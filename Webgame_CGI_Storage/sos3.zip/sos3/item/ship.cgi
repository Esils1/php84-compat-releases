# --------------------------------------------------- #
# Script of Saga III Ship.cgi Version 1
# Copyright (C) 2005 Missing Link.
# --------------------------------------------------- #

# Ship /�ϫ�?��/ #
%FI = (
    'Barca' =>
            { tp => '�ٸ���',
              ct => 0,
              im => 'barca.gif',
              gd => 1,
              db => 60 },
    'Kogg' =>
            { tp => '�ڱ�',
              ct => 1,
              im => 'kogg.gif',
              gd => 2,
              db => 80 },
    'Caravel' =>
            { tp => 'ī��',
              ct => 3,
              im => 'caravel.gif',
              gd => 3,
              db => 120 },
    'Carac' =>
            { tp => 'ī��',
              ct => 5,
              im => 'carac.gif',
              gd => 4,
              db => 160 },
    'Galleon' =>
            { tp => '������',
              ct => 7,
              im => 'galleon.gif',
              gd => 5,
              db => 200 },
);

# --------------------------------------------------- #
1;
