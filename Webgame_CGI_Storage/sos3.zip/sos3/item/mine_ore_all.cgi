# --------------------------------------------------- #
# Script of Saga III Mine Ore All.cgi Version 1
# Copyright (C) 2005 Missing Link.
# --------------------------------------------------- #

# Mine Ore All Data #
%FI = (
    '1000' =>
            { nm => '�׷��� �ֱ�',
              cl => 'Ig',
              id => 'Ingot01',
              im => 'ingot1.gif',
              qn => 1,
              bp => 10,
              gd => 1,
              wt => 0.5 },
     '500' =>
            { nm => '���� �ֱ�',
              cl => 'Ig',
              id => 'Ingot02',
              im => 'ingot2.gif',
              qn => 1,
              bp => 20,
              gd => 2,
              ef => 1,
              wt => 0.5 },
     '330' =>
            { nm => '���ο� �ֱ�',
              cl => 'Ig',
              id => 'Ingot03',
              im => 'ingot3.gif',
              qn => 1,
              bp => 30,
              gd => 3,
              ef => 2,
              wt => 0.5 },
     '225' =>
            { nm => '�׸� �ֱ�',
              cl => 'Ig',
              id => 'Ingot04',
              im => 'ingot4.gif',
              qn => 1,
              bp => 50,
              gd => 4,
              ef => 4,
              wt => 0.5 },
     '150' =>
            { nm => '���� �ֱ�',
              cl => 'Ig',
              id => 'Ingot05',
              im => 'ingot5.gif',
              qn => 1,
              bp => 70,
              gd => 5,
              ef => 6,
              wt => 0.5 },
      '90' =>
            { nm => '���� �ֱ�',
              cl => 'Ig',
              id => 'Ingot06',
              im => 'ingot6.gif',
              qn => 1,
              bp => 90,
              gd => 6,
              ef => 8,
              wt => 0.5 },
      '45' =>
            { nm => '���� �ֱ�',
              cl => 'Ig',
              id => 'Ingot07',
              im => 'ingot7.gif',
              qn => 1,
              bp => 110,
              gd => 7,
              ef => 10,
              wt => 0.5 },
      '15' =>
            { nm => '���� �ֱ�',
              cl => 'Ig',
              id => 'Ingot08',
              im => 'ingot8.gif',
              qn => 1,
              bp => 130,
              gd => 8,
              ef => 12,
              wt => 0.5 },
);

# --------------------------------------------------- #
1;
