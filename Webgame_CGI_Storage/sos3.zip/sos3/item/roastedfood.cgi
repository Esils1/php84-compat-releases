# --------------------------------------------------- #
# Script of Saga III Roastedfood.cgi Version 3 (1.4)
# Copyright (C) 2005-2007 Missing Link.
# --------------------------------------------------- #

# Roasted Food Data #
%FI = (
    '���' =>
            { nm => '��� ����',
              cl => 'Fd',
              id => 'Roastsardine',
              ql => 'R2',
              im => 'roastedfish.gif',
              bp => 12,
              ef => 'lf=8,hy=-1' },
    '�۾�' =>
            { nm => '�۾� ����',
              cl => 'Fd',
              id => 'Roasttrout',
              ql => 'R2',
              im => 'roastedfish.gif',
              bp => 18,
              ef => 'lf=10,hy=-1' },
    '�ް�' =>
            { nm => '�ް� �Ķ���',
              cl => 'Fd',
              id => 'Roastegg',
              ql => 'R2',
              im => 'sunnysideup.gif',
              bp => 10,
              ef => 'lf=6,hy=-1' },
    '�߰���' =>
            { nm => 'ġŲ�ٺ�ť',
              cl => 'Fd',
              id => 'Roastchicken',
              ql => 'R2',
              im => 'roastchicken.gif',
              bp => 15,
              ef => 'lf=9,hy=-1' },
    '�����' =>
            { nm => '����� ����',
              cl => 'Fd',
              id => 'Roastmutton',
              ql => 'R2',
              im => 'seekhkabab.gif',
              bp => 18,
              ef => 'lf=10,hy=-1' },
    '��������' =>
            { nm => '����',
              cl => 'Fd',
              id => 'Roastpork',
              ql => 'R2',
              im => 'roastpork.gif',
              bp => 20,
              ef => 'lf=12,hy=-1' },
    '�����' =>
            { nm => '����',
              cl => 'Fd',
              id => 'Roastbeef',
              ql => 'R2',
              im => 'roastbeef.gif',
              bp => 25,
              ef => 'lf=15,hy=-1' },
    '���' =>
            { nm => '��',
              cl => 'Mt',
              id => 'Ash',
              ql => 'Tr',
              im => 'ash.gif',
              bp => 5 },
);

# --------------------------------------------------- #
1;
