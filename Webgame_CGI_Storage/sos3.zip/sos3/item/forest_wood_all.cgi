# --------------------------------------------------- #
# Script of Saga III Forest Wood All.cgi Version 2 (1.2)
# Copyright (C) 2005-2007 Missing Link.
# --------------------------------------------------- #

# Forest Wood All Data #
%FI = (
    '1000' =>
            { nm => '������ ���',
              cl => 'Wd',
              id => 'Log01',
              im => 'wood1.gif',
              qn => 1,
              bp => 10,
              gd => 1,
              wt => 1 },
     '500' =>
            { nm => '��ǳ���� ���',
              cl => 'Wd',
              id => 'Log02',
              im => 'wood2.gif',
              qn => 1,
              bp => 20,
              gd => 2,
              ef => 1,
              wt => 1 },
     '330' =>
            { nm => '�ﳪ�� ���',
              cl => 'Wd',
              id => 'Log03',
              im => 'wood3.gif',
              qn => 1,
              bp => 30,
              gd => 3,
              ef => 2,
              wt => 1 },
     '225' =>
            { nm => '������ ���',
              cl => 'Wd',
              id => 'Log04',
              im => 'wood4.gif',
              qn => 1,
              bp => 50,
              gd => 4,
              ef => 4,
              wt => 1 },
     '150' =>
            { nm => '���ɳ��� ���',
              cl => 'Wd',
              id => 'Log05',
              im => 'wood5.gif',
              qn => 1,
              bp => 70,
              gd => 5,
              ef => 6,
              wt => 1 },
      '90' =>
            { nm => 'ġũ���� ���',
              cl => 'Wd',
              id => 'Log06',
              im => 'wood6.gif',
              qn => 1,
              bp => 90,
              gd => 6,
              ef => 8,
              wt => 1 },
      '45' =>
            { nm => '�������� ���',
              cl => 'Wd',
              id => 'Log07',
              im => 'wood7.gif',
              qn => 1,
              bp => 110,
              gd => 7,
              ef => 10,
              wt => 1 },
      '15' =>
            { nm => '���鳪�� ���',
              cl => 'Wd',
              id => 'Log08',
              im => 'wood8.gif',
              qn => 1,
              bp => 130,
              gd => 8,
              ef => 12,
              wt => 1 },
);

# --------------------------------------------------- #
1;
