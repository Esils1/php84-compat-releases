# --------------------------------------------------- #
# Script of Saga III Vessel.cgi Version 1
# Copyright (C) 2005 Missing Link.
# --------------------------------------------------- #

# Vessel Data #
%FI = (
    'Jarempty' =>
            { nm => '����',
              cl => 'Fv',
              id => 'Jarfull',
              ql => 'Vs',
              im => 'waterjar_full.gif',
              qn => 1,
              bp => 50,
              db => 30,
              wt => 2 },
    'Jarfull' =>
            { nm => '�� ����',
              cl => 'Ev',
              id => 'Jarempty',
              ql => 'Vs',
              im => 'waterjar_empty.gif',
              qn => 1,
              bp => 40,
              db => 0,
              wt => 2 },
);

# --------------------------------------------------- #
1;
