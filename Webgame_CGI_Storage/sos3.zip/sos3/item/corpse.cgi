# --------------------------------------------------- #
# Script of Saga III Corpse.cgi Version 3 (1.4)
# Copyright (C) 2005-2007 Missing Link.
# --------------------------------------------------- #

# Corpse Data /���� ������/ #
%FI = (
    '��' => [
            { nm => '�߰���',
              cl => 'Fd',
              id => 'Chicken',
              ql => 'Rf,Fl',
              im => 'chicken.gif',
              qn => 3.5,
              bp => 15,
              ef => 'lf=8',
              db => 0,
              wt => 0.1 },
     ],
    '����' => [
            { nm => '��������',
              cl => 'Fd',
              id => 'Pork',
              ql => 'Rf,Fl',
              im => 'pork.gif',
              qn => 6,
              bp => 20,
              ef => 'lf=12',
              db => 0,
              wt => 0.1 },
     ],
    '��' => [
            { nm => '�����',
              cl => 'Fd',
              id => 'Mutton',
              ql => 'Rf,Fl',
              im => 'mutton.gif',
              qn => 4,
              bp => 18,
              ef => 'lf=10',
              db => 0,
              wt => 0.1 },
     ],
    '��' => [
            { nm => '�Ұ���',
              cl => 'Fd',
              id => 'Beef',
              ql => 'Rf,Fl',
              im => 'beef.gif',
              qn => 7,
              bp => 25,
              ef => 'lf=15',
              db => 0,
              wt => 0.1 },
            { nm => '����',
              cl => 'Lt',
              id => 'Leather00',
              im => 'cowskin.gif',
              qn => 1,
              bp => 30,
              gd => 1,
              wt => 0.4 },
     ],
);

# --------------------------------------------------- #
1;
