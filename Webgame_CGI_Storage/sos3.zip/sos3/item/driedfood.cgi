# --------------------------------------------------- #
# Script of Saga III Driedfood.cgi Version 3 (1.4)
# Copyright (C) 2005-2007 Missing Link.
# --------------------------------------------------- #

# Dried Food Data #
%FI = (
    '���' =>
            { nm => '���� ���',
              cl => 'Fd',
              id => 'Driedsardine',
              ql => 'R3',
              im => 'driedfish.gif',
              bp => 12,
              ef => 'lf=8,hy=-1' },
    '�۾�' =>
            { nm => '���� �۾�',
              cl => 'Fd',
              id => 'Driedtrout',
              ql => 'R3',
              im => 'driedfish.gif',
              bp => 18,
              ef => 'lf=10,hy=-1' },
    '�����' =>
            { nm => '���� �����',
              cl => 'Fd',
              id => 'Driedmutton',
              ql => 'R3',
              im => 'jerky.gif',
              bp => 18,
              ef => 'lf=10,hy=-1' },
    '��������' =>
            { nm => '���� ��������',
              cl => 'Fd',
              id => 'Driedpork',
              ql => 'R3',
              im => 'jerky.gif',
              bp => 20,
              ef => 'lf=12,hy=-1' },
    '�Ұ���' =>
            { nm => '���� �Ұ���',
              cl => 'Fd',
              id => 'Driedbeef',
              ql => 'R3',
              im => 'jerky.gif',
              bp => 25,
              ef => 'lf=15,hy=-1' },
);

# --------------------------------------------------- #
1;
