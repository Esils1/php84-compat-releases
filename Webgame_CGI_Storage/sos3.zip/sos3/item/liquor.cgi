# --------------------------------------------------- #
# Script of Saga III Liquor.cgi Version 3 (1.4)
# Copyright (C) 2007 Missing Link.
# --------------------------------------------------- #

# Liquor Data /�� ������/ #
@FI = (
        { id => { Berry => 1, Sugar => 1, Mint => 1 },
          cl => { Ck => 1, Fv => 1 },
          ss => { Strawberry => 'Berry', Raspberry => 'Berry', Blueberry => 'Berry', Blackberry => 'Berry', Cassis => 'Berry' },
          gf => 'tc=1',
          gv => 'lf=1,vt=2',
          ex => 10,
          rl => 68,
          dt => { nm => '��������',
                  cl => 'Fd',
                  id => 'Berryfizz',
                  ql => 'Dr',
                  im => 'pinkfizz.gif',
                  qn => 1,
                  bp => 12,
                  ef => 'lf=2,hl=>4,hy=7',
                  wt => 0.2 } },
        { id => { Berry => 1, Yeast => 1, Mint => 1 },
          ss => { Strawberry => 'Berry', Raspberry => 'Berry', Blueberry => 'Berry', Blackberry => 'Berry', Cassis => 'Berry'  },
          cl => { Ba => 1, Fv => 1 },
          gf => 'tc=3',
          gv => 'lf=3,vt=2',
          ex => 30,
          rl => 64,
          dt => { nm => '���� ��',
                  cl => 'Fd,Dr,Al',
                  id => 'Liquorberry',
                  im => 'wine.gif',
                  qn => 1,
                  bp => 12,
                  ef => 'lf=1,hl=2,hy=11',
                  wt => 0.3 } },
        { id => { Tomato => 1, Lemon => 1 },
          cl => { Ck => 1 },
          gf => 'tc=1',
          gv => 'lf=1,vt=2',
          ex => 10,
          rl => 68,
          dt => { nm => '�丶�� �꽺',
                  cl => 'Fd',
                  id => 'Tomatojuice',
                  ql => 'Dr',
                  im => 'redfizz.gif',
                  qn => 1,
                  bp => 5,
                  ef => 'hl=>8,hy=1',
                  wt => 0.1 } },
);

# --------------------------------------------------- #
1;
