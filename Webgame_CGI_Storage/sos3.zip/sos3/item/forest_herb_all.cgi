# --------------------------------------------------- #
# Script of Saga III Forest Herb All.cgi Version 3 (1.4)
# Copyright (C) 2005-2007 Missing Link.
# --------------------------------------------------- #

# Forest Herb All Data #
%FI = (
    '450' =>
            { nm => '����',
              cl => 'Mt',
              id => 'Beehive',
              im => 'beehive.gif',
              qn => 1,
              bp => 10,
              wt => 0.2 },
    '400' =>
            { nm => '��Ʈ',
              cl => 'Mt',
              id => 'Mint',
              im => 'mint.gif',
              qn => 1,
              bp => 5,
              wt => 0.1 },
    '350' =>
            { nm => '����',
              cl => 'Mt',
              id => 'Redpepper',
              im => 'redpepper.gif',
              qn => 1,
              bp => 5,
              wt => 0.1 },
    '250' =>
            { nm => '����',
              cl => 'Mt',
              id => 'Garlic',
              im => 'garlic.gif',
              qn => 1,
              bp => 5,
              wt => 0.1 },
    '200' =>
            { nm => '����',
              cl => 'Mt',
              id => 'Mushroom',
              im => 'mushroom.gif',
              qn => 1,
              bp => 5,
              wt => 0.1 },
    '150' =>
            { nm => '�ų���',
              cl => 'Mt',
              id => 'Cinnamon',
              im => 'cinnamon.gif',
              qn => 1,
              bp => 5,
              wt => 0.1 },
    '100' =>
            { nm => '����',
              cl => 'Mt',
              id => 'Basil',
              im => 'basil.gif',
              qn => 1,
              bp => 5,
              wt => 0.1 },
    '50' =>
            { nm => '����',
              cl => 'Mt',
              id => 'Blackpepper',
              im => 'blackpepper.gif',
              qn => 1,
              bp => 5,
              wt => 0.1 },
);

# --------------------------------------------------- #
1;
