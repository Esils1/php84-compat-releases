# --------------------------------------------------- #
# Script of Saga III Product.cgi Version 3 (1.4)
# Copyright (C) 2005-2007 Missing Link.
# --------------------------------------------------- #

# Product Data #
%FI = (
    '��' => [
            { nm => '�ް�',
              cl => 'Fd',
              id => 'Egg',
              ql => 'Eg',
              im => 'egg.gif',
              qn => 3,
              bp => 10,
              ef => 'lf=6',
              wt => 0.1 },
    ],
    '��' => [
            { nm => '���',
              cl => 'Mt',
              id => 'Wool',
              im => 'wool.gif',
              qn => 1,
              bp => 30,
              wt => 0.2 },
    ],
    '��' => [
            { nm => '����',
              cl => 'Fd',
              id => 'Milk',
              ql => 'Ml',
              im => 'milk.gif',
              qn => 5,
              bp => 4,
              ef => 'lf=2,hl=2',
              wt => 0.1 },
    ],
);

# --------------------------------------------------- #
1;
