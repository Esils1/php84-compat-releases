# --------------------------------------------------- #
# Script of Saga III Animal Drug.cgi Version 2 (1.2)
# Copyright (C) 2005-2007 Missing Link.
# --------------------------------------------------- #

# Animal Drug Data /������ ������/ #
@FI = (
        { id => { Redliquid => 1,Mandrake => 1 },
          gf => 'tc=2',
          gv => 'lf=2,vt=2',
          ex => 20,
          rl => 68,
          dt => { nm => '�������',
                  cl => 'Fd',
                  id => 'Animaldruga',
                  ql => 'Fe',
                  im => 'animaldruga.gif',
                  qn => 1,
                  bp => 8,
                  ef => 'lf=20',
                  wt => 0.2 } },
);

# --------------------------------------------------- #
1;
