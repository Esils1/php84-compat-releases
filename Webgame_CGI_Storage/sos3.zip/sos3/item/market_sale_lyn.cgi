# --------------------------------------------------- #
# Script of Saga III Market Sale Lyn.cgi Version 2 (1.4)
# Copyright (C) 2007 Missing Link.
# --------------------------------------------------- #

# Market Sale Lyn #
@FI = (
            { nm => '�ô��� �帧[1.4ȣ]',
              cl => 'Mm',
              id => 'Readme',
              ql => 'Tr',
              im => 'magazine.gif',
              qn => 1,
              bp => 25,
              wt => 0.2, },
);

# --------------------------------------------------- #
1;
