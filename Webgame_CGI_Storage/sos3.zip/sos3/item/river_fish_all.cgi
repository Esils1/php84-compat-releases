# --------------------------------------------------- #
# Script of Saga III River Fish All.cgi Version 3 (1.4)
# Copyright (C) 2005-2007 Missing Link.
# --------------------------------------------------- #

# River Fish All Data #
%FI = (
    '400' =>    { nm => '���',
                cl => 'Fd',
                id => 'Sardine',
                ql => 'Rf,Fs',
                im => 'sardine.gif',
                qn => 1,
                bp => 12,
                ef => 'lf=6',
                wt => 0.1 },
    '150' =>    { nm => '�۾�',
                cl => 'Fd',
                id => 'Trout',
                ql => 'Rf,Fs',
                im => 'trout.gif',
                qn => 1,
                bp => 18,
                ef => 'lf=10',
                wt => 0.1 },
);

# --------------------------------------------------- #
1;
