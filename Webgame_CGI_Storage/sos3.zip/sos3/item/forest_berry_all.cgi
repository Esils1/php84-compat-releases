# --------------------------------------------------- #
# Script of Saga III Forest Berry All.cgi Version 3 (1.4)
# Copyright (C) 2005-2007 Missing Link.
# --------------------------------------------------- #

# Forest Berry All Data #
%FI = (
    '560' =>
            { nm => '�����',
              cl => 'Fd',
              id => 'Wildberry',
              ql => 'Ft,Rf,Ad',
              im => 'wildberry.gif',
              qn => 1,
              bp => 5,
              ef => 'lf=4',
              wt => 0.1 },
    '420' =>
            { nm => '���ġ�䳪�� ����',
              cl => 'Fd',
              id => 'Cassis',
              ql => 'Ft,R2',
              im => 'cassis.gif',
              qn => 1,
              bp => 5,
              ef => 'hl=3,hy=1',
              wt => 0.1 },
    '350' =>
            { nm => 'ü��',
              cl => 'Fd',
              id => 'Cherry',
              ql => 'Ft,R2',
              im => 'cherry.gif',
              qn => 1,
              bp => 5,
              ef => 'hl=3,hy=1',
              wt => 0.1 },
    '280' =>
            { nm => '����',
              cl => 'Fd',
              id => 'Strawberry',
              ql => 'Ft,R2',
              im => 'strawberry.gif',
              qn => 1,
              bp => 5,
              ef => 'hl=3,hy=1',
              wt => 0.1 },
    '210' =>
            { nm => '�����',
              cl => 'Fd',
              id => 'Raspberry',
              ql => 'Ft,R2',
              im => 'raspberry.gif',
              qn => 1,
              bp => 5,
              ef => 'hl=3,hy=1',
              wt => 0.1 },
    '140' =>
            { nm => '���纣��',
              cl => 'Fd',
              id => 'Blueberry',
              ql => 'Ft,R2',
              im => 'blueberry.gif',
              qn => 1,
              bp => 5,
              ef => 'hl=3,hy=1',
              wt => 0.1 },
    '70' =>
            { nm => '��������',
              cl => 'Fd',
              id => 'Blackberry',
              ql => 'Ft,R2',
              im => 'blackberry.gif',
              qn => 1,
              bp => 5,
              ef => 'hl=3,hy=1',
              wt => 0.1 },
);

# --------------------------------------------------- #
1;
