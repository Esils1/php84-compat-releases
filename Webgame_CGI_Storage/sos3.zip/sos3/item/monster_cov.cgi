# --------------------------------------------------- #
# Script of Saga III Monster(cov).cgi Version 2 (1.2)
# Copyright (C) 2005-2007 Missing Link.
# --------------------------------------------------- #

# Monster Data #
%FI = (
    '1000' =>
            { 'nm' => '������',
              'im' => 'mon_079.gif',
              'sk' => { },
              'lv' => 1,
              'tc' => 0,
              'dx' => 3,
              'st' => 0,
              'cn' => 2,
              'lf' => 10,
              'rh' => '������ ��/Sw/Rh,Sb/4/10/shortsword.gif',
              'ex' => 10,
              'gi' => 200,
              'i1' => { nm => '������ ��',
                        cl => 'Sw',
                        id => 'Badsword',
                        ql => 'Tr',
                        im => 'shortsword.gif',
                        qn => 1,
                        bp => 0,
                        ef => 'S1',
                        db => 10,
                        wt => 1.9 } },
    '500' =>
            { 'nm' => '������ ����',
              'im' => 'mon_098.gif',
              'sk' => { },
              'lv' => 1,
              'tc' => 1,
              'dx' => 4,
              'st' => 4,
              'cn' => 1,
              'lf' => 15,
              'ex' => 15,
              'gi' => 200,
              'i1' => { nm => '����',
                        cl => 'Mt',
                        id => 'Scorpion',
                        im => 'scorpion.gif',
                        qn => 1,
                        bp => 5,
                        wt => 0.1 } },
    '100' =>
            { 'nm' => '����� ����',
              'im' => 'mon_024.gif',
              'sk' => { },
              'lv' => 1,
              'tc' => 1,
              'dx' => 4,
              'st' => 8,
              'cn' => 1,
              'lf' => 25,
              'ex' => 35,
              'gi' => 200,
              'i1' => { nm => '���� ������',
                        cl => 'Bk',
                        id => 'Spellbook02',
                        im => 'spellbook2.gif',
                        qn => 1,
                        bp => 120,
                        gd => 2,
                        wt => 0.3,
                        cp => 'Mg,in=6' } },
);

# --------------------------------------------------- #
1;
