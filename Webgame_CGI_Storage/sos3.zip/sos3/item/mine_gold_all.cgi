# --------------------------------------------------- #
# Script of Saga III Mine Gold All.cgi Version 1
# Copyright (C) 2005 Missing Link.
# --------------------------------------------------- #

# Mine Gold All Data #
%FI = (
    '1000' =>
            { nm => '�� �ֱ�',
              cl => 'Pi',
              id => 'Preciousmetal01',
              im => 'silver.gif',
              qn => 1,
              bp => 20,
              gd => 1,
              wt => 0.5 },
     '200' =>
            { nm => '����',
              cl => 'Mt',
              id => 'Crystal',
              im => 'crystal.gif',
              qn => 1,
              bp => 10,
              gd => 1,
              ef => 2,
              wt => 0.5 },
     '100' =>
            { nm => '�� �ֱ�',
              cl => 'Pi',
              id => 'Preciousmetal02',
              im => 'gold.gif',
              qn => 1,
              bp => 40,
              gd => 2,
              ef => 1,
              wt => 0.5 },
      '30' =>
            { nm => '�÷�Ƽ�� �ֱ�',
              cl => 'Pi',
              id => 'Preciousmetal03',
              im => 'platinum.gif',
              qn => 1,
              bp => 80,
              gd => 3,
              ef => 2,
              wt => 0.5 },
);

# --------------------------------------------------- #
1;
