# --------------------------------------------------- #
# Script of Saga III Cloth.cgi Version 3 (1.3)
# Copyright (C) 2005-2007 Missing Link.
# --------------------------------------------------- #

# Cloth Data /�ʰ� ������/ #
@FI = (
        { id => { Wool => 1 },
          cl => { Sm => 1 },
          ss => { Cotton => 'Wool' },
          gf => 'lv=1',
          gv => 'lf=1,vt=2',
          ex => 10,
          rl => 68,
          dt => { nm => '��',
                  cl => 'Mt',
                  id => 'Thread',
                  im => 'thread.gif',
                  qn => 2,
                  bp => 15,
                  wt => 0.2 } },
        { id => { Thread => 2 },
          cl => { Lm => 1 },
          gf => 'lv=1',
          gv => 'lf=3,vt=2',
          gl => 10,
          ex => 10,
          rl => 80,
          dt => { nm => '���� �ʰ�',
                  cl => 'Ct',
                  id => 'Cloth01',
                  ql => 'Ct',
                  im => 'normalcloth.gif',
                  qn => 1,
                  bp => 30,
                  gd => 1,
                  wt => 0.5 } },
);

# --------------------------------------------------- #
1;
