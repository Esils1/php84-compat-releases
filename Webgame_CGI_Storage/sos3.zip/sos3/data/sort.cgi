# --------------------------------------------------- #
# Script of Saga III Sort.cgi Version 4 (1.4)
# Copyright (C) 2005-2007 Missing Link.
# --------------------------------------------------- #

my  $i;
my  @SO = (
    'Sm',
    'Lm',
    'Fv',
    'Ev',
    'Ba',
    'Ps',
    'Mi',
    'Sk',
    'Fi',
    'Ck',
    'Bs',
    'Sr',
    'Pl',
    'Sl',
    'Fr',
    'Tl',

    'Sf',
    'Bg',
    'Kn',

    'Sw',
    'Ax',
    'Sp',
    'Kt',
    'Bo',
    'Cl',
    'Wn',
    'Sh',

    'Hm',
    'Ht',
    'Ar',
    'Ds',
    'Bt',
    'Ac',
    'Rg',
    'Bk',

    'Dd',
    'Tm',
    'Cn',
    'Mm',
    'Tp',

    'Cu',
    'Ig',
    'Pi',
    'Cr',
    'Wd',
    'Ct',
    'Lt',
    'Mt',
    'Gd',
    'Fd',
    'Jw',
    'Gm',
);

foreach (@SO) { $SO{$_} = $i++ }

# --------------------------------------------------- #
1;
