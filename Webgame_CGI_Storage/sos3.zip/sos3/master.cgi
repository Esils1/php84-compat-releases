#!/usr/bin/perl

# �輭���� �°� ����
# �Ϲ������� #!/usr/local/bin/perl �Ǵ� #!/usr/bin/perl

# --------------------------------------------------- #
# Master of Saga III
    $version = 'b1.1';
# Copyright (C) 2005-2006 Missing Link.
# All rights reserved.
# ���� Sho
# E-mail: sho@area-s.com
# Home Page: http://www.area-s.com/
# �� ��ũ��Ʈ�� ���� ����Ʈ�����Դϴ�.
# �� ��ũ��Ʈ�� ����ϴ� ���� �Ʒ� URL�� �����
# �̿�Ծ࿡ ������ ������ �����մϴ�.
# http://www.area-s.com/main/rule.html
# ���۱��� MISSING LINK�� �����մϴ�.
# --------------------------------------------------- #

# ######################## �ʱ� �������� ########################
require './set.cgi';
if ($set::kpm) { require KCatch; import KCatch qw( source ) }
# if ($set::kpm) { use KCatch qw( source ) } # �� �ڵ忡 ������ ���� ���
require "$set::lib_dir/base.cgi";
# ###################### �������α׷� ���� ######################
$set::cgi_url = 'master.cgi';
$set::tit = 'Master of Saga III';
$set::pms = sprintf("%04d",oct($set::pms));
&decode;
if    ($F{md} eq 'main_menu')        { &main_menu        }
elsif ($F{md} eq 'edit_information') { &edit_information }
elsif ($F{md} eq 'make_information') { &make_information }
elsif ($F{md} eq 'edit_character')   { &edit_character   }
elsif ($F{md} eq 'make_character')   { &make_character   }
elsif ($F{md} eq 'edit_words')       { &edit_words       }
elsif ($F{md} eq 'delete_character') { &delete_character }
else                                 { &login            }
exit;
# ###################### �������α׷� ���� ######################

# Login #
sub login {
    &header(CSS=>'main');
    print <<"    END_OF_HTML";
    <form method=post action=$set::cgi_url>
    ������ ��й�ȣ <input type=password name=ps class=textbox size=8><br>
    <br>
    <input type=submit class=button value=OK>
    <input type=hidden name=md value=main_menu>
    </form>
    END_OF_HTML
    &footer;
}

# Sub Main Menu #
sub main_menu {
    &error('��й�ȣ�� Ʋ���ϴ�') if $F{ps} ne $set::pas;

    &header(CSS=>'main');
    $_[0] && print qq|<div><font color=red>$_[0]</font></div>|;
    print <<"    END_OF_HTML";
    <form method=post action=$set::cgi_url>
    <input type=radio name=md value=edit_information checked>���� �ۼ�<br>
    <input type=radio name=md value=edit_character>ĳ���� ���� ID: <input type=text name=ud class=textbox size=4><br>
    <input type=radio name=md value=edit_words>�ڱ�Ұ� ���� ID: <input type=text name=wid class=textbox size=4><br>
    <input type=radio name=md value=delete_character>ĳ���� ���� ID: <input type=text name=did class=textbox size=4><br>
    <br>
    <input type=submit class=button value=OK>
    <input type=hidden name=ps value=$F{ps}>
    </form>
    END_OF_HTML
    &footer;
}

# Sub Edit Information #
sub edit_information {
my  $t1;

    &error('��й�ȣ�� Ʋ���ϴ�') if $F{ps} ne $set::pas;

    @L = &open_dat("$set::dat_dir/information.cgi");
    $t1 = $L[0];
    $t1 =~ s/<br>/\n/g;

#    foreach (@L) {
#        $t1 .= $_ =~ s/<br>/\n/g;
#    }

    &header(CSS=>'sub');
    print <<"    END_OF_HTML";
    <div class=label>���� �ۼ�</div>
    <form method=post action=$set::cgi_url>
    <textarea class=textarea name=in cols=100 rows=30>$t1</textarea><br>
    <br>
    $set::but{OK}<br>
    <input type=hidden name=md value="make_information">
    <input type=hidden name=ps value="$F{ps}">
    </form>
    END_OF_HTML
    &footer;
}

# Sub Make Information #
sub make_information {
my  $t1;

    &error('��й�ȣ�� Ʋ���ϴ�') if $F{ps} ne $set::pas;

    $F{in} =~ s/&lt;/</g;
    $F{in} =~ s/&gt;/>/g;
    $F{in} =~ s/&#34;/"/g;
    $F{in} =~ s/&#44;/,/g;

    &write_dat("$set::dat_dir/information.cgi",$F{in});

    $t1 = &header(CSS=>'sub',GetTag=>1,Body=>" class=poem");
    $t1 .= $F{in};
    $t1 .= &footer(GetTag=>1);
    &write_dat($set::inf_htm,$t1);

    &main_menu('�����Ϸ�');
}

# Sub Edit Character #
sub edit_character {
my ($sx,$KG,$PL,$DA,$selected);

    &error('��й�ȣ�� Ʋ���ϴ�') if $F{ps} ne $set::pas;

    &say("ID�� �Է����ּ���",'main_menu') if $F{ud} eq '';

    $U = &get_user('U');
    &login_check($U);

    require "$set::dat_dir/place.cgi";
    require "$set::dat_dir/kingdom.cgi";
    require "$set::dat_dir/condition.cgi";

    map { $selected = $_ eq $U->{kg} ? ' selected' : '';
          $KG .= "<option$selected value=$_>$KG{$_}{nm}\n" } keys %KG;
    map { $selected = $_ eq $U->{pl} ? ' selected' : '';
          $PL .= "<option$selected value=$_>$PL{$_}{nm}\n" } keys %PL;

    foreach ('Av','Dd','St') {
        $selected = $_ eq $U->{da} ? ' selected' : '';
        $DA .= "<option$selected value=$_>$CD{$_}[1]\n";
    }

    $sx{$U->{sx}} = ' checked';

    &header(CSS=>'main');
    print <<"    END_OF_HTML";
    <div class=label>ĳ���� ����</div>
    <form method=post action=$set::cgi_url>
    <table class=innertable>
    <tr><td>�̸�</td><td><input type=text name=nm class=textbox value=$U->{nm}></td></tr>
    <tr><td>�̹��� ����</td><td><input type=text name=im class=textbox value=$U->{im}></td></tr>
    <tr><td>$set::lab{sx}</td><td><input type=radio name=sx class=radio$sx{m} value=m> <img src=$set::mim_dir/m.gif> <input type=radio name=sx class=radio$sx{w} value=w> <img src=$set::mim_dir/w.gif> <input type=radio name=sx class=radio$sx{0} value=0> <img src=$set::mim_dir/0.gif> <tt>NPC</tt></td></tr>
    <tr><td>$set::lab{kg}</td><td><select name=kg class=select>$KG</select>
    <tr><td>�� ��ġ</td><td><select name=pl class=select>$PL</select>
    <tr><td>$set::lab{jb}</td><td><input type=text name=jb class=textbox value=$U->{jb}></td></tr>
    <tr><td>���</td><td><input type=text size=20 name=sk class=textbox value=$U->{sk}></td></tr>
    <tr><td>$set::lab{lv}</td><td><input type=text size=2 name=lv class=textbox value=$U->{lv}></td></tr>
    <tr><td>$set::lab{ex}</td><td><input type=text size=5 name=ex class=textbox value=$U->{ex}></td></tr>
    <tr><td>$set::lab{gl}</td><td><input type=text size=5 name=gl class=textbox value=$U->{gl}> $set::mny</td></tr>
    <tr><td>$set::lab{lf}</td><td><input type=text size=3 name=lf class=textbox value=$U->{Mlf}></td></tr>
    <tr><td>$set::lab{tc}</td><td><input type=text size=3 name=tc class=textbox value=$U->{tc}></td></tr>
    <tr><td>$set::lab{st}</td><td><input type=text size=3 name=st class=textbox value=$U->{st}></td></tr>
    <tr><td>$set::lab{dx}</td><td><input type=text size=3 name=dx class=textbox value=$U->{dx}></td></tr>
    <tr><td>$set::lab{in}</td><td><input type=text size=3 name=in class=textbox value=$U->{in}></td></tr>
    <tr><td>$set::lab{cn}</td><td><input type=text size=3 name=cn class=textbox value=$U->{cn}></td></tr>
    <tr><td>$set::lab{vt}</td><td><input type=text size=3 name=vt class=textbox value=$U->{Mvt}></td></tr>
    <tr><td>$set::lab{hl}</td><td><input type=text size=3 name=hl class=textbox value=$U->{Mhl}></td></tr>
    <tr><td>$set::lab{ap}</td><td><input type=text size=3 name=ap class=textbox value=$U->{Map}></td></tr>
    <tr><td>$set::lab{hy}</td><td><input type=text size=3 name=hy class=textbox value=$U->{Mhy}></td></tr>
    <tr><td>$set::lab{da}</td><td><select name=da class=select>$DA</select></td></tr>
    <tr><td>$set::lab{ij}</td><td><input type=text size=2 name=ij class=textbox value=$U->{ij}></td></tr>
    <tr><td>$set::lab{cd}</td><td><input type=text size=20 name=cd class=textbox value=$U->{cd}></td></tr>
    <tr><td>�¸� Ƚ��</td><td><input type=text size=3 name=wn class=textbox value=$U->{wn}></td></tr>
    <tr><td>�й� Ƚ��</td><td><input type=text size=3 name=ls class=textbox value=$U->{ls}></td></tr>
    <tr><td>��� Ƚ��</td><td><input type=text size=3 name=dr class=textbox value=$U->{dr}></td></tr>
    <tr><td>���� Ƚ��</td><td><input type=text size=3 name=kl class=textbox value=$U->{kl}></td></tr>
    <tr><td>��� Ƚ��</td><td><input type=text size=3 name=dt class=textbox value=$U->{dt}></td></tr>
    <tr><td>���� Rate</td><td><input type=text size=4 name=rt class=textbox value=$U->{rt}></td></tr>
    <tr><td>$set::lab{rw}</td><td><input type=text size=4 name=rw class=textbox value=$U->{rw}></td></tr>
    <tr><td>�ڼ�</td><td><input type=text size=2 name=sc class=textbox value=$U->{sc}></td></tr>
    <tr><td>$set::eqp{rh}</td><td><input type=text size=40 name=rh class=textbox value=$U->{rh}></td></tr>
    <tr><td>$set::eqp{lh}</td><td><input type=text size=40 name=lh class=textbox value=$U->{lh}></td></tr>
    <tr><td>$set::eqp{sb}</td><td><input type=text size=40 name=db class=textbox value=$U->{sb}></td></tr>
    <tr><td>$set::eqp{hd}</td><td><input type=text size=40 name=hd class=textbox value=$U->{hd}></td></tr>
    <tr><td>$set::eqp{bd}</td><td><input type=text size=40 name=bd class=textbox value=$U->{bd}></td></tr>
    <tr><td>$set::eqp{lg}</td><td><input type=text size=40 name=lg class=textbox value=$U->{lg}></td></tr>
    <tr><td>$set::eqp{nk}</td><td><input type=text size=40 name=nk class=textbox value=$U->{nk}></td></tr>
    <tr><td>$set::eqp{fg}</td><td><input type=text size=40 name=fg class=textbox value=$U->{fg}></td></tr>
    <tr><td>�����ѵ�</td><td><input type=text size=3 name=Mbg class=textbox value=$U->{Mbg}></td></tr>
    <tr><td>$set::lab{gu}</td><td><input type=text size=3 name=gu class=textbox value=$U->{gu}></td></tr>
    <tr><td>$set::lab{py}</td><td><input type=text size=3 name=py class=textbox value=$U->{py}></td></tr>
    <tr><td>ģ��</td><td><input type=text size=20 name=fr class=textbox value=$U->{fr}></td></tr>
    <tr><td>�������</td><td><input type=text size=25 name=en class=textbox value=$U->{en}></td></tr>
    <tr><td>����</td><td><input type=text size=20 name=mg class=textbox value=$U->{mg}></td></tr>
    <tr><td>������ �ڱ�Ұ�</td><td><input type=text size=60 name=w1 class=textbox value=$U->{w1}></td></tr>
    <tr><td>����</td><td><input type=text size=40 name=ob class=textbox value=$U->{ob}></td></tr>
    <tr><td>�Ǹ��ѵ�</td><td><input type=text size=3 name=vx class=textbox value=$U->{vx}></td></tr>
    <tr><td>�������</td><td><input type=text size=3 name=bs class=textbox value=$U->{bs}></td></tr>
    <tr><td>���ڻ�</td><td><input type=text size=7 name=fc class=textbox value=$U->{fc}></td></tr>
    <tr><td>�ֿϵ��� �ѵ�</td><td><input type=text size=3 name=Mpx class=textbox value=$U->{Mpx}></td></tr>
    <tr><td>������ �ֿϵ���</td><td><input type=text size=3 name=co class=textbox value=$U->{co}></td></tr>
    <tr><td>��Ʈ���</td><td><input type=text size=3 name=pc class=textbox value=$U->{pc}></td></tr>
    <tr><td>������ ���ʽ�</td><td><input type=text size=3 name=lb class=textbox value=$U->{lb}></td></tr>
    <tr><td>���� �ִ� �����ѵ�</td><td><input type=text size=3 name=bk class=textbox value=$U->{bk}></td></tr>
    </table>
    <br>
    $set::but{OK}
    <input type=hidden name=ud value=$F{ud}>
    <input type=hidden name=ps value=$F{ps}>
    <input type=hidden name=pl2 value=$U->{pl}>
    <input type=hidden name=bg value=$U->{bg}>
    <input type=hidden name=px value=$U->{px}>
    <input type=hidden name=md value=make_character>
    </form>
    END_OF_HTML
    &footer;
}

# Sub Made Character #
sub make_character {
my ($F,@F);

    &error('��й�ȣ�� Ʋ���ϴ�') if $F{ps} ne $set::pas;
    &error('������ �����Դϴ�') if $ENV{'REQUEST_METHOD'} ne 'POST';
    &say("�̸��� �Է����ּ���",'edit_character') if $F{nm} eq '';
    &say("�̸��� �ѱ� $set::nmx�ڱ��� �����մϴ�",'edit_character') if length $F{nm} > $set::nmx * 2;

    require "$set::lib_dir/placechange.cgi";

    $U = &get_user('U');

    @F = keys %F;

    foreach (@F) {
        next if $_ eq 'ps';
        $F{$_} =~ s/&#44;/,/g;
        $U->{$_} = $F{$_};
    }
    foreach (@set::gva) {
        $U->{"M$_"} = $F{$_};
    }
    foreach (@set::sdt) {
        $U->{"M$_"} = $F{"M$_"};
    }

    &set_user($U);

    if ($F{pl} ne $F{pl2}) {
        $F = index($U->{id},'_') ? 0 : 1;
        &del_place($U) if $F{pl2};
        &set_place($U,$F);
    }
    &main_menu('���� �Ϸ�');
}

# Sub Delete Character #
sub delete_character {
    $F{id} = $F{did};
    &error('��й�ȣ�� Ʋ���ϴ�') if $F{ps} ne $set::pas;
    &error('������ �����Դϴ�') if $ENV{'REQUEST_METHOD'} ne 'POST';
    &say("ID�� �Է����ּ���",'main_menu') if $F{id} eq '';

    $I = &get_user('I');

    require "$set::lib_dir/placechange.cgi";
    require "$set::lib_dir/information.cgi";
    require "$set::lib_dir/delete.cgi";

    &delete_place($I);

    &delete_file($F{id});
    &total_players;
    &main_menu('���� �Ϸ�');
}

sub edit_words {
    &header(CSS=>'main');
    print <<"    END_OF_HTML";
    <div class=label>NPC ����</div>
    <form method=post action=$set::cgi_url>
    <table class=innertable>
    <tr><td>���� �ڱ�Ұ�</td><td><textarea class=textbox name=w2 cols=40 rows=8>$I->{w2}</textarea></td></tr>
    <tr><td>��밡 �������� ������ ��</td><td><textarea class=textbox name=w3 cols=40 rows=3>$I->{w3}</textarea></td></tr>
    <tr><td>�������� �ȷ��� ��</td><td><input type=text size=60 name=w4 class=textbox value=$I->{w4}></td></tr>
    <tr><td>�������� �¸����� ��</td><td><input type=text size=60 name=w5 class=textbox value=$I->{w5}></td></tr>
    <tr><td>�������� �й����� ��</td><td><input type=text size=60 name=w6 class=textbox value=$I->{w6}></td></tr>
    <tr><td>���ش����� ��</td><td><input type=text size=60 name=w7 class=textbox value=$I->{w7}></td></tr>
    <tr><td>���� �ŷ��� �������� ��</td><td><input type=text size=60 name=w8 class=textbox value=$I->{w8}></td></tr>
    </table>
    <br>
    <input type=submit class=button value=OK>
    <input type=hidden name=ps value=$F{ps}>
    <input type=hidden name=pl2 value=$I->{pl}>
    <input type=hidden name=md value=make_character>
    </form>
    END_OF_HTML
    &footer;
}

