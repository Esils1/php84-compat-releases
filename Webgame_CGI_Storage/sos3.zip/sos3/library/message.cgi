# --------------------------------------------------- #
# Script of Saga III Message.cgi Version 1
# Copyright (C) 2005 Missing Link.
# --------------------------------------------------- #

# Sub Message Before #
sub message_before {
    $I = &get_user('I');
    $U = &get_user('U');
    &place_check($U);

    &get_code;

	require "$set::lib_dir/partner.cgi";

    &header(CSS=>'sub',JavaScript=>"OpenWindow");
    print "<div class=label>�޼��� ������</div>\n";

    &partner_talk;

    print <<"    END_OF_HTML";
    <form method=post action=$set::cgi_url>
    <div class=outbox>
    <tt>���ڼ� ����: �ѱ� ���� $set::msx�ڱ���</tt><br>
    <input type=textbox name=msg class=textbox size=60><br>
    <div class=r>$set::but{OK}</div>
    <input type=hidden name=md value="message_after">
    <input type=hidden name=id value="$F{id}">
    <input type=hidden name=ud value="$F{ud}">
    <input type=hidden name=ps value="$F{ps}">
    <input type=hidden name=xx value="$I->{XX}">
    </div>
    </form>
    END_OF_HTML
	&partner_select;
    &footer;
}

# Sub Message After #
sub message_after {
    $I = &get_user('I');
    $U = &get_user('U');
    &place_check($U);

    if (length $F{msg} > $set::msx * 2) { &say("�޼����� �ѱ� ���� $set::msx�ڱ��� �����մϴ�",'message_before') }

    &set_code;

	require "$set::lib_dir/myrecord.cgi";
	require "$set::lib_dir/partner.cgi";

	$F{msg} = "$I->{nm}: <font color=$I->{fc}>��$F{msg}��</font>";

    &set_record($F{msg});
    &partner('','�޼����� ����');
}

# --------------------------------------------------- #
1;