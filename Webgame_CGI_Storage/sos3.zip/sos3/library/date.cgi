# --------------------------------------------------- #
# Script of Saga III Date.cgi Version 1
# Copyright (C) 2005 Missing Link.
# --------------------------------------------------- #

# Get Date #
sub get_date {
my  @wk;
my ($sc,$mn,$hr,$dy,$mt,$yr,$wd) = localtime(time);

    $ENV{'TZ'} = "GMT-9";
    $yr -= 100;
    @wk = ('Sun','Mon','Tue','Wed','Thu','Fri','Sat');
    return sprintf("%02d/%02d/%02d [%s] %02d:%02d",$yr,$mt+1,$dy,$wk[$wd],$hr,$mn);
}

# Departure Time #
sub departure_time {
my  $V = shift;

my ($mn,$hr,$dy,$mt) = (localtime($V))[1,2,3,4];

    $ENV{'TZ'} = "GMT-9";
    return sprintf("%02d/%02d %02d:%02d",$mt+1,$dy,$hr,$mn);
}

# --------------------------------------------------- #
1;