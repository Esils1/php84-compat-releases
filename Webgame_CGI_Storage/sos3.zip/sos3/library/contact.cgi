# --------------------------------------------------- #
# Script of Saga III Contact.cgi Version 1
# Copyright (C) 2005 Missing Link.
# --------------------------------------------------- #

# Contact Before #
sub contact_before {
my  $t1;

    $I = &get_user('I');

    &dead_check($I,'CLOSE');

    &get_place($I);
    &get_resident($I);

    &say("$I->{Pl}{nm}���� �ƹ��� �����ϴ�...",'CLOSE') if !$#{$I->{Pp}};

    foreach (@{$I->{Pp}}) {
        next if $_ eq $I->{id};
        $U = &get_user('A',$_);
        next if !$U;
        $U->{Id} = index($U->{id},'_') ? $U->{id} : 'NPC';
        &condition_initial($U,'da');
        $t1 .= qq|<option value="$U->{id}">$U->{Id}:  $U->{nm}��$U->{jb}����$U->{Da}{in}�� R: $U->{rt}</option>\n|;
    }

    &get_code;

    &header(CSS=>'sub');
    print <<"    END_OF_HTML";
    <div class=label>$I->{Pl}{nm}�� �ִ� �÷��̾� ����</div>
    <form method=post action=$set::cgi_url>
    <div class=outbox>
    <tt>����: <select name=ud class=select>$t1</select></tt><br>
    <br>
    <tt>ID: <input type=text name=ud2 class=textbox size=4></tt><br>
    <br>
    <div class=r>$set::but{OK} $set::but{CLOSE}</div>
    <input type=hidden name=md value="contact_after">
    <input type=hidden name=id value="$F{id}">
    <input type=hidden name=ps value="$F{ps}">
    <input type=hidden name=xx value="$I->{XX}">
    </div>
    </form>
    END_OF_HTML
    &footer;
}

# Contact After #
sub contact_after {
    require "$set::lib_dir/partner.cgi";

    if ($F{ud2}) {
        &say("ID�� ����,�����̿��� ���ڸ� �Է��� �� �����ϴ�",'contact_before') if $F{ud2} =~ /[^a-zA-Z\d]/;
        $F{ud} = $F{ud2};
    }

    $I = &get_user('I');
    $U = &get_user('U');

    &login_check($U);
    &place_check($U);

    &say("$U->{nm}���� ã�� �� �����ϴ�.",'contact_before') if $U->{Sk}{Hd} && $U->{lf} < $U->{Mlf} * $set::sHd;

    &set_code;

    &get_words($U);
    &partner($U->{w2});
}

# --------------------------------------------------- #
1;
