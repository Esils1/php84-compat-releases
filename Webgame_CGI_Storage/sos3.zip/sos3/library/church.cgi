# --------------------------------------------------- #
# Script of Saga III Church.cgi Version 2 (1.2)
# Copyright (C) 2005-2007 Missing Link.
# --------------------------------------------------- #

# Sub Church Before #
sub church_before {
my ($V1,$V2);

    $I = &get_user('I');

    &get_code;

    $V1 = $set::acm * $I->{lv};
    $V2 = $set::rvm * $I->{lv};

    &header(CSS=>'sub');
    print <<"    END_OF_HTML";
    <div class=label>??</div>
    <form method=post action=$set::cgi_url>
    <div class=outbox>
    <img src=$set::mim_dir/envCh.gif><br>
    <br>
    <input type=radio class=radio name=tp value=Cs checked> ���� �����ϱ�<br>
    <input type=radio class=radio name=tp value=Dd> ĳ���� ��Ȱ��Ű��<br>
    <br>
    <div class=r><tt>���ָ� �����Ϸ��� $V1 $set::mny �ʿ��մϴ�.</tt><br><tt>��Ȱ��Ű���� $V2 $set::mny �ʿ��մϴ�.</tt><br>$set::but{OK} $set::but{CLOSE}</div>
    <input type=hidden name=md value="church_after">
    <input type=hidden name=id value="$F{id}">
    <input type=hidden name=ps value="$F{ps}">
    <input type=hidden name=xx value="$I->{XX}">
    </div>
    </form>
    END_OF_HTML
    &footer;
}

# Church After #
sub church_after {
my  $V;

    $I = &get_user('I');

    if ($F{tp} eq 'Dd') {
        &say("$set::cnd{'Dd'}[1] ���°� �ƴմϴ�",'church_before') if $I->{da} ne 'Dd';
        $V = $set::rvm * $I->{lv};
        &M("$Ui->{Im} ��Ȱ�߽��ϴ�.");
        &change_condition($I,'da');
        &reload_data('revive','&nbsp;');
    }
    else {
        &say("$set::cnd{'Cs'}[1] ���°� �ƴմϴ�",'church_before') if !$I->{Cd}{Cs};
        $V = $set::acm * $I->{lv};
        &M("$I->{Cd}{Cs}�� Ǯ�Ƚ��ϴ�.");
        &change_condition($I,'cd','Cs');
    }

    &say("���� �����մϴ�.",'church_before') if $I->{gl} < $V;
    &change_status($I,'gl',-$V);

    &set_code;

    &set_user($I);

    &reload_data('gl');

    &inner_HTML;

    &say($I->{M},'CLOSE','Reload');
}

# --------------------------------------------------- #
1;
