# --------------------------------------------------- #
# Script of Saga III Contact.cgi Version 4 (1.4)
# Copyright (C) 2005-2007 Missing Link.
# --------------------------------------------------- #

# Player List #
sub playerlist {
my ($t1,$t2,@T);

    &playerlist_statistics if $F{or} eq 'Ps';
    &sales_information if $F{or} eq 'Si';

    $I->{pl} = $F{pl};
    $I->{pl} || &error('No Place');

    &get_resident($I);

    foreach (@{$I->{Pp}}) {
        $U = &get_user('U',$_) or next;
        next if $F{or} eq 'Cz' && !$U->{Sk}{Cz};
        next if $F{or} eq 'Ft' &&  $U->{Sk}{Cz};
        next if $F{or} eq 'Bt' &&  $U->{rw} < $set::sps;
        $U->{Li} = &login_check($U,'noerror') ? '��' : '��';
        $U->{Id} = index($U->{id},'_') ? $U->{id} : 'NPC';
        &condition_initial($U,'da');
        &condition_initial($U,'ij');
        &condition_initial($U,'cd');
        @{$U->{Ob}} = map { &orb_image($_) }
                     grep { /[a-z]/ } split(//,$U->{ob});
        &get_item($U);
        &get_pet($U);
        undef @T;
        foreach $Ui (@{$U->{Bg}},@{$U->{Pt}}) {
            next unless $Ui->{sp} && !$Ui->{rs};
            $t2  = $Ui->{nm};
            $t2 .= "+$Ui->{pl}" if $Ui->{pl};
            $t2  = "<span class=i$Ui->{gd}>$t2</span>" if $Ui->{gd};
            $t2 .= "x$Ui->{qn}" if $Ui->{qn} > 1;
            push(@T,"$t2=$Ui->{sp}$set::mny");
        }
        $t2 = join(' ',@T);
        $U->{Ob} = join('',@{$U->{Ob}});
        $U->{gu} &&= "<img src=$set::mim_dir/guild$U->{gu}.gif>";
        $t1 .= qq|<tr>|;
        $t1 .= qq|<td>$U->{Id}</td>|;
        $t1 .= qq|<td nowrap>$U->{nm}</td>|;
        $t1 .= qq|<td><img src=$set::mim_dir/$U->{sx}.gif></td>|;
        $t1 .= qq|<td nowrap>$U->{jb}</td>|;
        $t1 .= qq|<td>$U->{gu}</td>|;
        $t1 .= qq|<td>$U->{wn}</td>|;
        $t1 .= qq|<td>$U->{ls}</td>|;
        $t1 .= qq|<td>$U->{kl}</td>|;
        $t1 .= qq|<td>$U->{dt}</td>|;
        $t1 .= qq|<td nowrap>$U->{rt}</td>|;
        $t1 .= qq|<td>$U->{Da}{in}</td>|;
        $t1 .= qq|<td>$U->{Ij}{in}</td>|;
        $t1 .= qq|<td nowrap>$U->{Cd}{in}</td>|;
        $t1 .= qq|<td>$U->{Li}</td>|;
        $t1 .= qq|<td class=r>$U->{rw} $set::mny</td>|;
        $t1 .= qq|<td>$U->{w1}</td>|;
        $t1 .= qq|</tr>\n|;
        $t1 .= qq|<tr class=sec><td colspan=10>$U->{Ob}</td><td colspan=6>$t2</td></tr>\n| if $U->{Ob} || $t2;
    }

    &header(CSS=>'list');
    print <<"    END_OF_HTML";
    <table>
    <tr>
    <th>ID</th>
    <th nowrap>�̸�</th>
    <th>��</th>
    <th nowrap>����</th>
    <th nowrap>��</th>
    <th>��</th>
    <th>��</th>
    <th>��</th>
    <th>��</th>
    <th nowrap>Rate</th>
    <th>��</th>
    <th>��</th>
    <th>��</th>
    <th>��</th>
    <th nowrap>$set::lab{rw}</th>
    <th width=100%>�ڸ�Ʈ</th>
    </tr>
    <tr><th colspan=10>����</th><th colspan=6>�Ǹ�</th></tr>
    $t1
    </table>
    END_OF_HTML
    &footer;
}

# Player List Statistics #
sub playerlist_statistics {
my (@L,$L,$K,$V,$P,$G,%SO);
my ($t1,$t2,$t3);

    &transfer_HTML($set::stt_htm) if !&schedule_monitor(1);

    @L = &get_allusersID(1);
    $L->{npc} = @L;

    @L = &get_allusersID();
    $L->{tp} = $L->{c} = $L->{f} = $L->{m} = $L->{w} = 0;

    $set::psl = 2;

    foreach (@L) {
        $U = &get_user('A',$_);
        $L->{tp}++; # Total
        $L->{c}++ if $U->{sk} =~ /Cz/; # Citizen
        $L->{m}++ if $U->{sx} eq 'm';
        $L->{w}++ if $U->{sx} eq 'w';
        $L->{jb}{$U->{jb}}++;
        $L->{lv}[$U->{lv}]++;
        $L->{pl}{$U->{pl}}++;
    }

    $L->{f}  = $L->{tp} - $L->{c}; # Fighter
    $L->{mp} = $L->{tp} ? int($L->{m} / $L->{tp} * 100) : 0;
    $L->{wp} = $L->{tp} ? 100 - $L->{mp} : 0;
    $L->{mi} = &statistics_gage($L->{mp},4);
    $L->{wi} = &statistics_gage($L->{wp},1);
    $L->{fp} = $L->{tp} ? int($L->{f} / $L->{tp} * 100) : 0;
    $L->{cp} = $L->{tp} ? 100 - $L->{fp} : 0;
    $L->{fi} = &statistics_gage($L->{fp},4);
    $L->{ci} = &statistics_gage($L->{cp},1);

    require "$set::dat_dir/job.cgi";

    foreach (@JB) { $SO{$_->{nm}} = $i++ }
    @{$L->{Jb}} = sort{ $SO{$a} <=> $SO{$b} } keys %{$L->{jb}};

    foreach $K (@{$L->{Jb}}) {
        $V = $L->{jb}{$K};
        $V ||= 0;
        $P = int($V / $L->{tp} * 100);
        $G = &statistics_gage($P,3);
        $t1 .= "<tr><td nowrap>$K</td><td nowrap align=right>$V��</td><td nowrap align=right>$P%</td><td width=100%>$G</td></tr>\n";
    }

    foreach $K (0 .. $#{$L->{lv}}) {
        $V = $L->{lv}[$K];
        next if !$V;
        $P = int($V / $L->{tp} * 100);
        $G = &statistics_gage($P,3);
        $t2 = "<tr><td nowrap>$set::lab{lv} $K</td><td nowrap align=right>$V��</td><td nowrap align=right>$P%</td><td width=100%>$G</td></tr>\n".$t2;
    }

    require "$set::dat_dir/place.cgi";

    @{$L->{Pl}} = sort{ $PL{$a}{nm} cmp $PL{$b}{nm} } keys %PL;

    foreach $K (@{$L->{Pl}}) {
        $V = $L->{pl}{$K};
        next if !$V;
        $K = $PL{$K}{nm};
        $P = int($V / $L->{tp} * 100);
        $G = &statistics_gage($P,3);
        $t3 .= "<tr><td nowrap>$K</td><td nowrap align=right>$V��</td><td nowrap align=right>$P%</td><td width=100%>$G</td></tr>\n";
    }

    $t4  = &header(CSS=>'list',GetTag=>1);
    $t4 .= <<"    END_OF_HTML";
    <div class=label>�α����</div>
    <table>
    <tr><td nowrap colspan=4 class=heading>�� �α�</td></tr>
    <tr><td nowrap>NPC�α�</td><td align=right>$L->{npc}��</td><td colspan=2 width=100%></td></tr>
    <tr><td nowrap>�÷��̾� �α�</td><td align=right>$L->{tp}��</td><td colspan=2 width=100%></td></tr>
    <tr><td nowrap colspan=4 class=heading>�����</td></tr>
    <tr><td nowrap>��</td><td nowrap align=right>$L->{m}��</td><td nowrap align=right>$L->{mp}%</td><td width=100%>$L->{mi}</td></tr>
    <tr><td nowrap>��</td><td nowrap align=right>$L->{w}��</td><td nowrap align=right>$L->{wp}%</td><td width=100%>$L->{wi}</td></tr>
    <tr><td nowrap colspan=4 class=heading>���뺰</td></tr>
    <tr><td nowrap>������</td><td nowrap align=right>$L->{f}��</td><td nowrap align=right>$L->{fp}%</td><td width=100%>$L->{fi}</td></tr>
    <tr><td nowrap>�����</td><td nowrap align=right>$L->{c}��</td><td nowrap align=right>$L->{cp}%</td><td width=100%>$L->{ci}</td></tr>
    <tr><td nowrap colspan=4 class=heading>������</td></tr>
    $t1
    <tr><td nowrap colspan=4 class=heading>������</td></tr>
    $t2
    <tr><td nowrap colspan=4 class=heading>������</td></tr>
    $t3
    </table>
    END_OF_HTML
    $t4 .= &footer(GetTag=>1);
    &write_dat($set::stt_htm,$t4);
    &transfer_HTML($set::stt_htm);
}

# Sub Sales Information #
sub sales_information {
my (@L,@T,$T);
my ($t1,$t2);

    &transfer_HTML($set::sli_htm) if time - (stat("$set::sli_htm"))[9] < $set::ssi * 60;

    @L = &get_allusersID();

    require "$set::dat_dir/place.cgi";

    foreach (@L) {
        $U = &get_user('A',$_);
        &get_item($U);
        &get_pet($U);
        foreach $Ui (@{$U->{Bg}},@{$U->{Pt}}) {
            # �ǸŰ����� �����ǰ� �����ڰ� ����
            next unless $Ui->{sp} && !$Ui->{rs};
            $Ui->{Id} = $U->{id};
            $Ui->{Nm} = $U->{nm};
            $Ui->{Pl} = $PL{$U->{pl}}{nm};
            push (@T,$Ui);
        }
    }

    require "$set::dat_dir/sort.cgi";

    @T = sort { $SO{$a->{cl}} <=> $SO{$b->{cl}} || $a->{id} cmp $b->{id} || $a->{sp} <=> $b->{sp} } @T;


    foreach $T (@T) {
        $T->{nm} .= "+$T->{pl}" if $T->{pl};
        $T->{nm} .= " x $T->{qn}" if $T->{qn} > 1;
        $t1 .= "<tr><td nowrap>$T->{nm}</td><td>$T->{gd}</td><td nowrap align=right>$T->{sp} $set::mny</td><td nowrap>$T->{Id}</td><td nowrap>$T->{Nm}</td><td width=100%>$T->{Pl}</td></tr>\n";
    }

    $t2  = &header(CSS=>'list',GetTag=>1);
    $t2 .= <<"    END_OF_HTML";
    <div class=label>�Ǹ�����</div>
    <table>
    <tr><th nowrap>��ǰ��</th><th nowrap>�ݾ�</th><th nowrap>ID</th><th nowrap>�Ǹ���</th><th width=100%>��ġ</th></tr>
    $t1
    </table>
    END_OF_HTML
    $t2 .= &footer(GetTag=>1);
    &write_dat($set::sli_htm,$t2);
    &transfer_HTML($set::sli_htm);
}

# Sub Statistics Gage #
sub statistics_gage {
my  $L = shift;
my  $C = shift;
my  $X;

    $L  = int($L) * $set::psl;
    $X  = 100 * $set::psl - $L;
    $L  = qq|<img src=$set::mim_dir/gage$C.gif width=$L height=8>|;
    $X  = qq|<img src=$set::mim_dir/gage0.gif width=$X height=8>| if $X;
    $X  = undef if !$X;
    return("<span class=gage>$L$X</span>");
}

# --------------------------------------------------- #
1;
