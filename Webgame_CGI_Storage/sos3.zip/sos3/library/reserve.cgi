# --------------------------------------------------- #
# Script of Saga III Reserve.cgi Version 2 (1.4)
# Copyright (C) 2005-2007 Missing Link.
# --------------------------------------------------- #

# Sub Reserve Before #
sub reserve_before {
my  $i;
my  $Ii;
my  $t1;

    $I = &get_user('I');
    if ($F{fl} eq 'pet') {
        &get_pet($I);
        $I->{Bg} = $I->{Pt};
    }
    else {
        &get_item($I);
    }

    foreach $Ii (@{$I->{Bg}}) {
        $i++;
        next if !$Ii;
		next if !$F{$i};
	    if (!$Ii->{sp}) { $t1 .= "$Ii->{nm}(��)�� ������ �������� �ʾҽ��ϴ�.<br>\n" }
	    else {
            $t1 .= qq|<input type=textbox name=$i class=textbox size=5 value="$Ii->{rs}"> |;
            $t1 .= &decorate_item($Ii);
		}
	}

    $t1 ||= '������ �ȵƽ��ϴ�.';

    &get_code;

    &header(CSS=>'sub');
    print <<"    END_OF_HTML";
    <div class=label>����ǰ �����ϱ�</div>
    <form method=post action=$set::cgi_url>
    <div class=outbox>
    <tt>�������� ID�� �Է��� �ּ���.</tt><br>
    <br>
    $t1
    <br>
    <div class=r>$set::but{OK}</div>
    <input type=hidden name=md value="reserve_after">
    <input type=hidden name=id value="$F{id}">
    <input type=hidden name=ps value="$F{ps}">
    <input type=hidden name=fl value="$F{fl}">
    <input type=hidden name=xx value="$I->{XX}">
    </div>
    </form>
    END_OF_HTML
    &back_close($F{fl});
    &footer;
}

# Sub Reserve After #
sub reserve_after {
my  $i;
my  $Ii;

    $I = &get_user('I');

    &set_code;

    if ($F{fl} eq 'pet') {
        &get_pet($I);
        $I->{Bg} = $I->{Pt};
    }
    else {
        &get_item($I);
    }

    foreach $Ii (@{$I->{Bg}}) {
        $i++;
        next if !$Ii;
		if (exists $F{$i}) {
		    if (!$F{$i}) { $Ii->{rs} = '' }
            elsif ($F{$i} =~ /\W/) { &M("$Ii->{nm}: �߸��� ID�Դϴ�.") }
            else {
                $Ii->{rs} = $F{$i};
                &M("$Ii->{nm}: �����ڸ� �����߽��ϴ�.");
            }
		}
	}

    if ($F{fl} eq 'pet') {
        &set_pet($I);
    }
    else {
        &set_item($I);
    }
    &say($I->{M},$F{fl});
}
# --------------------------------------------------- #
1;
