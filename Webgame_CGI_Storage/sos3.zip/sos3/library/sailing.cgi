# --------------------------------------------------- #
# Script of Saga III Sailing.cgi Version 1
# Copyright (C) 2005 Missing Link.
# --------------------------------------------------- #

# Sub Get Ship #
sub get_ship {
my  $S = shift;
my  $V = shift; # ID
my  $T = shift; # selected or checked
my  ($L,@L,@P,$X);

    undef $S->{Si};

    return 0 unless -e "$set::sip_dir/$V.cgi";

    @P = &open_dat("$set::sip_dir/$V.cgi");
    $L = shift @P;
    @L = split(/<>/,$L);

    foreach (0 .. $#set::ndt) {
        $X = $set::ndt[$_];
        $S->{Si}{$X} = $L[$_];
    }

    $S->{Si}{pg} = @P;
    $S->{Si}{Pg} = \@P;
    $S->{Si}{Go}{$S->{Si}{go}} = ' ' . $T if $T eq 'selected';
    $S->{Si}{Go} = ' ' . $T if $S->{ab} eq $V && $T eq 'checked';
    return 1;
}

# Sub Set Ship #
sub set_ship {
my  $S = shift;
my  $V = shift;
my  (@L,$L,$X);

    if ($S->{Si}{tp} eq '') {
        unlink "$set::sip_dir/$V.cgi";
        return;
    }

    foreach (0 .. $#set::ndt) {
        $X = $set::ndt[$_];
        push(@L,$S->{Si}{$X});
    }
    push(@L,"\n");

    $L = join('<>',@L);

    @L = @{$S->{Si}{Pg}};

    unshift(@L,$L);

    &write_dat("$set::sip_dir/$V.cgi",@L);
}

# Sub Get Departure #
sub get_departure {
my  $V = shift;
my  @L;

    @L = &open_dat("$set::dat_dir/sailing_day.cgi");
    @L = map  { [split(/<>/)] } @L;
    @L = grep { $_->[0] ne $V } @L if $V;
    return \@L;
}

# Sub Set Departure #
sub set_departure {
my  $L = shift;
my  $V = shift;

    @$L = grep { $_->[0] ne $V } @$L if $V;
    @$L = grep { $_->[1] } @$L;
    @$L = sort { $a->[1] <=> $b->[1] } @$L;
    @$L = map  { join('<>',@$_,"\n") } @$L;
    &write_dat("$set::dat_dir/sailing_day.cgi",@$L);
}

# --------------------------------------------------- #
1;
