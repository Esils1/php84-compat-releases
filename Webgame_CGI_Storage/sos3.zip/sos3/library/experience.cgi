# --------------------------------------------------- #
# Script of Saga III Experience.cgi Version 2 (1.4)
# Copyright (C) 2005-2007 Missing Link.
# --------------------------------------------------- #

# Sub Experience #
sub experience {
my  $S = shift;
my  $V = shift;

    return if $V < 1;

    $S->{Nm} ||= $S->{nm};

    &M("<span class=exp>$S->{Nm}���� $V $set::lab{ex} ȹ��</span>");
    $S->{ex} += $V;
    &reload_data('ex') if $S->{id} eq $F{id};

    if ($S->{ex} >= $S->{lv} * $set::exl) {
        $S->{ex} -= $S->{lv} * $set::exl;
        $S->{lv}++ if $S->{lv} < $set::lvx;
        $S->{lb}+= $set::lub;
        &M("<span class=levelup>$S->{nm}�� $set::lab{lv} UP!</span>");
        &reload_data('lv') if $S->{id} eq $F{id};
        if ($S->{Sk}{Tb}) {
            $S->{Mlf} += $set::clf;
            &reload_gage('lf','V') if $S->{id} eq $F{id};
        }
    }
}

# Sub Pet Experience #
sub pet_experience {
my  $S = shift;
my  $V = shift;

    return if $V < 1;

    $S->{ex} += $V;

    if ($S->{ex} >= $S->{lv} * $set::pxl) {
        $S->{ex} -= $S->{lv} * $set::pxl;
        $S->{lv}++ if $S->{lv} < $set::lvx;
        $S->{of}+=  $set::pob;
        $S->{Mlf}+= $set::plb;
        $S->{lf} =  $S->{Mlf};
        &M("<span class=levelup>$S->{Nm}�� $set::lab{lv} UP!</span>");
    }
}

# --------------------------------------------------- #
1;
