# --------------------------------------------------- #
# Script of Saga III Main.cgi Version 3 (1.3)
# Copyright (C) 2005-2007 Missing Link.
# --------------------------------------------------- #

# Sub Main #
sub main {
my ($do,$body,$selected,$K,$V,$option_magic,$precode,
    $option_poem,$spotoption,$X,$Y,$environment);

    require "$set::lib_dir/placechange.cgi";

    &departure_monitor;

    &error('ID�� �Է����ּ���') if $F{id} eq '';
    &error('Password�� �Է����ּ���') if $F{ps} eq '';

    &lock($F{id});

    $I = &get_user('I','','in');

    $precode = (stat("$set::Ucd_dir/$I->{id}.cgi"))[9];

    &get_place($I);
    &get_kingdom($I);
    &set_cookie;

    @{$I->{Pp}} = &open_dat("$set::plc_dir/$I->{pl}.cgi");
    $I->{Pp} = @{$I->{Pp}};

    # �һ�
    if ($I->{da} eq 'Dd') {
        $K = time - $I->{dd} - $set::rvv * 3600;
        if ($K > 0) {
            &change_condition($I,'da');
        }
        else {
            $K  = abs($K);
            &M("Clock('revive','$K')",1);
        }
    }

    # HEA�� �Һ�
    &change_status($I,'hl',-$set::lgh);

    # VIT�� ȸ��
    $I->{Vt}  = int((time - $precode) / $set::rcv) / 10;
    $I->{vt} += $I->{Vt};
    $I->{vt}  = $I->{Mvt} if $I->{vt} > $I->{Mvt};
    $I->{Vt}  = int($I->{vt});
    $I->{li}  = 'in';
    &set_user($I);
    &unlock($F{id});

    # ���������� ǥ��
    foreach (@set::gfx) { $I->{"G$_"} = &fixed_gage($I->{$_}) }
    # ���������� ǥ��
    foreach (@set::gva) { ($I->{"G$_"},$I->{"X$_"}) = &variable_gage($I->{$_}) }
    # ȯ������� ǥ��
    foreach (split(/,/,$I->{Pl}{ev})) {
        $environment .= qq|<img src=$set::mim_dir/env$_.gif title="$I->{Pl}{ev}{$_}"> |;
    }
    # �̵� ���� �ɼ�
    &spot_option($I);
    $selected = ' selected';
    foreach (@{$I->{So}}) {
        ($K,$V) = split(/=/);
        $spotoption .=  qq|<option value="$K"$selected>$V �̵�</option>\n|;
        $selected = '';
    }

    # ����̸� �ҷ�����
    map { &get_equipment($I,$_);
          &get_effect($I->{ucfirst($_)}); } keys %set::eqp;

    # Ž��Ƚ�� �ɼ�
    for (1..$set::fdo) { $do .= qq|<option value="$_">$_ȸ</option>| }

    # ���ο� ����
    if ((stat("$set::Uml_dir/$I->{id}.cgi"))[9] > $I->{mb}) {
        &M("Message(self,'newmail','<img src=$set::mim_dir/mail.gif> ���ο� ������ �ֽ��ϴ�')",1);
    }

    # My Record
    if ((stat("$set::Urc_dir/$I->{id}.cgi"))[9] > $precode) {
        &M("Message(self,'newrecord','<img src=$set::mim_dir/mail.gif> My Record ������Ʈ��')",1);
    }

    &set_code('on');

    # ������ �÷��̾� ���� #
    if (&schedule_monitor(0)) {
        require "$set::lib_dir/delete.cgi";
        &delete_check;
    }

    $body = join(',',@{$I->{M}});
    $body = qq| onLoad="$body"| if $body;

    $I->{rw} = "<span class=alert>$I->{rw}</span>" if $I->{rw} >= $set::sps;

    ($X,$Y) = split(/,/,$I->{Pl}{lc});

    $V = $I->{Sk}{Po} ? '��':
         $I->{Sk}{Xd} ? 'Ž������': 0;

    $option_poem = qq|<option value="poem_before">$V ����</option>\n| if $V;
    $option_magic = qq|<option value="magic_before">���� ����</option>\n| if $I->{Sk}{Mg};

    &condition_initial($I,'cd') if !$I->{Cd}{in};
    &get_companion($I);
    $I->{Co}{Im} = &item_image($I->{Co});

    &header(CSS=>'main',JavaScript=>'OpenWindow,Clock,Reload',Body=>$body);
    print <<"    END_OF_HTML";
    <table class=basetable cellpadding=5 align=center>
    <tr>
    <td width=50%> 
    <div class=label>���</div>
    <table class=outertable border=1>
    <tr>
    <td class=padding><img id=I1 src=$set::mim_dir/$I->{Pl}{im}></td>
    <td class=padding width=100%>
    �ձ�: <span id=kg>$I->{Kg}{nm}</span><br>
    ������ġ: <span id=pl>$I->{Pl}{nm}</span><br>
    <span id=pl2>$I->{Pl}{nm}</span>�� �ִ� ���: <span id=pp>$I->{Pp}</span>�� <br>
    Ư¡: <span id=pr>$I->{Pl}{pr}</span>
    </td>
    </tr>
    <tr><td class=padding colspan=2>
    <span id=ev>$environment</span><img src=$set::mim_dir/envCh.gif title="��ȸ">
    <div class=r><input type=button class=button onClick="OpenWindow('$set::htm_dir/environment.html','myrecord',400,600)" value="ȯ�� ���"></div>
    </td></tr>
    </table>
    <br> 
    <div class=label>�ൿ</div>
    <table class=outertable>
    <tr>
    <form method=post action=$set::cgi_url target=myrecord>
    <td>
    <input type=submit class=button onClick="OpenWindow('$set::cgi_url','myrecord',600,600)" value="My Record">
    <input type=hidden name=md value="myrecord">
    <input type=hidden name=id value="$F{id}">
    <input type=hidden name=ps value="$F{ps}">
    </td>
    </form>
    <form name=mapform method=post action=$set::cgi_url target=map>
    <td>
    <input type=submit class=button onClick="OpenWindow('$set::cgi_url','map',500,400)" value="����">
    <input type=hidden name=md value="map">
    <input type=hidden name=x value="$X">
    <input type=hidden name=y value="$Y">
    <input type=hidden name=sx value="$I->{sx}">
    </td>
    </form>
    <form method=post action=$set::cgi_url target=bag>
    <td>
    <input type=submit class=button onClick="OpenWindow('$set::cgi_url','bag',350,500)" value="����">
    <input type=hidden name=md value="bag">
    <input type=hidden name=id value="$F{id}">
    <input type=hidden name=ps value="$F{ps}">
    </td>
    </form>
    <form method=post action=$set::cgi_url target=bag>
    <td>
    <input type=submit class=button onClick="OpenWindow('$set::cgi_url','bag',350,500)" value="����">
    <input type=hidden name=md value="compose">
    <input type=hidden name=id value="$F{id}">
    <input type=hidden name=ps value="$F{ps}">
    </td>
    </form>
    <form method=post action=$set::cgi_url target=pet>
    <td>
    <input type=submit class=button onClick="OpenWindow('$set::cgi_url','pet',350,600)" value="$set::lab{pt}">
    <input type=hidden name=md value="pet">
    <input type=hidden name=id value="$F{id}">
    <input type=hidden name=ps value="$F{ps}">
    </td>
    </form>
    <form method=post action=$set::cgi_url target=guild>
    <td>
    <input type=submit class=button onClick="OpenWindow('$set::cgi_url','guild',350,600)" value="$set::lab{gu}">
    <input type=hidden name=md value="guild">
    <input type=hidden name=id value="$F{id}">
    <input type=hidden name=ps value="$F{ps}">
    </td>
    </form>
    <form method=post action=$set::cgi_url target=quest>
    <td>
    <input type=submit class=button onClick="OpenWindow('$set::cgi_url','quest',350,600)" value="$set::lab{qs}">
    <input type=hidden name=md value="quest_before">
    <input type=hidden name=id value="$F{id}">
    <input type=hidden name=ps value="$F{ps}">
    </td>
    </form>
    <form method=post action=$set::cgi_url>
    <td width=100% class=r>
    <input type=submit class=button value="��������">
    <input type=hidden name=md value="logout">
    <input type=hidden name=id value="$F{id}">
    <input type=hidden name=ps value="$F{ps}">
    </td>
    </form>
    </tr>
    </table>

    <table class=outertable border=1>
    <tr><th>�׼�</th><th>�÷��̾� ���</th><th>�̵�</th><th>Ž��</th></tr>
    <tr>
    <form action=$set::cgi_url method=post target=action>
    <td nowrap>
    <select name=md size=8 class=select>
    <option value="contact_before" selected>�÷��̾� ����</option>
    <option value="transfer_before">�ٸ� �������� �̵�</option>
    <option value="words_before">�ڱ�Ұ� ����</option>
    <option value="friends_before">ģ�� ����</option>
    <option value="orb_before">$set::orb{x}�� ����</option>
    <option value="bounty_before">$set::lab{rw}�� �Ǵ�</option>
    <option value="option_before">�������� ������</option>
    $option_poem
    $option_magic
    <option value="color_before">���ڻ� ����</option>
    <option value="stance_before">�ڼ� ����</option>
    <option value="ornament_before">���⿡ ���� ����ϱ�</option>
    <option value="levelup_before">������ ���ʽ�</option>
    <option value="backup_before">����Ÿ ���</option>
    <option value="delete_before">ĳ���� ����</option>
    </select>
    <input type=submit class=button onClick="OpenWindow('$set::cgi_url','action',400,550)" value="$set::okb">
    <input type=hidden name=id value="$F{id}">
    <input type=hidden name=ps value="$F{ps}">
    </td>
    </form>
    <form name=playerlistform method=post action=$set::cgi_url target=playerlist>
    <td nowrap>
    <select name=or size=8 class=select>
    <option value="Ft" selected>������</option>
    <option value="Cz">�����</option>
    <option value="Bt">�����</option>
    <option value="Ps">�α����</option>
    <option value="Si">�Ǹ�����</option>
    </select>
    <input type=submit class=button onClick="OpenWindow('$set::cgi_url','playerlist',1024,768)" value="$set::okb">
    <input type=hidden name=md value="playerlist">
    <input type=hidden name=pl value="$I->{pl}">
    </td>
    </form>
    <form name=spotform method=post action=$set::cgi_url target=spot>
    <td nowrap>
    <select name=md size=8 class=select>$spotoption<option value=church_before> ��ȸ �̵�</option></select>
    <input type=submit class=button onClick="OpenWindow('$set::cgi_url','spot',400,500)" value="$set::okb">
    <input type=hidden name=id value="$F{id}">
    <input type=hidden name=ps value="$F{ps}">
    </td>
    </form>
    <form name=findform method=post action=$set::cgi_url target=find>
    <td nowrap width=100% class=r>
    <select name=do class=select>$do</select>
    <input type=submit class=button onClick="OpenWindow('$set::cgi_url','find',400,500)" value="$set::okb">
    <input type=hidden name=md value="find">
    <input type=hidden name=id value="$F{id}">
    <input type=hidden name=ps value="$F{ps}">
    </td>
    </form>
    </tr>
    </table>

    <table class=outertable>
    <tr>
    <form method=post action=$set::cgi_url target=mailbox>
    <td width=100% class=r>
    <input type=submit class=button onClick="OpenWindow('$set::cgi_url','mailbox',600,600)" value="������">
    <input type=hidden name=md value="mail_box">
    <input type=hidden name=id value="$F{id}">
    <input type=hidden name=ps value="$F{ps}">
    </td>
    </form>
    <form method=post action=$set::cgi_url target=mail>
    <td>
    <input type=submit class=button onClick="OpenWindow('$set::cgi_url','mail',400,500)" value="���� �ۼ�">
    <input type=hidden name=md value="mail_before">
    <input type=hidden name=id value="$F{id}">
    <input type=hidden name=ps value="$F{ps}">
    </td>
    </form>
    </tr>
    </table>

    </td>

    <td width=50%>
    <div class=label>����</div>
    <table class=outertable border=1>
    <tr>
    <th nowrap class=padding><img name=im src=$set::mim_dir/$I->{im} class=image><br><span id=nm>$I->{nm}</span></th>
    <td width=100% rowspan=2>

    <table width=100%>
    <tr>
    <td class=padding width=40%>
    $set::lab{sx}: <img src=$set::mim_dir/$I->{sx}.gif><br>
    $set::lab{kg}: <img src=$set::mim_dir/flag$I->{kg}.gif title=$I->{Kg}{nm}><br>
    $set::lab{jb}: <span id=jb>$I->{jb}</span><br>
    $set::lab{lv}: <span id=lv>$I->{lv}</span><br>
    $set::lab{ex}: <span id=ex>$I->{ex}</span><br>
    $set::lab{gl}: <span id=gl>$I->{gl}</span> $set::mny<br>
    $set::lab{rw}: <span id=rw>$I->{rw}</span> $set::mny<br>
    $set::lab{da}: <span id=da>$I->{Da}</span><br>
    $set::lab{ij}: <span id=ij>$I->{Ij}</span><br>
    $set::lab{cd}: <span id=cd>$I->{Cd}{in}</span><br>
    </td>
    <td class=padding>
    $set::eqp{rh}: <span id=rh>$I->{Rh}{Im}$I->{Rh}{nm}$I->{Rh}{Ef}</span><br>
    $set::eqp{lh}: <span id=lh>$I->{Lh}{Im}$I->{Lh}{nm}$I->{Lh}{Ef}</span><br>
    $set::eqp{sb}: <span id=sb>$I->{Sb}{Im}$I->{Sb}{nm}$I->{Sb}{Ef}</span><br>
    $set::eqp{hd}: <span id=hd>$I->{Hd}{Im}$I->{Hd}{nm}$I->{Hd}{Ef}</span><br>
    $set::eqp{bd}: <span id=bd>$I->{Bd}{Im}$I->{Bd}{nm}$I->{Bd}{Ef}</span><br>
    $set::eqp{lg}: <span id=lg>$I->{Lg}{Im}$I->{Lg}{nm}$I->{Lg}{Ef}</span><br>
    $set::eqp{nk}: <span id=nk>$I->{Nk}{Im}$I->{Nk}{nm}$I->{Nk}{Ef}</span><br>
    $set::eqp{fg}: <span id=fg>$I->{Fg}{Im}$I->{Fg}{nm}$I->{Fg}{Ef}</span><br>
    </td>
    </tr>
    </table>
    </td>
    </tr>
    <tr>
    <th><span id=pim>$I->{Co}{Im}</span><br><span id=pnm>$I->{Co}{nm}</span></th>
    </tr>
    </table>

    <table class=outertable border=1>
    <tr>
    <td width=100>
    <table>
    <tr>
    <td nowrap class=monospace>$set::lab{tc}</td>
    <td nowrap class=r><span id=tc>$I->{tc}</span></td>
    <td width=100%><span id=Gtc>$I->{Gtc}</span></td>
    </tr>
    <tr> 
    <td nowrap class=monospace>$set::lab{st}</td>
    <td nowrap class=r><span id=st>$I->{st}</span></td>
    <td width=100%><span id=Gst>$I->{Gst}</span></td>
    </tr>
    <tr> 
    <td nowrap class=monospace>$set::lab{dx}</td>
    <td nowrap class=r><span id=dx>$I->{dx}</span></td>
    <td width=100%><span id=Gdx>$I->{Gdx}</span></td>
    </tr>
    <tr> 
    <td nowrap class=monospace>$set::lab{in}</td>
    <td nowrap class=r><span id=in>$I->{in}</span></td>
    <td width=100%><span id=Gin>$I->{Gin}</span></td>
    </tr>
    <tr> 
    <td nowrap class=monospace>$set::lab{cn}</td>
    <td nowrap class=r><span id=cn>$I->{cn}</span></td>
    <td width=100%><span id=Gcn>$I->{Gcn}</span></td>
    </tr>
    </table>
    </td>
    <td>
    <table>
    <tr>
    <td nowrap class=monospace>$set::lab{lf}</td>
    <td nowrap class=r><span id=lf>$I->{lf}</span></td>
    <td width=100%><span id=Glf class=gage>$I->{Glf}$I->{Xlf}</span></td>
    </tr>
    <tr> 
    <td nowrap class=monospace>$set::lab{vt}</td>
    <td nowrap class=r><span id=vt>$I->{Vt}/$I->{Mvt}</span></td>
    <td width=100%><span id=Gvt class=gage>$I->{Gvt}$I->{Xvt}</span></td>
    </tr>
    <tr> 
    <td nowrap class=monospace>$set::lab{hl}</td>
    <td nowrap class=r><span id=hl>$I->{hl}</span></td>
    <td width=100%><span id=Ghl class=gage>$I->{Ghl}$I->{Xhl}</span></td>
    </tr>
    <tr> 
    <td nowrap class=monospace>$set::lab{ap}</td>
    <td nowrap class=r><span id=ap>$I->{ap}</span></td>
    <td width=100%><span id=Gap class=gage>$I->{Gap}$I->{Xap}</span></td>
    </tr>
    <tr> 
    <td nowrap class=monospace>$set::lab{hy}</td>
    <td nowrap class=r><span id=hy>$I->{hy}</span></td>
    <td width=100%><span id=Ghy class=gage>$I->{Ghy}$I->{Xhy}</span></td>
    </tr>
    </table>
    </td>
    </tr>
    </table>

    <table class=outertable>
    <tr> 
    <td width=33%>
    <a class=back href=$set::htm_dir/manual/ target=_blank>�޴���</a><br>
    <a class=back href=$set::htm_dir/kingdom.html target=_blank>�ձ� ���</a><br>
    </td>
    <td width=33%>
    </td>
    <td width=33%>
    </td>
    </tr>
    </table>
    </td>
    </tr>
    </table>
    <div class=inform><div id=newmail></div><div id=newrecord></div><div id=revive></div></div>
    END_OF_HTML
    &footer;
}

# Sub Fixed Gage #
sub fixed_gage {
my $width = shift;
my $color;

    return undef if !$width;
    $color = $width <  5 ? 1: # red
             $width < 10 ? 2: # brown
             $width < 15 ? 3: # black
                           4; # blue
    $width *= 3;
    return qq|<img src=$set::mim_dir/gage$color.gif width=$width height=8 class=gage>|;
}

# Sub Variable Gage #
sub variable_gage {
my  $width = shift;
my  $color;
my  $max;

    return undef if !$width;
    ($width,$max) = split(/\//,$width);
    $color = $width < 20 ? 1: # red
             $width < 50 ? 2: # brown
             $width < 80 ? 3: # black
                           4; # blue
    $width = int($width);
    $max  -= $width;
    $width = qq|<img src=$set::mim_dir/gage$color.gif width=$width height=8>|;
    $max   = qq|<img src=$set::mim_dir/gage0.gif width=$max height=8>| if $max;
    $max   = undef if !$max;
    return($width,$max);
}

# Sub Departure Monitor #
sub departure_monitor {
my  $V;
my (@L,$D,@D,$C,@C,$M);

    return unless (stat("$set::dat_dir/sailing_day.cgi"))[7];

    $V = time;

    @D = map { [split(/<>/,$_)] } &open_dat("$set::dat_dir/sailing_day.cgi");

    return if !@D;

    require "$set::lib_dir/myrecord.cgi";
    require "$set::lib_dir/sailing.cgi";

    foreach $D (@D) {
        last if $D->[1] > $V;
        $D->[1] = '';

        &lock($D->[0]);
        $I = &get_user('U',$D->[0]);
        &get_ship($I,$D->[0]);

        &delete_place($I);
        $I->{pl} = $I->{Si}{go};
        &get_place($I);
        &set_place($I);

        foreach (@{$I->{Si}{Pg}}) {
            chomp $_;
            &lock($_);
            $U = &get_user('U',$_) or next;
            $F = &login_check($U,1) ? 1 : 0;
            $F = 2 if $U->{gl} < $I->{Si}{sp};
            if (!$F) {
                &change_status($U,'gl',-$I->{Si}{sp});
                &change_status($I,'gl',$I->{Si}{sp});

                &delete_place($U);
                $U->{pl} = $I->{Si}{go};
                &set_place($U);
                push(@C,$U->{nm});
            }
            $U->{ab} = '';
            &set_user($U);
            &unlock($_);
            if ($F == 2) {
                &set_record("����� �� ���� ���� �踦 Ÿ�� ���߽��ϴ�.");
            }
            elsif ($F == 1) {
                &set_record("�������̾ �踦 Ÿ�� ���߽��ϴ�.");
            }
            else {
                &set_record("$I->{Pl}{nm}(��)�� �̵��߽��ϴ�.<br>������� $I->{Si}{sp} $set::mny�� $I->{nm}���� �½��ϴ�.");
            }
        }

        $I->{Si}{go} = '';
        $I->{Si}{dt} = '';
        $I->{Si}{se} = '';
        $I->{Si}{nw} = '';
        $I->{Si}{db}--;
        undef $I->{Si}{Pg};
        &set_ship($I,$I->{id});

        $I->{li} ='out';
        &set_user($I);

        $U = $I;
        $C = @C;
        $M = '<br>' . join('��',@C) . "�� $C���� �°��� �Ǿ� " . $I->{Si}{sp} * $C . " $set::mny�� ������ ������ϴ�." if $C;
        &set_record("$I->{Pl}{nm}(��)�� �̵��߽��ϴ�.$M");

        &unlock($D->[0]);
        $F = 1;
    }
    &set_departure(\@D) if $F;
}

# --------------------------------------------------- #
1;
