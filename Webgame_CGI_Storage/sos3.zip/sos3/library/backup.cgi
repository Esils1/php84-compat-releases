# --------------------------------------------------- #
# Script of Saga III Backup.cgi Version 1
# Copyright (C) 2005 Missing Link.
# --------------------------------------------------- #

# Sub Backup Before #
sub backup_before {
    $I = &get_user('I');

    &get_code;

    &header(CSS=>'sub');
    print <<"    END_OF_HTML";
    <form method=post action=$set::cgi_url>
    <div class=label>���</div>
    <div class=outbox>
    ����Ÿ�� ����մϴ�.<br>
    <br>
    <div class=r>$set::but{OK} $set::but{CLOSE}</div>
    <input type=hidden name=md value="backup_after">
    <input type=hidden name=id value="$F{id}">
    <input type=hidden name=ps value="$F{ps}">
    <input type=hidden name=xx value="$I->{XX}">
    </div>
    </form>
    END_OF_HTML
    &footer;
}

# Sub Backup After #
sub backup_after {
my  @I;

    $I = &get_user('I');

    &set_code;

    $I[0] = (&open_dat("$set::Udt_dir/$F{id}.cgi"))[0] . "\n";

    push(@I,"<Item>\n");
    push(@I,&open_dat("$set::Uit_dir/$F{id}.cgi"));
    push(@I,"<Pet>\n");
    push(@I,&open_dat("$set::Upt_dir/$F{id}.cgi"));

    &write_dat("$set::Ubu_dir/$F{id}.cgi",@I);

    &say('��� �Ϸ�','CLOSE');
}

# --------------------------------------------------- #
1;
