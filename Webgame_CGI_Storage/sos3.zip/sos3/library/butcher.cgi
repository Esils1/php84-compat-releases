# --------------------------------------------------- #
# Script of Saga III Butcher.cgi Version 2 (1.4)
# Copyright (C) 2005-2007 Missing Link.
# --------------------------------------------------- #

# Sub Butcher Before #
sub butcher_before {
my  $i;
my  $Ii;
my  $Ui;
my  $t1;
my  $age;

    $I = &get_user('I');

    &dead_check($I,'pet');

    &get_bonus($I,'Bc');
    &get_pet($I);

    require "$set::itm_dir/corpse.cgi";

    foreach $Ip (@{$I->{Pt}}) {
        $i++;
        next if !$Ip;
		next if !$F{$i};
        $Ip->{Im} = &item_image($Ip);
        &say("$Ip->{Im}$Ip->{Nm}(��)�� �׾����ϴ�. $Ip->{Nm}���Լ� �ƹ� �͵� ���� �� �������ϴ�.",'pet') if !$Ip->{hg};
        &say("$Ip->{Im}$Ip->{Nm}���Լ� �ƹ� �͵� ���� �� �������ϴ�.",'pet') if !$Ip->{sg} || !exists $FI{$Ip->{nm}};
        &say("$Ip->{Im}$Ip->{Nm}(��)�� Ÿ�� �ֽ��ϴ�.",'pet') if $Ip->{eq} eq 'rd';
        &say("$Ip->{Im}$Ip->{Nm}(��)�� ���迡 �������Դϴ�.",'pet') if $Ip->{eq} eq 'co';
        $age = &get_passage($Ip->{bt},$set::pyt);
        $t1 .= "$Ip->{Im}$Ip->{Nm}���Լ� ������ ���� �͵��� ������ϴ�.<br>\n";
        $t1 .= "<br>\n";
        foreach $Ui (@{$FI{$Ip->{nm}}}) {
            $Ui->{Qn} = int($age * $set::pcp * $Ui->{qn} * $Ip->{ft} / (80 - $I->{st}) * $I->{bonus});
            $Ui->{Qn} ||= 1;
            $t1 .= &decorate_item($Ui);
        }
        $t1 .= "<hr>\n";
        $t1 .= qq|<input type=hidden name=$i value="on">\n|;
    }

    &get_code;

    &header(CSS=>'sub');
    print <<"    END_OF_HTML";
    <div class=label>�����ϱ�</div>
    <form method=post action=$set::cgi_url>
    <div class=outbox>
    $t1
    <div class=r>
    <tt>������ ����: $I->{bg}/$I->{Mbg} $set::wgt</tt><br>
    <br>
    <tt>���� �����մϱ�?</tt><br>
    $set::but{OK}
    </div>
    <input type=hidden name=id value="$F{id}">
    <input type=hidden name=ps value="$F{ps}">
    <input type=hidden name=md value="butcher_after">
    <input type=hidden name=xx value="$I->{XX}">
    </div>
    </form>
    END_OF_HTML
    &back_close('pet');
    &footer;
}

# Sub Butcher After #
sub butcher_after {
my  $i;
my  $j;
my  $Ii;
my  $Ui;
my  $age;

    $I = &get_user('I');

	&say('���̻� ���� �� �����ϴ�','pet') if $I->{bg} >= $I->{Mbg};

    &get_equipment($I,'rh');
    &get_equipment($I,'sb');

    &say("����� ��� �����ؾ� �մϴ�",'CLOSE') if !$I->{Rh}{ql}{Cp} && !$I->{Sb}{ql}{Cp};

    &set_code;

    &get_bonus($I,'Bc');
    &get_pet($I);
    &get_item($I);

    require "$set::itm_dir/corpse.cgi";
    require "$set::lib_dir/experience.cgi";

    foreach $Ip (@{$I->{Pt}}) {
        $i++;
        next if !$Ip;
		next if !$F{$i};
        next if !$Ip->{hg};
        next if !$Ip->{sg};
        next if !exists $FI{$Ip->{nm}};
        $age = &get_passage($Ip->{bt},$set::pyt);
        foreach $Ui (@{$FI{$Ip->{nm}}}) {
            $Ui->{Qn} = int($age * $set::pcp * $Ui->{qn} * $Ip->{ft} / (80 - $I->{st}) * $I->{bonus});
            &error('Butcher Error') if $Ui->{Qn} > 100;
            $Ui->{Qn} ||= 1;

            for $j (1 .. $Ui->{Qn}) {
                last if $j * $Ui->{wt} + $I->{bg} > $I->{Mbg};
                $Ui->{qn} = $j;
            }

            next if !$Ui->{qn};

            &say("������ ���� á���ϴ�",'CLOSE') if @{$I->{Bg}} >= $I->{bs};

            push (@{$I->{Bg}},$Ui);
            $I->{bg} += $Ui->{qn} * $Ui->{wt};

            $Ui->{Im} = &item_image($Ui);

            &M("$Ui->{Im}$Ui->{nm}(��)�� $Ui->{qn}�� �����߽��ϴ�.");
            &experience($I,$Ui->{Qn} * 20) if $I->{Sk}{Bc};
        }
        $I->{px} -= $Ip->{sl};
        &change_status($I,'hy',-2,1) if !$I->{Sk}{Bc};
        $Ip->{id} = '';
    }

    require "$set::lib_dir/break.cgi";

    if ($I->{Rh}{ql}{Cp}) {
        &reload_data('rh') if &break_check('rh');
    }
    else {
        &reload_data('sb') if &break_check('sb');
    }

    &reload_data('ex') if $I->{Sk}{Bc};
    &reload_gage('hy','V') if !$I->{Sk}{Bc};

    &inner_HTML;

    &sort_item($I);

    &set_item($I);
    &set_pet($I);
    &set_user($I);

    &say($I->{M},'pet','Reload');
}

# --------------------------------------------------- #
1;
