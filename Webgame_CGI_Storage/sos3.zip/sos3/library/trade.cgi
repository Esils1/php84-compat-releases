# --------------------------------------------------- #
# Script of Saga III Trade.cgi Version 1
# Copyright (C) 2005 Missing Link.
# --------------------------------------------------- #

# Sub Trade Before #
sub trade_before {
my ($t1,$t2);
my  $checked;
my  %unique;

    $I = &get_user('I');

    &dead_check($I,'CLOSE');

    $U = &get_user('U');
    &login_check($U);
    &place_check($U);

	require "$set::lib_dir/partner.cgi";

    &partner('',"$set::orb{x}�� ������ ���� �ʽ��ϴ�.") if !$I->{ob};
	&partner('',"$U->{nm}�Կ��� �ŷ��� �� �ִ� $set::orb{x}�� �����ϴ�.") if $U->{ob} !~ /[a-z]/;

    @{$I->{Ob}} = grep { !$unique{$_}++ }
                  map  { $_ = lc $_ } split(//,$I->{ob});
    $checked = ' checked';
    foreach (@{$I->{Ob}}) {
        $t1 .= qq|<input type=radio name=Iob class=radio value="$_"$checked> |;
        $t1 .= &orb_image($_);
        $t1 .= "$set::orb{$_}$set::orb{x}<br>\n";
        $checked = '';
    }

    @{$U->{Ob}} = grep { /[a-z]/ } split(//,$U->{ob});
    $checked = ' checked';
    foreach (@{$U->{Ob}}) {
        $t2 .= qq|<input type=radio name=Uob class=radio value="$_"$checked> |;
        $t2 .= &orb_image($_);
        $t2 .= "$set::orb{$_}$set::orb{x}<br>\n";
        $checked = '';
    }

    &get_code;

    &header(CSS=>'sub',JavaScript=>"OpenWindow");
    print "<div class=label>$set::orb{x} �ŷ��ϱ�</div>\n";

    &get_words($U);
    &partner_talk($U->{w9});

    print <<"    END_OF_HTML";
    <form method=post action=$set::cgi_url>
    <div class=outbox>
    <tt>�ŷ��� $set::orb{x}�� �������ּ���.</tt><br>
    <br>
    $I->{nm}���� $set::orb{x}<br>
    $t1
    <br>
    $U->{nm}���� $set::orb{x}<br>
    $t2
    <div class=r>$set::but{OK}</div>
    <input type=hidden name=md value="trade_after">
    <input type=hidden name=id value="$F{id}">
    <input type=hidden name=ud value="$F{ud}">
    <input type=hidden name=ps value="$F{ps}">
    <input type=hidden name=xx value="$I->{XX}">
    </div>
    </form>
    END_OF_HTML
	&partner_select;
    &footer;
}

# Sub Trade After #
sub trade_after {
    $I = &get_user('I');
    &lock($F{id});
    $U = &get_user('U');
    &login_check($U);
    &place_check($U);

    unless ($I->{ob} =~ s/$F{Iob}// || $I->{ob} =~ s/$F{Iob}//i) { &say('�ŷ��� ������','trade_before') }
    else { @{$I->{Ob}} = split(//,$I->{ob}.uc($F{Uob})) }
    &set_orb($I);

    unless ($U->{ob} =~ s/$F{Uob}//) { &say('�ŷ��� ������','trade_before') }
    else { @{$U->{Ob}} = split(//,$U->{ob}.uc($F{Iob})) }
    &set_orb($U);

    &set_code;

    &set_user($I);
    &set_user($U);
    &unlock($U->{id});

	require "$set::lib_dir/myrecord.cgi";
	require "$set::lib_dir/partner.cgi";

    lc $F{Iob};
    lc $F{Uob};

    &set_record("$I->{nm}���� $set::orb{$F{Iob}}$set::orb{x}�� $U->{nm}���� $set::orb{$F{Uob}}$set::orb{x}�� �ŷ��߽��ϴ�.");
    &partner('',"$set::orb{x}�� �ŷ��߽��ϴ�");
}

# --------------------------------------------------- #
1;