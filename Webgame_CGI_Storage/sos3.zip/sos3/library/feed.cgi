# --------------------------------------------------- #
# Script of Saga III Feed.cgi Version 2 (1.4)
# Copyright (C) 2005-2007 Missing Link.
# --------------------------------------------------- #

# Sub Feed Before #
sub feed_before {
my  $i;
my ($Ii,$Ip);
my ($t1,$t2);

    $I = &get_user('I');
    &get_pet($I);

    $Ip = $I->{Pt}->[$F{pt}];
    @{$Ip->{Fd}} = split(/,/,$Ip->{fd});

    &say("$Ip->{Nm}(��)�� �׾����ϴ�",'pet') if !$Ip->{hg};

    &get_item($I);

    foreach $Ii (@{$I->{Bg}}) {
        $i++;
        next if !$Ii;
        next if !&favorite_check($Ip,$Ii);
        $t1 .= "<input type=checkbox name=$i class=checkbox> ";
        $t1 .= &decorate_item($Ii);
    }

    $t2 = &item_image($Ip)."$Ip->{Nm}<br>\n<br>\n";

    &say("$Ip->{Nm}(��)�� ���� �� �ִ� ���̰� �����ϴ�.",'pet') if !$t1;

    &get_code;

    &header(CSS=>'sub');
    print <<"    END_OF_HTML";
    <div class=label>�����ֱ�</div>
    <form method=post action=$set::cgi_url>
    <div class=outbox>
    $t2
    $t1
    <div class=r>$set::but{OK}</div>
    <input type=hidden name=id value="$F{id}">
    <input type=hidden name=ps value="$F{ps}">
    <input type=hidden name=md value="feed_after">
    <input type=hidden name=pt value="$F{pt}">
    <input type=hidden name=xx value="$I->{XX}">
    </div>
    </form>
    END_OF_HTML
    &back_close('pet');
    &footer;
}

# Sub Feed After #
sub feed_after {
my  $i;
my ($K,$V);
my ($Ii,$Ui);
my  $energy;
my  $intbonus;

    $I = &get_user('I');
    &set_code;

    &get_pet($I);

    $Ip = $I->{Pt}->[$F{pt}];
    @{$Ip->{Fd}} = split(/,/,$Ip->{fd});

    $V = $Ip->{cl} eq 'Ls' || $Ip->{cl} eq 'Hr' ? 'Br':
                              $Ip->{cl} eq 'Wa' ? 'At':
                              $Ip->{cl} eq 'Dr' ? 'Dt':
                                                  'Bt';
    $I->{bonus} = $I->{Sk}{$V} ? 3 : 1;

    $intbonus = (1 + $I->{in} / 10) * $I->{bonus};

    &get_item($I);

    foreach $Ii (@{$I->{Bg}}) {
        $i++;
        next if !$Ii;
		next if !$F{$i};
        &say('Item Select Error','CLOSE') if !&favorite_check($Ip,$Ii);

        foreach (split(/,/,$Ii->{ef})) {
            ($K,$V) = split(/=/);
            $Ii->{Ef} += $V;
        }
        if (!$Ii->{Ql}{Ad}) {
            &M("$Ip->{Nm}���� $Ii->{nm}(��)�� �����߽��ϴ�.") && next if $energy + $Ip->{hg} >= $Ip->{hx};
            $energy += int($Ii->{Ef} * $Ii->{qn});
        }
        &M("$Ip->{Nm}���� $Ii->{nm}(��)�� ����ϴ�.");
        &change_status($Ip,'lf',$Ii->{Ef},1,$Ip->{lx}) if $Ip->{lf} < $Ip->{lx};
        $Ii->{qn} = 0;
	}

    $confidence = int(($Ip->{ch} + 1) * ($energy / ($Ip->{hx} / 10)) * $intbonus);
    &change_status($Ip,'ft',$confidence,0,100);
    &change_status($Ip,'hg',$energy,0,$Ip->{hx});

    &set_item($I);
    &set_pet($I);
    &say($I->{M},'pet');
}

# Sub Favorite Check #
sub favorite_check {
my  $Sp = shift;
my  $Si = shift;

    foreach (@{$Sp->{Fd}}) {
        return 1 if $Si->{Ql}{$_};
    }
    return 0;
}

# --------------------------------------------------- #
1;
