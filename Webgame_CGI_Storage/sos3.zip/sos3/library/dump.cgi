# --------------------------------------------------- #
# Script of Saga III Dump.cgi Version 2 (1.4)
# Copyright (C) 2005-2007 Missing Link.
# --------------------------------------------------- #

# Sub Dump #
sub dump {
my  $i;
my  $Ii;

    $I = &get_user('I');
    &get_item($I);

    $I->{bg} = 0; # recalculate
    foreach $Ii (@{$I->{Bg}}) {
        $i++;
        $I->{bg} += $Ii->{wt} * $Ii->{qn};
        next if !$F{$i};
        if ($Ii->{Ql}{Nt}) { &M("$Ii->{nm}(��)�� ���� �� �����ϴ�.") }
        elsif ($Ii->{eq}) { &M("$Ii->{nm}(��)�� �������Դϴ�.") }
        else {
            $I->{bg} -= $Ii->{wt} * $Ii->{qn};
            &M("$Ii->{nm}(��)�� ���Ƚ��ϴ�.");
            $Ii->{qn} = 0;
        }
    }
    &change_status($I,'bg',0);

    &set_code;

    &set_user($I);
    &set_item($I);

    &say($I->{M},$F{fl});
}

# --------------------------------------------------- #
1;
