# --------------------------------------------------- #
# Script of Saga III River.cgi Version 1
# Copyright (C) 2005 Missing Link.
# --------------------------------------------------- #

# Sub River #
sub river {
my  $i;
my  $Ii;
my  $do;
my ($t1,$t2,$t3);
my ($checked,$checked2,$checked3);

    $I = &get_user('I');

    &dead_check($I,'CLOSE');

    &get_place($I);

    &spot_check($I,'Rv');

    &get_item($I);

    $checked = $checked2 = $checked3 = ' checked';

    # ���� �ð� �ɼ�
    for (1..$set::ydo) { $do .= qq|<option value="$_">$_�ð�</option>| }

    foreach $Ii (@{$I->{Bg}}) {
        $i++;
        next if !$Ii;
        if ($Ii->{cl} eq 'Fr') {
            $t1 .= qq|<input type=radio name=ft class=radio value="$i"$checked> |;
            $t1 .= &item_image($Ii);
            $t1 .= $Ii->{nm};
            $t1 .= "<br>\n";
            $checked = '';
        }
        elsif ($Ii->{cl} eq 'Ws') {
            $t2 .= qq|<input type=radio name=st class=radio value="$i"$checked2> |;
            $t2 .= &item_image($Ii);
            $t2 .= $Ii->{nm};
            $t2 .= "<br>\n";
            $checked2 = '';
        }
        elsif ($Ii->{cl} eq 'Ev' || $Ii->{cl} eq 'Fv') {
            $t3 .= qq|<input type=radio name=wt class=radio value="$i"$checked3> |;
            $t3 .= &item_image($Ii);
            $t3 .= $Ii->{nm};
            $t3 .= "<br>\n";
            $checked3 = '';
        }
    }

    &get_code;

    &header(CSS=>'sub');
    print <<"    END_OF_HTML";
    <div class=label>$I->{Sp}{Rv}{nm}</div>
    <form method=post action=$set::cgi_url>
    <div class=outbox>
    <img src=$set::mim_dir/envRv.gif><br>
    <br>
    <input type=radio name=md class=radio value="fishing" checked>�����⸦ ���´�<br>
    <div class=words>$t1</div>
    <div class=r><tt>1�ð��� $set::lab{vt}�� $set::yvt �Һ��.</tt></div>
    <br>
    <div class=r>�ð�: <select name=do class=select>$do</select></div>
    <input type=radio name=md class=radio value="swimming">�����ϱ�<br>
    <div class=words>$t2</div>
    <div class=r><tt>$set::lab{vt}�� $set::svt �Һ��.</tt></div>
    <br>
    <input type=radio name=md class=radio value="water">��⿡ ���� ��´�<br>
    <div class=words>$t3</div>
    <br>
    <br>
    <div class=r>$set::but{OK} $set::but{CLOSE}</div>
    <input type=hidden name=id value="$F{id}">
    <input type=hidden name=ps value="$F{ps}">
    <input type=hidden name=fl value="rv">
    <input type=hidden name=xx value="$I->{XX}">
    </div>
    </form>
    END_OF_HTML
    &footer;
}

# --------------------------------------------------- #
1;
