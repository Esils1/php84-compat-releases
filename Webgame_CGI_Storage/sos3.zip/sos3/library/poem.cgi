# --------------------------------------------------- #
# Script of Saga III Poem.cgi Version 1
# Copyright (C) 2005 Missing Link.
# --------------------------------------------------- #

# Sub Poem Before #
sub poem_before {
my  $V;

    $I = &get_user('I');

    $V = $I->{Sk}{Po} ? '��':
         $I->{Sk}{Xd} ? 'Ž������':
                        '���';

    &get_code;

    &header(CSS=>'sub');
    print <<"    END_OF_HTML";
    <div class=label>$V �ۼ��ϱ�</div>
    <form method=post action=$set::cgi_url>
    <div class=outbox>
    <tt>������ �� $V(��)�� ���������� �����˴ϴ�.</tt><br>
    <textarea class=textarea name=po cols=50 rows=20></textarea><br>
    <br>
    <div class=r>$set::but{OK} $set::but{CLOSE}</div>
    <input type=hidden name=md value="poem_after">
    <input type=hidden name=id value="$F{id}">
    <input type=hidden name=ps value="$F{ps}">
    <input type=hidden name=tp value="$V">
    </div>
    </form>
    END_OF_HTML
    &footer;
}

# Sub Poem After #
sub poem_after {
my  $t1;

    $I = &get_user('I');

    &set_code;

    &lock('_poem');

    @L = grep { index($_,"$I->{nm}<>") } &open_dat("$set::dat_dir/poem.cgi");

    unshift(@L,join('<>',$I->{nm},$I->{im},$F{tp},$F{po},$I->{fc},"\n"));
    pop(@L) if @L > $set::pox;

    &write_dat("$set::dat_dir/poem.cgi",@L);

    &unlock('_poem');

    $t1 = &header(CSS=>'sub',GetTag=>1,Body=>" class=poem");

    foreach (@L) {
        $t1 .= &print_poet(split(/<>/));
    }

    $t1 .= &footer(GetTag=>1);

    &write_dat($set::poe_htm,$t1);

    &say('�ۼ��Ϸ�','CLOSE');
}

# Sub Print Poet #
sub print_poet {
my  @V = @_;

    $V[3] .= "<div align=right><tt>$V[0]��$V[2]����</tt></div>\n"; #����
    $V[3] = &talk_bubble($V[3],$V[4]);

    return <<"    END_OF_HTML";
    <table class=outbox>
    <tr>
    <th rowspan=2><img src=$set::mim_dir/$V[1] class=image></th>
    <td width=100%>$V[3]</td>
    </tr>
    </table>
    END_OF_HTML
}

# --------------------------------------------------- #
1;
