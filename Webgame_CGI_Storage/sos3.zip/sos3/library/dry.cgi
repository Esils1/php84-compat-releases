# --------------------------------------------------- #
# Script of Saga III Dry.cgi Version 1
# Copyright (C) 2005 Missing Link.
# --------------------------------------------------- #

# Sub dry #
sub dry {
my  $i;
my  $Ii;

    $I = &get_user('I');

    &dead_check($I,'bag');

    &set_code;

    &get_bonus($I,'Bm',2);

    &get_item($I);

    require "$set::itm_dir/driedfood.cgi";

    foreach $Ii (@{$I->{Bg}}) {
        $i++;
        next if !$Ii;
        next if !$F{$i};
        if ($Ii->{cl} ne 'Fd') {
            &M("$Ii->{nm}(��)�� ������ �ƴմϴ�.");
        }
        elsif (!exists $FI{$Ii->{nm}}) {
            &M("$Ii->{nm}(��)�� �Ǿ�� ���� �� �����ϴ�.");
        }
        elsif (&roll_dice($I->{bonus}) == 1) {
            $Ii = &dried_food($Ii);
        }
        else {
            &M("$Ii->{nm}(��)�� �����Ƚ��ϴ�.");
            &change_status($I,'bg',-($Ii->{wt} * $Ii->{qn}));
            $Ii->{qn} = 0;
        }
    }

    &set_user($I);
    &set_item($I);

    &say($I->{M},'bag');
}

sub dried_food {
my  $Si = shift;
my  $V;
my  $X;

    $V = $Si->{qn};
    $X = $Si->{wt};
    $Si = $FI{$Si->{nm}};
    $Si->{qn} = $V;
    $Si->{wt} = $X;
    $Si->{Im} = &item_image($Si);

    &M("$Si->{Im}$Si->{nm}(��)�� ������ϴ�.");
    $Si;
}

# --------------------------------------------------- #
1;
