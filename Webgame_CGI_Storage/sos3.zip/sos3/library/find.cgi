# --------------------------------------------------- #
# Script of Saga III Find.cgi Version 4 (1.4)
# Copyright (C) 2005-2007 Missing Link.
# --------------------------------------------------- #

# Sub Find #
sub find {
    $I = &get_user('I');

    &dead_check($I,'CLOSE');

	&say('���̻� ���� �� �����ϴ�','CLOSE') if $I->{bg} >= $I->{Mbg};

    &get_place($I);

    &say("$I->{Pl}{nm}���� Ž���� �� �����ϴ�",'CLOSE') unless -e "$set::itm_dir/$I->{Pl}{it}";

	# Ž���� Ư���ɷ�
	$I->{bonus} = $set::sSi if $I->{Sk}{Si};

    &encounter if $I->{Pl}{ev}{Ms};

    &get_item($I);

    &found($I,'it',$set::fvt,'Ž��','�� �����߽��ϴ�',1);

    &sort_item($I);
    &set_item($I);

    &set_user($I);

    &reload_data('gl');
    &reload_gage(['vt'],'V');

    &inner_HTML;

    &say($I->{M},'CLOSE','Reload');
}

# Sub Encounter #
sub encounter {
    $U = {};

    &get_item($I);

    require "$set::lib_dir/fight.cgi";

    &found($I,'it',$set::fvt,'Ž��','�� �����߽��ϴ�',0,'monster');

    &sort_item($I);
    &set_item($I);

    &set_user($I);

    &inner_HTML;

    &say($I->{M},'CLOSE','Reload');
    exit;
}

# Sub Found #
sub found {
my  $S = shift;
my  $V0 = shift; # File
my  $V1 = shift; # VIT you loose 
my  $V2 = shift; # Label
my  $V3 = shift; # Words
my  $V4 = shift; # Money
my  $V5 = shift; # Encounter
my  ($i,$V,@V,$D,@FI);

    require "$set::itm_dir/$S->{Pl}{$V0}";
    require "$set::itm_dir/otheritem.cgi" if $S->{Sk}{Gt};

    @FI = sort { $a <=> $b } keys %FI;

    for $i (1..$F{do}) {
        last if $S->{vt} < $V1;

        &change_status($I,'vt',-$V1);

        &M() if $i > 1;
        &M("<tt>$V2$i��°</tt>");

        if ($V4) {
            $V = &roll_dice($S->{Pl}{gl});
            $S->{gl} += $V;
            &M("$V $set::mny(��)�� �����߽��ϴ�.");
        }

        $D  = &roll_dice(1000-$F{do}) - $S->{bonus};

        undef $Ii;
        if ($S->{Sk}{Gt} && $D <= $set::sGt) {
            $Ii = {%{$OI{Tm}}};
            $V = @V = keys %PL;
            $V = &roll_dice($V) - 1;
            $Ii->{ef} = $V[$V];
            $Ii->{nm} = $PL{$V[$V]}{nm} . '��' . $Ii->{nm};
        }
        else {
            foreach (@FI) {
                if ($D <= $_) {
                    $Ii = $FI{$_};
                    last;
                }
            }
        }

        &M("�ƹ��͵� ã�����߽��ϴ�.") && next if !$Ii;

        if ($V5 && !$Ii->{qn}) {
            $U = {%$Ii};
            $V = $V5 eq 'hunting' ? $set::hfx : $set::ffx;
            &fight_creature($V) || last;
            next if &roll_dice(1000) > $U->{gi} + $S->{bonus};
            $Ii = &select_acquisition($U) if !$U->{lf};
        }

        if ($Ii->{cl} eq 'Ob') {
            $Ii->{Im} = &orb_image($Ii->{ef});
            &M("$Ii->{Im}$Ii->{nm}(��)�� �߰��߽��ϴ�.");
            $S->{ob} .= $Ii->{ef};
            $S->{Ob} = [split(//,$S->{ob})];
        }
        elsif ($Ii->{qn}) {
            $Ii->{Im} = &item_image($Ii);
            $Ii->{Qn} = $Ii->{qn};
            for $j (1 .. $Ii->{Qn}) {
                last if $j * $Ii->{wt} + $S->{bg} > $S->{Mbg};
                $Ii->{qn} = $j;
            }
            &M("$Ii->{Im}$Ii->{nm}(��)�� ����������, ���̻� ���� �� ��� ���Ƚ��ϴ�.") && last if !$Ii->{qn};
            &M("$Ii->{Im}$Ii->{nm}(��)�� ����������, ������ ���� ���� ���Ƚ��ϴ�.") && last if @{$S->{Bg}} >= $S->{bs};

            push (@{$S->{Bg}},$Ii);
            $S->{bg} += $Ii->{wt} * $Ii->{qn};
            &M("$Ii->{Im}$Ii->{nm}(��)�� $Ii->{qn}$V3.");
            &M("���̻� ���� �� �����ϴ�.") && last if $S->{bg} == $S->{Mbg};
        }
    }

    &set_orb($S) if $S->{Ob};
}

# Sub Select Acquisition #
sub select_acquisition {
my  $D = shift;
my  $i = 1;
my (@L,$V);

    while ($D->{"i$i"}) {
        push(@L,$D->{"i$i"});
        $i++;
    }

    $V = &roll_dice($#L + 1) - 1;

    return $L[$V];
}

# --------------------------------------------------- #
1;