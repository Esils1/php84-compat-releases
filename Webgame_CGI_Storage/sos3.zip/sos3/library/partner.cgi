# --------------------------------------------------- #
# Script of Saga III Partner.cgi Version 1
# Copyright (C) 2005 Missing Link.
# --------------------------------------------------- #

# Partner #
sub partner {
my  $V = shift; # Words
my  $M = shift; # Message
my  $J = shift; # Javascript

    &unlock($I->{lock});

    if (ref($M)) { $M = join('',@$M) }
    $U->{Nm}  = $I->{Sk}{Se} && $U->{lf} < $U->{Mlf} * $set::sSe ? "$U->{nm} (�λ�)" : $U->{nm};

    &header(CSS=>'sub',JavaScript=>"OpenWindow,$J");
    print $I->{inner_HTML};
    print "<div class=label>$U->{Nm} ������</div>\n";
    print "<div class=outbox>$M</div>\n" if $M;
    &partner_talk($V);
	&partner_select;
    &footer;
    exit;
}

# Partner Talk #
sub partner_talk {
my  $V = shift; # Words
my  $T;

    $V = &talk_bubble($V,$U->{fc});
    $T = $U->{da} eq 'Dd' ? 'dead' : $U->{da} eq 'St' ? 'stone' : 'image';

    print <<"    END_OF_HTML";
    <table class=outertable>
    <tr>
    <th rowspan=2><img src=$set::mim_dir/$U->{im} class=$T><br>$U->{nm}</th>
    <td width=100%>$V</td>
    </tr>
    <tr>
    <form name=partner method=post action=$set::cgi_url target=partner>
    <td class=r style="vertical-align:bottom">
    <input type=submit class=button onClick="OpenWindow('$set::cgi_url','partner',300,500)" value="$U->{nm}�� ����">
    <input type=hidden name=md value="partner_status">
    <input type=hidden name=ud value="$F{ud}">
    </td>
    </form>
    </tr>
    </table>
    END_OF_HTML
}

# Partner Select #
sub partner_select {
my ($t1,$t2,$t3);

    $t1 = qq|<option value="cure_before">ġ��ޱ�</option>\n| if $U->{Sk}{Cu};
    $t2 = qq|<option value="partner_examine">�����ϱ�</option>\n| if $U->{da} eq 'Dd' && $I->{Sk}{Fe};
    $t3 = qq|<option value="destone">$set::cnd{St}[1] Ǯ��</option>\n| if $U->{da} eq 'St' && $I->{Sk}{Cu};

    print <<"    END_OF_HTML";
    <form method=post action=$set::cgi_url>
    <div class=outbox>
    <div class=r>
	<select name=md class=select>
    <option value="contact_before" checked>�������</option>
    <option value="fight_player">�ο��</option>
    <option value="buy_before">�����ϱ�</option>
    $t1$t2$t3
    <option value="message_before">���� �����</option>
    <option value="trade_before">$set::orb{x} �ŷ��ϱ�</option>
	</select>
	<input type=submit class=button value="$set::okb">
    <input type=hidden name=id value="$F{id}">
    <input type=hidden name=ud value="$F{ud}">
    <input type=hidden name=ps value="$F{ps}">
    </div>
    </div>
    </form>
    END_OF_HTML
}

# Partner Status #
sub partner_status {
my  $t1;
my  %unique;

    $U = &get_user('U');

    &get_place($U);
    &get_kingdom($U);

    @{$U->{Ob}} = grep { !$unique{$_}++ }
                  grep { /[a-z]/ } split(//,$U->{ob});

    foreach (@{$U->{Ob}}) {
        $t1 .= &orb_image($_);
    }
    $t1 = "<tr><td colspan=2>�ŷ����� $set::orb{x}$t1</td></tr>\n" if $t1;

    $U->{rw} = "<span class=alert>$U->{rw}</span>" if $U->{rw} >= $set::sps;

    # ����̸� �ҷ�����
    map { &get_equipment($U,$_) } keys %set::eqp;

    &get_companion($U);
    $U->{Co}{Im} = &item_image($U->{Co});

    &header(CSS=>'sub');
    print <<"    END_OF_HTML";
    <div class=label>$U->{nm}�� ����</div>
    <table class=outbox border=0>
    <tr>
    <td width=100% nowrap>
    ID: $U->{id}<br>
    $set::lab{sx}: <img src=$set::mim_dir/$U->{sx}.gif><br>
    $set::lab{kg}: <img src=$set::mim_dir/flag$U->{kg}.gif title=$U->{Kg}{nm}><br>
    $set::lab{jb}: $U->{jb}<br>
    $set::lab{da}: $U->{Da}<br>
    $set::lab{lv}: $U->{lv}<br>
    $set::lab{rw}: $U->{rw}<br>
    <br>
    $U->{Co}{Im}<br>
    $set::lab{pt}: $U->{Co}{nm}<br>
    <br>
    $set::eqp{rh}: $U->{Rh}{Im}$U->{Rh}{nm}<br>
    $set::eqp{lh}: $U->{Lh}{Im}$U->{Lh}{nm}<br>
    $set::eqp{sb}: $U->{Sb}{Im}$U->{Sb}{nm}<br>
    <br>
    $set::eqp{hd}: $U->{Hd}{Im}$U->{Hd}{nm}<br>
    $set::eqp{bd}: $U->{Bd}{Im}$U->{Bd}{nm}<br>
    $set::eqp{lg}: $U->{Lg}{Im}$U->{Lg}{nm}<br>
    <br>
    $set::eqp{nk}: $U->{Nk}{Im}$U->{Nk}{nm}<br>
    $set::eqp{fg}: $U->{Fg}{Im}$U->{Fg}{nm}<br>
    </td>
    <th nowrap><img src=$set::mim_dir/$U->{im} class=image><br>$U->{nm}</th>
    </tr>
    $t1
    <tr><td colspan=2 class=r>$set::but{CLOSE}</td><tr>
    </table>
    END_OF_HTML
    &footer;
}

# Partner Examine #
sub partner_examine {
my  $S;
my  $V;

    &set_code;

    $I = &get_user('I');
    $U = &get_user('U');

    $V = (split(/,/,$U->{en}))[0];

    $S = &get_user('A',$V) if $V;

    &partner('...',"...$S->{nm}�Կ��� ���� �� ����.") if $V;
    &partner('...',"...���������� ���� �� ����.");
}

# --------------------------------------------------- #
1;
