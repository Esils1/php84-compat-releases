# --------------------------------------------------- #
# Script of Saga III PlaceChange.cgi Version 1
# Copyright (C) 2005 Missing Link.
# --------------------------------------------------- #

# Sub Delete Place #
sub delete_place {
my  $S = shift;
my  @L;

    &lock($S->{pl});
    @L = grep { $_ ne "$S->{id}\n" } &open_dat("$set::plc_dir/$S->{pl}.cgi");
    &write_dat("$set::plc_dir/$S->{pl}.cgi",@L);
    &unlock($S->{pl});
}

# Sub Set Place #
sub set_place {
my  $S = shift;
my  $T = shift; # true -> unshift
my  @L;

    &lock($S->{pl});
    @L = grep { $_ ne "$S->{id}\n" } &open_dat("$set::plc_dir/$S->{pl}.cgi");
    if ($T) { unshift(@L,"$S->{id}\n") }
    else { push(@L,"$S->{id}\n")    }
    &write_dat("$set::plc_dir/$S->{pl}.cgi",@L);
    &unlock($S->{pl});
    return @L;
}

# Sub Spot Option #
sub spot_option {
my  $S = shift;
my  $V;

    foreach (split(/,/,$S->{Pl}{ev})) {
        next unless $S->{Sp}{$_}{md};
        $V = 1 if !$S->{Sp}{$_}{sk};
        $V = 1 if grep { $I->{Sk}{$_} } split(/,/,$S->{Sp}{$_}{sk});
        next if !$V;
        push (@{$S->{So}},"$S->{Sp}{$_}{md}=$S->{Sp}{$_}{nm}");
        $V = 0;
    }
}

# --------------------------------------------------- #
1;
