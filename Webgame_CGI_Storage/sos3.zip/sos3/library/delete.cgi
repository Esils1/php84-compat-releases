# --------------------------------------------------- #
# Script of Saga III Delete.cgi Version 2 (1.4)
# Copyright (C) 2005-2007 Missing Link.
# --------------------------------------------------- #

# Sub Delete Before #
sub delete_before {
    $I = &get_user('I');

    &get_code;

    &header(CSS=>'sub');
    print <<"    END_OF_HTML";
    <div class=label>ĳ���� ����</div>
    <form method=post action=$set::cgi_url>
    <div class=outbox>
    ĳ���͸� �����մϴ�.<br>
    <br>
    <div class=r><tt>�����Ϸ��� $set::dpc $set::mny �ʿ��մϴ�.</tt><br>$set::but{OK} $set::but{CLOSE}</div>
    <input type=hidden name=md value="delete_after">
    <input type=hidden name=id value="$F{id}">
    <input type=hidden name=ps value="$F{ps}">
    <input type=hidden name=xx value="$I->{XX}">
    </div>
    </form>
    END_OF_HTML
    &footer;
}

# Sub Delete After #
sub delete_after {

    $I = &get_user('I');

    &error("���� �����մϴ�.") if $I->{gl} < $set::dpc;

    &set_code;

    require "$set::lib_dir/placechange.cgi";
    require "$set::lib_dir/information.cgi";

    &delete_place($I);

    &delete_file($F{id});
    &total_players;
    &say('���� �Ϸ�','CLOSE');
    &header(CSS=>'sub',JavaScript=>'ReturnTop',Body=>qq| onLoad="ReturnTop('$set::cgi_url');"|);
    print <<"    END_OF_HTML";
    <div class=outbox>
    ���� �Ϸ�<br>
    <p class=r>$set::but{CLOSE}</p>
    </div>
    END_OF_HTML
    &footer;
}

# Sub Delete Check #
sub delete_check {
my  @L;
my  $U;

    require "$set::lib_dir/information.cgi";

    @L = &get_allusersID();
    foreach (@L) {
        next unless (stat("$set::Ucd_dir/$_.cgi"))[9] + $set::ddy * 86400 < time;
        $U = &get_user('A',$_);
        next if $U->{id} eq $F{id};
        next unless &get_crypt($set::pas,$U->{ps},$set::crp);
        &delete_place($U) if $U;
        &delete_file($U->{id});
    }
    &total_players;
}

# Sub Delete File #
sub delete_file {
$id = shift;

    if (-e "$set::Udt_dir/$id.cgi") { unlink "$set::Udt_dir/$id.cgi" }
    if (-e "$set::Ucd_dir/$id.cgi") { unlink "$set::Ucd_dir/$id.cgi" }
    if (-e "$set::Urc_dir/$id.cgi") { unlink "$set::Urc_dir/$id.cgi" }
    if (-e "$set::Uit_dir/$id.cgi") { unlink "$set::Uit_dir/$id.cgi" }
    if (-e "$set::Uwd_dir/$id.cgi") { unlink "$set::Uwd_dir/$id.cgi" }
    if (-e "$set::Uml_dir/$id.cgi") { unlink "$set::Uml_dir/$id.cgi" }
    if (-e "$set::Upt_dir/$id.cgi") { unlink "$set::Upt_dir/$id.cgi" }
    if (-e "$set::Uop_dir/$id.cgi") { unlink "$set::Uop_dir/$id.cgi" }
    if (-e "$set::Uqs_dir/$id.cgi") { unlink "$set::Uqs_dir/$id.cgi" }
    if (-e "$set::Ubk_dir/$id.cgi") { unlink "$set::Ubk_dir/$id.cgi" }
    if (-e "$set::Ubu_dir/$id.cgi") { unlink "$set::Ubu_dir/$id.cgi" }
    if (-e "$set::npc_dir/$id.cgi") { unlink "$set::npc_dir/$id.cgi" }
    if (-e "$set::sip_dir/$id.cgi") { unlink "$set::sip_dir/$id.cgi" }
}

# --------------------------------------------------- #
1;
