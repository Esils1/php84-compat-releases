# --------------------------------------------------- #
# Script of Saga III Sell.cgi Version 3 (1.4)
# Copyright (C) 2005-2007 Missing Link.
# --------------------------------------------------- #

# Sub Sell Before #
sub sell_before {
my  $i;
my  $id;
my  $t1;

    $I = &get_user('I');

    &dead_check($I,'CLOSE');

    &get_place($I);

    &spot_check($I,'Mk');

    &say("$I->{Sp}{Bm}{nm}�� �����ֽ��ϴ�",'market') unless -e "$set::bmk_dir/$I->{Pl}{xf}";

    &get_item($I);

    foreach $Ii (@{$I->{Bg}}) {
        $i++;
        next if !$Ii;
        next if $Ii->{eq};
        next if $Ii->{Ql}{Br};
        next if $Ii->{Ql}{Tr};

        $Ii->{Sp} = $Ii->{bp} * $Ii->{qn};
        $t1 .= "<input type=checkbox name=$i class=checkbox> ";
        $t1 .= &decorate_item($Ii);
    }

    $t1 ||= '������ �� �ִ� �������� �����ϴ�.';

    &get_code;

    &header(CSS=>'sub');
    print <<"    END_OF_HTML";
    <div class=label>$I->{Sp}{Bm}{nm}�� ���Ծ�����</div>
    <form method=post action=$set::cgi_url>
    <div class=outbox>
    <tt>�Ȱ� ���� �������� �������ּ���.</tt><br>
    <br>
    $t1
    <div class=r>$set::but{OK}</div>
    <input type=hidden name=md value="sell_after">
    <input type=hidden name=id value="$F{id}">
    <input type=hidden name=ps value="$F{ps}">
    <input type=hidden name=xx value="$I->{XX}">
    </div>
    </form>
    END_OF_HTML
    &back_close('market');
    &footer;
}

# Sub Sell After #
sub sell_after {
my  $i;
my  $id;
my  $Ii;
my  %UI;

    $I = &get_user('I');
    $U = {};

    &set_code;

    &get_item($I);
    &get_place($I);
    &get_item($U,1);

    %UI = map { $_->{id}."_".$_->{gd} => $_ } @{$U->{Bg}};

    $I->{bg} = 0; # recalculate
    foreach $Ii (@{$I->{Bg}}) {
        $i++;
        next if !$Ii;
        $I->{bg} += $Ii->{wt} * $Ii->{qn};
		next if !$F{$i};
   		$I->{bg} -= $Ii->{wt} * $Ii->{qn};
   		$I->{gl} += $Ii->{bp} * $Ii->{qn};
        $id = "$Ii->{id}_$Ii->{gd}";
        if (&item_class_check($Ii) ne 'M') {}
  		elsif ($UI{$id}) {
            &change_status($UI{$id},'qn',$Ii->{qn},0,$set::mix);
   		}
   		else {
            $Ii->{Ql}{Dx} = $Ii->{sp} = $Ii->{rs} = '';
   		    $UI{$id} = {%$Ii};
    	}
		&M("$Ii->{nm}(��)�� �Ⱦҽ��ϴ�.");
		$Ii->{qn} = 0;
	}
    &change_status($I,'bg',0);

    @{$U->{Bg}} = values %UI;

    &sort_item($U);

    &set_user($I);
    &set_item($I);
    &set_item($U,1);

    &reload_data('gl');

    &inner_HTML;

    &say($I->{M},'market','Reload');
}

# --------------------------------------------------- #
1;
