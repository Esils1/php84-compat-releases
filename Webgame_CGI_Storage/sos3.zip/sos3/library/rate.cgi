# --------------------------------------------------- #
# Script of Saga III Rate.cgi Version 1
# Copyright (C) 2005 Missing Link.
# --------------------------------------------------- #

# Sub Rate #
sub rate {
my  $W = shift;
my  $L = shift;
my  $R;

    $R = $L->{da} eq 'Dd' ? 1.5 : 1;
	$R = 16 - 0.04 * ($W->{rt} - $L->{rt}) * $R;
    $R = int($R);

	&change_status($W,'rt',$R,0,3000);
	&change_status($L,'rt',-$R,0,3000);
}

# --------------------------------------------------- #
1;

