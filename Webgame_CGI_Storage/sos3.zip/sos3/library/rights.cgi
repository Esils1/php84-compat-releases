# --------------------------------------------------- #
# Script of Saga III Rights.cgi Version 1
# Copyright (C) 2005 Missing Link.
# --------------------------------------------------- #

# Sub Rights #
sub rights {
my  $creators_label= 'Special Thanks';
my  $display = 'none' if !$set::stv;

    # �� ���۱� ǥ�� ��
    # � ���� ���� �Ʒ� ������ ����, ������ �� �����ϴ�.

    print qq|<div class=r style="position:absolute;right:3;bottom:0;">\n|;
    print qq|<span id=rights><a href=http://www.area-s.com/ title="Missing Link" target=_blank>Script of Saga III $version</a>\n|;
    print qq|<br>Edit: $set::edt\n| if $set::edt;
    print qq|</span>\n|;
    print qq|<br>\n|;
    print qq|<a href="#" onClick="GetView('creators')">$creators_label</a>\n| if !$set::stv;
    print qq|<span id=creators style="display:$display"> <tt>$set::spt</tt></span>\n| if $set::spt;
    print qq|</div>\n|;
}

# --------------------------------------------------- #
1;
