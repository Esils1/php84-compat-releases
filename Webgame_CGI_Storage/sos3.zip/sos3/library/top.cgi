# --------------------------------------------------- #
# Script of Saga III Top.cgi Version 2 (1.4)
# Copyright (C) 2005-2007 Missing Link.
# --------------------------------------------------- #

# Sub Top #
sub top {
my  $t1;
my  $V;

    $t1 = &login_players if $set::now;

    require "$set::lib_dir/rights.cgi";
    $V = (&open_dat("$set::dat_dir/totalplayers.cgi"))[0];
    chomp $V;

    &header(CSS=>'main',JavaScript=>'GetCookie,GetView',Body=>' onLoad="GetValue();"');
    print <<"    END_OF_HTML";
    <table class=basetable cellpadding=5 align=center>
    <tr>
    <td width=50%>
    <div class=label>�űԵ��</div>
    <form method=post action=$set::cgi_url>
    <div class=words>
    <tt>$set::lab{sx}�� �������ּ���.</tt><br>
    <div class=words><img src=$set::mim_dir/m.gif><input type=radio name=sx class=radio value="m" checked> <img src=$set::mim_dir/w.gif><input type=radio name=sx class=radio value="w"></div>
    <br>
    $set::but{OK}
    <input type=hidden name=md value="new_before">
    </div>
    <br>
    </form>
    <form name=loginform method=post action=$set::cgi_url>
    <div class=label>�α���</div>
    <pre class=words>
ID       <input type=text name=id class=textbox size=8>
Password <input type=password name=ps class=textbox size=8>

$set::but{OK}
<input type=hidden name=md value="main">
    </pre>
    </form>
    <div class=words>
    <a class=back href=$set::htm_dir/manual/ target=_blank>�޴���</a><br>
    <a class=back href=$set::htm_dir/statistics.html target=_blank>������ ���</a>
    </div>
    </td>
    <td>
    <iframe src=$set::inf_htm name="info" frameBorder=0 class=iframe1></iframe><br>
    <iframe src=$set::poe_htm name="poem" frameBorder=0 class=iframe2></iframe>
    </td>
    </tr>
    </table>
    <div class=inform>������: $V��<br>
    $t1
    </div>

    END_OF_HTML
    &rights;
    &footer;
}

# Login Players #
sub login_players {
my ($V,@L);

    opendir(DIR,"$set::Ucd_dir/") || return;
    @L = grep { time < $set::lgi + (stat("$set::Ucd_dir/$_"))[9] }
         grep /\.cgi/,readdir(DIR);
    closedir(DIR);
    $V = @L;
    return qq|���� ������: $V��\n|
}

# --------------------------------------------------- #
1;
