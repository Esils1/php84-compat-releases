# --------------------------------------------------- #
# Script of Saga III Bath.cgi Version 3 (1.3)
# Copyright (C) 2005-2007 Missing Link.
# --------------------------------------------------- #

# Sub Bath Before #
sub bath_before {
my ($V);

    $I = &get_user('I');

    &dead_check($I,'CLOSE');

    &get_place($I);

    &spot_check($I,'Pb');

    &get_code;

    $V = int($set::bmn * $I->{lv} * ($I->{Map} - $I->{ap}));
    $V *= 2 if $I->{Cd}{'Dt'};

    &header(CSS=>'sub');
    print <<"    END_OF_HTML";
    <div class=label>$I->{Sp}{Pb}{nm}</div>
    <form method=post action=$set::cgi_url>
    <div class=outbox>
    <div class=r><tt>
    <img src=$set::mim_dir/envPb.gif><br>
    <br>
    ����� $set::bmn $set::mny�Դϴ�.<br>
    $set::lab{ap}�� ���� ȸ���˴ϴ�.<br>
    <br>
    $set::lab{gl}: $I->{gl} $set::mny
    </tt></div>
    <br>
    <div class=r><input type=submit class=button value="����ϱ�"> $set::but{CLOSE}</div>
    <input type=hidden name=md value="bath_after">
    <input type=hidden name=id value="$F{id}">
    <input type=hidden name=ps value="$F{ps}">
    <input type=hidden name=xx value="$I->{XX}">
    </div>
    </form>
    END_OF_HTML
    &footer;
}

# Sub Bath After #
sub bath_after {
my ($V);

    $I = &get_user('I');

    $V = int($set::bmn * $I->{lv} * ($I->{Map} - $I->{ap}));
    $V *= 2 if $I->{Cd}{'Dt'};

    &say("$set::lab{gl}�� �����մϴ�.",'CLOSE') if $I->{gl} < $V;

    &set_code;

    &change_status($I,'ap',$I->{Map});

    &change_status($I,'gl',-$V);

    &reload_data('gl');
    &reload_gage('ap','V');

    &inner_HTML;

    &set_user($I);
    &say("����� �ϰ� ���� ����� �����մϴ�.<br>$set::lab{ap}�� ���� ȸ���ƽ��ϴ�",'CLOSE','Reload');
}

# --------------------------------------------------- #
1;
