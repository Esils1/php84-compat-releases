# --------------------------------------------------- #
# Script of Saga III Farm.cgi Version 1
# Copyright (C) 2005 Missing Link.
# --------------------------------------------------- #

# Sub Farm Before #
sub farm_before {
my  $Ui;
my  $Up;
my  $t1;
my  $t2;

    $I = &get_user('I');

    &dead_check($I,'CLOSE');

    &get_place($I);

    &spot_check($I,'Fm');

    &say("$I->{Sp}{Fm}{nm}(��)�� �����ֽ��ϴ�",'CLOSE') unless -e "$set::itm_dir/$I->{Pl}{fm}";
    &say("$I->{Sp}{Fm}{nm}(��)�� �����ֽ��ϴ�",'CLOSE') unless -e "$set::itm_dir/$I->{Pl}{ls}";

    require "$set::itm_dir/$I->{Pl}{fm}";

    foreach $Ui (@FI) {
        $Ui->{Sp} = int($Ui->{bp} * $set::mtp + $set::mpp) * $Ui->{qn};
        $t1 .= qq|<input type=checkbox name=$Ui->{id} class=checkbox> |;
        $t1 .= &decorate_item($Ui);
    }

    require "$set::itm_dir/$I->{Pl}{ls}";

    foreach $Up (@FI) {
        $Up->{Sp} = int($Up->{bp} * $set::mtp + $set::mpp);
        $t2 .= qq|<input type=checkbox name=$Up->{id} class=checkbox> |;
        $t2 .= &decorate_item($Up);
    }

    &get_code;

    &header(CSS=>'sub');

    print <<"    END_OF_HTML";
    <div class=label>$SP{Fm}{nm}</div>
    <form method=post action=$set::cgi_url>
    <div class=outbox>
    <tt>���忡�� �Ǹ����� ������</tt><br>
    $t1
    <div class=r><tt>������ ����: $I->{bg}/$I->{Mbg} $set::wgt</tt></div>
    <br>
    <tt>���忡�� �Ǹ��ϰ� �ִ� ����</tt><br>
    $t2
    <div class=r><tt>����: $I->{px}/$I->{Mpx} $set::wgt</tt></div>
    <br>
    <div class=r><tt>$set::lab{gl}: $I->{gl} $set::mny</tt></div>
    <br>
    <div class=r>$set::but{OK} $set::but{CLOSE}</div>
    <input type=hidden name=md value="farm_after">
    <input type=hidden name=id value="$F{id}">
    <input type=hidden name=ps value="$F{ps}">
    <input type=hidden name=xx value="$I->{XX}">
    </div>
    </form>
    END_OF_HTML
    &footer;
}

# Sub Farm After #
sub farm_after {
my  $Ii;
my  $Ui;
my  $Up;
my  $buyitemflag;
my  $buypetsflag;

    $I = &get_user('I');

    &set_code;

    &get_place($I);

    &get_item($I);

    require "$set::itm_dir/$I->{Pl}{fm}";

    foreach $Ui (@FI) {
        next if !$F{$Ui->{id}};
        $Ui->{Sp} = int($Ui->{bp} * $set::mtp + $set::mpp) * $Ui->{qn};

        &say('���ſ��� ���̻� ���� �� �����ϴ�','farm_before') if $I->{bg} + $Ui->{wt} * $Ui->{qn} > $I->{Mbg};
        &say('���� �����մϴ�','farm_before') if $Ui->{Sp} > $I->{gl};
        &say("������ ���� á���ϴ�",'farm_before') if @{$I->{Bg}} >= $I->{bs};

        &change_status($I,'gl',-$Ui->{Sp});
        &change_status($I,'bg',$Ui->{wt} * $Ui->{qn});

        $Ui->{Im} = &item_image($Ui);

        &M("$Ui->{Im}$Ui->{nm}(��)�� $Ui->{qn}�� �����߽��ϴ�.");

        push (@{$I->{Bg}},$Ui);
        $buyitemflag = 1;
    }

    if ($buyitemflag) {
        &sort_item($I);
        &set_item($I);
    }

    &get_pet($I);
    require "$set::itm_dir/$I->{Pl}{ls}";

    foreach $Up (@FI) {
        next if !$F{$Up->{id}};
        $Up->{Sp} = int($Up->{bp} * $set::mtp + $set::mpp);

        &say('������ �� á���ϴ�','farm_before') if $I->{px} + $Up->{sl} > $I->{Mpx};
        &say('���� �����մϴ�','farm_before') if $Up->{Sp} > $I->{gl};

        &change_status($I,'gl',-$Up->{Sp});
        &change_status($I,'px',$Up->{sl});

        $Up->{Im} = &item_image($Up);

        &M("$Up->{Im}$Up->{nm}(��)�� �����߽��ϴ�.");

        $Up->{up} = $Up->{bt} = time;
        $Up->{pd} = time if $Up->{pd};
        $Up->{ch} = &roll_dice(4) - 1;
        push (@{$I->{Pt}},$Up);
        $buypetsflag = 1;
    }

    if ($buypetsflag) {
        &sort_pet($I);
        &set_pet($I);
    }

    &set_user($I);
    &reload_data('gl');

    &inner_HTML;

    &say($I->{M},'farm_before','Reload');
}

# --------------------------------------------------- #
1;
