# --------------------------------------------------- #
# Script of Saga III Install.cgi Version 1
# Copyright (C) 2005 Missing Link.
# --------------------------------------------------- #

# Sub Install #
sub install {
my  $i;
my  $Ii;

    $I = &get_user('I');
    &get_item($I);

    foreach $Ii (@{$I->{Bg}}) {
        $i++;
        next if !$F{$i};
        if (!$Ii->{Ql}{Fu}) { &M("$Ii->{nm}(��)�� ��ġ�� �� �����ϴ�.") }
        else {
            &M("$Ii->{nm}(��)�� ��ġ�߽��ϴ�.");
            &change_status($I,'bg',-$Ii->{wt});
            $Ii->{wt} = 0;
            $Ii->{ql} =~ s/Fu/Lk,Sc,Tr,Ns/;
            $Ii->{sp} = $Ii->{rs} = '';
        }
    }

    &set_code;

    &set_user($I);
    &set_item($I);

    &say($I->{M},'bag');
}

# --------------------------------------------------- #
1;
