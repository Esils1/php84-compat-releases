# --------------------------------------------------- #
# Script of Saga III Attune.cgi Version 1
# Copyright (C) 2005 Missing Link.
# --------------------------------------------------- #

# Sub Attune Before #
sub attune_before {
my  $i;
my  $Ii;
my  $t1;

    $I = &get_user('I');

    &get_item($I);

    foreach $Ii (@{$I->{Bg}}) {
        $i++;
        next if !$Ii;
		next if !$F{$i};
	    if ($Ii->{cl} !~ /(Sw|Ax|Sp|Kt|Bo|Cl|Wn|Hm|Ar|Bt|Sh|Ht|Ds|Ac|Rg)/) {
	        $t1 .= "$Ii->{nm}(��)�� ����ȭ�� �� �����ϴ�.<br>\n"
	    }
	    else {
            &attune_price($Ii);
            $t1 .= qq|<input type=checkbox name=$i class=checkox checked> |;
            $t1 .= &decorate_item($Ii);
        }
	}

    &say("�������� �������ּ���",'bag') if !$t1;

    &get_code;

    &header(CSS=>'sub');
    print <<"    END_OF_HTML";
    <div class=label>����ȭ�ϱ�</div>
    <form method=post action=$set::cgi_url>
    <div class=outbox>
    <tt>����ȭ��Ų �������� ���ϸ��� ������,<br>�ٸ� ����� �ŷ��� ���� �����ϴ�.</tt><br>
    <br>
    $t1
    <div class=r><tt>$set::lab{gl}: $I->{gl} $set::mny</tt></div>
    <br>
    <div class=r>$set::but{OK}</div>
    <input type=hidden name=md value="attune_after">
    <input type=hidden name=id value="$F{id}">
    <input type=hidden name=ps value="$F{ps}">
    <input type=hidden name=xx value="$I->{XX}">
    </div>
    </form>
    END_OF_HTML
    &back_close('bag');
    &footer;
}

# Sub Attune After #
sub attune_after {
my  $i;
my  $Ii;

    $I = &get_user('I');

    &get_item($I);

    foreach $Ii (@{$I->{Bg}}) {
        $i++;
        next if !$Ii;
        next if !$F{$i};
        &attune_price($Ii);
        &M("$Ii->{nm}: ���� �����մϴ�.") && next if $Ii->{Sp} > $I->{gl};
        &change_status($I,'gl',-$Ii->{Sp});
        $Ii->{ql} = join(',',grep { $_ ne 'At' } keys %{$Ii->{Ql}},'Ns','Sc');
        $Ii->{sp} = $Ii->{rs} = '';
        &M("$Ii->{nm}(��)�� ����ȭ�߽��ϴ�.");
	}

    &set_code;

    &set_item($I);
    &set_user($I);

    &reload_data('gl');

    &inner_HTML;

    &say($I->{M},'bag','Reload');
}

# Sub Attune Price #
sub attune_price {
my  $Si = shift;

    $Si->{Sp}  = $Si->{bp};
    $Si->{Sp} *= 1 + ($Si->{gd} - 1) / 10 if $Si->{gd};
    $Si->{Sp} *= 1.2 if $Si->{Ql}{Ex};
    $Si->{Sp} *= 1 + $Si->{pl} / 10 if $Si->{pl};
    $Si->{Sp}  = int($Si->{Sp});
}

# --------------------------------------------------- #
1;
