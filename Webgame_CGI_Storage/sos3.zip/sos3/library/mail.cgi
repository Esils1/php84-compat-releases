# --------------------------------------------------- #
# Script of Saga III Mail.cgi Version 1
# Copyright (C) 2005 Missing Link.
# --------------------------------------------------- #

# Sub Mail Before #
sub mail_before {
my ($t1,$t2,$t3);
my  @L;
my  %unique;

    $I = &get_user('I');

    &get_place($I);
    &get_resident($I);

    foreach (@{$I->{Pp}}) {
        next if $_ eq $I->{id};
        next unless index($_,'_');
        $U = &get_user('A',$_,'noerror') or next;
        $t1 .= qq|<option value="$U->{id}">$U->{id}:  $U->{nm}��$U->{jb}��</option>\n|;
    }

    foreach (split(/,/,$I->{fr})) {
        ($U->{id},$U->{nm}) = split(/\//);
        next unless -e "$set::Udt_dir/$U->{id}.cgi";
        $t2 .= qq|<option value="$U->{id}">$U->{id}:  $U->{nm}</option>\n|;
    }

    @L = grep { !$unique{$_->[0]}++ }
         map  { [(split(/<>/))[3,4]] } &open_dat("$set::Uml_dir/$I->{id}.cgi");

    foreach (@L) {
        next if $_->[0] eq $I->{id};
        next unless -e "$set::Udt_dir/$_->[0].cgi";
        $t3 .= qq|<option value="$_->[0]">$_->[0]:  $_->[1]</option>\n|;
    }

    $F{mail} =~ s/<br>/\n/g if $F{mail};

    &header(CSS=>'sub');
    print <<"    END_OF_HTML";
    <div class=label>���� �ۼ�</div>
    <form method=post action=$set::cgi_url>
    <div class=outbox>
    <input type=radio class=radio name=type value="near" checked> $I->{Pl}{nm}�� �ִ� �÷��̾�<br>
    <tt>��Ͽ��� ����: <select name=ud_near class=select>$t1</select></tt><br>
    <tt>ID: <input type=textbox name=ud_near2 class=textbox size=4></tt><br>
    <br>
    <input type=radio class=radio name=type value="far"> �ٸ� ������ �ִ� �÷��̾�<br>
    <tt>ID: <input type=textbox name=ud_far class=textbox size=4></tt><br>
    <br>
    <input type=radio class=radio name=type value="friend"> ģ�� ����<br>
    <tt>��Ͽ��� ����: <select name=ud_friend class=select>$t2</select></tt><br>
    <br>
    <input type=radio class=radio name=type value="penpal"> �ֱ� ������ ������ ���� ���<br>
    <tt>��Ͽ��� ����: <select name=ud_penpal class=select>$t3</select></tt><br>
    <br>
    <tt>
    ���ڼ����� : �ѱ� ���� $set::llx�ڱ���<br>
    <textarea class=textarea name=mail cols=50 rows=8>$F{mail}</textarea>
    </tt><br>
    <br>
    <div class=r><tt>��ۺ񡤡���$I->{Pl}{nm}: $set::mmn $set::mny<br>�ٸ� ����: $set::mmf $set::mny</tt></div>
    <div class=r>$set::but{OK}<br><br>$set::but{CLOSE}</div>
    <input type=hidden name=md value="mail_confirm">
    <input type=hidden name=id value="$F{id}">
    <input type=hidden name=ps value="$F{ps}">
    </div>
    </form>
    END_OF_HTML
    &footer;
}

# Sub Mail Confirm #
sub mail_confirm {
my  $t1;
my  $mail;
my  $length;
my  $disabled;

    $F{ud} = $F{"ud_$F{type}"};
    $F{ud} = $F{ud_near2} if $F{type} eq 'near' && $F{ud_near2};

    &say('�޴� ����� ID�� �߸��ƽ��ϴ�','mail_before') if $F{ud} =~ /\W/;
    &say('�ڽſ��� ���� �� �����ϴ�','mail_before') if $F{ud} eq $F{id};

    $mail = $F{mail};
    $F{mail} =~ s/<br>/\n/g;

    $length = length $F{mail};
    &say('������ ������ �����ϴ�','mail_before') if !$length;
    $length = int($length / 2) + $length % 2;
    if ($length > $set::llx) { $t1 = "������ �ѱ� ���� <span class=alert>$set::llx</span>�ڱ��� ����<br><tt>���� ���ڼ�������$length��</tt><br>\n" }

    $I = &get_user('I');
    $U = &get_user('U');

    $I->{Gl} = $I->{pl} eq $U->{pl} ? $set::mmn : $set::mmf;
    &say("$set::lab{gl}�� �����մϴ�",'mail_before') if $I->{Gl} > $I->{gl};

    &get_code;

    $disabled = ' disabled' if $t1;

    &header(CSS=>'sub');
    print <<"    END_OF_HTML";
    <div class=label>���� Ȯ��</div>
    <div class=outbox>
    $U->{nm}�Կ��� ������ �����ϴ�.<br>
    <tt>$U->{nm}�Կ��� ������ ��ۺ񡤡��� <span class=alert>$I->{Gl} $set::mny</span></tt><br>
    <br>
    $t1
    <br>
    <tt>���� ����</tt><br>
    $mail
    <table class=r>
    <tr>
    <form method=post action=$set::cgi_url>
    <td>
    <input type=submit class=button value="���� ����">
    <input type=hidden name=md value="mail_before">
    <input type=hidden name=id value="$F{id}">
    <input type=hidden name=ps value="$F{ps}">
    <input type=hidden name=mail value="$F{mail}">
    </td>
    </form>
    <form method=post action=$set::cgi_url>
    <td>
    <input type=submit class=button value="���� ������"$disabled>
    <input type=hidden name=md value="mail_after">
    <input type=hidden name=id value="$F{id}">
    <input type=hidden name=ps value="$F{ps}">
    <input type=hidden name=ud value="$F{ud}">
    <input type=hidden name=xx value="$I->{XX}">
    <input type=hidden name=mail value="$F{mail}">
    </td>
    </form>
    </tr>
    </table>
    </div>
    END_OF_HTML
    &footer;
}

# Sub Mail After #
sub mail_after {
my  $V;
my  @L;

    $I = &get_user('I');
    $U = &get_user('U');

    &set_code;

	require "$set::lib_dir/date.cgi";
	$V = &get_date;

	$F{mail} = "<font color=$I->{fc}>$F{mail}</font>";

    &lock($U->{id});
    @L = &open_dat("$set::Uml_dir/$U->{id}.cgi");
	pop(@L) if @L >= $set::lsx;
	unshift(@L,join('<>',time,$V,$F{mail},$I->{id},$I->{nm},$I->{im},"\n"));
    &write_dat("$set::Uml_dir/$U->{id}.cgi",@L);
    &unlock($U->{id});

    if ($set::smi) {
        @L = &open_dat("$set::Uml_dir/$I->{id}.cgi");
    	pop(@L) if @L >= $set::lsx;
    	unshift(@L,join('<>',time,$V,$F{mail},$I->{id},$U->{nm},$I->{im},"\n"));
        &write_dat("$set::Uml_dir/$I->{id}.cgi",@L);
    }

    $I->{gl} -= $I->{pl} eq $U->{pl} ? $set::mmn : $set::mmf;
    $I->{mb}  = time + 10;
    &set_user($I);

    &reload_data('gl');

    &inner_HTML;

    &say('������ ���½��ϴ�','mail_before','Reload');
}

# Mail Box #
sub mail_box {
my  @L;
my  $t1;

    $I = &get_user('I');

    @L = map { [split(/<>/)] } &open_dat("$set::Uml_dir/$I->{id}.cgi");

    &header(CSS=>'sub',JavaScript=>'Reload');

    if ((stat("$set::Uml_dir/$I->{id}.cgi"))[9] > $I->{mb}) {
        &inner_HTML(Msg=>"'newmail'");
        print $I->{inner_HTML};
    }

    print "<div class=label>���� ����</div>";
    foreach (@L) {
        print qq|<div class=r><img src=$set::mim_dir/mail.gif></div>| if $_->[0] > $I->{mb};
        print qq|<img src=$set::mim_dir/$_->[5] class=float>\n|;
        $t1 = $_->[3] eq $I->{id} ? "$I->{nm}���� $_->[4]�Կ��� ���� ����":
                                    "[$_->[3]]$_->[4]���� $I->{nm}�Կ��� ���� ����";
        print qq|<tt>$t1</tt><br>\n|;
        print qq|$_->[2]\n|;
        print qq|<br class=clear><br>|;
        print qq|<div class=r><tt>$_->[1]</tt></div><hr>|;
    }
    print qq|<p class=c>$set::but{CLOSE}</p>\n|;
    &footer;

    $I->{mb} = time;
    &set_user($I);
}

# --------------------------------------------------- #
1;