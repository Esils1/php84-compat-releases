# --------------------------------------------------- #
# Script of Saga III Magic.cgi Version 1
# Copyright (C) 2005 Missing Link.
# --------------------------------------------------- #

require "$set::dat_dir/magic.cgi";

# Magic Before #
sub magic_before {
my ($i,$j,$C);
my  $t1;
my  $selected;

    $I = &get_user('I');

    &say("$SK{Mg}(��)�� ����� �� �����ϴ�",'CLOSE') if !$I->{Sk}{Mg};

    $C = &magic_count;

    $I->{Mg} = [split(/,/,$I->{mg})] if $I->{Sk}{Mg};

    for $i (1..$C) {
        $t1 .= "$i ��°: <select name=$i class=select>\n";
        foreach $j (0 .. $#MG) {
            next if $j && !$I->{Sk}{"M$j"};
            $selected = $I->{Mg}[$i-1] == $j ? ' selected' : '';
            $t1 .= "<option value=$j$selected>$MG[$j]{nm}</option>\n";
        }
        $t1 .= "</select><br>\n";
    }

    &get_code;

    &header(CSS=>'sub');
    print <<"    END_OF_HTML";
    <div class=label>$SK{Mg} �����ϱ�</div>
    <form method=post action=$set::cgi_url>
    <div class=outbox>
    <tt>�����߿� ����� $SK{Mg}(��)�� �����մϴ�</tt><br>
    <br>
    $t1
    <div class=r>$set::but{OK} $set::but{CLOSE}</div>
    <input type=hidden name=md value="magic_after">
    <input type=hidden name=id value="$F{id}">
    <input type=hidden name=ps value="$F{ps}">
    <input type=hidden name=xx value="$I->{XX}">
    </div>
    </form>
    END_OF_HTML
    &footer;
}

# Magic After #
sub magic_after {
my ($i,$C,@L);

    $I = &get_user('I');

    &set_code;

    $C = &magic_count;

    for $i (1..$C) {
        push(@L,$F{$i});
    }

    $I->{mg} = join(',',@L);
    &set_user($I);

    &say('���� �Ϸ�','magic_before');
}

# Magic Count #
sub magic_count {
my  $C;

    # �⺻ ���� Ƚ��
    $C = $set::frd;
    # ���
    $C++ if $I->{Sk}{Sa};
    # ī���� ����
    $C++ if $I->{Sk}{Ct};
    # ���� ����
    $C += $set::uBk;

    return $C;
}

# --------------------------------------------------- #
1;