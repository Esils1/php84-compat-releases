# --------------------------------------------------- #
# Script of Saga III Take Off.cgi Version 1
# Copyright (C) 2005 Missing Link.
# --------------------------------------------------- #

# Take Off #
sub takeoff {
my  $i;
my  $Ii;

    $I = &get_user('I');

    &get_item($I);

    &set_code;

    foreach $Ii (@{$I->{Bg}}) {
        $i++;
        next if !$Ii;
        next if !$F{$i};
        next if !$Ii->{eq};

        $I->{$Ii->{eq}} = '';
        &reload_data($Ii->{eq});
        &reload_data('of') if $Ii->{eq} eq 'rh';
        &reload_data('df') if $Ii->{cl} eq 'Ar';
        &M("$set::eqp{$Ii->{eq}}$Ii->{nm}O?B");
        $Ii->{eq} = '';
	}

    &inner_HTML;

    &set_user($I);
    &set_item($I);

    &say($I->{M},'bag','Reload');
}

# Take Off All #
sub takeoff_all {
my  @EQ;
my  $Ii;

    $I = &get_user('I');
    &get_item($I);

    &set_code;

    foreach $Ii (@{$I->{Bg}}) {
        next if !$Ii;
        $Ii->{eq} = '';
	}

    @EQ = keys %set::eqp;

    foreach (@EQ) {
        $I->{$_} = '';
        &reload_data($_);
    }

    &reload_data('of');
    &reload_data('df');

    &inner_HTML;

    &set_user($I);
    &set_item($I);

    &say('��� ��� ����������','bag','Reload');
}

# --------------------------------------------------- #
1