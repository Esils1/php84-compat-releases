﻿# --------------------------------------------------- #
# Script of Saga III Ride.cgi Version 1
# Copyright (C) 2005 Missing Link.
# --------------------------------------------------- #

require "$set::lib_dir/companion.cgi";

# Sub Ride Mount #
sub ride_mount {
my  $Ip;

    $I = &get_user('I');

    &dead_check($I,'CLOSE');

    &get_companion($I);

    &ride_check;

    &say("동행하고 있는 애완동물은 제외해주세요.",'pet') if $I->{Co}{tp} eq 'co';

    &set_code;

    &get_pet($I);

    $Ip = $I->{Pt}[$F{pt}];
    $Ip->{Im} = &item_image($Ip);

    &say("$Ip->{Im}$Ip->{Nm}에 탈 수 없습니다.",'pet') if $Ip->{cl} ne 'Hr' && $Ip->{cl} ne 'Dr' && $Ip->{cl} ne 'Pg';
    &say("$Ip->{Im}$Ip->{Nm}에 타려면 $SK{Hr} 기술이 필요합니다.",'pet') if $Ip->{cl} eq 'Hr' && !$I->{Sk}{Hr};
    &say("$Ip->{Im}$Ip->{Nm}에 타려면 $SK{Dr} 기술이 필요합니다.",'pet') if $Ip->{cl} eq 'Dr' && !$I->{Sk}{Dr};
    &say("$Ip->{Im}$Ip->{Nm}에 타려면 $SK{Pg} 기술이 필요합니다.",'pet') if $Ip->{cl} eq 'Pg' && !$I->{Sk}{Pg};
    &say("$Ip->{Im}$Ip->{Nm}(은)는 죽었습니다.",'pet') if !$Ip->{hg};
    &say("$Ip->{Im}$Ip->{Nm}(이)가 거부합니다.",'pet') if $Ip->{ft} < $set::pcr;

    &set_companion($Ip,'rd');

    &inner_HTML;

    &sort_pet($I);
    &set_pet($I);
    &set_user($I);
    &say("$Ip->{Im}$Ip->{Nm}에 올라탔습니다.",'pet','Set,Reload');
}

# Sub Ride Dismount #
sub ride_dismount {
my  $Ip;

    $I = &get_user('I');

    &get_companion($I);
    &say("이미 타고 있습니다.",'pet') if $I->{Co}{tp} ne 'rd';

    &set_code;

    &get_pet($I);

    $Ip = $I->{Pt}[$F{pt}];
    $Ip->{Im} = &item_image($Ip);

    &say("$Ip->{Im}$Ip->{Nm}(을)를 타고 있습니다.",'pet') if $Ip->{eq} ne 'rd';

    &delete_companion($Ip);

    &inner_HTML;

    &sort_pet($I);
    &set_pet($I);
    &set_user($I);
    &say("$Ip->{Im}$Ip->{Nm}에서 내렸습니다.",'pet','Reload');
}
# --------------------------------------------------- #
1;
