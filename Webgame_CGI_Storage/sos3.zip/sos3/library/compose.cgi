# --------------------------------------------------- #
# Script of Saga III Compose.cgi Version 4 (1.4)
# Copyright (C) 2005-2007 Missing Link.
# --------------------------------------------------- #

# Sub Compose #
sub compose {
my  $i;
my  $Ii;
my ($t1,$t2);

    $I = &get_user('I');

    &dead_check($I,'CLOSE');

    &get_item($I);

    foreach $Ii (@{$I->{Bg}}) {
        $i++;
        next if !$Ii;
        $t1 .= "<input type=checkbox name=$i class=checkbox> ";
        $t1 .= &decorate_item($Ii);
    }

    if ($I->{Sk}{Bs}) { $t2 .= qq|<option value="arms=Bs">�������� �� �ϱ�</option>\n| }
    if ($I->{Sk}{Tk}) { $t2 .= qq|<option value="silverwork=Tk">�������ǰ �����</option>\n| }
    if ($I->{Sk}{Ck}) { $t2 .= qq|<option value="dish_soup=Ck">�����ϱ� (����)</option>\n| }
    if ($I->{Sk}{Ck}) { $t2 .= qq|<option value="dish_sandwich=Ck">�����ϱ� (������ġ)</option>\n| }
    if ($I->{Sk}{Ck}) { $t2 .= qq|<option value="dish_sweets=Ck">�����ϱ� (����)</option>\n| }
    if ($I->{Sk}{Ck}) { $t2 .= qq|<option value="dish_other=Ck">�����ϱ� (�� ��)</option>\n| }
    if ($I->{Sk}{Bg}) { $t2 .= qq|<option value="liquor=Bg">�� �����</option>\n| }
    if ($I->{Sk}{Wv}) { $t2 .= qq|<option value="cloth=Wv">�ʰ�¥��</option>\n| }
    if ($I->{Sk}{Tl}) { $t2 .= qq|<option value="clothes=Tl">�� �����</option>\n| }
    if ($I->{Sk}{Tl}) { $t2 .= qq|<option value="leathercraft=Tl">������ǰ �����</option>\n| }
    if ($I->{Sk}{Pl}) { $t2 .= qq|<option value="crops=Pl">���� �Ѹ���</option>\n| }
    if ($I->{Sk}{Dp}) { $t2 .= qq|<option value="dairyproduct=Dp">����ǰ �����</option>\n| }
    if ($I->{Sk}{By}) { $t2 .= qq|<option value="bread=By">�� ����</option>\n| }
    if ($I->{Sk}{Ca}) { $t2 .= qq|<option value="woodwork=Ca">�����ǰ �����</option>\n| }
    if ($I->{Sk}{Vt}) { $t2 .= qq|<option value="animaldrug=Vt">������ �����</option>\n| }
    if ($I->{Sk}{Cu}) { $t2 .= qq|<option value="preparation=Cu">ġ���غ��ϱ�</option>\n| }
    if ($I->{Sk}{Ph}) { $t2 .= qq|<option value="drug=Ph">�����ϱ�</option>\n| }

    &say("���� ����� ������ ���� �ʽ��ϴ�",'CLOSE') if !$t2;

    &get_code;

    &header(CSS=>'sub',JavaScript=>'GetView');
    print <<"    END_OF_HTML";
    <div class=label>����</div>
    <form method=post action=$set::cgi_url>
    <div class=outbox>
    $t1
    <div class=r>
    <tt>������ ����: $I->{bg}/$I->{Mbg} $set::wgt</tt><br>
    </div>
    <br>
    <div class=r>
    <select id=mode name=md class=select onChange="HideObject('type','mode','compose_before','normal');">
    <option value="compose_before">�����</option>
    <option value="pack">��Ʈ�� �����</option>
    <option value="unpack_before">��Ʈ �и��ϱ�</option>
    <option value="dump">������</option>
    </select>
    <select id=type style="visibility:visible" name=tp class=select>
    $t2
    </select>
    $set::but{OK}<br>
    <br>
    $set::but{CLOSE}
    </div>
    <input type=hidden name=id value="$F{id}">
    <input type=hidden name=ps value="$F{ps}">
    <input type=hidden name=xx value="$I->{XX}">
    <input type=hidden name=fl value="compose">
    </div>
    </form>
    END_OF_HTML
    &footer;
}

# Sub Compose Before #
sub compose_before {
my  $i;
my  $Ii;
my ($t1,$t2);
my ($K,$V,$L,@L);

    $I = &get_user('I');

    ($K,$V) = split(/=/,$F{tp});

    require "$set::itm_dir/$K.cgi";

    @L = sort grep /\d/, keys %F;
    $L = join('/',@L);

    foreach $Ii (@FI) {
        $i++;
        next unless &creativity_check($I,$Ii);
        $t1 .= qq|<option value="$i">$Ii->{dt}{nm}|;
        $t1 .= qq| = $Ii->{gl} $set::mny| if $Ii->{gl};
        $t1 .= qq|</option>\n|;
    }

    foreach (1 .. $I->{pc}) {
        $t2 .= qq|<option value="$_">$_</option>\n|;
    }

    &set_code;
    &get_code;

    &header(CSS=>'sub');
    print <<"    END_OF_HTML";
    <div class=label>���� ������</div>
    <form method=post action=$set::cgi_url>
    <div class=outbox>
    <select name=ci class=select>$t1</select> ����: <select name=do class=select>$t2</select> $set::but{'OK'}
    <input type=hidden name=id value="$F{id}">
    <input type=hidden name=ps value="$F{ps}">
    <input type=hidden name=md value="compose_after">
    <input type=hidden name=xx value="$I->{XX}">
    <input type=hidden name=fi value="$K">
    <input type=hidden name=sk value="$V">
    <input type=hidden name=ai value="$L">
    <div class=r><tt>$set::lab{gl}: $I->{gl} $set::mny</tt></div>
    </div>
    </form>
    END_OF_HTML
    &back_close('compose');
    &footer;
}

# Sub Compose After #
sub compose_after {
my  $Ii;
my  $Ui;
my (@CL,@ID,$K,$V);

    $I = &get_user('I');

    &error('Compose Skill Error') if $F{sk} && !$I->{Sk}{$F{sk}};

    &set_code;

    map { $F{$_} = 1 } split(/\//,$F{ai});

    &get_item($I);

    &say("���濡 ������ �����մϴ�",'compose') if @{$I->{Bg}} >= $I->{bs};

    &error('Compose File Error') if !$F{fi} || $F{fi} =~ /[^a-z_]/;

    require "$set::itm_dir/$F{fi}.cgi";

    $Ui = $FI[$F{ci}-1];

    if ($F{do} > 1 && &item_class_check($Ui->{dt}) ne 'M') {
        &M("$Ui->{dt}{nm}(��)�� �ϳ��� �ۿ� ���� �� �����ϴ�.");
        $F{do} = 1;
    }

    if ($F{do} > 1) {
        foreach $V (keys %{$Ui->{cl}}) {
            $Ui->{cl}{$V} *= $F{do};
        }
        foreach $V (keys %{$Ui->{id}}) {
            $Ui->{id}{$V} *= $F{do};
        }
        $Ui->{dt}{qn} *= $F{do};
        $Ui->{ex} *= $F{do};
        $Ui->{gl} *= $F{do};
    }

    foreach (split(/,/,$Ui->{gv})) {
        ($K,$V) = split(/=/);
        $V *= $F{do};
        &say("$set::lab{$K}(��)�� $V �ʿ��մϴ�",'compose') if $I->{$K} < $V;
        &change_status($I,$K,-$V);
        &reload_gage($K,'V') if ${"M$K"};
    }

    &say("$set::lab{lf}(��)�� �����մϴ�",'compose') if !$I->{lf};

    if ($Ui->{gl}) {
        &say("���ۿ��� $Ui->{gl} $set::mny �ʿ��մϴ�",'compose') if $I->{gl} < $Ui->{gl};
        &change_status($I,'gl',-$Ui->{gl});
        &reload_data('gl');
    }

    require "$set::lib_dir/consumption.cgi";
    require "$set::lib_dir/status.cgi";

    foreach $Ii (@{$I->{Bg}}) {
        $i++;
        next if !$Ii;
        # �������� �ʾƵ� ������̸� �����μ� �����
        next if !$F{$i} && $Ii->{eq} ne 'rh' && $Ii->{eq} ne 'sb';
        # ���� üũ
        &reduce_item($I,$Ii,$Ui,'cl');
        # ID üũ
        &reduce_item($I,$Ii,$Ui,'id');
    }

    @CL = grep { $_ } values %{$Ui->{cl}};
    @ID = grep { $_ } values %{$Ui->{id}};

    &say("$Ui->{dt}{nm}(��)�� �����ϱ⿣, ��ᳪ ������ �����մϴ�.",'compose') if @CL || @ID;

    $V = $I->{ij} ? 120 : 100;
    $I->{Gd} ||= 1;

    if (&roll_dice($V) < $Ui->{rl} + $I->{dx} * 3 - ($I->{Gd} - 1) * 10) {
        $Ui->{Im} = &item_image($Ui->{dt});
        &M("$Ui->{Im}$Ui->{dt}{nm} x $Ui->{dt}{qn}(��)�� ��������ϴ�.");
        &happiness_bonus($I);
        &excellent_roll($I,$Ui->{dt}) if $Ui->{db};
        &deluxe_roll($I,$Ui->{dt}) if $Ui->{dt}{cl} eq 'Fd';
        &double_roll($I,$Ui->{dt}) if $Ui->{dt}{cl} eq 'Mt';
    }
    else {
        &M("$Ui->{dt}{nm}�� ������ �����߽��ϴ�.");
        $Ui->{dt}{qn} = 0;
        &change_status($I,'hy',-1,1);
        &health_bonus($I);
        &unexpected_accident($I);
        if ($I->{in} * 3 >= &roll_dice(100) + 80 - $Ui->{rl}) {
            &M("���ۿ� ����� ���� �������� ���ҽ��ϴ�.");
            $Ui->{ex} = 0;
            $I->{DS} = 1;
        }
        $Ui->{ex} &&= int($Ui->{ex} / 2);
    }

    if ($Ui->{ex}) {
        require "$set::lib_dir/experience.cgi";
        &experience($I,$Ui->{ex} * $I->{Gd});
        &reload_data('ex');
    }

    $Ui->{dt}{gd} = $I->{Gd};

    &change_status($I,'bg',$Ui->{dt}{qn} * $Ui->{dt}{wt});

    push(@{$I->{Bg}},$Ui->{dt});

    &reload_gage([@set::gva],'V');

    &inner_HTML;

    &sort_item($I);

    &set_item($I) if !$I->{DS};
    &set_user($I);

    &say($I->{M},'compose','Reload');
}

# Sub Creativity Check #
sub creativity_check {
my  $S = shift;
my  $Si = shift;
my ($K,$V);

    foreach (split(/,/,$Si->{gf})) {
        ($K,$V) = split(/=/);
        return 0 if (!$V && !$S->{Sk}{$K}) ||
                    ($K eq 'sx' && $S->{sx} ne $V) ||
                    ($S->{$K} < $V);
    }
    return 1;
}

# Sub Reduce Item #
sub reduce_item {
my  $S = shift;
my  $Si = shift;
my  $Ui = shift;
my  $V = shift; # cl or id
my ($W,$X,$Y,$Z);

    $X = $Ui->{$V};
    $Y = $Si->{$V};
    $W = $Si->{db} ? 'db' : 'qn';
    if ($Ui->{ss}{$Y}) { # ��üǰ
        $Y = $Ui->{ss}{$Y};
    }
    return if !$X;
    return if !$X->{$Y};
    if ($Si->{$W} >= $X->{$Y}) {
        $Z = $X->{$Y};
        $X->{$Y} = 0;
    }
    else {
        $Z = $Si->{$W};
        $X->{$Y} -= $Si->{$W};
    }
    &grade_check($S,$Si) if $Si->{gd} && $Ui->{ki} && $Ui->{ki} eq $Y;
    &consumption_check($Si,$Z);
}

# Sub Grade Check #
sub grade_check {
my  $S = shift;
my  $Si = shift;

    $S->{Gd} = $Si->{gd} if !$S->{Gd} || $Si->{gd} < $S->{Gd}; # ��� �����ϱ�
}

# Sub Excellent Roll #
sub excellent_roll {
my  $S = shift;
my  $Si = shift;

    if (&roll_dice(100 + $S->{Hy}) <= $set::erb + $S->{st}) {
        $Si->{ql} .= ',Ex';
        $Si->{db} = int($Si->{db} * $set::edu);
        $Si->{bp} = int($Si->{bp} * $set::edu);
        &M("$Si->{nm}(��)�� <span class=Ex>������Ʈǰ</span>�Դϴ�.");
    }
}

# Sub Deluxe Roll #
sub deluxe_roll {
my  $S = shift;
my  $Si = shift;
my  ($K,$V,@L);

    if (&roll_dice(100 + $S->{Hy}) <= $set::erb + $S->{st}) {
        $Si->{ql} .= ',Dx';
        foreach (split(/,/,$Si->{ef})) {
            ($K,$V) = split(/=/);
            $V = int($V * $set::ddu);
            push(@L,join('=',$K,$V));
        }
        $Si->{ef} = join(',',@L);
        $Si->{bp} = int($Si->{bp} * $set::ddu);
        &M("$Si->{nm}(��)�� <span class=Dx>�𷰽�ǰ</span>�Դϴ�.");
    }
}

# Sub Double Roll #
sub double_roll {
my  $S = shift;
my  $Si = shift;

    if (&roll_dice(100 + $S->{Hy}) <= $set::erb + $S->{st}) {
        $Si->{qn} *= 2;
        &M("����� �ھƳ� ������ 2 ��� �����½��ϴ�.");
    }
}

# Sub Unexpected Accident #
sub unexpected_accident {
my  $S = shift;
my  ($V);

    return if $S->{ij};

    $V  = $S->{cn};
    $V *= $set::sUb if $S->{Sk}{Ub};

    if (&roll_dice(100 - $S->{Hl} + $V) <= $set::icp) {
        $V = &roll_dice(4) - 1;
        $V = ('Fr','La','Bn','Pw')[$V];
        &change_condition($S,'ij',$V,1);
        &M("<span class=alert>$set::cnd{$V}[1]</span>(��)�� �����ϴ�.");
        &change_status($S,'hy',-3,1);
    }
}

# --------------------------------------------------- #
1;
