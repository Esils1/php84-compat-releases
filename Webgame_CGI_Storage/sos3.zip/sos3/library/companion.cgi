# --------------------------------------------------- #
# Script of Saga III Companion.cgi Version 3 (1.4)
# Copyright (C) 2005-2007 Missing Link.
# --------------------------------------------------- #

# Sub Companion #
sub companion {
my  $i;
my  $Ip;
my  $M;

    $I = &get_user('I');

    &dead_check($I,'CLOSE');

    &get_companion($I);

    &ride_check;

    &set_code;

    &get_pet($I);

    foreach $Ip (@{$I->{Pt}}) {
        $i++;
        next if !$Ip;
		if ($F{pt} != $i-1) {
            $Ip->{eq} = '';
		}
        elsif ($Ip->{eq} eq 'co') {
            $Ip->{Im} = &item_image($Ip);
            &delete_companion($Ip);
            $M = "$Ip->{Im}$Ip->{Nm}(��)�� ������ �ٴϴ� ���� ���׽��ϴ�.";
        }
        else {
            $Ip->{Im} = &item_image($Ip);
            &say("$Ip->{Im}$Ip->{Nm}(��)�� ������ �ٴ� �� �����ϴ�.",'pet') if $Ip->{cl} eq 'Ls' || $Ip->{cl} eq 'Hr';
            &say("$Ip->{Im}$Ip->{Nm}(��)�� �׾����ϴ�.",'pet') if !$Ip->{hg};
            &say("$Ip->{Im}$Ip->{Nm}(��)�� ���󰡴� ���� �ź��մϴ�.",'pet') if $Ip->{ft} < $set::pcr;
            &set_companion($Ip,'co');
            $M = "$Ip->{Im}$Ip->{Nm}(��)�� ������ �ٴմϴ�.";
        }
    }

    &inner_HTML;

    &sort_pet($I);
    &set_pet($I);
    &set_user($I);
    &say($M,'pet','Set,Reload');
}

# Sub Set Companion #
sub set_companion {
my  $Sp = shift;
my  $V = shift;

    $I->{co} = join('/',$Sp->{Nm},$Sp->{cl},'co',$Sp->{im});

    $Sp->{eq} = $V;
    $Sp->{sp} = '';
    $Sp->{rs} = '';

    &reload_data('pnm',$Sp->{Nm});
    &reload_data('pim','',$Sp->{im});
}

# Sub Delete Companion #
sub delete_companion {
my  $Sp = shift;

    $I->{co} = '';
    $Sp->{eq} = '';

    &reload_data('pnm','');
    &reload_data('pim','','');
}

# Sub Ride Check #
sub ride_check {
    $I->{Co}{Im} = &item_image($I->{Co});
    &say("$I->{Co}{Im}�̹� $I->{Co}{nm}�� Ÿ�� �ֽ��ϴ�.",'pet') if $I->{Co}{tp} eq 'rd';
}

# --------------------------------------------------- #
1;
