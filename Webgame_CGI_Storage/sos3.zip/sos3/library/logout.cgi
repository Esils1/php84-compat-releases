# --------------------------------------------------- #
# Script of Saga III Logout.cgi Version 1
# Copyright (C) 2005 Missing Link.
# --------------------------------------------------- #

# Sub Logout #
sub logout {
    require "$set::lib_dir/top.cgi";
    $I = &get_user('I');
    $I->{li} = 'out';
    &set_user($I);
    &set_code('on');
    &top;
}

# --------------------------------------------------- #
1;
