﻿# --------------------------------------------------- #
# Script of Saga III Aboard.cgi Version 1
# Copyright (C) 2005 Missing Link.
# --------------------------------------------------- #

# Sub Aboard Before #
sub aboard_before {
my  $L;
my  $t1;
my  $checked;

    require "$set::lib_dir/date.cgi";
    require "$set::lib_dir/sailing.cgi";

    $I = &get_user('I');

    &dead_check($I,'CLOSE');

    &get_place($I);

    &spot_check($I,'Hb');

    $L = &get_departure;

    foreach (@$L) {
        &get_ship($I,$_->[0],'checked');
        $I->{Si}{dt} = &departure_time($I->{Si}{dt});
        next if $I->{Si}{nw} ne $I->{pl};
        $t1 .= qq|<tr>|;
        $t1 .= qq|<td rowspan=2 align=center><img src=$set::iim_dir/$I->{Si}{im}><br><input type=radio name=ud class=radio value="$_->[0]"$I->{Si}{Go}></td>|;
        $I->{Si}{nm} .= $I->{Si}{nm} ? '호' : $I->{Si}{tp};
        $t1 .= qq|<td colspan=4>$I->{Si}{nm}</td>|;
        $t1 .= qq|</tr>\n|;
        $t1 .= qq|<tr>|;
        $t1 .= qq|<td>$PL{$I->{Si}{go}}{nm}</td>|;
        $t1 .= qq|<td align=right>$I->{Si}{dt}</td>|;
        $t1 .= qq|<td align=right>$I->{Si}{sp} $set::mny</td>|;
        $t1 .= qq|<td align=right>$I->{Si}{pg}/$I->{Si}{ct}</td>|;
        $t1 .= qq|</tr>\n|;
    }

    &get_code;

    $checked = ' checked' if !$I->{ab};

    &header(CSS=>'sub');
    print <<"    END_OF_HTML";
    <form method=post action=$set::cgi_url>
    <div class=label>승선예약</div>
    <div class=outbox>
    <img src=$set::mim_dir/envHb.gif><br>
    <br>
    <input type=radio name=ud class=radio value="0"$checked> 예약 취소하기<br>
    <table class=outbox border=1>
    <tr><th>&nbsp;</th><th>행선지</th><th>출항시간</th><th>뱃삵</th><th>정원</th></tr>
    $t1
    </table>
    <br>
    <div class=r>$set::but{OK}</div>
    <input type=hidden name=md value="aboard_after">
    <input type=hidden name=id value="$F{id}">
    <input type=hidden name=ps value="$F{ps}">
    <input type=hidden name=xx value="$I->{XX}">
    </div>
    </form>
    END_OF_HTML
    &back_close('harbor');
    &footer;
}

# Sub Aboard After #
sub aboard_after {
my ($V,$X,$L);

    require "$set::lib_dir/navigation.cgi";
    require "$set::lib_dir/sailing.cgi";

    $I = &get_user('I');

    &lock(navigation_lock);

    $V = $F{ud} ? $F{ud}:
         $I->{ab} ? $I->{ab}: 0;

    &say('이미 예약했습니다.','aboard_before') if !$V;
    &say('자신의 배에 승객으로 탈 수 없습니다.','aboard_before') if $F{ud} eq $I->{id};

    # 자신의 배에 항해설정이 되어있는가 체크 #
    if (($I->{Sk}{Sm} || $I->{Sk}{Sn}) && &get_ship($I,$I->{id})) {
        &say('다른 사람의 배에 승선하려면 자기 배의 항해설정을 해제해야 합니다.','aboard_before') if $I->{Si}{go};
    }

    &get_ship($I,$V);

    &say('배를 놓쳤습니다.','aboard_before') if !$I->{Si}{go};

    @{$I->{Si}{Pg}} = grep { $_ ne "$I->{id}\n" } @{$I->{Si}{Pg}};
    $I->{Si}{pg} = @{$I->{Si}{Pg}};

    &say('이미 예약이 꽉 찼습니다.','aboard_before') if $I->{Si}{pg} >= $I->{Si}{ct};

    if ($F{ud}) {
        &say("돈이 부족합니다.",'aboard_before') if $I->{gl} < $I->{Si}{sp};
        &say("일단 예약을 취소해주세요.",'aboard_before') if $I->{ab};
        $I->{ab} = $F{ud};
        push(@{$I->{Si}{Pg}},"$I->{id}\n");
    }
    else {
        $I->{ab} = '';
    }

    &set_code;

    &set_ship($I,$V);

    &unlock(navigation_lock);

    &set_user($I);

    &say('설정 완료','aboard_before');
}

# Sub Find Ship #
sub find_ship {
my  $V = shift;
my  $X;

    @P = &open_dat("$set::sip_dir/$V.cgi");
    $L = shift @P;
    @L = split(/<>/,$L);

    foreach (0 .. $#set::ndt) {
        $X = $set::ndt[$_];
        $I->{Si}{$X} = $L[$_];
    }

    $I->{Si}{pg} = @P;
    $I->{Si}{Pg} = \@P;
    $I->{Si}{Go} = ' checked' if $I->{ab} eq $V;
}

# --------------------------------------------------- #
1;
