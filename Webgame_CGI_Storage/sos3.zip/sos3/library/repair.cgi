# --------------------------------------------------- #
# Script of Saga III Repair.cgi Version 1
# Copyright (C) 2005 Missing Link.
# --------------------------------------------------- #

# Sub Repair Before #
sub repair_before {
my  $i;
my  $Ii;
my  $t1;

    $I = &get_user('I');

    &get_item($I);

    foreach $Ii (@{$I->{Bg}}) {
        $i++;
        next if !$Ii;
		next if !$F{$i};
	    if (!$Ii->{Ql}{Br}) { $t1 .= "$Ii->{nm}(��)�� �������� �ʾҽ��ϴ�.<br>\n" }
	    else {
            &repair_price($Ii);
            $t1 .= qq|<input type=checkbox name=$i class=checkox checked> |;
            $t1 .= &decorate_item($Ii);
        }
	}

    &say("�������� ������ �ּ���.",'bag') if !$t1;

    &get_code;

    &header(CSS=>'sub');
    print <<"    END_OF_HTML";
    <div class=label>�����ϱ�</div>
    <form method=post action=$set::cgi_url>
    <div class=outbox>
    <tt>�����Ϸ��� ������ ���� ����� �ʿ��մϴ�.</tt><br>
    <br>
    $t1
    <div class=r><tt>$set::lab{gl}��$I->{gl} $set::mny</tt></div>
    <br>
    <div class=r>$set::but{OK}</div>
    <input type=hidden name=md value="repair_after">
    <input type=hidden name=id value="$F{id}">
    <input type=hidden name=ps value="$F{ps}">
    <input type=hidden name=xx value="$I->{XX}">
    </div>
    </form>
    END_OF_HTML
    &back_close('bag');
    &footer;
}

# Sub Repair After #
sub repair_after {
my  $i;
my  $Ii;

    $I = &get_user('I');

    &get_item($I);

    foreach $Ii (@{$I->{Bg}}) {
        $i++;
        next if !$Ii;
        next if !$F{$i};
        &repair_price($Ii);
        &M("$Ii->{nm}�������� �����մϴ�.") && next if $Ii->{Sp} > $I->{gl};
        &change_status($I,'gl',-$Ii->{Sp});
        $Ii->{ql} = join(',',grep { $_ ne 'Br' } keys %{$Ii->{Ql}});
        &M("$Ii->{nm}(��)�� �����߽��ϴ�.");
	}

    &set_code;

    &set_item($I);
    &set_user($I);

    &reload_data('gl');

    &inner_HTML;

    &say($I->{M},'bag','Reload');
}

# Sub Repair Price #
sub repair_price {
my  $Si = shift;

    $Si->{Sp}  = $Si->{bp};
    $Si->{Sp} *= 1 + ($Si->{gd} - 1) / 5 if $Si->{gd};
    $Si->{Sp} *= 1.2 if $Si->{Ql}{Ex};
    $Si->{Sp} *= 1 + $Si->{pl} / 5 if $Si->{pl};
    $Si->{Sp} *= &repair_bonus($Si);
    $Si->{Sp}  = int($Si->{Sp});
}

# Sub Repair Bonus #
sub repair_bonus {
my  $Si = shift;

    if (($I->{Sk}{Rb} && $Si->{cl} =~ /(Sw|Kt|Sp|Ax|Cl|Hm|Ar|Bt)/) ||
        ($I->{Sk}{Rs} && $Si->{cl} =~ /(Rg|Ac)/) ||
        ($I->{Sk}{Rc} && $Si->{cl} =~ /(Sh|Wn|Bo|Cl)/) ||
        ($I->{Sk}{Rt} && $Si->{cl} =~ /(Ht|Ds|Bt)/)) {
        return $set::srb;
    }
    return 1;
}

# --------------------------------------------------- #
1;
