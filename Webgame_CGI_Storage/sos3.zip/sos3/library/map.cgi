# --------------------------------------------------- #
# Script of Saga III Map.cgi Version 1
# Copyright (C) 2005 Missing Link.
# --------------------------------------------------- #

# Sub Map #
sub map {
my  $V;

    if ($F{sx}) {
        $V = qq|<img src=$set::mim_dir/$F{sx}.gif style="position:absolute;top:$F{y};left:$F{x}">|;
    }
    &header(CSS=>'map',JavaScript=>'Set,MapProgram,MapInformation,MapData',Body=>' onLoad="SetMap()"');
    print qq|<div id=box class=map style="visibility:hidden"></div>\n|;
    print qq|<span id=map></span>\n|;
    print $V;
    &footer;
}

# --------------------------------------------------- #
1;
