# --------------------------------------------------- #
# Script of Saga III Break.cgi Version 1
# Copyright (C) 2005 Missing Link.
# --------------------------------------------------- #

# Break Check #
sub break_check {
my  $S = shift;
my  $e = shift;
my  ($E,$Ii);

    $E = ucfirst $e;

    &get_equipment($I,$E);

    return 0 if !$S->{$E}{db};

    if (&roll_dice($S->{$E}{db}) == 1) {
        &M("$S->{$E}{nm}(��)�� ���������ϴ�.");
        foreach $Ii (@{$I->{Bg}}) {
            if ($Ii->{eq} eq $E) {
                if ($S->{$E}{ql}{Rp}) {
                    $Ii->{ql} .= ',Br';
                    &M("$S->{$E}{nm}(��)�� ������ �ʿ��մϴ�.");
                }
                else {
                    $I->{bg} -= $Ii->{wt};
                    $Ii->{qn} = 0;
                }
                last;
            }
        }
        $S->{$e} = '';
        undef $S->{$E};
        return 1;
    }
    return 0;
}

# --------------------------------------------------- #
1;
