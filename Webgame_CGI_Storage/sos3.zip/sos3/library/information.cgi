# --------------------------------------------------- #
# Script of Saga III Information.cgi Version 1
# Copyright (C) 2005 Missing Link.
# --------------------------------------------------- #

# Sub Total Players #
sub total_players {
my  $L;

    $L = &get_allusersID();
    &write_dat("$set::dat_dir/totalplayers.cgi",$L);
}

# --------------------------------------------------- #
1;
