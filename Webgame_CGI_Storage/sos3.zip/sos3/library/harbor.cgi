# --------------------------------------------------- #
# Script of Saga III Harbor.cgi Version 1
# Copyright (C) 2005 Missing Link.
# --------------------------------------------------- #

# Sub Harbor #
sub harbor {
my  $do;
my ($t1,$t2);
my  $checked;

    $I = &get_user('I');

    &dead_check($I,'CLOSE');

    &get_place($I);

    &spot_check($I,'Hb');

    $checked = ' checked';

    # ���� �ð� �ɼ�
    for (1..$set::ydo) { $do .= qq|<option value="$_">$_�ð�</option>| }

    &get_item($I);

    foreach $Ii (@{$I->{Bg}}) {
        $i++;
        next if !$Ii;
        if ($Ii->{cl} eq 'Fr') {
            $t1 .= qq|<input type=radio name=ft class=radio value="$i"$checked> |;
            $t1 .= &item_image($Ii);
            $t1 .= $Ii->{nm};
            $t1 .= "<br>\n";
            $checked = '';
        }
    }

    if ($I->{Sk}{Sm}) {
        $t2 = qq|<input type=radio name=md class=radio value="navigation_before">���� ����<br>\n|;
    }

    &get_code;

    &header(CSS=>'sub');
    print <<"    END_OF_HTML";
    <form method=post action=$set::cgi_url>
    <div class=label>$I->{Sp}{Hb}{nm}</div>
    <div class=outbox>
    <img src=$set::mim_dir/envHb.gif><br>
    <br>
    <input type=radio name=md class=radio value="aboard_before" checked>�¼� �����ϱ�<br>
    $t2
    <input type=radio name=md class=radio value="fishing">�����ϱ�<br>
    <div class=words>$t1</div>
    <div class=r><select name=do class=select>$do</select></div>
    <br>
    <div class=r><tt>���� 1�ð��� $set::lab{vt}�� $set::yvt �Һ��մϴ�.</tt></div>
    <div class=r><tt>������ ����: $I->{bg}/$I->{Mbg} $set::wgt</tt></div>
    <br>
    <div class=r>$set::but{OK} $set::but{CLOSE}</div>
    <input type=hidden name=id value="$F{id}">
    <input type=hidden name=ps value="$F{ps}">
    <input type=hidden name=fl value="se">
    <input type=hidden name=xx value="$I->{XX}">
    </div>
    </form>
    END_OF_HTML
    &footer;
}

# --------------------------------------------------- #
1;
