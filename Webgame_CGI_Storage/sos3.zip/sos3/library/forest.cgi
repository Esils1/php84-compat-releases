# --------------------------------------------------- #
# Script of Saga III Forest.cgi Version 2 (1.4)
# Copyright (C) 2005-2007 Missing Link.
# --------------------------------------------------- #

# Sub Forest #
sub forest {
my ($do,$t1);

    $I = &get_user('I');

    &dead_check($I,'CLOSE');

    &get_place($I);

    &spot_check($I,'Fr');

    # �ð� �ɼ�
    for (1..$set::wdo) { $do .= qq|<option value="$_">$_�ð�</option>| }

    $t1 = '�����ɱ�'; # ���ڿ��� ��å
    $t1 = qq|<option value="capture_before">$t1</option>\n| if $I->{Sk}{Cc};

    &get_code;

    &header(CSS=>'sub',JavaScript=>'GetView');
    print <<"    END_OF_HTML";
    <form method=post action=$set::cgi_url>
    <div class=label>$I->{Sp}{Fr}{nm}</div>
    <div class=outbox>
    <img src=$set::mim_dir/envFr.gif><br>
    <br>
    <div class=r>
    <select id=do style="visibility:visible" name=do class=select>$do</select>
    <select id=mode name=md class=select onChange="HideObject('do','mode','capture_before','reverse');">
    <option value="hunting">����ϱ�</option>
    $t1
    <option value="lumberjacking">�����ϱ�</option>
    <option value="berry">����ä��</option>
    <option value="herb">����ä��</option>
    </select>
    </div>
    <br>
    <div class=r><tt>������ ���� : $I->{bg}/$I->{Mbg} $set::wgt</tt><br></div>
    <br>
    <div class=r><tt>$set::lab{vt}�� $set::wvt �Һ��մϴ�.</tt></div>
    <br>
    <div class=r>$set::but{OK} $set::but{CLOSE}</div>
    <input type=hidden name=id value="$F{id}">
    <input type=hidden name=ps value="$F{ps}">
    <input type=hidden name=xx value="$I->{XX}">
    <input type=hidden name=fl value="forest">
    </div>
    </form>
    END_OF_HTML
    &footer;
}

# --------------------------------------------------- #
1;
