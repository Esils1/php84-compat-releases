# --------------------------------------------------- #
# Script of Saga III Status.cgi Version 3 (1.3)
# Copyright (C) 2005-2007 Missing Link.
# --------------------------------------------------- #

# Sub Health Bonus #
sub health_bonus {
my  $S = shift;

    $S->{Hl} = $S->{Mhl} - $S->{hl} - 10;
    $S->{Hl} =  0 if $S->{Hl} < 0;
    $S->{Hl} = -5 if $S->{hl} == $S->{Mhl};
}

# Sub Happiness Bonus #
sub happiness_bonus {
my  $S = shift;

    $S->{Hy} = $S->{Mhy} - $S->{hy} - 10;
    $S->{Hy} =  0 if $S->{Hy} < 0;
    $S->{Hy} = -5 if $S->{hy} == $S->{Mhy};
}

# Sub Get Appearance #
sub get_appearance {
my  $S = shift;

    &get_equipment($S,'bd');
    $S->{Ap}  = $S->{ap};
    $S->{Ap} += $S->{Bd}{ef} if $S->{Bd}{cl} eq 'Ds';
    $S->{Ap} += $set::grd[$S->{Bd}{gd}] if $S->{Bd}{cl} eq 'Ds';
    $S->{Ap} -= $S->{Ap} <= 30 ? 30:
                $S->{Ap} <= 50 ? $S->{Ap}:
                                 50;
    $S->{Ap}  = $S->{Ap} / 100 * -1 + 1;
}

# --------------------------------------------------- #
1;
