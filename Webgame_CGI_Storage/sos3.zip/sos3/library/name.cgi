# --------------------------------------------------- #
# Script of Saga III Name.cgi Version 1
# Copyright (C) 2005 Missing Link.
# --------------------------------------------------- #

# Sub Name Before #
sub name_before {
my  $i;
my  $Ii;
my  $t1;

    $I = &get_user('I');
    &get_pet($I);

    foreach $Ip (@{$I->{Pt}}) {
        $i++;
        next if !$Ip;
		next if !$F{$i};
	    if ($Ip->{nn} && !$set::rnp) { $t1 .= "$Ip->{Nm}: �ѹ� ���� �̸��� ������ �� �����ϴ�.<br>\n" }
	    else {
            $t1 .= qq|<input type=textbox name=$i class=textbox size=20 value="$Ip->{nn}"> |;
            $t1 .= &item_image($Ip);
            $t1 .= "$Ip->{nm}<br>\n";
		}
	}

    &say("�������ּ���.",'pet') if !$t1;

    &get_code;

    &header(CSS=>'sub');
    print <<"    END_OF_HTML";
    <div class=label>�̸� ����</div>
    <form method=post action=$set::cgi_url>
    <div class=outbox>
    <tt>�ִ� ���ڼ�: $set::pnx��</tt><br>
    <br>
    $t1
    <br>
    <div class=r>$set::but{OK} $set::but{CLOSE}</div>
    <input type=hidden name=md value="name_after">
    <input type=hidden name=id value="$F{id}">
    <input type=hidden name=ps value="$F{ps}">
    <input type=hidden name=xx value="$I->{XX}">
    </div>
    </form>
    END_OF_HTML
    &footer;
}

# Sub Name After #
sub name_after {
my  $i;
my  $Ii;

    $I = &get_user('I');
    &set_code;

    &get_pet($I);

    foreach $Ip (@{$I->{Pt}}) {
        $i++;
        next if !$Ip;
		if ($F{$i}) {
            if ($F{$i} =~ /\//) { &M("$Ip->{nm}: �̸��� /�� �� �� �����ϴ�.") }
            elsif (length $F{$i} > $set::pnx * 2) { &M("$Ip->{nm}: �̸��� �ѱ� ���� $set::pnx�ڱ��� �����մϴ�.") }
            else {
                $Ip->{nn} = $F{$i};
                &M("$Ip->{nm}: $F{$i}(��)��� �̸����� �ٿ�����ϴ�.");
                if ($Ip->{eq}) {
                    &get_companion($I);
                    $I->{co} = "$F{$i}/$Ip->{cl}/$I->{Co}{tp}/$Ip->{im}";
                    &reload_data('pnm',$F{$i});
                    &inner_HTML;
                    &set_user($I);
                }
            }
		}
	}

    &set_pet($I);
    &say($I->{M},'pet','Reload');

}
# --------------------------------------------------- #
1;
