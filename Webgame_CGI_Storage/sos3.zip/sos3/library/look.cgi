# --------------------------------------------------- #
# Script of Saga III Look.cgi Version 2 (1.4)
# Copyright (C) 2005-2007 Missing Link.
# --------------------------------------------------- #

# Sub Look #
sub look {
my  $i;
my  $Ii;

    require "$set::dat_dir/itemdictionary.cgi";

    $I = &get_user('I');
    &get_item($I);

    foreach $Ii (@{$I->{Bg}}) {
        $i++;
		next if !$F{$i};
		&M("$set::lab{vt}�� �����մϴ�.") && last if !$I->{vt};
        $Ii->{Im} = &item_image($Ii);
		&M("$Ii->{Im}$Ii->{nm}<br>");
        foreach ($Ii->{cl},split(/,/,$Ii->{ql})) {
    		&M("$DIC{$_}",1);
		}

        if (!$Ii->{Ql}{El} && $Ii->{cl} ne 'Mm') {
            &M("�������� $Ii->{db}�Դϴ�.",1) if $Ii->{db};
            &M("1�� ����ϸ� �������ϴ�.",1) if !$Ii->{db};
        }
        &M("����� $Ii->{gd}�Դϴ�.",1) if $Ii->{gd};
        if ($Ii->{ef} && $Ii->{cl} !~ /(Gd|Gm|Tp)/) {
            if ($Ii->{cl} eq 'Fd') {
                &nutritive_value($Ii);
            }
            else {
                &get_effect($Ii);
            }
            &M("ȿ���� $Ii->{Ef}�Դϴ�.",1);
        }
        &change_status($I,'vt',-1,1);
        &M("<hr>",1);
	}

    &set_code;

    &reload_gage('vt','V');
    &inner_HTML;

    &set_user($I);

    &say($I->{M},'bag','Reload');
}

# Sub Nutritive Value #
sub nutritive_value {
my  $Si = shift;

    $Si->{Ef} = $Si->{ef};
    $Si->{Ef} =~ s/lf/LIF/;
    $Si->{Ef} =~ s/vt/VIT/;
    $Si->{Ef} =~ s/hl/HEA/;
    $Si->{Ef} =~ s/ap/APP/;
    $Si->{Ef} =~ s/hy/HAP/;
    $Si->{Ef} =~ s/,/��/;
    $Si->{Ef}  = "<span class=effect>$Si->{Ef}</span>";
}

# --------------------------------------------------- #
1;
