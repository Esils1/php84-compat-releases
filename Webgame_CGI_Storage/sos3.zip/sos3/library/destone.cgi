# --------------------------------------------------- #
# Script of Saga III Destone.cgi Version 1
# Copyright (C) 2005 Missing Link.
# --------------------------------------------------- #

# Sub Destone #
sub destone {
my  $Ii;
my  $F;

    require "$set::lib_dir/partner.cgi";
    require "$set::lib_dir/experience.cgi";
    require "$set::lib_dir/myrecord.cgi";

    $I = &get_user('I');
    &lock($F{ud});
    $U = &get_user('U');
    &login_check($U);
    &place_check($U);

    &get_item($I);

    foreach $Ii (@{$I->{Bg}}) {
        next if !$Ii->{Ql}{St};

        $Ii->{Im} = &item_image($Ii);

        &M("$Ii->{Im}$U->{nm}�� $set::cnd{St}[1]�� Ǯ�����ϴ�.");
        &change_condition($U,'da');

        $Ii->{qn}--;

        &change_status($I,'bg',-$Ii->{wt});
        &experience($I,$set::dse * $I->{lv} + $I->{in});

        $F = 1;
        last;
    }

    &partner('������',"$set::cnd{St}[1]�� Ǯ �� �ִ� �������� �����ϴ�.") if !$F;

    &set_code;

    &set_item($I);

    &set_user($I);
    &set_user($U);

    &set_record("$I->{nm}���� ��ȭ�� Ǯ�����ϴ�.");

    &unlock($F{ud});

    &reload_data('ex');

    &inner_HTML;

    &partner('',$I->{M},'Reload');
}

# --------------------------------------------------- #
1;
