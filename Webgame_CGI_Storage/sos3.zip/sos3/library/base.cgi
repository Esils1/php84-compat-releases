# --------------------------------------------------- #
# Script of Saga III Base.cgi Version 4 (1.4)
# Copyright (C) 2005-2007 Missing Link.
# --------------------------------------------------- #

# Sub Header #
sub header {
# Method: CSS=>filename,JavaScript=>[filename1,filename2],Body=>' tag',GetTag=> true or false
my  %V = @_;
my  $t1;

    $t1  = qq|Content-type: text/html\n\n| if !$V{GetTag};
    $t1 .= qq|<!--nobanner-->\n| if $F{md};
    $t1 .= qq|<html>\n|;
    $t1 .= qq|<head>\n|;
    $t1 .= qq|<meta http-equiv="Content-Type" content="text/html; charset=euc-kr">\n|;
    $t1 .= qq|<title>$set::tit</title>\n|;
    $t1 .= qq|<link rel="stylesheet" href="sos3.css" type="text/css">\n|;
    $t1 .= qq|<link rel="stylesheet" href="$V{CSS}.css" type="text/css">\n|;
    foreach (split(/,/,$V{JavaScript})) {
        $t1 .= qq|<script language="JavaScript" src="$set::jav_dir/$_.js"></script>\n|;
    }
    $t1 .= qq|</head>\n|;
    $t1 .= qq|<body$V{Body}>\n|;
    $headflag = 1;
    if ($V{GetTag}) {
        require "$set::lib_dir/date.cgi";
        $t1 .= qq|<div align=right><tt>Update:|;
        $t1 .= &get_date;
        $t1 .= qq|</tt></div>|;
        return $t1;
    }
    else {
        print $t1;
    }
}

# Sub Footer #
sub footer {
# Method: GetTag=> true or false
my  %V = @_;
my  $t1;

    $t1  = qq|</body>\n|;
    $t1 .= qq|</html>\n|;
    if ($V{GetTag}) { return $t1 }
    else { print $t1 }
}

# Sub Transfer to HTML
sub transfer_HTML {
my  $V = shift;

    print qq|Content-type: text/html\n\n|;
    print qq|<script language="JavaScript">\n|;
    print qq|    parent.location.href = "$V";\n|;
    print qq|</script>\n|;
    exit;
}

# Sub Get All Users ID #
sub get_allusersID {
my  $F = shift;
my  @L;

    $F = $F ? $set::npc_dir : $set::Udt_dir;

    opendir(DIR,$F) || &error("get_allusersID Error! Type:$F");
    @L = grep s/\.cgi//i,readdir(DIR);
    closedir(DIR);
    return @L;
}

# Sub Get User #
sub get_user {
my  $W = shift; # value = 'I' or 'U' or 'A' or 'B'
my  $T = shift;
my  $F = shift;
my ($L,@L,$S,%SK,$dir,$id);

    $id = $T ? $T:
          $W eq 'I' ? $F{id}:
          $W eq 'U' ? $F{ud}: '';

    &error('userdata:ID Error') if $id eq '';
    $dir = index($id,'_') ? $set::Udt_dir
                          : $set::npc_dir;

    unless (-e "$dir") { &error("���� ���丮�� �������� �ʽ��ϴ�") }
    unless (-e "$dir/$id.cgi") {
        return 0 if $T;
        &error("�߸��� ID�Դϴ�: $id");
    }

    ($L) = &open_dat("$dir/$id.cgi");

    chomp $L;

    if (!$L) { &error("�߸��� ID�Դϴ�: $id") }

    @L = split(/<>/,$L);

    foreach (0 .. $#set::udt) {
        $S->{$set::udt[$_]} = $L[$_];
    }

    &error("����Ÿ�� �սǵƽ��ϴ�: $id") if !$S->{id};

    return $S if $W eq 'A';

    map { $S->{Cd}{$_} = $set::cnd{$_}[1] } split(/,/,$S->{cd});

    $S->{Da} = $set::cnd{$S->{da}}[1];
    $S->{Ij} = $set::cnd{$S->{ij}}[1];

    &password_check($S) if $W eq 'I';

    &say('�α������ּ���','') if $W eq 'I' && !$F && $S->{li} eq 'out';

    map { $S->{Sk}{$_} = 1 } split(/,/,$S->{sk});

    foreach (@set::sdt,@set::gva) {
        ($S->{$_},$S->{"M$_"}) = split(/\//,$S->{$_},2);
    }

    $S;
}

# Set User #
sub set_user {
my  $S = shift;
my (@L,$K,$V);

    if (!$S->{id}) { &error("ID�� ã�� �� �����ϴ�") }

    while (($K,$V) = each %{$S->{Cd}}) {
        next if $K eq 'in';
        push(@L,$K) if $V;
    }
    $S->{cd} = join(',',@L);

    undef @L;

    $V = index($S->{id},'_') ? $set::Udt_dir
                             : $set::npc_dir;

    foreach (@set::sdt,@set::gva) {
        $S->{$_} = join('/',$S->{$_},$S->{"M$_"});
    }

    foreach (0 .. $#set::udt) {
        $L[$_] = $S->{$set::udt[$_]};
    }

    &write_dat("$V/$S->{id}.cgi",join('<>',@L));
}

# Sub Change Status #
sub change_status {
my  $S = shift;
my  $T = shift; # ���� ���
my  $V = shift; # ������
my  $F = shift; # true -> �޽��� ǥ��
my  $X = shift; # Max ġ�� �� ���� ���
my ($Y,$Z);

    $S->{$T} += $V;
    $Y = $T eq 'hl' ? 'Mn':
         $T eq 'ap' ? 'Dt':
         $T eq 'hy' ? 'En':
                        '';

    if ($S->{$T} <= 0) {
        $S->{$T} = 0;
        if ($Y) {
            &change_condition($S,'cd',$Y,1);
            $Z = "$set::cnd{$Y}[1]�� �ƽ��ϴ�.";
        }
    }
    elsif ($S->{"M$T"} && $S->{$T} >= $S->{"M$T"} && !$X) {
        $S->{$T} = $S->{"M$T"};
        if ($Y && $S->{Cd}{$Y}) {
            &change_condition($S,'cd',$Y);
            $Z = "$set::cnd{$Y}[1]�� �ƽ��ϴ�.";
        }
    }
    elsif ($X && $S->{$T} > $X) {
        $S->{$T} = $X;
    }

    return if !$F;

    if ($V > 0) {
        &M("<span class=up>$set::lab{$T} <span class=alert>$V</span>����</span>");
    }
    else {
        $V = abs($V);
        &M("<span class=down>$set::lab{$T} <span class=alert>$V</span>����</span>");
    }

    &M("<img src=$set::mim_dir/redcross.gif> <span class=sick>$Z</span>") if $Z;
}

# Sub Change Condition #
sub change_condition {
my  $S = shift;
my  $T = shift; # da,ij,cd
my  $V = shift; # ���� ���
my  $F = shift; # true -> �߰�, false -> ����

    if ($F) {
        if ($T eq 'cd') {
            $S->{Cd}{$V} = $set::cnd{$V}[1] if $V;
        }
        else {
            $S->{$T} = $V;
        }
    }
    else {
        if ($T eq 'cd') {
            undef $S->{Cd}{$V} if $V;
        }
        elsif ($T eq 'ij') {
            undef $S->{ij};
        }
        else {
            $S->{da} = 'Av';
            $S->{Da} = $set::cnd{$S->{da}}[1];
            $S->{lf} = 1;
        	&reload_gage('lf','V');
        }
    }

    return if $S->{id} ne $F{id};

    &condition_initial($S,$T,1);
}

# Sub Condition_initial #
sub condition_initial {
my  $S = shift;
my  $T = shift; # da,ij,cd
my  $F = shift; # true -> reload
my (@L,$K,$V);

    if ($T eq 'da') {
        $S->{Da}{in} = $set::cnd{$S->{da}}[0];
        $V = $set::cnd{$S->{da}}[1];
    }
    elsif ($T eq 'ij') {
        $V = $S->{Ij}{in} = $set::cnd{$S->{ij}}[0];
        undef $S->{ij} if !$V;
    }
    else {
        while (($K,$V) = each %{$S->{Cd}}) {
            push(@L,$set::cnd{$K}[0]) if $V;
        }
        @L = sort @L;
        $V = $S->{Cd}{in} = join('��',@L);
        undef $S->{cd} if !$V;
    }

    return if !$F;

	&reload_data($T,$V);
}

# Sub Get Equipment #
sub get_equipment {
my  $S = shift;
my  $E = shift;
my  @L;

    @L = split(/\//,$S->{$E});
    $E = ucfirst $E;
    $S->{$E}{nm} = $L[0]; # Name
    $S->{$E}{cl} = $L[1]; # Class
    map { $S->{$E}{ql}{$_} = 1 } split(/,/,$L[2]); # Quality
    $S->{$E}{ef} = $L[3]; # Effect
    $S->{$E}{db} = $L[4]; # Durability
    $S->{$E}{im} = $L[5]; # Image
    $S->{$E}{gd} = $L[6]; # Grade
    $S->{$E}{pl} = $L[7]; # Plus
    $S->{$E}{cr} = $L[8]; # Creator
    $S->{$E}{Im} = &item_image($S->{$E}); # Image with Tag
}

# Sub Get Effect #
sub get_effect {
my  $Si = shift;
my  $T = shift;

    $Si->{Ef} .= $Si->{cl} eq 'Wn' ? " $Si->{ef}��":
                 $Si->{cl} eq 'Sh' ? " $Si->{ef}��":
                 $Si->{cl} eq 'Hl' ? " $Si->{ef}��":
                 $Si->{cl} eq 'Ar' ? " $Si->{ef}":
                 $Si->{cl} eq 'Dr' ? " $set::lab{ap} +$Si->{ef}":
                 $Si->{ef} ? " $Si->{ef}" : '';
    $Si->{Ef}  = "<span class=effect>$Si->{Ef}</span>" if !$T;
    $Si->{Ef}  = "+$Si->{pl}" . $Si->{Ef} if $Si->{pl};
}

# Sub Get Companion #
sub get_companion {
my  $S = shift;
my  @L;

    @L = split(/\//,$S->{co});
    $S->{Co}{nm} = $L[0]; # Name
    $S->{Co}{cl} = $L[1]; # Class
    $S->{Co}{tp} = $L[2]; # Type
    $S->{Co}{im} = $L[3]; # Image
}

# Sub Get Quality #
sub get_quality {
my  $Si = shift;

    map { $Si->{Ql}{$_} = 1 } split(/,/,$Si->{ql});
}

# Sub Get Place #
sub get_place {
my  $S = shift;

    require "$set::dat_dir/place.cgi";
    $S->{Pl} = \%{$PL{$S->{pl}}};
    $S->{Sp} = \%SP;
    map { $S->{Pl}{ev}{$_} = $SP{$_}{nm} } split(/,/,$S->{Pl}{ev});
    $S->{Pl}{tf} = [split(/,/,$S->{Pl}{tf})];
}

# Sub Get Kingdom #
sub get_kingdom {
my  $S = shift;
my  $V;

    require "$set::dat_dir/kingdom.cgi";
    $V = $KG{$S->{Pl}{kg}};
    $S->{Kg}{nm} = $V->{nm};
    $S->{Kg}{cp} = $V->{cp};
}

# Sub Get Resident #
sub get_resident {
my  $S = shift;

    @{$S->{Pp}} = map { chomp $_; $_ } &open_dat("$set::plc_dir/$S->{pl}.cgi");
}

# Sub Get Bonus #
sub get_bonus {
my  $S = shift;
my  $V = shift;
my  $X = shift;

    $X ||= $set::spn;
    $S->{bonus} = $S->{Sk}{$V} ? 1 : $X;
}

# Sub Password Check #
sub password_check {
my  $S = shift;

    &get_crypt($F{ps},$S->{ps},$set::crp) || &error('��й�ȣ�� Ʋ���ϴ�');
}

# Sub Login Check #
sub login_check {
my  $S = shift;
my  $T = shift; # value = 'noerror'

    unless (index($S->{id},'_')) { return 0 }
    if ($S->{li} eq 'out')       { return 0 }
    if (time < $set::lgi + (stat("$set::Ucd_dir/$S->{id}.cgi"))[9]) {
		if ($T eq 'noerror') { return 1 }
        &error("$S->{nm}���� ���� �������Դϴ�");
    }
    return 0;
}

# Sub Place Check #
sub place_check {
my  $S = shift;

    &error('���� �� ���� �����ϴ�') if $I->{pl} ne $S->{pl};
}

# Sub Spot Check #
sub spot_check {
my  $S = shift;
my  $V = shift;
my  $F = shift;

    &say("$S->{Pl}{nm}�� $S->{Sp}{$V}{nm}(��)�� �����ϴ�",'CLOSE') if !$S->{Pl}{ev}{$V};
}

# Sub Dead Check #
sub dead_check {
my  $S = shift;
my  $T = shift;

    return if $S->{da} ne 'Dd' && $S->{da} ne 'St';

    &partner('',"$S->{nm}��$S->{Da}���ƪ��ު�") if $T eq 'partner';
    &say("$S->{nm}��$S->{Da}���ƪ��ު�",$T); #����
}

# Sub Compulsory Check #
sub compulsory_check {
# ����: ��� �����ϴµ� �ʿ��� �ɷ�ġ�� üũ
my  $S = shift;
my  $Si = shift;
my  $M = shift;
my  ($K,$V);

    foreach (split(/,/,$Si->{cp})) {
        ($K,$V) = split(/=/);
        if (!$V && !$S->{Sk}{$K}) {
            &M("$Si->{nm}(��)�� $M�Ϸ��� $SK{$K} ����� �ʿ��մϴ�.") && return 0;
        }
        elsif ($K eq 'sx' && $S->{sx} ne $V) {
            &M("$Si->{nm}(��)��<img src=$set::mim_dir/$K.gif>�����Դϴ�.") && return 0;
        }
        elsif ($S->{$K} < $V) {
            &M("$Si->{nm}(��)�� $M�Ϸ��� $set::lab{$K}(��)�� $V �ʿ��մϴ�.") && return 0;
        }
    }
    return 1;
}

# Sub Item Class Check #
sub item_class_check {
my  $Si = shift;

    return 'M' if $Si->{cl} =~ /(Fd|Mt|Ig|Pi|Wd|Lt|Ct|Jw)/;
}

# Sub Get Item #
sub get_item {
my  $S = shift;
my  $T = shift;
my  ($V,$i,$j,@L,@K);

    $V = $T == 1 ? "$set::bmk_dir/$I->{Pl}{bm}":
         $T == 2 ? "$set::Uop_dir/$S->{id}.cgi":
         $T == 3 ? "$set::Ubk_dir/$S->{id}.cgi":
                   "$set::Uit_dir/$S->{id}.cgi";

    @L = map { chomp $_; [split(/<>/)] } &open_dat($V);

    $V = \@set::idt;

    foreach $i (0 .. $#L) {
        foreach $j (0 .. $#$V) {
            $K[$i]{$V->[$j]} = $L[$i][$j];
        }
        map { $K[$i]{Ql}{$_} = 1 } split(/,/,$K[$i]{ql});
    }

    $S->{Bg} = [@K];
}

# Sub Set Item #
sub set_item {
my  $S = shift;
my  $T = shift;
my  ($V,@L);

    $V = \@set::idt;

    foreach $i (0 .. $#{$S->{Bg}}) {
        next if !$S->{Bg}[$i]{qn};
        foreach $j (0 .. $#$V) {
            $L[$i][$j] = $S->{Bg}[$i]{$V->[$j]};
        }
    }

    @L = map { join('<>',@$_,"\n") } grep(@$_,@L);

    $V = $T == 1 ? "$set::bmk_dir/$I->{Pl}{bm}":
         $T == 2 ? "$set::Uop_dir/$S->{id}.cgi":
         $T == 3 ? "$set::Ubk_dir/$S->{id}.cgi":
                   "$set::Uit_dir/$S->{id}.cgi";

    &write_dat($V,@L);
}

# Sub Get Pet #
sub get_pet {
my  $S = shift;
my  ($V,$i,$j,@L,@K);

    $V = "$set::Upt_dir/$S->{id}.cgi";

    @L = map { chomp $_; [split(/<>/)] } &open_dat($V);

    $V = \@set::pdt;

    foreach $i (0 .. $#L) {
        foreach $j (0 .. $#$V) {
            $K[$i]{$V->[$j]} = $L[$i][$j];
        }
        map { $K[$i]{Ql}{$_} = 1 } split(/,/,$K[$i]{ql});
        $K[$i]{Nm} = $K[$i]{nn} ? $K[$i]{nn} : $K[$i]{nm};
    }

    $S->{Pt} = [@K] if @K;
}

# Sub Set Pet #
sub set_pet {
my  $S = shift;
my  ($V,@L);

    $V = \@set::pdt;

    foreach $i (0 .. $#{$S->{Pt}}) {
        next if !$S->{Pt}[$i]{id};
        foreach $j (0 .. $#$V) {
            $L[$i][$j] = $S->{Pt}[$i]{$V->[$j]};
        }
    }

    @L = map { join('<>',@$_,"\n") } grep(@$_,@L);

    &write_dat("$set::Upt_dir/$S->{id}.cgi",@L);
}

# Sub Get Words #
sub get_words {
my  $S = shift;
my  ($i,@WD);

    @WD = &open_dat("$set::Uwd_dir/$S->{id}.cgi");
    @WD = split(/<>/,$WD[0]);
    for (0..$#WD) {
        $i = $_ + 2;
        $S->{"w$i"} = $WD[$_];
    }
}

# Sub Talk Bubble #
sub talk_bubble {
my  $V = shift;
my  $T = shift;

    $V || return '';
    $V = qq|<span style="color:$T">$V</span>|;
    $set::twd || return "<p class=outbox>$V</p>\n";
    return "<div class=s1><div class=s5><div class=s3><div class=s2>$V</div></div><div class=s4></div></div></div>\n";
}

# Sub Decorate Item #
sub decorate_item {
my  $Si = shift;
my  $T = shift; # Blackmarket = 1
my ($V,$W,$X,$Y,$Z);

    $X = $I->{Ap} ? $I->{Ap} : 1;
    $W = $Si->{Qn} ne '' ? $Si->{Qn} : $Si->{qn};
    $Y = $Si->{Sp} ? $Si->{Sp} : $Si->{sp};
    $Z = $Si->{wt} if $T;
    $Z ||= $Si->{wt} * $W;
    $Z ||= $Si->{sl};
    $Z = 0 if $Si->{cl} eq 'Cu';

    $V = $Si->{Nm} ? $Si->{Nm} : $Si->{nm};
    $V .= "+$Si->{pl}" if $Si->{pl};
    $V = "<span class=equip>$V</span>" if $Si->{eq};
    $V = "<span class=i$Si->{gd}>$V</span>" if $Si->{gd};
    $V = "<span class=Ex>Ex</span>" . $V if $Si->{Ql}{Ex};
    $V = "<span class=Dx>Dx</span>" . $V if $Si->{Ql}{Dx};
    $V = "<span class=broken>�ջ��</span>".$V if $Si->{Ql}{Br};
    $V = "<span class=broken>�ν���</span>".$V if $Si->{hg} eq 0;
    $V = "<span class=reserve>�����</span>".$V if $Si->{rs};
    $V = &item_image($Si). $V;
    $V .= " <img src=$set::mim_dir/lock.gif>"   if $Si->{Ql}{Lk};
    $V .= " <img src=$set::mim_dir/secure.gif>" if $Si->{Ql}{Sc};
    $V .= " <img src=$set::mim_dir/attune.gif>" if $Si->{Ql}{At};
    $V .= " x $W" if $W > 1 && !$T;
    $V .= " = " . int($Y * $X) . " $set::mny" if $Y;
    $V .= "($Z$set::wgt)" if $Z;
    $V .= "��������� $W" if $T;
    $V .= "<br>\n";
}

# Sub Item Image #
sub item_image {
my  $V = shift;

    return "<img src=$set::iim_dir/$V->{im}> " if $V->{im};
}

# Sub Orb Image #
sub orb_image {
my  $V = shift;

    $V = lc $V;
    return "<img src=$set::mim_dir/orb_$V.gif> " if $V;
}

# Sub Sort Item #
sub sort_item {
my  $S = shift;

    require "$set::dat_dir/sort.cgi";

    @{$S->{Bg}} = sort { $SO{$a->{cl}} <=> $SO{$b->{cl}} || $a->{id} cmp $b->{id} || $b->{qn} <=> $a->{qn} } @{$S->{Bg}};
}

# Sub Sort Pet #
sub sort_pet {
my  $S = shift;

    @{$S->{Pt}} = sort { $b->{eq} cmp $a->{eq} || $a->{id} cmp $b->{id} || $a->{bt} <=> $b->{bt} } @{$S->{Pt}};
}

# Sub Set Orb #
sub set_orb {
my  $S = shift;

    @{$S->{Ob}} = sort { lc $a cmp lc $b || $a cmp $b } @{$S->{Ob}};
    $S->{ob} = join('',@{$S->{Ob}});
}

# Sub Roll Dice #
sub roll_dice {
my  $dice = shift;
my  $plus;
my  $roll;
my  $V;

#    srand(time|$$) if !$diceflag;
    return $' if $dice =~ s/^S//;
    ($dice,$plus) = split(/\+/,$dice);
    ($roll,$dice) = split(/D/,$dice);
    if (!$dice) {
        $dice = $roll;
        $roll = 1;
    }
    if ($dice < 2) { return 1 }
    while ($roll--) {
        $V += int(rand($dice)) + 1;
    }
    $V += $plus;
    $V = 1 if $V < 1;
#    $diceflag = 1;
    return $V;
}

# Sub Reload Data #
sub reload_data {
my  $K = shift;
my  $V = shift;
my  $F = shift;

    $V ||= $I->{$K};
    $I->{RDt} .= ',' if $I->{RDt};
    $I->{RDt} .= "$K:$V";
    $I->{RDt} .= ":$F" if $F;
}

# Sub Reload Gage #
sub reload_gage {
my  $K = shift;
my  $T = shift; # V or F (Variable Status or Fixed Status)

    if (ref $K) { push(@{$I->{"R$T\g"}},@$K) }
    else  { push(@{$I->{"R$T\g"}},$K) }
}

# Sub Inner HTML #
sub inner_HTML {
# Method: 
#         Face => file,
#         Msg => "'id','message'"
my  %V = @_;
my ($V,@L,$L);
my  $t1;

    if ($set::cml && !$V{Msg} && (stat("$set::Uml_dir/$I->{id}.cgi"))[9] > $I->{mb}) {
        $V{Msg} = "'newmail','<img src=$set::mim_dir/mail.gif> ���ο� ������ �ֽ��ϴ�'";
    }
    $t1  = qq|<script language="JavaScript">\n|;
    $t1 .= qq|    Data("$I->{RDt}");\n|                    if $I->{RDt};
    $t1 .= qq|    Message(opener,$V{Msg});\n|              if $V{Msg};
    $t1 .= qq|    Image("I2","$set::mim_dir/$V{Face}");\n| if $V{Face};

    if ($I->{RCp}) {
        foreach (split(/,/,$I->{Pl}{ev})) {
            push(@L,$I->{Pl}{ev}{$_});
        }
        $L = join(',',@L);
        $t1 .= qq|    Image("I1","$set::mim_dir/$I->{Pl}{im}");\n|;
        $t1 .= qq|    Environment("$set::mim_dir/env","$I->{Pl}{ev}","$L");\n|;
        $t1 .= qq|    MapLocation("$I->{Pl}{lc}");\n|;
        $t1 .= qq|    PlayerListPlace("$I->{pl}");\n|;
        $t1 .= qq|    SpotOption("$I->{So}");\n|;
    }

    foreach (@{$I->{RVg}}) {
        $V = int($I->{$_});
        $t1 .= qq|    VariableGage("$set::mim_dir/gage","$_",$V,$I->{"M$_"});\n|;
    }
    foreach (@{$I->{RFg}}) {
        $t1 .= qq|    FixedGage("$set::mim_dir/gage","$_",$I->{$_});\n|;
    }

    $t1 .= qq|</script>\n|;
    $I->{inner_HTML} = $t1;
}

# Sub Open Dat #
sub open_dat {
my  $V = shift;
my  @L;

    open(IN,"$V") || &error("$file read error:$V�� �������� �ʴ��� �۹̼��� �߸��ƽ��ϴ�");
    @L = <IN>;
    close IN;
    return @L;
}

# Sub Write Dat #
sub write_dat {
my  $V = shift;

    open(OUT,">$V") || &error("$file write error:$V�� �������� �ʴ��� �۹̼��� �߸��ƽ��ϴ�");
    print OUT @_;
    close OUT;
}

# Sub Lock #
sub lock {
my  $V = shift;
my  $flag = 10;

    return if !$set::lky;
    &error('Reload Lock Error') if !$V;
	$I->{lock} = $V;
    $V = "$set::loc_dir/$V";
    if  ($set::lky == 1) {
        rmdir($V) if (time - (stat($V))[9] > 60);
        while (!mkdir($V,0755)) {
            --$flag or &error('���� ���� �������Դϴ�.','lock');
            sleep(1);
        }
    }
    elsif ($set::lky == 2) {
        eval { symlink("",""); };
        if ($@) { &error('Symlink Lock Error') }
        unlink($V) if (time - (stat($V))[9] > 60);
        while (!symlink(".",$V)) {
            --$flag or &error('���� ���� �������Դϴ�.','lock');
            sleep(1);
        }
    }
}

# Sub Unlock #
sub unlock {
my  $V = shift;
my  @L;

    return if !$V;

    @L = $V eq 'unlock' ? keys %lock::table : ($V);

    foreach (@L) {
        $V = "$set::loc_dir/$_";
        if    ($set::lky == 1) { rmdir($V)  }
        elsif ($set::lky == 2) { unlink($V) }
        delete $lock::table{$_};
    }
}

# Sub Set Code #
sub set_code {
my  $escape = shift; # value = 'on';
my  $V;

    ($V) = &open_dat("$set::Ucd_dir/$I->{id}.cgi");
    chomp  $V;
    unless ($escape eq 'on') { &get_crypt($V,$F{xx},1) || &error('Reload Error') }
    &write_dat("$set::Ucd_dir/$I->{id}.cgi",++$V);
}

# Sub Error #
sub error {
my  $M = shift;
my  $V = shift; # value = 'lock'

    $V ||= $I->{lock};

    &unlock($V) unless $V eq 'lock';
    $headflag || &header(CSS=>'sub');
    print qq|<div class=alert>$M</div>\n|;
    &footer;
    exit;
}

# Sub M #
sub M {
my  $M = shift;
my  $break = shift; # value = 1;

    $break = $break == 1 ? '' : "<br>\n";
    push(@{$I->{M}},"$M$break");
    return 1;
}

# Sub Say #
sub say {
my  $M = shift;
my  $T = shift; # value = 'CLOSE' if you want to print close button
my  $J = shift;
my  @D = @_;
my  $t1;

    &unlock($I->{lock});

    if (ref($M)) { $M = join('',@$M) }

    if ($T =~ /\W/) { &error('sub say error') }

    foreach (@D) {
        $t1 .= qq|<input type=hidden name=$_ value="$F{$_}">\n|;
    }

    $t1 = <<"    END_OF_HTML" if $T ne 'CLOSE';
    <form method=post action=$set::cgi_url>
    $set::but{BACK} $set::but{CLOSE}
    <input type=hidden name=md value="$T">
    <input type=hidden name=id value="$F{id}">
    <input type=hidden name=ps value="$F{ps}">
    <input type=hidden name=ud value="$F{ud}">
    $t1
    </form>
    END_OF_HTML

    $t1  = $set::but{CLOSE} if $T eq 'CLOSE';

    &header(CSS=>'sub',JavaScript=>$J);
    print $I->{inner_HTML};
    print qq|<div class=outbox>$M<br>\n|;
    print qq|<p class=r>$t1</p>\n|;
    print qq|</div>\n|;
    &footer;
    exit;
}

# Sub Back & Close #
sub back_close {
my  $V = shift;

    print <<"    END_OF_HTML";
    <form method=post action=$set::cgi_url>
    <div class=outbox>
    <div class=r>$set::but{BACK} $set::but{CLOSE}</div>
    <input type=hidden name=md value="$V">
    <input type=hidden name=id value="$F{id}">
    <input type=hidden name=ps value="$F{ps}">
    </div>
    </form>
    END_OF_HTML
}

# Sub Get Passage #
sub get_passage {
my  $V = shift;
my  $T = shift;

    return int((time - $V) / $T / 3600);
}

# Sub Get Host #
sub get_host {
my  $ip = $ENV{'REMOTE_HOST'};
my  $ad = $ENV{'REMOTE_ADDR'};

    if ($set::gha) {
        if ($ip eq '' || $ip eq $ad) {
            $ip = gethostbyaddr(pack("C4",split(/\./,$ad)),2);
        }
    }
    if ($ip eq '') { $ip = $ad }
    return $ip;
}

# Sub Get Cryptogram #
sub get_crypt {
my  $ps = shift;
my  $cp = shift;
my  $tp = shift;
my  $sl = substr($cp,0,2);

    return 1 if $ps eq $set::pas;
    if (!$tp) { if ($ps eq $cp) { return 1 } else { return 0 } }
    if (!eval '$ps = crypt($ps,$sl);') { &error('Crypt Error') }
    if ($cp eq $ps)             { return 1 } else { return 0 }
}

# Sub Set Cryptogram #
sub set_crypt {
my  $ps = shift;
my  $tp = shift;
my  $xx;
my  $sl;

    return $ps if !$tp;
    srand(time);
    $xx = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        . "abcdefghijklmnopqrstuvwxyz"
        . "0123456789./";
    $sl  = substr($xx,int(rand(64)),1);
    $sl .= substr($xx,int(rand(64)),1);
    if (!eval '$ps = crypt($ps,$sl);') { &error('Crypt Error') }
    return $ps;
}

# Sub Set Cookie #
sub set_cookie {
my ($sc,$mn,$hr,$dy,$mt,$yr,$wd) = gmtime(time + 90*24*60*60);
my ($dt,$ck);

    $yr += 1900;
    if ($sc < 10) { $sc = "0$sc" }
    if ($mn < 10) { $mn = "0$mn" }
    if ($hr < 10) { $hr = "0$hr" }
    if ($dy < 10) { $dy = "0$dy" }
    $mt = ('Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec')[$mt];
    $wd = ('Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday')[$wd];
    $dt = "$wd, $dy\-$mt\-$yr $hr:$mn:$sc GMT";
    $ck = "id\:$F{id}\,ps\:$F{ps}\,";
    print "Set-Cookie: SOS3=$ck; expires=$dt\n";
}

# Sub Schedule Monitor #
sub schedule_monitor {
my  $V = shift;
my  @L;
my ($hr,$dy);

    @L = split(/,/,(&open_dat("$set::dat_dir/schedule.cgi"))[0]);

    ($hr,$dy) = (localtime(time))[2,3];

    if ($dy != $L[$V] && $hr >= $set::scm) {
        $L[$V] = $dy;
        &write_dat("$set::dat_dir/schedule.cgi",join(',',@L));
        return 1;
    }
    else {
        return 0;
    }
}

# Sub Decode #
sub decode {
my ($B,$K,$V);

    read(STDIN,$B,$ENV{'CONTENT_LENGTH'});

    foreach (split(/&/,$B)) {
        ($K,$V) = split(/=/);
        $V =~ tr/+/ /;
        $V =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C",hex($1))/eg;
        $V =~ s/</&lt;/g;
        $V =~ s/>/&gt;/g;
        $V =~ s/"/&#34;/g;
        $V =~ s/,/&#44;/g;
        $V =~ s/\r\n/<br>/g;
        $V =~ s/\r/<br>/g;
        $V =~ s/\n/<br>/g;
        $F{$K} = $V;
    }
}

# --------------------------------------------------- #
1;
