# --------------------------------------------------- #
# Script of Saga III Market.cgi Version 1
# Copyright (C) 2005 Missing Link.
# --------------------------------------------------- #

# Sub Market #
sub market {
my  $t1;

    $I = &get_user('I');

    &dead_check($I,'CLOSE');

    &get_place($I);

    &spot_check($I,'Mk');

    if ($I->{Pl}{bm}) {
        $t1  = qq|<input type=radio name=md class=radio value="blackmarket_before">\n|;
        $t1 .= qq|�Ͻ��� �ѷ�����<br>\n|;
        $t1 .= qq|<input type=radio name=md class=radio value="sell_before">\n|;
        $t1 .= qq|�Ͻ��忡 ���� ������<br>\n|;
    }

    &header(CSS=>'sub');
    print <<"    END_OF_HTML";
    <div class=label>$I->{Sp}{Mk}{nm}</div>
    <form method=post action=$set::cgi_url>
    <div class=outbox>
    <div>
    <img src=$set::mim_dir/envMk.gif><br>
    <br>
    <tt>$I->{Sp}{Mk}{nm}�� ���� �ùε�� �����Ÿ��ϴ�.</tt>
    </div>
    <br>
    <input type=radio name=md class=radio value="shopping_before" checked>
    $I->{Sp}{Mk}{nm} �ѷ�����<br>
    $t1
    <br>
    <br>
    <div class=r>$set::but{OK} $set::but{CLOSE}</div>
    <input type=hidden name=id value="$F{id}">
    <input type=hidden name=ps value="$F{ps}">
    </div>
    </form>
    END_OF_HTML
    &footer;
}

# --------------------------------------------------- #
1;

