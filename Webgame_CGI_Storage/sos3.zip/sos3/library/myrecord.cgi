# --------------------------------------------------- #
# Script of Saga III My Record.cgi Version 1
# Copyright (C) 2005 Missing Link.
# --------------------------------------------------- #

# My Record #
sub myrecord {
my  @L;

    $I = &get_user('I');

    @L = map { [split(/<>/)] } &open_dat("$set::Urc_dir/$I->{id}.cgi");

    &inner_HTML(Msg=>"'newrecord'");

    &header(CSS=>'sub',JavaScript=>'Reload');
    print $I->{inner_HTML};
    print "<div class=label>$I->{nm}�� My Record</div>";
    foreach (@L) {
        print qq|$_->[2]\n|;
        print qq|<div class=r><tt>ID:$_->[3] $_->[1]</tt></div><hr>|;
    }
    print qq|<p class=c>$set::but{CLOSE}</p>\n|;
    &footer;
}

# Sub Set Record #
sub set_record {
my  $V = shift;
my  $T = shift;
my  @L;

    &error('������ �����Դϴ�') if !$U->{id};
    &lock($U->{id});
    @L = &open_dat("$set::Urc_dir/$U->{id}.cgi");

	require "$set::lib_dir/date.cgi";

    $V =~ s/\n//g;
    $T ||= $I->{id};

	pop(@L) if @L >= $set::rcx;
	unshift(@L,join('<>',time,&get_date,$V,$T,"\n"));

    &write_dat("$set::Urc_dir/$U->{id}.cgi",@L);
    &unlock($U->{id});
}

# --------------------------------------------------- #
1;