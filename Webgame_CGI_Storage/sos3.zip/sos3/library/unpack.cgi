# --------------------------------------------------- #
# Script of Saga III Unpack.cgi Version 2 (1.4)
# Copyright (C) 2005-2007 Missing Link.
# --------------------------------------------------- #

# Sub Unpack Before #
sub unpack_before {
my  $i;
my  $Ii;
my  $t1;

    $I = &get_user('I');
    &get_item($I);

    &say("���� ������ �����մϴ�",$F{fl}) if @{$I->{Bg}} >= $I->{bs};

    foreach $Ii (@{$I->{Bg}}) {
        $i++;
        next if !$Ii;
		next if !$F{$i};
	    next if $Ii->{qn} < 2;
        $t1 .= qq|<input type=textbox name=$i class=textbox size=2 value=1> |;
        $t1 .= &decorate_item($Ii);
	}

    &get_code;

    &header(CSS=>'sub');
    print <<"    END_OF_HTML";
    <div class=label>��Ʈ �и��ϱ�</div>
    <form method=post action=$set::cgi_url>
    <div class=outbox>
    <tt>��ġ�� �Է����ּ���.</tt>
    <br>
    $t1
    <div class=r><tt>���� ����: $I->{bs}</tt></div>
    <br>
    <div class=r>$set::but{OK}</div>
    <input type=hidden name=md value="unpack_after">
    <input type=hidden name=id value="$F{id}">
    <input type=hidden name=ps value="$F{ps}">
    <input type=hidden name=fl value="$F{fl}">
    <input type=hidden name=xx value="$I->{XX}">
    </div>
    </form>
    END_OF_HTML
    &back_close($F{fl});
    &footer;
}

# Sub Unpack After #
sub unpack_after {
my  $i;
my ($Ii,@UI);
my ($V,$X);

    $I = &get_user('I');
    &get_item($I);

    $V = $I->{bs} - @{$I->{Bg}};

    foreach $Ii (@{$I->{Bg}}) {
        next if !$Ii;
        $i++;
		next if !$F{$i};
        &M("$Ii->{nm}: ���� ������ �����մϴ�.") && next if $V < 1;
        &M("$Ii->{nm}: ���ڸ� �Է��ؾ� �մϴ�.") && next if $F{$i} =~ /\D/;
        &M("$Ii->{nm}: $Ii->{qn}�̻��� ���ڴ� �Է��� �� �����ϴ�.") && next if $F{$i} >= $Ii->{qn};
        $Ii->{sp} = $Ii->{rs} = '';
        $X = $Ii->{qn} - $F{$i};
        $Ii->{qn} = $F{$i};
        push(@UI,{%$Ii});
        $Ii->{qn} = $X;
        &M("$Ii->{nm}(��)�� $F{$i}�� �������ϴ�.");
        $V--;
    }
    push(@{$I->{Bg}},@UI);

    &set_code;

    &sort_item($I);

    &set_item($I);

    &say($I->{M},$F{fl});
}

# --------------------------------------------------- #
1;
