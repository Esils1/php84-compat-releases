function GetCookie(key) {
	tmp=document.cookie+";";
	tmp1=tmp.indexOf(key,0);
	if (tmp1 != -1) {
		tmp=tmp.substring(tmp1,tmp.length);
		start = tmp.indexOf(":",0)+1;
		end   = tmp.indexOf(",",start);
		return(unescape(tmp.substring(start,end)));
	}
	return("");
}
function GetValue() {
	document.loginform.id.value = GetCookie("id");
	document.loginform.ps.value = GetCookie("ps");
}
