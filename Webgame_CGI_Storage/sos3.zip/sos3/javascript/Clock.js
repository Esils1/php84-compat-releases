function Clock(id,timer) {
    try {
        minute = timer % 3600;
        hour = Math.floor(timer / 3600) + '�ð�';
        minute = Math.floor(minute / 60) + '��';
        target = GetObject(id,self);
        check = target.innerHTML;
        timer -= 60;
        setid = id;
        settimer = timer;
        if (settimer <= 0 || check == '&nbsp;') {
            target.innerHTML = '';
        }
        else {
            target.innerHTML = '�һ����� �����ð�' + hour + minute;
            setTimeout("Clock(setid,settimer);",60000);
        }
    }
    catch (err) { }
}
