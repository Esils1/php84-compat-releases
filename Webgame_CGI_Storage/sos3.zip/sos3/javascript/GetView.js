function GetObject(id,target) {
    if (document.getElementById) { target = target.document.getElementById(id) }
    else if (navigator.appName.charAt(0) == "M") {
        if (document.all) { target = target.document.all(id) }
    }
    else if (navigator.appName.charAt(0) == "N") {
        if (document.layers) { target = target.document.layers[id] }
    }
    return target;
}

function GetView(id) {
	target1 = GetObject(id,self);
	target2 = GetObject('rights',self);
	target1.style.display = target1.style.display == "none" ? "" : "none";
	target2.style.display = target2.style.display == "none" ? "" : "none";
}

function HideObject(hid,cid,keyvalue,flag) {
    try {
        var val1 = flag == 'reverse' ? "hidden" : "visible";
        var val2 = flag == 'reverse' ? "visible" : "hidden";
    	target1 = GetObject(hid,self);
    	target2 = GetObject(cid,self);
    	target1.style.visibility = target2.value == keyvalue ? val1 : val2;
    }
    catch (err) {}
}

