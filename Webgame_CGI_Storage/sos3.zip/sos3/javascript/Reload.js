function GetObject(id,target) {
    if (document.getElementById) { target = target.document.getElementById(id) }
    else if (navigator.appName.charAt(0) == "M") {
        if (document.all) { target = target.document.all(id) }
    }
    else if (navigator.appName.charAt(0) == "N") {
        if (document.layers) { target = target.document.layers[id] }
    }
    return target;
}

function Data(parameter) {
    try {
        parameterlist = parameter.split(",");
        for (i = 0; i < parameterlist.length; i++) {
            data = parameterlist[i].split(":");
            target = GetObject(data[0],opener);
            if (data[2]) { data[2] = "<img src=" + ItemImageDirectory + data[2] + "> " }
            else { data[2] = '' }
            if (target) { target.innerHTML = data[2] + data[1] }
        }
    }
    catch (err) {}
}

function Image(id,path) {
    try {
        target = GetObject(id,opener);
        if (target) { target.src = path }
    }
    catch (err) {}
}

function Environment(path,parameter,name) {
    var tag = '';
    try {
        parameterlist = parameter.split(",");
        namelist = name.split(",");
        target = GetObject("ev",opener);
        for (i = 0; i < parameterlist.length; i++) {
            tag += "<img src=" + path + parameterlist[i] + ".gif title=\"" + namelist[i] + "\"> ";
        }
        target.innerHTML = tag;
    }
    catch (err) {}
}

function MapLocation(val) {
    try {
        vallist = val.split(",");
        window.opener.document.mapform.x.value = vallist[0];
        window.opener.document.mapform.y.value = vallist[1];
    }
    catch (err) {}
}

function SpotOption(val) {
    try {
        if (val) { vallist = val.split(","); }
        else { vallist = new Array(); }
        vallist.push("church_before=��ȸ");
        window.opener.document.spotform.md.length = vallist.length;
        for (i = 0; i < vallist.length; i++) {
            spotlist = vallist[i].split("=");
            window.opener.document.spotform.md.options[i].value = spotlist[0];
            window.opener.document.spotform.md.options[i].text  = spotlist[1] + " �̵�";
        }
        window.opener.document.spotform.md.selectedIndex = 0;
    }
    catch (err) {}
}

function PlayerListPlace (val) {
    try {
        window.opener.document.playerlistform.pl.value = val;
    }
    catch (err) {}
}

function VariableGage(path,id,val,max) {
    var Gid = 'G' + id;
    var tag;
    try {
        target = GetObject(id,opener);
        if (target) { target.innerHTML = val + "/" + max }
        target = GetObject(Gid,opener);
        color = val < 20 ? 1:
                val < 50 ? 2:
                val < 80 ? 3:
                           4;
        max -= val;
        tag  = "<img src=" + path + color + ".gif width=" + val + " height=8>";
        if (max) { tag += "<img src=" + path + "0.gif width=" + max + " height=8>" }
        target.innerHTML = tag;
    }
    catch (err) {}
}

function FixedGage(path,id,val) {
    var Gid = 'G' + id;
    try {
        target = GetObject(id,opener);
        if (target) { target.innerHTML = val }
        target = GetObject(Gid,opener);
        color = val <  5 ? 1:
                val < 10 ? 2:
                val < 15 ? 3:
                           4;
        val *= 2;
        target.innerHTML = "<img src=" + path + color + ".gif width=" + val + " height=8 class=gage>";
    }
    catch (err) {}
}

function Message(win,id,val) {
    try {
        target = GetObject(id,win);
        if (val) {
            target.innerHTML = val;
            target.style.display = "";
        }
        else { target.style.display = "none"; }
    }
    catch (err) {}
}
