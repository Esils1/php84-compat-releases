function ReturnTop(url) {
    try {
        opener.location.href=url;
    }
    catch (err) {}
}
