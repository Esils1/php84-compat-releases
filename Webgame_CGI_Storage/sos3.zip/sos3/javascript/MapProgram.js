function GetObject(id,target) {
    if (document.getElementById) { target = target.document.getElementById(id) }
    else if (navigator.appName.charAt(0) == "M") {
        if (document.all) { target = target.document.all(id) }
    }
    else if (navigator.appName.charAt(0) == "N") {
        if (document.layers) { target = target.document.layers[id] }
    }
    return target;
}

function SetMap() {
  target = GetObject('map',self);
  for (i=0; i<crd.length; i++) {
	para = crd[i].split(",");
	target.innerHTML += "<img src=" + MainImageDirectory + "1n.gif id=\"" + para[0] + "\" width=" + para[1] + " height=" + para[2] + " style=\"left:" + para[3] + ";top:" + para[4] + ";position:absolute;\" onMouseOver=\"Information(this.id,event)\" onMouseOut=\"Information(0)\">";
  }
}

function Information(index,e) {
  target = GetObject('box',self);
  target.style.visibility = index ? "" : "hidden";
  if (!index) return;
  if (navigator.appName.charAt(0) == "M") {
        target.innerHTML  = msg[index];
        target.style.left = window.event.x - 10;
        target.style.top  = window.event.y - 25;
  }
  else {
	event = e || window.event;
	x = event.pageX;
	y = event.pageY;
    if (document.getElementById) {
	        target.innerHTML  = msg[index];
	        target.style.left = x - 10;
	        target.style.top  = y - 25;
	}
	else if (document.layers) {
	        target.document.open();
	        target.document.write(msg[index]);
	        target.document.close();
	        target.left = x - 10;
	        target.top  = y - 25;
	}
  }
}
