function Image(sex) {
  number = document.newform.im.selectedIndex + 1;
  document.image.src = MainImageDirectory + sex + number + ImageFileType;
}

function SetImageSelect(val) {
  for (i = 1; i <= TotalImage; i++) {
    document.newform.im.options[i-1] = new Option(i,i + ImageFileType);
    if (val == document.newform.im.options[i-1].value) {
        document.newform.im.options[i-1].selected = true;
    }
  }
}
