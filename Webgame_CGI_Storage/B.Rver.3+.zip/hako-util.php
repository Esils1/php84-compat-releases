<?php
/*******************************************************************

  모형정원 제도 B.R

*******************************************************************/

//--------------------------------------------------------------------
class Util {
  //---------------------------------------------------
  // 자금의 표시
  //---------------------------------------------------
  function aboutMoney($money = 0) {
    global $init;
    if($init->moneyMode) {
      if($money < 500) {
        return "추정 500{$init->unitMoney}미만";
      } else {
        return "추정" . round($money / 1000) . "000" . $init->unitMoney;
      }
    } else {
      return $money . $init->unitMoney;
    }
  }
  //---------------------------------------------------
  // 경험지로부터 미사일 기지 레벨을 산출
  //---------------------------------------------------
  function expToLevel($kind, $exp) {
    global $init;
    if($kind == $init->landBase) {
      // 미사일 기지
      for($i = $init->maxBaseLevel; $i > 1; $i--) {
        if($exp >= $init->baseLevelUp[$i - 2]) {
          return $i;
        }
      }
      return 1;
    } else {
      // 해저 기지
      for($i = $init->maxSBaseLevel; $i > 1; $i--) {
        if($exp >= $init->sBaseLevelUp[$i - 2]) {
          return $i;
        }
      }
      return 1;
    }
  }
  //---------------------------------------------------
  // 괴수의 종류·이름·체력을 산출
  //---------------------------------------------------
  function monsterSpec($lv) {
    global $init;
    // 종류
    $kind = (int)($lv / 10);
    // 이름
    $name = $init->monsterName[$kind];
    // 체력
    $hp = $lv - ($kind * 10);
    return array ( 'kind' => $kind, 'name' => $name, 'hp' => $hp );
  }
  //---------------------------------------------------
  // 섬의 이름으로부터 번호를 산출
  //---------------------------------------------------
  function  nameToNumber($hako, $name) {
    // 섬 전체로부터 찾는다
    for($i = 0; $i < $hako->islandNumber; $i++) {
      if(strcmp($name, "{$hako->islands[$i]['name']}") == 0) {
        return $i;
      }
    }
    // 발견되지 않았던 경우
    return -1;
  }
  //---------------------------------------------------
  // 패스워드 체크
  //---------------------------------------------------
  function checkPassword($p1 = "", $p2 = "") {
    global $init;

    // null체크
    if(empty($p2))
      return false;

    if(file_exists("{$init->passwordFile}")) {
      $fp = fopen("{$init->passwordFile}", "r");
      $masterPassword = chop(fgets($fp, READ_LINE));
      fclose($fp);
    }

    // 마스터 패스워드 체크
    if(strcmp($masterPassword, crypt($p2, 'ma')) == 0)
      return true;

    if(strcmp($p1, Util::encode($p2)) == 0)
      return true;
    
    return false;
  }

  function checkSpecialPassword($p = "") {
    global $init;

    // null 체크
    if(empty($p))
      return false;

    if(file_exists("{$init->passwordFile}")) {
      $fp = fopen("{$init->passwordFile}", "r");
      $masterPassword = chop(fgets($fp, READ_LINE));
      $specialPassword = chop(fgets($fp, READ_LINE));
      fclose($fp);
    }
    // 특수 패스워드 체크
    if(strcmp($specialPassword, crypt($p, 'sp')) == 0)
      return true;

    return false;
  }
  //---------------------------------------------------
  // 패스워드의 encode
  //---------------------------------------------------
  function encode($s) {
    global $init;
    if($init->cryptOn) {
      return crypt($s, 'h2');
    } else {
      return $s;
    }
  }
  //---------------------------------------------------
  // 0 ~ num -1 의 난수 생성
  //---------------------------------------------------
  function random($num = 0) {
    if($num <= 1) return 0;
    return mt_rand(0, $num - 1);
  }
  //---------------------------------------------------
  // 로컬 게시판의 메세지를 1개전에 늦춘다
  //---------------------------------------------------
  function slideBackLbbsMessage(&$lbbs, $num) {
    global $init;
    array_splice($lbbs, $num, 1);
    $lbbs[$init->lbbsMax - 1] = '0>>0>>';
  }
  //---------------------------------------------------
  // 로컬 게시판의 메세지를 1개 뒤로 비켜 놓는다
  //---------------------------------------------------
  function slideLbbsMessage(&$lbbs) {
    array_pop($lbbs);
    array_unshift($lbbs, $lbbs[0]);
  }
  //---------------------------------------------------
  // 랜덤인 좌표를 생성?
  //---------------------------------------------------
  function makeRandomPointArray() {
    global $init;
    $rx = $ry = array();
    for($i = 0; $i < $init->islandSize; $i++)
      for($j = 0; $j < $init->islandSize; $j++)
        $rx[$i * $init->islandSize + $j] = $j;

    for($i = 0; $i < $init->islandSize; $i++)
      for($j = 0; $j < $init->islandSize; $j++)
        $ry[$j * $init->islandSize + $i] = $j;
    

    for($i = $init->pointNumber; --$i;) {
      $j = Util::random($i + 1);
      if($i != $j) {
        $tmp = $rx[$i];
        $rx[$i] = $rx[$j];
        $rx[$j] = $tmp;
          
        $tmp = $ry[$i];
        $ry[$i] = $ry[$j];
        $ry[$j] = $tmp;
      }
    }
    return array($rx, $ry);
  }
  //---------------------------------------------------
  // 랜덤인 섬의 순서를 생성
  //---------------------------------------------------
  function randomArray($n = 1) {
    // 초기치
    for($i = 0; $i < $n; $i++) {
      $list[$i] = $i;
    }

    // 상훌
    for($i = 0; $i < $n; $i++) {
      $j = Util::random($n - 1);
      if($i != $j) {
        $tmp = $list[$i];
        $list[$i] = $list[$j];
        $list[$j] = $tmp;
      }
    }
    return $list;
  }
  //---------------------------------------------------
  // 커멘드를 앞에 두고 비켜 놓는다
  //---------------------------------------------------
  function slideFront(&$command, $number = 0) {
    global $init;
    // 각각 비켜 놓는다
    array_splice($command, $number, 1);

    // 마지막에 자금융통
    $command[$init->commandMax - 1] = array (
      'kind'   => $init->comDoNothing,
      'target' => 0,
      'x'      => 0,
      'y'      => 0,
      'arg'    => 0
      );
  }
  //---------------------------------------------------
  // 커멘드를 뒤에 늦춘다
  //---------------------------------------------------
  function slideBack(&$command, $number = 0) {
    global $init;
    // 각각 비켜 놓는다
    if($number == count($command) - 1)
      return;

    for($i = $init->commandMax - 1; $i >= $number; $i--) {
      $command[$i] = $command[$i - 1];
    }
  }

// function euc_convert($arg) {
    // 문자 코드를 EUC-JP로 변환해 돌려준다
    // 캐릭터 라인의 문자 코드를 판별
//    $code = i18n_discover_encoding("$arg");
    // 비EUC-KR의 경우만 EUC-JP에 변환
//   if ( $code != "EUC-KR" ) {
//    $arg = i18n_convert("$arg","EUC-KR");
//    }
//   return $arg;
//  }

//  function sjis_convert($arg) {
    // 문자 코드를 SHIFT_JIS로 변환해 돌려준다
    // 캐릭터 라인의 문자 코드를 판별
//    $code = i18n_discover_encoding("$arg");
    // 비SHIFT_JIS의 경우만 SHIFT_JIS에 변환
//    if ( $code != "SJIS" ) {
//      $arg = i18n_convert("$arg","SJIS");
//    }
//    return $arg;
//  }
  //---------------------------------------------------
  //  파일을 잠근다(기입시)
  //---------------------------------------------------
  function lockw($fp) {
    set_file_buffer($fp, 0);
    if(!flock($fp, LOCK_EX)) {
      HakoHakoError::lockFail();
    }
    rewind($fp);
  }
  //---------------------------------------------------
  // 파일을 잠근다(read시)
  //---------------------------------------------------
  function lockr($fp) {
    set_file_buffer($fp, 0);
    if(!flock($fp, LOCK_SH)) {
      HakoHakoError::lockFail();
    }
    rewind($fp);
  }
  //---------------------------------------------------
  // 파일을 언로크 한다
  //---------------------------------------------------
  function unlock($fp) {
    flock($fp, LOCK_UN);
  }
}

?>
