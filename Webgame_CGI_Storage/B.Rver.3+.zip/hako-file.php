<?php
/*******************************************************************

   모형정원 제도 B.R

*******************************************************************/

//--------------------------------------------------------------------
class HakoIO {
  var $islandTurn;	// 턴수
  var $islandLastTime;	// 최종 갱신 시각
  var $islandNumber;	// 섬의 총수
  var $islandNextID;	// 다음에 할당하는 섬ID
  var $islands;		// 섬 전체의 정보를 격납
  var $idToNumber;
  var $idToName;

  //---------------------------------------------------
  // 섬 전체 데이터를 읽어들인다
  // 'mode'가 바뀔 가능성이 있으므로$cgi를 참조로 받는다
  //---------------------------------------------------
  function readIslandsFile(&$cgi) {
    global $init;
    $num = $cgi->dataSet['ISLANDID'];

    $fileName = "{$init->dirName}/hakojima.dat";
    if(!is_file($fileName)) {
      return false;
    }
    $fp = fopen($fileName, "r");
    Util::lockr($fp);
    $this->islandTurn     = chop(fgets($fp, READ_LINE));
    $this->islandLastTime = chop(fgets($fp, READ_LINE));
    $this->islandNumber   = chop(fgets($fp, READ_LINE));
    $this->islandNextID   = chop(fgets($fp, READ_LINE));

    $GLOBALS['ISLAND_TURN'] = $this->islandTurn;
      
    // 턴 처리 판정
    $now = time();
    if((DEBUG && (strcmp($cgi->dataSet['mode'], 'debugTurn') == 0)) ||
       ((($now - $this->islandLastTime) >= $init->unitTime) &&
        ($this->islandNumber > $init->finish))) {
      $cgi->mode = $data['mode'] = 'turn';
      $num = -1;
    }
    for($i = 0; $i < $this->islandNumber; $i++) {
      $this->islands[$i] = $this->readIsland($fp, $num);
      $this->idToNumber[$this->islands[$i]['id']] = $i;
    }
    Util::unlock($fp);
    fclose($fp);
    return true;
  }
  //---------------------------------------------------
  // 섬하나 읽어들인다
  //---------------------------------------------------
  function readIsland($fp, $num) {
    global $init;
    $name     = chop(fgets($fp, READ_LINE));
    list($name, $owner, $monster) = split(",", $name);
    $id       = chop(fgets($fp, READ_LINE));
    $prize    = chop(fgets($fp, READ_LINE));
    $absent   = chop(fgets($fp, READ_LINE));
    $comment  = chop(fgets($fp, READ_LINE));
    list($comment, $comment_turn) = split(",", $comment);
    $password = chop(fgets($fp, READ_LINE));
    $money    = chop(fgets($fp, READ_LINE));
    $food     = chop(fgets($fp, READ_LINE));
    $pop      = chop(fgets($fp, READ_LINE));
    $area     = chop(fgets($fp, READ_LINE));
    $farm     = chop(fgets($fp, READ_LINE));
    $factory  = chop(fgets($fp, READ_LINE));
    $mountain = chop(fgets($fp, READ_LINE));
    $mout     = chop(fgets($fp, READ_LINE));
    $total    = chop(fgets($fp, READ_LINE));
    $min      = chop(fgets($fp, READ_LINE));
    $now      = chop(fgets($fp, READ_LINE));
    $get      = chop(fgets($fp, READ_LINE));
    $fire     = chop(fgets($fp, READ_LINE));

    $this->idToName[$id] = $name;
    
    if(($num == -1) || ($num == $id)) {
      $fp_i = fopen("{$init->dirName}/island.{$id}", "r");
      Util::lockr($fp_i);

      // 지형
      $offset = 4; // 한 벌의 데이터가 무엇 문자인가
      for($y = 0; $y < $init->islandSize; $y++) {
        $line = chop(fgets($fp_i, READ_LINE));
        for($x = 0; $x < $init->islandSize; $x++) {
          $l = substr($line, $x * $offset    , 2);
          $v = substr($line, $x * $offset + 2, 2);
          $land[$x][$y]      = hexdec($l);
          $landValue[$x][$y] = hexdec($v);
        }
      }
      
      // 커멘드
      for($i = 0; $i < $init->commandMax; $i++) {
        $line = chop(fgets($fp_i, READ_LINE));
        list($kind, $target, $x, $y, $arg) = split(",", $line);
        $command[$i] = array (
          'kind'   => $kind,
          'target' => $target,
          'x'      => $x,
          'y'      => $y,
          'arg'    => $arg,
          );
      }
      // 로컬 게시판
      for($i = 0; $i < $init->lbbsMax; $i++) {
        $line = chop(fgets($fp_i, READ_LINE));
        $lbbs[$i] = $line;
      }
      Util::unlock($fp_i);
      fclose($fp_i);
    }
    return array(
      'name'     => $name,
      'owner'    => $owner,
      'id'       => $id,
      'prize'    => $prize,
      'absent'   => $absent,
      'comment'  => $comment,
      'comment_turn' => $comment_turn,
      'password' => $password,
      'money'    => $money,
      'food'     => $food,
      'pop'      => $pop,
      'area'     => $area,
      'farm'     => $farm,
      'factory'  => $factory,
      'mountain' => $mountain,
      'mout'     => $mout,
      'total'    => $total,
      'min'      => $min,
      'now'      => $now,
      'get'      => $get,
      'fire'      => $fire,
      'monster'  => $monster,
      'land'     => $land,
      'landValue'=> $landValue,
      'command'  => $command,
      'lbbs'     => $lbbs,
      );
  }
  //---------------------------------------------------
  // 지형을 기입한다
  //---------------------------------------------------
  function writeLand($num, $island) {
    global $init;
    // 지형
    if(($num <= -1) || ($num == $island['id'])) {
      $fileName = "{$init->dirName}/island.{$island['id']}";

      if(!is_file($fileName))
        touch($fileName);

      $fp_i = fopen($fileName, "w");
      Util::lockw($fp_i);
      $land = $island['land'];
      $landValue = $island['landValue'];
  
      for($y = 0; $y < $init->islandSize; $y++) {
        for($x = 0; $x < $init->islandSize; $x++) {
          $l = sprintf("%02x%02x", $land[$x][$y], $landValue[$x][$y]);
          fputs($fp_i, $l);
        }
        fputs($fp_i, "\n");
      }

      // 커멘드
      $command = $island['command'];
      for($i = 0; $i < $init->commandMax; $i++) {
        $com = sprintf("%d,%d,%d,%d,%d\n",
                     $command[$i]['kind'],
                     $command[$i]['target'],
                     $command[$i]['x'],
                     $command[$i]['y'],
                     $command[$i]['arg']
                );
        fputs($fp_i, $com);
      }

      // 로컬 게시판
      $lbbs = $island['lbbs'];
      for($i = 0; $i < $init->lbbsMax; $i++) {
        fputs($fp_i, $lbbs[$i] . "\n");
      }
      Util::unlock($fp_i);
      fclose($fp_i);
    }
  }
  //---------------------------------------------------
  // 섬 전체 데이터를 기입한다
  //---------------------------------------------------
  function writeIslandsFile($num = 0) {
    global $init;
    $fileName = "{$init->dirName}/hakojima.dat";

    if(!is_file($fileName))
      touch($fileName);

    $fp = fopen($fileName, "w");
    Util::lockw($fp);
    fputs($fp, $this->islandTurn . "\n");
    fputs($fp, $this->islandLastTime . "\n");
    fputs($fp, $this->islandNumber . "\n");
    fputs($fp, $this->islandNextID . "\n");
    for($i = 0; $i < $this->islandNumber; $i++) {
      $this->writeIsland($fp, $num, $this->islands[$i]);
    }
    Util::unlock($fp);
    fclose($fp);
//    chmod($fileName, 0666);
  }
  //---------------------------------------------------
  // 섬하나 기입한다
  //---------------------------------------------------
  function writeIsland($fp, $num, $island) {
    global $init;
    fputs($fp, $island['name'] . "," . $island['owner'] . "," . $island['monster'] . "\n");
    fputs($fp, $island['id'] . "\n");
    fputs($fp, $island['prize'] . "\n");
    fputs($fp, $island['absent'] . "\n");
    fputs($fp, $island['comment'] . "," . $island['comment_turn'] . "\n");
    fputs($fp, $island['password'] . "\n");
    fputs($fp, $island['money'] . "\n");
    fputs($fp, $island['food'] . "\n");
    fputs($fp, $island['pop'] . "\n");
    fputs($fp, $island['area'] . "\n");
    fputs($fp, $island['farm'] . "\n");
    fputs($fp, $island['factory'] . "\n");
    fputs($fp, $island['mountain'] . "\n");
    fputs($fp, $island['mout'] . "\n");
    fputs($fp, $island['total'] . "\n");
    fputs($fp, $island['min'] . "\n");
    fputs($fp, $island['now'] . "\n");
    fputs($fp, $island['get'] . "\n");
    fputs($fp, $island['fire'] . "\n");
    // 지형
    if(($num <= -1) || ($num == $island['id'])) {
      $fileName = "{$init->dirName}/island.{$island['id']}";

      if(!is_file($fileName))
        touch($fileName);

      $fp_i = fopen($fileName, "w");
      Util::lockw($fp_i);
      $land = $island['land'];
      $landValue = $island['landValue'];
  
      for($y = 0; $y < $init->islandSize; $y++) {
        for($x = 0; $x < $init->islandSize; $x++) {
          $l = sprintf("%02x%02x", $land[$x][$y], $landValue[$x][$y]);
          fputs($fp_i, $l);
        }
        fputs($fp_i, "\n");
      }

      // 커멘드
      $command = $island['command'];
      for($i = 0; $i < $init->commandMax; $i++) {
        $com = sprintf("%d,%d,%d,%d,%d\n",
                     $command[$i]['kind'],
                     $command[$i]['target'],
                     $command[$i]['x'],
                     $command[$i]['y'],
                     $command[$i]['arg']
                );
        fputs($fp_i, $com);
      }

      // 로컬 게시판
      $lbbs = $island['lbbs'];
      for($i = 0; $i < $init->lbbsMax; $i++) {
        fputs($fp_i, $lbbs[$i] . "\n");
      }
      Util::unlock($fp_i);
      fclose($fp_i);
//      chmod($fileName, 0666);
    }
  }
  //---------------------------------------------------
  // 데이터의 백업
  //---------------------------------------------------
  function backUp() {
    global $init;

    if($init->backupTimes <= 0)
      return;
    
    $tmp = $init->backupTimes - 1;
    $this->rmTree("{$init->dirName}.bak{$tmp}");
    for($i = ($init->backupTimes - 1); $i > 0; $i--) {
      $j = $i - 1;
      if(is_dir("{$init->dirName}.bak{$j}"))
        rename("{$init->dirName}.bak{$j}", "{$init->dirName}.bak{$i}");
    }
    if(is_dir("{$init->dirName}"))
      rename("{$init->dirName}", "{$init->dirName}.bak0");

    mkdir("{$init->dirName}", $init->dirMode);

    // 로그 파일만 되돌린다
    for($i = 0; $i <= $init->logMax; $i++) {
      if(is_file("{$init->dirName}.bak0/hakojima.log{$i}"))
        rename("{$init->dirName}.bak0/hakojima.log{$i}", "{$init->dirName}/hakojima.log{$i}");
    }
    if(is_file("{$init->dirName}.bak0/hakojima.his"))
      rename("{$init->dirName}.bak0/hakojima.his", "{$init->dirName}/hakojima.his");
  }
  //---------------------------------------------------
  // 세이프 모드 백업
  //---------------------------------------------------
  function safemode_backup() {
    global $init;

    if($init->backupTimes <= 0)
      return;
    
    for($i = ($init->backupTimes - 1); $i > 0; $i--) {
      $from = $i - 1;
      // 데이터 디렉토리를 연다
      $dir = opendir("./{$init->dirName}.bak{$from}");
      while($copyFile = readdir($dir)) {
        if(is_file("{$init->dirName}.bak{$from}/{$copyFile}")) {
          // 카피원
          $from_copy = "{$init->dirName}.bak{$from}/{$copyFile}";
          // 카피처
          $to_copy = "{$init->dirName}.bak{$i}/{$copyFile}";
    
          // 카피 실행
          copy($from_copy, $to_copy);
        }
      }
    }
    // 데이터 디렉토리를 연다
    $dir = opendir("./{$init->dirName}");
    while($copyFile = readdir($dir)) {
      if(is_file("{$init->dirName}/{$copyFile}")) {
        // 카피원
        $from_copy = "{$init->dirName}/{$copyFile}";
        // 카피처
        $to_copy = "{$init->dirName}.bak0/{$copyFile}";
    
        // 카피 실행
        copy($from_copy, $to_copy);
      }
    }
  }
  //---------------------------------------------------
  // 불필요한 디렉토리와 파일을 삭제
  //---------------------------------------------------
  function rmTree($dirName) {
    if(is_dir("{$dirName}")) {
      $dir = opendir("{$dirName}/");
      while($fileName = readdir($dir)) {
        if(!(strcmp($fileName, ".") == 0 || strcmp($fileName, "..") == 0))
          unlink("{$dirName}/{$fileName}");
      }
      closedir($dir);
      rmdir($dirName);
    }
  }
}

?>
