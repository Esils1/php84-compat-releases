<?php
/*******************************************************************

  모형정원 제도 2 for PHP

  
  $Id: hako-html.php,v 1.10 2004/02/14 15:51:35 watson Exp $

*******************************************************************/

if(GZIP == true) {
  // gzip 압축 전송용
  require_once "HTTP/Compress.php";
  $http = new HTTP_Compress;
}

//--------------------------------------------------------------------
class HTML {

  //---------------------------------------------------
  //  HTML 헤더 출력
  //---------------------------------------------------
  function header($data = "") {
    global $init;
    global $PRODUCT_VERSION;

    // 압축 전송
    if(GZIP == true) {
      global $http;
      $http->start();
    }
    header("X-Product-Version: {$PRODUCT_VERSION}");
    $css = (empty($data['defaultSkin'])) ? $init->cssList[0] : $data['defaultSkin'];
    $bimg =  (empty($data['defaultImg'])) ? $init->imgDir : $data['defaultImg'];
    print <<<END
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html lang="ja">
<head>
<base href="{$bimg}/">
<meta http-equiv="Content-type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<link rel="stylesheet" type="text/css" href="{$init->cssDir}/{$css}">
<title>{$init->title}</title>
<script type="text/javascript" src="{$init->baseDir}/hako.js"></script>
</head>
<body>

<div id="LinkHeader">
[<a href="http://usagi.s31.xrea.com/">모형정원 제도 B.R 배포원</a>]
[<a href="{$GLOBALS['THIS_FILE']}?mode=conf">섬의 등록·설정 변경</a>]
[<a href="{$GLOBALS['THIS_FILE']}?mode=log">최근의 사건</a>]
[<a href="{$init->urlBbs}" target="_blank">게시판</a>]
[<A HREF="https://esils.com/hako/br3/hako-mente.php" target="main">관리모드</A>]
[<A HREF="https://esils.com/hako/br3/" target="main">홈으로 돌아가기</A>]
</div>
<hr>

END;
  }
  //---------------------------------------------------
  // HTML footer 출력
  //---------------------------------------------------
  function footer() {
    global $init;

    print <<<END
<hr>
<div id="LinkFoot">
관리자 : {$init->adminName}(<a href="mailto:{$init->adminEmail}">{$init->adminEmail}</a>)<br>
게시판(<a href="{$init->urlBbs}">{$init->urlBbs}</a>)<br>
탑 페이지(<a href="{$init->urlTopPage}">{$init->urlTopPage}</a>)
<br><div align="right">
END;

    if($init->performance) {
        list($tmp1, $tmp2) = split(" ", $init->CPU_start);
        list($tmp3, $tmp4) = split(" ", microtime());
        printf("<SMALL></SMALL>", $tmp4-$tmp2+$tmp3-$tmp1);
    }

    print <<<END
</div>
</div>
</body>
</html>

END;

    if(GZIP == true) {
      global $http;
      $http->output();
    }
  }
  //---------------------------------------------------
  // 최종 갱신 시각 ＋ 다음 턴 갱신 시각 출력
  //---------------------------------------------------
  function lastModified($hako) {
    global $init;
    $timeString = date("Y년 m월 d일　H시", $hako->islandLastTime);
    print <<<END
<h2 class="lastModified">최종 갱신 시간 : $timeString
<span style="font-weight: normal;">
END;

    // 종료 조건의 판정
    if($init->finish == 0){ $init->finish = 1; }
    if(($hako->islandNumber == $init->finish) && ($hako->islandTurn > 1)) {
      print "<span class='attention'>(게임 종료)</span>\n";
    } else {
      print <<<END
(다음의 턴까지, 나머지
<script type="text/javascript"> <!--
 var nextTime = $hako->islandLastTime + $init->unitTime;
 remainTime(nextTime);
//-->
</script>
END;
    }
    print <<<END
</span>
</h2>

END;
   }
}
//--------------------------------------------------------------------
class HtmlTop extends HTML {
  //---------------------------------------------------
  // TOP 페이지
  //---------------------------------------------------
  function main($hako, $data) {
    global $init;

    // 최종 갱신 시각 ＋ 다음 턴 갱신 시각 출력
    $this->lastModified($hako);
    if(empty($data['defaultDevelopeMode']) || $data['defaultDevelopeMode'] == "cgi") {
      $radio = "checked"; $radio2 = "";
    } else {
      $radio = ""; $radio2 = "checked";
    }

    $nextDeadTurn = 0;
    while(($hako->islandTurn >= $nextDeadTurn)||($init->stopTurn >= $nextDeadTurn)){
      $nextDeadTurn += $init->turnDead;
    }

    if($hako->islandNumber > 0){
      $ccc = (int)(50/$hako->islandNumber);
    }

    $mode = ($hako->islandTurn < $init->stopTurn)  ?  '정전 기간' : '전투 기간';

    $win = "";
    if($init->finish == 0){ $init->finish = 1; }
    if(($hako->islandNumber == $init->finish) && ($hako->islandTurn > 1)) {
      $win .= "승자!";
    }

    print "<h1>{$init->title}</h1>\n";
    if(DEBUG == true) {
      print <<<END
<form action="{$GLOBALS['THIS_FILE']}" method="post">
<input type="hidden" name="mode" value="debugTurn">
<input type="submit" value="턴을 진행시킨다">
</form>

END;
  }
    print <<<END
<h2 class='Turn'>턴$hako->islandTurn(다음번 $mode)</h2><br>
다음번<font size=4>{$nextDeadTurn}턴눈</font></span>에 최하정도의 섬소멸<br>
점유율<font size=4>$ccc%미만</font></span>으로 소멸<br>
<hr>
<TABLE BORDER=0 width="100%">
<TR valign="top">
<TD width="50%" class="M">
<div id="MyIsland">
<h2>자신 섬에</h2>
<form action="{$GLOBALS['THIS_FILE']}" method="post">
당신 섬의 이름은?<br>
<select name="ISLANDID">
$hako->islandList
</select>
<br>
패스워드를 부탁합니다!<br>
<input type="password" name="PASSWORD" value="{$data['defaultPassword']}" size="32" maxlength="32"><br>
<input type="hidden" name="mode" value="owner">
<input type="radio" name="DEVELOPEMODE" value="cgi" id="cgi" $radio><label for="cgi">통상 모드</label>
<input type="radio" name="DEVELOPEMODE" value="java" id="java" $radio2><label for="java">Java 스크립트 모드</label><BR>
<input type="submit" value="개발하러 간다">
</form>
</div>
</TD>
<TD width="50%" class="M">
END;

    $this->infoPrint();    // 「소식」을 표시
//  $this->historyPrint(); // 「발견의 기록」을 표시

    print <<<END
</TD></TR></TABLE>

<hr>

<div ID="IslandView">
<h2>제도의 상황
END;
if($hako->islandNumber != 0) {
  $islandListStart = $data['islandListStart'];
  if($init->islandListRange == 0) {
    $islandListSentinel = $hako->islandNumber;
  } else {
    $islandListSentinel = $islandListStart + $init->islandListRange - 1;
    if($islandListSentinel > $hako->islandNumber) {
      $islandListSentinel = $hako->islandNumber;
    }
  }
  print " [" . $islandListStart . " - " . $islandListSentinel . "명]";
}
print <<<END
</h2>
<p>섬의 이름을 클릭하면<strong>관광</strong>할 수가 있습니다. <br>
END;
if(($islandListStart != 1) || ($islandListSentinel != $hako->islandNumber)) {
  for($i = 1 ; $i <= $hako->islandNumber; $i += $init->islandListRange) {
    $j = $i + $init->islandListRange - 1;
    if($j > $hako->islandNumber) {
      $j = $hako->islandNumber;
    }
    print " ";
    if($i != $islandListStart) {
      print "<a href=\"" .$GLOBALS['THIS_FILE'] . "?islandListStart=" . $i ."\">";
    }
    print " [ ". $i . " - " . $j . " ]";
    if($i != $islandListStart) {
      print "</a>";
    }
  }
}
print <<<END
</p>
<table border="1">
<tr>
<th {$init->bgTitleCell}>{$init->tagTH_}순위{$init->_tagTH}</th>
<th {$init->bgTitleCell}>{$init->tagTH_}섬{$init->_tagTH}</th>
<th {$init->bgTitleCell}>{$init->tagTH_}인구/점유율{$init->_tagTH}</th>
<th {$init->bgTitleCell}>{$init->tagTH_}면적{$init->_tagTH}</th>
<th {$init->bgTitleCell}>{$init->tagTH_}자금{$init->_tagTH}</th>
<th {$init->bgTitleCell}>{$init->tagTH_}식량{$init->_tagTH}</th>
<th {$init->bgTitleCell}>{$init->tagTH_}농장 규모{$init->_tagTH}</th>
<th {$init->bgTitleCell}>{$init->tagTH_}공장 규모{$init->_tagTH}</th>
<th {$init->bgTitleCell}>{$init->tagTH_}채굴장 규모{$init->_tagTH}</th>
<th {$init->bgTitleCell}>{$init->tagTH_}M발사{$init->_tagTH}</th>
<th {$init->bgTitleCell}>{$init->tagTH_}M비 와{$init->_tagTH}</th>
<th {$init->bgTitleCell}>{$init->tagTH_}S탄{$init->_tagTH}</th>
</tr>

END;

    for($i = 0; $i < $hako->islandNumber; $i++){
      $allpop += $hako->islands[$i]['pop'];
    }

    $islandListStart--;
    for($i = $islandListStart; $i < $islandListSentinel ; $i++) {
      $island = $hako->islands[$i];
      $j = $i + 1;

      // 점유율
      $occu = (int)(($island['pop']*100)/$allpop);
      if($occu > 100){ $occu = 100; }

      $id    = $island['id'];
      $pop   = $island['pop'] . $init->unitPop;
      $area  = $island['area'] . $init->unitArea;
      $money = Util::aboutMoney($island['money']);
      $food  = $island['food'] . $init->unitFood;
      $farm  = ($island['farm'] <= 0) ? "보유 안함" : $island['farm'] * 10 . $init->unitPop;
      $factory  = ($island['factory'] <= 0) ? "보유 안함" : $island['factory'] * 10 . $init->unitPop;
      $mountain = ($island['mountain'] <= 0) ? "보유 안함" : $island['mountain'] * 10 . $init->unitPop;
      $comment  = $island['comment'];
      $comment_turn = $island['comment_turn'];
      $monster = '';
      if($island['monster'] > 0) {
        $monster = "<strong class=\"monster\">[괴수{$island['monster']}몸]</strong>";
      }
      
      $name = "";
      if($island['absent']  == 0) {
        $name = "{$init->tagName_}{$island['name']}섬{$init->_tagName}";
      } else {
        $name = "{$init->tagName2_}{$island['name']}섬({$island['absent']}){$init->_tagName2}";
      }
      if(!empty($island['owner'])) {
        $owner = $island['owner'];
      } else {
        $owner = "코멘트";
      }
      
      $prize = $island['prize'];
      $prize = $hako->getPrizeList($prize);

      if($init->commentNew > 0 && ($comment_turn + $init->commentNew) > $hako->islandTurn) {
        $comment .= " <span class=\"new\">New</span>";
      }
      
      print "<tr>\n";
      print "<th {$init->bgNumberCell} rowspan=\"2\">{$init->tagNumber_}$j{$init->_tagNumber}</th>\n";
      print "<td {$init->bgNameCell} rowspan=\"2\"><a href=\"{$GLOBALS['THIS_FILE']}?Sight={$id}\">{$win}{$name}</a> {$monster}<br>\n{$prize}</td>\n";

      print "<td {$init->bgInfoCell}>{$pop}/{$occu}%</td>\n";
      print "<td {$init->bgInfoCell}>$area</td>\n";
      print "<td {$init->bgInfoCell}>$money</td>\n";
      print "<td {$init->bgInfoCell}>$food</td>\n";
      print "<td {$init->bgInfoCell}>$farm</td>\n";
      print "<td {$init->bgInfoCell}>$factory</td>\n";
      print "<td {$init->bgInfoCell}>$mountain</td>\n";
      print "<td {$init->bgInfoCell}>{$island['mout']}발</td>\n";
      print "<td {$init->bgInfoCell}>{$island['min']}발</td>\n";
      print "<td {$init->bgInfoCell}>{$island['now']}발</td>\n";
      print "</tr>\n";
      print "<tr>\n";
      print "<td {$init->bgCommentCell} colspan=\"10\">{$init->tagTH_}{$owner}:{$init->_tagTH}$comment</td>\n";
      print "</tr>\n";
    }
    print "</table>\n</div>\n";
    print "<hr>\n";
    $this->historyPrint();
  }
  //---------------------------------------------------
  // 섬의 등록과 설정
  //---------------------------------------------------
  function regist(&$hako, $data = "") {
    global $init;
    $this->newDiscovery($hako->islandNumber, $hako->islandTurn);
    $this->changeIslandInfo($hako->islandList);
    $this->changeOwnerName($hako->islandList);
    $this->setStyleSheet();
    $this->setLocalImage($data);
  }
  //---------------------------------------------------
  // 새로운 섬을 찾는다
  //---------------------------------------------------
  function newDiscovery($number, $islandTurn) {
    global $init;

    print "<div id=\"NewIsland\">\n";
    print "<h2>새로운 섬을 찾는</h2>\n";
    if(($number < $init->maxIsland) &&
       (($init->entryTurn == 0) || ($islandTurn < $init->entryTurn))) {
      print <<<END
<form action="{$GLOBALS['THIS_FILE']}" method="post">
어떤 이름을 붙일 예정?<br>
<input type="text" name="ISLANDNAME" size="32" maxlength="32">도<br>
당신의 이름은? (생략가능)<br>
<input type="text" name="OWNERNAME" size="32" maxlength="32"><br>
패스워드는?<br>
<input type="password" name="PASSWORD" size="32" maxlength="32"><br>
만약을 위해 패스워드를 다시 한번<br>
<input type="password" name="PASSWORD2" size="32" maxlength="32"><br>
<input type="hidden" name="mode" value="new">
<input type="submit" value="찾으러 간다">
</form>
END;
    } else {
      if (!($number < $init->maxIsland)) {
        print "섬의 수가 최대수입니다···현재 등록할 수 없습니다.\n";
      } else {
        print "섬의 수가 최대수인가, 그 외의 이유에 의해, 현재 등록할 수 없습니다.\n";
      }
    }
    print "</div>\n";
    print "<hr>\n";
  }
  //---------------------------------------------------
  // 섬의 이름과 패스워드의 변경
  //---------------------------------------------------
  function changeIslandInfo($islandList = "") {
    global $init;
    print <<<END
<div id="ChangeInfo">
<h2>섬의 이름과 패스워드의 변경</h2>
<p>
(주의) 이름의 변경에는 500억 듭니다.
</p>
<form action="{$GLOBALS['THIS_FILE']}" method="post">
어느 섬입니까?<br>
<select NAME="ISLANDID">
$islandList
</select>
<br>
어떤 이름으로 바꿉니까? (변경하는 경우만)<br>
<input type="text" name="ISLANDNAME" size="32" maxlength="32">도<br>
패스워드는? (필수)<br>
<input type="password" name="OLDPASS" size="32" maxlength="32"><br>
새로운 패스워드는? (변경할 때 마셔)<br>
<input type="password" name="PASSWORD" size="32" maxlength="32"><br>
만약을 위해 패스워드를 다시 한번(변경할 때 마셔)<br>
<input type="password" name="PASSWORD2" size="32" maxlength="32"><br>
<input type="hidden" name="mode" value="change">
<input type="submit" value="변경한다">
</form>
</div>
<hr>

END;
  }
  //---------------------------------------------------
  // 오너명의 변경
  //---------------------------------------------------
  function changeOwnerName($islandList = "") {
    global $init;
    print <<<END
<div id="ChangeOwnerName">
<h2>오너명의 변경</h2>
<form action="{$GLOBALS['THIS_FILE']}" method="post">
어느 섬입니까?<br>
<select name="ISLANDID">
{$islandList}
</select>
<br>
새로운 오너명은? <br>
<input type="text" name="OWNERNAME" size="32" maxlength="32"><br>
패스워드는?<br>
<input type="password" name="OLDPASS" size="32" maxlength="32"><br>
<input type="hidden" name="mode" value="ChangeOwnerName">
<input type="submit" value="변경한다">
</form>
</div>
END;
  }
  //---------------------------------------------------
  // 스타일 시트의 설정
  //---------------------------------------------------
  function setStyleSheet() {
    global $init;
    $styleSheet;
    for($i = 0; $i < count($init->cssList); $i++) {
      $styleSheet .= "<option value=\"{$init->cssList[$i]}\">{$init->cssList[$i]}</option>\n";
    }
    print <<<END
<div id="HakoSkin">
<h2>스타일 시트의 설정</h2>
<form action="{$GLOBALS['THIS_FILE']}" method="post">
<select name="SKIN">
$styleSheet
</select>
<input type="hidden" name="mode" value="skin">
<input type="submit" value="설정">
</form>
</div>
<hr>

END;
  }
  //---------------------------------------------------
  // 화상의 로컬 설정
  //---------------------------------------------------
  function setLocalImage($data = "") {
    global $init;
    $Himgflag;
    if(empty($data['defaultImg']) || (strcmp($data['defaultImg'], $init->imgDir) == 0)){
      $Himgflag = '<span class=attention>미설정</span>';
    } else {
      $Himgflag = $data['defaultImg'];
    }
    print <<<END
<div id="localImage">
<h2>화상의 로컬 설정</h2>
<table border width=50%><tr><td class='N'>
화상 전송에 의한 서버에의 부하를 경감할 뿐만 아니라, 당신의 PC에 있는 화상을 호출하므로, 표시 스피드가 비약적으로 올라갑니다.<br>
화상은<B><a href="{$init->imgPack}">여기</a></B>로부터 다운로드해, 1개의 폴더에 해동해, 아래의 설정으로 「land0.gif」를 지정해 주세요.<br>
자세하게는<B><a href="{$init->imgExp}">설명의 페이지</a></B>를 봐 주세요.
</td></tr></table>
<table border=0 width=50%><tr><td class="M">
현재의 설정<B>[</B> ${Himgflag} <B>]</B>
<form action="{$GLOBALS['THIS_FILE']}" method="post">
<input type=file name="IMGLINE">
<input type="hidden" name="mode" value="imgset">
<input type="submit" value="설정">
</form>

<form action="{$GLOBALS['THIS_FILE']}" method="post">
<input type=hidden name="IMGLINE" value="delete">
<input type="hidden" name="mode" value="imgset">
<input type="submit" value="설정을 해제한다">
</form>
</td></tr></table>
</div>
<hr>

END;
  }
  //---------------------------------------------------
  // 최근의 사건
  //---------------------------------------------------
  function log() {
    global $init;
    print "<CENTER>{$GLOBALS['BACK_TO_TOP']}</CENTER>";
    print "<div id=\"RecentlyLog\">\n";
    print "<h2>최근의 사건</h2>\n";
    for($i = 0; $i < $init->logTopTurn; $i++) {
      LogIO::logFilePrint($i, 0, 0);
    }
    print "</div>\n";
  }
  //---------------------------------------------------
  // 발견의 기록
  //---------------------------------------------------
  function historyPrint() {
    print "<div id=\"HistoryLog\">\n";
    print "<h2>발견의 기록</h2>";
    LogIO::historyPrint();
    print "</div>\n";
  }
  //---------------------------------------------------
  // 소식
  //---------------------------------------------------
  function infoPrint() {
    global $init;
    print "<div id=\"HistoryLog\">\n";
    print "<h2>소식</h2>\n";
    print "<DIV style=\"overflow:auto; height:{$init->divHeight}px;\">\n";
    LogIO::infoPrint();
    print "</div></div>\n";
  }
}
//------------------------------------------------------------------
class HtmlMap extends HTML {
  //---------------------------------------------------
  // 개발 화면
  //---------------------------------------------------
  function owner($hako, $data) {
    global $init;
    $id     = $data['ISLANDID'];
    $number = $hako->idToNumber[$id];
    $island = $hako->islands[$number];

    // 패스워드 체크
    if(!Util::checkPassword($island['password'], $data['PASSWORD'])){
      HakoHakoError::wrongPassword();
      return;
    }
    $this->tempOwer($hako, $data, $number);
    
    //IP정보 취득
    $logfile = $init->logname;
    $ax = $init->axesmax - 1;
    $log = file($logfile);
    $fp = fopen($logfile,"w"); 
    $timedata =date ("Y년 m월 d일(D) H시 i분 s초");
    $islandID = "<center>{$data['ISLANDID']}</center>";
    $name = "{$island['name']}섬";
    $ip = getenv("REMOTE_ADDR");
    $host = gethostbyaddr(getenv("REMOTE_ADDR"));
    fputs($fp,$timedata.",".$islandID.",".$name.",".$ip.",".$host."\n");
    for($i=0; $i<$ax; $i++) fputs($fp,$log[$i]);
    fclose($fp);

    if($init->useBbs) {
      print "<div id=\"localBBS\">\n";
      $this->lbbsHead($island);
      $this->lbbsInputOW($island, $data);
      $this->lbbsContents($hako, $island, 1);
      print "</div>\n";
    }
    $this->islandRecent($island, 1);
  }

  //---------------------------------------------------
  // 관광 화면
  //---------------------------------------------------
  function visitor($hako, $data, $speakerID = 0) {
    global $init;
    $id     = $data['ISLANDID'];
    $number = $hako->idToNumber[$id];
    $island = $hako->islands[$number];

    $win = "";
    if($init->finish == 0){ $init->finish = 1; }
    if(($hako->islandNumber == $init->finish) && ($hako->islandTurn > 1)) {
      $win .= "【승자! 】";
    }

    print <<<END
<div align="center">
{$init->tagBig_}{$init->tagName_}턴{$win}{$island['name']}섬{$init->_tagName}거치자야말로!{$init->_tagBig}<br>
{$GLOBALS['BACK_TO_TOP']}<br>
</div>

END;

    $this->islandInfo($island, $number, 0);
    $this->islandMap($hako, $island, 0);
    // 다른 섬에
    print <<<END
<div align="center"><form action="{$GLOBALS['THIS_FILE']}" method="get">
<select name="Sight">$hako->islandList</select><input type="submit" value="관광">
</form></div>
END;

    if($init->useBbs) {
      print "<div id=\"localBBS\">\n";
      $this->lbbsHead($island);
      $this->lbbsInput($hako, $island, $data);
      $this->lbbsContents($hako, $island, 0, $speakerID);
      print "</div>\n";
    }
    $this->islandRecent($island, 0);
  }
  //---------------------------------------------------
  // 섬의 정보
  //---------------------------------------------------
  function islandInfo($island, $number = 0, $mode = 0) {
    global $init;
    $rank = $number + 1;
    $pop   = $island['pop'] . $init->unitPop;
    $area  = $island['area'] . $init->unitArea;
    $money = ($mode == 0) ? Util::aboutMoney($island['money']) : "{$island['money']}{$init->unitMoney}";
    $food  = $island['food'] . $init->unitFood;
    $farm  = ($island['farm'] <= 0) ? "보유 안함" : $island['farm'] * 10 . $init->unitPop;
    $factory  = ($island['factory'] <= 0) ? "보유 안함" : $island['factory'] * 10 . $init->unitPop;
    $mountain = ($island['mountain'] <= 0) ? "보유 안함" : $island['mountain'] * 10 . $init->unitPop;
    $comment  = $island['comment'];

    print <<<END
<div id="islandInfo">
<table border="1">
<tr>
<th {$init->bgTitleCell}>{$init->tagTH_}순위{$init->_tagTH}</th>
<th {$init->bgTitleCell}>{$init->tagTH_}인구{$init->_tagTH}</th>
<th {$init->bgTitleCell}>{$init->tagTH_}면적{$init->_tagTH}</th>
<th {$init->bgTitleCell}>{$init->tagTH_}자금{$init->_tagTH}</th>
<th {$init->bgTitleCell}>{$init->tagTH_}식량{$init->_tagTH}</th>
<th {$init->bgTitleCell}>{$init->tagTH_}농장 규모{$init->_tagTH}</th>
<th {$init->bgTitleCell}>{$init->tagTH_}공장 규모{$init->_tagTH}</th>
<th {$init->bgTitleCell}>{$init->tagTH_}채굴장 규모{$init->_tagTH}</th>
</tr>
<tr>
<th {$init->bgNumberCell}>{$init->tagNumber_}$rank{$init->_tagNumber}</th>
<td {$init->bgInfoCell}>$pop</td>
<td {$init->bgInfoCell}>$area</td>
<td {$init->bgInfoCell}>$money</td>
<td {$init->bgInfoCell}>$food</td>
<td {$init->bgInfoCell}>$farm</td>
<td {$init->bgInfoCell}>$factory</td>
<td {$init->bgInfoCell}>$mountain</td>
</tr>
<tr>
<td colspan="8" {$init->bgCommentCell}>$comment</td>
</tr>
</table>
</div>
<center>
<table border="1">
<tr>
<th {$init->bgTitleCell}>{$init->tagTH_}소유 네이팜탄{$init->_tagTH}</th>
<th {$init->bgTitleCell}>{$init->tagTH_}미사일 발사{$init->_tagTH}</th>
<th {$init->bgTitleCell}>{$init->tagTH_}미사일 발사(총계){$init->_tagTH}</th>
<th {$init->bgTitleCell}>{$init->tagTH_}미사일 비 와{$init->_tagTH}</th>
</tr>
<tr>
<td {$init->bgInfoCell}>{$island['now']}발</td>
<td {$init->bgInfoCell}>{$island['mout']}발</td>
<td {$init->bgInfoCell}>{$island['total']}발</td>
<td {$init->bgInfoCell}>{$island['min']}발</td>
</tr>
</table>
</center>
END;
  }
  //---------------------------------------------------
  // 지형 출력
  // $mode = 1 -- 미사일 기지등도 표시
  //---------------------------------------------------
  function islandMap($hako, $island, $mode = 0) {
    global $init;
    $land      = $island['land'];
    $landValue = $island['landValue'];
    $command   = $island['command'];
    if($mode == 1) {
      for($i = 0; $i < $init->commandMax; $i++) {
        $j = $i + 1;
        $com = $command[$i];
        if($com['kind'] < 20) {
          $comStr[$com['x']][$com['y']] .=
            "[{$j}]{$init->comName[$com['kind']]} ";
        }
      }
    }

    print "<div id=\"islandMap\" align=\"center\"><table border=\"1\"><tr><td>\n";
    for($y = 0; $y < $init->islandSize; $y++) {
      if($y % 2 == 0) { print "<img src=\"land0.gif\" width=\"16\" height=\"32\" alt=\"{$y}\">"; }

      for($x = 0; $x < $init->islandSize; $x++) {
        $hako->landString($land[$x][$y], $landValue[$x][$y], $x, $y, $mode, $comStr[$x][$y]);
      }

      if($y % 2 == 1) { print "<img src=\"land0.gif\" width=\"16\" height=\"32\" alt=\"{$y}\">"; }

      print "<br>";
    }
    print "<div id=\"NaviView\"></div>";
    print "</td></tr></table></div>\n";
  }
  //---------------------------------------------------
  // 관광자 통신
  //---------------------------------------------------
  function lbbsHead($island) {
    global $init;
    print <<<END
<hr>
<h2>{$island['name']}섬{$init->_tagName}관광자 통신</h2>

END;
  }
  //---------------------------------------------------
  // 관광자 통신 입력 부분
  //---------------------------------------------------
  function lbbsInput($hako, $island, $data) {
    global $init;

    $lbbsAtention = '';
    if($init->lbbsMoneyPublic + $init->lbbsMoneySecret > 0) {
      // 발언은 유료
      $lbbsAtention .= "<CENTER><B>※</B>";
      if($init->lbbsMoneyPublic > 0){
        $lbbsAtention .= "공개 통신은<B>{$init->lbbsMoneyPublic}{$init->unitMoney}</B>입니다.";
      }
      if($init->lbbsMoneySecret > 0){
        $lbbsAtention .= "극비 통신은<B>{$init->lbbsMoneySecret}{$init->unitMoney}</B>입니다.";
      }
      $lbbsAtention .= "</CENTER>";
    }
    $lbbsAnonny = '';
    if ($init->lbbsAnon){
      $lbbsAnonny .= "<input type=\"radio\" name=\"LBBSTYPE\" value=\"ANON\">관광객";
    } else {
      $col = " colspan=2";
    }

    print <<<END
<div align="center">
<form action="{$GLOBALS['THIS_FILE']}" method="post">
{$lbbsAtention}<B>※</B>섬을 가지고 있는 (분)편은 시마나가 코멘트의 후에 다합니다.
<table border="1">
<TR>
<th>이름</th>
<th{$col}>내용</th>
<th>통신 방법</th>
</tr>
<tr>
<td><input type="text" size="32" maxlength="32" name="LBBSNAME" value="{$data['defaultName']}"></td>
<td{$col}><input type="text" size="80" name="LBBSMESSAGE"></td>
<td>
<input type="radio" name="LBBSTYPE" value="PUBLIC" checked>공개
<input type="radio" name="LBBSTYPE" value="SECRET"><font color="red">극비</font>
</td>
</tr>
<tr>
<th>패스워드</th>
<th>시마나</th>
<th{$col}>동작</th>
</tr>
<tr>
<td><input type=password size="16" maxlength="16" name=PASSWORD value="{$data['defaultPassword']}"></td>
<td>
<select name="ISLANDID2">{$hako->islandList}</select>
{$lbbsAnonny}
</td>
<td>
<input type="hidden" name="mode" value="lbbs">
<input type="hidden" name="lbbsMode" value="0">
<input type="hidden" name="ISLANDID" value="{$island['id']}">
<input type="hidden" name="DEVELOPEMODE" value="{$data['DEVELOPEMODE']}">
<input type="submit" value="적는다">
<input type="submit" name="CHK" value="극비 확인"></TD>
END;
    if ($init->lbbsAnon == 0){
      print <<<END
<td align="right">
번호
<select name="NUMBER">
END;
      // 발언 번호
      for($i = 0; $i < $init->lbbsMax; $i++) {
        $j = $i + 1;
        print "<option value=\"{$i}\">{$j}</option>\n";
      }
      print <<<END
</select>
<input type="submit" name="DEL" value="삭제한다">
</td>
END;
    }
    print <<<END
</tr>
</table>
</form>
</div>

END;
  }
  //---------------------------------------------------
  // 관광자 통신 입력 부분 오너용
  //---------------------------------------------------
  function lbbsInputOW($island, $data) {
    global $init;
    print <<<END
<div align="center">
<table border="1">
<form action="{$GLOBALS['THIS_FILE']}" method="post">
<tr>
<th>이름</th>
<th colspan="2">내용</th>
</tr>
<tr>
<td><input type="text" size="32" maxlength="32" name="LBBSNAME" VALUE="{$data['defaultName']}"></TD>
<td colspan="2"><input type="text" size="80" name="LBBSMESSAGE"></td>
</tr>
<tr>
<th colspan="2">동작</th>
</tr>
<tr>
<td align="right">
<input type="hidden" name="mode" value="lbbs">
<input type="hidden" name="lbbsMode" value="1">
<input type="hidden" name="PASSWORD" value="{$data['defaultPassword']}">
<input type="hidden" name="ISLANDID" value="{$island['id']}">
<input type="hidden" name="DEVELOPEMODE" value="{$data['DEVELOPEMODE']}">
<input type="submit" value="적는다">
</td>
<td align="right">
번호
<select name="NUMBER">

END;
    
    // 발언 번호
    for($i = 0; $i < $init->lbbsMax; $i++) {
      $j = $i + 1;
      print "<option value=\"{$i}\">{$j}</option>\n";
    }
    print <<<END
</select>
<input type="submit" name="DEL" value="삭제한다">
</form>
</td>
</tr>
</table>
</div>

END;
  }
  //---------------------------------------------------
  // 관광자 통신 기입해진 내용을 출력
  //---------------------------------------------------
  function lbbsContents($hako, $island, $owner = 0, $speakerID = 0) {
    global $init;
    $lbbs = $island['lbbs'];
    print <<<END
<div align="center">
<table border="1">
<tr>
<th style="width:3em;">번호</th>
<th>기장 내용</th>
</tr>

END;
    for($i = 0; $i < $init->lbbsMax; $i++) {
      $j = $i + 1;
      $line = $lbbs[$i];
      list($secret, $sTemp, $mode, $turn, $message) = split(">", $line);
      list($sName, $sId) = split(",", $sTemp);
      $sNo = $hako->idToNumber[$sId];
      print "<tr><th>{$init->tagNumber_}{$j}{$init->_tagNumber}</th>";
      $speaker = '';
      if($init->lbbsSpeaker && ($sName != '')) {
        if($sNo == '0' || !empty($sNo)) {
          $speaker = " <font color=gray><b><small>(<a style=\"text-decoration:none\" href=\"{$GLOBALS['THIS_FILE']}?Sight={$sId}\">{$sName}</a>)</small></b></font>";
        } else {
          $speaker = " <font color=gray><b><small>({$sName})</small></b></font>";
        }
      }
      if($mode == 0) {
        // 관광자
        if($secret == 0) {
          // 공개
          print "<td>{$init->tagLbbsSS_}{$turn} &gt; {$message}{$init->_tagLbbsSS} {$speaker}</td></tr>\n";
        } else {
          // 극비
          if(($owner == 0) && (empty($speakerID) || ($sId != $speakerID))) {
            // 관광객
            print "<td><center><font color=gray>- 극비 -{$data['ISLANDID2']}</font></center></td></tr>\n";
          } else {
            // 오너
            print "<td>{$init->tagLbbsSS_}{$turn} &gt;(비) {$message}{$init->_tagLbbsSS} {$speaker}</td></tr>\n";
          }
        }
      } else {
        // 섬주
        print "<td>{$init->tagLbbsOW_}{$turn} &gt; {$message}{$init->_tagLbbsOW}</td></tr>\n";
      }
      
    }
    print "</table></div>\n";
  }
  //---------------------------------------------------
  // 섬의 근황
  //---------------------------------------------------
  function islandRecent($island, $mode = 0) {
    global $init;
    print "<hr>\n";
    print "<div id=\"RecentlyLog\">\n";
    print "<h2>{$island['name']}섬{$init->_tagName}의 근황</h2>\n";
    for($i = 0; $i < $init->logMax; $i++) {
      LogIO::logFilePrint($i, $island['id'], $mode);
    }
    print "</div>\n";
  }
  //---------------------------------------------------
  // 개발 화면
  //---------------------------------------------------
  function tempOwer($hako, $data, $number = 0) {
    global $init;
    $island = $hako->islands[$number];

    $width  = $init->islandSize * 32 + 50;
    $height = $init->islandSize * 32 + 100;
    $defaultTarget = ($init->targetIsland == 1) ? $island['id'] : $hako->defaultTarget;
    print <<<END
<script type="text/javascript">
<!--
var w;
var p = $defaultTarget;
function ps(x, y) {
  document.InputPlan.POINTX.options[x].selected = true;
  document.InputPlan.POINTY.options[y].selected = true;
  return true;
}

function ns(x) {
  document.InputPlan.NUMBER.options[x].selected = true;
  return true;
}

function settarget(part){
  p = part.options[part.selectedIndex].value;
}
function targetopen() {
  w = window.open("{$GLOBALS['THIS_FILE']}?target=" + p, "","width={$width},height={$height},scrollbars=1,resizable=1,toolbar=1,menubar=1,location=1,directories=0,status=1");
}


//-->
</script>
<div align="center">
{$init->tagBig_}{$init->tagName_}{$island['name']}섬{$init->_tagName}개발 계획{$init->_tagBig}<br>
{$GLOBALS['BACK_TO_TOP']}<br>
</div>

END;
    $this->islandInfo($island, $number, 1);
    print <<<END
<div align="center">
<table border="1">
<tr>
<td {$init->bgInputCell}>
<div align="center">
<form action="{$GLOBALS['THIS_FILE']}" method="post" name="InputPlan">
<input type="hidden" name="mode" value="command">
<input type="hidden" name="ISLANDID" value="{$island['id']}">
<input type="hidden" name="PASSWORD" value="{$data['defaultPassword']}">
<input type="submit" value="계획 송신">
<hr>
<strong>계획 번호</strong>
<select name="NUMBER">

END;
    // 계획 번호
    for($i = 0; $i < $init->commandMax; $i++) {
      $j = $i + 1;
      print "<option value=\"{$i}\">{$j}</option>";
    }
    print <<<END
</select><br>
<hr>
<strong>개발 계획</strong><br>
<select name="COMMAND">

END;
    // 커멘드
    for($i = 0; $i < $init->commandTotal; $i++) {
      $kind = $init->comList[$i];
      $cost = $init->comCost[$kind];
      if($cost == 0) {
        $cost = '무료';
      } elseif($cost < 0) {
        $cost  = - $cost;
        $cost .= $init->unitFood;
      } else {
        $cost .= $init->unitMoney;
      }
      if($kind == $data['defaultKind']) {
        $s = 'selected';
      } else {
        $s = '';
      }
      print "<option value=\"{$kind}\" {$s}>{$init->comName[$kind]}({$cost})</option>\n";
    }
    print <<<END
</select>
<hr>
<strong>좌표(</strong>
<select name="POINTX">

END;
    for($i = 0; $i < $init->islandSize; $i++) {
      if($i == $data['defaultX']) {
        print "<option value=\"{$i}\" selected>{$i}</option>\n";
      } else {
        print "<option value=\"{$i}\">{$i}</option>\n";
      }
    }
    print "</select>, <select name=\"POINTY\">";
    for($i = 0; $i < $init->islandSize; $i++) {
      if($i == $data['defaultY']) {
        print "<option value=\"{$i}\" selected>{$i}</option>\n";
      } else {
        print "<option value=\"{$i}\">{$i}</option>\n";
      }
    }
    print <<<END
</select><strong>)</strong>
<hr>
<strong>수량</strong>
<select name="AMOUNT">

END;
     for($i = 0; $i < 100; $i++)
       print "<option value=\"{$i}\">{$i}</option>\n";

     print <<<END
</select>
<hr>
<strong>목표의 섬</strong><br>
<select name="TARGETID" onchange="settarget(this);">
$hako->targetList
</select>
<input type="button" value="목표 포착" onClick="javascript: targetopen();">
<hr>
<strong>동작</strong><br>
<input type="radio" name="COMMANDMODE" id="insert" value="insert" checked><label for="insert">삽입</label>
<input type="radio" name="COMMANDMODE" id="write" value="write"><label for="write">덧쓰기</label><BR>
<input type="radio" name="COMMANDMODE" id="delete" value="delete"><label for="delete">삭제</label>
<hr>
<input type="hidden" name="DEVELOPEMODE" value="cgi">
<input type="submit" value="계획 송신">
</form>
<center>미사일 발사 상한수[<b> {$island['fire']} </b>]발</center>
</div>
</td>
<td {$init->bgMapCell}>

END;
    $this->islandMap($hako, $island, 1);    // 섬의 지도, 소유자 모드
    print <<<END
</td>
<td {$init->bgCommandCell}>
END;
    $command = $island['command'];
    for($i = 0; $i < $init->commandMax; $i++) {
      $this->tempCommand($i, $command[$i], $hako);
    }
    print <<<END
</td>
</tr>
</table>
</div>
<hr>
<div id='CommentBox'>
<h2>코멘트 갱신</h2>
<form action="{$GLOBALS['THIS_FILE']}" method="post">
코멘트<input type="text" name="MESSAGE" size="80" value="{$island['comment']}"><br>
<input type="hidden" name="PASSWORD" value="{$data['defaultPassword']}">
<input type="hidden" name="mode" value="comment">
<input type="hidden" name="ISLANDID" value="{$island['id']}">
<input type="hidden" name="DEVELOPEMODE" value="cgi">
<input type="submit" value="코멘트 갱신">
</form>
</div>

END;

  }
  //---------------------------------------------------
  // 입력이 끝난 커멘드 표시
  //---------------------------------------------------
  function tempCommand($number, $command, $hako) {
    global $init;

    $kind   = $command['kind'];
    $target = $command['target'];
    $x      = $command['x'];
    $y      = $command['y'];
    $arg    = $command['arg'];

    $comName = "{$init->tagComName_}{$init->comName[$kind]}{$init->_tagComName}";
    $point   = "{$init->tagName_}({$x},{$y}){$init->_tagName}";
    $target  = $hako->idToName[$target];
    if(empty($target)) {
      $target = "무인";
    }
    $target = "{$init->tagName_}{$target}섬{$init->_tagName}";
    $value = $arg * $init->comCost[$kind];
    if($value == 0) {
      $value = $init->comCost[$kind];
    }
    if($value < 0) {
      $value = -$value;
      $value = "{$value}{$init->unitFood}";
    } else {
      $value = "{$value}{$init->unitMoney}";
    }
    $value = "{$init->tagName_}{$value}{$init->_tagName}";

    $j = sprintf("%02d", $number + 1);

    print "<a href=\"javascript:void(0);\" onclick=\"ns({$number})\">{$init->tagNumber_}{$j}{$init->_tagNumber}";

    switch($kind) {
    case $init->comMissileSM:
    case $init->comDoNothing:
    case $init->comGiveup:
    case $init->comPropaganda:
      $str = "{$comName}";
      break;
    case $init->comMissileNM:
    case $init->comMissilePP:
    case $init->comMissileST:
    case $init->comMissileLD:
      // 미사일계
      $n = ($arg == 0) ? '무제한' : "{$arg}발";
      $str = "{$target}{$point}귉{$comName}({$init->tagName_}{$n}{$init->_tagName})";
      break;
    case $init->comMissileNB:
      // 네이팜탄 
      $str = "{$target}{$point}에{$comName}";
      break;
    case $init->comSendMonster:
      // 괴수 파견
      $str = "{$target}에{$comName}";
      break;
    case $init->comSell:
      // 식량 수출
      $str ="{$comName}{$value}";
      break;
    case $init->comDestroy:
      // 굴착
      if($arg != 0) {
        $str = "{$point}로{$comName}(예산{$value})";
      } else {
        $str = "{$point}로{$comName}";
      }
      break;
    case $init->comFarm:
    case $init->comFactory:
    case $init->comMountain:
      // 회수 첨부
      if($arg == 0) {
        $str = "{$point}로{$comName}";
      } else {
        $str = "{$point}로{$comName}({$arg}회)";
      }      
      break;
    default:
      // 좌표 첨부
      $str = "{$point}로{$comName}";
    }

    print "{$str}</a><br>";
  }
  //---------------------------------------------------
  // 새롭게 발견한 섬
  //---------------------------------------------------
  function newIslandHead($name) {
    global $init;
    print <<<END
<div align="center">
{$init->tagBig_}섬을 발견했습니다!{$init_tagBig}<br>
{$init->tagBig_}{$init->tagName_}「{$name}섬」{$init->_tagName}라고 명명합니다. {$init->_tagBig}<br>
{$GLOBALS['BACK_TO_TOP']}<br>
</div>
END;
  }
  //---------------------------------------------------
  // 목표 포착 모드
  //---------------------------------------------------
  function printTarget($hako, $data) {
    global $init;
    // id로부터 섬번호를 취득
    $id     = $data['ISLANDID'];
    $number = $hako->idToNumber[$id];
    // 왠지 그 섬이 없는 경우
    if($number < 0 || $number > $hako->islandNumber) {
      HakoHakoError::problem();
      return;
    }
    $island = $hako->islands[$number];

print <<<END
<script type="text/javascript">
<!--
function ps(x, y) {
  window.opener.document.InputPlan.POINTX.options[x].selected = true;
  window.opener.document.InputPlan.POINTY.options[y].selected = true;
  return true;
}
//-->
</script>

<div align="center">
{$init->tagBig_}{$init->tagName_}{$island['name']}섬{$init->_tagName}{$init->_tagBig}<br>
</div>

END;

    //섬의 지도
    $this->islandMap($hako, $island, 2);

  }
}
//------------------------------------------------------------------
class HtmlJS extends HtmlMap {
  function header($data = "") {
    global $init;
    global $PRODUCT_VERSION;

    // 압축 전송
    if(GZIP == true) {
      global $http;
      $http->start();
    }
    header("X-Product-Version: {$PRODUCT_VERSION}");
    $css = (empty($data['defaultSkin'])) ? $init->cssList[0] : $data['defaultSkin'];
    $bimg = (empty($data['defaultImg'])) ? $init->imgDir : $data['defaultImg'];
    print <<<END
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html lang="ja">
<head>
<base href="{$bimg}/">
<meta http-equiv="Content-type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<link rel="stylesheet" type="text/css" href="{$init->cssDir}/{$css}">
<title>{$init->title}</title>
<script type="text/javascript" src="{$init->baseDir}/hako.js"></script>
</head>
<body onload="init()">
<div id="LinkHeader">
[<a href="http://usagi.s31.xrea.com/">모형정원 제도 B.R 배포원</a>]?
[<a href="{$GLOBALS['THIS_FILE']}?mode=conf">섬의 등록·설정 변경</a>]?
[<a href="{$init->urlBbs}" target="_blank">게시판</a>]
</div>
<hr>

END;
  }
  //---------------------------------------------------
  // 개발 화면
  //---------------------------------------------------
  function tempOwer($hako, $data, $number = 0) {
    global $init;
    $island = $hako->islands[$number];

    $width  = $init->islandSize * 32 + 50;
    $height = $init->islandSize * 32 + 100;

    // 커멘드 세트
    $set_com = "";
    $com_max = "";
    for($i = 0; $i < $init->commandMax; $i++) {
      // 각 요소의 꺼내
      $command  = $island['command'][$i];
      $s_kind   = $command['kind'];
      $s_target = $command['target'];
      $s_x      = $command['x'];
      $s_y      = $command['y'];
      $s_arg    = $command['arg'];

      // 커멘드 등록
      if($i == $init->commandMax - 1){
        $set_com .= "[$s_kind, $s_x, $s_y, $s_arg, $s_target]\n";
        $com_max .= "0";
      } else {
        $set_com .= "[$s_kind, $s_x, $s_y, $s_arg, $s_target],\n";
        $com_max .= "0,";
      }
    }

    //커멘드 리스트 세트
    $l_kind;
    $set_listcom = "";
    $click_com = "";
    $click_com2 = "";
    $All_listCom = 0;
    $com_count = count($init->commandDivido);
    for($m = 0; $m < $com_count; $m++) {
      list($aa,$dd,$ff) = split(",", $init->commandDivido[$m]);
      $set_listcom .= "[ ";
      for($i = 0; $i < $init->commandTotal; $i++) {
        $l_kind = $init->comList[$i];
        $l_cost = $init->comCost[$l_kind];
        if($l_cost == 0) {
          $l_cost = '무료';
        } elseif($l_cost < 0) {
          $l_cost = - $l_cost; $l_cost .= $init->unitFood;
        } else {
          $l_cost .= $init->unitMoney;
        }
        if($l_kind > $dd-1 && $l_kind < $ff+1) {
          $set_listcom .= "[$l_kind, '{$init->comName[$l_kind]}', '{$l_cost}'],\n";
          if($m == 0){
            $click_com .= "<a href='javascript:void(0);' onclick='cominput(InputPlan, 6, {$l_kind})' onkeypress='cominput(InputPlan, 6, {$l_kind})' style='text-decoration:none'>{$init->comName[$l_kind]}({$l_cost})</a><br>\n";
          } elseif($m == 1) {
            $click_com2 .= "<a href='javascript:void(0);' onclick='cominput(InputPlan, 6, {$l_kind})' onkeypress='cominput(InputPlan, 6, {$l_kind})' style='text-decoration:none'>{$init->comName[$l_kind]}({$l_cost})</a><br>\n";
          }
          $All_listCom++;
        }
        if($l_kind < $ff+1) { next; }
      }
      $bai = strlen($set_listcom);
      $set_listcom = substr($set_listcom, 0, $bai - 2);
      $set_listcom .= " ],\n";
    }
    $bai = strlen($set_listcom);
    $set_listcom = substr($set_listcom, 0, $bai - 2);
    if(empty($data['defaultKind'])) {
      $default_Kind = 1;
    } else {
      $default_Kind = $data['defaultKind'];
    }

    // 섬리스트 세트
    $set_island = "";
    for($i = 0; $i < $hako->islandNumber; $i++) {
      $l_name = $hako->islands[$i]['name'];
      $l_name = preg_replace("/'/", "\'", $l_name);
      $l_id = $hako->islands[$i]['id'];
      if($i == $hako->islandNumber - 1){
        $set_island .= "[$l_id, '$l_name']\n";
      }else{
        $set_island .= "[$l_id, '$l_name'],\n";
      }
    }
    $defaultTarget = ($init->targetIsland == 1) ? $island['id'] : $hako->defaultTarget;

    print <<<END
<center>
{$init->tagBig_}{$init->tagName_}{$island['name']}섬{$init->_tagName}개발 계획{$init->_tagBig}<BR>
{$GLOBALS['BACK_TO_TOP']}<br>
</center>
<script type="text/javascript">
<!--
var w;
var p = $defaultTarget;

// JAVA 스크립트 개발 화면 배포원
// -암모형정원 제도( http://appoh.execweb.cx/hakoniwa/ )
// Programmed by Jynichi Sakai(―)
// ↑ 삭제하지 마세요.
var str;
g = [$com_max];
k1 = [$com_max];
k2 = [$com_max];
tmpcom1 = [ [0,0,0,0,0] ];
tmpcom2 = [ [0,0,0,0,0] ];
command = [
$set_com];

comlist = [
$set_listcom
];

islname = [
$set_island];


function init() {
  for(i = 0; i < command.length ;i++) {
    for(s = 0; s < $com_count ;s++) {
      var comlist2 = comlist[s];
      for(j = 0; j < comlist2.length ; j++) {
        if(command[i][0] == comlist2[j][0]) {
          g[i] = comlist2[j][1];
        }
      }
    }
  }
  SelectList('');
  outp();
  str = plchg();
  str = '<font color="blue">■ 송신이 끝난 ■<\\/font><br>' + str;
  disp(str, "");

  if(document.layers) {
    document.captureEvents(Event.MOUSEMOVE | Event.MOUSEUP);
  }
  document.onmouseup   = Mup;
  document.onmousemove = Mmove;
  document.onkeydown = Kdown;
  document.ch_numForm.AMOUNT.options.length = 100;
  for(i=0;i<document.ch_numForm.AMOUNT.options.length;i++){
    document.ch_numForm.AMOUNT.options[i].value = i;
    document.ch_numForm.AMOUNT.options[i].text  = i;
  }
  document.InputPlan.SENDPROJECT.disabled = true;
  ns(0);
}

function cominput(theForm, x, k, z) {
  a = theForm.NUMBER.options[theForm.NUMBER.selectedIndex].value;
  b = theForm.COMMAND.options[theForm.COMMAND.selectedIndex].value;
  c = theForm.POINTX.options[theForm.POINTX.selectedIndex].value;
  d = theForm.POINTY.options[theForm.POINTY.selectedIndex].value;
  e = theForm.AMOUNT.options[theForm.AMOUNT.selectedIndex].value;
  f = theForm.TARGETID.options[theForm.TARGETID.selectedIndex].value;
  if(x == 6){ b = k; menuclose(); }
  var newNs = a;
  if (x == 1 || x == 2 || x == 6){
    if(x == 6) b = k;
    if(x != 2) {
      for(i = $init->commandMax - 1; i > a; i--) {
        command[i] = command[i-1];
        g[i] = g[i-1];
      }
    }

    for(s = 0; s < $com_count ;s++) {
      var comlist2 = comlist[s];
      for(i = 0; i < comlist2.length; i++){
        if(comlist2[i][0] == b){
          g[a] = comlist2[i][1];
          break;
        }
      }
    }
    command[a] = [b,c,d,e,f];
    newNs++;
//    menuclose();
  } else if(x == 3) {
    var num = (k) ? k-1 : a;
    for(i = Math.floor(num); i < ($init->commandMax - 1); i++) {
      command[i] = command[i + 1];
      g[i] = g[i+1];
    }
    command[$init->commandMax - 1] = [41, 0, 0, 0, 0];
    g[$init->commandMax - 1] = '자금융통';
  } else if(x == 4) {
    i = Math.floor(a);
    if (i == 0){ return true; }
    i = Math.floor(a);
    tmpcom1[i] = command[i];tmpcom2[i] = command[i - 1];
    command[i] = tmpcom2[i];command[i-1] = tmpcom1[i];
    k1[i] = g[i];k2[i] = g[i - 1];
    g[i] = k2[i];g[i-1] = k1[i];
    ns(--i);
    str = plchg();
    str = '<font color="red"><strong>■ 미송신 ■<\\/strong><\\/font><br>' + str;
    disp(str,"white");
    outp();
    newNs = i-1;
  } else if(x == 5) {
    i = Math.floor(a);
    if (i == $init->commandMax - 1){ return true; }
    tmpcom1[i] = command[i];tmpcom2[i] = command[i + 1];
    command[i] = tmpcom2[i];command[i + 1] = tmpcom1[i];
    k1[i] = g[i];k2[i] = g[i + 1];
    g[i] = k2[i];g[i + 1] = k1[i];
    newNs = i+1;
  }else if(x == 7){
    // 이동
    var ctmp = command[k];
    var gtmp = g[k];
    if(z > k) {
      // 위에서 밑으로
      for(i = k; i < z-1; i++) {
        command[i] = command[i+1];
        g[i] = g[i+1];
      }
    } else {
      // 아래에서 위에
      for(i = k; i > z; i--) {
        command[i] = command[i-1];
        g[i] = g[i-1];
      }
    }
    command[i] = ctmp;
    g[i] = gtmp;
  }else if(x == 8){
    command[a][3] = k;
  }

  str = plchg();
  str = '<font color="red"><b>■ 미송신 ■<\\/b><\\/font><br>' + str;
  disp(str, "white");
  outp();
  theForm.SENDPROJECT.disabled = false;
  ns(newNs);
  return true;
}
function plchg() {
  strn1 = "";
  for(i = 0; i < $init->commandMax; i++) {
    c = command[i];

    kind = '{$init->tagComName_}' + g[i] + '{$init->_tagComName}';
    x = c[1];
    y = c[2];
    tgt = c[4];
    point = '{$init->tagName_}' + "(" + x + "," + y + ")" + '{$init->_tagName}';
    for(j = 0; j < islname.length ; j++) {
      if(tgt == islname[j][0]){
        tgt = '{$init->tagName_}' + islname[j][1] + "섬" + '{$init->_tagName}';
      }
    }
    if(c[0] == $init->comMissileSM || c[0] == $init->comDoNothing || c[0] == $init->comGiveup){
      //  미사일 쏘아 죽여 자금융통, 섬의 방폐
      strn2 = kind;
    }else if(c[0] == $init->comMissileNM || // 미사일 관련
             c[0] == $init->comMissilePP ||
             c[0] == $init->comMissileST ||
             c[0] == $init->comMissileLD){
      if(c[3] == 0) {
        arg = "(무제한)";
      } else {
        arg = "(" + c[3] + "발)";
      }
      strn2 = tgt + point + "에" + kind + arg;
    } else if(c[0] == $init->comMissileNB) { // 네이팜탄
      strn2 = tgt + point + "에" + kind;
    } else if(c[0] == $init->comSendMonster) { // 괴수 파견
      strn2 = tgt + "에" + kind;
    } else if(c[0] == $init->comSell) { // 식량 수출
      if(c[3] == 0){ c[3] = 1; }
      arg = c[3] * 100;
      arg = "(" + arg + "{$init->unitFood})";
      strn2 = kind + arg;
    } else if(c[0] == $init->comPropaganda) { // 유치 활동
      strn2 = kind;
    } else if(c[0] == $init->comDestroy) { // 굴착
      if(c[3] == 0){
        strn2 = point + "로" + kind;
      } else {
        arg = c[3] * {$init->comCost[$init->comDestroy]};
        arg = "(예\산" + arg + "{$init->unitMoney})";
        strn2 = point + "로" + kind + arg;
      }
    } else if(c[0] == $init->comFarm || // 농장, 공장, 채굴장 정비
              c[0] == $init->comFactory ||
              c[0] == $init->comMountain) {
      if(c[3] != 0){
        arg = "(" + c[3] + "회)";
        strn2 = point + "로" + kind + arg;
      }else{
        strn2 = point + "로" + kind;
      }
    }else{
      strn2 = point + "로" + kind;
    }
    tmpnum = '';
    if(i < 9){ tmpnum = '0'; }
    strn1 +=
      '<div id="com_'+i+'" '+
        'onmouseover="mc_over('+i+');return false;" '+
          '><a style="text-decoration:none;color:000000" HREF="javascript:void(0);" onclick="ns('+i+')" onkeypress="ns('+i+')" '+
            'onmousedown="return comListMove('+i+');" '+'ondblclick="chNum('+c[3]+');return false;" '+
              '><nobr>'+
                tmpnum+(i+1)+':'+
                  strn2+'<\\/nobr><\\/a><\\/div>\\n';
  }
  return strn1;
}

function disp(str,bgclr) {
  if(str==null)  str = "";

  if(document.getElementById || document.all){
    LayWrite('LINKMSG1', str);
    SetBG('plan', bgclr);
  } else if(document.layers) {
    lay = document.layers["PARENT_LINKMSG"].document.layers["LINKMSG1"];
    lay.document.open();
    lay.document.write("<font style='font-size:11pt'>"+str+"<\\/font>");
    lay.document.close();
    SetBG("PARENT_LINKMSG", bgclr);
  }
}

function outp() {
  comary = "";

  for(k = 0; k < command.length; k++){
    comary = comary + command[k][0]
      + " " + command[k][1]
        + " " + command[k][2]
          + " " + command[k][3]
            + " " + command[k][4]
              + " " ;
  }
  document.InputPlan.COMARY.value = comary;
}

function ps(x, y) {
  document.InputPlan.POINTX.options[x].selected = true;
  document.InputPlan.POINTY.options[y].selected = true;
  if(!(document.InputPlan.MENUOPEN.checked))
    moveLAYER("menu",mx+10,my-50);
  NaviClose();
  return true;
}


function ns(x) {
  if (x == $init->commandMax){ return true; }
  document.InputPlan.NUMBER.options[x].selected = true;
  return true;
}

function set_com(x, y, land) {
  com_str = land + " ";
  for(i = 0; i < $init->commandMax; i++) {
    c = command[i];
    x2 = c[1];
    y2 = c[2];
    if(x == x2 && y == y2 && c[0] < 30){
      com_str += "[" + (i + 1) +"]" ;
      kind = g[i];
      if(c[0] == $init->comDestroy){
        if(c[3] == 0){
          com_str += kind;
        } else {
          arg = c[3] * 200;
          arg = "(예\산" + arg + "{$init->unitMoney})";
          com_str += kind + arg;
        }
      } else if(c[0] == $init->comFarm ||
                c[0] == $init->comFactory ||
                c[0] == $init->comMountain) {
        if(c[3] != 0){
          arg = "(" + c[3] + "회)";
          com_str += kind + arg;
        } else {
          com_str += kind;
        }
      } else {
        com_str += kind;
      }
      com_str += " ";
    }
  }
  document.InputPlan.COMSTATUS.value= com_str;
}


function SelectList(theForm) {
  var u, selected_ok;
  if(!theForm) { s = '' }
  else { s = theForm.menu.options[theForm.menu.selectedIndex].value; }
  if(s == ''){
    u = 0; selected_ok = 0;
    document.InputPlan.COMMAND.options.length = $All_listCom;
    for (i=0; i<comlist.length; i++) {
      var command = comlist[i];
      for (a=0; a<command.length; a++) {
        comName = command[a][1] + "(" + command[a][2] + ")";
        document.InputPlan.COMMAND.options[u].value = command[a][0];
        document.InputPlan.COMMAND.options[u].text = comName;
        if(command[a][0] == $default_Kind){
          document.InputPlan.COMMAND.options[u].selected = true;
          selected_ok = 1;
        }
        u++;
      }
    }
    if(selected_ok == 0)
      document.InputPlan.COMMAND.selectedIndex = 0;
  } else {
    var command = comlist[s];
    document.InputPlan.COMMAND.options.length = command.length;
    for (i=0; i<command.length; i++) {
      comName = command[i][1] + "(" + command[i][2] + ")";
      document.InputPlan.COMMAND.options[i].value = command[i][0];
      document.InputPlan.COMMAND.options[i].text = comName;
      if(command[i][0] == $default_Kind){
        document.InputPlan.COMMAND.options[i].selected = true;
        selected_ok = 1;
      }
    }
    if(selected_ok == 0)
      document.InputPlan.COMMAND.selectedIndex = 0;
  }
}

function moveLAYER(layName,x,y){
  if(document.getElementById){            //NN6,IE5
    el = document.getElementById(layName);
    el.style.left = x;
    el.style.top  = y;
  } else if(document.layers){                             //NN4
    msgLay = document.layers[layName];
    msgLay.moveTo(x,y);
  } else if(document.all){                                //IE4
    msgLay = document.all(layName).style;
    msgLay.pixelLeft = x;
    msgLay.pixelTop = y;
  }
}

function menuclose() {
  moveLAYER("menu",-500,-500);
}

function Mmove(e){
  if(document.all){
    mx = event.x + document.body.scrollLeft;
    my = event.y + document.body.scrollTop;
  }else if(document.layers){
    mx = e.pageX;
    my = e.pageY;
  }else if(document.getElementById){
    mx = e.pageX;
    my = e.pageY;
  }

  return moveLay.move();
}

function LayWrite(layName, str) {
   if(document.getElementById){
      document.getElementById(layName).innerHTML = str;
   } else if(document.all){
      document.all(layName).innerHTML = str;
   } else if(document.layers){
      lay = document.layers[layName];
      lay.document.open();
      lay.document.write(str);
      lay.document.close();
   }
}

function SetBG(layName, bgclr) {
   if(document.getElementById) document.getElementById(layName).style.backgroundColor = bgclr;
   else if(document.all)       document.all.layName.bgColor = bgclr;
   //else if(document.layers)    document.layers[layName].bgColor = bgclr;
}

var oldNum=0;
function selCommand(num) {
  document.getElementById('com_'+oldNum).style.backgroundColor = '';
  document.getElementById('com_'+num).style.backgroundColor = '#FFFFAA';
  oldNum = num;
}

/* 커멘드 드러그＆드롭용 추가 스크립트 */
var moveLay = new MoveFalse();

var newLnum = -2;
var Mcommand = false;

function Mup() {
   moveLay.up();
   moveLay = new MoveFalse();
}

function setBorder(num, color) {
   if(document.getElementById) {
      if(color.length == 4) document.getElementById('com_'+num).style.borderTop = ' 1px solid '+color;
      else document.getElementById('com_'+num).style.border = '0px';
   }
}

function mc_out() {
   if(Mcommand && newLnum >= 0) {
      setBorder(newLnum, '');
      newLnum = -1;
   }
}

function mc_over(num) {
   if(Mcommand) {
      if(newLnum >= 0) setBorder(newLnum, '');
      newLnum = num;
      setBorder(newLnum, '#116');    // blue
   }
}

function comListMove(num) { moveLay = new MoveComList(num); return (document.layers) ? true : false; }

function MoveFalse() {
   this.move = function() { }
   this.up   = function() { }
}

function MoveComList(num) {
   var setLnum  = num;
   Mcommand = true;

   LayWrite('mc_div', '<NOBR><strong>'+(num+1)+': '+g[num]+'</strong></NOBR>');

   this.move = function() {
      moveLAYER('mc_div',mx+10,my-30);
      return false;
   }

   this.up   = function() {
      if(newLnum >= 0) {
         var com = command[setLnum];
         cominput(document.InputPlan,7,setLnum,newLnum);
      }
      else if(newLnum == -1) cominput(document.InputPlan,3,setLnum+1);

      mc_out();
      newLnum = -2;

      Mcommand = false;
      moveLAYER("mc_div",-50,-50);
   }
}

function showElement(layName) {
        var element = document.getElementById(layName).style;
        element.display = "block";
        element.visibility ='visible';
}

function hideElement(layName) {
        var element = document.getElementById(layName).style;
        element.display = "none";
}

function chNum(num) {
        document.ch_numForm.AMOUNT.options.length = 100;
        for(i=0;i<document.ch_numForm.AMOUNT.options.length;i++){
                if(document.ch_numForm.AMOUNT.options[i].value == num){
                        document.ch_numForm.AMOUNT.selectedIndex = i;
                        document.ch_numForm.AMOUNT.options[i].selected = true;
                        moveLAYER('ch_num', mx-10, my-60);
                        showElement('ch_num');
                        break;
                }
        }
}

function chNumDo() {
        var num = document.ch_numForm.AMOUNT.options[document.ch_numForm.AMOUNT.selectedIndex].value;
        cominput(document.InputPlan,8,num);
        hideElement('ch_num');
}

function Kdown(e){
  var c, el;
  var m = document.InputPlan.AMOUNT.selectedIndex;
  if(m > 9) { m = 0; }
  if(document.all){
    if (event.altKey || event.ctrlKey || event.shiftKey) return;
    c = event.keyCode;
    el = new String(event.srcElement.tagName);
    el = el.toUpperCase();
    if (el == "INPUT") return;
//  }else if(document.layers){// NN4 KEYDOWN이벤트는 Win98계로 글자가 깨지므로 코멘트화
//    if (e.modifiers != 0) return;
//    c = e.which;
//    if ((c >= 97) && (c <= 122)) c -= 32; // 영소문자를 영대 문자로 한다
//    el = new String(e.target);
//    el = el.toUpperCase();
//    if (el.indexOf("<INPUT") >= 0) return;
  }else if(document.getElementById){
    if (e.altKey || e.ctrlKey || e.shiftKey) return;
    c = e.which;
    el = new String(e.target.tagName);
    el = el.toUpperCase();
    if (el == "INPUT") return;
  }
  c = String.fromCharCode(c);

  // 밀린 키에 응해 계획 번호를 설정한다
  switch (c) {
    case 'A': c = $init->comPrepare;   break; // 정지
    case 'J': c = $init->comPrepare2;  break; // 땅 고르는 일
    case 'U': c = $init->comReclaim;   break; // 매립?
    case 'K': c = $init->comDestroy;   break; // 굴착
    case 'B': c = $init->comSellTree;  break; // 벌채
    case 'P': c = $init->comPlant;     break; // 식림
    case 'N': c = $init->comFarm;      break; // 농장 정비?
    case 'I': c = $init->comFactory;   break; // 공장 건설
    case 'S': c = $init->comMountain;  break; // 채굴장 정비?
    case 'D': c = $init->comDbase;     break; // 방위 시설 건설?
    case 'M': c = $init->comBase;      break; // 미사일 기지 건설?
    case 'F': c = $init->comSbase;     break; // 해저 기지 건설?
    case '-': c = $init->comDoNothing; break; //INS 자금 유통 ?
    case '.': cominput(InputPlan,3);  return; //DEL 삭제?
    case'\b': //BS  1개 전삭제
      var no = document.InputPlan.COMMAND.selectedIndex;
      if(no > 0) document.InputPlan.COMMAND.selectedIndex = no - 1;
      cominput(InputPlan,3);
      return;
    case '0':case'`': document.InputPlan.AMOUNT.selectedIndex = m*10+0; return;
    case '1':case'a': document.InputPlan.AMOUNT.selectedIndex = m*10+1; return;
    case '2':case'b': document.InputPlan.AMOUNT.selectedIndex = m*10+2; return;
    case '3':case'c': document.InputPlan.AMOUNT.selectedIndex = m*10+3; return;
    case '4':case'd': document.InputPlan.AMOUNT.selectedIndex = m*10+4; return;
    case '5':case'e': document.InputPlan.AMOUNT.selectedIndex = m*10+5; return;
    case '6':case'f': document.InputPlan.AMOUNT.selectedIndex = m*10+6; return;
    case '7':case'g': document.InputPlan.AMOUNT.selectedIndex = m*10+7; return;
    case '8':case'h': document.InputPlan.AMOUNT.selectedIndex = m*10+8; return;
    case '9':case'i': document.InputPlan.AMOUNT.selectedIndex = m*10+9; return;
    case 'Z':case'j': document.InputPlan.AMOUNT.selectedIndex = 0; return;
    default:
    // IE 에서는 리로드를 위한 F5 까지 주우므로, 여기에 처리를 넣어선 안 된다
    return;
  }
  cominput(document.InputPlan, 6, c);
}

function settarget(part){
  p = part.options[part.selectedIndex].value;
}
function targetopen() {
  w = window.open("{$GLOBALS['THIS_FILE']}?target=" + p, "","width={$width},height={$height},scrollbars=1,resizable=1,toolbar=1,menubar=1,location=1,directories=0,status=1");
}

    //-->
</script>
END;

    $this->islandInfo($island, $number, 1);

    print <<<END
<div id="menu" style="position:absolute; top:-500;left:-500;">
<table border=0 bgcolor=#e0ffff>
<tr><td nowrap>
$click_com<hr>
$click_com2<hr>
<a href="Javascript:void(0);" onClick="menuclose()" style="text-decoration:none">메뉴를 닫는다</a>
</td></tr>
</table>
</div>
<div ID="mc_div" style="background-color:white;position:absolute;top:-50;left:-50;height:22px;">&nbsp;</div>
<div ID="ch_num" style="position:absolute;visibility:hidden;display:none">
<form name="ch_numForm">
<table border=1 bgcolor="#e0ffff" cellspacing=1>
<tr><td valign=top nowrap>
<a href="JavaScript:void(0)" onClick="hideElement('ch_num');" style="text-decoration:none"><B>?</B></a><br>
<select name="AMOUNT" size=13 onchange="chNumDo()">
</select>
</TD>
</TR>
</TABLE>
</form>
</div>
<div align="center">
<table border="1">
<tr valign="top">
<td $init->bgInputCell>
<form action="{$GLOBALS['THIS_FILE']}" method="post" name="InputPlan">
<input type="hidden" name="mode" value="command">
<input type="hidden" name="COMARY" value="comary">
<input type="hidden" name="DEVELOPEMODE" value="java">
<div align="center">
<br>
<b>커멘드 입력</b><br>
<b>
<a href="javascript:void(0);" onclick="cominput(InputPlan,1)">삽입</a>
?<a href="javascript:void(0);" onclick="cominput(InputPlan,2)">덧쓰기</a>
?<a href="javascript:void(0);" onclick="cominput(InputPlan,3)">삭제</a>
</b>
<hr>
<b>계획 번호</b>
<select name="NUMBER">
END;

    // 계획 번호
    for($i = 0; $i < $init->commandMax; $i++) {
      $j = $i + 1;
      print "<option value=\"$i\">$j</option>\n";
    }

    if ($data['MENUOPEN'] == 'on') {
      $open = "CHECKED";
    }else{
      $open = "";
    }

    print <<<END
</select>
<hr>
<b>개발 계획</b><br>
<input type="checkbox" name="NAVIOFF" $open>NaviOff
<input type="checkbox" name="MENUOPEN" $open>PopupOff<br>
<br>
<select name="menu" onchange="SelectList(InputPlan)">
<option value="">전종류</option>

END;

    for($i = 0; $i < $com_count; $i++) {
      list($aa, $tmp) = split(",", $init->commandDivido[$i], 2);
      print "<option value=\"$i\">{$aa}</option>\n";
    }
    print <<<END
</select><br>
<select name="COMMAND">
<option>??????????</option>
<option>??????????</option>
<option>??????????</option>
<option>??????????</option>
<option>??????????</option>
<option>??????????</option>
<option>??????????</option>
<option>??????????</option>
<option>??????????</option>
<option>??????????</option>
</select>
<hr>
<b>좌표(</b>
<select name="POINTX">

END;

    for($i = 0; $i < $init->islandSize; $i++) {
      if($i == $data['defaultX']) {
        print "<option value=\"$i\" selected>$i</option>\n";
      } else {
        print "<option value=\"$i\">$i</option>\n";
      }
    }

    print "</select>, <select name=\"POINTY\">\n";

    for($i = 0; $i < $init->islandSize; $i++) {
      if($i == $data['defaultY']) {
        print "<option value=\"$i\" selected>$i</option>\n";
      } else {
        print "<option value=\"$i\">$i</option>\n";
      }
    }

    print <<<END
</select><b> )</b>
<hr>
<b>수량</b><select name="AMOUNT">

END;

    // 수량
    for($i = 0; $i < 100; $i++) {
      print "<option value=\"$i\">$i</option>\n";
    }

    print <<<END
</select>
<hr>
<b>목표의 섬</b><br>
<select name="TARGETID" onchange="settarget(this);">
$hako->targetList<br>
</select>
<input type="button" value="목표 포착" onClick="javascript: targetopen();">
<hr>
<b>커멘드 이동</b> :
<a href="javascript:void(0);" onclick="cominput(InputPlan,4)" style="text-decoration:none"> ▲ </a>··
<a href="javascript:void(0);" onclick="cominput(InputPlan,5)" style="text-decoration:none"> ▼ </a>
<hr>
<input type="hidden" name="ISLANDID" value="{$island['id']}">
<input type="hidden" name="PASSWORD" value="{$data['defaultPassword']}">
<input type="submit" value="계획 송신" name="SENDPROJECT">
<br>마지막에<font color="red">계획 송신 버튼</font>을<br>누르는 것을 잊지 않게.
</div>
</form>
<a title='숫자=수량 BS=1개 전삭제
DEL=삭제 INS=자금융통
A=정지 J=땅 고르는 일
K=굴착 U=매립
B=벌채 P=식림
N=농장 정비 I=공장 건설
S=채굴장 정비
D=방위 시설 건설
M=미사일 기지 건설
F=해저 기지 건설'>
키 입력 간이 설명</a>(NN4불가)
</td>
<td $init->bgMapCell id="plan" onmouseout="mc_out();return false;">
END;

    $this->islandMap($hako, $island, 1);    // 섬의 지도, 소유자 모드

    $comment = $hako->islands[$number]['comment'];

    print <<<END

</td>
<td $init->bgCommandCell id="plan">
<ilayer name="PARENT_LINKMSG" width="100%" height="100%">
<layer name="LINKMSG1" width="200"></layer>
<span id="LINKMSG1"></span>
</ilayer>
<br>
</td>
</tr>
</table>
</center>
<hr>
<div id='CommentBox'>
<h2>코멘트 갱신</h2>
<form action="{$GLOBALS['THIS_FILE']}" method="post">
코멘트<input type="text" name="MESSAGE" size="80" value="{$island['comment']}"><br>
<input type="hidden" name="PASSWORD" value="{$data['defaultPassword']}">
<input type="hidden" name="mode" value="comment">
<input type="hidden" name="DEVELOPEMODE" value="java">
<input type="hidden" name="ISLANDID" value="{$island['id']}">
<input type="submit" value="코멘트 갱신">
</FORM>
</DIV>
</DIV>
END;

  }
}



class HtmlSetted extends HTML {
  function setSkin() {
    global $init;
    print "{$init->tagBig_}스타일 시트를 설정했습니다.{$init->_tagBig}{$GLOBALS['BACK_TO_TOP']}\n";
  }
  function setImg() {
    global $init;
    print "{$init->tagBig_}화상의 로컬 설정을 했습니다.{$init->_tagBig}{$GLOBALS['BACK_TO_TOP']}\n";
  }
  function comment() {
    global $init;
    print "{$init->tagBig_}코멘트를 갱신했던{$init->_tagBig}<hr>";
  }
  function change() {
    global $init;
    print "{$init->tagBig_}변경 완료했던{$init->_tagBig}{$GLOBALS['BACK_TO_TOP']}\n";
  }
  function lbbsDelete() {
    global $init;
    print "{$init->tagBig_}기장 내용을 삭제했던{$init->_tagBig}<hr>";
  }
  function lbbsAdd() {
    global $init;
    print "{$init->tagBig_}기장을 실시했던{$init->_tagBig}<hr>";
  }
  // 커멘드 삭제
  function commandDelete() {
    global $init;
    print "{$init->tagBig_}커멘드를 삭제했던{$init->_tagBig}<hr>\n";
  }

  // 커멘드 등록
  function commandAdd() {
    global $init;
    print "{$init->tagBig_}커멘드를 등록했던{$init->_tagBig}<hr>\n";
  }
  // 섬의 강제 삭제
  function deleteIsland($name) {
    global $init;
    print "{$init->tagBig_}{$name}섬을 강제 삭제했습니다.{$init->_tagBig}{$GLOBALS['BACK_TO_TOP']}\n";
  }
}
class HakoError {
  function wrongPassword() {
    global $init;
    print "{$init->tagBig_}패스워드가 다릅니다.{$init->_tagBig}{$GLOBALS['BACK_TO_TOP']}\n";
    $html = new HTML(); $html->footer();
    exit;
  }
  function wrongID() {
    global $init;
    print "{$init->tagBig_}ID가 다릅니다.{$init->_tagBig}{$GLOBALS['BACK_TO_TOP']}\n";
    $html = new HTML(); $html->footer();
    exit;
  }
  // hakojima.dat가 없다
  function noDataFile() {
    global $init;
    print "{$init->tagBig_}데이터 파일이 열리지 않습니다.{$init->_tagBig}{$GLOBALS['BACK_TO_TOP']}\n";
    $html = new HTML(); $html->footer();
    exit;
  }
  function newIslandFull() {
    global $init;
    print "{$init->tagBig_}죄송합니다, 섬이 가득해 등록할 수 없습니다!{$init->_tagBig}{$GLOBALS['BACK_TO_TOP']}\n";
    $html = new HTML(); $html->footer();
    exit;
  }
  // 접수중인가 어떤가
  function tempNewIslandForbbiden() {
    global $init;
    print "{$init->tagBig_}죄송합니다, 접수를 중지하고 있습니다.{$init->_tagBig}{$GLOBALS['BACK_TO_TOP']}\n";
    $html = new HTML(); $html->footer();
    exit;
  }
  function newIslandNoName() {
    global $init;
    print "{$init->tagBig_}섬에 붙이는 이름이 필요합니다.{$init->_tagBig}{$GLOBALS['BACK_TO_TOP']}\n";
    $html = new HTML(); $html->footer();
    exit;
  }
  function newIslandBadName() {
    global $init;
    print "{$init->tagBig_},?()<>\$(이)라든지 들어가기도 하고, 「무인도」든지 말한 이상한 이름은 그만둡시다∼.{$init->_tagBig}{$GLOBALS['BACK_TO_TOP']}\n";
    $html = new HTML(); $html->footer();
    exit;
  }
  function newIslandAlready() {
    global $init;
    print "{$init->tagBig_}그 섬이라면 벌써 발견되고 있습니다.{$init->_tagBig}{$GLOBALS['BACK_TO_TOP']}\n";
    $html = new HTML(); $html->footer();
    exit;
  }
  function newIslandNoPassword() {
    global $init;
    print "{$init->tagBig_}패스워드가 필요합니다.{$init->_tagBig}{$GLOBALS['BACK_TO_TOP']}\n";
    $html = new HTML(); $html->footer();
    exit;
  }
  function changeNoMoney() {
    global $init;
    print "{$init->tagBig_}자금부족이기 때문에 변경할 수 없습니다{$init->_tagBig}{$GLOBALS['BACK_TO_TOP']}\n";
    $html = new HTML(); $html->footer();
    exit;
  }
  function changeNothing() {
    global $init;
    print "{$init->tagBig_}이름, 패스워드 모두 공난입니다{$init->_tagBig}{$GLOBALS['BACK_TO_TOP']}\n";
    $html = new HTML(); $html->footer();
    exit;
  }
  function problem() {
    global $init;
    print "{$init->tagBig_}문제 발생 우선 돌아와 주세요.{$init->_tagBig}{$GLOBALS['BACK_TO_TOP']}\n";
    $html = new HTML(); $html->footer();
    exit;
  }
  function lbbsNoMessage() {
    global $init;
    print "{$init->tagBig_}이름 또는 내용의 란이 공난입니다.{$init->_tagBig}{$GLOBALS['BACK_TO_TOP']}\n";
    $html = new HTML(); $html->footer();
    exit;
  }
  function lbbsNoMoney() {
    global $init;
    print "{$init->tagBig_}자금부족이기 때문에 기장할 수 없습니다.{$init->_tagBig}{$GLOBALS['BACK_TO_TOP']}\n";
    $html = new HTML(); $html->footer();
    exit;
  }
  function lockFail() {
    global $init;
    print "{$init->tagBig_}동시 액세스 에러입니다.<BR>브라우저의 「돌아온다」버튼을 눌러,<BR>당분간 기다리고 나서 재차 시험해 주세요.{$init->_tagBig}{$GLOBALS['BACK_TO_TOP']}\n";
    $html = new HTML(); $html->footer();
    exit;
  }
}
?>
