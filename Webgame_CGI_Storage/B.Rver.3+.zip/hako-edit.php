<?php
/*----------------------------------------------------------------------*
  모형정원 제도 2 for PHP 용 맵·에디터
  
  (주) 이 맵 에디터는, 무개조의 「모형정원 제도 2 for PHP」용입니다.
      개조를 실시하고 있는 「모형정원」에는 대응하고 있었기 때문에, 주의해 주십시오.
      데이터를 확실히 파괴합니다.
  
  Version: 1.0b (20041200)
  Author: 사행주
  Website: http://f22.aaa.livedoor.jp/~snufkin/
 *----------------------------------------------------------------------*/

require_once 'jcode.phps';
require_once 'config.php';
require_once 'hako-file.php';
require_once 'hako-html.php';
require_once 'hako-util.php';

$init = new Init;

define("READ_LINE", 1024);
$THIS_FILE =  $init->baseDir . "/hako-edit.php";
$BACK_TO_TOP = "<A HREF=\"JavaScript:void(0);\" onClick=\"document.TOP.submit();return false;\">{$init->tagBig_}긣긞긵귉뽣귡{$init->_tagBig}</A>";

//----------------------------------------------------------------------
class Hako extends HakoIO {

  function readIslands(&$cgi) {
    global $init;
    
    $m = $this->readIslandsFile($cgi);

    return $m;
  }
  //---------------------------------------------------
  // 지형 리스트를 생성
  //---------------------------------------------------
  function getLandList() {
    global $init;

    $landList = "";

    $landList .= "<option value=\"{$init->landSea}\"		>해, 얕은 여울</option>\n";
    $landList .= "<option value=\"{$init->landWaste}\"		>황무지</option>\n";
    $landList .= "<option value=\"{$init->landPlains}\"		>평지</option>\n";
    $landList .= "<option value=\"{$init->landForest}\"		>숲</option>\n";
    $landList .= "<option value=\"{$init->landTown}\"		>촌, 마을, 도시</option>\n";
    $landList .= "<option value=\"{$init->landFarm}\"		>농장</option>\n";
    $landList .= "<option value=\"{$init->landFactory}\"	>공장</option>\n";
    $landList .= "<option value=\"{$init->landMountain}\"	>산, 채굴장</option>\n";
    $landList .= "<option value=\"{$init->landBase}\"		>미사일 기지</option>\n";
    $landList .= "<option value=\"{$init->landHaribote}\"	>위장 시설</option>\n";
    $landList .= "<option value=\"{$init->landDefence}\"	>방위 시설</option>\n";
    $landList .= "<option value=\"{$init->landSbase}\"		>해저 기지</option>\n";
    $landList .= "<option value=\"{$init->landMonster}\"	>괴수</option>\n";

    return $landList;
  }
  //---------------------------------------------------
  // 지형에 관한 데이터 생성
  //---------------------------------------------------
  function landString($l, $lv, $x, $y, $mode, $comStr) {
    global $init;
    $point = "({$x},{$y})";
    $naviExp = "''";

    if($x < $init->islandSize / 2)
      $naviPos = 0;
    else
      $naviPos = 1;

    switch($l) {
    case $init->landSea:
      switch($lv) {
      case 1:
        // 얕은 여울
        $image = 'land14.gif';
        $naviTitle = '얕은 여울';
        break;
      default:
        // 해
        $image = 'land0.gif';
        $naviTitle = '바다';
      }
      break;
    case $init->landWaste:
      // 황무지
      if($lv == 1) {
        $image = 'land13.gif'; // 착탄점
      } else {
        $image = 'land1.gif';
      }
      $naviTitle = '황무지';
      break;
    case $init->landPlains:
      // 평지
      $image = 'land2.gif';
      $naviTitle = '평지';
      break;
    case $init->landForest:
      // 삼
      if($mode == 1) {
        $image = 'land6.gif';
        $naviText= "{$lv}{$init->unitTree}";
      } else {
        // 관광자의 경우는 키노모토수 숨긴다
        $image = 'land6.gif';
      }
      $naviTitle = '숲';
      break;
    case $init->landTown:
      // 정
      $p; $n;
      if($lv < 30) {
        $p = 3;
        $naviTitle = '마을';
      } else if($lv < 100) {
        $p = 4;
        $naviTitle = '마을';
      } else {
        $p = 5;
        $naviTitle = '도시';
      }
      $image = "land{$p}.gif";
      $naviText = "{$lv}{$init->unitPop}";
      break;
    case $init->landFarm:
      // 농장
      $image = 'land7.gif';
      $naviTitle = '농장';
      $naviText = "{$lv}0{$init->unitPop}규모";
      break;
    case $init->landFactory:
      // 공장
      $image = 'land8.gif';
      $naviTitle = '공장';
      $naviText = "{$lv}0{$init->unitPop}규모";
      break;
    case $init->landBase:
      if($mode == 0 || $mode == 2) {
        // 관광자의 경우는 숲의 행세
        $image = 'land6.gif';
        $naviTitle = '숲';
      } else {
        // 미사일 기지
        $level = Util::expToLevel($l, $lv);
        $image = 'land9.gif';
        $naviTitle = '미사일 기지';
        $naviText = "레벨 {$level} / 경험치 {$lv}";
      }
      break;
    case $init->landSbase:
      // 해저 기지
      if($mode == 0 || $mode == 2) {
        // 관광자의 경우는 바다의 행세
        $image = 'land0.gif';
        $naviTitle = '바다';
      } else {
        $level = Util::expToLevel($l, $lv);
        $image = 'land12.gif';
        $naviTitle = '해저기지';
        $naviText = "레벨 ${level} / 경험치 {$lv}";
      }
      break;
    case $init->landDefence:
      // 방위 시설
      $image = 'land10.gif';
      $naviTitle = '방위 시설';
      break;
    case $init->landHaribote:
      // 위장 시설
      $image = 'land10.gif';
      if($mode == 0 || $mode == 2) {
        // 관광자의 경우는 방위 시설의 행세
        $naviTitle = '방위 시설';
      } else {
        $naviTitle = '위장 시설';
      }
      break;
    case $init->landOil:
      // 해저 유전
      $image = 'land16.gif';
      $naviTitle = '해저 유전';
      break;
    case $init->landMountain:
      // 산
      if($lv > 0) {
        $image = 'land15.gif';
        $naviTitle = '채굴장';
        $naviText = "{$lv}0{$init->unitPop}규모";
      } else {
        $image = 'land11.gif';
        $naviTitle = '산';
      }
      break;
    case $init->landMonument:
      // 기념비
      $image = "monument{$lv}.gif";
      $naviTitle = '기념비';
      $naviText = $init->monumentName[$lv];
      break;
    case $init->landMonster:
      // 괴수
      $monsSpec = Util::monsterSpec($lv);
      $spec = $monsSpec['kind'];
      $special = $init->monsterSpecial[$spec];
      $image = "monster{$spec}.gif";
      $naviTitle = '괴수';

      // 경화중?
      if((($special == 3) && (($this->islandTurn % 2) == 1)) ||
         (($special == 4) && (($this->islandTurn % 2) == 0))) {
        // 경화중?
        $image = $init->monsterImage[$monsSpec['kind']];
      }
      $naviText = "괴수{$monsSpec['name']}(체력{$monsSpec['hp']})";
    }

    if($mode == 1 || $mode == 2) {
      print "<a href=\"javascript: void(0);\" onclick=\"ps($x,$y)\">";
      $naviText = "{$comStr}\\n{$naviText}";
    }
    print "<img src=\"{$image}\" width=\"32\" height=\"32\" alt=\"{$point} {$naviTitle} {$comStr}\" onMouseOver=\"Navi({$naviPos},'{$image}', '{$naviTitle}', '{$point}', '{$naviText}', {$naviExp});\" onMouseOut=\"NaviClose(); return false\">";

    // 좌표 설정 닫고
    if($mode == 1 || $mode == 2)
      print "</a>";
  }
}

//----------------------------------------------------------------------
class Cgi {
  var $mode = "";
  var $dataSet = array();
  //---------------------------------------------------
  // POST, GET의 데이터를 취득
  //---------------------------------------------------
  function parseInputData() {
    global $init;

    $this->mode = $_POST['mode'];
    if(!empty($_POST)) {
      while(list($name, $value) = each($_POST)) {
        $value = str_replace(",", "", $value);
        $value = JcodeConvert($value, 0, 2);
        $value = HANtoZEN_SJIS($value);
        if($init->stripslashes == true) {
          $this->dataSet["{$name}"] = stripslashes($value);
        } else {
          $this->dataSet["{$name}"] = $value;
        }
      }
      if(!empty($_POST['Sight'])) {
        $this->dataSet['ISLANDID'] = $_POST['Sight'];
      }
    }
  }
  //---------------------------------------------------
  //  COOKIE를 취득
  //---------------------------------------------------
  function getCookies() {
    if(!empty($_COOKIE)) {
      while(list($name, $value) = each($_COOKIE)) {
        switch($name) {
        case "POINTX":
          $this->dataSet['defaultX'] = $value;
          break;
        case "POINTY":
          $this->dataSet['defaultY'] = $value;
          break;
        case "SKIN":
          $this->dataSet['defaultSkin'] = $value;
          break;
        case "IMG":
          $this->dataSet['defaultImg'] = $value;
          break;
        }
      }
    }
  }
  //---------------------------------------------------
  // COOKIE를 생성
  //---------------------------------------------------
  function setCookies() {
    $time = time() + 30 * 86400; // 현재 + 30일 유효

    // Cookie의 설정 & POST로 입력된 데이터로, Cookie로부터 취득한 데이터를 갱신
    if($this->dataSet['POINTX']) {
      setcookie("POINTX",$this->dataSet['POINTX'], $time);
      $this->dataSet['defaultX'] = $this->dataSet['POINTX'];
    }
    if($this->dataSet['POINTY']) {
      setcookie("POINTY",$this->dataSet['POINTY'], $time);
      $this->dataSet['defaultY'] = $this->dataSet['POINTY'];
    }
    if($this->dataSet['SKIN']) {
      setcookie("SKIN",$this->dataSet['SKIN'], $time);
      $this->dataSet['defaultSkin'] = $this->dataSet['SKIN'];
    }
    if($this->dataSet['IMG']) {
      setcookie("IMG",$this->dataSet['IMG'], $time);
      $this->dataSet['defaultImg'] = $this->dataSet['IMG'];
    }
  }
}

//----------------------------------------------------------------------
class Edit {
  //---------------------------------------------------
  // TOP 표시(패스워드 입력)
  //---------------------------------------------------
  function enter() {
    global $init;

    print <<<END
<h1>모형정원 제도 2 for PHP<br>맵·에디터</h1>
<form action="{$GLOBALS['THIS_FILE']}" method="post">
<strong>패스워드</strong>
<input type="password" size="32" maxlength="32" name="PASSWORD">
<input type="hidden" name="mode" value="list">
<input type="submit" value="일람에">
</form>

END;
  }
  //---------------------------------------------------
  // 섬의 일람을 표시
  //---------------------------------------------------
  function main($hako, $data) {
    global $init;

    // 패스워드
    if(!Util::checkPassword("", $data['PASSWORD'])) {
      // password 실수
      HakoHakoError::wrongPassword();
      return;
    }

    print "<h1>모형정원 제도 2 for PHP 용<br>맵·에디터</h1>\n";

    print <<<END
<h2 class='Turn'>턴 $hako->islandTurn</h2>
<hr>
<div ID="IslandView">
<h2>제도의 상황</h2>
<p>
섬의 이름을 클릭하면<strong>맵</strong>이 표시됩니다.
</p>
<table border="1">
<tr>
<th {$init->bgTitleCell}>{$init->tagTH_}순위{$init->_tagTH}</th>
<th {$init->bgTitleCell}>{$init->tagTH_}섬{$init->_tagTH}</th>
<th {$init->bgTitleCell}>{$init->tagTH_}인구{$init->_tagTH}</th>
<th {$init->bgTitleCell}>{$init->tagTH_}면적{$init->_tagTH}</th>
<th {$init->bgTitleCell}>{$init->tagTH_}자금{$init->_tagTH}</th>
<th {$init->bgTitleCell}>{$init->tagTH_}식량{$init->_tagTH}</th>
<th {$init->bgTitleCell}>{$init->tagTH_}농장 규모{$init->_tagTH}</th>
<th {$init->bgTitleCell}>{$init->tagTH_}공장 규모{$init->_tagTH}</th>
<th {$init->bgTitleCell}>{$init->tagTH_}채굴장 규모{$init->_tagTH}</th>
</tr>

END;

    // 표시 내용은, 관리자용의 내용
    for($i = 0; $i < $hako->islandNumber; $i++) {
      $island = $hako->islands[$i];
      $j = $i + 1;
      $id    = $island['id'];
      $pop   = $island['pop'] . $init->unitPop;
      $area  = $island['area'] . $init->unitArea;
      $money = $island['money'] . $init->unitMoney;
      $food  = $island['food'] . $init->unitFood;
      $farm  = ($island['farm'] <= 0) ? "보유 안함" : $island['farm'] * 10 . $init->unitPop;
      $factory  = ($island['factory'] <= 0) ? "보유 안함" : $island['factory'] * 10 . $init->unitPop;
      $mountain = ($island['mountain'] <= 0) ? "보유 안함" : $island['mountain'] * 10 . $init->unitPop;
      
      $name = "";
      if($island['absent']  == 0) {
        $name = "{$init->tagName_}{$island['name']}섬{$init->_tagName}";
      } else {
        $name = "{$init->tagName2_}{$island['name']}섬({$island['absent']}){$init->_tagName2}";
      }
      if(!empty($island['owner'])) {
        $owner = $island['owner'];
      } else {
        $owner = "코멘트";
      }

      
      print "<tr>\n";
      print "<th {$init->bgNumberCell} rowspan=\"2\">{$init->tagNumber_}$j{$init->_tagNumber}</th>\n";
      print "<td {$init->bgNameCell} rowspan=\"2\"><a href=\"JavaScript:void(0);\" onClick=\"document.MAP{$id}.submit();return false;\">{$name}</a> {$monster}<br>\n{$prize}</td>\n";
      print <<<END
<form name="MAP{$id}" action="{$GLOBALS['THIS_FILE']}" method="post">
<input type="hidden" name="PASSWORD" value="{$data['PASSWORD']}">
<input type="hidden" name="mode" value="map">
<input type="hidden" name="Sight" value="{$id}">
</form>

END;

      print "<td {$init->bgInfoCell}>$pop</td>\n";
      print "<td {$init->bgInfoCell}>$area</td>\n";
      print "<td {$init->bgInfoCell}>$money</td>\n";
      print "<td {$init->bgInfoCell}>$food</td>\n";
      print "<td {$init->bgInfoCell}>$farm</td>\n";
      print "<td {$init->bgInfoCell}>$factory</td>\n";
      print "<td {$init->bgInfoCell}>$mountain</td>\n";
      print "</tr>\n";
      print "<tr>\n";
      print "<td {$init->bgCommentCell} colspan=\"7\">{$init->tagTH_}{$owner}:{$init->_tagTH}$comment</td>\n";
      print "</tr>\n";
    }

    print "</table>\n</div>\n";
  }
  //---------------------------------------------------
  //  맵 에디터의 표시
  //---------------------------------------------------
  function editMap($hako, $data) {
    global $init;

    // 패스워드
    if(!Util::checkPassword("", $data['PASSWORD'])) {
      // password 실수
      HakoHakoError::wrongPassword();
      return;
    }

    $html = new HtmlMap;

    $id     = $data['ISLANDID'];
    $number = $hako->idToNumber[$id];
    $island = $hako->islands[$number];

    print <<<END
<script type="text/javascript">
<!--
function ps(x, y, ld, lv) {
  document.InputPlan.POINTX.options[x].selected = true;
  document.InputPlan.POINTY.options[y].selected = true;
  document.InputPlan.LAND.options[ld].selected = true;

  if(ld == {$init->landMonster}) {
    mn = Math.floor(lv / 10);
    lv = lv - mn * 10;
    document.InputPlan.MONSTER.options[mn].selected = true;
    document.InputPlan.LEVEL.options[lv].selected = true;
  } else {
    document.InputPlan.LEVEL.options[lv].selected = true;
  }

  return true;
}

//-->
</script>
<div align="center">
{$init->tagBig_}{$init->tagName_}{$island['name']}섬{$init->_tagName}맵·에디터{$init->_tagBig}<br>
{$GLOBALS['BACK_TO_TOP']}
</div>

<form name="TOP" action="{$GLOBALS['THIS_FILE']}" method="post">
<input type="hidden" name="PASSWORD" value="{$data['PASSWORD']}">
<input type="hidden" name="mode" value="list">
</form>

END;

    // 섬의 정보를 표시
    $html->islandInfo($island, $number, 1);

    // 설명문을 표시
    print <<<END
<div align="center">
<table border="1">
<tr valign="top">
<td {$init->bgCommandCell}>
<b>레벨에 대해</b>
<ul>
<li><b>바다, 얕은 여울, 배계</b><br>레벨 1 때 얕은 여울
<li><b>황무지</b><br>레벨 1 때 착탄점
<li><b>촌, 마을, 도시</b><br>레벨 30 미만이 마을<br>레벨 100 미만이 마을<br>레벨 200 미만이 도시
<li><b>미사일 기지</b><br>경험치
<li><b>산, 채굴장</b><br>레벨 1 이상 때 채굴장
<li><b>괴수</b><br>각 괴수의 최대 레벨을 넘는다<br>설정은 할 수 없습니다
<li><b>해저 기지</b><br>경험치
</ul>

</td>
<td {$init->bgMapCell}>

END;

    // 지형 출력
    $html->islandMap($hako, $island, 1);

    // 에디터 영역의 표시?
    print <<<END
</td>
<td {$init->bgInputCell}>
<div align="center">
<form action="{$GLOBALS['THIS_FILE']}" method="post" name="InputPlan">
<input type="hidden" name="mode" value="regist">
<input type="hidden" name="ISLANDID" value="{$island['id']}">
<input type="hidden" name="PASSWORD" value="{$data['PASSWORD']}">
<strong>맵·에디터</strong><br>
<hr>
<strong>좌표(</strong>
<select name="POINTX">

END;

    for($i = 0; $i < $init->islandSize; $i++) {
      if($i == $data['defaultX']) {
        print "<option value=\"{$i}\" selected>{$i}</option>\n";
      } else {
        print "<option value=\"{$i}\">{$i}</option>\n";
      }
    }
    print "</select>, <select name=\"POINTY\">";
    for($i = 0; $i < $init->islandSize; $i++) {
      if($i == $data['defaultY']) {
        print "<option value=\"{$i}\" selected>{$i}</option>\n";
      } else {
        print "<option value=\"{$i}\">{$i}</option>\n";
      }
    }

    // 지형 리스트 취득
    $landList = $hako->getLandList();

    print <<<END
</select><strong>)</strong>
<hr>
<strong>지형</strong>
<select name="LAND">
{$landList}
</select>
<hr>
<strong>괴수의 종류</strong>
<select name="MONSTER">

END;

    for($i = 0; $i < $init->monsterNumber; $i++) {
        print "<option value=\"{$i}\">{$init->monsterName[$i]}</option>\n";
    }

    print <<<END
</select>
<hr>
<strong>레벨</strong>
<select name="LEVEL">

END;

    for($i = 0; $i < 255; $i++) {
        print "<option value=\"{$i}\">{$i}</option>\n";
    }

    print <<<END
</select>
<hr>
<input type="submit" value="등록">

</form>
</div>

<ul>
<li>등록할 때는 충분히 주의 바랍니다.
<li>데이터를 파괴하는 경우가 있습니다.
<li>백업을 실시하고 나서<br>실시하는 것처럼 합시다.
<li>지형 데이터를 변경할 뿐으로,<br>다른 데이터는 변경되지 않습니다. <br>
턴 갱신으로 다른 데이터에<br>반영됩니다.
</ul>

</td>
</tr>
</table>
</div>
END;
  }
  //---------------------------------------------------
  // 지형의 등록
  //---------------------------------------------------
  function regist($hako, $data) {
    global $init;

    // 패스워드
    if(!Util::checkPassword("", $data['PASSWORD'])) {
      // password 실수
      HakoHakoError::wrongPassword();
      return;
    }

    $id        = $data['ISLANDID'];
    $number    = $hako->idToNumber[$id];
    $island    = $hako->islands[$number];
    $land      = &$island['land'];
    $landValue = &$island['landValue'];

    $x     = $data['POINTX'];
    $y     = $data['POINTY'];
    $ld    = $data['LAND'];
    $mons  = $data['MONSTER'];
    $level = $data['LEVEL'];

    // 괴수의 레벨 설정
    if($ld == $init->landMonster) {
      $BHP = $init->monsterBHP[$mons];
      if($init->monsterDHP[$mons] > 0) { $DHP = $init->monsterDHP[$mons] - 1; } else { $DHP = $init->monsterDHP[$mons]; }
      $level = min($level, $BHP + $DHP);
      $level = $mons  * 10 + $level;
    }

    // 갱신 데이터 설정
    $land[$x][$y]      = $ld;
    $landValue[$x][$y] = $level;

    // 맵 데이터 갱신
    $hako->writeLand($id, $island);

    // 설정한 값을 되돌린다
    $hako->islands[$number] = $island;

    print "{$init->tagBig_}지형을 변경했던{$init->_tagBig}<hr>\n";

    // 맵 에디터의 표시에
    $this->editMap($hako, $data);
  }
}

//----------------------------------------------------------------------
class Main {

  function execute() {
    $hako = new Hako;
    $cgi = new Cgi;

    $cgi->parseInputData();
    $cgi->getCookies();
    if(!$hako->readIslands($cgi)) {
      $html = new HTML();
      $html->header($cgi->dataSet);
      HakoHakoError::noDataFile();
      $html = new HTML(); $html->footer();
      exit();
    }
    $cgi->setCookies();
    $edit = new Edit;

    switch($cgi->mode) {
    case "enter":
      $html = new HtmlTop;
      $html->header($cgi->dataSet);
      $edit->main($hako, $cgi->dataSet);
      $html->footer();
      break;
    case "list":
      $html = new HtmlTop;
      $html->header($cgi->dataSet);
      $edit->main($hako, $cgi->dataSet);
      $html->footer();
      break;
    case "map":
      $html = new HtmlTop;
      $html->header($cgi->dataSet);
      $edit->editMap($hako, $cgi->dataSet);
      $html->footer();
      break;

    case "regist":
      $html = new HtmlTop;
      $html->header($cgi->dataSet);
      $edit->regist($hako, $cgi->dataSet);
      $html->footer();
      break;

    case "skin":
      $html = new HtmlSetted;
      $html->header($cgi->dataSet);
      $html->setSkin();
      $html->footer();
      break;

    case "imgset":
      $html = new HtmlSetted;
      $html->header($cgi->dataSet);
      $html->setImg();
      $html->footer();
      break;

    default:
      $html = new HtmlTop;
      $html->header($cgi->dataSet);
      $edit->enter();
      $html->footer();
    }
    exit();
  }
}

$start = new Main;
$start->execute();
?>
