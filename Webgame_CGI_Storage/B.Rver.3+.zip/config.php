<?php
/*******************************************************************

  모형정원 제도 B.R ver. 3

  - 초기설정용 파일 -
  
  $Id: config.php,v 1.7 2003/09/29 11:54:19 Watson Exp $

*******************************************************************/
define("GZIP", false);	// true: GZIP 압축 전송을 사용  false: 사용하지 않는다
define("DEBUG", false);	// true: 디버그 false: 통상

class Init {
  //----------------------------------------
  // 각종 설정치
  //----------------------------------------
  // 프로그램을 두는 디렉토리
  var $baseDir		= "https://esils.com/hako/br3";

  // 화상을 두는 디렉토리
  var $imgDir		= "https://esils.com/hako/br3/img";

  // 로컬 설정용 화상
  var $imgPack      = 'https://esils.com/hako/br3/img';
  // 로컬 설정 설명 페이지
  var $imgExp       = "https://esils.com/hako/br3/index.html";

  // CSS 파일을 두는 디렉토리
  var $cssDir		= 'https://esils.com/hako/br3/css';

  // CSS 리스트
  var $cssList		= array('SkyBlue.css', 'Autumn.css');
  
  //패스워드의 암호화 true: 암호화, false: 암호화하지 않는다
  var $cryptOn		= true; 
  // 패스워드·파일
  var $passwordFile = "password.php";
  
  // 데이터 디렉토리의 이름
  var $dirName		= "data";

  // 게임 타이틀
  var $title            = "모형정원 제도 B.R ver. 3+";

  var $adminName	= "esils";
  var $adminEmail	= "loverofwind@naver.com";
  var $urlBbs		= "https://esils.com/xe/hakobbs";
  var $urlTopPage	= "https://esils.com";

  // 디렉토리 작성시의 퍼미션
  var $dirMode		= 0777;

  //  1 턴이 몇초인가
  var $unitTime		= 21600; // 6시간

  // 신규 등록 접수 턴?
  var $entryTurn    = 0;  // 설정 턴까지 접수,0:사용하지 않는다

  // 정전 기간
  var $stopTurn         = 50;

  // 무엇 턴 마다 최하정도의 섬이 멸망할까(전투 기간만))
  var $turnDead         = 100;

  // 몇명 남은 시점에서 종료할까(1이라면 1명이 될 때까지 싸운다. 0에는 할 수 없습니다. )
  var $finish           = 1;

  // 섬의 최대수
  var $maxIsland	= 50;

  // TOP 페이지에 한 번에 표시하는 섬의 수(0이라면 섬 전체 표시))
  var $islandListRange = 15;

  // 자금 표시 모드
  var $moneyMode	= true; // true: 100의 위로 사사오입, false: 그대로
  // 탑 페이지에 표시하는 로그의 턴수?
  var $logTopTurn	= 1;
  // 로그 파일 보관 유지 턴수
  var $logMax		= 8;
  // 정지 로그를 1개화할까? (0:하지 않는 1:좌표 있어 2:좌표 없음)
  var $logOmit      = 1;

  // 액세스 로그 파일의 이름
  var $logname  = "ip.log";

  // 액세스 로그 최대 기록 레코드수?
  var $axesmax  = 300;

  // 세이프 모드라면 1을 그렇지 않으면 0을 설정해 주세요
  var $safemode = 0;
  // 백업을 무엇 턴 걸러서 취할까
  var $backupTurn	= 6;
  // 백업을 몇회분 남길까
  var $backupTimes	= 5;

  // 발견 로그 보관 유지행수
  var $historyMax	= 10;

  // 소식
  var $infoFile     = "info.txt";
  // 기사 표시부의 최대의 높이.
  var $divHeight = 120;

  // 방폐 커멘드 자동 입력 턴수
  var $giveupTurn	= 100;

  // 커멘드 입력 한계수
  var $commandMax	= 20;

  // 로컬 게시판행수를 사용할지 어떨지(false:사용하지 않는, true:사용한다)
  var $useBbs		= true;
  // 로컬 게시판행수
  var $lbbsMax		= 5;
 // 로컬 게시판에의 익명 발언을 허가할까(false:금지, true:허가)
  var $lbbsAnon         = false;
  // 로컬 게시판의 발언에 발언자의 시마나를 표시할까(false:표시하지 않는, true:표시한다)
  var $lbbsSpeaker      = true;
  // 타섬의 로컬 게시판에 발언하기 위한 비용(0:무료)
  var $lbbsMoneyPublic =   0; // 공개
  var $lbbsMoneySecret = 100; // 극비

  // 섬의 크기
  var $islandSize	= 12;

  // 부하 계측 할까? (0:하지 않는,1:한다)
  var $performance = 1;
  var $CPU_start;

  // 초기 자금
  var $initialMoney	= 3000;
  // 초기 식량
  var $initialFood	= 100;
  // 초기 면적(설정하지 않는 경우는, 0)
  var $initialSize	= 32;
  // 초기섬데이터(사용하지 않는 경우는,"")
  var $initialLand	= "";

  // 자금 최대치
  var $maxMoney		= 99999;
  // 식량 최대치
  var $maxFood		= 99999;

  // 인구의 단위
  var $unitPop		= "00명";
  // 식량의 단위
  var $unitFood		= "00톤";
  // 넓이의 단위
  var $unitArea		= "00만평";
  // 나무의 수의 단위
  var $unitTree		= "00개";
  // 돈의 단위
  var $unitMoney	= "억";

  // 나무의 단위 당의 판매가
  var $treeValue	= 5;

  // 이름 변경의 코스트
  var $costChangeName	= 500;

  // 인구 1단위 당의 식량 소비료
  var $eatenFood	= 0.2;

  // 유전의 수입
  var $oilMoney		= 1000;
  // 유전의 고갈 확률
  var $oilRatio		= 40;

  // 복수 지점에의 미사일 발사를 가능하게 할까? 1:Yes 0:No
  var $multiMissiles = 1;

  // 네이팜탄
  // 몇 발 미사일 발사할 때 마다 받을 수 있을까
  // 총겟트수 0~9개는 100발 마다 받을 수 있다
  var $NB               = 100;

  // 총겟트수 10~는 200발 마다 받을 수 있다
  var $NB2              = 200;

  // 미사일 기지
  // 경험치의 최대치
  var $maxExpPoint	= 200; // 다만, 최대에서도 255까지

  // 레벨의 최대치
  var $maxBaseLevel	= 5; // 미사일 기지
  var $maxSBaseLevel	= 3; // 해저 기지

  // 경험치가 몇개로 레벨업인가
  var $baseLevelUp	= array(20, 60, 120, 200); // 미사일 기지
  var $sBaseLevelUp	= array(50, 200);          // 해저 기지

  // 괴수에게 밟혔을 때 자폭한다면 1, 하지 않으면 0
  var $dBaseAuto = 1;

  // 목표의 섬소유의 섬이 선택된 상태로 리스트를 생성 1, 순위가 TOP의 섬이라면0
  // 미사일의 오발이 많은 경우 등에 사용하면 좋을지도 모른다
  var $targetIsland = 1;
  
  var $disEarthquake = 5;  // 지진
  var $disTsunami    = 10; // 해일
  var $disTyphoon    = 20; // 태풍
  var $disMeteo      = 15; // 운석
  var $disHugeMeteo  = 3;  // 거대 운석
  var $disEruption   = 5; // 분화
  var $disFire       = 10; // 화재
  var $disMaizo      = 30; // 매장금

  // 지반침하
  var $disFallBorder = 90; // 안전 한계의 넓이(Hex수)
  var $disFalldown   = 30; // 그 넓이를 넘었을 경우의 확률

  // 괴수
  var $disMonsBorder1 = 1000; // 인구 기준 1(괴수 레벨 1)
  var $disMonsBorder2 = 2500; // 인구 기준 2(괴수 레벨 2)
  var $disMonsBorder3 = 4000; // 인구 기준 3(괴수 레벨 3)
  var $disMonster     = 3;    // 단위면적 근처의 출현율(0.01%단위)

  var $monsterLevel1  = 2; // 산지라까지   
  var $monsterLevel2  = 5; // 이노라 고우스트까지
  var $monsterLevel3  = 7; // 킹 이노라까지(전부)

  var $monsterNumber	= 8; // 괴수의 종류
  // 괴수의 이름
  var $monsterName	= array (
    '메카 이노라',
    '이노라',
    '산지라',
    '레드 이노라',
    '다크 이노라',
    '이노라 고우스트',
    '고래',
    '킹 이노라'
    );
  // 괴수의 화상(경화중)
  var $monsterImage	= array ('', '', 'kouka.gif', '', '', '', 'kouka.gif', '');

  // 최저 체력, 체력의 폭, 특수 능력, 경험치, 시체의 가격
  var $monsterBHP	= array( 2,   1,   1,    3,   2,   1,    4,    5,   3,   2,   3,    5,    6);
  var $monsterDHP	= array( 0,   2,   2,    2,   2,   0,    2,    2,   1,   2,   2,    2,    3);
  var $monsterSpecial	= array( 0,   0,   3,    6,   1,   2,    4,    7,   5,   1,   2,    9,   10);
  var $monsterExp	= array( 5,   5,   7,   12,  15,  10,   20,   30,  20,  15,  20,   50,  100);
  var $monsterValue	= array( 0, 400, 500, 1000, 800, 300, 1500, 2000, 500, 600, 800, 3000, 3500);

  // 턴배를 무엇 턴 마다 낼까
  var $turnPrizeUnit	= 100;

  // 상의 이름
  var $prizeName	= array (
    '턴배',
    '번영상',
    '초번영상',
    '궁극 번영상',
    '평화상',
    '초평화상',
    '궁극 평화상',
    '재난상',
    '초재난상',
    '궁극 재난상',
    );

  // 기념비
  var $monumentNumber   = 5;
  var $monumentName     = array (
    '모노리스',
    '싸움의 비',
    '기념수',
    '지구의',
    '쓰레기통',
    );

  /********************
       외관 관계
   ********************/
  // 큰 문자
  var $tagBig_ = '<span class="big">';
  var $_tagBig = '</span>';
  // 섬의 이름 등
  var $tagName_ = '<span class="islName">';
  var $_tagName = '</span>';
  // 얇아진 섬의 이름
  var $tagName2_ = '<span class="islName2">';
  var $_tagName2 = '</span>';
  // 순위의 번호 등
  var $tagNumber_ = '<span class="number">';
  var $_tagNumber = '</span>';
  // 순위표에 있어서의 보고있음
  var $tagTH_ = '<span class="head">';
  var $_tagTH = '</span>';
  // 개발 계획의 이름
  var $tagComName_ = '<span class="command">';
  var $_tagComName = '</span>';
  // 재해
  var $tagDisaster_ = '<span class="disaster">';
  var $_tagDisaster = '</span>';
  // 로컬 게시판, 관광자가 쓴 문자
  var $tagLbbsSS_ = '<span class="lbbsSS">';
  var $_tagLbbsSS = '</span>';
  // 로컬 게시판, 섬주가 쓴 문자
  var $tagLbbsOW_ = '<span class="lbbsOW">';
  var $_tagLbbsOW = '</span>';
  // 순위표, 셀의 속성
  var $bgTitleCell   = 'class="TitleCell"';   // 순위 표견 방편
  var $bgNumberCell  = 'class="NumberCell"';  // 순위표 순위
  var $bgNameCell    = 'class="NameCell"';    // 순위표도의 이름
  var $bgInfoCell    = 'class="InfoCell"';    // 순위표도의 정보
  var $bgCommentCell = 'class="CommentCell"'; // 순위표 코멘트란
  var $bgInputCell   = 'class="InputCell"';   // 개발 계획 폼
  var $bgMapCell     = 'class="MapCell"';     // 개발 계획 지도
  var $bgCommandCell = 'class="CommandCell"'; // 개발 계획 입력이 끝난 계획

  /********************
      지형 번호
   ********************/

  var $landSea		=  0; // 해 
  var $landWaste	=  1; // 황무지
  var $landPlains	=  2; // 평지
  var $landTown		=  3; // 마을계
  var $landForest	=  4; // 숲
  var $landFarm		=  5; // 농장?
  var $landFactory	=  6; // 공장
  var $landBase		=  7; // 미사일 기지
  var $landDefence	=  8; // 방위 시설?
  var $landMountain	=  9; // 산
  var $landMonster	= 10; // 괴수
  var $landSbase	= 11; // 해저 기지
  var $landOil		= 12; // 해저 유전
  var $landMonument	= 13; // 기념비?
  var $landHaribote	= 14; // 위장 시설 건설
  /********************
      커멘드
   ********************/
  // 커멘드 분할
  // 이 커멘드 분할만은, 자동 입력계의 커멘드는 설정하지 마세요.
  var $commandDivido = 
	array(
	'개발,0,10',  // 계획 번호 00~10
	'건설,11,30', // 계획 번호 11~30
	'공격,31,40', // 계획 번호 31~40
	'운영,41,60'  // 계획 번호 41~60
	);
  // 주의：스페이스는 들어갈 수  없게
  // ○→'개발,0,10',  # 계획 번호 00~10
  // ×→'개발, 0  ,10  ',  #계획 번호 00~10

  var $commandTotal	= 28; // 커멘드의 종류
  // 순서
  var $comList;
  // 정지계
  var $comPrepare	= 01; // 개간
  var $comPrepare2	= 02; // 땅고르기
  var $comReclaim	= 03; // 매립
  var $comDestroy	= 04; // 굴착
  var $comSellTree	= 05; // 벌채

  // 만드는 계
  var $comPlant		= 11; // 식림
  var $comFarm		= 12; // 농장 정비
  var $comFactory	= 13; // 공장 건설
  var $comMountain	= 14; // 채굴장 정비
  var $comBase		= 15; // 미사일 기지 건설
  var $comDbase		= 16; // 방위 시설 건설
  var $comSbase		= 17; // 해저 기지 건설
  var $comMonument	= 18; // 기념비 건조
  var $comHaribote	= 19; // 위장 시설 건설

  // 발사계
  var $comMissileNM	= 31; // 미사일 발사
  var $comMissilePP	= 32; // PP미사일 발사
  var $comMissileST	= 33; // ST미사일 발사
  var $comMissileLD	= 34; // 육지 파괴 탄발 쏘아 맞히고
  var $comMissileNB     = 35; // 네이팜탄 발사
  var $comMissileSM     = 36; // 미사일 쏘아 죽이고
  var $comSendMonster	= 37; // 괴수 파견

  // 운영계
  var $comDoNothing	= 41; // 자금융통
  var $comSell		= 42; // 식량 수출
  var $comPropaganda	= 43; // 유치 활동
  var $comGiveup	= 44; // 섬의 방폐

  // 자동 입력계
  var $comAutoPrepare	= 61; // 모두 개간
  var $comAutoPrepare2	= 62; // 모두 고르기
  var $comAutoDelete	= 63; // 모든 행동 삭제

  var $comName;
  var $comCost;

  // 섬의 좌표수
  var $pointNumber;

  // 주위 2 헥스의 좌표
  var $ax = array(0, 1, 1, 1, 0,-1, 0, 1, 2, 2, 2, 1, 0,-1,-1,-2,-1,-1, 0);
  var $ay = array(0,-1, 0, 1, 1, 0,-1,-2,-1, 0, 1, 2, 2, 2, 1, 0,-1,-2,-2);

  // 코멘트 등에, 예\정과 같이\가 마음대로 추가된다
  var $stripslashes;

  function setVariable() {
    $this->pointNumber = $this->islandSize * $this->islandSize;

    $this->comList	= array(
      $this->comPrepare,
      $this->comSell,
      $this->comPrepare2,
      $this->comReclaim,
      $this->comDestroy,
      $this->comSellTree,
      $this->comPlant,
      $this->comFarm,
      $this->comFactory,
      $this->comMountain,
      $this->comBase,
      $this->comDbase,
      $this->comSbase,
      $this->comMonument,
      $this->comHaribote,
      $this->comMissileNM,
      $this->comMissilePP,
      $this->comMissileST,
      $this->comMissileLD,
      $this->comMissileNB,
      $this->comMissileSM,
      $this->comSendMonster,
      $this->comDoNothing,
      $this->comPropaganda,
      $this->comGiveup,
      $this->comAutoPrepare,
      $this->comAutoPrepare2,
      $this->comAutoDelete,
      );
    // 계획의 이름과 가격
    $this->comName[$this->comPrepare]      = '개간';
    $this->comCost[$this->comPrepare]      = 5;
    $this->comName[$this->comPrepare2]     = '땅 고르기';
    $this->comCost[$this->comPrepare2]     = 100;
    $this->comName[$this->comReclaim]      = '매립';
    $this->comCost[$this->comReclaim]      = 150;
    $this->comName[$this->comDestroy]      = '굴착';
    $this->comCost[$this->comDestroy]      = 200;
    $this->comName[$this->comSellTree]     = '벌채';
    $this->comCost[$this->comSellTree]     = 0;
    $this->comName[$this->comPlant]        = '식림';
    $this->comCost[$this->comPlant]        = 50;
    $this->comName[$this->comFarm]         = '농장 정비';
    $this->comCost[$this->comFarm]         = 20;
    $this->comName[$this->comFactory]      = '공장 정비';
    $this->comCost[$this->comFactory]      = 100;
    $this->comName[$this->comMountain]     = '채굴장 건설';
    $this->comCost[$this->comMountain]     = 300;
    $this->comName[$this->comBase]         = '미사일 기지 건설';
    $this->comCost[$this->comBase]         = 300;
    $this->comName[$this->comDbase]        = '방위 시설 건설';
    $this->comCost[$this->comDbase]        = 800;
    $this->comName[$this->comSbase]        = '해저 기지 건설';
    $this->comCost[$this->comSbase]        = 8000;
    $this->comName[$this->comMonument]     = '기념비 건조';
    $this->comCost[$this->comMonument]     = 9999;
    $this->comName[$this->comHaribote]     = '위장 시설 설치';
    $this->comCost[$this->comHaribote]     = 1;
    $this->comName[$this->comMissileNM]    = '미사일 발사';
    $this->comCost[$this->comMissileNM]    = 20;
    $this->comName[$this->comMissilePP]    = 'PP미사일 발사';
    $this->comCost[$this->comMissilePP]    = 50;
    $this->comName[$this->comMissileST]    = 'ST미사일 발사';
    $this->comCost[$this->comMissileST]    = 50;
    $this->comName[$this->comMissileLD]    = '육지 파괴탄 발사';
    $this->comCost[$this->comMissileLD]    = 100;
    $this->comName[$this->comMissileNB]    = '네이팜탄 발사';
    $this->comCost[$this->comMissileNB]    = 200;
    $this->comName[$this->comMissileSM]    = '미사일 쏘아 죽이기[이게 머지?] ';
    $this->comCost[$this->comMissileSM]    = 0;
    $this->comName[$this->comSendMonster]  = '괴수파견';
    $this->comCost[$this->comSendMonster]  = 3000;
    $this->comName[$this->comDoNothing]    = '자금융통';
    $this->comCost[$this->comDoNothing]    = 0;
    $this->comName[$this->comSell]         = '식량 수출 ';
    $this->comCost[$this->comSell]         = -100;
    $this->comName[$this->comPropaganda]   = '유치활동';
    $this->comCost[$this->comPropaganda]   = 1000;
    $this->comName[$this->comGiveup]       = '섬의 방폐';
    $this->comCost[$this->comGiveup]       = 0;
    $this->comName[$this->comAutoPrepare]  = '개간 자동입력';
    $this->comCost[$this->comAutoPrepare]  = 0;
    $this->comName[$this->comAutoPrepare2] = '땅 고르기 자동입력';
    $this->comCost[$this->comAutoPrepare2] = 0;
    $this->comName[$this->comAutoDelete]   = '전계획을 모두 취소';
    $this->comCost[$this->comAutoDelete]   = 0;

  }
  function Init() {
    $this->CPU_start = microtime();
    $this->setVariable();
    mt_srand(time());
    // 일본 시간에 맞춘다
    // 해외의 서버에 설치하는 경우는 다음의 행에 있는//을 뗀다.
     putenv("TZ=KST-9");

    // 예\정과 같이\가 마음대로 추가된다
    $this->stripslashes	= get_magic_quotes_gpc();
  }
}
?>
