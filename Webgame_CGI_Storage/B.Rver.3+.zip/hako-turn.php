<?php
/*******************************************************************

  모형정원 제도 2 for PHP

  
  $Id: hako-turn.php,v 1.11 2004/03/23 13:00:23 watson Exp $

*******************************************************************/

require_once 'hako-log.php';

class MakeJS extends Make {
  //---------------------------------------------------
  // 커멘드 모드
  //---------------------------------------------------
  function commandMain($hako, $data) {
    global $init;
    $id  = $data['ISLANDID'];
    $num = $hako->idToNumber[$id];
    $island = $hako->islands[$num];
    $name = $island['name'];

    // 패스워드
    if(!Util::checkPassword($island['password'], $data['PASSWORD'])) {
      // password 실수
      HakoHakoError::wrongPassword();
      return;
    }
    // 모드로 분기
    $command = $island['command'];
    $comary = split(" " , $data['COMARY']);
    
    for($i = 0; $i < $init->commandMax; $i++) {
      $pos = $i * 5;
      $kind   = $comary[$pos];
      $x      = $comary[$pos + 1];
      $y      = $comary[$pos + 2];
      $arg    = $comary[$pos + 3];
      $target = $comary[$pos + 4];
      // 커멘드 등록
      if($kind == 0) {
        $kind = $init->comDoNothing;
      }
      $command[$i] = array (
        'kind'   => $kind,
        'x'      => $x,
        'y'      => $y,
        'arg'    => $arg,
        'target' => $target
        );
    }
    HtmlSetted::commandAdd();

    // 데이터의 서두
    $island['command'] = $command;
    $hako->islands[$num] = $island;
    $hako->writeIslandsFile($island['id']);

    // owner mode에
    $html = new HtmlJS;
    $html->owner($hako, $data);
  }
  
}
//--------------------------------------------------------------------
class Turn {
  var $log;
  var $rpx;
  var $rpy;
  //---------------------------------------------------
  // 턴 진행 모드
  //---------------------------------------------------
  function turnMain($hako, $data) {
    global $init;
    $this->log = new Log;
    
    // 최종 갱신 시간을 갱신
    $hako->islandLastTime += $init->unitTime;

    // 각 섬의 미사일비 와 수를 리셋트
    for($i = 0; $i < $hako->islandNumber; $i++){
      $hako->islands[$i]['min'] = 0;
      $hako->islands[$i]['mout'] = 0;
    }

    // 로그 파일을 뒤로 비켜 놓는다
    $this->log->slideBackLogFile();

    // 턴 번호
    $hako->islandTurn++;
    $GLOBALS['ISLAND_TURN'] = $hako->islandTurn;
    if($hako->islandNumber == 0) {
      // 섬이 없으면 턴수를 보존한 이후의 처리는 생략한다
      // 파일에 써내
      $hako->writeIslandsFile();
      return;
    }

    // 좌표 배열을 만든다
    $randomPoint = Util::makeRandomPointArray();
    $this->rpx = $randomPoint[0];
    $this->rpy = $randomPoint[1];
    // 차례 결정
    $order = Util::randomArray($hako->islandNumber);

    // 수입·소비
    for($i = 0; $i < $hako->islandNumber; $i++) {
      $this->estimate($hako->islands[$order[$i]]);
      $this->income($hako->islands[$order[$i]]);

      // 인구를 메모 한다
      $hako->islands[$order[$i]]['oldPop'] = $hako->islands[$order[$i]]['pop'];
    }
    // 커멘드 처리
    for($i = 0; $i < $hako->islandNumber; $i++) {
      // 반환값 1이 될 때까지 반복
      while($this->doCommand($hako, $hako->islands[$order[$i]]) == 0);
      // 정지 로그 (정리해 로그 출력)
      if($init->logOmit) { $this->logMatome($hako->islands[$order[$i]]); }
    }
    // 성장 및 단헥스 재해
    for($i = 0; $i < $hako->islandNumber; $i++) {
      $this->doEachHex($hako, $hako->islands[$order[$i]]);
    }
    // 섬전체 처리
    $remainNumber = $hako->islandNumber;
    for($i = 0; $i < $hako->islandNumber; $i++) {
      $island = $hako->islands[$order[$i]];
      $this->doIslandProcess($hako, $island);

      // 사멸 판정
      if($island['dead'] == 1) {
        $island['pop'] = 0;
        $remainNumber--;
      } elseif($island['pop'] == 0) {
        $island['dead'] = 1;
        $remainNumber--;
        // 사멸 메세지
        $tmpid = $island['id'];
        $this->log->dead($tmpid, $island['name']);
        if(is_file("{$init->dirName}/island.{$tmpid}")) {
          unlink("{$init->dirName}/island.{$tmpid}");
        }
      }
      $hako->islands[$order[$i]] = $island;
    }

    // 도수컷
    $hako->islandNumber = $remainNumber;

    if($hako->islandTurn > $init->stopTurn){
      // 인구÷(섬 전체의 인구의 합계÷100)가(100÷도수)÷2보다 적을 때, 그 섬은 소멸
      for($i = 0; $i < $hako->islandNumber; $i++) {
        $allpop += $hako->islands[$i]['pop'];
      }
      for($i = 0; $i < $hako->islandNumber; $i++) {
        $island = $hako->islands[$i];

        if(((int)(($island['pop']*100)/$allpop))<((int)(50/$hako->islandNumber))){

          if($hako->islandNumber > 1){
            $island['dead'] == 1;
            $remainNumber--;
            // 사멸 메세지
            $tmpid = $island['id'];
            $this->log->dead2($tmpid, $island['name']);
            if(is_file("{$init->dirName}/island.{$tmpid}")) {
              unlink("{$init->dirName}/island.{$tmpid}");
            }
          }
        }
      }
    }

    // 인구순서에 소트
    $this->islandSort($hako);

    // 도수컷
    $hako->islandNumber = $remainNumber;

    // 최하정도 흘림의 턴이라면 그 처리
    if((($hako->islandTurn % $init->turnDead) == 0) && ($hako->islandTurn > $init->stopTurn)) {
      if($hako->islandNumber > 1){

        $island = $hako->islands[$hako->islandNumber-1];
        $island['dead'] == 1;
        $remainNumber--;
        // 사멸 메세지
        $tmpid = $island['id'];
        $this->log->dead2($tmpid, $island['name']);
        if(is_file("{$init->dirName}/island.{$tmpid}")) {
          unlink("{$init->dirName}/island.{$tmpid}");
        }
      }
    }

    // 도수컷
    $hako->islandNumber = $remainNumber;

    // 턴배 대상 턴이라면, 그 처리
    if(($hako->islandTurn % $init->turnPrizeUnit) == 0) {
      $island = $hako->islands[0];
      $this->log->prize($island['id'], $island['name'], "{$hako->islandTurn}{$init->prizeName[0]}");
      $hako->islands[0]['prize'] .= "{$hako->islandTurn},";
    }
    // 도수컷
    $hako->islandNumber = $remainNumber;

    // 백업 턴이면, 쓰기 전에 rename
    if(!($init->safemode) && (($hako->islandTurn % $init->backupTurn) == 0)) {
      $hako->backUp();
    }

    // 백업 턴이면, 세이프 모드 백업 취득
    if(($init->safemode) && (($hako->islandTurn % $init->backupTurn) == 0)) {
      $hako->safemode_backup();
    }

    // 파일에 써내
    $hako->writeIslandsFile(-1);

    // 로그 서두
    $this->log->flush();

    // 기록 로그 조정
    $this->log->historyTrim();

  }
  //---------------------------------------------------
  // 로그를 정리한다
  //---------------------------------------------------
  function logMatome($island) {
    global $init;

    $sno = $island['seichi'];
    $point = "";
    if($sno > 0) {
      if($init->logOmit == 1) {
        $sArray = $island['seichipnt'];
        for($i = 0; $i < $sno; $i++) {
          $spnt = $sArray[$i];
          if($spnt == "") break;
          $x = $spnt['x'];
          $y = $spnt['y'];
          $point .= "($x, $y) ";
          if(!(($i+1)%20)) { $point .= "<br>???"; } // 전각 공백 3개?
        }
      }
      if($i > 1 || ($init->logOmit != 1)) { $point .= "의<strong>{$sno}개소</strong>"; }
    }
    if($point != "") {
      if(($init->logOmit == 1) && ($sno > 1)) {
        $this->log->landSucMatome($island['id'], $island['name'], '정지', $point);
      } else {
        $this->log->landSuc($island['id'], $island['name'], '정지', $point);
      }
    }
  }
  //---------------------------------------------------
  // 코만드페이즈
  //---------------------------------------------------
  function doCommand($hako, $island) {
    global $init;

    $comArray = $island['command'];
    $command  = $comArray[0];
    Util::slideFront($comArray, 0);
    $island['command'] = $comArray;
    
    $kind   = $command['kind'];
    $target = $command['target'];
    $x      = $command['x'];
    $y      = $command['y'];
    $arg    = $command['arg'];

    $name = $island['name'];
    $id   = $island['id'];
    $land = $island['land'];
    $landValue = $island['landValue'];
    $landKind = $land[$x][$y];
    $lv   = $landValue[$x][$y];
    $cost = $init->comCost[$kind];
    $comName = $init->comName[$kind];
    $point = "({$x},{$y})";
    $landName = $this->landName($landKind, $lv);

    $prize = $island['prize'];

    if($kind == $init->comDoNothing) {
      //$this->log->doNothing($id, $name, $comName);
      $island['money'] += 10;
      $island['absent']++;
      // 자동 방폐
      if($island['absent'] >= $init->giveupTurn) {
        $comArray[0] = array (
          'kind'   => $init->comGiveup,
          'target' => 0,
          'x'      => 0,
          'y'      => 0,
          'arg'    => 0
          );
        $island['command'] = $comArray;
      }
      return 1;
    }
    $island['command'] = $comArray;
    $island['absent']  = 0;
    // 코스트 체크
    if($cost > 0) {
      // 돈의 경우
      if($island['money'] < $cost) {
        $this->log->noMoney($id, $name, $comName);
        return 0;
      }
    } elseif($cost < 0) {
      // 식량의 경우
      if($island['food'] < (-$cost)) {
        $this->log->noFood($id, $name, $comName);
        return 0;
      }
    }

    $returnMode = 1;
    switch($kind) {
    case $init->comPrepare:
    case $init->comPrepare2:
      // 정지, 땅 고르는 일
      if(($landKind == $init->landSea) ||
         ($landKind == $init->landSbase) ||
         ($landKind == $init->landOil) ||
         ($landKind == $init->landMountain) ||
         ($landKind == $init->landMonster)) {
        // 바다, 해저 기지, 유전, 산, 괴수는 정지 할 수 없다
        $this->log->landFail($id, $name, $comName, $landName, $point);

        $returnMode = 0;
        break;
      }
      // 목적의 장소를 평지로 한다
      $land[$x][$y] = $init->landPlains;
      $landValue[$x][$y] = 0;
      if($init->logOmit) { // 로그의 통계
        $sno = $island['seichi'];
        $island['seichi']++;
        if($init->logOmit == 1) {
          // 좌표 있는 통계
          $seichipnt['x'] = $x;
          $seichipnt['y'] = $y;
          $island['seichipnt'][$sno] = $seichipnt;
        }
      } else {
        $this->log->landSuc($id, $name, '정지', $point);
      }

      // 금을 공제한다
      $island['money'] -= $cost;

      if($kind == $init->comPrepare2) {
        // 땅 고르는 일
        $island['prepare2']++;

        // 턴 소비하지 않고
        $returnMode = 0;
      } else {
        // 정지라면, 매장금의 가능성 있어
        if(Util::random(1000) < $init->disMaizo) {
          $v = 100 + Util::random(901);
          $island['money'] += $v;
          $this->log->maizo($id, $name, $comName, $v);
        }
        $returnMode = 1;
      }
      break;
    case $init->comReclaim:
      // 매립
      if(($landKind != $init->landSea) &&
         ($landKind != $init->landOil) &&
         ($landKind != $init->landSbase)) {
        // 바다, 해저 기지, 유전 밖에 매립하고 할 수 없다
        $this->log->landFail($id, $name, $comName, $landName, $point);

        $returnMode = 0;
        break;
      }

      // 주위에 육지가 있을까 체크
      $seaCount =
        Turn::countAround($land, $x, $y, $init->landSea, 7) +
          Turn::countAround($land, $x, $y, $init->landOil, 7) +
            Turn::countAround($land, $x, $y, $init->landSbase, 7);

      if($seaCount == 7) {
        // 전부해이니까 매립 불능
        $this->log->noLandAround($id, $name, $comName, $point);

        $returnMode = 0;
        break;
      }

      if(($landKind == $init->landSea) && ($lv == 1)) {
        // 얕은 여울의 경우
        // 목적의 장소를 황무지로 한다
        $land[$x][$y] = $init->landWaste;
        $landValue[$x][$y] = 0;
        $this->log->landSuc($id, $name, $comName, $point);
        $island['area']++;

        if($seaCount <= 4) {
          // 주위의 바다가 3 헥스 이내이므로, 얕은 여울로 한다

          for($i = 1; $i < 7; $i++) {
            $sx = $x + $init->ax[$i];
            $sy = $y + $init->ay[$i];

            // 행에 의한 위치 조정
            if((($sy % 2) == 0) && (($y % 2) == 1)) {
              $sx--;
            }

            if(($sx < 0) || ($sx >= $init->islandSize) ||
               ($sy < 0) || ($sy >= $init->islandSize)) {
            } else {
              // 범위내의 경우
              if($land[$sx][$sy] == $init->landSea) {
                $landValue[$sx][$sy] = 1;
              }
            }
          }
        }
      } else {
        // 바다라면, 목적의 장소를 얕은 여울로 한다
        $land[$x][$y] = $init->landSea;
        $landValue[$x][$y] = 1;
        $this->log->landSuc($id, $name, $comName, $point);
      }

      // 금을 공제한다
      $island['money'] -= $cost;
      $returnMode =  1;
      break;

    case $init->comDestroy:
      // 굴착
      if(($landKind == $init->landSbase) ||
         ($landKind == $init->landOil) ||
         ($landKind == $init->landMonster)) {
        // 해저 기지, 유전, 괴수는 굴착할 수 없다
        $this->log->landFail($id, $name, $comName, $landName, $point);

        $returnMode = 0;
        break;
      }

      if(($landKind == $init->landSea) && ($lv == 0)) {
        // 바다라면, 유전 찾기
        // 투자액 결정
        if($arg == 0) { $arg = 1; }

        $value = min($arg * ($cost), $island['money']);
        $str = "{$value}{$init->unitMoney}";
        $p = round($value / $cost);
        $island['money'] -= $value;

        // 발견될까 판정
        if($p > Util::random(100)) {
          // 유전 발견된다
          $this->log->oilFound($id, $name, $point, $comName, $str);
          $land[$x][$y] = $init->landOil;
          $landValue[$x][$y] = 0;
        } else {
          // 헛됨 공격해에 끝난다
          $this->log->oilFail($id, $name, $point, $comName, $str);
        }
        $returnMode = 1;
        break;
      }

      // 목적의 장소를 바다로 한다. 산이라면 황무지에. 얕은 여울이라면 바다에.
      if($landKind == $init->landMountain) {
        $land[$x][$y] = $init->landWaste;
        $landValue[$x][$y] = 0;
      } elseif($landKind == $init->landSea) {
        $landValue[$x][$y] = 0;
      } else {
        $land[$x][$y] = $init->landSea;
        $landValue[$x][$y] = 1;
        $island['area']--;
      }
      $this->log->landSuc($id, $name, $comName, $point);

      // 금을 공제한다
      $island['money'] -= $cost;

      $returnMode = 1;
      break;

    case $init->comSellTree:
      // 벌채
      if($landKind != $init->landForest) {
        // 숲 이외는 벌채할 수 없다
        $this->log->landFail($id, $name, $comName, $landName, $point);

        $returnMode = 0;
        break;
      }

      // 목적의 장소를 평지로 한다
      $land[$x][$y] = $init->landPlains;
      $landValue[$x][$y] = 0;
      $this->log->landSuc($id, $name, $comName, $point);

      // 매각금을 얻는다
      $island['money'] += $init->treeValue * $lv;

      $returnMode = 1;
      break;
    case $init->comPlant:
    case $init->comFarm:
    case $init->comFactory:
    case $init->comBase:
    case $init->comMonument:
    case $init->comHaribote:
    case $init->comDbase:
      // 지상 건설계
      if(!
         (($landKind == $init->landPlains) ||
          ($landKind == $init->landTown)   ||
          (($landKind == $init->landMonument) && ($kind == $init->comMonument)) ||
          (($landKind == $init->landFarm)     && ($kind == $init->comFarm))     ||
          (($landKind == $init->landFactory)  && ($kind == $init->comFactory))  ||
          (($landKind == $init->landDefence)  && ($kind == $init->comDbase)))) {
        // 부적당한 지형
        $this->log->landFail($id, $name, $comName, $landName, $point);

        $returnMode = 0;
        break;
      }

      // 종류로 분기
      switch($kind) {
      case $init->comPlant:
        // 목적의 장소를 숲으로 한다.
        $land[$x][$y] = $init->landForest;
        $landValue[$x][$y] = 1; // 뽜궼띍믟뭁댧
        $this->log->PBSuc($id, $name, $comName, $point);
        break;

      case $init->comBase:
        // 목적의 장소를 미사일 기지로 한다.
        $land[$x][$y] = $init->landBase;
        $landValue[$x][$y] = 0; // 똮뙮뭠0
        $this->log->PBSuc($id, $name, $comName, $point);
        break;

      case $init->comHaribote:
        // 목적의 장소를 하리보테로 한다
        $land[$x][$y] = $init->landHaribote;
        $landValue[$x][$y] = 0;
        $this->log->hariSuc($id, $name, $comName, $init->comName[$init->comDbase], $point);
        break;

      case $init->comFarm:
        // 농장
        if($landKind == $init->landFarm) {
          // 벌써 농장의 경우
          $landValue[$x][$y] += 2; // 규모 + 2000명
          if($landValue[$x][$y] > 50) {
            $landValue[$x][$y] = 50; // 최대 50000명
          }
        } else {
          // 목적의 장소를 농장에
          $land[$x][$y] = $init->landFarm;
          $landValue[$x][$y] = 10; // 규모 = 10000명
        }
        $this->log->landSuc($id, $name, $comName, $point);
        break;

      case $init->comFactory:
        // 공장
        if($landKind == $init->landFactory) {
          // 벌써 공장의 경우
          $landValue[$x][$y] += 10; // 규모 + 10000명
          if($landValue[$x][$y] > 100) {
            $landValue[$x][$y] = 100; // 최대 100000명
          }
        } else {
          // 목적의 장소를 공장에
          $land[$x][$y] = $init->landFactory;
          $landValue[$x][$y] = 30; // 규모 = 10000명
        }
        $this->log->landSuc($id, $name, $comName, $point);
        break;
        
      case $init->comDbase:
        // 방위 시설
        if($landKind == $init->landDefence) {
          // 벌써 방위 시설의 경우
          $landValue[$x][$y] = 1; // 자폭 장치 세트
          $this->log->bombSet($id, $name, $landName, $point);
        } else {
          // 목적의 장소를 방위 시설에
          $land[$x][$y] = $init->landDefence;
          $landValue[$x][$y] = 0;
          $this->log->landSuc($id, $name, $comName, $point);
        }
        break;
        
      case $init->comMonument:
        // 기념비
        if($landKind == $init->landMonument) {
          // 벌써 기념비의 경우

        if($hako->islandTurn <= $init->stopTurn) {
          // 실행이 허가되지 않는다
          $this->log->Forbidden($id, $name, $comName);
          $returnMode = 0;
          break;
        }

          // 타겟 취득
          $tn = $hako->idToNumber[$target];
          if($tn != 0 && empty($tn)) {
            // 타겟이 벌써 없다
            // 아무것도 말하지 않고 중지

            $returnMode = 0;
            break;
          }

          $hako->islands[$tn]['bigmissile']++;

          // 그 자리소는 황무지에
          $land[$x][$y] = $init->landWaste;
          $landValue[$x][$y] = 0;
          $this->log->monFly($id, $name, $landName, $point);
        } else {
          // 목적의 장소를 기념비에
          $land[$x][$y] = $init->landMonument;
          if($arg >= $init->monumentNumber) {
            $arg = 0;
          }
          $landValue[$x][$y] = $arg;
          $this->log->landSuc($id, $name, $comName, $point);
        }
        break;
      }

      // 금을 공제한다
      $island['money'] -= $cost;

      // 회수 첨부라면, 커멘드를 되돌린다
      if(($kind == $init->comFarm) ||
         ($kind == $init->comFactory)) {
        if($arg > 1) {
          $arg--;
          Util::slideBack($comArray, 0);
          $comArray[0] = array (
            'kind'   => $kind,
            'target' => $target,
            'x'      => $x,
            'y'      => $y,
            'arg'    => $arg
            );
        }
      }

      $returnMode = 1;
      break;
      // 여기까지 지상 건설계
    case $init->comMountain:
      // 채굴장
      if($landKind != $init->landMountain) {
        // 산 이외에는 만들 수 없다
        $this->log->landFail($id, $name, $comName, $landName, $point);

        $returnMode = 0;
        break;
      }

      $landValue[$x][$y] += 5; // 규모 + 5000명
      if($landValue[$x][$y] > 200) {
        $landValue[$x][$y] = 200; // 최대 200000명
      }
      $this->log->landSuc($id, $name, $comName, $point);

      // 금을 공제한다
      $island['money'] -= $cost;
      if($arg > 1) {
        $arg--;
        Util::slideBack($comArray, 0);
        $comArray[0] = array (
          'kind'   => $kind,
          'target' => $target,
          'x'      => $x,
          'y'      => $y,
          'arg'    => $arg,
          );
      }
      $returnMode = 1;
      break;

    case $init->comSbase:
      // 해저 기지
      if(($landKind != $init->landSea) || ($lv != 0)){
        // 바다 이외에는 만들 수 없다
        $this->log->landFail($id, $name, $comName, $landName, $point);
        $returnMode = 0;
        break;
      }

      $land[$x][$y] = $init->landSbase;
      $landValue[$x][$y] = 0; // 경험치 0
      $this->log->landSuc($id, $name, $comName, '(?, ?)');

      // 금을 공제한다
      $island['money'] -= $cost;
      $returnMode = 1;
      break;

    case $init->comMissileNB:
      // 네이팜탄

      if($island['now'] <= 0) {
        // 소유하고 있지 않다
        $this->log->noNB($id, $name, $comName);
        $returnMode = 0;
        break;
      }

      if($hako->islandTurn <= $init->stopTurn) {
        // 실행이 허가되지 않는다
        $this->log->Forbidden($id, $name, $comName);
        $returnMode = 0;
        break;
      }

      // 타겟 취득
      $tn = $hako->idToNumber[$target];
      if($tn != 0 && empty($tn)) {
        // 타겟이 벌써 없다
        $this->log->msNoTarget($id, $name, $comName);

        $returnMode = 0;
        break;
      }

      $bx = $by = 0;
      // 기지를 찾아낼 때까지 루프
      while($count < $init->pointNumber) {
        $bx = $this->rpx[$count];
        $by = $this->rpy[$count];
        if(($land[$bx][$by] == $init->landBase) ||
          ($land[$bx][$by] == $init->landSbase)) {
          break;
        }
        $count++;
      }
      if($count >= $init->pointNumber) {
        // 발견되지 않았으면 거기까지
        break;
      }

      // 사전 준비
      $tIsland = $hako->islands[$tn];
      $tName   = $tIsland['name'];
      $tLand   = $tIsland['land'];
      $tLandValue = $tIsland['landValue'];

      // 착탄점의 지형등 산출
      $tL  = $tLand[$x][$y];
      $tLv = $tLandValue[$x][$y];
      $tLname = $this->landName($tL, $tLv);
      $tPoint = "({$x}, {$y})";

      if($island['id'] == $tIsland['id']) {
        $tLand[$x][$y] = $land[$x][$y];
      }

      if(($tL == $init->landSea) || ($tL == $init->landOil) ||
        ($tL == $init->landWaste) || ($tL == $init->landSbase)) {
        $this->log->NBfail($id, $target, $name, $tName, $comName, $tLname, $point);
      } else {
        $this->log->NBSuc($id, $target, $name, $tName, $comName, $tLname, $point);
        $tLand[$x][$y] = $init->landWaste;
        $tLandValue[$x][$y] = 1;
      }

      // 돈과 소유수를 공제한다
      $island['money'] -= $cost;
      $island['now'] -= 1;

      $returnMode = 0;
      break;

    case $init->comMissileNM:
    case $init->comMissilePP:
    case $init->comMissileST:
    case $init->comMissileLD:
      // 미사일계

      if($hako->islandTurn <= $init->stopTurn) {
        // 실행이 허가되지 않는다
        $this->log->Forbidden($id, $name, $comName);
        $returnMode = 0;
        break;
      }

      $flag = 0;
      do {
      if($arg == 0) {
        // 0의 경우는 공격할 수 있을 뿐
        $arg = 10000;
      }

      // 타겟 취득
      $tn = $hako->idToNumber[$target];
      if($tn != 0 && empty($tn)) {
        // 타겟이 벌써 없다
        $this->log->msNoTarget($id, $name, $comName);

        $returnMode = 0;
        break;
      }

      // 사전 준비
      $tIsland = $hako->islands[$tn];
      $tName   = $tIsland['name'];
      $tLand   = $tIsland['land'];
      $tLandValue = $tIsland['landValue'];
      // 난민의 수
      $boat = 0;
      // 미사일의 내역
      $missiles = 0;
      $missileA = 0;
      $missileB = 0;
      $missileC = 0;
      $missileD = 0;

      // 오차
      if($kind == $init->comMissilePP) {
        $err = 7;
      } else {
        $err = 19;
      }

      $bx = $by = 0;
      // 금이 바닥날까 지정수 기에 충분할까 기지 전부가 공격할 때까지 루프
      while(($arg > 0) &&
            ($island['money'] >= $cost)) {
        // 기지를 찾아낼 때까지 루프
        while($count < $init->pointNumber) {
          $bx = $this->rpx[$count];
          $by = $this->rpy[$count];
          if(($land[$bx][$by] == $init->landBase) ||
             ($land[$bx][$by] == $init->landSbase)) {
            break;
          }
          $count++;
        }
        if($count >= $init->pointNumber) {
          // 발견되지 않았으면 거기까지
          break;
        }
        // 최저1개(살) 기지가 있었으므로, flag를 세운다
        $flag = 1;
        // 기지의 레벨을 산출
        $level = Util::expToLevel($land[$bx][$by], $landValue[$bx][$by]);
        // 기지내에서 루프
        while(($level > 0) &&
              ($arg > 0) &&
              ($island['money'] > $cost)) {
          // 공격했던 것이 확정이므로, 각 치를 소모시킨다
          $level--;
          $arg--;
          $island['money'] -= $cost;
          $island['fire'] -= 1;
          $missiles++;

          // 상대의 비 와 미사일＋
          $tIsland['min']++;
          $mCount++;

          // 자신의 발사 미사일수＋
          $island['mout']++;
          $island['total']++;

          // 착탄점산출
          $r = Util::random($err);
          $tx = $x + $init->ax[$r];
          $ty = $y + $init->ay[$r];
          if((($ty % 2) == 0) && (($y % 2) == 1)) {
            $tx--;
          }

          // 착탄점범위내외 체크
          if(($tx < 0) || ($tx >= $init->islandSize) ||
             ($ty < 0) || ($ty >= $init->islandSize)) {
            // 범위외
            $missileA++;
            continue;
          }

          // 착탄점의 지형등 산출
          $tL  = $tLand[$tx][$ty];
          $tLv = $tLandValue[$tx][$ty];
          $tLname = $this->landName($tL, $tLv);
          $tPoint = "({$tx}, {$ty})";

          if($island['id'] == $tIsland['id']) {
            $tLand[$tx][$ty] = $land[$tx][$ty];
          }

          // 방위 시설 판정
          $defence = 0;
          if($defenceHex[$id][$tx][$ty] == 1) {
            $defence = 1;
          } elseif($defenceHex[$id][$tx][$ty] == -1) {
            $defence = 0;
          } else {
            if($tL == $init->landDefence) {
              // 방위 시설에 명중
              // 플래그를 클리어
              for($i = 0; $i < 19; $i++) {
                $sx = $tx + $init->ax[$i];
                $sy = $ty + $init->ay[$i];

                // 행에 의한 위치 조정
                if((($sy % 2) == 0) && (($ty % 2) == 1)) {
                  $sx--;
                }

                if(($sx < 0) || ($sx >= $init->islandSize) ||
                   ($sy < 0) || ($sy >= $init->islandSize)) {
                  // 범위외의 경우 아무것도 하지 않는다
                } else {
                  // 범위내의 경우
                  $defenceHex[$id][$sx][$sy] = 0;
                }
              }
            } elseif(Turn::countAround($tLand, $tx, $ty, $init->landDefence, 19)) {
              $defenceHex[$id][$tx][$ty] = 1;
              $defence = 1;
            } else {
              $defenceHex[$id][$tx][$ty] = -1;
              $defence = 0;
            }
          }

          if($defence == 1) {
            // 공중 폭파
            $missileB++;
            continue;
          }

          // 「효과 없음」hex를 최초로 판정
          if((($tL == $init->landSea) && ($tLv == 0))|| // 깊은 바다
             ((($tL == $init->landSea) ||    // 바다 또는···
               ($tL == $init->landSbase) ||  // 해저 기지 또는···
               ($tL == $init->landMountain)) // 산에서···
              && ($kind != $init->comMissileLD))) { // 륙파탄 이외
            // 해저 기지의 경우, 바다의 후리
            if($tL == $init->landSbase) {
              $tL = $init->landSea;
            }
            $tLname = $this->landName($tL, $tLv);

            // 무효화
            $missileA++;
            continue;
          }

          // 총알의 종류로 분기
          if($kind == $init->comMissileLD) {
            // 육지 파괴탄
            switch($tL) {
            case $init->landMountain:
              // 산(황무지가 된다)
              $this->log->msLDMountain($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint);
              // 황무지가 된다
              $tLand[$tx][$ty] = $init->landWaste;
              $tLandValue[$tx][$ty] = 0;
              continue 2;

            case $init->landSbase:
              //  해저 기지
              $this->log->msLDSbase($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint);
              break;
              
            case $init->landMonster:
              // 괴수
              $this->log->msLDMonster($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint);
              break;
              
            case $init->landSea:
              // 얕은 여울
              $this->log->msLDSea1($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint);
              break;
              
            default:
              // 그 외
              $this->log->msLDLand($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint);
            }

            // 경험치
            if($tL == $init->landTown) {
              if(($land[$bx][$by] == $init->landBase) ||
                 ($land[$bx][$by] == $init->landSbase)) {
                // 아직 기지의 경우만
                $landValue[$bx][$by] += round($tLv / 20);
                if($landValue[$bx][$by] > $init->maxExpPoint) {
                  $landValue[$bx][$by] = $init->maxExpPoint;
                }
              }
            }

            // 얕은 여울이 된다
            $tLand[$tx][$ty] = $init->landSea;
            $tIsland['area']--;
            $tLandValue[$tx][$ty] = 1;

            // 그렇지만 유전, 얕은 여울, 해저 기지라면 바다
            if(($tL == $init->landOil) ||
               ($tL == $init->landSea) ||
               ($tL == $init->landSbase)) {
              $tLandValue[$tx][$ty] = 0;
            }
          } else {
            // 그 외 미사일
            if($tL == $init->landWaste) {
              // 황무지(피해 없음)
              $missileA++;
            } elseif($tL == $init->landMonster) {
              // 괴수
              $monsSpec = Util::monsterSpec($tLv);
              $special = $init->monsterSpecial[$monsSpec['kind']];

              // 경화중?
              if((($special == 3) && (($hako->islandTurn % 2) == 1)) ||
                 (($special == 4) && (($hako->islandTurn % 2) == 0))) {
                // 경화중
                if($kind == $init->comMissileST) {
                  // 스텔스
                  $this->log->msMonNoDamageS($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint);
                } else {
                  // 통상탄
                  $this->log->msMonNoDamage($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint);
                }
                $missileC++;
                continue;
              } else {
                // 경화중이 아니다
                if($monsSpec['hp'] == 1) {
                  // 괴수 쏘아 죽였다
                  if(($land[$bx][$by] == $init->landBase) ||
                     ($land[$bx][$by] == $init->landSbase)) {
                    // 경험치
                    $landValue[$bx][$by] += $init->monsterExp[$monsSpec['kind']];
                    if($landValue[$bx][$by] > $init->maxExpPoint) {
                      $landValue[$bx][$by] = $init->maxExpPoint;
                    }
                  }
                  $missileD++;

                  if($kind == $init->comMissileST) {
                    // 스텔스
                    $this->log->msMonKillS($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint);
                  } else {
                    // 통상
                    $this->log->msMonKill($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint);
                  }

                  // 수입
                  $value = $init->monsterValue[$monsSpec['kind']];
                  if($value > 0) {
                    $tIsland['money'] += $value;
                    $this->log->msMonMoney($target, $tLname, $value);
                  }

                  // 상관계
//                  $prize = $island['prize'];
                  list($flags, $monsters, $turns) = split(",", $prize, 3);
                  $v = 1 << $monsSpec['kind'];
                  $monsters |= $v;

                  $prize = "{$flags},{$monsters},{$turns}";
//                  $island['prize'] = "{$flags},{$monsters},{$turns}";
                } else {
                  // 괴수 살아 있다
                  if($kind == $init->comMissileST) {
                    // 스텔스
                    $this->log->msMonsterS($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint);
                  } else {
                    // 통상
                    $this->log->msMonster($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint);
                  }
                  // HP가  1줄어든다
                  $tLandValue[$tx][$ty]--;
                  $missileD++;
                  continue;
                }

              }
            } else {
              // 통상 지형
              if($kind == $init->comMissileST) {
                // 스텔스
                $this->log->msNormalS($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint);
              } else {
                // 통상
                $this->log->msNormal($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint);
              }
            }
            // 경험치
            if($tL == $init->landTown) {
              if(($land[$bx][$by] == $init->landBase) ||
                 ($land[$bx][$by] == $init->landSbase)) {
                $landValue[$bx][$by] += round($tLv / 20);
                $boat += $tLv; // 통상 미사일이므로 난민에게 플러스
                if($landValue[$bx][$by] > $init->maxExpPoint) {
                  $landValue[$bx][$by] = $init->maxExpPoint;
                }
              }
            }

            // 황무지가 된다
            $tLand[$tx][$ty] = $init->landWaste;
            $tLandValue[$tx][$ty] = 1; // 착탄점
            // 그렇지만 유전이라면 바다
            if($tL == $init->landOil) {
              $tLand[$tx][$ty] = $init->landSea;
              $tLandValue[$tx][$ty] = 0;
            }
          }
        }

        // 카운트증가나 해 둔다
        $count++;
      }

      // 미사일 로그
      if($missiles > 0){
        if($kind == $init->comMissileST) {
          // 스텔스
          $this->log->mslogS($id, $target, $name, $tName, $comName, $point, $missiles, $missileA, $missileB, $missileC, $missileD);
        } else {
          // 통상
          $this->log->mslog($id, $target, $name, $tName, $comName, $point, $missiles, $missileA, $missileB, $missileC, $missileD);
        }
      }

      if($flag == 0) {
        // 기지가 1개나 없었던 경우
        $this->log->msNoBase($id, $name, $comName);

        $returnMode = 0;
        break;
      }
      if($island['fire'] == 0) {
        // 최대 발사수를 넘었을 경우
        $this->log->msMaxOver($id, $name, $comName);

        $returnMode = 0;
        break;
      }
      
      $tIsland['land'] = $tLand;
      $tIsland['landValue'] = $tLandValue;
      unset($hako->islands[$tn]);
      $hako->islands[$tn] = $tIsland;
      
      
      // 난민 판정
      $boat = round($boat / 2);
      if(($boat > 0) && ($id != $target) && ($kind != $init->comMissileST)) {
        // 난민 표착
        $achive = 0; // 도달 난민
        for($i = 0; ($i < $init->pointNumber && $boat > 0); $i++) {
          $bx = $this->rpx[$i];
          $by = $this->rpy[$i];
          if($land[$bx][$by] == $init->landTown) {
            // 마을의 경우
            $lv = $landValue[$bx][$by];
            if($boat > 50) {
              $lv += 50;
              $boat -= 50;
              $achive += 50;
            } else {
              $lv += $boat;
              $achive += $boat;
              $boat = 0;
            }
            if($lv > 200) {
              $boat += ($lv - 200);
              $achive -= ($lv - 200);
              $lv = 200;
            }
            $landValue[$bx][$by] = $lv;
          } elseif($land[$bx][$by] == $init->landPlains) {
            // 평지의 경우
            $land[$bx][$by] = $init->landTown;;
            if($boat > 10) {
              $landValue[$bx][$by] = 5;
              $boat -= 10;
              $achive += 10;
            } elseif($boat > 5) {
              $landValue[$bx][$by] = $boat - 5;
              $achive += $boat;
              $boat = 0;
            }
          }
          if($boat <= 0) {
            break;
          }
        }
        if($achive > 0) {
          // 조금이라도 도착했을 경우, 로그를 토한다
          $this->log->msBoatPeople($id, $name, $achive);

          // 난민의 수가 일정수이상이라면, 평화상의 가능성 있어
          if($achive >= 200) {
            $prize = $island['prize'];
            list($flags, $monsters, $turns) = split(",", $prize, 3);

            if((!($flags & 8)) &&  $achive >= 200){
              $flags |= 8;
              $this->log->prize($id, $name, $init->prizeName[4]);
            } elseif((!($flags & 16)) &&  $achive > 500){
              $flags |= 16;
              $this->log->prize($id, $name, $init->prizeName[5]);
            } elseif((!($flags & 32)) &&  $achive > 800){
              $flags |= 32;
              $this->log->prize($id, $name, $init->prizeName[6]);
            }
            $island['prize'] = "{$flags},{$monsters},{$turns}";
          }
        }
      }

        $command  = $comArray[0];
        $kind   = $command['kind'];
        if (( $kind == $init->comMissileNM ) ||  // 다음도 미사일계라면...
            ( $kind == $init->comMissilePP ) ||
            ( $kind == $init->comMissileST ) ||
            ( $kind == $init->comMissileLD )) {

          $cost = $init->comCost[$kind];
          if (($island['fire'] > 0) && ($island['money'] >= $cost)) { // 적어도 1발은 공격할 수 있다
            Util::slideFront($comArray, 0);
            $island['command'] = $comArray;

            $kind   = $command['kind'];
            $target = $command['target'];
            $x      = $command['x'];
            $y      = $command['y'];
            $arg    = $command['arg'];

            $comName = $init->comName[$kind];
            $point = "({$x},{$y})";
            $landName = $this->landName($landKind, $lv);
          } else {
            break;
          }
        } else if($kind == $init->comMissileSM) {
          Util::slideFront($comArray, 0);
          break;
        } else {
          break;
        }
      } while (($island['fire'] > 0) && ($init->multiMissiles));

      $returnMode = 1;
      break;

    case $init->comSendMonster:
      // 괴수 파견

      if($hako->islandTurn <= $init->stopTurn) {
        // 실행이 허가되지 않는다
        $this->log->Forbidden($id, $name, $comName);
        $returnMode = 0;
        break;
      }

      // 타겟 취득
      $tn = $hako->idToNumber[$target];
      $tIsland = $hako->islands[$tn];
      $tName = $tIsland['name'];
      
      if($tn != 0 && empty($tn)) {
        // 타겟이 벌써 없다
        $this->log->msNoTarget($id, $name, $comName);

        $returnMode = 0;
        break;
      }

      // 메세지
      $this->log->monsSend($id, $target, $name, $tName);
      $tIsland['monstersend']++;
      $hako->islands[$tn] = $tIsland;

      $island['money'] -= $cost;
      $returnMode = 1;
      break;

    case $init->comSell:
      // 수출량 결정
      if($arg == 0) { $arg = 1; }
      $value = min($arg * (-$cost), $island['food']);

      // 수출 로그
      $this->log->sell($id, $name, $comName, $value);
      $island['food'] -=  $value;
      $island['money'] += ($value / 10);

      $returnMode = 0;
      break;
      
    case $init->comPropaganda:
      // 유치 활동
      $this->log->propaganda($id, $name, $comName);
      $island['propaganda'] = 1;
      $island['money'] -= $cost;

      $returnMode = 1;
      break;

    case $init->comGiveup:
      // 방폐
      $this->log->giveup($id, $name);
      $island['dead'] = 1;
      unlink("{$init->dirName}/island.{$id}");

      $returnMode = 1;
      break;
    }

    // 변경된 가능성이 있는 변수를 써 되돌린다
//    $hako->islands[$hako->idToNumber[$id]] = $island;

    // 사후 처리
    unset($island['prize']);
    unset($island['land']);
    unset($island['landValue']);
    unset($island['command']);
    $island['prize'] = $prize;
    $island['land'] = $land;
    $island['landValue'] = $landValue;
    $island['command'] = $comArray;

    return $returnMode;
  }
  //---------------------------------------------------
  // 성장 및 단헥스 재해
  //---------------------------------------------------
  function doEachHex($hako, $island) {
    global $init;
    // 도출치
    $name = $island['name'];
    $id = $island['id'];
    $land = $island['land'];
    $landValue = $island['landValue'];

    // 증가하는 인구의 씨치
    $addpop  = 10;  // 마을, 마을
    $addpop2 = 0; // 도시
    if($island['food'] < 0) {
      // 식량 부족
      $addpop = -30;
    } elseif($island['propaganda'] == 1) {
      // 유치 활동중
      $addpop = 30;
      $addpop2 = 3;
    }
    $monsterMove = array();
    // 루프
    for($i = 0; $i < $init->pointNumber; $i++) {
      $x = $this->rpx[$i];
      $y = $this->rpy[$i];
      $landKind = $land[$x][$y];
      $lv = $landValue[$x][$y];

      switch($landKind) {
      case $init->landTown:
        // 마을계
        if($addpop < 0) {
          // 부족
          $lv -= (Util::random(-$addpop) + 1);
          if($lv <= 0) {
            // 평지에 되돌린다
            $land[$x][$y] = $init->landPlains;
            $landValue[$x][$y] = 0;
            continue 2;
          }
        } else {
          // 성장
          if($lv < 100) {
            $lv += Util::random($addpop) + 1;
            if($lv > 100) {
              $lv = 100;
            }
          } else {
            // 도시가 되면(자) 성장 늦다
            if($addpop2 > 0) {
              $lv += Util::random($addpop2) + 1;
            }
          }
        }
        if($lv > 200) {
          $lv = 200;
        }
        $landValue[$x][$y] = $lv;
        break;
        
      case $init->landPlains:
        // 평지
        if(Util::random(5) == 0) {
          // 주위에 농장, 마을이 있으면, 여기도 마을이 된다
          if($this->countGrow($land, $landValue, $x, $y)){
            $land[$x][$y] = $init->landTown;
            $landValue[$x][$y] = 1;
          }
        }
        break;
        
      case $init->landForest:
        // 삼
        if($lv < 200) {
          // 나무를 늘린다
          $landValue[$x][$y]++;
        }
        break;
        
      case $init->landDefence:
        if($lv == 1) {
          // 방위 시설 자폭
          $lName = $this->landName($landKind, $lv);
          $this->log->bombFire($id, $name, $lName, "($x, $y)");

          // 광역 피해 루틴
          $this->wideDamage($id, $name, $land, $landValue, $x, $y);
        }
        break;
        
      case $init->landOil:
        // 해저 유전
        $lName = $this->landName($landKind, $lv);
        $value = $init->oilMoney;
        $island['money'] += $value;
        $str = "{$value}{$init->unitMoney}";

        // 수입 로그
        $this->log->oilMoney($id, $name, $lName, "($x, $y)", $str);

        // 고갈 판정
        if(Util::random(1000) < $init->oilRatio) {
          // 고갈
          $this->log->oilEnd($id, $name, $lName, "($x, $y)");
          $land[$x][$y] = $init->landSea;
          $landValue[$x][$y] = 0;
        }
        break;
        
      case $init->landMonster:

        // 괴수
        if($monsterMove[$x][$y] == 2) {
          // 벌써 움직인 후
          break;
        }

        // 각 요소의 꺼내
        $monsSpec = Util::monsterSpec($landValue[$x][$y]);
        $special  = $init->monsterSpecial[$monsSpec['kind']];
        $mName    = $monsSpec['name'];
        // 경화중?
        if((($special == 3) && (($hako->islandTurn % 2) == 1)) ||
           (($special == 4) && (($hako->islandTurn % 2) == 0))) {
          // 경화중
          break;
        }

        // 움직일 방향을 결정
        for($j = 0; $j < 3; $j++) {
          $d = Util::random(6) + 1;
          $sx = $x + $init->ax[$d];
          $sy = $y + $init->ay[$d];

          // 행에 의한 위치 조정
          if((($sy % 2) == 0) && (($y % 2) == 1)) {
            $sx--;
          }

          // 범위외 판정
          if(($sx < 0) || ($sx >= $init->islandSize) ||
             ($sy < 0) || ($sy >= $init->islandSize)) {
            continue;
          }
          // 바다, 해 기, 유전, 괴수, 산, 기념비 이외
          if(($land[$sx][$sy] != $init->landSea) &&
             ($land[$sx][$sy] != $init->landSbase) &&
             ($land[$sx][$sy] != $init->landOil) &&
             ($land[$sx][$sy] != $init->landMountain) &&
             ($land[$sx][$sy] != $init->landMonument) &&
             ($land[$sx][$sy] != $init->landMonster)) {
            break;
          }
        }

        if($j == 3) {
          // 움직이지 않았다
          break;
        }

        // 움직인 앞의 지형에 의해 메세지
        $l = $land[$sx][$sy];
        $lv = $landValue[$sx][$sy];
        $lName = $this->landName($l, $lv);
        $point = "({$sx}, {$sy})";

        // 이동
        $land[$sx][$sy] = $land[$x][$y];
        $landValue[$sx][$sy] = $landValue[$x][$y];

        // 아래 있던 위치를 황무지에
        $land[$x][$y] = $init->landWaste;
        $landValue[$x][$y] = 0;
      
        // 이동이 끝난 플래그
        if($init->monsterSpecial[$monsSpec['kind']] == 2) {
          // 이동이 끝난 플래그는 세우지 않다
        } elseif($init->monsterSpecial[$monsSpec['kind']] == 1) {
          //  빠른 괴수
          $monsterMove[$sx][$sy] = $monsterMove[$x][$y] + 1;
        } else {
          // 보통 괴수
          $monsterMove[$sx][$sy] = 2;
        }
        if(($l == $init->landDefence) && ($init->dBaseAuto == 1)) {
          // 방위 시설을 밟았다
          $this->log->monsMoveDefence($id, $name, $lName, $point, $mName);

          // 광역 피해 루틴
          $this->wideDamage($id, $name, $land, $landValue, $sx, $sy);
        } else {
          // 행선지가 황무지가 된다
          $this->log->monsMove($id, $name, $lName, $point, $mName);
        }
        break;
      }
      // 벌써 $init->landTown가 case문으로 사용되고 있으므로 switch를 별로 준비
      switch($landKind) {
      case $init->landTown:
      case $init->landHaribote:
      case $init->landFactory:
        // 화재 판정
        if($landKind == $init->landTown && ($lv <= 30))
          break;
        
        if(Util::random(1000) < $init->disFire) {
          // 주위의 숲과 기념비를 센다
          if((Turn::countAround($land, $x, $y, $init->landForest, 7) +
              Turn::countAround($land, $x, $y, $init->landMonument, 7)) == 0) {
            // 없었던 경우, 화재로 괴멸
            $l = $land[$x][$y];
            $lv = $landValue[$x][$y];
            $point = "({$x}, {$y})";
            $lName = $this->landName($l, $lv);
            $this->log->fire($id, $name, $lName, $point);
            $land[$x][$y] = $init->landWaste;
            $landValue[$x][$y] = 0;
          }
        }
        break;
      }
    }
    // 변경된 가능성이 있는 변수를 써 되돌린다
    $island['land'] = $land;
    $island['landValue'] = $landValue;
  }

  //---------------------------------------------------
  // 섬전체
  //---------------------------------------------------
  function doIslandProcess($hako, $island) {
    global $init;
    
    // 도출치
    $name = $island['name'];
    $id = $island['id'];
    $land = $island['land'];
    $landValue = $island['landValue'];

    // 지진 판정
    if(Util::random(1000) < (($island['prepare2'] + 1) * $init->disEarthquake)) {
      // 지진 발생
      $this->log->earthquake($id, $name);

      for($i = 0; $i < $init->pointNumber; $i++) {
        $x = $this->rpx[$i];
        $y = $this->rpy[$i];
        $landKind = $land[$x][$y];
        $lv = $landValue[$x][$y];

        if((($landKind == $init->landTown) && ($lv >= 100)) ||
           ($landKind == $init->landHaribote) ||
           ($landKind == $init->landFactory)) {
          // 1/4그리고 괴멸
          if(Util::random(4) == 0) {
            $this->log->eQDamage($id, $name, $this->landName($landKind, $lv), "({$x}, {$y})");
            $land[$x][$y] = $init->landWaste;
            $landValue[$x][$y] = 0;
          }
        }
      }
    }

    // 식량 부족
    if($island['food'] <= 0) {
      // 부족 메세지
      $this->log->starve($id, $name);
      $island['food'] = 0;

      for($i = 0; $i < $init->pointNumber; $i++) {
        $x = $this->rpx[$i];
        $y = $this->rpy[$i];
        $landKind = $land[$x][$y];
        $lv = $landValue[$x][$y];

        if(($landKind == $init->landFarm) ||
           ($landKind == $init->landFactory) ||
           ($landKind == $init->landBase) ||
           ($landKind == $init->landDefence)) {
          // 1/4그리고 괴멸
          if(Util::random(4) == 0) {
            $this->log->svDamage($id, $name, $this->landName($landKind, $lv), "({$x}, {$y})");
            $land[$x][$y] = $init->landWaste;
            $landValue[$x][$y] = 0;
          }
        }
      }
    }

    // 해일 판정
    if(Util::random(1000) < $init->disTsunami) {
      // 해일 발생
      $this->log->tsunami($id, $name);

      for($i = 0; $i < $init->pointNumber; $i++) {
        $x = $this->rpx[$i];
        $y = $this->rpy[$i];
        $landKind = $land[$x][$y];
        $lv = $landValue[$x][$y];

        if(($landKind == $init->landTown) ||
           ($landKind == $init->landFarm) ||
           ($landKind == $init->landFactory) ||
           ($landKind == $init->landBase) ||
           ($landKind == $init->landDefence) ||
           ($landKind == $init->landHaribote)) {
          // 1d12 <= (주위의 바다 - 1)로 붕괴
          if(Util::random(12) <
             (Turn::countAround($land, $x, $y, $init->landOil, 7) +
              Turn::countAround($land, $x, $y, $init->landSbase, 7) +
              Turn::countAround($land, $x, $y, $init->landSea, 7) - 1)) {
            $this->log->tsunamiDamage($id, $name, $this->landName($landKind, $lv), "({$x}, {$y})");
            $land[$x][$y] = $init->landWaste;
            $landValue[$x][$y] = 0;
          }
        }

      }
    }

    // 괴수 판정
    $r = Util::random(10000);
    $pop = $island['pop'];
    do{
      if((($r < ($init->disMonster * $island['area'])) &&
          ($pop >= $init->disMonsBorder1) && ($hako->islandTurn > $init->stopTurn)) ||
         ($island['monstersend'] > 0)) {
        // 괴수 출현
        // 종류를 결정한다
        if($island['monstersend'] > 0) {
          // 인조
          $kind = 0;
          $island['monstersend']--;
        } elseif($pop >= $init->disMonsBorder3) {
          // level3까지
          $kind = Util::random($init->monsterLevel3) + 1;
        } elseif($pop >= $init->disMonsBorder2) {
          // level2까지
          $kind = Util::random($init->monsterLevel2) + 1;
        } else {
          //  level1만
          $kind = Util::random($init->monsterLevel1) + 1;
        }

        // lv의 값을 결정한다
        $lv = $kind * 10
          + $init->monsterBHP[$kind] + Util::random($init->monsterDHP[$kind]);

        // 어디에 나타날까 결정한다
        for($i = 0; $i < $init->pointNumber; $i++) {
          $bx = $this->rpx[$i];
          $by = $this->rpy[$i];
          if($land[$bx][$by] == $init->landTown) {

            // 지형명
            $lName = $this->landName($init->landTown, $landValue[$bx][$by]);

            // 그 헥스를 괴수에게
            $land[$bx][$by] = $init->landMonster;
            $landValue[$bx][$by] = $lv;

            // 괴수 정보
            $monsSpec = Util::monsterSpec($lv);
            $mName    = $monsSpec['name'];

            // 메세지
            $this->log->monsCome($id, $name, $mName, "({$bx}, {$by})", $lName);
            break;
          }
        }
      }
    } while($island['monstersend'] > 0);

    // 지반침하 판정
    if(($island['area'] > $init->disFallBorder) &&
       (Util::random(1000) < $init->disFalldown)) {
      // 지반침하 발생
      $this->log->falldown($id, $name);

      for($i = 0; $i < $init->pointNumber; $i++) {
        $x = $this->rpx[$i];
        $y = $this->rpy[$i];
        $landKind = $land[$x][$y];
        $lv = $landValue[$x][$y];

        if(($landKind != $init->landSea) &&
           ($landKind != $init->landSbase) &&
           ($landKind != $init->landOil) &&
           ($landKind != $init->landMountain)) {

          // 주위에 바다가 있으면, 값을―1에
          if(Turn::countAround($land, $x, $y, $init->landSea, 7) +
             Turn::countAround($land, $x, $y, $init->landSbase, 7)) {
            $this->log->falldownLand($id, $name, $this->landName($landKind, $lv), "({$x}, {$y})");
            $land[$x][$y] = -1;
            $landValue[$x][$y] = 0;
          }
        }
      }

      for($i = 0; $i < $init->pointNumber; $i++) {
        $x = $this->rpx[$i];
        $y = $this->rpy[$i];
        $landKind = $land[$x][$y];

        if($landKind == -1) {
          // -1(이)가 되어 있는 곳을 얕은 여울에
          $land[$x][$y] = $init->landSea;
          $landValue[$x][$y] = 1;
        } elseif ($landKind == $init->landSea) {
          // 얕은 여울은 바다에
          $landValue[$x][$y] = 0;
        }

      }
    }

    // 태풍 판정
    if(Util::random(1000) < $init->disTyphoon) {
      // 태풍 발생
      $this->log->typhoon($id, $name);

      for($i = 0; $i < $init->pointNumber; $i++) {
        $x = $this->rpx[$i];
        $y = $this->rpy[$i];
        $landKind = $land[$x][$y];
        $lv = $landValue[$x][$y];

        if(($landKind == $init->landFarm) ||
           ($landKind == $init->landHaribote)) {

          // 1d12 <= (6 - 주위의 숲)로 붕괴
          if(Util::random(12) <
             (6
              - Turn::countAround($land, $x, $y, $init->landForest, 7)
              - Turn::countAround($land, $x, $y, $init->landMonument, 7))) {
            $this->log->typhoonDamage($id, $name, $this->landName($landKind, $lv), "({$x}, {$y})");
            $land[$x][$y] = $init->landPlains;
            $landValue[$x][$y] = 0;
          }
        }
      }
    }

    // 거대 운석 판정
    if(Util::random(1000) < $init->disHugeMeteo) {

      // 낙하
      $x = Util::random($init->islandSize);
      $y = Util::random($init->islandSize);
      $landKind = $land[$x][$y];
      $lv = $landValue[$x][$y];
      $point = "({$x}, {$y})";

      // 메세지
      $this->log->hugeMeteo($id, $name, $point);

      // 광역 피해 루틴
      $this->wideDamage($id, $name, $land, $landValue, $x, $y);
    }

    // 거대 미사일 판정
    while($island['bigmissile'] > 0) {
      $island['bigmissile']--;

      // 낙하
      $x = Util::random($init->islandSize);
      $y = Util::random($init->islandSize);
      $landKind = $land[$x][$y];
      $lv = $landValue[$x][$y];
      $point = "({$x}, {$y})";

      // 메세지
      $this->log->monDamage($id, $name, $point);

      // 광역 피해 루틴
      $this->wideDamage($id, $name, $land, $landValue, $x, $y);
    }

    // 운석 판정
    if(Util::random(1000) < $init->disMeteo) {
      $first = 1;
      while((Util::random(2) == 0) || ($first == 1)) {
        $first = 0;

        // 낙하
        $x = Util::random($init->islandSize);
        $y = Util::random($init->islandSize);
        $landKind = $land[$x][$y];
        $lv = $landValue[$x][$y];
        $point = "({$x}, {$y})";

        if(($landKind == $init->landSea) && ($lv == 0)){
          // 바다 포체
          $this->log->meteoSea($id, $name, $this->landName($landKind, $lv), $point);
        } elseif($landKind == $init->landMountain) {
          // 산파괴
          $this->log->meteoMountain($id, $name, $this->landName($landKind, $lv), $point);
          $land[$x][$y] = $init->landWaste;
          $landValue[$x][$y] = 0;
          continue;
        } elseif($landKind == $init->landSbase) {
          $this->log->meteoSbase($id, $name, $this->landName($landKind, $lv), $point);
        } elseif($landKind == $init->landMonster) {
          $this->log->meteoMonster($id, $name, $this->landName($landKind, $lv), $point);
        } elseif($landKind == $init->landSea) {
          // 얕은 여울
          $this->log->meteoSea1($id, $name, $this->landName($landKind, $lv), $point);
        } else {
          $this->log->meteoNormal($id, $name, $this->landName($landKind, $lv), $point);
        }
        $land[$x][$y] = $init->landSea;
        $landValue[$x][$y] = 0;
      }
    }

    // 분화 판정
    if(Util::random(1000) < $init->disEruption) {
      $x = Util::random($init->islandSize);
      $y = Util::random($init->islandSize);
      $landKind = $land[$x][$y];
      $lv = $landValue[$x][$y];
      $point = "({$x}, {$y})";
      $this->log->eruption($id, $name, $this->landName($landKind, $lv), $point);
      $land[$x][$y] = $init->landMountain;
      $landValue[$x][$y] = 0;

      for($i = 1; $i < 7; $i++) {
        $sx = $x + $init->ax[$i];
        $sy = $y + $init->ay[$i];

        // 행에 의한 위치 조정
        if((($sy % 2) == 0) && (($y % 2) == 1)) {
          $sx--;
        }

        $landKind = $land[$sx][$sy];
        $lv = $landValue[$sx][$sy];
        $point = "({$sx}, {$sy})";

        if(($sx < 0) || ($sx >= $init->islandSize) ||
           ($sy < 0) || ($sy >= $init->islandSize)) {
        } else {
          // 범위내의 경우
          $landKind = $land[$sx][$sy];
          $lv = $landValue[$sx][$sy];
          $point = "({$sx}, {$sy})";
          if(($landKind == $init->landSea) ||
             ($landKind == $init->landOil) ||
             ($landKind == $init->landSbase)) {
            // 바다의 경우
            if($lv == 1) {
              // 얕은 여울
              $this->log->eruptionSea1($id, $name, $this->landName($landKind, $lv), $point);
            } else {
              $this->log->eruptionSea($id, $name, $this->landName($landKind, $lv), $point);
              $land[$sx][$sy] = $init->landSea;
              $landValue[$sx][$sy] = 1;
              continue;
            }
          } elseif(($landKind == $init->landMountain) ||
                  ($landKind == $init->landMonster) ||
                  ($landKind == $init->landWaste)) {
            continue;
          } else {
            // 그 이외의 경우
            $this->log->eruptionNormal($id, $name, $this->landName($landKind, $lv), $point);
          }
          $land[$sx][$sy] = $init->landWaste;
          $landValue[$sx][$sy] = 0;
        }
      }
    }
    // 변경된 가능성이 있는 변수를 써 되돌린다
    $island['land'] = $land;
    $island['landValue'] = $landValue;

    // 식량가 넘치고 있으면(자) 환금
    if($island['food'] > $init->maxFood) {
      $island['money'] += round(($island['food'] - $init->maxFood) / 10);
      $island['food'] = $init->maxFood;
    }

    // 돈이 넘치고 있으면(자) 잘라서 버림
    if($island['money'] > $init->maxMoney) {
      $island['money'] = $init->maxMoney;
    }

    // 미사일수에 응해 네이팜탄 겟트
    if($island['get'] < 10) {
      while($island['total'] - (($island['get'] + 1) * $init->NB) >= 0){
        $island['get'] += 1;
        $island['now'] += 1;
      }
    } else {
      while($island['total'] - (($island['get'] + 1) * $init->NB2) >= 0){
        $island['get'] += 1;
        $island['now'] += 1;
      }
    }

    // 각종의 값을 계산
    Turn::estimate($island);

    // 번영, 재난상
    $pop = $island['pop'];
    $damage = $island['oldPop'] - $pop;
    $prize = $island['prize'];
    list($flags, $monsters, $turns) = split(",", $prize, 3);


    // 번영상
    if((!($flags & 1)) &&  $pop >= 3000){
      $flags |= 1;
      $this->log->prize($id, $name, $init->prizeName[1]);
    } elseif((!($flags & 2)) &&  $pop >= 5000){
      $flags |= 2;
      $this->log->prize($id, $name, $init->prizeName[2]);
    } elseif((!($flags & 4)) &&  $pop >= 10000){
      $flags |= 4;
      $this->log->prize($id, $name, $init->prizeName[3]);
    }

    // 재난상
    if((!($flags & 64)) &&  $damage >= 500){
      $flags |= 64;
      $this->log->prize($id, $name, $init->prizeName[7]);
    } elseif((!($flags & 128)) &&  $damage >= 1000){
      $flags |= 128;
      $this->log->prize($id, $name, $init->prizeName[8]);
    } elseif((!($flags & 256)) &&  $damage >= 2000){
      $flags |= 256;
      $this->log->prize($id, $name, $init->prizeName[9]);
    }

    $island['prize'] = "{$flags},{$monsters},{$turns}";

  }

  //---------------------------------------------------
  // 주위의 마을, 농장이 있을까 판정
  //---------------------------------------------------
  function countGrow($land, $landValue, $x, $y) {
    global $init;

    for($i = 1; $i < 7; $i++) {
      $sx = $x + $init->ax[$i];
      $sy = $y + $init->ay[$i];

      // 행에 의한 위치 조정
      if((($sy % 2) == 0) && (($y % 2) == 1)) {
        $sx--;
      }

      if(($sx < 0) || ($sx >= $init->islandSize) ||
         ($sy < 0) || ($sy >= $init->islandSize)) {
      } else {
        // 범위내의 경우
        if(($land[$sx][$sy] == $init->landTown) ||
           ($land[$sx][$sy] == $init->landFarm)) {
          if($landValue[$sx][$sy] != 1) {
            return true;
          }
        }
      }
    }
    return false;
  }
  //---------------------------------------------------
  // 광역 피해 루틴
  //---------------------------------------------------
  function wideDamage($id, $name, $land, $landValue, $x, $y) {
    global $init;

    for($i = 0; $i < 19; $i++) {
      $sx = $x + $init->ax[$i];
      $sy = $y + $init->ay[$i];

      // 행에 의한 위치 조정
      if((($sy % 2) == 0) && (($y % 2) == 1)) {
        $sx--;
      }

      $landKind = $land[$sx][$sy];
      $lv = $landValue[$sx][$sy];
      $landName = $this->landName($landKind, $lv);
      $point = "({$sx}, {$sy})";

      // 범위외 판정
      if(($sx < 0) || ($sx >= $init->islandSize) ||
         ($sy < 0) || ($sy >= $init->islandSize)) {
        continue;
      }

      // 범위에 의한 분기
      if($i < 7) {
        // 중심, 및 1 헥스
        if($landKind == $init->landSea) {
          $landValue[$sx][$sy] = 0;
          continue;
        } elseif(($landKind == $init->landSbase) ||
                 ($landKind == $init->landOil)) {
          $this->log->wideDamageSea2($id, $name, $landName, $point);
          $land[$sx][$sy] = $init->landSea;
          $landValue[$sx][$sy] = 0;
        } else {
          if($landKind == $init->landMonster) {
            $this->log->wideDamageMonsterSea($id, $name, $landName, $point);
          } else {
            $this->log->wideDamageSea($id, $name, $landName, $point);
          }
          $land[$sx][$sy] = $init->landSea;
          if($i == 0) {
            // 해
            $landValue[$sx][$sy] = 0;
          } else {
            // 얕은 여울
            $landValue[$sx][$sy] = 1;
          }
        }
      } else {
        // 2 헥스
        if(($landKind == $init->landSea) ||
           ($landKind == $init->landOil) ||
           ($landKind == $init->landWaste) ||
           ($landKind == $init->landMountain) ||
           ($landKind == $init->landSbase)) {
          continue;
        } elseif($landKind == $init->landMonster) {
          $this->log->wideDamageMonster($id, $name, $landName, $point);
          $land[$sx][$sy] = $init->landWaste;
          $landValue[$sx][$sy] = 0;
        } else {
          $this->log->wideDamageWaste($id, $name, $landName, $point);
          $land[$sx][$sy] = $init->landWaste;
          $landValue[$sx][$sy] = 0;
        }
      }
    }
  }

  //---------------------------------------------------
  // 인구순서로 소트
  //---------------------------------------------------
  function islandSort($hako) {
    global $init;
    usort($hako->islands, 'popComp');
  }
  //---------------------------------------------------
  //  수입, 소비 페이즈
  //---------------------------------------------------
  function income($island) {
    global $init;
    
    $pop = $island['pop'];
    $farm = $island['farm'] * 10;
    $factory = $island['factory'];
    $mountain =$island['mountain'];

    // 수입
    if($pop > $farm) {
      // 농업만은 손이 남는 경우
      $island['food'] += $farm; // 농장 풀 가동
      $island['money'] +=
        min(round(($pop - $farm) / 10),
              $factory + $mountain);
    } else {
      // 농업만으로 손 한 잔의 경우
      $island['food'] += $pop; // 전원 들일
    }

    // 식량 소비
    $island['food'] = round($island['food'] - $pop * $init->eatenFood);
  }
  //---------------------------------------------------
  // 인구 그 외의 값을 산출
  //---------------------------------------------------
  function estimate($island) {
    // estimate($island)와 같이 사용
    
    global $init;
    $land = $island['land'];
    $landValue = $island['landValue'];

    $area       = 0;
    $pop        = 0;
    $farm       = 0;
    $factory    = 0;
    $mountain   = 0;
    $monster    = 0;
    $fire       = 0;
    // 센다
    for($y = 0; $y < $init->islandSize; $y++) {
      for($x = 0; $x < $init->islandSize; $x++) {
        $kind = $land[$x][$y];
        $value = $landValue[$x][$y];
        if($kind == $init->landSbase) $fire += Util::expToLevel($kind, $value);
        if(($kind != $init->landSea) &&
           ($kind != $init->landSbase) &&
           ($kind != $init->landOil)){
          $area++;
          switch($kind) {
          case $init->landTown:
            // 정
            $pop += $value;
            break;
          case $init->landFarm:
            // 농장
            $farm += $value;
            break;
          case $init->landFactory:
            // 공장
            $factory += $value;
            break;
          case $init->landMountain:
            // 산
            $mountain += $value;
            break;
          case $init->landBase:
            // 미사일
            $fire += Util::expToLevel($kind, $value);
            break;
          case $init->landMonster:
            // 괴수
            $monster++;
            break;
          }
        }
      }
    }
    // 대입
    $island['pop']      = $pop;
    $island['area']     = $area;
    $island['farm']     = $farm;
    $island['factory']  = $factory;
    $island['mountain'] = $mountain;
    $island['monster'] = $monster;
    $island['fire']     = $fire;
    $island['seichi']   = 0;
  }
  //---------------------------------------------------
  // 범위내의 지형을 센다
  //---------------------------------------------------
  function countAround($land, $x, $y, $kind, $range) {
    global $init;
    // 범위내의 지형을 센다
    $count = 0;
    for($i = 0; $i < $range; $i++) {
      $sx = $x + $init->ax[$i];
      $sy = $y + $init->ay[$i];

      // 행에 의한 위치 조정
      if((($sy % 2) == 0) && (($y % 2) == 1)) {
        $sx--;
      }

      if(($sx < 0) || ($sx >= $init->islandSize) ||
         ($sy < 0) || ($sy >= $init->islandSize)) {
        // 범위외의 경우
        if($kind == $init->landSea) {
          // 바다라면 가산
          $count++;
        }
      } else {
        // 범위내의 경우
        if($land[$sx][$sy] == $kind) {
          $count++;
        }
      }
    }
    return $count;
  }
  //---------------------------------------------------
  // 지형의 부르는 법
  //---------------------------------------------------
  function landName($land, $lv) {
    global $init;
    switch($land) {
    case $init->landSea:
      if($lv == 1) {
        return '얕은 여울';
      } else {
        return '바다';
      }
      break;
    case $init->landWaste:
      return '황무지';
    case $init->landPlains:
      return '평지';
    case $init->landTown:
      if($lv < 30) {
        return '마을';
      } elseif($lv < 100) {
        return '마을';
      } else {
        return '도시';
      }
    case $init->landForest:
      return '숲';
    case $init->landFarm:
      return '농장';
    case $init->landFactory:
      return '공장';
    case $init->landBase:
      return '미사일 기지';
    case $init->landDefence:
      return '방위 시설';
    case $init->landMountain:
      return '산';
    case $init->landMonster:
      $monsSpec = Util::monsterSpec($lv);
      return $monsSpec['name'];
    case $init->landSbase:
      return '해저 기지';
    case $init->landOil:
      return '해저 유전';
    case $init->landMonument:
      return $init->monumentName[$lv];
    case $init->landHaribote:
      return '위장 시설';

    }
  }
}
// 인구를 비교
function popComp($x, $y) {
  if($x['pop'] == $y['pop']) return 0;
  return ($x['pop'] > $y['pop']) ? -1 : 1;
}


?>
