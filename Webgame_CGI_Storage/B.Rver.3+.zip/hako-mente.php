<?php
/*******************************************************************

  모형정원 제도 2 for PHP

  
  $Id: hako-mente.php,v 1.2 2003/03/25 11:49:32 Watson Exp $

*******************************************************************/

require 'config.php';
require 'hako-html.php';
define("READ_LINE", 1024);
$init = new Init;
$THIS_FILE = $init->baseDir . "/hako-mente.php";

class HtmlMente extends HTML {

  function enter() {
    global $init;
    print "<h1>모형정원 2 maintenance tool</h1>";
    if(file_exists("{$init->passwordFile}")) {
    print <<<END
<form action="{$GLOBALS['THIS_FILE']}" method="post">
<strong>패스워드</strong>
<input type="password" size="32" maxlength="32" name="PASSWORD">
<input type="hidden" name="mode" value="enter">
<input type="submit" value="설정">

END;
    } else {
                print <<<END
<form action="{$GLOBALS['THIS_FILE']}" method="post">
<H2>master password와 특수 패스워드를 매듭지어 주세요.</H2>
<P>※입력 미스를 막기 위해서(때문에), 각각 2회씩 입력해 주세요.</P>
<B>master password</B><BR>
(1) <INPUT type="password" name="MPASS1" value="$mpass1">&nbsp;&nbsp;(2) <INPUT type="password" name="MPASS2" value="$mpass2"><BR>
<BR>
<B>특수 패스워드</B><BR>
(1) <INPUT type="password" name="SPASS1" value="$spass1">&nbsp;&nbsp;(2) <INPUT type="password" name="SPASS2" value="$spass2"><BR>
<BR>
<input type="hidden" name="mode" value="setup">
<INPUT type="submit" value="패스워드를 설정한다">
END;
    }
    print "</form>\n";
  }
  function main($data) {
    global $init;
    print "<h1>모형정원  maintenance tool</h1>\n";
    
    if(is_dir("{$init->dirName}")) {
      $this->dataPrint($data);
    } else {
      print "<hr>\n";
      print "<form action=\"{$GLOBALS['THIS_FILE']}\" method=\"post\">\n";
      print "<input type=\"hidden\" name=\"PASSWORD\" value=\"{$data['PASSWORD']}\">\n";
      print "<input type=\"hidden\" name=\"mode\" value=\"NEW\">\n";
      print "<input type=\"submit\" value=\"새로운 데이터를 만드는\">\n";
      print "</form>\n";
    }

    // 백업 데이터
    $dir = opendir("./");
    while($dn = readdir($dir)) {
      if(preg_match("/{$init->dirName}\.bak(.*)$/", $dn, $suf)) {
        if (is_file("{$init->dirName}.bak{$suf[1]}/hakojima.dat")) {
          $this->dataPrint($data, $suf[1]);
        }
      }
    }
    closedir($dir);


  }
  // 표시 모드
  function dataPrint($data, $suf = "") {
    global $init;

    print "<HR>";
    if(strcmp($suf, "") == 0) {
      $fp = fopen("{$init->dirName}/hakojima.dat", "r");
      print "<h1>현역 데이터</h1>\n";
    } else {
      $fp = fopen("{$init->dirName}.bak{$suf}/hakojima.dat", "r");
      print "<h1>백업{$suf}</h1>\n";
    }

    $lastTurn = chop(fgets($fp, READ_LINE));
    $lastTime = chop(fgets($fp, READ_LINE));
    fclose($fp);
    $timeString = timeToString($lastTime);

    print <<<END
<strong>턴$lastTurn</strong><br>
<strong>최종 갱신 시간</strong>:$timeString<br>
<strong>최종 갱신 시간(초수의 표\시</strong>:1970년 1월 1일부터$lastTime 초<br>
<form action="{$GLOBALS['THIS_FILE']}" method="post">
<input type="hidden" name="PASSWORD" value="{$data['PASSWORD']}">
<input type="hidden" name="mode" value="DELETE">
<input type="hidden" name="NUMBER" value="{$suf}">
<input type="submit" value="이 데이터를 삭제">
</form>

END;

    if(strcmp($suf, "") == 0) {
      $time = localtime($lastTime, TRUE);
      $time['tm_year'] += 1900;
      $time['tm_mon']++;

      print <<<END
<h2>최종 갱신 시간의 변경</h2>
<form action="{$GLOBALS['THIS_FILE']}" method="post">
<input type="hidden" name="PASSWORD" value="{$data['PASSWORD']}">
<input type="hidden" name="mode" value="NTIME">
<input type="hidden" name="NUMBER" value="{$suf}">
<input type="text" size="4" name="YEAR" value="{$time['tm_year']}">년
<input type="text" size="2" name="MON" value="{$time['tm_mon']}">월
<input type="text" size="2" name="DATE" value="{$time['tm_mday']}">일
<input type="text" size="2" name="HOUR" value="{$time['tm_hour']}">시
<input type="text" size="2" name="MIN" value="{$time['tm_min']}">분
<input type="text" size="2" name="NSEC" value="{$time['tm_sec']}">초
<input type="submit" value="변경">
</form>
<form action="{$GLOBALS['THIS_FILE']}" method="post">
<input type="hidden" name="PASSWORD" value="{$data['PASSWORD']}">
<input type="hidden" name="mode" value="STIME">
<input type="hidden" name="NUMBER" value="{$suf}">
1970년 1월 1일부터<input type="text" size="32" name="SSEC" value="$lastTime">초
<input type="submit" value="초지정으로 변경">
</form>

END;
    }
  }
}

function timeToString($t) {
  $time = localtime($t, TRUE);
  $time['tm_year'] += 1900;
  $time['tm_mon']++;

  return "{$time['tm_year']}년 {$time['tm_mon']}월 {$time['tm_mday']}일 {$time['tm_hour']}시 {$time['tm_min']}분{$time['tm_sec']}초";
}

class Main {
  var $mode;
  var $dataSet = array();
  function execute() {
    $html = new HtmlMente;

    $this->parseInputData();

    $html->header();
    switch($this->mode) {
    case "NEW":
      if($this->passCheck())
        $this->newMode();

      $html->main($this->dataSet);
      break;

    case "DELETE":
      if($this->passCheck())
        $this->delMode($this->dataSet['NUMBER']);

      $html->main($this->dataSet);
      break;
    case "NTIME":
      if($this->passCheck())
        $this->timeMode();

      $html->main($this->dataSet);
      break;

    case "STIME":
      if($this->passCheck())
        $this->stimeMode($this->dataSet['SSEC']);

      $html->main($this->dataSet);
      break;

    case "setup":
      $this->setupMode();

      $html->enter();
      break;

    case "enter":
      if($this->passCheck())
        $html->main($this->dataSet);

      break;
    default:
      $html->enter();
      break;
    }
    $html->footer();
  }
  //----------------------------------------
  function parseInputData() {
    $this->mode = $_POST['mode'];    
    if(!empty($_POST)) {
      while(list($name, $value) = each($_POST)) {
//        $value = Util::sjis_convert($value);
        // 반각 가나가 있으면 전각으로 변환해 돌려준다
//        $value = i18n_ja_jp_hantozen($value,"KHV");
        $value = str_replace(",", "", $value);

        $this->dataSet["{$name}"] = $value;
      }
    }
  }
  function newMode() {
    global $init;
    mkdir($init->dirName, $init->dirMode);

    // 현재의 시간을 취득
    $now = time();
    $now = $now - ($now % ($init->unitTime));

    $fileName = "{$init->dirName}/hakojima.dat";
    $fp = fopen($fileName, "w");
    fputs($fp, "1\n");
    fputs($fp, "{$now}\n");
    fputs($fp, "0\n");
    fputs($fp, "1\n");
    fclose($fp);

  }
  function delMode($id) {
    global $init;
    if(strcmp($id, "") == 0) {
      $dirName = "{$init->dirName}";
    } else {
      $dirName = "{$init->dirName}.bak{$id}";
    }
    $this->rmTree($dirName);
  }
  function timeMode() {
    $year = $this->dataSet['YEAR'];
    $day  = $this->dataSet['DATE'];
    $mon  = $this->dataSet['MON'];
    $hour = $this->dataSet['HOUR'];
    $min  = $this->dataSet['MIN'];
    $sec  = $this->dataSet['NSEC'];
    $ctSec = mktime($hour, $min, $sec, $mon, $day, $year);
    $this->stimeMode($ctSec);
  }
  function stimeMode($sec) {
    global $init;
    
    $fileName = "{$init->dirName}/hakojima.dat";
    $fp = fopen($fileName, "r+");
    $buffer = array();
    while($line = fgets($fp, READ_LINE)) {
      array_push($buffer, $line);
    }
    $buffer[1] = "{$sec}\n";
    fseek($fp, 0);
    while($line = array_shift($buffer)) {
      fputs($fp, $line);
    }
    fclose($fp);
    
  }
  //----------------------------------------
  function rmTree($dirName) {
    if(is_dir("{$dirName}")) {
      $dir = opendir("{$dirName}/");
      while($fileName = readdir($dir)) {
        if(!(strcmp($fileName, ".") == 0 || strcmp($fileName, "..") == 0))
          unlink("{$dirName}/{$fileName}");
      }
      closedir($dir);
      rmdir($dirName);
    }
  }
  function setupMode() {
    global $init;
    if(empty($this->dataSet['MPASS1']) || empty($this->dataSet['MPASS2']) || strcmp($this->dataSet['MPASS1'], $this->dataSet['MPASS2'])) {
                print "<h2>master password가 입력되어 있지 않은가 잘못되어 있는</h2>\n";
                return 0;
    } else if(empty($this->dataSet['SPASS1']) || empty($this->dataSet['SPASS2']) || strcmp($this->dataSet['SPASS1'], $this->dataSet['SPASS2'])) {
                print "<h2>특수 패스워드가 입력되어 있지 않은가 잘못되어 있는</h2>\n";
                return 0;
    }
    $masterPassword  = crypt($this->dataSet['MPASS1'], 'ma');
    $specialPassword = crypt($this->dataSet['SPASS1'], 'sp');
    $fp = fopen("{$init->passwordFile}", "w");
    fputs($fp, "$masterPassword\n");
    fputs($fp, "$specialPassword\n");
    fclose($fp);
  }
  function passCheck() {
    global $init;
    if(file_exists("{$init->passwordFile}")) {
      $fp = fopen("{$init->passwordFile}", "r");
      $masterPassword = chop(fgets($fp, READ_LINE));
      fclose($fp);
    }
    if(strcmp(crypt($this->dataSet['PASSWORD'], 'ma'), $masterPassword) == 0) {
      return 1;
    } else {
      print "<h2>패스워드가 다릅니다.</h2>\n";
      return 0;
    }
  }
}

$start = new Main();
$start->execute();

?>
