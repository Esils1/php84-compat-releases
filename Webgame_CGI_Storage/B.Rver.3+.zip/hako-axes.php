<?php

require 'config.php';
require 'hako-html.php';
define("READ_LINE", 1024);
$init = new Init;
$THIS_FILE = $init->baseDir . "/hako-axes.php";

class HtmlMente extends HTML {

  function enter() {
    global $init;
    print <<<END
<h1>하코지마 액세스 로그 열람실</h1>
<form action="{$GLOBALS['THIS_FILE']}" method="post">
<strong>패스워드</strong>
<input type="password" size="32" maxlength="32" name="PASSWORD">
<input type="hidden" name="mode" value="enter">
<input type="submit" value="입실한다">
</form>

END;
  
  }

  function main($data) {
    global $init;
    print "<h1>하코지마 액세스 로그 열람실</h1>\n";
    $this->dataPrint($data);
  }

  // 표시 모드
  function dataPrint($data, $suf = "") {
    global $init;

    print "<HR>";

print <<<END
<br>
<h2>액세스 로그</h2>
<table><tr class="NumberCell">
<td>로그인한 시간</td><td>섬ID</td><td>섬의 이름</td><td>IP정보</td><td>호스트 정보</td></tr>
END;
$ip_log = file("$init->logname");
$ax = $init->axesmax - 1;
for($i=0; $i<$ax; $i++){
  $number = $ip_log[$i];
  $num = preg_replace( "/,/", "</TD><TD>", $number );
  print "<TR>\n";
  print "<TD>{$num}</TD>\n";
  print "</TR>\n";
}
print "</table>";
}
}

class Main {
  var $mode;
  var $dataSet = array();
  function execute() {
    $html = new HtmlMente;

    $this->parseInputData();

    $html->header();
    switch($this->mode) {

    case "enter":
      if($this->passCheck())
        $html->main($this->dataSet);

      break;
    default:
      $html->enter();
      break;
    }
    $html->footer();
  }
  //----------------------------------------
  function parseInputData() {
    $this->mode = $_POST['mode'];    
    if(!empty($_POST)) {
      while(list($name, $value) = each($_POST)) {
//        $value = Util::sjis_convert($value);
        // 반각 가나가 있으면 전각으로 변환해 돌려준다
//        $value = i18n_ja_jp_hantozen($value,"KHV");
        $value = str_replace(",", "", $value);

        $this->dataSet["{$name}"] = $value;
      }
    }
  }

  //----------------------------------------
  function passCheck() {
    global $init;
    if(file_exists("{$init->passwordFile}")) {
      $fp = fopen("{$init->passwordFile}", "r");
      $masterPassword = chop(fgets($fp, READ_LINE));
      fclose($fp);
    }
    if(strcmp(crypt($this->dataSet['PASSWORD'], 'ma'), $masterPassword) == 0) {
      return 1;
    } else {
      print "<h2>패스워드가 다릅니다.</h2>\n";
      return 0;
    }
  }
}

$start = new Main();
$start->execute();

?>
