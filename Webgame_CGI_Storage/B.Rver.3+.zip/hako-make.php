<?php
/*******************************************************************

 모형정원 제도 B.R

*******************************************************************/

require_once 'hako-log.php';

class Make {
  //---------------------------------------------------
  // 섬의 신규 작성 모드
  //---------------------------------------------------
  function newIsland($hako, $data) {
    global $init;
    $log = new Log;
    if($hako->islandNumber >= $init->maxIsland) {
      Error::newIslandFull();
      return;
    }

    // 접수 턴인가 어떤가
    if(($hako->islandTurn >= $init->entryTurn) && ($init->entryTurn > 0)) {
        Error::tempNewIslandForbbiden();
        return;
    }

    if(empty($data['ISLANDNAME'])) {
      Error::newIslandNoName();
      return;
    }
    // 이름이 정당화 체크
    if(ereg("[,?()<>$]", $data['ISLANDNAME']) || strcmp($data['ISLANDNAME'], "무인") == 0) {
      Error::newIslandBadName();
      return;
    }
    // 이름의 중복 체크
    if(Util::nameToNumber($hako, $data['ISLANDNAME']) != -1) {
      Error::newIslandAlready();
      return;
    }
    // 패스워드의 존재 판정
    if(empty($data['PASSWORD'])) {
      Error::newIslandNoPassword();
      return;
    }
    if(strcmp($data['PASSWORD'], $data['PASSWORD2']) != 0) {
      Error::wrongPassword();
      return;
    }
    // 새로운 섬의 번호를 결정한다
    $newNumber = $hako->islandNumber;
    $hako->islandNumber++;
    $island = $this->makeNewIsland();

    // 각종의 값을 설정
    $island['name']  = htmlspecialchars($data['ISLANDNAME']);
    $island['owner'] = htmlspecialchars($data['OWNERNAME']);
    $island['id']    = $hako->islandNextID;
    $hako->islandNextID++;
    $island['absent'] = $init->giveupTurn - 3;
    $island['comment'] = '(미등록)';
    $island['comment_turn'] = $hako->islandTurn;
    $island['password'] = Util::encode($data['PASSWORD']);
    $island['mout'] = 0;
    $island['total'] = 0;
    $island['min'] = 0;
    $island['now'] = 0;
    $island['get'] = 0;

    Turn::estimate($island);
    $hako->islands[$newNumber] = $island;
    $hako->writeIslandsFile($island['id']);

    $log->discover($island['name']);

    $htmlMap = new HtmlMap;
    $htmlMap->newIslandHead($island['name']);
    $htmlMap->islandInfo($island, $newNumber);
    $htmlMap->islandMap($hako, $island, 1, $data);
    
  }
  //---------------------------------------------------
  // 새로운 섬을 작성한다
  //---------------------------------------------------
  function makeNewIsland() {
    global $init;
    $command = array();
    // 초기 커멘드 생성
    for($i = 0; $i < $init->commandMax; $i++) {
      $command[$i] = array (
        'kind'   => $init->comDoNothing,
        'target' => 0,
        'x'      => 0,
        'y'      => 0,
        'arg'    => 0,
        );
    }
    $lbbs = "";
    // 초기 게시판 생성
    for($i = 0; $i < $init->lbbsMax; $i++) {
      $lbbs[$i] = "0>>0>>";
    }

    $land = array();
    $landValue = array();

    if ($init->initialLand) {
      // 초기섬데이터 파일 사용 모드

      // 기본형을 작성
      $fp_i = fopen($init->initialLand, "r");
      Util::lockr($fp_i);
      $offset = 4; // 한 벌의 데이터가 무엇 문자인가
      for($y = 0; $y < $init->islandSize; $y++) {
        $line = chop(fgets($fp_i, READ_LINE));
        for($x = 0; $x < $init->islandSize; $x++) {
          $l = substr($line, $x * $offset    , 2);
          $v = substr($line, $x * $offset + 2, 2);
          $land[$x][$y]      = hexdec($l);
          $landValue[$x][$y] = hexdec($v);
        }
      }
      Util::unlock($fp_i);
      fclose($fp_i);

    } else if ($init->initialSize) {
      // 초기 면적 통일 모드

      // 기본형을 작성
      for($y = 0; $y < $init->islandSize; $y++) {
        for($x = 0; $x < $init->islandSize; $x++) {
          $land[$x][$y]      = $init->landSea;
          $landValue[$x][$y] = 0;
        }
      }
      
      // 4*4에 황무지를 배치
      $center = $init->islandSize / 2 - 1;
      for($y = $center -1; $y < $center + 3; $y++) {
        for($x = $center - 1; $x < $center + 3; $x++) {
          $land[$x][$y] = $init->landWaste;
        }
      }

      // 섬발견시의 면적 고정
      $size = 16;

      // 8*8범위내에 육지를 증식
      while($size < $init->initialSize) {
        $x = Util::random(8) + $center - 3;
        $y = Util::random(8) + $center - 3;
        if(Turn::countAround($land, $x, $y, $init->landSea, 7) != 7) {
          // 주위에 육지가 있는 경우, 얕은 여울로 한다
          // 얕은 여울은 황무지로 한다
          // 황무지는 평지로 한다
          if($land[$x][$y] == $init->landSea) {
            if($landValue[$x][$y] == 1) {
              $land[$x][$y] = $init->landPlains;
              $landValue[$x][$y] = 0;
              $size++;
            } else {
              if($land[$x][$y] == $init->landWaste) {
                $land[$x][$y] = $init->landPlains;
                $landValue[$x][$y] = 0;
              } else {
                if($landValue[$x][$y] == 1) {
                  $land[$x][$y] = $init->landWaste;
                  $landValue[$x][$y] = 0;
                } else {
                  $landValue[$x][$y] = 1;
                }
              }
            }
          }
        }
      }

      // 숲을 만든다
      $count = 0;
      while($count < 4) {
        // 랜덤 좌표
        $x = Util::random(4) + $center - 1;
        $y = Util::random(4) + $center - 1;

        // 거기가 벌써 숲이 아니면, 숲을 만든다
        if($land[$x][$y] != $init->landForest) {
          $land[$x][$y] = $init->landForest;
          $landValue[$x][$y] = 5; // 처음은 500개
          $count++;
        }
      }
      $count = 0;
      while($count < 2) {
        // 랜덤 좌표
        $x = Util::random(4) + $center - 1;
        $y = Util::random(4) + $center - 1;

        // 거기가 숲이나 마을이 아니면, 마을을 만든다
        if(($land[$x][$y] != $init->landTown) &&
           ($land[$x][$y] != $init->landForest)) {
          $land[$x][$y] = $init->landTown;
          $landValue[$x][$y] = 5; // 처음은 500명
          $count++;
        }
      }

      // 산을 만든다
      $count = 0;
      while($count < 1) {
        // 랜덤 좌표
        $x = Util::random(4) + $center - 1;
        $y = Util::random(4) + $center - 1;

        // 거기가 숲이나 마을이 아니면, 마을을 만든다
        if(($land[$x][$y] != $init->landTown) &&
           ($land[$x][$y] != $init->landForest)) {
          $land[$x][$y] = $init->landMountain;
          $landValue[$x][$y] = 0; // 처음은 채굴장 없음
          $count++;
        }
      }

      // 기지를 만든다
      $count = 0;
      while($count < 1) {
        // 랜덤 좌표
        $x = Util::random(4) + $center - 1;
        $y = Util::random(4) + $center - 1;

        // 거기가 숲이나 마을이나 산이 아니면, 기지
        if(($land[$x][$y] != $init->landTown) &&
           ($land[$x][$y] != $init->landForest) &&
           ($land[$x][$y] != $init->landMountain)) {
          $land[$x][$y] = $init->landBase;
          $landValue[$x][$y] = 0;
          $count++;
        }
      }

    } else {
      // 통상 모드

      // 기본형을 작성
      for($y = 0; $y < $init->islandSize; $y++) {
        for($x = 0; $x < $init->islandSize; $x++) {
          $land[$x][$y]      = $init->landSea;
          $landValue[$x][$y] = 0;
        }
      }
      
      // 4*4에 황무지를 배치
      $center = $init->islandSize / 2 - 1;
      for($y = $center -1; $y < $center + 3; $y++) {
        for($x = $center - 1; $x < $center + 3; $x++) {
          $land[$x][$y] = $init->landWaste;
        }
      }
      // 8*8범위내에 육지를 증식
      for($i = 0; $i < 120; $i++) {
        $x = Util::random(8) + $center - 3;
        $y = Util::random(8) + $center - 3;
        if(Turn::countAround($land, $x, $y, $init->landSea, 7) != 7) {
          // 주위에 육지가 있는 경우, 얕은 여울로 한다
          // 얕은 여울은 황무지로 한다
          // 황무지는 평지로 한다
          if($land[$x][$y] == $init->landWaste) {
            $land[$x][$y] = $init->landPlains;
            $landValue[$x][$y] = 0;
          } else {
            if($landValue[$x][$y] == 1) {
              $land[$x][$y] = $init->landWaste;
              $landValue[$x][$y] = 0;
            } else {
              $landValue[$x][$y] = 1;
            }
          }
        }
      }
      // 숲을 만든다
      $count = 0;
      while($count < 4) {
        // 랜덤 좌표
        $x = Util::random(4) + $center - 1;
        $y = Util::random(4) + $center - 1;

        // 거기가 벌써 숲이 아니면, 숲을 만든다
        if($land[$x][$y] != $init->landForest) {
          $land[$x][$y] = $init->landForest;
          $landValue[$x][$y] = 5; // 처음은 500개
          $count++;
        }
      }
      $count = 0;
      while($count < 2) {
        // 랜덤 좌표
        $x = Util::random(4) + $center - 1;
        $y = Util::random(4) + $center - 1;

        // 거기가 숲이나 마을이 아니면, 마을을 만든다
        if(($land[$x][$y] != $init->landTown) &&
           ($land[$x][$y] != $init->landForest)) {
          $land[$x][$y] = $init->landTown;
          $landValue[$x][$y] = 5; // 처음은 500명
          $count++;
        }
      }

      //  산을 만든다
      $count = 0;
      while($count < 1) {
        // 랜덤 좌표
        $x = Util::random(4) + $center - 1;
        $y = Util::random(4) + $center - 1;

        // 거기가 숲이나 마을이 아니면, 마을을 만든다
        if(($land[$x][$y] != $init->landTown) &&
           ($land[$x][$y] != $init->landForest)) {
          $land[$x][$y] = $init->landMountain;
          $landValue[$x][$y] = 0; // 처음은 채굴장 없음
          $count++;
        }
      }

      // 기지를 만든다
      $count = 0;
      while($count < 1) {
        // 랜덤 좌표
        $x = Util::random(4) + $center - 1;
        $y = Util::random(4) + $center - 1;

        // 거기가 숲이나 마을이나 산이 아니면, 기지
        if(($land[$x][$y] != $init->landTown) &&
           ($land[$x][$y] != $init->landForest) &&
           ($land[$x][$y] != $init->landMountain)) {
          $land[$x][$y] = $init->landBase;
          $landValue[$x][$y] = 0;
          $count++;
        }
      }
    }

    return array (
      'money'	  => $init->initialMoney,
      'food'	  => $init->initialFood,
      'land'	  => $land,
      'landValue' => $landValue,
      'command'	  => $command,
      'lbbs'	  => $lbbs,
      'prize'	  => '0,0,',
      );    
  }
  //---------------------------------------------------
  // 코멘트 갱신
  //---------------------------------------------------
  function commentMain($hako, $data) {
    $id  = $data['ISLANDID'];
    $num = $hako->idToNumber[$id];
    $island = $hako->islands[$num];
    $name = $island['name'];

    // 패스워드
    if(!Util::checkPassword($island['password'], $data['PASSWORD'])) {
      //  password 실수
      Error::wrongPassword();
      return;
    }
    // 메세지를 갱신
    $island['comment'] = htmlspecialchars($data['MESSAGE']);
    $island['comment_turn'] = $hako->islandTurn;
    $hako->islands[$num] = $island;

    // 데이터의 서두
    $hako->writeIslandsFile();

    // 코멘트 갱신 메세지
    HtmlSetted::Comment();

    
    // owner mode에
    if($data['DEVELOPEMODE'] == "cgi") {
      $html = new HtmlMap;
    } else {
      $html = new HtmlJS;
    }
    $html->owner($hako, $data);
  }
  //---------------------------------------------------
  // 로컬 게시판 모드
  //---------------------------------------------------
  function localBbsMain($hako, $data) {
    global $init;

    $id  = $data['ISLANDID'];
    $num = $hako->idToNumber[$id];
    $island = $hako->islands[$num];
    $name = $island['name'];
    $speaker = "0>";

    // 왠지 그 섬이 없는 경우
    if($num != 0 && empty($num)) {
      Error::problem();
      return;
    }

    // 삭제 모드가 아니고 이름이나 메세지가 없는 경우
    if(empty($data['DEL']) && empty($data['CHK'])) {
      if(empty($data['LBBSNAME']) || (empty($data['LBBSMESSAGE']))) {
        Error::lbbsNoMessage();
        return;
      }
    }

    // 관광자 모드가 아닐 때는 패스워드 체크
    if($data['lbbsMode'] == 1) {
      if(!Util::checkPassword($island['password'], $data['PASSWORD'])) {
        // password 실수
        Error::wrongPassword();
        return;
      }
      // 오너명을 설정
      $HlbbsName = $island['owner'];
    } else if (empty($data['DEL']) && empty($data['CHK'])) {
      // 관광자 모드
      if ($data['LBBSTYPE'] != 'ANON') {
        // 공개와 극비

        // id로부터 섬번호를 취득
        $sNum = $hako->idToNumber[$data['ISLANDID2']];
        $sIsland = $hako->islands[$sNum];

        // 왠지 그 섬이 없는 경우
        if($sNum != 0 && empty($sNum)) {
          Error::problem();
          return;
        }

        // 패스워드 체크
        if(!Util::checkPassword($sIsland['password'], $data['PASSWORD'])) {
          // password 실수
          Error::wrongPassword();
          return;
        }

        // 오너명을 설정
        $HlbbsName = $sIsland['owner'];

        // 통신 비용을 지불한다
        if($data['LBBSTYPE'] == 'PUBLIC') {
          $cost = $init->lbbsMoneyPublic;
        } else {
          $cost = $init->lbbsMoneySecret;
        }
        if($sIsland['money'] < $cost) {
          // 비용 부족
          Error::lbbsNoMoney();
          return;
        }
        $sIsland['money'] -= $cost;
        $hako->islands[$sNum] = $sIsland;
      }

      // 발언자를 기억한다
      if($data['LBBSTYPE'] != 'ANON') {
        // 공개와 극비
        $speaker = $sIsland['name'] . '섬,' . $data['ISLANDID2'];
      } else {
        // 익명
        $speaker = getenv('REMOTE_HOST');
        if($speaker == '') {
          $speaker = getenv('REMOTE_ADDR');
        }
      }
      if($data['LBBSTYPE'] != 'SECRET') {
        // 공개와 익명
        $speaker = "0>$speaker";
      } else {
        // 극비
        $speaker = "1>$speaker";
      }
    } else {
      // 관광자 삭제 모드·극비 확인 모드
      // id로부터 섬번호를 취득
      $sNum = $hako->idToNumber[$data['ISLANDID2']];
      $sIsland = $hako->islands[$sNum];

      // 왠지 그 섬이 없는 경우
      if($sNum != 0 && empty($sNum)) {
        Error::problem();
        return;
      }

      // 패스워드 체크
      if(!Util::checkPassword($sIsland['password'], $data['PASSWORD'])) {
        // password 실수
        Error::wrongPassword();
        return;
      }
    }

    $lbbs = $island['lbbs'];

    // 모드로 분기
    if(!empty($data['CHK'])) {
      if($data['DEVELOPEMODE'] == "cgi") {
        $html = new HtmlMap;
      } else {
        $html = new HtmlJS;
      }
      $html->visitor($hako, $data, $data['ISLANDID2']);
      return;
    } else if(!empty($data['DEL'])) {
      if($data['lbbsMode'] == 0) {
        list($secret, $sTemp, $mode, $turn, $message) = split(">", $lbbs[$data['NUMBER']]);
        list($sName, $sId) = split(",", $sTemp);
        if($sId != $data['ISLANDID2']) {
          // ID실수
          Error::wrongID();
          return;
        }
      }
      // 삭제 모드
      // 메세지를 앞에 두고 비켜 놓는다
      Util::slideBackLbbsMessage($lbbs, $data['NUMBER']);
      HtmlSetted::lbbsDelete();
    } else {
      // 기장 모드
      Util::slideLbbsMessage($lbbs);

      // 메세지 기입
      if($data['lbbsMode'] == 0) {
        $message = '0';
      } else {
        $message = '1';
      }
      $bbs_name = "{$hako->islandTurn}:" . htmlspecialchars($data['LBBSNAME']);
      $bbs_message = htmlspecialchars($data['LBBSMESSAGE']);
      $lbbs[0] = "{$speaker}>{$message}>{$bbs_name}>{$bbs_message}";

      HtmlSetted::lbbsAdd();
    }
    $island['lbbs'] = $lbbs;
    $hako->islands[$num] = $island;

    // 데이터 서두
    $hako->writeIslandsFile($id);

    if($data['DEVELOPEMODE'] == "cgi") {
      $html = new HtmlMap;
    } else {
      $html = new HtmlJS;
    }
    // 원래의 모드에
    if($data['lbbsMode'] == 0) {
      $html->visitor($hako, $data);
    } else {
      $html->owner($hako, $data);
    }
  }
  //---------------------------------------------------
  // 정보 변경 모드
  //---------------------------------------------------
  function changeMain($hako, $data) {
    global $init;
    $log = new Log;
    
    $id  = $data['ISLANDID'];
    $num = $hako->idToNumber[$id];
    $island = $hako->islands[$num];
    $name = $island['name'];

    // 패스워드 체크
    if(Util::checkSpecialPassword($data['OLDPASS'])) {
      // 특수 패스워드
      if(preg_match("/^무인$/", $data['ISLANDNAME'])) {
        // 섬의 강제 삭제
        $this->deleteIsland($hako, $data);

        HtmlSetted::deleteIsland($name);
        return;
      } else {
        $island['money'] = $init->maxMoney;
        $island['food']  = $init->maxFood;
      }
    } elseif(!Util::checkPassword($island['password'], $data['OLDPASS'])) {
      // password 실수
      Error::wrongPassword();
      return;
    }

    // 확인용 패스워드
    if(strcmp($data['PASSWORD'], $data['PASSWORD2']) != 0) {
      //  password 실수
      Error::wrongPassword();
      return;
    }

    if(!empty($data['ISLANDNAME'])) {
      // 이름 변경의 경우
      // 이름이 정당한가 체크
      if(ereg("[,?()<>$]", $data['ISLANDNAME']) || strcmp($data['ISLANDNAME'], "무인") == 0) {
        Error::newIslandBadName();
        return;
      }

      // 이름의 중복 체크
      if(Util::nameToNumber($hako, $data['ISLANDNAME']) != -1) {
        Error::newIslandAlready();
        return;
      }

      if($island['money'] < $init->costChangeName) {
        // 돈이 부족하다
        Error::changeNoMoney();
        return;
      }

      // 대금
      if(!Util::checkSpecialPassword($data['OLDPASS'])) {
        $island['money'] -= $init->costChangeName;
      }

      // 이름을 변경
      $log->changeName($island['name'], $data['ISLANDNAME']);
      $island['name'] = $data['ISLANDNAME'];
      $flag = 1;
    }

    // password 변경의 경우
    if(!empty($data['PASSWORD'])) {
      // 패스워드를 변경
      $island['password'] = Util::encode($data['PASSWORD']);
      $flag = 1;
    }

    if(($flag == 0) && (strcmp($data['PASSWORD'], $data['PASSWORD2']) != 0)) {
      // 어느쪽이나 변경되어 있지 않다
      Error::changeNothing();
      return;
    }

    $hako->islands[$num] = $island;
    // 데이터 서두
    $hako->writeIslandsFile($id);

    // 변경 성공
    HtmlSetted::change();
  }
  //---------------------------------------------------
  // 오너명 변경 모드
  //---------------------------------------------------
  function changeOwnerName($hako, $data) {
    global $init;

    $id  = $data['ISLANDID'];
    $num = $hako->idToNumber[$id];
    $island = $hako->islands[$num];

    // 패스워드 체크
    if(Util::checkSpecialPassword($data['OLDPASS'])) {
      //  특수 패스워드
      $island['money'] = $init->maxMoney;
      $island['food']  = $init->maxFood;
    } elseif(!Util::checkPassword($island['password'], $data['OLDPASS'])) {
      //  password 실수
      Error::wrongPassword();
      return;
    }
    $island['owner'] = htmlspecialchars($data['OWNERNAME']);
    $hako->islands[$num] = $island;
    //  데이터 서두
    $hako->writeIslandsFile($id);

    // 변경 성공
    HtmlSetted::change();
  }
  //---------------------------------------------------
  // 커멘드 모드
  //---------------------------------------------------
  function commandMain($hako, $data) {
    global $init;
    $id  = $data['ISLANDID'];
    $num = $hako->idToNumber[$id];
    $island = $hako->islands[$num];
    $name = $island['name'];

    // 패스워드
    if(!Util::checkPassword($island['password'], $data['PASSWORD'])) {
      // password 실수
      Error::wrongPassword();
      return;
    }

    // 모드로 분기
    $command = $island['command'];

    if(strcmp($data['COMMANDMODE'], 'delete') == 0) {
      Util::slideFront($command, $data['NUMBER']);
      HtmlSetted::commandDelete();
    } elseif(($data['COMMAND'] == $init->comAutoPrepare) ||
             ($data['COMMAND'] == $init->comAutoPrepare2)) {
      // 풀정지, 풀 땅 고르는 일
      // 좌표 배열을 만든다
      $r = Util::makeRandomPointArray();
      $rpx = $r[0];
      $rpy = $r[1];
      $land = $island['land'];
      // 커멘드의 종류 결정
      $kind = $init->comPrepare;
      if($data['COMMAND'] == $init->comAutoPrepare2) {
        $kind = $init->comPrepare2;
      }

      $i = $data['NUMBER'];
      $j = 0;
      while(($j < $init->pointNumber) && ($i < $init->commandMax)) {
        $x = $rpx[$j];
        $y = $rpy[$j];
        if($land[$x][$y] == $init->landWaste) {
          Util::slideBack($command, $data['NUMBER']);
          $command[$data['NUMBER']] = array (
            'kind'	=> $kind,
            'target'	=> 0,
            'x'		=> $x,
            'y'		=> $y,
            'arg'	=> 0,
            );
          $i++;
        }
        $j++;
      }
      HtmlSetted::commandAdd();
    } elseif($data['COMMAND'] == $init->comAutoDelete) {
      // 전 지워
      for($i = 0; $i < $init->commandMax; $i++) {
        Util::slideFront($command, 0);
      }
      HtmlSetted::commandDelete();
    } else {
      if(strcmp($data['COMMANDMODE'], 'insert') == 0) {
        Util::slideBack($command, $data['NUMBER']);
      }
      HtmlSetted::commandAdd();
      // 커멘드를 등록
      $command[$data['NUMBER']] = array (
        'kind'   => $data['COMMAND'],
        'target' => $data['TARGETID'],
        'x'      => $data['POINTX'],
        'y'      => $data['POINTY'],
        'arg'    => $data['AMOUNT'],
        );
    }

    // 데이터의 서두
    $island['command'] = $command;
    $hako->islands[$num] = $island;
    $hako->writeIslandsFile($island['id']);

    // owner mode에
    $html = new HtmlMap;
    $html->owner($hako, $data);
  }
  //---------------------------------------------------
  // 섬의 강제 삭제
  //---------------------------------------------------
  function deleteIsland($hako, $data) {
    global $init;
    $log = new Log;

    $id  = $data['ISLANDID'];
    $num = $hako->idToNumber[$id];
    $island = $hako->islands[$num];

    // 섬테이블의 조작
    $island['pop']   = 0;
    $island['dead']  = 1;

    $tmpid = $island['id'];
    $log->deleteIsland($tmpid, $island['name']);
    if(is_file("{$init->dirName}/island.{$tmpid}")) {
      unlink("{$init->dirName}/island.{$tmpid}");
    }

    // 메인 데이터의 조작
    $hako->islands[$num] = $island;
    Turn::islandSort($hako); // 삭제하는 섬을 최하정도에 이동

    $hako->islandNumber -= 1; // 최하정도 삭제

    // 데이터 서두
    $hako->writeIslandsFile($id);
  }
}

?>
