<?php
/*******************************************************************

  모형정원 제도 2 for PHP

  
  $Id: hako-main.php,v 1.16 2004/02/14 15:51:45 watson Exp $

*******************************************************************/

require_once 'jcode.phps';
require_once 'config.php';
require_once 'hako-file.php';
require_once 'hako-html.php';
require_once 'hako-make.php';
require_once 'hako-util.php';
require_once 'hako-turn.php';

$init = new Init;

define("READ_LINE", 1024);
$THIS_FILE =  $init->baseDir . "/hako-main.php";
$BACK_TO_TOP = "<A HREF=\"{$THIS_FILE}?\">{$init->tagBig_}뒤로{$init->_tagBig}</A>";
$ISLAND_TURN; // 턴수

$PRODUCT_VERSION = '20040923';

//--------------------------------------------------------------------
class Hako extends HakoIO {
  var $islandList;	// 섬리스트
  var $targetList;	// 타겟의 섬리스트
  var $defaultTarget;	// 목표 보충용 타겟
  
  function readIslands(&$cgi) {
    global $init;
    
    $m = $this->readIslandsFile($cgi);
    $this->islandList = $this->getIslandList($cgi->dataSet['defaultID']);
    if($init->targetIsland == 1) {
      // 목표의 섬소유의 섬이 선택된 리스트
      $this->targetList = $this->islandList;
    } else {
      // 순위가 TOP의 섬이 선택된 상태의 리스트
      $this->targetList = $this->getIslandList($cgi->dataSet['defaultTarget']);
    }
    return $m;
  }

  //---------------------------------------------------
  // 섬리스트 생성
  //---------------------------------------------------
  function getIslandList($select = 0) {
    $list = "";
    for($i = 0; $i < $this->islandNumber; $i++) {
      $name = $this->islands[$i]['name'];
      $id   = $this->islands[$i]['id'];

      // 공격 목표를 미리 자신 섬으로 한다
      if(empty($this->defaultTarget)) {$this->defaultTarget = $id;}

      if($id == $select) {
        $s = "selected";
      } else {
        $s = "";
      }
      $list .= "<option value=\"$id\" $s>{$name}섬</option>\n";
    }
    return $list;
  }
  //---------------------------------------------------
  // 상에 관한 리스트를 생성
  //---------------------------------------------------
  function getPrizeList($prize) {
    global $init;
    list($flags, $monsters, $turns) = split(",", $prize, 3);

    $turns = split(",", $turns);
    $prizeList = "";
    // 턴배
    $max = -1;
    $nameList = "";
    if($turns[0] != "") {
      for($k = 0; $k < count($turns) - 1; $k++) {
        $nameList .= "[{$turns[$k]}] ";
        $max = $k;
      }
    }
    if($max != -1) {
      $prizeList .= "<img src=\"prize0.gif\" alt=\"$nameList\" width=\"16\" height=\"16\"> ";
    }
    // 상
    $f = 1;
    for($k = 1; $k < count($init->prizeName); $k++) {
      if($flags & $f) {
        $prizeList .= "<img src=\"prize{$k}.gif\" alt=\"{$init->prizeName[$k]}\" width=\"16\" height=\"16\"> ";
      }
      $f = $f << 1;
    }
    // 넘어뜨린 괴수 리스트
    $f = 1;
    $max = -1;
    $nameList = "";
    for($k = 0; $k < $init->monsterNumber; $k++) {
      if($monsters & $f) {
        $nameList .= "[{$init->monsterName[$k]}] ";
        $max = $k;
      }
      $f = $f << 1;
    }
    if($max != -1) {
      $prizeList .= "<img src=\"monster{$max}.gif\" alt=\"{$nameList}\" width=\"16\" height=\"16\"> ";
    }
    return $prizeList;
  }
  //------------------------------------------------------------------

  //---------------------------------------------------
  // 지형에 관한 데이터 생성
  //---------------------------------------------------
  function landString($l, $lv, $x, $y, $mode, $comStr) {
    global $init;
    $point = "({$x},{$y})";
    $naviExp = "''";

    if($x < $init->islandSize / 2)
      $naviPos = 0;
    else
      $naviPos = 1;

    switch($l) {
    case $init->landSea:
      switch($lv) {
      case 1:
        // 얕은 여울
        $image = 'land14.gif';
        $naviTitle = '얕은 여울';
        break;
      default:
        // 해
        $image = 'land0.gif';
        $naviTitle = '바다';
      }
      break;
    case $init->landWaste:
      // 황무지
      if($lv == 1) {
        $image = 'land13.gif'; // 착탄점
      } else {
        $image = 'land1.gif';
      }
      $naviTitle = '황무지';
      break;
    case $init->landPlains:
      // 평지
      $image = 'land2.gif';
      $naviTitle = '평지';
      break;
    case $init->landForest:
      // 삼
      if($mode == 1) {
        $image = 'land6.gif';
        $naviText= "{$lv}{$init->unitTree}";
      } else {
        // 관광자의 경우는 키노모토수 숨긴다
        $image = 'land6.gif';
      }
      $naviTitle = '숲';
      break;
    case $init->landTown:
      // 정
      $p; $n;
      if($lv < 30) {
        $p = 3;
        $naviTitle = '마을';
      } else if($lv < 100) {
        $p = 4;
        $naviTitle = '마을';
      } else {
        $p = 5;
        $naviTitle = '도시';
      }
      $image = "land{$p}.gif";
      $naviText = "{$lv}{$init->unitPop}";
      break;
    case $init->landFarm:
      // 농장
      $image = 'land7.gif';
      $naviTitle = '농장';
      $naviText = "{$lv}0{$init->unitPop}규모";
      break;
    case $init->landFactory:
      // 공장
      $image = 'land8.gif';
      $naviTitle = '공장';
      $naviText = "{$lv}0{$init->unitPop}규모";
      break;
    case $init->landBase:
      if($mode == 0 || $mode == 2) {
        // 관광자의 경우는 숲의 행세
        $image = 'land6.gif';
        $naviTitle = '숲';
      } else {
        // 미사일 기지
        $level = Util::expToLevel($l, $lv);
        $image = 'land9.gif';
        $naviTitle = '미사일 기지';
        $naviText = "레벨 {$level} / 경험치 {$lv}";
      }
      break;
    case $init->landSbase:
      // 해저 기지
      if($mode == 0 || $mode == 2) {
        // 관광자의 경우는 바다의 행세
        $image = 'land0.gif';
        $naviTitle = '바다';
      } else {
        $level = Util::expToLevel($l, $lv);
        $image = 'land12.gif';
        $naviTitle = '해저 기지';
        $naviText = "레벨 ${level} / 경험치 {$lv}";
      }
      break;
    case $init->landDefence:
      // 방위 시설
      $image = 'land10.gif';
      $naviTitle = '방위 시설';
      break;
    case $init->landHaribote:
      // 하리보테
      $image = 'land10.gif';
      if($mode == 0 || $mode == 2) {
        // 관광자의 경우는 방위 시설의 행세
        $naviTitle = '방위 시설';
      } else {
        $naviTitle = '하리보테';
      }
      break;
    case $init->landOil:
      // 해저 유전
      $image = 'land16.gif';
      $naviTitle = '해저 유전';
      break;
    case $init->landMountain:
      // 산
      if($lv > 0) {
        $image = 'land15.gif';
        $naviTitle = '채굴장';
        $naviText = "{$lv}0{$init->unitPop}규모";
      } else {
        $image = 'land11.gif';
        $naviTitle = '산';
      }
      break;
    case $init->landMonument:
      // 기념비
      $image = "monument{$lv}.gif";
      $naviTitle = '기념비';
      $naviText = $init->monumentName[$lv];
      break;
    case $init->landMonster:
      // 괴수
      $monsSpec = Util::monsterSpec($lv);
      $spec = $monsSpec['kind'];
      $special = $init->monsterSpecial[$spec];
      $image = "monster{$spec}.gif";
      $naviTitle = '괴수';

      // 경화중?
      if((($special == 3) && (($this->islandTurn % 2) == 1)) ||
         (($special == 4) && (($this->islandTurn % 2) == 0))) {
        // 경화중
        $image = $init->monsterImage[$monsSpec['kind']];
      }
      $naviText = "괴수{$monsSpec['name']}(체력{$monsSpec['hp']})";
    }

    if($mode == 1 || $mode == 2) {
      print "<a href=\"javascript: void(0);\" onclick=\"ps($x,$y)\">";
      $naviText = "{$comStr}\\n{$naviText}";
    }
    print "<img src=\"{$image}\" width=\"32\" height=\"32\" alt=\"{$point} {$naviTitle} {$comStr}\" onMouseOver=\"Navi({$naviPos},'{$image}', '{$naviTitle}', '{$point}', '{$naviText}', {$naviExp});\" onMouseOut=\"NaviClose(); return false\">";

    // 좌표 설정 닫고
    if($mode == 1 || $mode == 2)
      print "</a>";
  }
}
//--------------------------------------------------------------------
class LogIO {
  var $logPool = array();
  var $secretLogPool = array();
  var $lateLogPool = array();
  
  //---------------------------------------------------
  // 로그 파일을 뒤로 비켜 놓는다
  //---------------------------------------------------
  function slideBackLogFile() {
    global $init;
    for($i = $init->logMax - 1; $i >= 0; $i--) {
      $j = $i + 1;
      $s = "{$init->dirName}/hakojima.log{$i}";
      $d = "{$init->dirName}/hakojima.log{$j}";
      if(is_file($s)) {
        if(is_file($d))
           unlink($d);
        rename($s, $d);
      }
    }
  }
  //---------------------------------------------------
  // 최근의 사건을 출력
  //---------------------------------------------------
  function logFilePrint($num = 0, $id = 0, $mode = 0) {
    global $init;
    $fileName = $init->dirName . "/hakojima.log" . $num;
    if(!is_file($fileName)) {
      return;
    }
    $fp = fopen($fileName, "r");
    Util::lockr($fp);

    while($line = chop(fgets($fp, READ_LINE))) {
      list($m, $turn, $id1, $id2, $message) = split(",", $line, 5);
      if($m == 1) {
        if(($mode == 0) || ($id1 != $id)) {
          continue;
        }
        $m = "<strong>(기밀)</strong>";
      } else {
        $m = "";
      }
      if($id != 0) {
        if(($id != $id1) && ($id != $id2)) {
          continue;
        }
      }
      print "{$init->tagNumber_}턴{$turn}{$m}{$init->_tagNumber}:{$message}<br>\n";
    }
    Util::unlock($fp);
    fclose($fp);
  }
  //---------------------------------------------------
  // 발견의 기록을 출력
  //---------------------------------------------------
  function historyPrint() {
    global $init;
    $fileName = $init->dirName . "/hakojima.his";
    if(!is_file($fileName)) {
      return;
    }
    $fp = fopen($fileName, "r");
    Util::lockr($fp);

    $history = array();
    $k = 0;
    while($line = chop(fgets($fp, READ_LINE))) {
      array_push($history, $line);
      $k++;
    }
    for($i = 0; $i < $k; $i++) {
      list($turn, $his) = split(",", array_pop($history), 2);
      print "{$init->tagNumber_}턴{$turn}{$init->_tagNumber}:$his<br>\n";
    }
  }
  //---------------------------------------------------
  // 발견의 기록을 보존
  //---------------------------------------------------
  function history($str) {
    global $init;
    $fileName = "{$init->dirName}/hakojima.his";

    if(!is_file($fileName))
      touch($fileName);

    $fp = fopen($fileName, "a");
    Util::lockw($fp);
    fputs($fp, "{$GLOBALS['ISLAND_TURN']},{$str}\n");
    Util::unlock($fp);
    fclose($fp);
//    chmod($fileName, 0666);
    
  }
  //---------------------------------------------------
  // 발견의 기록 로그 조정
  //---------------------------------------------------
  function historyTrim() {
    global $init;
    $fileName = "{$init->dirName}/hakojima.his";
    if(is_file($fileName)) {
      $fp = fopen($fileName, "r");
      Util::lockr($fp);

      $line = array();
      while($l = chop(fgets($fp, READ_LINE))) {
        array_push($line, $l);
        $count++;
      }
      Util::unlock($fp);
      fclose($fp);
      if($count > $init->historyMax) {

        if(!is_file($fileName))
          touch($fileName);

        $fp = fopen($fileName, "w");
        Util::lockw($fp);
        for($i = ($count - $init->historyMax); $i < $count; $i++) {
          fputs($fp, "{$line[$i]}\n");
        }
        Util::unlock($fp);
        fclose($fp);
//        chmod($fileName, 0666);
      }
    }
  }
  //---------------------------------------------------
  // 로그
  //---------------------------------------------------
  function out($str, $id = "", $tid = "") {
    array_push($this->logPool, "0,{$GLOBALS['ISLAND_TURN']},{$id},{$tid},{$str}");
  }
  //---------------------------------------------------
  // 기밀 로그
  //---------------------------------------------------
  function secret($str, $id = "", $tid = "") {
    array_push($this->secretLogPool,"1,{$GLOBALS['ISLAND_TURN']},{$id},{$tid},{$str}");
  }
  //---------------------------------------------------
  // 지연 로그
  //---------------------------------------------------
  function late($str, $id = "", $tid = "") {
    array_push($this->lateLogPool,"0,{$GLOBALS['ISLAND_TURN']},{$id},{$tid},{$str}");
  }
  //---------------------------------------------------
  // 로그 서두
  //---------------------------------------------------
  function flush() {
    global $init;
    $fileName = "{$init->dirName}/hakojima.log0";

    if(!is_file($fileName))
      touch($fileName);

    $fp = fopen($fileName, "w");
    Util::lockw($fp);

    // 전부역순서로 해 써낸다
    if(!empty($this->secretLogPool)) {
      for($i = count($this->secretLogPool) - 1; $i >= 0; $i--) {
        fputs($fp, "{$this->secretLogPool[$i]}\n");
      }
    }
    if(!empty($this->lateLogPool)) {
      for($i = count($this->lateLogPool) - 1; $i >= 0; $i--) {
        fputs($fp, "{$this->lateLogPool[$i]}\n");
      }
    }
    if(!empty($this->logPool)) {
      for($i = count($this->logPool) - 1; $i >= 0; $i--) {
        fputs($fp, "{$this->logPool[$i]}\n");
      }
    }
    Util::unlock($fp);
    fclose($fp);
//    chmod($fileName, 0666);
  }    
  //---------------------------------------------------
  // 소식을 출력
  //---------------------------------------------------
  function infoPrint() {
    global $init;

    if($init->infoFile == "") return;

    $fileName = "{$init->infoFile}";
    if(!is_file($fileName)) return;

    $fp = fopen($fileName, "r");
    while($line = fgets($fp, READ_LINE)) {
      $line = chop($line);
      print "{$line}<br>\n";
    }
    fclose($fp);
  }
}

//--------------------------------------------------------------------
class Cgi {
  var $mode = "";
  var $dataSet = array();
  //---------------------------------------------------
  // POST, GET의 데이터를 취득
  //---------------------------------------------------
  function parseInputData() {
    global $init;

     $this->mode = $_POST['mode'];
    if(!empty($_POST)) {
      while(list($name, $value) = each($_POST)) {
//        $value = Util::sjis_convert($value);
        // 반각 가나가 있으면 전각으로 변환해 돌려준다
//       $value = i18n_ja_jp_hantozen($value,"KHV");
//       $value = str_replace(",", "", $value);
//       $value = JcodeConvert($value, 0, 2);
//        $value = HANtoZEN_SJIS($value);
        if($init->stripslashes == true) {
          $this->dataSet["{$name}"] = stripslashes($value);
        } else {
          $this->dataSet["{$name}"] = $value;
        }
      }
    }
    if(!empty($this->dataSet['IMGLINE'])) {
      $neo = $this->dataSet['IMGLINE'];
      if(strcmp($neo, 'delete') == 0) {
        $neo = $init->imgDir;
      } else {
        $neo = str_replace("\\", "/", $neo);
        $neo = preg_replace("/\/[\w\.]+\.gif/", "", $neo);
        $neo = 'file:///' . $neo;
      }
      $this->dataSet['IMG'] = $neo;
    }
    if(!empty($_GET['Sight'])) {
      $this->mode = "print";
      $this->dataSet['ISLANDID'] = $_GET['Sight'];
    }
    if(!empty($_GET['target'])) {
      $this->mode = "targetView";
      $this->dataSet['ISLANDID'] = $_GET['target'];
    }
    if($_GET['mode'] == "conf") {
      $this->mode = "conf";
    }
    if($_GET['mode'] == "log") {
      $this->mode = "log";
    }
    if($this->mode == "turn") {
      // 이 단계에서 mode 에 turn 가 세트 되는 것은 부정 액세스가 있는 경우만이므로 클리어 한다
      $this->mode = '';
    }
    if(!empty($_GET['islandListStart'])) {
      $this->dataSet['islandListStart'] = $_GET['islandListStart'];
    } else {
      $this->dataSet['islandListStart'] = 1;
    }
    $this->dataSet["ISLANDNAME"] = jsubstr($this->dataSet["ISLANDNAME"], 0, 16);
    $this->dataSet["MESSAGE"] = jsubstr($this->dataSet["MESSAGE"], 0, 60);
    $this->dataSet["LBBSMESSAGE"] = jsubstr($this->dataSet["LBBSMESSAGE"], 0, 60);
  }
  function lastModified() {
    global $init;

    // Last Modified 헤더를 출력
/*
    if($this->mode == "Sight") {
      $fileName = "{$init->dirName}/island.{$this->dataSet['ISLANDID']}";
    } else {
      $fileName = "{$init->dirName}/hakojima.dat";
    }
*/
    $fileName = "{$init->dirName}/hakojima.dat";
    $time_stamp = filemtime($fileName);
    $time = gmdate("D, d M Y G:i:s", $time_stamp);
    header ("Last-Modified: $time GMT");
    $this->modifiedSinces($time_stamp);
  }
  function modifiedSinces($time) {
    $modsince = $_SERVER{'HTTP_IF_MODIFIED_SINCE'};

    $ms = gmdate("D, d M Y G:i:s", $time) . " GMT";
    if($modsince == $ms)
      // RFC 822
      header ("HTTP/1.1 304 Not Modified\n");

    $ms = gmdate("l, d-M-y G:i:s", $time) . " GMT";
    if($modsince == $ms)
      // RFC 850
      header ("HTTP/1.1 304 Not Modified\n");

    $ms = gmdate("D M j G:i:s Y", $time);
    if($modsince == $ms)
      // ANSI C's asctime() format
      header ("HTTP/1.1 304 Not Modified\n");
  }
  //---------------------------------------------------
  // COOKIE를 취득
  //---------------------------------------------------
  function getCookies() {
    if(!empty($_COOKIE)) {
      while(list($name, $value) = each($_COOKIE)) {
        switch($name) {
        case "OWNISLANDID":
          $this->dataSet['defaultID'] = $value;
          break;
        case "OWNISLANDPASSWORD":
          $this->dataSet['defaultPassword'] = $value;
          break;
        case "TARGETISLANDID":
          $this->dataSet['defaultTarget'] = $value;
          break;
        case "LBBSNAME":
          $this->dataSet['defaultName'] = $value;
          break;
        case "POINTX":
          $this->dataSet['defaultX'] = $value;
          break;
        case "POINTY":
          $this->dataSet['defaultY'] = $value;
          break;
        case "COMMAND":
          $this->dataSet['defaultKind'] = $value;
          break;
        case "DEVELOPEMODE":
          $this->dataSet['defaultDevelopeMode'] = $value;
          break;
        case "SKIN":
          $this->dataSet['defaultSkin'] = $value;
          break;
        case "IMG":
          $this->dataSet['defaultImg'] = $value;
          break;
        }
      }
    }
  }
  //---------------------------------------------------
  // COOKIE를 생성
  //---------------------------------------------------
  function setCookies() {
    $time = time() + 30 * 86400; // 현재 + 30일 유효

    // Cookie의 설정 & POST로 입력된 데이터로, Cookie로부터 취득한 데이터를 갱신
    if($this->dataSet['ISLANDID'] && $this->mode == "owner") {
      setcookie("OWNISLANDID",$this->dataSet['ISLANDID'], $time);
      $this->dataSet['defaultID'] = $this->dataSet['ISLANDID'];
    }
    if($this->dataSet['PASSWORD']) {
      setcookie("OWNISLANDPASSWORD",$this->dataSet['PASSWORD'], $time);
      $this->dataSet['defaultPassword'] = $this->dataSet['PASSWORD'];
    }
    if($this->dataSet['TARGETID']) {
      setcookie("TARGETISLANDID",$this->dataSet['TARGETID'], $time);
      $this->dataSet['defaultTarget'] = $this->dataSet['TARGETID'];
    }
    if($this->dataSet['LBBSNAME']) {
      setcookie("LBBSNAME",$this->dataSet['LBBSNAME'], $time);
      $this->dataSet['defaultName'] = $this->dataSet['LBBSNAME'];
    }
    if($this->dataSet['POINTX']) {
      setcookie("POINTX",$this->dataSet['POINTX'], $time);
      $this->dataSet['defaultX'] = $this->dataSet['POINTX'];
    }
    if($this->dataSet['POINTY']) {
      setcookie("POINTY",$this->dataSet['POINTY'], $time);
      $this->dataSet['defaultY'] = $this->dataSet['POINTY'];
    }
    if($this->dataSet['COMMAND']) {
      setcookie("COMMAND",$this->dataSet['COMMAND'], $time);
      $this->dataSet['defaultKind'] = $this->dataSet['COMMAND'];
    }
    if($this->dataSet['DEVELOPEMODE']) {
      setcookie("DEVELOPEMODE",$this->dataSet['DEVELOPEMODE'], $time);
      $this->dataSet['defaultDevelopeMode'] = $this->dataSet['DEVELOPEMODE'];
    }
    if($this->dataSet['SKIN']) {
      setcookie("SKIN",$this->dataSet['SKIN'], $time);
      $this->dataSet['defaultSkin'] = $this->dataSet['SKIN'];
    }
    if($this->dataSet['IMG']) {
      setcookie("IMG",$this->dataSet['IMG'], $time);
      $this->dataSet['defaultImg'] = $this->dataSet['IMG'];
    }
  }
}


//--------------------------------------------------------------------
class Main {

  function execute() {
    $hako = new Hako;
    $cgi = new Cgi;
    
    $cgi->parseInputData();
    $cgi->getCookies();
    if(!$hako->readIslands($cgi)) {
      HTML::header($cgi->dataSet);
      Error::noDataFile();
      HTML::footer();
      exit();
    }
    $cgi->setCookies();
    $cgi->lastModified();

    if($cgi->dataSet['DEVELOPEMODE'] == "java") {
      $html = new HtmlJS;
      $com = new MakeJS;
    } else {
      $html = new HtmlMap;
      $com = new Make;
    }
    switch($cgi->mode) {
    case "turn":
      $turn = new Turn;
      $html = new HtmlTop;
      $html->header($cgi->dataSet);
      $turn->turnMain($hako, $cgi->dataSet); 
      $html->main($hako, $cgi->dataSet); // 턴 처리 후, TOP 페이지 open
      $html->footer();
      break;
    case "owner":
      $html->header($cgi->dataSet);
      $html->owner($hako, $cgi->dataSet);
      $html->footer();
      break;
    case "command":
      $html->header($cgi->dataSet);
      $com->commandMain($hako, $cgi->dataSet);
      $html->footer();
      break;
      
    case "new":
      $html->header($cgi->dataSet);
      $com->newIsland($hako, $cgi->dataSet);
      $html->footer();
      break;
    case "comment":
      $html->header($cgi->dataSet);
      $com->commentMain($hako, $cgi->dataSet);
      $html->footer();
      break;
      
    case "print":
      $html->header($cgi->dataSet);
      $html->visitor($hako, $cgi->dataSet);
      $html->footer();
      break;
    case "targetView":
      $html->header($cgi->dataSet);
      $html->printTarget($hako, $cgi->dataSet);
      $html->footer();
      break;
    case "change":
      $html->header($cgi->dataSet);
      $com->changeMain($hako, $cgi->dataSet);
      $html->footer();
      break;
    case "ChangeOwnerName":
      $html->header($cgi->dataSet);
      $com->changeOwnerName($hako, $cgi->dataSet);
      $html->footer();
      break;
    case "lbbs":
      $lbbs = new Make;
      $html->header($cgi->dataSet);
      $lbbs->localBbsMain($hako, $cgi->dataSet);
      $html->footer();
      break;
      
    case "skin":
      $html = new HtmlSetted;
      $html->header($cgi->dataSet);
      $html->setSkin();
      $html->footer();
      break;
    case "imgset":
      $html = new HtmlSetted;
      $html->header($cgi->dataSet);
      $html->setImg();
      $html->footer();
      break;
    case "conf":
      $html = new HtmlTop;
      $html->header($cgi->dataSet);
      $html->regist($hako, $cgi->dataSet);
      $html->footer();
      break;
    case "log":
      $html = new HtmlTop;
      $html->header($cgi->dataSet);
      $html->log();
      $html->footer();
      break;
      
    default: 
      $html = new HtmlTop;
      $html->header($cgi->dataSet);
      $html->main($hako, $cgi->dataSet);
      $html->footer();
    }
    exit();
  }
}
$start = new Main;
$start->execute();
?>
