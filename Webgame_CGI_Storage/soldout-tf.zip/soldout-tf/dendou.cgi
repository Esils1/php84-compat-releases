#!/usr/bin/perl
# $Id: stock.cgi,v 1.3 2001/12/31 12:59:27 mu Exp $
#TF�����Դϴ�(ȣ��)

require './_base.cgi';
GetQuery();

DataRead();
CheckUserPass(1);

	andolist();
	$disp.="<HR SIZE=1>";

	babelist();
	$disp.="<HR SIZE=1>";

	adalist();
	$disp.="<HR SIZE=1>";
	ibulist();

OutHTML('����',$disp);
exit;
sub andolist # �֐����Œ� [custom.cgi?cmd=andolist]�p
{
	my $rank=1;
	my @andoDT=grep $_->{user}->{ando},map{$_->{_now_rank}=$rank++,$_}@DT;
	
	$disp.="��ص�� ������<hr>";
	
	$disp.=join "",$TB,$TR,$TDNW,'����',$TDNW,'����',$TDNW,'����',$TDNW,'�ص����',$TRE,"\n";
	
	foreach my $DT (@andoDT)
	{
		if($DT->{item}[74-1]){
		my $itemtype=-1;
		my $itempro="";
		my $salelist="";
		foreach my $no (@{$DT->{showcase}})
		{
			$salelist.=GetTagImgItemType($no);
			$itemtype=0,next if $itemtype!=-1 && $ITEM[$no]->{type}!=$itemtype;
			$itemtype=$ITEM[$no]->{type};
		}
		$itempro=GetTagImgItemType(0,$itemtype,1)." " if $itemtype;
		my $job=$JOBTYPE{$DT->{job}};
		$job="��$job��" if $job;

		$disp.=join "",$TR,$TD,$DT->{_now_rank},$TD,$DT->{point},$TD,GetTagImgGuild($DT->{guild}).$itempro.$job.$DT->{shopname}."[$DT->{name}]",$TDNW,$DT->{user}->{ando},$TRE,"\n";
		}
	}
	$disp.=$TBE;
		
	return 1;
}

sub babelist # �֐����Œ� [custom.cgi?cmd=babelist]�p
{
	my $rank=1;
	my @babeDT=grep $_->{user}->{babe},map{$_->{_now_rank}=$rank++,$_}@DT;
	
	$disp.="��ٺ� ������<hr>";
	
	$disp.=join "",$TB,$TR,$TDNW,'����',$TDNW,'����',$TDNW,'����',$TDNW,'�ٺ���',$TRE,"\n";
	
	foreach my $DT (@babeDT)
	{
		if($DT->{item}[78-1]){
		my $itemtype=-1;
		my $itempro="";
		my $salelist="";
		foreach my $no (@{$DT->{showcase}})
		{
			$salelist.=GetTagImgItemType($no);
			$itemtype=0,next if $itemtype!=-1 && $ITEM[$no]->{type}!=$itemtype;
			$itemtype=$ITEM[$no]->{type};
		}
		$itempro=GetTagImgItemType(0,$itemtype,1)." " if $itemtype;
		my $job=$JOBTYPE{$DT->{job}};
		$job="��$job��" if $job;

		$disp.=join "",$TR,$TD,$DT->{_now_rank},$TD,$DT->{point},$TD,GetTagImgGuild($DT->{guild}).$itempro.$job.$DT->{shopname}."[$DT->{name}]",$TDNW,$DT->{user}->{babe},$TRE,"\n";
		}
	}
	$disp.=$TBE;
	
	return 1;
}

sub adalist # �֐����Œ� [custom.cgi?cmd=adalist]�p
{
	my $rank=1;
	my @adaDT=grep $_->{user}->{ada},map{$_->{_now_rank}=$rank++,$_}@DT;

	
	$disp.="��ƴ� ������<hr>";
	
	$disp.=join "",$TB,$TR,$TDNW,'����',$TDNW,'����',$TDNW,'����',$TDNW,'�ƴ��',$TRE,"\n";
	
	foreach my $DT (@adaDT)
	{
		if($DT->{item}[125-1]){
		my $itemtype=-1;
		my $itempro="";
		my $salelist="";
		foreach my $no (@{$DT->{showcase}})
		{
			$salelist.=GetTagImgItemType($no);
			$itemtype=0,next if $itemtype!=-1 && $ITEM[$no]->{type}!=$itemtype;
			$itemtype=$ITEM[$no]->{type};
		}
		$itempro=GetTagImgItemType(0,$itemtype,1)." " if $itemtype;
		my $job=$JOBTYPE{$DT->{job}};
		$job="��$job��" if $job;

		$disp.=join "",$TR,$TD,$DT->{_now_rank},$TD,$DT->{point},$TD,GetTagImgGuild($DT->{guild}).$itempro.$job.$DT->{shopname}."[$DT->{name}]",$TDNW,$DT->{user}->{ada},$TRE,"\n";
		}
	}
	$disp.=$TBE;
	
	
	return 1;
}

sub ibulist # �֐����Œ� [custom.cgi?cmd=ibulist]�p
{
	my $rank=1;
	my @ibuDT=grep $_->{user}->{ibu},map{$_->{_now_rank}=$rank++,$_}@DT;

	
	$disp.="���̺� ������<hr>";
	
	$disp.=join "",$TB,$TR,$TDNW,'����',$TDNW,'����',$TDNW,'����',$TDNW,'�̺��',$TRE,"\n";
	
	foreach my $DT (@ibuDT)
	{
		if($DT->{item}[124-1]){
		my $itemtype=-1;
		my $itempro="";
		my $salelist="";
		foreach my $no (@{$DT->{showcase}})
		{
			$salelist.=GetTagImgItemType($no);
			$itemtype=0,next if $itemtype!=-1 && $ITEM[$no]->{type}!=$itemtype;
			$itemtype=$ITEM[$no]->{type};
		}
		$itempro=GetTagImgItemType(0,$itemtype,1)." " if $itemtype;
		my $job=$JOBTYPE{$DT->{job}};
		$job="��$job��" if $job;

		$disp.=join "",$TR,$TD,$DT->{_now_rank},$TD,$DT->{point},$TD,GetTagImgGuild($DT->{guild}).$itempro.$job.$DT->{shopname}."[$DT->{name}]",$TDNW,$DT->{user}->{ibu},$TRE,"\n";
		}
	}
	$disp.=$TBE;
		
	return 1;
}

