#　설정 파일(SG soccer)

# 이 부분은 「저작권 표시」이므로 절대로 변경하지 말아 주세요
$ver = '샤코그레이드의 관：SG soccer 2 ver1. 00';

$|						= 1;	# 파일 버퍼 링크(변경 불가)
$method				= 'POST';	# GET or POST를 지정

# 각종 설정
$admin_pass		= '';	# 관리인 전용 패스워드
$league				= 1;	# 제? 회부터 2부 리그제 도입( 「0」으로 1부 리그제 속행)
$game_flg			= 2;	# 「0」으로 90분 결착, 「1」으로 연장 V골 방식, 「2」로 PK전 있어
$change				= 0;	# 「1」으로 무승부시 체프 교대
$div1_team		= 16;	# 1부 리그의 팀수
$updown_team	= 6;	# 승격 격하 팀수
$league[0]		= ' 제1부 리그';	# 1부 리그명
$league[1]		= ' 제2부 리그';	# 2부 리그명
$league_limit	= 7;	# 리그전의 기간 (일)
$league_game	= 50;	# 리그 기간 시합수의 최대치
$league_min		= 20;	# 이 시합수 오지 않음 없다고 평가점랭크에 나타나지 않는다
$league_time	= 0;	# 일자가 바뀌는 시간(0~23)
$between			= 1;	# 시합의 간격(분 )
$totpoint			= 212;# 팀의 파라미터 최대치(도중에의 변경은 불가)
$para_max			= 29;	# 선수 파라미터의 최대치
$para_min			= 10;	# 선수 파라미터의 최소치
$ten_max 			= 3;	# 파라미터 10의 수
$eight_max		= 5;	# 파라미터 8~9의 수
$nameleng			= 10;	# 이름의 길이를 전각무엇 문자까지 할까
$jogen				= 200;# 게임에 참가할 수 있는 상한 인원수
$userlimit		= 30;	# 유저 데이터 보관 유지 기한
$host_check		= 0;	# 「1」으로 복수 팀 사용을 제한
$proxy_check	= 0;	# 「1」으로 대리 경유 접속을 거부

# 디렉토리 패스
$dir[0]				= 'div1';	# 1부 리그 디렉토리
$dir[1]				= 'div2';	# 2부 리그 디렉토리
$datadir			= 'data';	# 데이터 파일 격납 디렉토리
$logdir				= 'log';	# 로그 파일 격납 디렉토리
$teamdir			= 'teamdata';	# 팀 데이터 격납 디렉토리
$imgdir				= 'image';	# 화상 파일 격납 디렉토리
$icondir			= 'icon';	# 아이콘 격납 디렉토리
$bkupdir			= 'backup';	# 백업 데이터 디렉토리
$tlogdir			= 'teamlog';	# 팀 로그 데이터 디렉토리

# 파일 패스
require 				'sgsoccer.pl';	# sgsoccer.pl의 패스 지정
$mainfile			= 'sgsoccer.cgi';	# 메인 파일
$gamefile			= 'game.pl';	# 게임 파일
$managefile		= 'manage.dat';	# 게임 진행 관리 파일
$winnerfile		= 'winner.dat';	# 현재의 승리자 파일
$zenkaifile		= 'zenkai.dat';	# 전회의 리그 랭킹 파일
$rekidaifile	= 'rekidai.dat';	# 역대 랭킹 파일
$wp_rankfile	= 'wp_rank.dat';	# 역대 승점 랭킹 파일
$rankingfile	= 'ranking.dat';	# 팀 랭킹 파일
$accesslog		= 'access.log';	# 액세스 로그 파일
$kekkalog			= 'kekka.log';	# 시합 결과 로그 파일
$muchlog			= 'much';	# 시합 경과 로그 파일(확장자(extension) 불요)
$helpfile			= 'help.html';	# 헬프 파일
$adminfile		= 'admin.cgi';	# 관리용 파일
$mentefile		= 'mente.cgi';	# 멘테후라그파일

# 표시 설정
$bgcolor			= '#339933';	# 백 칼라 지정
$text					= '#ffffff';	# 텍스트 칼라 지정
$text1				= '#ffff00';	# 텍스트 칼라 지정(주의 사항등 )
$text2				= '#00ffff';	# 텍스트 칼라 지정(주의 사항등 )
$link					= '#00ff00';	# 링크 텍스트 칼라 지정
$vlink				= '#00ff00';	# 링크제텍스트 칼라 지정
$alink				= '#00ff00';	# 링크중 텍스트 칼라 지정
$background		= 'pitch.gif';	# 배경 화상(확장자(extension)까지 기입)
$textsize			= '12pt';	# 문자의 크기(스타일 시트)
$thbgcolor		= '#008000';	# 겉(표)의 표제의 백 칼라
$thtcolor			= '#ffffff';	# 겉(표)의 표제의 색
$hover				= '#ffffff';	# 링크상 텍스트 칼라 지정(스타일 시트)
$bghover			= '#cc3300';	# 링크상백 칼라 지정(스타일 시트)
$homecolor		= '#ffff00';	# 홈 팀의 특성
$awaycolor		= '#00ffff';	# 어웨이 팀의 특성
$h_tag				= "<font color=$homecolor><b><big>";	# 홈 팀 태그
$h_tag_end		= '</big></b></font>';
$a_tag				= "<font color=$awaycolor><b><big>";	# 어웨이 팀 태그
$a_tag_end		= '</big></b></font>';
$width				= 600;	# 화면 사이즈
$cupmark			= "☆";	# 우승 회수를 나타내는 마크(태그 사용가능)

# 아이콘
$icon_use 		= 1;	# 「1」으로 아이콘을 사용
$icon_view		= 5;	# 아이콘 일람에서의 1행의 표시수
@icon					= ("world1","world2","world3","world4","world5","world6","world7","world8","world9","world10","world11","world12","world13","world14","world15","world16","world17","world18","world19","world20","world21","world22","world23","world24","world25","world26","world27","world28","world29","world30","world31","world32","world33","world34","world35","world36","world37","world38","world39","world40","world41","world42","world43","world44","world45","world46","world47","world48","world49","world50","world51","club1","club2","club3","club4","club5","club6","club7","club8","club9","club10","club11","club12","club13","club14","club15","club16","club17","club18","club19","club20","club21","club22","club23","club24","club25","club26","club27","club28","club29","club30","club31","club32","club33","club34","club35","club36","club37","club38","club39","club40","club41","club42","club43","club44","club45","club46","club47","club48","club49","club50","club51","club52","club53");	# 파일명(확장자(extension)는 불요)을 기입( 「. gif」마셔 사용 가능)
#@icon				= ("icon01","icon02");	# 예

# 락 파일 기구(KENT씨의 스크립트보다 일부 발췌하고 있습니다)
#   0 : 행하지 않는다
#   1 : 행한다(symlink 함수식)
#   2 : 행한다(mkdir 함수식)
$lockkey			= 2;
$lockfile			= './lock/sgsoccer.lock';	# 락 파일명


$home					= 'x2-dr';	# HP명
$homeurl			= 'http://www.x2-dr.com/';	# 귀가처 URL
$title2				= 'SG soccer 2';	# 브라우저에 표시되는 타이틀
$title				= <<"_EOF_";	# 탑 화면에 표시되는 타이틀(태그 사용가능)
<h1>SG soccer 2</h1>
_EOF_

$message			= <<"_EOF_";	#탑 페이지의 메세지
<small>「SG soccer 2」는 수치를 배분해 시합을 하는 축구 게임입니다. <br>
팀을 등록해$league_limit 일간($league_game 시합)의 리그전에 참가해 주세요. </small>
_EOF_

# 설정은 여기까지

1;
