
#----------------#
#  호스트 나토리 이득  #
#----------------#
sub get_host {
	
	my $host = $ENV{REMOTE_HOST};
	my $addr = $ENV{REMOTE_ADDR};
#	if((!$host)||($host eq $addr)){ 
#		$host = gethostbyaddr(pack('C4',split(/\./,$addr)),2) || $addr;
#	}
	if((!$host)||($host eq $addr)){ 
		$host = $addr;
	}
	return $host;
	
}#END get_host

1;

#------------------------------------#
#  디코드＆로컬 변수에 주고 받아  #
#------------------------------------#
sub decode {
	
	
	# 입력된 값을 디코드
	my $buffer="";
	if($ENV{REQUEST_METHOD} eq "GET"){
		$buffer = $ENV{QUERY_STRING};
	}elsif($ENV{REQUEST_METHOD} eq "POST"){
		read(STDIN, $buffer, $ENV{CONTENT_LENGTH});
	}
	my @pairs = split(/&/,$buffer);
	foreach (@pairs) {
		my ($name,$value) = split(/=/);
		$value =~ tr/+/ /;
		$value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
		$value =~ s/</&lt;/g;
		$value =~ s/>/&gt;/g;
		$value =~ s/ //g;
		$value =~ s/ //g;
		$form{$name} = $value;
	}
	
}#END decode

1;

#----------------#
#  로그 read  #
#----------------#
sub readlog {
	
	# 시간의 취득
	$times = time;
	my ($sec,$min,$hour) = localtime($times);
	$hour = sprintf("%02d",$hour);
	$min	= sprintf("%02d",$min);
	$sec	= sprintf("%02d",$sec);
	local $kakiko_times = $times-((($hour-$league_time+24)%24)*3600+$min*60+$sec);
	
	if(-z $managefile){
		$l_day_pri = "－<b> 첫날 </b>－";
		$ma_dai = 1;
		&write("$managefile","$kakiko_times<>$ma_dai<>0<><><><>0<><><><>\n");
	}else{
		my @manage = &load("$managefile");
		($ma_date, $ma_dai, $ma_rensho1, $ma_teamname1, $ma_owner1, $ma_icon1, $ma_rensho2, $ma_teamname2, $ma_owner2, $ma_icon2) = split(/<>/, $manage[0]);
		$league_day = int(($times-$ma_date) / (60*60*24)) + 1;
		if($league_day == 1){$l_day_pri = "－<b> 첫날 </b>－";}
		elsif($league_day == $league_limit){$l_day_pri = "－<b>마지막 날</b>－";}
		else{
			if($league_day > $league_limit){&league_end;}
			else{$l_day_pri = "－<b>$league_day 일째</b>－";}
		}
	}
	$l_day_pri .= "<br><small>(일자는 매일$league_time시로 바뀝니다)</small>";
	
}#END readlog

1;

#----------------#
#  헤더 표시  #
#----------------#
sub header {
	
	print "Content-type: text/html; charset=utf-8\n\n";#컨텐트 타입 출력
	print <<"_EOF_";
<html>
<head>
<title>$title2</title>
<META HTTP-EQUIV="Content-type" CONTENT="text/html; charset=utf-8">
<STYLE type="text/css">
<!--
BODY,TABLE,TH,TD,P,DIV{
  color : $text;
  font-size : "$textsize";
  font-family : "MS Pgothic";
}
H2{
  font-size : 18pt;
  font-family : "MS Pgothic";
}
A{
  color : $link;
  text-decoration : none;
}
A:LINK{
  color : "$link";
  text-decoration : none;
}
A:VISITED{
  color : "$vlink";
  text-decoration : none;
}
A:ACTIVE{
  color : "$alink";
  text-decoration : none;
}
A:HOVER{
  color : $hover;
	background-color : $bghover;
  text-decoration : underline;
}
.title{
  font-size : 18pt;
  font-family : Ms Gothic;
  color : $thtcolor;
	background-color : $thbgcolor;
}
-->
</STYLE>
</head>
<body bgcolor="$bgcolor" text="$text" alink="$alink" link="$link" vlink="$vlink" background="$imgdir/$background">
<center>
<!--광고 배너 삽입 위치, 페이지 상부-->
_EOF_
	
}#END header

1;

#----------------#
#  풋터 표시  #
#----------------#
sub footer {
	
	# 저작권 표시
	print <<"_CHOSAKU_";
<hr size=1>
<div align=right><small>
<a href="http://www.sg-kan.com/" target="_blank">$ver</a> <br>
<a href="http://soccer.sunnyday.jp/" target="_blank">아이콘 배부원：축구·트램포린</a><br>
<a href="http://x2-dr.com/" target="_blank">한글화 : X2-DR.com 웹게임 커뮤니티</a><br>
</small></div>
<!--광고 배너 삽입 위치, 페이지 하부-->
</center>
</body>
</html>
_CHOSAKU_
	
}#END footer

1;

#----------------#
#  메뉴 표시  #
#----------------#
sub menu {
	
	print <<"_EOF_";
<hr><div align=left>
<a href="$homeurl">$home</a>  / 
<a href="$mainfile">TOP</a>  / 
<a href="$helpfile" target=_blank>HELP</a> 
_EOF_
	if($form{login} || $form{login_check}){
		print " / <a href=$mainfile?ranking=team&id=$form{id}&password=$form{password} target=_blank>최신 팀 랭킹</a> \n";
		print " / <a href=$mainfile?ranking=player&id=$form{id}&password=$form{password}&teamname=$teamname target=_blank>최신 선수 랭킹</a> \n";
		print " / <a href=$mainfile?ranking=rensho&id=$form{id}&password=$form{password}&teamname=$teamname target=_blank>연승 기록 랭킹</a> \n";
		print " / <a href=$mainfile?ranking=rekidai&teamname=$teamname target=_blank>역대 랭킹</a> \n" if $ma_dai > 1;
;
		print " / <a href=$mainfile?ranking=zenkai&teamname=$teamname target=_blank>전회 랭킹</a> \n" if $ma_dai > 1;
	}
	if($form{ranking}){
		print " / (브라우저의 「돌아온다」버튼으로 돌아와 주세요) \n";
	}
	print "</div><hr>";
	
}#END menu

1;

#--------------#
#  리스트 작성  #
#--------------#
sub list {
	
	my $key = shift @_;
	my @list=();
	foreach(@_){
		if($_ ne $key){push @list,"<option value=$_>$_</option>\n";}
		else{push @list,"<option value=$_ selected>$_</option>\n";}
	}
	return @list;
	
}#END list

1;

#--------------------#
#  파일 read  #
#--------------------#
sub load {
	
	open(IN,"$_[0]") || &error("read error<br>($_[0])");
	seek(IN,0,0);
	my @loadfile = <IN>;
	close(IN);
	return @loadfile;
	
}#END load

1;

#--------------------#
#  파일 기입  #
#--------------------#
sub write {
	
	my $writefile = shift @_;
	open(OUT,">$writefile") || &error("기입 에러<br>($writefile)");
	eval 'flock(OUT,2);';
	seek(OUT,0,0);
	print OUT @_;
	eval 'flock(OUT,8);';
	close(OUT);
	
}#END write

1;

#--------------#
#  스프릿트  #
#--------------#
sub split {
	
	if ( $_[0] eq "teamdata" ){
		($id, $password, $owner, $teamname, $tac, $tac_zp, $tac_ca, $tac_pp, $tac_vszp, $tac_vsca, $tac_vspp, $icon, $date, $win, $win1, $win2, $lose, $draw, $win_p, $winmax, $sotokuten, $soshiten, $cup, $host) = split(/<>/,$_[1]);
	
	}elsif ( $_[0] eq "h_teamdata" ){
		($h_id, $h_password, $h_owner, $h_teamname, $h_tac, $h_tac_zp, $h_tac_ca, $h_tac_pp, $h_tac_vszp, $h_tac_vsca, $h_tac_vspp, $h_icon, $h_date, $h_win, $h_win1, $h_win2, $h_lose, $h_draw, $h_win_p, $h_winmax, $h_sotokuten, $h_soshiten, $h_cup, $h_host) = split(/<>/,$_[1]);
	
	}elsif ( $_[0] eq "a_teamdata" ){
		($a_id, $a_password, $a_owner, $a_teamname, $a_tac, $a_tac_zp, $a_tac_ca, $a_tac_pp, $a_tac_vszp, $a_tac_vsca, $a_tac_vspp, $a_icon, $a_date, $a_win, $a_win1, $a_win2, $a_lose, $a_draw, $a_win_p, $a_winmax, $a_sotokuten, $a_soshiten, $a_cup, $a_host) = split(/<>/,$_[1]);
	
	}elsif ( $_[0] eq "playersdata" ){
		($shozoku[$i], $p_name[$i], $posi[$i], $pass[$i], $dori[$i], $shoo[$i], $defe[$i], $fk[$i], $pk[$i], $style[$i], $fair[$i], $score[$i], $hyoka[$i], $cond[$i]) = split(/<>/,$_[1]);
	
	}elsif ( $_[0] eq "h_playersdata" ){
		($h_shozoku[$i], $h_name[$i], $h_posi[$i], $h_pass[$i], $h_dori[$i], $h_shoo[$i], $h_defe[$i], $h_fk[$i], $h_pk[$i], $h_style[$i], $h_fair[$i], $h_score[$i], $h_hyoka[$i], $h_cond[$i]) = split(/<>/,$_[1]);
	
	}elsif ( $_[0] eq "a_playersdata" ){
		($a_shozoku[$i], $a_name[$i], $a_posi[$i], $a_pass[$i], $a_dori[$i], $a_shoo[$i], $a_defe[$i], $a_fk[$i], $a_pk[$i], $a_style[$i], $a_fair[$i], $a_score[$i], $a_hyoka[$i], $a_cond[$i]) = split(/<>/,$_[1]);
	
	}elsif ( $_[0] eq "playerdata" ){
		($shozoku, $p_name, $posi, $pass, $dori, $shoo, $defe, $fk, $pk, $style, $fair, $score, $hyoka, $cond) = split(/<>/,$_[1]);
	
	}elsif ( $_[0] eq "winnerdata" ){
		($w_id, $w_teamname, $w_owner, $w_icon, $w_rensho, $w_cup, $w_before, $w_host) = split(/<>/,$_[1]);
	
	}elsif ( $_[0] eq "rekidai" ){
		($re_dai, $id, $owner, $teamname, $icon, $win, $win1, $win2, $lose, $draw, $win_p, $winmax, $sotokuten, $soshiten, $wm_id, $wm_owner, $wm_teamname, $wm_icon, $wm_winmax, $s_shozoku, $s_p_name, $s_posi, $s_score, $s_hyoka, $h_shozoku, $h_p_name, $h_posi, $h_score, $h_hyoka, $shozoku_gk, $p_name_gk, $score_gk, $hyoka_gk, $shozoku_df, $p_name_df, $score_df, $hyoka_df, $shozoku_dmf, $p_name_dmf, $score_dmf, $hyoka_dmf, $shozoku_omf, $p_name_omf, $score_omf, $hyoka_omf, $shozoku_fw, $p_name_fw, $score_fw, $hyoka_fw) = split(/<>/,$_[1]);
	
	}elsif ( $_[0] eq "kekka" ){
		($log_no, $log_date, $log_card, $log_result, $log_cmt) = split(/<>/,$_[1]);
	
	}else{&error("split에 실패했습니다");}
	
}#END split

1;

#--------------#
#  일자의 취득  #
#--------------#
sub get_date {
	
	my ($dsec, $dmin, $dhour, $dday, $dmon) = localtime($_[0]);
	$dmon++;
	$dmon	= sprintf("%02d",$dmon);
	$dday	= sprintf("%02d",$dday);
	$dhour= sprintf("%02d",$dhour);
	$dmin	= sprintf("%02d",$dmin);
	my $ddate = "$dmon/$dday $dhour:$dmin";
	return $ddate;
	
}#END get_date

1;

#------------------#
#  쿠키의 발행  #
#------------------#
sub set_cookie {
	
	$ENV{TZ} = "GMT"; # 국제 표준시를 취득
	my ($secg, $ming, $hourg, $mdayg, $mong, $yearg, $wdayg, $ydayg, $isdstg) =localtime(time+$userlimit*24*60*60);
	$yearg += 1900;
	$mdayg= sprintf("%02d",$mdayg);
	$hourg= sprintf("%02d",$hourg);
	$ming	= sprintf("%02d",$ming);
	$secg	= sprintf("%02d",$secg);
	my $month = ('Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec')[$mong];
	my $youbi = ('Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday')[$wdayg];
	$ENV{TZ} = "Japan";
	my $date_gmt = "$youbi, $mdayg\-$month\-$yearg $hourg:$ming:$secg GMT";
	my $cookie ="id<>$form{id}\,password<>$form{password}";
	print "Set-Cookie: SGSOCCER=$cookie; expires=$date_gmt\n";

}#END set_cookie

1;

#------------------#
#  쿠키를 취득  #
#------------------#
sub get_cookie {
	
	my @pairs = split(/;/,$ENV{HTTP_COOKIE});
	foreach(@pairs){
		my ($key,$val) = split(/=/);
		$key =~ s/\s//g;
		$GET{$key} = $val;
	}
	my @pairs = split(/,/, $GET{SGSOCCER});
	foreach(@pairs){
		my ($key,$val) = split(/<>/);
		$COOK{$key} = $val;
	}
	$c_password = $COOK{password};
	$c_id = $COOK{id};
	if ($form{id}){$c_id = $form{id};}
	if ($form{password}){$c_password = $form{password};}
	
}#END get_cookie

1;

#--------------#
#  락 처리  #
#--------------#
sub lock {
	
	local($retry) = 5;
	if(-e $lockfile){
		local($mtime) = (stat($lockfile))[9];
		if($mtime < time-60){&unlock;}
	}
	# symlink 함수식 락
	if($lockkey == 1){
		while(!symlink(".",$lockfile)){
			if(--$retry <= 0){&error('LOCK is BUSY');}
			sleep(1);
		}
	# mkdir 함수식 락
	}elsif($lockkey == 2){
		while(!mkdir($lockfile,0755)){
			if(--$retry <= 0){&error('LOCK is BUSY');}
			sleep(1);
		}
	}
	$lockflag=1;
	
}#END lock

1;

#--------------#
#  락 해제  #
#--------------#
sub unlock {
	
	if($lockkey == 1){unlink($lockfile);}
	elsif($lockkey == 2){rmdir($lockfile);}
	$lockflag=0;
	
}#END unlock

1;

#--------------------#
#  에러때의 처리  #
#--------------------#
sub error {
	
	if($lockflag){&unlock;}
	
	&header;
	print <<"_ERROR_";
<html><head><title>ERROR</title></head>
<body>
$_[0]<BR><BR>
(브라우저의 「돌아온다」버튼으로 돌아와 주세요)
</body>
</html>
_ERROR_
exit;
	
}#END error

1;

#--------------------------#
#  엔들레스 루프 체크 처리  #
#--------------------------#
sub loop_check {
	
	if($loop_count >= 1000){&error("1000이상의 루프 처리를 행했습니다. <br><a href=$homeurl>$home</a> 에 연락해 주세요<br><br>에러 코드：$_[0]");}
	$loop_count++;
	
}#END loop_check

1;

#------------#
#  ID암호화  #
#------------#
sub id_conv {
	
	$crypt_id = crypt($_[0],$_[0]);
	$crypt_id =~ tr/\///d;
	
}#END id_conv

1;

#--------------------#
#  팀 로그의 갱신  #
#--------------------#
sub log_write {
	
	# 팀 로그의 갱신
	&id_conv("$h_id");
#	if(-e "$tlogdir/konkai/$crypt_id.cgi"){
		open(OUT,">>$tlogdir/konkai/$crypt_id.cgi") || &error("기입 에러<br>($crypt_id.cgi)");
#	}else{
#		open(OUT,">$tlogdir/konkai/$crypt_id.cgi") || &error("기입 에러<br>($crypt_id.cgi)");
#	}
	eval 'flock(OUT,2);';
	seek(OUT,0,0);
	print OUT "$times<>0<>0<>0<>$a_id<>$a_teamname<>$a_owner<>$h_score-$a_score<>$remote_host<>\n";
	eval 'flock(OUT,8);';
	close(OUT);
	
	&id_conv("$a_id");
#	if(-e "$tlogdir/konkai/$crypt_id.cgi"){
		open(OUT,">>$tlogdir/konkai/$crypt_id.cgi") || &error("기입 에러<br>($crypt_id.cgi)");
#	}else{
#		open(OUT,">$tlogdir/konkai/$crypt_id.cgi") || &error("기입 에러<br>($crypt_id.cgi)");
#	}
	eval 'flock(OUT,2);';
	seek(OUT,0,0);
	print OUT "$times<>$h_id<>$h_teamname<>$h_owner<>0<>0<>0<>$h_score-$a_score<>$remote_host<>\n";
	eval 'flock(OUT,8);';
	close(OUT);
	
}#END log_write

1;

#----------------------------#
#  역대 승점 랭킹 갱신  #
#----------------------------#
sub win_p_rank_check {
	
	if($_[1] eq $dir[0]){$_[1] = 0;}
	else{$_[1] = 1;}
	my(@sortkey1, @sortkey2, @sort_check);
	my $kousin_flg = 0;
	my @check = &load("$dir[$_[1]]/$datadir/$wp_rankfile");
	my @log = split(/<>/,$check[9]);
	my @konkai = split(/<>/,$_[0]);
	if($konkai[5] > $log[5]){
		&id_conv("$konkai[1]");
		my @log = &load("$tlogdir/konkai/$crypt_id.cgi");
		open(OUT,">$tlogdir/rekidai/$crypt_id$konkai[0]. cgi") || &error("기입 에러<br>($tlogdir/rekidai/$crypt_id$konkai[0]. cgi)");
		eval 'flock(OUT,2);';
		seek(OUT,0,0);
		print OUT @log;
		eval 'flock(OUT,8);';
		close(OUT);
		foreach(@check){
			my ($wp_dai, $wp_id, $wp_teamname, $wp_owner, $wp_icon, $wp_win_p) = split(/<>/);
			if($wp_dai == $konkai[0] && $konkai[1] eq $wp_id){
				push(@sort_check,"$wp_dai<>$wp_id<>$wp_teamname<>$wp_owner<>$wp_icon<>$konkai[5]<>\n");
				push(@sortkey1, $konkai[5]);
				$kousin_flg = 1;
			}else{
				push(@sort_check,$_);
				push(@sortkey1,$wp_win_p);
			}
			push(@sortkey2,$wp_dai);
		}
		if(!$kousin_flg){
			push(@sort_check,$_[0]);
			push(@sortkey1,$konkai[5]);
			push(@sortkey2,$konkai[0]);
		}
		my @sort_check = @sort_check[sort {$sortkey1[$b] <=> $sortkey1[$a] or	$sortkey2[$a] <=> $sortkey2[$b]} 0 .. $#sortkey1];
		if(@sort_check >= 11){
			my $delete_log = pop(@sort_check);
			my ($wp_dai, $wp_id, $wp_teamname, $wp_owner, $wp_icon, $wp_win_p) = split(/<>/, $delete_log);
			&id_conv("$wp_id");
			if(-e "$tlogdir/rekidai/$crypt_id$wp_dai.cgi"){unlink "$tlogdir/rekidai/$crypt_id$wp_dai.cgi";}
		}
		&write("$dir[$_[1]]/$datadir/$wp_rankfile",@sort_check);
	}
	
}#END win_p_rank_check

1;

