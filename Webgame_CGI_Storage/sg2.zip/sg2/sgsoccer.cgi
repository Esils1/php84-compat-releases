#!/usr/bin/perl

#----------------------------------------------------------------------
#
#	이 스크립트는 동고의 「readme.txt」의 이용 규정에 따라 배포되고 있습니다.
#
# sgsoccer.ini(각종 설정 파일)의 패스 지정
require './sgsoccercon.cgi';
#
#----------------------------------------------------------------------

if(-e "$mentefile"){&error("지금  멘테중입니다 m(_ _) m");}
&decode;
&readlog;
if($form{make_new}){&regist_check; &make; exit;}
if($form{make}){&para_set; &make; exit;}
if($form{make_check}){&para_check; &para_set; &make; exit;}
if($form{iconlist}){&iconlist; exit;}
if($form{regist}){&regist; exit;}
if($form{login}){&login; exit;}
if($form{login_check}){&para_check; &login; exit;}
if($form{delete}){&delete; exit;}
if($form{delete_check}){&delete_check; exit;}
if($form{kickoff}){&teams_set; &kickoff; &kekka; &save_data; exit;}
if($form{result}){&result; exit;}
if($form{wincup}){&comment;}
if($form{ranking}){&ranking; exit;}
if($form{log_view}){&log_view; exit;}
&top;

exit;

#----------------#
#	탑 페이지	#
#----------------#
sub top {
	
	&get_cookie;
	&header;
	print <<"_EOF_";
<table width=$width><tr><td align=center width=70%>$title( 제<b>$ma_dai</b>회 )<br>$l_day_pri<br><br><table width=90% border=1 cellspacing=0 cellpadding=10><tr><td>$message</td></tr></table></td>
	<td align=center>
	<table border=1 width=100% cellspacing=0 class=border><tr align=center><form action=$mainfile method=$method><th bgcolor=$thbgcolor><font color=$thtcolor><big>MENU</big></font></th><tr align=center><td><br>
_EOF_
	print "<table border=1 cellspacing=0><tr><td>I	D</td><td><input type=text name=id size=8></td></tr><tr><td>PASS</td><td><input type=password name=password size=8></td></tr></table><br><input type=hidden name=making value=team><input type=submit name=make_new value='NEW GAME'><br><br>" if ! $COOK{id};
	print "<input type=submit name=login value=LOGIN><br><br>";
	print "<input type=submit name=delete_check value=DELETE><br><br>" if $league_day==1;
	print "<input type=hidden name=id value=$c_id><input type=hidden name=password value=$c_password>" if $COOK{id};
	print "</form><a href=$homeurl>$home에 돌아온다</a> <br><br></td></tr></table></td></tr></table><br>";
	if($league <= $ma_dai && $league){
		my @winner = &load("$dir[0]/$datadir/$winnerfile");
		&split("winnerdata","$winner[0]");
		my $icon_pri="<img src=$icondir/$w_icon.gif align=middle>" if $icon_use;
		my $rensho="<br><b>현재<B>$w_rensho</B>연승중</b><br>" if $w_rensho>1;
		my $cup_pri='';
		if($w_cup){
			$loop_count=0; # 루프 체크
			for($i=0; $i<$w_cup; $i++){
				&loop_check; # 루프 체크
				if(0 == $i%10 && $i != 0){$cup_pri .= "<br>";}
				$cup_pri .= $cupmark;
			}
		}
		print "<br><table border=1 width=$width cellspacing=0 cellpadding=5><tr align=center><th><big><big>$league[0]</big></big></th></tr>\n";
		print "<tr><td align=center><table><tr><td align=center><font color=#ffc0cd><big><b>NOW<br>CHAMPION</b></big></font><small>$rensho</small></td><td><table><tr><td rowspan=2>$icon_pri</td><td>$cup_pri</td></tr><tr><td><b><font color=$text1><big><big>$w_teamname</big></big></font></b>($w_owner)</td></tr></table></td></tr></table></tr></td></tr>\n";
		if($ma_rensho1 > 1){
#			my $icon_pri="<img src=$icondir/$ma_icon1.gif align=middle>" if $icon_use;
			print <<"_EOF_";
<tr align=center>
	<td><small>현재의 연승 기록：<font color=$text1><big><b>$ma_teamname1</b></big></font>($ma_owner1)의<font color=$text1><big>$ma_rensho1</big></font>연승</small></td>
</tr>
_EOF_
		}
		print "</table>\n";
		print "<table align=center width=$width><tr><td width=40% valign=top>\n";
		print "<br><table border=1 cellspacing=0 cellpadding=5 width=100%><caption><big><b>- 최근 3 시합의 결과 -</b></big></captin><tr><td><small>\n";
		my @kekka = &load("$dir[0]/$logdir/$kekkalog");
		foreach(@kekka){
			&split("kekka","$_");
			my $log_date = &get_date("$log_date");
			print "$log_date<br><a href=$mainfile?result=part&filename=$muchlog$log_no&class=div1><b>$log_card</b></a> <br>$log_result";
			print "<br>$log_cmt" if $log_cmt;
			print "<br><br>";
		}
		print "</dl></small></td></tr></table></td><td valign=top>\n";
		
		print "<br><table border=1 cellspacing=0 cellpadding=5 width=100%><caption><big><b>- 리그 랭킹 -</b></big></captin><tr align=center>\n";
		print "<td>순<br>위</td><td>팀명(HN)</td><td>시<br>합</td><td>승<br></td><td>패<br></td>";
		print "<td>인<br>분</td>" if $game_flg != 2;
		print "<td>승<br>점</td></tr>\n";
		my @ranking = &load("$dir[0]/$datadir/$rankingfile");
		$ii=0;
		foreach(@ranking){
			if($ii >= 5){last;}
			$ii++;
			&split("teamdata","$_");
			my $shiai = $win+$lose+$draw;
			if($ii == 1){
				my $icon_pri="<img src=$icondir/$icon.gif align=middle>" if $icon_use;
				my $cup_pri='';
				if($cup){
					$loop_count=0; # 루프 체크
					for($i=0; $i<$cup; $i++){
						&loop_check; # 루프 체크
						if(0 == $i%10 && $i != 0){$cup_pri .= "<br>";}
						$cup_pri .= $cupmark;
					}
				}
				print "<tr align=right><td align=center><big><b>$ii</b></big></td><td align=center><table cellspacing=0 cellpadding=0 width=100%><tr><td rowspan=2>$icon_pri</td><td>$cup_pri</td></tr><tr><td><big><b>$teamname</b></big><br>($owner)</td></tr></table></td><td>$shiai</td><td>$win</td><td>$lose</td>";
			}else{
				print "<tr align=right><td align=center>$ii</td><td align=left>$teamname<br><small>($owner)</small></td><td>$shiai</td><td>$win</td><td>$lose</td>";
			}
			print "<td>$draw</td>" if $game_flg != 2;
			print "<td>$win_p</td></tr>";
		}
		print "</table>";
		print "</td></tr></table><br>";
	}
	
	my @winner = &load("$dir[1]/$datadir/$winnerfile");
	&split("winnerdata","$winner[0]");
	my $icon_pri="<img src=$icondir/$w_icon.gif align=middle>" if $icon_use;
	my $rensho="<br><b>현재<B>$w_rensho</B>연승중</b><br>" if $w_rensho>1;
	my $cup_pri='';
	if($w_cup){
		$loop_count=0; # 루프 체크
		for($i=0; $i<$w_cup; $i++){
			&loop_check; # 루프 체크
			if(0 == $i%10 && $i != 0){$cup_pri .= "<br>";}
			$cup_pri .= $cupmark;
		}
	}
	print "<br><table border=1 width=$width cellspacing=0 cellpadding=5><tr align=center><th><big><big>$league[1]</big></big></th></tr>\n";
	print "<tr><td align=center><table><tr><td align=center><font color=#ffc0cd><big><b>NOW<br>CHAMPION</b></big></font><small>$rensho</small></td><td><table><tr><td rowspan=2>$icon_pri</td><td>$cup_pri</td></tr><tr><td><b><font color=$text1><big><big>$w_teamname</big></big></font></b>($w_owner)</td></tr></table></td></tr></table></tr></td></tr>\n";
	if($ma_rensho2 > 1){
#			my $icon_pri="<img src=$icondir/$ma_icon2.gif align=middle>" if $icon_use;
		print <<"_EOF_";
<tr align=center>
	<td><small>현재의 연승 기록：<font color=$text1><big><b>$ma_teamname2</b></big></font>($ma_owner2)의<font color=$text1><big>$ma_rensho2</big></font>연승</small></td>
</tr>
_EOF_
	}
	print "</table>\n";
	print "<table align=center width=$width><tr><td width=40% valign=top>\n";
	print "<br><table border=1 cellspacing=0 cellpadding=5 width=100%><caption><big><b>- 최근 3 시합의 결과 -</b></big></captin><tr><td><small>\n";
	my @kekka = &load("$dir[1]/$logdir/$kekkalog");
	foreach(@kekka){
		&split("kekka","$_");
		my $log_date = &get_date("$log_date");
		print "$log_date<br><a href=$mainfile?result=part&filename=$muchlog$log_no&class=div2><b>$log_card</b></a> <br>$log_result";
		print "<br>$log_cmt" if $log_cmt;
		print "<br><br>";
	}
	print "</dl></small></td></tr></table></td><td valign=top>\n";
	
	print "<br><table border=1 cellspacing=0 cellpadding=5 width=100%><caption><big><b>- 리그 랭킹 -</b></big></captin><tr align=center>\n";
	print "<td>순<br>위</td><td>팀명(HN)</td><td>시<br>합</td><td>승<br></td><td>패<br></td>";
	print "<td>인<br>분</td>" if $game_flg != 2;
	print "<td>승<br>점</td></tr>\n";
	my @ranking = &load("$dir[1]/$datadir/$rankingfile");
	$ii=0;
	foreach(@ranking){
		if($ii >= 5){last;}
		$ii++;
		&split("teamdata","$_");
		my $shiai = $win+$lose+$draw;
		if($ii == 1){
			my $icon_pri="<img src=$icondir/$icon.gif align=middle>" if $icon_use;
			my $cup_pri='';
			if($cup){
				$loop_count=0; # 루프 체크
				for($i=0; $i<$cup; $i++){
					&loop_check; # 루프 체크
					if(0 == $i%10 && $i != 0){$cup_pri .= "<br>";}
					$cup_pri .= $cupmark;
				}
			}
			print "<tr align=right><td align=center><big><b>$ii</b></big></td><td align=center><table cellspacing=0 cellpadding=0 width=100%><tr><td rowspan=2>$icon_pri</td><td>$cup_pri</td></tr><tr><td><big><b>$teamname</b></big><br>($owner)</td></tr></table></td><td>$shiai</td><td>$win</td><td>$lose</td>";
		}else{
			print "<tr align=right><td align=center>$ii</td><td align=left>$teamname<br><small>($owner)</small></td><td>$shiai</td><td>$win</td><td>$lose</td>";
		}
		print "<td>$draw</td>" if $game_flg != 2;
		print "<td>$win_p</td></tr>";
	}
	print "</table>";
	print "</td></tr></table>";
	&footer;
	
}#END top

#----------------------#
#	파라미터 체크	#
#----------------------#(21까지 사용중)
sub para_check {
	
	local @checker=();
	for($i=0; $i<11; $i++){
		if($form{"player$i"} eq ""){$checker[0]=1;}
		if(length($form{"player$i"}) > $nameleng*2){$checker[1]=1;}
		$loop_count=0; # 루프 체크
		for($ii=0; $ii<$i; $ii++){
			&loop_check; # 루프 체크
			if($form{"player$i"} eq $form{"player$ii"}){$checker[2]=1; last;}
		}
		if($form{"posi$i"} eq "GK"){$checker[3]++;}
		elsif($form{"posi$i"} eq "DF"){$checker[4]=1;}
		elsif($form{"posi$i"} eq "DMF"){$checker[5]=1;}
		elsif($form{"posi$i"} eq "OMF"){$checker[6]=1;}
		elsif($form{"posi$i"} eq "FW"){$checker[7]=1;}
		if($form{"fk$i"} eq "○"){$checker[8]=1;}
		if($form{"pk$i"} eq "○"){$checker[9]=1;}
		$para1[$i] = $form{"pass$i"}+$form{"plus1$i"};
		if($para1[$i]>10 || $para1[$i]<1){$checker[14]=1;}
		$para2[$i] = $form{"dori$i"}+$form{"plus2$i"};
		if($para2[$i]>10 || $para2[$i]<1){$checker[14]=1;}
		$para3[$i] = $form{"shoo$i"}+$form{"plus3$i"};
		if($para3[$i]>10 || $para3[$i]<1){$checker[14]=1;}
		$para4[$i] = $form{"defe$i"}+$form{"plus4$i"};
		if($para4[$i]>10 || $para4[$i]<1){$checker[14]=1;}
		my $total = $para1[$i]+$para2[$i]+$para3[$i]+$para4[$i];
		$checker[10] += $total;
		if($para_min > $total || $total > $para_max){$checker[11]=1;}
		if($para1[$i] >= 8 && $para1[$i] <= 9){$checker[12]++;}
		if($para2[$i] >= 8 && $para2[$i] <= 9){$checker[12]++;}
		if($para3[$i] >= 8 && $para3[$i] <= 9){$checker[12]++;}
		if($para4[$i] >= 8 && $para4[$i] <= 9){$checker[12]++;}
		if($para1[$i] >= 10){$checker[13]++;}
		if($para2[$i] >= 10){$checker[13]++;}
		if($para3[$i] >= 10){$checker[13]++;}
		if($para4[$i] >= 10){$checker[13]++;}
	}
	if($form{tac_zp}+$form{tac_ca}+$form{tac_pp} != 100){$checker[20]=1;}
	if($form{tac_vszp}+$form{tac_vsca}+$form{tac_vspp} != 100){$checker[21]=1;}
	if($form{tac_zp} < 0 || $form{tac_ca} < 0 || $form{tac_pp} < 0 || $form{tac_vszp} < 0 || $form{tac_vsca} < 0 || $form{tac_vspp} < 0){$checker[15]=1;}
	if(length($form{teamname}) > $nameleng*2){$checker[16]=1;}
	if(length($form{owner}) > $nameleng*2){$checker[17]=1;}
	&dir_check("1");
	$err_cmt .= "·팀명이 미입력입니다<br>\n" if ! $form{teamname};
	$err_cmt .= "·팀명이 전각<b>$nameleng</b>자 이상이 되어 있습니다<br>\n" if $checker[16]==1;
	$err_cmt .= "·이 팀명은 벌써 사용되고 있습니다<br>\n" if $checker[18]==1;
	$err_cmt .= "·당신의 이름이 미입력입니다<br>\n" if ! $form{owner};
	$err_cmt .= "·당신의 이름이 전각<b>$nameleng</b>자 이상이 되어 있습니다<br>\n" if $checker[17]==1;
	$err_cmt .= "·이 이름은 벌써 사용되고 있습니다<br>\n" if $checker[19]==1;
	$err_cmt .= "·기본 전술이 미선택입니다<br>\n" if ! $form{tac};
	$err_cmt .= "·공격 전술 포인트의 합계가<b>100</b>이 되지 않았습니다<br>\n" if $checker[20]==1;
	$err_cmt .= "·수비 전술 포인트의 합계가<b>100</b>이 되지 않았습니다<br>\n" if $checker[21]==1;
	$err_cmt .= "·전술 포인트가 마이너스가 되어 있습니다<br>\n" if $checker[15]==1;
	if($icon_use){$err_cmt .= "·아이콘이 미선택입니다<br>\n" if ! $form{icon};}
	my $nokori = $totpoint - $checker[10];
	$err_cmt .= "·현재의 합계는<b>$checker[10]</b>으로 나머지는<b>$nokori</b>입니다<br>\n" if $nokori;
	$err_cmt .= "·선수명이 미입력입니다<br>\n" if $checker[0]==1;
	$err_cmt .= "·선수명이 전각<b>$nameleng</b>자 이상이 되어 있습니다<br>\n" if $checker[1]==1;
	$err_cmt .= "·같은 선수명이 있습니다<br>\n" if $checker[2]==1;
	$err_cmt .= "·GK는 1명 뿐입니다<br>\n" if $checker[3]>1;
	$err_cmt .= "·GK가 없습니다<br>\n" if $checker[3]<1;
	$err_cmt .= "·DF가 없습니다<br>\n" if $checker[4]!=1;
	$err_cmt .= "·DMF가 없습니다<br>\n" if $checker[5]!=1;
	$err_cmt .= "·OMF가 없습니다<br>\n" if $checker[6]!=1;
	$err_cmt .= "·FW가 없습니다<br>\n" if $checker[7]!=1;
	$err_cmt .= "·FK·CK의 킥커가 지정되지 않았습니다<br>\n" if $checker[8]!=1;
	$err_cmt .= "·PK의 킥커가 지정되지 않았습니다<br>\n" if $checker[9]!=1;
	$err_cmt .= "·선수마다의 파라미터의 합계가<b>$para_min</b>~<b>$para_max</b>가 되지 않았습니다<br>\n" if $checker[11]==1;
	$err_cmt .= "·파라미터 8~9의 수는<b>$eight_max</b>개설정해 주세요<br>\n" if $checker[12]!=$eight_max;
	$err_cmt .= "·파라미터 10의 수는<b>$ten_max</b>개설정해 주세요<br>\n" if $checker[13]!=$ten_max;
	$err_cmt .= "·선수의 각 파라미터는 1~10이 되도록 해 주세요<br>\n" if $checker[14];
	$para_check_end = 1;
	$form{making} = $form{pastmake} eq "" ?  "" : $form{pastmake};
	
}#END para_check

#--------------------#
#	파라미터 세트	#
#--------------------#
sub para_set {
	
	$teamname = $form{teamname};
	$owner = $form{owner};
	$tac = $form{tac};
	$tac_zp = $form{tac_zp};
	$tac_ca = $form{tac_ca};
	$tac_pp = $form{tac_pp};
	$tac_vszp = $form{tac_vszp};
	$tac_vsca = $form{tac_vsca};
	$tac_vspp = $form{tac_vspp};
	$icon = $form{icon} if $icon_use;
	for($i=0; $i<11; $i++) {
		$posi[$i] = $form{"posi$i"};
		$p_name[$i] = $form{"player$i"};
		$pass[$i] = $form{"pass$i"};
		$dori[$i] = $form{"dori$i"};
		$shoo[$i] = $form{"shoo$i"};
		$defe[$i] = $form{"defe$i"};
		$plus1[$i] = $form{"plus1$i"};
		$plus2[$i] = $form{"plus2$i"};
		$plus3[$i] = $form{"plus3$i"};
		$plus4[$i] = $form{"plus4$i"};
		$fk[$i] = $form{"fk$i"};
		$pk[$i] = $form{"pk$i"};
		$style[$i] = $form{"style$i"};
		$fair[$i] = $form{"fair$i"};
	}
	
}#END para_set

#------------------#
#	팀 신규 등록	#
#------------------#
sub regist {
	
	&para_check;
	&error("파라미터 에러입니다") if $err_cmt ne "";
	my $remote_host = &get_host;
	my $regist_time = $times-($between*60);
	my @users=();
	$users[0] = "$form{id}<>$form{password}<>$form{owner}<>$form{teamname}<>$form{tac}<>$form{tac_zp}<>$form{tac_ca}<>$form{tac_pp}<>$form{tac_vszp}<>$form{tac_vsca}<>$form{tac_vspp}<>$form{icon}<>$regist_time<>0<>0<>0<>0<>0<>0<>0<>0<>0<>0<>$remote_host<>\n";
	for($i=0; $i<11; $i++) {
		$users[$i+1] = qq|$form{teamname}<>$form{"player$i"}<>$form{"posi$i"}<>$form{"pass$i"}<>$form{"dori$i"}<>$form{"shoo$i"}<>$form{"defe$i"}<>$form{"fk$i"}<>$form{"pk$i"}<>$form{"style$i"}<>$form{"fair$i"}<>0<>000<>5<>\n|;
	}
	&write("$dir[1]/$teamdir/$form{id}.dat",@users);
	
	# 현재의 승리자가 없을 때의 기입
	if(-z "$dir[1]/$datadir/$winnerfile"){&write("$dir[1]/$datadir/$winnerfile","$form{id}<>$form{teamname}<>$form{owner}<>$form{icon}<>0<>0<>도전자 모집중♪<>$remote_host<>\n");}
	
	&set_cookie;
	&header;
	print <<"_END_";
<h2>신규 등록이 완료했습니다</h2>
<hr>
<div align=left>
<a href="$homeurl">$home</a> / 
<a href="$mainfile?login=LOGIN&id=$form{id}&password=$form{password}">로그인 화면에</a>  / 
<a href="$mainfile">TOP에</a> 
</div>
<hr>
</body>
</html>
_END_
	
}#END regist

#----------------#
#	신규 등록 화면	#
#----------------#
sub make {
	
	my $browser = 1 if $ENV{HTTP_USER_AGENT} =~ /MSIE/i;
	&header;
	&menu;
	print "<form action=$mainfile method=$method>\n";
	print "<h2>신규 등록</h2>\n";
	print "<table width=$width align=center border=1><tr><td width=25% align=center>에러 코멘트<br><input type=submit name=make_check value=파라미터체크></td><td align=left>\n";
	print "파라미터 에러는 없습니다<input type=submit name=regist value=이것으로등록>\n" if $err_cmt eq "" && $para_check_end == 1;
	$err_cmt = $form{err_cmt} if $para_check_end!=1;
	$err_cmt =~ s/&lt;br&gt;/<br>/g; $err_cmt =~ s/&lt;b&gt;/<b>/g; $err_cmt =~ s/&lt;\/b&gt;/<\/b>/g; # 역디코드(^^;
	print "$err_cmt";
	print "</td></tr></table><br>\n";
	print "<input type=hidden name=pastmake value=$form{making}>\n";
	print "<input type=hidden name=id value=$form{id}>\n";
	print "<input type=hidden name=password value=$form{password}>\n";
	print "<input type=hidden name=err_cmt value='$err_cmt'>\n";
	if($browser){
		print "<input type=hidden name=making value=team><input type=submit name=make value='팀 파라미터를 변경한다'><br><br>\n" if $form{making} ne "team";
		print "<input type=hidden name=making value=para><input type=submit name=make value='선수 파라미터를 변경한다'><br><br>\n" if $form{making} ne "para";
	}
	print "<table width=$width align=center border=1>\n";
	print "<tr><th width=25%>I　D</th><td>$form{id}</td>\n";
	$form = $form{making} eq "team" || !$browser ? "<input type=text name=tac_zp size=2 value=$tac_zp>" : "$tac_zp<input type=hidden name=tac_zp value=$tac_zp>";
	print "<td colspan=3 align=center><small>각각 전부 100이 되도록 할당해 주세요</small></td></tr>\n";
	print "<tr><th>패스워드</th><td>$form{password}</td>\n";
	print "<th width=13% rowspan=3>공격 전술<br>포인트</th><td nowrap>존 프레스</td><td>$form</td></tr>\n";
	
	if($icon_use){
		my @iconlist=();
		if(!@icon){
			opendir(DIR,"$icondir") or die "오픈 에러($icondir)<br>$!";
			@icon = grep !/^\.\.?$|\.htm/,readdir(DIR);
			closedir(DIR);
			foreach(@icon){for($i=0; $i<=3; $i++){chop;}}
		}
		foreach(@icon){
			if($_ eq $icon){push @iconlist,"<option value=$_ selected>$_</option>\n";}
			else{push @iconlist,"<option value=$_>$_</option>\n";}
		}
		$form = $form{making} eq "team" || !$browser ? "<select name=icon>@iconlist</select>" : "$icon<input type=hidden name=icon value=$icon>";
		print "<tr><th width=25% rowspan=2>아이콘<br><small><a href=$mainfile?iconlist=1 target=_blank>(아이콘 일람)</a> </small></th><td rowspan=2>$form</td>\n";
	}else{print "<tr><th width=25% rowspan=2>아이콘</th><td rowspan=2>미사용</td>\n";}
	
	$form = $form{making} eq "team" || !$browser ? "<input type=text name=tac_ca size=2 value=$tac_ca>" : "$tac_ca<input type=hidden name=tac_ca value=$tac_ca>";
	print "<td nowrap>카운터</td><td>$form</td></tr>\n";
	
	$form = $form{making} eq "team" || !$browser ? "<input type=text name=tac_pp size=2 value=$tac_pp>" : "$tac_pp<input type=hidden name=tac_pp value=$tac_pp>";
	print "<td nowrap>포스트플레이</td><td>$form</td></tr>\n";
	
	$form = $form{making} eq "team" || !$browser ? "<input type=text name=teamname size=20 value=$teamname>" : "$teamname<input type=hidden name=teamname value=$teamname>";
	print "<tr><th>팀의 이름</th><td>$form</td>\n";
	
	$form = $form{making} eq "team" || !$browser ? "<input type=text name=tac_vszp size=2 value=$tac_vszp>" : "$tac_vszp<input type=hidden name=tac_vszp value=$tac_vszp>";
	print "<th width=13% rowspan=3>수비 전술<br>포인트</th><td nowrap>민첩한 패스 워크</td><td>$form</td></tr>\n";
	
	$form = $form{making} eq "team" || !$browser ? "<input type=text name=owner size=20 value=$owner>" : "$owner<input type=hidden name=owner value=$owner>";
	print "<tr><th>당신의 이름</th><td>$form</td>\n";
	
	$form = $form{making} eq "team" || !$browser ? "<input type=text name=tac_vsca size=2 value=$tac_vsca>" : "$tac_vsca<input type=hidden name=tac_vsca value=$tac_vsca>";
	print "<td nowrap>카운터 경계</td><td>$form</td></tr>\n";
	
	my @list=&list("$tac", qw(밸런스중시 공격중시 수비중시));
	$form = $form{making} eq "team" || !$browser ? "<select name=tac>@list</select>" : "$tac<input type=hidden name=tac value=$tac>";
	print "<tr><th>기본 전술</th><td>$form</td>\n";
	
	$form = $form{making} eq "team" || !$browser ? "<input type=text name=tac_vspp size=2 value=$tac_vspp>" : "$tac_vspp<input type=hidden name=tac_vspp value=$tac_vspp>";
	print "<td nowrap>포스트플레이어 마크</td><td>$form</td></tr>\n";
	
	print "</table><br>\n";
	
	print <<"_EOF_";
<table border=1 width=$width align=center><tr align=center>
	<th>포<br>지<br>션</th><th>선<br>수<br>명<br></th><th>패<br>스</th><th>드<br>리<br>블</th><th>슛</th><th>수<br>비<br>력</th><th>FK<br>·<br>CK</th><th>P<br>K</th><th>스<br>타<br>일</th><th>난<br>폭<br>함<br></th></tr>
_EOF_

	for($i=0; $i<11; $i++){
		print "<tr align=center>\n";
		my @list = &list("$posi[$i]",qw(GK DF DMF OMF FW));
		$form = $form{making} eq "team" || !$browser ? "<select name=posi$i>@list</select>" : "$posi[$i]<input type=hidden name=posi$i value=$posi[$i]>";
		print "<td>$form</td>\n";
		
		$form = $form{making} eq "team" || !$browser ? "<input type=text name=player$i size=20 value=$p_name[$i]>" : "$p_name[$i]<input type=hidden name=player$i value=$p_name[$i]>";
		print "<td>$form</td>\n";
		
		my @list = &list("$pass[$i]",(1..10));
		$form = $form{making} eq "para" || !$browser ? "<select name=pass$i>@list</select>" : "$pass[$i]<input type=hidden name=pass$i value=$pass[$i]>";
		print "<td>$form</td>\n";
		
		my @list = &list("$dori[$i]",(1..10));
		$form = $form{making} eq "para" || !$browser ? "<select name=dori$i>@list</select>" : "$dori[$i]<input type=hidden name=dori$i value=$dori[$i]>";
		print "<td>$form</td>\n";
		
		my @list = &list("$shoo[$i]",(1..10));
		$form = $form{making} eq "para" || !$browser ? "<select name=shoo$i>@list</select>" : "$shoo[$i]<input type=hidden name=shoo$i value=$shoo[$i]>";
		print "<td>$form</td>\n";
		
		my @list = &list("$defe[$i]",(1..10));
		$form = $form{making} eq "para" || !$browser ? "<select name=defe$i>@list</select>" : "$defe[$i]<input type=hidden name=defe$i value=$defe[$i]>";
		print "<td>$form</td>\n";
		
		$check = $fk[$i] ? "<input type=checkbox name=fk$i value=○ checked>" : "<input type=checkbox name=fk$i value=○>";
		$form = $form{making} eq "team" || !$browser ? $check : "$fk[$i]<input type=hidden name=fk$i value=$fk[$i]>";
		print "<td>$form</td>\n";
		
		$check = $pk[$i] ? "<input type=checkbox name=pk$i value=○ checked>" : "<input type=checkbox name=pk$i value=○>";
		$form = $form{making} eq "team" || !$browser ? $check : "$pk[$i]<input type=hidden name=pk$i value=$pk[$i]>";
		print "<td>$form</td>\n";
		
		my @list = &list("$style[$i]",(1..9));
		$form = $form{making} eq "team" || !$browser ? "<select name=style$i>@list</select>" : "$style[$i]<input type=hidden name=style$i value=$style[$i]>";
		print "<td>$form</td>\n";
		
		my @list = &list("$fair[$i]",(1..9));
		$form = $form{making} eq "team" || !$browser ? "<select name=fair$i>@list</select>" : "$fair[$i]<input type=hidden name=fair$i value=$fair[$i]>";
		print "<td>$form</td></tr>\n";
	}
	print "</table><br></form>\n";
	
}#END make

#--------------------#
#	신규 등록 체크	#
#--------------------#
sub regist_check {
	
	if($form{id} =~ m/[^0-9a-zA-Z]/){&error("ID에 반각영숫자 이외의 문자가 포함되어 있습니다");}
	if($form{password} =~ m/[^0-9a-zA-Z]/){&error("패스워드에 반각영숫자 이외의 문자가 포함되어 있습니다");}
	if($form{id} eq "" or length($form{id})<4 or length($form{id})>8){&error("ID는<b>4</b>문자 이상<b>8</b>문자 이하로 입력해 주세요");}
	if($form{password} eq "" or length($form{password})<4 or length($form{password})>8){&error("패스워드는<b>4</b>문자 이상<b>8</b>문자 이하로 입력해 주세요");}
	my $remote_host = &get_host;
	&dir_check("2");
	
	$teamname = "";
	$owner = "";
	$tac = "밸런스중시";
	$tac_zp = 40;
	$tac_ca = 30;
	$tac_pp = 30;
	$tac_vszp = 40;
	$tac_vsca = 30;
	$tac_vspp = 30;
	$icon = "? " if $icon_use;
	for($i=0; $i<11; $i++) {
		push @posi,"? ";
		push @p_name,"";
		push @pass,5;
		push @dori,5;
		push @shoo,5;
		push @defe,5;
		push @fk,"";
		push @pk,"";
		push @style,5;
		push @fair,5;
	}
	$form{making} = "team";
	
}#END regist_check

#----------------#
#	아이콘 일람	#
#----------------#
sub iconlist {
	
	if(!@icon){
		opendir(DIR,"$icondir") or die "오픈 에러($icondir)<br>$!";
		@icon = grep !/^\.\.?$|\.htm/,readdir(DIR);
		closedir(DIR);
		foreach(@icon){for($i=0; $i<=3; $i++){chop;}}
	}
	
	&header;
	print "<b>브라우저의 「돌아온다」버튼으로 돌아와♪</b><br><br>";
	print "<table border=1 width=$width>";
	$i=0; $ii=0;
	my $end_flg = 0;
	until($end_flg == 1){
		print "<tr align=center>";
		foreach(1..$icon_view){
			print "<td>$icon[$ii]</td>";
			$ii++;
			if($icon[$ii] eq ""){$end_flg = 1; last;}
		}
		print "</tr><tr align=center>";
		foreach(1..$icon_view){
			print "<td><img src=$icondir/$icon[$i].gif align=middle></td>";
			$i++;
			if($icon[$i] eq ""){$end_flg = 1; last;}
		}
		print "</tr>";
	}
	print "</table>";
	&footer;
	
}#END iconlist

#----------------#
#	현재 순위 출력	#
#----------------#
sub rank {
	
	local $rank = 0;
	$form{class} = 0;
	foreach(@dir){
		&rank_check("$_");
		if($rank){last;}
	}
	&error("ID가 잘못되어 있는") if !$rank;
	return $rank;
	
}#END rank

#----------------#
#	현재 순위 확인	#
#----------------#
sub rank_check {
	
	my(@teams,@t_sortkey1,@t_sortkey2,@t_sortkey3,@t_sortkey4);
	opendir(DIR,"$_[0]/$teamdir") or die "오픈 에러($_[0]/$teamdir)<br>$! ";
	my @teamdata = grep !/^\.\.?$|\.htm/,readdir(DIR);
	closedir(DIR);
	foreach(@teamdata){
		if($_ eq "$form{id}.dat"){
			my @users = &load("$_[0]/$teamdir/$_");
			&split("teamdata","$users[0]");
			&error("패스워드가 잘못되어 있는") if $form{password} ne $password;
			$form{class}=$_[0];
			foreach(@teamdata){
				my @users = &load("$form{class}/$teamdir/$_");
				&split("teamdata","$users[0]");
				push(@teams,$users[0]);
				my $sortkey = $win+$lose+$draw == 0 ? 0 : 1;
				push(@t_sortkey1,$sortkey);
				push(@t_sortkey2,$win_p);
				push(@t_sortkey3,($sotokuten-$soshiten));
				push(@t_sortkey4,$sotokuten);
			}
			my @team_rank = @teams[sort {$t_sortkey1[$b] <=> $t_sortkey1[$a] or	$t_sortkey2[$b] <=> $t_sortkey2[$a] or	$t_sortkey3[$b] <=> $t_sortkey3[$a] or	$t_sortkey4[$b] <=> $t_sortkey4[$a]} 0 .. $#t_sortkey1];
			foreach(@team_rank){
				&split("teamdata","$_");
				$rank++;
				if($form{id} eq $id){last;}
			}
			last;
		}
	}
	
}#END rank_check

#----------------#
#	로그인 화면	#
#----------------#
sub login {
	
	if($form{rank} eq ""){
		$form{rank} = &rank;
		my @users = &load("$form{class}/$teamdir/$form{id}.dat");
		&split("teamdata","$users[0]");
		for($i=0; $i<11; $i++){&split("playersdata","$users[$i+1]"); $plus1[$i]=$plus2[$i]=$plus3[$i]=$plus4[$i]=0;}
		$form{making} = "para";
	}else{
		my @users = &load("$form{class}/$teamdir/$form{id}.dat");
		&split("teamdata","$users[0]");
		for($i=0; $i<11; $i++){&split("playersdata","$users[$i+1]");}
		&para_set;
	}
	my $league_name = $form{class} eq $dir[0] ? $league[0] : $league[1];
	my $game = $win+$lose+$draw;
	my $game_nokori = $league_game-$game;
	$game_nokori = "시즌 종료" if $game_nokori<=0;
	my $icon_pri = "<img src=$icondir/$icon.gif align=middle>" if $icon_use;
	if($cup){
		$loop_count=0; # 루프 체크
		for($i=0; $i<$cup; $i++){
			&loop_check; # 루프 체크
			if(0 == $i%10 && $i != 0){$cup_pri .= "<br>";}
			$cup_pri .= $cupmark;
		}
	}
	my @condition=();
	for($i=0; $i<11; $i++){
		if($cond[$i] >= 8){$condition[$i]="절호<br><img src='icon/cond_bar5.gif'>";}
		elsif($cond[$i] >= 6 && $cond[$i] < 8){$condition[$i]="호조<br><img src='icon/cond_bar4.gif'>";}
		elsif($cond[$i] >= 4 && $cond[$i] < 6){$condition[$i]="보통<br><img src='icon/cond_bar3.gif'>";}
		elsif($cond[$i] >= 2 && $cond[$i] < 4){$condition[$i]="나쁨<br><img src='icon/cond_bar2.gif'>";}
		elsif($cond[$i] < 2){$condition[$i]="최악<br><img src='icon/cond_bar1.gif'>";}
	}
	
	my $browser = 1 if $ENV{HTTP_USER_AGENT} =~ /MSIE/i;
	&header;
	&menu;
	print "<form action=$mainfile method=$method>\n";
	if($game_flg == 1){$tmp = 10;}
	elsif($game_flg == 2){$tmp = 11;}
	elsif(!$game_flg){$tmp = 9;}
	print <<"_EOF_";
<table border=1 width=$width>
	<tr><th colspan=$tmp><big>$league_name</big></th></tr>
	<tr><th>시합</th><th>승리</th>
_EOF_
	print "<th>연장승</th>" if $game_flg;
	print "<th>PK승</th>" if $game_flg == 2;
	print <<"_EOF_";
<th>패배</th><th>무승부</th><th>연승</th><th>총득점</th><th>총실점</th><th>남은시합</th><th>순위</th></tr>
	<tr align=center><td>$game</td><td>$win</td>
_EOF_
	print "<td><small>($win1)</small></td>" if $game_flg;
	print "<td><small>($win2)</small></td>" if $game_flg == 2;
	print <<"_EOF_";
<td>$lose</td><td>$draw</td><td>$winmax</td><td>$sotokuten</td><td>$soshiten</td><td>$game_nokori</td><td><b>$form{rank}</b></td></tr>
</table>
<br>
_EOF_
	print "<table width=$width align=center border=1><tr><td width=25% align=center>에러 코멘트<br><input type=submit name=login_check value=파라미터체크></td><td align=left>\n";
	if($err_cmt eq "" && $para_check_end == 1 || $form{login} eq "LOGIN"){
		if($game >= $league_game){
			print "지금 시즌은 전일정($league_game)을 종료했던 \n";
		}elsif(($times-$date) < $between*60){
			my $nexttimes	= $date+($between+1) *60-$times;
			my $nextminits = int($nexttimes/60);
			print "다음의 시합까지 나머지$nextminits분 정도 기다려 주세요 m(_ _) m\n";
		}else{
			print "파라미터 에러는 없습니다<input type=submit name=kickoff value=시합개시>\n";
		}
	}
	$err_cmt = $form{err_cmt} if $para_check_end!=1;
	$err_cmt =~ s/&lt;br&gt;/<br>/g; $err_cmt =~ s/&lt;b&gt;/<b>/g; $err_cmt =~ s/&lt;\/b&gt;/<\/b>/g; # 역디코드(^^;
	print "$err_cmt";
	print "</td></tr></table><br>\n";
	print "<input type=hidden name=pastmake value=$form{making}>\n";
	print "<input type=hidden name=id value=$form{id}>\n";
	print "<input type=hidden name=password value=$form{password}>\n";
	print "<input type=hidden name=teamname value=$teamname>\n";
	print "<input type=hidden name=owner value=$owner>\n";
	print "<input type=hidden name=icon value=$icon>\n" if $icon_use;
	print "<input type=hidden name=rank value=$form{rank}>\n";
	print "<input type=hidden name=class value=$form{class}>\n";
	print "<input type=hidden name=err_cmt value='$err_cmt'>\n";
	if($browser){
		print "<input type=hidden name=making value=team><input type=submit name=login value='팀 파라미터를 변경한다'><br><br>\n" if $form{making} ne "team";
		print "<input type=hidden name=making value=para><input type=submit name=login value='선수 파라미터를 변경한다'><br><br>\n" if $form{making} ne "para";
	}
	&id_conv("$form{id}");
	print "<table width=$width align=center border=1>\n";
	print "<tr><td width=50% rowspan=6 colspan=2 align=center><table cellspacing=0 cellpadding=0><tr><td rowspan=2>$icon_pri</td><td>$cup_pri</td></tr><tr><td><a href=$mainfile?log_view=konkai&id=$crypt_id&teamname=$teamname target=_blank>$teamname</a> <br>($owner)</td></tr></table></td>\n";
	$form = $form{making} eq "team" || !$browser ? "<input type=text name=tac_zp size=2 value=$tac_zp>" : "$tac_zp<input type=hidden name=tac_zp value=$tac_zp>";
	print "<td colspan=3 align=center><small>각각 전부 100이 되도록 할당해 주세요</small></td></tr>\n";
	print "<th width=13% rowspan=3>공격 전술<br>포인트</th><td nowrap>존 프레스</td><td>$form</td></tr>\n";
	$form = $form{making} eq "team" || !$browser ? "<input type=text name=tac_ca size=2 value=$tac_ca>" : "$tac_ca<input type=hidden name=tac_ca value=$tac_ca>";
	print "<td nowrap>카운터</td><td>$form</td></tr>\n";
	$form = $form{making} eq "team" || !$browser ? "<input type=text name=tac_pp size=2 value=$tac_pp>" : "$tac_pp<input type=hidden name=tac_pp value=$tac_pp>";
	print "<td nowrap>포스트플레이</td><td>$form</td></tr>\n";
	$form = $form{making} eq "team" || !$browser ? "<input type=text name=tac_vszp size=2 value=$tac_vszp>" : "$tac_vszp<input type=hidden name=tac_vszp value=$tac_vszp>";
	print "<th width=13% rowspan=3>수비 전술<br>포인트</th><td nowrap>민첩한 패스 워크</td><td>$form</td></tr>\n";
	$form = $form{making} eq "team" || !$browser ? "<input type=text name=tac_vsca size=2 value=$tac_vsca>" : "$tac_vsca<input type=hidden name=tac_vsca value=$tac_vsca>";
	print "<td nowrap>카운터 경계</td><td>$form</td></tr>\n";
	
	my @list=&list("$tac", qw(밸런스중시 공격중시 수비중시));
	$form = $form{making} eq "team" || !$browser ? "<select name=tac>@list</select>" : "$tac<input type=hidden name=tac value=$tac>";
	print "<th>기본 전술</th><td>$form</td>\n";
	$form = $form{making} eq "team" || !$browser ? "<input type=text name=tac_vspp size=2 value=$tac_vspp>" : "$tac_vspp<input type=hidden name=tac_vspp value=$tac_vspp>";
	print "<td nowrap>포스트플레이어 마크</td><td>$form</td></tr></table><br>\n";
	
	print <<"_EOF_";
<table border=1 width=$width align=center><tr align=center>
	<th>포<br>지<br>션</th><th>선<br>수<br>명<br></th><th>패<br>스</th><th>드<br>리<br>블</th><th>슛</th><th>수<br>비<br>력</th><th>FK<br>·<br>CK</th><th>P<br>K</th><th>스<br>타<br>일</th><th>난<br>폭<br>함</th><th>득<br>점</th><th>상<br>태</th><th>평<br>가<br>점</th></tr>
_EOF_
	for($i=0; $i<11; $i++){
		print "<tr align=center>\n";
		my @list = &list("$posi[$i]",qw(GK DF DMF OMF FW));
		$form = $form{making} eq "team" || !$browser ? "<select name=posi$i>@list</select>" : "$posi[$i]<input type=hidden name=posi$i value=$posi[$i]>";
		print "<td>$form</td>\n";
		print "<td>$p_name[$i]<input type=hidden name='player$i' value=$p_name[$i]></td>\n";
		
		my @list = &list("$plus1[$i]",(0,1,-1));
		$form = $form{making} eq "para" || !$browser ? "<select name=plus1$i>@list</select>" : "<b>$plus1[$i]</b><input type=hidden name=plus1$i value=$plus1[$i]>";
		print "<td>$form<br>";
		print "<input type=hidden name=pass$i value=$pass[$i]>\n";
		if($pass[$i]<=7){print "($pass[$i])</td>\n";}
		elsif($pass[$i]>=8 && $pass[$i]<=9){print "(<font color=$text2>$pass[$i]</font>)</td>\n";}
		else{print "(<font color=$text1>$pass[$i]</font>)</td>\n";}
		
		my @list = &list("$plus2[$i]",(0,1,-1));
		$form = $form{making} eq "para" || !$browser ? "<select name=plus2$i>@list</select>" : "<b>$plus2[$i]</b><input type=hidden name=plus2$i value=$plus2[$i]>";
		print "<td>$form<br>";
		print "<input type=hidden name=dori$i value=$dori[$i]>\n";
		if($dori[$i]<=7){print "($dori[$i])</td>\n";}
		elsif($dori[$i]>=8 && $dori[$i]<=9){print "(<font color=$text2>$dori[$i]</font>)</td>\n";}
		else{print "(<font color=$text1>$dori[$i]</font>)</td>\n";}
		
		my @list = &list("$plus3[$i]",(0,1,-1));
		$form = $form{making} eq "para" || !$browser ? "<select name=plus3$i>@list</select>" : "<b>$plus3[$i]</b><input type=hidden name=plus3$i value=$plus3[$i]>";
		print "<td>$form<br>";
		print "<input type=hidden name=shoo$i value=$shoo[$i]>\n";
		if($shoo[$i]<=7){print "($shoo[$i])</td>\n";}
		elsif($shoo[$i]>=8 && $shoo[$i]<=9){print "(<font color=$text2>$shoo[$i]</font>)</td>\n";}
		else{print "(<font color=$text1>$shoo[$i]</font>)</td>\n";}
		
		my @list = &list("$plus4[$i]",(0,1,-1));
		$form = $form{making} eq "para" || !$browser ? "<select name=plus4$i>@list</select>" : "<b>$plus4[$i]</b><input type=hidden name=plus4$i value=$plus4[$i]>";
		print "<td>$form<br>";
		print "<input type=hidden name=defe$i value=$defe[$i]>\n";
		if($defe[$i]<=7){print "($defe[$i])</td>\n";}
		elsif($defe[$i]>=8 && $defe[$i]<=9){print "(<font color=$text2>$defe[$i]</font>)</td>\n";}
		else{print "(<font color=$text1>$defe[$i]</font>)</td>\n";}
		
		$check = $fk[$i] ? "<input type=checkbox name=fk$i value=○ checked>" : "<input type=checkbox name=fk$i value=○>";
		$form = $form{making} eq "team" || !$browser ? $check : "$fk[$i]<input type=hidden name=fk$i value=$fk[$i]>";
		print "<td>$form</td>\n";
		$check = $pk[$i] ? "<input type=checkbox name=pk$i value=○ checked>" : "<input type=checkbox name=pk$i value=○>";
		$form = $form{making} eq "team" || !$browser ? $check : "$pk[$i]<input type=hidden name=pk$i value=$pk[$i]>";
		print "<td>$form</td>\n";
		my @list = &list("$style[$i]",(1..9));
		$form = $form{making} eq "team" || !$browser ? "<select name=style$i>@list</select>" : "$style[$i]<input type=hidden name=style$i value=$style[$i]>";
		print "<td>$form</td>\n";
		my @list = &list("$fair[$i]",(1..9));
		$form = $form{making} eq "team" || !$browser ? "<select name=fair$i>@list</select>" : "$fair[$i]<input type=hidden name=fair$i value=$fair[$i]>";
		print "<td>$form</td>\n";
		print "<td>$score[$i]</td>\n";
		print "<td>$condition[$i]</td>\n";
		$hyoka[$i] = sprintf("%.2f",$hyoka[$i]/100);
		print "<td>$hyoka[$i]</td></tr>";
	}
	print "</table><br></form>\n";
	&menu;
	&footer;
	
}#END login

#----------------#
#	삭제 확인 화면	#
#----------------#
sub delete_check {
	
	if($league_day != 1){&error("삭제할 수 있는 것은 「첫날」 뿐입니다");}
	local $hit=0;
	&dir_check("3");
	if(!$hit){&error("ID가 잘못되어 있습니다");}
	
	&header;
	print <<"_END_";
<h2>삭제해 좋습니까? <br><br>($delete_team)</h2>
<hr><a href="$mainfile?delete=1&id=$form{id}&password=$form{password}">네</a>  / <a href="$mainfile">아니오</a> <hr>
</body>
</html>
_END_
	
}#END delete_check

#----------------#
#	삭제 확인 화면	#
#----------------#
sub delete {
	
	if($lockkey){&lock;}
	
	$ENV{'TZ'} = "GMT"; # 국제 표준시를 취득
	my($sec, $min, $hour, $day, $mon, $year, $wday, $yday, $isdst) =localtime(time-86400);
	$year += 1900;
	$mday	= sprintf("%02d",$mday);
	$hour	= sprintf("%02d",$hour);
	$min	= sprintf("%02d",$min);
	$sec	= sprintf("%02d",$sec);
	my $month = ('Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec')[$mon];
	my $youbi = ('Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday')[$wday];
	$ENV{'TZ'} = "Japan";
	my $delcookie = "$youbi, $day\-$month\-$year $hour:$min:$sec GMT";
	my $cookie="id<>$form{id}\,password<>$form{password}";
	print "Set-Cookie: SGSOCCER=$cookie; expires=$delcookie\n";
	
	local $hit=0;
	&dir_check("3");
	if(!$hit){&error("ID가 잘못되어 있습니다");}
	unlink "$class/$teamdir/$form{id}.dat";
	
	my @winner = &load("$class/$datadir/$winnerfile");
	&split("winnerdata","$winner[0]");
	if("$w_id" eq "$form{id}"){&write("$class/$datadir/$winnerfile","");}
	
	my $crypt_id = crypt($form{id},$form{id});
	&id_conv("$form{id}");
	if(-e "$tlogdir/konkai/$crypt_id.cgi"){unlink "$tlogdir/konkai/$crypt_id.cgi";}
	
	if($lockkey){&unlock;}
	
	&header;
	print <<"_END_";
<h2>삭제했습니다<br><br>($delete_team)</h2>
<hr><a href="$homeurl">$home</a>  / <a href="$mainfile">TOP에</a> <hr>
</body>
</html>
_END_
	
}#END delete

#------------------#
#	랭킹표시	#
#------------------#
sub ranking {
	
	&header;
	&menu;
	if($form{ranking} eq "team"){
		foreach(@dir){
			my $div = $_ eq $dir[0] ? 0 : 1;
			if(($league <= $ma_dai && $league) || $div){
				print <<"_EOF_";
<h2>$league[$div]랭킹</h2>
<table border=1 width=$width cellspacing=0>
<tr><th>순<br><br>위</th><th>팀명(HN)</th><th>시<br><br>합</th><th>승<br><br></th>
_EOF_
				print "<th>연<br>장<br>승</th>" if $game_flg;
				print "<th>P<br>K<br>승</th>" if $game_flg == 2;
				print <<"_EOF_";
<th>패<br><br></th><th>인<br><br>분</th><th>승<br><br>점</th><th>총<br>득<br>점</th><th>총<br>실<br>점</th><th>득<br>실<br>차</th></tr>
_EOF_
				my(@teams, @t_sortkey1, @t_sortkey2, @t_sortkey3, @t_sortkey4);
				opendir(DIR,"$dir[$div]/$teamdir") or die "오픈 에러($dir[$div]/$teamdir)<br>$! ";
				my @teamdata = grep !/^\.\.?$|\.htm/,readdir(DIR);
				closedir(DIR);
				foreach(@teamdata){
					my @users = &load("$dir[$div]/$teamdir/$_");
					push(@teams,$users[0]);
					&split("teamdata","$users[0]");
					my $sortkey = $win+$lose+$draw == 0 ? 0 : 1;
					push(@t_sortkey1,$sortkey);
					push(@t_sortkey2,$win_p);
					push(@t_sortkey3,($sotokuten-$soshiten));
					push(@t_sortkey4,$sotokuten);
				}
				my @team_rank = @teams[sort {$t_sortkey1[$b] <=> $t_sortkey1[$a] or	$t_sortkey2[$b] <=> $t_sortkey2[$a] or	$t_sortkey3[$b] <=> $t_sortkey3[$a] or	$t_sortkey4[$b] <=> $t_sortkey4[$a]} 0 .. $#t_sortkey1];
				$j=1;
				foreach(@team_rank){
					&split("teamdata","$_");
					my $shiai = $win+$lose+$draw;
					my $tokushitu = $sotokuten-$soshiten;
					my $icon_pri="<img src=$icondir/$icon.gif align=middle>" if $icon_use;
					my $cup_pri='';
					if($cup){
						$loop_count=0; # 루프 체크
						for($i=0; $i<$cup; $i++){
							&loop_check; # 루프 체크
							if(0 == $i%10 && $i != 0){$cup_pri .= "<br>";}
							$cup_pri .= $cupmark;
						}
					}
					print "<tr><td align=center><b>$j</b></td>";
					&id_conv("$id");
					if("$id" eq "$form{id}"){
						print "<td><table cellspacing=0 cellpadding=0><tr><td rowspan=2>$icon_pri</td><td>$cup_pri</td></tr><tr><td><font color=$text1><a href=$mainfile?log_view=konkai&id=$crypt_id&teamname=$teamname>$teamname</a> ($owner)</font></td></tr></table></td>";
						print "<td align=right><font color=$text1>$shiai</font></td>";
						print "<td align=right><font color=$text1>$win</font></td>";
						print "<td align=right><font color=$text1><small>($win1)</small></font></td>" if $game_flg;
						print "<td align=right><font color=$text1><small>($win2)</small></font></td>" if $game_flg == 2;
						print "<td align=right><font color=$text1>$lose</font></td>";
						print "<td align=right><font color=$text1>$draw</font></td>";
						print "<td align=right><font color=$text1><b>$win_p</b></font></td>";
						print "<td align=right><font color=$text1>$sotokuten</font></td>";
						print "<td align=right><font color=$text1>$soshiten</font></td>";
						print "<td align=right><font color=$text1>$tokushitu</font></td></tr>";
					}else{
						print "<td><table cellspacing=0 cellpadding=0><tr><td rowspan=2>$icon_pri</td><td>$cup_pri</td></tr><tr><td><a href=$mainfile?log_view=konkai&id=$crypt_id&teamname=$teamname>$teamname</a> ($owner)</td></tr></table></td>";
						print "<td align=right>$shiai</td>";
						print "<td align=right>$win</td>";
						print "<td align=right><small>($win1)</small></td>" if $game_flg;
						print "<td align=right><small>($win2)</small></td>" if $game_flg == 2;
						print "<td align=right>$lose</td>";
						print "<td align=right>$draw</td>";
						print "<td align=right><b>$win_p</b></td>";
						print "<td align=right>$sotokuten</td>";
						print "<td align=right>$soshiten</td>";
						print "<td align=right>$tokushitu</td></tr>";
					}
					$j++;
				}
				print "</table><br>";
			}
		}
	}elsif($form{ranking} eq "player"){
		foreach(@dir){
			my $div = $_ eq $dir[0] ? 0 : 1;
			if(($league <= $ma_dai && $league) || $div){
				my(@s_players, @h_players, @s_sortkey1, @h_sortkey1);
				opendir(DIR,"$dir[$div]/$teamdir") or die "오픈 에러($dir[$div]/$teamdir)<br>$! ";
				my @teamdata = grep !/^\.\.?$|\.htm/,readdir(DIR);
				closedir(DIR);
				foreach(@teamdata){
					my @users = &load("$dir[$div]/$teamdir/$_");
					&split("teamdata","$users[0]");
					for($i=1; $i<12; $i++){
						&split("playerdata","$users[$i]");
						if($score){
							push(@s_players,$users[$i]);
							push(@s_sortkey1,$score);
						}
						if(($win+$lose+$draw) >= $league_min){
							push(@h_players,$users[$i]);
							push(@h_sortkey1,$hyoka);
						}
					}
				}
				my @score_rank = @s_players[sort{$s_sortkey1[$b]<=>$s_sortkey1[$a]} 0 .. $#s_sortkey1];
				my @hyoka_rank = @h_players[sort{$h_sortkey1[$b]<=>$h_sortkey1[$a]} 0 .. $#h_sortkey1];
				print "<h2>$league[$div]랭킹</h2><small>($league_min 시합 소화 시점에서 랭킹에 반영됩니다)</small><br><br>";
				print "<table width=$width><tr><td width=50%>";
				print "<table border=1 width=100% cellspacing=0>";
				print "<tr><th colspan=2>득점왕랭킹</th></tr>";
				$i=0;
				foreach(@score_rank){
					&split("playerdata","$_");
					if($form{teamname} eq $shozoku){
						print "<tr><td><font color=$text1>$p_name($shozoku)</font></td><td align=right><font color=$text1>$score</font></td></tr>";
					}else{
						print "<tr><td>$p_name($shozoku)</td><td align=right>$score</td></tr>";
					}
					$i++;
					if($i >= 10){last;}
				}
				print "</table></td><td width=50%>";
				print "<table border=1 width=100% cellspacing=0>";
				print "<tr><th colspan=2>평가점랭킹</th></tr>";
				$i=0;
				foreach(@hyoka_rank){
					&split("playerdata","$_");
					$hyoka = sprintf("%.2f",$hyoka/100);
					if($form{teamname} eq $shozoku){
						print "<tr><td><font color=$text1>$p_name($shozoku)</font></td><td align=right><font color=$text1>$hyoka</font></td></tr>";
					}else{
						print "<tr><td>$p_name($shozoku)</td><td align=right>$hyoka</td></tr>";
					}
					$i++;
					if($i >= 10){last;}
				}
				print "</table></td></tr></table><br><table width=$width><tr><td width=50%>";
				&ranking_sub("GK",@hyoka_rank);
				print "</td><td width=50%>";
				&ranking_sub("DF",@hyoka_rank);
				print "</td></tr></table><br><table width=$width><tr><td width=50%>";
				&ranking_sub("DMF",@hyoka_rank);
				print "</td><td width=50%>";
				&ranking_sub("OMF",@hyoka_rank);
				print "</td></tr></table><br><table width=$width><tr><td width=50%>";
				&ranking_sub("FW",@hyoka_rank);
				print "</td><td></td></tr></table><br>";
			}
		}
	}elsif($form{ranking} eq "zenkai"){
		foreach(@dir){
			my $div = $_ eq $dir[0] ? 0 : 1;
			if(($league < $ma_dai && $league) || $div){
				$ze_dai = $ma_dai - 1;
				print <<"_EOF_";
<h2>$league[$div]랭킹( 제$ze_dai회)</h2>
<table border=1 width=$width cellspacing=0>
<tr><th>순<br><br>위</th><th>팀명(HN)</th><th>시<br><br>합</th><th>승<br><br></th>
_EOF_
				print "<th>연<br>장<br>승</th>" if $game_flg;
				print "<th>P<br>K<br>승</th>" if $game_flg == 2;
				print <<"_EOF_";
<th>패<br><br></th><th>인<br><br>분</th><th>승<br><br>점</th><th>총<br>득<br>점</th><th>총<br>실<br>점</th><th>득<br>실<br>차</th></tr>
_EOF_
				my @zenkai = &load("$dir[$div]/$datadir/$zenkaifile");
				my($cgk, $cdf, $cdmf, $comf, $cfw);
				$loop_count=0; # 루프 체크
				for($i=20; $i<@zenkai+1; $i++){
					&loop_check; # 루프 체크
					&split("playerdata","$zenkai[$i]");
					if($posi eq "GK"){$cgk++;}
					elsif($posi eq "DF" ){$cdf++;}
					elsif($posi eq "DMF" ){$cdmf++;}
					elsif($posi eq "OMF" ){$comf++;}
					elsif($posi eq "FW" ){$cfw++;}
					else{last;}
				}
				
				$j=1;
				$loop_count=0; # 루프 체크
				for($i=20+$cgk+$cdf+$cdmf+$comf+$cfw; $i<@zenkai; $i++){
					&loop_check; # 루프 체크
					&split("teamdata","$zenkai[$i]");
					my $shiai = $win+$lose+$draw;
					my $tokushitu = $sotokuten-$soshiten;
					my $icon_pri="<img src=$icondir/$icon.gif align=middle>" if $icon_use;
					print "<tr><td align=center><b>$j</b></td>";
					&id_conv("$id");
					if($form{teamname} eq $teamname){
						print "<td>$icon_pri<font color=$text1><a href=$mainfile?log_view=zenkai&id=$crypt_id&teamname=$teamname>$teamname</a> ($owner)</font></td>";
					}else{
						print "<td>$icon_pri<a href=$mainfile?log_view=zenkai&id=$crypt_id&teamname=$teamname>$teamname</a> ($owner)</td>";
					}
					print "<td align=right>$shiai</td>";
					print "<td align=right>$win</td>";
					print "<td align=right><small>($win1)</small></td>" if $game_flg;
					print "<td align=right><small>($win2)</small></td>" if $game_flg == 2;
					print "<td align=right>$lose</td>";
					print "<td align=right>$draw</td>";
					print "<td align=right>$win_p</td>";
					print "<td align=right>$sotokuten</td>";
					print "<td align=right>$soshiten</td>";
					print "<td align=right>$tokushitu</td></tr>";
					$j++;
				}
				print "</table><br><br>";
				print "<table width=$width><tr><td width=50%>";
				print "<table border=1 width=100% cellspacing=0>";
				print "<tr><th colspan=2>득점왕랭킹</th></tr>";
				for($i=0; $i<10; $i++){
					&split("playerdata","$zenkai[$i]");
					if($score eq ""){last;}
					&ranking_sub("$score");
				}
				print "</table></td><td width=50%>";
				print "<table border=1 width=100% cellspacing=0>";
				print "<tr><th colspan=2>평가점랭킹</th></tr>";
				for($i=10; $i<20; $i++){
					&split("playerdata","$zenkai[$i]");
					if($hyoka eq ""){last;}
					$hyoka = sprintf("%.2f",$hyoka/100);
					&ranking_sub("$hyoka");
				}
				print "</table></td></tr></table><br>";
				print "<table width=$width><tr><td width=50%>";
				print "<table border=1 width=100% cellspacing=0>";
				print "<tr><th colspan=2>평가점랭킹(GK)</th></tr>";
				$loop_count=0; # 루프 체크
				for($i=20; $i<20+$cgk; $i++){
					&loop_check; # 루프 체크
					&split("playerdata","$zenkai[$i]");
					$hyoka = sprintf("%.2f",$hyoka/100);
					&ranking_sub("$hyoka");
				}
				print "</table></td><td width=50%>";
				print "<table border=1 width=100% cellspacing=0>";
				print "<tr><th colspan=2>평가점랭킹(DF)</th></tr>";
				$loop_count=0; # 루프 체크
				for($i=20+$cgk; $i<20+$cgk+$cdf; $i++){
					&loop_check; # 루프 체크
					&split("playerdata","$zenkai[$i]");
					$hyoka = sprintf("%.2f",$hyoka/100);
					&ranking_sub("$hyoka");
				}
				print "</table></td></tr></table><br>";
				
				print "<table width=$width><tr><td width=50%>";
				print "<table border=1 width=100% cellspacing=0>";
				print "<tr><th colspan=2>평가점랭킹(DMF)</th></tr>";
				$loop_count=0; # 루프 체크
				for($i=20+$cgk+$cdf; $i<20+$cgk+$cdf+$cdmf; $i++){
					&loop_check; # 루프 체크
					&split("playerdata","$zenkai[$i]");
					$hyoka = sprintf("%.2f",$hyoka/100);
					&ranking_sub("$hyoka");
				}
				print "</table></td><td width=50%>";
				print "<table border=1 width=100% cellspacing=0>";
				print "<tr><th colspan=2>평가점랭킹(OMF)</th></tr>";
				$loop_count=0; # 루프 체크
				for($i=20+$cgk+$cdf+$cdmf; $i<20+$cgk+$cdf+$cdmf+$comf; $i++){
					&loop_check; # 루프 체크
					&split("playerdata","$zenkai[$i]");
					$hyoka = sprintf("%.2f",$hyoka/100);
					&ranking_sub("$hyoka");
				}
				print "</table></td></tr></table><br>";
				
				print "<table width=$width><tr><td width=50%>";
				print "<table border=1 width=100% cellspacing=0>";
				print "<tr><th colspan=2>평가점랭킹(FW)</th></tr>";
				$loop_count=0; # 루프 체크
				for($i=20+$cgk+$cdf+$cdmf+$comf; $i<20+$cgk+$cdf+$cdmf+$comf+$cfw; $i++){
					&loop_check; # 루프 체크
					&split("playerdata","$zenkai[$i]");
					$hyoka = sprintf("%.2f",$hyoka/100);
					&ranking_sub("$hyoka");
				}
				print "</table></td><td></td></tr></table><br>";
			}
		}
	}elsif($form{ranking} eq "rekidai"){
		foreach(@dir){
			my $div = $_ eq $dir[0] ? 0 : 1;
			if(($league < $ma_dai && $league) || $div){
				print <<"_EOF_";
<h2>$league[$div]역대 랭킹</h2>
<table border=1 width=$width cellspacing=0>
<tr><th><br></th><th>팀명(HN)</th><th>시<br><br>합</th><th>승<br><br></th>
_EOF_
				print "<th>연<br>장<br>승</th>" if $game_flg;
				print "<th>P<br>K<br>승</th>" if $game_flg == 2;
				print <<"_EOF_";
<th>패<br><br></th><th>인<br><br>분</th><th>승<br><br>점</th><th>총<br>득<br>점</th><th>총<br>실<br>점</th><th>득<br>실<br>차</th></tr>
_EOF_
				if($game_flg == 1){$tmp = 10;}
				elsif($game_flg == 2){$tmp = 11;}
				elsif(!$game_flg){$tmp = 9;}
				my @rekidai = &load("$dir[$div]/$datadir/$rekidaifile");
				foreach(@rekidai){
					&split("rekidai","$_");
					my $shiai = $win+$lose+$draw;
					my $tokushitu = $sotokuten-$soshiten;
					my $icon_pri="<img src=$icondir/$icon.gif align=middle>" if $icon_use;
					print "<tr><td align=center nowrap>제$re_dai회</td>";
					if($teamname){
						&id_conv("$id");
						if($form{teamname} eq $teamname){
							print "<td>$icon_pri<font color=$text1><a href=$mainfile?log_view=rekidai&id=$crypt_id$re_dai&teamname=$teamname>$teamname</a> ($owner)</font></td>";
						}else{
							print "<td>$icon_pri<a href=$mainfile?log_view=rekidai&id=$crypt_id$re_dai&teamname=$teamname>$teamname</a> ($owner)</td>";
						}
						print "<td align=right>$shiai</td>";
						print "<td align=right>$win</td>";
						print "<td align=right><small>($win1)</small></td>" if $game_flg;
						print "<td align=right><small>($win2)</small></td>" if $game_flg == 2;
						print "<td align=right>$lose</td>";
						print "<td align=right>$draw</td>";
						print "<td align=right>$win_p</td>";
						print "<td align=right>$sotokuten</td>";
						print "<td align=right>$soshiten</td>";
						print "<td align=right>$tokushitu</td></tr>";
					}else{print "<td align=center colspan=$tmp>해당 없음</td></tr>";}
				}
				print "</table><br><br>";
				print "<table width=$width><tr><td width=50%>";
				print "<table border=1 width=100% cellspacing=0>";
				print "<tr><th colspan=3>역대 승점 랭킹</th></tr>";
				my @wp_rank = &load("$dir[$div]/$datadir/$wp_rankfile");
				foreach(@wp_rank){
					my ($wp_dai, $wp_id, $wp_teamname, $wp_owner, $wp_icon, $wp_win_p) = split(/<>/);
					&id_conv("$wp_id");
#					&split("rekidai","$_");
					if(!$wp_win_p){last;}
					my $icon_pri_wp="<img src=$icondir/$wp_icon.gif align=middle>" if $icon_use;
					print "<tr><td align=center nowrap>제$wp_dai회</td>";
					&id_conv("$wp_id");
					if($form{teamname} eq $wp_teamname){
						print "<td>$icon_pri_wp<font color=$text1><a href=$mainfile?log_view=rekidai&id=$crypt_id$wp_dai&teamname=$wp_teamname>$wp_teamname</a> ($wp_owner)</font></td>";
					}else{
						print "<td>$icon_pri_wp<a href=$mainfile?log_view=rekidai&id=$crypt_id$wp_dai&teamname=$wp_teamname>$wp_teamname</a> ($wp_owner)</td>";
					}
					print "<td align=right>$wp_win_p</td></tr>";
				}
				print "</table></td><td width=50%>";
				print "<table border=1 width=100% cellspacing=0>";
				print "<tr><th colspan=3>역대 연승 랭킹</th></tr>";
				foreach(@rekidai){
					&split("rekidai","$_");
					my $icon_pri_wm="<img src=$icondir/$wm_icon.gif align=middle>" if $icon_use;
					print "<tr><td align=center nowrap>제$re_dai회</td>";
					if($wm_winmax){
						&id_conv("$wm_id");
						if($form{teamname} eq $wm_teamname){
							print "<td>$icon_pri_wm<font color=$text1><a href=$mainfile?log_view=rekidai&id=$crypt_id$re_dai&teamname=$wm_teamname>$wm_teamname</a> ($wm_owner)</font></td>";
						}else{
							print "<td>$icon_pri_wm<a href=$mainfile?log_view=rekidai&id=$crypt_id$re_dai&teamname=$wm_teamname>$wm_teamname</a> ($wm_owner)</td>";
						}
						print "<td align=center>$wm_winmax 연승</td></tr>";
					}else{print "<td align=center colspan=2>해당 없음</td></tr>";}
				}
				print "</table></td></tr></table><br>";
				print "<table width=$width><tr><td width=50%>";
				print "<table border=1 width=100% cellspacing=0>";
				print "<tr><th colspan=3>역대 득점왕</th></tr>";
				foreach(@rekidai){
					&split("rekidai","$_");
					print "<tr><td align=center nowrap>제$re_dai회</td>";
					if($s_p_name){
						if($form{teamname} eq $s_shozoku){
							print "<td><font color=$text1>$s_p_name($s_shozoku)</font></td><td align=right><font color=$text1>$s_score</font></td></tr>";
						}else{
							print "<td>$s_p_name($s_shozoku)</td><td align=right>$s_score</td></tr>";
						}
					}else{print "<td align=center colspan=2>해당 없음</td></tr>";}
				}
				print "</table></td><td width=50%>";
				print "<table border=1 width=100% cellspacing=0>";
				print "<tr><th colspan=3>역대 최우수 선수</th></tr>";
				foreach(@rekidai){
					&split("rekidai","$_");
					$h_hyoka = sprintf("%.2f",$h_hyoka/100);
					print "<tr><td align=center nowrap>제$re_dai회</td>";
					if($h_p_name){
						if($form{teamname} eq $h_shozoku){
							print "<td><font color=$text1>$h_p_name($h_shozoku)</font></td><td align=right><font color=$text1>$h_hyoka</font></td></tr>";
						}else{
							print "<td>$h_p_name($h_shozoku)</td><td align=right>$h_hyoka</td></tr>";
						}
					}else{print "<td align=center colspan=2>해당 없음</td></tr>";}
				}
				print "</table></td></tr></table><br>";
				print "<table width=$width><tr><td width=50%>";
				print "<table border=1 width=100% cellspacing=0>";
				print "<tr><th colspan=3>역대 최우수 선수(GK)</th></tr>";
				foreach(@rekidai){
					&split("rekidai","$_");
					$hyoka_gk = sprintf("%.2f",$hyoka_gk/100);
					print "<tr><td align=center nowrap>제$re_dai회</td>";
					if($p_name_gk){
						if($form{teamname} eq $shozoku_gk){
							print "<td><font color=$text1>$p_name_gk($shozoku_gk)</font></td><td align=right><font color=$text1>$hyoka_gk</font></td></tr>";
						}else{
							print "<td>$p_name_gk($shozoku_gk)</td><td align=right>$hyoka_gk</td></tr>";
						}
					}else{print "<td align=center colspan=2>해당 없음</td></tr>";}
				}
				print "</table></td><td width=50%>";
				print "<table border=1 width=100% cellspacing=0>";
				print "<tr><th colspan=3>역대 최우수 선수(DF)</th></tr>";
				foreach(@rekidai){
					&split("rekidai","$_");
					$hyoka_df = sprintf("%.2f",$hyoka_df/100);
					print "<tr><td align=center nowrap>제$re_dai회</td>";
					if($p_name_df){
						if($form{teamname} eq $shozoku_df){
							print "<td><font color=$text1>$p_name_df($shozoku_df)</font></td><td align=right><font color=$text1>$hyoka_df</font></td></tr>";
						}else{
							print "<td>$p_name_df($shozoku_df)</td><td align=right>$hyoka_df</td></tr>";
						}
					}else{print "<td align=center colspan=2>해당 없음</td></tr>";}
				}
				print "</table></td></tr></table><br>";
				print "<table width=$width><tr><td width=50%>";
				print "<table border=1 width=100% cellspacing=0>";
				print "<tr><th colspan=3>역대 최우수 선수(DMF)</th></tr>";
				foreach(@rekidai){
					&split("rekidai","$_");
					$hyoka_dmf = sprintf("%.2f",$hyoka_dmf/100);
					print "<tr><td align=center nowrap>제$re_dai회</td>";
					if($p_name_dmf){
						if($form{teamname} eq $shozoku_dmf){
							print "<td><font color=$text1>$p_name_dmf($shozoku_dmf)</font></td><td align=right><font color=$text1>$hyoka_dmf</font></td></tr>";
						}else{
							print "<td>$p_name_dmf($shozoku_dmf)</td><td align=right>$hyoka_dmf</td></tr>";
						}
					}else{print "<td align=center colspan=2>해당 없음</td></tr>";}
				}
				print "</table></td><td width=50%>";
				print "<table border=1 width=100% cellspacing=0>";
				print "<tr><th colspan=3>역대 최우수 선수(OMF)</th></tr>";
				foreach(@rekidai){
					&split("rekidai","$_");
					$hyoka_omf = sprintf("%.2f",$hyoka_omf/100);
					print "<tr><td align=center nowrap>제$re_dai회</td>";
					if($p_name_omf){
						if($form{teamname} eq $shozoku_omf){
							print "<td><font color=$text1>$p_name_omf($shozoku_omf)</font></td><td align=right><font color=$text1>$hyoka_omf</font></td></tr>";
						}else{
							print "<td>$p_name_omf($shozoku_omf)</td><td align=right>$hyoka_omf</td></tr>";
						}
					}else{print "<td align=center colspan=2>해당 없음</td></tr>";}
				}
				print "</table></td></tr></table><br>";
				print "<table width=$width><tr><td width=50%>";
				print "<table border=1 width=100% cellspacing=0>";
				print "<tr><th colspan=3>역대 최우수 선수(FW)</th></tr>";
				foreach(@rekidai){
					&split("rekidai","$_");
					$hyoka_fw = sprintf("%.2f",$hyoka_fw/100);
					print "<tr><td align=center nowrap>제$re_dai회</td>";
					if($p_name_omf){
						if($form{teamname} eq $shozoku_fw){
							print "<td><font color=$text1>$p_name_fw($shozoku_fw)</font></td><td align=right><font color=$text1>$hyoka_fw</font></td></tr>";
						}else{
							print "<td>$p_name_fw($shozoku_fw)</td><td align=right>$hyoka_fw</td></tr>";
						}
					}else{print "<td align=center colspan=2>해당 없음</td></tr>";}
				}
				print "</table></td><td><br></td></tr></table><br>";
			}
		}
	}elsif($form{ranking} eq "rensho"){
		foreach(@dir){
			my $div = $_ eq $dir[0] ? 0 : 1;
			if(($league <= $ma_dai && $league) || $div){
				print <<"_EOF_";
<h2>$league[$div]연승 기록 랭킹</h2>
<table border=1 width=$width cellspacing=0>
<tr><th>순위</th><th>팀명(HN)</th><th>연승 기록</th></tr>
_EOF_
				my(@teams,@t_sortkey1,@t_sortkey2);
				opendir(DIR,"$dir[$div]/$teamdir") or die "오픈 에러($dir[$div]/$teamdir)<br>$! ";
				my @teamdata = grep !/^\.\.?$|\.htm/,readdir(DIR);
				closedir(DIR);
				foreach(@teamdata){
					my @users = &load("$dir[$div]/$teamdir/$_");
					push(@teams,$users[0]);
					&split("teamdata","$users[0]");
					push(@t_sortkey1,$winmax);
					push(@t_sortkey2,$win_p);
				}
				my @team_rank = @teams[sort {$t_sortkey1[$b] <=> $t_sortkey1[$a] or	$t_sortkey2[$b] <=> $t_sortkey2[$a]} 0 .. $#t_sortkey1];
				
				$j=1;
				foreach(@team_rank){
					if($j >= 11){last;}
					&split("teamdata","$_");
					if(!$winmax){last;}
					my $icon_pri="<img src=$icondir/$icon.gif align=middle>" if $icon_use;
					my $cup_pri='';
					if($cup){
						$loop_count=0; # 루프 체크
						for($i=0; $i<$cup; $i++){
							&loop_check; # 루프 체크
							if(0 == $i%10 && $i != 0){$cup_pri .= "<br>";}
							$cup_pri .= $cupmark;
						}
					}
					print "<tr><td align=center><b>$j</b></td>";
					&id_conv("$id");
					if("$id" eq "$form{id}"){
						print "<td><table cellspacing=0 cellpadding=0><tr><td rowspan=2>$icon_pri</td><td>$cup_pri</td></tr><tr><td><font color=$text1><a href=$mainfile?log_view=konkai&id=$crypt_id&teamname=$teamname>$teamname</a> ($owner)</font></td></tr></table></td>";
						print "<td align=right><font color=$text1>$winmax</font></td></tr>";
					}else{
						print "<td><table cellspacing=0 cellpadding=0><tr><td rowspan=2>$icon_pri</td><td>$cup_pri</td></tr><tr><td><a href=$mainfile?log_view=konkai&id=$crypt_id&teamname=$teamname>$teamname</a> ($owner)</td></tr></table></td>";
						print "<td align=right>$winmax</td></tr>";
					}
					$j++;
				}
				print "</table><br>";
			}
		}
	}
	&menu;
	&footer;
	
}#END ranking

#--------------------------------#
#	랭킹표시(써브루틴)	#
#--------------------------------#
sub ranking_sub {
	
	if($form{ranking} eq "player"){
		$i=0; my $position = shift @_; my @rankdata = @_;
		print "<table border=1 width=100% cellspacing=0>";
		print "<tr><th colspan=2>평가점랭킹($position)</th></tr>";
		foreach(@rankdata){
			&split("playerdata","$_");
			if($posi eq $position){
				$hyoka = sprintf("%.2f",$hyoka/100);
				if($form{teamname} eq $shozoku){
					print "<tr><td><font color=$text1>$p_name($shozoku)</font></td><td align=right><font color=$text1>$hyoka</font></td></tr>";
				}else{
					print "<tr><td>$p_name($shozoku)</td><td align=right>$hyoka</td></tr>";
				}
				$i++;
				if($i >= 5){last;}
			}
		}
		print "</table>";
	}elsif($form{ranking} eq "zenkai"){
		if($form{teamname} eq $shozoku){
			print "<tr><td><font color=$text1>$p_name($shozoku)</font></td><td align=right><font color=$text1>$_[0]</font></td></tr>";
		}else{
			print "<tr><td>$p_name($shozoku)</td><td align=right>$_[0]</td></tr>";
		}
	}
	
}#END ranking_sub

#----------------#
#	시합 등록 확인	#
#----------------#
sub teams_set {
	
	if($lockkey){&lock;}
	
	&para_check;
	&error("파라미터 에러입니다") if $err_cmt ne "";
	if($proxy_check){&proxy_check;}
	$remote_host = &get_host;
	local $hit=0;
	&dir_check("4");
	if(!$hit){&error("ID가 잘못되어 있습니다");}
	
	# HOME 팀(도전자)의 파일을 읽어들여
	my @users = &load("$class/$teamdir/$form{id}.dat");
	&split("h_teamdata","$users[0]");
	if($host_check){&accesslog;}
	&error("연속으로 시합은 할 수 없습니다") if $times<$h_date+$between*60;
	for($i=0; $i<11; $i++){&split("h_playersdata","$users[$i+1]");}
	$h_teamname = $form{teamname};
	$h_owner = $form{owner};
	$h_tac = $form{tac};
	$h_tac_zp = $form{tac_zp};
	$h_tac_ca = $form{tac_ca};
	$h_tac_pp = $form{tac_pp};
	$h_tac_vszp = $form{tac_vszp};
	$h_tac_vsca = $form{tac_vsca};
	$h_tac_vspp = $form{tac_vspp};
	$h_icon = $form{icon} if $icon_use;
	for($i=0; $i<11; $i++){
		$h_gk = $i if $form{"posi$i"} eq 'GK';
		$h_posi[$i] = $form{"posi$i"};
		$h_name[$i] = $form{"player$i"};
		$h_pass[$i] = $form{"pass$i"}+$form{"plus1$i"};
		$h_dori[$i] = $form{"dori$i"}+$form{"plus2$i"};
		$h_shoo[$i] = $form{"shoo$i"}+$form{"plus3$i"};
		$h_defe[$i] = $form{"defe$i"}+$form{"plus4$i"};
		$h_fk[$i] = $form{"fk$i"};
		$h_pk[$i] = $form{"pk$i"};
		$h_style[$i] = $form{"style$i"};
		$h_fair[$i] = $form{"fair$i"};
	}
	
	# AWAY 팀(우승자)의 파일을 읽어들여
	if(-z "$class/$datadir/$winnerfile"){
		&write("$class/$datadir/$winnerfile","$form{id}<>$form{teamname}<>$form{owner}<>$form{icon}<>0<>0<>도전자 모집중♪<>$remote_host<>\n");
		&error("우승자 부재였기 때문에 「$form{teamname}」가 챔피언이 되었습니다");
	}
	my @winnerdata = &load("$class/$datadir/$winnerfile");
	&split("winnerdata","$winnerdata[0]");
	if(!-e "$class/$teamdir/$w_id.dat"){
		&write("$class/$datadir/$winnerfile","$form{id}<>$form{teamname}<>$form{owner}<>$form{icon}<>0<>0<>도전자 모집중♪<>$remote_host<>\n");
		&error("우승자 부재였기 때문에 「$form{teamname}」가 챔피언이 되었습니다");
	}
	&error("현재 우승자를 위해 싸울 수 없습니다") if $w_id eq $h_id;
	if($host_check){&error("2겹등록의 혐의가 있습니다") if $w_host eq $remote_host;}
	my @users = &load("$class/$teamdir/$w_id.dat");
	&split("a_teamdata","$users[0]");
	for($i=0; $i<11; $i++){
		&split("a_playersdata","$users[$i+1]");
		$a_gk = $i if $a_posi[$i] eq 'GK';
	}
	
	require $gamefile;
	
}#END teams_set

#----------------------#
#	프록시 체크	#
#----------------------#
sub proxy_check {
	
	&error("대리 경유에서의 접속은 제한하고 있는") if $ENV{HTTP_VIA} || $ENV{HTTP_PROXY_CONNECTION};
	
}#END proxy_check

#--------------------------#
#	디렉토리내 체크	#
#--------------------------#
sub dir_check {
	
	foreach(@dir){
		opendir(DIR,"$_/$teamdir") or die "오픈 에러($_/$teamdir)<br>$! ";
		my @teamdata = grep !/^\.\.?$|\.htm/,readdir(DIR);
		closedir(DIR);
		if(@_[0] == 2){
			&error("벌써 등록 인원수가<b>$jogen</b>인을 넘고 있으므로 등록할 수 없습니다") if @teamdata>=$jogen;
		}
		foreach $team (@teamdata){
			my @users = &load("$_/$teamdir/$team");
			&split("teamdata","$users[0]");
			foreach $no (@_){&checks("$no");}
		}
	}
	
}#END dir_check

#----------------#
#	각종 체크	#
#----------------#
sub checks {
	
	if($_[0] == 1){
		if($form{teamname} eq $teamname && $form{id} ne $id){$checker[18]=1;}
		if($form{owner} eq $owner && $form{id} ne $id){$checker[19]=1;}
	}elsif($_[0] == 2){
		if($form{id} eq $id){&error("이 ID는 벌써 사용되고 있습니다");}
		if($remote_host eq $host){&error("2겹등록의 혐의가 있습니다") if $host_check;}
	}elsif($_[0] == 3){
		if($form{id} eq $id){
			if($form{password} eq $password){$class=$_; $delete_team=$teamname; $hit=1; last;}
			else{&error("패스워드가 잘못되어 있습니다")}
		}
	}elsif($_[0] == 4){
		if($host eq $remote_host && $form{id} ne $id){&error("2겹등록의 혐의가 있습니다") if $host_check;}
		if($form{id} eq $id){
			if($form{password} eq $password){$class=$_; $hit=1;}
			else{&error("패스워드가 잘못되어 있습니다")}
		}
	}
	
}#END checks

#----------------#
#	액세스 로그	#
#----------------#
sub accesslog {
	
	my @logfile = &load("$accesslog");
	$i=0; my @delete=();
	foreach(@logfile){
		my @logs = split(/<>/);
		if($times<$logs[3]+$between*60){
			if($logs[2] eq $remote_host && $logs[0] ne $h_teamname){&error("2겹등록의 혐의가 있습니다");}
		}else{
			push @delete,$i;
		}
		$i++;
	}
	foreach(@delete){splice(@logfile,$_,1);}
	push @logfile,"$h_teamname<>$h_id<>$remote_host<>$times<>\n";
	&write("$accesslog",@logfile);
	
}#END accesslog

#--------------#
#	시합 전준비	#
#--------------#
sub junbi {
	
	for($i=0; $i<11; $i++){
		$h_total[$i] = $h_pass[$i]+$h_dori[$i]+$h_shoo[$i]+$h_defe[$i];
		if($h_posi[$i] eq 'DF'){
			push(@h_df_no,$i);
			$h_df[1] += $h_pass[$i];
			$h_df[2] += $h_dori[$i];
			$h_df[3] += $h_shoo[$i];
			$h_df[4] += $h_defe[$i];
			$h_df[5] += $h_cond[$i];
		}elsif($h_posi[$i] eq 'DMF'){
			push(@h_dmf_no,$i);
			$h_dmf[1] += $h_pass[$i];
			$h_dmf[2] += $h_dori[$i];
			$h_dmf[3] += $h_shoo[$i];
			$h_dmf[4] += $h_defe[$i];
			$h_dmf[5] += $h_cond[$i];
		}elsif($h_posi[$i] eq 'OMF'){
			push(@h_omf_no,$i);
			$h_omf[1] += $h_pass[$i];
			$h_omf[2] += $h_dori[$i];
			$h_omf[3] += $h_shoo[$i];
			$h_omf[4] += $h_defe[$i];
			$h_omf[5] += $h_cond[$i];
		}elsif($h_posi[$i] eq 'FW'){
			push(@h_fw_no,$i);
			$h_fw[1] += $h_pass[$i];
			$h_fw[2] += $h_dori[$i];
			$h_fw[3] += $h_shoo[$i];
			$h_fw[4] += $h_defe[$i];
			$h_fw[5] += $h_cond[$i];
		}
		
		$a_total[$i] = $a_pass[$i]+$a_dori[$i]+$a_shoo[$i]+$a_defe[$i];
		if($a_posi[$i] eq 'DF'){
			push(@a_df_no,$i);
			$a_df[1] += $a_pass[$i];
			$a_df[2] += $a_dori[$i];
			$a_df[3] += $a_shoo[$i];
			$a_df[4] += $a_defe[$i];
			$a_df[5] += $a_cond[$i];
		}elsif($a_posi[$i] eq 'DMF'){
			push(@a_dmf_no,$i);
			$a_dmf[1] += $a_pass[$i];
			$a_dmf[2] += $a_dori[$i];
			$a_dmf[3] += $a_shoo[$i];
			$a_dmf[4] += $a_defe[$i];
			$a_dmf[5] += $a_cond[$i];
		}elsif($a_posi[$i] eq 'OMF'){
			push(@a_omf_no,$i);
			$a_omf[1] += $a_pass[$i];
			$a_omf[2] += $a_dori[$i];
			$a_omf[3] += $a_shoo[$i];
			$a_omf[4] += $a_defe[$i];
			$a_omf[5] += $a_cond[$i];
		}elsif($a_posi[$i] eq 'FW'){
			push(@a_fw_no,$i);
			$a_fw[1] += $a_pass[$i];
			$a_fw[2] += $a_dori[$i];
			$a_fw[3] += $a_shoo[$i];
			$a_fw[4] += $a_defe[$i];
			$a_fw[5] += $a_cond[$i];
		}
		$h_getscore[$i]=$a_getscore[$i]=0;
		$h_hyoka_p[$i]=$a_hyoka_p[$i]=400;
	}
	$h_df[0] = $h_df[1]+$h_df[2]+$h_df[3]+$h_df[4];
	$h_dmf[0] = $h_dmf[1]+$h_dmf[2]+$h_dmf[3]+$h_dmf[4];
	$h_omf[0] = $h_omf[1]+$h_omf[2]+$h_omf[3]+$h_omf[4];
	$h_fw[0] = $h_fw[1]+$h_fw[2]+$h_fw[3]+$h_fw[4];
	$a_df[0] = $a_df[1]+$a_df[2]+$a_df[3]+$a_df[4];
	$a_dmf[0] = $a_dmf[1]+$a_dmf[2]+$a_dmf[3]+$a_dmf[4];
	$a_omf[0] = $a_omf[1]+$a_omf[2]+$a_omf[3]+$a_omf[4];
	$a_fw[0] = $a_fw[1]+$a_fw[2]+$a_fw[3]+$a_fw[4];
	$h_score = $a_score = 0;
	
}#END junbi

#----------------#
#	시합 결과 표시	#
#----------------#
sub kekka {
	
	&set_cookie;
	&header;
	&menu;
	print "$kekka_header";
	print "<div align=left><blockquote>";
	foreach(@comment){print;}
	print "</blockquote></div>";
	
	# 로그 넘버의 예약
	@kekka = &load("$class/$logdir/$kekkalog");
	&split("kekka","$kekka[0]");
	if(!$log_no || $log_no == 3){$log_no = 1;}
	else{$log_no++;}
	
	print "<br><table border=0><tr><form action=$mainfile method=$method>\n";
	print "<td>시합의 감상을 부디♪</td></tr>\n";
	print "<tr><td><input type=text name=comment size=50></td></tr>\n";
	print "<tr><td><input type=submit name=wincup value=투고></td>\n";
	print "<input type=hidden name=log_no value=$log_no>\n";
	print "<input type=hidden name=class value=$class>\n";
	print "</form></tr></table><br>\n";
	print "$kekka_footer";
	&menu;
	&footer;

}#END kekka

#--------------#
#	시합 후 처리	#
#--------------#
sub save_data {
	
	# 로그 파일의 기입
	unshift(@kekka,join('<>',$log_no,$times,$card,$result,'',"\n"));
	if(@kekka >= 4){pop(@kekka);}
	&write("$class/$logdir/$kekkalog",@kekka);
	
	unshift(@comment,$kekka_header);
	push(@comment,$kekka_footer);
	&write("$class/$logdir/$muchlog$log_no.log",@comment);
	
	# HOME 팀(도전자)의 파일 기입
	$h_users[0] = "$h_id<>$h_password<>$h_owner<>$h_teamname<>$h_tac<>$h_tac_zp<>$h_tac_ca<>$h_tac_pp<>$h_tac_vszp<>$h_tac_vsca<>$h_tac_vspp<>$h_icon<>$times<>$h_win<>$h_win1<>$h_win2<>$h_lose<>$h_draw<>$h_win_p<>$h_winmax<>$h_sotokuten<>$h_soshiten<>$h_cup<>$h_host<>\n";
	for($i=0; $i<11; $i++){
		$h_users[$i+1] = "$h_shozoku[$i]<>$h_name[$i]<>$h_posi[$i]<>$h_pass[$i]<>$h_dori[$i]<>$h_shoo[$i]<>$h_defe[$i]<>$h_fk[$i]<>$h_pk[$i]<>$h_style[$i]<>$h_fair[$i]<>$h_score[$i]<>$h_hyoka[$i]<>$h_cond[$i]<>\n";
	}
	&write("$class/$teamdir/$form{id}.dat",@h_users);
	
	# AWAY 팀(우승자)의 파일 기입
	$a_users[0] = "$a_id<>$a_password<>$a_owner<>$a_teamname<>$a_tac<>$a_tac_zp<>$a_tac_ca<>$a_tac_pp<>$a_tac_vszp<>$a_tac_vsca<>$a_tac_vspp<>$a_icon<>$a_date<>$a_win<>$a_win1<>$a_win2<>$a_lose<>$a_draw<>$a_win_p<>$a_winmax<>$a_sotokuten<>$a_soshiten<>$a_cup<>$a_host<>\n";
	for($i=0; $i<11; $i++){
		$a_users[$i+1] = "$a_shozoku[$i]<>$a_name[$i]<>$a_posi[$i]<>$a_pass[$i]<>$a_dori[$i]<>$a_shoo[$i]<>$a_defe[$i]<>$a_fk[$i]<>$a_pk[$i]<>$a_style[$i]<>$a_fair[$i]<>$a_score[$i]<>$a_hyoka[$i]<>$a_cond[$i]<>\n";
	}
	&write("$class/$teamdir/$a_id.dat",@a_users);
	
	# 우승자 파일 기입
	&write("$class/$datadir/$winnerfile","$w_id<>$w_teamname<>$w_owner<>$w_icon<>$w_rensho<>$w_cup<>$w_before<>$w_host<>\n");
	
	# 랭킹 파일의 기입
	foreach(@dir){
		my $div = $_ eq $dir[0] ? 0 : 1;
		if(($league <= $ma_dai && $league) || $div){
			my(@teams, @t_sortkey1, @t_sortkey2, @t_sortkey3, @t_sortkey4);
			opendir(DIR,"$dir[$div]/$teamdir") or die "오픈 에러($dir[$div]/$teamdir)<br>$! ";
			my @teamdata = grep !/^\.\.?$|\.htm/,readdir(DIR);
			closedir(DIR);
			foreach(@teamdata){
				my @users = &load("$dir[$div]/$teamdir/$_");
				push(@teams,$users[0]);
				&split("teamdata","$users[0]");
				my $sortkey = $win+$lose+$draw == 0 ? 0 : 1;
				push(@t_sortkey1,$sortkey);
				push(@t_sortkey2,$win_p);
				push(@t_sortkey3,($sotokuten-$soshiten));
				push(@t_sortkey4,$sotokuten);
			}
			my @team_rank = @teams[sort {$t_sortkey1[$b] <=> $t_sortkey1[$a] or	$t_sortkey2[$b] <=> $t_sortkey2[$a] or	$t_sortkey3[$b] <=> $t_sortkey3[$a] or	$t_sortkey4[$b] <=> $t_sortkey4[$a]} 0 .. $#t_sortkey1];
			&write("$dir[$div]/$datadir/$rankingfile",@team_rank);
		}
	}
	
	# 매니지먼트 파일의 기입
	my @manage = &load("$managefile");
	($ma_date,$ma_dai) = split(/<>/,$manage[0]);
	&write("$managefile","$ma_date<>$ma_dai<>$ma_rensho1<>$ma_teamname1<>$ma_owner1<>$ma_icon1<>$ma_rensho2<>$ma_teamname2<>$ma_owner2<>$ma_icon2<>");
	
	if($lockkey){&unlock;}
	
}#END save_data

#----------------------#
#	리그 기간 종료 처리	#
#----------------------#
sub league_end {
	
	if(-e $lockfile){
		my $mtime = (stat($lockfile))[9];
		if($mtime < time-60){&unlock;}
		else{&error("갱신중입니다");}
	}
	if($lockkey == 1){symlink(".", $lockfile);}
	elsif($lockkey == 2){mkdir($lockfile, 0755);}
	$lockflag=1;
	
	$ma_dai++;
	local(@down_teams, @up_teams, @div1data, @div2data);
	if($league < $ma_dai && $league){&div1_end;}
	&div2_end;
	
	# 로그 갱신
	opendir(DIR,"$tlogdir/zenkai") or die "오픈 에러($tlogdir/zenkai)<br>$! ";
	my @zenkai_log = grep !/^\.\.?$|\.htm/,readdir(DIR);
	closedir(DIR);
	foreach(@zenkai_log){unlink "$tlogdir/zenkai/$_";}
	opendir(DIR,"$tlogdir/konkai") or die "오픈 에러($tlogdir/konkai)<br>$! ";
	my @konkai_log = grep !/^\.\.?$|\.htm/,readdir(DIR);
	closedir(DIR);
	foreach(@konkai_log){
		my @log = &load("$tlogdir/konkai/$_");
		&write("$tlogdir/zenkai/$_",@log);
		unlink "$tlogdir/konkai/$_";
	}
	
	if($league <= $ma_dai && $league){
		foreach(@down_teams){
			my @users = &load("$dir[0]/$teamdir/$_");
			&write("$dir[1]/$teamdir/$_",@users);
			unlink "$dir[0]/$teamdir/$_";
		}
		unshift @div2data,@down_teams;
		foreach(@up_teams){
			my @users = &load("$dir[1]/$teamdir/$_");
			&write("$dir[0]/$teamdir/$_",@users);
			unlink "$dir[1]/$teamdir/$_";
		}
		push @div1data,@up_teams;
		my @users = &load("$dir[0]/$teamdir/$div1data[0]");
		&split("teamdata","$users[0]");
		$cup++ if $league < $ma_dai && $league;
		$users[0] = "$id<>$password<>$owner<>$teamname<>$tac<>$tac_zp<>$tac_ca<>$tac_pp<>$tac_vszp<>$tac_vsca<>$tac_vspp<>$icon<>$date<>0<>0<>0<>0<>0<>0<>0<>0<>0<>$cup<>$host<>\n";
		&write("$dir[0]/$teamdir/$div1data[0]",@users);
		&write("$dir[0]/$datadir/$winnerfile","$id<>$teamname<>$owner<>$icon<>0<>$cup<>전회 우승♪<>\n");
	}
	if(@div2data != 0){
		my @users = &load("$dir[1]/$teamdir/$div2data[0]");
		&split("teamdata","$users[0]");
		&write("$dir[1]/$datadir/$winnerfile","$id<>$teamname<>$owner<>$icon<>0<>$cup<><>\n");
	}else{&write("$dir[1]/$datadir/$winnerfile","");}
	&write("$managefile","$kakiko_times<>$ma_dai<>$ma_rensho1<>$ma_teamname1<>$ma_owner1<>$ma_icon1<>$ma_rensho2<>$ma_teamname2<>$ma_owner2<>$ma_icon2<>");
	$l_day_pri = "－<b> 첫날 </b>－";
	
	if($lockkey){&unlock;}
	
}#END league_end

#---------------------#
#	1부 리그 종료 처리	#
#---------------------#
sub div1_end {
	
	my(@teams, @s_players, @h_players, @t_sortkey1, @t_sortkey2, @t_sortkey3, @t_sortkey4, @s_sortkey1, @h_sortkey1, @wm_sortkey1, @wm_sortkey2);
	opendir(DIR,"$dir[0]/$teamdir") or die "오픈 에러($dir[0]/$teamdir)<br>$! ";
	@div1data = grep !/^\.\.?$|\.htm/,readdir(DIR);
	closedir(DIR);
	foreach(@div1data){
		my @users = &load("$dir[0]/$teamdir/$_");
		&split("teamdata","$users[0]");
		if($times > ($date+$userlimit*24*60*60)){unlink "$dir[0]/$teamdir/$_";}
	}
	
	opendir(DIR,"$dir[0]/$teamdir") or die "오픈 에러($dir[0]/$teamdir)<br>$! ";
	@div1data = grep !/^\.\.?$|\.htm/,readdir(DIR);
	closedir(DIR);
	foreach(@div1data){
		my @users = &load("$dir[0]/$teamdir/$_");
		&split("teamdata","$users[0]");
		push(@teams, $users[0]);
		my $sortkey = $win+$lose+$draw == 0 ? 0 : 1;
		push(@t_sortkey1,$sortkey);
		push(@t_sortkey2,$win_p);
		push(@t_sortkey3,($sotokuten-$soshiten));
		push(@t_sortkey4,$sotokuten);
		push(@wm_sortkey1,$winmax);
		push(@wm_sortkey2,$win_p);
		$users[0] = "$id<>$password<>$owner<>$teamname<>$tac<>$tac_zp<>$tac_ca<>$tac_pp<>$tac_vszp<>$tac_vsca<>$tac_vspp<>$icon<>$date<>0<>0<>0<>0<>0<>0<>0<>0<>0<>$cup<>$host<>\n";
		for($ii=1; $ii<12; $ii++){
			&split("playerdata","$users[$ii]");
			if($score){
				push(@s_players,$users[$ii]);
				push(@s_sortkey1,$score);
			}
			if(($win+$lose+$draw) >= $league_min){
				push(@h_players,$users[$ii]);
				push(@h_sortkey1,$hyoka);
			}
			$users[$ii] = "$shozoku<>$p_name<>$posi<>$pass<>$dori<>$shoo<>$defe<>$fk<>$pk<>$style<>$fair<>0<>000<>5<>\n";
		}
		&write("$dir[0]/$teamdir/$_",@users);
	}
	@div1data = @div1data[sort {$t_sortkey1[$b] <=> $t_sortkey1[$a] or	$t_sortkey2[$b] <=> $t_sortkey2[$a] or	$t_sortkey3[$b] <=> $t_sortkey3[$a] or	$t_sortkey4[$b] <=> $t_sortkey4[$a]} 0 .. $#t_sortkey1];
	my @div1wmrank = @teams[sort {$wm_sortkey1[$b] <=> $wm_sortkey1[$a] or	$wm_sortkey2[$b] <=> $wm_sortkey2[$a]} 0 .. $#wm_sortkey1];
	my @div1trank = @teams[sort {$t_sortkey1[$b] <=> $t_sortkey1[$a] or	$t_sortkey2[$b] <=> $t_sortkey2[$a] or	$t_sortkey3[$b] <=> $t_sortkey3[$a] or	$t_sortkey4[$b] <=> $t_sortkey4[$a]} 0 .. $#t_sortkey1];
	my @div1srank = @s_players[sort{$s_sortkey1[$b]<=>$s_sortkey1[$a]} 0 .. $#s_sortkey1];
	my @div1hrank = @h_players[sort{$h_sortkey1[$b]<=>$h_sortkey1[$a]} 0 .. $#h_sortkey1];
	$up_team = @div1data<($div1_team-$updown_team) ? $div1_team-@div1data : $updown_team;
	@down_teams = splice(@div1data,($div1_team-$updown_team));
	my @zenkai=();
	for($i=0; $i<10; $i++){
		if($div1srank[$i]){push(@zenkai,$div1srank[$i]);}
		else{push(@zenkai,"\n");}
	}
	for($i=0; $i<10; $i++){
		if($div1hrank[$i]){push(@zenkai,$div1hrank[$i]);}
		else{push(@zenkai,"\n");}
	}
	foreach("GK","DF","DMF","OMF","FW"){
		$i=0;
		foreach $player (@div1hrank){
			&split("playerdata","$player");
			if($posi eq $_){
				push(@zenkai,$player); $i++;
				if($i >= 5){last;}
			}
		}
	}
	foreach(@div1trank){push(@zenkai,$_);}
	&write("$dir[0]/$datadir/$zenkaifile",@zenkai);
	
#	if(!-z "$dir[0]/$datadir/$rekidaifile"){
	@rekidai = &load("$dir[0]/$datadir/$rekidaifile");
#		&split("rekidai","$rekidai[0]");
#		$re_dai++;
	if(@rekidai>=11){
		my $delete_log = pop(@rekidai);
		&split("rekidai","$delete_log");
		&id_conv("$id");
		if(-e "$tlogdir/rekidai/$crypt_id$re_dai.cgi"){unlink "$tlogdir/rekidai/$crypt_id$re_dai.cgi";}
		&id_conv("$wm_id");
		if(-e "$tlogdir/rekidai/$crypt_id$re_dai.cgi"){unlink "$tlogdir/rekidai/$crypt_id$re_dai.cgi";}
	}
	$re_dai = $ma_dai - 1;
	&split("teamdata","$div1trank[0]");
	my $new_rekidai = "$re_dai<>$id<>$owner<>$teamname<>$icon<>$win<>$win1<>$win2<>$lose<>$draw<>$win_p<>$winmax<>$sotokuten<>$soshiten";
	&split("teamdata","$div1wmrank[0]");
	$new_rekidai .= "<>$id<>$owner<>$teamname<>$icon<>$winmax";
	&split("playerdata","$div1srank[0]");
	$new_rekidai .= "<>$shozoku<>$p_name<>$posi<>$score<>$hyoka";
	&split("playerdata","$div1hrank[0]");
	$new_rekidai .= "<>$shozoku<>$p_name<>$posi<>$score<>$hyoka";
	foreach("GK","DF","DMF","OMF","FW"){
		foreach $player (@div1hrank){
			&split("playerdata","$player");
			if($posi eq $_){$new_rekidai .= "<>$shozoku<>$p_name<>$score<>$hyoka"; last;}
		}
	}
	$new_rekidai .= "<>\n";
	&split("rekidai","$new_rekidai");
	&id_conv("$id");
	if(-e "$tlogdir/konkai/$crypt_id.cgi"){
		my @log = &load("$tlogdir/konkai/$crypt_id.cgi");
		open(OUT,">$tlogdir/rekidai/$crypt_id$re_dai.cgi") || &error("기입 에러<br>($tlogdir/rekidai/$crypt_id$re_dai.cgi)");
		eval 'flock(OUT,2);';
		seek(OUT,0,0);
		print OUT @log;
		eval 'flock(OUT,8);';
		close(OUT);
	}
	
	&id_conv("$wm_id");
	if(-e "$tlogdir/konkai/$crypt_id.cgi"){
		my @log = &load("$tlogdir/konkai/$crypt_id.cgi");
		open(OUT,">$tlogdir/rekidai/$crypt_id$re_dai.cgi") || &error("기입 에러<br>($tlogdir/rekidai/$crypt_id$re_dai.cgi)");
		eval 'flock(OUT,2);';
		seek(OUT,0,0);
		print OUT @log;
		eval 'flock(OUT,8);';
		close(OUT);
	}
	
	unshift(@rekidai,$new_rekidai);
	&write("$dir[0]/$datadir/$rekidaifile",@rekidai);
	
}#END div1_end

#---------------------#
#	2부 리그 종료 처리	#
#---------------------#
sub div2_end {
	
	my(@teams, @s_players, @h_players, @t_sortkey1, @t_sortkey2, @t_sortkey3, @t_sortkey4, @s_sortkey1, @h_sortkey1, @wm_sortkey1, @wm_sortkey2);
	opendir(DIR,"$dir[1]/$teamdir") or die "오픈 에러($dir[1]/$teamdir)<br>$! ";
	@div2data = grep !/^\.\.?$|\.htm/,readdir(DIR);
	closedir(DIR);
	foreach(@div2data){
		my @users = &load("$dir[1]/$teamdir/$_");
		&split("teamdata","$users[0]");
		if($times > ($date+$userlimit*24*60*60)){unlink "$dir[1]/$teamdir/$_";}
	}
	
	opendir(DIR,"$dir[1]/$teamdir") or die "오픈 에러($dir[1]/$teamdir)<br>$! ";
	@div2data = grep !/^\.\.?$|\.htm/,readdir(DIR);
	closedir(DIR);
	foreach(@div2data){
		my @users = &load("$dir[1]/$teamdir/$_");
		&split("teamdata","$users[0]");
		push(@teams,$users[0]);
		my $sortkey = $win+$lose+$draw == 0 ? 0 : 1;
		push(@t_sortkey1,$sortkey);
		push(@t_sortkey2,$win_p);
		push(@t_sortkey3,($sotokuten-$soshiten));
		push(@t_sortkey4,$sotokuten);
		push(@wm_sortkey1,$winmax);
		push(@wm_sortkey2,$win_p);
		$users[0] = "$id<>$password<>$owner<>$teamname<>$tac<>$tac_zp<>$tac_ca<>$tac_pp<>$tac_vszp<>$tac_vsca<>$tac_vspp<>$icon<>$date<>0<>0<>0<>0<>0<>0<>0<>0<>0<>$cup<>$host<>\n";
		for($ii=1; $ii<12; $ii++){
			&split("playerdata","$users[$ii]");
			if($score){
				push(@s_players,$users[$ii]);
				push(@s_sortkey1,$score);
			}
			if(($win+$lose+$draw) >= $league_min){
				push(@h_players,$users[$ii]);
				push(@h_sortkey1,$hyoka);
			}
			$users[$ii] = "$shozoku<>$p_name<>$posi<>$pass<>$dori<>$shoo<>$defe<>$fk<>$pk<>$style<>$fair<>0<>000<>5<>\n";
		}
		&write("$dir[1]/$teamdir/$_",@users);
	}
	@div2data = @div2data[sort {$t_sortkey1[$b] <=> $t_sortkey1[$a] or	$t_sortkey2[$b] <=> $t_sortkey2[$a] or	$t_sortkey3[$b] <=> $t_sortkey3[$a] or	$t_sortkey4[$b] <=> $t_sortkey4[$a]} 0 .. $#t_sortkey1];
	my @div2wmrank = @teams[sort {$wm_sortkey1[$b] <=> $wm_sortkey1[$a] or	$wm_sortkey2[$b] <=> $wm_sortkey2[$a]} 0 .. $#wm_sortkey1];
	my @div2trank = @teams[sort {$t_sortkey1[$b] <=> $t_sortkey1[$a] or	$t_sortkey2[$b] <=> $t_sortkey2[$a] or	$t_sortkey3[$b] <=> $t_sortkey3[$a] or	$t_sortkey4[$b] <=> $t_sortkey4[$a]} 0 .. $#t_sortkey1];
	my @div2srank = @s_players[sort{$s_sortkey1[$b]<=>$s_sortkey1[$a]} 0 .. $#s_sortkey1];
	my @div2hrank = @h_players[sort{$h_sortkey1[$b]<=>$h_sortkey1[$a]} 0 .. $#h_sortkey1];
	if($league >= $ma_dai || !$league){
		my @users = &load("$dir[1]/$teamdir/$div2data[0]");
		&split("teamdata","$users[0]");
		$cup++;
		$users[0] = "$id<>$password<>$owner<>$teamname<>$tac<>$tac_zp<>$tac_ca<>$tac_pp<>$tac_vszp<>$tac_vsca<>$tac_vspp<>$icon<>$date<>0<>0<>0<>0<>0<>0<>0<>0<>0<>$cup<>$host<>\n";
		&write("$dir[1]/$teamdir/$div2data[0]",@users);
	}
	$up_team = $div1_team if $league == $ma_dai && $league;
	@up_teams = splice(@div2data,0,$up_team) if $league <= $ma_dai && $league;
	my @zenkai=();
	for($i=0; $i<10; $i++){
		if($div2srank[$i]){push(@zenkai,$div2srank[$i]);}
		else{push(@zenkai,"\n");}
	}
	for($i=0; $i<10; $i++){
		if($div2hrank[$i]){push(@zenkai,$div2hrank[$i]);}
		else{push(@zenkai,"\n");}
	}
	foreach("GK","DF","DMF","OMF","FW"){
		$i=0;
		foreach $player (@div2hrank){
			&split("playerdata","$player");
			if($posi eq $_){
				push(@zenkai,$player); $i++;
				if($i >= 5){last;}
			}
		}
	}
	foreach(@div2trank){push(@zenkai,$_);}
	&write("$dir[1]/$datadir/$zenkaifile",@zenkai);
	
	my @rekidai = &load("$dir[1]/$datadir/$rekidaifile");
#	&split("rekidai","$rekidai[0]");
	if(@rekidai>=11){
		my $delete_log = pop(@rekidai);
		&split("rekidai","$delete_log");
		&id_conv("$id");
		if(-e "$tlogdir/rekidai/$crypt_id$re_dai.cgi"){unlink "$tlogdir/rekidai/$crypt_id$re_dai.cgi";}
		&id_conv("$wm_id");
		if(-e "$tlogdir/rekidai/$crypt_id$re_dai.cgi"){unlink "$tlogdir/rekidai/$crypt_id$re_dai.cgi";}
	}
	$re_dai = $ma_dai - 1;
	&split("teamdata","$div2trank[0]");
	my $new_rekidai = "$re_dai<>$id<>$owner<>$teamname<>$icon<>$win<>$win1<>$win2<>$lose<>$draw<>$win_p<>$winmax<>$sotokuten<>$soshiten";
	&split("teamdata","$div2wmrank[0]");
	$new_rekidai .= "<>$id<>$owner<>$teamname<>$icon<>$winmax";
	&split("playerdata","$div2srank[0]");
	$new_rekidai .= "<>$shozoku<>$p_name<>$posi<>$score<>$hyoka";
	&split("playerdata","$div2hrank[0]");
	$new_rekidai .= "<>$shozoku<>$p_name<>$posi<>$score<>$hyoka";
	foreach("GK","DF","DMF","OMF","FW"){
		foreach $player (@div2hrank){
			&split("playerdata","$player");
			if($posi eq $_){$new_rekidai .= "<>$shozoku<>$p_name<>$score<>$hyoka"; last;}
		}
	}
	$new_rekidai .= "<>\n";
	
	&split("rekidai","$new_rekidai");
	&id_conv("$id");
	if(-e "$tlogdir/konkai/$crypt_id.cgi"){
		my @log = &load("$tlogdir/konkai/$crypt_id.cgi");
		open(OUT,">$tlogdir/rekidai/$crypt_id$re_dai.cgi") || &error("기입 에러<br>($tlogdir/rekidai/$crypt_id$re_dai.cgi)");
		eval 'flock(OUT,2);';
		seek(OUT,0,0);
		print OUT @log;
		eval 'flock(OUT,8);';
		close(OUT);
	}
	
	&id_conv("$wm_id");
	if(-e "$tlogdir/konkai/$crypt_id.cgi"){
		my @log = &load("$tlogdir/konkai/$crypt_id.cgi");
		open(OUT,">$tlogdir/rekidai/$crypt_id$re_dai.cgi") || &error("기입 에러<br>($tlogdir/rekidai/$crypt_id$re_dai.cgi)");
		eval 'flock(OUT,2);';
		seek(OUT,0,0);
		print OUT @log;
		eval 'flock(OUT,8);';
		close(OUT);
	}
	
	unshift(@rekidai,$new_rekidai);
	&write("$dir[1]/$datadir/$rekidaifile",@rekidai);
	
}#END div2_end

#----------------#
#	코멘트 처리	#
#----------------#
sub comment {
	
	&error("코멘트는 전각 40자 이내에서") if length($form{comment}) > 80;
	&error("코멘트를 입력해") if length($form{comment}) <= 0;
	my @kekka = &load("$form{class}/$logdir/$kekkalog");
	for($i=0; $i<=5; $i++){
		&split("kekka","$kekka[$i]");
		if($log_no == $form{log_no}){
			if($log_result =~ /교대/){
				$log_cmt = "신체프의 코멘트 「$form{comment}」";
			}elsif($log_result =~ /방위/){
				$log_cmt = "도전자의 코멘트 「$form{comment}」";
			}
			$kekka[$i] = join('<>', $log_no, $log_date, $log_card, $log_result, $log_cmt,"\n");
			&write("$form{class}/$logdir/$kekkalog",@kekka);
			last;
		}
	}
	
}#END comment

#---------------------#
#	과거의 시합 결과 표시	#
#---------------------#
sub result {
	
	my @comment = &load("$form{class}/$logdir/$form{filename}.log");
	&header;
	&menu;
	print "<div align=left><blockquote>";
	foreach(@comment){print;}
	print "<br></blockquote></div>";
	&menu;
	&footer;
	
}#END result

#-----------#
#	로그 표시	#
#-----------#
sub log_view {
	
	if(!-e "$tlogdir/$form{log_view}/$form{id}.cgi"){&error("$form{teamname} 의 로그는 없습니다");}
	my @log = &load("$tlogdir/$form{log_view}/$form{id}.cgi");
	&header;
	&menu;
	print "<table border=1 width=$width><tr><th colspan=5><br><big><b>$form{teamname}  시합 성적</b></big><br><br></th></tr>\n";
	print "<tr><th width=200>홈</th><th><br></th><th width=200>어웨이</th><th>스코아</th><th>일시</th></tr>\n";
	foreach(@log){
		my ($l_times, $lh_id, $lh_teamname, $lh_owner, $la_id, $la_teamname, $la_owner, $l_score, $l_host) = split(/<>/);
		my $l_date = &get_date("$l_times");;
		print "<tr>\n";
		if($lh_id){
			print "<td><small>$lh_teamname($lh_owner)</td>\n";
			print "<td align=center><small>vs</td>\n";
			print "<td align=center><small>-</td>\n";
		}else{
			print "<td align=center><small>-</td>\n";
			print "<td align=center><small>vs</td>\n";
			print "<td><small>$la_teamname($la_owner)</td>\n";
		}
		print "<td align=center><small>$l_score</td>\n";
		print "<td align=center><small>$l_date</td>\n";
		print "</tr>\n";
	}
	print "</table>\n";
	&menu;
	&footer;
	
}#END log_view
