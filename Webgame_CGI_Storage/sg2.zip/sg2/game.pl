
#------------#
#  시합 처리  #
#------------#
sub kickoff {
	
	#										 A0  A1  A2  CA1 CA2 ZP  PP1 PP2 FK1 FK2
	local @o_fw_rate	=	(1.0, 0.8, 0.5, 1.0, 1.0, 1.0, 0.0, 1.0, 0.0, 0.0);
	local @o_omf_rate	=	(0.5, 1.0, 0.8, 0.5, 1.0, 0.9, 0.0, 0.8, 0.0, 0.0);
	local @o_dmf_rate	=	(0.2, 0.3, 0.4, 0.2, 1.0, 0.8, 0.0, 0.5, 0.0, 0.0);
	local @o_df_rate	=	(0.1, 0.2, 0.3, 0.0, 1.0, 0.7, 0.0, 0.0, 0.0, 0.0);
	local @d_fw_rate	=	(0.1, 0.2, 0.3, 0.0, 0.0, 0.0, 0.7, 0.0, 0.0, 0.0);
	local @d_omf_rate	=	(0.2, 0.3, 0.4, 0.2, 0.1, 0.0, 0.8, 0.5, 0.0, 0.0);
	local @d_dmf_rate	=	(0.5, 1.0, 0.8, 0.5, 0.2, 0.0, 0.9, 0.7, 0.0, 0.0);
	local @d_df_rate	=	(1.0, 0.8, 0.5, 1.0, 0.5, 0.0, 1.0, 0.9, 0.1, 0.1);
	
	local(@h_df_no, @h_dmf_no, @h_omf_no, @h_fw_no, @a_df_no, @a_dmf_no, @a_omf_no, @a_fw_no);
	local(@h_df, @h_dmf, @h_omf, @h_fw, @a_df, @a_dmf, @a_omf, @a_fw);
	local(@h_total, @a_total);
	local($h_team_pow, $a_team_pow, $of_player_p, $df_player_p, $of_point, $df_point);
	&junbi;
	local $tac_flg=0; local $area=2; local $n_time=0; local $offence=0; local $comlog=0; local $before_action;
	local $game_end='시합개시';
	$comment[$comlog++] = "자, 드디어 시합개시입니다! <br>$a_tag$a_teamname$a_tag_end는 <b>$a_tac</b>의 전술로 도전해 왔습니다! <br>$h_tag$h_teamname$h_tag_end는 <b>$h_tac</b>의 전술로 맞이하고 있습니다! <br>\n";
	until($game_end eq '시합 종료'){
		if($n_time > 45 or ($game_end =~ /연장/ && $n_time >30)){
			if($game_end eq '시합개시'){
				$game_end = '전반 종료';
				$n_time = 0;
				$comment[$comlog++] = "<br>여기서<b>전반 종료</b>의 휘슬! <br>\n";
				if($h_score > $a_score){
					my $tensa = $h_score - $a_score;
					$comment[$comlog++] = "스코어는<b>$h_score－$a_score</b><br>「$h_tag$h_teamname$h_tag_end」가$tensa점 리드하고 있습니다! \n";
				}elsif($h_score < $a_score){
					my $tensa = $a_score - $h_score;
					$comment[$comlog++] = "스코어는 <b>$h_score－$a_score</b><br>「$a_tag$a_teamname$a_tag_end」가$tensa점 리드하고 있습니다! \n";
				}else{
					$comment[$comlog++] = "스코어는 <b>$h_score－$a_score</b><br>양팀 한 걸음도 나아가지 않았습니다! \n";
				}
				$comment[$comlog++] = "<br>하프 타임이 지나고 후반이 시작됩니다! <br>\n";
			}elsif($game_end eq '전반 종료'){
				if($h_score != $a_score){
					$game_end = '시합 종료';
					$comment[$comlog++] = "<br>그리고 <b>시합 종료</b>의 긴 휘슬! <br>\n";
					&winlose;
				}elsif($h_score == $a_score && $game_flg){
					$game_end = '연장 전반';
					$n_time = 0;
					$comment[$comlog++] = "<br>여기서 긴 휘슬! <br></b>전후반 90분에 승부가 나지 않았습니다! <br><b>연장전</b>에 돌입합니다! <br>\n";
				}elsif($h_score == $a_score && !$game_flg){
					$game_end = '시합 종료';
					$comment[$comlog++] = "<br>여기서 긴 휘슬! <br>\n";
					&winlose;
				}
			}elsif($game_end eq '연장 전반'){
				$game_end = '연장 후반';
				$n_time = 0;
				$comment[$comlog++] = "<br>연장전 전반 동안 계속 동점이였습니다! <br>마침내<b>연장 후반전</b>에 돌입합니다! <br>\n";
			}elsif($game_end eq '연장 후반'){
				if($h_score == $a_score && $game_flg == 1){
					$game_end = '시합 종료';
					$comment[$comlog++] = "<br>여기서 긴 휘슬! <br>\n";
					&winlose;
				}else{
					&vspk;
				}
			}else{&error("$game_end가 이상하다");} # 디버그용
		}elsif(!$offence){
			if($h_tac eq "공격중시"){$h_team_pow=120;}
			elsif($h_tac eq "수비중시"){$h_team_pow=80;}
			else{$h_team_pow=100;}
			if($a_tac eq "공격중시"){$a_team_pow=120;}
			elsif($a_tac eq "수비중시"){$a_team_pow=80;}
			else{$a_team_pow=100;}
			if(rand($h_team_pow+$a_team_pow) <= $h_team_pow){
			
#			$blance = 0;
			# FW가 DF보다 많을 때
#			if((@h_fw_no - @h_df_no) > 0){
#				$blance += (@h_fw_no - @h_df_no);
#			}
			# FW가 MF보다 많을 때
#			if((@h_fw_no - (@h_dmf_no + @h_omf_no)) > 0){
#				$blance += ((@h_dmf_no + @h_omf_no) - @h_fw_no);
#			}
			# MF보다 DF가 3명 이상 많을 때
#			if((@h_df_no - (@h_dmf_no + @h_omf_no + 2)) > 0){
#				$blance += ((@h_dmf_no + @h_omf_no) - @h_df_no);
#			}
			# DMF보다 DF가 적을 때
#			if((@h_dmf_no - @h_df_no) > 0){
#				$blance += (@h_dmf_no - @h_df_no);
#			}
			# OMF보다 DMF가 4명 이상 적을 때
#			if((@h_omf_no - (@h_dmf_no + 3)) > 0){
#				$blance += ((@h_omf_no - (@h_dmf_no + 3)));
#			}
			
				$offence="HOME";
				if($a_tac eq "공격중시"){$a_team_pow=80;}
				elsif($a_tac eq "수비중시"){$a_team_pow=120;}
				else{$a_team_pow=100;}
			}else{
				$offence="AWAY";
				if($h_tac eq "공격중시"){$h_team_pow=80;}
				elsif($h_tac eq "수비중시"){$h_team_pow=120;}
				else{$h_team_pow=100;}
			}
		}elsif($offence eq "HOME"){&home_attack;}
		elsif($offence eq "AWAY"){&away_attack;}
		else{&error("$n_time인가$offence가 이상하다");} # 디버그용
	}# 시합 종료
	
	&condition;
	&kekka_header;
	&kekka_footer;
	
}#END kickoff

1;

#------------#
#  승패 확정  #
#------------#
sub winlose {
	
	&log_write;
	if($h_score > $a_score && $game_end =~ /연장/){
		$comment[$comlog++] = "스코어는 <b>$h_score－$a_score</b>! <br>$h_tag$h_teamname$h_tag_end가 극적인 <b>연장전 승리</b>를 거두었습니다! <br>\n";
		$card="$h_teamname vs $a_teamname";
		$result="<b>$h_score-$a_score</b> 로$h_teamname가 승리해, 챔피언 교체";
		$h_win++;
		$h_win1++;
		$h_win_p += 2;
		&win_p_rank_check("$ma_dai<>$h_id<>$h_teamname<>$h_owner<>$h_icon<>$h_win_p<>\n","$class");
		$a_lose++;
		for($i=0; $i<11; $i++){$h_hyoka_p[$i] += 70+int(rand(30));}
		$w_id = $h_id;
		$w_teamname = $h_teamname;
		$w_owner = $h_owner;
		$w_icon = $h_icon;
		$w_rensho = 1;
		if($class eq $dir[0]){
			if($ma_rensho1 < $w_rensho){
				$ma_rensho1 = $w_rensho;
				$ma_teamname1 = $w_teamname;
				$ma_owner1 = $w_owner;
				$ma_icon1 = $w_icon;
			}
		}else{
			if($ma_rensho2 < $w_rensho){
				$ma_rensho2 = $w_rensho;
				$ma_teamname2 = $w_teamname;
				$ma_owner2 = $w_owner;
				$ma_icon2 = $w_icon;
			}
		}
		$w_cup = $h_cup;
		$w_before = "「$a_teamname」에 승리해 챔피언 교체";
		$w_host = $remote_host;
	}elsif($h_score < $a_score && $game_end =~ /연장/){
		$comment[$comlog++] = "스코어는<b>$h_score－$a_score</b>! <br>$a_tag$a_teamname$a_tag_end가 극적인<b>연장전 승리</b>를 거두었습니다! <br>\n";
		$card="$a_teamname vs $h_teamname";
		$result="<b>$a_score-$h_score</b> 로$a_teamname가 승리해, 챔피언 방어";
		$a_win++;
		$a_win1++;
		$a_win_p += 2;
		&win_p_rank_check("$ma_dai<>$a_id<>$a_teamname<>$a_owner<>$a_icon<>$a_win_p<>\n","$class");
		$h_lose++;
		for($i=0; $i<11; $i++){$a_hyoka_p[$i] += 80+int(rand(30));}
		$w_rensho++;
		if($class eq $dir[0]){
			if($ma_rensho1 < $w_rensho){
				$ma_rensho1 = $w_rensho;
				$ma_teamname1 = $w_teamname;
				$ma_owner1 = $w_owner;
				$ma_icon1 = $w_icon;
			}
		}else{
			if($ma_rensho2 < $w_rensho){
				$ma_rensho2 = $w_rensho;
				$ma_teamname2 = $w_teamname;
				$ma_owner2 = $w_owner;
				$ma_icon2 = $w_icon;
			}
		}
		$w_before = "「$h_teamname」팀에 승리해 챔피언 방어";
		$a_winmax=$w_rensho if $w_rensho>$a_winmax;
	}elsif($h_score > $a_score){
		my $tensa = $h_score - $a_score;
		if($tensa == 1){
			$comment[$comlog++] = "<b>$h_score－$a_score</b>로 $h_tag$h_teamname$h_tag_end가 접전끝에 승리 했습니다! <br>\n";
		}elsif($tensa == 2){
			$comment[$comlog++] = "<b>$h_score－$a_score</b>로 $h_tag$h_teamname$h_tag_end가 쾌승했습니다! <br>\n";
		}else{
			$comment[$comlog++] = "<b>$h_score－$a_score</b>로 $h_tag$h_teamname$h_tag_end, 압승입니다! <br>\n";
		}
		$card="$h_teamname vs $a_teamname";
		$result="<b>$h_score-$a_score</b> 로$h_teamname가 승리해, 챔피언 교체";
		$h_win++;
		$h_win_p += 3;
		&win_p_rank_check("$ma_dai<>$h_id<>$h_teamname<>$h_owner<>$h_icon<>$h_win_p<>\n","$class");
		$a_lose++;
		for($i=0; $i<11; $i++){$h_hyoka_p[$i] += 80+int(rand(30));}
		$w_id = $h_id;
		$w_teamname = $h_teamname;
		$w_owner = $h_owner;
		$w_icon = $h_icon;
		$w_rensho = 1;
		if($class eq $dir[0]){
			if($ma_rensho1 < $w_rensho){
				$ma_rensho1 = $w_rensho;
				$ma_teamname1 = $w_teamname;
				$ma_owner1 = $w_owner;
				$ma_icon1 = $w_icon;
			}
		}else{
			if($ma_rensho2 < $w_rensho){
				$ma_rensho2 = $w_rensho;
				$ma_teamname2 = $w_teamname;
				$ma_owner2 = $w_owner;
				$ma_icon2 = $w_icon;
			}
		}
		$w_cup = $h_cup;
		$w_before = "「$a_teamname」팀에 승리해 챔피언 교체";
		$w_host = $remote_host;
	}elsif($h_score < $a_score){
		my $tensa = $a_score - $h_score;
		if($tensa == 1){
			$comment[$comlog++] = "<b>$h_score－$a_score</b>로 $a_tag$a_teamname$a_tag_end가 접전끝에 승리 했습니다! <br>\n";
		}elsif($tensa == 2){
			$comment[$comlog++] = "<b>$h_score－$a_score</b>로 $a_tag$a_teamname$a_tag_end가 쾌승했습니다! <br>\n";
		}else{
			$comment[$comlog++] = "<b>$h_score－$a_score</b>로 $a_tag$a_teamname$a_tag_end, 압승입니다! <br>\n";
		}
		$card="$a_teamname vs $h_teamname";
		$result="<b>$a_score-$h_score</b> 로 $a_teamname가 승리해, 챔피언 방어";
		$a_win++;
		$a_win_p += 3;
		&win_p_rank_check("$ma_dai<>$a_id<>$a_teamname<>$a_owner<>$a_icon<>$a_win_p<>\n","$class");
		$h_lose++;
		for($i=0; $i<11; $i++){$a_hyoka_p[$i] += 80+int(rand(30));}
		$w_rensho++;
		if($class eq $dir[0]){
			if($ma_rensho1 < $w_rensho){
				$ma_rensho1 = $w_rensho;
				$ma_teamname1 = $w_teamname;
				$ma_owner1 = $w_owner;
				$ma_icon1 = $w_icon;
			}
		}else{
			if($ma_rensho2 < $w_rensho){
				$ma_rensho2 = $w_rensho;
				$ma_teamname2 = $w_teamname;
				$ma_owner2 = $w_owner;
				$ma_icon2 = $w_icon;
			}
		}
		$w_before = "「$h_teamname」에 승리해 챔피언 방어";
		$a_winmax=$w_rensho if $w_rensho>$a_winmax;
	}elsif($h_score == $a_score && $game_flg != 2){
		$comment[$comlog++] = "사투에도 결과가 나오지 않고,<b>$h_score－$a_score</b> 무승부로 끝나, 양팀 승점 1점을 손에 넣었습니다! <br>\n";
		$card="$h_teamname vs $a_teamname";
		$h_draw++;
		$h_win_p++;
		&win_p_rank_check("$ma_dai<>$h_id<>$h_teamname<>$h_owner<>$h_icon<>$h_win_p<>\n","$class");
		$a_draw++;
		$a_win_p++;
		&win_p_rank_check("$ma_dai<>$a_id<>$a_teamname<>$a_owner<>$a_icon<>$a_win_p<>\n","$class");
		for($i=0; $i<11; $i++){
			$h_hyoka_p[$i] += 40 + int(rand(15));
			$a_hyoka_p[$i] += 40 + int(rand(15));
		}
		if($change){
			$result="<b>$h_score-$a_score</b> 로 갈라 놓아 챔피언 교체";
			$w_id = $h_id;
			$w_teamname = $h_teamname;
			$w_owner = $h_owner;
			$w_icon = $h_icon;
			$w_rensho = 0;
			$w_cup = $h_cup;
			$w_before = "「$a_teamname」, 무승부로 챔피언 교체";
			$w_host = $remote_host;
		}else{
			$result="<b>$h_score-$a_score</b> 으로 갈라 놓아 챔피언 방어";
			$w_before = "「$a_teamname」에 갈라 놓아 챔피언 방어";
		}
	}else{
		if($h_pkscore > $a_pkscore){
			$comment[$comlog++] = "<br>마침내 열전에 종지부! <br>PK전의 끝에, $h_tag$h_teamname$h_tag_end가 승리를 거두었습니다! ";
			$card="$h_teamname vs $a_teamname";
			$result="<b>$h_score-$a_score($h_pkscore-$a_pkscore)</b> 로$h_teamname가 승리해, 챔피언 교체";
			$h_win++;
			$h_win2++;
			$h_win_p += 1;
  		&win_p_rank_check("$ma_dai<>$h_id<>$h_teamname<>$h_owner<>$h_icon<>$h_win_p<>\n","$class");
			$a_lose++;
			for($i=0; $i<11; $i++){$h_hyoka_p[$i] += 60+int(rand(30));}
			$w_id = $h_id;
			$w_teamname = $h_teamname;
			$w_owner = $h_owner;
			$w_icon = $h_icon;
			$w_rensho = 1;
		if($class eq $dir[0]){
			if($ma_rensho1 < $w_rensho){
				$ma_rensho1 = $w_rensho;
				$ma_teamname1 = $w_teamname;
				$ma_owner1 = $w_owner;
				$ma_icon1 = $w_icon;
			}
		}else{
			if($ma_rensho2 < $w_rensho){
				$ma_rensho2 = $w_rensho;
				$ma_teamname2 = $w_teamname;
				$ma_owner2 = $w_owner;
				$ma_icon2 = $w_icon;
			}
		}
			$w_cup = $h_cup;
			$w_before = "「$a_teamname」에 승리해 챔피언 교체";
			$w_host = $remote_host;
		}else{
			$comment[$comlog++] = "<br>마침내 열전에 종지부! <br>PK전의 끝, $a_tag$a_teamname$a_tag_end가 승리를 거두었습니다! ";
			$card="$a_teamname vs $h_teamname";
			$result="<b>$a_score-$h_score($a_pkscore-$h_pkscore)</b> 로$a_teamname가 승리해, 챔피언 방어";
			$a_win++;
			$a_win2++;
			$a_win_p += 1;
	  	&win_p_rank_check("$ma_dai<>$a_id<>$a_teamname<>$a_owner<>$a_icon<>$a_win_p<>\n","$class");
			$h_lose++;
			for($i=0; $i<11; $i++){$a_hyoka_p[$i] += 60+int(rand(30));}
			$w_rensho++;
		if($class eq $dir[0]){
			if($ma_rensho1 < $w_rensho){
				$ma_rensho1 = $w_rensho;
				$ma_teamname1 = $w_teamname;
				$ma_owner1 = $w_owner;
				$ma_icon1 = $w_icon;
			}
		}else{
			if($ma_rensho2 < $w_rensho){
				$ma_rensho2 = $w_rensho;
				$ma_teamname2 = $w_teamname;
				$ma_owner2 = $w_owner;
				$ma_icon2 = $w_icon;
			}
		}
			$w_before = "「$h_teamname」에 승리해 챔피언 방어";
			$a_winmax=$w_rensho if $w_rensho>$a_winmax;
		}
	}
	
}#END winlose

1;

#------------------------#
#  컨디션·평가  #
#------------------------#
sub condition {
	
	# 컨디션·평가점
	my $h_game = $h_win+$h_lose+$h_draw;
	my $a_game = $a_win+$a_lose+$a_draw;
	for($i=0; $i<11; $i++){
		$h_cond[$i] += int(rand(5))-2;
		if($h_cond[$i] >= 10){$h_cond[$i]=10;}
		elsif($h_cond[$i] <= 0){$h_cond[$i]=0;}
		$a_cond[$i] += int(rand(5))-2;
		if($a_cond[$i] >= 10){$a_cond[$i]=10;}
		elsif($a_cond[$i] <= 0){$a_cond[$i]=0;}
		$h_hyoka_p[$i] += $h_total[$i]*($h_cond[$i]+int(rand(3))+1)+int(rand(20));
		if($h_hyoka_p[$i] > 1000){$h_hyoka_p[$i]=1000;}
		$a_hyoka_p[$i] += $a_total[$i]*($a_cond[$i]+int(rand(3))+1)+int(rand(20));
		if($a_hyoka_p[$i] > 1000){$a_hyoka_p[$i]=1000;}
		$h_hyoka[$i] = ($h_hyoka[$i]*($h_game-1)+$h_hyoka_p[$i])/$h_game;
		$a_hyoka[$i] = ($a_hyoka[$i]*($a_game-1)+$a_hyoka_p[$i])/$a_game;
	}

}#END condition

1;

#--------------------#
#  결과 표시용 헤더  #
#--------------------#
sub kekka_header {
	
	if($icon_use){
		$h_icon_pri = "<img src=$icondir/$h_icon.gif align=middle>";
		$a_icon_pri = "<img src=$icondir/$a_icon.gif align=middle>";
	}
	
	$kekka_header = <<"_EOF_";
<table width=80%>
	<tr align=center>
	<td width=40% align=right><font color=$homecolor><big><b>$h_teamname</b></big></font>$h_icon_pri<br>(HOME)</td>
	<td><big><b>-</b></big></td>
	<td width=40% align=left>$a_icon_pri<font color=$awaycolor><big><b>$a_teamname</b></big></font><br>(AWAY)</td>
	</tr>
</table><br><br>
_EOF_

}#END kekka_header

1;

#--------------------#
#  결과 표시용 footer  #
#--------------------#
sub kekka_footer {
	
	$kekka_footer = "<center><br><br><table width=80%><tr><td width=40%>\n";
	$kekka_footer .= "<table width=100% border=1 cellspacing=0>\n";
	$kekka_footer .= "<tr><td colspan=4 align=center><big><font color=$homecolor><b>$h_teamname</b></font></big></td></tr>\n";
	for($i=0; $i<11; $i++){
		$h_hyoka_p[$i] = sprintf("%.2f",$h_hyoka_p[$i]/100);
		$kekka_footer .= "<tr><td align=center width=20%>$h_posi[$i]</td><td width=70%>$h_name[$i]</td><td align=right>$h_getscore[$i]</td><td align=right>$h_hyoka_p[$i]</td></tr>\n";
	}
	$kekka_footer .= "</table></td><td align=center>-</td><td width=40%>\n";
	$kekka_footer .= "<table width=100% border=1 cellspacing=0>\n";
	$kekka_footer .= "<tr><td colspan=4 align=center><big><font color=$awaycolor><b>$a_teamname</b></font></big></td></tr>\n";
	for($i=0; $i<11; $i++){
		$a_hyoka_p[$i] = sprintf("%.2f",$a_hyoka_p[$i]/100);
		$kekka_footer .= "<tr><td align=center width=20%>$a_posi[$i]</td><td width=70%>$a_name[$i]</td><td align=right>$a_getscore[$i]</td><td align=right>$a_hyoka_p[$i]</td></tr>\n";
	}
	$kekka_footer .= "</table></td></tr></table></center>\n";
	
}#END kekka_footer

1;

#----------------------------#
#  HOME 팀(도전자)의 공격  #
#----------------------------#
sub home_attack {
	
	if($area == 2){
		if(!$tac_flg){
			if(!$n_time){$n_time = int(rand(5))+1;}
			if($game_end eq '시합개시' || $game_end eq '연장 전반'){
				$comment[$comlog++] = "<br><b>전반$n_time분</b>이 경과했습니다<br>\n";
			}elsif($game_end eq '전반 종료' || $game_end eq '연장 후반'){
				$comment[$comlog++] = "<br><b>후반$n_time분</b>이 경과했습니다<br>\n";
			}
		}
		&get_player("home");
		if($h_posi[$kiten] eq 'GK'){
			&get_point("home","pass","$h_pass[$kiten]","A2","$kiten","$df");
			if($of_player_p > 30){
				$comment[$comlog++] = "키퍼 $h_tag$h_name[$kiten]$h_tag_end, 볼을 전방으로 완벽한 패스! <br>\n";
				$h_team_pow += 10; $h_hyoka_p[$kiten] += 20+int(rand(10));
			}elsif($of_player_p > 25){
				$comment[$comlog++] = "키퍼 $h_tag$h_name[$kiten]$h_tag_end, 볼을 전방으로 재빠르게 패스! <br>\n";
				$h_team_pow += 5; $h_hyoka_p[$kiten] += 10+int(rand(5));
			}elsif($of_player_p > 20){
				$comment[$comlog++] = "키퍼 $h_tag$h_name[$kiten]$h_tag_end, 볼을 전방에 패스! <br>\n";
				$h_hyoka_p[$kiten] += int(rand(10))-5;
			}elsif($of_player_p > 15){
				$comment[$comlog++] = "키퍼 $h_tag$h_name[$kiten]$h_tag_end, 볼을 전방으로 찼습니다만 조금 미스 킥! <br>\n";
				$h_team_pow -= 5; $h_hyoka_p[$kiten] -= 10+int(rand(5));
			}else{
				$comment[$comlog++] = "키퍼 $h_tag$h_name[$kiten]$h_tag_end, 볼을 전방으로 찼습니다만 분명하게 미스 킥! <br>\n";
				$h_team_pow -= 10; $h_hyoka_p[$kiten] -= 20+int(rand(10));
			}
			if($of_point >= $df_point){
				$comment[$comlog++] = "이것이 $h_tag$h_name[$next]$h_tag_end에게 패스 됐다! <br>\n";
				$before_action = "pass";
				$area--;
				$before = $kiten;
				$kiten = $next;
			}else{
				$comment[$comlog++] = "$a_tag$a_name[$df]$a_tag_end가 컷 했습니다! <br>$h_tag$h_name[$next]$h_tag_end에게 통하게 하지 않습니다! <br>\n";
				&attack_end;
			}
		}else{
			if(!int(rand(10)) && !$tac_flg){&fk("home");}
			$comment[$comlog++] = "자, $h_tag$h_name[$kiten]$h_tag_end가 볼을 가졌습니다! <br>\n";
			if($a_tac_zp > rand(140) && !$tac_flg){
				$tac_flg = 1;
				&zonepress("away");
			}
			my $next_play = rand(10.5);
			if($h_style[$kiten] >= $next_play){
				&get_point("home","pass","$h_pass[$kiten]","A2","$kiten","$df");
				$comment[$comlog++] = "여기서 $h_tag$h_name[$kiten]$h_tag_end가 $h_tag$h_name[$next]$h_tag_end에게 패스를 합니다. <br>\n";
				if($of_player_p > 30){
					$comment[$comlog++] = "이것은 완벽한 패스다! <br>\n";
					$h_team_pow += 10; $h_hyoka_p[$kiten] += 20+int(rand(10));
				}elsif($of_player_p > 25){
					$comment[$comlog++] = "이것은 훌륭한 패스다! <br>\n";
					$h_team_pow += 5; $h_hyoka_p[$kiten] += 10+int(rand(5));
				}elsif($of_player_p > 20){
					$comment[$comlog++] = "이것은 꽤 좋은 패스! <br>\n";
					$h_hyoka_p[$kiten] += int(rand(10))-5;
				}elsif($of_player_p > 15){
					$comment[$comlog++] = "이것은 조금 약한가? <br>\n";
					$h_team_pow -= 5; $h_hyoka_p[$kiten] -= 10+int(rand(5));
				}else{
					$comment[$comlog++] = "이것은 미스 패스인가? <br>\n";
					$h_team_pow -= 10; $h_hyoka_p[$kiten] -= 20+int(rand(10));
				}
				$comment[$comlog++] = "이 패스를 $a_tag$a_name[$df]$a_tag_end가 컷에 갑니다. <br>\n";
				if($df_player_p > 30){
					$comment[$comlog++] = "무려 $a_tag$a_name[$df]$a_tag_end! 마치 읽고 있었는지와 같이 패스코스를 막았다! <br>\n";
					$a_team_pow += 10; $a_hyoka_p[$df] += 20+int(rand(10));
				}elsif($df_player_p > 25){
					$comment[$comlog++] = "훌륭한 움직임입니다! <br>\n";
					$a_team_pow += 5; $a_hyoka_p[$df] += 10+int(rand(5));
				}elsif($df_player_p > 20){
					$comment[$comlog++] = "뛰어 갑니다! <br>\n";
					$a_hyoka_p[$df] += int(rand(10))-5;
				}elsif($df_player_p > 15){
					$comment[$comlog++] = "느리게 뛰어갑니다! <br>\n";
					$a_team_pow -= 5; $a_hyoka_p[$df] -= 10+int(rand(5));
				}else{
					$comment[$comlog++] = "수비에게 닿을것 같다 <br>\n";
					$a_team_pow -= 10; $a_hyoka_p[$df] -= 20+int(rand(10));
				}
				if($of_point >= $df_point){
					$comment[$comlog++] = "$h_tag$h_name[$kiten]$h_tag_end로부터 $h_tag$h_name[$next]$h_tag_end의 패스가 성공했다! <br>\n";
					$before_action = "pass";
					$area--;
					$before = $kiten;
					$kiten = $next;
				}else{
					$comment[$comlog++] = "$h_tag$h_name[$kiten]$h_tag_end로부터 $h_tag$h_name[$next]$h_tag_end에게의 패스를 $a_tag$a_name[$df]$a_tag_end가 컷 했습니다! <br>\n";
					&attack_end;
				}
			}elsif(10 >= $next_play){
				&get_point("home","dori","$h_dori[$kiten]","A2","$kiten","$df");
				$comment[$comlog++] = "여기서 $h_tag$h_name[$kiten]$h_tag_end가 드리블을 하며 뛰어 갑니다. <br>\n";
				if($of_player_p > 30){
					$comment[$comlog++] = "무려! 이것은 완벽한 드리블이다! <br>\n";
					$h_team_pow += 10; $h_hyoka_p[$kiten] += 20+int(rand(10));
				}elsif($of_player_p > 25){
					$comment[$comlog++] = "이것은 정말 위험한 드리블이다! <br>\n";
					$h_team_pow += 5; $h_hyoka_p[$kiten] += 10+int(rand(5));
				}elsif($of_player_p > 20){
					$comment[$comlog++] = "꽤 좋은 드리블입니다! <br>\n";
					$h_hyoka_p[$kiten] += int(rand(10))-5;
				}elsif($of_player_p > 15){
					$comment[$comlog++] = "그러나 조금 변변치않은 드리블입니다! <br>\n";
					$h_team_pow -= 5; $h_hyoka_p[$kiten] -= 10+int(rand(5));
				}else{
					$comment[$comlog++] = "이선수는 분명하게 드리블이 싫은 모양! <br>\n";
					$h_team_pow -= 10; $h_hyoka_p[$kiten] -= 20+int(rand(10));
				}
				$comment[$comlog++] = "$h_tag$h_name[$kiten]$h_tag_end의 드리블을 $a_tag$a_name[$df]$a_tag_end가 몸으로 끊으러 갑니다. <br>\n";
				if($df_player_p > 30){
					$comment[$comlog++] = "위험한 태클! 이것을 견딜 순 없다! <br>\n";
					$a_team_pow += 10; $a_hyoka_p[$df] += 20+int(rand(10));
				}elsif($df_player_p > 25){
					$comment[$comlog++] = "이것은 나이스인 슬라이딩택클! <br>\n";
					$a_team_pow += 5; $a_hyoka_p[$df] += 10+int(rand(5));
				}elsif($df_player_p > 20){
					$comment[$comlog++] = "어깨로부터 맞아 갑니다! <br>\n";
					$a_hyoka_p[$df] += int(rand(10))-5;
				}elsif($df_player_p > 15){
					$comment[$comlog++] = "이게 막아질까? <br>\n";
					$a_team_pow -= 5; $a_hyoka_p[$df] -= 10+int(rand(5));
				}else{
					$comment[$comlog++] = "왜 뛰어갔는지 모르겠습니다! <br>\n";
					$a_team_pow -= 10; $a_hyoka_p[$df] -= 20+int(rand(10));
				}
				if($of_point >= $df_point){
					$comment[$comlog++] = "$a_tag$a_name[$df]$a_tag_end의 태클을 주고 받아 $h_tag$h_name[$kiten]$h_tag_end, 드리블 돌파를 보입니다! <br>\n";
					my $pk_point = int(rand(22));
					if($h_fair[$kiten] > $pk_point){
						$comment[$comlog++] = "가, 이것은 $h_tag$h_name[$kiten]$h_tag_end의<b>파울! </b>조금 강행이었습니다! <br>\n";
						&attack_end;
						next;
					}elsif($pk_point < 9){
						$comment[$comlog++] = "이것은 반칙 휘슬! <br>\n";
					}elsif($pk_point < 15){
						$comment[$comlog++] = "매우 강행인 드리블! <br>\n";
					}elsif($pk_point < 20){
						$comment[$comlog++] = "강력한 돌파입니다! <br>\n";
					}
					$before_action = "dori";
					$area--;
				}else{
					$comment[$comlog++] = "$h_tag$h_name[$kiten]$h_tag_end의 드리블은 $a_tag$a_name[$df]$a_tag_end에게 부수어졌습니다! <br>\n";
					my $pk_point = int(rand(22));
					if($a_fair[$df] > $pk_point){
						$comment[$comlog++] = "가, 여기서 심판의 휘슬! $a_tag$a_name[$df]$a_tag_end의<b>파울</b>입니다! <br>$h_tag$h_teamname$h_tag_end,<b>프리 킥</b>이 됩니다! <br>\n";
						&fk("home");
					}elsif($pk_point < 9){
						$comment[$comlog++] = "이것은 파울을 놓쳐도 이상하지 않은 태클이었습니다! <br>\n";
					}elsif($pk_point < 15){
						$comment[$comlog++] = "꽤 강력한 태클이었습니다! <br>\n";
					}elsif($pk_point < 20){
						$comment[$comlog++] = "강력한 수비를 보입니다! <br>\n";
					}
					&attack_end;
				}
			}else{
				&get_point("home","shoo","$h_shoo[$kiten]","A2","$kiten","$a_gk");
				$comment[$comlog++] = "응? 무려 이런 멀리서<b>롱 슛! </b><br>\n";
				if($of_player_p > 30){
					$comment[$comlog++] = "! 이것은 강렬하다! <br>\n";
					$h_hyoka_p[$kiten] += 20+int(rand(10));
				}elsif($of_player_p > 25){
					$comment[$comlog++] = "이것은 호쾌! <br>\n";
					$h_hyoka_p[$kiten] += 10+int(rand(5));
				}elsif($of_player_p > 20){
					$comment[$comlog++] = "들어갈까! <br>\n";
					$h_hyoka_p[$kiten] += int(rand(10))-5;
				}elsif($of_player_p > 15){
					$comment[$comlog++] = "조금 빗겨간다! <br>\n";
					$h_hyoka_p[$kiten] -= 10+int(rand(5));
				}else{
					$comment[$comlog++] = "그러나 이것은 슛 미스인가? <br>\n";
					$h_hyoka_p[$kiten] -= 20+int(rand(10));
				}
				if($df_point-$of_point < 0){
					$comment[$comlog++] = "<b>들어갔다∼！</b>$h_tag$h_name[$kiten]$h_tag_end의 초 롱 슛이$a_tag$a_teamname$a_tag_end의 골대에 꽂혔습니다! <br>\n";
					&get_score("home","$kiten");
				}elsif($df_point-$of_point < 3){
					$comment[$comlog++] = "키퍼 $a_tag$a_name[$a_gk]$a_tag_end 펀칭! 좋은 반응입니다! <br>\n";
				}elsif($df_point-$of_point < 6){
					$comment[$comlog++] = "아깝게도 빠듯이 테두리를 빗나갔습니다! <br>\n";
				}elsif($df_point-$of_point < 9){
					$comment[$comlog++] = "키퍼 $a_tag$a_name[$a_gk]$a_tag_end의 바로 정면입니다! 튼튼한 캐치! <br>\n";
				}else{
					$comment[$comlog++] = "크게 테두리를 빗나갔습니다! <br>\n";
				}
				&attack_end;
			}
		}
	}elsif($area == 1){
		&get_player("home");
		if($h_tac_pp > rand(100) && !$tac_flg){
			$tac_flg = 1;
			if($h_posi[$kiten] ne "FW"){&postplay("home");}
		}
		my $next_play = rand(12);
		if($h_style[$kiten] >= $next_play){
			&get_point("home","pass","$h_pass[$kiten]","A1","$kiten","$df");
			if($before_action eq "pass"){
				$comment[$comlog++] = "여기서 골대로 뛰어 드는 $h_tag$h_name[$next]$h_tag_end, $h_tag$h_name[$kiten]$h_tag_end가 패스를 했습니다. <br>\n";
			}else{
				$comment[$comlog++] = "자, $h_tag$h_name[$kiten]$h_tag_end의 드리블로부터 전방의 공간에 뛰어 드는 $h_tag$h_name[$next]$h_tag_end에게 패스를 냈습니다. <br>\n";
			}
			if($of_player_p > 30){
				$comment[$comlog++] = "! 마치 질풍과 같은 킬링 패스! <br>\n";
				$h_team_pow += 10; $h_hyoka_p[$kiten] += 20+int(rand(10));
			}elsif($of_player_p > 25){
				$comment[$comlog++] = "이것은 훌륭한 스루패스다! <br>\n";
				$h_team_pow += 5; $h_hyoka_p[$kiten] += 10+int(rand(5));
			}elsif($of_player_p > 20){
				$comment[$comlog++] = "이것은 꽤 날카로운 패스다! <br>\n";
				$h_hyoka_p[$kiten] += int(rand(10))-5;
			}elsif($of_player_p > 15){
				$comment[$comlog++] = "가 조금 맞지 않는가? <br>\n";
				$h_team_pow -= 5; $h_hyoka_p[$kiten] -= 10+int(rand(5));
			}else{
				$comment[$comlog++] = "그러나 이것은 약하다! <br>\n";
				$h_team_pow -= 10; $h_hyoka_p[$kiten] -= 20+int(rand(10));
			}
			$comment[$comlog++] = "이 패스를 $a_tag$a_name[$df]$a_tag_end가 컷해 갑니다. <br>\n";
			if($df_player_p > 30){
				$comment[$comlog++] = "$a_tag$a_name[$df]$a_tag_end가 마치 읽고 있었는지 패스코스를 가로막는다! <br>\n";
				$a_team_pow += 10; $a_hyoka_p[$df] += 20+int(rand(10));
			}elsif($df_player_p > 25){
				$comment[$comlog++] = "민첩한 움직임입니다! <br>\n";
				$a_team_pow += 5; $a_hyoka_p[$df] += 10+int(rand(5));
			}elsif($df_player_p > 20){
				$comment[$comlog++] = "마크 되어 간다! <br>\n";
				$a_hyoka_p[$df] += int(rand(10))-5;
			}elsif($df_player_p > 15){
				$comment[$comlog++] = "가, 조금 움직임이 나쁘다! <br>\n";
				$a_team_pow -= 5; $a_hyoka_p[$df] -= 10+int(rand(5));
			}else{
				$comment[$comlog++] = "그러나, 닿을 것 같지 않다! <br>\n";
				$a_team_pow -= 10; $a_hyoka_p[$df] -= 20+int(rand(10));
			}
			if($of_point >= $df_point){
				$comment[$comlog++] = "$h_tag$h_name[$kiten]$h_tag_end로부터 $h_tag$h_name[$next]$h_tag_end에의 패스가 됐다! <br>이것은 절호의 골 찬스가 되었다! <br>\n";
				$before_action = "pass";
				$area--;
				$before = $kiten;
				$kiten = $next;
			}else{
				$comment[$comlog++] = "$h_tag$h_name[$kiten]$h_tag_end로부터 $h_tag$h_name[$next]$h_tag_end에의 패스를 $a_tag$a_name[$df]$a_tag_end가 컷 했습니다! <br>\n";
				if($a_tac_ca > rand(100)){
					$tac_flg = 1;
					&counter("away");
				}
				&attack_end;
			}
		}elsif(10 >= $next_play){
			&get_point("home","dori","$h_dori[$kiten]","A1","$kiten","$df");
			if($before_action eq "pass"){
				$comment[$comlog++] = "패스를 받은 $h_tag$h_name[$kiten]$h_tag_end, 골전에 드리블로 돌진해 갑니다! <br>\n";
			}else{
				$comment[$comlog++] = "$h_tag$h_name[$kiten]$h_tag_end, 한층 더 업그레이드된 드리블로 패널티 에리어내에 돌진해 갑니다! <br>\n";
			}
			if($of_player_p > 30){
				$comment[$comlog++] = "남편! 이것은 완벽한 드리블이다! 이것은 훌륭하다! <br>\n";
				$h_team_pow += 10; $h_hyoka_p[$kiten] += 20+int(rand(10));
			}elsif($of_player_p > 25){
				$comment[$comlog++] = "중심의 낮은 표본과 같은 드리블! <br>\n";
				$h_team_pow += 5; $h_hyoka_p[$kiten] += 10+int(rand(5));
			}elsif($of_player_p > 20){
				$comment[$comlog++] = "경쾌한 드리블이다! <br>\n";
				$h_hyoka_p[$kiten] += int(rand(10))-5;
			}elsif($of_player_p > 15){
				$comment[$comlog++] = "그러나 조금 발밑으로부터 볼이 떨어지기 쉽상! <br>\n";
				$h_team_pow -= 5; $h_hyoka_p[$kiten] -= 10+int(rand(5));
			}else{
				$comment[$comlog++] = "$h_tag$h_name[$kiten]$h_tag_end는 드리블이 질색인 모양! <br>\n";
				$h_team_pow -= 10; $h_hyoka_p[$kiten] -= 20+int(rand(10));
			}
			$comment[$comlog++] = "이 $h_tag$h_name[$kiten]$h_tag_end의 드리블을 $a_tag$a_name[$df]$a_tag_end가 몸으로 끊으러 갑니다. <br>\n";
			if($df_player_p > 30){
				$comment[$comlog++] = "위험한 태클! 반칙 휘슬! <br>\n";
				$a_team_pow += 10; $a_hyoka_p[$df] += 20+int(rand(10));
			}elsif($df_player_p > 25){
				$comment[$comlog++] = "잘 몸을 넣어 갔다! <br>\n";
				$a_team_pow += 5; $a_hyoka_p[$df] += 10+int(rand(5));
			}elsif($df_player_p > 20){
				$comment[$comlog++] = "격렬한 몸싸움을 보인다! <br>\n";
				$a_hyoka_p[$df] += int(rand(10))-5;
			}elsif($df_player_p > 15){
				$comment[$comlog++] = "가, 조금 맞아 패배인가? <br>\n";
				$a_team_pow -= 5; $a_hyoka_p[$df] -= 10+int(rand(5));
			}else{
				$comment[$comlog++] = "그러나 뿌리쳐질 것 같습니다! <br>\n";
				$a_team_pow -= 10; $a_hyoka_p[$df] -= 20+int(rand(10));
			}
			if($of_point >= $df_point){
				$comment[$comlog++] = "$h_tag$h_name[$kiten]$h_tag_end, $a_tag$a_name[$df]$a_tag_end의 태클을 주고 받아 골전에 돌진합니다! <br>이것은 찬스! <br>\n";
				my $pk_point = int(rand(22));
				if($h_fair[$kiten] > $pk_point){
					$comment[$comlog++] = "가, 이것은 $h_tag$h_name[$kiten]$h_tag_end의<b>파울! </b>조금 강행이었습니다! <br>\n";
					&attack_end;
					next;
				}elsif($pk_point < 9){
					$comment[$comlog++] = "이것은 반칙 휘슬! <br>\n";
				}elsif($pk_point < 15){
					$comment[$comlog++] = "매우 강행인 드리블! <br>\n";
				}elsif($pk_point < 20){
					$comment[$comlog++] = "강력한 돌파입니다! <br>\n";
				}
				$before_action = "dori";
				$area--;
			}else{
				$comment[$comlog++] = "$h_tag$h_name[$kiten]$h_tag_end의 드리블은 $a_tag$a_name[$df]$a_tag_end에 부수어졌습니다! <br>\n";
				my $pk_point = int(rand(22));
				if($a_fair[$df] > $pk_point){
					$comment[$comlog++] = "그러나 심판의 피리가 울렸다! $a_tag$a_name[$df]$a_tag_end의<b>파울</b>입니다! <br>그리고<b>PK! </b>$h_tag$h_teamname$h_tag_end, PK를 얻었습니다! <br>\n";
					&pk("home");
				}elsif($pk_point < 9){
					$comment[$comlog++] = "이것은 파울을 놓쳐도 이상하지 않은 태클이었습니다! <br>\n";
				}elsif($pk_point < 15){
					$comment[$comlog++] = "꽤 난폭한 몸싸움이었습니다! <br>\n";
				}elsif($pk_point < 20){
					$comment[$comlog++] = "강력한 수비를 보입니다! <br>\n";
				}
				if($a_tac_ca > rand(100)){
					$tac_flg = 1;
					&counter("away");
				}
				&attack_end;
			}
		}else{
			&get_point("home","shoo","$h_shoo[$kiten]","A1","$kiten","$a_gk");
			if($before_action eq "pass"){
				$comment[$comlog++] = "패스를 받은 $h_tag$h_name[$kiten]$h_tag_end, 조금 멀겠지만···그대로<b>미들 슛! </b><br>\n";
			}else{
				$comment[$comlog++] = "$h_tag$h_name[$kiten]$h_tag_end, 드리블 돌파로부터 직접<b>미들 슛! </b><br>\n";
			}
			if($of_player_p > 30){
				$comment[$comlog++] = "신음소리를 내는 것 같은 미들! <br>\n";
				$h_hyoka_p[$kiten] += 20+int(rand(10));
			}elsif($of_player_p > 25){
				$comment[$comlog++] = "이것은 강렬하다! <br>\n";
				$h_hyoka_p[$kiten] += 10+int(rand(5));
			}elsif($of_player_p > 20){
				$comment[$comlog++] = "이것은 들어갈까! <br>\n";
				$h_hyoka_p[$kiten] += int(rand(10))-5;
			}elsif($of_player_p > 15){
				$comment[$comlog++] = "가, 조금 위력이 약하다! <br>\n";
				$h_hyoka_p[$kiten] -= 10+int(rand(5));
			}else{
				$comment[$comlog++] = "그러나 이것은 슛 미스인가? <br>\n";
				$h_hyoka_p[$kiten] -= 20+int(rand(10));
			}
			if($df_point-$of_point < 0){
				$comment[$comlog++] = "<b>들어갔다∼！</b>$h_tag$h_name[$kiten]$h_tag_end의 미들 슛~! <br>\n";
				&get_score("home","$kiten");
			}elsif($df_point-$of_point < 3){
				$comment[$comlog++] = "크게 테두리를 빗나갔습니다! <br>\n";
			}elsif($df_point-$of_point < 6){
				$comment[$comlog++] = "키퍼 $a_tag$a_name[$a_gk]$a_tag_end 펀칭! 좋은 반응입니다! <br>\n";
			}elsif($df_point-$of_point < 9){
				$comment[$comlog++] = "키퍼 $a_tag$a_name[$a_gk]$a_tag_end의 바로 정면입니다! 튼튼 캐치! <br>\n";
				if($a_tac_ca > rand(100)){
					$df = $a_gk;
					$tac_flg = 1;
					&counter("away");
				}
				&attack_end;
			}else{
				$comment[$comlog++] = "아깝게도 빠듯이 테두리를 빗나갔습니다! <br>\n";
			}
			&attack_end;
		}
	}elsif($area == 0){
		&get_point("home","shoo","$h_shoo[$kiten]","A0","$kiten","$a_gk");
		if($before_action eq "pass"){
			$comment[$comlog++] = "패스를 받은 $h_tag$h_name[$kiten]$h_tag_end, GK와 1대  1! <b>슛! </b><br>\n";
		}else{
			$comment[$comlog++] = "$h_tag$h_name[$kiten]$h_tag_end, 드리블 돌파로부터 GK와 1대  1! <b>슛! </b><br>\n";
		}
		if($of_player_p > 30){
			$comment[$comlog++] = "초인적인 위력! <br>\n";
			$h_hyoka_p[$kiten] += 20+int(rand(10));
		}elsif($of_player_p > 25){
			$comment[$comlog++] = "이것은 강열~! <br>\n";
			$h_hyoka_p[$kiten] += 10+int(rand(5));
		}elsif($of_player_p > 20){
			$comment[$comlog++] = "들어갈까! <br>\n";
			$h_hyoka_p[$kiten] += int(rand(10))-5;
		}elsif($of_player_p > 15){
			$comment[$comlog++] = "가, 조금심지를 제외했다! <br>\n";
			$h_hyoka_p[$kiten] -= 10+int(rand(5));
		}else{
			$comment[$comlog++] = "그러나 이것은 슛 미스인가? <br>\n";
			$h_hyoka_p[$kiten] -= 20+int(rand(10));
		}
		if($df_point-$of_point < 0){
			$comment[$comlog++] = "<b>들어갔다∼！</b>$h_tag$h_name[$kiten]$h_tag_end의 위험한 슛~! <br>\n";
			&get_score("home","$kiten");
		}elsif($df_point-$of_point < 3){
			$comment[$comlog++] = "크게 테두리를 빗나갔습니다! <br>\n";
		}elsif($df_point-$of_point < 6){
			$comment[$comlog++] = "키퍼 $a_tag$a_name[$a_gk]$a_tag_end옆나는 일로 펀칭! <br>\n";
		}elsif($df_point-$of_point < 9){
			$comment[$comlog++] = "키퍼 $a_tag$a_name[$a_gk]$a_tag_end의 바로 정면! 캐치 했습니다! <br>\n";
			if($a_tac_ca > rand(100)){
				$df = $a_gk;
				$tac_flg = 1;
				&counter("away");
			}
			&attack_end;
		}else{
			$comment[$comlog++] = "조금범위의 밖! <br>\n";
		}
		&attack_end;
	}
}#END home_attack

1;

#----------------------------#
#  AWAY 팀(우승자)의 공격  #
#----------------------------#
sub away_attack {
	
	if($area == 2){
		if(!$tac_flg){
			if(!$n_time){$n_time = int(rand(5))+1;}
			if($game_end eq '시합개시' || $game_end eq '연장 전반'){
				$comment[$comlog++] = "<br><b>전반$n_time분</b>이 경과했습니다<br>\n";
			}elsif($game_end eq '전반 종료' || $game_end eq '연장 후반'){
				$comment[$comlog++] = "<br><b>후반$n_time분</b>이 경과했습니다<br>\n";
			}
		}
		&get_player("away");
		if($a_posi[$kiten] eq 'GK'){
			&get_point("away","pass","$a_pass[$kiten]","A2","$kiten","$df");
			if($of_player_p > 30){
				$comment[$comlog++] = "키퍼 $a_tag$a_name[$kiten]$a_tag_end, 볼을 전방에 완벽한 패스! <br>\n";
				$a_team_pow += 10; $a_hyoka_p[$kiten] += 20+int(rand(10));
			}elsif($of_player_p > 25){
				$comment[$comlog++] = "키퍼 $a_tag$a_name[$kiten]$a_tag_end, 볼을 전방에 재빠르게 패스! <br>\n";
				$a_team_pow += 5; $a_hyoka_p[$kiten] += 10+int(rand(5));
			}elsif($of_player_p > 20){
				$comment[$comlog++] = "키퍼 $a_tag$a_name[$kiten]$a_tag_end, 볼을 전방에 패스! <br>\n";
				$a_hyoka_p[$kiten] += int(rand(10))-5;
			}elsif($of_player_p > 15){
				$comment[$comlog++] = "키퍼 $a_tag$a_name[$kiten]$a_tag_end, 볼을 전방에 차기 시작했습니다만 조금 미스 킥 기색! <br>\n";
				$a_team_pow -= 5; $a_hyoka_p[$kiten] -= 10+int(rand(5));
			}else{
				$comment[$comlog++] = "키퍼 $a_tag$a_name[$kiten]$a_tag_end, 볼을 전방에 차기 시작했습니다만 분명하게 미스 킥! <br>\n";
				$a_team_pow -= 10; $a_hyoka_p[$kiten] -= 20+int(rand(10));
			}
			if($of_point >= $df_point){
				$comment[$comlog++] = "이것이 $a_tag$a_name[$next]$a_tag_end에 대로했다! <br>\n";
				$before_action = "pass";
				$area--;
				$before = $kiten;
				$kiten = $next;
			}else{
				$comment[$comlog++] = "$h_tag$h_name[$df]$h_tag_end가 컷 했습니다! <br>$a_tag$a_name[$next]$a_tag_end에 통하게 하지 않습니다! <br>\n";
				&attack_end;
			}
		}else{
			if(!int(rand(10)) && !$tac_flg){&fk("away");}
			$comment[$comlog++] = "자, $a_tag$a_name[$kiten]$a_tag_end가 볼을 가졌습니다! <br>\n";
			if($h_tac_zp > rand(140) && !$tac_flg){
				$tac_flg = 1;
				&zonepress("home");
			}
			my $next_play = rand(10.5);
			if($a_style[$kiten] >= $next_play){
				&get_point("away","pass","$a_pass[$kiten]","A2","$kiten","$df");
				$comment[$comlog++] = "여기서 $a_tag$a_name[$kiten]$a_tag_end, $a_tag$a_name[$next]$a_tag_end에 패스를 냅니다. <br>\n";
				if($of_player_p > 30){
					$comment[$comlog++] = "이것은 완벽한 패스다! <br>\n";
					$a_team_pow += 10; $a_hyoka_p[$kiten] += 20+int(rand(10));
				}elsif($of_player_p > 25){
					$comment[$comlog++] = "이것은 훌륭한 패스다! <br>\n";
					$a_team_pow += 5; $a_hyoka_p[$kiten] += 10+int(rand(5));
				}elsif($of_player_p > 20){
					$comment[$comlog++] = "이것은 꽤 좋은 패스! <br>\n";
					$a_hyoka_p[$kiten] += int(rand(10))-5;
				}elsif($of_player_p > 15){
					$comment[$comlog++] = "이것은 조금 약한가? <br>\n";
					$a_team_pow -= 5; $a_hyoka_p[$kiten] -= 10+int(rand(5));
				}else{
					$comment[$comlog++] = "이것은 미스 패스인가? <br>\n";
					$a_team_pow -= 10; $a_hyoka_p[$kiten] -= 20+int(rand(10));
				}
				$comment[$comlog++] = "이 패스를 $h_tag$h_name[$df]$h_tag_end가 컷에 갑니다. <br>\n";
				if($df_player_p > 30){
					$comment[$comlog++] = "무려 $h_tag$h_name[$df]$h_tag_end! 마치 읽고 있었는지와 같이 파스코스를 막았다! <br>\n";
					$h_team_pow += 10; $h_hyoka_p[$df] += 20+int(rand(10));
				}elsif($df_player_p > 25){
					$comment[$comlog++] = "훌륭한 움직임입니다! <br>\n";
					$h_team_pow += 5; $h_hyoka_p[$df] += 10+int(rand(5));
				}elsif($df_player_p > 20){
					$comment[$comlog++] = "대어 갑니다! <br>\n";
					$h_hyoka_p[$df] += int(rand(10))-5;
				}elsif($df_player_p > 15){
					$comment[$comlog++] = "가, 조금 대고가 달다! <br>\n";
					$h_team_pow -= 5; $h_hyoka_p[$df] -= 10+int(rand(5));
				}else{
					$comment[$comlog++] = "수비에게 닿을것 같다 <br>\n";
					$h_team_pow -= 10; $h_hyoka_p[$df] -= 20+int(rand(10));
				}
				if($of_point >= $df_point){
					$comment[$comlog++] = "$a_tag$a_name[$kiten]$a_tag_end로부터 $a_tag$a_name[$next]$a_tag_end에의 패스가 대로했다! <br>\n";
					$before_action = "pass";
					$area--;
					$before = $kiten;
					$kiten = $next;
				}else{
					$comment[$comlog++] = "$a_tag$a_name[$kiten]$a_tag_end로부터 $a_tag$a_name[$next]$a_tag_end에의 패스를 $h_tag$h_name[$df]$h_tag_end가 컷 했습니다! <br>\n";
					&attack_end;
				}
			}elsif(10 >= $next_play){
				&get_point("away","dori","$a_dori[$kiten]","A2","$kiten","$df");
				$comment[$comlog++] = "여기서 $a_tag$a_name[$kiten]$a_tag_end가 드리블로 채워 갑니다. <br>\n";
				if($of_player_p > 30){
					$comment[$comlog++] = "무려! 이것은 완벽한 드리블이다! <br>\n";
					$a_team_pow += 10; $a_hyoka_p[$kiten] += 20+int(rand(10));
				}elsif($of_player_p > 25){
					$comment[$comlog++] = "이것은 정말 위험한 드리블이다! <br>\n";
					$a_team_pow += 5; $a_hyoka_p[$kiten] += 10+int(rand(5));
				}elsif($of_player_p > 20){
					$comment[$comlog++] = "꽤 좋은 드리블입니다! <br>\n";
					$a_hyoka_p[$kiten] += int(rand(10))-5;
				}elsif($of_player_p > 15){
					$comment[$comlog++] = "그러나 조금 변변치않은 드리블입니다! <br>\n";
					$a_team_pow -= 5; $a_hyoka_p[$kiten] -= 10+int(rand(5));
				}else{
					$comment[$comlog++] = "가, 이것은 분명하게 드리블이 질색인 모양! <br>\n";
					$a_team_pow -= 10; $a_hyoka_p[$kiten] -= 20+int(rand(10));
				}
				$comment[$comlog++] = "이 $a_tag$a_name[$kiten]$a_tag_end의 드리블을 $h_tag$h_name[$df]$h_tag_end가 몸으로 끊으러 갑니다. <br>\n";
				if($df_player_p > 30){
					$comment[$comlog++] = "위험한 태클! 이것은 견딜 수 없다! <br>\n";
					$h_team_pow += 10; $h_hyoka_p[$df] += 20+int(rand(10));
				}elsif($df_player_p > 25){
					$comment[$comlog++] = "이것은 나이스인 슬라이딩택클! <br>\n";
					$h_team_pow += 5; $h_hyoka_p[$df] += 10+int(rand(5));
				}elsif($df_player_p > 20){
					$comment[$comlog++] = "어깨로부터 맞아 갑니다! <br>\n";
					$h_hyoka_p[$df] += int(rand(10))-5;
				}elsif($df_player_p > 15){
					$comment[$comlog++] = "그러나, 맞아 지고 하고 있을까? <br>\n";
					$h_team_pow -= 5; $h_hyoka_p[$df] -= 10+int(rand(5));
				}else{
					$comment[$comlog++] = "왜 뛰어갔는지 모르겠습니다! <br>\n";
					$h_team_pow -= 10; $h_hyoka_p[$df] -= 20+int(rand(10));
				}
				if($of_point >= $df_point){
					$comment[$comlog++] = "$h_tag$h_name[$df]$h_tag_end의 태클을 주고 받아 $a_tag$a_name[$kiten]$a_tag_end, 드리블 돌파를 보입니다! <br>\n";
					my $pk_point = int(rand(22));
					if($a_fair[$kiten] > $pk_point){
						$comment[$comlog++] = "가, 이것은 $a_tag$a_name[$kiten]$a_tag_end의<b>파울! </b>조금 강행이었습니다! <br>\n";
						&attack_end;
						next;
					}elsif($pk_point < 9){
						$comment[$comlog++] = "이것은 반칙 휘슬! <br>\n";
					}elsif($pk_point < 15){
						$comment[$comlog++] = "매우 강행인 드리블! <br>\n";
					}elsif($pk_point < 20){
						$comment[$comlog++] = "강력한 돌파입니다! <br>\n";
					}
					$before_action = "dori";
					$area--;
				}else{
					$comment[$comlog++] = "$a_tag$a_name[$kiten]$a_tag_end의 드리블은 $h_tag$h_name[$df]$h_tag_end에 부수어졌습니다! <br>\n";
					my $pk_point = int(rand(22));
					if($h_fair[$df] > $pk_point){
						$comment[$comlog++] = "가, 여기서 심판의 휘슬! $h_tag$h_name[$df]$h_tag_end의<b>파울</b>입니다! <br>$a_tag$a_teamname$a_tag_end,<b>프리 킥</b>이 됩니다! <br>\n";
						&fk("away");
					}elsif($pk_point < 9){
						$comment[$comlog++] = "이것은 파울을 놓쳐도 이상하지 않은 태클이었습니다! <br>\n";
					}elsif($pk_point < 15){
						$comment[$comlog++] = "꽤 란\폭\인 몸싸움이었습니다! <br>\n";
					}elsif($pk_point < 20){
						$comment[$comlog++] = "강력한 수비를 보입니다! <br>\n";
					}
					&attack_end;
				}
			}else{
				&get_point("away","shoo","$a_shoo[$kiten]","A2","$kiten","$h_gk");
				$comment[$comlog++] = "응? 무려 이런 멀리서<b>롱 슛! </b><br>\n";
				if($of_player_p > 30){
					$comment[$comlog++] = "! 이것은 강렬하다! <br>\n";
					$a_hyoka_p[$kiten] += 20+int(rand(10));
				}elsif($of_player_p > 25){
					$comment[$comlog++] = "이것은 호쾌! <br>\n";
					$a_hyoka_p[$kiten] += 10+int(rand(5));
				}elsif($of_player_p > 20){
					$comment[$comlog++] = "들어갈까! <br>\n";
					$a_hyoka_p[$kiten] += int(rand(10))-5;
				}elsif($of_player_p > 15){
					$comment[$comlog++] = "가, 조금 저스트 미트하고 있지 않다! <br>\n";
					$a_hyoka_p[$kiten] -= 10+int(rand(5));
				}else{
					$comment[$comlog++] = "그러나 이것은 슛 미스인가? <br>\n";
					$a_hyoka_p[$kiten] -= 20+int(rand(10));
				}
				if($df_point-$of_point < 0){
					$comment[$comlog++] = "<b>들어갔다∼！</b>$a_tag$a_name[$kiten]$a_tag_end의 초롱 슛이$h_tag$h_teamname$h_tag_end의 골에 꽂혔습니다! <br>\n";
					&get_score("away","$kiten");
				}elsif($df_point-$of_point < 3){
					$comment[$comlog++] = "키퍼 $h_tag$h_name[$h_gk]$h_tag_end 펀칭! 좋은 반응입니다! <br>\n";
				}elsif($df_point-$of_point < 6){
					$comment[$comlog++] = "아깝게도 빠듯이 테두리를 빗나갔습니다! <br>\n";
				}elsif($df_point-$of_point < 9){
					$comment[$comlog++] = "키퍼 $h_tag$h_name[$h_gk]$h_tag_end의 바로 정면입니다! 튼튼 캐치! <br>\n";
				}else{
					$comment[$comlog++] = "크게 테두리를 빗나갔습니다! <br>\n";
				}
				&attack_end;
			}
		}
	}elsif($area == 1){
		&get_player("away");
		if($a_tac_pp > rand(100) && !$tac_flg){
			$tac_flg = 1;
			if($a_posi[$kiten] ne "FW"){&postplay("away");}
		}
		my $next_play = rand(12);
		if($a_style[$kiten] >= $next_play){
			&get_point("away","pass","$a_pass[$kiten]","A1","$kiten","$df");
			if($before_action eq "pass"){
				$comment[$comlog++] = "여기서 골전에 뛰어 드는 $a_tag$a_name[$next]$a_tag_end에 $a_tag$a_name[$kiten]$a_tag_end가 패스를 냈습니다. <br>\n";
			}else{
				$comment[$comlog++] = "자, $a_tag$a_name[$kiten]$a_tag_end, 드리블로부터 전방의 스페이스에 뛰어 드는 $a_tag$a_name[$next]$a_tag_end에 패스를 냈습니다. <br>\n";
			}
			if($of_player_p > 30){
				$comment[$comlog++] = "! 마치 질풍과 같은 킬러 패스! <br>\n";
				$a_team_pow += 10; $a_hyoka_p[$kiten] += 20+int(rand(10));
			}elsif($of_player_p > 25){
				$comment[$comlog++] = "이것은 훌륭한 스루패스다! <br>\n";
				$a_team_pow += 5; $a_hyoka_p[$kiten] += 10+int(rand(5));
			}elsif($of_player_p > 20){
				$comment[$comlog++] = "이것은 꽤 날카로운 패스다! <br>\n";
				$a_hyoka_p[$kiten] += int(rand(10))-5;
			}elsif($of_player_p > 15){
				$comment[$comlog++] = "가 조금 맞지 않는가? <br>\n";
				$a_team_pow -= 5; $a_hyoka_p[$kiten] -= 10+int(rand(5));
			}else{
				$comment[$comlog++] = "그러나 이것은 약하다! <br>\n";
				$a_team_pow -= 10; $a_hyoka_p[$kiten] -= 20+int(rand(10));
			}
			$comment[$comlog++] = "이 패스를 $h_tag$h_name[$df]$h_tag_end가 컷에 갑니다. <br>\n";
			if($df_player_p > 30){
				$comment[$comlog++] = "무려 $h_tag$h_name[$df]$h_tag_end 마치 읽고 있었는지와 같이 파스코스에 가로막는다! <br>\n";
				$h_team_pow += 10; $h_hyoka_p[$df] += 20+int(rand(10));
			}elsif($df_player_p > 25){
				$comment[$comlog++] = "민첩한 움직임입니다! <br>\n";
				$h_team_pow += 5; $h_hyoka_p[$df] += 10+int(rand(5));
			}elsif($df_player_p > 20){
				$comment[$comlog++] = "마크에 대어 간다! <br>\n";
				$h_hyoka_p[$df] += int(rand(10))-5;
			}elsif($df_player_p > 15){
				$comment[$comlog++] = "가, 조금 움직임이 나쁘다! <br>\n";
				$h_team_pow -= 5; $h_hyoka_p[$df] -= 10+int(rand(5));
			}else{
				$comment[$comlog++] = "그러나, 닿을 것 같지 않은가? <br>\n";
				$h_team_pow -= 10; $h_hyoka_p[$df] -= 20+int(rand(10));
			}
			if($of_point >= $df_point){
				$comment[$comlog++] = "$a_tag$a_name[$kiten]$a_tag_end로부터 $a_tag$a_name[$next]$a_tag_end에의 패스가 대로했다! <br>이것은 절호의 골 찬스가 되었다! <br>\n";
				$before_action = "pass";
				$area--;
				$before = $kiten;
				$kiten = $next;
			}else{
				$comment[$comlog++] = "$a_tag$a_name[$kiten]$a_tag_end로부터 $a_tag$a_name[$next]$a_tag_end에의 패스를 $h_tag$h_name[$df]$h_tag_end가 컷 했습니다! <br>\n";
				if($h_tac_ca > rand(100)){
					$tac_flg = 1;
					&counter("home");
				}
				&attack_end;
			}
		}elsif(10 >= $next_play){
			&get_point("away","dori","$a_dori[$kiten]","A1","$kiten","$df");
			if($before_action eq "pass"){
				$comment[$comlog++] = "패스를 받은 $a_tag$a_name[$kiten]$a_tag_end, 골전에 드리블로 돌진해 갑니다! <br>\n";
			}else{
				$comment[$comlog++] = "$a_tag$a_name[$kiten]$a_tag_end, 한층 더 드리블로 패널티 에리어내에 돌진해 갑니다! <br>\n";
			}
			if($of_player_p > 30){
				$comment[$comlog++] = "남편! 이것은 완벽한 드리블이다! 이것은 훌륭하다! <br>\n";
				$a_team_pow += 10; $a_hyoka_p[$kiten] += 20+int(rand(10));
			}elsif($of_player_p > 25){
				$comment[$comlog++] = "중심의 낮은 표본과 같은 드리블! <br>\n";
				$a_team_pow += 5; $a_hyoka_p[$kiten] += 10+int(rand(5));
			}elsif($of_player_p > 20){
				$comment[$comlog++] = "경쾌한 드리블이다! <br>\n";
				$a_hyoka_p[$kiten] += int(rand(10))-5;
			}elsif($of_player_p > 15){
				$comment[$comlog++] = "그러나 조금 발밑으로부터 볼이 떨어지기 쉽상! <br>\n";
				$a_team_pow -= 5; $a_hyoka_p[$kiten] -= 10+int(rand(5));
			}else{
				$comment[$comlog++] = "가, $a_tag$a_name[$kiten]$a_tag_end는 드리블이 질색인 모양! <br>\n";
				$a_team_pow -= 10; $a_hyoka_p[$kiten] -= 20+int(rand(10));
			}
			$comment[$comlog++] = "이 $a_tag$a_name[$kiten]$a_tag_end의 드리블을 $h_tag$h_name[$df]$h_tag_end가 몸으로 끊으러 갑니다. <br>\n";
			if($df_player_p > 30){
				$comment[$comlog++] = "위험한 태클! 반칙 휘슬! <br>\n";
				$h_team_pow += 10; $h_hyoka_p[$df] += 20+int(rand(10));
			}elsif($df_player_p > 25){
				$comment[$comlog++] = "잘 몸을 넣어 갔다! <br>\n";
				$h_team_pow += 5; $h_hyoka_p[$df] += 10+int(rand(5));
			}elsif($df_player_p > 20){
				$comment[$comlog++] = "격렬한 몸싸움을 보인다! <br>\n";
				$h_hyoka_p[$df] += int(rand(10))-5;
			}elsif($df_player_p > 15){
				$comment[$comlog++] = "가, 조금 맞아 패배인가? <br>\n";
				$h_team_pow -= 5; $h_hyoka_p[$df] -= 10+int(rand(5));
			}else{
				$comment[$comlog++] = "그러나 뿌리쳐질 것 같습니다! <br>\n";
				$h_team_pow -= 10; $h_hyoka_p[$df] -= 20+int(rand(10));
			}
			if($of_point >= $df_point){
				$comment[$comlog++] = "$a_tag$a_name[$kiten]$a_tag_end, $h_tag$h_name[$df]$h_tag_end의 태클을 주고 받아 골전에 돌진합니다! <br>이것은 찬스! <br>\n";
				my $pk_point = int(rand(22));
				if($a_fair[$kiten] > $pk_point){
					$comment[$comlog++] = "가, 이것은 $a_tag$a_name[$kiten]$a_tag_end의<b>파울! </b>조금 강행이었습니다! <br>\n";
					&attack_end;
					next;
				}elsif($pk_point < 9){
					$comment[$comlog++] = "이것은 반칙 휘슬! <br>\n";
				}elsif($pk_point < 15){
					$comment[$comlog++] = "매우 강행인 드리블! <br>\n";
				}elsif($pk_point < 20){
					$comment[$comlog++] = "강력한 돌파입니다! <br>\n";
				}
				$before_action = "dori";
				$area--;
			}else{
				$comment[$comlog++] = "$a_tag$a_name[$kiten]$a_tag_end의 드리블은 $h_tag$h_name[$df]$h_tag_end에 부수어졌습니다! <br>\n";
				my $pk_point = int(rand(22));
				if($h_fair[$df] > $pk_point){
					$comment[$comlog++] = "그러나 심판의 피리가 울렸다! $h_tag$h_name[$df]$h_tag_end의<b>파울</b>입니다! <br>그리고<b>PK! </b>$a_tag$a_teamname$a_tag_end, PK를 얻었습니다! <br>\n";
					&pk("away");
				}elsif($pk_point < 9){
					$comment[$comlog++] = "이것은 파울을 놓쳐도 이상하지 않은 태클이었습니다! <br>\n";
				}elsif($pk_point < 15){
					$comment[$comlog++] = "꽤 란\폭\인 몸싸움이었습니다! <br>\n";
				}elsif($pk_point < 20){
					$comment[$comlog++] = "강력한 수비를 보입니다! <br>\n";
				}
				if($h_tac_ca > rand(100)){
					$tac_flg = 1;
					&counter("home");
				}
				&attack_end;
			}
		}else{
			&get_point("away","shoo","$a_shoo[$kiten]","A1","$kiten","$h_gk");
			if($before_action eq "pass"){
				$comment[$comlog++] = "패스를 받은 $a_tag$a_name[$kiten]$a_tag_end, 조금 멀겠지만···그대로<b>미들 슛! </b><br>\n";
			}else{
				$comment[$comlog++] = "$a_tag$a_name[$kiten]$a_tag_end, 드리블 돌파로부터 직접<b>미들 슛! </b><br>\n";
			}
			if($of_player_p > 30){
				$comment[$comlog++] = "신음소리를 내는 것 같은 미들! <br>\n";
				$a_hyoka_p[$kiten] += 20+int(rand(10));
			}elsif($of_player_p > 25){
				$comment[$comlog++] = "이것은 강렬하다! <br>\n";
				$a_hyoka_p[$kiten] += 10+int(rand(5));
			}elsif($of_player_p > 20){
				$comment[$comlog++] = "이것은 들어갈까! <br>\n";
				$a_hyoka_p[$kiten] += int(rand(10))-5;
			}elsif($of_player_p > 15){
				$comment[$comlog++] = "가, 조금 위력이 약하다! <br>\n";
				$a_hyoka_p[$kiten] -= 10+int(rand(5));
			}else{
				$comment[$comlog++] = "그러나 이것은 슛 미스인가? <br>\n";
				$a_hyoka_p[$kiten] -= 20+int(rand(10));
			}
			if($df_point-$of_point < 0){
				$comment[$comlog++] = "<b>들어갔다∼！</b>$a_tag$a_name[$kiten]$a_tag_end의 미들 슛~! <br>\n";
				&get_score("away","$kiten");
			}elsif($df_point-$of_point < 3){
				$comment[$comlog++] = "크게 테두리를 빗나갔습니다! <br>\n";
			}elsif($df_point-$of_point < 6){
				$comment[$comlog++] = "키퍼 $h_tag$h_name[$h_gk]$h_tag_end 펀칭! 좋은 반응입니다! <br>\n";
			}elsif($df_point-$of_point < 9){
				$comment[$comlog++] = "키퍼 $h_tag$h_name[$h_gk]$h_tag_end의 바로 정면입니다! 튼튼 캐치! <br>\n";
				if($h_tac_ca > rand(100)){
					$df = $h_gk;
					$tac_flg = 1;
					&counter("home");
				}
				&attack_end;
			}else{
				$comment[$comlog++] = "아깝게도 빠듯이 테두리를 빗나갔습니다! <br>\n";
			}
			&attack_end;
		}
	}elsif($area == 0){
		&get_point("away","shoo","$a_shoo[$kiten]","A0","$kiten","$h_gk");
		if($before_action eq "pass"){
			$comment[$comlog++] = "패스를 받은 $a_tag$a_name[$kiten]$a_tag_end, GK와 1대  1! <b>슛! </b><br>\n";
		}else{
			$comment[$comlog++] = "$a_tag$a_name[$kiten]$a_tag_end, 드리블 돌파로부터 GK와 1대  1! <b>슛! </b><br>\n";
		}
		if($of_player_p > 30){
			$comment[$comlog++] = "초인적인 위력! <br>\n";
			$a_hyoka_p[$kiten] += 20+int(rand(10));
		}elsif($of_player_p > 25){
			$comment[$comlog++] = "이것은 강열~! <br>\n";
			$a_hyoka_p[$kiten] += 10+int(rand(5));
		}elsif($of_player_p > 20){
			$comment[$comlog++] = "들어갈까! <br>\n";
			$a_hyoka_p[$kiten] += int(rand(10))-5;
		}elsif($of_player_p > 15){
			$comment[$comlog++] = "가, 조금심지를 제외했다! <br>\n";
			$a_hyoka_p[$kiten] -= 10+int(rand(5));
		}else{
			$comment[$comlog++] = "그러나 이것은 슛 미스인가? <br>\n";
			$a_hyoka_p[$kiten] -= 20+int(rand(10));
		}
		if($df_point-$of_point < 0){
			$comment[$comlog++] = "<b>들어갔다∼！</b>$a_tag$a_name[$kiten]$a_tag_end의 위험한 슛~! <br>\n";
			&get_score("away","$kiten");
		}elsif($df_point-$of_point < 3){
			$comment[$comlog++] = "크게 테두리를 빗나갔습니다! <br>\n";
		}elsif($df_point-$of_point < 6){
			$comment[$comlog++] = "키퍼 $h_tag$h_name[$h_gk]$h_tag_end옆나는 일로 펀칭! <br>\n";
		}elsif($df_point-$of_point < 9){
			$comment[$comlog++] = "키퍼 $h_tag$h_name[$h_gk]$h_tag_end의 바로 정면! 캐치 했습니다! <br>\n";
			if($h_tac_ca > rand(100)){
				$df = $h_gk;
				$tac_flg = 1;
				&counter("home");
			}
			&attack_end;
		}else{
			$comment[$comlog++] = "조금범위의 밖! <br>\n";
		}
		&attack_end;
	}
}#END away_attack

1;

#--------------#
#  카운터  #
#--------------#
sub counter {
	
	if($_[0] eq "home"){
		$h_team_pow=$a_team_pow; $a_team_pow=50;
		$comment[$comlog++] = "여기서 $h_tag$h_name[$df]$h_tag_end가 전선에 롱 볼을 차 붐빈다! <br>\n";
		$kiten = $df;
		$loop_count=0; # 루프 체크
		while($kiten == $df){
			&loop_check("H_CA"); # 루프 체크
			$kiten = int(rand(100));
			if($kiten <= 70){$kiten=$h_fw_no[int(rand(@h_fw_no))];}
			elsif($kiten <= 90){$kiten=$h_omf_no[int(rand(@h_omf_no))];}
			else{$kiten=$h_dmf_no[int(rand(@h_dmf_no))];}
		}
		$df = $a_df_no[int(rand(@a_df_no))];
		if($a_tac_vsca > rand(100)){
			$comment[$comlog++] = "그러나 카운터에 대비하고 있던 $a_tag$a_name[$df]$a_tag_end가 이 볼을 컷 했습니다! <br>\n";
		}else{
			$comment[$comlog++] = "이 볼을 $h_tag$h_name[$kiten]$h_tag_end가 받아<b>카운터</b>가 되었다! <br>\n";
			$comment[$comlog++] = "그러나 $a_tag$a_name[$df]$a_tag_end도 열심의 수비를 보인다! <br>\n";
			my $keypara = ($h_pass[$kiten]+$h_dori[$kiten]+$h_shoo[$kiten])/3;
			&get_point("home","","$keypara","CA1","$kiten","$df");
			if($of_player_p > 30){
				$h_team_pow += 10; $h_hyoka_p[$kiten] += 20+int(rand(10));
			}elsif($of_player_p > 25){
				$h_team_pow += 5; $h_hyoka_p[$kiten] += 10+int(rand(5));
			}elsif($of_player_p > 20){
				$h_hyoka_p[$kiten] += int(rand(10))-5;
			}elsif($of_player_p > 15){
				$h_team_pow -= 5; $h_hyoka_p[$kiten] -= 10+int(rand(5));
			}elsif($of_player_p <= 15){
				$h_team_pow -= 10; $h_hyoka_p[$kiten] -= 20+int(rand(10));
			}
			if($df_player_p > 30){
				$a_team_pow += 10; $a_hyoka_p[$df] += 20+int(rand(10));
			}elsif($df_player_p > 25){
				$a_team_pow += 5; $a_hyoka_p[$df] += 10+int(rand(5));
			}elsif($df_player_p > 20){
				$a_hyoka_p[$df] += int(rand(10))-5;
			}elsif($df_player_p > 15){
				$a_team_pow -= 5; $a_hyoka_p[$df] -= 10+int(rand(5));
			}else{
				$a_team_pow -= 10; $a_hyoka_p[$df] -= 20+int(rand(10));
			}
			if($of_point >= $df_point){
				$comment[$comlog++] = "$h_tag$h_name[$kiten]$h_tag_end, $a_tag$a_name[$df]$a_tag_end의 체크를 뿌리쳤다! <br>\n";
				$comment[$comlog++] = "이것은 결정적인가! <b>슈특! </b><br>\n";
				&get_point("home","","$h_shoo[$kiten]","CA2","$kiten","$a_gk");
				if($of_player_p > 30){$h_hyoka_p[$kiten] += 20+int(rand(10));}
				elsif($of_player_p > 25){$h_hyoka_p[$kiten] += 10+int(rand(5));}
				elsif($of_player_p > 20){$h_hyoka_p[$kiten] += int(rand(10))-5;}
				elsif($of_player_p > 15){$h_hyoka_p[$kiten] -= 10+int(rand(5));}
				else{$h_hyoka_p[$kiten] -= 20+int(rand(10));}
				if($df_player_p > 30){$a_hyoka_p[$a_gk] += 20+int(rand(10));}
				elsif($df_player_p > 25){$a_hyoka_p[$a_gk] += 10+int(rand(5));}
				elsif($df_player_p > 20){$a_hyoka_p[$a_gk] += int(rand(10))-5;}
				elsif($df_player_p > 15){$a_hyoka_p[$a_gk] -= 10+int(rand(5));}
				else{$a_hyoka_p[$a_gk] -= 20+int(rand(10));}
				if($of_point >= $df_point){
					$comment[$comlog++] = "들어갔다∼！<b>고~~르! </b>카운터가 정해진! <br>\n";
					&get_score("home","$kiten");
				}else{
					$comment[$comlog++] = "키퍼 $a_tag$a_name[$a_gk]$a_tag_end, 파인 세이브!　확실히 기적! <br>\n";
				}
			}else{
				$comment[$comlog++] = "$a_tag$a_name[$df]$a_tag_end가 볼을 빼앗아 클리어! 대핀치를 구했습니다! <br>\n";
			}
		}
	}elsif($_[0] eq "away"){
		$a_team_pow=$h_team_pow; $h_team_pow=50;
		$comment[$comlog++] = "여기서 $a_tag$a_name[$df]$a_tag_end가 전선에 롱 볼을 차 붐빈다! <br>\n";
		$kiten = $df;
		$loop_count=0; # 루프 체크
		while($kiten == $df){
			&loop_check("A_CA"); # 루프 체크
			$kiten = int(rand(100));
			if($kiten <= 70){$kiten=$a_fw_no[int(rand(@a_fw_no))];}
			elsif($kiten <= 90){$kiten=$a_omf_no[int(rand(@a_omf_no))];}
			else{$kiten=$a_dmf_no[int(rand(@a_dmf_no))];}
		}
		$df = $h_df_no[int(rand(@h_df_no))];
		if($h_tac_vsca > rand(100)){
			$comment[$comlog++] = "그러나 카운터에 대비하고 있던 $h_tag$h_name[$df]$h_tag_end가 이 볼을 컷 했습니다! <br>\n";
		}else{
			$comment[$comlog++] = "이 볼을 $a_tag$a_name[$kiten]$a_tag_end가 받아<b>카운터</b>가 되었다! <br>\n";
			$comment[$comlog++] = "그러나 $h_tag$h_name[$df]$h_tag_end도 열심의 수비를 보인다! <br>\n";
			my $keypara = ($a_pass[$kiten]+$a_dori[$kiten]+$a_shoo[$kiten])/3;
			&get_point("away","","$keypara","CA1","$kiten","$df");
			if($of_player_p > 30){
				$a_team_pow += 10; $a_hyoka_p[$kiten] += 20+int(rand(10));
			}elsif($of_player_p > 25){
				$a_team_pow += 5; $a_hyoka_p[$kiten] += 10+int(rand(5));
			}elsif($of_player_p > 20){
				$a_hyoka_p[$kiten] += int(rand(10))-5;
			}elsif($of_player_p > 15){
				$a_team_pow -= 5; $a_hyoka_p[$kiten] -= 10+int(rand(5));
			}elsif($of_player_p <= 15){
				$a_team_pow -= 10; $a_hyoka_p[$kiten] -= 20+int(rand(10));
			}
			if($df_player_p > 30){
				$h_team_pow += 10; $h_hyoka_p[$df] += 20+int(rand(10));
			}elsif($df_player_p > 25){
				$h_team_pow += 5; $h_hyoka_p[$df] += 10+int(rand(5));
			}elsif($df_player_p > 20){
				$h_hyoka_p[$df] += int(rand(10))-5;
			}elsif($df_player_p > 15){
				$h_team_pow -= 5; $h_hyoka_p[$df] -= 10+int(rand(5));
			}else{
				$h_team_pow -= 10; $h_hyoka_p[$df] -= 20+int(rand(10));
			}
			if($of_point >= $df_point){
				$comment[$comlog++] = "$a_tag$a_name[$kiten]$a_tag_end, $h_tag$h_name[$df]$h_tag_end의 체크를 뿌리쳤다! <br>\n";
				$comment[$comlog++] = "이것은 결정적인가! <b>슈특! </b><br>\n";
				&get_point("away","","$a_shoo[$kiten]","CA2","$kiten","$h_gk");
				if($of_player_p > 30){$a_hyoka_p[$kiten] += 20+int(rand(10));}
				elsif($of_player_p > 25){$a_hyoka_p[$kiten] += 10+int(rand(5));}
				elsif($of_player_p > 20){$a_hyoka_p[$kiten] += int(rand(10))-5;}
				elsif($of_player_p > 15){$a_hyoka_p[$kiten] -= 10+int(rand(5));}
				else{$a_hyoka_p[$kiten] -= 20+int(rand(10));}
				if($df_player_p > 30){$h_hyoka_p[$h_gk] += 20+int(rand(10));}
				elsif($df_player_p > 25){$h_hyoka_p[$h_gk] += 10+int(rand(5));}
				elsif($df_player_p > 20){$h_hyoka_p[$h_gk] += int(rand(10))-5;}
				elsif($df_player_p > 15){$h_hyoka_p[$h_gk] -= 10+int(rand(5));}
				else{$h_hyoka_p[$h_gk] -= 20+int(rand(10));}
				if($of_point >= $df_point){
					$comment[$comlog++] = "들어갔다∼！<b>고~~르! </b>카운터가 정해진! <br>\n";
					&get_score("away","$kiten");
				}else{
					$comment[$comlog++] = "키퍼 $h_tag$h_name[$h_gk]$h_tag_end, 파인 세이브!　확실히 기적! <br>\n";
				}
			}else{
				$comment[$comlog++] = "$h_tag$h_name[$df]$h_tag_end가 볼을 빼앗아 클리어! 대핀치를 구했습니다! <br>\n";
			}
		}
	}
	
}#END counter

1;

#----------------#
#  존 프레스  #
#----------------#
sub zonepress {
	
	if($_[0] eq "home"){
		$comment[$comlog++] = "여기서$h_tag$h_teamname$h_tag_end,<b>프레스</b>를 걸칩니다! <br>\n";
		
		if($a_tac_vszp > rand(140)){
			$comment[$comlog++] = "그러나$a_tag$a_teamname$a_tag_end, 원 투로 프레스를 주고 받습니다! <br>\n";
		}else{
			&get_point("home","","","ZP","","$df");
			if($of_point >= $df_point){
				if($of_point > 30){
					$comment[$comlog++] = "이것은 훌륭한 존 프레스! $a_tag$a_name[$kiten]$a_tag_end로부터 볼을 강탈했다! <br>\n";
				}elsif($of_point > 25){
					$comment[$comlog++] = "강렬한 존 프레스로 $a_tag$a_name[$kiten]$a_tag_end로부터 볼을 탈취! <br>\n";
				}elsif($of_point > 20){
					$comment[$comlog++] = "점차 $a_tag$a_name[$kiten]$a_tag_end를 사이드에 추적해 볼을 빼앗았다! <br>\n";
				}elsif($of_point > 15){
					$comment[$comlog++] = "상대의 미스를 타 볼을 빼앗았습니다! <br>\n";
				}else{
					$comment[$comlog++] = "완만한 프레스면서, 상대의 미스 패스를 주웠습니다! <br>\n";
				}
				$offence = "HOME";
				$area = 2;
				next;
			}else{
				$comment[$comlog++] = "그러나 $a_tag$a_name[$kiten]$a_tag_end, 프레스를 빠져 나갔습니다! <br>\n";
			}
		}
	}elsif($_[0] eq "away"){
		$comment[$comlog++] = "여기서$a_tag$a_teamname$a_tag_end,<b>프레스</b>를 걸칩니다! <br>\n";
		if($h_tac_vszp > rand(140)){
			$comment[$comlog++] = "그러나$h_tag$h_teamname$h_tag_end, 원 투로 프레스를 주고 받습니다! <br>\n";
		}else{
			&get_point("away","","","ZP","","$df");
			if($of_point >= $df_point){
				if($of_point > 30){
					$comment[$comlog++] = "이것은 훌륭한 존 프레스! $h_tag$h_name[$kiten]$h_tag_end로부터 볼을 강탈했다! <br>\n";
				}elsif($of_point > 25){
					$comment[$comlog++] = "강렬한 존 프레스로 $h_tag$h_name[$kiten]$h_tag_end로부터 볼을 탈취! <br>\n";
				}elsif($of_point > 20){
					$comment[$comlog++] = "점차 $h_tag$h_name[$kiten]$h_tag_end를 사이드에 추적해 볼을 빼앗았다! <br>\n";
				}elsif($of_point > 15){
					$comment[$comlog++] = "상대의 미스를 타 볼을 빼앗았습니다! <br>\n";
				}else{
					$comment[$comlog++] = "완만한 프레스면서, 상대의 미스 패스를 주웠습니다! <br>\n";
				}
				$offence = "AWAY";
				$area = 2;
				next;
			}else{
				$comment[$comlog++] = "그러나 $h_tag$h_name[$kiten]$h_tag_end, 프레스를 빠져 나갔습니다! <br>\n";
			}
		}
	}
	
}#END zonepress

1;

#----------------#
#  포스트플레이  #
#----------------#
sub postplay {
	
	if($_[0] eq "home"){
		$next=$h_fw_no[int(rand(@h_fw_no))];
		$comment[$comlog++] = "여기서 $h_tag$h_name[$kiten]$h_tag_end가 전선의 $h_tag$h_name[$next]$h_tag_end에 쐐기의 패스를 입금시켜 갑니다! <br>\n";
		if($a_tac_vspp > rand(100)){
			$comment[$comlog++] = "그러나$a_tag$a_teamname$a_tag_end, $h_tag$h_name[$next]$h_tag_end에의 밀착 마크로 볼에 손대게 하지 않습니다! <br>\n";
			&attack_end;
			next;
		}
		$kiten = $next;
		my $keypara = ($h_pass[$kiten]+$h_dori[$kiten]+$h_shoo[$kiten])/3;
		&get_point("home","","$keypara","PP1","$kiten","");
		if($of_point >= $df_point){
			if($of_point > 30){
				$comment[$comlog++] = "$h_tag$h_name[$kiten]$h_tag_end! 이것은 월드 클래스의 포스트플레이다! <br>\n";
				$h_hyoka_p[$kiten] += 30+int(rand(10));
				$h_team_pow += 50; $a_team_pow -= 50;
			}elsif($of_point > 25){
				$comment[$comlog++] = "$h_tag$h_name[$kiten]$h_tag_end! 이것을 훌륭한 포스트플레이로 처리한! <br>\n";
				$h_hyoka_p[$kiten] += 20+int(rand(10));
				$h_team_pow += 30; $a_team_pow -= 30;
			}elsif($of_point > 20){
				$comment[$comlog++] = "$h_tag$h_name[$kiten]$h_tag_end, 이것을 빈틈없이 처리해 찬스 메이크! <br>\n";
				$h_hyoka_p[$kiten] += 10+int(rand(10));
				$h_team_pow += 15; $a_team_pow -= 15;
			}elsif($of_point > 15){
				$comment[$comlog++] = "$h_tag$h_name[$kiten]$h_tag_end, 무난히 포스트를 해냈습니다! <br>\n";
				$h_hyoka_p[$kiten] += int(rand(10))-5;
				$h_team_pow += 5; $a_team_pow -= 5;
			}else{
				$comment[$comlog++] = "$h_tag$h_name[$kiten]$h_tag_end, 등에 울려 있고 포스트플레이입니다! <br>\n";
				$h_hyoka_p[$kiten] -= 10+int(rand(10));
			}
			$next = $kiten;
			$loop_count=0; # 루프 체크
			while($kiten == $next){
				&loop_check("H_PP01"); # 루프 체크
				$next = int(rand(100));
				if($next <= 60){$next=$h_fw_no[int(rand(@h_fw_no))];}
				elsif($next <= 80){$next=$h_omf_no[int(rand(@h_omf_no))];}
				elsif($next <= 95){$next=$h_dmf_no[int(rand(@h_dmf_no))];}
				else{$next=$h_df_no[int(rand(@h_df_no))];}
			}
			$kiten = $next;
			$comment[$comlog++] = "이 볼을 $h_tag$h_name[$kiten]$h_tag_end가<b>슛</b>에 말했다! <br>\n";
			&get_point("home","","$h_shoo[$kiten]","PP2","$kiten","$a_gk");
			if($of_point >= $df_point){
				$comment[$comlog++] = "들어갔다∼！<b>고~~르! </b>$h_tag$h_teamname$h_tag_end의 포스트플레이 작렬~! <br>\n";
				&get_score("home","$kiten");
			}else{
				$comment[$comlog++] = "키퍼 $a_tag$a_name[$a_gk]$a_tag_end, 펀칭! $h_tag$h_teamname$h_tag_end 써포터 한숨! <br>\n";
			}
		}else{
			$comment[$comlog++] = "그러나 $h_tag$h_name[$kiten]$h_tag_end, 어이없게 부수어졌습니다! <br>\n";
		}
		&attack_end;
		next;
	}elsif($_[0] eq "away"){
		$next=$a_fw_no[int(rand(@a_fw_no))];
		$comment[$comlog++] = "여기서 $a_tag$a_name[$kiten]$a_tag_end가 전선의 $a_tag$a_name[$next]$a_tag_end에 쐐기의 패스를 입금시켜 갑니다! <br>\n";
		if($h_tac_vspp > rand(100)){
			$comment[$comlog++] = "그러나$h_tag$h_teamname$h_tag_end, $a_tag$a_name[$next]$a_tag_end에의 밀착 마크로 볼에 손대게 하지 않습니다! <br>\n";
			&attack_end;
			next;
		}
		$kiten = $next;
		my $keypara = ($a_pass[$kiten]+$a_dori[$kiten]+$a_shoo[$kiten])/3;
		&get_point("away","","$keypara","PP1","$kiten","");
		if($of_point >= $df_point){
			if($of_point > 30){
				$comment[$comlog++] = "$a_tag$a_name[$kiten]$a_tag_end! 이것은 월드 클래스의 포스트플레이다! <br>\n";
				$a_hyoka_p[$kiten] += 30+int(rand(10));
				$a_team_pow += 50; $h_team_pow -= 50;
			}elsif($of_point > 25){
				$comment[$comlog++] = "$a_tag$a_name[$kiten]$a_tag_end! 이것을 훌륭한 포스트플레이로 처리한! <br>\n";
				$a_hyoka_p[$kiten] += 20+int(rand(10));
				$a_team_pow += 30; $h_team_pow -= 30;
			}elsif($of_point > 20){
				$comment[$comlog++] = "$a_tag$a_name[$kiten]$a_tag_end, 이것을 빈틈없이 처리해 찬스 메이크! <br>\n";
				$a_hyoka_p[$kiten] += 10+int(rand(10));
				$a_team_pow += 15; $h_team_pow -= 15;
			}elsif($of_point > 15){
				$comment[$comlog++] = "$a_tag$a_name[$kiten]$a_tag_end, 무난히 포스트를 해냈습니다! <br>\n";
				$a_hyoka_p[$kiten] += int(rand(10))-5;
				$a_team_pow += 5; $h_team_pow -= 5;
			}else{
				$comment[$comlog++] = "$a_tag$a_name[$kiten]$a_tag_end, 등에 울려 있고 포스트플레이입니다! <br>\n";
				$a_hyoka_p[$kiten] -= 10+int(rand(10));
			}
			$next = $kiten;
			$loop_count=0; # 루프 체크
			while($kiten == $next){
				&loop_check("A_PP01"); # 루프 체크
				$next = int(rand(100));
				if($next <= 60){$next=$a_fw_no[int(rand(@a_fw_no))];}
				elsif($next <= 80){$next=$a_omf_no[int(rand(@a_omf_no))];}
				elsif($next <= 95){$next=$a_dmf_no[int(rand(@a_dmf_no))];}
				else{$next=$a_df_no[int(rand(@a_df_no))];}
			}
			$kiten = $next;
			$comment[$comlog++] = "이 볼을 $a_tag$a_name[$kiten]$a_tag_end가<b>슛</b>에 말했다! <br>\n";
			&get_point("away","","$a_shoo[$kiten]","PP2","$kiten","$h_gk");
			if($of_point >= $df_point){
				$comment[$comlog++] = "들어갔다∼！<b>고~~르! </b>$a_tag$a_teamname$a_tag_end의 포스트플레이 작렬~! <br>\n";
				&get_score("away","$kiten");
			}else{
				$comment[$comlog++] = "키퍼 $h_tag$h_name[$h_gk]$h_tag_end, 펀칭! $h_tag$h_teamname$h_tag_end 써포터대환성! <br>\n";
			}
		}else{
			$comment[$comlog++] = "그러나 $a_tag$a_name[$kiten]$a_tag_end, 어이없게 부수어졌습니다! <br>\n";
		}
		&attack_end;
		next;
	}
	
}#END postplay

1;

#--------------------#
#  플레이어의 결정  #
#--------------------#
sub get_player {
	
	#										 A0  A1  A2  CA1 CA2 ZP  PP1 PP2 FK1 FK2
	local @o_fw_appr	=	(100, 50, 30 , 1.0, 1.0, 1.0, 0.0, 1.0, 0.0, 0.0);
	local @o_omf_appr	=	( 50,100, 80 , 0.5, 1.0, 0.9, 0.0, 0.8, 0.0, 0.0);
	local @o_dmf_appr	=	( 20, 30, 40 , 0.2, 1.0, 0.8, 0.0, 0.5, 0.0, 0.0);
	local @o_df_appr	=	( 10, 20, 30 , 0.0, 1.0, 0.7, 0.0, 0.0, 0.0, 0.0);
	local @d_fw_appr	=	( 10, 10, 20 , 0.0, 0.0, 0.0, 0.7, 0.0, 0.0, 0.0);
	local @d_omf_appr	=	( 20, 20, 30 , 0.2, 0.1, 0.0, 0.8, 0.5, 0.0, 0.0);
	local @d_dmf_appr	=	( 50, 50,100 , 0.5, 0.2, 0.0, 0.9, 0.7, 0.0, 0.0);
	local @d_df_appr	=	(100,100, 50 , 1.0, 0.5, 0.0, 1.0, 0.9, 0.1, 0.1);
	
	if($_[0] eq "home"){
		if($area == 2){
			# 기점 플레이어(HOME)의 결정
			my @appr = ($o_fw_appr[$area]*@h_fw_no,$o_omf_appr[$area]*@h_omf_no,$o_dmf_appr[$area]*@h_dmf_no,$o_df_appr[$area]*@h_df_no);
			kiten:{
				$kiten = rand($appr[0]+$appr[1]+$appr[2]+$appr[3]+5);
				if($kiten <= $appr[0]){
					$kiten = $h_fw_no[int(rand(@h_fw_no))];
				}elsif($kiten <= $appr[0]+$appr[1]){
					$kiten = $h_omf_no[int(rand(@h_omf_no))];
				}elsif($kiten <= $appr[0]+$appr[1]+$appr[2]){
					$kiten = $h_dmf_no[int(rand(@h_dmf_no))];
				}elsif($kiten <= $appr[0]+$appr[1]+$appr[2]+$appr[3]){
					$kiten = $h_df_no[int(rand(@h_df_no))];
				}else{
					if($tac_flg){goto kiten;}
					else{$kiten = $h_gk;}
				}
			}
			
			# 서브 플레이어(HOME)의 결정
			@fw_no=@omf_no=@dmf_no=@df_no=();
			for($i=0; $i<11; $i++){
				if($kiten == $i){next;}
				if($h_posi[$i] eq 'DF'){push(@df_no,$i);}
				elsif($h_posi[$i] eq 'DMF'){push(@dmf_no,$i);}
				elsif($h_posi[$i] eq 'OMF'){push(@omf_no,$i);}
				elsif($h_posi[$i] eq 'FW'){push(@fw_no,$i);}
			}
			my @appr = ($o_fw_appr[$area-1]*@fw_no,$o_omf_appr[$area-1]*@omf_no,$o_dmf_appr[$area-1]*@dmf_no,$o_df_appr[$area-1]*@df_no);
			$next = rand($appr[0]+$appr[1]+$appr[2]+$appr[3]);
			if($next <= $appr[0]){
				$next = $fw_no[int(rand(@fw_no))];
			}elsif($next <= $appr[0]+$appr[1]){
				$next = $omf_no[int(rand(@omf_no))];
			}elsif($next <= $appr[0]+$appr[1]+$appr[2]){
				$next = $dmf_no[int(rand(@dmf_no))];
			}else{
				$next = $df_no[int(rand(@df_no))];
			}
			
			# 수비 플레이어(AWAY)의 결정
			my @appr = ($d_fw_appr[$area]*@a_fw_no,$d_omf_appr[$area]*@a_omf_no,$d_dmf_appr[$area]*@a_dmf_no,$d_df_appr[$area]*@a_df_no);
			$df = rand($appr[0]+$appr[1]+$appr[2]+$appr[3]);
			if($df <= $appr[0]){
				$df = $a_fw_no[int(rand(@a_fw_no))];
			}elsif($df <= $appr[0]+$appr[1]){
				$df = $a_omf_no[int(rand(@a_omf_no))];
			}elsif($df <= $appr[0]+$appr[1]+$appr[2]){
				$df = $a_dmf_no[int(rand(@a_dmf_no))];
			}else{
				$df = $a_df_no[int(rand(@a_df_no))];
			}
		}elsif($area == 1){
			# 서브 플레이어(HOME)의 결정
			@fw_no=@omf_no=@dmf_no=@df_no=();
			for($i=0; $i<11; $i++){
				if($kiten == $i){next;}
				if($h_posi[$i] eq 'DF'){push(@df_no,$i);}
				elsif($h_posi[$i] eq 'DMF'){push(@dmf_no,$i);}
				elsif($h_posi[$i] eq 'OMF'){push(@omf_no,$i);}
				elsif($h_posi[$i] eq 'FW'){push(@fw_no,$i);}
			}
			my @appr = ($o_fw_appr[$area-1]*@fw_no,$o_omf_appr[$area-1]*@omf_no,$o_dmf_appr[$area-1]*@dmf_no,$o_df_appr[$area-1]*@df_no);
			$next = rand($appr[0]+$appr[1]+$appr[2]+$appr[3]);
			if($next <= $appr[0]){
				$next = $fw_no[int(rand(@fw_no))];
			}elsif($next <= $appr[0]+$appr[1]){
				$next = $omf_no[int(rand(@omf_no))];
			}elsif($next <= $appr[0]+$appr[1]+$appr[2]){
				$next = $dmf_no[int(rand(@dmf_no))];
			}else{
				$next = $df_no[int(rand(@df_no))];
			}
			
			# 수비 플레이어(AWAY)의 결정
			@fw_no=@omf_no=@dmf_no=@df_no=();
			for($i=0; $i<11; $i++){
				if($df == $i){next;}
				if($a_posi[$i] eq 'DF'){push(@df_no,$i);}
				elsif($a_posi[$i] eq 'DMF'){push(@dmf_no,$i);}
				elsif($a_posi[$i] eq 'OMF'){push(@omf_no,$i);}
				elsif($a_posi[$i] eq 'FW'){push(@fw_no,$i);}
			}
			my @appr = ($d_fw_appr[$area]*@fw_no,$d_omf_appr[$area]*@omf_no,$d_dmf_appr[$area]*@dmf_no,$d_df_appr[$area]*@df_no);
			$df = rand($appr[0]+$appr[1]+$appr[2]+$appr[3]);
			if($df <= $appr[0]){
				$df = $fw_no[int(rand(@fw_no))];
			}elsif($df <= $appr[0]+$appr[1]){
				$df = $omf_no[int(rand(@omf_no))];
			}elsif($df <= $appr[0]+$appr[1]+$appr[2]){
				$df = $dmf_no[int(rand(@dmf_no))];
			}else{
				$df = $df_no[int(rand(@df_no))];
			}
		}
	}elsif($_[0] eq "away"){
		if($area == 2){
			# 기점 플레이어(HOME)의 결정
			my @appr = ($o_fw_appr[$area]*@a_fw_no,$o_omf_appr[$area]*@a_omf_no,$o_dmf_appr[$area]*@a_dmf_no,$o_df_appr[$area]*@a_df_no);
			kiten:{
				$kiten = rand($appr[0]+$appr[1]+$appr[2]+$appr[3]+5);
				if($kiten <= $appr[0]){
					$kiten = $a_fw_no[int(rand(@a_fw_no))];
				}elsif($kiten <= $appr[0]+$appr[1]){
					$kiten = $a_omf_no[int(rand(@a_omf_no))];
				}elsif($kiten <= $appr[0]+$appr[1]+$appr[2]){
					$kiten = $a_dmf_no[int(rand(@a_dmf_no))];
				}elsif($kiten <= $appr[0]+$appr[1]+$appr[2]+$appr[3]){
					$kiten = $a_df_no[int(rand(@a_df_no))];
				}else{
					if($tac_flg){goto kiten;}
					else{$kiten = $a_gk;}
				}
			}
			
			# 서브 플레이어(HOME)의 결정
			@fw_no=@omf_no=@dmf_no=@df_no=();
			for($i=0; $i<11; $i++){
				if($kiten == $i){next;}
				if($a_posi[$i] eq 'DF'){push(@df_no,$i);}
				elsif($a_posi[$i] eq 'DMF'){push(@dmf_no,$i);}
				elsif($a_posi[$i] eq 'OMF'){push(@omf_no,$i);}
				elsif($a_posi[$i] eq 'FW'){push(@fw_no,$i);}
			}
			my @appr = ($o_fw_appr[$area-1]*@fw_no,$o_omf_appr[$area-1]*@omf_no,$o_dmf_appr[$area-1]*@dmf_no,$o_df_appr[$area-1]*@df_no);
			$next = rand($appr[0]+$appr[1]+$appr[2]+$appr[3]);
			if($next <= $appr[0]){
				$next = $fw_no[int(rand(@fw_no))];
			}elsif($next <= $appr[0]+$appr[1]){
				$next = $omf_no[int(rand(@omf_no))];
			}elsif($next <= $appr[0]+$appr[1]+$appr[2]){
				$next = $dmf_no[int(rand(@dmf_no))];
			}else{
				$next = $df_no[int(rand(@df_no))];
			}
			
			# 수비 플레이어(AWAY)의 결정
			my @appr = ($d_fw_appr[$area]*@h_fw_no,$d_omf_appr[$area]*@h_omf_no,$d_dmf_appr[$area]*@h_dmf_no,$d_df_appr[$area]*@h_df_no);
			$df = rand($appr[0]+$appr[1]+$appr[2]+$appr[3]);
			if($df <= $appr[0]){
				$df = $h_fw_no[int(rand(@h_fw_no))];
			}elsif($df <= $appr[0]+$appr[1]){
				$df = $h_omf_no[int(rand(@h_omf_no))];
			}elsif($df <= $appr[0]+$appr[1]+$appr[2]){
				$df = $h_dmf_no[int(rand(@h_dmf_no))];
			}else{
				$df = $h_df_no[int(rand(@h_df_no))];
			}
		}elsif($area == 1){
			# 서브 플레이어(HOME)의 결정
			@fw_no=@omf_no=@dmf_no=@df_no=();
			for($i=0; $i<11; $i++){
				if($kiten == $i){next;}
				if($a_posi[$i] eq 'DF'){push(@df_no,$i);}
				elsif($a_posi[$i] eq 'DMF'){push(@dmf_no,$i);}
				elsif($a_posi[$i] eq 'OMF'){push(@omf_no,$i);}
				elsif($a_posi[$i] eq 'FW'){push(@fw_no,$i);}
			}
			my @appr = ($o_fw_appr[$area-1]*@fw_no,$o_omf_appr[$area-1]*@omf_no,$o_dmf_appr[$area-1]*@dmf_no,$o_df_appr[$area-1]*@df_no);
			$next = rand($appr[0]+$appr[1]+$appr[2]+$appr[3]);
			if($next <= $appr[0]){
				$next = $fw_no[int(rand(@fw_no))];
			}elsif($next <= $appr[0]+$appr[1]){
				$next = $omf_no[int(rand(@omf_no))];
			}elsif($next <= $appr[0]+$appr[1]+$appr[2]){
				$next = $dmf_no[int(rand(@dmf_no))];
			}else{
				$next = $df_no[int(rand(@df_no))];
			}
			
			# 수비 플레이어(AWAY)의 결정
			@fw_no=@omf_no=@dmf_no=@df_no=();
			for($i=0; $i<11; $i++){
				if($df == $i){next;}
				if($h_posi[$i] eq 'DF'){push(@df_no,$i);}
				elsif($h_posi[$i] eq 'DMF'){push(@dmf_no,$i);}
				elsif($h_posi[$i] eq 'OMF'){push(@omf_no,$i);}
				elsif($h_posi[$i] eq 'FW'){push(@fw_no,$i);}
			}
			my @appr = ($d_fw_appr[$area]*@fw_no,$d_omf_appr[$area]*@omf_no,$d_dmf_appr[$area]*@dmf_no,$d_df_appr[$area]*@df_no);
			$df = rand($appr[0]+$appr[1]+$appr[2]+$appr[3]);
			if($df <= $appr[0]){
				$df = $fw_no[int(rand(@fw_no))];
			}elsif($df <= $appr[0]+$appr[1]){
				$df = $omf_no[int(rand(@omf_no))];
			}elsif($df <= $appr[0]+$appr[1]+$appr[2]){
				$df = $dmf_no[int(rand(@dmf_no))];
			}else{
				$df = $df_no[int(rand(@df_no))];
			}
		}
	}
	
}#END get_player

1;

#--------------#
#  판정치 산출  #
#--------------#
sub get_point {
	
	if($_[3] eq "A0" || $_[1] eq "shoo"){$scene = 0;}
	elsif($_[3] eq "A1"){$scene = 1;}
	elsif($_[3] eq "A2"){$scene = 2;}
	elsif($_[3] eq "CA1"){$scene = 3;}
	elsif($_[3] eq "CA2"){$scene = 4;}
	elsif($_[3] eq "ZP"){$scene = 5;}
	elsif($_[3] eq "PP1"){$scene = 6;}
	elsif($_[3] eq "PP2"){$scene = 7;}
	elsif($_[3] eq "FK1"){$scene = 8;}
	elsif($_[3] eq "FK2"){$scene = 9;}
	
	$of_player_p = $df_player_p = 0;
	$of_point = $df_point = 0;
	
	my $h_fair = $_[1] eq "dori" ? $h_fair[$_[4]]/2 : 0;
	my $a_fair = $_[1] eq "dori" ? $a_fair[$_[5]]/2 : 0;
	
	if($_[0] eq "home"){
		if($h_posi[$_[4]] eq "DF"){
			$h_df[1] -= $h_pass[$_[4]];
			$h_df[2] -= $h_dori[$_[4]];
			$h_df[3] -= $h_shoo[$_[4]];
			$h_df[4] -= $h_defe[$_[4]];
			$h_df[5] -= $h_cond[$_[4]];
			$h_df[0] = $h_df[1]+$h_df[2]+$h_df[3]+$h_df[4];
		}elsif($h_posi[$kiten] eq "DMF"){
			$h_dmf[1] -= $h_pass[$_[4]];
			$h_dmf[2] -= $h_dori[$_[4]];
			$h_dmf[3] -= $h_shoo[$_[4]];
			$h_dmf[4] -= $h_defe[$_[4]];
			$h_dmf[5] -= $h_cond[$_[4]];
			$h_dmf[0] = $h_dmf[1]+$h_dmf[2]+$h_dmf[3]+$h_dmf[4];
		}elsif($h_posi[$_[4]] eq "OMF"){
			$h_omf[1] -= $h_pass[$_[4]];
			$h_omf[2] -= $h_dori[$_[4]];
			$h_omf[3] -= $h_shoo[$_[4]];
			$h_omf[4] -= $h_defe[$_[4]];
			$h_omf[5] -= $h_cond[$_[4]];
			$h_omf[0] = $h_omf[1]+$h_omf[2]+$h_omf[3]+$h_omf[4];
		}elsif($h_posi[$_[4]] eq "FW"){
			$h_fw[1] -= $h_pass[$_[4]];
			$h_fw[2] -= $h_dori[$_[4]];
			$h_fw[3] -= $h_shoo[$_[4]];
			$h_fw[4] -= $h_defe[$_[4]];
			$h_fw[5] -= $h_cond[$_[4]];
			$h_fw[0] = $h_fw[1]+$h_fw[2]+$h_fw[3]+$h_fw[4];
		}
		if($a_posi[$_[5]] eq "DF"){
			$a_df[1] -= $a_pass[$_[5]];
			$a_df[2] -= $a_dori[$_[5]];
			$a_df[3] -= $a_shoo[$_[5]];
			$a_df[4] -= $a_defe[$_[5]];
			$a_df[5] -= $a_cond[$_[5]];
			$a_df[0] = $a_df[1]+$a_df[2]+$a_df[3]+$a_df[4];
		}elsif($a_posi[$_[5]] eq "DMF"){
			$a_dmf[1] -= $a_pass[$_[5]];
			$a_dmf[2] -= $a_dori[$_[5]];
			$a_dmf[3] -= $a_shoo[$_[5]];
			$a_dmf[4] -= $a_defe[$_[5]];
			$a_dmf[5] -= $a_cond[$_[5]];
			$a_dmf[0] = $a_dmf[1]+$a_dmf[2]+$a_dmf[3]+$a_dmf[4];
		}elsif($a_posi[$_[5]] eq "OMF"){
			$a_omf[1] -= $a_pass[$_[5]];
			$a_omf[2] -= $a_dori[$_[5]];
			$a_omf[3] -= $a_shoo[$_[5]];
			$a_omf[4] -= $a_defe[$_[5]];
			$a_omf[5] -= $a_cond[$_[5]];
			$a_omf[0] = $a_omf[1]+$a_omf[2]+$a_omf[3]+$a_omf[4];
		}elsif($a_posi[$_[5]] eq "FW"){
			$a_fw[1] -= $a_pass[$_[5]];
			$a_fw[2] -= $a_dori[$_[5]];
			$a_fw[3] -= $a_shoo[$_[5]];
			$a_fw[4] -= $a_defe[$_[5]];
			$a_fw[5] -= $a_cond[$_[5]];
			$a_fw[0] = $a_fw[1]+$a_fw[2]+$a_fw[3]+$a_fw[4];
		}
		
		if($_[3] eq "PK"){
			$of_player_p = $_[2]+$h_cond[$_[4]]/2+$h_total[$_[4]]/3+rand(16)+$h_fair;
			# 평가점시스템
		}elsif($_[3] ne "ZP"){
			$of_player_p = $_[2]+$h_cond[$_[4]]/2+$h_total[$_[4]]/3+rand(8)+$h_fair;
			# 평가점시스템
		}
		$of_point = $of_player_p;
		
		if($_[3] =~ /A0|A1|A2|CA1|CA2|PP2/){
			$of_point += ((($h_fw[5]*$o_fw_rate[$scene]+$h_omf[5]*$o_omf_rate[$scene]+$h_dmf[5]*$o_dmf_rate[$scene]+$h_df[5]*$o_df_rate[$scene]+rand(10))*0.075)+(($h_fw[0]*$o_fw_rate[$scene]+$h_omf[0]*$o_omf_rate[$scene]+$h_dmf[0]*$o_dmf_rate[$scene]+$h_df[0]*$o_df_rate[$scene]+rand(10))*0.1))*($h_team_pow*0.01);
		}elsif($_[3] eq "ZP"){
			$of_point += ($h_fw[5]*$o_fw_rate[$scene]+$h_omf[5]*$o_omf_rate[$scene]+$h_dmf[5]*$o_dmf_rate[$scene]+$h_df[5]*$o_df_rate[$scene]+rand(10))*0.075+($h_fw[0]*$o_fw_rate[$scene]+$h_omf[0]*$o_omf_rate[$scene]+$h_dmf[0]*$o_dmf_rate[$scene]+$h_df[0]*$o_df_rate[$scene]+rand(10))*0.1;
		}
		
		# Ver2. 32에서 변경(0→8)
		my $d_bonus = 8;
		$d_bonus += $scene*2 if $_[1] eq "shoo";
		$d_bonus = 5 if $_[3] =~ /FK1|FK2|PK/;
		if($_[3] ne "ZP" && $_[3] ne "PP1"){
			$df_player_p = $a_defe[$_[5]]+$a_cond[$_[5]]/2+$a_total[$_[5]]/3+rand($d_bonus)+$a_fair;
			# 평가점시스템
		}elsif($_[3] eq "ZP"){
			$df_player_p = ($a_pass[$_[5]]+$a_dori[$_[5]]+$a_shoo[$_[5]])/3+$a_cond[$_[5]]/2+$a_total[$_[5]]/3+rand(8);
			# 평가점시스템
		}
		$df_point = $df_player_p;
		
		if($_[3] =~ /A0|A1|A2|CA1|CA2|PP1|PP2/){
			# Ver2. 32에서 변경(0.050→0.000, 0.025→0.075)
			$df_point = $df_player_p+((($a_fw[4]*$d_fw_rate[$scene]+$a_omf[4]*$d_omf_rate[$scene]+$a_dmf[4]*$d_dmf_rate[$scene]+$a_df[4]*$d_df_rate[$scene]+rand(10))*0.000)+(($a_fw[5]*$d_fw_rate[$scene]+$a_omf[5]*$d_omf_rate[$scene]+$a_dmf[5]*$d_dmf_rate[$scene]+$a_df[5]*$d_df_rate[$scene]+rand(10))*0.075)+(($a_fw[0]*$d_fw_rate[$scene]+$a_omf[0]*$d_omf_rate[$scene]+$a_dmf[0]*$d_dmf_rate[$scene]+$a_df[0]*$d_df_rate[$scene]+rand(10))*0.1))*($a_team_pow*0.01);
		}elsif($_[3] =~ /FK1|FK2/){
			$df_point = $df_player_p+$a_df[4]*$d_df_rate[$scene]+rand(10)*0.050+$a_df[5]*$d_df_rate[$scene]+rand(10)*0.025;
		}
		
		if($h_posi[$_[4]] eq "DF"){
			$h_df[1] += $h_pass[$_[4]];
			$h_df[2] += $h_dori[$_[4]];
			$h_df[3] += $h_shoo[$_[4]];
			$h_df[4] += $h_defe[$_[4]];
			$h_df[5] += $h_cond[$_[4]];
			$h_df[0] = $h_df[1]+$h_df[2]+$h_df[3]+$h_df[4];
		}elsif($h_posi[$kiten] eq "DMF"){
			$h_dmf[1] += $h_pass[$_[4]];
			$h_dmf[2] += $h_dori[$_[4]];
			$h_dmf[3] += $h_shoo[$_[4]];
			$h_dmf[4] += $h_defe[$_[4]];
			$h_dmf[5] += $h_cond[$_[4]];
			$h_dmf[0] = $h_dmf[1]+$h_dmf[2]+$h_dmf[3]+$h_dmf[4];
		}elsif($h_posi[$_[4]] eq "OMF"){
			$h_omf[1] += $h_pass[$_[4]];
			$h_omf[2] += $h_dori[$_[4]];
			$h_omf[3] += $h_shoo[$_[4]];
			$h_omf[4] += $h_defe[$_[4]];
			$h_omf[5] += $h_cond[$_[4]];
			$h_omf[0] = $h_omf[1]+$h_omf[2]+$h_omf[3]+$h_omf[4];
		}elsif($h_posi[$_[4]] eq "FW"){
			$h_fw[1] += $h_pass[$_[4]];
			$h_fw[2] += $h_dori[$_[4]];
			$h_fw[3] += $h_shoo[$_[4]];
			$h_fw[4] += $h_defe[$_[4]];
			$h_fw[5] += $h_cond[$_[4]];
			$h_fw[0] = $h_fw[1]+$h_fw[2]+$h_fw[3]+$h_fw[4];
		}
		if($a_posi[$_[5]] eq "DF"){
			$a_df[1] += $a_pass[$_[5]];
			$a_df[2] += $a_dori[$_[5]];
			$a_df[3] += $a_shoo[$_[5]];
			$a_df[4] += $a_defe[$_[5]];
			$a_df[5] += $a_cond[$_[5]];
			$a_df[0] = $a_df[1]+$a_df[2]+$a_df[3]+$a_df[4];
		}elsif($a_posi[$_[5]] eq "DMF"){
			$a_dmf[1] += $a_pass[$_[5]];
			$a_dmf[2] += $a_dori[$_[5]];
			$a_dmf[3] += $a_shoo[$_[5]];
			$a_dmf[4] += $a_defe[$_[5]];
			$a_dmf[5] += $a_cond[$_[5]];
			$a_dmf[0] = $a_dmf[1]+$a_dmf[2]+$a_dmf[3]+$a_dmf[4];
		}elsif($a_posi[$_[5]] eq "OMF"){
			$a_omf[1] += $a_pass[$_[5]];
			$a_omf[2] += $a_dori[$_[5]];
			$a_omf[3] += $a_shoo[$_[5]];
			$a_omf[4] += $a_defe[$_[5]];
			$a_omf[5] += $a_cond[$_[5]];
			$a_omf[0] = $a_omf[1]+$a_omf[2]+$a_omf[3]+$a_omf[4];
		}elsif($a_posi[$_[5]] eq "FW"){
			$a_fw[1] += $a_pass[$_[5]];
			$a_fw[2] += $a_dori[$_[5]];
			$a_fw[3] += $a_shoo[$_[5]];
			$a_fw[4] += $a_defe[$_[5]];
			$a_fw[5] += $a_cond[$_[5]];
			$a_fw[0] = $a_fw[1]+$a_fw[2]+$a_fw[3]+$a_fw[4];
		}
		
	}elsif($_[0] eq "away"){
		if($h_posi[$_[5]] eq "DF"){
			$h_df[1] -= $h_pass[$_[5]];
			$h_df[2] -= $h_dori[$_[5]];
			$h_df[3] -= $h_shoo[$_[5]];
			$h_df[4] -= $h_defe[$_[5]];
			$h_df[5] -= $h_cond[$_[5]];
			$h_df[0] = $h_df[1]+$h_df[2]+$h_df[3]+$h_df[4];
		}elsif($h_posi[$_[5]] eq "DMF"){
			$h_dmf[1] -= $h_pass[$_[5]];
			$h_dmf[2] -= $h_dori[$_[5]];
			$h_dmf[3] -= $h_shoo[$_[5]];
			$h_dmf[4] -= $h_defe[$_[5]];
			$h_dmf[5] -= $h_cond[$_[5]];
			$h_dmf[0] = $h_dmf[1]+$h_dmf[2]+$h_dmf[3]+$h_dmf[4];
		}elsif($h_posi[$_[5]] eq "OMF"){
			$h_omf[1] -= $h_pass[$_[5]];
			$h_omf[2] -= $h_dori[$_[5]];
			$h_omf[3] -= $h_shoo[$_[5]];
			$h_omf[4] -= $h_defe[$_[5]];
			$h_omf[5] -= $h_cond[$_[5]];
			$h_omf[0] = $h_omf[1]+$h_omf[2]+$h_omf[3]+$h_omf[4];
		}elsif($h_posi[$_[5]] eq "FW"){
			$h_fw[1] -= $h_pass[$_[5]];
			$h_fw[2] -= $h_dori[$_[5]];
			$h_fw[3] -= $h_shoo[$_[5]];
			$h_fw[4] -= $h_defe[$_[5]];
			$h_fw[5] -= $h_cond[$_[5]];
			$h_fw[0] = $h_fw[1]+$h_fw[2]+$h_fw[3]+$h_fw[4];
		}
		if($a_posi[$_[4]] eq "DF"){
			$a_df[1] -= $a_pass[$_[4]];
			$a_df[2] -= $a_dori[$_[4]];
			$a_df[3] -= $a_shoo[$_[4]];
			$a_df[4] -= $a_defe[$_[4]];
			$a_df[5] -= $a_cond[$_[4]];
			$a_df[0] = $a_df[1]+$a_df[2]+$a_df[3]+$a_df[4];
		}elsif($a_posi[$_[4]] eq "DMF"){
			$a_dmf[1] -= $a_pass[$_[4]];
			$a_dmf[2] -= $a_dori[$_[4]];
			$a_dmf[3] -= $a_shoo[$_[4]];
			$a_dmf[4] -= $a_defe[$_[4]];
			$a_dmf[5] -= $a_cond[$_[4]];
			$a_dmf[0] = $a_dmf[1]+$a_dmf[2]+$a_dmf[3]+$a_dmf[4];
		}elsif($a_posi[$_[4]] eq "OMF"){
			$a_omf[1] -= $a_pass[$_[4]];
			$a_omf[2] -= $a_dori[$_[4]];
			$a_omf[3] -= $a_shoo[$_[4]];
			$a_omf[4] -= $a_defe[$_[4]];
			$a_omf[5] -= $a_cond[$_[4]];
			$a_omf[0] = $a_omf[1]+$a_omf[2]+$a_omf[3]+$a_omf[4];
		}elsif($a_posi[$_[4]] eq "FW"){
			$a_fw[1] -= $a_pass[$_[4]];
			$a_fw[2] -= $a_dori[$_[4]];
			$a_fw[3] -= $a_shoo[$_[4]];
			$a_fw[4] -= $a_defe[$_[4]];
			$a_fw[5] -= $a_cond[$_[4]];
			$a_fw[0] = $a_fw[1]+$a_fw[2]+$a_fw[3]+$a_fw[4];
		}
		
		if($_[3] ne "ZP"){
			$of_player_p = $_[2]+$a_cond[$_[4]]/2+$a_total[$_[4]]/3+rand(8)+$a_fair;
			# 평가점시스템
		}
		$of_point = $of_player_p;
		
		if($_[3] =~ /A0|A1|A2|CA1|CA2|PP2/){
			$of_point += ((($a_fw[5]*$o_fw_rate[$scene]+$a_omf[5]*$o_omf_rate[$scene]+$a_dmf[5]*$o_dmf_rate[$scene]+$a_df[5]*$o_df_rate[$scene]+rand(10))*0.075)+(($a_fw[0]*$o_fw_rate[$scene]+$a_omf[0]*$o_omf_rate[$scene]+$a_dmf[0]*$o_dmf_rate[$scene]+$a_df[0]*$o_df_rate[$scene]+rand(10))*0.1))*($a_team_pow*0.01);
		}elsif($_[3] eq "ZP"){
			$of_point += ($a_fw[5]*$o_fw_rate[$scene]+$a_omf[5]*$o_omf_rate[$scene]+$a_dmf[5]*$o_dmf_rate[$scene]+$a_df[5]*$o_df_rate[$scene]+rand(10))*0.075+($a_fw[0]*$o_fw_rate[$scene]+$a_omf[0]*$o_omf_rate[$scene]+$a_dmf[0]*$o_dmf_rate[$scene]+$a_df[0]*$o_df_rate[$scene]+rand(10))*0.1;
		}
		
		# Ver2. 32에서 변경(0→8)
		my $d_bonus = 8;
		$d_bonus += $scene*2 if $_[1] eq "shoo";
		$d_bonus = 5 if $_[3] =~ /FK1|FK2|PK/;
		if($_[3] ne "ZP" && $_[3] ne "PP1"){
			$df_player_p = $h_defe[$_[5]]+$h_cond[$_[5]]/2+$h_total[$_[5]]/3+rand($d_bonus)+$h_fair;
			# 평가점시스템
		}elsif($_[3] eq "ZP"){
			$df_player_p = ($h_pass[$_[5]]+$h_dori[$_[5]]+$h_shoo[$_[5]])/3+$h_cond[$_[5]]/2+$h_total[$_[5]]/3+rand(8);
			# 평가점시스템
		}
		$df_point = $df_player_p;
		
		if($_[3] =~ /A0|A1|A2|CA1|CA2|PP1|PP2/){
			# Ver2. 32에서 변경(0.050→0.000, 0.025→0.075)
			$df_point += ((($h_fw[4]*$d_fw_rate[$scene]+$h_omf[4]*$d_omf_rate[$scene]+$h_dmf[4]*$d_dmf_rate[$scene]+$h_df[4]*$d_df_rate[$scene]+rand(10))*0.000)+(($h_fw[5]*$d_fw_rate[$scene]+$h_omf[5]*$d_omf_rate[$scene]+$h_dmf[5]*$d_dmf_rate[$scene]+$h_df[5]*$d_df_rate[$scene]+rand(10))*0.075)+(($h_fw[0]*$d_fw_rate[$scene]+$h_omf[0]*$d_omf_rate[$scene]+$h_dmf[0]*$d_dmf_rate[$scene]+$h_df[0]*$d_df_rate[$scene]+rand(10))*0.1))*($h_team_pow*0.01);
		}elsif($_[3] =~ /FK1|FK2/){
			$df_point += $h_df[4]*$d_df_rate[$scene]+rand(10)*0.050+$h_df[5]*$d_df_rate[$scene]+rand(10)*0.025;
		}
		
		if($h_posi[$_[5]] eq "DF"){
			$h_df[1] += $h_pass[$_[5]];
			$h_df[2] += $h_dori[$_[5]];
			$h_df[3] += $h_shoo[$_[5]];
			$h_df[4] += $h_defe[$_[5]];
			$h_df[5] += $h_cond[$_[5]];
			$h_df[0] = $h_df[1]+$h_df[2]+$h_df[3]+$h_df[4];
		}elsif($h_posi[$_[5]] eq "DMF"){
			$h_dmf[1] += $h_pass[$_[5]];
			$h_dmf[2] += $h_dori[$_[5]];
			$h_dmf[3] += $h_shoo[$_[5]];
			$h_dmf[4] += $h_defe[$_[5]];
			$h_dmf[5] += $h_cond[$_[5]];
			$h_dmf[0] = $h_dmf[1]+$h_dmf[2]+$h_dmf[3]+$h_dmf[4];
		}elsif($h_posi[$_[5]] eq "OMF"){
			$h_omf[1] += $h_pass[$_[5]];
			$h_omf[2] += $h_dori[$_[5]];
			$h_omf[3] += $h_shoo[$_[5]];
			$h_omf[4] += $h_defe[$_[5]];
			$h_omf[5] += $h_cond[$_[5]];
			$h_omf[0] = $h_omf[1]+$h_omf[2]+$h_omf[3]+$h_omf[4];
		}elsif($h_posi[$_[5]] eq "FW"){
			$h_fw[1] += $h_pass[$_[5]];
			$h_fw[2] += $h_dori[$_[5]];
			$h_fw[3] += $h_shoo[$_[5]];
			$h_fw[4] += $h_defe[$_[5]];
			$h_fw[5] += $h_cond[$_[5]];
			$h_fw[0] = $h_fw[1]+$h_fw[2]+$h_fw[3]+$h_fw[4];
		}
		if($a_posi[$_[4]] eq "DF"){
			$a_df[1] += $a_pass[$_[4]];
			$a_df[2] += $a_dori[$_[4]];
			$a_df[3] += $a_shoo[$_[4]];
			$a_df[4] += $a_defe[$_[4]];
			$a_df[5] += $a_cond[$_[4]];
			$a_df[0] = $a_df[1]+$a_df[2]+$a_df[3]+$a_df[4];
		}elsif($a_posi[$_[4]] eq "DMF"){
			$a_dmf[1] += $a_pass[$_[4]];
			$a_dmf[2] += $a_dori[$_[4]];
			$a_dmf[3] += $a_shoo[$_[4]];
			$a_dmf[4] += $a_defe[$_[4]];
			$a_dmf[5] += $a_cond[$_[4]];
			$a_dmf[0] = $a_dmf[1]+$a_dmf[2]+$a_dmf[3]+$a_dmf[4];
		}elsif($a_posi[$_[4]] eq "OMF"){
			$a_omf[1] += $a_pass[$_[4]];
			$a_omf[2] += $a_dori[$_[4]];
			$a_omf[3] += $a_shoo[$_[4]];
			$a_omf[4] += $a_defe[$_[4]];
			$a_omf[5] += $a_cond[$_[4]];
			$a_omf[0] = $a_omf[1]+$a_omf[2]+$a_omf[3]+$a_omf[4];
		}elsif($a_posi[$_[4]] eq "FW"){
			$a_fw[1] += $a_pass[$_[4]];
			$a_fw[2] += $a_dori[$_[4]];
			$a_fw[3] += $a_shoo[$_[4]];
			$a_fw[4] += $a_defe[$_[4]];
			$a_fw[5] += $a_cond[$_[4]];
			$a_fw[0] = $a_fw[1]+$a_fw[2]+$a_fw[3]+$a_fw[4];
		}
	}
	
#	$comment[$comlog++] = "<br>of_player_p : $of_player_p ///df_player_p : $df_player_p";
#	$comment[$comlog++] = "<br>of_point : $of_point /// df_point : $df_point<br><br>";
	
	
}#end get_point

1;

#--------#
#  FK  #
#--------#
sub fk {
	
	if($_[0] eq "home"){
		my @kickers=();
		for($i=0; $i<11; $i++){push @kickers, $i if $h_fk[$i] eq "○";}
		my $fk = $kickers[int(rand(@kickers))];
		$comment[$comlog++] = "자 $h_tag$h_teamname$h_tag_end! <b>프리 킥</b>의 찬스를 얻었습니다! <br>킥커는 $h_tag$h_name[$fk]$h_tag_end! <br>\n";
		if(int(rand(2))){
			my $keypara = ($h_pass[$fk]+$h_shoo[$fk])/2;
			&get_point("home","","$keypara","FK1","$fk","$a_gk");
			if($of_point > 30){
				$comment[$comlog++] = "직접 노렸다! 세계 클래스의 킥! <br>\n";
				$h_hyoka_p[$fk] += 30+int(rand(20));
			}elsif($of_point > 25){
				$comment[$comlog++] = "직접 노렸다! 훌륭한 킥이다! <br>\n";
				$h_hyoka_p[$fk] += 20+int(rand(10));
			}elsif($of_point > 20){
				$comment[$comlog++] = "직접! 커브를 걸친! <br>\n";
				$h_hyoka_p[$fk] += 10+int(rand(5));
			}elsif($of_point > 15){
				$comment[$comlog++] = "직접 말했다! 들어간다! <br>\n";
				$h_hyoka_p[$fk] -= int(rand(10))-5;
			}else{
				$comment[$comlog++] = "직접 말했지만···조금 약하다! <br>\n";
				$h_hyoka_p[$fk] -= 10+int(rand(5));
			}
			if($of_point >= $df_player_p){
				if($of_point >= $df_point){
					$comment[$comlog++] = "<b>정해졌다∼</b>, $h_tag$h_name[$fk]$h_tag_end의 프리 킥이 직접 골 마우스에 꽂혔습니다! <br>\n";
					&get_score("home","$fk");
				}else{
					if($df_player_p > 30){
						$comment[$comlog++] = "이것을 키퍼 $a_tag$a_name[$a_gk]$a_tag_end, 완벽하게 캐치! 확실히 철벽! <br>\n";
						$a_hyoka_p[$a_gk] += 20+int(rand(20));
					}elsif($df_player_p > 25){
						$comment[$comlog++] = "이것을 키퍼 $a_tag$a_name[$a_gk]$a_tag_end, 여유를 가져 펀칭! 읽기가 즈바리! <br>\n";
						$a_hyoka_p[$a_gk] += 15+int(rand(10));
					}elsif($df_player_p > 20){
						$comment[$comlog++] = "이것을 키퍼 $a_tag$a_name[$a_gk]$a_tag_end, 펀칭! 확실히 절박함! <br>\n";
						$a_hyoka_p[$a_gk] += 5+int(rand(5));
					}elsif($df_player_p > 15){
						$comment[$comlog++] = "이것은 테두리의 밖, 빠듯이 빗나갔습니다! <br>\n";
						$a_hyoka_p[$a_gk] -= int(rand(8))-5;
					}else{
						$comment[$comlog++] = "이것은 크게 테두리를 빗나갔습니다! <br>\n";
						$a_hyoka_p[$a_gk] -= 10+int(rand(5));
					}
				}
			}else{
				$comment[$comlog++] = "벽에 해당되어 볼은 사이드 라인을 나누었습니다! <br>장내$h_tag$h_teamname$h_tag_end 써포터 한숨! <br>\n";
			}
		}else{
			$df = $a_df_no[int(rand(@a_df_no))];
			my $keypara = ($h_pass[$fk]+$h_shoo[$fk])/2;
			&get_point("home","","$keypara","FK2","$fk","$df");
			$next = $fk;
			$loop_count=0; # 루프 체크
			while($fk == $next){
				&loop_check("H_FK01"); # 루프 체크
				$next = int(rand(10))+1;
			}
			if($of_point > 30){
				$comment[$comlog++] = "찬! 직접 노리지 않고 핀 포인트로 $h_tag$h_name[$next]$h_tag_end에 맞추었다! <br>\n";
				$h_hyoka_p[$fk] += 20+int(rand(20));
			}elsif($of_point > 25){
				$comment[$comlog++] = "찬! 정확한 컨트롤로 $h_tag$h_name[$next]$h_tag_end에 맞추었다! <br>\n";
				$h_hyoka_p[$fk] += 10+int(rand(10));
			}elsif($of_point > 20){
				$comment[$comlog++] = "찼다! 이 볼에 $h_tag$h_name[$next]$h_tag_end가 대면시키러 간다! <br>\n";
				$h_hyoka_p[$fk] += int(rand(5))-5;
			}elsif($of_point > 15){
				$comment[$comlog++] = "찼다! 하지만 조금 정확함을 빠뜨리고 있을까? <br>\n";
				$h_hyoka_p[$fk] -= 10+int(rand(10));
			}else{
				$comment[$comlog++] = "찼다! 하지만 허약한 킥! <br>\n";
				$h_hyoka_p[$fk] -= 20+int(rand(20));
			}
			$comment[$comlog++] = "이것에 $a_tag$a_name[$df]$a_tag_end, 머리로 컷에 간다! <br>\n";
			if($of_point >= $df_point){
				$comment[$comlog++] = "그러나 닿지 않는다! <br>$h_tag$h_name[$next]$h_tag_end, 헤딩에서 만나게 한다! <br>\n";
				my $keypara = ($h_pass[$next]+$h_dori[$next]+$h_shoo[$next])/3;
				&get_point("home","","$keypara","FK3","$next","$a_gk");
				if($of_point >= $df_point){
					$comment[$comlog++] = "들어갔다∼！<b>고~~르! </b>$h_tag$h_name[$next]$h_tag_end가 결정했다∼！<br>\n";
					&get_score("home","$next");
				}else{
					if($df_point > 30){
						$comment[$comlog++] = "이것을 키퍼 $a_tag$a_name[$a_gk]$a_tag_end, 완벽하게 캐치! 확실히 철벽! <br>\n";
						$a_hyoka_p[$a_gk] += 20+int(rand(20));
					}elsif($df_point > 25){
						$comment[$comlog++] = "이것을 키퍼 $a_tag$a_name[$a_gk]$a_tag_end, 여유를 가져 캐팅! <br>\n";
						$a_hyoka_p[$a_gk] += 15+int(rand(10));
					}elsif($df_point > 20){
						$comment[$comlog++] = "키퍼 $a_tag$a_name[$a_gk]$a_tag_end, 이것을 빈틈없이 펀칭! <br>\n";
						$a_hyoka_p[$a_gk] += 5+int(rand(5));
					}elsif($df_point > 15){
						$comment[$comlog++] = "이것은 골포스트 빠듯이! 아깝게도 빗나갔습니다! <br>\n";
						$a_hyoka_p[$a_gk] -= int(rand(8))-5;
					}else{
						$comment[$comlog++] = "이것은 테두리에 말하지 않았습니다! <br>\n";
						$a_hyoka_p[$a_gk] -= 10+int(rand(5));
					}
				}
			}else{
				$comment[$comlog++] = "$a_tag$a_name[$df]$a_tag_end, 크고 클리어! <br>\n";
			}
		}
	}elsif($_[0] eq "away"){
		my @kickers=();
		for($i=0; $i<11; $i++){push @kickers, $i if $a_fk[$i] eq "○";}
		my $fk = $kickers[int(rand(@kickers))];
		$comment[$comlog++] = "자 $a_tag$a_teamname$a_tag_end! <b>프리 킥</b>의 찬스를 얻었습니다! <br>킥커는 $a_tag$a_name[$fk]$a_tag_end! <br>\n";
		if(int(rand(2))){
			my $keypara = ($a_pass[$fk]+$a_shoo[$fk])/2;
			&get_point("away","","$keypara","FK1","$fk","$h_gk");
			if($of_point > 30){
				$comment[$comlog++] = "직접 노렸다! 세계 클래스의 킥! <br>\n";
				$a_hyoka_p[$fk] += 30+int(rand(20));
			}elsif($of_point > 25){
				$comment[$comlog++] = "직접 노렸다! 훌륭한 킥이다! <br>\n";
				$a_hyoka_p[$fk] += 20+int(rand(10));
			}elsif($of_point > 20){
				$comment[$comlog++] = "직접! 커브를 걸친! <br>\n";
				$a_hyoka_p[$fk] += 10+int(rand(5));
			}elsif($of_point > 15){
				$comment[$comlog++] = "직접 말했다! 들어간다! <br>\n";
				$a_hyoka_p[$fk] -= int(rand(10))-5;
			}else{
				$comment[$comlog++] = "직접 말했지만···조금 약하다! <br>\n";
				$a_hyoka_p[$fk] -= 10+int(rand(5));
			}
			if($of_point >= $df_player_p){
				if($of_point >= $df_point){
					$comment[$comlog++] = "<b>정해졌다∼</b>, $a_tag$a_name[$fk]$a_tag_end의 프리 킥이 직접 골 마우스에 꽂혔습니다! <br>\n";
					&get_score("away","$fk");
				}else{
					if($df_player_p > 30){
						$comment[$comlog++] = "이것을 키퍼 $h_tag$h_name[$h_gk]$h_tag_end, 완벽하게 캐치! 확실히 철벽! <br>\n";
						$h_hyoka_p[$h_gk] += 20+int(rand(20));
					}elsif($df_player_p > 25){
						$comment[$comlog++] = "이것을 키퍼 $h_tag$h_name[$h_gk]$h_tag_end, 여유를 가져 펀칭! 읽기가 즈바리! <br>\n";
						$h_hyoka_p[$h_gk] += 15+int(rand(10));
					}elsif($df_player_p > 20){
						$comment[$comlog++] = "이것을 키퍼 $h_tag$h_name[$h_gk]$h_tag_end, 펀칭! 확실히 절박함! <br>\n";
						$h_hyoka_p[$h_gk] += 5+int(rand(5));
					}elsif($df_player_p > 15){
						$comment[$comlog++] = "이것은 테두리의 밖, 빠듯이 빗나갔습니다! <br>\n";
						$h_hyoka_p[$h_gk] -= int(rand(8))-5;
					}else{
						$comment[$comlog++] = "이것은 크게 테두리를 빗나갔습니다! <br>\n";
						$h_hyoka_p[$h_gk] -= 10+int(rand(5));
					}
				}
			}else{
				$comment[$comlog++] = "벽에 해당되어 볼은 사이드 라인을 나누었습니다! <br>장내$h_teamname 써포터대환성! <br>\n";
			}
		}else{
			$df = $h_df_no[int(rand(@h_df_no))];
			my $keypara = ($a_pass[$fk]+$a_shoo[$fk])/2;
			&get_point("away","","$keypara","FK2","$fk","$df");
			$next = $fk;
			$loop_count=0; # 루프 체크
			while($fk == $next){
				&loop_check("A_FK01"); # 루프 체크
				$next = int(rand(10))+1;
			}
			if($of_point > 30){
				$comment[$comlog++] = "찬! 직접 노리지 않고 핀 포인트로 $a_tag$a_name[$next]$a_tag_end에 맞추었다! <br>\n";
				$a_hyoka_p[$fk] += 20+int(rand(20));
			}elsif($of_point > 25){
				$comment[$comlog++] = "찬! 정확한 컨트롤로 $a_tag$a_name[$next]$a_tag_end에 맞추었다! <br>\n";
				$a_hyoka_p[$fk] += 10+int(rand(10));
			}elsif($of_point > 20){
				$comment[$comlog++] = "찼다! 이 볼에 $a_tag$a_name[$next]$a_tag_end가 대면시키러 간다! <br>\n";
				$a_hyoka_p[$fk] += int(rand(5))-5;
			}elsif($of_point > 15){
				$comment[$comlog++] = "찼다! 하지만 조금 정확함을 빠뜨리고 있을까? <br>\n";
				$a_hyoka_p[$fk] -= 10+int(rand(10));
			}else{
				$comment[$comlog++] = "찼다! 하지만 허약한 킥! <br>\n";
				$a_hyoka_p[$fk] -= 20+int(rand(20));
			}
			$comment[$comlog++] = "이것에 $h_tag$h_name[$df]$h_tag_end, 머리로 컷에 간다! <br>\n";
			if($of_point >= $df_point){
				$comment[$comlog++] = "그러나 닿지 않는다! <br>$a_tag$a_name[$next]$a_tag_end, 헤딩에서 만나게 한다! <br>\n";
				my $keypara = ($a_pass[$next]+$a_dori[$next]+$a_shoo[$next])/3;
				&get_point("away","","$keypara","FK3","$next","$h_gk");
				if($of_point >= $df_point){
					$comment[$comlog++] = "들어갔다∼！<b>고~~르! </b>$a_tag$a_name[$next]$a_tag_end가 결정했다∼！<br>\n";
					&get_score("away","$next");
				}else{
					if($df_point > 30){
						$comment[$comlog++] = "이것을 키퍼 $h_tag$h_name[$h_gk]$h_tag_end, 완벽하게 캐치! 확실히 철벽! <br>\n";
						$h_hyoka_p[$h_gk] += 20+int(rand(20));
					}elsif($df_point > 25){
						$comment[$comlog++] = "이것을 키퍼 $h_tag$h_name[$h_gk]$h_tag_end, 여유를 가져 캐팅! <br>\n";
						$h_hyoka_p[$h_gk] += 15+int(rand(10));
					}elsif($df_point > 20){
						$comment[$comlog++] = "키퍼 $h_tag$h_name[$h_gk]$h_tag_end, 이것을 빈틈없이 펀칭! <br>\n";
						$h_hyoka_p[$h_gk] += 5+int(rand(5));
					}elsif($df_point > 15){
						$comment[$comlog++] = "이것은 골포스트 빠듯이! 아깝게도 빗나갔습니다! <br>\n";
						$h_hyoka_p[$h_gk] -= int(rand(8))-5;
					}else{
						$comment[$comlog++] = "이것은 테두리에 말하지 않았습니다! <br>\n";
						$h_hyoka_p[$h_gk] -= 10+int(rand(5));
					}
				}
			}else{
				$comment[$comlog++] = "$h_tag$h_name[$df]$h_tag_end, 크고 클리어! <br>\n";
			}
		}
	}
	&attack_end;
	next;
	
}#END fk

1;

#--------#
#  CK  #
#--------#
sub ck {
	
	
}#END ck

1;

#--------#
#  PK  #
#--------#
sub pk {
	
	if($_[0] eq "home"){
		my @kickers=();
		for($i=0; $i<11; $i++){push @kickers, $i if $h_pk[$i] eq "○";}
		my $pk = $kickers[int(rand(@kickers))];
		$comment[$comlog++] = "자 $h_tag$h_teamname$h_tag_end! <b>PK</b>의 찬스! <br>차는 것은 $h_tag$h_name[$pk]$h_tag_end! <br>\n";
		my $keypara = ($h_pass[$pk]+$h_shoo[$pk])/2;
		&get_point("home","","$keypara","PK","$pk","$a_gk");
		if($of_point > 30){
			$comment[$comlog++] = "자, $h_tag$h_name[$pk]$h_tag_end! 찼다! 볼이 신음소리를 지른다! <br>\n";
			$h_hyoka_p[$pk] += 20+int(rand(20));
		}elsif($of_point > 25){
			$comment[$comlog++] = "자, $h_tag$h_name[$pk]$h_tag_end! 찼다! 호쾌! <br>\n";
			$h_hyoka_p[$pk] += 10+int(rand(10));
		}elsif($of_point > 20){
			$comment[$comlog++] = "자, $h_tag$h_name[$pk]$h_tag_end! 찼다! <br>\n";
			$h_hyoka_p[$pk] += 5+int(rand(5));
		}elsif($of_point > 15){
			$comment[$comlog++] = "자, $h_tag$h_name[$pk]$h_tag_end! 찼다! 조금 코스 달다! <br>\n";
			$h_hyoka_p[$pk] -= int(rand(10))-5;
		}else{
			$comment[$comlog++] = "자, $h_tag$h_name[$pk]$h_tag_end! 찼다! 조금 위력이 약하다! <br>\n";
			$h_hyoka_p[$pk] -= 10+int(rand(5));
		}
		if($df_point > 30){
			$comment[$comlog++] = "키퍼 $a_tag$a_name[$a_gk]$a_tag_end, 코스를 읽고 있다! <br>\n";
			$a_hyoka_p[$a_gk] += 20+int(rand(20));
		}elsif($df_point > 25){
			$comment[$comlog++] = "키퍼 $a_tag$a_name[$a_gk]$a_tag_end, 완전하게 반응하고 있다! <br>\n";
			$a_hyoka_p[$a_gk] += 15+int(rand(10));
		}elsif($df_point > 20){
			$comment[$comlog++] = "키퍼 $a_tag$a_name[$a_gk]$a_tag_end, 민첩한 반응을 보인다! <br>\n";
			$a_hyoka_p[$a_gk] += 5+int(rand(5));
		}elsif($df_point > 15){
			$comment[$comlog++] = "키퍼 $a_tag$a_name[$a_gk]$a_tag_end, 반응 둔하다! <br>\n";
			$a_hyoka_p[$a_gk] -= int(rand(8))-5;
		}elsif(15 >= $df_point){
			$comment[$comlog++] = "키퍼 $a_tag$a_name[$a_gk]$a_tag_end, 반응할 수 없습니다! <br>\n";
			$a_hyoka_p[$a_gk] -= 10+int(rand(5));
		}
		if($of_point >= $df_point){
			$comment[$comlog++] = "<b>정해졌다! </b>$h_tag$h_name[$pk]$h_tag_end, 빈틈없이 PK를 결정했습니다∼！<br>\n";
			&get_score("home","$pk");
		}else{
			if(int(rand(2)) == 0){
				$comment[$comlog++] = "그러나 볼은 크게 테두리를 빗나갔습니다! $h_tag$h_teamname$h_tag_end 써포터, 야유하는 소리! <br>\n";
			}elsif(int(rand(2)) == 1){
				$comment[$comlog++] = "그러나 볼은 조금범위를 빗나갔습니다! $h_tag$h_name[$pk]$h_tag_end, 하늘을 들이킵니다! <br>\n";
			}else{
				$comment[$comlog++] = "멈춘! 키퍼 $a_tag$a_name[$a_gk]$a_tag_end, 보기좋게 PK를 멈추었습니다! <br>\n";
			}
		}
	}elsif($_[0] eq "away"){
		my @kickers=();
		for($i=0; $i<11; $i++){push @kickers, $i if $a_pk[$i] eq "○";}
		my $pk = $kickers[int(rand(@kickers))];
		$comment[$comlog++] = "자 $a_tag$a_teamname$a_tag_end! <b>PK</b>의 찬스! <br>차는 것은 $a_tag$a_name[$pk]$a_tag_end! <br>\n";
		my $keypara = ($a_pass[$pk]+$a_shoo[$pk])/2;
		&get_point("away","","$keypara","PK","$pk","$h_gk");
		if($of_point > 30){
			$comment[$comlog++] = "자, $a_tag$a_name[$pk]$a_tag_end! 찼다! 볼이 신음소리를 지른다! <br>\n";
			$a_hyoka_p[$pk] += 20+int(rand(20));
		}elsif($of_point > 25){
			$comment[$comlog++] = "자, $a_tag$a_name[$pk]$a_tag_end! 찼다! 호쾌! <br>\n";
			$a_hyoka_p[$pk] += 10+int(rand(10));
		}elsif($of_point > 20){
			$comment[$comlog++] = "자, $a_tag$a_name[$pk]$a_tag_end! 찼다! <br>\n";
			$a_hyoka_p[$pk] += 5+int(rand(5));
		}elsif($of_point > 15){
			$comment[$comlog++] = "자, $a_tag$a_name[$pk]$a_tag_end! 찼다! 조금 코스 달다! <br>\n";
			$a_hyoka_p[$pk] -= int(rand(10))-10;
		}else{
			$comment[$comlog++] = "자, $a_tag$a_name[$pk]$a_tag_end! 찼다! 조금 위력이 약하다! <br>\n";
			$a_hyoka_p[$pk] -= 10+int(rand(5));
		}
		if($df_point > 30){
			$comment[$comlog++] = "키퍼 $h_tag$h_name[$h_gk]$h_tag_end, 코스를 읽고 있다! <br>\n";
			$h_hyoka_p[$h_gk] += 20+int(rand(20));
		}elsif($df_point > 25){
			$comment[$comlog++] = "키퍼 $h_tag$h_name[$h_gk]$h_tag_end, 완전하게 반응하고 있다! <br>\n";
			$h_hyoka_p[$h_gk] += 15+int(rand(10));
		}elsif($df_point > 20){
			$comment[$comlog++] = "키퍼 $h_tag$h_name[$h_gk]$h_tag_end, 민첩한 반응을 보인다! <br>\n";
			$h_hyoka_p[$h_gk] += 5+int(rand(5));
		}elsif($df_point > 15){
			$comment[$comlog++] = "키퍼 $h_tag$h_name[$h_gk]$h_tag_end, 반응 둔하다! <br>\n";
			$h_hyoka_p[$h_gk] -= int(rand(8))-5;
		}else{
			$comment[$comlog++] = "키퍼 $h_tag$h_name[$h_gk]$h_tag_end, 반응할 수 없습니다! <br>\n";
			$h_hyoka_p[$h_gk] -= 10+int(rand(5));
		}
		if($of_point >= $df_point){
			$comment[$comlog++] = "<b>정해졌다! </b>$a_tag$a_name[$pk]$a_tag_end, 빈틈없이 PK를 결정했습니다∼！<br>\n";
			&get_score("away","$pk");
		}else{
			$tmp = int(rand(5));
			if(int(rand(2)) == 0){
				$comment[$comlog++] = "그러나 볼은 크게 테두리를 빗나갔습니다! $a_tag$a_teamname$a_tag_end 써포터, 야유하는 소리! <br>\n";
			}elsif(int(rand(2)) == 1){
				$comment[$comlog++] = "그러나 볼은 조금범위를 빗나갔습니다! $a_tag$a_name[$pk]$a_tag_end, 하늘을 들이킵니다! <br>\n";
			}else{
				$comment[$comlog++] = "멈춘! 키퍼 $h_tag$h_name[$h_gk]$h_tag_end, 보기좋게 PK를 멈추었습니다! <br>\n";
			}
		}
	}
	&attack_end;
	next;
	
}#END pk

1;

#----------#
#  PK전  #
#----------#
sub vspk {
	
	$comment[$comlog++] = "<br>여기서 시합 종료의 휘슬! <br>연장전에서도 승패 붙지 않고, 결착은 PK전에 맡길 수 있었습니다! <br><br>\n";
	my @kickers=(0..10); my @sortkey=();
	for($i=0; $i<=10; $i++){push(@sortkey,($h_shoo[$i]+$h_pass[$i]));}
	my @h_kickers = @kickers[sort {$sortkey[$b] <=> $sortkey[$a]} 0 .. $#sortkey];
	my @kickers=(0..10); my @sortkey=();
	for($i=0; $i<=10; $i++){push(@sortkey,($a_shoo[$i]+$a_pass[$i]));}
	my @a_kickers = @kickers[sort {$sortkey[$b] <=> $sortkey[$a]} 0 .. $#sortkey];
	$h_pkscore = 0; $a_pkscore = 0;
	for($i=1; $i<=5; $i++){
		my $reach="";
		if(abs($h_pkscore-$a_pkscore) > (6-$i)){last;}
		elsif($h_pkscore-$a_pkscore == (6-$i)){$reach="home";}
		elsif($a_pkscore-$h_pkscore == (6-$i)){$reach="away";}
		$comment[$comlog++] = "자$h_tag$h_teamname$h_tag_end, $i명째의 킥커는 $h_tag$h_name[$h_kickers[$i-1]]$h_tag_end! 찼다! <br>\n";
		my $keypara = ($h_pass[$h_kickers[$i-1]]+$h_shoo[$h_kickers[$i-1]])/2;
		&get_point("home","","$keypara","PK","$h_kickers[$i-1]","$a_gk");
		if($of_point >= $df_point){
			$comment[$comlog++] = "<b>정해졌다! </b>$h_tag$h_name[$h_kickers[$i-1]]$h_tag_end, 빈틈없이 결정했습니다∼！<br><br>\n";
			$h_pkscore++;
			if($reach eq "home"){last;}
		}else{
			if(int(rand(2)) == 0){
				$comment[$comlog++] = "그러나 볼은 크게 테두리를 빗나갔습니다! $h_tag$h_teamname$h_tag_end 써포터, 야유하는 소리! <br><br>\n";
			}elsif(int(rand(2)) == 1){
				$comment[$comlog++] = "그러나 볼은 조금범위를 빗나갔습니다! $h_tag$h_name[$h_kickers[$i-1]]$h_tag_end, 하늘을 들이킵니다! <br><br>\n";
			}else{
				$comment[$comlog++] = "멈춘! 키퍼 $a_tag$a_name[$a_gk]$a_tag_end, 보기좋게 지켰습니다! <br><br>\n";
			}
			if($reach eq "away"){last;}
		}
		$comment[$comlog++] = "자$a_tag$a_teamname$a_tag_end, $i명째의 킥커는 $a_tag$a_name[$a_kickers[$i-1]]$a_tag_end! 찼다! <br>\n";
		my $keypara = ($a_pass[$a_kickers[$i-1]]+$a_shoo[$a_kickers[$i-1]])/2;
		&get_point("away","","$keypara","PK","$a_kickers[$i-1]","$h_gk");
		if($of_point >= $df_point){
			$comment[$comlog++] = "<b>정해졌다! </b>$a_tag$a_name[$a_kickers[$i-1]]$a_tag_end, 빈틈없이 결정했습니다∼！<br><br>\n";
			$a_pkscore++;
		}else{
			if(int(rand(2)) == 0){
				$comment[$comlog++] = "그러나 볼은 크게 테두리를 빗나갔습니다! $h_tag$h_teamname$h_tag_end 써포터, 대환성을 지릅니다! <br><br>\n";
			}elsif(int(rand(2)) == 1){
				$comment[$comlog++] = "그러나 볼은 조금범위를 빗나갔습니다! $a_tag$a_name[$a_kickers[$i-1]]$a_tag_end, 하늘을 들이킵니다! <br><br>\n";
			}else{
				$comment[$comlog++] = "멈춘! 키퍼 $h_tag$h_name[$h_gk]$h_tag_end, 보기좋게 지켰습니다! <br><br>\n";
			}
		}
	}
	if($h_pkscore == $a_pkscore){
		$loop_count=0; # 루프 체크
		for(;;$i++){
			&loop_check("VSPK01"); # 루프 체크
			$i=1 if $i>=12;
			$comment[$comlog++] = "자$h_tag$h_teamname$h_tag_end, 다음의 킥커는 $h_tag$h_name[$h_kickers[$i-1]]$h_tag_end! 찼다! <br>\n";
			my $keypara = ($h_pass[$h_kickers[$i-1]]+$h_shoo[$h_kickers[$i-1]])/2;
			&get_point("home","","$keypara","PK","$h_kickers[$i-1]","$a_gk");
			if($of_point >= $df_point){
				$comment[$comlog++] = "<b>정해졌다! </b>$h_tag$h_name[$h_kickers[$i-1]]$h_tag_end, 빈틈없이 결정했습니다∼！<br><br>\n";
				$h_pkscore++;
			}else{
				if(int(rand(2)) == 0){
					$comment[$comlog++] = "그러나 볼은 크게 테두리를 빗나갔습니다! $h_tag$h_teamname$h_tag_end 써포터, 야유하는 소리! <br><br>\n";
				}elsif(int(rand(2)) == 1){
					$comment[$comlog++] = "그러나 볼은 조금범위를 빗나갔습니다! $h_tag$h_name[$h_kickers[$i-1]]$h_tag_end, 하늘을 들이킵니다! <br><br>\n";
				}else{
					$comment[$comlog++] = "멈춘! 키퍼 $a_tag$a_name[$a_gk]$a_tag_end, 보기좋게 지켰습니다! <br><br>\n";
				}
			}
			
			$comment[$comlog++] = "자$a_tag$a_teamname$a_tag_end, 다음의 킥커는 $a_tag$a_name[$a_kickers[$i-1]]$a_tag_end! 찼다! <br>\n";
			my $keypara = ($a_pass[$a_kickers[$i-1]]+$a_shoo[$a_kickers[$i-1]])/2;
			&get_point("away","","$keypara","PK","$a_kickers[$i-1]","$h_gk");
			if($of_point >= $df_point){
				$comment[$comlog++] = "<b>정해졌다! </b>$a_tag$a_name[$a_kickers[$i-1]]$a_tag_end, 빈틈없이 결정했습니다∼！<br><br>\n";
				$a_pkscore++;
			}else{
				if(int(rand(2)) == 0){
					$comment[$comlog++] = "그러나 볼은 크게 테두리를 빗나갔습니다! $h_tag$h_teamname$h_tag_end 써포터, 대환성을 지릅니다! <br><br>\n";
				}elsif(int(rand(2)) == 1){
					$comment[$comlog++] = "그러나 볼은 조금범위를 빗나갔습니다! $a_tag$a_name[$a_kickers[$i-1]]$a_tag_end, 하늘을 들이킵니다! <br><br>\n";
				}else{
					$comment[$comlog++] = "멈춘! 키퍼 $h_tag$h_name[$h_gk]$h_tag_end, 보기좋게 지켰습니다! <br><br>\n";
				}
			}
			if($h_pkscore != $a_pkscore){last;}
		}
	}
	&winlose;
	$game_end = '시합 종료';
	
}#END vspk

1;

#------------#
#  점처리  #
#------------#
sub get_score {
	
	if($_[0] eq "home"){
		$h_score++;
		$h_score[$_[1]]++;
		$h_getscore[$_[1]]++;
		$h_hyoka_p[$_[1]] += 25+int(rand(50));
		$h_sotokuten++;
		$a_soshiten++;
	}elsif($_[0] eq "away"){
		$a_score++;
		$a_score[$_[1]]++;
		$a_getscore[$_[1]]++;
		$a_hyoka_p[$_[1]] += 25+int(rand(50));
		$a_sotokuten++;
		$h_soshiten++;
	}
	if($game_end =~ /연장/){
		$comment[$comlog++] = "<br>그리고 여기서 휘슬! <br>숨이 막히는 열전에 종지부가 맞았습니다! <br>\n";
		&winlose;
		last;
	}
	$comment[$comlog++] = "「$h_tag$h_teamname$h_tag_end」<b>$h_score－$a_score</b>「$a_tag$a_teamname$a_tag_end」<br>\n";
	
}#END get_score

1;

#------------#
#  공격 종료  #
#------------#
sub attack_end {
	
	$tac_flg = 0;
	$offence = 0;
	$area = 2;
	$n_time += int(rand(24))+1;
	
}#END attack_end

1;

