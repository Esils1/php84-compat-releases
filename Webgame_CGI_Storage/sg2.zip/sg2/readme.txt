★ 「SG soccer 2」에 대해
「극공간원 거절하는 리그 2」(배포원：http://homepage2.nifty.com/osktaka/)을 개조해 작성된 「SG soccer」의 속편입니다.


★ 스크립트 이용 규약(반드시 읽어 주세요)

1.
이 스크립트는, 상용 이용 이외의 목적에 대해서 무상 배포되고 있습니다.

2.
이 게임을 설치하는 데 있어는, 어느 정도 CGI의 설치에 관한 지식이 필요합니다.
설치에 관해서 메일에서의 문의에는 응할 수 없으므로, 질문등이 있으면, 자신인 정도 조사한 다음 「샤코그레이드의 관」의 「Free BBS」에서 문의해 주세요.
할 수 있는 한 질문에는 답합니다만, 관리인 다망을 위해 답변이 늦는 것이 있을 수 있기 때문에 미리 양해 바랍니다.

3.
이 스크립트의 저작권은, 작자인 「감색 SG」가 소지하고 있기 때문에, 그근처의 취급은 충분히 조심해 주세요.
덧붙여 당연한일이면서, 이용자는 저작권 표시를 삭제하는 등 , 안보이는 상태(보이기 어려운 상태)으로서는 안됩니다.
개조 등은 자유롭게 해 주셔 상관하지 않습니다만, 저작권 표시부분은 반드시 남겨 주세요.

4.
이 스크립트는 동작 보증은 행하고 있지 않습니다.
프로바이더나 환경의 차이등에 의해, 스크립트가 동작하지 않는 케이스도 있을 수 있습니다.
그 때의 보충은 할 수 있기 어려우므로, 미리 양해 바랍니다.

5.
이 스크립트를 이용해 하등의 손해가 있었다고 해도, 작자 「감색 SG」는 일절의 책임을 지지 않습니다.
또, 작자 「감색 SG」에 현저하게 불이익이 있다고 판단했을 경우에는, 스크립트의 이용을 정지해 주시는 경우가 있습니다.

6.
이 스크립트를 사용하고 있어, 하등의 버그를 발견했을 경우는 신속하게 「감색 SG」까지 알려 주세요.

7.
이 규약은, 예고 없이 개편, 가필을 실시하는 일이 있습니다.


★ 설치 방법
예로서 서버상의 「cgi-bin」폴더 이하에 설치하면(자)···(□는 폴더입니다)

□cgi-bin
┗□sgsoccer(755)
　┣sgsoccer.cgi(755)
　┣admin.cgi(755)
　┣sgsoccer.pl(644)
　┣sgsoccer.ini(644)
　┣game.pl(644)
　┣manage.dat(666)
　┣access.log(666)
　┣help.html(644)
　┣□div1(777)
　┃┣□data(777)
　┃┃┣ranking.dat(666)
　┃┃┣rekidai.dat(666)
　┃┃┣winner.dat(666)
　┃┃┣wp_rank.dat(666)
　┃┃┗zenkai.dat(666)
　┃┣□log(777)
　┃┃┣index.html(644)
　┃┃┗kekka.log(666)
　┃┗□teamdata(777)
　┃　┗index.html(644)
　┣□div2(777)
　┃┣□data(777)
　┃┃┣ranking.dat(666)
　┃┃┣rekidai.dat(666)
　┃┃┣winner.dat(666)
　┃┃┣wp_rank.dat(666)
　┃┃┗zenkai.dat(666)
　┃┣□log(777)
　┃┃┣index.html(644)
　┃┃┗kekka.log(666)
　┃┗□teamdata(777)
　┃　┗index.html(644)
　┣□image(755)
　┃┗□icon(755)
　┣□lock(777)
　┣□teamlog(777)
　┃┣□konkai(777)
　┃┃┗index.html(644)
　┃┣□rekidai(777)
　┃┃┗index.html(644)
　┃┗□zenkai(777)
　┃　┗index.html(644)
　┗□backup(777)
　　┣□div1(777)
　　┃┣□data(777)
　　┃┃┗index.html(644)
　　┃┣□log(777)
　　┃┃┗index.html(644)
　　┃┗□teamdata(777)
　　┃　┗index.html(644)
　　┣□div2(777)
　　┃┣□data(777)
　　┃┃┗index.html(644)
　　┃┣□log(777)
　　┃┃┗index.html(644)
　　┃┗□teamdata(777)
　　┃　┗index.html(644)
　　┗□teamlog(777)
　　　┣□konkai(777)
　　　┃┗index.html(644)
　　　┣□rekidai(777)
　　　┃┗index.html(644)
　　　┗□zenkai(777)
　　　　┗index.html(644)

그리고 「sgsoccer.cgi」에 액세스 하면 움직일 것입니다.
관리툴을 기동하고 싶을 때는 「admin.cgi」에 액세스 해 주세요.


★ 이력
ver1. 00
「SG soccer Ver. 2.32」를 「SG soccer 2 Ver1. 00」(으)로서 배포 개시

