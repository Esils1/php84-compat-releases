#!/usr/bin/perl

#-------------------------------------------------
#
# admin.cgi(SG soccer 2 전용 관리툴) Ver. 1.00
#
# sgsoccer.ini의 패스 지정
require './sgsoccercon.cgi';
#
#-------------------------------------------------

&decode;
if($form{admin_pass} ne $admin_pass){&admin_top;}
if($form{mente}){&mente;}
if($form{kaijo}){&kaijo;}
if($form{backup}){&backup;}
if($form{fukyu}){&fukyu;}
if($form{reset}){&reset;}
if($form{view}){&view;}
if($form{admin_delete}){&admin_delete;}
if($form{league}){&league;}
if($form{conversion}){&conversion;}
&admin_main;
exit;

#----------------#
#  탑 페이지  #
#----------------#
sub admin_top {
	
	&header;
	print <<"_EOF_";
<center>
<p>관리용 패스워드를 입력해 주세요. </p>
<p><form action=$adminfile method=$method>
<input type=password NAME=admin_pass size=10>
<input type=submit value="송신">
</form></p>
<p>(관리 화면에 들어가려면 , 관리용 패스워드가 필요합니다. )</p>
</center>
_EOF_
	
	exit;
	
}

#----------------#
#  메인 페이지  #
#----------------#
sub admin_main {
	
	&header;
	print <<"_EOF_";
<h1>관리자 메뉴</h1><hr></center>
$admin_message<br>
<form action=$adminfile method=$method>
_EOF_
	
	if(-e "$mentefile"){
		print "<p><input type=submit name=kaijo value='메인트넌스 모드를 해제'>";
	}else{
		print "<p><input type=submit name=mente value='메인트넌스 모드에 이행'>( 각 메뉴를 실시할 때는, 반드시 「메인트넌스 모드」로 가 주세요)<input type=hidden name=admin_pass value=$form{admin_pass}></form>";
		exit;
	}
	
	print <<"_EOF_";
<hr>
<p><input type=submit name=backup value="백업 작성">
<p><input type=submit name=fukyu value="백업으로부터 복구">
<p><input type=submit name=league value="1리그제에 이행">
<p><input type=submit name=reset value="전데이터 리셋트">
<input type=checkbox name=all_delete value=○>
팀 데이터를 삭제한다
<p><input type=submit name=view value="전팀 일람">
<input type=hidden name=admin_pass value=$form{admin_pass}>
</form>
_EOF_
	
# <p><input type=submit name=conversion value="데이터 변환">
	
}

#--------------------------#
#  메인트넌스 모드 이행  #
#--------------------------#
sub mente {
	
	&write("$mentefile","");
	$admin_message = "<br><h2>메인트넌스 모드에 이행 했습니다</h2>";
	
}

#--------------------------#
#  메인트넌스 모드 해제  #
#--------------------------#
sub kaijo {
	
	unlink "$mentefile";
	$admin_message = "<br><h2>메인트넌스 모드를 해제했습니다</h2>";
	
}

#----------------#
#  백업  #
#----------------#
sub backup {
	
	if($form{backup} eq "백업 작성"){
		&header;
		print <<"_END_";
<h2>백업을 작성해 좋습니까? <br>(이전 작성제의 백업파일이 있는 경우는 모두 없어집니다)</h2>
<hr><a href="$adminfile?backup=1&admin_pass=$form{admin_pass}">네</a>  / <a href=$adminfile?admin_pass=$form{admin_pass}>아니오</a> <hr>
</body>
</html>
_END_
		exit;
	}elsif($form{backup} eq 1){
		# 진행 파일
		unlink "$bkupdir/$managefile";
		my @data = &load("$managefile");
		&write("$bkupdir/$managefile",@data);
		
		for($i=0; $i<2; $i++){
			# 팀 데이터 디렉토리
			opendir(DIR,"$bkupdir/$dir[$i]/$teamdir") or die "에러($bkupdir/$dir[$i]/$teamdir)<br>$!";
			@data = grep !/^\.\.?$|\.htm/,readdir(DIR);
			closedir(DIR);
			foreach(@data){unlink "$bkupdir/$dir[$i]/$teamdir/$_";}
			opendir(DIR,"$dir[$i]/$teamdir") or die "에러($dir[$i]/$teamdir)<br>$! ";
			@data = grep !/^\.\.?$|\.htm/,readdir(DIR);
			closedir(DIR);
			foreach(@data){
				my @users = &load("$dir[$i]/$teamdir/$_");
				&write("$bkupdir/$dir[$i]/$teamdir/$_",@users);
			}
			
			# 데이터 디렉토리
			opendir(DIR,"$bkupdir/$dir[$i]/$datadir") or die "에러($bkupdir/$dir[$i]/$datadir)<br>$! ";
			@data = grep !/^\.\.?$|\.htm/,readdir(DIR);
			closedir(DIR);
			foreach(@data){unlink "$bkupdir/$dir[$i]/$datadir/$_";}
			opendir(DIR,"$dir[$i]/$datadir") or die "에러($dir[$i]/$datadir)<br>$! ";
			@data = grep !/^\.\.?$|\.htm/,readdir(DIR);
			closedir(DIR);
			foreach(@data){
				my @users = &load("$dir[$i]/$datadir/$_");
				&write("$bkupdir/$dir[$i]/$datadir/$_",@users);
			}
			
			# 로그 디렉토리
			opendir(DIR,"$bkupdir/$dir[$i]/$logdir") or die "에러($bkupdir/$dir[$i]/$logdir)<br>$! ";
			@data = grep !/^\.\.?$|\.htm/,readdir(DIR);
			closedir(DIR);
			foreach(@data){unlink "$bkupdir/$dir[$i]/$logdir/$_";}
			opendir(DIR,"$dir[$i]/$logdir") or die "에러($dir[$i]/$logdir)<br>$! ";
			@data = grep !/^\.\.?$|\.htm/,readdir(DIR);
			closedir(DIR);
			foreach(@data){
				my @users = &load("$dir[$i]/$logdir/$_");
				&write("$bkupdir/$dir[$i]/$logdir/$_",@users);
			}
			
			# 팀 로그 디렉토리
			foreach("konkai","zenkai","rekidai"){
				my $dir = $_;
				opendir(DIR,"$bkupdir/$tlogdir/$dir") or die "에러($bkupdir/$tlogdir/$dir)<br>$! ";
				@data = grep !/^\.\.?$|\.htm/,readdir(DIR);
				closedir(DIR);
				foreach(@data){unlink "$bkupdir/$tlogdir/$dir/$_";}
				opendir(DIR,"$tlogdir/$dir") or die "에러($tlogdir/$dir)<br>$! ";
				@data = grep !/^\.\.?$|\.htm/,readdir(DIR);
				closedir(DIR);
				foreach(@data){
					my @users = &load("$tlogdir/$dir/$_");
					&write("$bkupdir/$tlogdir/$dir/$_",@users);
				}
			}
		}
		$admin_message = "<br><h2>백업이 종료했습니다</h2>";
	}
	
}

#--------#
#  복구  #
#--------#
sub fukyu {
	
	if($form{fukyu} eq "백업으로부터 복구"){
		&header;
		print <<"_END_";
<h2>백업을 복구해 좋습니까? <br>(현재의 데이터는 모두 없어집니다)</h2>
<hr><a href="$adminfile?fukyu=1&admin_pass=$form{admin_pass}">네</a>  / <a href=$adminfile?admin_pass=$form{admin_pass}>아니오</a> <hr>
</body>
</html>
_END_
		exit;
	}elsif($form{fukyu} eq 1){
		# 진행 파일
		unlink "$managefile";
		my @data = &load("$bkupdir/$managefile");
		&write("$managefile",@data);
		
		$times = time;
		for($i=0; $i<2; $i++){
			# 팀 데이터 디렉토리
			opendir(DIR,"$dir[$i]/$teamdir") or die "에러($dir[$i]/$teamdir)<br>$! ";
			@data = grep !/^\.\.?$|\.htm/,readdir(DIR);
			closedir(DIR);
			foreach(@data){unlink "$dir[$i]/$teamdir/$_";}
			opendir(DIR,"$bkupdir/$dir[$i]/$teamdir") or die "에러($bkupdir/$dir[$i]/$teamdir)<br>$! ";
			@data = grep !/^\.\.?$|\.htm/,readdir(DIR);
			closedir(DIR);
			foreach(@data){
				my @users = &load("$bkupdir/$dir[$i]/$teamdir/$_");
				($id,$password,$owner,$teamname,$tac,$tac_zp,$tac_ca,$tac_pp,$tac_vszp,$tac_vsca,$tac_vspp,$icon,$date,$win,$win1,$win2,$lose,$draw,$win_p,$winmax,$sotokuten,$soshiten,$cup,$host) = split(/<>/,$users[0]);
				$users[0] = join('<>',$id,$password,$owner,$teamname,$tac,$tac_zp,$tac_ca,$tac_pp,$tac_vszp,$tac_vsca,$tac_vspp,$icon,$times,$win,$win1,$win2,$lose,$draw,$win_p,$winmax,$sotokuten,$soshiten,$cup,$host,"\n");
				&write("$dir[$i]/$teamdir/$_",@users);
			}
			
			# 데이터 디렉토리
			opendir(DIR,"$dir[$i]/$datadir") or die "에러($dir[$i]/$datadir)<br>$! ";
			@data = grep !/^\.\.?$|\.htm/,readdir(DIR);
			closedir(DIR);
			foreach(@data){unlink "$dir[$i]/$datadir/$_";}
			opendir(DIR,"$bkupdir/$dir[$i]/$datadir") or die "에러($bkupdir/$dir[$i]/$datadir)<br>$! ";
			@data = grep !/^\.\.?$|\.htm/,readdir(DIR);
			closedir(DIR);
			foreach(@data){
				my @users = &load("$bkupdir/$dir[$i]/$datadir/$_");
				&write("$dir[$i]/$datadir/$_",@users);
			}
			
			# 로그 디렉토리
			opendir(DIR,"$dir[$i]/$logdir") or die "에러($dir[$i]/$logdir)<br>$! ";
			@data = grep !/^\.\.?$|\.htm/,readdir(DIR);
			closedir(DIR);
			foreach(@data){unlink "$dir[$i]/$logdir/$_";}
			opendir(DIR,"$bkupdir/$dir[$i]/$logdir") or die "에러($bkupdir/$dir[$i]/$logdir)<br>$! ";
			@data = grep !/^\.\.?$|\.htm/,readdir(DIR);
			closedir(DIR);
			foreach(@data){
				my @users = &load("$bkupdir/$dir[$i]/$logdir/$_");
				&write("$dir[$i]/$logdir/$_",@users);
			}
			
			# 팀 로그 디렉토리
			foreach("konkai","zenkai","rekidai"){
				my $dir = $_;
				opendir(DIR,"$tlogdir/$dir") or die "에러($tlogdir/$dir)<br>$! ";
				@data = grep !/^\.\.?$|\.htm/,readdir(DIR);
				closedir(DIR);
				foreach(@data){unlink "$tlogdir/$dir/$_";}
				opendir(DIR,"$bkupdir/$tlogdir/$dir") or die "에러($bkupdir/$tlogdir/$dir)<br>$! ";
				@data = grep !/^\.\.?$|\.htm/,readdir(DIR);
				closedir(DIR);
				foreach(@data){
					my @users = &load("$bkupdir/$tlogdir/$dir/$_");
					&write("$tlogdir/$dir/$_",@users);
				}
			}
		}
		$admin_message = "<br><h2>복구가 종료했습니다</h2>";
	}
	
}

#------------#
#  리셋트  #
#------------#
sub reset {
	
	if($form{reset} eq "전데이터 리셋트" && $form{all_delete} eq "○"){
		&header;
		print <<"_END_";
<h2>전데이터를 삭제해 좋습니까? </h2>
<hr><a href="$adminfile?reset=1&all_delete=1&admin_pass=$form{admin_pass}">네</a>  / <a href=$adminfile?admin_pass=$form{admin_pass}>아니오</a> <hr>
</body>
</html>
_END_
		exit;
	}elsif($form{reset} eq 1 && $form{all_delete} eq 1){
		# 진행 파일
		&write("$managefile","");
		
		$times = time;
		for($i=0; $i<2; $i++){
			
			# 팀 데이터 디렉토리
			opendir(DIR,"$dir[$i]/$teamdir") or die "에러($dir[$i]/$teamdir)<br>$! ";
			@data = grep !/^\.\.?$|\.htm/,readdir(DIR);
			closedir(DIR);
			foreach(@data){unlink "$dir[$i]/$teamdir/$_";}
			
			# 데이터 디렉토리
			opendir(DIR,"$dir[$i]/$datadir") or die "에러($dir[$i]/$datadir)<br>$! ";
			@data = grep !/^\.\.?$|\.htm/,readdir(DIR);
			closedir(DIR);
			foreach(@data){&write("$dir[$i]/$datadir/$_","");}
			
			# 로그 디렉토리
			opendir(DIR,"$dir[$i]/$logdir") or die "에러($dir[$i]/$logdir)<br>$! ";
			@data = grep !/^\.\.?$|\.htm/,readdir(DIR);
			closedir(DIR);
			foreach(@data){
				if($_ =~ /much/){unlink "$dir[$i]/$logdir/$_";}
				else{&write("$dir[$i]/$logdir/$_","");}
			}
		}
		$admin_message = "<br><h2>전데이터를 삭제했습니다</h2>";
	}elsif($form{reset} eq "전데이터 리셋트"){
		&header;
		print <<"_END_";
<h2>전데이터를 리셋트 해 좋습니까? </h2>
<hr><a href="$adminfile?reset=1&admin_pass=$form{admin_pass}">네</a>  / <a href=$adminfile?admin_pass=$form{admin_pass}>아니오</a> <hr>
</body>
</html>
_END_
		exit;
	}elsif($form{reset} eq 1){
		# 진행 파일
		&write("$managefile","");
		
		$times = time;
		for($i=0; $i<2; $i++){
			
			# 팀 데이터 디렉토리
			opendir(DIR,"$dir[$i]/$teamdir") or die "에러($dir[$i]/$teamdir)<br>$! ";
			@data = grep !/^\.\.?$|\.htm/,readdir(DIR);
			closedir(DIR);
			foreach(@data){
				my @users = &load("$dir[$i]/$teamdir/$_");
				&split("teamdata","$users[0]");
				$users[0] = join('<>',$id,$password,$owner,$teamname,$tac,$tac_zp,$tac_ca,$tac_pp,$tac_vszp,$tac_vsca,$tac_vspp,$icon,$times, 0,0,0,0,0,0,0,0,0,0,$host,"\n");
				for($ii=1; $ii<12; $ii++){
					&split("playerdata","$users[$ii]");
					$users[$ii] = join('<>',$shozoku,$p_name,$posi,$pass,$dori,$shoo,$defe,$fk,$pk,$style,$fair,0,000,5,"\n");
				}
				&write("$dir[$i]/$teamdir/$_",@users);
			}
			
			# 데이터 디렉토리
			opendir(DIR,"$dir[$i]/$datadir") or die "에러($dir[$i]/$datadir)<br>$! ";
			@data = grep !/^\.\.?$|\.htm/,readdir(DIR);
			closedir(DIR);
			foreach(@data){&write("$dir[$i]/$datadir/$_","");}
			
			# 로그 디렉토리
			opendir(DIR,"$dir[$i]/$logdir") or die "에러($dir[$i]/$logdir)<br>$! ";
			@data = grep !/^\.\.?$|\.htm/,readdir(DIR);
			closedir(DIR);
			foreach(@data){
				if($_ =~ /much/){unlink "$dir[$i]/$logdir/$_";}
				else{&write("$dir[$i]/$logdir/$_","");}
			}
		}
		$admin_message = "<br><h2>전데이터를 리셋트 했습니다</h2>";
	}
	
}

#----------------#
#  전팀 일람  #
#----------------#
sub view {
	
	&header;
	print "<div align=left><a href=$adminfile?admin_pass=$form{admin_pass}>관리자 모드에 돌아온다</a> </div>";
	for($i=0; $i<2; $i++){
		opendir(DIR,"$dir[$i]/$teamdir") or die "에러($dir[$i]/$teamdir)<br>$! ";
		@data = grep !/^\.\.?$|\.htm/,readdir(DIR);
		closedir(DIR);
		print "<br><br><h2>$league[$i]</h2>\n";
		print "<table width=$width border=1>\n";
		foreach(@data){
			my @users = &load("$dir[$i]/$teamdir/$_");
			&split("teamdata","$users[0]");
			print "<tr>\n";
			print "<td><form action=$adminfile method=$method>$id</td>\n";
			print "<td>$teamname($owner)</td>\n";
			print "<td>$host</td>\n";
			print "<td><input type=submit name=admin_delete value='삭제'><input type=hidden name=admin_pass value=$form{admin_pass}><input type=hidden name=class value=$dir[$i]><input type=hidden name=id value=$id><input type=hidden name=teamname value=$teamname></form></td>\n";
			print "</tr></form>\n";
		}
		print "</table>\n";
	}
	exit;
	
}

#--------------#
#  팀 삭제  #
#--------------#
sub admin_delete {
	
	if($form{admin_delete} eq "삭제"){
		&header;
		print <<"_END_";
<h2>「$form{teamname}」를 삭제해 좋습니까? </h2>
<hr><a href="$adminfile?admin_delete=1&admin_pass=$form{admin_pass}&class=$form{class}&id=$form{id}&teamname=$form{teamname}">네</a>  / <a href=$adminfile?admin_pass=$form{admin_pass}>아니오</a> <hr>
</body>
</html>
_END_
		exit;
	}elsif($form{admin_delete} eq 1){
		unlink "$form{class}/$teamdir/$form{id}.dat";
		my @winner = &load("$form{class}/$datadir/$winnerfile");
		&split("winnerdata","$winner[0]");
		if("$w_id" eq "$form{id}"){&write("$form{class}/$datadir/$winnerfile","");}
		$admin_message = "<br><h2>「$form{teamname}」를 삭제했습니다</h2>";
	}
	
}

#-----------------#
#  1 리그제 이행  #
#-----------------#
sub league {
	
	if($form{league} eq "1 리그제에 이행"){
		&header;
		print <<"_END_";
<h2>1 리그제에 이행 해 좋습니까? </h2>
<hr><a href="$adminfile?league=1&admin_pass=$form{admin_pass}">네</a>  / <a href=$adminfile?admin_pass=$form{admin_pass}>아니오</a> <hr>
</body>
</html>
_END_
		exit;
	}elsif($form{league} eq 1){
			# 팀 데이터 디렉토리
			opendir(DIR,"$dir[0]/$teamdir") or die "에러($dir[0]/$teamdir)<br>$! ";
			@data = grep !/^\.\.?$|\.htm/,readdir(DIR);
			closedir(DIR);
			foreach(@data){
				my @users = &load("$dir[0]/$teamdir/$_");
				&write("$dir[1]/$teamdir/$_",@users);
				unlink "$dir[0]/$teamdir/$_";
			}
			
			# 데이터 디렉토리
			opendir(DIR,"$dir[0]/$datadir") or die "에러($dir[0]/$datadir)<br>$! ";
			@data = grep !/^\.\.?$|\.htm/,readdir(DIR);
			closedir(DIR);
			foreach(@data){&write("$dir[0]/$datadir/$_","");}
			
			# 로그 디렉토리
			opendir(DIR,"$dir[0]/$logdir") or die "에러($dir[0]/$logdir)<br>$! ";
			@data = grep !/^\.\.?$|\.htm/,readdir(DIR);
			closedir(DIR);
			foreach(@data){
				if($_ =~ /much/){unlink "$dir[0]/$logdir/$_";}
				else{&write("$dir[0]/$logdir/$_","");}
			}
		$admin_message = "<br><h2>1 리그제에의 이행이 종료했습니다<br>(반드시 「sgsoccer.ini」내의 설정을 「1 리그제」로 해 주세요)</h2>";
	}
	
}

#--------------#
#  데이터 변환  #
#--------------#
sub conversion {
	
	for($i=0; $i<2; $i++){
		opendir(DIR,"$dir[$i]/$teamdir") or die "에러($dir[0]/$teamdir)<br>$! ";
		my @teamdata = grep !/^\.\.?$|\.htm/,readdir(DIR);
		closedir(DIR);
		
		foreach(@teamdata){
			my @users = &load("$dir[$i]/$teamdir/$_");
			
			# $win1 $win2
			($id,$password,$owner,$teamname,$tac,$tac_zp,$tac_ca,$tac_pp,$tac_vszp,$tac_vsca,$tac_vspp,$icon,$date,$win,$lose,$draw,$win_p,$winmax,$sotokuten,$soshiten,$cup,$host) = split(/<>/,$users[0]);
			
			$users[0] = join('<>',$id,$password,$owner,$teamname,$tac,$tac_zp,$tac_ca,$tac_pp,$tac_vszp,$tac_vsca,$tac_vspp,$icon,$date,$win,0,0,$lose,$draw,$win_p,$winmax,$sotokuten,$soshiten,$cup,$host,"\n");
			
			&write("$dir[$i]/$teamdir/$_",@users);
		}
		
		my @ranking = &load("$dir[$i]/$datadir/$rankingfile");
		foreach(@ranking){
			
			# $win1 $win2
			($id,$password,$owner,$teamname,$tac,$tac_zp,$tac_ca,$tac_pp,$tac_vszp,$tac_vsca,$tac_vspp,$icon,$date,$win,$lose,$draw,$win_p,$winmax,$sotokuten,$soshiten,$cup,$host) = split(/<>/,$_);
			
			$_ = join('<>',$id,$password,$owner,$teamname,$tac,$tac_zp,$tac_ca,$tac_pp,$tac_vszp,$tac_vsca,$tac_vspp,$icon,$date,$win,0,0,$lose,$draw,$win_p,$winmax,$sotokuten,$soshiten,$cup,$host,"\n");
		}
		&write("$dir[$i]/$datadir/$rankingfile",@ranking);
		
		my @zenkai = &load("$dir[$i]/$datadir/$zenkaifile");
		my($cgk, $cdf, $cdmf, $comf, $cfw);
		$loop_count=0; # 루프 체크
		for($ii=20; $ii<@zenkai+1; $ii++){
			&loop_check; # 루프 체크
			&split("playerdata","$zenkai[$ii]");
			if($posi eq "GK"){$cgk++;}
			elsif($posi eq "DF" ){$cdf++;}
			elsif($posi eq "DMF" ){$cdmf++;}
			elsif($posi eq "OMF" ){$comf++;}
			elsif($posi eq "FW" ){$cfw++;}
			else{last;}
		}
		$loop_count=0; # 루프 체크
		for($ii=20+$cgk+$cdf+$cdmf+$comf+$cfw; $ii<@zenkai; $ii++){
			&loop_check; # 루프 체크
			
			# $win1 $win2
			($id,$password,$owner,$teamname,$tac,$tac_zp,$tac_ca,$tac_pp,$tac_vszp,$tac_vsca,$tac_vspp,$icon,$date,$win,$lose,$draw,$win_p,$winmax,$sotokuten,$soshiten,$cup,$host) = split(/<>/,$zenkai[$ii]);
			
			$zenkai[$ii] = join('<>',$id,$password,$owner,$teamname,$tac,$tac_zp,$tac_ca,$tac_pp,$tac_vszp,$tac_vsca,$tac_vspp,$icon,$date,$win,0,0,$lose,$draw,$win_p,$winmax,$sotokuten,$soshiten,$cup,$host,"\n");
			
		}
		&write("$dir[$i]/$datadir/$zenkaifile",@zenkai);
		
		my @rekidai = &load("$dir[$i]/$datadir/$rekidaifile");
		foreach(@rekidai){
			
			# $win1 $win2
			($re_dai,$owner,$teamname,$icon,$win,$lose,$draw,$win_p,$winmax,$sotokuten,$soshiten,$s_shozoku,$s_p_name,$s_posi,$s_score,$s_hyoka,$h_shozoku,$h_p_name,$h_posi,$h_score,$h_hyoka,$shozoku_gk,$p_name_gk,$score_gk,$hyoka_gk,$shozoku_df,$p_name_df,$score_df,$hyoka_df,$shozoku_dmf,$p_name_dmf,$score_dmf,$hyoka_dmf,$shozoku_omf,$p_name_omf,$score_omf,$hyoka_omf,$shozoku_fw,$p_name_fw,$score_fw,$hyoka_fw) = split(/<>/,$_);
			
			if($s_shozoku eq ""){$shozoku_gk = "";}
			
			$_ = join('<>',$re_dai,$owner,$teamname,$icon,$win,0,0,$lose,$draw,$win_p,$winmax,$sotokuten,$soshiten,$s_shozoku,$s_p_name,$s_posi,$s_score,$s_hyoka,$h_shozoku,$h_p_name,$h_posi,$h_score,$h_hyoka,$shozoku_gk,$p_name_gk,$score_gk,$hyoka_gk,$shozoku_df,$p_name_df,$score_df,$hyoka_df,$shozoku_dmf,$p_name_dmf,$score_dmf,$hyoka_dmf,$shozoku_omf,$p_name_omf,$score_omf,$hyoka_omf,$shozoku_fw,$p_name_fw,$score_fw,$hyoka_fw,"\n");
			
		}
		&write("$dir[$i]/$datadir/$rekidaifile",@rekidai);
	}
	$admin_message = "<br><h2>데이터 변환이 종료했습니다</h2>";
	
}

