#!/usr/bin/perl

#------------------------------------------------------#
#?FF ADVENTURE v0.21
#?programed by CUMRO
#?http://cgi.members.interq.or.jp/sun/cumro/mm/
#?cumro@sun.interq.or.jp
#
#  FF ADVENTURE(��) v1.101
#  remodeling by GUN
#  http://www.gun-online.com/
#  webmaster@gun-online.com
#
#  FF ADVENTURE(��) + v1.040
#  EDIT by Laldar
#------------------------------------------------------#
#--- [���ӎ�?] ------------------------------------------------#
# 1. ���̃X�N���v�g�̓t��??�t�g�ł��B���̃X�N���v�g���g�p���� #
#    �����Ȃ鑹�Q�ɑ΂��č�҂͈�؂̐ӔC�𕉂��܂���B     	#
# 2. ���̃X�N���v�g�̒��쌠��D.Takamiya(CUMRO)����AGUN����Ajun-k����ALaldar����ɂ���܂��B
# 3. ���ⓙ�����̊J���҂̕��ɐ�΂ɂ��Ȃ��悤���肢���܂��B
#---------------------------------------------------------------#

# ��?�ꃉ�C�u�����̓ǂݍ���
require 'data/jcode.pl';

# ���W�X�g���C�u�����̓ǂݍ���
require 'data/regist.cgi';

# �����ݒ�t?�C���̓ǂݍ���
require 'data/ff_ini.cgi';

#-----------------------------------------------------------------------------#
if($mente) { &error("���݃o?�W�����A�b�v���ł��B���΂炭���҂����������B"); }
&decode;
if($mode eq 'chocobattle') { &chocobattle; }
exit;

#������������������������������������������������������������������������������
#��   �I?�g��???
#������������������������������������������������������������������������������
sub AUTOLOAD {
	my $name = ($AUTOLOAD =~ /^main::(.+)$/)[0];
	($FLAG{'autoload'}++ > 50) && die $AUTOLOAD; # �O�̂��ߖ�����?�v�h?
	defined %SUB or &SUBS;
	if (!defined $SUB{$name}) {
		&error("��?����Ă��Ȃ��֐�($AUTOLOAD)���Ă΂�܂����B"); exit;
	}
	eval $SUB{$name}; length($@) && &error("EVAL ERROR: $@ ($AUTOLOAD)");
	delete $SUB{$name}; goto &{'main::' . $name};
}

sub SUBS {
%SUB = (
	chocobattle => <<'__SUB__',
#--------------#
#  ��?�X���  #
#--------------#
sub chocobattle {
	if($cbattle_flag) { &error("���ں� ŷ ������ ������ ã�� �� �����ϴ�."); }

	$cbattle_flag=1;

	open(IN,"./charalog/$in{'id'}.cgi") or &error('�߸��� ID�Դϴ�.');
	@battle = <IN>;
	close(IN);

	foreach(@battle){
		($kid,$kpass,$ksite,$kurl,$kname,$ksex,$kchara,$kn_0,$kn_1,$kn_2,$kn_3,$kn_4,$kn_5,$kn_6,$ksyoku,$khp,$kmaxhp,$kex,$klv,$kgold,$klp,$ktotal,$kkati,$kwaza,$kitem,$kmons,$khost,$kdate,$kmori,$kdef,$ktac,$kacsno,$kmoriturn,$kcllv,$ks0,$ks1,$ks2,$ks3,$ks4,$ks5,$ks6,$ks7,$ks8,$ks9,$ks10,$ks11,$ks12,$ks13,$ks14,$ks15,$ks16,$ks17,$ks18,$ks19,$ks20,$ks21,$ks22,$krec) = split(/<>/);
		if($in{'id'} eq "$kid" and $in{'pass'} eq "$kpass") { last; }
	}

	if($in{'id'} ne "$kid" or $in{'pass'} ne "$kpass"){&error("���� ID�̰ų�, �߸��� ��й�ȣ�� �Է��ϼ̽��ϴ�.");}

	open(IN,"$chocolog_file");
	@log_choco = <IN>;
	close(IN);

	foreach(@log_choco){
	($cy_id,$cy_pass,$cy_kname,$cy_no,$cy_name,$cy_gold,$cy_rank,$cy_sp,$cy_sta,$cy_maxsta,$cy_ex,$cy_total,$cy_kati,$cy_0,$cy_1,$cy_2,$cy_3,$cy_4,$cy_5,$cy_6,$cy_life) = split(/<>/);
		if($kid eq "$cy_id"){ $hit=1;last; }
	}

	&read_cwinner;

	$ltime = time();
	$ltime = $ltime - $kdate;
	$vtime = $b_time - $ltime;

	if($cw_id eq $kid) { &error("���� ���̵��̰ų�, ���ں��� �������� �ʽ��ϴ�."); }

	if($cy_life < 3) { &error("���ں��� ����� ���ƽ��ϴ�.");}

	if($vtime > 0){
	if($ltime < $b_time or !$ktotal) { &error("$vtime�� ������ �ൿ�� �� �����ϴ�."); }
			}
	if($in{'site'}) { $ksite = $in{'site'}; }
	if($in{'url'}) { $kurl = $in{'url'}; }
	if($in{'waza'}) { $kwaza = $in{'waza'}; }
	if($in{'c_name'}) { $kname = $in{'c_name'}; }
	$km_flg = 800;
	$wm_flg = 800;
	$ksta_flg = cy_sta;
	$wsta_flg = cw_sta;

	$i=1;$j=0;@battle_date=();
	foreach(1..$turn) {
		$dmg1 = $cy_5 + $cy_sp * (int(rand(3)) + 1);
		$dmg2 = $cw_5 + $cw_sp * (int(rand(3)) + 1);
		$clit1 = "";
		$clit2 = "";
		$com1 = "";
		$com2 = "";
		$kawasi1 = "";
		$kawasi2 = "";
		$battle_mes1 = "";
		$battle_mes2 = "";
		$sake1 = int(rand($cy_5)) - int(rand($cw_4));
		$sake2 = int(rand($cw_5)) - int(rand($cy_4));
		$kclit = $km_flg / 10;
		$wclit = $wm_flg / 10;
		$kmclit = $kmaxhp / 10;
		$wmclit = $wmaxhp / 10;
		$mybar = int(($km_flg / 800) * 100);
                $myb2 = 100 - $mybar + 1;
                $enbar = int(($wm_flg / 800) * 100);
                $enb2 = 100 - $enbar + 1;

			# ����ґ��s�����v�Z
			$com1 = "$kname�� $cy_name��(��) �޸���! <p>";
			if(int(rand(9)) == 0) {
				$com1 .= "<font size=5>$kname���뽬��-!!!��</font><p><font color=\"#FF0000\" size=7></font>\n";
				$dmg1 = $dmg1 * 2;
			}
			$dmg1 = $dmg1 + int(rand($cy_5));

			if($cy_life < 40){
				$sdmg1 = int($dmg1 / 2);
				}else{$sdmg1 = int($dmg1 / 3);}

			# �L���O���s�����v�Z
			$dmg2 = $dmg2 + int(rand($cw_5));

			if($wy_life < 40){
				$sdmg2 = int($dmg2 / 2);
				}else{$sdmg2 = int($dmg2 / 3);}

			$com2 = "$wname�� $cw_name��(��) �޸���!<p>";

			if(int(rand(30)) == 0) {
				$clit1 = "<b class=\"clit\">�͵���!!</b><P>";
				$dmg1 = $dmg1 * 3;
			}

			if(int(rand(30)) == 0) {
				$clit2 = "<font size=5>$wname���ű� ����!!��</font><p><b class=\"clit\">�͵���!!</b><P>";
				$dmg2 = int($dmg2 * 3.5);
			}

			if($wmaxhp > ($kmaxhp * 2) and $i == 1) {
				if($cw_rank - $cy_rank >= $level_sa){
				$sa = $kmaxhp;
				$clit1 .= "<p><font size=5><b>$kname��(��) <font color=red>���ں��� ����</font>�� �ϳ��� �Ǿ���!!</b></font><P>";
					if($wmaxhp < $sa){$dmg1 = $dmg1;}
					elsif($dmg1 > 200 - $sa){$dmg1 = $dmg1;}
					else{$dmg1 = 200 - $sa;}
				}else{
					if(int(rand(4)) == 1){
				$sa = $kmaxhp;
				$clit1 .= "<p><font size=5><b>$kname��(��) <font color=red>���ں��� ����</font>�� �ϳ��� �Ǿ���!!</b></font><P>";
					if($wmaxhp < $sa){$dmg1 = $dmg1;}
					elsif($dmg1 > 200 - $sa){$dmg1 = $dmg1;}
					else{$dmg1 = 200 - $sa;}
					}
				}
			}

			if($kmaxhp > ($wmaxhp * 2) and $i == 1) {
				if($cy_rank - $cw_rank >= $level_sa){
				$wsa = $wmaxhp;
				$clit2 .= "<p><font size=5><b>$wname��(��) <font color=blue>���ں��� ����</font>�� �ϳ��� �Ǿ���!!</b></font><P>";
					if($kmaxhp < $wsa){$dmg2 = $dmg2;}
					elsif($dmg2 > 200 - $wsa){$dmg2 = $dmg2;}
					else{$dmg2 = 200 - $wsa;}
				}else{
					if(int(rand(4)) == 1){
				$wsa = $wmaxhp;
				$clit2 .= "<p><font size=5><b>$wname��(��) <font color=blue>���ں��� ����</font>�� �ϳ��� �Ǿ���!!</b></font><P>";
					if($kmaxhp < $wsa){$dmg2 = $dmg2;}
					elsif($dmg2 > 200 - $wsa){$dmg2 = $dmg2;}
					else{$dmg2 = 200 - $wsa;}
					}
				}
			}


	if($ktac == 1 or $ktac == 18 or $ktac == 29 or $ktac == 52){
		$dmg1 = int($dmg1 * 1.5);
		$dmg2 = int($dmg2 * 1.5);
		}

	if($ktac == 2 or $ktac == 4 or $ktac == 6 or $ktac == 12 or $ktac == 17 or $ktac == 24){
		$dmg1 = int($dmg1 * 0.75);
		$dmg2 = int($dmg2 * 0.75);
		}

	if($ktac == 3 or $ktac == 21 or $ktac == 33 or $ktac == 42){
		$sake1 = $sake1 - int(rand($kn_1));
		if($wsyoku ==0 or $wsyoku == 3 or $wsyoku == 4 or $wsyoku == 11 or $wsyoku == 12 or $wsyoku == 13 or $wsyoku == 14 or $wsyoku == 19 or $wsyoku == 22){
			$dmg1 = $dmg1 * 3;
			}
		}

	if($ktac == 5 or $ktac == 22){
		$sake1 = $sake1 - int(rand($kn_2));
		if(int(rand(2)) == 0){
			$dmg1 =$dmg1 * 3;
			$com1 .="<P>������ ���ߴ�!!<P>";
			}
		}

	if($ktac == 7 or $ktac == 31 or $ktac == 35 or $ktac == 51){
		$dmg1 = int($dmg1 * 0.75);
		$sake1 = $sake1 + int(rand($cy_5));
		}

	if($ktac == 9 or $ktac == 27 or $ktac == 34 or $ktac == 46){
		$sake2 = $sake2 - int(rand($cw_4));
		$dmg1 = int($dmg1 * 0.75);
		}

	if($ktac == 11 or $ktac == 15){
		if(int(rand(2)) == 0){
			$dmg1 = $dmg1 * 2;
			}else{
			$dmg1 = int($dmg1 * 0.5);
			}
		}

	if($ktac == 13){
		$dmg1 = $dmg1 * 3;
		$dmg2 = $dmg2 * 2;
		$sake1 = $sake1 - int(rand($cy_0));
		}

	if($ktac == 14){
		$sake2 = $sake2 - int(rand($cw_6));
		$dmg1 = int($dmg1 * 0.75);
		}

	if($ktac == 16){
		$sake1 = $sake1 - int(rand($cy_3));
		$dmg1 = $dmg1 * 2;
		}

	if($ktac == 19){
		$sake1 = $sake1 + int(rand($cy_2));
		$dmg1 = int($dmg1 * 1.25);
		$dmg2 = $dmg2 * 2;
		}

	if($ktac == 20){
		$sake1 = $sake1 + (int(rand($cy_5)) * 2);
		$dmg1 = int($dmg1 * 0.5);
		$dmg2 = $dmg2 * 2;
		}

	if($ktac == 23){
		if($wsyoku ==0 or $wsyoku == 3 or $wsyoku == 4 or $wsyoku == 11 or $wsyoku == 12 or $wsyoku == 13 or $wsyoku == 14 or $wsyoku == 19 or $wsyoku == 22){
			$dmg1 = $dmg1 * 3;
			}
		if(int(rand(2)) == 0){
			$dmg1 =$dmg1 * 3;
			}
		$sake1 = int($sake1 * 0.5);
		$dmg2 = int($dmg2 * 1.5);
		}

	if($ktac == 25){
		$sake2 = int($sake2 * 0.5);
		$dmg1 = int($dmg1 * 0.75);
		}

	if($ktac == 26){
		$sake1 = $sake1 - int(rand($cy_2));
		if(int(rand(2)) == 0){
			$dmg1 =$dmg1 * 4;
			}
		}

	if($ktac == 28 and $i ==1){
		if(int(rand(4)) == 0){
			$dmg1 = $wmaxhp + $wd_dmg;
			}
		$sake1 = $sake1 - 100;
		$dmg2 = $dmg2 * 3;
		}

	if($ktac == 30){
		$dmg2 = int($dmg2 * 0.5);
		$sake1 = int($sake1 * 0.5);
		}

	if($ktac == 32){
		if($i%10 == 0){
			$dmg1 = $dmg1 * 3;
			}
		$sake1 = $sake1 - int(rand($cy_3));
		}

	if($ktac == 36){
		$dmg1 = $dmg1 * 2;
		$dmgme1 = int($dmg1 / 5);
		}

	if($ktac == 37){
		$dmg2 = int($dmg2 * 0.5);
		$sake2 = $sake2 - int(rand($cw_6));
		$sake1 = $sake1 - 100;
		}

	if($ktac == 38){
		if($wsyoku ==0 or $wsyoku == 3 or $wsyoku == 4 or $wsyoku == 11 or $wsyoku == 12 or $wsyoku == 13 or $wsyoku == 14 or $wsyoku == 19 or $wsyoku == 22){
			$dmg1 = $dmg1 * 3;
			}
		$dmg1 = $dmg1 * 2;
		$sake1 = $sake1 - 100;
		}

	if($ktac == 39){
		$dmg1 = $dmg1 * int(rand(5));
		$sake1 = $sake1 - 100;
		$sake2 = $sake2 * int(rand($cw_1));
		}

	if($ktac == 40){
		if($i%2 == 0){
			$dmg1 = $dmg1 * 4;
			$sake1 = $sake1 * int(rand($cy_5));
			}
		$dmg1 = int($dmg1 * 0.75);
		$sake1 = $sake1 - int(rand($cy_5));
		}

	if($ktac == 41){
		$dmg1 = $dmg1 + ($ci_dmg * 5);
		$dmg2 = $dmg2 * 2;
		}

	if($ktac == 43){
		if($wsyoku ==0 or $wsyoku == 3 or $wsyoku == 4 or $wsyoku == 11 or $wsyoku == 12 or $wsyoku == 13 or $wsyoku == 14 or $wsyoku == 19 or $wsyoku == 22){
			$dmg1 = $dmg1 * 3;
			}
		$sake1 = $sake1 - 100;
		$sake2 = $sake2 - $sake1;
		}

	if($ktac == 44){
		if($km_flg < $kmclit){
			if(int(rand(9)) == 0){
				$km_flg = 0;
				$com1 .="<p>������ �Ͼ��!!!<p>";
				}
			}
		$dmg1 = int($dmg1 * 0.75);
		}

	if($ktac == 45){
		$dmg1 = $dmg1 * 5;
		$dmg2 = $dmg2 * 2;
		$sake2 = $sake2 + int(rand($cy_5));
		$sake1 = $sake1 - int(rand($cy_5));
		$com1 .="<p>��û�� �⼼�� �޸���!!<p>";
		}

	if($ktac == 47){
		$sake1 = $sake1 * 2;
		$sake2 = $sake2 - 100;
		$dmg1 = int($dmg1 * 0.5);
		}

	if($ktac == 48){
		$dmg2 = $dmg2 * 2;
		$dmg1 = $dmg1 * 2;
		}

	if($ktac == 49){
		if($dmg1 < 0){
			$dmg1 = 0;
			}
		$dmg1 = int($dmg1 * 0.5);
		}

	if($ktac == 50){
		$ura = 22;
		$sake2 = $sake2 + int(rand($wlp));
		}

	if($ktac == 53){
		if($i%15 == 0){
			$dmg1 = $dmg1 * 10;
			}
		$sake1 = $sake1 - int(rand($cy_3));
		}


	if($wtac == 1 or $wtac == 18 or $wtac == 29 or $wtac == 52){
		$dmg2 = int($dmg2 * 1.5);
		$dmg1 = int($dmg1 * 1.5);
		}

	if($wtac == 2 or $wtac == 4 or $wtac == 6 or $wtac == 12 or $wtac == 17 or $wtac == 24){
		$dmg1 = int($dmg1 * 0.75);
		$dmg2 = int($dmg2 * 0.75);
		}

	if($wtac == 3 or $wtac == 21 or $wtac == 33 or $wtac == 42){
		$sake2 = $sake2 - int(rand($cw_1));
		if($ksyoku ==0 or $ksyoku == 3 or $ksyoku == 4 or $ksyoku == 11 or $ksyoku == 12 or $ksyoku == 13 or $ksyoku == 14 or $ksyoku == 19 or $ksyoku == 22){
			$dmg2 = $dmg2 * 3;
			}
		}

	if($wtac == 5 or $wtac == 22){
		$sake2 = $sake2 - int(rand($cw_2));
		if(int(rand(2)) == 0){
			$dmg2 =$dmg2 * 3;
			$com2 .="<P>������ ���ߴ�!!<P>";
			}
		}

	if($wtac == 7 or $wtac == 31 or $wtac == 35 or $wtac == 51){
		$dmg2 = int($dmg2 * 0.75);
		$sake2 = $sake2 + int(rand($cw_5));
		}

	if($wtac == 9 or $wtac == 27 or $wtac == 34 or $wtac == 46){
		$sake1 = $sake1 - int(rand($cn_4));
		$dmg2 = int($dmg2 * 0.75);
		}

	if($wtac == 11 or $wtac == 15){
		if(int(rand(2)) == 0){
			$dmg2 = $dmg2 * 2;
			}else{
			$dmg2 = int($dmg2 * 0.5);
			}
		}

	if($wtac == 13){
		$dmg2 = $dmg2 * 3;
		$dmg1 = $dmg1 * 2;
		$sake2 = $sake2 - int(rand($cw_0));
		}

	if($wtac == 14){
		$sake1 = $sake1 - int(rand($cw_6));
		$dmg2 = int($dmg2 * 0.75);
		}

	if($wtac == 16){
		$sake2 = $sake2 - int(rand($cw_3));
		$dmg2 = $dmg2 * 2;
		}

	if($wtac == 19){
		$sake2 = $sake2 + int(rand($cw_2));
		$dmg2 = int($dmg2 * 1.25);
		$dmg1 = $dmg1 * 2;
		}

	if($wtac == 20){
		$sake2 = $sake2 + (int(rand($cw_5)) * 2);
		$dmg2 = int($dmg2 * 0.5);
		$dmg1 = $dmg1 * 2;
		}

	if($wtac == 23){
		if($ksyoku ==0 or $ksyoku == 3 or $ksyoku == 4 or $ksyoku == 11 or $ksyoku == 12 or $ksyoku == 13 or $ksyoku == 14 or $ksyoku == 19 or $ksyoku == 22){
			$dmg2 = $dmg2 * 3;
			}
		if(int(rand(2)) == 0){
			$dmg2 =$dmg2 * 3;
			}
		$sake2 = int($sake2 * 0.5);
		$dmg1 = int($dmg1 * 1.5);
		}

	if($wtac == 25){
		$sake1 = int($sake1 * 0.5);
		$dmg2 = int($dmg2 * 0.75);
		}

	if($wtac == 26){
		$sake2 = $sake2 - int(rand($cw_2));
		if(int(rand(2)) == 0){
			$dmg2 =$dmg2 * 4;
			}
		}

	if($wtac == 28 and $i ==1){
		if(int(rand(4)) == 0){
			$dmg2 = $kmaxhp + $kd_dmg;
			}
		$sake2 = $sake2 - 100;
		$dmg1 = $dmg1 * 3;
		}

	if($wtac == 30){
		$dmg1 = int($dmg1 * 0.5);
		$sake2 = int($sake2 * 0.5);
		}

	if($wtac == 32){
		if($i%10 == 0){
			$dmg2 = $dmg2 * 3;
			}
		$sake2 = $sake2 - int(rand($cw_3));
		}

	if($wtac == 36){
		$dmg2 = $dmg2 * 2;
		$dmgme2 = int($dmg2 / 5);
		}

	if($wtac == 37){
		$dmg1 = int($dmg1 * 0.5);
		$sake1 = $sake1 - int(rand($cw_6));
		$sake2 = $sake2 - 100;
		}

	if($wtac == 38){
		if($ksyoku ==0 or $ksyoku == 3 or $ksyoku == 4 or $ksyoku == 11 or $ksyoku == 12 or $ksyoku == 13 or $ksyoku == 14 or $ksyoku == 19 or $ksyoku == 22){
			$dmg2 = $dmg2 * 3;
			}
		$dmg2 = $dmg2 * 2;
		$sake2 = $sake2 - 100;
		}

	if($wtac == 39){
		$dmg2 = $dmg2 * int(rand(5));
		$sake2 = $sake2 - 100;
		$sake1 = $sake1 * int(rand($cw_1));
		}

	if($wtac == 40){
		if($i%2 == 0){
			$dmg2 = $dmg2 * 4;
			$sake2 = $sake2 * int(rand($cw_5));
			}
		$dmg2 = int($dmg2 * 0.75);
		$sake2 = $sake2 - int(rand($cw_5));
		}

	if($wtac == 41){
		$dmg2 = $dmg2 + ($wi_dmg * 5);
		$dmg1 = $dmg1 * 2;
		}

	if($wtac == 43){
		if($ksyoku ==0 or $ksyoku == 3 or $ksyoku == 4 or $ksyoku == 11 or $ksyoku == 12 or $ksyoku == 13 or $ksyoku == 14 or $ksyoku == 19 or $ksyoku == 22){
			$dmg2 = $dmg2 * 3;
			}
		$sake2 = $sake2 - 100;
		$sake1 = $sake1 - $sake2;
		}

	if($wtac == 44){
		if($wm_flg < $wmclit){
			if(int(rand(9)) == 0){
				$wm_flg = 0;
				$com2 .="<p>������ �Ͼ��!!!<p>";
				}
			}
		$dmg2 = int($dmg2 * 0.75);
		}

	if($wtac == 45){
		$dmg2 = $dmg2 * 5;
		$dmg1 = $dmg1 * 2;
		$sake1 = $sake1 + int(rand($cw_5));
		$sake2 = $sake2 - int(rand($cw_5));
		$com2 .="<p>��û�� �⼼�� �޸���!!<p>";
		}

	if($wtac == 47){
		$sake2 = $sake2 * 2;
		$sake1 = $sake1 - 100;
		$dmg2 = int($dmg2 * 0.5);
		}

	if($wtac == 48){
		$dmg2 = $dmg2 * 2;
		$dmg1 = $dmg1 * 2;
		}

	if($wtac == 49){
		if($dmg2 < 0){
			$dmg2 = 0;
			}
		$dmg2 = int($dmg2 * 0.5);
		}

	if($wtac == 50){
		$wura = 22;
		$sake1 = $sake1 + int(rand($klp));
		}

	if($wtac == 53){
		if($i%15 == 0){
			$dmg2 = $dmg2 * 10;
			}
		$sake2 = $sake2 - int(rand($cw_3));
		}


			if($dmg2 < 0){$dmg2 = $dmg2;}
			elsif($dmg2 < $cd_dmg){$dmg2 = 0;}
			else{$dmg2 = $dmg2 - $cd_dmg;}

			if($dmg1 < 0){$dmg1 = $dmg1;}
			elsif($dmg1 < $wd_dmg){$dmg1 = 0;}
			else{$dmg1 = $dmg1 - $wd_dmg;}

	if($wm_flg < $wmclit){
		if($wm_flg < $kclit){
			if($i > 15){
			$dmg2 = $dmg2 * 5;
			$com2 .="<p>�̰ɷ� �������̴�!!!<p>";
				}
			}
	}elsif(int(rand($sake1)) + int(rand($klp)) - int(rand($wlp))> int(rand(40))) {
		$dmg2 = 0;
		$kawasi1 = "<P><FONT SIZE=4 COLOR=\"#DD6699\">$cw_name��(��) �Ѽ��� ��û�ŷȴ�!</FONT><P>";
	}
	if($km_flg < $kmclit){
		if($km_flg < $wclit){
			if($i > 15){
			$dmg1 = $dmg1 * 5;
			$com1 .="<p>�̰ɷ� �������̴�!!!<p>";
				}
			}
	}elsif(int(rand($sake2)) + int(rand($wlp)) - int(rand($klp))> int(rand(40))) {
		$dmg1 = 0;
		$kawasi2 = "<P><FONT SIZE=4 COLOR=\"#DD6699\">$cy_name��(��) �Ѽ��� ��û�ŷȴ�!</FONT><P>";
	}

	$d_k=int(rand(11))+2;
	$d_w=int(rand(11))+2;
	if((int($cy_5 / 6) + $d_k + 2) >= (int($cw_5 / 6) + $d_w)) {
	$battle_mes1 = "$com1 $clit1 $kawasi2 $cy_name ��(��) <font class=\"dmg\"><b>$dmg1 M</b></font>�� �޷ȴ�!<small> ���ļ� ���׹̳ʰ� <font class=\"dmg\">$sdmg1</font>�Ҹ�Ǿ���.</small><br>";
	if($km_flg - $dmg1 <= 0) { $battle_mes2 = ""; $dmg2 = 0;}
	else{$battle_mes2 = "$com2 $clit2 $kawasi1 $cw_name ��(��) <font class=\"dmg\"><b>$dmg2 M</b></font>�� �޷ȴ�!<small> ���ļ� ���׹̳ʰ� <font class=\"dmg\">$sdmg2</font>�Ҹ�Ǿ���.</small><p>";}
	}
	else {$battle_mes1 = "$com2 $clit2 $kawasi1 $cw_name ��(��) <font class=\"dmg\"><b>$dmg2 M</b></font>�� �޷ȴ�!<small> ���ļ� ���׹̳ʰ� <font class=\"dmg\">$sdmg2</font>�Ҹ�Ǿ���.</small><p>";
	if($wm_flg - $dmg2 <= 0) { $battle_mes2 =""; $dmg1 = 0;}
	else{$battle_mes2 = "$com1 $clit1 $kawasi2 $cy_name ��(��) <font class=\"dmg\"><b>$dmg1 M</b></font>�� �޷ȴ�!<small> ���ļ� ���׹̳ʰ� <font class=\"dmg\">$sdmg1</font>�Ҹ�Ǿ���.</small><br>";}
	}

		$battle_date[$j] = <<"EOM";
<TABLE BORDER=0>
<TR>
	<TD CLASS="b2" COLSPAN="3" ALIGN="center">
	$i�� °
	</TD>
</TR>
<TR>
	<TD ALIGN="center">
	<IMG SRC="$img_path/$choco_img[$cy_no]" width=32 height=32><table width="100%" border=1>
</table>
	</TD>
	<TD>
	</TD>
	<TD ALIGN="center">
	<IMG SRC="$img_path/$choco_img[$cw_no]" width=32 height=32><table width="100%" border=1>
</table></TD>
	</TR>
<TR>
<TD>
<TABLE BORDER=1>
<TR>
	<TD CLASS="b1">
	����
	</TD>
	<TD CLASS="b1">
	���ں� �̸�
	</TD>
	<TD CLASS="b1">
	���׹̳�
	</TD>
	<TD CLASS="b1" align="center">
	�����Ÿ�
	</TD>
</TR>
<TR>
	<TD>
	$kname
	</TD>
	<TD>
	$cy_name
	</TD>
	<TD>
	$cy_sta\/$cy_maxsta
	</TD>
	<TD>
	$km_flg<BR>
	<IMG SRC="images/chara/mrk.gif" WIDTH=$mybar HEIGHT=5 ALIGN=top><IMG SRC="images/chara/mrk_r.gif" WIDTH=$myb2 HEIGHT=5 ALIGN=top>
	</TD>
</TR>
</TABLE>
</TD>
<TD>
<FONT SIZE=5 COLOR="#9999DD">VS</FONT>
</TD>
<TD>
<TABLE BORDER=1>
<TR>
	<TD CLASS="b1">
	����
	</TD>
	<TD CLASS="b1">
	���ں� �̸�
	</TD>
	<TD CLASS="b1">
	���׹̳�
	</TD>
	<TD CLASS="b1" align="center">
	�����Ÿ�
	</TD>
</TR>
<TR>
	<TD>
	$wname
	</TD>
	<TD>
	$cw_name
	</TD>
	<TD>
	$cw_sta\/$cw_maxsta
	</TD>
	<TD>
	$wm_flg<BR>
        <IMG SRC="images/chara/mrk.gif" WIDTH=$enbar HEIGHT=5 ALIGN=top><IMG SRC="images/chara/mrk_r.gif" WIDTH=$enb2 HEIGHT=5 ALIGN=top>
	</TD>
</TR>
</TABLE>
</TD>
</TR>
</TABLE>
<p>
$battle_mes1
<br>
$battle_mes2
<p>
EOM

		$km_flg = $km_flg - $dmg1 - $dmgme2;
		$wm_flg = $wm_flg - $dmg2 - $dmgme1;
		$cy_sta = $cy_sta - $sdmg1;
		$cw_sta = $cw_sta - $sdmg2;

		if($wm_flg <= 0 or $cy_sta <= 0) { $win = 0; last; }
		elsif($km_flg <= 0 or $cw_sta <= 0) { $win = 1; last; }
	
		$i++;
		$j++;

	}

	if($wm_flg <=0){ $mes1 = "<b><font size=5>��¼��� $wname�� $cw_name��(��) �������ϴ�!</font></b>";}
	if($km_flg <=0){ $mes1 = "<b><font size=5>��¼��� $kname�� $cy_name��(��) �������ϴ�!</font></b>";}

	if($win) {
		if($cw_sta <=0){ $mes1 = "<b><font size=5>$cw_name�� <font color=\"red\">���׹̳�</font>�� ���ߴ�..(����)</font></b>";}
		$cy_total += 1;
		$cy_kati += 1;
		$exp = int($cw_rank * $kiso_exp + (rand($cy_rank) + 1));
		$cy_ex = $cy_ex + $exp;
		$gold = $cy_rank * 10 ;
		$cy_life -= 10;
		$comment = "<b><font size=5>$kname�� ���ں��� �¸�!</font></b><p><b><font size=5 color=\"#ff0000\">$kname���� �Ѵ�, $cy_name!��</font></b><p><b><font size=5 color=\"#0000ff\">$cy_name������~ �� ��</font></b><p>";
	}else{
		if($cy_sta <=0){ $mes1 = "<b><font size=5>$cy_name�� <font color=\"red\">���׹̳�</font>�� ���ߴ�..(����)</font></font></b>";}
		$cy_total += 1;
		$exp = int($cw_rank * (rand($cy_rank) + 1));
		$cy_ex = $cy_ex + $exp;
		$gold = int(rand($cy_rank));
		$cy_life -= 10;
		$comment = "<b><font size=5>$kname�� �й�....</font></b><p><b><font size=5 color=\"#0000ff\">$kname��$cy_name�� �Ͼ.. (T_T)</font></b><p><b><font size=5 color=\"#ff0000\">$cy_name����������....��</font></b><p>";
	}

	while($cy_ex >= ($cy_rank * $lv_up)) {
		$comment .= "$cy_name�� ������ �ö���!<p>";
		$hpup = int(rand($cy_3)) + 1;
                  if($cy_maxsta >= 999) {
                   $cy_maxsta = 999;
                  }elsif($cy_maxsta < 999) {
                   $cy_maxsta = $cy_maxsta + $hpup;
                   if($cy_maxsta > 999){
                   $cy_maxsta = 999;
                   }
                  }
		$cy_sta = $cy_maxsta;
		$comment .= "���׹̳ʰ� �ö���<p>";
		$cy_ex = $cy_ex - ($cy_rank * $lv_up);
		$cy_rank += 1;
                if($cy_0 >= 999) {
                  $cy_0 = 999;
                }elsif($cy_0 < 999) {
                if(int(rand(5)) == 0) { $cy_0 += 1; $t1 = 1;}
                }
                if($cy_1 >= 999) {
                 $cy_1 = 999;
                }elsif($cy_1 < 999) {
                if(int(rand(5)) == 0) { $cy_1 += 1; $t2 = 1;}
                }
                if($cy_2 >= 999) {
                 $cy_2 = 999;
                }elsif($cy_2 < 999) {
                if(int(rand(5)) == 0) { $cy_2 += 1; $t3 = 1;}
                }
                if($cy_3 >= 999) {
                 $cy_3 = 999;
                }elsif($cy_3 < 999) {
                if(int(rand(5)) == 0) { $cy_3 += 1; $t4 = 1;}
                }
                if($cy_4 >= 999) {
                 $cy_4 = 999;
                }elsif($cy_4 < 999) {
                if(int(rand(5)) == 0) { $cy_4 += 1; $t5 = 1;}
                }
                if($cy_5 >= 999) {
                 $cy_5 = 999;
                }elsif($cy_5 < 999) {
                if(int(rand(5)) == 0) { $cy_5 += 1; $t6 = 1;}
                }
                if($cy_6 >= 999) {
                 $cy_6 = 999;
                }elsif($cy_6 < 999) {
                if(int(rand(5)) == 0) { $cy_6 += 1; $t7 = 1;}
                }
		if($t1) { $comment .= "������ ������ �� �� ����. "; }
		if($t2) { $comment .= "������ �� �� ����. "; }
		if($t3) { $comment .= "���� �� �� �ϴ�. "; }
		if($t4) { $comment .= "���Ⱑ Ȱ��������. "; }
		if($t5) { $comment .= "���� �Ű����� ������. "; }
		if($t6) { $comment .= "�β������Ѵ�. "; }
		if($t7) { $comment .= "���� �Ϳ��� ����. "; }

	}

	if($cy_sta >= int($cy_maxsta / 2)){
		$cy_sta = int($cy_maxsta * 8 / 10 );
	}else{
		$cy_sta = $cy_sta + int(($cy_maxsta) * 5 / 10);}
	
	if($cw_sta >= int($cw_maxsta / 2)){
		$cw_sta = $cw_maxsta;
	}else{
		$cw_sta = $cw_sta + int(($cw_maxsta) * 7 / 10);}

	if($cy_sta >= $cy_maxsta) { $cy_sta = $cy_maxsta; }

	if($cw_sta > $cw_maxsta) { $cw_sta = $cw_maxsta; }

	if($cy_sta <= 0) { $cy_sta = int($cy_maxsta * 4 / 10 ); }
	if($cw_sta <= 0) { $cw_sta = int($cw_maxsta * 4 / 10 ); }

	$kgold = $kgold + $gold;

	# �t?�C�����b�N
	if ($lockkey == 1) { &lock1; }
	elsif ($lockkey == 2) { &lock2; }

	open(IN,"$chocolog_file") or &error('���ں��� �������� �ʽ��ϴ�.');
	@choco_chara = <IN>;
	close(IN);

	$hit=0;@new=();
	foreach(@choco_chara){
	($c_id,$c_pass,$c_kname,$c_no,$c_name,$c_gold,$c_rank,$c_sp,$c_sta,$c_maxsta,$c_ex,$c_total,$c_kati,$c_0,$c_1,$c_2,$c_3,$c_4,$c_5,$c_6,$c_life) = split(/<>/);
		if($kid eq "$c_id") {

	unshift(@new,"$cy_id<>$cy_pass<>$kname<>$cy_no<>$cy_name<>$cy_gold<>$cy_rank<>$cy_sp<>$cy_sta<>$cy_maxsta<>$cy_ex<>$cy_total<>$cy_kati<>$cy_0<>$cy_1<>$cy_2<>$cy_3<>$cy_4<>$cy_5<>$cy_6<>$cy_life<>\n");
	$hit=1;
	}else{
	push(@new,"$_");
	}
	}

	if(!$hit){
	unshift(@new,"$kid<>$kpass<>$kname<>$cy_no<>$cy_name<>$cy_gold<>$cy_rank<>$cy_sp<>$cy_sta<>$cy_maxsta<>$cy_ex<>$cy_total<>$cy_kati<>$cy_0<>$cy_1<>$cy_2<>$cy_3<>$cy_4<>$cy_5<>$cy_6<>$cy_life<>\n");
	}
	
	open(OUT,">$chocolog_file");
	print OUT @new;
	close(OUT);

	if($win){
		@new=();
		open(IN,">$cwinner_file");
		@winnew = <IN>;
		unshift(@new,"$cy_id<>$cy_pass<>$cy_kname<>$cy_no<>$cy_name<>$cy_gold<>$cy_rank<>$cy_sp<>$cy_sta<>$cy_maxsta<>$cy_ex<>$cy_total<>$cy_kati<>$cy_0<>$cy_1<>$cy_2<>$cy_3<>$cy_4<>$cy_5<>$cy_6<>$cy_life<>$host<>$date<>$win<>$wname<>\n");
		print IN @new;
		close(IN);

	}else{
		$wcount += 1;
		@new=();
		open(IN,">$cwinner_file");
		@winnew = <IN>;
		unshift(@new,"$cw_id<>$cw_pass<>$wname<>$cw_no<>$cw_name<>$cw_gold<>$cw_rank<>$cw_sp<>$cw_sta<>$cw_maxsta<>$cw_ex<>$cw_total<>$cw_kati<>$cw_0<>$cw_1<>$cw_2<>$cw_3<>$cw_4<>$cw_5<>$cw_6<>$cw_life<>$host<>$date<>$wcount<>$kname<>\n");
		print IN @new;
		close(IN);

		open(IN,"$crecode_file") or &error('���ں� ŷ �����Ͱ� �������� �ʽ��ϴ�.');
		@recode = <IN>;
		close(IN);

		($count,$name) = split(/<>/,$recode[0]);

		if($wcount > $count) {
			open(OUT,">$crecode_file") or &error('���ں� ŷ �����Ͱ� �������� �ʽ��ϴ�.');
			print OUT "$wcount<>$wname<>\n";
			close(OUT);
		}
	}

	# ���b�N����
	if (-e $lockfile) { unlink($lockfile); }

	&regist;

	if($refresh and !$win) { &header2; } else { &header; }

	print "<h1>$kname��(��) $wname���� ���ں� ���̽��� ��û�ߴ�!</h1><hr size=0><p>\n";

	$i=0;
	foreach(@battle_date){
		print "$battle_date[$i]";
		$i++;
	}
	
	print "$mes1<p>$comment<p>$cy_name��(��) <b>$exp</b>�� ����ġ�� �����. $kname��(��) <b>$gold</b>G�� �Լ��ߴ�.<p>\n";

	&footer;

	$cbattle_flag=0;

	exit;
}
__SUB__

	read_cwinner => <<'__SUB__',
#--------------------------#
#  ?���R?�L���O�ǂݍ���  #
#--------------------------#
sub read_cwinner {
	open(IN,"$cwinner_file");
	@winner = <IN>;
	close(IN);

	($cw_id,$cw_pass,$wname,$cw_no,$cw_name,$cw_gold,$cw_rank,$cw_sp,$cw_sta,$cw_maxsta,$cw_ex,$cw_total,$cw_kati,$cw_0,$cw_1,$cw_2,$cw_3,$cw_4,$cw_5,$cw_6,$cw_life,$host,$date,$wcount,$lname) = split(/<>/,$winner[0]);
}
__SUB__

	footer => <<'__SUB__',
#------------------#
#?HTML�̃t�b???#
#------------------#
sub footer {
	if($refresh and !$win and $mode eq 'battle') {
		print "�y<b><a href=\"http\:\/\/$wurl\">?�����v�̃z??�y?�W��</a></b>�z\n";
	}else{
			
	print "<hr><form action=\"$script\" method=\"post\">\n";
	print "<input type=hidden name=id value=$kid>\n";
	print "<input type=hidden name=pass value=$kpass>\n";
	print "<input type=hidden name=mode value=log_in>\n";
	print "<input type=submit class=btn value=\"�������ͽ� ȭ������\">\n";
	print "</form>\n";
	print "<A HREF=\"$scripto\">TOPȭ������</A>\n";
	}
	print "<HR SIZE=0 WIDTH=\"100%\"><DIV align=right>\n";
	print "Chobo race v1.00 edit by <a href=\"http://www8.big.or.jp/~k-kiku/ff/index.html\" target=\"_top\">Laldar</a><br>\n";
	print "$verg remodeling by <a href=\"http://www.gun-online.com/\" target=\"_top\">GUN</a><br>\n";
	print "$ver by <a href=\"http://www.interq.or.jp/sun/cumro/\">D.Takamiya(CUMRO)</a><br>\n";
	print "</DIV></body></html>\n";
}
__SUB__

	header => <<'__SUB__',
#------------------#
#  HTML�̃w�b??  #
#------------------#
sub header {
	print "Cache-Control: no-cache\n";
	print "Pragma: no-cache\n";
	print "Content-type: text/html\n\n";
	print <<"EOM";
<html>
<head>
<META HTTP-EQUIV="Content-type" CONTENT="text/html; charset=EUC-kr">
<SCRIPT Language="JavaScript" src="$java_script"></SCRIPT>
EOM

	if($access_flg) {
	print <<"EOM";
<SCRIPT language="JavaScript">
<!--
if(parent.location == location) location = "$top_url";
if(document.referrer =="") location = "$top_url";
//-->
</SCRIPT>
EOM
	}
	print <<"EOM";
<STYLE type="text/css">
<!--
BODY{
  font-family : $font_name;
  font-size:12px;
  color:$text;
  background-image : url($choco_back);
  background-attachment : fixed;
}
.red{font-family : $font_name;color:$red;}
.yellow{font-family : $font_name;color:$yellow;}
.blue{font-family : $font_name;color:$blue;}
.green{font-family : $font_name;color:$green;}
.white{font-family : $font_name;color:$white;}
.dark{font-family : $font_name;color:$dark;}
.small{font-size:8px;$font_name;color:$red;}
-->
</STYLE>
EOM
	print "<link rel=\"stylesheet\" href=\"$style_sheet\" type\"text.css\">\n";
	print "<title>$main_title</title></head>\n";
	print "<body background=\"$choco_back\" bgcolor=\"$bgcolor\" text=\"$text\" link=\"$link\" vlink=\"$vlink\" alink=\"$alink\">\n";
	print "<embed src=\"$chocorace_midi\" type=\"audio/midi\" height=\"2\" autostart=\"true\" repeat=\"true\" save=\"false\" volume=\"100\" width=\"2\">\n";
}
__SUB__

	header2 => <<'__SUB__',
#--------------#
#  �������җp  #
#--------------#
sub header2 {
	print "Content-type: text/html\n\n";
	print <<"EOM";
<html>
<head>
<META HTTP-EQUIV="Content-type" CONTENT="text/html; charset=Euc-kr">
<META http-equiv="refresh" content="$refresh;URL=http\:\/\/$wurl" target="_new"> 
<STYLE type="text/css">
<!--
body,tr,td,th { font-size: 10pt }
a:hover { color: $alink }
.b1 {background: #9ac;border-color: #ccf #669 #669 #ccf;color:#fff; border-style: solid; border-width: 1px;}
.b2 {background: #669;border-color: #99c #336 #336 #99c;color:#fff; border-style: solid; border-width: 1px; text-align: center}
.b3 {background: #fff;border-color: #ccf #669 #669 #ccf;}
.dmg { color: #FF0000; font-size: 18pt }
.clit { color: #0000FF; font-size: 18pt }
-->
</STYLE>
EOM
	print "<title>$main_title</title></head>\n";
	print "<body background=\"$backgif\" bgcolor=\"$bgcolor\" text=\"$text\" link=\"$link\" vlink=\"$vlink\" alink=\"$alink\">\n";
}
__SUB__

	set_cookie => <<'__SUB__',
#------------------#
#  �N�b�L?�̔��s  #
#------------------#
sub set_cookie {
	# �N�b�L?��60���ԗL��
	local($sec,$min,$hour,$mday,$mon,$year,$wday) = gmtime(time+60*24*60*60);

	@month=('Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec');
	$gmt = sprintf("%s, %02d-%s-%04d %02d:%02d:%02d GMT",
			$week[$wday],$mday,$month[$mon],$year+1900,$hour,$min,$sec);
	$cook="id<>$cookie_id\,pass<>$cookie_pass";
	print "Set-Cookie: FFADV=$cook; expires=$gmt\n";
}
__SUB__
);
}
