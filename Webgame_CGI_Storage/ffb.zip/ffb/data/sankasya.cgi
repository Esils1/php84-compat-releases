#----------------#
#  �Q���ғo?    #
#----------------#
sub guest_list{

	&get_host;

	opendir(DIR,'./charalog') or die "$!";
	foreach $entry (readdir(DIR)){

	open(IN,"./charalog/$entry");
	push(@SANKA, <IN>);
	close(IN);

	}
	closedir(DIR);

	$hit=0;
	foreach(@SANKA){
		($jid,$jpass,$jsite,$jurl,$jname,$jsex,$jchara,$jn_0,$jn_1,$jn_2,$jn_3,$jn_4,$jn_5,$jn_6,$jsyoku,$jhp,$jmaxhp,$jex,$jlv,$jgold,$jlp,$jtotal,$jkati,$jwaza,$jitem,$jmons,$jhost,$jdate,$jmori,$jdef,$jtac) = split(/<>/);
		if($in{'id'} eq "$jid" and $in{'pass'} eq "$jpass") {
			$hit=1; last;
		}
	}

open(GUEST,"$guestfile");
@guest=<GUEST>;
close(GUEST);
$flag=1;
$times = time;
undef(@member);
foreach $line (@guest) {
($timer,$name,$id,$host) = split(/ \, /, $line);
if( $times-65 > $timer){
$line = '';
next;
}
if((($jname eq $name)||($id eq $jid)) && $flag){
$line = "$times \, $jname \, $jid \, $jhost \, \n";
$flag = 0;
}
if($jname ne $name){
push (@member, "<a href=\"$scripta?mode=chara_sts&id=$id\">$name</a><font size=1 color=#aaaaff>��, </font>");
}
if($jname eq $name){
push (@member, "<a href=\"$scripta?mode=chara_sts&id=$jid\">$jname</a><font size=1 color=#aaaaff>��, </font>");
}
}
if($flag){
push(@guest,"$times \, $jname \, $jid \, $jhost \, \n");
if($name ne $jname){
push(@member, "<a href=\"$scripta?mode=chara_sts&id=$jid\">$jname</a><font size=1 color=#aaaaff>��</font>"); 
       }
}
	
open(GUEST,">$guestfile");
print GUEST @guest;
close(GUEST);
}

1;

#----------------#
#  �Q����?��    #
#----------------#

sub guest_view {
$num = @member;
if(!@member){@member = '�ƹ��� �����ϴ�.'; $num = 0;}
print "<font size=2 color=#aaaaff>������ ������($num��) : </font><b>@member</b>";
}

1;
#----------------#
#  �Q���ғo?    #
#----------------#
sub iguest_list{

	&get_host;

	opendir(DIR,'./charalog') or die "$!";
	foreach $entry (readdir(DIR)){

	open(IN,"./charalog/$entry");
	push(@SANKA, <IN>);
	close(IN);

	}
	closedir(DIR);

	$hit=0;
	foreach(@SANKA){
		($jid,$jpass,$jsite,$jurl,$jname,$jsex,$jchara,$jn_0,$jn_1,$jn_2,$jn_3,$jn_4,$jn_5,$jn_6,$jsyoku,$jhp,$jmaxhp,$jex,$jlv,$jgold,$jlp,$jtotal,$jkati,$jwaza,$jitem,$jmons,$jhost,$jdate,$jmori,$jdef,$jtac) = split(/<>/);
		if($in{'id'} eq "$jid" and $in{'pass'} eq "$jpass") {
			$hit=1; last;
		}
	}

open(GUEST,"$guestfile");
@guest=<GUEST>;
close(GUEST);
$flag=1;
$times = time;
undef(@member);
foreach $line (@guest) {
($timer,$name,$id,$host) = split(/ \, /, $line);
if( $times-65 > $timer){
$line = '';
next;
}
if((($jname eq $name)||($id eq $jid)) && $flag){
$line = "$times \, $jname \, $jid \, $jhost \, \n";
$flag = 0;
}
}
if($flag){
push(@guest,"$times \, $jname \, $jid \, $jhost \, \n");
}
	
open(GUEST,">$guestfile");
print GUEST @guest;
close(GUEST);
}

1;
