# Sub Shipyard #
sub shipyard {
	if ($F{'yard'} == 1) { &yard_buy; return }
	if ($F{'yard'} == 2) { &yard_sell; return }
	if ($F{'yard'} == 3) { &yard_rep; return }
print <<YARD;
������<br><form method=$method action=$seacgi>
<input type=hidden name=id value="$F{'id'}">
<input type=hidden name=ps value="$F{'ps'}">
<input type=hidden name=mode value="play">
<input type=hidden name=yard value="1">
<input type=submit value="����" class=button>
</form><form method=$method action=$seacgi>
<input type=hidden name=id value="$F{'id'}">
<input type=hidden name=ps value="$F{'ps'}">
<input type=hidden name=mode value="play">
<input type=hidden name=yard value="2">
<input type=submit value="�Ű�" class=button>
</form><form method=$method action=$seacgi>
<input type=hidden name=id value="$F{'id'}">
<input type=hidden name=ps value="$F{'ps'}">
<input type=hidden name=mode value="play">
<input type=hidden name=yard value="3">
<input type=submit value="����" class=button></form>
YARD
}

# Sub Buy Yard #
sub yard_buy {
	my $YardFile = new Nfile("$datadir/$yarddat",'read');
	my @yardline = $YardFile->read;
	&form_table('up','100%',1);
	&reload;
	print qq|������:���� |;
	&submit_button;
	print qq|</td></tr><tr><td align=left>\n|;
	foreach (0 .. $#yardline) {
		($goods,$kind,$goods_img,$sale_area,$sale_port,$volume,$ship_hp,$knot,$price)
		= split(/<>/,$yardline[$_]);
		if ($sale_area =~ /$area/ || $sale_port =~ /$port/) {
			$checked = !$first ? ' checked' : '';
			$first = 1;
			&price_up;
			print qq|<input type=radio name=goods value="$_"$checked>|;
			print qq|<img src="$img/$goods_img" height=15>$goods: $price G<br>|;
			if ($kind == 1) {
				print qq|[���� : $volume ���� : $ship_hp �ӵ� : $knot]<br>\n|;
			}
			elsif ($kind == 2) {
				print qq|������+ $volume<br>\n|;
			}
			elsif ($kind == 3) {
				print qq|���ַ�+ $volume<br>\n|;
			}
			elsif ($kind == 4) {
				print qq|���ط�+ $volume<br>\n|;
			}
		}
	}
	print qq|<input type=hidden name=yard value="1"><input type=hidden name=mode value="buy_ship">\n|;
	&id_ps;
	&form_table('down');
}

# Sub Price Up #
sub price_up {
	if ($kind == 2 || $kind == 3 || $kind ==4) {
		my $rate = $atk + $cmd + $nav;
		$price = int($price * exp($rate * 0.03 - 3))
	}
}

# Sub Buy Ship #
sub buy_ship {
	&get_me($F{'id'});
	if ($action ne $F{'reload'}) { &play; exit }
	&get_port($area,$port);
	&ship_data;
	my $YardFile = new Nfile("$datadir/$yarddat",'read');
	my @yardline = $YardFile->read;
	($goods,$kind,$goods_img,$sale_area,$sale_port,$volume,$ship_hp,$knot,$price)
	 = split(/<>/, $yardline[$F{'goods'}] );
	if ( $sale_area !~ /$area/ && $sale_port !~ /$port/ ) { &play("�����մϴ�."); exit }
	&price_up;
	if ( $money < $price ) { &play("���� �����մϴ�."); exit }
	if ( $#ship_ind == 16 && $kind == 1 ) { &play("���̻��� �� �� �����ϴ�."); exit}
	if ( $kind == 1 && $#ship_ind < 16 ) {
		push(@ship_ind , "$goods_img,$volume,$ship_hp,$knot,$goods");
		&msg("$goods(��)�� ����ϴ�.");
		&add_record("$goods(��)�� $price G�� ����")
	}
	elsif ( $kind == 2 ) {
		if ($atk >= $atk_limit) { &play("���̻��� �Ұ����մϴ�."); exit }
		$atk += $volume;
		&msg("�����߽��ϴ�.");
		&add_record("������+ $volume")
	}
	elsif ( $kind == 3 ) {
		if ($cmd >= $cmd_limit) { &play("���̻��� �Ұ����մϴ�."); exit }
		$cmd += $volume;
		&msg("���ַ��� ���������ϴ�.");
		&add_record("���ַ�+ $volume")
	}
	elsif ( $kind == 4 ) {
		if ($nav >= $nav_limit) { &play("���̻��� �Ұ����մϴ�."); exit }
		$nav += $volume;
		&msg("���ط��� ���������ϴ�.");
		&add_record("���ط�+ $volume")
	}
	$action = '';
	$money -= $price;
	&play;
}

# Sub Yard Sell #
sub yard_sell {
	if ( $#ship_ind < 0) { print qq|�谡 �����ϴ�.|; &return_button; return }
	my $YardFile = new Nfile("$datadir/$yarddat", 'read');
	my @yardline = $YardFile->read;
	&form_table('up','100%',1);
	&reload;
	print qq|������:�Ű� |;
	&submit_button;
	print qq|</td></tr><tr><td align=left>\n|;
	for ($i = 0; $i <= $#ship_ind; $i++) {
		($price) = map{ (split(/<>/))[8] } grep {$ship[$i][4] eq (split(/<>/,$_))[0]} @yardline;
		$price = int($price / 2);
		$checked = $i == 0 ? ' checked' : '';
		print qq|<input type=radio name=goods value="$i"$checked>|;
		print qq|$ship[$i][4]: $price G<br>\n|;
		print qq|[���� : $ship[$i][1] ���� : $ship[$i][2] �ӵ� : $ship[$i][3]]<br>|;
	}
	print qq|<input type=hidden name=yard value="2"><input type=hidden name=mode value="sell_ship">\n|;
	&id_ps;
	&form_table('down');
}

# Sub Sell Ship #
sub sell_ship {
	&get_me($F{'id'});
	if ($action ne $F{'reload'}) { &play; exit }
	&ship_data;
	&fleet;
	&load_data;
	if ( ($total - $total_load - $food - $sailor - $ship[$F{'goods'}][1]) < 0 ) {
		&play("�ϴ� ���Ϸ��� �ٿ��ּ���.");
		return
	}
	$action = '';
	my $YardFile = new Nfile("$datadir/$yarddat", 'read');
	my @yardline = $YardFile->read;
	($price) = map{ (split(/<>/))[8] } grep {$ship[$F{'goods'}][4] eq (split(/<>/,$_))[0]} @yardline;
	splice(@ship_ind , $F{'goods'} ,1);
	my $upmoney = int($price / 2);
	$money += $upmoney;
	&msg("$ship[$F{'goods'}][4](��)�� �Ⱦҽ��ϴ�.");
	&add_record("$ship[$F{'goods'}][4](��)�� $upmoney G�� �Ű�");
	&play;
}

# Sub Yard Repair #
sub yard_rep {
	if ( $#ship_ind < 0) { print qq|�谡 �����ϴ�.|; &return_button; return }
	my $YardFile = new Nfile("$datadir/$yarddat", 'read');
	my @yardline = $YardFile->read;
	&form_table('up','100%',1);
	&reload;
	print qq|������:���� |;
	&submit_button;
	print qq|</td></tr><tr><td align=left>\n|;
	for ($i = 0; $i <= $#ship_ind; $i++) {
		($max_hp,$price) = map{ (split(/<>/))[6,8] } grep {$ship[$i][4] eq (split(/<>/,$_))[0]} @yardline;
		if (!$max_hp) { $max_hp = $ship[$F{'goods'}][1] * 0.2; $price = $ship[$F{'goods'}][1] * 10000; }
		if ($max_hp <= $ship[$i][2]) { next }
		$price = $max_hp ? int($price * 0.03 / ($ship[$i][2] / $max_hp)) : 0;
		if ($ship[$i][1] > 500) { $down = $ship[$i][1] - 20 }
		elsif ($ship[$i][1] > 100) { $down = $ship[$i][1] - 10 }
		else { $down = $ship[$i][1] }
		$checked = !$f ? ' checked' : '';
		$f = 1;
		print qq|<input type=radio name=goods value="$i"$checked>|;
		print qq|$ship[$i][4]: $price G<br>\n|;
		print qq|[���� : $ship[$i][1] ���� : $ship[$i][2] �ӵ� : $ship[$i][3]]<br>|;
		print qq|������ [���� : $down ���� : $max_hp]<br>|;
	}
	print qq|������ �� �ִ� �谡 �����ϴ�.<input type=hidden name=mode value="play">\n| if !$f;
	print qq|<input type=hidden name=yard value="3"><input type=hidden name=mode value="rep_ship">\n| if $f;
	&id_ps;
	&form_table('down');
}

# Sub Repair Ship #
sub rep_ship {
	&get_me($F{'id'});
	if ($action ne $F{'reload'}) { &play; exit }
	&ship_data;
	&fleet;
	&load_data;
	my $YardFile = new Nfile("$datadir/$yarddat", 'read');
	my @yardline = $YardFile->read;
	($max_hp,$price) = map{ (split(/<>/))[6,8] } grep {$ship[$F{'goods'}][4] eq (split(/<>/,$_))[0]} @yardline;
	if (!$max_hp) { $max_hp = $ship[$F{'goods'}][1] * 0.2; $price = $ship[$F{'goods'}][1] * 10000; }
	$price = $max_hp ? int($price * 0.03 / ($ship[$F{'goods'}][2] / $max_hp)) : 0;
	if ( $money < $price ) { &play("���� �����մϴ�."); exit }
	if ($ship[$F{'goods'}][1] > 500) { $down = 20 }
	elsif ($ship[$F{'goods'}][1] > 100) { $down = 10 }
	if ( ($total - $total_load - $food - $sailor - $down) < 0 ) {
		&play("�ϴ� ���Ϸ��� �ٿ��ּ���.");
		return
	}
	$action = '';
	$ship[$F{'goods'}][1] = $ship[$F{'goods'}][1] - $down;
	splice(@ship_ind , $F{'goods'} ,1 ,"$ship[$F{'goods'}][0],$ship[$F{'goods'}][1],$max_hp,$ship[$F{'goods'}][3],$ship[$F{'goods'}][4]");
	$money -= $price;
	&msg("$ship[$F{'goods'}][4](��)�� �����߽��ϴ�.");
	&add_record("$ship[$F{'goods'}][4](��)�� $price G�� ����");
	&play;
}

1;