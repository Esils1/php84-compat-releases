#!/usr/bin/perl

#####################################################################################################
#Program:																							#
#Comment:																							#
#-plant data
#   0      1     2        3         4         5        6      7        8
#plantID,이름,심은 시각,rcreture,성장 레벨,성장 단계,빛과 온도,초,확인한 초,
#  9  10       11        12  13      14         15    16      17      18
#수분,초,검사한초,영양,초,검사한초,위치,유전자1,유전자2,평가액,uid1,uid2,
# 21   22      23         24      25                   26
#pid1,pid2,기본 교배료,설정교배료,앨범에 저장한시간,item이용상황
#-udata
# 0   1    2    3   4    5   6  7       8         9     10      11         12             13        #     
#uid,name,pass,url,mail,sex,ken,IP,access time,open_flg,nid,간단 설명,상세 설명,앨범 최종 편집 시간,#
#       14
#bbs쓰기시간
#
#
#   Date:	20060225																				#
#Version:	1.4																						#
# Author:	Gigaho																					#
#####################################################################################################

use lib'./lib';
use strict;

require 'sys_common.cgi';
require 'inc_plant_conf.cgi';

my $PNAME    = "blog_plant.cgi";
my $VERSION  = "블로그 식물 Ver.1.4";	#script version
my $RDATA    = inc_plant_conf::get_rdata();
my $PARAM    = sys_common::param();

#설치 URL 디렉터리(설정 예: http://XXXX.ne.jp/cgi-bin/inc_plant)
$RDATA->{inc_plant_url} |= qq{};
$RDATA->{free_comment}  |= qq{};

eval {
	my $str;
	
	my $in_html = get_blog_plant_str();
	if($PARAM->{TYPE} eq "html") {$str = get_exchange_htm($in_html);}
	else {$str = get_exchange_js($in_html);}
	
	print($str);

	exit 0;
};
error_end(__LINE__, "예상치 못한 오류", $@);

exit 1;

####################################################################################################
###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_blog_plant_str
{
	my %vector;
	my $rudata  = get_udata();
	my $uid     = $rudata->[0];
	my $rplant  = get_plant_data($uid);
	my @pids    = reverse(sort {$a <=> $b} keys(%$rplant));
	my $pcount  = @pids;
	my $pnum    = (int($PARAM->{PNUM}) * 1)?
		$PARAM->{PNUM} - 1: int(rand($pcount));
	my $pid     = $pids[$pnum];
	my $rdata   = $rplant->{"$pid"};
	my $time    = get_routine_time(); $time = $rudata->[8] if($time < $rudata->[8]);
#	my $time    = $rdata->[8];
	$vector{img_dir} = "$RDATA->{inc_plant_url}/$RDATA->{img_dir}";
	$vector{author}  = qq{
		<a href="http://gigaho.ddo.jp/~game/">
		<img src="$vector{img_dir}/leaf.gif" border="0" title="「신기한 식물」첫 화면으로" /></a>
	};
		
	$vector{freestr} = $RDATA->{free_comment} if(!($PARAM->{AD} eq "0"));	#<- 임의 표시인 경우
	$vector{freestr} = $RDATA->{free_comment} if(!($PARAM->{AD} eq "0"));	#<- 임의 표시인 경우
	$vector{namestr} = $rdata->[1] || qq{
		<font color="red">설치 오류입니다!<br>
		<a href="$RDATA->{inc_plant_url}/inc_plant.cgi?MODE=album">ID</a>가 정확한가요?
		</font>
	};
	$vector{daytime} = get_daytime_htm($time);

	my $bgcol   = get_time_bgcol($time, $rdata->[15]);
	my $bg      = get_safe_param($PARAM->{BG});
	my $bg_view = ($bg)? qq{background="$bg"}: qq{bgcolor="$bgcol"};
	$vector{plant} = get_flower_img_htm($rudata, $rdata, $bg_view);
	$vector{uname} = $rudata->[1];
	
	my $in_html = get_in_html(\%vector);
	$in_html =~ s/\n|\r//g;
	
	return $in_html;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_exchange_js
{
	my ($in_html) = @_;
	my $str;
	
	$str .= "Content-Type: text/javascript\n";
	$str .= "Pragma: no-cache\n";
	$str .= "Cache-Control: no-cache\n\n";
	$str .= "document.write('$in_html')";
	
	return $str;
}


###################################################
#  input:()
# retrun:
#comment:
#	<iframe src="http://URL/blog_plant.cgi?TYPE=html&..." frameborder="0" scrolling="no" width="140" height="300"></iframe>
###################################################
sub get_exchange_htm
{
	my ($in_html) = @_;
	
	my $str = "Content-type: text/html\n\n";
	$str .= qq{<html>
		<head>
		<style type="text/css">
		<!--
			body {margin:0px}
		-->
		</style>
		<meta HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
		<meta NAME="author" CONTENTS="GIGAHO">
		<link rel="stylesheet" type="text/css" href="$RDATA->{css_dir}/inc_plant.css">
		<title>블로그 식물</title>
		</head>
		<body bgcolor='#d1f8d8' background='' onLoad=''>$in_html</body></html>
	};
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_in_html
{
	my ($rvector) = @_;
	my $in_html;
	my $templ_file = $PARAM->{TEMPLATE}; $templ_file=~ s/[\\\/]//g;
	my $templ_path = ($templ_file && (-e "$RDATA->{sys_dir}/template/$templ_file"))?
		"$RDATA->{sys_dir}/template/$templ_file":
		"$RDATA->{sys_dir}/template/default.tpl";
	
	open(IN, $templ_path) || error_end(__LINE__, "파일 오류", $!);
	while(<IN>) {
		my $cp = $_;
		while(/\${(.+?)}/g) {
			my $new_str = $rvector->{$1};
			$cp =~ s/\${$1}/$new_str/g;
		}
		$in_html .= $cp;
	}
	close(IN) || error_end(__LINE__, "파일 오류", $!);
	
	return $in_html;
	
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_flower_img_htm
{
	my ($rudata, $rdata, $bg_view) = @_;
	
	my ($grow_step, $sun, $water, $nut) = @$rdata[5, 6, 9, 12];
	my ($uid, $uname) = (@$rudata)[0, 1];
	my $pid      = $rdata->[0];
	my $img_dir  = "$RDATA->{inc_plant_url}/$RDATA->{img_dir}";
	my $alb_dir  = "$RDATA->{inc_plant_url}/$RDATA->{album_img}";
	my $img_step = ($grow_step == 6)? 0: $grow_step;
	my $soil_bg  = ($PARAM->{SOIL} eq "0")?
		qq{background="$img_dir/soil0.gif"}:
		qq{background="$img_dir/soil1.gif"};
	my $flamecol = get_safe_param(substr($PARAM->{FLAMECOL}, 0, 7)) || "#186118";
	
	my ($htm_h, $htm_t);
	for(my $organ_id = 1; $organ_id <= 3; $organ_id++) {
		$htm_h .= qq{
			<table cellspacing="0" cellpadding="0"><tr>
			<td background="$alb_dir/u$uid/p${img_step}_${organ_id}_${pid}.gif">
		} if($pid >= 0);
		$htm_t .= qq{
			</td></tr></table>
		} if($pid >= 0);
	}
	
	my $link;
	if($PARAM->{LINK} eq "album") {
		$link = "OPT=$uid&MODE=album";
	} else {
		$link = "MODE=view_parent&UID=$uid&PID=$pid&BK=1";
	}
	
	my $yn = ($PARAM->{TYPE} eq "html")? '&#10;': '\\n';
	my $popup = "「$uname」님의 식물$yn---------$yn단계: $RDATA->{step}->[$grow_step]->[0]$yn---------$yn햇빛: $sun/9$yn수분: $water/9$yn영양: $nut/9";
	return ($uid <= 1)? qq{
		<table border="0" cellpadding="0" cellspacing="0"><tr><td $bg_view>
		<table cellspacing="0" cellpadding="0"><tr>
		<td $soil_bg>
		$htm_h
		<img style="border-color: $flamecol; border-width: 1px;" src="$img_dir/space.gif" height=200 width=100 align=top border=1>
		$htm_t
		</td></tr></table></td></tr></table>
	}: qq{
		<table border="0" cellpadding="0" cellspacing="0"><tr><td $bg_view>
		<table cellspacing="0" cellpadding="0"><tr>
		<td $soil_bg>
		$htm_h
		<a href="$RDATA->{inc_plant_url}/inc_plant.cgi?$link">
		<img style="border-color: $flamecol; border-width: 1px;" src="$img_dir/space.gif" height=200 width=100 align=top alt="" title="$popup" border=1></a>
		$htm_t
		</td></tr></table></td></tr></table>
	};
}

###################################################
#  input:()
# retrun:
#comment: $place = 1: 집 밖, 2: 집 안
###################################################
sub get_time_bgcol
{
	my ($time, $place) = @_;
	my $res_col;
	my $hour = (localtime($time))[2];
	if($place  <= 1) {
		if   (6  <= $hour && $hour < 17) {$res_col = "#ddeeee";}
		elsif(17 <= $hour && $hour < 19) {$res_col = "#e3d2b5";}
		else                             {$res_col = "#ffffdd";}
	} else {
		if   (6  <= $hour && $hour < 17) {$res_col = "#ddffff";}
		elsif(17 <= $hour && $hour < 19) {$res_col = "#ffdd99";}
		else                             {$res_col = "#dadada";}
	}
	
	return $res_col;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_daytime_htm
{
	my $time = shift;
	
	my ($sec, $min, $hour, $mday, $mon, $year)
		= (localtime($time))[0, 1, 2, 3, 4, 5];
	
	$sec  = sprintf("%02d", $sec);
	$min  = sprintf("%02d", $min);
	$hour = sprintf("%02d", $hour);
	$mday = sprintf("%02d", $mday);
	$mon  = sprintf("%02d", $mon + 1);
	
	my $time_str = ($year + 1900) . "년$mon월$mday일<br>$hour시$min분 " ;
	
	return $time_str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_udata
{
	my $uid   = $PARAM->{UID};
	my $unid  = $PARAM->{ID};
	my $uname = $PARAM->{NAM};
	
	if(-e "$RDATA->{data_dir}/user.cgi") {
		open(USER, "$RDATA->{data_dir}/user.cgi")
			|| error_end(__LINE__, "파일 오류", $!);
		while(chomp(my $line = <USER>)) {
			my @dt = split("\t", $line, 12);
			if((defined($uid) && $uid eq $dt[0]) ||
				(defined($unid) && $unid eq $dt[10]) ||
				(defined($uname) && $uname eq $dt[1])
			) {return \@dt;}
		}
		close(USER) || error_end(__LINE__, "파일 오류", $!);
	}
	
	return undef;
}

###################################################
#  input:()
# retrun:
#comment: plant.cgi에서 데이터를 추출합니다.
###################################################
sub get_plant_data
{
	my $uid = shift;
	my %status;
	
	if(-e "$RDATA->{data_dir}/u$uid/plant.cgi") {
		open(PLANT, "$RDATA->{data_dir}/u$uid/plant.cgi")
			|| error_end(__LINE__, "파일 오류", $!);
		while(chomp(my $line = <PLANT>)) {
			if(!$line) {next;}
			my @plant = split("\t", $line);
			$status{"$plant[0]"} = \@plant;
		}
		close(PLANT) || error_end(__LINE__, "파일 오류", $!);
	}
	
	return \%status;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_routine_time
{
	my $line;
	
	if(-e ("$RDATA->{data_dir}/timer.cgi")) {
		open(TIMER, "$RDATA->{data_dir}/timer.cgi")
			|| error_end(__LINE__, "파일 오류", $!);
		chomp($line = <TIMER>);
		close(TIMER) || error_end(__LINE__, "파일 오류", $!);
	}
	
	return $line;
}

###################################################
#  input:()
# retrun:
#comment: HTML 이스케이프 처리
###################################################
sub get_safe_param
{
	my ($str) = @_;

	$str =~ s/[<>"']//g;

	return $str;
}

#####################################################################################################
###################################################
#  input:($type, $comment, $point)
# retrun:exit 1
#comment: 오류 처리 서브루틴
###################################################
sub error_end
{
	my ($point, $type, $comment) = @_;
	$comment =~ s/\n//g;
	
	sys_common::error_htm($PNAME, $point, $type, $comment, {file => "$RDATA->{'data_dir'}/cgi.err"});

	exit 1;
}
####################################################################################################

1;
