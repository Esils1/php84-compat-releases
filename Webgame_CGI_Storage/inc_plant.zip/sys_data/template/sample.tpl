<table cellspacing="0" cellpadding="0" border="0">
	<tr><td align="center" background="${img_dir}/flame.gif" bgcolor="#729e86">
		<table width="140" height="300">
			<tr><td height="5"></td></tr>
			<tr><td></td><td align="center">
				<div style="font-size:15px; color:black;" width="120"><b>${namestr}</b></div>
			</td><td></td></tr>
			<tr><td colspan="3" align="center">${plant}</td></tr>
			<tr><td colspan="3" align="center">
				<table><tr>
					<td>${author}</td>
					<td><div style="font-size:12px; color:black;">${daytime}</div></td>
				</tr></table>
			</td></tr>
			<tr><td colspan="3">${freestr}</td></tr>
			<tr><td height="5"></td></tr>
		</table>
	</td></tr>
</table>
