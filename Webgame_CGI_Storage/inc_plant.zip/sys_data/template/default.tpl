<table cellspacing="0" cellpadding="0" border="0">
	<tr><td align="center" background="${img_dir}/flame3.gif" bgcolor="#729e86">
		<table width="140" height="300">
			<tr><td height="3"></td></tr>
			<tr><td width="135"><center>${plant}</center></td></tr>
			<tr><td height="15"></td></tr>
			<tr><td align="center">
				<div style="font-size:15px; color:black;"><b>${namestr}</b></div>
			</td></tr>
			<tr><td align="center">
				<table><tr>
					<td>${author}</td>
					<td><div style="font-size:11px; color:black;"><b>${daytime}</b></div></td>
				</tr></table>
			</td></tr>
			<tr><td align="center">${freestr}</td></tr>
			<tr><td height="1"></td></tr>
		</table>
	</td></tr>
</table>
