package inc_inc;
#####################################################################################################
#Program:																							#
#Comment:																							#
#																									#
#   Date:	20060122																				#
#Version:	1.0																						#
# Author:	gigaho																					#
#####################################################################################################
use strict;

my $MAX_POWER = 10000;

# tttttaaaaa를 재조합 지점으로 사용하므로 ttt라는 배열명은 사용하지 마세요
my %TRNA = (
	"TT" =>  0, "TA" =>  1, "TC" =>  2, "TG" =>  3,
	"AT" =>  4, "AA" =>  5, "AC" =>  6, "AG" =>  7,
	"CT" =>  8, "CA" =>  9, "CC" => 10, "CG" => 11,
	"GT" => 12, "GA" => 13, "GC" => 14, "GG" => 15,
);

###################################################
#my (%creature, @lines);
#open(DNA, "test_dna.dat") || die $!;
#while(chomp(my $line = <DNA>)) {
#	add_translated_gene_data(\%creature, $line);
#	push(@lines, $line);
#}
#add_expression_data(\%creature);
#
#print_all_gene_annotation(\%creature);
#
#my $rchrom = get_chromosome_stracture(\@lines);
#print("Recombnant point: @{$rchrom->[0]->{rec_poi}}\n");
#print("Recombnant point: @{$rchrom->[1]->{rec_poi}}\n");
#for(my $cnt = 0; $cnt < 10; $cnt++) {
#	my (%cr);
#	
#	my $body_seq = get_nbody_from_rchrom2($rchrom);
#	add_translated_gene_data(\%cr, $body_seq);
#	add_expression_data(\%cr);
#	print("\n======\n$body_seq\n");
#	print_all_gene_annotation(\%cr);
#	
#}
#
#my $organ_max = $creature{organ_max};
#if(!($organ_max->{"1"} * $organ_max->{"2"} * $organ_max->{"3"} * $organ_max->{"4"})) {
#	# 일부 기관을 만들 수 없음
#my $test = $organ_max->{"1"};
#	print("일부 기관을 만들 수 없음: $test\n"); exit 1;
#}
#
#print("탄생\n");
#close(DNA) || die $!;
#exit 0;
#
###################################################
#Incredible Incect
###################################################
#  input:()
# retrun:	$->{"organ_id"}->{protein}->[n]->{"quality"} = value
#
#comment:quality에 대해
#		organ 기관의 씨앗종류(1 잎, 2 줄기, 3 꽃),(1 머리, 2 가슴, 3 날개(배), 4 다리)
#		domain 이미지의 씨앗종류,
#		reaction strength를 더할지 여부(1: 더함, 2: 더하지 않음)
#		strength 강도
###################################################
sub add_translated_gene_data
{
	my ($rcreature, $line) = @_;
	
	my $new_point = 0;
	while((my $point = index($line, "ATG", $new_point)) != -1) {
		if(!($new_point = get_stop_codon_point($line, $point))) {
			# 종결 코돈이 없음
			die("종결코돈가\n"); exit 1;
		}
		my $mrna_lng;
		if(($mrna_lng = $new_point - $point) < 36) {
			#이상단백질
			die("이상단백질\n"); exit 1;
		}
		my $tcript   = substr($line, $point - 12, 53);
		my $mrna     = substr($line, $point, $mrna_lng);
		my $organ    = get_ribosome(substr($mrna,  3,  6));
		my $domain   = get_ribosome(substr($mrna,  9, 12));
		my $reaction = get_ribosome(substr($mrna, 21,  3));
		my $strength = get_ribosome(substr($mrna, 24, 12));
		my $quality  = {
			organ => $organ, domain => $domain, reaction => $reaction,
			strength => $strength, transcript => $tcript
		};
		push(@{$rcreature->{"$organ"}->{protein}}, $quality);
	}
	
	return 1;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_stop_codon_point
{
	my ($line, $point) = @_;
	for(my $in_poi = $point + 3; $in_poi + 2 < length($line); $in_poi += 3) {
		my $codon = substr($line, $in_poi, 3);
		if($codon =~ /TAA|TAG|TGA/) {return $in_poi;}
	}
	
	return undef;
}
	

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_ribosome
{
	my $domain_str = shift;
	my $res;

	for(my $poi = 0; $poi < length($domain_str) / 3; $poi++) {
		my $codon_str = substr($domain_str, $poi * 3, 2);
		$res += $TRNA{"$codon_str"} * (16 ** $poi);
	}

	return $res;
}

###################################################
#  input:()
# retrun:	$->{"organ_id"}->{protein}->[n] = quality
#			               ->{view}  = [n,...]
#			               ->{power} = total_strength
#comment:quality에 대해
#		organ 기관의 씨앗종류(1 잎, 2 줄기, 3 꽃),(1 머리, 2 가슴, 3 날개(배), 4 다리),
#		domain 이미지의 씨앗종류,
#		reaction strength를 더할지 여부
#		strength 강도
###################################################
sub add_expression_data
{
	my ($rcreature) = @_;
	
	foreach (values(%$rcreature)) {
		my ($min_strng, $stack_strng, $top_img, %sorter, @view_sort);
		for(my $cnt = 0; $cnt < @{$_->{protein}}; $cnt++) {
			my $reaction = $_->{protein}->[$cnt]->{reaction};
			my $strength = $_->{protein}->[$cnt]->{strength};
			if($reaction == 1) {
				$stack_strng += $strength;
				push(@{$sorter{"$strength"}}, $cnt);
			} elsif(!defined($min_strng) || $min_strng > $strength) {
				$min_strng = $strength;
				$top_img = $cnt;
			}
		}
		$stack_strng += $min_strng;
		$_->{power} = $stack_strng % $MAX_POWER;		#최대파워
		my @sorter_res = sort { $a <=> $b } keys(%sorter);
		@view_sort = ($sorter{"$sorter_res[0]"}->[0]);
		
		if(defined($top_img)) {@view_sort = ($top_img);}
		$_->{view} = \@view_sort;
	}
	
	return 1;
}

###################################################
#  input:()
# retrun:$chrom[배열번호]->{sequence} = 배열
#                        ->{rec_poi}->[n] = 재조합 지점
#comment:
###################################################
sub get_chromosome_stracture
{
	my ($rchromo) = @_;
	my @chrom;
	
	for(my $cnt = 0; $cnt < 2; $cnt++) {
		my $seq = $rchromo->[$cnt];
		$chrom[$cnt]->{sequence} = $seq;
		
		my $new_point = 0;
		while((my $point = index($seq, "TTTTAAAA", $new_point)) != -1) {
			push(@{$chrom[$cnt]->{rec_poi}}, $point + 4);
			$new_point = $point + 1;
		}
	}
	
	return \@chrom;
}

###################################################
#  input:()
# retrun:	$->{"organ_id"}->{protein}->[n] = quality
#			               ->{view}  = [n,...]
#			               ->{power} = total_strength
#comment:quality에 대해
#		organ 기관의 씨앗종류(1 잎, 2 줄기, 3 꽃),(1 머리, 2 가슴, 3 날개(배), 4 다리),
#		domain 이미지의 씨앗종류,
#		reaction strength를 더할지 여부
#		strength 강도
###################################################
sub print_all_gene_annotation
{
	my $rcreature = shift;
	my @body_parts = ("", "kuki", "leaf", "flower", "foot");
	
	while(my ($key, $val) = each(%$rcreature)) {
		my $parts_name = $body_parts[$key];
		print("Parts: $parts_name\n");
		print("\tView: @{$val->{view}}\n");
		print("\tPower: $val->{power}\n");
		print("\tEach gene:\n");
		foreach (@{$val->{protein}}) {
			while(my ($gen_key, $gen_val) = each(%$_)) {
				print("\t\t$gen_key: $gen_val\n");
			}
		}
	}
	
	return 1;
}


###################################################
###################################################
#  input:()
# retrun:
#comment: $mid_poi는 0 <= $mid_poi <= 1 범위입니다.
#			$mid_poi에 가까운 임의 값을 산출합니다.
###################################################
sub get_recombination_rand
{
	my ($mid_poi) = @_;
	my $bai = 4;
	my $res;
	
	if($mid_poi < 0.0001) {return 0.0001;}
	if($mid_poi > 0.9999) {return 0.9999;}
	
	my $rnd = rand();
	if($rnd < $mid_poi) {
		$res = (1 - (($mid_poi - $rnd) / $mid_poi) ** $bai) * $mid_poi;
#		$res = - (1 / $mid_poi * ($rnd ** 2)) + 2 * $rnd;
	} else {
		$res = ((($rnd - $mid_poi) / (1 - $mid_poi)) ** $bai)
			* (1 - $mid_poi) + $mid_poi;
#		$res = 1 / (1 - $mid_poi) * (($rnd - $mid_poi) ** 2) + $mid_poi;
	}
	
	return $res;
}

###################################################
#  input:()
# retrun:
#comment: 새 반수체 배열을 만듭니다.
#			$rchrom은 get_chromosome_stracture에서 얻습니다.
###################################################
sub get_nbody_from_rchrom
{
	my ($rchrom) = @_;
	my (%creature, $new_dna);
	
	add_translated_gene_data(\%creature, $rchrom->[0]->{sequence});
	add_translated_gene_data(\%creature, $rchrom->[1]->{sequence});
	add_expression_data(\%creature);
	my $total_s = $creature{"1"}->{power}
		+ $creature{"2"}->{power} + $creature{"3"}->{power};
	
	for(my $cnt = 0; $cnt < 20; $cnt++) {
		my (%hlf_cr);
		$new_dna = "";
		if(rand() < 0.5) {
			my $rnd = rand();
		
			my $rep0 = int((@{$rchrom->[0]->{rec_poi}} - 1) * $rnd) + 1;
			my $rep1 = int((@{$rchrom->[1]->{rec_poi}} - 1) * (1 - $rnd)) + 1;
			if(rand() < 0.5) {
				$new_dna .= substr($rchrom->[0]->{sequence}, 0,
					$rchrom->[0]->{rec_poi}->[$rep0] - 5);
				$new_dna .= substr($rchrom->[1]->{sequence}, 0,
					$rchrom->[1]->{rec_poi}->[$rep1] - 5);
			} else {
				$new_dna .= substr($rchrom->[1]->{sequence},
					$rchrom->[1]->{rec_poi}->[$rep1] - 5);
				$new_dna .= substr($rchrom->[0]->{sequence},
					$rchrom->[0]->{rec_poi}->[$rep0] - 5);
			}
		} else {
			my $rnd = rand();
		
			my $rep0 = int(@{$rchrom->[0]->{rec_poi}} * $rnd);
			my $rep1 = int(@{$rchrom->[1]->{rec_poi}} * $rnd);
			if(rand() < 0.5) {
				$new_dna .= substr($rchrom->[0]->{sequence}, 0,
					$rchrom->[0]->{rec_poi}->[$rep0]);
				$new_dna .= substr($rchrom->[1]->{sequence},
					$rchrom->[1]->{rec_poi}->[$rep1]);
			} else {
				$new_dna .= substr($rchrom->[1]->{sequence}, 0,
					$rchrom->[1]->{rec_poi}->[$rep1]);
				$new_dna .= substr($rchrom->[0]->{sequence},
					$rchrom->[0]->{rec_poi}->[$rep0]);
			}
		}
			
		add_translated_gene_data(\%hlf_cr, $new_dna);
		add_expression_data(\%hlf_cr);
		if(
			$hlf_cr{"1"}->{power} * $hlf_cr{"2"}->{power} * $hlf_cr{"3"}->{power}
			&& ($cnt % 2 == 0 || $hlf_cr{"1"}->{power} + $hlf_cr{"2"}->{power} 
			+ $hlf_cr{"3"}->{power} >= $total_s)
		) {
			last;
		}
	}

	return $new_dna;
}

###################################################
#  input:()
# retrun:
#comment: 새 반수체 배열을 만듭니다.
#			$rchrom은 get_chromosome_stracture에서 얻습니다.
###################################################
sub get_nbody_from_rchrom_
{
	my ($rchrom) = @_;

	my $rnd0 = rand();
	my $rnd1 = get_recombination_rand($rnd0);
	my $rep0 = int(@{$rchrom->[0]->{rec_poi}} * $rnd0);
	my $rep1 = int(@{$rchrom->[1]->{rec_poi}} * $rnd1);
	
	my $body_seq = get_nbody_seq($rchrom, $rep0, $rep1);
	
	return $body_seq;
}

###################################################
#  input:()
# retrun:
#comment: 새 반수체 배열을 만듭니다.
#			
###################################################
sub get_nbody_seq
{
	my ($rchrom, $rep0, $rep1) = @_;
	my $new_dna;
	
	if(rand() < 0.5) {
		$new_dna .= substr($rchrom->[0]->{sequence}, 0,
			$rchrom->[0]->{rec_poi}->[$rep0]);
		$new_dna .= substr($rchrom->[1]->{sequence}, 
			$rchrom->[1]->{rec_poi}->[$rep1]);
	} else {
		$new_dna .= substr($rchrom->[1]->{sequence}, 0,
			$rchrom->[1]->{rec_poi}->[$rep1]);
		$new_dna .= substr($rchrom->[0]->{sequence}, 
			$rchrom->[0]->{rec_poi}->[$rep0]);
	}
	
	return $new_dna;
}

1;
