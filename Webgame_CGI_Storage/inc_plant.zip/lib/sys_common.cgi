package sys_common;
#####################################################################################################
#Program:																							#
#Comment:																							#
#	기능: log 출력용 공통 서브루틴(로그 파일에 기록합니다)						#
#	인수: errorSub(log 파일 위치, 발생 위치, submit/error 등의 내용, 상세 내용, $option)	#
#																									#
#$option-+->{exit}   = exit 값(미지정 시: 1)									#
#        |																							#
#        +->{return} = return 값(지정하면 exit하지 않음)						#
#        |																							#
#        +->{file}   = "no" 지정 시 로그를 출력하지 않음. 또는 파일 경로를 입력,		#
#        |					미지정 시에는 ~HOME/logs/script.log에 출력됩니다)							#
#        |																							#
#																									#
#																									#
#   Date:	20050306																				#
# Update:	20051203																				#
#Version:	1.2																						#
# Author:	Gigaho																					#
#####################################################################################################
use strict;

###################################################
#  input:()
# retrun:
#comment:
#오류서브루틴(new)공통
###################################################
sub write_log
{
	my ($place, $type, $comment, $ropt) = @_;
	
	my $date     = localtime();
	my $ip       = $ENV{"REMOTE_ADDR"};
	my $client   = $ENV{"HTTP_USER_AGENT"};

	my $log_file = $ropt->{"file"};
	my $out_str  = "$date|$ip|$client|$place|$type|$comment\n";
	if($log_file ne "no") {
		if(!defined($log_file)) {$log_file = "default.cgi";}
		open(LOG,">>$log_file")
			|| die "$log_file Log open error $!\n";
		print LOG $out_str;
		close(LOG)
			|| die "$log_file Log close error $!\n";
		if($ropt->{"print"}){print $out_str;}
	}
	
	my $ret_num = $ropt->{return};
	if(!defined($ret_num)){
		my $exit_num = $ropt->{exit};
		if(defined($exit_num)){exit $exit_num;}
		exit 1;
	}
	
	return $ret_num; 
}

###################################################
#  input:()
# retrun:
#comment:
#comment: 오류 표시용 HTML
###################################################
sub error_htm
{
	my ($pname, $line, $type, $comment, $ropt) = @_;
	write_log("$pname($line)", $type, $comment, {
		file   => $ropt->{file},
		return => 1
	});
	
	my $logo = $ropt->{logo};
	my $back = $ropt->{back};
	if(!defined($back)){$back = "javascript:history.back();"}
	my $reflesh = ($ropt->{reflesh})?
		qq{<META HTTP-EQUIV="REFRESH" CONTENT="2;URL=$ropt->{reflesh}">}:"";
	
	print("Content-type: text/html\n\n");
	print qq{<HTML>
		<HEAD>
		<META HTTP-EQUIV='Content-Type' CONTENT='text/html; charset=UTF-8'>
		$reflesh
			<TITLE>$type</TITLE>
		</HEAD>
		<BODY BGCOLOR='#FFFFFF'>
		<BR>
		<CENTER><H1><FONT COLOR='red'>$type</FONT></H1><BR>
			<H2>$ropt->{v}</H2>
		</CENTER>
		<HR ALIGN='CENTER' WIDTH='100%'>
		<A HREF='$back'>BACK</A><BR>
	};
	
	if(defined($logo)){
		print("<IMG SRC=$logo WIDTH='220' HEIGHT='30' ALIGN='right' BORDER='0'>\n");
	}

	print("</BODY></HTML>\n");
	
	exit 1;
}


###################################################
#  input:()
# retrun:
#comment:
###################################################
sub param
{
	my (%param, $buffer);
	
	if ($ENV{'REQUEST_METHOD'} eq "POST") {
		if ($ENV{'CONTENT_LENGTH'} > 51200) { die "전송한 내용이 너무 큽니다"; }
		read(STDIN, $buffer, $ENV{'CONTENT_LENGTH'});
	} else { $buffer = $ENV{'QUERY_STRING'}; }
	my @pairs = split(/&/, $buffer);
	foreach (@pairs) {
		my ($name, $value) = split(/=/, $_);
		$value =~ tr/+/ /;
		$value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;

		$param{$name} = $value;
	}
	
	return \%param;
}

1;

