#!/usr/bin/perl

#####################################################################################################
#Program:																							#
#Comment:																							#
#-dna data
#
#dna,이름,
#
#-udata
# 0   1    2    3   4    5   6  7       8         9     10      11         12             13        #     
#uid,name,pass,url,mail,sex,ken,IP,access time,open_flg,nid,간단 설명,상세 설명,앨범 최종 편집 시간,#
#       14
#bbs쓰기시간
#
#-plant data
#   0      1     2        3         4         5        6      7        8
#plantID,이름,심은 시각,rcreture,성장 레벨,성장 단계,빛과 온도,초,확인한 초,
#  9  10       11        12  13      14         15    16      17      18
#수분,초,검사한초,영양,초,검사한초,위치,유전자1,유전자2,평가액,uid1,uid2,
# 21   22      23         24      25                   26
#pid1,pid2,기본 교배료,설정교배료,앨범에 저장한시간,item이용상황
#																									#
#-status data->[0]
# 0      1      2     3      4                  5          6    7    8
#금액,등록 초,등록 시간,등급,꽃 수(total),보유 종자 수,보유 가능 종자 수,,보유 가능 화분 수
#         9                        10                     11                      12
#,마지막으로 음악을 들려준 시각,앨범 저장 가능 식물 수,앨범 내 식물 수,지금까지 개화한 식물 수
#																									#
#-seed data
# 0      1        2     3      4       5      6       7       8     9
#pid,사용 가능 여부,이름,유전자1,유전자2,가격,자신uid,상대uid,자신pid,상대pid
#※ 가격은 plant data의 18번 항목과 일치하지 않을 수 있음
#
#-mail data
#    0       1    2     3       4
#송수신 구분,시각,UID,comment,신규 Flag
#
#-아이템데이터
# 0 ,  1      2     3       4            5         6      7
#iid, name, price, img,최대 보유 가능 수, 판매가,(등급용 예비 필드),설명
#
#   Date:	20060225																				#
#Version:	1.10																						#
# Author:	H.Wakaguri(GIGAHO)																		#
#####################################################################################################

use lib'./lib';
use strict;

require 'sys_common.cgi';
require 'inc_plant_conf.cgi';
require 'inc_inc.cgi';

my $PNAME = "inc_plant_maker.cgi";
my $VERSION = "신기한 식물 메이커 Ver.1.11";	#script version
my $RDATA = inc_plant_conf::get_rdata();

# 관리자 비밀번호 설정(inc_plant_conf.cgi에 설정하면 그 값이 우선됩니다)
$RDATA->{manager_pass} ||= "";

#MODE, UID, NAM, PWD, HP, MAIL, OPT, IID
my $PARAM = sys_common::param();

my @BODY_PARTS = ("", "튼튼함(줄기)", "향기(잎)", "아름다움(꽃)");
my @CODON = (
	"TTA", "TAC", "TCA", "TGG",
	"ATA", "AAG", "ACA", "AGG",
	"CTC", "CAC", "CCA", "CGG",
	"GTG", "GAA", "GCC", "GGA",
);

eval {
	my $rstr;
	
	if(!$RDATA->{manager_pass}) {
		$rstr = get_no_manager_htm();
	} elsif($PARAM->{MODE} eq "login") {
		$rstr = get_login_htm();
	} elsif($PARAM->{MODE} eq "server_login") {
		$rstr = get_server_login_htm();
	} elsif(is_cookie_ok()) {
		# 여기부터는 로그인 상태에서만 실행 가능
		if($PARAM->{MODE} eq "main" || $PARAM->{MODE} eq "dna_regist") {
			$rstr = get_main_htm();
		} elsif($PARAM->{MODE} eq "image_all") {
			$rstr = get_image_all_htm();
		} elsif($PARAM->{MODE} eq "secret_view") {
			$rstr = get_secret_view_htm();
		} elsif($PARAM->{MODE} eq "pure_view") {
			$rstr = get_pure_view_htm();
		} elsif($PARAM->{MODE} eq "file_error_log") {
			$rstr = get_file_error_log();
		} elsif($PARAM->{MODE} eq "file_user") {
			$rstr = get_file_user();
		} elsif($PARAM->{MODE} eq "remake_pspace") {
			$rstr = get_remake_plant_data();
		} elsif($PARAM->{MODE} eq "reset") {
			$rstr = get_reset_timer_data();
		} elsif($PARAM->{MODE} eq "check_data") {
			# 결과 표시 주의
			$rstr = print_check_data();
		} else {
			$rstr = get_start_htm();
		}
	} else {
		$rstr = get_start_htm();
	}
	
	print_headder() if($PARAM->{MODE} ne "check_data");
	print($$rstr);
	exit 0;
};
error_end(__LINE__, "예상치 못한 오류", $@);

exit 1;

####################################################################################################
###################################################
#  input:()
# retrun:
#comment:
###################################################
sub print_headder
{
	#for mac
	print("Pragma: no-cache\n");
	print("Cache-Control: no-cache\n");
	print("Expires: Thu, 01 Dec 1994 16:00:00 GMT\n");
	
	return 1;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_reset_timer_data
{
	my $str = "Content-type: text/html\n\n";

	$str .= qq{<HTML>
		<HEAD>
		<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
		<META NAME="author" CONTENTS="GIGAHO">
		<link rel="stylesheet" type="text/css" href="./inc_plant.css">
		<TITLE>신기한 식물 메이커(타이머 초기화)</TITLE>
		</HEAD>
		<BODY BGCOLOR='#d1f8d8' background='' onLoad=''><center>
	};
	if(is_exist_lockfile()) {
		$str .= qq{
			<br><font color='red'>$RDATA->{lock_dir}/lockfile 을삭제하고점검 모드에해 주세요.</font><br>
			&nbsp;&nbsp;&nbsp;
			<form>
				<input type="button" value='다음' onClick='location.href="$PNAME?MODE=reset"'>
				<input type="button" value='취소' onClick='location.href="$PNAME?MODE=main"'>
			</form>
		};
	} else {
		get_reset_data();
		$str .= qq{
			<br><font color='red'>타이머 초기화가 완료되었습니다.</font><br>
			&nbsp;&nbsp;&nbsp;
			<form>
				<input type="button" value='ＯＫ' onClick='location.href="$PNAME?MODE=main"'>
			</form>
		};
	}
	$str .= "</center>\n";
	$str .= get_copyright();
	$str .= "</body></html>\n";
	
	return \$str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_reset_data
{
	my $time = time;
	
	my $rusr = get_user_data();
	foreach (@$rusr) {
		my $uid    = $_->[0];
		my $rplant = get_plant_data($uid);
		foreach (@$rplant) {
			@$_[7, 8, 10, 11, 13, 14]
				= ($time, $time, $time, $time, $time, $time);
		}
		put_plant_data($uid, $rplant);
		$_->[8] = $time;
	}
	put_user_data($rusr);
	put_routine_time($time);
	
	return 1;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub print_check_data
{
	my $str;
	my $rnames = get_image_files_name();
	my $rokim  = $rnames->{okim};
	
	print("Content-type: text/html\n\n");
	print qq{<HTML>
		<HEAD>
		<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
		<META NAME="author" CONTENTS="GIGAHO">
		<link rel="stylesheet" type="text/css" href="./inc_plant.css">
		<TITLE>신기한 식물 메이커(데이터정합성검사)</TITLE>
		</HEAD>
		<BODY>
	};
	print("<b>순계식물데이터($RDATA->{sys_dir}/represent_plant.cgi)의 데이터정합성</b><br>\n");
	if(print_check_each_pure()){
		print "<font color='blue'>정상</font><br>\n";
	}
	print("<hr>\n");
	
	print("<b>유전자 데이터($RDATA->{sys_dir}/dna.cgi)의 데이터정합성</b><br>\n");
	if(print_check_each_dna($rokim)){
		print "<font color='blue'>정상</font><br>\n";
	}
	print("<hr>\n");
	
#	print("UID=1(플라워 팜)의 데이터정합성<br>\n");
#	if(print_check_each_user(1, "album")){
#		print "<font color='blue'>정상</font><br>\n";
#	}
#	print("<hr>\n");
	
	my $rusr = get_user_data();
	foreach (reverse(@$rusr)) {
		my ($uid, $name, $acctime) = (@$_)[0, 1, 8];
		print("UID=$uid($name)의 데이터정합성<br>\n");
		my $flg = print_check_each_user($rokim, $uid, "album")
			* print_check_each_user($rokim, $uid, "plant")
			* print_check_each_user($rokim, $uid, "seed");
		
		if($flg){
			print "<font color='blue'>정상</font><br>\n";
		}
		print("<hr>\n");
	}
	$str = qq{
		<br>데이터 검사가 정상적으로 종료되었습니다.<br>
		&nbsp;&nbsp;&nbsp;
		<form><input type="button" value='돌아가기' onClick='history.back()'></form>
		</body></html>
	};
	
	return \$str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_remake_plant_data
{
	my $str;
	if(is_exist_lockfile()) {
		$str = get_lockfile_not_found();
	} else {
	
		$str = "Content-type: text/html\n\n";
		$str .= qq{<HTML>
			<HEAD>
			<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
			<META NAME="author" CONTENTS="GIGAHO">
			<link rel="stylesheet" type="text/css" href="./inc_plant.css">
			<TITLE>신기한 식물 메이커(plant.cgi 파일 복구 작업)</TITLE>
			</HEAD>
			<BODY>
		};
		$str .= get_renew_plant_data();
		$str .= qq{
			<hr>
			<br>복구 작업이 정상적으로 종료되었습니다.<br>
			&nbsp;&nbsp;&nbsp;
			<form><input type="button" value='돌아가기' onClick='history.back()'></form>
			</body></html>
		};
	}
	
	return \$str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_lockfile_not_found
{
	my $str = "Content-type: text/html\n\n";
	$str .= qq{<HTML>
		<HEAD>
		<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
		<META NAME="author" CONTENTS="GIGAHO">
		<link rel="stylesheet" type="text/css" href="./inc_plant.css">
		<TITLE>신기한 식물 메이커(모드 오류)</TITLE>
		</HEAD>
		<BODY>
		<br><font color='red'>「$RDATA->{lock_dir}/lockfile」을 삭제하고
			점검 모드에해 주세요.</font><br>
		&nbsp;&nbsp;&nbsp;
		<form><input type="button" value='돌아가기' onClick='history.back()'></form>
		</body></html>
	};
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub print_check_each_dna
{
	my ($rokim) = @_;
	my $flag  = 1;
	my $imdir = $RDATA->{plant_img};
	my $rdnas = get_dna_data();

	foreach (@$rdnas) {
		my ($dna, $name) = @$_;
		my $rerr_data = get_check_dna($rokim, $dna);

		if($rerr_data->[0] == 6 || $rerr_data->[0] == -1 || !$rerr_data->[1]) {
			print("<font color='red'>유전자 데이터가 잘못되었습니다.");
			print("$RDATA->{sys_dir}/dna.cgi 의 ");
			print("$name의 데이터를삭제해 주세요.</font><br>\n");
		} elsif($rerr_data->[0] > 0) {
			print("<font color='red'>$imdir/ 의디렉터리에 ");
			print("o$rerr_data->[0]_$rerr_data->[2].gif 의이미지 파일이 존재하지 않습니다.");
			print("이미지 파일을 만들거나, $RDATA->{sys_dir}/dna.cgi 의 ");
			print("$name의 데이터를삭제해 주세요.</font><br>\n");
		}

		$flag = 0 if($rerr_data->[0] && $flag == 1);
	}
	
	return $flag;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub print_check_each_pure
{
	my $flag  = 1;
	my $imdir = $RDATA->{plant_img};
	my $rep_data = get_represent_data();

	for(my $rep_id = 0; $rep_id < @$rep_data; $rep_id++) {
		my $bg_path = "$imdir/obg/o${rep_id}.gif";
		if(!(-e $bg_path)) {
			$flag = 0;
			print("<font color='red'>배경 이미지 파일이 부족합니다.");
			print("$bg_path 를 준비해 주세요.</font><br>\n");
		}
	}
	
	return $flag;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub print_check_each_user
{
	my ($rokim, $uid, $type)  = @_;
	my $flag  = 1;
	my $imdir = $RDATA->{plant_img};
	my $ralbm = ($type eq "album")? get_album_data($uid):
		($type eq "plant")? get_plant_data($uid): get_seed_data($uid);

	foreach (reverse(@$ralbm)) {
		my $pid   = $_->[0];
		if($pid <= 0) {next;}
		my $pname = ($type eq "seed")? $_->[2]: $_->[1];
		my $dna1  = ($type eq "seed")? $_->[3]: $_->[16];
		my $dna2  = ($type eq "seed")? $_->[4]: $_->[17];
		foreach my $dna ($dna1, $dna2) {
			my $rerr_data = get_check_dna($rokim, $dna);

			if($rerr_data->[0] == -1 && $PARAM->{OPT} eq "w") {
				print("<font color='orange'>유전자 데이터가 오래된 형식입니다.");
				print("$RDATA->{data_dir}/u$uid/$type.cgi 의 ");
				print("PID=$pid($pname) 의 DNA 데이터가지정된 길이가 아니지만, ");
				print("동작에는 문제가 없습니다.</font><br>\n");
			} elsif($rerr_data->[0] == 6) {
				print("<font color='red'>유전자 데이터가 잘못되었습니다. ");
				print("$RDATA->{data_dir}/u$uid/$type.cgi ");
				print("의 PID=$pid($pname)의 데이터를삭제해 주세요.</font><br>\n");
			} elsif(0 < $rerr_data->[0] && $rerr_data->[0] <= 3) {
				print("<font color='red'>$imdir/ 의디렉터리에 ");
				print("o$rerr_data->[0]_$rerr_data->[2].gif 의이미지 파일이 존재하지 않습니다.");
				if($type eq "seed") {
					print("해당 이미지 파일을 만들어 주세요.</font><br>\n");
				} else {
					print("이미지 파일을 만들거나, $RDATA->{data_dir}/u$uid/$type.cgi ");
					print("의 PID=$pid($pname)의 데이터를삭제해 주세요.</font><br>\n");
				}
			} elsif($rerr_data->[0] == 5) {
				print("<font color='red'>유전자 데이터가 손실되어 있습니다.");
				print("$RDATA->{data_dir}/u$uid/$type.cgi 의 ");
				print("PID=$pid($pname) 의 DNA 데이터가손실하고 있는, ");
				print("의 데이터를수정해야 합니다.</font><br>\n");
			}

#			$flag = 0 if($rerr_data->[0] && $flag == 1);
			$flag = 0 if($rerr_data->[0] > 0 && $flag == 1);
		}
	}
	
	return $flag;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_check_dna
{
	my ($rokim, $dna) = @_;
	my @err_data;
	
	my $rcreature = get_expression_data($dna);
	$err_data[1]  = $rcreature->{"1"}->{power} * $rcreature->{"2"}->{power} *
		$rcreature->{"3"}->{power};
	
	foreach (values(%$rcreature)) {
		foreach (@{$_->{protein}}) {
			my $organ_id = $_->{"organ"};
			if($organ_id <= 0 || $organ_id >= 4) {$err_data[0] = 6; last;}
			my $img_id   = $_->{"domain"};
			if(!$rokim->[$organ_id]->{"$img_id"} && !$rokim->[$organ_id]->{"1"}) {
				$err_data[0] = $organ_id;
				$err_data[2] = $img_id;
			}
		}
	}

	if(!$err_data[0]) {
		if(length($dna) != 265) {
			if($rcreature->{"1"}->{power} + $rcreature->{"2"}->{power} +
				$rcreature->{"3"}->{power} == 0) {
		
				$err_data[0] = 5;
			} else {
				# 음수 값은 경고로 처리
				$err_data[0] = -1;
			}
		}
	}
	
	return \@err_data;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_file_user
{
	my $str;
	
	if(!$PARAM->{SUID}) {
		$str = get_file_all_user();
	} else {
		$str = get_file_each_user();
	}
	
	return \$str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_file_user_status
{
	my $uid  = $PARAM->{SUID};
	my $rstatus = get_status_data($uid);
	my $str .= "
		<h3>상태 파일($RDATA->{data_dir}/u$uid/status.cgi)</h3>
	";
	$str .= "<table border='1'>\n";
	$str .= "
		<tr><th>보유 금액</th><th>등록 시간</th><th>등록 시간</th>
			<th>레벨</th><th>마지막 Plant ID</th><th>보유 씨앗 수</th>
			<th>보유 가능 씨앗 수</th><th>---</th><th>보유 가능 화분 수</th>
			<th>음악을 들려준 시간</th><th>앨범 용량</th>
			<th>앨범 식물 수</th><th>앨범에 저장한 전체 식물 수</th>
		</tr>
	";
	$str .= "<tr>";
	for(my $cnt = 0; $cnt < @{$rstatus->[0]}; $cnt ++) {
		my $data = $rstatus->[0]->[$cnt];
		$str .= "<td><font size='-1'>$data</font></td>";
	}
	$str .= "</tr>\n";
	$str .= "</table><br><br>\n";
	$str .= "<table border='1'>\n";
	# 아래 항목은 추후 shop.cgi에서 가져오도록 변경 예정
	$str .= "
		<tr><th>---</th><th>비료</th><th>토양 시험지</th>
			<th>토양 분석 키트</th><th>화분(-1)</th><th>성장 촉진제</th>
			<th>영양/보수제 키트</th><th>플랜트 하우스</th><th>오디오 세트</th>
		</tr>
	";
	$str .= "<tr>";
	for(my $cnt = 0; $cnt < @{$rstatus->[1]}; $cnt ++) {
		my $data = $rstatus->[1]->[$cnt];
		$str .= "<td><font size='-1'>$data</font></td>";
	}
	$str .= "</tr>\n";
	$str .= "</table>\n";

	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_status_data
{
	my ($uid) = @_;
	my @status;
	
	if(-e "$RDATA->{data_dir}/u$uid/status.cgi") {
		open(IN, "$RDATA->{data_dir}/u$uid/status.cgi")
			|| error_end(__LINE__, "파일 오류", $!);
		chomp(my $line = <IN>);
		push(@status, [(split(/\t/, $line))]);
		chomp(my $line = <IN>);
		push(@status, [(split(/\t/, $line))]);
		close(IN) || error_end(__LINE__, "파일 오류", $!);
	}
	
	return \@status;
}

###################################################
#  input:()
# retrun:
#comment: status.cgi에서 데이터를 추출합니다.
###################################################
sub put_status_data
{
	my ($uid, $ruser) = @_;
	my ($line);
	
	open(UDT, ">$RDATA->{data_dir}/u$uid/status.cgi")
		|| error_end(__LINE__, "파일 오류", $!);
	$line = join("\t", @{$ruser->[0]});
	print UDT "$line\n";
	$line = join("\t", @{$ruser->[1]});
	print UDT "$line\n";
	close(UDT) || error_end(__LINE__, "파일 오류", $!);

	
	return 1;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub put_routine_time
{
	my $time = shift;
	
	open(TIMER, ">$RDATA->{data_dir}/timer.cgi")
		|| error_end(__LINE__, "파일 오류", $!);
	print TIMER "$time\n";
	close(TIMER) || error_end(__LINE__, "파일 오류", $!);
	
	return 1;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_file_user_seed
{
	my $uid  = $PARAM->{SUID};
	my $rerr = get_seed_data($uid);

	my $str .= "
		<h3>시드 파일($RDATA->{data_dir}/u$uid/seed.cgi)</h3>
		<font size='-1'>
		※ 전체 유전자를 선택 화면의 「염기서열에서 표현형으로 변환」을 실행하면 표현형을 확인할 수 있습니다
		</font>
	";
	$str .= "<table border='1'>\n";
	$str .= "
		<tr><th>Plant ID</th><th>이용 가능/불가</th><th>이름</th>
			<th>전체 유전자</th><th>유전자 1</th><th>유전자 2</th>
			<th>가격</th><th>부모 UserID 1</th><th>부모 UserID 2</th>
			<th>부모 PlantID 1</th><th>부모 PlantID 2</th>
		</tr>
	";
	foreach (reverse(@$rerr)) {
		$str .= "<tr>";
		for(my $cnt = 0; $cnt < @$_; $cnt ++) {
			
			if($cnt == 3) {
				$str .= "<td nowrap><font size='-1'>&gt;$_->[2]<br>\n"
					. get_return_str($_->[3], 30)
					. get_return_str($_->[4], 30) . "</font></td>";
			}
			my $data = ($cnt != 3 && $cnt != 4)? $_->[$cnt]:
				"&gt;$_->[2]_컬럼$cnt<br>\n" . get_return_str($_->[$cnt], 30);
			
			$str .= "<td nowrap><font size='-1'>$data</font></td>";
		}
		$str .= "</tr>\n";
	}
	$str .= "</table>\n";
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_file_user_plant
{
	my $rerr = get_plant_data($PARAM->{SUID});
	my $str  = get_file_user_detail($rerr, 1);
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_file_user_detail
{
	my ($rerr, $type) = @_;
	
	my $uid  = $PARAM->{SUID};
	my $file_sbj =
		($type == 1)? "플랜트 파일($RDATA->{data_dir}/u$uid/plant.cgi)":
		"앨범파일($RDATA->{data_dir}/u$uid/album.cgi)";
	
	my $str .= "
		<h3>$file_sbj</h3>
		<font size='-1'>
		※ 전체 유전자를 선택 화면의 「염기서열에서 표현형으로 변환」을 실행하면 표현형을 확인할 수 있습니다
		</font>
	";
	$str .= "<table border='1'>\n";
	$str .= "
		<tr><th>Plant ID</th><th>이름</th><th>심은 시간</th>
			<th>성장 레벨</th><th>성장 단계</th><th>햇빛 눈금</th>
			<th>수분 눈금</th><th>영양 눈금</th>
			<th>위치</th><th>전체 유전자</th><th>유전자 1</th><th>유전자 2</th>
			<th>평가액</th><th>부모 UserID 1</th><th>부모 UserID 2</th>
			<th>부모 PlantID 1</th><th>부모 PlantID 2</th><th>기본 교배료</th><th>설정교배료</th>
			<th>앨범저장시간</th><th>아이템이용상황</th>
		</tr>
	";
	foreach (reverse(@$rerr)) {
		$str .= "<tr>";
		for(my $cnt = 0; $cnt < @$_; $cnt ++) {
			if($cnt == 3 || $cnt == 7 || $cnt == 8 || $cnt == 10 || $cnt == 11
				|| $cnt == 13 || $cnt == 14){next;}
			
			if($cnt == 16) {
				$str .= "<td nowrap><font size='-1'>&gt;$_->[1]<br>\n"
					. get_return_str($_->[16], 30)
					. get_return_str($_->[17], 30) . "</font></td>";
			}
			my $data = ($cnt != 16 && $cnt != 17)? $_->[$cnt]:
				"&gt;$_->[1]_컬럼$cnt<br>\n" . get_return_str($_->[$cnt], 30);
			
			$str .= "<td nowrap><font size='-1'>$data</font></td>";
		}
		$str .= "</tr>\n";
	}
	$str .= "</table>\n";
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_seed_data
{
	my ($uid) = @_;
	my @seed;
	
	if(-e "$RDATA->{data_dir}/u$uid/seed.cgi") {
		open(IN, "$RDATA->{data_dir}/u$uid/seed.cgi")
			|| error_end(__LINE__, "파일 오류", $!);
		while(chomp(my $line = <IN>)) {
			push(@seed, [(split(/\t/, $line))]);
		}
		close(IN) || error_end(__LINE__, "파일 오류", $!);
	}
	
	return \@seed;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub put_seed_data
{
	my ($uid, $rseed) = @_;
	
	open(OUT, "+<$RDATA->{data_dir}/u$uid/seed.cgi")
		|| error_end(__LINE__, "파일 오류", "$!($uid)");
	flock(OUT, 2);
	seek(OUT, 0, 0);
	foreach (@$rseed) {
		my $each_line = join("\t", @$_);
		print OUT "$each_line\n";
	}
	truncate(OUT, tell(OUT));
	close(OUT) || error_end(__LINE__, "파일 오류", $!);
	
	return 1;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_plant_data
{
	my ($uid) = @_;
	my @plant;
	
	if(-e "$RDATA->{data_dir}/u$uid/plant.cgi") {
		open(IN, "$RDATA->{data_dir}/u$uid/plant.cgi")
			|| error_end(__LINE__, "파일 오류", $!);
		while(chomp(my $line = <IN>)) {
			push(@plant, [(split(/\t/, $line))]);
		}
		close(IN) || error_end(__LINE__, "파일 오류", $!);
	}
	
	return \@plant;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub put_plant_data
{
	my ($uid, $rplant) = @_;
	
	open(PLANT, "+<$RDATA->{data_dir}/u$uid/plant.cgi")
		|| error_end(__LINE__, "파일 오류", "$!($uid)");
	flock(PLANT, 2);
	seek(PLANT, 0, 0);
	foreach (@$rplant) {
		my $each_line = join("\t", @$_);
		print PLANT "$each_line\n";
	}
	truncate(PLANT, tell(PLANT));
	close(PLANT) || error_end(__LINE__, "파일 오류", $!);
	
	return 1;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_file_each_user
{
	my $str = "Content-type: text/html\n\n";
	$str .= qq{<HTML>
		<HEAD>
		<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
		<META NAME="author" CONTENTS="GIGAHO">
		<link rel="stylesheet" type="text/css" href="./inc_plant.css">

		<TITLE>신기한 식물 메이커</TITLE>
		</HEAD>
		<BODY BGCOLOR='#d1f8d8' background='' onLoad=''>
			<a href='$PNAME'>관리자첫 화면</a> / <a href='$PNAME?MODE=main'>선택 화면</a><hr>
	};
	$str .= get_datafile_link_htm();
	if($PARAM->{FILE} eq "album") {
		$str .= get_file_user_album();
	} elsif($PARAM->{FILE} eq "user") {
		$str .= get_file_user_plant();
	} elsif($PARAM->{FILE} eq "status") {
		$str .= get_file_user_status();
	} else {
		$str .= get_file_user_status() . "<hr>\n";
		$str .= get_file_user_plant()  . "<hr>\n";
		$str .= get_file_user_seed()  . "<hr>\n";
		$str .= get_file_user_album();
	}
	$str .= get_copyright();
	$str .= "</BODY></HTML>";
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_file_user_album
{
	my $rerr = get_album_data($PARAM->{SUID});
	my $str = get_file_user_detail($rerr, 2);
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_album_data
{
	my ($uid) = @_;
	my @album;
	
	if(-e "$RDATA->{data_dir}/u$uid/album.cgi") {
		open(IN, "$RDATA->{data_dir}/u$uid/album.cgi")
			|| error_end(__LINE__, "파일 오류", $!);
		while(chomp(my $line = <IN>)) {
			push(@album, [(split(/\t/, $line))]);
		}
		close(IN) || error_end(__LINE__, "파일 오류", $!);
	}
	
	return \@album;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_file_all_user
{
	my $rerr = get_user_data();
	my $str = "Content-type: text/html\n\n";
	$str .= qq{<HTML>
		<HEAD>
		<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
		<META NAME="author" CONTENTS="GIGAHO">
		<link rel="stylesheet" type="text/css" href="./inc_plant.css">

		<TITLE>신기한 식물 메이커</TITLE>
		</HEAD>
		<BODY BGCOLOR='#d1f8d8' background='' onLoad=''>
			<a href='$PNAME'>관리자첫 화면</a> / <a href='$PNAME?MODE=main'>선택 화면</a><hr>
	};
	$str .= get_datafile_link_htm();
	$str .= "
		<h3>사용자파일($RDATA->{data_dir}/user.cgi)</h3>
		<font size='-1' color='red'>※취급 주의</font><br>
		<font size='-1'>※ ID를 클릭하면 사용자의 상세 파일 데이터를 볼 수 있습니다</font>
	";
	$str .= "<table border='1'>\n";
	$str .= "
		<tr><th>ID</th><th>이름</th><th>비밀번호(암호화되지 않았습니다. 취급 주의)</th>
			<th>HP</th><th>메일</th><th>성별</th><th>출신지</th><th>IP</th>
			<th>접속시간</th><th>공개/비공개</th><th>표시ID</th><th>제목 댓글</th>
			<th>상세댓글</th><th>앨범갱신시간</th><th>BBS쓰기시간</th>
		</tr>
	";
	foreach (reverse(@$rerr)) {
		$str .= "<tr>";
		for(my $cnt = 0; $cnt < @$_; $cnt ++) {
			my $data = ($cnt == 0)?
				qq{<a href='$PNAME?MODE=file_user&SUID=$_->[0]'>$_->[0]</a>}: 
				$_->[$cnt];
			$str .= "<td nowrap><font size='-1'>$data</font></td>";
		}
		$str .= "</tr>\n";
	}
	$str .= "</table>\n";
	$str .= get_copyright();
	$str .= "</BODY></HTML>";
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_renew_plant_data
{
	my $err_str = "";
	my $rusr = get_user_data();
	foreach (reverse(@$rusr)) {
		my %exist_plant;
		my ($uid, $name) = (@$_)[0, 1];
		my $rstatus = get_status_data($uid);
		my $plant_space = $rstatus->[1]->[4] + 1;
		my $rplant = get_plant_data($uid);
		my $plant_cnt = 0;
		foreach(@$rplant) {
			$exist_plant{"$_->[0]"} = 1;
			$plant_cnt++;
		}
		if($plant_space < $plant_cnt) {
			$err_str .= "UID=$uid($name)의화분가($plant_space < $plant_cnt)<br>\n";
		} elsif($plant_space > $plant_cnt) {
			$err_str .= "UID=$uid($name)의화분 수를 확인해야 합니다($plant_space > $plant_cnt)<br>\n";
			while($plant_space > $plant_cnt) {
				$plant_cnt ++;
				push(@$rplant, [-$plant_cnt, "새화분", "null", "null", 0, 6, 9,
					"null", "null", 9, "null", "null", 9, "null", "null", 0, "null", "null", 0]);
			}
			put_plant_data($uid, $rplant);
			my $rseed = get_seed_data($uid);
			foreach(@$rseed) {
				if(!$exist_plant{"$_->[8]"}) {
					$err_str .= " PID=$_->[0]($_->[2])의 씨앗을 이용 가능으로 변경합니다<br>\n";
					$_->[1] = 1;
				}
			}
			put_seed_data($uid, $rseed);
		}
	}
	$err_str = "<font color='blue'>모두 정상입니다</font>" if(!$err_str);
	
	return $err_str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_user_data
{
	my @usr;
	
	if(-e "$RDATA->{data_dir}/user.cgi") {
		open(IN, "$RDATA->{data_dir}/user.cgi")
			|| error_end(__LINE__, "파일 오류", $!);
		while(chomp(my $line = <IN>)) {
			push(@usr, [(split(/\t/, $line))]);
		}
		close(IN) || error_end(__LINE__, "파일 오류", $!);
	}
	
	return \@usr;
}

###################################################
#  input:()
# retrun:
#comment: 데이터를 추출합니다. 호출 함수 쪽에서 잠금 처리 필요
###################################################
sub put_user_data
{
	my ($rusr) = @_;
	
	open(USER, ">$RDATA->{data_dir}/user.cgi")
		|| error_end(__LINE__, "파일 오류", $!);
	foreach (@$rusr) {
		my $each_line = join("\t", @$_);
		print USER "$each_line\n";
	}
	close(USER) || error_end(__LINE__, "파일 오류", $!);
	
	return 1;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_file_error_log
{

	my $rerr = get_error_data();
	my $str = "Content-type: text/html\n\n";
	$str .= qq{<HTML>
		<HEAD>
		<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
		<META NAME="author" CONTENTS="GIGAHO">
		<link rel="stylesheet" type="text/css" href="./inc_plant.css">

		<TITLE>신기한 식물 메이커</TITLE>
		</HEAD>
		<BODY BGCOLOR='#d1f8d8' background='' onLoad=''>
			<a href='$PNAME'>관리자첫 화면</a> / <a href='$PNAME?MODE=main'>선택 화면</a><hr>
	};
	$str .= get_datafile_link_htm();
	$str .= "
		<h3>오류로그($RDATA->{'data_dir'}/cgi.err)</h3>
		<font size='-1'>※ 이 파일은 수동으로 삭제해도 문제 없습니다</font>
	";
	$str .= "<table border='1'>\n";
	$str .= "
		<tr><th>시간</th><th>접속IP</th><th>접속 원본 플랫폼</th>
			<th>위치</th><th>내용</th><th>상세</th></tr>
	";
	foreach (reverse(@$rerr)) {
		$str .= "<tr><td>" . join("</td><td>", @$_) . "</td></tr>\n";
	}
	$str .= "</table>\n";
	$str .= get_copyright();
	$str .= "</BODY></HTML>";
	
	return \$str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_error_data
{
	my @err;
	
	if(-e "$RDATA->{'data_dir'}/cgi.err") {
		open(IN, "$RDATA->{'data_dir'}/cgi.err")
			|| error_end(__LINE__, "파일 오류", $!);
		while(chomp(my $line = <IN>)) {
			push(@err, [(split(/\|/, $line))]);
		}
		close(IN) || error_end(__LINE__, "파일 오류", $!);
	}
	
	return \@err;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_secret_view_htm
{
	my $str = "Content-type: text/html\n\n";
	$str .= qq{<HTML>
		<HEAD>
		<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
		<META NAME="author" CONTENTS="GIGAHO">
		<link rel="stylesheet" type="text/css" href="./inc_plant.css">

		<TITLE>신기한 식물 메이커</TITLE>
		</HEAD>
		<BODY BGCOLOR='#d1f8d8' background='' onLoad=''>
			<a href='$PNAME'>관리자첫 화면</a> / <a href='$PNAME?MODE=main'>선택 화면</a><hr>
	};
	$str .= get_optional_link_htm();
	$str .= qq{
			<hr><form action="$PNAME" method="$RDATA->{method}" name="reg">
	};
	$str .= get_secret_image_files_htm();
	$str .= qq{
			</form><br>
	};
	$str .= get_copyright();
	$str .= "</BODY></HTML>";
	
	return \$str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_image_all_htm
{
	my $sla;
	my $str = "Content-type: text/html\n\n";
	$str .= qq{<HTML>
		<HEAD>
		<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
		<META NAME="author" CONTENTS="GIGAHO">
		<link rel="stylesheet" type="text/css" href="./inc_plant.css">

		<TITLE>신기한 식물 메이커</TITLE>
		</HEAD>
		<BODY BGCOLOR='#d1f8d8' background='' onLoad=''>
			<a href='$PNAME'>관리자첫 화면</a> / <a href='$PNAME?MODE=main'>선택 화면</a><hr>
	};
	$str .= get_optional_link_htm();
	$str .= qq{
			<hr><form action="$PNAME" method="$RDATA->{method}" name="reg">
	};
	$str .= get_image_files_htm();
	$str .= qq{
			</form><br>
	};
	$str .= get_copyright();
	$str .= "</BODY></HTML>";
	
	return \$str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_optional_link_htm
{
	
	my $pure_str = ($PARAM->{MODE} eq "pure_view")? "순계 식물 목록":
		qq{<a href='$PNAME?MODE=pure_view&PGF=5&PAG=1'>순계 식물 목록</a>};
		
	my $secret_str = ($PARAM->{MODE} eq "secret_view")? "시크릿 식물목록":
		qq{<a href='$PNAME?MODE=secret_view&PGF=5&PAG=1'>시크릿 식물목록</a>};
		
	my $str .= qq{
			<b>목록 보기：
			[$pure_str] 
			[$secret_str] 
			[
	};
	my $sla = "";
	foreach (my $parts = 1; $parts <= 3; $parts ++) {
		my ($a_s, $a_e) = ("<a href='$PNAME?MODE=image_all&ORGAN=$parts&PGF=5&PAG=1'>", "</a>")
			if($parts != $PARAM->{ORGAN});
			
		$str .= qq{$sla$a_s$BODY_PARTS[$parts]$a_e\n};
		$sla = " / ";
	}
	$str .= "]</b>";
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_image_files_htm
{
	my ($str, %center);
	my $pg_s = abs(($PARAM->{PAG} - 1)) * $PARAM->{PGF};
	my $pg_e = $pg_s + $PARAM->{PGF};

	my $organ_id = $PARAM->{ORGAN};
	my $rnames   = get_image_files_name();
	my $rcenter  = get_all_init_creater();
	
	my @sorted_dt = sort {$a <=> $b} keys(%{$rnames->{imid}->[$organ_id]});
	my $max_cnt   = @sorted_dt;
	my $org_imdir = $RDATA->{plant_img};
	$str .= get_page_link_htm($max_cnt, "MODE=image_all&ORGAN=$organ_id");
	$str .= qq{<table cellspacing="0" cellpadding="0" border='2'><tr><td>};
	
	for(my $count = $pg_s; $count < $pg_e; $count ++) {
		if($count >= $max_cnt) {last;}
		my $pimg_id = $sorted_dt[$count];
		$str .= qq{<tr>};
		$str .= get_dna_use_table_htm($rcenter, $organ_id, $pimg_id);
		for(my $grow_step = 1; $grow_step <= 5; $grow_step++) {
			my $rim = $rnames->{main}->[$grow_step]->[$organ_id];
			my $img_id = ($rim->{"$pimg_id"})? $pimg_id: ($rim->{"1"})? 1: 0;
			if($img_id) {
				$str .= qq{
					<td>
					<img src='$org_imdir/o$grow_step/o${organ_id}_${img_id}.gif' border='1'><br>
					<center><font size='-1'>o$grow_step/o${organ_id}_${img_id}.gif</font></center>
					</td>
				};
			} else {
				$str .= "<td align='center'>
					<font color='red' size='-1'>DNA를 정상적으로<br>등록하려면<br>
					여기에 이미지를<br>준비해야<br>합니다.</font></td>";
			}
		}
		$str .= qq{</tr>};
	}
	$str .= qq{</table>};
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_dna_use_table_htm
{
	my ($rcenter, $organ_id, $img_id) = @_;
	
	my $str .= qq{
		<td valign='top'>
			<b>기관： $BODY_PARTS[$organ_id]</b><br>
			<b>이미지 번호： $img_id</b><br>
		<table cellspacing="0" cellpadding="0" border='1'>
			<tr><th>DNA_ID</th><th>식물 이름</th><th>발현 타입</th>
				<th>평가</th></tr>
	};
	foreach my $rc (@{$rcenter->{"$organ_id"}->{"$img_id"}}) {
		my ($dna_id, $name, $reaction_num, $strength) = @$rc;
		my $dna_id_ = $dna_id + 1;
		my $reaction = ($reaction_num == 1)? "추가형": "우열형";
		$str .= qq{
			<tr><td align='right'>$dna_id_</td>
				<td><a href='$PNAME?MODE=main&DNA_ID=$dna_id'><b>$name</b></a></td>
				<td>$reaction</td>
				<td align='right'>$strength</td></tr>
		};
	}
	$str .= qq{</table></td>\n};
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_all_init_creater
{
	my %center;
	
	my $rdnas = get_dna_data();
	for(my $dna_id = 0; $dna_id < @$rdnas; $dna_id ++) {
		my ($dna, $name) = @{$rdnas->[$dna_id]};
		my $rcreature = get_expression_data($dna);
		while(my ($organ_id, $rcre) = each(%$rcreature)) {
			foreach(@{$rcre->{protein}}) {
				push(@{$center{"$organ_id"}->{"$_->{domain}"}},
					[$dna_id, $name, $_->{"reaction"}, $_->{"strength"}]);
			}
		}
	}
	
	return \%center;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_secret_image_files_htm
{
	my ($str, %center);
	my $pg_s = abs(($PARAM->{PAG} - 1)) * $PARAM->{PGF};
	my $pg_e = $pg_s + $PARAM->{PGF};
	
	my $rnames  = get_image_files_name();
	my $rsecs   = get_secret_data();
	my $rcenter = get_all_init_creater();
	my $seq_cnt = @$rsecs;
	
	my $org_imdir = $RDATA->{plant_img};
	$str .= get_page_link_htm($seq_cnt, "MODE=secret_view");
	$str .= qq{<table cellspacing="0" cellpadding="0" border='2'><tr><td>};

	for(my $count = $pg_s; $count < $pg_e; $count ++) {
		if($count >= $seq_cnt) {last;}
		my ($organ_id, $img_id) = @{$rsecs->[$count]};
		$str .= qq{<tr>};
		$str .= get_dna_use_table_htm($rcenter, $organ_id, $img_id);
		for(my $grow_step = 1; $grow_step <= 5; $grow_step++) {
			my $rim = $rnames->{main}->[$grow_step]->[$organ_id];
			my $img_id = ($rim->{"$img_id"})? $img_id: ($rim->{"1"})? 1: 0;
			if($img_id) {
				$str .= qq{
					<td>
					<img src='$org_imdir/o$grow_step/o${organ_id}_${img_id}.gif' border='1'><br>
					<center><font size='-1'>o$grow_step/o${organ_id}_${img_id}.gif</font></center>
					</td>
				};
			} else {
				$str .= "<td align='center'>
					<font color='red' size='-1'>DNA를 정상적으로<br>등록하려면<br>
					여기에 이미지를<br>준비해야<br>합니다.</font></td>";
			}
		}
		$str .= qq{</tr>};
	}
	$str .= qq{</table>};
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_secret_data
{
	my @secs;
	
	open(IN, "$RDATA->{sys_dir}/secret_plant.cgi")
		|| error_end(__LINE__, "파일 오류", $!);
	while(chomp(my $line = <IN>)) {
		push(@secs, [(split(/\t/, $line))]);
	}
	close(IN) || error_end(__LINE__, "파일 오류", $!);
	
	return \@secs;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_image_files_name
{
	my %data;
	
	my $org_imdir = $RDATA->{plant_img};
	for(my $grow_step = 1; $grow_step <= 5; $grow_step++) {
		opendir(DIR, "$org_imdir/o$grow_step")
			|| error_end(__LINE__, "열기오류", $!);
		while (my $file = readdir(DIR)) {
			my ($organ_id, $img_id) = $file =~ /^o(\d+)_(\d+)/;
			if($img_id) {
				$data{main}->[$grow_step]->[$organ_id]->{"$img_id"} = 1;
				$data{imid}->[$organ_id]->{"$img_id"} = 1;
			}
		}
		closedir(DIR) || error_end(__LINE__, "디렉터리 종료 오류", $!);
	}
	
	for(my $organ_id = 1; $organ_id <= 3; $organ_id++) {
		foreach my $img_id (keys(%{$data{imid}->[$organ_id]})) {
			my $ok_flg = 1;
			for(my $grow_step = 1; $grow_step <= 5; $grow_step ++) {
				if(!$data{main}->[$grow_step]->[$organ_id]->{"$img_id"}) {
					$ok_flg = 0; last;
				}
			}
			$data{okim}->[$organ_id]->{"$img_id"} = 1 if($ok_flg);
		}
	}
	
	return \%data;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_no_manager_htm
{
	
	my $str = "Content-type: text/html\n\n";
	$str .= qq{<HTML>
		<HEAD>
		<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
		<META NAME="author" CONTENTS="GIGAHO">
		<link rel="stylesheet" type="text/css" href="./inc_plant.css">

		<TITLE>신기한 식물 메이커</TITLE>
		</HEAD>
		<BODY BGCOLOR='#d1f8d8' background='' onLoad=''>
			<form action="$PNAME" method="$RDATA->{method}" name="reg"><center>
			<img src='$RDATA->{img_dir}/inc_plant.gif' border='0'>
			<table width="450" border="0" cellspacing="0" cellpadding="0"><tr><td bgcolor="#aa8800"> 
			<table border="0" cellspacing="1" cellpadding="2" height="100%" width="100%">
			<tr><td bgcolor="#ffddcc" align="center" class='table_top start_top'>
				<b><font color="#664400" face="Arial, Helvetica, sans-serif">
				「신기한 식물 메이커」에 오신 것을 환영합니다</font></b></td>
			</tr>
			<tr><td bgcolor="#FFFFFF" class='table_bottom'><center><br>
					<font color='red'>관리자 사용자 비밀번호가 설정되어 있지 않습니다.</font>
					<table border="0" cellspacing="3" cellpadding="2" width='100%'>
						<tr><td align='right' colspan='2'>
							<a href='inc_plant.cgi'><font size='-1'>게임첫 화면으로</font></a>
						</td></tr>
					</table>
				</center></td>
			</tr></table></td></tr></table>
			</center></form><br>
	};
	$str .= get_copyright();
	$str .= "</BODY></HTML>";
	
	return \$str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_start_htm
{
	my $err_str  = shift;
	
	my $str = "Content-type: text/html\n\n";
	$str .= qq{<HTML>
		<HEAD>
		<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
		<META NAME="author" CONTENTS="GIGAHO">
		<link rel="stylesheet" type="text/css" href="./inc_plant.css">
	};
	$str .= qq{
		<TITLE>신기한 식물 메이커</TITLE>
		</HEAD>
		<BODY BGCOLOR='#d1f8d8' background='' onLoad=''>
			<form action="$PNAME" method="$RDATA->{method}" name="reg"><center>
			<img src='$RDATA->{img_dir}/inc_plant.gif' border='0'>
			<table width="450" border="0" cellspacing="0" cellpadding="0"><tr><td bgcolor="#aa8800"> 
			<table border="0" cellspacing="1" cellpadding="2" height="100%" width="100%">
			<tr><td bgcolor="#ffddcc" align="center" class='table_top start_top'>
				<b><font color="#664400" face="Arial, Helvetica, sans-serif">
				「신기한 식물 메이커」에 오신 것을 환영합니다<br>
				관리자비밀번호을 입력해해 주세요</font></b></td>
			</tr>
			<tr><td bgcolor="#FFFFFF" class='table_bottom'> 
				<center><font color='red'>$err_str</font>
				<table border="0" cellspacing="3" cellpadding="2" width='100%'>
					<tr><td ALIGN="right">
							<b><font size="2" face="Times New Roman, Times, serif">관리자비밀번호</font></b>
						</td><td align="left"> 
							<INPUT TYPE="password" NAME="PWD" SIZE="8" MAXLENGTH="8" value=''></td>
					</tr><tr> 
						<td colspan='2' ALIGN="center" valign="middle"> 
							<input type="submit" value='로그인'>
						</td>
					</tr>
					<tr><td align='right' colspan='2'>
						<a href='inc_plant.cgi'><font size='-1'>게임첫 화면으로</font></a>
					</td></tr>
				</table></center></td>
			</tr></table></td></tr></table>
			<INPUT TYPE="hidden" NAME="MODE" value='login'>
			</center></form>
			<br>
	};
	$str .= get_copyright();
	$str .= "</BODY></HTML>";
	
	return \$str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_server_login_htm
{
	my ($res_str);
	my $err_type   = -1;
	my $field_name = $RDATA->{field_name};

	if($PARAM->{PWD} ne $RDATA->{manager_pass}) {
		$err_type = 1;
		$res_str = "비밀번호가 다릅니다";
	} elsif(!$field_name) {
		$err_type = 2;
		$res_str = qq{"~/lib/inc_plant_conf.cgi"의field_name에 사이트를 등록해 주세요.};
	} else {
		$res_str = $field_name;
		my $url = $PARAM->{URL}; $url =~ s/\s//g;
		my $rserver = get_server_data();
		$rserver->{"$url"} = [$url, $PARAM->{KEY}, $PARAM->{SNAM}];
		put_server_data($rserver);
	}
	
	my $str = "Content-type: text/plain\n\n";
	$str .= "$err_type\n$res_str";
	
	return \$str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_main_htm
{
	my ($alert_str) = @_;

	my $str = "Content-type: text/html\n\n";
	$str .= qq{<HTML>
		<HEAD>
		<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
		<META NAME="author" CONTENTS="GIGAHO">
		<link rel="stylesheet" type="text/css" href="./inc_plant.css">
	};
	$str .= qq{
		<TITLE>신기한 식물 메이커</TITLE>
		</HEAD>
		<BODY BGCOLOR='#d1f8d8' background='' onLoad=''>
			<!-- <center><img src='$RDATA->{img_dir}/inc_plant.gif' border='0'></center> -->
	};
	if(defined($PARAM->{DNA_ID})) {
		my $dna_id = $PARAM->{DNA_ID} * 1;
		my $rdnas = get_dna_data();
		my ($dna, $name) = @{$rdnas->[$dna_id]};
		$str .= get_data_htm($dna, $name);
	} elsif(defined($PARAM->{NAME})) {
		my $dna = get_dna_seq();
		$str .= get_data_htm($dna, $PARAM->{NAME});
	} elsif(defined($PARAM->{SEQ})) {
		my ($dna, $name) = get_dna_seq_from_seq();
		$str .= get_data_htm($dna, $name);
	} else {
		$str .= get_select_dna_htm();
	}
	$str .= get_copyright();
	$str .= "</BODY></HTML>";
	
	return \$str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_dna_seq_from_seq
{
	my ($dna, $name);
	
	foreach (split(/\n/, $PARAM->{SEQ})) {
		if(substr($_, 0, 1) eq ">") {
			$name .= substr($_, 1);
			next;
		} elsif(substr($_, 0, 4) eq "&gt;") {
			$name .= substr($_, 4);
			next;
		}
		s/\s//g; $dna .= $_;
	}
	
	return ($dna, $name);
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_select_dna_htm
{
	my ($str);
	my $rdnas = get_dna_data();
	
	$str .= qq{
		<a href='$PNAME'>관리자첫 화면</a> / <hr>
		<b>힌트：</b><br><font size='-1'>
		-의메이커 프로그램는설정 정보를 열람하고, 새 식물을 작성하는 프로그램입니다.
		메이커 프로그램을조작하고도게임의 데이터가와는없습니다의에서, 하고이용해 주세요.
		설정 변경/추가는 관리자가 파일을 직접 편집해서 처리합니다.<br>
		-순계 식물 도감은「$RDATA->{album_img}/u0」안의 이미지와 u0 디렉터리 자체를 삭제해 주세요.<br>
		-꽃 농장은「$RDATA->{album_img}/u1」안의 이미지와 u1 디렉터리 자체를 삭제해 주세요.<br>
		</font><hr>
	};
	$str .= get_optional_link_htm();
	$str .= "<hr>";
	$str .= get_datafile_link_htm();
	$str .= get_datacheck_link_htm();
	$str .= get_input_htm();
	$str .= get_textarea_htm();
	$str .= qq{
		<h3>-등록되어기본식물</h3>
		<font size='-1'>※ 배경의 용도는, 활성화된 식물에서</font>
		<table cellspacing="0" cellpadding="0" border='1'>
			<tr><th>DNA_ID</th><th>식물 이름</th></tr>
	};
	for(my $dna_id = 0; $dna_id < @$rdnas; $dna_id++) {
		my ($dna, $name) = @{$rdnas->[$dna_id]};
		my $dna_id_ = $dna_id + 1;
		my $bgcol   = qq{bgcolor='#cccccc'}
			if (defined($RDATA->{init_dna_cnt}) && $RDATA->{init_dna_cnt} < $dna_id_);
		
		$str .= qq{
			<tr><td align='right' $bgcol><b>$dna_id_</b></td>
				<th $bgcol><a href='$PNAME?MODE=main&DNA_ID=$dna_id'>$name</a></th></tr>
		};
	}
	$str .= "</table>\n";
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_datafile_link_htm
{
	my $str = qq{
		<b>데이터 파일 보기：
		[<a href='$PNAME?MODE=file_error_log'>오류로그파일</a>] 
		[<a href='$PNAME?MODE=file_user'>사용자파일</a>]
		</b>
		<hr>
	};
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_datacheck_link_htm
{
	my $str = qq{
		<b>
		데이터 정합성 검사와 복구：
		[<a href='$PNAME?MODE=check_data'>유전자 데이터 오류 검사</a>]
		[<a href='$PNAME?MODE=remake_pspace'>plant.cgi 복구</a>]
		<hr><form>
		장시간 정지 후 복귀：
		<input type='button' value='타이머 초기화' onClick='if(confirm("게임 시간이 어긋나 식물이 시들거나 사용자가 삭제되는 것을 피하기 위해 내부 시간을 초기화합니다. 진행하시겠습니까?")) location.href="$PNAME?MODE=reset"' /></form>
		</b>
		<font size='-2'>서버가 장시간 정지했거나 접속이 없던 상태에서 
		복구 시에는 <font color='red'>”inc_plant.cgi에접속하기 전에”</font>[타이머 초기화]를 실행해 주세요.
		사용자 삭제까지의 시간이최대가 되고, 식물도 서버가 정지했던 동안의 상태로 처리될 수 있습니다.<br>
		정지시도식물의성장은 진행됩니다.복귀시의inc_plant.cgi에접속하기와의식물가시듦가능성이 있습니다의에서주의해 주세요.</font>
		<hr>
	};
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_data_htm
{
	my ($dna, $name) = @_;
	my ($str);
	
	$str .= "<a href='$PNAME'>관리자첫 화면</a> / <a href='$PNAME?MODE=main'>선택 화면</a><hr>\n";
	$str .= get_input_htm($dna, $name);
#	$str .= get_textarea_htm();
	my $rcreature = get_expression_data($dna);
	if($rcreature->{"1"}->{power} * $rcreature->{"2"}->{power} *
		$rcreature->{"3"}->{power} && $name) {
		
#		$str .= ($PARAM->{MODE} eq "dna_regist")?
#			get_register_dna($dna, $name):
#			get_hidden_htm($dna, $name);

		$str .= get_plants_htm($dna, $name);
	} else {
		$str .= qq{
			<font color='red'>유전자 데이터가 잘못되었습니다.</font><br>
			<form><input type='button' value='돌아가기' onClick='history.back()'></form>
		};
	}
	
	return $str;
}


###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_pure_view_htm
{
	my ($str);
	
	my $str = "Content-type: text/html\n\n";
	$str .= qq{<HTML>
		<HEAD>
		<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
		<META NAME="author" CONTENTS="GIGAHO">
		<link rel="stylesheet" type="text/css" href="./inc_plant.css">

		<TITLE>신기한 식물 메이커</TITLE>
		</HEAD>
		<BODY BGCOLOR='#d1f8d8' background='' onLoad=''>
		<a href='$PNAME'>관리자첫 화면</a> / <a href='$PNAME?MODE=main'>선택 화면</a><hr>
	};
	$str .= get_optional_link_htm();
	$str .= "<hr>\n";
	$str .= get_pure_plants_htm();
	$str .= get_copyright();
	$str .= "</BODY></HTML>";
	
	return \$str;
}


###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_register_dna
{
	my ($dna, $name) = @_;
	put_dna_data($dna, $name);
	
	my $str .= qq{
			<font color='red'>「$name」의 유전자 데이터를 등록했습니다.</font><br>
			<form><input type='button' value='돌아가기' onClick='history.back()'></form><hr>
	};
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_plants_htm
{
	my ($dna, $name) = @_;
	
	my $str .= "
		<h3>-표현형 상세</h3>
		<table border='0'>
	";
#	for(my $dna_id = 0; $dna_id < @$rdnas; $dna_id++) {
		my $rcreature = get_expression_data($dna);
		my $score = int(($rcreature->{"1"}->{power} + $rcreature->{"2"}->{power}
			+ $rcreature->{"3"}->{power} * 2) / 4);
		
		my $dna_str = "&gt;$name<br>\n";
		$dna_str   .= get_return_str($dna, 30);
		$str .= qq{
			<tr bgcolor='black' height='2'><th colspan='7'></th></tr>
			<tr><th colspan='7' bgcolor='#77cc66'>$name (종합평가: $score)</th></tr>
			<tr bgcolor='black' height='2'><th colspan='7'></th></tr>
			<tr><td colspan='2' valign='top'><font size='-1'>$dna_str</font></td>
		};
		$str .= get_flower_img_htm($rcreature);
		$str .= qq{</tr><tr bgcolor='black' height='2'><th colspan='7'></th></tr>};

		for(my $key = 1; $key <= 3; $key++) {
			my $val = $rcreature->{"$key"};
			my $parts_name = $BODY_PARTS[$key];
			my $img_id = $val->{protein}->[$val->{view}->[0]]->{domain};
			$str .= qq{
				<tr><td colspan='2' bgcolor='#aa8866'>$parts_name</td>
					<td colspan='5' bgcolor='#aa8866'>이미지: $img_id, 평가: $val->{power}</td>
				</tr>
			};
			my $num = 0;
			foreach (@{$val->{protein}}) {
				my $organ_id = $_->{"organ"};
				my $domain   = $_->{"domain"};
				my $reaction = ($_->{"reaction"} == 1)? "추가형": "우열형";
				my $strength = $_->{"strength"};

				$str .= qq{<tr><td>타입</td><td>$reaction</td>};
				$str .= get_each_flower_img_htm($domain, $organ_id, ($domain == $img_id)? 2: 1);
				$str .= qq{
					</tr>
					<tr><td>평가</td><td>$strength</td></tr>
					<tr><td>이미지</td><td>$domain</td></tr>
				};
				$num++;
			}
			$str .= qq{
					<tr bgcolor='black' height='1'><th colspan='7'></th></tr>
			};
		}
#	}
	$str .= "</table>\n";
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_pure_plants_htm
{
	my $rpure = get_represent_data();
	my $pure_cnt = @$rpure;
	my $pg_s  = abs(($PARAM->{PAG} - 1)) * $PARAM->{PGF};
	my $pg_e  = $pg_s + $PARAM->{PGF} || @$rpure;
	
	my $str .= "<h3>-순계 식물 목록</h3>";
	$str .= get_page_link_htm($pure_cnt, "MODE=pure_view");
	$str .= "<table border='0'>";
	for(my $ob_id = $pg_s; $ob_id < $pg_e; $ob_id ++) {
		if($ob_id >= $pure_cnt) {last;}
		my ($im1, $im2, $im3, $name) = @{$rpure->[$ob_id]};
		$str .= qq{
			<tr bgcolor='black' height='2'><th colspan='5'></th></tr>
			<tr><th colspan='5' bgcolor='#77cc66'>순계ID: $ob_id 「$name」
				(줄기: $im1, 잎: $im2, 꽃: $im3)</th></tr>
			<tr bgcolor='black' height='2'><th colspan='5'></th></tr>
			<tr>
		};
		$str .= get_pure_flower_img_htm([$im1, $im2, $im3], $ob_id);
		$str .= qq{</tr><tr bgcolor='black' height='2'><th colspan='5'></th></tr>};
	}
	$str .= "</table>\n";
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_input_htm
{
	my ($dna, $name) = @_;
	my $str .= qq{
		<h3>-전체 유전자 데이터 설정</h3>
		<form action="$PNAME" method="$RDATA->{method}">
		식물 이름: <input type='text' name='NAME' size="30" maxlength="30" value='$name'><br>
	};
	my $rrexp = get_expression_type($dna);
	for(my $cnt = 1; $cnt <= 5; $cnt++) {
		my $rexp = $rrexp->[$cnt];
		my $domain   = $rexp->{domain};
		my $strength = $rexp->{strength};
		my $organ    = $rexp->{organ};
		my $reaction = $rexp->{reaction};
		my (@sel_o, @sel_r);
		$sel_o[$organ]    = "selected";
		$sel_r[$reaction] = "selected";
		$str .= qq{
			기관: 
			<select name='ORGAN$cnt'>
			<option value="1" $sel_o[1]>튼튼함(줄기)</option>
			<option value="2" $sel_o[2]>향기(잎)</option>
			<option value="3" $sel_o[3]>아름다움(꽃)</option>
			</select>
			발현 타입: 
			<select name='REACTION$cnt'>
			<option value="2" $sel_r[2]>우열형</option>
			<option value="1" $sel_r[1]>추가형</option>
			</select>
			이미지 번호: <input type='text' name='DOMAIN$cnt' size="4" maxlength="4" value='$domain'>
			평가: <input type='text' name='STRENGTH$cnt' size="4" maxlength="4" value='$strength'><br>
		};
	}
	$str .= qq{
		<input type="hidden" name='MODE' value='main'>
		<input type="submit" value='표현형에서 변환'>
		</form><hr>
	};
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_expression_type
{
	my ($dna) = @_;
	
	my @exp;
	if(!defined($dna)) {
		for(my $cnt = 1; $cnt <= 5; $cnt++) {
			$exp[$cnt]->{domain}   = $PARAM->{"DOMAIN$cnt"};
			$exp[$cnt]->{strength} = $PARAM->{"STRENGTH$cnt"};
			$exp[$cnt]->{organ}    = $PARAM->{"ORGAN$cnt"} || 0;
			$exp[$cnt]->{reaction} = $PARAM->{"REACTION$cnt"} || 0;
		}
	} else {
		my $rcreature = get_expression_data($dna);
		my $cnt = 1;
		for(my $key = 1; $key <= 3; $key++) {
			my $val = $rcreature->{"$key"};
			foreach (@{$val->{protein}}) {
				$exp[$cnt]->{domain}   = $_->{"domain"};
				$exp[$cnt]->{strength} = $_->{"strength"};
				$exp[$cnt]->{organ}    = $_->{"organ"};
				$exp[$cnt]->{reaction} = $_->{"reaction"};
				$cnt ++;
			}
		}
	}
	
	return \@exp;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_textarea_htm
{
	my $str .= qq{
		<h3>-염기서열에서 표현형으로 변환</h3>
		<form action="$PNAME" method="$RDATA->{method}">
			<textarea name="SEQ" cols="35" rows="12" wrap="SEQ">$PARAM->{SEQ}</textarea>
			<input type="hidden" name='MODE' value='main'><br>
			<input type="submit" value='염기서열에서 변환'>
		</form><hr>
	};
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_hidden_htm
{
	my ($dna, $name) = @_;
	
	my $str .= qq{
		<h3>-전체 유전자 데이터 추가 등록</h3>
		<form action="$PNAME" method="$RDATA->{method}">
			<input type='hidden' name='SEQ' value='&gt;$name\n$dna'>
			<input type="hidden" name='MODE' value='dna_regist'><br>
			<input type="submit" value='유전자 등록'>
		</form><hr>
	};
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
	#plantID,이름,심은 시각,null,성장 레벨,성장 단계,빛과 온도,초,확인한 초,
#수분,초,검사한초,영양,초,검사한초,위치,유전자1,유전자2
###################################################
sub get_flower_img_htm
{
	my ($rcreature) = @_;
	my ($str, $bg_view);
	
	my $time = time;
	my $org_imdir = $RDATA->{plant_img};
	for(my $grow_step = 1; $grow_step <= 5; $grow_step++) {
		my ($htm_h, $htm_t);
		for(my $organ_id = 1; $organ_id <= 3; $organ_id++) {

			my $val = $rcreature->{"$organ_id"};
			my $img_id = $val->{protein}->[$val->{view}->[0]]->{domain};
			my $file_path = "$org_imdir/o$grow_step/o${organ_id}_${img_id}.gif";
			if(!(-e $file_path)) {
				$file_path = "$org_imdir/o$grow_step/o${organ_id}_1.gif";
			}
			$htm_h .= qq{
				<table cellspacing='0' cellpadding='0'><tr>
				<td background='$file_path?$time'>
			};
			$htm_t .= qq{
				</td></tr></table>
			};
		}
		$str .= qq{
			<td bgcolor='#ddffff'><table border='0' cellpadding='0' cellspacing='0'><tr><td>
				<td background='$RDATA->{img_dir}/soil1.gif'>
				$htm_h
				<img src="$RDATA->{img_dir}/space.gif" height=200 width=100 align=top border=2>
				$htm_t
				</td>
			</td></tr></table></td>
		};
	}
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_pure_flower_img_htm
{
	my ($rims, $bg_num) = @_;
	my ($str, $bg_view);
	
	my $time = time;
	my $org_imdir = $RDATA->{plant_img};
	for(my $grow_step = 1; $grow_step <= 5; $grow_step++) {
		my ($htm_h, $htm_t);
		for(my $organ_id = 1; $organ_id <= 3; $organ_id++) {

			my $img_id = $rims->[$organ_id - 1];
			my $file_path = "$org_imdir/o$grow_step/o${organ_id}_${img_id}.gif";
			if(!(-e $file_path)) {
				$file_path = "$org_imdir/o$grow_step/o${organ_id}_1.gif";
			}
			$htm_h .= qq{
				<table cellspacing='0' cellpadding='0'><tr>
				<td background='$file_path?$time'>
			};
			$htm_t .= qq{
				</td></tr></table>
			};
		}
		my $bg_view;
		my $htm_m = qq{
			<img src="$RDATA->{img_dir}/space.gif" height=200 width=100 align=top border=2>
		};
		if($grow_step == 5) {
			my $bg_path = "$org_imdir/obg/o${bg_num}.gif";
			if(!(-e $bg_path)) {
				$htm_m = qq{
					<table height="180" width="80"><tr><td>
						<b><font color='red'>오류</font><br>
						배경이미지파일'$bg_path' 가존재.</b>
					<td></tr></table>
				};
			} else {
				$bg_view = "background='$org_imdir/obg/o${bg_num}.gif'";
			}
		} else {
			$bg_view = "bgcolor='#ddffff'";
		}
		$str .= qq{
			<td $bg_view><table border='0' cellpadding='0' cellspacing='0'><tr><td>
				<td background='$RDATA->{img_dir}/soil1.gif'>
				$htm_h
				$htm_m
				$htm_t
				</td>
			</td></tr></table></td>
		};
	}
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
	#plantID,이름,심은 시각,null,성장 레벨,성장 단계,빛과 온도,초,확인한 초,
#수분,초,검사한초,영양,초,검사한초,위치,유전자1,유전자2
###################################################
sub get_each_flower_img_htm
{
	my ($img_id, $organ_id, $flg) = @_;
	my ($str, $bg_view);
	
	my $time = time;
	my $org_imdir = $RDATA->{plant_img};
	for(my $grow_step = 1; $grow_step <= 5; $grow_step++) {
		my $file_path = "$org_imdir/o$grow_step/o${organ_id}_${img_id}.gif";
		if(!(-e $file_path)) {
			$file_path = "$org_imdir/o$grow_step/o${organ_id}_1.gif";
		}
		
		$str .= qq{
			<td rowspan='3' bgcolor='#ddffff'>
			<table border='0' cellpadding='0' cellspacing='0'><tr><td $bg_view>
				<table cellspacing='0' cellpadding='0'><tr>
					<td background='$file_path?$time'>
					<img src="$RDATA->{img_dir}/space.gif" height=200 width=100 align=top border=$flg>
					</td>
				</tr></table>
			</td></tr></table></td>
		};
	}
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_return_str
{
	my ($dna, $trn) = @_;
	my $str;
	
	my $cnt = 0;
	while(my $line = substr($dna, $cnt, $trn)) {
		$str .= "$line<br>\n";
		$cnt += $trn;
	}
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
#			$->{"organ_id"}->{protein}->[n] = quality
#			               ->{view}  = [n,...]
#			               ->{power} = total_strength
###################################################
sub get_expression_data
{
	my ($dna1, $dna2) = @_;
	my %creature;
	
	inc_inc::add_translated_gene_data(\%creature, $dna1);
	inc_inc::add_translated_gene_data(\%creature, $dna2) if(defined($dna2));
	inc_inc::add_expression_data(\%creature);
	
	return \%creature;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_dna_seq
{
	my $gene;
	
	for(my $cnt = 1; $cnt <= 5; $cnt++) {
		my $domain   = $PARAM->{"DOMAIN$cnt"};
		my $strength = $PARAM->{"STRENGTH$cnt"};
		my $organ    = $PARAM->{"ORGAN$cnt"} || 0;
		my $reaction = $PARAM->{"REACTION$cnt"} || 0;

		$gene .= "TTTTTAAAAAGGATG" . get_change_val(2, $organ) . get_change_val(4, $domain)
			. get_change_val(1, $reaction) . get_change_val(4, $strength) . "TAAGG";
	}
	
	return $gene;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_change_val
{
	my ($keta, $val) = @_;
	
	my $domain;
	for(my $cnt = $keta - 1; $cnt >= 0; $cnt--) {
		my $kisu = 16 ** $cnt;
		my $codon = $CODON[int($val / $kisu)];
		$domain = "$codon$domain";
		$val     = $val % $kisu;
	}
	
	return $domain;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_dna_data
{
	my @dnas;
	
	open(DNA, "$RDATA->{sys_dir}/dna.cgi")
		|| error_end(__LINE__, "파일 오류", $!);
	while(chomp(my $line = <DNA>)) {
		push(@dnas, [(split(/\t/, $line))]);
	}
	close(DNA) || error_end(__LINE__, "파일 오류", $!);
	
	return \@dnas;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub put_dna_data
{
	my ($dna, $name) = @_;
	$name =~ s/\s//g;
	
	open(DNA, ">>$RDATA->{sys_dir}/dna.cgi")
		|| error_end(__LINE__, "파일 오류", $!);
	print DNA "$dna\t$name\n";
	close(DNA) || error_end(__LINE__, "파일 오류", $!);
	
	return 1;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_page_link_htm
{
	my ($data_num, $add_param) = @_;
	
	my $now_page = $PARAM->{PAG} * 1;
	my $pgf      = $PARAM->{PGF} * 1;
	my $max_page = int(($data_num + $pgf - 1) / $pgf);
	
	my $str = "<b>Total: ${max_page}page, Page: </b>";
	my $b_page = $now_page - 1;
	$str .= ($b_page < 1)? "&lt;&nbsp;&nbsp;":
		"<a href='$PNAME?$add_param&PGF=$pgf&PAG=$b_page'>&lt;</a>&nbsp;&nbsp;";
	
	for(my $page = $now_page - 5; $page <= $now_page + 5; $page ++) {
		if($page < 1) {next;} if($page > $max_page) {last;}
		if($page == $now_page) {$str .= "<font color='red'><b>$page</b></font>&nbsp;&nbsp;";}
		else {$str .= "<a href='$PNAME?$add_param&PGF=$pgf&PAG=$page'>$page</a>&nbsp;&nbsp;";}
	}
	my $n_page = $now_page + 1;
	$str .= ($n_page > $max_page)? "&gt;":
		"<a href='$PNAME?$add_param&PGF=$pgf&PAG=$n_page'>&gt;</a>";
	
	return $str;
}
#####################################################################################################
###################################################
#  input:()
# retrun:
#comment:
###################################################
sub is_old_version
{
	my $rusr = get_user_data();
	my $uid  = $rusr->[0]->[0];
	
	if(defined($uid)) {
		my $rstatus = get_status_data($uid);
#		if(!defined($rstatus->[0]->[12])
#			|| !(-e "$RDATA->{data_dir}/user_pure_count.cgi")) {
		if(!defined($rstatus->[0]->[12])) {
			
			return 1;
		}
	}
	
	return 0;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub renew_status_file
{
	my $rusr = get_user_data();
	foreach (@$rusr) {
		my $uid     = $_->[0];
		my $rstatus = get_status_data($uid);
		if(defined($rstatus->[0]->[12])) {last;}
		my $ralbm   = get_album_data($uid);
		my $alb_cnt = @$ralbm;
		my $album_max = $RDATA->{album_max} || 100;
		@{$rstatus->[0]}[10, 11, 12]
			= ($album_max, $alb_cnt, $alb_cnt);
		put_status_data($uid, $rstatus);
	}
	
	return 1;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_version_up_htm
{
	my $str;
	
	my $opt = $PARAM->{OPT};
	if(!$opt) {
		$str = get_version_up_confirm_htm("
			저장된 데이터 형식이inc_plant.cgi V.2.2이전 형식입니다.<br>
			버전 업합니다가?
		");
	} elsif(is_exist_lockfile()) {
		$str = get_version_up_confirm_htm("
			$RDATA->{lock_dir}/lockfile 을삭제하고점검 모드에해 주세요.
		");
	} else {
		renew_status_file();
		make_about_pure_data();
		$str = get_version_up_confirm_htm("
			데이터 버전 업이 정상적으로 완료되었습니다.<br>
			※ $RDATA->{lock_dir}/lockfile 을 업로드, 점검 모드를 해제해 주세요.
		");
	}
	
	return \$str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub make_about_pure_data
{
	my (@punum, %usr_pure);

	my $rusr = get_user_data();
	foreach my $ru (@$rusr) {
		my %counter;
		my $uid    = $ru->[0];
		my $rplant = get_album_data($uid);
		foreach (@$rplant) {
			my $rcreature = get_expression_data((@$_)[16, 17]);
			if(defined(my $rep_id = get_represent_flower($rcreature))) {
				if($punum[$rep_id]->[5] < $_->[25]) {
					$punum[$rep_id] = [$punum[$rep_id]->[0] +1, $uid,
						$_->[0], $ru->[1], $_->[1], $_->[25]];
				} else {
					$punum[$rep_id]->[0] ++;
				}
					
				$counter{"$rep_id"} = 1;
			}
		}
		my $pure_count = keys(%counter);
		$usr_pure{"$uid"} = $pure_count;
	}

	put_pure_number_data(\@punum);
	put_user_pure_count_data(\%usr_pure);

	return 1;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_represent_flower
{
	my ($rcreature) = @_;
	my @view;
	
	for(my $organ_id = 1; $organ_id <= 3; $organ_id++) {
		my $val = $rcreature->{"$organ_id"};
		my $im_id = $val->{protein}->[$val->{view}->[0]]->{domain};
		push(@view, $im_id);
	}
	my $rep_data = get_represent_data();
	for(my $rep_id = 0; $rep_id < @$rep_data; $rep_id++) {
		my $rrep = $rep_data->[$rep_id];
		if($rrep->[2] == $view[2] && $rrep->[1] == $view[1] && $rrep->[0] == $view[0]) {
			return $rep_id;
		}
	}
	
	return undef;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_represent_data
{
	my @data;
	
	open(IN, "$RDATA->{sys_dir}/represent_plant.cgi")
		|| error_end(__LINE__, "파일 오류", $!);
	while(chomp(my $line = <IN>)) {
		if(!$line) {next;}
		push(@data, [(split(/\t/, $line))]);
	}
	close(IN) || error_end(__LINE__, "파일 오류", $!);
	
	return \@data;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_version_up_confirm_htm
{
	my ($alert_str) = @_;
	my $str = "Content-type: text/html\n\n";
	$str .= qq{<HTML>
		<HEAD>
		<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
		<META NAME="author" CONTENTS="GIGAHO">
		<link rel="stylesheet" type="text/css" href="./inc_plant.css">
		<TITLE>신기한 식물 메이커(버전 업)</TITLE>
		</HEAD>
		<BODY BGCOLOR='#d1f8d8' background='' onLoad=''><center>
		<br><font color='red'>$alert_str</font><br>
		&nbsp;&nbsp;&nbsp;
		<form>
			<input type="button" value='다음' onClick='location.href="$PNAME?MODE=login&PWD=$PARAM->{PWD}&OPT=1"'>
			<input type="button" value='취소' onClick='location.href="$PNAME"'>
		</form>
		</center></body></html>
	};
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub put_pure_number_data
{
	my ($rpure_num) = @_;
	
	open(OUT, ">$RDATA->{data_dir}/pure_number.cgi")
		|| error_end(__LINE__, "파일 오류", $!);
	foreach (@$rpure_num) {
		if(defined($_)) {print OUT join("\t", @$_) . "\n";}
		else {print OUT "\n";}
	}
	close(OUT) || error_end(__LINE__, "파일 오류", $!);
	
	return 1;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub put_user_pure_count_data
{
	my ($rusr_pure) = @_;
	
	open(OUT, ">$RDATA->{data_dir}/user_pure_count.cgi")
		|| error_end(__LINE__, "파일 오류", $!);
	while(my ($uid, $pure_cnt) = each(%$rusr_pure)) {
		print OUT "$uid\t$pure_cnt\n";
	}
	close(OUT) || error_end(__LINE__, "파일 오류", $!);
	
	return 1;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_server_data
{
	my %data;
	
	if(-e "$RDATA->{data_dir}/server.cgi") {
		open(IN, "$RDATA->{data_dir}/server.cgi")
			|| error_end(__LINE__, "파일 오류", $!);
		while(chomp(my $line = <IN>)) {
			my @dt = split(/\t/, $line);
			$data{"$dt[0]"} = \@dt;
		}
		close(IN) || error_end(__LINE__, "파일 오류", $!);
	}
	
	return \%data;
}

###################################################
#  input:()
# retrun:
#comment: 원래는 잠금 처리가 필요합니다.
###################################################
sub put_server_data
{
	my ($rserver) = @_;
	
	open(OUT, ">$RDATA->{data_dir}/server.cgi")
		|| error_end(__LINE__, "파일 오류", $!);
	foreach (values(%$rserver)) {
		print OUT join("\t", @$_) . "\n";
	}
	close(OUT) || error_end(__LINE__, "파일 오류", $!);
	
	return 1;
}

#####################################################################################################
###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_login_htm
{
	my $rstr;

	if($PARAM->{PWD} ne $RDATA->{manager_pass}) {
		$rstr = get_start_htm("비밀번호가 다릅니다");
	} elsif(is_old_version()) {
		$rstr = get_version_up_htm();
	} else {
		my $rstr_t = get_main_htm();
		$$rstr = "Set-Cookie: UCK=$RDATA->{manager_pass}\n" . $$rstr_t;	#cookie의설정
	}
	
	return $rstr;
}

#####################################################################################################
###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_copyright
{
	my $str = "<hr size='1'>\n";
	
	$str .= "<table width='100%' border='0' cellspacing='0' cellpadding='0' class='copyright'>\n";
#	$str .= "<tr><td align='right'><font size='-2'>" . get_cpu_time() . "CPUs</font></td></tr>\n";
	$str .= "<tr><td align='right'><font size='-2'>$VERSION</font></td></tr>\n";

	foreach (@{$RDATA->{copyright}}) {
		$str .= "<tr><td align='right'><font size='-1'>$_</font></td></tr>\n";
	}

	$str .= "</table>\n";
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub is_exist_lockfile
{
	my $lock_dir = $RDATA->{lock_dir};

	opendir(LOCKDIR, $lock_dir);
	while (my $filename = readdir(LOCKDIR)) {
		if($filename =~ /lockfile/) {return 1;}
	}
	closedir(LOCKDIR);
	
	return 0;
}

###################################################
#  input:($type, $comment, $point)
# retrun:exit 1
#comment: 오류 처리 서브루틴
###################################################
sub error_end
{
	my ($point, $type, $comment) = @_;
	$comment =~ s/\n//g;
	
	sys_common::error_htm("$PNAME($VERSION)", $point, $type, $comment,
		{file => "$RDATA->{'data_dir'}/cgi.err"});

	exit 1;
}

##################################################
#input  :
#return :
#comment:
##################################################
sub is_cookie_ok
{
	my $rcook = get_cookie();
	if($rcook->{UCK} eq $RDATA->{manager_pass})
		{return 1;}
	
	return 0;
}

##################################################
#input  :
#return :
#comment:
##################################################
sub get_cookie
{

	my $cookie_str = $ENV{'HTTP_COOKIE'};
	my (%data, @cookie);

	@cookie = split(/ /, $cookie_str);

	foreach (@cookie) {
		my ($name, $val) = split(/=/);
		$val =~ s/;$//;
		$data{$name} = $val;
	}
	return \%data;

}

####################################################################################################

1;
