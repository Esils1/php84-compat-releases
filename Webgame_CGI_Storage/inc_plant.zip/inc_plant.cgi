#!/usr/bin/perl

#####################################################################################################
#Program:																							#
#Comment:																							#
#-dna data																							#
#																									#
#dna,이름,
#																									#
#-udata
# 0   1    2    3   4    5   6  7       8         9     10      11         12             13        #     
#uid,name,pass,url,mail,sex,ken,IP,access time,open_flg,nid,간단 설명,상세 설명,앨범 최종 편집 시간,#
#       14           15
#bbs쓰기시간,session_id
#
#-plant data
#   0      1     2        3         4         5        6      7        8
#plantID,이름,심은 시각,rcreture,성장 레벨,성장 단계,빛과 온도,초,확인한 초,
#  9  10       11        12  13      14         15    16      17      18
#수분,초,검사한초,영양,초,검사한초,위치,유전자1,유전자2,평가액,uid1,uid2,
# 21   22      23         24      25                   26           27
#pid1,pid2,기본 교배료,설정 교배료,앨범에 저장한 시간,아이템 이용 상황,최초 플래그
#																									#
#-status data->[0]
# 0      1      2     3      4                  5          6    7    8
#금액,등록 초,등록 시간,등급,꽃 수(total),보유 종자 수,보유 가능 종자 수,,보유 가능 화분 수
#         9                        10                     11                      12
#,마지막으로 음악을 들려준 시각,앨범 저장 가능 식물 수,앨범 내 식물 수,지금까지 개화한 식물 수
#																									#
#-seed data
# 0      1        2     3      4       5      6       7       8     9
#pid,사용 가능 여부,이름,유전자1,유전자2,가격,자신uid,상대uid,자신pid,상대pid
#※ 가격은 plant data의 18번 항목과 일치하지 않을 수 있음
#
#-mail data
#    0       1    2     3       4
#송수신 구분,시각,UID,comment,신규 Flag
#
#-bbs data
#    0       1    2   3     4
#삭제 플래그,시간,UID,PID,comment
#
#-아이템데이터
# 0 ,  1      2     3       4            5         6      7
#iid, name, price, img,최대 보유 가능 수, 판매가,(등급용 예비 필드),설명
#iid 체리님 16-20
#iid 루피나님 30-85
#
#
#-수분 식물왕
#
#uid,pid,수분 횟수
#
#-represent pure data
#   0          1          2         3       4      5
#im_id(줄기), im_id(잎), im_id(꽃), 일반명, 학명, 설명
#
#-pure_number
#  0      1    2       3        4      5
#개화 수, UID, PID, user_name, 식물명, time
#
#-user_pure_count
# 0        1    
#UID, 순계 종류 수
#
#숨겨진 기능: 개화 중인 꽃이라면 다른 사람의 꽃과도 수분할 수 있음. 일반 이용 중에는 사용할 수 없음.
#
#   Date:	20060326																				#
#Version:	2.5																						#
# Author:	H.Wakaguri(Gigaho)																		#
#####################################################################################################

use lib'./lib';
use strict;

require 'sys_common.cgi';
require 'inc_plant_conf.cgi';
require 'inc_inc.cgi';

my $PNAME   = "inc_plant.cgi";
my $VERSION = "신기한 식물 Ver.2.5";	#script version
my $RDATA   = inc_plant_conf::get_rdata();

#MODE, UID, NAM, PWD, HP, MAIL, OPT, IID...
my $PARAM = sys_common::param();
my $JST = 9 * 3600;

my $LOCK = my_flock() || error_end(__LINE__, "사이트가 혼잡합니다", "File lock", 1);
($LOCK != -1)         || error_end(__LINE__, "현재 점검 중입니다", "File lock", 1);

eval {
	my $str;

	put_routine();
	
	if($PARAM->{MODE} eq "reg_check") {
		$str = get_reg_check_htm();
	} elsif($PARAM->{MODE} eq "regist") {
		$str = get_regist_htm();
	} elsif($PARAM->{MODE} eq "reg_start") {
		$str = get_registration_start_htm();
	} elsif($PARAM->{MODE} eq "login") {
		$str = get_login_htm();
	} elsif($PARAM->{MODE} eq "whole_hist") {
		$str = get_whole_hitory_htm();
	} elsif($PARAM->{MODE} eq "album") {
		$str = get_album_htm();
	} elsif($PARAM->{MODE} eq "no_cook") {
		$str = get_no_cook_htm();
	} elsif($PARAM->{MODE} eq "score_table") {
		$str = get_score_table_htm();
	} elsif($PARAM->{MODE} eq "i_help") {
		$str = get_help_htm();
	} elsif($PARAM->{MODE} eq "view_parent") {
		$str = get_parent_album_htm();
	} elsif($PARAM->{MODE} eq "view_each") {
		$str = get_mono_album_htm();
	} elsif($PARAM->{MODE} eq "pedia") {
		$str = get_pedia_htm();
	} elsif($PARAM->{MODE} eq "open_bbs") {
		$str = get_bbs_secure_htm();
	} elsif($PARAM->{MODE} eq "server_login") {
		$str = get_server_login_htm();
	} elsif($PARAM->{MODE} eq "server_payment") {
		$str = get_server_payment_htm();
	} elsif($PARAM->{MODE} eq "server_makeseed") {
		$str = get_server_makeseed_htm();
	} elsif(is_cookie_ok()) {
		# 여기부터는 로그인 상태에서만 실행 가능
		if($PARAM->{MODE} eq "main") {
			$str = get_const_htm();
		} elsif($PARAM->{MODE} eq "into_album") {
			$str = get_into_album_htm();
		} elsif($PARAM->{MODE} eq "ch_comment") {
			$str = get_change_comment_htm();
		} elsif($PARAM->{MODE} eq "shop") {
			$str = get_shop_htm();
		} elsif($PARAM->{MODE} eq "shop_sell") {
			$str = get_shop_htm();
		} elsif($PARAM->{MODE} eq "seed_sell") {
			$str = get_shop_htm();
		} elsif($PARAM->{MODE} eq "use_item") {
			$str = get_use_item_htm();
		} elsif($PARAM->{MODE} eq "pollination") {
			$str = get_pollination_htm();
		} elsif($PARAM->{MODE} eq "sow_item") {
			$str = get_sow_item_htm();
		} elsif($PARAM->{MODE} eq "mail") {
			$str = get_mail_htm();
		} elsif($PARAM->{MODE} eq "bbs") {
			$str = get_bbs_htm();
		} elsif($PARAM->{MODE} eq "bbs_sel_album") {
			$str = get_bbs_sel_album_htm();
		} elsif($PARAM->{MODE} eq "reg_change") {
			$str = get_usr_registration_change_htm();
		} elsif($PARAM->{MODE} eq "album_del") {
			$str = get_plant_delete_check_htm();
		} elsif($PARAM->{MODE} eq "album_del_ok") {
			$str = get_plant_delete_ok_htm();
		} elsif($PARAM->{MODE} eq "server_select") {
			$str = get_server_select_htm();
		} else {
			$str = get_start_htm();
		}
	} else {
		$str = get_logout_htm();
	}
	my_funlock($LOCK);
	
	print_headder();
	print($str);

	exit 0;
};
error_end(__LINE__, "예상치 못한 오류", $@);

exit 1;

####################################################################################################
###################################################
#  input:()
# retrun:
#comment:
###################################################
sub print_headder
{
	#for mac
	print("Pragma: no-cache\nCache-Control: no-cache\nExpires: Thu, 01 Dec 1994 16:00:00 GMT\n");
	
	return 1;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub put_routine
{
	my @delusr_ids;
	
	my $tintim = get_routine_time();
	my $time   = time;
	if(!$tintim) {$tintim = $time; put_routine_time($time);}	#초기화
	if($time - $tintim >= $RDATA->{term}) {
		my $rallu  = get_all_udata_hash();
		while(my ($uid, $rudata) = each(%$rallu)) {
			my $rplant = get_plant_data($uid);
			$rplant = get_new_rplant($rudata, $rplant, $time);
			put_plant_data($uid, $rplant);
			do_new_event($uid, $tintim, $time);
			
			# 1개월 이상 로그인하지 않은 사용자 삭제
			if($RDATA->{delete_time} < $time - $rudata->[8]) {
				push(@delusr_ids, $uid);
			}
		}

		if(@delusr_ids) {
			foreach (@delusr_ids) {delete($rallu->{"$_"});}
			put_all_udata($rallu);
			# 파일 오류 회피용 임시 파일은 나중에 삭제
			foreach (@delusr_ids) {delete_regist_user($_);}
		}

		# 오류 판정을 쉽게 하기 위해 마지막에 타이머 입력
		put_routine_time($time - (($time - $tintim) % $RDATA->{term}));
	}
	
	make_uranai_data($time);
	make_backup_data($time);
	
	return 1;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub do_new_event
{
	my ($uid, $tintim, $time) = @_;
	my $term = $RDATA->{term};
	for(my $now_time = $tintim; $now_time < $time; $now_time += $term) {
		if(rand() < 1 / 144) {
			my $rseed  = get_seed_data($uid);
			if(keys(%$rseed) == 0) {
				my $rudata = get_status_data($uid);
				my $dna1 = get_rundom_dna();
				my $dna2 = $dna1;
#				my $dna2 = get_rundom_dna();
				my $rstatus = $rudata->[0];
				$rstatus->[5]++;
				my $new_pid = ++$rstatus->[4];
				$rseed->{"$new_pid"} = [$new_pid, 1, "새 식물($new_pid)", $dna1, $dna2, 0];
				put_seed_data($uid, $rseed);
				put_self_history($uid, "길가에서 식물 씨앗을 주웠습니다", "green", $now_time);
				put_status_data($uid, $rudata);
			}
		}
	}
	
	return 1;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_logout_htm
{
	my $str_t = get_start_htm();
	my $str = "Set-Cookie: UCK=\n" . $str_t;	#cookie 삭제 설정
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_start_htm
{
	my ($err_str, $uname)  = @_;
	
	$uname = $PARAM->{NAM} if(!defined($uname));
	my $rudata = get_all_udata();
	my $u_cnt  = @$rudata;
	my $regist_htm = ($u_cnt < $RDATA->{max_user})? qq{
		<input type="button" value='새로 등록' onClick="location.href='$PNAME?MODE=reg_start'"><br>
	}: qq{
		<font size='-1' color='red'>최대 등록 인원에 도달하여 새로 등록할 수 없습니다. 양해해 주세요.</font><br>
	};
	my $bbs_str = "/ <a href='$PNAME?MODE=open_bbs'>식물게시판</a>" if(defined($RDATA->{bbs}));
	my $pedia_url  = $RDATA->{pedia_url} || "$PNAME?MODE=pedia";
	my $field_name = $RDATA->{field_name} || "신기한 식물";
	
	my $str = "Content-type: text/html\n\n";
	$str .= qq{<html><head>};
	$str .= get_head();
	$str .= qq{
		<title>$field_name</title>
		</head>
		<body bgcolor='#d1f8d8' background='' onLoad=''>
			<form action="$PNAME" method="$RDATA->{method}" name="reg"><center>
			<img src='$RDATA->{img_dir}/inc_plant.gif' border='0'>
			<table width="450" border="0" cellspacing="0" cellpadding="0"><tr><td bgcolor="#aa8800"> 
			<table border="0" cellspacing="1" cellpadding="2" height="100%" width="100%">
			<tr><td bgcolor="#ffddcc" align="center" class='table_top start_top'>
				<b><font color="#664400" face="Arial, Helvetica, sans-serif">
				「$field_name」에 오신 것을 환영합니다<br>
				사용자명과 비밀번호를 입력해 주세요</font></b></td>
			</tr>
			<tr><td bgcolor="#FFFFFF" class='table_bottom'> 
				<center><font color='red'>$err_str</font>
				<table border="0" cellspacing="3" cellpadding="2">
					<tr><td ALIGN="right">
							<font face="Times New Roman, Times, serif" size="2"><b>닉네임</b></font></td>
						<td align="left"> 
							<INPUT TYPE="text" NAME="NAM" SIZE="8" MAXLENGTH="16" value='$uname'></td>
						<td ALIGN="right">
							<b><font size="2" face="Times New Roman, Times, serif">비밀번호</font></b>
						</td><td align="left"> 
							<INPUT TYPE="password" NAME="PWD" SIZE="8" MAXLENGTH="8" value=''></td>
					</tr><tr> 
						<td colspan='4' ALIGN="center" valign="middle"> 
							<input type="submit" value='입장'>
						</td>
					</tr>
				</table></center></td>
			</tr></table></td></tr></table>
			<INPUT TYPE="hidden" NAME="MODE" value='login'>
			</center></form>

			<form action="$PNAME" method="$RDATA->{method}" name="reg"><center>
			<table width="450" border="0" cellspacing="0" cellpadding="0"><tr><td bgcolor="#aa8800"> 
			<table border="0" cellspacing="1" cellpadding="2" height="100%" width="100%">
				<tr><td bgcolor="#ffccdd" align="center" class='table_top start_bottom'>
					<a href='$PNAME?MODE=whole_hist'>최근 소식</a> /
					<a href='$pedia_url'>식물 도감</a> /
					<a href='$PNAME?MODE=album'>식물 앨범</a>
					$bbs_str
				</td></tr>
				<tr><td bgcolor="#FFFFFF" align="center" class='table_bottom'>
				$regist_htm
				<font size='-1'>($u_cnt명등록안/$RDATA->{max_user}명까지등록할 수 있습니다.)</font>
				</td></tr>
				<tr><td bgcolor="#FFFFFF" align="left" class='table_top start_bottom'>
					$RDATA->{top_comment}
				</td></tr>
			</table></td></tr></table></center></form>
	};
	$str .= get_copyright();
	$str .= "<br></body></html>";
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_whole_hitory_htm
{
	
	my $back_url = ($PARAM->{UID})? "$PNAME?MODE=main&UID=$PARAM->{UID}": $RDATA->{home_url};

	my $str = "Content-type: text/html\n\n";
	$str .= qq{<html><head>};
	$str .= get_head();
	$str .= qq{
		<title>전체 소식</title>
		</head>
		<body bgcolor='#d1f8d8' background='' onLoad=''>
			<form><center>
			<img src='$RDATA->{img_dir}/inc_plant.gif' border='0'>
			<table width="450" border="0" cellspacing="0" cellpadding="0"><tr><td bgcolor="#ddbb88"> 
			<table border="0" cellspacing="1" cellpadding="2" height="100%" width="100%">
			<tr><td bgcolor="#FFFFFF" align="center" class='table_top hist_top'>
				<table width='100%'><tr>
					<td><img src='$RDATA->{img_dir}/btn11_0.gif' border='0'></td>
					<td align='center'>
						<b><font color="#997744" face="Arial, Helvetica, sans-serif">
						최근 소식<br>
						<font size='-1'>(소식이 도착 순서대로 표시됩니다)</font></font></b>
					</td>
					<td align='right' valign='bottom'><input type='button' value=' 돌아가기 ' onClick="location.href='$back_url'"></td>
				</tr></table>
				</td>
			</tr>
			<tr><td colspan='4' bgcolor="#FFFFFF" class='table_bottom'>
	};
	$str .= get_whole_history_main_htm();
	$str .= qq{
			</td></tr>
			<tr><td bgcolor="#FFFFFF" align="right" class='table_top hist_bottom'>
				<input type='button' value=' 돌아가기 ' onClick="location.href='$back_url'">
			</td></tr>
			</table></td></tr></table>
			</center></form>

	};
	$str .= get_copyright();
	$str .= "<br></body></html>";
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_seed_cost_from_rdata
{
	my ($rdata) = @_;
	
	my $rf_type = get_flower_type_data();
	my $seed_cost = get_seed_cost($rf_type, $rdata->[3]);

	return $seed_cost;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_seed_cost
{
	my ($rf_type, $rcreature) = @_;
	
	my $max_cost = $RDATA->{max_cost};
	my $min_cost = $RDATA->{min_cost};
	
	my $cost;
	if(!defined($rf_type->{"1"})) {return $min_cost * 4;}
	for(my $organ_id = 1; $organ_id <= 3; $organ_id++) {
		my $cnt_max = 2;
		while(my ($im_id, $im_cnt) = each(%{$rf_type->{"$organ_id"}})) {
			if($cnt_max < $im_cnt) {$cnt_max = $im_cnt;}
		}
		my $val = $rcreature->{"$organ_id"};
		my $im_id = $val->{protein}->[$val->{view}->[0]]->{domain};
		my $now_cnt = $rf_type->{"$organ_id"}->{"$im_id"} || 1;
		my $add_cost = ($now_cnt < (1 + $cnt_max) / 4)? 
			int((($min_cost - 3 * $max_cost) * $now_cnt - $min_cost
			 + $max_cost * $cnt_max) / ($cnt_max - 3)):
			int(((3 * $min_cost - $max_cost) * $now_cnt - $min_cost
			 + $max_cost * $cnt_max) / (3 * $cnt_max - 1));
		
#		my $add_cost = int(($min_cost * $max_cost * $cnt_max * ($cnt_max - 1)) /
#			(($max_cost - $min_cost * $cnt_max) * $now_cnt ** 2 +
#			($min_cost * $cnt_max ** 2 - $max_cost) * $now_cnt));
		
		if($organ_id == 3) {$add_cost *= 2;}
		$cost += $add_cost;
	}
	
	return $cost;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_popular_flower
{
	my (@poptree);
	
	if(-e "$RDATA->{data_dir}/popular_flower.cgi") {
		open(IN, "$RDATA->{data_dir}/popular_flower.cgi")
			|| error_end(__LINE__, "파일 오류", $!);
		while(chomp(my $line = <IN>)) {
			my ($uid, $pid) = split(/\t/, $line);
			push(@poptree, [$uid, $pid]);
		}
		close(IN) || error_end(__LINE__, "파일 오류", $!);
	}
	
	return \@poptree;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub put_popular_flower
{
	my ($rpoptree) = @_;
	
	open(OUT, ">$RDATA->{data_dir}/popular_flower.cgi")
		|| error_end(__LINE__, "파일 오류", $!);
	my $cnt = 0;
	my $max_cnt = $RDATA->{popular_plant_cnt} || 500;
	foreach (@$rpoptree) {
		print OUT join("\t", @$_) . "\n";
		if(++$cnt >= $max_cnt) {last;}
	}
	close(OUT) || error_end(__LINE__, "파일 오류", $!);
	
	return 1;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_flower_type_data
{
	my %type_cnt;
	
	if(-e "$RDATA->{data_dir}/flower_type.cgi") {
		open(IN, "$RDATA->{data_dir}/flower_type.cgi")
			|| error_end(__LINE__, "파일 오류", $!);
		while(chomp(my $line = <IN>)) {
			my ($organ_id, $im_id, $dt_cnt) = split(/\t/, $line);
			$type_cnt{"$organ_id"}->{"$im_id"} = $dt_cnt;
		}
		close(IN) || error_end(__LINE__, "파일 오류", $!);
	}
	
	return \%type_cnt;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub put_flower_type_data
{
	my ($rf_type) = @_;
	
	open(OUT, ">$RDATA->{data_dir}/flower_type.cgi")
		|| error_end(__LINE__, "파일 오류", $!);
	while(my ($organ_id, $rtype) = each(%$rf_type)) {
		while(my ($im_id, $cnt) = each(%$rtype)) {
			print OUT "$organ_id\t$im_id\t$cnt\n";
		}
	}
	close(OUT) || error_end(__LINE__, "파일 오류", $!);
	
	return 1;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_pure_number_data
{
	my @data;
	
	if(-e "$RDATA->{data_dir}/pure_number.cgi") {
		open(IN, "$RDATA->{data_dir}/pure_number.cgi")
			|| error_end(__LINE__, "파일 오류", $!);
		while(chomp(my $line = <IN>)) {
			push(@data, [(split(/\t/, $line))]);
		}
		close(IN) || error_end(__LINE__, "파일 오류", $!);
	}
	
	return \@data;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub put_pure_number_data
{
	my ($rpure_num) = @_;
	
	open(OUT, ">$RDATA->{data_dir}/pure_number.cgi")
		|| error_end(__LINE__, "파일 오류", $!);
	foreach (@$rpure_num) {
		if(defined($_)) {print OUT join("\t", @$_) . "\n";}
		else {print OUT "\n";}
	}
	close(OUT) || error_end(__LINE__, "파일 오류", $!);
	
	return 1;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_user_pure_count_data
{
	my %data;
	
	if(-e "$RDATA->{data_dir}/user_pure_count.cgi") {
		open(IN, "$RDATA->{data_dir}/user_pure_count.cgi")
			|| error_end(__LINE__, "파일 오류", $!);
		while(chomp(my $line = <IN>)) {
			my ($uid, $pure_cnt) = split(/\t/, $line);
			$data{"$uid"} = $pure_cnt;
		}
		close(IN) || error_end(__LINE__, "파일 오류", $!);
	}
	
	return \%data;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub put_user_pure_count_data
{
	my ($rusr_pure) = @_;
	
	open(OUT, ">$RDATA->{data_dir}/user_pure_count.cgi")
		|| error_end(__LINE__, "파일 오류", $!);
	while(my ($uid, $pure_cnt) = each(%$rusr_pure)) {
		print OUT "$uid\t$pure_cnt\n";
	}
	close(OUT) || error_end(__LINE__, "파일 오류", $!);
	
	return 1;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub delete_pure_data_from_uid
{
	my ($uid) = @_;
	
	my $rpunum = get_pure_number_data();
	foreach (@$rpunum) {
		$_->[1] = undef if($_->[1] == $uid);
	}
	put_pure_number_data($rpunum);
	
	my $rusr_pure = get_user_pure_count_data($uid);
	delete($rusr_pure->{"$uid"});
	put_user_pure_count_data($rusr_pure);
	
	return 1;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_bbs_sel_album_htm
{
	my $str = (defined($RDATA->{bbs}))?
		get_album_htm(): get_start_htm();
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_change_comment_htm
{
	my $alert_str = change_my_comment();
	my $str = get_album_htm($alert_str);
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub change_my_comment
{
	my $alert_str;
	
	my $uid = $PARAM->{UID};
	my $sbj = $PARAM->{SBJ};
	my $cmt = $PARAM->{CMT};
	if($sbj ne get_safe_htm($sbj, 1)) {
		$alert_str = "제목에 사용할 수 없는 문자가 포함되어 있습니다.";
	}
	if(length($sbj) > 50) {
		$alert_str = "제목이 너무 깁니다.";
	}
	if($cmt ne get_safe_htm($cmt, 2)) {
		$alert_str = "댓글에 사용할 수 없는 문자가 포함되어 있습니다.";
	}
	if(length($cmt) > 800) {
		$alert_str = "댓글이 너무 깁니다.";
	}
	$cmt =~ s/\r\n|\r|\n|\t/<br>/g;
	 
	if(!$alert_str) {
		my $rallu = get_all_udata_hash();
		my $ru    = $rallu->{"$uid"};
		@$ru[11, 12, 13] = ($sbj, $cmt, time);
		put_all_udata($rallu);
		$alert_str = "앨범 댓글을 수정했습니다.";
	}
	 
	return "<font color='red'>$alert_str</font>";
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_whole_history_main_htm
{
	my @lines;
	my $time = time;
	
	if(-e "$RDATA->{data_dir}/whole_hist.cgi") {
		open(UHIST, "$RDATA->{data_dir}/whole_hist.cgi")
			|| error_end(__LINE__, "파일 오류", $!);
		chomp(@lines = <UHIST>);
		close(UHIST) || error_end(__LINE__, "파일 오류", $!);
	}
	
	my $history = qq{<table>};
	foreach (reverse(@lines)) {
		my ($time, $comm, $color) = split(/\t/, $_);
		my $time_str = get_time_str($time);
		if(!$color) {$color = "blue";}
		$history .= "
			<tr><td nowrap valign='top' align='right'><font color='$color'>$time_str:</font></td> 
			<td ><font color='$color'>$comm</font></td></tr>
		";
	}
	$history .= qq{</table>};
	
	return $history;
}


###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_reg_check_htm
{
	my $str;

	my $rudata = get_all_udata();
	if(@$rudata < $RDATA->{max_user}) {
		my $ndata = get_regist_err_html();
		if(defined($ndata)) {
			$str = get_usr_registration_htm($ndata);
		} else {
			$str = get_usr_registration_check_htm();
		}
	} else {
		$str = get_start_htm();
	}
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_bbs_secure_htm
{
	if(!defined($RDATA->{bbs})) {return get_start_htm();}

	my $alert_str;
	my $uid     = $PARAM->{UID};
	my $rallu   = get_all_udata_hash();
	my $rsecret = get_secret_data();

	my $rbbs = get_bbs_data();
	
	my $str = "Content-type: text/html\n\n";
	$str .= qq{<html><head>};
	$str .= get_head();
	$str .= qq{
		<title>게시판 화면</title>
		</head>
		<body bgcolor='#d1f8d8' background='' onLoad=''>
			<center><img src='$RDATA->{img_dir}/inc_plant.gif' border='0'></center>
	};
	$str .= get_top_open_bbs_htm();
	$str .= get_bbs_table_htm($rbbs, $rallu, $rsecret);
	$str .= get_copyright();
	$str .= "<br></body></html>";
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_bbs_htm
{
	if(!defined($RDATA->{bbs})) {return get_start_htm();}

	my $alert_str;
	my $uid     = $PARAM->{UID};
	my $rallu   = get_all_udata_hash();
	my $rsecret = get_secret_data();

	my ($type, $bbsid) = split(/!/, $PARAM->{OPT});

	my $rbbs = get_bbs_data();
	if($type == 1) {
		$alert_str = contributing_bbs($rbbs, $rallu);
	} elsif($type == 3) {
		$alert_str = delete_bbs($rbbs);
	}
	
	my $str = "Content-type: text/html\n\n";
	$str .= qq{<html><head>};
	$str .= get_head();
	$str .= qq{
		<title>게시판 화면</title>
		</head>
		<body bgcolor='#d1f8d8' background='' onLoad=''>
			<center><img src='$RDATA->{img_dir}/inc_plant.gif' border='0'></center>
	};
	$str .= get_bbs_contribute_box_htm($rallu, $rsecret, $alert_str);
	$str .= get_bbs_table_htm($rbbs, $rallu, $rsecret);
	$str .= get_copyright();
	$str .= "<br></body></html>";
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_top_open_bbs_htm
{
	my $bbs_max = $RDATA->{bbs}->{max} || 100;
	my $str .= qq{
		<center>
		<table width="450" border="0" cellspacing="0" cellpadding="0"><tr><td bgcolor="#000099"> 
		<table border="0" cellspacing="1" cellpadding="2" height="100%" width="100%">
			<tr><td bgcolor="#bbbbff" align="center" class='table_top bbs_top'>
				<table><tr>
					<td><img src='$RDATA->{img_dir}/btn14_0.gif' border='0'></td>
					<td><b><font color="#000099" face="Arial, Helvetica, sans-serif" size='-1'>
						<<간단 게시판>> <br></b>
						(${bbs_max}건을 초과하면 오래된 글부터 삭제됩니다)
					</font></td>
				</tr></table>
			</tr><tr>
				<td bgcolor="#FFFFFF" class='table_bottom'><center>
				<table><tr>
					<td><b>
						게임에 로그인하면 글을 쓸 수 있습니다.
					</b></td>
				</tr></table>
				</center></td>
			</tr><tr>
				<td bgcolor="#ffffff" class='table_top bbs_bottom' align='right'>
				<input type="button" value='돌아가기' onClick='location.href="$RDATA->{home_url}"'>
				</td>
			</tr>
		</table></td></tr></table>
		</center><br>
	};
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_bbs_contribute_box_htm
{
	my ($rallu, $rsecret, $alert_str) = @_;
	my $uid = $PARAM->{UID};
	my $pid = $PARAM->{PID};
	my $bbs_max = $RDATA->{bbs}->{max} || 100;
	
	my $js = "document.sbm.CMT.value=this.form.cmt.value;";
	$js   .= "document.sbm.submit();";
	my $js2 = "document.sbm.MODE.value='bbs_sel_album';";
	$js2   .= "document.sbm.OPT.value='$uid!b';$js";
	my $js3 = "document.sbm.PID.value='';";
	$js3   .= "document.sbm.OPT.value='';$js";
	my $plant_table = qq{<input type='button' value='이미지 없음으로 변경' onClick="$js3"><br><br>}
		. get_plant_table_htm($uid, $pid, $rallu, $rsecret) if($pid);
	my @col_row = ($pid)? (25, 15): (40, 10);
	my $rpay = $RDATA->{bbs}->{pay};
	my $comment = qq{
		<br>게시판에 글을 작성하면 보유 금액이 $rpay->{max}$RDATA->{monney} 미만인 분에게는<br>
		$rpay->{span}일에 1회, 지원금 $rpay->{money}$RDATA->{monney}가 지급됩니다.
	} if($rpay);
	my $str .= qq{
			<form action="$PNAME" method="$RDATA->{method}" name="inputer" onSubmit='return false'><center>
			<table width="450" border="0" cellspacing="0" cellpadding="0"><tr><td bgcolor="#000099"> 
			<table border="0" cellspacing="1" cellpadding="2" height="100%" width="100%">
			<tr><td bgcolor="#bbbbff" align="center" class='table_top bbs_top'>
				<table><tr>
					<td><img src='$RDATA->{img_dir}/btn14_0.gif' border='0'></td>
					<td><b><font color="#000099" face="Arial, Helvetica, sans-serif" size='-1'>
					<<간단 게시판>><br></b>
					 (${bbs_max}건을 초과하면 오래된 글부터 삭제됩니다)
					$comment
					</font></b></td>
				</tr></table>
			</td></tr><tr>
				<td bgcolor="#FFFFFF" class='table_bottom'><center>
				<font color='red'><b>$alert_str</b></font>
				<table><tr>
					<td>
						$plant_table</td>
					<td valign='top'>
						<table border="0" cellspacing="3" cellpadding="2">
						<tr> 
							<td align="left">
								<input type='button' value='식물 이미지 첨부/변경' onClick="$js2"></td>
						</tr><tr>
							<td>
								<b><font size="2" face="Times New Roman, Times, serif">내용(영문 기준 800자까지)</font></b>
							</td>
						</tr><tr>
							<td><textarea name='cmt' cols='$col_row[0]' rows='$col_row[1]' wrap='hard'>$PARAM->{CMT}</textarea></td>
						</tr><tr> 
							<td align="center" valign="middle"> 
								<input type="button" value='== 등록 ==' onClick='$js'>
							</td>
						</tr>
						</table>
					</td>
				</tr></table>
				</center></td>
			</tr><tr>
				<td bgcolor="#ffffff" class='table_top bbs_bottom'>
					<table width='100%'><tr><td align='right'>
						<input type="button" value='돌아가기' onClick='location.href="$PNAME?UID=$uid&MODE=main"'>
					</td></tr></table>
				</td>
			</tr>

			</table></td></tr></table>
			</center></form>

			<form action="$PNAME" method="$RDATA->{method}" name="sbm"><center>
			<INPUT TYPE="hidden" NAME="MODE" value='bbs'>
			<INPUT TYPE="hidden" NAME="UID" value='$uid'>
			<INPUT TYPE="hidden" NAME="PID" value='$pid'>
			<INPUT TYPE="hidden" NAME="OPT" value='1'>
			<INPUT TYPE="hidden" NAME="CMT" value=''>
			</form>
	};
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_bbs_page_link_htm
{
	my ($bbs_cnt) = @_;
	my $uid    = $PARAM->{UID};
	my $pid    = $PARAM->{PID};
	my $mode   = $PARAM->{MODE};
	my $pag    = $PARAM->{PAGE}; $pag = 1 if($pag <= 0);
	my $pgf    = $RDATA->{bbs}->{page_format} || 10;
	my $pg_cnt = int(($bbs_cnt - 1 + $pgf) / $pgf);
	
	my $bpag = $pag - 1; my $npag = $pag + 1;
	my $bef = ($bpag == 0)?      "＜": qq{<a href='$PNAME?MODE=$mode&UID=$uid&PID=$pid&PAGE=$bpag'>＜</a>};
	my $nex = ($npag > $pg_cnt)? "＞": qq{<a href='$PNAME?MODE=$mode&UID=$uid&PID=$pid&PAGE=$npag'>＞</a>};
	my $str = qq{
		<font color='#002200' size='-1'><b>합계$pg_cnt페이지：</b>
		$bef&nbsp;
	};
	for(my $pg = 1; $pg <= $pg_cnt; $pg++) {
		$str .= ($pg != $pag)? qq{
			<a href='$PNAME?MODE=$mode&UID=$uid&PID=$pid&PAGE=$pg'>$pg</a>&nbsp;
		}: "<b><font color='#aa0000'>$pg</font></b>&nbsp;";
	}
	$str .= qq{
		$nex
		</font>
	};
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:1받은 메일, 2보낸 메일
###################################################
sub get_bbs_table_htm
{
	my ($rbbs, $rallu, $rsecret) = @_;
	my $uid    = $PARAM->{UID};
	my $pag    = $PARAM->{PAGE}; $pag = 1 if($pag <= 0);
	my $cnt    = @$rbbs;
	my $pgf    = $RDATA->{bbs}->{page_format} || 10;

	my $time = time;
	my $back = ($PARAM->{MODE} eq "bbs")?
		"$PNAME?UID=$uid&MODE=main": $RDATA->{home_url};
	
	my $page_str = get_bbs_page_link_htm($cnt);
	my $bbs_str .= qq{
		<tr bgcolor="#cceeff" class='table_top'>
			<th nowrap>
				<table width='100%'><tr>
					<td>$page_str</td>
				</tr></table>
			</th>
		</tr>
	};
	
	for(my $bbs_cnt = ($pag - 1) * $pgf; $bbs_cnt < $pag * $pgf; $bbs_cnt ++) {
		if(!defined($rbbs->[$bbs_cnt])) {last;}
		my ($bbsid, $stime, $suid, $spid, $comment) = @{$rbbs->[$bbs_cnt]};
		my $uname = ($rallu->{"$suid"}->[1])? 
			qq{<b><a href='$PNAME?OPT=$suid!a&MODE=album&BT=1'>
			$rallu->{"$suid"}->[1]</a></b>}: "<font color='red'><b>(탈퇴한 사용자)</b></font>";
		my $del_button = qq{<input type='button' value='삭제' onClick='if(confirm("이 글을 삭제하시겠습니까?")) location.href="$PNAME?UID=$uid&MODE=bbs&OPT=3!$bbsid"'>} if($suid == $uid);
		
		my $plant_table = get_plant_table_htm($suid, $spid, $rallu, $rsecret) if($spid);
		my $time_str = get_daytime_str($stime);
		$time_str .= " <font color='red'><b>New!!</b></font>" if($time - $stime <= 86400);
		$bbs_str .= qq{
			<tr bgcolor="#FFFFFF" class='table_bottom'>
				<td>
					<table><tr>
						<td colspan='2'><font size='-1'>
							($bbsid) 작성자: $uname ($time_str) $del_button
						</font></td>
					</tr><tr>
						<td width='5%'>$plant_table</td><td valign='top' width='95%'><br>
							<font size='-1'>$comment</font></td>
					</tr></table>
				</td>
			</tr>
		};
		$cnt--;
	}
	my $str = qq{
		<center><form><table width="450" border="0" cellspacing="0" cellpadding="0">
		<tr><td bgcolor="#000099"> 
		<table border="0" cellspacing="1" cellpadding="2" height="100%" width="100%">
		$bbs_str
		<tr bgcolor="#cceeff" class='table_top'>
			<td align='right'>
				<input type="button" value='돌아가기' onClick='location.href="$back"'>
			</td>
		</tr>
		</table></td></tr></table></form></center>
	};
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:1받은 메일, 2보낸 메일
###################################################
sub contributing_bbs
{
	my ($rbbs, $rallu) = @_;
	my $time = time;

	my $uid     = $PARAM->{UID};
	my $pid     = $PARAM->{PID};
	my $comment = $PARAM->{CMT};
	my $mlimit  = $RDATA->{bbs}->{limitation} || 2;

	if(!$comment) {return "내용이 없습니다.";}
	if($comment ne get_safe_htm($comment, 2)) {
		return "사용할 수 없는 문자가 포함되어 있습니다.";
	}
	if(length($comment) > 800) {
		return "글자 수가 너무 많습니다.";
	}
	$comment = get_safe_htm($comment);
	
	my $same_cnt = 0;
	my $cnt      = 0;
	my $bbsid    = 1;
	foreach (@$rbbs) {
		my ($mbbsid, $mtime, $msuid, $mspid, $mcomment) = @$_;
		
		if($time - $mtime <= 86400 && $cnt < $mlimit) {
			if($msuid == $uid) {
				if ($comment eq $mcomment) {
					return "중복 등록을 시도했습니다.";
				}
				if($mlimit && ++ $same_cnt == $mlimit) {
					return "하루 연속 등록은 ${mlimit}건까지입니다.";
				}
			}
		}
		if($bbsid <= $mbbsid) {$bbsid = $mbbsid + 1;}
			
		$cnt ++;
	}
	
	unshift(@$rbbs,  [$bbsid, $time, $uid, $pid, $comment]);
	put_bbs_data($rbbs);
	pay_bbs($rallu, $time, $uid);
	
	my $bbs_max = $RDATA->{bbs}->{max} || 100;
	if(@$rbbs > $bbs_max) {pop(@$rbbs);}
	
	return "등록했습니다";
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub pay_bbs
{
	my ($rallu, $time, $uid) = @_;
	
	if(my $rpay = $RDATA->{bbs}->{pay}) {
		my $rudata = get_status_data($uid);
	
		my $bef_time = $rallu->{"$uid"}->[14];
		if($rudata->[0]->[0] < $rpay->{max}) {
			if($bef_time + $rpay->{span} * 86400 <= $time) {
				$rudata->[0]->[0] += $rpay->{money};
				$rallu->{"$uid"}->[14] = $time;
				put_status_data($uid, $rudata);
				put_all_udata($rallu);
				put_self_history($uid,
					"게시판에 글을 작성해 주셔서 감사합니다. 식물 연구소에서 지원금 $rpay->{money}$RDATA->{monney}가 지급되었습니다.",
					"green", $time
				);
			}
		}
	}
	
	return 1;
}

###################################################
#  input:()
# retrun:
#comment:1받은 메일, 2보낸 메일
###################################################
sub delete_bbs
{
	my ($rbbs) = @_;
	my $time = time;

	my $uid     = $PARAM->{UID};
	my $bbsid   = (split(/!/, $PARAM->{OPT}))[1];
	my $bbs_cnt = @$rbbs;
	
	for(my $cnt = 0; $cnt < $bbs_cnt; $cnt ++) {
		my ($mbbsid, $mtime, $msuid, $mspid, $mcomment) = @{$rbbs->[$cnt]};
		if($mbbsid == $bbsid) {
			if($msuid != $uid) {
				return "다른 사람의 글은 삭제할 수 없습니다";
			}
			
			splice(@$rbbs, $cnt, 1);
			put_bbs_data($rbbs);
			
			return "글을 삭제했습니다";
		}
	}
	
	return "글을 삭제할 수 없습니다";
}

###################################################
#  input:()
# retrun:
#comment:1받은 메일, 2보낸 메일 잠금되어 있습니다
###################################################
sub get_mail_htm
{
	my $alert_str;
	my $uid  = $PARAM->{UID};
	my $rallu = get_all_udata_hash();

	my ($type, $op_id) = split(/!/, $PARAM->{OPT});

	my $rmail = get_mail_data($uid);
	if($type == 4) {
		$alert_str = sending_mail($rmail, $uid);	#rmail은 변경됩니다.
		if(!$alert_str) {
			my ($uname, $suname) = ($rallu->{"$uid"}->[1], $rallu->{"$op_id"}->[1]);
			$alert_str = qq{$suname님에게 메일을 보냈습니다};
			if($uid != $op_id) {#일단 자신에게 보낸 경우 알림 없이 변경했습니다.
				put_self_history($uid, $alert_str, "black");
				put_self_history($op_id, qq{$uname님에게서 메일이 도착했습니다}, "blue");
				if(rand() < 0) {
					put_whole_history("$uname님과 $suname님이 매우 친하다는 소문이 돌고 있습니다.", "pink");
				}
			}
		}
	}
	my $mail_comment = "
		<br>같은 사용자에게 하루에 보낼 수 있는 메일은 $RDATA->{mail_limitation}통까지입니다.
		단, 상대가 보낸 메일을 삭제하면 추가로 보낼 수 있습니다.
	" if($RDATA->{mail_limitation});
	
	my $str = "Content-type: text/html\n\n";
	$str .= qq{<html><head>};
	$str .= get_head();
	$str .= get_mail_js();
	$str .= qq{
		<title>메일 화면</title>
		</head>
		<body bgcolor='#d1f8d8' background='' onLoad=''>
			<a name='to_top'></a>
			<center><img src='$RDATA->{img_dir}/inc_plant.gif' border='0'></center>
			<form action="$PNAME" method="$RDATA->{method}" name="inputer" onSubmit='return false'><center>
			<table width="450" border="0" cellspacing="0" cellpadding="0"><tr><td bgcolor="#000099"> 
			<table border="0" cellspacing="1" cellpadding="2" height="100%" width="100%">
			<tr><td bgcolor="#bbbbff" align="center" class='table_top mail_top'>
				<table><tr>
					<td><img src='$RDATA->{img_dir}/btn15_0.gif' border='0'></td>
					<td><b><font color="#000099" face="Arial, Helvetica, sans-serif" size='-1'>
					<<간단 메일>></b><br>
					(100통을 초과하면 오래된 메일부터 삭제됩니다)
					$mail_comment
					</font></b></td>
				</tr></table>
			</td></tr>
			<tr><td bgcolor="#FFFFFF" class='table_bottom'> 
				<center>
				<table border="0" cellspacing="3" cellpadding="2">
					<tr><td ALIGN="left">
						<font face="Times New Roman, Times, serif" size="2"><b>받는 사람</b></font>
						<SELECT SIZE="1" name='UID'>
						<OPTION VALUE="0"> ---
	};
	$str .= get_selector($uid, $rallu);
	$str .= qq{
							</SELECT>
						<font size='-1'>←받는 사람을 잘못 선택하지 않도록 주의하세요!</font></td>
					</tr><tr> 
						<td align="left"> 
							<b><font size="2" face="Times New Roman, Times, serif">내용</font></b>
							<INPUT TYPE="text" NAME="COMMENT" SIZE="50" MAXLENGTH="256" value=''></td>
					</tr><tr> 
						<td colspan='4' ALIGN="center" valign="middle"> 
							<input type="button" value='송수신함' onClick='location.href="$PNAME?UID=$uid&MODE=mail&OPT=3"'>
							<input type="button" value='받은 편지함' onClick='location.href="$PNAME?UID=$uid&MODE=mail&OPT=1"'>
							<input type="button" value='보낸 편지함' onClick='location.href="$PNAME?UID=$uid&MODE=mail&OPT=2"'>
							<input type="button" value='== 보낸 메일 ==' onClick='send_mail()'>
						</td>
					</tr>
				</table></center></td>
			</tr><tr><td bgcolor="#ffffff" class='table_top mail_bottom'>
					<table width='100%'><tr><td align='center'>
						<font color='red'><b>$alert_str</b></font>
					</td><td align='right'>
						<input type="button" value='돌아가기' onClick='location.href="$PNAME?UID=$uid&MODE=main"'>
					</td></tr></table>
				</td>
			</tr>
			</table></td></tr></table>
			</center></form>

			<form action="$PNAME" method="$RDATA->{method}" name="sender"><center>
			<INPUT TYPE="hidden" NAME="MODE" value='mail'>
			<INPUT TYPE="hidden" NAME="UID" value='$uid'>
			<INPUT TYPE="hidden" NAME="OPT" value=''>
			</form>
	};
	if($type == 5) {
		my $mail_cnt = @$rmail;
		if($mail_cnt - $op_id >= 0) {
			splice(@$rmail, $mail_cnt - $op_id, 1);
			put_mail_data($uid, $rmail);
		}
	}
	if($type) {$str .= get_mail_table_htm($type, $rmail, $rallu);}
	$str .= get_copyright();
	$str .= "<br></body></html>";
	
	if($type == 1 || $type == 3) {put_off_mail($uid, $rmail);}
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_selector
{
	my ($uid, $rallu) = @_;
	my ($str, %ucheck);
	my ($type, $op_id) = split(/!/, $PARAM->{OPT});
	
	my $rsort = get_mail_sort_data($uid);
	foreach (@$rsort) {
		if($rallu->{"$_"}) {
			my $suname = $rallu->{"$_"}->[1];
			my $selected = "selected" if($_ == $op_id);
			$str .= qq{<option value="$_" $selected> $suname\n};
			$ucheck{"$_"} = 1;
		}
	}
	foreach (values(%$rallu)) {
		my ($suid, $suname) = @$_;
		if($ucheck{"$suid"}) {next;}
		my $selected = "selected" if($suid == $op_id);
		$str .= qq{<option value="$suid" $selected> $suname\n};
	}
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:1받은 메일, 2보낸 메일
###################################################
sub put_off_mail
{
	my ($uid, $rmail) = @_;
	
	foreach (@$rmail) {
		$_->[4] = 0;
	}
	put_mail_data($uid, $rmail);
	
	return 1;
}

###################################################
#  input:()
# retrun:
#comment:1받은 메일, 2보낸 메일
###################################################
sub get_mail_table_htm
{
	my ($type, $rmail, $rallu) = @_;
	my $uid  = $PARAM->{UID};
	my $mail_str .= qq{
		<tr bgcolor="#cceeff" class='table_top'><th>&nbsp;</th>
			<th nowrap><font size='-1'>송수신</font></th>
			<th nowrap><font size='-1'>시간</font></th>
			<th nowrap><font size='-1'>이름</font></th>
			<th nowrap><font size='-1'>내용</font></th>
			<th nowrap><font size='-1'>새 메일</font></th>
			<th nowrap><font size='-1'>삭제</font></th></tr>
	};
	
	my $cnt = @$rmail; $cnt = 100 if($cnt > 100);
	foreach (@$rmail) {
		my ($typ, $time, $suid, $comment, $new_flg) = @$_;
		my $uname = $rallu->{"$suid"}->[1] || "<font color='red'>(탈퇴한 사용자)</font>";
		if($typ == 2 && ($type == 2 || $type >= 3)) {
			my $time_str = get_time_str($time);
			$mail_str .= qq{
				<tr bgcolor="#FFFFFF" class='table_bottom'>
					<td nowrap><font size='-1'>$cnt</font></td>
					<td><font size='-1'>보낸 메일</font></td>
					<td><font size='-1'>$time_str</font></td>
					<td><font size='-1'>$uname</font></td>
					<td><font size='-1'>$comment</font></td>
					<td>&nbsp;</td>
					<td><input type="button" value="삭제" onClick='if(confirm("이 메일을 삭제하시겠습니까?")) location.href="$PNAME?UID=$uid&MODE=mail&OPT=5!$cnt"'>
					</td></tr>
			};
		}
		if($typ == 1 && ($type == 1 || $type >= 3)) {
			my $time_str = get_time_str($time);
			my $get_str  = ($new_flg)? "새 메일": "&nbsp;";
			my $button   = qq{<input type="button" value="답장" onClick='select_user($suid)'>}
				if($rallu->{"$suid"}->[1]);
			$mail_str .= qq{
				<tr bgcolor="#FFFFFF" class='table_bottom'>
					<td nowrap><b><font size='-1'>$cnt</font></b></td>
					<td><b><font size='-1'>받은 메일</font></b></td>
					<td><b><font size='-1'>$time_str</font></b></td>
					<td><b><font size='-1'>$uname</font></b><br>$button</td>
					<td><b><font size='-1'>$comment</font></b></td>
					<td><b><font size='-1'>$get_str</font></b></td>
					<td><input type="button" value="삭제" onClick='if(confirm("이 메일을 삭제하시겠습니까?")) location.href="$PNAME?UID=$uid&MODE=mail&OPT=5!$cnt"'></td>
				</tr>
			};
		}
		if(--$cnt == 0) {last;}
	}
	my $str = qq{
		<center><table width="450" border="0" cellspacing="0" cellpadding="0"><tr><td bgcolor="#000099"> 
		<form><table border="0" cellspacing="1" cellpadding="2" height="100%" width="100%">
		$mail_str
		</table></td></tr></table></form></center>
	};
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:1받은 메일, 2보낸 메일
###################################################
sub sending_mail
{
	my ($rmail, $uid) = @_;
	my $time = time;

	my ($suid, $comment) = (split(/!/, $PARAM->{OPT}))[1, 2];
	$comment = get_safe_htm($comment);
	
	my $rsmail = ($uid == $suid)? $rmail: get_mail_data($suid);
	my $same_cnt = 0;
	
	foreach (@$rsmail) {
		my ($mtyp, $mtime, $msuid, $mcomment) = @$_;
		if($time - $mtime > 86400) {last;}
		if($mtyp == 1) {
			if($msuid == $uid && $uid != $suid) {
				if ($comment eq $mcomment) {
					return "같은 메일을 보내려고 했습니다.";
				}
				my $mlimit = $RDATA->{mail_limitation};
				if($mlimit && ++ $same_cnt == $mlimit) {
					return "같은 사용자에게 보낼 수 있는 메일은 하루 ${mlimit}통까지입니다";
				}
			}
		}
	}
	
	unshift(@$rmail,  [2, $time, $suid, $comment]);
	unshift(@$rsmail, [1, $time, $uid,  $comment, 1]);
	put_mail_data($uid,  $rmail);
	put_mail_data($suid, $rsmail);
	
	my $rsort = get_mail_sort_data($uid);
	unshift(@$rsort, $suid);
	put_mail_sort_data($uid, $rsort);
	
	return undef;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_score_table_htm
{
	my $uprop;
	my $opt = $PARAM->{OPT};
	
	if($opt =~ /p/)    {$uprop = get_all_user_property();}
	elsif($opt =~ /c/) {$uprop = get_all_user_collection();}
	elsif($opt =~ /f/) {$uprop = get_all_popular_plant();}
	elsif($opt =~ /o/) {$uprop = get_all_user_flower_collection();}
	elsif($opt =~ /a/) {$uprop = get_all_pure_collector();}
	else               {$uprop = get_all_plant_score();}
	
	my $str = "Content-type: text/html\n\n";
	$str .= qq{<html><head>};
	$str .= get_head();
	$str .= qq{
		<title>순위표</title>
		</head>
		<body bgcolor='#d1f8d8' background='' onLoad=''>
			<center><img src='$RDATA->{img_dir}/inc_plant.gif' border='0'></center>
			<form action="$PNAME" method="$RDATA->{method}" name="inputer"><center>
			<table width="450" border="0" cellspacing="0" cellpadding="0"><tr><td bgcolor="#000099"> 
			<table border="0" cellspacing="1" cellpadding="2" height="100%" width="100%">
				<tr><td bgcolor="#bbbbff" colspan='3' class='table_top score_top'>
					<table width='100%'><tr><td align='left'>
						<font color='blue'><b>$uprop->[0](순위표)</b></font>
					</td><td align='right'>
						<input type="button" value='돌아가기' onClick='history.back()'>
					</td></tr></table>
				</td></tr>
	};
	$str .= qq{<tr><td bgcolor="#bbbbff" align="center" class='table_top score_sbj'>};
	$str .= join("</td><td bgcolor='#bbbbff' align='center' class='table_top score_sbj'>", @{$uprop->[1]});
	$str .= qq{</td></tr>\n};
	foreach (@{$uprop->[2]}) {
		my $suid = shift(@$_);
		$str .= qq{<tr bgcolor='#ffffff' class='table_bottom'><td align="center">};
#		if($PARAM->{UID} == $suid) {
#			$str .= "<b><font color='red'>";
#			$str .= join("</font></b></td><td align='center'><b><font color='red'>", @$_);
#			$str .= "</font></b>\n";
#		} else {
			$str .= join("</td><td align='center'>", @$_);
#		}
		$str .= qq{</td></tr>\n};
	}
	$str .= qq{
			</table></td></tr></table>
			</center></form>
	};
	$str .= get_copyright();
	$str .= "<br></body></html>";
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_regist_htm
{
	my $str;
	
	my $rudata = get_all_udata();
	if(@$rudata < $RDATA->{max_user}) {
		my $ndata = get_regist_err_html();
		my $uname_reged = get_uname_reged($rudata);

		if(defined($uname_reged)) {
			$str = get_start_htm($RDATA->{mlutireg_warn}, $uname_reged);
		} elsif(defined($ndata)) {
			$str = get_usr_registration_htm($ndata);
		} else {
			my $ses_id = get_new_session_id();
			write_regist_user($ses_id);
		
			my $uid = get_uid_from_uname($PARAM->{NAM});
			my $str_t = get_main_htm($uid);
			$str = "Set-Cookie: UCK=$uid\@$ses_id\n" . $str_t;	#cookie 설정
		}
	} else {
		$str = get_start_htm();
	}
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_login_htm
{
	my $str;
	my $pass = $PARAM->{PWD};

	my $rudt  = get_uid_from_namepass($PARAM->{NAM}, $pass);
	my ($uid, $ses_id) = @$rudt;
	
	if(!defined($uid)) {
		$str = get_start_htm("사용자명 또는 비밀번호가 올바르지 않습니다");
#	} elsif($PARAM->{OPT} eq "change") {
#		my $str_t = get_usr_registration_change_htm($uid);
#		$str = "Set-Cookie: UCK=$pass\n" . $str_t;	#cookie 설정
	} else {
		my $str_t = get_main_htm($uid);
		$str = "Set-Cookie: UCK=$uid\@$ses_id\n" . $str_t;	#cookie 설정
	}
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_const_htm
{
	my $uid = $PARAM->{UID};
	my $str;
	
	$str = get_main_htm($uid);

	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_into_album_htm
{
	my $uid = $PARAM->{UID};
	my $pid = $PARAM->{PID};

	my $rplant = get_plant_data($uid);
	my $rp = $rplant->{"$pid"};
	
	# 꽃 상태에서만 앨범에 보관할 수 있으므로
	if($rp->[5] == 5) {
		$rp->[25] = time;
		change_to_album($rp, $uid);
		$rp->[5] = 6;
		$rp->[4] = 0;
		put_plant_data($uid, $rplant);
	}
	
	my $str = get_main_htm($uid);
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_pollination_htm
{
	my ($alert_str, @suids);
	my $uid = $PARAM->{UID};
	my $pid = $PARAM->{PID};
	my $time = time;
	my $uname = ($uid == 1)? "플라워 팜": get_uname($uid);

	my $str = "Content-type: text/html\n\n";
	$str .= qq{<html><head>};
	$str .= get_head();
	$str .= get_hpb_js();
	$str .= qq{
		<title>수분 작업</title>
		</head>
		<body bgcolor='#d1f8d8' background='' onLoad=''>
		<form name='plant'><center>
		<table border='0' cellpadding='0' cellspacing='0' bgcolor='#dddddd'>
	};
	my $rplant = get_plant_data($uid);
	my $rdata = $rplant->{"$pid"};
	my ($rcreature, $grow_step, $place) = (@$rdata)[3, 5, 15];
	if($grow_step != 5) {
		error_end(__LINE__, "잘못된 수분 작업이 시도되었습니다", "pollination error");
		exit 1;
	}
	my $pname = $rdata->[1];
	my $bgcol  = get_time_bgcol($time, $place);
	$str .= qq{
		<tr><td><table width="225" border="0" cellspacing="0" cellpadding="0">
		<tr><td bgcolor="#008800"> 
		<table border="0" cellspacing="1" cellpadding="2" height="100%" width="100%">
			<tr><td bgcolor="#bbffbb" align="center" class='table_top flower_top'>
				<b><font color="#003300" face="Arial, Helvetica, sans-serif">$uname님의<br>
				$pname</font></b>
			</td></tr><tr><td bgcolor="#FFFFFF" align="center" class='table_bottom'>
				<table><tr><td colspan='3' align='center'>
	};
	$str .= get_flower_img_htm($uid, $pid, $rdata->[5], "bgcolor='$bgcol'");
	$str .= qq{
			</td><td rowspan='2' valign='top' nowrap>
				<b><font size='-1'>교배료：$RDATA->{plli_plice}$RDATA->{monney}</font></b><br>
	};
	my $pure_flg = defined(get_represent_flower($rcreature));
	my $rstat  = get_flower_status_data($rcreature);
	$str .= get_flower_status($rstat) . "<hr>\n";

	my $rudata = get_status_data($uid);
	if(defined($PARAM->{OPT})) {
		my $polled_flg;
		# $rudata 데이터가 갱신되고 seed.cgi에 기록됩니다.
		my $ralert = get_pollination_alert($uid, $rudata);
		($alert_str, $polled_flg) = @$ralert;
		put_status_data($uid, $rudata) if($polled_flg);
	}
	my $seed_rest = $rudata->[0]->[6] - $rudata->[0]->[5];

	my $href1 = "$PNAME?MODE=pollination&UID=$uid&PID=$pid&OPT=$uid!$pid";
	my $href2 = "$PNAME?OPT=!p&UID=$uid&MODE=album&PID=$pid";
	my $href3 = "$PNAME?MODE=server_select&NAM=$uname&UID=$uid&PID=$pid";
	my $outer = qq{
		<br><input type ="button" value='다른 필드' onClick='location.href="$href3"'>
	} if(-e "$RDATA->{data_dir}/server.cgi");
#	$str .= qq{<hr><font size='-1'>교배료: $rdata->[24]/$rdata->[23]</font><br><br>\n};
	$str .= ($seed_rest > 0)? qq{
					<font size='-1'><b>아래 버튼에서<br>수분 작업을 진행합니다</b><br>
						앞으로${seed_rest}개의 씨앗을 얻을 수 있습니다</font>
				<br><input type='button' value='자가 수분하기' onClick='if(confirm("자가 수분으로 씨앗을 얻겠습니까?")) location.href="$href1"'>
				<br><input type="button" value='앨범에서 선택' onClick='location.href="$href2"'>
				$outer
	}: qq{<font color='red' size='-1'><b>더 이상<br>씨앗을 보유할 수 없습니다.</b></font>};
	$str .= qq{
				</td></tr></table>
			</td></tr>
		</table></td></tr></table></td></tr>
		</table></center></form>
	};

	
	$str .= get_ustatus_htm($uid, $rudata, $alert_str, {property => 1});
	$str .= get_copyright();
	$str .= "<br></body></html>";
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_pollination_alert
{
	my ($uid, $rudata) = @_;
	my ($alert_str);
	my $polled_flg = 0;
	my $pid = $PARAM->{PID};
	my ($suid, $spid) = split(/!/, $PARAM->{OPT});
	my $rsplant = get_album_data($suid);
	$rsplant    = get_plant_data($suid) if(!defined($rsplant->{"$spid"}));
	my ($spname, $def_seed_cost) = (@{$rsplant->{"$spid"}})[1, 24];
	my $seed_cost = ($uid == $suid)? $RDATA->{plli_plice}: $def_seed_cost;

	my $rstatus = $rudata->[0];
	my $monney = $rstatus->[0];
	if($monney < $seed_cost) {
		$alert_str = "교배료($seed_cost$RDATA->{monney})를 지불할 수 없습니다";
	} elsif($rstatus->[5] >= $rstatus->[6]) {
		$alert_str = "더 이상 씨앗을 가질 수 없습니다";
	} else {
		$polled_flg = 1;
		if($uid != $suid && $suid != 0) {
			write_new_popflower($suid, $spid);
			my $uname  = get_uname($uid);
			my $rsudata = get_status_data($suid);
			$rsudata->[0]->[0] += $seed_cost;
			put_self_history($suid,
				"$uname님에게서 $spname에게 지급된 교배료 $seed_cost$RDATA->{monney}를 받았습니다", "green");
			put_status_data($suid, $rsudata);
		}
		$rstatus->[0] -= $seed_cost;
		if(my $rnew_dna = get_new_dna($uid, $pid, $suid, $spid)) {
			$rstatus->[5]++;
			my $new_pid = ++$rstatus->[4];
			my $rseed = get_seed_data($uid);
			$rseed->{"$new_pid"} = [$new_pid, 0, "새 식물($new_pid)",
				@$rnew_dna, $uid, $suid, $pid, $spid];
			put_seed_data($uid, $rseed);
#			put_self_history($uid, "새 씨앗을 얻었습니다", "green");
			$alert_str = "수분에 성공하여 씨앗을 얻었습니다.";
		} else {
			$alert_str = "수분에 실패했습니다";
		}
	}
	
	return [$alert_str, $polled_flg];
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub write_new_popflower
{
	my ($uid, $pid) = @_;

	my $rpop = get_popular_flower();
	unshift(@$rpop, [$uid, $pid]);
	put_popular_flower($rpop);
	
	return 1;
}

###################################################
#  input:()
# retrun:
#comment: 사용자 등록 시 초기화 처리
###################################################
sub write_regist_user
{
	my ($ses_id) = @_;
	my $name = get_safe_htm($PARAM->{NAM});
	my $pwd  = get_safe_htm($PARAM->{PWD});
	my $ken  = get_safe_htm($PARAM->{KEN});
	my $sex  = get_safe_htm($PARAM->{SEX});
	my $hp   = get_safe_htm($PARAM->{HP});
	my $mail = get_safe_htm($PARAM->{MAIL});
	my $opn  = ($PARAM->{OPN})? 1: 0;
	
	my ($time, $localtime) = (time, join(",", localtime));
	my ($uid, $nid) = get_new_uid();
	my $init_cash = $RDATA->{init_cash} || get_init_cash();
	my $album_max = $RDATA->{album_max}->[0] || 100;
	my $dna1      = get_rundom_dna();
	my $dna2      = $dna1;
#	my $dna2      = get_rundom_dna();
	my $total     = get_flower_total($dna1, $dna2);
	#plantID,이름,심은 시각,null,성장 레벨,성장 단계,빛과 온도,초,확인한 초,
	#수분,초,검사한초,영양,초,검사한초,위치,유전자1,유전자2,total
	my $rdata = [1, "새 식물(1)", $time, "null", 0, 0, 8, $time, $time, 
		8, $time, $time, 8, $time, $time, 2, $dna1, $dna2, $total];
	
	mkdir("$RDATA->{data_dir}/u$uid", 0755);
	mkdir("$RDATA->{album_img}/u$uid", 0755);
	open(SEED, ">$RDATA->{data_dir}/u$uid/seed.cgi")
		|| error_end(__LINE__, "파일 오류", $!);
	close(SEED) || error_end(__LINE__, "파일 오류", $!);
	open(ALBUM, ">$RDATA->{data_dir}/u$uid/album.cgi")
		|| error_end(__LINE__, "파일 오류", $!);
	close(ALBUM) || error_end(__LINE__, "파일 오류", $!);
	open(MAIL, ">$RDATA->{data_dir}/u$uid/mail.cgi")
		|| error_end(__LINE__, "파일 오류", $!);
	close(MAIL) || error_end(__LINE__, "파일 오류", $!);
	open(UDT, ">$RDATA->{data_dir}/u$uid/status.cgi")
		|| error_end(__LINE__, "파일 오류", $!);
	#금액,등록 초,등록 시간,등급,꽃 수(total),보유 종자 수,max_flower_num
	print UDT "$init_cash\t$time\t$localtime\t0\t1\t0\t2\t\t1\t\t$album_max\t0\t0\n";
#	print UDT "\t" x 100 . "\n";
	close(UDT) || error_end(__LINE__, "파일 오류", $!);
	open(PLANT, ">$RDATA->{data_dir}/u$uid/plant.cgi")
		|| error_end(__LINE__, "파일 오류", $!);
	print PLANT join("\t", @$rdata) . "\n";
	close(PLANT) || error_end(__LINE__, "파일 오류", $!);

	put_self_history($uid, "햇빛 게이지가 내려가면 설치 위치를 옮겨 주세요");
	put_self_history($uid, "가끔은 위치를 옮겨 주변 환경을 바꿔 주는 것도 필요합니다");
	put_self_history($uid, "햇빛 게이지는 처음에 위치를 집 밖으로 해 두면 올라갑니다");
	put_self_history($uid, "물과 비료를 주어 게이지를 파란 범위로 유지하세요");
	#	put_self_history($uid, "잘 키우면 하루 만에 싹이 나고 일주일이면 꽃이 핍니다");
	make_flower_gif($uid, $rdata);
	put_whole_history("$PARAM->{NAM}님이 새 꽃을 키우기 시작했습니다", "blue");

	open(USER, ">>$RDATA->{data_dir}/user.cgi") || error_end(__LINE__, "파일 오류", $!);
	print USER "$uid\t$name\t$pwd\t$hp\t$mail\t$sex\t$ken\t$ENV{'REMOTE_ADDR'}\t$time\t$opn\t$nid\t\t\t\t\t$ses_id\n";
	close(USER) || error_end(__LINE__, "파일 오류", $!);

	return 1;
}

###################################################
#  input:()
# retrun:
#comment: v1.6 이전 버전과의 호환성을 위한 처리
###################################################
sub get_init_cash
{
	my $rinit_d = inc_plant_conf::get_init_udata();
	
	return $rinit_d->{cash};
}

###################################################
#  input:()
# retrun:
#comment: 사용자 삭제 처리
###################################################
sub delete_regist_user
{
	my ($uid) = @_;

	delete_popflower($uid);
	delete_pure_data_from_uid($uid);
	delete_bbs_from_uid($uid) if($RDATA->{del_bbs});
	
	my $param;
	$param = "$RDATA->{data_dir}/u$uid";
	unlink(<$param/*>);
	$param = "$RDATA->{album_img}/u$uid";
	unlink(<$param/*>);
	
	rmdir("$RDATA->{data_dir}/u$uid");
	rmdir("$RDATA->{album_img}/u$uid");
	
	return 1;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub delete_popflower
{
	my ($uid) = @_;
	my @new_pop;
	
	my $rpop = get_popular_flower();
	foreach (@$rpop) {
		if((split(/,/, $_))[0] != $uid) {
			push(@new_pop, $_);
		}
	}
	put_popular_flower(\@new_pop);
	
	return 1;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub delete_bbs_from_uid
{
	my ($uid) = @_;
	my @new_bbs;
	
	my $rbbs = get_bbs_data();
	foreach (@$rbbs) {
		if($_->[2] != $uid) {
			push(@new_bbs, $_);
		}
	}
	put_bbs_data(\@new_bbs);
	
	return 1;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_rundom_dna
{
	my $rdnas = get_dna_data();
	my $dna_reg_cnt = @$rdnas;
	my $seed_max = $RDATA->{init_dna_cnt} || $dna_reg_cnt;

	my $dna_type = int(rand() * $seed_max);

	return $rdnas->[$dna_type]->[0];
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_dna_data
{
	my @dnas;
	
	open(DNA, "$RDATA->{sys_dir}/dna.cgi")
		|| error_end(__LINE__, "파일 오류", $!);
	while(chomp(my $line = <DNA>)) {
		$line =~ s/ //g; if(!$line) {next;}
		push(@dnas, [(split(/\t/, $line))]);
	}
	close(DNA) || error_end(__LINE__, "파일 오류", $!);
	
	return \@dnas;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub make_flower_shop
{
	my $rdnas = get_dna_data();

	mkdir("$RDATA->{album_img}/u1", 0755) if(!(-e "$RDATA->{album_img}/u1"));
	my $all_new_flg = (-e "$RDATA->{data_dir}/u1/album.cgi")? 0: 1;
	if($all_new_flg) {
		mkdir("$RDATA->{data_dir}/u1", 0755);
		open(PLANT, ">$RDATA->{data_dir}/u1/plant.cgi")
			|| error_end(__LINE__, "파일 오류", $!);
		close(PLANT);
		open(UDT, ">$RDATA->{data_dir}/u1/status.cgi")
			|| error_end(__LINE__, "파일 오류", $!);
		close(OUT);
	}
	open(ALBUM, ">$RDATA->{data_dir}/u1/album.cgi")
		|| error_end(__LINE__, "파일 오류", $!);
	for(my $cnt = 0; $cnt < @$rdnas; $cnt++) {
		my ($dna, $name, $open) = @{$rdnas->[$cnt]};
		if($open eq "N") {next;}
		my @dt;
		@dt[0, 1, 5, 16, 17] = ($cnt, $name, 5, $dna, $dna);
		$dt[3] = get_expression_data($dna, $dna);
		my $seed_cost = get_seed_cost_from_rdata(\@dt);
		@dt[23, 24] = ($seed_cost, $seed_cost);
		print ALBUM join("\t", @dt) . "\n";
		make_flower_gif(1, \@dt);
	}
	close(ALBUM) || error_end(__LINE__, "파일 오류", $!);

	return 1;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_pedia_htm
{
	if($RDATA->{pedia_url}) {return get_start_htm();}
	my $uid = $PARAM->{UID};
	
	my $rep_data = get_represent_data();
	my $pure_cnt = @$rep_data;
	make_pure_image($rep_data);	#순계 식물 이미지 준비
	my $pag = $PARAM->{PAGE}; $pag = 0 if($pag <= 0);
	
	my $str = "Content-type: text/html\n\n";
	$str .= qq{<html><head>};
	$str .= get_head();
	$str .= qq{
		<title>순계 식물 도감</title>
		</head>
		<body bgcolor='#d1f8d8' background='' onLoad=''>
			<center>
			<img src='$RDATA->{img_dir}/zukan_ttl.gif' border='0'>
			</center><br><br>
			<form><center>
			<table border="0" cellspacing="0" cellpadding="0"><tr><td bgcolor="black">
			<table border="0" cellspacing="1" cellpadding="2" height="100%" width="100%">
			<tr><td colspan='2' bgcolor='white' class='table_top'>
				<table width='100%'><tr><td>
					<img src='$RDATA->{img_dir}/btn01_0.gif' border='0'></td><td>
	};
	$str .= get_pedia_page_link_htm($pure_cnt);
	my $back_url = defined($uid)? "$PNAME?MODE=main&UID=$uid": $RDATA->{home_url};
	$str .= qq{
				</td><td align='right'>
					<input type='button' value=' 돌아가기 ' onClick="location.href='$back_url'">
				</td></tr></table>
			</td></tr><tr>
	};
	if($pag == 0) {
		$str .= "
			<td height='400' align='center' valign='top' bgcolor='#eeeeaa' class='table_bottom pedia_front'>
		";
		$str .= get_plant_statistics_htm();
		$str .= "</td>\n";
	} else {
		my $rpunum = get_pure_number_data();
		for(my $rep_id = ($pag - 1) * 4; $rep_id < $pag * 4; $rep_id++) {
			$str .= qq{<td width='325' bgcolor='white' class='table_bottom pedia_main'><table>}
				if($rep_id % 2 == 0);
				
			$str .= qq{<tr><td height='200'>\n};
			$str .= get_one_pure_htm($rep_data, $rep_id, $rpunum->[$rep_id])
				if($rep_id < $pure_cnt);
			
			$str .= qq{</td></tr>\n};
			$str .= qq{</table></td>} if($rep_id % 2 == 1);
		}
	}
	$str .= qq{</tr></table></td></tr></table></center></form>\n};
	$str .= get_copyright();
	$str .= "<br></body></html>";
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_plant_statistics_htm
{
	my $rstat  = get_plant_dna_statistics();
	my $str .= qq{
		<table><tr><td bgcolor='green'><hr>
			<font size='+3' color='#cccccc'><b>&nbsp;&nbsp;순계 식물 도감&nbsp;&nbsp;</b></font>
		<hr></td></tr></table><br>
		<img src="$RDATA->{img_dir}/hatena.gif" height='200' width='100' border='2'>
		<br><hr width='85%' size='2' color='red'>
		<table valign='bottom'>
			<tr><th colspan='6'><font size='-1'>현재 이 <font color='brown'>필드</font>
					에서 발견된 식물</font></th></tr>
			<tr><th><font size='-1'>순계식물</font></th>
				<th align='right'><font size='-1' color='red'>$rstat->[4]</font></th>
				<th><font size='-1'>씨앗종류, </font></th>
				<th><font size='-1'>비밀유전자</font></th>
				<th align='right'><font size='-1' color='red'>$rstat->[3]</font></th>
				<th><font size='-1'>씨앗종류, </font></th></tr>
			<tr><th><font size='-1'>꽃 씨앗류</font></th>
				<th align='right'><font size='-1' color='red'>$rstat->[2]</font></th>
				<th><font size='-1'>씨앗종류, </font></th>
				<th><font size='-1'>잎 씨앗류</font></th>
				<th align='right'><font size='-1' color='red'>$rstat->[1]</font></th>
				<th><font size='-1'>씨앗종류, </font></th></tr>
			<tr><th><font size='-1'>줄기 씨앗류</font></th>
				<th align='right'><font size='-1' color='red'>$rstat->[0]</font></th>
				<th><font size='-1'>씨앗종류.</font></th></tr>
		</table>
		<hr width='85%' size='2' color='red'>
	};
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_pedia_page_link_htm
{
	my ($pure_cnt) = @_;
	my $uid    = $PARAM->{UID};
	my $pag    = $PARAM->{PAGE}; $pag = 0 if($pag <= 0);
	my $pgf    = $RDATA->{bbs}->{page_format} || 10;
	my $pg_cnt = int(($pure_cnt + 3) / 4);
	
	my $bpag = $pag - 1; my $npag = $pag + 1;
	my $bef = ($bpag == -1)?     "＜": qq{<a href='$PNAME?MODE=pedia&UID=$uid&PAGE=$bpag'>＜</a>};
	my $nex = ($npag > $pg_cnt)? "＞": qq{<a href='$PNAME?MODE=pedia&UID=$uid&PAGE=$npag'>＞</a>};
	my $str = qq{
		<font color='#002200' size='-1'><b>합계$pg_cnt페이지：</b>
		$bef&nbsp;
	};
	$str .= ($pag == 0)? qq{
		<b><font color='#aa0000'>표지</font></b>&nbsp;
	}: qq{
		<a href='$PNAME?MODE=pedia&UID=$uid'>표지</a>&nbsp;
	};
	for(my $pg = 1; $pg <= $pg_cnt; $pg++) {
		$str .= ($pg != $pag)? qq{
			<a href='$PNAME?MODE=pedia&UID=$uid&PAGE=$pg'>$pg</a>&nbsp;
		}: "<b><font color='#aa0000'>$pg</font></b>&nbsp;";
	}
	$str .= qq{
		$nex
		</font>
	};
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_one_pure_htm
{
	my ($rep_data, $rep_id, $rep_inf) = @_;
	
	my $pure_image = "$RDATA->{album_img}/u0/o$rep_id.gif";
	my $rrep = $rep_data->[$rep_id];
	my $str .= qq{
		<table><tr><td>
	};
	if(!(-e $pure_image)) {
		$str .= get_flower_img_htm(0, $rep_id, 5, "bgcolor='#ddffff'");
	} else {
		$str .= qq{
			<table border='0' cellpadding='0' cellspacing='0'><tr><td>
			<img src="$pure_image" height='200' width='100' align='top' border='1' bgcolor='#ddffff'>
			</td></tr></table>
		};
	}
	
	my $italic_name = "(<i>$rrep->[4]</i>)<br>" if($rrep->[4]);
	my $comment     = ($rrep->[5])? $rrep->[5]:
		"<font color='red' size='-2'>연구소에서도 얻을 수 없는 꽃 씨앗입니다.</font>";
	my $num_rep;
	if($rep_inf->[1]) {
		my $day_str = get_day_str($rep_inf->[5]);
		$num_rep .= qq{
			<b>발견일:</b> $day_str<br>
			<b>발견자:</b> $rep_inf->[3]님
			(<a href='$PNAME?MODE=view_each&UID=$rep_inf->[1]&PID=$rep_inf->[2]'>$rep_inf->[4]</a>)<br>
		};
	}
	$num_rep .= ($rep_inf->[0])? "<b>출현 수:</b> $rep_inf->[0] 그루":
		"<font size='-2'>이 필드에서는 아직 발견되지 않았습니다</font>";
	
	$str .= qq{
		</td><td valign='top'>
			<br><b><font size='-1'>$rrep->[3]</b><br>
			$italic_name<br>
			$num_rep<hr>
			$comment
			</font>
			<br>
		</td></tr></table>
	};
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub make_pure_image
{
	my ($rep_data) = @_;

	if(!(-e "$RDATA->{album_img}/u0")) {
		mkdir("$RDATA->{album_img}/u0", 0755);
	}
	for(my $rep_id = 0; $rep_id < @$rep_data; $rep_id++) {
		my $rrep = $rep_data->[$rep_id];
		if(!(-e "$RDATA->{plant_img}/opure/o$rep_id.gif")) {
			for(my $organ_id = 1; $organ_id <= 3; $organ_id ++) {
				cp_image(0, $rep_id, 5, $organ_id, $rrep->[$organ_id - 1]);
			}
		} else {
			cp_pedia_img($rep_id);
		}
	}
	
	return 1;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_represent_flower
{
	my ($rcreature) = @_;
	my @view;
	
	for(my $organ_id = 1; $organ_id <= 3; $organ_id++) {
		my $val = $rcreature->{"$organ_id"};
		my $im_id = $val->{protein}->[$val->{view}->[0]]->{domain};
		push(@view, $im_id);
	}
	my $rep_data = get_represent_data();
	for(my $rep_id = 0; $rep_id < @$rep_data; $rep_id++) {
		my $rrep = $rep_data->[$rep_id];
		if($rrep->[2] == $view[2] && $rrep->[1] == $view[1] && $rrep->[0] == $view[0]) {
			
			return $rep_id;
		}
	}
	
	return undef;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_represent_data
{
	my @data;
	
	open(IN, "$RDATA->{sys_dir}/represent_plant.cgi")
		|| error_end(__LINE__, "파일 오류", $!);
	while(chomp(my $line = <IN>)) {
		if(!$line) {next;}
		push(@data, [(split(/\t/, $line))]);
	}
	close(IN) || error_end(__LINE__, "파일 오류", $!);
	
	return \@data;
}

###################################################
#  input:()
# retrun:[잎 씨앗류, 줄기 씨앗류, 꽃 씨앗류, secret_cnt, pure_cnt]
#comment:
###################################################
sub get_plant_dna_statistics
{
	my (@res, %data);
	my $rsecret  = get_secret_data();
	my $sec_cnt  = keys(%$rsecret);
	my $rep_data = get_represent_data();
	my $pure_cnt = @$rep_data;
	my $rdnas    = get_dna_data();

	foreach (@$rdnas) {
		my %creature;
		if($_->[2] eq "N") {next;}
		inc_inc::add_translated_gene_data(\%creature, $_->[0]);
		while(my ($organ_id, $rcre) = each(%creature)) {
			foreach (@{$creature{"$organ_id"}->{protein}}) {
				$data{"$organ_id"}->{"$_->{domain}"} = 1;
			}
		}
	}
	for(my $organ_id = 1; $organ_id <= 3; $organ_id++) {
		my $img_cnt = keys(%{$data{"$organ_id"}});
		push(@res, $img_cnt);
	}
	@res[3, 4] = ($sec_cnt, $pure_cnt);
	
	return \@res;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_secret_data
{
	my %data;
	
	open(IN, "$RDATA->{sys_dir}/secret_plant.cgi")
		|| error_end(__LINE__, "파일 오류", $!);
	while(chomp(my $line = <IN>)) {
		$line =~ s/ //g; if(!$line) {next;}
		my ($organ_id, $im_id) = split(/\t/, $line);
		$data{"$organ_id|$im_id"} = 1;
	}
	close(IN) || error_end(__LINE__, "파일 오류", $!);
	
	return \%data;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_secret_type
{
	my ($rsecret, $rcreature) = @_;
	for(my $organ_id = 1; $organ_id <= 3; $organ_id++) {
		my $val = $rcreature->{"$organ_id"};
		my $im_id = $val->{protein}->[$val->{view}->[0]]->{domain};
		return "$organ_id|$im_id" if($rsecret->{"$organ_id|$im_id"});
	}
	
	return 0;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_uname
{
	my $uid = shift;
	
	my $udata = get_udata($uid);
	
	return $udata->[1];
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_udata
{
	my $uid = shift;
	my $udata;
	
	my $rallu = get_all_udata_hash();
	$udata = $rallu->{"$uid"};
	
	if(!defined($udata)) {
		error_end(__LINE__, "사용자 정보가 잘못되었습니다", "uid = '$uid' not found");
		exit 1;
	}
	
	return $udata;
	
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_session_id
{
	my $uid = shift;
	my $ses_id;
	
	if(-e "$RDATA->{data_dir}/user.cgi") {
		open(USER, "$RDATA->{data_dir}/user.cgi")
			|| error_end(__LINE__, "파일 오류", $!);
		while(chomp(my $line = <USER>)) {
			my ($tmp_uid, $tmp_ses_id) = (split(/\t/, $line))[0, 15];
			if($uid == $tmp_uid) {$ses_id = $tmp_ses_id; last;}
		}
		close(USER) || error_end(__LINE__, "파일 오류", $!);
	}
	
	if(!defined($ses_id)) {
		error_end(__LINE__, "사용자 정보가 잘못되었습니다", "uid = '$uid' not found");
		exit 1;
	}
	
	return $ses_id;
	
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_new_session_id
{
	return int(rand() * 90000000 + 10000000);
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_new_uid
{
	my (%uids, @nids);
	if(-e "$RDATA->{data_dir}/user.cgi") {
		open(USER, "$RDATA->{data_dir}/user.cgi")
			|| error_end(__LINE__, "파일 오류", $!);
		while(chomp(my $line = <USER>)) {
			my ($uid, $nid) = (split(/\t/, $line))[0, 10];
			$uids{"$uid"} = 1;
			$nids[$nid] = 1;
		}
		close(USER) || error_end(__LINE__, "파일 오류", $!);
	}
	
	my $new_id;
	do {
		$new_id = time . int(rand(10));
	} while($uids{"$new_id"});
	
	my $new_nid = 0;
	while($nids[++$new_nid]) {}
	
	return ($new_id, $new_nid);
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_regist_err_html
{
	my $opt = shift;
	my $err_htm;
	
	my $uname = get_safe_htm($PARAM->{NAM});
	if($uname ne $PARAM->{NAM} || $uname =~ /\s| /) {
		$err_htm .= "이름에 사용할 수 없는 문자가 포함되어 있습니다.<br>\n";
	}
	if(length($uname) > 20) {
		$err_htm .= "이름이 너무 깁니다<br>\n";
	}
	if($uname eq "플라워 팜") {
		$err_htm .= "플라워 팜이라는 이름은 사용할 수 없습니다<br>\n";
	}
	my $pass = get_safe_htm($PARAM->{PWD});
	if($pass ne $PARAM->{PWD}) {
		$err_htm .= "비밀번호에 사용할 수 없는 문자가 포함되어 있습니다.<br>\n";
	}
	if(length($pass) > 20) {
		$err_htm .= "비밀번호가 너무 깁니다<br>\n";
	}
	if(get_safe_htm($PARAM->{HP}) ne $PARAM->{HP}) {
		$err_htm .= "URL에 사용할 수 없는 문자가 포함되어 있습니다.<br>\n";
	}
	if(length($PARAM->{HP}) > 50) {
		$err_htm .= "URL은 50자까지입니다.";
	}
	if(get_safe_htm($PARAM->{MAIL}) ne $PARAM->{MAIL}) {
		$err_htm .= "메일 주소에 사용할 수 없는 문자가 포함되어 있습니다.<br>\n";
	}
	if(length($PARAM->{MAIL}) > 25) {
		$err_htm .= "메일 주소는 25자까지입니다.";
	}
	if(get_safe_htm($PARAM->{SEX}) ne $PARAM->{SEX} || length($PARAM->{SEX}) > 3) {
		$err_htm .= "성별에 사용할 수 없는 문자가 포함되어 있습니다.<br>\n";
	}
	if(get_safe_htm($PARAM->{KEN}) ne $PARAM->{KEN} || length($PARAM->{KEN}) > 8) {
		$err_htm .= "거주지에 사용할 수 없는 문자가 포함되어 있습니다.<br>\n";
	}

	if(!$uname) {
		$err_htm .= "사용자명을 입력해 주세요<br>\n";
	} elsif(get_uid_from_uname($uname) && !$opt->{name_nocheck}) {
		$err_htm .= "그 사용자명은 이미 사용 중입니다.<br>\n";
	} elsif($uname eq $pass) {
		$err_htm .= "추측하기 어려운 비밀번호로 설정해 주세요.<br>\n";
	}
	
	if(length($pass) < 5) {
		$err_htm .= "비밀번호는 5자 이상으로 입력해 주세요.<br>\n";
	}
	
	return $err_htm;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_uid_from_uname
{
	my $uname = shift;
	my $uid;
	
	if(-e "$RDATA->{data_dir}/user.cgi") {
		open(USER, "$RDATA->{data_dir}/user.cgi")
			|| error_end(__LINE__, "파일 오류", $!);
		while(chomp(my $line = <USER>)) {
			my ($reged_uid, $reged_uname)
				= (split(/\t/, $line))[0, 1];
				
			if($uname eq $reged_uname) {
				$uid = $reged_uid;
				last;
			}
		}
		close(USER) || error_end(__LINE__, "파일 오류", $!);
	}
	
	return $uid;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_uid_from_namepass
{
	my ($uname, $pass) = @_;
	my ($uid, $ses_id);
	
	my $now_time = time;
	my $rallu = get_all_udata_hash();
	foreach (values(%$rallu)) {
		my ($reged_uid, $reged_uname, $reged_pass) = (@$_)[0, 1, 2];
		if($uname eq $reged_uname && $pass eq $reged_pass) {
			$ses_id = get_new_session_id();
			$uid = $reged_uid;
			@$_[7, 8, 15] = ($ENV{'REMOTE_ADDR'}, $now_time, $ses_id);
		}
	}
	put_all_udata($rallu);
	
	return [$uid, $ses_id];
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_all_udata
{
	my @uids;
	
	if(-e "$RDATA->{data_dir}/user.cgi") {
		open(USER, "$RDATA->{data_dir}/user.cgi")
			|| error_end(__LINE__, "파일 오류", $!);
		while(my $line = <USER>) {
			chomp($line);
			push(@uids, [split(/\t/, $line)]);
		}
		close(USER) || error_end(__LINE__, "파일 오류", $!);
	}
	
	return \@uids;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_ordered_udata
{
	my $ruids;
	my ($sort_type, $sort_ad) = split(/!/, $PARAM->{SORT});
	
	if($sort_type eq "al") {
		$ruids = get_updatetime_ordered_udata($sort_ad);
	} elsif($sort_type eq "ti") {
		$ruids = get_logintime_ordered_udata($sort_ad);
	} elsif($sort_type eq "id") {
		$ruids = get_nid_ordered_udata($sort_ad);
	} else {
		$ruids = get_random_ordered_udata();
	}
	
	
	return $ruids;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_random_ordered_udata
{
	my $ruids = get_all_udata();
	
	my @sorted_udata;
	for(my $cnt = @$ruids; $cnt > 0; $cnt --) {
		my ($pull) = splice(@$ruids, int(rand($cnt)), 1);
		if($PARAM->{UID} == $pull->[0]) {
			unshift(@sorted_udata, $pull);
		} else {
			push(@sorted_udata, $pull);
		}
	}
	
	return \@sorted_udata;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_nid_ordered_udata
{
	my ($sort_ad) = @_;
	my $ruids = get_all_udata();

	my %acct;
	foreach (@$ruids) {
		my $nid = $_->[10];
		push(@{$acct{"$nid"}}, $_);
	}
	my @sorted_udata;
	foreach (sort {$a <=> $b} keys(%acct)) {
		foreach (@{$acct{"$_"}}) {
			if($sort_ad eq 'd') {
				unshift(@sorted_udata, $_);
			} else {
				push(@sorted_udata, $_);
			}
		}
	}
	
	return \@sorted_udata;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_updatetime_ordered_udata
{
	my ($sort_ad) = @_;
	my $ruids = get_all_udata();

	my %acct;
	foreach (@$ruids) {
		my $nid = $_->[13];
		push(@{$acct{"$nid"}}, $_);
	}
	my @sorted_udata;
	foreach (sort {$a <=> $b} keys(%acct)) {
		foreach (@{$acct{"$_"}}) {
			if($sort_ad eq 'd') {
				unshift(@sorted_udata, $_);
			} else {
				push(@sorted_udata, $_);
			}
		}
	}
	
	return \@sorted_udata;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_logintime_ordered_udata
{
	my ($sort_ad) = @_;
	my $ruids = get_all_udata();

	my %acct;
	foreach (@$ruids) {
		my $nid = $_->[8];
		push(@{$acct{"$nid"}}, $_);
	}
	my @sorted_udata;
	foreach (sort {$a <=> $b} keys(%acct)) {
		foreach (@{$acct{"$_"}}) {
			if($sort_ad eq 'd') {
				unshift(@sorted_udata, $_);
			} else {
				push(@sorted_udata, $_);
			}
		}
	}
	
	return \@sorted_udata;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_word_cut_udata
{
	my ($ruids) = @_;

	my @hit_udt;
	
	my $search_word = $PARAM->{WORD};
	#http://www.din.or.jp/~ohzaki/perl.htm#JP_Match 에서받았습니다!
	my $euc_all = '[\x00-\x7F]|[\x8E\xA1-\xFE][\xA1-\xFE]|\x8F[\xA1-\xFE][\xA1-\xFE]';
	foreach (@$ruids) {
		# 외국어 이름에는 이쪽 처리를 사용
#		push(@hit_udt, $_) if(index($_->[1], $search_word) != -1);
		
		# 일본어 이름용 처리
		push(@hit_udt, $_) if((index($_->[1], $search_word) != -1)
			&& ($_->[1] =~ /^(?:$euc_all)*?\Q$search_word\E/));
	}
	
	return \@hit_udt;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_all_udata_hash
{
	my $ruids = get_all_udata();
	my %udata;
	
	foreach (@$ruids) {
		my $uid = $_->[0];
		$udata{"$uid"} = $_;
	}
	
	return \%udata;
}

###################################################
#  input:()
# retrun:
#comment: 데이터를 추출합니다. 호출 함수 쪽에서 잠금 처리 필요
###################################################
sub put_all_udata
{
	my ($rallu) = @_;
	
	open(USER, ">$RDATA->{data_dir}/user.cgi")
		|| error_end(__LINE__, "파일 오류", $!);
	foreach (values(%$rallu)) {
		my $each_line = join("\t", @$_);
		print USER "$each_line\n";
	}
	close(USER) || error_end(__LINE__, "파일 오류", $!);
	
	return 1;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_routine_time
{
	my $line;
	
	if(-e ("$RDATA->{data_dir}/timer.cgi")) {
		open(TIMER, "$RDATA->{data_dir}/timer.cgi")
			|| error_end(__LINE__, "파일 오류", $!);
		chomp($line = <TIMER>);
		close(TIMER) || error_end(__LINE__, "파일 오류", $!);
	}
	
	return $line;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub put_routine_time
{
	my $time = shift;
	
	open(TIMER, ">$RDATA->{data_dir}/timer.cgi")
		|| error_end(__LINE__, "파일 오류", $!);
	print TIMER "$time\n";
	close(TIMER) || error_end(__LINE__, "파일 오류", $!);
	
	return 1;
}

###################################################
#  input:()
# retrun:
#comment: status.cgi에서 데이터를 추출합니다.
###################################################
sub get_status_data
{
	my $uid = shift; $uid *= 1;
	my $line;
	
	open(UDT, "$RDATA->{data_dir}/u$uid/status.cgi")
		|| error_end(__LINE__, "파일 오류",
		"$! $RDATA->{data_dir}/u$uid/status.cgi");
	
	chomp($line = <UDT>);
	my @status = split(/\t/, $line);
	chomp($line = <UDT>);
	my @items = split(/\t/, $line);
	close(UDT) || error_end(__LINE__, "파일 오류", $!);
	
	return [\@status, \@items];
}

###################################################
#  input:()
# retrun:
#comment: status.cgi에서 데이터를 추출합니다.
###################################################
sub put_status_data
{
	my ($uid, $ruser, $opt) = @_; $uid *= 1;
	my ($line);
	
	open(UDT, ">$RDATA->{data_dir}/u$uid/status.cgi")
		|| error_end(__LINE__, "파일 오류", $!);
	$line = join("\t", @{$ruser->[0]});
	print UDT "$line\n";
	$line = join("\t", @{$ruser->[1]});
	print UDT "$line\n";
	close(UDT) || error_end(__LINE__, "파일 오류", $!);

	
	return 1;
}

###################################################
#  input:()
# retrun:
#comment: mail.cgi에서 데이터를 추출합니다.
###################################################
sub get_mail_data
{
	my $uid = shift; $uid *= 1;
	my @data;
	
	open(MAIL, "$RDATA->{data_dir}/u$uid/mail.cgi")
		|| error_end(__LINE__, "파일 오류", $!);
	while(chomp(my $line = <MAIL>)) {
		push(@data, [split(/\t/, $line)]);
	}
	close(MAIL) || error_end(__LINE__, "파일 오류", $!);
	
	return \@data;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub put_mail_data
{
	my ($uid, $rmail) = @_; $uid *= 1;
	my ($line);
	my $mail_max = 100;
	
	open(MAIL, ">$RDATA->{data_dir}/u$uid/mail.cgi")
		|| error_end(__LINE__, "파일 오류", $!);
	my $cnt = 0;
	foreach (@$rmail) {
		$line = join("\t", @$_);
		print MAIL "$line\n";
		if(++$cnt >= $mail_max) {last;}
	}
	close(MAIL) || error_end(__LINE__, "파일 오류", $!);
	
	return 1;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_bbs_data
{
	my @data;
	
	if(-e ("$RDATA->{data_dir}/bbs.cgi")) {
		open(IN, "$RDATA->{data_dir}/bbs.cgi")
			|| error_end(__LINE__, "파일 오류", $!);
		while(chomp(my $line = <IN>)) {
			push(@data, [split(/\t/, $line)]);
		}
		close(IN) || error_end(__LINE__, "파일 오류", $!);
	}
	
	return \@data;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub put_bbs_data
{
	my ($rbbs) = @_;
	my ($line);
	my $bbs_max = $RDATA->{bbs}->{max} || 100;
	
	open(OUT, ">$RDATA->{data_dir}/bbs.cgi")
		|| error_end(__LINE__, "파일 오류", $!);
	my $cnt = 0;
	foreach (@$rbbs) {
		$line = join("\t", @$_);
		print OUT "$line\n";
		if(++$cnt >= $bbs_max) {last;}
	}
	close(OUT) || error_end(__LINE__, "파일 오류", $!);
	
	return 1;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_mail_sort_data
{
	my $uid = shift; $uid *= 1;
	my @sort;
	
	my $file_name = "$RDATA->{data_dir}/u$uid/sort_mailto.cgi";
	
	if(-e $file_name) {
		open(IN, $file_name)
			|| error_end(__LINE__, "파일 오류", $! . $file_name);
		chomp(my $line = <IN>);
		@sort = split(/\t/, $line);
		close(IN) || error_end(__LINE__, "파일 오류", $!);
	}
	
	return \@sort;
}

###################################################
#  input:()
# retrun:
#comment: 중복 자동 삭제 처리. 이때 앞쪽 데이터를 우선합니다.
###################################################
sub put_mail_sort_data
{
	my ($uid, $rsort) = @_; $uid *= 1;
	my ($str, %ucheck);
	
	my $file_name = "$RDATA->{data_dir}/u$uid/sort_mailto.cgi";
	
	open(OUT, ">$file_name")
		|| error_end(__LINE__, "파일 오류", $! . $file_name);
	
	my $cnt = 0;
	foreach (@$rsort) {
		if($ucheck{"$_"}) {next;}
		$str .= "$_\t";
		$ucheck{"$_"} = 1;
		#20명까지정렬가능
		if(++$cnt >= 20) {last;}
	}
	print OUT "$str\n";

	close(OUT) || error_end(__LINE__, "파일 오류", $!);
	
	return 1;
}

###################################################
#  input:()
# retrun:
#comment: album.cgi에서 데이터를 추출합니다. 데이터가 늘면 무거워질 수 있습니다.
###################################################
sub get_album_data
{
	my $uid = shift; $uid *= 1;
	my %status;
	
	my $file_name = "$RDATA->{data_dir}/u$uid/album.cgi";
	
	if(-e $file_name) {
		open(ALBUM, $file_name)
			|| error_end(__LINE__, "파일 오류", $! . $file_name);
		while(chomp(my $line = <ALBUM>)) {
			my @plant = split(/\t/, $line);
			my $pid   = $plant[0];
			$status{"$pid"} = \@plant;
		}
		close(ALBUM) || error_end(__LINE__, "파일 오류", $!);
	}
	
	return \%status;
}

###################################################
#  input:()
# retrun:
#comment: 데이터를 추출합니다. 호출 함수 쪽에서 잠금 처리 필요
###################################################
sub push_album_data
{
	my ($uid, $rp) = @_;  $uid *= 1;
	
	open(ALBUM, ">>$RDATA->{data_dir}/u$uid/album.cgi")
		|| error_end(__LINE__, "파일 오류", "$!($uid)");
	my $each_line = join("\t", @$rp);
	print ALBUM "$each_line\n";
	close(ALBUM) || error_end(__LINE__, "파일 오류", $!);
	
	return 1;
}

###################################################
#  input:()
# retrun:
#comment: 데이터를 추출합니다. 호출 함수 쪽에서 잠금 처리 필요
###################################################
sub put_all_album_data
{
	my ($uid, $ralbum) = @_;  $uid *= 1;
	
	open(ALBUM, ">$RDATA->{data_dir}/u$uid/album.cgi")
		|| error_end(__LINE__, "파일 오류",
			$! . "$RDATA->{data_dir}/u$uid/album.cgi");
	foreach (values(%$ralbum)) {
		my $each_line = join("\t", @$_);
		print ALBUM "$each_line\n";
	}
	close(ALBUM) || error_end(__LINE__, "파일 오류", $!);
	
	return 1;
}

###################################################
#  input:()
# retrun:
#comment: plant.cgi에서 데이터를 추출합니다.
###################################################
sub get_plant_data_each
{
	my ($uid, $pid) = @_;
	
	my $rplant = get_plant_data($uid);
	
	return $rplant->{"$pid"};
}

###################################################
#  input:()
# retrun:
#comment: plant.cgi에서 데이터를 추출합니다.
###################################################
sub get_plant_data
{
	my $uid = shift; $uid *= 1;
	my %status;
	
	open(PLANT, "$RDATA->{data_dir}/u$uid/plant.cgi")
		|| error_end(__LINE__, "파일 오류",
			$! . "$RDATA->{data_dir}/u$uid/plant.cgi");
	while(chomp(my $line = <PLANT>)) {
		if(!$line) {next;}
		my @plant = split(/\t/, $line);
		$plant[3] = get_expression_data(@plant[16, 17]);
		$status{"$plant[0]"} = \@plant;
	}
	close(PLANT) || error_end(__LINE__, "파일 오류", $!);
	
	return \%status;
}

###################################################
#  input:()
# retrun:
#comment: plant.cgi에서 데이터를 추출합니다. 호출 함수 쪽에서 잠금 처리합니다.
###################################################
sub put_plant_data
{
	my ($uid, $rplant) = @_; $uid *= 1;
	
	open(PLANT, ">$RDATA->{data_dir}/u$uid/plant.cgi")
		|| error_end(__LINE__, "파일 오류", "$!($uid)");
	foreach (values(%$rplant)) {
#		$_->[3] = "null";
		my $each_line = join("\t", @$_);
		print PLANT "$each_line\n";
	}
	close(PLANT) || error_end(__LINE__, "파일 오류", $!);
	
	return 1;
}

###################################################
#  input:()
# retrun:
#comment: seed.cgi에서 데이터를 추출합니다.
###################################################
sub get_seed_data
{
	my $uid = shift; $uid *= 1;
	my %seeds;
	
	open(SEED, "$RDATA->{data_dir}/u$uid/seed.cgi")
		|| error_end(__LINE__, "파일 오류",
			$! . "$RDATA->{data_dir}/u$uid/seed.cgi");
	while(chomp(my $line = <SEED>)) {
		my @plant = split(/\t/, $line);
		my $pid   = $plant[0];
		$seeds{"$pid"} = \@plant;
	}
	close(SEED) || error_end(__LINE__, "파일 오류", $!);
	
	return \%seeds;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_server_data
{
	my %data;
	
	if(-e "$RDATA->{data_dir}/server.cgi") {
		open(IN, "$RDATA->{data_dir}/server.cgi")
			|| error_end(__LINE__, "파일 오류", $!);
		while(chomp(my $line = <IN>)) {
			my @dt = split(/\t/, $line);
			$data{"$dt[0]"} = \@dt;
		}
		close(IN) || error_end(__LINE__, "파일 오류", $!);
	}
	
	return \%data;
}

###################################################
#  input:()
# retrun:
#comment: seed.cgi에 데이터를 삽입합니다. 호출 함수 쪽에서 잠금 처리 필요
###################################################
sub put_seed_data
{
	my ($uid, $rseed) = @_; $uid *= 1;
	
	open(SEED, ">$RDATA->{data_dir}/u$uid/seed.cgi")
		|| error_end(__LINE__, "파일 오류", "$!($uid)");
	foreach (values(%$rseed)) {
		my $each_line = join("\t", @$_);
		print SEED "$each_line\n";
	}
	close(SEED) || error_end(__LINE__, "파일 오류", $!);
	
	return 1;
}

###################################################
#  input:()
# retrun:
#comment:
	#plantID,이름,심은 시각,성장한 초,성장도,성장 단계,빛과 온도,초,확인한 초,
#수분,초,검사한초,영양,초,검사한초,위치,유전자1,유전자2
###################################################
sub get_new_rplant
{
	my ($ru, $rplant, $time) = @_;
	my %new_plant;
	
	foreach (values(%$rplant)) {
		if($_->[5] == 6 || $_->[5] == 10) {
			$new_plant{"$_->[0]"} = $_;
			next;
		}	
		my @p = @$_;
		
		my @proc;
		change_step_time_for_sun(\@p, \@proc, $time);
		change_step_time(\@p, \@proc, $time, 1);
		change_step_time(\@p, \@proc, $time, 2);
		if($_->[5] == 5) {	#개화 중일 때 게이지와 관계없는 처리
			for (my $cnt = 0; $cnt < @proc; $cnt++) {
				for (my $cnt2 = 0; $cnt2 < @{$proc[$cnt]}; $cnt2++) {
					$proc[$cnt]->[$cnt2]->[0] = 9;
				}
			}
			($p[6], $p[9], $p[12]) = (9, 9, 9);
		}	
		change_grow_time(\@p, \@proc, $ru);
		$new_plant{"$_->[0]"} = \@p;
	}

	return \%new_plant;
}

###################################################
#  input:()
# retrun:
#comment:
	#plantID,이름,심은 시각,예약,성장도,성장 단계,빛과 온도,초,확인한 초,
#수분,초,검사한초,영양,초,검사한초,위치,유전자1,유전자2
#
#성장 단계：0:씨앗, 1:새싹, 2:본잎, 3:풀, 4:꽃봉오리, 5:꽃, 6:수확, 10:
###################################################
sub change_grow_time
{
	my ($rp, $rproc, $ru) = @_;
	my ($uid, $uname) = @$ru;
	my $rstep = $RDATA->{step};

	if(!defined($rproc->[0])) {return 1;}
	my $max_pnum = @{$rproc->[0]};
	if($max_pnum < @{$rproc->[1]}) {$max_pnum++;}
	if($max_pnum < @{$rproc->[2]}) {$max_pnum++;}
	my ($rcreature, $grow_level, $grow_step, $prom_flg)
		= (@$rp)[3, 4, 5, 26];
	
	for(my $cnt = 0; $cnt < $max_pnum; $cnt++) {
		if($grow_step == 5) {	#꽃인 경우
			$grow_level++;
		} else {
			my $status = 0;	#comment: 아래 함수의 처리 내용을 설명합니다.
			for(my $cnt2 = 0; $cnt2 <= 2; $cnt2++) {
				my $each_step = $rproc->[$cnt2]->[$cnt]->[0];
				if(!defined($each_step)) {$each_step = 9;}
				if($each_step == 0) {$status = 3; last;}
				elsif($each_step == 1) {$status = 2;}
				elsif($cnt2 != 0 && $each_step <= 5 && $status != 2) {$status = 1;}
				elsif($cnt2 == 0 && $each_step <= 3 && $status != 2) {$status = 1;}
			}
			if($status == 3) {
				my $time = $rproc->[0]->[$cnt]->[1];
				put_self_history($uid, "$rp->[1]이 시들어 버렸습니다", "red", $time);
				put_whole_history("$uname님의 $rp->[1]이 시들어 버렸습니다.", "black", $time);
				($rp->[5], $rp->[6], $rp->[9], $rp->[12]) = (10, 0, 0, 0);
				make_flower_gif($uid, $rp);
				pay_dead($uid, $time) if($RDATA->{support_money});
				last;
			}
			elsif($status == 2) {$grow_level = 0;}
			elsif($status == 0) {$grow_level++;}
		}
		my $up_point = $RDATA->{next_grow}->[$grow_step]
			+ get_grow_add($grow_step, $rcreature);
		$up_point /= 2 if($prom_flg & 1);	# 소수점 값이 나올 수 있으므로
		if($up_point <= $grow_level) {
			$grow_level = 0;
			$grow_step++;
			if($grow_step == 6) {	#씨앗인 경우
				$rp->[25] = $rproc->[0]->[$cnt]->[1];
				change_to_album($rp, $uid);
				$rp->[26] = 0;
				$rp->[5]  = 6;
				last;
			} else {
				my $time = $rproc->[0]->[$cnt]->[1];
				put_self_history($uid,
					"축하합니다. $rp->[1]$rstep->[$grow_step]->[1]",
					"red", $time);
				if($grow_step == 5) {
					put_whole_history("$uname님의 $rp->[1]이 개화했습니다.", "red", $time);
					change_flower_type_data($rp);
					my $seed_cost = get_seed_cost_from_rdata($rp);
					@$rp[6, 9, 12, 23, 24] = (9, 9, 9, $seed_cost, $seed_cost);
				}
			}
		}
		if($rp->[5] != $grow_step) {	#단계가 바뀔 때 이미지 변환
			$rp->[5] = $grow_step;
			if($grow_step != 6) {make_flower_gif($uid, $rp);}
		}
	}
	$rp->[4] = $grow_level;
	
	return 1;
}

###################################################
#  input:()
# retrun:
#comment: 마시마로님의 코드 제안을 채택한 부분
###################################################
sub pay_dead
{
	my ($uid, $time) = @_;

	my $rudata = get_status_data($uid);

	my $suportmoney = $RDATA->{support_money};
	if($rudata->[0]->[0] < $suportmoney) {
		$rudata->[0]->[0] += $suportmoney;
		put_status_data($uid, $rudata);
		put_self_history($uid,
			"그동안의 연구가 평가되어 식물 연구소에서 지원금 $suportmoney가 지급되었습니다.",
			"green", $time
		);
	}

	return 1;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_grow_add
{
	my ($grow_step, $rcreature) = @_;
	
	my $grows = (0, 1, 0, 2, 3, 0)[$grow_step];
	my $add_time = int($rcreature->{"$grows"}->{power} / 75) if($grows > 0);
	
	return $add_time;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub change_to_album
{
	my ($rp, $uid) = @_;
	
	my $pure_flg = 0;
	my $total    = $rp->[18] * 10;
	my $alb_time = $rp->[25];
	if(defined(my $rep_id = put_check_represent_flower($rp, $uid))) {
		my $pure_str; $pure_flg = 1;
		my $uname  = get_uname($uid);
		my $rpunum = get_pure_number_data();
		$rpunum->[$rep_id] = [$rpunum->[$rep_id]->[0] +1, $uid,
			$rp->[0], $uname, $rp->[1], $alb_time];
			
		put_pure_number_data($rpunum);
		$pure_str .= "<b>$uname"
			. "님의 <img src='$RDATA->{img_dir}/pure.gif' border='0' height='15'>식물"
			. " <a href='$PNAME?MODE=view_each&UID=$uid&PID=$rp->[0]'>"
			. "$rp->[1]</a>이 앨범에 저장되었습니다.</b>";
			
		put_whole_history($pure_str, "#aa0000", $alb_time);
		$total    *= $RDATA->{rep_rate};
		$rp->[18] *= $RDATA->{rep_rate};
	}
	if(my $first_str = get_first_plant_parts_str($rp)) {
		my $news_str = "<b>앨범에 저장된 " . get_uname($uid)
			. "님의 식물 「<a href='$PNAME?MODE=view_each&UID=$uid&PID=$rp->[0]'>"
			. "$rp->[1]</a>」은 ${first_str}가 새 씨앗인 것 같습니다!</b>";
			
		put_whole_history($news_str, "#00aaaa", $alb_time);
		put_self_history($uid, "$rp->[1]은 ${first_str}가 새 씨앗입니다", "#00aaaa", $alb_time);
		$rp->[27] = 1;
	}
	
	chage_seed_status($uid, $rp);

	my $rudata     = get_status_data($uid);
	my $seed_prfit = get_auto_seed_sell($pure_flg, $rudata->[0], $rp->[3]);
	my $flower_cnt = $rudata->[0]->[11];
	my $flower_max = $rudata->[0]->[10];
	$rudata->[0]->[0] += $total + $seed_prfit;
	if($flower_cnt < $flower_max) {
		$rudata->[0]->[11] ++;
		push_album_data($uid, $rp);
		my $rplant = get_album_data($uid);
		renew_pure_number_data($uid, $rplant);
	} else {
		put_self_history($uid,
			"앨범이 가득 차서 「$rp->[1]」은 폐기되었습니다", "red", $alb_time);
	}
	$rudata->[0]->[12] ++;
	put_status_data($uid, $rudata);
	
	my $seed_prfit_str = "자가 수분 씨앗을 얻어 판매했습니다(자동 처리)."
		. "이익 $seed_prfit$RDATA->{monney}를 얻었습니다." if(defined($seed_prfit));
	put_self_history($uid,
		"$rp->[1]이 앨범에 저장되었습니다. 평가액 $total$RDATA->{monney}를 얻었습니다.$seed_prfit_str",
		"red", $alb_time);

	put_album_time($uid, $alb_time);
	if(my $new_kyu = get_change_kyu($uid, $rudata->[0]->[12])) {
		my $seed_cnt      = get_can_hold_seed($new_kyu);
		my $kadan_cnt     = get_can_hold_garden($new_kyu);
		my $rpresent      = get_present_item($new_kyu);
		my $rudata        = get_status_data($uid);
		$rudata->[0]->[6] = $seed_cnt;
		$rudata->[0]->[8] = $kadan_cnt;
		$rudata->[1]->[$rpresent->[0]] += $rpresent->[1];
		put_status_data($uid, $rudata);
		my $level = $RDATA->{level_setting}->[$new_kyu]->[0] || $RDATA->{kyuu}->[$new_kyu];
		my $comment1 = "레벨이 ${level}로 올랐습니다.";
		my $comment2 = "씨앗을 $seed_cnt개까지 보유할 수 있게 되었습니다.";
		my $comment3 = "화분은 $kadan_cnt개까지 보유할 수 있습니다.";
		put_self_history($uid, "$comment1$comment2$comment3$rpresent->[2]", "red", $alb_time);
	}
	
	return 1;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_first_plant_parts_str
{
	my $rdata = shift;
	my $str;
	
	my $to = "";
	my $rcreature = $rdata->[3];
	my $rf_type = get_flower_type_data();
	while(my ($organ_id, $val) = each(%$rcreature)) {
		my $im_id = $val->{protein}->[$val->{view}->[0]]->{domain};

		if($rf_type->{"$organ_id"}->{"$im_id"} == 1) {
			$str .= $to . (undef, "줄기", "잎", "꽃")[$organ_id];
			$to = "와";
		}
	}
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub put_album_time
{
	my ($uid, $alb_time) = @_;
	
	my $rallu = get_all_udata_hash();
	$rallu->{"$uid"}->[13] = $alb_time;
	put_all_udata($rallu);
	
	return 1;
}

###################################################
#  input:()
# retrun:[어떤 item_id를, 몇 개 늘릴지, 표시 문구]
#comment:
###################################################
sub get_present_item
{
	my ($new_kyu) = @_;
	my ($iid, $add_cnt, $comment) = (0, 0, "");
	
	if($new_kyu == 1) {
		$iid     = 3;
		$add_cnt = 3;
		$comment = "축하 선물로 「토양 분석 키트」 3개를 받았습니다.";
	} elsif($new_kyu == 3) {
		$iid     = 6;
		$add_cnt = 1;
		$comment = "축하 선물로 「영양/보수제 키트」 1개를 받았습니다.";
	} elsif($new_kyu == 5) {
		$iid     = 7;
		$add_cnt = 1;
		$comment = "축하 선물로 「플랜트 하우스」 1개를 받았습니다.";
	} elsif($new_kyu == 7) {
		$iid     = 5;
		$add_cnt = 1;
		$comment = "축하 선물로 「성장 촉진제」 1개를 받았습니다.";
	}
	
	return [$iid, $add_cnt, $comment];
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_can_hold_seed
{
	my ($kyu) = @_;
	
	my $seed_cnt = $RDATA->{level_setting}->[$kyu]->[1]
		|| (2, 3, 5, 7, 10, 12, 15, 17, 20, 22, 25)[$kyu]
		|| 25;
	
	return $seed_cnt;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_can_hold_garden
{
	my ($kyu) = @_;
	
	my $garden_cnt = $RDATA->{level_setting}->[$kyu]->[2]
		|| (1, 1, 2, 2, 3, 3, 4, 4, 5, 6, 8)[$kyu]
		|| 8;
	
	return $garden_cnt;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub put_check_represent_flower
{
	my ($rp, $uid) = @_;
	
	my $rep_id = get_represent_flower($rp->[3]);
	if(defined($rep_id)) {cp_bg_img($uid, $rp->[0], $rep_id);}
	
	return $rep_id;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_change_kyu
{
	my ($uid, $flower_cnt) = @_;
	
	my $rudata     = get_status_data($uid);
	my $bkyu       = $rudata->[0]->[3];
	my $now_kyu    = int(log($flower_cnt) / log(2));
	if($bkyu < $now_kyu && $now_kyu <= 10) {
		$rudata->[0]->[3] = $now_kyu;
		put_status_data($uid, $rudata);
		
		return $now_kyu;
	}
	
	return undef;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_flower_total
{
	my ($dna1, $dna2) = @_;
	my $total;
	
	my $rcreature = get_expression_data($dna1, $dna2);
	while(my ($organ_id, $val) = each(%$rcreature)) {
		if($organ_id == 3) {$total += $val->{power} / 2;}
		else               {$total += $val->{power} / 4;}
	}
	$total = int($total);
	
	return $total;
}

###################################################
#  input:()
# retrun:
#comment: 씨앗 상태 변경, 평가액 입금, 앨범 등록 처리
###################################################
sub chage_seed_status
{
	my ($uid, $rp) = @_;
	my $pid = $rp->[0];
	
	my $rseed = get_seed_data($uid);
	foreach (values(%$rseed)) {	#부모가 자신의 식물이면 이용 가능으로 변환
		if($_->[8] == $pid) {$_->[1] = 1;}
	}
	put_seed_data($uid, $rseed);

	
	return 1;
}

###################################################
#  input:()
# retrun:
#comment: plant.cgi에서 데이터를 추출합니다. 호출 함수 쪽에서 잠금 처리합니다.
###################################################
sub put_self_history
{
	my ($uid, $str, $color, $time) = @_; $uid *= 1;
	my @lines;
	
	if(!$time) {$time = time;}
	my $file_pass = "$RDATA->{data_dir}/u$uid/history.cgi";
	
	if(-e $file_pass) {
		open(UHIST, $file_pass)
			|| error_end(__LINE__, "파일 오류", $!);
		chomp(@lines = <UHIST>);
		close(UHIST) || error_end(__LINE__, "파일 오류", $!);
		if(@lines >= $RDATA->{self_hist}){shift(@lines);}
	}
	
	
	open(UHIST, ">$file_pass")
		|| error_end(__LINE__, "파일 오류", $!);
	if(@lines) {print UHIST join("\n", @lines) . "\n";}
	print UHIST "$time\t$str\t$color\n";
	close(UHIST) || error_end(__LINE__, "파일 오류", $!);
	
	return 1;
}

###################################################
#  input:()
# retrun:
#comment: plant.cgi에서 데이터를 추출합니다. 호출 함수 쪽에서 잠금 처리합니다.
###################################################
sub put_whole_history
{
	my ($str, $color, $time) = @_;
	my @lines;
	
	if(!$time) {$time = time;}
	my $file_pass = "$RDATA->{data_dir}/whole_hist.cgi";
	
	if(-e $file_pass) {
		open(WHIST, $file_pass)
			|| error_end(__LINE__, "파일 오류", $!);
		chomp(@lines = <WHIST>);
		close(WHIST) || error_end(__LINE__, "파일 오류", $!);
		if(@lines >= $RDATA->{whole_hist}){shift(@lines);}
	}
	
	
	open(WHIST, ">$file_pass")
		|| error_end(__LINE__, "파일 오류", $!);
	if(@lines) {print WHIST join("\n", @lines) . "\n";}
	print WHIST "$time\t$str\t$color\n";
	close(WHIST) || error_end(__LINE__, "파일 오류", $!);
	
	return 1;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_self_history_htm
{
	my ($uid, $str) = @_; $uid *= 1;
	my $time = time;
	
	open(UHIST, "$RDATA->{data_dir}/u$uid/history.cgi")
		|| error_end(__LINE__, "파일 오류", "$! UID=$uid");
	chomp(my @lines = <UHIST>);
	close(UHIST) || error_end(__LINE__, "파일 오류", $!);
	
	my $history = qq{
		<tr><td colspan='4'><table width='100%' border='0' bgcolor='#eeeeee'>
			<tr><th bgcolor='#cccccc' colspan='4'><font size='-1'>재배 이력</font></th></tr>
			<tr><td><table>
	};
#	my $history = qq{
#		<tr><td colspan='4'>
#		<TABLE width='100%' border="0" cellspacing="1" style="border-top-width: 2px; border-right-width: 2px; border-bottom-width: 2px; border-left-width: 2px; border-style: dotted; border-color: green;">
#		<tr><td><table>
#	};
	foreach (reverse(@lines)) {
		my ($time, $comm, $color) = split(/\t/, $_);
		my $time_str = get_time_str($time);
		if(!$color) {$color = "blue";}
		$history .= "
			<tr><td nowrap valign='top'><font size='-2' color='$color'>$time_str:</font></td> 
			<td><font size='-2' color='$color'>$comm</font></td></tr>
		";
	}
	$history .= qq{
		</table></td></tr></table></td></tr>
	};
	
	return $history;
}


###################################################
#  input:()
# retrun:
#comment:
	#plantID,이름,심은 시각,성장한 초,,성장 단계,빛과 온도,초,확인한 초,
#수분,초,검사한초,영양,초,검사한초,위치,유전자1,유전자2
###################################################
sub change_step_time
{
	my ($rp, $rproc, $time, $kind) = @_;
	my $add = $kind * 3 + 6;
	my ($sstep, $stime, $cstime) = (@$rp)[$add, 1 + $add, 2 + $add];
	my $term_hr = $RDATA->{term} * 6;
	my $rstep   = $RDATA->{term_rate};
	
	my $pass_time = $time - $cstime;
	while($pass_time >= $term_hr) {
		my $next_flg = 0;
		while($pass_time >= $term_hr) {
			my $pass_term = ($cstime - $stime) / $term_hr;
			my $rand_rate = (defined($rstep->[$pass_term]))? $rstep->[$pass_term]:
				($pass_term < 5)? (0, 3 / 10, 1 / 7, 1 / 6, 2 / 5)[$pass_term]: 1;
				
			if(rand() < $rand_rate) {$next_flg = 1;}
			
			$cstime    += $term_hr;
			$pass_time -= $term_hr;
			if($next_flg) {
				$stime = $cstime;
				if($sstep > 0 && ($rp->[26] & 2) == 0) {$sstep--;}
				push(@{$rproc->[$kind]}, [$sstep, $cstime]);
				last;
			}
			push(@{$rproc->[$kind]}, [$sstep, $cstime]);
		}
	}
	($rp->[$add], $rp->[1 + $add], $rp->[2 + $add])
		= ($sstep, $stime, $cstime);
	
	return 1;
}

###################################################
#  input:()
# retrun:
#comment:
#	$place = 0:밖일치, 1:밖불일치, 2:안일치, 3:안불일치
	#plantID,이름,심은 시각,null,성장 레벨,성장 단계,빛과 온도,초,확인한 초,
#수분,초,검사한초,영양,초,검사한초,위치,유전자1,유전자2
#
#$place = 0:밖일치, 1:밖불일치, 2:안일치, 3:안불일치
###################################################
sub change_step_time_for_sun
{
	my ($rp, $rproc, $time) = @_;
	my ($sstep, $stime, $cstime, $place) = (@$rp)[6, 7, 8, 15];
	my $term_hr = $RDATA->{term} * 6;
	my $rstep   = $RDATA->{term_rate};
	my $change  = ($RDATA->{change_rate})? 1 / $RDATA->{change_rate}: 1 / 18;
	
	my $pass_time = $time - $cstime;
	while($pass_time >= $term_hr) {
		my $next_flg = 0;
		while($pass_time >= $term_hr) {
			if($place % 2 == 0 && rand() < $change) {
				$place ++;
			}

			my $pass_term = ($cstime - $stime) / $term_hr;
			my $rand_rate = (defined($rstep->[$pass_term]))? $rstep->[$pass_term]:
				($pass_term < 5)? (0, 3 / 10, 1 / 7, 1 / 6, 2 / 5)[$pass_term]: 1;

			if(rand() < $rand_rate) {$next_flg = 1;}
			
			$cstime    += $term_hr;
			$pass_time -= $term_hr;
			if($next_flg) {
				$stime = $cstime;
				if($place % 2 == 1 && $sstep > 0 && ($rp->[26] & 4) == 0) {$sstep--;}
				if($place % 2 == 0 && $sstep < 9) {$sstep++;}
				push(@{$rproc->[0]}, [$sstep, $cstime]);
				last;
			}
			push(@{$rproc->[0]}, [$sstep, $cstime]);
		}
	}
	($rp->[6], $rp->[7], $rp->[8], $rp->[15])
		= ($sstep, $stime, $cstime, $place);
		
	return 1;
}

###################################################
#  input:()
# retrun:
#comment: $rplant의 내용이 변경됩니다.
	#plantID,이름,심은 시각,성장한 초,확인한 초,성장 단계,빛과 온도,초,확인한 초,
#수분,초,검사한초,영양,초,검사한초,위치,유전자1,유전자2
###################################################
sub change_plant_data
{
	my ($rdata, $uid) = @_;
	my $alert;
	my ($pid, $option, $name) = split(/!/, $PARAM->{OPT});
	my $num = $PARAM->{NUM} || 1;
	
	my $step = $rdata->[5];
	if($option eq "w" && 0 <= $step && $step <= 4) {
		if($rdata->[9] >= 9) {$alert = "더 이상 물을 줄 수 없습니다.";}
		else {
			$rdata->[9] += $num;
			$rdata->[9] = 9 if($rdata->[9] > 9);
		}
	} elsif($option eq "p") {
		$rdata->[15] = 3 - $rdata->[15];
	} elsif($option eq "pi") {
		$rdata->[15] = 0 if($rdata->[15] == 3);
		$rdata->[15] = 1 if($rdata->[15] == 2);
	} elsif($option eq "po") {
		$rdata->[15] = 3 if($rdata->[15] == 0);
		$rdata->[15] = 2 if($rdata->[15] == 1);
	} elsif($option eq "n" && 0 <= $step && $step <= 5) {
		my $old_name = $rdata->[1];
		if($old_name eq $name) {
			$alert = "같은 이름입니다.";
		} elsif($name ne get_safe_htm($name)) {
			$alert = "이름에 사용할 수 없는 문자가 포함되어 있습니다.";
		} elsif(!$name) {
			$alert = "이름이 입력되지 않았습니다.";
		} else {
			put_self_history($uid,
				"「$old_name」을 「$name」으로 이름을 변경했습니다.");
			
			$rdata->[1] = $name;
		}
	}
	
	return $alert;
}

###################################################
#  input:()
# retrun:
#comment: $rplant의 내용이 변경됩니다.
	#plantID,이름,심은 시각,성장한 초,확인한 초,성장 단계,빛과 온도,초,확인한 초,
#수분,초,검사한초,영양,초,검사한초,위치,유전자1,유전자2
###################################################
sub change_seed_data
{
	my ($rseed, $uid) = @_;
	my $alert;
	my ($pid, $option, $name) = split(/!/, $PARAM->{RENAME});
	
	if(defined($rseed->{"$pid"}) && $option eq "n") {
		my $old_name = $rseed->{"$pid"}->[2];
		if($old_name eq $name) {
			$alert = "같은 이름입니다.";
		} elsif($name ne get_safe_htm($name)) {
			$alert = "씨앗 이름에 사용할 수 없는 문자가 포함되어 있습니다.";
		} elsif(!$name) {
			$alert = "씨앗 이름이 입력되지 않았습니다.";
		} else {
			$alert = "씨앗 이름을 변경했습니다.";
			put_self_history($uid,
				"씨앗 이름: 「$old_name」을 「$name」으로 변경했습니다.");
			
			$rseed->{"$pid"}->[2] = $name;
		}
	}
	
	return $alert;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_registration_start_htm
{
	my $str;

	my $rudata = get_all_udata();
	if(@$rudata < $RDATA->{max_user}) {
		my $uname_reged = get_uname_reged($rudata);
	
		if(defined($uname_reged)) {
			$str = get_start_htm($RDATA->{mlutireg_warn}, $uname_reged);
		} else {
			$str = get_usr_registration_htm();
		}
	} else {
		$str = get_start_htm();
	}
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_uname_reged
{
	my ($rudata) = @_;
	my ($uname_reged);

	if($RDATA->{mlutireg_warn}) {
		my $reg_ip = $ENV{'REMOTE_ADDR'};
		foreach (@$rudata) {
			if($reg_ip eq $_->[7]) {
				$uname_reged = $_->[1];
				last;
			}
		}
	}
	
	return $uname_reged;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_usr_registration_htm
{
	my $err_str  = shift;
	my $home_url = ($PARAM->{HP} =~ /^http:\/\//)? $PARAM->{HP}: "http://";
	
	my $str = "Content-type: text/html\n\n";
	$str .= qq{<html><head>};
	$str .= get_head();
	$str .= get_regist_jscript();
	$str .= qq{
		<title>사용자 등록 화면</title>
		</head>
		<body bgcolor='#d1f8d8' background='' onLoad=''>
			<form action="$PNAME" method="$RDATA->{method}" name="reg"><center>
			<img src='$RDATA->{img_dir}/inc_plant.gif' border='0'>
			<table width="450" border="0" cellspacing="0" cellpadding="0"><tr><td bgcolor="#aa8800"> 
			<table border="0" cellspacing="1" cellpadding="2" height="100%" width="100%">
			<tr><td bgcolor="#ffddcc" align="center" class='table_top start_top'>
				<b><font color="#442200" face="Arial, Helvetica, sans-serif">사용자 정보 등록</font></b></td>
			</tr>
			<tr><td bgcolor="#FFFFFF" class='table_bottom'> 
				<center><font color='red'>* 표시는 필수 입력 항목입니다<br>
				$err_str</font>
				<table border="0" cellspacing="3" cellpadding="2">
	};
	
	$str .= get_reg_tr_htm(
		qq{<INPUT TYPE="text" NAME="NAM" SIZE="16" MAXLENGTH="16" value='$PARAM->{NAM}'>},
		"", $PARAM->{KEN}, $PARAM->{SEX}, $PARAM->{HP}, $PARAM->{MAIL}, $PARAM->{OPN});
	
	$str .= qq{
					<tr> 
						<td colspan='4' ALIGN="center" valign="middle"> <br>
							<input type="button" value='등록' onClick="go_submit()">
							<input type="button" value='돌아가기' onClick="location.href='$RDATA->{home_url}'">
						</td>
					</tr>
				</table></center></td>
			</tr></table></td></tr></table>
			<INPUT TYPE="hidden" NAME="MODE" value='reg_check'>
			</center></form>
	};
	$str .= get_copyright();
	$str .= "<br></body></html>";
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_reg_tr_htm
{
	my ($name_htm, $pwd, $sex, $livein, $home_url, $mail, $opn) = @_;
	$home_url = ($home_url =~ /^http:\/\//)? $home_url: "http://";
	$opn      = ($opn)? "checked": "";

	my $str = qq{
		<tr>
			<td align="left" colspan='4'><hr></td>
		</tr><tr>
			<td ALIGN="right">
				<font face="Times New Roman, Times, serif" size="2"><b>*닉네임:</b></font></td>
			<td align="left" colspan='3'> 
				$name_htm</td>
		</tr><tr>
			<td ALIGN="right">
				<b><font size="2" face="Times New Roman, Times, serif">*비밀번호:</font></b>
			</td><td align="left"> 
				<INPUT TYPE="password" NAME="PWD" SIZE="8" MAXLENGTH="8" value='$pwd'></td>
			<td ALIGN="right">
				<b><font size="2" face="Times New Roman, Times, serif">*비밀번호 확인:</font></b>
			</td><td align="left"> 
				<INPUT TYPE="password" NAME="PWD2" SIZE="8" MAXLENGTH="8" value='$pwd'></td>
		</tr><tr>
			<td align="left" colspan='4'><hr></td>
		</tr><tr>
			<td align='right'><input type='checkbox' name='OPN' value='1' $opn></td>
			<td align="left" colspan='3'> 
					<b><font size="1" face="Times New Roman, Times, serif">
					아래 정보를 공개하려면 체크해 주세요.</font></b>
			</td>
		</tr><tr>
			<td ALIGN="right">
				<font face="Times New Roman, Times, serif" size="2"><b>거주지:</b></font></td>
			<td>
			<select name='KEN'>
	};
	
	foreach (
		"---", "서울특별시", "부산광역시", "대구광역시", "인천광역시", "광주광역시", "대전광역시", "울산광역시", "세종특별자치시", "경기도", "강원특별자치도", "충청북도", "충청남도", "전북특별자치도", "전라남도", "경상북도", "경상남도", "제주특별자치도", "해외", "기타"
	) {
		my $selected = "selected" if($livein eq $_);
		$str .= qq{<option value="$_" $selected>$_</option>\n};
	}
	$str .= qq{
			</select>
			</td>
			<td ALIGN="right">
				<font face="Times New Roman, Times, serif" size="2"><b>성별:</b></font></td>
			<td>
				<select name='SEX'>
	};
	foreach ("---", "남성", "여성") {
		my $selected = "selected" if($sex eq $_);
		$str .= qq{<option value="$_" $selected>$_</option>\n};
	}
	$str .= qq{
				</select>
			</td>
		</tr>
		<tr><td ALIGN="right">
				<b><font size="2" face="Times New Roman, Times, serif">홈페이지:</font></b>
			</td><td align="left" colspan='3'> 
				<INPUT TYPE="text" NAME="HP" SIZE="50" MAXLENGTH="100" value='$home_url'></td>
		</tr>
		<tr><td ALIGN="right">
				<b><font size="2" face="Times New Roman, Times, serif">메일 주소:</font></b>
			</td><td align="left" colspan='3'> 
				<INPUT TYPE="text" NAME="MAIL" SIZE="50" MAXLENGTH="100" value='$mail'></td>
		</tr>
	};
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_usr_registration_check_htm
{
	my $name = get_safe_htm($PARAM->{NAM});
	my $pwd  = get_safe_htm($PARAM->{PWD});
	my $ken  = get_safe_htm($PARAM->{KEN});
	my $sex  = get_safe_htm($PARAM->{SEX});
	my $hp   = get_safe_htm($PARAM->{HP});
	my $mail = get_safe_htm($PARAM->{MAIL});
	my $opns = ($PARAM->{OPN})? "공개": "비공개";
	
	my $str = "Content-type: text/html\n\n";
	$str .= qq{<html><head>};
	$str .= get_head();
	$str .= qq{
		<title>사용자 등록 확인 화면</title>
		</head>
		<body bgcolor='#d1f8d8' background='' onLoad=''>
			<form action="$PNAME" method="$RDATA->{method}" name="reg"><center>
			<img src='$RDATA->{img_dir}/inc_plant.gif' border='0'>
			<table width="450" border="0" cellspacing="0" cellpadding="0"><tr><td bgcolor="#aa8800"> 
			<table border="0" cellspacing="1" cellpadding="2" height="100%" width="100%">
			<tr><td bgcolor="#ffddcc" align="center" class='table_top start_top'>
				<b><font color="#442200" face="Arial, Helvetica, sans-serif">사용자 정보 등록확인</font></b></td>
			</tr>
			<tr><td bgcolor="#FFFFFF" class='table_bottom'> 
				<center><table border="0" cellspacing="3" cellpadding="2">
					<tr><td ALIGN="right">
							<font face="Times New Roman, Times, serif" size="2"><b>닉네임:</b></font></td>
						<td align="left"><b>$name</b></td>
					</tr>
					<tr><td ALIGN="right">
							<b><font size="2" face="Times New Roman, Times, serif">비밀번호:</font></b>
						</td><td align="left"><b>******</b></td>
					</tr>
					<tr><td ALIGN="right">
							<b><font size="2" face="Times New Roman, Times, serif">공개/비공개:</font></b>
						</td><td align="left" colspan='3'><b>
							<font size="2" face="Times New Roman, Times, serif">$opns</font>
						</b></td>
					</tr>
					<tr><td ALIGN="right">
							<b><font size="2" face="Times New Roman, Times, serif">거주지:</font></b>
						</td><td align="left" colspan='3'><b>$ken</b></td>
					</tr>
					<tr><td ALIGN="right">
							<b><font size="2" face="Times New Roman, Times, serif">성별:</font></b>
						</td><td align="left" colspan='3'><b>$sex</b></td>
					</tr>
					<tr><td ALIGN="right">
							<b><font size="2" face="Times New Roman, Times, serif">홈페이지:</font></b>
						</td><td align="left" colspan='3'><b>$hp</b></td>
					</tr>
					<tr><td ALIGN="right">
							<b><font size="2" face="Times New Roman, Times, serif">메일 주소:</font></b>
						</td><td align="left" colspan='3'><b>$mail</b></td>
					</tr><tr> 
						<td colspan='4' ALIGN="center" valign="middle"> 
							<input type="submit" value='등록'>
							<input type="button" value='돌아가기' onClick='history.back()'>
						</td>
					</tr>
				</table></center></td>
			</tr></table></td></tr></table>
			<INPUT TYPE="hidden" NAME="NAM" value='$PARAM->{NAM}'>
			<INPUT TYPE="hidden" NAME="PWD" value='$PARAM->{PWD}'>
			<INPUT TYPE="hidden" NAME="KEN" value='$PARAM->{KEN}'>
			<INPUT TYPE="hidden" NAME="SEX" value='$PARAM->{SEX}'>
			<INPUT TYPE="hidden" NAME="HP" value='$PARAM->{HP}'>
			<INPUT TYPE="hidden" NAME="MAIL" value='$PARAM->{MAIL}'>
			<INPUT TYPE="hidden" NAME="OPN" value='$PARAM->{OPN}'>
			<INPUT TYPE="hidden" NAME="MODE" value='regist'>
			</center></form>
	};
	$str .= get_copyright();
	$str .= "<br></body></html>";
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_usr_registration_change_htm
{
	my $str;
	my $uid = $PARAM->{UID};

	my $rallu = get_all_udata_hash();
	my $ru    = $rallu->{"$uid"};
	if($PARAM->{OPT} eq "delete") {
		delete($rallu->{"$uid"});
		put_all_udata($rallu);
		delete_regist_user($uid);
		$str = get_start_htm("사용자 정보를 삭제했습니다.");
	} elsif(!$PARAM->{NAM}) {
		$str = get_usr_registration_change_input_htm($uid, $ru);
	} elsif(my $err_htm = get_regist_err_html({name_nocheck => 1})) {
		$str = get_usr_registration_change_input_htm($uid, $ru, $err_htm);
	} else {
		my $opn  = ($PARAM->{OPN})? 1: 0;
		@$ru[2, 3, 4, 5, 6, 9] = (
			get_safe_htm($PARAM->{PWD}),  get_safe_htm($PARAM->{HP}),
			get_safe_htm($PARAM->{MAIL}), get_safe_htm($PARAM->{SEX}),
			get_safe_htm($PARAM->{KEN}),  $opn
		);
		put_all_udata($rallu);
		$str = get_main_htm($uid, "사용자 등록 정보를 변경했습니다");
	}
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_usr_registration_change_input_htm
{
	my ($uid, $ru, $err_str) = @_;
	
	my $str = "Content-type: text/html\n\n";
	$str .= qq{<html><head>};
	$str .= get_head();
	$str .= get_regist_jscript();
	$str .= qq{
		<title>사용자 등록 정보 변경 화면</title>
		</head>
		<body bgcolor='#d1f8d8' background='' onLoad=''>
			<form action="$PNAME" method="$RDATA->{method}" name="reg"><center>
			<img src='$RDATA->{img_dir}/inc_plant.gif' border='0'>
			<table width="450" border="0" cellspacing="0" cellpadding="0"><tr><td bgcolor="#aa8800"> 
			<table border="0" cellspacing="1" cellpadding="2" height="100%" width="100%">
			<tr><td bgcolor="#ffddcc" align="center" class='table_top start_top'>
				<b><font color="#442200" face="Arial, Helvetica, sans-serif">사용자 등록 정보 변경</font></b></td>
			</tr>
			<tr><td bgcolor="#FFFFFF" class='table_bottom'> 
				<center><font color='red'>* 표시는 필수 입력 항목입니다<br>
				$err_str</font>
				<table border="0" cellspacing="3" cellpadding="2">
	};
	$str .= get_reg_tr_htm("<b>$ru->[1]</b>", (@$ru)[2, 5, 6, 3, 4, 9]);
	$str .= qq{
					<tr> 
						<td colspan='4' ALIGN="center" valign="middle"> <br>
							<input type="button" value='등록 정보 변경' onClick="this.form.OPT.value='change'; go_submit();">
							<input type="button" value='사용자 정보 삭제' onClick="if(confirm('삭제하시겠습니까?')) {this.form.OPT.value='delete'; this.form.submit();}">
							<input type="button" value='돌아가기' onClick="location.href='$PNAME?UID=$uid&MODE=main'">
						</td>
					</tr>
				</table></center></td>
			</tr></table></td></tr></table>
			<INPUT TYPE="hidden" NAME="MODE" value='reg_change'>
			<INPUT TYPE="hidden" NAME="UID" value='$uid'>
			<INPUT TYPE="hidden" NAME="NAM" value='$ru->[1]'>
			<INPUT TYPE="hidden" NAME="OPT" value=''>
			</center></form>
	};
	$str .= get_copyright();
	$str .= "<br></body></html>";
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment: 메인 화면 HTML을 생성합니다.
###################################################
sub get_main_htm
{
	my ($uid, $alert_str) = @_;

	my $rudata = get_status_data($uid);
	if($PARAM->{MODE} eq "main" && $PARAM->{OPT} eq "u" && $rudata->[1]->[8] == 1) {
		exec_uranai($rudata, $uid);	#rudata안변경
		put_status_data($uid, $rudata);
	}
	my $uname = get_uname($uid);
	
	my $str = "Content-type: text/html\n\n";
	$str .= qq{<html><head>};
	$str .= get_head();
	$str .= get_main_js();
	$str .= get_hpb_js();
	$str .= qq{
		<title>$uname님의 신기한 식물</title>
		</head>
		<body bgcolor='#d1f8d8' background='' onLoad=''>
			<!-- <center><img src='$RDATA->{img_dir}/inc_plant.gif' border='0'></center> -->
	};
	$str .= get_flower_htm($uid, $rudata);
	$str .= get_ustatus_htm($uid, $rudata, $alert_str, {property => 1});
	$str .= get_copyright();
	$str .= "<br></body></html>";
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub exec_uranai
{
	my ($rudata, $uid) = @_;
	
	my $u_time = get_uranai_time();
	if(int(($rudata->[0]->[9] + $JST) / 86400) < int(($u_time + $JST) / 86400)) {
		my $hist_str;
		my $ruranai = get_user_uranai($uid);
		my ($frt_type, $order_str) = @$ruranai;
		if($frt_type != 4) {
			my $rplant = get_plant_data($uid);
			my $rp = (values(%$rplant))[int(rand() * keys(%$rplant))];
			my ($pname, $rcreature, $grow_level, $grow_step, $prom_flg)
				= (@$rp)[1, 3, 4, 5, 26];
			if(0 <= $grow_step && $grow_step <= 4) {
				my $new_grow_level = $grow_level + (4, 2, 2, 1, 0, -1, -4)[$frt_type];
				my $up_point = $RDATA->{next_grow}->[$grow_step]
					+ get_grow_add($grow_step, $rcreature);
				$up_point /= 2 if($prom_flg & 1);	# 소수점 값이 나올 수 있으므로
				$new_grow_level = 0 if($new_grow_level < 0);
				$new_grow_level = $up_point - 1 if($new_grow_level >= $up_point);
				$hist_str .= "음악이 「$pname」에 " . (
					"매우 좋은", "좋은", "좋은", "조금 좋은",
					undef, "조금 나쁜", "매우 나쁜"
				)[$frt_type] . "영향을 주었습니다.<br>";
				
				$rp->[4] = $new_grow_level;
				put_plant_data($uid, $rplant);
			}
		}
		my $rank_str = "($order_str위)" if($order_str);
		$hist_str .= "오늘의 운세는 「"
			. ("", "", "안", "", "", "", "")[$frt_type]
			. "$rank_str」입니다.";
		
		
		$hist_str .= get_item_change($rudata->[1], $frt_type);
		$rudata->[0]->[9] = $u_time;
		put_self_history($uid, $hist_str, "#006666");
	}
	
	return 1;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_item_change
{
	my ($ruitem, $frt_type) = @_;
	my $hist_str;
	
	if($frt_type >= 5) {
		my $pattern = int(rand() * 6);
		if($pattern == 0) {
			$hist_str .= "<br>오디오 세트가 고장났습니다.";
			$ruitem->[8] = 0;
		} elsif($pattern == 1 && $ruitem->[1] > 0) {
			$hist_str .= "<br>비료 냄새가 너무 심해서 폐기했습니다.($ruitem->[1]";
			if($frt_type == 5){$ruitem->[1]--;} else {$ruitem->[1] = 0;}
			$hist_str .= "→$ruitem->[1])";
		} elsif($pattern == 2 && $ruitem->[2] > 0) {
			$hist_str .= "<br>토양 시험지가 변색되어 폐기했습니다.($ruitem->[2]";
			if($frt_type == 5){$ruitem->[2]--;} else {$ruitem->[2] = 0;}
			$hist_str .= "→$ruitem->[2])";
		} elsif($pattern == 3 && $ruitem->[3] > 0) {
			$hist_str .= "<br>토양 분석 키트가 고장난 것 같아 1개 버렸습니다.($ruitem->[3]";
			$ruitem->[3]--; $hist_str .= "→$ruitem->[3])";
		} elsif($pattern == 4 && $ruitem->[5] > 0) {
			$hist_str .= "<br>성장 촉진제의 사용 기한이 지나 1개 버렸습니다.($ruitem->[5]";
			$ruitem->[5]--; $hist_str .= "→$ruitem->[5])";
		} elsif($pattern == 5 && $ruitem->[7] > 0) {
			$hist_str .= "<br>플랜트 하우스 1개가 사라졌습니다.($ruitem->[7]";
			$ruitem->[7]--; $hist_str .= "→$ruitem->[7])";
		}
	} elsif($frt_type <= 1) {
		my $pattern = int(rand() * 5);
		if($pattern == 1 || $pattern == 3) {
			if($frt_type == 0) {
				$hist_str .= "<br>시제품 성장 촉진제 1개를 받아 왔습니다.(" . ($ruitem->[5] * 1);
				$ruitem->[5]++; $hist_str .= "→$ruitem->[5])";
			} else {
				$hist_str .= "<br>수제 비료를 만들어 보았습니다. 비료가 1개 늘었습니다.(" . ($ruitem->[1] * 1);
				$ruitem->[1]++; $hist_str .= "→$ruitem->[1])";
			}
		} elsif($pattern == 2 || $pattern == 4) {
			if($frt_type == 0) {
				$hist_str .= "<br>친구에게 토양 분석 키트를 받았습니다. 토양 분석 키트가 1개 늘었습니다.(" . ($ruitem->[3] * 1);
				$ruitem->[3]++; $hist_str .= "→$ruitem->[3])";
			} else {
				$hist_str .= "<br>서랍에서 토양 시험지를 찾았습니다. 토양 시험지가 1개 늘었습니다.(" . ($ruitem->[2] * 1);
				$ruitem->[2]++; $hist_str .= "→$ruitem->[2])";
			}
		} elsif($pattern == 0) {
			$hist_str .= "<br>어쩐지 플랜트 하우스가 1개 늘었습니다. 행운입니다!(" . ($ruitem->[7] * 1);
			$ruitem->[7]++; $hist_str .= "→$ruitem->[7])";
		}
	}
	
	return $hist_str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_no_cook_htm
{
	my $suid = $PARAM->{OPT};
	my $str;
	
	if(defined($suid)) {
		$str = get_no_cook_main_htm($suid);
	} else {
		$str = get_no_cook_user_htm($PARAM->{UID}, $suid);
	}
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_no_cook_main_htm
{
	my $suid = shift;
	my $rudata  = get_status_data($suid);
	my $uname = get_uname($suid);
	
	my $str = "Content-type: text/html\n\n";
	$str .= qq{<html><head>};
	$str .= get_head();
	$str .= get_hpb_js();
	$str .= qq{
		<title>$uname님의 신기한 식물</title>
		</head>
		<body bgcolor='#d1f8d8' background='' onLoad=''>
			<!-- <center><img src='$RDATA->{img_dir}/inc_plant.gif' border='0'></center> -->
	};
	$str .= get_flower_htm($suid, $rudata);
	$str .= get_ustatus_htm($suid, $rudata);
	$str .= get_copyright();
	$str .= "<br></body></html>";
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_no_cook_user_htm
{
	my ($uid, $suid) = @_;
	my $ruids = get_ordered_udata();
	my $rc    = get_rc_data();
	my $search_word = $PARAM->{WORD} if($PARAM->{WORD} eq get_safe_htm($PARAM->{WORD}));
	$ruids    = get_word_cut_udata($ruids) if($search_word);
	my $href_str = qq{$PNAME?UID=$uid&MODE=no_cook&WORD=$search_word&SORT=};
	
	my $str = "Content-type: text/html\n\n";
	$str .= qq{<html><head>};
	$str .= get_head();
	$str .= get_hpb_js();
	$str .= qq{
		<title>다른 사용자의 신기한 식물</title>
		</head>
		<body bgcolor='#d1f8d8' background='' onLoad=''>
			<center><img src='$RDATA->{img_dir}/inc_plant.gif' border='0'></center>
		<form name='sbm' action='$PNAME' method="$RDATA->{method}">
			<input type='hidden' name='MODE' value='no_cook'>
			<input type='hidden' name='UID' value='$uid'>
			<input type='hidden' name='WORD' value=''>
		</form>
		<form onSubmit='return false'><center>
		<table width="450" border="0" cellspacing="0" cellpadding="0"><tr><td bgcolor="#008800"> 
		<table border="0" cellspacing="1" cellpadding="2" height="100%" width="100%">
			<tr><td  bgcolor="#bbffbb" align="center" class='table_top user_top'>
				<table width='100%'><tr>
					<td><img src='$RDATA->{img_dir}/btn13_0.gif' border='0'></td>
					<td align='center'><b>식물을 보고 싶은 사용자를 선택해 주세요</b></td>
					<td align='right'><input type='button' value=' 돌아가기 ' onClick="location.href='$PNAME?UID=$uid&MODE=main'"></td>
				</tr></table>
			</td></tr>
			<tr><td bgcolor="#ffffff" align="center" class='table_bottom'>
				<b>이름에 포함된 문자로 검색할 수 있습니다:</b>
				<input type='text' name='srch' size="16" maxlength="16" value='$search_word'>
				<input type='button' value='검색' onClick='document.sbm.WORD.value=this.form.srch.value;document.sbm.submit();'>
			</td></tr>
			<tr><td bgcolor="#FFFFFF" align="center" class='table_bottom'>
				<table width='100%'><tr>
					<td colspan='3' align='center'>
						<b><a href='$PNAME?OPT=1!c&UID=$PARAM->{UID}&MODE=album'>
						꽃 농장으로</a></b><hr>

						<table cellspacing="0" cellpadding="3" border='1' width='100%'>
							<tr><th nowrap>ID<input type='button' value='$rc->[0]->[0]' onClick="location.href='${href_str}id!$rc->[0]->[1]'"></th>
								<th>이름</th>
								<th>댓글</th>
								<th nowrap><table><tr>
									<th><font size='-1'>앨범<br>갱신일시</font></th>
									<td><input type='button' value='$rc->[1]->[0]' onClick="location.href='${href_str}al!$rc->[1]->[1]'"></td>
								</tr></table></th>
							</tr>
	};
	foreach (@$ruids) {
		my ($suid, $uname, $nid, $subj, $albtime) = (@$_)[0, 1, 10, 11, 13];
		my $albt_str = ($albtime)? get_daytime_str($albtime): "---";
		$subj = "&nbsp;" if(!$subj);
		if($suid != $uid) {
			$str .= qq{
				<tr><td align='right'>$nid</td>
					<td><b><a href='$PNAME?UID=$uid&OPT=$suid&MODE=no_cook'>$uname님의 식물</a></b></td>
					<td>$subj</td>
					<td align='center'><font size='-1'>$albt_str</font></td></tr>
			};
		}
	}
	$str .= qq{
						</table>
					</td>
				</tr></table>
			</td></tr>
			<tr><td bgcolor="#bbffbb" align="center" class='table_top user_bottom'>
				<input type='button' value=' 돌아가기 ' onClick="location.href='$PNAME?UID=$uid&MODE=main'">
			</td></tr>
		</table></td></tr></table>
		</center></form>
	};
	$str .= get_copyright();
	$str .= "</body></html>";
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_rc_data
{
	my @data = (['▼', 'd'], ['▼', 'd'], ['▼', 'd']);
	
	my $sort = $PARAM->{SORT};
	
	$data[0] = ['▲', 'a'] if($sort eq "id!d");
	$data[1] = ['▲', 'a'] if($sort eq "al!d");
	$data[2] = ['▲', 'a'] if($sort eq "ti!d");
	
	return \@data;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_sow_item_htm
{
	my $err_str;
	my $uid = $PARAM->{UID};

	my $rseed = get_seed_data($uid);
	my $old_pid = $PARAM->{OPT};
	my $new_pid = $PARAM->{IID};
	my $rrseed = $rseed->{"$new_pid"};
	if(!$rrseed->[1]) {
		$err_str = "이용할 수 없는 씨앗입니다";
	} else {
		my $rplant = get_plant_data($uid);
		my $grow_step = $rplant->{"$old_pid"}->[5];
		if ($grow_step != 6 && $grow_step != 10) {
			$err_str = "그곳에는 심을 수 없습니다";
		} else {
			my $rudata = get_status_data($uid);
			$rudata->[0]->[5]--;
			my $time = time;
			my ($pname, $dna1, $dna2, $uid1, $uid2, $pid1, $pid2)
				= (@$rrseed)[2, 3, 4, 6, 7, 8, 9];
			my $price = get_flower_total($dna1, $dna2);
			my $rdata = [$new_pid, $pname, $time, "null", 0, 0, 8, $time, $time, 8, $time,
				$time, 8, $time, $time, 2, $dna1, $dna2, $price, $uid1, $uid2, $pid1, $pid2];
			$rplant->{"$new_pid"} = $rdata;
			make_flower_gif($uid, $rdata);
			delete($rseed->{"$new_pid"});
			delete($rplant->{"$old_pid"});
			put_plant_data($uid, $rplant);
			put_seed_data($uid, $rseed);
			put_status_data($uid, $rudata);
			put_self_history($uid, "$pname의 씨앗을 심었습니다.", "black");
			delete_image($uid, $old_pid);
		}
	}
	
	my $str = get_main_htm($uid, $err_str);
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_use_item_htm
{
	my $alert_str;
	my $uid = $PARAM->{UID};
	my $uname = get_uname($uid);

	my $rseed = get_seed_data($uid);
	if($PARAM->{RENAME}) {
		$alert_str = change_seed_data($rseed, $uid);
		put_seed_data($uid, $rseed);
	}
	my $ritem_shop = get_item_shop();
	my $ruser = get_status_data($uid);
	
	my $str = "Content-type: text/html\n\n";
	$str .= qq{<html><head>};
	$str .= get_head();
	$str .= get_use_item_js();
	$str .= get_hpb_js();
	$str .= qq{
		<title>$uname님의 신기한 식물</title>
		</head>
		<body bgcolor='#d1f8d8' background='' onLoad=''>
			<!-- <center><img src='$RDATA->{img_dir}/inc_plant.gif' border='0'></center> -->
			<center><img src='$RDATA->{img_dir}/dougu_ttl.gif' border='0'></center>
	};
	$str .= get_flower_htm($uid, $ruser);	#아이템 데이터가 변환됩니다
	$str .= "<center><font color='red'>$alert_str</font></center>\n";
	$str .= get_user_item_htm($uid, $ritem_shop, $ruser, $rseed);
	$str .= get_ustatus_htm($uid, $ruser);
	$str .= get_copyright();
	$str .= "<br></body></html>";

	put_status_data($uid, $ruser);

	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_ustatus_htm
{
	my ($uid, $rudata, $alert_str, $opt) = @_;
	my $property_str;
	my $udata   = get_udata($uid);
	my $img_dir = $RDATA->{img_dir};
	my $rstatus = $rudata->[0];
	my $announc_htm = get_announce_htm($uid, $rstatus)
		if ($rstatus->[3] <= $RDATA->{hint} && $PARAM->{MODE} ne "no_cook");
	my $uname_htm = get_uname_htm($udata);
	if($opt->{property}) {
		my $property = get_user_property($uid);
		$property_str = qq{
			<td ALIGN="right">
				<b><font size="2" face="Times New Roman, Times, serif">자산:</font></b>
			</td><td align="left"><b>$property$RDATA->{monney}</b></td>
		};
	}
	
	my $garden_name = ($PARAM->{MODE} eq "pollination")? "수분 작업": 
		($uid == $PARAM->{UID})? "내 정원": "$udata->[1]님의 정원";
	my $level = $RDATA->{level_setting}->[$rstatus->[3]]->[0] || $RDATA->{kyuu}->[$rstatus->[3]];
	
	my $str = qq{
			<form action="$PNAME" method="$RDATA->{method}" name="reg"><center>
			<table width="450" border="0" cellspacing="0" cellpadding="0"><tr><td bgcolor="#333333"> 
			<table border="0" cellspacing="1" cellpadding="2" height="100%" width="100%">
			<tr><td bgcolor="#eeeeee" align="center" class='table_top status_bottom'>
				<b><font color="#333333" face="Arial, Helvetica, sans-serif">$garden_name</font></b></td>
			</tr>
			<tr><td bgcolor="#FFFFFF" class='table_bottom'> 
				$announc_htm
				<center><table width="100%" border="0" cellspacing="3" cellpadding="2">
					<tr><td ALIGN="center" colspan='4'>
						<font face="Times New Roman, Times, serif" size="2" color='red'>
						<b>$alert_str</b></font>
					</td></tr>
					<tr><td ALIGN="right">
							<font face="Times New Roman, Times, serif" size="2"><b>이름:</b></font></td>
						<td align="left">$uname_htm</td>
						<td ALIGN="right">
							<b><font size="2" face="Times New Roman, Times, serif">보유 금액:</font></b>
						</td><td align="left"><b>$rstatus->[0]$RDATA->{monney}</b></td>
					</tr>
					<tr><td ALIGN="right">
							<b><font size="2" face="Times New Roman, Times, serif">레벨:</font></b>
						</td><td align="left"><b>$level</b></td>
						$property_str
					</tr><tr> 
						<td colspan='4' ALIGN="center" valign="middle">
	};
	if($PARAM->{MODE} eq "use_item") {
		$str .= qq{
			<A href="$PNAME?UID=$uid&MODE=shop" id="ROLL03" onmouseout="HpbImgSwap('ROLL03', '$img_dir/btn03_0.gif');" onmouseover="HpbImgSwap('ROLL03', '$img_dir/btn03_1.gif');">
			<IMG src="$img_dir/btn03_0.gif" width="70" height="45" border="0" name="ROLL03" alt="비료 등 필요한 물품 구입"></A>
			<A href="$PNAME?UID=$uid&MODE=main" id="ROLL06" onmouseout="HpbImgSwap('ROLL06', '$img_dir/btn06_0.gif');" onmouseover="HpbImgSwap('ROLL06', '$img_dir/btn06_1.gif');">
			<IMG src="$img_dir/btn06_0.gif" width="70" height="45" border="0" name="ROLL06" alt="도구함 접기"></A>
		};
	} elsif($PARAM->{MODE} eq "no_cook") {
		$str .= qq{
			<A href="$PNAME?UID=$PARAM->{UID}&MODE=no_cook" id="ROLL13" onmouseout="HpbImgSwap('ROLL13', '$img_dir/btn13_0.gif');" onmouseover="HpbImgSwap('ROLL13', '$img_dir/btn13_1.gif');">
			<IMG src="$img_dir/btn13_0.gif" width="70" height="35" border="0" name="ROLL13" alt="사용자 선택 화면으로 돌아가기"></A>
			<A href="$PNAME?OPT=$uid!c&UID=$PARAM->{UID}&MODE=album" id="ROLL16" onmouseout="HpbImgSwap('ROLL16', '$img_dir/btn16_0.gif');" onmouseover="HpbImgSwap('ROLL16', '$img_dir/btn16_1.gif');">
			<IMG src="$img_dir/btn16_0.gif" width="70" height="35" border="0" name="ROLL16" alt="이 사용자의 앨범 보기"></A>
			<A href="$PNAME?UID=$PARAM->{UID}&MODE=mail&OPT=3!$uid" id="ROLL17" onmouseout="HpbImgSwap('ROLL17', '$img_dir/btn17_0.gif');" onmouseover="HpbImgSwap('ROLL17', '$img_dir/btn17_1.gif');">
			<IMG src="$img_dir/btn17_0.gif" width="70" height="35" border="0" name="ROLL17" alt="이 사용자에게 메일 보내기"></A>
			<A href="$PNAME?UID=$PARAM->{UID}&MODE=main" id="ROLL18" onmouseout="HpbImgSwap('ROLL18', '$img_dir/btn18_0.gif');" onmouseover="HpbImgSwap('ROLL18', '$img_dir/btn18_1.gif');">
			<IMG src="$img_dir/btn18_0.gif" width="70" height="35" border="0" name="ROLL18" alt="내 정원으로 돌아가기"></A>
		};
	} elsif($PARAM->{MODE} eq "pollination") {
		$str .= qq{
			<A href="$PNAME?UID=$uid&MODE=main" id="ROLL18" onmouseout="HpbImgSwap('ROLL18', '$img_dir/btn18_0.gif');" onmouseover="HpbImgSwap('ROLL18', '$img_dir/btn18_1.gif');">
			<IMG src="$img_dir/btn18_0.gif" width="70" height="35" border="0" name="ROLL18" alt="내 정원으로 돌아가기"></A>
		};
	} else {
		my $mid_str = ($rudata->[1]->[8] == 1 && int(($rstatus->[9] + $JST) / 86400) < int((get_uranai_time() + $JST) / 86400))?
			qq{<A href="$PNAME?MODE=main&UID=$uid&OPT=u" id="ROLL23" onmouseout="HpbImgSwap('ROLL23', '$img_dir/btn23_0.gif');" onmouseover="HpbImgSwap('ROLL23', '$img_dir/btn23_1.gif');">
				<IMG src="$img_dir/btn23_0.gif" width="70" height="35" border="0" name="ROLL23" alt="식물에게 음악 들려주기"></A>}: "";
			
		$str .= qq{
			<table><tr>
		};
		$str .= qq{
				<td><A href="$PNAME?MODE=pedia&UID=$uid" id="ROLL01" onmouseout="HpbImgSwap('ROLL01', '$img_dir/btn01_0.gif');" onmouseover="HpbImgSwap('ROLL01', '$img_dir/btn01_1.gif');">
					<IMG src="$img_dir/btn01_0.gif" width="70" height="45" border="0" name="ROLL01" alt="순계 식물 도감 보기"></A></td>
		} if(!$RDATA->{pedia_url});
		$str .= qq{
				<td><A href="$PNAME?UID=$uid&OPT=1&MODE=album" id="ROLL02" onmouseout="HpbImgSwap('ROLL02', '$img_dir/btn02_0.gif');" onmouseover="HpbImgSwap('ROLL02', '$img_dir/btn02_1.gif');">
					<IMG src="$img_dir/btn02_0.gif" width="70" height="45" border="0" name="ROLL02" alt="꽃 농장으로 이동"></A></td>
				<td><A href="$PNAME?UID=$uid&MODE=shop" id="ROLL03" onmouseout="HpbImgSwap('ROLL03', '$img_dir/btn03_0.gif');" onmouseover="HpbImgSwap('ROLL03', '$img_dir/btn03_1.gif');">
					<IMG src="$img_dir/btn03_0.gif" width="70" height="45" border="0" name="ROLL03" alt="비료 등 필요한 물품 구입"></A></td>
				<td><A href="$PNAME?OPT=$uid&UID=$uid&MODE=album" id="ROLL04" onmouseout="HpbImgSwap('ROLL04', '$img_dir/btn04_0.gif');" onmouseover="HpbImgSwap('ROLL04', '$img_dir/btn04_1.gif');">
					<IMG src="$img_dir/btn04_0.gif" width="70" height="45" border="0" name="ROLL04" alt="지금까지 핀 꽃 앨범 보기"></A></td>
				<td><A href="$PNAME?UID=$uid&MODE=use_item" id="ROLL05" onmouseout="HpbImgSwap('ROLL05', '$img_dir/btn05_0.gif');" onmouseover="HpbImgSwap('ROLL05', '$img_dir/btn05_1.gif');">
					<IMG src="$img_dir/btn05_0.gif" width="70" height="45" border="0" name="ROLL05" alt="비료 등 다른 도구가 들어 있습니다."></A></td>
			</tr>
			</table><table>
			<tr>
				<td><A href="$PNAME?UID=$uid&MODE=whole_hist" id="ROLL11" onmouseout="HpbImgSwap('ROLL11', '$img_dir/btn11_0.gif');" onmouseover="HpbImgSwap('ROLL11', '$img_dir/btn11_1.gif');">
					<IMG src="$img_dir/btn11_0.gif" width="70" height="35" border="0" name="ROLL11" alt="최근 소식 보기"></A></td>
				<td><A href="$PNAME?UID=$uid&MODE=album" id="ROLL12" onmouseout="HpbImgSwap('ROLL12', '$img_dir/btn12_0.gif');" onmouseover="HpbImgSwap('ROLL12', '$img_dir/btn12_1.gif');">
					<IMG src="$img_dir/btn12_0.gif" width="70" height="35" border="0" name="ROLL12" alt="다른 사용자의 앨범 보기"></A></td>
				<td><A href="$PNAME?UID=$uid&MODE=no_cook" id="ROLL13" onmouseout="HpbImgSwap('ROLL13', '$img_dir/btn13_0.gif');" onmouseover="HpbImgSwap('ROLL13', '$img_dir/btn13_1.gif');">
					<IMG src="$img_dir/btn13_0.gif" width="70" height="35" border="0" name="ROLL13" alt="다른 사용자의 식물 보기"></A></td>
		};
		$str .= qq{
				<td><A href="$PNAME?UID=$uid&MODE=bbs" id="ROLL14" onmouseout="HpbImgSwap('ROLL14', '$img_dir/btn14_0.gif');" onmouseover="HpbImgSwap('ROLL14', '$img_dir/btn14_1.gif');">
					<IMG src="$img_dir/btn14_0.gif" width="70" height="35" border="0" name="ROLL14" alt="게시판 읽기/쓰기"></A></td>
		} if(defined($RDATA->{bbs}));
		$str .= qq{
				<td><A href="$PNAME?UID=$uid&MODE=mail&OPT=3" id="ROLL15" onmouseout="HpbImgSwap('ROLL15', '$img_dir/btn15_0.gif');" onmouseover="HpbImgSwap('ROLL15', '$img_dir/btn15_1.gif');">
					<IMG src="$img_dir/btn15_0.gif" width="70" height="35" border="0" name="ROLL15" alt="다른 사용자에게 메일 보내기"></A></td>
			</tr>
			</table><table>
			<tr>
				<td><A href="$PNAME?UID=$uid&MODE=reg_change" id="ROLL21" onmouseout="HpbImgSwap('ROLL21', '$img_dir/btn21_0.gif');" onmouseover="HpbImgSwap('ROLL21', '$img_dir/btn21_1.gif');">
					<IMG src="$img_dir/btn21_0.gif" width="70" height="35" border="0" name="ROLL21" alt="등록 정보를 변경하기"></A></td>
				<td width='100' align='center'>$mid_str</td>
				<td><A href="$RDATA->{home_url}" id="ROLL22" onmouseout="HpbImgSwap('ROLL22', '$img_dir/btn22_0.gif');" onmouseover="HpbImgSwap('ROLL22', '$img_dir/btn22_1.gif');">
					<IMG src="$img_dir/btn22_0.gif" width="70" height="35" border="0" name="ROLL22" alt="로그아웃"></A></td>
			</tr></table>
		};
	}
	$str .= qq{
			</td>
		</tr><tr><td colspan='4' align='center' nowrap>
			<a href='$PNAME?UID=$uid&MODE=score_table&OPT=a'>
			<img src="$img_dir/btn44.gif" width="78" height="20" border="0" alt="순계 컬렉터왕"></A>
			<a href='$PNAME?UID=$uid&MODE=score_table&OPT=c'>
			<img src="$img_dir/btn41.gif" width="78" height="20" border="0" alt="식물 컬렉터왕"></A>
			<a href='$PNAME?UID=$uid&MODE=score_table&OPT=p'>
			<img src="$img_dir/btn40.gif" width="78" height="20" border="0" alt="자산왕"></A>
			<a href='$PNAME?UID=$uid&MODE=score_table&OPT=s'>
			<img src="$img_dir/btn42.gif" width="78" height="20" border="0" alt="식물 평가왕"></A>
			<a href='$PNAME?UID=$uid&MODE=score_table&OPT=f'>
			<img src="$img_dir/btn43.gif" width="78" height="20" border="0" alt="교배 인기왕"></A>
			</td>
		</tr>
	};
	if($PARAM->{MODE} eq "main" || $PARAM->{MODE} eq "into_album"
		|| $PARAM->{MODE} eq "login" || $PARAM->{MODE} eq "regist" 
		|| $PARAM->{MODE} eq "sow_item" || $PARAM->{MODE} eq "reg_change") {
	
		$str .= get_self_history_htm($uid);
	}
	$str .= qq{
				</table></center></td>
			</tr></table></td></tr></table>
			<INPUT TYPE="hidden" NAME="UID" value='$uid'>
			<INPUT TYPE="hidden" NAME="MODE" value='main'>
			</center></form>
	};
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_uname_htm
{
	my $udata = shift;
	my $ken;
	
	my $uname = "$udata->[1] ";
	if($udata->[9]) {
		my ($url, $mail, $sex, $kent) = (@$udata)[3, 4, 5, 6];
		$ken = "($kent)" if($kent && $kent ne "---");
		$uname .= qq{<a href="mailto:$mail"><img src='$RDATA->{img_dir}/u_icon01.gif' border='0' alt='메일 보내기'></a>\n} if($mail);
		$uname .= qq{<a href="$url"><img src='$RDATA->{img_dir}/u_icon02.gif' border='0' alt='홈페이지 보기'></a>\n} if($url && $url ne "http://");
		$uname .= qq{<img src='$RDATA->{img_dir}/u_icon03.gif' border='0' alt='남성'>\n} if($sex eq "남성" || $sex eq "남성");
		$uname .= qq{<img src='$RDATA->{img_dir}/u_icon04.gif' border='0' alt='여성'>\n} if($sex eq "여성" || $sex eq "여성");
	}
	
	return "<b>$uname</b><font size='-1'>$ken</font>";
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_announce_htm
{
	my ($uid, $rstatus) = @_;
	my ($oji_say);
	
	my $kyu    = $rstatus->[3];
	my $rplant = get_plant_data($uid);
	my $roji = $RDATA->{oji_say};

	foreach (values(%$rplant)) {
		my ($grow_level, $place_score, $water_score, $nut_score, $place)
			= (@$_)[5, 6, 9, 12, 15];
		if(($grow_level == 10 || $grow_level == 6) && $rstatus->[5] >= 1) {
			$oji_say .= $roji->{sow_seed} || "도구함에 있는 씨앗을 심으면 다시 식물을 키울 수 있습니다.";
		} elsif($grow_level <= 5) {
			if($kyu <= 3 && $place_score < 8 - $kyu) {
				if($place == 3) {
					$oji_say .= $roji->{move_in}
						|| "식물을 집 안으로 옮기는 것이 좋겠습니다.";
				} elsif($place == 1) {
					$oji_say .= $roji->{move_out}
						|| "식물을 집 밖으로 옮기는 것이 좋겠습니다.";
				}
			} elsif($place_score <= 7) {
				$oji_say .= $roji->{anal_item};
				if(!$roji->{anal_item}) {
					$oji_say .= (rand() < 0.7)? "
						「토양 시험지」와 「토양 분석 키트」를 사용하면 식물을 집 안에 둘지 밖에 둘지 확인할 수 있습니다.<br>
						햇빛 눈금이 올라가는 중에는 위치를 바꾸지 마세요.<br>
						내려가기 시작하면 위치를 바꾸세요.<br>
					": "
						「토양 시험지」는 빗나갈 수도 있으니 결과가 애매할 때는<br>
						몇 번 더 사용해서 확인해 보는 것이 좋습니다.<br>
					";
				}
			}
			if($kyu <= 3 && $water_score < 8 - $kyu) {
				$oji_say .= "그리고 " if ($oji_say);
				$oji_say .= $roji->{give_water} || "물을 주는 것이 좋겠습니다.";
			}
			if($kyu <= 3 && $nut_score < 8 - $kyu) {
				$oji_say .= "또 " if ($oji_say);
				$oji_say .= $roji->{give_nut} || "영양이 부족한 것 같습니다.
					상점에서 비료를 구입한 뒤 「도구함」에서 주세요.";
			}
		}
	}
	
	my $level_s = $RDATA->{level_setting}->[0]->[0] || $RDATA->{kyuu}->[0];
	my $level_e = $RDATA->{level_setting}->[$RDATA->{hint}]->[0] || $RDATA->{kyuu}->[$RDATA->{hint}];
	my $announce = qq{
		<TABLE width="100%" border="0" cellspacing="1" style="border-top-width: 2px; border-right-width: 2px; border-bottom-width: 2px; border-left-width: 2px; border-style: dotted; border-color: green;">
		<tr><td>
		<table border='0'><tr>
			<td><img src='$RDATA->{img_dir}/ozisan02.gif' border='0'></td>
			<td><font size='-1'>
				<center>
					<b>${level_s}〜${level_e} 이용자에게, 
					팜 아저씨의 힌트</b>
				</center><br>
				$oji_say
			</font></td>
		</tr></table>
		</td></tr></table>
	} if($oji_say);
	
	return $announce;
}

###################################################
#  input:()
# retrun:
#comment: 아래 함수의 처리 내용을 설명합니다.
###################################################
sub get_flower_htm
{
	my ($uid, $rudata) = @_;
	my ($str, $pre_alert_str);
	my ($action_pid) = $PARAM->{OPT} =~ /^(\d+)!/;
	my $time   = time;
	my $rstep  = $RDATA->{step};
	my $rplant = get_plant_data($uid);
	my $rstatus = $rudata->[0];
	
	if(($PARAM->{MODE} eq "use_item" || $PARAM->{MODE} eq "main") && $rplant->{"$action_pid"}) {
		$pre_alert_str = change_plant_situation($rudata->[1],
			$rplant->{"$action_pid"}, $uid);
		put_plant_data($uid, $rplant);
	}
	
	$str .= qq{<form name='plant'><center><table border='0' cellpadding='0' cellspacing='0'><tr>\n};
	my $cnt = 0;
	my @pids = reverse(sort {$a <=> $b} keys(%$rplant));
	foreach my $pid (@pids){
		my ($item_img, $place_ico, $in_out);
		my $rdata     = $rplant->{"$pid"};
		my $alert_str = $pre_alert_str if($pid == $action_pid);
		my $grow_step = $rdata->[5];
		
		#see change_plant_data
		if($rdata->[15] <= 1) {
			$place_ico = "$RDATA->{img_dir}/naka_l.gif"; $in_out = 1;
		} else {
			$place_ico = "$RDATA->{img_dir}/soto_l.gif"; $in_out = 2;
		}
		my $bgcol  = get_time_bgcol($time, $rdata->[15]);
		$item_img .= "<img src='$RDATA->{img_dir}/itm02.gif'>" if($rdata->[26] & 1);
		$item_img .= "<img src='$RDATA->{img_dir}/itm03.gif'>" if($rdata->[26] & 2);
		$item_img .= "<img src='$RDATA->{img_dir}/itm01.gif'>" if($rdata->[26] & 4);
		$item_img .= "<hr>" if($item_img);
		
		$str .= qq{
			<td><table width="225" border="0" cellspacing="0" cellpadding="0"><tr><td bgcolor="#008800"> 
			<table border="0" cellspacing="1" cellpadding="2" height="100%" width="100%">
				<tr><td bgcolor="#bbffbb" align="left" class='table_top flower_top' nowrap>
		};
		$str .= get_top_plant_name_htm($rdata, $pid, $cnt);
		$str .= qq{
				</td></tr><tr><td bgcolor="#FFFFFF" align="center" class='table_bottom'><table>
					<tr><td colspan='3' align='center'>
		};
		$str .= get_flower_img_htm($uid, $pid, $grow_step, "bgcolor='$bgcol'");
		$str .= qq{
						</td><td rowspan='2' valign='top' nowrap>
							$item_img
							<b><font size='-1'>단계：$rstep->[$grow_step]->[0]</font></b><br>
							<b><font size='-1'>위치：<img src='$place_ico' border='0'></font></b><br>
		};
		if($PARAM->{MODE} ne "use_item" && $PARAM->{MODE} ne "no_cook") {
			$str .= qq{<input type="button" value='물 주기' onClick="go_water($pid)"><br>\n} if($grow_step != 5);
			$str .= qq{<input type="button" value='위치 변경' onClick="go_place($pid, $in_out)"><br>\n};
			if($grow_step == 5) {
				my $rcreature  = $rdata->[3];
				my $pure_flg   = defined(get_represent_flower($rcreature));
				my $flower_cnt = $rstatus->[11];
				my $flower_max = $rstatus->[10];
				my $seed_rest  = $rstatus->[6] - $rstatus->[5];
				my $add_hint   = " ※종합평가의 10배 금액";
				$add_hint     .= "와 ${seed_rest}개분의 씨앗 판매 금액" if($seed_rest > 0 && !$pure_flg);
				$add_hint     .= "을 얻습니다.";
				my $alb_button = ($flower_cnt >= $flower_max)?
					qq{<font size='-1' color='red'>앨범이 가득 차서<br>저장할 수 없습니다<br></font>}:
					qq{<input type="button" value='앨범에 보관' onClick="if(confirm('「$rdata->[1]」 이름으로 결정하여 앨범에 저장하시겠습니까? $add_hint')) {location.href='$PNAME?UID=$uid&PID=$pid&MODE=into_album'}">};
				$str .= ($pure_flg)? qq{
							<br><b><font size='-1' color='red'>수분할 수 없는 식물입니다<br>앨범에 저장해 주세요</font></b><br>
							<hr>$alb_button<hr>
				}: qq{
							<hr><input type="button" value='수분 작업($seed_rest)' onClick="location.href='$PNAME?UID=$uid&PID=$pid&MODE=pollination'">
							<hr>$alb_button<hr>
				};
				my $rstat = get_flower_status_data($rcreature, $pure_flg);
				$str .= get_flower_status($rstat);
				$str .= qq{<hr><font size='-1'>교배료: $rdata->[24]/$rdata->[23]</font><br>}
					if(!$pure_flg);
			}
		}
		if($alert_str) {
			$str .= qq{<table border='1'><tr><td><font size='-2' color='red'>$alert_str</font></td></tr></table><br>\n};
		}
		$str .= qq{</td></tr>\n};
		$str .= get_scale_htm($rdata);
		$str .= qq{
				</table></td></tr>
			</table></td></tr></table></td>
		};
		$cnt++;
	}
	$str .= qq{
		</tr></table></center></form>
		<form name='go_main'>
		<input type='hidden' name='UID' value='$uid'>
		<input type='hidden' name='MODE' value='main'>
		<input type='hidden' name='OPT' value=''>
		<input type='hidden' name='NUM' value=''>
		</form>
	};
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment: 자동 판매 예상 금액을 계산합니다.
#        순계 식물 또는 이익이 없으면 undef를 반환합니다.
###################################################
sub get_auto_seed_sell
{
	my ($pure_flg, $rstatus, $rcreature) = @_;
	my $rstat      = get_flower_status_data($rcreature);
	my $seed_rest  = ($rstatus->[6] - $rstatus->[5]) 
		* ($rstat->[0]->[0] - $RDATA->{plli_plice});
		
	if($pure_flg || $seed_rest <= 0) {return undef;}

	return $seed_rest;
}

###################################################
#  input:()
# retrun:
#comment: 식물 상태 변경 및 아이템 사용 처리
###################################################
sub change_plant_situation
{
	my ($ritems, $rdata, $uid) = @_;
	my $alert_str;
	my ($pid, $option, $name) = split(/!/, $PARAM->{OPT});
	
	my $place = $rdata->[15];
	my $iid = $PARAM->{IID};
	my $num = $PARAM->{NUM} || 1;
	if(defined($iid)) {
		if($ritems->[$iid] <= 0) {
			return "이용할 수 없는 아이템입니다.";
#comment: 아래 함수의 처리 내용을 설명합니다.
#			exit 1;
		}
	}
	if($PARAM->{MODE} eq "use_item") {
		if($rdata->[5] < 0 || $rdata->[5] > 4) {return undef;}
		if($iid == 1) {
			if($rdata->[12] >= 9) {$alert_str = "더 이상 비료를 줄 수 없습니다.";}
			else {
				my $need_cnt = 9 - $rdata->[12];
				my $use_max = ($ritems->[1] < $need_cnt)? $ritems->[1]: $need_cnt;
				my $use_cnt = ($num < $use_max)? $num: $use_max;
				$rdata->[12] += $use_cnt;
				$ritems->[1] -= $use_cnt;
			}
		} elsif($iid == 2) {
			my $flag = ($place == 1 || $place == 2)? 1: -1;
			if(rand() < 0.2) {$flag = -$flag;}
			my $place_good = ($flag == 1)?
				"집 밖에 두는 것이 좋겠습니다.": "집 안에 두는 것이 좋겠습니다.";
			$alert_str = "토양 시험지를 사용했습니다.<br>현재 이 식물은 $place_good";
			$ritems->[2]--;
		} elsif($iid == 3) {
			my $flag = ($place == 1 || $place == 2)? 1: -1;
			my $place_good = ($flag == 1)?
				"집 밖에 두세요.": "집 안에 두세요.";
			$alert_str = "토양 분석 키트를 사용했습니다.<br>이 식물은 $place_good";
			$ritems->[3]--;
		} elsif($iid == 5) {
			if(($rdata->[26] & 1) == 0) {
				$rdata->[26] += 1;
				$alert_str = "성장 촉진제를 사용했습니다.";
				$ritems->[5]--;
			} else {
				$alert_str = "이 식물에는 이미 성장 촉진제가 사용되었습니다.";
			}
		} elsif($iid == 6) {
			if(($rdata->[26] & 2) == 0) {
				$rdata->[26] += 2;
				$alert_str = "영양/보수제 키트를 사용했습니다.";
				$ritems->[6]--; $rdata->[12] = 9; $rdata->[9] = 9;
			} else {
				$alert_str = "이 식물에는 이미 영양/보수제 키트가 사용되었습니다.";
			}
		} elsif($iid == 7) {
			if(($rdata->[26] & 4) == 0) {
				$rdata->[26] += 4;
				$alert_str = "플랜트 하우스를 사용했습니다.";
				$ritems->[7]--; $rdata->[6] = 9;
			} else {
				$alert_str = "이 식물에는 이미 플랜트 하우스가 사용되었습니다.";
			}
		}
	} else {
		$alert_str = change_plant_data($rdata, $uid);	#여기에서 $rdata가 변경되므로 주의!!
		if(defined($iid) && !defined($alert_str)) {$ritems->[$iid]--;}
	}

	return $alert_str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_top_plant_name_htm
{
	my ($rdata, $pid, $cnt) = @_;
	my $str;
	
	if($PARAM->{MODE} eq "use_item") {
		my $s_pid = (split(/!/, $PARAM->{OPT}))[0];
		my $checked = ((!defined($s_pid) && $cnt == 0) || $s_pid == $pid)? "checked": "";
		my $pname = $rdata->[1];
		$str .= qq{
				<input type='radio' name='PID' value="$pid" $checked>
				<b><font color="#003300" face="Arial, Helvetica, sans-serif">$pname</font></b>
		};
	} elsif($PARAM->{MODE} eq "no_cook") {
		my $pname = $rdata->[1];
		$str .= qq{
				<b><font color="#003300" face="Arial, Helvetica, sans-serif">$pname</font></b>
		};
	} else {
		$str .=  qq{
				<input type="text" name="NAM$pid" size="18" maxlength="16" value='$rdata->[1]'>
				<b><font color="#003300" size='-1' face="Arial, Helvetica, sans-serif">의 상태</font></b>
				<input type="button" value='이름 붙이기' onClick="go_rename($pid)">
		};
	}
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_scale_htm
{
	my $rdata = shift;
	my $rscore_str = get_score_html($rdata);
	my $str = qq{
					<tr><td align='center'>
						$rscore_str->[0]
						<img src='$RDATA->{img_dir}/sun.gif'><br>
						</td><td align='center'>
						$rscore_str->[1]
						<img src='$RDATA->{img_dir}/water.gif'><br>
						</td><td align='center'>
						$rscore_str->[2]
						<img src='$RDATA->{img_dir}/nut.gif'><br>
						</td>
					</tr>
	};
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment: $place = 1: 집 밖, 2: 집 안
###################################################
sub get_time_bgcol
{
	my ($time, $place) = @_;
	my $res_col;
	my $hour = (localtime($time))[2];
	if($place  <= 1) {
		if   (6  <= $hour && $hour < 17) {$res_col = "#ddeeee";}
		elsif(17 <= $hour && $hour < 19) {$res_col = "#e3d2b5";}
		else                             {$res_col = "#ffffdd";}
	} else {
		if   (6  <= $hour && $hour < 17) {$res_col = "#ddffff";}
		elsif(17 <= $hour && $hour < 19) {$res_col = "#ffdd99";}
		else                             {$res_col = "#dadada";}
	}
	
	return $res_col;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_plant_delete_ok_htm
{
	my $alert_str;
	my $uid = $PARAM->{UID} * 1;
	my $pid = $PARAM->{PID} * 1;

	my $rplant = get_album_data($uid) if($uid);
	if(my $rdata = $rplant->{"$pid"}) {
		$alert_str = "<font color='red'>「$rdata->[1]」을 앨범에서 삭제했습니다</font>";

		my $rudata = get_status_data($uid);
		$rudata->[0]->[11] --;
		put_status_data($uid, $rudata);

		delete($rplant->{"$pid"});
		put_all_album_data($uid, $rplant);
		
		foreach my $organ (1, 2, 3) {
			unlink("$RDATA->{album_img}/u$uid/p5_${organ}_${pid}.gif");
		}
		unlink("$RDATA->{album_img}/u$uid/bg_${pid}.gif");

		renew_pure_number_data($uid, $rplant);

		my @new_pop;
		my $rpop = get_popular_flower();
		foreach (@$rpop) {
			push(@new_pop, $_) if($_->[0] != $uid || $_->[1] != $pid);
		}
		put_popular_flower(\@new_pop);

	} else {
		$alert_str = "<font color='red'>그 식물은 삭제할 수 없습니다</font>";
	}
	my $str = get_album_htm($alert_str);
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_plant_delete_check_htm
{
	my ($alert_str) = @_;

	my $uid     = $PARAM->{UID} * 1;
	my $pid     = $PARAM->{PID} * 1;
	my $width   = ($RDATA->{album_span}) * 227;
	my $rallu   = get_all_udata_hash();
	my $rsecret = get_secret_data();
	my $rplant  = get_album_data($uid);
	my $rudata  = get_status_data($uid);
	add_album_expression_data($rplant);
	my $rstatistics_bef = get_plant_statistics($rplant, $uid, $rsecret, $rudata);
	my $rstatistics_aft = get_plant_statistics($rplant, $uid, $rsecret, $rudata, {"$pid" => 1});
	
	my $str = "Content-type: text/html\n\n";
	$str .= qq{<html><head>};
	$str .= get_head();
	$str .= qq{
		<title>사진 삭제 확인 화면</title>
		</head>
		<body bgcolor='#d1f8d8' background='' onLoad=''><center>
			$alert_str
			<table width="$width">
				<tr><td><b>삭제 전 집계</b></td></tr><tr><td align='center'>
	};
	$str .= get_totals_str($rstatistics_bef);
	$str .= qq{<tr><td><b>삭제 후 집계</b></td></tr><tr><td align='center'>\n};
	$str .= get_totals_str($rstatistics_aft);
	$str .= "<br><br>";
	$str .= get_plant_table_htm($uid, $pid, $rallu, $rsecret) if($pid);
	$str .= qq{
				</td></tr>
			</table>
		<br><font size='+1'><b>이 식물을 삭제하시겠습니까?</b></font>
		<form>
			<input type='button' value='  예  ' onClick="location.href='$PNAME?MODE=album_del_ok&UID=$uid&OPT=$uid&PID=$pid'"> 
			<input type='button' value='  아니오  ' onClick="location.href='$PNAME?MODE=album&UID=$uid&OPT=$uid'">
		</form>
	};
	$str .= get_copyright();
	$str .= "<br></center></body></html>";
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_album_htm
{
	my ($alert_str) = @_;
	my $logo;
	my $uid  = $PARAM->{UID};
	my ($suid, $mtype) = split(/!/, $PARAM->{OPT});
	if($suid == 1) {
		make_flower_shop();	#comment: 아래 함수의 처리 내용을 설명합니다.
		$logo = "<img src='$RDATA->{img_dir}/farm_ttl.gif' border='0'>";
	} else {
#		$logo = "inc_plant.gif";
	}
	
	my $rplant = get_album_data($suid) if($suid);
	add_album_expression_data($rplant);
	if((my $pcost = int($PARAM->{CST})) && $uid == $suid) {
		if(my $rdata = $rplant->{"$PARAM->{PID}"}) {
			my $max_pcost = $rdata->[23];
			if($RDATA->{plli_plice} <= $pcost && $pcost <= $max_pcost) {
				$rdata->[24] = $pcost;
				put_all_album_data($uid, $rplant);
				$alert_str = "<font color='red'>$rdata->[1]의 교배료를 $pcost$RDATA->{monney}로 변경했습니다</font>";
			} else {
				$alert_str = "<font color='red'>$rdata->[1]의 교배료는 $RDATA->{plli_plice}-$max_pcost$RDATA->{monney} 사이로 설정해 주세요</font>";
			}
		}
	}
	
	my $str = "Content-type: text/html\n\n";
	$str .= qq{<html><head>};
	$str .= get_head();
	$str .= qq{
		<title>식물 앨범</title>
		</head>
		<body bgcolor='#d1f8d8' background='' onLoad=''>
			<center>
			$logo
			$alert_str</center>
	};
	if($suid) {
		$str .= get_album_flower_htm($uid, $suid, $mtype, $rplant);
	} else {
		$str .= get_album_user_htm($mtype);
	}
	$str .= get_copyright();
	$str .= "<br></body></html>";
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_album_flower_htm
{
	my ($uid, $suid, $mtype, $rplant) = @_;
	my ($str, @totals);
	my $rsecret  = get_secret_data();
	my $time     = time;
	my $property = get_user_property($uid) if($mtype eq "p");
	my $mode = ($mtype eq "c")? "no_cook":
		($mtype eq "a" || $mtype eq "p")? "album":
		($mtype eq "b")? "bbs": "main";

	my $href = "$PNAME?MODE=$mode&UID=$uid&PID=$PARAM->{PID}";
	$href .= "&OPT=!p" if($mtype eq "p");
	my $button_str = ($PARAM->{BT})?
		qq{<input type='button' value='돌아가기' onClick='history.back()'>}:
		qq{<input type='button' value=' 돌아가기 ' onClick="location.href='$href'">};

	$str .= get_sort_link_htm($uid, $suid, $button_str);

	my $rfpid = get_filtered_pid($rplant, $suid);
	$str .= get_page_link_htm($uid, scalar(keys(%$rfpid)));
	my $rpid    = get_sort_pid($rplant);
	my $rpid_ok = get_cut_ok_pid($rpid, $rfpid);
	my $rudata  = get_status_data($suid);
	my $span    = $RDATA->{album_span};
	my $rstatistics = get_plant_statistics($rplant, $suid, $rsecret, $rudata);
	my $cnt = 0;
	foreach my $pid (@$rpid_ok) {
		my $rdata     = $rplant->{"$pid"};
		my ($rcreature, $big_cost, $set_cost) = (@$rdata)[3, 23, 24];
		my $pure_flg  = (-e "$RDATA->{album_img}/u$suid/bg_${pid}.gif")? 1: 0;
		my $rstat     = get_flower_status_data($rcreature, $pure_flg);
		my $is_secret = get_secret_type($rsecret, $rcreature);
		my $seed_cost = ($uid == $suid)? $RDATA->{plli_plice}: $set_cost;

		my $bgcol = get_flower_bgcolor($rcreature);
		my $tr  = ($cnt % $span == 0)? "<tr>":  "";
		my $etr = ($cnt % $span == $span - 1)? "</tr>": "";
		my $pname = $rdata->[1];
		my ($bg_view, $icon_img);
		if($pure_flg) {
			$bg_view  = "background='$RDATA->{album_img}/u$suid/bg_${pid}.gif'";
			$icon_img = "<img src='$RDATA->{img_dir}/pure.gif' border='0'>";
		} else {
			$bg_view = "bgcolor='$bgcol'";
		}
		$icon_img .= "<img src='$RDATA->{img_dir}/secret.gif' border='0'>" if($is_secret);
		$icon_img .= "<br>\n" if($icon_img);
		$str .= qq{
			$tr<td valign='bottom'>
			<table width="225" border="0" cellspacing="0" cellpadding="0"><tr><td bgcolor="#008800"> 
			<table border="0" cellspacing="1" cellpadding="2" height="100%" width="100%">
				<tr><td bgcolor="#bbffbb" align="center" class='table_top flower_top'>
					<b><font color="#003300" face="Arial, Helvetica, sans-serif">$pname</font></b>
				</td></tr>
				<tr><td bgcolor="#FFFFFF" align="center" class='table_bottom'>
					<table><tr>
						<td colspan='3' align='center'>
		};
		$str .= get_flower_img_htm($suid, $pid, $rdata->[5], $bg_view);
		$str .= qq{
						</td><td valign='top'>
							$icon_img
		};
		$str .= get_flower_status($rstat);
		$str .= "<hr><font size='-1'>촬영일: <br>" . get_day_str($rdata->[25]) . "</font><br>\n"
			if($suid != 1);
			
		if($mtype eq "p") {
			my $href = "$PNAME?MODE=pollination&UID=$uid&PID=$PARAM->{PID}&OPT=$suid!$pid";
			$str .= ($pure_flg)? qq{
				<hr><b><font size='-1'>수분할 수 없습니다</font></b>
			}: qq{
				<hr><font size='-1'>교배료: $set_cost/$big_cost</font><br>
				<b><font size='-1'>교배료：$seed_cost$RDATA->{monney}</font></b><br>
				<br><input type='button' value='수분하기' onClick='if(confirm("이 식물과 수분하여 씨앗을 얻으시겠습니까?")) location.href="$href"'>
			};
		} elsif($mtype eq "b") {
			my $href = "$PNAME?MODE=bbs&UID=$uid&PID=$pid";
			$str .= qq{<hr><font size='-1'>교배료: $set_cost/$big_cost</font><br>} if(!$pure_flg);
			$str .= qq{<input type='button' value='첨부하기' onClick='location.href="$href"'>};
		} elsif($uid == $suid) {
			my $href = "$PNAME?UID=$uid&PID=$pid";
			$str .= ($pure_flg)? qq{
				<hr>
			}: qq{
				<hr><font size='-1'>교배료: 
				<input type='text' name='cst$pid' size="4" MAXLENGTH="5" value='$set_cost'>/$big_cost</font><br>
				<input type='button' value='교배료변경' onClick='location.href="$href&MODE=album&OPT=$uid&CST="+this.form.cst$pid.value'>
			};
			$str .= qq{
				<input type='button' value='사진 삭제' onClick='location.href="$href&MODE=album_del"'>
			}
		} else {
			$str .= ($pure_flg)? qq{
				<hr>
			}: qq{
				<hr><font size='-1'>교배료: $set_cost/$big_cost</font><br>
			};
		}
		$str .= qq{
						</td>
					</tr></table>
				</td></tr>
			</table></td></tr></table>
			</td>$etr
		};
		$cnt++;
	}
	for(my $tr_cnt = 0; $tr_cnt < ($span - 1) - (($cnt - 1) % $span); $tr_cnt++) {
		$str .= "<td></td></tr>";
	}
	
	my $total_str = qq{
		<form name='sbm' action='$PNAME' method="$RDATA->{method}">
			<input type='hidden' name='MODE' value='ch_comment'>
			<input type='hidden' name='UID' value='$uid'>
			<input type='hidden' name='OPT' value='$uid'>
			<input type='hidden' name='SBJ' value=''>
			<input type='hidden' name='CMT' value=''>
		</form>
	} if($uid == $suid);
	$total_str .= qq{
		<form name='plant' onSubmit='return false'><center>
		<table border='0' cellpadding='0' cellspacing='0' bgcolor='#88dd88' class='table_top album_middle'>
			<tr><td colspan='$RDATA->{album_span}'>
	};
	$total_str .= get_album_top_htm($uid, $suid, $mtype)
		if($suid != 1 && $PARAM->{MODE} ne 'bbs_sel_album');
	
	$total_str .= get_totals_str($rstatistics);
	$total_str .= "</td></tr>";
	$total_str .= $str;
	$total_str .= qq{
			<tr><td colspan='$RDATA->{album_span}'>
			<table width="100%" border="0" cellspacing="0" cellpadding="0"><tr><td bgcolor="#008800"> 
			<table border="0" cellspacing="1" cellpadding="2" height="100%" width="100%">
				<tr><td bgcolor="#bbffbb" align="center" class='table_top album_bottom'>
					$button_str
				</td></tr>
			</table></td></tr></table></td></tr>
		</table></center></form>
	};
	
	return $total_str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_album_top_htm
{
	my ($uid, $suid, $mtype) = @_;
	my ($alb_subj, $alb_cmnt);
	
	my $udata = get_udata($suid);
	my $uname = $udata->[1];
	
	if($uid != $suid || $mtype eq "a" || $mtype eq "p") {
		$alb_subj = "<hr size='1' noshade><font size='+1'>$udata->[11]</font><hr size='1' noshade>"
			if ($udata->[11]);
			
		$alb_cmnt = "<font size='-1'>$udata->[12]</font>" if ($udata->[12]);
	} else {
		my $js = "document.sbm.SBJ.value=this.form.sbj.value;";
		$js   .= "document.sbm.CMT.value=this.form.cmt.value;";
		$js   .= "document.sbm.submit();";
		my $comment = $udata->[12]; $comment =~ s/<br>/\n/g;
		$alb_subj = qq{
			<hr size='1' noshade>
			<input type='text' name='sbj' size='50' maxlength='50' value='$udata->[11]'>
			<font size='-1'><b>←(영문 기준 50자까지)</b></font><hr size='1' noshade>
		};
		$alb_cmnt = qq{
			<center><table>
			<tr>
				<td><textarea name='cmt' rows='5' cols='58' wrap='hard'>$comment</textarea></td>
				<td><font size='-1'><b>←댓글(영문 기준 800자까지)</b></font></td>
			</tr>
			<tr><td align='center'>
				<input type='button' value='내용갱신' onClick="$js"></td></tr>
			</table></center>
		};
	}
	my $albt_str = "<font size='-2'><b>갱신일시: " . get_daytime_str($udata->[13])
		. "</b></font>" if ($udata->[13]);
	my $str = qq{
		<table cellspacing="0" cellpadding="0" width='100%'>
			<tr>
				<td bgcolor="#008200" class='album_score'></td>
				<td bgcolor="#008200" class='album_score' width="7" height="7"></td>
				<td bgcolor="#008200" class='album_score'></td>
			</tr><tr>
				<td align="center" bgcolor="#008200" width="7" rowspan="2" class='album_score'></td>
				<td align="center" bgcolor="#ccffff" class='table_bottom album_in'>
					<table cellspacing="0" cellpadding="0" width="500">
						<tr><th><font size='+1'><br>$uname님의 앨범</font></th></tr>
						<tr><td align="center">$alb_subj</td></tr>
						<tr><td>$alb_cmnt</td></tr>
						<tr><td align='right'><br>$albt_str</td></tr>
					</table>
				</td><td align="center" bgcolor="#008200" width="7" rowspan="2" class='album_score'></td>
			</tr><tr>
				<td height='22' bgcolor="#ccffff" class='table_bottom album_in album_in_img' background="$RDATA->{img_dir}/farm_line.gif">
				</td>
			</tr><tr>
				<td bgcolor="#008200" class='album_score'></td>
				<td bgcolor="#008200" class='album_score' width="7" height="7"></td>
				<td bgcolor="#008200" class='album_score'></td>
			</tr>
		</table>
	};
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
#	$rstat->[0] = [total_score, rep_id]
#	      ->[1] = [score, im_id]
#	      .
#	      .
#	      .
#
#	$rtotals->[0]->[organ]->{im_id or rep_id} = 1
#	        ->[1]->[organ] = [total_score, min, max]
#	        ->[2] = total_big_cost
#	        ->[3] = total_set_cost
#	        ->[4] = plant_total_count
#        식물 목록 HTML을 조합합니다.
###################################################
#sub add_totals
#{
#	my ($rtotals, $rstat, $big_cost, $set_cost) = @_;
#	
#	for(my $cnt = 0; $cnt <= 3; $cnt++) {
#		$rtotals->[0]->[$cnt]->{"$rstat->[$cnt]->[1]"} = 1;
#		my $score = $rstat->[$cnt]->[0];
#		$rtotals->[1]->[$cnt]->[0] += $score;
#		my $min = $rtotals->[1]->[$cnt]->[1];
#		$rtotals->[1]->[$cnt]->[1] = $score if(!$min || $min > $score);
#		my $max = $rtotals->[1]->[$cnt]->[2];
#		$rtotals->[1]->[$cnt]->[2] = $score if(!$max || $max < $score);
#	}
#	$rtotals->[2] += $big_cost;
#	$rtotals->[3] += $set_cost;
#	$rtotals->[4]++;
#	
#	return 1;
#}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_plant_statistics
{
	my ($rplant, $uid, $rsecret, $rudata, $rcut_pid) = @_;
	
	my (%sec_counter, @im_counter, @score);
	my ($plant_cnt, $big_total_cost, $set_total_cost, $pure_cnt) = (0, 0, 0, 0);
	while(my ($pid, $rdata) = each(%$rplant)) {
		if(defined($rcut_pid) && $rcut_pid->{"$pid"}) {next;}
		$plant_cnt ++;
		my ($rcreature, $big_cost, $set_cost) = (@$rdata)[3, 23, 24];
		my $sec_type = get_secret_type($rsecret, $rcreature);
		$sec_counter{"$sec_type"} = 1 if($sec_type);
		my $pure_flg  = (-e "$RDATA->{album_img}/u$uid/bg_${pid}.gif")? 1: 0;
		my $rstat     = get_flower_status_data($rcreature, $pure_flg);

		if($pure_flg) {
			$pure_cnt ++;
		} else {
			$big_total_cost += $big_cost;
			$set_total_cost += $set_cost;
		}
		
		for(my $cnt = 0; $cnt <= 3; $cnt++) {
			my $im_id = $rstat->[$cnt]->[1];
			$im_counter[$cnt]->{"$im_id"} = 1 if(defined($im_id));
			my $each_score = $rstat->[$cnt]->[0];
			$score[$cnt]->{total} += $each_score;
			my $min = $score[$cnt]->{min};
			$score[$cnt]->{min} = $each_score if(!$min || $min > $each_score);
			my $max = $score[$cnt]->{max};
			$score[$cnt]->{max} = $each_score if(!$max || $max < $each_score);
		}
	}
	if($plant_cnt == 0) {return {};}
	#comment: 아래 함수의 처리 내용을 설명합니다.
	my $pures = $plant_cnt - $pure_cnt || 1;
	
	return {
		plant_cnt   => $plant_cnt,
		plant_total => ($uid == 1)? undef: $rudata->[0]->[12],
		plant_max   => ($uid == 1)? undef: $rudata->[0]->[10],
		secret_cnt  => scalar(keys(%sec_counter)),
		pure_cnt    => scalar(keys(%{$im_counter[0]})),
		stem_cnt    => scalar(keys(%{$im_counter[1]})),
		leaf_cnt    => scalar(keys(%{$im_counter[2]})),
		flower_cnt  => scalar(keys(%{$im_counter[3]})),
		set_ave_cst => int($set_total_cost / $pures + 0.5),
		max_ave_cst => int($big_total_cost / $pures + 0.5),
		total_score => {
			max => $score[0]->{max},
			min => $score[0]->{min},
			ave => int($score[0]->{total} / $plant_cnt + 0.5),
		},
		strng_score => {
			max => $score[1]->{max},
			min => $score[1]->{min},
			ave => int($score[1]->{total} / $plant_cnt + 0.5),
		},
		smell_score => {
			max => $score[2]->{max},
			min => $score[2]->{min},
			ave => int($score[2]->{total} / $plant_cnt + 0.5),
		},
		beaut_score => {
			max => $score[3]->{max},
			min => $score[3]->{min},
			ave => int($score[3]->{total} / $plant_cnt + 0.5),
		},
	};
}

###################################################
#  input:()
# retrun:
#comment:album.cgi을열기
###################################################
sub get_pure_count
{
	my ($rplant) = @_;
	my %counter;
	
	foreach (values(%$rplant)) {
		my $rcreature = get_expression_data((@$_)[16, 17]);
		if(defined(my $rep_id = get_represent_flower($rcreature))) {
			$counter{"$rep_id"} = 1;
		}
	}
	my $pure_count = keys(%counter);
	
	return $pure_count;
}

###################################################
#  input:()
# retrun:
#comment:album.cgi을열기
###################################################
sub renew_pure_number_data
{
	my ($uid, $rplant) = @_;
	
	my $pure_cnt  = get_pure_count($rplant);

	my $rusr_pure = get_user_pure_count_data();
	$rusr_pure->{"$uid"} = $pure_cnt;
	put_user_pure_count_data($rusr_pure);
	
	return 1;
}

###################################################
#  input:()
# retrun:
#comment:
#	$rtotals->[0]->[organ]->{im_id or rep_id} = 1
#	        ->[1]->[organ] = [total_score, min, max]
#	        ->[2] = total_big_cost
#	        ->[3] = total_set_cost
#	        ->[4] = plant_total_count
###################################################
sub get_totals_str
{
	my ($rstatis) = @_;
	my $str;
	
	my $plant_cnt = $rstatis->{plant_cnt};
#	my ($rim, $rscore, $big_cst, $set_cst, $pln_cnt, $seq_num)
#		= @$rtotals;
	if(!$plant_cnt) {return "";}
#	$seq_num = 0 if(!$seq_num);
	
	$str .= qq{
		<table width="100%" border="0" cellspacing="0" cellpadding="0"><tr><td bgcolor="#008800"> 
		<table border="0" cellspacing="1" cellpadding="2" height="100%" width="100%">
		<tr bgcolor="#44aa44" class='album_score'>
			<th><font size='-1'>식물 수</font></th>
			<th><font size='-1'>비밀</font></th>
			<th><font size='-1'>순계 수</font></th>
			<th><font size='-1'>종합평가</font></th>
			<th><font size='-1'>꽃</font></th>
			<th><font size='-1'>아름다움</font></th>
			<th><font size='-1'>잎</font></th>
			<th><font size='-1'>향기</font></th>
			<th><font size='-1'>줄기</font></th>
			<th><font size='-1'>튼튼함</font></th>
			<th><font size='-1'>평균교배료</font></th>
		</tr><tr bgcolor="white" class='table_bottom score_bottom'>
	};
	
	my $plant_max   = "/$rstatis->{plant_max}" if($rstatis->{plant_max});
	my $plant_total = "누계: $rstatis->{plant_total}그루<br>" if($rstatis->{plant_total});
	$str .= qq{
		<td align='left'><font size='-1'>$plant_total저장: $plant_cnt$plant_max그루</font></td>
		<td align='right'><font size='-1'>$rstatis->{secret_cnt}씨앗</font></td>
	};
	
	for(my $asc = 0; $asc <= 3; $asc++) {
		my $cnt_typ = ("pure_cnt", "flower_cnt", "leaf_cnt", "stem_cnt")[$asc];
		my $sta_typ = ("total_score", "beaut_score", "smell_score", "strng_score")[$asc];
		$str .= qq{<td align='right'><font size='-1'>$rstatis->{$cnt_typ}씨앗</font></td>\n};
		my $av_score  = $rstatis->{$sta_typ}->{ave};
		my $min_score = $rstatis->{$sta_typ}->{min};
		my $max_score = $rstatis->{$sta_typ}->{max};
		$str .= qq{
			<td><font size='-1'>
			최고: $max_score<br>
			평균: $av_score<br>
			최소: $min_score<br>
			</font></td>
		};
	}
	$str .= qq{
		<td align='left'><font size='-1'>
			설정: $rstatis->{set_ave_cst}$RDATA->{monney}<br>
			최대: $rstatis->{max_ave_cst}$RDATA->{monney}
		</font></td>
	};
	$str .= "</tr></table></td></tr></table>";
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_sort_link_htm
{
	my ($uid, $suid, $button_str) = @_;
	my (@selected, @selcut);
	my $bt   = $PARAM->{BT};   my $opt = $PARAM->{OPT}; my $pid  = $PARAM->{PID};
	my $sort = $PARAM->{SORT}; my $cut = $PARAM->{CUT}; my $md   = $PARAM->{MODE};
	my $mode = ($md eq "ch_comment" || $md eq "album_del_ok")? "album": $PARAM->{MODE};
	
	my $num = 0;
	foreach ('picday!1!', 'tscore!1!', 'dtype!3!', 'dtype!2!', 'dtype!1!') {
		$selected[$num] = "selected" if($sort =~ /^$_/); $num++;
	}
	$num = 1;
	foreach ('p', 's') {
		$selcut[$num] = "selected" if($cut eq $_); $num++;
	}
	
	my $add_str = qq{
					<option value='picday!1!' $selected[0]>촬영일순</option>
					<option value='tscore!1!' $selected[1]>종합평가순</option>
	} if($uid != 1 && $suid != 1);
	
	my $href_str = qq{'$PNAME?MODE=$mode&UID=$uid&OPT=$opt&BT=$bt&PID=$pid&CUT='};
	$href_str .= qq{+this.form.filter.options[this.form.filter.selectedIndex].value};
	$href_str .= qq{+'&SORT='+this.form.pat.options[this.form.pat.selectedIndex].value};
	my $col_span = $RDATA->{album_span};
	my $str = qq{
		<tr height='25' bgcolor="#44aa44" class='album_score'>
			<td colspan='$col_span'>
				<table width='100%'><tr><td>
				<font color='#002200' size='-1'><b>&nbsp;
					<select name='filter'>
						<option value=''>전체</option>
						<option value='p' $selcut[1]>순계</option>
						<option value='s' $selcut[2]>비밀</option>
					</select>&nbsp;을&nbsp;
					<select name='pat'>
						$add_str
						<option value='dtype!3!' $selected[2]>꽃 씨앗류별</option>
						<option value='dtype!2!' $selected[3]>잎 씨앗류별</option>
						<option value='dtype!1!' $selected[4]>줄기 씨앗류별</option>
					</select>
					로 정렬
					<input type='button' value='▼' onClick="location.href=$href_str+'d'">
					<input type='button' value='▲' onClick="location.href=$href_str+'a'">
				</b></font>
				</td><td align='right'>$button_str&nbsp;&nbsp;</td></tr></table>
			</td>
		</tr>
	};
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_page_link_htm
{
	my ($uid, $plant_cnt) = @_;
	my $md     = $PARAM->{MODE};
	my $bt     = $PARAM->{BT};
	my $opt    = $PARAM->{OPT};
	my $sort   = $PARAM->{SORT};
	my $cut    = $PARAM->{CUT};
	my $pid    = $PARAM->{PID};	#교배시에필요
	my $mode   = ($md eq "ch_comment" || $md eq "album_del_ok")? "album": $PARAM->{MODE};
	my $suid   = (split(/!/, $PARAM->{OPT}))[0];
	my $pag    = $PARAM->{PAGE}; $pag = 1 if($pag <= 0);
	my $pgf    = $RDATA->{album_span} * $RDATA->{album_step};
	my $pg_cnt = int(($plant_cnt - 1 + $pgf) / $pgf);
	
	my $bpag = $pag - 1; my $npag = $pag + 1;
	my $bef = ($bpag == 0)?      "＜": qq{<a href='$PNAME?MODE=$mode&UID=$uid&OPT=$opt&PID=$pid&BT=$bt&SORT=$sort&CUT=$cut&PAGE=$bpag'>＜</a>};
	my $nex = ($npag > $pg_cnt)? "＞": qq{<a href='$PNAME?MODE=$mode&UID=$uid&OPT=$opt&PID=$pid&BT=$bt&SORT=$sort&CUT=$cut&PAGE=$npag'>＞</a>};
	my $str = qq{
		<tr height='25'>
			<td bgcolor="#88dd88" colspan='$RDATA->{album_span}' class='table_top album_top'>
			<font color='#002200' size='-1'><b>합계$pg_cnt페이지：</b>
			$bef&nbsp;
	};
	for(my $pg = 1; $pg <= $pg_cnt; $pg++) {
		$str .= ($pg != $pag)? qq{
			<a href='$PNAME?MODE=$mode&UID=$uid&OPT=$opt&PID=$pid&BT=$bt&SORT=$sort&CUT=$cut&PAGE=$pg'>$pg</a>&nbsp;
		}: "<b><font color='#aa0000'>$pg</font></b>&nbsp;";
	}
	$str .= qq{
			$nex
			</font>
		</td></tr>
	};
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_filtered_pid
{
	my ($rplant, $uid) = @_;
	my %new_pid;
	
	my $cut_type = $PARAM->{CUT};

	if($cut_type eq "p") {
		foreach my $pid (keys(%$rplant)) {
			if(-e "$RDATA->{album_img}/u$uid/bg_${pid}.gif") {
				$new_pid{"$pid"} = 1;
			}
		}
	} elsif($cut_type eq "s") {
		my $rsecret  = get_secret_data();
		while(my ($pid, $rp) = each(%$rplant)) {
			if(get_secret_type($rsecret, $rp->[3])) {
				$new_pid{"$pid"} = 1;
			}
		}

	} else {
		foreach my $pid (keys(%$rplant)) {
			$new_pid{"$pid"} = 1;
		}
	}
	
	return \%new_pid;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_sort_pid
{
	my $rplant = shift;
	my @pids;
	
	my ($sort_type, $opt, $sort_ad) = split(/!/, $PARAM->{SORT});
	if($sort_type) {
		my %sorter;
		if($sort_type eq "tscore") {
			foreach (values(%$rplant)) {
				push(@{$sorter{"$_->[18]"}}, $_->[0]);
			}
		} elsif($sort_type eq "dtype") {
			foreach (values(%$rplant)) {
				my $val = $_->[3]->{"$opt"};
				my $im_id = $val->{protein}->[$val->{view}->[0]]->{domain};
				push(@{$sorter{"$im_id"}}, $_->[0]);
			}
		} else {
			foreach (values(%$rplant)) {
				push(@{$sorter{"$_->[25]"}}, $_->[0]);
			}
		}
		
		if($sort_ad eq "a") {
			foreach (sort {$a <=> $b} keys(%sorter)) {
				foreach (@{$sorter{"$_"}}) {
					push(@pids, $_);
				}
			}
		} else {
			foreach (reverse(sort {$a <=> $b} keys(%sorter))) {
				foreach (@{$sorter{"$_"}}) {
					push(@pids, $_);
				}
			}
		}
	} else {
		if($sort_ad eq "a") {
			@pids = sort {$a <=> $b} keys(%$rplant);
		} else {
			@pids = reverse(sort {$a <=> $b} keys(%$rplant));
		}
	}
	
	return \@pids;
}


###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_cut_ok_pid
{
	my ($rpid, $rfpid) = @_;
	my @ok_pid;

	my $pag = $PARAM->{PAGE}; $pag = 1 if($pag <= 0);
	my $pgf = $RDATA->{album_span} * $RDATA->{album_step};
	my $cnt = 0;
	foreach (@$rpid) {
		if(!$rfpid->{"$_"}) {next;}
		if($cnt >= $pgf * ($pag - 1)) {
			if($cnt >= $pgf * $pag) {last;}
			push(@ok_pid, $_);
		}
		$cnt++;
	}
	
	return \@ok_pid;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_album_user_htm
{
	my $mtype = $_[0] || "a";
	my $str;
	
	my $uid = $PARAM->{UID}; my $pid = $PARAM->{PID};
	my $ruids = get_ordered_udata();
	my $rc    = get_rc_data();
	my $search_word = $PARAM->{WORD} if($PARAM->{WORD} eq get_safe_htm($PARAM->{WORD}));
	$ruids    = get_word_cut_udata($ruids) if($search_word);
	my $time  = time;
	my $href_str = qq{$PNAME?OPT=!$mtype&MODE=album&UID=$uid&PID=$pid&WORD=$search_word&SORT=};
	my $add_url = "$PNAME?UID=$uid&MODE=main";
	
	$str .= qq{
		<form name='sbm' action='$PNAME' method="$RDATA->{method}">
			<input type='hidden' name='OPT' value='!$mtype'>
			<input type='hidden' name='MODE' value='album'>
			<input type='hidden' name='UID' value='$uid'>
			<input type='hidden' name='PID' value='$pid'>
			<input type='hidden' name='WORD' value=''>
		</form>
		<form onSubmit='return false'><center>
		<table width="450" border="0" cellspacing="0" cellpadding="0"><tr><td bgcolor="#008800"> 
		<table border="0" cellspacing="1" cellpadding="2" height="100%" width="100%">
			<tr><td bgcolor="#bbffbb" align="center" class='table_top user_top'>
				<table width='100%'><tr>
					<td><img src='$RDATA->{img_dir}/btn12_0.gif' border='0'></td>
					<td align='center'><b>사용자 앨범을 선택해 주세요</b></td>
					<td align='right'><input type='button' value=' 돌아가기 ' onClick="location.href='$add_url'"></td>
				</tr></table>
			</td></tr>
			<tr><td bgcolor="#ffffff" align='center' class='table_bottom'>
				<b>이름에 포함된 문자로 검색할 수 있습니다:</b>
				<input type='text' name='srch' size="16" maxlength="16" value='$search_word'>
				<input type='button' value='검색' onClick='document.sbm.WORD.value=this.form.srch.value;document.sbm.submit();'>
			</td></tr>
			<tr><td bgcolor="#FFFFFF" align="center" class='table_bottom'>
				<table width='100%'><tr>
					<td colspan='3' align='center'>
						<b><a href='$PNAME?OPT=1!$mtype&UID=$uid&MODE=album&PID=$pid'>
						꽃 농장으로</a></b><hr>
						<table cellspacing="0" cellpadding="3" border='1' width='100%'>
							<tr><th nowrap>ID<input type='button' value='$rc->[0]->[0]' onClick="location.href='${href_str}id!$rc->[0]->[1]'"></th>
								<th>이름</th>
								<th>댓글</th>
								<th nowrap><table><tr>
									<th><font size='-1'>앨범<br>갱신일시</font></th>
									<td><input type='button' value='$rc->[1]->[0]' onClick="location.href='${href_str}al!$rc->[1]->[1]'"></td>
								</tr></table></th>
								<th nowrap>남은 수<input type='button' value='$rc->[2]->[0]' onClick="location.href='${href_str}ti!$rc->[2]->[1]'"></th></tr>
	};
	foreach (@$ruids) {
		my ($suid, $uname, $ac_time, $nid, $subj, $albtime) = (@$_)[0, 1, 8, 10, 11, 13];
		my $albt_str = ($albtime)? get_daytime_str($albtime): "---";
		my $rm_time  = get_remove_time($ac_time, $time);
		$subj = "&nbsp;" if(!$subj);
		$str .= "
			<tr><td align='right'>$nid</td>
				<td><b><a href='$PNAME?OPT=$suid!$mtype&UID=$uid&MODE=album&PID=$pid'>
					$uname님</a></b></td>
				<td>$subj</td>
				<td align='center'><font size='-1'>$albt_str</font></td>
				<td align='right'><font size='-1'>$rm_time</font></td>
			</tr>
		";
	}
	$str .= qq{
						</table>
					</td>
				</tr></table>
			</td></tr>
			<tr><td bgcolor="#bbffbb" align="center" class='table_top user_bottom'>
				<input type='button' value=' 돌아가기 ' onClick="location.href='$add_url'">
			</td></tr>
		</table></td></tr></table>
		</center></form>
	};
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_remove_time
{
	my ($ac_time, $time) = @_;
	my $rm_time;
	
	my $left_time = $RDATA->{delete_time} - ($time - $ac_time);
	if($left_time < 0) {
		my $till_rm = $RDATA->{term} - ($time - get_routine_time());
		$rm_time = "삭제까지${till_rm}초";
	} elsif($left_time < 60) {
		$rm_time = "${left_time}초";
	} elsif($left_time < 3600) {
		$rm_time = int($left_time / 60) . "분";
	} elsif($left_time < 86400) {
		$rm_time = int($left_time / 3600) . "시간";
	} else {
		$rm_time = int($left_time / 86400) . "일";
	}
	
	return $rm_time;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_flower_bgcolor
{
	my ($rcreature) = @_;
	my ($total, @rbg);

	while(my ($organ_id, $val) = each(%$rcreature)) {
		if($organ_id == 3) {$total += $val->{power} / 2;}
		else               {$total += $val->{power} / 4;}

		$rbg[$organ_id - 1]
			= sprintf("%x", (substr($val->{power} / 13, -1, 1) * 10
			+ substr($val->{power} / 17, -2, 1)) % 52 + 204);
	
	}
	$total = int($total);
	
	if($total <= 150) {return "#ccffff";}
	
#	my $tmax_power = 255 / $RDATA->{max_power};
#	while(my ($organ_id, $val) = each(%$rcreature)) {
#		$rbg[$organ_id - 1]
#			= sprintf("%x", int(255 - $val->{power} * $tmax_power));
#	}
	
	return "#$rbg[0]$rbg[1]$rbg[2]";
}

###################################################
#  input:()
# retrun:
#comment:
#comment: 아래 함수의 처리 내용을 설명합니다.
#수분,초,검사한초,영양,초,검사한초,위치,유전자1,유전자2
###################################################
sub make_flower_gif
{
	my ($uid, $rdata) = @_;
	my $flower;
	
	my $next_grow_step = $rdata->[5];
	my $rcreature = get_expression_data((@$rdata)[16, 17]);
	
	cp_flower_img($uid, $rdata->[0], $rcreature, $next_grow_step);
	
	return 1;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub change_flower_type_data
{
	my $rdata = shift;
	
	my $rcreature = $rdata->[3];
	my $rf_type = get_flower_type_data();
	while(my ($organ_id, $val) = each(%$rcreature)) {
		my $im_id = $val->{protein}->[$val->{view}->[0]]->{domain};
		$rf_type->{"$organ_id"}->{"$im_id"}++;
	}
	put_flower_type_data($rf_type);
	
	return 1;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_shop_htm
{
	my $uid = $PARAM->{UID};

	my $rseed = get_seed_data($uid);
	my $ritem_shop = get_item_shop();
	my $ruser   = get_status_data($uid);
	my $rstatus = $ruser->[0];
	my $err_str = change_about_item($uid, $ruser, $ritem_shop, $rseed);
	my $uname = get_uname($uid);
	my $img_dir = $RDATA->{img_dir};
	put_status_data($uid, $ruser);
	my $level = $RDATA->{level_setting}->[$rstatus->[3]]->[0]
		|| $RDATA->{kyuu}->[$rstatus->[3]];
	
	my $str = "Content-type: text/html\n\n";
	$str .= qq{<html><head>};
	$str .= get_head();
	$str .= qq{
		<title>아이템상점</title>
		</head>
		<body bgcolor='#d1f8d8' background='' onLoad=''>
			<!-- <center><img src='$RDATA->{img_dir}/inc_plant.gif' border='0'></center> -->
			<center><img src='$img_dir/shop_ttl.gif' border='0'></center>
	};
	$str .= get_item_htm($uid, $ritem_shop, $ruser, $err_str);
	$str .= get_user_item_htm($uid, $ritem_shop, $ruser, $rseed);
	$str .= qq{
			<form action="$PNAME" method="$RDATA->{method}" name="reg"><center>
			<table width="450" border="0" cellspacing="0" cellpadding="0"><tr><td bgcolor="#333333"> 
			<table border="0" cellspacing="1" cellpadding="2" height="100%" width="100%">
			<tr><td bgcolor="#eeeeee" align="center" class='table_top item_bottom'>
				<b><font color="#333333" face="Arial, Helvetica, sans-serif">사용자 정보</font></b></td>
			</tr>
			<tr><td bgcolor="#FFFFFF" class='table_bottom'> 
				<center><table border="0" cellspacing="3" cellpadding="2">
					<tr><td ALIGN="right">
							<font face="Times New Roman, Times, serif" size="2"><b>이름:</b></font></td>
						<td align="left"><b>$uname</b></td>
						<td ALIGN="right">
							<b><font size="2" face="Times New Roman, Times, serif">보유 금액:</font></b>
						</td><td align="left"><b>$rstatus->[0]$RDATA->{monney}</b></td>
					</tr>
					<tr><td ALIGN="right">
							<b><font size="2" face="Times New Roman, Times, serif">레벨:</font></b>
						</td><td align="left" colspan='3'><b>$level</b></td>
					</tr><tr> 
						<td colspan='4' ALIGN="center" valign="middle"> 
							<input type="button" value='상점 나가기' onClick="location.href='$PNAME?UID=$uid&MODE=main'">
						</td>
					</tr>
				</table></center></td>
			</tr></table></td></tr></table>
			<INPUT TYPE="hidden" NAME="UID" value='$uid'>
			<INPUT TYPE="hidden" NAME="MODE" value='main'>
			</center></form>
	};
	$str .= get_copyright();
	$str .= "<br></body></html>";
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:[[iid, 이름, 가격, 이미지], ,,,]
###################################################
sub change_about_item
{
	my ($uid, $ruser, $ritem_shop, $rseed) = @_;
	my ($err_str);
	my ($rstatus, $ritems) = @$ruser;

	my $iid = $PARAM->{IID};
	my $num = int($PARAM->{NUM}); $num = 1 if($num <= 0);
	if($iid) {
		if($PARAM->{MODE} eq "shop_sell") {
			my ($e_name, $s_price)
				= (@{$ritem_shop->[0]->{"$iid"}})[1, 5];
			if($ritems->[$iid] <= 0) {
				$err_str = "$e_name을 가지고 있지 않아 판매할 수 없습니다<br>\n";
			}
			if(!defined($err_str) && $s_price >= 0) {
				$rstatus->[0] += $s_price;
				$ritems->[$iid] --;
				$err_str = "$e_name을 $s_price$RDATA->{monney}에 판매했습니다<br>\n";
			}
		} elsif($PARAM->{MODE} eq "seed_sell") {
			if(!$rseed->{"$iid"}) {
				$err_str = "이미 판매했거나 존재하지 않는 씨앗을 판매하려고 했습니다";
			} else {
				my ($sell_flg, $p_name, $s_price) = (@{$rseed->{"$iid"}})[1, 2, 5];
				if($sell_flg) {
					$rstatus->[0] += $s_price;
					$rstatus->[5]--;
					delete($rseed->{"$iid"});
					$err_str = "$p_name의 씨앗을 $s_price$RDATA->{monney}에 판매했습니다<br>\n";
					put_seed_data($uid, $rseed);
				} else {
					$err_str = "앨범에 보관한 뒤 판매해 주세요.<br>URL 인수를 잘못 조작하지 마세요.";
				}
			}
		} else {
			my ($e_name, $e_price, $buy_max, $permit_kyu)
				= (@{$ritem_shop->[0]->{"$iid"}})[1, 2, 4, 6];

			if($rstatus->[3] < $permit_kyu) {$err_str = "구입할 수 없는 아이템입니다.";}
			if(!$buy_max) {$buy_max = 10;}
			if($e_price * $num > $rstatus->[0]) {
				$err_str = "$e_name을 구입하기에는 보유 금액이 부족합니다<br>\n";
			} elsif($iid != 4 && $buy_max < $ritems->[$iid] + $num) {
				$err_str = "$e_name은 더 이상 보유할 수 없습니다<br>\n";
			} elsif($iid >= 11 && $iid <= 13) {
				if($iid == 11 || $ritems->[$iid - 1]) {
					my $next_cnt = $RDATA->{album_max}->[$iid - 10];
					$rstatus->[10] = $next_cnt if($rstatus->[10] < $next_cnt);
				} else {
					$err_str = "구입할 수 없는 앨범입니다.";
				}
			} elsif($iid == 4) {
				$buy_max = $rstatus->[8];
				my $rplant = get_plant_data($uid);
				my $plant_cnt = keys(%$rplant);
				if($buy_max <= $plant_cnt) {
					$err_str = "이 레벨에서는 $e_name을 더 이상 보유할 수 없습니다<br>\n";
				} else {
					$rplant->{"-$plant_cnt"} = [-$plant_cnt, "새화분", "null", "null", 0, 6, 9,
						"null", "null", 9, "null", "null", 9, "null", "null", 0, "null", "null", 0];
					put_plant_data($uid, $rplant);
				}
			}
			if(!defined($err_str)) {
				$rstatus->[0] -= $e_price * $num;
				$ritems->[$iid] += $num;
				$err_str  = "$e_name을 구입했습니다.<br>\n";
				if($iid == 4 && $ritems->[4] == 1) {
					$err_str .= "<br>[힌트]<br>새 화분에 씨앗을 심거나 물을";
					$err_str .= "줄 때는<br>식물명 왼쪽에 라디오 버튼이 표시됩니다";
					$err_str .= "<br>이 버튼으로 선택할 수 있습니다!<br><br>";
				}
			}
		}
	}
	
	return $err_str;
}

###################################################
#  input:()
# retrun:
#comment:[[iid, 이름, 가격, 이미지], ,,,]
###################################################
sub get_item_htm
{
	my ($uid, $ritem_shop, $ruser, $alert_str) = @_;
	my $str;
	my ($rstatus, $ritems) = @$ruser;

	my $kyu = $rstatus->[3];
	$str .= qq{
		<center><form>
		<table width="450" border="0" cellspacing="0" cellpadding="0"><tr><td bgcolor="#550000"> 
		<table border="0" cellspacing="1" cellpadding="2" height="100%" width="100%">
			<tr><td bgcolor="#ffcccc" align="center" class='table_top item_top'>
				<b><font color="#550000" face="Arial, Helvetica, sans-serif">상품 목록</font></b>
			</td></tr>
			<tr><td bgcolor="#fff0f0" align="center" class='table_bottom'>
				<font color='red'><b>$alert_str</b></font>
				<table>
	};
	foreach (@{$ritem_shop->[1]}) {
		my $add_button;
		my $ri = $ritem_shop->[0]->{"$_"};
		if($kyu < $ri->[6]) {next;}
		my $buy_max = $ri->[4] || 10;
		if($_ == 4) {
			$buy_max = $rstatus->[8];
			my $rplant = get_plant_data($uid);
			if($buy_max <= keys(%$rplant)) {next;}
		} else {
			if($buy_max <= $ritems->[$_]) {next;}
		}
		
		if($_ == 1 || $_ == 2) {
			my $num_rest = $buy_max - $ritems->[$_];
			$add_button = qq{<input type='button' value='$num_rest개구입' onClick="location.href='$PNAME?UID=$uid&MODE=shop&IID=$ri->[0]&NUM=$num_rest'">};
		}
		$str .= qq{
			<tr>
				<td><img src='$RDATA->{img_dir}/$ri->[3]'></td>
				<td><a href='$PNAME?MODE=i_help#$ri->[0]'>$ri->[1]</a> ($buy_max)</td>
				<td align='right'>$ri->[2]$RDATA->{monney}</td>
				<td>
					<input type='button' value='구입' onClick="location.href='$PNAME?UID=$uid&MODE=shop&IID=$ri->[0]'">
					$add_button
				</td>
			</tr>
		};
	}
	$str .= qq{
				</table>
			</td></tr>
		</table></td></tr></table></form></center>
	};
	
	return $str;

}

###################################################
#  input:()
# retrun:
#comment:[[iid, 이름, 가격, 이미지, 판매가], ,,,]
###################################################
sub get_user_item_htm
{
	my ($uid, $ritem_shop, $ruser, $rseed) = @_;
	my $str;
	my ($rstatus, $ritems) = @$ruser;

	$str .= qq{
		<center><form name='seed'>
		<table width="450" border="0" cellspacing="0" cellpadding="0"><tr><td bgcolor="#550000"> 
		<table border="0" cellspacing="1" cellpadding="2" height="100%" width="100%">
			<tr><td bgcolor="#ddeeff" align="center" class='table_top item_middle'>
				<b><font color="#003388" face="Arial, Helvetica, sans-serif">보유아이템</font></b>
			</td></tr>
			<tr><td bgcolor="#f5ffff" align="center" class='table_bottom'>
	};
	$str .= get_shop_uitem_htm($uid, $ritem_shop, $ritems);
	$str .= get_seed_uitem_htm($uid, $rseed, $rstatus);
	$str .= qq{
			</td></tr>
		</table></td></tr></table></form></center>
		<form name='items' action='$PNAME'>
			<input type='hidden' name='UID' value='$uid'>
			<input type='hidden' name='MODE' value=''>
			<input type='hidden' name='OPT' value=''>
			<input type='hidden' name='IID' value=''>
			<input type='hidden' name='NUM' value=''>
		</form>
		<form name='seed_name' action='$PNAME'>
			<input type='hidden' name='UID' value='$uid'>
			<input type='hidden' name='MODE' value=''>
			<input type='hidden' name='RENAME' value=''>
		</form>
	};
	
	return $str;

}

###################################################
#  input:()
# retrun:
#comment:[[iid, 이름, 가격, 이미지, 판매가], ,,,]
###################################################
sub get_shop_uitem_htm
{
	my ($uid, $ritem_shop, $ritems) = @_;
	my $str;
	
	$str .= qq{
				<table>
	};
	for(my $iid = 1; $iid < @$ritems; $iid++) {
		if($iid == 4 || ($iid >= 11 && $iid <= 13)) {next;}
		my $icnt = $ritems->[$iid] || 0;
		if($icnt >= 1 || $iid == 1) {
			my $ri = $ritem_shop->[0]->{"$iid"};
			$str .= qq{
				<tr>
					<td><img src='$RDATA->{img_dir}/$ri->[3]'></td>
					<td>$ri->[1]</td>
					<td align='right'>$ri->[5]$RDATA->{monney}</td>
					<td align='right'>$icnt 개</td>
			};
			if($PARAM->{MODE} eq "use_item") {
				my $full_str = qq{<input type='button' value='채우기' onClick="use_item($iid, 'use_item', 9)">}
					if($iid == 1);
				$str .= qq{
					<td><input type='button' value='사용' onClick="use_item($iid, 'use_item')">
						$full_str
					</td>
				} if($iid != 8 && $icnt >= 1);
			} else {
				$str .= qq{
					<td><input type='button' value='판매' onClick="if(confirm('「$ri->[1]」을 정말 판매하시겠습니까?')) location.href='$PNAME?UID=$uid&MODE=shop_sell&IID=$iid'"></td>
				} if($icnt >= 1);
			}
			$str .= qq{
				</tr>
			};
		}
	}
	my $albm_iid = ($ritems->[13])? 13: ($ritems->[12])? 12: ($ritems->[11])? 11: 0;
	if($albm_iid) {
		my $ri = $ritem_shop->[0]->{"$albm_iid"};
		$str .= qq{<tr><td><img src='$RDATA->{img_dir}/$ri->[3]'></td><td>$ri->[1]</td>
			<td align='center'>---</td><td align='right'>1 개</td></tr>};
	}
	$str .= qq{
				</table><hr>
	};
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
#-seed data
# 0      1        2     3      4       5      6       7       8     9
#pid,사용 가능 여부,이름,유전자1,유전자2,가격,자신uid,상대uid,자신pid,상대pid
###################################################
sub get_seed_uitem_htm
{
	my ($uid, $rseed, $rstatus) = @_;
	my $str;
	
	my $level = $RDATA->{level_setting}->[$rstatus->[3]]->[0]
		|| $RDATA->{kyuu}->[$rstatus->[3]];
		
	$str .= qq{
		<b>「${level}」 씨앗은
		<font color='red'>$rstatus->[6]개</font>까지입니다.</b>
		<table>
	};
	foreach (sort {$a <=> $b} keys(%$rseed)) {
		my $rs = $rseed->{"$_"};
		my $text = ($PARAM->{MODE} eq "use_item")?
			qq{<input type="text" name="NAM$rs->[0]" size="18" maxlength="16" value='$rs->[2]' />의 씨앗}:
			qq{$rs->[2]의 씨앗};
		$str .= qq{
				<tr>
					<td><a href='$PNAME?MODE=view_parent&UID=$uid&PID=$rs->[0]'>
						<img src='$RDATA->{img_dir}/tane.gif' border='0'></a></td>
					<td>$text</td>
					<td align='right'>$rs->[5]$RDATA->{monney}</td>
		};
		if($PARAM->{MODE} eq "use_item" && $rs->[1] == 1) {
			my $text = qq{<input type="button" value='이름 붙이기' onClick="go_rename($rs->[0])">}
				if ($PARAM->{MODE} eq "use_item");
				
			$str .= qq{
					<td>$text
						<input type='button' value='심기' onClick="use_item($rs->[0], 'sow_item')">
					</td>
			};
		} elsif(($PARAM->{MODE} eq "shop" || $PARAM->{MODE} eq "seed_sell"
			|| $PARAM->{MODE} eq "shop_sell") && $rs->[1] == 1) {
			
			$str .= qq{
					<td><input type='button' value='판매' onClick="if(confirm('「$rs->[2]의 씨앗」을 정말 판매하시겠습니까?')) location.href='$PNAME?UID=$uid&MODE=seed_sell&IID=$rs->[0]'"></td>
			};
		}
		$str .= qq{
				</tr>
		};
	}
	$str .= qq{
				</table>
	};
	
	return $str;
}

###################################################
#  input:()
# retrun:	$items[0]->{iid} = [iid, name, price, img, urine]
#			      [1]->[n] = iid
#comment:
###################################################
sub get_item_shop
{
	my @items;
	
	open(SHOP, "$RDATA->{sys_dir}/shop.cgi")
		|| error_end(__LINE__, "파일 오류", $!);
	while(chomp(my $line = <SHOP>)) {
		my @e_item = split(/\t/, $line);
		my $iid    = $e_item[0];
		#comment: 아래 함수의 처리 내용을 설명합니다.
		if(($iid == 11 || $iid == 12 || $iid == 13)
			&& !defined($RDATA->{album_max}->[$iid - 10])) {next;}
			
		$items[0]->{"$iid"} = \@e_item;
		push(@{$items[1]}, $iid);
	}
	close(SHOP) || error_end(__LINE__, "파일 오류", $!);

	return \@items;
}


###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_score_html
{
	my $rdata = shift;
	my @res_htms;
	
	my @score = (@$rdata)[6, 9, 12];
	my @gif_d = (
		[
			["bw", "bw", "bw", "bw", "bw", "bw", "yw", "yw", "rw"],
			["bw", "bw", "bw", "bw", "bw", "bw", "yw", "yw", "rr"],
			["bw", "bw", "bw", "bw", "bw", "bw", "yw", "yy", "rr"],
			["bw", "bw", "bw", "bw", "bw", "bw", "yy", "yy", "rr"],
			["bw", "bw", "bw", "bw", "bw", "bb", "yy", "yy", "rr"],
			["bw", "bw", "bw", "bw", "bb", "bb", "yy", "yy", "rr"],
			["bw", "bw", "bw", "bb", "bb", "bb", "yy", "yy", "rr"],
			["bw", "bw", "bb", "bb", "bb", "bb", "yy", "yy", "rr"],
			["bw", "bb", "bb", "bb", "bb", "bb", "yy", "yy", "rr"],
			["bb", "bb", "bb", "bb", "bb", "bb", "yy", "yy", "rr"],
		],
		[
			["bw", "bw", "bw", "bw", "yw", "yw", "yw", "yw", "rw"],
			["bw", "bw", "bw", "bw", "yw", "yw", "yw", "yw", "rr"],
			["bw", "bw", "bw", "bw", "yw", "yw", "yw", "yy", "rr"],
			["bw", "bw", "bw", "bw", "yw", "yw", "yy", "yy", "rr"],
			["bw", "bw", "bw", "bw", "yw", "yy", "yy", "yy", "rr"],
			["bw", "bw", "bw", "bw", "yy", "yy", "yy", "yy", "rr"],
			["bw", "bw", "bw", "bb", "yy", "yy", "yy", "yy", "rr"],
			["bw", "bw", "bb", "bb", "yy", "yy", "yy", "yy", "rr"],
			["bw", "bb", "bb", "bb", "yy", "yy", "yy", "yy", "rr"],
			["bb", "bb", "bb", "bb", "yy", "yy", "yy", "yy", "rr"],
		],
		[
			["bw", "bw", "bw", "bw", "yw", "yw", "yw", "yw", "rw"],
			["bw", "bw", "bw", "bw", "yw", "yw", "yw", "yw", "rr"],
			["bw", "bw", "bw", "bw", "yw", "yw", "yw", "yy", "rr"],
			["bw", "bw", "bw", "bw", "yw", "yw", "yy", "yy", "rr"],
			["bw", "bw", "bw", "bw", "yw", "yy", "yy", "yy", "rr"],
			["bw", "bw", "bw", "bw", "yy", "yy", "yy", "yy", "rr"],
			["bw", "bw", "bw", "bb", "yy", "yy", "yy", "yy", "rr"],
			["bw", "bw", "bb", "bb", "yy", "yy", "yy", "yy", "rr"],
			["bw", "bb", "bb", "bb", "yy", "yy", "yy", "yy", "rr"],
			["bb", "bb", "bb", "bb", "yy", "yy", "yy", "yy", "rr"],
		],
	);
	for(my $cnt = 0; $cnt < @score; $cnt++) {
		my $each_score = $score[$cnt];
		foreach (@{$gif_d[$cnt]->[$each_score]}) {
			$res_htms[$cnt]
				.= qq{<img src='$RDATA->{img_dir}/$_.gif'><br>\n};
		}
	}
	
	return \@res_htms;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_regist_jscript
{
	my $str .= qq{
		<META HTTP-EQUIV='Content-Script-Type' CONTENT='text/javascript'>
		<SCRIPT LANGUAGE='JavaScript'>
		<!--
		//
		function go_submit() {
			if(document.reg.PWD.value == document.reg.PWD2.value) {
				document.reg.submit();
			} else {
				alert("비밀번호가 일치하지 않습니다.");
			}
			
			return true;
		}
		<!---->
		</SCRIPT>
	};
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_main_js
{
	my $str = qq{
		<META HTTP-EQUIV='Content-Script-Type' CONTENT='text/javascript'>
		<SCRIPT LANGUAGE='JavaScript'>
		<!--
		//
		function go_rename(pid) {
			document.go_main.OPT.value = pid + '!n!' + eval("document.plant.NAM" + pid).value;
			document.go_main.submit();
			
			return true;
		}
		//
		function go_water(pid) {
			document.go_main.OPT.value = pid + '!w';
			document.go_main.NUM.value = 9;
			document.go_main.submit();
			
			return true;
		}
		//
		function go_place(pid, in_out) {
			var o_i = (in_out == 1)? 'o': 'i';
			document.go_main.OPT.value = pid + '!p' + o_i;
			document.go_main.submit();
			
			return true;
		}
		<!---->
		</SCRIPT>
	};
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_hpb_js
{
	my $img_dir = $RDATA->{img_dir};
	my $str = qq{
		<META HTTP-EQUIV='Content-Script-Type' CONTENT='text/javascript'>
		<SCRIPT language="JavaScript">
		<!--
		//
		//  Licensed Materials - Property of IBM
		//  5724D51
		//  (C) Copyright IBM Corp. 1995, 2002 All Rights Reserved.
		//
		
		// HpbImgPreload:
		//
		function HpbImgPreload()
		{
			var appVer=parseInt(navigator.appVersion);
			var isNC=false,isN6=false,isIE=false;
			if (document.all && appVer >= 4) isIE=true; else
				if (document.getElementById && appVer > 4) isN6=true; else
					if (document.layers && appVer >= 4) isNC=true;
			if (isNC||isN6||isIE)
			{
				if (document.images)
				{
					var imgName = HpbImgPreload.arguments[0];
					var cnt;
					swImg[imgName] = new Array;
					for (cnt = 1; cnt < HpbImgPreload.arguments.length; cnt++)
					{
						swImg[imgName][HpbImgPreload.arguments[cnt]] = new Image();
						swImg[imgName][HpbImgPreload.arguments[cnt]].src = HpbImgPreload.arguments[cnt];
					}
				}
			}
		}
		// HpbImgFind:
		//
		function HpbImgFind(doc, imgName)
		{
			for (var i=0; i < doc.layers.length; i++)
			{
				var img = doc.layers[i].document.images[imgName];
				if (!img) img = HpbImgFind(doc.layers[i], imgName);
				if (img) return img;
			}
			return null;
		}
		// HpbImgSwap:
		//
		function HpbImgSwap(imgName, imgSrc)
		{
			var appVer=parseInt(navigator.appVersion);
			var isNC=false,isN6=false,isIE=false;
			if (document.all && appVer >= 4) isIE=true; else
				if (document.getElementById && appVer > 4) isN6=true; else
					if (document.layers && appVer >= 4) isNC=true;
			if (isNC||isN6||isIE)
			{
				if (document.images)
				{
					var img = document.images[imgName];
					if (!img) img = HpbImgFind(document, imgName);
					if (img) img.src = imgSrc;
				}
			}
		}
		var swImg; swImg=new Array;
		HpbImgPreload('ROLL01', '$img_dir/btn01_0.gif', '$img_dir/btn01_1.gif');
		HpbImgPreload('ROLL02', '$img_dir/btn02_0.gif', '$img_dir/btn02_1.gif');
		HpbImgPreload('ROLL03', '$img_dir/btn03_0.gif', '$img_dir/btn03_1.gif');
		HpbImgPreload('ROLL04', '$img_dir/btn04_0.gif', '$img_dir/btn04_1.gif');
		HpbImgPreload('ROLL05', '$img_dir/btn05_0.gif', '$img_dir/btn05_1.gif');
		HpbImgPreload('ROLL06', '$img_dir/btn06_0.gif', '$img_dir/btn06_1.gif');
		HpbImgPreload('ROLL11', '$img_dir/btn11_0.gif', '$img_dir/btn11_1.gif');
		HpbImgPreload('ROLL12', '$img_dir/btn12_0.gif', '$img_dir/btn12_1.gif');
		HpbImgPreload('ROLL13', '$img_dir/btn13_0.gif', '$img_dir/btn13_1.gif');
		HpbImgPreload('ROLL14', '$img_dir/btn14_0.gif', '$img_dir/btn14_1.gif');
		HpbImgPreload('ROLL15', '$img_dir/btn15_0.gif', '$img_dir/btn15_1.gif');
		HpbImgPreload('ROLL16', '$img_dir/btn16_0.gif', '$img_dir/btn16_1.gif');
		HpbImgPreload('ROLL17', '$img_dir/btn17_0.gif', '$img_dir/btn17_1.gif');
		HpbImgPreload('ROLL18', '$img_dir/btn18_0.gif', '$img_dir/btn18_1.gif');
		//-->
		</SCRIPT>
	};
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_mail_js
{

	my $str .= qq{
		<META HTTP-EQUIV='Content-Script-Type' CONTENT='text/javascript'>
		<SCRIPT LANGUAGE='JavaScript'>
		<!--
		//
		function send_mail() {
			var fi = document.inputer;
			var fs = document.sender;
			var rgexp = new RegExp("!", "g");
			var cmnt  = fi.COMMENT.value;
			cmnt      = cmnt.replace(rgexp, "|");
			
			var sele  = fi.UID;
			var suid  = sele.options[sele.selectedIndex].value;
			if(suid == 0) {alert('보낼 상대를 선택해 주세요'); return false;}

			fs.OPT.value = '4!' + suid + "!" + cmnt;

			fs.submit();
			
			return true;
		}
		
		//
		function select_user(suid) {
			var fi = document.inputer;
			var sele  = fi.UID;
			
			for(sel = 0; sel < sele.length; sel ++) {
				if(sele.options[sel].value == suid) {
					sele.selectedIndex = sel;
					location.href='#to_top';
					fi.COMMENT.focus();
					break;
				}
			}
			
			return true;
		}
		<!---->
		</SCRIPT>
	};
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_use_item_js
{
	my $str = qq{
		<META HTTP-EQUIV='Content-Script-Type' CONTENT='text/javascript'>
		<SCRIPT LANGUAGE='JavaScript'>
		<!--
		function use_item(iid, cmd, num) {
			if(!(num > 0)) num = 1;
			var pid;
			var fi = document.items;
			var fp = document.plant;
			var pi_lng = fp.PID.length;
			
			if(!pi_lng) {
				pid = fp.PID.value;
			} else {
				for (i = 0; i < pi_lng; i++) {
					if(fp.PID[i].checked) pid = fp.PID[i].value;
				}
			}
			fi.OPT.value = (cmd == 'use_item')? pid + "!i": pid;
			fi.IID.value = iid;
			fi.NUM.value = num;
			fi.MODE.value = cmd;
			fi.submit();
		}
		//
		function go_rename(pid) {
			var fi = document.seed_name;
			fi.RENAME.value = pid + '!n!' + eval("document.seed.NAM" + pid).value;
			fi.MODE.value = 'use_item';
			fi.submit();
			
			return true;
		}
		<!---->
		</SCRIPT>
	};
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub add_album_expression_data
{
	my $rplant = shift;
	
	foreach (values(%$rplant)) {
		$_->[3] = get_expression_data($_->[16], $_->[17]);
	}
	
	return 1;
}

###################################################
#  input:()
# retrun:
#comment:
#			$->{"organ_id"}->{protein}->[n] = quality
#			               ->{view}  = [n,...]
#			               ->{power} = total_strength
###################################################
sub get_expression_data
{
	my ($dna1, $dna2) = @_;
	my %creature;
	
	inc_inc::add_translated_gene_data(\%creature, $dna1);
	inc_inc::add_translated_gene_data(\%creature, $dna2);
	inc_inc::add_expression_data(\%creature);
	
	return \%creature;
}

###################################################
#  input:()
# retrun:
#comment:
#			$->{"organ_id"}->{protein}->[n] = quality
#			               ->{view}  = [n,...]
#			               ->{power} = total_strength
###################################################
sub get_flower_status
{
	my ($rstat) = @_;
	my $str;
	my @organ = ("종합평가", "튼튼함(줄기)", "향기(잎)", "아름다움(꽃)");
	
	$str .= "<font size='-1'>";
	for(my $asc = 0; $asc <= 3; $asc++) {
		my $cnt = (0, 3, 2, 1)[$asc];
		my $add_str = "$organ[$cnt]: $rstat->[$cnt]->[0]<br>\n";
		$add_str    = "<b>$add_str</b>" if($cnt == 0);
		$str       .= $add_str;
	}
	$str .= "</font>\n";
	
	return $str;
}

###################################################
#  input:()
# retrun:	$->[0] = [total_score, rep_id]
#			 ->[1] = [score, im_id]
#			...
#comment:
#			$->{"organ_id"}->{protein}->[n] = quality
#			               ->{view}  = [n,...]
#			               ->{power} = total_strength
#
#             ->[1] = [score, im_id]
###################################################
sub get_flower_status_data
{
	my ($rcreature, $pure_flg) = @_;
	my ($total, @temp);
	
	while(my ($organ_id, $val) = each(%$rcreature)) {
		$temp[$organ_id - 1]
			= [$val->{power}, $val->{protein}->[$val->{view}->[0]]->{domain}];
		if($organ_id == 3) {$total += $val->{power} / 2;}
		else               {$total += $val->{power} / 4;}
	}
	$total = int($total); $total *= $RDATA->{rep_rate} if($pure_flg);
	
	for(my $cnt = 2; $cnt >= 0; $cnt--) {
		$temp[$cnt]->[0] *= $RDATA->{rep_rate} if($pure_flg);
	}
	
	my $rep_id = get_represent_flower($rcreature) if($pure_flg);

	return [[$total, $rep_id], @temp];
}

###################################################
#  input:()
# retrun:[$dna1, $dna2, $total]
#comment:
###################################################
sub get_new_dna
{
	my ($uid1, $pid1, $uid2, $pid2) = @_;
	my (%creature);

	my $rdna1 = get_new_haploid($uid1, $pid1, 0);
	if(!$rdna1) {return undef;}
	my ($dna1, $rdata1) = @$rdna1;
	inc_inc::add_translated_gene_data(\%creature, $dna1);
	
	my $rdna2 = get_new_haploid($uid2, $pid2, 1);
	if(!$rdna2) {return undef;}
	my ($dna2, $rdata2) = @$rdna2;
	inc_inc::add_translated_gene_data(\%creature, $dna2);
	
	inc_inc::add_expression_data(\%creature);
	if($creature{"1"}->{power} * $creature{"2"}->{power} * $creature{"3"}->{power}) {
		my $cost1 = $rdata1->[18];
#		my $cost2 = $rdata2->[18];
		my $total = $cost1;	#comment: 아래 함수의 처리 내용을 설명합니다.

		return [$dna1, $dna2, $total];
	}
	
	return undef;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_new_haploid
{
	my ($uid, $pid, $alb_flg) = @_;
	my ($new_dna);
	
	my $rplant = get_album_data($uid) if($alb_flg);
	$rplant    = get_plant_data($uid) if(!$alb_flg || !defined($rplant->{"$pid"}));
	my $rdata  = $rplant->{"$pid"};
	if($rdata->[5] != 5) {return undef;}
	my ($dna1, $dna2) = (@$rdata)[16, 17];
	my $rcreature = get_expression_data($dna1, $dna2);
	if(defined(get_represent_flower($rcreature))) {
		return undef;
	} else {
		my $rchrom = inc_inc::get_chromosome_stracture([$dna1, $dna2]);
		$new_dna   = inc_inc::get_nbody_from_rchrom($rchrom);
	}
	
	return [$new_dna, $rdata];
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_user_property
{
	my ($uid) = @_;
	my $property;

	my $ritem_shop = get_item_shop();
	my $ruser      = get_status_data($uid);
	my $rseed      = get_seed_data($uid);
	my ($rstatus, $ritems) = @$ruser;
	
	my $rshop = $ritem_shop->[0];
	for(my $iid = 1; $iid < @$ritems; $iid++) {
		my $icnt       = $ritems->[$iid];
		my $sell_price = $rshop->{"$iid"}->[5];
		if($icnt >= 1 && $sell_price >= 1) {
			$property += $sell_price * $icnt;
		}
	}
	foreach (values(%$rseed)) {
		$property += $_->[5];
	}
	$property += $rstatus->[0];
	
	return $property;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_all_user_property
{
	my (@res, %table);
	my $ruids = get_all_udata();
	foreach (@$ruids) {
		my $property = get_user_property($_->[0]);

		push(@{$table{"$property"}}, $_)
			if($property > $RDATA->{init_cash});
	}
	my $order = 1;
	my @sorter = sort { $a <=> $b } keys(%table);
	foreach my $property (reverse(@sorter)) {
		foreach (@{$table{"$property"}}) {
			my $suid = $_->[0];
			my $rtag = get_tags($suid, $order);

			push(@res, [$suid,
				"$rtag->[2] $rtag->[0]$order위$rtag->[1]",
				"$rtag->[0]$_->[1]님$rtag->[1]",
				"$rtag->[0]$property$RDATA->{monney}$rtag->[1]"
			]);
		}
		if(++$order > 50) {last;}
	}
	
	return ["자산왕", ["순위", "이름", "자산"], \@res];
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_all_user_flower_collection
{
	my (@res, %table);

	my $ruids = get_all_udata();
	foreach (@$ruids) {
		my %hana;
		my $cnt    = 0;
		my $uid    = $_->[0];
		my $rplant = get_album_data($uid);
		foreach (values(%$rplant)) {
			my $rcreature = get_expression_data((@$_)[16, 17]);
			my $rhana  = $rcreature->{"3"};
			my $flower = $rhana->{protein}->[$rhana->{view}->[-1]]->{domain};
			if(!$hana{"$flower"}) {$hana{"$flower"} = 1; $cnt++;}
		}
		push(@{$table{"$cnt"}}, $_);
	}
	my $order = 1;
	my @sorter = sort { $a <=> $b } keys(%table);
	foreach my $property (reverse(@sorter)) {
		if($property == 0) {next;}
		foreach (@{$table{"$property"}}) {
			my $suid = $_->[0];
			my $rtag = get_tags($suid, $order);

			push(@res, [$_->[0],
				"$rtag->[2] $rtag->[0]$order위$rtag->[1]",
				"<a href='$PNAME?MODE=album&OPT=$_->[0]&BT=1'>$rtag->[0]$_->[1]</a>님$rtag->[1]",
				"$rtag->[0]$property씨앗종류$rtag->[1]"
			]);
		}
		if(++$order > 50) {last;}
	}
	
	return ["식물 컬렉터왕<font size='-2'>(보유 중인 꽃 씨앗 종류 순위입니다.)</font>",
		["순위", "이름", "재배 식물"], \@res];
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_all_user_collection
{
	my (@res, %table);

	my $ruids = get_all_udata();
	foreach (@$ruids) {
		my %hana;
		my $rudata = get_status_data($_->[0]);
		my $cnt    = $rudata->[0]->[12];
		push(@{$table{"$cnt"}}, $_);
	}
	my $order = 1;
	my @sorter = sort { $a <=> $b } keys(%table);
	foreach my $property (reverse(@sorter)) {
		if($property == 0) {next;}
		foreach (@{$table{"$property"}}) {
			my $rtag = get_tags($_->[0], $order);

			push(@res, [$_->[0],
				"$rtag->[2] $rtag->[0]$order위$rtag->[1]",
				"<a href='$PNAME?MODE=album&OPT=$_->[0]&BT=1'>$rtag->[0]$_->[1]</a>님$rtag->[1]",
				"$rtag->[0]${property}그루$rtag->[1]"
			]);
		}
		if(++$order > 50) {last;}
	}
	
	return ["식물 컬렉터왕", ["순위", "이름", "재배 식물"], \@res];
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_all_plant_score
{
	my (@res, %table);

	my $ruids = get_all_udata();
	foreach (@$ruids) {
		my $uid      = $_->[0];
		my $rplant = get_album_data($uid);
		foreach my $rrplant (values(%$rplant)) {
			my ($pid, $pname, $pcost) = (@$rrplant)[0, 1, 18];
			push(@{$table{"$pcost"}}, [(@$_)[0, 1], $pid, $pname]);
		}
	}
	my $order = 1;
	my @sorter = sort { $a <=> $b } keys(%table);
	foreach my $property (reverse(@sorter)) {
		foreach (@{$table{"$property"}}) {
			my $suid = $_->[0];
			my $rtag = get_tags($suid, $order);
			my ($tags, $tage, $img) = @$rtag;
			push(@res, [$_->[0],
				"$img $tags$order위$tage",
				"
					<a href='$PNAME?MODE=album&OPT=$_->[0]&BT=1'>
					$tags$_->[1]$tage</a>${tags}님의$tage
					<a href='$PNAME?MODE=view_each&UID=$_->[0]&PID=$_->[2]'>
					$tags$_->[3]$tage</a>
				",
				"$tags$property점$tage"
			]);
		}
		if(++$order > 50) {last;}
	}
	
	return ["식물 종합 평가왕", ["순위", "식물 이름", "종합평가"], \@res];
}

###################################################
#  input:()
# retrun:
#comment: 인기 순위 데이터를 집계합니다.
###################################################
sub get_all_popular_plant
{
	my (%pops, %counter, %tmp, %table, @res);
	
	my $rpop  = get_popular_flower();
	my $rallu = get_all_udata_hash();

	foreach (@$rpop) {
		$pops{"$_->[0],$_->[1]"} ++;
	}
	while(my ($upid, $count) = each(%pops)) {
		push(@{$counter{"$count"}}, $upid);
	}
	my @sorter = sort { $a <=> $b } keys(%counter);
	
	# 동일한 조합의 등장 횟수 누적
	my $order = 1;
	foreach (@sorter) {
		my $rupid = $counter{"$_"};
		foreach my $upid (@$rupid) {
			my ($uid, $pid) = split(/,/, $upid);
			push(@{$tmp{"$uid"}}, [$pid, $_]);
		}
		if(++$order > 50) {last;}
	}
	while(my ($uid, $rpicnt) = each(%tmp)) {
		my $rplant = get_album_data($uid);
		foreach (@$rpicnt) {
			my $uname = $rallu->{"$uid"}->[1];
			$uname .= ($uname)? "님": "플라워 팜";
			push(@{$table{"$_->[1]"}},
				[$uid, $uname, $_->[0], $rplant->{"$_->[0]"}->[1]]);
		}
	}
	
	my $order = 1;
	my @sorter = sort { $a <=> $b } keys(%table);
	foreach my $pop_cnt (reverse(@sorter)) {
		foreach (@{$table{"$pop_cnt"}}) {
			my $suid = $_->[0];
			my $rtag = get_tags($suid, $order);
			
			push(@res, [$_->[0],
				"$rtag->[2] $rtag->[0]$order위$rtag->[1]",
				"$rtag->[0]$_->[1]의 <a href='$PNAME?MODE=view_each&UID=$_->[0]&PID=$_->[2]'>$_->[3]</a>$rtag->[1]",
				"$rtag->[0]$pop_cnt회$rtag->[1]"
			]);
		}
		$order ++;
	}
	
	return ["교배 인기 식물왕<font size='-2'>(최근 인기 있는 식물 순위입니다.)</font>",
		["순위", "식물 이름", "교배 횟수"], \@res];
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_all_pure_collector
{
	my (@res, %table);

	my $rusr_pure = get_user_pure_count_data();
	my $rallu     = get_all_udata_hash();

	while(my ($uid, $pure_cnt) = each(%$rusr_pure)) {
		push(@{$table{"$pure_cnt"}}, $uid);
	}
	my $order = 1;
	my @sorter = sort { $a <=> $b } keys(%table);
	foreach my $pure_cnt (reverse(@sorter)) {
		if($pure_cnt == 0) {next;}
		foreach (@{$table{"$pure_cnt"}}) {
			my $rtag  = get_tags($_, $order);
			my $uname = $rallu->{"$_"}->[1];
			push(@res, [$_,
				"$rtag->[2] $rtag->[0]$order위$rtag->[1]",
				"<a href='$PNAME?MODE=album&OPT=$_&CUT=p&BT=1'>$rtag->[0]$uname</a>님$rtag->[1]",
				"$rtag->[0]${pure_cnt}씨앗종류$rtag->[1]"
			]);
		}
		if(++$order > 50) {last;}
	}
	
	return ["순계식물 컬렉터왕", ["순위", "이름", "순계 씨앗류"], \@res];
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_tags
{
	my ($suid, $order) = @_;
	my ($col, $tag_s, $tag_e, $imm);
	
	if($PARAM->{UID} == $suid) {$col='red';}
	
	if($order == 1)    {
		if(!defined($col)) {$col = '#999900';}
		$imm   = "<img src='$RDATA->{img_dir}/oukan1.gif'>";
		$tag_s = "<b><font color='$col' size='+2'>";
		$tag_e = "</font></b>";
	} elsif($order == 2) {
		if(!defined($col)) {$col = '#553355';}
		$imm   = "<img src='$RDATA->{img_dir}/oukan2.gif'>";
		$tag_s = "<b><font color='$col' size='+1'>";
		$tag_e = "</font></b>";
	} elsif($order == 3) {
		if(!defined($col)) {$col = '#990000';}
		$imm   = "<img src='$RDATA->{img_dir}/oukan3.gif'>";
		$tag_s = "<b><font color='$col' size='+1'>";
		$tag_e = "</font></b>";
	} elsif($col) {
		$tag_s = "<b><font color='$col'>";
		$tag_e = "</font></b>";
	}
	
	return [$tag_s, $tag_e, $imm];
}

#####################################################################################################
###################################################
#  input:()
# retrun:
#comment:
###################################################
sub delete_image
{
	my ($uid, $pid) = @_;
	
	foreach my $g_step (0, 1, 2, 3, 4, 10) {
		foreach my $organ (1, 2, 3) {
			unlink("$RDATA->{album_img}/u$uid/p${g_step}_${organ}_${pid}.gif");
		}
	}
	
	return 1;
}

###################################################
#  input:()
# retrun:
#comment:
#			$->{"organ_id"}->{protein}->[n] = quality
#			               ->{view}  = [n,...]
#			               ->{power} = total_strength
#
#$grow_step：0:씨앗, 1:새싹, 2:본잎, 3:풀, 4:꽃봉오리, 5:꽃, 6:수확, 10:
#$organ_id:  1:줄기, 2:잎, 3:꽃
###################################################
sub cp_flower_img
{
	my ($uid, $pid, $rcreature, $grow_step) = @_;
	
	while(my ($organ_id, $val) = each(%$rcreature)) {
		my $im_id = $val->{protein}->[$val->{view}->[0]]->{domain};
		cp_image($uid, $pid, $grow_step, $organ_id, $im_id);
	}
	
	return 1;
}

###################################################
#  input:()
# retrun:
#comment:
#
#$grow_step：0:씨앗, 1:새싹, 2:본잎, 3:풀, 4:꽃봉오리, 5:꽃, 6:수확, 10:
#$organ_id:  1:줄기, 2:잎, 3:꽃
###################################################
sub cp_image
{
	my ($uid, $pid, $grow_step, $organ_id, $im_id) = @_;
	
	my $cp_file = "$RDATA->{album_img}/u$uid/p${grow_step}_${organ_id}_${pid}.gif";
	if(!(-e $cp_file)) {
		my $file_path = "$RDATA->{plant_img}/o$grow_step/o${organ_id}_${im_id}.gif";
		if(!(-e $file_path)) {
			$file_path = "$RDATA->{plant_img}/o$grow_step/o${organ_id}_1.gif";
		}
		open(IN, "$file_path")
			|| error_end(__LINE__, "파일 오류", "$!($file_path)");
		binmode(IN);
		open(OUT, ">$cp_file")
			|| error_end(__LINE__, "파일 오류", "$!($cp_file)");
		binmode(OUT);

		my $buffer;
		while(read(IN, $buffer, 1024)) {
			print OUT $buffer;
		}

		close(OUT) || error_end(__LINE__, "파일 오류", $!);
		close(IN)  || error_end(__LINE__, "파일 오류", $!);
		
		return 1;
	}
	
	return 0;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub cp_bg_img
{
	my ($uid, $pid, $rep_id) = @_;
	
	my $cp_file = "$RDATA->{album_img}/u$uid/bg_${pid}.gif";
	my $file_path = "$RDATA->{plant_img}/obg/o$rep_id.gif";

	open(IN, "$file_path")
		|| error_end(__LINE__, "파일 오류", $!);
	binmode(IN);
	open(OUT, ">$cp_file")
		|| error_end(__LINE__, "파일 오류", $!);
	binmode(OUT);
	
	my $buffer;
	while(read(IN, $buffer, 1024)) {
		print OUT $buffer;
	}

	close(OUT) || error_end(__LINE__, "파일 오류", $!);
	close(IN)  || error_end(__LINE__, "파일 오류", $!);

#	system("cp $file_path $cp_file");
	
	return 1;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub cp_pedia_img
{
	my ($rep_id) = @_;
	
	my $file_path = "$RDATA->{plant_img}/opure/o$rep_id.gif";
	my $cp_file   = "$RDATA->{album_img}/u0/o$rep_id.gif";

	if(!(-e $cp_file)) {
		open(IN, "$file_path")
			|| error_end(__LINE__, "파일 오류", $!);
		binmode(IN);
		open(OUT, ">$cp_file")
			|| error_end(__LINE__, "파일 오류", $!);
		binmode(OUT);
	
		my $buffer;
		while(read(IN, $buffer, 1024)) {
			print OUT $buffer;
		}

		close(OUT) || error_end(__LINE__, "파일 오류", $!);
		close(IN)  || error_end(__LINE__, "파일 오류", $!);

#		system("cp $file_path $cp_file");
	}
	
	return 1;
}

###################################################
#  input:()
# retrun:
#comment:
#comment: 부모 식물 표시 데이터를 생성합니다.
#수분,초,검사한초,영양,초,검사한초,위치,유전자1,유전자2
###################################################
sub get_flower_img_htm
{
	my ($uid, $pid, $grow_step, $bg_view) = @_;
	
	my $img_dir  = $RDATA->{img_dir};
	my $alb_dir  = $RDATA->{album_img};
	my $img_step = ($grow_step == 6)? 0: $grow_step;
	
	my ($htm_h, $htm_t);
	for(my $organ_id = 1; $organ_id <= 3; $organ_id++) {
		$htm_h .= qq{
			<table cellspacing='0' cellpadding='0'><tr>
			<td background='$alb_dir/u$uid/p${img_step}_${organ_id}_${pid}.gif'>
		} if($pid >= 0);
		$htm_t .= qq{
			</td></tr></table>
		} if($pid >= 0);
	}
	
	return ($uid <= 1)? qq{
		<table border='0' cellpadding='0' cellspacing='0'><tr><td $bg_view>
		<table cellspacing='0' cellpadding='0'><tr>
		<td background='$img_dir/soil1.gif'>
		$htm_h
		<img src="$img_dir/space.gif" height=200 width=100 align=top border=1>
		$htm_t
		</td></tr></table></td></tr></table>
	}: qq{
		<table border='0' cellpadding='0' cellspacing='0'><tr><td $bg_view>
		<table cellspacing='0' cellpadding='0'><tr>
		<td background='$img_dir/soil1.gif'>
		$htm_h
		<a href='$PNAME?MODE=view_parent&UID=$uid&PID=$pid'>
		<img src="$img_dir/space.gif" height=200 width=100 align=top border=1 alt="이 식물의 선조 보기"></a>
		$htm_t
		</td></tr></table></td></tr></table>
	};
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_help_htm
{
	my $ritem_shop = get_item_shop();
	
	my $str = "Content-type: text/html\n\n";
	$str .= qq{<html><head>};
	$str .= get_head();
	$str .= qq{
		<title>아이템 도움말</title>
		</head>
		<body bgcolor='#d1f8d8' background='' onLoad=''>
			<center><img src='$RDATA->{img_dir}/inc_plant.gif' border='0'></center>
			<br><br><center>
		<table width="450" border="0" cellspacing="0" cellpadding="0"><tr><td bgcolor="#550000"> 
		<table border="0" cellspacing="1" cellpadding="2" height="100%" width="100%">
			<tr bgcolor="#ffaaaa" class='table_top'>
				<th>아이템명</th>
				<th>구매가/판매가</th>
				<th>최대 보유 수</th>
				<th>구입레벨</th>
				<th>설명</th>
			</tr>
	};
	foreach (@{$ritem_shop->[1]}) {
		my $ri = $ritem_shop->[0]->{"$_"};
		my $sold_plice = ($ri->[5] >= 0)? "$ri->[5]$RDATA->{monney}": "판매할 수 없음";
		my $buy_max    = ($ri->[0] == 4)? "---": $ri->[4] || 10;
		my $level      = ($ri->[0] == 4)? "---":
			($RDATA->{level_setting}->[$ri->[6]]->[0] || $RDATA->{kyuu}->[$ri->[6]]);
		
		$str .= qq{
			<tr bgcolor="#FFFFFF" class='table_bottom'>
				<td><img src='$RDATA->{img_dir}/$ri->[3]'><br>$ri->[1]</td>
				<td>$ri->[2]$RDATA->{monney}/$sold_plice</td>
				<td align='right'>$buy_max</td>
				<td>$level</td>
				<td>$ri->[7]</td>
			</tr>
		};
	}
	$str .= qq{
		</table></td></tr></table>
		<form><input type='button' value='돌아가기' onClick='history.back()'></form>
		</center>
	};
	$str .= get_copyright();
	$str .= qq{<br></body></html>};
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_parent_album_htm
{
	my ($alert_str, $uid1, $uid2, $pid1, $pid2, $my_plant);
	my ($uid, $pid) = ($PARAM->{UID}, $PARAM->{PID});
	my $rsecret = get_secret_data();
	my $rallu   = get_all_udata_hash();
	my $rseed   = get_seed_data($uid);
	my $rdata   = $rseed->{"$pid"};
	if(!defined($rdata)) {
		my $rplant = get_plant_data($uid);
		$rdata = $rplant->{"$pid"};
		if(!defined($rdata)) {
			my $ralbum = get_album_data($uid);
			$rdata = $ralbum->{"$pid"};
		}
		($uid1, $uid2, $pid1, $pid2) = (@$rdata)[19, 20, 21, 22];
		$my_plant = $rdata->[1];
	} else {
		($uid1, $uid2, $pid1, $pid2) = (@$rdata)[6, 7, 8, 9];
		$my_plant = $rdata->[2];
	}
	my $bk_btn_str
		= qq{&nbsp;&nbsp;&nbsp;<input type='button' value='첫 화면으로' onClick="location.href='$RDATA->{home_url}'">}
		if($PARAM->{BK});
	
	my $str = "Content-type: text/html\n\n";
	$str .= qq{<html><head>};
	$str .= get_head();
	$str .= qq{
		<title>식물 계보도</title>
		</head>
		<body bgcolor='#d1f8d8' background='' onLoad=''>
		<center><img src='$RDATA->{img_dir}/inc_plant.gif' border='0'></center><br>
		<form name='plant'><center>
		<table border='0' cellpadding='0' cellspacing='0' bgcolor='#dddddd'><tr><td colspan='4'>
			<table width="100%" border="0" cellspacing="0" cellpadding="0"><tr><td bgcolor="#008800"> 
			<table border="0" cellspacing="1" cellpadding="2" height="100%" width="100%">
				<tr><td bgcolor="#bbffbb" class='table_top user_top' align="center">
					<b>「$rallu->{"$uid"}->[1]님」의「$my_plant」의 부모</b>
				</td></tr>
			</table></td></tr></table></td></tr>
	};
	foreach ([$uid1, $pid1], [$uid2, $pid2]) {
		my ($suid, $spid) = @$_;
		my ($pname, $bg_view, $flower_img, $flower_stat, $flower_pol, $icon_img);
		my $find_flg = 0;
		my $uname = ($suid == 1)? "플라워 팜": qq{$rallu->{"$suid"}->[1]님};
		if(-e "$RDATA->{data_dir}/u$suid/album.cgi") {
			my $ralbum  = get_album_data($suid);
			my $rdata_e = $ralbum->{"$spid"};
			if(!defined($rdata_e)) {
				my $rplant = get_plant_data($suid);
				$rdata_e = $rplant->{"$spid"};
			}
			if(defined($rdata_e)) {
				$find_flg = 1;
				my $rcreature = get_expression_data((@$rdata_e)[16, 17]);
				my $bgcol = get_flower_bgcolor($rcreature);
				$pname = qq{<font size='-1'>「$uname」의<br>  「$rdata_e->[1]」</font>};
				my $pure_flg = (-e "$RDATA->{album_img}/u$suid/bg_${spid}.gif")? 1: 0;
				if($pure_flg) {
					$bg_view  = "background='$RDATA->{album_img}/u$suid/bg_${spid}.gif'";
					$icon_img = "<img src='$RDATA->{img_dir}/pure.gif' border='0'>";
				} else {
					$bg_view = "bgcolor='$bgcol'";
				}
				$icon_img .= "<img src='$RDATA->{img_dir}/secret.gif' border='0'>"
					if(get_secret_type($rsecret, $rcreature));
				$icon_img .= "<br>\n" if($icon_img);
				
				$flower_img  = get_flower_img_htm($suid, $spid, $rdata_e->[5], $bg_view);
				my $rstat = get_flower_status_data($rcreature);
				$flower_stat = get_flower_status($rstat);
				$flower_pol .= "<hr><font size='-1'>촬영일: <br>"
					. get_day_str($rdata_e->[25]) . "</font><br>\n";
				$flower_pol .= "<hr><font size='-1'>교배료: $rdata_e->[24]/$rdata_e->[23]</font><br>"
					if(!$pure_flg);
			}
		}
		if(!$find_flg){
			$pname = "<font color='red' size='-1'>선조 데이터를 찾을 수 없습니다</font>";
			$flower_img = qq{
				<table border='0' cellpadding='0' cellspacing='0'><tr><td bgcolor='white'>
				<table cellspacing='0' cellpadding='0'><tr>
				<td background='$RDATA->{img_dir}/soil1.gif'>
					<img src="$RDATA->{img_dir}/hatena.gif" height=200 width=100 align=top border=1>
				</td></tr></table></td></tr></table>
			};
		}
		$str .= qq{
			<td valign='bottom'>
			<table width="225" border="0" cellspacing="0" cellpadding="0"><tr><td bgcolor="#008800"> 
			<table border="0" cellspacing="1" cellpadding="2" height="100%" width="100%">
				<tr><td bgcolor="#bbffbb" align="center" class='table_top flower_top'>
					<b><font color="#003300" face="Arial, Helvetica, sans-serif">$pname</font></b>
				</td></tr>
				<tr><td bgcolor="#FFFFFF" align="center" class='table_bottom'>
					<table><tr>
						<td colspan='3' align='center'>
							$flower_img
						</td><td valign='top'>
							$icon_img
							$flower_stat
							$flower_pol
						</td>
					</tr></table>
				</td></tr>
			</table></td></tr></table>
			</td>
		};
	}
	$str .= qq{
			<tr><td colspan='4'>
			<table width="100%" border="0" cellspacing="0" cellpadding="0"><tr><td bgcolor="#008800"> 
			<table border="0" cellspacing="1" cellpadding="2" height="100%" width="100%">
				<tr><td bgcolor="#bbffbb" align="center" class='table_top user_bottom'>
					<input type='button' value=' 돌아가기 ' onClick="history.back()">
					<input type='button' value=' 돌아가기 ' onClick="history.back()">
					$bk_btn_str
				</td></tr>
			</table></td></tr></table></td></tr>
		</table></center></form>
	};
	$str .= get_copyright();
	$str .= qq{<br></body></html>};

	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_mono_album_htm
{
	my ($pname, $bg_view, $flower_img, $flower_stat, $flower_pol, $icon_img);

	my ($uid, $pid) = ($PARAM->{UID}, $PARAM->{PID});
	my $rsecret     = get_secret_data();
	my $rallu       = get_all_udata_hash();
	my $alb_table_str = get_plant_table_htm($uid, $pid, $rallu, $rsecret);
	
	my $str = "Content-type: text/html\n\n";
	$str .= qq{<html><head>};
	$str .= get_head();
	$str .= qq{
		<title>식물 표시</title>
		</head>
		<body bgcolor='#d1f8d8' background='' onLoad=''>
		<center><img src='$RDATA->{img_dir}/inc_plant.gif' border='0'></center><br>
		<form><center>
		<table border='0' cellpadding='0' cellspacing='0' bgcolor='#dddddd'>
			<tr><td valign='bottom'>
				$alb_table_str
			</td></tr>
			<tr><td colspan='4'>
			<table width="100%" border="0" cellspacing="0" cellpadding="0"><tr><td bgcolor="#008800"> 
			<table border="0" cellspacing="1" cellpadding="2" height="100%" width="100%">
				<tr><td bgcolor="#bbffbb" align="center" class='table_top album_bottom'>
					<input type='button' value=' 돌아가기 ' onClick="history.back()">
					<input type='button' value=' 돌아가기 ' onClick="history.back()">
				</td></tr>
			</table></td></tr></table></td></tr>
		</table></center></form>
	};
	$str .= get_copyright();
	$str .= qq{<br></body></html>};

	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_plant_table_htm
{
	my ($uid, $pid, $rallu, $rsecret) = @_;
	my ($pname, $bg_view, $flower_img, $flower_stat, $flower_pol, $icon_img);

	my $ralbum   = get_album_data($uid);
	my $rdata    = $ralbum->{"$pid"};
	my $my_plant = $rdata->[1];
	my $uname = ($uid == 1)? "플라워 팜": qq{$rallu->{"$uid"}->[1]님};
	if(defined($rdata->[1])) {
		my $rcreature = get_expression_data((@$rdata)[16, 17]);
		my $bgcol = get_flower_bgcolor($rcreature);
		$pname = qq{<font size='-1'>「<a href='$PNAME?MODE=album&OPT=$uid&BT=1'>}
			. qq{$uname</a>」의<br>  「$rdata->[1]」</font>};
			
		my $pure_flg = (-e "$RDATA->{album_img}/u$uid/bg_${pid}.gif")? 1: 0;
		if($pure_flg) {
			$bg_view  = "background='$RDATA->{album_img}/u$uid/bg_${pid}.gif'";
			$icon_img = "<img src='$RDATA->{img_dir}/pure.gif' border='0'>";
		} else {
			$bg_view = "bgcolor='$bgcol'";
		}
		$icon_img .= "<img src='$RDATA->{img_dir}/secret.gif' border='0'>"
			if(get_secret_type($rsecret, $rcreature));
		$icon_img .= "<br>\n" if($icon_img);

		$flower_img  = get_flower_img_htm($uid, $pid, $rdata->[5], $bg_view);
		my $rstat = get_flower_status_data($rcreature, $pure_flg);
		$flower_stat = get_flower_status($rstat);
		$flower_pol .= "<hr><font size='-1'>촬영일: <br>"
			. get_day_str($rdata->[25]) . "</font><br>\n";
		$flower_pol .= "<hr><font size='-1'>교배료: $rdata->[24]/$rdata->[23]</font><br>"
			if(!$pure_flg);
	} else {
		$pname = "---";
		$flower_img = qq{<font color='red'>이 식물은 삭제되었습니다.</font>};
	}

	my $str;
	$str .= qq{
			<table width="225" border="0" cellspacing="0" cellpadding="0"><tr><td bgcolor="#008800"> 
			<table border="0" cellspacing="1" cellpadding="2" height="100%" width="100%">
				<tr><td bgcolor="#bbffbb" align="center" class='table_top flower_top'>
					<b><font color="#003300" face="Arial, Helvetica, sans-serif">$pname</font></b>
				</td></tr>
				<tr><td bgcolor="#FFFFFF" align="center" class='table_bottom'>
					<table><tr>
						<td colspan='3' align='center'>
							$flower_img
						</td><td valign='top'>
							$icon_img
							$flower_stat
							$flower_pol
						</td>
					</tr></table>
				</td></tr>
			</table></td></tr></table>
	};

	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_head
{
	return qq{
		<meta HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
		<meta NAME="author" CONTENTS="GIGAHO">
		<link rel="stylesheet" type="text/css" href="$RDATA->{css_dir}/inc_plant.css">
	};
}

#####################################################################################################

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_user_uranai
{
	my ($uid) = @_;
	
	my ($frt_type, $user_id, $fortune, $order_str);
	if(-e "$RDATA->{data_dir}/uranai.cgi") {
		open(IN, "$RDATA->{data_dir}/uranai.cgi")
			|| error_end(__LINE__, "파일 오류", $!);
		<IN>;	#skip
		while(chomp(my $line = <IN>)) {
			($user_id, $fortune, $order_str) = split(/\t/, $line);
			if($user_id == $uid) {last;}
		}
		close(IN) || error_end(__LINE__, "파일 오류", $!);
	}
	if($user_id != $uid) {
		$fortune = rand();
		$order_str = undef;
	}
	
	if($fortune < 1 / 30)     {$frt_type = 6;}	#comment: 아래 함수의 처리 내용을 설명합니다.
	elsif($fortune < 3 / 30)  {$frt_type = 5;}	#comment: 아래 함수의 처리 내용을 설명합니다.
	elsif($fortune < 10 / 30) {$frt_type = 4;}	#comment: 아래 함수의 처리 내용을 설명합니다.
	elsif($fortune < 20 / 30) {$frt_type = 3;}	#comment: 아래 함수의 처리 내용을 설명합니다.
	elsif($fortune < 25 / 30) {$frt_type = 2;}	#comment: 아래 함수의 처리 내용을 설명합니다.
	elsif($fortune < 29 / 30) {$frt_type = 1;}	#comment: 아래 함수의 처리 내용을 설명합니다.
	else                      {$frt_type = 0;}	#comment: 아래 함수의 처리 내용을 설명합니다.
	
	
	return [$frt_type, $order_str];
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub make_uranai_data
{
	my ($time) = @_;
	my $btime = get_uranai_time();
	
	if(!defined($btime) || int(($btime + $JST) / 86400) < int(($time + $JST) / 86400)) {
		my %ft;
		my $rallu  = get_all_udata_hash();
		my $num   = 0;
		foreach (values(%$rallu)) {
			$num ++;
			my $fortune = rand();
			push(@{$ft{"$fortune"}}, $_);
		}
	
		my $order = $num;
		open(OUT, ">$RDATA->{data_dir}/uranai.cgi")
			|| error_end(__LINE__, "파일 오류", $!);
		print OUT "$time\n";
		foreach my $fortune (sort {$a <=> $b} keys(%ft)) {
			foreach (@{$ft{"$fortune"}}) {
				print OUT "$_->[0]\t$fortune\t$order/$num\n";
				$order--;
			}
		}
		close(OUT) || error_end(__LINE__, "파일 오류", $!);
	}
	
	return 1;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_uranai_time
{
	my $btime;
	
	if(-e "$RDATA->{data_dir}/uranai.cgi") {
		open(IN, "$RDATA->{data_dir}/uranai.cgi")
			|| error_end(__LINE__, "파일 오류", $!);
		chomp($btime = <IN>);
		close(IN) || error_end(__LINE__, "파일 오류", $!);
	}
	
	return $btime;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub make_backup_data
{
	my ($time) = @_;
	
	if((my $backup_dir = $RDATA->{backup}->{dir})
		&& (my $time_span = $RDATA->{backup}->{span} * 60)) {
		
		if(!(-e $backup_dir)) {return 0;}
		my $btime = get_backup_time();
		
		if(!defined($btime) || $btime + $time_span <= $time) {
			unless(fork){
				close(STDOUT);
				my @data_time;
				my $tar  = $RDATA->{backup}->{tar} || "tar";
				my $cmd1 = "$tar -czf $backup_dir/data$time.tgz $RDATA->{data_dir}";
				my $cmd2 = "$tar -czf $backup_dir/img$time.tgz $RDATA->{album_img}";
				system($cmd1); system($cmd2);
				opendir(DIR, $backup_dir) || error_end(__LINE__, "opendir 오류", $!);
				while (my $dir = readdir(DIR)) {
					if(my ($dtime) = $dir =~ /^data(\d+)/) {
						push(@data_time, $dtime);
					}
				}
				closedir(DIR) || error_end(__LINE__, "closedir 오류", $!);
				my @ftime = reverse(sort {$a <=> $b} @data_time);
				for(my $cnt = 0; $cnt < @ftime; $cnt ++) {
					if($RDATA->{backup}->{count} <= $cnt) {
						unlink("$backup_dir/data$ftime[$cnt].tgz");
						unlink("$backup_dir/img$ftime[$cnt].tgz");
					}
				}
				exit 0;
			}
		
			open(OUT, ">$RDATA->{data_dir}/backup.cgi")
				|| error_end(__LINE__, "파일 오류", $!);
			print OUT "$time\n";
			close(OUT) || error_end(__LINE__, "파일 오류", $!);
		}
	}
	
	return 1;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_backup_time
{
	my $btime;
	
	if(-e "$RDATA->{data_dir}/backup.cgi") {
		open(IN, "$RDATA->{data_dir}/backup.cgi")
			|| error_end(__LINE__, "파일 오류", $!);
		chomp($btime = <IN>);
		close(IN) || error_end(__LINE__, "파일 오류", $!);
	}
	
	return $btime;
}


#####################################################################################################
###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_server_select_htm
{
	my $rserver = get_server_data();
	my $uid = $PARAM->{UID};
	my $pid = $PARAM->{PID};
	my $site_url = "http://$ENV{HTTP_HOST}$ENV{SCRIPT_NAME}"; $site_url =~ s/\/\Q$PNAME\E//;
#	my $uname = get_uname($uid);
	
	my $str = "Content-type: text/html\n\n";
	$str .= qq{<html><head>};
	$str .= get_head();
	$str .= qq{
		<title>신기한 식물서버선택</title>
		</head>
		<body bgcolor='#d1f8d8' background='' onLoad=''>
			<center><img src='$RDATA->{img_dir}/inc_plant.gif' border='0'></center>
			<form><center>
			<table width="450" border="0" cellspacing="0" cellpadding="0"><tr><td bgcolor="#000099"> 
			<table border="0" cellspacing="1" cellpadding="2" height="100%" width="100%">
				<tr><td bgcolor="#bbbbff" colspan='3' class='table_top score_top'>
					<table width='100%'><tr><td align='left'>
						<font color='blue'><b>서버 선택 화면</b></font>
					</td><td align='right'>
						<input type="button" value='돌아가기' onClick='location.href="$PNAME?UID=$uid&MODE=main"'>
					</td></tr></table>
				</td></tr>
	};
	foreach (values(%$rserver)) {
		my ($url, $key, $serv_name) = @$_;
		$serv_name = "$url/inc_plant_server.cgi" if(!$serv_name);
		$str .= qq{
			<tr>
				<td bgcolor="white">
					<a href='$url/inc_plant_server.cgi?MODE=cli_sel&NAM=$PARAM->{NAM}&URL=$site_url&UID=$uid&PID=$pid'>
					$serv_name</a>
				</td>
			</tr>
		}
	}
	$str .= qq{
			</table></td></tr></table>
			</center></form>
	};
	$str .= get_copyright();
	$str .= "<br></body></html>";
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_server_login_htm
{
	my ($res_str);
	my $err_type = -1;
	my $pass = $PARAM->{PWD};

	my $rudt = get_uid_from_namepass($PARAM->{NAM}, $pass);
	my ($uid, $ses_id) = @$rudt;
	if(!defined($uid) || $uid != $PARAM->{UID}) {
		$err_type = 1;
	} else {
		my $charge  = $PARAM->{CHARGE};
		my $ruser   = get_status_data($uid);
		my ($rstatus, $ritems) = @$ruser;
		if($charge > $rstatus->[0]) {
			$err_type = 2;
			$res_str = "보유 금액이 부족합니다";
		} elsif($rstatus->[5] >= $rstatus->[6]) {
			$err_type = 3;
			$res_str = "더 이상 씨앗을 가질 수 없습니다";
		} else {
			$rstatus->[0] -= $charge;
			put_status_data($uid, $ruser);
			put_self_history($uid,
				qq{다른 필드와 교배했습니다. 교배료와 중개료 합계 $charge$RDATA->{monney}를 지불했습니다}, "green"
			);
		}
	}

	my $str = "Content-type: text/plain\n\n";
	$str .= "$err_type\n$res_str";
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_server_payment_htm
{
	my (%creature, $res_str);
	my $err_type = -1;
	
	my $rserver  = get_server_data();
	my $serv_key = $rserver->{"$PARAM->{URL}"}->[1];
	my ($uid, $pid) = ($PARAM->{UID}, $PARAM->{PID});
	my $rdna = get_new_haploid($uid, $pid, 1);
	if(!$serv_key || $serv_key ne $PARAM->{KEY}) {
		$err_type = 5;
		$res_str = "정상적인 서버 정보를 가져올 수 없었습니다";
	} elsif(!$rdna) {
		$err_type = 4;
		$res_str = "수분할 수 없는 씨앗입니다";	#comment: 아래 함수의 처리 내용을 설명합니다.
	} else {
		my $sizerr_flg = 0;
		my ($dna, $rdata) = @$rdna;
		inc_inc::add_translated_gene_data(\%creature, $dna);
		foreach (values(%creature)) {
			foreach (@{$_->{protein}}) {
				my $organ_id = $_->{organ};
				my $im_id    = $_->{domain};
				my $tcript   = $_->{transcript};
				my $size = get_file_size($organ_id, $im_id);
				if($size == 0) {$sizerr_flg = 1; last;}
				$res_str .= "$tcript,$size|";
			}
		}
		if($sizerr_flg) {
			$err_type = 7;
			$res_str = "이미지 데이터가 잘못되었습니다.";
		} else {
			my $charge = $PARAM->{CHARGE};
			my $rsplant = get_album_data($uid);
			$rsplant    = get_plant_data($uid) if(!defined($rsplant->{"$pid"}));
			my ($pname, $def_seed_cost) = (@{$rsplant->{"$pid"}})[1, 24];
			if($charge == $def_seed_cost) {
				write_new_popflower($uid, $pid);
				my $ruser  = get_status_data($uid);
				my ($rstatus, $ritems) = @$ruser;
				$rstatus->[0] += $charge;
				put_status_data($uid, $ruser);
				put_self_history($uid,
					qq{<a href='$PARAM->{FURL}/inc_plant.cgi'>$PARAM->{FNAM}</a>의}
					. qq{$PARAM->{NAM}님에게서 $pname 교배료 $charge$RDATA->{monney}를 받았습니다}, "green"
				);
			} else {
				$err_type = 6;
				$res_str = "교배료가 일치하지 않습니다";
			}
		}
	}

	my $str = "Content-type: text/plain\n\n";
	$str .= "$err_type\n$res_str";
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_server_makeseed_htm
{
	my ($err_type, $res_str);
	
	my ($uid, $pid) = ($PARAM->{UID}, $PARAM->{PID});
	my $new_dna  = get_outer_dna_data();
	my $rserver  = get_server_data();
	my $serv_key = $rserver->{"$PARAM->{URL}"}->[1];
	if(!$serv_key || $serv_key ne $PARAM->{KEY}) {
		$err_type = 5;
		$res_str = "정상적인 서버 정보를 가져올 수 없었습니다";
	} elsif(length($new_dna) != 53 * 5) {
		$err_type = 8;
		$res_str = "필드의 토양이 맞지 않는 것 같습니다.<br>수분에 실패했습니다.";
	} elsif(my $rnew_dna = get_new_dna2($uid, $pid, $new_dna)) {
		my $ruser   = get_status_data($uid);
		my $rstatus = $ruser->[0];
		$rstatus->[5]++;
		my $new_pid = ++$rstatus->[4];
		my $rseed = get_seed_data($uid);
		$rseed->{"$new_pid"} = [$new_pid, 0, "새 식물($new_pid)",
			@$rnew_dna, $uid, undef, $pid, undef];
		put_seed_data($uid, $rseed);
		put_status_data($uid, $ruser);
		$err_type = -1;
		$res_str = "수분에 성공하여 씨앗을 얻었습니다.";
	} else {
		$err_type = 9;
		$res_str = "수분에 실패했습니다";
	}

	my $str = "Content-type: text/plain\n\n";
	$str .= "$err_type\n$res_str\n";
	
	return $str;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_outer_dna_data
{
	my (@cres, $new_dna);
	my $ok_cnt = 0;
	
	foreach (split(/\|/, $PARAM->{HAPLOID})) {
		my (%tmp_cre);
		my ($tcript, $size) = split(/,/, $_);
		inc_inc::add_translated_gene_data(\%tmp_cre, $tcript);
		push(@cres, [\%tmp_cre, $size]);
	}
	
	my $rdnas = get_dna_data();
	OUTER: foreach (@$rdnas) {
		my %creature;
		inc_inc::add_translated_gene_data(\%creature, $_->[0]);
		foreach my $rcre (@cres) {
			my ($rtmp_cre, $size) = @$rcre;
			if(!$rtmp_cre) {next;}
			my ($organ_id) = keys(%$rtmp_cre);
			my $rrd = $rtmp_cre->{"$organ_id"};
			foreach my $rd (@{$rrd->{protein}}) {
				foreach (@{$creature{"$organ_id"}->{protein}}) {
					if($rd->{domain} == $_->{domain} && $rd->{reaction} == $_->{reaction}
						&& $size == get_file_size($organ_id, $_->{domain})) {
						
						$new_dna .= $_->{transcript};
						$rcre->[0] = undef;
						$ok_cnt ++;
						last;
					}
				}
				if($ok_cnt == 5) {last OUTER;}
			}
		}
	}
	return $new_dna;
}

###################################################
#  input:()
# retrun:[$dna1, $dna2, $total]
#comment:
###################################################
sub get_new_dna2
{
	my ($uid1, $pid1, $dna2) = @_;
	my (%creature);

	my $rdna1 = get_new_haploid($uid1, $pid1, 0);
	if(!$rdna1) {return undef;}
	my ($dna1, $rdata1) = @$rdna1;
	inc_inc::add_translated_gene_data(\%creature, $dna1);
	inc_inc::add_translated_gene_data(\%creature, $dna2);
	inc_inc::add_expression_data(\%creature);
	if($creature{"1"}->{power} * $creature{"2"}->{power} * $creature{"3"}->{power}) {
		#comment: 아래 함수의 처리 내용을 설명합니다.
		return [$dna1, $dna2, $rdata1->[18]];
	}
	
	return undef;
}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_file_size
{
	my ($organ_id, $im_id) = @_;
	
	my $file_path = "$RDATA->{plant_img}/o5/o${organ_id}_${im_id}.gif";
	if(!(-e $file_path)) {
		$file_path = "$RDATA->{plant_img}/o5/o${organ_id}_1.gif";
	}
	my $size = -s $file_path;
	
	return $size;
}

#####################################################################################################
###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_copyright
{
	my $str = "<hr size='1'>\n";
	
	$str .= "<table width='100%' border='0' cellspacing='0' cellpadding='0' class='copyright'>\n";
#	$str .= "<tr><td align='right'><font size='-2'>" . get_cpu_time() . "CPUs</font></td></tr>\n";
	$str .= "<tr><td align='right'><font size='-2'>$VERSION</font></td></tr>\n";

	foreach (@{$RDATA->{copyright}}) {
		$str .= "<tr><td align='right'><font size='-1'>$_</font></td></tr>\n";
	}

	$str .= "</table>\n";
	
	return $str;
}

###################################################
#  input:($type, $comment, $point)
# retrun:exit 1
#comment: 오류 처리 서브루틴
###################################################
sub error_end
{
	my ($point, $type, $comment, $no_unlock_flg) = @_;
	$comment =~ s/\n/ /g;
	
	my_funlock($LOCK) if(!$no_unlock_flg);

	sys_common::error_htm("$PNAME($VERSION)", $point, $type, $comment,
		{file => "$RDATA->{'data_dir'}/cgi.err"});

	exit 1;
}

###################################################
#  input:()
# retrun:
#comment:http://www.bayashi.net/st/pdmemo/filelock.html
# flock 방식의 잠금 처리
# 오래된 잠금 파일은 제한 시간이 지나면 회수합니다.
###################################################
sub my_flock
{
	my $lock;
	my $times      = 10;
	my $break_time = $RDATA->{break_time} || 60;
	
	my $lock_dir = $RDATA->{lock_dir};

	my $filename;
	opendir(LOCKDIR, $lock_dir);
	while ($filename = readdir(LOCKDIR)) {
		if($filename =~ /lockfile/) {last;}
	}
	closedir(LOCKDIR);
	
	if(!defined($filename)) {return -1;}
	
	my $lock_name = "$lock_dir/lockfile";
	if ($filename =~ /^lockfile(\d+)/) {
		return $lock if (time - $1 > $break_time &&
			rename("$lock_name$1", $lock = $lock_name . time));
	}

	for (my $i = 0; $i < $times; $i++, sleep 1) {
		return $lock if (rename($lock_name, $lock = $lock_name . time));
	}
	
	return undef;
}

sub my_funlock
{
	my $lock = shift;
	if(!rename($lock, "$RDATA->{lock_dir}/lockfile")) {
		sys_common::write_log("$PNAME($VERSION)", "unlock",
			"파일 손상 가능성이 있습니다. 자주 발생하면 break_time 값을 늘려 주세요.",
			{file => "$RDATA->{'data_dir'}/cgi.err", return => 1}
		);
	}
}

###################################################
#  input:()
# retrun:
#comment: HTML 이스케이프 처리
###################################################
sub get_safe_htm
{
	my ($str, $flg) = @_;

	$str =~ s/&/&amp;/g;
	$str =~ s/</&lt;/g;
	$str =~ s/>/&gt;/g;
	$str =~ s/\r\n|\r|\n|\t/<br>/g if($flg != 2);
	$str =~ s/ /&nbsp;/g if(!$flg);
	$str =~ s/"/&quot;/g;
	$str =~ s/'/&#39;/g;

	return $str;
}

##################################################
#input  :
#return :
#comment:
##################################################
sub is_cookie_ok
{
	my $uid = $PARAM->{UID};
	
	my $rcook = get_cookie();
	if($uid && $rcook->{UCK} eq "$uid\@" . get_session_id($uid))
		{return 1;}
	
	return 0;
}

##################################################
#input  :
#return :
#comment:
##################################################
sub get_cookie
{

	my $cookie_str = $ENV{'HTTP_COOKIE'};
	my (%data, @cookie);

	@cookie = split(/ /, $cookie_str);

	foreach (@cookie) {
		my ($name, $val) = split(/=/);
		$val =~ s/;$//;
		$data{$name} = $val;
	}
	return \%data;

}

###################################################
#  input:()
# retrun:
#comment:
###################################################
sub get_cpu_time
{
	
	my @cpu = times();
	
	return int(($cpu[0] + $cpu[1]) * 1000) / 1000;
}


##################################################
#input  :
#return :
#comment:
##################################################
sub get_time_str
{
	my $time = shift;
	
	my ($min, $hour, $mday, $mon) = (localtime($time))[1, 2, 3, 4];

	$min  = sprintf("%02d", $min);
	$hour = sprintf("%02d", $hour);
	$mday = sprintf("%02d", $mday);
	$mon  = $mon + 1;

	my $time_str = "$mon월$mday일$hour시$min분";
	
	return $time_str;
}

##################################################
#input  :
#return :
#comment:
##################################################
sub get_day_str
{
	my $time = shift;
	
	my ($mday, $mon, $year) = (localtime($time))[3, 4, 5];

	$mday = sprintf("%02d", $mday);
	$mon  = sprintf("%02d", $mon + 1);

	my $time_str = ($year + 1900) . "년$mon월$mday일" ;
	
	return $time_str;
}

##################################################
#input  :
#return :
#comment:
##################################################
sub get_daytime_str
{
	my $time = shift;
	
	my ($sec, $min, $hour, $mday, $mon, $year)
		= (localtime($time))[0, 1, 2, 3, 4, 5];
	
	$sec  = sprintf("%02d", $sec);
	$min  = sprintf("%02d", $min);
	$hour = sprintf("%02d", $hour);
	$mday = sprintf("%02d", $mday);
	$mon  = sprintf("%02d", $mon + 1);
	
	my $time_str = ($year + 1900) . "/$mon/$mday $hour:$min:$sec" ;
	
	return $time_str;
}
####################################################################################################

1;
