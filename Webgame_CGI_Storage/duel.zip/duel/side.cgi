#!/usr/bin/perl
#덱 교환

print "Content-type:text/html; charset=utf-8\n\n";

require 'data.lib';

($sec,$min,$hour,$mday,$mon) = localtime(time);
if(length($min)<2){$min="0$min";}
if(length($hour)<2){$hour="0$hour";}
if(length($mday)<2){$mday="0$mday";}
$mon++;
if(length($mon)<2){$mon="0$mon";}
$date=$mon.$mday.$hour.$min;

&get_input;
&get_ini;

if($G{'side1'} eq $id && $G{'side1'} ne ""){$u_side=1;}
elsif($G{'side2'} eq $id && $G{'side2'} ne ""){$u_side=2;}
else{print "Error!";exit;}

open(TIME,">tmp/".$fn."_time".$u_side);
print TIME $date;
close(TIME);

&get_ini2;
&cardread;

print<<"_EOF_";
<html>
<title>DECK CHANGE</title>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=utf-8">
<body bgcolor=#fffff0 background="embak.gif">
<center>
<form action=side.cgi method=post>
<input type=hidden name="id" value="$id">
<input type=hidden name="room" value="$room">
<font size=-1>표시가 이상한 경우는 리로드 해 주세요. </font>
<font size=+1><b><a href="duel.cgi?id=$id&room=$room&start_m=1">듀얼장으로 돌아오는</a></b></font><br>
_EOF_


@add_s = grep(/^add/,keys(%F));
@del_s = grep(/^del/,keys(%F));

@deck2 = @deck;
@side2 = @side;

if($#add_s!=$#del_s){$overmsg="<b>유희 「안되!　메인과 사이드로부터 같은 장수 선택해 줘」</b>";}
else{
	for($i=0;$i<$#add_s+1;$i++){
		$add_s[$i]=~s/^add//;
		$del_s[$i]=~s/^del//;
		$tmp=$side2[$add_s[$i]];
		$side2[$add_s[$i]]=$deck2[$del_s[$i]];
		$deck2[$del_s[$i]]=$tmp;
	}
	$erflg="";
	for($i=0;$i<$#deck2+1;$i++){
		$cardno=$deck2[$i];
		if($cardno==1037){$cardno=208;}
		$C{$cardno}++;
		if($c_zokusei[$cardno] eq "신" && $C{$cardno}>1){$overmsg.="<b>유희 「안되!　신의 카드는 전체에 1장이야」</b><br>\n";$erflg=1;last;}
		if($C{$cardno}>3){$overmsg.="<b>유희 「안되!　카드는 1종류 3장까지야」</b><br>\n";$erflg=1;last;}
	}
	if($erflg eq ""){
		@deck = sort decksort @deck2;
		@side = sort decksort @side2;
	}
}



sub decksort{
	if($c_zokusei[$a] eq "마"){$lva=1;}
	elsif($c_zokusei[$a] eq "함정"){$lva=2;}
	elsif($c_syokan[$a]==1){$lva=3;}
	else{$lva=0;}
	if($c_zokusei[$b] eq "마"){$lvb=1;}
	elsif($c_zokusei[$b] eq "함정"){$lvb=2;}
	elsif($c_syokan[$b]==1){$lvb=3;}
	else{$lvb=0;}
	if($lva ne $lvb){return($lva cmp $lvb);}

	if($lva==1 || $lva==2){return($c_name[$a] cmp $c_name[$b]);}

	if($c_ap[$a]=~/^X/){$pta=4000;}
	elsif($c_ap[$a]<$c_dp[$a]){$pta=$c_dp[$a];}
	else{$pta=$c_ap[$a];}

	if($c_ap[$b]=~/^X/){$ptb=4000;}
	elsif($c_ap[$b]<$c_dp[$b]){$ptb=$c_dp[$b];}
	else{$ptb=$c_ap[$b];}
	if($ptb ne $pta){$ptb <=> $pta;}
	else{$c_name[$a] cmp $c_name[$b];}
}

&put_ini2;

#표시

for($i=0;$i<$#deck+1;$i++){
	if($c_syokan[$deck[$i]]==1){push(@yugo_deck,$deck[$i]);push(@yugo_num,$i);}
	else{push(@main_deck,$deck[$i]);push(@main_num,$i);}
}

print<<"_EOF_";
$overmsg

<table border=4 cellpadding=5><tr valign=top>
<td colspan=2 align=center>
<font size=+2><input type=submit value="교환">
</font>
<br>
</td>
</tr><tr valign=top>
<td>
<font size=+1><b>사이드 덱</b></font><br>
_EOF_

if($#side<0){print "<br>\n<i>사이드 덱은 없습니다. </i>\n";}

for($i=0;$i<$#side+1;$i++){
	$j=$side[$i];
	print "<input type=checkbox name=\"add$i\">\n";
	&print_line;
}

print<<"_EOF_";
</td><td>
<font size=+1><b>메인 덱</b></font><br>
_EOF_

for($i=0;$i<$#main_deck+1;$i++){
	$j=$main_deck[$i];
	print "<input type=checkbox name=\"del$main_num[$i]\">\n";
	&print_line;
}

if($#yugo_deck>-1){print "<br><br><FONT SIZE=+1><b>융합 덱</b></font><br>\n";}
for($i=0;$i<$#yugo_deck+1;$i++){
	$j=$yugo_deck[$i];
	print "<input type=checkbox name=\"del$yugo_num[$i]\">\n";
	&print_line;
}

print<<"_EOF_";
<div align=right><input type=submit value="교환"></div><br>
</td></tr></table>
</body></html>

_EOF_


############################################
sub print_line{
	if(($c_zokusei[$j] eq "마" || $c_zokusei[$j] eq "함정" || $c_koka[$j] ne "") && !grep(/^$j$/,@ava)){$tmpname="<i>$c_name[$j]</i>";}
	else{$tmpname=$c_name[$j];}

	if($c_zokusei[$j] eq "마"){print "<a href=\"$khelp#$j\" target=new>$tmpname</a>/$c_syuzoku[$j]마법<br>\n";}
	elsif($c_zokusei[$j] eq "함정"){print "<a href=\"$khelp#$j\" target=new>$tmpname</a>/$c_syuzoku[$j]함정<br>\n";}
	else{
		print "$tmpname/$c_zokusei[$j]/$c_syuzoku[$j]/$c_ap[$j]:$c_dp[$j]/$c_lv[$j]";
		if($c_koka[$j]==2 || $c_koka[$j]==7){print "/<a href=\"$khelp#$j\" target=new>리버스</a>\n";}
		elsif($c_koka[$j] ne ""){print "/<a href=\"$khelp#$j\" target=new>효과</a>\n";}
		if($c_syokan[$j]==1){print "/<a href=\"$yhelp#$j\" target=new>융합</a>\n";}
		elsif($c_syokan[$j]==2){print "/<a href=\"$yhelp#$j\" target=new>의식</a>\n";}
		elsif($c_syokan[$j]==3){print "/<a href=\"$yhelp#$j\" target=new>조건 소환</a>\n";}
		elsif($c_syokan[$j]==4){print "/<a href=\"$yhelp#$j\" target=new>트</a>\n";}
		print "<br>\n";
	}
}

sub cardread{
	$cou=0;
	open(DATA,"card.txt");
	$lin=<DATA>;
	while(<DATA>){
		chop;
		@tmp=split(/\t/);
		$c_name[$cou]=$tmp[0];
		$c_zokusei[$cou]=$tmp[1];
		$c_syuzoku[$cou]=$tmp[2];
		$c_ap[$cou]=$tmp[3];
		$c_dp[$cou]=$tmp[4];
		$c_lv[$cou]=$tmp[5];
		$c_koka[$cou]=$tmp[6];
		$c_syokan[$cou]=$tmp[7];
		$cou++;
	}
}

sub get_ini{

	open(PFL,"tmp/".$fn);

	while(<PFL>){
		chop;
		($KEY,$VAL) = split(/\t/);
		$G{$KEY} = $VAL;
	}
	close(PFL);
}

sub put_ini2{
	local($i);
	if($id eq ""){return;}

	$P{'deck'}=join(",",@deck);
	$P{'side'}=join(",",@side);

	open(PFL,"> tmp/".$fn."_deck".$u_side);
	foreach $key (keys(%P)){
		print PFL "$key\t$P{$key}\n";
	}
	close(PFL);
}

sub get_ini2{

	open(PFL,"tmp/".$fn."_deck".$u_side);

	while(<PFL>){
		chop;
		($KEY,$VAL) = split(/\t/);
		$P{$KEY} = $VAL;
	}
	close(PFL);
	@deck=split(/,/,$P{'deck'});
	@side=split(/,/,$P{'side'});
}

sub get_input{
	if (length($ENV{'QUERY_STRING'}) > 0) {
		$INPUT = $ENV{'QUERY_STRING'};
	}
	elsif (length($ENV{'CONTENT_LENGTH'}) > 0) {
		read(STDIN, $INPUT, $ENV{'CONTENT_LENGTH'});
	}
	else {
		while ($TMP[0] = <STDIN>) {
			$INPUT .= $TMP[0];
		}
	}
	$INPUT =~ s/\&+/\&/g;
	$INPUT =~ s/#.+//;
	@TMP = split('&', $INPUT);
	for ($i = 0; $i <= $#TMP; ++$i) {
		($KEY, $VAL) = split('=', $TMP[$i]);
		$VAL =~ tr/+/ /;
		$VAL =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
		$VAL =~ s/\015\012/\012/g;
		$VAL =~ s/\015/\012/g;
		if($VAL ne ""){$F{$KEY}=$VAL;}
	}

	$id = $F{'id'};
	$room = $F{'room'};
	$fn = $roomst.$room;
}

