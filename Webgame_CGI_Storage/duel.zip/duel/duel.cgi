#!/usr/bin/perl

require "duellib.pl";
require "duellib2.pl";
require "magic.pl";
require "trap.pl";
require "koka.pl";
require "koka2.pl";
require "cpu.pl";
require "data.lib";

if ($ENV{'HTTP_ACCEPT_ENCODING'}=~/gzip/ && $gzip ne "") {
	print "Content-type: text/html; charset=utf-8\n";
	print "Content-encoding: gzip\n\n";
	open(STDOUT,"| ".$gzip."gzip -1 -c");
}else{
	print "Content-type: text/html; charset=utf-8\n\n";
}

print<<"_EOF_";
<html>
<title>듀얼장</title>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=utf-8">
<META HTTP-EQUIV="Pragma" CONTENT="no-cache">
<body bgcolor=$bgc text=$textc link=$textlc vlink=$textvc background="$bgimg">
_EOF_

$tehuda_max = 6;
$msgcou=0;

&get_input;

@pfldata = ("phase","bstep","turn","turn2","rule","seigen","c_end","srfchk","match","husatu","worm");
@pfldata2 = ("lp","player","cpu","side","pn","call");
@pflst = ("fld","fld_ad","fld_rf","a_m","a_b","fld_koka","syori","hk","jok","chain","chain2");
@pflst2 = ("deck","tehuda","tep","yugo","boti");

@waitko=("스탠바이","통상 소환","반전 소환","공격 선언","(소환 종료)","특수 소환","특수 소환","특수 소환","뒷수비 세트","마법 사용","함정 사용","엔드");
%cost=(894,700,877,2000,985,1000,1000,500,1207,500);
@omoteura=("표","리");
@seirei=(789,792,790,530,599,179);
@soubiatu=(720,704,1064,1094,973,731,1200);
@exo=(687,145,193,713,714);
@daiyo_mst = (591,590,589,592);
@omoteuse = (496,1078,1087,968,1119,1148);
@syu_arr = ("드래곤","비행야수","번개","해룡","어류","물","전사","야수전사","야수","곤충","파충류","식물","공룡","암석","언데드","악마","마법사","천사","화염","기계");
@mukomsg=("","하데스가 지배하는 명계에 떨어졌다!","다크·발타에 봉쇄되었다! ","케르베로스에 씹혀 부수어졌다!");

$fw1[1] = 10;$fw2[1] = 15;$fw1[2] = 5;$fw2[2] = 0;
$fside[1]=20;$fside[2]=21;

$run_phase=0;

for($i=0;$i<$#gisiki+1;$i+=3){$G_M{$gisiki[$i+1]}=$gisiki[$i];$G_S{$gisiki[$i+1]}=$gisiki[$i+2];}
undef(@gisiki);

($sec,$min,$hour,$mday,$mon,$year) = localtime(time);
if(length($min)<2){$min="0$min";}
if(length($hour)<2){$hour="0$hour";}
if(length($mday)<2){$mday="0$mday";}
$mon++;
if(length($mon)<2){$mon="0$mon";}
$date=$mon.$mday.$hour.$min.$year;

&read_carddata;

if($F{'start'} ne ""){&start;}
else{
	&get_ini;
	&get_playerdata;
	&get_timefile;
}

if($rule==1){$fldw2=1;}	#마법, 함정 필드의 폭
else{$fldw2=5;}

if($room ne ""){
	if($side[1] eq $id && $side[1] ne ""){$u_side=1;}
	elsif($side[2] eq $id && $side[2] ne ""){$u_side=2;}
	else{$read_only=1;$u_side=1;$u_side2=2;$not_control=1;undef(%F);&put_screen;}
	$u_side2 = 3-$u_side;

	$logcou=$t_logcou[$u_side];
	if($t_surr[$u_side2]==1 && $side[1] ne ""){$lp[$u_side2]=0;$syori[0]=3;}
}
else{$u_side=1;$u_side2=2;}

if($F{'mess'} ne ""){$F{'mess'}=~s/</&lt\;/g;&add_msg($pn[$u_side],$F{'mess'});}

if($F{'start_m'} ne ""){&start_m;}

if(($F{'surrender'} ne "") && $syori[0]!~/^3/){		#항복
	&add_msg("null","$pn[$u_side]의 사이드 카드");
	$lp[$u_side]=0;
	if($match eq ""){$surrflg=1;}
	&end_game;
}

if($F{'drop'} ne ""){
	if($side[1] eq ""){
		unlink("tmp/".$roomst.$room."_time2");
		unlink("tmp/".$roomst.$room);
		print "<a href=\"index.cgi?id=$id\">돌아가기</a>";exit;
	}
	else{&add_msg("null","!$u_side<i>(벌써 상대가 있기 때문에 떨어진다면 상대에게 끊어 줘)</i>");}
}
if($room ne "" && $syori[0]!~/^3/ && $side[1] ne "" && $t_date[$u_side2] ne "" && $natime ne "" && $ENV{'SCRIPT_NAME'}!~/gaterar/){
	$n_min=&get_min($date);
	$t_min=&get_min($t_date[$u_side2]);
	if($n_min-$t_min>$natime-1 && $n_min-$t_min<$natime-1+6){
		&add_msg("null","$natime분 동안 엑세스가 없어서 $pn[$u_side2]의 패배");
		$lp[$u_side2]=0;
		&end_game;
	}
}

for($i=0;$i<$#waitko+1;$i++){
	$wait_tmp[$i]=$F{'wait_'.$i};
	$wait_tmpj[$i]=$F{'waitj_'.$i};
}
@{$wait[$u_side]} = @wait_tmp;
@{$waitj[$u_side]} = @wait_tmpj;
$wait[$u_side][6]=$wait[$u_side][5];$wait[$u_side][7]=$wait[$u_side][5];
$waitj[$u_side][6]=$waitj[$u_side][5];$waitj[$u_side][7]=$waitj[$u_side][5];

if($room ne ""){
	@{$wait[$u_side2]} = split(/,/,$t_waitst[$u_side2]);
	@{$waitj[$u_side2]} = split(/,/,$t_waitstj[$u_side2]);
}

if($worm ne ""){
	@tmp=split(/<>/,$worm);
	for($i=0;$i<$#tmp+1;$i++){$tmp[$i]=~/^(\d+)/;push(@jiban2,$1);}
}

&chg_user;

&get_apdp_fld;

&control_chk;
if($not_control==1){$not_control_f=1;}

sub change_phase{
	local($act) = $_[0];
	if($chain[0] ne "" && $chain[0]!~/^[12]-4/){}
	elsif($act==3 && $phase==2){$phase=3;&get_apdp_fld;}
	elsif($act==2 && $phase==3){if($jok[1] ne ""){&bphase_end;}$phase=4;}
	elsif($phase==2){$jok[7]=1;}
}

if($cpu[$s_a]!=1 && $syori[0] eq "" && $not_control!=1 && $chain[0] eq "" && $F{'turn_end'} ne ""){if($jok[1] ne ""){&bphase_end;}$phase=5;}

while($run_phase<50 && $not_control!=1){
	$run_phase++;
	if($syori[0]==3 || $syori[0]=~/^5/){last;}		#종료

#$pst="$run_phase/aside-$s_a/";if($#chain>-1){$pst.="chain[0]-$chain[0]/#chain-$#chain/";}if($c_end ne ""){$pst.="c_end-$c_end/";}if($#chain2>-1){$pst.="chain2[0]-$chain2[0]/#chain2-$#chain2/";}if($#syori>-1){$pst.="syori[0]-$syori[0]/syori[1]-$syori[1]/#syori-$#syori/";}&add_msg($pn[$s_a],"$pst");
	if($syori[0]=~/^4/){		#피의 대상
		if($F{'putcard'} ne ""){
			&put_card_mst;$F{'putcard'}="";
			if($syokan_seiko==1){$bstep="";&del_syori;}
		}
		elsif($F{'not_select'} ne "" || $cpu[$s_a]==1){
			$lp[$s_a]+=500;&del_syori;$F{'not_select'}="";
		}
		else{last;}
	}
	elsif($syori[0]=~/^2/){		#선택
		&syori_p_set;
		if($F{'run_select'} ne "" || $cpu[$S{'i'}]==1){
			$F{'run_select'}="";
			if($#select<0){foreach $key (keys(%F)){if($key!~s/^select_//){next;}push(@select,$key)}}
			if((($S{'o'} ne "" && $F{'options'} eq "") || ($S{'s'} ne "" && $#select<0 && $S{'l'}!=1)) && $cpu[$S{'i'}]!=1){last;}

			$c_bak="";
			if($S{'n'} ne ""){&select_syori;$c_bak=$S{'c'};$p_bak=$S{'p'};}
			elsif($S{'c'} ne ""){&after_select($S{'c'},$S{'p'});}
			&del_syori;
			if($c_bak ne ""){&after_select($c_bak,$p_bak);}
		}
		elsif($F{'not_select'} ne ""){
			&del_syori;$F{'not_select'}="";
		}
		else{last;}
	}
	elsif($chain[0] ne ""){
		if($c_end==1){&del_chain;}
		elsif($F{'go_on'} ne ""){
			$F{'go_on'}="";
			$chudan=$chain[0];
			if($c_end eq ""){
				$c_end==2;
				if(!(&trap_checkj(1))){$c_end=1;&del_chain;}
			}
			elsif($c_end==2){$c_end=1;&del_chain;}
		}
		elsif($cpu[$s_a]==1){&cpu_usecard(3);}
		elsif($F{'usecard'} ne ""){
			$F{'usecard'}="";
			if($F{'use'} eq ""){&add_msg("null","!$s_a(사용하는 카드 지정)");last;}
			&use_card;
		}
		else{last;}
	}
	elsif($chain2[0] ne ""){&del_chain2;}
	else{
		if($phase==0){
			if($cpu[$s_a]==1 || $F{'turn_start'} ne ""){
				if(!($kekka=&draw_phase)){$phase=1;}
			}
			else{last;}
		}
		elsif($phase==1){
			&stanby_phase;
		}
		elsif($phase==2){
			if($cpu[$s_a]!=1){&main_phase;}
			else{&cpu_main_phase1;}
		}
		elsif($phase==3){
			if($bstep ne ""){@b_fld=split(/-/,$bstep);&battle_run2;}
			elsif($cpu[$s_a]!=1){&main_phase;}
			else{&cpu_battle_phase;}
		}
		elsif($phase==4){
			if($cpu[$s_a]!=1){&main_phase;}
			else{&cpu_main_phase2;}
		}
		elsif($phase==5){
			&end_phase;
		}
		else{last;}
	}
	if($l_act ne ""){
		$chudan=$l_act;$l_act="";$chubak=$chudan;
		if(($chain[0] ne "" || !(&trap_check)) && $chubak=~/^([12])-5-(\d+)-(\d+)/){
			$s_kind=5;$fldno=$2;$mstno=$3;
			if($fld[$fldno] ne ""){&put_card_mst2;}
		}
	}
}

&put_screen;
#######################################################################

sub draw_phase{

	&add_msg($pn[$s_a],$srf[$s_a][1]);

	if($hk[10+$s_a] ne ""){&add_msg("null","(드로페이즈 스킵)");$hk[10+$s_a]="";return 0;}

	if(&tehuda_draw(0,1)){return;}

	if($cpu[$s_a]!=1){
		$tmp=$srf[$s_a][8];
		$tmp=~s/≠/$c_name[$tehuda[$s_a][$#{$tehuda[$s_a]}]]/;
		&add_msg($pn[$s_a],"!$u_side($tmp)");
	}
	$draw_seiko=$tehuda[$s_a][$#{$tehuda[$s_a]}];
	0;
}

sub stanby_phase{
	$chudan="$s_a-0-$draw_seiko";
	if($cont_flg!=1 && &trap_check(1)){return;}

	for($i=$fw1[$s_a];$i<$fw1[$s_a]+5;$i++){
		if($fld_rf[$i]==1){next;}

		if($fld_koka[$i]=~/kisei/ && $kok[0][8] eq ""){
			$str=$fld_koka[$i];
			while($str=~s/(\d+)_kisei//){
				$l_side=&which_side($1,1);
				$tmp=int($ap_fld[$i]/2);
				&add_msg("null","정신 기생체는$c_name[$fld[$i]]으로부터$tmp라이프를 뺏었다");
				if($l_side==0){&lp_up($tmp);}
				else{&lp_up($tmp,1,1);}
			}
		}
		if($fld_koka[$i]=~/jukon/ && $kok[0][8] eq "" && !(&fisher($i))){
			$tmp=&juhuku_cou($fld_koka[$i],"jukon") *500;
			&add_msg("null","주혼의 가면의 저주로 $pn[$s_a]에$tmp의 데미지");
			$lp[$s_a]-=$tmp;&chk_lp;
		}
		if($fld[$i]==1006){
			$seast="99121";
			$tmp_syorip="<>i-$s_a<>n-m_gorosi<>m-아군 살인의 여자를 제물로 바치겠습니까? <>o-네::아니오<>g-1<>p-$i<>l-1";
			&go_select_syori;
		}
		elsif($fld[$i]==1221){&add_msg("null","<b>전설 데빌은 파워업!</b>");$fld_koka[$i].="ptr:700:0:0<>";}
		elsif($fld[$i]==1220){
			if($fld_koka[$i]=~/f_(\d+)::\d+_(\d+)/ && $turn-$2>5){
				&add_msg("null","<b>바이스가$c_name[$fld[$1]]의 머리를 파괴했다!</b>");&go_boti($1,5);
			}
		}
		elsif(($fld[$i]==1010 && $fld_ad[$i]!=1) || ($fld[$i]==1011 && $fld_ad[$i]==1) || $fld[$i]==1014){
			&add_msg("null","<b>$c_name[$fld[$i]]의 효과발동!</b>");
			if($fld[$i]==1014){&lp_up(800);}
			else{&lp_up(1000);}
		}
		elsif($fld[$i]==374){&add_msg("null","마탄고는 독의 숨을 입었다!<br>$pn[$s_a]에 300의 데미지!");$lp[$s_a]-=300;&chk_lp;}
		elsif($fld[$i]==832){if(&maisu_count(0)<2){&add_msg("null","다크 zebra는 아군이 없어서 공포심있었다!");$fld_ad[$i]=1;$a_m[$i]=2;}}
		elsif($fld[$i]==270 || ($fld[$i]==823 && $fld_koka[$i]=~/used/)){push(@chain2,"$s_a-5-$fld[$i]-$i");}
	}

	for($i=$fw2[$s_a];$i<$fw2[$s_a]+5;$i++){
		if($fld_rf[$i]==1){next;}

		if($cost{$fld[$i]} ne ""){
			$seast="";$jokenst="";
			$tmp_syorip="<>i-$s_a<><>n-cost<>m-$c_name[$fld[$i]]을(를) 지속할까요? (라이프$cost{$fld[$i]}가 필요)<>o-네::아니오<>g-1<>p-$i";
			&go_select_syori;
		}
		elsif($fld[$i]==850){
			&add_msg("null","($pn[$s_a]는 평화의 사자에 100라이프를 지불)");
			$lp[$s_a]-=100;&chk_lp;
		}
		elsif($fld[$i]==1091){
			$rann=rand;$rann=int($rann*6)+1;
			&add_msg("null","<b>무차별 파괴 발동!</b><br>주사위는......<b>$rann―</b>");
			for($j=5;$j<15;$j++){
				if($fld[$j] eq "" || $fld_rf[$j]==1){next;}
				$tmp=&lv_st($fld[$j],$j);
				if(($rann<6 && $tmp==$rann) || ($rann==6 && $tmp>5)){
					&add_msg("null","$c_name[$fld[$j]]을(를) 파괴!");&go_boti($j);
				}
			}
		}
		elsif($fld[$i]==1206 && &maisu_count(7)>0 && $kok[0][7] eq ""){
			&add_msg("null","$pn[$s_a]은(는) 상대 패로부터 1장 선택했다.");
			push(@chain2,"$s_a-5-1206");
		}
		if($fld_koka[$i]=~/muryo/ && $kok[0][8] eq ""){
			$tmp=&juhuku_cou($fld_koka[$i],"muryo") *500;
			&add_msg("null","마력 무력화의 가면의 저주로 $pn[$s_a]에$tmp의 데미지. ");
			$lp[$s_a]-=$tmp;&chk_lp;
		}
	}

	for($i=$fw2[$s_d];$i<$fw2[$s_d]+5;$i++){
		if($fld[$i]==704 && $kok[0][8] eq ""){
			$fld_koka[$i]=~/f_(\d+)/;$aite=$1;
			if($fld_koka[$aite]!~/sfia/ || &fisher($aite)){next;}
			if($player[$s_d]==14){&add_msg("밴디트 키스","<b>타임업이다!</b>");}
			&add_msg("null","<b>스피아 폭탄은$c_name[$fld[$aite]]와도 폭발!</b><br>$pn[$s_a]에$ap_fld[$aite]의 데미지!");
			$lp[$s_a]-=$ap_fld[$aite];&chk_lp;&go_boti($aite,5,"",1);
			next;
		}
	}

	for($i=0;$i<$#{$boti[$s_a]}+1;$i++){
		if($boti[$s_a][$i] eq "735"){
			$seast="";$jokenst="";
			$tmp_syorip="<>i-$s_a<><>n-kilasne<>m-킬러뱀을 패에 되돌릴까요?<>o-예::아니오<>g-1";
			&go_select_syori;
		}
		elsif($boti[$s_a][$i] eq "1019"){
			&add_msg("null","<b>타 천사 메리의 효과 발동!</b>");
			&lp_up(200);
		}
		elsif($hk[5+$s_a]>0 && $boti[$s_a][$i]==975 && !(&ext_chk)){
			&add_msg("null","<b>리바이벌 슬라임이 필드에 재생!</b>");
			if(&akichk()){next;}
			$hk[5+$s_a]--;$fld[$nf0]=975;$boti[$s_a][$i]="";
			&ext_set($nf0);$fld_ad[$nf0]=1;&hosatu;
		}
	}
	$hk[5+$s_a]="";
	if($kok[$s_a][28] ne "" && !(&ext_chk("slim"))){
		&fld_chk();
		if($nf0<0){&add_msg("null","(필드에 빈곳이 없어 슬라임을 낳을수 없다)");}
		else{
			&add_msg("null","<b>슬라임 증식로 발동!</b><br>필드에 한체의 슬라임을 낳았다");
			$fld[$nf0]=1093;&ext_set($nf0);
		}
	}

	&del_null(*boti,$s_a);
	if($kok[$s_d][15] ne ""){
		&lp_up(1000,$kok[$s_d][15]);
	}
	if($kok[$s_d][47] ne ""){
		for($i=0;$i<$#{$tehuda[$s_a]}+1;$i++){if($c_zokusei[$tehuda[$s_a][$i]] eq "마"){last;}}
		if($i<$#{$tehuda[$s_a]}+1){&lp_up(1000,$kok[$s_d][47]);}
	}
	if($kok[$s_d][22] ne ""){
		$tmp=$kok[$s_d][22] * 500;$lp[$s_a]-=$tmp;
		&add_msg("null","<b>말단 벼슬아치가$tmp의 라이프를 징수했다!</b>");
		&chk_lp;
	}
	if($kok[0][37] ne ""){
		$tmp=$kok[0][37] * 500;$lp[$s_a]-=$tmp;
		&add_msg("null","<b>타오르는 대지에 의해$tmp의 데미지!</b>");
		&chk_lp;
	}
	for($i=0;$i<$kok[$s_d][33];$i++){push(@chain2,"$s_d-5-1065");}

	if($husatu ne ""){
		@tmp=split(/<>/,$husatu);$husatu="";
		for($i=0;$i<$#tmp+1;$i++){
			($tsno,$cardno,$turnn)=split(/-/,$tmp[$i]);
			if($tsno==$s_a && $turn - $turnn >= 6){
				&add_msg("null","(빛의 봉살검 효과가 없어진다)");
				push(@{$tehuda[$tsno]},$cardno);
			}
			else{$husatu.=$tmp[$i]."<>";}
		}
	}

	if($worm ne ""){
		@tmp=split(/<>/,$worm);$worm="";undef(@jiban2);
		for($i=0;$i<$#tmp+1;$i++){
			@tmp2=split("-",$tmp[$i]);
			if(&which_side($tmp2[0],1)==0){
				&add_msg("null","(몬스터는 웜 홀로 부터 돌아온다)");
				$fld[$tmp2[0]]=$tmp2[1];$fld_rf[$tmp2[0]]=$tmp2[2];$fld_ad[$tmp2[0]]=$tmp2[3];
				if($tmp2[4] ne ""){$fld_koka[$tmp2[0]].="moto_$tmp2[4]<>";}
				if($tmp2[5] ne ""){$fld_koka[$tmp2[0]].="teni_$tmp2[5]<>";}
				if($tmp2[6] ne ""){$fld_koka[$tmp2[0]].="irr<>";}
				if($c_syokan[$tmp2[1]]==6 && $fld_rf[$tmp2[0]]!=1){$fld_koka[$tmp2[0]].="kotei<>";}
			}
			else{$worm.=$tmp[$i]."<>";push(@jiban2,$tmp2[0]);}
		}
		&get_apdp_fld;
	}

	for($i=0;$i<$hk[27+$s_a];$i++){push(@syori,"2<>i-$s_a<>n-hukkatu<>o-공격 표시::수비 표시<>g-1<>m-뱀파이어 로드의 표시 형식은?<>p-1223");}
	$hk[27+$s_a]="";

	$phase=2;
}

sub juhuku_cou{
	local($str)=$_[0];
	local($str2)=$_[1];
	$str0=$str;$str0=~s/$str2//g;
	$tmp = (length($str) - length($str0)) / length($str2);
}

sub main_phase{

	if($F{'putcard'} ne ""){
		@putm=grep(/^putm_/,keys(%F));
		if($#putm<0 && $F{'putcardno'} eq ""){&add_msg("null","!$u_side(내는 카드 지정)");}
		else{
			for($i=0;$i<$#putm+1;$i++){$putm[$i]=~s/^putm_//;}
			&put_card;
		}
		$F{'putcard'}="";
	}
	elsif($F{'usecard'} ne ""){
		if($F{'use'} eq ""){&add_msg("null","!$u_side(사용하는 카드 지정)");}
		else{&use_card;}
		$F{'usecard'}="";
	}
	elsif($F{'change'} ne ""){
		@chg = grep(/^chg_/,keys(%F));
		for($i=0;$i<$#chg+1;$i++){$chg[$i]=~s/^chg_//;}
		&change_mode;
		$F{'change'}="";
	}
	elsif($F{'battle'} ne "" && $phase!=4){
		if(($b_fld[0]=$F{'attack_from'}) eq ""){&add_msg("null","!$s_a몬스터가 지정되어 있지 않아");}
		elsif(($b_fld[1]=$F{'attack_to'}) eq ""){&add_msg("null","!$s_a대상이 지정되어 있지 않아");}
		else{&battle_run;}
		$F{'battle'}="";
	}
	else{$run_phase=100;}
}

sub end_phase{
	local($i);
	$chudan="$s_a-11-";
	if($cont_flg!=1 && &trap_check(1)){return;}

	&add_msg($pn[$s_a],$srf[$s_a][5]);

	for($i=0;$i<5*4;$i++){
		if($fld[$i] eq ""){next;}
		$cardno = $fld[$i];

		if(($cardno==125 || $cardno==930) && $fld_rf[$i]!=1){
			if($cardno==125){$tmp=5;}else{$tmp=3;}
			$fld_koka[$i]=~/turn_(\d+)<>/;
			if($turn - $1 >= $tmp){
				&add_msg("null","($c_name[$cardno]의 효과가 없어진다)");
				&go_boti($i);
			}
		}
		elsif($cardno==742 && $fld_koka[$i]=~s/hakai<>//){
			if(&akichk()){}
			else{
				&add_msg("유충","키");
				&add_msg("null","인섹트 퀸은 유충을 낳았다! ");
				$fld[$nf0]=1158;&ext_set($nf0);
			}
		}
		elsif($c_syokan[$cardno]==6 && $fld_rf[$i]!=1 && $fld_koka[$i]!~/kotei/ && 5<=$i && $i<15){
			if($kok[0][49] ne ""){$fld_koka[$i].="kotei<>";}
			else{
				&add_msg("null","$c_name[$cardno]은(는) 현세에 머물지 못하고 패로 돌아왔다. ");
				$tmps=&which_side($i);&return_tehuda($i);
				for($j=0;$j<$kok[$sno[$tmps]][64];$j++){$tmp2=3-$sno[$tmps];&add_msg("null","<b>스피릿의 권유!</b>");push(@chain2,"$tmp2-5-1207");}
			}
		}
		elsif($cardno==1194 && $fld_rf[$i]!=1 && $fw2[$s_a]<=$i && $i<$fw2[$s_a]+5){push(@chain2,"$s_a-5-1194-$i");}
		elsif($cardno==374 && &which_side($i,1)==0 && $which_area==1 && $fld_rf[$i]!=1){push(@chain2,"$s_a-5-374-$i");}


		if($kok[0][67] ne "" && &lv_st($fld[$i],1)<4 && $a_m[$i]==1 && $fld_rf[$i]!=1 && $fld_koka[$i]!~/ext<>/){&add_msg("null","<b>$c_name[$fld[$i]]은(는) 개미귀신에게 질질 끌어 들여졌다!</b>");&go_boti($i);next;}

		if($fld_koka[$i] eq ""){next;}
		if($fld_koka[$i]=~/genso/){
			&add_msg("null","<b>$c_name[$fld[$i]]은 환상이 되었다.</b>");
			&go_boti($i);next;
		}
		if($fld_koka[$i]=~/limit/ || $fld_koka[$i]=~/karate/){
			&add_msg("null","<b>$c_name[$fld[$i]]자폭!</b>");
			&go_boti($i);next;
		}

		if($fld_koka[$i]=~/(\d+)_dust(\d+)/ && $turn-$2>1 && $kok[0][8] eq "" && $fw1[$s_a]<=$i && $i<$fw1[$s_a]+5 && !(&fisher($i))){
			&return_tehuda($1);
			&add_msg("null","$c_name[$fld[$i]]은(는) 역병의 전에 힘이 다한...<br>블랙 더스트는 패로 돌아온다!");
			&go_boti($i,5,"",1);next;
		}
		if($fld_koka[$i]=~s/kokoro//){&ctrl_back($i,0);}
		if($fld_koka[$i]=~s/minom_$s_a//){&ctrl_back($i,0);}
		if($fld[$i]==1171 || $fld[$i]==1212){$fld_koka[$i]=~s/used//;}
		if($fld_koka[$i]=~/hakaarasi/){&add_msg("null","(훔친$c_name[$fld[$i]]는 묘지로 돌아왔다)");&go_boti($i);}
	}

	for($i=0;$i<$kok[$s_d][32];$i++){push(@chain2,"$s_d-5-1048");}
	for($tsno=1;$tsno<3;$tsno++){
		for($i=0;$i<$hk[8+$tsno];$i++){push(@chain2,"$tsno-5-1064");}
		if($jok[2+$tsno]!=2){for($i=0;$i<$hk[21+$tsno];$i++){push(@syori,"2<>i-$tsno<>n-hukkatu<>o-공격 표시::수비 표시<>g-1<>m-달러 드라의 표시 형식은? <>p-1174");}}
		for($i=0;$i<$#{$tep[$tsno]}+1;$i++){
			if($tep[$tsno][$i] eq "h" && $tehuda[$tsno][$i] ne ""){&add_msg("null","(훔친$c_name[$tehuda[$tsno][$i]]는 묘지로 돌아왔다)");&go_boti2($i,&usertoside($tsno));}
		}
		for($i=0;$i<$hk[23+$tsno];$i++){
			$l_side=&usertoside($tsno);
			for($j=0;$j<$jok[4+$tsno];$j++){&add_msg("null","<b>초재생!</b>　$pn[$tsno]은(는) 1장 드로");&tehuda_draw($l_side,1);}
		}
	}

	if($kok[0][30] ne ""){
		for($i=5;$i<5*3;$i++){undef($a_m[$i]);}
		for($i=$fw2[$s_d];$i<$fw2[$s_d]+5;$i++){undef($a_m[$i]);}
		for($i=$fw2[$s_a];$i<$fw2[$s_a]+5;$i++){
			if($a_m[$i]==5){$a_m[$i]=4;}
			else{undef($a_m[$i]);}
		}
	}
	else{undef(@a_m);}
	undef(@a_b);
	undef(%F);
	if($kok[$s_d][23] ne "" && $hk[30] eq ""){push(@chain2,"$s_d-5-4444");}
	if($hk[34] ne ""){
		$cou0=&maisu_count(0);
		$cou1=&maisu_count(1);
		if(($cou0>0 && $cou1>0) || ($cou0==0 && $cou1==0)){$tmp="양쪽 모두";$lp[$s_a]=0;$lp[$s_d]=0;}
		elsif($cou0>0){$tmp=$pn[$s_a];$lp[$s_d]=0;}
		else{$tmp=$pn[$s_d];$lp[$s_a]=0;}
		&add_msg("null","마지막 배틀의 승자는 --<br><b>$tmp―</b>");
		&chk_lp;
	}

	$sup = &maisu_count(6) - $tehuda_max;	#인원수?
	if($sup>0){
		$seast="999900001";$jokenst='';
		$tmp_syorip="<>i-$s_a<>n-t_sute<>g-1<>p-$sup<>m-(카드패가 6장이 되도록 버린다)";
		&go_select_syori;
	}


	$turn2=3-$turn2;
	$turn++;
	$call[1]="";$call[2]="";
	$hk[2]="";$hk[3]="";$hk[4]="";$hk[5]="";$hk[8]="";$hk[9]="";$hk[10]="";$hk[13]="";$hk[14]="";$hk[19]="";$hk[20]="";$hk[21]="";$hk[22]="";$hk[23]="";$hk[24]="";$hk[25]="";
	if($hk[30] ne "" && $turn-$hk[30]>1){&add_msg("null","(대한파의 효력이 없어졌다)");$hk[30]="";}
	undef(@jok);
	undef(@s_sitei);
	&chg_user;

	$phase=0;
	for($i=0;$i<2;$i++){
		$tsno=$sno[$i];
		if($hk[14+$tsno] ne "" && $#{$tehuda[$tsno]}>-1){
			$maisu=&maisu_count(6+$i);
			&add_msg("null","<b>$pn[$tsno]의 패는 타올랐다!</b>");
			for($j=0;$j<$#{$tehuda[$tsno]}+1;$j++){&go_boti2($j,$i);}
			undef(@{$tehuda[$tsno]});$hk[14+$tsno]="";
			&maryoku(17,$i,$maisu);
		}
	}
	if($hk[16+$s_a] ne ""){
		$hk[13]=999;$hk[16+$s_a]="";
	}
	if($hk[10+$s_a] eq ""){
		if($hk[25+$s_a] ne ""){push(@syori,"2<>i-$s_a<>n-maharagi<>o-아래::위인 채<>m-덱의 맨 위의 것$c_name[$deck[$s_a][0]]을 맨밑으로 되돌릴까요?<>g-1");$hk[25+$s_a]="";}
		for($i=$fw1[$s_a];$i<$fw1[$s_a]+5;$i++){
			if($fld[$i]==1121 && $fld_rf[$i]!=1){push(@syori,"2<>i-$s_a<>n-fleed1<>o-사용::사용안함<>m-후리드의 효과를 사용할까요? <>g-1");}
		}
	}
}

sub end_game{

	if($lp[1]<1 && $lp[2]<1){
		$lp[1]=0;$lp[2]=0;$winer=0;
		&add_msg("null","무승부");
	}
	elsif($lp[1]<1){
		$lp[1]=0;$winer=2;
		&end_msg($player[2],$player[1],2);
	}
	else{
		$lp[2]=0;$winer=1;
		&end_msg($player[1],$player[2],1);
	}

	if($match ne ""){
		if($match eq "on"){$match="";}
		$match.=$winer;

		if($match eq "11"){$winer=1;}
		elsif($match eq "22"){$winer=2;}
		elsif(length($match)==3){
			undef(@c);
			for($i=0;$i<3;$i++){$c[substr($match,$i,1)]++;}
			if($c[1]==2){$winer=1;}
			elsif($c[2]==2){$winer=2;}
			elsif($c[1]==1 && $c[0]==2){$winer=1;}
			elsif($c[2]==1 && $c[0]==2){$winer=1;}
			else{$winer=0;}
		}
		else{$winer="";}
	}

	&chg_user;
	if($match eq "" || $winer ne ""){
		if($room ne ""){
			&put_shohai($side[1],1);
			&put_shohai($side[2],2);
		}
		else{&put_shohai($id,1);}
		$syori[0]=3;
	}
	else{$syori[0]=5;}

	&put_screen;
}

sub put_shohai{
	local($id)=$_[0];
	local($tsno)=$_[1];

	open(PFL,"tmp/".$id."_pfl");
	undef(%P);
	while(<PFL>){chop;($key,$val)=split(/\t/);$P{$key}=$val;}
	close(PFL);
	$shohai=$P{'shohai'};
	if($room ne "" && $match ne ""){$chno=25;}
	elsif($room ne ""){$chno=13;}
	else{$chno=$player[2];}
	@tmp=split(":",$shohai);
	($win,$lose,$draw)=split(/-/,$tmp[$chno]);

	if($winer==0){$draw++;}
	elsif($winer==$tsno){$win++;}
	else{$lose++;}

	$tmp[$chno]="$win-$lose-$draw",
	$P{'shohai'}=join(":",@tmp);
	if($P{'deck'} eq ""){$P{'deck'}=join(",",@defo);}
	if($room ne ""){$P{'name'}=$pn[$tsno];$P{'seigen'}=$seigen;}

	open(PFL,">tmp/".$id."_pfl");
	foreach $key (keys(%P)){print PFL "$key\t$P{$key}\n";}
	close(PFL);
}

sub end_msg{
	local($win)=$_[0];
	local($lose)=$_[1];
	local($winner)=$_[2];
	$loser=3-$winner;

	if($win==0 && $lose==3){
		&add_msg("조이","역시 유희는 강해!");
		&add_msg("유희","좋은 승부였어, 조이!");
	}
	elsif($win==3 && $lose==0){
		&add_msg("조이","헉, 사실인가..!");
		&add_msg("유희","강해졌구나, 조이!");
	}
	elsif($win==1 && $lose==3){
		&add_msg("유희","이제 재구축 하는 것이 좋을것 같아...공략법을 알아버렸어...");
		&add_msg("조이","무슨 공략법~!");
	}
	elsif($win==2 && $lose==3){
		&add_msg("조이","젠장...졌다!");
		&add_msg("카이바","조이! 너는 암울한 모습이 어울린다!<br>일어서는 것 조차 할수없는 싸움에 진 주제!");
	}
	elsif($win==3 && $lose==1){
		&add_msg("유희","대단해, 조이!");
		&add_msg("조이","하하; 고마워");
	}
	elsif($win==0 && $lose==1){
		&add_msg("유희","내가 진것인가");
		&add_msg("어둠의 유희","후... 아직이다 파트너!");
	}
	elsif($win==1 && $lose==0){
		&add_msg("유희","됬다! 나의 승리야!");
		&add_msg("어둠의 유희","후... 잘하는데 또 하나의 나!");
	}
	elsif($win==0 && $lose==10){
		&add_msg("사마준","악~~ 거짓말이야~~");
		&add_msg("유희","냉큼 가버려! 무뇌충 자식");
	}
	elsif($win==3 && $lose==10){
		&add_msg("조이","너 너무 약하지 않아. 무뇌충 자식!");
		&add_msg("사마준","(뷁!)");
	}
	elsif($win==0 && $lose==12){
		&add_msg("마해룡","윽 대단해-! 역시 거물은-!");
		&add_msg("유희","너도 상당했어!");
	}
	elsif($win==3 && $lose==12){
		&add_msg("마해룡","다음은 내가 이긴다! 조이!");
		&add_msg("조이","오! 나는 좀더 강해져야 겠군!");
	}
	elsif($win==0 && $lose==4){
		&add_msg("유희","메이... 고마워요...");
		&add_msg("메이","유희...<br>나는 이 패배에 의해 강해질 자신이 있어요!");
	}
	elsif($win==1 && $lose==5){
		&add_msg("페가수스","UWOOOO~~~~!");
		&add_msg("유희","페가수스... 나의 승리다...");
	}
	elsif($win==5 && $lose==2){
		&add_msg("카이바","(안녕히다... 유희...)");
		&add_msg("페가수스","벌 게임! 마인드 카드!");
	}
	elsif($win==0 && $lose==8){
		&add_msg("바크라","이번은 나의 패배로 해두겠다!<br>하하하하하하하하하하하");
		&add_msg("유희","(..! )");
	}
	elsif($win==3 && $lose==15){
		&add_msg("사이퍼 로파","...");
		&add_msg("조이","초능력자 사이퍼 로파...<br>미래를 본 것은 나였어. ");
	}
	elsif($win==5 && $lose==14){
		&add_msg("밴디트 키스","오~마이갓~~ 오 마이갓~~!");
		&add_msg("페가수스","WOW!　톰의 승리 Days!");
	}
	elsif($win==3 && $lose==14){
		&add_msg("밴디트 키스","으 아 아!");
		&add_msg("조이","이겼다구 바보야!");
	}
	elsif($win==0 && $lose==17){
		&add_msg("판도라","윽!");
		&add_msg("유희","카드의 신뢰를 배반한 당신의 패배다! 판도라!");
	}
	elsif($win==6 && $lose==17){
		&add_msg("판도라","하...마...마리크...!");
		&add_msg("마리크","판도라...넌 결투에 패배했다...<br>분명하게 벌을 받지않으면...");
	}
	elsif($win==0 && $lose==19){
		&add_msg("조이","어...왜....우리가 싸우고 있지?");
		&add_msg("유희","조이!");
	}
	elsif($win==1 && $lose==19){
		&add_msg("유희","조이... 정말 잘하는데...");
		&add_msg("조이","죽이는데!　유희! ");
	}
	elsif($win==3 && $lose==20){
		&add_msg("리시드","조이... 나는 너와 싸울 수 있던 것을 자랑으로 생각한다...");
		&add_msg("조이","나도 그래! 너는 진정한 결투자였어!");
	}
	elsif($win==21 && $lose==22){
		&add_msg("마리크","절망의 미래밖에 안보이겠지... 누님...");
		&add_msg("이시즈",".......!");
	}
	elsif($win==2 && $lose==22){
		&add_msg("이시즈","인간의 미래는 바꿀수가 있는 것입니까...");
		&add_msg("카이바","미래를 따르는 놈에겐 --빛이없다...");
	}
	elsif($win==21 && $lose==4){
		&add_msg("메이","아 아 아 ...");
		&add_msg("마리크","아하하하하! 고통에 몸을 바쳐라~~");
	}
	elsif($win==2 && $lose==23){
		&add_msg("어둠의 가면","으 아 아 아 아　<FONT SIZE=-1>가...</font>");
		&add_msg("카이바","스스로가 건 함정으로 가는게 좋다! 하하하하하");
	}
	elsif($win==0 && $lose==23){
		&add_msg("빛의 가면","파트너... 무사한가~~");
		&add_msg("유희","죽음의 결투가 질리군!");
	}

	elsif($srf[$loser][7] ne ""){
		&add_msg($pn[$loser],$srf[$loser][7]);
		&add_msg($pn[$winner],$srf[$winner][6]);
	}
}

sub osiris_search{
	$osiris_flg=0;
	$seast = "099910001";
	$jokenst='$c_name[$cardno] eq "오시리스의 천공룡"';
	&card_search;
	if($#res_s>-1){$osiris_flg=1;}
}

sub get_input{

	if (length($ENV{'QUERY_STRING'}) > 0) {
		$INPUT = $ENV{'QUERY_STRING'};
	}
	elsif (length($ENV{'CONTENT_LENGTH'}) > 0) {
		read(STDIN, $INPUT, $ENV{'CONTENT_LENGTH'});
	}
	else {
		while ($TMP[0] = <STDIN>) {
			$INPUT .= $TMP[0];
		}
	}

	$INPUT =~ s/\&+/\&/g;
	$INPUT =~ s/#.+//;
	@TMP = split('&', $INPUT);
	for ($i = 0; $i <= $#TMP; ++$i) {
		($KEY, $VAL) = split('=', $TMP[$i]);
		$VAL =~ tr/+/ /;
		$VAL =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
		$VAL =~ s/\015\012/\012/g;
		$VAL =~ s/\015/\012/g;
		if($VAL ne ""){$F{$KEY}=$VAL;}
	}

	$id = $F{'id'};
	$id=~s/\.//g;$id=~s/\///g;$id=~s/<//g;
	$id=substr($id,0,50);
	if($id=~/^$roomst[0-9]/){print "이 듀얼네임을 사용할수 없습니다. 이름을 변경해 주세요<br>";exit;}

	$room = $F{'room'};
	$room=~s/\.//g;$room=~s/\///g;$room=~s/<//g;
	if($id eq "" && $room eq ""){print "Error";exit;}
}
