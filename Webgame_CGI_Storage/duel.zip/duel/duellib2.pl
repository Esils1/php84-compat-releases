sub hikari_chk{
	local($l_side)=$_[0];
	local($tsno)=$sno[$l_side];
	local($i);

	for($i=$fw1[$tsno];$i<$fw1[$tsno]+5;$i++){if($fld[$i] ne "" && $c_zokusei[$fld[$i]] ne "빛" && $fld_rf[$i]!=1){return 1;}}
	0;
}

sub raiden_ret{
	local($l_side)=$_[0];
	local($tsno)=$sno[$l_side];
	if($kok[$tsno][48] eq ""){return;}

	local($i);
	for($i=$fw1[$tsno];$i<$fw1[$tsno]+5;$i++){
		if($fld[$i]==1169){&add_msg("null","(뇌전딸(아가씨)들은 하늘에 돌아간다)");&go_boti($i);}
	}
}

sub nisewana_chk{
	local($fldno)=$_[0];
	if($nisewana==1 && $c_zokusei[$fld[$fldno]] eq "함정"){
		&add_msg("null","$c_name[$fld[$fldno]]을 지켰다! ");
		return 0;
	}
	1;
}

sub moto_chk{
	local($fldno)=$_[0];
	if($fld_koka[$fldno]!~/moto/){
		$tmp=$sno[&which_side($fldno)];
		$fld_koka[$fldno].="moto_$tmp<>";
	}
}

sub get_ko_no{
	local($koka) = $_[0];
	local($ko_no);
	$tmp=$koka;$tmp=~s/<>//g;
	$ko_no = (length($koka) - length($tmp)) / 2;
	return $ko_no;
}

sub fisher{
	local($res_si)=$_[0];
	if($kok[0][59] ne "" && $res_si<50 && $fld_rf[$res_si]!=1){
		if($fld[$res_si]==918){return 2;}
		elsif($fld[$res_si]==919){return 1;}
	}
	0;
}

sub rand_tehuda{
	local($l_side)=$_[0];
	local($i,$cou,$cou2,$tsno);
	$tsno=$sno[$l_side];

	$cou=&maisu_count(6+$l_side);
	if($cou==0){return -1;}
	$rann=rand;$rann=int($rann*$cou);
	$cou2=0;
	for($i=0;$i<$#{$tehuda[$tsno]}+1;$i++){
		if($tehuda[$tsno][$i] eq ""){next;}
		if($cou2==$rann){last;}
		$cou2++;
	}
	return $i;
}

sub kase_chk{
	if($kok[0][16] ne "" && $lp[$s_a]<=$kok[0][16]*500){
		&add_msg("null","!$s_a(마력의 항쇄에 지불할 라이프가 없다! )");return 1;
	}
}

sub kinsi_chk{
	local($tno)=$_[0];
	$kcno=$tehuda[$s_a][$tno];

	if($kinsi{$kcno} ne ""){&add_msg("null","!$s_a($c_name[$kcno]은(는) 금지되고 있다! )");return 1;}
	0;
}

sub kinsi_chk2{
	local($fno)=$_[0];
	$kcno=$fld[$fno];
	if($kinsi{$kcno} ne "" && $fld_koka[$fno]!~/kinsi/){&add_msg("null","!$s_a($c_name[$kcno]은(는) 금지되고 있다! )");return 1;}
	0;
}


sub chaintosel{
	if($chudan=~s/-o(\d+)$//){$F{'options'}=$1;}
	($use_cno,$use_f_no,@res_st)=split("-",$chudan);
	if($use_cno==873 || $c_syuzoku[$use_cno] eq "영속" || $c_syuzoku[$use_cno] eq "장비" || $c_syuzoku[$use_cno] eq "필드"){if($fld[$use_f_no] eq ""){return 1;}}

	undef(@select);$errflg_any=0;$errflg=0;
	undef(%BAS_CHK);
	for($i=0;$i<$#res_st+1;$i++){
		($t_cno,$basyo,$fldno) = split(/:/,$res_st[$i]);
		if($fldno ne ""){
			if($fld[$fldno] ne $t_cno && $use_cno!=954){$errflg_any=1;next;}
			push(@select,$fldno);
			next;
		}

		&basyo_set($basyo);
		for($j=0;$j<$#tmp_s+1;$j++){
			if($tmp_s[$j]==$t_cno && $BAS_CHK{$basyo."-".$j} eq ""){last;}
		}
		if($j==$#tmp_s+1){$errflg_any=1;next;}
		push(@select,$j+$sup);
		$BAS_CHK{$basyo."-".$j}=1;		#중복
	}
	if($#res_st<0){}
	elsif($#select<0){$errflg=1;}
	elsif($errflg_any==1 && $use_cno!=706 && $use_cno!=281){$errflg=1;}

	if($use_cno==86){$errflg=1;for($i=$fw1[$s_d];$i<$fw1[$s_d]+5;$i++){if($fld[$i] ne ""){$errflg="";last;}}}	#갈라진 대지

	if($errflg==1){&add_msg("null","($c_name[$use_cno]은 대상이 사라졌기 때문에 무효)");&end_usecard(1);return 1;}
	0;
}

sub niheya_chk{
	for($i=1;$i<$heyakazu+1;$i++){
		if($i==$room){next;}
		undef(%N);
		open(IN,"tmp/".$roomst.$i);
		while(<IN>){chop;($key,$val)=split(/\t/);$N{$key}=$val;}
		if($N{'syori'}=~/^3/){next;}
		if($N{'side1'} eq $id || $N{'side2'} eq $id){print "방 번호$i를 먼저 끝내 줘. ";exit;}
	}
}

sub maisu_count{
	local($mode)=$_[0];
	local($i,$cou);
	$cou=0;
	if($mode==0){for($i=$fw1[$s_a];$i<$fw1[$s_a]+5;$i++){if($fld[$i] ne ""){$cou++;}}}
	elsif($mode==1){for($i=$fw1[$s_d];$i<$fw1[$s_d]+5;$i++){if($fld[$i] ne ""){$cou++;}}}
	elsif($mode==2){for($i=$fw2[$s_a];$i<$fw2[$s_a]+5;$i++){if($fld[$i] ne ""){$cou++;}}if($fld[$fside[$s_a]] ne ""){$cou++;}}
	elsif($mode==3){for($i=$fw2[$s_d];$i<$fw2[$s_d]+5;$i++){if($fld[$i] ne ""){$cou++;}}if($fld[$fside[$s_d]] ne ""){$cou++;}}
	elsif($mode==4){for($i=$fw1[$s_a];$i<$fw1[$s_a]+5;$i++){if($fld[$i] ne "" && $fld_rf[$i]!=1){$cou++;}}}
	elsif($mode==5){for($i=$fw1[$s_d];$i<$fw1[$s_d]+5;$i++){if($fld[$i] ne "" && $fld_rf[$i]!=1){$cou++;}}}
	elsif($mode==6){for($i=0;$i<$#{$tehuda[$s_a]}+1;$i++){if($tehuda[$s_a][$i] ne ""){$cou++;}}}
	elsif($mode==7){for($i=0;$i<$#{$tehuda[$s_d]}+1;$i++){if($tehuda[$s_d][$i] ne ""){$cou++;}}}
	elsif($mode==8){for($i=$fw1[$s_a];$i<$fw1[$s_a]+5;$i++){if($fld[$i] eq "" && $jiban[$i] eq ""){$cou++;}}}
	elsif($mode==9){for($i=$fw1[$s_d];$i<$fw1[$s_d]+5;$i++){if($fld[$i] eq "" && $jiban[$i] eq ""){$cou++;}}}
	return $cou;
}

sub ext_chk{
	local($mode)=$_[0];
	local($msg_on)=$_[1];
	local($cardno)=$_[2];
	local($l_side)=$_[3];
	local($tsno);
	$tsno=$sno[$l_side];

	if($msg_on!=1){$msg_on="!$tsno";}
	else{$msg_on="";}

	if($mode eq "" || $mode eq "slim" || $mode eq "t"){
		if($kok[$tsno][28]>1 || ($kok[$tsno][28] ne "" && $mode ne "slim")){&add_msg("null","$msg_on(슬라임 증식로가 있는 한 소환·특수 소환할 수 없다)");return 1;}
		if($jok[2+$tsno]==2){&add_msg("null","$msg_on($pn[$tsno]은 이 턴 소환·특수 소환할 수 없다)");return 1;}
		if($kok[0][43] ne "" && $mode ne "t"){&add_msg("null","$msg_on(죠우겐이 장소에 있는 한 특수 소환할 수 없다)");return 1;}
		if($kok[0][71] ne ""){&add_msg("null","$msg_on(최종전사는 최종이며, 다른 몬스터는 소환할 수 없다)");return 1;}

		if($cardno ne ""){
			if($c_syokan[$cardno]==4 && $kok[$tsno][4] eq ""){&add_msg("null","$msg_on(툰 월드가 없기 때문에 ,$c_name[$cardno]는 특수 소환할 수 없다)");return 1;}
			if($c_syokan[$cardno]==6){&add_msg("null","$msg_on(스피릿은 특수 소환할 수 없다)");return 1;}
			if($cardno==1169 && &hikari_chk($l_side)){&add_msg("null","$msg_on(장소에 빛속성 이외의 몬스터가 있다)");return 1;}
		}
	}
	elsif($mode eq "s"){
		if($call[$tsno]==1 || $jok[2+$tsno] ne ""){&add_msg("null","$msg_on(이미 소환·특수 소환을 실시하고 있다)");return 1;}
	}
	0;
}

sub akichk2{
	local($l_side)=$_[0];

	&fld_chk($l_side);
	if($nf1<0){
		&add_msg("null","!$sno[$l_side](필드에 빈 곳이 없다)");
		return 1;
	}
	0;
}

sub akichk{
	local($l_side)=$_[0];

	&fld_chk($l_side);
	if($nf0<0){
		&add_msg("null","!$sno[$l_side](필드에 빈 곳이 없다)");
		return 1;
	}
	0;
}

sub fld_chk{
	local($l_side)=$_[0];
	local($tsno)=$sno[$l_side];
	local($i);

	$nf0=-1;$nf1=-1;

	for($i=$fw1[$tsno];$i<$fw1[$tsno]+5;$i++){
		if($fld[$i] eq "" && $jiban[$i] eq ""){$nf0=$i;last;}
	}
	if($rule==1){$ftmp=1;}else{$ftmp=5;}
	for($i=$fw2[$tsno];$i<$fw2[$tsno]+$ftmp;$i++){
		if($fld[$i] eq ""){$nf1=$i;last;}
	}
}

sub control_chk{
	$not_control="";
	if($read_only==1 || ($room ne "" && $side[1] eq "") || $syori[0] eq "5".$u_side){$not_control=1;$run_phase=100;return;}
	elsif($cpu[1]==1 || $cpu[2]==1){return;}

	&syori_p_set;

	if($S{'i'} ne ""){$l_side=$S{'i'};}
	elsif($chain[0]=~/^([12])-/){
		if($c_end==2){$l_side=$1;}
		else{$l_side=3-$1;}
	}
	else{$l_side=$turn2;}
	if($l_side ne $u_side){$not_control=1;$run_phase=100;}
}

sub syori_p_set{
	undef(%S);
	local($i,@tmp);
	if($syori[0] eq ""){return;}

	@tmp=split(/<>/,$syori[0]);
	for($i=0;$i<$#tmp+1;$i++){
		if($tmp[$i]=~/(.)-(.+)/){$S{$1}=$2;}
	}
}

sub read_carddata{
	$cou=-1;
	open(DATA,"card.txt");
	$lin=<DATA>;
	while(<DATA>){
		$cou++;
		chop;
		@tmp=split(/\t/);
		$c_name[$cou]=$tmp[0];
		$c_zokusei[$cou]=$tmp[1];
		$c_syuzoku[$cou]=$tmp[2];
		$c_ap[$cou]=$tmp[3];
		$c_dp[$cou]=$tmp[4];
		$c_lv[$cou]=$tmp[5];
		$c_koka[$cou]=$tmp[6];
		$c_syokan[$cou]=$tmp[7];
	}
	$card_su = $cou;
	close(DATA);
}

sub getf_res{		#res_s번호로부터cardno를 돌려준다
	local($a)=$_[0];

	if($a<50){return($fld[$a]);}
	elsif(50<=$a && $a<100){$basyo=8;return($tehuda[$s_a][$a-50]);}
	elsif(100<=$a && $a<150){$basyo=9;return($tehuda[$s_d][$a-100]);}
	elsif(200<=$a && $a<300){$basyo=10;return($boti[$s_a][$a-200]);}
	elsif(300<=$a && $a<400){$basyo=11;return($boti[$s_d][$a-300]);}
	elsif(400<=$a && $a<500){$basyo=12;return($deck[$s_a][$a-400]);}
	elsif(500<=$a && $a<600){$basyo=13;return($deck[$s_d][$a-500]);}
	elsif(600<=$a && $a<700){$basyo=14;return($yugo[$s_a][$a-600]);}
	elsif(700<=$a){$basyo=15;return($yugo[$s_d][$a-700]);}
	else{return(999);}
}

sub ap_cre_res{
	if($a<50){$tmpa=$ap_fld[$a];}
	else{$tmpa=$c_ap[&getf_res($a)];}
	if($b<50){$tmpb=$ap_fld[$b];}
	else{$tmpb=$c_ap[&getf_res($b)];}

	if($tmpa=~/^X/){$tmpa=4000;}
	if($tmpb=~/^X/){$tmpb=4000;}

	$tmpb <=> $tmpa;
}

sub ap_cre_tehuda{
	local($tmpa,$tmpb);
	$tmpa = $c_ap[$tehuda[$s_a][$a]];
	$tmpb = $c_ap[$tehuda[$s_a][$b]];
	if($tmpa eq "X000"){$tmpa=($#{$tehuda[$s_a]}+1)*1000;}
	if($tmpb eq "X000"){$tmpb=($#{$tehuda[$s_a]}+1)*1000;}
	$tmpb <=> $tmpa;
}

sub dp_cre_fld{
	local($tmpa,$tmpb);
	$tmpa = $dp_fld[$a];
	$tmpb = $dp_fld[$b];
	$tmpb <=> $tmpa;
}

sub del_null{
	local(*arr) = @_;
	local($ind)=$_[1];
	local($i);
	undef(@arr_stack);

	for($i=0;$i<$#{$arr[$ind]}+1;$i++){
		if($arr[$ind][$i] ne ""){push(@arr_stack,$arr[$ind][$i]);}
	}
	@{$arr[$ind]}=@arr_stack;
}

sub del_nullt{
	local($ind)=$_[0];
	local($i);
	undef(@arr_stack);undef(@arrp_stack);

	for($i=0;$i<$#{$tehuda[$ind]}+1;$i++){
		if($tehuda[$ind][$i] ne ""){
			push(@arr_stack,$tehuda[$ind][$i]);
			push(@arrp_stack,$tep[$ind][$i]);
		}
	}
	@{$tehuda[$ind]}=@arr_stack;
	@{$tep[$ind]}=@arrp_stack;
}

sub shuffle{
	local(*arr) = @_;
	local($ind)=$_[1];
	local($i,$j,$cou);

	srand;undef(@arr_stack);undef(@arr_nokori);
	$maisu=$#{$arr[$ind]};
	$nokori=$maisu;
	for($i=0;$i<$maisu+1;$i++){
		$rann=rand;
		$rann=int($rann * ($nokori+1));
		$cou=0;
		for($j=0;$j<$nokori+1;$j++){
			if($j==$rann){$arr_stack[$ind][$i]=$arr[$ind][$j];}
			else{$arr_nokori[$ind][$cou]=$arr[$ind][$j];$cou++;}
		}
		$arr[$ind]=$arr_nokori[$ind];
		$nokori--;
	}
	$arr[$ind]=$arr_stack[$ind];
}

sub chg_user{
	&syori_p_set;

	if($s_sitei[0] ne ""){$s_a=$s_sitei[0];}
	elsif($S{'i'} ne ""){$s_a=$S{'i'};}
	elsif($chain[0]=~/^([12])-/){
		if($c_end==2){$s_a=$1;}
		else{$s_a=3-$1;}
	}
	elsif($chain2[0]=~/^([12])-/){$s_a=$1;}
	else{$s_a=$turn2;}
	$s_d=3-$s_a;@sno=($s_a,$s_d);

	&find_koka;
}

sub chk_lp{		#승패 확인
	if($lp[$s_d]<1 || $lp[$s_a]<1){
		&end_game;
	}
}

sub keisiki_chk{
	local($cardno)=$_[0];
	if($max_pt<$c_ap[$cardno]){return 0;}
	if($max_ap>$c_ap[$cardno]){return 1;}
	if($c_ap[$cardno]>$c_dp[$cardno]){return 0;}
	1;
}

sub pt_chk{
	local($j);

	$max_ap=0;$max_dp=0;$max_pt=0;
	for($j=$fw1[$s_d];$j<$fw1[$s_d]+5;$j++){
		if($fld[$j] eq ""){next;}

		if($fld_rf[$j]==1 && $player[$s_a]!=5){next;}
		if($ap_fld[$j]>$max_ap && $fld_ad[$j]!=1){$max_ap=$ap_fld[$j];}
		if($dp_fld[$j]>$max_dp && $fld_ad[$j]==1){$max_dp=$dp_fld[$j];}
		if($ap_fld[$j]>$max_pt && $fld_ad[$j]!=1){$max_pt=$ap_fld[$j];}
		if($dp_fld[$j]>$max_pt && $fld_ad[$j]==1){$max_pt=$dp_fld[$j];}
	}
}

sub status_chk{
	local($i);

	$battle_chk=0;		#배틀 가능
	$direct_chk=0;		#직접 공격 가능
	if($turn==1){}
	elsif(!($phase==2 || $phase==3)){}
	else{
		for($i=$fw1[$s_a];$i<$fw1[$s_a]+5;$i++){
			if($fld[$i] ne "" && $a_b[$i]!=1 && ($fld_ad[$i]==0 || ($fld[$i]==718 && $fld_rf[$i]!=1))){
				$battle_chk=1;
				if($c_syokan[$fld[$i]]==4 || $c_koka[$fld[$i]]==13){$direct_chk=1;}
			}
		}

		if($battle_chk==1){
			$cou=0;$cou1=0;
			for($i=$fw1[$s_d];$i<$fw1[$s_d]+5;$i++){
				if(&fisher($i)==2){$cou1++;}
				elsif($fld[$i] ne ""){$cou++;}
			}
			if($cou==0){$direct_chk=1;}
			if($cou+$cou1+$direct_chk<2){$attack_onlystr=" checked";}
		}
	}
}

sub make_msg{
	while($#msg+1>$msgcou){pop(@msg);pop(@msgman);}
	if($room ne ""){
		undef(@msgman_new);undef(@msg_new);
		open(LOG,"tmp/".$roomst.$room."_log");
		for($i=0;$i<$logcou;$i++){$_=<LOG>;}
		while(<LOG>){
			chop;
			($tmp1,$tmp2)=split(/\t/,$_);
			push(@msgman_new,$tmp1);
			push(@msg_new,$tmp2);
			$i++;
		}
		close(LOG);$logcou=$i;

		if($msgcou>0){
			open(LOG,">>tmp/".$roomst.$room."_log");
			for($i=0;$i<$msgcou;$i++){
				print LOG "$msgman[$i]\t$msg[$i]\n";
				push(@msgman_new,$msgman[$i]);
				push(@msg_new,$msg[$i]);
			}
			close(LOG);
			$logcou+=$msgcou;
		}
		@msgman=@msgman_new;@msg=@msg_new;
	}

	for($i=0;$i<$#msg+1+1;$i++){
		if(substr($msg[$i],0,1) eq "!"){
			if(substr($msg[$i],1,1) ne $u_side || $read_only==1){next;}
			$msg[$i]=substr($msg[$i],2);
		}

		if($man_p ne $msgman[$i]){
			#닫는다
			if($man_p ne "null" && $man_p ne ""){
				$pstr =~ s/<br>$//;
				$pstr =~ s/. $//;
				$pstr.="」</td></tr>\n";
				if($msgman[$i] eq "null" || $msgman[$i] eq ""){$pstr.="</table>\n";}
			}

			#여는
			if($msgman[$i] ne "null" && $msgman[$i] ne ""){
				if($man_p eq "null" || $man_p eq ""){$pstr.="<table cellpadding=0 cellspacing=0>";}
				$pstr.="<tr valign=top><td>$msgman[$i]</td><td align=right>「</td><td>";
			}
		}
		if($msg[$i] ne ""){$pstr .= "$msg[$i]<br>";}
		$man_p=$msgman[$i];
	}

	if($syori[0]=~/^[35]/){return;}
	if($S{'m'} ne "" && $not_control!=1){$pstr.="$S{'m'}<br>";}
	elsif($syori[0]=~/^2/ && $not_control!=1){$pstr.="(대상을 선택하라)<br>";}
}

sub add_msg{
	$msgman[$msgcou]=$_[0];
	$msg[$msgcou]=$_[1];
	$msgcou++;
}

sub put_screen{
	&del_nullt($s_a);
	&del_nullt($s_d);

	$deckno[1]=$#{$deck[1]}+1;
	$deckno[2]=$#{$deck[2]}+1;

	@phasestr=("드로페이즈","스텐바이페이즈","메인페이즈 1","배틀페이즈","메인페이즈 2","엔드페이즈");
	$phasest=$pn[$turn2].$phasestr[$phase];

	if($match ne "" && $match ne "on"){
		$l=length($match);
		for($i=0;$i<$l;$i++){
			$i2=$i+1;
			$matchst.="$i2:";
			$tmp=substr($match,$i,1);
			if($tmp==0){$matchst.="무승부";}
			else{$matchst.=$pn[$tmp];}
			$matchst.="<br>\n";
		}
	}
	if($match ne ""){
		$matchst="【매치】<br>$matchst<br>\n";
	}

	if($read_only==1){&get_apdp_fld;&get_fld_mess;&make_msg;&put_screen2;}

	&chg_user;
	$t_v_flg="";
	while($syori[0] ne ""){
		&syori_p_set;
		$seast=$S{'s'};$jokenst=$S{'j'};
		if($S{'l'} ne ""){last;}
		if($seast ne ""){
			if(substr($seast,9,1)==1){
				if($u_side==$S{'i'}){$t_v_flg=1;}
				else{last;}
			}
			&card_search;
			if($#res_s<0){&del_syori;}
			else{last;}
		}
		else{last;}
	}
	&chg_user;&control_chk;
	if($room eq "" && $turn2==2 && $chain[0] eq "" && $S{'i'}!=1){$cpu_control=1;}

	&get_apdp_fld;
	&get_fld_mess;

	&syori_p_set;

	&make_msg;
	if($syori[0]=~/^5/ && $syori[0] ne "5".$u_side){$act="side.cgi";}
	elsif($syori[0]=~/^3/){$act="index.cgi";}
	else{$act="duel.cgi";}

	if($#{$yugo[$u_side]}>-1){$yugost="<br><br><a href=\"view.cgi?room=$room&id=$id&area=yugo$u_side\" target=yugo>융합 덱</a><br>\n";}
	if($husatu ne ""){$husatust="<br><br><a href=\"view.cgi?room=$room&id=$id&area=husatu\" target=yugo>빛의 봉살검</a><br>\n";}
	if($kok[0][69] ne ""){$tenpenst="<br><br><a href=\"view.cgi?room=$room&id=$id&area=tenpen\" target=yugo>천변지이</a><br>\n";}


	$waitst="<b>상대에게로의 체인</b>　<a href=\"$help#chain\" target=new>설명</a><br>";
	for($i=0;$i<$#waitko+1;$i++){
		if($i==4 || $i==6 || $i==7){next;}
		$waitst.="<input type=checkbox name=\"wait_$i\"";
		if($wait[$u_side][$i] ne ""){$waitst.=" checked";}
		$waitst.=">$waitko[$i]/";
	}

	$waitstj="<b>자신에게로의 체인</b><br>";
	for($i=0;$i<$#waitko+1;$i++){
		if($i==4 || $i==6 || $i==7){next;}
		$waitstj.="<input type=checkbox name=\"waitj_$i\"";
		if($waitj[$u_side][$i] ne ""){$waitstj.=" checked";}
		$waitstj.=">$waitko[$i]/";
	}

	$waitst2=join(",",@{$wait[$u_side]});
	$waitstj2=join(",",@{$waitj[$u_side]});

	if($cpu[$u_side]!=1){&status_chk;}

	if($room ne ""){
		$hidst="<input type=hidden name=\"room\" value=\"$room\">";
		$dat1=&make_date($date);
		if($side[$u_side2] ne ""){$dat2=&make_date($t_date[$u_side2]);}
		$updatest="<FONT SIZE=-1>【최종 액세스】<br>$pn[$u_side]：$dat1<br>$pn[$u_side2]：$dat2<br></font>";
	}

	$chainst="";
	for($i=0;$i<$#chain+1;$i++){
		@tmp = split(/-/,$chain[$i]);
		&make_chainst;
	}
	if($chainst ne ""){$chainst="<b>【체인 블록】</b><br>$chainst";}
	if($#chain<0 && $#chain2<0){$c_end="";}

	for($i=0;$i<$#chain2+1;$i++){
		if($chain2[$i]=~/^[12]-6/){next;}
		$i2=$i+1;
		$chainst.="<br>\n<b>【체인 블록$i2】</b><br>";
		@tmp = split(/-/,$chain2[$i]);
		$chainst.="＜$pn[$tmp[0]]＞：효과：$c_name[$tmp[2]]<br><br>\n";
	}
	$chudan=$chain[0];&chain_para_chk;

	&put_screen2;
}

sub make_chainst{
	$chainst.="＜$pn[$tmp[0]]＞$waitko[$tmp[1]]：";
	if($tmp[1]==3){
		if($tmp[2] eq "null" || $fld[$tmp[2]] eq "" || ($tmp[3] ne "player" && $fld[$tmp[3]] eq "")){$chainst.="(무효)";}
		else{
			$chainst.="$c_name[$fld[$tmp[2]]]→";
			if($tmp[3] eq "player"){$chainst.="플레이어";}
			elsif($fld_rf[$tmp[3]]==1){$chainst.="세트 몬스터";}
			else{$chainst.=$c_name[$fld[$tmp[3]]];}
		}
	}
	elsif($tmp[1]==9 || $tmp[1]==10){$chainst.="$c_name[$tmp[2]]";}
	elsif($tmp[1]==1 || $tmp[1]==2 ||  $tmp[1]==4 || $tmp[1]==5 || $tmp[1]==6){$chainst.="$c_name[$tmp[3]]";}
	$chainst.="<br>\n";
}

sub make_date{
	local($dat)=$_[0];
	$tmp=substr($dat,4,2);
	$tmp.=":".substr($dat,6,2);
	return $tmp;
}

sub put_screen2{

	#######################################################
	#표시 개시
	print<<"_EOF_";
<form action="$act" method=post>
<input type=hidden name="id" value="$id">
$hidst
<center>
<table width=100%><tr><td valign=top>
턴：$turn<br>
<br>
【LP】<br>
$pn[$u_side]：$lp[$u_side]<br>
$pn[$u_side2]：$lp[$u_side2]<br>
<br>
【산찰】<br>
$pn[$u_side]：$deckno[$u_side]<br>
$pn[$u_side2]：$deckno[$u_side2]<br>
<br>
【묘지】<br>
<a href="view.cgi?room=$room&id=$id&area=boti$u_side" target=yugo>$pn[$u_side]</a><br>
<a href="view.cgi?room=$room&id=$id&area=boti$u_side2" target=yugo>$pn[$u_side2]</a><br>
<BR>
$matchst
$updatest
</td><td valign=top align=center>
_EOF_


	#상대의 패
	@tmp_s=@{$tehuda[$u_side2]};

	if($not_control==1){}
	elsif($syori[0]=~/^2/ && substr($seast,9,1)==1){$t_v_flg=1;}
	elsif($kok[$u_side][47] ne ""){$t_v_flg=2;}
	elsif($player[1]==5 && $room eq ""){$t_v_flg=2;}

	if($t_v_flg ne ""){
		print "<table><tr align=center bgcolor=$bgc_huse>\n";
		for($i=0;$i<$#tmp_s+1;$i++){
			print "<td>";
			&view_card($tmp_s[$i]);
			if($t_v_flg==1){
				$res_si=$i+100;
				if(&card_search_sub($res_si)){print "선거<input type=checkbox name=select_$res_si>\n";}
			}
			print "</td>";
		}
		print "</tr></table>\n";
	}
	else{
		for($i=0;$i<$#tmp_s+1;$i++){print "■\n";}
	}

	if($direct_chk==1 && $read_only!=1 && $syori[0] eq "" && $not_control!=1 && $chain[0] eq ""){
		print "대상<input type=radio name=\"attack_to\" value=player$attack_onlystr>\n";
	}
	print "<br>\n";

	print "<table border=1>\n<tr align=center>\n";
	&view_field($u_side2,1);
	print "</tr><tr align=center>\n";
	&view_field($u_side2,0);
	print "</tr></table>\n<br>\n";

	#대사
	print $pstr;

	if($not_control!=1){&put_screen_select;}

	print "<table border=1>\n<tr align=center>\n";
	&view_field($u_side,0);
	print "</tr><tr align=center>\n";
	&view_field($u_side,1);
	print "</tr></table>\n<br>\n";

	if($read_only!=1){&decide_button;}

	print "</td><td valign=top align=center>\n";
	$fldno=19+$u_side2;
	if($fld[$fldno] ne ""){$v_side=$u_side2;print "<table><tr>\n";&view_field_sub($fldno,1);print "</tr></table>\n";}
	print $butst2;

	$fldno=19+$u_side;
	if($fld[$fldno] ne ""){$v_side=$u_side;print "<table><tr>\n";&view_field_sub($fldno,1);print "</tr></table>\n";}
	print $yugost;
	print $husatust;
	print $tenpenst;

	print<<"_EOF_";
</td></tr></table>
<table><tr align=center bgcolor=$bgc_tehuda><td>
$butst
_EOF_

	&view_tehuda;

	print "</td></tr></table>\n";
	if($room ne "" && $side[1] eq "" && $read_only!=1){
		print "<i>상대가 오는 것을 기다리고 있습니다. <br>돌아갈때는 맨 밑의 「돌아가기」를 눌러 주세요. <br></i>";
		$kosanst="<input type=\"submit\" name=\"drop\" value=\"빠짐\"><br>\n";
	}
	elsif($syori[0]!=3 && $syori[0]!~/^5/ && $read_only!=1){
		$kosanst="<input type=\"submit\" name=\"surrender\" value=\"항복\"><br>\n";
		if($not_control==1){print "<i>상대의 입력 대기입니다. <br>1분 정도 지나면 「WAIT」을 눌러 주세요. <br></i>";}
	}
	if($read_only!=1){$messt='<input type=text size=25 name="mess"><input type=submit value="메세지 송신"><br>';}
	if($syori[0]==3){$messt='</form><form action=duel.cgi method=post><input type=hidden name="id" value="'.$id.'"><input type=hidden name="room" value="'.$room.'">'.$messt;}

	print<<"_EOF_";
<br>
<font size=-1>$chainst</font>
<br>
<FONT SIZE=-1>$phasest<br>
<br>
$waitst<br>
<br>
$waitstj<br>
</font>
<br>
$messt
<br>
<br>
<a href="$help#duel" target=new>설명</a><br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
$kosanst
</form>
</body></html>
_EOF_

	if($read_only!=1 && $not_control_f!=1){&put_ini;}

	if($room ne "" && $read_only!=1){
		open(TIME,">tmp/".$fn."_time".$u_side);
		print TIME "$date\t$waitst2\t$logcou\t$surrflg\t$waitstj2";
		close(TIME);
	}
	exit;
}

sub view_field{	#필드 표시
	local($j,$st1,$st2);
	local($v_side) = $_[0];	#1-플레이어1
	local($v_kind) = $_[1];	#0-몬스터

	if($v_kind==0){$st=$fw1[$v_side];}
	else{$st=$fw2[$v_side];}

	for($j=$st;$j<$st+5;$j++){&view_field_sub($j,$v_kind);}
}

sub view_field_sub{
	local($fldno)=$_[0];
	local($v_kind)=$_[1];
	$cardno=$fld[$fldno];

	if($jiban[$fldno] ne ""){$bgc_t=" bgcolor=$bgc_jiban";}else{$bgc_t="";}
	if($cardno eq ""){
		print "<td valign=bottom$bgc_t>";
		if(substr($seast,3,1)==1 && $not_control!=1 && $read_only!=1){
			&which_side($fldno);
			if($syori[0]=~/^2/ && $fld[$fldno] eq "" && $which_area==1 && $jiban[$fldno] eq ""){print "선거<input type=checkbox name=\"select_$fldno\">";}
		}
		if($jiban[$fldno] ne ""){print "<font color=$bgc_jiban>";}
		else{print "<font color=$bgc>";}
		print "＿＿＿＿＿</font>";
	}
	else{
		if($fld_rf[$fldno]==1){print "<td bgcolor=$bgc_huse>";}
		else{print "<td$bgc_t>\n";}

		if($v_kind==0){
			if($fld_ad[$fldno]==0){print "<b>공격</b><br>";}
			else{print "<b>수비</b><br>";}
		}
		if($player[1]==5 && $room eq ""){&view_card($cardno,$fldno);}
		elsif(($read_only==1 || $u_side!=$v_side) && $fld_rf[$fldno]==1){
			print "<table border=1><tr><td>\n";
			print "<br><br><br><font color=$bgc_huse>＿＿＿＿＿</font></td></tr></table><br>\n";
		}
		else{&view_card($cardno,$fldno);}

		if($fld_mess[$fldno] ne ""){print $fld_mess[$fldno];}

		if($not_control!=1 && $read_only!=1){
			if($v_kind==0){&view_fldbutton_mst;}
			else{&view_fldbutton_mag;}
		}
	}
	print "</td>\n";
}

sub view_fldbutton_mst{

	$tstr="";

	if($syori[0] eq "" && ($phase==0 || $phase==1)){return;}
	if($syori[0]=~/^2/){
		if(substr($seast,4,1)!=1 && $fw1[$u_side]<=$fldno && $fldno<$fw1[$u_side]+5){return;}
		if(substr($seast,5,1)!=1 && $fw1[$u_side2]<=$fldno && $fldno<$fw1[$u_side2]+5 && !($hk[13]==$fldno && substr($seast,3,1)==2)){return;}

		if(!(&card_search_sub($fldno))){return;}

		print "선거<input type=checkbox name=\"select_$fldno\">";
		return;
	}
	elsif($syori[0]=~/^4/){
		if(($v_side==$u_side || $fldno==$hk[13]) && $rule==0 && $cardno!=1050 && $cardno!=974 && $kok[0][35] eq ""){$tstr.="생지<input type=checkbox name=\"nie_$fldno\">/";}
	}
	elsif($syori[0] ne ""){return;}
	elsif($chain[0] ne ""){
		if($v_side==$u_side && ($c_end!=2 && &chain_chk_mst($fldno)) || ($cardno==1171 && $c_end==2 && $pat==3)){$tstr.="효과<input type=radio name=\"use\" value=\"f_$fldno\">";}
	}

	elsif($v_side==$u_side){		#자 필드
		if($battle_chk==1 && $a_b[$fldno]!=1 && ($fld_ad[$fldno]==0 || ($cardno==718 && $fld_rf[$fldno]!=1))){$tstr.="배틀<input type=radio name=\"attack_from\" value=$fldno>/";}
		if($a_m[$fldno] eq ""){
			if($fld_ad[$fldno]==1){
				$tstr.="공표<input type=radio name=\"chg_$fldno\" value=\"a\">/";$changeflg=1;
			}
			else{
				$tstr.="수표<input type=radio name=\"chg_$fldno\" value=\"d\">/";$changeflg=1;
			}
		}
		if($rule==0 && $cardno!=1050 && $cardno!=974 && $kok[0][35] eq ""){$tstr.="생지<input type=checkbox name=\"nie_$fldno\">/";}
		if(($fld_rf[$fldno]==0 && $c_koka[$cardno]==4) || ($fld_koka[$fldno]=~/metal/ && ($cardno==155 || $cardno==719)) || ($fld_koka[$fldno]=~/tokima/ && $cardno==59)){$tstr.="효과<input type=radio name=\"use\" value=\"f_$fldno\">";}
	}

	else{				#적 필드
		$tstr.="대상<input type=radio name=\"attack_to\" value=$fldno$attack_onlystr>";
		if($fldno==$hk[13] && $rule==0 && $cardno!=1050 && $cardno!=974){$tstr.="생지<input type=checkbox name=\"nie_$fldno\">/";}

	}

	$tstr=~s/\/$//;
	print $tstr;
}

sub view_fldbutton_mag{
	if($syori[0]=~/^2/){
		if(substr($seast,6,1)!=1 && (($fw2[$u_side]<=$fldno && $fldno<$fw2[$u_side]+5) || $fldno==$fside[$u_side])){return;}
		if(substr($seast,7,1)!=1 && (($fw2[$u_side2]<=$fldno && $fldno<$fw2[$u_side2]+5) || $fldno==$fside[$u_side2])){return;}

		if(!(&card_search_sub($fldno))){return;}

		print "선거<input type=checkbox name=\"select_$fldno\">";
		return;
	}
	elsif($syori[0] ne ""){return;}
	elsif($v_side!=$u_side && !($fldno==$fside[$u_side2] && $fld_rf[$fldno]!=1)){return;}
	elsif($chain[0] eq "" && $phase!=2 && $phase!=3 && $phase!=4){return;}
	elsif(&use_chkf($fldno)){print "사용<input type=radio name=\"use\" value=\"f_$fldno\">";}
}

sub use_chkf{
	local($fldno)=$_[0];
	local($cardno)=$fld[$fldno];

	if($fld_rf[$fldno]!=1 && !grep(/^$cardno$/,@omoteuse)){return 0;}
	if($a_m[$fldno]==1 || $a_m[$fldno]==5){
		if($c_syuzoku[$cardno] eq "속공"){return 0;}
		if($c_zokusei[$cardno] eq "함정" && ($kok[$u_side][54] eq "" || $kok[0][8] ne "")){return 0;}
	}
	if($kok[0][30] ne "" && $c_zokusei[$cardno] eq "마" && ($a_m[$fldno]==4 || $a_m[$fldno]==5)){return 0;}

	if($chain[0] ne ""){
		if($c_syuzoku[$cardno] ne "속공" && $c_zokusei[$cardno] ne "함정"){return 0;}
		if($c_end==2 && $c_syokan[$cardno] ne "" && $cardno!=1001 && $cardno!=867 && $cardno!=717 && $c_syuzoku[$cardno] ne "카운터"){return 0;}
		if(!(&chain_chk($cardno))){return 0;}
	}
	else{
		if($c_zokusei[$cardno] eq "함정" && $c_syokan[$cardno] ne ""){return 0;}
	}
	1;
}

sub basyo_set{	#$tmp_s과$sup를 세트
	local($basyo)=$_[0];

	if($basyo==8){@tmp_s = @{$tehuda[$s_a]};$sup=50;}
	elsif($basyo==9){@tmp_s = @{$tehuda[$s_d]};$sup=100;}
	elsif($basyo==10){@tmp_s = @{$boti[$s_a]};$sup=200;}
	elsif($basyo==11){@tmp_s = @{$boti[$s_d]};$sup=300;}
	elsif($basyo==12){@tmp_s = @{$deck[$s_a]};$sup=400;}
	elsif($basyo==13){@tmp_s = @{$deck[$s_d]};$sup=500;}
	elsif($basyo==14){@tmp_s = @{$yugo[$s_a]};$sup=600;}
	elsif($basyo==15){@tmp_s = @{$yugo[$s_d]};$sup=700;}
}

sub put_screen_select{	#묘지등 의 선택
	local($i,$j,$cou);

	if($syori[0]!~/^2/){return;}

	if($S{'o'} eq "kinsi"){print "<input type=text size=20 name=\"options\"><br>\n";return;}

	if($S{'o'} eq "dna"){
		print "<select name=options>\n";
		for($i=0;$i<$#syu_arr+1;$i++){
			print "<option value=$i>$syu_arr[$i]\n";
		}
		print "</select>\n";
		return;
	}

	if($S{'o'} ne ""){
		@tmp=split(/::/,$S{'o'});
		for($i=0;$i<$#tmp+1;$i++){
			print "<input type=radio name=\"options\" value=$i";
			if($i==0){print " checked";}
			print ">$tmp[$i]　";
		}
		print "<br>";
	}

	for($j=10;$j<16;$j++){
		if(substr($seast,$j,1)!=1){next;}
		&basyo_set($j);

		print "<table><tr>\n";
		$cou=0;
		for($i=0;$i<$#tmp_s+1;$i++){
			$cardno=$tmp_s[$i];
			if($cardno eq ""){next;}
			if($cardno=~/_i$/){$cardno=~s/_i$//;$irrflg=1;}
			else{$irrflg=0;}
			$res_si = $i + $sup;
			if(!(&card_search_sub($res_si))){next;}
			print "<td align=center>";
			&view_card($cardno);
			print "<input type=checkbox name=\"select_$res_si\">선거<br>\n";
			print "</td>\n";
			if($cou%5==4){print "</tr><tr>\n";}
			$cou++;
			$taisyo_ari_flg=1;
		}
		print "</tr></table>\n";
	}
}

sub view_tehuda{
	local($i);

	@tmp_s=@{$tehuda[$u_side]};

	if($read_only==1){for($i=0;$i<$#tmp_s+1;$i++){print "■\n";}return;}

	print "<table border=0>\n";
	print "<tr align=center>\n";
	for($i=0;$i<$#tmp_s+1;$i++){
		$cardno=$tmp_s[$i];

		if($cardno eq ""){next;}
		else{
			print "<td>\n";
			&view_card($cardno);
		}
		if($not_control==1){}

		elsif($syori[0]=~/^2/){
			if(substr($seast,8,1)==1){
				$i8=$i+50;
				if(&card_search_sub($i8)){print "선거<input type=checkbox name=select_$i8>\n";}
			}
		}
		elsif($syori[0]=~/^4/){
			if($c_zokusei[$cardno] ne "마" && $c_zokusei[$cardno] ne "함정" && ($c_syokan[$cardno] ne "" || $c_zokusei[$cardno] ne "신")){
				print "공<input type=radio name=putcardno value=".$i."_a>\n";
				print "수<input type=radio name=putcardno value=".$i."_d>\n";
			}
		}
		elsif($chain[0] ne ""){
			if(&use_chkt($cardno)){print "사용<input type=radio name=use value=\"t_$i\">\n";}
		}
		elsif($syori[0] ne ""){}

		elsif($phase==2 || $phase==3 || $phase==4){
			if($c_zokusei[$cardno] eq "마" || $c_zokusei[$cardno] eq "함정"){
				print "세트<input type=checkbox name=putm_$i>";
				if(&use_chkt($cardno)){print "/사용<input type=radio name=use value=\"t_$i\">\n";}
			}
			else{
				if(($call[$u_side] eq "" && $c_syokan[$cardno]!=2) || ($c_syokan[$cardno]==3 && $c_zokusei[$cardno] ne "신")|| $c_syokan[$cardno]==4 || $cardno==914){
					print "공<input type=radio name=putcardno value=".$i."_a>\n";
					print "수<input type=radio name=putcardno value=".$i."_d>\n";
				}
				if($c_koka[$cardno]==3){
					print "효과<input type=radio name=use value=\"t_$i\">\n";
				}
			}
		}
		print "</td>\n";
	}
	print "</tr>\n";
	print "</table>\n<br>\n";

}

sub use_chkt{
	local($cardno)=$_[0];

	if($kok[0][30] ne "" && $c_zokusei[$cardno] eq "마"){return 0;}
	if($c_zokusei[$cardno] eq "함정"){
		if($hk[19+$u_side] eq ""){return 0;}
		if($chain[0] eq "" && $c_syokan[$cardno] ne ""){return 0;}
	}

	if($chain[0] ne ""){
		if($cardno==687){return 1;}
		if($chain[0]=~/^[12]-3-/ && $cardno==378 && $rule==0){return 1;}

		if($c_syuzoku[$cardno] ne "속공" && $c_zokusei[$cardno] ne "함정"){return 0;}
		if($c_syuzoku[$cardno] eq "속공" && $u_side!=$turn2){return 0;}
		if(!(&chain_chk($cardno))){return 0;}
	}
	1;
}

#동작 버튼 판정
sub decide_button{

	if($syori[0]==3){
		if($lp[$u_side]>0){$butst="<input type=submit value=\"YOU WIN!\">\n";}
		elsif($lp[$u_side2]>0){$butst="<input type=submit value=\"YOU LOSE!\">\n";}
		else{$butst="<input type=submit value=\"DRAW!\">\n";}
	}
	elsif($syori[0]=~/^5/ && $syori[0] ne "5".$u_side){
		$butst="<input type=submit value=\"덱 교환\">\n";
	}
	elsif($not_control==1 || $cpu_control==1){$butst="<input type=submit value=\"WAIT\">\n";}

	elsif($syori[0]=~/^2/){
		$butst="<input type=submit value=\"선택\" name=\"run_select\">\n";
		if($S{'g'}!=1){$butst.="<input type=submit value=\"그만두기\" name=\"not_select\">\n";}
	}
	elsif($syori[0]=~/^4/){
		$butst="<input type=submit value=\"카드 내기\" name=\"putcard\">\n";
		if($S{'g'}!=1){$butst.="<input type=submit value=\"그만두기\" name=\"not_select\">\n";}
	}

	elsif($chain[0] ne ""){
		$butst="<input type=submit value=\"마법/함정/효과\" name=\"usecard\">\n";
		$butst.="<input type=submit value=\"속행\" name=\"go_on\">\n";
	}

	elsif($phase==0){$butst="<input type=submit value=\"드로\" name=\"turn_start\">\n";}

	elsif($phase==2 || $phase==3 || $phase==4){
		if($battle_chk==1){$butst.="<input type=submit value=\"배틀! \" name=\"battle\">\n";}
		$butst.="<input type=submit value=\"카드 내기\" name=\"putcard\">\n";
		$butst.="<input type=submit value=\"마법/함정/효과\" name=\"usecard\">\n";
		$butst.="<input type=submit value=\"표시 변경\" name=\"change\">\n";
		$butst.="<input type=submit value=\"턴 종료\" name=\"turn_end\">\n";
	}
	$butst2=$butst;
	$butst2=~s/\n/<br><br>\n/g;
}

sub view_card{
	$cardno = $_[0];
	$fldno = $_[1];
	if($c_zokusei[$cardno] eq "마"){
		$tmp="【$c_syuzoku[$cardno]마법】";
		&view_card2($cardno);
	}
	elsif($c_zokusei[$cardno] eq "함정"){
		$tmp="【$c_syuzoku[$cardno]함정】";
		&view_card2($cardno);
	}
	else{
		&view_card1($cardno,$fldno);
	}
}

sub view_card2{		#마법·함정 카드 표시
	local($i);
	$cardno = $_[0];

	print<<"_EOF_";
<table border=1>
<tr><td>
$c_name[$cardno]
</td></tr>
<tr><td align=right>
$tmp
</td></tr>
<tr>
<td nowrap>
<a href="$khelp#$cardno" target=new>효과</a><br>
</tr></table>
_EOF_
}

sub view_card1{		#몬스터 카드 표시
	local($i,$ap,$dp);
	local($cardno) = $_[0];
	local($fldno) = $_[1];

	if($dna ne "" && 5<=$fldno && $fldno<15){$syust="<font color=$textc_p1>$syu_arr[$dna]</font>";}
	else{$syust=$c_syuzoku[$cardno];}

	if($v_kind==0 && $fldno ne ""){
		$ap=$ap_fld[$fldno];$dp=$dp_fld[$fldno];
		if($ap_fld[$fldno]>$c_ap[$cardno]){$ap="<font color=$textc_p1>$ap</font>";}
		elsif($ap_fld[$fldno]<$c_ap[$cardno]){$ap="<font color=$textc_p2>$ap</font>";}
		if($dp_fld[$fldno]>$c_dp[$cardno]){$dp="<font color=$textc_p1>$dp</font>";}
		elsif($dp_fld[$fldno]<$c_dp[$cardno]){$dp="<font color=$textc_p2>$dp</font>";}
	}
	else{$ap=$c_ap[$cardno];$dp=$c_dp[$cardno];}

	$tmpst="";
	if($c_koka[$cardno]==2 || $c_koka[$cardno]==7){$tmpst.="<a href=\"$khelp#$cardno\" target=new>리버스</a>\n";}
	elsif($c_koka[$cardno] ne ""){$tmpst.="<a href=\"$khelp#$cardno\" target=new>효과</a>\n";}
	if($c_syokan[$cardno]==1){$tmpst.="<a href=\"$yhelp#$cardno\" target=new>융합</a>\n";}
	elsif($c_syokan[$cardno]==2){$tmpst.="<a href=\"$yhelp#$cardno\" target=new>의식</a>\n";}
	elsif($c_syokan[$cardno]==3){$tmpst.="조건 소환\n";}
	elsif($c_syokan[$cardno]==4){$tmpst.="트\n";}
	elsif($c_syokan[$cardno]==6){$tmpst.="스피릿\n";}
	$starst="";$tmp=&lv_st($cardno,$fldno);
	for($i=0;$i<$tmp;$i++){$starst.="★";}

	print<<"_EOF_";
<table border=1>
<tr><td colspan=2>

<table width=100% cellpadding=0 cellspacing=0><tr><td>
$c_name[$cardno]</td><td align=right>/$c_zokusei[$cardno]</td>
</tr></table>

</td></tr>

<tr><td colspan=2 align=right>
$starst
</td></tr><tr>
<td nowrap>【$syust족】<br>
$tmpst
</td>
<td align=right>
$ap<br>
$dp<br>
</td>
</tr></table>
_EOF_
}

sub get_fld_mess{
	local($i,$j);
	undef(@fld_mess);
	for($i=0;$i<22;$i++){
		if($fld[$i] eq ""){next;}
		if($fld_koka[$i]=~/silkhat/){$fld_mess[$i]="비단 모자<br>";next;}

		if($fld_rf[$i]==1){}
		elsif(($fld[$i]==125 || $fld[$i]==930) && $fld_koka[$i]=~/turn_(\d+)<>/){
			if($fld[$i]==125){$tmp=3;}else{$tmp=2;}
			$tmp= $tmp - ($turn - $1) / 2;
			$tmp = int($tmp + 0.5);
			$fld_mess[$i]="나머지 턴：$tmp<br>";
		}
		elsif($fld[$i]==901){
			if($fld_koka[$i]!~/kin_(\d+)/){next;}
			$fld_mess[$i]="$c_name[$1]<br>";
		}
		elsif($fld[$i]==887){
			if($fld_koka[$i]!~/dna_(\d+)_/){next;}
			$fld_mess[$i]="$syu_arr[$1]<br>";
		}
		elsif($fld[$i]==1129){
			if($fld_koka[$i]=~/hunter_(\d+)/){$fld_mess[$i]="$syu_arr[$1]<br>";}
		}

		if($fld_koka[$i] ne ""){	#장비 마법 등
			@koka_tmp=split("<>",$fld_koka[$i]);

			for($j=0;$j<$#koka_tmp+1;$j++){
				if($koka_tmp[$j] eq ""){next;}
				if($koka_tmp[$j]=~/^f_(\d+)/ && $fld[$1] ne ""){
					if($fld_rf[$1]==1){
						$fno=$1;$fno %=5;$fno++;
						$fld_mess[$i].="세트 몬스터:<a href=\"$help#taino\" target=new>$fno</a><br>";
					}
					else{$fld_mess[$i].="$c_name[$fld[$1]]<br>";}

					if($fld_koka[$1]=~/_mayu(\d+)/){
						$tmp= ($turn - $1) / 2;
						$tmp = int($tmp);
						$fld_mess[$i].="진화 턴：$tmp<br>";
					}
				}
				elsif($koka_tmp[$j] eq "kokoro"){$fld_mess[$i].="마음의 변화<br>";}
				elsif($koka_tmp[$j] eq "minom_1" || $koka_tmp[$j] eq "minom_2"){$fld_mess[$i].="전자 조작<br>";}
				elsif($koka_tmp[$j] eq "limit"){$fld_mess[$i].="리미터 해제<br>";}
				elsif($koka_tmp[$j] eq "guard"){$fld_mess[$i].="가이드<br>";}
				elsif($koka_tmp[$j] =~ /^skill_$turn$/){$fld_mess[$i].="도적의 비법<br>";}
			}
		}
	}
}

sub syu_st{
	local($res_si)=$_[0];
	if($dna ne "" && 5<=$res_si && $res_si<15){return $syu_arr[$dna];}
	else{$tmp=&getf_res($res_si);return $c_syuzoku[$tmp];}
}

sub lv_st{
	local($cardno)=$_[0];
	local($fldflg)=$_[1];
	$lvtmp=$c_lv[$cardno];
	if($kok[0][60] eq "" || $c_zokusei[$cardno] ne "물"){}
	elsif($fldflg ne "" && ($cardno==918 || $cardno==919)){}
	else{$lvtmp--;if($lvtmp==0){$lvtmp=1;}}
	return $lvtmp;
}

%koka_chk=(125,0,705,1,54,2,892,3,860,4,965,5,861,6,566,7,894,8,953,9,877,10,850,11,963,12,561,13,826,14,801,15,793,16,602,17,784,18,967,19,787,20,387,21,966,22,1040,23,1005,24,930,25,1004,26,1003,27,1002,28,1085,29,751,30,1045,31,1048,32,1065,33,1073,34,986,35,923,36,959,37,1106,38,635,39,983,40,1000,41,1101,42,1060,43,1061,44,1082,45,916,46,871,47,1169,48,1194,49,1160,50,1132,51,1123,52,1205,53,1216,54,1215,55,1116,56,1153,57,1144,58,50,59,1190,60,999,61,1203,62,1188,63,1207,64,1168,65,737,66,972,67,998,68,1196,69,1127,70,1072,71,885,72,886,73);
@koka_sideari=(0,4,10,12,13,15,17,18,21,22,23,24,26,28,31,32,33,36,38,40,41,42,44,46,47,48,50,51,52,53,54,57,61,63,64,65,70,72,73);

sub find_koka_sub{
	local($fldno)=$_[0];
	local($tsno)=$_[1];
	local($mode)=$_[2];	#0-mst
	local($kinmode)=$_[3];
	$cardno=$fld[$fldno];

	if($cardno eq "" || $fld_rf[$fldno]==1 || $a_m[$fldno]==3){return;}
	if($mode==0 && ($c_zokusei[$cardno] eq "마" || $c_zokusei[$cardno] eq "함정")){return;}
	if($mode==1 && $c_zokusei[$cardno] ne "마" && $c_zokusei[$cardno] ne "함정"){return;}
	if($kinmode eq "kinsi" && $kinsi{$cardno} ne "" && $mode==0 && $fld_koka[$fldno]!~/kinsi/){return;}
	if($cardno==1101 && ($fld_rf[$fldno]==1 || $fld_ad[$fldno]!=1)){next;}

	if($c_koka[$cardno]==14){push(@field,$cardno);}
	elsif(($tmp=$koka_chk{$cardno}) ne ""){
		if(grep(/^$tmp$/,@koka_sideari)){$kok[$tsno][$tmp]++;}
		else{$kok[0][$tmp]++;}
	}
	elsif($cardno==954){
		$fld_koka[$fldno]=~/(\d+)-(\d+)<>/;
		$jiban[$1]=1;
		$jiban[$2]=1;
	}
	elsif($cardno==901){
		$fld_koka[$fldno]=~/kin_(\d+)/;
		$kinsi{$1}=1;
		$kinflg=1;
		if($kinsi{0}==1){$kinsi{1156}=1;}
		if($kinsi{208}==1){$kinsi{1037}=1;}
	}
	elsif($cardno==887){
		$fld_koka[$fldno]=~/dna_(\d+)_(\d+)<>/;
		$dna_t[$2]=$1;
	}
}

sub find_koka{
	local($kinmode)=$_[0];
	local($i);

	undef(@kok);undef(@field);undef(@jiban);undef(@dna_t);$kinflg="";$dna="";
	if($kinmode ne "kinsi"){undef(%kinsi);}
	for($i=$fw1[$s_a];$i<$fw1[$s_a]+5;$i++){&find_koka_sub($i,$s_a,0,$kinmode);}
	for($i=$fw2[$s_a];$i<$fw2[$s_a]+5;$i++){&find_koka_sub($i,$s_a,1,$kinmode);}
	for($i=$fw1[$s_d];$i<$fw1[$s_d]+5;$i++){&find_koka_sub($i,$s_d,0,$kinmode);}
	for($i=$fw2[$s_d];$i<$fw2[$s_d]+5;$i++){&find_koka_sub($i,$s_d,1,$kinmode);}
	&find_koka_sub($fside[$s_a],$s_a,1,$kinmode);
	&find_koka_sub($fside[$s_d],$s_d,1,$kinmode);

	if($kok[0][60] ne ""){$kok[0][59]=1;}
	if($kok[0][6] ne ""){$kok[0][7]=1;}
	if($kok[0][7] ne ""){$kok[0][8]="";undef(@dna_t);}
	if($kok[0][7] ne "" || $kok[0][8] ne ""){
		foreach $key (keys(%koka_chk)){
			if($key==566 || $key==1216 || $key==860 || $key==50){next;}
			if(($kok[0][7] ne "" && $c_zokusei[$key] eq "함정") || ($kok[0][8] ne "" && $c_zokusei[$key] eq "마")){
				$tmp=$koka_chk{$key};
				$kok[0][$tmp]="";$kok[$s_a][$tmp]="";$kok[$s_d][$tmp]="";
			}
		}
	}
	if($kok[0][8] ne ""){undef(@jiban);undef(%kinsi);$kinflg="";}
	if($kok[0][27] ne ""){$tehuda_max=99;}
	if($kok[0][25] ne ""){$kok[$s_a][0]=1;$kok[$s_d][0]=1;}

	if($kinflg==1 && $kinmode ne "kinsi"){&find_koka("kinsi");}
	if($#dna_t>-1){$dna=$dna_t[$#dna_t];}
	for($i=0;$i<$#jiban2+1;$i++){$jiban[$jiban2[$i]]=1;}
}

sub get_apdp_fld{
	local($i,$j,$seast,$jokenst,@koka_tmp,@koka_tmp2,$cou);

	&find_koka;

	if($kok[0][8] eq ""){
		if($fld[20] ne "" && $fld_rf[20]!=1 && $a_m[20]!=3){push(@field,$fld[20]);}
		elsif($fld[21] ne "" && $fld_rf[21]!=1 && $a_m[21]!=3){push(@field,$fld[21]);}
	}

	undef(@opt);
	for($i=5;$i<5*3;$i++){
		$cno=$fld[$i];
		if($cno eq ""){next;}
		if($cno==1170){push(@opt,$i);next;}

		if($fw1[$s_a]<=$i && $i<$fw1[$s_a]+5){$l_side=0;$sealet1="10";$sealet2="01";}
		else{$l_side=1;$sealet1="01";$sealet2="10";}
		$tsno=$sno[$l_side];$tsno2=$sno[1-$l_side];
		if(&fisher($i)){$fishflg=1;}else{$fishflg="";}

		if($kok[0][2] ne "" && &syu_st($i) eq "드래곤" && $fld_ad[$i]!=1){$fld_ad[$i]=1;}
		if($cno==1098 && $kok[0][7] ne ""){
			$fld_koka[$i]=~/^f_(\d+)<>/;$fld_koka[$1]="";$fld[$i]="";$fld_koka[$i]="";
			&add_msg("null","함정 몬스터 소멸! ");
			next;
		}

		if($fld_koka[$i]=~/silkhat/ && ($c_zokusei[$cno] eq "마" || $c_zokusei[$cno] eq "함정")){$ap_fld[$i]=0;$dp_fld[$i]=0;}
		elsif($cno==923){
			$cou=&maisu_count(6+$l_side);
			$ap_fld[$i]=$cou*1000;$dp_fld[$i]=$ap_fld[$i];
		}
		elsif($fld_koka[$i]=~/_mayu/){$ap_fld[$i]=0;$dp_fld[$i]=2000;}
		elsif($fld_koka[$i]=~/(\d+)_sacr/ && $fld_rf[$1]!=1){
			$ap_fld[$i]=$c_ap[$fld[$1]];
			$dp_fld[$i]=$c_dp[$fld[$1]];
		}
		elsif($cno==925 || $cno==1099 || $cno==1036){
			if($fld_koka[$i]=~/rar_(\d+)-(\d+)<>/){$ap_fld[$i]=$1;$dp_fld[$i]=$2;}
			else{$ap_fld[$i]=0;$dp_fld[$i]=0;}
		}
		else{
			$ap_fld[$i]=$c_ap[$cno];
			$dp_fld[$i]=$c_dp[$cno];
		}
		if($a_m[$i]==3){next;}

		$ap_tmp=0;$dp_tmp=0;$mul_tmp=1;if($hk[5] ne ""){$mul_tmp=-1;}

		if($phase==3 && $kok[$tsno2][31] ne "" && $turn2==$tsno){$ap_tmp-=300*$kok[$tsno2][31];}

		if($fld_koka[$i]=~/karate/){$ap_fld[$i]*=2;}
		elsif($fld_koka[$i]=~/(\d+)_kyodai/ && $a_m[$1]!=3 && $kok[0][8] eq "" && $fishflg!=1){
			$m_side=&which_side($1,1);
			if(($m_side==0 && $lp[$s_a]>$lp[$s_d]) || ($m_side==1 && $lp[$s_d]>$lp[$s_a])){$ap_fld[$i]=int($ap_fld[$i]/2);}
			elsif($lp[$s_a]!=$lp[$s_d]){$ap_fld[$i]*=2;}
		}

		$tmp=$#field+1;if($fishflg==1){$tmp--;}
		for($fi=0;$fi<$tmp;$fi++){		#필드 마법등
			$f_joken = $m_joken{$field[$fi]};
			$f_koka = $m_koka{$field[$fi]};
			if($f_joken eq "종족"){$f_val = &syu_st($i);}
			elsif($f_joken eq "속성"){$f_val = $c_zokusei[$cno];}
			elsif($f_joken eq "ad"){$f_val = $fld_ad[$i];}

			@k_tmp = split(/<>/,$f_koka);
			for($fj=0;$fj<$#k_tmp+1;$fj++){
				@k_tmp2 = split(/::/,$k_tmp[$fj]);
				if($k_tmp2[0] eq $f_val){
					$ap_tmp+=$k_tmp2[1];$dp_tmp+=$k_tmp2[2];last;
				}
			}
		}

		if($cno==912){
			$seast="0099".$sealet2."0000".$sealet2;
			$jokenst='&syu_st($res_si) eq "드래곤"';
			&card_search;
			$ap_tmp+=500 * ($#res_s+1);
		}
		elsif($cno==677 || $cno==1213){
			$seast="009900000011",$jokenst='$cardno==59 || $cardno==670';
			&card_search;
			$ap_tmp+=300 * ($#res_s+1);
		}
		elsif($cno==723){
			$seast="909911",$jokenst='$cardno==208 || $cardno==1037';
			&card_search;
			$ap_tmp+=300 * ($#res_s+1);
			$dp_tmp+=300 * ($#res_s+1);
		}
		elsif($cno==463){
			$seast="009911";$jokenst='&syu_st($res_si) eq "식물"';
			&card_search;
			$ap_tmp+=100 * ($#res_s+1);
		}
		elsif($cno==559){
			$seast="009911",$jokenst='&syu_st($res_si) eq "기계"';
			&card_search;
			$ap_tmp+=100 * ($#res_s+1);
		}
		elsif($cno==742){
			$seast="009911",$jokenst='&syu_st($res_si) eq "곤충"';
			&card_search;
			$ap_tmp+=200 * ($#res_s+1);
		}
		elsif($cno==830){
			$cou=&maisu_count(6+$l_side);
			$ap_tmp-=$cou * 400;
			$dp_tmp-=$cou * 400;
		}
		elsif($cno==837){
			$cou=&maisu_count(0+(1-$l_side));
			if($cou>0){$ap_tmp-=1000;}
		}
		elsif($cno==320){
			$seast="0999000000".$sealet1;
			$jokenst='';&card_search;
			$ap_tmp+=100 * ($#res_s+1);
		}
		elsif($cno==995){
			$cou=&maisu_count(0+(1-$l_side));
			$ap_tmp-=$cou*200;
		}
		elsif($cno==326){
			$cou=&maisu_count(6+$l_side);
			$ap_tmp+=$cou*300;$dp_tmp+=$cou*300;
		}
		elsif($cno==1046 && $phase==3 && $turn2==$tsno){
			$ap_tmp+=300;
		}
		elsif($cno==1047 && $phase==3 && $turn2!=$tsno){
			$ap_tmp+=300;
		}
		elsif($cno==1212 && $fld_koka[$i]=~/used/){$ap_tmp-=400;}
		elsif($cno==1141 && $phase==3){
			$ap_tmp+=&juhuku_cou($fld_koka[$i],"spilit:$turn")*1000;
		}
		elsif($cno==1225){
			$seast="009911000011";
			$jokenst='&syu_st($res_si) eq "드래곤"';
			&card_search;
			$ap_tmp+=1000 * ($#res_s+1);
		}
		elsif($cno==1226){
			$seast="009911000011";
			$jokenst='&syu_st($res_si) eq "드래곤"';
			&card_search;
			$ap_tmp+=500 * ($#res_s+1);
		}
		elsif($cno==624 && $fld_rf[$i]!=1){
			$seast="909911";$jokenst='$cardno==630';&card_search;
			if($#res_s>-1){
				$pcou=1;
				if($fld_koka[$i]=~/pumpkin:(\d+):(\d+)/){
					if($1==$turn || $2==5 || $sno[$l_side]!=$turn2){$pcou=$2;}
					else{$pcou=$2+1;$fld_koka[$i]=~s/pumpkin:\d+:\d+/pumpkin:$turn:$pcou/;}
				}
				else{$fld_koka[$i].="pumpkin:$turn:$pcou<>";}
				$ap_tmp+=100*$pcou;$dp_tmp+=100*$pcou;
			}
		}

		if($kok[$tsno][42] ne "" && &syu_st($i) eq "식물"){
			$ap_tmp+=500*$kok[$tsno][42];$dp_tmp+=500*$kok[$tsno][42];
		}
		elsif(&syu_st($i) eq "전사"){
			if($kok[$tsno][50] ne ""){$ap_tmp+=400*$kok[$tsno][50];}
			if($kok[$tsno][51] ne ""){
				$seast="9099".$sealet1;
				$jokenst='&syu_st($res_si) eq "전사" || &syu_st($res_si) eq "마법사"';
				&card_search;
				$ap_tmp+=200*($#res_s+1)*$kok[$tsno][51];
			}
		}
		if($kok[0][68] ne "" && $c_zokusei[$cno] eq "물" && $fishflg!=1){$ap_tmp-=500*$kok[0][68];}

		if($fld_koka[$i] ne ""){	#장비 마법 등
			@koka_tmp=split("<>",$fld_koka[$i]);

			for($j=0;$j<$#koka_tmp+1;$j++){
				if($koka_tmp[$j] eq ""){next;}
				$_=$koka_tmp[$j];
				if(/^limi/){
					if(/limi([tu])(\d*)_hk2$/ && ($1 eq "t" || $2==$turn)){$dp_fld[$i]+=$mul_tmp*$dp_tmp;$dp_fld[$i]*=2;$dp_tmp=0;}
					elsif(/limi([tu])(\d*)$/ && ($1 eq "t" || $2==$turn)){$ap_fld[$i]+=$mul_tmp*$ap_tmp;$ap_fld[$i]*=2;$ap_tmp=0;}
					elsif(/limid(\d*)_hk2$/ && $1==$turn){$ap_fld[$i]+=$mul_tmp*$dp_tmp;$dp_fld[$i]=int($dp_fld[$i]/2);$dp_tmp=0;}
					elsif(/limid(\d*)$/ && $1==$turn){$ap_fld[$i]+=$mul_tmp*$ap_tmp;$ap_fld[$i]=int($ap_fld[$i]/2);$ap_tmp=0;}
				}
				elsif(/^ptr:([-\d]+):([-\d]+):(\d+)$/){
					if($turn!=$3 && $3!=0){next;}
					$ap_tmp+=$1;$dp_tmp+=$2;
				}
				elsif(/^kuramasi:(\d+)$/){
					$kturn=$turn-$1+1;if($kturn>5){$kturn=5;}
					$ap_tmp+=$kturn*200;$dp_tmp+=$kturn*200;
				}
				elsif(/^f_(\d+)(.*)/){
					$koka_fld=$1;
					$huka_koka=$2;$huka_koka=~s/^_//;
					if($cno==775 && ($c_syuzoku[$fld[$koka_fld]] eq "장비" || grep(/^$fld[$koka_fld]$/,@soubiatu))){$ap_tmp+=500;}
					if($a_m[$koka_fld]==3){next;}
					if(($kok[0][8] ne "" || $fishflg==1) && $c_zokusei[$fld[$koka_fld]] eq "마"){next;}
					if($kok[0][7] ne "" && $c_zokusei[$fld[$koka_fld]] eq "함정"){next;}

					if($huka_koka eq "gilfer" && $kok[0][8] eq ""){$ap_tmp-=500;next;}
					if($fld[$koka_fld]==1022){
						$m_side=&which_side($koka_fld,1);
						$cou=&maisu_count(4+$m_side);
						$ap_tmp+=800*$cou;$dp_tmp+=800*$cou;next;
					}
					elsif($fld[$koka_fld]==1023){
						$m_side=&which_side($koka_fld,1);
						$cou=&maisu_count(2+$m_side);
						$ap_tmp+=500*$cou;$dp_tmp+=500*$cou;next;
					}
					elsif($fld[$koka_fld]==865){
						if($fld_koka[$koka_fld]=~/<>ap/){$ap_tmp+=700;}
						else{$dp_tmp+=700;}
					}
					else{
						@tmp_k2=split("::",$m_koka{$fld[$koka_fld]});
						if($huka_koka eq "hk2"){
							$ap_tmp+=$tmp_k2[1];$dp_tmp+=$tmp_k2[0];
						}
						else{$ap_tmp+=$tmp_k2[0];$dp_tmp+=$tmp_k2[1];}
					}
				}
			}
		}

		$ap_fld[$i]+=$mul_tmp*$ap_tmp;
		$dp_fld[$i]+=$mul_tmp*$dp_tmp;

		if($fld_koka[$i]=~/mirror/ && $kok[$tsno2][10] ne "" && $kok[0][7] eq ""){$ap_fld[$i]=int($ap_fld[$i]/2);}
		if($fld_koka[$i]=~/mon_box/){$ap_fld[$i]=0;}

		if($ap_fld[$i]<0){$ap_fld[$i]=0;}
		if($dp_fld[$i]<0){$dp_fld[$i]=0;}

		if($hk[2] ne ""){$tmp=$ap_fld[$i];$ap_fld[$i]=$dp_fld[$i];$dp_fld[$i]=$tmp;}
		if($fld_koka[$i]=~/force:$turn/){$ap_fld[$i]=int($ap_fld[$i]/2);}

		if($fld_koka[$i]=~/f_(\d+)_meikyo/ && $ap_fld[$i]>=1300){&add_msg("null","$c_name[$fld[$i]]은 명경지수의 경지로부터 탈락했다.");&go_boti($1);}
		if($fld_koka[$i]=~/moto/){&godatu_ido($i);}
	}

	for($i=0;$i<$#opt+1;$i++){
		if($fld_koka[$opt[$i]]=~/f_(\d+)::/){$ap_fld[$opt[$i]]=$ap_fld[$1];$dp_fld[$opt[$i]]=$dp_fld[$1];}
	}
}

1;

