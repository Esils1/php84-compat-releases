#!/usr/bin/perl
#µ¦±¸¼º

print "Content-type:text/html; charset=utf-8\n\n";

require 'series.lib';
require 'data.lib';

&get_input;
&get_ini2;
&cardread;

%miss=(
"µå·¡°ïÁ· ºÀÀÎÇ×¾Æ¸®",54,
"ÁöºØ ¹ØÀÇ °Í ±«",152,
"µµ±¼²Û ±¸¿ï",178,
"¿å¸ÁÀÇ Ç×¾Æ¸®",179,
"Ç×¾Æ¸® ¸¶ÀÎ",331,
"ÀÎÁ¶ÀÎ°£ -»çÀÌÄÚ¡¤¼ÕÄ«",861,
"¾ÆÆ÷ÇÇ½ºÀÇ È­½Å",1097,
"º£ÀÌºñ µå·¡°ï",300,
);

if($F{'mode'} eq ""){$modest="<a href=\"deck.cgi?id=$id&side=$F{'side'}&mode=text\">ÅØ½ºÆ®</a>";}
else{$modest="<a href=\"deck.cgi?id=$id&side=$F{'side'}\">Åë»ó</a>";}
if($F{'side'} eq ""){$sidest="<a href=\"deck.cgi?id=$id&mode=$F{'mode'}&side=on\">»çÀÌµå</a>";$deckn="¸ÞÀÎ";}
else{$sidest="<a href=\"deck.cgi?id=$id&mode=$F{'mode'}\">¸ÞÀÎ</a>";$deckn="»çÀÌµå";}

print<<"_EOF_";
<html>
<title>DECK</title>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=utf-8">
<body bgcolor=#fffff0 background="embak.gif">
<center>
<form action=deck.cgi method=post>
<input type=hidden name="id" value="$id">
<input type=hidden name="side" value="$F{'side'}">
_EOF_

if($F{'series'} eq ""){$F{'series'}=0;}
if($F{'kind'} ne "" && $F{'kind'}!=0){$F{'series'}=99;}
if($F{'sstr'} ne ""){$F{'series'}=99;$F{'kind'}=0;}

if($F{'sstr'} ne ""){		#@series <- ÁÂÃøÀ¸·Î Ç¥½ÃÇÏ´Â Ä«µå
	$cou=0;
	for($i=0;$i<$#c_name+1;$i++){
		if($c_name[$i]=~/$F{'sstr'}/){$series[$cou]=$i;$cou++;}
	}
}
elsif($F{'series'} ne "99"){@series=split(/,/,$ser[$F{'series'}]);}
else{for($i=0;$i<$#c_name+1;$i++){if($c_name[$i] ne ""){$series[$i]=$i;}}}

undef(@series_tmp);
if($F{'kind'}==0){}
elsif($F{'kind'}==44){@series = @ava;}
else{
	for($i=0;$i<$#series+1;$i++){
		$j = $series[$i];
		if($c_zokusei[$j] ne "¸¶" && $c_zokusei[$j] ne "ÇÔÁ¤"){$mst_card=1;}
		else{$mst_card=0;}

		if($F{'kind'}==1){if($mst_card==1){push(series_tmp,$j);}}
		elsif($F{'kind'}==2){if($mst_card==1 && $c_lv[$j]>4){push(series_tmp,$j);}}
		elsif($F{'kind'}==3){if($mst_card==1 && $c_lv[$j]<5){push(series_tmp,$j);}}
		elsif($F{'kind'}==4){if($mst_card==1 && $c_syokan[$j]==1){push(series_tmp,$j);}}
		elsif($F{'kind'}==5){if($mst_card==1 && $c_syokan[$j]==2){push(series_tmp,$j);}}
		elsif($F{'kind'}==6){if($mst_card==1 && $c_syokan[$j]==3){push(series_tmp,$j);}}
		elsif($F{'kind'}==46){if($mst_card==1 && $c_syokan[$j]==4){push(series_tmp,$j);}}
		elsif($F{'kind'}==47){if($mst_card==1 && $c_syokan[$j]==6){push(series_tmp,$j);}}
		elsif($F{'kind'}==48){if($mst_card==1 && ($c_koka[$j]==2 || $c_koka[$j]==7)){push(series_tmp,$j);}}
		elsif($F{'kind'}==7){if($mst_card==1 && $c_koka[$j] ne ""){push(series_tmp,$j);}}
		elsif($F{'kind'}==8){if($mst_card==1 && $c_zokusei[$j] eq "¾îµÒ"){push(series_tmp,$j);}}
		elsif($F{'kind'}==9){if($mst_card==1 && $c_zokusei[$j] eq "ºû"){push(series_tmp,$j);}}
		elsif($F{'kind'}==10){if($mst_card==1 && $c_zokusei[$j] eq "¶¥"){push(series_tmp,$j);}}
		elsif($F{'kind'}==11){if($mst_card==1 && $c_zokusei[$j] eq "¹°"){push(series_tmp,$j);}}
		elsif($F{'kind'}==12){if($mst_card==1 && $c_zokusei[$j] eq "ºÒ"){push(series_tmp,$j);}}
		elsif($F{'kind'}==13){if($mst_card==1 && $c_zokusei[$j] eq "¹Ù¶÷"){push(series_tmp,$j);}}
		elsif($F{'kind'}==14){if($mst_card==1 && $c_syuzoku[$j] eq "µå·¡°ï"){push(series_tmp,$j);}}
		elsif($F{'kind'}==15){if($mst_card==1 && $c_syuzoku[$j] eq "ºñÇà¾ß¼ö"){push(series_tmp,$j);}}
		elsif($F{'kind'}==16){if($mst_card==1 && $c_syuzoku[$j] eq "ÇØ·æ"){push(series_tmp,$j);}}
		elsif($F{'kind'}==17){if($mst_card==1 && $c_syuzoku[$j] eq "¾î·ù"){push(series_tmp,$j);}}
		elsif($F{'kind'}==18){if($mst_card==1 && $c_syuzoku[$j] eq "¹°"){push(series_tmp,$j);}}
		elsif($F{'kind'}==19){if($mst_card==1 && $c_syuzoku[$j] eq "Àü»ç"){push(series_tmp,$j);}}
		elsif($F{'kind'}==20){if($mst_card==1 && $c_syuzoku[$j] eq "¾ß¼öÀü»ç"){push(series_tmp,$j);}}
		elsif($F{'kind'}==21){if($mst_card==1 && $c_syuzoku[$j] eq "¾ß¼ö"){push(series_tmp,$j);}}
		elsif($F{'kind'}==22){if($mst_card==1 && $c_syuzoku[$j] eq "°ïÃæ"){push(series_tmp,$j);}}
		elsif($F{'kind'}==23){if($mst_card==1 && $c_syuzoku[$j] eq "½Ä¹°"){push(series_tmp,$j);}}
		elsif($F{'kind'}==24){if($mst_card==1 && $c_syuzoku[$j] eq "°ø·æ"){push(series_tmp,$j);}}
		elsif($F{'kind'}==25){if($mst_card==1 && $c_syuzoku[$j] eq "¾Ï¼®"){push(series_tmp,$j);}}
		elsif($F{'kind'}==26){if($mst_card==1 && $c_syuzoku[$j] eq "¾ðµ¥µå"){push(series_tmp,$j);}}
		elsif($F{'kind'}==27){if($mst_card==1 && $c_syuzoku[$j] eq "¾Ç¸¶"){push(series_tmp,$j);}}
		elsif($F{'kind'}==28){if($mst_card==1 && $c_syuzoku[$j] eq "¸¶¹ý»ç"){push(series_tmp,$j);}}
		elsif($F{'kind'}==29){if($mst_card==1 && $c_syuzoku[$j] eq "Ãµ»ç"){push(series_tmp,$j);}}
		elsif($F{'kind'}==30){if($mst_card==1 && $c_syuzoku[$j] eq "È­¿°"){push(series_tmp,$j);}}
		elsif($F{'kind'}==31){if($mst_card==1 && $c_syuzoku[$j] eq "±â°è"){push(series_tmp,$j);}}
		elsif($F{'kind'}==32){if($mst_card==1 && $c_syuzoku[$j] eq "ÆÄÃæ·ù"){push(series_tmp,$j);}}
		elsif($F{'kind'}==45){if($mst_card==1 && $c_syuzoku[$j] eq "¹ø°³"){push(series_tmp,$j);}}
		elsif($F{'kind'}==33){if($c_zokusei[$j] eq "¸¶"){push(series_tmp,$j);}}
		elsif($F{'kind'}==34){if($c_zokusei[$j] eq "¸¶" && $c_syuzoku[$j] eq "Åë»ó"){push(series_tmp,$j);}}
		elsif($F{'kind'}==35){if($c_zokusei[$j] eq "¸¶" && $c_syuzoku[$j] eq "Àåºñ"){push(series_tmp,$j);}}
		elsif($F{'kind'}==36){if($c_zokusei[$j] eq "¸¶" && $c_syuzoku[$j] eq "ÇÊµå"){push(series_tmp,$j);}}
		elsif($F{'kind'}==37){if($c_zokusei[$j] eq "¸¶" && $c_syuzoku[$j] eq "¿µ¼Ó"){push(series_tmp,$j);}}
		elsif($F{'kind'}==38){if($c_zokusei[$j] eq "¸¶" && $c_syuzoku[$j] eq "¼Û°ø"){push(series_tmp,$j);}}
		elsif($F{'kind'}==39){if($c_zokusei[$j] eq "¸¶" && $c_syuzoku[$j] eq "ÀÇ½Ä"){push(series_tmp,$j);}}
		elsif($F{'kind'}==40){if($c_zokusei[$j] eq "ÇÔÁ¤"){push(series_tmp,$j);}}
		elsif($F{'kind'}==41){if($c_zokusei[$j] eq "ÇÔÁ¤" && $c_syuzoku[$j] eq "Åë»ó"){push(series_tmp,$j);}}
		elsif($F{'kind'}==42){if($c_zokusei[$j] eq "ÇÔÁ¤" && $c_syuzoku[$j] eq "¿µ¼Ó"){push(series_tmp,$j);}}
		elsif($F{'kind'}==43){if($c_zokusei[$j] eq "ÇÔÁ¤" && $c_syuzoku[$j] eq "Ä«¿îÅÍ"){push(series_tmp,$j);}}
		elsif($F{'kind'}==49){if(($c_koka[$j] ne "" || $mst_card==0) && !(grep(/^$j$/,@ava))){push(series_tmp,$j);}}
		elsif($F{'kind'}==50){if(grep(/^$j$/,@seigen) || grep(/^$j$/,@junseigen)){push(series_tmp,$j);}}
	}
	@series = @series_tmp;
}

if($F{'text'} ne ""){
	undef(@deck);
	@tmp=split(/\n/,$F{'text'});
	for($i=0;$i<$#tmp+1;$i++){
		if($tmp[$i] ne ""){
			if($miss{$tmp[$i]} ne ""){push(@deck,$miss{$tmp[$i]});}
			else{$TX{$tmp[$i]}++;}
		}
	}
	for($i=0;$i<$#c_name+1;$i++){
		if($TX{$c_name[$i]} ne ""){
			$TXC{$c_name[$i]}=1;
			for($j=0;$j<$TX{$c_name[$i]};$j++){push(@deck,$i);}
		}
	}
	foreach $key (keys(%TX)){if($TXC{$key} eq ""){$overmsg.="<b>À¯Èñ $keyÀÌ¶ó´Â Ä«µå´Â Á¸ÀçÇÏÁö ¾Ê¾Æ</b><br>\n";}}

}

#µ¦À¸·Î ºÎÅÍ »èÁ¦
$cou=0;
@deck_new=@deck;
undef(@deck);
for($i=$#deck_new;$i>-1;$i--){
	if($F{'del'.$i} eq ""){
		&add_card($deck_new[$i]);
	}
}


@sel_s = grep(/^sel/,keys(%F));
for($i=0;$i<$#sel_s+1;$i++){
	$sel_s[$i]=~/^sel(\d+)/;
	&add_card($1);
}

if($F{'copy_run'} ne "" && $F{'copy'} ne ""){
	if($F{'copy'}==-1){
		@tmp=@defo;
	}
	else{
		open(CHD,"charadeck.dat");
		$cou=0;
		while(<CHD>){
			chop($chdst=$_);
			if($cou==$F{'copy'}){last;}
			$cou++;
		}
		@tmp=split(/,/,$chdst);
	}

	if($F{'copy'}==-1 || (16<$F{'copy'} && $F{'copy'}<42)){@deck=();undef(@card_cou);}
	for($i=$#tmp;$i>=0;$i--){&add_card($tmp[$i]);}
}

sub add_card{
	$cardno=$_[0];
	if($F{'seigen'}==2 && ($c_zokusei[$cardno] eq "¿À" || grep(/^$cardno$/,@seigen) || grep(/^$cardno$/,@junseigen))){
		$overmsg.="<b>À¯Èñ¡¸¾ÈµÇ!¡¡$c_name[$cardno]Àº(´Â) ±ÝÁö Ä«µå¾ß¡¹</b><br>\n";
	}
	elsif($c_zokusei[$cardno] eq "½Å"){
		if($kamicou<1){
			unshift(deck,$cardno);
			$kamicou++;
		}
		else{$overmsg.="<b>À¯Èñ¡¸¾ÈµÇ!¡¡½ÅÀÇÄ«µå´Â 1Àå¹Û¿¡ ³ÖÀ»¼ö ¾ø¾î¡¹</b><br>\n";}
	}
	elsif($F{'seigen'}==1 && grep(/^$cardno$/,@seigen)){
		if($card_cou[$cardno]<1){
			unshift(deck,$cardno);
			$card_cou[$cardno]++;
		}
		else{$overmsg.="<b>À¯Èñ¡¸¾ÈµÇ!¡¡$c_name[$cardno]Àº(´Â) Á¦ÇÑ Ä«µå¾ß¡¹</b><br>\n";}
	}
	elsif($F{'seigen'}==1 && grep(/^$cardno$/,@junseigen)){
		if($card_cou[$cardno]<2){
			unshift(deck,$cardno);
			$card_cou[$cardno]++;
		}
		else{$overmsg.="<b>À¯Èñ¡¸¾ÈµÇ!¡¡$c_name[$cardno]Àº(´Â) ÁØÁ¦ÇÑ Ä«µå¾ß</b><br>\n";}
	}
	else{
		if($cardno==1037){$couno=208;}
		elsif($cardno==1190){$couno=50;}
		else{$couno=$cardno;}
		if($card_cou[$couno]<3){
			unshift(deck,$cardno);
			$card_cou[$couno]++;
		}
		else{$overmsg.="<b>À¯Èñ¡¸¾ÈµÇ!¡¡Ä«µå´Â 1Á¾·ù 3Àå±îÁö¾ß</b><br>\n";}
	}
}

if($F{'side'} eq "" && $#deck>98){
	for($i=0;$i<99;$i++){$deck_stack[$i]=$deck[$i];}
	@deck=@deck_stack;
}
elsif($F{'side'} ne "" && $#deck>14){
	for($i=0;$i<15;$i++){$deck_stack[$i]=$deck[$i];}
	@deck=@deck_stack;
}

@deck_stack = sort decksort @deck;
@deck = @deck_stack;

sub decksort{
	if($c_zokusei[$a] eq "¸¶"){$lva=1;}
	elsif($c_zokusei[$a] eq "ÇÔÁ¤"){$lva=2;}
	elsif($c_syokan[$a]==1){$lva=3;}
	else{$lva=0;}
	if($c_zokusei[$b] eq "¸¶"){$lvb=1;}
	elsif($c_zokusei[$b] eq "ÇÔÁ¤"){$lvb=2;}
	elsif($c_syokan[$b]==1){$lvb=3;}
	else{$lvb=0;}
	if($lva ne $lvb){return($lva cmp $lvb);}

	if($lva==1 || $lva==2){return($c_name[$a] cmp $c_name[$b]);}

	if($c_ap[$a]=~/^X/){$pta=4000;}
	elsif($c_ap[$a]<$c_dp[$a]){$pta=$c_dp[$a];}
	else{$pta=$c_ap[$a];}

	if($c_ap[$b]=~/^X/){$ptb=4000;}
	elsif($c_ap[$b]<$c_dp[$b]){$ptb=$c_dp[$b];}
	else{$ptb=$c_ap[$b];}
	if($ptb ne $pta){$ptb <=> $pta;}
	else{$c_name[$a] cmp $c_name[$b];}
}

&put_ini2;

if($F{'allchk2'} ne ""){$chkstr2=" checked";}

#É½¼¨
$cou=0;
for($i=0;$i<$#series+1;$i++){
	$j=$series[$i];
	if($c_zokusei[$j] eq "¸¶"){$sort_src2[$cou2]=$j;$cou2++;}
	elsif($c_zokusei[$j] eq "ÇÔÁ¤"){$sort_src3[$cou3]=$j;$cou3++;}
	else{$sort_src[$cou]=$j;$cou++;}
}

if($F{'sortkey'}==0){@sort_res = sort s_ptr @sort_src;}
elsif($F{'sortkey'}==1){@sort_res = sort s_ap @sort_src;}
elsif($F{'sortkey'}==2){@sort_res = sort s_dp @sort_src;}
elsif($F{'sortkey'}==3){@sort_res = sort s_name @sort_src;}
elsif($F{'sortkey'}==4){@sort_res = sort s_zokusei @sort_src;}
elsif($F{'sortkey'}==5){@sort_res = sort s_syuzoku @sort_src;}
elsif($F{'sortkey'}==6){@sort_res = sort s_lv @sort_src;}
else{@sort_res = @sort_src;}

@sort_res2 = sort s_name @sort_src2;
@sort_res3 = sort s_name @sort_src3;

sub s_name{$c_name[$a] cmp $c_name[$b];}
sub s_zokusei{$c_zokusei[$a] cmp $c_zokusei[$b];}
sub s_syuzoku{$c_syuzoku[$a] cmp $c_syuzoku[$b];}
sub s_ap{
	if($c_ap[$b]=~/^X/){return 1;}
	elsif($c_ap[$a]=~/^X/){return -1;}
	$c_ap[$b] <=> $c_ap[$a];
}
sub s_dp{
	if($c_dp[$b]=~/^X/){return 1;}
	elsif($c_dp[$a]=~/^X/){return -1;}
	$c_dp[$b] <=> $c_dp[$a];
}
sub s_lv{$c_lv[$b] <=> $c_lv[$a];}
sub s_ptr{
	if($c_ap[$b]=~/^X/){return 1;}
	elsif($c_ap[$a]=~/^X/){return -1;}

	if($c_ap[$b]>$c_dp[$b]){$ptr2=$c_ap[$b];}
	else{$ptr2=$c_dp[$b];}
	if($c_ap[$a]>$c_dp[$a]){$ptr1=$c_ap[$a];}
	else{$ptr1=$c_dp[$a];}
	$ptr2 <=> $ptr1;
}
$selstr[$F{'sortkey'}]=" selected";
$selstr2[$F{'kind'}]=" selected";
$selstr3[$F{'series'}]=" selected";
if($F{'copy'} ne "" && $F{'copy'}!=-1){$selstr4[$F{'copy'}]=" selected";}
$selstr5[$F{'seigen'}]=" selected";

print<<"_EOF_";
$overmsg

<select name="series">
<option value=0$selstr3[0]>STARTER BOX
<option value=1$selstr3[1]>Vol.1
<option value=2$selstr3[2]>Vol.2
<option value=3$selstr3[3]>Vol.3
<option value=4$selstr3[4]>Vol.4
<option value=5$selstr3[5]>Vol.5
<option value=6$selstr3[6]>Vol.6
<option value=7$selstr3[7]>Vol.7
<option value=8$selstr3[8]>BOOSTER.1
<option value=9$selstr3[9]>BOOSTER.2
<option value=10$selstr3[10]>BOOSTER.3
<option value=11$selstr3[11]>BOOSTER.4
<option value=12$selstr3[12]>BOOSTER.5
<option value=13$selstr3[13]>BOOSTER.6
<option value=14$selstr3[14]>BOOSTER.7
<option value=23$selstr3[23]>¸ÅÁ÷ ·ê·¯
<option value=24$selstr3[24]>ÆÄ¶ó¿ÀÀÇ ÇÏÀÎ
<option value=25$selstr3[25]>¾Æ´©ºñ½ºÀÇ ÀúÁÖ
<option value=27$selstr3[27]>Ãµ¾ÈÀÇ ¸¶¼ú¼­
<option value=40$selstr3[40]>°¡¸éÀÇ ÁÖ¹Ú
<option value=46$selstr3[46]>¾Ç¸ùÀÇ ¹Ì±Ã
<option value=48$selstr3[48]>¾îµÒÀ» ¾ïÁ¦ÇÏ´Â »ç¶÷
<option value=57$selstr3[57]>¼Ò»ýÇÏ´Â ¿µÈ¥
<option value=20$selstr3[20]>Dark Ceremony Edition
<option value=21$selstr3[21]>Á¤¾ÈÀÇ ¹é·æ Àü¼³
<option value=22$selstr3[22]>PHANTOM GOD
<option value=51$selstr3[51]>¾ÏÈæ¸¶·æÀÇ ºÎÈ°
<option value=52$selstr3[52]>°­Ã¶ÀÇ ½À°ÝÀÚ
<option value=53$selstr3[53]>Booster R1
<option value=54$selstr3[54]>Booster R2
<option value=55$selstr3[55]>Booster R3
<option value=56$selstr3[56]>BoosterChronicle
<option value=16$selstr3[16]>EX À¯Èñ
<option value=17$selstr3[17]>EX À¯Èñ »çÀÌµå
<option value=18$selstr3[18]>EX Ä«ÀÌ¹Ù
<option value=19$selstr3[19]>EX Ä«ÀÌ¹Ù »çÀÌµå
<option value=26$selstr3[26]>EX EX-RºÀÀÔ
<option value=44$selstr3[44]>Structure À¯Èñ
<option value=45$selstr3[45]>Structure À¯ÈñSide
<option value=49$selstr3[49]>Structure Á¶ÀÌ
<option value=50$selstr3[50]>Structure Á¶ÀÌSide
<option value=60$selstr3[60]>Structure Ä«ÀÌ¹Ù
<option value=61$selstr3[61]>Structure Ä«ÀÌ¹ÙSide
<option value=29$selstr3[29]>´ëÈ¸¿ë
<option value=30$selstr3[30]>ÇÁ¸®¹Ì¾ö ÆÑ1
<option value=31$selstr3[31]>ÇÁ¸®¹Ì¾ö ÆÑ 2
<option value=32$selstr3[32]>ÇÁ¸®¹Ì¾ö ÆÑ 3
<option value=39$selstr3[39]>ÇÁ¸®¹Ì¾ö ÆÑ 4
<option value=59$selstr3[59]>ÇÁ¸®¹Ì¾ö ÆÑ 5
<option value=33$selstr3[33]>Limited Edition
<option value=42$selstr3[42]>Limited Edition 2
<option value=43$selstr3[43]>Limited Edition 3
<option value=34$selstr3[34]>¼­Àû, ÀâÁö ºÎ·Ï
<option value=35$selstr3[35]>Áø£Ä£Í
<option value=47$selstr3[47]>Áø£Ä£Í£²
<option value=36$selstr3[36]>£Ä£Í£²
<option value=37$selstr3[37]>£Ä£Í£³
<option value=38$selstr3[38]>£Ä£Í£´
<option value=41$selstr3[41]>£Ä£Í£µ
<option value=58$selstr3[58]>£Ä£Í£¶
<option value=28$selstr3[28]>µà¾óCGIÀü¿ë
<option value=99$selstr3[99]>ÀüÃ¼
</select>
¡¡<select name="kind">
<option value=0$selstr2[0]>ÀüÃ¼
<option value=44$selstr2[44]>»ç¿ë°¡´É ¸¶¹ý/ÇÔÁ¤/È¿°ú
<option value=49$selstr2[49]>»ç¿ëºÒ°¡ ¸¶¹ý/ÇÔÁ¤/È¿°ú
<option value=50$selstr2[50]>Á¦ÇÑ, ÁØÁ¦ÇÑ Ä«µå
<option value=1$selstr2[1]>¸ó½ºÅÍ
<option value=2$selstr2[2]>¡¡º° 5°³ ÀÌ»ó ¸ó½ºÅÍ
<option value=3$selstr2[3]>¡¡º° 4°³ ÀÌÇÏ ¸ó½ºÅÍ
<option value=4$selstr2[4]>¡¡À¶ÇÕ ¸ó½ºÅÍ
<option value=5$selstr2[5]>¡¡ÀÇ½Ä ¸ó½ºÅÍ
<option value=6$selstr2[6]>¡¡Á¶°Ç ¸ó½ºÅÍ
<option value=7$selstr2[7]>¡¡È¿°ú ¸ó½ºÅÍ
<option value=48$selstr2[48]>¡¡¸®¹ö½º ¸ó½ºÅÍ
<option value=46$selstr2[46]>¡¡Æ®
<option value=47$selstr2[47]>¡¡½ºÇÇ¸´
<option value=8$selstr2[8]>¡¡¾îµÒ
<option value=9$selstr2[9]>¡¡ºû
<option value=10$selstr2[10]>¡¡¶¥
<option value=11$selstr2[11]>¡¡¹°
<option value=12$selstr2[12]>¡¡ºÒ
<option value=13$selstr2[13]>¡¡¹Ù¶÷
<option value=14$selstr2[14]>¡¡µå·¡°ïÁ·
<option value=15$selstr2[15]>¡¡ºñÇà¾ß¼öÁ·
<option value=16$selstr2[16]>¡¡ÇØ·æÁ·
<option value=17$selstr2[17]>¡¡¾î·ùÁ·
<option value=18$selstr2[18]>¡¡¹°Á·
<option value=19$selstr2[19]>¡¡Àü»çÁ·
<option value=20$selstr2[20]>¡¡¾ß¼öÀü»çÁ·
<option value=21$selstr2[21]>¡¡¾ß¼öÁ·
<option value=22$selstr2[22]>¡¡°ïÃæÁ·
<option value=23$selstr2[23]>¡¡½Ä¹°Á¾
<option value=24$selstr2[24]>¡¡°ø·æÁ·
<option value=25$selstr2[25]>¡¡¾Ï¼®Á·
<option value=26$selstr2[26]>¡¡¾ðµ¥µåÁ·
<option value=27$selstr2[27]>¡¡¾Ç¸¶Á·
<option value=28$selstr2[28]>¡¡¸¶¹ý»çÁ·
<option value=29$selstr2[29]>¡¡Ãµ»çÁ·
<option value=30$selstr2[30]>¡¡È­¿°Á·
<option value=31$selstr2[31]>¡¡±â°èÁ·
<option value=32$selstr2[32]>¡¡ÆÄÃæ·ùÁ·
<option value=45$selstr2[45]>¡¡¹ø°³Á·
<option value=33$selstr2[33]>¸¶¹ý
<option value=34$selstr2[34]>¡¡Åë»ó ¸¶¹ý
<option value=35$selstr2[35]>¡¡Àåºñ ¸¶¹ý
<option value=36$selstr2[36]>¡¡ÇÊµå ¸¶¹ý
<option value=37$selstr2[37]>¡¡¿µ¼Ó ¸¶¹ý
<option value=38$selstr2[38]>¡¡¼Ó°ø ¸¶¹ý
<option value=39$selstr2[39]>¡¡ÀÇ½Ä ¸¶¹ý
<option value=40$selstr2[40]>ÇÔÁ¤
<option value=41$selstr2[41]>¡¡Åë»ó ÇÔÁ¤
<option value=42$selstr2[42]>¡¡¿µ¼Ó ÇÔÁ¤
<option value=43$selstr2[43]>¡¡Ä«¿îÅÍ ÇÔÁ¤
</select>
¡¡¡¡<input type=text name=sstr size=10 value="$F{'sstr'}">°Ë»ö
¡¡<select name="copy">
<option value=-1>µðÆúÆ®
<option value=0$selstr4[0]>À¯Èñ(DEATH-T)
<option value=1$selstr4[1]>À¯Èñ(¿Õ±¹Æí)
<option value=2$selstr4[2]>À¯Èñ(¹èÆ²½ÃÆ¼Æí)
<option value=3$selstr4[3]>Ä«ÀÌ¹Ù
<option value=4$selstr4[4]>Á¶ÀÌ
<option value=5$selstr4[5]>¸ÞÀÌ
<option value=6$selstr4[6]>Æä°¡¼ö½º
<option value=7$selstr4[7]>»ç¸¶ÁØ
<option value=8$selstr4[8]>¸¶ÇØ·æ
<option value=9$selstr4[9]>´ÙÀÌ³ª¼Ò ¿ë¸¸
<option value=10$selstr4[10]>¾îµÒÀÇ PK
<option value=11$selstr4[11]>°ñÃÑ
<option value=12$selstr4[12]>¹Ì±Ã
<option value=13$selstr4[13]>¹êµðÆ® Å°½º
<option value=14$selstr4[14]>·¹¾î ÇåÅÍ
<option value=15$selstr4[15]>»çÀÌÆÛ ·ÎÆÄ
<option value=42$selstr4[42]>ÆÇµµ¶ó
<option value=16$selstr4[16]>°ú¹¬ÇÑ ÀÎÇü(¸¶¸®Å©)
<option value=43$selstr4[43]>°¡¸éÄÞºñ
<option value=44$selstr4[44]>¹ÙÅ©¶ó
<option value=45$selstr4[45]>¸®½Ãµå
<option value=46$selstr4[46]>¾îµÒÀÇ ¸¶¸®Å©
<option value=47$selstr4[47]>ÀÌ½ÃÁî
<option value="">(¡é¹Ù·ù¾Æ 1¡¤»ùÇÃ)
<option value=17$selstr4[17]>ºÒ²É»çÀÇ ±â»ó
<option value=18$selstr4[18]>¸ÚÀÖ´Â ¸ÞÅ»¸¯
<option value=19$selstr4[19]>ºñ¹ÐÀÇ È­¿ø
<option value=20$selstr4[20]>ÅõÁö¾ß ¿Ê(±â¸ð³ë)
<option value=21$selstr4[21]>½ºÅ©·³ºí!
<option value=22$selstr4[22]>¿À´ÃÀº Ç³¾î!
<option value=23$selstr4[23]>¼Ç»þÀÎ 40
<option value=24$selstr4[24]>¾îµÒ¿¡ È÷ µå´Â °Í
<option value=25$selstr4[25]>µå¸² ±âÈ¹
<option value=26$selstr4[26]>¼Ó¼º µ·¹úÀÌ ±âºÐ
<option value=27$selstr4[27]>¼Û°÷ µà¾ó
<option value=28$selstr4[28]>À¯Èñ
<option value="">(¡é¹Ù·ù¾Æ 2¡¤»ùÇÃ)
<option value=29$selstr4[29]>µå·¡°ï »ç¿ë
<option value=30$selstr4[30]>¹«ÇÑ Æ÷´ë£«¥á
<option value=31$selstr4[31]>¿¢Á¶µð¾Æ
<option value=32$selstr4[32]>¶óÀÌÆ®´× Ç»Àü
<option value=33$selstr4[33]>µ¥ºñ¸£µ¥ÀÌ¸óÁîÄ«¿îÅ¸
<option value=34$selstr4[34]>°ø¼ö ¿ªÀü
<option value=35$selstr4[35]>ÆÄÀÌ¾î º¼
<option value=36$selstr4[36]>Ä«¿À½º À¶ÇÕ
<option value=37$selstr4[37]>µ¦ ÆÄ±«
<option value=38$selstr4[38]>´ÙÀÌ·ºÆ® µ¥¹ÌÁö
<option value=39$selstr4[39]>µ¥ÀÌ¸ó¹ÙÀÌ·Î
<option value=40$selstr4[40]>ÇÑµåµ¥½ºÆ®·ÎÀÌ
<option value=41$selstr4[41]>°¥¾ÆÀÔÈ÷±â ÆÄÆ¼
</select>
<input type=submit name="copy_run" value="Ä«ÇÇ">

<table border=4 cellpadding=5><tr valign=top>
<td colspan=2 align=center>
<a href="$help#deck" target=new>¼³¸í</a>
¡¡
<select name=seigen>
<option value=0$selstr5[0]>Á¦ÇÑ¾øÀÌ
<option value=1$selstr5[1]>Á¦ÇÑ»ç¿ë
<option value=2$selstr5[2]>±ÝÁö
</select>
¡¡<font size=+2><a href="index.cgi?id=$id">µ¹¾Æ°¡±â</a></font>

¡¡<font size=+2><input type=submit value="½ÇÇà">
¡¡$modest
¡¡$sidest
</font>
<br>
<FONT SIZE=-1>
<br>
»ç¼±ÀÇ ¸¶¹ý, ÇÔÁ¤, È¿°ú´Â ¾ÆÁ÷ »ç¿ëÇÒ ¼ö ¾ø½À´Ï´Ù.
<a href="$ahelp" target=new>ÇöÀç »ç¿ë°¡´É ¸¶¹ý, È¿°ú</a><br>
</font>
</td>
</tr><tr valign=top>
<td>
_EOF_
if($#sort_res>-1){
	&view_list(0);
	print "<div align=right><input type=submit value=\"½ÇÇà\"></div><br>\n";
}

if($#sort_res2>-1){
	&view_list(1);
	print "<div align=right><input type=submit value=\"½ÇÇà\"></div><br>\n";
}

if($#sort_res3>-1){
	&view_list(2);
	print "<div align=right><input type=submit value=\"½ÇÇà\"></div><br>\n";
}

print "</td><td>\n";

for($i=0;$i<$#deck+1;$i++){
	if($c_syokan[$deck[$i]]==1 && $F{'side'} eq ""){push(@yugo_deck,$deck[$i]);push(@yugo_num,$i);}
	else{push(@main_deck,$deck[$i]);push(@main_num,$i);}
}

$deckcou=$#main_deck+1;

###ÀÚ½ÅÀÇ µ¦###

if($F{'mode'} eq "text"){
	print "$decknµ¦ÀÇ Àå¼ö -$deckcouÀå<br>\n";
	print "<input type=hidden name=\"mode\" value=\"text\">\n";
	print "<textarea cols=30 rows=70 name=\"text\">";
	for($i=0;$i<$#deck+1;$i++){print "$c_name[$deck[$i]]\n";}
	print "\n</textarea>\n";
}
else{
	print<<"_EOF_";
	<font size=+1><b>$decknµ¦</b></font>¡¡ÇöÀç$deckcouÀå
	¡¡¡¡<font size=-1><input type=checkbox name="allchk2">ÀüºÎ Ã¼Å©</font><br>
_EOF_

	for($i=0;$i<$#main_deck+1;$i++){
		$j=$main_deck[$i];
		print "<input type=checkbox name=\"del$main_num[$i]\"$chkstr2>\n";
		&print_line;
	}

	if($#yugo_deck>-1){print "<br><br><FONT SIZE=+1><b>À¶ÇÕ µ¦</b></font><br>\n";}
	for($i=0;$i<$#yugo_deck+1;$i++){
		$j=$yugo_deck[$i];
		print "<input type=checkbox name=\"del$yugo_num[$i]\"$chkstr2>\n";
		&print_line;
	}
}

print<<"_EOF_";
<div align=right><input type=submit value="½ÇÇà"></div><br>
</td></tr></table>
<hr>
<a href="index.cgi?id=$id">µ¹¾Æ°¡±â</a><br>
</body></html>

_EOF_


############################################
sub print_line{
	if(($c_zokusei[$j] eq "¸¶" || $c_zokusei[$j] eq "ÇÔÁ¤" || $c_koka[$j] ne "") && !grep(/^$j$/,@ava)){$tmpname="<i>$c_name[$j]</i>";}
	else{$tmpname=$c_name[$j];}

	if($c_zokusei[$j] eq "¸¶"){print "<a href=\"$khelp#$j\" target=new>$tmpname</a>/$c_syuzoku[$j]¸¶¹ý<br>\n";}
	elsif($c_zokusei[$j] eq "ÇÔÁ¤"){print "<a href=\"$khelp#$j\" target=new>$tmpname</a>/$c_syuzoku[$j]ÇÔÁ¤<br>\n";}
	else{
		print "$tmpname/$c_zokusei[$j]/$c_syuzoku[$j]/$c_ap[$j]:$c_dp[$j]/$c_lv[$j]";
		if($c_koka[$j]==2 || $c_koka[$j]==7){print "/<a href=\"$khelp#$j\" target=new>¸®¹ö½º</a>\n";}
		elsif($c_koka[$j] ne ""){print "/<a href=\"$khelp#$j\" target=new>È¿°ú</a>\n";}
		if($c_syokan[$j]==1){print "/<a href=\"$yhelp#$j\" target=new>À¶ÇÕ</a>\n";}
		elsif($c_syokan[$j]==2){print "/<a href=\"$yhelp#$j\" target=new>ÀÇ½Ä</a>\n";}
		elsif($c_syokan[$j]==3){print "/Á¶°Ç ¼ÒÈ¯\n";}
		elsif($c_syokan[$j]==4){print "/Æ®\n";}
		elsif($c_syokan[$j]==6){print "/½ºÇÇ¸´\n";}
		print "<br>\n";
	}
}

sub view_list{
	$mode=$_[0];

	if($mode==0){
		print<<"_EOF_";
<font size=+1><b>¸ó½ºÅÍ Ä«µå</b></font>
¡¡<select name="sortkey">
<option value=0$selstr[0]>°ø/¼ö ¼ø
<option value=1$selstr[1]>°ø°Ý·Â ¼ø
<option value=2$selstr[2]>¼öºñ·Â ¼ø
<option value=3$selstr[3]>ÀÌ¸§ ¼ø
<option value=4$selstr[4]>¼Ó¼º ¼ø
<option value=5$selstr[5]>Á¾Á· ¼ø
<option value=6$selstr[6]>ÄÚ½ºÆ® ¼ø
</select>
<br>
_EOF_

		for($i=0;$i<$#sort_res+1;$i++){
			$j=$sort_res[$i];
			if($c_syokan[$j]==5 || $j==1224){next;}
			print "<input type=checkbox name=\"sel$j\">\n";
			&print_line;
		}
	}
	elsif($mode==1){
		print "<h3>¸¶¹ý Ä«µå</h3>\n";
		for($i=0;$i<$#sort_res2+1;$i++){
			$j=$sort_res2[$i];
			print "<input type=checkbox name=\"sel$j\">\n";
			&print_line;
		}
	}
	elsif($mode==2){
		print "<h3>ÇÔÁ¤ Ä«µå</h3>\n";
		for($i=0;$i<$#sort_res3+1;$i++){
			$j=$sort_res3[$i];
			print "<input type=checkbox name=\"sel$j\">\n";
			&print_line;
		}
	}
}

sub cardread{
	$cou=0;
	open(DATA,"card.txt");
	$lin=<DATA>;
	while(<DATA>){
		chop;
		@tmp=split(/\t/);
		$c_name[$cou]=$tmp[0];
		$c_zokusei[$cou]=$tmp[1];
		$c_syuzoku[$cou]=$tmp[2];
		$c_ap[$cou]=$tmp[3];
		$c_dp[$cou]=$tmp[4];
		$c_lv[$cou]=$tmp[5];
		$c_koka[$cou]=$tmp[6];
		$c_syokan[$cou]=$tmp[7];
		$cou++;
	}
}

sub put_ini2{
	local($i);
	if($id eq ""){return;}

	if($F{'side'} eq ""){$P{'deck'}=join(",",@deck);}
	else{$P{'side'}=join(",",@deck);}

	open(PFL,">tmp/".$id."_pfl");
	foreach $key (keys(%P)){
		print PFL "$key\t$P{$key}\n";
	}
	close(PFL);
}

sub get_ini2{

	if(-r "tmp/".$id."_pfl"){
		open(PFL,"tmp/".$id."_pfl");
	}
	else{@deck=@defo;return;}

	while(<PFL>){
		chop;
		($KEY,$VAL) = split(/\t/);
		$P{$KEY} = $VAL;
	}
	close(PFL);
	if($F{'side'} eq ""){@deck=split(/,/,$P{'deck'});}
	else{@deck=split(/,/,$P{'side'});}
}

sub get_input{
	if (length($ENV{'QUERY_STRING'}) > 0) {
		$INPUT = $ENV{'QUERY_STRING'};
	}
	elsif (length($ENV{'CONTENT_LENGTH'}) > 0) {
		read(STDIN, $INPUT, $ENV{'CONTENT_LENGTH'});
	}
	else {
		while ($TMP[0] = <STDIN>) {
			$INPUT .= $TMP[0];
		}
	}
	$INPUT =~ s/\&+/\&/g;
	$INPUT =~ s/#.+//;
	@TMP = split('&', $INPUT);
	for ($i = 0; $i <= $#TMP; ++$i) {
		($KEY, $VAL) = split('=', $TMP[$i]);
		$VAL =~ tr/+/ /;
		$VAL =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
		$VAL =~ s/\015\012/\012/g;
		$VAL =~ s/\015/\012/g;
		if($VAL ne ""){$F{$KEY}=$VAL;}
	}

	$id = $F{'id'};
	$id=~s/\.//g;
	$id=~s/\///g;
	$id=substr($id,0,50);
	if($id eq ""){print "µà¾ó³×ÀÓÀÌ ¾ø¾î";exit;}
}

