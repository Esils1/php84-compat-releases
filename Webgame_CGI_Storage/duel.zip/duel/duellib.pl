sub kokaused{
	if($fld_koka[$use_f_no]=~s/used_(\d+)/used_$turn/){}
	else{$fld_koka[$use_f_no].="used_$turn<>";}
}

sub kokausedchk{
	if($fld_koka[$use_f_no]=~/used_(\d+)/ && $1 eq $turn){&add_msg("null","!$s_a(이 효과는 1턴에 1회 밖에 사용할 수 없다)");return 1;}
	0
}

sub cointos2{
	if($cpu[$s_a]==1){$F{'options'}=0;}
	$rann=rand;$rann=int($rann*2);
	&add_msg($pn[$s_a],"<b>$omoteura[$F{'options'}]! </b>");
	&add_msg("null","나온 코인은 --<b>$omoteura[$rann]! </b>");
	$tmp=$F{'options'};$F{'options'} = "";
	$rann==$tmp;
}

sub cointos{
	if($F{'options'} eq "" && $cpu[$s_a]!=1){
		$tmp_syorip.="<>o-앞::뒤<>m-코인의 앞뒤를 맞힌다";
		&go_select_syori;return 1;
	}
}

sub soubi{
	local($mst_fld)=$_[0];
	local($mag_fld)=$_[1];
	local($huka_koka)=$_[2];

	$tcno=$fld[$mag_fld];

	if($huka_koka ne ""){}
	elsif($tcno==853){$huka_koka="_kyodai";}
	elsif($tcno==958){$huka_koka="_meteo";}
	elsif($tcno==720){$huka_koka="_metalka";}
	elsif($tcno==988){$huka_koka="_jukon";}
	elsif($tcno==635){$huka_koka="_jiryoku";}
	elsif($tcno==1079){$huka_koka="_dust$turn";}
	elsif($tcno==1189){$huka_koka="_meikyo";}
	elsif($tcno==757){$huka_koka="_ryugorosi";}
	elsif($tcno==1075){$huka_koka="_laser";}
	elsif($hk[2] ne ""){$huka_koka="_hk2";}

	$ko_no=&get_ko_no($fld_koka[$mst_fld]);
	$fld_koka[$mag_fld].="f_".$mst_fld."::".$ko_no."<>";
	$fld_koka[$mst_fld].="f_".$mag_fld.$huka_koka."<>";

	if($fld[$mst_fld]==913 && ($c_syuzoku[$tcno] eq "장비" || grep(/^$tcno$/,@soubiatu))){
		&add_msg("null","<b>철의 기사 기어·후리드의 효과 발동! </b><br>$c_name[$tcno]은(는) 장비 되지 않고 파괴! ");
		&go_boti($mag_fld,2);
	}
}

sub tyrant_sosei{
	$seast="99991";$jokenst='&syu_st($res_si) eq "드래곤"';
	$tmp_syorip="<>i-$s_a<>n-tydra<>p-$nf0<>m-드래곤족을 생지에 바친다. <>o-바친다::그만둔다<>g-1<>l-1";
	&go_select_syori;
}

sub reverse{
	local($l_side,$tsno,$i);
	local($fldno)=$_[0];
	$mukoflg=$_[1];

	$tcno=$fld[$fldno];
	if($tcno eq ""){return;}
	$fld_rf[$fldno]=0;
	$l_side=&which_side($fldno,1);
	$tsno=$sno[$l_side];

	if($c_koka[$tcno]==7 || $tcno==1181 || $tcno==1175){
		if($mukoflg ne ""){&add_msg("null","<b>$c_name[$tcno]은$mukomsg[$mukoflg]</b>");}
		elsif($c_koka[$tcno]==7){push(@chain2,"$tsno-7-$tcno-$fldno");}
		else{push(@chain2,"$tsno-5-$tcno-$fldno");}
	}
	if(($tcno==835 || $tcno==373) && $mukoflg eq "" && $kok[0][29] eq ""){$fld_koka[$fldno].="used<>";}

	if($tcno==1169 && &hikari_chk($l_side)){&add_msg("null","(뇌전딸(아가씨)들은 하늘에 돌아간다)");&go_boti($fldno);}
	elsif($c_zokusei[$tcno] ne "빛"){&raiden_ret($l_side);}

	if($tcno==1219 && $kok[$tsno][54] eq ""){
		&add_msg("null","(신전의 밖에서 셀 케토는 존재할 수 없다)");&go_boti($fldno);
	}
}

sub lp_up{
	local($ptr)=$_[0];
	local($cou)=$_[1];
	local($l_side)=$_[2];
	if($cou eq ""){$cou=1;}

	$tmp=$ptr*$cou;
	$tsno=$sno[$l_side];
	if($kok[3-$tsno][53] ne ""){
		&add_msg("null","<b>부작용! </b>　$pn[$tsno]에$tmp의 데미지! ");
		$lp[$tsno]-=$tmp;&chk_lp;
	}
	else{
		&add_msg("null","$pn[$tsno]의 라이프가$tmp회복! ");$lp[$tsno]+=$tmp;
		if($kok[$tsno][40] ne ""){
			$tmp=$kok[$tsno][40]*$cou*500;
			&add_msg("null","<b>빅뱅 걸의 효과 발동! </b><br>$pn[3-$tsno]에$tmp의 데미지! ");
			$lp[3-$tsno]-=$tmp;&chk_lp;
		}
	}
}

sub put_field{
	local($res_sno)=$_[0];
	local($rf)=$_[1];
	local($mode)=$_[2];
	local($cno,$fno);

	if($res_sno<50){return;}
	elsif(50<=$res_sno && $res_sno<100){$arrn="tehuda[$s_a]";$sup=50;}
	elsif(200<=$res_sno && $res_sno<300){$arrn="boti[$s_a]";$sup=200;}
	elsif(300<=$res_sno && $res_sno<400){$arrn="boti[$s_d]";$sup=300;}
	elsif(400<=$res_sno && $res_sno<500){$arrn="deck[$s_a]";$sup=400;}
	elsif(600<=$res_sno && $res_sno<700){$arrn="yugo[$s_a]";$sup=600;}

	$tno=$res_sno-$sup;
	if($tno<0){return;}
	$evalst='$cno = $'.$arrn.'['.$tno.']';
	eval($evalst);
	$evalst='$'.$arrn.'['.$tno.']=""';
	eval($evalst);
	$cno=~s/_i$//;

	$extflg="";
	if($c_zokusei[$cno] ne "마" && $c_zokusei[$cno] ne "함정"){
		$fno=$nf0;
		if($mode ne "t"){$extflg=1;}
	}
	elsif($c_syuzoku[$cno] eq "필드"){&go_boti($fside[$s_a]);$fno=$fside[$s_a];}
	else{$fno=$nf1;}

	$fld[$fno]=$cno;
	$fld_rf[$fno]=$rf;
	$fld_koka[$fno]="";
	if($extflg==1){&ext_set($nf0,$rf,$mode);}
	if($sup==50 && $tep[$s_a][$tno] ne ""){
		$fld_koka[$fno].="moto_$s_d<>teni_$s_a<>";
		if($tep[$s_a][$tno] eq "h"){$fld_koka[$fno].="hakaarasi<>";}
	}
}

sub bphase_end{
	local($i,$flg);

	if($hk[33] ne ""){
		for($i=5;$i<15;$i++){if($fld[$i] ne "" && $a_b[$i]=~/^[123]/ && !(&fisher($i))){&add_msg("null","$c_name[$fld[$i]]는 사투에 힘이 다했다... ");&go_boti($i);}}
	}

	for($i=5;$i<15;$i++){
		if($fld[$i] eq ""){next;}
		if($fld_koka[$i]=~/gorosare/){
			&add_msg("null","$c_name[$fld[$i]]은(는) 용 살인의 상처로 묘지로! ");
			&go_boti($i);next;
		}
		if($fld_koka[$i]=~/silkhat/){
			$flg=1;
			if($c_zokusei[$fld[$i]] eq "마" || $c_zokusei[$fld[$i]] eq "함정"){&go_boti($i);}
			else{$fld_koka[$i]=~s/silkhat<>//;}
		}
		if($fld_koka[$i]=~/m_arm/){
			$fld_koka[$i]=~s/m_arm//;&ctrl_back($i);
		}
		if($fld[$i]==921 && $a_b[$i]==1){
			&add_msg("null","고블린 돌격 부대는 수비 표시로 바뀐다! ");
			$fld_ad[$i]=1;
			if($fld_koka[$i]=~s/gobrin_\d+/gobrin_$turn/){}
			else{$fld_koka[$i].="gobrin_$turn<>";}
		}
		$fld_koka[$i]=~s/mon_box//g;
	}
	if($flg==1){&add_msg("null","비단 모자는 해제되었다. ");}
	for($i=0;$i<2;$i++){
		if($hk[30+$sno[$i]] eq "" || &akichk($i)){next;}
		@vtmp=split(/<>/,$hk[30+$sno[$i]]);$hk[30+$sno[$i]]="";
		for($j=0;$j<$#vtmp+1;$j++){push(@syori,"2<>i-$sno[$i]<>n-hukkatu<>o-공격 표시::수비 표시<>g-1<>m-$c_name[$vtmp[$j]]의 표시 형식은? <>p-v".$vtmp[$j]);}
	}

	$jok[1]="";
	&get_apdp_fld;
}

sub chg_koka{	#효과 대상이fldi1의 것을 ,fldi2에 바꾼다
	local($fldi1)=$_[0];
	local($fldi2)=$_[1];
	local($i,$j,@tmp);
	for($i=0;$i<5*4;$i++){
		@tmp=split("<>",$fld_koka[$i]);
		for($j=0;$j<$#tmp+1;$j++){
			$tmp_st="f_".$fldi1;
			if($tmp[$j]=~/^f_$fldi1([^\d].+)/){$tmp[$j]="f_".$fldi2.$1;}
		}
		$fld_koka[$i]=join("<>",@tmp);
		if($fld_koka[$i] ne ""){$fld_koka[$i].="<>";}
	}
}

sub ctrl_ido{
	local($fldi1)=$_[0];
	local($fldi2)=$_[1];

	if($fld[$fldi1]==1219 && $fld_rf[$fldi1]!=1){
		$tsnoc=$sno[&which_side($fldi2,1)];
		if($kok[$tsnoc][54] eq ""){&add_msg("null","(신전의 밖에서 셀 케토는 존재할 수 없다)");&go_boti($fldi1);return;}
	}

	$fld[$fldi2] = $fld[$fldi1];
	$fld_rf[$fldi2] = $fld_rf[$fldi1];
	$fld_ad[$fldi2] = $fld_ad[$fldi1];

	$fld_koka[$fldi2] = $fld_koka[$fldi1];
	&chg_koka($fldi1,$fldi2);
	$fld_koka[$fldi1]="";&syometu($fldi1);

	if(($fld[$fldi2]==782 || $fld[$fldi2]==783) && $fld_koka[$fldi2]!~/used/ && $fldi2!=30){
		$tmp=$sno[&which_side($fldi1,1)];
		push(@chain2,"$tmp-5-$fld[$fldi2]-$fldi2");
	}
}

sub ctrl_chg{
	local($fldi1)=$_[0];
	local($fldi2)=$_[1];

	&moto_chk($fldi1);
	&moto_chk($fldi2);
	&ctrl_ido($fldi1,30);
	&ctrl_ido($fldi2,$fldi1);
	&ctrl_ido(30,$fldi2);
	$fld_koka[$fldi1].="teni_$s_a<>";
	$fld_koka[$fldi2].="teni_$s_d<>";
	&add_msg("null","<b>$c_name[$fld[$fldi1]]와$c_name[$fld[$fldi2]]를 바꿔 넣었다! </b>");
}

sub ctrl_back{
	local($fldno) = $_[0];
	if($fld[$fldno] eq ""){return;}

	$l_side=&which_side($fldno,1);
	&fld_chk(1-$l_side);
	if($nf0<0){
		&add_msg("null","돌아오는 장소가 없는$c_name[$fld[$fldno]]은 묘지에 갔다. ");
		&go_boti($fldno);
	}
	else{
		&add_msg("null","$c_name[$fld[$fldno]]은(는)$pn[$sno[1-$l_side]]앞으로 돌아왔다. ");
		&ctrl_ido($fldno,$nf0);
	}
}

sub godatu_ido{
	local($fldno)=$_[0];
	$tmp1 = &which_side($fldno,1);
	$tmp2 = &which_side($fldno,2);
	if($tmp1 ne $tmp2){&ctrl_back($fldno);}
}

sub usertoside{
	local($userno)=$_[0];
	if($s_a==$userno){return 0;}
	else{return 1;}
}

sub which_side{
	local($fldno)=$_[0];
	local($mode)=$_[1];
	local($l_side,$i,$tmp,@tmp_k);

	if($fw1[$s_a]<=$fldno && $fldno<$fw1[$s_a]+5){$l_side=0;$which_area=1;}
	elsif($fw2[$s_a]<=$fldno && $fldno<$fw2[$s_a]+5){$l_side=0;$which_area=2;}
	elsif($fw1[$s_d]<=$fldno && $fldno<$fw1[$s_d]+5){$l_side=1;$which_area=1;}
	elsif($fw2[$s_d]<=$fldno && $fldno<$fw2[$s_d]+5){$l_side=1;$which_area=2;}
	elsif($fldno==$fside[$s_a]){$l_side=0;$which_area=2;}
	elsif($fldno==$fside[$s_d]){$l_side=1;$which_area=2;}
	else{return;}
	if($mode==1){return $l_side;}

	$tmp=$fld_koka[$fldno];$moto="";@tmp_k=split(/<>/,$tmp);
	if($tmp=~/moto_([12])/){
		$l_side=&usertoside($1);
		if($mode!=2){return $l_side;}
	}

	$fishflg=&fisher($fldno);
	for($i=0;$i<$#tmp_k+1;$i++){
		if($kok[0][8] eq "" && $tmp_k[$i]=~/^f_(\d+)$/ && $a_m[$1]!=3 && ($fld[$1]==801 || $fld[$1]==1064 || $fld[$1]==1094) && $fishflg==0){
			$l_side=&which_side($1,1);
		}
		elsif($tmp_k[$i]=~/teni_([12])/){$l_side=&usertoside($1);}

		elsif($tmp_k[$i]=~/kokoro/ || $tmp_k[$i]=~/minom/ || $tmp_k[$i]=~/m_arm/){$l_side=1-$l_side;}
	}
	return $l_side;
}

sub card_search_sub{
#$cardno에 대해 ,hit-1 nohit-0를 돌려주는
	local($res_si)=$_[0];

	if($res_si ne "" && $res_si<50){$res_sap=$ap_fld[$res_si];$res_sdp=$dp_fld[$res_si];}
	else{$res_sap=$c_ap[$cardno];$res_sdp=$c_dp[$cardno];}
	if($c_ap[$cardno]=~/^[X\?]/){$res_sap=4000;$res_sdp=$res_sap;}

	local($taisyo)=substr($seast,0,1);
	local($rf)=substr($seast,1,1);
	local($taisyo_toru)=substr($seast,2,1);

	$fkind=substr($seast,3,1);
	if($fkind==4 || $fkind==5){
		if($c_syokan[$cardno]==6){return 0;}
		if($c_syokan[$cardno]==4 && $kok[$s_a][4] eq ""){return 0;}
		if($cardno==1169 && $fkind==4 && &hikari_chk()){return 0;}
		elsif($cardno==1219 && $fkind==4){
			$tmp=&which_side($res_si,1);
			if($kok[$sno[$tmp]][54] eq ""){return 0;}
		}
		elsif($cardno==1099){
			$tmp=&which_side($res_si,1);
			if($player[$sno[$tmp]]!=20){return 0;}
		}
	}
	elsif($fkind==6){if(&fisher($res_si)){return 0;}}

	if($taisyo==0){if($c_zokusei[$cardno] eq "마" || $c_zokusei[$cardno] eq "함정"){return 0;}}
	elsif($taisyo==1){if($c_zokusei[$cardno] ne "마" && $c_zokusei[$cardno] ne "함정"){return 0;}}
	elsif($taisyo==2){if($c_zokusei[$cardno] ne "마"){return 0;}}
	elsif($taisyo==3){if($c_zokusei[$cardno] ne "함정"){return 0;}}

	if($res_si ne "" && $res_si < 50  && (($rf==0 && $fld_rf[$res_si]==1) || ($rf==1 && $fld_rf[$res_si]==0))){return 0;}

	if($taisyo_toru==1 && $res_si<50){
		if($c_zokusei[$cardno] eq "신" && $fld_rf[$res_si]!=1){return 0;}
		if($kok[0][1] ne "" && &syu_st($res_si) eq "드래곤" && $fld_rf[$res_si]!=1){return 0;}
	}

	if($jokenst ne ""){
		$evalst="\$tmp = ($jokenst)";
		eval($evalst);
		if($tmp!=1){return 0;}
	}

	return 1;
}

sub card_search_fld{
	if($fld[$i] eq ""){return;}
	$cardno=$fld[$i];
	if(&card_search_sub($i)){push(@res_s,$i);}
}
sub card_search_nfld{
	local($i);
	for($i=0;$i<$#tmp_s+1;$i++){
		if($tmp_s[$i] eq ""){next;}
		$cardno=$tmp_s[$i];
		if($cardno=~s/_i$//){$irrflg=1;}
		else{$irrflg=0;}
		if(&card_search_sub($i+$sup)){push(res_s,$i+$sup);}
	}
}

sub card_search{
	local($i,$cardno);
	undef(@res_s);

	if(substr($seast,3,1)==2){
		if(&ikenie_chk){return;}
		if($hk[13] ne "" && $hk[13]!=999){push(@res_s,$hk[13]);}
	}
	elsif(substr($seast,3,1)==3){
		if($kok[$s_d][44] ne ""){&add_msg("null","!$s_a(카이크우가 묘지를 봉하고 있다! )");return;}
	}
	elsif(substr($seast,3,1)==1){
		if($cpu[$s_a]==1){$st=5*2;}else{$st=5;}
		for($i=$st;$i<5*3;$i++){if($fld[$i] eq "" && $jiban[$i] eq ""){push(@res_s,$i);}}
		return;
	}

	if(substr($seast,4,1)==1){
		for($i=$fw1[$s_a];$i<$fw1[$s_a]+5;$i++){&card_search_fld;}
	}
	if(substr($seast,5,1)==1){
		for($i=$fw1[$s_d];$i<$fw1[$s_d]+5;$i++){&card_search_fld;}
	}
	if(substr($seast,6,1)==1){
		for($i=$fw2[$s_a];$i<$fw2[$s_a]+5;$i++){&card_search_fld;}
		$i=$fside[$s_a];&card_search_fld;
	}
	if(substr($seast,7,1)==1){
		for($i=$fw2[$s_d];$i<$fw2[$s_d]+5;$i++){&card_search_fld;}
		$i=$fside[$s_d];&card_search_fld;
	}
	if(substr($seast,8,1)==1){@tmp_s=@{$tehuda[$s_a]};$sup=50;&card_search_nfld;}
	if(substr($seast,9,1)==1){@tmp_s=@{$tehuda[$s_d]};$sup=100;&card_search_nfld;}
	if(substr($seast,10,1)==1){@tmp_s=@{$boti[$s_a]};$sup=200;&card_search_nfld;}
	if(substr($seast,11,1)==1){@tmp_s=@{$boti[$s_d]};$sup=300;&card_search_nfld;}
	if(substr($seast,12,1)==1){@tmp_s=@{$deck[$s_a]};$sup=400;&card_search_nfld;}
	if(substr($seast,13,1)==1){@tmp_s=@{$deck[$s_d]};$sup=500;&card_search_nfld;}
	if(substr($seast,14,1)==1){@tmp_s=@{$yugo[$s_a]};$sup=600;&card_search_nfld;}
	if(substr($seast,15,1)==1){@tmp_s=@{$yugo[$s_d]};$sup=700;&card_search_nfld;}
}

sub go_card_search{
	undef(@res_s);
	$go_msgon0=$go_msgon;$go_msgon="";

	if($#select<0){
		&card_search;$select_flg="";
	}
	else{
		for($ii=0;$ii<$#select+1;$ii++){
			if($select[$ii]<50){
				$cardno=$fld[$select[$ii]];
				if(!(&card_search_sub($select[$ii]))){next;}
			}
			$res_s[$ii]=$select[$ii];
		}
		undef(@select);
		$select_flg=1;
	}
	if($cpu[$s_a]==1){$select_flg=1;}

	$gohit=$go_hit;
	if($gohit=~s/>//){
		if($#res_s+1>$1){return 0;}
		else{$gohit=9999;}	#nohit를 표시시킨다
	}
	elsif($gohit=~s/<//){
		if($#res_s<0){$gohit=9999;}
		elsif(($#res_s+1<$gohit && $select_flg==1) || $cpu[$s_a]==1){return 0;}
		else{&go_select_syori;return 2;}
	}

	if($#res_s+1<$gohit){
		if($go_msg eq ""){$go_msg="(대상이 존재하지 않음)";}
		if($go_msgon0!=1){$go_msg="!".$s_a.$go_msg;}
		&add_msg("null",$go_msg);
		return 1;
	}
	elsif(($#res_s+1>$gohit || ($tmp_syorip=~/<>o-/ && $F{'options'} eq "")) && $cpu[$s_a]!=1){
		&go_select_syori;
		return 2;
	}
	else{return 0;}
}

sub go_select_syori{	#syori=2로 해 종료
	push(@syori,"2<>s-".$seast."<>j-".$jokenst.$tmp_syorip);
	return;
}

sub start{
	@roo=grep(/^room_/,keys(%F));
	$room=$roo[0];
	$room=~s/^room_//;

	&get_ini2;
	if($room ne ""){
		&get_timefile;
		$n_min=&get_min($date);
		$t_min=&get_min($update);

		if(length($F{'name'})>14){print "이름은 7문자 이내로";exit;}
		$F{'name'}=~s/<//g;
		if($n_min-$t_min>5){
			unlink("tmp/".$roomst.$room."_log");
		}
		else{&get_ini;}

		if($side[2] eq ""){
			$u_side=2;
			$rule=$F{'rule'};
			$seigen=$F{'seigen'};
			$match=$F{'match'};
			$run_phase=100;
		}
		elsif($side[1] eq ""){
			$u_side=1;
			if($id eq $side[2]){print "같은 듀얼네임의 대전은 할 수 없습니다. ";exit;}
		}
		else{print "사용중 $pn[1] VS $pn[2]";exit;}

		&niheya_chk;
		$side[$u_side]=$id;
		$pn[$u_side]=$F{'name'};
		&chk_deck;
		@{$deck[$u_side]}=@main_deck;
		@{$yugo[$u_side]}=@yugo_deck;
		$player[$u_side]=$F{'player1'};
		$t_logcou[$u_side]=0;
		&deckfile($u_side);

		if($side[1] eq ""){
			$lp[2]=8000;
			&get_playerdata;
			&put_ini;
			return;
		}
	}
	else{
		$player[1]=$F{'player1'};
		$player[2]=$F{'player2'};
		$rule=$F{'rule'};
		if($player[2] eq ""){$player[2]=0;}
		&chk_deck;
		@{$deck[1]}=@main_deck;
		@{$yugo[1]}=@yugo_deck;
		&cpu_deckmake;
		$cpu[2]=1;
	}

	srand;
	$rann=rand;$rann=int($rann*2);
	$turn2=$rann+1;
	&start2;
}

sub start2{
	$phase=0;
	$turn=1;

	$lp[1]=8000;
	$lp[2]=8000;
	&get_playerdata;

	&shuffle(*deck,1);
	&shuffle(*deck,2);

	for($i=0;$i<5;$i++){
		$tehuda[1][$#{$tehuda[1]}+1] = shift(@{$deck[1]});
		$tehuda[2][$#{$tehuda[2]}+1] = shift(@{$deck[2]});
	}

	if($srf[1][0] eq $srf[2][0]){
		&add_msg("null","<center>$pn[1]＆$pn[2]「$srf[1][0]」<br>");
	}
	else{
		&add_msg($pn[1],$srf[1][0]);
		&add_msg($pn[2],$srf[2][0]);
	}
	$run_phase=100;
	&put_ini;
}

sub chk_deck{
	local($i,$errflg);
	undef(@main_deck);
	undef(@yugo_deck);
	undef(%CHK);$kamisu="";$dcgi="";
	for($i=0;$i<$#odeck+1;$i++){
		if($c_syokan[$odeck[$i]]==1){push(@yugo_deck,$odeck[$i]);}
		else{push(@main_deck,$odeck[$i]);}
		if($seigen==0){next;}
		if($seigen==2){
			if(grep(/^$odeck[$i]$/,@seigen) || grep(/^$odeck[$i]$/,@junseigen) || $c_zokusei[$odeck[$i]] eq "신"){$errflg=2;last;}
			else{next;}
		}
		elsif($seigen==3){
			if($c_zokusei[$odeck[$i]] eq "신" || $odeck[$i]==1156 || $odeck[$i]==1157 || $odeck[$i]==1225){$errflg=3;last;}
		}
		elsif($seigen==4){
			if(grep(/^$odeck[$i]$/,@onekill)){$errflg=4;last;}
		}

		if(grep(/^$odeck[$i]$/,@seigen)){
			$CHK{$odeck[$i]}++;
			if($CHK{$odeck[$i]}>1){$errflg=1;last;}
		}
		elsif(grep(/^$odeck[$i]$/,@junseigen)){
			$CHK{$odeck[$i]}++;
			if($CHK{$odeck[$i]}>2){$errflg=1;last;}
		}
	}
	if($errflg==1){print "유희 「이 방은 공식 제한. 덱을 다시 구축해」";exit;}
	elsif($errflg==2){print "유희 「이 방은 금지 모드. 제한 카드, 준 제한 카드, 신 카드는 사용할 수 없어」";exit;}
	elsif($errflg==3){print "유희 「이 방은 OCG 룰. 듀얼CGI전용 카드는 사용할 수 없다」";exit;}
	elsif($errflg==4){print "유희 「이 방은 비1kill다. 「플레이 방법」의 「제한」을 읽어」";exit;}
	if($#main_deck<39){$tmp=$#main_deck+1;print "페가수스 「Oh~메인 덱이$tmp장, 40장이 over 되도록 덱을 재구축 해~」";exit;}
}

sub cpu_deckmake{
	if($player[2]==9){@{$deck[2]}=@{$deck[1]};@{$yugo[2]}=@{$yugo[1]};}
	else{
		open(CHD,"charadeck2.dat");
		$cou=0;
		while(<CHD>){
			chop($chdst=$_);
			if($cou==$player[2]){last;}
			$cou++;
		}
		close(CHD);
		@odeck=split(/,/,$chdst);
		for($i=0;$i<$#odeck+1;$i++){
			if($c_syokan[$odeck[$i]]==1){push(@{$yugo[2]},$odeck[$i]);}
			else{push(@{$deck[2]},$odeck[$i]);}
		}
		srand;
		for($i=$#{$deck[2]}+1;$i<40;$i++){
			$rann=rand;
			$rann=int($rann * $card_su);
			if($rann==837 || $rann==995){$i--;next;}
			if($c_syokan[$rann] ne ""){$i--;next;}
			if(($c_zokusei[$rann] eq "마" || $c_zokusei[$rann] eq "함정") && !(grep(/^$rann$/,@ava))){$i--;next;}
			if($c_syuzoku[$rann] eq "의식" || $c_syokan[$rann] ne ""){$i--;next;}
			$deck[2][$i]=$rann;
		}
	}
}

sub deckfile{
	$uno=$_[0];
	if($match eq "on"){
		if($P{'deck'} eq ""){$P{'deck'}=join(",",@defo);}
		open(DEF,"> tmp/".$roomst.$room."_deck".$uno);
		print DEF "deck\t$P{'deck'}\nside\t$P{'side'}\n";
	}
}

sub start_m{
	if($syori[0]!~/^5/ || $syori[0] eq "5".$u_side){return;}

	&get_ini2;
	unlink("tmp/".$roomst.$room."_log");

	&chk_deck;
	@{$deck[$u_side]}=@main_deck;
	@{$yugo[$u_side]}=@yugo_deck;
	$t_logcou[$u_side]=0;
	$t_surr[$u_side]=0;
	undef(@tehuda);

	$syori[0].=$u_side;
	&put_ini;
	if(length($syori[0])<3){return;}

	undef(@a_m);undef(@a_b);undef(@fld_koka);undef(@hk);undef(@chain);undef(@chain2);
	undef(@fld);undef(@fld_rf);undef(@fld_ad);undef(@jok);
	undef(@call);undef(@boti);
	undef(@syori);
	$turn2=2-(($turn2+$turn) % 2);
	&start2;
}

sub get_min{
	@daysu=(0,0,31,59,90,120,151,181,212,243,273,304,334,365);
	local($dat)=$_[0];
	$tmp=substr($dat,6,2);
	$tmp+=substr($dat,4,2)*60;
	$tmp+=substr($dat,2,2)*60*24;
	$tmp+=$daysu[substr($dat,0,2)]*60*24;
	$tmp+=substr($dat,8,2)*60*24*365;
	return $tmp;
}

sub tehuda_draw{
	local($l_side)=$_[0];
	local($maisu)=$_[1];
	local($method)=$_[2];
	local($tsno,$t_i);
	if($maisu==0){return;}

	$errflg=0;
	$tsno=$sno[$l_side];
	for($t_i=0;$t_i<$maisu;$t_i++){
		if($#{$deck[$tsno]}<0){
			&add_msg("null","$pn[$tsno]의 산표가 바닥났다! ");
			$lp[$tsno]=0;
			&end_game;
		}
		$tehuda[$tsno][$#{$tehuda[$tsno]}+1] = shift(@{$deck[$tsno]});

		if($hk[$tsno-1] ne ""){
			$tmpno=$tehuda[$tsno][$#{$tehuda[$tsno]}];
			if($turn-$hk[$tsno-1]>4){$hk[$tsno-1]="";}
			elsif($c_ap[$tmpno]>=1500 || $c_ap[$tmpno]=~/^X/){
				&add_msg("null","<b>바이러스의 효과로$c_name[$tmpno]소멸! </b>");
				&go_boti2($#{$tehuda[$tsno]},$l_side,1);
				$errflg=1;
			}
			else{&add_msg("null","!$s_d($c_name[$tmpno]은(는) 바이러스 대상밖)");}
		}
	}

	if($kok[$tsno][12] ne ""){
		&add_msg("null","<b>하나님의 베품! </b>");
		&lp_up(500,$kok[$tsno][12],$l_side);
	}
	if($phase!=0){
		if($kok[3-$tsno][72] ne ""){push(@chain2,"$sno[1-$l_side]-5-885-$kok[3-$tsno][72]");}
		if($method!=1 && $errflg!=1){&binjo_chk(1-$l_side);}
	}

	return $errflg;
}

sub deck_to_boti{
	local($l_side)=$_[0];
	local($maisu)=$_[1];
	$tsno=$sno[$l_side];

	undef(@sutehuda);
	for($t_i=0;$t_i<$maisu && $t_i<$#{$deck[$tsno]}+1;$t_i++){
		push(@sutehuda,$deck[$tsno][$t_i]);
		$deck[$tsno][$t_i]="";
	}
	&del_null(*deck,$tsno);
	&arr_to_boti(*sutehuda,$l_side);
}

sub arr_to_boti{
	local(*arr) = @_;
	local($l_side)=$_[1];
	local($kuju)=$_[2];
	local($cardno);
	$tsno=$sno[$l_side];

	$penguin_flg="";
	for($t_i=0;$t_i<$#arr+1;$t_i++){
		$cardno=$arr[$t_i];
		if($kok[0][14] ne ""){
			&add_msg("null","$c_name[$cardno]은(는) 빛의 저 멀리 추방되었다! ");
		}
		else{
			if($c_syokan[$cardno] ne "" && $c_syokan[$cardno]!=6 && $c_zokusei[$cardno] ne "함정"){$cardno.="_i";}
			push(@{$boti[$tsno]},$cardno);
			&maryoku(19,$l_side);
			if($c_koka[$cardno]==10){push(@chain2,"$tsno-5-$cardno");}
			if($cardno==778){$penguin_flg=1;}
		}
	}
	if($penguin_flg==1 && $kuju eq ""){push(@chain2,"$tsno-5-778");}
}

sub go_boti{
	local($fldno)=$_[0];
	local($method)=$_[1];
	local($k_muko)=$_[2];
	local($aiteflg)=$_[3];
	local($cardno,$l_side,$i,$koka_bak,$warea,$tsno);

	$cardno=$fld[$fldno];
	if($cardno eq ""){return;}

	if($method==2){
		if($fld_koka[$fldno]=~s/guard<>//){&add_msg("null","<b>매직 가이드! </b><br>$c_name[$cardno]대신에 가드너가 파괴되었다. ");return;}
		elsif($cardno==1191){&add_msg("null","<b>얼룩짐 상어 불사의 요력! </b><br>파괴되지 않고 필드에 머물었다! ");return;}
	}
	elsif($method==5 && $fld_koka[$fldno]=~/meikyo/ && $kok[0][8] eq ""){&add_msg("null","<b>명경지수! </b>　파괴되지 않고 필드에 머물었다! ");return;}

	$l_side=&which_side($fldno);
	$tsno=$sno[$l_side];
	$warea=$which_area;
	$koka_bak=$fld_koka[$fldno];

	if($method==4 && &syu_st($fldno) eq "드래곤"){
		$l_side2=&which_side($fldno,1);
		$jok[4+$sno[$l_side2]]++;
	}
	&syometu($fldno,$in_proc);

	if($fldno eq $hk[13]){$hk[13]=999;}
	if($cardno==826){&find_koka;}
	if($c_syokan[$cardno]==5){}
	elsif($kok[0][14] ne ""){
		&add_msg("null","$c_name[$cardno]은 빛의 저 멀리 추방되었다! ");
	}
	else{
		$botiiki=1;

		if($cardno==638 || $cardno==375 || $cardno==1064 || ($cardno==1223 && $method!=1 && $method!=4) || $cardno==735 || $cardno==1019 || $c_koka[$cardno]==5 || $c_koka[$cardno]==10 || ($c_koka[$cardno]==15 && $method==1) || (($cardno==1200 || $cardno==1192) && $method==2 && $koka_bak=~/f_\d+:/) || $cardno==373 || $cardno==835){
			if($k_muko ne ""){
				&add_msg("null","<b>$c_name[$cardno]은(는)$mukomsg[$k_muko]</b>");
				if($cardno==735 || $cardno==1019){$cardno.="_a";}
			}
			elsif($cardno==638 || $cardno==375 || $cardno==735){}
			elsif(($cardno==973 || $cardno==797) && $in_proc==1){}
			elsif($cardno==1174 && $method==4){}
			elsif($c_zokusei[$cardno] ne "마" && $c_zokusei[$cardno] ne "함정" && &kinsi_chk2($fldno)){}
			elsif($cardno==1064 || $cardno==1223){
				$l_side2=&which_side($fldno,1);
				if($l_side==$l_side2 && $warea==1 && ($l_side==1 || $method==1 || $aiteflg==1) && $aiteflg!=2){
					if($cardno==1064){
						&add_msg("인형","<b>기햐햐햐…</b>");
						&add_msg("null","개방된 영혼이 필드를 헤맨다...");
						$hk[8+$tsno]++;
					}
					else{
						&add_msg("뱀파이어","<i>나는 죽어도도 소생한다...</i>");
						$hk[27+$tsno]++;
					}
				}
			}
			else{push(@chain2,"$tsno-5-$cardno-$koka_bak");}
		}

		if($koka_bak=~/irr<>/){$cardno.="_i";}
		push(@{$boti[$tsno]},$cardno);
		&maryoku(19,$l_side);
		if($c_zokusei[$cardno] ne "마" && $c_zokusei[$cardno] ne "함정"){&maryoku(56,$l_side);}

		if($warea==1 && $tsno==$turn2){
			$jok[2]=$cardno;
			for($i=0;$i<$hk[14];$i++){push(@syori,"2<>i-$tsno<>o-사용::사용안함<>m-유언장의 효과를 사용할까요? <>n-yuigon_chk<>g-1");}
			$hk[14]="";
		}
	}

	if($c_koka[$cardno]==8 && $method!=3){
		if($k_muko ne ""){&add_msg("null","<b>$c_name[$cardno]은(는)$mukomsg[$k_muko]</b>");}
		elsif($cardno==899){&maiso($koka_bak);}
		else{push(@chain2,"$tsno-5-$cardno-$koka_bak");}
	}
}

sub syometu{
	local($i,$cardno,$koka_bak,$l_side,@koka_tmp,$j);
	local($fldno)=$_[0];

	$cardno=$fld[$fldno];
	$fld[$fldno]="";
	$l_side=&which_side($fldno);

	$koka_bak = $fld_koka[$fldno];
	$fld_koka[$fldno] = "";
	$a_m[$fldno] = "";
	$a_b[$fldno] = "";

	if($koka_bak ne ""){
		@koka_tmp=split("<>",$koka_bak);
		for($j=0;$j<$#koka_tmp+1;$j++){
			if($koka_tmp[$j]=~/^f_(\d+)::(\d+)/){
				if($fld_koka[$1] ne ""){&del_koka($1,$2);}
			}
			elsif($koka_tmp[$j]=~/^f_(\d+)/){&go_boti($1);}
		}
	}

	if($c_koka[$cardno]==11){
		$tsno=$sno[$l_side];
		if($cardno==873){&maiso($koka_bak,1);}
		else{push(@chain2,"$tsno-5-$cardno-".$koka_bak);}
	}
	if($koka_chk{$cardno} ne ""){&find_koka;}
}

sub return_deck{
	local($cardno)=$_[0];
	local($i);
	for($i=0;$i<$#{$boti[$s_a]}+1;$i++){
		if($boti[$s_a][$i]==$cardno){$boti[$s_a][$i]="";last;}
	}
	&del_null(*boti,$s_a);
	unshift(@{$deck[$s_a]},$cardno);
}

sub return_tehuda2{
	local($fldno)=$_[0];
	local($peng2)=$_[1];

	if($fld_rf[$fldno]==1){&add_msg("null","세트 몬스터를 패에 되돌렸다. ");}
	else{&add_msg("null","$c_name[$fld[$fldno]]을(를) 패에 되돌렸다. ");}
	&return_tehuda($fldno,0,$peng2);
}

sub return_tehuda{
	local($fldno)=$_[0];
	local($mode)=$_[1];	#1-덱에
	local($peng2)=$_[2];
	local($cardno,$l_side,$i);

	$cardno=$fld[$fldno];
	if($cardno eq ""){return;}
	$l_side=&which_side($fldno);
	$tsno=$sno[$l_side];

	if($cardno==1167 && $mode==1 && $fld_rf[$fldno]!=1){push(@chain2,"$tsno-5-1167");}
	&syometu($fldno);

	if($c_syokan[$cardno]==5 && $c_zokusei[$cardno] ne "함정"){}
	elsif($c_syokan[$cardno]==1 && $c_zokusei[$cardno] ne "함정"){push(@{$yugo[$tsno]},$cardno);}
	elsif($mode==1){push(@{$deck[$tsno]},$cardno);}
	else{
		push(@{$tehuda[$tsno]},$cardno);
		if($c_zokusei[$cardno] ne "마" && $c_zokusei[$cardno] ne "함정" && $peng2!=1){
			for($i=0;$i<2;$i++){
				if($kok[$sno[$i]][63] ne ""){&add_msg("null","<b>엘리먼트의 샘! </b>");&lp_up(500,$kok[$sno[$i]][63],$i);}
			}
		}
	}
}

sub go_boti2{
	local($i)=$_[0];
	local($l_side)=$_[1];
	local($method)=$_[2];
	local($method2)=$_[3];
	local($cardno);
	$tsno=$sno[$l_side];

	$cardno=$tehuda[$tsno][$i];
	$tehuda[$tsno][$i]="";
	if($cardno eq ""){return;}
	if($c_syuzoku[$cardno] eq "드래곤"){$jok[4+$s_a]++;}

	if($tep[$tsno][$i] ne ""){$tsno=3-$tsno;}

	if($kok[0][14] ne ""){
		&add_msg("null","$c_name[$cardno]은 빛의 저 멀리 추방되었다! ");
	}
	else{
		push(@{$boti[$tsno]},$cardno);
		if($c_syokan[$cardno] ne "" && $c_syokan[$cardno]!=6 && $c_zokusei[$cardno] ne "함정"){$boti[$tsno][$#{$boti[$tsno]}].="_i";}
		&maryoku(19,$l_side);
		if($c_koka[$cardno]==10 || (($cardno==779 || $cardno==780) && $method==2)){
			if($cardno==973 && $in_proc==1){}
			else{push(@chain2,"$tsno-5-$cardno");}
		}
	}
	if($cardno==1223 && $method==1 && $tsno==$sno[$l_side]){
		&add_msg("뱀파이어","<i>나는 죽어도 소생한다...</i>");
		$hk[27+$tsno]++;
	}
	if($method2==1){&binjo_chk($l_side,1);}
	if($method!=1 && $method!=3 && $kok[$tsno][73] ne ""){push(@chain2,"$tsno-5-886-$kok[$tsno][73]");}
}

sub del_koka{	#fldi의$kono번째 의 효과를 삭제
	local($fldi) = $_[0];
	local($kono) = $_[1];
	local($i,@tmp,@tmp2);
	@tmp=split("<>",$fld_koka[$fldi]);
	for($i=0;$i<$#tmp+1;$i++){
		if($i==$kono){$tmp[$i]="";}
	}
	$fld_koka[$fldi]=join("<>",@tmp);
	if($fld_koka[$fldi] ne ""){$fld_koka[$fldi].="<>";}
}

sub battle_run0{			#배틀 사전 처리
	local($mode)=$_[0];

	if($fld[$b_fld[0]] eq ""){return 1;}
	if($b_fld[1] ne "player" && $fld[$b_fld[1]] eq ""){return 1;}
	if($a_b[$b_fld[0]]==1 || ($fld_ad[$b_fld[0]]==1 && $fld[$b_fld[0]]!=718)){return 1;}

	$b_mst[0]=$fld[$b_fld[0]];$b_nam[0]=$c_name[$b_mst[0]];
	if($b_fld[1] ne "player"){$b_mst[1]=$fld[$b_fld[1]];$b_nam[1]=$c_name[$b_mst[1]];}
	else{$b_mst[1]="";$b_nam[1]="플레이어";}

	if($hk[13] ne ""){&add_msg("null","!$s_a(이 턴 배틀페이즈는 실시할 수 없다)");return 1;}

	if(&fisher($b_fld[0])){}
	else{
		if($kok[$s_d][0] ne ""){&add_msg("null","!$s_a공격은 봉쇄되고 있다! ");return 1;}
		if($fld_koka[$b_fld[0]]=~/jukon/ && $kok[0][8] eq ""){&add_msg("null","!$s_a주혼의 가면이 씌여지고 있다! ");return 1;}
		if($kok[0][11] ne "" && $ap_fld[$b_fld[0]]>=1500 && $mode==1){&add_msg("null","!$s_a평화의 사자에 의해 공격이 봉쇄되었다! ");return 1;}
		if($fld_koka[$b_fld[0]]=~/dust/ && $kok[0][8] eq ""){&add_msg("null","!$s_a블랙 더스트에 시달리고 있다! ");return 1;}
		if($kok[$s_d][46] ne "" && &syu_st($b_fld[0]) eq "곤충"){&add_msg("null","!$s_a(제충 장벽에 걸렸다! )");return 1;}
		if((($c_syokan[$b_mst[0]]==4  && $b_mst[0]!=1213) || $kok[0][45] ne "") && $a_m[$b_fld[0]]==1){
			&add_msg("null","!$s_a(소환한 턴에는 공격할 수 없다)");return 1;
		}

		if($c_syokan[$b_mst[0]]==4 && ($b_fld[1] eq "player" || $c_syokan[$b_mst[1]]!=4)){
			for($i=$fw1[$s_d];$i<$fw1[$s_d]+5;$i++){
				if($c_syokan[$fld[$i]]==4){$last;}
			}
			if($i<$fw1[$s_d]+5){&add_msg("null","!$s_a(상대의 장소에도 트가 있는 경우는 , 트 밖에 공격할 수 없어)");return 1;}
		}
	}

	if($kok[0][5] ne "" && &lv_st($b_mst[0])>3){&add_msg("null","!$s_a그라비티·바인드의 압력으로 공격할 수 없다! ");return 1;}
	if($kok[0][9]>1 || ($kok[0][9]==1 && $b_mst[0]!=953)){&add_msg("null","!$s_a<b>천안 주박! </b><br>공격도 표시 변경도 할 수 없다! ");return 1;}
	if($fld_koka[$b_fld[0]]=~/rokubo/ && $kok[0][7] eq ""){&add_msg("null","!$s_a주박을 걸치고 있다! ");return 1;}
	if($hk[19] ne "" && $mode==1 && $b_fld[1] ne "player" && $fld_rf[$b_fld[1]]==1){&add_msg("null","!$s_a이 턴 세트 몬스터에게는 공격할 수 없다! ");return 1;}
	if(($kok[$s_d][52]>1 || ($kok[$s_d][52]==1 && $b_mst[1]!=1123)) && $b_fld[1] ne "player" && &syu_st($b_fld[1]) eq "전사"){&add_msg("null","!$s_a절삭 깊이 대장이 가로막았다! ");return 1;}

	if($b_mst[0]==1069){if($b_fld[1] eq "player"){&add_msg("null","!$s_a(좀바이어는 직접 공격할 수 없어)");return 1;}}
	elsif($b_mst[0]==1139){if($b_fld[1] eq "player" && $a_b[$b_fld[0]]==2){&add_msg("null","!$s_a(상대의 장소에 몬스터가 없으면 2회 공격할 수 없다)");return 1;}}
	elsif($b_mst[0]==1145){
		for($i=$fw1[$s_a];$i<$fw1[$s_a]+5;$i++){if($i!=$b_fld[0] && &syu_st($i) eq "드래곤"){last;}}
		if($i==$fw1[$s_a]+5){&add_msg("null","!$s_a(그 밖에 드래곤족이 없으면 공격할 수 없어)");return 1;}
	}
	elsif($b_mst[0]==1176){if($b_fld[1] ne "player"){&add_msg("null","!$s_a(플레이어에게 직접 공격 밖에 할 수 없다)");return 1;}}
	elsif($b_mst[1]==1160){if($fld_rf[$b_fld[1]]!=1 && &maisu_count(1)>1){&add_msg("null","!$s_a(커멘드·나이트는 다른 몬스터의 그늘에 숨는다)");return 1;}}
	elsif(&fisher($b_fld[1])==2){&add_msg("null","!$s_a<b>시·스텔스II! </b>　피셔 맨은 바다에 기어들었다. ");return 1;}
	elsif($b_mst[0]==1183){
		$tmp=$a_b[$b_fld[0]];$tmp=~s/p$//;
		if($tmp ne "" && $b_fld[1] eq "player"){&add_msg("null","!$s_a(이미 몬스터에게 공격하고 있다)");return 1;}
		@tmp2=split(/<>/,$tmp);
		if(grep(/^$b_fld[1]$/,@tmp2)){&add_msg("null","!$s_a(이 몬스터에게는 공격이 끝난 상태다)");return 1;}
	}


	if($kok[0][39] ne ""){
		for($i=$fw1[$s_d];$i<$fw1[$s_d]+5;$i++){if($fld_koka[$i]=~/jiryoku/ && !(&fisher($i))){last;}}
		if($i<$fw1[$s_d]+5 && $fld_koka[$b_fld[1]]!~/jiryoku/){&add_msg("null","!$s_a(자력의 반지가 발동하고 있다! )");return 1;}
	}

	if(&kinsi_chk2($b_fld[0])){return 1;}

	if($kok[0][34] ne "" && $jok[0] ne "" && $a_b[$b_fld[0]] eq ""){&add_msg("null","!$s_a암흑의 문이 있는 한 , 1체의 몬스터 밖에 공격할 수 없다! ");return 1;}

	if($b_fld[1] eq "player"){
		if($b_mst[0]==755){
			for($i=$fw1[$s_d];$i<$fw1[$s_d]+5;$i++){if($fld[$i] ne "" && $fld_rf[$i]!=1 && ($tmp=$c_zokusei[$fld[$i]]) ne "땅" && $tmp ne "물" && $tmp ne "바람"){last;}}
			if($i<$fw1[$s_d]+5){&add_msg("null","!$s_a(땅.물.바람 이외의 몬스터가 있을거야)");return 1;}
		}
		elsif($c_syokan[$b_mst[0]]==4 || $c_koka[$b_mst[0]]==13){}
		else{
			for($i=$fw1[$s_d];$i<$fw1[$s_d]+5;$i++){if($fld[$i] ne "" && !(&fisher($i))){last;}}
			if($i<$fw1[$s_d]+5){&add_msg("null","!$s_a(벽 몬스터가 있을거야)");return 1;}
		}
	}

	0;
}

sub battle_run{			#공격 선언

	local($i);
	if(&battle_run0(1)){return;}

	if($a_b[$b_fld[0]] eq "" || $a_b[$b_fld[0]]!~/p$/){
		if($c_koka[$b_mst[0]]==6){if(&use_koka_6){return;}}
		if($c_syokan[$b_mst[0]]==4 && $b_mst[0]!=1213){
			if($cpu[$s_a]==1 && $lp[$s_a]<=500){return;}
			&add_msg("null","LP를 500포인트 지불 --");
			$lp[$s_a]-=500;&chk_lp;
		}
		if($kok[0][20] ne ""){
			$tmp=$kok[0][20]*500;
			if($lp[$s_a]<=$tmp){&add_msg("null","!$s_a(통행세를 지불할 수가 없다)");return;}
			&add_msg("null","<b>$pn[$s_a]은$tmp의 통행세를 지불했다! </b>");
			$lp[$s_a]-=$tmp;
		}
		if($kok[$s_d][18] ne ""){
			&add_msg("null","<b>묘수의 사용마가$pn[$s_a]의 덱로부터$kok[$s_d][18]장 빼앗는다! </b>");
			if($#{$deck[$s_a]}+1<$kok[$s_d][18]){
				&add_msg("null","<b>$pn[$s_a]의 산표가 바닥났다!</b>");
				$lp[$s_a]=0;&chk_lp;
			}
			&deck_to_boti(0,$kok[$s_d][18]);&del_null(*deck,$s_a);
		}
		$a_b[$b_fld[0]].="p";
	}

	&add_msg("null","<b>---------배틀! ---------</b>");

	if($b_fld[1] eq "player"){&add_msg("null","$pn[$s_a]「$b_nam[0]의 다이렉트·어택!」");}
	else{
		if($b_mst[0]==742 && $player[$s_a]==10){&add_msg("null","$pn[$s_a]「<b>여왕 마마의 공격! </b>」");}
		else{&add_msg("null","$pn[$s_a]「$b_nam[0]의 공격!」");}
	}

	if($a_m[$b_fld[0]]!=1){$a_m[$b_fld[0]]=2;}
	if($hk[34]!=1){&change_phase(3);}
	$jok[0]=1;
	$bstep="$b_fld[0]-$b_fld[1]";

	$chudan="$s_a-3-$b_fld[0]-$b_fld[1]";
	if(&trap_check(1)){$F{'battle'}="";return;}

	if($chain[0].$syori[0].$chain2[0] eq ""){$battle_zokkou=1;&battle_run2;}
}

sub b_step_koka{
	local($i);
	for($i=0;$i<4;$i++){
		if($bstk[$i] ne "" && $bstk[$i] ne "999"){
			$bfbak=$b_fld[1];
			$b_fld[1]=$bstk[$i];$b_mst[1]=$fld[$b_fld[1]];$b_nam[1]=$c_name[$b_mst[1]];
			if($i==0){&add_msg("null","<b>디펜드·슬라임 발동! </b><br>리바이벌 슬라임이 대신으로 되었다! ");}
			elsif($i==1){&add_msg("null","<b>고귀한 지령! </b><br>$b_nam[1]에 공격 대상을 변경! ");}
			elsif($i==2){&add_msg("null","<b>램프가 공격을 반사! </b><br>공격은$b_nam[1]에! ");$mlamp=1;$fld_rf[$bfbak]="";$bstk[2]=999;}
			elsif($i==3){&add_msg("null","<b>요정은 환영이었다! </b><br>공격 대상은$b_nam[1]! ");}
			$bstk[0]=999;$bstk[1]=999;
		}

		elsif($bstk[$i] eq ""){
			if($i==0 && ($kok[$s_d][26] eq "" || $b_fld[1] eq "player")){$bstk[$i]=999;next;}
			elsif($i==1 && $kok[$s_d][65] eq ""){$bstk[$i]=999;next;}
			elsif($i==2 && ($b_mst[1]!=1031 || $fld_rf[$b_fld[1]]!=1)){$bstk[$i]=999;next;}
			elsif($i==3 && $b_mst[1]!=1068){$bstk[$i]=999;next;}

			if($i==0){$seast="901901";$jokenst='$cardno==975 && $res_si ne "'.$b_fld[1].'"';}
			elsif($i==1 || $i==3){$seast="991901";$jokenst='$res_si ne "'.$b_fld[1].'"';}
			elsif($i==2){$seast="99191";$jokenst='$res_si ne "'.$b_fld[0].'"';}
			&card_search;
			if($#res_s<0){$bstk[$i]=999;}
			else{
				&add_msg("null","!$s_d($b_nam[1]을(를) 노리고 있을거야)");
				if($i==0){$tmp_syorip="<>m-대신 하는 슬라임을 선택해 줘. <>o-대신 한다::대신 하지 않는다";$seast="90191";}
				elsif($i==1 || $i==3){$tmp_syorip="<>m-공격 대상을 선택해 줘. <>o-변경한다::변경안한다";$seast="99191";}
				elsif($i==2){$tmp_syorip="<>m-공격의 반사처를 선택해 줘. <>o-반사한다::반사안한다";$seast="991901";}
				&bstk_sel;return 1;
			}
		}
	}

	0;
}

sub bstk_sel{
	$tmp="";
	for($j=0;$j<$#bstk+1;$j++){$tmp.=$bstk[$j]."-";}
	$tmp_syorip.="<>n-bstk<>i-$s_d<>g-1<>l-1<>c-3-$b_fld[0]-$b_fld[1]-$tmp<>p-$i";
	&go_select_syori;
}

sub battle_run2{

	if($tinmoku ne ""){}
	else{
		if($battle_zokkou!=1){if(&battle_run0(2)){$bstep="";return;}}
		if(&b_step_koka){return;}
		undef(@bstk);
	}
	$a_b[$b_fld[0]]!~s/p$//;
	undef($bstep);

	if($kok[$s_d][10] ne "" && $fld_koka[$b_fld[0]]!~/mirror/){
		&add_msg("null","<b>밀러 월 발동! </b><br>거울에 비친 자신을 공격!　공격력은 반감한다! ");
		$ap_fld[$b_fld[0]]=int($ap_fld[$b_fld[0]]/2);
		$fld_koka[$b_fld[0]].="mirror<>";
	}
	for($i=0;$i<$kok[$s_d][41];$i++){
		&add_msg("null","<b>몬스터 BOX 발동! </b>");
		$rann=rand;$rann=int($rann*2);
		if($rann==0){&add_msg("null","공격은……명중! ");}
		else{
			&add_msg("null","공격은……변두리! <br><b>대상을 잃었다$c_name[$b_mst[0]]는 공격력이 0에! </b>");
			$ap_fld[$b_fld[0]]=0;$fld_koka[$b_fld[0]].="mon_box<>";$jok[1]=1;
			last;
		}
	}
	if($reflection==1){$ap_fld[$b_fld[0]]=0;$reflection="";}

	if($fld_koka[$b_fld[0]]=~/metalka/ && $b_fld[1] ne "player" && $kok[0][7] eq ""){
		$cou=&juhuku_cou($fld_koka[$b_fld[0]],"metalka");
		$tmp=int($ap_fld[$b_fld[1]]/2);
		for($i=0;$i<$cou;$i++){
			&add_msg("null","<b>마법 반사 장갑 발동! </b><br>$b_nam[1]의 공격력의 반 ,$tmp이 반사된다! ");
			$ap_fld[$b_fld[0]]+=$tmp;
		}
	}

	if($hk[5] ne ""){$mul=-1;}else{$mul=1;}
	for($i=0;$i<2;$i++){
		$i2=1-$i;
		if($b_mst[$i]==1171 && $fld_koka[$b_fld[$i]]=~s/used//){
			&add_msg("null","라이프를2000지불해 --<br><b>릴리는 주사기를 찔렀다! </b>");
			$lp[$sno[$i]]-=2000;&chk_lp;
			$ap_fld[$b_fld[$i]]+=3000*$mul;
			next;
		}
		if($b_fld[$i2] eq "player"){next;}

		if($b_mst[$i]==1102 && &syu_st($b_fld[$i2]) eq "전사"){
			&add_msg("null","<b>스카우타 발동! </b>");
			$ap_fld[$b_fld[$i]]+=2000*$mul;$dp_fld[$b_fld[$i]]+=2000*$mul;
		}
		elsif($b_mst[$i]==1159 && $c_zokusei[$b_mst[$i2]] eq "어둠"){
			&add_msg("null","<b>태양의 빛이 어둠을 관철한다! </b>");
			$ap_fld[$b_fld[$i]]+=500*$mul;
		}
		elsif($b_mst[$i]==1129 && $fld_koka[$b_fld[$i]]=~/hunter_(\d+)/ && $syu_arr[$1] eq $c_syuzoku[$b_mst[$i2]]){
			&add_msg("null","<b>$syu_arr[$1]족은 헌터의 사냥감이다! </b>");
			$ap_fld[$b_fld[$i]]+=1000;
		}
	}

	$b_ptr[0]=$ap_fld[$b_fld[0]];if($b_ptr[0]<0){$b_ptr[0]=0;}
	if($b_fld[1] ne "player"){
		$tmpstr="$b_nam[0]　공격력：$b_ptr[0]　VS　$b_nam[1]　";
		if($fld_ad[$b_fld[1]]==0){
			$battle_kind=0;
			$b_ptr[1]=$ap_fld[$b_fld[1]];
			$tmpstr.="공격력：$ap_fld[$b_fld[1]]";
		}
		else{
			$battle_kind=1;
			$b_ptr[1]=$dp_fld[$b_fld[1]];
			$tmpstr.="수비력：$dp_fld[$b_fld[1]]";
		}
		&add_msg("null",$tmpstr);
	}

	$wazast="";
	if($b_nam[0] eq "오벨리스크의 거신병" && $player[$s_a]==2){$wazast.="<b>카이바 「죽을 수 있는 충 케라모두!」</b><br>";}
	if(($tmp=$waza{$b_mst[0]}) ne ""){$wazast.="<b>「$tmp」</b>";}
	if($b_nam[0] eq "정안의 흰색용" && $player[$s_a]==7){$wazast.="<br>카이바 「분쇄!　옥쇄!　대갈채 -!」";}
	if($wazast ne ""){&add_msg("null",$wazast);}

	$damage="";$dam_side=9;
	$botiiki[0]="";$botiiki[1]="";

	if($b_fld[1] eq "player"){		#직접 공격
		if($c_syokan[$b_mst[0]]==4 && $b_mst[0]!=1213){&add_msg("트","<b>트 ~~~·어택! </b>");}
		if($b_ptr[0]>0){$damage=$b_ptr[0];$dam_side=1;}
		&battle_run3;
		if($c_syokan[$b_mst[0]]==4 && $b_mst[0]!=1213){
			&add_msg("트","<b>개하하하하! </b>");
			if($player[$s_a]==5){&add_msg($pn[$s_a],"잇트미라크루! ");}
		}
	}
	else{
		if(&sfia){}
		elsif($b_ptr[0]>$b_ptr[1] && $battle_kind==0){
			&add_msg("null","$b_nam[1](을)를 격파! ");
			$damage=$b_ptr[0]-$b_ptr[1];$dam_side=1;
			$botiiki[1]=$b_fld[1];
		}
		elsif($b_ptr[0]==$b_ptr[1] && $battle_kind==0 && $b_ptr[0]>0){
			&add_msg("null","맞받아침! <br>서로의 카드가 소멸! ");
			$botiiki[0]=$b_fld[0];
			$botiiki[1]=$b_fld[1];
		}
		elsif($b_ptr[0]<$b_ptr[1] && $battle_kind==0){
			$damage=$b_ptr[1]-$b_ptr[0];$dam_side=0;
			&add_msg("null","패배! ");
			$botiiki[0]=$b_fld[0];
		}
		elsif($b_ptr[0]>$b_ptr[1] && $battle_kind==1){
			&add_msg("null","$b_nam[1]을(를) 격파! ");
			$botiiki[1]=$b_fld[1];
			&meteo;
		}
		elsif($b_ptr[0]<$b_ptr[1] && $battle_kind==1){
			$damage=$b_ptr[1]-$b_ptr[0];$dam_side=0;
			&add_msg("null","공격은 연주해 돌려주어졌다! ");

			if($counter_panch ne ""){
				&add_msg($pn[$s_d],"<b>함정 카드 발동!　「카운터 펀치」! </b>");
				$use_f_no=$counter_panch;$use_cno=1090;&end_usecard(0);
				if($kok[0][7] ne ""){&add_msg("null","<b>그러나 , 함정의 효과는 무효! </b>");}
				else{
					&add_msg("null","카운터 작렬! <br><b>$c_name[$b_mst[0]]을(를) 파괴! </b>");
					&go_boti($b_fld[0]);$counter_panch="";
				}
			}
			if($player[$s_d]==10){&add_msg("사마준","헛됨 표! ");}
		}
		else{
			&add_msg("null","무승부! ");
		}

		&battle_run3;
	}

	if($fld[$b_fld[0]] ne ""){&a_b_chg($b_fld[0]);}
	&add_msg("null","<b>--------------------------</b>");
	&chk_lp;

	undef($mlamp);
	if($fld[$b_fld[0]]==921){$jok[1]=1;}
	elsif($fld[$b_fld[0]]==1140){
		$fld_ad[$b_fld[0]]=1;
		&add_msg("null","$c_name[$b_mst[0]]은(는) 수비 표시로 바뀐다! ");
	}
	if($fld[$b_fld[1]]==1026){
		$fld_ad[$b_fld[1]]=0;
		&add_msg("null","$c_name[1026]은(는) 공격 표시로 바뀐다! ");
	}

	if($hk[34]==1){$hk[34]=2;$a_b[$b_fld[0]]="";}

	&get_apdp_fld;
}

sub a_b_chg{
	local($fno)=$_[0];

	if(($fld[$fno]==933 || $fld[$fno]==1139 || ($fld[$fno]==1146 && $fld_koka[$fno]=~/used_$turn/)) && $a_b[$fno] eq ""){$a_b[$fno]=2;}
	elsif($fld[$fno]==1183 && $b_fld[1] ne "player"){
		if($a_b[$b_fld[0]] eq ""){$a_b[$fno]="2<>";}
		if($fld[$b_fld[1]] ne ""){$a_b[$fno].=$b_fld[1]."<>";}
	}
	else{$a_b[$fno]=1;}
}

sub sfia{
	if(($b_mst[1]==704 || $b_mst[1]==908) && $fld_rf[$b_fld[1]]==1 && $fld_ad[$b_fld[1]]==1){}
	else{return;}

	&fld_chk(1);
	if($nf1<0){return;}
	&syometu($b_fld[1]);
	$fld[$nf1]=$b_mst[1];$fld_rf[$nf1]=0;
	if($b_mst[1]==704){
		&add_msg("null","<b>스피아·폭탄 장착! </b><br>$pn[$s_a]의 스텐바이페이즈에 폭발한다! ");
		&soubi($b_fld[0],$nf1,"_sfia");
	}
	else{
		&add_msg("null","<b>정신 기생체가 기생했다! </b>");
		&soubi($b_fld[0],$nf1,"_kisei");
	}
	1;
}

sub meteo{
	if($b_mst[0]==932){&add_msg("null","<b>검각짐승은 맹진했다! </b>");}
	elsif($b_mst[0]==1140){&add_msg("null","<b>스피아·드래곤은 창을 찔렀다! </b>");}
	elsif($b_mst[0]==1173){&add_msg("null","<b>파시아스는 검을 찔렀다! </b>");}
	elsif($b_mst[0]==1212 && $fld_koka[$b_fld[0]]=~/used/){&add_msg("null","<b>이그자리온은 창을 찔렀다! </b>");}
	elsif($fld_koka[$b_fld[0]]=~/meteo/ && !(&fisher($b_fld[0])) && $kok[0][8] eq ""){&add_msg("null","<b>날씨·스트라이크! </b>");}
	elsif($kok[$s_a][57] ne "" && &syu_st($b_fld[0]) eq "드래곤"){&add_msg("null","<b>용의 노여움! </b>");}
	elsif($fld_koka[$b_fld[0]]=~/laser/ && $kok[0][8] eq ""){&add_msg("null","<b>레이저가 적을 관통! </b>");}
	else{return;}

	$damage=$b_ptr[0]-$b_ptr[1];$dam_side=1;
}

sub battle_run3{		#데미지 스텝
	local($i,$i2);
	if($b_mst[0]==929 && ($dam_side eq "0" || $botiiki[0] ne "")){
		&add_msg("null","<b>무적 모드! </b>");
		$botiiki[0]="";$dam_side=9;
	}

	if($mlamp ne "" && $dam_side==1){$dam_side=0;}
	if($hk[34]==1){$dam_side=9;}

	for($i=0;$i<2;$i++){
		if($hk[2+$sno[$i]] ne "" && ($dam_side eq $i || $botiiki[$i] ne "")){
			&add_msg("null","<b>화목의 사자! </b><br>$pn[$sno[$i]]의 전투 데미지는 무효! ");
			$dam_side=9;$botiiki[$i]="";
		}
	}

	if($dam_side==1){
		if($not_damage==1){
			&add_msg("크리보","<b>크리 ~! </b>");
			&add_msg("null","<b>크리보 기계수뢰화! <i>(BOM! )</i></b><br> 유폭!　데미지는$pn[$s_d]까지 닿지 않는다! ");
			$not_damage="";$dam_side=9;
			if($player[$s_a]==2 && $room eq ""){&add_msg($pn[$s_a],"구…　이 자코들이…");}
		}
		elsif($kok[$s_d][61] ne ""){
			&add_msg("null","<b>맹렬한 회오리 해류벽! </b>　$pn[$s_d]의 데미지는 무효! ");
			$dam_side=9;
		}
	}

	undef(@muko);
	for($i=0;$i<2;$i++){
		$i2=1-$i;
		if($dam_side eq $i){
			if($b_mst[$i2]==1178){$damage=int($damage/2);}
			&add_msg("null","$pn[$sno[$i]]에$damage의 데미지! ");
			$lp[$sno[$i]]-=$damage;
			if($player[$sno[$i]]==17){&add_msg("판도라","락∼！　최고 ~~! ");}

			if($fld_koka[$b_fld[$i]]=~/f_(\d+)_sacr/ && $b_mst[$i]==774){
				&add_msg("null","<b>「산 제물을 바침·쉴드(shield)!」</b><br>$c_name[$fld[$1]]을(를) 방패로 했다! ");
				&add_msg("null","$pn[$sno[$i2]]에$damage의 데미지! ");$lp[$sno[$i2]]-=$damage;&chk_lp;
				$sacrflg=1;
			}

			if($mlamp ne ""){}
			else{
				if($c_koka[$b_mst[$i2]]==12){push(@chain2,"$sno[$i2]-5-$b_mst[$i2]-$damage");}
				if($kok[$sno[$i2]][21] ne ""){push(@chain2,"$sno[$i2]-5-387");}
				if($fld_koka[$b_fld[$i2]]=~/skill_$turn/){push(@chain2,"$sno[$i2]-5-1197");}
			}
		}

		if($botiiki[$i] ne ""){
			if($fld_koka[$b_fld[$i]]=~/f_(\d+)_sacr/){
				if($sacrflg!=1){&add_msg("null","<b>「산 제물을 바침·쉴드(shield)!」</b><br>$c_name[$fld[$1]]을(를) 방패로 했다! ");}
				&go_boti($1);$botiiki[$i]="";
			}

			if($b_mst[$i]==1038 && $ap_fld[$b_fld[$i2]]>=1900){
				&add_msg("null","<b>엘프 검사는 훌쩍 몸을 주고 받았다! </b>");
				$botiiki[$i]="";
			}
			elsif($fld_koka[$b_fld[$i]]=~/meikyo/ && $kok[0][8] eq ""){
				&add_msg("null","<b>명경지수! </b>　$b_nam[$i](은)는 장소에 머물었다. ");
				$botiiki[$i]="";
			}
			elsif($b_mst[$i]==1220 && $fld_koka[$b_fld[$i]]=~/f_\d+:/){
				&add_msg("null","<b>바이서·데스는 3턴의 사이 무적 상태! </b>");
				$botiiki[$i]="";
			}
			elsif($kok[$sno[$i2]][38] ne "" && &syu_st($b_fld[$i2]) eq "악마"){$muko[$i]=1;}
			elsif($b_mst[$i2]==1107){$muko[$i]=2;}
			elsif($b_mst[$i2]==1113 && $c_koka[$b_mst[$i]]==7){
				for($k=$fw1[$sno[$i2]];$k<$fw1[$sno[$i2]]+5;$k++){if($k!=$b_fld[$i2] && &syu_st($k) eq "악마"){last;}}
				if($k<$fw1[$sno[$i2]]+5){$muko[$i]=3;}
			}

		}
		elsif($fld_koka[$b_fld[$i2]]=~/ryugorosi/ && &syu_st($b_fld[$i]) eq "드래곤" && $kok[0][8] eq ""){&add_msg("null","<b>용 살인의 검은$b_nam[$i]에 치명상을 주었다! </b>");$fld_koka[$b_fld[$i]].="gorosare<>";$jok[1]=1;}

		&chk_lp;
	}

	if($b_fld[1] ne "player" && $fld_rf[$b_fld[1]]==1){&reverse($b_fld[1],$muko[1]);}

	if($b_mst[1]==638 && $botiiki[0] eq "" && $muko[1] eq ""){
		&add_msg("null","<b>$b_nam[0]은(는) 환영에 헤매어, 패로 돌아왔다! </b>");
		&return_tehuda($b_fld[0]);
	}
	if($b_mst[0]==929 && $botiiki[1] eq "" && $b_fld[1] ne "player"){
		&add_msg("null","$b_nam[1]의 공격력을 500내렸다! ");
		$fld_koka[$b_fld[1]].="ptr:-500:0:$turn<>";
	}

	if($b_mst[0]==523 && $c_zokusei[$b_mst[1]] eq "어둠" && $botiiki[1] eq ""){
		&add_msg("null","<b>$b_nam[1]은 컬러 구리독이 돌아 사망! </b>");
		&go_boti($b_fld[1],5);
	}

	for($i=0;$i<2;$i++){
		if($b_mst[$i]==375 && $muko[$i] eq "" && $b_fld[1] ne "player"){
			&add_msg("null","<b>이 차원의 전사는$b_nam[$i2]을 길동무로<br>이 차원으로 여행을 떠났다! </b>");
			&syometu($b_fld[0]);&syometu($b_fld[1]);
			return;
		}
	}

	for($i=0;$i<2;$i++){
		$i2=1-$i;
		if($botiiki[$i] ne ""){
			if($b_mst[$i2]==1215 && $c_syokan[$b_mst[$i]]!=5 && $kok[0][14] eq ""){
				&add_msg("null","<b>죽음의 송곳니! </b>　$pn[$sno[$i]]에500의 데미지! ");
				$lp[$sno[$i]]-=500;&chk_lp;
			}

			if($botiiki[$i2] ne ""){}
			elsif(($b_mst[$i]==1103 || $b_mst[$i]==1104 || $b_mst[$i]==1105) && $muko[$i] eq "" && $kok[0][58] eq ""){
				&add_msg("null","$b_nam[$i2]의 공수는 500다운! ");
				$fld_koka[$b_fld[$i2]].="ptr:-500:-500:0<>";
			}

			if($botiiki[$i2] ne ""){}
			elsif($b_mst[$i2]==742){$fld_koka[$b_fld[$i2]].="hakai<>";}
			elsif($b_mst[$i2]==1069){
				$fld_koka[$b_fld[$i2]].="ptr:-200:0:0<>";
				if($srfchk eq ""){&add_msg("하나사키","그는 정의가 되면 생명까지 깎아져 갑니다! <br>그런데도 그는 악으로 향한다! 근사해―！그 이름은 좀바이어다! ");$srfchk=1;}
			}
			elsif($b_mst[$i2]==1219){
				&add_msg("null","셀 케토는$b_nam[$i]을 흡수했다! ");
				&syometu($b_fld[$i]);
				if($srfchk==1){
					if($player[$s_d]==3){&add_msg("조이","구…식은이나가∼~! ");}
					if($player[$s_a]==20){&add_msg("리시드","몸의 털의 것야 개 광경이겠지만 이것이 셀 케토의 특수 능력…");}
					$srfchk=2;
				}
				&add_msg("null","<b>성수 진화! </b> 공격력500업! ");
				$fld_koka[$b_fld[$i2]].="ptr:500:0:0<>";
			}
			elsif($b_mst[$i2]==1108){
				&add_msg("null","$b_nam[$i]은(는) 이계에 보내졌다! ");
				&syometu($b_fld[$i]);
			}

			$ad_bak=$fld_ad[$b_fld[$i]];
			&go_boti($botiiki[$i],1,$muko[$i]);

			if($b_mst[$i2]==922){$hk[30+$sno[$i2]].="$b_mst[$i]<>";$jok[1]=1;}
			if($time_machine=~s/^$sno[$i]-// && $c_syokan[$b_mst[$i]]!=5 && $kok[0][14] eq ""){
				$tsnom=$sno[$i];
				&add_msg($pn[$tsnom],"<b>함정 카드 발동!　「타임 머신」! </b>");
				$use_f_no=$time_machine;$use_cno=717;&end_usecard(0);
				if($kok[0][7] ne ""){&add_msg("null","<b>그러나, 함정의 효과는 무효! </b>");}
				else{
					&add_msg("null","1턴 전부터$b_nam[$i]를 귀환시켰다! ");$nf0=$b_fld[$i];
					for($j=0;$j<$#{$boti[$tsnom]}+1;$j++){if($boti[$tsnom][$j]==$b_mst[$i]){&put_field($j+200+$i*100);last;}}
					&del_null(*boti,$tsnom);
					$fld_ad[$botiiki[$i]]=$ad_bak;
					$time_machine="";&hosatu($i);
				}
			}
		}
	}
	if($hk[33] ne "" && $b_fld[1] ne ""){$a_b[$b_fld[1]]=3;}
}

sub ext_set{
	local($fldno)=$_[0];
	local($rf)=$_[1];
	local($mode)=$_[2];

	$a_m[$fldno]=1;$fld_koka[$fldno].="ext<>";$a_b[$fldno]="";
	if($rf==1){$fld_rf[$fldno]=1;$fld_ad[$fldno]=1;if($kok[0][3] ne ""){$fld_rf[$fldno]=0;}}
	else{$fld_rf[$fldno]=0;$fld_ad[$fldno]=0;}
	$jok[2+$s_a]=1;

	if($mode==1){}
	elsif($mode==2){$l_act="$s_a-5-$fldno-$fld[$fldno]";}
	elsif($rf==1 && $kok[0][3] eq ""){$l_act="$s_a-7-$fldno-$fld[$fldno]";}
	else{$l_act="$s_a-6-$fldno-$fld[$fldno]";}
	$bstep="";
	if(($fld[$fldno]==1036 || $fld[$fldno]==1112 || ($fld[$fldno]==1170 && $mode!=1) || $fld[$fldno]==1072) && $rf!=1){push(@chain2,"$s_a-5-$fld[$fldno]-$fldno");}
	elsif($fld[$fldno]==1099){&rarcopy;}
	if($c_zokusei[$fld[$fldno]] ne "빛" && $mode!=1){&raiden_ret();}

	if($kok[0][62] ne ""){push(@syori,"2<>i-$s_d<>n-danatu<>o-한다::안한다<>m-$c_name[$fld[$fldno]]을 탄압할까요? <>p-$fldno");}
}

sub put_card2{
	local($i);

	$gilfo="";
	if($joken_s==1){}
	elsif($c_zokusei[$cardno] eq "신"){$yonie=3;}
	elsif($tmp_lv<7){$yonie=1;}
	elsif($cardno==1214 && $niesu>=3 && $s_kind==1){$yonie=3;$gilfo=1;}
	else{$yonie=2;}

	if($niesu<$yonie){
		if($yonie==3){&add_msg("null","!$s_a(신을 호출하려면, 제물 3체가 필요하다 )");}
		else{&add_msg("null","!$s_a($tmp_lv트별 몬스터를 소환하려면, 제물$yonie체가 필요하다 )");}
		return 1;
	}

	$nie_name="";
	for($i=0;$i<$yonie && $i<$#nie+1;$i++){
		$nino=$fld[$nie[$i]];
		if($nino==1050 || $nino==974){&add_msg("null","!$s_a(이 토큰은 생지로 할 수 없어)");return 1;}
		if($nie_name ne ""){$nie_name.="와$c_name[$nino]";}
		else{$nie_name.=$c_name[$nino];}
	}

	if($cardno==677 && $s_kind==1 && $player[$s_a]==0 && $player[$s_d]==17){
		&add_msg("유희","M＆W의 세계에는 최상급 마술사로부터 그 마력을 물려 받은 <br>단 한 명의 제자가 존재한다...");
		&add_msg("판도라","(해…사토루등이군요∼~)");
		&add_msg("유희","<b>보여 주겠다! </b>");
	}

	if($player[$s_a]==2 && $nie_name=~/오벨리스크/){&add_msg($pn[$s_a],"<b>신을 생지에 바친다!</b>");}
	elsif($nie_name ne ""){&add_msg($pn[$s_a],"$nie_name(을)를 제물로 바치고 --");}

	if($ad==1){
		&add_msg($pn[$s_a],$srf[$s_a][3]);
	}
	elsif($cardno==745){&add_msg("null","자석의 전사 3체가 합체! <br><b>자석의 전사 마그넷·벌키 리온! </b>");}
	elsif($cardno==669){&add_msg($pn[$s_a],"<b>3악마 합체!　게이트·가디안! </b>");}
	elsif($cardno==914 && $joken_s==1){&add_msg($pn[$s_a],"<b>기가 사이버 특수 소환! </b>");}
	elsif($cardno==924 && $player[$s_a]==2){&add_msg($pn[$s_a],"<b>이것은 파괴의 신 --<br>오벨리스크의 거신병이다!　와하하하하하</b>");}
	elsif($cardno==923 && $player[$s_a]==6){&add_msg($pn[$s_a],"<b>이것이 3환신 카드의 하나!　오시리스의 모습이다! </b>");}
	elsif($cardno==923 && $player[$s_a]==0){&add_msg($pn[$s_a],"<b>천공용 강림! </b>");}
	elsif($cardno==925 && $player[$s_a]==21){&add_msg("null","<i>태양신은 삼체의 생지를 묶어 그 힘을 얻지만<br>신을 따르는 사람의 주문을 하늘에 바쳐라</i>");&add_msg($pn[$s_a],"<b>이거야 말로 라의 익신룡이다! </b>");}
	elsif($cardno==1099){&add_msg($pn[$s_a],"<b>라의 익신룡! </b>");}
	elsif($cardno==319 && $player[$s_a]==10){&add_msg($pn[$s_a],"<b>오 오 오 오 오 오 오 왔다! <br>이것이 「그레이트·모스」4단 진화! </b>");}
	elsif($cardno==724 && $player[$s_a]==10){&add_msg($pn[$s_a],"<b>오 오 오 오 오 오 오 왔다! <br>이것이 그레이트·모스 육단 진화 궁극 완전태야! </b>");}
	elsif($cardno==861 && $player[$s_a]==3){&add_msg($pn[$s_a],"<b>사이코·손카! </b><br>나와 싸운 결투자로부터 물려 받은 영혼의 카드다! ");}
	elsif($cardno==1064 && $player[$s_a]==8){&add_msg($pn[$s_a],"세 개의 영혼을 생지로 해 소환된다...　죽음의 세계의 지배자 --...<br><b>다크·네크로피아 소환! </b>");&add_msg("바크라","$pn[$s_d]당신에게 가르쳐 주겠다...오컬트 덱의 공포를...");}
	elsif($cardno==1214 && $player[$s_a]==3){&add_msg($pn[$s_a],"<b>기르포드·더·라이트닝 소환! </b>");&add_msg("조이","이녀석으로 너를 넘어뜨리겠다!　$pn[$s_d]! ");}
	else{
		&add_msg($pn[$s_a],"<b>$c_name[$cardno]소환! </b>");
	}
	if($cardno==1219 && $srfchk eq "" && $ad==0){
		if($player[$s_d]==3){&add_msg("조이","위무엇이야! <br>(...그리고 괴물이! )");}
		if($player[$s_a]==20){&add_msg("리시드","성수 셀 케토는 성궤에 봉쇄된 카드의 수호신...<br>신의 카드 「라의 익신룡」의 것! ");}
		$srfchk=1;
	}
	elsif($cardno==1221 && $player[$s_a]==21 && $ad==0){&add_msg("마리크","쿠크크...<br>빨리 이녀석를 넘어뜨리지 않으면 한없이 공격력이 올라가지...");}

	if($cardno==925 || $cardno==1099){
		for($i=0;$i<$yonie;$i++){$rar_tmp+=$ap_fld[$nie[$i]];$rar_tmp2+=$dp_fld[$nie[$i]];}
		$rarst="rar_".$rar_tmp."-".$rar_tmp2;
	}

	$in_proc=1;
	for($ni_i=0;$ni_i<$yonie && $ni_i<$#nie+1;$ni_i++){&go_boti($nie[$ni_i],4);}
	$in_proc="";

	if($cardno==677 && $s_kind==1 && $player[$s_a]==0 && $player[$s_d]==17){
		&add_msg("판도라","<b>블랙 매지션<br>가 , 가 , 가르! </b>");
	}
	if(&akichk()){return 1;}

	0;
}

sub put_card{		#카드를 낸다
	&put_card_mag;
	&put_card_mst;
	&get_apdp_fld;
}

sub put_card_mst{
	local($i);
	local($s_kind,$cardno,$fldno);

	if($F{'putcardno'} eq ""){return;}
	if(&kase_chk){return;}

	$syokan_seiko="";$joken_s="";
	$t_no = $F{'putcardno'};
	if($t_no =~ s/_a//){$s_kind=1;$ad=0;}
	elsif($t_no =~ s/_d//){$s_kind=8;$ad=1;if($kok[0][3] ne ""){$s_kind=1;}}
	else{return;}

	if(&kinsi_chk($t_no)){return;}

	$cardno=$tehuda[$s_a][$t_no];
	if($cardno eq ""){return;}
	if($c_zokusei[$cardno] eq "마" || $c_zokusei[$cardno] eq "함정"){return;}

	@nie=grep(/^nie_/,keys(%F));$niesu=0;
	for($i=0;$i<$#nie+1;$i++){$nie[$i]=~s/nie_//;if($fld[$nie[$i]]==1222){$niesu++;}}
	if($c_zokusei[$cardno] ne "빛"){$niesu=0;}
	$niesu+=$#nie+1;

	if($c_syokan[$cardno]==3 && $c_zokusei[$cardno] ne "신"){$joken_s=1;}
	if($cardno==914 && $#nie<0){$joken_s=1;}
	if($c_syokan[$cardno]==4 || $joken_s==1){$s_kind=5;}
	if($call[$s_a] ne "" && $syori[0]!~/^4/ && $s_kind!=5){return;}

	if($s_kind==1 && &ext_chk("t")){return;}
	if($s_kind==5 && &ext_chk()){return;}

	if($syori[0]=~/^4/ && $s_kind==5){&add_msg("null","!$s_a(피의 대상으로 특수 소환은 할 수 없다)");return;}
	if($c_syokan[$cardno]==4 && $kok[$s_a][4] eq ""){&add_msg("null","!$s_a(장소에 툰 월드가 없으면 낼 수 없어)");return;}
	if($cardno==1099 && $player[$s_a]!=20){&add_msg("null","!$s_a(리시드 밖에 사용할 수 없어)");return;}
	if($s_kind==1 && &syokan_chk){return;}

	$tmp_lv=&lv_st($cardno);

	if($joken_s==1 && $rule==0 && &use_koka_1($cardno)){return;}

	if(($tmp_lv>4 && $rule==0 && !($cardno==1039 && $#{$tehuda[$s_a]}==0 && $s_kind==1)) || $joken_s==1){
		if(&put_card2){return;}
	}
	else{
		if(&akichk()){return;}
		if($ad==0){
			$tmp=$srf[$s_a][2];$tmp =~ s/~/$c_name[$cardno]/g;
			&add_msg($pn[$s_a],$tmp);
			if($cardno==1039){&add_msg("null","<b>암흑 기사 가이아는 번개 같이 나타났다! </b>");}
		}
		else{&add_msg($pn[$s_a],$srf[$s_a][3]);}
	}

	&put_field($t_no+50,0,"t");
	$fldno=$nf0;
	if($s_kind==5){
		&ext_set($fldno,0,1);$fld_ad[$fldno]=$ad;
		if($cardno==1170){&soubi($res_s[0],$fldno);}
	}
	else{
		if($cardno==925 || $cardno==1099){$fld_koka[$fldno].=$rarst."<>";}

		$fld_ad[$fldno]=$ad;
		if($s_kind==1){$fld_rf[$fldno]=0;}
		elsif($kok[0][3] ne ""){
			&add_msg("null","(「성스러운 빛」의 효과로 겉수비 표시가 된다)");
			$fld_rf[$fldno]=0;$s_kind=1;
		}
		else{$fld_rf[$fldno]=1;}
		if($cardno==1099){&rarcopy;}
	}
	if($cardno==918 && $player[$s_a]==12 && $s_kind==1 && $kok[0][59] ne ""){&add_msg("마해룡","후후…!　보이고 바구니해의 마귀…<br>이것이 스텔스II사악한 마음! ");}

	$a_m[$fldno] = 3;
	&maryoku(16);
	$syokan_seiko=1;

	if($syori[0]=~/^4/){$jok[2+$s_a]=1;if($chain[$#chain]=~/$s_d-3-/){$chain[$#chain]="$1-3-null";}}
	elsif($s_kind==1){$call[$s_a]=1;}
	elsif($s_kind==8){$call[$s_a]=2;}

	if($phase==2){$jok[7]=1;}

	$chudan="$s_a-$s_kind-$fldno-$cardno-$gilfo";
	if(&trap_check(1)){return;}

	&put_card_mst2;
}

sub syokan_chk{
	if($cardno==1145){
		if(&maisu_count(0)>0){&add_msg("null","!$s_a(그 밖에 몬스터가 있으면 소환할 수 없다)");return 1;}
	}
	elsif($cardno==1169){
		if(&hikari_chk()){&add_msg("null","!$s_a(장소에 빛속성이 아닌 몬스터가 있다)");return 1;}
	}
	elsif($cardno==1219){
		if($kok[$s_a][54] eq ""){&add_msg("null","!$s_a(왕가의 신전이 없다)");return 1;}
	}
	0;
}

sub put_card_mst2{

	&change_phase(2);
	$a_m[$fldno] = 1;
	$cardno=$fld[$fldno];

	if($s_kind==1 || $s_kind==2){
		for($i=1;$i<3;$i++){
			if($kok[$i][13]>0){
				&add_msg("null","<b>의문의 인형술사의 효과 발동! </b>");
				&lp_up(500,$kok[$i][13]);
			}
		}
	}

	if($s_kind==1){
		if($cardno==837 || $cardno==995){
			&add_msg("null","통상 소환되었다$c_name[$cardno]는 파괴된다! ");
			&go_boti($fldno);
		}
	}
	elsif($s_kind==2){
		if($kok[0][66] ne "" && &lv_st($cardno,1)<3){&add_msg("null","<b>$c_name[$cardno]은(는) 텐구의 집안에 날려 버려졌다! ");&go_boti($fldno);return;}
		else{&reverse($fldno);}
	}

	if($s_kind==1 || $s_kind==2 || $s_kind==5){
		if($cardno==1214 && $gilfo eq ""){}
		elsif($c_koka[$cardno]==9 || ($c_koka[$cardno]==16 && $s_kind==1)){push(@chain2,"$s_a-5-$cardno-$fldno");}
		if($c_zokusei[$cardno] ne "빛"){&raiden_ret();}
	}

	&get_apdp_fld;

	if($kok[$s_d][36] ne "" && ($s_kind==1 || $s_kind==8)){
		if($player[$s_d]==6 && $srfchk eq ""){
			&add_msg("마리크","새로운 하인을 소환했군...<b>이 순간에 오시리스의 특수 능력 발동! </b>");
			$srfchk=9;
		}
		&add_msg("null","오시리스가 이제 한쪽의 입이 열렸다...! ");
		if($player[$s_d]==6 && $player[$s_a]==0 && $srfchk==9){
			&add_msg("유희","!　상대 턴에도 공격을 걸어 오는 몬스터! ");
			&add_msg("마리크","몬스터가 아니다!　<b>신이다! </b>");
			$srfchk=1;
		}
		&add_msg("null","<FONT color=$textc_p2><b>소뢰탄! </b></font>");
		if($s_kind==1){
			$fld_koka[$fldno].="ptr:-1500:0:0<>";
			&add_msg("null","$c_name[$fld[$fldno]]의 공격력을1500내렸다! ");
		}
		elsif($dp_fld[$fldno]<=1500){
			&add_msg("null","<b>$c_name[$fld[$fldno]]은(는) 파괴되었다! </b>");
			&go_boti($fldno);
		}
		else{&add_msg("null","$pn[$s_a]의 몬스터는 참고 견뎠다. ");}
		&get_apdp_fld;
	}
}

sub change_mode{		#표시 변경
	local($i,$j);
	$seiko="";

	for($i=0;$i<$#chg+1;$i++){
		$s_kind="";
		$fldno=$chg[$i];
		if($fld[$fldno] eq "" || $a_m[$fldno] ne ""){next;}
		if($kok[0][9]>1 || ($kok[0][9]==1 && $fld[$fldno]!=953)){&add_msg("null","!$s_a<b>천안 주박! </b><br>공격도 표시 변경도 할 수 없다! ");next;}
	if($fld_koka[$fldno]=~/rokubo/ && $kok[0][7] eq ""){&add_msg("null","!$s_a주박을 걸칠 수 있고 있다! ");next;}
		$cardno=$fld[$fldno];

		if($fld_ad[$fldno]==1){		#공격 표시로 변경
			if($fld_rf[$fldno]==1){	#반전 소환
				$s_kind=2;
				if(&ext_chk("t")){next;}
				if(&syokan_chk){return;}
			}

			if($fld_koka[$fldno]=~/gobrin_(\d+)/ && $turn-$1<3){&add_msg("null","!$s_a고블린들은 돌격 했던 바로 직후로 , 태세를 변경할 수 없다! ");next;}
			if($kok[0][2] ne "" && &syu_st($fldno) eq "드래곤"){&add_msg("null","!$s_a봉인의 항아리의 효력에 의해 , 공격 표시로 할 수 없다! ");next;}

			$fld_ad[$fldno]=0;
			$fld_rf[$fldno]=0;

			$tmp=$srf[$s_a][9];
			$tmp=~s/~/$c_name[$cardno]/;
			&add_msg($pn[$s_a],$tmp);
			$seiko=1;
		}
		else{				#수비 표시로 변경
			$fld_ad[$fldno]=1;

			$tmp=$srf[$s_a][10];
			$tmp=~s/~/$c_name[$cardno]/;
			&add_msg($pn[$s_a],$tmp);
			$seiko=1;
		}

		&piero($fldno);
		if($s_kind==2){
			$a_m[$fldno] = 3;
			$jok[2+$s_a]=1;
			$chudan="$s_a-2-$fldno-$cardno";
			if(&trap_check(1)){return;}
			&put_card_mst2;
		}
		else{
			$a_m[$fldno] = 2;
			&get_apdp_fld;
		}
	}
	if($seiko ne ""){&change_phase(2);}
}


sub put_card_mag{
	local($cardno,$fldno);

	if($#putm<0){return;}
	if($hk[30] ne ""){&add_msg("null","!$s_a(대한파가 발동하고 있는)");return;}

	for($i=0;$i<$#putm+1;$i++){
		$cardno=$tehuda[$s_a][$putm[$i]];
		if($c_zokusei[$cardno] ne "마" && $c_zokusei[$cardno] ne "함정"){next;}
		elsif($c_name[$cardno] =~ /^죽음의 메세지/){&add_msg("null","!$s_a(위쟈반의 효과 이외의 장소에 낼 수 없다)");next;}
		if(&kase_chk){return;}
		if($c_syuzoku[$cardno] ne "필드" && &akichk2()){return;}
		if(&kinsi_chk($putm[$i])){next;}

		&put_field($putm[$i]+50,1);
		if($kok[0][30] ne ""){$a_m[$nf1] = 5;}
		else{$a_m[$nf1] = 1;}

		if($i==0){&add_msg($pn[$s_a],$srf[$s_a][4]);}
		&maryoku(16);
	}
	&change_phase(2);
}

sub put_ini{
	local($i);

	if($room ne ""){$fn=$roomst.$room;}
	else{$fn=$id;}

	$putst="";
	for($i=0;$i<$#pfldata+1;$i++){
		$evalst='$val=$'.$pfldata[$i];
		eval($evalst);
		if($val ne ""){$putst.="$pfldata[$i]\t$val\n";}
	}
	for($i=0;$i<$#pfldata2+1;$i++){
		$evalst='$val=$'.$pfldata2[$i].'[1]';
		eval($evalst);
		if($val ne ""){$putst.="$pfldata2[$i]1\t$val\n";}
		$evalst='$val=$'.$pfldata2[$i].'[2]';
		eval($evalst);
		if($val ne ""){$putst.="$pfldata2[$i]2\t$val\n";}
	}
	for($i=0;$i<$#pflst+1;$i++){
		$evalst = '$val=join(",",@'.$pflst[$i].')';
		eval($evalst);
		if($val!~/^,*$/){$putst.="$pflst[$i]\t$val\n";}
	}
	for($i=0;$i<$#pflst2+1;$i++){
		$evalst = '$val=join(",",@{$'.$pflst2[$i].'[1]})';
		eval($evalst);
		if($val!~/^,*$/){$putst.="$pflst2[$i]1\t$val\n";}
		$evalst = '$val=join(",",@{$'.$pflst2[$i].'[2]})';
		eval($evalst);
		if($val!~/^,*$/){$putst.="$pflst2[$i]2\t$val\n";}
	}
	open(PFL,">tmp/$fn");
	print PFL $putst;
	close(PFL);
}

sub get_ini{

	if($room ne ""){$fn=$roomst.$room;}
	else{$fn=$id;}

	if(-r "tmp/$fn"){
		open(PFL,"tmp/$fn");
	}
	else{return;}

	while(<PFL>){
		chop;
		($KEY,$VAL) = split(/\t/);
		$G{$KEY}=$VAL;
	}
	close(PFL);

	for($i=0;$i<$#pfldata+1;$i++){
		$evalst='$'.$pfldata[$i].'=$G{"'.$pfldata[$i].'"}';
		eval($evalst);
	}
	for($i=0;$i<$#pfldata2+1;$i++){
		$evalst='$'.$pfldata2[$i].'[1]=$G{"'.$pfldata2[$i].'1"}';
		eval($evalst);
		$evalst='$'.$pfldata2[$i].'[2]=$G{"'.$pfldata2[$i].'2"}';
		eval($evalst);
	}
	for($i=0;$i<$#pflst+1;$i++){
		$evalst='@'.$pflst[$i].'=split(/,/,$G{"'.$pflst[$i].'"})';
		eval($evalst);
	}
	for($i=0;$i<$#pflst2+1;$i++){
		$evalst='@{$'.$pflst2[$i].'[1]}=split(/,/,$G{"'.$pflst2[$i].'1"})';
		eval($evalst);
		$evalst='@{$'.$pflst2[$i].'[2]}=split(/,/,$G{"'.$pflst2[$i].'2"})';
		eval($evalst);
	}
	undef(%G);
}

sub get_ini2{	#스타트시 읽기

	if($match ne "" && $match ne "on"){
		open(PFL,"tmp/".$roomst.$room."_deck".$u_side);
	}
	elsif(-r "tmp/".$id."_pfl"){
		open(PFL,"tmp/".$id."_pfl");
	}
	else{@odeck=@defo;return;}

	while(<PFL>){chop;($KEY,$VAL) = split(/\t/);$P{$KEY} = $VAL;}
	close(PFL);

	@odeck = split(/,/,$P{'deck'});
	if($#odeck==-1){@odeck=@defo;}
}

sub get_timefile{
	if($room eq ""){return;}
	for($j=1;$j<3;$j++){
		$tfn="tmp/".$roomst.$room."_time".$j;
		if(!(-r $tfn)){$update[$j]=$date-10;}
		else{
			$runcou=0;
			while(!(-s $tfn) && $runcou<10){sleep(1);$runcou++;}
			open(TIME,$tfn);
			$_=<TIME>;($t_date[$j],$t_waitst[$j],$t_logcou[$j],$t_surr[$j],$t_waitstj[$j])=split(/\t/);close(TIME);
		}
	}
	if($t_date[1]<$t_date[2]){$update=$t_date[2];}
	else{$update=$t_date[1];}
}

sub get_playerdata{
	$cou=0;
	open(SRF,"srf.dat");
	$lin=<SRF>;
	while(<SRF>){
		chop;
		for($i=1;$i<3;$i++){
			if($cou eq $player[$i]){
				@tmp=split(/\t/);
				$t_name = shift(@tmp);
				if($pn[$i] eq ""){$pn[$i] = $t_name;}
				@{$srf[$i]} = @tmp;
			}
		}
		$cou++;
	}
	if($pn[1] eq $pn[2]){
		$pn[1].="1";
		$pn[2].="2";
	}
	if($player[2]==9){@{$srf[2]}=@{$srf[1]};$pn[2]="K ";}
}

%waza = (
0,"투 기염참검! ",
1,"정·검·참! ",
24,"멸망의 burst·스트림! ",
56,"스파이럴·셰이 바! ",
59,"흑·마·도! ",
114,"헬·후레임! ",
155,"흑염탄! ",
175,"쇄암검! ",
196,"마강뢰! ",
202,"화구의 비력! ",
207,"트라이앵글·X·스파크! ",
208,"마수 쇄단! ",
260,"날씨 플레어! ",
300,"드래곤 호흡! ",
315,"사우즌드·노즈·호흡! ",
317,"서울·스피아! ",
319,"모스·허리케인! ",
362,"다크·글라이드! ",
368,"암·캐논·쇼트! ",
500,"포이즌·조르! ",
536,"다이너소어·풋·스탬프! ",
572,"순살5연속 베어! ",
610,"지옥염! ",
652,"카오스·브레이드! ",
658,"포격!　훼일 본 버드! ",
670,"멸망하고의 주문 데스·아르테마! ",
676,"얼티메이트·burst! ",
677,"흑·마·도폭·렬·파! ",
722,"다크·메가·플레어! ",
723,"세인트·파이어·기가! ",
724,"모스·바닝·데스·토네이도! ",
742,"퀸즈·헬·호흡! ",
745,"전자검! ",
755,"활공검! ",
819,"드래곤·후레임! ",
861,"컴퓨터 에너지·쇼크! ",
912,"용 파괴의 검! ",
923,"초전도파 번개·포스! ",
924,"갓·핸드·분쇄기! ",
925,"갓·흔들리고 이즈·캐논! ",
973,"암흑마염장! ",
993,"생각살! ",
995,"빛의 포격! ",
1038,"정·검·참! ",
1039,"스파이럴·셰이 바! ",
1064,"생각안살! ",
1069,"URYAAAA－! (ZBUSH! )",
1095,"다크데스트라크션! ",
1156,"투 기염참검! ",
1157,"서울·스피아! ",
264,"뢰충탄! ",
265,"유수파! ",
1213,"등구·-! ",
1217,"단쇄 처형! ",
1214,"라이트닝크랏슈소드! ",
1225,"갤럭시·분쇄기!",
);

1;
