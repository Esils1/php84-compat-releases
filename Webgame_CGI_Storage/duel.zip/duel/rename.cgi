#!/usr/bin/perl
#이름 변경

&get_input;

if($id2 ne ""){
	if(-r "tmp/".$id2."_pfl"){$msg="<b>유희 「안되!　그 이름은 다른 사람이 사용하고 있는 것 같아」</b><br>";}
	else{
		open(IN,"tmp/".$id."_pfl");
		open(OUT,">tmp/".$id2."_pfl");
		while(<IN>){print OUT;}
		unlink("tmp/".$id."_pfl");
		$id=$id2;
		$id2="";
	}
}

print "Content-type:text/html; charset=utf-8\n\n";
print<<"_EOF_";
<html>
<title>FusionX</title>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=utf-8">
<body bgcolor=#fffff0 background="embak.gif">
<blockquote>
$msg
<br>
<form action="rename.cgi">
현재의 듀얼네임
<input type=text name=id value=$id size=8><br>
새로운 듀얼네임
<input type=text name=id2 size=8><br>
<input type=submit value="변경"><br>
※덱 내용 , 승패 결과는 인계됩니다. <br>
※듀얼네임은 반각영수(a~z,A~Z,0~9)50문자 이내에서 붙여 주세요. <br>
　전각 문자는 금지는 하지 않습니다만 , 그 경우의 동작은 보증하지 않습니다. <br>
<br>
<br>
<hr>
<center><a href="index.cgi?id=$id">돌아가기</a><br>
</body></html>
_EOF_

sub get_input{
	$INPUT = $ENV{'QUERY_STRING'};

	$INPUT =~ s/\&+/\&/g;
	$INPUT =~ s/#.+//;
	@TMP = split('&', $INPUT);
	for ($i = 0; $i <= $#TMP; ++$i) {
		($KEY, $VAL) = split('=', $TMP[$i]);
		$VAL =~ tr/+/ /;
		$VAL =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
		if($VAL ne ""){$F{$KEY}=$VAL;}
	}

	$cookie=$ENV{'HTTP_COOKIE'};
	if($F{'id'} ne ""){$id = $F{'id'};}
	elsif($cookie ne ""){$id=$cookie;$id=~s/^id=//;}

	$id=~s/\.//g;
	$id=~s/\///g;
	$id=substr($id,0,50);

	$id2=$F{'id2'};
	$id2=~s/\.//g;
	$id2=~s/\///g;
	$id2=substr($id2,0,50);
}
