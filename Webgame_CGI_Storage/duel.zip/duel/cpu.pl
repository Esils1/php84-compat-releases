sub cpu_usecard{
	local($i);
	local($mode) = $_[0];

	if($mode==3){
		$chudan = $chain[0];&chain_para_chk;
		if($t_damage<=1000){$run_flg=100;}
	}

	$used_flg="";
	if($rule==1 || &kase_chk){}
	else{
		for($i=0;$i<$#{$tehuda[$s_a]}+1;$i++){
			if($tehuda[$s_a][$i] eq ""){next;}

			&usecard_chk;
			$F{'use'}="t_$i";
			$cardno=$tehuda[$s_a][$i];$t_nm=$c_name[$cardno];

			if($c_zokusei[$cardno] eq "마"){
				if($kok[0][8] ne "" || $kok[0][30] ne ""){next;}
				if($mode==1){&cpu_usemagic_1;}
				elsif($mode==2){&cpu_usemagic_2;}
				else{if($c_syuzoku[$cardno] eq "속공" && $turn2==2){&cpu_usemagic_1;}}
			}
			elsif($t_nm eq "크리보" && $mode==3){&use_card;}
			elsif($t_nm eq "봉인된 엑조디아"){&use_card;}
			elsif($c_syokan[$cardno]==3 && $mode!=3){
				$tmp=&keisiki_chk($cardno);
				if($tmp==0){$F{'putcardno'}=$i."_a";}
				else{$F{'putcardno'}=$i."_d";}
				&put_card_mst;
			}

			if($mode!=3){if($chain[0].$syori[0].$chain2[0] ne ""){return;}}
			else{if($used_flg ne "" || $chain[0]=~/^2-/){return;}}
		}
	}

	if($chain[0]=~/^$s_d-/){$chudan=$chain[0];&chain_para_chk;}

	for($i=0;$i<5;$i++){
		$cardno=$fld[$i];
		if($cardno eq ""){next;}
		if(!(&use_chkf($i))){next;}

		$F{'use'}="f_$i";$t_nm=$c_name[$cardno];
		&usecard_chk;
		if($c_zokusei[$cardno] eq "마"){
			if($kok[0][8] ne ""){next;}
			if($mode==1){&cpu_usemagic_1;}
			elsif($mode==2){&cpu_usemagic_2;}
			else{if($c_syuzoku[$cardno] eq "속공"){&cpu_usemagic_1;}}
		}
		elsif($c_zokusei[$cardno] eq "함정"){
			if($kok[0][7] ne ""){next;}
			&cpu_usetrap;
		}
		else{next;}

		if($mode!=3){if($chain[0].$syori[0].$chain2[0] ne ""){return;}}
		else{if($used_flg ne "" || $chain[0]=~/^2-/){return;}}
	}
	if($mode==3){$F{'go_on'}=1;}
}

sub usecard_chk{		#CPU의 카드 사용시 각종 체크
	local($i);

	$win_flg=0;
	$mag_ariflg=0;
	$toon_ariflg=0;

	&pt_chk;

	for($i=5*3;$i<5*4;$i++){
		if($fld[$i] ne ""){$mag_ariflg=1;last;}
	}

	for($i=0;$i<$#{$tehuda[$s_a]}+1;$i++){
		if($c_syokan[$tehuda[$s_a][$i]]==4){$toon_ariflg=1;}
	}

	$max_tmp=0;
	if($call[$s_a] eq ""){
		for($i=0;$i<$#{$tehuda[$s_a]}+1;$i++){	#명함 최강
			if($c_zokusei[$tehuda[$s_a][$i]] eq "마" || $c_zokusei[$tehuda[$s_a][$i]] eq "함정"){next;}
			if($c_lv[$tehuda[$s_a][$i]]<4 && $c_ap[$tehuda[$s_a][$i]]>$max_tmp){$max_tmp=$c_ap[$tehuda[$s_a][$i]];}
			if($c_lv[$tehuda[$s_a][$i]]<4 && $c_dp[$tehuda[$s_a][$i]]>$max_tmp){$max_tmp=$c_dp[$tehuda[$s_a][$i]];}
		}
	}
	for($i=5;$i<5*2;$i++){	#장에서 최강
		if($ap_fld[$i]>$max_tmp){$max_tmp=$ap_fld[$i];}
		if($dp_fld[$i]>$max_tmp){$max_tmp=$dp_fld[$i];}
	}
	if($max_tmp>=$max_pt){$win_flg=1;}
}

sub cpu_usemagic_1{

	if($t_nm eq "번개" || $t_nm eq "블랙홀" || $t_nm eq "갈라진 대지" || $t_nm eq "죽음의 매직·박스"){if($win_flg==0 && $max_pt>700){&use_card;}}
	elsif($t_nm eq "하피의 날개추" || $t_nm eq "허리케인"){if($mag_ariflg==1){&use_card;}}
	elsif($t_nm eq "빛의 호봉검" || $t_nm eq "악몽의 철함"){if($win_flg==0 && $kok[$s_a][0] eq ""){&use_card;}}
	elsif($t_nm eq "대폭풍우"){if(&maisu_count(3)-&maisu_count(2)>1){&use_card;}}

	elsif($m_koka{$cardno} eq "kill"){
		$seast="00991";
		$jokenst=$m_joken{$cardno};$go_hit=">0";
		if(&go_card_search){&use_card;}
	}
	elsif($c_syuzoku[$cardno] eq "장비" || $t_nm eq "유쾌한 장의사" || $t_nm eq "슬라임 증식로" || $t_nm eq "카드 파괴" || $t_nm eq "크로스 소울" || $t_nm eq "유언장" || $t_nm eq "천사의 주사위" || $t_nm eq "명계류 괴뢰방법"){}

	elsif($t_nm eq "혁명"){if($#{$tehuda[$s_d]}>2){&use_card;}}
	elsif($t_nm eq "무한의 명함"){if($kok[0][27] eq ""){&use_card;}}
	elsif($t_nm eq "평화의 사자"){if($kok[0][11] eq ""){&use_card;}}
	elsif($t_nm eq "제충 배리어"){if($kok[$s_a][46] eq ""){&use_card;}}
	elsif($t_nm eq "왕가의 신전"){if($kok[$s_a][54] eq ""){&use_card;}}
	elsif($t_nm eq "무덤 털기"){if($s_a==$turn2){&use_card;}}
	elsif($t_nm eq "트·월드"){if($toon_ariflg==1 && $lp[$s_a]>2000 && $kok[$s_a][4] eq ""){&use_card;}}
	elsif($t_nm eq "마음의 변화" || $t_nm eq "강탈"){if($kok[$s_d][0] eq ""){&use_card;}}
	elsif($t_nm eq "융합" || $t_nm eq "퓨전·게이트"){&cpu_usemagic_yugo;}
	elsif($c_syuzoku[$cardno] eq "필드"){if($fld[$fside[$s_a]]!=$cardno || $fld_rf[$fside[$s_a]]==1){&use_card;}}
	else{&use_card;}
}

sub cpu_usemagic_2{

	if($t_nm eq "흉포화의 가면" || $t_nm eq "천사의 주사위"){if($kok[$s_d][0] eq "" && $turn!=1){&use_card;}}
	elsif($c_syuzoku[$cardno] eq "장비"){&use_card;}
	elsif($t_nm eq "카드 파괴"){&use_card;}
	elsif($t_nm eq "유언장"){if($jok[2] ne ""){&use_card;}}
}

sub cpu_usemagic_yugo{
	local($i,$yu_c_bak);
	$seast="099910001";$jokenst="";&card_search;@mst_s=@res_s;
	if($#mst_s<1){return;}
	$fusebak=$F{'use'};
	for($i=0;$i<$#{$yugo[$s_a]}+1;$i++){
		$yu_c_bak=$#{$yugo[$s_a]};
		@select=@mst_s;push(@select,$i+600);
		$F{'use'}=$fusebak;&use_card;
		undef(@select);
		if($yu_c_bak!=$#{$yugo[$s_a]}){last;}
	}
}

sub cpu_cyc{
	if($cpu[$s_a]!=1){return 0;}
	$seast="90990001";$jokenst='$c_syuzoku[$cardno] eq "영속"';
	&card_search;
	if($res_s[0] eq ""){
		$seast="91990001";$jokenst='';
		&card_search;
		if($res_s[0] eq ""){return 1;}
	}
	$tmp = $res_s[0];undef(@res_s);$res_s[0]=$tmp;
	0;
}

sub cpu_usetrap{
	if($t_nm eq "신의 선고"){
		if($lp[$s_a]>3000){next;}
		if($pat==9 || $pat==10){&use_card;}
		else{$t_nm="승천의 각적";}
	}
	elsif($t_nm eq "죽음의 데크 파괴 바이러스" || $t_nm eq "은막의 경벽" || $t_nm eq "6망성의 주박" || $t_nm eq "어둠의 주박" || $t_nm eq "화목의 사자" || $t_nm eq "타임 머신" || $t_nm eq "매직컬 비단 모자" || $t_nm eq "악마의 주사위" || $t_nm eq "몬스터 BOX "){if($pat==3){&use_card;}}
	elsif($t_nm eq "디펜드·슬라임"){
		if($pat!=3 || $kok[$s_a][26] ne ""){}
		else{
			$seast="90991";$jokenst='$cardno==975';&card_search;
			if($#res_s>-1){&use_card;}
		}
	}
	elsif($t_nm eq "왕궁의 칙명"){if($pat==9){&use_card;}}
	elsif($t_nm eq "왕궁의 명령"){if($pat==10){&use_card;}}
	elsif($t_nm eq "아포피스의 화 신"){if($max_pt>1600){$F{'options'}=1;}&use_card;}
	elsif($t_nm eq "호 -리·에르프의 축복"){
		$cou=&maisu_count(0)+&maisu_count(1);if($cou>3){&use_card;}
	}
	elsif($t_nm eq "자업자득"){
		$cou=&maisu_count(1);if($cou>1){&use_card;}
	}
	elsif($t_nm eq "승천의 각적"){
		if($ap_fld[$t_fld1]>1500 || ($pat==2 && $c_koka[$fld[$t_fld1]]==7)){&use_card;}
	}
	elsif($t_nm eq "마법의 통" || $t_nm eq "호리쟈베린"){
		if(&not_taisyo($t_fld1)){next;}
		if($ap_fld[$t_fld1]>1800 || $t_damage>$lp[$s_a]){&use_card;}
	}
	elsif($t_nm eq "성스러운 방어막 거울의 힘"){
		if($t_damage>1800 || $t_damage>$lp[$s_a]){&use_card;}
		else{if(&maisu_count(1)>1){&use_card;}}
	}
	elsif($t_nm eq "희생의 제물" || $t_nm eq "끼워 공격해" || $t_nm eq "사령의 소" || $t_nm eq "혼 분쇄"){}
	elsif($t_nm eq "격류장"){if($win_flg==0 && $max_pt>700){&use_card;}}
	elsif($t_nm eq "맹렬한 회오리 해류벽"){if($kok[$s_a][61] eq "" && $pat==3){&use_card;}}
	else{&use_card;}
}

sub cpu_usekoka{
	local($i);

	for($i=$fw1[$s_a];$i<$fw1[$s_a]+5;$i++){
		if($c_koka[$fld[$i]]!=4 || $fld_rf[$i]==1){next;}
		$t_nm = $c_name[$fld[$i]];
		$F{'use'}="f_$i";

		if($t_nm=~/산 제물을 바침$/ || $t_nm eq "속사포 드래곤" || $t_nm eq "오벨리스크의 거신병" || $t_nm eq "라의 익신룡"){&use_card;}

		elsif($t_nm eq "시간의 마술사"){
			&usecard_chk;
			if($win_flg==0){&use_card;}
		}
		elsif($t_nm eq "성수 셀 케토"){if(length($fld_koka[$i])>15){&use_card;}}
	}
	$F{'use'}="";
}

sub cpu_combo{
	local($i);

	if($rule==1){return;}

	if($player[$s_a]==2){
		if($kok[0][1] eq ""){
			$seast="999900101";$jokenst='$cardno==706';&card_search;
			if($#res_s>-1){
				$seast="099900001";$jokenst='$c_syuzoku[$cardno] eq "드래곤" && $c_ap[$cardno]>1600';&card_search;
				if($#res_s>-1){
					$seast="91991";$jokenst='$cardno==705';&card_search;
					if($#res_s>-1){$chg[0]=$res_s[0];&change_mode;}
					else{
						$seast="999900001";$jokenst='$cardno==705';&card_search;
						if($#res_s>-1){
							$combo_tehudano=$res_s[0]-50;
							$F{'putcardno'}=$combo_tehudano."_a";
							&put_card;
						}
					}
				}
			}
		}
	}
	elsif($player[$s_a]==4){
		$seast="909911";$jokenst='$cardno==208 || $cardno==1037';&card_search;
		if($#res_s<0){
			$seast="999900101";$jokenst='$cardno==229';&card_search;
			if($#res_s>-1){
				$seast="999900001";$jokenst='$cardno==208 || $cardno==1037';&card_search;
				if($#res_s>-1){
					$combo_tehudano=$res_s[0]-50;
					$seast="9999000010001";$jokenst='$cardno==207 || $cardno==208 || $cardno==1037';&card_search;
					if($#res_s>0){
						$F{'putcardno'}=$combo_tehudano."_a";
						&put_card;
					}
				}
			}
		}
	}
	elsif($player[$s_a]==3){
		$seast="999900001";$jokenst='$cardno==678';&card_search;
		if($#res_s>-1){
			&usecard_chk;
			if($win_flg==0){
				$c_tmp=$res_s[0]-50;
				$F{'putcardno'}=$c_tmp."_a";&put_card;
			}
		}
	}
	elsif($player[$s_a]==24 && $kok[0][8] eq ""){
		for($i=0;$i<$#{$tehuda[$s_a]}+1;$i++){
			if($tehuda[$s_a][$i]==786 || $tehuda[$s_a][$i]==179){$F{'use'}="t_$i";&use_card;}
		}
	}
}

sub cpu_main_phase1{
	if($player[2]==6){&osiris_search;}
	if($syori[0].$chain[0].$chain2[0].$l_act ne ""){return;}

	&cpu_combo;
	if($syori[0].$chain[0].$chain2[0].$l_act ne ""){return;}

	&cpu_usecard(1);
	if($syori[0].$chain[0].$chain2[0].$l_act ne ""){return;}

	&cpu_usekoka(0);
	if($syori[0].$chain[0].$chain2[0].$l_act ne ""){return;}

	&cpu_putcard_think;
	&cpu_move_think1;

	if($call[$s_a] eq ""){&cpu_putcard_act;}
	if($syori[0].$chain[0].$chain2[0].$l_act ne ""){return;}

	if($kok[$s_a][4] ne ""){
		&cpu_put_toon;
		if($syori[0].$chain[0].$chain2[0].$l_act ne ""){return;}
	}

	&change_mode;
	if($syori[0].$chain[0].$chain2[0].$l_act ne ""){return;}

	&cpu_putcard_thinkm(1);
	if($#putm>-1){
		&put_card_mag;
		&get_apdp_fld;
	}

	&cpu_usekoka(1);
	if($syori[0].$chain[0].$chain2[0].$l_act ne ""){return;}

	&cpu_usecard(2);
	if($syori[0].$chain[0].$chain2[0].$l_act ne ""){return;}

	$phase=3;&get_apdp_fld;
}

sub cpu_main_phase2{
	&cpu_move_think2;
	&change_mode;
	if($#{$tehuda[$s_a]}+1>$tehuda_max){&cpu_putcard_thinkm(2);$put_card_mag;}
	if($jok[1] ne ""){&bphase_end;}
	$phase=5;
}

sub cpu_putcard_thinkm{
	local($mode)=$_[0];
	local($i);
	if($osiris_flg==1){return;}
	if($kok[$s_a][23] ne ""){return;}

	$cou=0;
	for($i=0;$i<5;$i++){if($fld[$i] ne ""){$cou++;}}
	if($mode==2){$cou--;}
	for($i=0;$i<$#{$tehuda[$s_a]}+1 && $cou<4;$i++){
		$tcno=$tehuda[$s_a][$i];
		if($c_zokusei[$tcno] eq "함정"){
			push(@putm,$i);$cou++;
		}
		elsif($player[$s_a]==20){}
		elsif($c_zokusei[$tcno] eq "마" && $c_syuzoku[$tcno] ne "필드"){
			$rann=rand;
			if($rule==1 || $rann<0.2){push(@putm,$i);$cou++;}
		}
	}
}

sub get_fld_arr{
	undef(@fld_tmp);
	for($j=$fw1[$s_a];$j<$fw1[$s_a]+5;$j++){
		if($fld[$j] eq ""){next;}
		push(fld_tmp,$j);
	}
	@fld_arr = sort ap_cre_res @fld_tmp;
}

sub get_aite_arr{
	undef(@aite_a_tmp);undef(@aite_d_tmp);undef(@huse_tmp);
	$toon_flg="";

	for($i=$fw1[$s_d];$i<$fw1[$s_d]+5;$i++){
		if($fld[$i] eq ""){next;}
		if($fld_rf[$i]==1 && $player[$s_a]!=5){push(@huse_tmp,$i);}
		elsif($fld_ad[$i]==1){push(@aite_d_tmp,$i);}
		else{push(@aite_a_tmp,$i);}

		if($c_syokan[$fld[$i]]==4){$toon_flg=1;}
	}
	@aite_a_arr = sort ap_cre_res @aite_a_tmp;
	@aite_d_arr = sort dp_cre_fld @aite_d_tmp;
}

sub cpu_putcard_think{
	local($i,$j);

	&fld_chk();
	if($nf0<0){return;}
	if($#{$tehuda[$s_a]}<0){return;}

	&cpu_put_toon;undef(@nie_s);
	if($call[$s_a] eq ""){$put_tehudano = &get_cpu_putno;}
}

sub cpu_put_toon{
	local($i);

	if($kok[$s_a][4] eq ""){return;}

	$toonrun_flg=0;
	while($toonrun_flg<99){$toonrun_flg++;
		$putno=&get_cpu_putno(1);
		if($putno eq ""){last;}
		$F{'putcardno'}=$putno."_a";
		&cpu_putcard_act;
	}
}

sub cpu_putcard_act{
	for($i=$fw1[$s_a];$i<$fw1[$s_a]+5;$i++){delete($F{'nie_'.$i});}
	for($i=0;$i<$#nie_s+1;$i++){$F{'nie_'.$nie_s[$i]}=1;}

	&put_card_mst;
	$F{'putcardno'}="";
}

sub get_cpu_putno{
	local($mode)=$_[0];
	local($i,$j,$putno);
	$putno="";

	undef(@tehuda_tmp);
	for($i=0;$i<$#{$tehuda[$s_a]}+1;$i++){
		$tmp=$tehuda[$s_a][$i];

		if($c_zokusei[$tmp] eq "함정" || $c_zokusei[$tmp] eq "마"){if($tmp==707){$crossflg="t_$i";}}
		elsif($c_syokan[$tmp]==4 && $mode==1){push(@tehuda_tmp,$i);}
		elsif($c_syokan[$tmp] ne "" && $c_syokan[$tmp]!=6 && $c_zokusei[$tmp] ne "신"){}
		elsif($player[$s_a]==24 && grep(/^$tmp$/,@exo)){}
		elsif($mode!=1){push(@tehuda_tmp,$i);}
	}
	for($i=0;$i<5;$i++){if($fld[$i]==707){$crossflg="f_$i";}}

	@tehuda_arr = sort ap_cre_tehuda @tehuda_tmp;

	if($rule==1){return $tehuda_arr[0];}

	&get_fld_arr;

	for($i=0;$i<$#tehuda_arr+1;$i++){
		$put_tmp=$tehuda[$s_a][$tehuda_arr[$i]];
		$tmp_lv = &lv_st($put_tmp);
		$tmp_ap = $c_ap[$put_tmp];
		if($put_tmp==923){$tmp_ap=$#{$tehuda[$s_a]} * 1000;}
		elsif($put_tmp==925 || $put_tmp==1099){$tmp_ap=4000;}

		if($tmp_lv<5){$putno=$tehuda_arr[$i];last;}
		elsif($tehuda_arr[$i]==1039 && $#{$tehuda[$s_a]}==0){$putno=$tehuda_arr[$i];last;}
		elsif($#fld_tmp<0){next;}

		if($kok[0][35] ne ""){next;}
		if($c_zokusei[$put_tmp] eq "신"){$yonie=3;}
		elsif($put_tmp==1214){
			$cou=0;
			for($k=$fw1[$s_d];$k<$fw1[$s_d]+5;$k++){
				if($fld[$k] ne ""){$cou++;}
				if($ap_fld[$k]>2800){$cou=10;}
			}
			if($cou>1){$yonie=3;}
			else{$yonie=2;}
		}
		elsif(6<$tmp_lv){$yonie=2;}
		else{$yonie=1;}

		undef(@nie_s);
		for($j=$#fld_arr;$j>=0;$j--){	#약한 순서
			$tmp=$fld_arr[$j];
			if($fld[$tmp]==1050 || $fld[$tmp]==974){next;}
			if($ap_fld[$tmp]>=$tmp_ap && $fld_koka[$tmp]!~/kokoro/){last;}
			if($put_tmp==723 && $fld[$tmp]==207){$tmp_ap+=300;next;}
			push(@nie_s,$tmp);
			if($#nie_s+1==$yonie){last;}
		}
		if($crossflg ne "" && $yonie-$#nie_s-1<2){
			$F{'use'}=$crossflg;
			$putcno=$tehuda[$s_a][$tehuda_arr[$i]];
			&use_card;
			if($res_s[0] ne ""){
				if($yonie-$#nie_s-1==1){push(@nie_s,$res_s[0]);}
				else{$nie_s[0]=$res_s[0];}
				$crossflg==2;
			}
		}
		if($put_tmp==1214 && $#nie_s+1==2){$yonie=2;}
		if($#nie_s+1>=$yonie){
			if($crossflg==2){
				for($j=0;$j<$#{$tehuda[$s_a]}+1;$j++){if($tehuda[$s_a][$j]==$putcno){last;}}$putno=$j;}
			else{$putno=$tehuda_arr[$i];}
			last;
		}
	}
	return $putno;
}

sub apup{
	local($tmp)=$_[0];
	if($tmp==1022){$ap_up+=800*$#battle_arr;}
	elsif($tmp==1023){$ap_up+=800*$#battle_arr;}
	elsif($c_syuzoku[$tmp] eq "장비" && $m_koka{$tmp}=~/^(\d+)::([-\d]+)$/){$ap_up+=$1;}
}

sub cpu_move_think24{
	if($put_tehudano ne ""){$F{'putcardno'}=$put_tehudano."_d";}
}

sub cpu_move_think1{
	local($i);
	if($player[$s_a]==24){&cpu_move_think24;return;}

	$all_attack = 0;
	undef(@chg);

	&get_aite_arr;

	undef(@attack_fld);
	undef(@battle_tmp);

	for($j=$fw1[$s_a];$j<$fw1[$s_a]+5;$j++){
		if($fld[$j] eq "" || $a_b[$j]==1){next;}

		if($c_syokan[$fld[$j]]==4 && $toon_flg!=1){$attack_fld[$j]=1;}
		elsif($c_koka[$fld[$j]]==13 || $fld[$j]==929){$attack_fld[$j]=1;}
		elsif($c_koka[$fld[$j]]==7 && $fld_rf[$j]==1 && $fld[$j]!=166){$attack_fld[$j]=1;push(@battle_tmp,$j);}
		elsif($fld[$j]==1036 && $fld_rf[$j]==1){&pt_chk;if($max_ap>0){$attack_fld[$j]=1;push(@battle_tmp,$j);}}
		elsif($kok[0][5] ne "" && $c_lv[$fld[$j]]>3){next;}
		elsif($kok[0][11] ne "" && $ap_fld[$j]>=1500){next;}
		elsif($c_koka[$fld[$j]]==6){next;}
		elsif($ap_fld[$j]==0){next;}
		else{push(@battle_tmp,$j);}
	}

	$put_cno=$tehuda[$s_a][$put_tehudano];
	if($put_tehudano ne "" && ($c_koka[$put_cno]!=7 || $put_cno==1103) && $c_koka[$put_cno]!=13 && $put_cno!=995){
		push(@battle_tmp,20);
		$ap_fld[20]=$c_ap[$tehuda[$s_a][$put_tehudano]];
		$dp_fld[20]=$c_dp[$tehuda[$s_a][$put_tehudano]];
		if($ap_fld[20] eq "X000"){$ap_fld[20]=1000*$#{$tehuda[$s_a]};$dp_fld[20]=1000*$#{$tehuda[$s_a]};}
		elsif($ap_fld[20] eq "XXXX"){$ap_fld[20]=4000;$dp_fld[20]=4000;}
		elsif($tehuda[$s_a][$put_tehudano]==1036){&pt_chk;$ap_fld[20]=$max_ap;}
	}

	@battle_arr = sort ap_cre_res @battle_tmp;

	undef(@a_b_dummy);
	if($#aite_a_arr<0 && $#aite_d_arr<0){
		$all_attack = 1;
	}
	elsif($turn==1 || $kok[$s_d][0] ne ""){}

	else{
		$notwin = 0;

		$ap_up=0;
		for($i=0;$i<$#{$tehuda[$s_a]}+1;$i++){&apup($tehuda[$s_a][$i]);}
		for($i=0;$i<5;$i++){&apup($fld[$i]);}

		for($i=0;$i<=$#battle_arr;$i++){
			$battle_ap = $ap_fld[$battle_arr[$i]];
			if($i==0){$battle_ap+=$ap_up;}

			if($#aite_a_arr<0 && $#aite_d_arr<0){
				$attack_fld[$battle_arr[$i]]=1;next;
			}

			for($j=$#aite_a_arr;$j>-1;$j--){
				if($battle_ap>=$ap_fld[$aite_a_arr[$j]]){
					$attack_fld[$battle_arr[$i]]=1;
					$a_b_dummy[$i]=1;
					$aite_a_arr[$j]="";&del_null2(*aite_a_arr);last;
				}
			}
			if($a_b_dummy[$i] ne ""){next;}

			for($j=0;$j<$#aite_d_arr+1;$j++){
				if($battle_ap>$dp_fld[$aite_d_arr[$j]]){
					$attack_fld[$battle_arr[$i]]=1;
					$a_b_dummy[$i]=1;
					$aite_d_arr[$j]="";&del_null2(*aite_d_arr);last;
				}
			}
			if($a_b_dummy[$i] ne ""){next;}

			$notwin=1;last;
		}

		if($notwin==0){
			$all_attack = 1;
		}
		else{
			for($i0=$i;$i0<$#huse_tmp+1 && $i0<$#battle_arr+1;$i0++){
				if($ap_fld[$battle_arr[$i0]]<1000){last;}
				$attack_fld[$battle_arr[$i0]] = 1;
			}
		}
	}

	push(@aite_a_arr,@aite_d_arr);
	@aite_tmp = sort ap_cre_res @aite_a_arr;
	$aite_maxap = $ap_fld[$aite_tmp[0]];

	for($i=$fw1[$s_a];$i<$fw1[$s_a]+5+1;$i++){

		if($i==$fw1[$s_a]+5){if($put_tehudano ne ""){$i=20;}else{last;}}
		elsif($fld[$i] eq ""){next;}
		if($attack_fld[$i]==1){}
		elsif($ap_fld[$i]==0){$attack_fld[$i]=2;}
		elsif($all_attack==1){$attack_fld[$i]=1;}
		elsif($dp_fld[$i]-$ap_fld[$i]>1000){$attack_fld[$i]=2;}
		elsif($ap_fld[$i]<$aite_maxap){$attack_fld[$i]=2;}
		elsif($ap_fld[$i]>$dp_fld[$i]){$attack_fld[$i]=1;}
		else{$attack_fld[$i]=2;}

		if($i==20 && (($c_koka[$put_cno]==7 && $put_cno!=1103) || $put_cno==995 || $put_cno==1026)){$F{'putcardno'}=$put_tehudano."_d";}
		elsif($i==20 && $c_koka[$put_cno]==13){$F{'putcardno'}=$put_tehudano."_a";}
		elsif($i==20 && $attack_fld[$i]==1){$F{'putcardno'}=$put_tehudano."_a";}
		elsif($yonie==3){$F{'putcardno'}=$put_tehudano."_a";}
		elsif($i==20 && $attack_fld[$i]==2){$F{'putcardno'}=$put_tehudano."_d";}
		elsif($attack_fld[$i]==1 && $fld_ad[$i]==1){push(@chg,$i);}
	}
}

sub cpu_move_think2{
#전투 종료후의 표시 변경
	local($i);
	undef(@chg);

	&pt_chk;

	for($i=$fw1[$s_a];$i<$fw1[$s_a]+5;$i++){
		if($fld[$i] eq "" || $a_m[$i] ne ""){next;}

		if($ap_fld[$i]<$max_ap){if($fld_ad[$i]!=1){push(@chg,$i);}}
		elsif($ap_fld[$i]<600 || $player[$s_a]==24){if($fld_ad[$i]!=1){push(@chg,$i);}}
		elsif($ap_fld[$i]>=$dp_fld[$i]){if($fld_ad[$i]==1){push(@chg,$i);}}
		elsif($fld_ad[$i]!=1){push(@chg,$i);}
	}
}

sub cpu_battle_phase{
	local($i,$j,$i0);

	if($turn==1 || $kok[$s_d][0] ne "" || $kok[$s_d][10] ne "" || $hk[3] ne "" || $lp[$s_a]<=$kok[0][20]*500){$phase=4;return;}

	undef(@battle_tmp);undef(@toon_tmp);
	for($j=$fw1[$s_a];$j<$fw1[$s_a]+5;$j++){
		if($fld[$j] eq "" || $fld_ad[$j]==1 || $a_b[$j]==1 || $ap_fld[$j]==0){next;}
		if($c_syokan[$fld[$j]]==4 && $a_m[$j]==1){next;}
		elsif($c_syokan[$fld[$j]]==4 && $toon_flg!=1){push(@toon_tmp,$j);}
		elsif($c_koka[$fld[$j]]==13){push(@toon_tmp,$j);}
		else{push(@battle_tmp,$j);}
	}

	for($i=0;$i<$#toon_tmp+1;$i++){
		$b_fld[0]=$toon_tmp[$i];$b_fld[1]="player";&battle_run;
		if($syori[0].$chain[0].$chain2[0] ne ""){return;}
	}

	if($#battle_tmp<0){$phase=4;return;}
	@battle_arr = sort ap_cre_res @battle_tmp;	#공격력순에 소트

	undef(@b_chk);
	for($b_i=0;$b_i<$#battle_arr+1;$b_i++){
		$battle_ap = $ap_fld[$battle_arr[$b_i]];

		&get_aite_arr;

		if($#aite_a_arr<0 && $#aite_d_arr<0 && $#huse_tmp<0){
			if(&cpu_battle_act("player")){return;}
			next;
		}

		if($fld[$battle_arr[$b_i]]==929){$rocket=1;}else{$rocket="";}

		for($b_j=$#aite_a_arr;$b_j>-1;$b_j--){
			if($battle_ap>=$ap_fld[$aite_a_arr[$b_j]] || $rocket==1){
				if(&cpu_battle_act($aite_a_arr[$b_j])){return;}
				last;
			}
		}

		if($b_j>-1){next;}

		for($b_j=0;$b_j<$#aite_d_arr+1;$b_j++){
			if($battle_ap>$dp_fld[$aite_d_arr[$b_j]] || $rocket==1){
				if(&cpu_battle_act($aite_d_arr[$b_j])){return;}
				last;
			}
		}
		if($b_j<$#aite_d_arr+1){next;}

		for($b_j=0;$b_j<$#huse_tmp+1;$b_j++){
			if($battle_ap>700){
				if(&cpu_battle_act($huse_tmp[$b_j])){return;}
				last;
			}
		}
		if($b_j<$#huse_tmp+1){next;}

		last;
	}
	$phase=4;
}

sub cpu_battle_act{
	local($taisyo)=$_[0];
	$b_fld[0]=$battle_arr[$b_i];
	$b_fld[1]=$taisyo;

	$b_chk[$b_i]++;
	&battle_run;
	if($a_b[$battle_arr[$b_i]]==2 && $b_chk[$b_i]==1){$b_i--;}
	if($chain[0].$syori[0].$chain2[0] ne ""){return 1;}
}


sub del_null2{
	local(*arr) = @_;
	local($i,@arr_stack);

	for($i=0;$i<$#arr+1;$i++){
		if($arr[$i] ne ""){push(arr_stack,$arr[$i]);}
	}
	@arr = @arr_stack;
}

sub cpu_sutehuda{
	local($i);

	if($cpu[$s_a]!=1){return;}
	&del_nullt($s_a);
	$seast="999900001";$jokenst='';&card_search;
	if($player[$s_a]==24){
		&exo_sort_set;
		@t_sort2=sort {$t_val[$a] cmp $t_val[$b];} @t_sort;
		for($i=0;$i<$#t_sort2+1;$i++){$res_s[$i]=$t_sort2[$i]+50;}
	}
	@select=@res_s;
}

sub exo_sort_set{
	local($i);
	undef(%exo_chk);undef(@t_sort);undef(@t_val);
	for($i=0;$i<$#{$tehuda[$s_a]}+1;$i++){
		$t_sort[$i]=$i;
		$tmp=$tehuda[$s_a][$i];
		if(grep(/^$tmp$/,@exo)){
			if($exo_chk{$tmp} eq ""){$t_val[$i]=2;}
			else{$t_val[$i]=0;}
			$exo_chk{$tmp}=1;
		}
		else{$t_val[$i]=1;}
	}
}

sub exo_sort{
	local($i);undef(@res_s2);undef(@res_s3);
	for($i=0;$i<$#res_s+1;$i++){
		$cno=&getf_res($res_s[$i]);
		if(grep(/^$cno$/,@exo) && $exo_chk{$cno} eq ""){push(@res_s2,$res_s[$i]);$exo_chk{$cno}=1;}
		else{push(@res_s3,$res_s[$i]);}
	}
	push(@res_s2,@res_s3);
}

sub cpu_get_saikyo{
	local($seast)=$_[0];
	local($jokenst)=$_[1];
	local($gohit)=$_[2];
	local($saijaku)=$_[3];
	local($i);
	if($cpu[$s_a]!=1){return;}

	if($seast ne "" || $jokenst ne ""){&card_search;}
	if($player[$s_a]==24){&exo_sort_set;&exo_sort;}
	else{@res_s2 = sort ap_cre_res @res_s;}

	undef(@res_s);
	if($#res_s2<0){return 1;}
	if($gohit ne ""){
		for($i=0;$i<$gohit && $i<$#res_s2+1;$i++){$res_s[$i]=$res_s2[$i];}
	}
	elsif($saijaku==1){$res_s[0]=$res_s2[$#res_s2];}
	else{$res_s[0]=$res_s2[0];}
	0;
}


1;
