#!/usr/bin/perl
require "data.lib";

print "Content-type:text/html; charset=utf-8\n\n";

&get_input;
&get_ini2;

$st="<table border=1>\n<tr align=center><td>대전 상대</td><td>승리</td><td>패배</td><td>무승부</td></tr>\n";
@tmp=split(":",$F{'shohai'});
($win,$lose,$draw)=split(/-/,$tmp[13]);
$st.="<tr><td>$name[13]</td><td>$win</td><td>$lose</td><td>$draw</td></tr>\n";
($win,$lose,$draw)=split(/-/,$tmp[25]);
$st.="<tr><td>$name[25]</td><td>$win</td><td>$lose</td><td>$draw</td></tr>\n";
for($i=0;$i<$#name+1;$i++){
	if($i==13 || $i==25){next;}
	($win,$lose,$draw)=split(/-/,$tmp[$i]);
	$st.="<tr><td>$name[$i]</td><td>$win</td><td>$lose</td><td>$draw</td></tr>\n";
}
$st.="</table>\n";

print<<"_EOF_";
<html>
<title>성적</title>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=utf-8">
<META HTTP-EQUIV="pragma" CONTENT="no-cache">
<body bgcolor=#fffff0 background="embak.gif">
<h3 align=center>$id의 대전 성적</h3>
<center>
$st
<hr>
<a href="index.cgi?id=$id">돌아가기</a><br>
</body></html>
_EOF_

sub get_ini2{	#스타트시 읽기

	$tmpflg=0;
	if(-r "tmp/".$id."_pfl"){
		open(PFL,"tmp/".$id."_pfl");
	}
	else{
		open(PFL,"tmp/org_pfl");
		open(OPFL,">tmp/".$id."_pfl");
		$tmpflg=1;
	}

	while(<PFL>){
		if($tmpflg==1){print OPFL;}
		chop;
		($KEY,$VAL) = split(/\t/);
		if($F{$KEY} eq ""){	#파라미터 인도를 우선
			$F{$KEY} = $VAL;
		}
	}
	close(PFL);

	for($i=0;$i<$#pflst+1;$i++){
		$evalst = "\@$pflst[$i] = split(/,/,\$F{\"$pflst[$i]\"})";
		eval($evalst);
	}
}

sub get_input{
	if (length($ENV{'QUERY_STRING'}) > 0) {
		$INPUT = $ENV{'QUERY_STRING'};
	}
	elsif (length($ENV{'CONTENT_LENGTH'}) > 0) {
		read(STDIN, $INPUT, $ENV{'CONTENT_LENGTH'});
	}
	else {
		while ($TMP[0] = <STDIN>) {
			$INPUT .= $TMP[0];
		}
	}

	$INPUT =~ s/\&+/\&/g;
	$INPUT =~ s/#.+//;
	@TMP = split('&', $INPUT);
	for ($i = 0; $i <= $#TMP; ++$i) {
		($KEY, $VAL) = split('=', $TMP[$i]);
		$VAL =~ tr/+/ /;
		$VAL =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
#		$VAL =~ s/\015\012/\012/g;
#		$VAL =~ s/\015/\012/g;
		if($VAL ne ""){$F{$KEY}=$VAL;}
	}

	$cookie=$ENV{'HTTP_COOKIE'};
	if($F{'id'} ne ""){$id = $F{'id'};}
	elsif($cookie ne ""){$id=$cookie;$id=~s/^id=//;}

	if($id eq ""){$id=$$;}
	$id=~s/\.//g;
	$id=~s/\///g;
}
