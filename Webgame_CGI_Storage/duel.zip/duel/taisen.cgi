#!/usr/bin/perl
#대전

require "data.lib";
@daysu=(0,0,31,59,90,120,151,181,212,243,273,304,334,365);

$wfile="tmp/word.txt";

&get_input;
($sec,$min,$hour,$mday,$mon,$year) = localtime(time);
if(length($min)<2){$min="0$min";}
if(length($hour)<2){$hour="0$hour";}
if(length($mday)<2){$mday="0$mday";}
$mon++;
if(length($mon)<2){$mon="0$mon";}
$date=$mon.$mday.$hour.$min.$year;
$n_dat="$hour:$min";
$n_min=&get_min($date);

if($F{'nam'} ne "" && $F{'word'} ne ""){&put_word;}

if ($ENV{'HTTP_ACCEPT_ENCODING'}=~/gzip/ && $gzip ne "") {
	print "Content-type: text/html; charset=utf-8\n";
	print "Content-encoding: gzip\n\n";
	open(STDOUT,"| ".$gzip."gzip -1 -c");
}else{
	print "Content-type: text/html; charset=utf-8\n\n";
}

if($F{'mode'} eq "view"){&view_list;}

sub view_list{
	print<<"_EOF_";
<html>
<title>로그</title>
<META HTTP-EQUIV="Pragma" CONTENT="no-cache">
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=utf-8">
<body bgcolor=#fffff0 background="embak.gif">
<center>
<b>일행 전언판 로그</b><br>
</center>
<blockquote>
_EOF_
	open(IN,$wfile);
	while(<IN>){
		print;
		print "<hr>\n";
	}
	print<<"_EOF_";
</blockquote>
<hr>
<center><a href="taisen.cgi?id=$id">돌아가기</a><br>
</body></html>
_EOF_
	exit;
}

sub put_word{
	open(IN,$wfile);
	open(TMP,">$wfile.tmp");
	$F{'nam'}=~s/<//g;$F{'word'}=~s/<//g;
	print TMP "$F{'nam'}：$F{'word'}<FONT SIZE=-1>($n_dat)</font><br>\n";
	$cou=0;
	while(<IN>){print TMP;$cou++;if($cou>48){last;}}
	close(IN);close(TMP);
	open(IN,">$wfile");
	open(TMP,"$wfile.tmp");
	while(<TMP>){print IN;}
	close(IN);close(TMP);

	print "Location:taisen.cgi?id=$id&mode=view\n\n";
	exit;
}

&get_ini2;
&get_ini;

if($G{'player2'} eq ""){$G{'player2'}=1;}

@tmp=split(":",$F{'shohai'});
$win_a=0;$lose_a=0;$draw_a=0;
for($i=0;$i<$#tmp+1;$i++){
	($win,$lose,$draw)=split(/-/,$tmp[$i]);
	$win_a+=$win;$lose_a+=$lose;$draw_a+=$draw;
}

$selst[$G{'player1'}]=" selected";
$selst2[$G{'player2'}]=" selected";
if($P{'seigen'} ne ""){$selst4[$P{'seigen'}]=" selected";}
$deckno=$#deck+1;

print<<"_EOF_";
<html>
<title>대전</title>

<META HTTP-EQUIV="Pragma" CONTENT="no-cache">
<body bgcolor=#fffff0 background="embak.gif">
<FONT SIZE=-1>
※<b>플레이 전에 「대전에서의 주의」를 읽어 주세요. </b><br>
※서버에 부하가 걸리므로 , 버튼을 짧은 간격으로 연타하지 않을 것. 상대를 위해 갑작스럽게 하지 않을 것. <br>
※도중에 떨어졌을 경우 , 5분 이내라면 「상태를 본다」로부터 들어가면 게임에 복귀할 수 있습니다. <br>
※<FONT color=red>$natime분간 액세스가 없는 경우 , 액세스가 없는 쪽의 패배가 됩니다. </font><br>
</font>
<blockquote>
<form action="duel.cgi">
듀얼네임：$id　
<input type=hidden name=id value="$id">
<input type=hidden name=start value=on>
플레이어
<select name="player1">
_EOF_
for($i=0;$i<$#name+1;$i++){
	if($i==9 || $i==13 || $i==25){next;}
	print "<option value=$i$selst[$i]>$name[$i]\n";
}
print<<"_EOF_";
</select>
<select name="rule">
<option value=0>신전문가 룰
<option value=1>쥬니어 룰
</select>
<br>
이름(공난가능)<input type=text size=8 name="name" value="$P{'name'}">
　제한
<select name="seigen">
<option value=1>있음
<option value=0$selst4[0]>없음
<option value=2$selst4[2]>금지
<option value=3$selst4[3]>OCG 
<option value=4$selst4[4]>비1kill
</select>
　시합 형식
<select name="match">
<option value="">한판
<option value="on">매치
</select>
<hr>
<center>
<br>
현재 시각：$n_dat
　<b><a href="$help#taisen" target=new>대전에서의 주의</a>
　<a href="etc.html" target=new>다른 듀얼장</a>
　<a href="http://board.blueweb.co.kr/board.cgi?id=FusionX&bname=free" target=new>통합 게시판</a>
<br>
</b>
<table border=1><tr valign=top>
_EOF_

for($i=1;$i<$heyakazu+1;$i++){
	print "<td>";
	$notflg=0;
	undef(%G);

	print "<b>방 번호 $i</b><br>\n";

	for($j=1;$j<3;$j++){
		$tfn="tmp/".$roomst.$i."_time".$j;
		if(!(-e $tfn)){$t_date[$j]=0;}
		else{
			if(-z $tfn){$t_date[$j]=$date;}
			else{
				open(TIME,$tfn);
				$_=<TIME>;($t_date[$j],$dum)=split(/\t/);close(TIME);
			}
		}
	}
	if($t_date[1]<$t_date[2]){$t_date[1]=$t_date[2];}

	$t_min=&get_min($t_date[1]);
	$t_dat=&make_date($t_date[1]);

	if($n_min-$t_min>5){
		print "사람이 없습니다. <br>\n";
		print "<font size=-1><a href=\"duel.cgi?room=$i\">전의 기록 보기</a></font><br>\n";
	}
	else{
		open(IN,"tmp/".$roomst.$i);
		while(<IN>){chop;($key,$val)=split(/\t/);$G{$key}=$val;}
		if($G{'side1'} eq "" && $G{'side2'} ne ""){
			print "대전 상대를 기다리고 있습니다. <br>\n";
			if($G{'pn2'} ne ""){$nam=$G{'pn2'};}
			else{$nam=$name[$G{'player2'}];}
			print "이름：$nam<br>\n";
			print "룰：";
			if($G{'rule'}==0){print "신전문가 룰<br>\n";}
			else{print "쥬니어 룰<br>\n";}
			print "제한：";
			if($G{'seigen'}==1){print "있음<br>\n";}
			elsif($G{'seigen'}==2){print "금지<br>\n";}
			elsif($G{'seigen'}==3){print "OCG <br>\n";}
			elsif($G{'seigen'}==4){print "비1kill<br>\n";}
			else{print "없음<br>\n";}
			if($G{'match'} eq "on"){print "<b><i>매치전</i></b><br>\n";}
			print "최종 체크：$t_dat<br>\n";
			print "<a href=\"duel.cgi?room=$i&id=$id\">상태를 본다</a><br>\n";
		}
		else{
			print "사용중입니다. <br>\n";
			print "최종 체크：$t_dat<br>\n";
			print "<a href=\"duel.cgi?room=$i&id=$id\">상태를 본다</a><br>\n";
			$notflg=1;
		}
	}

	if($notflg==0){
		print "<center><input type=submit name=\"room_$i\" value=\"입실\"></center><br>\n";
	}

	print "</td>\n";
	if(($i-1)%4==3){print "</tr><tr valign=top>";}
}

print<<"_EOF_";
</tr></table>
<br>
</blockquote>
</center>
</form>
_EOF_

if($itigyou ne "0"){
	print<<"_EOF_";
<form action="taisen.cgi" method=post>
<input type=hidden name="id" value="$id">
<input type=hidden name="mode" value="view">
<center>────────────────────　자유 발언　────────────────────</center><br>
</font><br>
Name<input type=text size=8 name="nam" value="$P{'name'}">
　Word<input type=text size=30 name="word">
 <input type=submit value="쓰기">
<FONT SIZE=-1><a href="taisen.cgi?mode=view&id=$id">전건 표시</a></font>
<br>
<hr>
<blockquote>
_EOF_

	open(IN,$wfile);$cou=0;
	while(<IN>){
		print;
		$cou++;if($cou>=$itigyou){last;}
		print "<hr>\n";
	}
}

print<<"_EOF_";
</blockquote>
<hr>
<center><a href="index.cgi?id=$id">돌아가기</a><br>
</body></html>
_EOF_

sub make_date{
	local($dat)=$_[0];
	$tmp=substr($dat,4,2);
	$tmp.=":".substr($dat,6,2);
	return $tmp;
}

sub get_min{
	local($dat)=$_[0];
	$tmp=substr($dat,6,2);
	$tmp+=substr($dat,4,2)*60;
	$tmp+=substr($dat,2,2)*60*24;
	$tmp+=$daysu[substr($dat,0,2)]*60*24;
	$tmp+=substr($dat,8,2)*60*24*365;
	return $tmp;
}

sub get_ini2{	#스타트시 읽기

	$tmpflg=0;
	if(-r "tmp/".$id."_pfl"){
		open(PFL,"tmp/".$id."_pfl");
	}
	else{@deck=@defo;return;}

	while(<PFL>){
		chop;
		($KEY,$VAL) = split(/\t/);
		if($F{$KEY} eq ""){	#파라미터 인도를 우선
			$P{$KEY} = $VAL;
		}
	}
	close(PFL);
}

sub get_ini{

	if(-r "tmp/$id"){
		open(PFL,"tmp/$id");
	}
	else{
		return;
	}

	while(<PFL>){
		chop;
		($KEY,$VAL) = split(/\t/);
		if($G{$KEY} eq ""){	#파라미터 인도를 우선
			$G{$KEY} = $VAL;
		}
	}
	close(PFL);
}

sub get_input{
	if (length($ENV{'QUERY_STRING'}) > 0) {
		$INPUT = $ENV{'QUERY_STRING'};
	}
	elsif (length($ENV{'CONTENT_LENGTH'}) > 0) {
		read(STDIN, $INPUT, $ENV{'CONTENT_LENGTH'});
	}
	else {
		while ($TMP[0] = <STDIN>) {
			$INPUT .= $TMP[0];
		}
	}

	$INPUT =~ s/\&+/\&/g;
	$INPUT =~ s/#.+//;
	@TMP = split('&', $INPUT);
	for ($i = 0; $i <= $#TMP; ++$i) {
		($KEY, $VAL) = split('=', $TMP[$i]);
		$VAL =~ tr/+/ /;
		$VAL =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
		$VAL =~ s/\015\012/\012/g;
		$VAL =~ s/\015/\012/g;
		if($VAL ne ""){$F{$KEY}=$VAL;}
	}

	$id=$F{'id'};
	$id=~s/\.//g;
	$id=~s/\///g;
	$id=~s/<//g;
	if($id=~/^$roomst[0-9]/){print "이 듀얼네임은 사용할 수 없습니다. 이름을 변경해 주세요.<br>";exit;}
}
