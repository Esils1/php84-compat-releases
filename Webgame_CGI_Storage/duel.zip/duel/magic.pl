
sub use_card{
	local($i,$val,$use_f_no,$use_t_no,$use_cno,$kekka,$t_nm);

	if($cont_flg==1){if(&chaintosel){$cont_flg="";&go_boti($use_f_no);return;}}
	else{
		$val=$F{'use'};
		if($val eq ""){return;}

		if($val =~ s/^f_//){
			$use_cno = $fld[$val];
			$use_from = "f";
			$use_f_no = $val;
			if($c_zokusei[$use_cno] ne "함정" && $c_zokusei[$use_cno] ne "마"){if(&kinsi_chk2($use_f_no)){return;}}
			elsif($hk[30] ne ""){&add_msg("null","!$s_a(대한파가 발동하고 있다)");return;}
		}
		elsif($val =~ s/^t_//){
			$use_cno = $tehuda[$s_a][$val];
			$use_from = "t";
			$use_t_no = $val;$use_f_no = "";

			$through="";
			if($c_zokusei[$use_cno] ne "마" && $c_zokusei[$use_cno] ne "함정"){
				if($use_cno!=378 && $use_cno!=371){$through=1;}
			}
			else{
				if($hk[30] ne ""){&add_msg("null","!$s_a(대한파가 발동하고 있다)");return;}
				if($c_syuzoku[$use_cno] ne "필드" && &akichk2()){return;}
			}

			if($through!=1){
				if(&kase_chk){return;}
				if($rule==1){return;}
				if(&kinsi_chk($val)){return;}
			}
		}
	}

	if($kok[0][6] ne "" && $c_zokusei[$use_cno] eq "함정" && $cont_flg!=1){&add_msg("null","!$s_a(사이코·손카가 장소에 있는 한 , 함정을 사용할 수 없다! )");return;}

	$t_nm=$c_name[$use_cno];
	$tmp_syorip="<>c-6-$F{'use'}<>i-$s_a";$F{'use'}="";$F{'usecard'}="";

	$go_hit=1;$go_msg="";undef(@res_s);
	$kekka="";$jokenst='';$seast='';

	if($c_zokusei[$use_cno] eq "마" || $t_nm eq "리빙 데드의 부르는 소리"){$kekka=&use_magic;}
	elsif($c_zokusei[$use_cno] eq "함정"){$kekka=&use_trap;}
	elsif($use_from eq "t"){$kekka=&use_koka_3($use_t_no);}
	else{$kekka=&use_koka_4($use_cno);}
	if($kekka==1){&end_usecard(0);}
	elsif($cont_flg==1 && $umuko eq ""){&end_usecard(2);}
}

sub use_magic{
	local($i,$j,$tsno);

	if($t_nm =~ /^죽음의 메세지/){&add_msg("null","!$s_a(위쟈반의 효과 이외로 사용할 수 없다)");return;}

	elsif($c_syuzoku[$use_cno] eq "장비" && $m_koka{$use_cno} ne ""){
		$seast="901911";$jokenst=$m_joken{$use_cno};
		if($c_name[$use_cno] eq "자력의 반지"){$seast="90191";}
		if($cpu[$s_a]==1){
			if($t_nm eq "거대화" && $lp[$s_a]>=$lp[$s_d]){return;}
			$jokenst.=' && $fld_koka[$res_si]!~/kokoro/';
			$jokenst=~s/^ \&\&//;
		}
		$go_msg="(대상이 존재하지 않는다. 또는 표리시이므로 장비 할 수 없다)";
		if(&go_card_search){return;}

		if($cpu[$s_a]==1){
			if($use_cno==988 || $use_cno==1079){if(&cpu_get_saikyo("901901",$jokenst)){return;}}
			elsif(&cpu_get_saikyo("90191",$jokenst)){return;}
			if($t_nm=~/^날씨/ && ($ap_fld[$res_s[0]]<1700 || $fld_koka[$res_s[0]]=~/meteo/)){return;}
			if($t_nm=~/^자력/ && (($ap_fld[$res_s[0]]<2500 && $dp_fld[$res_s[0]]<2500) || $fld_koka[$res_s[0]]=~/jiryoku/)){return;}
		}

		if(&used){return;}
		if($fld[$use_f_no] eq ""){return;}

		&add_msg("null",$m_msg{$use_cno});
	}

	elsif($m_koka{$use_cno} eq "kill"){
		$seast="009911";
		$jokenst=$m_joken{$use_cno};$go_hit=">0";
		if(&go_card_search){return;}
		@kill_arr=@res_s;

		if(&used){return;}
		&add_msg("null",$m_msg{$use_cno});
		for($i=0;$i<$#kill_arr+1;$i++){
			if(!(&fisher($kill_arr[$i]))){&go_boti($kill_arr[$i]);}
		}
	}
	elsif($t_nm eq "집단 학살·워"){
		if($phase!=2){&add_msg("null","!$s_a(메인페이즈 1밖에 사용할 수 없다)");return;}
		if(&used){return;}
		&add_msg("null","학살 전쟁이 시작된다! ");
		$hk[33]=1;$jok[1]=1;
	}
	elsif($t_nm eq "도적의 비법"){
		$seast="991611";
		if(&go_card_search){return;}
		if(&used){return;}
		&add_msg("null","환영 여단의 단장이 나타났다! ");
		&add_msg("클로로","스킬 헌터! ");
		&add_msg("null","상대의 카드를 훔친다! ");
		$fld_koka[$res_s[0]].="skill_$turn<>";
	}
	elsif($t_nm eq "천변지이"){
		if(&used){return;}
		&add_msg("null","덱이 뒤집혔다! ");
		for($i=0;$i<2;$i++){
			$tsno=$sno[$i];undef(@tmp_arr);
			for($j=$#{$deck[$tsno]};$j>-1;$j--){push(@tmp_arr,$deck[$tsno][$j]);}
			&add_msg("null","$pn[$tsno]의 맨 위…$c_name[$deck[$tsno][0]]");
		}
	}
	elsif($t_nm eq "어둠을 싹 지우는 빛"){
		if(&used){return;}
		&add_msg("null","쏟아지는 빛이$pn[$s_d]의 장소를 비추었다! ");
		for($u_i=$fw1[$s_d];$u_i<$fw1[$s_d]+5;$u_i++){if($fld_rf[$u_i]==1){&reverse($u_i);}}
	}
	elsif($t_nm eq "대한파"){
		if($cont_flg!=1 && ($phase!=2 || $jok[7] ne "")){&add_msg("null","!$s_a(메인페이즈의 최초로 밖에 사용할 수 없다)");return;}
		if(&used){return;}
		&add_msg("null","장소는 눈과 얼음 에 갇혔다! <br>다음의 것$pn[$s_a]의 턴까지 서로 마법·함정을 플레이 할 수 없다! ");
		$hk[30]=$turn;
	}
	elsif($t_nm eq "웜·홀"){
		$seast="99161";
		if(&go_card_search){return;}
		if(&used){return;}
		$moto=&which_side($res_s[0]);$moto=$sno[$moto];
		@tmp=split(/<>/,$fld_koka[$res_s[0]]);
		for($i=$#tmp+1;$i>-1;$i--){if($tmp[$i]=~/^teni_([12])/){last;}}
		if($i>-1){$teni=$sno[$1];}
		if($fld_koka[$res_s[0]]=~/irr<>/){$irrflg=1;}else{$irrflg="";}
		$worm.="$res_s[0]-$fld[$res_s[0]]-$fld_rf[$res_s[0]]-$fld_ad[$res_s[0]]-$moto-$teni-$irrflg<>";
		&add_msg("null","차원의 충해구멍이 발생! <br>몬스터는 빨려 들여갔다! ");
		&syometu($res_s[0]);push(@jiban2,$res_s[0]);
	}
	elsif($t_nm eq "포스"){
		$seast="901611";$go_hit=2;$tmp_syorip.="<>m-어느 쪽의 공격력을 늘릴까요? <>o-자신측(양쪽 모두 같은 옆이라면 좌측)::상대측(동, 우측)";
		if(&go_card_search){return;}
		if(&used){return;}
		@res_s2 = sort {$a <=> $b;} @res_s;
		$sd0=&which_side($res_s2[0],1);$sd1=&which_side($res_s2[1],1);
		if($sd0==$sd1){
			if($F{'options'}==0){$foc0=$res_s2[0];$foc1=$res_s2[1];}
			else{$foc0=$res_s2[1];$foc1=$res_s2[0];}
		}
		else{
			if($sd1==0){$tmp=$res_s2[1];$res_s2[1]=$res_s2[0];$res_s2[0]=$tmp;}
			if($F{'options'}==0){$foc0=$res_s2[0];$foc1=$res_s2[1];}
			else{$foc0=$res_s2[1];$foc1=$res_s2[0];}
		}
		$tmp=int($ap_fld[$foc1]/2);
		&add_msg("null","1턴의 사이$c_name[$fld[$foc1]]의 영혼을 반 빼앗아 --<br>그 힘을$c_name[$fld[$foc0]]에! ");
		$fld_koka[$foc0].="ptr:$tmp:0:$turn<>";
		$fld_koka[$foc1].="force:$turn<>";
	}
	elsif($t_nm eq "돌진" || $t_nm eq "뢰 만약 나무 수호자"){
		$seast="991611";
		if(&go_card_search){return;}
		if(&used){return;}
		$tmp=$c_name[$fld[$res_s[0]]];
		if($t_nm=~/^돌/){&add_msg("null","$tmp은 돌진!　공격력700업! ");$fld_koka[$res_s[0]].="ptr:700:0:$turn<>";}
		else{&add_msg("null","수호자가 방어!　$tmp의 수비력700업! ");$fld_koka[$res_s[0]].="ptr:0:700:$turn<>";}
	}
	elsif($t_nm eq "초재생 능력"){
		if(&used){return;}
		&add_msg("null","드래곤의 상처는 엔드페이즈에 재생한다! ");
		$hk[23+$s_a]++;
	}
	elsif($t_nm eq "화룡의 화염탄"){
		$seast="90961";$jokenst='&syu_st($res_si) eq "드래곤"';&card_search;
		if($#res_s<0){&add_msg("null","!$s_a(장에 겉표시의 드래곤족이 없다)");return;}
		$seast="901911";$jokenst='$res_sdp<=800';&card_search;
		if($#res_s<0 || $cpu[$s_a]==1){$F{'options'}=1;}
		elsif($F{'options'}!=1){
			$tmp_syorip.="<>m-어느 쪽의 효과를 사용할까요? <br>(파괴는 대상도 선택해 준다)<>o-파괴::데미지<>l-1";
			if(&go_card_search){return;}
		}
		if(&used){return;}

		&add_msg("null","드래곤은 화염탄을 토했다! ");
		if($F{'options'}==1){&add_msg("null","$pn[$s_d]에800의 데미지! ");$lp[$s_d]-=800;&chk_lp;}
		else{&add_msg("null","<b>$c_name[$fld[$res_s[0]]](을)를 파괴! </b>");&go_boti($res_s[0],5);}
	}
	elsif($t_nm eq "stamping·크래쉬"){
		$seast="90991";$jokenst='&syu_st($res_si) eq "드래곤"';&card_search;
		if($#res_s<0){&add_msg("null","!$s_a(장에 겉표시의 드래곤족이 없다)");return;}
		$seast="99990011";if($cpu[$s_a]==1){$seast="99990001";}$jokenst='';
		if(&go_card_search){return;}
		if(&used){return;}
		&add_msg("null","드래곤은$c_name[$fld[$res_s[0]]]을 밟아 부수었다! ");
		$l_side=&which_side($res_s[0]);$tsno=$sno[$l_side];
		&add_msg("null","$pn[$tsno]에500의 데미지! ");$lp[$tsno]-=500;&chk_lp;
		&go_boti($res_s[0],2);
	}
	elsif($t_nm eq "비상식"){
		if($cont_flg!=1){
			$seast="9999001";$go_hit="<99";
			if($use_from eq "f"){$jokenst='$res_si!='.$use_f_no;}
			if(&go_card_search){return;}

			for($i=0;$i<$#res_s+1;$i++){
				&add_msg("null","$c_name[$fld[$res_s[$i]]]을 먹었다! ");
				&go_boti($res_s[$i],3);
			}
			$F{'options'}=$#res_s+1;undef(@res_s);
		}
		if(&used){return;}
		&lp_up(1000,$F{'options'});
	}
	elsif($t_nm eq "명계류 괴뢰방법"){
		if(&ext_chk()){return;}
		$seast="09940000001";$jokenst='$c_syuzoku[$cardno] eq "악마" && $irrflg!=1 && $cardno!=1106';
		if(&go_card_search){return;}
		if(&used){return;}
		$seast="99991";$jokenst='';$tmp_syorip="<>n-kairai<>i-$s_a<>p-$res_s[0]<>o-공격 표시::수비 표시";
		&go_select_syori;
	}
	elsif($t_nm eq "익스체인지"){
		if(&maisu_count(7)<1 || ($tcou=&maisu_count(6))<1 || ($use_from eq "t" && $tcou<2)){&add_msg("null","!$s_a(패가 없다)");return;}
		if(&used){return;}
		&add_msg("null","서로의 패를 1장씩 교환한다! ");
		if($player[$s_a]==1 && $player[$s_d]==19){
			&add_msg("유희","…　조이…<br>이 중에서 가지고 싶은 카드를 한 장 선택해…<br>가지고 있을거라고 해…");
		}
		&del_nullt($s_a);
		$seast="9999000001";$tmp_syorip="<>i-$s_d<>n-exchange1<>g-1";
		&go_select_syori;
	}
	elsif($t_nm eq "강제 전이"){
		$seast="991601";&card_search;
		if($#res_s<0){&add_msg("null","!$s_a(상대의 장소에 몬스터가 없다)");return;}
		@aite_s=@res_s;

		$seast="99191";
		if(&go_card_search){return;}
		if(&used){return;}
		&add_msg("null","$pn[$s_a]은$c_name[$fld[$res_s[0]]]을 선택했다! ");
		if($#aite_s==0){&ctrl_chg($res_s[0],$aite_s[0]);$a_m[$res_s[0]]=2;$a_m[$aite_s[0]]=2;}
		else{
			$seast="99191";$tmp_syorip="<>i-$s_d<>n-teni<>p-$res_s[0]<>g-1";
			&go_select_syori;
		}
	}
	elsif($t_nm eq "매직·가드너"){
		$seast="2099001";
		if(&go_card_search){return;}
		if(&used){return;}
		&add_msg("null","$c_name[$fld[$res_s[0]]]를 1회만 가이드 한다! ");
		$fld_koka[$res_s[0]].="guard<>";
	}
	elsif($t_nm eq "증원"){
		if(&used){return;}
		&add_msg("null","증원을 부를 수가 있다! ");
		$seast="9999000000001";$jokenst='$c_syuzoku[$cardno] eq "전사" && $c_lv[$cardno]<5';
		$tmp_syorip="<>n-zouen<>g-1<>i-$s_a";
		&go_select_syori;
	}
	elsif($t_nm eq "전사의 생환"){
		$seast="99990000001";$jokenst='$c_syuzoku[$cardno] eq "전사"';
		if(&go_card_search){return;}
		if(&used){return;}
		&add_msg("null","$c_name[$boti[$s_a][$res_s[0]-200]]는 패에 생환했다! ");
		push(@{$tehuda[$s_a]},$boti[$s_a][$res_s[0]-200]);
		$boti[$s_a][$res_s[0]-200]="";&del_null(*boti,$s_a);
	}
	elsif($t_nm eq "더블 트랩"){
		$seast="90191111";$jokenst='$cardno==566 || $cardno==861 || $cardno==1124 || $cardno==1139 || $cardno==1144 || $cardno==1148';
		if(&go_card_search){return;}
		if(&used){return;}
		&add_msg("null","<b>$c_name[$fld[$res_s[0]]]을 파괴! </b>");
		&go_boti($res_s[0],2);
	}
	elsif($t_nm eq "고대의 망원경"){
		if(&used){return;}
		&add_msg("null","$pn[$s_d]의 덱을 위로부터 5장까지 들여다 보았다! ");
		for($i=0;$i<$#{$deck[$s_d]}+1 && $i<5;$i++){
			&add_msg("null","!$s_a($c_name[$deck[$s_d][$i]])");
		}
	}
	elsif($t_nm eq "융합 해제"){
		$seast="901911";$jokenst='$c_syokan[$cardno]==1';
		$tmp_syorip.="<>m-소재 몬스터를 장소에 낼까요? <>o-낸다(공격 표시)::낸다(수비 표시)::안낸다";
		if($kekka=&go_card_search){return;}
		if($player[$s_a]==0 && $cont_flg!=1){&add_msg("유희","기억해 두어라…　너희들의 패배 요인은…<br>분노와 복수심에 있는 것을…");}
		if(&used){return;}
		&add_msg("null","$c_name[$fld[$res_s[0]]]의 융합을 해제했다! ");
		$yugside=&which_side($res_s[0]);
		$yugbak=$fld_koka[$res_s[0]];
		&return_tehuda($res_s[0],1);
		if($F{'options'}!=2 && $yugbak=~/yugo_([\d-]+)/){
			@tmp=split(/-/,$1);$mocou=$#tmp+1;
			$cou=&maisu_count(8+$yugside);
			if($cou<$#mocou){&add_msg("null","!$s_a(장소에 빈 곳이 없다)");}
			if($yugside==0){@tmp_arr=@{$boti[$s_a]};$sup=200;}
			else{@tmp_arr=@{$boti[$s_d]};$sup=300;}
			undef(@res);$mocou2=0;
			for($i=0;$i<$#tmp_arr+1;$i++){
				for($j=0;$j<$#tmp+1;$j++){
					if($tmp_arr[$i] eq $tmp[$j]){push(@res,$i+$sup);$tmp[$j]="";$mocou2++;last;}
					if($mocou2==$mocou){last;}
				}
			}
			if($mocou2<$mocou){&add_msg("null","!$s_a(묘지에 소재 몬스터가 없다)");}
			else{
				for($i=0;$i<$#res+1;$i++){
					&fld_chk($yugside);
					&put_field($res[$i]);
					if($F{'options'}==1){$fld_ad[$nf0]=1;}
				}
				if($yugside==0){&hosatu(0);&del_null(*boti,$s_a);}
				else{&hosatu(1);&del_null(*boti,$s_d);}
			}
		}
	}

	elsif($t_nm eq "유언장"){
		if($cont_flg!=1){
			if($jok[2] eq ""){$F{'options'}=1;}
			elsif($cpu[$s_a]==1){$F{'options'}=0;}
			elsif($F{'options'} eq ""){$tmp_syorip.="<>o-지금 사용한다::다음에 사용한다<>m-효과를 지금 사용할까요? ";&go_select_syori;return;}
		}
		if(&used){return;}
		&add_msg("null","묘지에 보내진 몬스터는 유언을 남긴다! ");
		if($F{'options'}==0){push(@chain2,"$s_a-5-645");}
		else{$hk[14]++;}
	}
	elsif($t_nm eq "고통 분담"){
		if($cont_flg!=1){
			$seast="99121";
			if(&go_card_search){return;}
			&add_msg("$pn[$s_a]","$c_name[$fld[$res_s[0]]]를 생지에 바치고 --");
			&go_boti($res_s[0],4);undef(@res_s);
		}
		if(&used){return;}
		&add_msg("null","$pn[$s_d]는 생지를 바칠 필요가 있다! ");
		$seast="99121";$tmp_syorip="<>n-itami<>g-1<>i-$s_d";&go_select_syori;
	}
	elsif($t_nm eq "성불"){
		if(&used){return;}
		&add_msg("null","장비 카드가 붙은 몬스터는 파괴되었다! ");
		for($i=0;$i<20;$i++){
			if($i==5){$i=15;}
			if(($c_syuzoku[$fld[$i]] eq "장비" || grep(/^$fld[$i]$/,@soubiatu)) && $fld_koka[$i]=~/f_(\d+)/ && !(&fisher($1))){&go_boti($1);}
		}
		for($i=5;$i<15;$i++){
			if($fld_koka[$i]=~/_sacr/){&go_boti($i);}
		}
	}
	elsif($t_nm eq "금지령"){
		if($cont_flg!=1){
			if($cpu[$s_a]==1){$rann=rand;$rann=int($rann*($#seigen+1));$F{'options'}=$seigen[$rann];}
			elsif($F{'options'} eq ""){$seast="";$tmp_syorip.="<>m-카드명을 입력해 줘. (모르는 경우는<a href=\"deck.cgi?id=$id\" target=new>이쪽</a>)<>o-kinsi";&go_select_syori;return;}
			else{
				for($i=0;$i<$#c_name+1;$i++){if($c_name[$i] eq $F{'options'}){last;}}
				if($i==$#c_name+1){&add_msg("null","!$s_a($F{'options'}(이)라고 하는 카드는 없다)");return;}
				if($i==1156){$i=0;}
				elsif($i==1037){$i=208;}
				$F{'options'}=$i;
			}
		}
		if(&used){return;}
		$fld_koka[$use_f_no].="kin_".$F{'options'};
		&add_msg("null","$c_name[$F{'options'}]을 금지했다! ");
		for($i=0;$i<20;$i++){if($fld[$i]==$F{'options'}){$fld_koka[$i].="kinsi<>";}}
	}
	elsif($t_nm eq "천사의 주사위"){
		if(&used){return;}
		&add_msg("null","천사가 나타나고 주사위를 흔들었다! ");
		$rann=rand;$rann=int($rann*6)+1;$tmp=$rann*100;
		&add_msg("null","<b>$rann! </b><br>턴 종료시까지 공수$tmp업! ");
		for($i=$fw1[$s_a];$i<$fw1[$s_a]+5;$i++){if($fld[$i] ne "" && $fld_rf[$i]!=1 && !(&fisher($i))){$fld_koka[$i].="ptr:$tmp:$tmp:$turn<>";}}
	}
	elsif($t_nm eq "타오르는 대지"){
		if(&used){return;}
		&add_msg("null","필드를 다 구웠다! ");
		&go_boti(20,2);&go_boti(21,2);
		&add_msg("null","서로의 스탄바이페이즈 마다 500의 데미지! ");
	}
	elsif($t_nm eq "마 이슬비"){
		if($phase!=2){&add_msg("null","!$s_a(메인페이즈 1밖에 사용할 수 없다)");return;}
		$seast="90161";$jokenst='$cardno==196 || &syu_st($res_si) eq "번개"';
		if(&go_card_search){return;}
		if(&used){return;}
		&add_msg("null","$c_name[$fld[$res_s[0]]]의 전격이 이슬비를 전도한다! ");
		$cou=$ap_fld[$res_s[0]];
		for($i=$fw1[$s_d];$i<$fw1[$s_d]+5;$i++){
			if($fld[$i] eq "" || $fld_rf[$i]==1 || $dp_fld[$i]>$cou || &fisher($i)){next;}
			&add_msg("null","<b>$c_name[$fld[$i]](을)를 파괴! </b>");
			&go_boti($i);
		}
		$hk[13]=999;
	}
	elsif($t_nm eq "몬스터 회수"){
		$seast="99161";
		if(&go_card_search){return;}
		if(&which_side($res_s[0])==1){&add_msg("null","!$s_a(상대의 몬스터는 대상으로 할 수 없다)");return;}
		if($player[$s_a]==0 && $cont_flg!=1){&add_msg("유희","1장의 카드는 하나의 가능성!　이것이 그 1장이다! ");}
		if(&used){return;}

		$cou=&maisu_count(6);
		&add_msg("null","$c_name[$fld[$res_s[0]]]와(과) 패를 덱에 되돌렸다! <br>셔플 해 , 원의 패 장수만 드로! ");
		&return_tehuda($res_s[0],1);
		for($i=0;$i<$#{$tehuda[$s_a]}+1;$i++){
			if($tehuda[$s_a][$i] eq ""){next;}
			if($tep[$s_a][$i] ne ""){&go_boti($i);$cou--;}
			else{push(@{$deck[$s_a]},$tehuda[$s_a][$i]);}
		}
		undef(@{$tehuda[$s_a]});
		&shuffle(*deck,$s_a);
		&tehuda_draw(0,$cou);
	}
	elsif($t_nm eq "크로스 소울"){
		if($phase!=2){&add_msg("null","!$s_a(메인페이즈 1밖에 사용할 수 없다)");return;}
		$seast="991601";
		if(&go_card_search){return;}
		if(&cpu_get_saikyo()){return;}
		if($player[$s_a]==2 && $cont_flg!=1){&add_msg("카이바","너의 필드에 몬스터를 받았다! ");}
		if(&used){return;}

		&add_msg("null","$c_name[$fld[$res_s[0]]](을)를 제물로 바칠 수가 있다! ");
		$hk[13]=$res_s[0];
	}
	elsif($t_nm eq "사망자에게로의 공물"){
		$seast="901611";
		if(&go_card_search){return;}
		if(&cpu_get_saikyo()){return;}
		if(&used){return;}

		&add_msg("null","<b>$c_name[$fld[$res_s[0]]]을 파괴했다! </b><br>$pn[$s_a]의 드로페이즈는 스킵 된다. ");
		&go_boti($res_s[0],5);$hk[10+$s_a]=1;
	}
	elsif($t_nm eq "벼락 부자 고블린"){
		if(&used){return;}
		&add_msg("null","1장 드로! ");
		&lp_up(1000,1,1);&tehuda_draw(0,1,1);
	}
	elsif($t_nm eq "마력 무력화의 가면"){
		$seast="20990011";if($cpu[$s_a]==1){$seast="20990001";}
		if(&go_card_search){return;}
		if(&used){return;}
		&add_msg("null","$c_name[$fld[$res_s[0]]]에 가면이 장착되었다! <br>스탄바이페이즈 마다500의 데미지! ");
		&soubi($res_s[0],$use_f_no,"_muryo");
	}
	elsif($t_nm eq "유언의 가면"){
		if(&used){return;}
		&add_msg("null","유언의 가면을 덱에 되돌려 셔플 했다.");
		&return_tehuda($use_f_no,1);&shuffle(*deck,$s_a);
	}
	elsif($t_nm eq "영혼 소멸"){
		if(&used){return;}
		&add_msg("null","장의 몬스터로부터 영혼이 떠올랐다. ");
		$hk[8]=1;
	}
	elsif($t_nm eq "요정"){
		$seast="99990001";
		if(&go_card_search){return;}
		if(&cpu_cyc){return;}
		if(&used){return;}
		if($kok[0][8] ne ""){&add_msg("null","요정은 무효화되지 않는다! ");}
		if($fld_rf[$res_s[0]]!=1){&add_msg("null","$c_name[$fld[$res_s[0]]]을(를) 명함에 되돌렸다! ");}
		else{&add_msg("null","덮고 카드를 명함에 되돌렸다! ");}
		&return_tehuda($res_s[0]);
		if($player[$s_a]==8){&add_msg("바크라","이것이 나모양의 초오칼트 덱의 위력이야! ");}
	}
	elsif($t_nm eq "지반침하"){
		$seast="9991";$go_hit=2;
		if(&go_card_search){return;}
		if(&used){return;}
		&add_msg("null","몬스터 존을 2개소 침하시켰다! ");
		$fld_koka[$use_f_no].="$res_s[0]-$res_s[1]<>";
	}
	elsif($t_nm eq "변덕스러운 재봉사"){
		$errmsg="(장비 카드 1매와 몬스터 1체를 선택한다)";
		$seast="90191111";$go_hit=2;$tmp_syorip.="<>m-$errmsg";
		if(&go_card_search){return;}
		$errmsg="!$s_a$errmsg";
		$errmsg2="!$s_a(대상이 부적당하다)";

		&which_side($res_s[0]);$area1=$which_area;
		&which_side($res_s[1]);$area2=$which_area;

		if($area1==$area2){&add_msg("null",$errmsg);return;}
		if($area1==1){$utu1=$res_s[0];$utu2=$res_s[1];}
		else{$utu2=$res_s[0];$utu1=$res_s[1];}
		if($c_syuzoku[$fld[$utu2]] ne "장비" && !(grep(/^$fld[$utu2]$/,@soubiatu))){&add_msg("null",$errmsg);return;}
		if($fld[$utu2]==899 || $fld[$utu2]==704){&add_msg("null","!$s_a(이 카드를 바꿀 수 없다)");return;}
		if($m_joken{$fld[$utu2]} ne ""){
			$cardno=$fld[$utu1];
			$evalst='$tmp=('.$m_joken{$fld[$utu2]}.')';
			eval($evalst);
			if($tmp!=1){&add_msg("null",$errmsg2);return;}
		}
		if($fld[$utu2]==801){
			$utus1=&which_side($utu1,1);
			$utus2=&which_side($utu2,1);
			if($utus1==$utus2){&add_msg("null",$errmsg2);return;}
		}
		if(&used){return;}
		if($fld_koka[$utu2] =~ s/^f_(\d+)::(\d+)//  && $fld_koka[$1] ne ""){$utu3=$1;&del_koka($1,$2);}

		&soubi($utu1,$utu2);

		&add_msg("null","재봉사가 나타났다! <br>$c_name[$fld[$utu2]](을)를$c_name[$fld[$utu1]]에 바꾸었다! ");
		if($fld[$utu2]==801){&godatu_ido($utu1);&godatu_ido($utu3);}
	}

	elsif($t_nm eq "최종전쟁"){
		if($cont_flg!=1){
			$seast="999900001";$go_hit=5;$go_msg="(패가 5장 없다)";
			if($use_from eq "t"){$tmp=$use_t_no+50;$jokenst='$res_si!='.$tmp;}
			if(&go_card_search){return;}
			&add_msg($pn[$s_a],"패를 5장 버리고 --");
			for($i=0;$i<5;$i++){&go_boti2($res_s[$i]-50);}
			undef(@res_s);
		}
		if(&used){return;}
		&add_msg("null","<b>최후의 대결전 발발! <br>장소의 모든 카드를 파괴! </b>");
		for($u_i=0;$u_i<5*4;$u_i++){if(!(&fisher($u_i))){&go_boti($u_i);}}
		&go_boti("f");
	}
	elsif($t_nm eq "밝은 장의사"){
		$seast="099900001";$go_hit="<4";
		if($use_from eq "t"){$tmp=$use_t_no+50;$jokenst='$res_si!='.$tmp;}
		if(&go_card_search){return;}

		if(&used){return;}
		for($i=0;$i<$#res_s+1;$i++){
			&add_msg("null","$c_name[$tehuda[$s_a][$res_s[$i]-50]]를 버렸다. ");
			&go_boti2($res_s[$i]-50,0,"",1);
		}
	}
	elsif($t_nm eq "스케이프·고트"){
		if(&ext_chk("s")){return;}
		$cou=&maisu_count(8);
		if($cou<4){&add_msg("null","!$s_a(필드에 4개 이상의 빈 곳이 없다)");return;}
		if(&used){return;}
		$cou=0;
		for($i=$fw1[$s_a];$i<$fw1[$s_a]+5 && $cou<4;$i++){
			if($fld[$i] ne "" || $jiban[$i] ne ""){next;}
			$cou++;$fld[$i]=1050;&ext_set($i);$fld_ad[$i]=1;
		}
		&add_msg("null","장소에 4체의 대역양이 나타났다! ");
		$jok[2+$s_a]=2;
	}
	elsif($t_nm eq "왕가의 신전"){
		if(&used){return;}
		&add_msg("null","장에 신전이 출현했다! ");
		if($player[$s_a]==20){&add_msg("리시드","왕의 유보 모셔 태양 성역 ----…<br>거기에는 침입자에게 중재를 주는 함정이 기다려 짓고 있는…");}
		&add_msg("null","$pn[$s_a]은 함정을 세트 한 턴에 사용할 수 있다! ");
	}
	elsif($t_nm eq "엘리먼트의 샘"){
		if(&used){return;}
		&add_msg("null","몬스터가 명함으로 돌아오면(자)500회복! ");
	}
	elsif($t_nm eq "연합군"){
		if(&used){return;}
		&add_msg("null","전사족은 전사 , 마법사족과 연합 해 , 공격력 200업! ");
	}
	elsif($t_nm eq "령자 에너지 고정 장치"){
		if(&used){return;}
		&add_msg("null","스피릿은 현세에 머무를 수가 있다! ");
	}
	elsif($t_nm eq "제충 배리어"){
		if($player[$s_a]==10 && $cont_flg!=1){&add_msg("사마준","역시 헛됨 표! ");}
		if(&used){return;}
		&add_msg("null","$pn[$s_d]의 곤충족은 공격할 수 없다! ");
	}
	elsif($t_nm eq "암흑의 문"){
		if(&used){return;}
		&add_msg("null","배틀 필드가 암흑의 문 에 갇혔다. <br>1턴에 1체의 몬스터 밖에 공격할 수 없다! ");
	}
	elsif($t_nm eq "슬라임 증식로"){
		if(&used){return;}
		&add_msg("null","$pn[$s_a]의 스탄바이페이즈에 , 생지 슬라임을 낳을거야! ");
	}
	elsif($t_nm eq "원령의 습지대"){
		if(&used){return;}
		&add_msg("null","원령이 가득 찬 습지에 발을 디뎠다! <br>소환한 턴에는 공격할 수 없다! ");
	}
	elsif($t_nm eq "무한의 명함"){
		if(&used){return;}
		&add_msg("null","서로의 명함의 매수 제한이 없어졌다! ");
	}
	elsif($t_nm eq "생환의 보찰"){
		if(&used){return;}
		&add_msg("null","사망자가 생환할 때마다 , 1매 드로 할 수 있다! ");
	}
	elsif($t_nm eq "통행세"){
		if(&used){return;}
		&add_msg("null","배틀 필드에 관문이 나타났다! <br>이후 , 공격에는 500의 라이프가 필요하다! ");
	}
	elsif($t_nm eq "묘수의 사용마"){
		if(&used){return;}
		&add_msg("null","$pn[$s_d]의 묘지에 사용해 마가 잠입했다! <br>이후 ,$pn[$s_d]의 공격마다 데크로부터 1매탈취한다! ");
	}
	elsif($t_nm eq "마력의 항쇄"){
		if(&used){return;}
		&add_msg("null","서로의 명함에 항쇄를 쓸 수 있었다! <br>이후 , 명함으로부터 플레이 할 때마다 500의 데미지! ");
	}
	elsif($t_nm eq "압수" || $t_nm eq "강행인 파수병" || $t_nm eq "봉 신경"){
		if($#{$tehuda[$s_d]}<0){&add_msg("null","!$s_a(상대의 패가 없다)");return;}
		if($t_nm eq "압수" && $cont_flg!=1){
			if($cpu[$s_a]==1 && $lp[$s_a]<=1000){return;}
			&add_msg("null","라이프를1000지불해 --");
			$lp[$s_a]-=1000;&chk_lp;
		}
		if(&used){return;}
		if($player[$s_a]==22){
			if($pn[$s_d] eq "카이바"){$tmp="뢰인";}else{$tmp=$pn[$s_d];}
			&add_msg("이시즈","패를 보이세요!　$tmp! ");
			if($player[$s_d]==2){&add_msg("카이바","(이 굴욕망! )");}
		}
		elsif($player[$s_d]==2 && $t_nm=~/^압/){&add_msg("카이바","구…　플레이어의 패를 쬐어 사람으로 하는 기들 강요하고 마법 카드! <br>패에 갖추어진 좋은 카드를 무덤에 버리게 당한다!　당신! <br>당신(고)");}
		$seast="9999000001";$tmp_syorip="<>i-$s_a<>n-ousyu<>g-1<>p-$use_cno";
		if($t_nm=~/^봉/){$jokenst='$c_syokan[$cardno]==6';&add_msg("null","경이$pn[$s_d]의 명함을 비추었다! ");}
		&go_select_syori;
	}

	elsif($t_nm eq "강탈"){
		if(&akichk()){return;}
		$seast="901901";
		if(&go_card_search){return;}
		if(&cpu_get_saikyo()){return;}

		if(&used){return;}

		&add_msg("null","<b>$c_name[$fld[$res_s[0]]]을 빼앗았다! </b><br>$pn[$s_d](은)는 스탄바이페이즈 마다1000회복한다. ");
		&ctrl_ido($res_s[0],$nf0);
	}

	elsif($t_nm eq "7카드"){
		$seast="901911";$jokenst='&syu_st($res_si) eq "기계"';
		$tmp_syorip.="<>o-공격력::수비력";
		if(&go_card_search){return;}
		if($cpu[$s_a]==1){if(&cpu_get_saikyo("90191",$jokenst)){return;}$F{'options'}=0;}

		if(&used){return;}
		if($F{'options'} eq "0"){$fld_koka[$use_f_no].="ap<>";$tmp_p="공격력";}
		else{$tmp_p="수비력";}

		if($player[$s_a]==14){&add_msg("밴디트 키스","이 카드는 기계족 전용의 파워 유니트! <br>이녀석로$tmp_p를 700UP 하군! ");}
		else{&add_msg("null","$tmp_p하지만 700업! ");}
	}
	elsif($t_nm eq "평화의 사자"){
		if(&used){return;}
		if($fld[$use_f_no] ne ""){
			&add_msg("null","사자가 나타나고 평화를 말했다! <br><b>공격력1500이상의 몬스터는 공격할 수 없다! </b>");
		}
	}
	elsif($t_nm eq "장난 꾸러기인 쌍둥이 악마"){
		if(($rann=&rand_tehuda(1))<0){&add_msg("null","!$s_a(상대의 페가 없다)");return;}
		if($cont_flg!=1){
			if($cpu[$s_a]==1 && $lp[$s_a]<=1000){return;}
			&add_msg("null","라이프를1000지불해 --");
			$lp[$s_a]-=1000;&chk_lp;
		}

		if(&used){return;}
		&add_msg("null","형(오빠)의 악마가 ,$pn[$s_d]의$c_name[$tehuda[$s_d][$rann]]를 버렸다! ");
		&go_boti2($rann,1,2,1);
		&maryoku(17,1);
		if($#{$tehuda[$s_d]}>-1){
			$seast="999900001";$jokenst='';
			$tmp_syorip="<>m-(명함을 1매 버린다)<>n-t_sute<>g-1<>i-$s_d<>p-1ha";
			&go_select_syori;
		}
	}
	elsif($t_nm eq "영혼의 해방"){
		$seast="999300000011";$go_hit="<6";
		if(&go_card_search){return;}
		&cpu_get_saikyo("999900000001","");

		if(&used){return;}
		for($i=0;$i<$#res_s+1;$i++){
			if($res_s[$i]<300){$tmp=$boti[$s_a][$res_s[$i]-200];$boti[$s_a][$res_s[$i]-200]="";}
			else{$tmp=$boti[$s_d][$res_s[$i]-300];$boti[$s_d][$res_s[$i]-300]="";}
			$tmp=~s/_i$//;&add_msg("null","$c_name[$tmp]은 해방되었다! ");
		}
		&del_null(*boti,$s_a);&del_null(*boti,$s_d);
	}
	elsif($t_nm eq "흑 마술의 커텐"){
		if(&ext_chk("s")){return;}
		if($cpu[$s_a]==1 && $lp[$s_a]>5000){return;}
		if(&akichk()){return;}

		for($deckno=0;$deckno<$#{$deck[$s_a]}+1;$deckno++){if($deck[$s_a][$deckno]==59){last;}}
		if($deckno==$#{$deck[$s_a]}+1){&add_msg("null","!$s_a(데크에 블랙·매지션이 없는)");return;}
		if($cont_flg!=1){
			if($player[$s_a]==17){&add_msg("판도라","살아요!　이것이 승리의 열쇠 카드! ");}
			&add_msg("null","라이프 포인트 반을 지불해 --");
			$lp[$s_a] = int($lp[$s_a] / 2);
		}

		if(&used){return;}
		&add_msg("null","장소를 검은 커텐이 가린다! <br><b>커텐중에서 블랙·매지션 출현! </b>");
		&put_field($deckno+400);&del_null(*deck,$s_a);
		$jok[2+$s_a]=2;
	}

	elsif($t_nm eq "죽음의 매직·박스"){
		$seast="991911";$go_hit=2;
		if(&go_card_search){return;}

		if($cpu[$s_a]==1){
			$seast="99191";&card_search;@res_s2 = sort ap_cre_res @res_s;
			$seast="901901";&card_search;@res_s3 = sort ap_cre_res @res_s;
			if($#res_s2<0 || $#res_s3<0){return;}
			if($ap_fld[$res_s3[0]] - $ap_fld[$res_s2[$#res_s2]]<700){return;}
			$res_s[0]=$res_s2[$#res_s2];$res_s[1]=$res_s3[0];
		}
		else{
			$errflg=0;
			$box1=&which_side($res_s[0],1);
			$box2=&which_side($res_s[1],1);
			if($box1==$box2){&add_msg("null","!$s_a(자신과 상대의 장소로부터 1체씩 선택한다)");return;}
			if($box1==1){$tmp=$res_s[0];$res_s[0]=$res_s[1];$res_s[1]=$tmp;}
		}

		if(&used){return;}

		&add_msg("null","장소에 2개의 박스가 나타났다! ");
		&add_msg("null","1개의 박스로$c_name[$fld[$res_s[1]]]를 꼬치에! ");
		&go_boti($res_s[1],5);
		if(&akichk(1)){return;}
		&add_msg("null","또 하나의 박스로부터$c_name[$fld[$res_s[0]]]출현! ");
		&moto_chk($res_s[0]);
		&ctrl_ido($res_s[0],$nf0);
		$fld_koka[$nf0].="teni_$s_d<>";
	}
	elsif($t_nm eq "리미터 해제"){
		if(&used){return;}
		&add_msg("null","기계족 몬스터의 리미터가 떼어졌다! ");
		&add_msg("null","<b>공격력이 2배에! </b>");
		for($i=$fw1[$s_a];$i<$fw1[$s_a]+5;$i++){
			if(&syu_st($i) eq "기계" && $fld_rf[$i]!=1 && !(&fisher($i))){
				if($hk[2] eq ""){$fld_koka[$i].="limit<>";}
				else{$fld_koka[$i].="limit_hk2<>";}
			}
		}
	}
	elsif($t_nm eq "트·월드"){
		if($cont_flg!=1){
			if($player[$s_a]==5){&add_msg($pn[$s_a],"트의 훌륭한 세계에…<br>지금부터 유를 초대 섬 쇼우! ");}
			&add_msg("null","라이프를1000지불해 --");
			$lp[$s_a]-=1000;&chk_lp;
		}
		if(&used){return;}
		&add_msg("null","장소에 입체 그림책이 나타났다! <br>툰몬스터를 장소에 낼 수가 있다! ");
	}
	elsif($t_nm eq "증식"){
		if(&ext_chk()){return;}
		if($cont_flg!=1){
			$seast="90921";$go_msg="(장에 겉표시의 구리 보가 없다)";
			$jokenst='$cardno==378';
			if(&go_card_search){return;}
			&go_boti($res_s[0],4);undef(@res_s);
		}
		if(&used){return;}
		if($player[$s_a]==0){&add_msg($pn[$s_a],"이녀석으로 크리보를 증식! ");}
		&add_msg("크리보","<b>크리 크리 크리 크리 ~~</b>");
		for($i=$fw1[$s_a];$i<$fw1[$s_a]+5;$i++){
			if($fld[$i] ne "" || $jiban[$i] ne ""){next;}
			$fld[$i]=974;&ext_set($i);$fld_ad[$i]=1;
		}
		&add_msg("null","크리보가 무수히 증식!　상대의 공격을 막는다! ");
	}
	elsif($t_nm eq "오른손엔 방패 왼손엔 검"){
		if(&used){return;}
		if($player[$s_a]==3){&add_msg("조이","이 카드로 공·수 역전! ");}
		&add_msg("null","턴 종료시까지 , 공격력과 수비 힘이 들어갈 수 있는 바뀐다! ");
		$hk[2]=1;
	}
	elsif($t_nm eq "만화경 -화려한 분신-"){
		if(&akichk()){return;}
		if(&ext_chk()){return;}
		$seast="909911";$jokenst='$cardno==208 || $cardno==1037';&card_search;
		if($#res_s<0){&add_msg("null","!$s_a(분신 시킬 해피 레이디가 필드에 없다)");return;}
		$seast="9999000010001";$jokenst='$cardno==207 || $cardno==208 || $cardno==1037';
		$tmp_syorip.="<>o-공격 표시::수비 표시";
		if(&go_card_search){return;}
		&cpu_get_saikyo();

		if(&used){return;}
		&put_field($res_s[0]);&del_null(*deck,$s_a);
		&add_msg("null","해피를 만화경으로 분신시켜,<b>$c_name[$fld[$nf0]]소환! </b>");
		if($F{'options'}==1){$fld_ad[$nf0]=1;}
	}

	elsif($t_nm =~ /(.+)의 사도$/){
		$sito_m=$1;

		if($1 eq "말살"){$seast="919911";if($cpu[$s_a]==1){$seast="919901";}}
		else{$seast="91990011";if($cpu[$s_a]==1){$seast="91990001";}}
		if(&go_card_search){return;}

		if(&used){return;}
		$taisyo=$fld[$res_s[0]];
		&add_msg("null","$c_name[$taisyo]은 완전하게$sito_m되었다! ");
		&syometu($res_s[0]);

		if(($sito_m eq "말살" && ($c_koka[$taisyo]==2 || $c_koka[$taisyo]==7)) || ($sito_m eq "박멸" && $c_zokusei[$taisyo] eq "함정")){
			&add_msg("null","게다가 서로의 덱안의 것$c_name[$taisyo]도$sito_m된다! ");
			undef(@tmp_s);
			for($i=0;$i<$#{$deck[$s_a]}+1;$i++){if($deck[$s_a][$i]!=$taisyo){push(@tmp_s,$deck[$s_a][$i]);}}
			@{$deck[$s_a]}=@tmp_s;undef(@tmp_s);
			for($i=0;$i<$#{$deck[$s_d]}+1;$i++){if($deck[$s_d][$i]!=$taisyo){push(@tmp_s,$deck[$s_d][$i]);}}
			@{$deck[$s_d]}=@tmp_s;
		}
	}
	elsif($t_nm eq "죽은 자에게 흔드는 손"){
		if($cont_flg!=1){
			if($use_from eq "t"){$tmp=$use_t_no+50;$jokenst='$res_si!='.$tmp;}
			$seast="991611001";$go_hit=2;
			if(&go_card_search){return;}

			@res_s2 = sort {$a <=> $b;} @res_s;@res_s=@res_s2;
			if($res_s[0]>=50 || $res_s[1]<50){return;}

			&add_msg("$pn[$s_a]","$c_name[$tehuda[$s_a][$res_s[1]-50]]을 버리고 --");
			&go_boti2($res_s[1]-50);&maryoku(17);$go_hit=1;
		}
		else{$res_s[0]=$select[0];}
		if(&used){return;}
		&add_msg("null","<b>$c_name[$fld[$res_s[0]]]를 파괴! </b>");
		&go_boti($res_s[0],5);
	}
	elsif($t_nm eq "혁명"){
		if(&used){return;}
		&add_msg("null","상대의 패 1장에 대해 ,200포인트의 데미지를 준다! ");
		$tmp=200*($#{$tehuda[$s_d]}+1);
		&add_msg("null","$pn[$s_d]에$tmp의 데미지! ");
		$lp[$s_d]-=$tmp;&chk_lp;
	}
	elsif($t_nm eq "괴로운 선택"){
		if($#{$deck[$s_a]}<5){&add_msg("null","!$s_a(덱에 5장 이상의 카드가 없다)");return;}

		if(&used){return;}
		$seast="9999000000001";$tmp_syorip="<>n-kuju<>g-1<>i-$s_a";
		&go_select_syori;
	}

	elsif($t_nm =~ /^「(....)」봉하고$/){
		$hujisyu=$1;
		if($hujisyu eq "공격"){$hujiad=0;$huji2="수비";$seast="991601";}
		else{$hujiad=1;$huji2="공격";$seast="999601";}
		$jokenst='$fld_ad[$res_si]=='.$hujiad;
		if(&go_card_search){return;}

		if(&used){return;}
		$taisyo=$res_s[0];
		&add_msg("null","$c_name[$fld[$taisyo]]의$hujisyu표시를 봉해$huji2표시로 변경! ");
		$fld_ad[$taisyo]=1-$hujiad;

		if($hujiad==1 && $fld_rf[$taisyo]==1){&reverse($taisyo);}
		&piero($taisyo);
	}
	elsif($t_nm eq "갈라진 대지"){
		$seast="909901";$go_hit=">0";$go_msg="(상대의 장소에 겉표시의 몬스터가 없다)";
		if(&go_card_search){return;}

		@res_s2 = sort ap_cre_res @res_s;
		$taisyo=$res_s2[$#res_s2];

		if(&used){return;}
		if(&fisher($taisyo)){return;}
		&add_msg("null","지면이 갈라져 공격력의 가장 낮은 몬스터가 떨어진다! <br><b>$c_name[$fld[$taisyo]]을(를) 파괴! </b>");
		&go_boti($taisyo);
	}

	elsif($t_nm eq "드래곤을 부르는 피리"){
		if($kok[0][1] eq ""){&add_msg("null","!$s_a(드래곤의 제왕이 장소에서 겉표시로 되어 있지 않아)");return;}
		if(&akichk()){return;}
		if(&ext_chk()){return;}

		$seast="099400001";$jokenst='$c_syuzoku[$cardno] eq "드래곤"';$go_hit="<3";
		$tmp_syorip.="<>o-공격 표시::수비 표시";
		if(&go_card_search){return;}
		&cpu_get_saikyo("","",2);

		if(&used){return;}
		for($i=0;$i<$#res_s+1;$i++){
			if(&akichk()){return;}
			if(&ext_chk("","",$tmpno)){next;}
			&put_field($res_s[$i]);
			if($F{'options'}==1){$fld_ad[$nf0]=1;}
			&add_msg("null","<b>$c_name[$fld[$nf0]]를 불렀다! </b>");
		}
	}

	elsif($t_nm eq "천개 나이프"){
		$flg=0;
		for($i=$fw1[$s_a];$i<$fw1[$s_a]+5;$i++){if($fld[$i]==59 && $fld_rf[$i]!=1){$flg=1;last;}}
		if($flg==0){&add_msg("null","!$s_a(필드에 블랙 매지션이 없다)");return;}

		$seast="991601";
		if(&go_card_search){return;}

		if($cpu[$s_a]==1){&cpu_get_saikyo();}
		if(&used){return;}

		&add_msg("null","블랙 매지션이 무수한 나이프를 발한다! <br><b>$c_name[$fld[$res_s[0]]](을)를 파괴했다! </b>");
		&go_boti($res_s[0],5);
	}
	elsif($t_nm eq "함정 해제"){
		$seast="30990011";if($cpu[$s_a]==1){$seast="30990001";}
		if(&go_card_search){return;}

		if(&used){return;}
		&add_msg("null","$c_name[$fld[$res_s[0]]]를 제외했다! ");
		&go_boti($res_s[0],2);
	}
	elsif($t_nm eq "사이클론"){
		$seast="99990011";
		if($use_from eq "f"){$jokenst='$res_si!='.$use_f_no;}
		if(&go_card_search){return;}
		if(&cpu_cyc){return;}

		if(&used){return;}
		if(&nisewana_chk($res_s[0])){
			&add_msg("null","「$c_name[$fld[$res_s[0]]]」을 파괴했다! ");
			&go_boti($res_s[0],2);
		}
	}
	elsif($t_nm eq "마법 제거"){
		$seast="99990011";
		$jokenst='$fld_rf[$res_si]==1 || $c_zokusei[$cardno] eq "마"';
		if(&go_card_search){return;}
		if(&cpu_cyc){return;}

		if(&used){return;}
		$tmp=$fld[$res_s[0]];
		if($c_zokusei[$tmp] eq "함정"){&add_msg("null","카드는$c_name[$tmp]이었다! <br>함정 카드이기 때문에 , 굳이 일어나지 않는다. ");}
		else{&add_msg("null","$c_name[$tmp](을)를 파괴했다! ");&go_boti($res_s[0],2);}
	}

	elsif($t_nm eq "천사의 베풀어"){
		if(&used){return;}
		&add_msg("null","3장 드로 , 2장 버린다! ");
		&tehuda_draw(0,3,1);
		$seast="999900001";
		$tmp_syorip="<>n-t_sute<>g-1<>i-$s_a<>p-2";&go_select_syori;
	}

	elsif($t_nm eq "욕망의 항아리"){
		if(&used){return;}
		&add_msg("null","덱으로부터 2장 드로 했다! ");
		&tehuda_draw(0,2);
	}

	elsif($t_nm eq "마음의 변화"){
		if(&akichk()){return;}
		$seast="091601";
		if(&go_card_search){return;}
		&cpu_get_saikyo();

		if(&used){return;}

		&add_msg("null","턴 종료시까지 ,$c_name[$fld[$res_s[0]]]를 조종할 수가 있다! ");
		&ctrl_ido($res_s[0],$nf0);
		$fld_koka[$nf0] .= "kokoro<>";
	}

	elsif($t_nm eq "카드 파괴"){
		if(&used){return;}
		&add_msg("null","서로의 패를 모두 버려 그 장수만 덱으로부터 드로! ");
		for($i=0;$i<2;$i++){
			$tsno=$sno[$i];if($i==1){$method=2;}else{$method="";}
			$maisu=&maisu_count(6+$i);
			$in_proc=1;
			for($j=0;$j<$#{$tehuda[$tsno]}+1;$j++){&go_boti2($j,$i,$method);}
			$in_proc="";
			undef(@{$tehuda[$tsno]});&maryoku(17,$i,$maisu);
			&tehuda_draw($i,$maisu);
		}
	}

	elsif($t_nm eq "너무 얕은 무덤"){
		if(&used){return;}
		$seast="09950000001";
		$jokenst='$irrflg!=1 && $cardno!=1106';
		$tmp_syorip="<>n-hakaana<>g-1<>i-$s_a";&go_select_syori;
		$tmp_syorip="<>n-hakaana<>g-1<>i-$s_d";&go_select_syori;
	}
	elsif($t_nm eq "죽은 자의 소생" || $t_nm eq "너무 빠른 매장" || $t_nm eq "리빙 데드의 부르는 소리"){
		if(&akichk()){return;}
		if(&ext_chk()){return;}
		if($t_nm=~/^죽/){$kind=0;}
		elsif($t_nm=~/^너/){$kind=1;}
		elsif($t_nm=~/^리/){$kind=2;}

		$seast="09940000001";
		if($kind==0){$seast.="1";}

		$jokenst='$irrflg!=1 && $cardno!=1106';
		$go_msg="(묘지에 몬스터가 없다)";
		if($kind==0){$tmp_syorip.="<>o-공격 표시::수비 표시";}
		if(&go_card_search){return;}
		&cpu_get_saikyo();

		$tmpno=&getf_res($res_s[0]);
		$tmpno=~s/_a$//;
		if($c_zokusei[$tmpno] eq "신" && $res_s[0]>=300){&add_msg("null","!$s_a신을 조종할 수 없다! ");return;}
		if(&ext_chk("","",$tmpno)){return;}

		if($kind==1 && $cont_flg!=1){
			if($cpu[$s_a]==1 && $lp[$s_a]<1000){return;}
			&add_msg("null","라이프를800지불해 --");
			$lp[$s_a]-=800;&chk_lp;
		}

		if(&used){return;}
		if(($kind==1 || $kind==2) && $fld[$use_f_no] eq ""){return;}

		&put_field($res_s[0]);
		if($F{'options'}==1){$fld_ad[$nf0]=1;}

		if($kind==0){&add_msg("null","<b>묘지로부터$c_name[$tmpno]가 생환! </b>");}
		elsif($kind==1){&add_msg("null","<b>묘지로부터$c_name[$tmpno]가 되살아났다! </b>");}
		elsif($kind==2){&add_msg("null","<b>묘지로부터$c_name[$tmpno]가 기어 나오고 했다…! </b>");}

		if($res_s[0]<300){&del_null(*boti,$s_a);&hosatu(0);}
		else{&del_null(*boti,$s_d);$fld_koka[$nf0]="moto_$s_d<>teni_$s_a<>";&hosatu(1);}

		if($player[$s_a]==12 && $tmpno==918){&add_msg($pn[$s_a],"(이 카드만은 묘지에 두고 싶지 않았던 응은…)");}
		if($kind==1 || $kind==2){&soubi($nf0,$use_f_no);}

		if($tmpno==925){$fld_koka[$nf0].="sosei_$turn<>";}
		elsif($tmpno==1139){&tyrant_sosei;if($kind==2){&go_boti($use_f_no);}}
		elsif(($tmpno==1121 || $tmpno==1124) && $kind==1){&go_boti($use_f_no);}
	}

	elsif($c_syuzoku[$use_cno] eq "의식"){
		if(&ext_chk()){return;}
		for($i=0;$i<$#{$tehuda[$s_a]}+1;$i++){if($tehuda[$s_a][$i]==$G_M{$use_cno}){last;}}
		if($i==$#{$tehuda[$s_a]}+1){&add_msg("null","!$s_a(대응하는 의식 몬스터가 패에 없다)");return;}

		$tmp_syorip.="<>m-(별이$G_S{$use_cno}이상이 되도록 제물을 선택한다)<>o-공격 표시::수비 표시";
		$i+=50;$seast="099210001";$jokenst='$res_si!='.$i;$go_hit="<99";
		if(&go_card_search){return;}

		$tmp_lv=0;$fld_flg="";undef(@res_s2);
		for($i=0;$i<$#res_s+1;$i++){
			if($res_s[$i]>=50){$tmp=$tehuda[$s_a][$res_s[$i]-50];$ftmp="";}
			else{
				if($cpu[$s_a]==1 && $c_ap[$G_M{$use_cno}]<=$ap_fld[$res_s[$i]]){$res_s[$i]="";next;}
				$tmp=$fld[$res_s[$i]];$fld_flg=1;$ftmp=$res_s[$i];
			}
			$tmp_lv+=&lv_st($tmp,$ftmp);
			push(@res_s2,$res_s[$i]);
			if($tmp_lv>=$G_S{$use_cno}){last;}
		}
		@res_s = @res_s2;

		if($tmp_lv<$G_S{$use_cno}){&add_msg("null","!$s_a(별의 수가 부족하다)");return;}
		if($fld_flg eq "" && &akichk()){return;}
		$go_hit=$#res_s+1;
		if(&used){return;}

		if($#res_s>0 && $t_nm=~/^카오스/){&add_msg("null","하나의 영혼은 히카루를 불러 , 하나의 영혼은 어둠을 이끈다! ");}

		$tmp_name="";
		for($i=0;$i<$#res_s+1;$i++){
			if($res_s[$i]>=50){$tmp_name.="$c_name[$tehuda[$s_a][$res_s[$i]-50]](와)과";&go_boti2($res_s[$i]-50,0,3);}
			else{$tmp_name.="$c_name[$fld[$res_s[$i]]]와";&go_boti($res_s[$i],4);}
		}
		$tmp_name=~s/와$//;
		$tmp=$c_name[$G_M{$use_cno}];
		if($tmp eq "매지션·오브·블랙 카오스"){$tmp="흑나무 혼돈의 마술사　$tmp";}
		if($tmp eq "카오스·솔저"){$tmp="전설의 검 투사　$tmp";}
		&add_msg("null","$tmp_name(을)를 살리고 지에 바치고 --<br><b>$tmp강림! </b>");
		if($tmp eq "요새 고래" && $player[$s_d]==3){&add_msg("조이","와…이런게 있었어―！！");}

		for($i=0;$i<$#{$tehuda[$s_a]}+1;$i++){if($tehuda[$s_a][$i]==$G_M{$use_cno}){last;}}
		&fld_chk();
		&put_field($i+50);
		if($F{'options'}==1){$fld_ad[$nf0]=1;}
	}

	elsif($t_nm eq "융합" || $t_nm eq "퓨전·게이트"){
		if(&ext_chk()){return;}
		$tmp_syorip.="<>o-공격 표시::수비 표시";$seast="099910001000001";$go_hit="<99";
		if(&go_card_search){return;}

		@res_s2 = sort {$a<=>$b;} @res_s;undef(@res_s);
		$yugo_ta = $res_s2[$#res_s2];
		if($yugo_ta<600){return;}
		$yugmon=$yugo[$s_a][$yugo_ta-600];
		@sozai = split(/=/,$yulib{$yugmon});

		$fld_flg=0;$daiyo=0;
		for($i=0;$i<$#res_s2;$i++){
			if($res_s2[$i]>100){return;}
			$tmpno=&getf_res($res_s2[$i]);
			if(grep(/^$tmpno$/,@daiyo_mst)){$daiyo++;push(@res_s,$res_s2[$i]);}
			else{
				for($j=0;$j<$#sozai+1;$j++){
					if($sozai[$j]==$tmpno){
						$sozai[$j]=9999;push(@res_s,$res_s2[$i]);
						if($res_s2[$i]<50){$fld_flg=1;}
						last;
					}
				}
			}
		}
		if($daiyo>1){&add_msg("null","!$s_a(대용 몬스터를 사용할 수 있는 것은 1체까지다)");return;}
		if($daiyo>0 && ($yugmon==1107 || $yugmon==1144 || $yugmon==1124 || $yugmon==1225 || $yugmon==1226)){&add_msg("null","!$s_a(이 융합에 대용 몬스터는 사용할 수 없다)");return;}

		if($fld_flg==0 && &akichk()){return;}

		if($#res_s!=$#sozai){&add_msg("null","!$s_a(융합할 수 없다)");return;}

		if($yugmon==1225){
			for($i=0;$i<$#res_s2;$i++){
				if($res_s2[$i]>=50 || $fld_koka[$res_s2[$i]]=~/irr/){&add_msg("null","!$s_a(소재는 올바른 순서로 장소에 나오지 않으면 안 된다)");return;}
			}
			if($cont_flg!=1 && (($player[$s_a]==0 && $player[$s_d]!=2) || ($player[$s_a]==2 && $player[$s_d]!=0))){&mofdk;}
		}

		push(@res_s,$yugo_ta);$go_hit=$#res_s+1;
		if(&used){return;}

		if($yugo_ta eq ""){return;}

		$name_tmp="";$yutmp="";
		for($i=0;$i<$#res_s;$i++){
			if($res_s[$i]<50){
				$name_tmp.="$c_name[$fld[$res_s[$i]]]와";
				$yutmp.=$fld[$res_s[$i]]."-";
				if($t_nm eq "융합"){&go_boti($res_s[$i]);}
				else{&syometu($res_s[$i]);}
			}
			else{
				$name_tmp.="$c_name[$tehuda[$s_a][$res_s[$i]-50]]과";
				$yutmp.=$tehuda[$s_a][$res_s[$i]-50]."-";
				if($t_nm eq "융합"){&go_boti2($res_s[$i]-50,0,3);}
				else{$tehuda[$s_a][$res_s[$i]-50]="";}
			}
		}
		&fld_chk();
		&put_field($yugo_ta);&del_null(*yugo,$s_a);
		if($F{'options'}==1){$fld_ad[$nf0]=1;}
		$fld_koka[$nf0].="yugo_$yutmp<>";

		$name_tmp=~s/과$//;
		&add_msg("null","$name_tmp가 융합! <br><b>$c_name[$fld[$nf0]]! </b>");
		if($c_name[$fld[$nf0]] eq "정안의 궁극용" && $player[$s_a]==2){&add_msg($pn[$s_a],"<b>하하하 어때! <br>이거야 말로 사상 최강으로 화려한 궁극 살륙 병기의 모습이다! </b>");}

	}

	elsif($t_nm eq "융합 현자"){
		if(&used){return;}
		$yuflg=0;
		for($i=0;$i<$#{$deck[$s_a]}+1;$i++){
			if($c_name[$deck[$s_a][$i]] eq "융합"){last;}
		}
		if($i==$#{$deck[$s_a]}+1){&add_msg("null","그러나 , 덱에는 「융합」이 없었다! ");}
		else{
			push(@{$tehuda[$s_a]},$deck[$s_a][$i]);
			$deck[$s_a][$i]="";
			&del_null(*deck,$s_a);
			&add_msg("null","「융합」을 1매 명함에 가세했다! ");
		}
	}

	elsif($t_nm eq "악몽의 철함"){
		if(&used){return;}
		if($fld[$use_f_no] eq ""){$fld_koka[$use_f_no]="";return;}
		&add_msg("null","서로의 플레이어는 철의 우리에게 갇혀졌다! <br>2턴의 사이 , 어느쪽이나 공격은 할 수 없다! ");
		if($player[$s_a]==6){&add_msg("마리크","어때…　철함 안에서 자유를 빼앗긴 기분은…<br>굴욕…?　절망…?　비탄…? ");}
	}
	elsif($t_nm eq "빛의 봉인검"){
		if(&used){return;}
		&add_msg("null","천보다 성스러운 검이 쏟아진다! <br>3턴의 사이 , 상대의 공격을 봉한다! ");
		for($u_i=$fw1[$s_d];$u_i<$fw1[$s_d]+5;$u_i++){if($fld_rf[$u_i]==1){&reverse($u_i);}}
	}
	elsif($t_nm eq "허리케인"){
		if(&used){return;}
		&add_msg("null","맹렬한 회오리가 발생! <br>장소의 마법·함정 카드는 패로 돌아온다! ");
		for($i=$fw2[$s_d];$i<$fw2[$s_d]+5;$i++){&return_tehuda($i);}
		for($i=$fw2[$s_a];$i<$fw2[$s_a]+5;$i++){if($i!=$use_f_no){&return_tehuda($i);}}
		&return_tehuda($fside[$s_d]);&return_tehuda($fside[$s_a]);
	}
	elsif($t_nm eq "태풍"){
		if(&used){return;}
		&add_msg("null","태풍이 카드를 날려 버린다! <br><b>장소의 모든 마법·함정 카드가 소멸! </b>");
		for($u_i=$fw2[$s_d];$u_i<$fw2[$s_d]+5;$u_i++){
			if(&nisewana_chk($u_i)){&go_boti($u_i,2);}
		}
		for($u_i=$fw2[$s_a];$u_i<$fw2[$s_a]+5;$u_i++){&go_boti($u_i,2);}
		&go_boti($fside[$s_d],2);&go_boti($fside[$s_a],2);
	}

	elsif($t_nm eq "하피의 날개추"){
		if(&used){return;}
		&add_msg("null","날개추가 장소를 쓸어 간다! <br><b>상대의 장소의 마법·함정 카드가 소멸! </b>");
		for($u_i=$fw2[$s_d];$u_i<$fw2[$s_d]+5;$u_i++){
			if(&nisewana_chk($u_i)){&go_boti($u_i,2);}
		}
		&go_boti($fside[$s_d],2);
	}

	elsif($t_nm eq "번개"){
		if(&used){return;}
		&add_msg("null","번개가 쏟아진다! <br><b>상대의 장소의 몬스터가 소멸! </b>");
		for($u_i=$fw1[$s_d];$u_i<$fw1[$s_d]+5;$u_i++){if(!(&fisher($u_i))){&go_boti($u_i);}}
	}

	elsif($t_nm eq "블랙홀"){
		if(&used){return;}
		&add_msg("null","블랙홀이 발생! <br><b>모든 몬스터는 삼켜진다! </b>");
		for($u_i=$fw1[$s_d];$u_i<$fw1[$s_d]+5;$u_i++){if(!(&fisher($u_i))){&go_boti($u_i);}}
		for($u_i=$fw1[$s_a];$u_i<$fw1[$s_a]+5;$u_i++){if(!(&fisher($u_i))){&go_boti($u_i);}}
	}

	elsif($c_syuzoku[$use_cno] eq "필드"){
		if(&used){return;}
		&add_msg("null",$m_msg{$use_cno});
	}
	elsif($m_koka{$use_cno}=~/lp([\+-])(\d+)/){	#라이프 회복·라이프 데미지
		if($t_nm eq "화염 지옥" && $cpu[$s_a]==1 && $lp[$s_a]<=500){return;}
		if(&used){return;}
		&add_msg("null",$m_msg{$use_cno});
		if($1 eq '+'){&lp_up($2);}
		else{$lp[$s_d]-=$2;}
		if($t_nm eq "화염 지옥"){$lp[$s_a]-=500;}
		elsif($t_nm eq "은혜의 비"){&lp_up(1000,1,1);}
		&chk_lp;
	}

	else{
		if(&used){return;}
		&add_msg("null","페가수스 「Sorry , 현재 사용할 수 있는 카드는<a href=\"$ahelp\" target=new>이것</a>뿐 이에요~」");
	}
	1;
}


sub used{
	local($i,$tmp);

	if($cont_flg!=1){

		if($chain[0]=~/^[12]-[12]-/ && $use_cno!=333 && $use_cno!=332){
			@res_sbak=@res_s;
			&del_chain;
			@res_s=@res_sbak;
			if($kok[0][6] ne "" && $c_zokusei[$use_cno] eq "함정"){&add_msg("null","!$s_a(사이코·손카가 장소에 있는 한 , 함정을 사용할 수 없다! )");return 1;}
		}

		$tmp_kind = $c_syuzoku[$use_cno];
		if($tmp_kind eq "통상" || $tmp_kind eq "장비"){$tmp_kind = "";}

		if(($c_zokusei[$use_cno] ne "함정" && $c_syuzoku[$use_cno] ne "속공") || $use_cno==1097){&change_phase(2);}
		if($phase==2){$jok[7]=1;}
		if($c_end==2){$c_end="";}

		if($c_zokusei[$use_cno] eq "마"){
			if($use_cno==1074 && $player[$s_a]==8){&add_msg($pn[$s_a],"햐핫핫학!　<b>요정 발동! </b>");}
			elsif($tmp_kind ne ""){&add_msg($pn[$s_a],"$tmp_kind마법<b>「$t_nm」</b>! ");}
			else{&add_msg($pn[$s_a],"마법 카드<b>「$t_nm」</b>! ");}
		}
		elsif($c_zokusei[$use_cno] eq "함정"){
			if($use_cno==1097 && $player[$s_a]==20){if($ideyo eq ""){&add_msg($pn[$s_a],"<b>출로!　아포피스! </b>");$ideyo=1;}}
			elsif($use_cno==386 && $player[$s_a]==0){&add_msg($pn[$s_a],"후후…　지금 , 분명히 「공격」이라고 말한 것 같아…. <br>상대의 「공격」의 말이 스윗치가 되어 발동하는 함정 카드! <br><b>「성스러운 배리어 밀러 포스 -」! </b>");}
			elsif($use_cno==386 && $player[$s_a]==1){&add_msg($pn[$s_a],"유감이야…　내가 덮은 카드는…<br><b>「성스러운 배리어 밀러 포스 -」! </b>");}
			elsif($use_cno==94 && $player[$s_a]==3){&add_msg($pn[$s_a],"<B><FONT SIZE=+1 color=$textc_p2>드카! </font><br>하하하하함정 카드 「함정」이야! </b>");}
			elsif($use_cno==1001 && $player[$s_a]==12){&add_msg($pn[$s_a],"예 있고 함정 카드 발동!　<B>격류장은―！！</b>");}
			elsif($player[$s_a]==20){&add_msg($pn[$s_a],"너는 함정에 떨어졌다. <br>너에 설치된 함정 카드는 이것이다!　<b>「$t_nm」! </b>");}
			elsif($tmp_kind ne ""){&add_msg($pn[$s_a],"$tmp_kind함정 발동!　<b>「$t_nm」! </b>");}
			else{&add_msg($pn[$s_a],"함정 카드 발동!　<b>「$t_nm」! </b>");}
		}
		else{&add_msg($pn[$s_a],"<b>$t_nm의 효과 발동! </b>");return;}

		if($use_from eq "t"){
			if($c_syuzoku[$use_cno] eq "필드"){$nf1=$fside[$s_a];}
			else{if(&akichk2()){return;}}
			$use_f_no = $nf1;
			&put_field($use_t_no+50);
			&maryoku(16);
		}
		$fld_rf[$use_f_no]=0;
		$a_m[$use_f_no] = 3;

		if($fld_koka[$use_f_no]=~/hakaarasi/){
			&add_msg("null","<b>무덤 털기에 천벌! </b>　$pn[$s_a]에2000의 데미지! ");
			$lp[$s_a]-=2000;&chk_lp;
		}

		if($go_hit eq ""){$go_hit=$#res_s+1;}
		elsif($go_hit=~/^>/){$go_hit=0;}
		elsif($go_hit=~s/^<//){$go_hit--;}
		undef(@res_s2);$chudan="";
		for($i=0;$i<$#res_s+1 && $i<$go_hit;$i++){
			push(@res_s2,$res_s[$i]);
			if($res_s[$i]<50){$chudan.="$fld[$res_s[$i]]:0:$res_s[$i]-";}
			else{
				$tmp=&getf_res($res_s[$i]);
				$chudan.="$tmp:$basyo-";
			}
		}
		@res_s=@res_s2;

		if($F{'options'} ne ""){$chudan.="-o$F{'options'}";}
		if($c_zokusei[$use_cno] eq "마"){$pat=9;}
		else{$pat=10;}
		$chudan="$s_a-$pat-$use_cno-$use_f_no-$chudan";
		if(&trap_check(1)){return 1;}
	}
	else{
		if(($c_syuzoku[$use_cno] eq "장비" || $c_syuzoku[$use_cno] eq "영속") && $fld[$use_f_no] eq ""){return 1;}
	}
	$a_m[$use_f_no] = "";

	$umuko="";
	if($c_zokusei[$use_cno] eq "함정"){
		if($kok[0][6] ne ""){&add_msg("사이코·손카","<b>트랩·서치! </b>");&add_msg("null","<b>$c_name[$use_cno]은(는) 무효! </b>");$umuko=2;}
		elsif($kok[0][7] ne ""){&add_msg("null","<b>왕궁의 명령에 의해 ,$c_name[$use_cno]는 무효! </b>");$umuko=1;}

		for($i=0;$i<$#res_s+1;$i++){
			if(($fld[$res_s[$i]]==1139 || $fld[$res_s[$i]]==1144) && $fld_rf[$res_s[$i]]!=1){&add_msg("null","<b>$c_name[$fld[$res_s[$i]]]은(는) 함정을 파괴했다! </b>");&go_boti($use_f_no);$umuko=1;}
		}
	}

	elsif($c_zokusei[$use_cno] eq "마" && $use_cno!=1074){
		if($kok[0][8] ne ""){
			&add_msg("null","<b>왕궁의 칙명에 의해 ,$c_name[$use_cno]는 무효! </b>");
			$umuko=1;
		}
		elsif($#res_s==0 && $fld[$res_s[0]]==1026 && $fld_rf[$res_s[0]]==1){&add_msg("null","<b>가드너의 대방패가 마법을 연주해 돌려주었다! </b>");$fld_rf[$res_s[0]]=0;$umuko=2;}
		else{
			for($i=0;$i<$#res_s+1;$i++){
				if($res_s[$i]>=50){next;}
				if(($fld[$res_s[$i]]==1121 || $fld[$res_s[$i]]==1124) && $fld_rf[$res_s[$i]]!=1){&add_msg("null","<b>$c_name[$fld[$res_s[$i]]]은(는) 마법을 연주해 돌려주었다! </b>");&go_boti($use_f_no);$umuko=1;}
				elsif(&fisher($res_s[$i])){&add_msg("null","<b>시·스텔스II! </b>　마법의 효과를 받지 않는다! ");$umuko=1;}
			}
		}

		if(($kok[$s_a][70] ne "" || $kok[$s_d][70] ne "") && $umuko eq ""){
			for($i=0;$i<$#res_s+1;$i++){
				if($res_s[$i]>=50){next;}
				if($fld_rf[$res_s[$i]]!=1 && &syu_st($res_s[$i]) eq "전사" && $kok[$sno[&which_side($res_s[$i],1)]][70] ne ""){last;}
			}
			if($i<$#res_s+1){&add_msg("null","<b>대현자가 마법을 막았다! </b>");&go_boti($use_f_no);$umuko=1;}
		}
	}

	#발동한
	if($umuko!=2){
		if($c_syuzoku[$use_cno] eq "필드"){if($fld_rf[$fside[$s_d]]!=1){&go_boti($fside[$s_d]);}}
		elsif($use_cno==707 || $use_cno==1034){$hk[13]=999;}
		elsif($use_cno==690 || $use_cno==1035){$jok[2+$s_a]=2;}
		elsif($use_cno==707){$hk[13]=999;}
		elsif($fld[$use_f_no] eq ""){}
		elsif($use_cno==125 || $use_cno==930){$fld_koka[$use_f_no].="turn_$turn<>";}
		elsif(($c_syuzoku[$use_cno] eq "장비" && $use_cno!=899) || $use_cno==720 || $use_cno==731){
			if($use_cno==801){&moto_chk($res_s[0]);}
			&soubi($res_s[0],$use_f_no);
		}

		if($kok[0][55] ne "" && $c_zokusei[$use_cno] eq "마" && ($c_syuzoku[$use_cno] eq "통상" || $c_syuzoku[$use_cno] eq "속공")){
			for($i=5;$i<15;$i++){if($fld[$i]==1215 && $fld_rf[$i]!=1){$fld_koka[$i].="ptr:200:0:$turn<>";}}
		}
	}

	if($umuko ne ""){&end_usecard(1);return 1;}

	0;
}

sub end_usecard{
	local($e_mode)=$_[0];	#1-무효시 2-대상 사라지고

	if($use_f_no eq "" || $fld[$use_f_no] eq ""){}
	elsif($c_zokusei[$use_cno] ne "마" && $c_zokusei[$use_cno] ne "함정"){}
	elsif($e_mode==1 && $use_cno==899){&go_boti($use_f_no);}
	elsif($use_cno==1200 || $use_cno==720 || $use_cno==873 || $use_cno==125 || $use_cno==930 || $c_syuzoku[$use_cno] eq "영속" || $c_syuzoku[$use_cno] eq "장비" || $c_syuzoku[$use_cno] eq "필드"){if($e_mode==2){&go_boti($use_f_no);}}
	elsif($use_cno==731 && $fld_koka[$use_f_no]=~/f_/){}
	else{&go_boti($use_f_no);}

	&get_apdp_fld;
	if($chain[0] ne ""){$c_end=1;}
	$used_flg=1;
}


@m_lib = (
1075,'$cardno==945',"300::0","빅크바이파는 파워 캅셀을 취했다! <br>레이저를 장비! ",
757,'&syu_st($res_si) eq "전사"',"700::0","공격력 700포인트 업! <br>드래곤을 일격으로 죽일 수가 있다! ",
998,'&syu_st($res_si) eq "전사"',"800::0","공격력 800포인트 업! <br>번개를 검에 떨어뜨려 , 물 속성 몬스터를 약체화! ",
1191,'&syu_st($res_si) eq "전사"',"800::0","불사의 요력을 가진 칼이다! <br>공격력 800포인트 업! ",
1079,''," ","역병에 시달렸다! <br>2턴 후에 파괴된다! ",
1189,''," ","명경지수의 경지를 얻을 수 있다! ",
1192,''," ","연옥을 품에 숨겼다. ",
635,'',"-500::-500","공수 500다운! <br>반지의 자력이 공격을 끌어당긴다! ",
1032,'',"-700::0",'',
731,'',"500::0",'',
1200,'',"500::0",'',
865,'&syu_st($res_si) eq "기계"','','',
720,'',"300::300",'',
800,'',"700","여자 악마가 입맞춤하여 어둠의 힘이 발동! <br>공격력이 700포인트 업! ",
799,'',"::800","모퉁이의 마력이 빛의 벽을 만든다! <br>수비력이 800포인트 업! ",
798,'',"500","불길한 빛을 가지는 팬던트다! <br>공격력이 500포인트 업! ",
859,'',"700::700","마력을 띤 모퉁이가 장비 된다! <br>공격력 , 수비력이 700포인트 업! ",
797,'',"1000","악마 힘을 가지는 거대한 도끼다! <br>공격력이 1000포인트 업! ",
730,'$cardno==207 || $cardno==208 || $cardno==1037',"500","요염한 본테이지에 몸을 싼다! <br>공격력이 500포인트 업! ",
88,'&syu_st($res_si) eq "마법사"',"300::300","마도의 비술을 기억했다! <br>공격력 , 수비력이 300포인트 업! ",
87,'&syu_st($res_si) eq "전사"',"300::300","전설의 검을 장비 했다! <br>공격력 , 수비력이 300포인트 업! ",
90,'&syu_st($res_si) eq "야수"',"300::300","날카로운 맹수의 이빨이 줄선다! <br>공격력 , 수비력이 300포인트 업! ",
91,'&syu_st($res_si) eq "언데드"',"300::300","마력을 가지는 수정의 힘! <br>공격력 , 수비력이 300포인트 업! ",
89,'&syu_st($res_si) eq "물"',"300::300","해의 신이 힘을 준다! <br>공격력 , 수비력이 300포인트 업! ",
129,'&syu_st($res_si) eq "기계"',"300::300","보다 강력하게 개조되었다! <br>공격력 , 수비력이 300포인트 업! ",
130,'&syu_st($res_si) eq "식물"',"300::300","마력을 띤 균이 번식한다! <br>공격력 , 수비력이 300포인트 업! ",
128,'&syu_st($res_si) eq "공룡"',"300::300","체온이 올라 , 활동이 활발하게! <br>공격력 , 수비력이 300포인트 업! ",
131,'&syu_st($res_si) eq "곤충"',"300::300","레이저 캐논을 장비! <br>공격력 , 수비력이 300포인트 업! ",
132,'&syu_st($res_si) eq "악마"',"300::300","어둠의 힘으로 파워업! <br>공격력 , 수비력이 300포인트 업! ",
180,'&syu_st($res_si) eq "천사"',"300::300","처음부터 내려 주신 성스러운 활과 화살이다! <br>공격력 , 수비력이 300포인트 업! ",
184,'&syu_st($res_si) eq "비행야수"',"300::300","하늘을 춤추는 사람에게 부는 순풍! <br>공격력 , 수비력이 300포인트 업! ",
182,'&syu_st($res_si) eq "야수전사"',"300::300","달빛이 마성을 불러 깬다! <br>공격력 , 수비력이 300포인트 업! ",
183,'&syu_st($res_si) eq "번개"',"300::300","전격 쇼크로 적을 분쇄! <br>공격력 , 수비력이 300포인트 업! ",
181,'&syu_st($res_si) eq "드래곤"',"300::300","드래곤족이 지키는 신비의 보물이다! <br>공격력 , 수비력이 300포인트 업! ",
384,'',"500::500","검에 머무는 집념이 머슴을 지배한다! <br>공격력 , 수비력이 500포인트 업!",
448,'$c_zokusei[$cardno] eq "땅"',"400::-200","대지의 힘이 각성 한다! <br>공격력 400포인트 업! 수비력 200포인트 다운! ",
449,'$c_zokusei[$cardno] eq "어둠"',"400::-200","신을 깨는 어둠의 힘이 머문다! <br>공격력 400포인트 업! 수비력 200포인트 다운! ",
450,'$c_zokusei[$cardno] eq "빛"',"400::-200","엘프족의 빛이 선 되는 사람을 비춘다! <br>공격력 400포인트 업! 수비력 200포인트 다운! ",
451,'$c_zokusei[$cardno] eq "바람"',"400::-200","마법의 부채로 돌풍이 일어난다! <br>공격력 400포인트 업! 수비력 200포인트 다운! ",
452,'$c_zokusei[$cardno] eq "불"',"400::-200","붉게 불타는 창을 장비 했다! <br>공격력 400포인트 업! 수비력 200포인트 다운! ",
453,'$c_zokusei[$cardno] eq "물"',"400::-200","등껍데기를 몸에 익히고 파워업! <br>공격력 400포인트 업! 수비력 200포인트 다운! ",
726,'$c_zokusei[$cardno] eq "불"',"700","염의 마법이 검에 머문다! <br>공격력 700포인트 업! ",
727,'$c_zokusei[$cardno] eq "빛"',"700","빛나 빛나는 성이 나타났다! <br>공격력 700포인트 업! ",
729,'&syu_st($res_si) eq "곤충"',"700","곤충만을 장비 할 수 있는 강력한 화기다! <br>공격력 700포인트 업! ",
958,''," ","수비 몬스터를 격파했을 때 , 운석이 떨어질거야! ",
853,''," ","몬스터가 거대화!　자신이 열세하면 공격력은 배에 --<br>우세하면 반이 된다! ",
1022,''," ","몬스터의 단결이 힘이 된다! <br>자신의 겉 표시 몬스터 도대체에 대해 , 공수 800업! ",
1023,''," ","마법과 함정이 힘을 준다! <br>자군 마법·함정 존의 카드 1매에 대해 , 공수 500업! ",
985,'',"1000::-1000","몬스터의 흉포성을 꺼내는 가면이다! <br>공격력1000업 , 수비력1000다운! ",
988,''," ","저주의 힘에 덮인 가면이다! <br>공격을 봉해 스탄바이페이즈 마다500의 데미지! ",
,
,
52,'',"lp+200","재료가 모두 불명의 맛있는 카레다! ",
421,'',"lp+400","푸르고 신선한 액체다. ",
92,'',"lp+500","거품이 이는 새빨간 액체를 마셨다. ",
134,'',"lp+600","쓴 맛이 입에 퍼져 가는…",
456,'',"lp+800","자비 깊은 천사가 스스로 피를 흘리는…",
644,'',"lp+1000","치료의 신이 상처를 달래는…",
957,'',"lp+1000","모든 플레이어에 위안의 비가 쏟아지는…",
422,'',"lp-300","번개가 플레이어를 직격! <BR>상대의 라이프에 300의 데미지! ",
53,'',"lp-500","플레이어에 불의 구슬이 쏟아진다! <BR>상대의 라이프에 500의 데미지! ",
93,'',"lp-200","조금 뜨거운 불의 마법<BR>상대의 라이프에 200의 데미지! ",
127,'',"lp-600","상대 플레이어는 불길에 구워진다! <BR>상대의 라이프에 600의 데미지! ",
457,'',"lp-800","큰 화재가 일어난다! <BR>상대의 라이프에 800의 데미지! ",
382,'',"lp-1000","지옥의 불길이 서로의 몸을 굽는다! <BR>상대에게 1000, 자신에게 500의 데미지! ",
230,'&syu_st($res_si) eq "전사"',"kill","말살자의 총탄이 전사를 노린다! <br>전사족 몬스터는 전멸! ",
231,'&syu_st($res_si) eq "기계"',"kill","강산이 폭풍우가 되어 금속을 녹인다! <br>기계족 몬스터는 전멸! ",
232,'&syu_st($res_si) eq "곤충"',"kill","충 싫은 것 신이 살충제를 내뿜었다! <br>곤충족 몬스터는 전멸! ",
233,'&syu_st($res_si) eq "암석"',"kill","신이 내뿜은 숨에 의해 바위는 모래로 바뀐다! <br>암석족 몬스터는 전멸! ",
234,'&syu_st($res_si) eq "어류"',"kill","이 마법으로 바다·호수와 늪의 물은 바싹 말랐다! <br>어족 몬스터는 전멸! ",
598,'&syu_st($res_si) eq "악마"',"kill","신의 힘이 악마를 치운다! <br>악마족 몬스터는 전멸! ",
600,'&syu_st($res_si) eq "마법사"',"kill","모든 마법사는 처형된다! <br>마법사족 몬스터는 전멸! ",
,
45,"종족","드래곤::200::200<>비행야수::200::200<>번개::200::200","드래곤·비행야수·번개족의 공격력과 수비력이 , 각각 200포인트 업! ",
46,"종족","전사::200::200<>야수전사::200::200","전사·야수전사족의 공격력과 수비력이 , 200포인트 업! ",
47,"종족","악마::200::200<>마법사::200::200<>천사::-200::-200","악마·마법사족의 공격력과 수비력이 , 200포인트 업! <br>천사족은 각각 200포인트 다운! ",
48,"종족","공룡::200::200<>언데드::200::200<>암석::200::200","공룡·언데드·암석족의 공격력과 수비력이 , 각각 200포인트 업! ",
49,"종족","곤충::200::200<>식물::200::200<>물::200::200<>야수전사::200::200","곤충·식물·물·야수전사족의 공격력과 수비력이 , 각각 200포인트 업! ",
50,"종족","어류::200::200<>해룡::200::200<>번개::200::200<>물::200::200<>기계::-200::-200<>화염::-200::-200","어류·해룡·번개·물족의 공격력과 수비력이 , 각각 200포인트 업! <br>기계·화염족은 각각 200포인트 다운! ",
1190,"속성","물::200::200","필드는 바다의 수도로 바뀐다! <br>물 속성 몬스터의 잽싸졌다! ",
844,"속성","땅::500::-400","모든 땅 속성 몬스터의 공격력은 500포인트 업! <br>수비력은 400포인트 다운! ",
845,"속성","물::500::-400","모든 물 속성 몬스터의 공격력은 500포인트 업! <br>수비력은 400포인트 다운! ",
846,"속성","불::500::-400","모든 불길 속성 몬스터의 공격력은 500포인트 업! <br>수비력은 400포인트 다운! ",
847,"속성","바람::500::-400","모든 바람 속성 몬스터의 공격력은 500포인트 업! <br>수비력은 400포인트 다운! ",
848,"속성","빛::500::-400","모든 광속성 몬스터의 공격력은 500포인트 업! <br>수비력은 400포인트 다운! ",
849,"속성","어둠::500::-400","모든 어둠 속성 몬스터의 공격력은 500포인트 업! <br>수비력은 400포인트 다운! ",
796,"ad","1::0::500","성역에 가성이 가득 차는…<br>수비 표시 몬스터의 수비력은 500포인트 업! ",
329,"속성","빛::500::0<>어둠::-400::0",'',
328,"속성","어둠::500::0<>빛::-400::0",'',
327,"속성","물::500::0<>불::-400::0",'',
325,"속성","불::500::0<>물::-400::0",'',
324,"속성","바람::500::0<>땅::-400::0",'',
330,"속성","땅::500::0<>바람::-400::0",'',
1101,"종족","식물::500::500",'',
);

for($i=0;$i<$#m_lib+1;$i++){
	$m_joken{$m_lib[$i]} = $m_lib[$i+1];
	$m_koka{$m_lib[$i]} = $m_lib[$i+2];
	$m_msg{$m_lib[$i]} = $m_lib[$i+3];
	$i+=3;
}
undef(@m_lib);
1;
