sub chaospod{
	local($l_side)=$_[0];
	$j=$sno[$l_side];

	$cou1=$#{$deck[$j]}-$ccou[$j];
	$cou=0;undef(@sutehuda);

	for($i=0;$i<$#{$deck[$j]}+1;$i++){
		if($cou>=$cou1){last;}
		$cardno=$deck[$j][$i];$deck[$j][$i]="";$flg=0;

		if($c_zokusei[$cardno] ne "마" && $c_zokusei[$cardno] ne "함정"){
			$cou++;
			if($c_lv[$cardno]>4 || $c_syokan[$cardno]==2 || $c_syokan[$cardno]==3 || $c_syokan[$cardno]==6 || 
			 &ext_chk("",1,$cardno)){push(@sutehuda,$cardno);}
			else{$flg=1;}
		}
		else{push(@sutehuda,$cardno);}

		if($flg==1 && &akichk($l_side)){$flg="";}

		if($flg==1){
			&add_msg("null","$pn[$j]은$c_name[$cardno]을 넘겼다. →필드에 세트");
			$fld[$nf0]=$cardno;
			&ext_set($nf0,1);
		}
		else{&add_msg("null","$pn[$j]는$c_name[$cardno]을 넘겼다. →묘지에");}
	}
	&del_null(*deck,$j);
	&arr_to_boti(*sutehuda,$l_side);
}

sub cyberpod{
	local($l_side)=$_[0];
	local($tsno)=$sno[$l_side];

	&add_msg("null","$pn[$tsno]는 덱으로부터 5장 넘겼다. ");
	undef(@sutehuda);
	for($i=0;$i<5 && $i<$#{$deck[$tsno]}+1;$i++){
		$cardno=$deck[$tsno][$i];$deck[$tsno][$i]="";
		&add_msg("null","$c_name[$cardno]");
		if($c_zokusei[$cardno] eq "마" || $c_zokusei[$cardno] eq "함정" || $c_lv[$cardno]>4 || $c_syokan[$cardno]==2 || $c_syokan[$cardno]==3 || &ext_chk("",1,$cardno)){push(@{$tehuda[$tsno]},$cardno);}
		elsif(&akichk($l_side)){push(@sutehuda,$cardno);}
		else{$fld[$nf0]=$cardno;$fld_ad[$nf0]=0;$fld_rf[$nf0]=0;}
	}
	&del_null(*deck,$tsno);
	if($#sutehuda>-1){&arr_to_boti(*sutehuda,$l_side);}
}

sub use_koka_r{				#리버스 효과
	local($cardno) = $_[0];
	local($para) = $_[1];
	local($i,$j,@res_s,$t_nm);

	$tmp_syorip="<>c-7-$cardno<>i-$s_a<>p-$para<>g-1";

	$t_nm = $c_name[$cardno];
	$go_hit=1;$jokenst="";$go_msg="";$seast="";

	if($cont_flg!=1){
		if($kok[0][29] ne ""){&add_msg("null","<b>왕궁의 호령에 의해 ,$t_nm의 효과는 무효! </b>");return;}
		if($kok[0][58] ne ""){&add_msg("null","<b>데스·demon·드래곤에 의해 ,$t_nm의 효과는 무효! </b>");return;}
		&add_msg("null","<b>리버스 효과 발동! 「$t_nm」! </b>");
	}

	if($t_nm eq ""){}
	elsif($t_nm eq "암흑의 성"){
		if($fld[$para]!=630){return;}
		&add_msg("null","암흑의 힘이 장소에 퍼졌다! <br>언데드는 1턴 마다 파워업! ");
		for($i=5;$i<15;$i++){
			if($fld[$i] ne "" && $fld_rf[$i]!=1 && &syu_st($i) eq "언데드"){
				$ko_no=&get_ko_no($fld_koka[$i]);
				$fld_koka[$para].="f_".$i."::".$ko_no."<>";
				$fld_koka[$i].="kuramasi:$turn<>";
			}
		}
	}
	elsif($t_nm eq "성스러운 방비손"){
		$seast="901911";
		if(&go_card_search){return;}
		&add_msg("null","$c_name[$fld[$res_s[0]]]을 덱에 되돌렸다! ");
		$l_side=&which_side($res_s[0]);$tsno=$sno[$l_side];
		unshift(@{$deck[$tsno]},$fld[$res_s[0]]);&syometu($res_s[0]);
		for($i=$fw1[$s_a];$i<$fw1[$s_a]+5;$i++){
			if($fld[$i] ne "" && $fld_rf[$i]!=1 && &syu_st($i) eq "전사"){
				&add_msg("null","게다가 전사에의 가호의 힘이 발동! ");
				$tmp_syorip="<>c-7-161<>i-$s_a<>g-1";
				&go_select_syori;last;
			}
		}
	}
	elsif($t_nm eq "주홍 있고 구두"){
		$seast="901911";
		if(&go_card_search){return;}
		&add_msg("null","저주의 구두를 신었다$c_name[$fld[$res_s[0]]]는 방향을 바꾸었다! ");
		$fld_ad[$res_s[0]]=1-$fld_ad[$res_s[0]];&piero($res_s[0]);
	}
	elsif($t_nm eq "왕좌의 침략자"){
		if($phase==3){&add_msg("null","(배틀페이즈에는 사용할 수 없는)");return;}
		if($fld[$para]!=776){return;}
		$seast="991901";
		if(&go_card_search){return;}
		&ctrl_chg($para,$res_s[0]);
	}
	elsif($t_nm eq "타임·보마"){
		&add_msg("null","폭탄에 스윗치가 들어갔다! ");
		$fld_koka[$para].="used<>";
	}
	elsif($t_nm eq "엄격한 노마술사"){
		&add_msg("null","상대가 덮고 카드를 엄격하게 조사했다. ");
		for($i=$fw1[$s_d];$i<$fw1[$s_d]+5;$i++){if($fld[$i] ne "" && $fld_rf[$i]==1){&add_msg("null",$c_name[$fld[$i]]);}}
		for($i=$fw2[$s_d];$i<$fw2[$s_d]+5;$i++){if($fld[$i] ne "" && $fld_rf[$i]==1){&add_msg("null",$c_name[$fld[$i]]);}}
	}
	elsif($t_nm eq "다크 패밀리어"){
		&add_msg("null","영혼의 소를 준비했다. ");
	}
	elsif($t_nm eq "번개 신선"){
		&lp_up(3000);
	}
	elsif($t_nm eq "섬유 포드"){
		&add_msg("null","모든 카드는 덱으로 돌아와 --<br>셔플 후 , 서로 5장 드로! ");
		for($i=0;$i<22;$i++){&return_tehuda($i,1);}
		undef(@fld);undef(@fld_koka);undef(@kok);
		for($tsno=1;$tsno<3;$tsno++){
			for($i=0;$i<$#{$boti[$tsno]}+1;$i++){
				$boti[$tsno][$i]=~s/_.+$//;
				if($c_syokan[$boti[$tsno][$i]]==1){push(@{$yugo[$tsno]},$boti[$tsno][$i]);}
				else{push(@{$deck[$tsno]},$boti[$tsno][$i]);}
			}
			for($i=0;$i<$#{$tehuda[$tsno]}+1;$i++){
				if($tehuda[$tsno][$i] eq ""){next;}
				if($tep[$tsno][$i] ne ""){push(@{$deck[3-$tsno]},$tehuda[$tsno][$i]);}
				else{push(@{$deck[$tsno]},$tehuda[$tsno][$i]);}
			}
			&shuffle(*deck,$tsno);
		}
		undef(@boti);undef(@tehuda);undef(@tep);
		&tehuda_draw(0,5,1);
		&tehuda_draw(1,5,1);
	}
	elsif($t_nm eq "환상 소환사"){
		if(&ikenie_chk){return;}
		if($#{$yugo[$s_a]}<0){&add_msg("null","(융합 몬스터가 없다)");return;}
		$cou=&maisu_count(0);if($fld[$para] ne ""){$cou--;}
		if($cou<1){&add_msg("null","(생지가 없다)");return;}
		$seast="999910000000001";$go_hit=2;$jokenst='$cardno!=1225 && $cardno!=1226 && $res_si!='.$para;$go_msg=" ";
		if($kekka=&go_card_search){if($kekka==1){&go_select_syori;}return;}
		@res_s2 = sort {$a <=> $b;} @res_s;
		if($res_s2[0]>50 || $res_s2[1]<600){&go_select_syori;return;}
		&add_msg("null","<b>환상 소환! </b><br>$c_name[$fld[$res_s2[0]]](을)를 생지에 ,$c_name[$yugo[$s_a][$res_s2[1]-600]]를 호출했다! ");
		&go_boti($res_s2[0],4);
		&fld_chk();&put_field($res_s2[1]);
		&del_null(*yugo,$s_a);
		$fld_koka[$nf0].="genso<>irr<>";
	}
	elsif($t_nm eq "리그 라스·리퍼"){
		&add_msg("null","서로 패를 1장 버린다! ");
		$jokenst='';$tmp="<>m-(패를 1장 버린다)<>n-t_sute<>g-1<>i-";
		if(&maisu_count(6)>0){$seast="999900001";$tmp_syorip=$tmp."$s_a<>p-1";&go_select_syori;}
		if(&maisu_count(7)>0){$seast="999900001";$tmp_syorip=$tmp."$s_d<>p-1a";&go_select_syori;}
	}
	elsif($t_nm eq "전자 미노충"){
		if(&akichk()){return;}
		$seast="901901";$jokenst='&syu_st($res_si) eq "기계"';$go_hit="<2";$tmp_syorip=~s/<>g-1//;
		if(&go_card_search){return;}
		&add_msg("null","전자 조작! <br>$c_name[$fld[$res_s[0]]]을(를) 자신의 엔드페이즈까지 조작한다! ");
		$fld_koka[$res_s[0]].="minom_$s_a<>";
		&ctrl_ido($res_s[0],$nf0);
	}
	elsif($t_nm eq "뉴트"){
		if($fld[$para] eq ""){return;}
		$fld_koka[$para].="ptr:500:500:0<>";
		&add_msg("null","공격력·수비력이 500업! ");
	}
	elsif($t_nm eq "불길의 여자 암살자"){
		if($#{$deck[$s_a]}+1<3){&add_msg("null","덱에 3매의 카드가 없다. ");return;}
		$tmp="";
		for($i=0;$i<3;$i++){$tmp.="$c_name[$deck[$s_a][$i]](와)과";$deck[$s_a][$i]="";}
		$tmp=~s/와$//;&del_null(*deck,$s_a);
		&add_msg("null","$tmp를 제외해 , 불길로 바꾸어 발했다! <br><b>$pn[$s_d]에800의 데미지! </b>");
		$lp[$s_d]-=800;&chk_lp;
	}
	elsif($t_nm eq "파이야소사라"){
		$tmp="";
		for($i=0;$i<2;$i++){
			if(($rann=&rand_tehuda())<0){&add_msg("null","명함이 2장 없다. ");return;}
			$tmp.="$c_name[$tehuda[$s_a][$rann]]와(과)";$tehuda[$s_a][$rann]="";
		}
		$tmp=~s/와$//;
		&add_msg("null","$tmp를 제외해 , 불길로 바꾸어 발했다! <br><b>$pn[$s_d]에800의 데미지! </b>");
		$lp[$s_d]-=800;&chk_lp;
	}
	elsif($t_nm eq "메타모르폿트"){
		&add_msg("null","서로의 패를 버려 데크로부터 5매 뺐다! ");
		for($i=0;$i<$#{$tehuda[$s_a]}+1;$i++){&go_boti2($i,0);}
		for($i=0;$i<$#{$tehuda[$s_d]}+1;$i++){&go_boti2($i,1,2);}
		&maryoku(17,0,$#{$tehuda[$s_a]}+1);undef(@{$tehuda[$s_a]});
		&maryoku(17,1,$#{$tehuda[$s_d]}+1);undef(@{$tehuda[$s_d]});
		&tehuda_draw(0,5);
		&tehuda_draw(1,5);
	}
	elsif($t_nm eq "니들 웜"){
		&add_msg("null","상대의 데크의 카드를 위로부터 5매 묘지에 버린다! ");
		&deck_to_boti(1,5);
	}

	elsif($t_nm eq "카오스 포드"){
		&add_msg("null","장의 몬스터를 덱에 되돌려 셔플! ");
		$ccou[1]=$#{$deck[1]};$ccou[2]=$#{$deck[2]};
		for($i=5;$i<5*3;$i++){&return_tehuda($i,1);}
		&shuffle(*deck,$s_a);&shuffle(*deck,$s_d);
		&add_msg("null","동수의 몬스터가 나올 때까지 덱으로부터 넘긴다! ");
		&chaospod(0);
		&chaospod(1);
	}
	elsif($t_nm eq "사이버 포드"){
		&add_msg("null","장의 몬스터를 모두 파괴! ");
		$in_proc=1;
		for($i=$fw1[$s_d];$i<$fw1[$s_d]+5;$i++){&go_boti($i);}
		for($i=$fw1[$s_a];$i<$fw1[$s_a]+5;$i++){&go_boti($i);}
		$in_proc="";&add_msg("null","덱 위로부터 5장 넘겨 ,Lv4이하의 몬스터를 필드에 낸다! ");
		&cyberpod(0);&cyberpod(1);

		$seast="99991";$jokenst='';$tmp_p="<>g-1<>l-1<>o-한다(요점 선택)::전부표<>n-cyber<>m-리 수비 표시로 할까요? ";
		$tmp_syorip=$tmp_p."<>i-$s_a";&go_select_syori;
		$tmp_syorip=$tmp_p."<>i-$s_d";&go_select_syori;
	}

	elsif($t_nm eq "악마의 정찰자"){
		&add_msg("null","$pn[$s_d]는 덱으로부터 3장 빼 , 마법 카드를 버렸다. ");
		$tmpp=$#{$tehuda[$s_d]};
		&tehuda_draw(1,3,1);
		$sutflg="";
		for($i=$tmpp+1;$i<$#{$tehuda[$s_d]}+1;$i++){
			if($c_zokusei[$tehuda[$s_d][$i]] eq "마"){
				&add_msg("null","($c_name[$tehuda[$s_d][$i]]를 버린)");
				&maryoku(17,1);&go_boti2($i,1);$sutflg=1;
			}
		}
		if($sutflg!=1){&binjo_chk(0);}
	}
	elsif($t_nm eq "스케르엔제르"){
		&add_msg("null","$pn[$s_a]는 덱으로부터 1장 뺐다. ");
		&tehuda_draw(0,1);
	}
	elsif($t_nm eq "검의 여왕"){
		$cou=&maisu_count(3);
		$tmp=$cou*500;
		&add_msg("null","검의 여왕은 상대의 마법·함정 카드로 검을 던졌다! <br><b>$pn[$s_d]에$tmp의 데미지! </b>");
		$lp[$s_d]-=$tmp;&chk_lp;
	}
	elsif($t_nm eq "폭탄이나 째충"){
		$tmp_syorip.="<>m-뒤 수비 몬스터를 선택해 주고";

		$seast="911901";$go_hit=1;$go_msg="";$jokenst='';
		if(&go_card_search){return;}

		&add_msg("null","폭탄이나 째충은$c_name[$fld[$res_s[0]]]에 폭탄을 던졌다! ");
		if($c_koka[$fld[$res_s[0]]] ne "" || $c_syokan[$fld[$res_s[0]]]==4){
			&add_msg("null","<b>$c_name[$fld[$res_s[0]]]을(를) 파괴했다! </b>");
			&go_boti($res_s[0],5);
		}
		else{&add_msg("null","효과 몬스터는 아니기 때문에 , 굳이 일어나지 않는다. ");}

	}
	elsif($t_nm eq "죽음의 4개(살)별이라고 묻는 벌레"){
		&add_msg("null","상대의 4개별 몬스터는 전멸! ");
		for($i=$fw1[$s_d];$i<$fw1[$s_d]+5;$i++){
			if(&lv_st($fld[$i],$i)==4 && $fld_rf[$i]!=1){&go_boti($i);}
		}
	}
	elsif($t_nm eq "성스러운 마술사" || $t_nm eq "암흑의 가면"){
		if($t_nm=~/^성/){$tmp2="마";$tmp3="마법";}
		else{$tmp2="함정";$tmp3="함정";}
		$tmp_syorip.="<>m-묘지의$tmp3카드를 패에 가세할 수가 있다! ";

		$seast="99990000001";$jokenst='$c_zokusei[$cardno] eq "'.$tmp2.'"';
		if(&go_card_search){return;}

		&add_msg("null","$pn[$s_a]은(는)$c_name[$boti[$s_a][$res_s[0]-200]]을 패에 가세했다! ");
		push(@{$tehuda[$s_a]},$boti[$s_a][$res_s[0]-200]);
		$boti[$s_a][$res_s[0]-200]="";&del_null(*boti,$s_a);
	}
	elsif($t_nm eq "돕페르겐가" || $t_nm eq "토네이도·버드"){
		$tmp_syorip.="<>m-(대상을 2장 선택해 준다)";
		if($t_nm=~/^돕/){$seast="91990011";}
		else{$seast="99990011";}
		$go_hit=2;
		if(&go_card_search){return;}
		$tmp="$c_name[$fld[$res_s[0]]]와$c_name[$fld[$res_s[1]]]";
		if($t_nm=~/^돕/){
			&add_msg("null","$tmp를 파괴했다! ");
			&go_boti($res_s[0],2);&go_boti($res_s[1],2);
		}
		else{
			&add_msg("null","토네이도가 발생! <br>카드를 2매 패에 되돌렸다! ");
			&return_tehuda($res_s[0]);&return_tehuda($res_s[1]);
		}
	}
	elsif($t_nm eq "펭귄·솔저"){
		$tmp_syorip=~s/<>g-1//;
		$tmp_syorip.="<>m-몬스터를 2체까지 패에 되돌릴 수가 있다. ";
		$seast="991911";$jokenst='';$go_hit="<3";
		if(&go_card_search){return;}

		if(&cpu_get_saikyo("991901","",2)){return;}
		for($i=0;$i<2 && $i<$#res_s+1;$i++){&return_tehuda2($res_s[$i],$i);}
	}
	elsif($t_nm eq "하늘하늘"){
		$tmp_syorip.="<>m-몬스터를 1체 패에 되돌린다! ";

		$seast="991911";
		if(&go_card_search){return;}

		$tmp=$res_s[0];
		if(&cpu_get_saikyo("991901")){$res_s[0]=$tmp;}
		&return_tehuda2($res_s[0]);
	}
	elsif($t_nm eq "식인충"){
		$tmp_syorip.="<>m-몬스터를 1체 파괴한다! ";
		$seast="991911";
		if(&go_card_search){return;}

		$tmp=$res_s[0];
		if(&cpu_get_saikyo("991901")){$res_s[0]=$tmp;}

		&add_msg("null","<b>식인충$c_name[$fld[$res_s[0]]]을 죽였다! </b>");
		&go_boti($res_s[0],5);
	}
	elsif($t_nm eq "푸른 첩자" || $t_nm eq "함정술사" || $t_nm eq "카드의 사신"){

		if($t_nm eq "푸른 첩자"){$tmp2="마";$tmp3="마법";}
		else{$tmp2="함정";$tmp3="함정";}
		$tmp_syorip.="<>m-장의$tmp3카드를 파괴한다! ";

		$seast="99990011";
		$jokenst='$fld_rf[$res_si]==1 || $c_zokusei[$fld[$res_si]] eq "'.$tmp2.'"';
		if(&go_card_search){return;}

		if($cpu[$s_a]==1){
			for($i=0;$i<$#res_s+1;$i++){
				if($fld_rf[$res_s[$i]]!=1 && $c_zokusei[$fld[$res_s[$i]]] eq $tmp2){$res_s[0]=$res_s[$i];last;}
			}
		}

		$tmp=$fld[$res_s[0]];
		if($c_zokusei[$tmp] ne $tmp2){&add_msg("null","그러나 , 카드는$c_name[$tmp]이었다! <br>$tmp3카드는 아니기 때문에 , 굳이 일어나지 않는다. ");}
		else{
			&add_msg("null","<b>$c_name[$tmp]을(를) 파괴했다! </b>");
			&go_boti($res_s[0],2);
		}
	}
	elsif($t_nm eq "데스함스타"){
		if(&akichk()){return;}
		if(&ext_chk("",1)){return;}

		$seast="0994000000001";$go_msgon=1;$go_msg="(특수 소환할 수 있는 몬스터가 덱에 없다)";
		$tmp_syorip=~s/<>g-1//;
		$jokenst='$cardno==934';$go_hit="<2";
		if(&go_card_search){return;}
		&put_field($res_s[0],1);
		&add_msg("null","햄스터가 왔다! ");
		&del_null(*deck,$s_a);&shuffle(*deck,$s_a);
	}
	&get_apdp_fld;
}

sub use_koka_a{				#유발 효과
	local($cardno) = $_[0];
	local($para) = $_[1];
	local($i,$j,@res_s,$t_nm);

	$tmp_syorip="<>c-5-$cardno<>i-$s_a<>p-$para";

	$t_nm = $c_name[$cardno];
	$go_hit=1;$jokenst="";$go_msg="";$seast="";

	if($cont_flg==1){}
	elsif($cardno==4444 || $c_koka[$cardno]==12 || $c_zokusei[$cardno] eq "마" || $c_zokusei[$cardno] eq "함정" || $cardno==1096 || $cardno==975 || $cardno==374 || $cardno==373 || $cardno==823 || $cardno==270 || $cardno==835 || $cardno==1170){}
	else{&add_msg("null","<b>$t_nm의 효과 발동! </b>");}

	if($cardno==4444){
		&fld_chk();
		if($nf1<0){&add_msg("null","(장소에 빈 곳이 없기 때문에 , 영혼으로부터의 메세지를 보낼 수 없는)");return;}
		$maxt=0;
		for($i=$fw2[$s_a];$i<$fw2[$s_a]+5;$i++){
			if($maxt<$fld[$i] && 1039<$fld[$i] && $fld[$i]<1045){$maxt=$fld[$i];}
		}
		if($maxt==0){return;}
		$maxt++;
		$seast="9999000010001";$jokenst='$cardno=='.$maxt;
		$go_msg="($c_name[$maxt]이 패에도 덱에도 없다)";
		$tmp_syorip.="<>m-죽음의 메세지 카드를 장소에 낸다. <>g-1";
		if(&go_card_search){return;}
		$fld[$nf1]=$maxt;$fld_rf[$nf1]=0;
		if($res_s[0]<100){$tehuda[$s_a][$res_s[0]-50]="";&del_null(*tehud_a);}
		else{$deck[$s_a][$res_s[0]-400]="";&del_null(*deck,$s_a);}
		&add_msg("null","<b>위쟈반이 움직이기 시작했다…! </b><br>$c_name[$maxt](을)를 지시했다. ");
		if($maxt==1044){
			&add_msg("null","<br><b>영혼과의 교신이 종료<br>보내진 메세지는…<br><br><font color=#990000 size=+2>「D」 「E」 「A」 「T」 「H」</font><br><br>$pn[$s_d]의 죽음이 확정했다! <br>");
			$lp[$s_d]=0;&end_game;
		}
		if($player[$s_a]==8){
			if($maxt==1041){&add_msg("바크라","이 턴으로 E의 문자가 떠오른다…. <br>너의 생명은 앞으로 3턴이다! ");}
			elsif($maxt==1042){&add_msg("바크라","위쟈반이 3번째 문자를 나타내군! <br>DEATH의 A의 문자를! ");}
			elsif($maxt==1043){&add_msg("바크라","위쟈반이 4문자째를 나타냈다!<br>당신에게 남겨진 것은 불과 1턴이다! ");}
		}
	}
	elsif($t_nm eq "크리터" || $t_nm eq "검은 숲의 마녀" || $t_nm eq "소닉 버드" || $t_nm eq "센쥬·갓" || $t_nm eq "바포멧트"){
		$seast="0999000000001";
		if($t_nm=~/^크/){$jokenst='$res_sap<=1500';$tmpst="공격력1500이하의 몬스터";$tmp_syorip.="<>g-1";}
		elsif($t_nm=~/^검/){$jokenst='$res_sdp<=1500';$tmpst="수비력1500이하의 몬스터";$tmp_syorip.="<>g-1";}
		elsif($t_nm =~/^소/){$seast="9999000000001";$jokenst='$c_syuzoku[$cardno] eq "의식"';$tmpst="의식 마법";}
		elsif($t_nm =~/^센/){$jokenst='$c_syokan[$cardno]==2 && $c_zokusei[$cardno] ne "함정"';$tmpst="의식 몬스터";}
		else{$jokenst='$cardno==702';$tmpst="환상수왕 가젤";}

		$go_msg="(그러나 ,$tmpst는 덱에 없었다)";$go_msgon=1;$go_hit="<2";
		$tmp_syorip.="<>m-$tmpst를 1장 패에 가세할 수가 있다! ";
		if(&go_card_search){return;}
		&cpu_get_saikyo();

		$tmp=$deck[$s_a][$res_s[0]-400];
		$deck[$s_a][$res_s[0]-400]="";
		&del_null(*deck,$s_a);
		push(@{$tehuda[$s_a]},$tmp);
		&add_msg("null","$pn[$s_a](은)는$c_name[$tmp]을 명함에 가세했다! ");
		&shuffle(*deck,$s_a);
	}
	elsif($t_nm eq "킬러·토마토" || $t_nm eq "거대 쥐" || $t_nm eq "그리즈리마자" || $t_nm eq "UFO 타톨" || $t_nm eq "드래곤 플라이" || $t_nm eq "샤인 엔젤" || $t_nm eq "자이언트 바이러스" || $t_nm eq "민첩한 하늘다람쥐" || $t_nm eq "군대용"){

		$seast="0994000000001";$go_msgon=1;$go_msg="(특수 소환할 수 있는 몬스터가 덱에 없다)";
		if($t_nm=~/^자/){
			if($cont_flg!=1){&add_msg("null","$pn[$s_d]에500의 데미지! ");$lp[$s_d]-=500;&chk_lp;}
			$jokenst='$cardno==833';$go_hit="<4";
		}
		elsif($t_nm=~/^민/){
			if($cont_flg!=1){&lp_up(1000);}
			$jokenst='$cardno==834';$go_hit="<4";
		}
		elsif($t_nm=~/^데/){
			$tmp_syorip=~s/<>g-1//;
			$jokenst='$cardno==934';$go_hit="<2";
		}
		elsif($t_nm=~/^군/){
			$tmp_syorip.="<>g-1<>o-공격 표시::수비 표시";
			$jokenst='$cardno==1147';
		}
		else{
			$go_hit="<2";$ztmp = $c_zokusei[$cardno];
			$jokenst='$res_sap<=1500 && $c_syokan[$cardno] eq "" && $c_zokusei[$cardno] eq "'.$ztmp.'"';
			$tmp_syorip.="<>m-공격력1500이하의$ztmp속성 몬스터를 특수 소환할 수 있다. ";
		}
		if(&akichk()){return;}
		if(&ext_chk("",1)){return;}
		if(&go_card_search){return;}
		
		if(&cpu_get_saikyo($seast,$jokenst,1)){return;}

		for($i=0;$i<$#res_s+1;$i++){
			if(&akichk()){return;}
			if($t_nm=~/^민/ || $t_nm=~/^데/){&put_field($res_s[$i],1);}
			else{&put_field($res_s[$i]);}
			&add_msg("null","$pn[$s_a]는 데크로부터$c_name[$fld[$nf0]]를 특수 소환! ");
		}
		&del_null(*deck,$s_a);&shuffle(*deck,$s_a);
		if($t_nm=~/^군/){$fld_ad[$nf0]=$F{'options'};}
	}

	elsif($t_nm eq "광의모퉁이" || $t_nm eq "악마의 입맞춤"){
		if($cpu[$s_a]==1 || $F{'options'} eq "1"){}
		elsif($F{'options'} eq "0"){
			&add_msg("null","$pn[$s_a]은 500의 라이프를 지불해 ,$c_name[$cardno]를 데크의 맨 위에 되돌렸다. ");
			$lp[$s_a]-=500;&chk_lp;&return_deck($cardno);
		}
		else{
			$seast="";$jokenst="";
			$tmp_syorip.="<>m-$t_nm(은)는 500의 라이프를 지불하면 , 덱의 맨 위로 돌아올거야. <>o-지불한다::지불안한다";
			&go_select_syori;
		}
	}
	elsif($t_nm eq "demon의 도끼"){
		if($cpu[$s_a]==1){return;}
		$seast="09921";$go_msg="(장에 몬스터가 없기 때문에 , demon의 도끼의 효과는 발동하지 않는다)";
		$go_hit="<2";
		$tmp_syorip.="<>m-demon의 도끼는 몬스터 1체를 제물로 바치면 , 덱의 맨 위로 돌아올거야. ";
		if(&go_card_search){return;}
		&add_msg("null","$pn[$s_a](은)는$c_name[$fld[$res_s[0]]]을 제물로 바쳐 demon의 도끼를 덱의 맨 위에 되돌렸다. ");
		&go_boti($res_s[0],4);&return_deck(797);
	}
	elsif($t_nm eq "일각수의 호른" || $t_nm eq "집념의 검"){
		&return_deck($cardno);
		&add_msg("null","($t_nm은 덱의 맨 위로 돌아온)");
	}
	elsif($t_nm eq "검은 팬던트"){
		&add_msg("null","(검은 팬던트의 저주로 ,$pn[$s_d]에500의 데미지! )");
		$lp[$s_d]-=500;&chk_lp;
	}
	elsif($t_nm eq "흰 도둑" || $t_nm eq "도적의 비법"){
		if(($rann=&rand_tehuda(1))<0){return;}
		&add_msg("null","<b>$pn[$s_d]의 명함으로부터$c_name[$tehuda[$s_d][$rann]]를 훔쳤다! </b>");
		&maryoku(17,1);&go_boti2($rann,1);
	}
	elsif($t_nm eq "로빈 고블린"){
		for($o_i=0;$o_i<$kok[$s_a][21];$o_i++){
			if(($rann=&rand_tehuda(1))<0){return;}
			&add_msg("null","<b>로빈 고블린은$pn[$s_d]의 명함으로부터$c_name[$tehuda[$s_d][$rann]]를 빼앗았다! </b>");
			&maryoku(17,1);&go_boti2($rann,1);
		}
	}
	elsif($t_nm eq "천공 기사 파시아스"){
		&add_msg("null","<b>파시아스의 효과로$pn[$s_a]는 1장 드로! </b>");
		&tehuda_draw(0,1);
	}
	elsif($t_nm eq "가면마도사"){
		&add_msg("null","<b>가면마도사의 효과로$pn[$s_a]는 1장 드로! </b>");
		&tehuda_draw(0,1);
	}
	elsif($t_nm eq "악마의 조리사"){
		&add_msg("null","<b>악마의 조리사의 효과로$pn[$s_d]는 2장 드로! </b>");
		&tehuda_draw(1,2);
	}
	elsif($t_nm eq "펭귄·나이트"){
		&add_msg("null","기사의 기의 아래 , 묘지의 카드가 다시 집결! <br>묘지의 카드를 덱에 가세해 셔플! ");
		for($i=0;$i<$#{$boti[$s_a]}+1;$i++){
			$boti[$s_a][$i]=~s/\i$//;
			if($c_syokan[$boti[$s_a][$i]]==1){push(@{$yugo[$s_a]},$boti[$s_a][$i]);}
			else{push(@{$deck[$s_a]},$boti[$s_a][$i]);}
		}
		undef(@{$boti[$s_a]});&shuffle(*deck,$s_a);
	}
	elsif($t_nm eq "리바이벌 슬라임"){
		if($F{'options'} eq "0" || $cpu[$s_a]==1){
			if($cpu[$s_a]==1 && $lp[$s_a]<2000){return;}
			&add_msg("null","1000의 라이프를 지불해 --<br><b>리바이벌 슬라임은 재생을 시작했다! </b>");
			$lp[$s_a]-=1000;&chk_lp;$hk[5+$s_a]++;
		}
		elsif($F{'options'} eq ""){
			$tmp_syorip.="<>m-리바이벌 슬라임을 재생할까요? (1000라이프 필요)<>o-네::아니오";
			$seast="";$jokenst="";&go_select_syori;return;
		}
	}
	elsif($t_nm eq "다크·네크로피아"){
		if(&akichk2()){return;}
		if(&akichk()){return;}
		$seast="901901";$go_msg="(빙의 대상이 존재하지 않는)";
		$tmp_syorip.="<>m-(빙의 대상을 선택한다)<>g-1";
		if(&go_card_search){return;}
		&cpu_get_saikyo();

		for($i=0;$i<$#{$boti[$s_a]}+1;$i++){if($boti[$s_a][$i]==1064){$boti[$s_a][$i]="";last;}}
		if($i==$#{$boti[$s_a]}+1){return;}
		&del_null(*boti,$s_a);$fld[$nf1]=1064;$fld_rf[$nf1]=0;
		&moto_chk($res_s[0]);
		&soubi($res_s[0],$nf1);
		&add_msg("null","<b>마리오네트의 영혼이$c_name[$fld[$res_s[0]]]에 빙의 했다! </b>");
		if($kok[0][8] eq ""){&ctrl_ido($res_s[0],$nf0);}
	}
	elsif($t_nm eq "물의 정령 악 에리어" || $t_nm eq "풍의 정령 가루다"){
		$seast="901901";$go_hit="<2";
		if(&go_card_search){return;}
		&add_msg("null","$c_name[$fld[$res_s[0]]]의 표시 형식을 변경했다. ");
		$fld_ad[$res_s[0]]=1-$fld_ad[$res_s[0]];
		$a_m[$res_s[0]]=2;
	}
	elsif($t_nm eq "가면마수 데스·가디우스"){
		$seast="9999000000001";$jokenst='$cardno==1094';&card_search;
		if($#res_s<0){&add_msg("null","(유언의 가면이 덱에 없다)");return;}
		$deckno=$res_s[0];
		if(&akichk()){return;}
		if(&akichk2()){return;}
		$seast="901901";$jokenst='';$tmp_syorip.="<>g-1";
		if(&go_card_search){return;}
		&put_field($deckno);&del_null(*deck,$s_a);
		&moto_chk($res_s[0]);
		&soubi($res_s[0],$nf1);
		&add_msg("null","<b>유언의 가면이$c_name[$fld[$res_s[0]]]에 장착되었다! </b>");
		if($kok[0][8] eq ""){
			if($player[$s_a]==23){&add_msg("빛의 가면","쿠크크…　보일까…<br>$c_name[$fld[$res_s[0]]]를 감싸는 가면마수의 분노와 복수심의 아우라가! ");}
			&ctrl_ido($res_s[0],$nf0);
		}
	}
	elsif($t_nm eq "아메바"){
		&add_msg("null","$pn[$s_d]에2000의 데미지! ");
		$lp[$s_d]-=2000;&chk_lp;$fld_koka[$para].="used<>";
	}
	elsif($t_nm eq "그리굴"){
		&lp_up(3000);$fld_koka[$para].="used<>";
	}
	elsif($t_nm eq "절대 방어 장군"){
		&add_msg("null","장군은 절대 방어 태세에 들어갔다. ");
		$fld_ad[$para]=1;
	}
	elsif($t_nm eq "룡살자"){
		$seast="901911";if($cpu[$s_a]==1){$seast="991901";}
		$jokenst='&syu_st($res_si) eq "드래곤"';
		if(&go_card_search){return;}

		&add_msg("null","<b>룡살자는$c_name[$fld[$res_s[0]]]을 죽였다! </b>");
		&go_boti($res_s[0],5);
	}
	elsif($t_nm eq "머더 서커스"){
		$seast="991901";$jokenst='';
		if(&go_card_search){return;}
		&add_msg("null","$c_name[$fld[$res_s[0]]]를 패에 되돌렸다! ");
		&return_tehuda($res_s[0]);
	}
	elsif($t_nm eq "드림 삐에로"){
		$seast="991901";$jokenst='';
		if(&go_card_search){return;}
		&add_msg("null","<b>$c_name[$fld[$res_s[0]]]를 파괴했다! </b>");
		&go_boti($res_s[0],5);
	}
	elsif($t_nm eq "암흑마족 기르파·demon"){
		if(&akichk2()){return;}
		$seast="901911";$tmp_syorip.="<>m-(장비 대상을 선택한다)";$go_hit="<2";
		if(&go_card_search){return;}
		for($i=0;$i<$#{$boti[$s_a]}+1;$i++){if($boti[$s_a][$i]==973){$boti[$s_a][$i]="";last;}}
		if($i==$#{$boti[$s_a]}+1){return;}
		&del_null(*boti,$s_a);
		if(&cpu_get_saikyo("901901",'$cardno!=913')){return;}
		$fld[$nf1]=973;$fld_rf[$nf1]=0;
		&soubi($res_s[0],$nf1,"_gilfer");
		&add_msg("null","상대 몬스터의 공격력을 500내렸다! ");
	}
	elsif($t_nm eq "승복의 대현자"){
		$seast="2999000000001";$tmp_syorip.="<>m-(마법 카드를 패에 가세한다)<>g-1";
		if(&go_card_search){return;}
		$cno=$deck[$s_a][$res_s[0]-400];$deck[$s_a][$res_s[0]-400]="";&del_null(*deck,$s_a);
		push(@{$tehuda[$s_a]},$cno);
		&add_msg("null","$c_name[$cno]을 명함에 가세했다! ");
	}
	elsif($t_nm eq "유익환수 키마이라"){
		if(&akichk()){return;}
		$seast="09990000001";$jokenst='$cardno==926 || $cardno==702';
		$tmp_syorip.="<>o-공격 표시::수비 표시";
		if(&go_card_search){return;}

		&put_field($res_s[0]);
		if($F{'options'}==1){$fld_ad[$nf0]=1;}
		&add_msg("null","키마이라는 분리해$c_name[$fld[$nf0]]가 되었다. ");
		$boti[$s_a][$res_s[0]-200]="";&del_null(*boti,$s_a);&hosatu(0);
	}
	elsif($t_nm eq "것 흉내내고 환상사"){
		$seast="901901";$tmp_syorip.="<>g-1";
		if(&go_card_search){return;}
		if($cpu[$s_a]==1){@res_s2 = sort {$c_ap[$fld[$b]] cmp $c_ap[$fld[$a]]} @res_s;$res_s[0]=$res_s2[0];}

		$cno=$fld[$res_s[0]];
		&add_msg("null","<b>「도·의·마·네!」</b><br>$c_name[$cno]도 가 흉내냈다! ");
		$fld_koka[$para].="rar_".$c_ap[$cno]."-".$c_dp[$cno]."<>";
	}
	elsif($t_nm eq "유언장"){
		if(&akichk()){return;}
		if(&ext_chk()){return;}
		$seast="0994000000001";$jokenst='$res_sap<=1500';
		$tmp_syorip.="<>g-1<>o-공격 표시::수비 표시";
		if(&go_card_search){return;}
		&cpu_get_saikyo();
		&put_field($res_s[0]);
		&add_msg("null","<b>$c_name[$jok[2]]의 유언! </b><br>$c_name[$fld[$nf0]]을(를) 소환했다! ");
		&del_null(*deck,$s_a);&shuffle(*deck,$s_a);
		if($F{'options'}==1){$fld_ad[$nf0]=1;}
	}
	elsif($t_nm eq "령멸술사 카이크우"){
		if($cont_flg!=1){&add_msg("null","<b>카이크우의 효과 발동! </b>");}
		$seast="099300000001";$go_hit="<3";
		if(&go_card_search){return;}
		for($i=0;$i<$#res_s+1 && $i<2;$i++){
			&add_msg("null","$c_name[$boti[$s_d][$res_s[$i]-300]](을)를 없앴다! ");
			$boti[$s_d][$res_s[$i]-300]="";
		}
		&del_null(*boti,$s_d);
	}
	elsif($t_nm eq "8오 큰뱀"){
		&add_msg("null","<b>$pn[$s_a]은 패가 5장이 될 때까지 드로! </b>");
		$tmp=5-($#{$tehuda[$s_a]}+1);
		if($tmp>0){&tehuda_draw(0,$tmp);}
	}
	elsif($t_nm eq "화지가구토"){
		&add_msg("null","$pn[$s_d]의 명함에 불씨를 넣었다! ");
		$hk[14+$s_d]=1;
	}
	elsif($t_nm eq "8태오"){
		&add_msg("null","<b>$pn[$s_d]의 드로페이즈를 봉했다! </b>");
		$hk[10+$s_d]=1;
	}
	elsif($t_nm eq "위대 텐구"){
		&add_msg("null","<b>$pn[$s_d]의 다음의 배틀페이즈를 봉했다! </b>");
		$hk[16+$s_d]=1;
	}
	elsif($t_nm eq "불사지염조"){
		&add_msg("null","<b>불사지염조의 효과 발동! </b>");
		&lp_up($para);
	}
	elsif($t_nm eq "령자 에너지 고정 장치"){
		if($F{'options'}!=1){
			$seast="999900001";
			$tmp_syorip.="<>m-고정 장치를 유지할가요? <>o-한다(패 버림)::하지않는다<>g-1<>l-1";
			$kekka=&go_card_search;
			if($kekka==2){return;}
		}
		if($kekka==1 || $F{'options'}==1 || $cpu[$s_a]==1){
			if($para eq ""){$para=$S{'p'};}
			&add_msg("null","고정 장치를 파괴했다. ");&go_boti($para);
		}
		else{
			&add_msg("null","$c_name[$tehuda[$s_a][$res_s[0]-50]]을(를) 버려 고정 장치를 유지했다. ");
			&go_boti2($res_s[0]-50);
		}
	}
	elsif($t_nm eq "절삭 깊이 대장"){
		if(&akichk()){return;}
		if(&ext_chk("",1)){return;}
		$seast="099400001";$go_msgon=1;
		$go_hit="<2";$jokenst='&lv_st($cardno)<=4 && ($c_syokan[$cardno] eq "" || $c_syokan[$cardno]==6)';
		$tmp_syorip.="<>o-공격 표시::수비 표시";
		if(&go_card_search){return;}

		&cpu_get_saikyo($seast,$jokenst,1);
		&put_field($res_s[$i]);
		if($F{'options'}==1){$fld_ad[$nf0]=1;}
		&add_msg("null","$c_name[$fld[$nf0]]는 대장의 뒤에 계속되었다! ");
	}
	elsif($t_nm eq "처형인 마큐라"){
		&add_msg("마큐라","<b>오오오오</b>");
		if($player[$s_a]==21 && $srfchk eq ""){&add_msg("마리크","기분이 좋아…<br>적이 함정에 걸린 순간은…　하하! ");$srfchk=1;}
		&add_msg("null","이 턴 명함으로부터 함정 카드를 발동할 수 있다! ");
		$hk[19+$s_a]=1;
	}
	elsif($t_nm eq "기르포드·더·라이트닝"){
		&add_msg("null","전설의 기사는 검을 지었다!");
		&add_msg("기르포드","<b>라이트닝·번개! </b>");
		&add_msg("null","번개가 달린다!　상대의 몬스터는 전멸! ");
		for($u_i=$fw1[$s_d];$u_i<$fw1[$s_d]+5;$u_i++){&go_boti($u_i);}
	}
	elsif($t_nm eq "아마조네스의 쇠사슬 사용"){
		if(&maisu_count(7)==0){$F{'options'}=1;}
		if($F{'options'} eq "0" || $cpu[$s_a]==1){
			if($cpu[$s_a]==1 && $lp[$s_a]<2500){return;}
			&add_msg("null","1500의 라이프를 지불해 --<br><b>임종의 쇠사슬 춤! </b>");
			$lp[$s_a]-=1500;&chk_lp;
			$seast="0999000001";$tmp_syorip="<>i-$s_a<>n-kusarimai";
			&go_select_syori;
		}
		elsif($F{'options'} eq ""){
			$tmp_syorip.="<>m-쇠사슬 사용의 효과를 사용할까요? (1500라이프 필요)<>o-네::아니오";
			$seast="";$jokenst="";&go_select_syori;return;
		}
	}
	elsif($t_nm eq "달러·드라"){$hk[21+$s_a]++;}
	elsif($t_nm eq "나가"){
		if(&ext_chk()){return;}
		if(&akichk()){return;}
		$seast="0994000000001";$jokenst='$c_lv[$cardno]<4';
		$tmp_syorip.="<>g-1<>o-공격 표시::수비 표시";
		if(&go_card_search){return;}
		&put_field($res_s[0]);&del_null(*deck,$s_a);&shuffle(*deck,$s_a);
		&add_msg("null","덱으로부터$c_name[$fld[$nf0]]를 특수 소환! ");
		$fld_ad[$nf0]=$F{'options'};
	}
	elsif($t_nm eq "쇠사슬 부착 폭탄"){
		if($kok[0][7] ne ""){return;}
		if($cont_flg!=1){&add_msg("null","<b>쇠사슬 부착 폭탄이 폭발! </b>");}
		$seast="99191111";$tmp_syorip.="<>g-1";
		if($cpu[$s_a]==1){$seast="99190101";&card_search;if($#res_s<0){$seast="99191111";}}
		if(&go_card_search){return;}
		&add_msg("null","<b>$c_name[$fld[$res_s[0]]]은(는) 날아갔다! </b>");
		&which_side($res_s[0]);
		if($which_area==1){&go_boti($res_s[0],5);}
		else{&go_boti($res_s[0],2);}
	}
	elsif($t_nm eq "도둑의 연옥"){
		if($kok[0][8] ne ""){return;}
		&add_msg("null","<b>연옥이 폭발! </b><br>이 틈에 상대의 패를 훔칠 수 있다! ");
		$seast="9999000001";$tmp_syorip="<>i-$s_a<>n-ousyu<>g-1<>p-1192";
		&go_select_syori;
	}
	elsif($t_nm eq "불길한 점"){
		if($F{'options'} eq "" && $cpu[$s_a]!=1){
			$tmp_syorip.="<>o-몬스터::마법::함정<>m-인 ~응이다? <>g-1";
			&go_select_syori;return;
		}

		if($cpu[$s_a]==1){$rann=rand;$F{'options'}=int($rann*3);}
		if(($ti=&rand_tehuda(1))<0){return;}
		$tmp=$c_zokusei[$tehuda[$s_d][$ti]];
		if($F{'options'}==1){$tmp2="마법";if($tmp eq "마"){$tmp=1;}}
		elsif($F{'options'}==2){$tmp2="함정";if($tmp eq "함정"){$tmp=1;}}
		else{$tmp2="몬스터";if($tmp ne "마" && $tmp ne "함정"){$tmp=1;}}

		&add_msg($pn[$s_a],"$tmp2! ");
		&add_msg("null","카드는$c_name[$tehuda[$s_d][$ti]]이었다! ");
		if($tmp!=1){&add_msg("null","변두리…");}
		else{&add_msg("null","정답!　$pn[$s_d]에700의 데미지! ");$lp[$s_d]-=700;&chk_lp;}
	}
	elsif($t_nm eq "바이스 악마 바이서·데스"){
		$seast="991901";$jokenst='';$tmp_syorip.="<>g-1";
		if(&go_card_search){return;}
		&add_msg("null","바이스가 적의 머리에 장착되었다! ");
		$ko_no=&get_ko_no($fld_koka[$para]);
		$ko_no2=&get_ko_no($fld_koka[$res_s[0]]);
		$fld_koka[$res_s[0]].="f_".$para."::".$ko_no."<>";
		$fld_koka[$para].="f_".$res_s[0]."::".$ko_no."_$turn<>";
		if($player[$s_a]==21){&add_msg("마리크","바이스가 천천히 머리를 단단히 조를거야…<br>쑥쑥 키리…　3턴 걸쳐 머리를 파괴해 주는…");}
	}
	elsif($t_nm eq "뱀파이어·로드"){
		if($F{'options'} eq "" && $cpu[$s_a]!=1){
			$tmp_syorip.="<>o-몬스터::마법::함정<>m-어떤 것을 흡혈할까요? <>g-1";
			&go_select_syori;return;
		}
		if($cpu[$s_a]==1){$rann=rand;$F{'options'}=int($rann*3);}
		if($F{'options'}==1){$tmp2="마법";$tmp=2;}
		elsif($F{'options'}==2){$tmp2="함정";$tmp=3;}
		else{$tmp2="몬스터";$tmp=0;}
		$seast=$tmp."999000000001";$tmp_syorip="<>n-vamp<>i-$s_d<>g-1";
		&add_msg("null","<b>$pn[$s_d]의 덱으로부터$tmp2를 흡혈 한다! </b>");
		&go_select_syori;
	}
	elsif($t_nm eq "용궁유키공주"){
		$seast="901901";$jokenst='';$go_hit="<2";
		if(&go_card_search){return;}
		&add_msg("null","춤으로$c_name[$fld[$res_s[0]]]의 형식을 바꾸었다! ");
		$fld_ad[$res_s[0]]=1-$fld_ad[$res_s[0]];&piero($res_s[0]);
	}
	elsif($t_nm eq "마파라위"){
		&add_msg("null","차의 드로페이즈에 덱의 맨 위를 볼 수가 있다! ");
		$hk[25+$s_a]=1;
	}
	elsif($t_nm eq "스피릿의 권유"){
		$seast="99191";$jokenst='';$tmp_syorip.="<>g-1";
		if(&go_card_search){return;}
		&cpu_get_saikyo("","","",1);
		&return_tehuda2($res_s[0]);
	}
	elsif($t_nm eq "트·월드"){
		&add_msg("null","<b>트 소멸! </b>");
		for($i=5;$i<5*3;$i++){if($c_syokan[$fld[$i]]==4){&go_boti($i);}}
	}
	elsif($t_nm eq "위쟈반" || $t_nm=~/^죽음의 메세지/){
		if($wija_suteta){return;}
		$wija_suteta=1;
		for($i=$fw2[$s_a];$i<$fw2[$s_a]+5;$i++){if(1040<=$fld[$i] && $fld[$i]<=1044){&go_boti($i);}}
		&add_msg("null","영혼과의 교신은 끊어진…");
	}
	elsif($t_nm eq "왕가의 신전"){
		&find_koka;if($kok[$tsno][54] ne ""){return;}
		for($i=$fw1[$s_a];$i<$fw1[$s_a]+5;$i++){
			if($fld[$i]==1219 && $fld_rf[$i]!=1){
				&add_msg("null","셀 케토는 신전과 함께 사라졌다. ");
				&go_boti($i);
			}
		}
	}
	elsif($t_nm eq "바다" || $t_nm eq "전설의 수도 아트란티스"){
		&find_koka;if($kok[0][59] ne ""){return;}
		for($i=0;$i<20;$i++){
			if($i==5){$i=15;}
			if($fld[$i]==999 && $fld_rf[$i]!=1){&go_boti($i);}
		}
	}
	elsif($t_nm eq "이비"){
		&add_msg("null","$pn[$s_d]에1000의 데미지! ");
		$lp[$s_d]-=1000;&chk_lp;
	}
	elsif($t_nm eq "일렉트릭·뱀"){
		&add_msg("null","$pn[$s_a]은 2장 드로! ");
		&tehuda_draw(0,2);
	}
	elsif($t_nm eq "머슈맨"){
		if(&akichk(1)){return;}
		if($F{'options'} eq "" && $cpu[$s_a]!=1){
			push(@syori,"2<>o-보냄::안보냄<>m-머슈맨을 상대에게 보내버릴까요? ".$tmp_syorip);
		}
		elsif($F{'options'}==0){
			&add_msg("null","500의 라이프를 지불해 , 머슈맨을 보내버렸다! ");
			$lp[$s_a]-=500;&chk_lp;
			&moto_chk($para);$fld_koka[$para].="teni_$s_d<>";&ctrl_ido($para,$nf0);
		}
	}
	elsif($t_nm eq "번개 신선"){
		if($para!~/used/){return;}
		&add_msg("null","<b>낙뢰! </b>　$pn[$s_a]에5000의 데미지! ");
		$lp[$s_a]-=5000;&chk_lp;
	}
	elsif($t_nm eq "다크 패밀리어"){
		if($para!~/used/){return;}
		&add_msg("null","영혼의 소를 가져 묘지에 갔다! <br>몬스터를 소생 할 수 있다. ");
		$seast="09950000001";$jokenst='$irrflg!=1 && $cardno!=1106 && $cardno!=835';
		$tmp_syorip0="<>n-hakaana<>o-공격 표시::뒤 수비 표시<>p-2<>g-1<>i-";
		$tmp_syorip=$tmp_syorip0.$s_d;&go_select_syori;
		$tmp_syorip=$tmp_syorip0.$s_a;&go_select_syori;
	}
	elsif($t_nm eq "박행의 미소녀"){
		&add_msg("null","$pn[$s_d]는 죄악감으로 공격을 그만두었다. ");
		if($jok[1] ne ""){&bphase_end;}$phase=4;
	}
	elsif($t_nm eq "타임·보마"){
		if(&ikenie_chk){return;}
		if($fld[$para]!=823){return;}
		if($F{'options'} eq "" && $cpu[$s_a]!=1){
			push(@syori,"2<>o-시키는::시키지 않는<>m-타임·보마를 폭발시켜? ".$tmp_syorip);
		}
		elsif($F{'options'}==0){
			if($player[$s_a]==5){&add_msg("페가수스","늦었다~!　이 순간 타임·보마는 자폭한다! ");}
			&add_msg("null","<b>타임·보마 폭발! </b>");
			&go_boti($para,4);
			$tmp=0;
			for($i=$fw1[$s_a];$i<$fw1[$s_a]+5;$i++){if($fld[$i] ne ""){$tmp+=$ap_fld[$i];&go_boti($i);}}
			$tmp=int($tmp/2);
			&add_msg("null","아군 모두를 파괴해 ,$pn[$s_d]에$tmp의 데미지! ");
			$lp[$s_d]-=$tmp;&chk_lp;
		}
	}
	elsif($t_nm eq "미스터·본 바"){
		if($F{'options'}==1){return;}
		if(&ikenie_chk){return;}
		if($fld[$para]!=270){return;}
		$seast="991911";$jokenst='($fld_rf[$res_si]==1 || $ap_fld[$res_si]<=1000) && $res_si!='.$para;$go_hit=2;
		$go_msg="(미스터·본 바는 대상 이루어)";
		$tmp_syorip.="<>o-던짐::안던짐<>m-폭탄을 던질까요? <br>(던지는 경우는 대상도 선택)";
		if(&go_card_search){return;}
		&go_boti($para,4);
		&add_msg("null","미스터·본 바는 양손의 폭탄을 던졌다! ");
		for($i=0;$i<2;$i++){
			if($ap_fld[$res_s[$i]]>1000){&add_msg("null","$c_name[$fld[$res_s[$i]]](은)는 공격력이1000보다 크다. ");}
			else{&add_msg("null","$c_name[$fld[$res_s[$i]]](을)를 파괴! ");&go_boti($res_s[$i],5);}
		}
	}
	elsif($t_nm eq "가고일의 어릿광대"){
		$seast="901911";$tmp_syorip.="<>g-1";
		if(&go_card_search){return;}
		&add_msg("null","$c_name[$fld[$res_s[0]]]의 표시 형식을 바꾸었다! ");
		$fld_ad[$res_s[0]]=1-$fld_ad[$res_s[0]];&piero($res_s[0]);
	}
	elsif($t_nm eq "7개의 무기를 가지는 헌터"){
		if($fld[$para]!=$cardno){return;}
		if($cont_flg!=1){
			if($cpu[$s_a]==1){$F{'options'}=6;}
			elsif($F{'options'} eq ""){$seast="";$tmp_syorip.="<>o-dna<>g-1";&go_select_syori;return;}
		}
		&add_msg("null","$syu_arr[$F{'options'}]족용의 무기를 준비했다! ");
		$fld_koka[$para].="hunter_$F{'options'}<>";
	}
	elsif($t_nm eq "이성의 최종전사"){
		$tsno=$sno[&which_side($para)];
		&add_msg("null","최종전사가 나타났을 때 , 아군은 전멸! ");
		for($i=$fw1[$tsno];$i<$fw1[$tsno]+5;$i++){if($i!=$para){&go_boti($i);}}
	}
	elsif($t_nm eq "옵션"){
		if($fld[$para]!=$cardno){return;}
		$seast="90191";$jokenst='$cardno==945';$tmp_syorip.="<>g-1";$go_msg="빅크바이파가 없다. ";
		if(($kekka=&go_card_search)==2){return 1;}
		if($kekka==1){&go_boti($para);return;}
		&add_msg("null","빅크바이파는 파워 캅셀을 취했다! <br>옵션 장착! ");
		&soubi($res_s[0],$para);
	}
	elsif($t_nm eq "라스트 배틀! "){
		@b_fld=split(/-/,$para);
		$hk[34]=1;&battle_run;
	}
	elsif($t_nm eq "편승"){
		$cou=2*$para;
		&add_msg("null","<b>편승! </b>　$pn[$s_a](은)는$cou장 드로! ");
		&tehuda_draw(0,$cou);
	}
	elsif($t_nm eq "강제 접수"){
		if(&maisu_count(7)<1){return;}
		&add_msg("null","<b>강제 접수! </b>　$pn[$s_d](은)는$para장 버린다! ");
		$seast="999900001";
		$tmp_syorip="<>n-t_sute<>g-1<>i-$s_d<>p-".$para."a";&go_select_syori;
	}

	&get_apdp_fld;
}

sub maryoku{
	local($kokano)=$_[0];
	local($l_side)=$_[1];
	local($maisu)=$_[2];
	local($tmp,$tsno);
	$tsno=$sno[$l_side];
	$tsno2=$sno[1-$l_side];

	if($kokano!=17){$kok[$tsno2][$kokano]=$kok[0][$kokano];}
	if($kok[$tsno2][$kokano] eq ""){return;}

	if($kokano==16){$cnotmp="마력의 항쇄";$damp=500;}
	elsif($kokano==17){$cnotmp="마력의 가시나무";$damp=500;}
	elsif($kokano==19){$cnotmp="사령의 권유";$damp=300;}
	elsif($kokano==56){$cnotmp="죽음의 연산";$damp=500;}

	if($maisu eq ""){$maisu=1;}

	$tmp=$kok[$tsno2][$kokano]*$damp*$maisu;$tmpn=$pn[$tsno];$lp[$tsno]-=$tmp;
	&add_msg("null","<b>$cnotmp! </b>　$tmpn에$tmp의 데미지! ");
	&chk_lp;
}

sub binjo_chk{
	local($l_side)=$_[0];
	local($mode)=$_[1];
	local($i,$tsno);
	if($kok[0][7] ne "" || $chain[0] ne "" || $binchkflg==1){return;}

	$tsno=$sno[$l_side];
	if($mode==0){$bcno=885;}else{$bcno=886;}

	for($i=$fw2[$tsno];$i<$fw2[$tsno]+5;$i++){
		if($fld[$i]==$bcno && $fld_rf[$i]==1 && ($a_m[$i]!=1 || $kok[$tsno][54] ne "")){last;}
	}
	if($i==$fw2[$tsno]+5){return;}
	push(@chain2,"$tsno-6-f_$i");$binchkflg=1;
}

sub hosatu{
	local($l_side)=$_[0];
	local($i,$tsno);
	$tsno=$sno[$l_side];

	for($i=0;$i<$kok[$tsno][24];$i++){
		&add_msg("null","<b>생환의 보찰! </b>　$pn[$tsno](은)는 1장 드로! ");
		&tehuda_draw($l_side,1);
	}
}

sub piero{
	local($fldno)=$_[0];
	if($fld[$fldno]!=626 && $fld[$fldno]!=628){return;}

	$tsno=$sno[&which_side($fldno,1)];
	if($fld[$fldno]==626 && $fld_ad[$fldno]!=1){push(@chain2,"$tsno-5-626-");}
	elsif($fld[$fldno]==628 && $fld_ad[$fldno]==1){push(@chain2,"$tsno-5-628-");}
}

sub maiso{
	local($para)=$_[0];
	local($mode)=$_[1];
	local($fldno);

	if($para!~/f_(\d+):/ || $fld[$1] eq ""){return;}
	$fldno=$1;
	if($mode!=1){
		if($kok[0][8] ne "" || $fld[$fldno]==1121){return;}
		&add_msg("null","$c_name[$fld[$fldno]]은(는) 다시 매장되었다! ");
	}
	else{
		if($kok[0][7] ne "" || $fld[$fldno]==1139){return;}
		&add_msg("null","$c_name[$fld[$fldno]]은(는) 다시 묘지에 질질 끌어 들여졌다…!");
	}
	&go_boti($fldno,5,"",2);
}

1;
