sub use_trap{
	local($taisyo_fld,$i);

	if($t_nm eq ""){}
	elsif($t_nm eq "라스트 배틀! "){
		if($s_a==$turn2){&add_msg("null","!$s_a(상대 턴 밖에 사용할 수 없다)");return;}
		if($lp[$s_a]>1000){&add_msg("null","!$s_a(라이프가1000이하가 아니다)");return;}
		$seast="99191";
		if(&go_card_search==2){return;}
		&cpu_get_saikyo();
		if($cont_flg!=1){&add_msg("null","<b>「일대일 대결을 신청한다!」</b><br>$pn[$s_a]은(는) 마지막 승부에 걸었다! ");}
		if(&used){return;}
		if($res_s[0] ne ""){if($fld_rf[$res_s[0]]!=1){&add_msg("null","$pn[$s_a]의 대표는 --<b>$c_name[$fld[$res_s[0]]]! </b>");}}
		else{$res_s[0]=99;}
		for($i=0;$i<22;$i++){if($i!=$res_s[0]){&go_boti($i,3);}}
		for($i=0;$i<$#{$tehuda[$s_a]}+1;$i++){&go_boti2($i);}
		for($i=0;$i<$#{$tehuda[$s_d]}+1;$i++){&go_boti2($i,1);}
		$hk[34]=1;
		$seast="0994000000001";$tmp_syorip="<>n-lb<>g-1<>i-$s_d<>p-$res_s[0]";
		&go_select_syori;
		if($chain[0]=~/^[12]-11/){$chain[0]="";$phase=5;}
	}
	elsif($t_nm eq "드래곤의 보석"){
		if($cont_flg!=1){
			$seast="999900001";$go_msg="(패가 존재하지 않는다)";
			if(&go_card_search){return;}
			&cpu_sutehuda;
			&add_msg($pn[$s_a],"$c_name[$tehuda[$s_a][$res_s[0]-50]]을 버리고 --");
			$in_proc=1;&go_boti2($res_s[0]-50);$in_proc="";&maryoku(17);undef(@res_s);
		}
		if(&used){return;}
		&add_msg("null","보석의 힘이 드래곤을 함정으로부터 지켰다! ");
		$chain[0]=~s/^([12])-10-\d+-(\d+).*/$1/;
		&go_boti($2);
	}
	elsif($t_nm eq "수호영혼의 부적"){
		$seast="09990000001";&card_search;$sgcou=$#res_s+1;
		$seast="991611";
		if(&go_card_search){return;}
		if(&used){return;}
		$sgcou*=100;
		&add_msg("null","묘지의 몬스터가 수호영혼이 되었다!　$c_name[$fld[$res_s[0]]](은)는 공격력$sgcou업! ");
		$fld_koka[$res_s[0]].="ptr:$sgcou:0:$turn<>";
	}
	elsif($t_nm eq "영혼 분쇄"){
		for($i=$fw1[$s_a];$i<$fw1[$s_a]+5;$i++){if($c_syuzoku[$fld[$i]] eq "악마"){last;}}
		if($i==$fw1[$s_a]+5){&add_msg("null","!$s_a(필드에 악마족이 없으면 사용할 수 없다)");return;}
		$seast="09930000001";&card_search;$cou0=$#res_s;
		$seast="099300000001";&card_search;$cou1=$#res_s;
		if($cou0<0 || $cou1<0){&add_msg("null","!$s_a(어느 쪽의 묘지에 몬스터가 없다)");return;}
		if($cont_flg!=1){&add_msg("null","라이프를500지불해 --");$lp[$s_a]-=500;&chk_lp;}
		if(&used){return;}
		$seast="099300000001";
		$tmp_syorip="<>n-soul<>g-1<>i-$s_a";&go_select_syori;
		$tmp_syorip="<>n-soul<>g-1<>i-$s_d";&go_select_syori;
	}
	elsif($t_nm eq "그리폰의 날개"){
		if(&used){return;}
		&add_msg("null","날개는 날개의 전에 싹 지워진다! <br><b>$pn[$s_d]의 마법·함정 카드가 소산! </b>");
		for($u_i=$fw2[$s_d];$u_i<$fw2[$s_d]+5;$u_i++){
			if(&nisewana_chk($u_i)){&go_boti($u_i,2);}
		}
		&go_boti($fside[$s_d],2);
		$chain[0]=~s/^([12])-.*/$1-/;
	}
	elsif($t_nm eq "피뢰침" || $t_nm eq "화이트·홀"){
		if(&used){return;}
		if($t_nm=~/^피/){&add_msg("null","전격은 지면을 통해서 상대로 되돌아온다! <br><b>$pn[$s_d]의 장소의 몬스터는 전멸! </b>");}
		else{&add_msg("null","블랙 홀에 출구가 열렸다! <br><b>$pn[$s_a]의 몬스터만 살아났다! </b>");}
		for($u_i=$fw1[$s_d];$u_i<$fw1[$s_d]+5;$u_i++){&go_boti($u_i);}
		$chain[0]=~s/^([12])-\d+-\d+-(\d+).+/$1-/;
		&go_boti($2);
	}
	elsif($t_nm eq "지원군" || $t_nm eq "성벽" || $t_nm eq "독사의 아"){
		$seast="991611";
		if(&go_card_search){return;}
		if(&used){return;}
		$tmp=$c_name[$fld[$res_s[0]]];
		if($t_nm=~/^지/){&add_msg("null","지원군이 왔다!　$tmp(은)는 공격력500업! ");$fld_koka[$res_s[0]].="ptr:500:0:$turn<>";}
		elsif($t_nm=~/^성/){&add_msg("null","$tmp은 성벽에 둘러싸였다!　수비력500업! ");$fld_koka[$res_s[0]].="ptr:0:500:$turn<>";}
		else{&add_msg("null","$tmp(은)는 독사에 물렸다!　수비력500다운! ");$fld_koka[$res_s[0]].="ptr:0:-500:$turn<>";}
	}
	elsif($t_nm eq "왕궁의 탄압"){
		if(&used){return;}
		&add_msg("null","양플레이어는 특수 소환을 탄압할 수 있다! ");
		if($chain[0]=~/$s_d-[567]-(\d+)/){push(@syori,"2<>i-$s_a<>n-danatu<>o-한다::안한다<>m-$c_name[$fld[$1]]을 탄압할까요? <>p-$1");}
	}
	elsif($t_nm eq "버블·크래쉬"){
		$cou_a=&maisu_count(0)+&maisu_count(2)+&maisu_count(6);
		$cou_d=&maisu_count(1)+&maisu_count(3)+&maisu_count(7);
		if($cou_a<6 && $cou_d<6){&add_msg("null","!$s_a(양쪽 모두 6장 이상의 카드가 없다)");return;}
		if(&used){return;}
		&add_msg("null","버블 붕괴!　카드 자산은 5장까지 감소! ");
		$seast="999910101";$tmp="<>n-bubble<>g-1<>i-";
		if($cou_a>5){$tmp_syorip.=$tmp.$s_a;&go_select_syori;}
		if($cou_d>5){$tmp_syorip.=$tmp.$s_d;&go_select_syori;}
	}
	elsif($t_nm eq "쇠사슬 부착 폭탄"){
		$seast="90191";
		if(&go_card_search){return;}
		if(&used){return;}
		&add_msg("null","공격력 500업! <br>파괴되었을 때 폭발한다! ");
		&soubi($res_s[0],$use_f_no);
	}
	elsif($t_nm eq "데빌·코메디언"){
		if(&cointos){return;}
		if(&used){return;}

		if(&cointos2){
			&add_msg("문희준","김종서씨와 한국의 락을 이끌어 가겠습니다.");
			&add_msg("카이바","와하하하하! ");
			&add_msg("null","성공!　$pn[$s_d]의 묘지의 카드는 웃어 승천! ");
			undef(@{$boti[$s_d]});
		}
		else{
			$tmp=$#{$boti[$s_d]}+1;
			&add_msg("문희준","립싱크도 기술이에요.");
			&add_msg("조이","아씹 벌래주제에 - - ");
			&add_msg("null","실패!　$pn[$s_a]의 덱으로부터$tmp장 묘지에! ");
			&deck_to_boti(0,$tmp);
		}
	}
	elsif($t_nm eq "burst 호흡"){
		if(&ikenie_chk){return;}
		$seast="99991";$jokenst='&syu_st($res_si) eq "드래곤"';
		if(&go_card_search){return;}
		if(&used){return;}
		$cou=$ap_fld[$res_s[0]];
		&add_msg("null","$c_name[$fld[$res_s[0]]]은 생명과 교환에 불의 호흡을 토했다! <br>수비력$cou이하의 몬스터는 구워 다하여진다! ");
		&go_boti($res_s[0],4);
		for($i=5;$i<15;$i++){
			if($fld[$i] eq "" || $fld_rf[$i]==1 || $dp_fld[$i]>$cou){next;}
			&add_msg("null","<b>$c_name[$fld[$i]]을(를) 파괴! </b>");
			&go_boti($i);
		}
	}
	elsif($t_nm eq "무덤 털기"){
		$seast="299900000001";
		if(&go_card_search){return;}
		if(&used){return;}
		$tcno=$boti[$s_d][$res_s[0]-300];
		$boti[$s_d][$res_s[0]-300]="";&del_null(*boti,$s_d);
		if($player[$s_a]==3 && $player[$s_d]==14){&add_msg("조이","켁<br>도둑질의 팔자리 승리라고 하는 사원이지만…");}
		&add_msg("null","$pn[$s_d]의 묘지로부터$c_name[$tcno]를 훔쳤다! ");
		push(@{$tehuda[$s_a]},$tcno);$tep[$s_a][$#{$tehuda[$s_a]}]="h";
	}
	elsif($t_nm eq "마법 제거 세균병기"){
		if($cont_flg!=1){
			$seast="99921";$go_hit="<9";$jokenst='$c_syokan[$cardno]!=5';
			if($cpu[$s_a]==1){$jokenst.=' && $ap_fld[$res_si]<=1000';}
			if(&go_card_search){return;}
			$tmpst="";
			for($i=0;$i<$#res_s+1;$i++){$tmpst.="$c_name[$fld[$res_s[$i]]]와";&go_boti($res_s[$i],4);}
			$F{'options'}=$i;$tmpst=~s/와$//;
			&add_msg("null","$tmpst를 생지에 --");
			undef(@res_s);
		}
		if(&used){return;}
		if($player[$s_a]==2){&add_msg("카이바","와하하하하하<br>카드의 살륙 병기야 --놈의 마법 카드를 묘지에 보내라! ");}
		$seast="29990000000001";$jokenst="";&card_search;
		if($#res_s<0){&add_msg("null","(그러나 , 상대의 덱에 마법 카드는 없었다)");return;}
		$cou=$F{'options'};
		if($#res_s+1<$cou){$cou=$#res_s+1;}
		$seast="2999000000001";$tmp_syorip="<>n-saikinheiki<>i-$s_d<>p-$cou<>g-1<>(카드를$cou장 선택해 줘)";
		&go_select_syori;
		if($#res_s+1==$cou){
			undef(%F);
			for($i=0;$i<$#res_s+1;$i++){$tmp=$res_s[$i]-100;$F{'select_'.$tmp}=1;}
			$F{'run_select'}=1;
		}
	}
	elsif($t_nm eq "현세와 명계의 역전"){
		$tmp=$#{$boti[$s_a]}+1;
		if($tmp<15){&add_msg("null","!$s_a(묘지에 카드가$tmp매 밖에 없다)");return;}
		if($cont_flg!=1){
			if($player[$s_a]==22){&add_msg("이시즈","함정에 떨어진 것은 당신인 것입니다…<br>무덤 방비의 함정에…! ");}
			&add_msg("null","라이프를1000지불해 --");$lp[$s_a]-=1000;&chk_lp;
		}
		if(&used){return;}
		&add_msg("null","묘지에 자고 있던 카드가 산찰이 되어 --<br>산찰인 카드는 모두 묘지에 잔다…! ");
		for($j=1;$j<3;$j++){
			undef(@tmp_s);
			for($i=0;$i<$#{$deck[$j]}+1;$i++){
				if($c_syokan[$deck[$j][$i]] ne "" && $c_syokan[$deck[$j][$i]]!=6 && $c_zokusei[$deck[$j][$i]] ne "함정"){$deck[$j][$i].="_i";}
				$tmp_s[$i]=$deck[$j][$i];
			}
			undef(@{$deck[$j]});
			for($i=0;$i<$#{$boti[$j]}+1;$i++){
				$boti[$j][$i]=~s/_.$//;
				if($c_syokan[$boti[$j][$i]]==1){push(@{$yugo[$j]},$boti[$j][$i]);}
				else{push(@{$deck[$j]},$boti[$j][$i]);}
			}
			@{$boti[$j]}=@tmp_s;&shuffle(*deck,$j);
		}
		if($player[$s_d]==2){&add_msg("카이바","(구…　믿은 것일까…<br>내 패배의 미래 등! )");}
	}
	elsif($t_nm eq "시못치에 의한 부작용"){
		if(&used){return;}
		&add_msg("null","시못치 발생! <br>$pn[$s_d]의 라이프 회복은 , 부작용으로 데미지가 된다! ");
	}
	elsif($t_nm eq "먼지떨이 흘림"){
		if(&used){return;}
		if($chain[0]=~/[12]-0-(\d+)/ && $tehuda[$s_d][$#{$tehuda[$s_d]}]==$1){
			&add_msg("null","$c_name[$1]을 먼지떨이 떨어뜨렸다! ");
			&go_boti2($#{$tehuda[$s_d]},1,2);
		}
	}
	elsif($t_nm eq "로스트"){
		$seast="999300000001";
		if(&go_card_search){return;}
		if(&used){return;}
		&add_msg("null","$c_name[$boti[$s_d][$res_s[0]-300]]는 영원히 없어졌다! ");
		$boti[$s_d][$res_s[0]-300]="";&del_null(*boti,$s_d);
	}
	elsif($t_nm eq "양동 작전"){
		if(&used){return;}
		&add_msg("null","이 턴 덮고 몬스터에게는 공격할 수 없다! ");
		$hk[19]=1;
	}
	elsif($t_nm eq "요격 준비"){
		$seast="901911";$jokenst='&syu_st($res_si) eq "전사" || &syu_st($res_si) eq "마법사"';
		if(&go_card_search){return;}
		if(&used){return;}
		&add_msg("null","$c_name[$fld[$res_s[0]]]는 요격 태세를 취했다! ");
		$fld_ad[$res_s[0]]=1;$fld_rf[$res_s[0]]=1;
		@so_arr=split(/<>/,$fld_koka[$res_s[0]]);
		for($i=0;$i<$#so_arr+1;$i++){
			if($so_arr[$i]!~/^f_(\d+)/){next;}
			$fno=$1;$cno=$fld[$fno];
			if($c_syuzoku[$cno] eq "장비" || grep(/^$cno$/,@soubiatu) || $so_arr[$i]=~/sacr/){&go_boti($fno,3);$so_arr[$i]="";}
		}
		$fld_koka[$res_s[0]]=join("<>",@so_arr);
	}
	elsif($t_nm eq "진실의 눈"){
		if(&used){return;}
		if($player[$s_a]==0){&add_msg("유희","이 카드에 의해 너의 패는 모두 열린다! ");}
		&add_msg("null","우쟈트의 눈이$pn[$s_d]의 명함을 간파했다! ");
		if($player[$s_d]==2){&add_msg("카이바","(구…나의 패를 보는것은 최대의 굴욕! )");}
	}
	elsif($t_nm eq "영식마도 분쇄기"){
		$seast="299900001";
		if(&go_card_search){return;}
		if(&used){return;}
		&add_msg("null","$c_name[$tehuda[$s_a][$res_s[0]-50]]를 분쇄! <br>$pn[$s_d]에500의 데미지! ");
		$lp[$s_d]-=500;&chk_lp;
		&go_boti2($res_s[0]-50);&del_null(*tehuda,$s_a);
	}
	elsif($t_nm eq "가짜 함정"){
		@tmp=split(/-/,$chain[0]);$nise="";$nisef=$tmp[3];
		if($tmp[2]==805 || $tmp[2]==872){
			$tmp[4]=~/\d+:\d+:(\d+)/;
			if($c_zokusei[$fld[$1]] ne "함정"){&add_msg("null","!$s_a(함정 밖에 지킬 수 없다)");return;}
			$nise=$c_name[$fld[$1]];
		}
		if(&used){return;}
		&add_msg("null","<font color=$textc_p2><b>스카　! </b></font>");
		$nisewana=1;
	}
	elsif($t_nm eq "DNA 개조 수술"){
		if($cont_flg!=1){
			if($cpu[$s_a]==1){$F{'options'}=9;}
			elsif($F{'options'} eq ""){$seast="";$tmp_syorip.="<>o-dna";&go_select_syori;return;}
		}
		if(&used){return;}
		&add_msg("null","장의 몬스터를 수술해$syu_arr[$F{'options'}]족으로 했다! ");
		$tmp=$#dna_t+1;
		$fld_koka[$use_f_no].="dna_$F{'options'}_$tmp<>";
	}
	elsif($t_nm eq "무차별 파괴"){
		if(&used){return;}
		&add_msg("null","스텐바이페이즈에 무차별 파괴를 실시한다! ");
	}
	elsif($t_nm eq "포스 필드"){
		if($chain[0]!~/[12]-9-(\d+)-(\d+)(.*)/){return;}
		@tmp=split(/-/,$3);shift(@tmp);
		$mes="!$s_a(몬스터 1체를 대상으로 하는 마법이 아니다)";
		if($#tmp!=0){&add_msg("null",$mes);return;}
		@tmp2=split(/:/,$tmp[0]);
		if($tmp2[1]==0){if($tmp2[2]<5 || 15<=$tmp2[2]){&add_msg("null",$mes);return;}}
		elsif($c_zokusei[$tmp[0]] eq "마" || $c_zokusei[$tmp[0]] eq "함정"){&add_msg("null",$mes);return;}

		if(&used){return;}
		&add_msg("null","력의 장소가 발생! <br><b>$c_name[$1]의 효과를 지웠다! </b>");
		&go_boti($2);
		$chain[0]=~s/^([12]).+/$1-null/;
	}
	elsif($t_nm eq "카운터 펀치"){
		$counter_panch=$use_f_no;$c_end=1;return;
	}
	elsif($t_nm eq "사령의 소"){
		if($cont_flg!=1){
			$seast="00131100001";$go_hit="<99";
			if(&go_card_search){return;}
			@res=sort {$b cmp $a} @res_s;
			if($res[0]>50 || $res[1]<200){return;}
			if(&lv_st($fld[$res[0]],$res_s[0])!=$#res){&add_msg("null","!$s_a(수가 맞지 않는다)");return;}
			$tmp="";
			for($i=1;$i<$#res+1;$i++){
				$tmp.=$c_name[$boti[$s_a][$res[$i]-200]]."와";
				$boti[$s_a][$res[$i]-200]="";
			}
			$tmp=~s/와$//;&add_msg("null","$tmp를 없애 --");
			@res_s=($res[0]);&del_null(*boti,$s_a);
		}
		else{@res_s=@select;}
		if(&used){return;}
		&add_msg("null","$c_name[$fld[$res_s[0]]]는 사령에 질질 끌어 들여졌다! ");
		&go_boti($res_s[0],5);
	}
	elsif($t_nm eq "격류장"){
		if(&used){return;}
		&add_msg("null","격류가 모든 몬스터를 삼킨다! ");
		for($u_i=$fw1[$s_d];$u_i<$fw1[$s_d]+5;$u_i++){&go_boti($u_i);}
		for($u_i=$fw1[$s_a];$u_i<$fw1[$s_a]+5;$u_i++){&go_boti($u_i);}
		if($player[$s_a]==12 && $player[$s_d]==3 && $room eq ""){
			&add_msg("조이","원! ");
			&add_msg("마해룡","(이런 반응이 없는 결투자는 처음…)");
		}
	}
	elsif($t_nm eq "몬스터 BOX "){
		if(&used){return;}
		if($player[$s_a]==3){&add_msg("조이","이녀석으로 공격을 교란하군! ");}
		&add_msg("null","장소에 나타난 상자에 몬스터를 숨겼다! ");
	}
	elsif($t_nm eq "악마의 주사위"){
		if(&used){return;}
		&add_msg("null","악마가 나타나고 주사위를 흔들었다! ");
		$rann=rand;$rann=int($rann*6)+1;$tmp=$rann*100;
		&add_msg("null","<b>$rann! </b><br>턴 종료시까지 공수$tmp다운! ");
		for($i=$fw1[$s_d];$i<$fw1[$s_d]+5;$i++){if($fld[$i] ne "" && $fld_rf[$i]!=1){$fld_koka[$i].="ptr:-$tmp:-$tmp:$turn<>";}}
	}
	elsif($t_nm eq "매직 암·쉴드(shield)"){
		if(&akichk()){return;}
		if($chain[0]!~/^$s_d-3-(\d+)-(.+)/){return;}
		if($2 eq "player"){&add_msg("null","!$s_a(몬스터가 공격을 받았을 때 밖에 발동할 수 없어)");return;}
		$taisyo_fld=$1;
		$seast="901901";$jokenst='$res_si!='.$taisyo_fld;
		if(&go_card_search){return;}
		if($player[$s_a]==3 && $cont_flg!=1){&add_msg("조이","여기하기 어려워! ");} 
		if(&used){return;}
		&add_msg("null","매직 암으로$c_name[$fld[$res_s[0]]]를 끌어 들였다!<br>공격은$c_name[$fld[$res_s[0]]]이 대신으로 된다! ");
		&ctrl_ido($res_s[0],$nf0);
		$fld_koka[$nf0].="m_arm<>";$jok[1]=1;
		$bstep=~s/(\d+)-.+/$1-$nf0/;$b_mst[1]=$fld[$nf0];$b_nam[1]=$c_name[$fld[$nf0]];
	}
	elsif($t_nm eq "쇠사슬 부착 부메랑"){
		$seast="90191";$tmp_syorip.="<>m-장비 한다면 장비 대상을 선택해 줘. <br>상대의 표시 형식을 변경할까요? <>o-한다::안한다<>l-1";
		&card_search;
		if($#res_s<0){$F{'options'}=0;}
		elsif($cpu[$s_a]!=1 && $F{'options'} eq ""){&go_select_syori;return;}

		if($chain[0]!~/^$s_d-3-(\d+)/){return;}$taisyo_fld=$1;

		if($cont_flg!=1){
			if($cpu[$s_a]!=1){if($select[0] ne ""){$res_s[0]=$select[0];undef(@select);$go_hit=2;}}
			elsif(!(&cpu_get_saikyo($seast,"",1))){$go_hit=2;}
			push(@res_s,$taisyo_fld);
		}
		else{@res_s=@select;}

		if(&used){return;}

		if($F{'options'}==0 && $fld[$taisyo_fld] ne "" && !(&not_taisyo($taisyo_fld))){
			$fld_ad[$taisyo_fld]=1;
			&add_msg("null","$c_name[$fld[$taisyo_fld]]을 쇠사슬로 매운 취했다! ");
			&piero($taisyo_fld);
		}
		if($res_s[1] ne "" && $fld[$res_s[0]] ne ""){
			&add_msg("null","부메랑은$c_name[$fld[$res_s[0]]]이 장비 해 , 공격력 500업! ");
		}
		if($player[$s_a]==3 && $player[$s_d]!=0 && $player[$s_d]!=1 && $srf_chk eq ""){&add_msg("조이","나는 유희와 싸우기로 한 남자야! <br>그럼! ");$srf_chk=1;}
	}
	elsif($t_nm eq "빛의 봉찰검"){
		if(($rann=&rand_tehuda(1))<0){&add_msg("null","!$s_a(상대에게 패가 없다)");return;}
		if(&used){return;}

		$husatu.="$s_d-$tehuda[$s_d][$rann]-$turn<>";
		$tehuda[$s_d][$rann]="";&del_null(*tehuda,$s_d);
		&add_msg("null","$pn[$s_d]의 명함을 1장 봉했다! <br>이 명함은 3턴의 사이 사용할 수 없다. ");
	}
	elsif($t_nm eq "연쇄 파괴"){
		if($chain[0]!~/^[12]-[12456]-(\d+)/){return;}
		if($ap_fld[$1]>2000){&add_msg("null","!$s_a(공격력2000이하의 몬스터 밖에 발동할 수 없다)");return;}
		@res_s=($1);
		if(&not_taisyo($1)){return;}

		if(&used){return;}
		if($chain[0]!~/^([12])-[456]-(\d+)-(\d+)/){return;}
		$renno=$1;$tmpno=$3;undef(@sutehuda);
		&add_msg("null","$pn[$renno]의 패와 덱을 파괴의 쇠사슬이 관철한다! ");
		if($c_syokan[$tmpno]==1){
			for($i=0;$i<$#{$yugo[$renno]}+1;$i++){
				if($yugo[$renno][$i]==$tmpno){
					$yugo[$renno][$i]="";push(@sutehuda,$tmpno);
					&add_msg("null","융합 덱의 것$c_name[$tmpno]을 파괴했다! ");
				}
			}
			&del_null(*yugo,$renno);
		}
		else{
			for($i=0;$i<$#{$tehuda[$renno]}+1;$i++){
				if($tehuda[$renno][$i]==$tmpno){
					$tehuda[$renno][$i]="";push(@sutehuda,$tmpno);
					&add_msg("null","패의 것$c_name[$tmpno]을 파괴했다! ");
				}
			}
			&del_null(*tehuda,$renno);
			for($i=0;$i<$#{$deck[$renno]}+1;$i++){
				if($deck[$renno][$i]==$tmpno){
					$deck[$renno][$i]="";push(@sutehuda,$tmpno);
					&add_msg("null","덱의 것$c_name[$tmpno]을 파괴했다! ");
				}
			}
			&del_null(*deck,$renno);&shuffle(*deck,$renno);
		}
		if($#sutehuda>-1){&arr_to_boti(*sutehuda,&usertoside($renno));}
	}
	elsif($t_nm eq "매직컬 비단 모자"){
		if($s_a==$turn2 || $phase!=3){&add_msg("null","!$s_a(상대 턴의 배틀페이즈 밖에 사용할 수 없다)");return;}
		if(&maisu_count(8)<2){&add_msg("null","!$s_a(장소에 빈 곳이 없다)");return;}
		$seast="99191";
		if(&go_card_search){return;}
		if($cpu[$s_a]==1){$chain[0]=~/^[12]-3-\d+-(\d+)/;$res_s[0]=$1;}

		if(&used){return;}
		$seast="1999000000001";$tmp_syorip="<>n-silkhat<>g-1<>i-$s_a<>p-$res_s[0]<>h-2";
		&go_select_syori;
		$jok[1]=1;
	}
	elsif($t_nm eq "각의 봉인"){
		if(&used){return;}
		&add_msg("null","$pn[$s_d]의 드로페이즈를 봉인했다! ");$hk[10+$s_d]=1;
	}
	elsif($t_nm eq "탐욕인 병"){
		if(&used){return;}
		&add_msg("null","산찰로부터 1장 드로! ");&tehuda_draw(0,1);
	}
	elsif($t_nm eq "약체화의 가면"){
		if(&used){return;}
		if($chain[0]!~/^[12]-3-(\d+)-/){return;}
		&add_msg("null","몬스터를 약체화 시키는 가면이 장착되었다! <br>턴 종료시까지 공격력 700다운! ");
		$fld_koka[$1].="ptr:-700:0:$turn<>";
	}
	elsif($t_nm eq "침묵의 사악영혼"){
		if($chain[0]!~/^[12]-3-(\d+)-(.+)/){return;}
		$at_fld=$1;
		$seast="901901";$jokenst='$res_si!='.$at_fld;
		if(&go_card_search){return;}

		if(&used){return;}

		&add_msg("null","$c_name[$fld[$at_fld]]은 침묵을 피할수 없게 되고 --<br>공격 명령은$c_name[$fld[$res_s[0]]]에! ");
		&a_b_chg($at_fld);
		$fld_ad[$res_s[0]]=0;$a_b[$res_s[0]]="p";$a_m[$res_s[0]]=2;
		$bstep=~s/\d+-(.+)/$res_s[0]-$1/;$b_mst[0]=$fld[$res_s[0]];$b_nam[0]=$c_name[$fld[$res_s[0]]];
		$tinmoku=1;
	}
	elsif($t_nm eq "아포피스의 화 신"){
		if(&akichk()){return;}
		if(&ext_chk()){return;}
		if($phase==2 || $phase==4){}
		elsif($phase==3 && $chain[0] eq ""){}
		else{&add_msg("null","!$s_a(이 카드는 메인페이즈 밖에 사용할 수 없다)");return;}
		if($F{'options'} eq "" && $cpu[$s_a]!=1){$tmp_syorip.="<>o-공격 표시::수비 표시";$seast="";&go_select_syori;return;}

		if(&used){return;}

		&add_msg("null","함정이 작동해 , 함정 몬스터가 나타났다! ");
		$fld[$nf0]=1098;&ext_set($nf0);
		if($F{'options'}==1){$fld_ad[$nf0]=1;}$F{'options'}="";
		$fld_koka[$nf0].="f_".$use_f_no."<>";
		$fld_koka[$use_f_no].="f_".$nf0."<>";
	}
	elsif($t_nm eq "황산이 쌓인 함정"){
		$seast="919911";$jokenst='$fld_ad[$res_si]==1';
		if(&go_card_search){return;}
		if(&used){return;}
		$t_side=$sno[&which_side($res_s[0],1)];
		$t_mst = $fld[$res_s[0]];
		&add_msg("null","세트 몬스터를 넘겼다. $c_name[$t_mst](이)였다! ");
		if($dp_fld[$res_s[0]]<=2000){
			&add_msg("null","$c_name[$t_mst](은)는 황산안에 떨어졌다. ");
			&reverse($res_s[0]);
			&go_boti($res_s[0]);
		}
		else{&add_msg("null","그대로 바탕으로 되돌렸다. ");}
	}

	elsif($t_nm eq "이타크의 폭풍"){
		$seast="909901";&card_search;
		if($#res_s<0){&add_msg("null","!$s_a(상대의 필드에 겉표시 몬스터가 없다)");return;}
		undef(@res_s);
		if(&used){return;}
		&add_msg("null","괴조 이타크의 홰쳐! <br>$pn[$s_d]의 겉표시 몬스터는 표시 형식이 변경된다! ");
		for($i=$fw1[$s_d];$i<$fw1[$s_d]+5;$i++){if($fld[$i] ne "" && $fld_rf[$i]!=1){$fld_ad[$i]=1-$fld_ad[$i];&piero($i);}}

	}
	elsif($t_nm eq "협공"){
		$seast="991911";$go_hit=3;
		if(&go_card_search){return;}
		@res_s2 = sort {$a <=> $b;} @res_s;@res_s=@res_s2;
		if($fw1[$s_a]>$fw1[$s_d]){$tmp=$res_s[0];$res_s[0]=$res_s[2];$res_s[2]=$tmp;}
		$hasi1=&which_side($res_s[0],1);
		$hasi2=&which_side($res_s[1],1);
		$hasi3=&which_side($res_s[2],1);
		if($hasi1!=0 || $hasi2!=0 || $hasi3!=1){return;}
		if(&used){return;}
		&add_msg("null","$c_name[$fld[$res_s[0]]]와$c_name[$fld[$res_s[1]]]의 협공! <br><b>$c_name[$fld[$res_s[2]]]을(를) 파괴! </b>");
		&go_boti($res_s[0]);&go_boti($res_s[1]);&go_boti($res_s[2],5);
	}
	elsif($t_nm eq "보충 요원"){
		$seast="09990000001";&card_search;
		if($#res_s<4){&add_msg("null","!$s_a(묘지에 몬스터가 5장 이상 없다)");return;}
		$jokenst='$res_sap<=1500 && $c_koka[$cardno] eq ""';$go_hit="<4";
		if(&go_card_search){return;}
		&cpu_get_saikyo("","",3);
		if(&used){return;}
		for($i=0;$i<$#res_s+1;$i++){
			$tmpno=$boti[$s_a][$res_s[$i]-200];$boti[$s_a][$res_s[$i]-200]="";
			push(@{$tehuda[$s_a]},$tmpno);
			&add_msg("null","$c_name[$tmpno]을 보충했다! ");
		}
		&del_null(*boti,$s_a);
	}
	elsif($t_nm eq "만능 지뢰 그레이모야"){
		if(&used){return;}
		$seast="999901";$jokenst='$fld_ad[$res_si]!=1';&card_search;
		@res_s2 = sort ap_cre_res @res_s;
		if($res_s2[0] ne ""){
			&add_msg("null","$pn[$s_d]는 지뢰를 밟았다! <br><b>$c_name[$fld[$res_s2[0]]](은)는 폭풍으로 날아갔다! </b>");&go_boti($res_s2[0]);
		}
	}
	elsif($t_nm eq "심술꾸러기의 저주"){
		if(&used){return;}
		&add_msg("null","역전의 저주가 나돌았다! <br>파워업·다운은 반대로 작용한다! ");
		$hk[5]=1;
	}
	elsif($t_nm eq "자업자득"){
		if(&used){return;}
		$cou=&maisu_count(1);$tmp=$cou*500;
		&add_msg("null","상대 몬스터의 수만큼 데미지를 준다! <br><b>$pn[$s_d](은)는$tmp의 데미지! </b>");
		$lp[$s_d]-=$tmp;&chk_lp;
	}
	elsif($t_nm eq "매직·드레인"){
		if(&used){return;}
		&add_msg("null","$pn[$s_d]의 마력을 흡수! ");
		$seast="299900001";$jokenst="";
		$tmp_syorip="<>n-drain<>i-$s_d<>m-(마법을 발동하려면  , 마법 카드를 버릴 필요가 있다)<>o-버린다::안버린다(마법 무효)<>l-1<>g-1";
		&go_select_syori;
	}
	elsif($t_nm eq "정령의 거울"){
		if(&used){return;}
		if($chain[0]!~/^([12])-9-(\d+)/){return;}
		&add_msg("null","$c_name[$2]을 장악 해 , 효과를 바꾸었다! ");
		$tmp=3-$1;substr($chain[0],0,1)=$tmp;
	}
	elsif($t_nm eq "위쟈반"){
		if($cpu[$s_a]==1 && $kok[$s_a][23] ne ""){return;}
		if(&used){return;}
		&add_msg("null","영혼과의 교신반이 나타났다…! <br>지시판이 움직이기 시작해 , 「D」의 문자를 지시했다. ");
		if($player[$s_a]==8){&add_msg("바크라","5턴 후 -- 「DEATH」의 5문자가 갖추어졌을 때…<br>당신은 말살된다…!　쿠크크…");}
	}
	elsif($t_nm eq "신의 심판" || $t_nm eq "매직 재머" || $t_nm eq "도적의 7가지 도구" || $t_nm eq "승천의 뿔피리"){
		if($t_nm=~/^매/){
			$kind=1;
			if($cont_flg!=1){
				$seast="999900001";$go_msg="(패가 존재하지 않는다)";
				if(&go_card_search){if($#res_s>0){&add_msg("null","!$s_a(패를 1장 버릴 필요가 있다)");}return;}
				&cpu_sutehuda;
				&add_msg($pn[$s_a],"$c_name[$tehuda[$s_a][$res_s[0]-50]]을 버리고 --");
				$in_proc=1;&go_boti2($res_s[0]-50);$in_proc="";&maryoku(17);undef(@res_s);
			}
		}
		elsif($t_nm=~/^도/){
			$kind=2;
			if($cont_flg!=1){
				if($cpu[$s_a]==1 && $lp[$s_a]<=1000){return;}
				&add_msg($pn[$s_a],"1000의 라이프를 지불해 --");
				$lp[$s_a]-=1000;&chk_lp;
			}
		}
		elsif($t_nm=~/^승/){
			$kind=3;
			if($cont_flg!=1){
				$seast="99121";$go_msg="(자신의 장소에 몬스터가 없다)";
				if(&go_card_search){if($#res_s>0){&add_msg("null","!$s_a(자군 몬스터를 제물로 바친다)");}return;}
				if($cpu[$s_a]==1){
					@res_s2 = sort ap_cre_res @res_s;
					$res_s[0]=$res_s2[$#res_s2];
				}
				&add_msg($pn[$s_a],"$c_name[$fld[$res_s[0]]]를 제물로 바치고 --");
				&go_boti($res_s[0],4);undef(@res_s);
			}
		}
		else{
			$chain[0]=~/[12]-(\d+)-/;
			if($1==9){$kind=1;}elsif($1==10){$kind=2;}else{$kind=3;}
			if($cont_flg!=1){
				if($cpu[$s_a]==1 && $lp[$s_a]>3000){return;}
				&add_msg("null","라이프 포인트 반을 지불해 --");
				$lp[$s_a] = int($lp[$s_a] / 2);
			}
		}
		if(&used){return;}

		if($kind==1){
			if($chain[0]!~/[12]-9-(\d+)-(\d*)/){return;}
			if($1==1074){&add_msg("null","<b>요정은 무효화되지 않는다! </b>");return 1;}
			else{&add_msg("null","<b>$c_name[$1]의 효과를 지웠다! </b>");&go_boti($2);}
		}
		elsif($kind==2){
			if($chain[0]!~/[12]-10-(\d+)-(\d*).*/){return;}
			&add_msg("null","<b>$c_name[$1](을)를 해제했다! </b>");
			&go_boti($2);
		}
		elsif($kind==3){
			if($chain[0]!~/[12]-[125]-(\d+)/){return;}
			$tfno=$1;$tcno=$fld[$tfno];
			&add_msg("null","<b>$c_name[$tcno]의 소환을 지웠다! </b>");
			$ltmp=&which_side($tfno);&syometu($tfno);
			undef(@sutehuda);$sutehuda[0]=$tcno;&arr_to_boti(*sutehuda,$ltmp,1);
		}
		$chain[0]=~s/^(\d-).+/$1/;
	}
	elsif($t_nm eq "맹렬한 회오리 해류벽"){
		if($kok[0][59] eq ""){&add_msg("null","!$s_a(필드가 바다가 아니다)");return;}
		if($player[$s_a]==12 && $chain[0]=~/^[12]-3-/ && $cont_flg!=1){&add_msg("미목","에!　그렇게는 안돼! ");}
		if(&used){return;}
		&add_msg("null","바다의 필드가 거대한 맹렬한 회오리에 변화! <br>플레이어의 방어벽이 되었다! ");
	}
	elsif($t_nm eq "강제 접수"){
		if(&used){return;}
		&add_msg("null","명함 버리기에 상대를 말려들게 할 수가 있다! ");
	}
	elsif($t_nm eq "편승"){
		if(&used){return;}
		&add_msg("null","상대의 드로에 편승 할 수가 있다! ");
	}
	elsif($t_nm eq "구세주의 개미귀신"){
		if(&used){return;}
		&add_msg("null","시공의 개미귀신이 발생! <br>레벨 3이하의 몬스터는 소환한 턴에 파괴! ");
	}
	elsif($t_nm eq "텐구의 집안"){
		if(&used){return;}
		&add_msg("null","텐구가 나타나고 집안으로 파랑 희생타 했다! ");
	}
	elsif($t_nm eq "스피릿의 권유"){
		if(&used){return;}
		&add_msg("null","스피릿이 명함으로 돌아올 때 길동무를 동반한다! ");
	}
	elsif($t_nm eq "불길한 점"){
		if(&used){return;}
		&add_msg("null","스탄바이페이즈에 점을 할 수 있다! ");
	}
	elsif($t_nm eq "용의 노여움"){
		if(&used){return;}
		&add_msg("null","노여움에 접할 수 있었던 용은 , 수비 몬스터에게도 데미지를 준다! ");
	}
	elsif($t_nm eq "죽음의 연산반"){
		if(&used){return;}
		&add_msg("null","묘지에 연산반이 나타났다! <br>몬스터가 통과할 때 , 연산을 한다! ");
	}
	elsif($t_nm eq "생지 봉하고의 가면"){
		if(&used){return;}
		if($player[$s_a]==23){&add_msg("빛의 가면","햐하하 걸렸는지 샀다! ");}
		&add_msg("null","장소에 기분 나쁜 가면이 나타났다! <br><b>모든 살리고 지는 봉쇄되었다! </b>");
	}
	elsif($t_nm eq "디펜드·슬라임"){
		if($player[$s_a]==6 && $cont_flg!=1){&add_msg("마리크","그렇게 는…　가지 않는다! ");}
		if(&used){return;}
		&add_msg("null","리바이벌 슬라임이 대신으로 된다! ");
	}
	elsif($t_nm eq "고블린의 말단 벼슬아치"){
		if($lp[$s_d]>3000){&add_msg("null","!$s_a(상대의 라이프가3000이하가 아니면 발동할 수 없어)");return;}
		if(&used){return;}
		&add_msg("null","약자로부터 세 사리 잡는 말단 벼슬아치다!<br>$pn[$s_d](은)는 스탄바이페이즈 마다 500의 세를 지불한다! ");
	}
	elsif($t_nm eq "로빈 고블린"){
		if(&used){return;}
		&add_msg("null","데미지를 줄 때마다 , 패를 1장 빼앗는다! ");
	}
	elsif($t_nm eq "마력의 가시나무"){
		if(&used){return;}
		&add_msg("null","$pn[$s_d]의 명함에 가시나무가 감긴다! <br>명함으로부터 버릴 때마다 500의 데미지! ");
	}
	elsif($t_nm eq "사령의 권해"){
		if(&used){return;}
		&add_msg("null","서로의 묘지에 사령이 저주를 걸쳤다! <br>묘지에 카드가 보내질 때마다 300의 데미지! ");
	}
	elsif($t_nm eq "때의 기계 -타임·머신 -"){
		if(&ext_chk()){return;}
		$time_machine=$s_a."-".$use_f_no;$c_end=1;return;
	}

	elsif($t_nm eq "메탈화·마법 반사 장갑"){
		$seast="901911";
		if(&go_card_search){return;}

		if($cpu[$s_a]==1){if(&cpu_get_saikyo("90191",'')){return;}}

		if(&used){return;}
		&add_msg("null","메탈화로 공격력·수비력이 300업! <br>한층 더$c_name[$fld[$res_s[0]]]의 공격시에 마법 반사 장갑이 발동한다! ");
	}

	elsif($t_nm eq "파괴고리"){
		$seast="901911";
		if(&go_card_search){return;}

		if(&cpu_get_saikyo("901901",'$ap_fld[$res_si]>1700 && $ap_fld[$res_si]<$lp[$s_a]')){return;}
		if(&used){return;}
		$dam_tmp=$ap_fld[$res_s[0]];
		&add_msg("null","$c_name[$fld[$res_s[0]]]에 파괴의 고리가 장착되었다! <br><b>파괴! <br>서로$dam_tmp의 데미지! </b>");
		$lp[$s_a]-=$dam_tmp;$lp[$s_d]-=$dam_tmp;&chk_lp;
		&go_boti($res_s[0],5);
	}
	elsif($t_nm eq "희생의 제물"){
		if($s_a ne $turn2 && $phase!=3){&add_msg("null","!$s_a(상대 턴에는 배틀페이즈로 밖에 사용할 수 없어)");return;}
		if($cont_flg!=1){
			&add_msg("null","500의 라이프를 지불해 --");
			$lp[$s_a]-=500;&chk_lp;
		}
		if(&used){return;}
		&add_msg("null","몬스터를 1체 소환할 수가 있다! ");
		push(@syori,"4<>i-$s_a");
	}

	elsif($t_nm eq "호 -리·에르프의 축복"){
		if(&used){return;}
		$cou=&maisu_count(0)+&maisu_count(1);
		&add_msg("null","호 -리·에르프는 회복의 주문을 주창했다! ");
		&lp_up(300,$cou);
	}

	elsif($t_nm eq "화목의 사자"){
		if(&used){return;}
		&add_msg("null","사자가 나타나고 화목을 묶었다! <br><b>이 턴$pn[$s_a]의 전투 데미지는 무효! </b>");
		$hk[2+$s_a]=1;
	}

	elsif($t_nm eq "하나님의 베품"){
		if(&used){return;}
		&add_msg("null","이후 , 드로마다500의 라이프를 얻는다! ");
	}

	elsif($t_nm eq "은막의 경벽"){
		if(&used){return;}
		&add_msg("null","장에 거울의 벽이 출현! ");
	}

	elsif($t_nm eq "공격의 무력화"){
		if($chain[0]!~/^[12]-3-/){return;}
		if(&used){return;}
		$chain[0]=~s/^(\d-).+/$1/;
		&add_msg("null","공격은 시공의 소용돌이에 흡수되어 바트르페이즈 종료! ");
		if($jok[1] ne ""){&bphase_end;}$phase=4;
	}

	elsif($t_nm eq "6망성의 주박" || $t_nm eq "어둠의 주박"){
		$seast="991901";$jokenst='$fld_koka[$res_si]!~/rokubo/';
		if(&go_card_search){return;}

		if($cpu[$s_a]==1){&cpu_get_saikyo();}
		if(&used){return;}
		if($player[$s_d]==5 && $t_nm=~/^어둠/){&add_msg("페가수스","여기서 그 카드를 적용한다고는…그레이트! ");}
		&add_msg("null","상대 몬스터는 주박에 걸려 , 공격도 표시 변경도 할 수 없다! ");
		&soubi($res_s[0],$use_f_no,"_rokubo");
	}

	elsif($t_nm eq "사진의 오타츠권"){
		$seast="99990001";
		if(&go_card_search){return;}
		if(&cpu_cyc){return;}

		if(&used){return;}
		if(&nisewana_chk($res_s[0])){
			&add_msg("null","「$c_name[$fld[$res_s[0]]]」을 파괴했다! ");
			&go_boti($res_s[0],2);
		}

		$seast="199900001";$jokenst='$c_name[$cardno]!~/^죽음의 메/';&card_search;
		if($#res_s>-1){
			$tmp_syorip="<>n-sajin<>m-(마법·함정 카드를 1장 세트 할 수가 있다)<>i-$s_a";
			&go_select_syori;
			if($cpu[$s_a]==1){$select[0]=$res_s[0];}
		}
	}
	elsif($t_nm eq "유혹의 그림자"){
		if(&used){return;}
		if($chain[0]!~/^[12]-8-(\d+)/){return;}
		$taisyo_fld = $1;
		&add_msg("null","공격 페로몬의 힘으로 ,$c_name[$fld[$taisyo_fld]]는 강제적으로 공격 표시가 된다! ");
		$fld_rf[$taisyo_fld]=0;$fld_ad[$taisyo_fld]=0;
	}
	elsif($t_nm eq "죽음의 데크 파괴 바이러스"){
		if($cont_flg!=1){
			$seast="99121";$jokenst='$c_zokusei[$cardno] eq "어둠" && $res_sap<=1000';
			$go_msg="(매개가 존재하지 않는다)";
			if(&go_card_search){return;}

			if($player[$s_a]==2){&add_msg($pn[$s_a],"후후…, 세에도 무서운 재즈 악단을 보여 준다…. ");}
			&add_msg($pn[$s_a],"$c_name[$fld[$res_s[0]]]을(를) 매개에 --");
			&go_boti($res_s[0],4);undef(@res_s);
		}
		if(&used){return;}
		&add_msg("null","<b>공격력1500이상의 몬스터는 소멸! </b><br>――장소 --");

		for($i=$fw1[$s_d];$i<$fw1[$s_d]+5;$i++){
			if($fld[$i] eq ""){next;}
			elsif($ap_fld[$i]<1500){&add_msg("null","($c_name[$fld[$i]]는 바이러스 대상외)");}
			else{&add_msg("null","$c_name[$fld[$i]]소멸! ");&go_boti($i);}
		}
		&add_msg("null","――카드패 --");
		for($i=0;$i<$#{$tehuda[$s_d]}+1;$i++){
			$tmp=$tehuda[$s_d][$i];
			if($tmp eq ""){}
			elsif($c_ap[$tmp]<1500 && $c_ap[$tmp]!~/^X/){&add_msg("null","($c_name[$tmp]는 바이러스 대상외)");}
			else{&add_msg("null","$c_name[$tmp]소멸! ");&go_boti2($i,1,1);}
		}
		&del_null(*tehuda,$s_d);
		&add_msg("null","게다가$pn[$s_d]의 덱은 3턴의 사이 바이러스에 감염! ");
		$hk[2-$s_a]=$turn;
	}
	elsif($t_nm eq "정전협정"){
		if(&used){return;}
		&add_msg("null","표리시 몬스터는 겉표시가 되어 , 효과 몬스터×500의 데미지를 준다! ");
		$tmp=0;
		for($i=5;$i<5*3;$i++){
			$fld_rf[$i]=0;
			if($c_koka[$fld[$i]] ne "" || $c_syokan[$fld[$i]]==4){$tmp++;}
		}
		if($tmp>0){
			$tmp *= 500;$lp[$s_d]-=$tmp;
			&add_msg("null","<b>$pn[$s_d]에$tmp의 데미지! </b>");
			&chk_lp;
		}
	}
	elsif($t_nm eq "마 봉하고의 방향"){
		if(&used){return;}
		&add_msg("null","마를 봉하는 방향이 자욱하는…<br>마법 카드는 덮고 나서 다음의 자 턴까지 사용할 수 없다! ");
	}
	elsif($t_nm eq "왕궁의 호령"){
		if(&used){return;}
		&add_msg("null","왕궁으로부터 호령이 내려졌다! <br><b>모든 리버스 효과는 무효가 된다! </b>");
	}
	elsif($t_nm eq "왕궁의 명령"){
		if(&used){return;}
		&add_msg("null","왕궁으로부터 명령이 내려졌다! <br><b>모든 함정의 효과는 무효가 된다! </b>");
	}
	elsif($t_nm eq "왕궁의 칙명"){
		if(&used){return;}
		&add_msg("null","왕궁으로부터 칙명이 내려졌다! <br><b>모든 마법 효과는 무효가 된다! </b>");
	}
	elsif($t_nm eq "그라비티·바인드초 중력의 그물 -"){
		if(&used){return;}
		&add_msg("null","장소에 강한 중력을 걸칠 수 있었다! <br><b>레벨 4이상의 몬스터는 공격할 수 없다! </b>");
	}
	elsif($t_nm eq "드래곤족 봉인항아리"){
		if(&used){return;}
		&add_msg("null","장에 봉인의 항아리가 출현! <br><b>모든 드래곤족은 수비 표시가 된다! </b>");
	}
	elsif($t_nm eq "성스러운 빛나"){
		if(&used){return;}
		&add_msg("null","강렬한 빛이 장소를 비춘다! <br>이후 , 수비 표시로 낸 몬스터는 모두 겉(표)가 된다! ");
	}
	elsif($t_nm eq "성스러운 방어막 거울의 힘"){
		if(&used){return;}

		&add_msg("null","밀러 베리어가 상대의 공격을 사방으로 치고 돌려준다! <br><b>상대의 장소의 공격 몬스터는 전멸! </b>");

		for($t_i=$fw1[$s_d];$t_i<$fw1[$s_d]+5;$t_i++){
			if($fld_ad[$t_i]!=1){&go_boti($t_i);}
		}
		if($player[$s_a]==0 && $player[$s_d]==10 && $room eq ""){
			&add_msg($pn[$s_d],"<b>교에에에에 곤충 군단 전멸 ~~~! </b>");
			&add_msg($pn[$s_a],"너 약하지! ");
		}
	}
	elsif($t_nm eq "마법의 통" || $t_nm eq "호리쟈베린"){
		if($chain[0]!~/^[12]-3-(\d+)-(.+)/){return;}
		$at_fld = $1;
		@res_s=($at_fld);
		if(&not_taisyo($at_fld)){return;}
		if(&used){return;}

		if($fld[$at_fld] eq ""){&add_msg("null","그러나 , 대상이 존재하지 않았다");return;}

		if($t_nm=~/^마/){
			&add_msg("null","매직 실린더에 흡수된 공격은 , 그대로 상대에게 돌아간다! ");
			&add_msg("null","<b>$pn[$s_d]에$ap_fld[$at_fld]의 데미지! </b>");
			$lp[$s_d]-=$ap_fld[$at_fld];&chk_lp;
			&a_b_chg($at_fld);
			$chain[0]=~s/^(\d-).+/$1/;
		}
		else{
			&add_msg("null","성스러운 창이 상대의 공격력을 흡수! ");
			&add_msg("null","<b>$pn[$s_a](은)는$ap_fld[$at_fld]의 라이프를 회복! </b>");
			&lp_up($ap_fld[$at_fld]);
		}
	}
	elsif($t_nm eq "함정속으로" || $t_nm eq "점착 테이프의 집" || $t_nm eq "쥐잡기"){
		if($chain[0]!~/^$s_d-[124]-(\d+)/){return;}
		$taisyo=$1;if($fld[$taisyo] eq ""){return;}
		if(($t_nm=~/^함/ && $ap_fld[$taisyo]<1000) || ($t_nm=~/^점/ && $dp_fld[$taisyo]>500) || ($t_nm=~/^쥐/ && $ap_fld[$taisyo]>500)){&add_msg("null","!$s_a(공수의 조건을 채우지 않았다)");return;}
		if(&not_taisyo($taisyo)){return;}
		@res_s=($taisyo);
		if(&used){return;}

		if($t_nm=~/^함/){&add_msg("null","공격력1000이상의 몬스터는 함정에 빠진다! ");}
		elsif($t_nm=~/^점/){&add_msg("null","소형 몬스터는 점착 테이프에 매운 놓쳤다! ");}
		else{&add_msg("null","소형 몬스터는요 완료 잡기에 걸렸다! ");}
		&add_msg("null","<b>$c_name[$fld[$res_s[0]]]소멸! </b>");
		&go_boti($res_s[0],5);
		if($t_nm=~/^함/ && $player[$s_a]==3 && $player[$s_d]==14 && $room eq ""){
			&add_msg("밴디트 키스","야 와…　함정이라면! ");
			&add_msg("조이","키스야 …<br>라고 째 -는 역시 타락하는 곳까지 타락해! ");
		}
	}
	elsif($t_nm eq "나락의 함정"){
		if($chain[0]!~/^$s_d-[12456]-(\d+)/){return;}
		if($ap_fld[$1]<1500){&add_msg("null","!$s_a(공격력1500이상의 몬스터 밖에 발동할 수 없다)");return;}
		if(&not_taisyo($1)){return;}
		@res_s=($1);
		if(&used){return;}
		$taisyo_fld = $1;

		&add_msg("null","공격력1500이상의 몬스터는 함정에 빠진다! ");
		&add_msg("null","<b>$c_name[$fld[$taisyo_fld]](은)는 나락에 사라졌다! </b>");
		&syometu($taisyo_fld);
	}
	else{
		if(&used){return;}
		&add_msg("null","페가수스 「Sorry , 현재 사용할 수 있는 카드는<a href=\"$ahelp\" target=new>이것</a>뿐이에요~」");
	}

	return 1;
}

sub del_chain{
	$chudan=$chain[0];
	$chudan=~s/^([12])-//;
	if($chain[0]=~/^([12])-[125]-(.+)/){$chain[0]="$1-4-$2";}
	else{shift(@chain);}
	push(@s_sitei,$1);
	&chg_user;
	&chudan_kaihuku($chudan);
	shift(@s_sitei);
	&chg_user;

	undef(@select);
	if($#chain<0){$c_end="";}
}

sub del_chain2{
	$chudan=shift(@chain2);
	$chudan=~s/^([12])-//;
	push(@s_sitei,$1);
	&chg_user;
	if($chudan=~s/^5-(\d+)-*//){&use_koka_a($1,$chudan);}
	elsif($chudan=~s/^7-(\d+)-*//){&use_koka_r($1,$chudan);}
	elsif($chudan=~s/^6-//){$F{'use'}=$chudan;&use_card;}
	shift(@s_sitei);
	&chg_user;
}

sub revice_syori{
	local($tmp);

	foreach $key (keys(%S)){
		$tmp.="$key-$S{$key}<>";
	}
	unshift(@syori,"2<>$tmp");
}

sub del_syori{
	shift(@syori);
	undef(@select);$F{'options'}="";
	&chg_user;
}

sub after_select{
	local($chudan)=$_[0];
	local($para)=$_[1];

	if($chudan=~s/^1-//){
		$F{'putcardno'}=$chudan;
		&put_card_mst;
	}
	elsif($chudan=~s/^3-//){
		@b_fld=split(/-/,$chudan);
		&battle_run2;
	}
	elsif($chudan=~s/^4-//){
		@b_fld=split(/-/,$chudan);
		&battle_run;
	}
	elsif($chudan=~s/^5-//){
		$cont_flg=1;
		&use_koka_a($chudan,$para);
		$cont_flg="";
	}
	elsif($chudan=~s/^6-//){
		$F{'use'}=$chudan;
		&use_card;
	}
	elsif($chudan=~s/^7-//){
		$cont_flg=1;
		&use_koka_r($chudan,$para);
		$cont_flg="";
	}
}

sub chudan_kaihuku{
	local($chudan)=$_[0];

	if($chudan=~/^0-/){
		$cont_flg=1;
		&stanby_phase;
		$cont_flg="";
	}
	elsif($chudan=~/^([1258])-(\d+)-(\d+)-*(\d*)/){
		$s_kind=$1;$fldno=$2;$mstno=$3;$gilfo=$4;
		if($fld[$fldno] ne ""){&put_card_mst2;}
	}
	elsif($chudan=~s/^9-// || $chudan=~s/^10-//){
		$cont_flg=1;
		&use_card;
		$cont_flg="";
	}
	elsif($chudan=~/^11-/){
		$cont_flg=1;
		&end_phase;
		$cont_flg="";
	}
}

sub chain_chk{
	local($cardno)=$_[0];

	$syokan=$c_syokan[$cardno];

	if($pat==10 && $c_syuzoku[$t_cno] eq "카운터"){if($c_syuzoku[$cardno] ne "카운터"){return 0;}}

	if($syokan eq ""){return 1;}

	if($syokan==10){
		if($cardno==332){if($pat==1 || $pat==2  || $pat==5 || $pat==9 || $pat==10){return 1;}}
		elsif($cardno==1209){if($chudan=~/[12]-0-\d+/){return 1;}}
		elsif($cardno==1001){if($pat==1 || $pat==2  || $pat==5 || $pat==6 || $pat==7){return 1;}}
		elsif($cardno==867 || $cardno==1204){if($pat==1 || $pat==2  || $pat==5 || $pat==6){return 1;}}
		elsif($cardno==334){if($pat==10){return 1;}}
		elsif($cardno==1033){if($pat==9 && (grep(/^$t_cno$/,@seirei) || ($m_koka{$t_cno}=~/^lp/ && $t_cno!=382 && $t_cno!=957))){return 1;}}
		elsif($cardno==1090 && $chudan=~/^[12]-3-\d+-(\d+)/){if($1 ne "player" && $fld_ad[$1]==1){return 1;}}
		elsif($cardno==284){if(($pat==9 || $pat==10) && ($t_cno==728 || $t_cno==634 || $t_cno==805 || $t_cno==872 || $t_cno==637)){return 1;}}
		elsif($cardno==282){if($pat==9 && $t_cno==43){return 1;}}
		elsif($cardno==531){if($pat==9 && $t_cno==85){return 1;}}
		elsif($cardno==637){if($pat==9 && $t_cno==728){return 1;}}
		elsif($cardno==717){if($pat==3 && $t_fld2 ne "player"){return 1;}}
		elsif($cardno==1086 && $chudan=~/^[12]-9-\d+-\d+-\d+:0:\d+-$/){return 1;}
		elsif($cardno==1148 && $chudan=~/^[12]-10-\d+-\d+-\d+:0:(\d+)-$/ && &syu_st($1) eq "드래곤"){return 1;}
	}
	elsif($pat==1){if($syokan==2){return 1;}}
	elsif($pat==2){if($syokan==2){return 1;}}
	elsif($pat==3){if($syokan==3){return 1;}}
	elsif($pat==8){if($syokan==8){return 1;}}
	elsif($pat==9){if($syokan==9){return 1;}}
	return 0;
}

sub chain_chk_mst{
	local($fldno)=$_[0];
	if($pat==3 && $t_fld2 eq $fldno){
		if($fld[$fldno]==1171){return 1;}
		if(($fld[$fldno]==264 || $fld[$fldno]==265 || $fld[$fldno]==266) && $fld_koka[$fldno]!~/used<>/){return 1;}
	}
	if($fld[$fldno]==1071 && $fld_rf[$fldno]!=1 && $pat==9){return 1;}
	if($fld[$fldno]==1107 && $fld_rf[$fldno]!=1 && $pat==9 && $c_syuzoku[$t_cno] eq "통상"){return 1;}
	if($fld[$fldno]==1124 && $fld_rf[$fldno]!=1 && $pat==10 && $c_syuzoku[$t_cno] eq "통상"){return 1;}
	0;
}

sub chain_para_chk{
	@tmp=split(/-/,$chudan);
	$pat=$tmp[1];
	if($pat==1 || $pat==2){$t_fld1=$tmp[2];}
	elsif($pat==3){
		$t_fld1=$tmp[2];$t_fld2=$tmp[3];
		if($t_fld2 eq "player"){$t_damage=$ap_fld[$t_fld1];}
		elsif($fld_ad[$t_fld2]!=1){$t_damage=$ap_fld[$t_fld1];}
		elsif($fld_koka[$t_fld1]=~/meteo/ || $fld[$t_fld1]==932 || $fld[$t_fld1]==1140 || $fld[$t_fld1]==1173 || ($kok[$tmp[0]][57] ne "" && &syu_st($t_fld[1]) eq "드래곤")){$t_damage=$ap_fld[$t_fld1];}
		else{$t_damage="";}
	}
	elsif($pat==9 || $pat==10){$t_cno=$tmp[2];$t_ufldno=$tmp[3];}
}

sub trap_checkj{
	local($i,$flg);
	local($mode)=$_[0];

	if($c_end==1){return;}
	($ts,$pat)=split(/-/,$chudan);

	if($waitj[$ts][$pat] eq ""){
		$chudan="";$pat="";$c_end="";return 0;
	}
	else{
		if($mode!=1){unshift(@chain,$chudan);}
		$c_end=2;&chg_user;
		return 1;
	}
}

sub trap_check{
	local($i,$flg);

	if($c_end==1){return;}
	$ts=3-substr($chudan,0,1);

	&chain_para_chk;
	$flg=0;$huse_ariflg=0;
	if($wait[$ts][$pat] ne "" || $cpu[$ts]==1){$flg=1;}

	for($i=$fw2[$ts];$i<$fw2[$ts]+5;$i++){
		$tcno=$fld[$i];
		if($tcno eq "" || ($fld_rf[$i]!=1 && !(grep(/^$tcno$/,@omoteuse)))){next;}
		$huse_ariflg=1;

		if($c_zokusei[$tcno] ne "함정" || $kok[0][7] ne ""){next;}
		if($tcno==894 && $pat==9){$flg=2;next;}
		if($tcno==566 && $pat==10){$flg=2;next;}
		if($c_syokan[$tcno] eq ""){next;}
		if(&chain_chk($tcno)){$flg=2;last;}
	}
	if($flg!=2){
		for($i=$fw1[$ts];$i<$fw1[$ts]+5;$i++){if(&chain_chk_mst($i)){$huse_ariflg=1;$flg=1;last;}}
	}
	for($i=0;$i<$#{$tehuda[$ts]}+1;$i++){
		if($flg==2){last;}
		$tcno=$tehuda[$ts][$i];
		if($tcno==378 && $pat==3 && $t_damage>0){$huse_ariflg=1;$flg=1;}
		if(($c_syuzoku[$tcno] eq "속공" && $ts==$turn2) || $tcno==687){$huse_ariflg=1;}
		if($hk[19+$ts] ne ""){
			if($c_zokusei[$tcno] ne "함정"){next;}
			if($kok[0][7] ne ""){next;}
			if($tcno==894 && $pat==9){$flg=1;}
			if($tcno==566 && $pat==10){$flg=1;}
			if($c_syokan[$tcno] ne "" && &chain_chk($tcno)){$flg=2;last;}
			$huse_ariflg=1;
		}
	}

	if($huse_ariflg==0){$flg=0;}

	if($flg==0){
		if(&trap_checkj()){return 1;}
		return 0;
	}
	else{
		if($pat==3){
			$fno1 = $t_fld1;$fno2 = $t_fld2;
			$fno1 %=5;$fno1++;$fno2 %=5;$fno2++;
			$tmp="$c_name[$fld[$t_fld1]]:<a href=\"$help#taino\" target=new>$fno1</a>→";
			if($t_fld2 ne "player"){$tmp.="$c_name[$fld[$t_fld2]]:<a href=\"$help#taino\" target=new>$fno2</a>";}
			else{$tmp.="플레이어";}
			&add_msg("null","!$s_d($tmp)");
		}
		elsif($chudan=~/^[12]-9-(\d+)-\d+-(.+)$/ || $chudan=~/^[12]-10-(\d+)-\d+-(.+)$/){
			$tmpst="";$tmpcno=$1;$tmpp=$2;$tmpp=~s/-o(\d+)$//;
			if($tmpcno==901){$tmpst=$c_name[$1];}
			@tmp=split(/-/,$tmpp);
			for($i=0;$i<$#tmp+1;$i++){
				($cno,$basyo,$fno)=split(/:/,$tmp[$i]);
				if($cno eq ""){next;}
				if($basyo==10 || $basyo==11){$tmpst.="$c_name[$cno]와";}
				elsif($basyo==0){
					$tmp=&which_side($fno,1);
					if($fld_rf[$fno]!=1 || $tmp==1){$tmpst.="$c_name[$cno]";}
					else{$tmpst.="세트 몬스터";}
					$fno %=5;$fno++;
					$tmpst.=":<a href=\"$help#taino\" target=new>$fno</a>와";
				}
			}
			$tmpst=~s/와$//;
			if($tmpst ne ""){&add_msg("null","!$ts(대상…$tmpst)");}
		}
		unshift(@chain,$chudan);
		&chg_user;
		return 1;
	}
}

sub not_taisyo{			#「대상이 되지 않는다」의 체크
	local($fldno)=$_[0];

	if($c_zokusei[$fld[$fldno]] eq "신" || ($kok[0][1] ne "" && $c_syuzoku[$fld[$fldno]] eq "드래곤")){
		&add_msg("null","<b>(이 몬스터는 함정의 대상이 되지 않는다!)</b>");
		return 1;
	}
	return 0;
}

1;
