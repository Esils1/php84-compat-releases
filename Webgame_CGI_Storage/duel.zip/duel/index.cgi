#!/usr/bin/perl

require "data.lib";

@pfldata=("shohai");

&get_input;
&get_ini2;
&get_ini;

if($G{'player2'} eq ""){$G{'player2'}=1;}

open(IN,"kosin.txt");
$kodat=<IN>;$kost=$kodat;$kodat=~s/<br>//;
while(<IN>){$kost.=$_;}


@tmp=split(":",$F{'shohai'});
$win_a=0;$lose_a=0;$draw_a=0;
for($i=0;$i<$#tmp+1;$i++){
	($win,$lose,$draw)=split(/-/,$tmp[$i]);
	$win_a+=$win;$lose_a+=$lose;$draw_a+=$draw;
}


$selst[$G{'player1'}]=" selected";
$selst2[$G{'player2'}]=" selected";
$selst3[$G{'rule'}]=" selected";

print "Set-Cookie:id=$id;expires=WED, 28-JUL-2005 08:00:00:\n";
print "Content-type:text/html; charset=utf-8\n\n";

if($id=~/^\d+$/ && length($id)<6){$tesst="듀얼네임을 반각영수로 등록해 주세요. <br>숫자인 채에서도 놀 수 있습니다만 , 다른 사람이 같은 듀얼네임으로 액세스 하면 동작이 이상해지는 일이 있습니다. <br>";}

print<<"_EOF_";
<html>
<title>이 제목이 보이시는 분은 새창을 띄우신 분입니다. 다중플레이는 권하지않습니다.</title>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=utf-8">
<body bgcolor=#fffff0 background="embak.gif">
<center>
<FONT SIZE=+3 color=red><B>★ 유 희 왕 ★</b></font><br>
<FONT SIZE=+1><B>버섯서버의 유희왕</b></font><br>
<br>
Last Update 20$kodat<br>
</center>
<hr>
<center>
<form action="index.cgi">
듀얼네임
<input type=text name=id value=$id size=8>
<input type=submit value="등록">
<a href="rename.cgi?id=$id">변경하기</a>
</form>
<a href="seiseki.cgi?id=$id">성적</a>　$win_a승　$lose_a패　$draw_a무승부<br>
<br>
$tesst
<hr width=80%>
<h3><a href="taisen.cgi?id=$id">○넷 플레이○</a></h3>
<hr width=80%>
<br>
<form action="duel.cgi">
<input type=hidden name=id value=$id>
<input type=hidden name=start value=on>
플레이어
<select name="player1">
_EOF_

for($i=0;$i<$#name+1;$i++){
	if($i==9 || $i==13 || $i==25){next;}
	print "<option value=$i$selst[$i]>$name[$i]\n";
}
print "</select>　VS　<select name=\"player2\">\n";
for($i=0;$i<$#name+1;$i++){
	if($i==9 || $i==13 || $i==25){next;}
	print "<option value=$i$selst2[$i]>$name[$i]\n";
}
print<<"_EOF_";
<option value=9$selst2[9]>$name[9]
</select>
CPU 
<br>
<select name="rule">
<option value=0$selst3[0]> 신전문가 룰
<option value=1$selst3[1]>쥬니어 룰
</select>
<br>
<br>
<FONT SIZE=+2><B>
<input type=submit value="CPU전">
</b></font>
<br>
</form>
<hr width=80%>
<br>
<form action="deck.cgi">
<input type=hidden name=id value=$id>
<FONT SIZE=+2><B>
<input type=submit value="덱 구축">
</b></font><br>
</form>
<br>
<hr width=80%>
<br>
<FONT SIZE=+2><B>
<a href="$help" target=new>플레이 방법</a></b>
</font>
　<a href="$ahelp" target=new>현재 사용 가능한 마법·함정·효과</a>
<br>
<hr width=80%>
<br clear=all>
</center>
<br>
<hr>
<center>
(c)타카하시 가즈키 스튜디오·다이스/<a href="http://www.jump.ne.jp/">슈우에이샤</a>/<a href="http://www.yugioh-card.com/">코나미</a><br>
<br>
<br>
<FONT SIZE=-1><a href="http://www.big.or.jp/~rufus/gaterar/duel/index.html">CGI배포처</a>/<a href="http://FusionX.wf.to">FusionX의 홈</a></font><br>
</body></html>
_EOF_

sub get_ini2{	#스타트시 읽기

	$tmpflg=0;
	if(-r "tmp/".$id."_pfl"){
		open(PFL,"tmp/".$id."_pfl");
	}

	while(<PFL>){
		chop;
		($KEY,$VAL) = split(/\t/);
		$F{$KEY} = $VAL;
	}
	close(PFL);

}

sub get_ini{

	if(-r "tmp/$id"){
		open(PFL,"tmp/$id");
	}
	else{
		return;
	}

	while(<PFL>){
		chop;
		($KEY,$VAL) = split(/\t/);
		if($G{$KEY} eq ""){	#파라미터 인도를 우선
			$G{$KEY} = $VAL;
		}
	}
	close(PFL);
}

sub get_input{
	if (length($ENV{'QUERY_STRING'}) > 0) {
		$INPUT = $ENV{'QUERY_STRING'};
	}
	elsif (length($ENV{'CONTENT_LENGTH'}) > 0) {
		read(STDIN, $INPUT, $ENV{'CONTENT_LENGTH'});
	}
	else {
		while ($TMP[0] = <STDIN>) {
			$INPUT .= $TMP[0];
		}
	}

	$INPUT =~ s/\&+/\&/g;
	$INPUT =~ s/#.+//;
	@TMP = split('&', $INPUT);
	for ($i = 0; $i <= $#TMP; ++$i) {
		($KEY, $VAL) = split('=', $TMP[$i]);
		$VAL =~ tr/+/ /;
		$VAL =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
		if($VAL ne ""){$F{$KEY}=$VAL;}
	}

	$cookie=$ENV{'HTTP_COOKIE'};
	if($F{'id'} ne ""){$id = $F{'id'};}
	elsif($cookie=~/id=(.+)/){$id=$1;$id=~s/\;.+//;}

	if($id eq ""){$id=$$;}
	$id=~s/\.//g;
	$id=~s/\///g;
	$id=~s/<//g;
}
