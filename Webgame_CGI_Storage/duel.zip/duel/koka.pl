sub select_syori{		#효과 해결후의 처리
	local($i);
	&chg_user;
	@res_s=@select;

	if($S{'n'} eq "ousyu"){
		if(&cpu_get_saikyo($S{'s'},$S{'j'},"",1)){return;}
		if($S{'p'}==792){
			$tcno=$tehuda[$s_d][$res_s[0]-100];$tehuda[$s_d][$res_s[0]-100]="";
			if($tep[$s_d][$res_s[0]-100] ne ""){$tsno=$s_a;}else{$tsno=$s_d;}
			&add_msg("null","<b>$pn[$s_d]의 것$c_name[$tcno]을 덱에 되돌렸다! </b>");
			push(@{$deck[$tsno]},$tcno);
			&shuffle(*deck,$tsno);
		}
		else{
			if($S{'p'}==789){&add_msg("null","<b>$pn[$s_d]의$c_name[$tehuda[$s_d][$res_s[0]-100]]를 압수했다! </b>");}
			elsif($S{'p'}==1192){&add_msg("null","<b>$pn[$s_d]의$c_name[$tehuda[$s_d][$res_s[0]-100]]를 훔쳤다! </b>");}
			else{&add_msg("null","<b>$c_name[$tehuda[$s_d][$res_s[0]-100]]의 혼백은 봉신대에 날았다! </b>");}
			&go_boti2($res_s[0]-100,1,2);
			&maryoku(17,1);
		}
	}
	elsif($S{'n'} eq "lb"){
		if(&ext_chk()){return;}
		if(&cpu_get_saikyo($S{'s'},$S{'j'})){return;}
		if(&akichk){return;}
		&put_field($res_s[0]);
		&add_msg("null","$pn[$s_a]의 대표는 --<b>$c_name[$fld[$nf0]]! </b>");
		if($S{'p'}!=99){push(@chain2,"$s_a-5-1211-$nf0-$S{'p'}");}
	}
	elsif($S{'n'} eq "soul"){
		if(&cpu_get_saikyo($S{'s'},$S{'j'})){return;}
		&add_msg("null","악마의 힘으로$c_name[$boti[$s_d][$res_s[0]-300]]의 영혼을 부수었다! ");
		$boti[$s_d][$res_s[0]-300]="";&del_null(*boti,$s_d);
	}
	elsif($S{'n'} eq "vamp"){
		if(&cpu_get_saikyo($S{'s'},$S{'j'},"",1)){return;}
		$tcno=$deck[$s_a][$res_s[0]-400];$deck[$s_a][$res_s[0]-400]="";
		&add_msg("null","$c_name[$tcno]을(를) 버렸다! ");
		&del_null(*deck,$s_a);
		@sutehuda=($tcno);&arr_to_boti(*sutehuda,0);
	}
	elsif($S{'n'} eq "danatu"){
		if($F{'options'}==1 || $fld[$S{'p'}] eq ""){return;}
		&add_msg($pn[$s_a],"라이프를800지불해 --");
		&add_msg("null","<b>왕궁의 탄압! </b>　$c_name[$fld[$S{'p'}]]을(를) 파괴! ");
		$lp[$s_a]-=800;&chk_lp;&go_boti($S{'p'});
	}
	elsif($S{'n'} eq "bubble"){
		$cou=&maisu_count(0)+&maisu_count(2)+&maisu_count(6);$cou2=0;
		&cpu_get_saikyo($S{'s'},$S{'j'},$cou-5,1);
		for($i=0;$i<$#res_s+1;$i++){
			if($cou<6){last;}
			if($res_s[$i]<50){&add_msg("null","$c_name[$fld[$res_s[$i]]]을(를) 버렸다. ");&go_boti($res_s[$i],3);}
			else{&add_msg("null","$c_name[$tehuda[$s_a][$res_s[$i]-50]]을(를) 버렸다. ");&go_boti2($res_s[$i]-50);$cou2++;}
			$cou--;
		}
		if($cou2>0){&maryoku(17,0,$cou2);}
		if($cou>5){&revice_syori;}
	}
	elsif($S{'n'} eq "hukkatu"){
		if(&akichk()){return;}
		if($S{'p'}=~s/^v//){$tbno=$s_d;$sup=300;}else{$tbno=$s_a;$sup=200;}
		if(&ext_chk($S{'p'})){return;}

		for($i=0;$i<$#{$boti[$tbno]}+1;$i++){if($boti[$tbno][$i]==$S{'p'}){last;}}
		if($i==$#{$boti[$tbno]}+1){return;}
		&put_field($i+$sup);&del_null(*boti,$tbno);
		$fld_ad[$nf0]=$F{'options'};

		if($tbno==$s_d){&add_msg("null","뱀파이어·베이비에게 물렸다$c_name[$S{'p'}]는 하인이 되었다…! ");$fld_koka[$nf0].="moto_$s_d<>teni_$s_a<>";}
		elsif($S{'p'}==1174){$fld[$nf0]=1224;$fld_koka[$nf0].="ptr:-500:-200:0<>";&add_msg("null","달러·드라는 목을 하나 잃어 부활했다! ");}
		else{&add_msg("null","뱀파이어·로드는 관으로부터 일어났다! ");}
		&hosatu(&usertoside($tbno));
	}
	elsif($S{'n'} eq "kairai"){
		$tmpno=&getf_res($S{'p'});
		$cou=0;for($i=0;$i<$#res_s+1;$i++){$cou+=&lv_st($fld[$res_s[$i]],$res_s[$i]);}
		if($cou!=$c_lv[$tmpno]){&add_msg("null","!$s_a(레벨수의 합계가 다른)");&revice_syori;return;}
		$tmp="";for($i=0;$i<$#res_s+1;$i++){$tmp.=$c_name[$fld[$res_s[$i]]]."과";&syometu($res_s[$i]);}
		$tmp=~s/와$//;&add_msg("null","$tmp를 제외해 --");
		&fld_chk();&put_field($S{'p'});
		&add_msg("null","<b>영혼을$c_name[$fld[$nf0]]에 불어왔다! </b>");
		&del_null(*boti,$s_a);
		$fld_ad[$nf0]=$F{'options'};
	}
	elsif($S{'n'} eq "kusarimai"){
		if(&cpu_get_saikyo($S{'s'},$S{'j'})){return;}
		$tcno=$tehuda[$s_d][$res_s[0]-100];$tehuda[$s_d][$res_s[0]-100]="";
		&add_msg("null","<b>$c_name[$tcno]을(를) 빼앗았다! </b>");
		push(@{$tehuda[$s_a]},$tcno);
		if($tep[$s_d][$res_s[0]-100] eq ""){$tep[$s_a][$#{$tehuda[$s_a]}]="a";}
		if($player[$s_a]==4 && $player[$s_d]==21){
			&add_msg("마리크","...　당신이 죽을 때는 괴로움으로 장식해 주지...");
			&add_msg("메이","재미있는 일을 말하는군...그 전에...<br>니가 지옥에 갈껄! ");
		}
	}
	elsif($S{'n'} eq "exchange2"){
		&cpu_get_saikyo($S{'s'},$S{'j'});
		$tcno1=$tehuda[$s_d][$res_s[0]-100];$tehuda[$s_d][$res_s[0]-100]="";
		&add_msg("null","$pn[$s_a]은(는)$c_name[$tcno1]을 선택했다. <br>카드를 교환했다. ");
		$tcno2=$tehuda[$s_a][$S{'p'}];$tehuda[$s_a][$S{'p'}]="";
		push(@{$tehuda[$s_a]},$tcno1);
		push(@{$tehuda[$s_d]},$tcno2);
		if($tep[$s_d][$res_s[0]-100] eq ""){$tep[$s_a][$#{$tehuda[$s_a]}]="a";}
		if($tep[$s_a][$S{'p'}] eq ""){$tep[$s_d][$#{$tehuda[$s_d]}]="a";}
	}
	elsif($S{'n'} eq "exchange1"){
		if($cpu[$s_a]==1){$seast=$S{'s'};$jokenst=$S{'j'};&card_search;}
		if($player[$s_a]==19 && $player[$s_d]==1 && grep(/^155$/,@{$tehuda[$s_d]})){
			$tmpno=&getf_res($res_s[0]);
			if($cpu[$s_a]!=1 && $tmpno==155){}
			elsif($cpu[$s_a]==1 && $tmpno==155 && $res_s[1] eq ""){}
			else{
				if($cpu[$s_a]==1){$res_s[0]=$res_s[1];}
				&add_msg("마리크","(하하하하하<br>실력이 미숙한 것은 알고 있었지만 여기까지! <br>조이...붉눈이다!　붉눈을 받는다! )");
				&add_msg("조이","에 에!　당연히! 이 카드가 있으면 무서운게 없어!<br>‥‥‥‥. <br>‥‥‥‥. ‥‥‥‥. <br>구…　구…　……! <br>(어째서 잡히고 …　어째서…)");
				$joflg=1;
			}
		}

		$tmp=$res_s[0]-100;
		&add_msg("null","$pn[$s_a]는$c_name[$tehuda[$s_d][$tmp]]을 선택했다. ");
		$seast="9999000001";$tmp_syorip="<>i-$s_d<>n-exchange2<>g-1<>p-$tmp";
		&go_select_syori;
		if($joflg==1){
			&add_msg("유희","조이...　나는 분명하게 알았다... <br>너는 진정한 결투자의 마음을 잃지 않았단 것을...");
			&add_msg("조이","파는 키!　우다우다 말해 그럼! ");
			&add_msg("유희","그리고 확신했다... <br>이 붉은눈의 카드라면!　너의 마음을 상기시킬 수가 있다 라고! ");
			&add_msg("조이","에...　훌륭하구나...");
		}
	}
	elsif($S{'n'} eq "saikinheiki"){
		if($cpu[$s_a]==1){$seast=$S{'s'};$jokenst=$S{'j'};&card_search;}
		if($#res_s+1<$S{'p'}){&add_msg("null","!$s_a(카드를$S{'p'}장 선택해 줘)");&revice_syori;return;}
		undef(@sutehuda);$tmpst="";
		for($i=0;$i<$S{'p'};$i++){
			push(@sutehuda,$deck[$s_a][$res_s[$i]-400]);
			$tmpst.="$c_name[$deck[$s_a][$res_s[$i]-400]]와";
			$deck[$s_a][$res_s[$i]-400]="";
		}
		$tmpst=~s/와$//;&add_msg("null","$tmpst는 세균에 시달려 묘지에 떨어졌다! ");
		&del_null(*deck,$s_a);&shuffle(*deck,$s_a);
		&arr_to_boti(*sutehuda,0);
	}
	elsif($S{'n'} eq "selketo2"){
		($tmp1,$tmp2)=split(/_/,$S{'p'});
		$s_sitei[0]=$tmp2;&chg_user;
		&fld_chk();
		$fld[$nf0]=1099;
		$fld_koka[$nf0]="rar_$tmp1<>";
		$fld_ad[$nf0]=0;$fld_rf[$nf0]=0;
		&add_msg("리시드","봐라 , 신의 모습을! ");
		&rarcopy;
	}
	elsif($S{'n'} eq "selketo"){
		if(&akichk()){return;}
		if(&cpu_get_saikyo($S{'s'},$S{'j'})){return;}
		if(&getf_res($res_s[0])==1099 && $player[$s_a]==20 && $room eq ""){
			&add_msg("리시드","성수를 생지에 --우리 생명의 조각과 함께 바친다! <br>성스러운 궤에 자 타앵 신의 영혼!　지금 , 그 모습과 함께 소생해라! <br><b>출로!　라의 익신룡! </b>");
			&add_msg("조이","(˚○˚;");
			&add_msg("카이바","(˚▽˚)");
			&add_msg("유희","(˚○˚;");
			$syori[0]="2<>i-2<>n-selketo2<>p-".$S{'p'}."_".$s_a;
			$not_control=1;&make_msg;$act="duel.cgi";
			undef(@chain2);
			&put_screen2;
		}
		&put_field($res_s[0]);
		$cardno=$fld[$nf0];
		if($c_syokan[$cardno]==1){$fld_koka[$nf0].="irr<>";}
		if($cardno==925 || $cardno==1099){$fld_koka[$nf0].="rar_$S{'p'}<>";}
		&add_msg("null","<b>성궤로부터$c_name[$cardno]가 풀어 발해졌다! </b>");
		&del_null(*deck,$s_a);&del_null(*yugo,$s_a);
	}
	elsif($S{'n'} eq "teni"){
		&cpu_get_saikyo($S{'s'},$S{'j'},"",1);
		&ctrl_chg($res_s[0],$S{'p'});$a_m[$res_s[0]]=2;$a_m[$S{'p'}]=2;
	}
	elsif($S{'n'} eq "zouen"){
		&cpu_get_saikyo($S{'s'},$S{'j'});
		&add_msg("null","<b>$c_name[$deck[$s_a][$res_s[0]-400]]을(를) 패에 불렀다! </b>");
		push(@{$tehuda[$s_a]},$deck[$s_a][$res_s[0]-400]);
		$deck[$s_a][$res_s[0]-400]="";&del_null(*deck,$s_a);&shuffle(*deck,$s_a);
	}
	elsif($S{'n'} eq "yuigon_chk"){
		if($F{'options'}==0 || $cpu[$s_a]==1){push(@chain2,"$s_a-5-645");}
		else{$hk[14]++;}
	}
	elsif($S{'n'} eq "itami"){
		if($cpu[$s_a]==1){
			$seast=$S{'s'};$jokenst="";&card_search;
			if($#res_s<0){return;}
			@res_s2 = sort ap_cre_res @res_s;$res_s[0]=$res_s2[$#res_s2];
		}
		&add_msg("null","$pn[$s_a]은(는)$c_name[$fld[$res_s[0]]]을 생지에 바쳤다. ");
		&go_boti($res_s[0],4);
	}
	elsif($S{'n'} eq "maharagi"){
		if($F{'options'} eq "0" && $cpu[$s_a]!=1){
			$tcno=$deck[$s_a][0];
			&add_msg("null","!$s_a($c_name[$tcno]을(를) 덱의 맨 밑에 되돌린다)");
			shift(@{$deck[$s_a]});push(@{$deck[$s_a]},$tcno);
		}
	}
	elsif($S{'n'} eq "fleed2"){
		push(@{$tehuda[$s_a]},$deck[$s_a][$res_s[0]-400]);
		&add_msg("null","후리드는$c_name[$deck[$s_a][$res_s[0]-400]]을 불렀다. ");
		$deck[$s_a][$res_s[0]-400]="";&del_null(*deck,$s_a);&shuffle(*deck,$s_a);
		$phase=1;
	}
	elsif($S{'n'} eq "fleed1"){
		if($F{'options'} eq "0" && $cpu[$s_a]!=1){
			&add_msg("null","<b>무패 장군 후리드의 효과 발동! </b>");
			$seast="9999000000001";$jokenst='$c_syuzoku[$cardno] eq "전사" && $c_lv[$cardno]<5';
			$tmp_syorip="<>i-$s_a<>n-fleed2<>g-1";&go_select_syori;
		}
	}
	elsif($S{'n'} eq "tydra"){
		if($F{'options'}==1 || $cpu[$s_a]==1){
			&add_msg("null","생지가 없기 때문에 , 소생은 무효. ");
			&syometu($S{'p'});push(@{$boti[$s_a]},1139);
		}
		else{
			if($#res_s<0 || $fld[$res_s[0]] eq "" || &ikenie_chk){&revice_syori;return;}
			if($res_s[0]==$S{'p'}){&add_msg("null","!$s_a(자신을 제물로 할 수 없다)");&revice_syori;return;}
			&add_msg("null","$c_name[$fld[$res_s[0]]]을 생지에 바쳤다. ");
			&go_boti($res_s[0],4);
		}
	}
	elsif($S{'n'} eq "silkhat"){
		$go_hit=2;
		if(&go_card_search){return;}
		if($fld_rf[$S{'p'}]!=1){$name="$c_name[$fld[$S{'p'}]]와(과)";}
		else{$name="몬스터와";}
		$rann=rand;$rann=int($rann*3);$cou=0;
		$mstno=$fld[$S{'p'}];$kokasil=$fld_koka[$S{'p'}];$rfsil=$fld_rf[$S{'p'}];
		$fld[$S{'p'}]="";
		if($chain[0]=~/([12])-3-\d+-(\d+)/ && $2==$S{'p'}){$chain[0]="$1-3-null";}
		
		for($i=0;$i<3;$i++){
			&fld_chk();
			if($rann==$i){
				$fld[$nf0]=$mstno;
				$fld_koka[$nf0]=$kokasil;
				&chg_koka($S{'p'},$nf0);
				$fld_ad[$nf0]=1;$fld_rf[$nf0]=1;
				if($kok[0][3] ne ""){$fld_rf[$nf0]=$rfsil;}
			}
			else{
				$fld[$nf0]=$deck[$s_a][$res_s[$cou]-400];
				$deck[$s_a][$res_s[$cou]-400]="";
				&ext_set($nf0,1);
				$name.="$c_name[$fld[$nf0]]와";
				$cou++;
			}
			$fld_koka[$nf0].="silkhat<>";
		}
		&del_null(*deck,$s_a);
		$name=~s/와$//;&add_msg("null","$name를 비단 모자에 숨겼다! ");
	}
	elsif($S{'n'} eq "bstk"){
		$tmp=$S{'c'};$tmp=~s/^3-\d+-[^-]+-*//;@bstk=split(/-/,$tmp);
		&cpu_get_saikyo($S{'s'},$S{'j'});

		if(($F{'options'} eq "0" || $cpu[$s_a]==1) && $res_s[0] ne ""){$bstk[$S{'p'}]=$res_s[0];}
		elsif($F{'options'} eq "0"){}
		else{$bstk[$S{'p'}]=999;}
	}
	elsif($S{'n'} eq "hakaana"){
		if(&akichk()){return;}
		if(&ext_chk()){return;}
		if(&cpu_get_saikyo($S{'s'},$S{'j'})){return;}

		if($S{'p'} eq ""){$rf=1;$fld_ad[$nf0]=1;}
		elsif($S{'p'}==1){$rf=0;$fld_ad[$nf0]=$F{'options'};}
		else{$rf=$F{'options'};$fld_ad[$nf0]=$F{'options'};}
		$tcno=$boti[$s_a][$res_s[0]-200];
		if($rf==1 && ($kok[0][3] ne "" || $c_syokan[$tcno]==3 || $c_syokan[$tcno]==4)){$rf=0;}
		if($rf!=1 && &ext_chk("","",$tcno)){return;}
		&put_field($res_s[0],$rf);
		&add_msg("null","<b>무덤으로부터$c_name[$tcno]가 부활했다! </b>");
		&hosatu(0);
		if($tcno==1139){&tyrant_sosei;}
	}
	elsif($S{'n'} eq "drain"){
		if($F{'options'}==1 || $cpu[$s_a]==1){
			if($chain[0]!~/([12]-9-)(\d+)-(\d+)/){return;}
			&add_msg("null","마력이 부족하기 때문에 ,$c_name[$2]는 발동되지 않았다! ");
			&go_boti($3);
			$chain[0]=$1;
		}
		else{
			if($#res_s<0){&revice_syori;return;}
			&add_msg("null","$c_name[$tehuda[$s_a][$res_s[0]-50]]을(를) 버려 마력을 보급했다. ");
			&go_boti2($res_s[0]-50);&maryoku(17);
		}
	}
	elsif($S{'n'} eq "thundra"){
		for($i=0;$i<$#res_s+1 && $i<2;$i++){
			&add_msg("null","$pn[$s_a]은(는) 썬더 드래곤을 패에 가세했다. ");
			push(@{$tehuda[$s_a]},371);
			$deck[$s_a][$res_s[$i]-400]="";
		}
		&del_null(*deck,$s_a);
	}
	elsif($S{'n'} eq "cyber"){
		if($cpu[$s_a]==1){undef(@res_s);
			for($i=$fw1[$s_a];$i<$fw1[$s_a]+$fldw;$i++){if($c_koka[$fld[$i]]==7){push(@res_s,$i);}}
		}
		for($i=$fw1[$s_a];$i<$fw1[$s_a]+5;$i++){
			if($fld[$i] eq ""){next;}
			if(!(grep(/^$i$/,@res_s)) || $F{'options'}==1){&ext_set($i);}
			else{&ext_set($i,1);}
		}
	}
	elsif($S{'n'} eq "sajin"){
		if(&akichk2()){return;}
		if($cpu[$s_a]==1){return;}
		if(&kinsi_chk($res_s[0]-50)){return;}

		&put_field($res_s[0],1);
		$a_m[$nf1]=1;
		&add_msg("null","$pn[$s_a]은(는) 마법·함정 카드를 1장 세트 했다. ");
	}
	elsif($S{'n'} eq "m_gorosi"){
		if($fld[$S{'p'}] eq ""){}
		elsif($F{'options'}==1 || $cpu[$s_a]==1){
			&add_msg("null","(아군 살인의 여자 기사를 파괴한다)");
			&go_boti($S{'p'});&get_apdp_fld;
		}
		else{
			if($#res_s<0 || $fld[$res_s[0]] eq ""){&revice_syori;return;}
			if($res_s[0]==$S{'p'}){&add_msg("null","!$s_a(자신을 제물로 할 수 없다)");&revice_syori;return;}
			&add_msg("null","아군 살인의 여자 기사는 , 아군의 것$c_name[$fld[$res_s[0]]]을 죽였다. ");
			&go_boti($res_s[0],4);
		}
	}
	elsif($S{'n'} eq "kilasne"){
		if($F{'options'}==0 || $cpu[$s_a]==1){
			for($i=0;$i<$#{$boti[$s_a]}+1;$i++){
				if($boti[$s_a][$i]==735){$boti[$s_a][$i]="";push(@{$tehuda[$s_a]},735);last;}
			}
			if($i<$#{$boti[$s_a]}+1){
				&add_msg("null","킬러·뱀은$pn[$s_a]의 패으로 돌아왔다. ");
				&del_null(*boti,$s_a);
			}
		}
	}
	elsif($S{'n'} eq "cost"){
		$cost_tmp=$cost{$fld[$S{'p'}]};
		if($cpu[$s_a]==1){
			if($lp[$s_a]>$cost_tmp*2 && $fld[$S{'p'}]==1000){$F{'options'}=0;}
			else{$F{'options'}=1;}
		}
		if($fld[$S{'p'}] eq ""){return;}
		if($F{'options'}==0){
			&add_msg("null","($c_name[$fld[$S{'p'}]]에$cost_tmp의 라이프를 지불했다)");
			$lp[$s_a]-=$cost_tmp;&chk_lp;
		}
		else{
			&add_msg("null","($c_name[$fld[$S{'p'}]]를 파괴한다)");
			&go_boti($S{'p'});&get_apdp_fld;
		}
	}
	elsif($S{'n'} eq "kuju2"){
		if($#res_s!=0 && $cpu[$s_a]!=1){
			&add_msg("null","!$u_side(카드를 1장 선택한다)");
			&revice_syori;
			return;
		}

		@tmp=split(/ \|\| /,$S{'j'});undef(@koho);
		for($i=0;$i<$#tmp+1;$i++){
			$tmp[$i]=~s/\$res_si==//;
			push(@koho,$tmp[$i]);
		}
		if($cpu[$s_a]==1){
			$rann=rand;$rann=int($rann * 5);$res_s[0]=$koho[$rann];
		}

		push(@{$tehuda[$s_d]},$deck[$s_d][$res_s[0]-500]);
		&add_msg("null","$pn[$s_a]는$c_name[$deck[$s_d][$res_s[0]-500]]을 선택했다. ");
		&add_msg("null","$pn[$s_d]은(는)$c_name[$deck[$s_d][$res_s[0]-500]]을 패에 가세했다. ");
		$deck[$s_d][$res_s[0]-500]="";

		undef(@sutehuda);
		for($i=0;$i<$#koho+1;$i++){
			if($koho[$i]==$res_s[0]){next;}
			push(@sutehuda,$deck[$s_d][$koho[$i]-500]);
			$deck[$s_d][$koho[$i]-500]="";
		}

		&del_null(*deck,$s_d);
		&shuffle(*deck,$s_d);
		&arr_to_boti(*sutehuda,1,1);
	}
	elsif($S{'n'} eq "kuju"){
		if($cpu[$s_a]==1){@res_s=(400,401,402,403,404);}
		if($#res_s!=4){
			&add_msg("null","!$u_side(카드를 5장 선택한다)");
			&revice_syori;
			return;
		}

		$jokenst="";$tmpst="";
		for($i=0;$i<$#res_s+1;$i++){
			$tmpst.=$c_name[$deck[$s_a][$res_s[$i]-400]]."와<br>";
			$tmp=$res_s[$i]+100;
			$jokenst.=' || $res_si=='.$tmp;
		}
		$jokenst=~s/^ \|\| //;$tmpst=~s/와<br>$//;
		&add_msg("null","$pn[$s_a]는$tmpst을 선택했다. ");

		$seast="99990000000001";$tmp_syorip="<>i-$s_d<>n-kuju2<>g-1";
		&go_select_syori;
	}
	elsif($S{'n'} eq "t_sute"){
		&cpu_sutehuda;
		$tcou=&maisu_count(6);if($tcou==0){return;}
		if($S{'p'}=~s/a$//){$method=2;}else{$method="";}
		if($S{'p'}=~s/h$//){$sst="남동생의 악마가 ,$pn[$s_a]의";}else{$sst="$pn[$s_a]는";}
		if($#res_s+1<$S{'p'} && $#res_s+1<$tcou && $cpu[$s_a]!=1){
			&add_msg("null","!$s_a(카드패를$S{'p'}장 선택한다)");
			&revice_syori;
			return;
		}
		for($i=0;$i<$#res_s+1 && $i<$S{'p'};$i++){
			if($i==0){$ses=1;}else{$ses="";}
			&add_msg("null","$sst$c_name[$tehuda[$s_a][$res_s[$i]-50]]를 버렸다. ");
			&go_boti2($res_s[$i]-50,0,$method,$ses);&maryoku(17);
		}
	}
	&get_apdp_fld;
}

sub use_koka_1{
	local($cardno)=$_[0];
	undef(%chk);
	$joken_sflg=1;
	$tmp_syorip.="<>c-1-$F{'putcardno'}";

	if($cardno==1095){
		if($cpu[$s_a]!=1){
			$flg=0;
			for($i=0;$i<2;$i++){if($fld[$nie[$i]]==993 || $fld[$nie[$i]]==994){$flg=1;}}
			if($flg==0){&add_msg("null","!$s_a(카스드·규라나 메르키드 사면짐승을 생지에 바친다)");return 1;}
			$yonie=2;
		}
		else{
			$seast="99921";$jokenst='$cardno==993 || $cardno==994';&card_search;
			if($#res_s<0){return 1;}
			$nie[0]=$res_s[0];
			if(&cpu_get_saikyo($seast,'$res_si!='.$res_s[0])){return 1;}
			$nie[1]=$res_s[$#res_s];$yonie=2;
		}
	}
	elsif($cardno==1064 || $cardno==1045 || $cardno==1046 || $cardno==1047 || $cardno==1048 || $cardno==1065){
		if($hk[8] eq ""){$seast="99930000001";}
		else{$seast="99931";}
		if($cardno==1064){$jokenst='$c_syuzoku[$cardno] eq "악마"';}
		else{$jokenst='$c_zokusei[$cardno] eq "'.$c_zokusei[$cardno].'"';}
		$tmp_syorip.="<>m-(몬스터를 제외한다)";
		if($cardno==1064){$go_hit=3;}
		elsif($cardno==1045){$go_hit=2;}
		else{$go_hit=1;}
		$go_msg="제외 몬스터가 부족하다. ";
		if(&go_card_search){return 1;}
		if($cpu[$s_a]==1){
			@res_s2 = sort ap_cre_res @res_s;undef(@res_s);
			for($i=0;$i<$go_hit;$i++){push(@res_s,$res_s2[$#res_s2-$i]);}
		}

		$str="";
		for($i=0;$i<$#res_s+1;$i++){
			if($res_s[$i]<50){$str.=$c_name[$fld[$res_s[$i]]]."(와)과";&syometu($res_s[$i]);}
			else{
				$tmp=$boti[$s_a][$res_s[$i]-200];$tmp=~s/_i$//;
				$str.=$c_name[$tmp]."와";
				$boti[$s_a][$res_s[$i]-200]="";
			}
		}
		$str=~s/와$//;&add_msg("null","$str를 없애 --");&del_null(*boti,$s_a);
		$yonie=0;
	}
	elsif($cardno==745){
		$seast="999210001";$jokenst='$cardno==740 || $cardno==741 || $cardno==744';
		$tmp_syorip.="<>m-(자석의 전사를 제물로 바친다)";
		$go_hit=3;$go_msg="자석의 전사가 부족하다. ";
		if(&go_card_search){return 1;}

		$flg="";
		for($i=0;$i<$#res_s+1 && $i<3;$i++){
			if($res_s[$i]<50){$chk{$fld[$res_s[$i]]}=1;$flg=1;}
			else{$chk{$tehuda[$s_a][$res_s[$i]-50]}=1;}
		}
		if($flg!=1 && &akichk()){return 1;}

		if($chk{740} ne "" && $chk{741} ne "" && $chk{744} ne ""){
			for($i=0;$i<3;$i++){
				if($res_s[$i]<50){&go_boti($res_s[$i],4);}
				else{&go_boti2($res_s[$i]-50,0,3);}
			}
		}
		else{
			&add_msg("null","!$s_a(자석의 전사α,β,γ가 지정되어 있지 않다)");return 1;
		}
	}
	elsif($cardno==669){
		$yonie=3;
		for($i=0;$i<3;$i++){$chk{$fld[$nie[$i]]}=1;}
		if($chk{"264"}!=1 || $chk{"265"}!=1 || $chk{"266"}!=1){
			&add_msg("null","!$s_a(3체의 악마를 제물로 바친다)");
			return 1;
		}
		$yonie=3;
	}
	elsif($cardno==207){
		&add_msg("null","!$s_a(「만화경」의 힘으로 밖에 필드에 낼 수 없어)");
		return 1;
	}
	elsif($cardno==272 || $cardno==319 || $cardno==724){
		if($cardno==272){$sinka=2;}
		elsif($cardno==319){$sinka=4;}
		else{$sinka=6;}

		if($fld[$nie[0]]!=213 || $fld_koka[$nie[0]]!~/_mayu(\d+)/){
			&add_msg("null","!$s_a(진화의 고치에 들어간 꼬마 모스를 제물로 바친다)");
			return 1;
		}
		elsif(($turn-$1)/2<$sinka){
			&add_msg("null","!$s_a(꼬마 모스는$sinka턴 진화하지 않으면 안된다)");
			return 1;
		}
		else{
			&add_msg("null","진화한 꼬마 모스는 고치를 찢었다! ");
			$yonie=1;
		}
	}
	elsif($cardno==1027 || $cardno==721 || $cardno==722){
		&add_msg("null","!$s_a(조건을 채운 필드의 몬스터로 「효과」를 사용해 줘)");
		return 1;
	}
	elsif($cardno==914){
		$cou1=&maisu_count(0);
		$cou2=&maisu_count(1);
		if($cou2-$cou1<2){&add_msg("null","!$s_a(몬스터수의 조건을 채우지 않아)");return 1;}
		&add_msg("null","<b>마도 텔레포트! </a>");
	}
	elsif($cardno==1170){
		$seast="90191";$jokenst='$cardno==945';$go_hit=1;
		if(&go_card_search){return 1;}
		&add_msg("null","빅크바이파는 파워 캅셀을 취했다! ");
	}
	else{&add_msg("페가수스","!$s_a(Sorry , 이 조건 소환은 아직이에요~)");return 1;}
	0;
}

sub use_koka_6{			#전투 개시에 조건

	$chudan="4-$b_fld[0]-$b_fld[1]";
	$tmp_syorip="<>c-$chudan<>i-$s_a";

	$t_nm = $c_name[$b_mst[0]];
	if($t_nm eq "지뢰 거미"){
		if(&cointos){return 1;}
		&add_msg("null","<b>지뢰 거미의 효과 발동! </b>");
		if(!(&cointos2)){
			&add_msg("null","<b>변두리!　$pn[$s_a]의 라이프는 반이 된다! </b>");
			$lp[$s_a]=int($lp[$s_a]/2);
		}
	}
	elsif($t_nm eq "칠흑의 표 전사 판사·워리아" || $t_nm eq "인 섹트 여왕"){
		$seast="99921";$jokenst='$res_si!='.$b_fld[0];$go_hit=1;$go_msg="(제물이 존재하지 않는다)";
		$tmp_syorip.="<>m-자신의 필드의 몬스터 1체를 제물로 바칠 필요가 있다. ";
		if(&go_card_search){return 1;}
		if($cpu[$s_a]==1){
			$jokenst.=' && $ap_fld[$res_si]<$ap_fld['.$b_fld[0].']';&card_search;
			if($#res_s<0){return 1;}
			@res_s2 = sort ap_cre_res @res_s;$res_s[0]=$res_s2[$#res_s2];
		}
		&add_msg("null",$c_name[$fld[$res_s[0]]]."을(를) 제물로 바치고 --");
		&go_boti($res_s[0],4);
		&get_apdp_fld;
	}
	elsif($t_nm eq "다크 엘프"){
		&add_msg("null","LP를1000포인트 지불 --");
		$lp[$s_a]-=1000;&chk_lp;
	}

	return 0;
}

sub ikenie_chk{
	if($kok[0][35] ne ""){&add_msg("null","!$s_a(생지는 봉쇄되고 있다)");return 1;}
	0;
}

sub use_koka_4{			#장소로부터
	local($cardno) = $_[0];
	local($i,$j,@res_s,$t_nm);
	if(&kinsi_chk2($use_f_no)){return;}

	$t_nm = $c_name[$cardno];
	if($t_nm eq "캐논 솔저" || $t_nm eq "중강갑 거북"){
		$seast="99121";$go_hit="<99";
		if(&go_card_search){return;}
		&used;$in_proc=1;
		for($i=0;$i<$#res_s+1;$i++){
			if($t_nm=~/^캐/){$dam=500;}
			else{$dam=int($ap_fld[$res_s[$i]]/2);}
			&add_msg("null","$c_name[$fld[$res_s[$i]]]를 사출! <br>$pn[$s_d]에$dam의 데미지! ");
			$lp[$s_d]-=$dam;&chk_lp;
			&go_boti($res_s[$i],4);
		}
		$in_proc="";
	}
	elsif($t_nm eq "자석의 전사 마그넷·벌키 리온"){
		if(&ikenie_chk()){return;}
		if(&maisu_count(8)<2){&add_msg("null","!$s_a(필드에 빈 곳이 없다)");return;}
		undef(@jitmp);@jicno=(740,741,744);
		for($i=0;$i<$#{$boti[$s_a]}+1;$i++){
			for($j=0;$j<3;$j++){if($boti[$s_a][$i]==$jicno[$j]){$jitmp[$j]=$i;last;}}
		}
		if($jitmp[0] eq "" || $jitmp[1] eq "" || $jitmp[2] eq ""){&add_msg("null","!$s_a(자석의 전사가 묘지에 없어)");return;}
		&used;
		&add_msg("null","<b>합체 해제! </b>　자석의 전사 3체 로 분리했다. ");
		&go_boti($use_f_no,4);
		for($i=0;$i<3;$i++){&fld_chk();&put_field($jitmp[$i]+200);}
		&del_null(*boti,$s_a);&hosatu(0);
	}
	elsif($t_nm eq "카라테만"){
		if($fld_koka[$use_f_no]=~/karate/){&add_msg("null","!$s_a(이 효과는 1턴에 1회 밖에 사용할 수 없다)");return;}
		&used;
		$fld_koka[$use_f_no].="karate<>";
		&add_msg("null","<font color=$textc_p2><b>「화·조·풍·월!」</b></font><br>아후로파워로 공격력이 배가 되었다! ");
	}
	elsif($t_nm eq "블랙 매지션"){
		if($fld_koka[$use_f_no]!~/tokima/){return;}
		if(&ext_chk()){return;}
		if(&ikenie_chk()){return;}
		$seast="9999000010001";$jokenst='$cardno==1027';
		if(&go_card_search){return;}

		&go_boti($use_f_no,4);
		&add_msg("null","천년을 넘긴 흑 마술사는 , 모든 마술을 아는 대현자가 된다! <br><b>승복의 대현자! </b>");
		$nf0=$use_f_no;
		&put_field($res_s[0],0,2);&del_null(*deck,$s_a);
		&change_phase(2);
	}
	elsif($t_nm eq "붉은눈의 흑룡" || $t_nm eq "데비르조아"){
		if($fld_koka[$use_f_no]!~/metal/){return;}
		if(&ext_chk()){return;}
		if(&ikenie_chk()){return;}

		if($t_nm=~/^붉/){$taisyo=722;}
		else{$taisyo=721;}
		for($deckno=0;$deckno<$#{$deck[$s_a]}+1;$deckno++){
			if($deck[$s_a][$deckno]==$taisyo){last;}
		}
		if($deckno==$#{$deck[$s_a]}+1){&add_msg("null","!$s_a(덱에$c_name[$taisyo]가 없다)");return;}

		&go_boti($use_f_no,4);
		$nf0=$use_f_no;
		&put_field($deckno+400,0,2);&del_null(*deck,$s_a);
		&add_msg("null","$t_nm이 메탈 폼! <br><b>$c_name[$taisyo]! </b>");
		&change_phase(2);
	}
	elsif($t_nm eq "속사포 드래곤"){
		if(&kokausedchk){return;}
		$seast="991901";
		if(&go_card_search){return;}
		if($cpu[$s_a]==1){&cpu_get_saikyo();}
		&used;
		if($player[$s_a]==14){&add_msg($pn[$s_a],"쿠크크…, 라고 째생명의 교환은 한 적 있을까…(바! )");}

		&kokaused;
		&add_msg("null","<font color=$textc_p1><b>Russian·룰렛! </b></font><br>코인을 3장 던진다 --");
		$cou=0;$tmp="";
		for($i=0;$i<3;$i++){
			$rann=rand;$rann=int($rann*2);
			if($rann==0){$cou++;}
			$tmp.="$omoteura[$rann]·";
		}
		$tmp=~s/·$//;&add_msg("null","<b>$tmp</b>");
		if($cou>1){
			&add_msg("null","<b>명중!　<font color=$textc_p2>암·캐논·쇼트! </font><br>$c_name[$fld[$res_s[0]]]을(를) 파괴! </b>");
			&go_boti($res_s[0],5);
		}
		else{&add_msg("null","하 엇갈렸네...");}
	}

	elsif($t_nm eq "데빌·후란켄"){
		if(&akichk()){return;}
		if(&ext_chk()){return;}

		$seast="999900000000001";$jokenst='$cardno!=1225 && $cardno!=1226';
		if(&go_card_search){return;}

		&add_msg("null","LP을5000지불해 --");
		$lp[$s_a]-=5000;&chk_lp;
		&used;
		&put_field($res_s[0]);&del_null(*yugo,$s_a);
		&add_msg("null","<b>$c_name[$fld[$nf0]]를 호출했다! </b>");
		$fld_koka[$nf0]="irr<>";
	}

	elsif($t_nm eq "시간의 마술사"){
		if(&kokausedchk){return;}
		if(&cointos){return;}
		&used;
		if($player[$s_a]==3){$msgcou=$msgcou_pre;&add_msg($pn[$s_a],"<b>가군!　시간의 마술사! </b>");}
		&add_msg("시간의 마술사","<b><FONT color=$textc_p1>타임·룰렛! </font></b>");
		if(&cointos2){
			&add_msg("null","<b>성공! </b>");
			&add_msg("시간의 마술사","<b><FONT color=$textc_p1>타임·매직! </font></b>");
			&add_msg("null","상대 몬스터는 시공의 소용돌이에 삼켜진다! ");
			for($i=$fw1[$s_d];$i<$fw1[$s_d]+5;$i++){&go_boti($i);}
			for($i=$fw1[$s_a];$i<$fw1[$s_a]+5;$i++){if($fld[$i]==59 && $fld_koka[$i]!~/tokima/){$fld_koka[$i].="tokima<>";last;}}
		}
		else{
			&add_msg("null","<b>실패! </b><br>자군 몬스터는 시공의 소용돌이에 삼켜진다! ");
			$sum=0;
			for($i=$fw1[$s_a];$i<$fw1[$s_a]+5;$i++){$sum+=$ap_fld[$i]/2;&go_boti($i);}
			if($player[$s_a]==3){&add_msg("조이","가지 말아줘∼~! ");}
			$sum=int($sum);
			&add_msg("null","공격력의 반이 라이프로부터 끌린다! <br><b>$pn[$s_a]에$sum의 데미지! </b>");
			$lp[$s_a]-=$sum;&chk_lp;
		}
		&kokaused;
	}

	elsif($t_nm=~/산 제물을 바침$/){
		&fld_chk();
		if($fld_koka[$use_f_no]=~/_sacr/){&add_msg("null","!$s_a(흡수할 수 있는 것은 1체까지다)");return;}
		if(&kokausedchk){return;}
		if($nf1==-1){&add_msg("null","!$s_a(마법·함정 에리어에 빈 곳이 없다)");return;}

		$seast="991901";
		if(&go_card_search){return;}
		if($cpu[$s_a]==1){if(&cpu_get_saikyo($seast,$jokenst)){return;}}

		&used;
		&add_msg("null","<b>다크·홀! </b><br>$c_name[$fld[$res_s[0]]]을(를) 흡수했다! ");
		$fld[$nf1]=$fld[$res_s[0]];$fld_rf[$nf1]=$fld_rf[$res_s[0]];
		&soubi($use_f_no,$nf1,"_sacr");
		$l_side_tmp=&which_side($res_s[0]);
		if($l_side_tmp==1){$fld_koka[$nf1].="moto_$s_d<>teni_$s_a<>";}
		&syometu($res_s[0]);
		if($fld_koka[$use_f_no]=~s/used_(\d+)/used_$turn/){}
		else{$fld_koka[$use_f_no].="used_$turn<>";}
	}
	elsif($t_nm eq "오벨리스크의 거신병"){
		if($fld_koka[$use_f_no]=~/used/){&add_msg("null","!$s_a(이 효과는 1회 밖에 사용할 수 없다)");return;}
		$seast="99121";$go_hit=2;$jokenst='$res_si!=$use_f_no';$go_msg="(생지가 부족하다)";
		if(&go_card_search){return;}
		&add_msg("null","$c_name[$fld[$res_s[0]]]와$c_name[$fld[$res_s[1]]]의 서울 파워를 흡수! ");
		&go_boti($res_s[0],4);&go_boti($res_s[1],4);
		&add_msg("null","<br><FONT SIZE=+2 color=$textc_p1><B>오벨리스크·갓·핸드·분쇄기! </b></font>");
		if($player[$s_a]==2){&add_msg("카이바","<b>이것이 나의 오벨리스크다!　와하하하하</b>");}
		&add_msg("null","<br>모든 몬스터를 파괴!　상대에게4000의 데미지! ");
		for($i=$fw1[$s_d];$i<$fw1[$s_d]+5;$i++){&go_boti($i);}
		$lp[$s_d]-=4000;&chk_lp;
		$fld_koka[$use_f_no].="used<>";
		$a_b[$use_f_no]=1;
		&change_phase(2);
	}
	elsif($t_nm eq "라의 익신룡"){
		if($fld_koka[$use_f_no]!~/sosei_$turn/){&add_msg("null","!$s_a(묘지로부터 소생 한 턴 밖에 사용할 수 없다)");return;}
		if($fld_koka[$use_f_no]=~/used/){&add_msg("null","!$s_a(이미 효과를 사용하고 있다)");return;}
		if($cpu[$s_a]==1){
			if($lp[$s_a]<=1000){return;}
			for($i=$fw1[$s_d];$i<$fw1[$s_d]+5;$i++){if($fld[$i] ne "" && $fld_ad[$i]==1){last;}}
			if($i==$fw1[$s_d]+5){$F{'options'}=1;}
		}
		if($F{'options'} eq "1"){
			if($lp[$s_a]<2){return;}
			&add_msg("null","<i>신은 땅에서 소생 하는 재생의 방법과 종자의 생명을 주어라<br>때는 하나이든지 전장의 적은 불길에 의해 시체화한다</i><br>");
			if($player[$s_a]==21){&add_msg("마리크","1턴 KILL……! ");}
			$tmp=$lp[$s_a]-1;$lp[$s_a]=1;
			$fld_koka[$use_f_no].="ptr:".$tmp.":".$tmp.":$turn<>used<>";
			&add_msg("null","<b>$pn[$s_a]은(는) 신과 일체화! <br>스스로의 라이프를 1만 남겨 , 남는 모두를신의 능력에 변환! </b>");
			&change_phase(2);
		}
		else{
			$seast="991901";$tmp_syorip.="<>m-어느 쪽의 효과를 사용할까요? <br>(갓 훼닉스는 대상도 선택해 준다)<>o-갓 훼닉스::1턴KILL<>l-1";
			if($kekka=&go_card_search){if($kekka==1 && $cpu[$s_a]!=1){&go_select_syori;}return;}
			&cpu_get_saikyo();

			&add_msg("null","<i>시 하나로서 신은 불사조가 되는<br>선택된  마귀는 대지에 자는</i><br>");
			&add_msg("null","1000의 라이프를 지불해 --");
			$lp[$s_a]-=1000;&chk_lp;
			&add_msg("null","<b>라의 익신룡 최종 형태! <br><font color=$textc_p2 size=+1>갓 훼닉스! </font></b>");
			if($player[$s_a]==21){
				&add_msg("마리크","아명의 파편을 바치고<br>신이야 적의 머슴을 지옥의 맹렬한 불로 다 구워라! ");
				if($room eq "" && $player[$s_d]==3){&phoenix;}
			}
			&add_msg("null","$c_name[$fld[$res_s[0]]]은(는) 불사조에게 구워 다하여졌다! </b>");
			&go_boti($res_s[0],5);
			$fld_koka[$use_f_no].="used<>";
			&change_phase(2);
		}
	}
	elsif($t_nm eq "아마조네스의 사수"){
		$seast="99121";$go_hit=2;$jokenst='';$go_msg="(생지가 부족하다)";
		if(&go_card_search){return;}
		&used;
		&add_msg("null","$c_name[$fld[$res_s[0]]]와$c_name[$fld[$res_s[1]]]를 사출! <br>상대에게1200의 데미지! ");
		$in_proc=1;&go_boti($res_s[0],4);&go_boti($res_s[1],4);$in_proc="";
		$lp[$s_d]-=1200;&chk_lp;
	}
	elsif($t_nm eq "히스테릭 천사"){
		$seast="99121";$go_hit=2;$jokenst='';$go_msg="(생지가 부족하다)";
		if(&go_card_search){return;}
		&used;
		&add_msg("null","$c_name[$fld[$res_s[0]]]와$c_name[$fld[$res_s[1]]]를 생지에 바쳤다. ");
		$in_proc=1;&go_boti($res_s[0],4);&go_boti($res_s[1],4);$in_proc="";
		&lp_up(1000);
	}
	elsif($t_nm eq "승령술사 죠우겐"){
		if($#{$tehuda[$s_a]}<0){&add_msg("null","!$s_a(카드패가 없다)");return;}
		$rann=rand;$rann=int($rann*($#{$tehuda[$s_a]}+1));
		&add_msg("null","$c_name[$tehuda[$s_a][$rann]]을 버린다 --");
		&go_boti2($rann);
		&used;
		for($i=5;$i<15;$i++){
			if($fld[$i] eq ""){next;}
			if($fld_koka[$i]=~/ext<>/){
				&add_msg("null","$c_name[$fld[$i]]를 승령 했다! ");
				&go_boti($i);
			}
		}
	}
	elsif($t_nm eq "마력 흡수 구체" || $t_nm eq "마인 다크·발타" || $t_nm eq "드래곤·워리아"){
		if($t_nm=~/체$/ && $s_a==$turn2){&add_msg("null","!$s_a(상대 턴 밖에 사용할 수 없다)");return;}
		if($t_nm=~/^드/){$tmp=10;}else{$tmp=9;}
		if($chain[0]!~/([12])-$tmp-(\d+)-(\d+)/){return;}
		$kyu1=$2;$kyu2=$3;
		$chain[0]="$1-null";
		if($t_nm=~/체$/){if(&ikenie_chk){return;}&go_boti($use_f_no,4);}
		else{&add_msg("null","1000의 라이프를 지불해 --");$lp[$s_a]-=1000;&chk_lp;}
		&used;
		if($t_nm=~/체$/){&add_msg("null","$c_name[$kyu1]을 흡수했다! ");}
		else{&add_msg("null","$c_name[$kyu1](을)를 싹 지웠다! ");}
		&go_boti($kyu2);
	}
	elsif($t_nm eq "영혼을 식자 바즈"){
		if(&kokausedchk){return;}
		if($hk[8] eq ""){$seast="09930000001";}
		else{$seast="09931";}
		$go_hit="<4";
		if(&go_card_search){return;}
		&used;$tmp="";
		for($i=0;$i<$#res_s+1 && $i<3;$i++){
			$tmp.="$c_name[$boti[$s_a][$res_s[$i]-200]]와";
			$boti[$s_a][$res_s[$i]-200]="";
		}
		$tmp=~s/와$//;$tmp2=300*($#res_s+1);
		&add_msg("null","$tmp의 영혼을 먹어 공격력$tmp2업! ");
		$tmp=$turn+1;
		$fld_koka[$use_f_no].="ptr:$tmp2:0:$turn<>ptr:$tmp2:0:$tmp<>";
		&kokaused;
		&del_null(*boti,$s_a);
	}
	elsif($t_nm eq "번개 마신-썬가" || $t_nm eq "수 마신-스가" || $t_nm eq "풍 마신-휴가"){
		if($fld_koka[$use_f_no]=~/used<>/){return;}
		if($chain[0]!~/$s_d-3-/){return;}
		&used;
		if($t_nm=~/^번/){&add_msg("null","<b>리플렉션!　번개 바리어! </b>");}
		elsif($t_nm=~/^수/){&add_msg("null","<b>리플렉션!　수해승벽! </b>");}
		else{&add_msg("null","<b>리플렉션!　스톰 바리게이트! </b>");}
		&add_msg("null","상대의 공격력을 0으로 했다! ");
		$reflection=1;
		$fld_koka[$use_f_no].="used<>";
	}
	elsif($t_nm eq "주사 천사 릴리"){
		if($fld_koka[$use_f_no]=~/used<>/){return;}
		&add_msg("null","!$s_a(릴리는 주사기를 지은다)");
		$fld_koka[$use_f_no].="used<>";
	}
	elsif($t_nm eq "안되어 사람 용병 부대"){
		if(&ikenie_chk()){return;}
		$seast="991911";$jokenst='$res_si!='.$use_f_no;
		if(&go_card_search){return;}
		&used;
		&add_msg("null","안되어 사람들은$c_name[$fld[$res_s[0]]]에 치고 덤볐다! <br><b>「오라오라오라!」</b><br>$c_name[$fld[$res_s[0]]]와(과) 함께 자멸! ");
		&go_boti($use_f_no,4);&go_boti($res_s[0],5);
	}
	elsif($t_nm eq "이그자리온·유니버스"){
		if($fld_koka[$use_f_no]=~/used<>/){return;}
		if($phase==4){&add_msg("null","!$s_a(배틀 스텝 밖에 사용할 수 없다)");return;}
		&add_msg("null","이그자리온은 창을 지었다! ");
		$fld_koka[$use_f_no].="used<>";$phase=3;
	}
	elsif($t_nm eq "성수 셀 케토"){
		if($kok[0][8] ne ""){&add_msg("null","!$s_a(왕가의 신전이 무효)");return;}
		if(&ext_chk()){return;}
		if($cpu[$s_a]==1 && $player[$s_a]==20 && !(grep(/^1099$/,@{$boti[$s_a]}))){
			&add_msg("리시드","셀 케토의 공 --");
			&add_msg("마리크","기다려라!　리시드! <br>$pn[$s_d]하…　신의 공격으로 잡아라! <br>니가 신의 옮기기몸을 조종할 수가 있으면<br> 아버님도 너를 아들로 인정하고 말이야…");
			&add_msg("리시드","(…아버지 ……상…)<br>이 턴…내가 신의 소지자인 증거를 세우자…");
		}
		$ap_bak=$ap_fld[$use_f_no]."-".$dp_fld[$use_f_no];&go_boti($use_f_no);
		for($i=$fw2[$s_a];$i<$fw2[$s_a]+5;$i++){if($fld[$i]==1216){&go_boti($i);last;}}
		&add_msg("null","셀 케토와 왕가의 신전을 묘지에 보냈다! ");
		$seast="099400001000101";$jokenst='$c_syokan[$cardno]!=2 && $c_syokan[$cardno]!=3 && $cardno!=1225';
		$tmp_syorip="<>i-$s_a<>n-selketo<>g-1<>p-$ap_bak";
		&go_select_syori;
		&change_phase(2);
	}
	elsif($t_nm eq "빙의 하는 블래드·서울"){
		if(&ikenie_chk){return;}
		$cou=&maisu_count(8);
		$seast="909901";$jokenst='&lv_st($cardno,$res_si)<4';&card_search;
		if($#res_s<0){&add_msg("null","!$s_a(대상이 존재하지 않는)");return;}
		elsif($#res_s>$cou){$go_hit=$cou+1;if(&go_card_search){return;}}

		&go_boti($use_f_no,4);
		&used;
		for($i=0;$i<$#res_s+1;$i++){
			&fld_chk();
			&add_msg("null","$c_name[$fld[$res_s[$i]]]빙의! ");
			&moto_chk($res_s[$i]);
			&ctrl_ido($res_s[$i],$nf0);
			$fld_koka[$nf0].="teni_$s_a<>";
		}
		&card_search;
		for($i=0;$i<$#res_s+1;$i++){
			&add_msg("null","$c_name[$fld[$res_s[$i]]](은)는 장소에 빈 곳이 없기 때문에 파괴. ");
			&go_boti($res_s[$i]);
		}
	}
	elsif($t_nm eq "하·데스의 사용마"){
		if(&ikenie_chk){return;}
		$seast="901911";$jokenst='&syu_st($res_si) eq "악마" && $res_si!='.$use_f_no;
		if(&go_card_search){return;}
		&used;
		&go_boti($use_f_no,4);
		&add_msg("null","하·데스의 힘을$c_name[$fld[$res_s[0]]]에게 주었다! ");
		$fld_koka[$res_s[0]].="ptr:700:700:0<>";
	}
	elsif($t_nm eq "스피릿·드래곤"){
		if($phase==4){&add_msg("null","!$s_a(배틀 스텝 밖에 사용할 수 없다)");return;}
		$seast="099900001";$jokenst='$c_syuzoku[$cardno] eq "드래곤"';
		if(&go_card_search){return;}
		&add_msg("null","<b>$c_name[$tehuda[$s_a][$res_s[0]-50]]의 영혼이 스피릿·드래곤에 머물었다! </b>");
		&go_boti2($res_s[0]-50);
		$fld_koka[$use_f_no].="spilit:$turn<>";
		$phase=3;
	}
	elsif($t_nm eq "그레이·윙"){
		if($phase!=2){&add_msg("null","!$s_a(메인페이즈1밖에 사용할 수 없는)");return;}
		$seast="999900001";
		if(&go_card_search){return;}
		&add_msg("null","$c_name[$tehuda[$s_a][$res_s[0]-50]]을 버리고 --");
		&used;
		&add_msg("null","이 턴 2회 공격할 수 있다! ");
		&go_boti2($res_s[0]-50);
		$fld_koka[$use_f_no].="used_$turn<>";
	}
	elsif($t_nm eq "리프·페어리"){
		$seast="90990011";$jokenst='$fld_koka[$res_si]=~/f_'.$use_f_no.':/';
		if(&go_card_search){return;}
		$tcno=$fld[$res_s[0]];
		if($c_syuzoku[$tcno] ne "장비" && !(grep(/^$tcno$/,@soubiatu))){return;}
		&used;
		$in_proc=1;&go_boti($res_s[0],3);$in_proc="";
		&add_msg("null","$c_name[$tcno]는 고엽이 되어 떨어졌다! <br>$pn[$s_d]에500의 데미지! ");
		$lp[$s_d]-=500;&chk_lp;
	}
	elsif($t_nm eq "매직·램프"){
		if(&ext_chk()){return;}
		if(&akichk()){return;}
		$seast="999900001";$jokenst='$cardno==512';$tmp_syorip.="<>o-공격 표시::수비 표시";
		if(&go_card_search){return;}
		&used;
		&add_msg("null","<b>파파라파! </b><br>램프로부터 라·진이 나타났다! ");
		&put_field($res_s[0]);
		$fld_ad[$nf0]=$F{'options'};
	}
	elsif($t_nm eq "아일의 꼬마검사"){
		$seast="99121";$go_hit="<99";$jokenst='$res_si!='.$use_f_no;
		if(&go_card_search){return;}
		&used;$in_proc=1;
		for($i=0;$i<$#res_s+1;$i++){
			&add_msg("null","$c_name[$fld[$res_s[$i]]]힘이 검에 머문다! ");
			&go_boti($res_s[$i],4);
		}
		$in_proc="";$tmp=700*($#res_s+1);
		&add_msg("null","공격력$tmp업! ");
		$fld_koka[$use_f_no].="ptr:$tmp:0:$turn<>";
	}
	elsif($t_nm eq "투석 부대"){
		if(&ikenie_chk){return;}
		$seast="901911";$go_hit=2;
		if(&go_card_search){return;}
		$sid0=&which_side($res_s[0],1);$sid1=&which_side($res_s[1],1);
		if($sid0==$sid1){return;}
		if($sid1==0){$tmp=$res_s[1];$res_s[1]=$res_s[0];$res_s[0]=$tmp;}
		if(&syu_st($res_s[0]) ne "전사"){return;}
		if($dp_fld[$res_s[1]]>$dp_fld[$res_s[0]]){return;}
		&used;
		&add_msg("null","$c_name[$fld[$res_s[0]]]를 투석기로부터 사출! <br><b>$c_name[$fld[$res_s[1]]](을)를 파괴! </b>");
		$in_proc=1;&go_boti($res_s[0]);$in_proc="";
		&go_boti($res_s[1],5);
	}
	elsif($t_nm eq "몬스터·아이"){
		for($i=0;$i<$#{$boti[$s_a]}+1;$i++){if($boti[$s_a][$i]==44){last;}}
		if($i==$#{$boti[$s_a]}+1){return;}
		$boti[$s_a][$i]="";
		&add_msg("null","1000의 라이프를 지불해 --");
		$lp[$s_a]-=1000;&chk_lp;
		&used;
		&add_msg("null","묘지의 「융합」을 패에 되돌렸다! ");
		push(@{$tehuda[$s_a]},44);
		&del_null(*boti,$s_a);
	}
	elsif($t_nm eq "와 우연의 여신"){
		if(&kokausedchk){return;}
		if(&cointos){return;}
		&used;
		if($hk[2] ne ""){$hkst="_hk2";}else{$hkst="";}
		if(&cointos2){
			&add_msg("null","와 우연에 파워업! <br>공격력이 2배에! ");
			$fld_koka[$use_f_no].="limiu$turn$hkst<>";
		}
		else{
			&add_msg("null","와 우연에 파워다운! <br>공격력이 반에! ");
			$fld_koka[$use_f_no].="limid$turn$hkst<>";
		}
		&kokaused;
	}

	return 1;
}

sub use_koka_3{			#패로부터
	local($use_t_no) = $_[0];
	local($i,$j);

	$t_nm = $c_name[$tehuda[$s_a][$use_t_no]];

	if($t_nm eq "봉인된 엑조디아"){
		&exo_sort_set;
		if($exo_chk{145}.$exo_chk{193}.$exo_chk{713}.$exo_chk{714} ne "1111"){&add_msg("null","!$s_a(5장의 파츠 카드가 갖추어지지 않아)");return;}
		if($player[$s_a]==24){&add_msg("레어 헌터","후후…　나의 승리다…! ");}

		&add_msg("null","<b>지금 , 여기에……<br>신의 사지인 모든 카드가 갖추어졌다! <h3>엑조디아는 소환된다! </h3><h2><font color=$textc_p2>분노의 지옥의 맹렬한 불 엑조드·후레임! </font></h2><h3>엑조디아 공격력∞<br>모든 적은 티끌화했다! </h3><br>");
		undef(@fld_rf);undef(@fld_ad);undef(@fld_koka);undef(@{$tehuda[$s_a]});
		if($s_a==1){@fld=("","","","","","","","","","",714,145,687,193,713);}
		else{@fld=("","","","","",714,145,687,193,713);}
		$lp[$s_d]=0;
		&chk_lp;
	}

	elsif($t_nm eq "썬더 드래곤"){
		&used;
		&maryoku(16);&maryoku(17);
		&go_boti2($use_t_no);
		$seast="9999000000001";$jokenst='$cardno==371';&card_search;
		if($#res_s<0){&add_msg("null","(그러나 , 덱에 썬더 드래곤이 없었다)");}
		else{$tmp_syorip="<>n-thundra<>i-$s_a<>g-1<>h-<3";&go_select_syori;}
	}

	elsif($t_nm eq "크리보"){
		if($chain[0]!~/^[12]-3-/){return;}
		&maryoku(16);&maryoku(17);
		&go_boti2($use_t_no);
		$not_damage=1;$c_end=1;
		return;
	}

	elsif($t_nm eq "진화의 고치"){
		if(&ext_chk()){return;}
		if($call[$s_a] ne ""){&add_msg("null","!$s_a(이 효과는 통상 소환 취급이다. 이미 통상 소환을 실시하고 있다)");return;}
		&fld_chk();
		if($nf1<0){&add_msg("null","!$s_a(필드에 빈 곳이 없다)");return;}

		$seast="90991";$go_hit=1;$go_msg="(공식상의 꼬마 모스가 없다)";
		$jokenst='$cardno==213 && $fld_koka[$res_si]!~/mayu/';
		if(&go_card_search){return;}

		if($player[$s_a]==10){&add_msg("사마준","효효효효효 ~~! <br>모든 것은 나의 작전-에 진행했다! ");}
		&used;
		$nf0=$nf1;
		&put_field($use_t_no+50);
		&soubi($res_s[0],$nf1,"_mayu$turn");
		&add_msg("null","꼬마 모스는 고치에 싸여 진화를 시작했다! ");
		$call[$s_a]=1;&maryoku(16);
	}
	elsif($t_nm eq "타카아시의 기라자우르스"){
		if(&akichk()){return;}
		if(&ext_chk()){return;}
		if($F{'options'} eq "" && $cpu[$s_a]!=1){
			$tmp_syorip.="<>o-공격 표시::수비 표시<>m-(표시 형식을 선택해 준다)";
			&go_select_syori;return;
		}
		else{
			&add_msg("null","<b>기라자우르스는 타카아시를 발휘했다! </b>");
			&put_field($use_t_no+50);
			&ext_set($nf0,0,2);
			if($F{'options'}==1){$fld_ad[$nf0]=1;}
		}
		$F{'options'} = "";

		$seast="09940000001";$jokenst='$irrflg!=1 && $cardno!=1106';
		$tmp_syorip="<>i-$s_d<>n-hakaana<>o-공격 표시::수비 표시<>p-1";&go_select_syori;
	}
	return 1;
}

sub rarcopy{
	&add_msg("리시드","각오 해!　$pn[$s_d]! <br><b>태양신의 공격! </b>");
	&add_msg("마리크","! <br>하!　나의 덱안의…<br>진정한 신이 분노의 아우라를 발하고 있다…! ");
	&add_msg("리시드","……!　왜…　신은 공격하지 않는…");
	&add_msg("마리크","이것…신은 모습등으로는 없다! <br>몸을 옮겨 사용한 것에 대한 신의 분노…! ");
	if($player[$s_d]==3){&add_msg("조이","무엇이…어떻게 하든 이야! ");}
	&add_msg("마리크","신의 분노는 그 게임에 참가한 플레이어에 내려지는…");
	&add_msg("리시드","신 …　나를 일족의 후계자로 인정해 주시지 않는 것인지…<br>나에게 신의 카드를 따르게 하는 힘은 없다고 하는지…<br>신은…나에게 중재를 주려는……");
	&add_msg("null","<FONT SIZE=+1><B>드쿨☆</b></font>");
	if($player[$s_d]==3){
		&add_msg("이소노","이 턴내에서 먼저 일어선 사람을 승자로 한다. ");
		&add_msg("리시드","마리크…(가크)");
		&add_msg("조이","유희…혼다…모두…　동내 대회는…? ");
		&add_msg("이소노","승자 --조이 카츠야! (돈☆)");
		$lp[$s_a]=0;
	}
	else{$lp[$s_a]=0;$lp[$s_d]=0;}
	&chk_lp;
}

sub phoenix{
	&add_msg("조이","(장난치지 않지…　내가 지면 메이도…<br>유희도 원나른해지든지! )<br><b>원 아! </b>");
	&add_msg("마리크","하하하하하하! <br>다 불타라!　생명의 연료의 한 방울까지! ");
	&add_msg("조이","후~…");
	&add_msg("마리크","쿠크크 …충분하다 …　되돌아올 수 있는 불사조야…<br>조이의 영혼이 외곬의 연기가 되어 하늘에 사라져 가는 것이 보인다…<br>‥‥‥! <br>하!　놈은 아직…　죽음…<br>(바…　시시한…! )");
	&add_msg("조이","…나의　…턴…<br>기어·후리드의…<br>(유희…　나는…　…이겼다구…)<br>공…");
	&add_msg("유희","글자…　<FONT SIZE=+1><B>조이! </b></font>");
	&add_msg("null","<br><i><FONT SIZE=+1>뜻 반…　조이, 진다! </font></i>");
	$lp[$s_d]=0;$srf[$s_d][7]="";$srf[$s_a][6]="";&chk_lp;
}

sub mofdk{
	&add_msg("유희","카이바 , 지금 궁극용을 소환한다! ");
	&add_msg("카이바","너!　나에 명령하는 것인가! ");
	&add_msg("유희","그런 일을 말하는 경우인가! ");
	&add_msg("유희","너의 힘을 빌리지 않고도 , 놈은 나 한 명 힘으로 넘어뜨려 보인다! ");
	&add_msg("BIG5","카이바 , 백룡과 함께 사라지는게  좋다! ");
	&add_msg("모크바","형-! ");
	&add_msg("null","(모크바 , 카이바를 감싸 소멸)");
	&add_msg("카이바","모크바---! <br>안되... , 하..... BIG5! <br>출로 궁극용!　이제야말로 그 궁극의 모습을 나타내라! ");
	&add_msg("유희","최강의 용과 전사 모일때 , 사악한 신은 멸망한다…. <br>지금 가르쳐 주는군!");
}

1;
