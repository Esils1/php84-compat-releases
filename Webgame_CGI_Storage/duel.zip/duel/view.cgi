#!/usr/bin/perl
require "data.lib";

print "Content-type:text/html; charset=utf-8\n\n";

&get_input;
@pflst = ("yugo1","yugo2","boti1","boti2");
&get_ini;
&get_playerdata;

if($room ne ""){
	if($G{'side1'} eq $id){$u_side=1;}
	elsif($G{'side2'} eq $id){$u_side=2;}
	else{$u_side=0;}
}
else{$u_side=1;}

print<<"_EOF_";
<html>
<title>표시</title>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=utf-8">
<META HTTP-EQUIV="pragma" CONTENT="no-cache">
<body bgcolor=#fffff0 background="embak.gif">
<blockquote>
_EOF_

if($F{'area'} =~ /^yugo([12])$/){
	if($u_side ne $1){exit;}

	if($F{'area'} eq "yugo1"){$t_name=$G{'pn1'};@tmp_s=@yugo1;}
	else{$t_name=$G{'pn2'};@tmp_s=@yugo2;}

	print "<b>○$t_name의 융합 덱</b><br>\n<dl>\n";

	for($i=0;$i<$#tmp_s+1;$i++){
		print "<li>$c_name[$tmp_s[$i]](";
		@tmp=split(/=/,$yulib{$tmp_s[$i]});
		for($j=0;$j<$#tmp+1;$j++){$tmp[$j]=$c_name[$tmp[$j]];}
		$st=join("＋",@tmp);
		print "$st)<br>\n";
	}
}

elsif($F{'area'} eq "boti1" || $F{'area'} eq "boti2"){

	if($F{'area'} eq "boti1"){$t_name=$G{'pn1'};@tmp_s=@boti1;}
	else{$t_name=$G{'pn2'};@tmp_s=@boti2;}

	print "<b>○$t_name의 묘지</b><br>\n<dl>\n";
	if($#tmp_s<0){print "묘지에 카드가 없습니다. <br>\n";}
	for($i=0;$i<$#tmp_s+1;$i++){
		if($tmp_s[$i] eq "" || $tmp_s[$i] eq "_i"){next;}
		print "<li>";
		if($tmp_s[$i]=~s/_i$//){$irrflg=1;print "*";}
		elsif($tmp_s[$i]=~s/_a$//){print "(효과 무효)";}
		print "$c_name[$tmp_s[$i]]<br>\n";
	}
	if($irrflg==1){print "<br>*가 붙어 있는 것은 , 정식적 소환 순서를 밟지 않았다. <br>(사망자 소생등 으로 부활할 수 없다 )<br>";}
}
elsif($F{'area'} eq "husatu"){
	print "<b>○빛의 봉찰검</b><br>\n<dl>\n";
	@tmp=split(/<>/,$G{'husatu'});
	for($i=0;$i<$#tmp+1;$i++){
		($side,$cardno,$turn)=split(/-/,$tmp[$i]);
		print "<li>";
		if($u_side ne $side){print "(상대의 카드)";}
		else{print $c_name[$cardno];}
		$turn= 3 - ($G{'turn'} - $turn) / 2;
		$turn = int($turn + 0.5);
		print "　나머지 턴：$turn<br>\n";
	}
}
elsif($F{'area'} eq "tenpen"){
	require "duellib.pl";
	require "duellib2.pl";
	@pfldata2 = ("pn");
	@pflst = ("fld","fld_ad","fld_rf","a_m","fld_koka");
	@pflst2 = ("deck");
	&get_ini;
	$s_a=1;$s_d=2;@fw1=(5,10);@fw2=(0,15);
	&find_koka;
	if($kok[0][69] eq ""){return;}

	print "<b>○덱의 맨 위</b><br>\n";
	print "$pn[1] … $c_name[$deck[1][0]]<br>\n";
	print "$pn[2] … $c_name[$deck[2][0]]<br>\n";
}

print<<"_EOF_";
</blockquote>
</body></html>
_EOF_

sub get_ini{

	if($room ne ""){$fn=$roomst.$room;}
	else{$fn=$id;}

	if(-r "tmp/$fn"){
		open(PFL,"tmp/$fn");
	}
	else{print "Error";exit;}

	while(<PFL>){
		chop;
		($KEY,$VAL) = split(/\t/);
		$G{$KEY} = $VAL;
	}
	close(PFL);

	for($i=0;$i<$#pflst+1;$i++){
		$evalst = "\@$pflst[$i] = split(/,/,\$G{\"$pflst[$i]\"})";
		eval($evalst);
	}
}

sub get_input{
	$INPUT = $ENV{'QUERY_STRING'};
	$INPUT =~ s/\&+/\&/g;
	$INPUT =~ s/#.+//;
	@TMP = split('&', $INPUT);
	for ($i = 0; $i <= $#TMP; ++$i) {
		($KEY, $VAL) = split('=', $TMP[$i]);
		$VAL =~ tr/+/ /;
		$VAL =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
#		$VAL =~ s/\015\012/\012/g;
#		$VAL =~ s/\015/\012/g;
		if($VAL ne ""){$F{$KEY}=$VAL;}
	}

	$cou=0;
	open(DATA,"card.txt");
	$lin=<DATA>;
	while(<DATA>){
		chop;
		@tmp=split(/\t/);
		$c_name[$cou]=$tmp[0];
		$c_zokusei[$cou]=$tmp[1];
		$c_zoku[$cou]=$tmp[2];
		$c_ap[$cou]=$tmp[3];
		$c_dp[$cou]=$tmp[4];
		$c_lv[$cou]=$tmp[5];
		$c_kouka[$cou]=$tmp[6];
		$c_syokan[$cou]=$tmp[7];
		$cou++;
	}

	$room = $F{'room'};
	$room=~s/\.//g;
	$room=~s/\///g;

	$id = $F{'id'};
	if($id eq ""){$id="test";}
	$id=~s/\.//g;
	$id=~s/\///g;
}


sub get_playerdata{
	$cou=0;
	open(SRF,"srf.dat");
	$lin=<SRF>;
	while(<SRF>){
		chop;
		if($cou==$G{'player1'}){
			@tmp=split(/\t/);
			$t_name = shift(@tmp);
			if($G{'name1'} eq ""){$G{'name1'} = $t_name;}
		}
		if($cou==$G{'player2'}){
			@tmp=split(/\t/);
			$t_name = shift(@tmp);
			if($G{'name2'} eq ""){$G{'name2'} = $t_name;}
		}
		$cou++;
	}
	if($G{'name1'} eq $G{'name2'}){
		$G{'name1'}.="1";
		$G{'name2'}.="2";
	}
}


