
$roomst="room";			#대전용 데이터 파일의 이름
$help = "help.html";		#help.html의 장소
$yhelp = "yugo.html";		#yugo.html의 장소
$khelp = "kouka.html";		#kouka.html의 장소
$ahelp = "avail.html";		#avail.html의 장소
$bgc = "#fffff0";		#배경색
$textc = "#000000";		#문자색
$textlc = "#0000ff";		#문자색(link)
$textvc = "#0000ff";		#문자색(vlink)
$textc_p1 = "#0000ff";		#공격력, 수비력의 색(통상보다 높다)
$textc_p2 = "#ff0000";		#공격력, 수비력의 색(통상보다 낮다)
$bgc_huse = "#cccccc";		#세트 카드의 색
$bgc_tehuda = "#ddddff";	#카드패 에리어의 색
$bgc_jiban = "#dd9966";		#지반침하의 색
$heyakazu = 8;			#대전방의 수
$itigyou = 5;			#대전 화면에서의 1행 전언의 표시행수 0이라면 1행 전언판 없음

#$gzip = "/bin/";		#gzip압축을 사용하는 경우 ,gzip가 있는 디렉토리. readme참조
$bgimg = "embak.gif";		#배경 화면

$natime = 5;			#액세스없이 패배가 되는 시간(분)
1;
