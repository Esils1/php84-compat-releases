#+++++++++++++++++++++++++++++++++++++
#  Copyright (c) 2003 brassiere
#  인생의 게임 ver.1.34
#  
#  web：http://www.yakan.jp/brassiere/
#  mail：brassiere@yakan.jp
#  이 프로그램에 의해서 일어난 일에 책임을 지지 않습니다.
#+++++++++++++++++++++++++++++++++++++
# 한글 번역：찬제
#
# phpable@gmail.com
# http://www.weggy.net 
# http://www.php1st.net
#
# 카피라이트는 삭제하지 말아주세요
# 
# 소스에 대한 질문은 일절 받지 않습니다.
#
# !!! 수정후 재배포 절대 금지 !!!
#+++++++++++++++++++++++++++++++++++++
sub message_hyouzi {
	&header(2);
		$my_log_file = "./member/"."$in{'id'}"."log.cgi";
		open(MYL,"$my_log_file") || &error("로그 파일($my_log_file)이 열리지 않습니다.<br>재차 로그인해도 동일한 관리인($master_ad)까지 메일을 주세요.");
		@messe = <MYL>;
		if(@messe== ""){&error("로그 파일에 문제가 일어났습니다.<br>수고스럽겠지만, 관리인($master_ad)까지 메일을 주세요.");}
		$messe_naiyou = $messe[1];
		close(MYL);
	print "$messe_naiyou";
	if($basyo ne "31" && $basyo ne "11" && $basyo ne "26"){
#	if($basyo eq "31" && $basyo eq "11" && $basyo eq "26"){
	print <<"EOM";
			</td></tr></table>
			<div align=center>
		     <form method="POST" action="$script">
			<input type=hidden name=mode value="login_view">
			<input type=hidden name=command value="select_com">
			<input type=hidden name=name value="$in{'name'}">
			<input type=hidden name=pass value="$in{'pass'}">
			<input type=hidden name=id value="$in{'id'}">
		        <div align="center">
		          <input type="submit" name="Submit2" value=" O K ">
		        </div>
		      </form>
			</div>
			</body></html>
EOM
	}
	exit;
}

sub susumu {
		$susumu_syori .= "<table width=400 border=0 cellspacing=0 cellpadding=15 align=center><tr><td>";
#	$syori=@_[0];

#					if($syori != 6){
#						if($syori == $basyo){&error2("강제 종됩니다.");}
#					}
#					$basyo=$syori;
###스타트 통과했을 경우
					if(@_[1] == 1){
#스타트 통과 보너스
							$yobi4 ++;
							$start_tuuka=int($yobi4/3);
								$susumu_syori .= "<div class=purasu>●스타트 지점을$yobi4회통과했으므로$start_tuuka 만원을 획득했습니다(통과 회수÷3×1만).</div>";
							$money=$money+$start_tuuka;
#요술 망치 보너스
							if($kounyuu  =~ /요술 망치/){
											$susumu_syori .= "<div class=purasu>●요술 망치가 치린과 소리를 울려 100만을 눈앞에 떨어뜨려서 갔습니다.</div>";
										$money=$money+100;
							}
#100회보너스
							if(($yobi4 % 100) == 0){
											$susumu_syori .= "<div class=purasu>●스타트 통과수키리차례 특별 보너스로 해서 500만이 들어갑니다.</div>";
										$money=$money+500;
							}
#은행의 이자 가산
							$rimawari=int($yobi5*0.005);
							if($rimawari >= 1){
									$money=$money+$rimawari;
										$susumu_syori .= "<div class=purasu>●은행에$yobi5만 맡기고 있으므로 이자(0.5%)로 해서$rimawari만을 얻었습니다.</div>";
							}
#슈퍼 정기예금의 이자 가산
							$super_rimawari=int($yobi9*0.01);
							if($super_rimawari > 1){
									$imano_super=$yobi9+$super_rimawari;
										$susumu_syori .= "<div class=purasu>●슈퍼 정기예금에$yobi9만 맡기고 있으므로 이자분 (1%)의$super_rimawari만이 위탁액에 가산되었습니다.현재의 슈퍼 정기예금 예입액：$imano_super만</div>";
									$yobi9=$imano_super;
							}
#물품세를 당긴다
							(@kounyuus)= split(/,/,$kounyuu);
							foreach(@kounyuus){
								$nedan=($mono{$_}+$takara{$_}+$birthday{$_});
								$buppinzei=$nedan*0.05;
								$nedan_goukei=$nedan_goukei+$nedan;
								$zei_goukei=$zei_goukei+$buppinzei;
							}
							$zei_goukei=int($zei_goukei);
							if($zei_goukei > 1){
										$susumu_syori .= "<div class=mainasu>●현재, 총액$nedan_goukei만의 소유물이 있기 때문에, 물품세(5%)로서$zei_goukei만이 끌립니다.</div>";
									$money=$money-$zei_goukei;
							}
#ver.1.36 여기로부터
#부동산 취득세를 당긴다
						if ($land ne "없음" && $house ne "없음"){
							($toti_basyo2,$tubosuu2,$toti_kounyuugaku2)= split(/,/,$land);
							($ieyousiki2,$iekakaku2)= split(/,/,$house);
							$totizeikingaku = ($toti_kounyuugaku2 + $iekakaku2) * 0.04;
							$money=$money-$totizeikingaku;
							$susumu_syori .= "<div class=mainasu>●현재, $toti_basyo2에$tubosuu2평의 토지를 소유하고 있으므로, 부동산 취득세(토지+가 구입시의 4%)로서$totizeikingaku만이 징됩니다.</div>";
						}
#ver.1.36여기까지
#배우자와 아이가 있었을 경우
							if($haiguu ne "독신"){
									$susumu_syori .= "<div class=purasu>●$name씨는 결혼했으므로 보조금 30만이 들어갔습니다.</div>";
								$money=$money+30;
							}
							if($kodomo ne ""){
							(@my_kodomo)= split(/,/,$kodomo);
							$chile_suu=$#my_kodomo+1;
								$kodomo_money=$chile_suu*10;
									$susumu_syori .= "<div class=mainasu>●$name씨는 아이가$chile_suu인 있으므로 양육비로서$kodomo_money만 걸렸습니다.</div>";
								$money=$money-$kodomo_money;
							}
							(@kounyuus)= split(/,/,$kounyuu);
							foreach(@kounyuus){
								if($_ eq "손해보험"){
											$susumu_syori .= "<div class=mainasu>●손해보험료 8만을 지불했습니다.</div>";
										$money=$money-8;
								}
								if($_ eq "건강보험"){
											$susumu_syori .= "<div class=mainasu>●건강보험료 5만을 지불했습니다.</div>";
										$money=$money-5;
								}
							}
#스타트에 돌아오는이었던 경우
					}elsif(@_[1] == 3){
								$susumu_syori .= "<div class=mainasu>●스타트 지점에 되돌려졌습니다.스타트 통과 보너스는 받을 수 없습니다.</div>";
					}

#눈이었던 경우의 주식 상하 처리
					if(@_[2] == 1){
						if($kabu ne "없음"){
							($meigara,$hitokabu,$agari,$sagari,$kazu,$syokiti)= split(/,/,$kabu);
							$hitokabu=$hitokabu+$agari;
							$kabu="$meigara,$hitokabu,$agari,$sagari,$kazu,$syokiti";
								$susumu_syori .= "<div class=purasu>●홀수눈이 나왔으므로$meigara의 주가가$agari만 올랐습니다.</div>";
						}
					}elsif(@_[2] == 2){
						if($kabu ne "없음"){
							($meigara,$hitokabu,$agari,$sagari,$kazu,$syokiti)= split(/,/,$kabu);
							$hitokabu=$hitokabu-$sagari;
							if($hitokabu < 10){
									$kabu="없음";
										$susumu_syori .= "<div class=mainasu>●짝수눈이 나왔기 때문에$meigara의 주가가$sagari만 내린 결과, 주가가 10만을 나누었으므로$meigara주는 없어졌습니다.</div>";
							}else{
									$kabu="$meigara,$hitokabu,$agari,$sagari,$kazu,$syokiti";
										$susumu_syori .= "<div class=mainasu>●짝수눈이 나왔으므로$meigara의 주가가$sagari만 내렸습니다.</div>";
							}
						}
					}
#각 매스마다의 처리
					if(@_[0] == 1){
							$randed=int(rand(50))+1;
							if(($randed % 2) == 0){
									$money=$money+$randed;
										$susumu_syori .= "<div class=purasu>●파칭코에 나갔습니다.$randed만 돈을 벌었습니다.</div>";
							}else{
									$money=$money-$randed;
										$susumu_syori .= "<div class=mainasu>●파칭코에 나갔습니다.$randed만 손해보았습니다.</div>";
							}
					}
					
					if(@_[0] == 2){
								$susumu_syori .= "<div class=purasu>●일로 사장상을 겟트!30만 받았습니다.일스킬치가  5증가했습니다.</div>";
							$money=$money+30;
							$yobi2=$yobi2+5;
							if($kounyuu  =~ /치와와/){
										$susumu_syori .= "<div class=purasu>●한층 더$name씨가 기르고 있는 「치와와」를 사장이 몹시 마음에 들어, 개의 먹이대로서 20만 주었습니다.</div>";
									$money=$money+20;
							}
					}
					
					if(@_[0] == 3){
							if($kounyuu  =~ /손해보험/){
											$susumu_syori .= "<div class=mainasu>●대지진이 발생해 큰 피해를 입었습니다만, 손해보험 덕분에 20만의 손실에 억제했습니다.</div>";
										$money=$money-20;
							}else{
								$susumu_syori .= "<div class=mainasu>●대지진이 발생하고, 큰 피해를 입었습니다.100만 마이너스.</div>";
							$money=$money-100;
							}
					}
					
					if(@_[0] == 4){
								$susumu_syori .= "<div class=mainasu>●일로 중대한 미스를 해 버렸습니다.30만의 배상금을 지불해, 일스킬치가  5줄어 들었습니다.</div>";
							$money=$money-30;
							$yobi2=$yobi2-5;
							if($kounyuu  =~ /골프세트/){
										$susumu_syori .= "<div class=purasu>●그러나 골프 세트를 가져 클라이언트를 접대했는데 신뢰를 회복했습니다.일스킬치 플러스 8</div>";
									$yobi2=$yobi2+8;
							}
					}
					
					if(@_[0] == 5){
							$randed=int(rand(50))+1;
								$susumu_syori .= "<div class=purasu>●길에서 지갑을 주웠습니다.안에는$randed만원이 들어가있었습니다. </div>";
							$money=$money+$randed;
					}
					
					if(@_[0] == 6){
								$susumu_syori .= "<div class=mainasu>●형무소에 들어가 있습니다.눈이 나올 때까지 나올 수 없습니다!그 사이는 마이너스 30만.3회 날려 안되면 4번째에 탈출할 수 있습니다.</div>";
							if($kounyuu  =~ /찬제면죄부/){
								$randed=int(rand(2))+1;
								if ($randed == 1 && !$hsw) {
									$susumu_syori .= "<div class=purasu>●그러나 찬제의 면죄부를 갖고 있었기 때문에 무사히 빠져나올 수 있었습니다.</div>";
									$hsw = 0;
								}
								else {
									$susumu_syori .= "<div class=mainasu>●찬제의 면죄부를 갖고 있었지만, 왠지모를 힘에 이끌려 계속 있어야 했습니다.</div>";
									$hsw = 1;
								}
							}
					}
					
					if(@_[0] == 7){
							$randed=int(rand(5))+1;
								$susumu_syori .= "<div class=purasu>●러브도가$randed 올랐습니다!</div>";
							$love=$love+$randed;
							if($kounyuu  =~ /실크의속옷세트/){
									$susumu_syori .= "<div class=purasu>●실크의 속옷 세트를 가지고 있었기 때문에, 한층 더 러브도가$randed 올랐습니다!</div>";
								$love=$love+$randed;
							}
							if($kounyuu  =~ /에이치회수권/){
									$susumu_syori .= "<div class=purasu>●에이치 회수권을 가지고 있었기 때문에, 한층 더 러브도가$randed 올랐습니다!</div>";
								$love=$love+$randed;
							}
							if($kounyuu  =~ /비아그라/){
									$susumu_syori .= "<div class=purasu>●비아그라를 가지고 있었기 때문에, 한층 더 러브도가$randed 올랐습니다!</div>";
								$love=$love+$randed;
							}
							if($kounyuu  =~ /버스트업캔디/){
									$susumu_syori .= "<div class=purasu>●버스트 업 캔디를 가지고 있었기 때문에, 한층 더 러브도가$randed 올랐습니다!</div>";
								$love=$love+$randed;
							}
							if($kounyuu  =~ /SM세트/){
									$susumu_syori .= "<div class=purasu>●SM세트를 가지고 있었기 때문에, 한층 더 러브도가$randed 올랐습니다!</div>";
								$love=$love+$randed;
							}
							&item_love_hash;
							(@kounyuus)= split(/,/,$kounyuu);
							foreach (@kounyuus) {
								if ($item_love_hash{$_} ne ""){
									$love_up = $item_love_hash{$_};
									$susumu_syori .= "<div class=purasu>●$_(을)를 가지고 있었기 때문에, 한층 더 러브도가$love_up 올랐습니다!</div>";
								$love=$love+$item_love_hash{$_};
								}
							}
					}
					
					if(@_[0] == 8){
							$randed=int(rand(10))+1;
							$yobi2=$yobi2+$randed;
							&yakusyoku_hyouzi($yobi2);
								$susumu_syori .= "<div class=purasu>●일의 스킬이$randed 올랐습니다!현재, 일스킬치는$yobi2로 직무는$yakusyoku입니다.)</div>";
							if($kounyuu  =~ /파소콘/){
									$yobi2=$yobi2+$randed;
									&yakusyoku_hyouzi($yobi2);
										$susumu_syori .= "<div class=purasu>●게다가 평상시파\소\콘의 공부를 하고 있는 것이 인정되어 일스킬치가$randed 올랐습니다!현재, 일스킬치는$yobi2로 직무는$yakusyoku입니다.)</div>";
							}
							&item_job_hash;
							(@kounyuus)= split(/,/,$kounyuu);
							foreach (@kounyuus) {
								if ($item_job_hash{$_} ne ""){
									$job_up = $item_job_hash{$_};
									$yobi2=$yobi2+$item_job_hash{$_};
									&yakusyoku_hyouzi($yobi2);
									$susumu_syori .= "<div class=purasu>●$_(을)를 가지고 있었기 때문에, 한층 더 일스킬치가$job_up 올랐습니다!현재, 일스킬치는$yobi2로 직무는$yakusyoku입니다.)</div>";
								}
							}
					}
					
					if(@_[0] == 9){
							$randed=int(rand(3))+1;
							if($kounyuu  =~ /할머니지혜봉투/){
									$susumu_syori .= "<div class=purasu>●할머니 지혜를 정리한 책을 출판했는데, 베스트셀러가 되었습니다!200만의 인세를 받았습니다.</div>";
								$money=$money+200;
							}elsif($randed == 1){
									$susumu_syori .= "<div class=purasu>●책을 출판했는데, 적당히 팔렸습니다!40만의 인세를 받았습니다.</div>";
								$money=$money+40;
							}elsif($randed == 2){
									$susumu_syori .= "<div class=purasu>●책을 출판했는데, 많이 팔렸습니다!80만의 인세를 받았습니다.</div>";
								$money=$money+80;
							}else{
									$susumu_syori .= "<div class=mainasu>●책을 출판했습니다만, 전혀 팔리지 않았습니다.50만 손해보았습니다.</div>";
								$money=$money-50;
							}
					}
					
					if(@_[0] == 10){
								$susumu_syori .= "<div class=purasu>●집의 근처에서 온천이 솟아 올랐습니다!<br>슈퍼 목욕탕을 시작했는데 대성황으로 100만의 수입을 얻었습니다.</div>";
							$money=$money+100;
					}
					
					if(@_[0] == 11){
							$card_game_flag="on";
					}
					
					if(@_[0] == 12){
						if($kabu ne "없음"){
							($meigara,$hitokabu,$agari,$sagari,$kazu,$syokiti)= split(/,/,$kabu);
							$hitokabu=int($hitokabu/2);
							if($hitokabu < 10){
									$kabu="없음";
										$susumu_syori .= "<div class=mainasu>●대공황이 일어나 주가가 급락!$meigara의 주가는 반이 되어 버렸습니다.그 결과, 주가가 10만을 나누었으므로$meigara주는 없어졌습니다.</div>";
							}else{
									$kabu="$meigara,$hitokabu,$agari,$sagari,$kazu,$syokiti";
										$susumu_syori .= "<div class=mainasu>●대공황이 일어나 주가가 급락!$meigara의 주가는 반이 되어 버렸습니다.</div>";
							}
						}else{
										$susumu_syori .= "<div class=purasu>●대공황이 일어났습니다만, 주식을 가지고 있지 않았기 때문에 피해는 없었습니다.</div>";
						}
					}
					
					if(@_[0] == 13){
						if($kabu ne "없음"){
							($meigara,$hitokabu,$agari,$sagari,$kazu,$syokiti)= split(/,/,$kabu);
							$hitokabu=int($hitokabu*2);
									$kabu="$meigara,$hitokabu,$agari,$sagari,$kazu,$syokiti";
										$susumu_syori .= "<div class=purasu>●보기 드물게 보는 호경기이기 때문에 주가가 급등!$meigara의 주가가 2배가 되었습니다!</div>";
						}else{
										$susumu_syori .= "<div class=purasu>●보기 드물게 보는 호경기가 왔습니다만, 주식을 가지고 있지 않기 때문에 벌이는 없었습니다.</div>";
						}
					}
					
					if(@_[0] == 14){
							&kyuuyo;
							&siokuri;
							&item_kyuuryou_hash;
							(@kounyuus)= split(/,/,$kounyuu);
							foreach (@kounyuus) {
								if ($item_kyuuryou_hash{$_} ne ""){
									$money_up = $item_kyuuryou_hash{$_};
									$susumu_syori .= "<div class=purasu>●$_(을)를 가지고 있었기 때문에, $money_up만의 보너스를 받을 수 있습니다.</div>";
								$money=$money+$item_kyuuryou_hash{$_};
								}
							}
					}
					
					if(@_[0] == 15){
							@gameataris=("프로 게이트 볼 팀을 만들자","잔화의 숙소","일발","그레이트 가난 맨","팝파라팝파","가면 무도회","슬픔의 원아","한 명주","언제라도 빵 퍼스","하마와 함께","술이라도 마시자구","그 딸(아가씨)는 돌아가지 않는다","길거리 선샤인","","조용한 톤","마지막 키스 낚시");
							$randed=int(rand(15));
							$gameatari=$gameataris[$randed];
								$susumu_syori .= "<div class=purasu>●「$gameatari」라고 하는 게임을 개발했는데 대히트.80만원을 얻었습니다.</div>";
							$money=$money+80;
					}
					
					if(@_[0] == 16){
							$randed=int(rand(10))+1;
								$susumu_syori .= "<div class=purasu>●러브도가$randed 올랐습니다!</div>";
							$love=$love+$randed;
							$randed=int(rand(10))+1;
							$yobi2=$yobi2+$randed;
								$susumu_syori .= "<div class=purasu>●일의 스킬이$randed 올랐습니다!현재, 일스킬치는$yobi2입니다.)</div>";
							$randed=int(rand(100))+1;
								$susumu_syori .= "<div class=purasu>●$randed만의 임시 수입이 있었습니다!</div>";
							$money=$money+$randed;
					}
					
					if(@_[0] == 17){
							if($kounyuu  =~ /관음보살/){
									$susumu_syori .= "<div class=purasu>●사업을 일으켰지만 대실패에 끝났습니다.그러나 관음보살이 이상한 힘을 가져와, 마이너스를 플러스로 변했습니다!100만 플러스.</div>";
								$money=$money+100;
							}else{
									$susumu_syori .= "<div class=mainasu>●사업을 일으켰지만 대실패에 끝났습니다.200만 마이너스.</div>";
								$money=$money-200;
							}
					}
					
					if(@_[0] == 18){
							$randed=int(rand(100))+1;
							if(($randed % 2) == 0){
									$money=$money+$randed;
										$susumu_syori .= "<div class=purasu>●경마하러 나갔습니다.$randed만 돈을 벌었습니다.</div>";
							}else{
									$money=$money-$randed;
										$susumu_syori .= "<div class=mainasu>●경마하러 나갔습니다.$randed만 손해보았습니다.</div>";
							}
					}
					
					if(@_[0] == 19){
						if($kounyuu eq ""){
								$susumu_syori .= "<div class=mainasu>●강도에 들어와졌습니다만 도둑맞는 것이 없었기 때문에, 피해는 없습니다.</div>";
						}else{
							$randed=int(rand(3))+1;
							if($randed == 1){
								if($kounyuu  =~ /방범카메라/){
										$bouhan_randed=int(rand(3))+1;
										if($bouhan_randed != 1){
												$susumu_syori .= "<div class=purasu>●강도에 들어와졌습니다만 방범 카메라가 범인을 파악하고 있었기 때문에 도품은 돌아왔습니다.</div>";
										}else{
											(@kounyuus)= split(/,/,$kounyuu);
											$randed=int(rand($#kounyuus));
											$touhin=splice(@kounyuus,$randed,1);
											$kounyuu=join(",",@kounyuus);
												$susumu_syori .= "<div class=mainasu>●강도에 들어와졌습니다!방범 카메라가 우연히 고장나 있어 작동하지 않고, $touhin를 도둑맞아 버렸습니다.</div>";
										}
								}else{
									(@kounyuus)= split(/,/,$kounyuu);
									$randed=int(rand($#kounyuus));
									$touhin=splice(@kounyuus,$randed,1);
									$kounyuu=join(",",@kounyuus);
										$susumu_syori .= "<div class=mainasu>●강도에 들어와졌습니다!$touhin를 도둑맞아 버렸습니다.</div>";
								}
							}else{
										$susumu_syori .= "<div class=purasu>●강도에 들어와졌습니다만, 갑자기 공포심있었는지 아무것도 훔치지 않고 떠난 것 같습니다.</div>";
							}
						}
						open(ITM,"$item_file") || &error("로그 파일($item_file)이 열리지 않습니다.");
						$uketori_flag=0;
						while (<ITM>) {
								($itemName,$syoyuusya,$syoyuusya_id,$job_up_ritu,$love_up_ritu,$money_up_ritu,$item_money_gaku,$present_uketori)= split(/<>/);
								if($touhin eq $itemName){next;}
				$item_temp = "$itemName<>$syoyuusya<>$syoyuusya_id<>$job_up_ritu<>$love_up_ritu<>$money_up_ritu<>$item_money_gaku<>$present_uketori<>\n";
				push (@new_goutou_item,$item_temp);
						}
						close(ITM);
# 로그를 갱신
			&lock;
#ver.1.36 여기로부터
		$err = data_save($item_file, @new_goutou_item);
		if ($err) {&error("$err");}
#			open(OUT,">$item_file") || &error("Write Error : $item_file");
#			print OUT @new_goutou_item;
#			close(OUT);	
#ver.1.36여기까지
			&unlock;
					}
					
					if(@_[0] == 20){
							if($kounyuu  =~ /야보텐만궁의부적/){
											$susumu_syori .= "<div class=purasu>●파산의 위기에 빠졌습니다만, 「야보 텐만궁의 부적」이 있던 덕분에 기적적으로 살아났습니다.</div>";
							}else{
								$randed=int(rand(3))+1;
								if($randed == 1){
										$susumu_syori .= "<div class=mainasu>●큰 일입니다!파산해 버렸습니다!소유금은 0원이 됩니다.다만 가져 돈이 마이너스였던 경우, 빚이 소멸이 됩니다.다만 빚이 1억 이상의 경우는 그대로입니다.</div>";
									if($money >= -10000){
									$money=0;
									}
								}else{
										$susumu_syori .= "<div class=purasu>●파산 직전에까지 몰렸습니다만, 필사의 자금융통이 결실을 봐, 무사했습니다.</div>";
								}
							}
					}
					
					if(@_[0] == 21){
							@cd_ataris=("긴자가 진한 네이산","간타레","잘 여기까지","찬스는 한 번","방귀의 비법","맨발의 청춘","당신에게 꿈 속","오늘 밤은 무김기","망가져 왔는지","곰 물어 개까지도","처녀가척 해","좋아?안되?","아마치마리","킨 타마","그 비인 채로","돈으로 속박하는 것으로부터 눈을 뜨면","오늘 밤은 돌려주지 않아∼","힘내라!코코넛","키스는 구멍으로 해","BOSS 언제나 곁에 있어","안나미라즈의 여자","힘내라 나카타 응원가","이봐 이봐");
							$randed=int(rand(22));
							$cd_atari=$cd_ataris[$randed];
								$susumu_syori .= "<div class=purasu>●「$cd_atari」라고 하는 CD싱글을 발매했는데 대히트.50만원을 얻었습니다.</div>";
							$money=$money+50;
							$yobi8 ++;
							if(($yobi8 % 10) == 0){
									$volume=$yobi8/10;
										$susumu_syori .= "<div class=purasu>●발매한 CD싱글이 10매 쌓였으므로, 「$name 's 베스트 히트 vol.$volume」를 발매!게다가 100만을 얻었습니다.</div>";
									$money=$money+120;
							}
					}
					
					if(@_[0] == 23){
						if($money < 4){
										$susumu_syori .= "<div class=mainasu>●화재가 발생했습니다만, 돈이 마이너스였으므로 특히 피해는 없습니다.</div>";
						}else{
							if($kounyuu  =~ /손해보험/){
											$susumu_syori .= "<div class=mainasu>●화재로 큰 피해를 입었습니다만, 손해보험 덕분에 20만의 손실에 억제했습니다.</div>";
										$money=$money-20;
							}else{
								$randed=int(rand(3))+1;
								if($randed == 1){
										$susumu_syori .= "<div class=mainasu>●큰 화재로 상당한 피해를 입었습니다.소유금이 4분의 1이 되었습니다.</div>";
									$money=int($money / 4);
								}else{
										$susumu_syori .= "<div class=mainasu>●화재로 큰 피해를 입었습니다.100만의 손실이었습니다.</div>";
									$money=$money-100;
								}
							}
						}
					}
					
					if(@_[0] == 24){
							if($kounyuu  =~ /건강보험/){
											$susumu_syori .= "<div class=mainasu>●다리를 골절해 입원해 버렸습니다.다만 건강보험을 가지고 있었기 때문에 비용은 15만으로 끝났습니다.</div>";
										$money=$money-15;
							}else{
								$susumu_syori .= "<div class=mainasu>●다리를 골절해 입원해 버렸습니다.입원비용으로서 80만원 들었습니다.</div>";
							$money=$money-80;
							}
					}
					
					if(@_[0] == 25){
							@syoubaiataris=("우동가게","국수집","라면집","카레집","소고기 덮밥가게","편의점","스파게티가게","프랑스 요리집","카페","PC 관련 상품점");
							$randed=int(rand(9));
							$syoubaiatari=$syoubaiataris[$randed];
								$susumu_syori .= "<div class=purasu>●$syoubaiatari를 시작했는데 대번성.80만원을 얻었습니다.</div>";
							$money=$money+80;
					}
					
					if(@_[0] == 26){
							$loto_flag="on";
					}
					
					if(@_[0] == 27){
									(@kounyuus)= split(/,/,$kounyuu);
									if($#kounyuus > 15){
											$randed=int(rand($#kounyuus));
											$bossyuu=splice(@kounyuus,$randed,1);
											$kounyuu=join(",",@kounyuus);
												$susumu_syori .= "<div class=mainasu>●세관에 걸렸습니다.소지품이 많았던 것 같습니다.유무를 말하게 하지 않고$bossyuu가 몰수되어 섬 했습니다.</div>";
						open(ITM,"$item_file") || &error("로그 파일($item_file)이 열리지 않습니다.");
						$uketori_flag=0;
						while (<ITM>) {
								($itemName,$syoyuusya,$syoyuusya_id,$job_up_ritu,$love_up_ritu,$money_up_ritu,$item_money_gaku,$present_uketori)= split(/<>/);
								if($bossyuu eq $itemName){next;}
				$item_temp = "$itemName<>$syoyuusya<>$syoyuusya_id<>$job_up_ritu<>$love_up_ritu<>$money_up_ritu<>$item_money_gaku<>$present_uketori<>\n";
				push (@new_zeikan_item,$item_temp);
						}
						close(ITM);
# 로그를 갱신
			&lock;
#ver.1.36 여기로부터
		$err = data_save($item_file, @new_zeikan_item);
		if ($err) {&error("$err");}
#			open(OUT,">$item_file") || &error("Write Error : $item_file");
#			print OUT @new_zeikan_item;
#			close(OUT);	
#ver.1.36여기까지
			&unlock;
									}else{
												$susumu_syori .= "<div class=purasu>●소유물의 수가 세관 기준보다 적었기 때문에, 무사히 세관을 빠져 나갔습니다.</div>";
									}
					}
					
					if(@_[0] == 28){
						open(ITM,"$item_file") || &error("로그 파일($item_file)이 열리지 않습니다.");
						$uketori_flag=0;
						while (<ITM>) {
								($itemName,$syoyuusya,$syoyuusya_id,$job_up_ritu,$love_up_ritu,$money_up_ritu,$item_money_gaku,$present_uketori)= split(/<>/);
								if($uketori_flag != 1){
										if($present_uketori eq $id){
											(@kounyuus)= split(/,/,$kounyuu);
											push (@kounyuus,$itemName);
											$kounyuu=join(",",@kounyuus);
											$susumu_syori .= "<div class=purasu>●「해피 생일♪$name」<br>$syoyuusya씨가 「$itemName」를 주었습니다.</div>";
											$present_uketori = "";
											$syoyuusya = $name;
											$uketori_flag=1;
										}
								}
				$item_temp = "$itemName<>$syoyuusya<>$syoyuusya_id<>$job_up_ritu<>$love_up_ritu<>$money_up_ritu<>$item_money_gaku<>$present_uketori<>\n";
				push (@new_item,$item_temp);
						}
						close(ITM);
# 로그를 갱신
			&lock;
#ver.1.36 여기로부터
		$err = data_save($item_file, @new_item);
		if ($err) {&error("$err");}
#			open(OUT,">$item_file") || &error("Write Error : $item_file");
#			print OUT @new_item;
#			close(OUT);	
#ver.1.36여기까지
			&unlock;
									@present= keys %birthday;
									$randed=int(rand($#present));
									$present=splice(@present,$randed,1);
									(@kounyuus)= split(/,/,$kounyuu);
									push (@kounyuus,$present);
									$kounyuu=join(",",@kounyuus);
										$susumu_syori .= "<div class=purasu>●「생일 축합니다!$name」<br>친구로부터$present를 받았습니다.</div>";
					}
					
					if(@_[0] == 29){
						$randed=int(rand(3))+1;
							if($randed == 1){
									$susumu_syori .= "<div class=purasu>●세무서에 갔습니다만, 세무관이 우연히도 소꿉 친구였으므로 납세를 면제해 주었습니다♪</div>";
							}elsif($randed == 2){
											(@kounyuus)= split(/,/,$kounyuu);
											$randed=int(rand($#kounyuus));
											$touhin=splice(@kounyuus,$randed,1);
											$kounyuu=join(",",@kounyuus);
											$susumu_syori .= "<div class=mainasu>●세무서에 갔습니다만, $touhin를 뇌물에 주었는데 납세를 면제해 주었습니다.</div>";
						open(ITM,"$item_file") || &error("로그 파일($item_file)이 열리지 않습니다.");
						$uketori_flag=0;
						while (<ITM>) {
								($itemName,$syoyuusya,$syoyuusya_id,$job_up_ritu,$love_up_ritu,$money_up_ritu,$item_money_gaku,$present_uketori)= split(/<>/);
								if($touhin eq $itemName){next;}
				$item_temp = "$itemName<>$syoyuusya<>$syoyuusya_id<>$job_up_ritu<>$love_up_ritu<>$money_up_ritu<>$item_money_gaku<>$present_uketori<>\n";
				push (@new_wairo_item,$item_temp);
						}
						close(ITM);
# 로그를 갱신
			&lock;
#ver.1.36 여기로부터
		$err = data_save($item_file, @new_wairo_item);
		if ($err) {&error("$err");}
#			open(OUT,">$item_file") || &error("Write Error : $item_file");
#			print OUT @new_wairo_item;
#			close(OUT);	
#ver.1.36여기까지
			&unlock;
							}elsif($randed == 3){
							if($yobi6 < 10000){
									$susumu_syori .= "<div class=purasu>●$name씨는 총자산이 1억 미만이므로 세금은 빼앗기지 않습니다.</div>";
							}elsif($yobi6 < 50000){
								$zeikingaku=int($yobi6*0.002);
								$money=$money-$zeikingaku;
									$susumu_syori .= "<div class=mainasu>●$name씨는 총자산이 1억을 넘고 있기 때문에, 총자산($yobi6만)에 대한 0.2%인$zeikingaku 만원의 세금이 징수되었습니다.</div>";
							}elsif($yobi6 < 100000){
								$zeikingaku=int($yobi6*0.005);
								$money=$money-$zeikingaku;
									$susumu_syori .= "<div class=mainasu>●$name씨는 총자산이 5억을 넘고 있기 때문에, 총자산($yobi6만)에 대한 0.5%인$zeikingaku 만원의 세금이 징수되었습니다.</div>";
							}elsif($yobi6 < 300000){
								$zeikingaku=int($yobi6*0.008);
								$money=$money-$zeikingaku;
									$susumu_syori .= "<div class=mainasu>●$name씨는 총자산이 10억을 넘고 있기 때문에, 총자산($yobi6만)에 대한 0.8%인$zeikingaku 만원의 세금이 징수되었습니다.</div>";
							}elsif($yobi6 >= 300000){
								$zeikingaku=int($yobi6*0.01);
								$money=$money-$zeikingaku;
									$susumu_syori .= "<div class=mainasu>●$name씨는 총자산이 30억을 넘고 있기 때문에, 총자산($yobi6만)에 대한 1%인$zeikingaku 만원의 세금이 징수되었습니다.</div>";
							}
						}
					}
					
					if(@_[0] == 30){
							$randed=int(rand(4))+1;
							if($randed == 1){
									@present= keys %takara;
									$randed=int(rand($#present));
									$present=splice(@present,$randed,1);
									(@kounyuus)= split(/,/,$kounyuu);
									push (@kounyuus,$present);
									$kounyuu=join(",",@kounyuus);
								$susumu_syori .= "<div class=purasu>●보상을 찾아냈습니다!안에는 「$present」가 들어가 있었습니다!</div>";
						}else{
								$susumu_syori .= "<div class=purasu>●보상을 찾아냈습니다만, 안은 하늘이었습니다.</div>";
						}
					}
					
					if(@_[0] == 31){
							$luckyflag="on";
					}
					
					$yobi10 = time;
					$host = $ENV{'REMOTE_HOST'};
					$addr = $ENV{'REMOTE_ADDR'};
					if ($host eq "" || $host eq $addr) {
					$host = gethostbyaddr(pack("C4", split(/\./, $addr)), 2) || $addr;}
					$yobi12 = $host;
	
	if($luckyflag eq "on"){
		&chance_card;
	}
	if($card_game_flag eq "on"){
		&card_game;
	}
	if($loto_flag eq "on"){
		&loto;
	}
}

sub card_game {
	if($in{'command'} eq "hiku"){
	if($in{'sentaku_card'} == ""){&error("카드를 선택해 주세요.");}
		&header(2);
	$my_log_file = "./member/"."$in{'id'}"."log.cgi";
	open(IN,"$my_log_file") || &error("Open Error : $my_log_file");
		$start_flag=0;
		@my_prof=<IN>;
		if($my_prof[1] eq "card_on"){&error2("재독 봐 포함은 금지입니다.");}
		&split_var2($my_prof[0]);
		close(IN);
				print <<"EOM";
				<div class=purasu align=center>＋＋＋결과 발표\＋＋＋</div>
				<table border=0 cellspacing=0 cellpadding=3 align=center width=400><tr>
EOM
				$randed=int(rand(4))+1;
				for($i=1;$i < 5 ;$i ++){
					if($in{'sentaku_card'} == $i){$koredaro="<div align=center>↑<br>선택한 카드</div>";}else{$koredaro="";}
					if($i == $randed){print "<td><img src=$img_dir/atari.gif width=90 height=109>$koredaro</td>\n";}
					else{print "<td><img src=$img_dir/hazure.gif width=90 height=109>$koredaro</td>\n";}
				}
				print "</tr></table>";
#맞았을 경우
				if($in{'sentaku_card'} == $randed){
					if($money >0){
							print "<div class=purasu align=center>훌륭히 맞았습니다!소유금이  3배가 됩니다!</div>\n";
							$money=$money*3;
					}else{
							print "<div class=mainasu align=center>맞아 버렸습니다..빚이 2배가 됩니다.</div>\n";
							$money=$money*2;
					}
#빠졌을 경우
				}else{
					if($money >0){
							$money=int($money/2);
							print "<div class=mainasu align=center>빠져 버렸습니다.소유금이 반이 됩니다.</div>\n";
					}else{
							print "<div class=purasu align=center>빠졌습니다♪　빚이 2분의 1이 됩니다.</div>\n";
							$money=int($money/2);
					}
				}		#else(당 탈락 판단)가 닫아
				$temp="$id<>$name<>$pass<>$money<>$basyo<>$haiguu<>$kodomo<>$love<>$land<>$house<>$kabu<>$kounyuu<>$sex<>$yobi1<>$yobi2<>$yobi3<>$yobi4<>$yobi5<>$yobi6<>$yobi7<>$yobi8<>$yobi9<>$yobi10<>$yobi11<>$yobi12<>$yobi13<>$yobi14<>\n";
				$newrank[0]=$temp;
				$newrank[1]="card_on";

	# 로그를 갱신
	&lock;
	open(OUT,">$my_log_file") || &error("Write Error : $my_log_file");
	print OUT @newrank;
	close(OUT);	
	&unlock;
	print <<"EOM";
	<div align=center>
     <form method="POST" action="$script">
	<input type=hidden name=mode value="login_view">
	<input type=hidden name=command value="select_com">
	<input type=hidden name=name value="$in{'name'}">
	<input type=hidden name=pass value="$in{'pass'}">
	<input type=hidden name=id value="$in{'id'}">
          <input type="submit" name="Submit2" value=" O K ">
      </form>
	</div>
	</body></html>
EOM
	exit;
	
	}else{		#if(당기는 커멘드라면)가 닫아
								$susumu_syori .= "<form method=\"POST\" action=\"$script\"><input type=hidden name=mode value=\"card_game\"><input type=hidden name=command value=\"hiku\"><input type=hidden name=name value=\"$in{'name'}\"><input type=hidden name=pass value=\"$in{'pass'}\"><input type=hidden name=id value=\"$in{'id'}\"><input type=hidden name=my_basyo value=\"$in{'my_basyo'}\"><div class=purasu align=center>＋＋＋카드게임＋＋＋</div><table border=\"0\" cellspacing=\"0\" cellpadding=\"3\" align=\"center\" width=\"400\"><tr><td align=center><img src=$img_dir/card_sentaku.gif width=90 height=109><br><input type=radio name=sentaku_card value=1></td><td align=center><img src=$img_dir/card_sentaku.gif width=90 height=109><input type=radio name=sentaku_card value=2></td><td align=center><img src=$img_dir/card_sentaku.gif width=90 height=109><input type=radio name=sentaku_card value=3></td><td align=center><img src=$img_dir/card_sentaku.gif width=90 height=109><input type=radio name=sentaku_card value=4></td></td></tr></table><div align=center><input type=submit value=\"이것으로 좋은\"></div></form><div class=honbun>※4매의 카드중 1매만 당이 숨겨져 있습니다.훌륭히 당을 당기면 소유금이 3배!빠져 버리면 소유금이 반이 됩니다.다만, 소유금이 마이너스였던 경우, 당을 당기면 빚이 2배, 반대로 빠지면 빚이 반으로 감합니다.</div>";
	}		#else(당기는 커멘드로 없는 경우)가 닫아
}		#sub 닫아

sub loto {
	if($in{'command'} eq "hiku"){
		&header(2);
	$my_log_file = "./member/"."$in{'id'}"."log.cgi";
	open(IN,"$my_log_file") || &error("Open Error : $my_log_file");
		$start_flag=0;
		@my_prof=<IN>;
		if($my_prof[1] eq "card_on"){&error2("재독 봐 포함은 금지입니다.");}
		&split_var2($my_prof[0]);
		close(IN);
				print <<"EOM";
				<div class=midasi align=center>＋＋＋결과 발표\＋＋＋</div><br>
				<table border=0 cellspacing=0 cellpadding=0 align=center width=400>
EOM
				$loto1=int(rand(10));
				$loto2=int(rand(10));
				$loto3=int(rand(10));
				$loto4=int(rand(10));
				$loto5=int(rand(10));
				$loto6=int(rand(10));
				print <<"EOM";
				<tr><td colspan=6><div class=mainasu align=center>◆◆◆당선 숫자◆◆◆</div></td></tr>
				<tr class=sumi><td class=loto align=center>$loto1</td><td class=loto align=center>$loto2</td><td class=loto align=center>$loto3</td><td class=loto align=center>$loto4</td><td class=loto align=center>$loto5</td><td class=loto align=center>$loto6</td></tr>
<tr><td align=center class=purasu>↓</td><td align=center class=purasu>↓</td><td align=center class=purasu>↓</td><td align=center class=purasu>↓</td><td align=center class=purasu>↓</td><td align=center class=purasu>↓</td></tr>
				<tr class=sumi><td class=loto align=center>$in{'loto1'}</td><td class=loto align=center>$in{'loto2'}</td><td class=loto align=center>$in{'loto3'}</td><td class=loto align=center>$in{'loto4'}</td><td class=loto align=center>$in{'loto5'}</td><td class=loto align=center>$in{'loto6'}</td></tr>
				<tr><td colspan=6><div class=purasu align=center>$name씨가 선택한 숫자</div></td></tr>
				</table><br>
EOM
#맞았을 경우
					$atari = 0;
					if($loto1 == $in{'loto1'}){$atari ++;}
					if($loto2 == $in{'loto2'}){$atari ++;}
					if($loto3 == $in{'loto3'}){$atari ++;}
					if($loto4 == $in{'loto4'}){$atari ++;}
					if($loto5 == $in{'loto5'}){$atari ++;}
					if($loto6 == $in{'loto6'}){$atari ++;}
					if($atari == 0){
							print "<div align=center class=mainasu>유감스럽지만 하나도 맞지 않았기 때문에 50만은 몰됩니다.</div>\n";
								$money=$money-50;
					}elsif($atari == 1){
							print "<div align=center  class=purasu>1자리수 맞았습니다!10만 획득!</div align=center >\n";
								$money=$money+10;
					}elsif($atari == 2){
							print "<div align=center  class=purasu>2자리수 맞았습니다!100만 획득!</div align=center >\n";
								$money=$money+100;
					}elsif($atari == 3){
							print "<div align=center  class=purasu>축합니다.3자리수 맞았습니다!500만 획득!</div align=center >\n";
								$money=$money+500;
					}elsif($atari == 4){
							print "<div align=center  class=purasu>했습니다!4자리수 맞았습니다!1000만 획득!</div align=center >\n";
								$money=$money+1000;
					}elsif($atari == 5){
							print "<div align=center  class=purasu>대합니다!5자리수 맞았습니다!5000만 획득!</div align=center >\n";
								$money=$money+5000;
					}elsif($atari == 6){
							print "<div align=center  class=purasu>, , 대합니다!6자리수 맞았습니다!1억원 획득입니다!</div align=center >\n";
								$money=$money+10000;
					}

				$temp="$id<>$name<>$pass<>$money<>$basyo<>$haiguu<>$kodomo<>$love<>$land<>$house<>$kabu<>$kounyuu<>$sex<>$yobi1<>$yobi2<>$yobi3<>$yobi4<>$yobi5<>$yobi6<>$yobi7<>$yobi8<>$yobi9<>$yobi10<>$yobi11<>$yobi12<>$yobi13<>$yobi14<>\n";
				$newrank[0]=$temp;
				$newrank[1]="card_on";

	# 로그를 갱신
	&lock;
	open(OUT,">$my_log_file") || &error("$my_log_file가 열리지 않습니다");
	print OUT @newrank;
	close(OUT);
	&unlock;
	print <<"EOM";
	<div align=center>
     <form method="POST" action="$script">
	<input type=hidden name=mode value="login_view">
	<input type=hidden name=command value="select_com">
	<input type=hidden name=name value="$in{'name'}">
	<input type=hidden name=pass value="$in{'pass'}">
	<input type=hidden name=id value="$in{'id'}">
          <input type="submit" name="Submit2" value=" O K ">
      </form>
	</div>
	</body></html>
EOM
	exit;
	
	}else{		#if(당기는 커멘드라면)가 닫아
	$susumu_syori .= "<form method=\"POST\" action=\"$script\"><input type=hidden name=mode value=\"loto\"><input type=hidden name=command value=\"hiku\"><input type=hidden name=name value=\"$in{'name'}\"><input type=hidden name=pass value=\"$in{'pass'}\"><input type=hidden name=id value=\"$in{'id'}\"><input type=hidden name=my_basyo value=\"$in{'my_basyo'}\"><div class=midasi align=center>LOTO6 게임</div><table border=\"0\" cellspacing=\"0\" cellpadding=\"3\" align=\"center\" width=\"400\"><tr><td colspan=6><div class=honbun>6자리수의 숫자를 예\상\하고 일확천금을 목표로 합시다!　참가비용은 50만입니다.각 형의 숫자가 1자리수 맞으면 10만, 2자리수 맞으면 100만, 3자리수 맞으면 500만, 4자리수 맞으면 1000만, 5자리수 맞으면 5000만, 그리고 6자리수 맞으면 뭐라고 1억 받을 수 있습니다!</div><br></td></tr><tr>";
for ($a=1;$a < 7; $a ++){
		$susumu_syori .= "<td><select name=loto$a>";
		for ($b=0; $b < 10; $b ++){
				if($b == 5){$susumu_syori .= "<option value=$b selected>$b</option>";}else{
				  $susumu_syori .= "<option value=$b>$b</option>";}
		}
		$susumu_syori .= "</select></td>";
}
	$susumu_syori .= "</tr></table><br><div align=center><input type=submit value=\"이것으로 좋다\"></div></form></body></html>";
	}		#else(당기는 커멘드로 없는 경우)가 닫아
}		#sub 닫아


sub chance_card {
								$susumu_syori .= "<div align=center><img src=$img_dir/card.gif width=90 height=109></div><br><br><div class=purasu align=center>럭키 찬스!카드를 1매 뺄 수 있습니다.</div></td></tr></table><div align=center><form method=\"POST\" action=\"$script\"><input type=hidden name=mode value=\"chance\"><input type=hidden name=name value=\"$in{'name'}\"><input type=hidden name=pass value=\"$in{'pass'}\"><input type=hidden name=id value=\"$in{'id'}\"><input type=hidden name=my_basyo value=\"$in{'my_basyo'}\"><div align=\"center\"><input type=\"submit\" name=\"Submit2\" value=\"카드를 깎는다\"></div></form></div></body></html>";
}

sub chance{
	&header(2);
	$my_log_file = "./member/"."$in{'id'}"."log.cgi";
	open(IN,"$my_log_file") || &error("Open Error : $my_log_file");
		$start_flag=0;
		@my_prof=<IN>;
		if($my_prof[1] eq "card_on"){&error2("재독 봐 포함은 금지입니다.");}
		&split_var2($my_prof[0]);
		close(IN);
		print <<"EOM";
		<table border=0 width=100% align=center cellspacing="10" cellpadding="0">
	<tr><td align=center>
EOM
	$randed=int(rand(25))+1;
		print "<img src=$img_dir/card"."$randed".".gif width=90 height=109>";
	if($randed ==1){$money=$money+100;}
	elsif($randed ==2){$money=$money-100;}
	elsif($randed ==3){$money=$money-10;
	}elsif($randed ==4){
			if($kounyuu  =~ /골프 세트/){
					$money=$money+10;
			}
	}elsif($randed ==5){
			if($kounyuu  =~ /페라~리/){
					$money=$money+500;
			}
	}elsif($randed ==6){
			if($kounyuu  =~ /포르셰/){
					$money=$money+350;
			}
	}elsif($randed ==7){
			if($kounyuu  =~ /페어 레이디 Z/){
					$money=$money+150;
			}
	}elsif($randed ==8){
			if($kounyuu  =~ /카로~라/){
					$money=$money+20;
			}
	}elsif($randed ==9){
			if($kounyuu  =~ /벤츠/){
					$money=$money+200;
			}
	}elsif($randed ==10){
			if($kounyuu  =~ /BMW/){
					$money=$money+180;
			}
	}elsif($randed ==11){
			if($kounyuu  =~ /디즈니~랜드 연간 파스포~트/){
					$money=$money+5;
			}
#ver.1.36 여기로부터
	}elsif($randed ==12){
			if($kounyuu  =~ /비통의 가방/){
					$money=$money+30;
			}
	}elsif($randed ==13){
			if($kounyuu  =~ /샤넬의 지갑/){
					$money=$money+10;
			}
	}elsif($randed ==14){
			if($kounyuu  =~ /헤르메스의 가방/){
					$money=$money+40;
			}
#ver.1.36여기까지
	}elsif($randed ==15){
					$money=$money+1000;
	}elsif($randed ==16){
					$money=$money-100;
	}elsif($randed ==17){
					$money=$money+30;
	}elsif($randed ==18){
					$money=$money+400;
	}elsif($randed ==19){
					$money=$money+300;
	}elsif($randed ==20){
					$money=$money+300;
	}elsif($randed == 21 || $randed == 22){
					(@kounyuus)= split(/,/,$kounyuu);
							foreach $kuruma (@kounyuus){
								if($kuruma  eq "페라~리" || $kuruma  eq "포르셰" || $kuruma  eq "페어 레이디 Z" || $kuruma  eq "카로~라" || $kuruma  eq "벤츠" || $kuruma  eq "BMW" || $kuruma  eq "란보르기~니·카운탁크"){
								$money=$money+200;
								}
							}
	}elsif($randed == 23 || $randed == 24 || $randed == 25 ){
					(@kounyuus)= split(/,/,$kounyuu);
							foreach $kuruma (@kounyuus){
								if($kuruma  eq "비통의 가방" || $kuruma  eq "샤넬의 지갑" || $kuruma  eq "헤르메스의 가방" || $kuruma  eq "나이키의 스니커즈" || $kuruma  eq "티파니의 반지" || $kuruma  eq "불가리의 손목시계" || $kuruma  eq "프라다의 지갑" || $kuruma  eq "샤넬의 향수" || $kuruma  eq "페라가모의 구두" || $kuruma  eq "코치의 가방"){
								$money=$money+80;
								}
							}
	}

				$temp="$id<>$name<>$pass<>$money<>$basyo<>$haiguu<>$kodomo<>$love<>$land<>$house<>$kabu<>$kounyuu<>$sex<>$yobi1<>$yobi2<>$yobi3<>$yobi4<>$yobi5<>$yobi6<>$yobi7<>$yobi8<>$yobi9<>$yobi10<>$yobi11<>$yobi12<>$yobi13<>$yobi14<>\n";
				$newrank[0]=$temp;
				$newrank[1]="card_on";
# 로그를 갱신
	&lock;
	open(OUT,">$my_log_file") || &error("$my_log_file가 열리지 않습니다");
	print OUT @newrank;
	close(OUT);
	&unlock;
	print <<"EOM";
	</td></tr></table>
	<div align=center>
     <form method="POST" action="$script">
	<input type=hidden name=mode value="login_view">
	<input type=hidden name=command value="select_com">
	<input type=hidden name=name value="$in{'name'}">
	<input type=hidden name=pass value="$in{'pass'}">
	<input type=hidden name=id value="$in{'id'}">
          <input type="submit" name="Submit2" value=" O K ">
      </form>
	</div>
	</body></html>
EOM
	exit;
}

sub siokuri {
	open(KF,"$kodomo_file") || &error("Open Error : $kodomo_file");
	while (<KF>) {
	($k_id,$k_name,$oya1,$oya2,$seinengappi,$atama,$sports,$art,$food_time,$k_yobi2,$k_yobi3,$k_yobi4,$k_yobi5)= split(/<>/);
			if($k_yobi2 eq "on"){
				if($oya1 eq $name || $oya2 eq $name){
						$siokurigaku=int($k_yobi4*0.005);
						if($siokurigaku >0){
							$susumu_syori .= "<div class=purasu>●자립해 「$k_yobi3」가 된$k_name씨가$siokurigaku만의 송금을 보내 주었습니다.</div>";
							$money=$money+$siokurigaku;
						}
				}
			}
	}
	close(KF);
}

sub kyuuyo {
							if ($yobi2 < 50){$susumu_syori .= "<div class=purasu><div class=purasu>●급료가 나왔습니다!$name씨는 견습이므로 급료는 15만입니다.</div>";$money=$money+15;}
							elsif($yobi2 < 100){$susumu_syori .= "<div class=purasu>●급료가 나왔습니다!$name씨는 신입사원이므로 급료는 20만입니다.</div>";$money=$money+20;}
							elsif($yobi2 < 150){$susumu_syori .= "<div class=purasu>●급료가 나왔습니다!$name씨는 평사원이므로 급료는 25만입니다.</div>";$money=$money+25;}
							elsif($yobi2 < 200){$susumu_syori .= "<div class=purasu>●급료가 나왔습니다!$name씨는 주임이므로 급료는 35만입니다.</div>";$money=$money+35;}
							elsif($yobi2 < 250){$susumu_syori .= "<div class=purasu>●급료가 나왔습니다!$name씨는 계장이므로 급료는 60만입니다.</div>";$money=$money+60;}
							elsif($yobi2 < 300){$susumu_syori .= "<div class=purasu>●급료가 나왔습니다!$name씨는 과장이므로 급료는 100만입니다.</div>";$money=$money+100;}
							elsif($yobi2 < 500){$susumu_syori .= "<div class=purasu>●급료가 나왔습니다!$name씨는 부장이므로 급료는 200만입니다.</div>";$money=$money+200;}
							elsif($yobi2 < 700){$susumu_syori .= "<div class=purasu>●급료가 나왔습니다!$name씨는 상무이므로 급료는 300만입니다.</div>";$money=$money+300;}
							elsif($yobi2 < 900){$susumu_syori .= "<div class=purasu>●급료가 나왔습니다!$name씨는 전무이므로 급료는 350만입니다.</div>";$money=$money+350;}
							elsif($yobi2 < 1200){$susumu_syori .= "<div class=purasu>●급료가 나왔습니다!$name씨는 사장이므로 급료는 500만입니다.</div>";$money=$money+500;}
							elsif($yobi2 < 1500){$susumu_syori .= "<div class=purasu>●급료가 나왔습니다!$name씨는 회장이므로 급료는 700만입니다.</div>";$money=$money+700;}
							elsif($yobi2 < 1800){$susumu_syori .= "<div class=purasu>●급료가 나왔습니다!$name씨는 명예회장이므로 급료는 800만입니다.</div>";$money=$money+800;}
							elsif($yobi2 < 2200){$susumu_syori .= "<div class=purasu>●급료가 나왔습니다!$name씨는 대신이므로 급료는 900만입니다.</div>";$money=$money+900;}
							elsif($yobi2 < 2600){$susumu_syori .= "<div class=purasu>●급료가 나왔습니다!$name씨는 수상이므로 급료는 1000만입니다.</div>";$money=$money+1000;}
							elsif($yobi2 < 3000){$susumu_syori .= "<div class=purasu>●급료가 나왔습니다!$name씨는 대통령이므로 급료는 1200만입니다.</div>";$money=$money+1200;}
							elsif($yobi2 < 3500){$susumu_syori .= "<div class=purasu>●급료가 나왔습니다!$name씨는 슈퍼스타이므로 급료는 1300만입니다.</div>";$money=$money+1300;}
							elsif($yobi2 < 4000){$susumu_syori .= "<div class=purasu>●급료가 나왔습니다!$name씨는 갓 파더이므로 급료는 1400만입니다.</div>";$money=$money+1400;}
							elsif($yobi2 < 4500){$susumu_syori .= "<div class=purasu>●급료가 나왔습니다!$name씨는 킹이므로 급료는 1500만입니다.</div>";$money=$money+1500;}
							elsif($yobi2 < 10000){$susumu_syori .= "<div class=purasu2>●급료가 나왔습니다!$name씨는 「신」이므로 급료는 2000만입니다.</div>";$money=$money+2000;}
							elsif($yobi2 < 11000){$susumu_syori .= "<div class=purasu2>●$name씨는 「정년퇴직」하고 있기 때문에 20만의 연금이 나왔습니다.</div>";$money=$money+20;}
							elsif($yobi2 < 13000){$susumu_syori .= "<div class=mainasu>●$name씨는 양로원을 돌보는 것을 받고 있으므로 50만을 지불했습니다.</div>";$money=$money-50;}
							elsif($yobi2 >= 13000){$susumu_syori .= "<div class=purasu2>●$name씨는 「전설의 사람」이 되었습니다.세계로부터 5000만의 기부금이 모였습니다.</div>";$money=$money+5000;}
}

1;
