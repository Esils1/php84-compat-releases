#!/usr/bin/perl
BEGIN {
    require FindBin;
    FindBin->import();
    chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
    unshift @INC, $FindBin::Bin;
}
# ↑사용의 서버의 패스에 맞추어 주세요.
#+++++++++++++++++++++++++++++++++++++
#  Copyright (c) 2003 brassiere
#  인생의 게임 ver.1.34
#  
#  web：http://www.yakan.jp/brassiere/
#  mail：brassiere@yakan.jp
#이 프로그램에 의해서 일어난 일에 책임을 지지 않습니다.
#+++++++++++++++++++++++++++++++++++++

#관리자 패스워드
$password = 'changethispassword';

#-------------------초기설정 여기까지.이하는 필요가 있으면 변경해 주세요.

#로그 데이터 파일
$logfile='./zinseilog.cgi';
#이 스크립트의 이름
$script='./admin.cgi';
#락 파일명
$lockfile = './lock/zinsei.lock';
#아이 기록 파일
$kodomo_file='./kodomoFile.cgi';
#아이템 기록 파일
$item_file = './itemlog.cgi';

require './cgi-lib.pl';
require './zinsei_lib.pl';

##############메인 처리
	local($buf, $key, $val, @buf);
#디코드
	if ($ENV{'REQUEST_METHOD'} eq "POST") {
		&ReadParse;
		while (($key,$value) =each %in){
#			$value =~ s/,/, /g;
			$value =~ s/\r\n/<br>/g;
			$value =~ s/\r/<br>/g;
			$value =~ s/\n/<br>/g;
			$in{$key} = $value;
		}
	} else { $buf = $ENV{'QUERY_STRING'}; }
	@buf = split(/&/, $buf);
	foreach (@buf) {
		($key, $val) = split(/=/);
		$val =~ tr/+/ /;
		$val =~ s/%([a-fA-F0-9][a-fA-F0-9]) /pack("C", hex($1)) /eg;
		# 문자 코드 변환 (Shift-JIS 코드)
		$in{$key} = $val;
	}
	
#패스워드 입력 화면
	if ($in{'password'} eq ""){
	&header(2);
	print <<"EOM";
	<form method="POST" action="$script">
	<div align=center class=kuro>
	패스워드를 입력해 주세요.<br>
	<input type=text name=password size=10><input type=submit value="OK"></div>
	</form>
EOM
		if($in{'mode'} eq "showWho") { &ds; }
exit;
	}
	if ($in{'password'} ne $password){&error("패스워드가 다릅니다");}
	
		$refe = $ENV{'HTTP_REFERER'};
	if ($refe !~ /$setti1/ && $refe !~ /$setti2/ && $refe !~ /$setti3/){
	&error("톱 페이지보다 올바르고 들어오세요.<br>$refe");}
	
#조건 분기
	if($in{'mode'} eq "kensaku"){&kensaku;}
	if($in{'mode'} eq "dataHukkatu"){&dataHukkatu;}
	if($in{'mode'} eq "backup_change"){&backup_change;}
	if($in{'mode'} eq "kodomo_change"){&kodomo_change;}
	if($in{'mode'} eq "item_change"){&item_change;}
	if($in{'mode'} eq "itiran"){&itiran;}
	if($in{'mode'} eq "deletUsr"){&deletUsr;}
	
#화면 출력
	&header(2);
	print <<"EOM";
	<div align=center class=midasi>관리자 메뉴</div><br>
	<table width="500" border="0" cellspacing="0" cellpadding="10" align=center>
  <tr><td>
  <div class=kuro><a href=$script?mode=itiran&sort_id=0&password=$in{'password'}>■등록자(랭킹 데이터) 일람</a></div>
  	<hr size=1>
  이 게임에서는, 로그 보존 및 백업을 이하와 같게 가고 있습니다.<br><br>
  ●통상 플레이로의 개인 데이터= 「member」폴더 내 「유저의 ID번호＋log.cgi」<br>
  ●개인의 수신 메일 데이터= 「member」폴더 내 「유저의 ID번호＋.cgi」<br>
  ●랭킹 데이터( 「데이터를 보존」커멘드로 기록된다)= 「zinseilog.cgi」<br>
  ●상기 랭킹 데이터의 백업(1시간 마다의 자동 보존)= 「back_up.cgi」<br>
  ●아이 데이터= 「kodomoFile.cgi」<br>
  ●상기 아이 데이터의 백업(1시간 마다의 자동 보존)= 「kodomo_back.cgi」<br>
  ●아이템 기록 데이터= 「itemlog.cgi」<br>
  ●상기 아이템 기록 데이터의 백업(1시간 마다의 자동 보존)= 「item_back_log.cgi」<br>
  <br>
  만일, 로그 파일이 망가져 버렸을 경우는 이하의 메뉴에 의해 부활시킬 수 있습니다.<br><hr size=1>
  
  <div class=kuro>■개인 데이터의 부활(마지막에 랭킹 데이터에 「데이터 보존」한 상태로 한다)</div>
  ※다만 메일 수신 데이터가 망가져 있었을 경우는 수신 메일을 부활시킬 수 없습니다.<br>
	<form method="POST" action="$script">
	<input type=hidden name=mode value="kensaku">
	<input type=hidden name=password value="$in{'password'}">
	유저명 <input type=text name=name size=20><input type=submit value="검 색">
	</form>
	
  <div class=kuro>■랭킹 데이터의 부활(백업 데이터로 전환한다)</div>
  ※랭킹 파일이 비웠을 경우, 「멘테중」의 에러\표\시가 나오고, 플레이 할 수 없는 상태가 됩니다.이쪽에서 백업 데이터로 전환하는 것으로 속행할 수 있게 됩니다.백업 데이터는 1시간 마다에 보존되고 있기 때문에, 그만큼 큰 차이는 없습니다만, 각자가 「데이터를 보존」하는 것에 의해서 최신의 데이터에 갱신되기 때문에, 그 취지를 톱 화면등에서 알리는 편이 좋을까 생각합니다.<br>
	<form method="POST" action="$script">
	<input type=hidden name=mode value="backup_change">
	<input type=hidden name=password value="$in{'password'}">
	<input type=submit value="랭킹 데이터를 부활시킨다">
	</form>
  
  <div class=kuro>■아이 데이터의 부활(백업 데이터로 전환한다)</div>
  ※아이 파일이 비웠을 경우, 에러\표\시가 나오고, 랭킹\표\시 할 수 없는 상태가 됩니다.이쪽에서 백업 데이터로 전환하는 것으로\표\시 할 수 있게 됩니다.아이 데이터는 개인 데이터와는 별취급 때문에, 백업으로 전환하는 것으로 최대 1시간의 갭이 나오기 때문에, 그 취지를 알리는 편이 좋을까 생각합니다.<br>
	<form method="POST" action="$script">
	<input type=hidden name=mode value="kodomo_change">
	<input type=hidden name=password value="$in{'password'}">
	<input type=submit value="아이 데이터를 부활시킨다">
	</form>
	
  <div class=kuro>■아이템 기록 데이터의 부활(백업 데이터로 전환한다)</div>
  ※아이템 기록 파일이 비웠을 경우, 아이템 작성시에 에러\표\시가 나오고, 새로운 아이템을 만들 수 없는 상태가 됩니다.이쪽에서 백업 데이터로 전환하는 것으로 작성할 수 있게 됩니다.아이템 데이터는 개인 데이터와는 별취급 때문에, 백업으로 전환하는 것으로 최대 1시간의 갭이 나오기 때문에, 그 취지를 알리는 편이 좋을까 생각합니다.<br>
	<form method="POST" action="$script">
	<input type=hidden name=mode value="item_change">
	<input type=hidden name=password value="$in{'password'}">
	<input type=submit value="아이템 기록 데이터를 부활시킨다">
	</form>
	
	</body></html>
EOM
exit;


sub itiran {
	&header(2);
	open(IN,"$logfile") || &error("Open Error : $logfile");
	@rankingMember = <IN>;
		foreach (@rankingMember) {
			$data=$_;
			$key=(split(/<>/,$data))[$in{'sort_id'}];		#소트 하는 요소를 선택한다
			push @alldata,$data;
			push @keys,$key;
		}
	close(IN);
	if($in{'sort_id'} eq ""){
		sub gyakujun{$keys[$a] <=> $keys[$b];}
		@alldata=@alldata[ sort gyakujun 0..$#alldata]; 
	}elsif($in{'sort_id'} eq "12" || $in{'sort_id'} eq "1" || $in{'sort_id'} eq "24"){
		sub byString{$keys[$a] cmp $keys[$b];}
		@alldata=@alldata[ sort byString 0..$#alldata]; 
	}else{
		sub seijun{$keys[$b] <=> $keys[$a];}
		@alldata=@alldata[ sort seijun 0..$#alldata]; 
	}
#동일 호스트의 배열을 작성
	if($in{'sort_id'} eq "24"){
			foreach $one(@alldata) {
		($id,$name,$pass,$money,$basyo,$haiguu,$kodomo,$love,$land,$house,$kabu,$kounyuu,$sex,$yobi1,$yobi2,$yobi3,$yobi4,$yobi5,$yobi6,$yobi7,$yobi8,$yobi9,$yobi10,$yobi11,$yobi12,$yobi13,$yobi14)= split(/<>/,$one);
				if($yobi12 eq "$maeno_host"){
						push @tajuutouroku , $one;
						$check_flag=0;
						foreach $two(@tajuutouroku){
							(@check_yobi12)= split(/<>/,$two);
									if($yobi12 eq "$check_yobi12[24]"){$check_flag ++;}
						}
						if($check_flag <= 1 && $maeno_data ne ""){push @tajuutouroku , $maeno_data;}
				}
				$maeno_host = $yobi12;
				$maeno_data = $one;
			}
	}
		
	print <<"EOM";
	<center>
	<div align=center class=midasi>등록자 일람(랭킹 데이터)</div><br>
<a href=$script?mode=itiran&password=$in{'password'}><span class=sub3>[ID 순서]</span></a><img src=$img_dir/space.gif width=5 height=1>
<a href=$script?mode=itiran&sort_id=18&password=$in{'password'}><span class=sub3>[총자산]</span></a><img src=$img_dir/space.gif width=5 height=1>
<a href=$script?mode=itiran&sort_id=12&password=$in{'password'}><span class=sub3>[성별]</span></a><img src=$img_dir/space.gif width=5 height=1>
<a href=$script?mode=itiran&sort_id=1&password=$in{'password'}><span class=sub3>[이름]</span></a><img src=$img_dir/space.gif width=5 height=1>
<a href=$script?mode=itiran&sort_id=19&password=$in{'password'}><span class=sub3>[데이터 보존]</span></a><img src=$img_dir/space.gif width=5 height=1>
<a href=$script?mode=itiran&sort_id=0&password=$in{'password'}><span class=sub3>[신규 등록순서]</span></a><img src=$img_dir/space.gif width=5 height=1>
<a href=$script?mode=itiran&sort_id=24&password=$in{'password'}><span class=sub3>[호스트순서(다중 등록자)]</span></a>
</center>
	
	<table border=0 width=98% align=center cellspacing="1" cellpadding="5">
	<tr><td colspan=10>●이름을 클릭하면 그 사람의 개인 데이터에 액세스 할 수 있습니다.또 그 화면에서 유저 삭제도 실시할 수 있습니다.
	<form method="POST" action="$script">
	<input type=hidden name=mode value="kensaku">
	<input type=hidden name=command value="kozin_file">
	<input type=hidden name=name value="$name">
	<input type=hidden name=password value="$in{'password'}">
	ID번호 <input type=text name=id size="6">이쪽에서 ID번호를 입력해 검색할 수도 있습니다.
	</form>
	</td></tr>
	<tr  class=sumi bgcolor=#ffff66><td align=center >ID</td><td align=center  width=120>이름</td><td align=center >성별</td><td align=center >총자산</td><td align=center >배우자</td><td align=center >연인</td><td align=center >직무</td><td align=center >START 통과</td><td align=center >데이터 보존</td><td align=center >호스트</td></tr>
EOM
#다중 등록자 표시
	if($in{'sort_id'} eq "24"){
		print "<tr  class=sita bgcolor=#bbbbbb><td colspan=10>다중 등록자(동일 IP or 호스트로의 등록자)</td></tr>";
		foreach $one(@tajuutouroku) {
($id,$name,$pass,$money,$basyo,$haiguu,$kodomo,$love,$land,$house,$kabu,$kounyuu,$sex,$yobi1,$yobi2,$yobi3,$yobi4,$yobi5,$yobi6,$yobi7,$yobi8,$yobi9,$yobi10,$yobi11,$yobi12,$yobi13,$yobi14)= split(/<>/,$one);
#성별 표시를 정형
	if($sex eq "m"){$seibetu_hyouzi = "남";}else{$seibetu_hyouzi = "녀";}
	
#최종 보존 표시를 정형
	$ENV{'TZ'} = "JST-9";
	($sec,$min,$hour,$mday,$mon,$year,$wday) = localtime($yobi7);
	$mon  = $mon+1;
	$year = $year + 1900;
	$date = "$year년$mon월$mday일  $hour시$min분";
	
#직무의 표시 조정
	&yakusyoku_hyouzi($yobi2);
#리스트를 순서에 표시
						print <<"EOM";
<tr class=sita bgcolor=#dddddd><td align=center >$id</td><td align=center ><a href=$script?mode=kensaku&command=kozin_file&id=$id&name=$name&password=$in{'password'}>$name</a></td><td align=center >$seibetu_hyouzi</td><td align=right>$yobi6만</td><td align=center >$haiguu</td><td align=left>$yobi3</td><td align=center >$yakusyoku</td><td align=right>$yobi4회</td><td align=left>$date</td><td align=left>$yobi12</td></tr>
EOM
		}	#foreach 닫아
		print "<tr  class=sita bgcolor=#ffffcc><td colspan=10>이하전참가자의 리스트</td></tr>";
	}

	foreach $one(@alldata) {
($id,$name,$pass,$money,$basyo,$haiguu,$kodomo,$love,$land,$house,$kabu,$kounyuu,$sex,$yobi1,$yobi2,$yobi3,$yobi4,$yobi5,$yobi6,$yobi7,$yobi8,$yobi9,$yobi10,$yobi11,$yobi12,$yobi13,$yobi14)= split(/<>/,$one);
#성별 표시를 정형
	if($sex eq "m"){$seibetu_hyouzi = "남";$m_count ++ ;}else{$seibetu_hyouzi = "녀";$f_count ++ ;}
	
#최종 보존 표시를 정형
	$ENV{'TZ'} = "JST-9";
	($sec,$min,$hour,$mday,$mon,$year,$wday) = localtime($yobi7);
	$mon  = $mon+1;
	$year = $year + 1900;
	$date = "$year년$mon월$mday일  $hour시$min분";
	
#직무의 표시 조정
	&yakusyoku_hyouzi($yobi2);
#리스트를 순서에 표시
						print <<"EOM";
<tr class=sita><td align=center >$id</td><td align=center ><a href=$script?mode=kensaku&command=kozin_file&id=$id&name=$name&password=$in{'password'}>$name</a></td><td align=center >$seibetu_hyouzi</td><td align=right>$yobi6만</td><td align=center >$haiguu</td><td align=left>$yobi3</td><td align=center >$yakusyoku</td><td align=right>$yobi4회</td><td align=left>$date</td><td align=left>$yobi12</td></tr>
EOM
		}	#foreach 닫아

	close(IN);
	$total_count=$m_count+$f_count;
	print <<"EOM";
</table>
	<center><br>
<a href=$script?mode=itiran&password=$in{'password'}><span class=sub3>[ID 순서]</span></a><img src=$img_dir/space.gif width=5 height=1>
<a href=$script?mode=itiran&sort_id=18&password=$in{'password'}><span class=sub3>[총자산]</span></a><img src=$img_dir/space.gif width=5 height=1>
<a href=$script?mode=itiran&sort_id=12&password=$in{'password'}><span class=sub3>[성별]</span></a><img src=$img_dir/space.gif width=5 height=1>
<a href=$script?mode=itiran&sort_id=1&password=$in{'password'}><span class=sub3>[이름]</span></a><img src=$img_dir/space.gif width=5 height=1>
<a href=$script?mode=itiran&sort_id=19&password=$in{'password'}><span class=sub3>[데이터 보존]</span></a><img src=$img_dir/space.gif width=5 height=1>
<a href=$script?mode=itiran&sort_id=0&password=$in{'password'}><span class=sub3>[신규 등록순서]</span></a><img src=$img_dir/space.gif width=5 height=1>
<a href=$script?mode=itiran&sort_id=24&password=$in{'password'}><span class=sub3>[호스트순서(다중 등록자)]</span></a>
</center>
<br><div align=center>총등록자수：$total_count인 남성：$m_count인 여성：$f_count인<br><br>
<a href=$script?password=$in{'password'}>돌아온다</a></div>
	</body></html>
EOM
	exit;
}
sub kensaku {
	if($in{'command'} eq "kozin_file"){
			$hukkatu_flag=1;
			$my_log_file = "./member/"."$in{'id'}"."log.cgi";
			open(MYL,"$my_log_file") || &error("로그 파일($my_log_file)이 열리지 않습니다");
			$my_prof = <MYL>;
			&split_var2($my_prof);
			close(MYL);
			$hukkatu_botan= <<"EOM";
	<form method="POST" action="$script">
	<input type=hidden name=mode value="deletUsr">
	<input type=hidden name=command value="del_kakunin">
	<input type=hidden name=name value="$name">
	<input type=hidden name=password value="$in{'password'}">
	<input type=submit value="이 유저를 삭제한다">
	</form>
EOM
			$page_comment = "$name씨의 개인 파일 데이터입니다.";
	}else{
			open(HUK,"$logfile") || &error("Open Error : $logfile");
			$hukkatu_flag=0;
			while (<HUK>) {
					&split_var;
					if($in{'name'} eq $name){$hukkatu_flag=1;last;}
			}
			close(HUK);
			$hukkatu_botan= <<"EOM";
	<form method="POST" action="$script">
	<input type=hidden name=mode value="dataHukkatu">
	<input type=hidden name=name value="$name">
	<input type=hidden name=password value="$in{'password'}">
	<input type=submit value="이 데이터 내용으로 개인 파일을 부활시킨다">
	</form>
EOM
			$page_comment = "랭킹 데이터에 보존되고 있는$name씨의 데이터입니다.";
	}
	if($hukkatu_flag == 0){&error("그 이름에서는 등록되어 있지 않습니다!");}
		&header(2);
#토지의 표시형을 정형
	if($land ne "없음"){
			($toti_basyo,$tubosuu,$toti_kounyuugaku)= split(/,/,$land);
			$land_hyouzi="$toti_basyo($tubosuu평)";
	}else{$land_hyouzi = "없음";$toti_kounyuugaku="0";}
#집의 표시형을 정형
	if($house ne "없음"){
			($house_style,$ie_kounyuugaku)= split(/,/,$house);
	}else{$house_style = "없음";$ie_kounyuugaku="0";}
#주식의 표시형을 정형
	if($kabu ne "없음"){
			($meigara,$hitokabu,$agari,$sagari,$kazu,$syokiti)= split(/,/,$kabu);
			$urine=$hitokabu*$kazu;
			$kabuhyouzi="$meigara($hitokabu만×$kazu주)";
	}else{
			$kabuhyouzi="없음";
			$urine="0";
	}
	
#직무의 표시 조정
	&yakusyoku_hyouzi($yobi2);
	
#성별 표시를 정형
	if($sex eq "m"){$seibetu_hyouzi = "남";}else{$seibetu_hyouzi = "녀";}
	
#최종 보존 시간표시를 정형
	$ENV{'TZ'} = "JST-9";
	($sec,$min,$hour,$mday,$mon,$year,$wday) = localtime($yobi7);
	$mon  = $mon+1;
	$year = $year + 1900;
	$date = "$year/$mon/$mday  $hour : $min";
	
#액세스 시간표시를 정형
	$ENV{'TZ'} = "JST-9";
	($a_sec,$a_min,$a_hour,$a_mday,$a_mon,$a_year,$a_wday) = localtime($yobi10);
	$a_mon  = $a_mon+1;
	$a_year = $a_year + 1900;
	$access_date = "$a_year/$a_mon/$a_mday  $a_hour : $a_min";
	
					print <<"EOM";
	<div align=right class=midasi>$page_comment</div>
	<table width="80%" border="1" cellspacing="0" cellpadding="3" align=center>
	<tr><td width=30% align=right>이름</td><td>$name</td></tr>
	<tr><td align=right>성별</td><td>$seibetu_hyouzi</td></tr>
	<tr><td align=right>직무</td><td>$yakusyoku</td></tr>
	<tr><td align=right>패스워드</td><td>$pass</td></tr>
	<tr><td align=right>소유금</td><td>$money만</td></tr>
	<tr><td align=right>은행예금</td><td>$yobi5만</td></tr>
	<tr><td align=right>슈퍼 정기예금</td><td>$yobi9만</td></tr>
	<tr><td align=right>총자산</td><td>$yobi6만</td></tr>
	<tr><td align=right>배우자</td><td>$haiguu</td></tr>
	<tr><td align=right>아이</td><td>$kodomo</td></tr>
	<tr><td align=right>연인</td><td>$yobi3</td></tr>
	<tr><td align=right>러브도</td><td>$love</td></tr>
	<tr><td align=right>일스킬치</td><td>$yobi2</td></tr>
	<tr><td align=right>토지</td><td>$land_hyouzi</td></tr>
	<tr><td align=right>집</td><td>$house_style</td></tr>
	<tr><td align=right>주식</td><td>$kabuhyouzi</td></tr>
	<tr><td align=right>소유물</td><td>$kounyuu</td></tr>
	<tr><td align=right>CD발매 회수</td><td>$yobi8회</td></tr>
	<tr><td align=right>스타트 통과 회수</td><td>$yobi4회</td></tr>
	<tr><td align=right>현재의 반의 위치</td><td>$basyo</td></tr>
	<tr><td align=right>형무소 플래그</td><td>$yobi1</td></tr>
	<tr><td align=right>호스트</td><td>$yobi12</td></tr>
	<tr><td align=right>최종 액세스</td><td>$access_date</td></tr>
	<tr><td align=right>최종 데이터 보존</td><td>$date</td></tr></table>
	<br><div align=center>
			$hukkatu_botan
	<br><a href=\"javascript:history.back()\"> [앞에 화면으로 돌아온다] </a></div>
	</body></html>
EOM
exit;
}


sub dataHukkatu {
					&lock;
	open(HUK,"$logfile") || &error("Open Error : $logfile");
	$hukkatu_flag=0;
	while (<HUK>) {
			&split_var;
			if($in{'name'} eq $name){$hukkatu_flag=1;last;}
	}
	close(HUK);
	if($hukkatu_flag == 0){&error("그 이름에서는 등록되어 있지 않습니다!");}
					$my_log_file = "./member/$id"."log.cgi";
					$my_temp="$id<>$name<>$pass<>$money<>$basyo<>$haiguu<>$kodomo<>$love<>$land<>$house<>$kabu<>$kounyuu<>$sex<>$yobi1<>$yobi2<>$yobi3<>$yobi4<>$yobi5<>$yobi6<>$yobi7<>$yobi8<>$yobi9<>$yobi10<>$yobi11<>$yobi12<>$yobi13<>$yobi14<>\n";
					open(HU,">$my_log_file") || &error("Open Error : $my_log_file");
					print HU $my_temp;
					close(HU);
					&unlock;
					&message("$name씨의 데이터를 부활시켰습니다.");
}

sub backup_change {
				&lock;
				open(DA,"back_up.cgi") || &error("Open Error : back_up.cgi");
				@backup_data= <DA>;
				close(DA);
				
# 로그를 갱신
#ver.1.36 여기로부터
		$err = data_save($logfile, @backup_data);
		if ($err) {&error("$err");}
#	&renameLock1;
#	open(BACKOUT,">$tmpFile") || &error("$tmpFile가 열리지 않습니다");
#	print BACKOUT @backup_data;
#	close(BACKOUT);
#	&renameLock2("$logfile");
#ver.1.36여기까지
				&unlock;
				&message("랭킹 파일을 백업 데이터로 전환했습니다.");
}

sub kodomo_change {
				&lock;
				open(KD,"kodomo_back.cgi") || &error("Open Error : kodomo_back.cgi");
				@kodomo_backup= <KD>;
				close(KD);
#ver.1.36 여기로부터
		$err = data_save($kodomo_file, @kodomo_backup);
		if ($err) {&error("$err");}
#				open(KDOUT,">$kodomo_file") || &error("$kodomo_file가 열리지 않습니다");
#				print KDOUT @kodomo_backup;
#				close(KDOUT);
#ver.1.36여기까지
				&unlock;
				&message("아이 파일을 백업 데이터로 전환했습니다.");
}

sub item_change {
				&lock;
				open(IFE,"item_back_log.cgi") || &error("Open Error : item_back_log.cgi");
				@item_backup= <IFE>;
				close(IFE);
#ver.1.36 여기로부터
		$err = data_save($item_file, @item_backup);
		if ($err) {&error("$err");}
#				open(IFO,">$item_file") || &error("$item_file가 열리지 않습니다");
#				print IFO @item_backup;
#				close(IFO);
#ver.1.36여기까지
				&unlock;
				&message("아이템 기록 파일을 백업 데이터로 전환했습니다.");
}

sub split_var{
($id,$name,$pass,$money,$basyo,$haiguu,$kodomo,$love,$land,$house,$kabu,$kounyuu,$sex,$yobi1,$yobi2,$yobi3,$yobi4,$yobi5,$yobi6,$yobi7,$yobi8,$yobi9,$yobi10,$yobi11,$yobi12,$yobi13,$yobi14)= split(/<>/);
#yobi1:눈의 회수(형무소용)　yobi2:일스킬치 　yobi3:연인　yobi4:스타트 통과 회수　yobi5:저금　yobi6:총자산　yobi7:최종 데이터 갱신 시간　yobi8:CD발매 회수　yobi9:슈퍼 정기예금
}

sub split_var2{
($id,$name,$pass,$money,$basyo,$haiguu,$kodomo,$love,$land,$house,$kabu,$kounyuu,$sex,$yobi1,$yobi2,$yobi3,$yobi4,$yobi5,$yobi6,$yobi7,$yobi8,$yobi9,$yobi10,$yobi11,$yobi12,$yobi13,$yobi14)= split(/<>/,@_[0]);
#yobi1:눈의 회수(형무소용)　yobi2:일스킬치 　yobi3:연인　yobi4:스타트 통과 회수　yobi5:저금　yobi6:총자산　yobi7:최종 데이터 갱신 시간　yobi8:CD발매 회수　yobi9:슈퍼 정기예금　yobi10:최종 액세스 시간
}

sub deletUsr {
	if($in{'command'} eq "del_kakunin"){
			&header(2);
			print <<"EOM";
			<br><br><div align=center>$in{'name'}씨를 삭제합니다.좋습니까?
			<form method="POST" action="$script">
			<input type=hidden name=mode value="deletUsr">
			<input type=hidden name=name value="$in{'name'}">
			<input type=hidden name=password value="$in{'password'}">
			<input type=submit value="O K">
			</form></div>
			</body></html>
EOM
			exit;
	}
	&lock;
	open(IN,"$logfile") || &error("Open Error : $logfile");
	@rankingMember = <IN>;
		foreach (@rankingMember) {
			&split_var;
			if($in{'name'} eq $name){ 
#연인의 리스트로부터 자신의 이름을 지운다
				&checkMyKoibito($id);
				if($return_koibito_name ne ""){
					(@my_koibitos)= split(/,/,$return_koibito_name);
					foreach $my_koibito (@my_koibitos){
							&id_check ($my_koibito);
							&koibitoSakujo($return_id,$name);
							&sakujoMessageSend($return_id,$name,2);
					}
				}
#배우자의 리스트로부터 자신의 이름을 지운다
				if($return_haiguu_name ne "독신"){
					&id_check ($return_haiguu_name);
					&haiguuSakujo($return_id,$name);
					&sakujoMessageSend($return_id,$name,1);
				}
#아이 파일로부터 부모의 이름을 지운다
					&rikon_kodomo($name);
#개인 데이터 삭제
					unlink ("./member/$id" . ".cgi");
					unlink ("./member/$id" . "log.cgi");
					next;
			}		#if가 닫아
				push @alldata,$_;
	}		#foreach가 닫아
	close(IN);
#ver.1.36 여기로부터
		$err = data_save($logfile, @alldata);
		if ($err) {&error("$err");}
		
#	&renameLock1;
#	open(OUT,">$tmpFile") || &error("$tmpFile가 열리지 않습니다");
#	print OUT @alldata;
#	close(OUT);
#	&renameLock2("$logfile");
#ver.1.36여기까지
	&unlock;
	&message("$in{'name'}씨를 삭제했습니다.");
}

#유저 삭제시의 배우자로부터 자신을 지우는 써브루틴
sub haiguuSakujo {
my($id,$name,$pass,$money,$basyo,$haiguu,$kodomo,$love,$land,$house,$kabu,$kounyuu,$sex,$yobi1,$yobi2,$yobi3,$yobi4,$yobi5,$yobi6,$yobi7,$yobi8,$yobi9,$yobi10,$yobi11,$yobi12,$yobi13,$yobi14);
							$aite_log_file = "./member/"."@_[0]"."log.cgi";
							open(AIT,"$aite_log_file") || &error("상대의 분의 로그 파일($aite_log_file)이 열리지 않습니다.<br>데이터 갱신이 아직 끝나지 않는 것 같습니다.");
							$aite_prof = <AIT>;
							if($aite_prof == ""){&error("상대의 분의 로그 파일에 문제가 있습니다.");}
($id,$name,$pass,$money,$basyo,$haiguu,$kodomo,$love,$land,$house,$kabu,$kounyuu,$sex,$yobi1,$yobi2,$yobi3,$yobi4,$yobi5,$yobi6,$yobi7,$yobi8,$yobi9,$yobi10,$yobi11,$yobi12,$yobi13,$yobi14)= split(/<>/,$aite_prof);
							close(AIT);
							if("@_[1]" eq "$haiguu"){
										$haiguu = "독신";
							}
$temp="$id<>$name<>$pass<>$money<>$basyo<>$haiguu<>$kodomo<>$love<>$land<>$house<>$kabu<>$kounyuu<>$sex<>$yobi1<>$yobi2<>$yobi3<>$yobi4<>$yobi5<>$yobi6<>$yobi7<>$yobi8<>$yobi9<>$yobi10<>$yobi11<>$yobi12<>$yobi13<>$yobi14<>\n";
	open(OUT,">$aite_log_file") || &error("$aite_log_file가 열리지 않습니다");
	print OUT $temp;
	close(OUT);
}

sub header {
	if (@_[0] eq "2"){$bgcolor="#ffffff";}
	print "Content-type: text/html; charset=UTF-8\n\n";
	print "<html>\n<head>\n";
	print "<META HTTP-EQUIV=\"Content-type\" CONTENT=\"text/html; charset=UTF-8\">\n";
	print "<title>인생의 게임 관리자 메뉴</title>\n";
	print <<"EOM";
	<script language="JavaScript">
<!--
function CH2(P1){
		window.open(P1,"_top");
}
//-->
</script>
<style type="text/css">
<!--
.midasi {  font-size: 14px; font-weight: bold; text-align: center;color: #0066ff}
.midasi2{  font-size: 14px; font-weight: bold; text-align: center;color: #ff3300}
.purasu {  font-size: 13px; color: #009900;line-height:180%}
.purasu2 {  font-size: 13px; color: #cc9900;line-height:180%}
.mainasu {  font-size: 13px; color: #ff3300;line-height:180%}
.kuro {  font-size: 13px; text-align: left;color: #ff6600}
.honbun {  font-size: 11px; line-height: 16px; color: #000000}
.honbun2 {  font-size: 11px; line-height: 18px; color: #99000}
.loto {  font-size: 28px; color: #000000;line-height:180%;}
.honbun3 {  font-size: 12px; line-height: 16px; color: #000000;ine-height:180%}
.sumi {  font-size: 11px; border: #000000; border-style: solid; border-top-width: 1px; border-right-width: 1px; border-bottom-width: 1px; border-left-width: 1px}
.sumi2{  border: #ff9933; border-style: dotted; border-top-width: 2px; border-right-width: 2px; border-bottom-width: 2px; border-left-width: 2px}
.migi {  border: #000000; border-style: solid; border-top-width: 1px; border-right-width: 1px; border-bottom-width: 1px; border-left-width: 0px}
.sita {  font-size: 11px; border: #000000; border-style: solid; border-top-width: 0px; border-right-width: 1px; border-bottom-width: 1px; border-left-width: 1px}
.naka {  border: #000000; border-style: solid; border-top-width: 1px; border-right-width: 0px; border-bottom-width: 1px; border-left-width: 0px}
a {color:#ff3300;text-decoration: none}
a:hover {text-decoration: underline}
body {font-size:12px;color:#000000 }
table {font-size:12px;color:#000000 }
-->
</style>
EOM
	print "</head><body bgcolor=$bgcolor>\n";
}

#메세지 화면 출력
sub message {
&header(2);
	# 락 플래그가 있으면 락 디렉토리를 삭제
	if ($lockflag) { &unlock; }
	print <<"EOM";
	<div align=center>
	<br><br>$_[0]<br><br>
		<a href=$script?password=$in{'password'}>돌아온다</a>
	</div>
	</body></html>
EOM
exit;
}

#에러 화면 출력
sub error {
&header(2);
	# 락 플래그가 있으면 락 디렉토리를 삭제
	if ($lockflag) { &unlock; }

	print "<br><center><h3><font color=#ff3300>ERROR !</font></h3>\n";
	print "<font color='#000000'>$_[0]</font>\n";
	print "<br><a href=\"javascript:history.back()\"> [앞에 화면으로 돌아온다] </a>";
	print "<P></center>\n";
	print "</body></html>\n";
	exit;
}
sub error2{
	# 락 플래그가 있으면 락 디렉토리를 삭제
	if ($lockflag) { &unlock; }
	print "<br><center><h3><font color=#ff3300>ERROR !</font></h3>\n";
	print "<font color='#000000'>$_[0]</font>\n";
	print "<br><a href=$script target=_top> [종료] </a>";
	print "<P></center>\n";
	print "</body></html>\n";
	exit;
}

sub lock {
	local($retry, $mtime);

	# 1분 이상 낡은 락은 삭제한다
	if (-e $lockfile) {
		($mtime) = (stat($lockfile))[9];
		if ($mtime < time - 60) { &unlock; }
	}

	# 리트라이는 10회
	$retry = 10;
	while (!mkdir($lockfile, 0755)) {
		if (--$retry <= 0) { &error('지금  사이트가 붐비고 있습니다.조금 기다려 주세요.'); }
		sleep(1);
	}
	# 락 플래그를 세운다
	$lockflag=1;
}


########  락 해제  
sub unlock {
	# 락 디렉토리 삭제
	rmdir($lockfile);

	# 락 플래그를 해제
	$lockflag=0;
}

#유저 삭제시의 연인으로부터 자신을 지우는 써브루틴
sub koibitoSakujo {
my($id,$name,$pass,$money,$basyo,$haiguu,$kodomo,$love,$land,$house,$kabu,$kounyuu,$sex,$yobi1,$yobi2,$yobi3,$yobi4,$yobi5,$yobi6,$yobi7,$yobi8,$yobi9,$yobi10,$yobi11,$yobi12,$yobi13,$yobi14);
							$aite_log_file = "./member/"."@_[0]"."log.cgi";
							open(AIT,"$aite_log_file") || &error("상대의 분의 로그 파일($aite_log_file)이 열리지 않습니다.<br>데이터 갱신이 아직 끝나지 않는 것 같습니다.");
							$aite_prof = <AIT>;
							if($aite_prof == ""){&error("상대의 분의 로그 파일에 문제가 있습니다.");}
($id,$name,$pass,$money,$basyo,$haiguu,$kodomo,$love,$land,$house,$kabu,$kounyuu,$sex,$yobi1,$yobi2,$yobi3,$yobi4,$yobi5,$yobi6,$yobi7,$yobi8,$yobi9,$yobi10,$yobi11,$yobi12,$yobi13,$yobi14)= split(/<>/,$aite_prof);
							close(AIT);
										undef @new_aite_koibito;
										(@koibito)= split(/,/,$yobi3);
										foreach $one_koibito (@koibito){
												if("@_[1]" eq "$one_koibito"){next;}
												push (@new_aite_koibito,$one_koibito);
										}
										$yobi3 = join(",",@new_aite_koibito);
$temp="$id<>$name<>$pass<>$money<>$basyo<>$haiguu<>$kodomo<>$love<>$land<>$house<>$kabu<>$kounyuu<>$sex<>$yobi1<>$yobi2<>$yobi3<>$yobi4<>$yobi5<>$yobi6<>$yobi7<>$yobi8<>$yobi9<>$yobi10<>$yobi11<>$yobi12<>$yobi13<>$yobi14<>\n";
	open(OUT,">$aite_log_file") || &error("$aite_log_file가 열리지 않습니다");
	print OUT $temp;
	close(OUT);
}

#이혼했을 경우의 아이 파일에의 기록
sub rikon_kodomo {
	open(KF,"$kodomo_file") || &error("Open Error : $kodomo_file");
					undef @new_oya;
			while (<KF>) {
					($k_id,$k_name,$oya1,$oya2,$seinengappi,$atama,$sports,$art,$food_time,$k_yobi2,$k_yobi3,$k_yobi4,$k_yobi5)= split(/<>/);
					if(@_[0] eq $oya1){
							$oya1 = "";
					}
					if(@_[0] eq $oya2){
							$oya2 = "";
					}
					$k_temp="$k_id<>$k_name<>$oya1<>$oya2<>$seinengappi<>$atama<>$sports<>$art<>$food_time<>$k_yobi2<>$k_yobi3<>$k_yobi4<>$k_yobi5<>\n";
					push (@new_oya,$k_temp);
			}
						close(KF);
# 로그를 갱신
#ver.1.36 여기로부터
		$err = data_save($kodomo_file, @new_oya);
		if ($err) {&error("$err");}
#						open(KOUT,">$kodomo_file") || &error("Write Error : $kodomo_file");
#						print KOUT @new_oya;
#						close(KOUT);
#ver.1.36여기까지
}

#연인이 삭제한 취지의 메세지 송신
sub sakujoMessageSend {
			if(@_[2] eq "1"){
						$naiyou = "haiguuSakujo";
						$message_in="@_[1]씨의 데이터가 삭제되었으므로 배우자로부터 소거했습니다.";
			}elsif(@_[2] eq "2"){
						$naiyou = "koibitoSakujo";
						$message_in="@_[1]씨의 데이터가 삭제되었으므로 연인으로부터 소거했습니다.";
			}
$member_file="./member/@_[0]" . ".cgi";
			open(MM,"$member_file") || &error("Open Error : $member_file가 열리지 않습니다.");
						undef @newrank;
						$topmesse=<MM>;
						($kibou_type,$m_name,$m_messe,$m_money,$m_land,$m_house,$m_number,$m_id,$kekka,$m_yobi4)= split(/<>/, $topmesse);
						$m_number ++;
						$newrank[0]="$naiyou<><>$message_in<><><><>$m_number<><><><>\n";
						$newrank[1]="$topmesse";
						while (<MM>) {
							push(@newrank,$_);
						}		#while가 닫아
			close(MM);
			open(MMO,">$member_file") || &error("Write Error : $member_file");
			print MMO @newrank;
			close(MMO);	
}

#id번호 획득 써브루틴
sub id_check{
			my($id,$name,$pass,$money,$basyo,$haiguu,$kodomo,$love,$land,$house,$kabu,$kounyuu,$sex,$yobi1,$yobi2,$yobi3,$yobi4,$yobi5,$yobi6,$yobi7,$yobi8,$yobi9,$yobi10,$yobi11,$yobi12,$yobi13,$yobi14);
	open(IC,"$logfile") || &error("Open Error : $logfile");
	$name_flag=0;
	while (<IC>) {
($id,$name,$pass,$money,$basyo,$haiguu,$kodomo,$love,$land,$house,$kabu,$kounyuu,$sex,$yobi1,$yobi2,$yobi3,$yobi4,$yobi5,$yobi6,$yobi7,$yobi8,$yobi9,$yobi10,$yobi11,$yobi12,$yobi13,$yobi14)= split(/<>/);
				if($name eq @_[0]){$name_flag=1;last;}
	}
	$return_id=$id;
	if($name_flag==0){$return_id="";}
	close(IC);
}

sub checkMyKoibito {
		$my_log_file = "./member/"."@_[0]"."log.cgi";
		if(-e $my_log_file){
		open(MYL,"$my_log_file") || &error("로그 파일($my_log_file)이 열리지 않습니다.<br>재차 로그인해도 동일한 관리인($master_ad)까지 메일을 주세요.");
		$my_prof = <MYL>;
		if($my_prof == ""){&error("로그 파일에 문제가 일어났습니다.<br>수고스럽겠지만, 관리인($master_ad)까지 메일을 주세요.");}
		&split_var2($my_prof);
		close(MYL);
		$return_koibito_name = $yobi3;
		$return_haiguu_name = $haiguu;
		}else{
		$return_koibito_name = "";
		$return_haiguu_name = "";
		}
}

#직무 써브루틴
sub yakusyoku_hyouzi {
	if (@_[0] < 50){$yakusyoku="견습";}
	elsif(@_[0] < 100){$yakusyoku="신입사원";}
	elsif(@_[0] < 150){$yakusyoku="평사원";}
	elsif(@_[0] < 200){$yakusyoku="주임";}
	elsif(@_[0] < 250){$yakusyoku="계장";}
	elsif(@_[0] < 300){$yakusyoku="과장";}
	elsif(@_[0] < 500){$yakusyoku="부장";}
	elsif(@_[0] < 700){$yakusyoku="상무";}
	elsif(@_[0] < 900){$yakusyoku="전무";}
	elsif(@_[0] < 1200){$yakusyoku="사장";}
	elsif(@_[0] < 1500){$yakusyoku="회장";}
	elsif(@_[0] < 1800){$yakusyoku="명예회장";}
	elsif(@_[0] < 2200){$yakusyoku="대신";}
	elsif(@_[0] < 2600){$yakusyoku="수상";}
	elsif(@_[0] < 3000){$yakusyoku="대통령";}
	elsif(@_[0] < 3500){$yakusyoku="슈퍼스타";}
	elsif(@_[0] < 4000){$yakusyoku="갓 파더";}
	elsif(@_[0] < 4500){$yakusyoku="킹";}
	elsif(@_[0] < 10000){$yakusyoku="신";}
	elsif(@_[0] < 11000){$yakusyoku="정년퇴직자";}
	elsif(@_[0] < 13000){$yakusyoku="노인";}
	elsif(@_[0] >= 13000){$yakusyoku="전설의 사람";}
}

