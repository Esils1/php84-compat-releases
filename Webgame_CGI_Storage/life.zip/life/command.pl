#연애 화면 출력
sub kokuhaku {
#신청 메세지 처리
		if ($in{'command'} eq "mousikomi"){
						if($in{'messe'}  =~ /,/){&error("「,」(은)는 사용하지 말아 주세요");}
						if($in{'messe'}  =~ /<>/){&error("「<>」은 사용하지 말아 주세요");}
			if ($in{'kibou'} eq "교제 대답"){
#ok라면 두 명의 로그 파일에 연인의 이름을 써
				if ($in{'sentaku'} eq "ok"){
#에러 체크
					&openMylog($in{'id'});
								(@koibito)= split(/,/,$yobi3);
								if($#koibito >= 2){&error("당신에게는 벌써 3명의 연인이 있기 위해 더이상 연인은 만들 수 없습니다");}
#상대의 파일을 갱신
					&openAitelog($in{'oaite'});
								if($in{'name'} eq $haiguu){&error("이 분은 당신의 배우자예요...(땀");}
								(@koibito)= split(/,/,$yobi3);
								foreach(@koibito){
									if($in{'name'} eq $_){&error("벌써 이 분은 당신의 연인입니다");}
								}
								if($#koibito >= 2){&error("상대에게는 벌써 3명의 연인이 있기 위해 더이상 연인은 만들 수 없습니다");}
								push (@koibito,$in{'name'});
								$yobi3=join(",",@koibito);
								
								&temp_routin;
								&log_kousin($aite_log_file,$temp);

#자신의 파일을 갱신
					&openMylog($in{'id'});
								(@koibito)= split(/,/,$yobi3);
								push (@koibito,$in{'aite_name'});
								$yobi3=join(",",@koibito);
								
								&temp_routin;
								&log_kousin($my_log_file,$temp);
				}		#if 문장(ok의 경우)이 덮어
			}elsif($in{'kibou'} eq "결혼 대답"){
############결혼 처리
#ok라면 두 명의 로그 파일에 배우자의 이름을 써
				if ($in{'sentaku'} eq "ok"){
#에러 체크
								if($in{'ie_sentaku'} eq "aite"){
										if($in{'aite_house'} eq "없음"){&error("상대는 집을 가지고 있지 않습니다!");}
								}
								if($in{'ie_sentaku'} eq "zibun"){
										if($in{'my_house'} eq "없음"){&error("당신은 집을 가지고 있지 않습니다!");}
								}
					&openAitelog($in{'oaite'});
								if($in{'name'} eq $haiguu){&error("벌써 이 분은 당신의 배우자입니다.");}
								if ($haiguu ne "독신"){&error("벌써 이 분은$haiguu씨와 결혼 하시고 있습니다.");}
					&openMylog($in{'id'});
								if ($haiguu ne "독신"){&error("당신은$haiguu씨와 결혼했기 때문에,<br>$haiguu씨와 헤어질 때까지 $in{'aite_name'}씨와 결혼할 수 없습니다.");}

#상대의 파일을 갱신
					&openAitelog($in{'oaite'});
								$haiguu = "$in{'name'}";
#상대의 아이 정보를 변수에 대입
								$aite_kodomo_umu = $kodomo;
#상대가 연인이었던 경우 상대의 연인 리스트로부터 지운다
								(@koibito)= split(/,/,$yobi3);
								foreach(@koibito){
									if($in{'name'} eq $_){next;}
									push(@new_your_koibito,$_);
								}
								$yobi3=join(",",@new_your_koibito);
#자신에게 아이가 있었을 경우 상대의 리스트에 아이를 추가
								(@kodomo_hairetu)= split(/,/,$kodomo);
								(@my_kodomo_hairetu)= split(/,/,$in{'my_child'});
								push(@kodomo_hairetu,@my_kodomo_hairetu);
								$kodomo=join(",",@kodomo_hairetu);
								
#집선택이 자신이었던 경우, 상대의 집을 갱신
								if($in{'ie_sentaku'} eq "zibun"){
										$land = "$in{'my_land'}";
										$house = "$in{'my_house'}";
								}

								&temp_routin;
								&log_kousin($aite_log_file,$temp);
#자신의 파일을 갱신
					&openMylog($in{'id'});
								$haiguu = "$in{'aite_name'}";
#상대에게 아이가 있는 경우, 자신의 리스트에 추가
								if($aite_kodomo_umu ne ""){
									(@kodomo_hairetu)= split(/,/,$aite_kodomo_umu);
									(@my_kodomo_hairetu)= split(/,/,$kodomo);
									push(@kodomo_hairetu,@my_kodomo_hairetu);
									$kodomo=join(",",@kodomo_hairetu);
								}
								
#자신과 상대에게 아이가 있었을 경우, 아이 파일에 상대의 이름(새로운 부모)을 기록
								&kekkon_kodomo($name,$in{'aite_name'});
								
#상대가 연인이었던 경우 자신의 연인 리스트로부터 지운다
								(@koibito)= split(/,/,$yobi3);
								foreach(@koibito){
									if($in{'aite_name'} eq $_){next;}
									push(@new_my_koibito,$_);
								}
								$yobi3=join(",",@new_my_koibito);
#집선택이 상대였던 경우, 자신의 집을 갱신
								if($in{'ie_sentaku'} eq "aite"){
										$land = "$in{'aite_land'}";
										$house = "$in{'aite_house'}";
								}

								&temp_routin;
								&log_kousin($my_log_file,$temp);
								
				}		#if 문장(ok의 경우)이 덮어
#송금의 경우
			}elsif ($in{'kibou'} eq "송금"){
#자신의 돈이 충분하면 송금분을 뺀다
					&openMylog($in{'id'});
						if($in{'kingaku'} ne ""){
										if($in{'kingaku'} <= 0){&error("마이너스의 돈을 송금할 수 없습니다!");}
										if ($in{'kingaku'} !~ /\d/){&error("입력액이 올바르지 않습니다");}
										if($money < $in{'kingaku'}){&error("돈이 충분하지 않습니다!");}
										else{$money=$money-$in{'kingaku'};}
						}
						if($in{'okurumono'} ne ""){
												(@kounyuus)= split(/,/,$kounyuu);
												undef @imaarumono;
												$syoyuu_flag=0;
												foreach (@kounyuus) {
														if ($_ eq "$in{'okurumono'}"){
															if ($syoyuu_flag !=1){
																$syoyuu_flag=1;next;
															}
														}
														push (@imaarumono,$_);
												}
												if($syoyuu_flag== 0){&error("벌써 그 소유물은 없습니다!");}
												$kounyuu=join(",",@imaarumono);
						}
								&temp_routin;
								&log_kousin($my_log_file,$temp);
#상대의 소유금에 플러스
					&openAitelog($in{'oaite'});
										$money=$money+$in{'kingaku'};
										(@kounyuus)= split(/,/,$kounyuu);
										push (@kounyuus,$in{'okurumono'});
										$kounyuu=join(",",@kounyuus);
								&temp_routin;
								&log_kousin($aite_log_file,$temp);
						
#아이 만들기의 경우
			}elsif ($in{'kibou'} eq "아이작"){
#에러 체크
						if (length($in{'messe'}) > 22) { &error("아이의 이름은 전각으로 10 문자 이내로 해 주세요."); }
#클릭한 메일을 소거
						&kodomo_messe_delete($in{'id'},$in{'mail_no'});
#아이의 이름이 등록되지 않은가 체크
						open(KF,"$kodomo_file") || &error("Open Error : $kodomo_file");
						@kodomo_name_check=<KF>;
						if(@kodomo_name_check == ''){&error("아이 파일에 문제가 있습니다.<br>수고스럽겠지만 관리인($master_ad)까지 보고해 주십시오.")}
						foreach (@kodomo_name_check) {
($k_id,$k_name,$oya1,$oya2,$seinengappi,$atama,$sports,$art,$food_time,$k_yobi2,$k_yobi3,$k_yobi4,$k_yobi5)= split(/<>/);
							if($in{'messe'} eq $k_name){ &error("그 아이의 이름은 벌써 등록되어 있습니다.다른 이름을 생각해 주세요.");}
							$k=$k_id;
							if($in{'name'} eq $oya1 && $k_yobi2 ne "on"){$kodomo_ninzuu ++;}
							if($in{'name'} eq $oya2 && $k_yobi2 ne "on"){$kodomo_ninzuu ++;}
						}
						close(KF);
						if($kodomo_ninzuu > 5){&error("아이가 만들 수 있는 것은 6명까지입니다");}
#아이 플래그를 0으로 한다
						$kodomoflag=0;
						if($in{'biyakuflag'} eq "on"){
							$randed=int(rand(3))+1;
						}else{
							$randed=int(rand(5))+1;
						}
#아이 탄생
					if($randed == 1){
						$kodomoflag=1;
#자신의 파일에 아이를 기입
					&openMylog($in{'id'});
										(@my_kodomo)= split(/,/,$kodomo);
										push (@my_kodomo,$in{'messe'});
										$kodomo = join(",",@my_kodomo);
								&temp_routin;
								&log_kousin($my_log_file,$temp);
#상대의 파일에 아이를 기입
					&openAitelog($in{'oaite'});
										$aite_name1= $name;
										(@your_kodomo)= split(/,/,$kodomo);
										push (@your_kodomo,$in{'messe'});
										$kodomo = join(",",@your_kodomo);
								&temp_routin;
								&log_kousin($aite_log_file,$temp);
#아이 파일에 기록
	$k ++;
	$now_time = time;		#ver.1.36
	$ENV{'TZ'} = "JST-9";
	($sec,$min,$hour,$mday,$mon,$year,$wday) = localtime($now_time);		#ver.1.36
	$umareta_time=  "$sec,$min,$hour,$mday,$mon,$year,$wday";
	$k_temp="$k<>$in{'messe'}<>$in{'name'}<>$aite_name1<>$umareta_time<>0<>0<>0<>$now_time<><><><><>\n";		#ver.1.36
	&lock;
	open(KOUT,">>$kodomo_file") || &error("Write Error : $kodomo_file");
	print KOUT $k_temp;
	close(KOUT);
	&unlock;
					}	#if 문장(아이가 생겼을 경우)이 덮어
#이혼의 경우
			}elsif ($in{'kibou'} eq "이혼"){
					&openMylog($in{'id'});
#자신의 돈이 충분하면 돈을 깎아 독신에게.집, 토지, 아이를 지운다.
										if($money < 200){
												&error("돈이 충분하지 않습니다!");
										}else{
											$haiguu="독신";
											$money=$money-200;
											$land="없음";
											$house="없음";
											$kodomo="";
											&rikon_kodomo($name);
										}
								&temp_routin;
								&log_kousin($my_log_file,$temp);
#배우자를 독신에게
					&openAitelog($in{'oaite'});
										$haiguu="독신";
										$money=$money+200;
								&temp_routin;
								&log_kousin($aite_log_file,$temp);

#헤어지는 경우
			}elsif ($in{'kibou'} eq "헤어진다"){
#자신의 연인 리스트로부터 지운다
					&openMylog($in{'id'});
										(@my_koibito)= split(/,/,$yobi3);
										foreach $my_one_koibito (@my_koibito){
												&id_check ($my_one_koibito);
												$my_koibito_id=$return_id;
												if($my_koibito_id eq $in{'oaite'}){next;}
												push (@new_my_koibito,$my_one_koibito);
										}
										$yobi3 = join(",",@new_my_koibito);
								&temp_routin;
								&log_kousin($my_log_file,$temp);
#상대의 연인 리스트로부터 자신을 지운다
					&openAitelog($in{'oaite'});
										(@koibito)= split(/,/,$yobi3);
										foreach $one_koibito (@koibito){
												&id_check ($one_koibito);
												$koibito_id=$return_id;
												if($koibito_id eq $in{'id'}){next;}
												push (@new_aite_koibito,$one_koibito);
										}
										$yobi3 = join(",",@new_aite_koibito);
								&temp_routin;
								&log_kousin($aite_log_file,$temp);

			}		#elsif(kibou의 커멘드가 있었을 경우)가 닫아
####상대의 사서함에의 써 처리
			if ($in{'kibou'} eq "연인" || $in{'kibou'} eq "결혼"){
					if ($in{'oaite'} eq ""){&error("상대를 선택해 주세요.");}
					if ($in{'messe'} eq ""){&error("고백의 대사를 입력해 주세요.");}
			}
			$mail_id=$in{'oaite'};
			$member_file="./member/$mail_id" . ".cgi";
			open(IN,"$member_file") || &error("Open Error : $member_file가 열리지 않습니다.");
						$topmesse=<IN>;
						($kibou_type,$m_name,$m_messe,$m_money,$m_land,$m_house,$m_number,$m_id,$kekka,$m_yobi4)= split(/<>/, $topmesse);
						$m_number ++;
						&time_get;
						$m_yobi4=$date_sec;
#송금이나 이혼, 헤어지는이었던 경우 메세지를 변경
						if ($in{'kibou'} eq "송금"){
								if($in{'kingaku'} ne ""){
									$message_in .="$in{'name'}씨보다 $in{'kingaku'}만의 송금이 있었습니다.<br>";
								}
								if($in{'okurumono'} ne ""){
									$message_in .="$in{'name'}씨가 $in{'okurumono'}를 보내 주었습니다.<br>";
								}
						}elsif ($in{'kibou'} eq "이혼") {
								$message_in="$in{'name'}씨보다 이혼의 신\해 넣어가 있었습니다.위자료로 해서 200만 지불되었습니다.";
						}elsif ($in{'kibou'} eq "헤어진다") {
								$message_in="$in{'name'}씨보다 안녕을 들었습니다.";
						}elsif ($in{'kibou'} eq "아이") {
								$message_in="$in{'messe'}";
						}elsif ($in{'kibou'} eq "아이작") {
								if($kodomoflag==0){
										$message_in="유감스럽지만 $in{'name'}씨와의 아이($in{'messe'})는 할 수 없었습니다.";
								}else{
										$message_in="축합니다!<br>$in{'name'}씨와의 사이에 아이가 태어났습니다.<br>이름은 「$in{'messe'}」입니다.";
								}
						}else{
								$message_in="$in{'messe'}($date2)";
						}
						$newrank[0]="$in{'kibou'}<>$in{'name'}<>$message_in<>$in{'money'}<>$in{'land'}<>$in{'house'}<>$m_number<>$in{'id'}<>$in{'sentaku'}<>$m_yobi4<>\n";
						$newrank[1]="$topmesse";
						while (<IN>) {
							push(@newrank,$_);
						}		#while가 닫아
			close(IN);
# 로그를 갱신
			&lock;
			open(OUT,">$member_file") || &error("Write Error : $member_file");
			print OUT @newrank;
			close(OUT);	
			&unlock;
			if ($in{'kibou'} eq "아이작"){
					if($kodomoflag==0){
							$kodomo_kekka= "<div style=font-size:14>유감스럽지만 아이는 할 수 없었습니다.</div><br><br>";
					}else{
							$kodomo_kekka= "<div style=font-size:14;color=#ff3300>축합니다!아이가 태어났습니다.</div><br><br>";
					}
					&header(2);
							print <<"EOM";
							<div align=center>
							<br><br>$kodomo_kekka
							<a href=$script?mode=login_view&name=$in{'name'}&pass=$in{'pass'}>돌아온다</a>
							</div>
							</body></html>
EOM
						exit;
			}
			&message("메세지를 전달했습니다.","login_view");
	}else{
####신청 화면
	&header(2);
	if ($in{'haiguu'} eq "독신"){
			$kibou_sentaku="<option value=결혼>결혼</option>\n<option value=연인>연인</option>";
	}else{$kibou_sentaku="<option value=연인>연인</option>";}
			print <<"EOM";
<table width="95%" border="0" cellspacing="0" cellpadding="0" align=center>
<tr><td>
<div align=center style=font-size:16px;color:#ff3300>고백 타임</div><br>
<div style=font-size:12px>LOVE도가 많은 상위$love_list인(기준치$love_kijun를 넘고 있는 사람만)으로 독신인 분의 리스트입니다.상대를 체크하고 나서, 아래의 폼으로 고백해 주세요.다만, 이 리스트에 나와 있어도, 상대가 데이터 갱신을 하고 있지 않는 것뿐으로, 벌써 결혼한 가\능\성이 있습니다.<br>
결혼하면 두 명은 같은 집을 소유하게 되기 위해, 결혼하기 위해서는, 당신이나 상대의 어느 쪽인지가 집을 가지고 있지 않으면 됩니다.두 사람 모두 집을 가지고 있었을 경우, 신\한 사람이 어느 쪽의 집으로 할까를 선택할 수 있습니다.결혼한 후, 어느 쪽인지가 집을 구입했을 경우, 배우자의 집도 동시에 변경됩니다.<br>
또, 연인 이상이 된다고 메세지의 교환이나 송금이 생기게 됩니다.다만, 연인이 만들 수 있는 것은 3명까지입니다.</div>
</td></tr></table>
     <form method="POST" action="$script">
	<input type=hidden name=mode value="kokuhaku">
	<input type=hidden name=command value="mousikomi">
	<input type=hidden name=name value="$in{'name'}">
	<input type=hidden name=pass value="$in{'pass'}">
	<input type=hidden name=money value="$in{'money'}">
	<input type=hidden name=land value="$in{'land'}">
	<input type=hidden name=house value="$in{'house'}">
	<input type=hidden name=id value="$in{'id'}">
	<input type=hidden name=kodomo value="$in{'kodomo'}">
	<table width="95%" border="0" cellspacing="0" cellpadding="5" align=center>
<tr class=sumi><td align=center>이름</td><td align=center>총자산</td><td align=center>직무</td><td align=center>LOVE도</td><td align=center>토지</td><td align=center>가</td></tr>
EOM
		open(IN,"$logfile") || &error("Open Error : $logfile");
		while (<IN>) {
				&split_var;
			$data=$_;
			chop $data;
			$key=(split(/<>/,$data))[7];		#소트 하는 요소를 선택한다
				if($in{'name'} eq $name){next;}
			push @all_alldata,$data;
			push @all_keys,$key;
				if($in{'sex'} eq $sex){next;}
				if($love < $love_kijun){next;}
				if($haiguu ne "독신"){next;}
			push @alldata,$data;
			push @keys,$key;
		}
			close(IN);
		sub bykeys{$keys[$b] <=> $keys[$a];}
		@alldata=@alldata[ sort bykeys 0..$#alldata]; 
		
		sub all_bykeys{$all_keys[$b] <=> $all_keys[$a];}
		@all_alldata=@all_alldata[ sort all_bykeys 0..$#all_alldata]; 
		
$i=1;
	foreach $one(@alldata) {
($id,$name,$pass,$money,$basyo,$haiguu,$kodomo,$love,$land,$house,$kabu,$kounyuu,$sex,$yobi1,$yobi2,$yobi3,$yobi4,$yobi5,$yobi6,$yobi7,$yobi8,$yobi9,$yobi10,$yobi11,$yobi12,$yobi13,$yobi14)= split(/<>/,$one);
#토지의 표시형을 정형
				if($land ne "없음"){
						($toti_basyo,$tubosuu)= split(/,/,$land);
						$land_hyouzi="$toti_basyo($tubosuu평)";
				}else{$land_hyouzi = "없음";}
#집의 표시형을 정형
				if($house ne "없음"){
						($house_style,$ie_kounyuugaku)= split(/,/,$house);
				}else{$house_style = "없음";}
				&yakusyoku_hyouzi($yobi2);
				
				print "<tr class=sita><td nowrap><input type=radio name=oaite value=$id>$name</td><td align=right>$yobi6만</td><td align=center>$yakusyoku</td><td align=center>$love</td><td align=center>$land_hyouzi</td><td align=center>$house_style</td></tr>\n";
				
			if($i >=$love_list){last;}
			$i++;
		}

	print <<"EOM";
	</table><br>
	<table width="95%" border="0" cellspacing="0" cellpadding="0" align=center>
	<tr><td>희망하는 관계 
	<select name="kibou">
	$kibou_sentaku
      </select>
	</td><td>고백의 대사 <input type=text name=messe size=30></td></tr>
	</table>
        <div align="center">
          <br><input type="submit" name="Submit2" value="신\한다"><br><br>
		  <a href=\"javascript:history.back()\"> [앞에 화면으로 돌아온다] </a>
        </div>
      </form>
	  <hr size=1>
<table width="95%" border="0" cellspacing="0" cellpadding="0" align=center>
<tr><td>
<div align=center style=font-size:16px;color:#ff3300>메세지 송신</div><br>
<div style=font-size:12px>독신, 기혼, 남녀, 관계없이 LOVE도가 많은 상위$love_list인(기준치$love_kijun를 넘고 있는 사람만)의 리스트입니다.여기로부터 상대에게 메세지 송신을 할 수 있습니다.상대를 체크하고 나서 아래에 메세지를 입력해 주세요.</div>
</td></tr></table>
     <form method="POST" action="$script">
	<input type=hidden name=mode value="kokuhaku">
	<input type=hidden name=command value="mousikomi">
	<input type=hidden name=name value="$in{'name'}">
	<input type=hidden name=pass value="$in{'pass'}">
	<input type=hidden name=id value="$in{'id'}">
	<input type=hidden name=kibou value="메시지">
	<table width="95%" border="0" cellspacing="0" cellpadding="5" align=center>
<tr class=sumi><td align=center>이름</td><td align=center>총자산</td><td align=center>직무</td><td align=center>LOVE도</td></tr>
EOM
	  
$i=1;
	foreach $all_one(@all_alldata) {
($id,$name,$pass,$money,$basyo,$haiguu,$kodomo,$love,$land,$house,$kabu,$kounyuu,$sex,$yobi1,$yobi2,$yobi3,$yobi4,$yobi5,$yobi6,$yobi7,$yobi8,$yobi9,$yobi10,$yobi11,$yobi12,$yobi13,$yobi14)= split(/<>/,$all_one);
				if($love < $love_kijun){next;}
				&yakusyoku_hyouzi($yobi2);
				
				print "<tr class=sita><td nowrap><input type=radio name=oaite value=$id>$name</td><td align=right>$yobi6만</td><td align=center>$yakusyoku</td><td align=right>$love</td></tr>\n";
				
			if($i >= $love_list){last;}
			$i++;
		}

	print <<"EOM";
	<tr><td colspan=4>
	메세지 <input type=text name=messe size=40><input type="submit" name="Submit2" value=" O K ">
	</td></tr>
	</table></form>
        <div align="center"><a href=\"javascript:history.back()\"> [앞에 화면으로 돌아온다] </a></div>
	</body></html>
EOM
	exit;
	}		#else가 닫아
}	#써브루틴이 닫아

#쇼핑 화면 출력
sub kaimono {
	&header(2);
					&openMylog($in{'id'});
	print <<"EOM";
     <form method="POST" action="$script">
	<input type=hidden name=mode value="kounyuu">
	<input type=hidden name=name value="$in{'name'}">
	<input type=hidden name=pass value="$in{'pass'}">
	<input type=hidden name=id value="$in{'id'}">
<table width="350" border="0" cellspacing="0" cellpadding="0" align=center>
<tr><td>
<div align=center style=font-size:16px;color:#ff9900>쇼핑</div><br>
<div style=font-size:12px;>구입하고 싶은 것에 체크를 넣어 OK버튼을 눌러 주세요.<br>
$name씨의 소유금：$money만</div><br>
</td></tr>
EOM
	while(($key,$val) = each %mono){
			push @keys,$key;
			push @values,$val;
	}
			sub by_tkeys{$values[$b] <=> $values[$a];}
		@t_rank=@keys[ sort by_tkeys 0..$#keys]; 
	foreach(@t_rank){
		print "<tr><td><input type=radio name=kaimono value=$_>$_</td><td align=right nowrap>$mono{$_}만</td></tr><tr><td colspan=2><hr size=1></td></tr>\n";
	}
	print <<"EOM";
	</table>
        <div align="center">
          <input type="submit" name="Submit2" value=" 구입 "><br><br>
		  <a href=\"javascript:history.back()\"> [앞에 화면으로 돌아온다] </a>
        </div>
      </form>
	</div>
	<hr size=1>
	<div align=center style=font-size:16px;color:#ff9900>소유물을 판다</div>
	     <form method="POST" action="$script">
	<input type=hidden name=mode value="monouri">
	<input type=hidden name=name value="$in{'name'}">
	<input type=hidden name=pass value="$in{'pass'}">
	<input type=hidden name=id value="$in{'id'}">
	<table width="350" border="0" cellspacing="0" cellpadding="0" align=center>
<tr><td>
<div style=font-size:12px;>팔고 싶은 것에 체크를 넣어 OK버튼을 눌러 주세요.판매가는 구입시의 50%입니다.</div>
EOM
	(@kounyuus)= split(/,/,$kounyuu);
	$kijun_over=$#kounyuus-15;
	if($kijun_over > 0){print "※현재, 소지 허용수가 세관 기준을$kijun_over개오버하고 있기 때문에, 세관에 걸렸을 경우, 소지품을 하나 빼앗겨 버립니다.<br><br></td></tr>\n";}
	else{print "※현재, 소지 허용수는 세관 기준을 클리어 하고 있습니다.<br><br></td></tr>\n";}
	&item_money_hash;
	foreach(@kounyuus){
				$urine=int(($mono{$_})/2) +int(($birthday{$_})/2) +$takara{$_}+int($item_money_hash{$_}/2);
				print "<tr><td><input type=radio name=urimono value=$_>$_</td><td align=right nowrap>$urine만</td></tr><tr><td colspan=2><hr size=1></td></tr>\n";
	}
	print <<"EOM";
	</table>
        <div align="center">
          <input type="submit" name="Submit2" value=" 매각 "><br><br>
		  <a href=\"javascript:history.back()\"> [앞에 화면으로 돌아온다] </a>
        </div>
      </form>
	</div>
	<hr size=1>
	<div align=center style=font-size:16px;color:#ff9900>아이템을 창작한다</div>
	     <form method="POST" action="$script">
	<input type=hidden name=mode value="item_create">
	<input type=hidden name=name value="$in{'name'}">
	<input type=hidden name=pass value="$in{'pass'}">
	<input type=hidden name=id value="$in{'id'}">
	<table width="350" border="0" cellspacing="0" cellpadding="0" align=center>
<tr><td>
이쪽에서 자신이 좋아하는 아이템을 만들 수 있습니다.생각한 아이템명을 입력하고 버튼을 눌러 주세요.다만, 다른 사람이 벌써 만든 아이템과 같은 이름에서는 작성할 수 없습니다.또 여기서 작성한 아이템은 연인이나 배우자의 생일 선물로서 메세지 송신 화면에서 줄 수 있습니다.<br>
※새롭게 만들 수 있는 오리지날 아이템은 선물 된 것도 포함 6까지입니다.<br><br>
아이템명 <input type=text size=15 name=item_name> <input type=submit value=" O K ">
</td></tr></table></form>
		  <div align=center><a href=\"javascript:history.back()\"> [앞에 화면으로 돌아온다] </a></div>
	</body></html>
EOM
	exit;
}
#쇼핑 구입 처리
sub kounyuu {
		$kattamono=$in{'kaimono'};
		&openMylog($in{'id'});
						if($money < $mono{$kattamono}){&error("돈이 충분하지 않습니다!");}
						(@kounyuus)= split(/,/,$kounyuu);
						push (@kounyuus,$kattamono);
						$kounyuu=join(",",@kounyuus);
						$money=$money-$mono{$kattamono};
	&temp_routin;
	&log_kousin($my_log_file,$temp);
	&message("$kattamono($mono{$kattamono}만)를 구입했습니다.","login_view");
}

#쇼핑 매각 처리
sub monouri {
		$uttamono=$in{'urimono'};
					&openMylog($in{'id'});
						(@kounyuus)= split(/,/,$kounyuu);
						$uriflag=0;
						foreach $motteru(@kounyuus){
								if($motteru =~ /$uttamono/ || $motteru =~ /도라에몽/){ # 아이템 개조 (한글) 2006.12.25 찬제
										if($uriflag != 1){
											$uriflag=1;next;
										}
								}

								push (@new_kounyuus,$motteru);
						}
						if($uriflag == 0){&error("그 아이템은 더이상 없습니다");}
						$kounyuu=join(",",@new_kounyuus);
						&item_money_hash;

						$urine=int(($mono{$uttamono})/2) +int(($birthday{$uttamono})/2) +$takara{$uttamono}+int($item_money_hash{$uttamono}/2);
						$money=$money+$urine;
								&temp_routin;
								&log_kousin($my_log_file,$temp);
						open(ITM,"$item_file") || &error("로그 파일($item_file)이 열리지 않습니다.");
						$uketori_flag=0;
						while (<ITM>) {
								($itemName,$syoyuusya,$syoyuusya_id,$job_up_ritu,$love_up_ritu,$money_up_ritu,$item_money_gaku,$present_uketori)= split(/<>/);
								if($uttamono eq $itemName){next;}
				$item_temp = "$itemName<>$syoyuusya<>$syoyuusya_id<>$job_up_ritu<>$love_up_ritu<>$money_up_ritu<>$item_money_gaku<>$present_uketori<>\n";
				push (@new_item,$item_temp);
						}
						close(ITM);
# 로그를 갱신
			&lock;
#ver.1.36 여기로부터
		$err = data_save($item_file, @new_item);
		if ($err) {&error("$err");}
			open(OUT,">$item_file") || &error("Write Error : $item_file");
			print OUT @new_item;
			close(OUT);	
#ver.1.36여기까지
			&unlock;
	&message("$uttamono($urine만)를 팔았습니다.","login_view");
}

#아이템 작성 처리
sub item_create {
		if($mono{$in{'item_name'}}  ne "" || $takara{$in{'item_name'}}  ne "" || $birthday{$in{'item_name'}}  ne ""){&error("그 아이템명은 벌써 사용되고 있습니다.다른 이름으로 시험해 주세요.");}
		if($in{'item_name'}  eq ""){&error("아이템명을 입력해 주세요");}
		if($in{'item_name'} =~ /면죄부/){&error("찬제의면죄부는 만들 수 없습니다.");}
		if($in{'item_name'}  =~ /,/){&error("아이템명에 「,」(은)는 사용하지 말아 주세요");}
		if($in{'item_name'}  =~ /<>/){&error("아이템명에 「<>」은 사용하지 말아 주세요");}
		if (length($in{'item_name'}) > 50) { &error("아이템명은 전각으로 25 문자 이내로 해 주세요."); }
		open(ITM,"$item_file") || &error("로그 파일($item_file)이 열리지 않습니다.");
				@items_name_check = <ITM>;
				if(@items_name_check == ''){&error("아이템 기록 파일에 문제가 있습니다.<br>수고스럽겠지만 관리인($master_ad)까지 보고해 주십시오.")}
		$item_suu = 0;
		foreach (@items_name_check) {
								($itemName,$syoyuusya,$syoyuusya_id,$job_up_ritu,$love_up_ritu,$money_up_ritu,$item_money_gaku,$present_uketori)= split(/<>/);
			if($syoyuusya eq $in{'name'} && $present_uketori eq ""){$item_suu ++;}
			if($in{'item_name'} eq $itemName){ &error("그 아이템명은 벌써 등록되어 있습니다.다른 이름으로 시험해 주세요.");}
		}
		close(ITM);
		if($item_suu >= 6){&error("새롭게 만들 수 있는 오리지날 아이템은 선물 된 것도 포함해라 6까지입니다.");}
	$randed1=int(rand(10))+1;
	$randed2=int(rand(10))+1;
	$randed3=int(rand(1000))+1;
	$job_item = $randed1*400;
	$love_item = $randed2*400;
	$money_item = $randed3*25;
	$item_name = $in{'item_name'};
#ver.1.36 여기로부터
	$item_name =~ s/"/&quot\;/g;
	$item_name =~ s/ /&nbsp\;/g;
	$item_name =~ s/　/&emsp\;/g;
#ver.1.36여기까지
	$item_money = $job_item + $love_item + $money_item;
	&header(2);
	print <<"EOM";
	<form method="POST" action="$script">
	<input type=hidden name=mode value="item_create_ok">
	<input type=hidden name=name value="$in{'name'}">
	<input type=hidden name=pass value="$in{'pass'}">
	<input type=hidden name=id value="$in{'id'}">
	<input type=hidden name=item_name value="$item_name">
	<input type=hidden name=job_up value="$randed1">
	<input type=hidden name=love_up value="$randed2">
	<input type=hidden name=money_up value="$randed3">
	<input type=hidden name=item_money value="$item_money">
	<table width="400" border="0" cellspacing="0" cellpadding="0" align=center>
	<tr><td class=purasu>
	<br><div align=center class=midasi>「$item_name」</div>
	이 아이템을 가지고 있으면…<br>
	●「스킬 업」에 그쳤을 때에 받을 수 있는 일스킬치=$randed1<br>
	●「LOVE」에 그쳤을 때에 받을 수 있는 러브 포인트=$randed2<br>
	●「급료」에 그쳤을 때 받을 수 있는 금액=$randed3만<br><br>
	이 아이템을 작성하려면 $item_money만 걸립니다.작성해도 괜찮습니까?<br>
	<div align=center><input type=submit value=" O K "></div>
	</td></tr></table>
	</form>
	<div align=center><a href=\"javascript:history.back()\"> [앞에 화면으로 돌아온다] </a></div>
EOM
	exit;
}

#아이템 작성 처리
sub item_create_ok {
	$lock;
#ver.1.36 여기로부터
	$sakusei_item_name = $in{'item_name'};
	$sakusei_item_name =~ s/"/&quot\;/g;
	$sakusei_item_name =~ s/ /&nbsp\;/g;
	$sakusei_item_name =~ s/　/&emsp\;/g;
#ver.1.36여기까지
		open(ITM,"$item_file") || &error("로그 파일($item_file)이 열리지 않습니다.");
		while (<ITM>) {
			($itemName)= split(/<>/);
			if($sakusei_item_name eq $itemName){ &error("그 이름은 벌써 등록되어 있습니다.");}
		}
		close(ITM);
	&openMylog($in{'id'});
				if($money < $in{'item_money'}){&error("돈이 충분하지 않습니다!");}
				$money = $money - $in{'item_money'};
								(@kounyuu_list)= split(/,/,$kounyuu);
								push (@kounyuu_list,$sakusei_item_name);
								$kounyuu=join(",",@kounyuu_list);
				&temp_routin;
				&log_kousin($my_log_file,$temp);
	$item_temp = "$sakusei_item_name<>$in{'name'}<>$in{'id'}<>$in{'job_up'}<>$in{'love_up'}<>$in{'money_up'}<>$in{'item_money'}<><>\n";
	open(ITMO,">>$item_file") || &error("로그 파일($item_file)이 열리지 않습니다.");
	print ITMO $item_temp;
	close(ITMO);
	&unlock;
	&message("$sakusei_item_name($in{'item_money'}만)를 작성했습니다.","login_view");
}

#########생일 선물 송신 처리
sub birthdayPresent {
#ver.1.36 여기로부터
	$okuraretamono_name = $in{'okurumono'};
	$okuraretamono_name =~ s/"/&quot\;/g;
	$okuraretamono_name =~ s/ /&nbsp\;/g;
	$okuraretamono_name =~ s/　/&emsp\;/g;
#ver.1.36여기까지
								&openMylog($in{'id'});
								(@kounyuus)= split(/,/,$kounyuu);
								undef @imaarumono;
								$syoyuu_flag=0;
								foreach (@kounyuus) {
										if ($_ eq "$okuraretamono_name"){$syoyuu_flag=1;next;}
										push (@imaarumono,$_);
								}
								if($syoyuu_flag== 0){&error("벌써 그 소유물은 없습니다!");}
								$kounyuu=join(",",@imaarumono);
								&temp_routin;
								&log_kousin($my_log_file,$temp);
		open(ITM,"$item_file") || &error("로그 파일($item_file)이 열리지 않습니다.");
		while (<ITM>) {
				($itemName,$syoyuusya,$syoyuusya_id,$job_up_ritu,$love_up_ritu,$money_up_ritu,$item_money_gaku,$present_uketori)= split(/<>/);
				if($itemName eq $okuraretamono_name){
						$present_uketori = $in{'oaite'};
				}
				$item_temp = "$itemName<>$syoyuusya<>$syoyuusya_id<>$job_up_ritu<>$love_up_ritu<>$money_up_ritu<>$item_money_gaku<>$present_uketori<>\n";
				push (@new_item,$item_temp);
		}
		close(ITM);
# 로그를 갱신
			&lock;
#ver.1.36 여기로부터
		$err = data_save($item_file, @new_item);
		if ($err) {&error("$err");}
#			open(OUT,">$item_file") || &error("Write Error : $item_file");
#			print OUT @new_item;
#			close(OUT);	
#ver.1.36여기까지
			&unlock;
			&message("선물을 맡았습니다.<br>상대의 분의 생일때에 선물은 전합니다.","login_view");
}


###########은행
sub ginkou {
		&openMylog($in{'id'});
				if ($in{'command'} eq "맡긴다"){
								if($in{'azukegaku'} <= 0){&error("마이너스의 돈은 맡겨지지 않습니다!");}
								if ($in{'azukegaku'} !~ /\d/){&error("입력액이 올바르지 않습니다");}
								if($in{'azukegaku'} > $money){&error("그렇게 돈을 가지지 않습니다!");}
								$yobi5=$yobi5+$in{'azukegaku'};
								$money=$money-$in{'azukegaku'};
								$message_in = "은행에 돈을 $in{'azukegaku'}만 맡겼습니다.";
				}elsif ($in{'command'} eq "내린다"){
								if($in{'orosigaku'} <= 0){&error("마이너스의 돈을 인출할 수 없습니다!");}
								if ($in{'orosigaku'} !~ /\d/){&error("입력액이 올바르지 않습니다");}
								if($in{'orosigaku'} > $yobi5){&error("은행에 그렇게 맡겨 있지 않습니다!");}
								$yobi5=$yobi5-$in{'orosigaku'};
								$money=$money+$in{'orosigaku'};
								$message_in = "은행으로부터 돈을 $in{'orosigaku'}만 내렸습니다.";
				}elsif ($in{'command'} eq "슈퍼"){
								if($in{'azukegaku'} <= 0){&error("마이너스의 돈은 맡겨지지 않습니다!");}
								if ($in{'azukegaku'} !~ /\d/){&error("입력액이 올바르지 않습니다");}
								$super_azuke_kin = ($in{'azukegaku'}*1000);
								if($super_azuke_kin > $money){&error("그렇게 돈을 가지지 않습니다!");}
								$yobi9=$yobi9+$super_azuke_kin;
								$money=$money-$super_azuke_kin;
								$message_in = "슈퍼 정기예금에 돈을$super_azuke_kin만 맡겼습니다.";
				}elsif ($in{'command'} eq "해약"){
								$money=$money+$yobi9;
								$message_in = "슈퍼 정기예금($yobi9만)을 해약했습니다.";
								$yobi9=0;
				}else{
#은행 화면 출력
			&header(2);
			if($yobi5 eq  ""){$ima_azuke = "없음";}else{$ima_azuke="$yobi5만";}
			if($yobi9 > 0){$super_gaku = "슈퍼 정기예금 예금액：$yobi9만<br>";}
			print <<"EOM";
<div align=center style=font-size:16px>은행</div><br>
	<table width="90%" border="0" cellspacing="0" cellpadding="10" align=center class=sumi>
	<tr><td>
<div style="font-size:12px;">$name씨의 소유금：$money만<br>
은행에 맡기고 있는 액：$ima_azuke<br>
$super_gaku </div><br>
<div style=font-size:14px;color:#336699>■돈을 맡긴다</div>
	<form method="POST" action="$script">
	<input type=hidden name=mode value="ginkou">
	<input type=hidden name=command value="맡긴다">
	<input type=hidden name=name value="$in{'name'}">
	<input type=hidden name=pass value="$in{'pass'}">
	<input type=hidden name=id value="$in{'id'}">
	맡기는 금액 <input type=text name=azukegaku size=10>만 <input type=submit value="맡긴다">
	</form>
	
<div style=font-size:14px;color:#336699>■돈을 인출한다</div>
	<form method="POST" action="$script">
	<input type=hidden name=mode value="ginkou">
	<input type=hidden name=command value="내린다">
	<input type=hidden name=name value="$in{'name'}">
	<input type=hidden name=pass value="$in{'pass'}">
	<input type=hidden name=id value="$in{'id'}">
	내리는 금액 <input type=text name=orosigaku size=10>만 <input type=submit value="내린다">
	</form>
	
	<div style=font-size:14px;color:#336699>■슈퍼 정기예금에 맡긴다</div>
	※슈퍼 정기예금은 이자가 1%가 됩니다(보통예금은 0.5%).다만, 예입액수는 1000만 단위로, 돈을 인출하고 말이야 있어는 해약으로서 전액 인출하지 않으면 되지 않습니다.
	<form method="POST" action="$script">
	<input type=hidden name=mode value="ginkou">
	<input type=hidden name=command value="슈퍼">
	<input type=hidden name=name value="$in{'name'}">
	<input type=hidden name=pass value="$in{'pass'}">
	<input type=hidden name=id value="$in{'id'}">
	맡기는 금액 <input type=text name=azukegaku size=4> 000만 <input type=submit value="맡긴다">
	</form>
	
<div style=font-size:14px;color:#336699>■슈퍼 정기예금 해약</div>
	<form method="POST" action="$script">
	<input type=hidden name=mode value="ginkou">
	<input type=hidden name=command value="해약">
	<input type=hidden name=name value="$in{'name'}">
	<input type=hidden name=pass value="$in{'pass'}">
	<input type=hidden name=id value="$in{'id'}">
	<input type=submit value="해약한다">
	</form>
	
	</td></tr></table>
	<div align="center"><a href=\"javascript:history.back()\"> [앞에 화면으로 돌아온다] </a></div>
	</body></html>
EOM
	exit;
			}		#else(은행 화면 출력)가 닫아

					&temp_routin;
					&log_kousin($my_log_file,$temp);
					&message($message_in,"login_view");

}	#sub kaimono가 닫아

##########주
sub kabu {
#주식 구입 처리
	if($in{'command'} eq "kai"){
					&openMylog($in{'id'});
						if($in{'kazu'} > $kabu_gendo){&error("구입할 수 있는 주식은$kabu_gendo주까지입니다.");}		#ver.1.36
						if($in{'kazu'} <= 0){&error("구입수가 부적절합니다!");}
						if ($in{'kazu'} !~ /\d/){&error("입력수가 부적절합니다");}
						$total_kabu=$in{hitokabu}*$in{kazu};
						if($money < $total_kabu){&error("돈이 충분하지 않습니다!");}
						$kabu="$in{meigara},$in{hitokabu},$in{agari},$in{sagari},$in{kazu},$in{hitokabu}";
						$money=$money-$in{hitokabu}*$in{kazu};
					&temp_routin;
					&log_kousin($my_log_file,$temp);
	&message("$in{meigara}주를 $in{kazu}주 구입했습니다.","login_view");
#주식 매각 확인 화면
	}elsif($in{'command'} eq "uri"){
					&openMylog($in{'id'});
	($meigara,$hitokabu,$agari,$sagari,$kazu)= split(/,/,$kabu);
	$uriage=$hitokabu*$kazu;
	&header(2);
	print <<"EOM";
     <form method="POST" action="$script">
	<input type=hidden name=mode value="kabu">
	<input type=hidden name=command value="uruyo">
	<input type=hidden name=name value="$in{'name'}">
	<input type=hidden name=pass value="$in{'pass'}">
	<input type=hidden name=id value="$in{'id'}">
	<table width="400" border="0" cellspacing="0" cellpadding="10" align=center>
		<tr><td><div align=center  style=font-size:14px>
		$meigara의$kazu주를 팝니까?<br><br>
		$hitokabu만×$kazu주로$uriage만이 됩니다.
		</td></tr>
	</table>
        <div align="center">
          <br><input type="submit" name="Submit2" value=" 판다 "><br><br>
		  <a href=\"javascript:history.back()\"> [앞에 화면으로 돌아온다] </a>
        </div>
      </form></body></html>
EOM
exit;

#주식 매각 처리
	}elsif($in{'command'} eq "uruyo"){
					&openMylog($in{'id'});
					($meigara,$hitokabu,$agari,$sagari,$kazu)= split(/,/,$kabu);
					$money=$money+$hitokabu*$kazu;
					$kabu="없음";
								&temp_routin;
								&log_kousin($my_log_file,$temp);
	&message("주를 매각했습니다.","login_view");

#주식 구입 화면 출력
	}else{
					&openMylog($in{'id'});
	&header(2);
	print <<"EOM";		#ver.1.36
<div align=center style=font-size:16px>주식 구입</div><br>
	<table width="400" border="1" cellspacing="0" cellpadding="10" align=center>
	<tr><td colspan=6>
<div style=font-size:12px>「구입수」에 사고 싶은 주 수를 입력해 「구입」버튼을 눌러 주세요.<br>
주식은 홀수눈이 나올 때마다 올라, 짝수눈이 나올 때마다 내립니다.<br>
예를 들면, 소\니주를 10주 구입했을 경우,<br>
30만(초기의 가격)×10주=300만 필요합니다.<br>
만약, 1회홀수눈이 나오면 오름치가 4만이므로, 주가는 34만이 되어, 그 시점에서 모두 팔면<br>
34만×10주=340만이기 때문에 40만 득을 본 것이  됩니다.<br>
덧붙여 주식은 하나의 종목만 소유할 수 있습니다.또 주가가 10만을 나누면 주식을 손놓지 않으면 안 되게 됩니다.<br>
※한 번에 구입할 수 있는 주식은$kabu_gendo주까지입니다.<br><br>
<div style="color:#336699">$name씨의 소유액：$money만</div></div>
	</td></tr>
<tr><td align=center>종목</td><td width=60>1주의 가격(만)</td><td width=60>오름치(만)</td><td width=60>내려감치(만)</td><td>구입수</td><td></td></tr>
EOM
		open(IN,"./kabu.dat") || &error("Open Error : kabu.dat");
		while (<IN>) {
		chop $_;
($meigara,$hitokabu,$agari,$sagari)= split(/<>/);
				print <<"EOM";
<form method="POST" action="$script">
	<input type=hidden name=mode value="kabu">
	<input type=hidden name=command value="kai">
	<input type=hidden name=name value="$in{'name'}">
	<input type=hidden name=pass value="$in{'pass'}">
	<input type=hidden name=id value="$in{'id'}">
	<input type=hidden name=meigara value="$meigara">
	<input type=hidden name=hitokabu value="$hitokabu">
	<input type=hidden name=agari value="$agari">
	<input type=hidden name=sagari value="$sagari">
<tr>
<td nowrap>$meigara</td><td align=right>$hitokabu</td><td align=right>$agari</td><td align=right>$sagari</td><td><input type=text name=kazu size=6></td><td><input type=submit value="구입"></td></tr>
</form>
EOM
		}
		close(IN);
		print <<"EOM";
		</table>
		        <div align="center">
		  <a href=\"javascript:history.back()\"> [앞에 화면으로 돌아온다] </a>
        </div>
		</body></html>
EOM
	}
exit;
}

##########집구입 처리
sub ie {
#토지 구입 확인 화면
	if($in{'command'} eq "toti_kai_kakunin"){
		if($in{basyo} eq ""){&error("토지를 선택해 주세요!");}
		if($in{kazu} eq ""){&error("구입하는 평수를 입력해 주세요!");}
		if($in{'kazu'} <= 0){&error("평수가 부적절합니다!");}
		if ($in{'kazu'} !~ /\d/){&error("평수가 부적절합니다");}
					&openMylog($in{'id'});
						$before_sp=$in{basyo};
						($basyo,$tubo_tanka)= split(/<>/,$before_sp);
						$kounyuugaku=$tubo_tanka*$in{kazu};
						if($money < $kounyuugaku){&error("돈이 충분하지 않습니다!");}
		&header(2);
		print <<"EOM";
	<form method="POST" action="$script">
	<input type=hidden name=mode value="ie">
	<input type=hidden name=command value="toti_kai">
	<input type=hidden name=name value="$in{'name'}">
	<input type=hidden name=pass value="$in{'pass'}">
	<input type=hidden name=basyo value="$basyo">
	<input type=hidden name=tubo_tanka value="$tubo_tanka">
	<input type=hidden name=id value="$in{'id'}">
	<input type=hidden name=oaite value="$in{'oaite'}">
	<input type=hidden name=kazu value="$in{'kazu'}">
	<br><div style="font-size:14px" align=center>
	$basyo의 토지, $tubo_tanka만×$in{'kazu'}평으로$kounyuugaku만이 됩니다.<br><br>
	좋습니까?<br><br>
	<input type=submit value=" O K "><br><br>
	<a href=\"javascript:history.back()\"> [앞에 화면으로 돌아온다] </a>
	</div>
	</form>
	</body></html>
EOM
	exit;
	
#토지 구입 처리
	}elsif($in{'command'} eq "toti_kai"){
#자신의 파일을 갱신
					&openMylog($in{'id'});
						$kounyuugaku=$in{tubo_tanka}*$in{kazu};
						$land="$in{basyo},$in{kazu},$kounyuugaku";
						$money=$money-$in{tubo_tanka}*$in{kazu};
								&temp_routin;
								&log_kousin($my_log_file,$temp);
#배우자의 파일을 갱신
				if($in{'oaite'} ne ""){
					&openAitelog($in{'oaite'});
						$kounyuugaku=$in{tubo_tanka}*$in{kazu};
						$land="$in{basyo},$in{kazu},$kounyuugaku";
								&temp_routin;
								&log_kousin($aite_log_file,$temp);
				}
	&message("$in{basyo}의 토지를 $in{kazu}평 구입했습니다.","login_view");
	
#집구입 처리
	}elsif($in{'command'} eq "ie_kai"){
#자신의 파일을 갱신
					&openMylog($in{'id'});
						if($land eq "없음"){&error("집은 토지가 없으면 살 수 없습니다!");}
						($toti_basyo,$tubosuu)= split(/,/,$land);
						if($tubosuu < $in{'hituyou_tubo'}){&error("소유하고 있는 토지에서는, 이 집을 세우는데 필요한 평수가 충분하지 않습니다!");}
						if($money < $in{'nedan'}){&error("돈이 충분하지 않습니다!");}
						$house="$in{'syurui'},$in{'nedan'}";
						$money=$money-$in{'nedan'};
								&temp_routin;
								&log_kousin($my_log_file,$temp);
#배우자의 파일을 갱신
				if($in{'oaite'} ne ""){
					&openAitelog($in{'oaite'});
						$house="$in{'syurui'},$in{'nedan'}";
								&temp_routin;
								&log_kousin($aite_log_file,$temp);
				}
	&message("$in{syurui}를$toti_basyo의 토지에 세웠습니다.","login_view");

#토지매각 처리
	}elsif($in{'command'} eq "toti_uri"){
#자신의 파일을 갱신
					&openMylog($in{'id'});
					$money=$money+$in{'toti_uri_gaku'};
					$money=$money+$in{'ie_uri_gaku'};
					$land="없음";
					$house="없음";
								&temp_routin;
								&log_kousin($my_log_file,$temp);
#배우자의 파일을 갱신
				if($in{'oaite'} ne ""){
					&openAitelog($in{'oaite'});
					$land="없음";
					$house="없음";
								&temp_routin;
								&log_kousin($aite_log_file,$temp);
				}
	&message("토지를 매각했습니다.","login_view");
	
#집매각 처리
	}elsif($in{'command'} eq "ie_uri"){
#자신의 파일을 갱신
					&openMylog($in{'id'});
					$money=$money+$in{'ie_uri_gaku'};
					$house="없음";
								&temp_routin;
								&log_kousin($my_log_file,$temp);
#배우자의 파일을 갱신
				if($in{'oaite'} ne ""){
					&openAitelog($in{'oaite'});
					$house="없음";
								&temp_routin;
								&log_kousin($aite_log_file,$temp);
				}
	&message("집을 매각했습니다.","login_view");

#집구입 화면 출력
	}else{
					&openMylog($in{'id'});
	&header(2);
#토지의 표시형을 정형
	if($land ne "없음"){
			($toti_basyo,$tubosuu,$toti_kounyuugaku)= split(/,/,$land);
			$land_hyouzi="$toti_basyo($tubosuu평)";
	}else{$land_hyouzi = "없음";}
	$toti_uri_gaku=int($toti_kounyuugaku*0.8);
#집의 표시형을 정형
	if($house ne "없음"){
			($house_style,$ie_kounyuugaku)= split(/,/,$house);
	}else{$house_style = "없음";}
	$ie_uri_gaku=int($ie_kounyuugaku*0.3);
	
	&id_check($haiguu);
	$haiguu_id = $return_id;
	print <<"EOM";
	<table width="85%" border="0" cellspacing="0" cellpadding="5" align=center>
<tr><td>
<div style=font-size:12px>집을 세우려면 , 우선 토지를 살 필요합니다.사고 싶은 장소를 체크해, 아래의 평수를 입력해 「구입」버튼을 눌러 주세요.<br>세우는 집의 종류에 의해서 필요한 토지의 평수가 정해져 있기 때문에(아래의 겉(표)\참조), 어떤 집을 세울까 생각한 다음 구입하는 평수를 결정해 주세요.배우자가 있는 경우, 배우자의 토지나 집도 동시에 변경되기 때문에, 집을 살 때는 자주(잘) 상담합시다.<br>또 토지는 추가해 살 수 없습니다.새로운 토지를 사면 지금 있는 토지는 소멸하기 때문에, 먼저 토지를 팔고 나서 삽시다.
<br><br>
	$name씨의 소유액：$money만<br>
	소유하고 있는 토지：$land_hyouzi<br>
	소유하고 있는 집：$house_style</div></div><br>
	</td></tr></table>
	<div align=center style=font-size:16px>토지 구입</div>
	<table width="80%" border="1" cellspacing="0" cellpadding="5" align=center>
<tr><td align=center>장소</td><td  align=center>평단가</td></tr>
<form method="POST" action="$script">
	<input type=hidden name=mode value="ie">
	<input type=hidden name=command value="toti_kai_kakunin">
	<input type=hidden name=name value="$in{'name'}">
	<input type=hidden name=pass value="$in{'pass'}">
	<input type=hidden name=id value="$in{'id'}">
	<input type=hidden name=oaite value="$haiguu_id">
EOM
		open(IN,"./toti.dat") || &error("Open Error : toti.dat");
		@totilist_hyouzi = <IN>;
		foreach (@totilist_hyouzi) {
		chop $_;
($basyo,$tubo_tanka)= split(/<>/);
				print <<"EOM";
<!--	<input type=hidden name=tubo_tanka value="$tubo_tanka"> -->
<tr>
<td nowrap><input type=radio name=basyo value="$basyo<>$tubo_tanka">$basyo</td><td align=right>$tubo_tanka만</td></tr>
EOM
		}
		close(IN);
		print <<"EOM";
		<tr><td colspan=2 align=center><input type=text name=kazu size=6>평 <input type=submit value="구입"></td></tr></form></table>
		<div align="center"><a href=\"javascript:history.back()\"> [앞에 화면으로 돌아온다] </a></div>
		
	<br><br><div align=center style=font-size:16px>집구입</div>
	<table width="80%" border="1" cellspacing="0" cellpadding="5" align=center>
<tr><td align=center>종류</td><td align=center>필요한<br>토지의 평수</td><td  align=center>가의 금액</td><td></td></tr>
EOM
		open(IN,"./ie.dat") || &error("Open Error : ie.dat");
		while (<IN>) {
		chop $_;
($syurui,$nedan,$hituyou_tubo)= split(/<>/);
				print <<"EOM";
<form method="POST" action="$script">
	<input type=hidden name=mode value="ie">
	<input type=hidden name=command value="ie_kai">
	<input type=hidden name=name value="$in{'name'}">
	<input type=hidden name=pass value="$in{'pass'}">
	<input type=hidden name=id value="$in{'id'}">
	<input type=hidden name=oaite value="$haiguu_id">
	<input type=hidden name=syurui value="$syurui">
	<input type=hidden name=nedan value="$nedan">
	<input type=hidden name=hituyou_tubo value="$hituyou_tubo">
<tr>
<td nowrap>$syurui</td><td align=center>$hituyou_tubo평</td><td align=right>$nedan만</td><td align=center><input type=submit value="구입"></td></tr>
</form>
EOM
		}
		close(IN);
		print <<"EOM";
		</table>
		        <div align="center">
		  <a href=\"javascript:history.back()\"> [앞에 화면으로 돌아온다] </a>
        </div><br>
		
		<hr size=1>
<!--매각 화면-->
		<br><div align=center style=font-size:16px>집·토지매각</div><br>
<div style=font-size:12px>자신이 가지고 있는 토지와 집은 매각할 수 있습니다.다만, 토지의 가격은 샀을 때의 8할, 집의 가격은 3할의 가격이 됩니다.토지를 팔았을 경우는 동시에 집도 팔게 됩니다.또 배우자가 있는 경우, 토지나 집을 팔면 배우자의 토지나 집도 없어지기 때문에, 매각할 때는 자주(잘) 상담하고 나서로 해 주세요.<br><br>
	$name씨의 소유액：$money만<br>
EOM
	if($land eq "없음"){$toti_uri_messe="토지를 소유하고 있지 않습니다<br>";}
	else{$toti_uri_messe= <<"EOM";
	<form method="POST" action="$script">
	<input type=hidden name=mode value="ie">
	<input type=hidden name=name value="$in{'name'}">
	<input type=hidden name=pass value="$in{'pass'}">
	<input type=hidden name=id value="$in{'id'}">
	<input type=hidden name=oaite value="$haiguu_id">
	<input type=hidden name=command value="toti_uri">
	<input type=hidden name=toti_uri_gaku value="$toti_uri_gaku">
	<input type=hidden name=ie_uri_gaku value="$ie_uri_gaku">
	■소유하고 있는 토지：$land_hyouzi　※매각하면$toti_uri_gaku만이 됩니다.
	<input type=submit value="토지를 판다"></form>
EOM
	}
	if($house eq "없음"){$ie_uri_messe="가를 소유하고 있지 않습니다";}
	else{$ie_uri_messe= <<"EOM";
	<form method="POST" action="$script">
	<input type=hidden name=mode value="ie">
	<input type=hidden name=name value="$in{'name'}">
	<input type=hidden name=pass value="$in{'pass'}">
	<input type=hidden name=id value="$in{'id'}">
	<input type=hidden name=oaite value="$haiguu_id">
	<input type=hidden name=command value="ie_uri">
	<input type=hidden name=ie_uri_gaku value="$ie_uri_gaku">
	■소유하고 있는 집：$house_style　※매각하면$ie_uri_gaku만이 됩니다.
	<input type=submit value="집을 판다"></form>
EOM
	}
		print <<"EOM";
		$toti_uri_messe
		$ie_uri_messe
		<div align="center">
		  <a href=\"javascript:history.back()\"> [앞에 화면으로 돌아온다] </a>
        </div><br>
		</body></html>
EOM
exit;
	}
}


#메일 체크
sub mail_check {
#		&id_check($in{'name'});
		$my_log_file = "./member/"."$in{'id'}"."log.cgi";
		open(IN,"$my_log_file") || &error("로그 파일($my_log_file)이 열리지 않습니다.<br>재차 로그인해도 동일한 관리인($master_ad)까지 메일을 주세요.");
		$my_prof = <IN>;
		if($my_prof == ""){&error("로그 파일에 문제가 일어났습니다.<br>수고스럽겠지만, 관리인($master_ad)까지 메일을 주세요.");}
		&split_var2($my_prof);
		close(IN);
					if($in{'pass'} ne $pass){&error("이름과 패스워드가 일치하지 않습니다!");}

#삭제 커멘드의 경우
	if ($in{'command'} eq "sakujo"){
			$member_file="./member/$id" . ".cgi";
			open(IN,"$member_file") || &error("Open Error : $member_file가 열리지 않습니다.");
			@sakujo_messe = <IN>;
			foreach (@sakujo_messe) {
					($kibou_type,$m_name,$m_messe,$m_money,$m_land,$m_house,$m_number,$m_id,$kekka,$m_yobi4)= split(/<>/);
					
					if($in{'m_id'} eq "$m_number"){next;}
					$temp="$kibou_type<>$m_name<>$m_messe<>$m_money<>$m_land<>$m_house<>$m_number<>$m_id<>$kekka<>$m_yobi4<>\n";
					push(@newrank,$temp);
			}
			close(IN);
# 로그를 갱신
			&lock;
			open(OUT,">$member_file") || &error("Write Error : $member_file");
			print OUT @newrank;
			close(OUT);	
			&unlock;
			&message("삭제가 완료했습니다.","mail_check");
	}else{
		&header(2);
#사서함 최종 액세스 시간을 써
		open(TIMEIN,"$lasttime_file") || &error("Open Error : $lasttime_file");
		$flag=0;
		$now_time= time;
		while (<TIMEIN>) {
				 ($mypost_id,$mailcheck_time) = split(/<>/);
				if($id eq $mypost_id){$mailcheck_time= $now_time;$flag=1;}
				$mail_tmp="$mypost_id<>$mailcheck_time<>\n";
				push(@new_mail_rank,$mail_tmp);
		}
		close(TIMEIN);
		if($flag == 0){
				$new_mail_usr="$id<>$now_time<>\n";
				push(@new_mail_rank,$new_mail_usr);
		}
# 최종 액세스 로그를 갱신
	&lock;
		open(TIMEOUT,">$lasttime_file") || &error("Write Error : $lasttime_file");
		print TIMEOUT @new_mail_rank;
		close(TIMEOUT);
	&unlock;

		print <<"EOM";
<div align=center style=font-size:16px;color:#ff3300>메일</div><br>
<table width="95%" border="0" cellspacing="5" cellpadding="0" align=center><tr><td>
※보존해 둘 수 있는 메일은 50건입니다.50건을 넘었을 경우 낡은 것으로부터 자동적으로 삭제됩니다.</td></tr></table><br>
EOM

#자신의 사서함을 연다
			$member_file="./member/$id" . ".cgi";
			open(IN,"$member_file") || &error("Open Error : $member_file가 열리지 않습니다.");
			@allmail_data=<IN>;
				if(! @allmail_data){print "<div align=center>현재 도착하는 메세지는 없습니다<br><br><a href=\"$script?mode=login_view&command=select_com&name=$in{'name'}&pass=$in{'pass'}\"> [돌아온다] </a></div><br>";}
			foreach (@allmail_data) {
			($kibou_type,$m_name,$m_messe,$m_money,$m_land,$m_house,$m_number,$m_id,$kekka,$m_yobi4)= split(/<>/);
			
#토지의 표시형을 정형
	if($m_land ne "없음"){
			($toti_basyo,$tubosuu)= split(/,/,$m_land);
			$land_hyouzi="$toti_basyo($tubosuu평)";
	}else{$land_hyouzi = "없음";}
#집의 표시형을 정형
	if($m_house ne "없음"){
			($house_style,$ie_kounyuugaku)= split(/,/,$m_house);
	}else{$house_style = "없음";}
	
				if ($kibou_type eq "연인"){
					print <<"EOM";
<table width="95%" border="0" cellspacing="5" cellpadding="0" align=center  class=sumi>
<tr><td rowspan="2" width=64><img src=$img_dir/koibito.gif width=64 height=37></td><td align=center>★이름</td><td align=center>★총자산</td><td align=center>★토지</td><td align=center>★가</td></tr>
<tr><td align=center class=mainasu>$m_name</td><td align=center>$m_money만</td><td align=center>$land_hyouzi</td><td align=center>$house_style</td></tr><tr><td colspan=5><hr size=1></td></tr>
<tr><td colspan=1 align=right>메세지●</td><td colspan=4>$m_messe</td></tr>
<tr><td colspan=4>
     <form method="POST" action="$script">
	<input type=hidden name=mode value="kokuhaku">
	<input type=hidden name=command value="mousikomi">
	<input type=hidden name=kibou value="교제 대답">
	<input type=hidden name=name value="$in{'name'}">
	<input type=hidden name=pass value="$in{'pass'}">
	<input type=hidden name=id value="$id">	<!--자신의id -->
	<input type=hidden name=oaite value="$m_id">	<!--상대의id -->
	<input type=hidden name=aite_name value="$m_name">	<!--상대의 이름 -->
		(답례)답장 <select name="sentaku">
        <option value="ok">수행원 맞습시다</option>
        <option value="ng">미안해요</option>
      </select>
	<input type="submit" name="Submit2" value=" O K ">
</td><td><a href=$script?mode=mail_check&command=sakujo&m_id=$m_number&name=$in{'name'}&pass=$in{'pass'}&id=$in{'id'}>이 메일을 삭제</a></td></tr></form>
</table><div align=center><a href=\"$script?mode=login_view&command=select_com&name=$in{'name'}&pass=$in{'pass'}\"> [돌아온다] </a></div><br>
EOM
			}elsif($kibou_type eq "결혼"){
					print <<"EOM";
<table width="95%" border="0" cellspacing="5" cellpadding="0" align=center class=sumi>
<tr><td rowspan="2" width=64><img src=$img_dir/kekkon.gif width=64 height=37></td><td align=center>★이름</td><td align=center>★총자산</td><td align=center>★토지</td><td align=center>★가</td></tr>
<tr><td align=center class=mainasu>$m_name</td><td align=center>$m_money만</td><td align=center>$land_hyouzi</td><td align=center>$house_style</td></tr><tr><td colspan=5><hr size=1></td></tr>
<tr><td colspan=1 align=right>메세지●</td><td colspan=4>$m_messe</td></tr>
<tr><td colspan=4>
     <form method="POST" action="$script">
	<input type=hidden name=mode value="kokuhaku">
	<input type=hidden name=command value="mousikomi">
	<input type=hidden name=kibou value="결혼 대답">
	<input type=hidden name=name value="$in{'name'}">
	<input type=hidden name=pass value="$in{'pass'}">
	<input type=hidden name=id value="$id">	<!--자신의id -->
	<input type=hidden name=oaite value="$m_id">	<!--상대의id -->
	<input type=hidden name=aite_name value="$m_name">	<!--상대의 이름 -->
	<input type=hidden name=my_land value="$land">	<!--자신의 토지 -->
	<input type=hidden name=my_house value="$house">	<!--자신의 집 -->
	<input type=hidden name=aite_land value="$m_land">	<!--상대의 토지 -->
	<input type=hidden name=aite_house value="$m_house">	<!--상대의 집 -->
	<input type=hidden name=my_child value="$kodomo">	<!--자신의 아이 -->
		(답례)답장 <select name="sentaku">
        <option value="ok">결혼합시다</option>
        <option value="ng">미안해요</option>
      </select>
		사는 집 <select name="ie_sentaku">
        <option value="zibun">자신의 집</option>
        <option value="aite">$m_name의 집</option>
      </select>
	<input type="submit" name="Submit2" value=" O K "></form>
</td><td><a href=$script?mode=mail_check&command=sakujo&m_id=$m_number&name=$in{'name'}&pass=$in{'pass'}&id=$in{'id'}>이 메일을 삭제</a></td></tr></form>
</table>
<div align=center><a href=\"$script?mode=login_view&command=select_com&name=$in{'name'}&pass=$in{'pass'}\"> [돌아온다] </a></div><br>
EOM
			}elsif($kibou_type eq "메시지"){
#상대의 관계를 변수에 대입
					if($m_name eq $haiguu){
							$kankei = "<div class=honbun>(배우자)</div>";
					}else{
							@koibito_list = split(/,/,$yobi3);
							$koibito_flag=0;
							foreach (@koibito_list){
									if($m_name eq "$_"){$koibito_flag=1;}
							}
							if($koibito_flag == 1){$kankei = "<div class=honbun>(연인)</div>";
							}else{$kankei = "";}
					}

					print <<"EOM";
<table width="95%" border="0" cellspacing="5" cellpadding="0" align=center class=sumi>
<tr><td width=64><img src=$img_dir/messe.gif width=64 height=37></td>
<td class=mainasu nowrap width=60 align=center>$m_name$kankei</td><td>●$m_messe</td></tr>
<tr><td colspan=3>
     <form method="POST" action="$script">
	<input type=hidden name=mode value="kokuhaku">
	<input type=hidden name=command value="mousikomi">
	<input type=hidden name=kibou value="메시지">
	<input type=hidden name=name value="$in{'name'}">
	<input type=hidden name=pass value="$in{'pass'}">
	<input type=hidden name=id value="$id">	<!--자신의id -->
	<input type=hidden name=oaite value="$m_id">	<!--상대의id -->
	<input type=hidden name=aite_name value="$m_name">	<!--상대의 이름 -->
	<input type="text" size=40 name=messe>
	<input type="submit" name="Submit2" value="대답을 보낸다"> 
	<a href=$script?mode=mail_check&command=sakujo&m_id=$m_number&name=$in{'name'}&pass=$in{'pass'}&id=$in{'id'}>이 메일을 삭제</a>
</td></tr></form>
</table>
<div align=center><a href=\"$script?mode=login_view&command=select_com&name=$in{'name'}&pass=$in{'pass'}\"> [돌아온다] </a></div><br>
EOM
			}elsif($kibou_type eq "교제 대답" || $kibou_type eq "결혼 대답"){
				if($kibou_type eq "교제 대답"){$dotti="교제";}else{$dotti="결혼";}
				print "<table width=95% border=0 cellspacing=5 cellpadding=0 align=center class=sumi><tr><td>";
					if($kekka eq "ok"){
					print <<"EOM";
					<div class=midasi2>축합니다!$m_name씨가$dotti를 승낙해 주었습니다!</div>
EOM
					}else{
					print <<"EOM";
					<div class=midasi>유감입니다만, $m_name씨로부터$dotti 거절의 대답이 왔습니다.</div>
EOM
					}
			print "<div align=center><a href=$script?mode=mail_check&command=sakujo&m_id=$m_number&name=$in{'name'}&pass=$in{'pass'}&id=$in{'id'}>이 메일을 삭제</a></div></td></tr></table><div align=center><a href=\"$script?mode=login_view&command=select_com&name=$in{'name'}&pass=$in{'pass'}\"> [돌아온다] </a></div><br><br>";
			}elsif ($kibou_type eq "송금"){
					print <<"EOM";
					<table width=95% border=0 cellspacing=5 cellpadding=0 align=center class=sumi><tr><td>
					<div class=midasi2>$m_messe</div>
					<div align=center><a href=$script?mode=mail_check&command=sakujo&m_id=$m_number&name=$in{'name'}&pass=$in{'pass'}&id=$in{'id'}>이 메일을 삭제</a></div>
					</td></tr></table><div align=center><a href=\"$script?mode=login_view&command=select_com&name=$in{'name'}&pass=$in{'pass'}\"> [돌아온다] </a></div><br><br>
EOM
			}elsif ($kibou_type eq "이혼" || $kibou_type eq "헤어진다"){
					print <<"EOM";
					<table width=95% border=0 cellspacing=5 cellpadding=0 align=center class=sumi><tr><td>
					<div class=midasi>$m_messe</div>
					<div align=center><a href=$script?mode=mail_check&command=sakujo&m_id=$m_number&name=$in{'name'}&pass=$in{'pass'}&id=$in{'id'}>이 메일을 삭제</a></div>
					</td></tr></table><div align=center><a href=\"$script?mode=login_view&command=select_com&name=$in{'name'}&pass=$in{'pass'}\"> [돌아온다] </a></div><br><br>
EOM

			}elsif ($kibou_type eq "아이작"){
					print <<"EOM";
					<table width=95% border=0 cellspacing=5 cellpadding=0 align=center class=sumi><tr><td>
					<div class=midasi>$m_messe</div>
					<div align=center><a href=$script?mode=mail_check&command=sakujo&m_id=$m_number&name=$in{'name'}&pass=$in{'pass'}&id=$in{'id'}>이 메일을 삭제</a></div>
					</td></tr></table><div align=center><a href=\"$script?mode=login_view&command=select_com&name=$in{'name'}&pass=$in{'pass'}\"> [돌아온다] </a></div><br><br>
EOM

			}elsif($kibou_type eq "아이"){
					if($kounyuu  =~ /미약/){$biyakuflag="on";}
					print <<"EOM";
<table width="95%" border="0" cellspacing="5" cellpadding="0" align=center class=sumi>
<tr><td><div style="font-size:12;color:#336699"">$m_name씨가 「$m_messe」라고 하는 이름으로 아이를 만들고 싶다고 합니다.승낙이라면 OK버튼을 눌러 주세요.아이가 태어나는 확률은 5분의 1입니다.다만, 「미약」을 가지고 있으면 확률이 3분의 1에 오릅니다.또 아이가 만들 수 있는 것은 6명까지입니다.</div></td></tr><tr>
<td align=center>
     <form method="POST" action="$script">
	<input type=hidden name=mode value="kokuhaku">
	<input type=hidden name=command value="mousikomi">
	<input type=hidden name=kibou value="아이작">
	<input type=hidden name=name value="$in{'name'}">
	<input type=hidden name=pass value="$in{'pass'}">
	<input type=hidden name=id value="$id">	<!--자신의id -->
	<input type=hidden name=oaite value="$m_id">	<!--상대의id -->
	<input type=hidden name=aite_name value="$m_name">	<!--상대의 이름 -->
	<input type=hidden name=messe value="$m_messe">	<!--아이의 이름 -->
	<input type=hidden name=mail_no value="$m_number">	<!--이 메일의 파일number -->
	<input type=hidden name=biyakuflag value="$biyakuflag">	<!--미약 -->
	<input type="submit" name="Submit2" value=" O K "> <br>
	※OK버튼을 누른 시점에서 이 메일은 삭제됩니다.<br>
	임의에 이 메일을 삭제하는 경우<a href=$script?mode=mail_check&command=sakujo&m_id=$m_number&name=$in{'name'}&pass=$in{'pass'}&id=$in{'id'}>「이쪽」</a>
</td></tr></form></table><div align=center><a href=\"$script?mode=login_view&command=select_com&name=$in{'name'}&pass=$in{'pass'}\"> [돌아온다] </a></div><br><br>
EOM

			}else{
					print <<"EOM";
					<table width=95% border=0 cellspacing=5 cellpadding=0 align=center class=sumi><tr><td>
					<div class=midasi>$m_messe</div>
					<div align=center><a href=$script?mode=mail_check&command=sakujo&m_id=$m_number&name=$in{'name'}&pass=$in{'pass'}&id=$in{'id'}>이 메일을 삭제</a></div>
					</td></tr></table><div align=center><a href=\"$script?mode=login_view&command=select_com&name=$in{'name'}&pass=$in{'pass'}\"> [돌아온다] </a></div><br><br>
EOM
			}			#else가 닫아
			$m ++;
			push @mail_max,$_;
			if($m >= 50){last;}
		}	#while가 닫아
	close(IN);
					&lock;
					open(SAK,">$member_file") || &error("Open Error : $member_file");
					print SAK @mail_max;
					close(SAK);
					&unlock;
	print "</body></html>";
	exit;
	}	#if 문장(커멘드가 없는 경우)이 덮어
}		#써브루틴이 닫아

#메세지 송신
sub mail_sousin {
	&header(2);
	print "<div align=center style=font-size:16px;color:#336699>메세지 송신</div><br>";
					&openMylog($in{'id'});
							&item_money_hash;
							&item_id_hash;
							undef $ori_item;
							undef $normal_item;
							(@kounyuus)= split(/,/,$kounyuu);
							foreach (@kounyuus) {
								if ($item_money_hash{$_} ne ""){
											if ($item_id_hash{$_} eq "$in{'id'}"){
												$ori_item .= "<option value=$_>$_</option>\n";
											}
								}else{
									$normal_item .= "<option value=$_>$_</option>\n";
								}
							}
							if($ori_item eq ""){$ori_item = "<option value=\"\">작성한 아이템은 없습니다</option>\n";}
								
						if($haiguu ne "독신"){
								if($sex eq "m"){$aite_yobi="아내";}else{$aite_yobi="남편";}
								&id_check ($haiguu);
								$aite_id=$return_id;
								print <<"EOM";
	<table width="95%" border="0" cellspacing="0" cellpadding="5" align=center class=sumi>
	<tr><td>
     <form method="POST" action="$script">
	<input type=hidden name=mode value="kokuhaku">
	<input type=hidden name=command value="mousikomi">
	<input type=hidden name=name value="$name">
	<input type=hidden name=pass value="$pass">
	<input type=hidden name=id value="$id">
	<input type=hidden name=oaite value="$aite_id">
	<input type=hidden name=kibou value="메시지">
	<div style="font-size:12px; color:#336699">■$aite_yobi($haiguu씨)에 메세지를 보낸다</div>
	<textarea cols=58 rows=4 name=messe wrap="soft"></textarea>
	<input type="submit" name="Submit2" value=" O K ">
	</form></td></tr>
	
	<tr><td>
     <form method="POST" action="$script">
	<input type=hidden name=mode value="kokuhaku">
	<input type=hidden name=command value="mousikomi">
	<input type=hidden name=name value="$name">
	<input type=hidden name=pass value="$pass">
	<input type=hidden name=id value="$id">
	<input type=hidden name=oaite value="$aite_id">
	<input type=hidden name=kibou value="송금">
	<div style="font-size:12px; color:#336699">■돈이나 소유물을 보낸다</div>
	※돈과 소유물(1점만)은 동시에 보낼 수 있습니다(선물 된 것을 제외하다).<br>
	○보내는 금액 <input type=text name=kingaku size=8> 만　
	○보내는 소유물 <select name="okurumono">
    <option value="">없음</option>
	$normal_item
	</select>
	<input type="submit" name="Submit2" value=" O K ">
	</form></td></tr>

	<tr><td>
     <form method="POST" action="$script">
	<input type=hidden name=mode value="birthdayPresent">
	<input type=hidden name=name value="$name">
	<input type=hidden name=pass value="$pass">
	<input type=hidden name=id value="$id">
	<input type=hidden name=oaite value="$aite_id">
	<div style="font-size:12px; color:#336699">■생일 선물을 준다</div>
	※「쇼핑을 한다」커멘드내의 「아이템을 창작한다」에서 작성한 아이템이 있으면 생일 선물로서 줄 수 있습니다.<br>
	<select name="okurumono">
	$ori_item
	</select>
	<input type="submit" name="Submit2" value=" O K ">
	</form></td></tr>
	
	
	<tr><td>
     <form method="POST" action="$script">
	<input type=hidden name=mode value="kokuhaku">
	<input type=hidden name=command value="mousikomi">
	<input type=hidden name=name value="$name">
	<input type=hidden name=pass value="$pass">
	<input type=hidden name=id value="$id">
	<input type=hidden name=oaite value="$aite_id">
	<input type=hidden name=kibou value="아이">
	<div style="font-size:12px; color:#336699">■아이를 만든다</div>
	※아이 조림 싶은 이름을 입력하고 버튼을 눌러 주세요(전각 10 문자 이내).상대가 OK 했을 경우, 5분의 1의 확률로 아이가 태어납니다.<br>
	<input type=text name=messe size=20> 
	<input type="submit" name="Submit2" value=" O K ">
	</form></td></tr>
	
	<tr><td>
     <form method="POST" action="$script">
	<input type=hidden name=mode value="kokuhaku">
	<input type=hidden name=command value="mousikomi">
	<input type=hidden name=name value="$name">
	<input type=hidden name=pass value="$pass">
	<input type=hidden name=id value="$id">
	<input type=hidden name=oaite value="$aite_id">
	<input type=hidden name=kibou value="이혼">
	<div style="font-size:12px; color:#336699">■이혼한다</div>
	※이혼하는 경우하의 버튼을 눌러 주세요.그 경우, 위자료로 해서 200만이 필요합니다.또 집, 토지, 아이는 상대의 것이 됩니다.취소는 할 수 없기 때문에 신중하게.<br>
	<input type="submit" name="Submit2" value=" 이혼 ">
	</form></td></tr>
	
	</table><br><br>
EOM
						}		#if(독신이 아니다) 문장이 덮어
#연인당의 송신 폼을 출력
						if($yobi3 ne "없음"){
								(@koibito)= split(/,/,$yobi3);
							foreach $one_koibito (@koibito){
								&id_check ($one_koibito);
								$aite_id=$return_id;
#독신이라면 프로포즈 버튼 표시
								if($haiguu eq "독신"){
									$propose_b= <<"EOM"
	<tr><td>
     <form method="POST" action="$script">
	<input type=hidden name=mode value="kokuhaku">
	<input type=hidden name=command value="mousikomi">
	<input type=hidden name=name value="$name">
	<input type=hidden name=pass value="$pass">
	<input type=hidden name=money value="$yobi6">
	<input type=hidden name=land value="$land">
	<input type=hidden name=house value="$house">
	<input type=hidden name=id value="$id">
	<input type=hidden name=oaite value="$aite_id">
	<input type=hidden name=kibou value="결혼">
	<div style="font-size:12px; color:#336699">■프로포즈한다(결혼을 신\한다)</div>
	고백의 대사 <input type=text name=messe size=30>
	<input type="submit" name="Submit2" value=" O K ">
	</form></td></tr>
EOM
								}
								print <<"EOM";
	<table width="95%" border="0" cellspacing="0" cellpadding="5" align=center class=sumi>
	<tr><td>
     <form method="POST" action="$script">
	<input type=hidden name=mode value="kokuhaku">
	<input type=hidden name=command value="mousikomi">
	<input type=hidden name=name value="$name">
	<input type=hidden name=pass value="$pass">
	<input type=hidden name=id value="$id">
	<input type=hidden name=oaite value="$aite_id">
	<input type=hidden name=kibou value="메시지">
	<div style="font-size:12px; color:#336699">■$one_koibito씨(연인)에게 메세지를 보낸다</div>
	<textarea cols=58 rows=4 name=messe wrap="soft"></textarea>
	<input type="submit" name="Submit2" value=" O K ">
	</form></td></tr>
	
	<tr><td>
     <form method="POST" action="$script">
	<input type=hidden name=mode value="kokuhaku">
	<input type=hidden name=command value="mousikomi">
	<input type=hidden name=name value="$name">
	<input type=hidden name=pass value="$pass">
	<input type=hidden name=id value="$id">
	<input type=hidden name=oaite value="$aite_id">
	<input type=hidden name=kibou value="송금">
	<div style="font-size:12px; color:#336699">■돈이나 소유물을 보낸다</div>
	※돈과 소유물(1점만)은 동시에 보낼 수 있습니다.<br>
	○보내는 금액 <input type=text name=kingaku size=8> 만　
	○보내는 소유물 <select name="okurumono">
    <option value="">없음</option>
	$normal_item
	</select>
	<input type="submit" name="Submit2" value=" O K ">
	</form></td></tr>
	
	<tr><td>
     <form method="POST" action="$script">
	<input type=hidden name=mode value="birthdayPresent">
	<input type=hidden name=name value="$name">
	<input type=hidden name=pass value="$pass">
	<input type=hidden name=id value="$id">
	<input type=hidden name=oaite value="$aite_id">
	<div style="font-size:12px; color:#336699">■생일 선물을 준다</div>
	※「쇼핑을 한다」커멘드내의 「아이템을 창작한다」에서 작성한 아이템이 있으면 생일 선물로서 줄 수 있습니다.<br>
	<select name="okurumono">
	$ori_item
	</select>
	<input type="submit" name="Submit2" value=" O K ">
	</form></td></tr>
	
	$propose_b;
	
	<tr><td>
     <form method="POST" action="$script">
	<input type=hidden name=mode value="kokuhaku">
	<input type=hidden name=command value="mousikomi">
	<input type=hidden name=name value="$name">
	<input type=hidden name=pass value="$pass">
	<input type=hidden name=id value="$id">
	<input type=hidden name=oaite value="$aite_id">
	<input type=hidden name=kibou value="헤어진다">
	<div style="font-size:12px; color:#336699">■헤어진다</div>
	※아래의 버튼을 누르는 곳쪽과 헤어질 수 있습니다.취소는 할 수 없기 때문에 신중하게.<br>
	<input type="submit" name="Submit2" value=" 헤어진다 ">
	</form></td></tr>
	
	</table><br><br>
EOM
							}		#foreach(연인의 수만큼 반복한다)가 닫아
						}		#if(연인이 없다) 문장이 덮어
		print <<"EOM";
		<div align="center"><a href=\"javascript:history.back()\"> [앞에 화면으로 돌아온다] </a></div>
		</body></html>
EOM
	exit;
}


#아이 만들기 메세지 소거 써브루틴
sub kodomo_messe_delete {
			my($kibou_type,$m_name,$m_messe,$m_money,$m_land,$m_house,$m_number,$m_id,$kekka,$m_yobi4,$member_file,$new_temp,@new_rank);
			$kesu_file_id=@_[0];
			$kesu_file_number=@_[1];
			$member_file="./member/$kesu_file_id" . ".cgi";
			open(MK,"$member_file") || &error("Open Error : $member_file가 열리지 않습니다.");
			while (<MK>) {
					($kibou_type,$m_name,$m_messe,$m_money,$m_land,$m_house,$m_number,$m_id,$kekka,$m_yobi4)= split(/<>/);
					if($kesu_file_number eq "$m_number"){next;}
					$new_temp="$kibou_type<>$m_name<>$m_messe<>$m_money<>$m_land<>$m_house<>$m_number<>$m_id<>$kekka<>$m_yobi4<>\n";
					push(@new_rank,$new_temp);
			}
			close(MK);
# 로그를 갱신
			&lock;
			open(MKO,">$member_file") || &error("Write Error : $member_file");
			print MKO @new_rank;
			close(MKO);	
			&unlock;
}


#이혼했을 경우의 아이 파일에의 기록
sub rikon_kodomo {
	open(KF,"$kodomo_file") || &error("Open Error : $kodomo_file");
			undef @new_oya;
			while (<KF>) {
					($k_id,$k_name,$oya1,$oya2,$seinengappi,$atama,$sports,$art,$food_time,$k_yobi2,$k_yobi3,$k_yobi4,$k_yobi5)= split(/<>/);
					if(@_[0] eq $oya1){
							$oya1 = "";
					}
					if(@_[0] eq $oya2){
							$oya2 = "";
					}
					$k_temp="$k_id<>$k_name<>$oya1<>$oya2<>$seinengappi<>$atama<>$sports<>$art<>$food_time<>$k_yobi2<>$k_yobi3<>$k_yobi4<>$k_yobi5<>\n";
					push (@new_oya,$k_temp);
			}
						close(KF);
# 로그를 갱신
#ver.1.36 여기로부터
			if (@_[1] ne "no_lock") { &lock;}
						$err = data_save($kodomo_file, @new_oya);
						if ($err) {&error("$err");}
#						open(KOUT,">$kodomo_file") || &error("Write Error : $kodomo_file");
#						print KOUT @new_oya;
#						close(KOUT);
			if (@_[1] ne "no_lock") { &unlock;}
#ver.1.36여기까지
}

#결혼했을 경우의 아이 파일에의 기록
sub kekkon_kodomo {
	open(KF,"$kodomo_file") || &error("Open Error : $kodomo_file");
			while (<KF>) {
					($k_id,$k_name,$oya1,$oya2,$seinengappi,$atama,$sports,$art,$food_time,$k_yobi2,$k_yobi3,$k_yobi4,$k_yobi5)= split(/<>/);
					if(@_[0] eq $oya1){
							$oya2 = "@_[1]";
					}elsif(@_[0] eq $oya2){
							$oya1 = "@_[1]";
					}elsif(@_[1] eq $oya1){
							$oya2 = "@_[0]";
					}elsif(@_[1] eq $oya2){
							$oya1 = "@_[0]";
					}
					$k_temp="$k_id<>$k_name<>$oya1<>$oya2<>$seinengappi<>$atama<>$sports<>$art<>$food_time<>$k_yobi2<>$k_yobi3<>$k_yobi4<>$k_yobi5<>\n";
					push (@new_oya,$k_temp);
			}
						close(KF);
# 로그를 갱신
						&lock;
#ver.1.36 여기로부터
		$err = data_save($kodomo_file, @new_oya);
		if ($err) {&error("$err");}
#						open(KOUT,">$kodomo_file") || &error("Write Error : $kodomo_file");
#						print KOUT @new_oya;
#						close(KOUT);
#ver.1.36여기까지
						&unlock;
}


#아이 파일에의 기록
sub kosodate {
		if ($in{'command'} eq "sodateru"){
						&lock;
						&openMylog($in{'id'});
						if($in{'kingaku'} <= 0){&error("입력액이 올바르지 않습니다");}
						if ($in{'kingaku'} !~ /\d/){&error("입력액이 올바르지 않습니다");}
						if ($money < $in{'kingaku'}){&error("돈이 충분하지 않습니다!");}
						$money -=$in{'kingaku'};
								&temp_routin;
	open(OUT,">$my_log_file") || &error("$my_log_file가 열리지 않습니다");
	print OUT $temp;
	close(OUT);
						
						open(KF,"$kodomo_file") || &error("Open Error : $kodomo_file");
						while (<KF>) {
							($k_id,$k_name,$oya1,$oya2,$seinengappi,$atama,$sports,$art,$food_time,$k_yobi2,$k_yobi3,$k_yobi4,$k_yobi5)= split(/<>/);
							if($in{'k_name'} eq $k_name){
									if($in{'bunya'} eq "atama"){$atama = $atama + $in{'kingaku'};}
									if($in{'bunya'} eq "sports"){$sports = $sports + $in{'kingaku'};}
									if($in{'bunya'} eq "art"){$art = $art+ $in{'kingaku'};}
									
							}
							$k_temp="$k_id<>$k_name<>$oya1<>$oya2<>$seinengappi<>$atama<>$sports<>$art<>$food_time<>$k_yobi2<>$k_yobi3<>$k_yobi4<>$k_yobi5<>\n";
							push (@new_kodomo,$k_temp);
						}
						close(KF);
# 로그를 갱신
#ver.1.36 여기로부터
		$err = data_save($kodomo_file, @new_kodomo);
		if ($err) {&error("$err");}
#						open(KOUT,">$kodomo_file") || &error("Write Error : $kodomo_file");
#						print KOUT @new_kodomo;
#						close(KOUT);
#ver.1.36여기까지
						&unlock;
						&message("$in{'k_name'}에 $in{'kingaku'}만의 돈을 들였습니다.","login_view");
		}else{
						&header(2);
						print << "EOM";
<div align=center style=font-size:16px>육아</div><br>
<table border=0 width=90% align=center cellspacing="1" cellpadding="5">
<tr><td colspan=10>●기르고 싶은 분야를 선택해 금액을 입력해 주세요.건 금액에 의해서 각각의 능\력\이 오릅니다.또 배우자도 같은 아이를 길러 가게 됩니다.아이 랭킹의 상위 목표로 해 노력합시다.<br>
●아이는 1일 1세씩 나이를 합니다.20세가 되면 아이는 자립해, 부모 슬하로부터 없어지는 것과 동시에, 아이 랭킹에도\겉(표)\나타나지 않게 됩니다.또, 그때까지 걸치고 있던 돈과 분야에 의해서 아이의 직업이 결정됩니다.</td></tr></table>
EOM
						open(KF,"$kodomo_file") || &error("Open Error : $kodomo_file");
						while (<KF>) {
							($k_id,$k_name,$oya1,$oya2,$seinengappi,$atama,$sports,$art,$food_time,$k_yobi2,$k_yobi3,$k_yobi4,$k_yobi5)= split(/<>/);
								if($in{'name'} eq $oya1 || $in{'name'} eq $oya2){
								if($k_yobi2 eq "on"){
								print <<"EOM";
<br><table  class=sumi border=0 width=90% align=center cellspacing="1" cellpadding="5"><tr><td>
<div class=kuro>$k_name씨는 자립해$k_yobi3가 되었습니다.</div></td></tr></table>
EOM
								}else{		#자립으로 없는 경우
#ver.1.36 여기로부터
									($sec,$min,$hour,$mday,$mon,$year,$wday) = split(/,/,$seinengappi);
									$now_zikan = time;
									if ($module_on == 1) {
										$nenrei =  int(($now_zikan-$food_time)/60/60/24);
									}else{
										&konotosi_get($seinengappi);
									}
									$mon  = $mon+1;
									$year = $year + 1900;
									$date = "$year년$mon월$mday일";
									$atama_hyouzi=int($atama/60);
									$sports_hyouzi=int($sports/60);
									$art_hyouzi=int($art/60);
#ver.1.36여기까지
								if($nenrei >= 20){&hatati($k_name,$in{'haiguu'}); next;}

								print << "EOM";
	<form method="POST" action="$script">
	<input type=hidden name=mode value="kosodate">
	<input type=hidden name=command value="sodateru">
	<input type=hidden name=name value="$in{'name'}">
	<input type=hidden name=pass value="$in{'pass'}">
	<input type=hidden name=id value="$in{'id'}">
	<input type=hidden name=k_name value="$k_name">
<table  class=sumi border=0 width=90% align=center cellspacing="1" cellpadding="5">
		<tr bgcolor=#ffcc99><td align=center  width=120>이름</td><td align=center >생년월일</td><td align=center >두의 좋은 점</td><td align=center >운동신경</td><td align=center >미술 센스</td></tr>
		<tr><td align=center  width=120><font color=#ff3300>★$k_name</font>($nenrei나이) $nenrei2</td><td align=center >$date</td><td align=center >$atama_hyouzi</td><td align=center >$sports_hyouzi</td><td align=center >$art_hyouzi</td></tr>
		<tr><td colspan=5>
	<select name="bunya">
	<option value="atama">공부</option>
	<option value="sports">스포츠</option>
	<option value="art">예술</option>
      </select>
	   의 분야에<input type=text name=kingaku size=10> 만 걸친다  <input type=submit value="OK">
		</td></tr></form>
		<tr><td colspan=5><hr size=1><span style="font-size:12;color:336699">■자립시킨다</span><br>
		※이쪽에서 강제적으로 아이를 자립시킬 수 있습니다.한 번 자립시키면 두 번 다시 부모 슬하에는 돌아오지 않으므로, 사용할 때는 배우자와 자주(잘) 상담해 주세요.<br>
	<form method="POST" action="$script">
	<input type=hidden name=mode value="ziritu">
	<input type=hidden name=command value="ziritu_kakunin">
	<input type=hidden name=name value="$in{'name'}">
	<input type=hidden name=pass value="$in{'pass'}">
	<input type=hidden name=id value="$in{'id'}">
	<input type=hidden name=k_name value="$k_name">
	<input type=hidden name=haiguu value="$in{'haiguu'}">
		<input type=submit value="자립시킨다">
		</table></form>
EOM
									}			#else(자립하고 있지 않는 경우)가 닫아
								}			#if(자신이 부모의 경우)가 닫아
						}			#while가 닫아
						close(KF);
						
		print <<"EOM";
		<div align="center">
		<a href=\"javascript:history.back()\"> [앞에 화면으로 돌아온다] </a>
        </div>
		</body></html>
EOM
					exit;
		}		#else가 닫아
}

##자립 써브루틴
sub hatati {
my($k_id,$k_name,$oya1,$oya2,$seinengappi,$atama,$sports,$art,$food_time,$k_yobi2,$k_yobi3,$k_yobi4,$k_yobi5,$k_temp,@new_syoku);
	undef @new_syoku;
	open(HA,"$kodomo_file") || &error("Open Error : $kodomo_file");
	while (<HA>) {
	($k_id,$k_name,$oya1,$oya2,$seinengappi,$atama,$sports,$art,$food_time,$k_yobi2,$k_yobi3,$k_yobi4,$k_yobi5)= split(/<>/);
							if(@_[0] eq $k_name){
									$k_yobi2 = "on";
									if ($atama > $sports){
											if($atama > $art){
												$k_syokugyou = 1;
											}else{$k_syokugyou = 3;}
									}elsif($sports > $art){
											$k_syokugyou = 2;
									}else{$k_syokugyou = 3;}
									if ($k_syokugyou == 1){$syokugyou_suuti = $atama; $k_yobi4=$atama;}
									if ($k_syokugyou == 2){$syokugyou_suuti = $sports; $k_yobi4=$sports;}
									if ($k_syokugyou == 3){$syokugyou_suuti = $art; $k_yobi4=$art;}
									&syokugyou_kettei($k_syokugyou,$syokugyou_suuti);
									$k_yobi3 = $returtn_syokugyou;
										if(@_[2] != 1){
						print <<"EOM";
<br><table  class=sumi border=0 width=90% align=center cellspacing="1" cellpadding="5"><tr><td>
<div class=kuro>$k_name씨는 자립해$k_yobi3가 되었습니다.</div></td></tr></table>
EOM
										}
							}		#이름 판단이 닫아
					$k_temp="$k_id<>$k_name<>$oya1<>$oya2<>$seinengappi<>$atama<>$sports<>$art<>$food_time<>$k_yobi2<>$k_yobi3<>$k_yobi4<>$k_yobi5<>\n";
					push (@new_syoku,$k_temp);
			}		#while가 닫아
	close(HA);
# 로그를 갱신
						&lock;
#ver.1.36 여기로부터
		$err = data_save($kodomo_file, @new_syoku);
		if ($err) {&error("$err");}
#						open(KOUT,">$kodomo_file") || &error("Write Error : $kodomo_file");
#						print KOUT @new_syoku;
#						close(KOUT);
#ver.1.36여기까지
#로그 파일로부터 아이를 지운다
										if(@_[2] != 1){
						&my_child_delete(@_[0],@_[1]);
										}
						&unlock;
}

sub ziritu {
	if ($in{'command'} eq "ziritu_kakunin"){
						&header(2);
			print <<"EOM";
				<table  border=0 width=90% align=center cellspacing="1" cellpadding="5"><tr><td>
				<br><div class=purasu align=center>$in{'k_name'}씨를 자립시킵니다.좋습니까?</div>
				<form method="POST" action="$script">
				<input type=hidden name=mode value="ziritu">
				<input type=hidden name=name value="$in{'name'}">
				<input type=hidden name=pass value="$in{'pass'}">
				<input type=hidden name=id value="$in{'id'}">
				<input type=hidden name=k_name value="$in{'k_name'}">
				<input type=hidden name=haiguu value="$in{'haiguu'}">
				<div align=center><input type=submit value=" O K "></div>
				</td></tr></table></form>
						<div align="center">
		<a href=\"javascript:history.back()\"> [앞에 화면으로 돌아온다] </a>
        </div>		</body></html>
EOM
exit;
	}else{
	open(KF,"$kodomo_file") || &error("Open Error : $kodomo_file");
	while (<KF>) {
	($k_id,$k_name,$oya1,$oya2,$seinengappi,$atama,$sports,$art,$food_time,$k_yobi2,$k_yobi3,$k_yobi4,$k_yobi5)= split(/<>/);
							if($in{'k_name'} eq $k_name){
									$k_yobi2 = "on";
									if ($atama > $sports){
											if($atama > $art){
												$k_syokugyou = 1;
											}else{$k_syokugyou = 3;}
									}elsif($sports > $art){
											$k_syokugyou = 2;
									}else{$k_syokugyou = 3;}
									if ($k_syokugyou == 1){$syokugyou_suuti = $atama; $k_yobi4=$atama;}
									if ($k_syokugyou == 2){$syokugyou_suuti = $sports; $k_yobi4=$sports;}
									if ($k_syokugyou == 3){$syokugyou_suuti = $art; $k_yobi4=$art;}
									&syokugyou_kettei($k_syokugyou,$syokugyou_suuti);
									$k_yobi3 = $returtn_syokugyou;
							}		#이름 판단이 닫아
					$k_temp="$k_id<>$k_name<>$oya1<>$oya2<>$seinengappi<>$atama<>$sports<>$art<>$food_time<>$k_yobi2<>$k_yobi3<>$k_yobi4<>$k_yobi5<>\n";
					push (@new_syoku,$k_temp);
			}		#while가 닫아
						close(KF);
# 로그를 갱신
						&lock;
#ver.1.36 여기로부터
		$err = data_save($kodomo_file, @new_syoku);
		if ($err) {&error("$err");}
#						open(KOUT,">$kodomo_file") || &error("Write Error : $kodomo_file");
#						print KOUT @new_syoku;
#						close(KOUT);
#ver.1.36여기까지
#로그 파일로부터 아이를 지운다
						&my_child_delete($in{'k_name'},$in{'haiguu'});
						&unlock;
			&message("$in{'k_name'}씨는 자립해, $returtn_syokugyou가 되었습니다.","login_view");
	}		#else(커멘드가 없는 경우)가 닫아
}

#자립한 아이를 자신의 파일로부터 지운다
sub my_child_delete {
					&openMylog($in{'id'});
								(@my_kodomo_hairetu)= split(/,/,$kodomo);
								foreach(@my_kodomo_hairetu){
									if(@_[0] eq $_){next;}
									push(@new_kodomo_hairetu,$_);
								}
								$kodomo=join(",",@new_kodomo_hairetu);
					&temp_routin;
	open(OUT,">$my_log_file") || &error("$my_log_file가 열리지 않습니다");
	print OUT $temp;
	close(OUT);
					if(@_[1] ne "독신"){
					&id_check(@_[1]);
					&openAitelog($return_id);
								(@my_kodomo_hairetu)= split(/,/,$kodomo);
								foreach(@my_kodomo_hairetu){
									if(@_[0] eq $_){next;}
									push(@your_new_kodomo_hairetu,$_);
								}
								$kodomo=join(",",@your_new_kodomo_hairetu);
								&temp_routin;
	open(OUT,">$aite_log_file") || &error("$aite_log_file가 열리지 않습니다");
	print OUT $temp;
	close(OUT);
					}
}

##아이의 직업 결정 써브루틴
sub syokugyou_kettei {
		if (@_[0] == 1){
				if(@_[1] < 500) {
						$returtn_syokugyou="불량 사회인";
				}elsif(@_[1] < 5000) {
						$returtn_syokugyou="조차 없는 회사원";
				}elsif (@_[1] < 50000){
						$ruret =int(rand(10))+1;
						if($ruret == 1){$returtn_syokugyou="간호사";}
						if($ruret == 2){$returtn_syokugyou="어부";}
						if($ruret == 3){$returtn_syokugyou="전기제품가게씨";}
						if($ruret == 4){$returtn_syokugyou="수학의 선생님";}
						if($ruret == 5){$returtn_syokugyou="가정교사";}
						if($ruret == 6){$returtn_syokugyou="편의점의 점장";}
						if($ruret == 7){$returtn_syokugyou="선술집의 점장";}
						if($ruret == 8){$returtn_syokugyou="경찰관";}
						if($ruret == 9){$returtn_syokugyou="아나운서";}
						if($ruret == 10){$returtn_syokugyou="텔레폰 아포인트멘트 인터";}
				}elsif (@_[1] < 150000){
						$ruret =int(rand(10))+1;
						if($ruret == 1){$returtn_syokugyou="덴츠의 과장";}
						if($ruret == 2){$returtn_syokugyou="교감 선생님";}
						if($ruret == 3){$returtn_syokugyou="대학원생";}
						if($ruret == 4){$returtn_syokugyou="부장";}
						if($ruret == 5){$returtn_syokugyou="1류기업의 사원";}
						if($ruret == 6){$returtn_syokugyou="요요기제미의 명물 교사";}
						if($ruret == 7){$returtn_syokugyou="후지텔레비의 인기 아나운서";}
						if($ruret == 8){$returtn_syokugyou="교장 선생님";}
						if($ruret == 9){$returtn_syokugyou="NTT 도코모의 부장";}
						if($ruret == 10){$returtn_syokugyou="공장장";}
				}elsif (@_[1] < 1000000){
						$ruret =int(rand(5))+1;
						if($ruret == 1){$returtn_syokugyou="소니의 사장";}
						if($ruret == 2){$returtn_syokugyou="변호사";}
						if($ruret == 3){$returtn_syokugyou="파일럿";}
						if($ruret == 4){$returtn_syokugyou="의사";}
						if($ruret == 5){$returtn_syokugyou="경시총감";}
				}elsif (@_[1] < 5000000){
						$ruret =int(rand(6))+1;
						if($ruret == 1){$returtn_syokugyou="도쿄대학 교수";}
						if($ruret == 2){$returtn_syokugyou="경시총감";}
						if($ruret == 3){$returtn_syokugyou="문부대신";}
						if($ruret == 4){$returtn_syokugyou="노벨상 수상 박사";}
						if($ruret == 5){$returtn_syokugyou="세계의 발명왕";}
						if($ruret == 6){$returtn_syokugyou="토쿄지사";}
				}else{
						$ruret =int(rand(5))+1;
						if($ruret == 1){$returtn_syokugyou="내각총리대신";}
						if($ruret == 2){$returtn_syokugyou="블랙잭의 후계자";}
						if($ruret == 3){$returtn_syokugyou="최강의 변호사";}
						if($ruret == 4){$returtn_syokugyou="도쿄대학 명예 교수";}
						if($ruret == 5){$returtn_syokugyou="마이크로소\후\트 CEO";}
				}
				
		}elsif (@_[0] == 2){
				if(@_[1] < 500) {
						$returtn_syokugyou="깡패";
				}elsif(@_[1] < 5000) {
						$returtn_syokugyou="조차 없는 회사원";
				}elsif (@_[1] < 50000){
						$ruret =int(rand(10))+1;
						if($ruret == 1){$returtn_syokugyou="조차 없는 J리거";}
						if($ruret == 2){$returtn_syokugyou="동네 야구의 코치";}
						if($ruret == 3){$returtn_syokugyou="체육의 선생님";}
						if($ruret == 4){$returtn_syokugyou="2군의 프로야구 선수";}
						if($ruret == 5){$returtn_syokugyou="조차 없는 마라톤 러너";}
						if($ruret == 6){$returtn_syokugyou="이길 수 없는 프로 복서";}
						if($ruret == 7){$returtn_syokugyou="아랫쪽의 역사";}
						if($ruret == 8){$returtn_syokugyou="조차 없는 발리볼 선수";}
						if($ruret == 9){$returtn_syokugyou="J2의 보결";}
						if($ruret == 10){$returtn_syokugyou="조차 없는 농구 선수";}
				}elsif (@_[1] < 150000){
						$ruret =int(rand(10))+1;
						if($ruret == 1){$returtn_syokugyou="J리거";}
						if($ruret == 2){$returtn_syokugyou="프로야구 선수";}
						if($ruret == 3){$returtn_syokugyou="프로 복서";}
						if($ruret == 4){$returtn_syokugyou="발리볼 선수";}
						if($ruret == 5){$returtn_syokugyou="농구 선수";}
						if($ruret == 6){$returtn_syokugyou="수영의 선수";}
						if($ruret == 7){$returtn_syokugyou="핸드볼의 선수";}
						if($ruret == 8){$returtn_syokugyou="K1파이터";}
						if($ruret == 9){$returtn_syokugyou="역사";}
						if($ruret == 10){$returtn_syokugyou="유도 선수";}
				}elsif (@_[1] < 1000000){
						$ruret =int(rand(5))+1;
						if($ruret == 1){$returtn_syokugyou="인기 J리거";}
						if($ruret == 2){$returtn_syokugyou="거인군의 4번 타자";}
						if($ruret == 3){$returtn_syokugyou="세이부의 에이스";}
						if($ruret == 4){$returtn_syokugyou="K1챔피언";}
						if($ruret == 5){$returtn_syokugyou="복싱 일본 체프";}
				}elsif (@_[1] < 5000000){
						$ruret =int(rand(6))+1;
						if($ruret == 1){$returtn_syokugyou="메이저 리그의 4번 타자";}
						if($ruret == 2){$returtn_syokugyou="세리에 A의 10번";}
						if($ruret == 3){$returtn_syokugyou="양키스의 에이스";}
						if($ruret == 4){$returtn_syokugyou="복싱 세계 챔피언";}
						if($ruret == 5){$returtn_syokugyou="육상의 금메달리스트";}
						if($ruret == 6){$returtn_syokugyou="요코즈나";}
				}else{
						$ruret =int(rand(6))+1;
						if($ruret == 1){$returtn_syokugyou="세계 제일 빠른 남자";}
						if($ruret == 2){$returtn_syokugyou="양키스의 영구 결번";}
						if($ruret == 3){$returtn_syokugyou="세계 제일 강한 남자";}
						if($ruret == 4){$returtn_syokugyou="100 m의 세계기록 보유자";}
						if($ruret == 5){$returtn_syokugyou="역사에 남는 축구 선수";}
						if($ruret == 6){$returtn_syokugyou="지하 조직의 제왕";}
				}
		}else{
				if(@_[1] < 500) {
						$returtn_syokugyou="부랑자";
				}elsif(@_[1] < 5000) {
						$returtn_syokugyou="팔리지 않는 연예인";
				}elsif (@_[1] < 50000){
						$ruret =int(rand(10))+1;
						if($ruret == 1){$returtn_syokugyou="그래픽 디자이너";}
						if($ruret == 2){$returtn_syokugyou="떠돌이 광대";}
						if($ruret == 3){$returtn_syokugyou="팔리지 않는 화가";}
						if($ruret == 4){$returtn_syokugyou="미용사";}
						if($ruret == 5){$returtn_syokugyou="팔리지 않는 조각가";}
						if($ruret == 6){$returtn_syokugyou="음악의 선생님";}
						if($ruret == 7){$returtn_syokugyou="미술의 선생님";}
						if($ruret == 8){$returtn_syokugyou="복식 디자이너";}
						if($ruret == 9){$returtn_syokugyou="팔리지 않는 만담가";}
						if($ruret == 10){$returtn_syokugyou="일러스트레이터";}
				}elsif (@_[1] < 150000){
						$ruret =int(rand(10))+1;
						if($ruret == 1){$returtn_syokugyou="2류아이돌";}
						if($ruret == 2){$returtn_syokugyou="예술가";}
						if($ruret == 3){$returtn_syokugyou="조각가";}
						if($ruret == 4){$returtn_syokugyou="플룻 연주자";}
						if($ruret == 5){$returtn_syokugyou="밴드 맨";}
						if($ruret == 6){$returtn_syokugyou="피아노 연주자";}
						if($ruret == 7){$returtn_syokugyou="건축가";}
						if($ruret == 8){$returtn_syokugyou="화가";}
						if($ruret == 9){$returtn_syokugyou="미대교수";}
						if($ruret == 10){$returtn_syokugyou="스타일리스트";}
				}elsif (@_[1] < 1000000){
						$ruret =int(rand(6))+1;
						if($ruret == 1){$returtn_syokugyou="인기 아이돌";}
						if($ruret == 2){$returtn_syokugyou="인기인 연예인";}
						if($ruret == 3){$returtn_syokugyou="유명한 화가";}
						if($ruret == 4){$returtn_syokugyou="유명한 건축가";}
						if($ruret == 5){$returtn_syokugyou="유명한 디자이너";}
						if($ruret == 6){$returtn_syokugyou="유명한 음악가";}
				}elsif (@_[1] < 5000000){
						$ruret =int(rand(6))+1;
						if($ruret == 1){$returtn_syokugyou="초인기 아이돌";}
						if($ruret == 2){$returtn_syokugyou="거물 연예인";}
						if($ruret == 3){$returtn_syokugyou="세계적인 건축가";}
						if($ruret == 4){$returtn_syokugyou="세계적인 화가";}
						if($ruret == 5){$returtn_syokugyou="세계적인 디자이너";}
						if($ruret == 6){$returtn_syokugyou="예술 대학 명예 교수";}
				}else{
						$ruret =int(rand(5))+1;
						if($ruret == 1){$returtn_syokugyou="거장";}
						if($ruret == 2){$returtn_syokugyou="아카데미상 수상 배우";}
						if($ruret == 3){$returtn_syokugyou="그래미상 수상 가수";}
						if($ruret == 4){$returtn_syokugyou="역사에 남는 할리우드 스타";}
						if($ruret == 5){$returtn_syokugyou="세계 제일이라고 해지는 프로듀서";}
				}
		}
}

1;

