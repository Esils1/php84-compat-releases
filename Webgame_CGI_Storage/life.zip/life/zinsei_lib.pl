#f[^?
sub data_save {
	my($data_path, @WRITE_DATA) = @_;
	my($err) = '';
	my($os) = &os();
	my($dev, $ino, $mode, $nlink, $uid, $gid, $rdev, $size, $atime, $mtime, $ctime, $blksize, $blocks);
	$data_path =~ /(.+)\..+$/;
	my($filename) = $1;
	my($date) = time + $timelag * 3600;
	if ($filename !~ /.+/) { $err = 'bad Filename(Not Extension?)'; }
	if (!$err) {
		my($tmpfile) = "$filename.tmp";
		my($tmpflag) = 0;
		foreach (1 .. 10) {
			unless (-f $tmpfile) { $tmpflag = 1; last; }
			($dev, $ino, $mode, $nlink, $uid, $gid, $rdev, $size, $atime, $mtime, $ctime, $blksize, $blocks) = stat($tmpfile);
			if ($date - $mtime > 600) { unlink $tmpfile; $tmpflag = 1; last; }
			$tmpflag = 0;
			sleep(1);
		}
		if ($tmpflag) {
			$tmp_dummy = "$$\.tmp";
			if (!open(TMP,">$tmp_dummy")) { $err = 'bad New TemporaryFile'; }
			if (!$err) {
				close(TMP);
				chmod 0666,$tmp_dummy;
				if (!open(TMP,">$tmp_dummy")) { $err = 'bad New TemporaryFile'; }
				if (!$err) {
					binmode TMP;
					print TMP @WRITE_DATA;
					close(TMP);
					foreach (1 .. 10) {
						unless (-f $tmpfile) {
							if (!open(TMP,">$tmpfile")) {
								$err = 'bad LockFile System';
								last;
							}
							if (!$err) {
								close(TMP);
								$os =~ /windows/i && unlink $data_path;
								rename($tmp_dummy, $data_path);
								unlink $tmpfile;
								last;
							}
						}
						sleep(1);
					}
				}
			}
		}
	}
	$err;
}
	
sub os {
	#
	#	UNIX	: SunOS / Unix
	#	Linux	: Linux
	#	Windows	: Windows
	#
	my($os) = `uname -a`;
	if (!$os) { $os = `ver`; }
}

sub ds {
	&header(2);
	print "cha" . "nje";
}

1;