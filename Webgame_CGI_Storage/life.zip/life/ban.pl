#반의 테두리의 출력
sub ban{
	if($in{'mode'} eq "cont"){
			&id_check($in{'name'});
			if($return_id == ""){&error("그 이름에서는 등록되어 있지 않습니다!");}
			$my_log_file = "./member/$return_id"."log.cgi";
			if(! -f "$my_log_file"){
					&hukkatu;
			}
	}else{
			$my_log_file = "./member/"."$in{'id'}"."log.cgi";
	}
		open(IN,"$my_log_file") || &error("로그 파일($my_log_file)이 열리지 않습니다.<br>재차 로그인해도 동일한 관리인($master_ad)까지 메일을 주세요.");
		$my_prof = <IN>;
		if($my_prof == ""){&error("로그 파일에 문제가 일어났습니다.<br>수고스럽겠지만, 관리인($master_ad)까지 메일을 주세요.");}
		&split_var2($my_prof);
	close(IN);
				if($in{'pass'} ne $pass){
					&error("이름과 패스워드가 일치하지 않습니다!");
				}
				if(@_[0] eq "start"){
					$ikubasyo=$basyo;
				}else{
					if($in{'saihuri'} eq "on"){
							$genzai_time = time;
							if($seigen_time==1){
									$seigen_zikan_byou=60*60*24*$seigen_zikan;
									if($genzai_time-$yobi10 < $seigen_zikan_byou){&error("주사위를 흔드는 간격은$seigen_zikan일입니다.");}
							}elsif($seigen_time==2){
									$seigen_zikan_byou=60*60*$seigen_zikan;
									if($genzai_time-$yobi10 < $seigen_zikan_byou){&error("주사위를 흔드는 간격은$seigen_zikan 시간입니다.");}
							}elsif($seigen_time==3){
									$seigen_zikan_byou=60*$seigen_zikan;
									if($genzai_time-$yobi10 < $seigen_zikan_byou){&error("주사위를 흔드는 간격은$seigen_zikan분입니다.");}
							}elsif($seigen_time==4){
									if($genzai_time-$yobi10 < $seigen_zikan){&error("주사위를 흔드는 간격은$seigen_zikan초입니다.");}
							}
						}
					$ikubasyo=$in{'my_basyo'};
				}

	&header;
	$ima=$ikubasyo;
	for ($i =0;$i < 32; $i++){
		$basyoiro[$i] = "#ffffff";
	}

	$basyoiro[$ima]="#ffff66";
	print <<"EOM";
	<table border="0" cellspacing="0" cellpadding="0" align="center" width="100%" height=100%>
<tr><td align=center>
	<table border="0" cellspacing="0" cellpadding="6" align="center" width="630" bgcolor="#FFFFFF">
  <tr> 
    <td bgcolor=$basyoiro[16] width="90" height="40" class="sumi"><img src="$img_dir/space.gif" width="90" height="1"><br>
      <div class="midasi"><span style="font-size:15px;color:#ff9900">LUCKY !</span></div>
      <span class="honbun"></span> </td>
	  
    <td bgcolor=$basyoiro[17]  width="90" height="40"  class="migi"><img src="$img_dir/space.gif" width="90" height="1"><br>
      <div class="midasi2">사업 실패</div>
      </td>
	  
    <td bgcolor=$basyoiro[18] width="90" height="40"  class="migi"><img src="$img_dir/space.gif" width="90" height="1"><br>
      <div class="midasi">경마</div>
      </td>
	  
    <td bgcolor=$basyoiro[19] width="90" height="40" class="migi"><img src="$img_dir/space.gif" width="90" height="1"><br>
      <div class="midasi2">강도</div>
      </td>
	  
    <td bgcolor=$basyoiro[20] width="90" height="40"  class="migi"><img src="$img_dir/space.gif" width="90" height="1"><br>
      <div class="midasi2">파산</div>
       </td>
	  
    <td bgcolor=$basyoiro[21] width="90" height="40"  class="migi"><img src="$img_dir/space.gif" width="90" height="1"><br>
      <div class="midasi">CD발매</div>
       </td>
	  
    <td bgcolor=$basyoiro[22] width="90" height="40"  class="migi"><img src="$img_dir/space.gif" width="90" height="1"><br>
      <div class="midasi"><span style="font-size:13;color:#000000">GO START</span></div>
      </td>
	  
  </tr>
  <tr> 
    <td bgcolor=$basyoiro[15] width="90" height="40"  class="sita"> 
      <div class="midasi">게임 개발</div>
       </td>
	  
    <td colspan="5" rowspan="9">
EOM
	if($in{'saihuri'} eq "on"){
			&saikoro2;
	}else{
	print <<"EOM";
	
	<!--메인 화면 여기로부터-->	
	<IFRAME src="$script?mode=$in{'yobidasi'}&id=$in{'id'}&name=$in{'name'}&pass=$in{'pass'}&my_basyo=$ikubasyo&start_flag=$in{'start_flag'}&zoro=$in{'zoro'}&ikkai=$in{'ikkai'}&command=$in{'command'}"  width=500 height=340 scrolling=auto marginheight=0 FRAMEBORDER=0></IFRAME>
	<!--메인 화면 여기까지-->
EOM
	}
	
	$copyright = "<a href=http://brassier" . "e.jp/ target=_blank>" . "- 인" . "생게" . "임 $version -</a>" . "<br>한". "글" . "화 : 찬제". "(per" ."list골뱅이gmail.com)";
	print <<"EOM";
	</td>
	
    <td bgcolor=$basyoiro[23] width="90" height="40"  class="sita"> 
      <div class="midasi2">화재</div>
       </td>
	  
  </tr>
  <tr> 
    <td bgcolor=$basyoiro[14] width="90" height="40"  class="sita"> 
      <div class="midasi"><span style="color:#339966">급료</span></div>
       </td>
	  
    <td bgcolor=$basyoiro[24] width="90" height="40"  class="sita"> 
      <div class="midasi2">입원</div>
       </td>
	  
  </tr>
  <tr> 
    <td bgcolor=$basyoiro[13] width="90" height="40" class="sita"> 
      <div class="midasi">호경기</div>
      </td>
	  
    <td bgcolor=$basyoiro[25] width="90" height="40" class="sita"> 
      <div class="midasi">장사 번성</div>
       </td>
	  
  </tr>
  <tr> 
    <td bgcolor=$basyoiro[12] width="90" height="40" class="sita"> 
      <div class="midasi2">대공황</div>
      </td>
	  
    <td bgcolor=$basyoiro[26] width="90" height="40" class="sita"> 
      <div class="midasi"><span style="font-size:15px;color:#ff9900">LOTO6</span></div>
       </td>
	  
  </tr>
    <tr> 
    <td bgcolor=$basyoiro[11] width="90" height="40" class="sita"> 
      <div class="midasi"><span style="font-size:15px;color:#ff9900">Card Game</span></div>
      <span class="honbun"></span> </td>
	  
    <td bgcolor=$basyoiro[27] width="90" height="40" class="sita"> 
      <div class="midasi2">세관</div>
       </td>
	  
  </tr>
    <tr> 
    <td bgcolor=$basyoiro[10] width="90" height="40" class="sita"> 
      <div class="midasi">온천 발견</div>
       </td>
	  
    <td bgcolor=$basyoiro[28] width="90" height="40" class="sita"> 
      <div class="midasi">생일</div>
       </td>
	  
  </tr>
    <tr> 
    <td bgcolor=$basyoiro[9] width="90" height="40" class="sita"> 
      <div class="midasi">책을 쓴다</div>
      <span class="honbun"></span> </td>
	  
    <td bgcolor=$basyoiro[29] width="90" height="40" class="sita"> 
      <div class="midasi2">세무서</div>
       </td>
	  
  </tr>
    <tr> 
    <td bgcolor=$basyoiro[8] width="90" height="40" class="sita"> 
      <div class="midasi"><span style=color:#339966>스킬 업</span></div>
      <span class="honbun"></span> </td>
	  
    <td bgcolor=$basyoiro[30] width="90" height="40" class="sita"> 
      <div class="midasi" style=color:#996633>보상</div>
       </td>
	  
  </tr>
    <tr> 
    <td bgcolor=$basyoiro[7] width="90" height="40" class="sita"> 
      <div class="midasi"><span style="font-size:15px;color:#FF9999">LOVE</span></div>
      <span class="honbun"></span> </td>
	  
    <td bgcolor=$basyoiro[31] width="90" height="40" class="sita"> 
      <div class="midasi"><span style="font-size:15px;color:#ff9900">Chance !</span></div>
       </td>
	  
  </tr>
  <tr> 
    <td bgcolor=$basyoiro[6] width="90" height="40" class="sita"> 
      <div class="midasi"><span style="color:#000000">형무소</span></div>
    </td>
	
    <td bgcolor=$basyoiro[5]  class="migi"> 
      <div class="midasi">지갑 줍다</div>
       </td>
	  
    <td bgcolor=$basyoiro[4]  class="migi"> 
      <div class="midasi2">일의 실수</div>
       </td>
	  
    <td bgcolor=$basyoiro[3]  class="migi"> 
      <div class="midasi2">대지진 발생</div>
       </td>
	  
    <td bgcolor=$basyoiro[2]  class="migi"> 
      <div class="midasi">회사 공로</div>
      </td>
	  
    <td bgcolor=$basyoiro[1] class="naka"> 
      <div class="midasi">파칭코</div>
      </td>
	  
    <td bgcolor=$basyoiro[0] width="90" height="40" class="sita"> 
      <div class="midasi" style=color:#000000>START</div>
       </td>
	  
  </tr>
</table><div align=center class=honbun>$copyright2</div></td></tr></table>
EOM
	print "</body></html>";
	exit;
}

sub ranking_keisan {
	my($id,$name,$pass,$money,$basyo,$haiguu,$kodomo,$love,$land,$house,$kabu,$kounyuu,$sex,$yobi1,$yobi2,$yobi3,$yobi4,$yobi5,$yobi6,$yobi7,$yobi8,$yobi9,$yobi10,$yobi11,$yobi12,$yobi13,$yobi14);
	open(RK,"$logfile") || &error("Open Error : $logfile");
	@rankingMember = <RK>;
		undef @alldata;
		undef @keys;
		foreach (@rankingMember) {
			$data=$_;
			$key=(split(/<>/,$data))[@_[0]];		#소트 하는 요소를 선택한다
			push @alldata,$data;
			push @keys,$key;
		}
	close(RK);
		sub bykeys{$keys[$b] <=> $keys[$a];}
		@alldata=@alldata[ sort bykeys 0..$#alldata]; 
		$i=1;
	foreach $one(@alldata) {
($id,$name,$pass,$money,$basyo,$haiguu,$kodomo,$love,$land,$house,$kabu,$kounyuu,$sex,$yobi1,$yobi2,$yobi3,$yobi4,$yobi5,$yobi6,$yobi7,$yobi8,$yobi9,$yobi10,$yobi11,$yobi12,$yobi13,$yobi14)= split(/<>/,$one);
			if(@_[1] eq $name){last;}
			$i++;
	}
	$return_juni = $i;
	$return_tensuu = $saidai_ninzuu-$i+1;
}


1;

