sub main_view {
my($sec,$min,$hour,$mday,$mon,$year,$wday);
#긫긞긏귺긞긵룉뿚
			open(BACK,"$back_time_file") || &error("Open Error : $back_time_file");
			$back_up_time=<BACK>;
			$ENV{'TZ'} = "JST-9";
			($sec,$min,$hour,$mday,$mon,$year,$wday) = localtime(time);
			if($hour ne  $back_up_time){
				&lock;
				open(TI,">$back_time_file") || &error("Open Error : $back_time_file");
				print TI $hour;
				close(TI);
				
				open(DA,"$logfile") || &error("Open Error : $logfile");
				@backup_data= <DA>;
				close(DA);
				
				open(BACKOUT,">back_up.cgi") || &error("back_up.cgi");
				print BACKOUT @backup_data;
				close(BACKOUT);
				
				open(KD,"$kodomo_file") || &error("Open Error : $logfile");
				@kodomo_backup= <KD>;
				close(KD);
				if(@kodomo_backup != ""){
					open(KDOUT,">kodomo_back.cgi") || &error("kodomo_back.cgi");
					print KDOUT @kodomo_backup;
					close(KDOUT);
				}

				open(IFE,"$item_file") || &error("Open Error : $item_file");
				@items_backup= <IFE>;
				close(IFE);
				if(@items_backup != ""){
					open(IFO,">item_back_log.cgi") || &error("item_back_log.cgi");
					print IFO @items_backup;
					close(IFO);
				}
				&unlock;
			}
				open(DA,"$logfile") || &error("Open Error : $logfile");
				@sankaMember= <DA>;
				$sankasyasuu = $#sankaMember+1;
				if($sankasyasuu < $saidai_ninzuu){
					$sinkiButton="<span style=\"font-size:9pt\"><font color=red><b>●<a href=./touroku.html>신규 등록</a>(현재의 등록자수：$sankasyasuu사람/최대 등록자수：$saidai_ninzuu사람)</span></font></b>";
				}else{
					$sinkiButton="※현재, 최대 등록자수에 이르고 있기 때문에, 신규 등록은 할 수 없습니다.";
				}
	&header(2);
	&get_cookie;
print <<"EOM";
<table border="0" cellspacing="0" cellpadding="0" align="center" width="100%" height=100% bgcolor="#FFFFFF">
<tr><td align=center>
<table border="0" cellspacing="0" cellpadding="6" align="center" width="630" bgcolor="#FFFFFF">
  <tr> 
    <td bgcolor=#ffffff width="90" height="40" class="sumi"><img src="$img_dir/space.gif" width="90" height="1"><br>
      <div class="midasi"><span style="font-size:15px;color:#ff9900">LUCKY !</span></div>
      <span class="honbun"></span> </td>
	  
    <td bgcolor=#ffffff width="90" height="40"  class="migi"><img src="$img_dir/space.gif" width="90" height="1"><br>
      <div class="midasi2">사업 실패</div>
      </td>
	  
    <td bgcolor=#ffffff width="90" height="40"  class="migi"><img src="$img_dir/space.gif" width="90" height="1"><br>
      <div class="midasi">경마</div>
      </td>
	  
    <td bgcolor=#ffffff width="90" height="40" class="migi"><img src="$img_dir/space.gif" width="90" height="1"><br>
      <div class="midasi2">강도</div>
      </td>
	  
    <td bgcolor=#ffffff width="90" height="40"  class="migi"><img src="$img_dir/space.gif" width="90" height="1"><br>
      <div class="midasi2">파산</div>
       </td>
	  
    <td bgcolor=#ffffff width="90" height="40"  class="migi"><img src="$img_dir/space.gif" width="90" height="1"><br>
      <div class="midasi">CD발매</div>
       </td>
	  
    <td bgcolor=#ffffff width="90" height="40"  class="migi"><img src="$img_dir/space.gif" width="90" height="1"><br>
      <div class="midasi"><span style="font-size:13;color:#000000">GO START</span></div>
     </td>
	  
  </tr>
  <tr> 
    <td bgcolor=#ffffff width="90" height="40"  class="sita"> 
      <div class="midasi">게임 개발</div>
       </td>
	  
    <td colspan="5" rowspan="9">
<table width="95%" border="0" cellspacing="0" cellpadding="10" align=center>
  <tr>
    <td>
      <div align="center">$titile_image<b> (서버 1-딜레이 20초)</b></div>
        <br><div class=honbun3>가상 세계에서 억만장자를 목표로 합시다.룰은 「인생 게임」과 닮습니다만, 참가하고 있는 다른 분과 연인이 되거나 결혼하거나 할 수 있습니다.또 쇼핑을 하거나 주식으로 돈을 벌거나 물론 집을 세우기도 할 수 있어요.Let's start ! </div>
      
     <form method="POST" action="$script">
	<input type=hidden name=mode value="cont">
	<input type=hidden name=yobidasi value="login_view">
	<input type=hidden name=command value="select_com">
	$osirase
	<br><br>
        ● 게임 계속<br>
        이름
        <input type="text" name="name" size="18" value="$ck{'name'}"> <!-- ver.1.36 -->
        패스워드 
        <input type="password" name="pass" size="10" value="$ck{'pass'}"><!-- ver.1.36 -->
        <input type="submit" value="OK">
      </form><br>
$sinkiButton
<br><br><div align=center><a href=$homepage target=_blank>[HOME]</a></div><br>


    </td>
  </tr>
</table>
	</td>
	
    <td bgcolor=#ffffff width="90" height="40"  class="sita"> 
      <div class="midasi2">화재</div>
       </td>
	  
  </tr>
  <tr> 
    <td bgcolor=#ffffff width="90" height="40"  class="sita"> 
      <div class="midasi"><span style="color:#339966">급료</span></div>
       </td>
	  
    <td bgcolor=#ffffff width="90" height="40"  class="sita"> 
      <div class="midasi2">입원</div>
       </td>
	  
  </tr>
  <tr> 
    <td bgcolor=#ffffff width="90" height="40" class="sita"> 
      <div class="midasi">호경기</div>
      </td>
	  
    <td bgcolor=#ffffff width="90" height="40" class="sita"> 
      <div class="midasi">장사 번성</div>
       </td>
	  
  </tr>
  <tr> 
    <td bgcolor=#ffffff width="90" height="40" class="sita"> 
      <div class="midasi2">대공황</div>
      </td>
	  
    <td bgcolor=#ffffff width="90" height="40" class="sita"> 
      <div class="midasi"><span style="font-size:15px;color:#FF9999">LOVE</span></div>
       </td>
	  
  </tr>
    <tr> 
    <td bgcolor=#ffffff width="90" height="40" class="sita"> 
      <div class="midasi"><span style="font-size:15px;color:#ff9900">Card Game</span></div>
      <span class="honbun"></span> </td>
	  
    <td bgcolor=#ffffff width="90" height="40" class="sita"> 
      <div class="midasi2">세관</div>
       </td>
	  
  </tr>
    <tr> 
    <td bgcolor=#ffffff width="90" height="40" class="sita"> 
      <div class="midasi">온천 발견</div>
       </td>
	  
    <td bgcolor=#ffffff width="90" height="40" class="sita"> 
      <div class="midasi">생일</div>
       </td>
	  
  </tr>
    <tr> 
    <td bgcolor=#ffffff width="90" height="40" class="sita"> 
      <div class="midasi">책을 쓴다</div>
      <span class="honbun"></span> </td>
	  
    <td bgcolor=#ffffff width="90" height="40" class="sita"> 
      <div class="midasi"><span style="color:#339966">급료</span></div>
       </td>
	  
  </tr>
    <tr> 
    <td bgcolor=#ffffff width="90" height="40" class="sita"> 
      <div class="midasi"><span style=color:#339966>스킬 업</span></div>
      <span class="honbun"></span> </td>
	  
    <td bgcolor=#ffffff width="90" height="40" class="sita"> 
      <div class="midasi" style=color:#996633>보상</div>
       </td>
	  
  </tr>
    <tr> 
    <td bgcolor=#ffffff width="90" height="40" class="sita"> 
      <div class="midasi"><span style="font-size:15px;color:#FF9999">LOVE</span></div>
      <span class="honbun"></span> </td>
	  
    <td bgcolor=#ffffff width="90" height="40" class="sita"> 
      <div class="midasi"><span style="font-size:15px;color:#ff9900">Chance !</span></div>
       </td>
	  
  </tr>
  <tr> 
    <td bgcolor=#ffffff width="90" height="40" class="sita"> 
      <div class="midasi"><span style="color:#000000">형무소</span></div>
    </td>
	
    <td bgcolor=#ffffff  class="migi"> 
      <div class="midasi">지갑 줍다</div>
       </td>
	  
    <td bgcolor=#ffffff  class="migi"> 
      <div class="midasi2">일의 실수</div>
       </td>
	  
    <td bgcolor=#ffffff  class="migi"> 
      <div class="midasi2">대지진 발생</div>
       </td>
	  
    <td bgcolor=#ffffff  class="migi"> 
      <div class="midasi">회사 공로</div>
      </td>
	  
    <td bgcolor=#ffffff class="naka"> 
      <div class="midasi">파칭코</div>
      </td>
	  
    <td bgcolor=#ffffff width="90" height="40" class="sita"> 
      <div class="midasi" style=color:#000000>START</div>
       </td>
	  
  </tr>
</table><div align=center class=honbun><a href=http://brassiere.jp/ target=_blank>- 인생게임 $version -</a><br>한글화 : 찬제(http://www.weggy.net)</div></td></tr></table>
</body></html>
EOM
}
1;