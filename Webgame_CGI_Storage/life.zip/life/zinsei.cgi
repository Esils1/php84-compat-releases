#!/usr/bin/perl
BEGIN {
    require FindBin;
    FindBin->import();
    chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
    unshift @INC, $FindBin::Bin;
}
# ↑사용의 서버의 패스에 맞추어 주세요.
#+++++++++++++++++++++++++++++++++++++
#  Copyright (c) 2003 brassiere
#  인생의 게임 
$version = 'ver.1.36';
#  web：http://www.yakan.jp/brassiere/
#  mail：brassiere@yakan.jp
#이 프로그램에 의해서 일어난 일에 책임을 지지 않습니다.
#+++++++++++++++++++++++++++++++++++++
#
#------------------설치 방법--------------------------------
#	서버의 환경은 perl5가 필요합니다.
#	「zinsei.cgi」의 1행째의 perl의 패스를 사용의 서버의 패스에 맞추어 변경해 주세요.
#	「zinsei_ini.pl」의 초기설정을 필요에 따라서 수정해 주세요.
#	「admin.cgi」의 1행째의 perl의 패스를 사용의 서버의 패스에 맞추어 변경해, 관리자용 패스워드를 설정해 주세요.
#	다운로드한 상태의 디렉토리 구성인 채 서버에 올라가,
#	퍼미션의 설정을 해 주세요( ) 안이 퍼미션.
#	버전 업은, (ver.00변경)이 붙어 있는 파일=파일을 교환.(ver.00신규)가 붙어 있는 파일=파일을 추가.ver.1.1보다 향후의 버전 업에 대비해 초기설정 파일(zinsei_ini.pl)을 독립시켰으므로, 재차 초기설정을 수정해 주세요.
#		sugoroku--------------------(777) 격납 디렉토리.환경에 따라서는(755)도 가능
#		zinsei.cgi--------------(755)※메인 스크립트(ver.1.34 변경)
#		admin.cgi--------------(755)※관리자 메뉴 스크립트(ver.1.34 변경)
#		zinseilog.cgi-----------(666)※랭킹용 로그 파일
#		kodomoFile.cgi--------(666)※어린이용 로그 파일
#		last_backup.cgi-------(666)※최종 백업 시간 기록 파일
#		last_mail_check.cgi--(666)※최종 메일 체크 시간 기록 파일
#		itemlog.cgi------------(666)※오리지날 아이템 로그 파일(ver.1.1 신규)(ver.1.31 변경)
#		member---------------(777)※개인 데이터 보존 디렉토리.환경에 따라서는(755)도 가능
#		lock--------------------(777)※락 디렉토리.환경에 따라서는(755)도 가능
#		※이하는 644로 OK이므로 대부분의 서버에서는 설정의 필요는 없을까 생각합니다.
#		zinsei_ini.pl-----------(644)※초기설정 파일(ver.1.1 신규)(ver.1.33 변경)
#		ban.pl------------------(644)※게임반라이브러리(ver.1.33 변경)
#		command.pl-----------(644)※커멘드 라이브러리(ver.1.34 변경)
#		susumu.pl-------------(644)※이벤트 처리 라이브러리(ver.1.33 변경)
#		top.pl------------------(644)※톱 페이지 HTML(ver.1.33 변경)
#		touroku.html----------(644)※신규 등록 화면 HTML(ver.1.31 변경)
#		toti.dat----------------(644)※토지 데이터
#		ie.dat------------------(644)※가 데이터
#		kabu.dat---------------(644)※주 기업 데이터
#		cgi-lib.pl---------------(644)※문자 처리 라이브러리(ver.1.33 개행 코드 수정)
#		img--------------------※화상 격납 디렉토리
#	※퍼미션은 이용 서버에 따라서 다르므로 이 마지막으로 네 없습니다.
#
#　zinsei.cgi에 액세스 해, 신규 등록해 동작 체크를 해 주세요.더미 데이터가 들어가 있기 위해 등록자수가 벌써 한 명이 되어 있습니다만, 「랭킹을 본다」를 여는 곳의 더미 데이터는 소됩니다.이 게임에서는 로그 파일이 비우면 에러가 나와 속행할 수 없는 사양이 되어 있기 때문에, 삭제등 해 등록자 0명에게는 하지 않게 해 주세요.
#　admin.cgi에 액세스 해, 패스워드를 입력하면 관리자 메뉴에 넣습니다.관리자 메뉴에서는 유저의 삭제나 만일 로그가 소실했을 경우의 개인 데이터, 랭킹 파일의 부활, 등록자 일람등의 기능이 있습니다.
require 'cgi-lib.pl';
require 'ban.pl';
require 'top.pl';
require 'susumu.pl';
require 'command.pl';
require 'zinsei_ini.pl';
require 'zinsei_lib.pl';

##############메인 처리
	local($buf, $key, $val, @buf);
#디코드
	if ($ENV{'REQUEST_METHOD'} eq "POST") {
		&ReadParse;
		while (($key,$value) =each %in){
#			$value =~ s/,/, /g;
			$value =~ s/\r\n/<br>/g;
			$value =~ s/\r/<br>/g;
			$value =~ s/\n/<br>/g;
			$in{$key} = $value;
		}
	} else { $buf = $ENV{'QUERY_STRING'}; }
	@buf = split(/&/, $buf);
	foreach (@buf) {
		($key, $val) = split(/=/);
		$val =~ tr/+/ /;
		$val =~ s/%([a-fA-F0-9][a-fA-F0-9]) /pack("C", hex($1)) /eg;
		# 문자 코드 변환 (Shift-JIS 코드)
		$in{$key} = $val;
	}
	
#GET로의 액세스를 거부
if($in{'mode'} ne "" && $in{'mode'} ne "login_view" && $in{'mode'} ne "main_view" && $in{'mode'} ne "susumu" && $in{'mode'} ne "ranking" && $in{'mode'} ne "sousisan" && $in{'mode'} ne "kodomo_ranking" && $in{'mode'} ne "mail_check" && $in{'mode'} ne "message_hyouzi"){		#ver.1.36
		if ($ENV{'REQUEST_METHOD'} ne "POST") {
			&error("부정 액세스이기 때문에 강제 종됩니다.");
		}
}

#패스워드 체크
if($in{'mode'} ne "" && $in{'mode'} ne "main_view"  && $in{'mode'} ne "new"  && $in{'mode'} ne "cont"  && $in{'mode'} ne "login_view" && $in{'mode'} ne "susumu" && $in{'mode'} ne "ranking" && $in{'mode'} ne "sousisan" && $in{'mode'} ne "kodomo_ranking"){
		&check_pass;
}

# 지정 호스트 액세스 거부
	# 호스트명을 취득
	$host = $ENV{'REMOTE_HOST'};
	$addr = $ENV{'REMOTE_ADDR'};
	if ($host eq "" || $host eq $addr) {
		$host = gethostbyaddr(pack("C4", split(/\./, $addr)), 2) || $addr;
	}
#	if ($host eq "") { &error("송합니다만 호스트 취득할 수 없는 PC로부터의 액세스는 할 수 없습니다"); }
	foreach (@deny) {
		if ($_ eq "") { next; }
		$_ =~ s/\*/\.\*/g;
		if ($host =~ /$_/i) { &error("송합니다만 이용중의 호스트에게서는 액세스 할 수 없습니다"); }
	}

#하늘 로그 체크
			open(CK,"$logfile") || &error("Open Error : $logfile");
			@backup_check = <CK>;
			if(@backup_check == ''){&error("랭킹 파일에 문제가 있습니다.<br>수고스럽겠지만 관리인($master_ad)까지 보고해 주십시오.")}
			close(CK);
	
#멘테체크
	if($mente_flag == 1){&error("$mente_message")}

#조건 분기
@WEGGY_NET = ();
if (-f '../black.cgi') {
	require '../black.cgi';
}
foreach $i (@WEGGY_NET) { &error("Access denied.") if $ENV{'REMOTE_ADDR'} eq $i; }
	if($in{'mode'} eq "cont"){&ban(start);}
	if($in{'mode'} eq "login_view"){&login_view;}
	if($in{'mode'} eq "new"){&new;}
	if($in{'mode'} eq "saikoro"){&saikoro;}
	if($in{'mode'} eq "susumu"){&susumu;}
	if($in{'mode'} eq "frame_kousin"){&frame_kousin;}
	if($in{'mode'} eq "chance"){&chance;}
	if($in{'mode'} eq "card_game"){&card_game;}
	if($in{'mode'} eq "kaimono"){&kaimono;}
	if($in{'mode'} eq "kounyuu"){&kounyuu;}
	if($in{'mode'} eq "monouri"){&monouri;}
	if($in{'mode'} eq "kabu"){&kabu;}
	if($in{'mode'} eq "ie"){&ie;}
	if($in{'mode'} eq "kokuhaku"){&kokuhaku;}
	if($in{'mode'} eq "mail_check"){&mail_check;}
	if($in{'mode'} eq "mail_sousin"){&mail_sousin;}
	if($in{'mode'} eq "ranking"){&ranking;}
	if($in{'mode'} eq "ban"){&ban;}
	if($in{'mode'} eq "ginkou"){&ginkou;}
	if($in{'mode'} eq "sousisan"){&sousisan;}
	if($in{'mode'} eq "sousisan_hozon"){&sousisan_hozon;}
	if($in{'mode'} eq "loto"){&loto;}
	if($in{'mode'} eq "kosodate"){&kosodate;}
	if($in{'mode'} eq "kodomo_ranking"){&kodomo_ranking;}
	if($in{'mode'} eq "ziritu"){&ziritu;}
	if($in{'mode'} eq "hukkatu"){&hukkatu;}
	if($in{'mode'} eq "message_hyouzi"){&message_hyouzi;}
	if($in{'mode'} eq "item_create"){&item_create;}
	if($in{'mode'} eq "item_create_ok"){&item_create_ok;}
	if($in{'mode'} eq "birthdayPresent"){&birthdayPresent;}
	&main_view;
exit;
sub ERROR {
        foreach $i (@_){$O =0 if($O eq '');$MSG.="$_[$O]\\n";$O +=1;}
        print "<script language=\"JavaScript\">\nalert('$MSG')\;\n\n</script>";
        exit;
}
sub split_var2{
($id,$name,$pass,$money,$basyo,$haiguu,$kodomo,$love,$land,$house,$kabu,$kounyuu,$sex,$yobi1,$yobi2,$yobi3,$yobi4,$yobi5,$yobi6,$yobi7,$yobi8,$yobi9,$yobi10,$yobi11,$yobi12,$yobi13,$yobi14)= split(/<>/,@_[0]);
#yobi1:눈의 회수(형무소용)　yobi2:일스킬치 　yobi3:연인　yobi4:스타트 통과 회수　yobi5:저금　yobi6:총자산　yobi7:최종 데이터 갱신 시간　yobi8:CD발매 회수　yobi9:슈퍼 정기예금　yobi10:최종 액세스 시간　yobi11:빈 곳　yobi12:호스트　yobi13:종합 포인트
}

sub split_var{
($id,$name,$pass,$money,$basyo,$haiguu,$kodomo,$love,$land,$house,$kabu,$kounyuu,$sex,$yobi1,$yobi2,$yobi3,$yobi4,$yobi5,$yobi6,$yobi7,$yobi8,$yobi9,$yobi10,$yobi11,$yobi12,$yobi13,$yobi14)= split(/<>/);
#yobi1:눈의 회수(형무소용)　yobi2:일스킬치 　yobi3:연인　yobi4:스타트 통과 회수　yobi5:저금　yobi6:총자산　yobi7:최종 데이터 갱신 시간　yobi8:CD발매 회수　yobi9:슈퍼 정기예금　yobi10:최종 액세스 시간　yobi11:빈 곳　yobi12:호스트　yobi13:종합 포인트
}

sub temp_routin {
	$temp="$id<>$name<>$pass<>$money<>$basyo<>$haiguu<>$kodomo<>$love<>$land<>$house<>$kabu<>$kounyuu<>$sex<>$yobi1<>$yobi2<>$yobi3<>$yobi4<>$yobi5<>$yobi6<>$yobi7<>$yobi8<>$yobi9<>$yobi10<>$yobi11<>$yobi12<>$yobi13<>$yobi14<>\n";
}

sub log_kousin {
	&lock;	
#ver.1.36 여기로부터
	 ($kirokufile,$kirokunaiyou) = @_;
	@kirokunaiyou[0] = $kirokunaiyou;
	$err = data_save($kirokufile, @kirokunaiyou);
	if ($err) {&error("$err");}
	
#	open(OUT,">@_[0]") || &error("@_[0]이 열리지 않습니다");
#	print OUT @_[1];
#	close(OUT);
#ver.1.36여기까지
	&unlock;
}

sub openMylog {
		$my_log_file = "./member/"."@_[0]"."log.cgi";
		open(MYL,"$my_log_file") || &error("로그 파일($my_log_file)이 열리지 않습니다.<br>재차 로그인해도 동일한 관리인($master_ad)까지 메일을 주세요.");
		$my_prof = <MYL>;
		if($my_prof == ""){&error("로그 파일에 문제가 일어났습니다.<br>수고스럽겠지만, 관리인($master_ad)까지 메일을 주세요.");}
		&split_var2($my_prof);
		close(MYL);
}

sub check_pass {
		$my_log_file = "./member/"."$in{'id'}"."log.cgi";
		open(MYL,"$my_log_file") || &error("로그 파일($my_log_file)이 열리지 않습니다.<br>재차 로그인해도 동일한 관리인($master_ad)까지 메일을 주세요.");
		$my_prof = <MYL>;
		if($my_prof == ""){&error("로그 파일에 문제가 일어났습니다.<br>수고스럽겠지만, 관리인($master_ad)까지 메일을 주세요.");}
		&split_var2($my_prof);
				if($in{'pass'} ne $pass){
					&error("이름과 패스워드가 일치하지 않습니다!");
				}
		close(MYL);
}

sub openAitelog {
					$aite_log_file = "./member/"."@_[0]"."log.cgi";
					open(AIT,"$aite_log_file") || &error("상대의 분의 로그 파일($aite_log_file)이 열리지 않습니다.<br>데이터 갱신이 아직 끝나지 않는 것 같습니다.");
					$aite_prof = <AIT>;
					if($aite_prof == ""){&error("상대의 분의 로그 파일에 문제가 있습니다.");}
					&split_var2($aite_prof);
					close(AIT);
}

sub kodomo_split {
							($k_id,$k_name,$oya1,$oya2,$seinengappi,$atama,$sports,$art,$food_time,$k_yobi2,$k_yobi3,$k_yobi4,$k_yobi5)= split(/<>/);
}
#k_yobi2:자립 온 오프　k_yobi3:직업　k_yobi4:최종 능력치　food_time=태어난 초

###################써브루틴
#데이터 부활
sub hukkatu {
	open(HUK,"$logfile") || &error("Open Error : $logfile");
	$hukkatu_flag=0;
	while (<HUK>) {
			&split_var;
			if($in{'name'} eq $name){$hukkatu_flag=1;last;}
	}
	close(HUK);
	if($hukkatu_flag == 0){&error("그 이름에서는 등록되어 있지 않습니다!");}
					if($in{'pass'} ne $pass){&error("이름과 패스워드가 일치하지 않습니다!");}
					$my_log_file = "./member/$id"."log.cgi";
					$my_temp="$id<>$name<>$pass<>$money<>$basyo<>$haiguu<>$kodomo<>$love<>$land<>$house<>$kabu<>$kounyuu<>$sex<>$yobi1<>$yobi2<>$yobi3<>$yobi4<>$yobi5<>$yobi6<>$yobi7<>$yobi8<>$yobi9<>$yobi10<>$yobi11<>$yobi12<>$yobi13<>$yobi14<>\n";
					&lock;
					open(HU,">$my_log_file") || &error("Open Error : $my_log_file");
					print HU $my_temp;
					close(HU);
					&unlock;
}


#로그인 화면
sub login_view {
	&header2(2);
	&id_check($in{'name'});
	$my_log_file = "member/$return_id"."log.cgi";
	open(IN,"$my_log_file") || &error("Open Error : $my_log_file");
		$my_prof = <IN>;
		&split_var2($my_prof);
	close(IN);
	
#new 메일의 체크
	$member_file="member/$id.cgi";
	open(MS,"$member_file");# || &error("자신의 사서함 파일이 열리지 않습니다");
	$lastAccess=<MS>;
	close(MS);
	@lastAccess=split(/<>/,$lastAccess);
	
	open(IN,"$lasttime_file") || &error("Open Error : $lasttime_file");
		while (<IN>) {
			($mypost_id,$mailcheck_time) = split(/<>/);
			if($id eq $mypost_id){last;}
		}
	close(IN);
	
#	print "마지막에 메일 체크한 시간：$mailcheck_time";
#	print "메일이 온 시간：$lastAccess[5]";
	if($mailcheck_time<$lastAccess[9]){$newMail= "<span style=color:#ff3300>새로운 메세지가 도착했습니다!</span>";}
	
	
	
#토지의 표시형을 정형
	if($land ne "없음"){
			($toti_basyo,$tubosuu)= split(/,/,$land);
			$land_hyouzi="$toti_basyo($tubosuu평)";
	}else{$land_hyouzi = "없음";}
#집의 표시형을 정형
	if($house ne "없음"){
			($house_style,$ie_kounyuugaku)= split(/,/,$house);
	}else{$house_style = "없음";}
#주식의 표시형을 정형
	if($kabu ne "없음"){
			($meigara,$hitokabu,$agari,$sagari,$kazu,$syokiti)= split(/,/,$kabu);
			$urine=$hitokabu*$kazu;
			$syokitousi=$syokiti*$kazu;
			$uriage=$urine-$syokitousi;
			if($uriage > 0){$kabu_kekka="$uriage만 득을 봅니다";}
			elsif($uriage == 0){$kabu_kekka="손익에 관계 없습니다";}
			else{$uriage=abs $uriage;$kabu_kekka="$uriage만의 손해입니다";}
			$kabuhyouzi="$meigara($hitokabu만×$kazu주) 지금 팔면$urine만으로 $kabu_kekka";
	}else{
			$kabuhyouzi="없음";
	}
	
#직무의 표시 조정
	&yakusyoku_hyouzi($yobi2);
#커멘드 버튼 준비
#	if($in{'command'} eq "select_com"){
				$botan .= <<"EOM";
				<td><form method="POST" action="$script">
				<input type=hidden name=mode value="kaimono">
				<input type=hidden name=name value="$in{'name'}">
				<input type=hidden name=pass value="$in{'pass'}">
				<input type=hidden name=id value="$id">
			        <div align="center">
			          <input type="submit" name="Submit2" value="쇼핑을 한다">
			        </div>
			      </form>
				  </td>
				  <td>
				<form method="POST" action="$script">
				<input type=hidden name=mode value="ginkou">
				<input type=hidden name=name value="$in{'name'}">
				<input type=hidden name=pass value="$in{'pass'}">
				<input type=hidden name=id value="$id">
			        <div align="center">
			          <input type="submit" name="Submit2" value="은행에 간다">
			        </div>
			      </form>
				  </td></tr>

				<tr><td><form method="POST" action="$script">
				<input type=hidden name=mode value="ie">
				<input type=hidden name=name value="$in{'name'}">
				<input type=hidden name=pass value="$in{'pass'}">
				<input type=hidden name=id value="$id">
			        <div align="center">
			          <input type="submit" name="Submit2" value="집을 구입한다">
			        </div>
			      </form></td><td>
EOM
				if($kabu ne "없음"){
						$botan .= <<"EOM";
				<form method="POST" action="$script">
				<input type=hidden name=mode value="kabu">
				<input type=hidden name=command value="uri">
				<input type=hidden name=name value="$in{'name'}">
				<input type=hidden name=pass value="$in{'pass'}">
				<input type=hidden name=id value="$id">
			        <div align="center">
			          <input type="submit" name="Submit2" value="주식을 매각한다">
			        </div>
			      </form></td></tr>
EOM
				}else{
						$botan .= <<"EOM";
				<form method="POST" action="$script">
				<input type=hidden name=mode value="kabu">
				<input type=hidden name=name value="$in{'name'}">
				<input type=hidden name=pass value="$in{'pass'}">
				<input type=hidden name=id value="$id">
			        <div align="center">
			          <input type="submit" name="Submit2" value="주식을 구입한다">
			        </div>
			      </form></td>
EOM
				}
				
				if($haiguu ne "독신" || $yobi3 ne ""){
						$botan2 .= <<"EOM";
				<form method="POST" action="$script">
				<input type=hidden name=mode value="mail_sousin">
				<input type=hidden name=name value="$in{'name'}">
				<input type=hidden name=pass value="$in{'pass'}">
				<input type=hidden name=id value="$id">
			        <div align="center">
			          <input type="submit" name="Submit2" value="메세지 송신">
			        </div>
			      </form>
EOM
				}
#LOVE 기준을 넘었을 경우의 버튼
				if($love > $love_kijun){
						$botan2 .= <<"EOM";
				<form method="POST" action="$script">
				<input type=hidden name=mode value="mail_check">
				<input type=hidden name=name value="$in{'name'}">
				<input type=hidden name=pass value="$in{'pass'}">
				<input type=hidden name=id value="$id">
			        <div align="center">
			          <input type="submit" name="Submit2" value="메일 체크"> <br>$newMail
			        </div>
			      </form>
						
				<form method="POST" action="$script">
				<input type=hidden name=mode value="kokuhaku">
				<input type=hidden name=name value="$in{'name'}">
				<input type=hidden name=pass value="$in{'pass'}">
				<input type=hidden name=sex value="$sex">
				<input type=hidden name=haiguu value="$haiguu">
				<input type=hidden name=money value="$yobi6">
				<input type=hidden name=land value="$land">
				<input type=hidden name=house value="$house">
				<input type=hidden name=id value="$id">
				<div align="center">
				<input type="submit" name="Submit2" value="프로포즈한다">
				</div>
				</form>
EOM
				}else{$hagemase= "<div align=left>※LOVE도가$love_kijun를 넘으면 연애 커멘드가 나타나기 때문에 노력해 주세요.</div>";}
#아이가 있었을 경우의 버튼
				if($kodomo ne ""){
						$botan2 .= <<"EOM";
				<form method="POST" action="$script">
				<input type=hidden name=mode value="kosodate">
				<input type=hidden name=name value="$in{'name'}">
				<input type=hidden name=pass value="$in{'pass'}">
				<input type=hidden name=haiguu value="$haiguu">
				<input type=hidden name=id value="$id">
			        <div align="center">
			          <input type="submit" name="Submit2" value="육아를 한다">
			        </div>
			      </form>
EOM
				}
				
#	}	#if 문장(셀렉트 버튼의 경우)이 덮어
	$kounyuu =~ s/,/, /g;
	$yobi3 =~ s/,/, /g;
	$kodomo =~ s/,/, /g;

				if($seigen_time != 0){
							$genzai_time = time;
							if($seigen_time==1){
									$seigen_zikan_byou=60*60*24*$seigen_zikan;
									if($genzai_time-$yobi10 < $seigen_zikan_byou){
											$ato_nanbyou=$seigen_zikan_byou-($genzai_time-$yobi10);
											$saikoroprint="<input type=text name=cdown value=\"$ato_nanbyou\" size=10 style='height: 11px; font-size: 11px; text-align: left; border: 0'>";
									}
							}elsif($seigen_time==2){
									$seigen_zikan_byou=60*60*$seigen_zikan;
									if($genzai_time-$yobi10 < $seigen_zikan_byou){
											$ato_nanbyou=$seigen_zikan_byou-($genzai_time-$yobi10);
											$saikoroprint="<input type=text name=\"cdown\" value=\"$ato_nanbyou\" size=8 style=\"height: 11px; font-size: 11px; text-align: left; border: 0\">";
									}
							}elsif($seigen_time==3){
									$seigen_zikan_byou=60*$seigen_zikan;
									if($genzai_time-$yobi10 < $seigen_zikan_byou){
											$ato_nanbyou=$seigen_zikan_byou-($genzai_time-$yobi10);
											$saikoroprint="<input type=text name=cdown value=\"$ato_nanbyou\" size=6 style='height: 11px; font-size: 11px; text-align: left; border: 0'>";
									}
							}elsif($seigen_time==4){
									if($genzai_time-$yobi10 < $seigen_zikan){
											$ato_nanbyou=$seigen_zikan-($genzai_time-$yobi10);
											$saikoroprint="<input type=text name=cdown value=\"$ato_nanbyou\" size=4 style='height: 11px; font-size: 11px; text-align: left; border: 0'> 초 후 주사위를 던질 수 있습니다.";
									}
							}
				}
				
	print <<"EOM";
<table width="100%" border="0" cellspacing="0" cellpadding="10" align=center>
  <tr>
    <td class="sumi2" valign=top width=50% bgcolor=#ffffcc>
      <div align="center" class=purasu>$name씨의 스테이터스</div><br>
        <span class=honbun2>소유금</span>：$money만<br>
		<span class=honbun2>직무</span>：$yakusyoku(일스킬치 $yobi2)<br>
		<span class=honbun2>배우자</span>：$haiguu<br>
		<span class=honbun2>아이</span>：$kodomo<br>
		<span class=honbun2>연인</span>：$yobi3<br>
		<span class=honbun2>러브도</span>：$love 포인트<br>
		<span class=honbun2>토지</span>：$land_hyouzi<br>
		<span class=honbun2>　가　</span>：$house_style<br>
		<span class=honbun2>　주　</span>：$kabuhyouzi<br>
		<span class=honbun2>소유물</span>：$kounyuu<br>
    </td>
    <td>
<!-- ver.1.36여기로부터 -->
	  <center><!--<form name=form1><a href=\"$script?mode=ban&id=$id&name=$in{'name'}&pass=$in{'pass'}&my_basyo=$basyo&saihuri=on\" target=_top style=\"font-size:15;color:#000000;\">◆주사위를 던진다◆</a><br>$saikoroprint</form>-->
	<form name=form1 method="POST" action="$script" target=_parent>
	<input type=hidden name=mode value="ban">
	<input type=hidden name=id value="$id">
	<input type="hidden" name="name" value=$in{'name'}>
	<input type="hidden" name="pass" size="10" value=$in{'pass'}>
	<input type=hidden name=my_basyo value="$basyo">
	<input type=hidden name=saihuri value="on">
	<input type="submit" value="◆주사위를 흔든다◆">
	<br>$saikoroprint
	</form>

	  </center>
	  <table width="100%" border="0" cellspacing="0" cellpadding="10" align=center><tr>
	  $botan
	  <tr><td colspan=2 style="border: #666666; border-style: solid; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 1px; border-left-width: 0px">
	  $botan2
	  $hagemase
	  </td></tr></table>
	  <!--<hr size=1>-->
	  <table width="100%" border="0" cellspacing="0" cellpadding="0" align=center><tr><td>
	  <a href=$script?mode=ranking&sort_id=sougou target="game">■랭킹을 본다</a><br>
	  <a href="$script?mode=sousisan&name=$name&pass=$pass&id=$id"><b><font color=red>■데이터를 보존 (끝내기전 꼭 클릭)</font></b></a><br>
	  <a href=$script?mode=kodomo_ranking target="game">■아이 랭킹</a><br>
	  <a href=$script target=game>■게임 종료</a></td><td width=92>
	  <!--ver.1.3 추가 배너 표시.여기의 배너 표시는 강제가 아닙니다.시끄러웠으면 삭제해 괜찮습니다.여기로부터-->

	<!--추가 배너 표시 여기까지-->
<!-- ver.1.36여기까지 -->
    </td>
  </tr>
</table></td></tr></table>
</body></html>
EOM
exit;
}


#######신규 등록 처리
sub new {
	&lock;
	if($in{'name'} eq '' || $in{'pass'} eq '' || $in{'sex'} eq ''){&error("기입 누락이 있습니다!");}
	if($in{'name'}  =~ / / || $in{'name'}  =~ /　/){&error("이름에 스페이스를 사용하지 말아 주세요");}
	my ($temp,$i);
	open(IN,"$logfile") || &error("Open Error : $logfile");
		$host = $ENV{'REMOTE_HOST'};
	$addr = $ENV{'REMOTE_ADDR'};
	while (<IN>) {
		&split_var;
#		if($host eq $yobil2){ &error("중복 등록은 금지입니다. $name");}
		if($in{'name'} eq $name){ &error("그 이름은 벌써 등록되어 있습니다.다른 이름으로 시험해 주세요.");}
		$i=$id;
	}
	close(IN);
# 로그를 갱신
	$i++;
	$first_access_time= time;
# 호스트명을 취득
	$host = $ENV{'REMOTE_HOST'};
	$addr = $ENV{'REMOTE_ADDR'};
	if ($host eq "" || $host eq $addr) {
		$host = gethostbyaddr(pack("C4", split(/\./, $addr)), 2) || $addr;
	}
	$temp="$i<>$in{'name'}<>$in{'pass'}<>50<>0<>독신<><>0<>없음<>없음<>없음<><>$in{'sex'}<><><><><><><>$first_access_time<><><>$first_access_time<><>$host<><><>\n";
	open(OUT,">>$logfile") || &error("Write Error : $logfile");
	print OUT $temp;
	close(OUT);
#자신용 로그 파일 작성
	$my_log_file = "./member/"."$i"."log.cgi";
	open(MYF,">$my_log_file") || &error("Open Error : $my_log_file");
	print MYF $temp;
	close(MYF);
#메시지 교환용 파일 작성
	$message_file="./member/$i".".cgi";
	open(MF,">$message_file") || &error("Write Error : $message_file");
	close(MF);
	&unlock;
	&set_cookie;
	&header(2);
	print <<"EOM";
	<div align=center>
	<br><br>무사 등록은 완료했습니다.<br><br>
		<a href=$script?mode=main_view&name=$in{'name'}&pass=$in{'pass'}>돌아온다</a>
	</div>
	</body></html>
EOM
exit;
}

#######랭킹표\시
sub ranking {		#ver.1.36　sub ranking 모두
	$hyouzi_kirikae = "총자산";
	if($in{sort_id} eq "sougou"){
			$sortid=25;
			$c_title="<font color=#ff6600>종합 랭킹 베스트 $rankMax</font>";
			$hyouzi_kirikae = "종합 포인트";
	}elsif($in{sort_id} eq "money"){
			$sortid=18;
			$c_title="<font color=#ff6600>총자산 랭킹 베스트 $rankMax</font>";
	}elsif ($in{sort_id} eq "love"){
			$sortid=7;
			$c_title="<font color=#ff6600>LOVE 포인트 랭킹 베스트 $rankMax</font>";
	}elsif ($in{sort_id} eq "sigoto"){
			$sortid=14;
			$c_title="<font color=#ff6600>일스킬치 랭킹 베스트 $rankMax</font>";
	}elsif ($in{sort_id} eq "tuuka"){
			$sortid=16;
			$c_title="<font color=#ff6600>START 통과 회수 랭킹 베스트 $rankMax</font>";
	}
	&header(2);
	open(IN,"$logfile") || &error("Open Error : $logfile");
	@rankingMember = <IN>;
	close(IN);

		&lock;
		$sakujo_usr_flg=0;
		foreach (@rankingMember) {
			&split_var;
#방치 유저 삭제 처리
			if($yobi7 < (time)-(60*60*24*$deleteUser)){ 
#연인의 리스트로부터 자신의 이름을 지운다
				&checkMyKoibito($id);
				if($return_koibito_name ne ""){
					(@my_koibitos)= split(/,/,$return_koibito_name);
					foreach $my_koibito (@my_koibitos){
							&id_check ($my_koibito);
							$aite_log_file1 = "./member/"."$return_id"."log.cgi";
							$aite_log_file2 = "./member/"."$return_id".".cgi";
							if (-e $aite_log_file1 && -e $aite_log_file2){
								&koibitoSakujo($return_id,$name);
								&sakujoMessageSend($return_id,$name,2);
							}
					}

				}
#배우자의 리스트로부터 자신의 이름을 지운다
				if($return_haiguu_name ne "독신" && $return_haiguu_name ne ""){

					&id_check ($return_haiguu_name);
					$aite_log_file1 = "./member/"."$return_id"."log.cgi";
					$aite_log_file2 = "./member/"."$return_id".".cgi";
					if (-e $aite_log_file1 && -e $aite_log_file2){
						&haiguuSakujo($return_id,$name);
						&sakujoMessageSend($return_id,$name,1);
					}

				}
#아이 파일로부터 부모의 이름을 지운다
					&rikon_kodomo($name,'no_lock');
#삭제 유저 로그 삭제
					$this_mail_file = "./member/$id" . ".cgi";
					$this_log_file = "./member/$id" . "log.cgi";
					if (-e $this_mail_file ){unlink ("$this_mail_file");}
					if (-e $this_log_file ){unlink ("$this_log_file");}
					$sakujo_usr_flg = 1;
					next;
			}		#if(삭제 유저의 경우) 닫아
			$data=$_;
			$key=(split(/<>/,$data))[$sortid];		#소트 하는 요소를 선택한다
			push @alldata,$data;
			push @keys,$key;
		}		#foreach 닫아
	if ($sakujo_usr_flg == 1) {
		$err = data_save($logfile, @alldata);
		if ($err) {&error("$err");}
#		&renameLock1;
#		open(OUT,">$tmpFile") || &error("$tmpFile가 열리지 않습니다");
#		print OUT @alldata;
#		close(OUT);
#		&renameLock2("$logfile");

	}
	&unlock;
	
		sub bykeys{$keys[$b] <=> $keys[$a];}
		@alldata=@alldata[ sort bykeys 0..$#alldata]; 
		
	$nii = $saidai_ninzuu-1;
	$sani = $saidai_ninzuu-2;
	$saikou_tokuten = $saidai_ninzuu*4;
	print <<"EOM";
	<center><br>
	<a href=$script?mode=ranking&sort_id=sougou&name=$in{'name'}&pass=$in{'pass'}><span class=sub3>[종합 랭킹]</span></a><img src=$img_dir/space.gif width=5 height=1>
	<a href=$script?mode=ranking&sort_id=money&name=$in{'name'}&pass=$in{'pass'}><span class=sub3>[총자산 랭킹]</span></a><img src=$img_dir/space.gif width=5 height=1>
	<a href=$script?mode=ranking&sort_id=love&name=$in{'name'}&pass=$in{'pass'}><span class=sub3>[LOVE 포인트 랭킹]</span></a><img src=$img_dir/space.gif width=5 height=1>
	<a href=$script?mode=ranking&sort_id=sigoto&name=$in{'name'}&pass=$in{'pass'}><span class=sub3>[일스킬치 랭킹]</span></a><img src=$img_dir/space.gif width=5 height=1>
	<a href=$script?mode=ranking&sort_id=tuuka&name=$in{'name'}&pass=$in{'pass'}><span class=sub3>[START 통과 회수 랭킹]</span></a>
		<br><br><div align=center class=midasi>$c_title</div><br>
		</center>
	<table border=0 width=90% align=center cellspacing="1" cellpadding="5">
	<tr><td colspan=10>
	●「데이터를 보존」으로 데이터를 갱신하지 않으면 이 랭킹에 반영되지 않습니다.<br>
	●종합 포인트 산출 방법：총자산, 일스킬치, 러브도, 스타트 통과 회수의 각 분야에서 순위를 내, 1위=$saidai_ninzuu점을 최고점으로 해, 2위=$nii점, 3위=$sani점…으로 순위에 의해서 1점씩 차이가 붙은 점수가 붙여집니다.4개의 분야의 합계점이 종합 포인트가 됩니다.즉 4개의 분야 모두로 톱이 되면$saikou_tokuten점입니다.</td></tr>
	<tr  class=sumi bgcolor=#ffff66><td align=center >순위</td><td align=center>이름</td><td align=center>$hyouzi_kirikae</td><td align=center>배우자</td><td align=center >LOVE도</td><td align=center >일스킬치</td><td align=center >직무</td><td align=center >토지</td><td align=center >가</td><td align=center >START 통과</td></tr>
EOM

$i=1;
	foreach $one(@alldata) {
($id,$name,$pass,$money,$basyo,$haiguu,$kodomo,$love,$land,$house,$kabu,$kounyuu,$sex,$yobi1,$yobi2,$yobi3,$yobi4,$yobi5,$yobi6,$yobi7,$yobi8,$yobi9,$yobi10,$yobi11,$yobi12,$yobi13,$yobi14)= split(/<>/,$one);
	
#토지의 표시형을 정형
	if($land ne "없음"){
			($toti_basyo,$tubosuu)= split(/,/,$land);
			$land_hyouzi="$toti_basyo($tubosuu평)";
	}else{$land_hyouzi = "없음";}
#집의 표시형을 정형
	if($house ne "없음"){
			($house_style,$ie_kounyuugaku)= split(/,/,$house);
	}else{$house_style = "없음";}
#직무의 표시 조정
	&yakusyoku_hyouzi($yobi2);
	
	if($in{sort_id} ne "sougou"){
print "<tr class=sita><td align=center>$i</td><td align=center nowrap>$name</td><td align=right>$yobi6만</td><td align=center>$haiguu</td><td align=right>$love</td><td align=right>$yobi2</td><td align=center >$yakusyoku</td><td align=center nowrap>$land_hyouzi</td><td align=center  nowrap>$house_style</td><td align=right>$yobi4회</td></tr>\n";
	}else{
print "<tr class=sita><td align=center>$i</td><td align=center nowrap>$name</td><td align=right nowrap>$yobi13점</td><td align=center nowrap>$haiguu</td><td align=right>$love</td><td align=right>$yobi2</td><td align=center nowrap>$yakusyoku</td><td align=center nowrap>$land_hyouzi</td><td align=center  nowrap>$house_style</td><td align=right nowrap>$yobi4회</td></tr>\n";
	}
				if($i >=$rankMax){last;}
			$i++;
	}
	print "</table></body></html>";
	exit;
}	#써브루틴이 닫아

#아이 랭킹
sub kodomo_ranking {
	&header(2);
								$now_zikan = time;
	open(KF,"$kodomo_file") || &error("Open Error : $kodomo_file");
			@kodomo_data = <KF>;
			if(@kodomo_data == ''){&error("아이 랭킹 파일에 문제가 있습니다.<br>수고스럽겠지만 관리인($master_ad)까지 보고해 주십시오.")}
			foreach (@kodomo_data) {
			($k_id,$k_name,$oya1,$oya2,$seinengappi,$atama,$sports,$art,$food_time,$k_yobi2,$k_yobi3,$k_yobi4,$k_yobi5)= split(/<>/);
			if($k_yobi2 eq "on"){next;}
#스무살을 지난 아이를 자립시킨다(ver.1.3)
					($sec,$min,$hour,$mday,$mon,$year,$wday) = split(/,/,$seinengappi);
#ver.1.36 여기로부터
									$now_zikan = time;
									if ($module_on == 1) {
										$nenrei =  int(($now_zikan-$food_time)/60/60/24);
									}else{
										&konotosi_get($seinengappi);
									}
#ver.1.36여기까지
					if($nenrei >= 20){
							&id_check($oya1);
							$oya1_id = $return_id;
							&id_check($oya2);
							$oya2_id = $return_id;
							&lock;
							&ziritu_auto($k_name,$oya1_id);
							&ziritu_auto($k_name,$oya2_id);
							&unlock;
							&hatati($k_name,1,1);
							next;
					}
			push @alldata,$_;
			push @t_keys,$atama;		#공부의 순위용 소트 배열
			push @y_keys,$sports;		#스포츠의 순위용 소트 배열
			push @s_keys,$art;		#미술의 소트 배열
		}
	close(KF);
	
		sub benkyou{$t_keys[$b] <=> $t_keys[$a];}
		@t_rank=@alldata[ sort benkyou 0..$#alldata]; 
		
		sub by_ykeys{$y_keys[$b] <=> $y_keys[$a];}
		@y_rank=@alldata[ sort by_ykeys 0..$#alldata]; 
		
		sub by_skeys{$s_keys[$b] <=> $s_keys[$a];}
		@s_rank=@alldata[ sort by_skeys 0..$#alldata]; 
		
			print <<"EOM";
			<div align=center class=midasi><font color=#ff6699>아이 랭킹 베스트 $rankMax</font></div><br>
			<table border=0 width=90% align=center cellspacing="1" cellpadding="5">
			<tr><td valign=top>
EOM
#모의 시험 랭킹
print <<"EOM";
<table border=0 width=95% align=left cellspacing="1" cellpadding="2" align=center>
<tr><td colspan=3>■전국 모의 시험의 결과</td></tr>
<tr class=sumi bgcolor=#ff9999><td></td><td align=center>이름</td><td align=center>부모의 이름</td></tr>
EOM
$i=1;
	foreach (@t_rank) {
		($k_id,$k_name,$oya1,$oya2,$seinengappi,$atama,$sports,$art,$food_time,$k_yobi2,$k_yobi3,$k_yobi4,$k_yobi5)= split(/<>/,$_);
		if($oya1 eq "" || $oya2 eq ""){$oya_hyouzi="$oya1 $oya2";}else{
		$oya_hyouzi="$oya1 <img src=\"$img_dir/hart.gif\" width=\"9\" height=\"10\"> $oya2 부부";}
								($sec,$min,$hour,$mday,$mon,$year,$wday) = split(/,/,$seinengappi);
#ver.1.36여기로부터
									$now_zikan = time;
									if ($module_on == 1) {
										$nenrei =  int(($now_zikan-$food_time)/60/60/24);
									}else{
										&konotosi_get($seinengappi);
									}
#ver.1.36여기까지
			print "<tr class=sita><td align=center>$i</td><td align=left>$k_name($nenrei나이)</td><td align=center>$oya_hyouzi</td></tr>";
		if($i >=$rankMax){last;}
		$i++;
	}
	print "</table></td><td valign=top >";
			
#운동회 랭킹
print <<"EOM";
<table border=0 width=95% align=left cellspacing="1" cellpadding="2" align=center>
<tr><td colspan=3>■운동회의 결과</td></tr>
<tr class=sumi bgcolor=#ff9999><td></td><td align=center>이름</td><td align=center>부모의 이름</td></tr>
EOM
$i=1;
	foreach (@y_rank) {
		($k_id,$k_name,$oya1,$oya2,$seinengappi,$atama,$sports,$art,$food_time,$k_yobi2,$k_yobi3,$k_yobi4,$k_yobi5)= split(/<>/,$_);
		if($oya1 eq "" || $oya2 eq ""){$oya_hyouzi="$oya1 $oya2";}else{
		$oya_hyouzi="$oya1 <img src=\"$img_dir/hart.gif\" width=\"9\" height=\"10\"> $oya2 부부";}
								($sec,$min,$hour,$mday,$mon,$year,$wday) = split(/,/,$seinengappi);
#ver.1.36 여기로부터
									$now_zikan = time;
									if ($module_on == 1) {
										$nenrei =  int(($now_zikan-$food_time)/60/60/24);
									}else{
										&konotosi_get($seinengappi);
									}
#ver.1.36여기까지
			print "<tr class=sita><td align=center>$i</td><td align=left>$k_name($nenrei나이)</td><td align=center>$oya_hyouzi</td></tr>";
		if($i >=$rankMax){last;}
		$i++;
	}
	print "</table></td><td valign=top >";
	
#미술 콩쿨 랭킹
print <<"EOM";
<table border=0 width=95% align=left cellspacing="1" cellpadding="2" align=center>
<tr><td colspan=3>■미술 콩쿨의 결과</td></tr>
<tr class=sumi bgcolor=#ff9999><td></td><td align=center>이름</td><td align=center>부모의 이름</td></tr>
EOM
$i=1;
	foreach (@s_rank) {
		($k_id,$k_name,$oya1,$oya2,$seinengappi,$atama,$sports,$art,$food_time,$k_yobi2,$k_yobi3,$k_yobi4,$k_yobi5)= split(/<>/,$_);
		if($oya1 eq "" || $oya2 eq ""){$oya_hyouzi="$oya1 $oya2";}else{
		$oya_hyouzi="$oya1 <img src=\"$img_dir/hart.gif\" width=\"9\" height=\"10\"> $oya2 부부";}
								($sec,$min,$hour,$mday,$mon,$year,$wday) = split(/,/,$seinengappi);
#ver.1.36 여기로부터
									$now_zikan = time;
									if ($module_on == 1) {
										$nenrei =  int(($now_zikan-$food_time)/60/60/24);
									}else{
										&konotosi_get($seinengappi);
									}
#ver.1.36여기까지
			print "<tr class=sita><td align=center>$i</td><td align=left>$k_name($nenrei나이)</td><td align=center>$oya_hyouzi</td></tr>";
		if($i >=$rankMax){last;}
		$i++;
	}
	print "</table></td></tr></table></body></html>";
	exit;
	
}	#써브루틴이 닫아
#######헤더 출력
sub header {
	$header_flg=1;		#ver.1.36
	if (@_[0] eq "2"){$bgcolor="#ffffff";}
	print "Content-type: text/html; charset=UTF-8\n\n";
	print "<html>\n<head>\n";
	print "<META HTTP-EQUIV=\"Content-type\" CONTENT=\"text/html; charset=UTF-8\">\n";
	print "<title>$title</title>\n";
	print <<"EOM";
	<script>
if (top.game == null) {
//top.location.href='/tool/nogame.html';
}
</script>
<style type="text/css">
<!--
.midasi {  font-size: 14px; font-weight: bold; text-align: center;color: #0066ff}
.midasi2{  font-size: 14px; font-weight: bold; text-align: center;color: #ff3300}
.purasu {  font-size: 13px; color: #009900;line-height:180%}
.purasu2 {  font-size: 13px; color: #cc9900;line-height:180%}
.mainasu {  font-size: 13px; color: #ff3300;line-height:180%}
.kuro {  font-size: 13px; text-align: left;color: #000000}
.honbun {  font-size: 9pt; line-height: 16px; color: #000000}
.honbun2 {  font-size: 11px; line-height: 18px; color: #99000}
.loto {  font-size: 28px; color: #000000;line-height:180%;}
.honbun3 {  font-size: 12px; line-height: 16px; color: #000000;ine-height:180%}
.sumi {  border: #000000; border-style: solid; border-top-width: 1px; border-right-width: 1px; border-bottom-width: 1px; border-left-width: 1px}
.sumi2{  border: #ff9933; border-style: dotted; border-top-width: 2px; border-right-width: 2px; border-bottom-width: 2px; border-left-width: 2px}
.migi {  border: #000000; border-style: solid; border-top-width: 1px; border-right-width: 1px; border-bottom-width: 1px; border-left-width: 0px}
.sita {  border: #000000; border-style: solid; border-top-width: 0px; border-right-width: 1px; border-bottom-width: 1px; border-left-width: 1px}
.naka {  border: #000000; border-style: solid; border-top-width: 1px; border-right-width: 0px; border-bottom-width: 1px; border-left-width: 0px}
a {color:#000000;text-decoration: none}
a:hover {text-decoration: underline}
body {font-size:11px;color:#000000 }
table {font-size:11px;color:#000000 }
-->
</style>
EOM
	print "</head><body bgcolor=$bgcolor>\n";
}


sub header2 {
	$header_flg=1;		#ver.1.36
	if (@_[0] eq "2"){$bgcolor="#ffffff";}
	print "Content-type: text/html; charset=UTF-8\n\n";
	print "<html>\n<head>\n";
	print "<META HTTP-EQUIV=\"Content-type\" CONTENT=\"text/html; charset=UTF-8\">\n";
	print "<title>$title</title>\n";
	print <<"EOM";
	<script language="JavaScript">
<!--
function pfvsetInterval(){
	retval = setInterval('countdown()',1000)
}
function countdown(){
	if(document.form1==null){clearInterval(retval);return;}
	if(document.form1.cdown==null){clearInterval(retval);return;}
	if(document.form1.cdown.value!='O K'){
		min = document.form1.cdown.value;
		min--;
		document.form1.cdown.value = min;
		if(document.form1.cdown.value==0){
			document.form1.cdown.value='O K'
			clearInterval(retval);
		}
	}
	else{clearInterval(retval);}
}
//-->
</script>

<style type="text/css">
<!--
.midasi {  font-size: 14px; font-weight: bold; text-align: center;color: #0066ff}
.midasi2{  font-size: 14px; font-weight: bold; text-align: center;color: #ff3300}
.purasu {  font-size: 13px; color: #009900;line-height:180%}
.purasu2 {  font-size: 13px; color: #cc9900;line-height:180%}
.mainasu {  font-size: 13px; color: #ff3300;line-height:180%}
.kuro {  font-size: 13px; text-align: left;color: #000000}
.honbun {  font-size: 11px; line-height: 16px; color: #000000}
.honbun2 {  font-size: 11px; line-height: 18px; color: #99000}
.loto {  font-size: 28px; color: #000000;line-height:180%;}
.honbun3 {  font-size: 12px; line-height: 16px; color: #000000;ine-height:180%}
.sumi {  border: #000000; border-style: solid; border-top-width: 1px; border-right-width: 1px; border-bottom-width: 1px; border-left-width: 1px}
.sumi2{  border: #ff9933; border-style: dotted; border-top-width: 2px; border-right-width: 2px; border-bottom-width: 2px; border-left-width: 2px}
.migi {  border: #000000; border-style: solid; border-top-width: 1px; border-right-width: 1px; border-bottom-width: 1px; border-left-width: 0px}
.sita {  border: #000000; border-style: solid; border-top-width: 0px; border-right-width: 1px; border-bottom-width: 1px; border-left-width: 1px}
.naka {  border: #000000; border-style: solid; border-top-width: 1px; border-right-width: 0px; border-bottom-width: 1px; border-left-width: 0px}
a {color:#000000;text-decoration: none}
a:hover {text-decoration: underline}
body {font-size:11px;color:#000000 }
table {font-size:11px;color:#000000 }
-->
</style>
EOM
	print "</head><body bgcolor=$bgcolor  onLoad=\"pfvsetInterval()\">\n";
}

#메세지 화면 출력
sub message {
&header(2);
	# 락 플래그가 있으면 락 디렉토리를 삭제
	if ($lockflag) { &unlock; }
	print <<"EOM";
	<div align=center>
	<br><br>$_[0]<br><br>
		<a href="$script?mode=$_[1]&name=$in{'name'}&pass=$in{'pass'}&id=$in{'id'}&command=$_[2]">돌아온다</a><!-- ver.1.36 -->
	</div>
	</body></html>
EOM
exit;
}

#에러 화면 출력
sub error {
	if ($header_flg !=1) {&header(2);}		#ver.1.36
	# 락 플래그가 있으면 락 디렉토리를 삭제
	if ($lockflag) { &unlock; }

	print "<br><center><h3><font color=#ff3300>ERROR !</font></h3>\n";
	print "<font color='#000000'>$_[0]</font>\n";
	print "<br><a href=\"javascript:history.back()\"> [앞에 화면으로 돌아온다] </a>";
	print "<P></center>\n";
	print "</body></html>\n";
	exit;
}
sub error2{
	# 락 플래그가 있으면 락 디렉토리를 삭제
	if ($lockflag) { &unlock; }
	print "<br><center><h3><font color=#ff3300>ERROR !</font></h3>\n";
	print "<font color='#000000'>$_[0]</font>\n";
	print "<br><a href=$script target=_top> [종료] </a>";
	print "<P></center>\n";
	print "</body></html>\n";
	exit;
}
sub error3{
			$yobi11 = "off";
			&temp_routin;
			&log_kousin($my_log_file,$temp);
	# 락 플래그가 있으면 락 디렉토리를 삭제
	if ($lockflag) { &unlock; }
	print "<br><center><h3><font color=#ff3300>ERROR !</font></h3>\n";
	print "<font color='#000000'>$_[0]</font>\n";
	print "<br><a href=$script target=_top> [종료] </a>";
	print "<P></center>\n";
	print "</body></html>\n";
	exit;
}
#시간 취득
sub time_get {
	$date_sec = time ;
	$ENV{'TZ'} = "JST-9";
	($sec,$min,$hour,$mday,$mon,$year,$wday) = localtime(time);
	$mon  = $mon+1;
	$year = $year + 1900;
	$date = "$year/$mon/$mday";
	$date2 = "$year/$mon/$mday $hour:$min";
}

#락 처리
sub lock {
	local($retry, $mtime);

	# 1분 이상 낡은 락은 삭제한다
	if (-e $lockfile) {
		($mtime) = (stat($lockfile))[9];
		if ($mtime < time - 60) { &unlock; }
	}

	# 리트라이는 10회
	$retry = 10;
	while (!mkdir($lockfile, 0755)) {
		if (--$retry <= 0) { &error('지금 사이트가 붐비고 있습니다.조금 기다려 주세요.'); }
		sleep(1);
	}
	# 락 플래그를 세운다
	$lockflag=1;
}


########  락 해제  
sub unlock {
	# 락 디렉토리 삭제
	rmdir($lockfile);

	# 락 플래그를 해제
	$lockflag=0;
}

######쿠키를 취득
sub get_cookie {
	local($key, $val, @cook);

	@cook = split(/;/, $ENV{'HTTP_COOKIE'});
	foreach (@cook) {
		($key, $val) = split(/=/);
		$key =~ s/\s//g;
		$cook{$key} = $val;
	}
	%ck = split(/<>/, $cook{'zinsei'});

	# 투고 직후에 쿠키 정보를 표시
	if ($in{'cook'} eq "on") {
		if ($in{'name'}) { $ck{'name'} = $in{'name'}; }
		if ($in{'email'}) { $ck{'pass'} = $in{'pass'}; }
	}
}


#####쿠키를 발행  
sub set_cookie {
	local($gmt, $cook, @w, @m, @t);

	# 주, 달을 정의
	@w = ('Sun','Mon','Tue','Wed','Thu','Fri','Sat');
	@m = ('Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec');

	# 국제 표준시간을 베이스로 보존 시간은 60일
	@t = gmtime(time + 60*24*60*60);
	$gmt = sprintf("%s, %02d-%s-%04d %02d:%02d:%02d GMT",
			$w[$t[6]], $t[3], $m[$t[4]], $t[5]+1900, $t[2], $t[1], $t[0]);

	# 쿠키 정보를 정의
	$cook = "name<>$in{'name'}<>pass<>$in{'pass'}<>";

	print "Set-Cookie: zinsei=$cook; expires=$gmt\n";
}


sub saikoro2 {
print << "EOM";
		<table border=0 width=500 align=center cellspacing="10" cellpadding="0">
	<tr><td align=center>
EOM
$goukei=0;
$zoro=0;
$ikkai=0;
	foreach(a..b){
		$randed=int(rand(6))+1;
		print "<img src=$img_dir/"."$randed".".gif width=54 height=54><img src=$img_dir/space.gif width=15 height=1>";
		if($ikkai == $randed){		#1회째와 같다=눈이었던 경우
			if(($ikkai % 2) == 0){$zoro=2;}		#짝수눈이라면 $zoro=2
			else{$zoro=1;}	#홀수눈이라면 $zoro=1
		}
		$ikkai=$randed;		#첫째의 주사위의 눈
		$goukei=$goukei+$randed;
	}
				&openMylog($in{'id'});
						if($basyo == 6){	#형무소에 있었을 경우
				  	if($kounyuu  =~ /찬제면죄부/ && $hsw){
																		$yobi1=0;
									$my_basyo=$basyo+$goukei;
									if($my_basyo >= 32){
										$start_flag=1;
										$my_basyo=$my_basyo-32;
									}
							}
							else {
							if($zoro == 0){$yobi1 ++;$money=$money-30;		#눈이 아니었던 경우
									if($yobi1 >= 4){		#4번째로 빠진다
												$money=$money+30;
												$yobi1=0;
												$my_basyo=$basyo+$goukei;
												if($my_basyo >= 32){
													$start_flag=1;
													$my_basyo=$my_basyo-32;
													$hsw=0;
												}
									}else{$my_basyo=6;}
							}else{		#눈이라면 빠진다
									$yobi1=0;
									$my_basyo=$basyo+$goukei;
									if($my_basyo >= 32){
										$start_flag=1;
										$my_basyo=$my_basyo-32;
										$hsw=0;
									}
							}
						}
						}else{		#형무소에 없는 경우의 통상의 진행
									$my_basyo=$basyo+$goukei;
									if($my_basyo >= 32){
										$start_flag=1;
										$my_basyo=$my_basyo-32;
									}
						}
				if($my_basyo == 22){$my_basyo=0;$start_flag=3;}
				&susumu($my_basyo,$start_flag,$zoro);
				$basyo=$my_basyo;
				$temp="$id<>$name<>$pass<>$money<>$basyo<>$haiguu<>$kodomo<>$love<>$land<>$house<>$kabu<>$kounyuu<>$sex<>$yobi1<>$yobi2<>$yobi3<>$yobi4<>$yobi5<>$yobi6<>$yobi7<>$yobi8<>$yobi9<>$yobi10<>$yobi11<>$yobi12<>$yobi13<>$yobi14<>\n";
				$newrank[0]=$temp;
				$newrank[1]=$susumu_syori;

# 로그를 갱신
	&lock;
	open(OUT,">$my_log_file") || &error("$my_log_file가 열리지 않습니다");
	print OUT @newrank;
	close(OUT);
	&unlock;
	print <<"EOM";
	</td></tr>
  <tr align="center"> 
    <td><br>
	<div align="center">
	주사위의 눈이 멈추면 아래의 버튼을 눌러 진출해 주세요.<br>
	또, 이 화면 상태로 게임을 종료하지 말아 주세요.
				<form method="POST" action="$script">
				<input type=hidden name=mode value="ban">
				<input type=hidden name=yobidasi value="message_hyouzi">
				<input type=hidden name=name value="$in{'name'}">
				<input type=hidden name=pass value="$in{'pass'}">
				<input type=hidden name=id value="$in{'id'}">
				<input type=hidden name=my_basyo value="$my_basyo">
				<input type="submit" class=button name="BT" value="진출한다">
	</div>
	</form>
<!--	주사위의 눈의 합계는$goukei.$zoromesse -->
	</td></tr></table></body></html>
EOM
}

#총자산을 보존
sub sousisan {
	$my_log_file = "./member/"."$in{'id'}"."log.cgi";
	open(IN,"$my_log_file") || &error("Open Error : $my_log_file");
		$my_prof = <IN>;
		&split_var2($my_prof);
	close(IN);
	
	
#화면 출력
	&set_cookie;
	&header(2);
#토지의 표시형을 정형
	if($land ne "없음"){
			($toti_basyo,$tubosuu,$toti_kounyuugaku)= split(/,/,$land);
			$land_hyouzi="$toti_basyo($tubosuu평)";
	}else{$land_hyouzi = "없음";$toti_kounyuugaku="0";}
#집의 표시형을 정형
	if($house ne "없음"){
			($house_style,$ie_kounyuugaku)= split(/,/,$house);
	}else{$house_style = "없음";$ie_kounyuugaku="0";}
#주식의 표시형을 정형
	if($kabu ne "없음"){
			($meigara,$hitokabu,$agari,$sagari,$kazu,$syokiti)= split(/,/,$kabu);
			$urine=$hitokabu*$kazu;
			$kabuhyouzi="$meigara($hitokabu만×$kazu주)";
	}else{
			$kabuhyouzi="없음";
			$urine="0";
	}
#슈퍼 정기예금 표시 정형
	if($yobi9 > 0){$super_hyouzi="<tr class=sita><td style=color:#ff6633;>슈퍼 정기예금</td><td align=right>$yobi9만</td></tr>";}else{$super_hyouzi="";}
	
#직무의 표시 조정
	&yakusyoku_hyouzi($yobi2);
			print <<"EOM";
<div align=center style=font-size:16px>데이터 보존</div><br>
	<table width="320" border="0" cellspacing="0" cellpadding="3" align=center>
	<div class=honbun>
	<tr><td colspan=2>여기서 보존을 하지 않으면 랭킹에 반영되지 않습니다.또 보존을 하지 않는 기간이$deleteUser 일간을 넘으면$name씨의 유저 데이터가 삭제됩니다.</td></tr>
	<tr class=sumi><td style="background-color:#ffff99;" colspan=2>스테이터스</td></tr>
	<tr class=sita><td style="color:#ff6633;" width=100>직무</td><td>$yakusyoku</td></tr>
	<tr class=sita><td style="color:#ff6633;">일스킬치</td><td>$yobi2</td></tr>
	<tr class=sita><td style="color:#ff6633;">배우자</td><td>$haiguu</td></tr>
	<tr class=sita><td style="color:#ff6633;">아이</td><td>$kodomo</td></tr>
	<tr class=sita><td style="color:#ff6633;">연인</td><td>$yobi3</td></tr>
	<tr class=sita><td style="color:#ff6633;">러브도</td><td>$love 포인트</td></tr>
	
	<tr class=sumi><td style="background-color:#ffff99;" colspan=2>총자산</td></tr>
	<tr class=sita><td style="color:#ff6633;">소유금</td><td align=right>$money만</td></tr>
	<tr class=sita><td style="color:#ff6633;">저금</td><td align=right>$yobi5만</td></tr>
	$super_hyouzi
	<tr class=sita><td style="color:#ff6633;">토지：$land_hyouzi</td><td align=right>$toti_kounyuugaku만</td></tr>
	<tr class=sita><td style="color:#ff6633;">집：$house_style</td><td align=right>$ie_kounyuugaku만</td></tr>
	<tr class=sita><td style="color:#ff6633;">주식：$kabuhyouzi</td><td align=right>$urine만</td></tr>
	<tr class=sita><td colspan=2 style="color:#ff6633;">소유물：</td></tr>
EOM

#소유물 표시
							(@kounyuus)= split(/,/,$kounyuu);
							&item_money_hash;
							foreach(@kounyuus){
								$nedan=($mono{$_}+$birthday{$_}+$takara{$_}+$item_money_hash{$_});
								$nedan_goukei=$nedan_goukei+$nedan;
								print "<tr class=sita><td>$_</td><td align=right>$nedan만</td></tr>";
							}
							
#합계 계산
					$sougoukei=$money+$yobi5+$yobi9+$toti_kounyuugaku+$ie_kounyuugaku+$urine+$nedan_goukei;
				

					print <<"EOM";
			<tr></table></div>
			<br><div  align=center style="font-size:15px;">총자산 합계：$sougoukei만</div>
			
			<div align="center">
	<form method="POST" action="$script">
	<input type=hidden name=mode value="sousisan_hozon">
	<input type=hidden name=name value="$in{'name'}">
	<input type=hidden name=pass value="$in{'pass'}">
	<input type=hidden name=id value="$in{'id'}">
	<input type=hidden name=yobi2 value="$yobi2">
	<input type=hidden name=haiguu value="$haiguu">
	<input type=hidden name=kodomo value="$kodomo">
	<input type=hidden name=yobi3 value="$yobi3">
	<input type=hidden name=love value="$love">
	<input type=hidden name=land value="$land">
	<input type=hidden name=house value="$house">
	<input type=hidden name=kabu value="$kabu">
	<input type=hidden name=yobi9 value="$yobi9">
	<input type=hidden name=kounyuu value="$kounyuu">
	<input type=hidden name=money value="$money">
	<input type=hidden name=yobi5 value="$yobi5">
	<input type=hidden name=yobi4 value="$yobi4">
	<input type=hidden name=yobi8 value="$yobi8">
	<input type=hidden name=basyo value="$basyo">
	<input type=hidden name=yobi1 value="$yobi1">
	<input type=hidden name=yobi10 value="$yobi10">
	<input type=hidden name=yobi12 value="$yobi12">
	<input type=hidden name=sougoukei value="$sougoukei">
	<input type=submit value="보존">
	</form>
			<a href=\"javascript:history.back()\"> [앞에 화면으로 돌아온다] </a></div>
			</body></html>
EOM
exit;
}

#총자산 보존 처리
sub sousisan_hozon {		#ver.1.36
	&lock;
	open(SH,"$logfile") || &error("Open Error : $logfile");
	@sousisan_keisanti = <SH>;
	close(SH);
	my $hensuuti = 0;
	foreach (@sousisan_keisanti) {
			&split_var;
			if($in{'name'} eq $name){
					&ranking_keisan(18,$name);
					$sousisan_juni = $return_juni;
					$sousisan_point = $return_tensuu;
					&ranking_keisan(7,$name);
					$love_juni = $return_juni;
					$love_point = $return_tensuu;
					&ranking_keisan(14,$name);
					$job_juni = $return_juni;
					$job_point = $return_tensuu;
					&ranking_keisan(16,$name);
					$start_juni = $return_juni;
					$start_point = $return_tensuu;
					$sougou_point = $sousisan_point + $love_point + $job_point + $start_point;
					$yobi13 = $sougou_point;
					$yobi2=$in{'yobi2'};
					$haiguu=$in{'haiguu'};
					$kodomo=$in{'kodomo'};
					$yobi3=$in{'yobi3'};
					$love=$in{'love'};
					$land=$in{'land'};
					$house=$in{'house'};
					$kabu=$in{'kabu'};
					$kounyuu=$in{'kounyuu'};
					$money=$in{'money'};
					$yobi5=$in{'yobi5'};
					$yobi4=$in{'yobi4'};
					$yobi8=$in{'yobi8'};
					$basyo=$in{'basyo'};
					$yobi1=$in{'yobi1'};
					$yobi6=$in{'sougoukei'};
					$yobi7 = time;
					$yobi10=$in{'yobi10'};
					$yobi12=$in{'yobi12'};
					$yobi9=$in{'yobi9'};
					$temp="$id<>$name<>$pass<>$money<>$basyo<>$haiguu<>$kodomo<>$love<>$land<>$house<>$kabu<>$kounyuu<>$sex<>$yobi1<>$yobi2<>$yobi3<>$yobi4<>$yobi5<>$yobi6<>$yobi7<>$yobi8<>$yobi9<>$yobi10<>$yobi11<>$yobi12<>$yobi13<>$yobi14<>\n";
					$sousisan_keisanti[$hensuuti] = "$temp";
					last;
			}
#				push(@newrank,$temp);
		$hensuuti ++;
	}	#foreach가 닫아
# 로그를 갱신
		$err = data_save($logfile, @sousisan_keisanti);
		if ($err) {&error("$err");}
#	&renameLock1;
#	open(OUT,">$tmpFile") || &error("$tmpFile가 열리지 않습니다");
#	print OUT @sousisan_keisanti;
#	close(OUT);
#	&renameLock2("$logfile");
	
	&openMylog($in{'id'});
	$yobi6=$in{'sougoukei'};
	$yobi7 = time;
	&temp_routin;
	open(OUT,">$my_log_file") || &error("@_[0]이 열리지 않습니다");
	print OUT $temp;
	close(OUT);
	&unlock;
	&message("데이터를 갱신했습니다.<br><br>총자산：$sousisan_juni위($sousisan_point점)<br><br>일스킬치：$job_juni위($job_point점)<br><br>러브도：$love_juni위($love_point점)<br><br>스타트 통과 회수：$start_juni위($start_point점)<br><br><font color=#ff6600>종합 포인트：$sougou_point점</font>","login_view");
}

#배우자, 연인의 이름을 돌려주는 써브루틴
sub checkMyKoibito {
		$my_log_file = "./member/"."@_[0]"."log.cgi";
		if(-e $my_log_file){
		open(MYL,"$my_log_file") || &error("로그 파일($my_log_file)이 열리지 않습니다.<br>재차 로그인해도 동일한 관리인($master_ad)까지 메일을 주세요.");
		$my_prof = <MYL>;
#		if($my_prof == ""){&error("로그 파일에 문제가 일어났습니다.<br>수고스럽겠지만, 관리인($master_ad)까지 메일을 주세요.");}		#ver.1.36
		&split_var2($my_prof);
		close(MYL);
		$return_koibito_name = $yobi3;
		$return_haiguu_name = $haiguu;
		}else{
		$return_koibito_name = "";
		$return_haiguu_name = "";
		}
}

#유저 삭제시의 배우자로부터 자신을 지우는 써브루틴
sub haiguuSakujo {
my($id,$name,$pass,$money,$basyo,$haiguu,$kodomo,$love,$land,$house,$kabu,$kounyuu,$sex,$yobi1,$yobi2,$yobi3,$yobi4,$yobi5,$yobi6,$yobi7,$yobi8,$yobi9,$yobi10,$yobi11,$yobi12,$yobi13,$yobi14);
							$aite_log_file = "./member/"."@_[0]"."log.cgi";
							open(AIT,"$aite_log_file") || &error("상대의 분의 로그 파일($aite_log_file)이 열리지 않습니다.<br>데이터 갱신이 아직 끝나지 않는 것 같습니다.");
							$aite_prof = <AIT>;
							if($aite_prof == ""){&error("상대의 분의 로그 파일에 문제가 있습니다.");}
($id,$name,$pass,$money,$basyo,$haiguu,$kodomo,$love,$land,$house,$kabu,$kounyuu,$sex,$yobi1,$yobi2,$yobi3,$yobi4,$yobi5,$yobi6,$yobi7,$yobi8,$yobi9,$yobi10,$yobi11,$yobi12,$yobi13,$yobi14)= split(/<>/,$aite_prof);
							close(AIT);
							if("@_[1]" eq "$haiguu"){
										$haiguu = "독신";
							}
$temp="$id<>$name<>$pass<>$money<>$basyo<>$haiguu<>$kodomo<>$love<>$land<>$house<>$kabu<>$kounyuu<>$sex<>$yobi1<>$yobi2<>$yobi3<>$yobi4<>$yobi5<>$yobi6<>$yobi7<>$yobi8<>$yobi9<>$yobi10<>$yobi11<>$yobi12<>$yobi13<>$yobi14<>\n";
	open(OUT,">$aite_log_file") || &error("$aite_log_file가 열리지 않습니다");
	print OUT $temp;
	close(OUT);
}

#유저 삭제시의 연인으로부터 자신을 지우는 써브루틴
sub koibitoSakujo {
my($id,$name,$pass,$money,$basyo,$haiguu,$kodomo,$love,$land,$house,$kabu,$kounyuu,$sex,$yobi1,$yobi2,$yobi3,$yobi4,$yobi5,$yobi6,$yobi7,$yobi8,$yobi9,$yobi10,$yobi11,$yobi12,$yobi13,$yobi14);
							$aite_log_file = "./member/"."@_[0]"."log.cgi";
							open(AIT,"$aite_log_file") || &error("상대의 분의 로그 파일($aite_log_file)이 열리지 않습니다.<br>데이터 갱신이 아직 끝나지 않는 것 같습니다.");
							$aite_prof = <AIT>;
							if($aite_prof == ""){&error("상대의 분의 로그 파일에 문제가 있습니다.");}
($id,$name,$pass,$money,$basyo,$haiguu,$kodomo,$love,$land,$house,$kabu,$kounyuu,$sex,$yobi1,$yobi2,$yobi3,$yobi4,$yobi5,$yobi6,$yobi7,$yobi8,$yobi9,$yobi10,$yobi11,$yobi12,$yobi13,$yobi14)= split(/<>/,$aite_prof);
							close(AIT);
										undef @new_aite_koibito;
										(@koibito)= split(/,/,$yobi3);
										foreach $one_koibito (@koibito){
												if("@_[1]" eq "$one_koibito"){next;}
												push (@new_aite_koibito,$one_koibito);
										}
										$yobi3 = join(",",@new_aite_koibito);
$temp="$id<>$name<>$pass<>$money<>$basyo<>$haiguu<>$kodomo<>$love<>$land<>$house<>$kabu<>$kounyuu<>$sex<>$yobi1<>$yobi2<>$yobi3<>$yobi4<>$yobi5<>$yobi6<>$yobi7<>$yobi8<>$yobi9<>$yobi10<>$yobi11<>$yobi12<>$yobi13<>$yobi14<>\n";
	open(OUT,">$aite_log_file") || &error("$aite_log_file가 열리지 않습니다");
	print OUT $temp;
	close(OUT);
}

#연인이 삭제한 취지의 메세지 송신
sub sakujoMessageSend {
			if(@_[2] eq "1"){
						$naiyou = "haiguuSakujo";
						$message_in="@_[1]씨의 데이터가 삭제되었으므로 배우자로부터 소거했습니다.";
			}elsif(@_[2] eq "2"){
						$naiyou = "koibitoSakujo";
						$message_in="@_[1]씨의 데이터가 삭제되었으므로 연인으로부터 소거했습니다.";
			}
$member_file="./member/@_[0]" . ".cgi";
			open(MM,"$member_file") || &error("Open Error : $member_file가 열리지 않습니다.");
						undef @newrank;
						$topmesse=<MM>;
						($kibou_type,$m_name,$m_messe,$m_money,$m_land,$m_house,$m_number,$m_id,$kekka,$m_yobi4)= split(/<>/, $topmesse);
						$m_number ++;
						$newrank[0]="$naiyou<><>$message_in<><><><>$m_number<><><><>\n";
						$newrank[1]="$topmesse";
						while (<MM>) {
							push(@newrank,$_);
						}		#while가 닫아
			close(MM);
			open(MMO,">$member_file") || &error("Write Error : $member_file");
			print MMO @newrank;
			close(MMO);	
}

#id번호 획득 써브루틴
sub id_check{
			my($id,$name,$pass,$money,$basyo,$haiguu,$kodomo,$love,$land,$house,$kabu,$kounyuu,$sex,$yobi1,$yobi2,$yobi3,$yobi4,$yobi5,$yobi6,$yobi7,$yobi8,$yobi9,$yobi10,$yobi11,$yobi12,$yobi13,$yobi14);
	open(IN,"$logfile") || &error("Open Error : $logfile");
	$name_flag=0;
	while (<IN>) {
($id,$name,$pass,$money,$basyo,$haiguu,$kodomo,$love,$land,$house,$kabu,$kounyuu,$sex,$yobi1,$yobi2,$yobi3,$yobi4,$yobi5,$yobi6,$yobi7,$yobi8,$yobi9,$yobi10,$yobi11,$yobi12,$yobi13,$yobi14)= split(/<>/);
				if($name eq @_[0]){$name_flag=1;last;}
	}
	$return_id=$id;
	if($name_flag==0){$return_id="";}
	close(IN);
}

#오리지날 아이템과 금액의 해시를 작성하는 써브루틴
sub item_money_hash {
		open(ITM,"$item_file") || &error("로그 파일($item_file)이 열리지 않습니다.");
		while (<ITM>) {
			($itemName,$syoyuusya,$syoyuusya_id,$job_up_ritu,$love_up_ritu,$money_up_ritu,$item_money_gaku,$present_uketori)= split(/<>/);
			$item_money_hash{$itemName} = $item_money_gaku;
		}
		close(ITM);
}

#오리지날 아이템과 일스킬 업의 해시를 작성하는 써브루틴
sub item_job_hash {
		open(ITM,"$item_file") || &error("로그 파일($item_file)이 열리지 않습니다.");
		while (<ITM>) {
			($itemName,$syoyuusya,$syoyuusya_id,$job_up_ritu,$love_up_ritu,$money_up_ritu,$item_money_gaku,$present_uketori)= split(/<>/);
			$item_job_hash{$itemName} = $job_up_ritu;
		}
		close(ITM);
}

#오리지날 아이템과 러브 업도의 해시를 작성하는 써브루틴
sub item_love_hash {
		open(ITM,"$item_file") || &error("로그 파일($item_file)이 열리지 않습니다.");
		while (<ITM>) {
			($itemName,$syoyuusya,$syoyuusya_id,$job_up_ritu,$love_up_ritu,$money_up_ritu,$item_money_gaku,$present_uketori)= split(/<>/);
			$item_love_hash{$itemName} = $love_up_ritu;
		}
		close(ITM);
}

#오리지날 아이템과 급료의 해시를 작성하는 써브루틴
sub item_kyuuryou_hash {
		open(ITM,"$item_file") || &error("로그 파일($item_file)이 열리지 않습니다.");
		while (<ITM>) {
			($itemName,$syoyuusya,$syoyuusya_id,$job_up_ritu,$love_up_ritu,$money_up_ritu,$item_money_gaku,$present_uketori)= split(/<>/);
			$item_kyuuryou_hash{$itemName} = $money_up_ritu;
		}
		close(ITM);
}

#오리지날 아이템과 소유자 ID의 해시를 작성하는 써브루틴
sub item_id_hash {
		open(ITM,"$item_file") || &error("로그 파일($item_file)이 열리지 않습니다.");
		while (<ITM>) {
			($itemName,$syoyuusya,$syoyuusya_id,$job_up_ritu,$love_up_ritu,$money_up_ritu,$item_money_gaku,$present_uketori)= split(/<>/);
			$item_id_hash{$itemName} = $syoyuusya_id;
		}
		close(ITM);
}


#직무 써브루틴
sub yakusyoku_hyouzi {
	if (@_[0] < 50){$yakusyoku="견습";}
	elsif(@_[0] < 100){$yakusyoku="신입사원";}
	elsif(@_[0] < 150){$yakusyoku="평사원";}
	elsif(@_[0] < 200){$yakusyoku="주임";}
	elsif(@_[0] < 250){$yakusyoku="계장";}
	elsif(@_[0] < 300){$yakusyoku="과장";}
	elsif(@_[0] < 500){$yakusyoku="부장";}
	elsif(@_[0] < 700){$yakusyoku="상무";}
	elsif(@_[0] < 900){$yakusyoku="전무";}
	elsif(@_[0] < 1200){$yakusyoku="사장";}
	elsif(@_[0] < 1500){$yakusyoku="회장";}
	elsif(@_[0] < 1800){$yakusyoku="명예회장";}
	elsif(@_[0] < 2200){$yakusyoku="대신";}
	elsif(@_[0] < 2600){$yakusyoku="수상";}
	elsif(@_[0] < 3000){$yakusyoku="대통령";}
	elsif(@_[0] < 3500){$yakusyoku="슈퍼스타";}
	elsif(@_[0] < 4000){$yakusyoku="갓 파더";}
	elsif(@_[0] < 4500){$yakusyoku="킹";}
	elsif(@_[0] < 10000){$yakusyoku="신";}
	elsif(@_[0] < 11000){$yakusyoku="정년퇴직자";}
	elsif(@_[0] < 13000){$yakusyoku="노인";}
	elsif(@_[0] >= 13000){$yakusyoku="전설의 사람";}
}

#랭킹을 연 타이밍으로의 아이 자립 처리(자신의 파일로부터 아이의 이름을 지운다)
sub ziritu_auto {
	if (@_[1] ne ""){
					&openMylog(@_[1]);
								undef @new_kodomo_hairetu;
								(@my_kodomo_hairetu)= split(/,/,$kodomo);
								foreach(@my_kodomo_hairetu){
									if(@_[0] eq $_){next;}
									push(@new_kodomo_hairetu,$_);
								}
								print "";
								$kodomo=join(",",@new_kodomo_hairetu);
					&temp_routin;
	open(OUT,">$my_log_file") || &error("$my_log_file가 열리지 않습니다");
	print OUT $temp;
	close(OUT);
	}
}

#ver.1.36 여기로부터
#생년월일부터 연령을 취득
sub konotosi_get {
#		my ($sec,$min,$hour,$mday,$mon,$year,$wday) = split(/,/,@_[0]);
		use Time::Local;
		my $time_henkan = timelocal($sec,$min,$hour,$mday,$mon,$year,$wday);
		$nenrei =  int(($now_zikan-$time_henkan)/60/60/24);
}



#ver.1.36여기까지 
