#!/usr/bin/perl

#----------------------------------------------------------------------
#	 ���� ���� ���� ver2. 50(Free)
#	 AUTHOR	: ������ ����
#	 URL	: http://www.abi-station.com/
#	 ����������/��Ʋ �ο� ver 1.10 (Free)
#	 AUTHOR	: Alpha-kou.
#	 URL	: http://www.grn.mmtr.or.jp/~dabo/
#
#          �ѱ۹��� : jjangg96@hanmail.net
#          �ѱ۹��� : http://www.x2-dr.com
#
#
#	�� ��ũ��Ʈ�� �����Դϴٸ�, ��� �̿��� ����, �� ������� �������� �����Ƿ� ������ �ֽʽÿ�.
#	��ũ��Ʈ�� ���� ������ "������ ����"���� ��Ź�մϴ�. (�߸��ص� Alpha-kou���� ���� �ʰ�^^;)
#	�� ��ũ��Ʈ�� ����� �Ͼ�� �Ǵ� ������ å���� ���� �ʽ��ϴ�.
#	�� ��ũ��Ʈ�� ������ �̿� ������ ���� �����ǰ� �ֽ��ϴ�.
#	http://www.grn.mmtr.or.jp/~dabo/cgiroom/kitei.html
#
#	�������� �����ϴٸ�, �۹̼��� ���ϰ� �˴ϴ�.
#	ainori.cgi(755)
#	Ȯ����(extension)��. dat�� ��(666)
#----------------------------------------------------------------------

$| = 1;
require './jcode.pl';
require './custom.cgi';

&kankyou;

if($filelockuse ==1){&lock;}

&decode;
&readlog;

# ���丮 ó��
if((int($timemin/$between) != $times2[0])&&($chara[5])){&syori;}

$yokoku = $between + $times2[1];
($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime($yokoku);
	$year += 1900;
	$month = sprintf("%02d",$mon +1);
	$mday = sprintf("%02d",$mday);
	$hour = sprintf("%02d",$hour);
	$min = sprintf("%02d",$min);
	$sec = sprintf("%02d",$sec);
	$yokoku2 = "$month/$mday $hour:$min";


if($form{'reload'} eq "�ڵ�" && $form{'reloadent'}){
	$reload = "�ڵ�";
	&set_cookie;
	&html;
	if($filelockuse ==1){if (-e,$lockfile){unlink($lockfile);}}
	exit;
}elsif($form{'reload'} eq "����" && $form{'reloadent'}){
	$reload = "����";
	&set_cookie;
	&html;
	if($filelockuse ==1){if (-e,$lockfile){unlink($lockfile);}}
	exit;
}
if($form{'del2'}){&del2;&html;if($filelockuse ==1){if (-e,$lockfile){unlink($lockfile);}}exit;}
if($form{'record'}) {&record;&rec;if($filelockuse ==1){if (-e,$lockfile){unlink($lockfile);}}exit;}
if($form{'mode'} eq "ssi"){&ssi;if($filelockuse ==1){if (-e,$lockfile){unlink($lockfile);}}exit;}
if($form{'mode'}){&imagevw;if($filelockuse ==1){if (-e,$lockfile){unlink($lockfile);}}exit;}
if($form{'story'}){&storyvw;if($filelockuse ==1){if (-e,$lockfile){unlink($lockfile);}}exit;}
if($form{'no'}){&fight;if($filelockuse ==1){if (-e,$lockfile){unlink($lockfile);}}exit;}
if($form{'rule'}){&rule;if($filelockuse ==1){if (-e,$lockfile){unlink($lockfile);}}exit;}
if($form{'rec'}){&rec;if($filelockuse ==1){if (-e,$lockfile){unlink($lockfile);}}exit;}
if($form{'rank'}){&rank;if($filelockuse ==1){if (-e,$lockfile){unlink($lockfile);}}exit;}
if($form{'couple'}){&couple;if($filelockuse ==1){if (-e,$lockfile){unlink($lockfile);}}exit;}
if($form{'log'}){&log;if($filelockuse ==1){if (-e,$lockfile){unlink($lockfile);}}exit;}
if($form{'useredit3'}){
	&useredit3;
	&html;
	if($filelockuse ==1){if (-e,$lockfile){unlink($lockfile);}}
	exit;
}
if($form{'useredit2'}){
	if($filelockuse ==1){if (-e,$lockfile){unlink($lockfile);}}
	&useredit2;
	exit;
}
if($form{'pass'}){
	if($filelockuse ==1){if (-e,$lockfile){unlink($lockfile);}}
	&useredit;
	exit;
}
&html;

if($filelockuse ==1){if (-e,$lockfile){unlink($lockfile);}}
exit;

##### ���ڵ壦���� ������ �ְ� �޾�
sub decode{

#�Էµ� ���� ���ڵ�
	if ($ENV{'REQUEST_METHOD'} eq "GET") {
		$buffer = $ENV{'QUERY_STRING'};
	} elsif ($ENV{'REQUEST_METHOD'} eq "POST") {
		read(STDIN, $buffer, $ENV{'CONTENT_LENGTH'});
	}
@pairs = split(/&/,$buffer);
foreach $pair (@pairs) {
	($key, $value) = split(/=/, $pair);
	$value =~ tr/+/ /;
	$value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
	&jcode'convert(*value, "euc");
#	$value =~ s/</&lt;/g;
#	$value =~ s/>/&gt;/g;
#	$value =~ s/ //g;
#	$value =~ s/ //g;
	$form{$key} = $value;

	}

}#end decode

##### �α� read
sub readlog{
	open(DB,"$logfile");
	seek(DB,0,0);  @chara = <DB>;  close(DB);

	for ($i=0; $i<6; $i++){
		($no[$i], $name[$i], $sakusya[$i], $homepage[$i], $lif[$i], $look[$i], $kind[$i], $spe[$i], $date[$i], $ip[$i], $love1[$i], $plus1[$i], $plus2[$i], $plus3[$i], $plus4[$i], $plus5[$i], $old[$i], $imgtype[$i], $job[$i], $love2[$i], $sex[$i],$love3[$i],$entrypass[$i],$mail[$i],$mailopen[$i],$rideonmail[$i],$sendstory[$i],$dmy) = split(/<>/,$chara[$i]);
	}

	open(KTM,"$ktimefile");
	seek(KTM,0,0);  @times2 = <KTM>;  close(KTM);

# �ð��� ���
	
	$timemin = time();		# �ʽð��� ���
	$times =time;
	($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime($times);
	$year += 1900;
	$month = sprintf("%02d",$mon +1);
	$mday = sprintf("%02d",$mday);
	$hour = sprintf("%02d",$hour);
	$min = sprintf("%02d",$min);
	$sec = sprintf("%02d",$sec);
	$jikan = "$month/$mday $hour:$min";
	$jikan2 = "($month/$mday $hour:$min)";
	
	if($times2[0] eq ""){
		$times2[0] = int($timemin/$between);
		$times2[0]="$times2[0]\n";
		$tmptime="$times\n";	
		$dmy="\n";
		$zero="0\n";
		push(@t,$times2[0]);push(@t,$tmptime);push(@t,$dmy);push(@t,$dmy);push(@t,$zero);push(@t,$zero);push(@t,$zero);
		open(KTM,">$ktimefile") ;	
			eval 'flock(KTM,2);';
			seek(KTM,0,0);	print KTM @t;
			eval 'flock(KTM,8);';
		close(KTM);
	}
	if(($chara[0] eq "")||($#chara < 5)){
		$dmycharam="-<>-<>-<><>-<>-<>-<>-<>-<>-<>-<>-<>-<>-<>-<>-<>-<>$imgfld/dmy.gif<>-<>-<>m<>-<><><><><><>\n";
		$dmycharaw="-<>-<>-<><>-<>-<>-<>-<>-<>-<>-<>-<>-<>-<>-<>-<>-<>$imgfld/dmy.gif<>-<>-<>w<>-<><><><><><>\n";
		@tmp ="";
		push(@tmp,"$dmycharam$dmycharam$dmycharam");
		push(@tmp,"$dmycharaw$dmycharaw$dmycharaw");
		open(DB,">$logfile") ;	
			eval 'flock(DB,2);';
			seek(DB,0,0);	print DB @tmp;
			eval 'flock(DB,8);';
		close(DB);
	}

#print "Content-type: text/html\n\n";
#	for ($i=0; $i<$#chara +1; $i++){
#		($no[$i], $name[$i], $sakusya[$i], $homepage[$i], $lif[$i], $look[$i], $kind[$i], $spe[$i], $date[$i], $ip[$i], $love1[$i], $plus1[$i], $plus2[$i], $plus3[$i], $plus4[$i], $plus5[$i], $old[$i], $imgtype[$i], $job[$i], $love2[$i], $sex[$i],$love3[$i],$dmy) = split(/<>/,$chara[$i]);
#print "$no[$i] >> ";
#		if(!$no[$i]){
#			splice(@chara,$i,1);
#			$delflg = 1;
#		}
#	}
#	if($delflg){
#		open(DB,">$logfile") ;	
#			eval 'flock(DB,2);';
#			seek(DB,0,0);	print DB @chara;
#			eval 'flock(DB,8);';
#		close(DB);
#		for ($i=0; $i<6; $i++){
#			($no[$i], $name[$i], $sakusya[$i], $homepage[$i], $lif[$i], $look[$i], $kind[$i], $spe[$i], $date[$i], $ip[$i], $love1[$i], $plus1[$i], $plus2[$i], $plus3[$i], $plus4[$i], $plus5[$i], $old[$i], $imgtype[$i], $job[$i], $love2[$i], $sex[$i],$love3[$i],$dmy) = split(/<>/,$chara[$i]);
#		}
#	}
	
}#end readlog

##### ���丮 ���� ó��

sub syori{
	$retireflg=0;
	if($times2[4] == 5){#��6 ����(��Ÿ�̾� üũ)
		for ($i=0; $i<6; $i++){
			if((($lif[$i]<1) && ($lif[$i] ne "-"))||($lif[$i] eq "*")){#��Ÿ�̾ ����
				if($sex[$i] eq "m"){
					$retirecol="6666FF";
					$retiresex="m";
				}else{
					$retirecol="FF6666";
					$retiresex="w";
				}
				$retireline=$i;
				if($lif[$i] eq "*"){
					$log = "$jikan2 ��δ�<font color=$retirecol>$name[$i]</font>(��)�� �����ߴ�. <br>\n";
				}else{
					$log = "$jikan2 <font color=$retirecol>$name[$i]</font>(��)�� ���������� �Ѱ谡 �ͼ�,<font color=red><b>����</b></font>�ϰ� �Ǿ���. <br>\n";
				}
				$retireflg=1;
				$ritsendstoryline = $sendstory[$i];
				$ritmailtitle = $storymailtitle;
				$ritcomment = $storymailcomment;
				$ritmail = $mail[$i];
				$ritname = $sakusya[$i];
				$ritcurchara = $name[$i];
				$ugokuno = $no[$i];#��Ÿ�̾�ø�$ugokuno�� ��Ÿ�̾� ĳ���ͷ� �Ѵ�
				$targetno="";
				$dmychara="-<>-<>-<><>-<>-<>-<>-<>-<>-<>-<>-<>-<>-<>-<>-<>-<>$imgfld/dmy.gif<>-<>-<>$retiresex<>-<><><><><><>\n";
				for ($i=0; $i<6; $i++){
					if($times2[2]==$no[$i]){
						$manno=$i;#Ŀ�� ������ �� ��ȣ
					}elsif($times2[3]==$no[$i]){
						$wmanno=$i;	#Ŀ�� ������ �� ��ȣ
					}
				}
				if($retireline==0){
					if($no[3] ne "-"){$love1[3]=0;}
					if($no[4] ne "-"){$love1[4]=0;}
					if($no[5] ne "-"){$love1[5]=0;}
				}elsif($retireline==1){
					if($no[3] ne "-"){$love2[3]=0;}
					if($no[4] ne "-"){$love2[4]=0;}
					if($no[5] ne "-"){$love2[5]=0;}
				}elsif($retireline==2){
					if($no[3] ne "-"){$love3[3]=0;}
					if($no[4] ne "-"){$love3[4]=0;}
					if($no[5] ne "-"){$love3[5]=0;}
				}elsif($retireline==3){
					if($no[0] ne "-"){$love1[0]=0;}
					if($no[1] ne "-"){$love1[1]=0;}
					if($no[2] ne "-"){$love1[2]=0;}
				}elsif($retireline==4){
					if($no[0] ne "-"){$love2[0]=0;}
					if($no[1] ne "-"){$love2[1]=0;}
					if($no[2] ne "-"){$love2[2]=0;}
				}elsif($retireline==5){
					if($no[0] ne "-"){$love3[0]=0;}
					if($no[1] ne "-"){$love3[1]=0;}
					if($no[2] ne "-"){$love3[2]=0;}
				}
				# ĳ���� ������ ����
				open(DB,"$logfile");
				eval 'flock(DB,2);';
				seek(DB,0,0);  @chara = <DB>; close(DB);
				for ($i=0; $i<6; $i++){
					$dmy =~ s/\n//g;
					$tmpchara="$no[$i]<>$name[$i]<>$sakusya[$i]<>$homepage[$i]<>$lif[$i]<>$look[$i]<>$kind[$i]<>$spe[$i]<>$date[$i]<>$ip[$i]<>$love1[$i]<>$plus1[$i]<>$plus2[$i]<>$plus3[$i]<>$plus4[$i]<>$plus5[$i]<>$old[$i]<>$imgtype[$i]<>$job[$i]<>$love2[$i]<>$sex[$i]<>$love3[$i]<>$entrypass[$i]<>$mail[$i]<>$mailopen[$i]<>$rideonmail[$i]<>$sendstory[$i]<>$dmy\n";
					if($retireline==$i){
						splice(@chara,$i,1,$dmychara);
					}else{
						splice(@chara,$i,1,$tmpchara);
					}
				}	

				if(($bo == 1)&&($times2[6] >= $bput)){

				#��� ��ȣ�� ���ĸ� �����Ѵ�
					@linestmp = @chara;
					foreach $i (0..(@linestmp-1)) {
					@Buftmp = split('<>', @linestmp[$i]);
					$SDatatmp{$i} = $Buftmp[0];
					}

					@SortDatatmp = sort {($SDatatmp{$b} <=> $SDatatmp{$a}) || ($b cmp $a)} keys(%SDatatmp);
					$lno = $linestmp[$SortDatatmp[0]] +1;

					srand;
					$bclines = $#bonuscharas +1;
					$tmpsel = int(rand($bclines));
					$bonuscharas[$tmpsel] =~ s/Bonus/$lno/g;
					$bonusc = $bonuscharas[$tmpsel];
					@Buftmp = split('<>', $bonusc);
					$bonuszumi = 0;
					for ($i=0; $i<$#chara +1; $i++){					
						($no[$i], $name[$i], $sakusya[$i], $homepage[$i], $lif[$i], $look[$i], $kind[$i], $spe[$i], $date[$i], $ip[$i], $love1[$i], $plus1[$i], $plus2[$i], $plus3[$i], $plus4[$i], $plus5[$i], $old[$i], $imgtype[$i], $job[$i], $love2[$i], $sex[$i],$love3[$i],$entrypass[$i],$mail[$i],$mailopen[$i],$rideonmail[$i],$sendstory[$i],$dmy) = split(/<>/,$chara[$i]);
						if($name[$i] eq $Buftmp[1]){$bonuszumi = 1;last;}
					}
					if($bonuszumi == 0){push(@chara,$bonusc);}
					$times2[6] = "0\n";
				}

				open(DB,">$logfile") ;
					print DB @chara;
					eval 'flock(DB,8);';
				close(DB);

			}
		}
		if($retireflg==1){
			$stcode=16;#��Ÿ�̾ ������(��) ��17 ���ܿ�
		}else{
			$times2[4]=0;$stcode=0;#������ �� ���� ���� �������� �Ѵ�
		}
	}

	if($times2[4]==0){#��1 ����
		#�����̴� ����� �����Ѵ�
		srand;
		$spetotal = $spe[0] + $spe[1] + $spe[2] + $spe[3] + $spe[4] + $spe[5] - 1;
		$ugokuhito = int(rand($spetotal))+1;
		if($ugokuhito <= $spe[0]){
			$ugoku = 0;$ugokuhito="$name[0]";$ugokucol="6666FF";$ugokuno=$no[0];
		}elsif($ugokuhito > $spe[0] && $ugokuhito <= ($spe[0] + $spe[1])){
			$ugoku = 1;$ugokuhito="$name[1]";$ugokucol="6666FF";$ugokuno=$no[1];
		}elsif($ugokuhito > ($spe[0] + $spe[1]) && $ugokuhito <= ($spe[0] + $spe[1] + $spe[2])){
			$ugoku = 2;$ugokuhito="$name[2]";$ugokucol="6666FF";$ugokuno=$no[2];
		}elsif($ugokuhito > ($spe[0] + $spe[1] + $spe[2]) && $ugokuhito <= ($spe[0] + $spe[1] + $spe[2] + $spe[3])){
			$ugoku = 3;$ugokuhito="$name[3]";$ugokucol="FF6666";$ugokuno=$no[3];
		}elsif($ugokuhito > ($spe[0] + $spe[1] + $spe[2] + $spe[3]) && $ugokuhito <= ($spe[0] + $spe[1] + $spe[2] + $spe[3] + $spe[4])){
			$ugoku = 4;$ugokuhito="$name[4]";$ugokucol="FF6666";$ugokuno=$no[4];
		}else{
			$ugoku = 5;$ugokuhito="$name[5]";$ugokucol="FF6666";$ugokuno=$no[5];
		}
	
		#Ÿ���� �����Ѵ�
		if($love1[$ugoku] > $love2[$ugoku] && $love1[$ugoku] > $love3[$ugoku]){
			$target = 1;
		}elsif($love2[$ugoku] > $love1[$ugoku] && $love2[$ugoku] > $love3[$ugoku]){
			$target = 2;
		}else{
			$target = 3;
		}

		#Ÿ���� ĳ������ �̸����� �Ѵ�.
		if($ugoku < 3){
			if($target == 1){
				$targethito = "$name[3]";$targetcol="FF6666";$targetno=$no[3];
				if($love1[$ugoku]>$tyousuki){$ulovekubun=3;}
			}elsif($target == 2){
				$targethito = "$name[4]";$targetcol="FF6666";$targetno=$no[4];
				if($love2[$ugoku]>$tyousuki){$ulovekubun=3;}
			}elsif($name[5] ne "-"){
				$targethito = "$name[5]";$targetcol="FF6666";$targetno=$no[5];
				if($love3[$ugoku]>$tyousuki){$ulovekubun=3;}
			}else{
				$targethito = "$name[4]";$targetcol="FF6666";$targetno=$no[4];
				if($love2[$ugoku]>$tyousuki){$ulovekubun=3;}
			}

		}else{
			if($target == 1){$targethito = "$name[0]";$targetcol="#6666FF";$targetno=$no[0];}
			elsif($target == 2){$targethito = "$name[1]";$targetcol="#6666FF";$targetno=$no[1];}
			elsif($name[2] ne "-"){$targethito = "$name[2]";$targetcol="#6666FF";$targetno=$no[2];}
			else{$targethito = "$name[1]";$targetcol="#6666FF";$targetno=$no[1];}
		}		
		if($ulovekubun==3){
			$stcode=30;
		}elsif($targetno eq "-"){
			$times2[4] = 16;
		}else{
			$stcode=0;
		}
	}else{#��2 ���� ���ĸ� ���� ������ ����
		for ($i=0; $i<6; $i++){#������ ����� ������ �ݱ�
			if($times2[2]==$no[$i]){
				$ugokuhito="$name[$i]";
				$ugokuno="$no[$i]";
				$ugokuserifu="$plus1[$i]";
				$ugoku=$i;
				$ugokukind=$kind[$i];
			}
		}
		for ($i=0; $i<6; $i++){#Ÿ���� ������ �ݱ�
			if($times2[3]==$no[$i]){
				$targethito="$name[$i]";
				$targetno="$no[$i]";
				$targetkind=$kind[$i];
				$target=$i;
				if($target == 3){
					if($love1[$ugoku]>$tyousuki){$ulovekubun=3;}
				}elsif($target == 4){
					if($love2[$ugoku]>$tyousuki){$ulovekubun=3;}
				}elsif($target == 5){
					if($love3[$ugoku]>$tyousuki){$ulovekubun=3;}
				}
				if(($ugoku==0) || ($ugoku==3)){
					if($love1[$i]>$tyousuki){$targetserifu="$plus1[$i]";$lovekubun=3;}
					elsif($love1[$i]>$suki){$targetserifu="$plus1[$i]";$lovekubun=2;}
					elsif($love1[$i]>$futu){$targetserifu="$plus3[$i]";$lovekubun=1;}
					else{$targetserifu="$plus2[$i]";$lovekubun=0;}
					$targetlove=$love1[$i];
					if($ugoku==0){$ugokucol="#6666FF";$targetcol="#FF6666"}
					else{$ugokucol="#FF6666";$targetcol="#6666FF"}
				}elsif(($ugoku==1) || ($ugoku==4)){
					if($love2[$i]>$tyousuki){$targetserifu="$plus1[$i]";$lovekubun=3;}
					elsif($love2[$i]>$suki){$targetserifu="$plus1[$i]";$lovekubun=2;}
					elsif($love2[$i]>$futu){$targetserifu="$plus3[$i]";$lovekubun=1;}
					else{$targetserifu="$plus2[$i]";$lovekubun=0;}
					$targetlove=$love2[$i];
					if($ugoku==1){$ugokucol="#6666FF";$targetcol="#FF6666"}
					else{$ugokucol="#FF6666";$targetcol="#6666FF"}
				}else{
					if($love3[$i]>$tyousuki){$targetserifu="$plus1[$i]";$lovekubun=3;}
					elsif($love3[$i]>$suki){$targetserifu="$plus1[$i]";$lovekubun=2;}
					elsif($love3[$i]>$futu){$targetserifu="$plus3[$i]";$lovekubun=1;}
					else{$targetserifu="$plus2[$i]";$lovekubun=0;}
					$targetlove=$love3[$i];
					if($ugoku==2){$ugokucol="#6666FF";$targetcol="#FF6666"}
					else{$ugokucol="#FF6666";$targetcol="#6666FF"}
				}
			}
		}
		
		$rival1="";#���̹� �ݱ�
		if($target==0){
			if($ugoku==3){
				if(($love1[4] > $love1[5]) && ($love1[4] > 66)){$rival1="$name[4]";$rival1no="$no[4]";$rival1line=4;}
				elsif(($love1[5] > $love1[4]) && ($love1[5] > 66)){$rival1="$name[5]";$rival1no="$no[5]";$rival1line=5;}
				elsif(($love1[1] > $love1[2]) && ($love1[1] > 66)){$rival1="$name[1]";$rival1no="$no[1]";$rival1line=1;}
				elsif(($love1[2] > $love1[1]) && ($love1[2] > 66)){$rival1="$name[2]";$rival1no="$no[2]";$rival1line=2;}
			}elsif($ugoku==4){
				if(($love1[3] > $love1[5]) && ($love1[3] > 66)){$rival1="$name[3]";$rival1no="$no[3]";$rival1line=3;}
				elsif(($love1[5] > $love1[3]) && ($love1[5] > 66)){$rival1="$name[5]";$rival1no="$no[5]";$rival1line=5;}
				elsif(($love2[1] > $love2[2]) && ($love2[1] > 66)){$rival1="$name[1]";$rival1no="$no[1]";$rival1line=1;}
				elsif(($love2[2] > $love2[1]) && ($love2[2] > 66)){$rival1="$name[2]";$rival1no="$no[2]";$rival1line=2;}
			}elsif($ugoku==5){
				if(($love1[3] > $love1[4]) && ($love1[3] > 66)){$rival1="$name[3]";$rival1no="$no[3]";$rival1line=3;}
				elsif(($love1[4] > $love1[3]) && ($love1[4] > 66)){$rival1="$name[4]";$rival1no="$no[4]";$rival1line=4;}
				elsif(($love3[1] > $love3[2]) && ($love3[1] > 66)){$rival1="$name[1]";$rival1no="$no[1]";$rival1line=1;}
				elsif(($love3[2] > $love3[1]) && ($love3[2] > 66)){$rival1="$name[2]";$rival1no="$no[2]";$rival1line=2;}
			}
		}elsif($target==1){
			if($ugoku==3){
				if(($love2[4] > $love2[5]) && ($love2[4] > 66)){$rival1="$name[4]";$rival1no="$no[4]";$rival1line=4;}
				elsif(($love2[5] > $love2[4]) && ($love2[5] > 66)){$rival1="$name[5]";$rival1no="$no[5]";$rival1line=5;}
				elsif(($love1[0] > $love1[2]) && ($love1[0] > 66)){$rival1="$name[0]";$rival1no="$no[0]";$rival1line=0;}
				elsif(($love1[2] > $love1[0]) && ($love1[2] > 66)){$rival1="$name[2]";$rival1no="$no[2]";$rival1line=2;}
			}elsif($ugoku==4){
				if(($love2[3] > $love2[5]) && ($love2[3] > 66)){$rival1="$name[3]";$rival1no="$no[3]";$rival1line=3;}
				elsif(($love2[5] > $love2[3]) && ($love2[5] > 66)){$rival1="$name[5]";$rival1no="$no[5]";$rival1line=5;}
				elsif(($love2[0] > $love2[2]) && ($love2[0] > 66)){$rival1="$name[0]";$rival1no="$no[0]";$rival1line=0;}
				elsif(($love2[2] > $love2[0]) && ($love2[2] > 66)){$rival1="$name[2]";$rival1no="$no[2]";$rival1line=2;}
			}elsif($ugoku==5){
				if(($love2[3] > $love2[4]) && ($love2[3] > 66)){$rival1="$name[3]";$rival1no="$no[3]";$rival1line=3;}
				elsif(($love2[4] > $love2[3]) && ($love2[4] > 66)){$rival1="$name[4]";$rival1no="$no[4]";$rival1line=4;}
				elsif(($love3[0] > $love3[2]) && ($love3[0] > 66)){$rival1="$name[0]";$rival1no="$no[0]";$rival1line=0;}
				elsif(($love3[2] > $love3[0]) && ($love3[2] > 66)){$rival1="$name[2]";$rival1no="$no[2]";$rival1line=2;}
			}
		}elsif($target==2){
			if($ugoku==3){
				if(($love3[4] > $love3[5]) && ($love3[4] > 66)){$rival1="$name[4]";$rival1no="$no[4]";$rival1line=4;}
				elsif(($love3[5] > $love3[4]) && ($love3[5] > 66)){$rival1="$name[5]";$rival1no="$no[5]";$rival1line=5;}
				elsif(($love1[0] > $love1[1]) && ($love1[0] > 66)){$rival1="$name[0]";$rival1no="$no[0]";$rival1line=0;}
				elsif(($love1[1] > $love1[0]) && ($love1[1] > 66)){$rival1="$name[1]";$rival1no="$no[1]";$rival1line=1;}
			}elsif($ugoku==4){
				if(($love3[3] > $love3[5]) && ($love3[3] > 66)){$rival1="$name[3]";$rival1no="$no[2]";$rival1line=2;}
				elsif(($love3[5] > $love3[3]) && ($love3[5] > 66)){$rival1="$name[5]";$rival1no="$no[5]";$rival1line=5;}
				elsif(($love2[0] > $love2[1]) && ($love2[0] > 66)){$rival2="$name[0]";$rival2no="$no[0]";$rival1line=0;}
				elsif(($love2[1] > $love2[0]) && ($love2[1] > 66)){$rival2="$name[1]";$rival2no="$no[1]";$rival1line=1;}
			}elsif($ugoku==5){
				if(($love3[3] > $love3[4]) && ($love3[3] > 66)){$rival1="$name[3]";$rival1no="$no[3]";$rival1line=3;}
				elsif(($love3[4] > $love3[3]) && ($love3[4] > 66)){$rival1="$name[4]";$rival1no="$no[4]";$rival1line=4;}
				elsif(($love3[0] > $love3[1]) && ($love3[0] > 66)){$rival3="$name[0]";$rival3no="$no[0]";$rival1line=0;}
				elsif(($love3[1] > $love3[0]) && ($love3[1] > 66)){$rival3="$name[1]";$rival3no="$no[1]";$rival1line=1;}
			}
		}elsif($target==3){
			if($ugoku==0){
				if(($love1[4] > $love1[5]) && ($love1[4] > 66)){$rival1="$name[4]";$rival1no="$no[4]";$rival1line=4;}
				elsif(($love1[5] > $love1[4]) && ($love1[5] > 66)){$rival1="$name[5]";$rival1no="$no[5]";$rival1line=5;}
				elsif(($love1[1] > $love1[2]) && ($love1[1] > 66)){$rival1="$name[1]";$rival1no="$no[1]";$rival1line=1;}
				elsif(($love1[2] > $love1[1]) && ($love1[2] > 66)){$rival1="$name[2]";$rival1no="$no[2]";$rival1line=2;}
			}elsif($ugoku==1){
				if(($love2[4] > $love2[5]) && ($love2[4] > 66)){$rival1="$name[4]";$rival1no="$no[4]";$rival1line=4;}
				elsif(($love2[5] > $love2[4]) && ($love2[5] > 66)){$rival1="$name[5]";$rival1no="$no[5]";$rival1line=5;}
				elsif(($love1[0] > $love1[2]) && ($love1[0] > 66)){$rival1="$name[0]";$rival1no="$no[0]";$rival1line=0;}
				elsif(($love1[2] > $love1[0]) && ($love1[2] > 66)){$rival1="$name[2]";$rival1no="$no[2]";$rival1line=2;}
			}elsif($ugoku==2){
				if(($love3[4] > $love3[5]) && ($love3[4] > 66)){$rival1="$name[4]";$rival1no="$no[4]";$rival1line=4;}
				elsif(($love3[5] > $love3[4]) && ($love3[5] > 66)){$rival1="$name[5]";$rival1no="$no[5]";$rival1line=5;}
				elsif(($love1[0] > $love1[1]) && ($love1[0] > 66)){$rival1="$name[0]";$rival1no="$no[0]";$rival1line=0;}
				elsif(($love1[1] > $love1[0]) && ($love1[1] > 66)){$rival1="$name[1]";$rival1no="$no[1]";$rival1line=1;}
			}
		}elsif($target==4){
			if($ugoku==0){
				if(($love1[3] > $love1[5]) && ($love1[3] > 66)){$rival1="$name[3]";$rival1no="$no[3]";$rival1line=3;}
				elsif(($love1[5] > $love1[3]) && ($love1[5] > 66)){$rival1="$name[5]";$rival1no="$no[5]";$rival1line=5;}
				elsif(($love2[1] > $love2[2]) && ($love2[1] > 66)){$rival1="$name[1]";$rival1no="$no[1]";$rival1line=1;}
				elsif(($love2[2] > $love2[1]) && ($love2[2] > 66)){$rival1="$name[2]";$rival1no="$no[2]";$rival1line=2;}
			}elsif($ugoku==1){
				if(($love2[3] > $love2[5]) && ($love2[3] > 66)){$rival1="$name[3]";$rival1no="$no[3]";$rival1line=3;}
				elsif(($love2[5] > $love2[3]) && ($love2[5] > 66)){$rival1="$name[5]";$rival1no="$no[5]";$rival1line=5;}
				elsif(($love2[0] > $love2[2]) && ($love2[0] > 66)){$rival1="$name[0]";$rival1no="$no[0]";$rival1line=0;}
				elsif(($love2[2] > $love2[0]) && ($love2[2] > 66)){$rival1="$name[2]";$rival1no="$no[2]";$rival1line=2;}
			}elsif($ugoku==2){
				if(($love3[3] > $love3[5]) && ($love3[3] > 66)){$rival1="$name[3]";$rival1no="$no[3]";$rival1line=3;}
				elsif(($love3[5] > $love3[3]) && ($love3[5] > 66)){$rival1="$name[5]";$rival1no="$no[5]";$rival1line=5;}
				elsif(($love2[0] > $love2[1]) && ($love2[0] > 66)){$rival1="$name[0]";$rival1no="$no[0]";$rival1line=0;}
				elsif(($love2[1] > $love2[0]) && ($love2[1] > 66)){$rival1="$name[1]";$rival1no="$no[1]";$rival1line=1;}
			}
		}else{
			if($ugoku==0){
				if(($love1[3] > $love1[4]) && ($love1[3] > 66)){$rival1="$name[3]";$rival1no="$no[3]";$rival1line=3;}
				elsif(($love1[4] > $love1[3]) && ($love1[4] > 66)){$rival1="$name[4]";$rival1no="$no[4]";$rival1line=4;}
				elsif(($love3[1] > $love3[2]) && ($love3[1] > 66)){$rival1="$name[1]";$rival1no="$no[1]";$rival1line=1;}
				elsif(($love3[2] > $love3[1]) && ($love3[2] > 66)){$rival1="$name[2]";$rival1no="$no[2]";$rival1line=2;}
			}elsif($ugoku==1){
				if(($love2[3] > $love2[4]) && ($love2[3] > 66)){$rival1="$name[3]";$rival1no="$no[3]";$rival1line=3;}
				elsif(($love2[4] > $love2[3]) && ($love2[4] > 66)){$rival1="$name[4]";$rival1no="$no[4]";$rival1line=4;}
				elsif(($love3[0] > $love3[2]) && ($love3[0] > 66)){$rival1="$name[0]";$rival1no="$no[0]";$rival1line=0;}
				elsif(($love3[2] > $love3[0]) && ($love3[2] > 66)){$rival1="$name[2]";$rival1no="$no[2]";$rival1line=2;}
			}elsif($ugoku==2){
				if(($love3[3] > $love3[4]) && ($love3[3] > 66)){$rival1="$name[3]";$rival1no="$no[3]";$rival1line=3;}
				elsif(($love3[4] > $love3[3]) && ($love3[4] > 66)){$rival1="$name[4]";$rival1no="$no[4]";$rival1line=4;}
				elsif(($love3[0] > $love3[1]) && ($love3[0] > 66)){$rival1="$name[0]";$rival1no="$no[0]";$rival1line=0;}
				elsif(($love3[1] > $love3[0]) && ($love3[1] > 66)){$rival1="$name[1]";$rival1no="$no[1]";$rival1line=1;}
			}
		}
	}

	if(($stcode==30) && ($times2[4]!=16)){
		$log = "$jikan2 <font color=$ugokucol>$ugokuhito</font>(��)�� ��ħ�� ������, $wagon�� ���ߴ�! <br>\n";		
		$stcode=31;
	}elsif($times2[4]==31){
		$log = "$jikan2 <font color=$ugokucol>$ugokuhito</font>��<font color=green>$ticket</font>�� �ּ���.��<br>\n";		
		$stcode=32;
	}elsif($times2[4]==32){
		$log = "$jikan2 <font color=$ugokucol>$ugokuhito</font>(��)�� �㿡 <font color=$targetcol>$targethito</font>(��)�� ȣ���� �㿡�� ȣ���ߴ�. <br>\n";
		$stcode=1;
	}elsif($times2[4]==0){
		srand;
		$ep = int(rand(4));
		if($ep==0){
			$log = "$jikan2 <font color=$ugokucol>$ugokuhito</font>(��)�� <font color=$targetcol>$targethito</font>(��)�� �������ִ� ������ �Ҿ�´�. <br>\n";
		}elsif($ep==1){
			$log = "$jikan2 <font color=$ugokucol>$ugokuhito</font>(��)�� <font color=$targetcol>$targethito</font>(��)�� ������ ������ ����. <br>\n";
		}elsif($ep==2){
			$log = "$jikan2 <font color=$ugokucol>$ugokuhito</font>�� <font color=$targetcol>$targethito</font>(��)�� ������ ������. <br>\n";
		}else{
			$log = "$jikan2 <font color=$ugokucol>$ugokuhito</font>(��)�� �������� <font color=$targetcol>$targethito</font>�� ��ó�� �ɾҴ�. <br>\n";
		}
		$stcode=1;
	}elsif($times2[4] == 1){
		if($ulovekubun==3){
			$log = "$jikan2 $plus4[$ugoku]\n";
		}else{
			$log = "$jikan2 $ugokuserifu\n";
		}		
		$stcode=2;
	}elsif($times2[4] == 2){
		if($ulovekubun==3){
			$log = "$jikan2 $plus4[$target]\n";
		}else{
			$log = "$jikan2 $targetserifu\n";
		}
		$stcode=3;
	}elsif($times2[4] == 3){#��4 ����
		if(($ulovekubun==3) && ($ugoku<3)){
			$log = "$jikan2 <font color=$ugokucol>$ugokuhito</font>(��)��<font color=$targetcol>$targethito</font>���� <font color=green>$ticket</font>�� �ǳ��־���. ���� ���� �����!?<br>\n";
			$stcode=7;
		}elsif((($lovekubun==3) && ($ugoku>2))||(($lovekubun>0) && ($lovekubun<4) )){
			srand;$ugokukind = int(rand($ugokukind));
			if($ugokukind<1){$ugokukind=1;}
			$log = "$jikan2 <font color=$targetcol>$targethito</font>(��)��<font color=$ugokucol>$ugokuhito</font>�� ����� ���� $tablelove�� $ugokukind �ö���. <br>\n";
			$stcode=4;
			for ($i=0; $i<6; $i++){
				if($times2[3]==$no[$i]){
					if(($ugoku==0) || ($ugoku==3)){
						$love1[$i]=$love1[$i]+$ugokukind;
					}elsif(($ugoku==1) || ($ugoku==4)){
						$love2[$i]=$love2[$i]+$ugokukind;
					}else{
						$love3[$i]=$love3[$i]+$ugokukind;
					}
				}
			}
		}else{
			srand;$ugokukind = int(rand($ugokukind))+1;
			if($ugokukind<1){$ugokukind=1;}
			$log = "$jikan2 <font color=$targetcol>$targethito</font>(��)�� �и��� �Ⱦ� �ϰ� �־������� <font color=$ugokucol>$ugokuhito</font>�� ����� ����$tablelove��$ugokukind �ö���. <br>\n";
			$stcode=4;
		for ($i=0; $i<6; $i++){
			if($times2[3]==$no[$i]){
				if(($ugoku==0) || ($ugoku==3)){
					$love1[$i]=$love1[$i]+$ugokukind;
				}elsif(($ugoku==1) || ($ugoku==4)){
					$love2[$i]=$love2[$i]+$ugokukind;
				}else{
					$love3[$i]=$love3[$i]+$ugokukind;
				}
			}
		}
		}
		# ĳ���� ������ ����
		open(DB,"$logfile");
		eval 'flock(DB,2);';
		seek(DB,0,0);  @chara = <DB>;  close(DB);
		for ($i=0; $i<6; $i++){
			$dmy =~ s/\n//g;
			$tmpchara="$no[$i]<>$name[$i]<>$sakusya[$i]<>$homepage[$i]<>$lif[$i]<>$look[$i]<>$kind[$i]<>$spe[$i]<>$date[$i]<>$ip[$i]<>$love1[$i]<>$plus1[$i]<>$plus2[$i]<>$plus3[$i]<>$plus4[$i]<>$plus5[$i]<>$old[$i]<>$imgtype[$i]<>$job[$i]<>$love2[$i]<>$sex[$i]<>$love3[$i]<>$entrypass[$i]<>$mail[$i]<>$mailopen[$i]<>$rideonmail[$i]<>$sendstory[$i]<>$dmy\n";
			splice(@chara,$i,1,$tmpchara);
		}	
		open(DB,">$logfile") ;
			print DB @chara;
			eval 'flock(DB,8);';
		close(DB);
			
	}elsif($times2[4] == 4){#��5 ����
		srand;$tmphekomi = int(rand($suki));
		$hekomi=int($targetlove - $tmphekomi);
		if($hekomi<1){$hekomi=1;}
		elsif($hekomi>10){$hekomi=10;}
		if($lovekubun>1){#��뵵 ȣ���� ������ �ִ� ���
			srand;$targetkind = int(rand($targetkind))+1;
			if($targetkind<1){$targetkind=1;}
			$log = "$jikan2 <font color=$ugokucol>$ugokuhito</font>(��)��<font color=$targetcol>$targethito</font>�� ����� ���� ���, $tablelove��$targetkind �ö���. <br>\n";
			for ($i=0; $i<6; $i++){	
				if($times2[2]==$no[$i]){
					if(($target==0) || ($target==3)){
						$love1[$i]=$love1[$i]+$targetkind;
					}elsif(($target==1) || ($target==4)){
						$love2[$i]=$love2[$i]+$targetkind;
					}else{
						$love3[$i]=$love3[$i]+$targetkind;
					}
				}
			}
		}elsif($lovekubun==1){#���� ���� �������� ���� ���
			$log = "$jikan2 <font color=$ugokucol>$ugokuhito</font>(��)��<font color=$targetcol>$targethito</font>�� ������ �����⿡ $tablelif�� $hekomi �پ�����. <br>\n";
			for ($i=0; $i<6; $i++){
				if($times2[2]==$no[$i]){
					$lif[$i]=$lif[$i]-$hekomi;
				}
			}
		}else{#��밡 �Ⱦ� �ϰ� �ִ� ���
			$log = "$jikan2 <font color=$ugokucol>$ugokuhito</font>(��)��<font color=$targetcol>$targethito</font>�� ������ ���� $tablelif�� $hekomi��ŭ �پ�����. <br>\n";
			for ($i=0; $i<6; $i++){
				if($times2[2]==$no[$i]){
					$lif[$i]=$lif[$i]-$hekomi;
				}
			}
		}
		for ($i=0; $i<6; $i++){
			if($no[$i] eq "-"){
				$retireflg=1;
				$sendstoryline = $sendstory[$i];
				$mailtitle = $storymailtitle;
				$comment = $storymailcomment;
				$mail = $mail[$i];
				$name = $sakusya[$i];
				$curchara = $name[$i];
				$ugokuno=$no[$i];#��������� �߰��� ����$ugokuno�� ��Ÿ�̾� ĳ���ͷ� �Ѵ�
				$targetno="";
			}
		}
		if($retireflg==1){
			$stcode=16;#��Ÿ�̾ ������(��) ��7 ���ܿ�
		}else{
			$stcode=5;
		}
		# ĳ���� ������ ����
		open(DB,"$logfile");
		eval 'flock(DB,2);';
		seek(DB,0,0);  @chara = <DB>;  close(DB);
		for ($i=0; $i<6; $i++){
			$dmy =~ s/\n//g;
			$tmpchara="$no[$i]<>$name[$i]<>$sakusya[$i]<>$homepage[$i]<>$lif[$i]<>$look[$i]<>$kind[$i]<>$spe[$i]<>$date[$i]<>$ip[$i]<>$love1[$i]<>$plus1[$i]<>$plus2[$i]<>$plus3[$i]<>$plus4[$i]<>$plus5[$i]<>$old[$i]<>$imgtype[$i]<>$job[$i]<>$love2[$i]<>$sex[$i]<>$love3[$i]<>$entrypass[$i]<>$mail[$i]<>$mailopen[$i]<>$rideonmail[$i]<>$sendstory[$i]<>$dmy\n";
			splice(@chara,$i,1,$tmpchara);
		}	
		open(DB,">$logfile") ;
			print DB @chara;
			eval 'flock(DB,8);';
		close(DB);
	}elsif($times2[4] == 7){#��8 ����(Ƽ�� �ǳ��� �� )
		$log = "$jikan2 <font color=$targetcol>$targethito</font>(��)��<font color=green>$ticket</font>�� �޾�, �� �� ���� ���� ���´�. <br>\n";
		$stcode=8;
	}elsif($times2[4] == 8){#��9 ����(Ƽ�� �ǳ��� �� )
		$log = "$jikan2 <font color=$ugokucol>$ugokuhito</font>�� ����, �� �� ���� ���� ���´�. <br>\n";
		$stcode=9;
	}elsif($times2[4] == 9){#��10 ����(Ƽ�� �ǳ��� �� )
		$log = "$jikan2 ������,<font color=$ugokucol>$ugokuhito</font>(��)��,<font color=$targetcol>$targethito</font>(��)�� ��ٸ���. <br>\n";
		$stcode=10;
	}elsif($times2[4] == 10){#��11 ����(Ƽ�� �ǳ��� �� )
		$log = "$jikan2 <font color=$targetcol>$targethito</font>�� �Դ�. ����������. <br>\n";
		$stcode=11;
	}elsif($times2[4] == 11){#��12 ����(������ �Ǵ�)
		if($lovekubun==3){
			srand;
			$ep = int(rand(6));
			if($ep==0){
				$log = "$jikan2 <font color=$targetcol>$targethito</font>���̷� ���� ���������� �Բ� ���ư� �ּ���.��<br>\n";
			}elsif($ep==1){
				$log = "$jikan2 <font color=$targetcol>$targethito</font>�� ����$ugokuhito�� ���ؼ� ���ݱ��� �������� ����� �Ǿ����� ���� ������<br>$ugokuhito�� ���� ���� �����մϴ�. �׷��ϱ� ���� ������ �ѱ��� ���ư� �ּ���.��<br>\n";
			}elsif($ep==2){
				$log = "$jikan2 <font color=$targetcol>$targethito</font>���� ��Ź�帳�ϴ�.��<br>\n";
			}elsif($ep==3){
				$log = "$jikan2 <font color=$targetcol>$targethito</font>������ �ѱ��� ���ư���.��<br>\n";
			}elsif($ep==4){
				$log = "$jikan2 <font color=$targetcol>$targethito</font>��������$ugokuhito�� ������ �����ϴ� ���. ������ �����ϴ� ���.��<br>\n";
			}else{
				$log = "$jikan2 <font color=$targetcol>$targethito</font>�������� ���� ����?��<br>\n";
			}
			$stcode=12;
		}else{
			$log = "$jikan2 $plus5[$target]\n";
			$stcode=20;
		}
	}elsif($times2[4] == 20){#���������� ���
			$log = "$jikan2 $plus5[$ugoku]\n";
			$stcode=21;
	}elsif($times2[4] == 21){#���������� ���
		$log = "$jikan2 <font color=$ugokucol>$ugokuhito</font>(��)�� �������Ƿ�,<font color=red><b>ȥ�ڼ� �ͱ�</b></font>�ϰ� �Ǿ���. <br>\n";
		$retireflg=1;
		$targetno="";
		$lif[$ugoku]="*";
		$stcode=5;
		# ĳ���� ������ ����
		open(DB,"$logfile");
		eval 'flock(DB,2);';
		seek(DB,0,0);  @chara = <DB>;  close(DB);
		for ($i=0; $i<6; $i++){
			$dmy =~ s/\n//g;
			$tmpchara="$no[$i]<>$name[$i]<>$sakusya[$i]<>$homepage[$i]<>$lif[$i]<>$look[$i]<>$kind[$i]<>$spe[$i]<>$date[$i]<>$ip[$i]<>$love1[$i]<>$plus1[$i]<>$plus2[$i]<>$plus3[$i]<>$plus4[$i]<>$plus5[$i]<>$old[$i]<>$imgtype[$i]<>$job[$i]<>$love2[$i]<>$sex[$i]<>$love3[$i]<>$entrypass[$i]<>$mail[$i]<>$mailopen[$i]<>$rideonmail[$i]<>$sendstory[$i]<>$dmy\n";
			splice(@chara,$i,1,$tmpchara);
		}	
		open(DB,">$logfile") ;
		eval 'flock(DB,2);';
			print DB @chara;
			eval 'flock(DB,8);';
		close(DB);

	}elsif($times2[4] == 12){#��12 ����(Ŀ�� ����)
		$log = "$jikan2 �� ����� ���࿡ ��� ��Ȳ�ߴ�<font color=$ugokucol>$ugokuhito</font>��<font color=$targetcol>$targethito</font>. 2���� ����� ��ħ�� ����� ���Ҵ�. <br>\n";
		$stcode=13;
	}elsif($times2[4] == 13){#��12 ����(�ູ)
		if($rival1 ne ""){
			if($rival1line < 3){
				$rivalcol="6666FF";
			}else{
				$rivalcol="FF6666";
			}
			$log = "$jikan2 <font color=$rivalcol>$rival1</font>(��)�� ������ ���� ���� �󱼷�<font color=$targetcol>$targethito</font>(��)�� ���´�. <br>\n";
			for ($i=0; $i<6; $i++){
				if($rival1no==$no[$i]){
					srand;$hekomi = int(rand($hekomishisu))+1;
					$lif[$i]=$lif[$i]-$hekomi;
				}
			}
			# ĳ���� ������ ����
			open(DB,"$logfile");
			eval 'flock(DB,2);';
			seek(DB,0,0);  @chara = <DB>;  close(DB);
			for ($i=0; $i<6; $i++){
				$dmy =~ s/\n//g;
				$tmpchara="$no[$i]<>$name[$i]<>$sakusya[$i]<>$homepage[$i]<>$lif[$i]<>$look[$i]<>$kind[$i]<>$spe[$i]<>$date[$i]<>$ip[$i]<>$love1[$i]<>$plus1[$i]<>$plus2[$i]<>$plus3[$i]<>$plus4[$i]<>$plus5[$i]<>$old[$i]<>$imgtype[$i]<>$job[$i]<>$love2[$i]<>$sex[$i]<>$love3[$i]<>$entrypass[$i]<>$mail[$i]<>$mailopen[$i]<>$rideonmail[$i]<>$sendstory[$i]<>$dmy\n";
				splice(@chara,$i,1,$tmpchara);
			}	
			open(DB,">$logfile") ;
				print DB @chara;
				eval 'flock(DB,8);';
			close(DB);
		}else{
			$log = "$jikan2 ��δ� �׵��� �ູ�ߴ�. <br>\n";
		}
		$stcode=14;
	}elsif($times2[4] == 14){#��13 ����(Ŀ�� ������ �ҽ�)
		open(CP,"$couplefile");
		seek(CP,0,0);  @couple = <CP>; close(CP);
		#Ŀ�� ��ȣ�� ���ĸ� �����Ѵ�
		open(DBTMP,"$couplefile");
		seek(DBTMP,0,0);  @couple = <DBTMP>;  close(DBTMP);
		foreach $i (0..(@couple-1)) {
		@Buftmpt = split('<>', @couple[$i]);
		$SDatatmpt{$i} = $Buftmpt[0];
		}
		@SortDatatmpt = sort {($SDatatmpt{$b} <=> $SDatatmpt{$a}) || ($b cmp $a)} keys(%SDatatmpt);
		$cpno = $couple[$SortDatatmpt[0]] +1;

		$log = "$jikan2 <font color=blue><b>$title2$cpnoȣ Ŀ�� ź��! ������ �����մϴ�! </b></font><br>\n";
		$stcode=15;
	}elsif($times2[4] == 15){#��14 ����(Ŀ�� ����� �����Ѵ�)
		for ($i=0; $i<6; $i++){
			if($times2[2]==$no[$i]){
				$manno=$i;#Ŀ�� ������ �� ��ȣ
			}elsif($times2[3]==$no[$i]){
				$wmanno=$i;	#Ŀ�� ������ �� ��ȣ
			}
		}
		if($manno==0){
			if($wmanno==3){$wmanlove=$love1[3];}
			elsif($wmanno==4){$wmanlove=$love1[4];}
			elsif($wmanno==5){$wmanlove=$love1[5];}
			if($no[3] ne "-"){$love1[3]=0;}
			if($no[4] ne "-"){$love1[4]=0;}
			if($no[5] ne "-"){$love1[5]=0;}
		}elsif($manno==1){
			if($wmanno==3){$wmanlove=$love2[3];}
			elsif($wmanno==4){$wmanlove=$love2[4];}
			elsif($wmanno==5){$wmanlove=$love2[5];}
			if($no[3] ne "-"){$love2[3]=0;}
			if($no[4] ne "-"){$love2[4]=0;}
			if($no[5] ne "-"){$love2[5]=0;}
		}elsif($manno==2){
			if($wmanno==3){$wmanlove=$love3[3];}
			elsif($wmanno==4){$wmanlove=$love3[4];}
			elsif($wmanno==5){$wmanlove=$love3[5];}
			if($no[3] ne "-"){$love3[3]=0;}
			if($no[4] ne "-"){$love3[4]=0;}
			if($no[5] ne "-"){$love3[5]=0;}
		}
		if($wmanno==3){
			if($manno==0){$manlove=$love1[0];}
			elsif($manno==1){$manlove=$love1[1];}
			elsif($manno==2){$manlove=$love1[2];}
			if($no[0] ne "-"){$love1[0]=0;}
			if($no[1] ne "-"){$love1[1]=0;}
			if($no[2] ne "-"){$love1[2]=0;}
		}elsif($wmanno==4){
			if($manno==0){$manlove=$love2[0];}
			elsif($manno==1){$manlove=$love2[1];}
			elsif($manno==2){$manlove=$love2[2];}
			if($no[0] ne "-"){$love2[0]=0;}
			if($no[1] ne "-"){$love2[1]=0;}
			if($no[2] ne "-"){$love2[2]=0;}
		}elsif($wmanno==5){
			if($manno==0){$manlove=$love3[0];}
			elsif($manno==1){$manlove=$love3[1];}
			elsif($manno==2){$manlove=$love3[2];}
			if($no[0] ne "-"){$love3[0]=0;}
			if($no[1] ne "-"){$love3[1]=0;}
			if($no[2] ne "-"){$love3[2]=0;}
		}
		$mdmychara="-<>-<>-<><>-<>-<>-<>-<>-<>-<>-<>-<>-<>-<>-<>-<>-<>$imgfld/dmy.gif<>-<>-<>m<>-<><><><><><>\n";
		$wdmychara="-<>-<>-<><>-<>-<>-<>-<>-<>-<>-<>-<>-<>-<>-<>-<>-<>$imgfld/dmy.gif<>-<>-<>w<>-<><><><><><>\n";
		# ĳ���� ������ ����
		open(DB,"$logfile");
		eval 'flock(DB,2);';
		seek(DB,0,0);  @chara = <DB>;close(DB);
		for ($i=0; $i<6; $i++){
			$dmy =~ s/\n//g;
			$tmpchara="$no[$i]<>$name[$i]<>$sakusya[$i]<>$homepage[$i]<>$lif[$i]<>$look[$i]<>$kind[$i]<>$spe[$i]<>$date[$i]<>$ip[$i]<>$love1[$i]<>$plus1[$i]<>$plus2[$i]<>$plus3[$i]<>$plus4[$i]<>$plus5[$i]<>$old[$i]<>$imgtype[$i]<>$job[$i]<>$love2[$i]<>$sex[$i]<>$love3[$i]<>$entrypass[$i]<>$mail[$i]<>$mailopen[$i]<>$rideonmail[$i]<>$sendstory[$i]<>$dmy\n";
			if($manno==$i){
				$cpman=$tmpchara;
				$tmpchara=$mdmychara;
			}elsif($wmanno==$i){
				$cpwman=$tmpchara;
				$tmpchara=$wdmychara;
			}
			splice(@chara,$i,1,$tmpchara);
		}	

		if(($bo == 1)&&($times2[6] >= $bput)){

			#��� ��ȣ�� ���ĸ� �����Ѵ�
			@linestmp = @chara;
			foreach $i (0..(@linestmp-1)) {
				@Buftmp = split('<>', @linestmp[$i]);
				$SDatatmp{$i} = $Buftmp[0];
			}

			@SortDatatmp = sort {($SDatatmp{$b} <=> $SDatatmp{$a}) || ($b cmp $a)} keys(%SDatatmp);
			$lno = $linestmp[$SortDatatmp[0]] +1;

			srand;
			$bclines = $#bonuscharas +1;
			$tmpsel = int(rand($bclines));
			$bonuscharas[$tmpsel] =~ s/Bonus/$lno/g;
			$bonusc = $bonuscharas[$tmpsel];
			@Buftmp = split('<>', $bonusc);
			$bonuszumi = 0;
			for ($i=0; $i<$#chara +1; $i++){					
				($no[$i], $name[$i], $sakusya[$i], $homepage[$i], $lif[$i], $look[$i], $kind[$i], $spe[$i], $date[$i], $ip[$i], $love1[$i], $plus1[$i], $plus2[$i], $plus3[$i], $plus4[$i], $plus5[$i], $old[$i], $imgtype[$i], $job[$i], $love2[$i], $sex[$i],$love3[$i],$entrypass[$i],$mail[$i],$mailopen[$i],$rideonmail[$i],$sendstory[$i],$dmy) = split(/<>/,$chara[$i]);
				if($name[$i] eq $Buftmp[1]){$bonuszumi = 1;last;}
			}
			if($bonuszumi == 0){push(@chara,$bonusc);}
			$times2[6] = "0\n";
		}

		open(DB,">$logfile") ;
			print DB @chara;
			eval 'flock(DB,8);';
		close(DB);

		#Ŀ�� ������ ����
		($mno, $mname, $msakusya, $mhomepage, $mlif, $mlook, $mkind, $mspe, $mdate, $mip, $mlove1, $mplus1, $mplus2, $mplus3, $mplus4, $mplus5, $mold, $mimgtype, $mjob, $mlove2, $msex,$mlove3,$mentrypass,$mmail,$mmailopen,$mrideonmail,$msendstory,$dmy) = split(/<>/,$cpman);
		($wno, $wname, $wsakusya, $whomepage, $wlif, $wlook, $wkind, $wspe, $wdate, $wip, $wlove1, $wplus1, $wplus2, $wplus3, $wplus4, $wplus5, $wold, $wimgtype, $wjob, $wlove2, $wsex,$wlove3,$wentrypass,$wmail,$wmailopen,$wrideonmail,$wsendstory,$dmy) = split(/<>/,$cpwman);
		open(CP,"$couplefile");
		eval 'flock(CP,2);';
		seek(CP,0,0);  @couple = <CP>; close(CP);

		#Ŀ�� ��ȣ�� ���ĸ� �����Ѵ�
		open(DBTMP,"$couplefile");
		seek(DBTMP,0,0);  @couple = <DBTMP>;  close(DBTMP);
		foreach $i (0..(@couple-1)) {
		@Buftmpt = split('<>', @couple[$i]);
		$SDatatmpt{$i} = $Buftmpt[26];
		}
		@SortDatatmpt = sort {($SDatatmpt{$b} <=> $SDatatmpt{$a}) || ($b cmp $a)} keys(%SDatatmpt);
		$cpno = $couple[$SortDatatmpt[26]] +1;

		$clog="$cpno<>$mno<>$mname<>$msakusya<>$mhomepage<>$mlif<>$mlook<>$mkind<>$mspe<>$mdate<>$manlove<>$mold<>$mimgtype<>$mjob<>$wno<>$wname<>$wsakusya<>$whomepage<>$wlif<>$wlook<>$wkind<>$wspe<>$wdate<>$wmanlove<>$wold<>$wimgtype<>$wjob<>$jikan2\n";
		unshift (@couple , join('' , $clog));
		splice( @couple, $max_couple);
	
		open(CP,">$couplefile") ;
			print CP @couple;
			eval 'flock(CP,8);';
		close(CP);

		if($abiyause == 1){$syokinlog = "$jikan2 <b>�Ұ���$msakusya����$wsakusya���� ����� ��Ʈ �߽��ϴ�. </b><br>";}
		$log = "$jikan2 <font color=$ugokucol>$ugokuhito</font>��<font color=$targetcol>$targethito</font>���� �̺��� ���ϰ� $wagon�� ������ �������� ��ǥ�� �Ѵ�. <br>$syokinlog\n";

		#ť�ǵ� ������ ����
		open(RK,"$rankfile");
		eval 'flock(RK,2);';
		seek(RK,0,0);  @rank = <RK>; close(RK);
		for ($i=0; $i<$#rank +1; $i++){
			($sakusya, $hp, $entry, $goal, $entrytime, $hyjtime) = split(/<>/,$rank[$i]);
			if($msakusya eq $sakusya){
				$goal = $goal+1;
			}
			if($wsakusya eq $sakusya){
				$goal = $goal+1;
			}
			$tmpline = "$sakusya<>$hp<>$entry<>$goal<>$entrytime<>$hyjtime";
			if(($entrytime+ (60*60*24*$cutday)) > $timemin){
				splice(@rank,$i,1,$tmpline);
			}else{
				splice(@rank,$i,1);
			}
		}	

		#���� ����
		if($abiyause == 1){#������ ���� ������ ������ �߰�
			open(SAIFU,"$osaifufile") || print "Content-type: text/html\n\n$osaifufile�� ������ �ʾҽ��ϴ�";
			seek(SAIFU,0,0) ;@saifu = <SAIFU>;close(SAIFU);
			for ($ii=0; $ii<$#saifu+1; $ii++){
				($oname, $ocount,$odate,$ohost,$oraitenkaisu,$osankaimg,$opw,$intime2,$jikan2,$totaltime2,$llwgn,$abicorp,$vboss,$mahjong,$dmy1,$dmy2,$dmy3,$dmy4) = split(/<>/, $saifu[$ii]);
				if($msakusya eq $oname){
					if($wip  eq "b"){$couplesyokin = $bcharasyokin;}
					$ocounttmp = $couplesyokin / 10000;
					$ocount = $ocount + $couplesyokin;
					$llwgn = $llwgn + int($ocounttmp);
					$newline = "$oname<>$ocount<>$odate<>$ohost<>$oraitenkaisu<>$osankaimg<>$opw<><>$jikan2<>$totaltime2<>$llwgn<>$abicorp<>$vboss<>$mahjong<>$dmy1<>$dmy2<>$dmy3<>\n";
					splice(@saifu,$ii,1,$newline);
				}
				if($wsakusya eq $oname){
					if($mip eq "b"){$couplesyokin = $bcharasyokin;}
					$ocounttmp = $couplesyokin / 10000;
					$ocount = $ocount + $couplesyokin;
					$llwgn = $llwgn + int($ocounttmp);
					$newline = "$oname<>$ocount<>$odate<>$ohost<>$oraitenkaisu<>$osankaimg<>$opw<><>$jikan2<>$totaltime2<>$llwgn<>$abicorp<>$vboss<>$mahjong<>$dmy1<>$dmy2<>$dmy3<>\n";
					splice(@saifu,$ii,1,$newline);
				}
			}

			if($abiyafilelockuse ==1){&abiyalock;}
			open(SAIFU,">$osaifufile");seek(SAIFU,0,0);print SAIFU @saifu;close(SAIFU);
			if (-e,$abiyalockfile){unlink($abiyalockfile);}

		}
		

		#���������� �ټ� �ٲ۴�
		foreach $i (0..($#rank +1)) {
		@Buf = split('<>', @rank[$i]);
		$SDataten{$i} = $Buf[3];
		}

		@SortDataten = sort {($SDataten{$b} <=> $SDataten{$a}) || ($b cmp $a)} keys(%SDataten);
		foreach $i (@SortDataten) {
		push(@newrank,$rank[$i]);
		}

		open(RK,">$rankfile") ;
			print RK @newrank;
			eval 'flock(RK,8);';
		close(RK);

		$stcode=90;
	}elsif($times2[4] == 90){#��91 ����(���� �̵� ó��)
		open(CN,"$countryfile");
		seek(CN,0,0);  @country = <CN>; close(CN);
		if($times2[5] < $#country){
			$times2[5] = $times2[5] +1;
			$times2[5] = "$times2[5]\n";
		}else{
			$times2[5] = "0\n";
		}
		$countryno = $times2[5];
		$country = $country[$countryno];
		$log = "$jikan2 $wagon(��)�� ���� <font color=green>$country</font>�� �Ա��ߴ�. <br>\n";

		$stcode=16;
	}elsif($times2[4] == 16){#��15 ����( �Ÿ�� �߰� ó��)
		for ($morw=0; $morw<2; $morw++){
			if($morw==0){
				for ($i=0; $i<6; $i++){
					if($no[$i] eq "-"){
						$retiresex=$sex[$i];
						$retireline=$i;
						last;
					}
				}
			}else{
				if($newmember != 1){
					for ($i=3; $i<6; $i++){
						if($no[$i] eq "-"){
							$retiresex=$sex[$i];
							$retireline=$i;
							last;
						}
					}
				}else{
					last;
				}
			}
			for ($i=6; $i<$#chara +1; $i++){
				($no[$i], $name[$i], $sakusya[$i], $homepage[$i], $lif[$i], $look[$i], $kind[$i], $spe[$i], $date[$i], $ip[$i], $love1[$i], $plus1[$i], $plus2[$i], $plus3[$i], $plus4[$i], $plus5[$i], $old[$i], $imgtype[$i], $job[$i], $love2[$i], $sex[$i],$love3[$i],$entrypass[$i],$mail[$i],$mailopen[$i],$rideonmail[$i],$sendstory[$i],$dmy) = split(/<>/,$chara[$i]);
				if($sex[$i] eq $retiresex){#������ ������
					if($sex[$i] eq "m"){
						$newmemcol="6666FF";
						srand;$ep1 = int(rand($firstimp));
						srand;$ep2 = int(rand($firstimp));
						srand;$ep3 = int(rand($firstimp));
						if($look[3] ne "-"){$love1[$i]=$look[3]+$ep1;}
						if($look[4] ne "-"){$love2[$i]=$look[4]+$ep2;}
						if($look[5] ne "-"){$love3[$i]=$look[5]+$ep3;}
						if($retireline==0){
							if($love1[3] ne "-"){$love1[3]=$look[$i]+$ep1;}
							if($love1[4] ne "-"){$love1[4]=$look[$i]+$ep2;}
							if($love1[5] ne "-"){$love1[5]=$look[$i]+$ep3;}
						}elsif($retireline==1){
							if($love2[3] ne "-"){$love2[3]=$look[$i]+$ep1;}
							if($love2[4] ne "-"){$love2[4]=$look[$i]+$ep2;}
							if($love2[5] ne "-"){$love2[5]=$look[$i]+$ep3;}
						}elsif($retireline==2){
							if($love3[3] ne "-"){$love3[3]=$look[$i]+$ep1;}
							if($love3[4] ne "-"){$love3[4]=$look[$i]+$ep2;}
							if($love3[5] ne "-"){$love3[5]=$look[$i]+$ep3;}
						}
					}elsif($sex[$i] eq "w"){
						$newmemcol="FF6666";
						srand;$ep1 = int(rand($firstimp));
						srand;$ep2 = int(rand($firstimp));
						srand;$ep3 = int(rand($firstimp));
						if($look[0] ne "-"){$love1[$i]=$look[0]+$ep1;}
						if($look[1] ne "-"){$love2[$i]=$look[1]+$ep2;}
						if($look[2] ne "-"){$love3[$i]=$look[2]+$ep3;}
						if($retireline==3){
							if($love1[0] ne "-"){$love1[0]=$look[$i]+$ep1;}
							if($love1[1] ne "-"){$love1[1]=$look[$i]+$ep2;}
							if($love1[2] ne "-"){$love1[2]=$look[$i]+$ep3;}
						}elsif($retireline==4){
							if($love2[0] ne "-"){$love2[0]=$look[$i]+$ep1;}
							if($love2[1] ne "-"){$love2[1]=$look[$i]+$ep2;}
							if($love2[2] ne "-"){$love2[2]=$look[$i]+$ep3;}
						}elsif($retireline==5){
							if($love3[0] ne "-"){$love3[0]=$look[$i]+$ep1;}
							if($love3[1] ne "-"){$love3[1]=$look[$i]+$ep2;}
							if($love3[2] ne "-"){$love3[2]=$look[$i]+$ep3;}
						}
					}
					$dmy =~ s/\n//g;
					$chara[$i]="$no[$i]<>$name[$i]<>$sakusya[$i]<>$homepage[$i]<>$lif[$i]<>$look[$i]<>$kind[$i]<>$spe[$i]<>$date[$i]<>$ip[$i]<>$love1[$i]<>$plus1[$i]<>$plus2[$i]<>$plus3[$i]<>$plus4[$i]<>$plus5[$i]<>$old[$i]<>$imgtype[$i]<>$job[$i]<>$love2[$i]<>$sex[$i]<>$love3[$i]<>$entrypass[$i]<>$mail[$i]<>$mailopen[$i]<>$rideonmail[$i]<>$sendstory[$i]<>$dmy\n";
					$chara[$retireline]=$chara[$i];
					splice(@chara,$i,1);
					$log = "$jikan2 ���ú��� ���ο� ȸ�� <font color=$newmemcol>$name[$i]</font>(��)�� ��������. <br>\n";
					if($rideonmail[$i] == 1 && $mail[$i]){
						$mailtitle = $rideonmailtitle;
						$comment = $rideonmailcomment;
						$mail = $mail[$i];
						$name = $sakusya[$i];
						$curchara =$name[$i];
						&mail_to;
					}
					$newmember = 1;
					for ($i=0; $i<6; $i++){
						if($i==$retireline){
							$chara[$i]=$chara[$retireline];
						}else{
							$dmy =~ s/\n//g;
							$chara[$i]="$no[$i]<>$name[$i]<>$sakusya[$i]<>$homepage[$i]<>$lif[$i]<>$look[$i]<>$kind[$i]<>$spe[$i]<>$date[$i]<>$ip[$i]<>$love1[$i]<>$plus1[$i]<>$plus2[$i]<>$plus3[$i]<>$plus4[$i]<>$plus5[$i]<>$old[$i]<>$imgtype[$i]<>$job[$i]<>$love2[$i]<>$sex[$i]<>$love3[$i]<>$entrypass[$i]<>$mail[$i]<>$mailopen[$i]<>$rideonmail[$i]<>$sendstory[$i]<>$dmy\n";
						}
						splice(@chara,$i,1,$chara[$i]);
					}	
					last;
				}
			}
		}		
		
		open(DB,">$logfile") ;
			eval 'flock(DB,2);';
			print DB @chara;
			eval 'flock(DB,8);';
		close(DB);
		$stcode=5;
	}
	#���丮 ������ ����
	open(ST,"$storyfile");
	eval 'flock(ST,2);';
	seek(ST,0,0);  @story = <ST>; close(ST);

	unshift (@story , join('' , $log));
	splice( @story, $max_story);

	open(ST,">$storyfile") ;
		print ST @story;
		eval 'flock(ST,8);';
	close(ST);


	# �ð� ������ ����
	if ($between){$times2 = int($timemin/$between);}
	@t=();
	push(@t,"$times2\n$times\n$ugokuno\n$targetno\n$stcode\n$times2[5]$times2[6]");
	open(KTM,">$ktimefile") ;
		eval 'flock(KTM,2);';
		seek(KTM,0,0);	print KTM @t;
		eval 'flock(KTM,8);';
	close(KTM);

	#���� �۽�
	if($stcode == 16 && $ritsendstoryline >= 1 && $ritmail){
			$sendstoryline = $ritsendstoryline;
			$mailtitle = $storymailtitle;
			$comment = $storymailcomment;
			$mail = $ritmail;
			$name = $ritname;
			$curchara = $ritcurchara;
			&mail_to;
	}
	if($stcode == 90){
		if($msendstory >= 1 && $mmail){
			$sendstoryline = $msendstory;
			$mailtitle = $storymailtitle;
			$comment = $storymailcomment;
			$mail = $mmail;
			$name = $msakusya;
			$curchara = $mname;
			&mail_to;
		}
		if($wsendstory >= 1 && $wmail){
			$sendstoryline = $wsendstory;
			$mailtitle = $storymailtitle;
			$comment = $storymailcomment;
			$mail = $wmail;
			$name = $wsakusya;
			$curchara = $wname;
			&mail_to;
		}
	}

}#end syori


##### ĳ���� ��� ó��

sub record{
open(DB,"$logfile");
seek(DB,0,0);  @lines = <DB>;  close(DB);

if($lines[${smax_chara}-1]){&error(0);} #ĳ���Ͱ� �����ϸ�(��) ƨ���

# ������ �Űܳ��´�
	$formchara = $form{'chara'};
	$formname = $form{'name'};
	$formentrypass = $form{'entrypass'};
	$formhp = $form{'hp'};
	$formmail = $form{'mail'};
	$formlif = $form{'life'};
	$formlook = $form{'look'};
	$formkind = $form{'kind'};
	$formspe = $form{'speed'};
	$formold = $form{'old'};
	$formjob = $form{'job'};
	if($form{'imode'} eq "f"){
		$formsex = $form{'sex'};
		$formimg = $form{'ficon'};
	}elsif($form{'imode'} ne "f"){
		$formimg = $form{'img'};#ǥ�� �̹����� �����ϸ�(��) ������ �ڵ� ����
		if($form{'img'} eq "$imgfld/$imgfile[0]"){$formsex = "m";}
		if($form{'img'} eq "$imgfld/$imgfile[1]"){$formsex = "m";}
		if($form{'img'} eq "$imgfld/$imgfile[2]"){$formsex = "m";}
		if($form{'img'} eq "$imgfld/$imgfile[3]"){$formsex = "m";}
		if($form{'img'} eq "$imgfld/$imgfile[4]"){$formsex = "m";}
		if($form{'img'} eq "$imgfld/$imgfile[5]"){$formsex = "m";}
		if($form{'img'} eq "$imgfld/$imgfile[6]"){$formsex = "w";}
		if($form{'img'} eq "$imgfld/$imgfile[7]"){$formsex = "w";}
		if($form{'img'} eq "$imgfld/$imgfile[8]"){$formsex = "w";}
		if($form{'img'} eq "$imgfld/$imgfile[9]"){$formsex = "w";}
		if($form{'img'} eq "$imgfld/$imgfile[10]"){$formsex = "w";}
		if($form{'img'} eq "$imgfld/$imgfile[11]"){$formsex = "w";}
	}

# �ɷ�ġ üũ
	if(($formlook >100)||($formlook < 5)){&error(1)};
	if(($formkind >100)||($formkind < 5)){&error(1)};
	if(($formspe >100)||($formspe < 5)){&error(1)};
	if(($formlif >100)||($formlif < 5)){&error(1)};
	$pointtotal = $formlook + $formkind + $formspe + $formlif ;
	if($pointtotal ne 100){&error(2)};

# �̸��� ���� üũ
	if((length($formchara) < 1)||(length($formchara) > $nameleng *2)){&error(3)};
	if((length($formname) < 1)||(length($formname) > $nameleng *2)){&error(3)};
	if((length($formjob) < 1)||(length($formjob) > $nameleng *2)){&error(5)};
	if(length($form{'plus1'}) < 1){&error(6)};
	if(length($form{'plus2'}) < 1){&error(6)};
	if(length($form{'plus3'}) < 1){&error(6)};
	if(length($form{'plus4'}) < 1){&error(6)};
	if(length($form{'plus5'}) < 1){&error(6)};
	if($formhp =~ /http/){
		($formhp =~ /^http:\/\/[a-zA-Z0-9]+/) || ($formhp = '');	#HP�� ����
	}else{
		$formhp = '';
	}
	if($formmail =~ /@/){
		if($formmail !~ /mailto/){
			$formmail = "mailto:$formmail"
		}
		$formmailopen  = $form{'mailopen'};
		$formrideonmail  = $form{'rideonmail'};
		$formsendstory  = $form{'sendstory'};
	}else{
		$formmail = '';
		$formmailopen = 0;
		$formrideonmail  = 0;
		$formsendstory  = 0;
	}

# ����Ʈ ȣ��Ʈ ���
	$host = $ENV{'REMOTE_ADDR'};
	if($doubleentry == 1){
		@checkip = split(/<>/,$lines[$#lines]);
		if($host eq $checkip[9]){&error(4);} 
	}elsif($doubleentry == 2){
		for ($i=0; $i<$#lines +1; $i++){
			@checkip = split(/<>/,$lines[$i]);
			if($host eq $checkip[9]){&error(7);} #IP�ּҿ����� ��
			if($formname eq $checkip[2]){&error(7);} #�̸������� ��
		}
	}

#���� ���� �ο����� Ȯ��
	$m=0;$w=0;
	for ($i=0; $i<$#lines +1; $i++){
		@checksex = split(/<>/,$lines[$i]);
		if($checksex[20] eq "m"){$m++;}
		else{$w++;}
		if($w>=$maxw && $formsex eq "w"){&error(8);} 
		if($m>=$maxm && $formsex eq "m"){&error(9);} 
	}


# ����� ó��

	if($formsex eq "m"){
		$serifucol="6666FF"
	}else{
		$serifucol="FF6666"
	}
	if($form{'plus1'}){$formplus1 = qq|<font color=$serifucol>$formchara</font>��$form{'plus1'}��<BR>|;}
	if($form{'plus2'}){$formplus2 = qq|<font color=$serifucol>$formchara</font>��$form{'plus2'}��<BR>|;}
	if($form{'plus3'}){$formplus3 = qq|<font color=$serifucol>$formchara</font>��$form{'plus3'}��<BR>|;}
	if($form{'plus4'}){$formplus4 = qq|<B><font color=$serifucol>$formchara</font>��$form{'plus4'}��</B><BR>|;}
	if($form{'plus5'}){$formplus5 = qq|<B><font color=$serifucol>$formchara</font>��$form{'plus5'}��</B><BR>|;}

	if($formsex eq ""){$formsex = "m";}

# �����信 ����� ��ǥ��

	$recflag = '1';

}#end record

#####���۱� ǥ��

sub chosaku{
$viewbr = "Win InternetExplorer6,Win Mozilla<br>Mac InternetExplorer5";
&secretcopyright;
print <<"_CHOSAKU_";

<hr size="1">
<table width=100%><tr><td style="font-size: 10pt;color: #9b9b9b;">Check environment of operation<br>$viewbr</td>
<td><div align="right"><a href="http://www.abi-station.com/" target="_top"><font size="2">���� ���� ���� ver2. 50(Free)<br><img src="$imgfld/banner.gif" width="88" height="31" border="0"></a> <br>
<a href="http://www.grn.mmtr.or.jp/~dabo/" target="_top">����������/��Ʋ �ο� ver1. 10(Free)</font></a> <br>
<a href="http://www.x2-dr.com/" target="_blank"><font size="2">X2-DR.com ������ Ŀ�´�Ƽ : �ѱ��� ����</font></a><br>
</div></td></tr></table>
$footbanner
</body>
</html>
_CHOSAKU_

}#end chosaku


sub ssi{
	open(DB,"$logfile");
	seek(DB,0,0);  @chara = <DB>;  close(DB);
	print "Content-type: text/html\n\n";
	for ($i=0; $i<6; $i++){
		($no[$i], $name[$i], $sakusya[$i], $homepage[$i], $lif[$i], $look[$i], $kind[$i], $spe[$i], $date[$i], $ip[$i], $love1[$i], $plus1[$i], $plus2[$i], $plus3[$i], $plus4[$i], $plus5[$i], $old[$i], $imgtype[$i], $job[$i], $love2[$i], $sex[$i],$love3[$i],$entrypass[$i],$mail[$i],$mailopen[$i],$rideonmail[$i],$sendstory[$i],$dmy) = split(/<>/,$chara[$i]);
		if($no[$i] && $no[$i] ne "-"){
			if($profileuse && $sakusya[$i] ne "-"){
				local($edname) = &urlencode($sakusya[$i]);
				$sakusya[$i] = "<a href=\"$profileurl?mode=view&name=$edname\">$sakusya[$i]</a>";
			}
			print "<img src=\"$imgtype[$i]\" width=\"26\" height=\"26\"><font size=\"1\">$name[$i] by$sakusya[$i],</font>";
		}
	}
}

##### ���
sub html{

	if ($title){$comment = "<BR><BR>$comment";}
	open(BOOK,"$storyfile");
	seek(BOOK,0,0);  @story = <BOOK>;  close(BOOK);
	@topst = ();
	for ($i=0; $i<$topstline; $i++){
		push(@topst,$story[$i])
	}

	open(CN,"$countryfile");
	seek(CN,0,0);  @country = <CN>; close(CN);
	$countryno = $times2[5];
	$oncountry = $country[$countryno];
	
	$interval = int((86400 / $storyshisu));#���� ���͹�
	
	$entrycnt = $#chara -5;
	if($entrycnt < 0){$entrycnt = 0;}

	$canentry = $max_chara - $entrycnt;
	if($abiyause == 1){
		$edit_a = &addcamma($couplesyokin);
		$abiyahowto = "�� Ŀ�� �������� ���$edit_a����Ʈ! <br>";
		if($bo == 1){
			$edit_b = &addcamma($bcharasyokin);
			$abiyabhowto = "�� ���ʽ� ĳ����(���� ���� �۾� ĳ����)�� Ŀ�� �������� ���$edit_b����Ʈ! <br>";
		}
		$abiyasetumei = "�� �����<a href=$abiya_url target=_$abiya_name>$abiya_name</a> �� ������ �ݿ��˴ϴ�. <br>";
	}

	&get_cookie;

	if($COOKIE{'reload'} eq "�ڵ�"){
		$reloadtag = "����� �ڵ� ���� ����Դϴ�. <br><input type=\"hidden\" name=\"reload\" value=\"����\"><input type=submit value=���� ���� ���� ��ȯ�Ѵ�>";
		$reloadflg = 1;
	}elsif($form{'reload'} eq "�ڵ�"){
		$reloadtag = "����� �ڵ� ���� ����Դϴ�. <br><input type=\"hidden\" name=\"reload\" value=\"����\"><input type=submit value=���� ���� ���� ��ȯ�Ѵ�>";
		$reloadflg = 1;
	}elsif($form{'reload'} eq "�ڵ� ���� ���� ��ȯ�Ѵ�"){
		$reloadtag = "����� �ڵ� ���� ����Դϴ�. <br><input type=\"hidden\" name=\"reload\" value=\"����\"><input type=submit value=���� ���� ���� ��ȯ�Ѵ�>";
		$reloadflg = 1;
	}elsif($form{'reload'} eq "���� ���� ���� ��ȯ�Ѵ�"){
		$reloadtag = "����� ���� ���� ����Դϴ�. <br><input type=\"hidden\" name=\"reload\" value=\"�ڵ�\"><input type=submit value=�ڵ� ���� ���� ��ȯ�Ѵ�>";
		$reloadflg = 0;
	}else{
		$reloadtag = "����� ���� ���� ����Դϴ�. <br><input type=\"hidden\" name=\"reload\" value=\"�ڵ�\"><input type=submit value=�ڵ� ���� ���� ��ȯ�Ѵ�>";
		$reloadflg = 0;
	}
	
if($ENV{'HTTP_ACCEPT_ENCODING'}=~/gzip/ && $gzipuse){
	print "Content-type: text/html\n";
	print "Content-encoding: gzip\n\n";
	open(STDOUT,"| $gzippass -1 -c");
}else{
	print "Content-type: text/html\n\n";
}

print <<"_HTML1_";
<html><head><title>$title2</title><META HTTP-EQUIV="Content-type" CONTENT="text/html; charset=euc">
$style
_HTML1_
if($reloadflg==1){print"<META HTTP-EQUIV='Refresh' CONTENT='$interval';URL=\"$cgifile\">";}
print <<"_HTML1_";
</head>
$body
$menu
$headbanner
<center><br>
<img src=\"$title\" width=\"$titlew\" height=\"$titleh\"><br>
<br>
<form action="$cgifile" method="$method">
$tablefuchitag1<table border="1" cellpadding="3" bordercolor="$flamecol" bordercolordark="$flamecol" bordercolorlight="$flamecol" bgcolor="$flamecol">
	<tr bgcolor="$iroformwaku">
		<td align="center">
			<input type="submit" name="rec" value="$mesrec">
			<input type="submit" name="couple" value="$mescouple">
			<input type="submit" name="rank" value="$mesrank">
			<input type="button" value="$meshome" onClick="location.href='$url'">
		</td>
	</tr>
</table>$tablefuchitag2
</form>
<form action="$cgifile" method="$method">
<input type="hidden" name="chara" value="$COOKIE{'charaa'}">
<input type="hidden" name="name" value="$COOKIE{'namea'}">
<input type="hidden" name="entrypass" value="$COOKIE{'entrypassa'}">
<input type="hidden" name="hp" value="$COOKIE{'hpa'}">
<input type="hidden" name="mail" value="$COOKIE{'maila'}">
<input type="hidden" name="mailopen" value="$COOKIE{'mailopena'}">
<input type="hidden" name="rideonmail" value="$COOKIE{'rideonmaila'}">
<input type="hidden" name="sendstory" value="$COOKIE{'sendstorya'}">
<input type="hidden" name="life" value="$COOKIE{'lifea'}">
<input type="hidden" name="speed" value="$COOKIE{'speeda'}">
<input type="hidden" name="kind" value="$COOKIE{'kinda'}">
<input type="hidden" name="look" value="$COOKIE{'looka'}">
<input type="hidden" name="old" value="$COOKIE{'olda'}">
<input type="hidden" name="job" value="$COOKIE{'joba'}">
<input type="hidden" name="sex" value="$COOKIE{'sexa'}">
<input type="hidden" name="img" value="$COOKIE{'imga'}">
<input type="hidden" name="reloadent" value="1">
$reloadtag
</form>
  <table border="0" cellspacing="0" cellpadding="5">
    <tr>
      <td>$tablefuchitag1<img src=$ruleimg width=$rulew height=$ruleh>$tablefuchitag2
        <div style="font-size:80%;line-height:130%">
	<font color=red>�� �̰����� �߸� �����Դϴ�, �ڱⰡ �߸��ڰ� �Ǿ� �󸶳� ���� ������� �����ֳ� ���Ѻ��� �����Դϴ�<br>
	�� <b>��! ���ڴ� ���� ĳ����, ���ڴ� ���� ĳ���͸� �������ּ��� �ȱ׷� �̻����ݾ� ^^;;</b></font><br>
	�� ���� ���� , �� ����̶�� �����Ǵ� �̼��� �������� �ѱ����� ���ư���$ticket�� �ǳ��ָ� ����!<br>
        �� ����ްԵǸ�, �Ϸ絿�� ������ ������ OK��� Ű��! NO���$ticket�� �����ش�! <br>
        �� Ŀ�� ������ �Ǹ� 2���� �ѱ� �ͱ� ! ���̸� ȥ�ڼ� �ͱ�! <br>
        �� �����ϰ� �� �ο��� ���߿� ���ο� ȸ���� ���� ! <br>
        �� $max_chara�� �̻��� ���� �� �� �����ϴ�! <br>$abiyahowto$abiyabhowto$abiyasetumei
_HTML1_
if($reloadflg==1){print"�� �������� ���� ������, ���丮�� ��ü��$interval�� �ɷ��� �����մϴ�! ";}
print <<"_HTML1_";
		</div> </td>
    </tr>
  </table>
  <br>
  $tablefuchitag1<table cellpadding="5" border="1" cellspacing="0" bordercolor="$stflamecol" bordercolordark="$stflamecol" bordercolorlight="$stflamecol" bgcolor="$stbgcol">
    <tr><td bgcolor="$headcol" background=$tableheadimg align=center> << ���ݱ����� ���� >> </td></tr>
	<tr>
      <td style="line-height:130%">������ ���� <font color=green>$oncountry</font><br><br>@topst<br>
_HTML1_
if($#story>$topstline){print"<a href=\"$cgifile?story=storyv\" target=\"_blank\">�� �� ���� ���並 ����</a> ";}
print <<"_HTML1_";
	  </td>
    </tr>
  </table>$tablefuchitag2
  <br>
$tablefuchitag1$tablehead

_HTML1_

open(DB,"$logfile");
seek(DB,0,0);  @chara = <DB>;  close(DB);

	for ($i=0; $i<6; $i++){
		($no[$i], $name[$i], $sakusya[$i], $homepage[$i], $lif[$i], $look[$i], $kind[$i], $spe[$i], $date[$i], $ip[$i], $love1[$i], $plus1[$i], $plus2[$i], $plus3[$i], $plus4[$i], $plus5[$i], $old[$i], $imgtype[$i], $job[$i], $love2[$i], $sex[$i],$love3[$i],$entrypass[$i],$mail[$i],$mailopen[$i],$rideonmail[$i],$sendstory[$i],$dmy) = split(/<>/,$chara[$i]);
		if($profileuse && $sakusya[$i] ne "-"){
			local($edname) = &urlencode($sakusya[$i]);
			$sakusya[$i] = "<a href=\"$profileurl?mode=view&name=$edname\">$sakusya[$i]</a> ";
		}
		if($homepage[$i]){
			$hp[$i] = "[<a href=\"$homepage[$i]\">HOME</a>]";
		}else{
			$hp[$i] = ""
		}
		if($mail[$i] && $mailopen[$i] == 1){
			$ml[$i] = "[<a href=\"$mail[$i]\">MAIL</a>]";
		}else{
			$ml[$i] = "";
		}
	}

	for ($i=0; $i<6; $i++){
		if($i < 3){$temp1=3;$temp2=4;$temp3=5;$col1="#0000CC";$col2="#6666FF";$col3="#9999FF";}
		else{$temp1=0;$temp2=1;$temp3=2;$col1="#CC0000";$col2="#FF6666";$col3="#FF9999";}

	print "<tr bgcolor=$datacol><td align=right rowspan=2 background=$tabledataimg2>$no[$i]</td><td align=center rowspan=2 background=$tabledataimg2><img src=$imgtype[$i] width=26 height=26></td><td rowspan=2 background=$tabledataimg2>$name[$i]</td><td  rowspan=2 background=$tabledataimg2>$sakusya[$i] $hp[$i] $ml[$i]</td><td align=right background=$tabledataimg>$old[$i]</td><td background=$tabledataimg>$job[$i]</td><td align=right background=$tabledataimg>$spe[$i]</td><td align=right background=$tabledataimg>$look[$i]</td><td align=right background=$tabledataimg>$kind[$i]</td><td align=right background=$tabledataimg>$lif[$i]</td></tr><tr bgcolor=$datacol nowrap><td align=right colspan=6 background=$tabledataimg><div align=left><table border=0 cellspacing=0 cellpadding=0><tr valign=middle><td rowspan=2>$tablelove</td><td nowrap><div align=right><font size=1>$name[$temp1]</font></div></td><td rowspan=2><img src=$imgtype[$temp1] width=26 height=26></td><td></td><td nowrap><div align=right><font size=1>$name[$temp2]</font></div></td><td rowspan=2><img src=$imgtype[$temp2] width=26 height=26></td><td></td><td nowrap><div align=right><font size=1>$name[$temp3]</font></div></td><td rowspan=2><img src=$imgtype[$temp3] width=26 height=26></td><td></td></tr><tr valign=middle><td width=50><div align=right><font color=$col1>$love1[$i]\></font><font color=$col2>\></font><font color=$col3>\></font></div></td><td></td><td width=50><div align=right><font color=$col1>$love2[$i]\></font><font color=$col2>\></font><font color=$col3>\></font></div></td><td></td><td width=50><div align=right><font color=$col1>$love3[$i]\></font><font color=$col2>\></font><font color=$col3>\></font></div></td><td></td></tr></table></div></td></tr>";

	}
	  print "</table>$tablefuchitag2<br>";	

$m=0;$w=0;
for ($i=0; $i<$#chara +1; $i++){
	@checksex = split(/<>/,$chara[$i]);
	if($checksex[20] eq "m"){$m++;}
	else{$w++;}
}
if($m>=$maxm){
	$entrym = "������ �� �̻� ����� �� �����ϴ�";
}elsif ($m<$maxm){
#	$m = $maxm - $m;
	$entrym = "���� ��ϰ���";
}
if($w>=$maxw){
	$entryw = "������ �� �̻� ����� �� �����ϴ�";
}elsif($w<$maxw){
#	$w = $maxw - $w;
	$entryw = "���� ��ϰ���";
}

	$m = $m-3;$w = $w-3;

if($canentry > 0){
	  print "<center>������ ��ٸ��� �е� $entrycnt��(����$m:���� $w) <font size=2>($entrym , $entryw)</font></center><br>";
}else{
	  print "<center>������ ��ٸ��� �е� $entrycnt�� <font size=2 color=red>(�� �̻� ����� �� �����ϴ�)</font></center><br>";
}
	  print "$tablefuchitag1$tablehead2";

	for ($i=6; $i<$#chara+1; $i++){
		($no[$i], $name[$i], $sakusya[$i], $homepage[$i], $lif[$i], $look[$i], $kind[$i], $spe[$i], $date[$i], $ip[$i], $love1[$i], $plus1[$i], $plus2[$i], $plus3[$i], $plus4[$i], $plus5[$i], $old[$i], $imgtype[$i], $job[$i], $love2[$i], $sex[$i],$love3[$i],$entrypass[$i],$mail[$i],$mailopen[$i],$rideonmail[$i],$sendstory[$i],$dmy) = split(/<>/,$chara[$i]);
		local($edname) = &urlencode($sakusya[$i]);
		if($profileuse && $sakusya[$i] ne "-"){$sakusya[$i] = "<a href=\"$profileurl?mode=view&name=$edname\">$sakusya[$i]</a> "}
		if($homepage[$i]){
			$hp[$i] = "[<a href=\"$homepage[$i]\">HOME</a>]"
		}else{
			$hp[$i] = ""
		}
		if($mail[$i] && $mailopen[$i] == 1){
			$ml[$i] = "[<a href=\"$mail[$i]\">MAIL</a>]"
		}else{
			$ml[$i] = ""
		}
		if($sex[$i] eq "m"){$sex = "��";}else{$sex = "��";}
		print "<tr bgcolor=$datacol nowrap><td align=right background=$tabledataimg>$no[$i]</td><td align=center background=$tabledataimg><img src=$imgtype[$i] width=26 height=26></td><td background=$tabledataimg>$name[$i]</td><td background=$tabledataimg>$sakusya[$i] $hp[$i] $ml[$i]</td><td align=right background=$tabledataimg>$old[$i]</td><td align=center background=$tabledataimg>$sex</td><td background=$tabledataimg>$job[$i]</td><td align=right background=$tabledataimg>$spe[$i]</td><td align=right background=$tabledataimg>$look[$i]</td><td align=right background=$tabledataimg>$kind[$i]</td><td align=right background=$tabledataimg>$lif[$i]</td></tr>";
	}

print <<"_HTML2_";

        </table>$tablefuchitag2
<form action="$cgifile" method="$method">
$tablefuchitag1<table border="1" cellpadding="3" bordercolor="$flamecol" bordercolordark="$flamecol"
bordercolorlight="$flamecol" bgcolor="$flamecol">
            <tr bgcolor="$iroformwaku">
              <td> 
                <div align="center">
                  <input type="submit" name="rec" value="$mesrec">
                  <input type="submit" name="couple" value="$mescouple">
                  <input type="submit" name="rank" value="$mesrank">
                  <input type="button" value="$meshome" onClick="location.href='$url'">
                </div>
              </td></tr></table>$tablefuchitag2
</form>
<form action="$cgifile" method="$method">
$tablefuchitag1<table border="1" cellpadding="3" bordercolor="$flamecol" bordercolordark="$flamecol"
bordercolorlight="$flamecol" bgcolor="$flamecol">
            <tr bgcolor="$iroformwaku">
              <td nowrap> 
�̸�<input type="text" name="name" size="15" value="$COOKIE{'namea'}">
�н�����<input type="password" name="pass" size="8" value="$COOKIE{'entrypassa'}"><input type="submit" value="���������">
              </td></tr></table>$tablefuchitag2
</form>
</center>
<div align="center">

_HTML2_

&chosaku;
}#end html

# �� ����
#
sub storyvw {

	open(BOOK,"$storyfile");
	seek(BOOK,0,0);  @story = <BOOK>;  close(BOOK);
	@oldst = ();
	for ($i=$topstline; $i<$#story+1; $i++){
		push(@oldst,$story[$i])
	}

	if($ENV{'HTTP_ACCEPT_ENCODING'}=~/gzip/ && $gzipuse){
		print "Content-type: text/html\n";
		print "Content-encoding: gzip\n\n";
		open(STDOUT,"| $gzippass -1 -c");
	}else{
		print "Content-type: text/html\n\n";
	}
	print <<"EOM";
<html lang="ja"><head>
<meta http-equiv="Content-Type" content="text/html; charset=euc">
<title>$title2</title>
<meta http-equiv="Content-Style-Type" content="text/css">
$style
</head>
$body
$menu
EOM
	print "<br><center>$tablefuchitag1<table cellpadding=5 border=1 cellspacing=0 bordercolor=$stflamecol bordercolordark=$stflamecol bordercolorlight=$stflamecol bgcolor=$stbgcol><tr><td style=\"line-height:130%\">@oldst</td></tr></table>$tablefuchitag2</center><br>";
	print "<center><input type='button' value=\"  �ݴ´�  \" onClick='top.close();'></center><br>";
	print "</body></html>\n";
	if($filelockuse ==1){if (-e,$lockfile){unlink($lockfile);}}
	exit;
}

##### ĳ���� ��� ���
sub rec{

&get_cookie;

if($formsex eq "m"){
	$seibetsu = "����";
}else{
	$seibetsu = "����";
}

if($recflag == 1){

if($ENV{'HTTP_ACCEPT_ENCODING'}=~/gzip/ && $gzipuse){
	print "Content-type: text/html\n";
	print "Content-encoding: gzip\n\n";
	open(STDOUT,"| $gzippass -1 -c");
}else{
	print "Content-type: text/html\n\n";
}
print <<"_HTML1_";

<html><head><title>$title2</title><META HTTP-EQUIV="Content-type" CONTENT="text/html; charset=euc">
$style
<script language='JavaScript'>
<!--
function ImageView(){
window.open('$cgifile?mode=imagevw','windowimg');
}
//-->
</script></head>
$body
$menu
<center><br>
<img src=\"$title\" width=\"$titlew\" height=\"$titleh\"><br><br><font size=4>$mesrec</font><br>
�� �������� Ʋ�����°� Ȯ�� ��Ź�մϴ�. <br>
<br>
<form action="$cgifile" method="$method">
$tablefuchitag1<table border="1" cellspacing="1" bgcolor="$flamecol" bordercolor="$flamecol" bordercolordark="$flamecol" bordercolorlight="$flamecol" width="300"><tr><td bgcolor="#ffffff">

<center>
<table widtn="100%">
 <tr>
  <td valign="bottom" bgcolor="#ffffff"><center>��� ī��</center><br>
   <center>
   <table border="1" cellspacing="0" bgcolor="$flamecol" bordercolor="$flamecol" bordercolordark="$flamecol" bordercolorlight="$flamecol">
    <tr>
	 <td bgcolor="#ffffff">�������� ��
      <table align="center">
	   <tr>
	    <td align="center">
		 <img src=$formimg width=26 height=26><br>
		 ������$seibetsu
		</td>
	   </tr>
	  </table>
     </td>
	</tr>
   </table>
   <br>
   </center>
   <table border="1" cellspacing="0" width="100%" bgcolor="$flamecol" bordercolor="$flamecol" bordercolordark="$flamecol" bordercolorlight="$flamecol">
    <tr>
	 <td bgcolor="#ffffff" nowrap>�������� $tablenam��$formchara</td>
     <td bgcolor="#ffffff" nowrap>�������� $tablejob��$formjob</td>
	</tr>
    <tr>
	 <td bgcolor="#ffffff" nowrap>����� $tablenam��$formname</td>
     <td bgcolor="#ffffff">�������� $tableold��$formold</td>
	</tr>
   </table>
  </td>
 </tr>
 <tr>
  <td colspan="2">
   <table border="1" cellspacing="0" width="100%" bgcolor="$flamecol" bordercolor="$flamecol" bordercolordark="$flamecol" bordercolorlight="$flamecol">
    <tr>
	 <td bgcolor="#ffffff" nowrap>���� �ּң�$formmail<br>
_HTML1_

	if($formmailopen){
		print "���� ����<br>";
	}else{
		print "���� �����<br>";
	}

	if($formrideonmail){
		print "$wagon�� Ÿ��(��) ���Ϸ� �˷� �ش�<br>";
	}else{
		print "$wagon�� Ÿ�� ���Ϸ� �˷� ���� �ʴ´�<br>";
	}
		
	if($formsendstory >= 1){
		print "�ͱ��ϸ�(��) ���丮��$formsendstory�� ���� �ش�<br>";
	}else{
		print "�ͱ��ص� ���丮�� ���� ���� �ʴ´�<br>";
	}

	print <<"_HTML3_";
     </td>
    </tr>
    <tr>
 	<td bgcolor="#ffffff">Ȩ ��������$formhp</td>
    </tr>
   </table>
  </td>
 </tr>
 <tr>
  <td colspan="2">
   <table border="1" cellspacing="0" width="100%" bgcolor="$flamecol" bordercolor="$flamecol" bordercolordark="$flamecol" bordercolorlight="$flamecol">
    <tr>
	 <td bgcolor="#ffffff">
      �������� Ư¡<BR>
      $tablelook��$formlook<br>
      $tablekind��$formkind<br>
      $tablespe��$formspe<br>
      $tablelif��$formlif<br>
     </td>
	</tr>
   </table>
  </td>
 </tr>
 <tr>
  <td colspan="2">
   <table border="1" cellspacing="0" width="100%" bgcolor="$flamecol" bordercolor="$flamecol" bordercolordark="$flamecol" bordercolorlight="$flamecol">
    <tr>
	 <td bgcolor="#ffffff">
      �����ϴ� ����� ���<BR>
      ȣ���� ������ �ִ� ��뿡�Է��� ���<BR>
      $formplus1<br>
      ���� ��뿡�Է��� ���<BR>
      $formplus2<br>
      ��� �ʵ� �ƴ� ��뿡�Է��� ���<BR>
      $formplus3<br>
      ����) Ƽ���� �ǳ��� ��/����) Ƽ���� �޾��� ���� ���<BR>
      $formplus4<br>
      ����) ������ ��/����) ������ ���� ���<BR>
      $formplus5
     </td>
	</tr>
   </table>
  </td>
 </tr>
</table>
<input type="hidden" name="rec" value="2">
<input type="hidden" name="chara" value="$formchara">
<input type="hidden" name="name" value="$formname">
<input type="hidden" name="entrypass" value="$formentrypass">
<input type="hidden" name="hp" value="$formhp">
<input type="hidden" name="mail" value="$formmail">
<input type="hidden" name="mailopen" value="$formmailopen">
<input type="hidden" name="rideonmail" value="$formrideonmail">
<input type="hidden" name="sendstory" value="$formsendstory">
<input type="hidden" name="life" value="$formlif">
<input type="hidden" name="speed" value="$formspe">
<input type="hidden" name="kind" value="$formkind">
<input type="hidden" name="look" value="$formlook">
<input type="hidden" name="old" value="$formold">
<input type="hidden" name="job" value="$formjob">
<input type="hidden" name="sex" value="$formsex">
<input type="hidden" name="img" value="$formimg">
<input type="hidden" name="plus1" value="$formplus1">
<input type="hidden" name="plus2" value="$formplus2">
<input type="hidden" name="plus3" value="$formplus3">
<input type="hidden" name="plus4" value="$formplus4">
<input type="hidden" name="plus5" value="$formplus5">
<input type="hidden" name="reload" value="$form{'reload'}">
<div align="center"><input type="submit" value="�̰����� OK! "></div>
</td></tr>
</table>$tablefuchitag2
</form>
_HTML3_

}elsif($form{'rec'} == 2){

	open(DB,"$logfile");
	seek(DB,0,0);  @lines = <DB>;  close(DB);

# ����Ʈ ȣ��Ʈ ���
	$host=$ENV{'REMOTE_ADDR'};
	if($doubleentry == 1){
		@checkip = split(/<>/,$lines[$#lines]);
		if($host eq $checkip[9]){&error(4);} 
	}elsif($doubleentry == 2){
		for ($i=0; $i<$#lines +1; $i++){
			@checkip = split(/<>/,$lines[$i]);
			if($host eq $checkip[9]){&error(7);} #IP�ּҿ����� ��
			if($formname eq $checkip[2]){&error(7);} #�̸������� ��
		}
	}

# ������ �Űܳ��´�
	$formchara = $form{'chara'};
	$formname = $form{'name'};
	$formentrypass = $form{'entrypass'};
	$formhp = $form{'hp'};
	$formmail = $form{'mail'};
	$formmailopen  = $form{'mailopen'};
	$formrideonmail  = $form{'rideonmail'};
	$formsendstory  = $form{'sendstory'};
	$formlif = $form{'life'};
	$formlook = $form{'look'};
	$formkind = $form{'kind'};
	$formspe = $form{'speed'};
	$formold = $form{'old'};
	$formjob = $form{'job'};
	$formsex = $form{'sex'};
	$formimg = $form{'img'};
	$formplus1 = $form{'plus1'};
	$formplus2 = $form{'plus2'};
	$formplus3 = $form{'plus3'};
	$formplus4 = $form{'plus4'};
	$formplus5 = $form{'plus5'};

# ĳ���� ��� �ѹ�

#��� ��ȣ�� ���ĸ� �����Ѵ�
	open(DBTMP,"$logfile");
	seek(DBTMP,0,0);  @linestmp = <DBTMP>;  close(DBTMP);
	foreach $i (0..(@linestmp-1)) {
	@Buftmp = split('<>', @linestmp[$i]);
	$SDatatmp{$i} = $Buftmp[0];
	}

	@SortDatatmp = sort {($SDatatmp{$b} <=> $SDatatmp{$a}) || ($b cmp $a)} keys(%SDatatmp);

	$lno = $linestmp[$SortDatatmp[0]] +1;

# ��Ͻð�
	$year += 1900;
	$month = sprintf("%02d",$mon +1);
	$mday = sprintf("%02d",$mday);
	$hour = sprintf("%02d",$hour);
	$min = sprintf("%02d",$min);
	$sec = sprintf("%02d",$sec);
	$jikan = "$month/$mday $hour:$min";
	
	&set_cookie;

	if(($profileuse)&&($profilemust)){#������ CGI�� �н��� �д´�
		open(PROFILE,"$profiledata");@prof = @LIST = <PROFILE>;close(PROFILE);

		$prozumi=0;
		for ($pri=0; $pri<$#prof+1; $pri++){
			$prof[$pri] =~ s/\x0D?\x0A?$//;
			if ($prof[$pri] =~ /^1\:\@\Q$formname\E\:\@/){
				@data_1 = split(/\:\@/,$prof[$pri]);
				if("$formname" eq "$data_1[1]"){
					$prozumi = 1;
					if("$formentrypass" eq "$data_1[2]"){

						if($profilelastuse){#��Ʈ ���� �ð��� �����ʿ� ���
							$lastuse = time();# �ʽð��� ���
							$prokakiko = "1\:\@";
							for($iii=0;$iii<=17;$iii++){
								$data_1[$iii] =~ s/\s*$//;
							}
							for($iii=1;$iii<=$#data_1;$iii++){
								if($iii == 11){
									$prokakiko = "$prokakiko"."$lastuse\:\@";
								}else{
									$prokakiko = "$prokakiko"."$data_1[$iii]\:\@";
								}
							}
							$prokakiko = "$prokakiko"."\n";

							local($md)=@_;
							if ($i_body !~ /BODY/i){
								$body = "$org_body\n$headertag";
							} else {
								$body = $i_body
							}

							@OLD=();

							open(DATA,">$profiledata") || die("can't open DAT $profiledata:$!\n");

							local($com) = 0;
							local($hit) = 0;
							local($del_memb);
							foreach $line (@LIST){
								if ($line =~ /^1\:\@\Q$formname\E\:\@$formentrypass\:\@/){
									$hit=1;
									$del_memb = $line;
									push(@OLD,$line);
									print DATA $prokakiko;
								}elsif ($line =~ /^3\:\@\Q$formname\E\:\@/){
									push(@OLD,$line);
									print DATA $line;
								}elsif ($line =~ /^2\:\@\Q$formname\E\:\@/){
									push(@OLD,$line);
									$com = 1;
									print DATA $line;
								}elsif ($com == 1 && $line =~ /^end/){
									push(@OLD,$line);
									$com = 0;
									print DATA $line;
								}elsif ($com == 1){
									push(@OLD,$line);
									print DATA $line;
								}elsif ($line =~ /^1\:\@\Q$formname\E\:\@/){
									push(@OLD,$line);
									print DATA $line;
								} else {
									print DATA $line;
								}
							}
							close(DATA);
						}

					}else{
						&error(10);
					}
					last;
				}
			}
		}
		if($profilemust == 1 && $prozumi != 1){
			&error(11);
		}
	}

# �α׿� �����ϴ� ��Ÿ���� ����
	$kakiko = "$lno<>$formchara<>$formname<>$formhp<>$formlif<>$formlook<>$formkind<>$formspe<>$jikan<>$host<>0<>$formplus1<>$formplus2<>$formplus3<>$formplus4<>$formplus5<>$formold<>$formimg<>$formjob<>0<>$formsex<>0<>$formentrypass<>$formmail<>$formmailopen<>$formrideonmail<>$formsendstory<>\n";

#��� �ִ���� ������(��) ����� �� ����

	open(DB,"$logfile");
	eval 'flock(DB,2);';
	seek(DB,0,0);@lines = <DB>;  close(DB);

	if($lines[${smax_chara}-1]){
		($lno, $lname, $lsakusya, $lhomepage, $llif, $llook, $lkind, $lspe, $ldate, $lip, $llove1, $plus1, $plus2, $plus3, $plus4, $plus5, $lold,$limgtype, $ljob, $llove2, $lsex,$llove3,$dmy,) = split(/<>/,$lines[${smax_chara}-1]);
	}

	$hantei = "$formplus1$formplus2$formplus3$formplus4$formplus5";
	$blname = $formname;
	&autobl;

# �α׿��� ������
#BL�� �Ǹ��� ������ ��� �㰡
	if($addbl != 1){
		open(DB,">>$logfile") ;
			print DB $kakiko;
			eval 'flock(DB,8);';
		close(DB);
		push(@lines,$kakiko);

#ť�ǵ� ������ ����
		open(RK,"$rankfile");
		eval 'flock(RK,2);';
		seek(RK,0,0);  @rank = <RK>; close(RK);
		for ($i=0; $i<$#rank +1; $i++){
			($sakusya, $hp, $entry, $goal, $entrytime, $hyjtime) = split(/<>/,$rank[$i]);
			if($formname eq $sakusya){
				$entry = $entry+1;
				$jyorenflg =1;
				$tmpline = "$sakusya<>$formhp<>$entry<>$goal<>$timemin<>$jikan\n";
				splice(@rank,$i,1,$tmpline);
			}else{
				if(($entrytime+ (60*60*24*$cutday)) <= $timemin){
					splice(@rank,$i,1);
				}
			}
		}
		if($jyorenflg != 1){
			$tmpline = "$formname<>$formhp<>1<>0<>$timemin<>$jikan\n";
			push(@rank,$tmpline);
		}

		open(RK,">$rankfile") ;
			print RK @rank;
			eval 'flock(RK,8);';
		close(RK);

		open(KTM,"$ktimefile");seek(KTM,0,0);  @times2 = <KTM>;  close(KTM);
		$times2[6]++;
		$times2[6]="$times2[6]\n";
		@t=();
		push(@t,$times2[0]);push(@t,$times2[1]);push(@t,$times2[2]);push(@t,$times2[3]);push(@t,$times2[4]);push(@t,$times2[5]);push(@t,$times2[6]);
		open(KTM,"+<$ktimefile");flock(KTM, 2);truncate(KTM, 0);seek(KTM, 0, 0);print KTM @t;close(KTM);
	}

&kankyou;

if($ENV{'HTTP_ACCEPT_ENCODING'}=~/gzip/ && $gzipuse){
	print "Content-type: text/html\n";
	print "Content-encoding: gzip\n\n";
	open(STDOUT,"| $gzippass -1 -c");
}else{
	print "Content-type: text/html\n\n";
}
print <<"_HTML1_";

<html><head><title>$title2</title><META HTTP-EQUIV="Content-type" CONTENT="text/html; charset=euc">
$style
<script language='JavaScript'>
<!--
function ImageView(){
window.open('$cgifile?mode=imagevw','windowimg');
}
//-->
</script></head>
$body
$menu
<center><br>
<img src=\"$title\" width=\"$titlew\" height=\"$titleh\"><br><br><font size=4>$mesrec</font><br>

<P>
�����մϴ�. <br>�׸����� Ŀ���� �����ϴ���, ���� �����̷� �� �ּ���.
</P>
_HTML1_

}else{

	$imageselect1 = "<select name=\"img\">";
	foreach (0 .. $#imgfile) {
		$tmpimg = "$imgfld/$imgfile[$_]";
		if("$COOKIE{'imga'}" eq "$tmpimg") {
			$imageselect1 = "$imageselect1"."<option value=\"$tmpimg\" selected>$imgname[$_]";
			$facehit = 1;
		}else{
			$imageselect1 = "$imageselect1"."<option value=\"$tmpimg\">$imgname[$_]";
		}
	}
	$imageselect1 = "$imageselect1"."</select>";
	if($COOKIE{'imga'} && !$facehit){
		$imgval = "$COOKIE{'imga'}";
		$bck = "checked";
		$cimg = "<img src=\"$COOKIE{'imga'}\" width=\"25\" height=\"25\" alt=\"\">"
	}else{
		$imgval = 'http://****.gif';
		$ack = "checked";
	}

if($ENV{'HTTP_ACCEPT_ENCODING'}=~/gzip/ && $gzipuse){
	print "Content-type: text/html\n";
	print "Content-encoding: gzip\n\n";
	open(STDOUT,"| $gzippass -1 -c");
}else{
	print "Content-type: text/html\n\n";
}
print <<"_HTML1_";

<html><head><title>$title2</title><META HTTP-EQUIV="Content-type" CONTENT="text/html; charset=euc">
$style
</head>
$body
$menu
<center><br>
<img src=\"$title\" width=\"$titlew\" height=\"$titleh\"><br><br><font size=4>$mesrec</font><br>

<SCRIPT LANGUAGE="JavaScript">
<!--
function checkurl_face(){
	window.open(document.entryform.ficon.value,"URLCHECK");
}
function SubmitCheck(){
	if(document.entryform.chara.value==""){
		alert("�������� �̸��� �Է��� �ּ���. ");
		return false;
	}
	if(document.entryform.job.value==""){
		alert("�������� ������ �Է��� �ּ���. ");
		return false;
	}
	if(document.entryform.name.value==""){
		alert("����� �̸��� �Է��� �ּ���. ");
		return false;
	}
	if(document.entryform.entrypass.value==""){
		alert("�н����带 �Է��� �ּ���. ");
		return false;
	}
	return true;
}
// -->
</SCRIPT>
<P>
<form action="$cgifile" name="entryform" method="$method" onSubmit="return SubmitCheck()">
$tablefuchitag1<table border="1" cellspacing="1" bgcolor="$flamecol" bordercolor="$flamecol" bordercolordark="$flamecol" bordercolorlight="$flamecol" width="300"><tr><td bgcolor="#ffffff">

<center><table widtn="100%"><tr><td valign="bottom" bgcolor="#ffffff"><center>��� ī��</center><br>
<center><table border="1" cellspacing="0" bgcolor="$flamecol" bordercolor="$flamecol" bordercolordark="$flamecol" bordercolorlight="$flamecol">
<tr><td bgcolor="#ffffff">�������� ��(<font color=red>���ڴ� ����, ���ڴ� ����!</font>)
<table><tr><td nowrap valign="top"><input type=radio name=imode value='n' $ack>ǥ�� �̹���</td>
<td>
$imageselect1
(���� �ڵ� ����)<br>[<a href="$cgifile?mode=imagevw" target="_blank">ȭ�� �̹��� ����</a> ]</td></tr>
<tr><td nowrap valign="top"><input type=radio name=imode value='f' $bck>���� �̹���<br>$cimg</td><td valign="top"><input type=text name=ficon size=30 value="$imgval"><input type="button" value="URLȮ��" onClick="checkurl_face()">
<select name=sex>
_HTML1_
if($COOKIE{'sexa'} eq "w"){
	print <<"_HTML1_";
<option value="m">����
<option value="w" selected>����
_HTML1_
}else{
	print <<"_HTML1_";
<option value="m" selected>����
<option value="w">����
_HTML1_
}

print <<"_HTML1_";
</select><br>
[<a href="http://www.abi-station.com/icon/make/imagemake.cgi" target="imagelist">������ ����</a> ]���֣�������� 26��26
</td></tr></table><br></center></td></tr></table><br>
<table border="1" cellspacing="0" width="100%" bgcolor="$flamecol" bordercolor="$flamecol" bordercolordark="$flamecol" bordercolorlight="$flamecol">
<tr><td bgcolor="#ffffff" nowrap>��������$tablenam($nameleng �ڱ���)<BR><input type="text" name="chara" size="15" value="$COOKIE{'charaa'}" maxlength="$nameleng"></td>
<td bgcolor="#ffffff" nowrap>��������$tablejob($nameleng �ڱ���)<BR><input type="text" name="job" size="15" value="$COOKIE{'joba'}" maxlength="$nameleng"></td></tr>
<tr><td bgcolor="#ffffff" nowrap>�����$tablenam($nameleng �ڱ���)<BR><input type="text" name="name" size="15" value="$COOKIE{'namea'}" maxlength="$nameleng"></td>
<td bgcolor="#ffffff">�������� $tableold<BR>
<select name=old>

_HTML1_
for ($i=$oldmin; $i<$oldmax+1; $i++){
	if($COOKIE{'olda'}){$defold = $COOKIE{'olda'};}
	if ($i == $defold) {
		print "<option value=\"$i\" selected>$i";
	} else {
		print "<option value=\"$i\">$i";
	}
}
print <<"_HTML3_";

</select>
</td></tr>
<tr><td colspan="2" bgcolor="#ffffff">
�н�����<input type="password" name="entrypass" size="8" value="$COOKIE{'entrypassa'}"> ������ ����մϴ�
</td></tr>
</table>
</td></tr>
<tr><td colspan="2">
<table border="1" cellspacing="0" width="100%" bgcolor="$flamecol"
bordercolor="$flamecol" bordercolordark="$flamecol"
bordercolorlight="$flamecol">
<tr>
	<td bgcolor="#ffffff">���� �ּ�<br>
	<input type="text" name="mail" size="40" value="$COOKIE{'maila'}"><br>
	<input type=checkbox name=mailopen value=1 checked>üũ�ϸ� ���� ����
_HTML3_
if($sendmail){
	print "<br><input type=checkbox name=rideonmail value=1 checked>$wagon�� Ÿ�� ���Ϸ� �ҽ�<br>�ͱ��ϸ� ���丮��<select name=sendstory>";

	foreach (0 .. $#sendstorysel) {
		if($sendstorysel[$_] eq $COOKIE{'sendstorya'}){
			print "<option value=\"$sendstorysel[$_]\" selected>$sendstorysel[$_]\n";
		}else{
			print "<option value=\"$sendstorysel[$_]\">$sendstorysel[$_]\n";
		}
	}
	print "</select>�� ���� �۽�</td>";
}
	print <<"_HTML3_";
</tr>
<tr>
	<td bgcolor="#ffffff">Ȩ ������(�ִٸ�)<BR><input type="text" name="hp" size="40" value="$COOKIE{'hpa'}"></td>
</tr>
</table>
</td></tr><tr><td colspan="2">
<table border="1" cellspacing="0" width="100%" bgcolor="$flamecol"
bordercolor="$flamecol" bordercolordark="$flamecol"
bordercolorlight="$flamecol">
<tr><td bgcolor="#ffffff">
�������� Ư¡(�հ� 100�� �ǵ��� ����� �ּ���)<BR>
<input type="text" name="look" size="5" value="$COOKIE{'looka'}">��$tablelook(5~100)<BR>
<input type="text" name="kind" size="5" value="$COOKIE{'kinda'}">��$tablekind(5~100)<BR>
<input type="text" name="speed" size="5" value="$COOKIE{'speeda'}">��$tablespe(5~100)<BR>
<input type="text" name="life" size="5" value="$COOKIE{'lifea'}">��$tablelif(5~100)<BR>
</font>
</td></tr></table>
</td></tr><tr><td colspan="2">
<table border="1" cellspacing="0" width="100%" bgcolor="$flamecol"
bordercolor="$flamecol" bordercolordark="$flamecol"
bordercolorlight="$flamecol">
$formplus</td></tr></table>
</td></tr></table>
<div align="center"><input type="submit" value="���"></div>
</td></tr>
</table>$tablefuchitag2
<input type="hidden" name="reload" value="$COOKIE{'reload'}">
<input type="hidden" name="record" value="1">
</form>
</P>

_HTML3_
}

# ǥ�� �̹���
#
sub imagevw {

	if($ENV{'HTTP_ACCEPT_ENCODING'}=~/gzip/ && $gzipuse){
		print "Content-type: text/html\n";
		print "Content-encoding: gzip\n\n";
		open(STDOUT,"| $gzippass -1 -c");
	}else{
		print "Content-type: text/html\n\n";
	}
	print <<"EOM";
<html lang="ja"><head>
<meta http-equiv="Content-Type" content="text/html; charset=euc">
<title>ǥ�� �̹��� ȭ�� �϶�</title>
<meta http-equiv="Content-Style-Type" content="text/css">
$style
</head>
$body
$menu
EOM
	print "<center><hr size=1 width=70%>";
	print "<big>ǥ�� �̹��� ȭ�� �϶�</big><br><br>";
	print "<hr size=1 width=70%><br>";
	print "$tablefuchitag1<table border=2 cellpadding=2 cellspacing=0 bordercolor=$flamecol bordercolordark=$flamecol bordercolorlight=$flamecol bgcolor=$datacol><tr>";
	$i=0; $j=0;
	$stop = @imgfile;
	foreach (0 .. $#imgfile) {
		$i++; $j++;
		print "<td align=center background=$tabledataimg><img src=\"$imgfld/$imgfile[$_]\" align=middle onmousedown=\"alert('$iconclickmsg2');\"><br>$imgname[$_]</td>";
		if ($i >= 6) { print "</tr><tr>"; $i=0; }
		if ($j eq "$stop") {
			if ($i == 0) { last; }
			while ($i < 6) { print "<td background=$tabledataimg><br></td>"; $i++; }
		}
	}
	print "</tr></table>$tablefuchitag2<table width=95% border=0 cellpadding=1 cellspacing=0>";
	print "<tr><td nowrap align=center width=100%>(C) 2002 <a href=http://members8.cool.ne.jp/~yurix/>���� ��</a>  / (C) 2002 <a href=http://www.abi-station.com/>Abi-Station</a> </td>";
	$i=0; $j=0;
	print "</tr></table><br><input type='button' value=\"  �ݴ´�  \" onClick='top.close();'></center>";
	print "</body></html>\n";
	if($filelockuse ==1){if (-e,$lockfile){unlink($lockfile);}}
	exit;
}

sub set_cookie {
	local(@mon,@week,$gmt,$cook);
	local($sec,$min,$hour,$mday,$mon,$year,$wday) = gmtime(time + 60*24*60*60);
	@mon  = ('Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec');
	@week = ('Sun','Mon','Tue','Wed','Thu','Fri','Sat');

	$gmt = sprintf("%s, %02d-%s-%04d %02d:%02d:%02d GMT",
			$week[$wday],$mday,$mon[$mon],$year+1900,$hour,$min,$sec);
	$cook="charaa<>$form{'chara'}<>namea<>$form{'name'}<>imga<>$form{'img'}<>sexa<>$form{'sex'}<>olda<>$form{'old'}<>joba<>$form{'job'}<>entrypassa<>$form{'entrypass'}<>hpa<>$form{'hp'}<>maila<>$form{'mail'}<>mailopena<>$form{'mailopen'}<>rideonmaila<>$form{'rideonmail'}<>sendstorya<>$form{'sendstory'}<>lifea<>$form{'life'}<>looka<>$form{'look'}<>kinda<>$form{'kind'}<>speeda<>$form{'speed'}<>jikana<>$jikan<>hosta<>$host<>plus1a<>$form{'plus1'}<>plus2a<>$form{'plus2'}<>plus3a<>$form{'plus3'}<>plus4a<>$form{'plus4'}<>plus5a<>$form{'plus5'}<>reload<>$reload";
	print "Set-Cookie: $cookname=$cook; expires=$gmt\n";
}

sub get_cookie {
	local($key, $val, @cook, %tmp);
	@cook = split(/;/, $ENV{'HTTP_COOKIE'});
	foreach (@cook) {
		($key, $val) = split(/=/);
		$key =~ s/\s//g;
		$tmp{$key} = $val;
	}
	%ck = split(/<>/, $tmp{"$cookname"});
    $COOKIE{charaa} = $ck{'charaa'};
    $COOKIE{namea} = $ck{'namea'};
    $COOKIE{imga} = $ck{'imga'};
    $COOKIE{sexa} = $ck{'sexa'};
    $COOKIE{olda} = $ck{'olda'};
    $COOKIE{joba} = $ck{'joba'};
    $COOKIE{entrypassa} = $ck{'entrypassa'};
    $COOKIE{hpa} = $ck{'hpa'};
    $COOKIE{maila} = $ck{'maila'};
    $COOKIE{mailopena} = $ck{'mailopena'};
    $COOKIE{rideonmaila} = $ck{'rideonmaila'};
    $COOKIE{sendstorya} = $ck{'sendstorya'};
    $COOKIE{lifea} = $ck{'lifea'};
    $COOKIE{looka} = $ck{'looka'};
    $COOKIE{kinda} = $ck{'kinda'};
    $COOKIE{speeda} = $ck{'speeda'};
    $COOKIE{reload} = $ck{'reload'};
}


print <<"_HTML4_";
<P>

_HTML4_

	open(DB,"$logfile");
	seek(DB,0,0);  @chara = <DB>;  close(DB);

	  print "</table><br><center>���� ��ٸ��� �е�</center><br>";
	  print "$tablefuchitag1$tablehead2";

	for ($i=6; $i<$#chara+1; $i++){
		($no[$i], $name[$i], $sakusya[$i], $homepage[$i], $lif[$i], $look[$i], $kind[$i], $spe[$i], $date[$i], $ip[$i], $love1[$i], $plus1[$i], $plus2[$i], $plus3[$i], $plus4[$i], $plus5[$i], $old[$i], $imgtype[$i], $job[$i], $love2[$i], $sex[$i],$love3[$i],$entrypass[$i],$mail[$i],$mailopen[$i],$rideonmail[$i],$sendstory[$i],$dmy) = split(/<>/,$chara[$i]);
		local($edname) = &urlencode($sakusya[$i]);
		if($profileuse && $sakusya[$i] ne "-"){$sakusya[$i] = "<a href=\"$profileurl?mode=view&name=$edname\">$sakusya[$i]</a>"}
		if($sex[$i] eq "m"){$sex = "��";}else{$sex = "��";}
		print "<tr bgcolor=$datacol nowrap><td align=right background=$tabledataimg>$no[$i]</td><td align=center background=$tabledataimg><img src=$imgtype[$i] width=26 height=26></td><td background=$tabledataimg>$name[$i]</td><td background=$tabledataimg>$sakusya[$i]</td><td align=right background=$tabledataimg>$old[$i]</td><td align=center background=$tabledataimg>$sex</td><td background=$tabledataimg>$job[$i]</td><td align=right background=$tabledataimg>$spe[$i]</td><td align=right background=$tabledataimg>$look[$i]</td><td align=right background=$tabledataimg>$kind[$i]</td><td align=right background=$tabledataimg>$lif[$i]</td></tr>";
	}

print <<"_HTML2_";
</table>$tablefuchitag2
</P>
</center>
<div align="center">
<form action="$cgifile" method="$method">
$tablefuchitag1<table border="1" cellpadding="3" bordercolor="$flamecol" bordercolordark="$flamecol"
bordercolorlight="$flamecol" bgcolor="$flamecol">
<tr><td bgcolor="$iroformwaku">
<input type="submit" value="$mestop">
<input type="submit" name="couple" value="$mescouple">
<input type="submit" name="rank" value="$mesrank">
<input type="button" value="$meshome" onClick="location.href='$url'">
</td></tr></table>$tablefuchitag2
</form>
_HTML2_
&chosaku;
}#end rec


##### Ŀ�� ���
sub couple{

	if($ENV{'HTTP_ACCEPT_ENCODING'}=~/gzip/ && $gzipuse){
		print "Content-type: text/html\n";
		print "Content-encoding: gzip\n\n";
		open(STDOUT,"| $gzippass -1 -c");
	}else{
		print "Content-type: text/html\n\n";
	}

print <<"_HTML1_";
<html><head><title>$title2</title><META HTTP-EQUIV="Content-type" CONTENT="text/html; charset=euc">
$style
</head>
$body
$menu
<center><br>
<img src=\"$title\" width=\"$titlew\" height=\"$titleh\"><br><br>
<font size=4>$mescouple</font><br>

$tablefuchitag1<table border="1" cellspacing="1" width="$ysize" bgcolor="$flamecol" bordercolor="$flamecol" bordercolordark="$flamecol" bordercolorlight="$flamecol">
<tr bgcolor=$headcol align=center>
      <td background=$tableheadimg nowrap>�ͱ� �Ͻ�</td>
      <td background=$tableheadimg nowrap>$tableno</td>
      <td background=$tableheadimg nowrap>$tableface</td>
      <td background=$tableheadimg nowrap>$tablenam</td>
      <td background=$tableheadimg nowrap>$tableaut</td>
      <td background=$tableheadimg nowrap>$tableold</td>
      <td background=$tableheadimg nowrap>$tablejob</td>
      <td background=$tableheadimg nowrap>$tablespe</td>
      <td background=$tableheadimg nowrap>$tablelook</td>
      <td background=$tableheadimg nowrap>$tablekind</td>
      <td background=$tableheadimg nowrap>$tablelif</td>
      <td background=$tableheadimg nowrap>���� $tablelove</td>
</tr>

_HTML1_

	open(CP,"$couplefile");
	seek(CP,0,0);  @couple = <CP>;  close(CP);
	
foreach $couple (@couple) {
	($lno,$mno,$mname,$msakusya,$mhomepage,$mlif,$mlook,$mkind,$mspe,$mdate,$manlove,$mold,$mimgtype,$mjob,$wno,$wname,$wsakusya,$whomepage,$wlif,$wlook,$wkind,$wspe,$wdate,$wmanlove,$wold,$wimgtype,$wjob,$goaltime) = split(/<>/,$couple);
	local($edname) = &urlencode($msakusya);
	if($profileuse && $msakusya ne "-"){$msakusya = "<a href=\"$profileurl?mode=view&name=$edname\">$msakusya</a>"}
	local($edname) = &urlencode($wsakusya);
	if($profileuse && $wsakusya ne "-"){$wsakusya = "<a href=\"$profileurl?mode=view&name=$edname\">$wsakusya</a>"}

	print "<tr bgcolor=$datacol><td rowspan=2 align=center background=$tabledataimg2 nowrap>$lnoȣ<br>$goaltime</td><td align=right background=$tabledataimg nowrap>$mno</td><td align=center background=$tabledataimg><img src=$mimgtype width=26 height=26></td><td background=$tabledataimg nowrap>$mname</td><td background=$tabledataimg nowrap>$msakusya</td><td align=right background=$tabledataimg>$mold</td><td background=$tabledataimg nowrap>$mjob</td><td align=right background=$tabledataimg>$mspe</td><td align=right background=$tabledataimg>$mlook</td><td align=right background=$tabledataimg>$mkind</td><td align=right background=$tabledataimg>$mlif</td><td align=right background=$tabledataimg><table border=0 cellspacing=0 cellpadding=0><tr><td nowrap><div align=right><font size=1>$wname</font></div></td><td rowspan=2><img src=$wimgtype width=26 height=26></td></tr><tr><td><div align=right><font color=#0000CC>$manlove\></font><font color=#6666FF>\></font><font color=#9999FF>\></font></div></td></tr></table></td></tr><tr bgcolor=$datacol nowrap><td align=right background=$tabledataimg>$wno</td><td align=center background=$tabledataimg><img src=$wimgtype width=26 height=26></td><td background=$tabledataimg>$wname</td><td background=$tabledataimg>$wsakusya</td><td align=right background=$tabledataimg>$wold</td><td background=$tabledataimg>$wjob</td><td align=right background=$tabledataimg>$wspe</td><td align=right background=$tabledataimg>$wlook</td><td align=right background=$tabledataimg>$wkind</td><td align=right background=$tabledataimg>$wlif</td><td align=right background=$tabledataimg><table border=0 cellspacing=0 cellpadding=0><tr><td nowrap><div align=right><font size=1>$mname</font></div></td><td rowspan=2><img src=$mimgtype width=26 height=26></td></tr><tr><td><div align=right><font color=#0000CC><font color=#CC0000>$wmanlove\></font></font><font color=#FF6666>\></font><font color=#FF9999>\></font></div></td></tr></table></td></tr><tr bgcolor=$datacol><td colspan=12><img src=$imgfld/dmy.gif width=1 height=2></td></tr>";
	}


print <<"_HTML2_";
</table>$tablefuchitag2
</center>
<div align="center">
<form action="$cgifile" method="$method">
$tablefuchitag1<table border="1" cellpadding="3" bordercolor="$flamecol" bordercolordark="$flamecol"
bordercolorlight="$flamecol" bgcolor="$flamecol">
<tr><td bgcolor="$iroformwaku">
<input type="submit" value="$mestop">
<input type="submit" name="rec" value="$mesrec">
<input type="submit" name="rank" value="$mesrank">
<input type="button" value="$meshome" onClick="location.href='$url'">
</td></tr></table>$tablefuchitag2
</form>
_HTML2_
&chosaku;
}#end couple

##### ��ŷ ���
sub rank{

	if($ENV{'HTTP_ACCEPT_ENCODING'}=~/gzip/ && $gzipuse){
		print "Content-type: text/html\n";
		print "Content-encoding: gzip\n\n";
		open(STDOUT,"| $gzippass -1 -c");
	}else{
		print "Content-type: text/html\n\n";
	}

print <<"_HTML1_";
<html><head><title>$title2</title><META HTTP-EQUIV="Content-type" CONTENT="text/html; charset=euc">
$style
</head>
$body
$menu
<center><br>
<img src=\"$title\" width=\"$titlew\" height=\"$titleh\"><br><br>
$mesrank<br>
<font size=2>$cutday �ϰ� �Ұ��� ���� ť�ǵ�� ���ܵ˴ϴ�</font><br>
$tablefuchitag1<table border="1" cellspacing="1" width="$ysize" bgcolor="$flamecol" bordercolor="$flamecol" bordercolordark="$flamecol" bordercolorlight="$flamecol">

<tr bgcolor=$headcol align=center>
      <td background=$tableheadimg nowrap>$tableaut</td>
      <td background=$tableheadimg nowrap>�Ұ� ȸ��</td>
      <td background=$tableheadimg nowrap>���� ȸ��</td>
      <td background=$tableheadimg nowrap>������</td>
      <td background=$tableheadimg nowrap>���� ����</td>
</tr>

_HTML1_
	
	open(RK,"$rankfile");
	seek(RK,0,0);  @cuprank = <RK>;  close(RK);

	foreach $cuprank (@cuprank) {

		($sakusya,$hp,$entry,$goal,$entrytime,$hyjtime) = split(/<>/,$cuprank);

		local($edname) = &urlencode($sakusya);
		if($profileuse && $sakusya ne "-"){$sakusya = "<a href=\"$profileurl?mode=view&name=$edname\">$sakusya</a>"}
		if($goal > 0){
			$goalp = ($goal / $entry) * 100;
			$goalpersent = int($goalp);
		}else{
			$goalpersent = 0;
		}
		print "<tr bgcolor=$datacol><td background=$tabledataimg nowrap>$sakusya</td><td align=right background=$tabledataimg nowrap>$entry</td><td align=right background=$tabledataimg nowrap>$goal</td><td align=right background=$tabledataimg nowrap>$goalpersent%</td><td align=right background=$tabledataimg nowrap>$hyjtime</td></tr>";
	}

print <<"_HTML2_";
</table>$tablefuchitag2
</center>
<div align="center">
<form action="$cgifile" method="$method">
$tablefuchitag1<table border="1" cellpadding="3" bordercolor="$flamecol" bordercolordark="$flamecol"
bordercolorlight="$flamecol" bgcolor="$flamecol">
<tr><td bgcolor="$iroformwaku">
<input type="submit" value="$mestop">
<input type="submit" name="rec" value="$mesrec">
<input type="submit" name="couple" value="$mescouple">
<input type="button" value="$meshome" onClick="location.href='$url'">
</td></tr></table>$tablefuchitag2
</form>
_HTML2_
&chosaku;
}#end rank


sub edit{########################################### ���� ���
	open(DB,"$logfile");
	seek(DB,0,0);  @chara = <DB>;  close(DB);

		if($ENV{'HTTP_ACCEPT_ENCODING'}=~/gzip/ && $gzipuse){
			print "Content-type: text/html\n";
			print "Content-encoding: gzip\n\n";
			open(STDOUT,"| $gzippass -1 -c");
		}else{
			print "Content-type: text/html\n\n";
		}
print <<"_HTML1_";

<html><head><title>$title</title><META HTTP-EQUIV="Content-type" CONTENT="text/html; charset=euc">
$style
</head>
$body
$menu
<center>

_HTML1_
#���� �Է� ȭ��
print <<"_HTML2_";

<br><center>���� ī��<br><br>�����ϴ� ��ȣ�� ���� �ּ���. <br><br>
<table border=1 cellspacing=1 bgcolor=$flamecol bordercolor=$flamecol bordercolordark=$flamecol bordercolorlight=$flamecol><tr bgcolor=$headcol><td align=center>$tableno</td><td align=center>$tableface</td><td align=center>$tablenam</td><td align=center>$tableaut</td><td align=center>$tableold</td><td align=center>$tablesex</td><td align=center>$tablejob</td><td align=center width=60>$tablespe</td><td align=center width=60>$tablelook</td><td align=center width=60>$tablekind</td><td align=center width=60>$tablelif</td><td align=center>IP</td></tr>

_HTML2_
	for ($i=0; $i<$#chara +1; $i++){
		($no[$i], $name[$i], $sakusya[$i], $homepage[$i], $lif[$i], $look[$i], $kind[$i], $spe[$i], $date[$i], $ip[$i], $love1[$i], $plus1[$i], $plus2[$i], $plus3[$i], $plus4[$i], $plus5[$i], $old[$i], $imgtype[$i], $job[$i], $love2[$i], $sex[$i],$love3[$i],$entrypass[$i],$mail[$i],$mailopen[$i],$rideonmail[$i],$sendstory[$i],$dmy) = split(/<>/,$chara[$i]);
		local($edname) = &urlencode($sakusya[$i]);
		if($profileuse && $sakusya[$i] ne "-"){$sakusya[$i] = "<a href=\"$profileurl?mode=view&name=$edname\">$sakusya[$i]</a>"}
		if($sex[$i] eq "m"){$sex = "��";}else{$sex = "��";}
		# IP�ּҴ� ��Ž���� ����Ʈ�� ��ũ�Ѵ�
		if($ip[$i] =~ /(\d+).(\d+).(\d+).(\d+)/) {
			$ip[$i] = "<a href=http://serv.nic.ad.jp/cgi-bin/whois_gw?key=$ip[$i]>$ip[$i]</a> ";
		}

		if($ip[$i]){#���ʽ� ĳ���ʹ� ���� ����
			print "<form action=\"$cgifile\" method=\"$method\"><tr bgcolor=$datacol nowrap><td><input type=submit value=\"$no[$i]\"></td><input type=hidden name=del2 value=\"$no[$i]\"></form><td align=center><img src=$imgtype[$i] width=26 height=26></td><td>$name[$i]</td><td>$sakusya[$i]</td><td align=right>$old[$i]</td><td align=center>$sex</td><td>$job[$i]</td><td align=right>$spe[$i]</td><td align=right>$look[$i]</td><td align=right>$kind[$i]</td><td align=right>$lif[$i]</td><td>$ip[$i]</td></tr>";
		}
	}

print <<"_HTML3_";

</table>
</center><br>
</body>
</html>
_HTML3_
}

##### ���� ó��

sub del2{

# ����
	open(DB,"$logfile");
	eval 'flock(DB,2);';
	seek(DB,0,0);@lines = <DB>;  close(DB);
	$flg=0;
	for ($i=0; $i<6; $i++){
		($no[$i], $name[$i], $sakusya[$i], $homepage[$i], $lif[$i], $look[$i], $kind[$i], $spe[$i], $date[$i], $ip[$i], $love1[$i], $plus1[$i], $plus2[$i], $plus3[$i], $plus4[$i], $plus5[$i], $old[$i], $imgtype[$i], $job[$i], $love2[$i], $sex[$i],$love3[$i],$entrypass[$i],$mail[$i],$mailopen[$i],$rideonmail[$i],$sendstory[$i],$dmy) = split(/<>/,$lines[$i]);
		if(($form{'del2'} == $no[$i] && $form{'pass'} eq $entrypass[$i]) || ($form{'del2'} == $no[$i] && $form{'pass'} eq $masterkey)){
			$dmychara="-<>-<>-<><>-<>-<>-<>-<>-<>-<>-<>-<>-<>-<>-<>-<>-<>$imgfld/dmy.gif<>-<>-<>$sex[$i]<>-<><><><><><>\n";
			splice(@lines,$i,1,$dmychara);
			$flg=1;
			last;
		}
	}
	if($flg == 0){
		for ($i=6; $i<$#lines +1; $i++){
			($no[$i], $name[$i], $sakusya[$i], $homepage[$i], $lif[$i], $look[$i], $kind[$i], $spe[$i], $date[$i], $ip[$i], $love1[$i], $plus1[$i], $plus2[$i], $plus3[$i], $plus4[$i], $plus5[$i], $old[$i], $imgtype[$i], $job[$i], $love2[$i], $sex[$i],$love3[$i],$entrypass[$i],$mail[$i],$mailopen[$i],$rideonmail[$i],$sendstory[$i],$dmy) = split(/<>/,$lines[$i]);
			if(($form{'del2'} == $no[$i] && $form{'pass'} eq $entrypass[$i]) || ($form{'del2'} == $no[$i] && $form{'pass'} eq $masterkey)){
				splice(@lines,$i,1);
				last;
			}
		}
	}
		
# �α׿��� ������
	open(DB,">$logfile") ;
		print DB @lines;
		eval 'flock(DB,8);';
	close(DB);

}

##### ���� ȭ��

sub useredit2{

	open(DB,"$logfile");
	eval 'flock(DB,2);';
	seek(DB,0,0);@lines = <DB>;  close(DB);
	for ($i=0; $i<$#lines +1; $i++){
		($no, $name, $sakusya, $homepage, $lif, $look, $kind, $spe, $date, $ip, $love1, $plus1, $plus2, $plus3, $plus4, $plus5, $old, $imgtype, $job, $love2, $sex,$love3,$entrypass,$mail,$mailopen,$rideonmail,$sendstory,$dmy) = split(/<>/,$lines[$i]);
		if(($form{'useredit2'} == $no && $form{'pass'} eq $entrypass) || ($form{'useredit2'} == $no && $form{'pass'} eq $masterkey)){
			last;
		}
	}

	if($ENV{'HTTP_ACCEPT_ENCODING'}=~/gzip/ && $gzipuse){
		print "Content-type: text/html\n";
		print "Content-encoding: gzip\n\n";
		open(STDOUT,"| $gzippass -1 -c");
	}else{
		print "Content-type: text/html\n\n";
	}
	print <<"_HTML_";

<html><head><title>$title2</title><META HTTP-EQUIV="Content-type" CONTENT="text/html; charset=euc">
$style
<script language='JavaScript'>
<!--
function ImageView(){
window.open('$cgifile?mode=imagevw','windowimg');
}
//-->
</script></head>
$body
$menu
<center><br>
<img src=\"$title\" width=\"$titlew\" height=\"$titleh\"><br><br><font size=4>���������</font><br>

<SCRIPT LANGUAGE="JavaScript">
<!--
function SubmitCheck(){
	if(document.entryform.chara.value==""){
		alert("�������� �̸��� �Է��� �ּ���. ");
		return false;
	}
	if(document.entryform.job.value==""){
		alert("�������� ������ �Է��� �ּ���. ");
		return false;
	}
	return true;
}
// -->
</SCRIPT>
<P>
<form action="$cgifile" name="entryform" method="$method" onSubmit="return SubmitCheck()">
$tablefuchitag1<table border="1" cellspacing="1" bgcolor="$flamecol" bordercolor="$flamecol" bordercolordark="$flamecol" bordercolorlight="$flamecol" width="300"><tr><td bgcolor="#ffffff">

<center><table widtn="100%"><tr><td valign="bottom" bgcolor="#ffffff"><center>��� ī��</center><br>
<center><table border="1" cellspacing="0" bgcolor="$flamecol" bordercolor="$flamecol" bordercolordark="$flamecol" bordercolorlight="$flamecol">
<tr><td bgcolor="#ffffff">�������� ��
<table><tr><td nowrap valign="top">
_HTML_
	foreach (0 .. $#imgfile) {
		if($imgtype eq "$imgfld/$imgfile[$_]"){
			$nflg = 1;
			last;
		}
	}
	if($nflg == 1){
		print "<input type=radio name=imode value='n' checked>";
	}else{
		print "<input type=radio name=imode value='n'>";
	}
	print <<"_HTML_";
ǥ�� �̹���</td>
<td>
<select name=img>

_HTML_
	foreach (0 .. $#imgfile) {
		if($imgtype eq "$imgfld/$imgfile[$_]"){
			print "<option value=\"$imgfld/$imgfile[$_]\" selected>$imgname[$_]\n";
		}else{
			print "<option value=\"$imgfld/$imgfile[$_]\">$imgname[$_]\n";
		}
	}
	print <<"_HTML_";

</select>
(���� �ڵ� ����)<br>[<a href='javascript:ImageView()'>ȭ�� �̹��� ����</a> ]</td></tr>
<tr><td nowrap valign="top">
_HTML_

	if($nflg == 1){
		print"<input type=radio name=imode value='f'>";
		print "���� �̹���</td><td valign=top>";
		print "<input type=text name=ficon size=30 value='http://****.gif or .jpg'>";
		print "<select name=sex>";
		print "<option value=\"m\">����";
		print "<option value=\"w\">����";
		
	}else{
		print"<input type=radio name=imode value='f' checked>";
		print "���� �̹���</td><td valign=top>";
		print "<input type=text name=ficon size=30 value=$imgtype>";
		print "<select name=sex>";
		if($sex eq "m"){
			print "<option value=\"m\" selected>����";
			print "<option value=\"w\">����";
		}else{
			print "<option value=\"m\">����";
			print "<option value=\"w\" selected>����";
		}
	}
	
	print <<"_HTML_";

</select><br>������� 26��26<br><font color=red>������� ������ ����, ȭ�� �ּҸ� �������� Ȯ���սô�. </font>
</td></tr></table><br></center></td></tr></table><br>
<table border="1" cellspacing="0" width="100%" bgcolor="$flamecol" bordercolor="$flamecol" bordercolordark="$flamecol" bordercolorlight="$flamecol">
<tr><td bgcolor="#ffffff" nowrap>��������$tablenam(����$nameleng ���ڱ���)<BR><input type="text" name="chara" size="15" value="$name"></td>
<td bgcolor="#ffffff" nowrap>��������$tablejob(����$nameleng ���ڱ���)<BR><input type="text" name="job" size="15" value="$job"></td></tr>
<tr><td bgcolor="#ffffff" nowrap>����� $tablenam<BR>$sakusya</td>
<td bgcolor="#ffffff">�������� $tableold<BR>
<select name=old>

_HTML_
	for ($i=$oldmin; $i<$oldmax+1; $i++){
		if ($i == $old) {
			print "<option value=\"$i\" selected>$i";
		} else {
			print "<option value=\"$i\">$i";
		}
	}
	if($mailopen == 1){$a = "checked";}else{$a = "";}
	print <<"_HTML_";

</select>
</td></tr>
</table>
</td></tr>
<tr><td colspan="2">
<table border="1" cellspacing="0" width="100%" bgcolor="$flamecol"
bordercolor="$flamecol" bordercolordark="$flamecol"
bordercolorlight="$flamecol">
<tr>
	<td bgcolor="#ffffff">���� �ּ�<br>
	<input type="text" name="mail" size="40" value="$mail"><br>
	<input type=checkbox name=mailopen value=1 $a>üũ�ϸ�(��) ���� ����
_HTML_
	if($sendmail){
		if($rideonmail == 1){$a = "checked";}else{$a = "";}
		print "<br><input type=checkbox name=rideonmail value=1 $a>$wagon�� Ÿ��(��) ���Ϸ� �ҽ�<br>�ͱ��ϸ�(��) ���丮��<select name=sendstory>";

		foreach (0 .. $#sendstorysel) {
			if($sendstorysel[$_] eq $sendstory){
				print "<option value=\"$sendstorysel[$_]\" selected>$sendstorysel[$_]\n";
			}else{
				print "<option value=\"$sendstorysel[$_]\">$sendstorysel[$_]\n";
			}
		}
		print "</select>�� ���� �۽�</td>";
	}
	print <<"_HTML_";
</tr>
<tr>
	<td bgcolor="#ffffff">Ȩ ������(�ִٸ�)<BR><input type="text" name="hp" size="40" value="$homepage"></td>
</tr>
</table>
</td></tr><tr><td colspan="2">
<table border="1" cellspacing="0" width="100%" bgcolor="$flamecol"
bordercolor="$flamecol" bordercolordark="$flamecol"
bordercolorlight="$flamecol">
<tr><td bgcolor="#ffffff">
�������� Ư¡<BR>
$look��$tablelook(5~100)<BR>
$kind��$tablekind(5~100)<BR>
$spe��$tablespe(5~100)<BR>
$lif��$tablelif(5~100)<BR>
</td></tr></table>
</td></tr><tr><td colspan="2">
<table border="1" cellspacing="0" width="100%" bgcolor="$flamecol"
bordercolor="$flamecol" bordercolordark="$flamecol"
bordercolorlight="$flamecol">
<tr><td colspan="2" bgcolor="#ffffff" nowrap>
�����ϴ� ����� ���� ������(��� �Է� �ʼ�)<BR>
ȣ���� ������ �ִ� ��뿡�Է��� ���<BR>
$plus1<br>
���� ��뿡�Է��� ���<BR>
$plus2<br>
��� �ʵ� �ƴ� ��뿡�Է��� ���<BR>
$plus3<br>
����) Ƽ���� �ǳ��� ��/����) Ƽ���� �޾��� ���� ���<BR>
$plus4<br>
����) ������ ��/����) ������ ���� ���<BR>
$plus5
</td></tr>
</table>
<input type=hidden name=pass value="$form{'pass'}">
<input type=hidden name=useredit3 value="$no">
</td></tr></table>
<div align="center"><input type="submit" value="����"></div>
</td></tr>
</table>$tablefuchitag2
</form>
</P>

_HTML_

}

##### ���� �����ͷ� �ٲپ� �ְ� ó��

sub useredit3{

	$formchara = $form{'chara'};
	$formname = $form{'name'};
	$formhp = $form{'hp'};
	$formmail = $form{'mail'};
	$formmailopen  = $form{'mailopen'};
	$formrideonmail  = $form{'rideonmail'};
	$formsendstory  = $form{'sendstory'};
	$formold = $form{'old'};
	$formjob = $form{'job'};
	if($form{'imode'} eq "f"){
		$formsex = $form{'sex'};
		$formimg = $form{'ficon'};
	}elsif($form{'imode'} ne "f"){
		$formimg = $form{'img'};#ǥ�� �̹����� �����ϸ�(��) ������ �ڵ� ����
		if($form{'img'} eq "$imgfld/$imgfile[0]"){$formsex = "m";}
		if($form{'img'} eq "$imgfld/$imgfile[1]"){$formsex = "m";}
		if($form{'img'} eq "$imgfld/$imgfile[2]"){$formsex = "m";}
		if($form{'img'} eq "$imgfld/$imgfile[3]"){$formsex = "m";}
		if($form{'img'} eq "$imgfld/$imgfile[4]"){$formsex = "m";}
		if($form{'img'} eq "$imgfld/$imgfile[5]"){$formsex = "m";}
		if($form{'img'} eq "$imgfld/$imgfile[6]"){$formsex = "w";}
		if($form{'img'} eq "$imgfld/$imgfile[7]"){$formsex = "w";}
		if($form{'img'} eq "$imgfld/$imgfile[8]"){$formsex = "w";}
		if($form{'img'} eq "$imgfld/$imgfile[9]"){$formsex = "w";}
		if($form{'img'} eq "$imgfld/$imgfile[10]"){$formsex = "w";}
		if($form{'img'} eq "$imgfld/$imgfile[11]"){$formsex = "w";}
	}

# �̸��� ���� üũ
	if((length($formchara) < 1)||(length($formchara) > $nameleng *2)){&error(3)};
	if((length($formjob) < 1)||(length($formjob) > $nameleng *2)){&error(5)};
	if($formold < $oldmin || $formold > $oldmax){&error(14)}
	if($formhp !~ /^http:\/\/[a-zA-Z0-9]+/){
		$formhp = '';
	}
	if($formmail =~ /@/){
		if($formmail !~ /mailto/){
			$formmail = "mailto:$formmail"
		}
	}else{
		$formmail = '';
	}

	open(DB,"$logfile");
	eval 'flock(DB,2);';
	seek(DB,0,0);@lines = <DB>;  close(DB);

	for ($i=6; $i<$#lines +1; $i++){
		($no[$i], $name[$i], $sakusya[$i], $homepage[$i], $lif[$i], $look[$i], $kind[$i], $spe[$i], $date[$i], $ip[$i], $love1[$i], $plus1[$i], $plus2[$i], $plus3[$i], $plus4[$i], $plus5[$i], $old[$i], $imgtype[$i], $job[$i], $love2[$i], $sex[$i],$love3[$i],$entrypass[$i],$mail[$i],$mailopen[$i],$rideonmail[$i],$sendstory[$i],$dmy) = split(/<>/,$lines[$i]);
		if(($form{'useredit3'} == $no[$i] && $form{'pass'} eq $entrypass[$i]) || ($form{'useredit3'} == $no[$i] && $form{'pass'} eq $masterkey)){
			$editchara="$no[$i]<>$formchara<>$sakusya[$i]<>$formhp<>$lif[$i]<>$look[$i]<>$kind[$i]<>$spe[$i]<>$date[$i]<>$ip[$i]<>$love1[$i]<>$plus1[$i]<>$plus2[$i]<>$plus3[$i]<>$plus4[$i]<>$plus5[$i]<>$formold<>$formimg<>$formjob<>$love2[$i]<>$formsex<>$love3[$i]<>$entrypass[$i]<>$formmail<>$formmailopen<>$formrideonmail<>$formsendstory<>\n";
			splice(@lines,$i,1,$editchara);
			last;
		}
	}

# �α׿��� ������
	open(DB,">$logfile") ;
		print DB @lines;
		eval 'flock(DB,8);';
	close(DB);

}


sub useredit{########################################### ���� ���� ���
	open(DB,"$logfile");
	seek(DB,0,0);  @chara = <DB>;  close(DB);

		if($ENV{'HTTP_ACCEPT_ENCODING'}=~/gzip/ && $gzipuse){
			print "Content-type: text/html\n";
			print "Content-encoding: gzip\n\n";
			open(STDOUT,"| $gzippass -1 -c");
		}else{
			print "Content-type: text/html\n\n";
		}
print <<"_HTML1_";

<html><head><title>$title2</title><META HTTP-EQUIV="Content-type" CONTENT="text/html; charset=euc">
$style
</head>
$body
$menu
<center>

_HTML1_
#���� �Է� ȭ��
print <<"_HTML2_";

<br><center>���� ī��<br><br>�����̳� ������ ���� �ּ���. <br><br>
$tablefuchitag1<table border=1 cellspacing=1 bgcolor=$flamecol bordercolor=$flamecol bordercolordark=$flamecol bordercolorlight=$flamecol><tr bgcolor=$headcol><td align=center background=$tableheadimg>����</td><td align=center background=$tableheadimg>����</td><td align=center background=$tableheadimg>$tableface</td><td align=center background=$tableheadimg>$tablenam</td><td align=center background=$tableheadimg>$tableaut</td><td align=center background=$tableheadimg>$tableold</td><td align=center background=$tableheadimg>$tablesex</td><td align=center background=$tableheadimg>$tablejob</td><td align=center width=55 background=$tableheadimg>$tablespe</td><td align=center width=55 background=$tableheadimg>$tablelook</td><td align=center width=55 background=$tableheadimg>$tablekind</td><td align=center width=55 background=$tableheadimg>$tablelif</td><td align=center background=$tableheadimg>IP</td></tr>

_HTML2_
	$print = 0;
	for ($i=6; $i<$#chara +1; $i++){
		($no[$i], $name[$i], $sakusya[$i], $homepage[$i], $lif[$i], $look[$i], $kind[$i], $spe[$i], $date[$i], $ip[$i], $love1[$i], $plus1[$i], $plus2[$i], $plus3[$i], $plus4[$i], $plus5[$i], $old[$i], $imgtype[$i], $job[$i], $love2[$i], $sex[$i],$love3[$i],$entrypass[$i],$mail[$i],$mailopen[$i],$rideonmail[$i],$sendstory[$i],$dmy) = split(/<>/,$chara[$i]);
		if($sex[$i] eq "m"){$sex = "��";}else{$sex = "��";}
		# IP�ּҴ� ��Ž���� ����Ʈ�� ��ũ�Ѵ�
		if($ip[$i] =~ /(\d+).(\d+).(\d+).(\d+)/) {
			$ip[$i] = "<a href=http://serv.nic.ad.jp/cgi-bin/whois_gw?key=$ip[$i]>$ip[$i]</a> ";
		}

		if(($form{'pass'} eq $entrypass[$i] && $form{'name'} eq $sakusya[$i]) || ($form{'pass'} eq $masterkey)){
			print "<form action=\"$cgifile\" method=\"$method\"><tr bgcolor=$datacol nowrap><td background=$tabledataimg><input type=submit value=\"����\"></td><input type=hidden name=useredit2 value=\"$no[$i]\"><input type=hidden name=pass value=\"$entrypass[$i]\"></form><form action=\"$cgifile\" method=\"$method\"><td background=$tabledataimg><input type=submit value=\"����\"></td><input type=hidden name=del2 value=\"$no[$i]\"><input type=hidden name=pass value=\"$entrypass[$i]\"></form><td align=center background=$tabledataimg><img src=$imgtype[$i] width=26 height=26></td><td background=$tabledataimg>$name[$i]</td><td background=$tabledataimg>$sakusya[$i]</td><td align=right background=$tabledataimg>$old[$i]</td><td align=center background=$tabledataimg>$sex</td><td background=$tabledataimg>$job[$i]</td><td align=right background=$tabledataimg>$spe[$i]</td><td align=right background=$tabledataimg>$look[$i]</td><td align=right background=$tabledataimg>$kind[$i]</td><td align=right background=$tabledataimg>$lif[$i]</td><td background=$tabledataimg>$ip[$i]</td></tr>";
			$print = 1;
		}
	}
	print "</table>$tablefuchitag2";
	if($print == 0){print "�� �̸��� �н����尡 ��ġ�ϴ� ����� �������ϴ�. <br>";}
	print "�֣����� ��ٸ��� ��� �ۿ� ������ �� �����ϴ�. ";
print <<"_HTML3_";
</center><br>
</body>
</html>
_HTML3_
}

sub addcamma {########################################### ĭ�� ����

	#-- �μ��� ���
	local($buf) = @_;

	#-- ĳ���� �������� ���
	$len = length($buf);
	#-- �����ϴ� ĭ���� ���� ���
	$num = int($len/3);
	#-- ĭ�� ���� ��ġ�� ���
	$point = int($len%3);
	#-- ���� ���� ��ġ�� ���
	$offset = 0;
	#-- ���ư� ���� �ʱ�ȭ
	$res = '';
	#-- �ڸ����� 3���� ������ �������� ���
	if($point == 0) {
		$num = $num - 1;
		$point = 3;
	}

	#-- ĳ���� �������� 3 ���� ������ ���(ĭ���� �ʿ����)
	if($len <= 3) {
		$res = $buf;
	} else {
	#-- ĳ���� �������� 4 ���� �̻��� ���
		while($offset <= $len) {
			if($num > 0) {
				$tmp = substr($buf,$offset,$point);
				$tmp = "$tmp".",";
				$num--;
				#-- ���� ���� ��ġ�� �缳��
				$offset = $offset + $point;
				$point = 3;
			} else {
				#-- �������� ���ڸ� ���
				$tmp = substr($buf,$offset);
				$res = "$res"."$tmp";
				last;
			}
			$res = "$res"."$tmp";
			$tmp = '';
		}
	}
	return $res;
}


sub lock{########################################### ���� ��


	$symlink_check = (eval {symlink("","");}, $@eq "");

	if(!$symlink_check) {
		$c = 0;
		while(-f "$lockfile") {
			$c++;
			if($c >= $lockretry) {
				unlink("$lockfile");
			}
			sleep(1);
		}
		open(LOCK, ">$lockfile");
		close(LOCK);
	}else{
		local($retry) = $lockretry;
		while(!symlink(".",$lockfile)) {
			if(--$retry <= 0) {
				unlink("$lockfile");
			}
			sleep(1);
		}
	}

}

sub abiyalock{########################################### ������ ���� ���� ������ ���� ��

	$symlink_check = (eval {symlink("","");}, $@eq "");
	if(!$symlink_check) {
		$c = 0;
		while(-f "$abiyalockfile") {
			$c++;
			if($c >= $abiyalockretry) {
				unlink("$abiyalockfile");
			}
			sleep(1);
		}
		open(LOCK, ">$abiyalockfile");
		close(LOCK);
	}else{
		local($retry) = $abiyalockretry;
		while(!symlink(".",$abiyalockfile)) {
			if(--$retry <= 0) {
				unlink("$abiyalockfile");
			}
			sleep(1);
		}
	}

}

sub blbase{########################################### BL����ڿ��� �׼��� ��Ű�� �ʴ� ��ƾ

	open(BL,"$blfile")  || print "Content-type: text/html\n\n$blfile�� ������ �ʾҽ��ϴ�";
	seek(BL,0,0);@bl=<BL>;close(BL);
	$host=$ENV{'REMOTE_ADDR'};
	$forwarded=$ENV{'HTTP_X_FORWARDED_FOR'};
	foreach (@bl) {
		if(($_ !~ /word/)&&($_ !~ /name/)&&($_ !~ /------/)){
			$tmp = $_;
			$tmp =~ s/\s*$//;
			$tmp =~ s/\*/\.\*/g;
			if(($host =~ /$tmp/)&&($tmp)){
				$addbl = 1;
			}
			if(("$forwarded" eq "$tmp")&&($tmp)&&($forwarded)){
				$addbl = 1;
			}
		}
	}

	if($kankyouhissu1){
		if(!$ENV{'HTTP_USER_AGENT'}){$addbl = 1;}
	}
	if($kankyouhissu2){
		if($ENV{'HTTP_USER_AGENT'} =~ /ANONYMIZER/){$addbl = 1;}
	}
	foreach (@kinshiname2) {
		if(index("$ENV{'HTTP_COOKIE'}","$_") > 0){$addbl = 1;}
	}
	if($addbl){
		if($filelockuse ==1){
			if (-e,$lockfile){unlink($lockfile);}
		}
		print "Location: $bljump\n\n";exit;
	}

}

sub autobl{########################################### �ڵ� BL�߰� ��ƾ

	open(BL,"$blfile")  || print "Content-type: text/html\n\n$blfile�� ������ �ʾҽ��ϴ�";
	seek(BL,0,0);@bl=<BL>;close(BL);
	$host=$ENV{'REMOTE_ADDR'};
	$addbl = 0;
	if($fullusekey){push(@kinshiword,$fullusekey);}
	foreach (@kinshiword) {
		if(index("$hantei","$_") > 0){$addbl = 1;last;}
	}
	foreach (@tyuiword) {
		if(index("$hantei","$_") > 0){&error("������ ���� ���ԵǾ� �־����Ƿ� ��ȿ�����ϴ�. ");}
	}
	$retmp = 1;
	$hantei2= $hantei;
	($match, $code) = jcode::getcode(\$hantei2);
	$code = 'euc' if $code eq undef and $match > 0;
	jcode::convert(\$hantei2, 'euc', $code);
	$ascii = '[\x00-\x7F]';
	$twoBytes = '[\x8E\xA1-\xFE][\xA1-\xFE]';
	$threeBytes = '\x8F[\xA1-\xFE][\xA1-\xFE]';
	@chars = $hantei2 =~ /$ascii|$twoBytes|$threeBytes/og;

	for ($set=0; $set<$#chars; $set++){
		if($set > 0){
			$setm = $set - 1;
			if($chars[$setm] eq $chars[$set]){
				$retmp++;
			}else{
				$retmp = 1;
			}
			if($retmp >= $renzoku){$addbl = 1;last;}
			if($retmp >= $tyuirenzoku){&error("���� ���ڸ� �ʹ� ����ϰ� �־����Ƿ� ��ȿ�����ϴ�. ");}
		}
	}

	if($kankyouhissu1){
		if(!$ENV{'HTTP_USER_AGENT'}){$addbl = 1;}
	}
	foreach (@bl) {
		if($_ =~ /name/){
			$tmp = $_;
			$tmp =~ s/\s*$//;
			$tmp =~ s/name_//g;
			if($blname eq $tmp){$addbl = 1;last;}
		}
	}
	
	
	if($addbl){
		$times = time;
		($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime($times);
		$year += 1900;
		$month = sprintf("%02d",$mon +1);
		$mday = sprintf("%02d",$mday);
		$hour = sprintf("%02d",$hour);
		$min = sprintf("%02d",$min);
		$sec = sprintf("%02d",$sec);
		$jikan = "$year/$month/$mday $hour:$min:$sec";

		($ipa,$ipb,$ipc,$ipd) = split(/\./, $host);
		$host2= "$ipa.$ipb.$ipc.*";
		$forwarded2 = $ENV{'HTTP_X_FORWARDED_FOR'};
		if($forwarded2){
			$pushdata = "------$jikan\n$host2\n$host\n$forwarded2\nname_$blname\nword_$hantei\n";
		}else{
			$pushdata = "------$jikan\n$host2\n$host\nname_$blname\nword_$hantei\n";
		}

		push(@bl,$pushdata);

		open(BL,"+<$blfile");flock(BL, 2);truncate(BL, 0);seek(BL,0,0);print BL @bl;close(BL);

		if($filelockuse ==1){
			if (-e,$lockfile){unlink($lockfile);}
		}

		print <<"EOF";
<script Language="JavaScript"><!--
location.href = "$bljump";
// --></script>
EOF
		exit;
	}

}

sub mail_to {

    &jcode'convert(*mailtitle,'euc');
#    &jcode'convert(*comment,'euc');

	$mail =~ s/mailto://g;

    if (open(MAIL,"| $sendmail -t")) {

		print MAIL "To: $mail\n";
		print MAIL "From: $mailto\n";
		print MAIL "Subject: $mailtitle\n";
		print MAIL "Content-Transfer-Encoding: 7bit\n";
		if(($stcode == 90 && $sendstoryline >= 1) || ($stcode == 16 && $sendstoryline >= 1)){
			print MAIL "Content-type: text/html;\n";
		    &jcode'convert(*storymailcomment,'euc');
			print MAIL "$storymailcomment";
			for ($i=0; $i<$sendstoryline; $i++){
				print MAIL "$story[$i]";
			}
			print MAIL "$mailfooter2";
		}else{
			print MAIL "Content-type: text/plain; charset=euc-kr\n";
			$comment = "$curchara���� �Ұ���$name��.$comment";
#		    &jcode'convert(*comment,'euc');
			print MAIL "\n\n$comment\n\n";
			print MAIL "$mailfooter\n";
		}

		#sendmail�� �ݴ´�
		close(MAIL);

	}
}


sub urlencode{
    local($val) = @_;
	$val =~ s/(\W)/sprintf("%%%02X", ord($1))/eg;
    return $val;
}

##########���� �޼���

###�������� ó��.
sub error {

local($no) = @_;

$msg[0] = '���� �մ����� ��ġ�� �ֱ� ������ ���� �����ϰ� �ֽ��ϴ�. <br>�˼��մϴٸ� �������� �ͱ��� ������ ��ٷ� �ּ���. ';
$msg[1] = '�˼��մϴٸ� �ɷ�ġ�� 1~100�� �������� ������ �ּ���. ';
$msg[2] = '�˼��մϴٸ� �ɷ�ġ�� ��Ż�� 100�� �ǵ���(����) ������ �ּ���. ';
$msg[3] = "\��\�� (��)���� �����ϴٸ�$tablenam�� ���̴�$nameleng ���� ���Ϸ� ������ �ּ���. ";
$msg[4] = '�˼��մϴٸ� ���� ����� �������� �ʽ��ϴ�. ';
$msg[5] = "\��\�� (��)���� �����ϴٸ�$tablejob�� ���̴�$nameleng ���� ���Ϸ� ������ �ּ���. ";
$msg[6] = "\��\�� (��)���� �����ϴٸ� ��� ��縦 ������ �ּ���. ";
$msg[7] = '�˼��մϴٸ� 2��°�� ����� �������� �ʽ��ϴ�. <br>��� ĳ���Ͱ� �ͱ��ϴ� ���� ��ٷ� �ּ���. ';
$msg[8] = '�˼��մϴٸ� �� �̻� ������ ����� �������� �ʽ��ϴ�. <br>���� ĳ���Ͱ� �ͱ��ϴ� ���� ��ٷ� �ּ���. ';
$msg[9] = '�˼��մϴٸ� �� �̻� ������ ����� �������� �ʽ��ϴ�. <br>���� ĳ���Ͱ� �ͱ��ϴ� ���� ��ٷ� �ּ���. ';
$msg[10] = '�н����尡 �ٸ��� ������ ����� �������� �ʽ��ϴ�. ';
$msg[11] = "<a href=$profileurl target=profile>�������� ���</a>�� �ּ���. ";
$msg[12] = "$hantei<br><br>������ ���� ���ԵǾ� �־����Ƿ� ����� ��ȿ�����ϴ�. ";
$msg[13] = "$hantei<br><br>���� ���ڸ� �ʹ� ����ϰ� �־����Ƿ� ����� ��ȿ�����ϴ�. ";
$msg[14] = "������ �����մϴ�. ";

&kankyou;

print "Content-type: text/html\n\n";
print <<"_ERROR_";
<html><head><title>$title2 ���� ����ڿ��Է��� ��Ź</title>$style</head>
$body
$menu
<div align=\"center\">
<img src=\"$title\" width=\"$titlew\" height=\"$titleh\"><br>
<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\"><tr><td>
<BR>$msg[$no]<BR>
<!--<form action="$cgifile" method="$method">-->
<!--<input type="submit" value="���� �������� ���ƿ´�">-->
<!--</form>-->
�������������� �������� �����ƿ´١��� ���ƿ� �ּ���.
</td></tr></table></div>
</body>
</html>
_ERROR_
if($filelockuse ==1){if (-e,$lockfile){unlink($lockfile);}}
exit;
}#END error

sub secretcopyright{
$secret = qq|<!--�� ��ũ��Ʈ�� ���� ����������kou & ������ ���� ���� ���� �ֽ��ϴ�. -->|;
print $secret;
} #END
