#####################
## 캐릭터독입/쓰기 ##
#####################
sub chara_open{
	if($in{'id'} eq ""){&error2("ID가 불명합니다.");}
	open(IN,"./logfile/chara/$in{'id'}.cgi") or &error2('캐릭터 데이터 파일을 열지 않았습니다.');
	@CH_DATA = <IN>;
	close(IN);
	($mid,$mpass,$mname,$murl,$mchara,$msex,$mhp,$mmaxhp,$mmp,$mmaxmp,$mele,$mstr,$mvit,$mint,$mfai,$mdex,$magi,$mmax,$mcom,$mgold,$mbank,$mex,$mtotalex,$mjp,$mabp,$mcex,$munit,$mcon,$marm,$mpro,$macc,$mtec,$msta,$mpos,$mmes,$mhost,$mdate,$mdate2,$mclass,$mtotal,$mkati,$mtype,$moya,$msk,$mflg,$mflg2,$mflg3,$mflg4,$mflg5,$mmacro,$mbong,$mquest,$mquest2) = split(/<>/,$CH_DATA[0]);
	$date = time();
#	if(!$login && $date>$mdate+1200){&error2("타임 아웃이 되었습니다.다시 로그인해 주세요.");}
	$mlv = int($mex/100)+1;
	($mjp[0],$mjp[1],$mjp[2],$mjp[3],$mjp[4],$mjp[5]) = split(/,/,$mjp);
	($mmaxstr,$mmaxvit,$mmaxint,$mmaxmen,$mmaxdex,$mmaxagi,$mmaxlv) = split(/,/,$mmax);
	if($in{'id'} ne "$mid" or $in{'pass'} ne "$mpass"){&error2("패스워드가 올바르지는 않습니다.");}
}

sub chara_input {
	&host_name;
	$date = time();
	@N_DATA=();
	$mjp = "$mjp[0],$mjp[1],$mjp[2],$mjp[3],$mjp[4],$mjp[5]";
	$str = "$mid<>$mpass<>$mname<>$murl<>$mchara<>$msex<>$mhp<>$mmaxhp<>$mmp<>$mmaxmp<>$mele<>$mstr<>$mvit<>$mint<>$mfai<>$mdex<>$magi<>$mmax<>$mcom<>$mgold<>$mbank<>$mex<>$mtotalex<>$mjp<>$mabp<>$mcex<>$munit<>$mcon<>$marm<>$mpro<>$macc<>$mtec<>$msta<>$mpos<>$mmes<>$host<>$date<>$mdate2<>$mclass<>$mtotal<>$mkati<>$mtype<>$moya<>$msk<>$mflg<>$mflg2<>$mflg3<>$mflg4<>$mflg5<>$mmacro<>$mbong<>$mquest<>$mquest2<>";
	$str =~ s/\n//;
	unshift(@N_DATA,"$str\n");
	open(OUT,">./logfile/chara/$in{'id'}.cgi") or &error('데이터를 쓸 수 없습니다.');
	print OUT @N_DATA;
	close(OUT);
}

sub enemy_open{
	open(IN,"./logfile/chara/$enemy_id.cgi");
	@E_DATA = <IN>;
	close(IN);
	($eid,$epass,$ename,$eurl,$echara,$esex,$ehp,$emaxhp,$emp,$emaxmp,$eele,$estr,$evit,$eint,$efai,$edex,$eagi,$emax,$ecom,$egold,$ebank,$eex,$etotalex,$ejp,$eabp,$ecex,$eunit,$econ,$earm,$epro,$eacc,$etec,$esta,$epos,$emes,$ehost,$edate,$esyo,$eclass,$etotal,$ekati,$etype,$eoya,$esk,$eflg,$eflg2,$eflg3,$eflg4,$eflg5,$emacro,$ebong,$equest,$equest2) = split(/<>/,$E_DATA[0]);
	$elv = int($eex/100)+1;
#	if($enemy_id ne "$eid"){&error("ID가 올바르지는 않습니다.$eid");}
}

sub enemy_input {
	$date = time();
	@NE_DATA=();
	if($ename){
		$str = "$eid<>$epass<>$ename<>$eurl<>$echara<>$esex<>$ehp<>$emaxhp<>$emp<>$emaxmp<>$eele<>$estr<>$evit<>$eint<>$efai<>$edex<>$eagi<>$emax<>$ecom<>$egold<>$ebank<>$eex<>$etotalex<>$ejp<>$eabp<>$ecex<>$eunit<>$econ<>$earm<>$epro<>$eacc<>$etec<>$esta<>$epos<>$emes<>$host<>$edate<>$edate2<>$eclass<>$etotal<>$ekati<>$etype<>$eoya<>$esk<>$eflg<>$eflg2<>$eflg3<>$eflg4<>$eflg5<>$emacro<>$ebong<>$equest<>$equest2<>";
		$str =~ s/\n//;
		unshift(@NE_DATA,"$str\n");
		open(OUT,">./logfile/chara/$enemy_id.cgi") or &error('데이터를 쓸 수 없습니다.');
		print OUT @NE_DATA;
		close(OUT);
	}
}

sub enemy_open2{
	open(IN,"./logfile/chara/$enemy_id.cgi");
	@E_DATA = <IN>;
	close(IN);
	($eid,$epass,$ename,$eurl,$echara,$esex,$ehp,$emaxhp,$emp,$emaxmp,$eele,$estr,$evit,$eint,$efai,$edex,$eagi,$emax,$ecom,$egold,$ebank,$eex,$etotalex,$ejp,$eabp,$ecex,$eunit,$econ,$earm,$epro,$eacc,$etec,$esta,$epos,$emes,$ehost,$edate,$esyo,$eclass,$etotal,$ekati,$etype,$eoya,$esk,$eflg,$eflg2,$eflg3,$eflg4,$eflg5,$emacro,$ebong,$equest,$equest2) = split(/<>/,$E_DATA[0]);
	$elv = int($eex/100)+1;
}

sub enemy_input2 {
	$date = time();
	@NE_DATA=();
	$str = "$eid<>$epass<>$ename<>$eurl<>$echara<>$esex<>$ehp<>$emaxhp<>$emp<>$emaxmp<>$eele<>$estr<>$evit<>$eint<>$efai<>$edex<>$eagi<>$emax<>$ecom<>$egold<>$ebank<>$eex<>$etotalex<>$ejp<>$eabp<>$ecex<>$eunit<>$econ<>$earm<>$epro<>$eacc<>$etec<>$esta<>$epos<>$emes<>$host<>$date<>$edate2<>$eclass<>$etotal<>$ekati<>$etype<>$eoya<>$esk<>$eflg<>$eflg2<>$eflg3<>$eflg4<>$eflg5<>$emacro<>$ebong<>$equest<>$equest2<>";
	$str =~ s/\n//;
	unshift(@NE_DATA,"$str\n");
	open(OUT,">./logfile/chara/$enemy_id.cgi") or &error('데이터를 쓸 수 없습니다.');
	print OUT @NE_DATA;
	close(OUT);
}

sub pet_open {
	if($in{'id'} eq ""){&error2("ID가 불명합니다.");}
	open(IN,"./logfile/pet/$in{'id'}.cgi");
	@CH_DATA = <IN>;
	close(IN);
	($mpname,$mplv,$mpfm,$mphungry,$mpap) = split(/<>/,$CH_DATA[0]);
}

sub pet_input {
	$str = "$mpname<>$mplv<>$mpfm<>$mphungry<>$mpap<>";
	$str =~ s/\n//;
	unshift(@N_DATA,"$str\n");
	open(OUT,">./logfile/pet/$in{'id'}.cgi") or &error('데이터를 쓸 수 없습니다.');
	print OUT @N_DATA;
	close(OUT);
}

##거리 데이터 읽기
sub town_open{
	open(IN,"./data/towndata.cgi") or &error("타운 데이터 파일이 열리지 않습니다.");
	@TOWN_DATA = <IN>;
	close(IN);

	$t_no = 0;
	foreach(@TOWN_DATA){
		($town_id,$town_name,$town_con,$town_ele,$town_gold,$town_arm,$town_pro,$town_acc,$town_ind,$town_tr,$town_s,$town_x,$town_y,$town_etc,$town_admin) =split(/<>/);
		if("$town_id" eq "$mpos"){last;$hit=1;}
		$t_no++;
	}
	($town_hp,$town_max,$town_str,$town_def,$town_dex,$town_flg) =split(/,/,$town_etc);

	$cnttt=0;
	foreach(@TOWN_DATA){
		($ta,$tb) =split(/<>/);
		if($ta && $tb) { $cnttt++; }
	}

	if($cnttt ne 21) {
		open(IN,"./data/towndata2.cgi");
		@BACKUP_TOWN=<IN>;
		close(IN);

		open(OUT,">./data/towndata.cgi");
		print OUT @BACKUP_TOWN;
		close(OUT);

		&error("타운데이터 박살나서 다시 복구했심. 귀찮겠지만 다시 실행시켜주세요. 님은 히어로!.");
	}
}

###거리 데이터 기입
sub town_input{
	$town_etc="$town_hp,$town_max,$town_str,$town_def,$town_dex,$town_flg";
	if($town_id ne ""){
		@NTOWN=();
		foreach(@TOWN_DATA){
			($town2_id,$town2_name,$town2_con,$town2_ele,$town2_gold,$town2_arm,$town2_pro,$town2_acc,$town2_ind,$town2_tr,$town2_s,$town2_x,$town2_y,$town2_etc,$town2_admin) =split(/<>/);
			if("$town_id" eq "$town2_id"){
				$str = "$town_id<>$town_name<>$town_con<>$town_ele<>$town_gold<>$town_arm<>$town_pro<>$town_acc<>$town_ind<>$town_tr<>$town_s<>$town_x<>$town_y<>$town_etc<>$town_admin<>";
				$str =~ s/\n//;
				push(@NTOWN,"$str\n");
			}else{
				push(@NTOWN,"$_");
			}
		}

		$cnt=0;
		foreach(@NTOWN) {
			($ta,$tb,$tc) = split(/<>/);
			if ($ta && $tb && $tc) { $cnt++; }
		}

		if ($cnt ne 21) { &error("다시 실행해 주세요."); }

		open(OUT,">./data/towndata.cgi") or &error('타운 데이터를 쓸 수 없습니다.');
		print OUT @NTOWN;
		close(OUT);
		if(int(rand(2)) eq 1){
			open(OUT,">./data/towndata2.cgi");
			print OUT @NTOWN;
			close(OUT);
		}
	}
	else{&error("타운 데이터에 이상이 있습니다.");}
}

###나라 데이터
sub con_open{
	open(IN,"./data/country.cgi") or &error("나라 데이터 파일이 열리지 않습니다.");
	@CON_DATA = <IN>;
	close(IN);

	$c_no = 0;
	foreach(@CON_DATA){
		($con_id,$con_name,$con_ele,$con_gold,$con_king,$con_yaku,$con_cou,$con_mes,$con_etc,$con_tax,$con_about,$con_ming,$con_bong) =split(/<>/);
		if("$con_id" eq "$mcon"){$hit=1;last;}
		$c_no++;
	}
	if(!$hit){
		$con_id=0;$con_name="무소속";
		$con_ele=0;$con_gold=0;
		$con_mes="";$con_etc=0;
		$con_king="";$con_yaku="";
	}
	($y_name[0],$y_name[1],$y_name[2],$y_chara[0],$y_chara[1],$y_chara[2]) =split(/,/,$con_yaku);
}
sub con_input{
	if($con_id ne "" && $con_id ne 0){
		@NCON=();
		foreach(@CON_DATA){
			($con2_id,$con2_name,$con2_ele,$con2_gold,$con2_king,$con2_yaku,$con2_cou,$con2_mes,$con2_etc,$con2_tax,$con2_about,$con2_ming) =split(/<>/);
			if("$con_id" eq "$con2_id"){
				$str = "$con_id<>$con_name<>$con_ele<>$con_gold<>$con_king<>$con_yaku<>$con_cou<>$con_mes<>$con_etc<>$con_tax<>$con_about<>$con_ming<>$con_bong<>";
				$str =~ s/\n//;
				push(@NCON,"$str\n");
			}else{
				push(@NCON,"$_");
			}
		}
		open(OUT,">./data/country.cgi") or &error('나라 데이터를 쓸 수 없습니다.');
		print OUT @NCON;
		close(OUT);
	}
}
#################
##　　로그     ##
#################
#사건
sub maplog{
	&time_data;
	open(IN,"./data/maplog.cgi") or error2("파일을 열지 않았습니다");
	@data = <IN>;
	close(IN);
	unshift(@data, "$_[0]($daytime) \n");
	splice(@data,20);
	open (OUT, "> ./data/maplog.cgi");
	print OUT @data;
	close (OUT);
}
#역사
sub maplog2{
	&time_data;
	open(IN,"./data/maplog2.cgi") or error2("파일을 열지 않았습니다");
	@data2 = <IN>;
	close(IN);
	unshift(@data2, "【$year년$mon월$mday일】$_[0]\n");
	splice(@data2,50);
	open (OUT, "> ./data/maplog2.cgi");
	print OUT @data2;
	close (OUT);
}
#경고
sub maplog3{
	&time_data;
	open(IN,"./data/maplog3.cgi") or error2("파일을 열지 않았습니다");
	@data = <IN>;
	close(IN);
	unshift(@data, "$_[0]($daytime) \n");
	splice(@data,30);
	open (OUT, "> ./data/maplog3.cgi");
	print OUT @data;
	close (OUT);
}
#아이템 사용 로그
sub maplog4{
	&time_data;
	open(IN,"./data/maplog4.cgi") or error2("파일을 열지 않았습니다");
	@data = <IN>;
	close(IN);
	unshift(@data, "$_[0]($daytime) \n");
	splice(@data,50);
	open (OUT, "> ./data/maplog4.cgi");
	print OUT @data;
	close (OUT);
}
#전투 로그
sub maplog5{
	&time_data;
	open(IN,"./data/maplog5.cgi") or error2("파일을 열지 않았습니다");
	@data5 = <IN>;
	close(IN);
	unshift(@data5, "$_[0]($daytime) \n");
	splice(@data5,20);
	open (OUT, "> ./data/maplog5.cgi");
	print OUT @data5;
	close (OUT);
}
#개명 로그
sub maplog6{
	&time_data;
	open(IN,"./data/maplog6.cgi") or error2("파일을 열지 않았습니다");
	@data6 = <IN>;
	close(IN);
	unshift(@data6, "$_[0]($daytime) \n");
	splice(@data6,30);
	open (OUT, "> ./data/maplog6.cgi");
	print OUT @data6;
	close (OUT);
}
#발견 로그
sub maplog7{
	&time_data;
	open(IN,"./data/maplog7.cgi") or error2("파일을 열지 않았습니다");
	@data7 = <IN>;
	close(IN);
	unshift(@data7, "$_[0]($daytime) \n");
	splice(@data7,30);
	open (OUT, "> ./data/maplog7.cgi");
	print OUT @data7;
	close (OUT);
}
sub kh_log{
	&time_data;
	open(IN,"./logfile/history/$mid.cgi");
	@data = <IN>;
	close(IN);
	unshift(@data, "$_[0]<>$_[1]<>$mon월$mday일 \n");
	splice(@data,6);
	open (OUT, "> ./logfile/history/$mid.cgi");
	print OUT @data;
	close (OUT);
}
sub eh_log{
	&time_data;
	open(IN,"./logfile/history/$eid.cgi");
	@data = <IN>;
	close(IN);
	unshift(@data, "$_[0]<>$_[1]<>$mon월$mday일 \n");
	splice(@data,6);
	open (OUT, "> ./logfile/history/$eid.cgi");
	print OUT @data;
	close (OUT);
}
#################
##　　장비     ##
#################
sub equip_open{
	($marmno,$marmname,$marmval,$marmdmg,$marmwei,$marmele,$marmhit,$marmcl,$marmsta,$marmtype,$marmflg) = split(/,/,$marm);
	($mprono,$mproname,$mproval,$mprodmg,$mprowei,$mproele,$mprohit,$mprocl,$mprosta,$mprotype,$mproflg) = split(/,/,$mpro);
	($maccno,$maccname,$maccval,$maccdmg,$maccwei,$maccele,$macchit,$macccl,$maccsta,$macctype,$maccflg) = split(/,/,$macc);
	($msk[0],$msk[1]) = split(/,/,$msk);
	if($msk[0] eq "62" || $msk[1] eq "62"){$eleplus = 0.15;}

	if($mele eq "$marmele" && $marmele ne "0"){$marmdmg = int($marmdmg*(1.2 + $eleplus));}
	if($mele eq "$mproele" && $mproele ne "0"){$mprodmg = int($mprodmg*(1.2 + $eleplus));}
	if($mele eq "$maccele" && $maccele ne "0"){$maccdmg = int($maccdmg*(1.5 + $eleplus));}
	if($ARM[$mclass] eq "$marmtype"){$marmhit += 10;}

	if($eid){
		($esk[0],$esk[1]) = split(/,/,$esk);
		
		($earmno,$earmname,$earmval,$earmdmg,$earmwei,$earmele,$earmhit,$earmcl,$earmsta,$earmtype,$earmflg) = split(/,/,$earm);
		($eprono,$eproname,$eproval,$eprodmg,$eprowei,$eproele,$eprohit,$eprocl,$eprosta,$eprotype,$eproflg) = split(/,/,$epro);
		($eaccno,$eaccname,$eaccval,$eaccdmg,$eaccwei,$eaccele,$eacchit,$eacccl,$eaccsta,$eacctype,$eaccflg) = split(/,/,$eacc);
		if($esk[0] eq "62" || $esk[1] eq "62"){$eleplus2=0.15;}

		if($eele eq "$earmele" && $earmele ne "0"){$earmdmg = int($earmdmg*(1.2 + $eleplus2));}
		if($eele eq "$eproele" && $eproele ne "0"){$eprodmg = int($eprodmg*(1.2 + $eleplus2));}
		if($eele eq "$eaccele" && $eaccele ne "0"){$eaccdmg = int($eaccdmg*(1.5 + $eleplus2));}
		if($ARM[$eclass] eq "$earmtype"){$earmhit += 10;}
	}
}

sub status_print{
	open(IN,"./logfile/battle/$in{'id'}.cgi");
	@BC_DATA = <IN>;
	close(IN);
	($mhpr,$mmpr,$mtim) =split(/<>/,$BC_DATA[0]);
	if($mhpr eq""){$mhpr=1;}
	if($mmpr eq""){$mmpr=1;}
	$mken=$mhpr*100;

	$STPR= <<"_STATUS_";
	<TABLE border="0"cellspacing="2" CLASS=MC>
        <TBODY>
          <TR>
          <TD colspan="2" rowspan="4" bgcolor="$ELE_C[$mele]" align=center><img src="./img/chara/$mchara.gif"></TD>
          <TD bgcolor="$ELE_C[$mele]"><font size=2>이름</font></TD>
          <TD colspan="2" bgcolor="$ELE_C[$mele]"><font size=2>$mname</font></TD>
          <TD bgcolor="$ELE_C[$mele]"><font size=2>LV</TD>
          <TD colspan="2" bgcolor="$ELE_C[$mele]"><font size=2>$mlv</font></TD>
          <TD bgcolor="$ELE_C[$mele]"><font size=2>성별</TD>
          <TD colspan="2" bgcolor="$ELE_C[$mele]"><font size=2>$SEX[$msex]</font></TD>
          </TR>
          <TR>
          <TD bgcolor="$ELE_C[$mele]"><font size=2>HP</TD>
          <TD colspan="2" bgcolor="$ELE_C[$mele]"><font size=2>$mhp/$mmaxhp</font></TD>
          <TD bgcolor="$ELE_C[$mele]"><font size=2>MP</TD>
          <TD colspan="2" bgcolor="$ELE_C[$mele]"><font size=2>$mmp/$mmaxmp</font></TD>
          <TD bgcolor="$ELE_C[$mele]"><font size=2>건강도</TD>
          <TD colspan="2" bgcolor="$ELE_C[$mele]"><font size=2>$mken %</font></TD>
          </TR>
          <TR>
          <TD bgcolor="$ELE_C[$mele]"><font size=2>경험치</font></TD>
          <TD colspan="2" bgcolor="$ELE_C[$mele]"><font size=2>$mex</font></TD>
          <TD bgcolor="$ELE_C[$mele]"><font size=2>직업</font></TD>
          <TD colspan="2" bgcolor="$ELE_C[$mele]"><font size=2>$JOB[$mclass]</font></TD>
          <TD bgcolor="$ELE_C[$mele]"><font size=2>숙련도</font></TD>
          <TD colspan="2" bgcolor="$ELE_C[$mele]"><font size=2>$mabp</font></TD>
          </TR>
	  <TR>
          <TD bgcolor="$ELE_C[$mele]"><font size=2>자금</font></TD>
          <TD colspan="2" bgcolor="$ELE_C[$mele]"><font size=2>$mgold</font></TD>
          <TD bgcolor="$ELE_C[$mele]"><font size=2>은행</font></TD>
          <TD colspan="2" bgcolor="$ELE_C[$mele]"><font size=2>$mbank</font></TD>
          <TD bgcolor="$ELE_C[$mele]"><font size=2>명성</font></TD>
          <TD colspan="2" bgcolor="$ELE_C[$mele]"><font size=2>$mcex</font></TD>
          </TR>
        </TBODY>
      </TABLE>
_STATUS_
}

##참가자 리스트
sub guest_list {

	open(IN,"./data/guest_list.cgi");
	@guest = <IN>;
	close(IN);
	&host_name;
	$timer = time() ;@newguest=();
	foreach(@guest) {
		($gname,$gtime,$gcon,$ghost) =split(/<>/);
		if($timer>$gtime+300){next;}
		elsif($mname eq $gname && $mname ne "찬제"){
			if($timer<$gtime+3){&error("갱신 시간은 3초 이상 열어 주세요.");}
			$ghit=1;
			push(@newguest,"$mname<>$timer<>$con_ele<>$host<>\n");
			$guestlist.="<font color=$ELE_BG[$gcon]>★$mname</font>";
		}
		else{
			push(@newguest,"$gname<>$gtime<>$gcon<>$ghost<>\n");
			$guestlist.="<font color=$ELE_BG[$gcon]>★$gname</font>";
		}
	}
	if(!$ghit && $mname ne "찬제"){
		push(@newguest,"$mname<>$timer<>$con_ele<>$host<>\n");
		$guestlist.="<font color=$ELE_BG[$mcon]>★$mname</font>";
	}
	open(OUT,">./data/guest_list.cgi") or &error('타운 데이터를 쓸 수 없습니다.');
	print OUT @newguest;
	close(OUT);

}

###시간 취득
sub time_data{
	$tt = time ;
	($sec,$min,$hour,$mday,$mon,$year,$wday,$yday) = localtime(time);
	$year += 1900;
	$mon++;
	$ww = (Sun,Mon,Tue,Wed,Thu,Fri,Sat)[$wday];
	$daytime = sprintf("%4d\/%02d\/%02d\/(%s)　%02d시 %02d분", $year,$mon,$mday,$ww,$hour,$min);
}

###문자 관계
sub decode{
	if ($ENV{'REQUEST_METHOD'} eq "POST") {
		read(STDIN, $buffer, $ENV{'CONTENT_LENGTH'});
	}else{$buffer = $ENV{'QUERY_STRING'}; }
	@buffer = split(/&/, $buffer);

	foreach (@buffer) {
	
		($na, $val) = split(/=/, $_);

		$val =~ tr/+/\ /;$val =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
		$val =~ s/</&lt;/g;$val =~ s/>/&gt;/g;$val =~ s/\n//g;
		$val =~ s/=/=/g;$val =~ s/&/&/g;

		# 개행등 처리
		if ($na eq "message") {
			$val =~ s/\r\n/<br>/g;
			$val =~ s/\r/<br>/g;
			$val =~ s/\n/<br>/g;
		} else {
			$val =~ s/\r//g;
			$val =~ s/\n//g;
		}
		$in{$na} = $val;
	}
}

##호스트 취득
sub host_name {

	$host = $ENV{'REMOTE_HOST'};
	$addr = $ENV{'REMOTE_ADDR'};

	if ($get_remotehost) {
		if ($host eq "" || $host eq "$addr") {
			$host = gethostbyaddr(pack("C4", split(/\./, $addr)), 2);
		}
	}
	if ($host eq "") { $host = $addr; }

}
##에러
sub error {
	&header;
	print <<"EOF";
	<center>
	<TABLE border="0" width="50%" bgcolor="#660000" CLASS=TC>
  	<TBODY>
    	<TR>
      	<TD align="center"><FONT color="#ffffcc"><B>ERROR</B></FONT></TD>
    	</TR>
    	<TR>
      	<TD bgcolor="#ffffff" align="center"><BR><B>$_[0]</B>
      	<form action="./top.cgi" method="POST"><input type=hidden name=id value="$mid"><input type=hidden name=pass value="$mpass">
      	<CENTER><input type="submit" CLASS=FC value="돌아온다">
	</CENTER>
      	</form>
      	</TD>
    	</TR>
  	</TBODY>
	</TABLE>
	</CENTER>
	<BR><BR>
	</form>
	<P><hr size=0></center>
	</center>
EOF
	&footer;
	exit;
}
sub error2 {
	&header;
	print <<"EOF";
	<center>
	<TABLE border="0" width="50%" bgcolor="#660000" CLASS=TC>
  	<TBODY>
    	<TR>
      	<TD align="center"><FONT color="#ffffcc"><B>ERROR</B></FONT></TD>
    	</TR>
    	<TR>
      	<TD bgcolor="#ffffff" align="center"><BR><B>$_[0]</B>
      	</TD>
    	</TR>
  	</TBODY>
	</TABLE>
	</CENTER>
	<BR><BR>
	<P><hr size=0></center>
	</center>
EOF
	&footer;
	exit;
}

sub header{
	print "Cache-Control: no-cache\n";
	print "Pragma: no-cache\n";
	print "Content-type: text/html; charset=utf-8\n\n";
	print <<"EOF";
<html>
<head>
<META HTTP-EQUIV="Content-type" CONTENT="text/html; charset=utf-8">
<STYLE type="text/css">
<!--
A:HOVER{
 color: $ALINK
}
.BC {border-top-width : medium;border-right-width : medium;border-bottom-width : medium;border-left-width :medium; border-color : $ELE_BG[0] $ELE_BG[0] $ELE_BG[0] $ELE_BG[0];border-style : double double double double;background-color : $ELE_BG[0];color : black;}
.TC {border-top-width : medium;border-right-width : medium;border-bottom-width : medium;border-left-width :medium; border-color : $FCOLOR $FCOLOR $FCOLOR $FCOLOR;border-style : double double double double;background-color : $FCOLOR;color : black;}
.CC {border-top-width : medium;border-right-width : medium;border-bottom-width : medium;border-left-width :medium; border-color : $ELE_BG[$con_ele] $ELE_BG[$con_ele] $ELE_BG[$con_ele] $ELE_BG[$con_ele];border-style : double double double double;background-color : $ELE_BG[$con_ele];color : black;}
.CC2 {border-top-width : medium;border-right-width : medium;border-bottom-width : medium;border-left-width :medium; border-color : $ELE_BG[$con2_ele] $ELE_BG[$con2_ele] $ELE_BG[$con2_ele] $ELE_BG[$con2_ele];border-style : double double double double;background-color : $ELE_BG[$con2_ele];color : black;}
.MC {border-top-width : medium;border-right-width : medium;border-bottom-width : medium;border-left-width :medium; border-color : $ELE_BG[$mele] $ELE_BG[$mele] $ELE_BG[$mele] $ELE_BG[$mele];border-style : double double double double;background-color : $ELE_BG[$mele];color : black;}
.MFC {border-top-width : medium;border-right-width : medium;border-bottom-width : medium;border-left-width : $ELE_BG[$con_ele];border-top-color : $ELE_BG[$con_ele];border-right-color : $ELE_BG[$con_ele];border-bottom-color : $ELE_BG[$con_ele];border-left-color : $ELE_BG[$con_ele];border-style : double double double double;background-color : $ELE_C[$con_ele];color : black;}
.FC {border-top-width : medium;border-right-width : medium;border-bottom-width : medium;border-left-width : $FCOLOR;border-top-color : $FCOLOR;border-right-color : $FCOLOR;border-bottom-color : $FCOLOR;border-left-color : $FCOLOR;border-style : double double double double;background-color : $FCOLOR2;color : black;}
.TOC {border-top-width : medium;border-right-width : medium;border-bottom-width : medium;border-left-width :medium; border-color : $ELE_BG[$town_ele] $ELE_BG[$town_ele] $ELE_BG[$town_ele] $ELE_BG[$town_ele];border-style : double double double double;background-color : $ELE_BG[$town_ele];color : black;}
.dmg { color: #FF0000; font-size: 10pt }
.clit { color: #0000FF; font-size: 10pt }
input,select,table,tr,td,body { font-size:9pt; letter-spacing:-1px; }
a, a:hover, a:active, a:visited { color:#999999; text-decoration:none; }
-->
</STYLE>

EOF
	@BANLIST = ("124.216.75.5","222.251.231.11","218.49.202.31");
	foreach(@BANLIST) {
		($ip) = split(/<>/);
		if ($ip eq $ENV{'REMOTE_ADDR'}) {
			print "님은 짤렷심. YOUR IP : $ENV{'REMOTE_ADDR'} 차단된 IP : $temp";
			exit;
		}
	}

	if($tmode eq "timer"){
	if($s_time > 0){
print << "_TIMER_";
<SCRIPT language="JavaScript">
<!--
	now=new Date();
function to() {
	d=new Date();
	
	sa=parseInt($s_time-(d-now)/1000);
	document.tokei.tok.value =("다음의 행동까지" + sa + "초");
	if(sa>0){setTimeout("to()", 1000);}}
//-->
</SCRIPT>

_TIMER_
	}

	}
	
	print "<title>$TITLE</title>\n";
	print "</head>";
	print "<body background=\"$BGIF\" bgcolor=\"$BG\" oncontextmenu=\"return false\">";
}

sub footer{
	print <<"EOF";
	<DIV align=center>
	<font size=2>
	$VER <A HREF="http://mame242.cool.ne.jp/top.html" target="blank">bean</a><BR>
	참고：The Wars of Roses Ver6.4 <a href=\"http://g2.ngw.jp/~maccyu/game/\" target="blank">maccyu</a><br></font>
	<A HREF="./html/thanks.html" target="blank">[special thanks]</a><BR><BR>
	</body>
	</html>
EOF
}

1;

