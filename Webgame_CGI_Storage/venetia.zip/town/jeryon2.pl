sub jeryon2 {
	&chara_open;
	&equip_open;
	
	if($in{'itno'} eq ""){&error("올바르게 선택되지 않았습니다.");}

	open(IN,"./logfile/item/$mid.cgi");
	@ITEM = <IN>;
	close(IN);
	($it_no,$it_ki,$it_name,$it_val,$it_dmg,$it_wei,$it_ele,$it_hit,$it_cl,$it_sta,$it_type,$it_flg) =split(/<>/,$ITEM[$in{'itno'}]);

	if ($it_name eq "C급위력강화주문서" && int(rand(100)) > 40) { #C급위력강화주문서. 60% 확률
		&maplog("<font color=blue>[강화]</font><font color=red>$mname</font>은 <font color=red>$marmname</font>에 <font color=red>C급위력강화주문서</font>를 발라, 성공했다!");
		$marmdmg += 25;
		$marmname .= "★";
		$mess = "C급위력강화주문서를 $marmname에 잘 발랐습니다. 성공했다!";
	}
	elsif ($it_name eq "B급위력강화주문서" && int(rand(100)) > 50) { #B급위력강화주문서. 50% 확률
		&maplog("<font color=blue>[강화]</font><font color=red>$mname</font>은 <font color=red>$marmname</font>에 <font color=red>B급위력강화주문서</font>를 발라, 성공했다!");
		$marmdmg += 50;
		$marmname .= "★";
		$mess = "B급위력강화주문서를 $marmname에 잘 발랐습니다. 성공했다!";
	}
	elsif ($it_name eq "A급위력강화주문서" && int(rand(100)) > 70) { #A급위력강화주문서. 30% 확률
		&maplog("<font color=blue>[강화]</font><font color=red>$mname</font>은 <font color=red>$marmname</font>에 <font color=red>A급위력강화주문서</font>를 발라, 성공했다!");
		$marmdmg += 75 + int($marmdmg * 0.1);
		$marmname .= "★";
		$mess = "A급위력강화주문서를 $marmname에 잘 발랐습니다. 성공했다!";
	}
	elsif ($it_name eq "S급위력강화주문서" && int(rand(100)) > 85) { #S급위력강화주문서. 15% 확률
		&maplog("<font color=blue>[강화]</font><font color=red>$mname</font>은 <font color=red>$marmname</font>에 <font color=red>S급위력강화주문서</font>를 발라, 성공했다!");
		$marmdmg += 100 + int($marmdmg * 0.2);
		$marmname .= "★";
		$mess = "S급위력강화주문서를 $marmname에 잘 발랐습니다. 성공했다!";
	}

	elsif ($it_name eq "SS급위력강화주문서" && int(rand(100)) > 93) { #SS급위력강화주문서. 7% 확률
		&maplog("<font color=blue>[강화]</font><font color=red>$mname</font>은 <font color=red>$marmname</font>에 <font color=red>SS급위력강화주문서</font>를 발라, 성공했다!");
		$marmdmg += 125 + int($marmdmg * 0.3);
		$marmname .= "★";
		$mess = "SS급위력강화주문서를 $marmname에 잘 발랐습니다. 성공했다!";
	}
	else {
		$mess = "실패했다.....";
	}

	splice(@ITEM,$in{'itno'},1);
	
	if($it_name){
		open(OUT,">./logfile/item/$in{'id'}.cgi");
		print OUT @ITEM;
		close(OUT);
		&chara_input;
	}else{&error("아이템에 이상이 있습니다.");}

	$marm = "$marmno<>$marmname<>$marmval<>$marmdmg<>$marmwei<>$marmele<>$marmhit<>$marmcl<>$marmsta<>$marmtype<>$marmflg<>";

	&chara_input;
	&header;
	
	print <<"EOF";
<TABLE border="0" width="80%" align=center height="150" CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="$FCOLOR"><FONT color="$FCOLOR2">제련소</FONT></TD>
    </TR>
    <TR>
      <TD colspan=2 height=100 bgcolor="#330000"><FONT color="$FCOLOR2">$mess</FONT>
　　</TD></TR>
	<TR><TD align=center height=5%>
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value="돌아간다"></form>
	</TD>
    </TR>
  </TBODY>
</TABLE>
<center></center>
EOF
	&footer;
	exit;
	
}
1;
