sub event2{
	&chara_open;
	&town_open;
	&status_print;

	if($moya%300 ne 1){
		&maplog("[부정]$mname는 이벤트로 부정을 실시했습니다.");
		&error("부정을 실시했습니다.");
	}

        $par= int($moya/300)%3;

	if($moya eq 3001){
         	$mesno=1;
		$mes=$EMES[$mesno];
		if($mflg3<=0){
			$mesno=0;
			$mes=$EMES2[$mesno];
		}elsif($mflg3>0 && $mflg3<=5){
			$mesno=$mflg3;
			$mes=$EMES2[$mesno];
		}elsif($mflg3>5){
			$mesno=8;
			$mes=$EMES2[$mesno];
		}
	#귀신 퇴치
	}elsif($par eq 0){
         	$ran=int(rand(3))+1;
		$EN[1]="도적";
		$EN[2]="재수생";
		$EN[3]="몬스터";
		$EN[20]="에치고 가게";
		
		$monlv=$ran;
		if(int(rand(20)) eq 7){$ran=20;$monlv=0;}
		if(int(rand(5))>=$monlv){
			$win=1;
		}
		
		if($win){
			$gold=int(rand(100000*$ran));
			$mes2="<font color=blue>$EN[$ran]의 퇴치에 성공했다!$gold Gold를 손에 넣었다!명성이$ran 올랐다!</font>";
			$mgold+=$gold;
			$mcex+=$ran;
		}else{
			$gold=int(rand(50000*$ran));
			$mes2="<font color=red>$EN[$ran]에 패배했다...$gold Gold를 잃었다..명성이$ran 내렸다.</font>";
			if($mgold>$gold){
				$mgold-=$gold;
			}else{
				$mbank-=$gold;
				if($mbank<0){$mbank=0;}
			}
			$mcex-=$ran;
			if($mcex<0){$mcex=0;}
		}
		$mes="거리에서 날뛰고 있는 것은<font color=red>$EN[$ran]</font>였다.<BR>$mname는<font color=red>$EN[$ran]</font>와 싸웠다!<BR>·····<BR>$mes2";
	#적
	}elsif($par eq 1){
         	if($mflg3 eq 0){
			$button="<form action=./town.cgi method=POST><INPUT type=hidden name=id value=$mid><INPUT type=hidden name=pass value=$mpass><INPUT type=hidden name=mode value=event2><INPUT type=submit CLASS=FC value=맡는다></form>";
			$mes="[술집]<BR>계(오)세요, 병사.<BR>너, 알고 있어 있어?<BR>바로 최근 여성이 마귀에 데려 가로채진 것 같다.<BR>마귀는 파브니르산의 정상에 서 그리고 있다고 한다.구출하러 & 줄래?";
			$img=$EIMG[$mflg3];
		}
	#외출
	}else{
         	if(int(rand(2)) eq 1){
			if(int(rand(15)) eq 1){
				$moya=3001;
			}else{
 				$moya=int(rand(20000));
			}
			$mes="초원에서 누웠다.";
		}elsif(int(rand(50)) eq 1){
                 	$mes="$SEN[9]에 겨우 도착했다.";
		}elsif(int(rand(5)) eq 1){
                 	$mes="$SEN[9]에 겨우 도착했다.";
		}elsif(int(rand(5)) eq 1){
                 	$mes="$SEN[8]을 발견했다!";
		}else{
			$rand=int(rand(2));
			if($rand eq 0){
                 		$mes="$SEN[6]을 발견했다!";
			}elsif($rand eq 1){
                         	$mes="$SEN[7]을 발견했다!";
			}
		}
	}
	&chara_input;
	&header;
	
	print <<"EOF";
<TABLE border="0" width="80%" bgcolor="#ffffff" height="150" align=center CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">이벤트</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="./img/etc/$img.gif"></TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc">$mes</FONT></TD>
    </TR>
    <TR>
      <TD colspan="2" align="right">
	$STPR
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value=돌아온다></form></TD>
	
    </TR>
  </TBODY>
</TABLE>
EOF
	&chara_input;
	&footer;
	exit;
}
1;

