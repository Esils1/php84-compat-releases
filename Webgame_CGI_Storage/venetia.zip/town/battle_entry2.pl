sub battle_entry2{
	&chara_open;
	&town_open;
	&con_open;
	&time_data;

	if(!$wday){&error("대회 개최일은 엔트리 할 수 없습니다.");}
	
	open(IN,"./data/entry_list.cgi") or &error("등록자 리스트가 열리지 않습니다.");
	@ENTRY_DATA = <IN>;
	close(IN);
	foreach(@ENTRY_DATA){
		($e_id,$e_name,$e_chara,$e_con,$e_cname,$e_cele,$e_point,$e_flg) =split(/<>/);
		if($e_id eq $mid){&error("이미 등록되어 있습니다.");}
	}
	$point=int(($mmaxhp+$mmaxmp) /3+$mstr+$mvit+$mint+$mfai+$mdex+$magi);
	
	push(@ENTRY_DATA,"$mid<>$mname<>$mchara<>$mcon<>$con_name<>$con_ele<>$point<><>\n");
	open(OUT,">./data/entry_list.cgi");
	print OUT @ENTRY_DATA;
	close(OUT);

	&header;
	
	print <<"EOF";
<TABLE border="0" width="80%" bgcolor="#ffffff" height="150" align=center CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">엔트리 완료</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="./img/etc/arena.jpg"></TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc">천하 제일 무도회에의 엔트리가 완료했습니다.<BR>시합 개시까지 기다려 주세요.</FONT></TD>
    </TR>
    <TR>
      <TD colspan="2" align="right">
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value="회장을 나온다"></form></TD>
	
    </TR>
  </TBODY>
</TABLE>
EOF
	&footer;
	exit;
}
1;

