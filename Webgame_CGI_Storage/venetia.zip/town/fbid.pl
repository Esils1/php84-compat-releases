sub fbid{
	&chara_open;
	&time_data;
	if($in{'no'} eq ""){&error("입찰하는 아이템이 올바르게 선택되지 않았습니다.");}
	if($in{'gold'} eq "" ){&error("입찰 금액이 입력되고 있지 않습니다.");}
	if($in{'gold'} <= 0){&error("성실하게 입력해 주세요.");}
	
	open(IN,"./data/free.cgi") or &error("데이터 파일을 열지 않았습니다.");
	@FREE = <IN>;
	close(IN);

	($f_no,$f_ki,$f_name,$f_val,$f_dmg,$f_wei,$f_ele,$f_hit,$f_cl,$f_type,$f_sta,$f_flg,$f_id,$f_hname,$f_min,$f_max,$f_p,$f_last,$f_lname,$f_time,$f_pat) =split(/<>/,$FREE[$in{'no'}]);
	$bidgold=$in{'gold'}*10000;
	if($f_id eq $mid){&error("출품자는 입찰할 수 없습니다.");}
	if($bidgold < $f_min){&error("최저 입찰액 미만으로의 입찰은 할 수 없습니다.");}
	if($bidgold > $f_max){&error("최고 입찰액을 넘고 있습니다.");}
	if($f_max <= $f_p){&error("그 상품에는 입찰할 수 없습니다.");}
	if($mbank < $bidgold){&error("예금액을 넘는 입찰은 실시할 수 없습니다.");}
	$date = time();
	if($bidgold <= $f_p){$hit=1;}
	
	if($f_time<$date){
		&maplog("<font color=red>[부정]</font>$mname는 옥션 회장에서$f_name의 부정 입찰을 실시했습니다.");
		&error("부정을 실시했습니다.");
	}

	$bidc = "$mname는$f_name를<font color=red>$bidgold Gold</font>로 입찰했습니다.";

	if($f_max<=$bidgold){
		$bidc = "$mname는$f_name를<font color=red>$bidgold Gold</font>로 즉결 입찰했습니다.";
		&maplog("<font color=red>[입찰]</font>$mname는$f_name를<font color=red>$bidgold Gold</font>로 즉결 입찰했습니다.");
		
	}
	$no = 0;
	@NFREE=();
	foreach(@FREE){
		($f2_no,$f2_ki,$f2_name,$f2_val,$f2_dmg,$f2_wei,$f2_ele,$f2_hit,$f2_cl,$f2_type,$f2_sta,$f2_flg,$f2_id,$f2_hname,$f2_min,$f2_max,$f2_p,$f2_last,$f2_lname,$f2_time,$f2_pat) =split(/<>/);
		if($in{'no'} eq "$no" && !$hit){
			push(@NFREE,"$f2_no<>$f2_ki<>$f2_name<>$f2_val<>$f2_dmg<>$f2_wei<>$f2_ele<>$f2_hit<>$f2_cl<>$f2_type<>$f2_sta<>$f2_flg<>$f2_id<>$f2_hname<>$f2_min<>$f2_max<>$bidgold<>$mid<>$mname<>$f2_time<>$f2_pat<>\n");
		}else{
			push(@NFREE,"$_");
		}
		$no++;
	}

	open(OUT,">./data/free.cgi");
	print OUT @NFREE;
	close(OUT);

	&chara_input;
	&header;
	
print <<"EOF";
<TABLE border="0" width="80%" align=center bgcolor="#000000" height="150" CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="$FCOLOR"><FONT color="$FCOLOR2">입찰</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="$FCOLOR2" width=20% align=center><img src="./img/etc/buki.gif"></TD>
      <TD bgcolor="#330000"><FONT color="$FCOLOR2">$bidc</FONT></TD>
    </TR>
    <TR>
    <TD colspan="2" align="center" bgcolor="ffffff">
	<form action="./town.cgi" method="POST">
	<INPUT type=hidden name=mode value=fshop>
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value="옥션에 돌아온다"></TD></form>
	</TD>
    </TR>
  </TBODY>
</TABLE>
<center></center>
EOF

	&footer;
	exit;
	
}
1;
