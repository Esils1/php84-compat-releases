sub hinn2{
	&chara_open;
	&town_open;

	$hinn_gold=int($mmaxhp+$mmaxmp+$mstr+$mvit+$mint+$mdex+$mfai+$magi)*5000;
	if($hinn_gold<1000000){$hinn_gold=1000000;}
	if($mgold<$hinn_gold){&error("돈이 충분하지 않습니다.")};
	$mgold-=$hinn_gold;

	$mmaxmaxhp = $mmaxstr*5 + $mmaxvit*10 + $mmaxmen*3 - 2000;
	$mmaxmaxmp = $mmaxint*5 + $mmaxmen*3 - 800;

	$hpup = 150 + int(rand(150));
	$mpup = 80 + int(rand(80));

	$mmaxhp += $hpup;
	$mmaxmp += $mpup;
			
	if($mmaxhp>$mmaxmaxhp){$mmaxhp=$mmaxmaxhp;}
	if($mmaxmp>$mmaxmaxmp){$mmaxmp=$mmaxmaxmp;}

	$town_gold+=int($hinn_gold/((1500-$town_ind)/250));

	&town_input;
	
	&header;
	
	print <<"EOF";
<TABLE border="0" width="80%" bgcolor="#ffffff" height="150" align=center CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">고급 여관</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="./img/etc/inn2.gif"></TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc">$mname는 고급 여관에 묵었습니다.<BR>HP의 최대치가<font color=red>$hpup</font>와 MP의 최대치가<font color=red>$mpup</font>상승했습니다.</FONT></TD>
    </TR>
    <TR>
      <TD colspan="2" align="right">
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value="여관을 나온다"></form></TD>
    </TR>
  </TBODY>
</TABLE>
EOF
	&chara_input;
	&footer;
	exit;
}
1;

