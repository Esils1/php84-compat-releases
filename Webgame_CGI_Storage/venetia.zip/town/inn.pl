sub inn{
	&header;
	&chara_open;
	&town_open;
	&status_print;

	$inn_gold=int($mmaxhp+$mmaxmp+($mstr+$mvit+$mint+$mdex+$mfai+$magi)/3);
	if($inn_gold<10){$inn_gold=10;}
	if($mgold>300000){
		$inn_gold=100000;
		$mes="높습니다는?그것은 이제(벌써), 부자의$mname님이는 로열 스위트 룸을 준비 했으므로.";
	}
	if($mgold<$inn_gold && $mbank<$inn_gold){
		$mes="돈을 가지고 있지 않은 것 같네요.이번은 특별 서비스로 해요.";
	}
	$mhp=$mmaxhp;
	$mmp=$mmaxmp;
	if($mgold<$inn_gold){
		$mbank-=$inn_gold;
		if($mbank<0){$mbank=0;$hit=1;}
		
	}else{
		$mgold-=$inn_gold;
		if($mgold<0){$mgold=0;}
	}
	if(!$hit){
		$town_gold+=int($inn_gold/((1500-$town_ind)/250));
	}
	&town_input;
	open(IN,"./logfile/battle/$in{'id'}.cgi");
	@BC_DATA = <IN>;
	close(IN);
	($mhpr,$mmpr,$mtim) =split(/<>/,$BC_DATA[0]);

	$date = time();
	$rec = int(($date - $mtim)/12)/100;
	$mhpr+=$rec;
	$mmpr+=$rec;
	if($mhpr>1){$mhpr=1;}
	if($mmpr>1){$mmpr=1;}
	if($mmpr<0.2){$mmpr=0.2;}
	
	@N_BC=();
	unshift(@N_BC,"$mhpr<>$mmpr<>$date<>\n");
	open(OUT,">./logfile/battle/$in{'id'}.cgi");
	print OUT @N_BC;
	close(OUT);

	print <<"EOF";
<TABLE border="0" width="80%" bgcolor="#ffffff" height="150" align=center CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">여인숙</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="./img/etc/inn2.gif"></TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc">어서 오십시오, $mname씨.긴 여행으로 필시 피로지요?<BR>일박 $inn_gold Gold가 됩니다.$mes 그러면, 천천히.<BR>$mname는 숙소에 묵었습니다.<BR>HP와 MP가 회복했습니다.<BR>건강도가 회복했습니다.</FONT></TD>
    </TR>
    <TR>
      <TD colspan="2" align="right">
	$STPR
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value="여인숙을 나온다"></form></TD>
	
    </TR>
  </TBODY>
</TABLE>
EOF
	&chara_input;
	&footer;
	exit;
}
1;

