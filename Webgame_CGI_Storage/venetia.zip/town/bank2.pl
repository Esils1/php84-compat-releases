sub bank2{
	&chara_open;
	
	if($in{'azuke'} eq "" && $in{'hiki'} eq ""){&error("금액이 입력되지 않았습니다.");}
	if($in{'azuke'} =~ m/[^0-9]/ || $in{'hiki'} =~ m/[^0-9]/){&error("금액에 숫자 이외의 문자가 포함되어 있습니다.");}
	if($in{'azuke'} <0 || $in{'hiki'} < 0){&error("성실하게 입력해 주세요.");}
	

	if($in{'mode'} eq"banka"){
		$com="위탁";
		$gold=$in{'azuke'}*10000;
		$mgold-=$gold;
		if($mgold<0){&error("소지금이 충분하지 않습니다.");}
		$mbank+=$gold;
	}elsif($in{'mode'} eq"bankh"){
		$com="인출";
		$gold=$in{'hiki'}*10000;
		$mgold+=$gold;
		$mbank-=$gold;
		if($mbank<0){&error("예금이 충분하지 않습니다.");}
	}elsif($in{'mode'} eq"bankall"){
		$com="위탁";
		if($mgold<0){&error("소지금이 충분하지 않습니다.");}
		$gold=$mgold;
		$mbank+=$gold;
		$mgold=0;
	}else{&error("부정한 액세스입니다.");}
	
	&header;
	
	print <<"EOF";
<TABLE border="0" width="80%" bgcolor="#ffffff" height="150" align=center CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">은행</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="./img/etc/pub.gif"></TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc">$gold Gold$com했다.</FONT></TD>
    </TR>
    <TR>
      <TD colspan="2" align="right">
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value="은행을 나온다"></form></TD>
	
    </TR>
  </TBODY>
</TABLE>
EOF
	&chara_input;
	&footer;
	exit;
}
1;

