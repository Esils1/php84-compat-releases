sub fget{
	&chara_open;
	&time_data;
	if($in{'no'} eq ""){&error("대상 아이템이 올바르게 선택되지 않았습니다.");}
	
	open(IN,"./data/free.cgi") or &error("데이터 파일을 열지 않았습니다.");
	@FREE = <IN>;
	close(IN);

	($f_no,$f_ki,$f_name,$f_val,$f_dmg,$f_wei,$f_ele,$f_hit,$f_cl,$f_type,$f_sta,$f_flg,$f_id,$f_hname,$f_min,$f_max,$f_p,$f_last,$f_lname,$f_time,$f_pat) =split(/<>/,$FREE[$in{'no'}]);
	
	$date = time();
	$xdate = ($date-$f_time)/3600;

	if($mid ne $f_id && $f_last ne $mid){
		&maplog("<font color=red>[부정]</font>$mname는 옥션 회장에서$f_name에 대해서 부정 낙찰을 실시했습니다.");
		&error("부정을 실시했습니다.");
	}

	$bidc = "$mname는 낙찰되지 않았다$f_name를 인수했습니다.";
	if($mid ne $f_last && $mid eq $f_id && $xdate>240){
		$bidc = "10일 이상 경과한 때문, 출품자에게 인도해졌습니다.";
		$f_last = $mid;
		$bidflg = 1;
	}

	if((($mid ne $f_last && $mid eq $f_id) || ($mid eq $f_last && $mid ne $f_id)) && !$bidflg){
		
		if($mid eq $f_last){
			$enemy_id="$f_id";
			&enemy_open;
			if($mbank < $f_p){&error("은행의 잔고가 부족합니다.");}
			$mbank -= $f_p;
			$ebank+=$f_p;
		}
		elsif($mid eq $f_id){
			$enemy_id="$f_last";
			&enemy_open;
			if($ebank < $f_p){&error("은행의 잔고가 부족합니다.");}
			$mbank+=$f_p;
			$ebank -= $f_p;
		}else{
			&error("그 상품은 인수할 수 없습니다.");
		}

		&enemy_input;

		$bidc = "$f_name는$f_lname에<font color=red>$f_p Gold</font>로 거두어 졌습니다.";
		&maplog("<font color=green>[낙찰]</font>$f_hname의$f_name는$f_lname에<font color=red>$f_p Gold</font>로 거두어 졌습니다.");
	}

	open(IN,"./logfile/item/$f_last.cgi") or &error("아이템 데이터 파일을 열지 않았습니다.");
	@ITEM = <IN>;
	close(IN);

	splice(@FREE,$in{'no'},1);
	push(@ITEM,"$f_no<>$f_ki<>$f_name<>$f_val<>$f_dmg<>$f_wei<>$f_ele<>$f_hit<>$f_cl<>$f_type<>$f_sta<>$f_flg<>\n");

	open(OUT,">./data/free.cgi");
	print OUT @FREE;
	close(OUT);

	open(OUT,">./logfile/item/$f_last.cgi");
	print OUT @ITEM;
	close(OUT);

	&chara_input;
	&header;
	
print <<"EOF";
<TABLE border="0" width="80%" align=center bgcolor="#000000" height="150" CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="$FCOLOR"><FONT color="$FCOLOR2">낙찰</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="$FCOLOR2" width=20% align=center><img src="./img/etc/buki.gif"></TD>
      <TD bgcolor="#330000"><FONT color="$FCOLOR2">$bidc</FONT></TD>
    </TR>
    <TR>
    <TD colspan="2" align="center" bgcolor="ffffff">
	<form action="./town.cgi" method="POST">
	<INPUT type=hidden name=mode value=fshop>
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value=옥션에 돌아온다></TD></form>
	</TD>
    </TR>
  </TBODY>
</TABLE>
<center></center>
EOF

	&footer;
	exit;
	
}
1;
