sub buy {
	&chara_open;
	&town_open;
	$val_off=0;
	if($mcon eq $town_con && $town_con ne 0){
		$val_off=int($mcex/100)+1;
		if($val_off>15){$val_off=15;}
	}
	if($in{'itype'} eq"0"){$idata="arm";}
	elsif($in{'itype'} eq"1"){$idata="pro";}
	elsif($in{'itype'} eq"2"){$idata="acc";}
	elsif($in{'itype'} eq"3"){$idata="item";}
	else{&error("올바르게 선택되지 않았습니다.");}
	if($in{'no'} eq ""){&error("올바르게 선택되지 않았습니다.");}

	open(IN,"./data/$idata.cgi") or &error("장비 데이터 파일을 열지 않았습니다.");
	@it_data = <IN>;
	close(IN);
	$it_num=@it_data;
	$num=$in{'no'};
	if($it_num>$num){
		($it_name,$it_val,$it_dmg,$it_wei,$it_ele,$it_hit,$it_cl,$it_type,$it_sta,$it_pos) =split(/<>/,$it_data[$in{'no'}]);
	}else{
		open(IN,"./data/carm.cgi") or &error("장비 데이터 파일을 열지 않았습니다.");
		@it2_data = <IN>;
		close(IN);
		$no2=$num-$it_num;
		($it_t,$it_name,$it_val,$it_dmg,$it_wei,$it_ele,$it_hit,$it_cl,$it_type,$it_sta,$it_pos) =split(/<>/,$it2_data[$no2]);
		if("$in{'itype'}" ne"$it_t"||$it_name eq""){&error("부정한 액세스입니다.");}
	}
	$it_val=int($it_val*(1-$val_off/100));
	
	if($mgold<$it_val){&error("돈이 충분하지 않습니다.");}
	$mgold-=$it_val;

	$townget=$town_ind/300;
	$town_gold+=int($it_val/((1500-$town_ind)/250));
	if(int(rand(10)) eq 7){
		$ames="<BR><font color=red>이번은 세간 극상의 녀석을 구매해 왔다.너에게 줄게.</font>";
		$it_dmg=int($it_dmg*1.1);
		$it_name.="+";
	}

	open(IN,"./logfile/item/$in{'id'}.cgi");
	@ITEM = <IN>;
	close(IN);
	if(@ITEM>=$ITM_MAX){&error("더 이상 가질 수 없습니다.(최대$ITM_MAX개)");}

	push(@ITEM,"$in{'no'}<>$in{'itype'}<>$it_name<>$it_val<>$it_dmg<>$it_wei<>$it_ele<>$it_hit<>$it_cl<>$it_type<>$it_sta<>$it_flg<>\n");
	open(OUT,">./logfile/item/$in{'id'}.cgi");
	print OUT @ITEM;
	close(OUT);

	&chara_input;
	&town_input;

	&header;
	
	print <<"EOF";
<TABLE border="0" width="80%" align=center height="150" CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="$FCOLOR"><FONT color="$FCOLOR2">$EQU[$in{'itype'}]가게</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="$FCOLOR2" width=20% align=center><img src="./img/etc/buki.gif"></TD>
      <TD bgcolor="#330000"><FONT color="$FCOLOR2">[$EQU[$in{'itype'}]가게의 점원]<BR>$it_name인가.$ames<br>$it_val Gold입니다. 다음에 또 둘러주세요.</FONT></TD>
    </TR>
    <TR>
    <TD colspan="2" align="center" bgcolor="ffffff">
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value="가게를 나온다"></TD></form>
	</TD>
    </TR>
  </TBODY>
</TABLE>
<center></center>
EOF
	&footer;
	exit;
	
}
1;
