sub fshop {
	&chara_open;
	&status_print;
	&town_open;
	&equip_open;
	$val_off=0;
	&time_data;

	$date = time();
	open(IN,"./data/free.cgi") or &error("데이터 파일을 열지 않았습니다[$idata].");
	@F_DATA = <IN>;
	close(IN);
	$no=0;
	foreach(@F_DATA){
		($f_no,$f_ki,$f_name,$f_val,$f_dmg,$f_wei,$f_ele,$f_hit,$f_cl,$f_sta,$f_type,$f_flg,$f_id,$f_hname,$f_min,$f_max,$f_p,$f_last,$f_lname,$f_time,$f_pat) =split(/<>/);
		
		if($f_ki ne 3 && $f_sta){$add="(※)";}
		else{$add="";}

		$f_time2=int(($f_time-$date)/3600);
		$f_timec="후$f_time2 시간";
		$rakusatu="?";
		$rakuval="?";
		if($f_time2 < 1){
			$f_time3=int(($f_time-$date)/60);
			$f_timec="후$f_time3분";
		}
		$f_tb="<input type=radio name=no value=$no>";
		if($f_time<$date || $f_max<=$f_p){
			$f_timec="<FONT color=red>종료</FONT>";
			$f_tb="<FONT color=red>종료</FONT>";
			$rakusatu="$f_lname";
			$rakuval="$f_p";
			if($f_last eq $mid || $f_id eq $mid){
				$f_tb="<FONT color=blue>낙찰</FONT>";
				$rtable.="<TR><TD width=5% bgcolor=ffffcc><input type=radio name=no value=$no></TD><TD bgcolor=white><font size=1>$EQU[$f_ki]</font></TD><TD bgcolor=white>$f_name$add</TD><TD bgcolor=white align=right>$f_val Gold</TD><TD bgcolor=white>$f_dmg</TD><TD bgcolor=white>$f_wei</TD><TD bgcolor=white>$ELE[$f_ele]</TD><TD bgcolor=white>$f_hname</TD><TD bgcolor=white>$f_min</TD><TD bgcolor=white>$f_max</TD><TD bgcolor=white>$f_p</TD><TD bgcolor=white>$f_lname</TD><TD bgcolor=white>$f_timec</TD></TR>";
			}
		}
		$ftable.="<TR><TD width=5% bgcolor=ffffcc><font size=1>$f_tb</font></TD><TD bgcolor=white><font size=1>$EQU[$f_ki]</font></TD><TD bgcolor=white><font size=1>$f_name$add</font></TD><TD bgcolor=white align=right><font size=1>$f_val Gold</font></TD><TD bgcolor=white><font size=1>$f_dmg</font></TD><TD bgcolor=white><font size=1>$f_wei</font></TD><TD bgcolor=white><font size=1>$ELE[$f_ele]</font></TD><TD bgcolor=white><font size=1>$f_hname</font></TD><TD bgcolor=white><font size=1>$f_min</font></TD><TD bgcolor=white><font size=1>$f_max</font></TD><TD bgcolor=white><font size=1>$rakuval</font></TD><TD bgcolor=white><font size=1>$rakusatu</font></TD><TD bgcolor=white><font size=1>$f_timec</font></TD></TR>";
		
		$no++;
	}

	open(IN,"./logfile/item/$mid.cgi");
	@ITEM = <IN>;
	close(IN);
	$no2=0;
	foreach(@ITEM){
		($it_no,$it_ki,$it_name,$it_val,$it_dmg,$it_wei,$it_ele,$it_hit,$it_cl,$it_sta,$it_type,$it_flg) =split(/<>/);
		$sel_val=int($it_val/2);
		$ittable.="<TR><TD width=5% bgcolor=ffffcc><input type=radio name=itno value=$no2></TD><TD bgcolor=white><font size=1>$it_name</font></TD><TD bgcolor=white><font size=1>$sel_val</font></TD><TD bgcolor=white><font size=1>$it_dmg</font></TD><TD bgcolor=white><font size=1>$it_wei</font></TD><TD bgcolor=white><font size=1>$ELE[$it_ele]</font></TD><TD bgcolor=white><font size=1>$EQU[$it_ki]</font></TD></TR>";
		$no2++;
	}

	&header;
	
	print <<"EOF";
<TABLE border="0" width="90%" align=center bgcolor="#000000" height="150" CLASS=TC>
  <TBODY>
    <TR>
      <TD colspan="4" align="center" bgcolor="$FCOLOR"><FONT color="#ffffcc">옥션</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="./img/etc/buki.gif"></TD>
      <TD bgcolor="#330000" colspan="3"><FONT color="#ffffcc">[옥션의 점원]<BR>옥션에 어서 오십시오.현재의 출품 리스트는 이하와 같다가 되고 있습니다.<BR>어느 쪽으로 입찰 하십니까?</FONT></TD>
    </TR>
    <TR>
      <TD align=center bgcolor="ffffff" colspan=4 width=100%>
	<font size=1>
	<table border=0 width="100%" bgcolor=$FCOLOR CLASS=TC>
	<tr><td colspan=12 align=center><font color=ffffcc>출품 리스트</font></td></tr>
	<tr>
	<td bgcolor=ffffcc></td>
	<td bgcolor=white><font size=1>종류</font></td>
	<td bgcolor=white><font size=1>이름</font></td>
	<td bgcolor=white><font size=1>가격</font></td>
	<td bgcolor=white><font size=1>위력</font></td>
	<td bgcolor=white><font size=1>무게</font></td>
	<td bgcolor=white><font size=1>속성</font></td>
	<td bgcolor=white><font size=1>출품자</font></td>
	<td bgcolor=white><font size=1>최저 낙찰액</font></td>
	<td bgcolor=white><font size=1>즉결 가격</font></td>
	<td bgcolor=white><font size=1>현재 입찰액</font></td>
	<td bgcolor=white><font size=1>최종 입찰자</font></td>
	<td bgcolor=white><font size=1>기한</font></td>
	</tr>
	<form action="./town.cgi" method="post">
	$ftable
	<TR><TD colspan=13 align=center bgcolor="ffffff">
	입찰 금액：<INPUT type=txt name=gold size=10>0000Gold<br>
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=hidden name=itype value=$itype>
	<INPUT type=hidden name=mode value=fbid>
	<INPUT type=submit CLASS=FC value=입찰></TD></TR></form>
	</FONT>

	<tr><td colspan=13 align=center><font color=ffffcc>낙찰 상품/비낙찰물 리스트</font></td></tr>
	<form action="./town.cgi" method="post">
	$rtable
	<TR><TD colspan=13 align=center bgcolor="ffffff">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=hidden name=mode value=fget>
	<INPUT type=submit CLASS=FC value=거래를 실시한다></TD></TR></form>
	</table>
	</TD></TR>
	<tr>
	<TD bgcolor="#ffffff" colspan="6" align=center>
	$STPR<BR>
	<table border=0 width="90%" align=center bgcolor=$FCOLOR CLASS=TC>
	<BR>
	<TR><td colspan=7 align=center bgcolor="$FCOLOR"><font color=ffffcc>소지품 리스트</font></td></tr>
	<TR>
	<TD bgcolor=ffffcc></TD><td bgcolor=white><font size=1>이름</font></td><td bgcolor=white><font size=1>판매가</font></td><td bgcolor=white><font size=1>위력</font></td><td bgcolor=white><font size=1>무게</font></td><td bgcolor=white><font size=1>속성</font></td><td bgcolor=white><font size=1>종류</font></td>
	</TR>
	<form action="./town.cgi" method="POST">
	$ittable
	<TR><TD colspan=7 align=center bgcolor=ffffff>
	<table border=0 width="50%" align=center bgcolor=$FCOLOR CLASS=TC>
	<tr>
	<TD bgcolor="#ffffff" colspan="3" align=center>
	최저 낙찰액：
	</TD>
	<TD bgcolor="#ffffff" colspan="3" align=center>
	<INPUT type=txt name=mingold size=10>0000Gold<br>
	</TD>
	</tr>
	<TD bgcolor="#ffffff" colspan="3" align=center>
	즉결 가격：
	</TD>
	<TD bgcolor="#ffffff" colspan="3" align=center>
	<INPUT type=txt name=maxgold size=10>0000Gold<br>
	</TD>
	</tr>
	<TD bgcolor="#ffffff" colspan="3" align=center>
	기한：
	</TD>
	<TD bgcolor="#ffffff" colspan="3" align=center>
	<INPUT type=txt name=hour size=10>시간 후<br>
	</TD>
	</tr>
	</table>
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=hidden name=itype value=$itype>
	<INPUT type=hidden name=mode value=fex>
	<INPUT type=submit CLASS=FC value=출품></TD></form>
	</TR></font>
	</table>
	</TD>
    </TR>
    <TR>
    <TD colspan="7" align="center" bgcolor="ffffff">
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value="가게를 나온다"></TD></form>
	</TD>
    </TR>
  </TBODY>
</TABLE>
EOF

	&footer;
	exit;
}
1;

