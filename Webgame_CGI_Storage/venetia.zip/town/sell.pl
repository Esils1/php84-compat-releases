sub sell{
	&chara_open;
	if($in{'itno'} eq ""){&error("올바르게 선택되지 않았습니다.");}
	if($in{'itype'} eq"0"){$mode2="arm";}
	elsif($in{'itype'} eq"1"){$mode2="pro";}
	elsif($in{'itype'} eq"2"){$mode2="acc";}
	elsif($in{'itype'} eq"3"){$mode2="item";}
	
	open(IN,"./logfile/item/$in{'id'}.cgi") or &error("아이템 데이터 파일을 열지 않았습니다.");
	@ITEM = <IN>;
	close(IN);
	($it_no,$it_ki,$it_name,$it_val,$it_dmg,$it_wei,$it_ele,$it_hit,$it_cl,$it_sta,$it_type,$it_flg) =split(/<>/,$ITEM[$in{'itno'}]);
	#if($it_name eq ""){&error("그 아이템은 팔리지 않습니다.");}

	$selgold=int($it_val/2);
	if($it_no eq "rea" && $it_ki eq 3){$selgold=3000000;}
	elsif($it_no eq "rea"){$selgold=10000000;}
			
	$mgold+=int($selgold);
	splice(@ITEM,$in{'itno'},1);

	open(OUT,">./logfile/item/$in{'id'}.cgi");
	print OUT @ITEM;
	close(OUT);

	&chara_input;
	&header;
	
print <<"EOF";
<TABLE border="0" width="80%" align=center bgcolor="#000000" height="150" CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="$FCOLOR"><FONT color="$FCOLOR2">$EQU[$in{'itype'}]가게</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="$FCOLOR2" width=20% align=center><img src="./img/etc/buki.gif"></TD>
      <TD bgcolor="#330000"><FONT color="$FCOLOR2">[$EQU[$in{'itype'}]가게의 점원]<BR>$it_name를 파시는 건가요? $selgold Gold입니다. 감사합니다.</FONT></TD>
    </TR>
    <TR>
    <TD colspan="2" align="center" bgcolor="ffffff">
	<form action="./town.cgi" method="POST">
	<INPUT type=hidden name=mode value=$mode2>
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value="판매장에 돌아온다"></TD></form>
	</TD>
    </TR>
  </TBODY>
</TABLE>
<center></center>
EOF

	&footer;
	exit;
	
}
1;
