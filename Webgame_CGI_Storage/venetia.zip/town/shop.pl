sub shop {
	&chara_open;
	&status_print;
	&town_open;
	&equip_open;
	$val_off=0;
	if($mcon eq $town_con && $town_con ne 0){
		$val_off=int($mcex/100)+1;
		if($val_off>15){$val_off=15;}
		$mes="<BR>야, $mname씨가 아닌가. 특별히<font color=red>$val_off%</font>깎아 드리죠.";
	}

	if($in{'mode'} eq"arm"){$idata="arm";$itype=0;$dev=$town_arm;}
	elsif($in{'mode'} eq"pro"){$idata="pro";$itype=1;$dev=$town_pro;}
	elsif($in{'mode'} eq"acc"){$idata="acc";$itype=2;$dev=$town_acc;}
	elsif($in{'mode'} eq"item"){$idata="item";$itype=3;$dev=$town_ind;}
	else{&error("올바르게 선택되지 않았습니다.");}
	open(IN,"./data/$idata.cgi") or &error("장비 데이터 파일을 열지 않았습니다[$idata].");
	@ARM_DATA = <IN>;
	close(IN);
	$no=0;
	foreach(@ARM_DATA){
		($arm_name,$arm_val,$arm_dmg,$arm_wei,$arm_ele,$arm_hit,$arm_cl,$arm_sta,$arm_type,$arm_pos) =split(/<>/);
		$arm_val2=$arm_val;
		$arm_val=int($arm_val*(1-$val_off/100));
		if(($town_id eq $arm_pos || $arm_pos eq"all") && $arm_val2>0 && ($arm_val2<=($dev*$dev*10+100) ||$dev>=999)){
			if($arm_sta && $in{'mode'} ne "item"){$arm_name="$arm_name(※)";}
			$armtable.="<TR><TD width=5% bgcolor=ffffcc><input type=radio name=no value=$no></TD><TD bgcolor=white><font size=2>$arm_name</font></TD><TD bgcolor=white align=right><font size=2>$arm_val Gold</font></TD><TD bgcolor=white><font size=2>$arm_dmg</font></TD><TD bgcolor=white><font size=2>$arm_wei</font></TD><TD bgcolor=white><font size=2>$ELE[$arm_ele]</font></TD><TD bgcolor=white><font size=2>$arm_type</font></TD></TR>";
		}
		$no++;
	}
	if($town_con>=0){
		open(IN,"./data/carm.cgi");
		@CARM = <IN>;
		close(IN);
		foreach(@CARM){
			($arm_t,$arm_name,$arm_val,$arm_dmg,$arm_wei,$arm_ele,$arm_hit,$arm_cl,$arm_sta,$arm_type,$arm_pos) =split(/<>/);
			$arm_val=int($arm_val*(1-$val_off/100));
			if(($town_id eq $arm_pos && $arm_t eq $itype) && $arm_val>0 && ($arm_val<=($dev*$dev*10+100) || $dev>=999)){
				if($arm_sta){$arm_name="$arm_name(※)";}
				$armtable.="<TR><TD width=5% bgcolor=ffffcc><input type=radio name=no value=$no></TD><TD bgcolor=white><font size=2>$arm_name</font></TD><TD bgcolor=white align=right><font size=2>$arm_val Gold</font></TD><TD bgcolor=white><font size=2>$arm_dmg</font></TD><TD bgcolor=white><font size=2>$arm_wei</font></TD><TD bgcolor=white><font size=2>$ELE[$arm_ele]</font></TD><TD bgcolor=white><font size=2>$arm_type</font></TD></TR>";
			}
			$no++;
		}
	}

	open(IN,"./logfile/item/$mid.cgi");
	@ITEM = <IN>;
	close(IN);
	$no2=0;
	foreach(@ITEM){
		($it_no,$it_ki,$it_name,$it_val,$it_dmg,$it_wei,$it_ele,$it_hit,$it_cl,$it_sta,$it_type,$it_flg) =split(/<>/);
		$sel_val=int($it_val/2);
		if($it_no eq "rea" && $it_ki eq 3){$sel_val=3000000;}
		elsif($it_no eq "rea"){$sel_val=10000000;}
		$ittable.="<TR><TD width=5% bgcolor=ffffcc><input type=radio name=itno value=$no2></TD><TD bgcolor=white><font size=2>$it_name</font></TD><TD bgcolor=white><font size=2>$sel_val</font></TD><TD bgcolor=white><font size=2>$it_dmg</font></TD><TD bgcolor=white><font size=2>$it_wei</font></TD><TD bgcolor=white><font size=2>$ELE[$it_ele]</font></TD><TD bgcolor=white><font size=2>$EQU[$it_ki]</font></TD></TR>";
		$no2++;
	}

	&header;
	
	print <<"EOF";
<TABLE border="0" width="90%" align=center bgcolor="#000000" height="150" CLASS=TC>
  <TBODY>
    <TR>
      <TD colspan="3" align="center" bgcolor="$FCOLOR"><FONT color="#ffffcc">$EQU[$itype]가게</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="./img/etc/buki.gif"></TD>
      <TD bgcolor="#330000" colspan="3"><FONT color="#ffffcc">[$EQU[$itype]가게의 점원]<BR>어서오세요. 좋은 것이 갖추어져 있습니다.$mes<BR>골라보세요^^</FONT></TD>
    </TR>
    <TR>
      <TD align=center bgcolor="ffffff" colspan=2 width=55%>
	<table border=0 width="100%" bgcolor=$FCOLOR CLASS=TC>
	<tr><td colspan=6 align=center><font color=ffffcc>상품 리스트</font></td></tr>
	<tr>
	<td bgcolor=ffffcc></td><td bgcolor=white>이름</td><td bgcolor=white>가격</td><td bgcolor=white>위력</td><td bgcolor=white>무게</td><td bgcolor=white>속성</td><td bgcolor=white>종류</td>
	</tr>
	<form action="./town.cgi" method="post">
	$armtable
	<TR><TD colspan=7 align=center bgcolor="ffffff">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=hidden name=itype value=$itype>
	<INPUT type=hidden name=mode value=buy>
	<INPUT type=submit CLASS=FC value=구입></TD></TR></form>
	</table>
	
	<TD bgcolor="#ffffff" align=center>
	$STPR<BR>
	<table colspan=3 width=90% align=center CLASS=MC>
	<tr><td bgcolor="$ELE_BG[$mele]"><font color=ffffcc>종류</font></td><td bgcolor="$ELE_BG[$mele]"><font color=ffffcc>이름</font></td><td bgcolor="$ELE_BG[$mele]"><font color=ffffcc>위력/무게</font></td></tr>
	<tr><td bgcolor="$ELE_C[$mele]">무기</td><td bgcolor="$ELE_C[$mele]">$marmname</td><td bgcolor="$ELE_C[$mele]">$marmdmg/$marmwei</td></tr>
	<tr><td bgcolor="$ELE_C[$mele]">방어구</td><td bgcolor="$ELE_C[$mele]">$mproname</td><td bgcolor="$ELE_C[$mele]">$mprodmg/$mprowei</td></tr>
	<tr><td bgcolor="$ELE_C[$mele]">악세사리</td><td bgcolor="$ELE_C[$mele]">$maccname</td><td bgcolor="$ELE_C[$mele]">$maccdmg/$maccwei</td></tr>
	</table>
	<table border=0 width="90%" align=center bgcolor=$FCOLOR CLASS=TC>
	<BR>
	<TR><td colspan=7 align=center bgcolor="$FCOLOR"><font color=ffffcc>소지품 리스트</font></td></tr>
	<TR>
	<TD bgcolor=ffffcc></TD><td bgcolor=white><font size=2>이름</font></td><td bgcolor=white><font size=2>판매가</font></td><td bgcolor=white><font size=2>위력</font></td><td bgcolor=white><font size=2>무게</font></td><td bgcolor=white><font size=2>속성</font></td><td bgcolor=white><font size=2>종류</font></td>
	</TR>
	<form action="./town.cgi" method="POST">
	$ittable
	<TR><TD colspan=7 align=center bgcolor=ffffff>
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=hidden name=itype value=$itype>
	<INPUT type=hidden name=mode value=sell>
	<INPUT type=submit CLASS=FC value=판다></TD></form>
	</TR></font>
	</table>
	</TD>
    </TR>
    <TR>
    <TD colspan="3" align="center" bgcolor="ffffff">
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value="가게를 나온다"></TD></form>
	</TD>
    </TR>
  </TBODY>
</TABLE>
EOF

	&footer;
	exit;
}
1;

