sub hinn{
	&header;
	&chara_open;
	&town_open;
	&status_print;

	$hinn_gold=int($mmaxhp+$mmaxmp+$mstr+$mvit+$mint+$mdex+$mfai+$magi)*5000;
	if($hinn_gold<1000000){$hinn_gold=1000000;}
	
	print <<"EOF";
<TABLE border="0" width="80%" bgcolor="#ffffff" height="150" align=center CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">고급 여관</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="./img/etc/inn2.gif"></TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc">어서 오십시오, $mname씨.이런, 건강이 없음 그렇네요?<BR>부디당여관의 온천에 잠겨, 최고의 요리를 드셔 파워업 해 주세요.<BR>일박 $hinn_gold Gold가 됩니다만 좋습니까?</FONT></TD>
    </TR>
    <TR>
      <TD colspan="2" align="right">
	$STPR
	<form action="./town.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=hidden name=mode value=hinn2>
	<INPUT type=submit CLASS=FC value="여관에 묵는다"></form>

	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value="여관을 나온다"></form></TD>
	
    </TR>
  </TBODY>
</TABLE>
EOF
	&footer;
	exit;
}
1;

