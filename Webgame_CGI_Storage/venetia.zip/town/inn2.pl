sub inn2{
	&header;
	&chara_open;
	&town_open;

	$inn_gold=int($mmaxhp+$mmaxmp+($mstr+$mvit+$mint+$mdex+$mfai+$magi)/3);
	if($inn_gold<5){$inn_gold=5;}
	$mhp=$mmaxhp;
	$mmp=$mmaxmp;
	if($mgold<$inn_gold){
		$mbank-=$inn_gold;
		if($mbank<0){$mbank=0;}
		
	}else{
		$mgold-=$inn_gold;
		if($mgold<0){$mgold=0;}
	}
	&town_input;
	open(IN,"./logfile/battle/$in{'id'}.cgi");
	@BC_DATA = <IN>;
	close(IN);
	($mhpr,$mmpr,$mtim)=split(/<>/,$BC_DATA[0]);

	$date = time();
	$rec = int(($date - $mtim)/12)/100;
	$mhpr+=$rec;
	$mmpr+=$rec;
	if($mhpr>1){$mhpr=1;}
	if($mmpr>1){$mmpr=1;}
	
	@N_BC=();
	unshift(@N_BC,"$mhpr<>$mmpr<>$date<>\n");
	open(OUT,">./logfile/battle/$in{'id'}.cgi");
	print OUT @N_BC;
	close(OUT);

	print <<"EOF";
<TABLE border="0" width="80%" bgcolor="#ffffff" height="150" align=center CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">여관</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="./img/etc/inn2.gif"></TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc">$mname는(은) 숙소에서 묵었습니다.<BR>HP와 MP가 회복되었습니다.<BR>건강도가 회복되었습니다.</FONT></TD>
    </TR>
    <TR>
      <TD colspan="2" align="right">
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value=돌아온다></form></TD>
	
    </TR>
  </TBODY>
</TABLE>
EOF
	&chara_input;
	&footer;
	exit;
}
1;
