sub bank {
	&chara_open;
	&header;
	&status_print;
	$inn_gold=int(($mmaxhp-20) /3+$mmaxmp/3+($mstr+$mvit+$mint+$mdex+$mfai+$magi)/5);
	if($inn_gold<5){$inn_gold=5;}
	if($mgold<$inn_gold && $mbank<$inn_gold){$mes="돈을 가지고 있지 않은 것 같네요.이번은 특별 서비스로 해요.";}
	print <<"EOF";
<TABLE border="0" width="80%" align=center bgcolor="#ffffff" height="150" CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">은행</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="./img/etc/pub.gif"></TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc">어서 오십시오, $mname씨.현재맡아 하고 있는 금액은 $mbank Gold가 되고 있습니다.<BR>오늘은 어떤 용건입니까?</FONT></TD>
    </TR>
    <TR>
      <TD colspan="2" align="center">
	$STPR
	<BR>
	<현재의 예금액：$mbank Gold>
	<form action="./town.cgi" method="post">
	<INPUT type=text size=5 name=azuke>0000Gold
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=hidden name=mode value=banka>
	<INPUT type=submit value=맡긴다 CLASS=MFC></form>
	<form action="./town.cgi" method="post">
	<INPUT type=hidden name=azuke value=$mgold>
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=hidden name=mode value=bankall>
	<INPUT type=submit value="전액 맡긴다" CLASS=MFC></form>
	<form action="./town.cgi" method="post">
	<INPUT type=text size=5 name=hiki>0000Gold
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=hidden name=mode value=bankh>
	<INPUT type=submit value=꺼낸다 CLASS=MFC></form>
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value="은행을 나온다"></form></TD>
	
    </TR>
  </TBODY>
</TABLE>
EOF

	&footer;
	exit;
}
1;

