sub battle_entry{
	&chara_open;
	&status_print;
	&time_data;

	$start_time="13";

	&conv;

	open(IN,"./data/entry_list.cgi") or &error("등록자 리스트가 열리지 않습니다.");
	@ENTRY = <IN>;
	close(IN);

	$en=0;
	$entry_list.="<table class=TC width=80%>";
	$entry_list.="<tr><td colspan=6 align=center><font color=$FCOLOR2>등록자 일람</font></td></tr><tr>";
	foreach(@ENTRY){
		($eid,$ename,$echara,$econ,$ecname,$ecele,$epoint,$eflg) =split(/<>/);
		$entry_list.="<td bgcolor=$ELE_BG[$ecele] align=center><font color=$ELE_C[$ecele]>$ename<BR>\능\력치 :$epoint</font></td>";
		$entry_list2.="<td bgcolor=$ELE_C[$ecele] align=center><img src=\"./img/chara/$echara.gif\"></td>";
		$en++;
		if($en%6 eq 0){
			$entry_list.="</tr><tr>$entry_list2</tr><tr>";
			$entry_list2="";
		}
	}
	$entry_list.="</tr><tr>$entry_list2</tr><tr>";
	$entry_list.="</tr></table>";


	open(IN,"./data/winner_list.cgi") or &error("등록자 리스트가 열리지 않습니다.");
	@WINNER = <IN>;
	close(IN);
	$win=1;
	$win_list.="<table class=TC width=80%>";
	$win_list.="<tr><td colspan=4 align=center><font color=$FCOLOR2>제$btotal회천하 제일 무도회 시합 결과</font></td></tr>";
	
	foreach(@WINNER){
		($fid,$fchara,$fname,$ename,$fcon,$ctype,$ctime) =split(/<>/);
		$win_list.="<tr>";
		$win_list.="<td bgcolor=000000 align=center><font color=ffffff>$ctype</font></td>";
		$win_list.="<td bgcolor=$FCOLOR2 align=center><font color=000000>$fname VS $ename</font></td>";
		$win_list.="<td bgcolor=$FCOLOR2 align=center><font color=000000>승자：$fname</font></td>";
		$win_list.="<td bgcolor=$FCOLOR2 align=center><font color=000000><a href=./data/battle/$win.html target=blank>시합 결과</a></font></td></tr>";
		
		$win++;
	}
	$win_list.="</table>";

	&header;
	
	print <<"EOF";
<TABLE border="0" width="80%" align=center bgcolor="#ffffff" height="150" CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">천하 제일 무도회 등록 회장</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="./img/etc/arena.jpg"></TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc">천하 제일 무도회에 어서 오십시오!<BR>주에 한 번, 최강을 결정하는 대회가 열려!<BR>팔에 자신이 있다면 자꾸자꾸 참가해.<BR>다만 참가예\약\자가 16명 이상의 경우,\능\력의 낮은 사람은 대회에 나올 수 없는 것도 있지만 낙심하지 말아줘.<BR></FONT></TD>
    </TR>
    <TR>
      <TD colspan="2" align="center">
	$entry_list
	$win_list
	<font size=4 color=red><b>※$com</b></font>
	<form action="./town.cgi" method="post">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=hidden name=mode value=battle_entry2>
	<INPUT type=submit value=엔트리 CLASS=FC></form>
	<form action="./town.cgi" method="post">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=hidden name=mode value=entry_can>
	<INPUT type=submit value=등록 해제 CLASS=FC></form>
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value=그만둔다></form></TD>
	
    </TR>
  </TBODY>
</TABLE>
<center></center>
EOF

	&footer;
	exit;
}
sub conv{
	open(IN,"./data/entry_list.cgi") or &error("등록자 리스트가 열리지 않습니다.");
	@ENTRY = <IN>;
	close(IN);
	$entry_cou=@ENTRY;

	open(IN,"./data/battle_time.cgi") or &error("타임 데이터가 열리지 않습니다.");
	@BTIME = <IN>;
	close(IN);
	($btime,$bcount,$btotal,$blast,$bflg) =split(/<>/,$BTIME[0]);
	if(!$wday && $hour>=$start_time){
		$date = time();
		$convt = $CONV - $date + $btime;
		$convt2=int($convt/60);
		if($convt>0 && $entry_cou>1){$com="다음의 시합까지 $convt2분 ($convt 초) 기다려 주세요.";}
		elsif($entry_cou>1){
			$com="시합을 했습니다!";
			require'./battle/tenka.pl';
			&tenka;
		}else{
			$com="모든 시합이 종료했습니다.";
		}
	}elsif(!$wday && $hour<$start_time && !$bflg && $entry_cou>1){
		$bflg=1;

		@tmp = map {(split /<>/)[6]} @ENTRY;
		@ENTRY = @ENTRY[sort {$tmp[$b] <=> $tmp[$a]} 0 .. $#tmp];

		@N_ENTRY=();
		foreach(@ENTRY){
			($e_id,$e_name,$e_chara,$e_con,$e_cname,$e_cele,$e_point,$e_flg) =split(/<>/);
			$convrand=int(rand(5));
			if($convrand eq 1){$ok_list1.="$_";}
			elsif($convrand eq 2){$ok_list2.="$_";}
			elsif($convrand eq 3){$ok_list3.="$_";}
			elsif($convrand eq 4){$ok_list4.="$_";}
			else{$ok_list5.="$_";}
			$ent++;
			if($ent>=16){last;}
		}
		$ok_list.="$ok_list1";
		$ok_list.="$ok_list2";
		$ok_list.="$ok_list3";
		$ok_list.="$ok_list4";
		$ok_list.="$ok_list5";

		open(OUT,">./data/entry_list.cgi") or &error("등록자 데이터가 열리지 않습니다.");
		print OUT $ok_list;
		close(OUT);

		@N_TIMEDATA=();
		push(@N_TIMEDATA,"$btime<>$bcount<>$btotal<>$blast<>$bflg<>\n");
		open(OUT,">./data/battle_time.cgi") or &error('데이터를 쓸 수 없습니다.');
		print OUT @N_TIMEDATA;
		close(OUT);

		@N_WIN=();
		open(OUT,">./data/winner_list.cgi") or &error('데이터를 쓸 수 없습니다.');
		print OUT @N_WIN;
		close(OUT);

		$com="등록자를 상훌 했습니다.";
	}else{
		$com="대회는 일요일의$start_time시부터 개최됩니다.";
	}
}
1;

