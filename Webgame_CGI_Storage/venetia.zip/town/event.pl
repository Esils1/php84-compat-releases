sub event{
	&chara_open;
	&town_open;
	&status_print;

	if($moya%300 ne 1){
		&maplog("[부정]$mname는 이벤트로 부정을 실시했습니다.");
		&error("부정을 실시했습니다.");
	}
	$par= int($moya/300)%3;

	#귀신 퇴치
	if($par eq 0){
         	$button="<form action=./town.cgi method=POST><INPUT type=hidden name=id value=$mid><INPUT type=hidden name=pass value=$mpass><INPUT type=hidden name=mode value=event2><INPUT type=submit CLASS=FC value=퇴치한다></form>";
		$mes="거리에서 누군가가 날뛰고 있다.<BR>거리의 사람이 도움을 요구하고 있습니다.퇴치합니까?";
	#적
	}elsif($par eq 1 && $mflg3<=5){
         	if($mflg3 <= 0){
			$button="<form action=./town.cgi method=POST><INPUT type=hidden name=id value=$mid><INPUT type=hidden name=pass value=$mpass><INPUT type=hidden name=mode value=event2><INPUT type=submit CLASS=FC value=도전한다></form>";
			$mes="[술집]<BR>계(오)세요, 병사.<BR>창의나 너, 알고 있어 있어?<BR>바로 최근 여성이 마귀에 데려 가로채진 것 같다.<BR>마귀는 그 파브니르산의 정상에 서 그리고 있다고 한다.<BR>지금까지 그 산으로 향해 돌아온 사람은 없다고 듣지만, 그런데도 도전해 볼까?";
			$img="pub";
		}elsif($mflg3 > 0 && $mflg3<=5){
			$mes=$EMES[$mflg3];
			$img=$EIMG[$mflg3];
		}
	#외출
	}else{
         	$mes="$mname는 나가기로 했다.";
		$button="<form action=./town.cgi method=POST><INPUT type=hidden name=id value=$mid><INPUT type=hidden name=pass value=$mpass><INPUT type=hidden name=mode value=event2><INPUT type=submit CLASS=FC value=나간다></form>";
	}
	&header;
	
	print <<"EOF";
<TABLE border="0" width="80%" bgcolor="#ffffff" height="150" align=center CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">이벤트</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="./img/etc/$img.gif"></TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc">$mes</FONT></TD>
    </TR>
    <TR>
      <TD colspan="2" align="right">
	$STPR
	$button
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value=돌아온다></form></TD>
	
    </TR>
  </TBODY>
</TABLE>
EOF
	&chara_input;
	&footer;
	exit;
}
1;

