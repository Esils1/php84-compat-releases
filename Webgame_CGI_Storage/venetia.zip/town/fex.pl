sub fex{
	&chara_open;
	&time_data;
	if($in{'itno'} eq ""){&error("올바르게 선택되지 않았습니다.");}
	if($in{'mingold'} eq "" || $in{'maxgold'} eq "" ||  $in{'hour'} eq ""){&error("최저 낙찰액, 즉결 금액, 기한이 입력되고 있지 않습니다.");}
	if($in{'maxgold'} <= $in{'mingold'}){&error("최저 낙찰액에 즉결 금액을 넘는 값은 입력할 수 없습니다.");}
	if($in{'mingold'} <1 || $in{'maxgold'} < 1 || $in{'hour'} < 1){&error("성실하게 입력해 주세요.");}
	if($in{'hour'} > 480){&error("기한은 최대로 20일 뒤에까지입니다.");}
	
	$date = time();
	
	$mingold=$in{'mingold'}*10000;
	$maxgold=$in{'maxgold'}*10000;
	$lastdate=$date + $in{'hour'}*3600;
	
	open(IN,"./logfile/item/$in{'id'}.cgi") or &error("아이템 데이터 파일을 열지 않았습니다.");
	@ITEM = <IN>;
	close(IN);
	($it_no,$it_ki,$it_name,$it_val,$it_dmg,$it_wei,$it_ele,$it_hit,$it_cl,$it_type,$it_sta,$it_flg) =split(/<>/,$ITEM[$in{'itno'}]);
	
	$xit_val=$it_val*3;
	if($maxgold > $xit_val && $it_val ne 0){
		&error("그것에서는 밤입니다.매너는 지킵시다.");
	}

	open(IN,"./data/free.cgi") or &error("데이터 파일을 열지 않았습니다.");
	@FREE = <IN>;
	close(IN);

	foreach(@FREE){
		($f2_no,$f2_ki,$f2_name,$f2_val,$f2_dmg,$f2_wei,$f2_ele,$f2_hit,$f2_cl,$f2_type,$f2_sta,$f2_flg,$f2_id,$f2_hname,$f2_min,$f2_max,$f2_p,$f2_last,$f2_lname,$f2_time,$f2_pat) =split(/<>/);
		if($mid eq "$f2_id"){
			&error("동시에 복수의 출품은 할 수 없습니다.");
		}
	}
	
	&maplog("<font color=green>[출품]</font>$mname는<font color=red>$it_name($it_dmg/$it_wei)</font>를 최저 금액<font color=red>$mingold Gold</font>, 즉결 금액<font color=red>$maxgold Gold</font>로 출품했습니다.");
	
	push(@FREE,"$it_no<>$it_ki<>$it_name<>$it_val<>$it_dmg<>$it_wei<>$it_ele<>$it_hit<>$it_cl<>$it_type<>$it_sta<>$it_flg<>$mid<>$mname<>$mingold<>$maxgold<>0<>$mid<><>$lastdate<>$pat<>\n");
	open(OUT,">./data/free.cgi");
	print OUT @FREE;
	close(OUT);

	splice(@ITEM,$in{'itno'},1);

	open(OUT,">./logfile/item/$in{'id'}.cgi");
	print OUT @ITEM;
	close(OUT);

	&chara_input;
	&header;
	
print <<"EOF";
<TABLE border="0" width="80%" align=center bgcolor="#000000" height="150" CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="$FCOLOR"><FONT color="$FCOLOR2">옥션</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="$FCOLOR2" width=20% align=center><img src="./img/etc/buki.gif"></TD>
      <TD bgcolor="#330000"><FONT color="$FCOLOR2">[옥션의 점원]<BR>$it_name를 최저 금액 $mingold Gold, 즉결 금액 $maxgold Gold, 기한은 $in{'hour'}시간 다음에 출품이군요, 이해했습니다.</FONT></TD>
    </TR>
    <TR>
    <TD colspan="2" align="center" bgcolor="ffffff">
	<form action="./town.cgi" method="POST">
	<INPUT type=hidden name=mode value=fshop>
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value="마켓에 돌아온다"></TD></form>
	</TD>
    </TR>
  </TBODY>
</TABLE>
<center></center>
EOF

	&footer;
	exit;
	
}
1;
