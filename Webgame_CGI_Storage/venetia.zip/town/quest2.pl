sub quest2{
	&chara_open;
	&town_open;
	&status_print;

	require './data/quest.cgi';

	if ($in{'q'} eq "cancel") {
		$mquest="";
		$mquest2="";
		$mes="퀘스트를 취소했습니다.";
	}
	else {
		$mquest="$in{'q'}";
		$mquest2="";
		$mes="퀘스트를 수락했습니다.<br>「잘 부탁해요~」";
	}

	&chara_input;
	&header;
	
	print <<"EOF";
<TABLE border="0" width="80%" bgcolor="#ffffff" height="150" align=center CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">이벤트</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="./img/etc/inn.gif"></TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc">$mes</FONT></TD>
    </TR>
    <TR>
      <TD colspan="2" align="right">
	$STPR
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value=돌아온다></form></TD>
	
    </TR>
  </TBODY>
</TABLE>
EOF
	&chara_input;
	&footer;
	exit;
}
1;

