sub rbuy {
	&chara_open;
	&town_open;
	$val_off=0;
	if($mcon eq $town_con && $town_con ne 0){
		$val_off=int($mcex/100)+1;
		if($val_off>15){$val_off=15;}
	}
	$idata="ritem";
	if($in{'no'} eq ""){&error("올바르게 선택되지 않았습니다.");}
	if($moya%1000 ne "1"){
		&maplog("<font color=red>[부정]</font>$mname는 마녀의 가게에서 부정을 실시했습니다.");
		&error("부정을 실시했습니다.");
	}

	open(IN,"./data/$idata.cgi") or &error("장비 데이터 파일을 열지 않았습니다.");
	@it_data = <IN>;
	close(IN);
	$it_num=@it_data;
	$num=$in{'no'};
	if($it_num>$num){
		($it_name,$it_val,$it_dmg,$it_wei,$it_ele,$it_hit,$it_cl,$it_type,$it_sta,$it_pos) =split(/<>/,$it_data[$in{'no'}]);
	}
	$it_val=int($it_val*(1-$val_off/100));
	
	if($mgold<$it_val){&error("돈이 충분하지 않습니다.");}
	$mgold-=$it_val;

	$townget=$town_ind/300;
	$town_gold+=int($it_val/((1500-$town_ind)/250));
	
	open(IN,"./logfile/item/$in{'id'}.cgi");
	@ITEM = <IN>;
	close(IN);
	if(@ITEM>=$ITM_MAX){&error("더 이상 가질 수 없습니다.(최대$ITM_MAX개)");}

	push(@ITEM,"$in{'no'}<>3<>$it_name<>$it_val<>$it_dmg<>$it_wei<>$it_ele<>$it_hit<>$it_cl<>$it_type<>$it_sta<>$it_flg<>\n");
	open(OUT,">./logfile/item/$in{'id'}.cgi");
	print OUT @ITEM;
	close(OUT);

	&maplog("<font color=blueviolet>[구입]</font>$mname는 마녀의 가게에서 쇼핑을 했습니다.");
	$moya=int(rand(10000));
	&chara_input;
	&town_input;

	&header;
	
	print <<"EOF";
<TABLE border="0" width="80%" align=center height="150" CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="$FCOLOR"><FONT color="$FCOLOR2">마녀의 가게</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="$FCOLOR2" width=20% align=center><img src="./img/etc/inn.gif"></TD>
      <TD bgcolor="#330000"><FONT color="$FCOLOR2">[마녀의 가게의 마녀]<BR>$it_name인가.$ames<br>$it_val Gold구나.소중하게 사용인.이봐요.</FONT></TD>
    </TR>
    <TR>
    <TD colspan="2" align="center" bgcolor="ffffff">
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value="가게를 나온다"></TD></form>
	</TD>
    </TR>
  </TBODY>
</TABLE>
<center></center>
EOF
	&footer;
	exit;
	
}
1;
