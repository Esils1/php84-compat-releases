sub arena {
	&chara_open;
	&header;
	&status_print;
	$arena_gold=10000;
	if($mgold<$arena_gold){
		$mes="야, 돈을 가지지 않지 않은가.다시 해 오는거야.";
	}
	open(IN,"./data/chanp.cgi") or &error("체프데이타가 열리지 않습니다.");
	@CHANP = <IN>;
	close(IN);
	($eid,$ename,$echara,$eele,$ehp,$emaxhp,$emp,$emaxmp,$estr,$evit,$eint,$efai,$edex,$eagi,$earm,$epro,$eacc,$etec,$esk,$etype,$eclass,$emes,$eex,$egold,$eren) =split(/<>/,$CHANP[0]);
	$elv = int($eex/100)+1;
	&equip_open;
	if($eid ne $mid && $mgold>=$arena_gold){
		$form= <<"EOF";
		<form action="./battle.cgi" method="post">
		<INPUT type=hidden name=id value=$mid>
		<INPUT type=hidden name=pass value=$mpass>
		<INPUT type=hidden name=mode value=battle2>
		<INPUT type=submit value=도전한다($arena_gold\Gold) CLASS=FC></form>
EOF
	}
	print <<"EOF";
<TABLE border="0" width="80%" align=center bgcolor="#ffffff" height="150" CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">투기장</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="./img/etc/arena.jpg"></TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc">어서 오십시오 $mname.여기는 투기장이다.<BR>현재의 체프에 도전해, 이길 수 있으면 상금을 받을 수 있을거야.<BR>1회 $arena_gold Gold다.도전할까?$mes</FONT></TD>
    </TR>
    <TR>
      <td colspan=2>
	<TABLE border="0" align=center width="70%" height="143" CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="5" align="center" bgcolor="$FCOLOR"><font color=$FCOLOR2 size=4>Champion</font></TD>
    </TR>
    <TR>
      <TD colspan="5" class=FC align="center" ><font color=$FCOLOR2><font color=$FCOLOR>현재$eren 연승중 상금：$egold Gold</font></TD>
    </TR>
    <TR>
      <TD rowspan="5" bgcolor="$ELE_C[$eele]" align=center><img src="./img/chara/$echara.gif"></TD>
      <TD bgcolor="$ELE_C[$eele]" align="left">LV</TD>
      <TD bgcolor="$ELE_C[$eele]" align="right">$elv</TD>
      <TD bgcolor="$ELE_C[$eele]">종족</TD>
      <TD bgcolor="$ELE_C[$eele]" align="right">$TYPE[$etype]</TD>
    </TR>
    <TR>
      <TD bgcolor="$ELE_C[$eele]">HP</TD>
      <TD bgcolor="$ELE_C[$eele]" align="right">$ehp/$emaxhp</TD>
      <TD bgcolor="$ELE_C[$eele]">MP</TD>
      <TD bgcolor="$ELE_C[$eele]" align="right">$emp/$emaxmp</TD>
    </TR>
    <TR>
      <TD bgcolor="$ELE_C[$eele]">힘</TD>
      <TD bgcolor="$ELE_C[$eele]" align="right">$estr</TD>
      <TD bgcolor="$ELE_C[$eele]">생명력</TD>
      <TD bgcolor="$ELE_C[$eele]" align="right">$evit</TD>
    </TR>
    <TR>
      <TD bgcolor="$ELE_C[$eele]">지력</TD>
      <TD bgcolor="$ELE_C[$eele]" align="right">$eint</TD>
      <TD bgcolor="$ELE_C[$eele]">정신</TD>
      <TD bgcolor="$ELE_C[$eele]" align="right">$efai</TD>
    </TR>
    <TR>
      <TD bgcolor="$ELE_C[$eele]">운</TD>
      <TD bgcolor="$ELE_C[$eele]" align="right">$edex</TD>
      <TD bgcolor="$ELE_C[$eele]">속도</TD>
      <TD bgcolor="$ELE_C[$eele]" align="right">$eagi</TD>
    </TR>
    <TR>
      <TD bgcolor="$ELE_C[$eele]" align="center">$ename</TD>
      <TD bgcolor="$ELE_C[$eele]">직업</TD>
      <TD bgcolor="$ELE_C[$eele]" align="right">$JOB[$eclass]</TD>
      <TD bgcolor="$ELE_C[$eele]">속성</TD>
      <TD bgcolor="$ELE_C[$eele]" align="right">$ELE[$eele]</TD>
    </TR>
   
    <TR>
      <TD colspan="5" align="center" bgcolor="$FCOLOR"><font color=$FCOLOR2>장비</font></TD>
    </TR>
    <TR>
      <TD bgcolor="$ELE_C[$eele]"></TD>
      <TD colspan="2" bgcolor="$ELE_C[$eele]" align="center">이름</TD>
      <TD bgcolor="$ELE_C[$eele]" align="center">위력</TD>
      <TD bgcolor="$ELE_C[$eele]" align="center">무게</TD>
    </TR>
    <TR>
      <TD bgcolor="$ELE_C[$eele]">무기</TD>
      <TD colspan="2" bgcolor="$ELE_C[$eele]" align="right">$earmname($ELE[$earmele])</TD>
      <TD bgcolor="$ELE_C[$eele]" align="right">$earmdmg</TD>
      <TD bgcolor="$ELE_C[$eele]" align="right">$earmwei</TD>
    </TR>
    <TR>
      <TD bgcolor="$ELE_C[$eele]">방어구</TD>
      <TD colspan="2" bgcolor="$ELE_C[$eele]" align="right">$eproname($ELE[$eproele])</TD>
      <TD bgcolor="$ELE_C[$eele]" align="right">$eprodmg</TD>
      <TD bgcolor="$ELE_C[$eele]" align="right">$eprowei</TD>
    </TR>
    <TR>
      <TD bgcolor="$ELE_C[$eele]">악세사리</TD>
      <TD colspan="2" bgcolor="$ELE_C[$eele]" align="right">$eaccname($ELE[$eaccele])</TD>
      <TD bgcolor="$ELE_C[$eele]" align="right">$eaccdmg</TD>
      <TD bgcolor="$ELE_C[$eele]" align="right">$eaccwei</TD>
    </TR>
    <TR>
      <TD colspan=5 align=center bgcolor="$FCOLOR"><font color=$FCOLOR2>코멘트</font></TD>
    </TR>
　　<TR>
      <TD colspan=5 bgcolor="$ELE_C[$eele]">$emes</TD>
    </TR>
	</table>
      </td>
    </TR>
    <TR>
      <TD colspan="2" align="center">
	$form
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value=돌아온다></form></TD>
	
    </TR>
  </TBODY>
</TABLE>
<center>$STPR</center>
EOF

	&footer;
	exit;
}
1;

