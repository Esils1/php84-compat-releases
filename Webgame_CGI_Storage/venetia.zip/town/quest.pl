sub quest{
	&chara_open;
	&town_open;
	&status_print;

	&header;
	
	print <<"EOF";
<TABLE border="0" width="80%" bgcolor="#ffffff" height="150" align=center CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">퀘스트</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="./img/etc/inn.gif"></TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc">퀘스트를 받을 수 있는 곳입니다.<br>여기에서 주어진 퀘스트는 공개 퀘스트이며, 숨겨진 퀘스트도 있다는거~</FONT></TD>
    </TR>
	<TR><form action="./town.cgi" method="POST">
      <TD colspan="2" align="center">
	<table class=FC width=100%>
	<tr><td colspan=3 bgcolor="#993300"><FONT color="#ffffcc"><center>퀘스트를 선택해주세요</td></tr>
	<tr><td width=5%>
	<input type=radio name=q value="cancel">
	</td>
	<td colspan=2>
	퀘스트 없애기 (이미 진행중인 퀘스트를 취소하고 싶을 경우 선택하세요)
	</td></tr>
	<!-★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★-->
	<tr><td width=5%>
	<input type=radio name=q value="goblin">
	</td>
	<td width=20%>
	고블린 퇴치 작전
	</td>
	<td width=75%>
	안녕하세요. 찬제입니다. 요즘 고블린들이 날뛰고 있다는건 아시죠? 그래서 고블린들을 좀 잡아주셨으며 하는데.. 어떠세요? 딱 500마리만 잡아주세요.
	<b>
	고블린 500마리를 잡아라.
	</b>
	</td></tr>
	<!-★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★-->
	<tr><td width=5%>
	<input type=radio name=q value="incubus">
	</td>
	<td width=20%>
	수집광 월야 [미완성]
	</td>
	<td width=75%>
	黑月夜에요. 하이? 한자 틀릴 수 있지만 제끼셈. 그건 그렇고 제 인큐버스의 날개가 부러진거있죠~ㅠ_ㅠ 그래서 어디론가 사라진것 같긴 한데.. 어디인지... 에휴~ 전투를 하다 보니 잃어버렸으니까, 분명히 어딘가엔 있을거에요 분명! 제 인큐버스의 날개를 찾아와 주실래요~? 보상은 찬제님이 해드린데요[..]
	<b>
	인큐버스의 조각들을 찾아라. 조각들은 5개로 나누어져 있다 (인큐버스의 첫번재 날개, ... 인큐버스의 다섯번째 날개). 전투를 할때 다섯개의 날개가 모두 있으면 된다.
	</b>
	</td></tr>

	</table>
	</TD>
	</TR>
    <TR>
      <TD colspan="2" align="right">
	$STPR
	
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=hidden name=mode value="quest2">
	<INPUT type=submit CLASS=FC value="퀘스트 수락하기"></form>
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value=돌아온다></form></TD>
    </TR>
  </TBODY>
</TABLE>
<br>
<br>
EOF
	&chara_input;
	&footer;
	exit;
}
1;

