sub move2{
	&chara_open;
	&town_open;

	($msk[0],$msk[1]) = split(/,/,$msk);
	if($msk[0] eq "55" || $msk[1] eq "55"){$moveall = 1;}

	if($in{'tid'} eq ""){&error("이동처가 올바르게 선택되지 않았습니다.");}
	$date = time();
	$btime = $BTIME - $date + $mdate;
	if($btime>0){&error("다음의 행동까지 $btime 초 기다려 주세요.");}
	foreach(@TOWN_DATA){
		($town2_id,$town2_name,$town2_con,$town2_ele,$town2_gold,$town2_arm,$town2_pro,$town2_acc,$town2_ind,$town2_tr,$town2_s,$town2_x,$town2_y) =split(/<>/);
		if($in{'tid'} eq $town2_id){last;}
		$tx++;
	}
	if(abs($town2_x-$town_x) > 1 && abs($town2_y-$town_y) > 1 && !$moveall){&error("부정한 액세스입니다.");}
	$mpos=$in{'tid'};
	&chara_input;

	&header;
	
	print <<"EOF";
<TABLE border="0" width="80%" bgcolor="#ffffff" height="150" align=center CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">이동</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="./img/etc/inn2.gif"></TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc">$town2_name에 도착했습니다.</FONT></TD>
    </TR>
    <TR>
      <TD colspan="2" align="right">
	
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value=돌아온다>
	</TD>
	
    </TR>
  </TBODY>
</TABLE>
EOF
	&chara_input;
	&footer;
	exit;
}
1;

