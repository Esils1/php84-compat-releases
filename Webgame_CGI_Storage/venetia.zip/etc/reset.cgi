##############
# Reset Mode #
##############

sub RESET_MODE{

	# MAIN DATA
	$dir="./logfile/chara";
	opendir(dirlist,"$dir");
	while($file = readdir(dirlist)){
		if($file =~ /\.cgi/i){
			unlink("$dir/$file");
		}
	}
	closedir(dirlist);

	# HISTORY DATA
	$dir="./logfile/history";
	opendir(dirlist,"$dir");
	while($file = readdir(dirlist)){
		if($file =~ /\.cgi/i){
			unlink("$dir/$file");
		}
	}
	closedir(dirlist);

	# ITEM DATA
	$dir="./logfile/item";
	opendir(dirlist,"$dir");
	while($file = readdir(dirlist)){
		if($file =~ /\.cgi/i){
			unlink("$dir/$file");
		}
	}
	closedir(dirlist);

	# JOB DATA
	$dir="./logfile/job";
	opendir(dirlist,"$dir");
	while($file = readdir(dirlist)){
		if($file =~ /\.cgi/i){
			unlink("$dir/$file");
		}
	}
	closedir(dirlist);

	# ABILITY DATA
	$dir="./logfile/ability";
	opendir(dirlist,"$dir");
	while($file = readdir(dirlist)){
		if($file =~ /\.cgi/i){
			unlink("$dir/$file");
		}
	}
	closedir(dirlist);

	# OUT DATA
	$dir="./logfile/out";
	opendir(dirlist,"$dir");
	while($file = readdir(dirlist)){
		if($file =~ /\.cgi/i){
			unlink("$dir/$file");
		}
	}
	closedir(dirlist);

	# MESS DATA
	$dir="./logfile/mes";
	opendir(dirlist,"$dir");
	while($file = readdir(dirlist)){
		if($file =~ /\.cgi/i){
			unlink("$dir/$file");
		}
	}
	closedir(dirlist);

	# PROF DATA
	$dir="./logfile/prof";
	opendir(dirlist,"$dir");
	while($file = readdir(dirlist)){
		if($file =~ /\.cgi/i){
			unlink("$dir/$file");
		}
	}
	closedir(dirlist);

	# meslog
	$dir="./meslog";
	opendir(dirlist,"$dir");
	while($file = readdir(dirlist)){
		if($file =~ /\.cgi/i){
			unlink("$dir/$file");
		}
	}
	closedir(dirlist);

	# chat
	$dir="./blog/chat";
	opendir(dirlist,"$dir");
	while($file = readdir(dirlist)){
		if($file =~ /\.cgi/i){
			unlink("$dir/$file");
		}
	}
	closedir(dirlist);

	# conv
	$dir="./blog/conv";
	opendir(dirlist,"$dir");
	while($file = readdir(dirlist)){
		if($file =~ /\.cgi/i){
			unlink("$dir/$file");
		}
	}
	closedir(dirlist);

	# rule
	$dir="./blog/rule";
	opendir(dirlist,"$dir");
	while($file = readdir(dirlist)){
		if($file =~ /\.cgi/i){
			unlink("$dir/$file");
		}
	}
	closedir(dirlist);
	

	# NEW DATA
	@NEW_DATA = ();

	# COUNTRY
	$confile = "./data/country.cgi";
	open(OUT,">$confile");
	print OUT @NEW_DATA;
	close(OUT);

	# TOWNDATA
	open(IN,"./data/towndatabk.cgi") or &error("마을 데이터 파일이 열리지 않습니다.");
	@TOWN_DATA = <IN>;
	close(IN);

	$confile = "./data/towndata.cgi";
	open(OUT,">$confile");
	print OUT @TOWN_DATA;
	close(OUT);

	# BUILD LIST
	open(OUT,">./data/build.cgi");
	print OUT @NEW_DATA;
	close(OUT);

	# CARM LIST
	open(OUT,">./data/carm.cgi");
	print OUT @NEW_DATA;
	close(OUT);

	# DEF LIST
	open(OUT,">./data/def.cgi");
	print OUT @NEW_DATA;
	close(OUT);

	# ENTRY LIST
	open(OUT,">./data/entry_list.cgi");
	print OUT @NEW_DATA;
	close(OUT);

	# GUEST LIST
	open(OUT,">./data/guest_list.cgi");
	print OUT @NEW_DATA;
	close(OUT);

	# MAP LOG LIST
	open(OUT,">./data/maplog.cgi");
	print OUT @NEW_DATA;
	close(OUT);

	# MAP LOG LIST2
	open(OUT,">./data/maplog2.cgi");
	print OUT @NEW_DATA;
	close(OUT);

	# WINNER LIST
	open(OUT,">./data/winner_list.cgi");
	print OUT @NEW_DATA;
	close(OUT);

	
	&maplog("모든 데이터를 초기화했습니다.");
}
sub RESET_MODE2{

	# chat
	$dir="./blog/chat";
	opendir(dirlist,"$dir");
	while($file = readdir(dirlist)){
		if($file =~ /\.cgi/i){
			unlink("$dir/$file");
		}
	}
	closedir(dirlist);

	# conv
	$dir="./blog/conv";
	opendir(dirlist,"$dir");
	while($file = readdir(dirlist)){
		if($file =~ /\.cgi/i){
			unlink("$dir/$file");
		}
	}
	closedir(dirlist);

	# rule
	$dir="./blog/rule";
	opendir(dirlist,"$dir");
	while($file = readdir(dirlist)){
		if($file =~ /\.cgi/i){
			unlink("$dir/$file");
		}
	}
	closedir(dirlist);
	

	# NEW DATA
	@NEW_DATA = ();

	# COUNTRY
	$confile = "./data/country.cgi";
	open(OUT,">$confile");
	print OUT @NEW_DATA;
	close(OUT);

	# TOWN
	open(IN,"./data/towndatabk.cgi") or &error("마을 데이터 파일이 열리지 않습니다.");
	@TOWN_DATA = <IN>;
	close(IN);

	$confile = "./data/towndata.cgi";
	open(OUT,">$confile");
	print OUT @TOWN_DATA;
	close(OUT);

	# BUILD LIST
	open(OUT,">./data/build.cgi");
	print OUT @NEW_DATA;
	close(OUT);

	# CARM
	open(OUT,">./data/carm.cgi");
	print OUT @NEW_DATA;
	close(OUT);

	# DEF LIST
	open(OUT,">./data/def.cgi");
	print OUT @NEW_DATA;
	close(OUT);

	# ENTRY LIST
	open(OUT,">./data/entry_list.cgi");
	print OUT @NEW_DATA;
	close(OUT);

	# GUEST LIST
	open(OUT,">./data/guest_list.cgi");
	print OUT @NEW_DATA;
	close(OUT);

	# MAP LOG LIST
	open(OUT,">./data/maplog.cgi");
	print OUT @NEW_DATA;
	close(OUT);

	# MAP LOG LIST2
	open(OUT,">./data/maplog2.cgi");
	print OUT @NEW_DATA;
	close(OUT);

	# WINNER LIST
	open(OUT,">./data/winner_list.cgi");
	print OUT @NEW_DATA;
	close(OUT);

	&maplog("일부 데이터를 초기화했습니다.");
}
1;

