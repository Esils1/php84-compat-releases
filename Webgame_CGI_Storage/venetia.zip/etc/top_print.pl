sub top_print{
	open(IN,"./data/def.cgi");
	@DEF = <IN>;
	close(IN);
	foreach(@DEF){
		($name,$id,$pos) =split(/<>/);
		if($pos eq "$mpos"){$def_list.="★$name";}
	}
	if(!$mflg){
	##맵 표시
	$tpr="<table bgcolor=663300><TD width=15 height=10 bgcolor=ffffcc CLASS=GC>　</TD>";
	for($i=0;$i<6;$i++){
		$tpr.= "<TD width=15 height=10 bgcolor=ffffcc><font size=1>$i</font></TD>";
	}
	for($i=0;$i<6;$i++){
		$n = $i;
		$tpr.= "<TR><TD bgcolor=ffffcc><font size=1>$n</font></td>";
		for($j=0;$j<6;$j++){
			$m_hit=0;$tx=0;
			foreach(@TOWN_DATA){
				($town2_id,$town2_name,$town2_con,$town2_ele,$town2_gold,$town2_arm,$town2_pro,$town2_acc,$town2_ind,$town2_tr,$town2_s,$town2_x,$town2_y) =split(/<>/);
				if("$town2_x" eq "$j" && "$town2_y" eq "$i"){$m_hit=1;last;}
				$tx++;
			}
			$col="";
			if($m_hit){
				if($town2_id eq $mpos){
					$col = $ELE_C[$CONELE[$town2_con]];
				}else{
					$col = $ELE_BG[$CONELE[$town2_con]];
				}
				if($town2_id eq 0){
					$tpr.= "<TH bgcolor=$col><img src=\"./img/town/m_2.gif\" title=\"$town2_name($ELE[$town2_ele])【$CONNAME[$town2_con]국】\" width=15 height=10></TH>";
				}else{
					$tpr.= "<TH bgcolor=$col><img src=\"./img/town/m_4.gif\" title=\"$town2_name($ELE[$town2_ele])【$CONNAME[$town2_con]국】\" width=15 height=10></TH>";
				}
			}else{
				$tpr.= "<TH>　</TH>";
			}
		}
		$tpr.= "</TR>";
	}
	$tpr.="</table>";
	$tpr2="<TD colspan=2 align=center bgcolor=\"$ELE_C[$con2_ele]\">$tpr</TD>";
                
	}

	$enemy_id = "$town_admin";
	&enemy_open;

	$top_print=<<"_TPR_";
	<TR>
      	<TD align="center">
      	<TABLE border="0" width="100%">
	<TBODY>
          <TR>
            <TD height="38">
            <TABLE  border="0" bgcolor="$ELE_BG[$town_ele]" width=100% CLASS=CC2>
              <TBODY>
		<TR>
            	<TD colspan="11" bgcolor="$ELE_BG[$con2_ele]"><FONT color="#ffffff">$town_name</FONT></TD>
          	</TR>
		<TR><TD colspan="11">
		<TR>
                  <TD align="center" bgcolor="$ELE_C[$con2_ele]" colspan="2"><img src="$timg" width=150 height=120></TD>
		  $tpr2
                  <TD colspan="7" bgcolor="#000000"><FONT color="ffffcc" >
		<span style="font-size:20pt; font-family:바탕; letter-spacing:-2px;">$con2_name국 <font color=red>$town_name</font> (영주: $ename)</span><BR>
                  타민족이 대부분 이주하는 이 거리에서는 많은 주민이 살고 있어,<br>
		마을 전체가 활기에 넘쳐 많은 상인들로 활기차 있다.</FONT></TD>
                </TR>
		<TR>
                  <TD colspan="11"><FONT color="#ffffcc" >$town_name의 정보</FONT></TD>
                </TR><TR>
                  <TD bgcolor="$ELE_C[$con2_ele]" width=12.5%>수익</FONT></TD>
                  <TD  bgcolor="$ELE_C[$con2_ele]" width=12.5%><span style="font-size:8pt;">$town_gold Gold</span></FONT></TD>
                  <TD bgcolor="$ELE_C[$con2_ele]" width=12.5%>지배국</FONT></TD>
                  <TD bgcolor="$ELE_C[$con2_ele]" width=12.5%>$con2_name국</FONT></TD>
                  <TD bgcolor="$ELE_C[$con2_ele]" width=12.5%>소재</FONT></TD>
                  <TD bgcolor="$ELE_C[$con2_ele]" width=12.5%>$town_x - $town_y</FONT></TD>
                  <TD bgcolor="$ELE_C[$con2_ele]" width=12.5%>속성</FONT></TD>
                  <TD bgcolor="$ELE_C[$con2_ele]" width=12.5%>$ELE[$town_ele]</FONT></TD>
                </TR>
                <TR>
                  <TD bgcolor="$ELE_C[$con2_ele]" width=12.5%>무기 개발</FONT></TD>
                  <TD bgcolor="$ELE_C[$con2_ele]" width=12.5%>$town_arm</FONT></TD>
                  <TD bgcolor="$ELE_C[$con2_ele]" width=12.5%>방어구 개발</FONT></TD>
                  <TD bgcolor="$ELE_C[$con2_ele]" width=12.5%>$town_pro</FONT></TD>
                  <TD bgcolor="$ELE_C[$con2_ele]" width=12.5%>악세사리</FONT></TD>
                  <TD bgcolor="$ELE_C[$con2_ele]" width=12.5%>$town_acc</FONT></TD>
                  <TD bgcolor="$ELE_C[$con2_ele]" width=12.5%>산업치</FONT></TD>
                  <TD bgcolor="$ELE_C[$con2_ele]" width=12.5%>$town_ind</font></TD>
                </TR>
                <TR>
                  <TD bgcolor="$ELE_C[$con2_ele]">성벽</FONT></TD>
                  <TD bgcolor="$ELE_C[$con2_ele]">$town_hp/$town_max</FONT></TD>
                  <TD bgcolor="$ELE_C[$con2_ele]">성벽 공격력</FONT></TD>
                  <TD bgcolor="$ELE_C[$con2_ele]">$town_str</FONT></TD>
                  <TD bgcolor="$ELE_C[$con2_ele]">성벽 내구력</FONT></TD>
                  <TD bgcolor="$ELE_C[$con2_ele]">$town_def</FONT></TD>
                  <TD bgcolor="$ELE_C[$con2_ele]"></FONT></TD>
                  <TD bgcolor="$ELE_C[$con2_ele]"></FONT></TD>
                </TR></TBODY>
		</TD>
		</TR>
		<TR>
		<TD colspan=11>
		<font color=$ELE_C[$con2_ele] >거리의 수비</font>
		</TD>
		</TR>
		<TR>
		<TD colspan=11 bgcolor=$ELE_C[$con2_ele]>
		<font color=$ELE_BG[$con2_ele] >$def_list</font>
		</TD>
		</TR><TR>
	    <TD>
	    <TR>
	    <table CLASS=CC width=100%>
	    <TR>
	    <TD width=15% ><font  color=$ELE_C[$con_ele]>$con_name국($ELE[$con_ele])의 자금</font>
	    </TD><TD bgcolor=$ELE_C[$con_ele] width=50% colspan=5 align=right>$con_gold Gold</font></TD>
	    </TR>
	    </table>
	    </TR>
	    </TD>
	    
	  </TR>
              </TBODY>
            </TABLE>
            </TD>
          </TR>
_TPR_
}
1;

