sub mode_change{
	&header;
	&chara_open;

	$list.="<option value=1>맵\표\시없음";
	$list.="<option value=0>맵\표\시 있어";
	$list.="<option value=2>일모드";
	
	print <<"EOF";
<TABLE border="0" width="80%" bgcolor="#ffffff" height="150" align=center CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">\표\시모드 변경</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="./img/etc/inn2.gif"></TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc">\표\시모드를 선택해 주세요.</FONT></TD>
    </TR>
　　<TR>
      <TD colspan="2" align="right">
	<form action="./etc.cgi" method="POST">
	<select name=pmode>
	$list
	</select>
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=hidden name=mode value=mode_change2>
	<INPUT type=submit CLASS=FC value=변경></form>
　　　
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value=돌아온다></form>
　　　</TD>
    </TR>
  </TBODY>
</TABLE>
EOF
	&footer;
	exit;
}
1;

