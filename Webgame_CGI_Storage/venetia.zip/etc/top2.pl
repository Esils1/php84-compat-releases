require './jcode.pl';
require './sub.cgi';
require './conf.cgi';

$tmode="timer";
&decode;
if($ENV{'HTTP_REFERER'} !~ /cgi$/ ){ &error2("주소 바에 값을 입력하지 말아 주세요."); }

if($tmode eq"timer"){&top;}

sub top{
&chara_open;
&town_open;
&con_open;
&guest_list;
&time_data;

$tt = time;
$s_time = $tt - $mdate;
$s_time = $BTIME - $s_time;

foreach(@CON_DATA){
	($con2_id,$con2_name,$con2_ele,$con2_gold,$con2_king,$con2_yaku,$con2_cou,$con2_mes,$con2_etc) =split(/<>/);
	$CONELE[$con2_id]=$con2_ele;
	$CONNAME[$con2_id]=$con2_name;
	$c_no++;
}
$hit=0;
foreach(@CON_DATA){
	($con2_id,$con2_name,$con2_ele,$con2_gold,$con2_king,$con2_yaku,$con2_cou,$con2_mes,$con2_etc) =split(/<>/);
	if("$con2_id" eq "$town_con"){$hit=1;last;}
}
if(!$hit){$con2_ele=0;$con2_name="무소속";$con2_id=0;}

&header;

if($s_time > 0){
	$clock="<FORM NAME=\"tokei\"><INPUT TYPE=\"text\" NAME=\"tok\" SIZE=\"25\" style=\"color:#00FF00;background-color:#404040;\">";
}
else{$clock= "<font color=$ELE_C[$con_ele] size=2>행동 OK</font>";}

open(IN,"./data/maplog.cgi");
@MAP = <IN>;
close(IN);
foreach(@MAP){
	$maplog.="<b><font color=000000>●$MAP[$l]</font></b><BR>";
	$l++;
}

if($in{'id'} eq""){&error2("ID가 입력되고 있지 않습니다.");}
if($in{'pass'} eq""){&error2("패스워드가 입력되고 있지 않습니다.");}


##메세지 표시
open(IN,"./meslog/all.cgi");
@MES_DATA1 = <IN>;
close(IN);
open(IN,"./meslog/$con_id.cgi");
@MES_DATA2 = <IN>;
close(IN);
open(IN,"./logfile/mes/$mid.cgi");
@MES_DATA3 = <IN>;
close(IN);

$atable="<table border=0 bgcolor=$FCOLOR width=100%>";
foreach(@MES_DATA1){
	($lid,$laite,$leid,$lchara,$lname,$lmes,$ldaytime) =split(/<>/);
	$atable.="<tr><td align=center bgcolor=000000 width=15%><img src=\"./img/chara/$lchara.gif\"></td><td align=left bgcolor=000000 width=85%><b>$lname<BR><font color=ffffff>「$lmes」</b></font></td></tr>";
}
$atable.="</table>";

$ctable="<table border=0 bgcolor=$ELE_BG[$con_ele] width=100%>";
foreach(@MES_DATA2){
	($lid,$laite,$leid,$lchara,$lname,$lmes,$ldaytime) =split(/<>/);
	$ctable.="<tr><td align=center bgcolor=000000 width=15%><img src=\"./img/chara/$lchara.gif\"></td><td align=left bgcolor=000000 width=85%><b>$lname<BR><font color=ffffff>「$lmes」</b></font></td></tr>";
}
$ctable.="</table>";

$ktable="<table border=0 bgcolor=$ELE_BG[$mele] width=100%>";
foreach(@MES_DATA3){
	($lid,$laite,$leid,$lchara,$lname,$lmes,$ldaytime) =split(/<>/);
	$ktable.="<tr><td align=center bgcolor=000000 width=15%><img src=\"./img/chara/$lchara.gif\"></td><td align=left bgcolor=000000 width=85%><b>$lname<BR><font color=ffffff>「$lmes」</b></font></td></tr>";
}
$ktable.="</table>";

##화면 표시
$player=@newguest;
print <<"EOF";
<table width=94% align=center CLASS=TC>
	    <tr>
	    <td bgcolor="$TCOLOR">
	    <font color="ffffff" size=-1>참가자($player명)</font></TD>
	    </tr>
	    <tr>
	    <td bgcolor="ffffff">
	    <font size=-1>$guestlist</font></TD>
	    </tr></table>
	<CENTER>
	<TABLE border="0" width="95%">
	<TBODY>
          <TR>
            <TD height="39">
            <TABLE border="0" width=100% bgcolor="$FCOLOR2" CLASS=CC>
              <TBODY>
                <TR>
                  <TD colspan="5"><FONT color="#ffffcc" size="-1">스테이터스</FONT></TD>
                  <TD><FONT color="#ffffcc" size="-1">커멘드</FONT></TD>
		<TD>$clock
		</TD></FORM>
                <TD bgcolor=$FCOLOR2>
		<form action="./top2.cgi" method="post">
		<input type=hidden name=id value=$mid>
		<input type=hidden name=pass value=$mpass>
		<input type=submit CLASS=MFC value="갱신">
		</TD></form>
                </TR>
		
                <TR>
                  <TD bgcolor="$ELE_C[$mele]" width="50" rowspan="4"><img src="img/chara/$mchara.gif"></TD>
                  <TD bgcolor="$ELE_C[$mele]" width="10%"><FONT size="-1">LV</FONT></TD>
                  <TD bgcolor="$ELE_C[$mele]" width="10%"><FONT size="-1">$mlv</FONT></TD>
                  <TD bgcolor="$ELE_C[$mele]" width="10%"><FONT size="-1">종족</FONT></TD>
                  <TD bgcolor="$ELE_C[$mele]" ><FONT size="-1">$TYPE[$mtype]</FONT></TD>
                  <TD bgcolor="$ELE_C[$mele]" ><FONT size="-1">훈련·전투</FONT></TD>
                  <TD bgcolor="$ELE_C[$mele]" >
		<form action="./battle.cgi" method="post">
		<input type=hidden name=id value=$mid>
		<input type=hidden name=pass value=$mpass>
		<SELECT name=mode> 
		    <OPTION value=1 selected>$town_name 평야
                    <OPTION value=2>$town_name 늪지대
                    <OPTION value=3>$town_name의 숲
                    <OPTION value=4>$town_name의 탑
                    <OPTION value=5>$town_name의 동굴
                    <OPTION value=6>$town_name의 미궁
                    
      		</SELECT>
		</TD>
                  <TD bgcolor="$ELE_C[$mele]" width=5%><FONT size="-1"><INPUT type="submit" CLASS=MFC value="실행" onSubmit="return" check()></FONT></TD>
                </form></TR>
                <TR>
                  <TD bgcolor="$ELE_C[$mele]" width="10%"><FONT size="-1">HP</FONT></TD>
                  <TD bgcolor="$ELE_C[$mele]" width="10%"><FONT size="-1">$mhp/$mmaxhp</FONT></TD>
                  <TD bgcolor="$ELE_C[$mele]" width="10%"><FONT size="-1">속성</FONT></TD>
                  <TD bgcolor="$ELE_C[$mele]" width="10%"><FONT size="-1">$ELE[$mele]</FONT></TD>
                  <TD bgcolor="$ELE_C[$mele]"><FONT size="-1">거리의 시설</FONT></TD>
                  <TD bgcolor="$ELE_C[$mele]">
		<form action="./town.cgi" method="post">
		<input type=hidden name=id value=$mid>
		<input type=hidden name=pass value=$mpass>
		
		  <SELECT name=mode> 
		  <OPTION>==== 거리의 시설 ====
                    <OPTION value=inn selected>여인숙
                    <OPTION value=arm>무기가게
                    <OPTION value=pro>방어구가게
                    <OPTION value=acc>악세사리가게
                    <OPTION value=bank>은행
                    <OPTION value=arena>투기장
                    
      		</SELECT></TD>
                  <TD bgcolor="$ELE_C[$mele]" width=5%><FONT size="-1">
		<INPUT type="submit" CLASS=MFC value="실행" onSubmit="return" check()>
		
		</FONT></TD></form>
                </TR>
                <TR>
                  <TD bgcolor="$ELE_C[$mele]" width="10%"><FONT size="-1">MP</FONT></TD>
                  <TD bgcolor="$ELE_C[$mele]" width="10%"><FONT size="-1">$mmp/$mmaxmp</FONT></TD>
                  <TD bgcolor="$ELE_C[$mele]" width="10%"><FONT size="-1">직업</FONT></TD>
                  <TD bgcolor="$ELE_C[$mele]" width="10%"><FONT size="-1">$JOB[$mclass]</FONT></TD>
                  <TD bgcolor="$ELE_C[$mele]"><FONT size="-1">캐릭터의 확인·변경</FONT></TD>
                  <TD bgcolor="$ELE_C[$mele]">
		<form action="./status.cgi" method=post>
		<input type=hidden name=id value=$mid>
		<input type=hidden name=pass value=$mpass>
		<SELECT name=mode> 
		    <OPTION value=status selected>스테이터스 체크
                    <OPTION value=equip>아이템의 사용/장비
                    <OPTION value=money_send>송금
                    <OPTION value=tec_set>기술의 변경
                    <OPTION value=change>직업의 변경
                    <OPTION value=reborn>전생의 사이
                    <OPTION value=skill>스킬의 습득
                    <OPTION value=data_change>아이콘의 변경
                    </SELECT></TD>
                  <TD bgcolor="$ELE_C[$mele]" width=5%><FONT size="-1"><INPUT type="submit" CLASS=MFC value="실행" onSubmit="return" check()></FONT></TD>
		  </form>
                </TR>
                <TR>
                  <TD bgcolor="$ELE_C[$mele]" width="10%"><FONT size="-1">경험치</FONT></TD>
                  <TD bgcolor="$ELE_C[$mele]" width="10%"><FONT size="-1">$mex</FONT></TD>
                  <TD bgcolor="$ELE_C[$mele]" width="10%"><FONT size="-1">명성</FONT></TD>
                  <TD bgcolor="$ELE_C[$mele]" width="10%"><FONT size="-1">$mcex</FONT></TD>
                  <TD bgcolor="$ELE_C[$mele]"><FONT size="-1">군사·내정</FONT></TD>
                  <TD bgcolor="$ELE_C[$mele]">
		<form action="./country.cgi" method="post">
		<input type=hidden name=id value=$mid>
		<input type=hidden name=pass value=$mpass>
		<SELECT name=mode> 
		  <OPTION value=rule selected>$con_name국 룰
                    <OPTION value=all_rule>전국 룰
                    <OPTION value=money_get>수익금의 회수
                    <OPTION value=suport_money>자금 원조
                    <OPTION value=town_up>거리의 개발
                    <OPTION value=ram_up>성벽의 강화
                    <OPTION value=town_arm>무기·방어구 개발
                    <OPTION value=sirei>지령의 변경
                    <OPTION>====== 경비 ======
                    <OPTION value=def>거리의 수비
                    <OPTION value=def_out>수비 해제
                    <OPTION >=======독립=========
                    <OPTION value=con_change>나라에 관직에 오름
                    <OPTION value=con_change3>하야
                    <OPTION value=build>건국
                    </SELECT></TD>
                  <TD bgcolor="$ELE_C[$mele]" width=5%><FONT size="-1">
		<INPUT type="submit" CLASS=MFC value="실행" onSubmit="return" check()></FONT></TD>
		</form>
                </TR>
                <TR>
                  <TD bgcolor="$ELE_C[$mele]" width="72"><FONT size="-1">$mname</FONT></TD>
                  <TD bgcolor="$ELE_C[$mele]" width="10%"><FONT size="-1">자금</FONT></TD>
                  <TD bgcolor="$ELE_C[$mele]" width="34"><FONT size="-1">$mgold</FONT></TD>
                  <TD bgcolor="$ELE_C[$mele]" width="86"><FONT size="-1">은행</FONT></TD>
                  <TD bgcolor="$ELE_C[$mele]" width="34"><FONT size="-1">$mbank</FONT></TD>
                  <TD bgcolor="$ELE_C[$mele]"><FONT size="-1">이동·침략</FONT></TD>
                  <TD bgcolor="$ELE_C[$mele]">
		<form action="./etc.cgi" method="post">
		<input type=hidden name=id value=$mid>
		<input type=hidden name=pass value=$mpass>
		<SELECT name=mode> 
		　　<OPTION value=move selected>이동
                    <OPTION value=inv>거리 공격
     		 </SELECT>
		</TD>
                  <TD bgcolor="$ELE_C[$mele]" width=5%><FONT size="-1">
		<INPUT type="submit" CLASS=MFC value="실행" onSubmit="return" check()></FONT>
		</TD></FORM>
                </TR>
		
              </TBODY>
            </TABLE>
            </TD>
          </TR>
          <TR>
            <TD>
	    <table width=100% CLASS=CC>
	    <tr>
	    <td bgcolor="$ELE_BG[$con_ele]">
	    <font color="$ELE_C[$con_ele]" size=-1>사건</font></TD>
	    </tr>
	    <tr>
	    <td bgcolor="$ELE_C[$con_ele]">
	    <font color="$ELE_BG[$con_ele]" size=-1>$maplog</font></TD>
	    </tr></table>
	    </td>
          </TR>
          <TR>
    <TD>
    <TABLE CLASS=TC WIDTH=100%>
	<TR><TD colspan=2 align=center>
	<font color=ffffcc>CHAT</font>
	</TD></TR>
	<TR><TD colspan=2 bgcolor=$FCOLOR2 align=center>
	<form action="./status.cgi" method="post">
	<input type=hidden name=id value=$mid>
	<input type=hidden name=pass value=$mpass>
	<input type=hidden name=mode value=chat>
	메세지：<input type=text name=mes size=60>
	<SELECT name=mes_sel>
		<option value=1>전원에게
		<option value=2>$con_name 국내에
		$mesate
		<option value=3>상대를 지정↓
	</SELECT>
        <input type=submit class=FC value=송신><BR>
	　　　　　　　　　　　　　　　　　　　　　　　보내는 상대의 이름을 입력：<input type=text name=aite size=20>
	</TD>
	</form>
	</TR>
	<TR>
	<TD bgcolor=$FCOLOR2 width=50%>
	전원앞<br>
	$atable
	$mname앞<br>
	$ktable
	<TD bgcolor=$FCOLOR2 width=50%>
	$con_name국앞<br>
	$ctable<br>
	</TD>
	</TR>
	</TD>
     </TABLE>
	</TD>
	</TR>
        </TBODY>
      </TABLE>
      </TD>
    </TR>
    
  </TBODY>
</TABLE>
<BR>
</CENTER>
<P><BR>
<BR>
</P>

EOF

if($s_time > 0){
print <<"EOM";
<SCRIPT LANGUAGE = "JavaScript">
  <!-- JavaScript
	to();
  //end -->
  </SCRIPT>

EOM
}

&footer;

exit;
}

