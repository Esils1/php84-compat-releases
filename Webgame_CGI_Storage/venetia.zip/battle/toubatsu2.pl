sub toubatsu2{
	&chara_open;
	&town_open;
	&con_open;

	if($in{'player'} eq ""){&error("상대가 선택되지 않았습니다.");}
	if($in{'player'} eq "$mid"){&error("자신은 선택할 수 없습니다.");}
	
	$date = time();
	$btime = $BTIME - $date + $mdate;
	if($btime>0){&error("다음의 전투까지 $btime 초 기다려 주세요.");}

	open(IN,"./logfile/battle/$in{'id'}.cgi");
	@BC_DATA = <IN>;
	close(IN);

	open(IN,"./data/battlecount.cgi");
	@COUNT_DATA = <IN>;
	close(IN);
	($battlecount) =split(/<>/,$COUNT_DATA[0]);

	($mhpr,$mmpr,$mtim) =split(/<>/,$BC_DATA[0]);
	if($mhpr eq""){$mhpr=1;}
	if($mmpr eq""){$mmpr=1;}
	if($mhpr<0.2){&error("공격받는 상태가 아닙니다.");}
	$mhp=int($mmaxhp*$mhpr);
	$mmp=int($mmaxmp*$mmpr);

	$mtotal++;
	$date = time();
	$ktime = $KTIME - $date + $mdate2;
	if($ktime>0){&error("토벌까지 $ktime 초 기다려 주세요.");}
	if($con_id eq 0){
		&error("무소속은 실행할 수 없습니다.");
	}
	
	foreach(@TOWN_DATA){
		($town2_id,$town2_name,$town2_con,$town2_ele,$town2_gold,$town2_arm,$town2_pro,$town2_acc,$town2_ind,$town2_tr,$town2_s,$town2_x,$town2_y,$town2_etc) =split(/<>/);
		if($in{'tid'} eq $town2_id){$tohit=1;last;}
		$tx++;
	}

	$dir="./logfile/chara";
	opendir(dirlist,"$dir");
	$i=0;
	while($file = readdir(dirlist)){
		if($file =~ /\.cgi/i){
			$datames = "검색：$dir/$file<br>\n";
			if(!open(cha,"$dir/$file")){
				&error("$dir/$file가 발견되지 않습니다.<br>\n");
			}
			@cha = <cha>;
			close(cha);
			$list[$i]="$file";
			($rid,$rpass,$rname,$rurl,$rchara,$rsex,$rhp,$rmaxhp,$rmp,$rmaxmp,$rele,$rstr,$rvit,$rint,$rfai,$rdex,$ragi,$rmax,$rcom,$rgold,$rbank,$rex,$rtotalex,$rabp,$rjp,$rcex,$runit,$rcon,$rarm,$rpro,$racc,$rtec,$rsta,$rpos,$rmes,$rhost,$rdate,$rsyo,$rclass,$rtotal,$rkati,$rtype) = split(/<>/,$cha[0]);
			if($rcon eq $town2_con){$zin++;}
			elsif($rcon eq $mcon){$zin2++;}
		}
		$mn++;
	}
	closedir(dirlist);

	$conhit=0;
	foreach(@CON_DATA){
		($con2_id,$con2_name,$con2_con,$con2_ele,$con2_gold,$con2_king,$con2_yaku,$con2_cou,$con2_mes,$con2_etc) =split(/<>/);
		if($town2_con eq $con2_id){$conhit=1;last;}
		$tx++;
	}
	if(!$conhit){$con2_ele=0;$con2_name="무소속";}
	
				
	require './battle_suport.cgi';

	$dhit=0;

	$enemy_id=$in{'player'};
	&enemy_open;
	&maplog5("<a href=\"./data/inv/$battlecount.html\" TARGET=\"_blank\"><font color=black>【토벌】</font></a><font color=red>$con_name국</font>의<font color=blue>$mname</font>는,<font color=red>$ename</font>에 공격을 장치했습니다.");
	
	&equip_open;
	&PARA;

	
	open(IN,"./logfile/battle/$enemy_id.cgi");
	@BE_DATA = <IN>;
	close(IN);
	($ehpr,$empr,$etim) =split(/<>/,$BE_DATA[0]);
	if($ehpr eq""){$ehpr=1;}
	if($empr eq""){$empr=1;}
	$ehp=int($emaxhp*$ehpr);
	$emp=int($emaxmp*$empr);
	
	&TEC_OPEN;

	&header;
	$blog.= <<"EOF";
<TABLE border="0" width="100%" align=center height="144" CLASS=TOC>
  <TBODY>
    <TR>
      <TD colspan="3" align="center" bgcolor="$ELE_BG[$town_ele]"><FONT color="#ffffcc">$town_name </FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#cccccc" width="30%">
      <TABLE border="0" width="100%" height="100%" bgcolor=$ELE_BG[$mele] align=right>
        <TBODY>
          <TR>
            <TD rowspan="2"><FONT size="-1"><img src="./img/chara/$mchara.gif"></FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">HP</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">$mhp/$mmaxhp</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">공격력</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">$mstr(+$marmdmg)</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">무기</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">$marmname<BR>
            【$marmdmg/$marmwei】</FONT></TD>
          </TR>
          <TR>
            <TD bgcolor=$FCOLOR2><FONT size="-1">MP</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">$mmp/$mmaxmp</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">방어력</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">$mvit(+$mprodmg+$maccdmg)</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">방어구</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">$mproname<BR>
            【$mprodmg/$mprowei】</FONT></TD>
          </TR>
          <TR>
            <TD bgcolor=$FCOLOR2><FONT size="-1">$mname</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">직업</FONT></TD>
            <TD bgcolor=$FCOLOR2>$JOB[$mclass]</TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">속도</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">$magi</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">악세사리</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">$maccname<BR>
            【$maccdmg/$maccwei】</FONT></TD>
          </TR>
        </TBODY>
      </TABLE>
      </TD>
      <TD align="center" bgcolor="$FCOLOR2" width="20%"><IMG src="./img/town/machi.gif" width="150" height="113" border="0"></TD>
      <TD bgcolor="#cccccc" width=30%>
      <TABLE border="0" width="100%" height="100%" bgcolor=$ELE_BG[$eele]>
        <TBODY>
          <TR>
            <TD rowspan="2"><FONT size="-1"><img src="./img/chara/$echara.gif"></FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">HP</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">$ehp/$emaxhp</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">공격력</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">$estr(+$earmdmg)</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">무기</FONT></TD>
          <TD bgcolor=$FCOLOR2><FONT size="-1">$earmname<BR>【$earmdmg/$earmwei】</FONT></TD>
         </TR>
          <TR>
            <TD bgcolor=$FCOLOR2><FONT size="-1">MP</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">$emp/$emaxmp</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">방어력</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">$evit(+$eprodmg+$eaccdmg)</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">방어구</FONT></TD>
         <TD bgcolor=$FCOLOR2><FONT size="-1">$eproname<BR>【$eprodmg/$eprowei】</FONT></TD>
         </TR>
          <TR>
            <TD bgcolor=$FCOLOR2><FONT size="-1">$ename</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">직업</FONT></TD>
            <TD bgcolor=$FCOLOR2>$JOB[$eclass]</TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">속도</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">$eagi</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">악세사리</FONT></TD>
          <TD bgcolor=$FCOLOR2><FONT size="-1">$eaccname<BR>【$eaccdmg/$eaccwei】</FONT></TD>
         </TR>
        </TBODY>
      </TABLE>
      </TD>
    </TR>
    <TR>
      <TD bgcolor=#000000><font color="white" size="-1">「$mcom」</font></TD>
      <TD align=center bgcolor="666600"><font color="white" size="-1">코멘트</font></TD>
      <TD bgcolor=#000000><font color="white" size="-1">「$ecom」</font></TD>
    </TR>
  </TBODY>
</TABLE>
<BR><BR>
EOF
	&BATTLE;
	
	&log_print;

	@N_COUNT=();
	$battlecount+=1;
	if($battlecount>=10){$battlecount=1;}

	unshift(@N_COUNT,"$battlecount<>\n");
	open(OUT,">./data/battlecount.cgi");
	print OUT @N_COUNT;
	close(OUT);


	print <<"EOF";
	$blog
	<center>
	<form action="./top.cgi" method="POST">
	<input type=hidden name=id value="$mid">
	<input type=hidden name=pass value="$mpass">
	<CENTER>
	<input type="submit" value="돌아온다" CLASS=FC>
	</CENTER>
	<BR><BR>
	</form>
	<P><hr size=0></center>
	</center>
EOF
	&chara_input;

#건강도
	$mhpr=int($mhp*100/$mmaxhp)/100-0.1;
	if($mhpr<0.05){$mhpr=0.05;}
	$mmpr=int($mmp*100/$mmaxmp)/100-0.1;
	if($mmpr<0.05){$mmpr=0.05;}
	@N_BC=();
	unshift(@N_BC,"$mhpr<>$mmpr<>$date<>\n");
	open(OUT,">./logfile/battle/$in{'id'}.cgi");
	print OUT @N_BC;
	close(OUT);
	
	$date = time();
	$ehpr=int($ehp*100/$emaxhp)/100-0.1;
	if($ehpr<0.05){$ehpr=0.05;}
	$empr=int($emp*100/$emaxmp)/100-0.1;
	if($empr<0.05){$empr=0.05;}
	@N_BE=();
	unshift(@N_BE,"$ehpr<>$empr<>$date<>\n");
	open(OUT,">./logfile/battle/$enemy_id.cgi");
	print OUT @N_BE;
	close(OUT);
	
	&footer;
	exit;
}


sub BATTLE{##전투 처리
	while($turn<=50){
		$turn++;
		$bmess="";
		if($mab[15] && $mabdmg[15]>$eabdmg[15] && int(rand($mabdmg[15])) eq 0){$sensei = 1;}
		elsif($eab[15] && $eabdmg[15]>$mabdmg[15] && int(rand($eabdmg[15])) eq 0){$sensei = 0;}
		elsif(int(rand($mdex)) > int(rand($edex))){$sensei = 1;}
		else{$sensei = 0;}
		if($sensei){
			if($mhp>0){&MATT;}
			if($ehp>0){&EATT;}
		}else{
			if($ehp>0){&EATT;}
			if($mhp>0){&MATT;}
		}if($win){
			$mkati++;
			&BATTLEPRINT;
			$mlv=int($mex/100)+1;
			$get_ex=50 + int(rand(10));
			if($mex<9900){
				$mex+=$get_ex;
			}
			$mtotalex+=$get_ex;
			$get_gold=$e_gold + int(rand($e_gold/3));
			$mgold+=$get_gold;
			$getabp=2;
			if($mab[22]){$getabp += 1;}

			$mabp+=$getabp;
			$mjp[$mtype]+=$getabp;
			if($mjp[$mtype]>$MAXJOB){$mjp[$mtype] = $MAXJOB;}
			
			##레벨업
			&LVUP;
			&maplog5("<font color=red>【승리】</font>$mname는$ename에 승리했습니다.");
			
			$blog.= <<"EOF";
			<center>
			<TABLE border="0" width="400" bgcolor="#000000" CLASS=TC>
  			<TBODY><TR>
      			<TD colspan="2" align="center" bgcolor="$FCOLOR"><FONT color="#ffffcc">승리!</FONT></TD>
    			</TR>
    			<TR><TD colspan="2" align="center" bgcolor="$FCOLOR2">경험치<FONT color="#cc0000">$get_ex</FONT>포인트 획득<BR>
      			<FONT color="#000099">$get_gold</FONT> Gold를 손에 넣었다!<BR>$com<BR>
      			숙련도<FONT color="#cc0000">$getabp</FONT>포인트 획득<BR>
			<TABLE border="0" bgcolor="#990000">
        		<TBODY><TR>
            		<TD bgcolor="#ffffcc">경험치</TD>
            		<TD bgcolor="#ffffcc">$mex(+$get_ex) point</TD>
          		</TR>
          		<TR><TD bgcolor="#ffffcc">Gold</TD>
            		<TD bgcolor="#ffffcc">$mgold(+$get_gold) Gold</TD>
          		</TR></TBODY></TABLE>
      			</TD></TR>
  			</TBODY></TABLE>
			</center>
EOF
			last;
		}if($lose){
			&maplog5("<font color=blue>【패배】</font>$mname는$ename에 패배했습니다..");
			
			$bmess.="$mname의 소지금이 반이 되어 버렸다.";
			&BATTLEPRINT;
			last;
		}
		&BATTLEPRINT;
		
	}
	if(!$win && !$lose){
		$bmess.="결착이 붙지 않았다.";
		&BATTLEPRINT;
	}
	$mdate2=time();
	
}

#턴별 전투 결과 표시
sub BATTLEPRINT{
	$blog.= <<"EOF";
<CENTER>


<TABLE border="0" width="80%" bgcolor="#000000" CLASS=TC>
  <TBODY>
    <TR>
      <TD colspan="8" align="center" bgcolor="$FCOLOR"><B><FONT color="#ffffcc">$turn 턴</FONT></B></TD>
    </TR>
    <TR>
      <TD colspan="4" bgcolor="000063" align="center"><FONT color="$FCOLOR2"><B><FONT size="-1">$mname</FONT></B></FONT></TD>
      <TD colspan="4" bgcolor="9c0000" align="center"><B><FONT size="-1" color="$FCOLOR2">$ename</FONT></B></TD>
    </TR>
    <TR>
      <TD colspan="4" bgcolor="#003300" align="center"><IMG src="./img/chara/$mchara.gif"></TD>
      <TD colspan="4" bgcolor="#003300" align="center"><IMG src="./img/chara/$echara.gif"></TD>
    </TR>
    <TR>
      <TD colspan="8" bgcolor="$FCOLOR2" align="center"><font size=-1>$bmess</font></TD>
    </TR>
    <TR>
      <TD bgcolor="#ccffff" width=12.5%>HP</TD>
      <TD bgcolor="#ccffff" width=12.5%>$mhp/$mmaxhp</TD>
      <TD bgcolor="#ccffff" width=12.5%>MP</TD>
      <TD bgcolor="#ccffff" width=12.5%>$mmp/$mmaxmp</TD>
      <TD bgcolor="#ccffff" width=12.5%>HP</TD>
      <TD bgcolor="#ccffff" width=12.5%>$ehp/$emaxhp</TD>
      <TD bgcolor="#ccffff" width=12.5%>MP</TD>
      <TD bgcolor="#ccffff" width=12.5%>$emp/$emaxmp</TD>
    </TR>
  </TBODY>
</TABLE>
</CENTER>
<BR><BR><BR><P>
EOF
}

sub log_print{
	$header = <<"EOM";
	<html>
	<head>
	<META HTTP-EQUIV="Content-type" CONTENT="text/html; charset=utf-8">
	<STYLE type="text/css">
	<!--
A:HOVER{
 color: $ALINK
}
.BC {border-top-width : medium;border-right-width : medium;border-bottom-width : medium;border-left-width :medium; border-color : $ELE_BG[0] $ELE_BG[0] $ELE_BG[0] $ELE_BG[0];border-style : double double double double;background-color : $ELE_BG[0];color : black;}
.TC {border-top-width : medium;border-right-width : medium;border-bottom-width : medium;border-left-width :medium; border-color : $FCOLOR $FCOLOR $FCOLOR $FCOLOR;border-style : double double double double;background-color : $FCOLOR;color : black;}
.CC {border-top-width : medium;border-right-width : medium;border-bottom-width : medium;border-left-width :medium; border-color : $ELE_BG[$con_ele] $ELE_BG[$con_ele] $ELE_BG[$con_ele] $ELE_BG[$con_ele];border-style : double double double double;background-color : $ELE_BG[$con_ele];color : black;}
.CC2 {border-top-width : medium;border-right-width : medium;border-bottom-width : medium;border-left-width :medium; border-color : $ELE_BG[$con2_ele] $ELE_BG[$con2_ele] $ELE_BG[$con2_ele] $ELE_BG[$con2_ele];border-style : double double double double;background-color : $ELE_BG[$con2_ele];color : black;}
.MC {border-top-width : medium;border-right-width : medium;border-bottom-width : medium;border-left-width :medium; border-color : $ELE_BG[$wele] $ELE_BG[$wele] $ELE_BG[$wele] $ELE_BG[$wele];border-style : double double double double;background-color : $ELE_BG[$wele];color : black;}
.MFC {border-top-width : medium;border-right-width : medium;border-bottom-width : medium;border-left-width : $ELE_BG[$con_ele];border-top-color : $ELE_BG[$con_ele];border-right-color : $ELE_BG[$con_ele];border-bottom-color : $ELE_BG[$con_ele];border-left-color : $ELE_BG[$con_ele];border-style : double double double double;background-color : $ELE_C[$con_ele];color : black;}
.FC {border-top-width : medium;border-right-width : medium;border-bottom-width : medium;border-left-width : $FCOLOR;border-top-color : $FCOLOR;border-right-color : $FCOLOR;border-bottom-color : $FCOLOR;border-left-color : $FCOLOR;border-style : double double double double;background-color : $FCOLOR2;color : black;}
.TOC {border-top-width : medium;border-right-width : medium;border-bottom-width : medium;border-left-width :medium; border-color : $ELE_BG[$town_ele] $ELE_BG[$town_ele] $ELE_BG[$town_ele] $ELE_BG[$town_ele];border-style : double double double double;background-color : $ELE_BG[$town_ele];color : black;}
.dmg { color: #FF0000; font-size: 10pt }
.clit { color: #0000FF; font-size: 10pt }
-->
	</STYLE>
	<title>$TITLE</title></head>
	<body background=\"$BGIF\" bgcolor=\"$BG\">
EOM

	open(OUT,">./data/inv/$battlecount.html");
	print OUT $header;
	print OUT $blog;
	print OUT "</BODY></HTML>";
	close(OUT);
}

1;

