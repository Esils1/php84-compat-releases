sub kunren2{
	&chara_open;
	&town_open;
	if($in{'player'} eq ""){&error("상대가 선택되지 않았습니다.");}
	if($in{'player'} eq "$mid"){&error("자신은 선택할 수 없습니다.");}
	
	$mtotal++;
	$date = time();
	$btime = $BTIME - $date + $mdate;
	if($btime>0){&error("다음의 전투까지 $btime 초 기다려 주세요.");}

	$enemy_id=$in{'player'};
	&enemy_open;

	&equip_open;
	&PARA;
	&TEC_OPEN;
	&header;
	
	print <<"EOF";
<TABLE border="0" width="100%" align=center height="144" CLASS=TOC>
  <TBODY>
    <TR>
      <TD colspan="3" align="center" bgcolor="$ELE_BG[$town_ele]"><FONT color="#ffffcc">$town_name $sen$SEN[$in{'mode'}]</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#cccccc" width="30%">
      <TABLE border="0" width="100%" height="100%" bgcolor=$ELE_BG[$mele] align=right>
        <TBODY>
          <TR>
            <TD rowspan="2"><FONT size="-1"><img src="./img/chara/$mchara.gif"></FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">HP$mode5</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">$mhp/$mmaxhp</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">공격력</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">$mstr $chi1(+$marmdmg)</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">무기</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">$marmname<BR>
            【$marmdmg/$marmwei】</FONT></TD>
          </TR>
          <TR>
            <TD bgcolor=$FCOLOR2><FONT size="-1">MP</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">$mmp/$mmaxmp</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">방어력</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">$mvit $chi1(+$mprodmg+$maccdmg)</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">방어구</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">$mproname<BR>
            【$mprodmg/$mprowei】</FONT></TD>
          </TR>
          <TR>
            <TD bgcolor=$FCOLOR2><FONT size="-1">$mname</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">직업</FONT></TD>
            <TD bgcolor=$FCOLOR2>$JOB[$mclass]</TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">속도</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">$magi</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">악세사리</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">$maccname<BR>
            【$maccdmg/$maccwei】</FONT></TD>
          </TR>
        </TBODY>
      </TABLE>
      </TD>
      <TD align="center" bgcolor="$FCOLOR2" width="20%"><IMG src="./img/town/machi.gif" width="150" height="113" border="0"></TD>
      <TD bgcolor="#cccccc" width=30%>
      <TABLE border="0" width="100%" height="100%" bgcolor=$ELE_BG[$eele]>
        <TBODY>
          <TR>
            <TD rowspan="2"><FONT size="-1"><img src="./img/chara/$echara.gif"></FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">HP</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">$ehp/$emaxhp</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">공격력</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">$estr $chi2</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">무기</FONT></TD>
          </TR>
          <TR>
            <TD bgcolor=$FCOLOR2><FONT size="-1">MP</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">$emp/$emaxmp</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">방어력</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">$evit $chi2</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">방어구</FONT></TD>
         </TR>
          <TR>
            <TD bgcolor=$FCOLOR2><FONT size="-1">$ename</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">직업</FONT></TD>
            <TD bgcolor=$FCOLOR2></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">속도</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">$eagi</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">악세사리</FONT></TD>
          </TR>
        </TBODY>
      </TABLE>
      </TD>
    </TR>
    <TR>
      <TD bgcolor=#000000><font color="white" size="-1">「$mcom」</font></TD>
      <TD align=center bgcolor="666600"><font color="white" size="-1">코멘트</font></TD>
      <TD bgcolor=#000000><font color="white" size="-1">「$ecom」</font></TD>
    </TR>
  </TBODY>
</TABLE>
<BR><BR>
EOF


##전투 처리
	$turn=0;
	while($turn<=30){
		$turn++;
		if($turn>100){&error("루프");}
		$bmess="";
		if($mab[15] && $mabdmg[15]>$eabdmg[15] && int(rand(3-$mabdmg[15])) eq 0){$sensei = 1;}
		elsif($eab[15] && $eabdmg[15]>$mabdmg[15] && int(rand(3-$eabdmg[15])) eq 0){$sensei = 0;}
		elsif(int(rand($mdex)) > int(rand($edex))){$sensei = 1;}
		else{$sensei = 0;}
		if($sensei){
			if($mhp>0){&MATT;}
			if($ehp>0){
				&EATT;
			}
		}else{
			if($ehp>0){
				&EATT;
			}
			if($mhp>0){&MATT;}
		}
		if($win){
			$mkati++;
			&BPRINT;
			$mlv=int($mex/100)+1;
			
			$epoint=int($emaxhp+$emaxmp+($estr+$evit+$eint+$edex+$efai+$eagi)/3);
	
			$get_ex=(int($epoint/15) + 10 + int(rand(10)));
			if($get_ex>50){$get_ex = 50 + int(rand(10));}
			if($get_ex<10){$get_ex = 10 + int(rand(10));}

			
			if($mab[22]){
				$get_ex = int($get_ex*1.2);
				$getabp += 1;
			}

			$getabp=3;
			
			$mbex=$mex;
			if($mex<9900){
				$mex+=$get_ex;
			}
			$mtotalex+=$get_ex;
			$get_gold=($epoint + int(rand($epoint/5)))*4;

			$mabp+=$getabp;
			$bmjp[$mtype]=$mjp[$mtype];
			$mjp[$mtype]+=$getabp;
			if($mjp[$mtype]>$MAXJOB){$mjp[$mtype] = $MAXJOB;}
			
			$get_gold2=$get_gold+$add_gold + $z_gold;

			$mgold+=$get_gold2;

			##레벨업
			&LVUP;

			print <<"EOF";
			<center>
			<TABLE border="0" width="400" bgcolor="#000000" CLASS=TC>
  			<TBODY><TR>
      			<TD colspan="2" align="center" bgcolor="$FCOLOR"><FONT color="#ffffcc">승리!</FONT></TD>
    			</TR>
    			<TR><TD colspan="2" align="center" bgcolor="$FCOLOR2">
			경험치<FONT color="#cc0000">$get_ex</FONT>포인트 획득<BR>
      			<FONT color="#000099">$get_gold</FONT> Gold를 손에 넣었다!<BR>
			숙련도<FONT color="#cc0000">$getabp</FONT>포인트 획득<BR>
			$com<BR>
      			<TABLE border="0" bgcolor="#990000">
        		<TBODY><TR>
            		<TD bgcolor="#ffffcc">경험치</TD>
            		<TD bgcolor="#ffffcc">$mex(+$get_ex) point</TD>
          		</TR>
          		<TR><TD bgcolor="#ffffcc">Gold</TD>
            		<TD bgcolor="#ffffcc">$mgold(+$get_gold2) Gold</TD>
          		</TR></TBODY></TABLE>
      			</TD></TR>
  			</TBODY></TABLE>
			</center>
EOF
			last;
		}if($lose){
			
			$bmess.="$mname의 소지금이 반이 되어 버렸다.";
			$mgold=int($mgold/2);
			&BPRINT;last;
		}
		&BPRINT;
	}
	if(!$win && !$lose){
		$bmess.="결착이 붙지 않았다.";
		&atp;
		&BPRINT;
	}

	&chara_input;

	print <<"EOF";
	<center>
	<form action="./top.cgi" method="POST">
	<input type=hidden name=id value="$mid">
	<input type=hidden name=pass value="$mpass">
	<input type="submit" value="돌아온다" CLASS=FC>
	</form>
	<form action="./town.cgi" method="POST">
	<input type=hidden name=id value="$mid">
	<input type=hidden name=pass value="$mpass">
	<INPUT type=hidden name=mode value=inn>
	<input type="submit" value="여인숙에 직행" CLASS=FC>
	</form>
	<P><hr size=0></center>
	</center>
EOF
	&footer;
}

1;
