sub bat{
	&chara_open;
	&town_open;
	&equip_open;
	if($in{'mode'} eq "" || $SEN[$in{'mode'}] eq ""){&error("올바르게 선택되고 있지 않습니다.");}

	$mtotal++;
	$date = time();
	$btime = $BTIME - $date + $mdate;
	if($btime>0){&error("다음의 전투까지 $btime 초 기다려 주세요.");}

	$rand=int(rand(1000));
	
	if(int(rand(50)) eq 7){$monfile="monster2.cgi";$reamon=1;}
	else{$monfile="monster.cgi";}
	open(IN,"./data/$monfile") or &error("타운 데이터 파일이 열리지 않습니다.");
	@MON_DATA = <IN>;
	close(IN);

	$mode=$in{'mode'};
	$mode2=$in{'mode'};
	if($in{'mode'} eq 5){
		$mode=1;
		if($mex%11 ne 0){
			&maplog("<font color=red>[부정]</font>$mname는 $SEN[$in{'mode'}]로 부정을 실시했습니다.");
			&error("부정을 실시했습니다.5");
		}
	}
	elsif($in{'mode'} eq 6){
		$mode=2;
		if($moya%40 ne "0"){
			&maplog("<font color=red>[부정]</font>$mname는 $SEN[$in{'mode'}]로 부정을 실시했습니다.");
			&error("부정을 실시했습니다.6");
		}
	}elsif($in{'mode'} eq 7){
		$mode=2;
		if(int(rand(15)) eq 7){
			$xmode=1;
			$mode2=18;
		}
		
		if($moya%80 ne "7"){
			&maplog("<font color=red>[부정]</font>$mname는 $SEN[$in{'mode'}]로 부정을 실시했습니다.");
			&error("부정을 실시했습니다.7");
		}
	}elsif($in{'mode'} eq 8){
		$mode=3;
		if($moya%300 ne "8"){
			&maplog("<font color=red>[부정]</font>$mname는 $SEN[$in{'mode'}]로 부정을 실시했습니다.");
			&error("부정을 실시했습니다.8");
		}
	}
	elsif($in{'mode'} eq 9){
		$mode=4;
		if($moya%1000 ne "9"){
			&maplog("<font color=red>[부정]</font>$mname는 $SEN[$in{'mode'}]로 부정을 실시했습니다.");
			&error("부정을 실시했습니다.9");
		}
	}
	elsif($in{'mode'} eq 10){
		$mode=1;
		if($moya ne "777"){
			&maplog("<font color=red>[부정]</font>$mname는 $SEN[$in{'mode'}]로 부정을 실시했습니다.");
			&error("부정을 실시했습니다.10");
		}
	}
	elsif($in{'mode'} eq 11){
		$mode=2;
		if($moya%2500 ne "17"){
			&maplog("<font color=red>[부정]</font>$mname는 $SEN[$in{'mode'}]로 부정을 실시했습니다.");
			&error("부정을 실시했습니다.11");
		}
	}
	elsif($in{'mode'} eq 12){
		$mode=3;
		if($moya ne "55555"){
			&maplog("<font color=red>[부정]</font>$mname는 $SEN[$in{'mode'}]로 부정을 실시했습니다.");
			&error("부정을 실시했습니다.12");
		}
	}
	elsif($in{'mode'} eq 13){
		$mode=3;
		if($moya%5000 ne "773"){
			&maplog("<font color=red>[부정]</font>$mname는 $SEN[$in{'mode'}]로 부정을 실시했습니다.");
			&error("부정을 실시했습니다.13");
		}
	}
	elsif($in{'mode'} eq 14){
		$mode=1;
		if($moya ne "77777"){
			&maplog("<font color=red>[부정]</font>$mname는 $SEN[$in{'mode'}]로 부정을 실시했습니다.");
			&error("부정을 실시했습니다.14");
		}
	}
	elsif($in{'mode'} eq 15){
		$mode=1;
		if($moya ne "775" && $moya ne "776"){
			&maplog("<font color=red>[부정]</font>$mname는 $SEN[$in{'mode'}]로 부정을 실시했습니다.");
			&error("부정을 실시했습니다.15");
		}
	}

	@N_MON_DATA=();
	foreach(@MON_DATA){
		($ename,$eab,$etec,$esk,$e_ex,$e_gold,$etype,$elv) =split(/<>/);
		if($elv eq $mode){push(@N_MON_DATA,"$_");}
	}
	if(@N_MON_DATA ==()){&error("몬스터 데이터에 이상이 있습니다");}
	$rand=int(rand(@N_MON_DATA));
	($ename,$eab,$etec,$esk,$e_ex,$e_gold,$etype,$elv) =split(/<>/,$N_MON_DATA[$rand]);
	($ehp,$emp,$str,$vit,$eint,$efai,$edex,$eagi,$eele) =split(/,/,$eab);

	$emaxhp=int(($ehp+$mmaxhp/2)/1.5);
	$emaxmp=$emp + int(rand($emp/2));
	if($reamon){
		$emaxhp=$ehp;
		$emaxmp=$emp;
	}
	$estr=int(($str+($mstr+$mvit)/2)/1.7);
	$evit=int(($vit+($mstr+$mvit)/2)/1.7);
	
	$epoint=int(($ehp+$emp)/3) +$str+$vit+$eint+$efai+$edex+$eagi;

	if($mode eq 1){$echara="enemy";}
	elsif($mode eq 2){$echara="enemy2";}
	elsif($mode eq 3){$echara="enemy3";}
	else{$echara="enemy4";}
	$ehp2=$ehp;
	$emp2=$emp;

	&PARA;
	&TEC_OPEN;
	&header;
	
	print <<"EOF";
<TABLE border="0" width="100%" align=center height="144" CLASS=TOC>
  <TBODY>
    <TR>
      <TD colspan="3" align="center" bgcolor="$ELE_BG[$town_ele]"><FONT color="#ffffcc">$town_name $sen$SEN[$in{'mode'}]</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#cccccc" width="30%">
      <TABLE border="0" width="100%" height="100%" bgcolor=$ELE_BG[$mele] align=right>
        <TBODY>
          <TR>
            <TD rowspan="2"><center><img src="./img/chara/$mchara.gif"></FONT></TD>
            <TD bgcolor=$FCOLOR2>HP$mode5</FONT></TD>
            <TD bgcolor=$FCOLOR2>$mhp/$mmaxhp</FONT></TD>
            <TD bgcolor=$FCOLOR2>공격력</FONT></TD>
            <TD bgcolor=$FCOLOR2>$mstr $chi1(+$marmdmg)</FONT></TD>
            <TD bgcolor=$FCOLOR2>무기</FONT></TD>
            <TD bgcolor=$FCOLOR2>$marmname<BR>
            【$marmdmg/$marmwei】</FONT></TD>
          </TR>
          <TR>
            <TD bgcolor=$FCOLOR2>MP</FONT></TD>
            <TD bgcolor=$FCOLOR2>$mmp/$mmaxmp</FONT></TD>
            <TD bgcolor=$FCOLOR2>방어력</FONT></TD>
            <TD bgcolor=$FCOLOR2>$mvit $chi1(+$mprodmg+$maccdmg)</FONT></TD>
            <TD bgcolor=$FCOLOR2>방어구</FONT></TD>
            <TD bgcolor=$FCOLOR2>$mproname<BR>
            【$mprodmg/$mprowei】</FONT></TD>
          </TR>
          <TR>
            <TD bgcolor=$FCOLOR2>$mname</FONT></TD>
            <TD bgcolor=$FCOLOR2>직업</FONT></TD>
            <TD bgcolor=$FCOLOR2>$JOB[$mclass]</TD>
            <TD bgcolor=$FCOLOR2>속도</FONT></TD>
            <TD bgcolor=$FCOLOR2>$magi</FONT></TD>
            <TD bgcolor=$FCOLOR2>악세사리</FONT></TD>
            <TD bgcolor=$FCOLOR2>$maccname<BR>
            【$maccdmg/$maccwei】</FONT></TD>
          </TR>
        </TBODY>
      </TABLE>
      </TD>
      <TD align="center" bgcolor="$FCOLOR2" width="20%"><IMG src="./img/etc/$mode2.jpg" width="150" height="113" border="0"></TD>
      <TD bgcolor="#cccccc" width=30%>
      <TABLE border="0" width="100%" height="100%" bgcolor=$ELE_BG[$eele]>
        <TBODY>
          <TR>
            <TD rowspan="2"><center><img src="./img/chara/$echara.gif"></FONT></TD>
            <TD bgcolor=$FCOLOR2>HP</FONT></TD>
            <TD bgcolor=$FCOLOR2>$ehp/$emaxhp</FONT></TD>
            <TD bgcolor=$FCOLOR2>공격력</FONT></TD>
            <TD bgcolor=$FCOLOR2>$estr $chi2</FONT></TD>
            <TD bgcolor=$FCOLOR2>무기</FONT></TD>
          </TR>
          <TR>
            <TD bgcolor=$FCOLOR2>MP</FONT></TD>
            <TD bgcolor=$FCOLOR2>$emp/$emaxmp</FONT></TD>
            <TD bgcolor=$FCOLOR2>방어력</FONT></TD>
            <TD bgcolor=$FCOLOR2>$evit $chi2</FONT></TD>
            <TD bgcolor=$FCOLOR2>방어구</FONT></TD>
         </TR>
          <TR>
            <TD bgcolor=$FCOLOR2>$ename</FONT></TD>
            <TD bgcolor=$FCOLOR2>직업</FONT></TD>
            <TD bgcolor=$FCOLOR2></TD>
            <TD bgcolor=$FCOLOR2>속도</FONT></TD>
            <TD bgcolor=$FCOLOR2>$eagi</FONT></TD>
            <TD bgcolor=$FCOLOR2>악세사리</FONT></TD>
          </TR>
        </TBODY>
      </TABLE>
      </TD>
    </TR>
    <TR>
      <TD bgcolor=#000000><font color="white">「$mcom」</font></TD>
      <TD align=center bgcolor="666600"><font color="white">$town_name $sen$SEN[$in{'mode'}]에서 일어난<br>이 전투의 승자는 과연 누가 될 것인가!</font></TD>
      <TD bgcolor=#000000><font color="white">「덤벼라, 후회하게 해 주지!」</font></TD>
    </TR>
  </TBODY>
</TABLE>
<BR><BR>
EOF


##전투 처리
	$turn=0;
	while($turn<=30){
		$turn++;
		if($turn>100){&error("루프");}
		$bmess="";
		if($mab[15] && $mabdmg[15]>$eabdmg[15] && int(rand(3-$mabdmg[15])) eq 0){$sensei = 1;}
		elsif($eab[15] && $eabdmg[15]>$mabdmg[15] && int(rand(3-$eabdmg[15])) eq 0){$sensei = 0;}
		elsif(int(rand($mdex)) > int(rand($edex))){$sensei = 1;}
		else{$sensei = 0;}
		if($sensei){
			if($mhp>0){&MATT;}
			if($ehp>0){
				if($reamon && int(rand(5)) eq 4){$bmess.="$ename는 도망갔다.";last;}
				&EATT;
			}
		}else{
			if($ehp>0){
				if($reamon && int(rand(5)) eq 4){$bmess.="$ename는 도망갔다.";last;}
				&EATT;
			}
			if($mhp>0){&MATT;}
		}
		if($win){
			$mkati++;
			&atp;
			&BPRINT;
			$mlv=int($mex/100)+1;
			
			$get_ex=(int($epoint/15) + 10 + int(rand(10)));
			if($get_ex>50){$get_ex = 50 + int(rand(10));}
			if($get_ex<10){$get_ex = 10 + int(rand(10));}

			
			if($in{'mode'} eq 5 && $mex < 9900){
				$mode=5;
				$get_ex = 100;
				$z_gold = int(rand($mex*20));
				$com.="$mname는<font color=blueviolet><b>숨은 재보</b></font>를 발견했다!<BR><font color=blue size=4><b>$z_gold</b></font>Gold를 손에 넣었다.<BR>";
			}
			elsif($in{'mode'} eq 7){
				$mode=10;
				$get_ex = 100;
				$z_gold = int(rand(300000));
				$com.="$mname는<font color=blueviolet><b>숨은 재보</b></font>를 발견했다!<BR><font color=blue size=4><b>$z_gold</b></font>Gold를 손에 넣었다.<BR>";
			}elsif($in{'mode'} eq 8){
				$mode=10;
				$get_ex = 100;
				$z_gold = int(rand(1000000));
				$com.="$mname는<font color=blueviolet><b>숨은 재보</b></font>를 발견했다!<BR><font color=blue size=4><b>$z_gold</b></font>Gold를 손에 넣었다.<BR>";
				
			}
			$getabp=$mode;
			if($in{'mode'} eq 9){
				$mode=9;
				$get_ex = 100;
				$getabp=100 + int(rand(200));
				if(int(rand(20)) eq 7){$getabp=1000;}
				$muprnd=int(rand(6));

				if($muprnd eq "0"){
					$mmaxstr += 1;
					$com.="<font color=orange>힘의 한계가 1올랐다!</font><BR>";
				}elsif($muprnd eq "1"){
					$mmaxvit += 1;
					$com.="<font color=orange>생명의 한계가 1올랐다!</font><BR>";
				}elsif($muprnd eq "2"){
					$mmaxint += 1;
					$com.="<font color=orange>지력의 한계가 1올랐다!</font><BR>";
				}elsif($muprnd eq "3"){
					$mmaxmen += 1;
					$com.="<font color=orange>정신의 한계가 1올랐다!</font><BR>";
				}elsif($muprnd eq "4"){
					$mmaxdex += 1;
					$com.="<font color=orange>운의 한계가 1올랐다!</font><BR>";
				}elsif($muprnd eq "5"){
					$mmaxagi += 1;
					$com.="<font color=orange>속도의 한계가 1올랐다!</font><BR>";
				}
				$mmax="$mmaxstr,$mmaxvit,$mmaxint,$mmaxmen,$mmaxdex,$mmaxagi,$mmaxlv";
			}
			if($in{'mode'} eq 6){
				$mode=6;
				$get_ex = 100;
				$getabp=int(rand(50));
				if(int(rand(20)) eq 7){$getabp=300;}
				$z_gold = int(rand(100000));
				$com.="$mname는<font color=blueviolet><b>숨은 재보</b></font>를 발견했다!<BR><font color=blue size=4><b>$z_gold</b></font>Gold를 손에 넣었다.<BR>";
			}
			if($in{'mode'} eq 13){
				$getabp = 1000;
			}
			if($mab[22]){
				$get_ex = int($get_ex*1.2);
				$getabp += 1;
			}

			if($reamon eq 1){$getabp=$mode*20;}
			
			# 자동 버닝
			&time_data;

#			$BMSG = "일주일동안 경험치 1.5배입니다.";

			if ($ww eq "Sun") {
				$com .= "<b>자동버닝: Sunday Burning</b><br>경험치, 숙련도 1.5배 획득<br>";
				$get_ex *= 1.5; $get_ex = int($get_ex);
				$getabp *= 1.5; $getabp = int($getabp);
			}elsif($hour eq 10 || $hour eq 22) {
				$com .= "<b>자동버닝: Climax Time</b><br>경험치, 숙련도 1.5배 획득<br>";
				$get_ex *= 1.5; $get_ex = int($get_ex);
				$getabp *= 1.5; $getabp = int($getabp);
			}elsif($BMSG) {
				$com .= "<b>깜짝버닝: 「$BMSG」</b><br>경험치, 숙련도 1.5배 획득<br>";
				$get_ex *= 1.5; $get_ex = int($get_ex);
				$getabp *= 1.5; $getabp = int($getabp);
			}

			# 주문서, 속성 변경의 돌 겟
			if(int(rand(100000)) eq "77777") {
				open(IN,"./logfile/item/$in{'id'}.cgi");
				@ITEM = <IN>;
				close(IN);

				$grade = (SS,S,A,B,C)[int(rand(4))];

				if(@ITEM<$ITM_MAX){
					push(@ITEM,"rea<>3<>$grade급위력강화주문서<>0<>0<>0<>0<>0<>0<>0<>10<>0<>\n");
					open(OUT,">./logfile/item/$in{'id'}.cgi");
					print OUT @ITEM;
					close(OUT);
					$com.="<BR><B><font color=#ff0066>$grade급위력강화주문서</font></B>를 발견했다!!<BR>";
					&maplog("<font color=#ff0066>[발견]</font>$mname는 $SEN[$in{'mode'}]로<font color=red>$grade급위력강화주문서</font>를 발견했습니다!!");
					&maplog7("<font color=#ff0066>[발견]</font>$mname는 $SEN[$in{'mode'}]로 $led<font color=red>$grade급위력강화주문서</font>를 발견했습니다!!");
				}
			}
			elsif(int(rand(10000)) eq "77777") {
				open(IN,"./logfile/item/$in{'id'}.cgi");
				@ITEM = <IN>;
				close(IN);
				$grade = ("무","불","수","풍","별","번개","빛","어둠")[int(rand(7))];

				if(@ITEM<$ITM_MAX){
					push(@ITEM,"rea<>3<>$grade속성변경의돌<>0<>0<>0<>0<>0<>0<>0<>10<>0<>\n");
					open(OUT,">./logfile/item/$in{'id'}.cgi");
					print OUT @ITEM;
					close(OUT);
					$com.="<BR><B><font color=#ff0066>$grade속성변경의돌</font></B>를 발견했다!!<BR>";
					&maplog("<font color=#ff0066>[발견]</font>$mname는 $SEN[$in{'mode'}]로<font color=red>$grade속성변경의돌</font>를 발견했습니다!!");
					&maplog7("<font color=#ff0066>[발견]</font>$mname는 $SEN[$in{'mode'}]로 $led<font color=red>$grade속성변경의돌</font>를 발견했습니다!!");
				}
			}
			
			# 퀘스트
			require './data/quest.cgi';

			($a,$b,$thank) = split(/<>/, $QUEST->{$mquest});

			$mquest2=0 if !$mquest;

			if ($mquest eq "goblin" && $ename eq "고블린") {
				$mquest2++;
				$com .= "고블린을 잡았다. ($mquest2/500마리 남음)<br>";
				if ($mquest2 > 500) {
					&maplog("<font color=orange>[퀘스트]</font>$mname은 고블린 퇴치작전을 완수했다. 1천만 골드와 명성 1천을 획득했다.");
					$mgold += 10000000;
					$mcex += 1000;
					$mquest=0; $mquest2=0;
					&chara_input;
					$com .= "<b>고블린 500마리를 잡았다.</b><br>보상으로 1천만 골드와 명성 1천을 획득!<br>「$thank」<br>";
				}
			}

			if ($mquest eq "incubus") {
				open(IN,"./logfile/item/$in{'id'}.cgi");
				@ITEM = <IN>;
				close(IN);
				if (int(rand(1000000)) eq "7" && @ITEM<$ITM_MAX) {
					$grade = ("1","2","3","4","5")[int(rand(4))];

					push(@ITEM,"rea<>3<>인큐버스의$grade번째날개<>0<>0<>0<>0<>0<>0<>0<>10<>0<>\n");
					open(OUT,">./logfile/item/$in{'id'}.cgi");
					print OUT @ITEM;
					close(OUT);
					$com .= "<B>인큐버스의 $grade번째 날개를 획득했다.<br></b>";
				}

				$isw1=$isw2=$isw3=$isw4=$isw5=$no=0;

				foreach(@ITEM) {
					($a,$b,$name) = split(/<>/);
					if ($name =~ /인큐버스의1번째날개/) { $isw1 = $no; }
					if ($name =~ /인큐버스의2번째날개/) { $isw2 = $no; }
					if ($name =~ /인큐버스의3번째날개/) { $isw3 = $no; }
					if ($name =~ /인큐버스의4번째날개/) { $isw4 = $no; }
					if ($name =~ /인큐버스의5번째날개/) { $isw5 = $no; }
					$no++;
				}

				if ($isw1 && $isw2 && $isw3 && $isw4 && $isw5) {
					&maplog("<font color=orange>[퀘스트]</font>$mname은 수집광 월야를 완수했다. 7백만 골드와 명성 777을 획득했다.");
					$mgold += 7000000;
					$mcex += 777;
					$mquest=0; $mquest2=0;
					&chara_input;
					$com .= "인큐버스 날개 5개를 획득! 보상으로 700만 골드와 명성 777을 획득!<br>「$thank」<br>";

					splice(@ITEM,$isw1,1);
					splice(@ITEM,$isw2,1);
					splice(@ITEM,$isw3,1);
					splice(@ITEM,$isw4,1);
					splice(@ITEM,$isw5,1);
				
					open(OUT,">./logfile/item/$in{'id'}.cgi");
					print OUT @ITEM;
					close(OUT);
				}
			}

			$mbex=$mex;
			if($mex<9900){
				$mex+=$get_ex;
			}
			$mtotalex+=$get_ex;
			$get_gold=($epoint + int(rand($epoint/5)))*4;

			$mabp+=$getabp;
			$bmjp[$mtype]=$mjp[$mtype];
			$mjp[$mtype]+=$getabp;
			if($mjp[$mtype]>$MAXJOB){$mjp[$mtype] = $MAXJOB;}
			
			if($mab[13]){
				$find = int($mabdmg[13]/750);
			}
			if(int(rand(10-$find)) eq 1){
				$add_gold=int(rand($get_gold*5+1000));
				$com.="골드 보너스! <font color=orange size=4>$add_gold</font>Gold를 더 주었다.<BR>";
			}

			# 사냥세
			open(IN,"./data/country.cgi");
			@CON_DATA=<IN>;
			close(IN);

			$hit=0;
			foreach(@CON_DATA){
				($con2_id,$con2_name,$con2_ele,$con2_gold,$con2_king,$con2_yaku,$con2_cou,$con2_mes,$con2_etc,$con2_tax) =split(/<>/);
				if("$con2_id" eq "$town_con"){$hit=1;last;}
			}

			if ($hit) {
				$get_gold3 = int(($get_gold+$add_gold+$z_gold) * 0.01 * $con2_tax);
				$com .= "사냥금 중 $get_gold3골드는 $con2_name국의 사냥세($con2_tax%)로 납부했다.<br>";
				$town_gold += $get_gold3;
				&town_input;
			}
			else {
				$get_gold3 = 0;
			}

			$get_gold2=$get_gold+$add_gold + $z_gold - $get_gold3;

			$mgold+=$get_gold2;

			##레벨업
			&LVUP;

			##한계 업
			$maxtotal = $mmaxstr + $mmaxvit + $mmaxint + $mmaxmen + $mmaxdex + $mmaxagi;
			$maxrand = int(($maxtotal - 1000)/20);
			if($maxrand<0){&error("한계치에 이상이 있습니다.");}
			$maxrand2 = $maxrand * $maxrand;
			if($mab[22]){
				$maxrand2=int($maxrand2/1.5);
			}
			if(int(rand($maxrand2)) eq "1" || $in{'mode'} eq "13"){
				&MAXUP;
			}

			##보상겟트
			$reaup = 0;
			if($mab[13]){
				$reaup += $mabdmg[13];
			}
			if($in{'mode'} eq 4){$reaup += 2000;}
			$han2=int(rand(10000-$reaup));
			if($in{'mode'} eq "12" && int(rand(5)) eq "3"){
				$rflg=1;
				$REA="item";
				$reano=3;
				$b_no2 = int(rand(5));
				$ino=45+$b_no2;
				$reahit=1;
				$iflg=1;
			}elsif($in{'mode'} eq "14"){
				$rflg=1;
				$REA="item";
				$reano=3;
				$b_no2 = int(rand(4));
				$ino=44;
				$reahit=1;
			}elsif($in{'mode'} eq "9" && int(rand(15)) eq 7){
				$rflg=1;
				$REA="item";
				$reano=3;
				$b_no2 = 0;
				$ino=50;
				$reahit=1;
			}elsif($in{'mode'} >= 3 && $han2 eq "7" || $in{'mode'} eq "10"){
				$brand=int(rand(5));
				if($in{'mode'} eq 3 || $in{'mode'} eq 4){
					$brand=int(rand(3)) + 1;
					$rrand=7;
				}else{
					$rrand=15;
				}
				if($brand eq 1){
					$REA="rarearm";
					$reano=0;
					$b_no2 = int(rand(26));
					if(int(rand($rrand)) eq 1){
						$b_no2 = 26 + int(rand(35));
					}
					$ino=$b_no2;
				}
				elsif($brand eq 2){
					$rflg=1;
					$REA="rarepro";
					$reano=1;
					$b_no2 = int(rand(23));
					if(int(rand($rrand)) eq 1){
						$b_no2 = 23 + int(rand(21));
					}
					$ino=$b_no2;
				}
				elsif($brand eq 3){
					$rflg=1;
					$REA="rareacc";
					$reano=2;
					$b_no2 = int(rand(25));
					if(int(rand($rrand)) eq 1){
						$b_no2 = 25 + int(rand(22));
					}
					$ino=$b_no2;
				}else{
					$rflg=1;
					$REA="item";
					$reano=3;
					$b_no2 = int(rand(21));
					$ino=19+$b_no2;
				}
				$reahit=1;
			}
			if($reahit){
				open(IN,"./data/$REA.cgi");
				@REA = <IN>;
				close(IN);
				($it_name,$it_val,$it_dmg,$it_wei,$it_ele,$it_hit,$it_cl,$it_type,$it_sta,$it_pos) = split(/<>/,$REA[$ino]);

				open(IN,"./logfile/item/$in{'id'}.cgi");
				@ITEM = <IN>;
				close(IN);
				if(@ITEM<$ITM_MAX && $it_name ne ""){
					push(@ITEM,"rea<>$reano<>$it_name<>$it_val<>$it_dmg<>$it_wei<>$it_ele<>$it_hit<>$it_cl<>$it_type<>$it_sta<>0<>\n");
					open(OUT,">./logfile/item/$in{'id'}.cgi");
					print OUT @ITEM;
					close(OUT);
					$com.="<BR><B><font color=#ff0066>$it_name</font></B>를 발견했다!!<BR>";
					&maplog("<font color=#ff0066>[발견]</font>$mname는 $SEN[$in{'mode'}]로<font color=red>$it_name</font>를 발견했습니다!!");
					&maplog7("<font color=#ff0066>[발견]</font>$mname는 $SEN[$in{'mode'}]로 $led<font color=red>$it_name</font>를 발견했습니다!!");
				}
			}

			print <<"EOF";
			<center>
			<TABLE border="0" width="400" bgcolor="#000000" CLASS=TC>
  			<TBODY><TR>
      			<TD colspan="2" align="center" bgcolor="$FCOLOR"><FONT color="#ffffcc">승리!</FONT></TD>
    			</TR>
    			<TR><TD colspan="2" align="center" bgcolor="$FCOLOR2">
			경험치<FONT color="#cc0000">$get_ex</FONT>포인트 획득<BR>
      			<FONT color="#000099">$get_gold</FONT> Gold를 손에 넣었다!<BR>
			숙련도<FONT color="#cc0000">$getabp</FONT>포인트 획득<BR>
			$com<BR>
      			<TABLE border="0" bgcolor="#990000">
        		<TBODY><TR>
            		<TD bgcolor="#ffffcc">경험치</TD>
            		<TD bgcolor="#ffffcc">$mex(+$get_ex) point</TD>
          		</TR>
          		<TR><TD bgcolor="#ffffcc">Gold</TD>
            		<TD bgcolor="#ffffcc">$mgold(+$get_gold2) Gold</TD>
          		</TR></TBODY></TABLE>
      			</TD></TR>
  			</TBODY></TABLE>
			</center>
EOF
			last;
		}if($lose){
			
			$bmess.="$mname의 소지금이 반이 되어 버렸다.";
			$mgold=int($mgold/2);
			&atp;
			&BPRINT;last;
		}
		&BPRINT;
	}
	if(!$win && !$lose){
		$bmess.="결착이 붙지 않았다.";
		&atp;
		&BPRINT;
	}

	if($mab[30]){
		$un = 8000;
		$un2 = 5;
	}
	if($moya eq "55555"){
		if($iflg || int(rand(5)) eq "1" || $lose){
			$moya=int(rand(30000));
		}
	}
	else{$moya=int(rand(20000-$un));}

	if($in{'mode'} eq 11){$moya = 775 + int(rand(12-$un2));}
	elsif($in{'mode'} eq 15){
		if(int(rand(30)) eq 7){$moya=77777;}
		else{$moya = 777 + int(rand(4));}
	}
	elsif($mode2 eq 18){$moya = 770 + int(rand(15-$un2));}
	elsif($in{'mode'} eq 7 && $moya ne 777 && $moya ne 775 && $moya ne 776){$moya = int(rand(20-$un2));}
	elsif($in{'mode'} eq 8 && int(rand(10)) eq 1 && !$lose){
		$moya = 55555;
	}
	if($moya eq 777 && $mtotal<3000 && int(rand(4)) < 3){
		$moya=int(rand(20000-$un));
	}

	if(int(rand(150000)) eq 777){
		$moya=77777;
	}

	&chara_input;


if($moya eq "77777"){$dun.="<OPTION value=14 style=\"background-color:yellow;\">◆ $SEN[14]";}
if($moya eq "777"){$dun.="<OPTION value=10 style=\"background-color:yellow;\">◆ $SEN[10]";}
if($moya eq "775" || $moya eq "776"){$dun.="<OPTION value=15 style=\"background-color:yellow;\">◆ $SEN[15]";}
if($moya%5000 eq "773"){$dun.="<OPTION value=13 style=\"background-color:yellow;\">◆ $SEN[13]";}
if($moya eq "55555"){$dun.="<OPTION value=12 style=\"background-color:yellow;\">◆ $SEN[12]";}
if($moya%2500 eq "17"){$dun.="<OPTION value=11 style=\"background-color:yellow;\">◆ $SEN[11]";}
if($moya%1000 eq "9"){$dun.="<OPTION value=9 style=\"background-color:yellow;\">◆ $SEN[9]";}
if($moya%300 eq "8"){$dun.="<OPTION value=8 style=\"background-color:yellow;\">◆ $SEN[8]";}
if($moya%80 eq "7"){$dun.="<OPTION value=7 style=\"background-color:yellow;\">◆ $SEN[7]";}
if($moya%40 eq "0"){$dun.="<OPTION value=6 style=\"background-color:yellow;\">◆ $SEN[6]";}
if($mex%11 eq "0" && $mex < 9900){$dun.="<OPTION value=5 style=\"background-color:yellow;\">◆ $SEN[5]";}

if($moya%1000 eq "1"){$shop.="<OPTION style=\"background-color:pink;\" value=rshop>마녀의 가게";}
if($moya%5000 eq "37"){$status.="<OPTION style=\"background-color:#CCFFCC;\" value=name_change>개명의 신전";}

	$injung = int(($mmacro - time) / 60 * 100)/100; $injung=0 if $injung < 0;

	print <<"EOF";
	<center>
	<form action="./battle.cgi" method="post">
		<br>
		<Br>
		<div id=reload>남은 딜레이: <b>8</b>초</div>
		<br>
		<div id=macro>남은 인증시간: <b>$injung</b>분</div>
		<Br>
		<script>
			var t = 8;
			function dec() {
				t--;
				reload.innerHTML = '남은 딜레이: <b>' + t + '</b>초';
				if (t > 0) { 
					setTimeout("dec()",1000);
				}
			}
			dec();
		</script>
		<input type=hidden name=id value=$mid>
		<input type=hidden name=pass value=$mpass>
		<SELECT name=mode> 
		    $dun
		    <OPTION value=1>◆ $town_name 평야
                    <OPTION value=2>◆ $town_name 늪지대
                    <OPTION value=3>◆ $town_name의 숲
		    <OPTION value=4>◆ $town_name의 탑
      		    <OPTION value="">===============
      		    <OPTION value=kunren>◆ 훈련
		    <OPTION value=toubatsu>◆ 토벌
		</SELECT>
	<INPUT type="submit" CLASS=MFC value="실행" onSubmit="return" check()>
		</form>
	<form action="./top.cgi" method="POST">
	<input type=hidden name=id value="$mid">
	<input type=hidden name=pass value="$mpass">
	<input type="submit" value="돌아온다" CLASS=FC>
	</form>
	<form action="./status.cgi" method="POST">
	<input type=hidden name=id value="$mid">
	<input type=hidden name=pass value="$mpass">
	<INPUT type=hidden name=mode value=backup>
	<input type="submit" value="백업하기" CLASS=FC>
	</form>
	<form action="./town.cgi" method="POST">
	<input type=hidden name=id value="$mid">
	<input type=hidden name=pass value="$mpass">
	<INPUT type=hidden name=mode value=inn>
	<input type="submit" value="여관으로" CLASS=FC>
	</form>
	<form action="./town.cgi" method="POST">
	<input type=hidden name=id value="$mid">
	<input type=hidden name=pass value="$mpass">
	<INPUT type=hidden name=mode value=bank>
	<input type="submit" value="은행으로" CLASS=FC>
	</form>
	<P><hr size=0></center>
	</center>
EOF
	&footer;
}
sub atp{
	open(IN,"./logfile/item/$in{'id'}.cgi");
	@K_ITEM = <IN>;
	close(IN);
	$ihit=0;
	@NEW_C_ITEM=();
	foreach(@K_ITEM){
		($k_no,$k_mark,$k_name,$k_val,$k_dmg,$k_wei,$k_ele,$k_hit,$k_cl,$k_type,$k_sta,$k_flg) = split(/<>/);
		if($k_sta eq "1" || $k_sta eq "99") {
			if($k_sta eq "1"){
				$mhp = $mmaxhp;
				$k_val-=$mmaxhp*2;
				$ihit=1;
				$pnum = int($k_val/2);
				$bmess.= "<BR>$k_name를 사용했다.(나머지<font color=red>$pnum</font>)<BR>";
				if($k_val <0){
					$bmess.= "<font color=red>$k_name는 흔적도 없게 무너져 떠났다..</font><BR>";
				}else{
					push(@NEW_C_ITEM,"$k_no<>$k_mark<>$k_name<>$k_val<>$k_dmg<>$k_wei<>$k_ele<>$k_hit<>$k_cl<>$k_type<>$k_sta<>$k_flg<>\n");
				}
			}
			if($k_sta eq "99"){
				$mmp = $mmaxmp;
				$k_val-=$mmaxmp*2;
				$ihit=1;
				$pnum = int($k_val/2);
				$bmess.= "<BR>$k_name를 사용했다.(나머지<font color=red>$pnum</font>)<BR>";
				if($k_val <0){
					$bmess.= "<font color=red>$k_name는 흔적도 없게 무너져 떠났다..</font><BR>";
				}else{
					push(@NEW_C_ITEM,"$k_no<>$k_mark<>$k_name<>$k_val<>$k_dmg<>$k_wei<>$k_ele<>$k_hit<>$k_cl<>$k_type<>$k_sta<>$k_flg<>\n");
				}
			}
		}
		else{
			push(@NEW_C_ITEM,"$_");
		}
	}
	open(OUT,">./logfile/item/$in{'id'}.cgi");
	print OUT @NEW_C_ITEM;
	close(OUT);
}

1;
