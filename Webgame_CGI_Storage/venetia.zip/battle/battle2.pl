sub battle2{
	&chara_open;
	&town_open;
	if($in{'mode'} eq ""){&error("올바르게 선택되고 있지 않습니다.");}
	$mgold-=10000;
	if($mgold<0){&error("돈이 충분하지 않습니다.");}

	$mtotal++;
	$date = time();
	$btime = $BTIME - $date + $mdate;
	if($btime>0){&error("다음의 전투까지 $btime 초 기다려 주세요.");}

	open(IN,"./data/chanp.cgi") or &error("체프데이타파일이 열리지 않습니다.");
	@CHANP_DATA = <IN>;
	close(IN);
	($eid,$ename,$echara,$eele,$ehp,$emaxhp,$emp,$emaxmp,$estr,$evit,$eint,$efai,$edex,$eagi,$earm,$epro,$eacc,$etec,$esk,$etype,$eclass,$emes,$eex,$egold,$eren) =split(/<>/,$CHANP_DATA[0]);
	
	$ehp2=$ehp;
	$emp2=$emp;
	&equip_open;

	$epoint=int(($ehp+$emp)/3) +$estr+$evit+$eint+$efai+$edex+$eagi;

	&PARA;
	&TEC_OPEN;

	&header;
	
	print <<"EOF";
<TABLE border="0" width="100%" align=center height="144" CLASS=TOC>
  <TBODY>
    <TR>
      <TD colspan="3" align="center" bgcolor="$ELE_BG[$town_ele]"><FONT color="#ffffcc">투기장</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#cccccc" width="30%">
      <TABLE border="0" width="100%" height="100%" bgcolor=$ELE_BG[$mele] align=right>
        <TBODY>
          <TR>
            <TD rowspan="2"><FONT size="-1"><img src="./img/chara/$mchara.gif"></FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">HP</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">$mhp/$mmaxhp</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">공격력</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">$mstr(+$marmdmg)</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">무기</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">$marmname<BR>
            【$marmdmg/$marmwei】</FONT></TD>
          </TR>
          <TR>
            <TD bgcolor=$FCOLOR2><FONT size="-1">MP</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">$mmp/$mmaxmp</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">방어력</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">$mvit(+$mprodmg)</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">방어구</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">$mproname<BR>
            【$mprodmg/$mprowei】</FONT></TD>
          </TR>
          <TR>
            <TD bgcolor=$FCOLOR2><FONT size="-1">$mname</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">직업</FONT></TD>
            <TD bgcolor=$FCOLOR2>$JOB[$mclass]</TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">속도</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">$magi</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">악세사리</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">$maccname<BR>
            【$maccdmg/$maccwei】</FONT></TD>
          </TR>
        </TBODY>
      </TABLE>
      </TD>
      <TD align="center" bgcolor="$FCOLOR2" width="20%"><IMG src="./img/etc/arena.jpg" width="150" height="113" border="0"></TD>
      <TD bgcolor="#cccccc" width=30%>
      <TABLE border="0" width="100%" height="100%" bgcolor=$ELE_BG[$eele]>
        <TBODY>
          <TR>
            <TD rowspan="2"><FONT size="-1"><img src="./img/chara/$echara.gif"></FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">HP</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">$ehp/$emaxhp</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">공격력</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">$estr</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">무기</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">$earmname<BR>【$earmdmg/$earmwei】</FONT></TD>
          </TR>
          <TR>
            <TD bgcolor=$FCOLOR2><FONT size="-1">MP</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">$emp/$emaxmp</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">방어력</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">$evit</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">방어구</FONT></TD>
	    <TD bgcolor=$FCOLOR2><FONT size="-1">$eproname<BR>【$eprodmg/$eprowei】</FONT></TD>
         </TR>
          <TR>
            <TD bgcolor=$FCOLOR2><FONT size="-1">$ename</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">직업</FONT></TD>
            <TD bgcolor=$FCOLOR2></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">속도</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">$eagi</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">악세사리</FONT></TD>
	    <TD bgcolor=$FCOLOR2><FONT size="-1">$eaccname<BR>【$eaccdmg/$eaccwei】</FONT></TD>
          </TR>
        </TBODY>
      </TABLE>
      </TD>
    </TR>
    <TR>
      <TD bgcolor=#000000><font color="white" size="-1">「$mcom」</font></TD>
      <TD align=center bgcolor="666600"><font color="white" size="-1">코멘트</font></TD>
      <TD bgcolor=#000000><font color="white" size="-1">「$emes」</font></TD>
    </TR>
  </TBODY>
</TABLE>
<BR><BR>
EOF


##전투 처리
	$turn=0;
	while($turn<=50){
		$turn++;
		$bmess="";
		if($mab[15] && $mabdmg[15]>$eabdmg[15] && int(rand(3-$mabdmg[15])) eq 0){$sensei = 1;}
		elsif($eab[15] && $eabdmg[15]>$mabdmg[15] && int(rand(3-$eabdmg[15])) eq 0){$sensei = 0;}
		elsif(int(rand($mdex)) > int(rand($edex))){$sensei = 1;}
		else{$sensei = 0;}
		if($sensei){
			if($mhp>0){&MATT;}
			if($ehp>0){&EATT;}
		}else{
			if($ehp>0){&EATT;}
			if($mhp>0){&MATT;}
		}if($win){
			$mkati++;
			&BPRINT;
			$mlv=int($mex/100)+1;
			$get_ex=$epoint + int(rand($epoint/3));
			if($get_ex>50){$get_ex = 50 + int(rand(10));}
			if($get_ex<10){$get_ex = 10 + int(rand(10));}

			$mbex=$mex;
			if($mex<9900){
				$mex+=$get_ex;
			}
			$mtotalex+=$get_ex;
			$get_gold=$egold;
			push(@N_CHANP,"$mid<>$mname<>$mchara<>$mele<>$mmaxhp<>$mmaxhp<>$mmaxmp<>$mmaxmp<>$mstr<>$mvit<>$mint<>$mfai<>$mdex<>$magi<>$marm<>$mpro<>$macc<>$mtec<>$msk<>$mtype<>$mclass<>$mcom<>$mex<>20000<>1<>\n");
			open(OUT,">./data/chanp.cgi") or &error('체프데이타를 쓸 수 없습니다.');
			print OUT @N_CHANP;
			close(OUT);

			$mgold+=$get_gold;

			##레벨업
			&LVUP;

			print <<"EOF";
			<center>
			<TABLE border="0" width="400" bgcolor="#000000" CLASS=TC>
  			<TBODY><TR>
      			<TD colspan="2" align="center" bgcolor="$FCOLOR"><FONT color="#ffffcc">승리!</FONT></TD>
    			</TR>
    			<TR><TD colspan="2" align="center" bgcolor="$FCOLOR2">경험치<FONT color="#cc0000">$get_ex</FONT>포인트 획득<BR>
      			<FONT color="#000099">$get_gold</FONT> Gold를 손에 넣었다!<BR>$com<BR>
      			<TABLE border="0" bgcolor="#990000">
        		<TBODY><TR>
            		<TD bgcolor="#ffffcc">경험치</TD>
            		<TD bgcolor="#ffffcc">$mex(+$get_ex) point</TD>
          		</TR>
          		<TR><TD bgcolor="#ffffcc">Gold</TD>
            		<TD bgcolor="#ffffcc">$mgold(+$get_gold) Gold</TD>
          		</TR></TBODY></TABLE>
      			</TD></TR>
  			</TBODY></TABLE>
			</center>
EOF
			last;
		}if($lose){
			$bmess.="$mname의 소지금이 반이 되어 버렸다.";
			$mgold=int($mgold/2);
			$egold+=10000;
			$eren++;
			push(@N_CHANP,"$eid<>$ename<>$echara<>$eele<>$emaxhp<>$emaxhp<>$emaxmp<>$emaxmp<>$estr<>$evit<>$eint<>$efai<>$edex<>$eagi<>$earm<>$epro<>$eacc<>$etec<>$esk<>$etype<>$eclass<>$emes<>$eex<>$egold<>$eren<>\n");
			open(OUT,">./data/chanp.cgi") or &error('체프데이타를 쓸 수 없습니다.');
			print OUT @N_CHANP;
			close(OUT);

			&BPRINT;last;
		}
		&BPRINT;
	}
	if(!$win && !$lose){
		$bmess.="결착이 붙지 않았다.";
		&BPRINT;
	}
	&chara_input;

	print <<"EOF";
	<center>
	<P><font color=red><B>$_[0]</B></font>
	<form action="./top.cgi" method="POST">
	<input type=hidden name=id value="$mid">
	<input type=hidden name=pass value="$mpass">
	<CENTER>
	<input type="submit" value="돌아온다" CLASS=FC>
	</CENTER>
	<BR><BR>
	</form>
	<P><hr size=0></center>
	</center>
EOF
	&footer;
}

1;
