sub bat3{
	&chara_open;
	&town_open;
	&equip_open;
	if($in{'mode'} eq "" || $SEN[$in{'mode'}] eq ""){&error("올바르게 선택되고 있지 않습니다.");}

	$mtotal++;
	$date = time();
	$btime = $BTIME - $date + $mdate;
	if($btime>0){&error("다음의 전투까지 $btime 초 기다려 주세요.");}

	
	$mode=$in{'mode'};

	if($moya%50 ne 0){
		&maplog("<font color=red>[부정]</font>$mname는 $SEN[$in{'mode'}]로 부정을 실시했습니다.");
		&error("부정을 실시했습니다.");
	}

	$emaxhp=10000;
	$emaxmp=3000;
	$estr=50;
	$evit=50;
	$eint=50;
	$efai=50;
	$edex=50;
	$eagi=50;
	$ename="선인";
	$etec="90,92,95,20,20";
	$ecom="수행 개시다∼.";
	
	$epoint=int(($ehp+$emp)/3) +$estr+$evit+$eint+$efai+$edex+$eagi;

	$echara="161";
	$ehp=$emaxhp;
	$emp=$emaxmp;

	&PARA;
	&TEC_OPEN;

	&header;
	
	print <<"EOF";
<TABLE border="0" width="100%" align=center height="144" CLASS=TOC>
  <TBODY>
    <TR>
      <TD colspan="3" align="center" bgcolor="$ELE_BG[$town_ele]"><FONT color="#ffffcc">$town_name $sen$SEN[$in{'mode'}]</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#cccccc" width="30%">
      <TABLE border="0" width="100%" height="100%" bgcolor=$ELE_BG[$mele] align=right>
        <TBODY>
          <TR>
            <TD rowspan="2"><FONT size="-1"><img src="./img/chara/$mchara.gif"></FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">HP</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">$mhp/$mmaxhp</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">공격력</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">$mstr $chi1(+$marmdmg)</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">무기</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">$marmname<BR>
            【$marmdmg/$marmwei】</FONT></TD>
          </TR>
          <TR>
            <TD bgcolor=$FCOLOR2><FONT size="-1">MP</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">$mmp/$mmaxmp</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">방어력</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">$mvit $chi1(+$mprodmg)</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">방어구</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">$mproname<BR>
            【$mprodmg/$mprowei】</FONT></TD>
          </TR>
          <TR>
            <TD bgcolor=$FCOLOR2><FONT size="-1">$mname</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">직업</FONT></TD>
            <TD bgcolor=$FCOLOR2>$JOB[$mclass]</TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">속도</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">$magi</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">악세사리</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">$maccname<BR>
            【$maccdmg/$maccwei】</FONT></TD>
          </TR>
        </TBODY>
      </TABLE>
      </TD>
      <TD align="center" bgcolor="$FCOLOR2" width="20%"><IMG src="./img/etc/$in{'mode'}.jpg" width="150" height="113" border="0"></TD>
      <TD bgcolor="#cccccc" width=30%>
      <TABLE border="0" width="100%" height="100%" bgcolor=$ELE_BG[$eele]>
        <TBODY>
          <TR>
            <TD rowspan="2"><FONT size="-1"><img src="./img/chara/$echara.gif"></FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">HP</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">$ehp/$emaxhp</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">공격력</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">$estr $chi2</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">무기</FONT></TD>
          </TR>
          <TR>
            <TD bgcolor=$FCOLOR2><FONT size="-1">MP</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">$emp/$emaxmp</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">방어력</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">$evit $chi2</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">방어구</FONT></TD>
         </TR>
          <TR>
            <TD bgcolor=$FCOLOR2><FONT size="-1">$ename</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">직업</FONT></TD>
            <TD bgcolor=$FCOLOR2></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">속도</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">$eagi</FONT></TD>
            <TD bgcolor=$FCOLOR2><FONT size="-1">악세사리</FONT></TD>
          </TR>
        </TBODY>
      </TABLE>
      </TD>
    </TR>
    <TR>
      <TD bgcolor=#000000><font color="white" size="-1">「$mcom」</font></TD>
      <TD align=center bgcolor="666600"><font color="white" size="-1">코멘트</font></TD>
      <TD bgcolor=#000000><font color="white" size="-1">「$ecom」</font></TD>
    </TR>
  </TBODY>
</TABLE>
<BR><BR>
EOF


##전투 처리
	$turn=0;
	while($turn<=30){
		$turn++;

		$edef+=30;
		$emdef+=30;
		$eat+=30;
		$eint+=30;
		$efai+=30;
		$espeed+=30;
		
		if($turn>100){&error("루프");}
		$bmess="";
		if($mab[15] && !$eab[15]){$sensei = 1;}
		elsif($eab[15] && !$mab[15]){$sensei = 0;}
		elsif(int(rand($mdex)) > int(rand($edex))){$sensei = 1;}
		else{$sensei = 0;}
		if($sensei){
			if($mhp>0){&MATT;}
			if($ehp>0){
				&EATT;
			}
		}else{
			if($ehp>0){
				&EATT;
			}
			if($mhp>0){&MATT;}
		}
		if($win || $lose){
			if($win){$mkati++;}
			&atp;
			&BPRINT;
			$mlv=int($mex/100)+1;
			
			$get_ex=(int($epoint/15) + 10 + int(rand(10)))*10;
			if($get_ex>50){$get_ex = 50 + int(rand(10));}
			if($get_ex<10){$get_ex = 10 + int(rand(10));}

			$getabp=3;
			$getabp+=int($maxdmg/100);
			$getabp+=$turn*2;
			$getabp+=int(($emaxhp-$ehp)/500);
			if($win){$getabp=100;}
			$hval=int($getabp/20);
			
			$hantei[0]="불가";
			$hantei[1]="가능";
			$hantei[2]="합";
			$hantei[3]="양";
			$hantei[4]="우";
			$hantei[5]="천재";

			if($reamon eq 1){$getabp=$mode*100;}
			
			if($mab[22]){
				$get_ex = int($get_ex*1.2);
				$getabp += 1;
			}

			$mbex=$mex;
			if($mex<9900){
				$mex+=$get_ex;
			}
			$mtotalex+=$get_ex;
			$get_gold=0;

			$mabp+=$getabp;
			$bmjp[$mtype]=$mjp[$mtype];
			$mjp[$mtype]+=$getabp;
			if($mjp[$mtype]>$MAXJOB){$mjp[$mtype] = $MAXJOB;}
			
			##레벨업
			&LVUP;

			print <<"EOF";
			<center>
			<TABLE border="0" width="400" bgcolor="#000000" CLASS=TC>
  			<TBODY><TR>
      			<TD colspan="2" align="center" bgcolor="$FCOLOR"><FONT color="#ffffcc">종료!</FONT></TD>
    			</TR>
    			<TR><TD colspan="2" align="center" bgcolor="$FCOLOR2">
			턴수：<FONT color="#cc0000">$turn</FONT><BR>
      			최대 데미지：<FONT color="#cc0000">$maxdmg</FONT><BR>
      			선인 나머지 HP：<FONT color="#cc0000">$ehp</FONT><BR><BR>
      			<FONT color="#cc0000">판정：$hantei[$hval]</FONT><BR><BR>
      			
      			경험치<FONT color="#cc0000">$get_ex</FONT>포인트 획득<BR>
      			<FONT color="#000099">$get_gold</FONT> Gold를 손에 넣었다!<BR>
			숙련도<FONT color="#cc0000">$getabp</FONT>포인트 획득<BR>
			$com<BR>
      			<TABLE border="0" bgcolor="#990000">
        		<TBODY><TR>
            		<TD bgcolor="#ffffcc">경험치</TD>
            		<TD bgcolor="#ffffcc">$mex(+$get_ex) point</TD>
          		</TR>
          		<TR><TD bgcolor="#ffffcc">Gold</TD>
            		<TD bgcolor="#ffffcc">$mgold(+$get_gold2) Gold</TD>
          		</TR></TBODY></TABLE>
      			</TD></TR>
  			</TBODY></TABLE>
			</center>
EOF
			last;
		}
		$bmess.="$ename는 한층 더 진심을 보였다.";
		
		&BPRINT;
	}
	if(!$win && !$lose){
		$bmess.="결착이 붙지 않았다.";
		&atp;
		&BPRINT;
	}

	$moya=int(rand(10000));
	&chara_input;

	print <<"EOF";
	<center>
	<form action="./top.cgi" method="POST">
	<input type=hidden name=id value="$mid">
	<input type=hidden name=pass value="$mpass">
	<input type="submit" value="돌아온다" CLASS=FC>
	<BR><BR>
	</form>
	<form action="./town.cgi" method="POST">
	<input type=hidden name=id value="$mid">
	<input type=hidden name=pass value="$mpass">
	<INPUT type=hidden name=mode value=inn>
	<input type="submit" value="여인숙에 직행" CLASS=FC>
	</form>
	<P><hr size=0></center>
	</center>
EOF
	&footer;
}
sub atp{
	open(IN,"./logfile/item/$in{'id'}.cgi");
	@K_ITEM = <IN>;
	close(IN);
	$ihit=0;
	@NEW_C_ITEM=();
	foreach(@K_ITEM){
		($k_no,$k_mark,$k_name,$k_val,$k_dmg,$k_wei,$k_ele,$k_hit,$k_cl,$k_sta,$k_type,$k_flg) = split(/<>/);
		if($k_sta eq "1" && $ihit eq "0" && $k_mark eq 3){
			$mhp = $mmaxhp;
			$k_val-=$mmaxhp*3;
			$ihit=1;
			$pnum = int($k_val/3);
			$bmess.= "<BR>$k_name를 사용했다.(나머지<font color=red>$pnum</font>)<BR>";
			if($k_val <0){
				$bmess.= "<font color=red>$k_name는 흔적도 없게 무너져 떠났다..</font><BR>";
			}else{
				push(@NEW_C_ITEM,"$k_no<>$k_mark<>$k_name<>$k_val<>$k_dmg<>$k_wei<>$k_ele<>$k_hit<>$k_cl<>$k_sta<>$k_type<>$k_flg<>\n");
			}
		}else{
			push(@NEW_C_ITEM,"$_");
		}
	}
	open(OUT,">./logfile/item/$in{'id'}.cgi");
	print OUT @NEW_C_ITEM;
	close(OUT);
}

1;
