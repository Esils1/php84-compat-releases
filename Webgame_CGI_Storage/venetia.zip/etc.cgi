#!/usr/bin/perl
require './jcode.pl';
require './sub.cgi';
require './conf.cgi';

&decode;
if($ENV{'HTTP_REFERER'} !~ /cgi$/ ){ &error2("주소 바에 값을 입력하지 말아 주세요."); }
if($in{'mode'} eq"move"){require './etc/move.pl';&move;}
elsif($in{'mode'} eq"move2"){require './etc/move2.pl';&move2;}
elsif($in{'mode'} eq"inv"){require './etc/inv.pl';&inv;}
elsif($in{'mode'} eq"inv2"){require './etc/inv2.pl';&inv2;}
elsif($in{'mode'} eq"mode_change"){require './etc/mode_change.pl';&mode_change;}
elsif($in{'mode'} eq"mode_change2"){require './etc/mode_change2.pl';&mode_change2;}
else{&error2("올바르게 선택되고 있지 않습니다.");}
exit;

