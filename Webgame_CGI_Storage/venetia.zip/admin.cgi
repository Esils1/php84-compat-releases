#!/usr/bin/perl

#################################################################
#   【면책 사항】                                                #
#    이 스크립트는 프리 소프트입니다.이 스크립트를 사용했다 #
#    어떠한 손해에 대해서 작자는 일절의 책임을 지지 않습니다.         #
#    또 설치에 관한 질문은 서포트 게시판에 부탁드리겠습니다.   #
#    직접 메일에 의한 질문은 일절 받고있지 않습니다.       #
#################################################################

require './jcode.pl';
require './conf.cgi';
require './sub.cgi';

&decode;
	$adminid = "1064";
	$adminpass = "1064";
	$mode = "$in{'mode'}";

if($mode eq 'MENTE') { &MENTE; }
elsif($mode eq 'DEL') { &DEL; }
elsif($mode eq 'INIT_DATA') { &INIT_DATA; }
elsif($mode eq 'INIT_DATA2') { &INIT_DATA2; }
elsif($mode eq 'WARN') { &WARN; }
elsif($mode eq 'LOGIN') { &LOGIN; }
elsif($mode eq 'MINDEL') { &MINDEL; }
elsif($mode eq 'MINDEL2') { &MINDEL2; }
else{&TOP;}


#_/_/_/_/_/_/_/_/_/#
#_/   MAIN 화면   _/#
#_/_/_/_/_/_/_/_/_/#

sub TOP {

	if($in{'id'} ne "관리자 아이디" || $in{'pass'} ne "관리자 비밀번호"){
		print <<"EOM";
		<form method=post>
			아이디 : <input type=text name=id><br>
			패스 : <input type=password name=pass><br>
			<input type=submit>
		</form>
EOM
	}

	&decode;
	&header;
	print <<"EOM";
<h2>관리툴</h2>
<CENTER>
<table width=80% cellspacing=1 border=0 bgcolor=aa0000><TBODY bgcolor=FFFFF8><TR><Th>
<form method="post" action="adminiii.cgi">
<input type=hidden name=mode value=MENTE>
<input type=hidden name=id value="$in{id}">
<input type=hidden name=pass value="$in{pass}">
<input type=submit value='캐릭터의 삭제'>
<br></form>
</Th><TD>
·등록자의 데이터를 삭제합니다.
</TD></TR>
<TR><Th>
<form method="post" action="adminiii.cgi">
<input type=hidden name=mode value=INIT_DATA>
<input type=hidden name=id value="$in{id}">
<input type=hidden name=pass value="$in{pass}">
<input type=submit value='모두 초기화'>
<br></form>
</Th><TD>
·모든 데이터를 초기화합니다.
</TD></TD></TR>
<TR><Th>
<form method="post" action="adminiii.cgi">
<input type=hidden name=mode value=INIT_DATA2>
<input type=hidden name=id value="$in{id}">
<input type=hidden name=pass value="$in{pass}">
<input type=submit value='캐릭터 데이터 이외의 초기화'>
<br></form>
</Th><TD>
·가·국 관련의 데이터만 초기화합니다.
</TD></TD></TR>

<TR><Th>
<form method="post" action="adminiii.cgi">
<input type=hidden name=mode value=MINDEL>
<input type=hidden name=id value="$in{id}">
<input type=hidden name=pass value="$in{pass}">
<input type=submit value='방치 플레이어 삭제'>
<br></form>
</Th><TD>
·10전 미만으로 1주간 이상 방치해 있는 플레이어를 삭제합니다.
</TD></TD></TR>

<TR><Th>
<form method="post" action="adminiii.cgi">
<input type=hidden name=mode value=WARN>
<input type=hidden name=id value="$in{id}">
<input type=hidden name=pass value="$in{pass}">
<input type=text name=player>
<input type=submit value='에 경고'>
<br></form>
</Th><TD>
·입력한 이름의 플레이어에 경고를 발표합니다.
</TD></TD></TR>


<TR><Th>
<form method="post" action="adminiii.cgi">
<input type=hidden name=mode value=LOGIN>
ID:<input type=text size=15 name=id><BR>
PASS:<input type=password size=15 name=pass><BR>
<input type=hidden name=aid value="$in{id}">
<input type=hidden name=apass value="$in{pass}">
<input type=submit value='뒷문 입학'>
<br></form>
</Th><TD>
·뒷문 입학합니다.
</TD></TD></TR>
</TBODY></TABLE>

<form method="post" action="index.cgi">
</select><input type=submit value='편집을 끝낸다'>
<br></form>

</CENTER>

EOM
	&footer;
	exit;
}

#_/_/_/_/_/_/_/_/_/#
#_/  MENTE 화면   _/#
#_/_/_/_/_/_/_/_/_/#

sub MENTE {

	if($in{'id'} ne "관리자 아이디" || $in{'pass'} ne "관리자 비밀번호"){
	&ERR2("ID, 패스워드 에러 $num ");}

$dir="./logfile/chara";
opendir(dirlist,"$dir");
$i=0;
while($file = readdir(dirlist)){
	if($file =~ /\.cgi/i){
		$datames = "검색：$dir/$file<br>\n";
		if(!open(page,"$dir/$file")){
			$datames .= "$dir/$file가 발견되지 않습니다.<br>\n";
			return 1;
		}
		@page = <page>;
		close(page);
		$list[$i]="$file";
		($eid,$epass,$ename,$eurl,$echara,$esex,$ehp,$emaxhp,$emp,$emaxmp,$eele,$estr,$evit,$eint,$efai,$edex,$eagi,$emax,$ecom,$egold,$ebank,$eex,$etotalex,$ejp,$eabp,$ecex,$eunit,$econ,$earm,$epro,$eacc,$etec,$esta,$epos,$emes,$ehost,$edate,$esyo,$eclass,$etotal,$ekati,$etype,$eoya,$esk,$eflg,$eflg2,$eflg3,$eflg4,$eflg5) = split(/<>/,$page[0]);

		if("$in{'serch'}" ne ""){
			if("$ename" =~ "$in{'serch'}"){
				$human_data[$i]="$ehost<>$ename<>$eid<>";
			}else{
				next;
			}
		}else{
			if($in{'no'} eq "2"){
				$human_data[$i]="$ename<>$ehost<>$eid<>";
			}elsif($in{'no'} eq "3"){
				$human_data[$i]="$eid<>$ehost<>$ename<>";
			}else{
				$human_data[$i]="$ename<>$ehost<>$eid<>";
			}
		}
		push(@newlist,"@page<br>");
		$i++;
	}
}
	closedir(dirlist);

	@human_data = sort @human_data;

$tt = time - (60 * 60 * 24 * 34);
($sec,$min,$hour,$mday,$mon,$year,$wday,$yday) = localtime($tt);
$year += 1900;
$mon++;
$ww = (Sun,Mon,Tue,Wed,Thu,Fri,Sat)[$wday];
$daytime = sprintf("%4d\/%02d\/%02d\/(%s) %02d:%02d:%02d", $year,$mon,$mday,$ww,$hour,$min,$sec);


	&header;
	print <<"EOM";
<h2>캐릭터 관리툴</h2>
<br>
·호스트명은 수시 갱신하고 있습니다.<br>
<form method="post" action="adminiii.cgi">
<input type=hidden name=mode value=DEL>삭제하는 파일：
<select name=fileno>
EOM
$i=0;$w_host="";
foreach(@human_data){
	if($in{'no'} eq "2"){
		($ename,$ehost,$eid) = split(/<>/);
	}elsif($in{'no'} eq "3"){
		($eid,$ehost,$ename) = split(/<>/);
	}else{
		($ename,$ehost,$eid) = split(/<>/);
	}
	print "<option value=$eid\.cgi>$eid $ename $ehost";
	print "★★★" if $ehost eq "124.216.75.5";
	print "\n";
	if($in{'no'} eq "" || $in{'no'} eq "1"){
		if($w_host eq "$ehost"){
			$mess .= "$ename | $w_name<BR>\n";
		}
	}
	$w_host = "$ehost";
	$w_name = "$ename";
	$i++;
}
print <<"EOM";
</select><input type=hidden name=id value="$in{id}">
<input type=hidden name=pass value="$in{pass}">
<input type=submit value='삭제'>
<br></form>

2중등록 의혹자<p>
<font color=red>$mess</font>
<form method="post" action="adminiii.cgi">
<input type=hidden name=id value="$in{id}">
<input type=hidden name=pass value="$in{pass}">
<input type=submit value='TOP'>
<br></form>

EOM

	&footer;
	exit;
}

#_/_/_/_/_/_/_/_/_/#
#_/ 파일 삭제 _/#
#_/_/_/_/_/_/_/_/_/#

sub DEL {

	if($in{'id'} ne "관리자 아이디" || $in{'pass'} ne "관리자 비밀번호"){
		&error("ID, 패스워드 에러 $num ");
	}

	open(IN,"./logfile/chara/$in{'fileno'}") or &error('파일을 삭제할 수 없었습니다.');
	@CN_DATA = <IN>;
	close(IN);
	($kid,$kpass,$kname) = split(/<>/,$CN_DATA[0]);

			$dir2="./logfile/chara";
			unlink("$dir2/$in{'fileno'}");
			$dir2="./logfile/item";
			unlink("$dir2/$in{'fileno'}");
			$dir2="./logfile/job";
			unlink("$dir2/$in{'fileno'}");
			$dir2="./logfile/ability";
			unlink("$dir2/$in{'fileno'}");
			$dir2="./logfile/history";
			unlink("$dir2/$in{'fileno'}");


	open(IN,"./data/maplog.cgi");
	@S_MOVE = <IN>;
	close(IN);
	&time_data;

	unshift(@S_MOVE,"<font color=red><B>\[삭제\]</B></font> $kname는 삭제되었습니다.($mday일$hour시$min분 ) \n");
	splice(@S_MOVE,20);

	open(OUT,">./data/maplog.cgi") or &error2('LOG 새로운 데이터를 쓸 수 없습니다.');
	print OUT @S_MOVE;
	close(OUT);

	&header;
	print <<"EOM";
<center><h2><font color=red>$kname를 삭제했습니다.</font></h2><hr size=0>
<form method="post" action="adminiii.cgi">
<input type=hidden name=id value="$in{id}">
<input type=hidden name=pass value="$in{pass}">
<input type=submit value='돌아온다'>
<br></form>
EOM

	&footer;
	exit;
}

#_/_/_/_/_/_/_/_/_/#
#_/   편집 화면   _/#
#_/_/_/_/_/_/_/_/_/#

sub INIT_DATA {

	if($in{'id'} ne "관리자 비밀번호" || $in{'pass'} ne "관리자 비밀번호"){
		&error2("ID, 패스워드 에러 $num ");
	}
	require "reset.cgi";
	&RESET_MODE;
	
	&header;
	print <<"EOM";
<h2><font color=red>전데이터를 초기화했습니다.</h2></font>
<br>
<br>
<form method="post" action="adminiii.cgi">
<input type=hidden name=id value="$in{id}">
<input type=hidden name=pass value="$in{pass}">
<input type=submit value='돌아온다'>
</form>
<br>
EOM

	&footer;
	exit;
}


#_/_/_/_/_/_/_/_/_/#
#_/   편집 화면   _/#
#_/_/_/_/_/_/_/_/_/#

sub INIT_DATA2 {

	if($in{'id'} ne "관리자 아이디" || $in{'pass'} ne "관리자 비밀번호"){
		&error2("ID, 패스워드 에러 $num ");
	}
	require "reset.cgi";
	&RESET_MODE2;
	
	&header;
	print <<"EOM";
<h2><font color=red>일부 데이터의 초기화를 실시했습니다.</h2></font>
<br>
<br>
<form method="post" action="adminiii.cgi">
<input type=hidden name=id value="$in{id}">
<input type=hidden name=pass value="$in{pass}">
<input type=submit value='돌아온다'>
</form>
<br>
EOM

	&footer;
	exit;
}

#_/_/_/_/_/_/_/_/_/#
#_/   편집 화면   _/#
#_/_/_/_/_/_/_/_/_/#

sub WARN {

	if($in{'id'} ne "관리자 아이디" || $in{'pass'} ne "관리자 비밀번호"){
		&error2("ID, 패스워드 에러 $num ");
	}
	&maplog("<font color=red>[경고]</font>관리인으로부터 $in{'player'}씨에게 경고.");
	&header;
	print <<"EOM";
<h2><font color=red>경고했습니다.</h2></font>
<br>
<br>
<form method="post" action="adminiii.cgi">
<input type=hidden name=id value="$in{id}">
<input type=hidden name=pass value="$in{pass}">
<input type=submit value='돌아온다'>
</form>
<br>
EOM

	&footer;
	exit;
}

#_/_/_/_/_/_/_/_/_/#
#_/   편집 화면   _/#
#_/_/_/_/_/_/_/_/_/#

sub LOGIN {

	if($in{'aid'} ne "관리자 아이디" || $in{'apass'} ne "관리자 비밀번호"){
		&error2("ID, 패스워드 에러 $num ");
	}
	$login=1;
	&chara_open;
	&chara_input;

	&header;
	print <<"EOM";
<h2><font color=red>인증 완료.</h2></font>
<br>
<br>
<form method="post" action="top.cgi">
<input type=hidden name=id value="$in{id}">
<input type=hidden name=pass value="$in{pass}">
<input type=submit value='로그인'>
</form>
<br>
EOM

	&footer;
	exit;
}

#_/_/_/_/_/_/_/_/_/#
#_/ 방치자 일람 _/#
#_/_/_/_/_/_/_/_/_/#

sub MINDEL {

	if($in{'id'} ne "관리자 아이디" || $in{'pass'} ne "관리자 비밀번호"){
		&error("ID, 패스워드 에러 $num ");
	}


	# MAIN DATA
	$dir="./logfile/chara";
	opendir(dirlist,"$dir");

	$date = time();
	while($file = readdir(dirlist)){
		if($file =~ /\.cgi/i){
			$datames = "검색：$dir/$file<br>\n";
			if(!open(page,"$dir/$file")){
				$datames .= "$dir/$file가 발견되지 않습니다.<br>\n";
				return 1;
			}
			@page = <page>;
			close(page);
			$list[$i]="$file";
			($eid,$epass,$ename,$eurl,$echara,$esex,$ehp,$emaxhp,$emp,$emaxmp,$eele,$estr,$evit,$eint,$efai,$edex,$eagi,$emax,$ecom,$egold,$ebank,$eex,$etotalex,$ejp,$eabp,$ecex,$eunit,$econ,$earm,$epro,$eacc,$etec,$esta,$epos,$emes,$ehost,$edate,$esyo,$eclass,$etotal,$ekati,$etype,$eoya,$esk,$eflg,$eflg2,$eflg3,$eflg4,$eflg5) = split(/<>/,$page[0]);
			if($etotal<10 && $date>$edate+604800){
				$mess.="$ename<BR>";
			}
		}
	}
	closedir(dirlist);

	&header;
	print <<"EOM";
<center><h2><font color=red>이하의 플레이어를 삭제합니다.<BR></font></h2><hr size=0>
$mess
<form method="post" action="adminiii.cgi">
<input type=hidden name=mode value=MINDEL2>
<input type=hidden name=id value="$in{id}">
<input type=hidden name=pass value="$in{pass}">
<input type=submit value='삭제'>
<br></form>

<form method="post" action="adminiii.cgi">
<input type=hidden name=id value="$in{id}">
<input type=hidden name=pass value="$in{pass}">
<input type=submit value='돌아온다'>
<br></form>
EOM

	&footer;
	exit;
}


#_/_/_/_/_/_/_/_/_/#
#_/ 방치자 삭제 _/#
#_/_/_/_/_/_/_/_/_/#

sub MINDEL2 {

	if($in{'id'} ne "관리자 아이디" || $in{'pass'} ne "관리자 비밀번호"){
		&error("ID, 패스워드 에러 $num ");
	}

	$date = time();

	# MAIN DATA
	$dir="./logfile/chara";
	opendir(dirlist,"$dir");
	while($file = readdir(dirlist)){
		if($file =~ /\.cgi/i){
			$datames = "검색：$dir/$file<br>\n";
			if(!open(page,"$dir/$file")){
				$datames .= "$dir/$file가 발견되지 않습니다.<br>\n";
				return 1;
			}
			@page = <page>;
			close(page);
			$list[$i]="$file";
			($eid,$epass,$ename,$eurl,$echara,$esex,$ehp,$emaxhp,$emp,$emaxmp,$eele,$estr,$evit,$eint,$efai,$edex,$eagi,$emax,$ecom,$egold,$ebank,$eex,$etotalex,$ejp,$eabp,$ecex,$eunit,$econ,$earm,$epro,$eacc,$etec,$esta,$epos,$emes,$ehost,$edate,$esyo,$eclass,$etotal,$ekati,$etype,$eoya,$esk,$eflg,$eflg2,$eflg3,$eflg4,$eflg5) = split(/<>/,$page[0]);

			if($etotal<10 && $date>$edate+604800){
				$dir2="./logfile/chara";
				unlink("$dir2/$eid.cgi");
				$dir2="./logfile/item";
				unlink("$dir2/$eid.cgi");
				$dir2="./logfile/job";
				unlink("$dir2/$eid.cgi");
				$dir2="./logfile/ability";
				unlink("$dir2/$eid.cgi");
				$dir2="./logfile/history";
				unlink("$dir2/$eid.cgi");
				$dir2="./logfile/out";
				unlink("$dir2/$eid.cgi");
				$dir2="./logfile/mes";
				unlink("$dir2/$eid.cgi");
				$dir2="./logfile/prof";
				unlink("$dir2/$eid.cgi");
				$mess.="$ename<BR>";
				$count++;
			}
		}
	}
	closedir(dirlist);
	
	open(IN,"./data/maplog.cgi");
	@S_MOVE = <IN>;
	close(IN);
	&time_data;

	unshift(@S_MOVE,"<font color=red><B>\[삭제\]</B></font> 1주간 로그인하지 않았던 10전 미만의 플레이어($count명)는 삭제되었습니다.($mday일$hour시$min분 ) \n");
	splice(@S_MOVE,20);

	open(OUT,">./data/maplog.cgi") or &error2('LOG 새로운 데이터를 쓸 수 없습니다.');
	print OUT @S_MOVE;
	close(OUT);

	&header;
	print <<"EOM";
<center><h2><font color=red>이하의 플레이어를 삭제했습니다.<BR>$mess</font></h2><hr size=0>
<form method="post" action="adminiii.cgi">
<input type=hidden name=id value="$in{id}">
<input type=hidden name=pass value="$in{pass}">
<input type=submit value='돌아온다'>
<br></form>
EOM

	&footer;
	exit;
}
