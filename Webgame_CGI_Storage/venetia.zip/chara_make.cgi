#!/usr/bin/perl
require './jcode.pl';
require './sub.cgi';
require './conf.cgi';
require './attestation.cgi';

&decode;
&host_name;

if($CHARA_ENT){&error2("현재 신규 등록할 수 없습니다.");}
if($ENV{'HTTP_REFERER'} !~ /cgi$/ ){ &error2("주소 바에 값을 입력하지 말아 주세요."); }

if($in{'id'} eq ""){&error2("ID를 입력해 주세요.");}
if($in{'pass'} eq $in{'id'}){&error2("ID와 패스워드는 다른 것을 사용해 주세요.");}
if($in{'pass'} eq ""){&error2("패스워드를 입력해 주세요.");}
if(length($in{'id'}) < 4||length($in{'id'}) > 8){&error2("ID는 4 문자 이상 8 문자 이내에서 입력해 주세요.");}
if(length($in{'pass'}) < 4||length($in{'pass'}) > 8){&error2("패스워드는 4 문자 이상 8 문자 이내에서 입력해 주세요.");}
if($in{'id'} eq $in{'pass'}){&error2("ID와 패스워드는 다른 것을 이용해 주세요."); }	
if ($in{'id'} =~ m/[^0-9a-zA-Z]/) {&error2("ID는 반각으로 입력해 주세요."); }
if ($in{'pass'} =~ m/[^0-9a-zA-Z]/) {&error2("패스워드는 반각으로 입력해 주세요."); }
if($in{'name'} eq ""){&error2("이름을 입력해 주세요.");}
if(length($in{'name'}) < 4||length($in{'name'}) > 16){&error2("이름은 2 문자 이상 8 문자 이내에서 입력해 주세요.");}
if($in{'sex'} eq ""){&error2("성별을 선택해 주세요.");}
if($in{'img'} eq ""){&error2("캐릭터 화상을 선택해 주세요.");}
if($in{'ele'} eq ""){&error2("속성을 선택해 주세요.");}
if($in{'con_id'} eq ""){&error2("소속국을 선택해 주세요.");}
if ($in{'mail'} =~ /yahoo/ || $in{'mail'} =~ /hotmail/ || $in{'mail'} =~ /excite/ || $in{'mail'} =~ /infoseek/  || $in{'mail'} =~ /goo/) {&error2("그 메일 주소는 사용할 수 없습니다."); }
if ($in{'mail'} eq "" || $in{'mail'} !~ /(.*)\@(.*)\.(.*)/){&error2("메일의 입력이 부정합니다.");}
if ($in{'mail'} ne $in{'mailconfirm'}){&error2("메일이 올바르게 입력되고 있지 않습니다.");}

if($ATTESTATION){
	$os = 1;
}else{
	$os = "";
}
	
$id=$in{'id'};
$pass=$in{'pass'};
$hp=50;$mp=10;$str=20;$vit=20;$int=20;
$dex=20;$agi=20;$fai=20;
$gold=50;$ex=0;$cex=0;$bank=0;
$arm="0,녹이 쓴 창,0,0,0,0,80,10,0,0,0";
$pro="0,녹이 쓴 장갑옷,0,0,0,0,80,10,0,0,0";
$acc="0,무색의 밴드,0,0,0,0,80,10,0,0,0";
$tac="0,0,0,50,50";
$max="200,200,200,200,200,200";
$class=0;$kati=0;$total=0;$pos=0;
$date = time();
if($ATTESTATION){$mailcom="<BR><font color=red>※입력한 주소에 인증 ID와 패스워드를 메일로 보낸 내용에 따라, 인증을 실시해 주세요.</font>";}

open(IN,"./data/country.cgi") or &error2("타운 데이터 파일이 열리지 않습니다.");
@CON_DATA = <IN>;
close(IN);

foreach(@CON_DATA){
	($con_id,$con_name,$con_ele) =split(/<>/);
	if("$con_id" eq "$in{'con_id'}"){$hit=1;last;}
}
if($in{'con_id'} ne 0 && !$hit){&error2("소속하는 나라가 올바르게 선택되지 않았습니다.");}
if($in{'con_id'} eq 0){$con_name="무소속";}

$dir="./logfile/chara";
opendir(dirlist,"$dir");
while($file = readdir(dirlist)){
	if($file =~ /\.cgi/i){
		$datames = "검색：$dir/$file<br>\n";
		if(!open(chara,"$dir/$file")){
			&error("$dir/$file가 발견되지 않습니다.<br>\n");
		}
		@chara = <chara>;
		close(chara);
		$list[$i]="$file";
		($eid,$epass,$ename,$eurl,$echara,$esex,$ehp,$emaxhp,$emp,$emaxmp,$eele,$estr,$evit,$eint,$efai,$edex,$eagi,$emax,$ecom,$egold,$ebank,$eex,$etotalex,$ejp,$eabp,$ecex,$eunit,$econ,$earm,$epro,$eacc,$etec,$esta,$epos,$emes,$ehost,$edate,$esyo,$eclass,$etotal,$ekati,$etype,$eoya,$eaup,$eflg,$eflg2,$eflg3,$eflg4,$eflg5) = split(/<>/,$chara[0]);
	
		if($DOUBLE eq "1" && $ehost eq"$host"){
			&maplog3("<font color=red>[중복]</font>$in{'name'}는$ename와 호스트명이 동일한 때문, 신규 등록할 수 없었습니다.");
			&error2("2중등록은 금지되고 있습니다.");
		}
		if($eflg4 eq"$in{'mail'}"){&error2("이미 같은 메일 주소가 사용되고 있습니다.");}
		if($ename eq"$in{'name'}"){&error2("이미 같은 이름이 사용되고 있습니다.");}
		if($eid eq"$in{'id'}"){&error2("이미 같은 ID가 사용되고 있습니다.");}
		
	}
	if($cn>10000){&error("루프");}
	$cn++;
}
closedir(dirlist);

if($ATTESTATION){
	&mail_to;
}
	
unshift(@CHARA_DATA,"$id<>$pass<>$in{'name'}<>$os<>$in{'img'}<>$in{'sex'}<>$hp<>$hp<>$mp<>$mp<>$in{'ele'}<>$str<>$vit<>$int<>$fai<>$dex<>$agi<>$max<><>$gold<>$bank<>0<>0<>0<>0<>$cex<><>$in{'con_id'}<>$arm<>$pro<>$acc<>$tac<>$sta<>$pos<>$mes<>$host<>$date<>$date<>$class<>$total<>$kati<>0<><><>1<><><>$in{'mail'}<><>\n");

open(OUT,">./logfile/chara/$in{'id'}.cgi") or &error2('데이터를 쓸 수 없습니다.');
print OUT @CHARA_DATA;
close(OUT);
$mid="$id";
&kh_log("$con_name국의 국민이 된다.",$con_name);
&maplog("<font color=999933>[등록]</font>$in{'name'}가$con_name국에 입국했습니다.");

&header;

print <<"EOF";
<P align="center"><BR>
등록 완료</P>
<CENTER>
<TABLE border="0" width="415" height="67" bgcolor="#990099">
  <TBODY>
    <TR>
      <TD bgcolor="#660066" colspan="3" align="center"><FONT color="#ffffcc">등록 정보</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc">이름</TD>
      <TD bgcolor="#ffffcc">$in{'name'}</TD>
    </TR><TR>
      <TD bgcolor="#ffffcc">ID</TD>
      <TD bgcolor="#ffffcc">$id</TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc">패스워드</TD>
      <TD bgcolor="#ffffcc">$pass</TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc">소속국</TD>
      <TD bgcolor="#ffffcc">$con_name</TD>
    </TR>
    <TR>
      <TD colspan="3" bgcolor="#ffcc99"><FONT color="#993399">캐릭터의 등록이 완료했습니다.<BR>
      「계속으로부터」 보다, 상기의 ID와 패스워드에 의해 로그인할 수 있습니다.<BR>
      ID와 패스워드는 잊지 않게 메모를 해 두어 주세요.</FONT>	$mailcom<BR>
      </TD>
    </TR>
    <TR>
      <TD colspan="3" align=center bgcolor="#ffcc99">
      	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$in{'id'}>
	<INPUT type=hidden name=pass value=$in{'pass'}>
	<INPUT type=submit CLASS=FC value=PLAY></form>
      </TD>
    </TR>
  </TBODY>
</TABLE>
</CENTER>

EOF

&footer;
exit;

