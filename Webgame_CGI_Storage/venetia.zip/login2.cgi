#!/usr/bin/perl
require './jcode.pl';
require './sub.cgi';
require './conf.cgi';
&decode;

#중복 체크

open(IN,"./data/guest_list.cgi");
@gue = <IN>;
close(IN);
$guest=@gue;
if($guest>$LMAX){&error2("참가자 다수 때문에, 로그인할 수 없습니다.");}
$login=1;

&chara_open;

#중복 체크
foreach(@gue) {
		($gname,$gtime,$gcon,$ghost) =split(/<>/);
		if($gname ne $mname && $ghost eq $mhost){
			&maplog3("[중복]$mname는$gname와 호스트명이 동일합니다.");
			$com="<BR><font color=red>경고：$gname와 호스트명이 동일합니다.</font>";
		}
	}
&chara_input;

&header;

print <<"EOF";
<BR>
<BR>
<CENTER>
<form action="top.cgi" method="POST">
<TABLE border="0" width="200" CLASS=FC>
  <TBODY>
    <TR>
      <TD bgcolor=$FCOLOR colspan=2 align=center><font size=3 color=$FCOLOR2>인증 완료 $com</font></TD>
    </TR>
    <TR>
      <TD colspan="2" align=center>
	<input type=hidden name=id value=$mid>
    	<input type=hidden name=pass value=$mpass>
	<input type=submit CLASS=FC value=로그인></TD>
    </TR>
  </TBODY>
</TABLE>
</CENTER>
</form>
EOF
&footer;
exit;

