#파라미터등 취득
sub PARA{
	#어빌리티 정보
	($msk[0],$msk[1]) = split(/,/,$msk);
	($esk[0],$esk[1]) = split(/,/,$esk);
	open(IN,"./data/ability.cgi");
	@ABILITY = <IN>;
	close(IN);

	foreach(@ABILITY){
		($abno,$abname,$abcom,$abdmg,$abrate,$abpoint,$abclass,$abtype) =split(/<>/);
		if($msk[0] eq $abno || $msk[1] eq $abno || $marmsta eq $abno || $mprosta eq $abno || $maccsta eq $abno){
			$mab[$abtype]=1;
			$mabdmg[$abtype]=$abdmg;
			$mabname[$abno]=$abname;
			$mabtype[$abno]=$abtype;
		}
		if($esk[0] eq $abno || $esk[1] eq $abno || $earmsta eq $abno || $eprosta eq $abno || $eaccsta eq $abno){
			$eab[$abtype]=1;
			$eabdmg[$abtype]=$abdmg;
			$eabname[$abno]=$abname;
			$eabtype[$abno]=$abtype;
		}
	}
	#지형 효과
	if($mab[19]){$tup=$mabdmg[19]/100;}
	if($eab[19]){$etup=$eabdmg[19]/100;}

	if($iflg){$tt_ele=$town2_ele;}
	else{$tt_ele=$town_ele;}

	if($tt_ele eq $mele){$maddstr=int($mstr*(0.1 + $tup)) ;$madddef=int($mvit*(0.1 + $tup)) ;$chi1="<font color=red>↑</font>";}
	elsif($tt_ele eq $ANELE[$mele]){$maddstr=-int($mstr*(0.1)) ;$madddef=-int($mvit*0.1) ;$chi1="<font color=blue>↓</font>";}
	if($tt_ele eq $eele){$eaddstr=int($estr*(0.1 + $etup)) ;$eadddef=int($evit*(0.1 + $etup)) ;$chi2="<font color=red>↑</font>";}
	elsif($tt_ele eq $ANELE[$eele]){$eaddstr=-int($estr*(0.1)) ;$eadddef=-int($evit*0.1) ;$chi2="<font color=blue>↓</font>";}
	
	#마법검
	if($mab[18]){$marmdmg+=int($mint*$mabdmg[18]/100);}
	if($eab[18]){$earmdmg+=int($eint*$eabdmg[18]/100);}

	#물리 공격 계산
	$mat=$mstr + $marmdmg + int($marmwei/5) + $maddstr;
	if($mab[2]){$mat+=int($mabdmg[2]/100*$mat);}#력 업
	$eat=$estr + $earmdmg + int($earmwei/5) + $eaddstr;
	if($eab[2]){$eat+=int($eabdmg[2]/100*$eat);}#력 업
	
	if($mab[3]){$eat-=int($mabdmg[2]/100*$eat);}#데미지 경감
	if($eab[3]){$mat-=int($eabdmg[2]/100*$mat);}#데미지 경감
	
	#물리 방어 계산
	$mdef=$mvit + $mprodmg + $maccdmg + $madddef;
	$edef=$evit + $eprodmg + $eaccdmg + $eadddef;

	#마법 방어 계산
	$mmdef=int($mfai/2);
	if(int($msk/10) eq 4){$mmdef+=int($msklv) /10*$mmdef;}
	
	$emdef=int($efai/2);

	#위기 계산
	#$mcl=$marmcl;
	$mcl=20;
	$mcl+=int($mdex/3);
	$ecl=20;
	$ecl+=int($edex/3);
	if($mab[10]){$mcl+=$mabdmg[10]*10;}
	if($eab[10]){$ecl+=$eabdmg[10]*10;}
	if($mcl>250){$mcl=250;}
	if($ecl>250){$ecl=250;}

	#회피율 계산
	$msh=int($mdex/3);
	$esh=int($edex/3);
	if($mab[8]){$msh2=$mabdmg[8]*10;}
	if($eab[8]){$esh2=$eabdmg[8]*10;}

	#공격 회수
	$madagi=0;
	$eadagi=0;

	if($mab[4]){$madkai=$mabdmg[4];}#헤이 파업
	if($eab[4]){$eadkai=$eabdmg[4];}#헤이 파업
		
	$mspeed=$magi-$marmwei-$mprowei-$maccwei+$madagi + $madkai * 50;
	$espeed=$eagi-$earmwei-$eprowei-$eaccwei+$eadagi + $eadkai * 50;
	
	#적HP계산
	$ehp=$emaxhp;
	$emp=$emaxmp;
}

#기술 데이터 취득
sub TEC_OPEN {

	open(IN,"./data/tec.cgi") or &error('파일을 열지 않았습니다.');
	@TEC = <IN>;
	close(IN);
	($mtec1,$mtec2,$mtec3,$mmprate,$mhprate) =split(/,/,$mtec);
	
	if($mtec1 eq ""){$mtec1=0;}
	if($mtec2 eq ""){$mtec2=0;}
	if($mtec3 eq ""){$mtec3=0;}

	($mtec_name[0],$mtec_str[0],$mtec_hit[0],$mtec_mp[0],$mtec_ab[0],$mtec_sta[0],$mtec_class[0]) = split(/<>/,$TEC[$mtec1]);
	($mtec_name[1],$mtec_str[1],$mtec_hit[1],$mtec_mp[1],$mtec_ab[1],$mtec_sta[1],$mtec_class[1]) = split(/<>/,$TEC[$mtec2]);
	($mtec_name[2],$mtec_str[2],$mtec_hit[2],$mtec_mp[2],$mtec_ab[2],$mtec_sta[2],$mtec_class[2]) = split(/<>/,$TEC[$mtec3]);
	
	if($estr){
		($etec1,$etec2,$etec3,$emprate,$ehprate) =split(/,/,$etec);
		if($etec1 eq ""){$etec1=0;}
		if($etec2 eq ""){$etec2=0;}
		if($etec3 eq ""){$etec3=0;}

		($etec_name[0],$etec_str[0],$etec_hit[0],$etec_mp[0],$etec_ab[0],$etec_sta[0],$etec_class[0]) = split(/<>/,$TEC[$etec1]);
		($etec_name[1],$etec_str[1],$etec_hit[1],$etec_mp[1],$etec_ab[1],$etec_sta[1],$etec_class[1]) = split(/<>/,$TEC[$etec2]);
		($etec_name[2],$etec_str[2],$etec_hit[2],$etec_mp[2],$etec_ab[2],$etec_sta[2],$etec_class[2]) = split(/<>/,$TEC[$etec3]);
	}

}

#자신의 공격 처리
sub MATT{
	if(!$mpara2){
		if($mab[1]){
			$hpsai=int($mabdmg[1]/100*$mmaxhp);
			$mhp+=$hpsai;
			if($mhp>$mmaxhp){$mhp=$mmaxhp;}
			$bmess.="[재생]$mname는 HP가<font color=blue><b>$hpsai</b></font>회복했다.<BR>";
		}

		$mkai = int($mspeed/100 + rand($mspeed/100)) + 1;
		if($mkai<1){$mkai=1;}
		if($mkai>=8){$mkai=8;}

		$bmess.="<font color=blue size=4><b>$mname</b></font>의<font color=blue size=4><b>$mkai</b></font>회공격!<BR>";
		if($mpara){
			$mhpd=int(rand($mmaxhp*$mpara/10));
			$mhp-=$mhpd;
			if($mhp<=1){$mhp=1;}
			$bmess.="<font color=red>독에 의해$mhpd의 데미지를 받았다.</font><BR>";
		}

		for($kou=0;$kou<$mkai;$kou++){
			$rand=int(rand(100)) ;$at=0;$msv=0;
			if($mhp/($mmaxhp+1)*100<=$mhprate){$magic=2;}
			elsif($mmp/($mmaxmp+1)*100<=$mmprate){$magic=1;}
			else{$magic=0;}

			##기술 발동
			$mpdown=$mtec_mp[$magic];
			if($mab[6]){$mpdown-=int($mtec_mp[$magic]*$mabdmg[6]/100);}

			if($mab[25]){
				$mhitup=1.5;
			}else{
				$mhitup=1;
			}
			if($mtec_hit[$magic]*$mhitup>$rand && $mpdown<=$mmp){
				$bmess.="<font color=red size=4><b>$mtec_name[$magic] </b></font>";
				if($mab[6]){$bmess.="<font color=blue><b>(소비 $mabdmg[6]%경감)</b></font>";}
				$mmp-=$mpdown;
				if($mtec_sta[$magic] eq 1){
					$mhpup=$mtec_str[$magic] + int(rand($mfai/2));
					$mhp+=$mhpup;
					if($mhp>$mmaxhp){$mhp=$mmaxhp;}
					$bmess.="HP가<font color=blue><b>$mhpup</b></font>회복했다.<BR>";
				}elsif($mtec_sta[$magic] eq 2){
					$mhp+=int($mmaxhp/10);
					$mmp+=int($mmaxmp/10);
					if($mhp>$mmaxhp){$mhp=$mmaxhp;}
					if($mmp>$mmaxmp){$mmp=$mmaxmp;}
					$bmess.="<font color=blue>HP와 MP가 회복했다.</font><BR>";
				}elsif($mtec_sta[$magic] eq 3){
					$mat+=int($mfai*($mtec_str[$magic]/100));
					$bmess.="<font color=blue>공격력이 상승했다.</font><BR>";
				}elsif($mtec_sta[$magic] eq 4){
					$mdef+=int($mfai*($mtec_str[$magic]/100));
					$bmess.="<font color=blue>내구력이 상승했다.</font><BR>";
				}elsif($mtec_sta[$magic] eq 5){
					$mmdef+=int($mfai*($mtec_str[$magic]/100));
					$bmess.="<font color=blue>마법 내구력이 상승했다.</font><BR>";
				}elsif($mtec_sta[$magic] eq 6){
					$mdmg=$mtec_str[$magic] + int(rand($mint)) -int($emdef);
					$msv=6;
					$at=1;
				}elsif($mtec_sta[$magic] eq 7){
					$msmp=int(rand($emaxmp)/5);
					$emp-=$msmp;
					if($emp<0){$emp=0;}
					$mmp+=$msmp;
					if($mmp>$mmaxmp){$mmp=$mmaxmp;}
					$bmess.="$ename의 MP를<font color=red>$msmp</font>빼앗았다.<BR>";
				}elsif($mtec_sta[$magic] eq 8){
					$ehp=int($ehp-$ehp/$mtec_str[$magic]);
					$bmess.="$ename의 체력이 $mtec_str[$magic]분의 1 감소했다.<BR>";
				}else{
					$mdmg=$mtec_str[$magic] + int(rand($mint)) -int($emdef);
					if($mab[5]){
						$mdmg+=int($mdmg*$mabdmg[5]/100);
						$bmess.="<font color=blue><b>(데미지 +$mabdmg[5]%) </b></font>";
					}
					if($eab[7]){
						$mdmg-=int($mdmg*$eabdmg[7]/100);
						$bmess.="<font color=blue><b>(데미지-$eabdmg[7]%) </b></font>";
					}
				
					$at=1;
					if($mtec_sta[$magic] eq 9){$msv=1;$at=1;}#즉사
					if($mtec_sta[$magic] eq 10){$msv=2;$at=1;}#방어 다운
					if($mtec_sta[$magic] eq 11){$msv=3;$at=1;}#독
					if($mtec_sta[$magic] eq 12){$msv=4;$at=1;}#명중 다운
					if($mtec_sta[$magic] eq 13){$msv=5;$at=1;}#마비
					if($mtec_sta[$magic] eq 14){$msv=7;$at=1;}#둔화
					
				}
				$bmess.="<br>";
			}else{##통상 공격
				$mdmg=int(rand($mat-$edef/2));
				$at=1;
			}
			if($at){
				##회피·위기
				$hitrand=int(rand(2));
				if($eab[12] && 100>int(rand(1200-$efai))){
					$edmg=int(($mdmg+int(rand($estr))) /2*$eabdmg[12]);
					if($edmg<1){$edmg=1;}
					$mhp-=$edmg;
					if($mhp<1){$mhp=1;}
					$mdmg=0;
					$hitrand=0;
					$bmess.="<font color=blue size=3>$ename의 카운터!</font><BR>$mname에<font color=red size=4><b>$edmg</b></font>의 데미지를 주었다.";
				}elsif($esh>int(rand(1000))){
					$bmess.="<font color=blue size=3>$ename는 재빠르게 몸을 주고 받았다.<BR></font>";
					$mdmg=0;
					$hitrand=0;
				}elsif($esh2>int(rand(1000))){
					$bmess.="<font color=blue size=3>$ename는 가드 밑.<BR></font>";
					$mdmg=0;
					$hitrand=0;
				}elsif($mcl>int(rand(1000))){
					$bmess.="<font color=blue size=4>위기!</font>";
					$mdmg=int($mdmg*1.5);
					if($mab[23]){
						$mdmg=int($mdmg*$mabdmg[23]);
					}
				}
				##데미지
				if($mdmg<=0 && $hitrand eq 0){
					$mdmg=0;
					$bmess.="<font color=red>$ename</font>에 데미지가 주어지지 않았다.<BR>";
				}elsif($mdmg<=0){
					$mdmg=1;
				}
				if($mdmg){
					$bmess.="<font color=red>$ename</font>에<font color=red size=4><b>$mdmg</b></font>의 데미지를 주었다.<BR>";
					if($msv eq 2){
						$edef-=int($edef/10);
						if($edef < 0){$edef=0;}
						$bmess.="$ename의 방어력이 내렸다.<BR>";
					}
					elsif(int(rand(4)) eq 2 && $msv eq 3 || $mab[14] && int(rand(6)) < 1){
						$epara=$mabdmg[14];
						if(!$epara){$epara=1;}
						$bmess.="<font color=red>$ename는 독에 범해졌다.</font><BR>";
					}
					elsif($msv eq 4 && $msh<1000){
						$msh+=40;
						$bmess.="<font color=red>$ename의 명중율이 내렸다.</font><BR>";
					}
					elsif(int(rand(8)) eq 2 && $msv eq 5 || $mab[24] && int(rand(15)) eq 1){
						$epara2=1;
						$bmess.="<font color=red>$ename는 마비되었다.</font><BR>";
					}
					elsif($msv eq 6 || $mab[28] && int(rand(4)) eq 1){
						$mhpup=int($mdmg/2);
						$mhp+=$mhpup;
						if($mhp>$mmaxhp){$mhp=$mmaxhp;}
						$bmess.="$mname는 HP를<font color=blue>$mhpup</font>흡수했다.<BR>";
					}
					elsif(int(rand(8)) eq 2 && $msv eq 7 || $mab[16] && int(rand(100)) < $mabdmg[16]){
						$espeed-=50;
						if($espeed<0){$espeed=0;}
						$bmess.="<font color=red>$ename는 움직임이 늦어졌다.</font><BR>";
					}
					elsif($mab[26] && int(rand(3)) eq 1){
						$addmg = int(rand(200));
						$bmess.="<font color=red size=2>한층 더<b>$addmg</b>의 추가 데미지를 주었다.</font><BR>";
						$mdmg += $addmg;
					}
					elsif($mab[27] && int(rand(3)) eq 1){
						$msmp=int(rand(150));
						$emp-=$msmp;
						if($emp<0){$emp=0;}
						$mmp+=$msmp;
						if($mmp>$mmaxmp){$mmp=$mmaxmp;}
						$bmess.="$ename의 MP를<font color=red>$msmp</font>빼앗았다.<BR>";
					}
					elsif($mab[31] && int(rand(2)) eq 1){
						$abrand = int(rand(2));
						$iab = $esk[$abrand];
						$atype = $eabtype[$iab];
						if($eab[$atype]){
							$eab[$atype] = 0;
							$bmess.="<font color=red>$ename의 어빌리티 :$eabname[$iab]를 봉했다!</font><BR>";
						}
					}

					if($ename ne "요새" && int(rand(30)) eq 7 && $msv eq 1 || $ename ne "요새" && $mab[9] && int(rand(1000)) < $mabdmg[9]){
						$ehp=0;
						$bmess.="<font color=red>$ename는 즉사했다.</font><BR>";
					}
				}
				$ehp-=$mdmg;
				if($maxdmg < $mdmg){$maxdmg = $mdmg;}
			}
			if($ehp<=0){
				$bmess.="<font color=red>$ename를 넘어뜨렸다!</font><BR>";
			}
			if($ehp<=0 && $eab[11]  && int(rand(100)) < $eabdmg[11] && !$mhflg){
				$ehp=int($emaxhp/2);
				$mhflg=1;
				$bmess.="<font color=red>$ename는 부활했다!</font><BR>";
			}elsif($ehp<=0){
				$ehp=0;
				$win=1;
			}
		
			if($kou>10){&error;}
			if($win){last;}
		}
		$bmess.="<BR>";
	}else{$bmess.="<font color=red>$mname는 움직일 수 없다.</font><BR>";}
	$mpara2=0;
}

#적의 공격 처리
sub EATT{
	if(!$epara2){
		if($eab[1]){
			$hpsai=int($eabdmg[1]/100*$emaxhp);
			$ehp+=$hpsai;
			if($ehp>$emaxhp){$ehp=$emaxhp;}
			$bmess.="[재생]$ename는 HP가<font color=blue><b>$hpsai</b></font>회복했다.<BR>";
		}
		$ekai = int($espeed/100 + rand($espeed/100)) + 1;
		if($ekai<1){$ekai=1;}
		if($ekai>=8){$ekai=8;}

		$bmess.="<font color=red size=4><b>$ename</b></font>의<font color=blue size=4><b>$ekai</b></font>회공격!<BR>";
		if($epara){
			$ehpd=int(rand($emaxhp*$epara/10));
			$ehp-=$ehpd;
			if($ehp<=1){$ehp=1;}
			$bmess.="<font color=red>독에 의해$ehpd의 데미지를 받았다.</font><BR>";
		}
		
		for($kou=0;$kou<$ekai;$kou++){
			$rand=int(rand(100)) ;$at=0;$esv=0;
			if($ehp/($emaxhp+1)*100<=$ehprate){$magic=2;}
			elsif($emp/($emaxmp+1)*100<=$emprate){$magic=1;}
			else{$magic=0;}

			##기술 발동
			$mpdown=$etec_mp[$magic];
			if($eab[6]){$mpdown-=int($etec_mp[$magic]*$eabdmg[6]/100);}

			if($eab[25]){
				$ehitup=1.5;
			}else{
				$ehitup=1;
			}
			if($etec_hit[$magic]*$ehitup>$rand && $mpdown<=$emp){
				$bmess.="<font color=red size=4><b>$etec_name[$magic] </b></font>";
				if($eab[6]){$bmess.="<font color=blue><b>(소비 $eabdmg[6]%경감)</b></font>";}
				$emp-=$mpdown;
				if($etec_sta[$magic] eq 1){
					$ehpup=$etec_str[$magic] + int(rand($efai/2));
					$ehp+=$ehpup;
					if($ehp>$emaxhp){$ehp=$emaxhp;}
					$bmess.="HP가<font color=blue><b>$ehpup</b></font>회복했다.<BR>";
				}elsif($etec_sta[$magic] eq 2){
					$ehp+=int($emaxhp/10);
					$emp+=int($emaxmp/10);
					if($ehp>$emaxhp){$ehp=$emaxhp;}
					if($emp>$emaxmp){$emp=$emaxmp;}
					$bmess.="<font color=blue>HP와 MP가 회복했다.</font><BR>";
				}elsif($etec_sta[$magic] eq 3){
					$eat+=int($efai*($etec_str[$magic]/100));
					$bmess.="<font color=blue>공격력이 상승했다.</font><BR>";
				}elsif($etec_sta[$magic] eq 4){
					$edef+=int($efai*($etec_str[$magic]/100));
					$bmess.="<font color=blue>내구력이 상승했다.</font><BR>";
				}elsif($etec_sta[$magic] eq 5){
					$emdef+=int($efai*($etec_str[$magic]/100));
					$bmess.="<font color=blue>마법 내구력이 상승했다.</font><BR>";
				}elsif($etec_sta[$magic] eq 6){
					$edmg=$etec_str[$magic] + int(rand($eint)) -int($mmdef);
					$esv=6;
					$at=1;
				}elsif($etec_sta[$magic] eq 7){
					$esmp=int(rand($mmaxmp)/5);
					$mmp-=$esmp;
					if($mmp<0){$mmp=0;}
					$emp+=$esmp;
					if($emp>$emaxmp){$emp=$emaxmp;}
					$bmess.="$mname의 MP를<font color=red><b>$esmp</b></font>빼앗았다.<BR>";
				}elsif($etec_sta[$magic] eq 8){
					$mhp=int($mhp-$mhp/$etec_str[$magic]);
					$bmess.="$mname의 체력이 $etec_str[$magic]분의 1 감소했다.<BR>";
				}else{
					$edmg=$etec_str[$magic] + int(rand($eint)) -int($mmdef);
					if($eab[5]){
						$edmg+=int($edmg*$eabdmg[5]/100);
						$bmess.="<font color=blue><b>(데미지 +$eabdmg[5]%) </b></font>";
					}
					if($mab[7]){
						$edmg-=int($edmg*$mabdmg[7]/100);
						$bmess.="<font color=blue><b>(데미지-$mabdmg[7]%) </b></font>";
					}
					$at=1;
					if($etec_sta[$magic] eq 9){$esv=1;}#즉사
					if($etec_sta[$magic] eq 10){$esv=2;}#방어 다운
					if($etec_sta[$magic] eq 11){$esv=3;}#독
					if($etec_sta[$magic] eq 12){$esv=4;}#명중 다운
					if($etec_sta[$magic] eq 13){$esv=5;}#마비
					if($etec_sta[$magic] eq 14){$esv=7;}#둔화
				}
				
				$bmess.="<br>";
			}else{##통상 공격
				$edmg=int(rand($eat-$mdef/2));
				$at=1;
			}
			if($at){
				##회피, 위기
				$hitrand=int(rand(2));
				if($mab[12] && 100>int(rand(1200-$mfai))){
					$mdmg=int(($edmg+int(rand($mstr))) /2*$mabdmg[12]);
					if($mdmg<1){$mdmg=1;}
					$ehp-=$mdmg;
					if($ehp<1){$ehp=1;}
					$edmg=0;
					$hitrand=0;
					$bmess.="<font color=blue size=3>$mname의 카운터!</font><BR>$ename에<font color=red size=4><b>$mdmg</b></font>의 데미지를 주었다.";
				}elsif($msh>int(rand(1000))){
					$bmess.="<font color=blue size=3>$mname는 재빠르게 몸을 주고 받았다.<BR></font>";
					$edmg=0;
					$hitrand=0;
				}elsif($msh2>int(rand(1000))){
					$bmess.="<font color=blue size=3>$mname는 가드 밑.<BR></font>";
					$edmg=0;
					$hitrand=0;
				}elsif($ecl>int(rand(1000))){
					$bmess.="<font color=blue size=4>위기!</font>";
					$edmg=int($edmg*1.5);
					if($eab[23]){
						$edmg=int($edmg*$eabdmg[23]);
					}
				}
				##데미지
				if($edmg<=0 && $hitrand eq 0){
					$edmg=0;
					$bmess.="<font color=blue>$mname</font>에 데미지가 주어지지 않았다.<BR>";
				}elsif($edmg<=0){
					$edmg=1;
				}
				if($edmg){
					$bmess.="<font color=blue>$mname</font>에<font color=red size=4><b>$edmg</b></font>의 데미지를 주었다.<BR>";
					if($esv eq 2){
						$mdef-=int($mdef/10);
						if($mdef < 0){$mdef=0;}
						$bmess.="$mname의 방어력이 내렸다.<BR>";
					}
					elsif(int(rand(4)) eq 2 && $esv eq 3 || $eab[14] && int(rand(6)) < 1){
						$mpara=$eabdmg[14];
						if(!$mpara){$mpara=1;}
						$bmess.="<font color=red>$mname는 독에 범해졌다.</font><BR>";
					}
					elsif($esv eq 4 && $esh<1000){
						$esh+=40;
						$bmess.="<font color=red>$mname의 명중율이 내렸다.</font><BR>";
					}
					elsif(int(rand(8)) eq 2 && $esv eq 5 || $eab[24] && int(rand(15)) eq 1){
						$mpara2=1;
						$bmess.="<font color=red>$mname는 마비되었다.</font><BR>";
					}
					elsif($esv eq 6 || $eab[28] && int(rand(4)) eq 1){
						$ehpup=int($edmg/2);
						$ehp+=$ehpup;
						if($ehp>$emaxhp){$ehp=$emaxhp;}
						$bmess.="$ename는 HP를<font color=blue>$ehpup</font>흡수했다.<BR>";
					}
					elsif(int(rand(8)) eq 2 && $esv eq 7 || $eab[16] && int(rand(1000)) < $eabdmg[16]){
						$mspeed-=50;
						if($mspeed<0){$mspeed=0;}
						$bmess.="<font color=red>$mname는 움직임이 늦어졌다.</font><BR>";
					}
					elsif(int(rand(30)) eq 7 && $esv eq 1 || $eab[9] && int(rand(1000)) < $eabdmg[9]){
						$mhp=0;
						$bmess.="<font color=red>$mname는 즉사했다.</font><BR>";
					}
					elsif($eab[26] && int(rand(3)) eq 1){
						$addmg = int(rand(200));
						$bmess.="한층 더<font color=red size=2><b>$addmg</b></font>의 추가 데미지를 주었다.<BR>";
						$edmg += $addmg;
					}
					elsif($eab[27] && int(rand(3)) eq 1){
						$esmp=int(rand(150));
						$mmp-=$esmp;
						if($mmp<0){$mmp=0;}
						$emp+=$esmp;
						if($emp>$emaxmp){$emp=$emaxmp;}
						$bmess.="$mname의 MP를<font color=red>$esmp</font>빼앗았다.<BR>";
					}
					elsif($eab[31] && int(rand(7)) eq 5){
						$abrand = int(rand(2));
						$iab = $msk[$abrand];
						$atype = $mabtype[$iab];
						if($mab[$atype]){
							$mab[$atype] = 0;
							$bmess.="<font color=red>$mname의 어빌리티 :$mabname[$iab]를 봉했다!</font><BR>";
						}
					}
				}
				$mhp-=$edmg;
			}
			if($mhp<=0){
				$bmess.="<font color=red>$mname는 힘이 다했다.</font><BR>";
			}
			if($mhp<=0 && $mab[11]  && int(rand(100)) < $mabdmg[11] && !$ehflg){
				$mhp=int($mmaxhp/2);
				$ehflg=1;
				$bmess.="<font color=red>$mname는 부활했다!</font><BR>";
			}elsif($mhp<=0){
				$mhp=0;
				$lose=1;
			}
			if($kou>10){&error("몇회 공격해와 군요");}
			if($lose){last;}
		}
		$bmess.="<BR>";
	}else{$bmess.="<font color=red>$ename는 움직일 수 없다.</font><BR>";}
	$epara2=0;
}

#턴별 전투 결과 표시
sub BPRINT{
	print <<"EOF";
<CENTER>


<TABLE border="0" width="80%" bgcolor="#000000" CLASS=TC>
  <TBODY>
    <TR>
      <TD colspan="8" align="center" bgcolor="$FCOLOR"><B><FONT color="#ffffcc">$turn 턴</FONT></B></TD>
    </TR>
    <TR>
      <TD colspan="4" bgcolor="000063" align="center"><FONT color="$FCOLOR2"><B><FONT size="-1">$mname</FONT></B></FONT></TD>
      <TD colspan="4" bgcolor="9c0000" align="center"><B><FONT size="-1" color="$FCOLOR2">$ename</FONT></B></TD>
    </TR>
    <TR>
      <TD colspan="4" bgcolor="#003300" align="center"><IMG src="./img/chara/$mchara.gif"></TD>
      <TD colspan="4" bgcolor="#003300" align="center"><IMG src="./img/chara/$echara.gif"></TD>
    </TR>
    <TR>
      <TD colspan="8" bgcolor="$FCOLOR2" align="center"><font size=-1>$bmess</font></TD>
    </TR>
    <TR>
      <TD bgcolor="#ccffff" width=12.5%>HP</TD>
      <TD bgcolor="#ccffff" width=12.5%>$mhp/$mmaxhp</TD>
      <TD bgcolor="#ccffff" width=12.5%>MP</TD>
      <TD bgcolor="#ccffff" width=12.5%>$mmp/$mmaxmp</TD>
      <TD bgcolor="#ccffff" width=12.5%>HP</TD>
      <TD bgcolor="#ccffff" width=12.5%>$ehp/$emaxhp</TD>
      <TD bgcolor="#ccffff" width=12.5%>MP</TD>
      <TD bgcolor="#ccffff" width=12.5%>$emp/$emaxmp</TD>
    </TR>
  </TBODY>
</TABLE>
</CENTER>
<BR><BR><BR><P>
EOF
}

#레벨업시의 처리
sub LVUP{
	$mlv2=int($mex/100)+1;
	if($mlv2>100){
		$mlv2=100;
		$mex=9999;
	}
	if($mlv2>$mlv){
		for($i=0;$i<$mlv2-$mlv;$i++){
			$com.="<font color=red>$mname는 레벨이 올랐다!</font><BR>";
			if($mflg3 eq""){$mflg3=0;}
			$hpup=int(rand($mvit/40+$mfai/80+8)) +1;$mmaxhp+=$hpup;
			$mpup=int(rand($mint/40+$mfai/80+2)) ;$mmaxmp+=$mpup;
			$strup=int(rand(2)) ;$mstr+=$strup;
			$vitup=int(rand(2)) ;$mvit+=$vitup;
			$intup=int(rand(2)) ;$mint+=$intup;
			$faiup=int(rand(2)) ;$mfai+=$faiup;
			$dexup=int(rand(2)) ;$mdex+=$dexup;
			$agiup=int(rand(2)) ;$magi+=$agiup;
			
			$mmaxmaxhp = $mmaxstr*5 + $mmaxvit*10 + $mmaxmen*3 - 2000;
			$mmaxmaxmp = $mmaxint*5 + $mmaxmen*3 - 800;
			
			if($mmaxmaxhp < $mmaxhp){$mmaxhp=$mmaxmaxhp;$maxcom[0]="<font color=red>(한계에 이르렀습니다.)</font>";}
			if($mmaxmaxmp < $mmaxmp){$mmaxmp=$mmaxmaxmp;$maxcom[1]="<font color=red>(한계에 이르렀습니다.)</font>";}

			if($mmaxstr < $mstr){$mstr=$mmaxstr;$maxcom[2]="<font color=red>(한계에 이르렀습니다.)</font>";}
			if($mmaxvit < $mvit){$mvit=$mmaxvit;$maxcom[3]="<font color=red>(한계에 이르렀습니다.)</font>";}
			if($mmaxint < $mint){$mint=$mmaxint;$maxcom[4]="<font color=red>(한계에 이르렀습니다.)</font>";}
			if($mmaxmen < $mfai){$mfai=$mmaxmen;$maxcom[5]="<font color=red>(한계에 이르렀습니다.)</font>";}
			if($mmaxdex < $mdex){$mdex=$mmaxdex;$maxcom[6]="<font color=red>(한계에 이르렀습니다.)</font>";}
			if($mmaxagi < $magi){$magi=$mmaxagi;$maxcom[7]="<font color=red>(한계에 이르렀습니다.)</font>";}
			
			$com.="HP가<font color=blue>$hpup</font>올랐다. $maxcom[0]<BR>";
			$com.="MP가<font color=blue>$mpup</font>올랐다. $maxcom[1]<BR>";
			if($strup){$com.="힘이<font color=blue>$strup</font>올랐다. $maxcom[2]<BR>";}
			if($vitup){$com.="생명력이<font color=blue>$vitup</font>올랐다. $maxcom[3]<BR>";}
			if($intup){$com.="지력이<font color=blue>$intup</font>올랐다. $maxcom[4]<BR>";}
			if($faiup){$com.="정신이<font color=blue>$faiup</font>올랐다. $maxcom[5]<BR>";}
			if($dexup){$com.="운이<font color=blue>$dexup</font>올랐다. $maxcom[6]<BR>";}
			if($agiup){$com.="속도가<font color=blue>$agiup</font>올랐다. $maxcom[7]<BR>";}

		}
	}
}


#한계 업시의 처리
sub MAXUP{
	if(int(rand(200)) eq 1){
		$coment="<font color=orange><b>$mname는 급성장했다!</b></font>";
		&maplog("<font color=orange>[급성장]</font>$mname는 급성장을 이루었습니다!");
		$rate=5;
	}
	elsif(int(rand(1000)) eq 1){
		$coment="<font color=red><b>$mname는 각성 했다!</b></font>";
		&maplog("<font color=red>[각성]</font>$mname는 각성 했다!");
		$rate=15;
	}
	else{
		$coment="<font color=green><b>$mname의 한계치가 상승했다!</b></font>";
		$rate=1;
	}
	$com.="$coment<BR>";
	$mmaxstr += $JMAX[$mtype][0]*$rate;
	$mmaxvit += $JMAX[$mtype][1]*$rate;
	$mmaxint += $JMAX[$mtype][2]*$rate;
	$mmaxmen += $JMAX[$mtype][3]*$rate;
	$mmaxdex += $JMAX[$mtype][4]*$rate;
	$mmaxagi += $JMAX[$mtype][5]*$rate;
	if($mmaxstr>=400){$mmaxstr = 400;}
	if($mmaxvit>=400){$mmaxvit = 400;}
	if($mmaxint>=400){$mmaxint = 400;}
	if($mmaxmen>=400){$mmaxmen = 400;}
	if($mmaxdex>=400){$mmaxdex = 400;}
	if($mmaxagi>=400){$mmaxagi = 400;}
	$mmax="$mmaxstr,$mmaxvit,$mmaxint,$mmaxmen,$mmaxdex,$mmaxagi,$mmaxlv";
}

1;

