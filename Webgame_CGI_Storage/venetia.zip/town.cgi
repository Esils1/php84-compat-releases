#!/usr/bin/perl
require './jcode.pl';
require './sub.cgi';
require './conf.cgi';

&decode;
if($ENV{'HTTP_REFERER'} !~ /cgi$/ ){ &error2("주소 바에 값을 입력하지 말아 주세요."); }
if($in{'mode'} eq"inn"){require './town/inn.pl';&inn;}
elsif($in{'mode'} eq"rshop"){require './town/rshop.pl';&rshop;}
elsif($in{'mode'} eq"rbuy"){require './town/rbuy.pl';&rbuy;}
elsif($in{'mode'} eq"hinn"){require './town/hinn.pl';&hinn;}
elsif($in{'mode'} eq"hinn2"){require './town/hinn2.pl';&hinn2;}
elsif($in{'mode'} eq"event"){require './town/event.pl';&event;}
elsif($in{'mode'} eq"event2"){require './town/event2.pl';&event2;}
elsif($in{'mode'} eq"arm" || $in{'mode'} eq"pro" || $in{'mode'} eq"acc" || $in{'mode'} eq"item"){require './town/shop.pl';&shop;}
elsif($in{'mode'} eq"buy"){require './town/buy.pl';&buy;}
elsif($in{'mode'} eq"sell"){require './town/sell.pl';&sell;}
elsif($in{'mode'} eq"fshop"){require './town/fshop.pl';&fshop;}
elsif($in{'mode'} eq"fex"){require './town/fex.pl';&fex;}
elsif($in{'mode'} eq"fbid"){require './town/fbid.pl';&fbid;}
elsif($in{'mode'} eq"fget"){require './town/fget.pl';&fget;}
elsif($in{'mode'} eq"s_shop"){require './town/s_shop.pl';&s_shop;}
elsif($in{'mode'} eq"s_buy"){require './town/s_buy.pl';&s_buy;}
elsif($in{'mode'} eq"arena"){require './town/arena.pl';&arena;}
elsif($in{'mode'} eq"entry_can"){require './town/entry_can.pl';&entry_can;}
elsif($in{'mode'} eq"battle_entry"){require './town/battle_entry.pl';&battle_entry;}
elsif($in{'mode'} eq"battle_entry2"){require './town/battle_entry2.pl';&battle_entry2;}
elsif($in{'mode'} eq"jeryon"){require './town/jeryon.pl';&jeryon;}
elsif($in{'mode'} eq"jeryon2"){require './town/jeryon2.pl';&jeryon2;}
elsif($in{'mode'} eq"quest"){require './town/quest.pl';&quest;}
elsif($in{'mode'} eq"quest2"){require './town/quest2.pl';&quest2;}
elsif($in{'mode'} eq"bank"){require './town/bank.pl';&bank;}
elsif($in{'mode'} eq"banka"||$in{'mode'} eq"bankh"||$in{'mode'} eq"bankall"||$in{'mode'} eq"bankall2"){require './town/bank2.pl';&bank2;}
else{&error2("올바르게 선택되고 있지 않습니다.");}
exit;

