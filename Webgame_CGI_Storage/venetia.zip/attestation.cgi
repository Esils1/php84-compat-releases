sub attestation {

	&header;
print <<NEW;
◆ 메일에 첨부된 인증 키와 ID와 패스를 입력해 주세요.<BR>
◆ 인증 키가 등록되면 게임을 개시할 수 있습니다.<p>

<center><form method=$method action=./newentry.cgi>
<table bgcolor=$TABLE_C><tbody bgcolor=$TD_C3>
<TR><TH bgcolor=$TD_C2 colspan=2>인증</TH></TR>
<TR><TH>ID</TH><TD>
<input type=text name=id class=text size=10></TD></TR>
<TR><TH>패스워드</TH><TD>
<input type=password name=pass class=text size=10></TD></TR>
<TR><TH>인증 키</TH><TD>
<input type=password name=key class=text size=10></TD></TR>
</TD></TR>
<input type=hidden name=mode value="set_entry">
<TR><TD bgcolor=$TD_C4 colspan=2 align=center><input type=submit value="인증"></TD></TR>
</TBODY></TABLE>
</form>

NEW
	&footer;
	exit;
}

# Sub Set Regist #
sub set_entry {

	&host_name;
	&chara_open;
	$akey = crypt("$mpass",$ATTESTATION_ID);

	if($akey ne $in{'key'}){&error2("암증 키가 다릅니다!\n");}
	if($murl eq ""){&error2("이미 인증이 끝난 상태입니다.");}

	&maplog("<font color=blue><B>[인증]</B></font>$mname가 새롭게 등록되었습니다!");
	$murl="";

	&chara_input;
	&header;

	print qq|인증이 완료했습니다<br>\n|;
	print qq|ID는$mid입니다.<br>\n|;
	print qq|패스워드는$mpass입니다.<br><br>\n|;

	print qq|등록 수속은 이것으로 완료입니다.<br>\n|;
	print qq|TOP 페이지로부터 로그인할 수 있습니다.<br>\n|;

	print qq|<a href="./index.cgi">\[돌아오는\]</a>\n|;
	&footer;
	exit;
}

#------------------#
#  메일 송신 처리  #
#------------------#
sub mail_to {
	unless (-e $SENDMAIL) { &error2("sendmail의 패스가 부정합니다"); }

	# 메일 타이틀
	$mail_sub = " 등록 완료 통지";
	&time_data;

	$a_pass = crypt("$in{'pass'}", $ATTESTATION_ID);
	# 메일 본문
	$mail_msg = <<"EOM";
$in{'name'} 님

지난 번에는, $TITLE 에의 등록을 감사합니다.
등록 내용은 이하대로이므로, 확인해 주십시오.

■등록일시：$daytime
■호스트명：$host
■참가자명：$in{'name'}
■E메일：$in{'mail'}
■ID    ：$in{'id'}
■PASS：$in{'pass'}
■인증 키：$a_pass

인증 키를 등록하는 것에 의해서 게임에 참가하는 것이로
옵니다.

[인증 키의 설정]
$FH_URL/newentry.cgi?mode=ATTESTATION
(※이쪽으로부터 등록을 할 수 있습니다.)

자주(잘) 참가 규약을 잘 읽고 나서 게임을 개시해 주세요.
또, 패스워드, ID등의 재발행은 하지 않으므로 소중히
보관해 두어 주세요.

_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/
$TITLE 관리인
  Home:   $LINKURL1
EOM
	# JIS 코드에 변환
    	&jcode::convert(*mail_sub,'jis');
    	&jcode::convert(*mail_msg,'jis');

	# 코멘트내의 개행과 태그를 복원
	$mail_msg =~ s/<br>/\n/ig;

	# 메일 처리
	open(MAIL,"| $SENDMAIL -t") || &E_ERR("메일 송신에 실패했습니다");
	print MAIL "To: $in{'mail'}\n";
	print MAIL "Subject: $mail_sub\n";
	print MAIL "MIME-Version: 1.0\n";
	print MAIL "Content-type: text/plain; charset=ISO-2022-JP\n";
	print MAIL "Content-Transfer-Encoding: 7bit\n";
	print MAIL "X-Mailer: $ver\n\n";
	print MAIL "$mail_msg\n";
	close(MAIL);

}

1;
