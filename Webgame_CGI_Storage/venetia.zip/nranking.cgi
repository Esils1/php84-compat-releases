#!/usr/bin/perl
require './jcode.pl';
require './sub.cgi';
require './conf.cgi';
	&header;
	print"<table CLASS=TC width=100%><td align=center><font color=$FCOLOR2 size=4>각종 랭킹</font></td></table><BR>";
	print"<center><a href=./jranking.cgi>숙련 랭킹</a></center>";
	open(IN,"./data/country.cgi") or &error2('나라 데이터를 열지 않았습니다.');
	@COU = <IN>;
	close(IN);
	$con_no=0;
	
		
	$dir="./logfile/chara";
	opendir(dirlist,"$dir");
	$i=0;
	while($file = readdir(dirlist)){
		if($file =~ /\.cgi/i){
			$datames = "검색：$dir/$file<br>\n";
			if(!open(cha,"$dir/$file")){
				&error("$dir/$file가 발견되지 않습니다.<br>\n");
			}
			@cha = <cha>;
			close(cha);
			$list[$i]="$file";
			($rid,$rpass,$rname,$rurl,$rchara,$rsex,$rhp,$rmaxhp,$rmp,$rmaxmp,$rele,$rstr,$rvit,$rint,$rfai,$rdex,$ragi,$rmax,$rcom,$rgold,$rbank,$rex,$rtotalex,$rjp,$rabp,$rcex,$runit,$rcon,$rarm,$rpro,$racc,$rtec,$rsta,$rpos,$rmes,$rhost,$rdate,$rsyo,$rclass,$rtotal,$rkati,$rtype) = split(/<>/,$cha[0]);
			$rpoint=int(($rmaxhp+$rmaxmp)/3) +$rstr+$rvit+$rint+$rfai+$rdex+$ragi;
			($rjp[0],$rjp[1],$rjp[2],$rjp[3],$rjp[4],$rjp[5]) = split(/,/,$rjp);
			($rmaxstr,$rmaxvit,$rmaxint,$rmaxmen,$rmaxdex,$rmaxagi,$rmaxlv) = split(/,/,$rmax);
			$rmaxtotal=$rmaxstr+$rmaxvit+$rmaxint+$rmaxint+$rmaxmen+$rmaxdex+$rmaxagi;
			push(@CL_DATA,"$rid<>$rpass<>$rname<>$rurl<>$rchara<>$rsex<>$rhp<>$rmaxhp<>$rmp<>$rmaxmp<>$rele<>$rstr<>$rvit<>$rint<>$rfai<>$rdex<>$ragi<>$rmax<>$rcom<>$rgold<>$rbank<>$rex<>$rtotalex<>$rjp[0]<>$rjp[1]<>$rjp[2]<>$rjp[3]<>$rjp[4]<>$rjp[5]<>$rabp<>$rcex<>$runit<>$rcon<>$rarm<>$rpro<>$racc<>$rtec<>$rsta<>$rpos<>$rmes<>$rhost<>$rdate<>$rsyo<>$rclass<>$rtotal<>$rkati<>$rtype<>$rpoint<>$rmaxtotal<>\n");
		}
		if($mn>10000){&error("루프");}
		$mn++;
	}
	closedir(dirlist);

	@tmp1 = map {(split /<>/)[20]} @CL_DATA;
	@tmp2 = map {(split /<>/)[47]} @CL_DATA;
	@tmp3 = map {(split /<>/)[48]} @CL_DATA;
	@CL_DATA1 = @CL_DATA[sort {$tmp1[$b] <=> $tmp1[$a]} 0 .. $#tmp1];
	@CL_DATA2 = @CL_DATA[sort {$tmp2[$b] <=> $tmp2[$a]} 0 .. $#tmp2];
	@CL_DATA3 = @CL_DATA[sort {$tmp3[$b] <=> $tmp3[$a]} 0 .. $#tmp3];
	
	$NAME[0]="부호 순위";
	$NAME[1]="강자 순위";
	$NAME[2]="잠재력";
	for($i=0;$i<3;$i++){
		$con_table[$i].="<table CLASS=FC>";
		$con_table[$i].="<tr>";
		$con_table[$i].="<td colspan=4 align=center bgcolor=$ELE_BG[$con_ele]><font color=$FCOLOR2 size=5><b>$NAME[$i]</b></font></td>";
		$con_table[$i].="</tr>";
		$con_table[$i].="<tr>";
		$con_table[$i].="<td width=25% CLASS=TC><font color=$FCOLOR2>순위</font></td><td width=25% CLASS=TC><font color=$FCOLOR2>이름</font></td><td width=25% CLASS=TC><font color=$FCOLOR2>얼굴</font></td><td width=25% CLASS=TC><font color=$FCOLOR2>포인트</font></td>";
		$con_no++;
	}
	
	foreach(@CL_DATA1){
		($rid,$rpass,$rname,$rurl,$rchara,$rsex,$rhp,$rmaxhp,$rmp,$rmaxmp,$rele,$rstr,$rvit,$rint,$rfai,$rdex,$ragi,$rmax,$rcom,$rgold,$rbank,$rex,$rtotalex,$rjp[0],$rjp[1],$rjp[2],$rjp[3],$rjp[4],$rjp[5],$rab,$rcex,$runit,$rcon,$rarm,$rpro,$racc,$rtec,$rsta,$rpos,$rmes,$rhost,$rdate,$rsyo,$rclass,$rtotal,$rkati,$rtype,$rpoint,$rmaxtotal) = split(/<>/);
		$pid = &id_change("$rid");
		if($cont_cou[0]<30){
			$cont_cou[0]++;
			$rank="$cont_cou[0]위";
			if($cont_cou[0] eq 1){
				$rank="<font color=red size=4><b>★$cont_cou[0]위</b></font>";
				$rbank="<font color=red size=4><b>$rbank</b></font>";
			}
			elsif($cont_cou[0] < 4){
				$rank="<font color=blue size=3><b>$cont_cou[0]위</b></font>";
				$rbank="<font color=blue size=3><b>$rbank</b></font>";
			}
			$con_table[0].="<tr><td bgcolor=$ELE_C[$con_ele[0]] size=2>$rank</td><td bgcolor=$ELE_C[$con_ele[0]] size=2>$rname</td><td bgcolor=$ELE_C[$con_ele[0]]><img src=\"./img/chara/$rchara.gif\"></td><td bgcolor=$ELE_C[$con_ele[0]]>－</td></tr>";
		}else{last;}
	}
	foreach(@CL_DATA2){
		($rid,$rpass,$rname,$rurl,$rchara,$rsex,$rhp,$rmaxhp,$rmp,$rmaxmp,$rele,$rstr,$rvit,$rint,$rfai,$rdex,$ragi,$rmax,$rcom,$rgold,$rbank,$rex,$rtotalex,$rjp[0],$rjp[1],$rjp[2],$rjp[3],$rjp[4],$rjp[5],$rab,$rcex,$runit,$rcon,$rarm,$rpro,$racc,$rtec,$rsta,$rpos,$rmes,$rhost,$rdate,$rsyo,$rclass,$rtotal,$rkati,$rtype,$rpoint,$rmaxtotal) = split(/<>/);
		$pid = &id_change("$rid");
		if($cont_cou[1]<30){
			$cont_cou[1]++;
			$rank="$cont_cou[1]위";
			if($cont_cou[1] eq 1){
				$rank="<font color=red size=4><b>★$cont_cou[1]위</b></font>";
				$rpoint="<font color=red size=4><b>$rpoint</b></font>";
			}
			elsif($cont_cou[1] < 4){
				$rank="<font color=blue size=3><b>$cont_cou[1]위</b></font>";
				$rpoint="<font color=blue size=3><b>$rpoint</b></font>";
			}
			$con_table[1].="<tr><td bgcolor=$ELE_C[$con_ele[0]] size=2>$rank</td><td bgcolor=$ELE_C[$con_ele[0]] size=2>$rname</td><td bgcolor=$ELE_C[$con_ele[0]]><img src=\"./img/chara/$rchara.gif\"></td><td bgcolor=$ELE_C[$con_ele[0]]>$rpoint</td></tr>";
		}else{last;}
	}
	foreach(@CL_DATA3){
		($rid,$rpass,$rname,$rurl,$rchara,$rsex,$rhp,$rmaxhp,$rmp,$rmaxmp,$rele,$rstr,$rvit,$rint,$rfai,$rdex,$ragi,$rmax,$rcom,$rgold,$rbank,$rex,$rtotalex,$rjp[0],$rjp[1],$rjp[2],$rjp[3],$rjp[4],$rjp[5],$rab,$rcex,$runit,$rcon,$rarm,$rpro,$racc,$rtec,$rsta,$rpos,$rmes,$rhost,$rdate,$rsyo,$rclass,$rtotal,$rkati,$rtype,$rpoint,$rmaxtotal) = split(/<>/);
		$pid = &id_change("$rid");
		if($cont_cou[2]<30){
			$cont_cou[2]++;
			$rank="$cont_cou[2]위";
			if($cont_cou[2] eq 1){
				$rank="<font color=red size=4><b>★$cont_cou[2]위</b></font>";
				$rmaxtotal="<font color=red size=4><b>$rmaxtotal</b></font>";
			}
			elsif($cont_cou[2] < 4){
				$rank="<font color=blue size=3><b>$cont_cou[2]위</b></font>";
				$rmaxtotal="<font color=blue size=3><b>$rmaxtotal</b></font>";
			}
			$con_table[2].="<tr><td bgcolor=$ELE_C[$con_ele[0]] size=2>$rank</td><td bgcolor=$ELE_C[$con_ele[0]] size=2>$rname</td><td bgcolor=$ELE_C[$con_ele[0]]><img src=\"./img/chara/$rchara.gif\"></td><td bgcolor=$ELE_C[$con_ele[0]]>$rmaxtotal</td></tr>";
		}else{last;}
	}
	
	$con_no=0;
	for($i=0;$i<3;$i++){
		$con_table[$i].="</table>";
	}
	print"<table colspan=3>";
	for($i=0;$i<3;$i++){
		if($i%3 eq 0){
			print"<tr><td>$con_table[$i]</td>";
		}elsif($i%3 eq 1){
			print"<td>$con_table[$i]</td>";
		}else{
			print"<td>$con_table[$i]</td></tr>";
		}
	}
	print"</table>";
	print"<center>플레이어수：$mn명</center><BR>";
&footer;
sub id_change {
	local($inpw) = $_[0];

	@yy = unpack("C*", $inpw);
	$word="";
	foreach(@yy){
		$word .= "$_\,";
	}
	chomp($word);
	$encrypt = reverse($word);

	return $encrypt;
}
exit;

