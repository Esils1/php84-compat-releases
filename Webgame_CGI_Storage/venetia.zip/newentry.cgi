#!/usr/bin/perl

#################################################################
#   【면책 사항】                                                #
#    이 스크립트는 프리 소프트입니다.이 스크립트를 사용했다 #
#    어떠한 손해에 대해서 작자는 일절의 책임을 지지 않습니다.         #
#    또 설치에 관한 질문은 서포트 게시판에 부탁드리겠습니다.   #
#    직접 메일에 의한 질문은 일절 받고있지 않습니다.       #
#################################################################

require './jcode.pl';
require './sub.cgi';
require './conf.cgi';

&decode;

if($in{'mode'} eq 'ATTESTATION') { require './attestation.cgi';&attestation; }
elsif($in{'mode'} eq 'set_entry') { require './attestation.cgi';&set_entry; }
else{ require './attestation.cgi';&attestation;}

exit;

