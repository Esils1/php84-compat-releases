#!/usr/bin/perl
require './jcode.pl';
require './sub.cgi';
require './conf.cgi';
	&decode;
	&header;
	
	#렬수
	$col=10;
	#행수
	$line=6;
	#1 페이지에 표시하는 수
	$pre=$col*$line;

	$page=$in{'page'};
	$nextpage=$page+1;
	$frontpage=$page-1;
	$first=$page*$pre;
	$last=($page+1) *$pre-1;
	if($last>$CHARAIMG){$last=$CHARAIMG;}
	print"<center><table CLASS=TC width=900><tr><td colspan=15 align=center><font color=$FCOLOR2 size=4>아이콘 일람</font></td></tr>";
	for($i=$first;$i<=$last;$i++){
		if($i%$col eq 0){
			print"<tr>";
		}
		print"<td align=center bgcolor=$FCOLOR2><img src=./img/chara/$i.gif><br><font size=2>No.$i</font></td>";
		if($i%$col eq $col-1){
			print"</tr>";
		}
	}

	print"<tr><td bgcolor=$FCOLOR2 colspan=15 align=center>";
	if($page>0){
		print"<form action=icon.cgi method=POST><input type=hidden name=page value=$frontpage><input type=submit CLASS=FC value=전에></form>";
	}
	if($i<$CHARAIMG){
		print"<form action=icon.cgi method=POST><input type=hidden name=page value=$nextpage><input type=submit CLASS=FC value=다음에></form>";
	}
	print"</td></tr>";
	print"</table>";
	$con_no=0;
	
	print"$htable</table></center><BR>";
&footer;
exit;

