sub unit {
	&chara_open;
	&con_open;
	&town_open;
	&header;
	&status_print;
	open(IN,"./data/unit.cgi");
	@UNIT_DATA = <IN>;
	close(IN);

	@UNIT_DATA2 = @UNIT_DATA;

	$no=0;
	$unit="<table border=0 bgcolor=000000 width=90%>";
	$unit.="<tr><td colspan=6 width=100% bgcolor=$ELE_BG[0] align=center><font color=$ELE_C[0]>부대 편성</font></td></tr>";
	$unit.="<tr><td bgcolor=$ELE_C[0] align=center><font color=$ELE_BG[0] size=2>선택</font></td>";
	$unit.="<td bgcolor=$ELE_C[0] align=center><font color=$ELE_BG[0] size=2>부대명</font></td>";
	$unit.="<td bgcolor=$ELE_C[0] align=center><font color=$ELE_BG[0] size=2>대장</font></td>";
	$unit.="<td bgcolor=$ELE_C[0] align=center><font color=$ELE_BG[0] size=2>대장명</font></td>";
	$unit.="<td bgcolor=$ELE_C[0] align=center><font color=$ELE_BG[0] size=2>대원</font></td>";
	$unit.="<td bgcolor=$ELE_C[0] align=center><font color=$ELE_BG[0] size=2>메세지</font></td></tr>";
	foreach(@UNIT_DATA){
		($uid,$lchara,$lname,$uname,$bid,$bname,$bmes,$bcon) =split(/<>/);
		$tname = "";
		if($uid eq $bid && $mcon eq $bcon){
			foreach(@UNIT_DATA2){
				($u2id,$l2chara,$l2name,$u2name,$b2id,$b2name,$b2mes,$b2con) =split(/<>/);
				if($uid eq $u2id && $u2id ne $b2id){
					$tname.="$b2name,";
				}
			}
			$unit.="<tr><td width=1% bgcolor=$ELE_BG[$lcon]><input type=radio name=no value=$uid></td>";
			$unit.="<td bgcolor=$ELE_C[0] align=center><font color=$ELE_BG[0]>$uname</font></td>";
			$unit.="<td bgcolor=$ELE_C[0] align=center><font color=$ELE_BG[0] size=2><img src=http://amylz.com/venetia/img/chara/$lchara.gif></font></td>";
			$unit.="<td bgcolor=$ELE_C[0] align=center><font color=$ELE_BG[0] size=2>$lname</font></td>";
			$unit.="<td bgcolor=$ELE_C[0] align=center><font color=$ELE_BG[0] size=2>$tname</font></td>";
			$unit.="<td bgcolor=$ELE_C[0] align=center><font color=$ELE_BG[0] size=2>$bmes</font></td>";
			$no++;
		}
	}
	$rule.="</table>";

	print <<"EOF";
<TABLE border="0" width="80%" align=center bgcolor="#ffffff" height="150" CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">부대 편성</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="http://amylz.com/venetia/img/etc/country2.gif"></TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc">부대의 편성을 실시합니다.<BR>부대의 입대·이탈·해산, 대원의 해고를 실시할 수 있습니다.<BR></FONT></TD>
    </TR>
    <TR>
      <TD colspan="2" align="center">
	<form action="./country.cgi" method="POST">
	$unit
    </TR>
    <TR>
      <TD colspan="6" align="center" bgcolor="#ffffcc">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=hidden name=mode value=unit_entry>
	<INPUT type=submit CLASS=FC value=입대></form>
	<form action="./country.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=hidden name=mode value=unit_delete>
	<INPUT type=submit CLASS=FC value="부대의 해산·이탈"></form>
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value=돌아온다></form></TD>
    </TR>
    <TR>
      <td colspan=6 width=100% bgcolor=$ELE_BG[0] align=center><font color=$ELE_C[0]>부대 신규 작성(명성 100이상)</font></td>
    </TR>
　　<TR bgcolor=$ELE_C[0]>
	<form action="./country.cgi" method="POST">
	<TD colspan=3 align=right>부대명(2~10자)</TD>
      	<TD colspan=3><input type=text name=unit></TD>
    </TR>
    <TR bgcolor=$ELE_C[0]>
	<TD colspan=3 align=right>코멘트(20자 이내)</TD>
      	<TD colspan=3><input type=text size=60 name=com></TD>
    </TR>
　　<TR>
      <TD colspan="6" align="center" bgcolor="#ffffcc">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=hidden name=mode value=unit_edit>
	<INPUT type=submit CLASS=FC value="신규 작성"></form>
	</TD>
    </TR>
  </TBODY>
</TABLE>
<center></center>
EOF
	&footer;
	exit;
}
1;

