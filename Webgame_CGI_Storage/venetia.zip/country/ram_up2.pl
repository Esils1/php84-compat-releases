sub ram_up2 {
	&chara_open;
	&header;
	&status_print;
	&town_open;
	&con_open;
	if($con_id eq 0){&error("무소속은 이용할 수 없습니다.");}
	if($town_con ne $mcon){&error("자국의 거리가 아닙니다.");}
	if(!$hit){&error("나라 데이터에 이상이 있습니다.");}
	if($mcex<100){&error("명성이  100필요합니다.");}
	if($in{'gold'} eq ""){&error("금액이 입력되지 않았습니다.");}
	if($in{'gold'} =~ m/[^0-9]/){&error("금액에 숫자 이외의 문자가 포함되어 있습니다.");}
	if($in{'gold'} <0){&error("성실하게 입력해 주세요.");}
	if($in{'gold'} >300){&error("최대 300만 Gold까지입니다.");}

	$date = time();
	$ktime = $KTIME - $date + $mdate2;
	if($ktime>0){&error("다음의 강화까지 $ktime 초 기다려 주세요.");}

	$gold=$in{'gold'}*10000;
	$con_gold-=$gold;
	if($con_gold<0){&error("국고가 충분하지 않습니다.");}
	$up=int($in{'gold'}*((100+$mint)/300));
	
	if($in{'pow'} eq"t_maxhp"){
		$com="성벽 MAX";
		$up=$up*10;
		$town_max+=$up;
		if($town_max>9999){$town_max=9999;}
	}elsif($in{'pow'} eq"t_hp"){
		$com="성벽";
		$up=$up*100;
		$town_hp+=$up;
		if($town_hp>$town_max){$town_hp=$town_max;}
	}elsif($in{'pow'} eq"t_str"){
		$com="공격력";
		$town_str+=$up;
		if($town_str>999){$town_str=999;}
	}elsif($in{'pow'} eq"t_def"){
		$com="내구력";
		$town_def+=$up;
		if($town_def>999){$town_def=999;}
	}else{&error("부정한 액세스입니다.");}
	$mdate2=time();

	&con_input;
	&chara_input;
	&town_input;
	&maplog("<font color=blueviolet>[강화]</font>$mname는$town_name의$com를<font color=red>$up</font>강화했습니다.");
	print <<"EOF";
<TABLE border="0" width="80%" align=center bgcolor="#ffffff" height="150" CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">성벽의 강화</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="http://amylz.com/venetia/img/etc/siro.gif"></TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc">$com를$up강화했습니다.</FONT></TD>
    </TR>
    <TR>
      <TD colspan="2" align="center">
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value=돌아온다></form></TD>
	
    </TR>
  </TBODY>
</TABLE>
<center></center>
EOF

	&footer;
	exit;
}
1;
