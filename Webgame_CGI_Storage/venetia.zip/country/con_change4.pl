sub con_change4{
	&chara_open;
	&con_open;
	&town_open;

	if($con_id eq 0){&error("무소속은 실행할 수 없습니다.");}
	if($munit ne ""){&error("부대로부터 이탈해 주세요.");}
	if($con_king eq"$mid"){&error("국왕은 실행할 수 없습니다.");}
	$mgold-=5000000;
	if($mgold<0){&error("돈이 충분하지 않습니다.");}
	$mcon=0;
	$mcex=0;
#	$mhp=50;$mmaxhp=50;
#	$mmp=30;$mmaxmp=30;
#	$mstr=30;$mvit=30;
#	$mint=30;$mfai=30;
#	$mdex=30;$magi=30;
#	$mex=0;

	&header;
	
	print <<"EOF";
<TABLE border="0" width="80%" bgcolor="#ffffff" height="150" align=center CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">하야</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="./img/etc/country.gif"></TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc">하야 했습니다.</FONT></TD>
    </TR>
    <TR>
      <TD colspan="2" align="right">
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value=돌아온다></form></TD>
	
    </TR>
  </TBODY>
</TABLE>
EOF
	&chara_input;
	&maplog("<font color=black>[하야]</font>$mname는 무소속이 되었습니다.");
	&kh_log("하야를 실시해, 무소속이 된다.","무소속");

	&footer;
	exit;
}
1;

