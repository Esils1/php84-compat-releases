sub suport_money {
	&chara_open;
	&status_print;
	&con_open;
	
	if($con_id eq 0){&error("무소속은 원조할 수 없습니다.");}
	&header;
	
	print <<"EOF";
<TABLE border="0" width="80%" align=center bgcolor="#ffffff" height="150" CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">자금의 원조</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="http://amylz.com/venetia/img/etc/pub.gif"></TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc">$con_name국에 자금의 원조를 실시합니다.<BR>원조액을 입력해 주세요.<BR>나라의 자금：$con_gold Gold</FONT></TD>
    </TR>
    <TR>
      <TD colspan="2" align="center">
	$STPR
	<form action="./country.cgi" method="post">
	<INPUT type=text size=5 name=gold>0000Gold
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=hidden name=mode value=suport_money2>
	<INPUT type=submit value=원조 CLASS=FC></form>
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value=돌아온다></form></TD>
	
    </TR>
  </TBODY>
</TABLE>
<center></center>
EOF
	&footer;
	exit;
}
1;

