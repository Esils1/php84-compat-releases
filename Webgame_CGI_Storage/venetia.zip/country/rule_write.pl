sub rule_write {
	&chara_open;
	&header;
	&status_print;
	&con_open;
	&town_open;
	&time_data;

	if($in{'message'} eq ""){&error("메세지를 입력해 주세요.");}
	if(length($in{'message'}) > 200){&error("100 문자 이내에서 입력해 주세요.");}
	if($con_king ne $mid && $y_chara[0] ne $mid && $y_chara[1] ne $mid && $y_chara[2] ne $mid){&error("직무자 이외 실행할 수 없습니다.");}
	
	if($in{'type'} eq 1){
		$BFILE="./blog/rule/$con_id.cgi";
		$rule="rule";
	}elsif($in{'type'} eq 2){
		if($con_king ne $mid){&error("왕 이외 실행할 수 없습니다.");}
		$BFILE="./blog/rule/0.cgi";
		$rule="all_rule";
	}else{&error("부정한 액세스입니다.");}
	open(IN,"$BFILE");
	@BBS_DATA = <IN>;
	close(IN);
	
	if($con_king eq $mid){$etc="$con_name 국왕";}
	$bcount=@BBS_DATA;
	if($bcount>=20){&error("더 이상 추가할 수 없습니다.");}
	unshift(@BBS_DATA,"$mid<>$mname<>$mchara<>$con_ele<>$in{'message'}<>$etc<>$mhost<>$daytime<>\n");
	
	open(OUT,">$BFILE");
	print OUT @BBS_DATA;
	close(OUT);

	print <<"EOF";
<TABLE border="0" width="80%" align=center bgcolor="#ffffff" height="120" CLASS=FC>
  <TBODY>
    <TR>
      <TD align="center" bgcolor="#993300"><FONT color="#ffffcc">기입 완료</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#330000" height=100><FONT color="#ffffcc">썼습니다.</FONT></TD>
    </TR>
    <TR>
      <TD align="center">
	<form action="./country.cgi" method="POST">
	<INPUT type=hidden name=mode value=$rule>
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value=OK></form></TD>
	
    </TR>
  </TBODY>
</TABLE>
<center></center>
EOF

	&footer;
	exit;
}
1;

