sub ram_down {
	&chara_open;
	&status_print;
	&con_open;
	&town_open;
	if($con_id eq 0){&error("무소속은 이용할 수 없습니다.");}
	if($town_con ne $mcon){&error("자국의 거리가 아닙니다.");}

	foreach(@CON_DATA){
		($con2_id,$con2_name,$con2_ele,$con2_gold,$con2_king,$con2_yaku,$con2_cou,$con2_mes,$con2_etc) =split(/<>/);
		if("$con2_id" eq "$town_con"){$hit=1;}
		$CONELE[$con2_id]=$con2_ele;
		$CONNAME[$con2_id]=$con2_name;
		$c_no++;
	}
	if(!$hit){$con2_ele=0;$con2_name="무소속";$con2_id=0;}

	$i=0;
	$tpr="<table bgcolor=663300><TD width=15 height=5 bgcolor=ffffcc CLASS=GC>　</TD>";
	for($i=0;$i<6;$i++){
		$tpr.= "<TD width=15 height=5 bgcolor=ffffcc><font size=1>$i</font></TD>";
	}
	for($i=0;$i<6;$i++){
		$n = $i;
		$tpr.= "<TR><TD bgcolor=ffffcc><font size=1>$n</font></td>";
		for($j=0;$j<6;$j++){
			$m_hit=0;$tx=0;
			foreach(@TOWN_DATA){
				($town2_id,$town2_name,$town2_con,$town2_ele,$town2_gold,$town2_arm,$town2_pro,$town2_acc,$town2_ind,$town2_tr,$town2_s,$town2_x,$town2_y) =split(/<>/);
				if("$town2_x" eq "$j" && "$town2_y" eq "$i"){$m_hit=1;last;}
				$tx++;
			}
			$col="";
			if($m_hit){
				if($town2_id eq $mpos){
					$col = $ELE_C[$CONELE[$town2_con]];
				}else{
					$col = $ELE_BG[$CONELE[$town2_con]];
				}
			
				if($town2_id eq 0){
					$tpr.= "<TH bgcolor=$col><img src=\"http://amylz.com/venetia/img/town/m_2.gif\" title=\"$town2_name【$CONNAME[$town2_con]】\" width=15 height=10></TH>";
				}else{
					$tpr.= "<TH bgcolor=$col><img src=\"http://amylz.com/venetia/img/town/m_4.gif\" title=\"$town2_name【$CONNAME[$town2_con]】\" width=15 height=10></TH>";
				}
			}else{
				$tpr.= "<TH>　</TH>";
			}
		}
		$tpr.= "</TR>";
	}
	$tpr.="</table>";

	$movelist="<select name=tid>";
	$movelist.="<option value=\"\">거리를 선택";
	foreach(@TOWN_DATA){
		($town2_id,$town2_name,$town2_con,$town2_ele,$town2_gold,$town2_arm,$town2_pro,$town2_acc,$town2_ind,$town2_tr,$town2_s,$town2_x,$town2_y) =split(/<>/);
		if(abs($town2_x-$town_x) <= "1" && abs($town2_y-$town_y) <= "1" && $town_name ne $town2_name){$movelist.="<option value=$town2_id>$town2_name";}
		$tx++;
	}
	$movelist.="</select>";


	$list="<select name=pow>";
	$list.="<option value=t_str>공격력 다운";
	$list.="<option value=t_def>내구력 다운";
	$list.="</select>";

	&header;
	print <<"EOF";
<TABLE border="0" width="80%" align=center bgcolor="#ffffff" height="150" CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">계략</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center>$tpr</TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc">타국의 거리에 계략을 실시합니다.<BR>공격 대상을 선택해, 금액을 입력해 주세요.<BR>나라의 자금：$con_gold Gold</FONT></TD>
    </TR>
    <TR>
      <TD colspan="2" align="center">
	<form action="./country.cgi" method="post">
	$movelist
	$list
	<INPUT type=text size=5 name=gold>0000Gold
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=hidden name=mode value=ram_down2>
	<INPUT type=submit value=계략 CLASS=FC></form>
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value=돌아온다></form></TD>
	
    </TR>
  </TBODY>
</TABLE>
<center></center>
EOF

	&footer;
	exit;
}
1;

