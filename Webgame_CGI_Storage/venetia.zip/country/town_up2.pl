sub town_up2 {
	&chara_open;
	&status_print;
	&town_open;
	&con_open;
	if($con_id eq 0){&error("무소속은 이용할 수 없습니다.");}
	if($town_con ne $mcon){&error("자국의 거리가 아닙니다.");}
	if($mid ne"$con_king" && $y_chara[0] ne $mid && $y_chara[1] ne $mid && $y_chara[2] ne $mid && $mid ne "chanje"){&error("왕 또는 직무자 이외 실행할 수 없습니다.");}
	if($mcex<500){&error("명성이  500필요합니다.");}
	if(!$hit){&error("나라 데이터에 이상이 있습니다.");}
	if($in{'gold'} eq ""){&error("금액이 입력되지 않았습니다.");}
	if($in{'gold'} =~ m/[^0-9]/){&error("금액에 숫자 이외의 문자가 포함되어 있습니다.");}
	if($in{'gold'} <0){&error("성실하게 입력해 주세요.");}
	
	$gold=$in{'gold'}*10000;
	$up=int($in{'gold'}*((100+$mint)/300));
	$con_gold-=$gold;
	if($con_gold<0){&error("국고가 충분하지 않습니다.");}
		
	if($in{'pow'} eq"t_arm"){
		$com="무기 개발치";
		$town_arm+=$up;
		if($town_arm>999){$town_arm=999;}
	}elsif($in{'pow'} eq"t_pro"){
		$com="방어구 개발치";
		$town_pro+=$up;
		if($town_pro>999){$town_pro=999;}
	}elsif($in{'pow'} eq"t_acc"){
		$com="악세사리 개발치";
		$town_acc+=$up;
		if($town_acc>999){$town_acc=999;}
	}elsif($in{'pow'} eq"t_ind"){
		$com="산업치";
		$town_ind+=$up;
		if($town_ind>999){$town_ind=999;}
	}else{&error("부정한 액세스입니다.");}

	&maplog("<font color=green>[개발]</font>$mname는$town_name의$com를<font color=red>$up</font>강화했습니다.");
	&town_input;
	&con_input;

	&header;
	
	print <<"EOF";
<TABLE border="0" width="80%" align=center bgcolor="#ffffff" height="150" CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">거리의 개발</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="http://amylz.com/venetia/img/etc/town.gif"></TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc">$com가$up상승했습니다.</FONT></TD>
    </TR>
    <TR>
      <TD colspan="2" align="center">
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value=돌아온다></form></TD>
	
    </TR>
  </TBODY>
</TABLE>
<center></center>
EOF

	&footer;
	exit;
}
1;
