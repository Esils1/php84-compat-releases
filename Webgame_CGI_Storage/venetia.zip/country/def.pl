sub def{
	&chara_open;
	&town_open;
	&con_open;
	if($town_con ne $mcon){&error("자국이 아닙니다.");}
	if($town_con eq 0){&error("그 거리에는 앉히지 않습니다.");}
	if($mcon eq 0){&error("무소속은 수비에 붙이지 않습니다.");}
	open(IN,"./data/def.cgi");
	@DEF = <IN>;
	close(IN);
	$hit=0;

	$date = time();
	$btime = $BTIME - $date + $mdate;
	if($btime>0){&error("앞으로 $btime 초 기다려 주세요.");}

	foreach(@DEF){
		($name,$id,$pos) =split(/<>/);
		if($id eq "$mid"){$hit=1;}
	}

	open(IN,"./logfile/battle/$in{'id'}.cgi");
	@BC_DATA = <IN>;
	close(IN);
	($mhpr,$mmpr,$mtim) =split(/<>/,$BC_DATA[0]);
	if($mhpr eq""){$mhpr=1;}
	if($mmpr eq""){$mmpr=1;}
	if($mhpr<0.25){&error("수비에 앉히는 상태가 아닙니다.");}

	if($hit){&error("이미 수비에 오르고 있습니다.");}
	else{
		unshift(@DEF,"$mname<>$mid<>$mpos<>\n");
		open(OUT,">./data/def.cgi") or &error('데이터를 쓸 수 없습니다.');
		print OUT @DEF;
		close(OUT);
	}
	&header;
print <<"EOF";
<TABLE border="0" width="80%" align=center height="150" CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="$FCOLOR"><FONT color="$FCOLOR2">거리의 수비</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="$FCOLOR2" width=20% align=center><img src="./img/etc/country.gif"></TD>
      <TD bgcolor="#330000"><FONT color="$FCOLOR2">$town_name의 수비에 올랐습니다.</FONT></TD>
    </TR>
    <TR>
    <TD colspan="2" align="center" bgcolor="ffffff">
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value=돌아온다></TD></form>
	</TD>
    </TR>
  </TBODY>
</TABLE>
<center></center>
EOF
	&chara_input;
	&footer;
	exit;
	

}
1;

