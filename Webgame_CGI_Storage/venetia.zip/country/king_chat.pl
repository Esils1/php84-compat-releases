sub king_chat {
	&chara_open;
	&header;
	&con_open;
	&town_open;
	&time_data;

	if($in{'mes_sel'} eq ""){&error("나라가 올바르게 선택되지 않았습니다.");}
	if($in{'mes'} eq ""){&error("메세지를 입력해 주세요.");}
	if(length($in{'mes'}) > 200){&error("100 문자 이내에서 입력해 주세요.");}
	if($con_king ne $mid && $y_chara[0] ne $mid && $y_chara[1] ne $mid && $y_chara[2] ne $mid){&error("직무자 이외 실행할 수 없습니다.");}
	
	if($con_king eq"$mid"){$smess="<font color=orange>[국왕]</font>$in{'mes'}";}
	else{
		for($k=0;$k<3;$k++){
			if($y_chara[$k] eq $mid){$smess="<font color=ff0099>[$y_name[$k]]</font>$in{'mes'}";}
		}
	}

	if($in{'mes_sel'} eq "0"){
		$MESFILE="./blog/chat/0.cgi";
		$name="<font color=$ELE_C[$con_ele]>$mname＠$con_name국</font>";
		$mes_max=10;$eid=1;
	}
	else{
		$MESFILE="./blog/chat/$in{'mes_sel'}.cgi";
		$name="<font color=$ELE_C[$con_ele]>$mname＠$con_name국</font>";
		$mes_max=10;$eid=2;
		if($in{'mes_sel'} ne"$con_id"){
			foreach(@CON_DATA){
				($con2_id,$con2_name,$con2_ele,$con2_gold,$con2_king,$con2_yaku,$con2_cou,$con2_mes,$con2_etc) =split(/<>/);
				if($con2_id eq $in{'mes_sel'}){$chit=1;last;}
			}
			if(!$chit){&error("지정된 나라가 올바르게 선택되지 않았습니다.");}
			$name="<font color=$ELE_C[$con_ele]>$mname＠$con_name국</font>으로부터<font color=$ELE_C[$con2_ele]>$con2_name국</font>에";
			open(IN,"./blog/chat/$con_id.cgi");
			@MMES_DATA = <IN>;
			close(IN);
			unshift(@MMES_DATA,"$mid<>$con_id<>$aite<>$mchara<>$name<>$smess<>$daytime<>\n");
			splice(@MMES_DATA,$mes_max);
			open(OUT,">./blog/chat/$con_id.cgi");
			print OUT @MMES_DATA;
			close(OUT);
		}
	}
	
	$aite=$in{'mes_sel'};

	open(IN,"$MESFILE");
	@MES_DATA = <IN>;
	close(IN);
	if($in{'mes'} eq"clear"){
		$smess="♪~";
		@N_MES=();
		foreach(@MES_DATA){
			($mes_id,$mes_aite,$mes_eid,$mes_chara,$mes_name,$mes_mes,$mes_daytime) =split(/<>/);
			if($mid eq "$mes_id"){next;}
			else{push(@N_MES,"$_");}
		}
		@MES_DATA=@N_MES;
	}
	unshift(@MES_DATA,"$mid<>$con_id<>$aite<>$mchara<>$name<>$smess<>$daytime<>\n");
	splice(@MES_DATA,$mes_max);

	open(OUT,">$MESFILE");
	print OUT @MES_DATA;
	close(OUT);

	print <<"EOF";
<TABLE border="0" width="80%" align=center bgcolor="#ffffff" height="120" CLASS=FC>
  <TBODY>
    <TR>
      <TD align="center" bgcolor="#993300"><FONT color="#ffffcc">송신 완료</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#330000" height=100><FONT color="#ffffcc">메세지를 송신했습니다.</FONT></TD>
    </TR>
    <TR>
      <TD align="center">
	<form action="./country.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=hidden name=mode value=king_conv>
	<INPUT type=submit CLASS=FC value=돌아온다></form></TD>
	
    </TR>
  </TBODY>
</TABLE>
<center></center>
EOF

	&footer;
	exit;
}
1;

