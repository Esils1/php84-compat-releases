sub town_arm {
	&chara_open;
	&status_print;
	&con_open;
	&town_open;
	if($con_id eq 0){&error("무소속은 이용할 수 없습니다.");}
	if($town_con ne $mcon){&error("자국의 거리가 아닙니다.");}
	if($mid ne"$con_king" && $y_chara[0] ne $mid && $y_chara[1] ne $mid && $y_chara[2] ne $mid){&error("왕 또는 직무자 이외 실행할 수 없습니다.");}

	$list="<select name=eqp>";
	$list.="<option value=t_arm>무기";
	$list.="<option value=t_pro>방어구";
	$list.="<option value=t_acc>악세사리";
	$list.="</select>";

	##속성 선택
	$j=0;
	$elelist="<select name=ele>";
	$elelist.="<option value=\"\">-속성의 선택-";
	foreach(@ELE){
		$elelist.="<option value=$j>$ELE[$j]";
		$j++;
	}
	$elelist.="</select>";

	##종류 2 선택
	$tlist="<select name=atype>";
	foreach(@ARM){
		$tlist.="<option value=$_>$_";
	}
	$tlist.="</select>";

	&header;
	
	print <<"EOF";
<TABLE border="0" width="80%" align=center bgcolor="#ffffff" height="150" CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">무기·방어구의 개발</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="http://amylz.com/venetia/img/etc/buki.gif"></TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc">무기 또는 방어구의 개발을 실시합니다.<BR>개발하는 것을 선택해, 금액을 입력해 주세요.<BR>나라, 거리에 맞은 속성을 선택하는 것으로, 보다 좋은 것을 기대할 수 있습니다.<BR>상, 특산품은 1개의 거리에 3개까지 작성가\능\입니다.<BR>현재의 나라의 자금：$con_gold Gold</FONT></TD>
    </TR>
    <TR>
      <TD colspan="2" align="center">
	<form action="./country.cgi" method="post">
	종류：$list 
	종류 2(무기의 경우 선택)：$tlist <BR>
	이름：<INPUT type=text size=15 name=name>
	속성：$elelist<BR>
	위력：<INPUT type=text size=5 name=dmg>0000Gold
	무게：<INPUT type=text size=5 name=wei>0000Gold<BR>
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=hidden name=mode value=town_arm2>
	<INPUT type=submit value=개발 CLASS=FC></form>
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value=돌아온다></form></TD>
	
    </TR>
  </TBODY>
</TABLE>
<center></center>
EOF
	&footer;
	exit;
}
1;

