sub king_com {
	&chara_open;
	&status_print;
	&con_open;

	if($con_id eq 0){&error("무소속은 실행할 수 없습니다.");}
	$dir="./logfile/chara";
	opendir(dirlist,"$dir");
	$i=0;
	
	for($i=0;$i<3;$i++){
		$list[$i].="후보자：<select name=cand>";
		if($y_name[$i]){
			open(IN,"./logfile/chara/$y_chara[$i].cgi");
			@E_DATA = <IN>;
			close(IN);
			($eid,$epass,$ename,$eurl,$echara,$esex,$ehp,$emaxhp,$emp,$emaxmp,$eele,$estr,$evit,$eint,$efai,$edex,$eagi,$emax,$ecom,$egold,$ebank,$eex,$ecex,$eunit,$econ,$earm,$epro,$eacc,$etec,$esta,$epos,$emes,$ehost,$edate,$esyo,$eclass,$etotal,$ekati,$etype,$eoya,$esk,$eflg,$eflg2,$eflg3,$eflg4,$eflg5) = split(/<>/,$E_DATA[0]);
			if($y_chara[$i] eq "$eid"){
				$list[$i].="<option value=$eid selected>$ename";
			}
		}
	}
	while($file = readdir(dirlist)){
		if($file =~ /\.cgi/i){
			$datames = "검색：$dir/$file<br>\n";
			if(!open(cha,"$dir/$file")){
				&error("$dir/$file가 발견되지 않습니다.<br>\n");
			}
			@cha = <cha>;
			close(cha);
			($rid,$rpass,$rname,$rurl,$rchara,$rsex,$rhp,$rmaxhp,$rmp,$rmaxmp,$rele,$rstr,$rvit,$rint,$rfai,$rdex,$ragi,$rmax,$rcom,$rgold,$rbank,$rex,$rtotalex,$rjp,$rabp,$rcex,$runit,$rcon,$rarm,$rpro,$racc,$rtec,$rsta,$rpos,$rmes,$rhost,$rdate,$rsyo,$rclass,$rtotal,$rkati,$rtype) = split(/<>/,$cha[0]);
			if($con_id eq $rcon && $rcex>500 && $mid ne"$rid"){
				$ylist.="<option value=$rid>$rname";
			}
		}
		$mn++;
	}
	closedir(dirlist);

	for($i=0;$i<3;$i++){
		$ylist[$i].="</select><BR>";
		$ylist[$i].="직함<input type=text size=10 name=yname value=$y_name[$i]><BR>";

		$list[$i].="$ylist $ylist[$i]<input type=hidden name=no value=$i>";
	}
	&header;
	
	print <<"EOF";
<TABLE border="0" width="90%" align=center bgcolor="#ffffff" height="150" CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">직무 임명</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="./img/etc/country2.gif"></TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc">직무를 최대 3명까지 임명할 수 있습니다.<BR>다만 후보자는 공헌도가 500이상 어떤 사람만으로, 직무의 임명은 왕만이 가\능\입니다.<BR>임명하고 싶은 직무, 상대를 결정해 주세요.</FONT></TD>
    </TR>
    <TR>
      <TD colspan="2" align="center">
	<table class=TC width=80%>
	<tr><td colspan=3 align=center><font color=$FCOLOR2>임명</font></td></tr>
	<tr>
	<td bgcolor=$FCOLOR2 align=center><font color=$FCOLOR>직무 1</font></td>
	<td bgcolor=$FCOLOR2 align=center><font color=$FCOLOR>직무 2</font></td>
	<td bgcolor=$FCOLOR2 align=center><font color=$FCOLOR>직무 3</font></td>
	</tr>
	<tr><td bgcolor=$FCOLOR2 align=center>
	<form action="./country.cgi" method="post">
	$list[0]
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=hidden name=mode value=king_com2>
	<INPUT type=submit value=결정 CLASS=FC>
	</td></form>
	<td bgcolor=$FCOLOR2 align=center>
	<form action="./country.cgi" method="post">
	$list[1]
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=hidden name=mode value=king_com2>
	<INPUT type=submit value=결정 CLASS=FC>
	</td></form>
	<td bgcolor=$FCOLOR2 align=center>
	<form action="./country.cgi" method="post">
	$list[2]
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=hidden name=mode value=king_com2>
	<INPUT type=submit value=결정 CLASS=FC>
	</td></form></tr>
	</table>
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value=돌아온다></form>
      </TD>
    </TR>
  </TBODY>
</TABLE>
<center>$STPR</center>
EOF

	&footer;
	exit;
}
1;

