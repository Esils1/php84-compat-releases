sub set_about {
	&chara_open;
	&status_print;
	&con_open;
	&town_open;

	if($con_id eq 0){&error("무소속은 이용할 수 없습니다.");}
	if($town_con ne $mcon){&error("자국의 거리가 아닙니다.");}
	if($mid ne"$con_king" && $y_chara[0] ne $mid && $y_chara[1] ne $mid && $y_chara[2] ne $mid && $mid ne "chanje"){&error("왕 또는 직무자 이외 실행할 수 없습니다.");}

	&header;
	
	print <<"EOF";
<TABLE border="0" width="80%" align=center bgcolor="#ffffff" height="150" CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">홍보문 변경</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="http://amylz.com/venetia/img/etc/country2.gif"></TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc">홍보문을 변경합니다. 80자 이내로 자신의 국가를 홍보할 홍보문을 작성해 주세요.<br>홍보문 뒤의 (닉네임님으로부터) 는 자동으로 붙으니 수정하는 경우엔 삭제해 주시기 바랍니다.</FONT></TD>
    </TR>
    <TR>
      <TD colspan="2" align="center">
	<form action="./country.cgi" method="post">
	<INPUT type=text name=what size=80 maxlength=80 value="$con_hongbo"><BR>
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=hidden name=mode value=set_about2>
	<INPUT type=submit value="홍보문 변경" CLASS=FC></form>
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value=그만둔다></form></TD>
	
    </TR>
  </TBODY>
</TABLE>
<center></center>
EOF

	&footer;
	exit;
}
1;

