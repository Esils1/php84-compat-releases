sub king_com2 {
	&chara_open;
	&status_print;
	&town_open;
	&con_open;

	if($mid ne"$con_king"){&error("왕 이외 실행할 수 없습니다.");}
	if($con_id eq 0){&error("무소속은 실행할 수 없습니다.");}
	if($in{'yname'} eq ""){&error("직함이 입력되지 않았습니다.");}
	if(length($in{'yname'}) < 2||length($in{'yname'}) > 8){&error("직함은 2 문자 이상 4 문자 이내에서 입력해 주세요.");}
	if($in{'cand'} eq ""){&error("후보자가 올바르게 선택되지 않았습니다.");}
	if($in{'no'} eq ""){&error("직무가 불명합니다.");}
	
	$enemy_id=$in{'cand'};
	&enemy_open;

	for($i=0;$i<3;$i++){
		if($y_chara[$i] eq $in{'cand'} && $in{'no'} ne $i){
			&error("복수의 직무에는 앉히지 않습니다.");
		}
	}
	$y_name[$in{'no'}]="$in{'yname'}";
	$y_chara[$in{'no'}]="$in{'cand'}";
	$con_yaku="$y_name[0],$y_name[1],$y_name[2],$y_chara[0],$y_chara[1],$y_chara[2]";
	&con_input;
	&eh_log("$con_name국의<font color=red>$in{'yname'}</font>에 임명된다.","$con_name");

	&header;
	
	print <<"EOF";
<TABLE border="0" width="80%" align=center bgcolor="#ffffff" height="150" CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">직무 임명</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="./img/etc/inn.gif"></TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc">$ename를<font color=red>$in{'yname'}</font>에 임명했습니다.</FONT></TD>
    </TR>
    <TR>
      <TD colspan="2" align="center">
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value=돌아온다></form></TD>
	
    </TR>
  </TBODY>
</TABLE>
<center></center>
EOF

	&footer;
	exit;
}
1;

