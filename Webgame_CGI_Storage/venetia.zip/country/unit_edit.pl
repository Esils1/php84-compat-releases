sub unit_edit {
	&chara_open;
	&con_open;
	&town_open;
	&status_print;
	open(IN,"./data/unit.cgi");
	@UNIT_DATA = <IN>;
	close(IN);

	if($in{'unit'} eq ""){&error("부대명이 입력되고 있지 않습니다.");}
	if($in{'com'} eq ""){&error("코멘트가 입력되고 있지 않습니다.");}
	if($mcex<100){&error("명성이  100필요합니다.");}
	if(length($in{'unit'}) < 4||length($in{'unit'}) > 20){&error("부대명은 2 문자 이상 10 문자 이내에서 입력해 주세요.");}
	if(length($in{'com'}) > 40){&error("코멘트는 20 문자 이내에서 입력해 주세요.");}
	foreach(@UNIT_DATA){
		($uid,$lchara,$lname,$uname,$bid,$bname,$bmes,$bflg) =split(/<>/);
		if($bid eq $mid){&error("이미 부대에 소속해 있습니다.새롭게 부대를 작성하려면  현재 소속해 있는 부대로부터 이탈해 주세요.");}
	}
	if($in{'unit'} eq $uname){&error("같은 부대명이 벌써 있습니다.");}

	$munit = $mid;
	unshift(@UNIT_DATA,"$mid<>$mchara<>$mname<>$in{'unit'}<>$mid<>$mname<>$in{'com'}<>$mcon<>\n");
	open(OUT,">./data/unit.cgi") or &error('데이터를 쓸 수 없습니다.');
	print OUT @UNIT_DATA;
	close(OUT);

	&chara_input;
	&header;
	
	print <<"EOF";
<TABLE border="0" width="80%" align=center bgcolor="#ffffff" height="150" CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">신규 작성</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="http://amylz.com/venetia/img/etc/country2.gif"></TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc">부대：$in{'unit'}를 작성했습니다.<BR></FONT></TD>
    </TR>
    <TR>
      <TD colspan="2" align="center" bgcolor="#ffffcc">
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value=돌아온다></form></TD>
    </TR>
  </TBODY>
</TABLE>
<center></center>
EOF
	&footer;
	exit;
}
1;

