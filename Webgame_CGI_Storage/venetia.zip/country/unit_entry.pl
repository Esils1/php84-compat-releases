sub unit_entry {
	&chara_open;
	&con_open;
	&town_open;
	&status_print;
	&time_data;

	open(IN,"./data/unit.cgi");
	@UNIT_DATA = <IN>;
	close(IN);

	if($in{'no'} eq ""){&error("올바르게 선택되고 있지 않습니다.");}
	foreach(@UNIT_DATA){
		($uid,$lchara,$lname,$uname,$bid,$bname,$bmes,$bflg) =split(/<>/);
		if($bid eq $mid){&error("이미 부대에 소속해 있습니다.");}
		if($uid eq $in{'no'}){
			$unit = $uname;
			$unit_id = $uid;
			$l_chara = $lchara;
			$l_name = $lname;
			$hit = 1;
		}
	}
	if($hit){
		$munit = $unit_id;
		unshift(@UNIT_DATA,"$unit_id<>$l_chara<>$l_name<>$unit<>$mid<>$mname<><><>\n");
		open(OUT,">./data/unit.cgi") or &error('데이터를 쓸 수 없습니다.');
		print OUT @UNIT_DATA;
		close(OUT);
	}else{
		&error("올바르게 선택되고 있지 않습니다.");
	}

	open(IN,"./data/unit.cgi");
	@UNIT_DATA = <IN>;
	close(IN);
	$MESFILE="./meslog/unit/$munit.cgi";
	$mes_max=$MES2;$eid=4;

	open(IN,"$MESFILE");
	@MES_DATA = <IN>;
	close(IN);

	$smess="<font color=red>$mname가 입대했습니다.</font>";
	unshift(@MES_DATA,"$mid<>4<>$aite<>$mchara<>$name<>$smess<>$daytime<>\n");
	splice(@MES_DATA,$mes_max);

	open(OUT,">$MESFILE");
	print OUT @MES_DATA;
	close(OUT);

	&header;
	&chara_input;
	print <<"EOF";
<TABLE border="0" width="80%" align=center bgcolor="#ffffff" height="150" CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">입대</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="http://amylz.com/venetia/img/etc/country2.gif"></TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc">$unit에 입대했습니다.<BR></FONT></TD>
    </TR>
    <TR>
      <TD colspan="2" align="center" bgcolor="#ffffcc">
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value=돌아온다></form></TD>
    </TR>
  </TBODY>
</TABLE>
<center></center>
EOF
	&footer;
	exit;
}
1;

