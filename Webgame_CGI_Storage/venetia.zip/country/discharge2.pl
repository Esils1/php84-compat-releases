sub discharge2 {
	&chara_open;
	&status_print;
	&town_open;
	&con_open;

	if($mid ne"$con_king" && $y_chara[0] ne $mid && $y_chara[1] ne $mid && $y_chara[2] ne $mid){&error("왕 또는 직무자 이외 실행할 수 없습니다.");}
	if($con_id eq 0){&error("무소속은 실행할 수 없습니다.");}
	
	if($in{'cand'} eq ""){&error("대상자가 올바르게 선택되지 않았습니다.");}
	
	$enemy_id=$in{'cand'};
	&enemy_open;

	for($i=0;$i<3;$i++){
		if($y_chara[$i] eq $in{'cand'}){
			&error("대상자가 직무에 붙어 있는 경우, 해제를 실시하고 나서 실행해 주세요.");
		}
	}
	if($mcex < 100){&error("명성이 충분하지 않습니다.");}
	$mcex-=100;
	$ecex=0;
	$econ=0;

	if($eunit){
		open(IN,"./data/unit.cgi");
		@UNIT_DATA = <IN>;
		close(IN);
		@NUNIT=();

		foreach(@UNIT_DATA){
			($uid,$lchara,$lname,$uname,$bid,$bname,$bmes,$bcon) =split(/<>/);
			if($bid eq $eid){
				if($eid eq $uid){$hit=1;}
				else{$hit=2;}
			}
			else{push(@NUNIT,"$_");}
		}
		if($hit eq 1){
			foreach(@NUNIT){
				($u2id,$l2chara,$l2name,$u2name,$b2id,$b2name,$b2mes,$b2con) =split(/<>/);
				if($u2id eq $eid){
					$enemy_id="$b2id";
					&enemy_open2;
					$e2unit="";
					if($e2id){
						&enemy_input2;
					}
				}
				else{push(@N2UNIT,"$_");}
			}
			open(OUT,">./data/unit.cgi") or &error('데이터를 쓸 수 없습니다.');
			print OUT @N2UNIT;
			close(OUT);
		}elsif($hit eq 2){
			open(OUT,">./data/unit.cgi") or &error('데이터를 쓸 수 없습니다.');
			print OUT @NUNIT;
			close(OUT);
		}
		$eunit="";
	}

	&eh_log("$con_name국으로부터<font color=red>해고</font>된다.","$con_name");
	&maplog("<font color=red>[해고]</font><font color=$ELE_BG[$con_ele]>$con_name국</font>의$mname는<font color=red>$ename</font>를 해고했습니다.");

	&time_data;
	open(IN,"./logfile/out/$eid.cgi");
	@data = <IN>;
	close(IN);

	unshift(@data, "$con_id<>$daytime<>\n");
	open (OUT, "> ./logfile/out/$eid.cgi");
	print OUT @data;
	close (OUT);

	&enemy_input;
	&chara_input;

	&header;
	
	print <<"EOF";
<TABLE border="0" width="80%" align=center bgcolor="#ffffff" height="150" CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">해고</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="./img/etc/inn.gif"></TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc">$ename를<font color=red>해고</font>했습니다.</FONT></TD>
    </TR>
    <TR>
      <TD colspan="2" align="center">
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value=돌아온다></form></TD>
	
    </TR>
  </TBODY>
</TABLE>
<center></center>
EOF

	&footer;
	exit;
}


sub enemy_open2{
	open(IN,"./logfile/chara/$enemy_id.cgi");
	@E_DATA = <IN>;
	close(IN);
	($e2id,$e2pass,$e2name,$e2url,$e2chara,$e2sex,$e2hp,$e2maxhp,$e2mp,$e2maxmp,$e2ele,$e2str,$e2vit,$e2int,$e2fai,$e2dex,$e2agi,$e2max,$e2com,$e2gold,$e2bank,$e2ex,$e2totalex,$e2jp,$e2abp,$e2cex,$e2unit,$e2con,$e2arm,$e2pro,$e2acc,$e2tec,$e2sta,$e2pos,$e2mes,$e2host,$e2date,$e2syo,$e2class,$e2total,$e2kati,$e2type,$e2oya,$e2sk,$e2flg,$e2flg2,$e2flg3,$e2flg4,$e2flg5) = split(/<>/,$E_DATA[0]);
	$e2lv = int($e2ex/100)+1;
}

sub enemy_input2 {
	$date = time();
	@NE_DATA=();
	unshift(@NE_DATA,"$e2id<>$e2pass<>$e2name<>$e2url<>$e2chara<>$e2sex<>$e2hp<>$e2maxhp<>$e2mp<>$e2maxmp<>$e2ele<>$e2str<>$e2vit<>$e2int<>$e2fai<>$e2dex<>$e2agi<>$e2max<>$e2com<>$e2gold<>$e2bank<>$e2ex<>$e2totalex<>$e2jp<>$e2abp<>$e2cex<>$e2unit<>$e2con<>$e2arm<>$e2pro<>$e2acc<>$e2tec<>$e2sta<>$e2pos<>$e2mes<>$host<>$date<>$e2date2<>$e2class<>$e2total<>$e2kati<>$e2type<>$e2oya<>$e2sk<>$e2flg<>$e2flg2<>$e2flg3<>$e2flg4<>$e2flg5<>\n");
	open(OUT,">./logfile/chara/$enemy_id.cgi") or &error('데이터를 쓸 수 없습니다.');
	print OUT @NE_DATA;
	close(OUT);
}
1;

