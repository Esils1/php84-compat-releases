sub all_rule {
	&chara_open;
	&con_open;
	&town_open;
	&header;
	&status_print;
	open(IN,"./blog/rule/0.cgi");
	@RULE_DATA = <IN>;
	close(IN);

	$no=0;
	$rule="<table border=0 bgcolor=000000 width=90%>";
	$rule.="<tr><td colspan=2 width=100% bgcolor=$ELE_BG[0] align=center><font color=$ELE_C[0]>전국 룰</font></td></tr>";
	foreach(@RULE_DATA){
		($lid,$lname,$lchara,$lcon,$lmes,$letc,$lhost,$ldaytime) =split(/<>/);
		$rule.="<tr><td width=1% bgcolor=$ELE_BG[$lcon]><input type=radio name=no value=$no></td><td align=left bgcolor=$ELE_C[$lcon] width=85% height=50><font color=000000>$lmes<BR>($ldaytime $letc $lname로부터</b></font></td></tr>";
		$no++;
	}
	$rule.="</table>";

	print <<"EOF";
<TABLE border="0" width="80%" align=center bgcolor="#ffffff" height="150" CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">전국 국법</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="./img/etc/country2.gif"></TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc">전국 공통의 룰입니다.<BR>모든 플레이어에 있어서 매우 중요한 정보이므로, 이하의 룰을 잘 읽어, 룰을 지키도록(듯이) 유의합시다.<BR></FONT></TD>
    </TR>
    <TR>
      <TD colspan="2" align="center">
	<form action="./country.cgi" method="POST">
	$rule
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=hidden name=mode value=rule_delete>
	<INPUT type=hidden name=type value=2>
	<INPUT type=submit CLASS=MFC value="룰의 삭제"></form>
	<form action="./country.cgi" method="post">

	<img src="./img/chara/$mchara.gif">
	<TEXTAREA name="message" cols="40" rows="4"></TEXTAREA><BR>
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=hidden name=mode value=rule_write>
	<INPUT type=hidden name=type value=2>
	<INPUT type=submit value="룰의 추가(국왕만)" CLASS=MFC></form>

	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value=돌아온다></form></TD>
	
    </TR>
  </TBODY>
</TABLE>
<center></center>
EOF
	&footer;
	exit;
}
1;

