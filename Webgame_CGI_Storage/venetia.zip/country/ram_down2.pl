sub ram_down2 {
	&chara_open;
	&status_print;
	&town_open;
	&con_open;
	if($con_id eq 0){&error("무소속은 이용할 수 없습니다.");}
	if($town_con ne $mcon){&error("자국의 거리가 아닙니다.");}
	if(!$hit){&error("나라 데이터에 이상이 있습니다.");}
	if($mcex<500){&error("명성이  500필요합니다.");}
	if($in{'gold'} eq ""){&error("금액이 입력되지 않았습니다.");}
	if($in{'gold'} =~ m/[^0-9]/){&error("금액에 숫자 이외의 문자가 포함되어 있습니다.");}
	if($in{'gold'} <0){&error("성실하게 입력해 주세요.");}
	if($in{'gold'} >300){&error("최대 300만 Gold까지입니다.");}

	$date = time();
	$ktime = $KTIME - $date + $mdate2;
	if($ktime>0){&error("다음의 계략까지 $ktime 초 기다려 주세요.");}


	if($in{'tid'} eq ""){&error("계략처가 올바르게 선택되지 않았습니다.");}
	foreach(@TOWN_DATA){
		($town2_id,$town2_name,$town2_con,$town2_ele,$town2_gold,$town2_arm,$town2_pro,$town2_acc,$town2_ind,$town2_tr,$town2_s,$town2_x,$town2_y,$town2_etc) =split(/<>/);
		if($in{'tid'} eq $town2_id){$t2hit=1;last;}
		$tx++;
	}
	if($town2_etc eq""||!$t2hit){&error("거리가 올바르게 선택되지 않았습니다.");}
	if($town2_id eq "0"||$town2_con eq 0||$town2_con eq $town_con){&error("그 거리에는 계략을 실시할 수 없습니다.");}
	
	($town2_hp,$town2_max,$town2_str,$town2_def,$town2_dex,$town2_flg) =split(/,/,$town2_etc);

	
	$gold=$in{'gold'}*10000;
	$con_gold-=$gold;
	if($con_gold<0){&error("국고가 충분하지 않습니다.");}
	$up=int($in{'gold'}*((100+$mint)/600));
	
	if($in{'pow'} eq"t_str"){
		$com="공격력";
		$town2_str-=$up;
		if($town2_str<400){$town2_str=400;}
	}elsif($in{'pow'} eq"t_def"){
		$com="내구력";
		$town2_def-=$up;
		if($town2_def<400){$town2_def=400;}
	}else{&error("부정한 액세스입니다.");}

	$town2_etc="$town2_hp,$town2_max,$town2_str,$town2_def,$town2_dex,$town2_flg";
	if($town2_id ne ""){
		@N_TOWN=();
		foreach(@TOWN_DATA){
			($town4_id,$town4_name,$town4_con,$town4_ele,$town4_gold,$town4_arm,$town4_pro,$town4_acc,$town4_ind,$town4_tr,$town4_s,$town4_x,$town4_y,$town4_etc) =split(/<>/);
			if("$town2_id" eq "$town4_id"){
				push(@N_TOWN,"$town2_id<>$town2_name<>$town2_con<>$town2_ele<>$town2_gold<>$town2_arm<>$town2_pro<>$town2_acc<>$town2_ind<>$town2_tr<>$town2_s<>$town2_x<>$town2_y<>$town2_etc<>\n");
			}else{
				push(@N_TOWN,"$_");
			}
		}
		open(OUT,">./data/towndata.cgi") or &error('타운 데이터를 쓸 수 없습니다.');
		print OUT @N_TOWN;
		close(OUT);
	}
	else{&error("타운 데이터에 이상이 있습니다.");}
	$mdate2=time();

	&con_input;
	&chara_input;

	&header;
	
	&maplog("<font color=red>[계략]</font>$mname는$town2_name의$com를<font color=red>$up</font>내렸습니다.");
	print <<"EOF";
<TABLE border="0" width="80%" align=center bgcolor="#ffffff" height="150" CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">계략</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="http://amylz.com/venetia/img/etc/siro.gif"></TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc">$com를$up 내렸습니다.</FONT></TD>
    </TR>
    <TR>
      <TD colspan="2" align="center">
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value=돌아온다></form></TD>
	
    </TR>
  </TBODY>
</TABLE>
<center></center>
EOF

	&footer;
	exit;
}
1;
