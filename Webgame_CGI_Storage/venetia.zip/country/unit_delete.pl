sub unit_delete {
	&chara_open;
	&con_open;
	&town_open;
	&status_print;
	open(IN,"./data/unit.cgi");
	@UNIT_DATA = <IN>;
	close(IN);
	@NUNIT=();
	@N2UNIT=();
	foreach(@UNIT_DATA){
		($uid,$lchara,$lname,$uname,$bid,$bname,$bmes,$bcon) =split(/<>/);
		if($bid eq $mid){
			if($mid eq $uid){$hit=1;}
			else{$hit=2;}
		}
		else{push(@NUNIT,"$_");}
	}
	if($hit eq 1){
		foreach(@NUNIT){
			($u2id,$l2chara,$l2name,$u2name,$b2id,$b2name,$b2mes,$b2con) =split(/<>/);
			if($u2id eq $mid){
				$enemy_id="$b2id";
				&enemy_open2;
				$eunit="";
				if($eid){
					&enemy_input2;
				}
			}
			else{push(@N2UNIT,"$_");}
		}
		open(OUT,">./data/unit.cgi") or &error('데이터를 쓸 수 없습니다.');
		print OUT @N2UNIT;
		close(OUT);
		$mess="부대를 해산했습니다.";
	}elsif($hit eq 2){
		open(OUT,">./data/unit.cgi") or &error('데이터를 쓸 수 없습니다.');
		print OUT @NUNIT;
		close(OUT);
		$mess="부대로부터 탈퇴했습니다.";
	}else{
		&error("이미 탈퇴하고 있습니다.");
	}
	$munit="";
	&chara_input;

	&header;
	
	print <<"EOF";
<TABLE border="0" width="80%" align=center bgcolor="#ffffff" height="150" CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">부대의 이탈</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="http://amylz.com/venetia/img/etc/country2.gif"></TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc">$mess<BR></FONT></TD>
    </TR>
    <TR>
      <TD colspan="2" align="center" bgcolor="#ffffcc">
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value=돌아온다></form></TD>
    </TR>
  </TBODY>
</TABLE>
<center></center>
EOF
	&footer;
	exit;
}

1;

