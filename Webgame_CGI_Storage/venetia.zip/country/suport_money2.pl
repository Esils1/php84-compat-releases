sub suport_money2 {
	&chara_open;
	&con_open;

	if($con_id eq 0){&error("무소속은 이용할 수 없습니다.");}
	if(!$hit){&error("나라 데이터에 이상이 있습니다.");}
	if($in{'gold'} eq ""){&error("금액이 입력되지 않았습니다.");}
	if($in{'gold'} =~ m/[^0-9]/){&error("금액에 숫자 이외의 문자가 포함되어 있습니다.");}
	if($in{'gold'} <0){&error("성실하게 입력해 주세요.");}
	
	$date = time();
	$btime = $BTIME - $date + $mdate;
	
	$gold=$in{'gold'}*10000;
	$con_gold+=$gold;
	$mgold-=$gold;
	if($mgold<0){&error("소지금이 충분하지 않습니다.");}
	$mcex+=$in{'gold'};
	&maplog("<font color=orange>[원조]</font>$mname는$con_name국에<font color=red>$gold</font>Gold 원조했습니다.");
	&con_input;
	&chara_input;

	&header;
	
	print <<"EOF";
<TABLE border="0" width="80%" align=center bgcolor="#ffffff" height="150" CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">자금의 원조</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="http://amylz.com/venetia/img/etc/pub.gif"></TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc">$con_name에<font color=red>$gold</font>Gold 원조했습니다.</FONT></TD>
    </TR>
    <TR>
      <TD colspan="2" align="center">
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value=돌아온다></form></TD>
	
    </TR>
  </TBODY>
</TABLE>
<center></center>
EOF

	&footer;
	exit;
}
1;
