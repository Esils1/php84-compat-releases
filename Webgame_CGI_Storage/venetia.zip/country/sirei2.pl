sub sirei2 {
	&chara_open;
	&status_print;
	&town_open;
	&con_open;
	$conkazu="@CON_DATA";

	if($mcex<500){&error("사령의 변경에는 명성이 500이상 필요합니다.");}
	if($con_id eq 0){&error("무소속은 실행할 수 없습니다.");}
	if($in{'mes'} eq ""){&error("메세지가 입력되지 않았습니다.");}
	if(length($in{'mes'}) < 4||length($in{'mes'}) > 200){&error("국명은 2 문자 이상 100 문자 이내에서 입력해 주세요.");}
	if ($in{'mes'} =~ /<>/){&error("사용할 수 없는 문자가 포함되어 있습니다.");}
	$con_mes="$in{'mes'} ($mname로부터)";
	&con_input;
	&header;
	
	print <<"EOF";
<TABLE border="0" width="80%" align=center bgcolor="#ffffff" height="150" CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">지령의 변경</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="http://amylz.com/venetia/img/etc/country2.gif"></TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc">사령을 변경했습니다.</FONT></TD>
    </TR>
    <TR>
      <TD colspan="2" align="center">
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value=돌아온다></form></TD>
	
    </TR>
  </TBODY>
</TABLE>
<center></center>
EOF

	&footer;
	exit;
}
1;

