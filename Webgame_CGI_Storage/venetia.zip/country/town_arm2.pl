sub town_arm2 {
	&chara_open;
	&status_print;
	&town_open;
	&con_open;
	if($con_id eq 0){&error("무소속은 이용할 수 없습니다.");}
	if($town_con ne $mcon){&error("자국의 거리가 아닙니다.");}
	if($mid ne"$con_king" && $y_chara[0] ne $mid && $y_chara[1] ne $mid && $y_chara[2] ne $mid){&error("왕 또는 직무자 이외 실행할 수 없습니다.");}
	if($mcex<500){&error("명성이  500필요합니다.");}
	if(!$hit){&error("나라 데이터에 이상이 있습니다.");}
	if($in{'name'} eq""){&error("이름이 입력되지 않았습니다.");}
	if($in{'dmg'} eq ""||$in{'wei'} eq ""){&error("금액이 입력되지 않았습니다.");}
	if($in{'dmg'} =~ m/[^0-9]/||$in{'wei'} =~ m/[^0-9]/){&error("금액에 숫자 이외의 문자가 포함되어 있습니다.");}
	if($in{'dmg'} <50){&error("금액이 너무 적습니다.");}
	if($in{'ele'} eq ""){&error("속성이 올바르게 선택되지 않았습니다.");}
	
	$dmg=$in{'dmg'};
	$wei=$in{'wei'};
	$gold=($dmg+$wei)*10000;
	$up=0;
	if($in{'ele'} eq $town_ele){$up+=0.2;}
	if($in{'ele'} eq $con_id){$up+=0.2;}
	$dmg=int($dmg*(1+$up));
	$wei=int($wei*(1+$up));

	open(IN,"./data/carm.cgi");
	@CARM = <IN>;
	close(IN);
	$carmno=@CARM;
	if($carmno>50){&error("그 이상 만들 수 없습니다.");}

	foreach(@CARM){
		($carm_t,$carm_name,$carm_val,$carm_dmg,$carm_wei,$carm_ele,$carm_hit,$carm_cl,$carm_type,$carm_sta,$carm_pos) =split(/<>/);
		$arm_val=int($arm_val*(1-$val_off/100));
		if($town_id eq $carm_pos){
			$no++;
		}
	}
	if($no>2){&error("특산품의 개발은 1개의 거리에 3개까지입니다.");}

	$con_gold-=$gold;
	if($con_gold<0){&error("국고가 충분하지 않습니다.");}
	if($in{'eqp'} eq"t_arm"){
		$armno=0;
		$atype=$in{'atype'};
		$com="무기";
	}elsif($in{'eqp'} eq"t_pro"){
		$armno=1;
		$atype="방어구";
		$com="방어구";
	}elsif($in{'eqp'} eq"t_acc"){
		$armno=2;
		$atype="악세사리";
		$com="악세사리";
	}
		
	if($in{'eqp'} eq"t_arm"||$in{'eqp'} eq"t_pro"){
		#위력 결정
		$armdmg=int(sqrt($dmg)) + int(rand(sqrt($dmg)*4)) - int(rand(sqrt($wei)/2));
		if($armdmg>250){$armdmg=250;}
		$armdmg+=int(rand($up*50+5));
		$drand=int(rand(10));
		if($armdmg<10+$drand){$armdmg=10+$drand;}

		#무게 결정
		if($armdmg<200){
			$armwei=$armdmg - int(sqrt($wei)*2) - int(rand(sqrt($wei)*5));
			if($armwei<5){$armwei=5;}
			$armwei-=int(rand($up*30+5));
			if($armwei<5){$armwei=5-int(rand(10));}

		}else{
			$armwei=$armdmg - int(sqrt($wei)) - int(rand(sqrt($wei)*3));
			if($armwei<15){$armwei=15;}
			$armwei-=int(rand($up*30+5));
			if($armwei<15){$armwei=15-int(rand(10));}
		}
		
		#가격
		$sa=$armdmg-$armwei;
		if($sa<1){$sa=1;}
		$armval=$armdmg*$armdmg*250+$sa*$sa*500;

		if($armdmg<30){$armval=int($armval/10);}
		elsif($armdmg<50){$armval=int($armval/5);}
		elsif($armdmg<100){$armval=int($armval/3);}
		elsif($armdmg<150){$armval=int($armval/2);}
		elsif($armdmg<200){$armval=int($armval/1.5);}
	
	}elsif($in{'eqp'} eq"t_acc"){
		#위력 결정
		$armdmg=int(sqrt($dmg)/3) + int(rand(sqrt($dmg))) - int(rand(sqrt($wei)/5));
		if($armdmg>55+$up*50){$armdmg=55+$up*50;}
		$armdmg+=int(rand($up*20+3));

		#무게 결정
		if($armdmg<50){
			$armwei=$armdmg - int(sqrt($wei)) - int(rand(sqrt($wei)*2));
			$armwei-=int(rand($up*10+2));
			if($armwei<0){$armwei=0-int(rand(10));}
		}else{
			$armwei=$armdmg - int(sqrt($wei)/2) - int(rand(sqrt($wei)));
			$armwei-=int(rand($up*10+2));
			if($armwei<5){$armwei=5-int(rand(5));}
		}
		
		#가격
		$sa=$armdmg-$armwei;
		if($sa<1){$sa=1;}
		$armval=$armdmg*$armdmg*2000+$sa*$sa*4000;
		if($armdmg<20){$armval=int($armval/10);}
		elsif($armdmg<30){$armval=int($armval/5);}
		elsif($armdmg<40){$armval=int($armval/3);}
		elsif($armdmg<50){$armval=int($armval/2);}
		elsif($armdmg<60){$armval=int($armval/1.5);}
	}else{&error("부정한 액세스입니다.");}

	$armval=int($armval*0.8) +int(rand($armval*0.4));
	if($armval<1000){$armval=1000;}

	$armhit=75 + int(rand(10));
	$armcl=9 + int(rand(2));
	if($armno eq 0){
		if($atype eq"도끼"){$armdmg=int($armdmg*1.15) ;$armwei+=20;}
		elsif($atype eq"지팡이"){$armdmg=int($armdmg*0.9) ;$armwei-=5;}
		elsif($atype eq"활"){$armdmg=int($armdmg*1.1) ;$armwei+=12;}
		elsif($atype eq"주먹"){$armdmg=int($armdmg*0.8) ;$armwei-=10;}
		elsif($atype eq"나이프"){$armdmg=int($armdmg*0.95) ;$armwei-=3;}
		
	}
	push(@CARM,"$armno<>$in{'name'}<>$armval<>$armdmg<>$armwei<>$in{'ele'}<>$armhit<>$armcl<>0<>$atype<>$town_id<>$con_id<>\n");
	open(OUT,">./data/carm.cgi");
	print OUT @CARM;
	close(OUT);

	&maplog("<font color=green>[$com 개발]</font>$con_name의$mname는$town_name거리에서 $com：<font color=red>$in{'name'}($armdmg/$armwei)</font>($ELE[$in{'ele'}])를 개발했습니다.");
	&con_input;
	&header;
	
	print <<"EOF";
<TABLE border="0" width="80%" align=center bgcolor="#ffffff" height="150" CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">$com의 개발</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="http://amylz.com/venetia/img/etc/buki.gif"></TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc">$com：<font color=red>$in{'name'}</font>($armdmg/$armwei)($ELE[$in{'ele'}])를 개발했습니다.</FONT></TD>
    </TR>
    <TR>
      <TD colspan="2" align="center">
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value=돌아온다></form></TD>
	
    </TR>
  </TBODY>
</TABLE>
<center></center>
EOF

	&footer;
	exit;
}
1;
