sub build {
	&chara_open;
	&status_print;
	&con_open;
	&town_open;

	$kengold=$BUGOLD;
	if($con_id ne 0){&error("무소속이 아니면 건국할 수 없습니다.");}
	$e=0;
	$elelist="<select name=ele>";
	foreach(@ELE){
		if($e ne 0){
			$elelist.="<option value=$e>$ELE[$e]";
		}
		$e++;
	}
	$elelist.="</select>";
	&header;

	print <<"EOF";
<TABLE border="0" width="80%" align=center bgcolor="#ffffff" height="150" CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">건국</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="./img/etc/town.gif"></TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc">건국을 실시합니다.<BR>희망하는 국명을 2~6 문자 이내에서 입력해, 나라의 속성을 선택해 주세요.<BR>다만 건국에는<font color=red>$kengold</font> Gold 필요합니다.</FONT></TD>
    </TR>
    <TR>
      <TD colspan="2" align="center">
	<form action="./country.cgi" method="post">
	국명：<INPUT type=text name=country size=15 name=gold>국<BR>
	나라의 속성：$elelist<BR><BR>
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=hidden name=mode value=build2>
	<INPUT type=submit value=건국 CLASS=FC></form>
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value=그만둔다></form></TD>
	
    </TR>
  </TBODY>
</TABLE>
<center></center>
EOF

	&footer;
	exit;
}
1;

