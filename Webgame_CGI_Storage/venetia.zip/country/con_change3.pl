sub con_change3{
	&chara_open;
	&con_open;
	&town_open;
	if($con_id eq 0){&error("무소속은 실행할 수 없습니다.");}
	foreach(@CON_DATA){
		($con2_id,$con2_name,$con2_ele,$con2_gold,$con2_king,$con2_yaku,$con2_cou,$con2_mes,$con2_etc) =split(/<>/);
		if("$con2_id" eq "$town_con"){$hit=1;last;}
	}
	&header;
	
	print <<"EOF";
<TABLE border="0" width="80%" align=center bgcolor="#ffffff" height="150" CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">하야</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="./img/etc/country.gif"></TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc">무소속이 됩니다.하야에는 5000000 Gold가 필요합니다.<BR>망명시 명성은 0으로 초기화됩니다.<BR>좋습니까?</FONT></TD>
    </TR>
    <TR>
      <TD colspan="2" align="center">
	<form action="./country.cgi" method="post">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=hidden name=mode value=con_change4>
	<INPUT type=submit value="하야 한다" CLASS=FC></form>
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value=그만둔다></form></TD>
	
    </TR>
  </TBODY>
</TABLE>
<center></center>
EOF

	&footer;
	exit;
}
1;

