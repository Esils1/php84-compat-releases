sub set_gmoney {
	&chara_open;
	&status_print;
	&con_open;
	&town_open;

	if($con_id eq 0){&error("무소속은 이용할 수 없습니다.");}
	if($town_con ne $mcon){&error("자국의 거리가 아닙니다.");}
	if($mid ne"$con_king" && $y_chara[0] ne $mid && $y_chara[1] ne $mid && $y_chara[2] ne $mid){&error("왕 또는 직무자 이외 실행할 수 없습니다.");}

	&header;
	
	print <<"EOF";
<TABLE border="0" width="80%" align=center bgcolor="#ffffff" height="150" CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">최소 수금액 결정</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="http://amylz.com/venetia/img/etc/country2.gif"></TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc">자국의 도시에서 최소로 수금할 수 있는 금액을 결정합니다. 1만 골드부터 1백만 골드까지 가능합니다.</FONT></TD>
    </TR>
    <TR>
      <TD colspan="2" align="center">
	<form action="./country.cgi" method="post">
	사냥세 <INPUT type=text name=what size=10 maxlength=7 value="$con_ming"><BR>
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=hidden name=mode value=set_gmoney2>
	<INPUT type=submit value="최소 수금액 결정" CLASS=FC></form>
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value=그만둔다></form></TD>
	
    </TR>
  </TBODY>
</TABLE>
<center></center>
EOF

	&footer;
	exit;
}
1;

