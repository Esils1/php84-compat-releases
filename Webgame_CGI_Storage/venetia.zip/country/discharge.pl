sub discharge {
	&chara_open;
	&status_print;
	&con_open;

	if($con_id eq 0){&error("무소속은 실행할 수 없습니다.");}
	$dir="./logfile/chara";
	opendir(dirlist,"$dir");
	$i=0;
	
	$list.="후보자：<select name=cand>";
	while($file = readdir(dirlist)){
		if($file =~ /\.cgi/i){
			$datames = "검색：$dir/$file<br>\n";
			if(!open(cha,"$dir/$file")){
				&error("$dir/$file가 발견되지 않습니다.<br>\n");
			}
			@cha = <cha>;
			close(cha);
			($rid,$rpass,$rname,$rurl,$rchara,$rsex,$rhp,$rmaxhp,$rmp,$rmaxmp,$rele,$rstr,$rvit,$rint,$rfai,$rdex,$ragi,$rmax,$rcom,$rgold,$rbank,$rex,$rtotalex,$rjp,$rabp,$rcex,$runit,$rcon,$rarm,$rpro,$racc,$rtec,$rsta,$rpos,$rmes,$rhost,$rdate,$rsyo,$rclass,$rtotal,$rkati,$rtype) = split(/<>/,$cha[0]);
			if($con_id eq $rcon && $rid ne"$con_king" && $mid ne"$rid"){
				$list.="<option value=$rid>$rname";
			}
		}
		$mn++;
	}
	closedir(dirlist);

	
	$list.="</select><BR>";
	$list.="<input type=hidden name=no value=$i>";

	&header;
	
	print <<"EOF";
<TABLE border="0" width="90%" align=center bgcolor="#ffffff" height="150" CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">해고</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="./img/etc/country2.gif"></TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc">해고를 실시합니다.<BR>왕 또는 직무자만이 가\능\입니다(명성 100 소비).<BR>해고된 상대는 두 번 다시$con_name국에 관직에 오름을 할 수 없게 되어, 한층 더 명성이 0이 됩니다.<BR>대상자를 선택해, 해고해 주세요.</FONT></TD>
    </TR>
    <TR>
      <TD colspan="2" align="center">
	<table class=TC width=80%>
	<tr><td align=center><font color=$FCOLOR2>해고</font></td></tr>
	<tr>
	<td bgcolor=$FCOLOR2 align=center><font color=$FCOLOR>후보</font></td>
	</tr>
	<tr><td bgcolor=$FCOLOR2 align=center>
	<form action="./country.cgi" method="post">
	$list
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=hidden name=mode value=discharge2>
	<INPUT type=submit value=결정 CLASS=FC>
	</td></form>
	</tr>
	</table>
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value=돌아온다></form>
      </TD>
    </TR>
  </TBODY>
</TABLE>
<center>$STPR</center>
EOF

	&footer;
	exit;
}
1;

