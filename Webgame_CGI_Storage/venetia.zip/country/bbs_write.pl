sub bbs_write {
	&chara_open;
	&status_print;
	&con_open;
	&town_open;
	&time_data;

	if($in{'message'} eq ""){&error("메세지를 입력해 주세요.");}
	if(length($in{'message'}) > 200){&error("100 문자 이내에서 입력해 주세요.");}
	if($con_king ne $mid){&error("직무자 이외는 추가할 수 없습니다.");}
	
	$BFILE="./blog/$con_id.cgi";
	
	open(IN,"$BFILE");
	@BBS_DATA = <IN>;
	close(IN);
	
	$bcount=@BBS_DATA;
	if($bcount>=10){&error("더 이상 추가할 수 없습니다.");}
	unshift(@BBS_DATA,"$mid<>$mname<>$mchara<>$mcon<>$in{'message'}<>$etc<>$daytime<>\n");
	
	open(OUT,">$BFILE");
	print OUT @BBS_DATA;
	close(OUT);
	&header;
	
	print <<"EOF";
<TABLE border="0" width="80%" align=center bgcolor="#ffffff" height="120" CLASS=FC>
  <TBODY>
    <TR>
      <TD align="center" bgcolor="#993300"><FONT color="#ffffcc">기입 완료</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#330000" height=100><FONT color="#ffffcc">썼습니다.</FONT></TD>
    </TR>
    <TR>
      <TD align="center">
	<form action="./country.cgi" method="POST">
	<INPUT type=hidden name=mode value=rule>
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value=OK></form></TD>
	
    </TR>
  </TBODY>
</TABLE>
<center></center>
EOF

	&footer;
	exit;
}
1;

