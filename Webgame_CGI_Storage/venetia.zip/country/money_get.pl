sub money_get{
	&chara_open;
	&town_open;
	&con_open;
	if($mcon eq 0){&error("무소속은 회수를 실시할 수 없습니다.");}
	if($mcon ne"$town_con"){&error("자국의 거리 이외 회수할 수 없습니다.");}
	if($town_gold <=$con_ming){&error("수익이 $con_ming Gold 이상이 아니면 회수할 수 없습니다.");}
	
	$upgold=$town_gold;
	$upgold2=int($upgold/20);
	if($upgold2>1000000){$upgold2=1000000;}
	$con_gold+=$upgold;
	$mcex+=int($upgold/50000);
	$mgold+=$upgold2;
	$town_gold=0;

	&maplog("<font color=orange>【회수】</font>$con_name국의 $mname님은, <font color=red>$upgold골드</font>의 수익을 회수했습니다. 보상으로 <font color=red>$upgold2골드</font>를 얻었습니다.");
	
	&town_input;
	&con_input;
	&chara_input;
	&header;
print <<"EOF";
<TABLE border="0" width="80%" align=center height="150" CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="$FCOLOR"><FONT color="$FCOLOR2">수익의 회수</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="$FCOLOR2" width=20% align=center><img src="http://amylz.com/venetia/img/etc/pub.gif"></TD>
      <TD bgcolor="#330000"><FONT color="$FCOLOR2">$upgold Gold의 수익을 회수했습니다.<br>$mname는$upgold2의 보수를 받았습니다.</FONT></TD>
    </TR>
    <TR>
    <TD colspan="2" align="center" bgcolor="ffffff">
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value=돌아온다></TD></form>
	</TD>
    </TR>
  </TBODY>
</TABLE>
<center></center>
EOF
	&footer;
	exit;
	

}
1;

