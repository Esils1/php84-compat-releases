sub build2 {
	&chara_open;
	&town_open;
	&con_open;
	$conkazu = @CON_DATA;

	if($conkazu>9){&error("건국은 10국까지입니다.");}
	if($con_id ne 0){&error("무소속 이외는 건국할 수 없습니다.");}
	if($town_id eq 0){&error("그 거리에는 건국할 수 없습니다.");}
	if($in{'ele'} eq ""){&error("속성이 올바르게 선택되지 않았습니다.");}
	if($in{'country'} eq ""){&error("국명이 입력되지 않았습니다.");}
	if(length($in{'country'}) < 4||length($in{'country'}) > 12){&error("국명은 2 문자 이상 6 문자 이내에서 입력해 주세요.");}

	foreach(@CON_DATA){
		($con_id,$con_name,$con_ele,$con_gold,$con_king,$con_yaku,$con_cou,$con_mes,$con_etc) =split(/<>/);
		if("$con_id" eq "$town_con"){&error("무소속의 거리 이외 건국할 수 없습니다.");}
	}

	open(IN,"./data/build.cgi") or &error("건국 데이터가 열리지 않습니다.");
	@BUILD = <IN>;
	close(IN);
	$maxid=@BUILD+1;
	$kengold=$BUGOLD;
	$mgold-=$kengold;
	$mcon=$maxid;
	$mcex+=500;

	if($mgold<0){&error("소지금이 충분하지 않습니다.");}

	$town_con=$maxid;
	&town_input;
	push(@CON_DATA,"$maxid<>$in{'country'}<>$in{'ele'}<>$BUGOLD<>$mid<><>1<><>0<>\n");
	open(OUT,">./data/country.cgi") or &error("타운 데이터를 쓸 수 없습니다.");
	print OUT @CON_DATA;
	close(OUT);

	&maplog("<b><font color=red>[건국]</font>$mname는<font color=$ELE_BG[$in{'ele'}]>$in{'country'}나라($ELE[$in{'ele'}])</font>를 건국했습니다.</b>");
	&maplog2("$mname에 의해 $in{'country'}나라가 건국된다.");
	&kh_log("<font color=red>$in{'country'}나라</font>를 건국해,<font color=red>국왕</font>이 된다.","$in{'country'}");

	push(@BUILD,"$maxid<>$in{'country'}<>$in{'ele'}<>$mname<>$daytime<>\n");
	open(OUT,">./data/build.cgi") or &error("건국 데이터를 쓸 수 없습니다.");
	print OUT @BUILD;
	close(OUT);

	&chara_input;

	&header;
	print <<"EOF";
<TABLE border="0" width="80%" align=center bgcolor="#ffffff" height="150" CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">건국</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="./img/etc/town.gif"></TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc">$in{'country'}나라를 건국했습니다.</FONT></TD>
    </TR>
    <TR>
      <TD colspan="2" align="center">
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value=돌아온다></form></TD>
	
    </TR>
  </TBODY>
</TABLE>
<center></center>
EOF

	&footer;
	exit;
}
1;

