sub conv_write {
	&chara_open;
	&status_print;
	&con_open;
	&town_open;
	&time_data;

	if($in{'type'} && $in{'title'} eq""){&error("타이틀을 입력해 주세요.");}
	if($in{'message'} eq ""){&error("메세지를 입력해 주세요.");}
	if(length($in{'title'}) > 30){&error("타이틀은 15 문자 이내에서 입력해 주세요.");}
	if(length($in{'message'}) > 400){&error("200 문자 이내에서 입력해 주세요.");}
	if($in{'bbs'} eq "con" && $con_id eq "0"){&error("무소속은 이용할 수 없습니다.");}

	if($in{'bbs'} eq "all"){
		$BFILE="./blog/conv/0.cgi";
		$conv="all_conv";
	}elsif($in{'bbs'} eq "con"){
		$BFILE="./blog/conv/$con_id.cgi";
		$conv="con_conv";
	}else{&error("부정한 액세스입니다.");}

	open(IN,"$BFILE");
	@BBS_DATA = <IN>;
	close(IN);
	
	$no=0;
	@BBS_DATA2=();
	@N_BBS=();
	@N_BBS2=();
	foreach(@BBS_DATA){
		($lid,$lname,$lchara,$lcon,$ltitle,$lmes,$letc,$lhost,$ldaytime) =split(/<>/);
		if($ltitle ne""){
			$no2=$no;
		}
		if($no2 eq"$in{'resno'}" && $in{'resno'} ne""){
			$hit=1;
			push(@BBS_DATA2,"$_");
		}else{push(@N_BBS,"$_");}
		$no++;
	}
	
	if($con_king eq $mid){$etc="$con_name 국왕";}
	else{$etc="$con_name 병사";}
	push(@BBS_DATA2,"$mid<>$mname<>$mchara<>$con_ele<>$in{'title'}<>$in{'message'}<>$etc<>$mhost<>$daytime<>\n");

	@N_BBS2=(@BBS_DATA2,@N_BBS);
	splice(@N_BBS2,30);
	
	open(OUT,">$BFILE");
	print OUT @N_BBS2;
	close(OUT);

	&header;
	
	print <<"EOF";
<TABLE border="0" width="80%" align=center bgcolor="#ffffff" height="120" CLASS=FC>
  <TBODY>
    <TR>
      <TD align="center" bgcolor="#993300"><FONT color="#ffffcc">기입 완료</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#330000" height=100><FONT color="#ffffcc">썼습니다.</FONT></TD>
    </TR>
    <TR>
      <TD align="center">
	<form action="./country.cgi" method="POST">
	<INPUT type=hidden name=mode value=$conv>
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value=OK></form></TD>
	
    </TR>
  </TBODY>
</TABLE>
<center></center>
EOF

	&footer;
	exit;
}
1;

