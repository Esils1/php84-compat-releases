sub ram_up {
	&chara_open;
	&status_print;
	&con_open;
	&town_open;
	if($con_id eq 0){&error("무소속은 이용할 수 없습니다.");}
	if($town_con ne $mcon){&error("자국의 거리가 아닙니다.");}

	$list="<select name=pow>";
	$list.="<option value=t_hp>성벽의 수복";
	$list.="<option value=t_maxhp>성벽 MAX";
	$list.="<option value=t_str>공격력";
	$list.="<option value=t_def>내구력";
	$list.="</select>";

	&header;
	print <<"EOF";
<TABLE border="0" width="80%" align=center bgcolor="#ffffff" height="150" CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">성벽의 강화</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="http://amylz.com/venetia/img/etc/siro.gif"></TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc">$town_name의 성벽의 강화를 실시합니다.<BR>강화하는 항목을 선택해, 금액을 입력해 주세요.<BR>나라의 자금：$con_gold Gold</FONT></TD>
    </TR>
    <TR>
      <TD colspan="2" align="center">
	<form action="./country.cgi" method="post">
	$list를
	<INPUT type=text size=5 name=gold>0000Gold
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=hidden name=mode value=ram_up2>
	<INPUT type=submit value=강화 CLASS=FC></form>
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value=돌아온다></form></TD>
	
    </TR>
  </TBODY>
</TABLE>
<center></center>
EOF

	&footer;
	exit;
}
1;

