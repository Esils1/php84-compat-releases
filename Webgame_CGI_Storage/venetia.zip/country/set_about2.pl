sub set_about2 {
	&chara_open;
	&status_print;
	&town_open;
	&con_open;

	if($con_id eq 0){&error("무소속은 이용할 수 없습니다.");}
	if($town_con ne $mcon){&error("자국의 거리가 아닙니다.");}
	if($mid ne"$con_king" && $y_chara[0] ne $mid && $y_chara[1] ne $mid && $y_chara[2] ne $mid){&error("왕 또는 직무자 이외 실행할 수 없습니다.");}

	&error("내용을 입력하세요") if $in{'what'} eq "";
	$con_about = $in{'what'} . " ($mname님으로부터)";


	&maplog("<font color=green>[홍보문 변경]</font>$mname은 <font color=red>$con_name국</font>의 홍보문을 변경했습니다.");
	&con_input;
	&header;
	
	print <<"EOF";
<TABLE border="0" width="80%" align=center bgcolor="#ffffff" height="150" CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">홍보문 변경</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="http://amylz.com/venetia/img/etc/country2.gif"></TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc">홍보문을 변경했습니다.</FONT></TD>
    </TR>
    <TR>
      <TD colspan="2" align="center">
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value=돌아온다></form></TD>
	
    </TR>
  </TBODY>
</TABLE>
<center></center>
EOF

	&footer;
	exit;
}
1;

