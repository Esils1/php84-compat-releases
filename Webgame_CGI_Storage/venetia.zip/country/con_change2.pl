sub con_change2{
	&chara_open;
	&con_open;
	&town_open;

	if($con_id ne 0){&error("무소속이 아니다고 망명 할 수 없습니다.");}
	if($munit ne ""){&error("부대로부터 이탈해 주세요.");}
	foreach(@CON_DATA){
		($con2_id,$con2_name,$con2_ele,$con2_gold,$con2_king,$con2_yaku,$con2_cou,$con2_mes,$con2_etc) =split(/<>/);
		if("$con2_id" eq "$town_con"){$hit=1;last;}
	}
	if(!$hit){&error("망명 하고 싶은 나라의 영토까지 가, 망명 해 주세요.");}
	if($town_con eq 0){&error("그 나라에는 망명 할 수 없습니다.");}

	open(IN,"./logfile/out/$mid.cgi");
	@DATA = <IN>;
	close(IN);

	$c_no = 0;
	foreach(@DATA){
		($dcon_id,$dtime) =split(/<>/);
		if("$dcon_id" eq "$town_con"){$hit2=1;last;}
	}
	if($hit2){&error("해고된 나라에는 망명 할 수 없습니다.");}

	$mcon=$town_con;

	&chara_input;
	
	&maplog("<font color=green>[망명]</font>$mname는$con2_name국에 망명 했습니다.");
	&kh_log("$con2_name국의 국민이 된다.",$con2_name);

	&header;

	print <<"EOF";
<TABLE border="0" width="80%" bgcolor="#ffffff" height="150" align=center CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">망명</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="./img/etc/inn2.gif"></TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc">$con2_name에 망명 했습니다.</FONT></TD>
    </TR>
    <TR>
      <TD colspan="2" align="right">
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value=돌아온다></form></TD>
	
    </TR>
  </TBODY>
</TABLE>
EOF
	&footer;
	exit;
}
1;

