sub king_change2 {
	&chara_open;
	&status_print;
	&town_open;
	&con_open;

	if($mid ne"$con_king" && $y_chara[0] ne $mid && $y_chara[1] ne $mid && $y_chara[2] ne $mid){&error("왕 또는 직무자 이외 실행할 수 없습니다.");}
	if($con_id eq 0){&error("무소속은 실행할 수 없습니다.");}
	if($mid ne"$con_king" && ($y_chara[0] eq $mid || $y_chara[1] ne $mid || $y_chara[2] ne $mid)){
		if($mcex < 3000){
			&error("직무자는 공헌도 3000이상 필요합니다.");
		}
		if($mgold < 10000000){
			&error("직무자가 왕의 교대를 실시하는 경우, 10000000 gold 필요합니다.");
		}
		$mgold -= 10000000;
	}
	if($in{'cand'} eq ""){&error("후보자가 올바르게 선택되지 않았습니다.");}
	
	$enemy_id=$in{'cand'};
	&enemy_open;

	for($i=0;$i<3;$i++){
		if($y_chara[$i] eq $in{'cand'}){
			&error("후보자가 직무에 붙어 있는 경우, 해제를 실시하고 나서 실행해 주세요.");
		}
	}
	$con_king = "$in{'cand'}";
	&con_input;
	&eh_log("$con_name국의<font color=red>국왕</font>으로 임명된다.","$con_name");
	&maplog("<font color=blueviolet>[국왕 교대]</font><font color=$ELE_BG[$con_ele]>$con_name국($ELE[$con_ele])</font>의$mname는<font color=red>$ename</font>를 국왕으로 임명했습니다.");
	
	&header;
	
	print <<"EOF";
<TABLE border="0" width="80%" align=center bgcolor="#ffffff" height="150" CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">직무 임명</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="./img/etc/inn.gif"></TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc">$ename를<font color=red>$in{'yname'}</font>에 임명했습니다.</FONT></TD>
    </TR>
    <TR>
      <TD colspan="2" align="center">
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value=돌아온다></form></TD>
	
    </TR>
  </TBODY>
</TABLE>
<center></center>
EOF

	&footer;
	exit;
}
1;

