#!/usr/bin/perl
require './jcode.pl';
require './sub.cgi';
require './conf.cgi';

&decode;
if($ENV{'HTTP_REFERER'} !~ /cgi$/ ){ &error2("주소 바에 값을 입력하지 말아 주세요."); }
if($in{'mode'} eq"def"){require './country/def.pl';&def;}
elsif($in{'mode'} eq"def_out"){require './country/def_out.pl';&def_out;}
elsif($in{'mode'} eq"town_up"){require './country/town_up.pl';&town_up;}
elsif($in{'mode'} eq"town_up2"){require './country/town_up2.pl';&town_up2;}
elsif($in{'mode'} eq"town_arm"){require './country/town_arm.pl';&town_arm;}
elsif($in{'mode'} eq"town_arm2"){require './country/town_arm2.pl';&town_arm2;}
elsif($in{'mode'} eq"ram_up"){require './country/ram_up.pl';&ram_up;}
elsif($in{'mode'} eq"ram_up2"){require './country/ram_up2.pl';&ram_up2;}
elsif($in{'mode'} eq"ram_down"){require './country/ram_down.pl';&ram_down;}
elsif($in{'mode'} eq"ram_down2"){require './country/ram_down2.pl';&ram_down2;}
elsif($in{'mode'} eq"build"){require './country/build.pl';&build;}
elsif($in{'mode'} eq"build2"){require './country/build2.pl';&build2;}
elsif($in{'mode'} eq"king_conv"){require './country/king_conv.pl';&king_conv;}
elsif($in{'mode'} eq"king_chat"){require './country/king_chat.pl';&king_chat;}
elsif($in{'mode'} eq"king_com"){require './country/king_com.pl';&king_com;}
elsif($in{'mode'} eq"king_com2"){require './country/king_com2.pl';&king_com2;}
elsif($in{'mode'} eq"king_change"){require './country/king_change.pl';&king_change;}
elsif($in{'mode'} eq"king_change2"){require './country/king_change2.pl';&king_change2;}
elsif($in{'mode'} eq"all_conv"){require './country/all_conv.pl';&all_conv;}
elsif($in{'mode'} eq"con_conv"){require './country/con_conv.pl';&con_conv;}
elsif($in{'mode'} eq"conv_write"){require './country/conv_write.pl';&conv_write;}
elsif($in{'mode'} eq"rule"){require './country/rule.pl';&rule;}
elsif($in{'mode'} eq"all_rule"){require './country/all_rule.pl';&all_rule;}
elsif($in{'mode'} eq"rule_write"){require './country/rule_write.pl';&rule_write;}
elsif($in{'mode'} eq"rule_delete"){require './country/rule_delete.pl';&rule_delete;}
elsif($in{'mode'} eq"sirei"){require './country/sirei.pl';&sirei;}
elsif($in{'mode'} eq"sirei2"){require './country/sirei2.pl';&sirei2;}
elsif($in{'mode'} eq"unit"){require './country/unit.pl';&unit;}
elsif($in{'mode'} eq"unit_entry"){require './country/unit_entry.pl';&unit_entry;}
elsif($in{'mode'} eq"unit_delete"){require './country/unit_delete.pl';&unit_delete;}
elsif($in{'mode'} eq"unit_out"){require './country/unit_out.pl';&unit_out;}
elsif($in{'mode'} eq"unit_edit"){require './country/unit_edit.pl';&unit_edit;}
elsif($in{'mode'} eq"money_get"){require './country/money_get.pl';&money_get;}
elsif($in{'mode'} eq"con_change"){require './country/con_change.pl';&con_change;}
elsif($in{'mode'} eq"con_change2"){require './country/con_change2.pl';&con_change2;}
elsif($in{'mode'} eq"con_change3"){require './country/con_change3.pl';&con_change3;}
elsif($in{'mode'} eq"con_change4"){require './country/con_change4.pl';&con_change4;}
elsif($in{'mode'} eq"suport_money"){require './country/suport_money.pl';&suport_money;}
elsif($in{'mode'} eq"suport_money2"){require './country/suport_money2.pl';&suport_money2;}
elsif($in{'mode'} eq"discharge"){require './country/discharge.pl';&discharge;}
elsif($in{'mode'} eq"discharge2"){require './country/discharge2.pl';&discharge2;}
elsif($in{'mode'} eq"set_tax"){require './country/set_tax.pl';&set_tax;}
elsif($in{'mode'} eq"set_tax2"){require './country/set_tax2.pl';&set_tax2;}
elsif($in{'mode'} eq"set_about"){require './country/set_about.pl';&set_about;}
elsif($in{'mode'} eq"set_about2"){require './country/set_about2.pl';&set_about2;}
elsif($in{'mode'} eq"set_ming"){require './country/set_ming.pl';&set_ming;}
elsif($in{'mode'} eq"set_ming2"){require './country/set_ming2.pl';&set_ming2;}
elsif($in{'mode'} eq"set_gmoney"){require './country/set_gmoney.pl';&set_gmoney;}
elsif($in{'mode'} eq"set_gmoney2"){require './country/set_gmoney2.pl';&set_gmoney2;}
elsif($in{'mode'} eq"set_bong"){require './country/set_bong.pl';&set_bong;}
elsif($in{'mode'} eq"set_bong2"){require './country/set_bong2.pl';&set_bong2;}
else{&error2("올바르게 선택되고 있지 않습니다.");}
exit;

