#!/usr/bin/perl
require './jcode.pl';
require './sub.cgi';
require './conf.cgi';
require './battle_suport.cgi';

&decode;
&chara_open;

if ($mmacro < time) {
	require './status/macro.pl';
	&macro;
	exit;
}

if($ENV{'HTTP_REFERER'} !~ /cgi$/ ){ &error2("주소 바에 값을 입력하지 말아 주세요."); }

if($in{'mode'} eq "battle2"){require './battle/battle2.pl';&battle2;}
elsif($in{'mode'} eq "kunren"){require './battle/kunren.pl';&kunren;}
elsif($in{'mode'} eq "kunren2"){require './battle/kunren2.pl';&kunren2;}
elsif($in{'mode'} eq "toubatsu"){require './battle/toubatsu.pl';&toubatsu;}
elsif($in{'mode'} eq "toubatsu2"){require './battle/toubatsu2.pl';&toubatsu2;}
elsif($in{'mode'}){require './battle/battle.pl';&bat;}
else{&error2("올바르게 선택되지 않았습니다.");}
exit;

