#!/usr/bin/perl
require './jcode.pl';
require './sub.cgi';
require './conf.cgi';
&decode;
&header;

open(IN,"./data/maplog4.cgi");
@MA = <IN>;
close(IN);
foreach(@MA){
	$mapl.="<b><font color=$FCOLOR>●$MA[$m]</font></b><BR>";
	$m++;
}

print <<"EOF";
<CENTER>
<a href=./ilog.cgi>아이템 사용 로그</a>
<a href=./warn.cgi>경고 로그</a>
<a href=./rename.cgi>개명 로그</a>
<a href=./find.cgi>발견 로그</a>
<TABLE border="0" bgcolor="#660033" width="700" cellspacing="5" height="509">
  <TBODY>
    <TR>
      <TD colspan="2" bgcolor="#ffffcc"><FONT style="font-size:15px" color="#666600"><아이템 사용 로그><BR>$mapl</FONT><BR></TD>
    </TR>
  </TBODY>
</TABLE>
<BR>
</P>
</CENTER>

<hr>
EOF

&footer;
exit;

