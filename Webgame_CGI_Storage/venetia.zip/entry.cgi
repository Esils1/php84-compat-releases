#!/usr/bin/perl
require './jcode.pl';
require './sub.cgi';
require './conf.cgi';

&decode;

if($CHARA_ENT){&error2("현재 신규 등록할 수 없습니다.");}
##캐릭터 화상 선택
$chlist="<select name=img>";
for($i=0;$i<=$CHARAIMG;$i++){
	$chlist.="<option value=$i>No.$i";
}
$chlist.="</select>";

##속성 선택
$j=0;
$elelist="<select name=ele>";
$elelist.="<option>-속성의 선택-";
foreach(@ELE){
	$elelist.="<option value=$j>$ELE[$j]";
	$j++;
}
$elelist.="</select>";

##소속국 선택
$k=0;
open(IN,"./data/country.cgi") or &error2("나라 데이터 파일이 열리지 않습니다.");
@CON = <IN>;
close(IN);

$conlist="<select name=con_id>";
$conlist.="<option>소속국을 선택";
$conlist.="<option value=0>무소속";
foreach(@CON){
	($con_id,$con_name,$con_ele,$con_gold,$con_king,$con_yaku,$con_cou,$con_mes,$con_etc) =split(/<>/);
	$c_no++;
	$conlist.="<option value=$con_id>$con_name($ELE[$con_ele])";
	$k++;
}
$conlist.="</select>";

if($ATTESTATION){$mailcom="<BR><font color=red size=2>입력한 주소앞에 인증 패스워드가 메일에서 보내집니다.등록 후, 입력한 메일 주소앞에 닿는 메일에 기재된 패스워드로 인증을 실시하는 일로 등록 완료가 됩니다.<BR>메일 주소가 올바르지 않은 경우, 인증 메일이 도착하지 않고 등록할 수 없습니다.또, 재차 등록할 수도 있기 때문에 주의해 주세요.</font>";}

&header;

print <<"EOF";
<script language="JavaScript">
function changeImg(){
  	num=document.para.img.selectedIndex;
  	document.Img.src="./img/chara/"+ num +".gif";
}
</script>
<CENTER>
<form action="./chara_make.cgi" name=para method="POST">
<TABLE border="0" width="700" height="500" class=TC>
  <TBODY>
    <TR>
      <TD colspan="2" bgcolor="$FCOLOR" align="center"><FONT size="+2"><B><FONT color="#ffffcc" size="+2">Entry page</FONT></B></FONT></TD>
    </TR>
    <TR>
      <TD colspan="2" bgcolor="#ffffcc">●캐릭터를 작성합니다.<BR>
	●ID, 패스워드, 메일 주소는 정확하게 입력해 주세요.입력에 잘못이 있는 경우, 플레이할 수 없게 되므로 주의해 주세요.<BR>
	<font color=red>●또, 2중등록은 금지하고 있습니다.한 번 등록 후, 재차 등록하는 일은 할 수 없습니다.2중등록을 실시했을 경우, 액세스 제한 하겠습니다.</font>
      </TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc">주인공의 이름</TD>
      <TD bgcolor="#ffffcc"><INPUT size=30 name=name><BR>
      ※2~8 문자로 입력해 주세요</TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc">ID</TD>
      <TD bgcolor="#ffffcc"><INPUT size=20 name=id><BR>
      ※ID를 반각으로 입력해 주세요(4~8 문자)</TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc">패스워드</TD>
      <TD bgcolor="#ffffcc"><INPUT type=password size=20 name=pass><BR>
      ※패스워드를 반각으로 입력해 주세요(4~8 문자)</TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc">메일 주소</TD>
      <TD bgcolor="#ffffcc"><INPUT type=text size=20 name=mail value=@><BR>
      ※메일 주소를 입력해 주세요(※프리 메일 불가) $mailcom</TD>
    </TR>
   <TR>
      <TD bgcolor="#ffffcc">메일 주소(확인용)</TD>
      <TD bgcolor="#ffffcc"><INPUT type=text size=20 name=mailconfirm value=@><BR>
      ※확인 (위해)때문에, 한번 더 입력해 주세요.</TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc">캐릭터의 아이콘</TD>
	     <TD bgcolor="#ffffcc"><img src=\"./img/chara/0.gif\" name=\"Img\"><BR>
	   <select name=img onChange=\"changeImg()\">
EOF
	foreach (0..$CHARAIMG){print "<option value=\"$_\">이미지[$_]\n";}

	print <<"EOF";
	</select><br>캐릭터의 화상을 선택해 주세요.</TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc">성별</TD>
      <TD bgcolor="#ffffcc"><select name="sex"><option value="0">남성<option value="1">여성</select></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc">속성</TD>
      <TD bgcolor="#ffffcc">$elelist</TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc">소속하는 나라</TD>
      <TD bgcolor="#ffffcc">$conlist</TD>
    </TR>
    <TR>
      <TD colspan="2" bgcolor="#ffffcc" align="center"><input type="submit"CLASS=FC value="등록한다"></TD>
    </TR>
  </TBODY>
  </form>
</TABLE>
</CENTER>
EOF

&footer;
exit;


