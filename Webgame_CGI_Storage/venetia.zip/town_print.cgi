#!/usr/bin/perl

#################################################################
#   【면책 사항】                                                #
#    이 스크립트는 프리 소프트입니다.이 스크립트를 사용했다 #
#    어떠한 손해에 대해서 작자는 일절의 책임을 지지 않습니다.         #
#    또 설치에 관한 질문은 서포트 게시판에 부탁드리겠습니다.   #
#    직접 메일에 의한 질문은 일절 받고있지 않습니다.       #
#################################################################

require 'jcode.pl';
require 'sub.cgi';
require 'conf.cgi';

if($MENTE) { &error2("점검 안입니다.잠깐 기다려 주세요."); }
&decode;
#if($ENV{'HTTP_REFERER'} !~ /i/ ){ &error2("주소 바에 값을 입력하지 말아 주세요."); }
&town_print;

#_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/#
#        전가정보 표시       #
#_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/#

sub town_print {

	open(IN,"./data/towndata.cgi");
	@T_LIST = <IN>;
	close(IN);

	open(IN,"./data/country.cgi") or &error2('파일을 열지 않았습니다.');
	@COU_DATA = <IN>;
	close(IN);
	$country_no=1;
	foreach(@COU_DATA){
		($xxcid,$xxname,$xxele,$xxgold,$xxking,$xxyaku,$xxcou,$xxmes,$xxetc) =split(/<>/);
		$country_name[$xxcid]="$xxname";
		$country_no++;
		$c_ele[$xxcid] = $xxele; 
	}

	&header;

	print <<"EOM";
<TABLE WIDTH="100%" CLASS=TC>
  <TBODY>
    <TR>
      <TH BGCOLOR=$TD_C2 height=5>가명</TH>
      <TH BGCOLOR=$TD_C1 height=5>지배국</TH>
      <TH BGCOLOR=$TD_C1 height=5>소재</TH>
      <TH BGCOLOR=$TD_C4 height=5>수익금</TH>
      <TH BGCOLOR=$TD_C3 height=5>속성</TH>
      <TH BGCOLOR=$TD_C2 height=5>무기 개발</TH>
      <TH BGCOLOR=$TD_C1 height=5>방어구 개발</TH>
      <TH BGCOLOR=$TD_C4 height=5>악세사리 개발</TH>
      <TH BGCOLOR=$TD_C3 height=5>산업치</TH>
      <TH BGCOLOR=$TD_C3 height=5>요새</TH>

    </TR>
EOM

	$town_c0=0;$town_c1=0;$town_c2=0;$town_c3=0;
	foreach(@T_LIST){
		($zcid,$zname,$zcon,$zele,$zmoney,$zarm,$zpro,$zacc,$zind,$zs,$ztr,$zx,$zy,$zetc) =split(/<>/);
		($town_hp,$town_max,$town_str,$town_def,$town_dex,$town_flg) =split(/,/,$zetc);
		$TOWN_NAME[$zcid]="$zname";
		$wc_ele = $c_ele[$zcon];
print <<"EOM";
<TR>
      <TD BGCOLOR=$ELE_C[$wc_ele] height=5 align=center><B><font color=$ELE_BG[$wc_ele]>$zname</TD>
      <TD BGCOLOR=$ELE_C[$wc_ele] height=5 align=center><font color=$ELE_BG[$wc_ele]>$country_name[$zcon] 국</TD>
      <TD BGCOLOR=$ELE_C[$wc_ele] height=5><font color=$ELE_BG[$wc_ele]>$zx-$zy</TD>
      <TD BGCOLOR=$ELE_C[$wc_ele] height=5 align=right><font color=$ELE_BG[$wc_ele]>$zmoney GOLD</TD>
      <TD BGCOLOR=$ELE_C[$wc_ele] height=5><font color=$ELE_BG[$wc_ele]>$ELE[$zele]</TD>
      <TD BGCOLOR=$ELE_C[$wc_ele] height=5><font color=$ELE_BG[$wc_ele]>$zarm</TD>
      <TD BGCOLOR=$ELE_C[$wc_ele] height=5><font color=$ELE_BG[$wc_ele]>$zpro</TD>
      <TD BGCOLOR=$ELE_C[$wc_ele] height=5><font color=$ELE_BG[$wc_ele]>$zacc</TD>
      <TD BGCOLOR=$ELE_C[$wc_ele] height=5><font color=$ELE_BG[$wc_ele]>$zind</TD>
      <TD BGCOLOR=$ELE_C[$wc_ele] height=5><font color=$ELE_BG[$wc_ele]>$town_hp/$town_max</TD>
      
</TR>
EOM
	}

print <<"EOM";
  </TBODY>
</TABLE>
EOM

	&footer;

	exit;
}

