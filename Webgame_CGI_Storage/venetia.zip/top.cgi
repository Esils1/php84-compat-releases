#!/usr/bin/perl
require './jcode.pl';
require './sub.cgi';
require './conf.cgi';
#require './data/town_mes.cgi';

$cond = "정상";

&decode;
if($ENV{'HTTP_REFERER'} !~ /cgi$/ ){ &error2("주소 바에 값을 입력하지 말아 주세요."); }

$tmode = "timer";
&chara_open;
if($murl ne ""){&error2("인증이 끝나고 있지 않습니다.등록한 메일 주소에 인증 ID가 첨부되고 있으므로 등록해 주세요.");}
&town_open;
&con_open;
&guest_list;
&time_data;

$tt = time;
$s_time = $tt - $mdate;
$s_time = $BTIME - $s_time;


$mesr= int(rand(15));
foreach(@CON_DATA){
	($con2_id,$con2_name,$con2_ele,$con2_gold,$con2_king,$con2_yaku,$con2_cou,$con2_mes,$con2_etc) =split(/<>/);
	$CONELE[$con2_id]=$con2_ele;
	$CONNAME[$con2_id]=$con2_name;
	$c_no++;
}
$hit=0;
foreach(@CON_DATA){
	($con2_id,$con2_name,$con2_ele,$con2_gold,$con2_king,$con2_yaku,$con2_cou,$con2_mes,$con2_etc) =split(/<>/);
	if("$con2_id" eq "$town_con"){$hit=1;last;}
}
if(!$hit){$con2_ele=0;$con2_name="무소속";$con2_id=0;}

&header;

if($s_time > 0){
	$clock="<FORM NAME=\"tokei\"><INPUT TYPE=\"text\" NAME=\"tok\" SIZE=\"25\" style=\"color:#00FF00;background-color:#404040;\">";
}
else{$clock= "<font color=$ELE_C[$con_ele] size=2>행동 OK</font>";}

if($hour > 20 || $hour < 4){$timg ="$TOWN_IMG2";}
else{$timg ="$TOWN_IMG";}
if($mflg<2){require'./etc/top_print.pl';&top_print;}

open(IN,"./data/maplog.cgi");
@MAP = <IN>;
close(IN);
foreach(@MAP){
	$maplog.="<font color=000000><span style=\"font-size:9pt;\">●$MAP[$l]</font><BR>";
	$l++;
}

open(IN,"./data/maplog5.cgi");
@MAP2 = <IN>;
close(IN);
foreach(@MAP2){
	$maplog.="<font color=000000><span style=\"font-size:9pt;\">●$MAP2[$l2]</font><BR>";
	$l2++;
}

if($in{'id'} eq""){&error2("ID가 입력되고 있지 않습니다.");}
if($in{'pass'} eq""){&error2("패스워드가 입력되고 있지 않습니다.");}


##메세지 표시
open(IN,"./meslog/all.cgi");
@MES_DATA1 = <IN>;
close(IN);
open(IN,"./meslog/$con_id.cgi");
@MES_DATA2 = <IN>;
close(IN);
open(IN,"./logfile/mes/$mid.cgi");
@MES_DATA3 = <IN>;
close(IN);

open(IN,"./meslog/unit/$munit.cgi");
@MES_DATA4 = <IN>;
close(IN);

$atable="<table border=0 bgcolor=$FCOLOR width=100%>";
foreach(@MES_DATA1){
	($lid,$laite,$leid,$lchara,$lname,$lmes,$ldaytime) =split(/<>/);
	$atable.="<tr><td align=center bgcolor=000000 width=15%><img src=\"./img/chara/$lchara.gif\" width=80 height=80></td><td align=left bgcolor=000000 width=85%><b>$lname<BR><font color=ffffff>「$lmes」</b></font></font><font color=#999999 size=1><BR>($ldaytime)</font></td></tr>";
}
$atable.="</table>";

$ctable="<table border=0 bgcolor=$ELE_BG[$con_ele] width=100%>";
foreach(@MES_DATA2){
	($lid,$laite,$leid,$lchara,$lname,$lmes,$ldaytime) =split(/<>/);
	$ctable.="<tr><td align=center bgcolor=000000 width=15%><img src=\"./img/chara/$lchara.gif\" width=80 height=80></td><td align=left bgcolor=000000 width=85%><b>$lname<BR><font color=ffffff>「$lmes」</b></font></font><font color=#999999 size=1><BR>($ldaytime)</font></td></tr>";
}
$ctable.="</table>";

$ktable="<table border=0 bgcolor=$ELE_BG[$mele] width=100%>";
foreach(@MES_DATA3){
	($lid,$laite,$leid,$lchara,$lname,$lmes,$ldaytime) =split(/<>/);
	if($lid ne $mid){$klist.="<option value=$lid>$leid씨에게";}
	$ktable.="<tr><td align=center bgcolor=000000 width=15%><img src=\"./img/chara/$lchara.gif\" width=80 height=80></td><td align=left bgcolor=000000 width=85%><b>$lname<BR><font color=ffffff>「$lmes」</b></font></font><font color=#999999 size=1><BR>($ldaytime)</font></td></tr>";
}
$ktable.="</table>";

$btable="<table border=0 bgcolor=$ELE_BG[$con_ele] width=100%>";
foreach(@MES_DATA4){
	($lid,$laite,$leid,$lchara,$lname,$lmes,$ldaytime) =split(/<>/);
	$btable.="<tr><td align=center bgcolor=000000 width=15%><img src=\"./img/chara/$lchara.gif\" width=80 height=80></td><td align=left bgcolor=000000 width=85%><b>$lname<BR><font color=ffffff>「$lmes」</b></font></font><font color=#999999 size=1><BR>($ldaytime)</font></td></tr>";
}
$btable.="</table>";

##은폐 지하 감옥
$moya2=$moya%1000;

if($moya eq "77777"){$dun.="<OPTION value=14 style=\"background-color:yellow;\">◆ $SEN[14]";}
if($moya eq "777"){$dun.="<OPTION value=10 style=\"background-color:yellow;\">◆ $SEN[10]";}
if($moya eq "775" || $moya eq "776"){$dun.="<OPTION value=15 style=\"background-color:yellow;\">◆ $SEN[15]";}
if($moya%5000 eq "773"){$dun.="<OPTION value=13 style=\"background-color:yellow;\">◆ $SEN[13]";}
if($moya eq "55555"){$dun.="<OPTION value=12 style=\"background-color:yellow;\">◆ $SEN[12]";}
if($moya%2500 eq "17"){$dun.="<OPTION value=11 style=\"background-color:yellow;\">◆ $SEN[11]";}
if($moya%1000 eq "9"){$dun.="<OPTION value=9 style=\"background-color:yellow;\">◆ $SEN[9]";}
if($moya%300 eq "8"){$dun.="<OPTION value=8 style=\"background-color:yellow;\">◆ $SEN[8]";}
if($moya%80 eq "7"){$dun.="<OPTION value=7 style=\"background-color:yellow;\">◆ $SEN[7]";}
if($moya%40 eq "0"){$dun.="<OPTION value=6 style=\"background-color:yellow;\">◆ $SEN[6]";}
if($mex%11 eq "0" && $mex < 9900){$dun.="<OPTION value=5 style=\"background-color:yellow;\">◆ $SEN[5]";}

if($moya%1000 eq "1"){$shop.="<OPTION style=\"background-color:pink;\" value=rshop>마녀의 가게";}
if($moya%5000 eq "37"){$status.="<OPTION style=\"background-color:#CCFFCC;\" value=name_change>개명의 신전";}

##펫
&pet_open;
if ($mpname || $mid eq "chanje") {

$status = "ㅁㄴㅇㄹ" if 
$pstatus .= << "EOM";
       <TABLE border="0" width=100% bgcolor="$FCOLOR2" CLASS=CC>
		   <TBODY>
			     <TR>
                  <TD colspan="5"><FONT color="#ffffcc" >$mname 펫의 스테이터스</FONT></TD>
                  </TR>
			      <TR>
                  <TD bgcolor="$ELE_C[$mele]" width=50><img src="./img/chara/$mchara.gif"></TD>
                  <TD bgcolor="$ELE_C[$mele]" colspan=5>「$status」</TD>
                     </TR>
			      <TR>
                  <TD bgcolor="$ELE_C[$mele]">이름</FONT></TD>
                  <TD bgcolor="$ELE_C[$mele]">$mpname</FONT></TD>
                  <TD bgcolor="$ELE_C[$mele]">레벨</FONT></TD>
                  <TD bgcolor="$ELE_C[$mele]">$mplv</FONT></TD>
                  <TD bgcolor="$ELE_C[$mele]">친밀도</FONT></TD>
                  <TD bgcolor="$ELE_C[$mele]">$mpfm</FONT></TD>
                  </TR>
			      <TR>
                  <TD bgcolor="$ELE_C[$mele]">공복도</FONT></TD>
                  <TD bgcolor="$ELE_C[$mele]">$mphungry</FONT></TD>
                  <TD bgcolor="$ELE_C[$mele]">AP</FONT></TD>
                  <TD bgcolor="$ELE_C[$mele]">$mpap</FONT></TD>
                  <TD bgcolor="$ELE_C[$mele]">친밀도</FONT></TD>
                  <TD bgcolor="$ELE_C[$mele]">$mpfm</FONT></TD>
                  </TR>
			</TBODY>
				</TABLE>
EOM
}

##해야할일
$todo = "<ul>";
$todo .= "<li>레벨 50이 넘으면 전직이 가능해요. 열렙하세요~</li>" if $mlv < 50;
$todo .= "<li>...</li>";

require "./data/quest.cgi";
($qname,$qdesc) = split(/<>/, $QUEST->{$mquest});

$qn = "현재 퀘스트: <b>$qname</b> ... $qdesc";
$qn = "현재 퀘스트: 퀘스트를 받고 있지 않습니다." if !$mquest;

##화면 표시
$player=@newguest;
print <<"EOF";
<style>
td { font-size:9pt; }
</style>
<table width=94% align=center CLASS=CC>
	    <tr>
	    <td bgcolor="$TCOLOR">
	    <font color="ffffff" >참가자($player명) - <b>즐황제의 THE VENETIA II Ver1.00 </b> - <a href=index.cgi onfocus=blur()>[메인화면]</a> - <a href=/mini/mini.php?id=venetia target=_blank onfocus=blur()>[베네치아 게시판]</a></font></TD>
	    </tr>
	    <tr>
	    <td bgcolor="ffffff">
	    <span style="font-size:12pt; letter-spacing:-1px;"><marquee>$guestlist</span></font></TD>
	    </tr></table>
	<CENTER>
	<table CLASS=CC width=94%>
	    <TR>
	    <TD colspan=11 bgcolor=$ELE_BG[$con_ele]><font  color=$ELE_C[$con_ele]>$con_name국으로부터의 지령</font>
	    </TD>
	    </TR>
	    <TR>
	    <TD colspan=11 bgcolor=$ELE_C[$con_ele]><font color=$ELE_BG[$con_ele]><marquee scrolldelay=20 scrollamount=1 truespeed><b>$con_mes</b></marquee></font>
	    </TD>
	    </TR>
	</table>
	<TABLE border="0" width="95%">
	<TBODY>
	  $top_print
	  
          <TR>
            <TD height="39">
            <TABLE border="0" width=100% bgcolor="$FCOLOR2" CLASS=CC>
              <TBODY>
                <TR>
                  <TD colspan="5"><FONT color="#ffffcc" >스테이터스</FONT></TD>
                  <TD><FONT color="#ffffcc" >커멘드</FONT></TD>
		<TD>$clock
		</TD></FORM>
                <TD bgcolor=$FCOLOR2>
		<form action="./top.cgi" method="post">
		<input type=hidden name=id value=$mid>
		<input type=hidden name=pass value=$mpass>
		<input type=submit CLASS=MFC value="갱신">
		</TD></form>
                </TR>
                <TR>
                  <TD bgcolor="$ELE_C[$mele]" width="50" rowspan="4"><img src="./img/chara/$mchara.gif"></TD>
                  <TD bgcolor="$ELE_C[$mele]" width="10%">LV</FONT></TD>
                  <TD bgcolor="$ELE_C[$mele]" width="10%">$mlv</FONT></TD>
                  <TD bgcolor="$ELE_C[$mele]" width="10%">속성</FONT></TD>
                  <TD bgcolor="$ELE_C[$mele]" width="10%">$ELE[$mele]</FONT></TD>
                  <TD bgcolor="$ELE_C[$mele]" >훈련·전투</FONT></TD>
                  <TD bgcolor="$ELE_C[$mele]" >
		<form action="./battle.cgi" method="post">
		<input type=hidden name=id value=$mid>
		<input type=hidden name=pass value=$mpass>
		<SELECT name=mode> 
		    $dun
		    <OPTION value=1>◆ $town_name 평야
                    <OPTION value=2>◆ $town_name 늪지대
                    <OPTION value=3>◆ $town_name의 숲
		    <OPTION value=4>◆ $town_name의 탑
      		    <OPTION value="">===============
      		    <OPTION value=kunren>◆ 훈련
		    <OPTION value=toubatsu>◆ 토벌
		</SELECT>
		</TD>
                  <TD bgcolor="$ELE_C[$mele]" width=5%><INPUT type="submit" CLASS=MFC value="실행" onSubmit="return" check()></FONT></TD>
                </form></TR>
                <TR>
                  <TD bgcolor="$ELE_C[$mele]" width="10%">HP</FONT></TD>
                  <TD bgcolor="$ELE_C[$mele]" width="10%">$mhp/$mmaxhp</FONT></TD>
                  <TD bgcolor="$ELE_C[$mele]" width="10%">직업</FONT></TD>
                  <TD bgcolor="$ELE_C[$mele]" width="10%">$JOB[$mclass]</FONT></TD>
                  <TD bgcolor="$ELE_C[$mele]">거리의 시설</FONT></TD>
                  <TD bgcolor="$ELE_C[$mele]">
		<form action="./town.cgi" method="post">
		<input type=hidden name=id value=$mid>
		<input type=hidden name=pass value=$mpass>
		  <SELECT name=mode>
		　  $shop
                    <OPTION value=inn>◆ 여인숙
                    <OPTION value=arm>◆ 무기가게
                    <OPTION value=pro>◆ 방어구가게
                    <OPTION value=acc>◆ 악세사리가게
                    <OPTION value=item>◆ 아이템가게
                    <OPTION value=bank>◆ 은행
                    <OPTION value=arena>◆ 투기장
				    <OPTION value=hinn>◆ 고급 여관
                    <OPTION value=fshop>◆ 옥션
					<OPTION value=jeryon>◆ 제련소
					<OPTION value=quest>◆ 의뢰소(퀘스트)
                    <OPTION value=battle_entry>◆ 천하 제일 무도회
      		</SELECT></TD>
                  <TD bgcolor="$ELE_C[$mele]" width=5%>
		<INPUT type="submit" CLASS=MFC value="실행" onSubmit="return" check()>
		</FONT></TD></form>
                </TR>
                <TR>
                  <TD bgcolor="$ELE_C[$mele]" width="10%">MP</FONT></TD>
                  <TD bgcolor="$ELE_C[$mele]" width="10%">$mmp/$mmaxmp</FONT></TD>
                  <TD bgcolor="$ELE_C[$mele]" width="10%">숙련도<br><b>$TYPE[$mtype]</b>숙련도</FONT></TD>
                  <TD bgcolor="$ELE_C[$mele]" >$mabp<br>$mjp[$mtype]</FONT></TD>
                  <TD bgcolor="$ELE_C[$mele]">캐릭터의 확인·변경</FONT></TD>
                  <TD bgcolor="$ELE_C[$mele]">
		<form action="./status.cgi" method=post>
		<input type=hidden name=id value=$mid>
		<input type=hidden name=pass value=$mpass>
		<SELECT name=mode> 
		    $status
				    <OPTION value=status>◆ 스테이터스 체크
                    <OPTION value=equip>◆ 아이템의 사용/장비
					<OPTION value=chang>◆ 아이템 창고
					<OPTION value=macro>◆ 인증하기
					<OPTION value=bong>◆ 봉급받기
                    <OPTION>==== 송금·택배 ====
                    <OPTION value=money_send>◆ 송금
                    <OPTION value=item_send>◆ 아이템 택배
                    <OPTION>==== 기술·어빌리티 ====
                    <OPTION value=tec_set>◆ 기술의 변경
                    <OPTION value=sk_set>◆ 어빌리티의 변경
                    <OPTION value=skill>◆ 어빌리티의 취득/수행
                    <OPTION>==== 직업 ====
                    <OPTION value=change>◆ 직업의 변경
                    <OPTION value=getabp>◆ 숙련도의 취득
                    <OPTION>==== 연금 ====
                    <OPTION value=renkin>◆ 아이템의 작성
                    <OPTION>==== 커스터마이즈 ====
                    <OPTION value=jc>◆ 전용 아이콘의 변경
                    <OPTION value=data_change>◆ 아이콘의 변경
                    <OPTION value=prof_edit>◆ 프로필 변경
                    <OPTION>==== 그 외 ====
                    <OPTION value=hero>◆ 전설의 영웅에게 등록
                    <OPTION value=backup>◆ 백업
                    <OPTION value=con_renew>◆ 소속국 정보의 갱신
                    </SELECT></TD>
                  <TD bgcolor="$ELE_C[$mele]" width=5%><INPUT type="submit" CLASS=MFC value="실행" onSubmit="return" check()></FONT></TD>
		  </form>
                </TR>
                <TR>
                  <TD bgcolor="$ELE_C[$mele]" width="10%">경험치</FONT></TD>
                  <TD bgcolor="$ELE_C[$mele]" width="10%">$mex</FONT></TD>
                  <TD bgcolor="$ELE_C[$mele]" width="10%">명성</FONT></TD>
                  <TD bgcolor="$ELE_C[$mele]" width="10%">$mcex</FONT></TD>
                  <TD bgcolor="$ELE_C[$mele]">군사·내정</FONT></TD>
                  <TD bgcolor="$ELE_C[$mele]">
		<form action="./country.cgi" method="post">
		<input type=hidden name=id value=$mid>
		<input type=hidden name=pass value=$mpass>
		<SELECT name=mode> 
		  <OPTION>====== 교류 ======
                    <OPTION value=all_conv selected>◆ 전국 게시판
                    <OPTION value=con_conv>◆ $con_name국 게시판
                    <OPTION value=all_rule>◆ 전국 룰
                    <OPTION value=rule>◆ $con_name국 룰
                    <OPTION value=king_conv>◆ 직무 회의
                    <OPTION>====== 내정 ======
                    <OPTION value=money_get>◆ 수익금의 회수
					<OPTION value=set_tax>◆ 사냥세 설정
					<OPTION value=set_about>◆ 홍보문 설정
					<OPTION value=set_gmoney>◆ 최소 수금액 결정
					<OPTION value=set_bong>◆ 봉금 수당 결정
                    <OPTION value=suport_money>◆ 자금 원조
                    <OPTION value=town_up>◆ 거리의 개발
                    <OPTION value=ram_up>◆ 성벽의 강화
                    <OPTION value=ram_down>◆ 계략
                    <OPTION value=town_arm>◆ 무기·방어구 개발
					<OPTION value=sirei>◆ 지령의 변경
					<OPTION value=unit>◆ 부대 편성
					<OPTION>====== 왕·직무 ======
					<OPTION value=king_com>◆ 직무의 임명
					<OPTION value=king_change>◆ 국왕의 교대
					<OPTION value=discharge>◆ 해고
					<OPTION>====== 경비 ======
                    <OPTION value=def>◆ 거리의 수비
                    <OPTION value=def_out>◆ 수비 해제
                    <OPTION >=======독립=========
                    <OPTION value=con_change>◆ 망명
                    <OPTION value=con_change3>◆ 하야
                    <OPTION value=build>◆ 건국
                    </SELECT></TD>
                  <TD bgcolor="$ELE_C[$mele]" width=5%>
		<INPUT type="submit" CLASS=MFC value="실행" onSubmit="return" check()></FONT></TD>
		</form>
                </TR>
                <TR>
                  <TD bgcolor="$ELE_C[$mele]" width="72">$mname ($cond)</FONT></TD>
                  <TD bgcolor="$ELE_C[$mele]" width="10%">자금<br>은행</FONT></TD>
                  <TD bgcolor="$ELE_C[$mele]" width="34">$mgold<br>$mbank</FONT></TD>
                  <TD bgcolor="$ELE_C[$mele]" colspan=2><marquee>$qn</marquee></FONT></TD>
                  <TD bgcolor="$ELE_C[$mele]">그 외</FONT></TD>
                  <TD bgcolor="$ELE_C[$mele]">
		<form action="./etc.cgi" method="post">
		<input type=hidden name=id value=$mid>
		<input type=hidden name=pass value=$mpass>
		<SELECT name=mode> 
		　　<OPTION value=move selected>◆ 이동
                    <OPTION value=inv>◆ 거리 공격
		    <OPTION value=mode_change>◆ \표\시모드의 변경
     		 </SELECT>
		</TD>
                  <TD bgcolor="$ELE_C[$mele]" width=5%>
		<INPUT type="submit" CLASS=MFC value="실행" onSubmit="return" check()></FONT>
		</TD></FORM>
                </TR>
            <TR>
                  <TD bgcolor="$ELE_C[$mele]" colspan=5>
				  <!---------------------------------->
				
				 <!---------------------------------->
				  </FONT></TD>
                  <TD bgcolor="$ELE_C[$mele]">조합</FONT></TD>
                  <TD bgcolor="$ELE_C[$mele]">
		<form action="./town.cgi" method="post">
		<input type=hidden name=id value=$mid>
		<input type=hidden name=pass value=$mpass>
		<!--<SELECT name=mode> 
		　　<OPTION value=johap selected>◆ 조합
            <OPTION value=recipe>◆ 주점(조합레시피)
     		 </SELECT>-->
			 &nbsp;&nbsp;5월 업데이트에 추가 예정 ^^
		</TD>
                  <TD bgcolor="$ELE_C[$mele]" width=5%>
		<INPUT type="submit" CLASS=MFC value="실행" onSubmit="return" check()></FONT>
		</TD></FORM>
                </TR>		
              </TBODY>
            </TABLE>
            </TD>
          </TR>
		  <TR>
		  <TD>
		  $pstatus
		  </TD>
		  </TR>
          <TR>
            <TD>
	    <table width=100% CLASS=CC>
	    <tr>
	    <td bgcolor="$ELE_BG[$con_ele]" width=50%>
	    	<font color="$ELE_C[$con_ele]" >사건</font>
	    </td>
	    </tr>
	    <tr>
	    <td bgcolor="$ELE_C[$con_ele]">
<script language="JavaScript1.2">
function start(){
 if (document.all)  scroller.start();
}
function stop(){
 if (document.all)  scroller.stop();
}
</script>
	    <font color="$ELE_BG[$con_ele]">
<table align=left width=100% onMouseOut="start()"  onMouseOver="stop()">
<tr><td>
<marquee id="scroller" direction=up marquee scrolldelay=50 scrollamount=1 truespeed onmouseout="javascript:scroller.start()" onmouseover="javascript:scroller.stop()" width="100%" height=70>
$maplog
</marquee>
</table>

		</font>
	    </td>
	    </tr></table>
	    </td>
          </TR>
	  
	  <TR>
            <TD>
	    <table width=100% CLASS=CC>
	    <tr>
	    <td bgcolor="000000"><font color="ffffff" >[힌트]<BR><BR>$MES[$mesr]<BR><BR>$todo</font></TD>
	    <td align=center bgcolor=ffffff width=15%><img src=\"./img/chara/hint.gif\"></td>
	    </tr>
		</table>

	    </td>
          </TR>
          <TR>
    <TD>
    <TABLE CLASS=TC WIDTH=100%>
	<TR><TD colspan=2 align=center>
	<font color=ffffcc>CHAT</font>
	</TD></TR>
	<TR><TD colspan=2 bgcolor=$FCOLOR2 align=center>
	<form action="./status.cgi" method="post">
	<input type=hidden name=id value=$mid>
	<input type=hidden name=pass value=$mpass>
	<input type=hidden name=mode value=chat>
	메세지：<input type=text name=mes size=60>
	<SELECT name=mes_sel>
		<option value=2>$con_name 국내에
		<option value=1>전원에게
		<option value=4>부대에
		$klist
		<option value=3>상대를 지정↓
	</SELECT>
        <input type=submit class=FC value=송신><BR>
	　　　　　　　　　　　　　　　　　　　　　　　보내는 상대의 이름을 입력：</font><input type=text name=aite size=20>
	<BR><br><br><b><알리미>로 오시면 더 빠른 대답을 들으실 수 있으며 잡담을 하면서 베네치아를 즐기실 수 있습니다^^*</b>
	<br><br>
	<br>
	</TD>
	</form>
	</TR>
	<TR>
	<TD bgcolor=$FCOLOR2 width=50% valign=top>
	<span style="font-size:12pt; font-weight:bold; font-family:Tahoma;">전원에게</span><br></font>
	$atable
	<span style="font-size:12pt; font-weight:bold; font-family:Tahoma;">$mname에게</span></font><br>
	$ktable
	<TD bgcolor=$FCOLOR2 width=50% valign=top>
	<span style="font-size:12pt; font-weight:bold; font-family:Tahoma;">$con_name국민에게</span></font>
	$ctable
	<span style="font-size:12pt; font-weight:bold; font-family:Tahoma;">부대에게</span></font><br>
	$btable
	</TD>
	</TR>
	</TD>
     </TABLE>
	</TD>
	</TR>
        </TBODY>
      </TABLE>
      </TD>
    </TR>
    
  </TBODY>
</TABLE>
<BR>
</CENTER>
<P><BR>
<BR>
</P>
EOF

if($s_time > 0){
print <<"EOM";
<SCRIPT LANGUAGE = "JavaScript">
  <!-- JavaScript
	to();
  //end -->
  </SCRIPT>

EOM
}

&footer;

exit;
1;

