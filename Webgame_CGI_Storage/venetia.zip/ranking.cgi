#!/usr/bin/perl
require './jcode.pl';
require './sub.cgi';
require './conf.cgi';
	&header;
	print"<table CLASS=TC width=100%><td align=center><font color=$FCOLOR2 size=4>플레이어 정보</font></td></table><BR>";
	open(IN,"./data/country.cgi") or &error2('나라 데이터를 열지 않았습니다.');
	@COU = <IN>;
	close(IN);
	$con_no=0;
	foreach(@COU){
		($con_id,$con_name,$con_ele,$con_gold,$con_king,$con_yaku,$con_cou,$con_mes,$con_etc) =split(/<>/);
		$con_name[$con_id]="$con_name";
		$c[$country_no]=0;
		open(IN,"./logfile/chara/$con_king.cgi");
		@KING_DATA = <IN>;
		close(IN);
		($eid,$epass,$ename,$eurl,$echara,$esex,$ehp,$emaxhp,$emp,$emaxmp,$eele,$estr,$evit,$eint,$efai,$edex,$eagi,$emax,$ecom,$egold,$ebank,$eex,$etotalex,$ejp,$eabp,$ecex,$eunit,$econ,$earm,$epro,$eacc,$etec,$esta,$epos,$emes,$ehost,$edate,$esyo,$eclass,$etotal,$ekati,$etype,$eoya,$eaup,$eflg,$eflg2,$eflg3,$eflg4,$eflg5) = split(/<>/,$KING_DATA[0]);
		
		$con_ele[$con_id]=$con_ele;
		$con_king[$con_id]="$ename";
		$con_table[$con_id].="<table CLASS=FC>";
		$con_table[$con_id].="<tr><td colspan=14 align=center bgcolor=$ELE_BG[$con_ele]><font color=$FCOLOR2 size=5><b>$con_name국</b></font></td></tr>";
		$con_table[$con_id].="<tr><td colspan=14 align=center CLASS=FC><font color=$FCOLOR>국왕：$con_king[$con_id]　속성：$ELE[$con_ele]　자금：$con_gold Gold</font></td></tr>";
		$con_table[$con_id].="<tr><td CLASS=TC><font color=$FCOLOR2>이름</font></td><td CLASS=TC><font color=$FCOLOR2>캐릭터</font></td><td width=7% CLASS=TC><font color=$FCOLOR2>속성</font><td width=7% CLASS=TC><font color=$FCOLOR2>HP</font></td><td width=7% CLASS=TC><font color=$FCOLOR2>MP</font></td><td width=7% CLASS=TC><font color=$FCOLOR2>력</font></td><td width=7% CLASS=TC><font color=$FCOLOR2>생명</font></td><td width=7% CLASS=TC><font color=$FCOLOR2>지력</font></td><td width=7% CLASS=TC><font color=$FCOLOR2>정신</font></td><td width=7% CLASS=TC><font color=$FCOLOR2>운</font></td><td width=7% CLASS=TC><font color=$FCOLOR2>속도</font></td><td width=7% CLASS=TC><font color=$FCOLOR2>명성</font></td><td width=7% CLASS=TC><font color=$FCOLOR2>직업</font></td><td width=7% CLASS=TC><font color=$FCOLOR2>전적</font></td></tr>";
		$con_no++;
	}
	$con_ele[0]=0;
	$con_table[0].="<table CLASS=FC>";
	$con_table[0].="<tr><td colspan=14 align=center bgcolor=$ELE_BG[0]><font color=$FCOLOR2 size=5><b>무소속</b></font></td></tr>";
		
	$dir="./logfile/chara";
	opendir(dirlist,"$dir");
	$i=0;
	while($file = readdir(dirlist)){
		if($file =~ /\.cgi/i){
			$datames = "검색：$dir/$file<br>\n";
			if(!open(cha,"$dir/$file")){
				&error("$dir/$file가 발견되지 않습니다.<br>\n");
			}
			@cha = <cha>;
			close(cha);
			$list[$i]="$file";
			($rid,$rpass,$rname,$rurl,$rchara,$rsex,$rhp,$rmaxhp,$rmp,$rmaxmp,$rele,$rstr,$rvit,$rint,$rfai,$rdex,$ragi,$rmax,$rcom,$rgold,$rbank,$rex,$rtotalex,$rjp,$rabp,$rcex,$runit,$rcon,$rarm,$rpro,$racc,$rtec,$rsta,$rpos,$rmes,$rhost,$rdate,$rsyo,$rclass,$rtotal,$rkati,$rtype) = split(/<>/,$cha[0]);
			push(@CL_DATA,"$rid<>$rpass<>$rname<>$rurl<>$rchara<>$rsex<>$rhp<>$rmaxhp<>$rmp<>$rmaxmp<>$rele<>$rstr<>$rvit<>$rint<>$rfai<>$rdex<>$ragi<>$rmax<>$rcom<>$rgold<>$rbank<>$rex<>$rcex<>$runit<>$rcon<>$rarm<>$rpro<>$racc<>$rtec<>$rsta<>$rpos<>$rmes<>$rhost<>$rdate<>$rsyo<>$rclass<>$rtotal<>$rkati<>$rtype<>\n");
		}
		if($mn>10000){&error("루프");}
		$mn++;
	}
	closedir(dirlist);
	@tmp = map {(split /<>/)[22]} @CL_DATA;
	@CL_DATA = @CL_DATA[sort {$tmp[$b] <=> $tmp[$a]} 0 .. $#tmp];

	foreach(@CL_DATA){
		($rid,$rpass,$rname,$rurl,$rchara,$rsex,$rhp,$rmaxhp,$rmp,$rmaxmp,$rele,$rstr,$rvit,$rint,$rfai,$rdex,$ragi,$rmax,$rcom,$rgold,$rbank,$rex,$rcex,$runit,$rcon,$rarm,$rpro,$racc,$rtec,$rsta,$rpos,$rmes,$rhost,$rdate,$rsyo,$rclass,$rtotal,$rkati,$rtype) = split(/<>/);
		$pid = &id_change("$rid");
		if($cont_cou[$rcon]<10 && $rcon ne 0){
			$con_table[$rcon].="<tr><td bgcolor=$ELE_C[$con_ele[$rcon]] size=2><a href=\"javascript:void(0);\" onClick=\"window.open('./status_print.cgi?id=$pid', 'newwin', 'width=600,height=400,scrollbars =yes')\">$rname</a></td><td bgcolor=$ELE_C[$con_ele[$rcon]]><img src=\"./img/chara/$rchara.gif\"></td><td bgcolor=$ELE_C[$con_ele[$rcon]]>$ELE[$rele]</td><td bgcolor=$ELE_C[$con_ele[$rcon]]>$rhp/$rmaxhp</td><td bgcolor=$ELE_C[$con_ele[$rcon]]>$rmp/$rmaxmp</td><td bgcolor=$ELE_C[$con_ele[$rcon]]>$rstr</td><td bgcolor=$ELE_C[$con_ele[$rcon]]>$rvit</td><td bgcolor=$ELE_C[$con_ele[$rcon]]>$rint</td><td bgcolor=$ELE_C[$con_ele[$rcon]]>$rfai</td><td bgcolor=$ELE_C[$con_ele[$rcon]]>$rdex</td><td bgcolor=$ELE_C[$con_ele[$rcon]]>$ragi</td><td bgcolor=$ELE_C[$con_ele[$rcon]]>$rcex</td><td bgcolor=$ELE_C[$con_ele[$rcon]]>$JOB[$rclass]</td><td bgcolor=$ELE_C[$con_ele[$rcon]]>$rtotal전$rkati승</td></tr>";
			$cont_cou[$rcon]++;
		}elsif(($cont_cou[$rcon] >=10 || $rcon eq 0) && $rurl eq ""){
			$con_table2[$rcon].="<font color=$ELE_BG[$con_ele[$rcon]] size=2><a href=\"javascript:void(0);\" onClick=\"window.open('./status_print.cgi?id=$pid', 'newwin', 'width=600,height=400,scrollbars =yes')\">$rname</a>,</font>";
			$cout_cou[$rcon]++;
		}
	}
	$con_no=0;
	foreach(@COU){
		($con_id,$con_name,$con_ele,$con_gold,$con_king,$con_yaku,$con_cou,$con_mes,$con_etc) =split(/<>/);
		$con_table[$con_id].="<tr><td colspan=14 CLASS=FC>$con_table2[$con_id]</td></tr></table><BR>";
		print"$con_table[$con_id]";
		$con_no++;
	}
	$con_table[0].="<tr><td colspan=14 CLASS=FC>$con_table2[0]</td></tr></table>";
	print"$con_table[0]<BR>";
	print"<center>플레이어수：$mn명</center><BR>";
&footer;
sub id_change {
	local($inpw) = $_[0];

	@yy = unpack("C*", $inpw);
	$word="";
	foreach(@yy){
		$word .= "$_\,";
	}
	chomp($word);
	$encrypt = reverse($word);

	return $encrypt;
}
exit;

