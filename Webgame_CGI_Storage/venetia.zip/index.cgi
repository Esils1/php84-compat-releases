#!/usr/bin/perl
require './jcode.pl';
require './sub.cgi';
require './conf.cgi';
&decode;
&header;

open(IN,"./data/count.cgi");
@counter = <IN>;
close(IN);

($count) =split(/<>/,$counter[0]);
$count++;

@N_COUNT=();
unshift(@N_COUNT,"$count<>\n");
open(OUT,">./data/count.cgi");
print OUT @N_COUNT;
close(OUT);


open(IN,"./data/guest_list.cgi");
@gue = <IN>;
close(IN);

foreach(@gue){
	($fname,$ftime,$fcon,$fhost) =split(/<>/);
	$glist.="<font color=$ELE_BG[$gcon]>★$fname</font>";
}
$player=@gue;

open(IN,"./data/maplog.cgi");
@MA = <IN>;
close(IN);
foreach(@MA){
	$mapl.="<font color=$FCOLOR>●$MA[$m]</font></b><BR>";
	$m++;
}

if($LINK1){$print.="<a href=\"$LINKURL1\" TARGET=\"_top\"><font color=ffffcc>[$LINK1]</font></a>　";}
$print.="<a href=\"entry.cgi\"><font color=ffffcc>[신규등록]</font></a>　";
$print.="<a href=\"login.cgi\"><font color=ffffcc>[계속하기]</font></a>　";
if($LINK2){$print.="<a href=\"$LINKURL2\" TARGET=\"_blank\"><font color=ffffcc>[$LINK2]</font></a>　";}
if($LINK3){$print.="<a href=\"$LINKURL3\" TARGET=\"_blank\"><font color=ffffcc>[$LINK3]</font></a>　";}
if($LINK4){$print.="<a href=\"$LINKURL4\" TARGET=\"_blank\"><font color=ffffcc>[$LINK4]</font></a>　";}
if($LINK5){$print.="<a href=\"$LINKURL5\" TARGET=\"_blank\"><font color=ffffcc>[$LINK5]</font></a>　";}
if($LINK6){$print.="<a href=\"$LINKURL6\" TARGET=\"_blank\"><font color=ffffcc>[$LINK6]</font></a>　";}
if($LINK7){$print.="<a href=\"$LINKURL7\" TARGET=\"_blank\"><font color=ffffcc>[$LINK7]</font></a>　";}
if($LINK8){$print.="<a href=\"$LINKURL8\" TARGET=\"_blank\"><font color=ffffcc>[$LINK8]</font></a>　";}
if($LINK9){$print.="<a href=\"$LINKURL9\" TARGET=\"_blank\"><font color=ffffcc>[$LINK9]</font></a>　";}
if($LINK10){$print.="<a href=\"$LINKURL10\" TARGET=\"_blank\"><font color=ffffcc>[$LINK10]</font></a>　";}
if($LINK11){$print.="<a href=\"$LINKURL11\" TARGET=\"_blank\"><font color=ffffcc>[$LINK11]</font></a>　";}
if($LINK12){$print.="<a href=\"$LINKURL12\" TARGET=\"_blank\"><font color=ffffcc>[$LINK12]</font></a>　";}
if($LINK13){$print.="<a href=\"$LINKURL13\" TARGET=\"_blank\"><font color=ffffcc>[$LINK13]</font></a>　";}
if($LINK14){$print.="<a href=\"$LINKURL14\" TARGET=\"_blank\"><font color=ffffcc>[$LINK14]</font></a>　";}

open(IN,"./data/country.cgi") or &error("나라 데이터 파일이 열리지 않습니다.");
@CON_DATA = <IN>;
close(IN);

$hongbolist = "<table class=FC width=100%>";
$c_no = 0;
foreach(@CON_DATA){
	($con_id,$con_name,$con_ele,$con_gold,$con_king,$con_yaku,$con_cou,$con_mes,$con_etc,$con_tax,$con_about,$con_ming) =split(/<>/);
	$hongbolist .= "<tr><td bgcolor=$ELE_BG[$con_ele]><font color=$ELE_C[$con_ele] face=바탕 size=3><b>$con_name국</td><td>$con_about 사냥세:$con_tax%</td></tr>";
	$c_no++;
}
$hongbolist .= "</table>";

print <<"EOF";
<CENTER>
<TABLE border="0" bgcolor="#242424" width="700" cellspacing="5" height="509">
  <TBODY>
    <TR>
      <TD colspan="2" width="696" height="25" bgcolor="#585858" align="center">
	<FONT style="font-size:9pt" color="#ffff99">
	$print
	</TD>
    </TR>
    <TR>
      <TD colspan="2" align="center" bgcolor="black" width="700" height="350">
	  <span style="font-size:36pt; font-family:Tahoma; color:red; font-weight:bold;">THE VENETIA II</span>
	  <BR>
      </TD>
    </TR>
    <TR>
      <TD colspan="2" bgcolor="white" width="696" height="23" align="left"><FONT style="font-size:15px" color="black">현재의 참가자($player인)：$glist</FONT></TD>
    </TR>
	<TR>
	<TD colspan="2" bgcolor="#c8c8c8">
	$hongbolist
	</TD>
	</TR>
    <TR>
      <TD colspan="2" bgcolor="#c8c8c8"><FONT style="font-size:15px" color="#666600"><최근의 정보><BR><span style="font-size:9pt;">$mapl</FONT><BR><font size=1>[Total $count Hit, Since 2007.04.17]</font></TD>
    </TR>
<TR><TD colspan="2" align="center">
	<font size=3 color=ffff99>
	<form method=post action=./adminiii.cgi>
	ID:<input type=text name=id size=7>
	PASS:<input type=pass name=pass size=7>
	<input type=submit value=관리자>
	</form>
	</font>
      </TD>
    </TR>
  </TBODY>
</TABLE>
<BR>
</P>
</CENTER>

<hr>
EOF

&footer;
exit;

