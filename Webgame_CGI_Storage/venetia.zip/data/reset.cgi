##############
# Reset Mode #
##############

sub RESET_MODE{

	open(IN,"./data/resetlog.cgi");
	@RESET = <IN>;
	close(IN);

	push(@RESET, "$ENV{'REMOTE_ADDR'} 리셋 시도. (리셋모드:1) ");

	open(OUT, "./data/resetlog.cgi');
	print OUT @RESET;
	close(OUT);

}
sub RESET_MODE2{

	open(IN,"./data/resetlog.cgi");
	@RESET = <IN>;
	close(IN);

	push(@RESET, "$ENV{'REMOTE_ADDR'} 리셋 시도. (리셋모드:2) ");

	open(OUT, "./data/resetlog.cgi');
	print OUT @RESET;
	close(OUT);

}
1;


