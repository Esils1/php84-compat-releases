#!/usr/bin/perl

#################################################################
#   【면책 사항】                                                #
#    이 스크립트는 프리 소프트입니다.이 스크립트를 사용했다 #
#    어떠한 손해에 대해서 작자는 일절의 책임을 지지 않습니다.         #
#    또 설치에 관한 질문은 서포트 게시판에 부탁드리겠습니다.   #
#    직접 메일에 의한 질문은 일절 받고있지 않습니다.       #
#################################################################

require 'jcode.pl';
require './conf.cgi';
require 'sub.cgi';

if($MENTE) { &error2("점검 안입니다.잠깐 기다려 주세요."); }
&decode;
&STATUS_PRINT2;

sub STATUS_PRINT2 {

	#&SERVER_STOP;
	$chid = decrypt($in{'id'});

	open(IN,"./logfile/chara/$chid.cgi") or &error2("파일을 열지 않았습니다.err no :$in{'id'}");
	@E_DATA = <IN>;
	close(IN);
	($eid,$epass,$ename,$eurl,$echara,$esex,$ehp,$emaxhp,$emp,$emaxmp,$eele,$estr,$evit,$eint,$efai,$edex,$eagi,$emax,$ecom,$egold,$ebank,$eex,$etotalex,$ejp,$eabp,$ecex,$eunit,$econ,$earm,$epro,$eacc,$etec,$esta,$epos,$emes,$ehost,$edate,$esyo,$eclass,$etotal,$ekati,$etype,$eoya,$esk,$eflg,$eflg2,$eflg3,$eflg4,$eflg5) = split(/<>/,$E_DATA[0]);
	$elv = int($eex/100)+1;
	&equip_open;
		
	open(IN,"./data/ability.cgi");
	@ABILITY = <IN>;
	close(IN);

	$abname1="－";
	$abname2="－";
	$abname3="－";
	foreach(@ABILITY){
		($abno,$abname,$abcom,$abdmg,$abrate,$abpoint,$abclass,$abtype) =split(/<>/);
		if($earmsta eq $abno){
			$abname1=$abname;
		}
		if($eprosta eq $abno){
			$abname2=$abname;
		}
		if($eaccsta eq $abno){
			$abname3=$abname;
		}
		$j++;
	}

	open(IN,"./logfile/prof/$eid.cgi");
	@PROF_DATA = <IN>;
	close(IN);

	if(@PROF_DATA == ()){
		$com1="코멘트가 등록되지 않았습니다.";
	}
	else{
		$com1="@PROF_DATA";
	}


	open(IN,"./data/country.cgi") or &error2('파일을 열지 않았습니다.err no :country');
	@COU_DATA = <IN>;
	close(IN);
	$country_no=0;$hit=0;
	foreach(@COU_DATA){
		($con2_id,$con2_name,$con2_ele,$con2_gold,$con2_king,$con2_yaku,$con2_cou,$con2_mes,$con2_etc) =split(/<>/);
		if("$con2_id" eq "$econ"){$hit=1;last;}
		$country_no++;
	}

	if(!$hit){
		$con2_id=0;
		$con2_name="무소속";
		$con2_ele=0;
	}
	open(IN,"./logfile/history/$eid.cgi");
	@HIS_DATA = <IN>;
	close(IN);
	$history="<table bgcolor=$ELE_BG[$con2_ele] width=100%>";
	$history.="<tr><td><font color=ffffff>소속</font></td><td><font color=ffffff>년월</font></td><td><font color=ffffff>사건</font></td></tr>";
	foreach(@HIS_DATA){
		($hcom,$hcon,$htime) =split(/<>/);
		$history.="<tr><td bgcolor=$ELE_C[$con2_ele]>$hcon국</td><td bgcolor=$ELE_C[$con2_ele] width=15%>$htime</td><td bgcolor=$ELE_C[$con2_ele]>$hcom</td></tr>";
	}
	$history.="</table>";

	&header;

print <<"EOM";
<TABLE border="0" width="80%" bgcolor="#000000" align=center>
  <TBODY>
    <TR>
      <TD colspan="7" bgcolor="$ELE_BG[$con2_ele]" align="center"><font color=ffffff>【$ename의 정보】</font></TD>
    </TR>
    <TR>
      <TD bgcolor="$ELE_C[$con2_ele]" rowspan="5" width=10%><img src="./img/chara/$echara.gif"></TD>
      <TD bgcolor="$ELE_BG[$con2_ele]"><font color=$ELE_C[$con2_ele]>소속국</font></TD>
      <TD bgcolor="$ELE_C[$con2_ele]">$con2_name국</TD>
      <TD bgcolor="$ELE_BG[$con2_ele]"><font color=$ELE_C[$con2_ele]>속성</font></TD>
      <TD bgcolor="$ELE_C[$con2_ele]">$ELE[$eele]</TD>
      <TD bgcolor="$ELE_BG[$con2_ele]"><font color=$ELE_C[$con2_ele]>직업</font></TD>
      <TD bgcolor="$ELE_C[$con2_ele]">$JOB[$eclass]</TD>
    </TR>
    <TR>
      <TD bgcolor="$ELE_BG[$con2_ele]"><font color=$ELE_C[$con2_ele]>LV</font></TD>
      <TD bgcolor="$ELE_C[$con2_ele]">$elv</TD>
      <TD bgcolor="$ELE_BG[$con2_ele]"><font color=$ELE_C[$con2_ele]>HP</font></TD>
      <TD bgcolor="$ELE_C[$con2_ele]">$ehp/$emaxhp</TD>
      <TD bgcolor="$ELE_BG[$con2_ele]"><font color=$ELE_C[$con2_ele]>MP</font></TD>
      <TD bgcolor="$ELE_C[$con2_ele]">$emp/$emaxmp</TD>
      </TR>
    <TR>
      <TD bgcolor="$ELE_BG[$con2_ele]"><font color=$ELE_C[$con2_ele]>힘</font></TD>
      <TD bgcolor="$ELE_C[$con2_ele]">$estr</TD>
      <TD bgcolor="$ELE_BG[$con2_ele]"><font color=$ELE_C[$con2_ele]>생명</font></TD>
      <TD bgcolor="$ELE_C[$con2_ele]">$evit</TD>
      <TD bgcolor="$ELE_BG[$con2_ele]"><font color=$ELE_C[$con2_ele]>지력</font></TD>
      <TD bgcolor="$ELE_C[$con2_ele]">$eint</TD>
    </TR>
    <TR>
      <TD bgcolor="$ELE_BG[$con2_ele]"><font color=$ELE_C[$con2_ele]>정신</font></TD>
      <TD bgcolor="$ELE_C[$con2_ele]">$efai</TD>
      <TD bgcolor="$ELE_BG[$con2_ele]"><font color=$ELE_C[$con2_ele]>운</font></TD>
      <TD bgcolor="$ELE_C[$con2_ele]">$edex</TD>
      <TD bgcolor="$ELE_BG[$con2_ele]"><font color=$ELE_C[$con2_ele]>속도</font></TD>
      <TD bgcolor="$ELE_C[$con2_ele]">$eagi</TD></TR>
    <TR>
      <TD bgcolor="$ELE_BG[$con2_ele]"><font color=$ELE_C[$con2_ele]>전적</font></TD>
      <TD bgcolor="$ELE_C[$con2_ele]">$etotal전$ekati승</TD>
      <TD bgcolor="$ELE_BG[$con2_ele]"><font color=$ELE_C[$con2_ele]>명성</font></TD>
      <TD bgcolor="$ELE_C[$con2_ele]">$ecex</TD>
      <TD bgcolor="$ELE_BG[$con2_ele]"><font color=$ELE_C[$con2_ele]>넘어뜨린 인원수</font></TD>
      <TD bgcolor="$ELE_C[$con2_ele]">$eflg2인</TD>
    </TR>
    <TR>
      <TD bgcolor="$ELE_BG[$con2_ele]"><font color=$ELE_C[$con2_ele]>무기</font></TD>
      <TD bgcolor="$ELE_C[$con2_ele]" colspan=3>$earmname($ELE[$earmele])</TD>
      <TD bgcolor="$ELE_C[$con2_ele]" align=center>$abname1</TD>
      <TD bgcolor="$ELE_C[$con2_ele]" colspan=2 align=right>$earmdmg/$earmwei</TD>
    </TR>
    <TR>
      <TD bgcolor="$ELE_BG[$con2_ele]"><font color=$ELE_C[$con2_ele]>방어구</font></TD>
      <TD bgcolor="$ELE_C[$con2_ele]" colspan=3>$eproname($ELE[$eproele])</TD>
      <TD bgcolor="$ELE_C[$con2_ele]" align=center>$abname2</TD>
      <TD bgcolor="$ELE_C[$con2_ele]" colspan=2 align=right>$eprodmg/$eprowei</TD>
    </TR>
    <TR>
      <TD bgcolor="$ELE_BG[$con2_ele]"><font color=$ELE_C[$con2_ele]>악세사리</font></TD>
      <TD bgcolor="$ELE_C[$con2_ele]" colspan=3>$eaccname($ELE[$eaccele])</TD>
      <TD bgcolor="$ELE_C[$con2_ele]" align=center>$abname3</TD>
      <TD bgcolor="$ELE_C[$con2_ele]" colspan=2 align=right>$eaccdmg/$eaccwei</TD>
    </TR>
    <TR>
      <TD colspan="7" bgcolor="$ELE_BG[$con2_ele]"><FONT color="$ELE_C[$con2_ele]">$ename의 프로필</FONT></TD>
    </TR>
    <TR>
      <TD colspan="7" bgcolor="$ELE_C[$con2_ele]">$com1</TD>
    </TR>
    <TR>
      <TD colspan="7" bgcolor="$ELE_BG[$con2_ele]"><FONT color="$ELE_C[$con2_ele]">$ename의 경력</FONT></TD>
    </TR>
    <TR>
      <TD colspan="7" bgcolor="$ELE_C[$con2_ele]">$history</TD>
    </TR>
  </TBODY>
</TABLE>

EOM
	&footer;
	exit;
}

#----------------------#
#  패스워드 조합 처리  #
#----------------------#
sub decrypt {
	local($inpw) = @_;
	$encrypt = reverse($inpw);
	@dec = split(/\,/,"$encrypt");
	$inpw = pack("C*", @dec);
	
	return $inpw;
}

