package Nfile;

sub new {
    my ($class, $file, $mode) = @_;

    my $self = {
        file => $file,
        mode => $mode,
    };

    bless $self, $class;
    return $self;
}

sub read {
    my $self = shift;
    my @lines = ();

    if (open(my $fh, '<', $self->{file})) {
        @lines = <$fh>;
        close($fh);
    }

    return @lines;
}

1;