#!/usr/bin/perl
require './jcode.pl';
require './sub.cgi';
require './conf.cgi';
&decode;


open(IN,"./data/apo.cgi");
@apo = <IN>;
close(IN);
&host_name;
$timer = time() ;@newapo=();
if(length($in{'name'})>20){&error("닉네임이 너무 깁니다.");}
foreach(@apo) {
	($gname,$gid,$gtime) =split(/<>/);
	if($timer>$gtime+900){next;}
	elsif($in{'id'} eq $gid){
		&error2("예\약\이 끝난 상태입니다.");
	}
	else{
		push(@newapo,"$gname<>$gid<>$gtime<>\n");
	}
}
	push(@newapo,"$in{'name'}<>$in{'id'}<>$timer<>\n");

open(OUT,">./data/apo.cgi") or &error('타운 데이터를 쓸 수 없습니다.');
print OUT @newapo;
close(OUT);

&header;

print <<"EOF";
<BR>
<BR>
<CENTER>
<form action="index.cgi" method="POST">
<TABLE border="0" width="200" CLASS=FC>
  <TBODY>
    <TR>
      <TD bgcolor=$FCOLOR colspan=2 align=center><font size=3 color=$FCOLOR2>예\약\완료</font></TD>
    </TR>
    <TR>
      <TD colspan="2" align=center>
	<input type=hidden name=id value=$mid>
    	<input type=submit CLASS=FC value=TOP우와></TD>
    </TR>
  </TBODY>
</TABLE>
</CENTER>
</form>
EOF
&footer;
exit;

