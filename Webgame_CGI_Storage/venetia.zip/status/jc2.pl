sub jc2{
	&header;
	&chara_open;
	if($in{'chara'} eq ""){&error("올바르게 선택되지 않았습니다.");}
	$mgold-=100000;
	if($mgold<0){&error("돈이 충분하지 않습니다.");}
	$mchara="$in{'chara'}";
	print <<"EOF";
<TABLE border="0" width="80%" bgcolor="#ffffff" height="150" align=center CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">아이콘의 변경</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="./img/etc/inn2.gif"></TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc">아이콘을 변경했습니다.</FONT></TD>
    </TR>
    <TR>
      <TD colspan="2" align="right">
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value=돌아온다></form></TD>
	
    </TR>
  </TBODY>
</TABLE>
EOF
	&chara_input;
	&footer;
	exit;
}
1;

