sub macro {
	&chara_open;
	&status_print;

	$no1 = int(rand(8))+1;
	$no2 = int(rand(8))+1;

	$no = $no1*10 + $no2;

	&header;
	
	print <<"EOF";
<TABLE border="0" width="80%" align=center bgcolor="#ffffff" height="150" CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">인증하기</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="./img/etc/inn2.gif"></TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc">매크로 플레이를 방지하기 위해 인증하기를 도입했습니다.<br>한번 인증을 하면 45분동안 유효합니다. 틀릴 경우 로그에 남게 됩니다.</FONT></TD>
    </TR>
    <TR>
      <TD colspan="2" align="center">
	<table border=0 width="100%" bgcolor=$FCOLOR CLASS=TC>
	<tr><td colspan=6 align=center><font color=ffffcc>다음 숫자를 입력해 주세요. 숫자는 2자리입니다.</font></td></tr>
	<tr>
	<td bgcolor=ffffcc><center><img src="./images/$no1.gif"><img src="./images/$no2.gif"></td>
	</tr>
	<form action="./status.cgi" method="post">
	$jobtable
	<TR><TD colspan=6 align=center bgcolor="ffffff">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=hidden name=mode value=macro2>
	<INPUT type=hidden name=verify2 value=$no>
	<INPUT type=text name=verify size=10 maxlength=2 style="font-size:24pt; letter-spacing:-1px; font-weight:bold; text-align:center; font-family:Tahoma;">
	<INPUT type=submit CLASS=FC value=인증한다></TD></TR></form>
	</table>

	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value=돌아온다></form></TD>
	
    </TR>
  </TBODY>
</TABLE>
<center></center>
EOF

	&footer;
	exit;
}
1;

