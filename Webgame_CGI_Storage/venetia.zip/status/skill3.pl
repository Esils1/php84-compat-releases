sub skill3{
	&chara_open;

	#능력 상승에 필요한 숙련도
	$point=int(($mmaxstr+$mmaxvit+$mmaxint+$mmaxmen+$mmaxdex+$mmaxagi-1000)/20);
	$uppoint=$point*$point;
	if($uppoint>10000){$uppoint=10000;}

	$mabp-=$uppoint;
	if($mabp < 0){&error("숙련도가 충분하지 않습니다.");}

	if(int(rand(15)) eq 1){
		$coment="$mname는 급성장했습니다!";
		&maplog("<font color=orange>[급성장]</font>$mname는 급성장을 이루었습니다!");
		$rate=5;
	}
	elsif(int(rand(100)) eq 1){
		$coment="$mname는 각성 했습니다!";
		&maplog("<font color=red>[각성]</font>$mname는 각성 했다!");
		$rate=15;
	}
	else{
		$coment="한계치가 상승했습니다.";
		$rate=1;
	}
	$com.="$coment<BR>";
	$mmaxstr += $JMAX[$mtype][0]*$rate;
	$mmaxvit += $JMAX[$mtype][1]*$rate;
	$mmaxint += $JMAX[$mtype][2]*$rate;
	$mmaxmen += $JMAX[$mtype][3]*$rate;
	$mmaxdex += $JMAX[$mtype][4]*$rate;
	$mmaxagi += $JMAX[$mtype][5]*$rate;
	if($mmaxstr>=400){$mmaxstr = 400;}
	if($mmaxvit>=400){$mmaxvit = 400;}
	if($mmaxint>=400){$mmaxint = 400;}
	if($mmaxmen>=400){$mmaxmen = 400;}
	if($mmaxdex>=400){$mmaxdex = 400;}
	if($mmaxagi>=400){$mmaxagi = 400;}
	$mmax="$mmaxstr,$mmaxvit,$mmaxint,$mmaxmen,$mmaxdex,$mmaxagi,$mmaxlv";

	&chara_input;
	&header;
	
	print <<"EOF";
<TABLE border="0" width="80%" bgcolor="#ffffff" height="150" align=center CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">수행</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="./img/etc/palace2.gif"></TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc">$mname는<font color=red>수행을 실시했습니다.<BR>$coment</FONT></TD>
    </TR>
    <TR>
      <TD colspan="2" align="right">
	<form action="./status.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=hidden name=mode value=skill>
	<INPUT type=submit CLASS=FC value=취득 화면에></form></TD>
	
    </TR>
  </TBODY>
</TABLE>
EOF
	&chara_input;
	&footer;
	exit;
}
1;

