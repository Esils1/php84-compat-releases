sub bong{
	&chara_open;
	&town_open;
	&con_open;

	$how = "약";
	$how .= int(($mbong - time) / 3600 * 100) / 100;
	$how .= "시간";

	&error("봉급을 받을 수 없습니다. $how이 지난 후에 받을 수 있습니다.") if $mbong > time;

	$gold = $con_bong * $mcex;

	&error("받을 봉급이 없습니다.") if $gold < 1;

	$mgold += $gold;
	$con_gold -= $gold;
	&error("국고가 부족합니다.") if $con_gold<0;

	&maplog("<b><font color=green>[급여]</font></b>$mname님은 $con_name국에서 하루치의 급여($gold골드)를 받았습니다.");

	&con_input;

	&header;
	
	print <<"EOF";
<TABLE border="0" width="80%" bgcolor="#ffffff" height="150" align=center CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">급여 받기</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="./img/etc/inn2.gif"></TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc">$gold골드를 받았습니다.</FONT></TD>
    </TR>
    <TR>
      <TD colspan="2" align="right">
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value=돌아온다></form></TD>
	
    </TR>
  </TBODY>
</TABLE>
EOF
	&chara_input;
	&footer;
	exit;
}
1;

