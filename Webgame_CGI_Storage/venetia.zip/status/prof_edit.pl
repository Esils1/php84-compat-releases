#_/_/_/_/_/_/_/_/_/#
#_/    프로필    _/#
#_/_/_/_/_/_/_/_/_/#

sub prof_edit {

	&chara_open;
	&con_open;
    	
	open(IN,"./logfile/prof/$mid.cgi");
	@PROF_DATA = <IN>;
	close(IN);

	if(@PROF_DATA == ()){
		$com1="거주지：\n를 좋아하는 음식：\n취미：\n 마지막에 한마디：";
		$com2="코멘트가 등록되지 않았습니다.";
	}
	else{
		$com2="@PROF_DATA";
	}
	&header;
	print <<"EOM";
<TABLE CLASS=TC WIDTH="100%" height=100%>
<TBODY><TR>
<TD BGCOLOR=$FCOLOR WIDTH=100% height=5>　<font color=$FCOLOR2 size=4>　　　＜＜<B> * 프로필의 갱신 *</B>＞＞</font></TD>
</TR><TR>
<TD height="5">
<TABLE border="0" width=100%><TBODY>
<TR><TD><img src=\"./img/etc/house.gif\"></TD><TD width="100%" bgcolor=000000><font color=ffffff>프로필의 갱신을 실시할 수 있습니다.<BR>자유롭게 코멘트를 기입해 주세요.</font></TD>
</TR>
</TBODY></TABLE>
</TD>
</TR><TR>
<TD WIDTH=100% align=center bgcolor=$FCOLOR2>
<form action="top.cgi" method="post">
<input type=hidden name=id value=$mid>
<input type=hidden name=pass value=$mpass>
<input type=submit CLASS=FC value="도시로 돌아온다"></form>
</TD>
</TR>
<TR>
<td colspan=2 bgcolor=$FCOLOR2 align=center>
<table CLASS=TC width=80%>
<tr>
<TD align=center><font color=$FCOLOR2>$mname의 프로필</font></TD>
</tr>
<tr>
<TD bgcolor=000000><font color=$FCOLOR2>$com2</font></TD>
</tr>
</table>
</td>
</TR>
<TR>
<TD align=center bgcolor=$FCOLOR2>

<br><form action="./status.cgi" method="post">
코멘트：<BR>
<textarea name=message cols=50 rows=10>$com1
</TEXTAREA> <img src="./img/chara/$mchara.gif"><p>
<input type=hidden name=id value=$mid>
<input type=hidden name=pass value=$mpass>
<input type=hidden name=mode value=prof_write>
<input type=submit CLASS=MFC value="프로필 갱신">
</form>
</font>

</CENTER>
</TD>
</TR>
</TBODY></TABLE>
EOM

	&footer;
	exit;
}
1;
