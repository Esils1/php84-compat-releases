sub hero{
	&chara_open;
	&town_open;
	&con_open;

	open(IN,"./data/hero.cgi");
	@HERO = <IN>;
	close(IN);

	$num = @HERO-1;

	($bid,$bpass,$bname,$bchara,$bsex,$bhp,$bmaxhp,$bmp,$bmaxmp,$bele,$bstr,$bvit,$bint,$bfai,$bdex,$bagi,$bmax,$bcon,$bclass,$btotal,$bkati,$bpoint) = split(/<>/,$HERO[$num]);

	$mpoint=int(($mmaxhp+$mmaxmp)/3) +$mstr+$mvit+$mint+$mfai+$mdex+$magi;

	if($bpoint > $mpoint && $num > 8){
		&error("\능\력\값이 충분하지 않습니다.필\요\능\력치：$bpoint\포인트 현재：$mpoint\n")
	}
	foreach(@HERO) {
		($bid,$bpass,$bname,$bchara,$bsex,$bhp,$bmaxhp,$bmp,$bmaxmp,$bele,$bstr,$bvit,$bint,$bfai,$bdex,$bagi,$bmax,$bcon,$bclass,$btotal,$bkati,$bpoint) = split(/<>/);

		if("$bid" eq "$in{'id'}"){
			splice(@HERO,$i,1,"$mid<>$mpass<>$mname<>$mchara<>$msex<>$mhp<>$mmaxhp<>$mmp<>$mmaxmp<>$mele<>$mstr<>$mvit<>$mint<>$mfai<>$mdex<>$magi<>$mmax<>$mcon<>$mclass<>$mtotal<>$mkati<>$mpoint<>\n");
			$flg=1;
			last;
		}
		$i++;
	}

	if(!$flg){
		unshift(@HERO,"$mid<>$mpass<>$mname<>$mchara<>$msex<>$mhp<>$mmaxhp<>$mmp<>$mmaxmp<>$mele<>$mstr<>$mvit<>$mint<>$mfai<>$mdex<>$magi<>$mmax<>$mcon<>$mclass<>$mtotal<>$mkati<>$mpoint<>\n");
	}

	@tmp = map {(split /<>/)[21]} @HERO;
	@HERO = @HERO[sort {$tmp[$b] <=> $tmp[$a]} 0 .. $#tmp];

	$num = @HERO;
	if($num > 10) { pop(@HERO); }

	open(OUT,">./data/hero.cgi") or &error('새로운 데이터를 쓸 수 없습니다.');
	print OUT @HERO;
	close(OUT);

	&header;
	
	print <<"EOF";
<TABLE border="0" width="80%" bgcolor="#ffffff" height="150" align=center CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">등록</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="./img/etc/inn2.gif"></TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc">전설의 영웅에게 등록되었습니다!축하합니다 있습니다!</FONT></TD>
    </TR>
    <TR>
      <TD colspan="2" align="right">
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value=돌아온다></form></TD>
	
    </TR>
  </TBODY>
</TABLE>
EOF
	&chara_input;
	&footer;
	exit;
}
1;

