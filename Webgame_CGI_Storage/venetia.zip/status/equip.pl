sub equip{
	&chara_open;
	&status_print;
	&equip_open;
	open(IN,"./logfile/item/$mid.cgi");
	@ITEM = <IN>;
	close(IN);
	$no2=0;
	foreach(@ITEM){
		($it_no,$it_ki,$it_name,$it_val,$it_dmg,$it_wei,$it_ele,$it_hit,$it_cl,$it_type,$it_sta,$it_flg) =split(/<>/);
		$sel_val=int($it_val/2);
		if($it_ki>=0 && $it_ki<=3){$ittable.="<TR><TD width=5% bgcolor=ffffcc><input type=radio name=itno value=$no2></TD><TD bgcolor=white><font size=2>$it_name</font></TD><TD bgcolor=white><font size=2>$sel_val</font></TD><TD bgcolor=white><font size=2>$it_dmg</font></TD><TD bgcolor=white><font size=2>$it_wei</font></TD><TD bgcolor=white><font size=2>$ELE[$it_ele]</font></TD><TD bgcolor=white><font size=2>$EQU[$it_ki]</font></TD></TR>";}
		$no2++;
	}
	&header;
	
	print <<"EOF";
<TABLE border="0" width="90%" align=center CLASS=TC height="400">
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="$FCOLOR"><FONT color="$FCOLOR2">아이템의 사용/장비</FONT></TD>
    </TR>
    <TR>
     <TD colspan=2 align="center" bgcolor="000000" height=50><FONT color="$FCOLOR2">장비 또는 사용하는 아이템을 선택해 주세요.</FONT></TD>
    </TR><TR>
	<TD bgcolor="#ffffff" align=center>
	$STPR
	<table colspan=3 width=90% align=center CLASS=MC>
	<BR>
	<tr><td bgcolor="$ELE_BG[$mele]"><font color=ffffcc>종류</font></td><td bgcolor="$ELE_BG[$mele]"><font color=ffffcc>이름</font></td><td bgcolor="$ELE_BG[$mele]"><font color=ffffcc>위력/무게</font></td></tr>
	<tr><td bgcolor="$ELE_C[$mele]">무기</td><td bgcolor="$ELE_C[$mele]">$marmname</td><td bgcolor="$ELE_C[$mele]">$marmdmg/$marmwei</td></tr>
	<tr><td bgcolor="$ELE_C[$mele]">방어구</td><td bgcolor="$ELE_C[$mele]">$mproname</td><td bgcolor="$ELE_C[$mele]">$mprodmg/$mprowei</td></tr>
	<tr><td bgcolor="$ELE_C[$mele]">악세사리</td><td bgcolor="$ELE_C[$mele]">$maccname</td><td bgcolor="$ELE_C[$mele]">$maccdmg/$maccwei</td></tr>
	</table>
	</TD>
	<TD bgcolor="#ffffff" align=center>
	<table border=0 width="90%" align=center CLASS=TC>
	
	<TR><td colspan=6 align=center><font color=ffffcc>소지품 리스트</font></td></tr>
	<TR>
	<TD bgcolor=ffffcc></TD><td bgcolor=white><font size=2>이름</font></td><td bgcolor=white><font size=2>판매가</font></td><td bgcolor=white><font size=2>위력</font></td><td bgcolor=white><font size=2>무게</font></td><td bgcolor=white><font size=2>속성</font></td><td bgcolor=white><font size=2>종류</font></td>
	</TR>
	<form action="./status.cgi" method="POST">
	$ittable
	<TR><TD colspan=7 align=center bgcolor=ffffff>
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=hidden name=itype value=$itype>
	<INPUT type=hidden name=mode value=equip2>
	<INPUT type=submit CLASS=FC value=사용/장비></TD></form>
	</TR></font>
	</table>
	</TD>
    </TR>
    <TR>
    <TD colspan="2" align="center" bgcolor="ffffff">
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value=돌아온다></TD></form>
	</TD>
    </TR>
  </TBODY>
</TABLE>
EOF
&footer;
exit;
}
1;

