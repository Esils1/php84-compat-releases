sub type_change2{
	&header;
	&chara_open;
	if($in{'type'} eq ""){&error("항목이 올바르게 선택되지 않았습니다.");}
	$mflg3="$in{'type'}";
	print <<"EOF";
<TABLE border="0" width="80%" bgcolor="#ffffff" height="150" align=center CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">훈련 메뉴의 변경</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="./img/etc/house.gif"></TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc">$mname는 훈련 메뉴를 「$TMENU[$mflg3]」로 변경했습니다.</FONT></TD>
    </TR>
    <TR>
      <TD colspan="2" align="right">
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value=돌아온다></form></TD>
	
    </TR>
  </TBODY>
</TABLE>
EOF
	&chara_input;
	&footer;
	exit;
}
1;

