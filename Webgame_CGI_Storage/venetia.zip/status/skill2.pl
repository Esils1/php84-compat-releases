sub skill2{
	&chara_open;
	if($in{'skill'} eq ""){&error("어빌리티가 올바르게 선택되고 있지 않습니다.");}
	
	open(IN,"./data/ability.cgi");
	@ABILITY = <IN>;
	close(IN);
	foreach(@ABILITY){
		($abno,$abname,$abcom,$abdmg,$abrate,$abpoint,$abclass,$abtype) =split(/<>/);
		if($abno eq $in{'skill'}){
			$hit=1;
			$mabp-=$abpoint;
			if($mabp < 0){&error("숙련도가 충분하지 않습니다.");}
			
			open(IN,"./logfile/ability/$mid.cgi");
			@ABDATA = <IN>;
			close(IN);
			foreach(@ABDATA){
				($kabno,$kabname,$kabcom,$kabdmg,$kabrate,$kabpoint,$kabclass,$kabtype) =split(/<>/);
				if($kabno eq $abno){&error("이미 습득하고 있습니다.");}
			}
			push(@ABDATA,"$abno<>$abname<>$abcom<>$abdmg<>$abrate<>$abpoint<>$abclass<>$abtype<>l<>e<>\n");
			open(OUT,">./logfile/ability/$mid.cgi") or &error('데이터를 쓸 수 없습니다.');
			print OUT @ABDATA;
			close(OUT);
			last;
		}
	}
	if(!$hit){&error("부정한 액세스입니다.");}

	&header;
	
	print <<"EOF";
<TABLE border="0" width="80%" bgcolor="#ffffff" height="150" align=center CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">어빌리티의 습득</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="./img/etc/palace2.gif"></TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc">$mname는<font color=red>어빌리티：$abname</font>를 습득했습니다.</FONT></TD>
    </TR>
    <TR>
      <TD colspan="2" align="right">
	<form action="./status.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=hidden name=mode value=skill>
	<INPUT type=submit CLASS=FC value="취득 화면에"></form></TD>
	
    </TR>
  </TBODY>
</TABLE>
EOF
	&chara_input;
	&footer;
	exit;
}
1;

