sub skill {
	&chara_open;
	&header;
	&status_print;

	#어빌리티 정보
	open(IN,"./data/ability.cgi");
	@ABILITY = <IN>;
	close(IN);

	#취득이 끝난 어빌리티 정보
	open(IN,"./logfile/ability/$mid.cgi");
	@ABDATA = <IN>;
	close(IN);

	#능력 상승에 필요한 숙련도
	$point=int(($mmaxstr+$mmaxvit+$mmaxint+$mmaxmen+$mmaxdex+$mmaxagi-1000)/20);
	$uppoint=$point*$point;
	if($uppoint>10000){$uppoint=10000;}

	require './data/abini.cgi';
	@jlist = split(/,/,$AJOB[$mclass]);

	$i=0;
	foreach(@jlist){
		$jobflg[$jlist[$i]] = 1;
		$i++;
	}
	$j=0;
	foreach(@ABILITY){
		($abno,$abname,$abcom,$abdmg,$abrate,$abpoint,$abclass,$abtype) =split(/<>/);
		if($jobflg[$abclass] eq 1){
			$sumi="<input type=radio name=skill value=$abno>";
			$hit=0;
			foreach(@ABDATA){
				($kabno,$kabname,$kabcom,$kabdmg,$kabrate,$kabpoint,$kabclass,$kabtype) =split(/<>/);
				if($kabno eq $abno){
					$sumi="<font color=red>제</font>";
				}
				if($kabno eq $abrate){
					$hit=1;
				}
			}
			if($hit eq 1 || $abrate eq 0){
				$abtable.="<TR><TD width=5% bgcolor=ffffcc align=center><font color=red>$sumi</font></TD><TD bgcolor=$FCOLOR2>$abname</TD><TD bgcolor=$FCOLOR2>$abcom</TD><TD bgcolor=$FCOLOR2 align=right>$abpoint</TD></TR>";
			}
		}
		$j++;
	}
	print <<"EOF";
<TABLE border="0" width="80%" align=center bgcolor="#ffffff" height="150" CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">어빌리티의 취득</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="./img/etc/palace2.gif"></TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc">어서 오십시오, $mname.여기는 어빌리티 취득과 수행동안입니다.현재 당신이 취득할 수 있는 어빌리티는 이하와 같습니다.</FONT></TD>
    </TR>
    <TR>
      <TD colspan="2" align="center">
	$STPR 

	<table border=0 width="100%" bgcolor=$FCOLOR CLASS=TC>
	<tr><td colspan=6 align=center><font color=ffffcc>취득가\능\인 어빌리티 일람</font></td></tr>
	<tr>
	<td bgcolor=ffffcc></td><td bgcolor=$FCOLOR2 align=center>어빌리티</td><td bgcolor=$FCOLOR2 align=center>효과</td><td bgcolor=$FCOLOR2 align=center>필요 숙련도</td>
	</tr>
	<form action="./status.cgi" method="post">
	$abtable
	<TR><TD colspan=7 align=center bgcolor="ffffff">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=hidden name=mode value=skill2>
	<INPUT type=submit CLASS=FC value="어빌리티를 취득"></TD></TR></form>
	</table>

	<table border=0 width="100%" bgcolor=$FCOLOR CLASS=TC>
	<tr><td colspan=6 align=center><font color=ffffcc>수행</font></td></tr>
	<tr>
	<td bgcolor=$FCOLOR2 align=center>효과</td><td bgcolor=$FCOLOR2 align=center>필요 숙련도</td>
	</tr>
	<form action="./status.cgi" method="post">
	<TR><TD bgcolor=$FCOLOR2>잠재력을 끌어 낸다</TD>
	<TD bgcolor=$FCOLOR2 align=right>$uppoint</TD></TR>
	<TR><TD colspan=7 align=center bgcolor="ffffff">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=hidden name=mode value=skill3>
	<INPUT type=submit CLASS=FC value="수행을 실시한다"></TD></TR></form>
	</table>

	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value=돌아온다></form></TD>
	
    </TR>
  </TBODY>
</TABLE>
<center></center>
EOF

	&footer;
	exit;
}
1;

