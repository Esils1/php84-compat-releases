sub name_change {
	&chara_open;
	&header;
	&status_print;
	$rename_gold=10000000;

	print <<"EOF";
<TABLE border="0" width="80%" align=center bgcolor="#ffffff" height="150" CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">개명의 신전</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="./img/etc/palace2.gif"></TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc">어서 오십시오, 여기에서는 이름의 변경을 할 수 있습니다.<BR>다만, 이름의 변경에는 $rename_gold Gold 필요합니다.<BR>새로운 이름을 입력해 주세요.</FONT></TD>
    </TR>
    <TR>
      <TD colspan="2" align="center">
	$STPR 
	<form action="./status.cgi" method="post">
	새로운 이름(2~8 문자)：<INPUT type=text size=20 name=rname><BR>
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=hidden name=mode value=name_change2>
	<INPUT type=submit value=개명 CLASS=FC></form>
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value=돌아온다></form></TD>
	
    </TR>
  </TBODY>
</TABLE>
<center></center>
EOF

	&footer;
	exit;
}
1;
