sub macro2{
	&chara_open;
	&header;
	
	&error("숫자가 맞지 않습니다") if $in{'verify'} ne $in{'verify2'};

	$mmacro = time + 60*60;

	print <<"EOF";
<TABLE border="0" width="80%" bgcolor="#ffffff" height="150" align=center CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">인증</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="./img/etc/palace.gif"></TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc">인증되었습니다.</FONT></TD>
    </TR>
    <TR>
      <TD colspan="2" align="right">
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value="돌아온다"></form></TD>
	
    </TR>
  </TBODY>
</TABLE>
EOF
	&chara_input;
	&footer;
	exit;
}
1;

