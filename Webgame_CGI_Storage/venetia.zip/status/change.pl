sub change {
	&chara_open;
	&status_print;

	open(IN,"./data/class.cgi") or &error("직업 데이터 파일이 열리지 않습니다.");
	@CLASS_DATA = <IN>;
	close(IN);
	
	$j=0;
	$joblist="<select name=job>";

	open(IN,"./logfile/job/$mid.cgi");
	@JOB_DATA = <IN>;
	close(IN);
	@job = split(/<>/,$JOB_DATA[0]);

	foreach(@CLASS_DATA){
		($cname,$cjp,$cnou,$cup,$cflg,$ctype) =split(/<>/);
		($cjp[0],$cjp[1],$cjp[2],$cjp[3],$cjp[4],$cjp[5]) = split(/,/,$cjp);
		($cp[0],$cp[1],$cp[2],$cp[3],$cp[4],$cp[5]) = split(/,/,$cnou);
		if($mjp[0] >= $cjp[0] && $mjp[1] >= $cjp[1] && $mjp[2] >= $cjp[2] && $mjp[3] >= $cjp[3] && $mjp[4] >= $cjp[4] && $mjp[5] >= $cjp[5]
		&& $mstr >= $cp[0] && $mvit >= $cp[1] && $mint >= $cp[2] && $mfai >= $cp[3] && $mdex >= $cp[4] && $magi >= $cp[5] ){
			$jobtable.="<TR><TD width=5% bgcolor=ffffcc><input type=radio name=job value=$j></TD><TD bgcolor=$FCOLOR2>$cname</TD><TD bgcolor=$FCOLOR2>$TYPE[$ctype]</TD><TD bgcolor=$FCOLOR2 align=right>$job[$j]</TD></TR>";
		}
		$j++;
	}
	$joblist.="</select>";

	&header;
	
	print <<"EOF";
<TABLE border="0" width="80%" align=center bgcolor="#ffffff" height="150" CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">전직의 신전</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="./img/etc/palace.gif"></TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc">어서 오십시오, $mname.여기는 전직의 신전입니다.<BR>어느 직업을 소망입니까?</FONT></TD>
    </TR>
    <TR>
      <TD colspan="2" align="center">
	$STPR 

	<table border=0 width="100%" bgcolor=$FCOLOR CLASS=TC>
	<tr><td colspan=6 align=center><font color=ffffcc>전직가\능\인 직업 일람</font></td></tr>
	<tr>
	<td bgcolor=ffffcc></td><td bgcolor=$FCOLOR2 align=center>직업</td><td bgcolor=$FCOLOR2 align=center>타입</td><td bgcolor=$FCOLOR2 align=center>숙련도</td>
	</tr>
	<form action="./status.cgi" method="post">
	$jobtable
	<TR><TD colspan=7 align=center bgcolor="ffffff">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=hidden name=mode value=change2>
	<INPUT type=submit CLASS=FC value=전직></TD></TR></form>
	</table>

	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value=돌아온다></form></TD>
	
    </TR>
  </TBODY>
</TABLE>
<center></center>
EOF

	&footer;
	exit;
}
1;

