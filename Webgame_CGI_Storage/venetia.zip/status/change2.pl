sub change2{
	&chara_open;
	if($in{'job'} eq ""){&error("직업이 올바르게 선택되지 않았습니다.");}
	if($mlv<50){&error("레벨 50 이하의 경우, 전직할 수 없습니다.");}

	open(IN,"./data/class.cgi") or &error("직업 데이터 파일이 열리지 않습니다.");
	@CLASS_DATA = <IN>;
	close(IN);

	($cname,$cjp,$cnou,$cup,$cflg,$ctype) =split(/<>/,$CLASS_DATA[$in{'job'}]);

	($hpup,$mpup,$strup,$vitup,$intup,$faiup,$dexup,$agiup) = split(/,/,$cup);
		
	for($i=0;$i<6;$i++){
		$jup[$i]=sqrt(sqrt(sqrt($mjp[$i])));
		$jup[$i]=int($jup[$i]*$jup[$i]*$jup[$i]);
	}

	$mmaxmaxhp = $mmaxstr*5 + $mmaxvit*10 + $mmaxmen*3 - 1500;
	$mmaxmaxmp = $mmaxint*7 + $mmaxmen*3 - 1000;

	$mmaxhp=int(rand($mmaxhp/1.5)) +$hpup;
	$mmaxmp=int(rand($mmaxmp/1.5)) +$mpup;
	$mstr=int(rand($mstr/1.5)) +$strup+$jup[0];
	$mvit=int(rand($mvit/1.5)) +$vitup+$jup[4];
	$mint=int(rand($mint/1.5)) +$intup+$jup[1];
	$mfai=int(rand($mfai/1.5)) +$faiup+$jup[2];
	$mdex=int(rand($mdex/1.5)) +$dexup+$jup[3];
	$magi=int(rand($magi/1.5)) +$agiup+$jup[5];

	if($mmaxhp<100){$mmaxhp=100;}
	if($mmaxmp<30){$mmaxmp=30;}
	if($mmaxhp>$mmaxmaxhp){$mmaxhp=$mmaxmaxhp;}
	if($mmaxmp>$mmaxmaxmp){$mmaxmp=$mmaxmaxmp;}

	if($mmaxhp<$mhp){$mhp=$mmaxhp;}
	if($mmaxmp<$mmp){$mmp=$mmaxmp;}

	if($mstr<30){$mstr=30;}
	if($mvit<30){$mvit=30;}
	if($mint<30){$mint=30;}
	if($mfai<30){$mfai=30;}
	if($mdex<30){$mdex=30;}
	if($magi<30){$magi=30;}

	if($mstr>$mmaxstr){$mstr=$mmaxstr;}
	if($mvit>$mmaxvit){$mvit=$mmaxvit;}
	if($mint>$mmaxint){$mint=$mmaxint;}
	if($mfai>$mmaxmen){$mfai=$mmaxmen;}
	if($mdex>$mmaxdex){$mdex=$mmaxdex;}
	if($magi>$mmaxagi){$magi=$mmaxagi;}

	open(IN,"./logfile/job/$mid.cgi");
	@JOB_DATA = <IN>;
	close(IN);
	@job = split(/<>/,$JOB_DATA[0]);
	$job[$mclass] = $mabp;
		
	@N_JOB_DATA=();
	unshift(@N_JOB_DATA,"$job[0]<>$job[1]<>$job[2]<>$job[3]<>$job[4]<>$job[5]<>$job[6]<>$job[7]<>$job[8]<>$job[9]<>$job[10]<>$job[11]<>$job[12]<>$job[13]<>$job[14]<>$job[15]<>$job[16]<>$job[17]<>$job[18]<>$job[19]<>$job[20]<>$job[21]<>$job[22]<>$job[23]<>$job[24]<>$job[25]<>$job[26]<>$job[27]<>$job[28]<>$job[29]<>$job[30]<>$job[31]<>$job[32]<>$job[33]<>$job[34]<>$job[35]<>$job[36]<>$job[37]<>$job[38]<>\n");
	open(OUT,">./logfile/job/$mid.cgi") or &error('데이터를 쓸 수 없습니다.');
	print OUT @N_JOB_DATA;
	close(OUT);

	($msk[0],$msk[1]) = split(/,/,$msk);

	if($mclass ne $in{'job'}){
		$msk="$msk[0],0";
		$mclass="$in{'job'}";
		$mtec="0,0,0,50,50";
	}
	
	$mtype="$ctype";
	$mex=0;
	
	$mabp = $job[$in{'job'}];

	&header;
	
	print <<"EOF";
<TABLE border="0" width="80%" bgcolor="#ffffff" height="150" align=center CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">전직의 신전</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="./img/etc/palace.gif"></TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc">$mname는<font color=red>$JOB[$in{'job'}]</font>되었습니다.</FONT></TD>
    </TR>
    <TR>
      <TD colspan="2" align="right">
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value="신전을 나온다"></form></TD>
	
    </TR>
  </TBODY>
</TABLE>
EOF
	&chara_input;
	&footer;
	exit;
}
1;

