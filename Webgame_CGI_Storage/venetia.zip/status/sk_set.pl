sub sk_set {
	&chara_open;
	&status_print;

	#어빌리티 정보
	open(IN,"./data/ability.cgi");
	@ABILITY = <IN>;
	close(IN);

	#취득이 끝난 어빌리티 정보
	open(IN,"./logfile/ability/$mid.cgi");
	@ABDATA = <IN>;
	close(IN);

	($msk[0],$msk[1]) = split(/,/,$msk);

	require './data/abini.cgi';
	@jlist = split(/,/,$AJOB[$mclass]);

	$i=0;
	foreach(@jlist){
		$jobflg[$jlist[$i]] = 1;
		$i++;
	}

	$j=0;
	foreach(@ABILITY){
		($abno,$abname,$abcom,$abdmg,$abrate,$abpoint,$abclass,$abtype) =split(/<>/);
		if($msk[0] eq $abno){
			$abname1=$abname;
			$abcom1=$abcom;
		}
		if($msk[1] eq $abno){
			$abname2=$abname;
			$abcom2=$abcom;
		}
		foreach(@ABDATA){
			($kabno,$kabname,$kabcom,$kabdmg,$kabrate,$kabpoint,$kabclass,$kabtype) =split(/<>/);
			if($kabno eq $abno){
				$abtable.="<TR><TD width=5% bgcolor=ffffcc align=center><input type=radio name=skill value=$abno></TD><TD bgcolor=$FCOLOR2>$abname</TD><TD bgcolor=$FCOLOR2>$abcom</TD></TR>";
			}
			if($kabno eq $abno && $jobflg[$abclass] eq 1){
				$abtable2.="<TR><TD width=5% bgcolor=ffffcc align=center><input type=radio name=skill2 value=$abno></TD><TD bgcolor=$FCOLOR2>$abname</TD><TD bgcolor=$FCOLOR2>$abcom</TD></TR>";
			}
		}
		$j++;
	}

	&header;
	print <<"EOF";
<TABLE border="0" width="80%" align=center bgcolor="#ffffff" height="150" CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">어빌리티의 변경</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="./img/etc/palace2.gif"></TD>
      <TD bgcolor="#330000">
	<FONT color="#ffffcc" size=2>
	어서 오십시오, $mname.여기에서는 취득한 어빌리티의 변경을 할 수 있습니다.어빌리티를 선택해, 변경해 주세요.
	<BR>메인어빌리티에서는 취득한 모든 어빌리티로부터 선택할 수 있습니다.직업 어빌리티에서는 현재의 직업에 의해 선택할 수 있는 어빌리티가 제한됩니다.
	<BR><FONT color="red">※같은 어빌리티 및, 효과의 같은 계통의 어빌리티를 2개 세트 해도 1개 밖에 효과는 발휘되지 않으므로 주의해 주세요.</FONT>
	</FONT>
　　　</TD>
    </TR>
    <TR>
      <TD colspan="2" align="center">
	$STPR 
	<table border=0 width="100%" bgcolor=$FCOLOR CLASS=TC>
	<tr><td colspan=6 align=center><font color=ffffcc>메인어빌리티</font></td></tr>
	<tr>
	<td bgcolor=ffffcc></td><td bgcolor=$FCOLOR2 align=center>어빌리티</td><td bgcolor=$FCOLOR2 align=center>효과</td>
	</tr>
	<tr><td width=5% bgcolor=ffcc99 align=center>현재</td><td bgcolor=ee9999>$abname1</td><td bgcolor=ee9999>$abcom1</td></tr>
	<form action="./status.cgi" method="post">
	$abtable
	<TR><TD colspan=7 align=center bgcolor="ffffff">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=hidden name=mode value=sk_set2>
	<INPUT type=hidden name=type value=1>
	<INPUT type=submit CLASS=FC value="메인어빌리티를 변경"></TD></TR></form>
	</table>

	<table border=0 width="100%" bgcolor=$FCOLOR CLASS=TC>
	<tr><td colspan=6 align=center><font color=ffffcc>직업 어빌리티</font></td></tr>
	<tr>
	<td bgcolor=ffffcc></td><td bgcolor=$FCOLOR2 align=center>어빌리티</td><td bgcolor=$FCOLOR2 align=center>효과</td>
	</tr>
	<tr><td width=5% bgcolor=ffcc99 align=center>현재</td><td bgcolor=ee9999>$abname2</td><td bgcolor=ee9999>$abcom2</td></tr>";
	<form action="./status.cgi" method="post">
	$abtable2
	<TR><TD colspan=7 align=center bgcolor="ffffff">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=hidden name=mode value=sk_set2>
	<INPUT type=hidden name=type value=2>
	<INPUT type=submit CLASS=FC value="직업 어빌리티를 변경"></TD></TR></form>
	</table>

	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value=돌아온다></form>
     </TD>	
    </TR>
  </TBODY>
</TABLE>
<center></center>
EOF

	&footer;
	exit;
}
1;

