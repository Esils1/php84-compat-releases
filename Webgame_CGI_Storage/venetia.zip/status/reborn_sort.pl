sub reborn_sort{
	&header;
	&chara_open;
	open(IN,"./logfile/soul/$mid.cgi") or error("파일을 열지 않았습니다.");
	@SOUL = <IN>;
	close(IN);

	$soul=@SOUL;
	if($soul<=0){&error("영혼이 없습니다.");}
	
	@N_SOUL=();
	foreach(@SOUL){
		($name,$hp,$mp,$str,$vit,$int,$fai,$dex,$agi,$type,$tec,$sk)=split(/<>/);
		$nou=int($hp/3+$mp/3+$str+$vit+$int+$fai+$dex+$agi);
		if($type eq"\n"||$tec eq"\n" || $sk eq"\n"){&error("영혼 리스트에 이상이 있습니다. 코우신을 실시해 주세요.");}
		push(@N_SOUL,"$nou<>$name<>$hp<>$mp<>$str<>$vit<>$int<>$fai<>$dex<>$agi<>$type<>$tec<>$sk<>\n");
	}
	@tmp = map {(split /<>/)[0]} @N_SOUL;
	@N_SOUL = @N_SOUL[sort {$tmp[$b] <=> $tmp[$a]} 0 .. $#tmp];

	@N2_SOUL=();
	foreach(@N_SOUL){
		($nou,$name,$hp,$mp,$str,$vit,$int,$fai,$dex,$agi,$type,$tec,$sk)=split(/<>/);
		push(@N2_SOUL,"$name<>$hp<>$mp<>$str<>$vit<>$int<>$fai<>$dex<>$agi<>$type<>$tec<>$sk<>\n");
	}
	open(OUT,">./logfile/soul/$mid.cgi") or &error('데이터를 기입할 수가 없습니다.');
	print OUT @N2_SOUL;
	close(OUT);

	print <<"EOF";
<TABLE border="0" width="80%" bgcolor="#ffffff" height="150" align=center CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">영혼의 소트</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="./img/etc/palace.gif"></TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc">영혼의 소트를 실시했습니다.</FONT></TD>
    </TR>
    <TR>
      <TD colspan="2" align="right">$STPR
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value=돌아온다></form></TD>
	
    </TR>
  </TBODY>
</TABLE>
EOF
	&chara_input;
	&footer;
	exit;
}
1;
