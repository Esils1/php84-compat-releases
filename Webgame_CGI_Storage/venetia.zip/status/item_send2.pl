sub item_send2{
	&chara_open;
	&time_data;
	if($in{'player'} eq ""){&error("상대가 선택되지 않았습니다.");}
	if($in{'player'} eq "$mid"){&error("자신에게는 보낼 수 없습니다.");}
	if($in{'itno'} eq ""){&error("아이템이 올바르게 선택되지 않았습니다.");}
	
	$send_money = 100000;
	$mbank -= $send_money;

	if($mbank<0){&error("우송료 $send_money Gold가 필요합니다.");}

	$enemy_id="$in{'player'}";
	&enemy_open;
	if($mtotal<0){&error("보내는 자격이 없습니다.");}
	if($etotal<0){&error("그 상대에게는 보낼 수 없습니다.");}

	open(IN,"./logfile/item/$mid.cgi");
	@MITEM = <IN>;
	close(IN);

	open(IN,"./logfile/item/$eid.cgi");
	@EITEM = <IN>;
	close(IN);

	($it_no,$it_ki,$it_name,$it_val,$it_dmg,$it_wei,$it_ele,$it_hit,$it_cl,$it_sta,$it_type,$it_flg) =split(/<>/,$MITEM[$in{'itno'}]);
	if($it_name eq ""){&error("아이템에 이상이 있습니다.");}
	
	$name="<font color=$ELE_C[$con_ele]>$mname</font><font color=orange>로부터$ename에</font>";
		
	$MESFILE="./logfile/mes/$mid.cgi";
	open(IN,"$MESFILE");
	@MES_DATA = <IN>;
	close(IN);
	unshift(@MES_DATA,"$mid<>$eid<>$ename<>$mchara<>$name<>$ename씨에게<font color=red>$it_name</font>보냈습니다.<>$daytime<>\n");
	splice(@MES_DATA,$MES3);
	open(OUT,">$MESFILE");
	print OUT @MES_DATA;
	close(OUT);

	$MESFILE2="./logfile/mes/$eid.cgi";
	open(IN,"$MESFILE2");
	@MES2_DATA = <IN>;
	close(IN);
	unshift(@MES2_DATA,"$mid<>$eid<>$ename<>$mchara<>$name<>$mname씨로부터<font color=red>$it_name</font>가 보내졌습니다.<>$daytime<>\n");
	splice(@MES2_DATA,$MES3);
	open(OUT,">$MESFILE2");
	print OUT @MES2_DATA;
	close(OUT);
	
	splice(@MITEM,$in{'itno'},1);
	open(OUT,">./logfile/item/$mid.cgi");
	print OUT @MITEM;
	close(OUT);

	push(@EITEM,"$it_no<>$it_ki<>$it_name<>$it_val<>$it_dmg<>$it_wei<>$it_ele<>$it_hit<>$it_cl<>$it_sta<>$it_type<>$it_flg<>\n");
	open(OUT,">./logfile/item/$eid.cgi");
	print OUT @EITEM;
	close(OUT);
					
	&enemy_input;
	&header;
	
	print <<"EOF";
<TABLE border="0" width="80%" bgcolor="#ffffff" height="150" align=center CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">아이템을 보낸다</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="./img/etc/pub.gif"></TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc">$mname는$ename에<font color=red>$it_name</font>를 보냈습니다.</FONT></TD>
    </TR>
    <TR>
      <TD colspan="2" align="right">$STPR
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value=돌아온다></form></TD>
	
    </TR>
  </TBODY>
</TABLE>
EOF
	&chara_input;
	&footer;
	exit;
}
1;

