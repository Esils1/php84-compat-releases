sub reborn_renew{
	&header;
	&chara_open;
	open(IN,"./logfile/soul/$mid.cgi") or error("파일을 열지 않았습니다.");
	@SOUL = <IN>;
	close(IN);
	open(IN,"./data/monster.cgi") or &error("마을 데이터 파일이 열리지 않습니다.");
	@MON_DATA = <IN>;
	close(IN);
	

	$soul=@SOUL;
	if($soul<=0){&error("영혼이 없습니다.");}
	
	@N_SOUL=();
	foreach(@SOUL){
		$monhit=0;
		($name,$hp,$mp,$str,$vit,$int,$fai,$dex,$agi,$type,$tec,$sk)=split(/<>/);
		foreach(@MON_DATA){
			($ename,$eab,$etec,$esk,$e_ex,$e_gold,$etype,$elv)=split(/<>/);
			if($ename eq $name){
				($hp,$mp,$str,$vit,$int,$fai,$dex,$agi)=split(/,/,$eab);
				$monhit=1;last;
			}
		}
		if(!$monhit){&error("데이터에 이상이 있습니다.");}
		$nou=int($hp/3+$mp/3+$str+$vit+$int+$fai+$dex+$agi);
		if($type eq"\n"){$type="0";}
		push(@N_SOUL,"$nou<>$name<>$hp<>$mp<>$str<>$vit<>$int<>$fai<>$dex<>$agi<>$etype<>$etec<>$esk<>\n");
	}
	@tmp = map {(split /<>/)[0]} @N_SOUL;
	@N_SOUL = @N_SOUL[sort {$tmp[$b] <=> $tmp[$a]} 0 .. $#tmp];

	@N2_SOUL=();
	foreach(@N_SOUL){
		($nou,$name,$hp,$mp,$str,$vit,$int,$fai,$dex,$agi,$type,$tec,$sk)=split(/<>/);
		push(@N2_SOUL,"$name<>$hp<>$mp<>$str<>$vit<>$int<>$fai<>$dex<>$agi<>$type<>$tec<>$sk<>\n");
	}
	open(OUT,">./logfile/soul/$mid.cgi") or &error('데이터를 기입할 수가 없습니다.');
	print OUT @N2_SOUL;
	close(OUT);

	print <<"EOF";
<TABLE border="0" width="80%" bgcolor="#ffffff" height="150" align=center CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">영혼 리스트 갱신</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="./img/etc/palace.gif"></TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc">영혼 리스트를 갱신했습니다.</FONT></TD>
    </TR>
    <TR>
      <TD colspan="2" align="right">$STPR
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value=돌아온다></form></TD>
	
    </TR>
  </TBODY>
</TABLE>
EOF
	&chara_input;
	&footer;
	exit;
}
1;
