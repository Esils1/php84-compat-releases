sub money_send2{
	&chara_open;
	&time_data;
	if($in{'player'} eq ""){&error("상대가 선택되지 않았습니다.");}
	if($in{'gold'} eq ""){&error("금액이 입력되지 않았습니다.");}
	if($in{'gold'} <= 0){&error("금액이 올바르게 입력되지 않았습니다.");}
	if($in{'gold'} =~ m/[^0-9]/){&error("금액에 숫자 이외의 문자가 포함되어 있습니다.");}
	
	$send_money=$in{'gold'}*10000;
	$mbank-=$send_money;
	if($mbank<0){&error("돈이 충분하지 않습니다.");}

	$enemy_id="$in{'player'}";
	&enemy_open;
	if($mtotal<100){&error("송금하는 자격이 없습니다.");}
	if($etotal<500){&error("그 상대에게는 송금할 수 없습니다.");}
	
	$name="<font color=$ELE_C[$con_ele]>$mname</font><font color=orange>로부터$ename에</font>";
		
	$MESFILE="./logfile/mes/$mid.cgi";
	open(IN,"$MESFILE");
	@MES_DATA = <IN>;
	close(IN);
	unshift(@MES_DATA,"$mid<>$eid<>$ename<>$mchara<>$name<>$ename씨에게<font color=red>$send_money Gold</font>보냈습니다.<>$daytime<>\n");
	splice(@MES_DATA,$MES3);
	open(OUT,">$MESFILE");
	print OUT @MES_DATA;
	close(OUT);

	$MESFILE2="./logfile/mes/$eid.cgi";
	open(IN,"$MESFILE2");
	@MES2_DATA = <IN>;
	close(IN);
	unshift(@MES2_DATA,"$mid<>$eid<>$ename<>$mchara<>$name<>$mname씨로부터<font color=red>$send_money Gold</font>가 보내졌습니다.<>$daytime<>\n");
	splice(@MES2_DATA,$MES3);
	open(OUT,">$MESFILE2");
	print OUT @MES2_DATA;
	close(OUT);
	
	$ebank+=$send_money;
	&enemy_input;
	&header;
	
	print <<"EOF";
<TABLE border="0" width="80%" bgcolor="#ffffff" height="150" align=center CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">송금</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="./img/etc/pub.gif"></TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc">$mname는$ename에<font color=red>$send_money Gold</font>송금했습니다.</FONT></TD>
    </TR>
    <TR>
      <TD colspan="2" align="right">$STPR
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value=돌아온다></form></TD>
	
    </TR>
  </TBODY>
</TABLE>
EOF
	&chara_input;
	&footer;
	exit;
}
1;

