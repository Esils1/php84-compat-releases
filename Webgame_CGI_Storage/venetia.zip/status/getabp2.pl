sub getabp2{
	&chara_open;
	if($in{'job'} eq ""){&error("직업이 올바르게 선택되지 않았습니다.");}
	
	require './data/abini.cgi';
	@jlist = split(/,/,$AJOB[$mclass]);

	$i=0;
	foreach(@jlist){
		$jobflg[$jlist[$i]] = 1;
		$i++;
	}
	if($jobflg[$in{'job'}] ne 1){
		&maplog("<font color=red>[부정]</font>$mname는 부정하게 숙련도의 취득을 실시했습니다.");
		&error("부정을 실시했습니다.");
	}
	open(IN,"./logfile/job/$mid.cgi");
	@JOB_DATA = <IN>;
	close(IN);
	@job = split(/<>/,$JOB_DATA[0]);

	$getabp = int($job[$in{'job'}]*0.7);
		
	if($getabp > 1){
		$mabp += $getabp;
		$job[$in{'job'}] = 0;
	}else{
		&error("취득할 수 있는 숙련도가 없습니다.");
	}

	@N_JOB_DATA=();
	unshift(@N_JOB_DATA,"$job[0]<>$job[1]<>$job[2]<>$job[3]<>$job[4]<>$job[5]<>$job[6]<>$job[7]<>$job[8]<>$job[9]<>$job[10]<>$job[11]<>$job[12]<>$job[13]<>$job[14]<>$job[15]<>$job[16]<>$job[17]<>$job[18]<>$job[19]<>$job[20]<>$job[21]<>$job[22]<>$job[23]<>$job[24]<>$job[25]<>$job[26]<>$job[27]<>$job[28]<>$job[29]<>$job[30]<>$job[31]<>$job[32]<>$job[33]<>$job[34]<>$job[35]<>$job[36]<>$job[37]<>$job[38]<>\n");
	open(OUT,">./logfile/job/$mid.cgi") or &error('데이터를 쓸 수 없습니다.');
	print OUT @N_JOB_DATA;
	close(OUT);

	&chara_input;
	
	&header;
	print <<"EOF";
<TABLE border="0" width="80%" bgcolor="#ffffff" height="150" align=center CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">취득 완료</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="./img/etc/palace2.gif"></TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc">숙련도를<font color=red>$getabp</font>취득했습니다.</FONT></TD>
    </TR>
    <TR>
      <TD colspan="2" align="right">
	<form action="./status.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=hidden name=mode value=getabp>
	<INPUT type=submit CLASS=FC value="취득 화면에"></form>
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value="거리에"></form>
    </TD>
    </TR>
  </TBODY>
</TABLE>
EOF
	&footer;
	exit;
}
1;

