sub status{
	&chara_open;
	&equip_open;
	&status_print;

	open(IN,"./data/tec.cgi") or &error('파일을 열지 않았습니다.');
	@TEC = <IN>;
	close(IN);
	($mtec1,$mtec2,$mtec3,$mmprate,$mhprate) =split(/,/,$mtec);

	$mmaxmaxhp = $mmaxstr*5 + $mmaxvit*10 + $mmaxmen*3 - 2000;
	$mmaxmaxmp = $mmaxint*5 + $mmaxmen*3 - 800;

	if($mtec1 eq ""){$mtec1=0;}
	if($mtec2 eq ""){$mtec2=0;}
	if($mtec3 eq ""){$mtec3=0;}

	($mtec_name[0],$mtec_str[0],$mtec_hit[0],$mtec_mp[0],$mtec_ab[0],$mtec_sta[0],$mtec_class[0]) = split(/<>/,$TEC[$mtec1]);
	($mtec_name[1],$mtec_str[1],$mtec_hit[1],$mtec_mp[1],$mtec_ab[1],$mtec_sta[1],$mtec_class[1]) = split(/<>/,$TEC[$mtec2]);
	($mtec_name[2],$mtec_str[2],$mtec_hit[2],$mtec_mp[2],$mtec_ab[2],$mtec_sta[2],$mtec_class[2]) = split(/<>/,$TEC[$mtec3]);
			
	open(IN,"./data/ability.cgi");
	@ABILITY = <IN>;
	close(IN);

	($msk[0],$msk[1]) = split(/,/,$msk);

	foreach(@ABILITY){
		($abno,$abname,$abcom,$abdmg,$abrate,$abpoint,$abclass,$abtype) =split(/<>/);
		if($msk[0] eq $abno){
			$abname1=$abname;
			$abcom1=$abcom;
		}
		if($msk[1] eq $abno){
			$abname2=$abname;
			$abcom2=$abcom;
		}
		if($marmsta eq $abno){
			$abname3=$abname;
		}
		if($mprosta eq $abno){
			$abname4=$abname;
		}
		if($maccsta eq $abno){
			$abname5=$abname;
		}
		$j++;
	}
	
	&header;
	
	print <<"EOF";
<TABLE border="0" align=center width="70%" height="143" CLASS=MC>
  <TBODY>
    <TR>
      <TD colspan="5" align="center" bgcolor="$ELE_BG[$mele]"><font color=$ELE_C[$mele]>스테이터스</font></TD>
    </TR>
    <TR>
      <TD rowspan="5" bgcolor="$ELE_C[$mele]" align=center><img src="./img/chara/$mchara.gif"></TD>
      <TD bgcolor="$ELE_C[$mele]" align="left">LV</TD>
      <TD bgcolor="$ELE_C[$mele]" align="right">$mlv</TD>
      <TD bgcolor="$ELE_C[$mele]">속성</TD>
      <TD bgcolor="$ELE_C[$mele]" align="right">$ELE[$mele]</TD>
    </TR>
    <TR>
      <TD bgcolor="$ELE_C[$mele]">HP</TD>
      <TD bgcolor="$ELE_C[$mele]" align="right">$mhp/$mmaxhp($mmaxmaxhp)</TD>
      <TD bgcolor="$ELE_C[$mele]">MP</TD>
      <TD bgcolor="$ELE_C[$mele]" align="right">$mmp/$mmaxmp($mmaxmaxmp)</TD>
    </TR>
    <TR>
      <TD bgcolor="$ELE_C[$mele]">힘</TD>
      <TD bgcolor="$ELE_C[$mele]" align="right">$mstr($mmaxstr)</TD>
      <TD bgcolor="$ELE_C[$mele]">생명력</TD>
      <TD bgcolor="$ELE_C[$mele]" align="right">$mvit($mmaxvit)</TD>
    </TR>
    <TR>
      <TD bgcolor="$ELE_C[$mele]">지력</TD>
      <TD bgcolor="$ELE_C[$mele]" align="right">$mint($mmaxint)</TD>
      <TD bgcolor="$ELE_C[$mele]">정신</TD>
      <TD bgcolor="$ELE_C[$mele]" align="right">$mfai($mmaxmen)</TD>
    </TR>
    <TR>
      <TD bgcolor="$ELE_C[$mele]">운</TD>
      <TD bgcolor="$ELE_C[$mele]" align="right">$mdex($mmaxdex)</TD>
      <TD bgcolor="$ELE_C[$mele]">속도</TD>
      <TD bgcolor="$ELE_C[$mele]" align="right">$magi($mmaxagi)</TD>
    </TR>
    <TR>
      <TD bgcolor="$ELE_C[$mele]" align="center">$mname</TD>
      <TD bgcolor="$ELE_C[$mele]">직업</TD>
      <TD bgcolor="$ELE_C[$mele]" align="right">$JOB[$mclass]</TD>
      <TD bgcolor="$ELE_C[$mele]">명성</TD>
      <TD bgcolor="$ELE_C[$mele]" align="right">$mcex</TD>
    </TR>
    <TR>
      <TD bgcolor="$ELE_C[$mele]" align="center">$mtotal전$mkati승</TD>
      <TD bgcolor="$ELE_C[$mele]">경험치</TD>
      <TD bgcolor="$ELE_C[$mele]" align="right">$mex</TD>
      <TD bgcolor="$ELE_C[$mele]">숙련도</TD>
      <TD bgcolor="$ELE_C[$mele]" align="right">$mabp</TD>
    </TR>
    <TR>
      <TD bgcolor="$ELE_C[$mele]" align="center">총경험치：$mtotalex</TD>
      <TD bgcolor="$ELE_C[$mele]">건강도</TD>
      <TD bgcolor="$ELE_C[$mele]" align="right">$mken%</TD>
      <TD bgcolor="$ELE_C[$mele]">자금</TD>
      <TD bgcolor="$ELE_C[$mele]" align="right">$mgold</TD>
    </TR>
    <TR>
      <TD bgcolor="$ELE_C[$mele]" align="center"></TD>
      <TD bgcolor="$ELE_C[$mele]">검술</TD>
      <TD bgcolor="$ELE_C[$mele]" align="right">$mjp[0]</TD>
      <TD bgcolor="$ELE_C[$mele]">마술</TD>
      <TD bgcolor="$ELE_C[$mele]" align="right">$mjp[1]</TD>
    </TR>
　　<TR>
      <TD bgcolor="$ELE_C[$mele]" align="center"></TD>
      <TD bgcolor="$ELE_C[$mele]">신술</TD>
      <TD bgcolor="$ELE_C[$mele]" align="right">$mjp[2]</TD>
      <TD bgcolor="$ELE_C[$mele]">궁술</TD>
      <TD bgcolor="$ELE_C[$mele]" align="right">$mjp[3]</TD>
    </TR>
    <TR>
      <TD bgcolor="$ELE_C[$mele]" align="center"></TD>
      <TD bgcolor="$ELE_C[$mele]">체술</TD>
      <TD bgcolor="$ELE_C[$mele]" align="right">$mjp[4]</TD>
      <TD bgcolor="$ELE_C[$mele]">둔갑술</TD>
      <TD bgcolor="$ELE_C[$mele]" align="right">$mjp[5]</TD>
    </TR>
    <TR>
      <TD colspan="5" align="center" bgcolor="$ELE_BG[$mele]"><font color=$ELE_C[$mele]>어빌리티</font></TD>
    </TR>
　　<TR>
      <TD colspan="1" align="center" bgcolor="blueviolet"><font color=$ELE_C[$mele]>메인</font></TD>
      <TD colspan="1" align="center" bgcolor="$ELE_C[$mele]"><font color=$ELE_BG[$mele]>$abname1</font></TD>
      <TD colspan="3" align="center" bgcolor="$ELE_C[$mele]"><font color=$ELE_BG[$mele]>$abcom1</font></TD>
    </TR>
　　<TR>
      <TD colspan="1" align="center" bgcolor="blueviolet"><font color=$ELE_C[$mele]>직업</font></TD>
      <TD colspan="1" align="center" bgcolor="$ELE_C[$mele]"><font color=$ELE_BG[$mele]>$abname2</font></TD>
      <TD colspan="3" align="center" bgcolor="$ELE_C[$mele]"><font color=$ELE_BG[$mele]>$abcom2</font></TD>
    </TR>
    <TR>
      <TD colspan="5" align="center" bgcolor="$ELE_BG[$mele]"><font color=$ELE_C[$mele]>기술</font></TD>
    </TR>
    <TR>
      <TD bgcolor="$ELE_C[$mele]"></TD>
      <TD bgcolor="$ELE_C[$mele]" align="center" colspan="2">이름</TD>
      <TD bgcolor="$ELE_C[$mele]" align="center">위력</TD>
      <TD bgcolor="$ELE_C[$mele]" align="center">발동율</TD>
    </TR>
    <TR>
      <TD bgcolor="$ELE_C[$mele]">통상</TD>
      <TD bgcolor="$ELE_C[$mele]" colspan="2">$mtec_name[0]</TD>
      <TD bgcolor="$ELE_C[$mele]" align="right">$mtec_str[0]</TD>
      <TD bgcolor="$ELE_C[$mele]" align="right">$mtec_hit[0]</TD>
    </TR>
    <TR>
      <TD bgcolor="$ELE_C[$mele]">MP가$mmprate%이하</TD>
      <TD bgcolor="$ELE_C[$mele]" colspan="2">$mtec_name[1]</TD>
      <TD bgcolor="$ELE_C[$mele]" align="right">$mtec_str[1]</TD>
      <TD bgcolor="$ELE_C[$mele]" align="right">$mtec_hit[1]</TD>
    </TR>
    <TR>
      <TD bgcolor="$ELE_C[$mele]">HP가$mhprate%이하</TD>
      <TD bgcolor="$ELE_C[$mele]" colspan="2">$mtec_name[2]</TD>
      <TD bgcolor="$ELE_C[$mele]" align="right">$mtec_str[2]</TD>
      <TD bgcolor="$ELE_C[$mele]" align="right">$mtec_hit[2]</TD>
    </TR>
    <TR>
      <TD colspan="5" align="center" bgcolor="$ELE_BG[$mele]"><font color=$ELE_C[$mele]>장비</font></TD>
    </TR>
    <TR>
      <TD bgcolor="$ELE_C[$mele]"></TD>
      <TD colspan="2" bgcolor="$ELE_C[$mele]" align="center">이름</TD>
      <TD bgcolor="$ELE_C[$mele]" align="center">어빌리티</TD>
      <TD bgcolor="$ELE_C[$mele]" align="center">위력/무게</TD>
    </TR>
    <TR>
      <TD bgcolor="$ELE_C[$mele]">무기</TD>
      <TD colspan="2" bgcolor="$ELE_C[$mele]" align="right">$marmname($ELE[$marmele])</TD>
      <TD bgcolor="$ELE_C[$mele]" align="right">$abname3</TD>
      <TD bgcolor="$ELE_C[$mele]" align="right">$marmdmg/$marmwei</TD>
    </TR>
    <TR>
      <TD bgcolor="$ELE_C[$mele]">방어구</TD>
      <TD colspan="2" bgcolor="$ELE_C[$mele]" align="right">$mproname($ELE[$mproele])</TD>
      <TD bgcolor="$ELE_C[$mele]" align="right">$abname4</TD>
      <TD bgcolor="$ELE_C[$mele]" align="right">$mprodmg/$mprowei</TD>
    </TR>
    <TR>
      <TD bgcolor="$ELE_C[$mele]">악세사리</TD>
      <TD colspan="2" bgcolor="$ELE_C[$mele]" align="right">$maccname($ELE[$maccele])</TD>
      <TD bgcolor="$ELE_C[$mele]" align="right">$abname5</TD>
      <TD bgcolor="$ELE_C[$mele]" align="right">$maccdmg/$maccwei</TD>
    </TR>
    <TR>
      <TD colspan=5 align=center bgcolor=$ELE_C[$mele]>
        <form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=MFC value=돌아온다></TD></form>
    </TR>
  </TBODY>
</TABLE>
EOF
&footer;
exit;
}
1;

