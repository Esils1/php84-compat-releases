#_/_/_/_/_/_/_/_/_/#
#_/ 등록 정보 변경 _/#
#_/_/_/_/_/_/_/_/_/#

sub data_change {

	&chara_open;
	&header;

	print <<"EOM";
	<script language="JavaScript">
 	function changeImg(){
  		num=document.para.chara.selectedIndex;
  		document.Img.src="./img/chara/"+ num +".gif";
 	}
	</script>
	<TABLE border="0" width="80%" align=center bgcolor="#ffffff" height="150" CLASS=FC>
  	 <TBODY>
    	 <TR>
      	  <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">아이콘의 변경</FONT></TD>
    	 </TR>
    	 <TR>
      	  <TD bgcolor="#ffffcc" width=20% align=center><img src="./img/etc/pub.gif"></TD>
      	  <TD bgcolor="#330000"><FONT color="#ffffcc">아이콘의 변경을 실시할 수 있습니다.<BR>희망의 아이콘을 선택해 주세요.<BR>다만 아이콘의 변경에는 1회<font color=red>100000Gold</font>걸립니다.</FONT></TD>
    	 </TR>
	 <TR>
    	  <TD colspan=2 align=center bgcolor=$FCOLOR2>
	   <TABLE bgcolor=$FCOLOR>
	    <form action="./status.cgi" method="post" name=para>
	    <TR>
	     <TD><img src=\"img/chara/0.gif\" name=\"Img\"></TD>
	    </TR>
	   </TABLE>
	   <select name=chara onChange=\"changeImg()\">
EOM
	foreach (0..$CHARAIMG){print "<option value=\"$_\">이미지[$_]\n";}

	print <<"EOM";
	   </select><br>캐릭터의 화상을 선택해 주세요.<BR>
	   <input type=submit CLASS=FC value=변경>
	   <input type=hidden name=id value=$mid>
	   <input type=hidden name=pass value=$mpass>
	   <input type=hidden name=mode value=data_change2>
	   
	   </form>
  	   <form action="./top.cgi" method="post">
	   <input type=hidden name=id value=$mid>
	   <input type=hidden name=pass value=$mpass>
	   <input type=submit CLASS=FC value="돌아온다">
	   </form>
           </TD>
          </TR>
	  </TBODY>
	 </TABLE>
	</CENTER>
EOM

	&footer;
	exit;
}

1;


