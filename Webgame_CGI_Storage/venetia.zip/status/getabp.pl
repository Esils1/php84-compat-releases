sub getabp {
	&chara_open;
	&status_print;

	open(IN,"./data/class.cgi") or &error("직업 데이터 파일이 열리지 않습니다.");
	@CLASS_DATA = <IN>;
	close(IN);
	

	require './data/abini.cgi';
	@jlist = split(/,/,$AJOB[$mclass]);

	$i=0;
	foreach(@jlist){
		$jobflg[$jlist[$i]] = 1;
		$i++;
	}

	$j=0;
	$joblist="<select name=job>";

	open(IN,"./logfile/job/$mid.cgi");
	@JOB_DATA = <IN>;
	close(IN);
	@job = split(/<>/,$JOB_DATA[0]);

	foreach(@CLASS_DATA){
		($cname,$cjp,$cnou,$cup,$cflg,$ctype) =split(/<>/);
		if($jobflg[$j] && $mclass ne $j){
			$jobtable.="<TR><TD width=5% bgcolor=ffffcc><input type=radio name=job value=$j></TD><TD bgcolor=$FCOLOR2>$cname</TD><TD bgcolor=$FCOLOR2>$TYPE[$ctype]</TD><TD bgcolor=$FCOLOR2 align=right>$job[$j]</TD></TR>";
		}
		$j++;
	}
	$joblist.="</select>";

	&header;
	
	print <<"EOF";
<TABLE border="0" width="80%" align=center bgcolor="#ffffff" height="150" CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">숙련도의 취득</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="./img/etc/palace.gif"></TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc">하위의 직업으로부터 숙련도를 취득합니다.취득을 실시했을 경우, 취득처의 숙련도는 0이 됩니다.<BR>직업을 선택해 주세요.<BR>상, 취득할 수 있는 숙련도는 취득처의 숙련도의 70%입니다.</FONT></TD>
    </TR>
    <TR>
      <TD colspan="2" align="center">
	$STPR 

	<table border=0 width="100%" bgcolor=$FCOLOR CLASS=TC>
	<tr><td colspan=6 align=center><font color=ffffcc>취득가\능\인 직업 일람</font></td></tr>
	<tr>
	<td bgcolor=ffffcc></td><td bgcolor=$FCOLOR2 align=center>직업</td><td bgcolor=$FCOLOR2 align=center>타입</td><td bgcolor=$FCOLOR2 align=center>숙련도</td>
	</tr>
	<form action="./status.cgi" method="post">
	$jobtable
	<TR><TD colspan=7 align=center bgcolor="ffffff">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=hidden name=mode value=getabp2>
	<INPUT type=submit CLASS=FC value=취득한다></TD></TR></form>
	</table>

	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value=돌아온다></form></TD>
	
    </TR>
  </TBODY>
</TABLE>
<center></center>
EOF

	&footer;
	exit;
}
1;

