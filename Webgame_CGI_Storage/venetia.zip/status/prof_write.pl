#_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/#
#_/       회의실 기입     _/#
#_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/#

sub prof_write{

	&chara_open;
	&con_open;
    	
	if($in{'message'} eq"") { &error("코멘트를 입력해 주세요."); }
	if(length($in{'message'}) > 1000) { &error("더 간략하게 써 주세요"); }
	if(length($in{'message'}) > 1000) { &error("더 간략하게 써 주세요"); }

	if($lockkey) { &F_LOCK; }
	open(IN,"./logfile/prof/$mid.cgi");
	@PROF_DATA = <IN>;
	close(IN);
	$in{'message'}.="<BR>";
	@t = split(/<br>/,$in{'message'});
	$gyou=@t;
	if($gyou>20){&error("20행 이내로 부탁합니다.");}

	@N_PROF_DATA=();
	push(@N_PROF_DATA,"$in{'message'}");

	open(OUT,">./logfile/prof/$mid.cgi");
	print OUT @N_PROF_DATA;
	close(OUT);

	&header;
	
print <<"EOF";
<TABLE border="0" width="80%" bgcolor="#ffffff" height="150" align=center CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">프로필의 갱신</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="img/etc/house.gif"></TD>
      <TD bgcolor="#000000"><FONT color="#ffffcc">프로필을 갱신했습니다.</FONT></TD>
    </TR>
    <TR>
      <TD colspan="2" align="center">
<form action="./status.cgi" method="post">
<input type=hidden name=id value=$mid>
<input type=hidden name=pass value=$mpass>
<input type=hidden name=mode value=prof_edit>
<input type=submit CLASS=FC value="OK"></form></TD>
	
    </TR>
  </TBODY>
</TABLE>
EOF
	&footer;
	exit;
	
}
1;
