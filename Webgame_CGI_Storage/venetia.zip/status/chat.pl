sub chat {
	&chara_open;
	&status_print;
	&con_open;
	&town_open;
	&time_data;

	&error("사용 금지 단어입니다.") if $in{'mes'} =~ /에소루/;
	&error("사용 금지 단어입니다.") if $in{'mes'} =~ /webgame/;

	if($con_king eq"$mid"){$smess="<font color=orange>[국왕]</font>$in{'mes'}";}
	else{$smess="<font color=red>[국민]</font>$in{'mes'}";}
	for($k=0;$k<3;$k++){
		if($y_chara[$k] eq $mid){$smess="<font color=#ff0099>[$y_name[$k]]</font>$in{'mes'}";}
	}

	if($in{'mes_sel'} eq ""){&error("송신 상대가 올바르게 선택되지 않았습니다.");}
	if($in{'mes'} eq ""){&error("메세지를 입력해 주세요.");}
	if(length($in{'mes'}) > 300){&error("150 문자 이내에서 입력해 주세요.");}

	$pid = &id_change("$mid");

	$aite=$in{'mes_sel'};
	if($in{'mes_sel'} eq "1"){
		$MESFILE="./meslog/all.cgi";
		$name="<a href=\"javascript:void(0);\" onClick=\"window.open('./status_print.cgi?id=$pid', 'newwin', 'width=600,height=400,scrollbars =yes')\"><font color=$ELE_C[$con_ele]>$mname</a>＠$con_name국</font>";
		$mes_max=$MES1;$eid=1;
	}
	elsif($in{'mes_sel'} eq "2"){
		$MESFILE="./meslog/$con_id.cgi";

		open(IN,"./data/unit.cgi");
		@UNIT_DATA = <IN>;
		close(IN);

		foreach(@UNIT_DATA){
		($uid,$lchara,$lname,$uname,$bid,$bname,$bmes,$bcon) =split(/<>/);
			if($uid eq $munit && $munit ne ""){
				$hit=1;$unit=$uname;last;
			}
		}
		if(!$hit){$unit="무소속";}
		$name="<a href=\"javascript:void(0);\" onClick=\"window.open('./status_print.cgi?id=$pid', 'newwin', 'width=600,height=400,scrollbars =yes')\"><font color=$ELE_C[$con_ele]>$mname</a>＠$unit</font>";
		$mes_max=$MES2;$eid=2;
	}
	##개앞
	elsif($in{'mes_sel'} eq"3"){
		if($in{'aite'} eq""){&error("보내는 상대를 입력해 주세요.");}
		if($in{'aite'} eq"$mname"){&error("자신에게는 보낼 수 없습니다.");}
		$dir="./logfile/chara";
		opendir(dirlist,"$dir");
		$i=0;
		while($file = readdir(dirlist)){
			if($file =~ /\.cgi/i){
				$datames = "검색：$dir/$file<br>\n";
				if(!open(chara,"$dir/$file")){
					&error("$dir/$file가 발견되지 않습니다.<br>\n");
				}
				@chara = <chara>;
				close(chara);
				$list[$i]="$file";
				($eid,$epass,$ename,$eurl,$echara) = split(/<>/,$chara[0]);
				
				if($ename eq"$in{'aite'}"){$mh=1;last;}
			}
			if($mn>10000){&error("루프");}
			$mn++;
		}
		closedir(dirlist);
		if(!$mh){&error("보내는 상대가 발견되지 않았습니다.");}
		$MESFILE="./logfile/mes/$eid.cgi";
		$name="<a href=\"javascript:void(0);\" onClick=\"window.open('./status_print.cgi?id=$pid&id2=$mid', 'newwin', 'width=750,height=500,scrollbars =yes')\"><font color=$ELE_C[$con_ele]>$mname</a></font><font color=orange>로부터$ename에</font>";
		$mes_max=$MES3;
		$aite ="$mname";

		open(IN,"./logfile/mes/$mid.cgi");
		@MMES_DATA = <IN>;
		close(IN);
		unshift(@MMES_DATA, "$mid<>$eid<>$aite<>$mchara<>$name<>$in{'mes'}<>$daytime<>\n");
		splice(@MMES_DATA,$mes_max);

		open(OUT,">./logfile/mes/$mid.cgi");
		print OUT @MMES_DATA;
		close(OUT);
	}elsif($in{'mes_sel'} eq "4"){
		open(IN,"./data/unit.cgi");
		@UNIT_DATA = <IN>;
		close(IN);
		if($munit eq ""){&error("부대에 소속해 있지 않습니다.");}
		foreach(@UNIT_DATA){
		($uid,$lchara,$lname,$uname,$bid,$bname,$bmes,$bcon) =split(/<>/);
			if($uid eq $munit && $munit ne ""){
				$unit=$uname;$hit=1;last;
			}
		}
		if(!$hit){$unit="무소속";}

		$MESFILE="./meslog/unit/$munit.cgi";
		$name="<a href=\"javascript:void(0);\" onClick=\"window.open('./status_print.cgi?id=$pid', 'newwin', 'width=600,height=400,scrollbars =yes')\"><font color=$ELE_C[$con_ele]>$mname</a>＠$unit</font>";
		$mes_max=$MES2;$eid=4;
	}elsif($in{'mes_sel'} ne""){
		$enemy_id=$in{'mes_sel'};
		&enemy_open;

		$MESFILE="./logfile/mes/$eid.cgi";
		$name="<a href=\"javascript:void(0);\" onClick=\"window.open('./status_print.cgi?id=$pid', 'newwin', 'width=750,height=500,scrollbars =yes')\"><font color=$ELE_C[$con_ele]>$mname</a></font><font color=orange>로부터$ename에</font>";
		$mes_max=$MES3;
		$aite ="$mname";

		open(IN,"./logfile/mes/$mid.cgi");
		@MMES_DATA = <IN>;
		close(IN);
		unshift(@MMES_DATA, "$mid<>$eid<>$aite<>$mchara<>$name<>$in{'mes'}<>$daytime<>\n");
		splice(@MMES_DATA,$mes_max);

		open(OUT,">./logfile/mes/$mid.cgi");
		print OUT @MMES_DATA;
		close(OUT);
	}
	else{&error("올바르게 선택되지 않았습니다.$in{'mes_sel'}");}

	
	open(IN,"$MESFILE");
	@MES_DATA = <IN>;
	close(IN);
#	if($in{'mes'} eq"clear"){
#		$smess="♪~";
#		@N_MES=();
#		foreach(@MES_DATA){
#			($mes_id,$mes_aite,$mes_eid,$mes_chara,$mes_name,$mes_mes,$mes_daytime) =split(/<>/);
#			if($mid eq "$mes_id"){next;}
#			else{push(@N_MES,"$_");}
#		}
#		@MES_DATA=@N_MES;
#	}
	unshift(@MES_DATA,"$mid<>$eid<>$aite<>$mchara<>$name<>$smess<>$daytime<>\n");
	splice(@MES_DATA,$mes_max);

	open(OUT,">$MESFILE");
	print OUT @MES_DATA;
	close(OUT);

	&header;
	
	print <<"EOF";
<TABLE border="0" width="80%" align=center bgcolor="#ffffff" height="120" CLASS=FC>
  <TBODY>
    <TR>
      <TD align="center" bgcolor="#993300"><FONT color="#ffffcc">송신 완료</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#330000" height=100><FONT color="#ffffcc">메세지를 송신했습니다.</FONT></TD>
    </TR>
    <TR>
      <TD align="center">
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value=돌아온다></form></TD>
	
    </TR>
  </TBODY>
</TABLE>
<center></center>
EOF

	&footer;
	exit;
}
#----------------------#
#  패스워드 암호 처리  #
#----------------------#
sub id_change {
	local($inpw) = $_[0];

	@yy = unpack("C*", $inpw);
	$word="";
	foreach(@yy){
		$word .= "$_\,";
	}
	chomp($word);
	$encrypt = reverse($word);

	return $encrypt;
}
1;

