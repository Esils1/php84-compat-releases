sub tec_set2{
	&chara_open;
	if($in{'tec1'} eq ""||$in{'tec2'} eq ""||$in{'tec3'} eq ""){&error("기술이 올바르게 선택되지 않았습니다.");}
	if ($in{'mprate'} =~ m/[^0-9]/ || $in{'hprate'} =~ m/[^0-9]/){&error("조건에 숫자 이외의 문자가 포함되어 있습니다."); }
	if ($in{'mprate'} >100 || $in{'mprate'} <0 || $in{'hprate'} > 100 || $in{'hprate'} < 0){&error("조건은 0~100%의 범위에서 입력해 주세요."); }
	if(length($in{'bcom'}) > 40){&error("코멘트는 20 문자 이내에서 입력해 주세요.");}
	
	$mcom="$in{'bcom'}";
	$mtec="$in{'tec1'},$in{'tec2'},$in{'tec3'},$in{'mprate'},$in{'hprate'}";
	&chara_input;

	&header;
	print <<"EOF";
<TABLE border="0" width="80%" bgcolor="#ffffff" height="150" align=center CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">변경 완료</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="./img/etc/house.gif"></TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc">기술을 변경했습니다.</FONT></TD>
    </TR>
    <TR>
      <TD colspan="2" align="right">
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value=돌아온다></form></TD>
	
    </TR>
  </TBODY>
</TABLE>
EOF
	&footer;
	exit;
}
1;

