sub name_change2{
	&chara_open;
	&con_open;
	if($in{'rname'} eq ""){&error("이름이 올바르게 입력되고 있지 않습니다.");}
	if($moya%5000 ne "37"){&error("부정을 실시했습니다.");}
	if(length($in{'rname'}) > 16 || length($in{'rname'}) < 4){&error("이름은 2~8 문자로 입력해 주세요.");}
	$rename_gold=10000000;
	if($mgold<$rename_gold){&error("돈이 충분하지 않습니다.($rename_gold Gold)");}
	&maplog("<font color=green>[개명]</font>$mname는<font color=red>$in{'rname'}</font>에 개명했습니다!");
	&maplog6("<font color=green>[개명]</font>$mname는<font color=red>$in{'rname'}</font>에 개명했습니다!");
	&kh_log("$mname→$in{'rname'}에 개명한다.",$con_name);
			
	$moya = int(rand(20000));
	$mgold-=$rename_gold;
	$mname="$in{'rname'}";
	&chara_input;

	&header;
	print <<"EOF";
<TABLE border="0" width="80%" bgcolor="#ffffff" height="150" align=center CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">개명의 신전</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="./img/etc/palace2.gif"></TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc"><font color=red>$in{'rname'}</font>에 개명했습니다.</FONT></TD>
    </TR>
    <TR>
      <TD colspan="2" align="right">
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value=돌아온다></form></TD>
	
    </TR>
  </TBODY>
</TABLE>
EOF
	&footer;
	exit;
}
1;

