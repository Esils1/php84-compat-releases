sub renkin2 {
	&chara_open;
	&town_open;
	$val_off=0;

	#어빌리티 정보
	($msk[0],$msk[1]) = split(/,/,$msk);
	open(IN,"./data/ability.cgi");
	@ABILITY = <IN>;
	close(IN);

	foreach(@ABILITY){
		($abno,$abname,$abcom,$abdmg,$abrate,$abpoint,$abclass,$abtype) =split(/<>/);
		if($msk[0] eq $abno || $msk[1] eq $abno){
			$mab[$abtype]=1;
			$mabdmg[$abtype]=$abdmg;
		}
	}

	$idata="renkin";
	if($in{'no'} eq ""){&error("올바르게 선택되지 않았습니다.");}
	

	open(IN,"./data/$idata.cgi") or &error("연금 데이터 파일을 열지 않았습니다.");
	@it_data = <IN>;
	close(IN);
	$it_num=@it_data;
	$num=$in{'no'};
	if($it_num>$num){
		($it_name,$it_val,$it_dmg,$it_wei,$it_ele,$it_hit,$it_cl,$it_type,$it_sta,$it_pos,$it_lv) =split(/<>/,$it_data[$in{'no'}]);
	}
	$it_val=int($it_val*(1-$val_off/100));

	if($it_lv > $mabdmg[21]){
		&maplog("<font color=red>[부정]</font>$mname는 련금으로 부정을 실시했습니다.");
		&error("부정을 실시했습니다.");
	}
	
	if($mabp<$it_val){&error("숙련도가 충분하지 않습니다.");}
	$mabp-=$it_val;

	open(IN,"./logfile/item/$in{'id'}.cgi");
	@ITEM = <IN>;
	close(IN);
	if(@ITEM>=$ITM_MAX){&error("더 이상 가질 수 없습니다.(최대$ITM_MAX개)");}

	push(@ITEM,"$in{'no'}<>3<>$it_name<>0<>$it_dmg<>$it_wei<>$it_ele<>$it_hit<>$it_cl<>$it_type<>$it_sta<>$it_flg<>\n");
	open(OUT,">./logfile/item/$in{'id'}.cgi");
	print OUT @ITEM;
	close(OUT);

	&maplog("<font color=orange>[연금]</font>$mname는<font color=red>$it_name</font>를 작성했습니다.");
	&chara_input;

	&header;
	
	print <<"EOF";
<TABLE border="0" width="80%" align=center height="150" CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="$FCOLOR"><FONT color="$FCOLOR2">연금</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="$FCOLOR2" width=20% align=center><img src="./img/etc/inn.gif"></TD>
      <TD bgcolor="#330000"><FONT color="$FCOLOR2">숙련도<font color=red>$it_val</font>Point를 소비했습니다.<BR><font color=red>$it_name</font>를 작성했습니다.</FONT></TD>
    </TR>
    <TR>
    <TD colspan="2" align="center" bgcolor="ffffff">
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value="거리에 돌아온다"></TD></form>
	</TD>
    </TR>
  </TBODY>
</TABLE>
<center></center>
EOF
	&footer;
	exit;
	
}
1;
