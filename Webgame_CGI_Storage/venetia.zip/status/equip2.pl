sub equip2 {
	&chara_open;
	
	if($in{'itno'} eq ""){&error("올바르게 선택되지 않았습니다.");}

	open(IN,"./logfile/item/$mid.cgi");
	@ITEM = <IN>;
	close(IN);
	($it_no,$it_ki,$it_name,$it_val,$it_dmg,$it_wei,$it_ele,$it_hit,$it_cl,$it_sta,$it_type,$it_flg) =split(/<>/,$ITEM[$in{'itno'}]);
	if($it_name =~ /속성변경의돌/) {
		$name = $it_name;
		&error("무속성이 되어야 합니다") if $mele ne 0 && $name !~ /무/;
		if ($name =~ /무/) { $mele = 0; }
		elsif ($name =~ /불/) { $mele = 1; }
		elsif ($name =~ /수/) { $mele = 2; }
		elsif ($name =~ /풍/) { $mele = 3; }
		elsif ($name =~ /별/) { $mele = 4; }
		elsif ($name =~ /번개/) { $mele = 5; }
		elsif ($name =~ /빛/) { $mele = 6; }
		elsif ($name =~ /어둠/) { $mele = 7; }
		&maplog("<font color=blue>[속성의 변경]</font>$mname은 자신의 속성을 $name을 이용해 변경했습니다.");
		$mess = "속성이 변경되었습니다.";
	}elsif($it_ki eq"0"){
		$idata="arm";
		($it_no2,$it_name2,$it_val2,$it_dmg2,$it_wei2,$it_ele2,$it_hit2,$it_cl2,$it_sta2,$it_type2,$it_flg2) =split(/,/,$marm);
		push(@ITEM,"$it_no2<>0<>$it_name2<>$it_val2<>$it_dmg2<>$it_wei2<>$it_ele2<>$it_hit2<>$it_cl2<>$it_sta2<>$it_type2<>$it_flg2<>\n");
		$marm="$it_no,$it_name,$it_val,$it_dmg,$it_wei,$it_ele,$it_hit,$it_cl,$it_sta,$it_type,$it_flg";
		$mess="<font color=red>$it_name</font>를 장비했습니다.";
	}elsif($it_ki eq"1"){
		$idata="pro";
		($it_no2,$it_name2,$it_val2,$it_dmg2,$it_wei2,$it_ele2,$it_hit2,$it_cl2,$it_sta2,$it_type2,$it_flg2) =split(/,/,$mpro);
		push(@ITEM,"$it_no2<>1<>$it_name2<>$it_val2<>$it_dmg2<>$it_wei2<>$it_ele2<>$it_hit2<>$it_cl2<>$it_sta2<>$it_type2<>$it_flg2<>\n");
		$mpro="$it_no,$it_name,$it_val,$it_dmg,$it_wei,$it_ele,$it_hit,$it_cl,$it_sta,$it_type,$it_flg";
		$mess="<font color=red>$it_name</font>를 장비했습니다.";
	}elsif($it_ki eq"2"){
		$idata="acc";
		($it_no2,$it_name2,$it_val2,$it_dmg2,$it_wei2,$it_ele2,$it_hit2,$it_cl2,$it_sta2,$it_type2,$it_flg2) =split(/,/,$macc);
		push(@ITEM,"$it_no2<>2<>$it_name2<>$it_val2<>$it_dmg2<>$it_wei2<>$it_ele2<>$it_hit2<>$it_cl2<>$it_sta2<>$it_type2<>$it_flg2<>\n");
		$macc="$it_no,$it_name,$it_val,$it_dmg,$it_wei,$it_ele,$it_hit,$it_cl,$it_sta,$it_type,$it_flg";
		$mess="<font color=red>$it_name</font>를 장비했습니다.";
	}elsif($it_ki eq"3"){
		$mess="<font color=red>$it_name</font>를 사용했습니다.";
		if($it_type eq"0"){
			$mhp += $it_dmg;
			if($mhp>$mmaxhp){$mhp = $mmaxhp;}
			$mess.="<BR>HP가<font color=red>$it_dmg</font>회복했습니다.";
		}elsif($it_type eq"3"){
			if($mele <= 0){
				$mele = $it_ele;
				$mess.="<BR>속성이<font color=red>$ELE[$it_ele]</font>에 변화했습니다.";
			}else{
				$mess.="<BR>그러나 아무것도 일어나지 않았다···.";
			}
		}elsif($it_type eq"9"){
			open(IN,"./logfile/battle/$in{'id'}.cgi");
			@BC_DATA = <IN>;
			close(IN);
			($mhpr,$mmpr,$mtim) =split(/<>/,$BC_DATA[0]);

			$date = time();
			$rec = 1;
			$mhpr+=$rec;
			$mmpr+=$rec;
			if($mhpr>1){$mhpr=1;}
			if($mmpr>1){$mmpr=1;}
			if($mmpr<0.2){$mmpr=0.2;}
	
			@N_BC=();
			unshift(@N_BC,"$mhpr<>$mmpr<>$date<>\n");
			open(OUT,">./logfile/battle/$in{'id'}.cgi");
			print OUT @N_BC;
			close(OUT);

			$mess.="<BR>상처가 치유되었습니다.";
		}elsif($it_type eq"10"){
			if(int(rand(4)) eq 1){
				$moya = 777;
				$mess.="<BR><font color=red>밤하늘에 유성이 보인다···</font>";
			}else{
				$mess.="<BR>그러나 아무것도 일어나지 않았다...";
			}
		}elsif($it_type eq"11"){
			$mabp += $it_dmg;
			$mess.="<BR>숙련도가<font color=red>$it_dmg</font>올라갔습니다.";
		}elsif($it_type eq"12"){
			$mjp[$it_ele] += $it_dmg;
			if($mjp[$it_ele]>$MAXJOB){$mjp[$it_ele] = $MAXJOB;}
			$mess.="<BR>$TYPE[$it_ele]숙련도가<font color=red>$it_dmg</font>올라갔습니다.";
		}elsif($it_type eq"13"){
			$mele = $it_ele;
			$mess.="<BR>속성이<font color=red>$ELE[$it_ele]</font>에 변화했습니다.";
		}elsif($it_type >= 20 && $it_type <=23){
			$trlv = $it_type - 19;
			$rate = $trlv * 25;

			$brand=int(rand(5));
			if($it_type eq 22){$brand= 1 + int(rand(3));}
			if($it_type eq 23){$brand= 1 + int(rand(3)) ;$rate = 100;}

			if($brand eq 1){
				$REA="arm";
				$reano=0;
				$b_no2 = int(rand(91));
				$ino=0;
				if(int(rand(100)) < $rate){
					$rflg=1;
					$REA="rarearm";
					$b_no2 = int(rand(26));
					if(($it_type eq 22 && int(rand(10)) eq 1) || $it_type eq 23){
						$b_no2 = 26 + int(rand(35));
					}
					$ino=0;
				}
			}
			elsif($brand eq 2){
				$REA="pro";
				$reano=1;
				$b_no2 = int(rand(59));
				$ino=0;
				if(int(rand(100)) < $rate){
					$rflg=1;
					$REA="rarepro";
					$b_no2 = int(rand(23));
					if(($it_type eq 22 && int(rand(10)) eq 1) || $it_type eq 23){
						$b_no2 = 23 + int(rand(21));
					}
					$ino=0;
				}
			}
			elsif($brand eq 3){
				$REA="acc";
				$reano=2;
				$b_no2 = int(rand(67));
				$ino=0;
				if(int(rand(100)) < $rate){
					$rflg=1;
					$REA="rareacc";
					$b_no2 = int(rand(25));
					if(($it_type eq 22 && int(rand(10)) eq 1) || $it_type eq 23){
						$b_no2 = 25 + int(rand(22));
					}
					$ino=0;
				}
			}
			else{
				$rflg=1;
				$REA="item";
				$reano=3;
				$b_no2 = int(rand(21));
				$ino=19;
			}
			open(IN,"./data/$REA.cgi");
			@A2_DATA = <IN>;
			close(IN);

			$kit_no=$ino+$b_no2;
			($rit_name,$rit_val,$rit_dmg,$rit_wei,$rit_ele,$rit_hit,$rit_cl,$rit_sta,$rit_type,$rit_pos) = split(/<>/,$A2_DATA[$kit_no]);
			if($rflg eq ""){
				$rit_dmg += int(rand($rit_dmg*0.2));
				$rit_wei -= int(rand(5));
				$rit_name.= "+";
			}
			if($rit_val ne ""){
				push(@ITEM,"rea<>$reano<>$rit_name<>$rit_val<>$rit_dmg<>$rit_wei<>$rit_ele<>$rit_hit<>$rit_cl<>$rit_sta<>$rit_type<>0<>\n");
				$mess.="<BR>보상안에는<font color=red>$rit_name</font>가 들어가 있었다.";
			}
			else{$mess.="<BR>그러나 보상은 텅 비었다···.";}
			&maplog("<font color=orange>[보상]</font>$mname는 보상을 열었습니다.");
		}elsif($it_type eq"24"){
			if($it_name eq "어둠의 모래시계" && $moya%2500 ne "17"){
				&error("푸른 하늘아래에서 사용해 주세요.");
			}else{
				$moya = $it_dmg;
			}
		}elsif($it_type eq"25"){
			if(int(rand(5)) eq 1){
				$moya = 77777;
				$mess.="<BR><font color=red>비보가 자는 장소가 기록되고 있었다!</font>";
			}else{
				$mess.="<BR>그러나 지도가 깨져 있어 비보의 소재는 몰랐다...";
			}
		}elsif($it_type eq"26"){
			$moya = int(rand(15));
			$mess.="<BR>조금 무엇인가 좋은 일 있을지도···？";
		}elsif($it_type eq "100"){
			$upval = 1;
			if($it_dmg eq "0"){
				$mmaxstr += $upval;
				$mess.="<font color=orange>힘의 한계가$upval 올랐다!</font><BR>";
			}elsif($it_dmg eq "1"){
				$mmaxvit += $upval;
				$mess.="<font color=orange>생명의 한계가$upval 올랐다!</font><BR>";
			}elsif($it_dmg eq "2"){
				$mmaxint += $upval;
				$mess.="<font color=orange>지력의 한계가$upval 올랐다!</font><BR>";
			}elsif($it_dmg eq "3"){
				$mmaxmen += $upval;
				$mess.="<font color=orange>정신의 한계가$upval 올랐다!</font><BR>";
			}elsif($it_dmg eq "4"){
				$mmaxdex += $upval;
				$mess.="<font color=orange>운의 한계가$upval 올랐다!</font><BR>";
			}elsif($it_dmg eq "5"){
				$mmaxagi += $upval;
				$mess.="<font color=orange>속도의 한계가$upval 올랐다!</font><BR>";
			}
			$mmax="$mmaxstr,$mmaxvit,$mmaxint,$mmaxmen,$mmaxdex,$mmaxagi,$mmaxlv";
		}elsif($it_type eq "101"){
			$upval = 2;
			if($it_dmg eq "0"){
				$mmaxstr += $upval;
				$mess.="<font color=orange>힘의 한계가$upval 올랐다!</font><BR>";
			}elsif($it_dmg eq "1"){
				$mmaxvit += $upval;
				$mess.="<font color=orange>생명의 한계가$upval 올랐다!</font><BR>";
			}elsif($it_dmg eq "2"){
				$mmaxint += $upval;
				$mess.="<font color=orange>지력의 한계가$upval 올랐다!</font><BR>";
			}elsif($it_dmg eq "3"){
				$mmaxmen += $upval;
				$mess.="<font color=orange>정신의 한계가$upval 올랐다!</font><BR>";
			}elsif($it_dmg eq "4"){
				$mmaxdex += $upval;
				$mess.="<font color=orange>운의 한계가$upval 올랐다!</font><BR>";
			}elsif($it_dmg eq "5"){
				$mmaxagi += $upval;
				$mess.="<font color=orange>속도의 한계가$upval 올랐다!</font><BR>";
			}

			if($it_wei eq "0"){
				$mmaxstr -= $upval;
				$mess.="<font color=blue>힘의 한계가$upval 내렸다..</font><BR>";
			}elsif($it_wei eq "1"){
				$mmaxvit -= $upval;
				$mess.="<font color=blue>생명의 한계가$upval 내렸다..</font><BR>";
			}elsif($it_wei eq "2"){
				$mmaxint -= $upval;
				$mess.="<font color=blue>지력의 한계가$upval 내렸다..</font><BR>";
			}elsif($it_wei eq "3"){
				$mmaxmen -= $upval;
				$mess.="<font color=blue>정신의 한계가$upval 내렸다..</font><BR>";
			}elsif($it_wei eq "4"){
				$mmaxdex -= $upval;
				$mess.="<font color=blue>운의 한계가$upval 내렸다..</font><BR>";
			}elsif($it_wei eq "5"){
				$mmaxagi -= $upval;
				$mess.="<font color=blue>속도의 한계가$upval 내렸다..</font><BR>";
			}

			if($mmaxstr>500){$mmaxstr=500;}
			if($mmaxvit>500){$mmaxvit=500;}
			if($mmaxint>500){$mmaxint=500;}
			if($mmaxmen>500){$mmaxmen=500;}
			if($mmaxdex>500){$mmaxdex=500;}
			if($mmaxagi>500){$mmaxagi=500;}

			if($mmaxstr<100){$mmaxstr=100;}
			if($mmaxvit<100){$mmaxvit=100;}
			if($mmaxint<100){$mmaxint=100;}
			if($mmaxmen<100){$mmaxmen=100;}
			if($mmaxdex<100){$mmaxdex=100;}
			if($mmaxagi<100){$mmaxagi=100;}
			
			$mmax="$mmaxstr,$mmaxvit,$mmaxint,$mmaxmen,$mmaxdex,$mmaxagi,$mmaxlv";
		}else{
			&error("그 아이템은 사용할 수 없습니다.");
		}
		&maplog4("[사용]$mname는<font color=red>$it_name</font>를 사용했습니다.");
		
	}else{&error("그 아이템은 장비할 수 없습니다.$it_ki");}
	splice(@ITEM,$in{'itno'},1);
	
	if($it_name){
		open(OUT,">./logfile/item/$in{'id'}.cgi");
		print OUT @ITEM;
		close(OUT);
		&chara_input;
	}else{&error("아이템에 이상이 있습니다.");}

	&header;
	
	print <<"EOF";
<TABLE border="0" width="80%" align=center height="150" CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="$FCOLOR"><FONT color="$FCOLOR2">아이템의 장비/사용</FONT></TD>
    </TR>
    <TR>
      <TD colspan=2 height=100 bgcolor="#330000"><FONT color="$FCOLOR2">$mess</FONT>
　　</TD></TR>
	<TR><TD align=center height=5%>
	<form action="./status.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=hidden name=mode value=equip>
	<INPUT type=submit CLASS=FC value="장비 화면에"></form>
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value=""거리에 돌아온다""></TD></form>
	</TD>
    </TR>
  </TBODY>
</TABLE>
<center></center>
EOF
	&footer;
	exit;
	
}
1;
