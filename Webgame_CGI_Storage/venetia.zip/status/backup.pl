sub backup{
	&chara_open;
	&town_open;
	&con_open;
	
	&host_name;
	$date = time();
	@N_DATA=();
	$mjp = "$mjp[0],$mjp[1],$mjp[2],$mjp[3],$mjp[4],$mjp[5]";
	$mmax = "$mmaxstr,$mmaxvit,$mmaxint,$mmaxmen,$mmaxdex,$mmaxagi,$mmaxlv";
	unshift(@N_DATA,"$mid<>$mpass<>$mname<>$murl<>$mchara<>$msex<>$mhp<>$mmaxhp<>$mmp<>$mmaxmp<>$mele<>$mstr<>$mvit<>$mint<>$mfai<>$mdex<>$magi<>$mmax<>$mcom<>$mgold<>$mbank<>$mex<>$mtotalex<>$mjp<>$mabp<>$mcex<>$munit<>$mcon<>$marm<>$mpro<>$macc<>$mtec<>$msta<>$mpos<>$mmes<>$host<>$date<>$mdate2<>$mclass<>$mtotal<>$mkati<>$mtype<>$moya<>$msk<>$mflg<>$mflg2<>$mflg3<>$mflg4<>$mflg5<>\n");
	open(OUT,">./logfile/backup/$in{'id'}.cgi") or &error('데이터를 쓸 수 없습니다.');
	print OUT @N_DATA;
	close(OUT);
	
	open(IN,"./logfile/item/$in{'id'}.cgi");
	@ITEM = <IN>;
	close(IN);

	open(OUT,">./logfile/backup/item/$in{'id'}.cgi");
	print OUT @ITEM;
	close(OUT);

	&header;
	print <<"EOF";
<TABLE border="0" width="80%" bgcolor="#ffffff" height="150" align=center CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">백업</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="./img/etc/inn2.gif"></TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc">백업의 작성을 실시했습니다.</FONT></TD>
    </TR>
    <TR>
      <TD colspan="2" align="right">
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value=돌아온다></form></TD>
	
    </TR>
  </TBODY>
</TABLE>
EOF
	&chara_input;
	&footer;
	exit;
}
1;

