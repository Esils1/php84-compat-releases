sub item_send {
	&chara_open;
	&status_print;
	&con_open;

	$dir="./logfile/chara";
	opendir(dirlist,"$dir");
	$i=0;
	while($file = readdir(dirlist)){
		if($file =~ /\.cgi/i){
			$datames = "검색：$dir/$file<br>\n";
			if(!open(cha,"$dir/$file")){
				&error("$dir/$file가 발견되지 않습니다.<br>\n");
			}
			@cha = <cha>;
			close(cha);
			$list[$i]="$file";
			($rid,$rpass,$rname,$rurl,$rchara,$rsex,$rhp,$rmaxhp,$rmp,$rmaxmp,$rele,$rstr,$rvit,$rint,$rfai,$rdex,$ragi,$rmax,$rcom,$rgold,$rbank,$rex,$rtotalex,$rjp,$rabp,$rcex,$runit,$rcon,$rarm,$rpro,$racc,$rtec,$rsta,$rpos,$rmes,$rhost,$rdate,$rsyo,$rclass,$rtotal,$rkati,$rtype) = split(/<>/,$cha[0]);
			$clist[$rcon].="<option value=$rid>$rname씨에게";
		}
		$mn++;
	}
	closedir(dirlist);
		
	foreach(@CON_DATA){
		($con2_id,$con2_name,$con2_ele,$con2_gold,$con2_king,$con2_yaku,$con2_cou,$con2_mes,$con2_etc) =split(/<>/);
		$plist.="<option value=\"\">★★★$con2_name국★★★";
		$plist.="$clist[$con2_id]";
	}
	$plist.="<option value=\"\">★★★무소속★★★";
	$plist.="$clist[0]";

	open(IN,"./logfile/item/$mid.cgi");
	@ITEM = <IN>;
	close(IN);
	$no2=0;
	foreach(@ITEM){
		($it_no,$it_ki,$it_name,$it_val,$it_dmg,$it_wei,$it_ele,$it_hit,$it_cl,$it_sta,$it_type,$it_flg) =split(/<>/);
		$sel_val=int($it_val/2);
		$ittable.="<TR><TD width=5% bgcolor=ffffcc><input type=radio name=itno value=$no2></TD><TD bgcolor=white><font size=2>$it_name</font></TD><TD bgcolor=white><font size=2>$sel_val</font></TD><TD bgcolor=white><font size=2>$it_dmg</font></TD><TD bgcolor=white><font size=2>$it_wei</font></TD><TD bgcolor=white><font size=2>$ELE[$it_ele]</font></TD><TD bgcolor=white><font size=2>$EQU[$it_ki]</font></TD></TR>";
		$no2++;
	}

	&header;
	
	print <<"EOF";
<TABLE border="0" width="80%" align=center bgcolor="#ffffff" height="150" CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">송금</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="./img/etc/pub.gif"></TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc">지정한 상대에게 아이템을 보냅니다.<BR>상대를 선택해, 보내는 아이템을 선택해 주세요.</FONT></TD>
    </TR>
    <TR>
      <TD colspan="2" align="center">
	$STPR 
	<form action="./status.cgi" method="post">
	<select name=player>
	$plist
	</select>
	<BR>
	<table border=0 width="90%" align=center bgcolor=$FCOLOR CLASS=TC>
	<BR>
	<TR><td colspan=7 align=center bgcolor="$FCOLOR"><font color=ffffcc>소지품 리스트</font></td></tr>
	<TR>
	<TD bgcolor=ffffcc></TD><td bgcolor=white><font size=2>이름</font></td><td bgcolor=white><font size=2>판매가</font></td><td bgcolor=white><font size=2>위력</font></td><td bgcolor=white><font size=2>무게</font></td><td bgcolor=white><font size=2>속성</font></td><td bgcolor=white><font size=2>종류</font></td>
	</TR>
	$ittable
	</table>
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=hidden name=mode value=item_send2>
	<INPUT type=submit value=보낸다 CLASS=FC></form>
	</form>
	
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value=돌아온다></form></TD>
	
	</TR></font>
    </TR>
  </TBODY>
</TABLE>
<center></center>
EOF

	&footer;
	exit;
}
1;

