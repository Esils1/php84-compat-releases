sub tec_set {
	&chara_open;
	&header;
	&status_print;

	($mtec1,$mtec2,$mtec3,$mprate,$hprate) =split(/,/,$mtec);
	($otec1,$otec2,$otec3,$omprate,$ohprate) =split(/,/,$mflg4);

	open(IN,"./data/tec.cgi");
	@TEC = <IN>;
	close(IN);

	require './data/abini.cgi';
	@jlist = split(/,/,$AJOB[$mclass]);

	$i=0;
	foreach(@jlist){
		$jobflg[$jlist[$i]] = 1;
		$i++;
	}

	$teclist1="<select name=tec1>";
	$teclist2="<select name=tec2>";
	$teclist3="<select name=tec3>";

	$teclist.="<option>--기술을 선택해 주세요--";
	$j=0;

	($tecname,$tecdmg,$tecrate,$tecmp,$tecab,$tecsta,$tecclass) =split(/<>/,$TEC[$mtec1]);
	if($tecname){$teclist1.="<option value=$mtec1>$tecname(위력：$tecdmg 확률：$tecrate 소비：$tecmp)";}
	($tecname,$tecdmg,$tecrate,$tecmp,$tecab,$tecsta,$tecclass) =split(/<>/,$TEC[$mtec2]);
	if($tecname){$teclist2.="<option value=$mtec2>$tecname(위력：$tecdmg 확률：$tecrate 소비：$tecmp)";}
	($tecname,$tecdmg,$tecrate,$tecmp,$tecab,$tecsta,$tecclass) =split(/<>/,$TEC[$mtec3]);
	if($tecname){$teclist3.="<option value=$mtec3>$tecname(위력：$tecdmg 확률：$tecrate 소비：$tecmp)";}
	
	foreach(@TEC){
		($tecname,$tecdmg,$tecrate,$tecmp,$tecab,$tecsta,$tecclass) =split(/<>/);
		($str,$vit,$int,$fai,$dex,$agi) =split(/,/,$tecab);
		if(($jobflg[$tecclass] && $tecclass ||$tecclass eq"all") && $mstr>$str && $mvit>$vit && $mint>$int && $mfai>$fai && $mdex>$dex && $magi>$agi){
			$teclist.="<option value=$j>$tecname(위력：$tecdmg 확률：$tecrate 소비：$tecmp)";
		}
		$j++;
	}
	$teclist.="</select><br>";

	$teclist1.="$teclist";
	$teclist2.="$teclist";
	$teclist3.="$teclist";

	print <<"EOF";
<TABLE border="0" width="80%" align=center bgcolor="#ffffff" height="150" CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">기술세트</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="./img/etc/house.gif"></TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc">어서 오십시오, 여기에서는 기술의 변경을 할 수 있습니다.<BR>조건 마다 기술을 설정해 주세요.<BR>기술의 우선 순위는, 조건 1＜조건 2＜조건 3이 됩니다.</FONT></TD>
    </TR>
    <TR>
      <TD colspan="2" align="center">
	$STPR 
	<form action="./status.cgi" method="post">
	<table border=0 CLASS=FC>
	<tbody>
	<tr><td>조건 1：</td><td>통상</td><td>$teclist1</td></tr>
	<tr><td>조건 2：</td><td>MP가<input type=text size=5 name=mprate value=$mprate>%이하로</td><td>$teclist2</td></tr>
	<tr><td>조건 3：</td><td>HP가<input type=text size=5 name=hprate value=$hprate>%이하로</td><td>$teclist3</td></tr>
	</tbody></table>
	코멘트：<INPUT type=text size=50 name=bcom value=$mcom><BR>
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=hidden name=mode value=tec_set2>
	<INPUT type=submit value=결정 CLASS=FC></form>
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value=돌아온다></form></TD>
	
    </TR>
  </TBODY>
</TABLE>
<center></center>
EOF

	&footer;
	exit;
}
1;
