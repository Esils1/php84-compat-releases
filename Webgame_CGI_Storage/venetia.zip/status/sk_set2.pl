sub sk_set2{
	&chara_open;
	if($in{'type'} eq "1" && $in{'skill'} eq "" ){&error("어빌리티가 올바르게 선택되고 있지 않습니다.");}
	if($in{'type'} eq "2" && $in{'skill2'} eq "" ){&error("어빌리티가 올바르게 선택되고 있지 않습니다.");}
	($msk[0],$msk[1]) = split(/,/,$msk);
	
	
	if($in{'type'} eq "1"){
		$msk="$in{'skill'},$msk[1]";
	}elsif($in{'type'} eq "2"){
		$msk="$msk[0],$in{'skill2'}";
	}
	&chara_input;

	
	&header;
	print <<"EOF";
<TABLE border="0" width="80%" bgcolor="#ffffff" height="150" align=center CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">변경 완료</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="./img/etc/palace2.gif"></TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc">어빌리티를 변경했습니다.</FONT></TD>
    </TR>
    <TR>
      <TD colspan="2" align="right">
	<form action="./status.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=hidden name=mode value=sk_set>
	<INPUT type=submit CLASS=FC value=변경 화면에></form>
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value=거리에></form>
    </TD>
    </TR>
  </TBODY>
</TABLE>
EOF
	&footer;
	exit;
}
1;

