sub type_change {
	&chara_open;
	&header;
	&status_print;

	$j=0;
	$menulist="<select name=type>";
	foreach(@TMENU){
		$menulist.="<option value=$j>$TMENU[$j]";
		$j++;
	}
	$menulist.="</select>";

	print <<"EOF";
<TABLE border="0" width="80%" align=center bgcolor="#ffffff" height="150" CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="#993300"><FONT color="#ffffcc">훈련 메뉴의 변경</FONT></TD>
    </TR>
    <TR>
      <TD bgcolor="#ffffcc" width=20% align=center><img src="./img/etc/house.gif"></TD>
      <TD bgcolor="#330000"><FONT color="#ffffcc">훈련 메뉴를 변경합니다.<BR>레벨업시의\능\력의 상승에 영향을 줍니다.<BR>이하의 리스트로부터 훈련 메뉴를 선택해 주세요.</FONT></TD>
    </TR>
    <TR>
      <TD colspan="2" align="center">
	$STPR 
	<form action="./status.cgi" method="post">
	$menulist
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=hidden name=mode value=type_change2>
	<INPUT type=submit value=변경 CLASS=FC></form>
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value=돌아온다></form></TD>
	
    </TR>
  </TBODY>
</TABLE>
<center></center>
EOF

	&footer;
	exit;
}
1;

