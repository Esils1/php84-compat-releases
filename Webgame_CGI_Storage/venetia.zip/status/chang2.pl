sub chang2 {
	&chara_open;
	
	if($in{'act'} eq "in") { #입고
		if($in{'itno'} eq ""){&error("올바르게 선택되지 않았습니다.");}

		open(IN,"./logfile/item/$mid.cgi");
		@ITEM = <IN>;
		close(IN);
		($it_no,$it_ki,$it_name,$it_val,$it_dmg,$it_wei,$it_ele,$it_hit,$it_cl,$it_sta,$it_type,$it_flg) =split(/<>/,$ITEM[$in{'itno'}]);

		open(IN, "./logfile/itembag/$mid.cgi");
		@CITEM = <IN>;
		close(IN);

		push(@CITEM,"$ITEM[$in{'itno'}]");

		open(OUT,">./logfile/itembag/$in{'id'}.cgi");
		print OUT @CITEM;
		close(OUT);

		splice(@ITEM,$in{'itno'},1);
		
		if($it_name){
			open(OUT,">./logfile/item/$in{'id'}.cgi");
			print OUT @ITEM;
			close(OUT);
		}else{&error("아이템에 이상이 있습니다.");}

		$mess = "<font color=red>$it_name</font>의 <font color=red>입고</font>가 정상적으로 처리되었습니다^^";
	}elsif($in{'act'} eq "out") { #출고
		if($in{'itno2'} eq ""){&error("올바르게 선택되지 않았습니다.");}

		open(IN,"./logfile/itembag/$mid.cgi");
		@ITEM = <IN>;
		close(IN);
		($it_no,$it_ki,$it_name,$it_val,$it_dmg,$it_wei,$it_ele,$it_hit,$it_cl,$it_sta,$it_type,$it_flg) =split(/<>/,$ITEM[$in{'itno2'}]);

		open(IN, "./logfile/item/$mid.cgi");
		@CITEM = <IN>;
		close(IN);

		push(@CITEM,"$ITEM[$in{'itno2'}]");

		open(OUT,">./logfile/item/$in{'id'}.cgi");
		print OUT @CITEM;
		close(OUT);

		splice(@ITEM,$in{'itno2'},1);
		
		if($it_name){
			open(OUT,">./logfile/itembag/$in{'id'}.cgi");
			print OUT @ITEM;
			close(OUT);
		}else{&error("아이템에 이상이 있습니다.");}

		$mess = "<font color=red>$it_name</font>의 <font color=red>출고</font>가 정상적으로 처리되었습니다^^";
	}
	&chara_input;
	&header;
	
	print <<"EOF";
<TABLE border="0" width="80%" align=center height="150" CLASS=FC>
  <TBODY>
    <TR>
      <TD colspan="2" align="center" bgcolor="$FCOLOR"><FONT color="$FCOLOR2">아이템 창고</FONT></TD>
    </TR>
    <TR>
      <TD colspan=2 height=100 bgcolor="#330000"><FONT color="$FCOLOR2">$mess</FONT>
　　</TD></TR>
	<TR><TD align=center height=5%>
	<form action="./top.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=submit CLASS=FC value="거리에 돌아온다"></TD></form>
    </TR>
	<TR><TD align=center height=5%>
	<form action="./status.cgi" method="POST">
	<INPUT type=hidden name=id value=$mid>
	<INPUT type=hidden name=pass value=$mpass>
	<INPUT type=hidden name=mode value=chang>
	<INPUT type=submit CLASS=FC value="창고 화면으로"></TD></form>
    </TR>
  </TBODY>
</TABLE>
<center></center>
EOF
	&footer;
	exit;
	
}
1;
