#!/usr/bin/perl
require './jcode.pl';
require './sub.cgi';
require './conf.cgi';
&decode;
&header;

open(IN,"./data/country.cgi");
@CON = <IN>;
close(IN);
open(IN,"./data/towndata.cgi");
@TOWN_DATA = <IN>;
close(IN);

$dir="./logfile/chara";
opendir(dirlist,"$dir");
$i=0;
while($file = readdir(dirlist)){
	if($file =~ /\.cgi/i){
		$datames = "검색：$dir/$file<br>\n";
		if(!open(cha,"$dir/$file")){
			&error("$dir/$file가 발견되지 않습니다.<br>\n");
		}
		@cha = <cha>;
		close(cha);
		$list[$i]="$file";
		($rid,$rpass,$rname,$rurl,$rchara,$rsex,$rhp,$rmaxhp,$rmp,$rmaxmp,$rele,$rstr,$rvit,$rint,$rfai,$rdex,$ragi,$rmax,$rcom,$rgold,$rbank,$rex,$rtotalex,$rjp,$rabp,$rcex,$runit,$rcon) = split(/<>/,$cha[0]);
		$KOKUMIN[$rcon]++;
	}
	if($mn>10000){&error("루프");}
	$mn++;
}
closedir(dirlist);

foreach(@TOWN_DATA){
	($town_id,$town_name,$town_con,$town_ele,$town_gold,$town_arm,$town_pro,$town_acc,$town_ind,$town_tr,$town_s,$town_x,$town_y,$town_etc) =split(/<>/);
	$TOWN[$town_con]++;
}

$conlist="<table CLASS=FC width=100%>";
$conlist.="<tr><td CLASS=TC><font color=$FCOLOR2>국명</font></td><td CLASS=TC><font color=$FCOLOR2>국왕</font></td><td CLASS=TC><font color=$FCOLOR2>국민</font></td><td CLASS=TC><font color=$FCOLOR2>자금</font></td><td CLASS=TC><font color=$FCOLOR2>영토</font></td></tr>";

foreach(@CON){
	($con2_id,$con2_name,$con2_ele,$con2_gold,$con2_king,$con2_yaku,$con2_cou,$con2_mes,$con2_etc) =split(/<>/);
	push(@CONS,"$con2_id<>$con2_name<>$KOKUMIN[$con2_id]<>$con2_gold<>$TOWN[$con2_id]<>\n");
	$CONELE[$con2_id]=$con2_ele;
	$CONNAME[$con2_id]=$con2_name;
	$c_no++;
}

@tmp = map {(split /<>/)[2]} @CONS;
@CONS = @CONS[sort {$tmp[$b] <=> $tmp[$a]} 0 .. $#tmp];
$rank=1;
foreach(@CONS){
	($con3_id,$con3_name) =split(/<>/);
	$KRANK[$con3_id]=$rank;
	$POINT[$con3_id]+=($c_no-$rank)*2;
	if($rank eq 1){$KRANK1="$con3_name";}
	$rank++;
}
@tmp = map {(split /<>/)[3]} @CONS;
@CONS = @CONS[sort {$tmp[$b] <=> $tmp[$a]} 0 .. $#tmp];

$rank=1;
foreach(@CONS){
	($con3_id,$con3_name) =split(/<>/);
	$GRANK[$con3_id]=$rank;
	$POINT[$con3_id]+=($c_no-$rank);
	if($rank eq 1){$GRANK1="$con3_name";}
	$rank++;
}
@tmp = map {(split /<>/)[4]} @CONS;
@CONS = @CONS[sort {$tmp[$b] <=> $tmp[$a]} 0 .. $#tmp];

$rank=1;
foreach(@CONS){
	($con3_id,$con3_name) =split(/<>/);
	$TRANK[$con3_id]=$rank;
	$POINT[$con3_id]+=($c_no-$rank);
	if($rank eq 1){$TRANK1="$con3_name";}
	push(@NCONS,"$con3_id<>$con3_name<>$KRANK[$con3_id]<>$GRANK[$con3_id]<>$TRANK[$con3_id]<>$POINT[$con3_id]<>\n");
	$rank++;
}


foreach(@CON){
	($con2_id,$con2_name,$con2_ele,$con2_gold,$con2_king,$con2_yaku,$con2_cou,$con2_mes,$con2_etc) =split(/<>/);
	open(IN,"./logfile/chara/$con2_king.cgi");
	@K_DATA = <IN>;
	close(IN);
	($kid,$kpass,$kname,$kurl,$kchara,$ksex) =split(/<>/,$K_DATA[0]);
	$conlist.="<tr><td bgcolor=$ELE_BG[$con2_ele]><font color=$ELE_C[$con2_ele]>$con2_name국($ELE[$con2_ele])</font></td><td bgcolor=$ELE_C[$con2_ele]>$kname</td><td bgcolor=$ELE_C[$con2_ele] align=right>$KOKUMIN[$con2_id]인($KRANK[$con2_id]위)</td><td bgcolor=$ELE_C[$con2_ele] align=right>$con2_gold Gold($GRANK[$con2_id]위)</td><td bgcolor=$ELE_C[$con2_ele] align=right>$TOWN[$con2_id]($TRANK[$con2_id]위)</td></tr>";

}
$conlist.="</table>";


##맵 표시
$tpr="<table bgcolor=663300><TD width=15 height=10 bgcolor=ffffcc CLASS=GC>　</TD>";
for($i=0;$i<6;$i++){
	$tpr.= "<TD width=15 height=10 bgcolor=ffffcc><font size=1>$i</font></TD>";
}
for($i=0;$i<6;$i++){
	$n = $i;
	$tpr.= "<TR><TD bgcolor=ffffcc><font size=1>$n</font></td>";
	for($j=0;$j<6;$j++){
		$m_hit=0;$tx=0;
		foreach(@TOWN_DATA){
			($town2_id,$town2_name,$town2_con,$town2_ele,$town2_gold,$town2_arm,$town2_pro,$town2_acc,$town2_ind,$town2_tr,$town2_s,$town2_x,$town2_y) =split(/<>/);
			if("$town2_x" eq "$j" && "$town2_y" eq "$i"){$m_hit=1;last;}
			$tx++;
		}
		$col="";
		if($m_hit){
			
			$col = $ELE_BG[$CONELE[$town2_con]];
			
			if($town2_id eq 0){
				$tpr.= "<TH bgcolor=$col><img src=\"./img/town/m_2.gif\" title=\"$town2_name【$CONNAME[$town2_con]】\" width=15 height=10></TH>";
			}else{
				$tpr.= "<TH bgcolor=$col><img src=\"./img/town/m_4.gif\" title=\"$town2_name【$CONNAME[$town2_con]】\" width=15 height=10></TH>";
			}
		}else{
			$tpr.= "<TH>　</TH>";
		}
	}
	$tpr.= "</TR>";
}
$tpr.="</table>";

$m=0;
open(IN,"./data/maplog2.cgi");
@MA = <IN>;
close(IN);
foreach(@MA){
	$mapl.="<b><font color=$FCOLOR>●$MA[$m]</font></b><BR>";
	$m++;
}


#상황 해설

@tmp = map {(split /<>/)[5]} @NCONS;
@NCONS = @NCONS[sort {$tmp[$b] <=> $tmp[$a]} 0 .. $#tmp];
($c_id,$c_name,$korank,$grank,$trank,$point) =split(/<>/,$NCONS[0]);
if($c_no>4){
	($c_id2,$c_name2,$korank2,$grank2,$trank2,$point2) =split(/<>/,$NCONS[1]);
	($c_id3,$c_name3,$korank3,$grank3,$trank3,$point3) =split(/<>/,$NCONS[2]);
}
$c_no2=$c_no-1;
($c_idl,$c_namel,$korankl,$grankl,$trankl,$pointl) =split(/<>/,$NCONS[$c_no2]);
if($c_no>1){
	$com.="현재$c_no개국이 싸우는 상황.그 중에 「$c_name국」우세라고나 할까.<BR>";
	if($c_no>4){
		$com.="2번째에는 「$c_name2국」,그 다음에 「$c_name3국」이 뒤를 쫓는 형태말한다.<BR>";
	}
	$com.="국민의 수에서는 「$KRANK1국」, 자금력으로는 「$GRANK1국」, 영토의 넓이에서는 「$TRANK1국」이 리드.<BR>";
	if($korank eq 1){
		$com.="「$c_name국」은 국민수에 대해도 타국에 이기고 있어 향후도 「$c_name국」을 중심으로 움직인다고 생각된다.<BR>";
	}else{
		$hit=1;
		$com.="그러나 「$KRANK1국」은 국민수에 대해 「$c_name국」에 이기고 있어 향후 성장해 갈 것이다.「$c_name」를 가장 위협하는 존재이다.<BR>";
	}if($grank ne 1 && !$hit){
		$com.="「$GRANK1국」은 전력으로는 약간 뒤떨어지지만, 풍부한 자금을 가져, 어떻게 이용해 나갈까에 주목이다.<BR>";
	}
	if($c_no>2){
		$com.="「$c_namel국」은 약간 형세 불리한 상황이라고 했는데이지만, 우수한 인재는 대부분 존재한다.과연 향후 어떠한 전개를 보여 주는 것일까.<BR>";
	}
	if($c_no eq 2){
		$com.="이 2국 가운데, 어느 쪽이 싸워 이기는 것일까.그렇지 않으면 아직 보지 않는 국가가···<BR>";
	}
}elsif($c_no>0){
	$com.="현재는 「$c_name국」의 1개국이 건국되고 있는 상황이다.「$c_name국」이 이대로 세계를 통일할 수 있는 것일까.<BR>";
}else{
	$com.="아직도 나라를 일으키는 사람은 나타나지 않았다.이 앞 어떤 국가가 탄생해, 어떠한 전개가 기다리고 있을 것이다인가.<BR>";
}
print <<"EOF";
<CENTER>
<TABLE border="0" bgcolor="#660033" width="700" cellspacing="5" height="509">
  <TBODY>
    <TR>
      <TD colspan="2" width="696" align="center"><FONT style="font-size:30px" font color="#ffff99">세계 정세</FONT></TD>
    </TR>
    <TR>
      <TD align="center" bgcolor="#330000" width="30%" height="80">
	$tpr<BR>
      </TD>
　　　<TD colspan="1" align="left" bgcolor="#844200" width="70%" height="80">
	<FONT style="font-size:17px" font face="HG행서체" color="#ffffcc"><각국의 상황><BR>$com</FONT>
      </TD>
    </TR>
    <TR>
      <TD colspan="2" bgcolor="#330000">
	<FONT style="font-size:15px" font face="HG행서체" color="#660000">$conlist</FONT>
      </TD>
    </TR>
    <TR>
      <TD colspan="2" bgcolor="#ffffcc">
	<FONT style="font-size:15px" font face="HG행서체" color="#660000"><역사><BR>$mapl</FONT>
	</TD>
    </TR>
  </TBODY>
</TABLE>
</CENTER>

<hr>
EOF

&footer;
exit;

