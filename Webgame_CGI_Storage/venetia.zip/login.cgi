#!/usr/bin/perl
require './jcode.pl';
require './sub.cgi';
require './conf.cgi';
&decode;

open(IN,"./data/guest_list.cgi");
@gue = <IN>;
close(IN);
$guest=@gue;
#if($guest>$LMAX){&error2("참가자 다수 때문에, 로그인할 수 없습니다.");}
if($guest>$LMAX*0.9){&login2;}
else{&login;}

sub login{
	&header;

print <<"EOF";
<BR>
<BR>
<CENTER>

<form action="login2.cgi" method="POST">
<TABLE border="0" width="200" CLASS=FC>
  <TBODY>
    <TR>
      <TD bgcolor=$FCOLOR colspan=2 align=center><font size=3 color=$FCOLOR2>로그인 화면</font></TD>
    </TR>
    <TR>
      <TD width="56" align=right>ID</TD>
      <TD width="46"><input type=text size=15 name=id></TD>
    </TR>
    <TR>
      <TD width="56" align=right>PASS</TD>
      <TD width="46"><input type=password size=15 name=pass></TD>
    </TR>
    <TR>
      <TD colspan="2" align=center><input type=submit CLASS=FC value=로그인></TD>
    </TR>
  </TBODY>
</TABLE>
</CENTER>
</form>
EOF
	&footer;
	exit;
}

sub login2{
	&header;

	open(IN,"./data/apo.cgi");
	@apo = <IN>;
	close(IN);
	&host_name;
	$timer = time() ;@newapo=();
	foreach(@apo) {
		($gname,$gid,$gtime) =split(/<>/);
		$time=300+$gtime-$timer;
		if($time>0){
			$guest2.="$gname(나머지$time초)<BR>";
		}else{
			$guest2.="<font color=red>$gname(로그인가\능\)</font><BR>";
		}
	}

print <<"EOF";
<CENTER>
<TABLE border="0" width="100%" CLASS=FC>
  <TBODY>
    <TR>
      <TD bgcolor=$FCOLOR colspan=2 align=center><font size=3 color=$FCOLOR2>부하 방지 모드</font></TD>
    </TR>
    <TR>
      <TD width="100%" colspan=2 align=center>현재 매우 붐비고 있습니다. 예약을 실시해, 로그인까지 5분간 기다려 주세요.</TD>
    </TR>
  </TBODY>
</TABLE>

<form action="login3.cgi" method="POST">

<TABLE border="0" width="300" CLASS=FC>
  <TBODY>
    <TR>
      <TD bgcolor=$FCOLOR colspan=2 align=center><font size=3 color=$FCOLOR2>예약화면<</font></TD>
    </TR>
    <TR>
      <TD width="200" align=right>닉네임(가짜)</TD>
      <TD width="100"><input type=text size=15 name=name></TD>
    </TR>
    <TR>
      <TD width="200" align=right>ID</TD>
      <TD width="100"><input type=text size=15 name=id></TD>
    </TR>
    <TR>
      <TD colspan="2" align=center><input type=submit CLASS=FC value="예약"></TD>
    </TR>
  </TBODY>
</TABLE>
</form>
<TABLE border="0" width="500" CLASS=FC>
  <TBODY>
    <TR>
      <TD bgcolor=$FCOLOR colspan=2 align=center><font size=3 color=$FCOLOR2>\예\약자 일람</font></TD>
    </TR>
    <TR>
      <TD bgcolor=$FCOLOR2 colspan=2 align=center><font size=3 color=$FCOLOR>$guest2</font></TD>
    </TR>
  </TBODY>
</TABLE>
<form action="login4.cgi" method="POST">
<TABLE border="0" width="200" CLASS=FC>
  <TBODY>
    <TR>
      <TD bgcolor=$FCOLOR colspan=2 align=center><font size=3 color=$FCOLOR2>로그인 화면</font></TD>
    </TR>
    <TR>
      <TD width="56" align=right>ID</TD>
      <TD width="46"><input type=text size=15 name=id></TD>
    </TR>
    <TR>
      <TD width="56" align=right>PASS</TD>
      <TD width="46"><input type=password size=15 name=pass></TD>
    </TR>
    <TR>
      <TD colspan="2" align=center><input type=submit CLASS=FC value=로그인></TD>
    </TR>
  </TBODY>
</TABLE>
</CENTER>
</form>
</CENTER>
EOF
	&footer;
	exit;
}

