#!/usr/bin/perl
# ↑서버의 환경에 맞게 변경해주세요.
# #############################################################
# 넷항해시대
# Copyright (C) 2002 코스미, All rights reserved.
# E-Mail : impulse@kun.ne.jp
# Web : http://www.kosumi.vxx.jp/
# 이 스크립트는 프레웨어입니다.
# 이용방침은 URL:http://www.kosumi.vxx.jp/rules.htm
# 에 기재되었으며 이 스크립트를 사용하는것은 이용방침에 동의한것으로 간주합니다.
# 저작권은 코스미가 가지고 있으며,
# 이 스크립트의 일부분은 Missing Link의 PeoPle 의 일부분을
# 인용하였습니다.
# 인용부분에 대한 저작권등은 Missing Link 의 Sho님에게 있습니다.
# 자세한것은 ReadMe를 봐주세요.(Missing Link:http://www.area-s.com/)
# 이 스크립트를 이용함으로 인해 발생하는 피해는 책임지지 않습니다.
# 질문등은 서포트 게시판을 이용해주세요. (http://www.kosumi.vxx.jp/support.htm)
# #############################################################
#  한글번역 - 꼬마얀 (Transfered by midGetyAn)
#  Web : http://vampelf.freeto.net/
# #############################################################

# 필요에 따라 아래의 설정을 변경하세요.
use lib '/var/www/html/game/venetia';
use Nfile;
$g_basedat	= 'base.dat';	# 교역품 기본 가격
$yarddat	= 'item.dat';	# 배 가격 및 판매 항구
$adfiles	= 'a_list.dat';	# 모험정보 목록

$trade_lower	= 0.5;		# 물가의 하한(0.5이상)
$trade_upper	= 1.5;		# 물가의 상한(1.5이하)
$flac       	= 0.00000003;	# 1G 에 대한 변동양
$sell_rate  	= 0.6;		# 매각시의 값 (원가 ×)
$cf		= 213;		# 교역품의 랜덤 변동 갯수(적당한값임. 0이면 변동하지 않음.)
$cycle		= 7;		# 랜덤 변동의 주기(일)
$pay		= 100;		# 선원 1인당 고용료
$f_price	= 10;		# 식료품 1개당 가격
$time_scale	= 250;		# 이동시간 200~500 추천
$waste		= 0.001;	# 선원 1명이 1초에 소비하는 식료품
$cont		= 15;		# 연속전투 제한 (분)
$same		= 0.5;		# 같은 상대 전투 제한 (일)
$stop		= 3;		# 계류시간 (시)
$robmoney	= 5;		# 전투로 빼앗는 돈의 최대 액(%)
$b_flac		= 100;		# 마을 습격시의 난수폭
$atk_limit	= 200;		# 전투력 한계
$cmd_limit	= 150;		# 지휘력 한계
$nav_limit	= 200;		# 항해력 한계
$newcity	= 1000000;	# 도시의 신설에 필요한 자금
$poten		= 10000;	# 도시의 초기 HP
$r_fee		= 50;		# 도시의 수리비용 (HP1당)
$atkfee		= 1000000;	# 도시에 공작을 걸기위한 비용
$cityatked 	= 1000;		# 공작시의 데미지
$citypwr	= 400;		# 도시의 기본 공격력
$cl_limit	= 7;		# 도시의 반입가능 갯수 (교역품)
$cs_limit	= 7;		# 도시의 반입가능 갯수 (배)
$rookie		= 30;		# 신인 수
$retry		= 1;		# 재 등록제한 (시간) -1라면 제한안함.

$x_rev	= 85;			# 지도 0,0 의 값 픽셀
$y_rev	= 73;
$map_x	= 0.556;		# x 방향의 1' 에 해당하는 값 (픽셀), 지도 폭/360
$map_y	= 0.733;		# 지도 높이/180
$map_height = 132;		# 지도의 폭
$map_width = 200;		# 지도의 높이
$move_ship = "move.gif";	# 이동용 배 이미지
$move_width = 400;		# 이동 거리 (픽셀)

# 보물 특수 효과
@shield = ('삿톤후의 투구', '왕족의 검', '수정의 촉루');	# 피습격시 쉴드(shield)
$atkup = ('시페토테쿠신의 가면');		# 공격턴수증가
$gard = ('왕의 심볼');				    	# 보물 보호
$vanish = ('태양의 돌');						# 전투 회피
$save = ('존 왕의 술잔');					# 식료 소비 절감

# ↓각 포인트로의 메시지('해상','항구','교역소','조선소','술집','도시','습격')
@ms = ( '' , '「해적들이 눈에 불을 켜겠군요..」' , '「교역의 기본은 싸게 사고 비싸게 파는 것이지..」' , '「최고의 선단을 만들어보자고!」' , '「술집은 항구의 오아시스란말이야！」' , '' , 'Good luck !');   

require 'setting.cgi';		# 설정 파일
require 'sys.cgi';

# 설정은 여기까지

# ###################################################################
&error("유저 폴더 이름을 변경해주세요. [setting.cgi]") if $usrdir eq 'userdir';
&decode;
if ($F{'id'} =~ /\W/) { &error('부정한 입력입니다.') }
if (!$F{'mode'})      { require 'rank.cgi'; &start_view }
else                  {
				if	(($F{'mode'} eq 'trade_sell') || ($F{'mode'} eq 'trade_buy')) { require 'trade.cgi' }
				elsif ($F{'mode'} eq 'move') { require 'move.cgi' }
				elsif (($F{'mode'} eq 'bar_trade') || ($F{'mode'} eq 'adven')) { require 'bar.cgi' }
				elsif (($F{'mode'} eq 'rep_ship') || ($F{'mode'} eq 'buy_ship') || ($F{'mode'} eq 'sell_ship')) { require 'yard.cgi' }	
				elsif ($F{'mode'} eq 'battle') { require 'battle.cgi' }
				elsif ($F{'mode'} =~ /city/) { require 'city.cgi' }
				elsif ($F{'mode'} =~ /ctrade/) { require 'ctrade.cgi' }
				elsif ($F{'mode'} =~ /cadmin/) { require 'cadmin.cgi' }
				elsif ($F{'mode'} eq 'cbattle_atk')	{ require 'cbattle.cgi' }
				&{$F{'mode'}}   }
exit;
# ###################################################################

# Sub Ships #
sub ships {
	if ( $#ship_ind < 0 && $money < 2000 ) {
		print qq|<form method=$method action=$seacgi>배를 잃어버리고,<br>자금도 바닥났습니다.<br>처음부터 다시 합니까?<br>\n|;
		print qq|<input type=hidden name=mode value="restart">\n|;
		&id_ps;
		&submit_button;
		print qq|</form>\n|;
		return
	}
	for ($i=0; $i <= 16; $i++){
		if(!$ship[$i][0]){ $ship[$i][0] = $damgif; }
	}
print <<SHIP_TABLE;
<table border=0 cellspacing=0 cellpadding=0 background="$img/$seaimg" cols=5>
<tr>
<td height=40 width=40 align=center valign=center><br></td>
<td height=40 width=40 align=center valign=center><br></td>
<td height=40 width=40 align=center valign=center><img src="$img/$ship[11][0]" alt="$ship[11][4](HP$ship[11][2])"></td>
<td height=40 width=40 align=center valign=center><img src="$img/$ship[15][0]" alt="$ship[15][4](HP$ship[15][2])"></td>
<td height=40 width=40 align=center valign=center><br></td>
</tr>
<tr>
<td height=40 width=40 align=center valign=center><br></td>
<td height=40 width=40 align=center valign=center><img src="$img/$ship[9][0]" alt="$ship[9][4](HP$ship[9][2])"></td>
<td height=40 width=40 align=center valign=center><img src="$img/$ship[3][0]" alt="$ship[3][4](HP$ship[3][2])"></td>
<td height=40 width=40 align=center valign=center><img src="$img/$ship[7][0]" alt="$ship[7][4](HP$ship[7][2])"></td>
<td height=40 width=40 align=center valign=center><img src="$img/$ship[13][0]" alt="$ship[13][4](HP$ship[13][2])"></td>
</tr>
<tr>
<td height=40 width=40 align=center valign=center><img src="$img/$ship[6][0]" alt="$ship[6][4](HP$ship[6][2])"></td>
<td height=40 width=40 align=center valign=center><img src="$img/$ship[2][0]" alt="$ship[2][4](HP$ship[2][2])"></td>
<td height=40 width=40 align=center valign=center><img src="$img/$ship[0][0]" alt="$ship[0][4](HP$ship[0][2])"></td>
<td height=40 width=40 align=center valign=center><img src="$img/$ship[1][0]" alt="$ship[1][4](HP$ship[1][2])"></td>
<td height=40 width=40 align=center valign=center><img src="$img/$ship[5][0]" alt="$ship[5][4](HP$ship[5][2])"></td>
</tr>
<tr>
<td height=40 width=40 align=center valign=center><br></td>
<td height=40 width=40 align=center valign=center><img src="$img/$ship[10][0]" alt="$ship[10][4](HP$ship[10][2])"></td>
<td height=40 width=40 align=center valign=center><img src="$img/$ship[4][0]" alt="$ship[4][4](HP$ship[4][2])"></td>
<td height=40 width=40 align=center valign=center><img src="$img/$ship[8][0]" alt="$ship[8][4](HP$ship[8][2])"></td>
<td height=40 width=40 align=center valign=center><img src="$img/$ship[14][0]" alt="$ship[14][4](HP$ship[14][2])"></td>
</tr>
<tr>
<td height=40 width=40 align=center valign=center><br></td>
<td height=40 width=40 align=center valign=center><br></td>
<td height=40 width=40 align=center valign=center><img src="$img/$ship[12][0]" alt="$ship[12][4](HP$ship[12][2])"></td>
<td height=40 width=40 align=center valign=center><img src="$img/$ship[16][0]" alt="$ship[16][4](HP$ship[16][2])"></td>
<td height=40 width=40 align=center valign=center><br></td>
</tr>
</table>
SHIP_TABLE
}

# Sub Status #
sub status {
	&fleet;
	&load_data;
	$rest = $total - $total_load - $food - $sailor;
	($load_detail =$load) =~ s/△/＆/g;
	($item_detail =$item_line) =~ s/,/＆/g;
	$load_detail .= '<br>';
	$item_detail .= '<br>';
	my $now_price = sprintf "%3.2f" , $p_price*100;
	my $avoid = int($cmd / 3);
	$message .= $record;
	$record = '';
	$message = '<br>' if !$message;
	my $i_up = 1 + $t_item*0.01;
	my $alv = &level($aexp*$i_up);
	my $plv = &level($pexp*$i_up);
	my $tlv = &level($texp*$i_up);
	$on_clickf = qq|onClick="return opWin('$listcgi?mode=player_list','win6')"|;
	$on_clickh = qq|onClick="return opWin('$listcgi?mode=history&id=$id&ps=$F{'ps'}','win6')"|;
	$on_clicke = qq|onClick="return opWin('$listcgi?mode=event_look','win6')"|;
	$on_clickm = qq|onClick="return opWin('$listcgi?mode=mail_form&id=$id&ps=$F{'ps'}','win6')"|;
	$on_clicki = qq|onClick="return opWin('$listcgi?mode=introduce&id=$id&ps=$F{'ps'}','win6')"|;
print <<STATUS_TABLE;
<table border=1 width="100%" bgcolor=$t_bgcol bordercolor=$bdcol cellspacing=0>
<tr>
<td colspan=2 align=center>상태</td>
</tr><tr>
<td width=80 align=center>함대</td><td>$name 함대</td>
</tr><tr>
<td width=80 align=center>적하량</td><td>총:$total 현재:$total_load 남은양:$rest</td>
</tr><tr>
<td width=80 align=center>상세내용</td><td>$load_detail</td>
</tr><tr>
<td width=80 align=center>식료품</td><td>$food</td>
</tr><tr>
<td width=80 align=center>자금</td><td>$money G</td>
</tr><tr>
<td width=80 align=center>선원</td><td>$sailor명</td>
</tr><tr>
<td width=80 align=center>Lv</td><td>모험Lv: $alv 해적Lv: $plv 상인Lv: $tlv</td>
</tr><tr>
<td width=80 align=center>전투력</td><td>$atk</td>
</tr><tr>
<td width=80 align=center>회피율</td><td>$avoid％ (지휘력:$cmd)</td>
</tr><tr>
<td width=80 align=center>속도</td><td>$vector Knot (항해력:$nav)</td>
</tr><tr>
<td width=80 align=center>현재위치</td><td>$p_name(물가:$now_price％)</td>
</tr><tr>
<td width=80 align=center>보물</td><td>$item_detail</td>
</tr><tr>
<td width=80 align=center>명성</td><td>모험:$adven<br>해적:$piracy<br>상인:$trade</td>
</tr><tr>
<td colspan=2 align=center>$message</td>
</tr><tr>
<td colspan=2 align=center>
STATUS_TABLE
	print qq|<a href="$listcgi?mode=player_list" $on_clickf target=_blank>[함대]</a>\n|;
	print qq|<a href="$listcgi?mode=history&id=$id&ps=$F{'ps'}" $on_clickh target=_blank>[기록]</a>\n|;
	print qq|<a href="$listcgi?mode=event_look" $on_clicke target=_blank>[사건]</a>\n|;
	print qq|<a href="$listcgi?mode=mail_form&id=$id&ps=$F{'ps'}" $on_clickm target=_blank>[편지]</a>\n|;
	print qq|<a href="$listcgi?mode=introduce&id=$id&ps=$F{'ps'}" $on_clicki target=_blank>[Profile]</a>\n|;
	print qq|</td></tr></table>\n|;
}

# Sub Play #
sub play {
	&get_me($F{'id'});
	&set_cookie if $F{'mode'} eq 'play';
	&get_host;
	&get_port($area,$port) if $port;
	&get_port($area,$area) if !$port;
	&ship_data;
	$last = time;
	&t_check;
	&sink;
	&header;
	&quest;
	my ($y,$x) = split(/,/,$p_locate);
	$x = int($x * $map_x + $x_rev + 0.5); # 반올림을 위해 0.5 더함
	$y = int($y_rev - $y * $map_y + 0.5);
	print qq|<center><H2><font color=#4169e1>$title</font></H2>\n|;
	print qq|<table width="90%"><tr align=center valign=top><td>\n|;
	print qq|<table width=$map_width><tr><td height=$map_height background="$img/worldmap.gif" align=left valign=top>\n|;
	print qq|<div><span style="position:relative; top:$y; left:$x;">\n|;
	print qq|<img src="$img/pointer.gif"></span></div></td></tr><tr><td>\n|;
	&ships;
	&dis_tactics if $tactics != 4 || $moved < $last;
	print qq|</td></tr></table><td width="40%">\n|;
	&status;
	&move_point if $last > $moved; # $port &&  $port 가 있으면(항구에 있으면) 항구간 이동 표시
	print qq|</td><td width="30%">\n|;
	if($_[0]) {print qq|$_[0]\n<form method=$method action=$seacgi><input type=hidden name="mode" value="play">|; &id_ps; &submit_button; print qq|</form>|;}
	elsif ($point==1 && $last >= $moved )	{ require 'move.cgi'; &move_list }
	elsif ($point==2) { require 'trade.cgi'; &trade_dis('구입',$trade_line); &trade_dis('매각',$load) if $load; }
	elsif ($point==3) { require 'yard.cgi'; &shipyard }
	elsif ($point==4) { require 'bar.cgi'; &bar_meet }
	elsif ($point==5) { require 'city.cgi'; &city_top }
	elsif ($point==6) { require 'battle.cgi'; &enemy }
	elsif ($last < $moved) { &moving }
	print qq|</td></tr></table></center>\n|;
	&home_button;
	&footer;
	&set_me;exit;
}

# Sub Start View #
sub start_view {
	print qq|Set-Cookie: T$cookname=check;\n|;
	&header;
	print qq|<center><H2><font color=#4169e1>$title</font></H2><br>\n|;
	&get_cookie;
	&form_table('up','40',0);
	print qq|<a href="$newcgi">신규등록</a><br><a href="guilds.cgi">길 드</a><br><a href="manual.htm" target=_blank>설명서</a><p>삭제방치기간: $def_dead 일<br></td></tr><tr><td align=center>|;
	$on_click = qq|onClick="return opWin('$listcgi?mode=id_list','win4')"|;
	print qq|ID 【<a href=$listcgi?mode=id_list $on_click target=_blank>ID LIST</a>】<br>\n|;
	print qq|<input type=text name=id class=text size=$stx_wth value="$c_id">\n|;
	print qq|</td></tr><tr><td align=center>\n|;
	print qq|암호<br>\n|;
	print qq|<input type=password name=ps class=text size=$stx_wth value="$c_ps">\n|;
	print qq|</td></tr><tr><td align=right>\n|;
	&submit_button;
	print qq|<input type=hidden name=mode value="play"></center>\n|;
	&form_table('down');
	&ranking;
	&home_button;
	&footer;
}

# Sub Get Port #1인수=$area, 2인수=$port(or $area), 변경필수
sub get_port {
	if ($_[0] =~ /\W/) { &error('부정합니다.') }
	my $AreaFile = new Nfile("$datadir/$_[0]\.dat",'read');
	@arealine = $AreaFile->read;
	($port_line) = grep {($num) = split(/<>/,$_); $num == $_[1];} @arealine;
	if (!$port_line) { &error("항구 데이타를 읽을 수 없습니다."); exit }
	($p_num,$p_name,$p_locate,$trade_line,$p_price) = split(/<>/,$port_line);
}

# Sub Trade Check #
sub trade_check {
	&ship_data;
	&fleet;
	&load_data;
	$rest = $total - $total_load - $food - $sailor;
	if ($F{'quan'} =~ /[^0-9]/) { &play("수치의 입력이 이상합니다.");exit }
	if (!$F{'quan'}) { &play("내용이 입력되지 않았습니다.");exit }
	if ($money < ($price * $F{'quan'}) ) { &play("돈이 부족합니다.");exit }
	if ($rest < $F{'quan'} ) { &play("더이상 짐을 실을 수 없습니다.");exit }
}

# Sub Sell Check #
sub sell_check {
	if ($F{'quan'} =~ /[^0-9]/) { &play("수치의 입력이 이상합니다.");exit }
	if (!$F{'quan'}) { &play("내용이 입력되지 않았습니다.");exit }
}

# Sub Quest #
sub quest {
	if (!$quest_flag) { return }
	my ($qarea,$qport,$qpoint,$guide,$prog,$get) = split(/,/,$quest_line);
	if ( $port == $qport && $area == $qarea && $point == $qpoint ) {
		&msg("$guide");
		&add_record("$guide");
		$prog++;
		my $ConFile = new Nfile("$datadir/$quest_flag",'read');
		@content = $ConFile->read;
		$quest_line = $content[$prog];
		chomp($quest_line);
		undef @content;
		if (!$quest_line) {
			if ($end_quest !~ /$quest_flag/) {
				$adven += $prog * 5000;
				$aexp += $prog * 5000;
				$end_quest .= "$quest_flag,";
				if ($get) {
					my @item_check = split(/,/,$item_line);
					foreach (@item_check) { if ($_ eq $get) { $find = 1; last } }
					if (!$find) {
						$item_line = join(',' , @item_check , $get);
						&add_record("$get(을)를 입수");
						&msg("$get(을)를 입수했습니다.");
					}
				}
			}
			$quest_flag = '';
			return
		}
		my @item_check = split(/,/,$quest_line);
		if ( $#item_check >= 4 ) {
			splice(@item_check , 4 , 0 , $prog);
			$quest_line = join(',' , @item_check);
			return
		}			
		$quest_line .= ",$prog"
	}
}

# Sub Add Record #
sub add_record {
	&get_date(time) if !$date;
	if ($_[1] && $_[0]) {
		$words =  "[$date] $_[0]\n";
		pop (@ulines) if @ulines >= $def_om;
		unshift (@ulines,$words);
	}
	elsif ($_[0]) {
		$words =  "[$date] $_[0]\n";
		pop (@ilines) if @ilines >= $def_om;
		unshift (@ilines,$words);
	}
}

# Sub Message #
sub msg {
	return if !$_[0];
	$message = "" if $message eq '<br>';
	$message .= "<br>" if $message;
	$message .= "$_[0]\n";
}

# Sub Get Date #
sub get_date {
	($sec,$min,$hour,$day,$month,$year) = localtime($_[0]);
	$year += 1900;
	$month++;
	$date   = sprintf("%04d\/%02d\/%02d",$year,$month,$day);
}

# Sub Get Ship Data # $ship[$_][0]=이미지명, [1]=적재량, [2]=HP, [3]=속도, [4]=이름
sub ship_data {
	undef @ship;
	for (0 .. $#ship_ind) {
		@{$ship[$_]} = split(/,/,$ship_ind[$_])
	}
}

# Sub Fleet Status #
sub fleet {
	$total = $vector = 0;
	for(0 .. $#ship){
	  $total += $ship[$_][1];
	  $vector += $ship[$_][3]
	}
	$vector = @ship_ind > 0 ? int( ($vector + ($nav * 0.1)) / @ship_ind ) : 0;
	$vector = ($vector * int((100 + &level($aexp*(1 + $t_item*0.01)))/10))/10;
}

# Sub Total Load #
sub load_data {
	$total_load = 0;
	my @load_ind = split(/△/,$load);
	foreach (@load_ind) {
		($load_name,$load_quan) = split(/,/,$_);
		$total_load += $load_quan;
	}
}

# Sub Moving #
sub moving {
	$take = $moved - time;
	$take = 0 if $take < 0;
	$amount = $take == 0 ? $move_width : 1;
	$delay = ($take * 1000) / $move_width ;
print qq|<center><table width="100%"><tr><td align=center><form method=$method action=$seacgi>★도착|;
print qq|<input type=hidden name=mode value="play">\n|;
&id_ps;
&submit_button;
print <<SHIP_MOVE;
</form></td></tr><tr>
<td background="$img/$seaimg">
<marquee behavior=slide loop="1" height=$move_width direction=up scrollamount=$amount scrolldelay=$delay truespeed>
<center><img src="$img/$move_ship"></center>
</marquee>
</td></tr></table>
<FORM action="./" method="post" name="count">
 남은 시간<INPUT NAME="down" SIZE="10">
<SCRIPT LANGUAGE="JavaScript">
<!---
xx = $take;
function down() {
if (xx < 0)xx = 0;
sec = xx % 60;
min = ((xx - sec) / 60) % 60;
hor = (xx - min * 60 - sec) / 3600;
if (hor < 10)hor = "0" + hor;
if (min < 10)min = "0" + min;
if (sec < 10)sec = "0" + sec;
xx--;
document.count.down.value = hor+":"+min+":"+sec;
setTimeout('down()', 1000);
}
down();
//end --->
</SCRIPT>
</FORM>
</center>
SHIP_MOVE
}

# Sub Sink #
sub sink {
	if (!$port && $#ship_ind < 0) {
		&set_cookie('del');
		&header;
		print qq|<center><font size=5 color=#4169e1>$title</font><br><br><br>\n|;
		print qq|<font size=6 color=#FF0000>\n|;
		print qq|게임오버!<br>당신은 해상에서 전멸하고,<br>바다의 귀신이 되었습니다...\n|;
		print qq|</font></center>\n|;
		&home_button;
		&footer;
		unlink("$usrdir/$id\.dat");
		exit
	}
}

# Sub Submit Button #
sub submit_button {
	print qq|<input type=submit value="$sub_lbl" class=button>\n|;
}

# Sub Display Tactics #
sub dis_tactics {
	my(@t_type)=('열혈','보통','조심');
	&form_table('up','100%',1);
	print qq|전술|;
	&id_ps;
	&submit_button;
	&reload;
	print qq|</td></tr><tr><td align=center valign=center>\n|;
	for($i=0;$i<3;$i++) {
		$checked = $i == $tactics  ? ' checked' : '';
		print qq|<input type=radio name=tactics value="$i"$checked>$t_type[$i] \n|;
	}
	if ($#ship_ind <= 1) {
		$checked = $tactics == 3  ? ' checked' : '';
		print qq|<br><input type=radio name=tactics value="3"$checked>항복(모든 명성 0)\n|;
	}
	if ($port && $moved < $last) {
		$checked = $tactics == 4  ? ' checked' : '';
		print qq|<br><input type=radio name=tactics value="4"$checked>계류($stop시간)\n|;
	}
	print qq|<input type=hidden name=mode value="ch_tac">\n|;
	&form_table('down');
}

# Sub Change Tactics #
sub ch_tac {
	&get_me($F{'id'});
	if ($action ne $F{'reload'}) { &play; exit }
	$tactics = $F{'tactics'};
	if ($tactics == 4) { $moved = time + ($stop * 3600); $point = 1 }
	$action = '';
	&play;
}

# Sub Tactics Check #
sub t_check {
	if (($tactics == 3 && $#ship_ind > 1) || ($tactics == 4 && $moved < $last)) { $tactics = 1 }
	if ($tactics == 3) {
		$piracy = 0 if $piracy > 0;
		$adven = 0 if $adven > 0;
		$trade = 0 if $trade > 0;
	}
}

# Sub Move Point #
sub move_point {
	my(@in_port)=('항구','교역소','조선소','술집','도시','습격'); # $point 해상=0,항구=1,교역=2,조선=3,술집=4,도시=5,습격=6
	print qq|<br>\n|;
	&form_table('up','100%',1);
	print qq|항내이동 | if $port;
	print qq|행동 | if !$port;
	&submit_button;
	print qq|</td></tr><tr><td align=center>\n|;
	for($i=1;$i<7;$i++) {
		$checked = $i == $point  ? ' checked' : '';
		print qq|<input type=radio name=point value="$i"$checked>$in_port[$i-1] \n|;
		$i += 4 if !$port;
	}
	&id_ps;
	print qq|<input type=hidden name=mode value="ch_point">\n|;
	&form_table('down');
}

# Sub Change Point #
sub ch_point {
	&get_me($F{'id'});
	if (time < $moved) { &play; return }
	$point = $F{'point'};
	&msg("$ms[$F{'point'}]");
	&play;
}

# Sub Restart #
sub restart {
	require 'rank.cgi';
	&get_me($F{'id'},'read');
	unlink("$usrdir\/$id\.dat");
	&set_cookie('del');
	&start_view;
	exit;
}

# Sub Table #1=상or하, 2=폭, 3=경계
sub form_table {
if($_[0] eq 'up') {
print <<TAB;
	<center><form method=$method action=$seacgi>
	<table width="$_[1]" border="$_[2]" bgcolor=$t_bgcol bordercolor=$bdcol cellspacing=0>
	<tr><td align=center>
TAB
}
if($_[0] eq 'down') {
print <<TAB;
	</td></tr>
	</table></form>
	</center>
TAB
}
}

# Sub Return Button #
sub return_button {
	print qq|<center><form method=$method action=$seacgi><input type="button" value="뒤로" onClick="history.back()"></form></center>\n|;
}

# Sub Home Button #
sub home_button {
	if (!$def_ho) { return }
	print qq|<center><a href=$hom_url target=$hom_tgt>$hom_lbl</a><br></center>\n|;
}

# Sub ID & Password #
sub id_ps {
	print qq|<input type=hidden name=id value="$F{'id'}">\n|;
	print qq|<input type=hidden name=ps value="$F{'ps'}">\n|;
}

# Sub Reload #
sub reload {
	$action = rand(1000) if !$reloadflag;
	print qq|<input type=hidden name=reload value="$action">\n|;
	$reloadflag = 1;
}

# Sub Level #
sub level {
	return int(5.9 * log($_[0] + 4792) - 50)
}

# Sub Error #
sub error {
	&unlock if $locked;
	if (!$headflag) { &header }
print <<ERR;
<center>
<hr width=80%>
<B><font color=#FF0000>$_[0]</font></B>
<hr width=80%>
</center>
ERR
	&return_button if !$def_rb;
	&footer('no');
	exit;
}

# Sub Get Cookie #
sub get_cookie { 
	@pairs = split(/\;/,$ENV{'HTTP_COOKIE'});
	foreach $pair (@pairs) {
		my($name, $value) = split(/\=/, $pair);
		$name =~ s/ //g;
		$DUMMY{$name} = $value;
	}
	@pairs = split(/\,/,$DUMMY{$cookname});
	foreach $pair (@pairs) {
		my($name, $value) = split(/\:/, $pair);
		$COOKIE{$name} = $value;
	}
	$c_id = $COOKIE{'id'};
	$c_ps = $COOKIE{'ps'}
}

# Sub Set Cookie #
sub set_cookie {
	# 90일간 유효함
	($secg,$ming,$hourg,$mdayg,$mong,$yearg,$wdayg,$ydayg,$isdstg) = gmtime(time + $def_dead*24*60*60);
	($secg,$ming,$hourg,$mdayg,$mong,$yearg,$wdayg,$ydayg,$isdstg) = gmtime(time + $retry*60*60) if $_[0] eq 'del';
	$yearg += 1900;
	if ($secg  < 10) { $secg  = "0$secg";  }
	if ($ming  < 10) { $ming  = "0$ming";  }
	if ($hourg < 10) { $hourg = "0$hourg"; }
	if ($mdayg < 10) { $mdayg = "0$mdayg"; }
	$month = ('Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec')[$mong];
	$youbi = ('Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday')[$wdayg];
	$date_gmt = "$youbi, $mdayg\-$month\-$yearg $hourg:$ming:$secg GMT";
	$cook = "id\:$F{'id'}\,ps\:$F{'ps'}";
	print "Set-Cookie: $cookname=$cook; expires=$date_gmt\n";
}

# Sub Decode #
sub decode {
	if ($ENV{'REQUEST_METHOD'} eq "POST") {
		read(STDIN, $buffer, $ENV{'CONTENT_LENGTH'});
		@pairs = split(/&/, $buffer);
	} else {
		@pairs = split(/&/, $ENV{'QUERY_STRING'});
		if($#pairs >= 0 && $method eq 'POST') { &error("부정한 에러입니다."); }
	}

	foreach $pair (@pairs) {
		($name, $value) = split(/=/, $pair);
		$name =~ tr/+/ /;
		$name =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
		$value =~ tr/+/ /;
		$value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;

		$value =~ s/</&lt;/g;
		$value =~ s/>/&gt;/g;
		$value =~ s/\,/□/g;
		$value =~ s/\r\n/<br>/g;
		$value =~ s/\r/<br>/g;
		$value =~ s/\n/<br>/g;

		$F{$name} = $value;
	}
}

# Sub Get Host #
sub get_host {
	$host = $ENV{'REMOTE_HOST'};
	$ad = $ENV{'REMOTE_ADDR'};
	if ($get_remotehost) {
		if ($host eq "" || $host eq "$ad") {
			$host = gethostbyaddr(pack("C4",split(/\./,$ad)),2);
		}
	}
	if ($host eq "") { $host = $ad }
}
