#!/usr/bin/perl

$ver = "v1.06";
#| 슬라임 브리더 Version 1.06(2000/02/17)
#| by tatuta(1999/6/29β-1999/11/22v1.00)
#| tatuta@geocities.co.jp
#| HomePageUrl http://www2j.biglobe.ne.jp/~tatuta/_MENU.htm

# ----------------------------------------------------------
# 각종 설정
# ----------------------------------------------------------

$backurl   = '../';					# 복귀 페이지 URL
$backtitle = '홈으로';# 복귀 페이지 제목

$comtmax = 50;	# 댓글 파일 최대 보관 수
$rankmax = 60;	# 랭킹 최대 보관 수
$dendo   = 3;		# 명예의 전당 입성 방어 횟수

$ps_god = 'gene';		# 유전자 해석용 비밀번호
$ps_usr = 'user';		# 사용자 파일 열람용 비밀번호
$ps_mna = 'sys';	# 시스템 해설 페이지용 비밀번호
# 관리자 영역에 비밀번호를 입력해 사용합니다.

$cginame     = './slm.cgi';				# 이 CGI 파일 이름
$userfile    = './slmuser.cgi';		# 사용자 관리
$rankfile    = './slmrank.cgi';		# 랭킹
$kingfile    = './slmking.cgi';		# 명예의 전당
$comtfile    = './slmcomt.cgi';		# 댓글 파일
$usertmp     = './slmuser.tmp';		# 사용자 tmp 파일
$ranktmp     = './slmrank.tmp';		# 랭킹 tmp 파일
$kingtmp     = './slmking.tmp';		# 명예의 전당 tmp 파일
$comttmp     = './slmcomt.tmp';		# 댓글 tmp 파일
$userloc     = './slmuser.loc';		# 사용자 잠금 파일
$rankloc     = './slmrank.loc';		# 랭킹 잠금 파일
$kingloc     = './slmking.loc';		# 명예의 전당 잠금 파일
$comtloc     = './slmcomt.loc';		# 댓글 잠금 파일

$bg_gif       = './slmbg.gif';		# 배경 GIF
$char_normal  = "./slmnormal.gif";
$char_aura    = "./slmaura.gif";
$char_hider   = "./slmhider.gif";
$char_wing    = "./slmwing.gif";
$char_ribbon  = "./slmribbon.gif";
$char_ribbonw = "./slmribbonw.gif";
$char_crown   = "./slmcrown.gif";
$char_crownw  = "./slmcrownw.gif";
$char_angel   = "./slmangel.gif";
$char_devil   = "./slmdevil.gif";
$char_aho     = "./slmaho.gif";
$char_oyaji   = "./slmoyaji.gif";
$char_musi    = "./slmmusi.gif";
$char_zombie  = "./slmzombie.gif";

# ----------------------------------------------------------
# 초기 전역 변수
# ----------------------------------------------------------

$seed_gage = $rankmax * 10;	# 씨앗 생성 속도
$henka = 50;	# 돌연변이 확률 1/$henka

$eve =<<"_EOF_";
0<p><p>이브<p><p>태초의 신<p><p>#ffffff<p>$char_normal<p><p>48<>60<s>51<>58<s>32<>51<s>40<>48<s>54<>49<s>45<>37<s>62<>41<s>1<s>1<s>1<s>1<s>1<s>1<s>1<s>1<s>1<m>45<>40<s>60<>41<s>63<>52<s>50<>49<s>48<>39<s>63<>63<s>61<>42<s>1<s>1<s>1<s>1<s>1<s>1<s>1<s>1<s>1<p><>태초의 신<><s><>태초의 신<><s><><><s><><><s><><><s><><><s><><><s><><><s><><><s><><><s><><><s><><><s><><><s><><><p><p><p>d
_EOF_

$adam =<<"_EOF_";
1<p>0<p>아담<p><p>태초의 신<p><p>#000000<p>./slmnormal.gif<p><p>43<>63<s>64<>29<s>63<>47<s>54<>53<s>36<>62<s>41<>61<s>47<>44<s>0<s>0<s>0<s>0<s>0<s>0<s>0<s>0<s>0<m>52<>50<s>53<>42<s>52<>55<s>47<>62<s>50<>65<s>47<>60<s>49<>61<s>0<s>0<s>0<s>0<s>0<s>0<s>0<s>0<s>0<p><>태초의 신<><s><>태초의 신<><s><><><s><><><s><><><s><><><s><><><s><><><s><><><s><><><s><><><s><><><s><><><s><><><p>10<p>0<p>0<>0<p>0<p>d
_EOF_

# ----------------------------------------------------------
# 초기 설정(수정 불필요)
# ----------------------------------------------------------

&check_code;
&read_form;
srand (time ^ ($$ + ($$ << 15)));
@rank = &read ($rankfile);
unless (@rank) {
	$cain = &create_char ($eve,$adam);
	($u_no,$u1,$u_name,$u3,$u4,$u5,$u6,$u7,$u_status,$u9,$ua,$ub,$check,$ud) = split(/<p>/,$cain);
	$cain = "2<p>1<p>카인<p>$u3<p>이브<p>$u5<p>$u6<p>$u7<p>$u_status<p>$u9<p>$ua<p>10<p>0<p>1<>0<p>0<p>1위\n";

	$abel = &create_char ($eve,$adam);
	($u_no,$u1,$u_name,$u3,$u4,$u5,$u6,$u7,$u_status,$u9,$ua,$ub,$check,$ud) = split(/<p>/,$abel);
	$abel = "1<p>2<p>아벨<p>$u3<p>이브<p>$u5<p>$u6<p>$u7<p>$u_status<p>$u9<p>$ua<p>10<p>0<p>0<>1<p>0<p>2위\n";

	push (@rank,$cain);
	push (@rank,$abel);
	&save ($rankfile,$ranktmp,$rankloc,@rank);
}
&wgt_set;

# ----------------------------------------------------------
# HTML
# ----------------------------------------------------------

$html_head=<<"_EOF_";
Content-type: text/html; charset=UTF-8

<HTML>
<HEAD>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
<TITLE>슬라임 브리더</TITLE>
</HEAD>
<BODY BGCOLOR="#000000" TEXT="#eeeeee" LINK="#00FFFF" VLINK="#7FFFFF">
<BASEFONT SIZE=3 FACE="Arial, sans-serif">
_EOF_

$html_foot=<<"_EOF_";
<HR>
<!-- 저작권표시 (생략 금지, 반드시 표시할 것) -->
<DIV ALIGN="right">
<FONT color="#7f7fff" FACE="Times New Roman"><i><B>SLIME BREEDER</B> $ver </FONT>Copyright &copy;1999 <A HREF="http://www2j.biglobe.ne.jp/~tatuta/_MENU.htm">tatuta.</A></i><BR>
</DIV>

</BODY></HTML>
_EOF_

# ----------------------------------------------------------
# 메인
# ----------------------------------------------------------

if ($FORM{'mode'} eq 'title') { &title_print; exit; }
if ($FORM{'mode'} eq 'rank') { &rank_print; exit; }
if ($FORM{'mode'} eq 'enter') { &enter_print; exit; }
if ($FORM{'mode'} eq 'create') { &create; exit; }
if ($FORM{'mode'} eq 'fight') { &fight; exit; }
if ($FORM{'mode'} eq 'com') { &add_comt; &title_print; exit; }
if ($FORM{'mode'} eq 'king') { &king_print; exit; }
if ($FORM{'mode'} eq 'god') {
	if ($FORM{'pass'} eq $ps_god) { &rank_print; exit; }
	if ($FORM{'pass'} eq $ps_usr) { &userfile; exit; }
	if ($FORM{'pass'} eq $ps_mna) { &mania; exit; }
	&king_print; exit;
}
if ($FORM{'mode'} eq 'guide') { &guide; exit; }
if ($FORM{'mode'} eq 'mania') { &mania; exit; }
&frame_set;
exit;

# ----------------------------------------------------------
# 프레임
# ----------------------------------------------------------

sub frame_set{
	print "Content-type: text/html; charset=UTF-8\n\n";
	print <<"_EOF_";
<HTML>
<HEAD>
<TITLE>슬라임 브리더</TITLE>
</HEAD>

<FRAMESET ROWS="240,*">
	<FRAME SRC="$cginame?mode=title" NAME="top">
	<FRAME SRC="$cginame?mode=rank" NAME="bottom">
</FRAMESET>

<NOFRAMES>
<BODY BGCOLOR="#003f3f" TEXT="#eeeeee" LINK="#00FFFF" VLINK="#7FFFFF">
<CENTER>
<font size=5>프레임을 지원하지 않는 브라우저에서는 사용할 수 없습니다 m(__)m </font>
</BODY>
</NOFRAMES>
</HTML>
_EOF_
}

# ----------------------------------------------------------
# 평균 체중 결정
# ----------------------------------------------------------

sub wgt_set {
	$wgt_sum = 0;
	foreach $line (@rank) {
		$status = (split(/<p>/,$line))[8];
		$wgt_sum += (split (/<>/,$status))[0];
	}
	$wgt_ave = int ($wgt_sum / @rank);
	$disp_cut = length($wgt_ave) - 2;
	$tumble = 8;
	$range = int ($wgt_ave / 30) + 2;
}

# ----------------------------------------------------------
# 타이틀 화면
# ----------------------------------------------------------

sub title_print {
	&get_cookie;
	if ($c_name eq '') {
		$comtname = "<INPUT type=\"text\" name=\"user\" size=16 value=\"이름\">";
	} else {
		$comtname = "$c_name<INPUT TYPE=\"hidden\" NAME=\"user\" VALUE=\"$c_name\">";
	}
	print $html_head;
	print<<"_EOF_";
<FORM ACTION="$cginame" METHOD=post>
<A HREF="$backurl" target="_top">$backtitle</A>／<A HREF="$cginame?mode=guide" target="bottom">안내서</A>／<A HREF="$cginame?mode=rank" target="bottom">랭킹</A>／<A HREF="$cginame?mode=king" target="bottom">명예의 전당</A>／<A HREF="$cginame?mode=title">새로고침</A><BR>
<TABLE BORDER=0 width="100%" background="$bg_gif">
<TR><TD>
<CENTER>
<FONT size=7 color="#7f7fff" FACE="Times New Roman"><i>SLIME BREEDER</i></FONT><BR>
<FONT SIZE=2 color="red"><i>슬라임 브리더</i></FONT><BR>
<BR>
<INPUT TYPE="hidden" NAME="mode" VALUE="enter">
사용자명<INPUT type="text" name="user" size=16 value="$c_name">
 비밀번호<input type="password" name="pass" size=8 maxlength=8 value="$c_pwd">
<INPUT TYPE="submit" VALUE="Enter">
</CENTER>
</FORM>
<FORM ACTION="$cginame" METHOD=post>
<small>
처음 이용하는 분은 여기에 입력한 정보로 등록됩니다. 중요한 비밀번호는 사용하지 마세요.<BR>
</small>
</TD></TR>
</TABLE>
<HR>
<INPUT TYPE="hidden" NAME="mode" VALUE="com">
한마디 댓글：$comtname<INPUT type="text" name="comt" size=60>
<INPUT TYPE="submit" VALUE="등록">(150자 이내)
<HR>
_EOF_

	@comt = &read ($comtfile);
	foreach $line (@comt) {
		($date,$name,$comt,$dmy) = split(/<>/,$line);

$comt_date = "<FONT COLOR=\"#ffb0ff\">$date</FONT>";				# 날짜
$comt_name = "<FONT COLOR=\"#b0ffff\"><B>$name</B></FONT>";	# 이름
$comt_text = "<B>「$comt」</B>";														# 본문

		print "$comt_date $comt_name$comt_text<HR>\n";
	}	
	print<<"_EOF_";
</FORM>
<FORM ACTION="$cginame" METHOD="post" target="bottom">
<DIV align="right">
<INPUT TYPE="hidden" NAME="mode" VALUE="god">
관리자 영역<INPUT TYPE="password" NAME="pass" SIZE=8>
<INPUT TYPE="submit" VALUE="열기">
</DIV>
</FORM>

_EOF_
	print $html_foot;
}

sub add_comt {
	@comt = &read ($comtfile,$comtloc);
	$date = &date(time);
	$name = $FORM{'user'};
	$comt = $FORM{'comt'};
	$ipad = $ENV{'REMOTE_ADDR'};
	$checktext = (split(/<>/,$comt[0]))[2];
	$checkname = (split(/<>/,$comt[0]))[1];

	if ($comt eq '') {
		&error(1,'내용을 입력해 주세요.');
	}
	if ($comt eq $checktext && $name eq $checkname) {
		&error(1,'중복 등록입니다.');
	}
	if (length($comt) > 300) { $comt = substr($comt,0,300); }
	if (length($name) > 16) { $name = substr($name,0,16); }

	$i = 0;
	@new = '';
	unshift(@comt,"$date<>$name<>$comt<>$ipad\n");
	foreach $line (@comt) {
		if ($i < $comtmax) { push(@new,$line); }
		$i++;
	}
	&save ($comtfile,$comttmp,$comtloc,@new);
}

# ----------------------------------------------------------
# 랭킹 화면
# ----------------------------------------------------------

sub rank_print {
	print $html_head;
	print "<FONT SIZE=5 COLOR=yellow>랭킹</FONT><BR><BR>\n";

	$rank = 1;
	foreach $line (@rank) {
		$pts = (split(/<p>/,$line))[0];
		$no = (split(/<p>/,$line))[1];
		$name = (split(/<p>/,$line))[2];
		$sedai = (split(/<p>/,$line))[3];
		$color = (split(/<p>/,$line))[6];
		$seed = (split(/<p>/,$line))[11];
		if ($seed != 0) { $seed = "<FONT COLOR=\"yellow\">$seed</FONT>"; }
		$child = (split(/<p>/,$line))[12];
		$result = (split(/<p>/,$line))[13];
		$highrank = (split(/<p>/,$line))[15];
		($win,$lose) = split(/<>/,$result);
		print "<a name=\"$no\"></A>\n";
		print "<big><B>제$rank위 <FONT COLOR=\"\#ffb0ff\">$name</B></FONT><sub>$sedai</sub></big> 씨앗$seed개 자식$child마리 $win승$lose패 최고$highrank$pts<small>pts.</small><BR>\n";
		if ($FORM{'mode'} eq 'god') {
			$print = &god_print ($line);
		} else { $print = &status_print ($line); }
		print $print;
		print "<HR>\n\n";
		$rank++;
	}

	print<<"_EOF_";
<CENTER>
[<A HREF="$backurl" target="_top">$backtitle</A>][<A HREF="$cginame?mode=title" target="top">제목</A>][<A HREF="$cginame?mode=rank">새로고침</A>]<BR>
</CENTER>
_EOF_

	print $html_foot;
}

sub status_print {
	local ($data) = $_[0];
	$name = (split (/<p>/,$data))[2];
	$sedai = (split (/<p>/,$data))[3];
	$owner = (split (/<p>/,$data))[4];
	$time = (split (/<p>/,$data))[5];
	$birth = &date ($time);
	$color = (split (/<p>/,$data))[6];
	$gif = (split (/<p>/,$data))[7];
	$status = (split (/<p>/,$data))[8];
	@status = split (/<>/,$status);

	$i = 0;
	$yuko = 4 - (length ($status[0]) - $disp_cut);
	foreach $line (@status) {
		$statusp[$i] = int ($status[$i] / (10 ** $disp_cut) + 0.5);
		if ($FORM{'mode'} eq 'king' && (length ($status[0]) - $disp_cut) < 1) {
			$statusp[$i] = $status[$i] / (10 ** $disp_cut);
			$statusp[$i] = substr ($statusp[$i],0,$yuko);
		}
		$i++;
	}
# 0=WGT 1=HP 2=STM 3=STR 4=DEX 5=SPD 6=CST 7=SEX 
	$blood = (split (/<p>/,$data))[10];
	@blood = split (/<s>/,$blood);
# 0=자신의 부모 1=상대 부모 2=자신의 부모부모 345=상대 부모부모 6=자신의 부모부모부모 7-13=상대 부모부모부모 
	for ($i = 0; $i < 14; $i++) {
		($b_no[$i],$b_name1[$i],$b_sedai[$i]) = split (/<>/,$blood[$i]);
		$b_name[$i] = "<FONT COLOR=\"#00ffff\">$b_name1[$i]</FONT>";
		if ($FORM{'mode'} eq 'rank') {
			$b_name[$i] = "<A href=\"\#$b_no[$i]\">$b_name1[$i]</A>";
		}
		if ($FORM{'mode'} eq 'create' || $FORM{'mode'} eq 'enter') {
			$b_name[$i] = "<A href=\"$cginame?mode=rank\#$b_no[$i]\" target=\"bottom\">$b_name1[$i]</A>";
		}
	}
	$gif_size = int (($status[0] / $wgt_ave * .55 + .5) * 110);

$html_status=<<"_EOF_";
<TABLE BORDER=1 BGCOLOR="#003f3f" bordercolordark="lightblue">
<TR><TD align="center" valign="middle">
	<TABLE BORDER=0 bgcolor="$color" cellpadding=0 cellspacing=0>
	<TR><TD><IMG SRC="$gif" width=$gif_size height=$gif_size></TD></TR>
	</TABLE>
	<FONT SIZE=2>weight:$status[0]</FONT><BR>
	</TD>
	<TD background="$bg_gif">
	<TABLE BORDER=1>
	<TR><TH>제$sedai대: $birth 출생</TH><TH>HP</TH><TH>STM</TH><TH>STR</TH><TH>DEX</TH><TH>SPD</TH></TR>
	<TR><TH>오너：$owner</TH><TH>$statusp[1]</TH><TH>$statusp[2]</TH><TH>$statusp[3]</TH><TH>$statusp[4]</TH><TH>$statusp[5]</TH></TR>
	</TABLE>
	<TABLE BORDER=1>
	<TR><TD valign="middle">
		$b_name[0]<FONT COLOR="yellow"><sub>$b_sedai[0]</sub></FONT><BR>
		<HR>
		$b_name[1]<sub>$b_sedai[1]</sub><BR>
		</TD>
	<TD valign="middle">
		<FONT SIZE=2>$b_name[2] <FONT COLOR="yellow">$b_sedai[2]</FONT></FONT><BR>
		<FONT SIZE=2>$b_name[3] $b_sedai[3]</FONT><BR>
		<HR>
		<FONT SIZE=2>$b_name[4] $b_sedai[4]</FONT><BR>
		<FONT SIZE=2>$b_name[5] $b_sedai[5]</FONT><BR>
		</TD>
	<TD valign="top">
		<FONT SIZE=2>$b_name[6] <FONT COLOR="yellow">$b_sedai[6]</FONT></FONT><BR>
		<FONT SIZE=2>$b_name[7] $b_sedai[7]</FONT><BR>
		<FONT SIZE=2>$b_name[8] $b_sedai[8]</FONT><BR>
		<FONT SIZE=2>$b_name[9] $b_sedai[9]</FONT><BR>
		</TD>
	<TD valign="bottom">
		<FONT SIZE=2>$b_name[10] $b_sedai[10]</FONT><BR>
		<FONT SIZE=2>$b_name[11] $b_sedai[11]</FONT><BR>
		<FONT SIZE=2>$b_name[12] $b_sedai[12]</FONT><BR>
		<FONT SIZE=2>$b_name[13] $b_sedai[13]</FONT><BR>
		</TD>
	</TR>
	</TABLE>
	</TD>
</TR>
</TABLE>

_EOF_
	return $html_status;
}

# 명예의 전당

sub king_print {
	@king = &read ($kingfile);
	$bg_gif = './slmbg2.gif';
	print $html_head;
	print "<FONT SIZE=6 color=\"#7f7fff\" FACE=\"serif\">명예의 전당</FONT><BR><BR>\n";
	foreach $line (@king) {
		$no = (split(/<p>/,$line))[1];
		$name = (split(/<p>/,$line))[2];
		$sedai = (split(/<p>/,$line))[3];
		$color = (split(/<p>/,$line))[6];
		$child = (split(/<p>/,$line))[12];
		$result = (split(/<p>/,$line))[13];
		($win,$lose) = split(/<>/,$result);
		$lose--;
		$highrank = (split(/<p>/,$line))[15];
		($v5_rank,$v5_defend) = split(/<sup>/,$highrank);
		($defend,$dmy) = split(/</,$v5_defend);
		unless ($defend) { $defend = 0; }
		print "<big><B><FONT COLOR=\"\#dfcf3f\">$name</B><sub>$sedai</sub></big> $win승$lose패 방어$defend회 자식$child마리 제$no자식</FONT><BR>\n";
		$print = &status_print ($line);
		print $print;
		print "<HR>\n\n";
	}

	print<<"_EOF_";
<CENTER>
[<A HREF="$backurl" target="_top">$backtitle</A>][<A HREF="$cginame?mode=rank">랭킹</A>]<BR>
</CENTER>
_EOF_

	print $html_foot;
}

# 유전자해석

sub god_print {
	local ($data) = $_[0];
	$name = (split (/<p>/,$data))[2];
	$sedai = (split (/<p>/,$data))[3];
	$owner = (split (/<p>/,$data))[4];
	$time = (split (/<p>/,$data))[5];
	$birth = &date ($time);
	$color = (split (/<p>/,$data))[6];
	$gif = (split (/<p>/,$data))[7];
	$status = (split (/<p>/,$data))[8];
	@status = split (/<>/,$status);
# 0=WGT 1=HP 2=STM 3=STR 4=DEX 5=SPD 6=CST 7=SEX 
	$dna = (split (/<p>/,$data))[9];
	@dna = split (/<m>/,$dna);
	for ($i = 0; $i < 2; $i++) {
		($hrd[$i],$sft[$i],$brn[$i],$net[$i],$fat[$i],$men[$i],$sex[$i],$r[$i],$g[$i],$b[$i],$x[$i],$y[$i],$z[$i],$u[$i],$v[$i],$w[$i])  = split (/<s>/,$dna[$i]);
	}
	$blood = (split (/<p>/,$data))[10];
	@blood = split (/<s>/,$blood);
# 0=자신의 부모 1=상대 부모 2=자신의 부모부모 345=상대 부모부모 6=자신의 부모부모부모 7-13=상대 부모부모부모 
	for ($i = 0; $i < 14; $i++) {
		($b_no[$i],$b_name1[$i],$b_sedai[$i]) = split (/<>/,$blood[$i]);
		$b_name[$i] = "<A href=\"\#$b_no[$i]\">$b_name1[$i]</A>";
	}
	$gif_size = int (($status[0] / $wgt_ave * .55 + .5) * 110);

$html_status=<<"_EOF_";
<TABLE BORDER=1 BGCOLOR="#003f3f" bordercolordark="lightblue">
<TR><TD align="center" valign="middle">
	<TABLE BORDER=0 bgcolor="$color" cellpadding=0 cellspacing=0>
	<TR><TD><IMG SRC="$gif" width=$gif_size height=$gif_size></TD></TR>
	</TABLE>
	<FONT SIZE=2>$color</FONT><BR>
	<FONT SIZE=2>weight:$status[0]</FONT><BR>
	<TABLE BORDER=1 BGCOLOR="#000000">
	<TR><TH>X</TH><TH>Y</TH><TH>Z</TH><TH>RBN</TH><TH>CRW</TH><TH>WNG</TH></TR>
	<TR><TH>$x[0]</TH><TH>$y[0]</TH><TH>$z[0]</TH><TH>$u[0]</TH><TH>$v[0]</TH><TH>$w[0]</TH></TR>
	<TR><TH>$x[1]</TH><TH>$y[1]</TH><TH>$z[1]</TH><TH>$u[1]</TH><TH>$v[1]</TH><TH>$w[1]</TH></TR>
	</TABLE>
	</TD>
	<TD BGCOLOR="#000000">
	<TABLE BORDER=1>
	<TR><TH>제$sedai대: $birth 출생</TH><TH>HP</TH><TH>STM</TH><TH>STR</TH><TH>DEX</TH><TH>SPD</TH><TH>CST</TH><TH>SEX</TH></TR>
	<TR><TH>오너：$owner</TH><TH>$status[1]</TH><TH>$status[2]</TH><TH>$status[3]</TH><TH>$status[4]</TH><TH>$status[5]</TH><TH>$status[6]</TH><TH>$status[7]</TH></TR>
	</TABLE>
	<TABLE BORDER=1>
	<TR><TH>HRD</TH><TH>SFT</TH><TH>BRN</TH><TH>NET</TH><TH>FAT</TH><TH>MEN</TH><TH>SEX</TH></TR>
	<TR><TH>$hrd[0]</TH><TH>$sft[0]</TH><TH>$brn[0]</TH><TH>$net[0]</TH><TH>$fat[0]</TH><TH>$men[0]</TH><TH>$sex[0]</TH></TR>
	<TR><TH>$hrd[1]</TH><TH>$sft[1]</TH><TH>$brn[1]</TH><TH>$net[1]</TH><TH>$fat[1]</TH><TH>$men[1]</TH><TH>$sex[1]</TH></TR>
	</TABLE>
	<TABLE BORDER=1>
	<TR><TD valign="middle">
		$b_name[0]<FONT COLOR="yellow"><sub>$b_sedai[0]</sub></FONT><BR>
		<HR>
		$b_name[1]<sub>$b_sedai[1]</sub><BR>
		</TD>
	<TD valign="middle">
		<FONT SIZE=2>$b_name[2] <FONT COLOR="yellow">$b_sedai[2]</FONT></FONT><BR>
		<FONT SIZE=2>$b_name[3] $b_sedai[3]</FONT><BR>
		<HR>
		<FONT SIZE=2>$b_name[4] $b_sedai[4]</FONT><BR>
		<FONT SIZE=2>$b_name[5] $b_sedai[5]</FONT><BR>
		</TD>
	<TD valign="top">
		<FONT SIZE=2>$b_name[6] <FONT COLOR="yellow">$b_sedai[6]</FONT></FONT><BR>
		<FONT SIZE=2>$b_name[7] $b_sedai[7]</FONT><BR>
		<FONT SIZE=2>$b_name[8] $b_sedai[8]</FONT><BR>
		<FONT SIZE=2>$b_name[9] $b_sedai[9]</FONT><BR>
		</TD>
	<TD valign="bottom">
		<FONT SIZE=2>$b_name[10] $b_sedai[10]</FONT><BR>
		<FONT SIZE=2>$b_name[11] $b_sedai[11]</FONT><BR>
		<FONT SIZE=2>$b_name[12] $b_sedai[12]</FONT><BR>
		<FONT SIZE=2>$b_name[13] $b_sedai[13]</FONT><BR>
		</TD>
	</TR>
	</TABLE>
	</TD>
</TR>
</TABLE>

_EOF_
	return $html_status;
}

# 사용자 파일

sub userfile {
	@user = &read ($userfile);
	$usersuu = @user;
	$rnd_range = ($tumble * $range - $tumble) / 2;
	print $html_head;
	print "<B>사용자 파일</B><BR>\n";
	print "사용자 수: $usersuu 평균 체중: $wgt_ave 주사위: $range면체 $tumble개 ±$rnd_range<BR><BR>\n";
	foreach $line (@user) {
		$no = (split(/<p>/,$line))[0];
		$ip = (split(/<p>/,$line))[1];
		$name = (split(/<p>/,$line))[2];
		$sedai = (split(/<p>/,$line))[3];
		$owner = (split (/<p>/,$line))[4];
		$time = (split (/<p>/,$line))[5];
		$birth = &date ($time);
		$color = (split(/<p>/,$line))[6];
		$gif = (split (/<p>/,$line))[7];
		$status = (split (/<p>/,$line))[8];
		@status = split (/<>/,$status);
		$i = 0;
		foreach $line (@status) {
			$statusp[$i] = int ($status[$i] / (10 ** $disp_cut) + 0.5);
			$i++;
		}
# 0=WGT 1=HP 2=STM 3=STR 4=DEX 5=SPD 6=CST 7=SEX 
	$blood = (split (/<p>/,$line))[10];
	@blood = split (/<s>/,$blood);
# 0=자신의 부모 1=상대 부모 2=자신의 부모부모 345=상대 부모부모 6=자신의 부모부모부모 7-13=상대 부모부모부모 
	for ($i = 0; $i < 2; $i++) {
		($b_no[$i],$b_name1[$i],$b_sedai[$i]) = split (/<>/,$blood[$i]);
		$b_name[$i] = "$b_name1[$i] $b_sedai[$i]";
	}
	print<<"_EOF_";
<TABLE BORDER=1 BGCOLOR="#003f3f" bordercolordark="lightblue">
<TR><TD align="center" valign="middle">
	<TABLE BORDER=0 bgcolor="$color" cellpadding=0 cellspacing=0>
	<TR><TD><IMG SRC="$gif" width=40 height=40></TD></TR>
	</TABLE>
	<FONT SIZE=2>weight:$status[0]</FONT><BR>
	</TD>
	<TD bgcolor="black">
	<TABLE BORDER=1>
	<TR><TH>$birth $name</TH><TH>HP</TH><TH>STM</TH><TH>STR</TH><TH>DEX</TH><TH>SPD</TH><TH>$b_name[1]</TH></TR>
	<TR><TH>$sedai대 "$owner" 제$no자식</TH><TH>$statusp[1]</TH><TH>$statusp[2]</TH><TH>$statusp[3]</TH><TH>$statusp[4]</TH><TH>$statusp[5]</TH><TH>$ip</TH></TR>
	</TABLE>
	</TD>
</TR>
</TABLE>
<HR>
_EOF_
	}
	print<<"_EOF_";
<CENTER>
[<A HREF="$backurl" target="_top">$backtitle</A>][<A HREF="$cginame?mode=title" target="top">제목</A>][<A HREF="$cginame?mode=rank">랭킹</A>]<BR>
</CENTER>
_EOF_
	print $html_foot;
}

# ----------------------------------------------------------
# 입장 처리
# ----------------------------------------------------------

# 입장 화면

sub enter_print {
	@users = &read ($userfile);
	$userdata = &user_set; 
	$name = (split (/<p>/,$userdata))[2];
	$sedai = (split (/<p>/,$userdata))[3];
	print $html_head;
	print<<"_EOF_";
<FORM METHOD="post" ACTION="$cginame">
$user님, 환영합니다.$name의 교배 상대를 선택하세요.<BR>
<INPUT TYPE="hidden" NAME="mode" VALUE="create">
<INPUT TYPE="hidden" NAME="user" VALUE="$user">
<INPUT TYPE="hidden" NAME="pass" VALUE="$FORM{'pass'}">
<big><FONT COLOR="#ffb0ff"><B>$name</B></FONT><sub>$sedai</sub></big> × 
_EOF_

	if ($ipflag == 0) {
		print "<SELECT NAME=\"sel\">\n";
		print "<OPTION VALUE=\"\">교배 상대\n";
		$rank=1;
		foreach $line (@rank) {
			$no = (split (/<p>/,$line))[1];
			$name = (split (/<p>/,$line))[2];
			$sedai = (split (/<p>/,$line))[3];
			$seed = (split (/<p>/,$line))[11];
			if ($seed > 0) {
				print "<OPTION VALUE=\"$no\">$rank위 $name $sedai\n";
			}
			$rank++;
		}
		print<<"_EOF_";
</SELECT>
<INPUT TYPE=submit VALUE="교배">
_EOF_
	} else {
		print "이용은 1시간에 1회까지만 가능합니다.<BR>\n";
	}

	$print = &status_print ($userdata);
	print $print;
	print<<"_EOF_";
</FORM>
_EOF_
	print $html_foot;
}

sub user_set {
	$user = $FORM{'user'};
	if ($user eq '') {
		&error(1,'사용자명을 입력해야 등록할 수 있습니다.');
	}
	if (length($user) > 16) { $user = substr($user,0,16); }
	&set_cookie;

	$match = 0;
	$time = time;
	$ipflag = 0;
	$ipad = $ENV{'REMOTE_ADDR'};
	$userdata = '';

	foreach $line (@users) {
		$checkuser = (split(/<p>/,$line))[4];
		$checkpass = (split(/<p>/,$line))[11];
		$checkip = (split(/<p>/,$line))[1];
		$checktime = (split(/<p>/,$line))[5];

		if ($checkuser eq $user) {
			$match = &pass_match ($FORM{'pass'},$checkpass);
			if (($time - 3600) < $checktime) {
				$ipflag = 1;
				if ($FORM{'mode'} eq 'create') {
					&error(1,'캐릭터를 다시 만들려고 하지 마세요.');
				}
			}
			if ($match) { $userdata = $line; }
			else { 
				&error(1,'비밀번호가 틀렸거나 해당 이름을 다른 사람이 이미 사용 중입니다.');
			}
		}
		if ($checkip eq $ipad && ($time - 3600) < $checktime) { 
			$ipflag = 1;
			if ($FORM{'mode'} eq 'create') {
				&error(1,'캐릭터를 다시 만들려고 하지 마세요.');
			}
		}
	}
	$newbie = 0;
	if ($userdata eq '') {
		$newbie = 1;
		$userdata = &create_char ($eve,$adam);
	}
	return $userdata;
}

# ----------------------------------------------------------
# 새 캐릭터 생성
# ----------------------------------------------------------

sub create {
	@users = &read ($userfile,$userloc);
	$userdata = &user_set;
	$halfdata = &seed_set;
	$newdata = &create_char ($userdata,$halfdata);
	&user_save ($newdata);
	&create_print;
}

# 캐릭터 합성

sub create_char {
	local ($userdata,$halfdata) = @_;
	$dna1 = (split(/<p>/,$userdata))[9];
	$dna2 = (split(/<p>/,$halfdata))[9];
	$seed1 = &seed_create ($dna1);
	$seed2 = &seed_create ($dna2);
	$new_dna = "$seed1<m>$seed2";
	($status,$color,$gif) = &status_set ($new_dna);
	$new_no = (split(/<p>/,$users[0]))[0] + 1;
	if ($new_no == 1) { $new_no = 3; }
	$name = (split(/<p>/,$userdata))[2];
	$new_sedai = (split(/<p>/,$userdata))[3] + 1;
	$time = time;
	$new_blood = &blood_mix ($userdata,$halfdata);
	$ango = &encode_pass ($FORM{'pass'});
	if ($newbie) {
		$name = "이브의 아이";
		$new_sedai = 0;
		if ($newbie == 2) {
			$name = "아직 이름 없음";
			$new_sedai = 1;
		}
		$newbie = 2;
	}

	$newdata = "$new_no<p>$ipad<p>$name<p>$new_sedai<p>$user<p>$time<p>$color<p>$gif<p>$status<p>$new_dna<p>$new_blood<p>$ango<p>0<p>d\n";
	return $newdata;
}

# 사용자 파일 저장 및 만료 데이터 삭제

sub user_save {
	@new = '';
	push(@new,$_[0]);
	foreach $line (@users) {
		$lineowner = (split(/<p>/,$line))[4];
		$linetime = (split(/<p>/,$line))[5];
		if (($time - 604800) < $linetime && $user ne $lineowner) {
			push(@new,$line);
		}
	}
	@new = sort {$b <=> $a} @new;
	&save ($userfile,$usertmp,$userloc,@new);
}

# 새 캐릭터 표시

sub create_print {
	print $html_head;
	print<<"_EOF_";
<FORM METHOD="post" ACTION="$cginame" target="bottom">
$name의 아이가 태어났습니다. 이름을 붙이고 랭킹에 도전하세요!<BR>
<INPUT TYPE="hidden" NAME="mode" VALUE="fight">
<INPUT TYPE="hidden" NAME="user" VALUE="$user">
<INPUT TYPE="hidden" NAME="pass" VALUE="$FORM{'pass'}">
이름:<INPUT type="text" name="name" size=18 value="$name">
<INPUT TYPE="submit" VALUE="전투 시작">
_EOF_

	$print = &status_print ($newdata);
	print $print;
	print<<"_EOF_";
이 아이는 세계가 창조된 뒤$new_no번째로 태어난 슬라임입니다.<BR>
</FORM>
_EOF_
	print $html_foot;
}

# 새 혈통 데이터 작성

sub blood_mix {
	local ($data1,$data2) = @_;
	$blood1 = (split(/<p>/,$data1))[10];
	$blood2 = (split(/<p>/,$data2))[10];
	@blood1 = split (/<s>/,$blood1);
	@blood2 = split (/<s>/,$blood2);
# 0=자신의 부모 1=상대 부모 2=자신의 부모부모 345=상대 부모부모 6=자신의 부모부모부모 7-13=상대 부모부모부모 

	$no1 = (split(/<p>/,$userdata))[0];
	$name1 = (split(/<p>/,$userdata))[2];
	$sedai1 = (split(/<p>/,$userdata))[3];
	$no2 = (split(/<p>/,$halfdata))[1];
	$name2 = (split(/<p>/,$halfdata))[2];
	$sedai2 = (split(/<p>/,$halfdata))[3];

	$p0 = "$no1<>$name1<>$sedai1";
	$p1 = "$no2<>$name2<>$sedai2";

	$p2 = @blood1[0];
	$p3 = @blood1[1];
	$p4 = @blood2[0];
	$p5 = @blood2[1];

	$p6 = @blood1[2];
	$p7 = @blood1[3];
	$p8 = @blood1[4];
	$p9 = @blood1[5];
	$pa = @blood2[2];
	$pb = @blood2[3];
	$pc = @blood2[4];
	$pd = @blood2[5];

	$new_blood = "$p0<s>$p1<s>$p2<s>$p3<s>$p4<s>$p5<s>$p6<s>$p7<s>$p8<s>$p9<s>$pa<s>$pb<s>$pc<s>$pd";
	return $new_blood;
}

# 교배 상대 데이터 읽기

sub seed_set {
	@lines = &read ($rankfile,$rankloc);
	$seekno = $FORM{'sel'};
	if ($seekno eq '') {
		&error(1,'교배 상대를 선택해 주세요.');
	}
	@new = '';
	$halfflag = 0;
	foreach $line (@lines) {
		($a0,$no,$a2,$a3,$a4,$a5,$a6,$a7,$status,$a9,$b0,$seedrest,$child,$b3,$sperm,$b5) = split(/<p>/,$line);
		if ($no eq $seekno) {
			if ($seedrest < 1) {
				&error(1,'그 상대의 씨앗은 누군가가 먼저 사용한 것 같습니다.');
			}
			$halfdata = $line;
			$halfflag = 1;
			$seedrest -= 1;
			$child += 1;
		}
		$sex = (split(/<>/,$status))[7];
		$sperm += $sex;
		if ($sperm > $seed_gage) {
			$sperm -= $seed_gage;
			$seedrest += 1;
		}
		push(@new,"$a0<p>$no<p>$a2<p>$a3<p>$a4<p>$a5<p>$a6<p>$a7<p>$status<p>$a9<p>$b0<p>$seedrest<p>$child<p>$b3<p>$sperm<p>$b5");
	}
	if ($halfflag == 0) {
		&error(1,'그 상대는 랭킹 밖으로 밀려났습니다.');
	}
	&save ($rankfile,$ranktmp,$rankloc,@new);
	return $halfdata;
}

# 씨앗 생성

sub seed_create {
	local ($dna) = $_[0];
	local ($seed,$part,$dna1,$dna2,$rnd,$dice,$para,$parap);
	$seed = '';
	($dna1,$dna2) = split (/<m>/,$dna);
	for ($i = 0; $i < 16; $i++) {
		$rnd = &rnd;
		if ($rnd) { $part = (split (/<s>/,$dna1))[$i]; }
		else { $part = (split (/<s>/,$dna2))[$i]; }
		if ($i < 7) {
			($para,$parap) = split (/<>/,$part);
			$dice = &dice;
			$para += $dice - ($tumble * (1 + $range) / 2);
			$para = $para * ($para > 0) + ($para < 1);
			$dice = &dice;
			$parap += $dice - ($tumble * (1 + $range) / 2);
			$part = "$para<>$parap";
		}
		$seed .= $part;
		if ($i < 15) { $seed .= '<s>'; }
	}
	return $seed;
}

# 능력치 설정

sub status_set {
	local ($dna) = $_[0];
# @para:0=HRD 1=SFT 2=BRN 3=NET 4=FAT 5=MEN 6=SEX
# 	7=RED 8=GRN 9=BLU 10=X  11=Y  12=Z  13=리본 14=왕관  15=날개
	@para = &dna_trans($dna);
	$para[5] -= ($para[5] > ($para[2] * 2)) * ($para[5] - ($para[2] * 2));
	$wgt = int (($para[0] * 2 + $para[1]  * 3 + $para[2] + $para[4] * 5) / 11);
	$hp  = int (($para[0] + $para[1] + $para[4]) * 10 / 3);
	$stm = int (($para[4] + $para[5]) * 10 / 2);
	$str = int (($para[0] + $para[1] + $wgt * 3) / 5);
	$dex = int (($para[1] + $para[3]) / 2 * $para[2] / $wgt) + 1;
	$spd = int ($para[1] * $para[3] / $wgt) + 1;
	$cst = int (($wgt * 3 + $para[2] + $para[3] + $para[6]) / 6);
	$sex = int ($para[6] / $cst * 100) + 1;
	$status = "$wgt<>$hp<>$stm<>$str<>$dex<>$spd<>$cst<>$sex";

# 돌연변이

	$rgb = $para[7] + $para[8] + $para[9];
	$xyz = $para[10] + $para[11] + $para[12];
	$uvw = $para[13] + $para[14] + $para[15];
	$dnaflag = 0;
	$rgbup = 0;
	$rgbdn = 0;
	$xyzup = 0;
	$xyzdn = 0;
	$uvwup = 0;
	$uvwdn = 0;
	if ($rgb == 0 && int (rand ($henka)) == 0) { $dnaflag = 1; $rgbup = 1; }
	if ($rgb == 6 && int (rand ($henka)) == 0) { $dnaflag = 1; $rgbdn = 1; }
	if ($xyz == 0 && int (rand ($henka)) == 0) { $dnaflag = 1; $xyzup = 1; }
	if ($xyz == 6 && int (rand ($henka)) == 0) { $dnaflag = 1; $xyzdn = 1; }
	if ($uvw == 0 && int (rand ($henka)) == 0) { $dnaflag = 1; $uvwup = 1; }
	if ($uvw == 6 && int (rand ($henka)) == 0) { $dnaflag = 1; $uvwdn = 1; }
	if ($dnaflag) {
		($dna[0],$dna[1]) = split (/<m>/,$dna);
		for ($i = 0; $i < 2; $i++) {
			($d0,$d1,$d2,$d3,$d4,$d5,$d6,$r,$g,$b,$x,$y,$z,$u,$v,$w) = split (/<s>/,$dna[$i]);
			if ($rgbup) { $r = 1; $g = 1; $b =1; }
			if ($rgbdn) { $r = 0; $g = 0; $b =0; }
			if ($xyzup) { $x = 1; $y = 1; $z =1; }
			if ($xyzdn) { $x = 0; $y = 0; $z =0; }
			if ($uvwup) { $u = 1; $v = 1; $w =1; }
			if ($uvwdn) { $u = 0; $v = 0; $w =0; }
			$change[$i] = "$d0<s>$d1<s>$d2<s>$d3<s>$d4<s>$d5<s>$d6<s>$r<s>$g<s>$b<s>$x<s>$y<s>$z<s>$u<s>$v<s>$w";
		}
		$new_dna = "$change[0]<m>$change[1]";
		@para = &dna_trans($new_dna);
		$rgb = $para[7] + $para[8] + $para[9];
		$xyz = $para[10] + $para[11] + $para[12];
		$uvw = $para[13] + $para[14] + $para[15];
	}

# 색상 결정

	if ($para[7] == 0) {
		$red = '00';
		if ($para[10] == 1) { $red = '3f'; }
	}	elsif ($para[7] == 1) {
		$red = '7f';
	}	else {
		$red = 'ff';
		if ($para[10] == 1) { $red = 'bf'; }
	}
	if ($para[8] == 0) {
		$grn = '00';
		if ($para[11] == 1) { $grn = '3f'; }
	}	elsif ($para[8] == 1) {
		$grn = '7f';
	}	else {
		$grn = 'ff';
		if ($para[11] == 1) { $grn = 'bf'; }
	}
	if ($para[9] == 0) {
		$blu = '00';
		if ($para[12] == 1) { $blu = '3f'; }
	}	elsif ($para[9] == 1) {
		$blu = '7f';
	}	else {
		$blu = 'ff';
		if ($para[12] == 1) { $blu = 'bf'; }
	}
	$color = "#$red$grn$blu";

	$gif = $char_normal;
	if ($xyz == 6) {
		$gif = $char_aura;
		if ($uvw == 3) { $gif = $char_hider; }
		if ($para[15] == 2) { $gif = $char_wing; }
		if ($para[13] == 2) {
			$gif = $char_ribbon;
			if ($para[15] == 2) { $gif = $char_ribbonw; }
		}
		if ($para[14] == 2) {
			$gif = $char_crown;
			if ($para[13] == 2) {
				$gif = $char_aho;
				if ($rgb < 2) { $gif = $char_zombie; }
				if ($rgb == 6) { $gif = $char_oyaji; }
			}
			if ($para[15] == 2) { $gif = $char_crownw; }
		}
		if ($uvw == 6) {
			$gif = $char_musi;
			if ($rgb > 3) { $gif = $char_angel; }
			if ($rgb < 1) { $gif = $char_devil; }
		}
	}
	return ($status,$color,$gif);
}

# DNA 해석

sub dna_trans {
	local ($dna) = $_[0];
	local ($part1,$part2,$dna1,$dna2,$parap1,$para1,$parap2,$para2);
	@para = '';
	($dna1,$dna2) = split (/<m>/,$dna);
	for ($i = 0; $i < 16; $i++) {
		$part1 = (split (/<s>/,$dna1))[$i];
		$part2 = (split (/<s>/,$dna2))[$i];
		if ($i < 7) {
			($para1,$parap1) = split (/<>/,$part1);
			($para2,$parap2) = split (/<>/,$part2);
			if ($parap1 > ($parap2 + ($range - 1) * $tumble * 0.05)) { $para[$i] = $para1; }
			elsif (($parap1 + ($range - 1) * $tumble * 0.05) < $parap2) { $para[$i] = $para2; }
			else { $para[$i] = int (($para1 + $para2) / 3) + 1; }
		} else { $para[$i] = $part1 + $part2; }
	}
	return @para;
}

# ----------------------------------------------------------
# 전투
# ----------------------------------------------------------

sub fight {
	@users = &read ($userfile,$userloc);
	$userdata = &user_set;
		($u_no,$u1,$u_name,$u3,$u4,$u5,$u6,$u7,$u_status,$u9,$ua,$ub,$check,$ud) = split(/<p>/,$userdata);
	if ($check) {
		&error(1,'전투는 다시 시작할 수 없습니다. 또는 서버 혼잡으로 저장되지 않았으니 교배부터 다시 진행해 주세요.');
	}

	print $html_head;
	if ($FORM{'name'} ne '') { $u_name = $FORM{'name'}; }
	if (length($u_name) > 18) { $u_name = substr($u_name,0,18); }
	$checkeduser = "$u_no<p>$u1<p>$u_name<p>$u3<p>$u4<p>$u5<p>$u6<p>$u7<p>$u_status<p>$u9<p>$ua<p>$ub<p>1<p>$ud";
	&user_save ($checkeduser);

	@rank = &read ($rankfile,$rankloc);
	$u_pts = 1;
	$u_win = 0;
	$u_lose = 0;
	$loseflag = 0;
	$result_text = '';

	@new = '';
	@rank = sort {$a <=> $b} @rank;
	$rankend_pts = (split(/<p>/,$rank[0]))[0];
	$cut_length = length($rankend_pts) - 2;
	$cut_length *= ($cut_length > 0);
	$r = @rank;

	foreach $line (@rank) {
		($e_pts,$a1,$e_name,$e_sedai,$a4,$a5,$e_color,$a7,$e_status,$a9,$b0,$b1,$b2,$e_result,$b4,$b5) = split(/<p>/,$line);
		($e_win,$e_lose) = split(/<>/,$e_result);
		$e_pts = int ($e_pts / (10 ** $cut_length));
		unless ($loseflag) {
			if ($e_pts >= $u_pts || $r < 4) {
				&fight_set ($u_status,$e_status);
				if ($r == 1 && $loseflag) {
					($b5_rank,$b5_defend) = split(/<sup>/,$b5);
					$b5_defend += 1;
					$b5 = "1위<sup>$b5_defend</sup>\n";
				}
				print $result_text;
				$result_text = '';
			}
		}
		$e_result = "$e_win<>$e_lose";
		if ($b5 > $r || $b5 == 0) { $b5 = $r . "위\n"; }
		$newline = "$e_pts<p>$a1<p>$e_name<p>$e_sedai<p>$a4<p>$a5<p>$e_color<p>$a7<p>$e_status<p>$a9<p>$b0<p>$b1<p>$b2<p>$e_result<p>$b4<p>$b5";
		push(@new,$newline);
		$r--;
	}
	$iniseed = int ($sex[0] /10);
	$u_data = "$u_pts<p>$u_no<p>$u_name<p>$u3<p>$u4<p>$u5<p>$u6<p>$u7<p>$u_status<p>$u9<p>$ua<p>$iniseed<p>0<p>$u_win<>$u_lose<p>0<p>$rankmax위\n";
	unshift (@new,$u_data);

# 챔피언 방어 및 랭킹 저장

	$champ = @new[@new-1];
	pop @new;

	@new = sort {$b <=> $a} @new;

	$ranger = $new[0];
	$champ_pts = (split(/<p>/,$champ))[0];
	$ranger_pts = (split(/<p>/,$ranger))[0];
	$king_flag = 0;
	if ($champ_pts < $ranger_pts) {
		($u_pts,$u1,$u_name,$u_sedai,$u4,$u5,$u_color,$u7,$u_status,$u9,$v0,$v1,$v2,$u_result,$v4,$v5) = split(/<p>/,$champ);
		($u_win,$u_lose) = split(/<>/,$u_result);
		($e_pts,$a1,$e_name,$e_sedai,$a4,$a5,$e_color,$a7,$e_status,$a9,$b0,$b1,$b2,$e_result,$b4,$b5) = split(/<p>/,$ranger);
		($e_win,$e_lose) = split(/<>/,$e_result);
		($v5_rank,$v5_defend) = split(/<sup>/,$v5);
		if ($loseflag == 0) {
			shift @new;
			unshift (@new,$champ);
			unshift (@new,$ranger);
			if ($v5_defend > ($dendo - 1)) { $king_flag = 1; }
		} else {
			$loseflag = 0;
			&fight_set ($u_status,$e_status);
			$u_result = "$u_win<>$u_lose";
			$e_result = "$e_win<>$e_lose";
			$champ = "$u_pts<p>$u1<p>$u_name<p>$u_sedai<p>$u4<p>$u5<p>$u_color<p>$u7<p>$u_status<p>$u9<p>$v0<p>$v1<p>$v2<p>$u_result<p>$v4<p>$v5";
			$ranger = "$e_pts<p>$a1<p>$e_name<p>$e_sedai<p>$a4<p>$a5<p>$e_color<p>$a7<p>$e_status<p>$a9<p>$b0<p>$b1<p>$b2<p>$e_result<p>$b4<p>$b5";
			if ($loseflag) {
				shift @new;
				unshift (@new,$champ);
				unshift (@new,$ranger);
				if ($v5_defend > ($dendo - 1)) { $king_flag = 1; }
			} else {
				$v5_defend += 1;
				$v5 = "1위<sup>$v5_defend</sup>\n";
				$champ = "$u_pts<p>$u1<p>$u_name<p>$u_sedai<p>$u4<p>$u5<p>$u_color<p>$u7<p>$u_status<p>$u9<p>$v0<p>$v1<p>$v2<p>$u_result<p>$v4<p>$v5";
				shift @new;
				unshift (@new,$ranger);
				unshift (@new,$champ);
			}
		}
	} else {
		unshift (@new,$champ);
	}

	while (@new > $rankmax) { pop @new; }
	&save ($rankfile,$ranktmp,$rankloc,@new);

# 명예의 전당 입성
	if ($king_flag) {
		@king = &read ($kingfile,$kingloc);
		unshift (@king,$champ);
		&save ($kingfile,$kingtmp,$kingloc,@king);

		$FORM{'user'} = "축하-명예의 전당 입성";
		$FORM{'comt'} = "$u_name $u_sedai 가 명예의 전당에 입성했습니다.$u4님, 축하합니다.";
		&add_comt;
	}

	if ($u3 > 99) {
		$mania = "[<A HREF=\"$cginame?mode=mania\">시스템 해설</A>]";
	} else { $mania = ''; }

	print<<"_EOF_";
<FONT SIZE=2>[O]=명중 [X]=빗나감 [o]=피격 [x]=회피</FONT>
<HR>
<CENTER>
[<A HREF="$backurl" target="_top">$backtitle</A>][<A HREF="$cginame?mode=rank">랭킹</A>][<A HREF="$cginame?mode=title" target="top">제목</A>]$mania
<BR>
</CENTER>
_EOF_
	print $html_foot;
}

sub fight_set {
	local (@status) = @_;
	for ($i = 0; $i < 2; $i++) {
		($wgt[$i],$maxhp[$i],$maxst[$i],$str[$i],$dex[$i],$spd[$i],$cst[$i],$sex[$i]) = split (/<>/,$status[$i]);
	}
# 자신[$turn != 0]
# 상대[$turn == 0]
	@gage = '';
	$turn = 0;
	$hit[0] = 0; $hit[1] = 0;
	$attack[0] = 0; $attack[1] = 0;
	$maxst[0] *= 8; $maxst[1] *= 8;
	$hp[0] = $maxhp[0]; $hp[1] = $maxhp[1];
	$st[0] = $maxst[0]; $st[1] = $maxst[1];
	$pow[0] = 1; $pow[1] = 1;
	$powx[0] = 1; $powx[1] = 1;
	$powy[0] = 1; $powy[1] = 1;
	$sum_rndhit[0] = 0; $sum_rndhit[1] = 0;
	$sum_hitper[0] = 0; $sum_hitper[1] = 0;
	$spd_gage = ($spd[0] >= $spd[1]) * $spd[0] + ($spd[0] < $spd[1]) * $spd[1] - 1;
	$fightlog = '';
	$round = 1;
	until ($hp[0] < 1 || $hp[1] < 1) {
		if ($gage[$turn != 0] > $spd_gage) {
			$gage[$turn != 0] -= $spd_gage;
			$attack[$turn != 0] += 1;
			$my_dex = $dex[$turn != 0] * $powx[$turn != 0];
			$rnd_hit = rand ($my_dex + $spd[$turn == 0] * $powx[$turn == 0]);
			$hit_per = 1 - ($rnd_hit / $my_dex) ** 2;
			$sum_rndhit[$turn != 0] += (1 - $rnd_hit / ($my_dex + $spd[$turn == 0] * $powx[$turn == 0]));
			if ($rnd_hit < $my_dex) {
				$hit[$turn != 0] += 1;
				$hp[$turn == 0] -= int ($str[$turn != 0] * $hit_per * $powx[$turn != 0]);
				$st[$turn == 0] -= int ($cst[$turn != 0] * $hit_per * 1.25 * $powy[$turn != 0]);
				$sum_hitper[$turn != 0] += $hit_per;
				if ($turn == 0) {
					$fightlog .= "O";
				} else { 
					$fightlog .= "o";
				}
			} else {
				if ($turn == 0) {
					$fightlog .= "X";
				} else { 
					$fightlog .= "x";
				}
			}
			$st[$turn != 0] -= $cst[$turn != 0] * $powy[$turn != 0];
			$st[$turn == 0] -= int ($cst[$turn != 0] * 0.25 * $powy[$turn != 0]);
			$st[$turn != 0] *= ($st[$turn != 0] > 0);
			$st[$turn == 0] *= ($st[$turn == 0] > 0);
			$pow[$turn != 0] = $st[$turn != 0] / $maxst[$turn != 0];
			$pow[$turn == 0] = $st[$turn == 0] / $maxst[$turn == 0];
			$powx[$turn != 0] = 0.4 + 0.6 * (1 - (1 - $pow[$turn != 0]) ** 2);
			$powx[$turn == 0] = 0.4 + 0.6 * (1 - (1 - $pow[$turn == 0]) ** 2);
			$powy[$turn != 0] = 0.6 + 0.4 * (1 - (1 - $pow[$turn != 0]) ** 2);
			$powy[$turn == 0] = 0.6 + 0.4 * (1 - (1 - $pow[$turn == 0]) ** 2);
			if (!($round % 10)) {
				$fightlog .= " ";
			}
			$round++;
		}
		$gage[$turn != 0] += int ($spd[$turn != 0] * $powx[$turn != 0]);
		$turn = ($turn == 0);
	}
	if ($turn) { &fight_win; }
	else { &fight_lose; }
}

sub fight_win {
	$u_pts += $e_pts;
	$u_win += 1;
	$e_lose += 1;
	$result_msg=<<"_EOF_";
<FONT SIZE=7 color="red" FACE="Times New Roman"><i>YOU WIN!</i></FONT><BR>
NOW $u_pts<small>pts.</small><BR>
_EOF_
	if ($r == 1) {
		$cong=<<"_EOF_";
<BR>
<FONT SIZE=7 color="yellow" FACE="Times New Roman"><i>
Congratulations!<BR>
You are the new CHAMPION!<BR>
</i></FONT>
_EOF_
		$result_msg .= $cong;
	}
	&fight_print;
}

sub fight_lose {
	$e_pts += $u_pts;
	$e_win += 1;
	$u_lose += 1;
	$result_msg=<<"_EOF_";
<FONT SIZE=7 color="blue" FACE="Times New Roman"><i>YOU LOSE!</i></FONT><BR>
TOTAL $u_pts<small>pts.</small><BR>
_EOF_
	$loseflag = 1;
	&fight_print;
}

sub fight_print {
	$print1=<<"_EOF_";
<BIG><B><FONT COLOR="yellow">VS</FONT> 제$r위 <FONT COLOR="#ffb0ff">$e_name</FONT></B><sub>$e_sedai</sub></BIG> 씨앗$b1개 자식$b2마리 $e_win승$e_lose패 최고$b5$e_pts<small>pts.</small><BR>
_EOF_

	$print2 = &status_print ($line);

	$pow[0] = int ($pow[0] * 100);
	$pow[1] = int ($pow[1] * 100);
	$dmg_ave[0] = 0;
	$dmg_ave[1] = 0;
	if ($hit[0]) { $dmg_ave[0] = int (($maxhp[1] - $hp[1]) / $hit[0]); }
	if ($hit[1]) { $dmg_ave[1] = int (($maxhp[0] - $hp[0]) / $hit[1]); }
	if ($hit[0]) { $luck_hit[0] = int (100 * $sum_hitper[0] / $hit[0]); }
	if ($hit[1]) { $luck_hit[1] = int (100 * $sum_hitper[1] / $hit[1]); }
	if ($attack[0]) { $luck_atk[0] = int (100 * $sum_rndhit[0] / $attack[0]); }
	if ($attack[1]) { $luck_atk[1] = int (100 * $sum_rndhit[1] / $attack[1]); }
	$print3=<<"_EOF_";
<TABLE BORDER=0>
<TR bgcolor="#00007f"><TD>$u_name </TD><TD>HP:<FONT COLOR="yellow">$hp[0]</FONT>/<sub>$maxhp[0]</sub> </TD><TD>STM:$pow[0]% </TD><TD>HIT$hit[0]</TD><TD>/ATTACK$attack[0]회 </TD><TD>DmgAve$dmg_ave[0] </TD><TD>LUCK:$luck_atk[0]($luck_hit[0])</TD></TR>
<TR><TD>$e_name </TD><TD>HP:<FONT COLOR="yellow">$hp[1]</FONT>/<sub>$maxhp[1]</sub> </TD><TD>STM:$pow[1]% </TD><TD>HIT$hit[1]</TD><TD>/ATTACK$attack[1]회 </TD><TD>DmgAve$dmg_ave[1] </TD><TD>LUCK:$luck_atk[1]($luck_hit[1])</TD></TR>
</TABLE>
<BR>
<CENTER>
$result_msg
</CENTER>
<BR>
$fightlog
<HR>
_EOF_

	$result_text .= "$print1$print2$print3";
}

# ----------------------------------------------------------
# 난수 생성
# ----------------------------------------------------------

# 0 또는 1을 반환
sub rnd {
	$rnd = int (rand (2));
	return $rnd;
}

# 주사위
sub dice {
	local ($dice,$j);
	$dice = 0;
	for ($j = 0; $j < $tumble; $j++) {
		$dice += int (1 + rand ($range));
	}
	return $dice;
}

# ----------------------------------------------------------
# 쿠키
# ----------------------------------------------------------

sub set_cookie {
	# 쿠키는 7일간 유효
	($secg,$ming,$hourg,$mdayg,$mong,$yearg,$wdayg,$ydayg,$isdstg)
		 				= gmtime(time + 7*24*60*60);

	$yearg += 1900;
	if ($secg  < 10) { $secg  = "0$secg";  }
	if ($ming  < 10) { $ming  = "0$ming";  }
	if ($hourg < 10) { $hourg = "0$hourg"; }
	if ($mdayg < 10) { $mdayg = "0$mdayg"; }

	$month = ('Jan','Feb','Mar','Apr','May','Jun','Jul',
				'Aug','Sep','Oct','Nov','Dec')[$mong];
	$youbi = ('Sunday','Monday','Tuesday','Wednesday',
				'Thursday','Friday','Saturday')[$wdayg];

	$date_gmt = "$youbi, $mdayg\-$month\-$yearg $hourg:$ming:$secg GMT";
	$cook="user\:$user\,pwd\:$FORM{'pass'}";
	print "Set-Cookie: slime=$cook; expires=$date_gmt\n";
}

sub get_cookie { 
	@pairs = split(/;/, $ENV{'HTTP_COOKIE'});
	foreach $pair (@pairs) {
		local($name, $value) = split(/=/, $pair);
		$name =~ s/ //g;
		$DUMMY{$name} = $value;
	}
	@pairs = split(/,/, $DUMMY{'slime'});
	foreach $pair (@pairs) {
		local($name, $value) = split(/:/, $pair);
		$COOKIE{$name} = $value;
	}
	$c_name  = $COOKIE{'user'};
	$c_pwd   = $COOKIE{'pwd'};
}

# ----------------------------------------------------------
# 비밀번호
# ----------------------------------------------------------

sub encode_pass {
	$now = time;
	($pack1, $pack2) = unpack("C2", $now);
	$wk = $now / (60*60*24*7) + $pack1 + $pack2 - 8;
	@saltset = ('a'..'z','A'..'Z','0'..'9','.','/');
	$nsalt = $saltset[$wk % 64] . $saltset[$now % 64];
	$ango = crypt($_[0], $nsalt);
	return $ango;
}

sub pass_match {
	local ($inputpass,$checkpass) = @_;
	if ($checkpass eq crypt ($inputpass,substr ($checkpass,0,2))) {
# FreeBSD서버는substr ($checkpass,3,2)에변경
		$match = 1;
	} else { $match = 0; }
	return $match;
}

# ----------------------------------------------------------
# 날짜 가져오기
# ----------------------------------------------------------

sub date {
	local ($time) = $_[0];
	($sec,$min,$hour,$day,$mon) = localtime($time);
	$mon++;
	if ($sec < 10)  { $sec  = "0$sec";  }
	if ($min < 10)  { $min  = "0$min";  }
	if ($hour < 10) { $hour = "0$hour"; }
	if ($day < 10)  { $day  = "0$day";  }
	if ($mon < 10)  { $mon  = "0$mon";  }

	$date = "$mon/$day $hour:$min";
	return $date;
}

# ----------------------------------------------------------
# 기록 파일 처리
# ----------------------------------------------------------

sub read {
	local($logfile,$lockfile) = @_;
	if ($lockfile) {
		foreach (1 .. 45) {
			unless (-f $lockfile) {
				open(LOC,">$lockfile") || die "Can't create lock file.\n";
				close(LOC);
				push(@locklist,$lockfile);
				last;
			}
			sleep(1);
		}
	}
	if (!open(IN,$logfile)) { &error(1,"기록 파일을 읽을 수 없습니다."); }
	local(@files) = <IN>;
	close(IN);
	return @files;
}

sub save {
	local($logfile,$tmpfile,$lockfile,@lines) = @_;
	$tmp_dummy = "$$\.tmp";
	open(TMP,">$tmp_dummy") || die "Can't create tmp file.\n";
	close(TMP);
	chmod 0666,$tmp_dummy;
	open(TMP,">$tmp_dummy") || die "Can't open tmp file.\n";
	print TMP @lines;
	close(TMP);
	foreach (1 .. 30) {
		if (link($tmp_dummy,$tmpfile) == 1) {
			last;
		}
		sleep(1);
	}
	rename($tmpfile,$logfile); 
	chmod 0644,$logfile;
	unlink $tmp_dummy;
	if (-f $lockfile) { unlink $lockfile; }
}

# ----------------------------------------------------------
# 폼 데이터 읽기
# ----------------------------------------------------------

sub read_form {
    local($pair,$buffer);
    if ($ENV{'REQUEST_METHOD'} eq "POST") { read(STDIN, $buffer, $ENV{'CONTENT_LENGTH'}); } else { $buffer = $ENV{'QUERY_STRING'}; }
    local(@pairs) = split(/&/,$buffer);
    foreach $pair (@pairs) {
        local($name,$value) = split(/=/,$pair);
        $value =~ tr/+/ /;
        $value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C",hex($1))/eg;
        $FORM{$name} = &change_code($value);
    }
}

# ----------------------------------------------------------
# 문자 코드 관련
# ----------------------------------------------------------

sub check_code {
    $mojicode = "utf8";
    $charset_code = "UTF-8";
}

sub change_code {
    local($text)=$_[0];
    $text =~ s/\&/&amp;/g;
    $text =~ s/</&lt;/g;
    $text =~ s/>/&gt;/g;
    return $text;
}

# ----------------------------------------------------------
# 오류 처리
# ----------------------------------------------------------

sub error {
	($err,$err_msg) = @_;
	if ($err) {
		print $html_head;
		print<<"_EOF_";
<FONT COLOR="red"><B>오류：$err_msg</B></FONT><BR>
<A HREF="$cginame" target="_top">새로고침</A><BR>
</BODY></HTML>
_EOF_
		print $html_foot;
	}
	foreach $line (@locklist) {
		if (-f $line) { unlink $line; }
	}
	exit;
}

# ----------------------------------------------------------
# 안내서
# ----------------------------------------------------------

sub guide {
	print $html_head;
	print<<"_EOF_";
★글자 수 제한<BR>
사용자명은 한글 기준 8자, 영문 기준 16자까지입니다.<BR>
슬라임 이름은 한글 기준 9자, 영문 기준 18자까지입니다.<BR>
<BR>
★게임 소개<BR>
이 게임은 유전자 진화 시뮬레이션입니다. 각 슬라임은 DNA를 가지고 있으며, 능력치와 외형은 DNA 조합으로 결정됩니다.<BR>
강한 슬라임을 만들려면 교배를 반복하며 좋은 혈통을 이어 가야 합니다.<BR>
<BR>
★진행 방법<BR>
플레이어가 할 일은 자신의 슬라임에게 어울리는 교배 상대를 고르는 것입니다.<BR>
새 슬라임이 태어나면 이름을 붙이고 전투를 시작하세요. 전투는 랭킹 하위부터 자동으로 진행되며, 패배할 때까지 이어집니다.<BR>
씨앗이 없는 개체는 교배 상대로 고를 수 없습니다. 서버 부하를 줄이기 위해 플레이는 1시간에 1회로 제한됩니다.<BR>
1주일 이상 접속하지 않은 데이터는 삭제됩니다.<BR>
<BR>
★화면 읽는 법<BR>
순위, 이름, 세대, 보유 씨앗 수, 태어난 자식 수, 전적, 최고 순위, 현재 포인트가 표시됩니다.<BR>
표에는 HP, STM, STR, DEX, SPD 등 주요 능력치와 오너, 생년월일, 외형, 체중, 혈통 정보가 표시됩니다.<BR>
HP는 체력, STM은 스태미나, STR은 공격력, DEX는 명중과 손재주, SPD는 공격 속도입니다.<BR>
<BR>
★전투 결과<BR>
전투 로그의 큰 O/X는 내 공격, 작은 o/x는 상대 공격입니다. O 또는 o는 명중, X 또는 x는 빗나감입니다.<BR>
HP는 남은 체력, STM은 전투 종료 시 남은 스태미나, HIT/ATTACK은 명중 수와 공격 횟수, DmgAve는 평균 피해량, LUCK은 난수 운을 뜻합니다.<BR>
<BR>
★랭킹과 명예의 전당<BR>
랭킹은 포인트제로 운영됩니다. 상대를 쓰러뜨리면 그 상대의 포인트를 얻고, 전투 종료 후 포인트 순서로 정렬됩니다.<BR>
1위를 일정 횟수 이상 방어한 슬라임은 전설의 슬라임으로 명예의 전당에 등록됩니다.<BR>
<BR>
★유전자와 진화<BR>
각 부모에게서 절반씩 유전자를 물려받습니다. 같은 능력에도 두 유전자가 존재하며, 자기 주장도가 강한 쪽이 겉으로 드러납니다.<BR>
강한 개체가 더 자주 교배 상대로 선택되므로 자연스럽게 도태압이 생기고, 종 전체가 진화해 가는 흐름을 관찰할 수 있습니다.<BR>
<BR>
★이야기<BR>
신은 심심풀이로 진흙을 빚어 슬라임이라는 생물을 만들었습니다. 검은 아담과 흰 이브가 태어났고, 이브가 아담의 씨앗을 먹으면서 색과 크기가 변했습니다.<BR>
슬라임은 빠르게 늘어났고, 먹을 것이 부족해지자 전투가 시작되었습니다.<BR>
_EOF_
	print $html_foot;
}
sub mania {
	print $html_head;
	print<<"_EOF_";
이 페이지는 100회 이상 플레이한 숙련 브리더를 위한 시스템 해설입니다.<BR>
<BR>
★유전 파라미터<BR>
HRD, SFT, BRN, NET, FAT, MEN, SEX의 7개 파라미터가 슬라임의 신체 특성을 결정합니다.<BR>
각 파라미터는 능력값과 자기 주장도로 이루어지며, 상대적으로 자기 주장도가 높은 유전자가 우성으로 작용합니다.<BR>
두 유전자의 자기 주장도가 거의 같으면 충돌이 발생해 능력치가 약 30% 낮아집니다. 근친 교배에서는 같은 유전자가 겹칠 확률이 높아 이런 불이익이 더 자주 생길 수 있습니다.<BR>
<BR>
★능력치 공식<BR>
weight = (HRD×2 + SFT×3 + BRN + FAT×5) / 11<BR>
HP = (HRD + SFT + FAT) / 3 × 10<BR>
STM = (FAT + MEN) / 2 × 10<BR>
STR = (HRD + SFT + weight×3) / 5<BR>
DEX = (SFT + NET) / 2 × BRN / weight<BR>
SPD = SFT × NET / weight<BR>
STM 소비량 = (weight×3 + BRN + NET + SEX) / 6<BR>
번식력 = SEX / STM 소비량 × 100<BR>
번식력 / 10의 정수부가 초기 씨앗 수가 됩니다.<BR>
<BR>
★전투 시스템<BR>
SPD만큼 속도 게이지가 차오르고, 게이지가 가득 차면 공격합니다. 명중, 피해량, SPD에는 남은 STM에 따른 계수가 적용됩니다.<BR>
공격하거나 공격을 받으면 STM이 줄고, STM이 떨어질수록 실제 전투력이 낮아집니다.<BR>
<BR>
★외형 유전자<BR>
색, 변이 스위치, 변이체 결정 유전자가 있으며 조건이 맞으면 특수한 변이체가 나타납니다.<BR>
<BR>
★어린 세대도 강해질 수 있는 이유<BR>
초기 유전자인 아담과 이브의 유전자는 자기 주장도가 낮은 편이어서 상대의 강한 유전자가 더 잘 드러나게 합니다. 그래서 첫 세대에서도 강한 슬라임이 태어날 수 있습니다.<BR>
<BR>
시스템 구조를 이해했다면, 계속 슬라임 브리더를 즐겨 주세요.<BR>
<HR>
<CENTER>
[<A HREF="$backurl" target="_top">$backtitle</A>][<A HREF="$cginame?mode=rank">랭킹</A>][<A HREF="$cginame?mode=title" target="top">타이틀</A>]<BR>
</CENTER>
_EOF_
	print $html_foot;
}
