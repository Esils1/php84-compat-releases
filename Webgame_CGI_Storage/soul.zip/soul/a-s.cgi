#!/usr/bin/perl

# 환경설정파일
require 'a-s.ini';

#================================================================#
# 여기서부터는 CGI에 자신이 있으신분들만 수정해주시기 바랍니다.  #
#================================================================#

#----------#
# 메인처리 #
#----------#
if($mente) { &error("현재 계산중입니다. 잠시 기다려 주십시오."); }
&decode;
if($mode eq "") { &html_top; }
elsif($mode eq 'log_in') { &log_in; }
elsif($mode eq 'chara_make') { &chara_make; }
elsif($mode eq 'make_end') { &make_end; }
elsif($mode eq 'regist') { &regist; }
elsif($mode eq 'battle') { &battle; }
elsif($mode eq 'monster') { &monster; }
elsif($mode eq 'ranking') { &ranking; }
elsif($mode eq 'inn') { &inn; }
elsif($mode eq 'message') { &message; }
elsif($mode eq 'item_shop') { &item_shop; }
elsif($mode eq 'item_shop1') { &item_shop1; }
elsif($mode eq 'item_buy') { &item_buy; }
elsif($mode eq 'item_sell') { &item_sell; }
elsif($mode eq 'aty_up') { &aty_up; }
elsif($mode eq 'wsk_set') { &wsk_set; }
elsif($mode eq 'ig_pview') { &ig_pview; }
elsif($mode eq 'status2') { &status2; }
elsif($mode eq 'k_stone1') { &k_stone1; }
elsif($mode eq 'k_stone2') { &k_stone2; }
&html_top;

#------------#
# TOP 페이지 #
#------------#
sub html_top {
	&read_winner;
	&get_cookie;

	if($wkati) { $ritu = int(($wkati / $wtotal) * 100); }
	else { $ritu = 0; }

	open(IN,"$recode_file");
	@recode = <IN>;
	close(IN);

	($rcount,$rname,$rsite,$rurl) = split(/<>/,$recode[0]);

	if($wsex) { $esex = "남"; } else { $esex = "여"; }

      if($wlv eq 1){$next_ex=1000;}
      if($wlv eq 2){$next_ex=2000;}
      if($wlv eq 3){$next_ex=4000;}
      if($wlv eq 4){$next_ex=8000;}
      if($wlv eq 5){$next_ex=16000;}
      if($wlv eq 6){$next_ex=32000;}
      if($wlv eq 7){$next_ex=48000;}
      if($wlv eq 8){$next_ex=64000;}
      if($wlv eq 9){$next_ex=80000;}
      if($wlv eq 10){$next_ex=96000;}
      if($wlv eq 11){$next_ex=112000;}
      if($wlv eq 12){$next_ex=128000;}

	if($witem){
		open(IN,"$item_file");
		@battle_item = <IN>;
		close(IN);

		foreach(@battle_item){
			($wi_no,$wi_name,$wi_dmg,$wi_gold,$wi_kind,$wi_wkind,$wi_ref,$wi_cls) = split(/<>/);
			if($witem eq $wi_no) {last;}
		}
	}else{$wi_name="없음";}

	if($witem1){
		open(IN,"$item_file");
		@battle_item = <IN>;
		close(IN);

		foreach(@battle_item){
			($wi_no1,$wi_name1,$wi_dmg,$wi_gold,$wi_kind,$wi_wkind1,$wi_ref,$wi_cls) = split(/<>/);
			if($witem1 eq $wi_no1) { last; }
		}
	}else{ $wi_name1 = "없음"; }

	if($witem2){
		open(IN,"$item_file");
		@battle_item = <IN>;
		close(IN);

		foreach(@battle_item){
			($wi_no2,$wi_name2,$wi_dmg,$wi_gold,$wi_kind,$wi_wkind,$wi_ref,$wi_cls) = split(/<>/);
			if($witem2 eq $wi_no2) { last; }
		}
	}else{ $wi_name2 = "없음"; }

	# 헤더표시
	&header;

	# HTML표시
	print <<"EOM";
<img src=$title_img><p>
<table border=0 width='100%'>
<tr>
<td width="500" valign="top">
	<table width=100% border=1 bordercolordark=white bordercolorlight=black cellspacing=0>
	<tr>
	<td colspan=5 align="center" class="b2"><font color=white>$wcount연승중 <font style=font-size:9pt>&lt연승기록: $rcount연승, $rname(<a href=\"http:\/\/$rurl\" target=\"champ\"><font color=#c2c2c2>$rsite</font></a>)&gt</font></font></td>
	</tr>
	<tr>
	<td align="center" class="b1">HomePage</td>
	<td colspan="4">&nbsp;<a href="http\:\/\/$wurl"><b>$wsite</b></a>
EOM
	if($rurl eq "$wurl") {
		print "<IMG SRC=\"$mark\" border=0>\n";
	}
	print <<"EOM";
	</td>
	</tr>
	<tr>
	<td align="center" rowspan="8" width="30%"><img src="$img_path/$chara_img[$wchara]"><p><font style=font-size:9pt>승률 : $ritu\%<br>무기 : $wi_name<br>방패 : $wi_name1<br>갑옷 : $wi_name2</font></td>
	<td align="center" class="b1" width="15%">이름</td><td width="17%"><b>$wname</b></td>
	<td align="center" class="b1">종족(성별)</td><td><b>$chara_race[$wrace]($esex)</b></td>
	</tr>
	<tr>
	<td align="center" class="b1">직업</td><td><b>$chara_class[$wclass]</b></td>
	<td align="center" class="b1">돈<td><b>$wgold</b></td>
	</tr>
	<tr>
	<td align="center" class="b1">레벨</td><td><b>$wlv</b></td>
	<td align="center" class="b1">경험치</td><td><b>$wex/$next_ex</b></td>
	</tr>
	<tr>
	<td align="center" class="b1">HP</td><td><b>$whp\/$wmaxhp</b></td>
	<td align="center" class="b1">MP</td><td><b>$wmp\/$wmaxmp</b></td>
	</tr>
	<tr>
	<td align="center" class="b1">힘</td><td><b>$wn_0</b></td>
	<td align="center" class="b1">생명력</td><td><b>$wn_1</b></td>
	</tr>
	<tr>
	<td align="center" class="b1">민첩</td><td><b>$wn_2</b></td>
	<td align="center" class="b1">기술</td><td><b>$wn_3</b></td>
	</tr>
	<tr>
	<td align="center" class="b1">지능</td><td><b>$wn_4</b></td>
	<td align="center" class="b1">매력</td><td><b>$wn_5</b></td>
	</tr>
	<tr>
	<td align="center" class="b1">행운</td><td><b>$wn_6</b></td>
	<td align="center" class="b1">집중력</td><td><b>$wwab_2</b></td>
	</tr>
	<tr>
	<td colspan=5 align="center">$lname 의 <A HREF=\"http\:\/\/$lurl\" TARGET=\"_blank\">$lsite</A> 에게 승리!</td>
	</tr>
	</table>
</td>
<td valign="top" class=small>
[<B><FONT COLOR="#FF9933">$main_title 공지사항</FONT></B>]<br>
&nbsp;◆&nbsp;$notice0<br>
&nbsp;◆&nbsp;$notice1<br>
&nbsp;◆&nbsp;$notice2<br>
&nbsp;◆&nbsp;$notice3<br>
&nbsp;◆&nbsp;$notice4<br>
&nbsp;◆&nbsp;$notice5<br>
&nbsp;◆&nbsp;$notice6<br>
&nbsp;◆&nbsp;$notice7<br>
&nbsp;◆&nbsp;$notice8<br>
&nbsp;◆&nbsp;$notice9<p>
<font style=font-size:9pt>
<a href="$script?mode=item_shop">아이템상점</a> / <a href="$script?mode=item_shop1">골동품상점</a> / <a href="$script?mode=k_stone1">자살바위</a> / <a href="$script?mode=ranking">영웅들의 기록</a> / <a href="$rule_htm">게임의 룰</a> /</font><p>
<table border=0><tr><td>
<form action=$script method=POST>
<input type=hidden name=mode value=log_in>
<font style=font-size:9pt>I D</font>&nbsp;<input type="text" size="10" name="id" value="$c_id" style="border-style:none;border-bottom:1px solid gray">&nbsp;<font style=font-size:9pt>Password</font>&nbsp;<input type="password" size="10" name="pass" style="border-style:none;border-bottom:1px solid gray">&nbsp;
<input type="submit" value="Log In" style='font-size:9pt;background-color:gray;border-style:none;width:70;height:20;color:white;font-family:tahoma'></form>
</td><td>
<form action=$script method=POST>
<input type="hidden" name="mode" value="chara_make">
<input type="submit" value="캐릭터 작성" style='font-size:9pt;background-color:gray;border-style:none;width:80;height:20;color:white;font-family:tahoma'></form>
</td></tr></table>
</td>
</tr>
</table>
</font>
EOM
	# Footer 표시
	&footer;
	exit;
}

#------#
# 랭킹 #
#------#
sub ranking {
	open(IN,"$chara_file");
	@RANKING = <IN>;
	close(IN);
	$ranrank = @RANKING;
	@tmp1 = @tmp2 = ();
	foreach (@RANKING) {
 		my ($aa,$bb,$cc,$dd,$ee,$ff,$gg,$hh,$ii,$jj,$kk,$ll,$mm,$nn,$oo,$pp,$qq,$rr,$ss,$tt,$second,$first) = split /<>/;
 		push(@tmp1, $first);
 		push(@tmp2, $second);
	}
	@RANKING = @RANKING[sort {$tmp1[$b] <=> $tmp1[$a] or
			$tmp2[$b] <=> $tmp2[$a]} 0 .. $#tmp1];
	$ima = time();
	&header;
	print <<"EOM";
<img src="$title2"><br>
<hr size=0><br>
<center><font style=font-size:9pt>현재 등록되어 있는 캐릭터 <b>$ranrank</b>명중 레벨TOP <b>$rank_top</b>을 표시합니다.</font><p></center>
<table border=1 cellspacing=0 bordercolordark=white bordercolorlight=black align=center width=700>
<tr align=center bgcolor=#cecece>
<td>&nbsp;</td><td><font style=font-size:9pt>이 름</font></td><td><font style=font-size:9pt>직업</font></td><td><font style=font-size:9pt>Homepage</font></td><td><font style=font-size:9pt>레벨</font></td><td><font style=font-size:9pt>경험치</font></td><td><font style=font-size:9pt>HP</font></td><td><font style=font-size:9pt>삭제까지</font></td>
</tr>
EOM
	$i=1;
	foreach(@RANKING){
		($rid,$rpass,$rsite,$rurl,$rname,$rsex,$rchara,$rn_0,$rn_1,$rn_2,$rn_3,$rn_4,$rn_5,$rn_6,$rrace,$rclass,$rhp,$rmaxhp,$rmp,$rmaxmp,$rex,$rlv,$rgold,$rtotal,$rkati,$ritem,$ritem1,$ritem2,$rmons,$rhost,$rdate,$rwab_0,$rwab_1,$rwab_2,$rab_0,$rab_1,$rab_2,$rab_3,$rab_4,$rab_5,$rab_6,$rab_7,$rab_8,$rab_9,$rab_10,$rabpint,$rwskill,$rwskiti) = split(/<>/);
		if($i > $rank_top) { last; }
		$rdate = $rdate + (60*60*24*$limit);
		$niti = $rdate - $ima;
		$niti = int($niti / (60*60*24));
		print "<tr align=center>\n";
		print "<td><font style=font-size:9pt>$i</font></td><td><font style=font-size:9pt>$rname</font></td><td><font style=font-size:9pt>$chara_class[$rclass]</font></td><td><a href=\"http\:\/\/$rurl\"><font style=font-size:9pt>$rsite</font></a></td><td align=center><font style=font-size:9pt>$rlv</font></td><td align=center><font style=font-size:9pt>$rex</font></td><td align=center><font style=font-size:9pt>$rhp\/$rmaxhp</font></td><td align=center><font style=font-size:9pt>앞으로 $niti일</font></td>\n";
		print "</tr>\n";
		$i++;
	}
	print "</table><p>\n";
	&footer;
	exit;
}

#----------------#
#   아이템표시   #
#----------------#
sub item_shop {
	open(IN,"$item_file");
	@item_array = <IN>;
	close(IN);

	&header;

	print <<"EOM";
<img src="$title1"><br>
<hr size=0><br>
<form action="$script" method="post">
<center><font style=font-size:9pt>사고 싶은 아이템에 체크한 후, 당신의 ID와 Password를 입력해 주십시오. 매력에 따른 할인율이 적용되지 않은 상태입니다.<br>
(직업 약칭 F:전사,K:기사,T:도적,C:성직자,M:마법사,H:정령사)</font></center>
<table border=1 cellspacing=0 cellpadding=0 align=center width=700 bordercolordark=white bordercolorlight=black>
<tr align=center bgcolor=#cecece>
<td bgcolor=#716262><font size=2 color=white><b>무기</b></font></td><td><font style=font-size:9pt>이 름</font></td><td><font style=font-size:9pt>위력</font></td><td><font style=font-size:9pt>분류</font></td><td><font style=font-size:9pt>가격</font></td><td><font style=font-size:9pt>사용가능직업</font></td>
<td>&nbsp;</td></td><td><font style=font-size:9pt>이 름</font></td><td><font style=font-size:9pt>위력</font></td><td><font style=font-size:9pt>분류</font></td><td><font style=font-size:9pt>가격</font></td><td><font style=font-size:9pt>사용가능직업</font></td>
</tr>
EOM
      $lchz=0;$i=0;$y=0;
	foreach(@item_array){
		($ino,$iname,$idmg,$igold,$i_kind,$i_wkind,$i_ref,$i_cls) = split(/<>/);
            #아이템 세부 출력하기 위한 변형 분류
            ($i_wkind,$i_whand) = split(/a/,$i_wkind);
            if($i_whand == 1) {$tmp2="한손";}else{$tmp2="양손";}
            if($i_kind == 1){
              ($indmg,$tmp1) = split(/p/,$idmg);
            }elsif($i_kind == 2){
              $tmp2="갑옷";
              if($y == 0){$i=1;}
            }elsif($i_kind == 3){
              $tmp2="방패";
              if($i == 2){$y=0;$i=3;}
            }

            if(($i == 1 & $y == 0) || ($i == 3 & $y == 0)){
              print "</tr></table><br><table border=1 cellspacing=0 align=center width=700 bordercolordark=white bordercolorlight=black>\n";$lchz=0;
              if($i == 1){$i=2;$y=1;}
              if($i == 3){$i=4;$y=1;}
              print "<tr align=center bgcolor=#cecece>\n";
              print "<td bgcolor=#716262><font size=2 color=white><b>$tmp2</b></font></td><td><font style=font-size:9pt>이 름</font></td><td><font style=font-size:9pt>AV</font></td><td><font style=font-size:9pt>가격</font></td><td><font style=font-size:9pt>사용가능직업</font></td>\n";
              print "<td>&nbsp;</td></td><td><font style=font-size:9pt>이 름</font></td><td><font style=font-size:9pt>AV</font></td><td><font size=2>가격</font></td><td><font style=font-size:9pt>사용가능직업</font></td></tr>\n";
            }
		if(($lchz == 0 & $i == 0) || ($lchz == 0 & $i == 2) || ($lchz == 0 & $i == 4)){print "<tr align=center>\n";}

            $tmp3="FKTCMH";
            if($i_cls == 1){$tmp3="FKTCH";}
            elsif($i_cls == 2){$tmp3="FKTC";}
            elsif($i_cls == 3){$tmp3="FKC";}
            elsif($i_cls == 4){$tmp3="FKTH";}
            elsif($i_cls == 5){$tmp3="T";}
            elsif($i_cls == 6){$tmp3="FKCH";}
             if($i_kind == 1){
               print "<td><input type=radio name=item_no value=\"$ino\"></td><td><font style=font-size:9pt>$iname</font></td><td><font style=font-size:9pt>$indmg+$tmp1</font></td><td><font style=font-size:9pt>$tmp2</font></td><td><font style=font-size:9pt>$igold</font></td><td><font style=font-size:9pt>$tmp3</font></td>\n";
               if($lchz < 2){$lchz++;}
             }
             elsif($i_kind == 3){
               print "<td><input type=radio name=item_no value=\"$ino\"></td><td><font style=font-size:9pt>$iname</font></td><td><font style=font-size:9pt>$idmg/$i_ref%</font></td><td><font style=font-size:9pt>$igold</font></td><td><font style=font-size:9pt>$tmp3</font></td>\n";
               if($lchz < 2){$lchz++;}
             }else{
               print "<td><input type=radio name=item_no value=\"$ino\"></td><td><font style=font-size:9pt>$iname</font></td><td><font style=font-size:9pt>$idmg</font></td><td><font style=font-size:9pt>$igold</font></td><td><font style=font-size:9pt>$tmp3</font></td>\n";
               if($lchz < 2){$lchz++;}
             }
		if($lchz == 2){print "</tr>\n";$lchz=0;}
	}
	print <<"EOM";

</table>
<p align=center>
ID : <input type=text name=id size=10 style="border-style:none;border-bottom:1px solid gray">
PASS : <input type=password name=pass size=10 style="border-style:none;border-bottom:1px solid gray">
<input type=hidden name=mode value=item_buy>
<input type=submit value="아이템 구입" style='font-size:9pt;background-color:gray;border-style:none;width:100;height:20;color:white;font-family:tahoma'>
</p>
</form>
EOM
	&footer;
	exit;
}

#----------------#
#    물품구입    #
#----------------#
sub item_buy {
	if($in{'id'} eq "") {
		&error("ID가 잘못되었습니다.");
	}elsif($in{'pass'} eq ""){
		&error("암호가 잘못되었습니다.");
	}elsif($in{'item_no'} eq ""){
		&error("아이템이 선택되지 않았습니다.");
	}
	$item_id = $in{'id'};
	$item_pass = $in{'pass'};

	open(IN,"$item_file");
	@item_array = <IN>;
	close(IN);

      $hit=0;
      foreach(@item_array){
	 ($i_no,$i_name,$i_dmg,$i_gold,$i_kind,$i_wkind,$i_ref,$i_cls) = split(/<>/);
	 if($in{'item_no'} eq "$i_no") { $hit=1;last; }
	}
	if(!$hit) { &error("존재하지 않는 아이템입니다."); }

	&get_host;

	$date = time();

	# Lock 파일
	if ($lockkey eq 1) { &lock1; }
	elsif ($lockkey eq 2) { &lock2; }
	elsif ($lockkey eq 3) { &file'lock; }

	open(IN,"$chara_file");
	@item_chara = <IN>;
	close(IN);

	$hit=0;@item_new=();$buyno=0;
	foreach(@item_chara){
        ($iid,$ipass,$isite,$iurl,$iname,$isex,$ichara,$in_0,$in_1,$in_2,$in_3,$in_4,$in_5,$in_6,$irace,$iclass,$ihp,$imaxhp,$imp,$imaxmp,$iex,$ilv,$igold,$itotal,$ikati,$iitem,$iitem1,$iitem2,$imons,$ihost,$idate,$iwab_0,$iwab_1,$iwab_2,$iab_0,$iab_1,$iab_2,$iab_3,$iab_4,$iab_5,$iab_6,$iab_7,$iab_8,$iab_9,$iab_10,$iabpint,$iwskill,$iwskiti) = split(/<>/);
        if($iid eq "$item_id" & $ipass eq "$item_pass") {
            if($i_cls == 1 & $iclass == 1){$buyno=1;}
            elsif($i_cls == 2 & ($iclass == 1 || $iclass == 5)){$buyno=1;}
            elsif($i_cls == 3 & ($iclass == 1 || $iclass == 3 || $iclass == 5)){$buyno=1;}
            elsif($i_cls == 4 & ($iclass == 1 || $iclass == 2)){$buyno=1;}
            elsif($i_cls == 5 & $iclass != 3){$buyno=1;}
            elsif($i_cls == 6 & ($iclass == 1 || $iclass == 3)){$buyno=1;}
            if($buyno){
                  &error("이 직업은 사용할 수 없는 아이템입니다.");
            }else{
                  #매력에 따른 할인율
                  if($in_5>=7 & $in_5<=12) {$i_gold -= int($i_gold*0.05);}
                  elsif($in_5>=13 & $in_5<=18) {$i_gold -= int($i_gold*0.1);}
                  elsif($in_5>=19 & $in_5<=21) {$i_gold -= int($i_gold*0.15);}
                  elsif($in_5>=22) {$i_gold -= int($i_gold*0.2);}
                  if($igold < $i_gold) { &error("돈이 부족합니다."); } else { $igold -= $i_gold; }

                  ($i_wkind,$i_whand) = split(/a/,$i_wkind);
                  if($i_kind == 1 & $i_whand == 2){$iitem=$i_no;$iitem1=0;}
              	elsif($i_kind == 1){$iitem=$i_no;}
                  elsif($i_kind == 2){$iitem2=$i_no;}
                  elsif($i_kind == 3){
                    if($iclass == 1){&error("이 직업은 방패를 착용할 수 없습니다.");}

                    foreach(@item_array){
                      ($i_no,$temp1,$temp1,$temp1,$temp1,$i_wkind,$temp1,$temp1) = split(/<>/);
                	    if($iitem eq "$i_no") { last; }
                    }
                    ($i_wkind,$i_whand) = split(/a/,$i_wkind);
                    if($i_whand == 2) { $iitem=0; }
                    $iitem1=$i_no;
                  }
                  unshift(@item_new,"$iid<>$ipass<>$isite<>$iurl<>$iname<>$isex<>$ichara<>$in_0<>$in_1<>$in_2<>$in_3<>$in_4<>$in_5<>$in_6<>$irace<>$iclass<>$ihp<>$imaxhp<>$imp<>$imaxmp<>$iex<>$ilv<>$igold<>$itotal<>$ikati<>$iitem<>$iitem1<>$iitem2<>$imons<>$host<>$idate<>$iwab_0<>$iwab_1<>$iwab_2<>$iab_0<>$iab_1<>$iab_2<>$iab_3<>$iab_4<>$iab_5<>$iab_6<>$iab_7<>$iab_8<>$iab_9<>$iab_10<>$iabpint<>$iwskill<>$iwskiti<>\n");
			$hit=1;
            }
        }else{
			push(@item_new,"$_");
        }
	}

	if(!$hit) { &error("해당 캐릭터를 찾을 수 없습니다."); }

	open(OUT,">$chara_file");
	print OUT @item_new;
	close(OUT);

	# Lock 해제
	if ($lockkey eq 3) { &file'unlock; }
	else { if(-e $lockfile) { unlink($lockfile); } }

	&header;

	print <<"EOM";
<img src="$title1"><br>
<hr size=0><br>
<form action="$script" method="post">
<input type=hidden name=id value="$item_id">
<input type=hidden name=pass value="$item_pass">
<input type=hidden name=mode value=log_in>
<center>아이템을 구입하였습니다.<input type=submit value="To Status" style='font-size:9pt;background-color:gray;border-style:none;width:100;height:20;color:white;font-family:tahoma'></center>
</form>
EOM
	&footer;
	exit;
}

#----------------#
#  골동품상점    #
#----------------#
sub item_shop1 {
      &header;

      print <<"EOM";
<img src="$title1"><br>
<hr size=0><br>
<form action="$script" method="post">
<center><font style=font-size:9pt>팔고자 하는 아이템을 선택해주세요.</font></center>
<table border=1 cellspacing=0 cellpadding=0 align=center width=300 bordercolordark=white bordercolorlight=black>
<tr align=center bgcolor=#cecece>
<td><font size=2 color=white><b>무 기</b></font></td>
<td><font size=2 color=white><b>방 패</b></font></td>
<td><font size=2 color=white><b>갑 옷</b></font></td>
</tr>
<tr align=center>
<td><input type=radio name=sell_item value=1></td>
<td><input type=radio name=sell_item value=2></td>
<td><input type=radio name=sell_item value=3></td>
</tr></table><p>
<p align=center>
ID : <input type=text name=id size=10 style="border-style:none;border-bottom:1px solid gray">
PASS : <input type=password name=pass size=10 style="border-style:none;border-bottom:1px solid gray">
<input type=hidden name=mode value=item_sell>
<input type=submit value="아이템 판매" style='font-size:9pt;background-color:gray;border-style:none;width:100;height:20;color:white;font-family:tahoma'>
</p></form>
EOM
	&footer;
	exit;
}

#----------------#
#    물품판매    #
#----------------#
sub item_sell {
	if($in{'id'} eq "") {
		&error("ID가 잘못되었습니다.");
	}elsif($in{'pass'} eq ""){
		&error("암호가 잘못되었습니다.");
	}elsif($in{'sell_item'} eq ""){
		&error("아이템이 선택되지 않았습니다.");
	}
	$item_id = $in{'id'};
	$item_pass = $in{'pass'};

	&get_host;

	$date = time();

	# Lock 파일
	if ($lockkey eq 1) { &lock1; }
	elsif ($lockkey eq 2) { &lock2; }
	elsif ($lockkey eq 3) { &file'lock; }

	open(IN,"$chara_file");
	@item_chara = <IN>;
	close(IN);

   	open(IN,"$item_file");
	@item_array = <IN>;
	close(IN);

	$hit1=0;@item_new=();
	foreach(@item_chara){
        ($iid,$ipass,$isite,$iurl,$iname,$isex,$ichara,$in_0,$in_1,$in_2,$in_3,$in_4,$in_5,$in_6,$irace,$iclass,$ihp,$imaxhp,$imp,$imaxmp,$iex,$ilv,$igold,$itotal,$ikati,$iitem,$iitem1,$iitem2,$imons,$ihost,$idate,$iwab_0,$iwab_1,$iwab_2,$iab_0,$iab_1,$iab_2,$iab_3,$iab_4,$iab_5,$iab_6,$iab_7,$iab_8,$iab_9,$iab_10,$iabpint,$iwskill,$iwskiti) = split(/<>/);
        if($iid eq "$item_id" & $ipass eq "$item_pass") {
           if($in{'sell_item'} == 1){$temp2=$iitem;}
           elsif($in{'sell_item'} == 2){$temp2=$iitem1;}
           elsif($in{'sell_item'} == 3){$temp2=$iitem2;}
           $hit=0;
           foreach(@item_array){
            ($i_no,$temp1,$temp1,$i_gold,$temp1,$temp1,$temp1,$temp1) = split(/<>/);
            if($temp2 eq "$i_no") { $hit=1;last; }
           }
           if(!$hit) { &error("존재하지 않는 아이템입니다."); }
           $sell_gold=int($i_gold/2);
           if($in_5>=7 & $in_5<=12) {$sell_gold += int($i_gold*0.05);}
           elsif($in_5>=13 & $in_5<=18) {$sell_gold += int($i_gold*0.1);}
           elsif($in_5>=19 & $in_5<=21) {$sell_gold += int($i_gold*0.15);}
           elsif($in_5>=22) {$sell_gold += int($i_gold*0.2);}
           $igold+=$sell_gold;
           if($in{'sell_item'} == 1){$iitem=0;}
           elsif($in{'sell_item'} == 2){$iitem1=0;}
           elsif($in{'sell_item'} == 3){$iitem2=0;}
           unshift(@item_new,"$iid<>$ipass<>$isite<>$iurl<>$iname<>$isex<>$ichara<>$in_0<>$in_1<>$in_2<>$in_3<>$in_4<>$in_5<>$in_6<>$irace<>$iclass<>$ihp<>$imaxhp<>$imp<>$imaxmp<>$iex<>$ilv<>$igold<>$itotal<>$ikati<>$iitem<>$iitem1<>$iitem2<>$imons<>$host<>$idate<>$iwab_0<>$iwab_1<>$iwab_2<>$iab_0<>$iab_1<>$iab_2<>$iab_3<>$iab_4<>$iab_5<>$iab_6<>$iab_7<>$iab_8<>$iab_9<>$iab_10<>$iabpint<>$iwskill<>$iwskiti<>\n");
           $hit1=1;
        }else{
			push(@item_new,"$_");
        }
	}
	if(!$hit1) { &error("해당 캐릭터를 찾을 수 없습니다."); }

	open(OUT,">$chara_file");
	print OUT @item_new;
	close(OUT);

	# Lock 해제
	if ($lockkey eq 3) { &file'unlock; }
	else { if(-e $lockfile) { unlink($lockfile); } }

	&header;

	print <<"EOM";
<img src="$title1"><br>
<hr size=0><br>
<form action="$script" method="post">
<input type=hidden name=id value="$item_id">
<input type=hidden name=pass value="$item_pass">
<input type=hidden name=mode value=log_in>
<center>$sell_gold GP에 아이템을 판매하였습니다.<input type=submit value="To Status" style='font-size:9pt;background-color:gray;border-style:none;width:100;height:20;color:white;font-family:tahoma'></center>
</form>
EOM
	&footer;
	exit;
}

#------------#
#   HP회복   #
#------------#
sub inn {
	&get_host;

	$date = time();

	# Lock 파일
	if ($lockkey eq 1) { &lock1; }
	elsif ($lockkey eq 2) { &lock2; }
	elsif ($lockkey eq 3) { &file'lock; }

	open(IN,"$chara_file");
	@INN = <IN>;
	close(IN);

	$hit=0;@inn_new=();
	foreach(@INN){
	($yid,$ypass,$ysite,$yurl,$yname,$ysex,$ychara,$yn_0,$yn_1,$yn_2,$yn_3,$yn_4,$yn_5,$yn_6,$yrace,$yclass,$yhp,$ymaxhp,$ymp,$ymaxmp,$yex,$ylv,$ygold,$ytotal,$ykati,$yitem,$yitem1,$yitem2,$ymons,$yhost,$ydate,$ywab_0,$ywab_1,$ywab_2,$yab_0,$yab_1,$yab_2,$yab_3,$yab_4,$yab_5,$yab_6,$yab_7,$yab_8,$yab_9,$yab_10,$yabpint,$ywskill,$ywskiti) = split(/<>/);
		if($in{'id'} eq "$yid") {
			$inn_gold = $inn_gld * $ylv;
			#매력에 따른 할인율
		    if($yn_5>=7 & $yn_5<=12) {$inn_gold -= int($inn_gold*0.05);}
		    elsif($yn_5>=13 & $yn_5<=18) {$inn_gold -= int($inn_gold*0.1);}
		    elsif($yn_5>=19 & $yn_5<=21) {$inn_gold -= int($inn_gold*0.15);}
		    elsif($yn_5>=22) {$inn_gold -= int($inn_gold*0.2);}
			if($ygold < $inn_gold) { &error("돈이 부족합니다."); } else { $ygold -= $inn_gold; }
			unshift(@inn_new,"$yid<>$ypass<>$ysite<>$yurl<>$yname<>$ysex<>$ychara<>$yn_0<>$yn_1<>$yn_2<>$yn_3<>$yn_4<>$yn_5<>$yn_6<>$yrace<>$yclass<>$ymaxhp<>$ymaxhp<>$ymaxmp<>$ymaxmp<>$yex<>$ylv<>$ygold<>$ytotal<>$ykati<>$yitem<>$yitem1<>$yitem2<>$ymons<>$yhost<>$ydate<>$ywab_0<>$ywab_1<>$ywab_2<>$yab_0<>$yab_1<>$yab_2<>$yab_3<>$yab_4<>$yab_5<>$yab_6<>$yab_7<>$yab_8<>$yab_9<>$yab_10<>$yabpint<>$ywskill<>$ywskiti<>\n");
		}else{
			push(@inn_new,"$_");
		}
	}

	open(OUT,">$chara_file");
	print OUT @inn_new;
	close(OUT);

	&read_winner;

	if($in{'id'} == "$wid") {
		open(OUT,">$winner_file");
		print OUT "$wid<>$wpass<>$wsite<>$wurl<>$wname<>$wsex<>$wchara<>$wn_0<>$wn_1<>$wn_2<>$wn_3<>$wn_4<>$wn_5<>$wn_6<>$wrace<>$wclass<>$whp<>$wmaxhp<>$wmp<>$wmaxmp<>$wex<>$wlv<>$wgold<>$wtotal<>$wkati<>$witem<>$witem1<>$witem2<>$wmons<>$whost<>$wdate<>$wwab_0<>$wwab_1<>$wwab_2<>$wab_0<>$wab_1<>$wab_2<>$wab_3<>$wab_4<>$wab_5<>$wab_6<>$wab_7<>$wab_8<>$wab_9<>$wab_10<>$wwskill<>$wwskiti<>$wcount<>$lsite<>$lurl<>$lname<>\n";
		close(OUT);
	}

	# Lock 해제
	if ($lockkey eq 3) { &file'unlock; }
	else { if(-e $lockfile) { unlink($lockfile); } }

	&header;

	print <<"EOM";
<img src="$title4"><br>
<hr size=0><br>
<form action="$script" method="post">
<input type=hidden name=mode value=log_in>
<input type=hidden name=id value="$in{'id'}">
<input type=hidden name=pass value="$in{'pass'}">
<center>
HP가 회복되었습니다. <input type=submit value="To Status" style='font-size:9pt;background-color:gray;border-style:none;width:100;height:20;color:white;font-family:tahoma'></center>
</form>
EOM
	&footer;
	exit;
}

#----------------------#
#   신규 캐릭터 작성
#----------------------#
sub chara_make {
	# 헤더표시
	&header;
	print <<"EOM";
<img src="$title3"><br>
<hr size=0><br>
<form action="$script" method="post">
<input type="hidden" name="mode" value="make_end">
<table border=1 cellspacing=0 bordercolordark=white bordercolorlight=black>
<tr>
<td class="b1">능력치</td>
<td align=center>
	<table border=1 cellspacing=0 bordercolordark=white bordercolorlight=black>
	<tr class="b1" align=center>
	<td width="50">힘</td><td width="50">생명력</td><td width="50">민첩</td><td width="50">기술</td><td width="50">지능</td><td width="50">매력</td><td width="50">행운</td>
	</tr>
	<tr>
EOM
      $ii=0;
      foreach(0..6) {
            foreach(1..3) { $in{'n_$ii'} += int(rand(6))+1; }
       print "<td width=50 align=center>$in{'n_$ii'}</td>";
       print "<input type=hidden name=n_$ii value=$in{'n_$ii'}>";
      $ii++;
      $in{'n_$ii'}=0;
      }
	print <<"EOM";
	</tr>
	</table>
<font style=font-size:9pt>◇ 캐릭터의 능력치입니다. 해당 종족에 따른 패널티 및 보너스가 적용됩니다.<br>
만약 이 능력치를 원치 않으신다면 브라우저의 <b>새로고침</b>을 눌러 화면을 갱신하십시요.<br>
</font>
</td>
</tr>
<tr>
<td class="b1">ID</td>
<td><input type="text" name="id" size="10"><br><font style=font-size:9pt>◇ 영문자,숫자로 4~8문자이내로 작성하여 주세요.</font></td>
</tr>
<tr>
<td class="b1">Password</td>
<td><input type="password" name="pass" size="10"><br><font style=font-size:9pt>◇ 영문자,숫자로 4~8문자이내로 작성하여 주세요.<br>암호화 되지 않습니다. 운영자가 악용하는 일은 없겠지만, 만약을 위해 자주 사용하지 않는것으로 해주세요.</font></td>
</tr>
<tr>
<td class="b1">Homepage</td>
<td><input type="text" name="site" size="40"><br><font style=font-size:9pt>◇ 홈페이지명를 입력해 주세요.</font></td>
</tr>
<tr>
<td class="b1">URL</td>
<td><input type="text" name="url" size="50" value="http://"><br><font style=font-size:9pt>◇ 홈페이지의 URL을 입력해 주세요.</font></td>
</tr>
<tr>
<td class="b1">이름</td>
<td><input type="text" name="c_name" size="30"><br><font style=font-size:9pt>◇ 캐릭터의 이름을 입력해주세요.</font></td>
</tr>
<tr>
<td class="b1">성별</td>
<td><input type="radio" name="sex" value="1">남<input type="radio" name="sex" value="0">여<br><font style=font-size:9pt>◇ 캐릭터의 성별을 선택해주세요.</font></td>
</tr>
<tr>
<td class="b1">이미지 선택</td>
<td><select name="chara">
EOM
	$i=0;
	foreach(@chara_name){
		print "<option value=\"$i\">$chara_name[$i]\n";
		$i++;
	}
	print <<"EOM";
</select>&nbsp;&nbsp;<font style=font-size:9pt><a href="$script?mode=ig_pview" target="imgpview">이미지 미리보기</a></font><br><font style=font-size:9pt>◇ 캐릭터의 이미지를 선택해주세요.</font></td>
</tr>
<tr>
<td class="b1">종족 선택</td>
<td><select name="race">
EOM
      $i=0;
      foreach(@chara_race){
		print "<option value=\"$i\">$chara_race[$i]\n";
		$i++;
	}
	print <<"EOM";
</select><br><font style=font-size:9pt>◇ 캐릭터의 종족을 선택해주세요.</font></td>
</tr>
<tr>
<td colspan="2" align="center"><input type="submit" value="다음" style='font-size:9pt;background-color:gray;border-style:none;width:100;height:20;color:white;font-family:tahoma'></td>
</tr>
</table>
</form>
EOM
	# Footer표시
	&footer;
	exit;
}

#-----------------#
# 이미지 미리보기 #
#-----------------#
sub ig_pview {
	# 헤더표시
	&header;
      print "<table border=1 cellspacing=0 cellpadding=0 align=center>\n";
      print "<tr align=center>\n";
	$i=0;$y=0;
	foreach(@chara_name){
            if($y == 8){print "</tr><tr align=center>\n";$y=0;}
		print "<td><img src=\"$img_path/$chara_img[$i]\"><br><font size=2 face=tahoma>$chara_name[$i]</font></td>\n";
		$i++;
            $y++;
	}
      print "</tr></table>\n";
      print "</body></html>\n";
	exit;
}

#----------------#
#    등록완료    #
#----------------#
sub make_end {
	if($chara_stop){ &error("현재는 등록이 안됩니다."); }
	if ($in{'id'} =~ m/[^0-9a-zA-Z]/){&error("ID가 잘못된 형식입니다."); }
	if ($in{'pass'} =~ m/[^0-9a-zA-Z]/){&error("암호가 잘못된 형식입니다."); }
	# 직업선택안하면
		if($in{'class'} eq "") {
		if($in{'id'} eq "" or length($in{'id'}) < 4 or length($in{'id'}) > 8) { &error("ID는 영문자,숫자로 4~8자이내이어야 합니다."); }
		elsif($in{'pass'} eq "" or length($in{'pass'}) < 4 or length($in{'pass'}) > 8) { &error("암호는 영문자,숫자로 4~8자이내이어야 합니다."); }
		elsif($in{'site'} eq "") { &error("홈페이지명이 입력되지 않았습니다."); }
		elsif($in{'url'} eq "") { &error("홈페이지주소가 입력되지 않았습니다."); }
		elsif($in{'c_name'} eq "") { &error("이름이 입력되지 않았습니다."); }
		elsif($in{'sex'} eq "") { &error("성별이 선택되지 않았습니다."); }

            #선택한 종족에 따른 보너스,패널티 적용

            if ($in{'race'} == 0) {$in{'n_0'}+=2;$in{'n_4'}+=1;$in{'n_6'}+=3; }
            if ($in{'race'} == 1) {$in{'n_0'}-=2;$in{'n_1'}-=2;$in{'n_2'}+=2;$in{'n_4'}+=2;$in{'n_5'}+=3;$in{'n_6'}-=2;}
            if ($in{'race'} == 2) {$in{'n_1'}-=1;$in{'n_2'}+=1;$in{'n_4'}+=1;$in{'n_5'}+=2;$in{'n_6'}-=1;}
            if ($in{'race'} == 3) {$in{'n_0'}+=4;$in{'n_1'}+=3;$in{'n_2'}-=2;$in{'n_3'}+=1;$in{'n_5'}-=2;$in{'n_6'}+=1;}
            if ($in{'race'} == 4) {$in{'n_0'}-=1;$in{'n_2'}+=2;$in{'n_3'}+=2;$in{'n_4'}+=1;$in{'n_5'}+=1;$in{'n_6'}-=1;}

		&header;

            #종족에 따른 선택가능한 직업리스트 출력

            print "<img src=\"$title3\"><br>\n";
            print "<hr size=0><br>\n";
		print "<font style=font-size:9pt>◇ 캐릭터의 직업을 선택해주세요.</font><p>\n";
		print "<form action=\"$script\" method=\"post\">\n";
		print "<input type=hidden name=mode value=regist>\n";
		print "<select name=class>\n";
		print "<option value=0>$chara_class[0]\n";

            if ($in{'race'} eq 0) {
               print "<option value=1>$chara_class[1]\n";
               print "<option value=2>$chara_class[2]\n";
               print "<option value=3>$chara_class[3]\n";
               print "<option value=4>$chara_class[4]\n";
               print "<option value=5>$chara_class[5]\n";
            }
            if ($in{'race'} eq 1) {
               print "<option value=3>$chara_class[3]\n";
               print "<option value=5>$chara_class[5]\n";
            }
            if ($in{'race'} eq 2) {
               print "<option value=2>$chara_class[2]\n";
               print "<option value=3>$chara_class[3]\n";
            }
            if ($in{'race'} eq 3) {
               print "<option value=1>$chara_class[1]\n";
               print "<option value=2>$chara_class[2]\n";
               print "<option value=3>$chara_class[3]\n";
               print "<option value=5>$chara_class[5]\n";
            }
            if ($in{'race'} eq 4) {
               print "<option value=3>$chara_class[3]\n";
               print "<option value=5>$chara_class[5]\n";
            }
		print "</select>\n";

		print "<input type=hidden name=new value=new>\n";
		print "<input type=hidden name=id value=\"$in{'id'}\">\n";
		print "<input type=hidden name=pass value=\"$in{'pass'}\">\n";
		print "<input type=hidden name=site value=\"$in{'site'}\">\n";
		print "<input type=hidden name=url value=\"$in{'url'}\">\n";
		print "<input type=hidden name=c_name value=\"$in{'c_name'}\">\n";
		print "<input type=hidden name=sex value=\"$in{'sex'}\">\n";
		print "<input type=hidden name=chara value=\"$in{'chara'}\">\n";
		print "<input type=hidden name=n_0 value=\"$in{'n_0'}\">\n";
		print "<input type=hidden name=n_1 value=\"$in{'n_1'}\">\n";
		print "<input type=hidden name=n_2 value=\"$in{'n_2'}\">\n";
		print "<input type=hidden name=n_3 value=\"$in{'n_3'}\">\n";
		print "<input type=hidden name=n_4 value=\"$in{'n_4'}\">\n";
		print "<input type=hidden name=n_5 value=\"$in{'n_5'}\">\n";
		print "<input type=hidden name=n_6 value=\"$in{'n_6'}\">\n";
		print "<input type=hidden name=race value=\"$in{'race'}\">\n";
		print "<input type=submit value=\"선택\" style='font-size:9pt; background-color:gray; border-style:none; width:100; height:20;color:white;font-family:tahoma'></form>\n";
		&footer;
		exit;
	}else{
            if($in{'sex'}) {$esex = "남";}else{$esex = "여";}
            if($lv eq 1) {$next_ex=1000;}
            if($lv eq 2) {$next_ex=2000;}
            if($lv eq 3) {$next_ex=4000;}
            if($lv eq 4) {$next_ex=8000;}
            if($lv eq 5) {$next_ex=16000;}
            if($lv eq 6) {$next_ex=32000;}
            if($lv eq 7) {$next_ex=48000;}
            if($lv eq 8) {$next_ex=64000;}
            if($lv eq 9) {$next_ex=80000;}
            if($lv eq 10) {$next_ex=96000;}
            if($lv eq 11) {$next_ex=112000;}
            if($lv eq 12) {$next_ex=128000;}

		&header;

		print <<"EOM";
아래의 내용이 지금까지 입력하신 내용입니다.<br>
<hr size=0>
<br>
<table border=1 cellspacing=0 bordercolordark=white bordercolorlight=black width=800>
<tr>
<td class="b1">Homepage</td>
<td colspan="12"><a href="http\:\/\/$in{'url'}">$in{'site'}</a></td>
</tr>
<tr align=center>
<td rowspan="5" align="center"><img src="$img_path/$chara_img[$in{'chara'}]"></td>
<td class="b1">이름</td>
<td>$in{'c_name'}</td>
<td class="b1">종족</td>
<td>$chara_race[$in{'race'}]</td>
<td class="b1">성별</td>
<td>$esex</td>
<td class="b1">직업</td>
<td>$chara_class[$in{'class'}]</td>
<td class="b1">레벨</td>
<td>$lv</td>
<td class="b1">경험치</td>
<td>$ex/$next_ex</td>
</tr>
<tr align=center>
<td class="b1">돈</td>
<td>$gold</td>
<td class="b1">HP</td>
<td>$hp</td>
<td class="b1">MP</td>
<td>$mp</td>
<td class="b1">힘</td>
<td>$n_0</td>
<td class="b1">생명력</td>
<td>$n_1</td>
<td class="b1">민첩</td>
<td>$n_2</td>
</tr>
<tr align=center>
<td class="b1">기술</td>
<td>$n_3</td>
<td class="b1">지능</td>
<td>$n_4</td>
<td class="b1">매력</td>
<td>$n_5</td>
<td class="b1">행운</td>
<td>$n_6</td>
<td class="b1">전투기능</td>
<td>$wab_0</td>
<td class="b1">저항력</td>
<td>$wab_1</td>
</tr>
<tr align=center>
<td class="b1">집중력</td>
<td>$wab_2</td>
<td class="b1">검</td>
<td>$ab_0</td>
<td class="b1">도끼</td>
<td>$ab_1</td>
<td class="b1">장대무기</td>
<td>$ab_2</td>
<td class="b1">타격무기</td>
<td>$ab_3</td>
<td class="b1">특수무기</td>
<td>$ab_4</td>
</tr>
<tr align=center>
<td class="b1">괴력</td>
<td>$ab_5</td>
<td class="b1">마법저항</td>
<td>$ab_6</td>
<td class="b1">회피</td>
<td>$ab_7</td>
<td class="b1">받기</td>
<td>$ab_8</td>
<td class="b1">정신수양</td>
<td>$ab_9</td>
<td class="b1">단련</td>
<td>$ab_10</td>
</tr>
</table>
<form action="$script" method="post">
<input type="hidden" name=mode value=log_in>
<input type="hidden" name=id value="$in{'id'}">
<input type="hidden" name=pass value="$in{'pass'}">
<center><input type="submit" value="To Status" style='font-size:9pt;background-color:gray;border-style:none;width:100;height:20;color:white;font-family:tahoma'></center>
</form>
EOM
		&footer;
		exit;
	}
}

#----------------#
#  쓰고읽기처리  #
#----------------#
sub regist {
	&set_cookie;
	&get_host;
	$date = time();

	# Lock 파일
	if ($lockkey eq 1) { &lock1; }
	elsif ($lockkey eq 2) { &lock2; }
	elsif ($lockkey eq 3) { &file'lock; }

	open(IN,"$chara_file");
	@regist = <IN>;
	close(IN);

	$hit=0;@new=();
	foreach(@regist){
		($cid,$cpass,$csite,$curl,$cname,$csex,$cchara,$cn_0,$cn_1,$cn_2,$cn_3,$cn_4,$cn_5,$cn_6,$crace,$cclass,$chp,$cmaxhp,$cmp,$cmaxmp,$cex,$clv,$cgold,$ctotal,$ckati,$citem,$citem1,$citem2,$cmons,$chost,$cdate,$cwab_0,$cwab_1,$cwab_2,$cab_0,$cab_1,$cab_2,$cab_3,$cab_4,$cab_5,$cab_6,$cab_7,$cab_8,$cab_9,$cab_10,$cabpint,$cwskill,$cwskiti) = split(/<>/);
		if($cid eq "$in{'id'}" and $in{'new'} eq 'new') {
			&error("이미 등록되어 있는 ID입니다.");
		}elsif($curl eq "$in{'url'}" and $in{'new'} eq 'new'){
			&error("이미 등록되어 있는 URL입니다.");
		}elsif($host eq "$chost" and $in{'new'} eq 'new'){
			&error("한 사람당 한 캐릭터입니다. 지키지 않으시면 억세스 제한을 겁니다. 이 에러를 낸 당신의 IP 주소는 보존됩니다.");
		}elsif($cid eq "$kid"){
			unshift(@new,"$kid<>$kpass<>$ksite<>$kurl<>$kname<>$ksex<>$kchara<>$kn_0<>$kn_1<>$kn_2<>$kn_3<>$kn_4<>$kn_5<>$kn_6<>$krace<>$kclass<>$khp<>$kmaxhp<>$kmp<>$kmaxmp<>$kex<>$klv<>$kgold<>$ktotal<>$kkati<>$kitem<>$kitem1<>$kitem2<>$kmons<>$host<>$date<>$kwab_0<>$kwab_1<>$kwab_2<>$kab_0<>$kab_1<>$kab_2<>$kab_3<>$kab_4<>$kab_5<>$kab_6<>$kab_7<>$kab_8<>$kab_9<>$kab_10<>$kabpint<>$kwskill<>$kwskiti<>\n");
			$hit=1;
		}else{
			if(($date - $cdate) > (60 * 60 * 24 * $limit)) { next; }
			push(@new,"$_");
		}
	}

	if(!$hit and $in{'new'} eq 'new'){
            # HP MP 계산
            srand();
            if($in{'class'} eq 0) { $hp=int(rand(10))+1;$mp=int(rand(4))+1; }
            if($in{'class'} eq 1) { $hp=int(rand(8))+1;$mp=int(rand(8))+1; }
            if($in{'class'} eq 2) { $hp=int(rand(8))+1;$mp=int(rand(10))+1; }
            if($in{'class'} eq 3) { $hp=int(rand(6))+1;$mp=int(rand(6))+1; }
            if($in{'class'} eq 4) { $hp=int(rand(6))+1;$mp=int(rand(10))+1; }
            if($in{'class'} eq 5) { $hp=int(rand(4))+1;$mp=int(rand(10))+1; }
            #보너스 추가
            $hp+=$in{'n_1'};$mp+=$in{'n_4'};

            $ex=0;$lv=1;
            $n_0 = $in{'n_0'};
            $n_1 = $in{'n_1'};
            $n_2 = $in{'n_2'};
            $n_3 = $in{'n_3'};
            $n_4 = $in{'n_4'};
            $n_5 = $in{'n_5'};
            $n_6 = $in{'n_6'};
            $race = $in{'race'};

		if($in{'sex'}){$n_0+=1;$n_2-=1;}else{$n_0-=1;$n_2+=1;}

            $c_class = $in{'class'};
            #전투기능, 저항력 직업보너스
            if($in{'class'} eq 0){$tmp1=20;$tmp2=5;}
            if($in{'class'} eq 1){$tmp1=5;$tmp2=10;}
            if($in{'class'} eq 2){$tmp1=15;$tmp2=5;}
            if($in{'class'} eq 3){$tmp1=15;$tmp2=5;}
            if($in{'class'} eq 4){$tmp1=20;$tmp2=5;}
            if($in{'class'} eq 5){$tmp1=10;$tmp2=5;}
            $wab_0=(int(($n_0+$n_2+$n_3)/3))+$tmp1;
            $wab_1=(int(($n_1+$n_6)/2))+$tmp2;
            foreach(1..3) {$wab_2 += int(rand(6))+1;}
            $wab_2+=30;

            $ab_0=0;$ab_1=0;$ab_2=0;$ab_3=0;$ab_4=0;$ab_5=0;$ab_6=0;$ab_7=0;$ab_8=0;$ab_9=0;$ab_10=0;
            $item=0;$item1=0;$item2=0;$wskill=0;$wskiti=0;$total=1;$kati=1;

            #돈+어빌리티 계산
            $tmp1=int(rand(100))+1;
            #인간,하프엘프
            if($race eq 0 || $race eq 3){
              if($tmp1 == 1) {$gold=(int(rand(10))+1)*10000;$ab_0=1;$abpint=2;}
              elsif($tmp1>=2 & $tmp1<=5) {$gold=(int(rand(10))+1)*1000;$ab_0=1;$abpint=4;}
              elsif($tmp1>=6 & $tmp1<=30) {$gold=(int(rand(10))+1)*200;$ab_8=1;$abpint=5;}
              elsif($tmp1>=31 & $tmp1<=40) {$gold=(int(rand(10))+1)*400;$ab_6=1;$abpint=6;}
              elsif($tmp1>=41 & $tmp1<=100) {$gold=(int(rand(10))+1)*100;$ab_0=1;$abpint=6;}
            }
            #드워프
            if($race eq 2){
              if($tmp1 == 1) {$gold=(int(rand(10))+1)*10000;$ab_1=1;$abpint=6;}
              elsif($tmp1>=2 & $tmp1<=10) {$gold=(int(rand(10))+1)*1000;$ab_1=1;$abpint=6;}
              elsif($tmp1>=11 & $tmp1<=20) {$gold=(int(rand(10))+1)*200;$ab_1=1;$abpint=6;}
              elsif($tmp1>=21 & $tmp1<=30) {$gold=(int(rand(10))+1)*400;$ab_5=1;$abpint=5;}
              elsif($tmp1>=31 & $tmp1<=40) {$gold=(int(rand(10))+1)*200;$ab_1=1;$ab_5=1;$abpint=4;}
              elsif($tmp1>=41 & $tmp1<=50) {$gold=(int(rand(10))+1)*100;$ab_1=1;$ab_5=1;$abpint=1;}
              elsif($tmp1>=51 & $tmp1<=90) {$gold=(int(rand(10))+1)*100;$ab_1=1;$abpint=6;}
              elsif($tmp1>=91 & $tmp1<=100) {$gold=(int(rand(10))+1)*100;$ab_1=1;$ab_5=1;$abpint=2;}
            }
            #엘프
            if($race eq 1){
              if($tmp1>=1 & $tmp1<=50) {$gold=(int(rand(10))+1)*200;$ab_7=1;$abpint=6;}
              elsif($tmp1>=51 & $tmp1<=60) {$gold=(int(rand(10))+1)*100;$ab_7=1;$ab_8=1;$abpint=4;}
              elsif($tmp1>=61 & $tmp1<=99) {$gold=(int(rand(10))+1)*100;$ab_0=1;$ab_7=1;$abpint=4;}
              elsif($tmp1 == 100) {$gold=(int(rand(10))+1)*100;$ab_0=1;$ab_7=1;$abpint=4;}
            }
            #다크 엘프
            if($race eq 4){
              if($tmp1>=1 & $tmp1<=30) {$gold=(int(rand(10))+1)*200;$ab_6=1;$abpint=3;}
              elsif($tmp1>=31 & $tmp1<=50) {$gold=(int(rand(10))+1)*100;$ab_0=1;$ab_6=1;$abpint=3;}
              elsif($tmp1>=51 & $tmp1<=100) {$gold=(int(rand(10))+1)*100;$ab_0=1;$ab_6=1;$abpint=4;}
            }
		unshift(@new,"$in{'id'}<>$in{'pass'}<>$in{'site'}<>$in{'url'}<>$in{'c_name'}<>$in{'sex'}<>$in{'chara'}<>$n_0<>$n_1<>$n_2<>$n_3<>$n_4<>$n_5<>$n_6<>$race<>$c_class<>$hp<>$hp<>$mp<>$mp<>$ex<>$lv<>$gold<>$total<>$kati<>$item<>$item1<>$item2<>$mons<>$host<>$date<>$wab_0<>$wab_1<>$wab_2<>$ab_0<>$ab_1<>$ab_2<>$ab_3<>$ab_4<>$ab_5<>$ab_6<>$ab_7<>$ab_8<>$ab_9<>$ab_10<>$abpint<>$wskill<>$wskiti<>\n");
	}

	open(OUT,">$chara_file");
	print OUT @new;
	close(OUT);

	# Lock 해제
	if ($lockkey eq 3) { &file'unlock; }
	else { if(-e $lockfile) { unlink($lockfile); } }

	if($in{'new'}) { &make_end; }
}


#-----------------#
# 특기포인트 변경 #
#-----------------#
sub aty_up {
      if($in{'abilt'} eq 'no') { &error("수련할 능력치를 선택해 주십시오."); }
	$id = $in{'id'};
	&get_host;
	$date = time();

	open(IN,"$chara_file");
	@abaup = <IN>;
	close(IN);

	@abil_new = ();
	foreach(@abaup) {
        ($aid,$apass,$asite,$aurl,$aname,$asex,$achara,$an_0,$an_1,$an_2,$an_3,$an_4,$an_5,$an_6,$arace,$aclass,$ahp,$amaxhp,$amp,$amaxmp,$aex,$alv,$agold,$atotal,$akati,$aitem,$aitem1,$aitem2,$amons,$ahost,$adate,$awab_0,$awab_1,$awab_2,$aab_0,$aab_1,$aab_2,$aab_3,$aab_4,$aab_5,$aab_6,$aab_7,$aab_8,$aab_9,$aab_10,$aabpint,$awskill,$awskiti) = split(/<>/);
        if($id eq $aid) {
           $abilt = $in{'abilt'};
           $tmp1=int(rand(10))+1;$tmp2=int(rand(10))+1;
           if(!$aabpint) { &error("특기포인트가 부족합니다. 1"); }
           #전투기능, 저항력 직업보너스
           if($aclass eq 0){$tmp1=20;$tmp2=5;}
           if($aclass eq 1){$tmp1=5;$tmp2=10;}
           if($aclass eq 2){$tmp1=15;$tmp2=5;}
           if($aclass eq 3){$tmp1=15;$tmp2=5;}
           if($aclass eq 4){$tmp1=20;$tmp2=5;}
           if($aclass eq 5){$tmp1=10;$tmp2=5;}

           #능력치가 1~9
           if($abilt eq 1 & $an_0<=9) {$an_0+=1;$aabpint-=2;$ab_name="힘을";$awab_0=int(($an_0+$an_2+$an_3)/3)+$tmp1;}
           elsif($abilt eq 2 & $an_1<=9) {$an_1+=1;$aabpint-=2;$ab_name="생명력을";$amaxhp+=1;$awab_1=int(($an_1+$an_6)/2)+$tmp2;}
           elsif($abilt eq 3 & $an_2<=9) {$an_2+=1;$aabpint-=2;$ab_name="민첩을";$awab_0=int(($an_0+$an_2+$an_3)/3)+$tmp1;}
           elsif($abilt eq 4 & $an_3<=9) {$an_3+=1;$aabpint-=2;$ab_name="기술을";$awab_0=int(($an_0+$an_2+$an_3)/3)+$tmp1;}
           elsif($abilt eq 5 & $an_4<=9) {$an_4+=1;$aabpint-=2;$ab_name="지능을";$amaxmp+=1;}
           elsif($abilt eq 6 & $an_5<=9) {$an_5+=1;$aabpint-=2;$ab_name="매력을";}
           elsif($abilt eq 7 & $an_6<=9) {$an_6+=1;$aabpint-=2;$ab_name="행운을";$awab_1=int(($an_1+$an_6)/2)+$tmp2;}

           #능력치가 10~19
           elsif($abilt eq 1 & $an_0>=10 & $an_0<=19) {$an_0+=1;$aabpint-=4;$ab_name="힘을";$awab_0=int(($an_0+$an_2+$an_3)/3)+$tmp1;}
           elsif($abilt eq 2 & $an_1>=10 & $an_1<=19) {$an_1+=1;$aabpint-=4;$ab_name="생명력을";$amaxhp+=1;$awab_1=int(($an_1+$an_6)/2)+$tmp2;}
           elsif($abilt eq 3 & $an_2>=10 & $an_2<=19) {$an_2+=1;$aabpint-=4;$ab_name="민첩을";$awab_0=int(($an_0+$an_2+$an_3)/3)+$tmp1;}
           elsif($abilt eq 4 & $an_3>=10 & $an_3<=19) {$an_3+=1;$aabpint-=4;$ab_name="기술을";$awab_0=int(($an_0+$an_2+$an_3)/3)+$tmp1;}
           elsif($abilt eq 5 & $an_4>=10 & $an_4<=19) {$an_4+=1;$aabpint-=4;$ab_name="지능을";$amaxmp+=1;}
           elsif($abilt eq 6 & $an_5>=10 & $an_5<=19) {$an_5+=1;$aabpint-=4;$ab_name="매력을";}
           elsif($abilt eq 7 & $an_6>=10 & $an_6<=19) {$an_6+=1;$aabpint-=4;$ab_name="행운을";$awab_1=int(($an_1+$an_6)/2)+$tmp2;}

           #능력치가 20~
           elsif($abilt eq 1 & $an_0>=20) {$an_0+=1;$aabpint-=8;$ab_name="힘을";$awab_0=int(($an_0+$an_2+$an_3)/3)+$tmp1;}
           elsif($abilt eq 2 & $an_1>=20) {$an_1+=1;$aabpint-=8;$ab_name="생명력을";$amaxhp+=1;$awab_1=int(($an_1+$an_6)/2)+$tmp2;}
           elsif($abilt eq 3 & $an_2>=20) {$an_2+=1;$aabpint-=8;$ab_name="민첩을";$awab_0=int(($an_0+$an_2+$an_3)/3)+$tmp1;}
           elsif($abilt eq 4 & $an_3>=20) {$an_3+=1;$aabpint-=8;$ab_name="기술을";$awab_0=int(($an_0+$an_2+$an_3)/3)+$tmp1;}
           elsif($abilt eq 5 & $an_4>=20) {$an_4+=1;$aabpint-=8;$ab_name="지능을";$amaxmp+=1;}
           elsif($abilt eq 6 & $an_5>=20) {$an_5+=1;$aabpint-=8;$ab_name="매력을";}
           elsif($abilt eq 7 & $an_6>=20) {$an_6+=1;$aabpint-=8;$ab_name="행운을";$awab_1=int(($an_1+$an_6)/2)+$tmp2;}

           elsif($abilt eq 8 & $aabpint>=1 & ($aclass eq 0 || $aclass eq 4)){$aab_0+=1;$aabpint-=1;$ab_name="검을";$agold-=40;}
           elsif($abilt eq 9 & $aabpint>=1 & $aclass eq 0){$aab_1+=1;$aabpint-=1;$ab_name="도끼를";$agold-=40;}
           elsif($abilt eq 10 & $aabpint>=1 & ($aclass eq 0 || $aclass eq 4)){$aab_2+=1;$aabpint-=1;$ab_name="장대무기를";$agold-=40;}
           elsif($abilt eq 11 & $aabpint>=1 & $aclass eq 0){$aab_3+=1;$aabpint-=1;$ab_name="타격무기를";$agold-=40;}
           elsif($abilt eq 12 & $aabpint>=1 & $aclass eq 3){$aab_4+=1;$aabpint-=1;$ab_name="특수무기를";$agold-=60;}
           elsif($abilt eq 13 & $aabpint>=1 & ($aclass eq 0 || $aclass eq 4)){$aab_5+=1;$aabpint-=1;$ab_name="괴력을";$agold-=10;}
           elsif($abilt eq 14 & $aabpint>=1){$aab_6+=1;$aabpint-=1;$ab_name="마법저항을";$agold-=50;}
           elsif($abilt eq 15 & $aabpint>=1 & $aclass == 3){$aab_7+=1;$aabpint-=1;$ab_name="회피를";$agold-=100;}
           elsif($abilt eq 16 & $aabpint>=1 & $aclass != 1){$aab_8+=1;$aabpint-=1;$ab_name="받기를";$agold-=20;}
           elsif($abilt eq 17 & $aabpint>=1 & ($aclass eq 1 || $aclass eq 2 || $aclass eq 5)){$aab_9+=1;$aabpint-=1;$ab_name="정신수양을";$agold-=30;$amaxmp+=$tmp2;}
           elsif($abilt eq 18 & $aabpint>=1 & $aclass eq 0){$aab_10+=1;$aabpint-=1;$ab_name="단련을";$amaxhp+=$tmp1;$agold-=30;}
           elsif($abilt eq 8 & $aabpint>=2){$aab_0+=1;$aabpint-=2;$ab_name="검을";$agold-=40;}
           elsif($abilt eq 9 & $aabpint>=2){$aab_1+=1;$aabpint-=2;$ab_name="도끼를";$agold-=40;}
           elsif($abilt eq 10 & $aabpint>=2){$aab_2+=1;$aabpint-=2;$ab_name="장대무기를";$agold-=40;}
           elsif($abilt eq 11 & $aabpint>=2){$aab_3+=1;$aabpint-=2;$ab_name="타격무기를";$agold-=40;}
           elsif($abilt eq 12 & $aabpint>=2){$aab_4+=1;$aabpint-=2;$ab_name="특수무기를";$agold-=60;}
           elsif($abilt eq 13 & $aabpint>=2){$aab_5+=1;$aabpint-=2;$ab_name="괴력을";$agold-=10;}
           elsif($abilt eq 14 & $aabpint>=2){$aab_6+=1;$aabpint-=2;$ab_name="마법저항을";$agold-=50;}
           elsif($abilt eq 15 & $aabpint>=2){$aab_7+=1;$aabpint-=2;$ab_name="회피를";$agold-=100;}
           elsif($abilt eq 16 & $aabpint>=2){$aab_8+=1;$aabpint-=2;$ab_name="받기를";$agold-=20;}
           elsif($abilt eq 17 & $aabpint>=2){$aab_9+=1;$aabpint-=2;$ab_name="정신수양을";$agold-=30;$amaxmp+=$tmp2;}
           elsif($abilt eq 18 & $aabpint>=2){$aab_10+=1;$aabpint-=2;$ab_name="단련을";$amaxhp+=$tmp1;$agold-=30;}else{&error("특기포인트가 부족합니다.");}

           unshift(@abil_new,"$aid<>$apass<>$asite<>$aurl<>$aname<>$asex<>$achara<>$an_0<>$an_1<>$an_2<>$an_3<>$an_4<>$an_5<>$an_6<>$arace<>$aclass<>$ahp<>$amaxhp<>$amp<>$amaxmp<>$aex<>$alv<>$agold<>$atotal<>$akati<>$aitem<>$aitem1<>$aitem2<>$amons<>$ahost<>$adate<>$awab_0<>$awab_1<>$awab_2<>$aab_0<>$aab_1<>$aab_2<>$aab_3<>$aab_4<>$aab_5<>$aab_6<>$aab_7<>$aab_8<>$aab_9<>$aab_10<>$aabpint<>$awskill<>$awskiti<>\n");
        }else{
           push(@abil_new,"$_");
        }
      }

	open(OUT,">$chara_file");
	print OUT @abil_new;
	close(OUT);

	&header;

	print <<"EOM";
<img src="$title5"><br>
<hr size=0><br>
<form action="$script" method="post">
<input type="hidden" name=id value="$in{'id'}">
<input type="hidden" name=pass value="$in{'pass'}">
<input type="hidden" name=mode value=log_in>
<center>
$ab_name 수련하였습니다. <input type="submit" value="To Status" style='font-size:9pt;background-color:gray;border-style:none;width:100;height:20;color:white;font-family:tahoma'></center>
</form>
EOM
	&footer;
	exit;
}

#----------------#
#    상세정보    #
#----------------#
sub status2 {
	open(IN,"$chara_file");
	@log_in = <IN>;
	close(IN);

	$hit=0;
	foreach(@log_in){
		($kid,$kpass,$ksite,$kurl,$kname,$ksex,$kchara,$kn_0,$kn_1,$kn_2,$kn_3,$kn_4,$kn_5,$kn_6,$krace,$kclass,$khp,$kmaxhp,$kmp,$kmaxmp,$kex,$klv,$kgold,$ktotal,$kkati,$kitem,$kitem1,$kitem2,$kmons,$khost,$kdate,$kwab_0,$kwab_1,$kwab_2,$kab_0,$kab_1,$kab_2,$kab_3,$kab_4,$kab_5,$kab_6,$kab_7,$kab_8,$kab_9,$kab_10,$kabpint,$kwskill,$kwskiti) = split(/<>/);
		if($in{'id'} eq "$kid" and $in{'pass'} eq "$kpass") {$hit=1;last;}
	}

	open(IN,"$item_file");
	@log_item = <IN>;
	close(IN);

	$hit=0;
	foreach(@log_item){
		($i_no,$i_name,$i_dmg,$i_gold,$i_kind,$i_wkind,$i_ref,$i_cls) = split(/<>/);
		if($kitem eq "$i_no"){ $hit=1;last; }
	}

      #아이템 데이타 세부적 분류(무기)
      ($i_mindmg,$tmp1) = split(/D/,$i_dmg);
      ($i_maxdmg,$i_pdmg) = split(/p/,$tmp1);
      ($i_wkind,$i_whand) = split(/a/,$i_wkind);
      if($kitem == "" || $kitem == 0){$i_mindmg=1;$i_maxdmg=2;$i_pdmg=$klv;}
      $tmp3=$i_mindmg+$i_pdmg+$kab_5;
      $tmp4=($i_maxdmg*$i_mindmg)+$i_pdmg+$kab_5;

      if($kn_0>=7 & $kn_0<=9){$tmp3+=1;$tmp4+=1;}
      if($kn_0>=10 & $kn_0<=12){$tmp3+=2;$tmp4+=2;}
      if($kn_0>=13 & $kn_0<=15){$tmp3+=3;$tmp4+=3;}
      if($kn_0>=16 & $kn_0<=18){$tmp3+=4;$tmp4+=4;}
      if($kn_0>=19 & $kn_0<=21){$tmp3+=5;$tmp4+=5;}
      if($kn_0>=22 & $kn_0<=25){$tmp3+=6;$tmp4+=6;}

      #방어구 찾기
	$hit=0;
	foreach(@log_item){
		($i_no2,$i_name2,$i_av,$i_gold,$i_kind2,$i_wkind2,$i_ref2,$i_cls) = split(/<>/);
		if($kitem2 eq "$i_no2"){ $hit=1;last; }
	}
      ($tmp1,$tmp2) = split(/a/,$i_wkind2);
      if($tmp1 == 1){$i_minuses1=$tmp2;}

      #보조아이템 찾기
	$hit=0;
	foreach(@log_item){
		($i_no1,$i_name1,$i_av1,$i_gold,$i_kind1,$i_wkind1,$i_ref1,$i_cls) = split(/<>/);
		if($kitem1 eq "$i_no1"){ $hit=1;last; }
	}

      $tmp1=$kab_7*5+$kn_2-$i_minuses1;
      $tmp2=int($kwab_0/3)+($kab_8*5)+$i_av1;

	&header;
      print "<img src=\"$title8\"><br>";
	print <<"EOM";
<hr size=0><br>
<table border=1 bordercolordark=white bordercolorlight=black cellspacing=0 width=500 align=center>
<tr align=center>
<td class=b1>전투기능</td>
<td>$kwab_0</td>
<td class=b1>저항력</td>
<td>$kwab_1</td>
<td class=b1>집중력</td>
<td>$kwab_2</td>
<td class=b1>검</td>
<td>$kab_0</td>
<td class=b1>도끼</td>
<td>$kab_1</td>
</tr><tr align=center>
<td class=b1>장대무기</td>
<td>$kab_2</td>
<td class=b1>타격무기</td>
<td>$kab_3</td>
<td class=b1>특수무기</td>
<td>$kab_4</td>
<td class=b1>괴력</td>
<td>$kab_5</td>
<td class=b1>마법저항</td>
<td>$kab_6</td>
</tr><tr align=center>
<td class=b1>회피</td>
<td>$kab_7</td>
<td class=b1>받기</td>
<td>$kab_8</td>
<td class=b1>정신수양</td>
<td>$kab_9</td>
<td class=b1>단련</td>
<td>$kab_10</td>
<td class=b1>회피력</td>
<td>$tmp1</td>
</tr><tr align=center>
<td class=b1>받기치</td>
<td>$tmp2</td>
<td class=b1>최소 데미지</td>
<td>$tmp3</td>
<td class=b1>최대 데미지</td>
<td>$tmp4</td>
<td class=b1>&nbsp;</td>
<td>&nbsp;</td>
<td class=b1>&nbsp;</td>
<td>&nbsp;</td>
</tr>
</table><p>
<center>
<input type=submit onclick=javascript:history.back() value=이전으로 style='font-size:9pt; background-color:gray; border-style:none; width:100; height:25; color:white;font-family:tahoma;'>
</center>
</body>
</html>
EOM
	exit;
}

#----------------#
#    자살바위    #
#----------------#
sub k_stone1 {
      &header;

      print <<"EOM";
<img src=$title_img><br>
<hr size=0><br>
<form action="$script" method="post">
<center><font style=font-size:9pt>캐릭터를 삭제하시려면 ID와 Password를 입력하여주시기 바랍니다.</font></center><p>
<p align=center>
ID : <input type=text name=id size=10 style="border-style:none;border-bottom:1px solid gray">
PASS : <input type=password name=pass size=10 style="border-style:none;border-bottom:1px solid gray">
<input type=hidden name=mode value=k_stone2>
<input type=submit value="자살" style='font-size:9pt;background-color:gray;border-style:none;width:100;height:20;color:white;font-family:tahoma'>
</p></form>
EOM
	&footer;
	exit;
}

#----------------#
#    자살처리    #
#----------------#
sub k_stone2 {
	if($in{'id'} eq "") {
		&error("ID가 잘못되었습니다.");
	}elsif($in{'pass'} eq ""){
		&error("암호가 잘못되었습니다.");
	}
	$kill_id = $in{'id'};
	$kill_pass = $in{'pass'};

	&get_host;

	$date = time();

	# Lock 파일
	if ($lockkey eq 1) { &lock1; }
	elsif ($lockkey eq 2) { &lock2; }
	elsif ($lockkey eq 3) { &file'lock; }

	open(IN,"$chara_file");
	@kill_chara = <IN>;
	close(IN);

	$hit=0;@kill_new=();
	foreach(@kill_chara){
        ($kid,$kpass,$ksite,$kurl,$kname,$ksex,$kchara,$kn_0,$kn_1,$kn_2,$kn_3,$kn_4,$kn_5,$kn_6,$krace,$kclass,$khp,$kmaxhp,$kmp,$kmaxmp,$kex,$klv,$kgold,$ktotal,$kkati,$kitem,$kitem1,$kitem2,$kmons,$khost,$kdate,$kwab_0,$kwab_1,$kwab_2,$kab_0,$kab_1,$kab_2,$kab_3,$kab_4,$kab_5,$kab_6,$kab_7,$kab_8,$kab_9,$kab_10,$kabpint,$kwskill,$kwskiti) = split(/<>/);
        if($kid eq "$kill_id" & $kpass eq "$kill_pass") {
           $hit=1;
        }else {
           push(@kill_new,"$_");
        }
	}
	if(!$hit) { &error("해당 캐릭터를 찾을 수 없습니다."); }

	open(OUT,">$chara_file");
	print OUT @kill_new;
	close(OUT);

	# Lock 해제
	if ($lockkey eq 3) { &file'unlock; }
	else { if(-e $lockfile) { unlink($lockfile); } }

	&header;

	print <<"EOM";
<img src=$title_img><br>
<hr size=0><br>
<center>당신의 캐릭터가 삭제되었습니다.</center>
</form>
EOM
	&footer;
	exit;
}

#----------------#
#    로그인      #
#----------------#
sub log_in {
	$chara_flag=1;

	# Lock 파일
	if ($lockkey eq 1) { &lock1; }
	elsif ($lockkey eq 2) { &lock2; }
	elsif ($lockkey eq 3) { &file'lock; }

	open(IN,"$chara_file");
	@log_in = <IN>;
	close(IN);

	$hit=0;
	foreach(@log_in){
		($kid,$kpass,$ksite,$kurl,$kname,$ksex,$kchara,$kn_0,$kn_1,$kn_2,$kn_3,$kn_4,$kn_5,$kn_6,$krace,$kclass,$khp,$kmaxhp,$kmp,$kmaxmp,$kex,$klv,$kgold,$ktotal,$kkati,$kitem,$kitem1,$kitem2,$kmons,$khost,$kdate,$kwab_0,$kwab_1,$kwab_2,$kab_0,$kab_1,$kab_2,$kab_3,$kab_4,$kab_5,$kab_6,$kab_7,$kab_8,$kab_9,$kab_10,$kabpint,$kwskill,$kwskiti) = split(/<>/);
		if($in{'id'} eq "$kid" and $in{'pass'} eq "$kpass") {$hit=1;last;}
	}

	$ltime = time();
	$ltime = $ltime - $kdate;
	$vtime = $b_time - $ltime;
	$mtime = $m_time - $ltime;

	if(!$hit) { &error("없는 ID이거나 암호가 잘못되었습니다. 초기메뉴에서 -신규 캐릭터 작성-으로 캐릭터를 새로 만들어주시기 바랍니다."); }

	if($ksex) { $esex = "남"; } else { $esex = "여"; }
      if($klv eq 1) { $next_ex=1000; }
      if($klv eq 2) { $next_ex=2000; }
      if($klv eq 3) { $next_ex=4000; }
      if($klv eq 4) { $next_ex=8000; }
      if($klv eq 5) { $next_ex=16000; }
      if($klv eq 6) { $next_ex=32000; }
      if($klv eq 7) { $next_ex=48000; }
      if($klv eq 8) { $next_ex=64000; }
      if($klv eq 9) { $next_ex=80000; }
      if($klv eq 10) { $next_ex=96000; }
      if($klv eq 11) { $next_ex=112000; }
      if($klv eq 12) { $next_ex=128000; }

	open(IN,"$item_file");
	@log_item = <IN>;
	close(IN);

      #이름표시
	$hit=0;
	foreach(@log_item){
		($i_no,$i_name,$i_dmg,$i_gold,$i_kind,$wi_wkind,$i_ref,$i_cls) = split(/<>/);
		if($kitem eq "$i_no"){ $hit=1;last; }
	}
	if(!$hit) { $i_name="없음"; }

	$hit=0;
	foreach(@log_item){
		($i_no,$i_name1,$i_dmg,$i_gold,$i_kind,$wi_wkind,$i_ref,$i_cls) = split(/<>/);
		if($kitem1 eq "$i_no"){ $hit=1;last; }
	}
	if(!$hit) { $i_name1="없음"; }

      #갑옷이름표시
	$hit=0;
	foreach(@log_item){
		($i_no2,$i_name2,$i_dmg,$i_gold,$i_kind,$wi_wkind,$i_ref,$i_cls) = split(/<>/);
		if($kitem2 eq "$i_no2"){ $hit=1;last; }
	}
	if(!$hit) { $i_name2="없음"; }

	&header;
      print "<img src=\"$title8\"><br>";
	if($ltime < $b_time || !$ktotal){
	print <<"EOM";
<hr size=0>
<FORM NAME="form1">
<font style=font-size:9pt>행동이 가능한 시간까지 앞으로 <INPUT TYPE="text" NAME="clock" SIZE="2" VALUE="$vtime" style="border-style:none;font-size:9pt">초가 남았습니다．0이 되면，자동적으로 갱신이 되니 브라우저의 <b>새로고침</b>을 누르지 마십시요.</font>
</FORM>
EOM
	}
	print <<"EOM";
<table border=0>
<tr>
<form action="$script" mehotd="post">
<td valign=top width=52%>
<table border=1 bordercolordark=white bordercolorlight=black cellspacing=0 width=100%>
<tr>
<td colspan="4" class="b2" align="center">◆ Status ◆</td>
<td align="right" class="b2">
<input type="hidden" name=mode value=status2>
<input type="hidden" name=id value="$kid">
<input type="hidden" name=pass value="$kpass">
<input type=submit value="상세정보" style="font-size:9pt;background-color:gray;border-style:none;width:60;height:20;color:white;font-family:tahoma;">
</td>
</tr>
<tr>
<td class="b1" width="30%">Homepage</td>
<td colspan="4">$ksite</td>
</tr>
<tr>
<td class="b1" width="30%">URL</td>
<td colspan="4">$kurl</td>
</tr>
<tr>
<td colspan="5" class="b2" align="center">캐릭터 데이타</td>
</tr>
<tr>
<td width="30%" rowspan="8" align="center"></form><img src="$img_path/$chara_img[$kchara]"><br><font style=font-size:9pt>무기 : $i_name<br>방패 : $i_name1<br>갑옷 : $i_name2</font></td>
<td class="b1" width="15%">이름</td><td width="17%">$kname</td>
<td class="b1" width="17%">종족(성별)</td><td>$chara_race[$krace]($esex)</td>
</tr>
<tr>
<td class="b1" width="15%">직업</td><td width="17%">$chara_class[$kclass]</td>
<td class="b1" width="17%">돈</td><td>$kgold</td>
</tr>
<tr>
<td class="b1" width="15%">레벨</td><td width="17%">$klv</td>
<td class="b1" width="17%">경험치</td><td>$kex/$next_ex</td>
</tr>
<tr>
<td class="b1" width="15%">HP</td><td width="17%">$khp\/$kmaxhp</td>
<td class="b1" width="17%">MP</td><td>$kmp\/$kmaxmp</td>
</tr>
<tr>
<td class="b1" width="15%">힘</td><td width="17%">$kn_0</td>
<td class="b1" width="17%">생명력</td><td>$kn_1</td>
</tr>
<tr>
<td class="b1" width="15%">민첩</td><td width="17%">$kn_2</td>
<td class="b1" width="17%">기술</td><td>$kn_3</td>
</tr>
<tr>
<td class="b1" width="15%">지능</td><td width="17%">$kn_4</td>
<td class="b1" width="17%">매력</td><td>$kn_5</td>
</tr>
<tr>
<td class="b1" width="15%">행운</td><td width="17%">$kn_6</td>
<td class="b1" width="17%">집중력</td><td>$kwab_2</td>
</tr>
<tr>
<td colspan="5" align="center">
<form action="$script" method="post">
<input type="hidden" name=mode value=battle>
<input type="hidden" name=id value="$kid">
<input type="hidden" name=pass value="$kpass">
EOM
	if($ltime >= $b_time or !$ktotal) {
		print "<input type=submit value=\"최강자에게 도전\" style='font-size:9pt;background-color:gray;border-style:none;width:110;height:20;color:white;font-family:tahoma;'>\n";
	}else{
		print "<font style=font-size:9pt>$vtime초 후에 실행해주세요.</font>\n";
	}

	print <<"EOM";
</td>
</tr>
</table>
</form>
</td>
<td valign="top">
<form action="$script" method="post">
【특기수련】&nbsp;
<select name=abilt>
<option value="no">선택해 주십시오.
EOM

if( ($kn_0<=9 & $kabpint>=2) || ($kn_0>=10 & $kn_0<=19 & $kabpint>=4) || ($kn_0>=20 & $kabpint>=8) ) {print "<option value=1>힘\n";}
if( ($kn_1<=9 & $kabpint>=2) || ($kn_1>=10 & $kn_1<=19 & $kabpint>=4) || ($kn_1>=20 & $kabpint>=8) ) {print "<option value=2>생명력\n";}
if( ($kn_2<=9 & $kabpint>=2) || ($kn_2>=10 & $kn_2<=19 & $kabpint>=4) || ($kn_2>=20 & $kabpint>=8) ) {print "<option value=3>민첩\n";}
if( ($kn_3<=9 & $kabpint>=2) || ($kn_3>=10 & $kn_3<=19 & $kabpint>=4) || ($kn_3>=20 & $kabpint>=8) ) {print "<option value=4>기술\n";}
if( ($kn_4<=9 & $kabpint>=2) || ($kn_4>=10 & $kn_4<=19 & $kabpint>=4) || ($kn_4>=20 & $kabpint>=8) ) {print "<option value=5>지능\n";}
if( ($kn_5<=9 & $kabpint>=2) || ($kn_5>=10 & $kn_5<=19 & $kabpint>=4) || ($kn_5>=20 & $kabpint>=8) ) {print "<option value=6>매력\n";}
if( ($kn_6<=9 & $kabpint>=2) || ($kn_6>=10 & $kn_6<=19 & $kabpint>=4) || ($kn_6>=20 & $kabpint>=8) ) {print "<option value=7>행운\n";}

if( $kgold>=40 & (($klv<=2 & $kab_0<2) || ($klv>=3 & $klv<=5 & $kab_0<3) || ($klv>=6 & $klv<=9 & $kab_0<4) || ($klv>=10 & $kab_0<5)) ){print "<option value=8>검\n";}
if( $kgold>=40 & $kclass != 1 & (($klv<=2 & $kab_1<2) || ($klv>=3 & $klv<=5 & $kab_1<3) || ($klv>=6 & $klv<=9 & $kab_1<4) || ($klv>=10 & $kab_1<5)) ){print "<option value=9>도끼\n";}
if( $kgold>=40 & (($klv<=2 & $kab_2<2)||($klv>=3 & $klv<=5 & $kab_2<3)||($klv>=6 & $klv<=9 & $kab_2<4)||($klv>=10 & $kab_2<5))){print "<option value=10>장대무기\n";}
if( $kgold>=30 & (($klv<=2 & $kab_3<2)||($klv>=3 & $klv<=5 & $kab_3<3)||($klv>=6 & $klv<=9 & $kab_3<4)||($klv>=10 & $kab_3<5))){print "<option value=11>타격무기\n";}
if( $kgold>=50 & (($klv<=2 & $kab_4<2)||($klv>=3 & $klv<=5 & $kab_4<3)||($klv>=6 & $klv<=9 & $kab_4<4)||($klv>=10 & $kab_4<5))){print "<option value=12>특수무기\n";}
if( $kgold>=10 & (($klv<=2 & $kab_5<2)||($klv>=3 & $klv<=5 & $kab_5<3)||($klv>=6 & $klv<=9 & $kab_5<4)||($klv>=10 & $kab_5<5))){print "<option value=13>괴력\n";}
if( $kgold>=50 & (($klv<=2 & $kab_6<2)||($klv>=3 & $klv<=5 & $kab_6<3)||($klv>=6 & $klv<=9 & $kab_6<4)||($klv>=10 & $kab_6<5))){print "<option value=14>마법저항\n";}
if( $kgold>=100 & (($klv<=2 & $kab_7<2)||($klv>=3 & $klv<=5 & $kab_7<3)||($klv>=6 & $klv<=9 & $kab_7<4)||($klv>=10 & $kab_7<5))){print "<option value=15>회피\n";}
if( $kgold>=20 & (($klv<=2 & $kab_8<2)||($klv>=3 & $klv<=5 & $kab_8<3)||($klv>=6 & $klv<=9 & $kab_8<4)||($klv>=10 & $kab_8<5))){print "<option value=16>받기\n";}
if( $kgold>=30 & (($klv<=2 & $kab_9<2)||($klv>=3 & $klv<=5 & $kab_9<3)||($klv>=6 & $klv<=9 & $kab_9<4)||($klv>=10 & $kab_9<5))){print "<option value=17>정신수양\n";}
if( $kgold>=30 & (($klv<=2 & $kab_10<2)||($klv>=3 & $klv<=5 & $kab_10<3)||($klv>=6 & $klv<=9 & $kab_10<4)||($klv>=10 & $kab_10<5))){print "<option value=18>단련\n";}

print <<"EOM";
</select>
<input type=hidden name=id value=$kid>
<input type=hidden name=pass value=$kpass>
<input type=hidden name=mode value=aty_up>
<input type=submit value=수련 style="font-size:9pt;background-color:gray;border-style:none;width:60;height:20;color:white;font-family:tahoma">
<br>
<font style=font-size:9pt>※ 당신의 현재 특기포인트는 <b>$kabpint</b> 입니다.</font>
</form>
<form action="$script" method="post">
【몬스터퇴치수행】
<input type=hidden name=id value=$kid>
<input type=hidden name=pass value=$kpass>
<input type=hidden name=mode value=monster>
EOM

	if($ltime >= $m_time || !$ktotal) {
		print "<input type=submit value=\"수행\" style='font-size:9pt;background-color:gray;border-style:none;width:60;height:20;color:white;font-family:tahoma'><br>\n";
	}else{
		print "<font style=font-size:9pt>$mtime초후에 실행해주세요.</font><br>\n";
	}
	$inn_gold = $inn_gld * $klv;

      #매력에 따른 할인율
      if($kn_5>=7 & $kn_5<=12) {$inn_gold -= int($inn_gold*0.05);}
      elsif($kn_5>=13 & $kn_5<=18) {$inn_gold -= int($inn_gold*0.1);}
      elsif($kn_5>=19 & $kn_5<=21) {$inn_gold -= int($inn_gold*0.15);}
      elsif($kn_5>=22) {$inn_gold -= int($inn_gold*0.2);}

	print <<"EOM";
</form>
<form action="$script" method="post">
【여관에서 노숙】<br>
<font style=font-size:9pt>※ 회복하려면 <b>$inn_gold</b>GP가 필요합니다.</font>
<input type=hidden name=id value=$kid>
<input type=hidden name=pass value=$kpass>
<input type=hidden name=mode value=inn>
<input type=submit value="노숙" style='font-size:9pt;background-color:gray;border-style:none;width:80;height:20; color:white;font-family:tahoma'><br>
</form>
<form action="$script" method="post">
【메세지 전송】<br>
<input type="text" name=mes size=50 style="border-style:1px solid black"><br>
<select name=mesid><option value="">보낼 사람 선택
EOM
	open(IN,"$chara_file");
	@MESSAGE = <IN>;
	close(IN);

	foreach(@MESSAGE) {
		($did,$dpass,$dsite,$durl,$dname) = split(/<>/);
		if($kid eq $did){next;}
            print "<option value=$did>$dname님\n";
	}

	print <<"EOM";
</select>
<input type=hidden name=id value=$kid>
<input type=hidden name=name value=$kname>
<input type=hidden name=pass value=$kpass>
<input type=hidden name=mode value=message>
<input type=submit value="Send" style='font-size:9pt;background-color:gray;border-style:none;width:60;height:20;color:white;font-family:tahoma'>
</form>
<form action="$script" method="post">
【전투중 사용할 기술】<br>
<font style=font-size:9pt>&nbsp;◆ 현재 설정:&nbsp;
EOM
 open(IN,"$magic_file");
 @MAGIC = <IN>;
 close(IN);

 if($kwskill eq 0){print "사용안함";}

 foreach(@MAGIC){
   ($mg_no,$mg_lv,$mg_name,$mg_mp,$mg_time,$mg_kind,$mg_dta1,$mg_dta2,$mg_re,$mg_cls)=split(/<>/);
   if( $kwskill eq $mg_no ) { print "$mg_name"; }
 }

 print " ◆ 시기: ";
 if($kwskiti == 0){print "사용안함";}
 if($kwskiti == 1){print "전투시작과 함께";}
 if($kwskiti == 2){print "자신의 HP가 1/3이하로 내려갔을때";}
 if($kwskiti == 3){print "상대의 레벨이 높을때(전투시작시)";}
 if($kwskiti == 4){print "매 라운드마다";}
 print "</font><br>";
print <<"EOM";
&nbsp;<select name=wsk>
<option value="no">선택해주십시오.
<option value=0>사용안함
EOM
 foreach(@MAGIC){
  ($mg_no,$mg_lv,$mg_name,$mg_mp,$mg_time,$mg_kind,$mg_dta1,$mg_dta2,$mg_re,$mg_cls)=split(/<>/);
  $tmp1=0;
  if($mg_lv <= $klv) {
    if($mg_cls == 2 & ($kclass == 1 || $kclass == 4)){$tmp1=1;}
    elsif($mg_cls == 1 & $kclass == 1){$tmp1=1;}
    elsif($mg_cls == 5 & $kclass == 0){$tmp1=1;}
    elsif($mg_cls == 6 & $kclass == 3){$tmp1=1;}
    elsif($mg_cls == 7 & $kclass == 4){$tmp1=1;}
    elsif($mg_cls == 3 & $kclass == 5){$tmp1=1;}
    elsif($mg_cls == 4 & $kclass == 2){$tmp1=1;}
    if($tmp1){print "<option value=$mg_no>$mg_name\n";$tmp1=0;}
  }
 }
print <<"EOM";
</select>
&nbsp;<select name=wsk1>
<option value="no">사용시기를 선택해주십시오.
<option value=1>전투시작과 함께
<option value=2>자신의 HP가 1/3이하로 내려갔을때
<option value=3>상대의 레벨이 높을때(전투시작시)
<option value=4>매 라운드마다
</select>
<input type=hidden name=id value=$kid>
<input type=hidden name=pass value=$kpass>
<input type=hidden name=mode value=wsk_set>
<input type=submit value=변경 style="font-size:9pt;background-color:gray;border-style:none;width:60;height:20;color:white;font-family:tahoma">
</form>
</td>
</tr>
</table>
【받은/보낸메세지】표시수 <b>$max_gyo</b> 건.<br>
<hr size=0>
EOM
	open(IN,"$message_file");
	@MESSAGE_LOG = <IN>;
	close(IN);

        open(IN, "$battle_file");
        @battle_log = <IN>;
        close(IN);

	$hit=0;$i=1;
	foreach(@MESSAGE_LOG){
		($pid,$hid,$hname,$hmessage,$hhname,$htime) = split(/<>/);
		if($kid eq "$pid"){
			if($max_gyo < $i) { last; }
			print "<font style=font-size:9pt>&nbsp;&nbsp;<b>$hname</b>님이 <b>$hmessage</b> (이)라고 보내왔습니다.($htime)</font><br>\n";
			$hit=1;$i++;
		}elsif($kid eq "$hid"){
			print "<font style=font-size:9pt>&nbsp;&nbsp;<b>$hhname님</b>에게 <b>$hmessage</b> (이)라고 보냈습니다.($htime)</font><br>\n";
		}
	}
	if(!$hit){ print "<font style=font-size:9pt>&nbsp;&nbsp;$kname님에게 도착한 메세지가 없습니다.</font><br>\n"; }
	print "<hr size=0>";
      if($baloguse){
        print "【당신의 전투기록들】표시수 <b>$max_blog</b> 건.<br>";

        $hit=0;$i=1;
        foreach(@battle_log){
                ($bdate,$bid,$bn,$bround,$bwin) = split(/<>/);
                if($kid eq "$bid"){
                        if($max_blog < $i) { last; }
                        if($bwin) {print "<font style=font-size:9pt>&nbsp;&nbsp;VS $bn : $bround 라운드만에 승리!! ($bdate)</font><br>\n";}else{print "<font style=font-size:9pt>&nbsp;&nbsp;VS $bn : $bround 라운드만에 패배.. ($bdate)</font><br>\n";}
			$hit=1;$i++;
                 }
	  }
        if(!$hit){ print "<font style=font-size:9pt>&nbsp;&nbsp;당신은 아직까지 싸운적이 없습니다.</font><br>\n"; }
	print "<hr size=0>";
      }

	&footer;

	# Lock 해제
	if ($lockkey eq 3) { &file'unlock; }
	else { if(-e $lockfile) { unlink($lockfile); } }

	$chara_flag=0;
	exit;
}

#--------------#
#    메세지    #
#--------------#
sub message {
	if($in{'mes'} eq "") { &error("메세지 내용이 없습니다."); }
	if($in{'mesid'} eq "") { &error("메세지를 보낼 상대방을 선택하지 않으셨습니다."); }

	&get_time;

	# Lock 파일
	if ($lockkey eq 1) { &lock1; }
	elsif ($lockkey eq 2) { &lock2; }
	elsif ($lockkey eq 3) { &file'lock; }

	open(IN,"$message_file");
	@mes_regist = <IN>;
	close(IN);

	open(IN,"$chara_file");
	@MESSAGE = <IN>;
	close(IN);

	foreach(@MESSAGE) {
		($did,$dpass,$dsite,$durl,$dname) = split(/<>/);
		if($in{'mesid'} eq "$did") { last; }
	}

	$mes_max = @mes_regist;

	if($mes_max > $max) { pop(@mes_regist); }

	unshift(@mes_regist,"$in{'mesid'}<>$in{'id'}<>$in{'name'}<>$in{'mes'}<>$dname<>$gettime<>\n");

	open(OUT,">$message_file");
	print OUT @mes_regist;
	close(OUT);

	# Lock 해제
	if ($lockkey eq 3) { &file'unlock; }
	else { if(-e $lockfile) { unlink($lockfile); } }

	&header;

	print <<"EOM";
<img src="$title6"><br>
<hr size=0><br>
<form action="$script" method="post">
<input type=hidden name=mode value=log_in>
<input type=hidden name=id value="$in{'id'}">
<input type=hidden name=pass value="$in{'pass'}">
<center>
$dname님에게 메세지를 성공적으로 보냈습니다. <input type=submit value="To Status" style='font-size:9pt;background-color:gray;border-style:none;width:100;height:20;color:white;font-family:tahoma'></center>
</form>
EOM
	&footer;
	exit;
}

#------------#
#    전투    #
#------------#
sub battle {
	if($battle_flag) { &error("현재 전투중입니다. 잠시 기다린 후 싸워주십시오."); }

	$battle_flag=1;$ratk1=1;$ratk2=1;

	open(IN,"$chara_file");
	@battle = <IN>;
	close(IN);

      open(IN,"$item_file");
	@battle_item = <IN>;
	close(IN);

	open(IN,"$magic_file");
	@MAGIC = <IN>;
	close(IN);

	foreach(@battle){
        ($kid,$kpass,$ksite,$kurl,$kname,$ksex,$kchara,$kn_0,$kn_1,$kn_2,$kn_3,$kn_4,$kn_5,$kn_6,$krace,$kclass,$khp,$kmaxhp,$kmp,$kmaxmp,$kex,$klv,$kgold,$ktotal,$kkati,$kitem,$kitem1,$kitem2,$kmons,$khost,$kdate,$kwab_0,$kwab_1,$kwab_2,$kab_0,$kab_1,$kab_2,$kab_3,$kab_4,$kab_5,$kab_6,$kab_7,$kab_8,$kab_9,$kab_10,$kabpint,$kwskill,$kwskiti) = split(/<>/);
		if($in{'id'} eq "$kid") { last; }
	}

	$ltime = time();
	$ltime = $ltime - $kdate;
	$vtime = $b_time - $ltime;
	$mtime = $m_time - $ltime;

	if($ltime < $b_time and $ktotal) {
		&error("$vtime초 후에 실행해주세요.\n");
	}

	&read_winner;
	if($wid eq $kid) { &error("당신이 현재 최강자입니다."); }
	if($champ_limit) {
           if($kurl eq $lurl) { &error("최강자가 바뀔때까지는 싸울 수가 없습니다."); }
      }

	if($kitem){
		foreach(@battle_item){
                        ($ci_no,$ci_name,$ci_dmg,$i_gold,$ci_kind,$ci_wkind,$ci_ref,$i_cls) = split(/<>/);
			if($kitem eq $ci_no){last;}
		}
	}
        # 아이템 데이타 세부적 분류(무기)
        ($ci_mindmg,$tmp1) = split(/D/,$ci_dmg);
        ($ci_maxdmg,$ci_pdmg) = split(/p/,$tmp1);
        ($ci_wkind,$ci_whand) = split(/a/,$ci_wkind);

	if($kitem2){
		foreach(@battle_item){
                        ($ci_no2,$ci_name2,$ci_av,$i_gold,$ci_kind2,$ci_wkind2,$ci_ref2,$i_cls) = split(/<>/);
			if($kitem2 eq $ci_no2){last;}
		}
	}
      ($tmp1,$tmp2) = split(/a/,$ci_wkind2);
      if($tmp1 == 1){$ci_minuses1=$tmp2;}

       if($kitem1){
              foreach(@battle_item){
                        ($ci_no1,$ci_name1,$ci_av1,$i_gold,$ci_kind1,$ci_wkind1,$ci_ref1,$i_cls) = split(/<>/);
                     if($kitem1 eq $wi_no1){last;}
              }
       }

	if($witem){
		foreach(@battle_item){
              		($wi_no,$wi_name,$wi_dmg,$i_gold,$wi_kind,$wi_wkind,$wi_ref,$i_cls) = split(/<>/);
			if($witem eq $wi_no){last;}
		}

	}
        # 아이템 데이타 세부적 분류(무기)
        ($wi_mindmg,$tmp1) = split(/D/,$wi_dmg);
        ($wi_maxdmg,$wi_pdmg) = split(/p/,$tmp1);
        ($wi_wkind,$wi_whand) = split(/a/,$wi_wkind);

	if($witem2){
		foreach(@battle_item){
              		($wi_no2,$wi_name2,$wi_av,$i_gold,$wi_kind2,$wi_wkind2,$wi_ref2,$i_cls) = split(/<>/);
			if($witem2 eq $wi_no2){last;}
		}
	}
      ($tmp1,$tmp2) = split(/a/,$wi_wkind2);
      if($tmp1 == 1){$wi_minuses1=$tmp2;}

       if($witem1){
              foreach(@battle_item){
                           ($wi_no1,$wi_name1,$wi_av1,$i_gold,$wi_kind1,$wi_wkind1,$wi_ref1,$i_cls) = split(/<>/);
                     if($witem1 eq $wi_no1){last;}
              }
       }

      if($kwskill != 0){
      $hit=0;
        foreach(@MAGIC){
          ($mg_no,$mg_lv,$mg_name,$mg_mp,$mg_time,$mg_kind,$mg_dta1,$mg_dta2,$mg_re,$mg_cls)=split(/<>/);
          if($kwskill eq "$mg_no"){$hit=1;last;}
        }
      }
      if($mg_kind eq 1){
        #공격마법을 위한 세부분류
        ($mg_mindmg,$mg_maxdmg) = split(/D/,$mg_dta1);
      }

      if($wwskill != 0){
      $hit=0;
        foreach(@MAGIC){
          ($wmg_no,$wmg_lv,$wmg_name,$wmg_mp,$wmg_time,$wmg_kind,$wmg_dta1,$wmg_dta2,$wmg_re,$wmg_cls)=split(/<>/);
          if($kwskill eq "$mg_no"){$hit=1;last;}
        }
      }
      if($wmg_kind eq 1){
        #공격마법을 위한 세부분류
        ($wmg_mindmg,$wmg_maxdmg) = split(/D/,$wmg_dta1);
      }

        #도전자회피율
        $ces1 = $kab_7 * 5 + $kn_2 - $ci_minuses1;
        #도전자받기
        $ces2 = int($kwab_0 / 3) + ($kab_8*5)+$ci_av1;

        #최강자회피율
        $wes1 = $wab_7 * 5 + $wn_2 - $wi_minuses1;
        #최강자받기
        $wes2 = int($wwab_0 / 3) + ($wab_8*5)+$wi_av1;

        #장비한 무기의 기능포인트가 있을 경우 능력치*5% 명중률 상승
        if($ci_wkind eq 1&$kab_0>=1){$cpg+=int($kab_0*0.5);}
        if($ci_wkind eq 2&$kab_1>=1){$cpg+=int($kab_1*0.5);}
        if($ci_wkind eq 3&$kab_2>=1){$cpg+=int($kab_2*0.5);}
        if($ci_wkind eq 4&$kab_3>=1){$cpg+=int($kab_3*0.5);}
        if($ci_wkind eq 5&$kab_4>=1){$cpg+=int($kab_4*0.5);}
        $cpg=$kwab_0-$wes1;
        #무기의 기능포인트에 따른 라운드당 공격횟수 설정
        if(($ci_wkind eq 1&$kab_0 eq 3)||($ci_wkind eq 2&$kab_1 eq 3)||($ci_wkind eq 3&$kab_2 eq 3)||($ci_wkind eq 4&$kab_3 eq 3)||($ci_wkind eq 5&$kab_4 eq 3)){$ratk1=2;}
        elsif(($ci_wkind eq 1&$kab_0 eq 4)||($ci_wkind eq 2&$kab_1 eq 4)||($ci_wkind eq 3&$kab_2 eq 4)||($ci_wkind eq 4&$kab_3 eq 4)||($ci_wkind eq 5&$kab_4 eq 4)){$ratk1=3;}
        elsif(($ci_wkind eq 1&$kab_0 eq 5)||($ci_wkind eq 2&$kab_1 eq 5)||($ci_wkind eq 3&$kab_2 eq 5)||($ci_wkind eq 4&$kab_3 eq 5)||($ci_wkind eq 5&$kab_4 eq 5)){$ratk1=4;}

        #최강자
        if($wi_wkind eq 1&$wab_0>=1){$wpg+=int($wab_0*0.5);}
        if($wi_wkind eq 2&$wab_1>=1){$wpg+=int($wab_1*0.5);}
        if($wi_wkind eq 3&$wab_2>=1){$wpg+=int($wab_2*0.5);}
        if($wi_wkind eq 4&$wab_3>=1){$wpg+=int($wab_3*0.5);}
        if($wi_wkind eq 5&$wab_4>=1){$wpg+=int($wab_4*0.5);}
        $wpg=$wwab_0-$ces1;
        if(($wi_wkind eq 1&$wab_0 eq 3)||($wi_wkind eq 2&$wab_1 eq 3)||($wi_wkind eq 3&$wab_2 eq 3)||($wi_wkind eq 4&$wab_3 eq 3)||($wi_wkind eq 5&$wab_4 eq 3)){$ratk2=2;}
        elsif(($wi_wkind eq 1&$wab_0 eq 4)||($wi_wkind eq 2&$wab_1 eq 4)||($wi_wkind eq 3&$wab_2 eq 4)||($wi_wkind eq 4&$wab_3 eq 4)||($wi_wkind eq 5&$wab_4 eq 4)){$ratk2=3;}
        elsif(($wi_wkind eq 1&$wab_0 eq 5)||($wi_wkind eq 2&$wab_1 eq 5)||($wi_wkind eq 3&$wab_2 eq 5)||($wi_wkind eq 4&$wab_3 eq 5)||($wi_wkind eq 5&$wab_4 eq 5)){$ratk2=4;}

	$khp_flg = $khp;
	$whp_flg = $whp;
      $kre=$kwab_1;
      $wre=$wwab_1;

	$i=1;$j=0;@battle_date=();$castround1=0;$castround2=0;$maguse1=0;$maguse2=0;
	foreach(1..$round) {

          $dmg1=0;$dmg11=0;$dmg12=0;$dmg13=0;$magicdmg1=0;$mg_regist1=0;
          $com1="";$com11="";$com12="";$com13="";$tmpcom="";$c1="";$c2="";$c3="";$clit1="";$skcom="";

          $dmg2=0;$dmg21=0;$dmg22=0;$dmg23=0;$magicdmg2=0;$mg_regist2=0;
          $com2="";$com21="";$com22="";$com23="";$tmpcom1="";$c21="";$c22="";$c23="";$skcom1="";

            if($maguse1 == 1 & $castround1 != 0){
               if($mgh11 == 8){$khp_flg+=$mgh12;}
               if($mgh14 == 8){$khp_flg+=$mgh15;}
            }
            if($maguse2 == 1 & $castround2 != 0){
               if($mgh21 == 8){$whp_flg+=$mgh22;}
               if($mgh24 == 8){$whp_flg+=$mgh25;}
            }

            #기술사용타이밍과 현재의 타이밍 일치여부
            if(($kwskiti == 1 & $i == 1) || ($kwskiti == 2 & $kmaxhp/3 >= $khp_flg & $maguse1 != 1) || ($kwskiti == 3 & $klv < $wlv & $i == 1) || ($kwskiti == 4)){
             if($mg_mp <= $kmp){
               $kmp-=$mg_mp;
               $maguse1=1;
               $mg_dice=int(rand(100))+1;$reroll=int(rand(100))+1;$wab2roll=int(rand(100))+1;
               if($wab2roll<=$kwab_2 || $wab2roll<=int($kwab_2/10)){$reroll=int($reroll*($klv*0.05));}
               if($wab2roll<=$wwab_2 || $wab2roll<=int($wwab_2/10)){$mg_regist1=1;}
               #백스탭
               if($kwskill == 35){
                  if($mg_dice>=1 & $mg_dice<=50){
                    $skcom="당신이 바람처럼 사라졌다가 $wname 뒤에 슬며시 나타납니다.<br>";$magicsp1=1;
                  }else{$skcom="당신이 재빠르게 움직이지만 $wname(은)는 이미 눈치채고 있습니다.<br>";$magicsp1=4;}
               #돌격
               }elsif($kwskill == 36){
                  if($mg_dice>=1 & $mg_dice<=40){
                    $skcom="당신이 $wname에게 힘차게 돌진합니다.<br>";$magicsp1=2;
                  }else{$skcom="당신이 $wname에게 힘차게 돌진합니다.<br>";$magicsp1=5;}
               }
               #공격마법
               if($mg_kind == 1){
                  if($mg_dice>=1 & $mg_dice<=90){
                   #마법성공
                   foreach(1..$mg_mindmg){$magicdmg1+=int(rand($mg_maxdmg))+1;}
                   $magicdmg1+=$klv;
                    #저항성공
                    if(($reroll<=10 || int($wwab_1/10)>=$reroll || $wwab_1>=$reroll) & $mg_regist1 == 1){
                     #효과소멸
                     $mg_regist1=0;
                     if($mg_re == 1){$skcom="당신이 $mg_name의 주문을 외웁니다. 콰쾅~! 그러나 $wname(은)는 멀쩡히 서 있습니다.<br>";}
                     elsif($mg_re == 3){
                       #효과반감
                       $magicdmg1=int($magicdmg1/2);$skcom="당신이 $mg_name의 주문을 외웁니다. 콰쾅~! <font class=dmg><b>(-$magicdmg1)</b></font><br>";
                       if($magicdmg1<=0){$magicdmg1=0;$skcom="당신이 $mg_name의 주문을 외웁니다. 콰쾅~! 그러나 $wname(은)는 멀쩡히 서 있습니다.<br>";}
                     }else{$skcom="당신이 $mg_name의 주문을 외웁니다. 콰쾅~! <font class=dmg><b>(-$magicdmg1)</b></font><br>";}
                    }else{
                     #저항실패
                     $skcom="당신이 $mg_name의 주문을 외웁니다. 콰쾅~! <font class=dmg><b>(-$magicdmg1)</b></font><br>";
                    }
                  }else{
                    #마법실패
                    $skcom="당신이 중얼중얼 주문을 외우지만, 아무런 일도 벌어지지 않습니다.<br>";
                  }
               #보조마법
               }elsif($mg_kind == 2){
                  if($mg_dice>=1 & $mg_dice<=90){
                     ($mgh11,$mgh12,$mgh13)=split(/q/,$mg_dta1);
                     ($mgh14,$mgh15,$mgh16)=split(/q/,$mg_dta2);
                     $skcom="당신이 $mg_name의 주문을 외웁니다.<br>";
                     if($kwskill == 33){$skcom="당신이 천지가 흔들릴정도로 엄청난 고함을 질러댑니다.<br>";}
                     if($kwskill == 34){$skcom="당신이 재주를 넘듯이 움직입니다.<br>";}
                     if($kwskill == 37){$skcom="당신이 마음속에 숨어있던 흉폭함을 표출하기 시작합니다.<br>";}
                     if($mgh13 == 1 || $mgh16 == 1){
                       if($mgh11 == 1){
                         $cpg+=$mgh12;
                         if($mg_time){$castround1=$mg_time;}
                       }
                       if($mgh11 == 2){
                         $ces1+=$mgh12;
                         if($mg_time){$castround1=$mg_time;}
                       }
                       if($mgh11 == 3){
                         $ci_av+=$mgh12;
                         if($mg_time){$castround1=$mg_time;}
                       }
                       if($mgh11 == 4){
                         $cmg_pdmg=$mgh12;
                         if($mg_time){$castround1=$mg_time;}
                       }
                       if($mgh11 == 5){
                         $kre+=int($mgh12/100);
                         if($mg_time){$castround1=$mg_time;}
                       }
                       if($mgh11 == 6){
                         $ces2+=$mgh12;
                         if($mg_time){$castround1=$mg_time;}
                       }
                       if($mgh11 == 7){
                         ($mgh7,$mgh8)=split(/D/,$mgh12);
                         foreach(1..$mgh7){$hpresto+=int(rand($mgh8))+1;}
                         $hpresto+=$klv;$khp_flg+=$hpresto;
                       }
                       if($mgh11 == 8){
                         if($mg_time){$castround1=$mg_time;}
                       }
                       if($mgh11 == 9){
                         $mag_armor1=$mgh12;
                         if($mg_time){$castround1=$mg_time;}
                       }
                       if($mgh11 == 10){$khp_flg=$kmaxhp;}
                       if($mgh14 == 1){
                         $cpg+=$mgh15;
                         if($mg_time){$castround1=$mg_time;}
                       }
                       if($mgh14 == 2){
                         $ces1+=$mgh15;
                         if($mg_time){$castround1=$mg_time;}
                       }
                       if($mgh14 == 3){
                         $ci_av+=$mgh15;
                         if($mg_time){$castround1=$mg_time;}
                       }
                       if($mgh14 == 4){
                         $cmg_pdmg=$mgh15;
                         if($mg_time){$castround1=$mg_time;}
                       }
                       if($mgh14 == 5){
                         $kre+=int($mgh15/100);
                         if($mg_time){$castround1=$mg_time;}
                       }
                       if($mgh14 == 6){
                         $ces2+=$mgh15;
                         if($mg_time){$castround1=$mg_time;}
                       }
                       if($mgh11 == 7){
                         ($mgh7,$mgh8)=split(/D/,$mgh15);
                         foreach(1..$mgh7){$hpresto+=int(rand($mgh8))+1;}
                         $hpresto+=$klv;$khp_flg+=$hpresto;
                       }
                       if($mgh14 == 8){
                         if($mg_time){$castround1=$mg_time;}
                       }
                       if($mgh14 == 9){
                         $mag_armor1=$mgh15;
                         if($mg_time){$castround1=$mg_time;}
                       }
                       if($mgh14 == 10){$khp_flg=$kmaxhp;}
                       if($khp_flg>$kmaxhp){$khp_flg=$kmaxhp;}
                     }elsif($mgh13 == 2 || $mgh16 == 2){
                       if($reroll<=10 || int($wwab_1/10)>=$reroll || $wwab_1>=$reroll){
                        if($mg_re == 1){$skcom="당신이 $mg_name의 주문을 외웁니다.<br>";}
                        if($kwskill == 33){$skcom="당신이 천지가 흔들릴정도로 엄청난 고함을 질러댑니다.<br>";}
                       }else{
                        $skcom="당신이 $mg_name의 주문을 외우자 이상한 기운이 올라옵니다.<br>";
                        if($kwskill == 33){$skcom="당신이 천지가 흔들릴정도로 엄청난 고함을 질러댑니다.<br>";}
                        if($mgh11 == 1){
                          $wpg-=$mgh12;
                          if($mg_time){$castround1=$mg_time;}
                        }
                        if($mgh11 == 2){
                          $wes1-=$mgh12;
                          if($mg_time){$castround1=$mg_time;}
                        }
                        if($mgh11 == 3){
                          $wi_av-=$mgh12;
                          if($mg_time){$castround1=$mg_time;}
                        }
                        if($mgh11 == 4){
                          $cmg_pdmg1=$mgh12;
                          if($mg_time){$castround1=$mg_time;}
                        }
                        if($mgh11 == 5){
                          $wre-=int($mgh12/100);
                          if($mg_time){$castround1=$mg_time;}
                        }
                        if($mgh11 == 6){
                          $wes2-=$mgh12;
                          if($mg_time){$castround1=$mg_time;}
                        }
                        if($mgh14 == 1){
                          $wpg-=$mgh15;
                          if($mg_time){$castround1=$mg_time;}
                        }
                        if($mgh14 == 2){
                          $wes1-=$mgh15;
                          if($mg_time){$castround1=$mg_time;}
                        }
                        if($mgh14 == 3){
                          $wi_av-=$mgh15;
                          if($mg_time){$castround1=$mg_time;}
                        }
                        if($mgh14 == 4){
                          $cmg_pdmg1=$mgh15;
                          if($mg_time){$castround1=$mg_time;}
                        }
                        if($mgh14 == 5){
                          $wre-=int($mgh15/100);
                          if($mg_time){$castround1=$mg_time;}
                        }
                        if($mgh14 == 6){
                          $wes2-=$mgh15;
                          if($mg_time){$castround1=$mg_time;}
                        }
                       }
                     }
                  }else{
                     $skcom="당신이 중얼중얼 주문을 외우지만, 아무런 일도 벌어지지 않습니다.<br>";
                     if($kwskill == 33){$skcom="당신이 콜록거리며 기침을 해댑니다.<br>";}
                     if($kwskill == 34){$skcom="당신이 재주를 넘듯이 움직이다가 콰당 넘어집니다.<br>";}
                     if($kwskill == 37){$skcom="당신이 마음속에 숨어있던 흉폭함을 표출하려하지만 뜻대로 되지않습니다.<br>";}
                  }
               }
               #스페셜마법
               }elsif($mg_kind == 3){
                  if($mg_dice>=1 & $mg_dice<=90){
                    if($reroll<=10 || int($wwab_1/10)>=$reroll || $wwab_1>=$reroll){
                     $skcom="당신이 중얼중얼 주문을 외우지만, 아무런 일도 벌어지지 않습니다.<br>";
                    }else{
                     #몬스터저항실패
                     $magicdmg1=$whp_flg;
                     $skcom="당신이 $mg_name의 주문을 외웁니다. 콰쾅~! <font class=dmg><b>(-$magicdmg1)</b></font><br>";last;
                    }
                  }else{$skcom="당신이 중얼중얼 주문을 외우지만, 아무런 일도 벌어지지 않습니다.<br>";
               }
             }else{
               $skcom="당신이 주문을 외우려하지만, 정신이 집중되지 않습니다.<br>";
               if($kwskill == 33 || $kwskill == 34 || $kwskill ==35){$skcom="정신이 집중되지않아 기술을 쓸 수 없습니다.<br>";}
             }
            }

          #주도권결정
          $iv1 = int(rand(10))+1;
          $iv2 = int(rand(10))+1;

         $it1=1;
         foreach(1..$ratk1) {

          $tmpdmg=0;
          #명중여부체크
          $cgpg = int(rand(100))+1;
          #받기여부체크 crefroll 도전자 wrefroll 최강자
          $wrefroll = int(rand(100))+1;

          #행운에 따른 명중률 향상
          $luck_roll=int(rand(10))+1;
          if($kn_6>=7 & $kn_6<=12 & $luck_roll > 9) {$cgpg+=int(rand(5))+1;}
          if($kn_6>=13 & $kn_6<=18 & $luck_roll > 8) {$cgpg+=int(rand(10))+1;}
          if($kn_6>=19 & $kn_6<=21 & $luck_roll > 7) {$cgpg+=int(rand(12))+1;}
          if($kn_6>=22 & $luck_roll > 4) {$cppg+=int(rand(15))+1;}

          #43,44,51 방패는 받기율+0.3,5,8%가 더해짐
          if($witem1 eq "0043" || $witem1 eq "0044" || $witem1 eq "0051"){$wrefroll=int($wrefroll*$wi_ref1);}

          #받기실패
          if($wrefroll>=$wes2 || $wrefroll>=91){$wref=0;}
          #받기성공
          elsif($wrefroll<=$wes2 || $wrefroll<=int($wes2/10)){$wref=1;}

          # 도전자가 최강자에게 주는 데미지 계산 (D&D주사위방식 xdyy)
          # x는 돌리는 회수 yy는 굴리는 주사위 면수
          foreach(1..$ci_mindmg){$tmpdmg=int(rand($ci_maxdmg))+1;}
          $tmpdmg+=$ci_pdmg;
          if($kitem == "" || $kitem == 0){$tmpdmg=int(rand(2))+1+$klv;}
          $tmpdmg+=$kab_5+$cmg_pdmg;
          $tmpdmg-=$wmg_pdmg1;

          if($magicsp1 == 1){$tmpdmg=$tmpdmg*3;$magicsp1=0;$ttmp1=1;$ttmp1=1;}
          if($magicsp1 == 2){$tmpdmg=$tmpdmg*2;$ces1-=60;$magicsp1=3;$ttmp1=1;}
          if($magicsp1 == 3){$ces1+=60;$magicsp1=0;}
          if($magicsp1 == 5){$ces1-=60;$magicsp1=6;}
          if($magicsp1 == 6){$ces1+=60;$magicsp1=0;}
          if($magicsp2 == 4){$tmpdmg=$tmpdmg*2;$magicsp2=0;}

          #힘에 따른 데미지 보너스
          if($kn_0>=7 & $kn_0<=9){$tmpdmg+=1;}
          if($kn_0>=10 & $kn_0<=12){$tmpdmg+=2;}
          if($kn_0>=13 & $kn_0<=15){$tmpdmg+=3;}
          if($kn_0>=16 & $kn_0<=18){$tmpdmg+=4;}
          if($kn_0>=19 & $kn_0<=21){$tmpdmg+=5;}
          if($kn_0>=22 & $kn_0<=25){$tmpdmg+=6;}

                  # 도전자 데미지 계산
                  if($cgpg<=int($cpg/10)) {
                     #크리티컬
                     if($tmpdmg>$whp_flg){$tmpdmg=$whp_flg;}
                     $tmpcom="당신이 $wname님이 막아낼 틈도 주지않고 순간적으로 공격합니다. <b class=clit>크리티컬!!</b> <font class=dmg><b>(-$tmpdmg)</b></font>";
                  }elsif($cgpg<=$cpg || $cgpg<=10 || $ttmp1 == 1) {
                     # 공격성공
                     $tmpdmg-=$wi_av;$ttmp1=0;
                     # 만약 데미지가 적의 현 에너지보다 크다면 데미지는 적의 현 에너지가 됨.
                     if($tmpdmg>$whp_flg){$dmg1=$whp_flg;}
                     $tmpcom="당신이 $wname님을 공격합니다. <font class=dmg><b>(-$tmpdmg)</b></font>";
                     if($tmpdmg<=0){$tmpcom="당신이 $wname님을 공격했지만, 아무런 피해도 주지 못했습니다.";$tmpdmg=0;}
                     if($wref eq 1 & $wes2 != 0){
                      #적이 받기성공시
                      $tmpdmg-=$wi_ref;
                      $tmpcom="당신의 공격을 $wname님이 막아냈지만, 데미지를 조금 입었습니다.<font class=dmg><b>(-$tmpdmg)</b></font>";
                      if($tmpdmg<=0){$tmpcom="당신이 $wname님을 공격했지만, $wname님이 성공적으로 막아내어 아무런 피해도 주지 못했습니다.";$tmpdmg=0;}
                      #소드브레이커 특수효과
                      if((($wi_no eq "0032" & $wab_4 >= 1) || ($wi_no eq "0053" & $wab_4 >= 1)) & ($wrefroll<=int($wes2/10))){
                       $tmpcom="<font size=3 color=\"#a0b8c8\">당신의 공격을 $wname님이 소드 브레이커로 막아내자 당신의 무기가 박살납니다.</font><br>";
                       $tmpdmg=0;$kitem=0;
                      }
                     }
                  }elsif($cgpg>=$cpg || $cgpg>=91) {
                     # 공격실패
                     $tmpdmg=0;
                     $tmpcom="당신이 $wname님을 빗맞췄습니다.";
                  }
                  if($it1 eq 1){$com1=$tmpcom;$dmg1=$tmpdmg;}
                  if($it1 eq 2){$com11=$tmpcom;$dmg11=$tmpdmg;$c1="<br>";}
                  if($it1 eq 3){$com12=$tmpcom;$dmg12=$tmpdmg;$c2="<br>";}
                  if($it1 eq 4){$com13=$tmpcom;$dmg13=$tmpdmg;$c3="<br>";}

	  if(($wlv - $klv) >= $level_sa & $i eq 1 & it1 eq 1) {
            $sa = $wlv - $klv;
            $clit1 .= "<p><font size=4 color=blue><b>$kname의 몸에서 파란 불꽃같은 것이 솟아오른다….</b></font><br>";
            $dmg1+=$kmaxhp;
         }
        $it1++;
        }

            #기술사용타이밍과 현재의 타이밍 일치여부
            if(($wwskiti == 1 & $i == 1) || ($wwskiti == 2 & $wmaxhp/3 >= $whp_flg & $maguse2 != 1) || ($wwskiti == 3 & $wlv < $klv & $i == 1) || ($wwskiti == 4)){
             if($wmg_mp <= $wmp){
               $wmp-=$wmg_mp;
               $maguse2=1;
               $mg_dice=int(rand(100))+1;$reroll=int(rand(100))+1;$wab2roll=int(rand(100))+1;
               if($wab2roll<=$wwab_2 || $wab2roll<=int($wwab_2/10)){$reroll=int($reroll*($wlv*0.05));}
               if($kab2roll<=$kwab_2 || $kab2roll<=int($kwab_2/10)){$mg_regist2=1;}
               #백스탭
               if($wwskill == 35){
                  if($mg_dice>=1 & $mg_dice<=50){
                    $skcom1="$wname님이 바람처럼 사라졌다가 당신의 뒤에 슬며시 나타납니다.<br>";$magicsp2=1;
                  }else{$skcom1="$wname님이 재빠르게 움직이는듯하지만 뻔히 보입니다.<br>";$magicsp2=4;}
               #돌격
               }elsif($wwskill == 36){
                  if($mg_dice>=1 & $mg_dice<=40){
                    $skcom1="$wname님이 당신을 향해 돌진해옵니다.<br>";$magicsp2=2;
                  }else{$skcom1="$wname님이 당신을 향해 돌진해옵니다.<br>";$magicsp2=5;}
               }
               #공격마법
               if($wmg_kind == 1){
                  if($mg_dice>=1 & $mg_dice<=90){
                   #마법성공
                   foreach(1..$wmg_mindmg){$magicdmg2+=int(rand($wmg_maxdmg))+1;}
                   $magicdmg2+=$wlv;
                    #저항성공
                    if(($reroll<=10 || int($kwab_1/10)>=$reroll || $kwab_1>=$reroll) & $mg_regist2 == 1){
                     #효과소멸
                     $mg_regist2=0;
                     if($wmg_re == 1){$skcom1="$wname님이 $wmg_name의 주문을 외웁니다. 콰쾅~! 그러나 하나도 아프지 않습니다.<br>";}
                     elsif($wmg_re == 3){
                       #효과반감
                       $magicdmg2=int($magicdmg2/2);$skcom1="$wname님이 $wmg_name의 주문을 외웁니다. 콰쾅~! <font class=dmg><b>(-$magicdmg2)</b></font><br>";
                       if($magicdmg2<=0){$magicdmg2=0;$skcom1="$wname님이 $wmg_name의 주문을 외웁니다. 콰쾅~! 그러나 하나도 아프지 않습니다.<br>";}
                     }else{$skcom1="$wname님이 $wmg_name의 주문을 외웁니다. 콰쾅~! <font class=dmg><b>(-$magicdmg2)</b></font><br>";}
                    }else{
                     #저항실패
                     $skcom1="$wname님이 $wmg_name의 주문을 외웁니다. 콰쾅~! <font class=dmg><b>(-$magicdmg2)</b></font><br>";
                    }
                  }else{
                    #마법실패
                    $skcom1="$wname님이 중얼중얼 주문을 외우지만, 아무런 일도 벌어지지 않습니다.<br>";
                  }
               #보조마법
               }elsif($wmg_kind == 2){
                  if($mg_dice>=1 & $mg_dice<=90){
                     ($mgh21,$mgh22,$mgh23)=split(/q/,$wmg_dta1);
                     ($mgh24,$mgh25,$mgh26)=split(/q/,$wmg_dta2);
                     $skcom1="$wname님이 $wmg_name의 주문을 외웁니다.<br>";
                     if($wwskill == 33){$skcom1="$wname님이 천지가 흔들릴정도로 엄청난 고함을 질러댑니다.<br>";}
                     if($wwskill == 34){$skcom1="$wname님이 재주를 넘듯이 움직입니다.<br>";}
                     if($wwskill == 37){$skcom1="$wname님이 마음속에 숨어있던 흉폭함을 표출하기 시작합니다.<br>";}
                     if($mgh23 == 1 || $mgh26 == 1){
                       if($mgh21 == 1){
                         $wpg+=$mgh22;
                         if($wmg_time){$castround2=$wmg_time;}
                       }
                       if($mgh21 == 2){
                         $wes1+=$mgh22;
                         if($wmg_time){$castround2=$wmg_time;}
                       }
                       if($mgh21 == 3){
                         $wi_av+=$mgh22;
                         if($wmg_time){$castround2=$wmg_time;}
                       }
                       if($mgh21 == 4){
                         $wmg_pdmg=$mgh22;
                         if($wmg_time){$castround2=$wmg_time;}
                       }
                       if($mgh21 == 5){
                         $wre+=int($mgh22/100);
                         if($wmg_time){$castround2=$wmg_time;}
                       }
                       if($mgh21 == 6){
                         $wes2+=$mgh22;
                         if($wmg_time){$castround2=$wmg_time;}
                       }
                       if($mgh21 == 7){
                         ($mgh7,$mgh8)=split(/D/,$mgh22);
                         foreach(1..$mgh7){$hpresto+=int(rand($mgh8))+1;}
                         $hpresto+=$klv;$whp_flg+=$hpresto;
                       }
                       if($mgh21 == 8){
                         if($wmg_time){$castround2=$wmg_time;}
                       }
                       if($mgh21 == 9){
                         $mag_armor2=$mgh22;
                         if($wmg_time){$castround2=$wmg_time;}
                       }
                       if($mgh21 == 10){$whp_flg=$wmaxhp;}
                       if($mgh24 == 1){
                         $wpg+=$mgh25;
                         if($wmg_time){$castround2=$wmg_time;}
                       }
                       if($mgh24 == 2){
                         $wes1+=$mgh25;
                         if($wmg_time){$castround2=$wmg_time;}
                       }
                       if($mgh24 == 3){
                         $wi_av+=$mgh25;
                         if($wmg_time){$castround2=$wmg_time;}
                       }
                       if($mgh24 == 4){
                         $wmg_pdmg=$mgh25;
                         if($wmg_time){$castround2=$wmg_time;}
                       }
                       if($mgh24 == 5){
                         $wre+=int($mgh25/100);
                         if($wmg_time){$castround2=$wmg_time;}
                       }
                       if($mgh24 == 6){
                         $wes2+=$mgh25;
                         if($wmg_time){$castround2=$wmg_time;}
                       }
                       if($mgh21 == 7){
                         ($mgh7,$mgh8)=split(/D/,$mgh5);
                         foreach(1..$mgh7){$hpresto+=int(rand($mgh8))+1;}
                         $hpresto+=$klv;$whp_flg+=$hpresto;
                       }
                       if($mgh4 == 8){
                         if($wmg_time){$castround2=$wmg_time;}
                       }
                       if($mgh4 == 9){
                         $mag_armor2=$mgh25;
                         if($wmg_time){$castround2=$wmg_time;}
                       }
                       if($mgh24 == 10){$whp_flg=$wmaxhp;}
                       if($whp_flg>$wmaxhp){$whp_flg=$wmaxhp;}
                     }elsif($mgh3 == 2 || $mgh6 == 2){
                       if($reroll<=10 || int($kwab_1/10)>=$reroll || $kwab_1>=$reroll){
                        if($wmg_re == 1){$skcom1="$wname님이 $wmg_name의 주문을 외웁니다.<br>";}
                        if($wwskill == 33){$skcom1="$wname님이 천지가 흔들릴정도로 엄청난 고함을 질러댑니다.<br>";}
                       }else{
                        $skcom1="$wname님이 $wmg_name의 주문을 외우자 이상한 기운이 올라옵니다.<br>";
                        if($wwskill == 33){$skcom1="$wname님이 천지가 흔들릴정도로 엄청난 고함을 질러댑니다.<br>";}
                        if($mgh21 == 1){
                          $cpg-=$mgh22;
                          if($wmg_time){$castround2=$wmg_time;}
                        }
                        if($mgh21 == 2){
                          $ces1-=$mgh22;
                          if($wmg_time){$castround2=$wmg_time;}
                        }
                        if($mgh21 == 3){
                          $ci_av-=$mgh22;
                          if($wmg_time){$castround2=$wmg_time;}
                        }
                        if($mgh21 == 4){
                          $wmg_pdmg1=$mgh22;
                          if($wmg_time){$castround2=$wmg_time;}
                        }
                        if($mgh21 == 5){
                          $kre-=int($mgh22/100);
                          if($wmg_time){$castround2=$wmg_time;}
                        }
                        if($mgh21 == 6){
                          $ces2-=$mgh22;
                          if($wmg_time){$castround2=$wmg_time;}
                        }
                        if($mgh24 == 1){
                          $cpg-=$mgh25;
                          if($wmg_time){$castround2=$wmg_time;}
                        }
                        if($mgh24 == 2){
                          $ces1-=$mgh25;
                          if($wmg_time){$castround2=$wmg_time;}
                        }
                        if($mgh24 == 3){
                          $ci_av-=$mgh25;
                          if($wmg_time){$castround2=$wmg_time;}
                        }
                        if($mgh24 == 4){
                          $wmg_pdmg1=$mgh25;
                          if($wmg_time){$castround2=$wmg_time;}
                        }
                        if($mgh24 == 5){
                          $kre-=int($mgh25/100);
                          if($wmg_time){$castround2=$wmg_time;}
                        }
                        if($mgh24 == 6){
                          $ces2-=$mgh25;
                          if($wmg_time){$castround2=$wmg_time;}
                        }
                       }
                     }
                  }else{
                     $skcom1="$wname님이 중얼중얼 주문을 외우지만, 아무런 일도 벌어지지 않습니다.<br>";
                     if($wwskill == 33){$skcom1="$wname님이 콜록거리며 기침을 해댑니다.<br>";}
                     if($wwskill == 34){$skcom1="$wname님이 재주를 넘듯이 움직이다가 콰당 넘어집니다.<br>";}
                     if($wwskill == 37){$skcom1="$wname님이 마음속에 숨어있던 흉폭함을 표출하려하지만 뜻대로 되지않습니다.<br>";}
                  }
               }
               #스페셜마법
               }elsif($wmg_kind == 3){
                  if($mg_dice>=1 & $mg_dice<=90){
                    if($reroll<=10 || int($kwab_1/10)>=$reroll || $kwab_1>=$reroll){
                     $skcom1="$wname님이 중얼중얼 주문을 외우지만, 아무런 일도 벌어지지 않습니다.<br>";
                    }else{
                     #저항실패
                     $magicdmg2=$khp_flg;
                     $skcom1="$wname님이 $wmg_name의 주문을 외웁니다. 콰쾅~! <font class=dmg><b>(-$magicdmg2)</b></font><br>";last;
                    }
                  }else{$skcom1="$wname님이 중얼중얼 주문을 외우지만, 아무런 일도 벌어지지 않습니다.<br>";
               }
             }else{
               $skcom1="$wname님이 주문을 외우려하지만, 정신이 집중되지 않습니다.<br>";
               if($wwskill == 33 || $wwskill == 34 || $wwskill ==35){$skcom1="$wname님이 뭔가를 하려하다 맙니다.<br>";}
             }
            }

        $it2=1;
        foreach(1..$ratk2) {

          $tmpdmg1=0;
          #받기여부체크 crefroll 도전자 wrefroll 최강자
          $crefroll = int(rand(100))+1;

          #43,44,51 방패는 받기율+0.3,5,8%가 더해짐
          if($citem1 eq "0043" || $citem1 eq "0044" || $citem1 eq "0051"){$crefroll=int($crefroll*$ci_ref1);}

          #받기실패
          if($crefroll>=$ces2 || $crefroll>=91){$cref=0;}
          #받기성공
          elsif($crefroll<=$ces2 || $crefroll<=10){$cref=1;}

          # 최강자가 도전자에게 주는 데미지 계산 (D&D주사위방식 xdyy)
          # x는 돌리는 회수 yy는 굴리는 주사위 면수
          foreach(1..$wi_mindmg){$tmpdmg1=int(rand($wi_maxdmg))+1;}
          $tmpdmg1+=$wi_pdmg;
          if($witem == "" || $witem == 0){$tmpdmg1=int(rand(2))+1+$wlv;}
          $tmpdmg1+=$wab_5+$wmg_pdmg;
          $tmpdmg1-=$cmg_pdmg1;

          if($magicsp2 == 1){$tmpdmg1=$tmpdmg1*3;$magicsp2=0;$ttmp2=1;}
          if($magicsp2 == 2){$tmpdmg1=$tmpdmg1*2;$wes1-=60;$magicsp2=3;$ttmp2=1;}
          if($magicsp2 == 3){$wes1+=60;$magicsp2=0;}
          if($magicsp2 == 5){$wes1-=60;$magicsp2=6;}
          if($magicsp2 == 6){$wes1+=60;$magicsp2=0;}
          if($magicsp1 == 4){$tmpdmg1=$tmpdmg1*2;$magicsp1=0;}

          #힘에 따른 데미지 보너스
          if($wn_0>=7 & $wn_0<=9){$tmpdmg1+=1;}
          if($wn_0>=10 & $wn_0<=12){$tmpdmg1+=2;}
          if($wn_0>=13 & $wn_0<=15){$tmpdmg1+=3;}
          if($wn_0>=16 & $wn_0<=18){$tmpdmg1+=4;}
          if($wn_0>=19 & $wn_0<=21){$tmpdmg1+=5;}
          if($wn_0>=22 & $wn_0<=25){$tmpdmg1+=6;}

          #명중여부체크
          $wgpg = int(rand(100))+1;

          #행운에 따른 명중률 향상
          $luck_roll=int(rand(10))+1;
          if($wn_6>=7 & $wn_6<=12 & $luck_roll > 9) {$wgpg+=int(rand(5))+1;}
          if($wn_6>=13 & $wn_6<=18 & $luck_roll > 8) {$wgpg+=int(rand(10))+1;}
          if($wn_6>=19 & $wn_6<=21 & $luck_roll > 7) {$wgpg+=int(rand(12))+1;}
          if($wn_6>=22 & $luck_roll > 4) {$wgpg+=int(rand(15))+1;}

 		# 최강자 데미지 계산
                  if($wgpg<=int($wpg/10)) {
                     # 크리티컬
                     if($tmpdmg1>$khp_flg){$tmpdmg1=$khp_flg;}
                     $tmpcom1 = "$wname님이 당신이 막아낼 틈도 주지않고 순간적으로 공격합니다. <b class=clit>크리티컬!!</b> <font class=dmg><b>(-$tmpdmg1)</b></font>";
                  }elsif($wgpg<=int($wpg) || $wgpg<=10 || $ttmp2 == 1) {
                     # 공격성공
                     $tmpdmg1-=$ci_av;$ttmp2=0;
                     # 만약 데미지가 도전자의 현 에너지보다 크다면 데미지는 도전자의 현 에너지가 됨.
                     if($tmpdmg1>$khp_flg) {$dmg2=$khp_flg;}
                     $tmpcom1 = "$wname님이 당신을 공격합니다. <font class=dmg><b>(-$tmpdmg1)</b></font>";
                     if($tmpdmg1<=0) { $tmpcom1 = "$wname님이 당신을 공격했지만, 아무런 피해도 주지 못했습니다."; $tmpdmg1=0; }
                     if($cref eq 1 & $ces2 != 0){
                      #도전자가 받기성공시
                      $tmpdmg1 -= $ci_av;
                      $tmpcom1 = "$wname님의 공격을 당신이 막아냈지만, 데미지를 조금 입었습니다. <font class=dmg><b>(-$tmpdmg1)</b></font>";
                      if($tmpdmg1<=0) { $tmpcom1 = "$wname님이 당신을 공격했지만, 당신이 성공적으로 막아내어 아무런 피해도 주지 못했습니다."; $tmpdmg1=0; }
                      #소드브레이커 특수효과
                      if((($ci_no eq "0032" & $cab_4 >= 1) || ($ci_no eq "0053" & $cab_4 >= 1)) & $crefroll<=int($ces2/10)){
                       $tmpcom1="<font size=3 color=\"#a0b8c8\">$wname님의 공격을 당신이 소드 브레이커로 막아내자 $wname님의 무기가 박살납니다.</font><br>";
                       $tmpdmg1=0;$witem=0;
                      }
                     }
                  }elsif($wgpg>=int($wpg) || $wgpg>=91) {
                     # 공격실패
                     $tmpdmg1 = 0;
                     $tmpcom1 ="$wname님이 당신을 빗맞췄습니다.";
                  }
                  if($it2 eq 1){$com2=$tmpcom1;$dmg2=$tmpdmg1;}
                  if($it2 eq 2){$com21=$tmpcom1;$dmg21=$tmpdmg1;$c21="<br>";}
                  if($it2 eq 3){$com22=$tmpcom1;$dmg22=$tmpdmg1;$c22="<br>";}
                  if($it2 eq 4){$com23=$tmpcom1;$dmg23=$tmpdmg1;$c23="<br>";}
        $it2++;
        }

        #매 라운드마다 1 ~ 최강자레벨 / 2 까지의 랜덤적인 경험치를 획득
        $tmp2+=int(((rand($wlv))+1)/2);

         if($ratk1 eq 1){$lastdmg1=$dmg1;}
         if($ratk1 eq 2){$lastdmg1=$dmg1+$dmg11;}
         if($ratk1 eq 3){$lastdmg1=$dmg1+$dmg11+$dmg12;}
         if($ratk1 eq 4){$lastdmg1=$dmg1+$dmg11+$dmg12+$dmg13;}

         if($ratk2 eq 1){$lastdmg2=$dmg2;}
         if($ratk2 eq 2){$lastdmg2=$dmg2+$dmg21;}
         if($ratk2 eq 3){$lastdmg2=$dmg2+$dmg21+dmg22;}
         if($ratk2 eq 4){$lastdmg2=$dmg2+$dmg21+dmg22+dmg23;}

		$battle_date[$j] = <<"EOM";
<TABLE BORDER=0>
<TR><TD CLASS="b2" COLSPAN="3" ALIGN="center">$i Round</TD></TR>
<TR><TD ALIGN="center"><IMG SRC="$img_path/$chara_img[$kchara]"></TD>
<TD>&nbsp;</TD>
<TD ALIGN="center"><IMG SRC="$img_path/$chara_img[$wchara]"></TD></TR>
<TR><TD>
<TABLE BORDER=1 CELLSPACING=0 BORDERCOLORDARK=WHITE BORDERCOLORLIGHT=BLACK>
<TR><TD CLASS="b1">이름</TD><TD CLASS="b1">HP</TD><TD CLASS="b1">직업</TD><TD CLASS="b1">LV</TD></TR>
<TR><TD>$kname</TD><TD>$khp_flg\/$kmaxhp</TD><TD>$chara_class[$kclass]</TD><TD>$klv</TD></TR></TABLE>
</TD>
<TD><FONT SIZE=5 COLOR="#9999DD">VS</FONT></TD>
<TD>
<TABLE BORDER=1 CELLSPACING=0 BORDERCOLORDARK=WHITE BORDERCOLORLIGHT=BLACK>
<TR><TD CLASS="b1">이름</TD><TD CLASS="b1">HP</TD><TD CLASS="b1">직업</TD><TD CLASS="b1">LV</TD></TR>
<TR><TD>$wname</TD><TD>$whp_flg\/$wmaxhp</TD><TD>$chara_class[$wclass]</TD><TD>$wlv</TD></TR></TABLE></TD></TR></TABLE>
<p>
$skcom $clit1 $com1 $c1 $com11 $c2 $com12 $c3 $com13<br>
$skcom1 $com2 $c21 $com21 $c22 $com23 $c22 $com23<br>
EOM
        #주도권에 따른 선공여부
          if($iv1>=$iv2) {
           #도전자 선공
            $whp_flg-=$lastdmg1+$magicdmg1;
            if($whp_flg<= 0){$win=1;last;}
            $khp_flg-=$lastdmg2+$magicdmg2;
            if($khp_flg<=0){$win=0;last;}
          }else{
           #최강자 선공
            $khp_flg-=$lastdmg2+$magicdmg2;
            if($khp_flg <= 0){$win=0;last;}
            $whp_flg-=$lastdmg1+$magicdmg1;
            if($whp_flg <= 0){$win=1;last;}
         }
		$i++;
		$j++;
            $castround1--;$castround2--;
            if($castround1 == 0 & $maguse1 == 1){
               if($mgh13 == 1 || $mgh16 == 1){
                  if($mgh11 == 1){$cpg-=$mgh12;}
                  if($mgh11 == 2){$ces1-=$mgh12;}
                  if($mgh11 == 3){$ci_av-=$mgh12;}
                  if($mgh11 == 4){$cmg_pdmg=0;}
                  if($mgh11 == 5){$kre=$kwab_1;}
                  if($mgh11 == 6){$ces2-=$mgh12;}
                  if($mgh11 == 9){$mag_armor1=0;}
                  if($mgh14 == 1){$cpg-=$mgh15;}
                  if($mgh14 == 2){$ces1-=$mgh15;}
                  if($mgh14 == 3){$ci_av-=$mgh15;}
                  if($mgh14 == 4){$cmg_pdmg=0;}
                  if($mgh14 == 5){$kre=$kwab_1;}
                  if($mgh14 == 6){$ces2-=$mgh15;}
                  if($mgh14 == 9){$mag_armor1=0;}
               }elsif($mgh13 == 2 || $mgh16 == 2){
                  if($mgh11 == 1){$wpg+=$mgh12;}
                  if($mgh11 == 2){$wes1+=$mgh12;}
                  if($mgh11 == 3){$wi_av+=$mgh12;}
                  if($mgh11 == 4){$cmg_pdmg1=0;}
                  if($mgh11 == 5){$wre=$mre;}
                  if($mgh11 == 6){$wes2+=$mgh12;}
                  if($mgh14 == 1){$wpg+=$mgh15;}
                  if($mgh14 == 2){$wes1+=$mgh15;}
                  if($mgh14 == 3){$wi_av+=$mgh15;}
                  if($mgh14 == 4){$cmg_pdmg1=0;}
                  if($mgh14 == 5){$wre=$wwab_1;}
                  if($mgh14 == 6){$wes2+=$mgh15;}
                }
            }
            if($castround2 == 0 & $maguse2 == 1){
               if($mgh23 == 1 || $mgh26 == 1){
                  if($mgh21 == 1){$wpg-=$mgh22;}
                  if($mgh21 == 2){$wes1-=$mgh22;}
                  if($mgh21 == 3){$wi_av-=$mgh22;}
                  if($mgh21 == 4){$wmg_pdmg=0;}
                  if($mgh21 == 5){$wre=$wwab_1;}
                  if($mgh21 == 6){$wes2-=$mgh22;}
                  if($mgh21 == 9){$mag_armor2=0;}
                  if($mgh24 == 1){$wpg-=$mgh25;}
                  if($mgh24 == 2){$wes1-=$mgh25;}
                  if($mgh24 == 3){$wi_av-=$mgh25;}
                  if($mgh24 == 4){$wmg_pdmg=0;}
                  if($mgh24 == 5){$wre=$wwab_1;}
                  if($mgh24 == 6){$wes2-=$mgh25;}
                  if($mgh24 == 9){$mag_armor2=0;}
               }elsif($mgh23 == 2 || $mgh26 == 2){
                  if($mgh21 == 1){$cpg+=$mgh22;}
                  if($mgh21 == 2){$ces1+=$mgh22;}
                  if($mgh21 == 3){$ci_av+=$mgh22;}
                  if($mgh21 == 4){$wmg_pdmg1=0;}
                  if($mgh21 == 5){$kre=$kwab_1;}
                  if($mgh21 == 6){$mes2+=$mgh22;}
                  if($mgh24 == 1){$cpg+=$mgh25;}
                  if($mgh24 == 2){$ces1+=$mgh25;}
                  if($mgh24 == 3){$ci_av+=$mgh25;}
                  if($mgh24 == 4){$wmg_pdmg1=0;}
                  if($mgh24 == 5){$kre=$kwab_1;}
                  if($mgh24 == 6){$ces2+=$mgh25;}
                }
            }
	}

	if($win){
		$ktotal += 1;
		$kkati += 1;
		$tmp2 = int($wlv * (rand($kn_6) + 1));
		$kex += $tmp2;
		$gold = $wlv * 5 + int(rand($kn_6));
		$kmons = $mon_limit;
		$comment = "<b><font size=5>$kname님이 전투에서 승리하셨습니다!!!</font></b><br>";
	}else{
		$ktotal += 1;
		$tmp2 = int($wlv * (rand($kn_6) + 1));
		$kex += $tmp2;
		$gold = int(rand($kn_6));
		$kmons = $mon_limit;
		$comment = "<b><font size=5>$kname님이 전투에서 패배하셨습니다...</font></b><br>";

	}

        if($klv eq 1) { $next_ex=1000; }
        if($klv eq 2) { $next_ex=2000; }
        if($klv eq 3) { $next_ex=4000; }
        if($klv eq 4) { $next_ex=8000; }
        if($klv eq 5) { $next_ex=16000; }
        if($klv eq 6) { $next_ex=32000; }
        if($klv eq 7) { $next_ex=48000; }
        if($klv eq 8) { $next_ex=64000; }
        if($klv eq 9) { $next_ex=80000; }
        if($klv eq 10) { $next_ex=96000; }
        if($klv eq 11) { $next_ex=112000; }
        if($klv eq 12) { $next_ex=128000; }

      #전투로그파일추가
	&get_time;
	open(IN,"$battle_file");
	@blog = <IN>;
       $bat_max = @blog;
       if($bat_max > $batmax){pop(@blog);}
        unshift(@blog, "$gettime<>$kid<>$mname<>$i<>$win<>\n");
	open(OUT,">$battle_file");
	print OUT @blog;
	close(IN);
	close(OUT);

	if($kex > $next_ex & $klv<13) {
            $comment .= "$kname님의 레벨이 상승하였습니다!!!<p>";

            if($kclass eq 0) {$kmaxhp+=int(rand(10))+1;$kmaxmp+=int(rand(4))+1;}
            if($kclass eq 1) {$kmaxhp+=int(rand(4))+1;$kmaxmp+=int(rand(8))+1;}
            if($kclass eq 2) {$kmaxhp+=int(rand(8))+1;$kmaxmp+=int(rand(10))+1;}
            if($kclass eq 3) {$kmaxhp+=int(rand(6))+1;$kmaxmp+=int(rand(6))+1;}
            if($kclass eq 4) {$kmaxhp+=int(rand(8))+1;$kmaxmp+=int(rand(10))+1;}
            if($kclass eq 5) {$kmaxhp+=int(rand(6))+1;$kmaxmp+=int(rand(10))+1;}
            # 생명력보너스 추가
            $kmaxhp+=$kn_1;$kmaxmp+=$kn_4;

            $khp = $kmaxhp;
            $kmp = $kmaxmp;
            $kex = 0;
            $klv += 1;
            $kwab_1 += 2;

            #랜덤하게 특기포인트를 줌.
            $tmp4=int(rand(1));
            if($tmp4){$tmp5=$lvup_abilit+1;}else{$tmp5=$lvup_abilit+2;}
            $kabpint += $tmp5;
            $comment .= "특기포인트가 <b>$tmp5</b> 상승하였습니다.<br>";

            #기능치 상승
            if($kclass eq 0) { $kwab_0+=4;$kwab_1+=2;}
            if($kclass eq 1) { $kwab_0+=2;$kwab_1+=2;}
            if($kclass eq 2) { $kwab_0+=4;$kwab_1+=2;}
            if($kclass eq 3) { $kwab_0+=3;$kwab_1+=2;}
            if($kclass eq 4) { $kwab_0+=4;$kwab_1+=2;}
            if($kclass eq 5) { $kwab_0+=3;$kwab_1+=2;}
	}

	$khp = $khp_flg + int( (rand($kn_3)+rand($kn_6)) / 2 );
	$kmp += int( (rand($kn_5)+rand($kn_6)) / 2 );
	if($khp > $kmaxhp || $khp < 0) { $khp = $kmaxhp; }
	if($kmp > $kmaxmp || $kmp < 0) { $kmp = $kmaxmp; }
	$whp = $whp_flg + int(rand($wn_3)+rand($wn_6));
	$wmp += int( (rand($wn_5)+rand($wn_6)) / 2 );
	if($whp > $wmaxhp) { $whp = $wmaxhp; }
	if($wmp > $wmaxmp) { $wmp = $wmaxmp; }
	$kgold+=$gold;

	# Lock 파일
	if ($lockkey eq 1) { &lock1; }
	elsif ($lockkey eq 2) { &lock2; }
	elsif ($lockkey eq 3) { &file'lock; }

	if($win){
		@new=();
		open(IN,">$winner_file");
		@winnew = <IN>;
		unshift(@new,"$kid<>$kpass<>$ksite<>$kurl<>$kname<>$ksex<>$kchara<>$kn_0<>$kn_1<>$kn_2<>$kn_3<>$kn_4<>$kn_5<>$kn_6<>$krace<>$kclass<>$khp<>$kmaxhp<>$kmp<>$kmaxmp<>$kex<>$klv<>$kgold<>$ktotal<>$kkati<>$kitem<>$kitem1<>$kitem2<>$kmons<>$host<>$date<>$kwab_0<>$kwab_1<>$kwab_2<>$kab_0<>$kab_1<>$kab_2<>$kab_3<>$kab_4<>$kab_5<>$kab_6<>$kab_7<>$kab_8<>$kab_9<>$kab_10<>$kwskill<>$kwskiti<>$win<>$wsite<>$wurl<>$wname<>\n");
		print IN @new;
		close(IN);
	}else{
		$wcount += 1;
		@new=();
		open(IN,">$winner_file");
		@winnew = <IN>;
		unshift(@new,"$wid<>$wpass<>$wsite<>$wurl<>$wname<>$wsex<>$wchara<>$wn_0<>$wn_1<>$wn_2<>$wn_3<>$wn_4<>$wn_5<>$wn_6<>$wrace<>$wclass<>$whp<>$wmaxhp<>$wmp<>$wmaxmp<>$wex<>$wlv<>$wgold<>$wtotal<>$wkati<>$witem<>$witem1<>$witem2<>$wmons<>$host<>$date<>$wwab_0<>$wwab_1<>$wwab_2<>$wab_0<>$wab_1<>$wab_2<>$wab_3<>$wab_4<>$wab_5<>$wab_6<>$wab_7<>$wab_8<>$wab_9<>$wab_10<>$wwskill<>$wwskiti<>$wcount<>$ksite<>$kurl<>$kname<>\n");
		print IN @new;
		close(IN);

		open(IN,"$recode_file");
		@recode = <IN>;
		close(IN);

		($count,$name) = split(/<>/,$recode[0]);

		if($wcount > $count) {
			open(OUT,">$recode_file");
			print OUT "$wcount<>$wname<>$wsite<>$wurl<>\n";
			close(IN);
		}
	}

	# Lock 해제
	if ($lockkey eq 3) { &file'unlock; }
	else { if(-e $lockfile) { unlink($lockfile); } }

	&regist;

	if($refresh and !$win) { &header2; } else { &header; }

	print "<h1>$kname님이 $wname님에게 결투를 신청하였습니다!!</h1><hr size=0><p>\n";

	$i=0;
	foreach(@battle_date){
		print "$battle_date[$i]";
		$i++;
	}
	
	print "$comment<p>$kname님이 <b>$tmp2</b>의 경험치를 얻었고, <b>$gold</b>GP를 얻었습니다.<p>\n";

	&footer;
	$battle_flag=0;
	exit;
}

#--------------------#
#  최강자 읽고쓰기   #
#--------------------#
sub read_winner {
	open(IN,"$winner_file");
	@winner = <IN>;
	close(IN);
	($wid,$wpass,$wsite,$wurl,$wname,$wsex,$wchara,$wn_0,$wn_1,$wn_2,$wn_3,$wn_4,$wn_5,$wn_6,$wrace,$wclass,$whp,$wmaxhp,$wmp,$wmaxmp,$wex,$wlv,$wgold,$wtotal,$wkati,$witem,$witem1,$witem2,$wmons,$whost,$wdate,$wwab_0,$wwab_1,$wwab_2,$wab_0,$wab_1,$wab_2,$wab_3,$wab_4,$wab_5,$wab_6,$wab_7,$wab_8,$wab_9,$wab_10,$wwskill,$wwskiti,$wcount,$lsite,$lurl,$lname) = split(/<>/,$winner[0]);
}

#----------------------#
#   몬스터와의 전투    #
#----------------------#
sub monster {
	if($battle_flag) { &error("현재 전투중입니다. 잠시후에 다시 해주세요."); }

	$battle_flag=1;$ratk=1;

	open(IN,"$chara_file");
	@battle = <IN>;
	close(IN);

	foreach(@battle){
		($kid,$kpass,$ksite,$kurl,$kname,$ksex,$kchara,$kn_0,$kn_1,$kn_2,$kn_3,$kn_4,$kn_5,$kn_6,$krace,$kclass,$khp,$kmaxhp,$kmp,$kmaxmp,$kex,$klv,$kgold,$ktotal,$kkati,$kitem,$kitem1,$kitem2,$kmons,$khost,$kdate,$kwab_0,$kwab_1,$kwab_2,$kab_0,$kab_1,$kab_2,$kab_3,$kab_4,$kab_5,$kab_6,$kab_7,$kab_8,$kab_9,$kab_10,$kabpint,$kwskill,$kwskiti) = split(/<>/);
		if($in{'id'} eq "$kid") { last; }
	}

	$ltime = time();
	$ltime = $ltime - $kdate;
	$vtime = $b_time - $ltime;
	$mtime = $m_time - $ltime;

	if($ltime < $m_time & $ktotal) { &error("$mtime초 후에 실행해주세요.<br>\n"); }

	if(!$kmons){&error("최강자와 한 번 싸워주세요.");}

	open(IN,"$monster_file");
	@MONSTER = <IN>;
	close(IN);

	open(IN,"$item_file");
	@log_item = <IN>;
	close(IN);

	open(IN,"$magic_file");
	@MAGIC = <IN>;
	close(IN);

	$hit=0;
	foreach(@log_item){
		($i_no,$i_name,$i_dmg,$i_gold,$i_kind,$i_wkind,$i_ref,$i_cls) = split(/<>/);
		if($kitem eq "$i_no"){ $hit=1;last; }
	}

      #아이템 데이타 세부적 분류(무기)
      ($i_mindmg,$tmp1) = split(/D/,$i_dmg);
      ($i_maxdmg,$i_pdmg) = split(/p/,$tmp1);
      ($i_wkind,$i_whand) = split(/a/,$i_wkind);

      #방어구 찾기
	$hit=0;
	foreach(@log_item){
		($i_no2,$i_name2,$i_av,$i_gold,$i_kind2,$i_wkind2,$i_ref2,$i_cls) = split(/<>/);
		if($kitem2 eq "$i_no2"){ $hit=1;last; }
	}
      ($tmp1,$tmp2) = split(/a/,$i_wkind2);
      if($tmp1 == 1){$i_minuses1=$tmp2;}

      #보조아이템 찾기
	$hit=0;
	foreach(@log_item){
		($i_no1,$i_name1,$i_av1,$i_gold,$i_kind1,$i_wkind1,$i_ref1,$i_cls) = split(/<>/);
		if($kitem1 eq "$i_no1"){ $hit=1;last; }
	}

      if($kwskill != 0){
      $hit=0;
        foreach(@MAGIC){
          ($mg_no,$mg_lv,$mg_name,$mg_mp,$mg_time,$mg_kind,$mg_dta1,$mg_dta2,$mg_re,$mg_cls)=split(/<>/);
          if($kwskill eq "$mg_no"){$hit=1;last;}
        }
      }
      if($mg_kind eq 1){
        #공격마법을 위한 세부분류
        ($mg_mindmg,$mg_maxdmg) = split(/D/,$mg_dta1);
      }

      #회피율
      $es1=$kab_7*5+$kn_2-$i_minuses1;
      #받기
      $es2=int($kwab_0/3)+($kab_8*5)+$i_av1;

      $r_no=@MONSTER;

      foreach(@MONSTER){
        #싸울 몬스터 선택
        $r_no=int(rand($r_no));

        #해당 몬스터 데이타 변수에 입력
        ($mlv,$mname,$mex,$mhp,$mdmg,$mmg,$miv,$mes,$tmp2,$mav,$mre)=split(/<>/,$MONSTER[$r_no]);
        #일반적으로 캐릭터 레벨과 비슷한 레벨을 가진 몬스터가 선택되나 간혹 그렇지않음.
        $mmm=int(rand(10))+1;
        if($mmm<=1 & $mmm<=6 & $mlv<=$klv+1){last;}
        if($mmm<=7 & $mmm<=8 & $mlv<=$klv+2){last;}
        if($mmm eq 9 || $mmm eq 10){last;}
      }

      #몬스터 데이타 세부적 분류
      ($mindmg,$tmp1)=split(/D/,$mdmg);
      ($maxdmg,$mpdmg)=split(/p/,$tmp1);
      ($minhp,$tmp1)=split(/D/,$mhp);
      ($maxhp,$mhpp)=split(/p/,$tmp1);
      ($mes2,$mes2av)=split(/a/,$tmp2);

      $khp_flg=$khp;$tmp2=0;

      #몬스터 생명점 결정
      $mhp=0;
      foreach(1..$minhp){$mhp+=int(rand($maxhp))+1;}
      $mhp+=$mhpp;
      $mhp_flg=$mhp;
      #장비한 무기의 기능포인트가 있을 경우 능력치*5% 명중률 상승
      if($i_wkind eq 1&$kab_0>=1){$ppg+=int($kab_0*0.5);}
      if($i_wkind eq 2&$kab_1>=1){$ppg+=int($kab_1*0.5);}
      if($i_wkind eq 3&$kab_2>=1){$ppg+=int($kab_2*0.5);}
      if($i_wkind eq 4&$kab_3>=1){$ppg+=int($kab_3*0.5);}
      if($i_wkind eq 5&$kab_4>=1){$ppg+=int($kab_4*0.5);}
      $ppg=$kwab_0-$mes;
      $mmg-=$es1;
      $kre=$kwab_1;
      $mre_flg=$mre;

      #무기의 기능포인트에 따른 라운드당 공격횟수 설정
      if(($i_wkind eq 1 & $kab_0 eq 3)||($i_wkind eq 2 & $kab_1 eq 3)||($i_wkind eq 3 & $kab_3 eq 3)||($i_wkind eq 4 & $kab_2 eq 3)||($i_wkind eq 5 & $kab_4 eq 3)){$ratk=2;}
      elsif(($i_wkind eq 1&$kab_0 eq 4)||($i_wkind eq 2&$kab_1 eq 4)||($i_wkind eq 3&$kab_3 eq 4)||($i_wkind eq 4&$kab_2 eq 4)||($i_wkind eq 5&$kab_4 eq 4)){$ratk=3;}
      elsif(($i_wkind eq 1&$kab_0 eq 5)||($i_wkind eq 2&$kab_1 eq 5)||($i_wkind eq 3&$kab_3 eq 5)||($i_wkind eq 4&$kab_2 eq 5)||($i_wkind eq 5&$kab_4 >= 5)){$ratk=4;}

      $i=1;$j=0;@battle_date=();$castround=0;$maguse=0;
      #설정된 라운드까지 이기지 못하면 자동으로 패배
      foreach(1..$round) {

            $dmg1=0;$dmg11=0;$dmg12=0;$dmg13=0;$dmg2=0;$magicdmg=0;
            $skcom="";$com1="";$com11="";$com12="";$com13="";$com2="";$com3="";$tmpcom="";$c1="";$c2="";$c3="";

            if($maguse == 1 & $castround != 0){
               if($mgh1 == 8){$khp_flg+=$mgh2;}
               if($mgh4 == 8){$khp_flg+=$mgh5;}
            }

            #기술사용타이밍과 현재의 타이밍 일치여부
            if(($kwskiti == 1 & $i == 1) || ($kwskiti == 2 & $kmaxhp/3 >= $khp_flg & $maguse != 1) || ($kwskiti == 3 & $klv < $mlv & $i == 1) || ($kwskiti == 4)){
             if($mg_mp <= $kmp){
               $kmp-=$mg_mp;
               $maguse=1;
               $mg_dice=int(rand(100))+1;$mreroll=int(rand(100))+1;$wab2roll=int(rand(100))+1;
               if($wab2roll<=$kwab_2 || $wab2roll<=int($kwab_2/10)){$mreroll=int($mreroll*($klv*0.05));}
               #백스탭
               if($kwskill == 35){
                  if($mg_dice>=1 & $mg_dice<=50){
                    $skcom="당신이 바람처럼 사라졌다가 $mname 뒤에 슬며시 나타납니다.<br>";$magicsp=1;
                  }else{$skcom="당신이 재빠르게 움직이지만 $mname(은)는 이미 눈치채고 있습니다.<br>";$magicsp=4;}
               #돌격
               }elsif($kwskill == 36){
                  if($mg_dice>=1 & $mg_dice<=40){
                    $skcom="당신이 $mname에게 힘차게 돌진합니다.<br>";$magicsp=2;
                  }else{$skcom="당신이 $mname에게 힘차게 돌진합니다.<br>";$magicsp=5;}
               }
               #공격마법
               if($mg_kind == 1){
                  if($mg_dice>=1 & $mg_dice<=90){
                   #마법성공
                   foreach(1..$mg_mindmg){$magicdmg+=int(rand($mg_maxdmg))+1;}
                   $magicdmg+=$klv;
                    #몬스터저항성공
                    if($mreroll<=10 || int($mre_flg/10)>=$mreroll || $mre_flg>=$mreroll){
                     #효과소멸
                     if($mg_re == 1){$skcom="당신이 $mg_name의 주문을 외웁니다. 콰쾅~! 그러나 $mname(은)는 멀쩡히 서 있습니다.<br>";}
                     elsif($mg_re == 3){
                       #효과반감
                       $magicdmg=int($magicdmg/2);$skcom="당신이 $mg_name의 주문을 외웁니다. 콰쾅~! <font class=dmg><b>(-$magicdmg)</b></font><br>";
                       if($magicdmg<=0){$magicdmg=0;$skcom="당신이 $mg_name의 주문을 외웁니다. 콰쾅~! 그러나 $mname(은)는 멀쩡히 서 있습니다.<br>";}
                     }else{$skcom="당신이 $mg_name의 주문을 외웁니다. 콰쾅~! <font class=dmg><b>(-$magicdmg)</b></font><br>";}
                    }else{
                     #몬스터저항실패
                     $skcom="당신이 $mg_name의 주문을 외웁니다. 콰쾅~! <font class=dmg><b>(-$magicdmg)</b></font><br>";
                    }
                  }else{
                    #마법실패
                    $skcom="당신이 중얼중얼 주문을 외우지만, 아무런 일도 벌어지지 않습니다.<br>";
                  }
               #보조마법
               }elsif($mg_kind == 2){
                  if($mg_dice>=1 & $mg_dice<=90){
                     ($mgh1,$mgh2,$mgh3)=split(/q/,$mg_dta1);
                     ($mgh4,$mgh5,$mgh6)=split(/q/,$mg_dta2);
                     $skcom="당신이 $mg_name의 주문을 외웁니다.<br>";
                     if($kwskill == 34){$skcom="당신이 재주를 넘듯이 움직입니다.<br>";}
                     if($kwskill == 37){$skcom="당신이 마음속에 숨어있던 흉폭함을 표출하기 시작합니다.<br>";}
                     if($mgh3 == 1 || $mgh6 == 1){
                       if($mgh1 == 1){
                         $ppg+=$mgh2;
                         if($mg_time){$castround=$mg_time;}
                       }
                       if($mgh1 == 2){
                         $es1+=$mgh2;
                         if($mg_time){$castround=$mg_time;}
                       }
                       if($mgh1 == 3){
                         $i_av+=$mgh2;
                         if($mg_time){$castround=$mg_time;}
                       }
                       if($mgh1 == 4){
                         $mg_pdmg=$mgh2;
                         if($mg_time){$castround=$mg_time;}
                       }
                       if($mgh1 == 5){
                         $kre+=int($mgh2/100);
                         if($mg_time){$castround=$mg_time;$castplus=$mgh2;}
                       }
                       if($mgh1 == 6){
                         $es2+=$mgh2;
                         if($mg_time){$castround=$mg_time;$castplus=$mgh2;}
                       }
                       if($mgh1 == 7){
                         ($mgh7,$mgh8)=split(/D/,$mgh2);
                         foreach(1..$mgh7){$hpresto+=int(rand($mgh8))+1;}
                         $hpresto+=$klv;$khp_flg+=$hpresto;
                       }
                       if($mgh1 == 8){
                         if($mg_time){$castround=$mg_time;}
                       }
                       if($mgh1 == 9){
                         $mag_armor=$mgh2;
                         if($mg_time){$castround=$mg_time;}
                       }
                       if($mgh1 == 10){$khp_flg=$kmaxhp;}
                       if($mgh4 == 1){
                         $ppg+=$mgh5;
                         if($mg_time){$castround=$mg_time;}
                       }
                       if($mgh4 == 2){
                         $es1+=$mgh5;
                         if($mg_time){$castround=$mg_time;}
                       }
                       if($mgh4 == 3){
                         $i_av+=$mgh5;
                         if($mg_time){$castround=$mg_time;}
                       }
                       if($mgh4 == 4){
                         $mg_pdmg=$mgh5;
                         if($mg_time){$castround=$mg_time;}
                       }
                       if($mgh4 == 5){
                         $kre+=int($mgh5/100);
                         if($mg_time){$castround=$mg_time;}
                       }
                       if($mgh4 == 6){
                         $es2+=$mgh5;
                         if($mg_time){$castround=$mg_time;}
                       }
                       if($mgh1 == 7){
                         ($mgh7,$mgh8)=split(/D/,$mgh5);
                         foreach(1..$mgh7){$hpresto+=int(rand($mgh8))+1;}
                         $hpresto+=$klv;$khp_flg+=$hpresto;
                       }
                       if($mgh4 == 8){
                         if($mg_time){$castround=$mg_time;}
                       }
                       if($mgh4 == 9){
                         $mag_armor=$mgh5;
                         if($mg_time){$castround=$mg_time;}
                       }
                       if($mgh4 == 10){$khp_flg=$kmaxhp;}
                       if($khp_flg>$kmaxhp){$khp_flg=$kmaxhp;}
                     }elsif($mgh3 == 2 || $mgh6 == 2){
                       if($mreroll<=10 || int($mre_flg/10)>=$mreroll || $mre_flg>=$mreroll){
                        if($mg_re == 1){$skcom="당신이 $mg_name의 주문을 외웁니다.<br>";}
                        if($kwskill == 33){$skcom="당신이 천지가 흔들릴정도로 엄청난 고함을 질러댑니다.<br>";}
                       }else{
                        $skcom="당신이 $mg_name의 주문을 외우자 이상한 기운이 올라옵니다.<br>";
                        if($kwskill == 33){$skcom="당신이 천지가 흔들릴정도로 엄청난 고함을 질러댑니다.<br>";}
                        if($mgh1 == 1){
                          $mmg-=$mgh2;
                          if($mg_time){$castround=$mg_time;}
                        }
                        if($mgh1 == 2){
                          $mes-=$mgh2;
                          if($mg_time){$castround=$mg_time;}
                        }
                        if($mgh1 == 3){
                          $mav-=$mgh2;
                          if($mg_time){$castround=$mg_time;}
                        }
                        if($mgh1 == 4){
                          $mg_pdmg1=$mgh2;
                          if($mg_time){$castround=$mg_time;}
                        }
                        if($mgh1 == 5){
                          $mre_flg-=int($mgh2/100);
                          if($mg_time){$castround=$mg_time;}
                        }
                        if($mgh1 == 6){
                          $mes2-=$mgh2;
                          if($mg_time){$castround=$mg_time;}
                        }
                        if($mgh4 == 1){
                          $mmg-=$mgh5;
                          if($mg_time){$castround=$mg_time;}
                        }
                        if($mgh4 == 2){
                          $mes-=$mgh5;
                          if($mg_time){$castround=$mg_time;}
                        }
                        if($mgh4 == 3){
                          $mav-=$mgh5;
                          if($mg_time){$castround=$mg_time;}
                        }
                        if($mgh4 == 4){
                          $mg_pdmg1=$mgh5;
                          if($mg_time){$castround=$mg_time;}
                        }
                        if($mgh4 == 5){
                          $mre_flg-=int($mgh5/100);
                        }
                        if($mgh4 == 6){
                          $mes2-=$mgh5;
                          if($mg_time){$castround=$mg_time;}
                        }
                       }
                     }
                  }else{
                     $skcom="당신이 중얼중얼 주문을 외우지만, 아무런 일도 벌어지지 않습니다.<br>";
                     if($kwskill == 33){$skcom="당신이 콜록거리며 기침을 해댑니다.<br>";}
                     if($kwskill == 34){$skcom="당신이 재주를 넘듯이 움직이다가 콰당 넘어집니다.<br>";}
                     if($kwskill == 37){$skcom="당신이 마음속에 숨어있던 흉폭함을 표출하려하지만 뜻대로 되지않습니다.<br>";}
                  }
               }
               #스페셜마법
               }elsif($mg_kind == 3){
                  if($mg_dice>=1 & $mg_dice<=90){
                    if($mreroll<=10 || int($mre_flg/10)>=$mreroll || $mre_flg>=$mreroll){
                     $skcom="당신이 중얼중얼 주문을 외우지만, 아무런 일도 벌어지지 않습니다.<br>";
                    }else{
                     #몬스터저항실패
                     $magicdmg=$mhp;
                     $skcom="당신이 $mg_name의 주문을 외웁니다. 콰쾅~! <font class=dmg><b>(-$magicdmg)</b></font><br>";last;
                    }
                  }else{$skcom="당신이 중얼중얼 주문을 외우지만, 아무런 일도 벌어지지 않습니다.<br>";
               }
             }else{
               $skcom="당신이 주문을 외우려하지만, 정신이 집중되지 않습니다.<br>";
               if($kwskill == 33 || $kwskill == 34 || $kwskill ==35){$skcom="정신이 집중되지않아 기술을 쓸 수 없습니다.<br>";}
             }
            }

          $ivi=int(rand(10))+1;  #주도권결정

          $it1=1;
          foreach(1..$ratk) {
            $tmpdmg=0;

            #명중여부체크 mgmg몬스터 pgpg플레이어
            $mgmg=int(rand(100))+1;
            $pgpg=int(rand(100))+1;
            #받기여부체크prefroll플레이어 mrefroll몬스터
            $prefroll=int(rand(100))+1;
            $mrefroll=int(rand(100))+1;

            #행운에 따른 명중률 향상
            $luck_roll=int(rand(10))+1;
            if($kn_6>=7 & $kn_6<=12 & $luck_roll > 9) {$pgpg+=int(rand(5))+1;}
            if($kn_6>=13 & $kn_6<=18 & $luck_roll > 8) {$pgpg+=int(rand(10))+1;}
            if($kn_6>=19 & $kn_6<=21 & $luck_roll > 7) {$pgpg+=int(rand(12))+1;}
            if($kn_6>=22 & $luck_roll > 4) {$pgpg+=int(rand(15))+1;}

            #43,44,51 방패는 받기율+0.3,5,8,8%가 더해짐
            if($kitem1 eq "0043" || $kitem1 eq "0044" || $kitem1 eq "0051"){$prefroll=int($prefroll*$i_ref1);}

            #받기실패
            if($prefroll>=$es2 || $prefroll>=91){$pref=0;}
            #받기성공
            elsif($prefroll<=$es2 || $prefroll<=int($es2/10)){$pref=1;}
            #받기실패
            if($mrefroll>=$mmg || $mrefroll>=91){$mref=0;}
            #받기성공
            elsif($mrefroll<=$mmg || $mrefroll<=int($mmg/10)){$mref=1;}

          #플레이어가 몬스터에게 주는 데미지 계산 (D&D주사위방식 xdyy)
          #x는 돌리는 회수 yy는 굴린 주사위 면수
          foreach(1..$i_mindmg) {$tmpdmg+=int(rand($i_maxdmg))+1;}
          $tmpdmg+=$i_pdmg;
          if($kitem == "" || $kitem == 0){$tmpdmg=int(rand(2))+1+$klv;}
          $tmpdmg+=$kab_5+$mg_pdmg;
          if($magicsp == 1){$tmpdmg=$tmpdmg*3;$magicsp=0;$ttmp=1;}
          if($magicsp == 2){$tmpdmg=$tmpdmg*2;$es1-=60;$magicsp=3;$ttmp=1;}
          if($magicsp == 3){$es1+=60;$magicsp=0;}
          if($magicsp == 5){$es1-=60;$magicsp=6;}
          if($magicsp == 6){$es1+=60;$magicsp=0;}

          #힘에 따른 데미지 보너스
          if($kn_0>=7 & $kn_0<=9){$tmpdmg+=1;}
          if($kn_0>=10 & $kn_0<=12){$tmpdmg+=2;}
          if($kn_0>=13 & $kn_0<=15){$tmpdmg+=3;}
          if($kn_0>=16 & $kn_0<=18){$tmpdmg+=4;}
          if($kn_0>=19 & $kn_0<=21){$tmpdmg+=5;}
          if($kn_0>=22 & $kn_0<=25){$tmpdmg+=6;}

			#player 데미지 계산
                  if($pgpg<=int($ppg/10)) {
                     #크리티컬
                     if($tmpdmg>$mhp){$tmpdmg=$mhp;}
                     $tmpcom = "당신이 $mname(이)가 막아낼 틈도 주지않고 순간적으로 공격합니다. <b class=\"clit\">크리티컬!!</b> <font class=dmg><b>(-$tmpdmg)</b></font>";
                  }elsif($pgpg<=int($ppg) || $pgpg<=10 || $ttmp == 1) {
                     #공격성공
                     $tmpdmg-=$mav;$ttmp=0;
                     #만약 데미지가 적의 현 에너지보다 크다면 데미지는 적의 현 에너지가 됨.
                     if($tmpdmg>$mhp) {$tmpdmg=$mhp;}
                     $tmpcom = "당신이 $mname(을)를 공격합니다. <font class=dmg><b>(-$tmpdmg)</b></font>";
                     if($tmpdmg<=0) { $tmpcom = "당신이 $mname(을)를 공격했지만, 아무런 피해도 주지 못했습니다."; $tmpdmg=0; }
                     if($mref == 1 & $mes2 != 0){
                      #몬스터가 받기성공시
                      $tmpdmg-=$mes2av;
                      $tmpcom="당신의 공격을 $mname(이)가 막아냈지만, 데미지를 조금 입었습니다. <font class=dmg><b>(-$tmpdmg)</b></font>";
                      if($tmpdmg<=0) { $tmpcom = "당신이 $mname(을)를 공격했지만, $mname(이)가 성공적으로 막아내어 아무런 피해도 주지 못했습니다.";$tmpdmg=0;}
                     }
                  }elsif($pgpg>=int($ppg) || $pgpg>=91) {
                     #공격실패
                     $tmpdmg=0;
                     $tmpcom="당신이 $mname(을)를 빗맞췄습니다.";
                  }
                  if($it1 eq 1){$com1=$tmpcom;$dmg1=$tmpdmg;}
                  if($it1 eq 2){$com11=$tmpcom;$dmg11=$tmpdmg;$c1="<br>";}
                  if($it1 eq 3){$com12=$tmpcom;$dmg12=$tmpdmg;$c2="<br>";}
                  if($it1 eq 4){$com13=$tmpcom;$dmg13=$tmpdmg;$c3="<br>";}
          $it1++;
          }

          #몬스터가 사용자에게 주는 데미지 계산 (D&D주사위방식 xdyy)
          #x는 돌리는 회수 yy는 굴리는 주사위 면수
          foreach(1..$mindmg) {$dmg2+=int(rand($maxdmg))+1;}
          $dmg2+=$mpdmg;
          $dmg2-=$mg_pdmg1;
          if($magicsp == 4){$dmg2=$dmg2*2;$magicsp=0;}

          #매 라운드마다 1 ~ 몬스터레벨 /2 까지의 랜덤적인 경험치를 획득
          $tmp2+=int(((rand($mlv))+1)/2);

                  #몬스터 공격
                  if($mgmg<=int($mmg/10)) {
                     #크리티컬
                     if($dmg2>$khp_flg){$dmg2=$khp_flg;}
                     $com2="$mname(이)가 당신이 막아낼 틈도 주지않고 순간적으로 공격합니다. <b class=\"clit\">크리티컬!!</b> <font class=dmg><b>(-$dmg2)</b></font>";
                  }elsif($mgmg>=$mmg || $mgmg>=91) {
                     #공격실패
                     $dmg2=0;
                     $com2="$mname(이)가 당신을 빗맞췄습니다.";
                  }elsif($mgmg<=$mmg || $mgmg<=10) {
                     #공격성공
                     $dmg2-=$i_av;
                     #만약 데미지가 플레이어의 현 에너지보다 크다면 데미지는 플레이어의 현 에너지가 됨.
                     if($dmg2>$khp_flg) {$dmg2=$khp_flg;}
                     $com2 = "$mname(이)가 당신을 공격합니다. <font class=dmg><b>(-$dmg2)</b></font>";
                     if($dmg2<=0) { $com2="$mname(이)가 당신을 공격했지만, 아무런 피해도 주지 못했습니다."; $dmg2=0; }
                     if($pref == 1 & $es2 != 0){
                      #플레이어가 받기성공시
                      $dmg2 -= $i_ref+$i_av1;
                      $com2 = "$mname의 공격을 당신이 막아냈지만, 데미지를 조금 입었습니다. <font class=dmg><b>(-$dmg2)</b></font>";
                      if($dmg2<=0) { $com2="$mname(이)가 당신을 공격했지만, 당신이 성공적으로 막아내어 아무런 피해도 주지 못했습니다.";$dmg2=0;}
                     }
                  }

         if($ivi<=$miv){$com3=$com1;$com1=$com2;$com2=$com3;}
         if($ratk eq 1){$lastdmg=$dmg1;}
         if($ratk eq 2){$lastdmg=$dmg1+$dmg11;}
         if($ratk eq 3){$lastdmg=$dmg1+$dmg11+$dmg12;}
         if($ratk eq 4){$lastdmg=$dmg1+$dmg11+$dmg12+$dmg13;}

		$battle_date[$j] = <<"EOM";
<TABLE BORDER=0>
<TR><TD CLASS="b2" COLSPAN="3" ALIGN="center">$i Round</TD></TR>
<TR><TD>
<TABLE BORDER=1 CELLSPACING=0 BORDERCOLORDARK=WHITE BORDERCOLORLIGHT=BLACK>
<TR><TD CLASS="b1">이름</TD><TD CLASS="b1">HP</TD><TD CLASS="b1">직업</TD><TD CLASS="b1">LV</TD></TR>
<TR><TD>$kname</TD><TD>$khp_flg/$kmaxhp</TD><TD>$chara_class[$kclass]</TD><TD>$klv</TD></TR></TABLE>
</TD>
<TD><FONT SIZE=5 COLOR="#9999DD">VS</FONT></TD>
<TD>
<TABLE BORDER=1 CELLSPACING=0 BORDERCOLORDARK=WHITE BORDERCOLORLIGHT=BLACK>
<TR><TD CLASS="b1">이름</TD><TD CLASS="b1">HP</TD></TR>
<TR><TD>$mname</TD><TD>$mhp/$mhp_flg</TD></TR></TABLE>
</TD></TR></TABLE>
<p>
$skcom $com1 $c1 $com11 $c2 $com12 $c3 $com13<br>
$com2<p>
EOM

        #주도권에 따른 선공여부
          if($ivi>=$miv) {
           #플레이어 선공
            $mhp-=$lastdmg+$magicdmg;
            if($mhp<=0){$win=1;last;}
            if($maguse == 1 & $mag_armor > 0){
              $mag_armor-=$dmg2;
              if($mag_armor < 0){$khp_flg+=$mag_armor;}
            }else{$khp_flg-=$dmg2;}
            if($khp_flg<=0){$win=0;last;}
          }else{
           #몬스터 선공
            if($maguse == 1 & $mag_armor > 0){
              $mag_armor-=$dmg2;
              if($mag_armor < 0){$khp_flg+=$mag_armor;}
            }else{$khp_flg-=$dmg2;}
            if($khp_flg<=0){$win=0;last;}
            $mhp-=$lastdmg+$magicdmg;
            if($mhp<=0){$win=1;last;}
         }
		$i++;
		$j++;
            $castround--;
            if($castround == 0 & $maguse == 1){
               if($mgh3 == 1 || $mgh6 == 1){
                  if($mgh1 == 1){$ppg-=$mgh2;}
                  if($mgh1 == 2){$es1-=$mgh2;}
                  if($mgh1 == 3){$i_av-=$mgh2;}
                  if($mgh1 == 4){$mg_pdmg=0;}
                  if($mgh1 == 5){$kre=$kwab_1;}
                  if($mgh1 == 6){$es2-=$mgh2;}
                  if($mgh1 == 9){$mag_armor=0;}
                  if($mgh4 == 1){$ppg-=$mgh5;}
                  if($mgh4 == 2){$es1-=$mgh5;}
                  if($mgh4 == 3){$i_av-=$mgh5;}
                  if($mgh4 == 4){$mg_pdmg=0;}
                  if($mgh4 == 5){$kre=$kwab_1;}
                  if($mgh4 == 6){$es2-=$mgh5;}
                  if($mgh4 == 9){$mag_armor=0;}
               }elsif($mgh3 == 2 || $mgh6 == 2){
                  if($mgh1 == 1){$mmg+=$mgh2;}
                  if($mgh1 == 2){$mes+=$mgh2;}
                  if($mgh1 == 3){$mav+=$mgh2;}
                  if($mgh1 == 4){$mg_pdmg1=0;}
                  if($mgh1 == 5){$mre_flg=$mre;}
                  if($mgh1 == 6){$mes2+=$mgh2;}
                  if($mgh4 == 1){$mmg+=$mgh5;}
                  if($mgh4 == 2){$mes+=$mgh5;}
                  if($mgh4 == 3){$mav+=$mgh5;}
                  if($mgh4 == 4){$mg_pdmg1=0;}
                  if($mgh4 == 5){$mre_flg=$mre;}
                  if($mgh4 == 6){$mes2+=$mgh5;}
                }
            }
     }

	if($win) {
		$ktotal += 1;
		$kkati += 1;
            $mex+=int(rand($kn_6))+$tmp2;
		$kex+=$mex;
		$kmons-=1;
            $gold=$klv*10+int(rand($kn_6));
		$kgold+=$gold;
		$comment = "<b><font size=5>$kname님이 전투에서 승리하셨습니다!!!</font></b><br>";
	}else{
		$ktotal += 1;
		$kex+=$tmp2;
		$kmons-=1;
		if($kgold) {$kgold-=int($kgold/10);}else{$kgold=0;}
		$comment = "<b><font size=5>$kname님이 전투에서 패배하셨습니다...</font></b><br>";
	}

        if($klv eq 1) { $next_ex=1000; }
        if($klv eq 2) { $next_ex=2000; }
        if($klv eq 3) { $next_ex=4000; }
        if($klv eq 4) { $next_ex=8000; }
        if($klv eq 5) { $next_ex=16000; }
        if($klv eq 6) { $next_ex=32000; }
        if($klv eq 7) { $next_ex=48000; }
        if($klv eq 8) { $next_ex=64000; }

        if($klv eq 9) { $next_ex=80000; }
        if($klv eq 10) { $next_ex=96000; }
        if($klv eq 11) { $next_ex=112000; }
        if($klv eq 12) { $next_ex=128000; }

      #전투로그파일추가
	&get_time;
	open(IN,"$battle_file");
	@blog = <IN>;
      $bat_max = @blog;

      if($bat_max > $batmax){pop(@blog);}
      unshift(@blog, "$gettime<>$kid<>$mname<>$i<>$win<>\n");
	open(OUT,">$battle_file");
	print OUT @blog;
	close(IN);
	close(OUT);

	if($kex > $next_ex & $klv<13) {
            $comment .= "$kname님의 레벨이 상승하였습니다!!!<br>";
            #$kmaxhp = $kmaxhp + int(rand($kn_3)) + 1;

            if($kclass == 0) {$kmaxhp+=int(rand(10))+1;$kmaxmp+=int(rand(4))+1;}
            if($kclass == 1) {$kmaxhp+=int(rand(4))+1;$kmaxmp+=int(rand(8))+1;}
            if($kclass == 2) {$kmaxhp+=int(rand(8))+1;$kmaxmp+=int(rand(10))+1;}
            if($kclass == 3) {$kmaxhp+=int(rand(6))+1;$kmaxmp+=int(rand(6))+1;}
            if($kclass == 4) {$kmaxhp+=int(rand(8))+1;$kmaxmp+=int(rand(10))+1;}
            if($kclass == 5) {$kmaxhp+=int(rand(6))+1;$kmaxmp+=int(rand(10))+1;}
            # 생명력보너스 추가
            $kmaxhp+=$kn_1;$kmaxmp+=$kn_4;

            $khp = $kmaxhp;
            $kmp = $kmaxmp;
            $kex = 0;
            $klv += 1;
            $kwab_1 += 2;

            #랜덤하게 특기포인트를 줌.
            $tmp4=int(rand(1));
            if($tmp4){$tmp5=$lvup_abilit+1;}else{$tmp5=$lvup_abilit+2;}
            $kabpint += $tmp5;
            $comment .= "특기포인트가 <b>$tmp5</b> 상승하였습니다.<br>";

            #기능치 상승
            if($kclass == 0) {$kwab_0+=4;$kwab_1+=2;}
            if($kclass == 1) {$kwab_0+=2;$kwab_1+=2;}
            if($kclass == 2) {$kwab_0+=4;$kwab_1+=2;}
            if($kclass == 3) {$kwab_0+=3;$kwab_1+=2;}
            if($kclass == 4) {$kwab_0+=4;$kwab_1+=2;}
            if($kclass == 5) {$kwab_0+=3;$kwab_1+=2;}
	}

	$khp=$khp_flg+int( (rand($kn_1)+rand($kn_6)) / 2 );
	$kmp += int( (rand($kn_5)+rand($kn_6)) / 2 );
      if($kmp>$kmaxmp || $kmp<0) {$kmp=$kmaxmp;}
	if($khp>$kmaxhp || $khp<0) {$khp=$kmaxhp;}

	&regist;
	&header;

	print "<h1>$kname님이 $mname에게 싸움을 걸었습니다.</h1><hr size=0><br>\n";

	$i=0;
	foreach(@battle_date){
		print "$battle_date[$i]";
		$i++;
	}
	
	if($win) { print "$comment<p>$kname님이 $mex의 경험치를 얻었고, <b>$gold</b>GP를 얻었습니다.<p>\n"; }
	else { print "$comment<p>$kname님이 $tmp2의 경험치를 얻었고, 가지고 있는 돈의 1/10을 잃었습니다.<p>\n"; }

	&footer;
	$battle_flag=0;
	exit;
}

#----------------#
#  전투기술 설정 #
#----------------#
sub wsk_set {
      if($in{'wsk'} eq "no"){&error("기술을 선택해 주십시오.");}
      if($in{'wsk1'} eq "no"){&error("사용시기를 선택해 주십시오.");}
      if($in{'wsk'} eq 0 & $in{'wsk1'} != 0){&error("사용을 안하는데 시기를 정할 필요는 없겠죠?");}
	$id = $in{'id'};
	&get_host;
	$date = time();

	open(IN,"$chara_file");
	@wskset = <IN>;
	close(IN);

	open(IN,"$magic_file");
	@wskset1 = <IN>;
	close(IN);

	@wskset_new = ();
	foreach(@wskset) {
        ($sid,$spass,$ssite,$surl,$sname,$ssex,$schara,$sn_0,$sn_1,$sn_2,$sn_3,$sn_4,$sn_5,$sn_6,$srace,$sclass,$shp,$smaxhp,$smp,$smaxmp,$sex,$slv,$sgold,$stotal,$skati,$sitem,$sitem1,$sitem2,$smons,$shost,$sdate,$swab_0,$swab_1,$swab_2,$sab_0,$sab_1,$sab_2,$sab_3,$sab_4,$sab_5,$sab_6,$sab_7,$sab_8,$sab_9,$sab_10,$sabpint,$swskill,$swskiti) = split(/<>/);

        if($id eq $sid) {
          $swskill=$in{'wsk'};$swskiti=$in{'wsk1'};
          if($swskiti == 4){

             $hit=0;
             foreach(@wskset1){
                ($mg_no,$mg_lv,$mg_name,$mg_mp,$mg_time,$mg_kind,$mg_dta1,$mg_dta2,$mg_re,$mg_cls)=split(/<>/);
                if($swskill eq "$mg_no"){$hit=1;last;}
             }
             if(!$hit) { &error("존재하지 않는 기술,마법입니다."); }
             if($mg_kind != 1) { &error("이 기술,마법은 이 사용시기로 설정할 수 없습니다."); }
          }
          unshift(@wskset_new,"$sid<>$spass<>$ssite<>$surl<>$sname<>$ssex<>$schara<>$sn_0<>$sn_1<>$sn_2<>$sn_3<>$sn_4<>$sn_5<>$sn_6<>$srace<>$sclass<>$shp<>$smaxhp<>$smp<>$smaxmp<>$sex<>$slv<>$sgold<>$stotal<>$skati<>$sitem<>$sitem1<>$sitem2<>$smons<>$shost<>$sdate<>$swab_0<>$swab_1<>$swab_2<>$sab_0<>$sab_1<>$sab_2<>$sab_3<>$sab_4<>$sab_5<>$sab_6<>$sab_7<>$sab_8<>$sab_9<>$sab_10<>$sabpint<>$swskill<>$swskiti<>\n");
        }else{
	    push(@wskset_new,"$_");
        }
      }

	open(OUT,">$chara_file");
	print OUT @wskset_new;
	close(OUT);

	&header;

	print <<"EOM";
<img src="$title7"><br>
<hr size=0><br>
<form action="$script" method="post">
<input type="hidden" name=id value="$in{'id'}">
<input type="hidden" name=pass value="$in{'pass'}">
<input type="hidden" name=mode value=log_in>
<center>
변경되었습니다. <input type="submit" value="To Status" style='font-size:9pt;background-color:gray;border-style:none;width:100;height:20;color:white;font-family:tahoma'></center>
</form>
EOM
	&footer;
	exit;
}

#----------------#
#  호스트명취득  #
#----------------#
sub get_host {
	$host = $ENV{'REMOTE_HOST'};
	$addr = $ENV{'REMOTE_ADDR'};

	if ($get_remotehost) {
		if ($host eq "" || $host eq "$addr") {
			$host = gethostbyaddr(pack("C4", split(/\./, $addr)), 2);
		}
	}
	if ($host eq "") { $host = $addr; }
}

#--------------#
#   에러처리   #
#--------------#
sub error {
	# Lock 해제
	if ($lockkey eq 3) { &file'unlock; }
	else { if(-e $lockfile) { unlink($lockfile); } }
	$battle_flag=0;

	&header;
	print "<center><hr width=400><h3>ERROR !</h3>\n";
	print "<P><font color=red><B>$_[0]</B></font>\n";
	print "<P><hr width=400>\n";
      print "<input type=submit onclick=javascript:history.back() value=이전으로 style='font-size:9pt; background-color:gray; border-style:none; width:100; height:25; color:white; font-family:돋움;'></center>\n";
	print "</body></html>\n";
	exit;
}

#------------------#
#    HTML  Footer  #
#------------------#
sub footer {
	if($refresh and !$win and $mode eq 'battle') {
		print "<font style=font-size:9pt>【<b><a href=\"http\:\/\/$wurl\">최강자의 Homepage로</a></b>】</font>\n";
	}else{
		if($mode ne ""){
			print "<font style=font-size:9pt><a href=\"$script\">TOP Page</a></font>\n";
		}
		if($kid and $mode ne 'log_in' and $mode ne 'aty_up' and $mode ne 'inn' and $mode ne 'k_stone2') {
			print "<font style=font-size:9pt> / <a href=\"$script?mode=log_in&id=$kid&pass=$kpass\">To Status</a>\n</font>";
		}
	}
	print "<HR SIZE=0 WIDTH=\"100%\"><DIV align=center class=small>\n";
      print "<font face=tahoma size=2>$ver2 by <a href=\"http://myan.xo.st\">Midget Yan</a>&nbsp;/&nbsp;\n";
	print "$ver by <a href=\"http://www.interq.or.jp/sun/cumro/\">D.Takamiya(CUMRO)</a></font>\n";
	print "</DIV>\n";

	if($mode eq 'log_in' and $ltime < $b_time and $ktotal){
	print <<"EOM";
<SCRIPT language="JavaScript">
<!--
window.setTimeout('CountDown()',100);
//-->
</SCRIPT>
EOM
	}
	print "</body></html>\n";
}

#------------------#
#    HTML header   #
#------------------#
sub header {
	print "Cache-Control: no-cache\n";
	print "Pragma: no-cache\n";
	print "Content-type: text/html; charset=utf-8\n\n";
	print <<"EOM";
<html>
<head>
<META HTTP-EQUIV="Content-type" CONTENT="text/html; charset=utf-8">
EOM

if($mode eq 'log_in' and $ltime < $b_time and $ktotal){
	print <<"EOM";
<META HTTP-EQUIV="Refresh" CONTENT="$vtime">
<SCRIPT LANGUAGE="JavaScript">
<!--
	var start=new Date();
	start=Date.parse(start)/1000;
	var counts=$vtime;
	function CountDown(){
		var now=new Date();
		now=Date.parse(now)/1000;
		var x=parseInt(counts-(now-start),10);
		if(document.form1){document.form1.clock.value = x;}
		if(x>0){
			timerID=setTimeout("CountDown()", 100)
		}else{
			location.href="$script?mode=log_in&id=$kid&pass=$kpass"
		}
	}
//-->
</SCRIPT>
EOM
}
	print <<"EOM";
<STYLE type="text/css">
<!--
body,tr,td,th { font-size: $b_size;cursor:crosshair;}
a:link, a:visited, a:active {text-decoration:none;color:$link}
a:hover {text-decoration:none;color:$alink}
.small {font-size:10pt}
.b1 {background: #cecece;color:black;}
.b2 {background: gray;text-align: center; color: white;}
.b3 {background: #fff;}
.dmg { color: #FF0000; font-size: 14pt }
.clit { color: #0000FF; font-size: 14pt }
body {color:$text;font-family:tahoma;scrollbar-face-color:#FFFFFF;scrollbar-shadow-color:black;scrollbar-highlight-color:black;scrollbar-3dlight-color:#FFFFFF;scrollbar-darkshadow-color:#FFFFFF;scrollbar-track-color:#FFFFFF;scrollbar-arrow-color:black}
-->
</STYLE>
EOM
	print "<title>$main_title</title></head>\n";
	print "<body background=\"$backgif\" bgcolor=\"$bgcolor\">\n";
}

#--------------#
#  강제송환용  #
#--------------#
sub header2 {
	print "Content-type: text/html; charset=utf-8\n\n";
	print <<"EOM";

<html>
<head>
<META HTTP-EQUIV="Content-type" CONTENT="text/html; charset=utf-8">
<META http-equiv="refresh" content="$refresh;URL=http\:\/\/$wurl">
<STYLE type="text/css">
<!--
body,tr,td,th { font-size: $b_size;cursor:crosshair;}
a:hover { color: $alink }
.small { font-size: 10pt }
.b1 {background: #cecece;border-color: #ccf #669 #669 #ccf;color:#fff; border-style: solid; border-width: 1px;}
.b2 {background: #669;border-color: #99c #336 #336 #99c;color:#fff; border-style: solid; border-width: 1px; text-align: center}
.b3 {background: #fff;border-color: #ccf #669 #669 #ccf;}
.dmg { color: #FF0000; font-size: 18pt }
.clit { color: #0000FF; font-size: 18pt }
-->
</STYLE>
EOM
	print "<title>$main_title</title></head>\n";
	print "<body background=\"$backgif\" bgcolor=\"$bgcolor\" text=\"$text\" link=\"$link\" vlink=\"$vlink\" alink=\"$alink\">\n";
}

#----------------#
#  디코드의 처리 #
#----------------#
sub decode {
	if ($ENV{'REQUEST_METHOD'} eq "POST") {
		if ($ENV{'CONTENT_LENGTH'} > 51200) { &error("투고량이 너무 많습니다!!"); }
		read(STDIN, $buffer, $ENV{'CONTENT_LENGTH'});
	} else { $buffer = $ENV{'QUERY_STRING'}; }
	@pairs = split(/&/, $buffer);
	foreach (@pairs) {
		($name,$value) = split(/=/, $_);
		$value =~ tr/+/ /;
		$value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;

		# 태그처리
		$value =~ s/</&lt;/g;
		$value =~ s/>/&gt;/g;
		$value =~ s/\"/&quot;/g;

		# 개행 처리
		$value =~ s/\r//g;
		$value =~ s/\n//g;

		# 일괄삭제용
		if ($name eq 'del') { push(@DEL,$value); }
		$in{$name} = $value;
	}
	$mode = $in{'mode'};
	$in{'url'} =~ s/^http\:\/\///;
	$cookie_pass = $in{'pass'};
	$cookie_id = $in{'id'};

}

#-------------------------------#
#       Lock 파일 symlink       #
#-------------------------------#
sub lock1 {
	local($retry) = 5;
	while (!symlink(".", $lockfile)) {
		if (--$retry <= 0) { &error("LOCK is BUSY"); }
		sleep(1);
	}
}

#----------------------------#
#       Lock 파일 open       #
#----------------------------#
sub lock2 {
	local($retry) = 0;
	foreach (1 .. 5) {
		if (-e $lockfile) { sleep(1); }
		else {
			open(LOCK,">$lockfile") || &error("Can't Lock");
			close(LOCK);
			$retry = 1;
			last;
		}
	}
	if (!$retry) { &error("잠시만 기다려주세요. (^^;)"); }
}

#------------------#
#   쿠키의 발행    #
#------------------#
sub set_cookie {
	# 60일간 유효
	local($sec,$min,$hour,$mday,$mon,$year,$wday) = gmtime(time+60*24*60*60);

	@month=('Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec');
	$gmt = sprintf("%s, %02d-%s-%04d %02d:%02d:%02d GMT",
			$week[$wday],$mday,$month[$mon],$year+1900,$hour,$min,$sec);
	$cook="id<>$cookie_id\,pass<>$cookie_pass";
	print "Set-Cookie: FFADV=$cook; expires=$gmt\n";
}

#------------------#
#    쿠키의 취득   #
#------------------#
sub get_cookie {
	@pairs = split(/;/, $ENV{'HTTP_COOKIE'});
	foreach (@pairs) {
		local($key,$val) = split(/=/);
		$key =~ s/\s//g;
		$GET{$key} = $val;

	}
	@pairs = split(/,/, $GET{'FFADV'});
	foreach (@pairs) {
		local($key,$val) = split(/<>/);
		$COOK{$key} = $val;
	}
	$c_id  = $COOK{'id'};
	$c_pass = $COOK{'pass'};
}

#--------------#
#  시간의취득  #
#--------------#
sub get_time {
	$ENV{'TZ'} = "JST-9";
	($sec,$min,$hour,$mday,$mon,$year,$wday) = localtime(time);
	@week = ('Sun','Mon','Tue','Wed','Thu','Fri','Sat');

	# 날짜,시간 리셋
	$gettime = sprintf("%04d/%02d/%02d %02d:%02d",
			$year+1900,$mon+1,$mday,$hour,$min);
}

#Lock 파일
sub file'lock
{
	local($lockfile, $locktest) = @_;
	$locktest = ($locktest > 0 ? $locktest : 4);	#0이하라면 표준으로 4회
	$locktest = ($locktest < 8 ? $locktest : 8);	#최대 8까지로 제한

	$file'lockflag = 0;
	$file'lockfile = $lockfile;	       	#원래 Lock File의 이름
	$file'lock_sw0 = $lockfile . ".sw0";	#최신날짜와 시간의 Lock File작성용
	$file'lock_sw1 = $lockfile . ".sw1";	#Lock되어있는 상태의 이름

	(-l $lockfile) && &file'error(0);
	(-d $lockfile) && &file'error(0);

	#Lock 파일이 있는 서버의 현재 시간을 취득(time으로는 안됨)
	$locktemp = $lockfile . ".$$";
	open(LOCK, ">$locktemp") || return (0);	close(LOCK);
	$time = (stat($locktemp))[9];
	unlink($locktemp);

	#작성된 후 lock_limit초 이상 경과한 Lock File의 이름을 돌려준다.
	if ((-f $file'lock_sw1) && ($time - (stat($file'lock_sw1))[9] > $lock_limit)) {
		rename($file'lock_sw1, $file'lockfile) || return (0);
	}

	#Lock 파일의 작성날짜와 시간을 갱신
	open(LOCK, ">$file'lock_sw0") || &file'error(2);
	close(LOCK);
	rename($file'lock_sw0, $file'lockfile) || return (0);

	(-f $file'lock_sw1) && return (0);

	#Lock 취득
	while (($file'lockflag = rename($file'lockfile, $file'lock_sw1)) == 0 && $lock_try) {
		#0.03, [0.07, 0.13, 0.17], 0.23
		select(undef, undef, undef, 0.13);
		$lock_try--;
	}
	$file'lockflag;
}

#File Unlock
sub file'unlock
{
	if ($file'lockflag) {
		rename($file'lock_sw1, $file'lockfile);

		#0.03, [0.07, 0.13, 0.17], 0.23
		select(undef, undef, undef, 0.03);
	}
}

sub file'error
{
	local(@error) = (
		"작성을 중지했습니다.<br>\n(Lock이외의 같은 이름의 파일이 존재)<br>\n",
		"작성에 실패했습니다.<br>\n",
		"작성에 실패했습니다.<br>\n",
		"작성에 실패했습니다.<br>\n",
		$_[1],
	);

	select(STDOUT);	$| = 1;
	print "$error[$_[0]]\n";
	exit;
}
