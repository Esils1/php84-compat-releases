Antiquity-Soul v0.24.2
---------------------
HOMEPAGE: Monologue(http://myan.xo.st)
E-MAIL: vampelf@gmail.com



 안내사항

 - Antiquity-Soul(이하 A-S)는 D.Takamiya님의 FFADV를 개조하여 만들었습니다.

 - 이 스크립트의 사용으로 발생하는 손해에 대해선 일체 책임지지 않습니다.



 설치시 알아둘 점

  1. Perl의 경로
   a-s.cgi의 첫줄에 Perl의 경로를 지정해야합니다.
   '#!/usr/bin/perl'
   이 부분이며 대부분 이 값으로 되어있지만, #!/usr/local/bin/perl로 되어
   있는곳도 있습니다. 반드시 서버에 확인해보시기 바랍니다.

  2. 퍼미션의 설정
   A-S (777)--+--------- chara (755) / *.gif (644)
              |
              |-a-s.cgi (755)     메인 스크립트
              |-a-s.ini (644)     설정 파일
              |-monster.ini (644) 몬스터 데이타파일
              |-item.ini (644)    아이템 데이타파일
              |-magic.ini (644)   마법&기술 데이타파일
              |-data.cgi (666)   캐릭터 데이타파일
              |-battle.cgi (666)  전투기록 데이타파일
              |-recode.cgi (666)  신기록 데이타파일
              |-winner.cgi (666)  최강자 데이타파일
              |-message.cgi (666) 메세지 데이타파일
              |-bg.gif            배경 이미지파일
              |-title.jpg         타이틀 이미지파일
              |-pochi5.gif        최고연승표시 이미지파일
              |-rule.htm          게임의룰 설명파일

  3. Lock File에 대해
   lock기능이 완전하지 않기때문에 data.cgi,record.cgi의 백업은
  자주하는 것이 좋을듯 싶습니다.



 잡담
 
 - 버그많고 부족한 프로그램을 받아주셔서 감사합니다.

 - 0.24.1에서의 알려진 일부 문제를 해결하였습니다.

      +캐릭터 생성시 잘못 출력되는 능력치의 위치 수정.
      +방패 구입 문제 해결
      +4타이상 데미지가 제대로 들어가지 않던 문제 해결.