# wis 2004/02/28 유래

$image[0]=GetTagImgKao("도우미","help");
DataRead();
CheckUserPass();
$disp.="<BIG>●wis</BIG><br><br>";

if ($Q{form})
{
WisWrite();
}
else
{
WisForm();
}
OutSkin();
1;


sub WisForm
{
	$disp.=<<"HTML";
$TB$TR
$TD$image[0]$TD
<SPAN>도우미</SPAN>：상대에게 말을 건넬 수가 있어요.<br>
부디 실례가 없도록 해주세요.
$TRE$TBE<br>
<FORM ACTION="action.cgi" $METHOD>
$MYFORM$USERPASSFORM
<INPUT TYPE=HIDDEN NAME=mode VALUE="plus">
$TB
$TR$TDB<b>상대</b>
HTML

$disp.=$TD."<SELECT NAME=to><OPTION VALUE=\"-1\">－－상대 선택--";
	foreach (@DT)
	{
		$disp.="<OPTION VALUE=\"$_->{id}\">$_->{shopname}";
	}
$disp.="</SELECT>$TRE\n";

$disp.=<<"HTML";
$TR$TDB<b>내용</b>
$TD<INPUT TYPE=TEXT NAME=msg SIZE=60>$TRE
$TR$TD<SPAN>사용법</SPAN>$TD
·상대가 수신하기 전에 다른 wis가 보내지면, 처음의 wis는 사라져 버립니다.<br>
·상대가 로그인하고 있지 않는 경우, 나중이 되어 수신되는 일이 있습니다.<br>
·채팅 대신에 사용하는 것은 피합시다.
$TBE
<br><INPUT TYPE=HIDDEN NAME=form VALUE="plus">
<INPUT TYPE=SUBMIT VALUE="송신">
</FORM>
HTML
}

sub WisWrite
{
	my ($to,$msg)=($Q{to},$Q{msg});
	OutError("상대를 지정해 주세요.") if $to==-1;
	OutError("존재하지 않는 가게입니다.") if !defined($id2idx{$to});
	OutError("메시지를 입력해 주세요.") if !$msg;
	OutError('메시지의 캐릭터수가 많습니다.') if length($msg)>72;
	$NOMENU=1;$Q{bk}="wis";
	$msg=~s/&/&amp;/g;
	$msg=~s/>/&gt;/g;
	$msg=~s/</&lt;/g;
	OpenAndCheck(GetPath($SUBDATA_DIR,$DT[$id2idx{$to}]->{id}."-wis"));
	print OUT "<SPAN>$DT->{name}</SPAN> > <b>$msg</b>";
	close(OUT);
	$disp.="wis 송신했습니다.";
	return;
}


