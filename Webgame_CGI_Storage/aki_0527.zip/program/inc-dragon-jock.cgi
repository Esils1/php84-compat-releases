# 드래곤 레이스 기수 메뉴 표시 2005/03/30 유래

ReadJock();
$disp.="<BIG>●드래곤 레이스：기수</BIG><br><br>";

if ($MYJK==-1)
{
$disp.="$TB$TR$TD".GetTagImgKao("기수 동료","slime5").$TD;
$disp.="<SPAN>기수 동료</SPAN>：기수를 고용하지 않았군.<br>";
$disp.="기수를 고용하면, 자신이나 타인의 드래곤의 힘을 레이스로 이용할수 있다.".$TRE.$TBE."<br>";
if (scalar @JK < $JKmax)
	{
	FormJock();
	}
	else
	{
	$disp.="<BIG>●기수 고용</BIG>： 정원에 이르고 있기 때문에, 더 이상 고용할 수 없습니다.";
	}
}
else
{
$disp.="$TB$TR$TDB이름$TDB근속$TDB도선$TDB선추$TDB성적$TDB특수능력$TDB출주 $TRE";
$disp.=$TR;
$disp.=$TD.$JK[$MYJK]->{name};
$disp.=$TD.GetTime2found($NOW_TIME-$JK[$MYJK]->{birth});
$disp.=$TD.$VALUE[int($JK[$MYJK]->{ahead} /100*6)];
$disp.=$TD.$VALUE[int($JK[$MYJK]->{back} /100*6)];
$disp.=$TD.($JK[$MYJK]->{g1win} + 0)." - ".($JK[$MYJK]->{g2win} + 0)." - ".($JK[$MYJK]->{g3win} + 0)." - ".($JK[$MYJK]->{sdwin} + 0);
$disp.=$TD."<small>".$JKSP[($JK[$MYJK]->{sp} + 0)]."</small>";
$disp.=$TD.$ONRACE[$JK[$MYJK]->{race}];
$disp.=$TRE.$TBE;
}
1;

sub FormJock
{
my $estmsg=GetMoneyString($JKest);
$disp.=<<STR;
<FORM ACTION="action.cgi" $METHOD>
<INPUT TYPE=HIDDEN NAME=key VALUE="slime-s">
<INPUT TYPE=HIDDEN NAME=bk VALUE="slime">
$USERPASSFORM
<INPUT TYPE=HIDDEN NAME=mode VALUE="jkedit">
<INPUT TYPE=HIDDEN NAME=code VALUE="new">
<BIG>●기수 고용</BIG>： <INPUT TYPE=TEXT NAME=name SIZE=20> 이라고 이름 붙여
<INPUT TYPE=SUBMIT VALUE='고용'>
</FORM>
<br>
$TB$TR$TD
·기수를 고용하려면 ,자금 <b>$estmsg</b>가 듭니다.<br>
·기수는 전체로 <b>$JKmax</b>인이 정원이며, 만원이 되면 고용할 수 없습니다.
$TBE
STR
}


