# 길드 입단 처리 2003/11/03 유래

my $functionname=$Q{edit};
OutError("bad request") if !defined(&$functionname);
&$functionname;
WriteEntry();
CoDataCA();
CoUnLock();
1;


sub new
{
	OutError("bad request") if (!$DT->{guild});
	my $checkok;
	$ckeckok=1 if ($GUILD_DETAIL{$DT->{guild}}->{leadt} eq $MYDIR && $GUILD_DETAIL{$DT->{guild}}->{leader} == $DT->{id});
	$ckeckok=1 if ($GUILD_DETAIL{$DT->{guild}}->{$MYDIR} == $DT->{id});
	OutError("bad request") if (!$ckeckok);
	my $town="";
	my $id="";
	foreach my $pg(@OtherDir)
		{
		$id=$Q{$pg},$town=$pg if ($Q{$pg})
		}
	OutError('허가하는 상대를 지정해 주세요.') if !$id;
	foreach my $i(@MYENTRY)
		{
		OutError('이미 허가하고 있습니다.') if ($ENTRY[$i]->{town} eq $town && $ENTRY[$i]->{id}==$id);
		}

	@ENTRY=reverse(@ENTRY);
	$Ecount++;
	my $i=$Ecount;
	$ENTRY[$i]->{no}=($i > 0) ? ($ENTRY[$i-1]->{no} + 1) : 1;
	$ENTRY[$i]->{tm}=$NOW_TIME + 2 * 86400;
	$ENTRY[$i]->{town}=$town;
	$ENTRY[$i]->{id}=$id;
	$ENTRY[$i]->{guild}=$DT->{guild};
	@ENTRY=reverse(@ENTRY);
	$Q{mode}="submit";
}

sub join
{
OutError("bad request") if ($DT->{guild});
OutError("길드전중에 입단할 수 없습니다") if ($DTevent{guildbattle});
my $checkok;
	foreach my $cnt(0..$Ecount)
		{
		next if ($ENTRY[$cnt]->{town} ne $MYDIR || $ENTRY[$cnt]->{id} != $DT->{id});
		my $guild=$ENTRY[$cnt]->{guild};
		undef $ENTRY[$cnt];
		next if ($Q{guild} ne $guild);
		$checkok=1;
		}
OutError("허가가 나와 있지 않습니다") if (!$checkok);
	my $name=$GUILD{$Q{guild}}->[$GUILDIDX_name];
	my $member=$GUILD_DETAIL{$Q{guild}}->{member};
	PushLog(1,0,$DT->{shopname}."가 길드 「".$name."」의 ".$member." 되었습니다.");
	$DT->{guild}=$Q{guild};
RenewLog();
DataWrite();
DataCommitOrAbort();
UnLock();
$Q{mode}="joind";
}

sub WriteEntry
{
	undef @MYENTRY;		# 보존과 재정의를 동시에
	my @buf;
	foreach my $i(0..$Ecount)
		{
		next unless defined($ENTRY[$i]->{no});
		$buf[$i]=join(",",map{$ENTRY[$i]->{$_}}@ENTRYnamelist)."\n";
		push(@MYENTRY,$i) if ($ENTRY[$i]->{guild} eq $DT->{guild});
		}
	OpenAndCheck(GetPath($COTEMP_DIR,"entry"));
	print OUT @buf;
	close(OUT);
}



