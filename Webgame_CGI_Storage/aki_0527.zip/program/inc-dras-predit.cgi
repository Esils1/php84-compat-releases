# 드라곤레이스드라곤멘테 2005/03/30 유래

ReadDragon();
$disp.="<BIG>●드래곤 레이스：목장</BIG><br><br>";

my $functionname=$Q{code};
OutError("bad request") if !defined(&$functionname);
&$functionname;

WriteDragon();
CoDataCA();
1;

sub retire
{
	#드래곤 체크
	my $cnt=$id2dra{$Q{dr}};
	OutError("bad request") if ($DR[$cnt]->{town} ne $MYDIR || $DR[$cnt]->{owner} != $DT->{id});
	OutError("bad request") if ($DR[$cnt]->{race} > 1);
	OutError("bad request") if ($NOW_TIME-$DR[$cnt]->{birth} < $DRretire);

	OutError("드래곤을 은퇴시키려면 retire 라고 입력해 주세요") if ($Q{check} ne "retire");

	$disp.="드래곤 「".$DR[$cnt]->{name}."」(을)를 은퇴시켰습니다.";

	if ($DR[$cnt]->{prize} >= $PRentry)
	{
	$disp.="<br>현역 시대의 활약에 의해, ".($DR[$cnt]->{fm} ? "번식" : "종").$FM[$DR[$cnt]->{fm}]."룡입이 인정되었습니다.";
	PushDraLog(0,"드래곤 「".$DR[$cnt]->{name}."」(이)가 은퇴해, ".($DR[$cnt]->{fm} ? "번식" : "종").$FM[$DR[$cnt]->{fm}]."룡입했습니다.");
	RenewDraLog();

	ReadParent();
	
	@PR=reverse(@PR);
	$PRcount++;
	my $i=$PRcount;
	$PR[$i]->{no}=($i > 0) ? ($PR[$i-1]->{no} + 1) : 1 ;
	$PR[$i]->{birth}=$DR[$cnt]->{birth};
	$PR[$i]->{fm}=$DR[$cnt]->{fm};
	$PR[$i]->{color}=$DR[$cnt]->{color};
	$PR[$i]->{name}=$DR[$cnt]->{name};
	$PR[$i]->{town}=$MYDIR;
	$PR[$i]->{owner}=$DT->{id};
	$PR[$i]->{apt}=$DR[$cnt]->{apt};
	$PR[$i]->{hr}=int(rand(95)) + 5;

	$PR[$i]->{sp}=$DR[$cnt]->{sp} - $DR[$cnt]->{spp};
	$PR[$i]->{sr}=$DR[$cnt]->{sr} - $DR[$cnt]->{srp};
	$PR[$i]->{ag}=$DR[$cnt]->{ag} - $DR[$cnt]->{agp};
	$PR[$i]->{pw}=$DR[$cnt]->{pw} - $DR[$cnt]->{pwp};
	$PR[$i]->{hl}=$DR[$cnt]->{hl} - $DR[$cnt]->{hlp};
	$PR[$i]->{fl}=$DR[$cnt]->{fl} - $DR[$cnt]->{flp};

	$PR[$i]->{prize}=$DR[$cnt]->{prize};
	$PR[$i]->{sdwin}=$DR[$cnt]->{sdwin};
	$PR[$i]->{g3win}=$DR[$cnt]->{g3win};
	$PR[$i]->{g2win}=$DR[$cnt]->{g2win};
	$PR[$i]->{g1win}=$DR[$cnt]->{g1win};

	@PR=reverse(@PR);
	WriteParent();
	}

	undef $DR[$cnt];
}


sub preg
{
	OutError('더 이상 드래곤을 소유할 수 없습니다.') if (scalar @MYDR >= $MYDRmax);

	ReadParent();

	#자드래곤 체크
	my $p=$id2pr{$Q{dr}};
	OutError("bad request") if ($MYDIR ne $PR[$p]->{town});
	OutError("bad request") if ($PR[$p]->{owner}!=$DT->{id});
	OutError("bad request") if (!$PR[$p]->{fm});
	OutError("bad request") if ($NOW_TIME-$PR[$p]->{preg} < $PRcycle);

	#종 드래곤 체크
	my $q=$id2pr{$Q{pr}};
	OutError("bad request") if ($PR[$q]->{fm});

	# 이름의 정당성을 체크
	if(!$Q{name})
	{
		OutError('이름을 입력해 주세요.');
	}
	if($Q{name} =~ /([,:;\t\r\n<>&])/ || CheckNGName($Q{name}) )
	{
		OutError('이름에 사용할 수 없는 문자가 포함되어 있습니다.');
	}

	#한 번 EUC에 변환
	$ZkatakanaExt = '(?:\xA5[\xA1-\xF6]|\xA1[\xA6\xBC\xB3\xB4])';
#	OutError('이름은 전각 카타카나로 지정해 주세요.') if ($Q{name} !~ /^($ZkatakanaExt)*$/);

	OutError('이름이 너무 깁니다.') if length($Q{name})>20;
	OutError('이름이 너무 짧습니다.') if length($Q{name})<6;

	@DR=reverse(@DR);
	$DRcount++;
	my $i=$DRcount;
	$DR[$i]->{no}=($i > 0) ? ($DR[$i-1]->{no} + 1) : 1 ;
	$DR[$i]->{birth}=$NOW_TIME;
	$DR[$i]->{fm}=int(rand(2));
	$DR[$i]->{color}=int(rand(scalar @DRCOLOR));
	$DR[$i]->{name}=$Q{name};
	$DR[$i]->{town}=$MYDIR;
	$DR[$i]->{owner}=$DT->{id};

	my @preg=qw(
		apt sp sr ag pw hl fl
		);

	foreach(0..$#preg)
		{
		my $m=$preg[$_];
		$DR[$i]->{$m}=int(($PR[$p]->{$m} * $PR[$p]->{hr} + $PR[$q]->{$m} * $PR[$q]->{hr}) / ($PR[$p]->{hr} + $PR[$q]->{hr}));
		next if !$_;
		$DR[$i]->{$m}=int(($DR[$i]->{$m} * 4 + rand($DR[$i]->{$m}) * 2) / 5);
		$DR[$i]->{$m}=100 if ($DR[$i]->{$m} > 100);
		}

	$DR[$i]->{apt}=int(($DR[$i]->{apt} * 100 + 50) / 100);
	$DR[$i]->{con}=30 + int(rand(10));
	$DR[$i]->{wt}=43 + int(rand(3));

	@DR=reverse(@DR);

	$PR[$p]->{preg}=$NOW_TIME;
	WriteParent();

$disp.="새로운 드래곤 「<b>".$Q{name}."</b>」(이)가 탄생했습니다.";
}


