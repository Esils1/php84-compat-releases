# 아이템 진열 하청 2004/01/20 유래

$disp.=<<STR;
<FORM ACTION="action.cgi" $METHOD>
<INPUT TYPE=HIDDEN NAME=key VALUE="sc-s">
$USERPASSFORM
<INPUT TYPE=HIDDEN NAME=bk VALUE="$Q{bk}">
<INPUT TYPE=HIDDEN NAME=item VALUE="$itemno">
<BIG>●진열：</BIG>
<SELECT NAME=no>
STR
foreach my $cnt (1..$DT->{showcasecount})
{
	$disp.="<OPTION VALUE='".($cnt-1)."'".($showcase==$cnt?' SELECTED':'').">";
	$disp.="선반 $cnt($ITEM[$DT->{showcase}[$cnt-1]]->{name})";
}
	$disp.="</SELECT>";
	$disp.="에 표준 가격";
	$disp.=<<STR;
<SELECT NAME=per>
<OPTION VALUE='50'>5 할인
<OPTION VALUE='60'>4 할인
<OPTION VALUE='70'>3 할인
<OPTION VALUE='80'>2 할인
<OPTION VALUE='90'>1 할인
<OPTION VALUE='100' SELECTED>
<OPTION VALUE='110'>1 할증
<OPTION VALUE='120'>2 할증
</SELECT>
또는
<INPUT TYPE=TEXT NAME=prc SIZE=6 VALUE="$Q{pr}">원
그리고
<INPUT TYPE=SUBMIT VALUE='진열한다'>
(시간${\GetTime2HMS($TIME_EDIT_SHOWCASE)}소비)
</FORM>
STR
1;

