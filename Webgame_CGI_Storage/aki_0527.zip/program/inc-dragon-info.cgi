# 드래곤 레이스 빈 곳 스포 표시 2005/03/30 유래

$disp.="<BIG>●드래곤 레이스：옥희 스포츠</BIG><br><br>";
$disp.="$TB$TR$TD".GetTagImgKao("편집장","slime4").$TD;
$disp.="<SPAN>편집장</SPAN>：옥희스포츠신문에서는, 경룡에 도움이 되는 정보를 제공하고 있지요.<br>";
$disp.="버튼을 누르면 별도의 윈도우로 열리므로, 정보를 참조하면서 조작할 수 있지요.".$TRE.$TBE;
$disp.=<<STR;
<br><FORM>
<input type="button" value="스케줄" onclick="javascript:window.open('action.cgi?key=slime-l&mode=sche','_blank','width=760,height=580,scrollbars')">
<input type="button" value="경쟁룡 일람" onclick="javascript:window.open('action.cgi?key=slime-l&mode=dra','_blank','width=760,height=580,scrollbars')">
<input type="button" value="은거룡 일람" onclick="javascript:window.open('action.cgi?key=slime-l&mode=pr','_blank','width=760,height=580,scrollbars')">
<input type="button" value="목장 일람" onclick="javascript:window.open('action.cgi?key=slime-l&mode=rc','_blank','width=760,height=580,scrollbars')">
<input type="button" value="마굿간 일람" onclick="javascript:window.open('action.cgi?key=slime-l&mode=st','_blank','width=760,height=580,scrollbars')">
<input type="button" value="기수 일람" onclick="javascript:window.open('action.cgi?key=slime-l&mode=jk','_blank','width=760,height=580,scrollbars')">
</FORM>
STR
ReadDraLog();

my($page,$pagestart,$pageend,$pagenext,$pageprev,$pagemax);
my $pagecontrol="";
($page,$pagestart,$pageend,$pagenext,$pageprev,$pagemax)
	=GetPage($Q{lpg},$LIST_PAGE_ROWS,scalar(@MESSAGE));
	
	$pagecontrol=GetPageControl($pageprev,$pagenext,"mode=info","lpg",$pagemax,$page);
	$disp.=$pagecontrol;
	
	$disp.="<BR>";

$disp.=$TB;
$disp.=$TR.$TD;
foreach my $cnt ($pagestart..$pageend)
{
	my $msg=$MESSAGE[$cnt];
	next if $msg eq '';
	my($tm,$mode,$message) =split('\t',$msg);
	chop($message);

	if ($mode==1)
	{$disp.="<small>".GetTime2FormatTime($tm)."</small> <SPAN>[신룡]".$message."</SPAN>";}
	elsif ($mode==2)
	{$disp.="<small>".GetTime2FormatTime($tm)."</small> <BIG>[대상]".$message."</BIG>";}
	else
	{$disp.="<small>".GetTime2FormatTime($tm)."</small> ".$message;}
	$disp.="<BR>";
}
$disp.=$TRE.$TBE;
$disp.=$pagecontrol;
1;

sub ReadDraLog
{
	undef @MESSAGE;
	open(IN,GetPath($COMMON_DIR,"dra-log0"));
	push(@MESSAGE,<IN>);
	close(IN);
	open(IN,GetPath($COMMON_DIR,"dra-log1"));
	push(@MESSAGE,<IN>);
	close(IN);
	@MESSAGE=("0Yt0\t정보는 없습니다 \n") if !scalar(@MESSAGE);
}


