# 입상 리스트 표시 2005/01/06 유래

$disp.="<BIG>●신문：입상 리스트</BIG><br><br>";
$disp.=$TB.$TR;

	@DT=sort{$b->{rankingcount}<=>$a->{rankingcount}}@DT;

$disp.=$TDNW.$tdh_pt.GetTagImgKao($DT[0]->{name},$DT[0]->{icon});
$disp.=$TD."<SPAN>최다 우승</SPAN><br><b>".$DT[0]->{shopname}."</b>";
$disp.="<td>우승 회수<br>".($DT[0]->{rankingcount}+0)."회";
$disp.="<td>".$DT[0]->{comment};

	@DT=sort{$b->{taxyesterday}<=>$a->{taxyesterday}}@DT;

$disp.=$TRE.$TR;
$disp.=$TDNW.$tdh_pt.GetTagImgKao($DT[0]->{name},$DT[0]->{icon});
$disp.=$TD."<SPAN>납세 탑</SPAN><br><b>".$DT[0]->{shopname}."</b>";
$disp.="<td>전기 납세금<br>".GetMoneyString($DT[0]->{taxyesterday});
$disp.="<td>".$DT[0]->{comment};

	@DT=sort{$b->{money}<=>$a->{money}}@DT;

$disp.=$TRE.$TR;
$disp.=$TDNW.$tdh_pt.GetTagImgKao($DT[0]->{name},$DT[0]->{icon});
$disp.=$TD."<SPAN>대부호</SPAN><br><b>".$DT[0]->{shopname}."</b>";
$disp.="<td>자금<br>".GetMoneyString($DT[0]->{money});
$disp.="<td>".$DT[0]->{comment};

	@DT=reverse(@DT);

$disp.=$TRE.$TR;
$disp.=$TDNW.$tdh_pt.GetTagImgKao($DT[0]->{name},$DT[0]->{icon});
$disp.=$TD."<SPAN>가난뱅이</SPAN><br><b>".$DT[0]->{shopname}."</b>";
$disp.="<td>자금<br>".GetMoneyString($DT[0]->{money});
$disp.="<td>".$DT[0]->{comment};

	@DT=sort{$b->{costyesterday}<=>$a->{costyesterday}}@DT;

$disp.=$TRE.$TR;
$disp.=$TDNW.$tdh_pt.GetTagImgKao($DT[0]->{name},$DT[0]->{icon});
$disp.=$TD."<SPAN>가장 많은 유지비</SPAN><br><b>".$DT[0]->{shopname}."</b>";
$disp.="<td>전기 유지비<br>".GetMoneyString($DT[0]->{costyesterday});
$disp.="<td>".$DT[0]->{comment};

	@DT=sort{$b->{trush}<=>$a->{trush}}@DT;

$disp.=$TRE.$TR;
$disp.=$TDNW.$tdh_pt.GetTagImgKao($DT[0]->{name},$DT[0]->{icon});
$disp.=$TD."<SPAN>더러운 게으름뱅이</SPAN><br><b>".$DT[0]->{shopname}."</b>";
$disp.="<td>쓰레기<br>".GetCleanMessage($DT[0]->{trush});
$disp.="<td>".$DT[0]->{comment};

	@DT=sort{$b->{rank}<=>$a->{rank}}@DT;

$disp.=$TRE.$TR;
$disp.=$TDNW.$tdh_pt.GetTagImgKao($DT[0]->{name},$DT[0]->{icon});
$disp.=$TD."<SPAN>지금 대인기</SPAN><br><b>".$DT[0]->{shopname}."</b>";
$disp.="<td>인기<br>".GetRankMessage($DT[0]->{rank});
$disp.="<td>".$DT[0]->{comment};

	@DT=reverse(@DT);

$disp.=$TRE.$TR;
$disp.=$TDNW.$tdh_pt.GetTagImgKao($DT[0]->{name},$DT[0]->{icon});
$disp.=$TD."<SPAN>파리 날리는 집</SPAN><br><b>".$DT[0]->{shopname}."</b>";
$disp.="<td>인기<br>".GetRankMessage($DT[0]->{rank});
$disp.="<td>".$DT[0]->{comment};

$disp.="</td></tr></table>";
1;

