# 궁전 달성 처리 2004/01/20 유래

Lock();
RequireFile("inc-palace.cgi");
$image[0]=GetTagImgKao("임금님","king",'align="left" ');
$image[1]=GetTagImgKao("대신","minister",'align="left" ');

DataRead();
CheckUserPass();

$evt=GetTownData('evt');
$evt=0 if (!$evt);
$level=DignityDefine($DT->{dignity});

$disp.="<BIG>●궁전</BIG><br><br>";

$shopname=$DT->{shopname};
$name=$DT->{name};
$need=$itemno[$evt];

if ( $DT->{item}[$need-1] < $count[$evt] )
	{
	$disp.='<TABLE cellpadding="26" width="570"><tr>';
	$disp.=qq|<TD style="background-repeat : repeat-x;background-image : url($IMAGE_URL/palace.png);" valign="top"><br><br>|;
	$disp.=$image[0].'뭐라는 겐가<b>'.$shopname.'</b>의<b>'.$name.$level.'</b>.<br>';
	$disp.='<b>'.GetTagImgItemType($need).$ITEM[$need]->{name}.$count[$evt].$ITEM[$need]->{scale}.'</b>는,아직도 갖추어 지지 못한 것인가!<br>';
	$disp.='그렇지 않으면 '.$name.'는 짐을 조롱하고 있는 것은 아닌가?';
	$disp.='<br>빠르게 사명을 달성하는 것을 잊으면 안된다.'.$TRE;
	$disp.=$TBE."<br>임금님은 분노하기 시작해 버렸습니다.";
	}
	else
	{
	$disp.='<TABLE cellpadding="26" width="570"><tr>';
	$disp.=qq|<TD style="background-repeat : repeat-x;background-image : url($IMAGE_URL/palace.png);" valign="top"><br><br>|;
	$disp.=$image[0].'훌륭하군<b>'.$shopname.'</b>의<b>'.$name.$level.'</b>.<br>';
	$disp.='<b>'.GetTagImgItemType($need).$ITEM[$need]->{name}.$count[$evt].$ITEM[$need]->{scale}.'</b>는 확실히 받았다.<br>';
	$disp.='따라서 너에게 포상으로서 '.DignityDefine(1,1).'<b>작위 경험치</b>를 주도록 하마.'.$TRE;
	$disp.=$TBE."<br>";

	$DT->{item}[$need-1] -= $count[$evt];
	$DT->{dignity}++;
	$evt=int(rand(scalar(@itemno)));
	SetTownData('evt',$evt);

	PushLog(0,0,$DT->{shopname}.'가 임금님의 사명을 달성했습니다.');
	RenewLog();
	DataWrite();
	DataCommitOrAbort();
	}
UnLock();
OutSkin();
1;

