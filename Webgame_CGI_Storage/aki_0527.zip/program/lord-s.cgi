# 영주저 2004/01/20 유래

$image[0]=GetTagImgKao("대신","minister");
Lock();
DataRead();
CheckUserPass();

my $functionname=$Q{mode};
OutError("bad request") if !defined(&$functionname);
&$functionname;
RenewLog();
DataWrite();
DataCommitOrAbort();
UnLock();

OutSkin();
1;

sub inside
{
if ($Q{taxrate} =~ /([^0-9])/
	|| $Q{devem} =~ /([^0-9])/
	|| $Q{safem} =~ /([^0-9])/
	) { OutError('사용할 수 있는 캐릭터는 반각 숫자 뿐입니다'); }
OutError($image[0].'뭐든지 적당히가 중요해요.') if ($Q{taxrate} > 40) ;
OutError($image[0].'한 번에 그만큼 대책비를 쏟아 넣어도 무의미해요.') if ($Q{devem} > 10000000 || $Q{safem} > 10000000) ;

$Q{taxrate}=0 if $Q{taxrate}<0;
$Q{devem}=0 if $Q{devem}<0;
$Q{safem}=0 if $Q{safem}<0;
my $taxrate=int($Q{taxrate});
$disp.="거리의 내정 방침을 변경했습니다.";

if ($DTTaxrate != $taxrate )
	{
	my $i="인상했습니다";
	$i="인하했습니다" if $DTTaxrate > $taxrate;
	$DTTaxrate=int($Q{taxrate});
	PushLog(2,0,"영주 ".$DT->{name}."(은)는 거리의 세율을 $taxrate%로 $i.");
	$disp.="<br>거리의 세율을 $taxrate%로 $i.";
	}
$STATE->{devem}=int($Q{devem});
$STATE->{safem}=int($Q{safem});
}

sub outside
{
OutError('반란중이기 때문에 고용할 수 없습니다.') if $DTevent{rebel};
my $stock=int($STATE->{money} / 1200);
$count=CheckCount($Q{cnt1},$Q{cnt2},0,$stock);
OutError('고용 인원수를 지정해 주세요') if !$count;
$STATE->{money}-=$count * 1200;
$STATE->{army}+=$count;
$disp.="호위군을 $count인 고용했습니다.";
}

sub outdel
{
OutError('반란중이기 때문에 해고할 수 없습니다.') if $DTevent{rebel};
$count=CheckCount($Q{cnt1},$Q{cnt2},0,$STATE->{army});
OutError('해고 인원수를 지정해 주세요') if !$count;
$STATE->{army}-=$count;
$disp.="호위군을 $count인 해고했습니다.";
}

sub taxside
{
OutError('대상 지점을 선택해 주세요.') if !defined($id2idx{$Q{tg}});
my $i=$id2idx{$Q{tg}};
if ($Q{md} eq "free")
	{
	PushLog(2,0,"영주 ".$DT->{name}."는 ".$DT[$i]->{shopname}."의 세를 면제했습니다.") if ($DT[$i]->{taxmode}!=1);
	$DT[$i]->{taxmode}=1;
	$disp.=$DT[$i]->{shopname}."의 세를 면제했습니다.";
	}
elsif ($Q{md} eq "double")
	{
	PushLog(2,0,"영주 ".$DT->{name}."는 ".$DT[$i]->{shopname}."의 세율을 배로 했습니다.") if ($DT[$i]->{taxmode}!=2);
	$DT[$i]->{taxmode}=2;
	$disp.=$DT[$i]->{shopname}."의 세율을 배로 했습니다.";
	}
	else
	{
	PushLog(2,0,"영주 ".$DT->{name}."는 ".$DT[$i]->{shopname}."의 면세를 취소했습니다.") if ($DT[$i]->{taxmode}==1);
	PushLog(2,0,"영주 ".$DT->{name}."는 ".$DT[$i]->{shopname}."의 중과세를 취소했습니다.") if ($DT[$i]->{taxmode}==2);
	delete $DT[$i]->{taxmode};
	$disp.=$DT[$i]->{shopname}."의 세를 통상으로 되돌렸습니다.";
	}
}

sub treset
{
foreach (@DT) {
	delete $_->{taxmode};
}
PushLog(2,0,"영주".$DT->{name}."(은)는 중과세나 면세를 모두 취소했습니다.");
$disp.="모든 가게의 세율을 통상으로 되돌렸습니다.";
}

sub expose
{
OutError('반란중이기 때문에 실행할 수 없습니다.') if $DTevent{rebel};
OutError('대상가게를 선택해 주세요.') if !defined($id2idx{$Q{tg}});
OutError('비용이 충분하지 않습니다.') if ($STATE->{money} < 1000000);
my $i=$id2idx{$Q{tg}};
OutError($image[0].'그 가게에 대한 단속은 그다지 의미가 없는 것 같아요.') if ($DT[$i]->{rank} < 2000) ;
$STATE->{money}-=1000000;
$DT[$i]->{rank}=int($DT[$i]->{rank} / 10);
$STATE->{safety}+=500;
$STATE->{safety}=10000 if $STATE->{safety} > 10000;
PushLog(2,0,"영주 ".$DT->{name}."는 ".$DT[$i]->{shopname}."에 대해서 단속을 실시했습니다.");
$disp.=$DT[$i]->{shopname}."에 대해서 단속을 실시했습니다.";
}

