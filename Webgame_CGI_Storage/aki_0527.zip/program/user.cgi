# 사용자 정보 변경 처리 2005/03/30 유래

Lock();
DataRead();
CheckUserPass();
$Q{er}='other';

my $functionname=$Q{mode};
OutError("bad request") if !defined(&$functionname);
&$functionname;

RenewLog();
DataWrite();
DataCommitOrAbort();
UnLock();

OutSkin();
1;

sub comment
{
	$comment=$Q{cmt};
	if(($comment) =~ /([,:;\t\r\n<>&])/
	|| CheckNGName($comment)
	)
		{
		OutError('댓글에 사용할 수 없는 캐릭터가 포함되어 있습니다.');
		}
	OutError('댓글의 캐릭터수가 많습니다.') if length($comment)>36;
	$comment=~s/&/&amp;/g;
	$comment=~s/>/&gt;/g;
	$comment=~s/</&lt;/g;
	$DT->{comment}=$comment;
	$disp.="댓글 갱신했습니다";
}

sub icon
{
	$DT->{icon}=$Q{icon};
	$disp.="점주 아이콘 변경했습니다";
}

sub shopname
{
	OutError('자금이 충분하지 않습니다.') if $DT->{money}<50000;
	if(($Q{rename}) =~ /([,:;\t\r\n<>&])/
	|| CheckNGName($Q{rename})
	)
		{
		OutError('가게명에 사용할 수 없는 캐릭터가 포함되어 있습니다.');
		}
	OutError('가게명은 20 캐릭터 이내입니다.') if length($Q{rename})>20;
	OutError('가게명이 너무 짧습니다.') if length($Q{rename})<4;
	OutError('이미 존재하는 가게명입니다.-> '.$Q{rename}) if GetDoubleName($Q{rename});;
	PushLog(1,0,$DT->{shopname}."가 「".$Q{rename}."」으로 가게명을 고쳤습니다.");
	$DT->{shopname}=$Q{rename};
	$DT->{money}-=50000;
	$disp.=$DT->{shopname}."으로 개명했습니다.<BR>탑에서 다시 입점해 주세요.<BR><BR>";
	$disp.="<A HREF='index.cgi'>탑에</A> ";
}

sub owname
{
	OutError('자금이 충분하지 않습니다.') if $DT->{money}<50000;
	if(($Q{owname}) =~ /([,:;\t\r\n<>&])/
	|| CheckNGName($Q{owname})
	)
		{
		OutError('이름에 사용할 수 없는 캐릭터가 포함되어 있습니다.');
		}
	OutError('이름은 12 캐릭터 이내입니다.') if length($Q{owname})>12;
	OutError('이름이 너무 짧습니다.') if length($Q{owname})<2;
	OutError('이미 존재하는 이름입니다.-> '.$Q{owname}) if $name2pass{$Q{owname}};
	PushLog(1,0,$DT->{name}."가 「".$Q{owname}."」에 개명했습니다.");
	$DT->{name}=$Q{owname};
	$DT->{money}-=50000;
	$disp.=$DT->{name}."에 개명했습니다.<BR>탑에서 다시 입점해 주세요.<BR><BR>";
	$disp.="<A HREF='index.cgi?u=$DT->{name}'>탑에</A> ";
}

sub repass
{
	OutError('확인 입력과 불일치이기 때문에 변경중 중지합니다.') if $Q{pw1}ne$Q{pw2};
	OutError('변경 비밀번호가 입력되고 있지 않습니다.') if $Q{pw1}eq'';
	OutError('비밀번호에 사용할 수 없는 캐릭터가 있었으므로 변경중 중지합니다.') if $Q{pw1}=~/[^a-zA-Z0-9_\-]/;
	OutError('비밀번호는 8 캐릭터까지입니다.') if length($Q{pw1})>8;
	$DT->{pass}=$PASSWORD_CRYPT ? crypt($Q{pw1},GetSalt()) : $Q{pw1};
	$disp.="비밀번호 변경했습니다<BR>탑보다 다시 입점해 주세요<BR><BR>";
	$disp.="<A HREF='index.cgi?nm=$DT->{name}&pw=$Q{pw1}'>탑에</A> ";
}

sub restart
{
	RequireFile('inc-req.cgi');
	OutError('재출발하고 싶은 경우는 restart 라고 입력해 주세요.') if $Q{rss} ne 'restart';
	OutError('창업 후 3시간 이내는 재출발할 수 없습니다') if (($NOW_TIME-$DT->{foundation}) < 3600*3);
	my @list=map{$_->{id}}@REQ;
	@list=grep($_ eq $DT->{id},@list);
	OutError('의뢰소에서 당신을 기다리고 있을지 모릅니다. 취소하고나서 재출발합시다.') if @list;

	my ($id,$name,$shopname,$pass,$icon)=($DT->{id},$DT->{name},$DT->{shopname},$DT->{pass},$DT->{icon});
	while(my($key,$val) =each %$DT) { delete $DT->{$key}; }
	($DT->{id},$DT->{name},$DT->{shopname},$DT->{pass},$DT->{icon},$DT->{time})=($id,$name,$shopname,$pass,$icon);
	$DT->{status}	      =1;
	$DT->{lastlogin}    =$NOW_TIME;
	$DT->{money}        =100000;
	$DT->{rank}         =5010;
	$DT->{foundation}   =$NOW_TIME;
	$DT->{showcasecount}=1;
	require "$ITEM_DIR/funcnew.cgi" if $DEFINE_FUNCNEW;
	opendir(SESS,$SUBDATA_DIR);
	my @dir=readdir(SESS);
	closedir(SESS);
	foreach(map{"$SUBDATA_DIR/$_"}grep(/^$DT->{id}\-.+\.cgi$/,@dir))
	{
		unlink $_;
	}
	PushLog(1,0,$DT->{shopname}."가 새로운 기분으로 다시 했습니다.");
	$disp.="데이터가 초기화되었습니다.<BR><BR>기분을 새롭게 노력해 주세요♪";
}

sub cls
{
	OutError('폐점 하고 싶은 경우는 closeshop 라고 입력해 주세요.') if $Q{cls}ne'closeshop';
	SetCookieSession();
	$USERPASSURL=$USERPASSFORM="";
	CloseShop($DT->{id},'자발적 폐점');
	PushLog(1,0,$DT->{shopname}."가 폐점했습니다.");
	$disp.="폐점의 수속이 완료했습니다.<BR><BR>"
		  ."본게임에의 참가,정말로 감사합니다.";
	$DTblockip=$DT->{remoteaddr};
}

sub guild
{
	OutError('탈퇴하려면  leave와 입력해 주세요') if $Q{guild} ne 'leave';
	OutError('길드에 입단하고 있지 않았기 때문에 탈퇴의 필요가 없습니다') if !$DT->{guild};
	ReadGuild();
	my $name=$GUILD{$DT->{guild}}->[$GUILDIDX_name];
	$name="해산한 길드" if $name eq '';;
	PushLog(1,0,$DT->{shopname}."가 길드 「".$name."」(으)로부터 탈퇴했습니다.");
	$disp.=$name."(으)로부터 탈퇴했습니다.";
	delete $DT->{user}{_so_e};
	$DT->{guild}="";
}


