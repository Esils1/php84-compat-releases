# 아이템 리스트 2005/03/30 유래

# -------- 설정 부분 ---------
# 열람 설정
$listcheck=2;		# 아이템 소개는0:가게 소유자 밖에 볼 수  없는,1:누구라도 볼 수 있는,2:관리자 밖에 볼 수  없다(추천).

# 플레이어에는 보이지 않는 아이템(번호로 지정)
# 지정예… $DENYITEM='25,86';  ←No.25로 86을 표시하지 않는다.

$DENYITEM='';

# 플레이어가 볼 때의 표시 설정
$design_no=0;		#아이템 No를0:표시하지 않는(추천),1:표시한다.
$design_sale=0;		#매출을0:표시하지 않는(추천),1:표시한다.
$design_prof=1;		#이익율을0:수치로 표시,1:5 단계 표시(추천).
$design_rank=1;		#인기율을0:수치로 표시,1:5 단계 표시(추천).
$design_plus=1;		#시장 입하를0:수치로 표시,1:0×으로 표시(추천).

# -------- 설정 완료 ---------

DataRead();
CheckUserPass($listcheck);
$DENYITEM=','.$DENYITEM.',';

if ($MASTER_USER) {
$NOMENU=1;
$Q{bk}="none";
@NGItem=(0);
$design_no=1;
$design_sale=1;
$design_prof=0;
$design_rank=0;
$design_plus=0;
$disp.="<BIG>●아이템 데이터</BIG><br><br>";
} else {
OutError("bad request") if ($listcheck == 2);
$disp.="<BIG>●아이템 소개</BIG><br><br>";
}

my $tp=int($Q{tp}+0);
undef %adminitemlist;
my($ITEM,$stock,$price,$mpl,$mph,$popular,$uppoint);

foreach my $no(1..$MAX_ITEM)
{
	next if ($DENYITEM =~ /,$no,/);
	$ITEM=$ITEM[$no];
	next if ($ITEM->{type} != $tp)&&($tp != 0);;
	$adminitemlist{$no}=$ITEM;
}

foreach my $cnt (0..$#ITEMTYPE)
{
	$disp.=$cnt==$tp ? "[" : "<A HREF=\"action.cgi?key=item-list&$USERPASSURL&tp=$cnt\">";
	$disp.=GetTagImgItemType(0,$cnt) if $cnt && !$MOBILE;
	$disp.=$ITEMTYPE[$cnt];
	$disp.=$cnt==$tp ? "]" :"</A> ";
	$disp.=" ";
}
	$disp.="<br>";

my($page,$pagestart,$pageend,$pagenext,$pageprev,$pagemax)
	=GetPage($Q{pg},$LIST_PAGE_ROWS,scalar(keys(%adminitemlist)));

$disp.=GetPageControl($pageprev,$pagenext,"tp=$tp","",$pagemax,$page);

$disp.=$TB;
$disp.=$TR;
$disp.=$TDB.'No.' if $design_no;
$disp.=$TDB.'상품명';
$disp.=$TDB.'표준 가격';
$disp.=$TDB.'유지비';
$disp.=$TDB.'매행' if $design_sale;
$disp.=$TDB.'이익율';
$disp.=$TDB.'인기율';
$disp.=$TDB.'입하';
$disp.=$TDB.'설명';
$disp.=$TRE;
foreach my $ITEM ((sort{$a->{sort} <=> $b->{sort}} values(%adminitemlist))[$pagestart..$pageend])
{
	my $itemno=$ITEM->{no};
	$disp.=$TR;
	$disp.=$TDNW.$itemno if $design_no;
	$disp.=$TDNW;
	$disp.=GetTagImgItemType($itemno).$ITEM->{name}."</A> ";
	$disp.=$TDNW.GetMoneyString($ITEM->{price});
	$disp.=$TDNW.GetMoneyString($ITEM->{cost});

	my $admin_item=int($ITEM->{popular}/$SALE_SPEED);

	$disp.=$TDNW.($admin_item ? GetTime2HMS($admin_item) : "×")  if $design_sale;

	if ($design_prof) {
	$disp.=$TDNW.($admin_item ? GetStarRank(int($ITEM->{price} *24*6*6/10 / $admin_item)) : "");
	} else {
	$disp.=$TDNW.($admin_item ? int($ITEM->{price} *24*6*6/10 / $admin_item) : "---");
	}

	if ($design_rank) {
	$disp.=$TDNW.($admin_item ? GetStarRank(int($ITEM->{point} *24*6*6/10 / $admin_item)) : "");
	} else {
	$disp.=$TDNW.($admin_item ? int($ITEM->{point} *24*6*6/10 / $admin_item) : "---");
	}

	if ($ITEM->{plus} > 0) { 
	$disp.=($design_plus ? $TDNW."○" : $TDNW.GetTime2HMS($ITEM->{plus}));
	} else { $disp.=$TDNW."×" }

	$disp.=$TDNW."<small>".$ITEM->{info}."</small>";
	$disp.=$TRE;
}
$disp.=$TBE;
$disp.=GetPageControl($pageprev,$pagenext,"tp=$tp","",$pagemax,$page);
OutSkin();
1;

sub GetStarRank		#표시의 사용자 지정 가능.
{
	my($no)=@_;
	my $flag='<font color="#cccc99">||</font>';
	$flag.='<font color="#ddcc44">||</font>' if $no > 50;
	$flag.='<font color="#ffcc00">||</font>' if $no > 90;
	$flag.='<font color="#ff9900">||</font>' if $no > 120;
	$flag.='<font color="#ff6600">||</font>' if $no > 180;
	return $flag;
}

