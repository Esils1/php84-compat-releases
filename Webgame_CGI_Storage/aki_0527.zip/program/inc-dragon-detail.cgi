# 드래곤 레이스 드래곤 상세 표시 2005/03/30 유래

$disp.="<BIG>●드래곤 레이스：목장</BIG><br><br>";

ReadDragon();
my $cnt=$id2dra{$Q{dr}};
OutError("bad request") if ($DR[$cnt]->{town} ne $MYDIR || $DR[$cnt]->{owner} != $DT->{id});
my $stname="";
$forment="";

ReadStable();
if (scalar @ST)
	{
	foreach(0..$STcount)
		{
		$stname=$ST[$_]->{name} if ($ST[$_]->{no}==$DR[$cnt]->{stable});
		$forment.="<OPTION VALUE=\"$ST[$_]->{no}\">$ST[$_]->{name}";
		}
	}

$disp.="$TB$TR$TDB 명칭$TDB 연령$TDB 성별$TDB 모색$TDB 예탁 마굿간$TDB각질$TDB 거리 적성$TDB총상금$TDB 성적$TDB 출주 $TRE";
$disp.=$TR;
$disp.=$TD."<b>".GetTagImgDra($DR[$cnt]->{fm},$DR[$cnt]->{color}).$DR[$cnt]->{name}."</b>";
$disp.=$TD.GetTime2found($NOW_TIME-$DR[$cnt]->{birth});
$disp.=$TD.$FM[$DR[$cnt]->{fm}];
$disp.=$TD.$DRCOLOR[$DR[$cnt]->{color}];
$disp.=$TD.$stname;
$disp.=$TD.$STRATE[ GetRaceStrate($DR[$cnt]->{sr},$DR[$cnt]->{ag}) ];
$disp.=$TD.GetRaceApt($DR[$cnt]->{apt},$DR[$cnt]->{fl})."km";
$disp.=$TD.($DR[$cnt]->{prize} + 0)."만";
$disp.=$TD.($DR[$cnt]->{g1win} + 0)." - ".($DR[$cnt]->{g2win} + 0)." - ".($DR[$cnt]->{g3win} + 0)." - ".($DR[$cnt]->{sdwin} + 0);
$disp.=$TD.$ONRACE[$DR[$cnt]->{race}];
$disp.=$TRE;
$disp.=$TBE."<br>";
$disp.="<BIG>●능\력의 상세</BIG><br><br>";
$disp.=$TB;
$disp.=$TR.$TDB."스피드".$TD.GetDragonBar($DR[$cnt]->{sp},$DR[$cnt]->{spp}).$TRE;
$disp.=$TR.$TDB."승부 근성".$TD.GetDragonBar($DR[$cnt]->{sr},$DR[$cnt]->{srp}).$TRE;
$disp.=$TR.$TDB."순발력".$TD.GetDragonBar($DR[$cnt]->{ag},$DR[$cnt]->{agp}).$TRE;
$disp.=$TR.$TDB."파워".$TD.GetDragonBar($DR[$cnt]->{pw},$DR[$cnt]->{pwp}).$TRE;
$disp.=$TR.$TDB."건강".$TD.GetDragonBar($DR[$cnt]->{hl},$DR[$cnt]->{hlp}).$TRE;
$disp.=$TR.$TDB."유연성".$TD.GetDragonBar($DR[$cnt]->{fl},$DR[$cnt]->{flp}).$TRE;
$disp.=$TR.$TDB."컨디션".$TD.GetConBar($DR[$cnt]->{con}).$TRE;
$disp.=$TR.$TDB."체중".$TD.GetWtBar($DR[$cnt]->{wt}).$TRE;
$disp.=$TR.$TDB."성장도".$TD.GetConBar($DR[$cnt]->{gr},1).$TRE;
$disp.=$TBE."<br>";
if ($DR[$cnt]->{race} < 2)
	{
	FormEnt() if (scalar @ST);
	FormToRace();
	FormRetire() if ($NOW_TIME-$DR[$cnt]->{birth} > $DRretire);
	}
1;

sub GetDragonBar
{
	my($point,$up)=@_;
	my $per=$point - $up;
	
	my $bar="";
	$bar ="<nobr>";
	$bar.=qq|<img src="$IMAGE_URL/b.gif" width="|.($per).qq|" height="12">| if $per;
	$bar.=qq|<img src="$IMAGE_URL/r.gif" width="|.($up).qq|" height="12">| if $up;
	$bar.=qq|<img src="$IMAGE_URL/t.gif" width="|.(100-$point).qq|" height="12">| if $point!=100;
	$bar.=" ".($per + 0)." + ".($up + 0);
	$bar.="</nobr>";
	return $bar;
}

sub GetConBar
{
	my($per,$mode)=@_;
	
	$per=100 if $per > 100;
	my $bar="";
	$bar ="<nobr>";
	$bar.=qq|<img src="$IMAGE_URL/r.gif" width="|.($per).qq|" height="12">| if $per;
	$bar.=qq|<img src="$IMAGE_URL/t.gif" width="|.(100-$per).qq|" height="12">| if $per!=100;
	$bar.=" ".$EVALUE[int($per/100*4)] if !$mode;
	$bar.=" ".($per + 0)."%";
	$bar.="</nobr>";
	return $bar;
}

sub GetWtBar
{
	my($point)=@_;
	my $per=($point - 40) * 5;
	my $rank=int(($point - 50) / 2);
	$rank=-$rank if ($rank < 0);
	$rank=3 - $rank;
	$rank=0 if $rank < 0;
	
	my $bar="";
	$bar ="<nobr>";
	$bar.=qq|<img src="$IMAGE_URL/r.gif" width="|.($per).qq|" height="12">| if $per;
	$bar.=qq|<img src="$IMAGE_URL/t.gif" width="|.(100-$per).qq|" height="12">| if $per!=100;
	$bar.=" ".$EVALUE[int($rank)]." ".$point."톤";
	$bar.="</nobr>";
	return $bar;
}

sub FormEnt
{
my $costmsg=GetMoneyString($STcost);
$disp.=<<STR;
<FORM ACTION="action.cgi" $METHOD>
<INPUT TYPE=HIDDEN NAME=key VALUE="slime-s">
<INPUT TYPE=HIDDEN NAME=bk VALUE="slime">
$USERPASSFORM
<INPUT TYPE=HIDDEN NAME=mode VALUE="dredit">
<INPUT TYPE=HIDDEN NAME=code VALUE="ent">
<INPUT TYPE=HIDDEN NAME=dr VALUE="$Q{dr}">
<BIG>●마굿간 예탁</BIG>： <SELECT NAME=ent SIZE=1>
$forment
</SELECT> 에 드래곤을 
<INPUT TYPE=SUBMIT VALUE='예탁'>
</FORM>
<br>
$TB$TR$TD
·마굿간에게 드래곤을 예탁하면,조교에 의한 성장을 전망할 수 있습니다.<br>
·예탁료가 매일 <b>$costmsg</b> 듭니다.
$TBE<br>
STR
}

sub FormToRace
{
my $formrace="";
my $formjock="<OPTION VALUE=\"0\">－－기수 없음--";
my $formstrate="";
foreach (0..$#RACETERM)
	{
	$formrace.="<OPTION VALUE=\"$_\">$RACETERM[$_]";
	}
foreach (0..3)
	{
	$formstrate.="<OPTION VALUE=\"$_\">$STRATE[$_]";
	}
ReadJock();
if (scalar @JK)
	{
	foreach(0..$JKcount)
		{
		next if $JK[$_]->{race} > 1;
		$formjock.="<OPTION VALUE=\"$JK[$_]->{no}\">$JK[$_]->{name}";
		}
	}


$disp.=<<STR;
<FORM ACTION="action.cgi" $METHOD>
<INPUT TYPE=HIDDEN NAME=key VALUE="slime-s">
<INPUT TYPE=HIDDEN NAME=bk VALUE="slime">
$USERPASSFORM
<INPUT TYPE=HIDDEN NAME=mode VALUE="dredit">
<INPUT TYPE=HIDDEN NAME=code VALUE="torace">
<INPUT TYPE=HIDDEN NAME=dr VALUE="$Q{dr}">
<BIG>●레이스 출주 등록</BIG>：드래곤을 <SELECT NAME=rcode SIZE=1>
$formrace
</SELECT> 에, 기수 <SELECT NAME=jock SIZE=1>
$formjock
</SELECT> 작전 <SELECT NAME=str SIZE=1>
$formstrate
</SELECT> 으로 
<INPUT TYPE=SUBMIT VALUE='출주'>
</FORM>
<br>
$TB$TR$TD
·정원을 넘기면, 추첨에 의해 출주할 수 없는 경우가 있습니다.<br>
·출주하면, 그 사이의 조교를 하지 않는 데다가, 컨디션·체중이 감소합니다.<br>
·레이스의 거리나 핸디캡, 다른 출장룡 등을 봐, 불리하게 되지 않을지 확인합시다.
$TBE<br>
STR
}

sub FormRetire
{
my $remsg=GetTime2found($DRretire);
$disp.=<<STR;
<FORM ACTION="action.cgi" $METHOD>
<INPUT TYPE=HIDDEN NAME=key VALUE="slime-s">
<INPUT TYPE=HIDDEN NAME=bk VALUE="slime">
$USERPASSFORM
<INPUT TYPE=HIDDEN NAME=mode VALUE="predit">
<INPUT TYPE=HIDDEN NAME=code VALUE="retire">
<INPUT TYPE=HIDDEN NAME=dr VALUE="$Q{dr}">
<BIG>●은퇴</BIG>： 드래곤을
<INPUT TYPE=SUBMIT VALUE='은퇴시킨다'>
<INPUT TYPE=TEXT NAME=check SIZE=10 VALUE="">
(retire와 입력) 
</FORM>
<br>
$TB$TR$TD
·연령 <b>$remsg</b>이상의 드래곤은, 은퇴시킬 수가 있습니다.<br>
·총상금이 <b>$PRentry만</b>이상의 드래곤은, 종·번식 들어갑니다.
$TBE
STR
}


