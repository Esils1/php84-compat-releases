# 우편 2004/01/20 유래

$Q{mode}='new', if ($Q{form} eq "make")&&($Q{ok}); 	# 송신 모드 전환
CoLock() if $Q{mode};

$NOITEM=1;
DataRead();
CheckUserPass();

$image[0]=GetTagImgKao("도우미","help");
$WriteFlag=0;						# 갱신 플래그.

ReadLetterName();
ReadLetter();

RequireFile('inc-letter-edit.cgi') if ($Q{mode});	# 각종 처리

if ($Q{form})
{
RequireFile('inc-letter-form.cgi');
}
else
{
RequireFile('inc-letter.cgi');
}

	if ($WriteFlag)
	{
	CoLock() if !$COLOCKED;
	WriteLetter();
	CoDataCA();
	CoUnLock();
	}
OutSkin();
1;

