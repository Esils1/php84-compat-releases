# 길드 커멘드 처리 2005/01/06 유래

$NOMENU=1;
$Q{bk}=$Q{er}="gd";
my $usetime=3*60*60;

Lock();
DataRead();
CheckUserPass();
OutError('길드에 들어가 있지 않습니다') if !$DT->{guild};
ReadGuild();
ReadGuildData();

my $functionname=$Q{mode};
OutError('bad request') if !defined(&$functionname);
&$functionname;

WriteGuildData();
RenewLog();
DataWrite();
DataCommitOrAbort();
UnLock();
$disp.=$ret;
OutSkin();
1;

sub fund
{
$count=CheckCount($Q{cnt1},$Q{cnt2},0,$DT->{money});

OutError('기부금액을 지정해 주세요') if !$count;
OutError('최악이어도 '.GetMoneyString(100000).'는 자점에 남깁시다') if ($DT->{money} - $count) < 100000;

$ret="길드 「".$GUILD{$DT->{guild}}->[$GUILDIDX_name]."」에 ".GetMoneyString($count)."기부";
EditGuildMoney($DT->{guild} ,$count);
$DT->{money}-=$count;
$DT->{paytoday}+=$count;
PushLog(0,0,$DT->{shopname}."가 길드 「".$GUILD{$DT->{guild}}->[$GUILDIDX_name]."」에 ".GetMoneyString($count)." 기부했습니다.");
}

sub break
{
OutError('직함이 붙지 않으면 실행할 수 없습니다') if (!$DT->{user}{_so_e});
OutError('시간이 충분하지 않습니다') if GetStockTime($DT->{time})<$usetime;
UseTime($usetime);
my $tg=$Q{tg};
OutError('표적을 지정해 주세요') if !$tg;
OutError('그 길드에 대해서 공격은 할 수 없습니다') if ($GUILD_DATA{$tg}->{money} <= $GUILD_DATA{$DT->{guild}}->{money});

$ret="길드 「".$GUILD{$DT->{guild}}->[$GUILDIDX_name]."」의 브레이크.";
my $attack=0;
my $powerdeg=$GUILD_DATA{$DT->{guild}}->{atk} - $GUILD_DATA{$tg}->{def} + int(rand(50));
$attack= int( ($GUILD_DATA{$tg}->{money} + 1000000) * $powerdeg / 1600) if ($powerdeg > 0);

$GUILD_DATA{$DT->{guild}}->{atk}=int($GUILD_DATA{$DT->{guild}}->{atk} *9 /10);
$GUILD_DATA{$tg}->{def}=int($GUILD_DATA{$tg}->{def} *4 /5);

$ret.="그러나 「".$GUILD{$tg}->[$GUILDIDX_name]."」(은)는 방어!",PushLog(2,0,$ret),return if (!$attack);

$ret.="「".$GUILD{$tg}->[$GUILDIDX_name]."」(으)로부터 ".GetMoneyString($attack)."(을)를 탈취!";
EditGuildMoney($tg ,-$attack);
PushLog(2,0,$ret);

$income=int($attack / 10) + 1000;
$attack=int($attack * 9 / 10);
EditGuildMoney($DT->{guild} ,$attack);
$DT->{money}+=$income;
$DT->{saletoday}+=$income;
PushLog(0,$DT->{id},"브레이크 성공의 보상금으로 해서 ".GetMoneyString($income)." 입수.");
$ret.="<br>브레이크 성공의 보상금으로 해서 ".GetMoneyString($income)." 입수.";
if ($GUILD_DATA{$tg}->{money} < 0)
	{
	unlink($COMMON_DIR."/".$tg.".pl") ;
	$GUILD_DATA{$DT->{guild}}->{def}=int($GUILD_DATA{$DT->{guild}}->{def} * 3 / 2);
	$GUILD_DATA{$DT->{guild}}->{def}=1000 if ($GUILD_DATA{$DT->{guild}}->{def} > 1000);
	}
}

sub force
{
my $checkok;
$ckeckok=1 if ($GUILD_DETAIL{$DT->{guild}}->{leadt} eq $MYDIR && $GUILD_DETAIL{$DT->{guild}}->{leader} == $DT->{id});
$ckeckok=1 if ($GUILD_DETAIL{$DT->{guild}}->{$MYDIR} == $DT->{id});
OutError('bad request') if (!$ckeckok);
OutError('직함이 붙지 않으면 실행할 수 없습니다') if (!$DT->{user}{_so_e});
OutError('시간이 충분하지 않습니다') if GetStockTime($DT->{time})<$usetime;
UseTime($usetime);
OutError('증강의 필요가 없습니다') if ($GUILD_DATA{$DT->{guild}}->{atk} > 990);
my $guild=$GUILD_DATA{$DT->{guild}};
my $cnt=int($guild->{money} / 4);
$guild->{money} -= $cnt;
$guild->{atk} += int($cnt/25000);
$guild->{atk} = 1000 if $guild->{atk} > 1000;
$ret = "길드 「".$GUILD{$DT->{guild}}->[$GUILDIDX_name]."」(이)가 군비를 증강했습니다.";
PushLog(0,0,$ret);
}


