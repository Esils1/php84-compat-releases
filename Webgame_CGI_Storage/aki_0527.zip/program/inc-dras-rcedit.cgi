# 드래곤 레이스 목장 편집 표시 2005/03/30 유래

ReadRanch();
$disp.="<BIG>●드래곤 레이스：목장</BIG><br><br>";

my $functionname=$Q{code};
OutError("bad request") if !defined(&$functionname);
&$functionname;

WriteRanch();
RenewDraLog();
CoDataCA();
1;


sub new
{
OutError("bad request") if ($MYRC!=-1);
OutError('자금의 여유가 없습니다.') if ($DT->{money} < $RCest);

	# 이름의 정당성을 체크

	if(!$Q{name})
	{
		OutError('이름을 입력해 주세요.');
	}
	if($Q{name} =~ /([,:;\t\r\n<>&])/ || CheckNGName($Q{name}) )
	{
		OutError('이름에 사용할 수 없는 캐릭터가 포함되어 있습니다.');
	}
	OutError('이름이 너무 깁니다.') if length($Q{name})>20;
	OutError('이름이 너무 짧습니다.') if length($Q{name})<6;

	@RC=reverse(@RC);
	$RCcount++;
	my $i=$RCcount;
	$RC[$i]->{no}=($i > 0) ? ($RC[$i-1]->{no} + 1) : 1 ;
	$RC[$i]->{birth}=$NOW_TIME;
	$RC[$i]->{name}=$Q{name};
	$RC[$i]->{town}=$MYDIR;
	$RC[$i]->{owner}=$DT->{id};
	@RC=reverse(@RC);

WritePayLog($MYDIR,$DT->{id},-$RCest);
PushDraLog(0,"새로운 목장 「".$Q{name}."」(이)가 설립되었습니다.");
$disp.="새로운 목장 「<b>".$Q{name}."</b>」(을)를 설립했습니다.";
}


