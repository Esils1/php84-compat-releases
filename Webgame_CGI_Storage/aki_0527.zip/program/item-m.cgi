# 아이템 사용 화면 2005/01/06 유래

$NOMENU=1;
DataRead();
CheckUserPass();

$itemno=$Q{item};
$no=$Q{no};
CheckItemNo($itemno);
$itemcode=GetPath($ITEM_DIR,"use",$ITEM[$itemno]->{code});
OutError('사용할 수 없습니다') if $itemcode eq '' || !(-e $itemcode);

$ITEM=$ITEM[$itemno];
@item::DT=@DT;
$item::DT=$DT;
@item::ITEM=@ITEM;
$item::ITEM=$ITEM;
RequireFile('inc-item.cgi');
require $itemcode;

$USE=GetUseItem($no);
OutError('사용할 수 없습니다') if !$USE || !$USE->{useok};
$item::USE=$USE;

RequireFile('inc-html-ownerinfo.cgi');

my $MAX_COUNT=9999999999;
my $scale=$USE->{scale} ? $USE->{scale} : '회';
my $action=$USE->{action} ? $USE->{action} : '사용하는';
my $scaleone="";
$scaleone="(1$scale)" if $USE->{arg}!~/nocount/;

$USE->{time}=GetItemUseTime($USE);

$disp.="<BIG>●".$USE->{name}."</BIG><br><br>";
$disp.=$TB;
$disp.=$TR.$TDB."비고".$TD.$USE->{info}.$TRE;
$disp.=$TR.$TDB."비용 $scaleone$TD".GetMoneyString($USE->{money}).$TRE if $USE->{money};
my $exp=$DT->{exp}->{$USE->{itemno}};

if($USE->{time} || $exp)
{
	$disp.=$TR.$TDB."시간 $scaleone".$TD.GetTime2HMS($USE->{time});
	$disp.="(숙련도".int($exp/10)."%)" if $exp;
	$disp.=$TRE;
	
	$disp.=$TR.$TDB.'필요 숙련도'.$TD.int($USE->{needexp}/10).'%'.$TRE if $USE->{needexp};
}

$disp.=$TR.$TDB.'필요 직업'.$TD.$JOBTYPE{$USE->{needjob}}.$TRE if $USE->{needjob};
$disp.=$TR.$TDB.'필요 점수'.$TD.$USE->{needpoint}.$TRE if $USE->{needpoint};
$disp.=$TR.$TDB.'필요 인기'.$TD.int($USE->{needpop}/100).'%'.$TRE if $USE->{needpop};

my $count_min=$MAX_COUNT;
if(defined($USE->{use}[0]))
{
	$disp.=$TR.$TDB."사용 $scaleone".$TD;
	$disp.=$TB;
	foreach my $USEITEM (@{$USE->{use}})
	{
		my $no=$USEITEM->{no};
		my $count=int($DT->{item}[$no-1]/$USEITEM->{count});
		
		$disp.=$TR;
		$disp.=$TD.$ITEM[$no]->{name};
		$disp.=$TD.$USEITEM->{count}.$TD."잔".$DT->{item}[$no-1];
		if($USEITEM->{proba}==0)
		{
			$disp.=$TD."소비하지 않는다";
		}
		elsif($USEITEM->{proba}==1000)
		{
			$disp.=$TD."소비한다";
			$count_min=$count if $count<$count_min;
		}
		else
		{
			$disp.=$TD."소비 확률".($USEITEM->{proba}/10)."\%";
			$count_min=$count if $count<$count_min;
		}
		$disp.=$TRE;
	}
	$disp.=$TBE;
}
my $money=$MAX_COUNT;
my $time=$MAX_COUNT;
my %msg;
my $count_max;
if($USE->{arg}!~/nocount/)
{
	if($USE->{money}!=0){$money=int($DT->{money}/$USE->{money});}
	if($USE->{time}){$time=int(GetStockTime($DT->{time}) /$USE->{time});}
	$msg{1}=1; $msg{2}=2; $msg{3}=3; $msg{5}=5;
	$msg{10}=10; $msg{20}=20; $msg{50}=50; $msg{100}=100;
	$msg{1000}=1000; $msg{10000}=10000;
	if($money<=$time){$count_max=$money;}else{$count_max=$time;}
	if($count_min<=$count_max){$count_max=$count_min;}
	$msg{$money}="$money(자금 최대)";
	$msg{$time}="$time(시간 최대)";
	$msg{$count_min}="$count_min(재료 최대)";

	$disp.=$TR;
	$disp.=$TDB."최대 회수".$TD.$count_max;
	$disp.=$TRE;
}
$disp.=$TRE.$TBE."<br>";

if( ($USE->{money}) && ($DT->{money} < $USE->{money}) )
	{$nonuse=1; $disp.="<B>자금이 충분하지 않습니다</B><BR>";}

if($DT->{time}+$USE->{time}>$NOW_TIME)
	{$nonuse=1; $disp.="<B>시간이 충분하지 않습니다</B><BR>";}

if($exp<$USE->{needexp})
	{$nonuse=1; $disp.="<B>숙련도가 충분하지 않습니다</B><BR>";}

if($USE->{needjob} && ($DT->{job} ne $USE->{needjob}))
	{$nonuse=1; $disp.="<B>필요한 직업에 종사하고 있지 않습니다</B><BR>";}

if($USE->{needpoint} && ($DT->{point} < $USE->{needpoint}))
	{$nonuse=1; $disp.="<B>점수가 충분하지 않습니다</B><BR>";}

if($USE->{needpop} && ($DT->{rank} < $USE->{needpop}))
	{$nonuse=1; $disp.="<B>인기가 충분하지 않습니다</B><BR>";}

if($USE->{needevent} && !$DTevent{$USE->{needevent}})
	{$nonuse=1; $disp.="<B>이 커멘드에는 특정의 이벤트의 발생이 필요합니다</B><BR>";}

$disp.=&{"item::".$USE->{functioninfo}}() if $USE->{functioninfo}; # @@use funci

my $select_target="";
my $select_count="";
my $input_message="";
my $select_userdata="";
if(!$nonuse)
{
	if($USE->{arg}=~ /target/)
	{
		$select_target="<SELECT NAME=tg>";
		foreach (@DT)
		{
			$select_target.="<OPTION VALUE='$_->{id}'>$_->{shopname}";
		}
		$select_target.="</SELECT>에 대해서";
	}
	
	if($USE->{arg}!~ /nocount/)
	{
		$select_count.="<SELECT NAME=cnt1>";
		my $oldcnt=0;
		foreach $cnt (sort { $a <=> $b } (1,2,3,5,10,20,50,100,1000,10000,$time,$money,$count_min))
		{
			if($count_max>=$cnt && $cnt!=$oldcnt)
				{$select_count.="<OPTION VALUE=\"$cnt\">$msg{$cnt}";}
			else
				{last;}
			$oldcnt=$cnt;
		}
		$select_count.="</SELECT>$scale ";
		$select_count.="또는<INPUT TYPE=TEXT NAME=cnt2 SIZE=5>$scale";
	}
	else
	{
		$select_count.="<INPUT TYPE=HIDDEN NAME=cnt2 VALUE=\"1\">";
	}
	
	if($USE->{arg}=~ /message(\d*)/)
	{
		my $limit=$1||80;
		my $header=$USE->{argmessage}||'댓글';
		$header.='('.$limit.'글자 이내)';
		$input_message="$header<BR><INPUT TYPE=TEXT NAME=msg VALUE=\"\" MAXLENGTH=\"$limit\"><BR>";
	}
	
	if($USE->{arg}=~ /select/ && $USE->{argselect})
	{
		my @fld=split(/;/,$USE->{argselect});
		unshift(@fld,'선택') if @fld%2==0;
		my $header=shift @fld;
		$select_userdata.=qq|$header <select name="select">|;
		while(@fld)
		{
			my $val=shift @fld;
			my $cap=shift @fld;
			$select_userdata.=qq|<option value="$val">$cap|;
		}
		$select_userdata.=qq|</select> |;
	}
	
	$disp.=<<STR;
<FORM ACTION="action.cgi" $METHOD>
<INPUT TYPE=HIDDEN NAME=key VALUE="item-s">
$USERPASSFORM
<INPUT TYPE=HIDDEN NAME=bk VALUE="$Q{bk}">
<INPUT TYPE=HIDDEN NAME=item VALUE="$itemno">
<INPUT TYPE=HIDDEN NAME=no VALUE="$no">
$input_message
$select_target
$select_userdata
$select_count
<INPUT TYPE=SUBMIT VALUE='$action'>
</FORM>
STR
}

OutSkin();
1;

