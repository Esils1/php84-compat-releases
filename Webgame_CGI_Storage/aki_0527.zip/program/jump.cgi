# URL 점프 2004/01/20 유래

$NOITEM=1;
$NOMENU=1;
JumpGuild($Q{guild}) if $Q{guild} ne '';
JumpTown($Q{town}) if $Q{town} ne '';
OutSkin();
exit;
1;

sub JumpGuild
{
	my($code)=@_;
	my $guild=ReadGuild($code);
	return if !$guild || $guild->{url} eq '';
	$disp="";
	$disp.="길드 ".GetTagImgGuild($code).$guild->{name}."<br>";
	$disp.="<br>".$guild->{comment}."<br><br>";
	$disp.=GetTagA($guild->{name}."에 자동적으로 점프 합니다.하지 않는 경우는 이 링크를 눌러주세요.",$guild->{url})."<br>";
	print "Refresh: 1; url=$guild->{url}\n";
}

sub JumpTown
{
	my($code)=@_;
	my $town=ReadTown($code);
	return if !$town || $town->{url} eq '';
	print "Refresh: 1; url=$town->{url}\n";
	$disp="";
	$disp.=GetTagA($town->{name}."에 자동적으로 점프 합니다.하지 않는 경우는 이 링크를 눌러 주세요.");
}
