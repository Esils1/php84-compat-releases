# 이벤트 함수 2005/01/06 유래

package event; #변경 불가

######################################################################
# ★이벤트용 하청 함수：로그 글
# usage:  WriteLog(중요도,대상 가게 ID,메시지)
#           중요도     0==일반 1==중요 2==정보
#           대상 가게 ID 0==가게 전체포앞가게 ID==프라이빗
#           메시지 로그 메시지
# return: 0 고정
######################################################################
sub WriteLog
{
	main::PushLog($_[0],$_[1],$_[2]);
	return 0;
}

######################################################################
# ★디버그용 로그 글
# usage: DebugLog(메시지)
#           메시지 로그 메시지
# return: 0 고정
######################################################################
sub DebugLog
{
	my($msg)=@_;
	main::WriteErrorLog($msg,$main::LOG_DEBUG_FILE) if $main::DEBUG_LOG_ENABLE;
	return 0;
}

######################################################################
# ★시장 재고 조사：이벤트 발동 계기 판단용
# usage:  stock_le(아이템 번호,개수)
# return: 1 시장의 아이템의 재고가 개수 이하의 경우
#         0 상기 이외
######################################################################
sub stock_le
{
	my($itemno,$count)=@_;
	return 1 if $main::DTwholestore[$itemno-1]<=$count;
	return 0;
}

######################################################################
# ★시장 재고 조사：이벤트 발동 계기 판단용
# usage:  stock_ge(아이템 번호,개수)
# return: 1 시장의 아이템의 재고가 개수 이상의 경우
#         0 상기 이외
######################################################################
sub stock_ge
{
	my($itemno,$count)=@_;
	return 1 if $main::DTwholestore[$itemno-1]>=$count;
	return 0;
}

sub GetUserData
{
	return &main::GetUserData;
}

sub GetMoneyString
{
	return &main::GetMoneyString;
}

require "$main::ITEM_DIR/funcevent.cgi" if $main::DEFINE_FUNCEVENT;
1;

