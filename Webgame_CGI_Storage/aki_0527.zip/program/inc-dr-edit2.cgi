# 드래곤 레이스 레이스 전개 2005/03/30 유래

if ($NOW_TIME > $DRTIME[2]) { $rcode=1; } else { $rcode=0; }

ReadRace($rcode);

@MYRACE=@{$RACE[$rcode]};
@R=@{$MYRACE[$RDS[1]]};
undef $RACELOG;
if (!$RDS[0])
	{
	Entry();
	}
	else
	{
	my $functionname="Race".$RDS[0];
	&$functionname;
	}
WriteRaceLog($rcode,$RACELOG) if $RACELOG;
WriteRace($rcode);
WriteDrLast();
RenewDraLog();
CoDataCA();
CoUnLock();
1;


sub WriteRaceLog
{
	my($f,$message)=@_;
	$f||=0;
	my $fn=GetPath($COMMON_DIR,"dra-rlog$f");
	open(OUT,">>$fn") or return;
	print OUT $message;
	close(OUT);
}

sub Entry
{
	# 출주 슬라임 확정 처리
	ReadDragon();
	ReadJock();

	if (scalar @RD < 3)
		{
		# 출주수가 3개에 못 미친 경우는 전부 낙선 소금 흐름
		foreach(0..$#RD)
			{
			my $id=$RD[$_]->{dr};
			$DR[$id2dra{$id}]->{race}=1 if (defined $id2dra{$id});

			$id=$RD[$_]->{jock};
			$JK[$id2jk{$id}]->{race}=1 if (defined $id2jk{$id});

			undef $RD[$_];

			}
		PushDraLog($rcode+1,$R[0]."(은)는 출주용부족을 이유로 개최가 보류되었습니다.");
		$DRTIME[$rcode+1]+=86400*2;
		$RDS[1]++;
		$RDS[1]=0 if ($RDS[1] > $#MYRACE);
		$RDS[2]=int(rand(2));
		}
		else
		{
		PushDraLog($rcode+1,$R[0]."의 출주 등록이 마감되었습니다.");
		# 출주수가 정원을 넘는 경우는 추첨
		if (scalar @RD > $R[9])
			{
			foreach(0..$#RD) { $RD[$_]->{rnd}=($RD[$_]->{prize} * 10000) + int(rand(10000));}
			if ($rcode)
				{
				@RD=sort{$b->{rnd}<=>$a->{rnd}}@RD;	#중상경주는 큰 순서
				}
				else
				{
				@RD=sort{$a->{rnd}<=>$b->{rnd}}@RD;	#신룡레이스는 작은 순서
				}
			foreach($R[9]..$#RD)
				{
				#낙선
				my $id=$RD[$_]->{dr};
				$DR[$id2dra{$id}]->{race}=1 if (defined $id2dra{$id});

				$id=$RD[$_]->{jock};
				$JK[$id2jk{$id}]->{race}=1 if (defined $id2jk{$id});
				undef $RD[$_];
				}
			PushDraLog($rcode+1,"출주룡이 다수이기 때문에, 추첨을 했습니다.");
			}

		#출주 처리
		my $num=$R[9] - 1;
		foreach(0..$num)
			{
			next if !$RD[$_]->{name};
			$RD[$_]->{no}=$_ + 1;	#범위 차례 거절해 수선
			my $id=$RD[$_]->{dr};
			$DR[$id2dra{$id}]->{race}=3 if (defined $id2dra{$id});

			$id=$RD[$_]->{jock};
			$JK[$id2jk{$id}]->{race}=3 if (defined $id2jk{$id});
			}

		$DRTIME[$rcode+1]+=3600*2;
		$RDS[0]++;
		}
	my $fn=GetPath($COMMON_DIR,"dra-rlog$rcode");
	unlink $fn if -e $fn;				#과거의 실황 로그 소거
	WriteDragon();
	WriteJock();
}

sub Race1
{
	# 인기의 결정
	foreach(0..$#RD) { $RD[$_]->{sumsp}=$RD[$_]->{prize}*100 + int(rand(100)); }
	@RD=sort{$b->{sumsp}<=>$a->{sumsp}}@RD;

	foreach(0..$#RD)
		{
		$RD[$_]->{pop}=$_ + 1;		#인기를 출력
		$RD[$_]->{time}+=int($R[5] * 1000 / 4 / $RD[$_]->{sp1});
		}
	@RD=sort{$a->{time}<=>$b->{time}}@RD;

	$RACELOG.="그러면 <b>".$R[0]."</b>의 출주입니다<br>\n";
	$RACELOG.="건장한 용들이 집결<br>\n" if $R[1]==5;
	$RACELOG.="영관을 손에 넣는 것은 과연 어느 용이 될 것인가<br>\n" if $R[1]==0;
	$RACELOG.="이 코스의 종반은 비탈이 있습니다. 제 1의 변수가 있을지도 모릅니다<br>\n" if $R[4];
	$RACELOG.="이제 시작입니다<br>\n";

	if ($RD[0]->{strate}< 2)
		{
		$RACELOG.="선두에 있는 용은 <b>".GetTagImgDra($RD[0]->{fm},$RD[0]->{color}).$RD[0]->{name}."</b><br>\n";
		$RACELOG.="대부분이 예상한 일입니까<br>\n";
		}
		else
		{
		$RACELOG.="아니 <b>".GetTagImgDra($RD[0]->{fm},$RD[0]->{color}).$RD[0]->{name}."</b>가 갑자기 선두로 섰습니다<br>\n";
		$RACELOG.="이것은 계략인가<br>\n";
		}

	#임의의 1마리를 소개
	my $i=int(rand($#RD))+1;
	$RACELOG.="현재 ".($i + 1)."번째로 달리고 있는 것은 ".$RD[$i]->{no}."화 <b>".GetTagImgDra($RD[$i]->{fm},$RD[$i]->{color}).$RD[$i]->{name}."</b><br>\n";
	if ($RD[$i]->{pop} < 4)
		{
		$RACELOG.=$RD[$i]->{pop}."지켜 보는 사람의 기대를 접수. 이 정도의 사람이 승리를 원합니다<br>\n";
		}
		else
		{
		$RACELOG.="인기는 ".$RD[$i]->{pop}."등입니다만 과연 이 용은 복병이 될까요<br>\n";
		}

	$DRTIME[$rcode+1]+=3600*8;
	$RDS[0]++;
}

sub Race2
{
	my $no=$RD[0]->{no};	#이전의 1위를 앞에 두고 둔다
	foreach(0..$#RD)
		{
		$RD[$_]->{time}+=int($R[5] * 1000 / 4 / $RD[$_]->{sp2});
		}
	@RD=sort{$a->{time}<=>$b->{time}}@RD;

	$RACELOG.="최초의 코너를 돌았습니다<br>\n";
	if ($no == $RD[0]->{no})
		{
		$RACELOG.="현재 선두는 변함없이 <b>".GetTagImgDra($RD[0]->{fm},$RD[0]->{color}).$RD[0]->{name}."</b><br>\n";
		$RACELOG.="이 기세는 끝까지 계속될 것인가<br>\n";
		}
		else
		{
		$RACELOG.="여기서 선두가 바뀌었습니다 ";
		$RACELOG.="선두는 <b>".GetTagImgDra($RD[0]->{fm},$RD[0]->{color}).$RD[0]->{name}."</b><br>\n";
		}

	#레이스 전개 판정미실장
	$RACELOG.="중간 ".($R[5] / 2)."km의 통과 타임은 ".GetRaceTime($RD[0]->{time})."<br>\n";
	$RACELOG.="거의 평상대로라고 할 수 있겠지요. 전개에 그다지 영향은 없을 것 같습니다<br>\n";

	#경마에서 도중까지 부진하다가 의 1마리를 소개
	my $i=int(rand($#RD))+1;
	foreach(1..$#RD)
		{
		$i=$_,last if ($RD[$_]->{strate}==2 || $RD[$_]->{strate}==3);
		}
	$RACELOG.="<b>".GetTagImgDra($RD[$i]->{fm},$RD[$i]->{color}).$RD[$i]->{name}."</b> 좋은 위치에요 여기부터 선두를 노리는 것인가<br>\n";

	$DRTIME[$rcode+1]+=3600*8;
	$RDS[0]++;
}

sub Race3
{
	my $no=$RD[0]->{no};
	foreach(0..$#RD)
		{
		$RD[$_]->{time}+=int($R[5] * 1000 / 4 / $RD[$_]->{sp3});
		}
	@RD=sort{$a->{time}<=>$b->{time}}@RD;

	$RACELOG.="후속룡이 차이를 좁혀갑니다<br>\n";
	if ($no == $RD[0]->{no})
		{
		$RACELOG.="자 과연...</b> ";
		$RACELOG.="선두는 변함없이 <b>".GetTagImgDra($RD[0]->{fm},$RD[0]->{color}).$RD[0]->{name}."</b><br>\n";
		$RACELOG.="이대로 잘 도주할 수 있을 것인가";
		}
		else
		{
		$RACELOG.="<b>".GetTagImgDra($RD[0]->{fm},$RD[0]->{color}).$RD[0]->{name}."</b>가 추월했다!<br>\n";
		$RACELOG.="자 과연...</b> ";
		}
	$RACELOG.="뒤를 쫓는 것은 <b>".GetTagImgDra($RD[1]->{fm},$RD[1]->{color}).$RD[1]->{name}."</b><br>\n";

	#경마에서 도중까지 부진하다가 의 1마리를 소개
	my $i=int(rand($#RD))+1;
	foreach(2..$#RD)
		{
		$i=$_,last if ($RD[$_]->{strate}==2 || $RD[$_]->{strate}==3);
		}
	$RACELOG.="<b>".GetTagImgDra($RD[$i]->{fm},$RD[$i]->{color}).$RD[$i]->{name}."</b> 좋은 페이스지만...<br>\n";

	$DRTIME[$rcode+1]+=3600*6;
	$RDS[0]++;
}

sub Race4
{
	my $no=$RD[0]->{no};
	foreach(0..$#RD)
		{
		$RD[$_]->{time}+=int($R[5] * 1000 / 4 / $RD[$_]->{sp4});
		}
	@RD=sort{$a->{time}<=>$b->{time}}@RD;

	my $name1=GetTagImgDra($RD[0]->{fm},$RD[0]->{color})."<b>".$RD[0]->{name}."</b>";
	my $name2=GetTagImgDra($RD[1]->{fm},$RD[1]->{color})."<b>".$RD[1]->{name}."</b>";

	$RACELOG.="마지막 코너를 돌아 직선에 들어갑니다<br>\n";
	if ($no == $RD[0]->{no})
			{
			# 상위 변함없이
			$RACELOG.="자 과연 ";
			$RACELOG.="$name2가 추입을 시도합니다<br>\n";
			$RACELOG.="$name1가 도주합니다 이대로 잘 도주할 것인가<br>\n";

			if ($RD[1]->{time} - $RD[0]->{time} < 15)
				{
				$RACELOG.="$name2가 달려듭니다. 그러나 $name1도 스퍼트를 올립니다!<br>\n";
				$RACELOG.="$name1다! 잘 도주했습니다! 이긴 용은 $name1!<br>\n";
				}
				else
				{
				$RACELOG.="$name1 차이를 벌였습니다!<br>\n";
				$RACELOG.="$name1! 이 용은 강합니다! 이긴 용은 $name1!<br>\n";
				}
			}
		elsif ($no == $RD[1]->{no})
			{
			# 2착
			$RACELOG.="자 과연 ";
			$RACELOG.="$name1 가 추입을 시도합니다<br>\n";
			$RACELOG.="$name2 가 도주합니다 이대로 잘 도주할 것인가<br>\n";
			if ($RD[1]->{time} - $RD[0]->{time} < 15)
				{
				$RACELOG.="$name1가 달려듭니다! $name2도 스퍼트를 올립니다!<br>\n";
				$RACELOG.="$name1가 추월했습니다!<br>\n";
				$RACELOG.="$name2과 한 걸음차도 되지 않아서! 이긴 것은 $name1!<br>\n";
				}
				else
				{
				$RACELOG.="$name1가 추월했습니다!<br>\n";
				$RACELOG.="$name1 더욱 차이를 벌입니다!<br>\n";
				$RACELOG.="$name1! 이 용은 강합니다! 이긴 것은 $name1!<br>\n";
				}
			}
		else
			{
			# 상위 완전 교대
			$RACELOG.="자 과연 ";
			$RACELOG.="$name2 가 추월했습니다!<br>\n";
			$RACELOG.="게다가 <b>$name1</b> 가 뒤로 밀렸습니다!<br>\n";
			if ($RD[1]->{time} - $RD[0]->{time} < 15)
				{
				$RACELOG.="$name1가 달려듭니다! $name2 도 스퍼트를 올립니다!<br>\n";
				$RACELOG.="$name1가 추월했습니다!<br>\n";
				$RACELOG.="$name2과 한 걸음차도 되지 않아서! 이긴 것은 $name1!<br>\n";
				}
				else
				{
				$RACELOG.="$name1가 단번에 추월했습니다!<br>\n";
				$RACELOG.="$name1 게다가 차이를 벌입니다!<br>\n";
				$RACELOG.="$name1! 이 용은 강합니다! 이긴 것은 $name1!<br>\n";
				}
			}

	ReadDragon();
	ReadJock();
	ReadRanch();
	ReadStable();

	# 탑
	PushDraLog($rcode+1,$R[0]."에서 「".$RD[0]->{name}."」(이)가 이겼습니다.");

	my $id=$RD[0]->{dr};
	if (defined $id2dra{$id})
		{
		my $i=$id2dra{$id};
		$DR[$i]->{gr}+=80;
		$DR[$i]->{prize}+=$R[6];

		WritePayLog($DR[$i]->{town},$DR[$i]->{owner},$R[6]*10000);

		if ($R[1] > 2) { $DR[$i]->{sdwin}++;}
		elsif ($R[1]==2) { $DR[$i]->{g3win}++;}
		elsif ($R[1]==1) { $DR[$i]->{g2win}++;}
		else { $DR[$i]->{g1win}++;}
		}

	# 상위 기수
	my $id=$RD[0]->{jock};
	if (defined $id2jk{$id})
		{
		my $i=$id2jk{$id};
		$JK[$i]->{sp}=int(rand(scalar @JKSP)) if !$JK[$i]->{sp};

		#취한 작전에 응해 능력 상승
		if ($RD[0]->{str} > 1)
			{
			$JK[$i]->{back}+=15;
			$JK[$i]->{back}=100 if ($JK[$i]->{back} > 100);
			}
			else
			{
			$JK[$i]->{ahead}+=15;
			$JK[$i]->{ahead}=100 if ($JK[$i]->{ahead} > 100);
			}
		if ($R[1] > 2) { $JK[$i]->{sdwin}++;}
		elsif ($R[1]==2) { $JK[$i]->{g3win}++;}
		elsif ($R[1]==1) { $JK[$i]->{g2win}++;}
		else { $JK[$i]->{g1win}++;}
		}

	# 상위 목장
	my $id=$RD[0]->{ranch};
	if (defined $id2rc{$id})
		{
		my $i=$id2rc{$id};
		$RC[$i]->{prize}+=$R[6];
		if ($R[1] > 2) { $RC[$i]->{sdwin}++;}
		elsif ($R[1]==2) { $RC[$i]->{g3win}++;}
		elsif ($R[1]==1) { $RC[$i]->{g2win}++;}
		else { $RC[$i]->{g1win}++;}
		}

	# 상위 마굿간
	my $id=$RD[0]->{stable};
	if (defined $id2st{$id})
		{
		my $i=$id2st{$id};
		$ST[$i]->{tr}+=int(rand(20));
		$ST[$i]->{tr}=100 if ($ST[$i]->{tr} > 100);
		$ST[$i]->{con}+=int(rand(20));
		$ST[$i]->{con}=100 if ($ST[$i]->{con} > 100);
		$ST[$i]->{wt}+=int(rand(20));
		$ST[$i]->{wt}=100 if ($ST[$i]->{wt} > 100);

		if ($R[1] > 2) { $ST[$i]->{sdwin}++;}
		elsif ($R[1]==2) { $ST[$i]->{g3win}++;}
		elsif ($R[1]==1) { $ST[$i]->{g2win}++;}
		else { $ST[$i]->{g1win}++;}
		}

	# 2벌
	my $id=$RD[1]->{dr};
	if (defined $id2dra{$id})
		{
		my $i=$id2dra{$id};
		$DR[$i]->{gr}+=40;
		$DR[$i]->{prize}+=$R[7];

		WritePayLog($DR[$i]->{town},$DR[$i]->{owner},$R[7]*10000);
		}

	# 2벌 목장
	my $id=$RD[1]->{ranch};
	if (defined $id2rc{$id})
		{
		my $i=$id2rc{$id};
		$RC[$i]->{prize}+=$R[7];
		}

	# 3벌
	my $id=$RD[2]->{dr};
	if (defined $id2dra{$id})
		{
		my $i=$id2dra{$id};
		$DR[$i]->{gr}+=20;
		$DR[$i]->{prize}+=$R[8];

		WritePayLog($DR[$i]->{town},$DR[$i]->{owner},$R[8]*10000);
		}

	# 3벌 목장
	my $id=$RD[2]->{ranch};
	if (defined $id2rc{$id})
		{
		my $i=$id2rc{$id};
		$RC[$i]->{prize}+=$R[8];
		}

	$RACELOG.="<br>";
	foreach(0..$#RD)
		{
		$RACELOG.=($_ + 1)."착 ".GetRaceTime($RD[$_]->{time});
		$RACELOG.=" ".$STRATE[ $RD[$_]->{str} ]." ";
		$RACELOG.=GetTagImgDra($RD[$_]->{fm},$RD[$_]->{color}).$RD[$_]->{name};
		$RACELOG.=" <small>(".$RD[$_]->{lose}.")</small>" if $_;
		$RACELOG.="<br>";
		my $id=$RD[$_]->{dr};
		if (defined $id2dra{$id})
			{
			my $i=$id2dra{$id};
			$DR[$i]->{race}=0;
			$DR[$i]->{con}-=40;
			$DR[$i]->{con}=0 if ($DR[$i]->{con} < 0);

			$DR[$i]->{wt}-=4;
			$DR[$i]->{wt}=38 if ($DR[$i]->{wt} < 38);
			}
		$id=$RD[$_]->{jock};
		$JK[$id2jk{$id}]->{race}=0 if (defined $id2jk{$id});

		undef $RD[$_];
		}
	WriteDragon();
	WriteJock();
	WriteRanch();
	WriteStable();

	$DRTIME[$rcode+1]=$NOW_TIME + 86400 -(($NOW_TIME + $TZ_JST - $DRTIMESET[$rcode+1] * 3600) % 86400);
	$RDS[0]=0;
	$RDS[1]++;
	$RDS[1]=0 if ($RDS[1] > $#MYRACE);
	$RDS[2]=int(rand(2));
}


