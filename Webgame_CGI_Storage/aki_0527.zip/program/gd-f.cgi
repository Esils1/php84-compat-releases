# 길드 편집 폼 2004/01/20 유래

$NOITEM=1;
DataRead();
CheckUserPass(1);
RequireFile('inc-gd.cgi');

if ($DT->{guild})
{
GuildEditMenu();
}
elsif ($DT->{dignity} < $DIG_FORGUILD)
{
$disp.=$TB.$TR.$TD.$image[0].$TD."<SPAN>길드 접수</SPAN>：이쪽은 길드 결성 신고소입니다.<br>";
$disp.="길드를 결성하려면 , $DIG_FORGUILD 이상의 작위포인트가 필요합니다.".$TRE.$TBE."<br>";
$disp.="조건을 채우지 않았습니다";
}
else
{
GuildBuildMenu();
}
OutSkin();
1;


sub GuildEditMenu
{
my $leaderid=$GUILD_DETAIL{$DT->{guild}}->{leader};
OutError('길드를 변경할 수 있는 것은 단장만입니다') if (defined($id2idx{$leaderid}) && $leaderid != $DT->{id});
ReadLetterName();
$code=$DT->{guild};
$GUILD_DETAIL{$code}->{url}="http://" if !$GUILD_DETAIL{$code}->{url};
$disp.=$TB.$TR.$TD.$image[0].$TD."<SPAN>길드 접수</SPAN>：이쪽은".GetTagImgGuild($code);
$disp.="<BIG>".$GUILD{$code}->[$GUILDIDX_name]."</BIG> 집무실입니다.<br>";
$disp.="단장님, 향후의 길드를 어떻게 하실 생각입니까?".$TRE.$TBE."<br>";
my $i=GuildCommonForm();

$disp.=<<"HTML";
<FORM ACTION="action.cgi" enctype="multipart/form-data" $METHOD>
<INPUT TYPE=hidden NAME=key VALUE="gd-b">
$USERPASSFORM
<INPUT TYPE=hidden NAME=mode VALUE="edit">
$TB$TR$TDB<b>길드 코드</b>
<td colspan=2><b>$code</b><INPUT TYPE=HIDDEN NAME=code VALUE="$code">$TRE
$TR$TDB<b>길드 화상</b><br>(32*16pt)
<td colspan=2>gif 형식 화상만(지정하지 않으면 현상인 채)<br><input type=file name=upfile size=36>$TRE
$TR$TDB<b>길드 홈 페이지</b><br>(60 캐릭터 이내)
<td colspan=2>일반용 홈 페이지<br><INPUT TYPE=TEXT NAME=url SIZE=56 VALUE="$GUILD_DETAIL{$code}->{url}">$TRE
$i
$TR$TDB<b>참모 임명</b><br>( 각 거리 1명까지)
HTML

my $r=int(scalar(@OtherDir) / 2 + 0.5) ;$r||=1;
foreach(0..$#OtherDir)
	{
	my $pg=$OtherDir[$_];
	$disp.=( ($_ % $r) ? "<br>" : $TD);
	$disp.="$Tname{$pg} <SELECT NAME=$pg><OPTION VALUE=\"\">－－－－";
	foreach my $i(0..$Ncount{$pg})
		{
		$disp.="<OPTION VALUE=\"$LID{$pg}[$i]\"".($GUILD_DETAIL{$code}->{$pg}==$LID{$pg}[$i] ? ' SELECTED' : '').">$LNAME{$pg}[$i]";
		}
	$disp.="</SELECT>\n";
	}

$disp.=<<"HTML";
$TRE$TBE
<br><INPUT TYPE=SUBMIT VALUE="이상의 내용으로 결정">
<br>(반영되려면  몇분 걸립니다)
</FORM>
HTML
}


sub GuildBuildMenu
{
$code="";
$disp.=$TB.$TR.$TD.$image[0].$TD."<SPAN>길드 접수</SPAN>：이쪽은 길드 결성 신고소입니다.<br>";
$disp.="새로운 단장님, 어떠한 길드를 결성 하시는 생각입니까?".$TRE.$TBE."<br>";
my $i=GuildCommonForm();

$disp.=<<"HTML";
<FORM ACTION="action.cgi" enctype="multipart/form-data" $METHOD>
<INPUT TYPE=hidden NAME=key VALUE="gd-b">
$USERPASSFORM
<INPUT TYPE=hidden NAME=mode VALUE="make">
$TB$TR$TDB<b>길드 코드</b><br>(10 캐릭터 이내)
<td colspan=2>반각영수<b>소문자만</b><br><INPUT TYPE=TEXT NAME=code SIZE=10 VALUE="">$TRE
$TR$TDB<b>길드 화상</b><br>(32*16pt)
<td colspan=2>gif 형식 화상만<br><input type=file name=upfile size=36>$TRE
$i
$TBE
<br><INPUT TYPE=SUBMIT VALUE="이상의 내용으로 결정">
<br>(반영되려면 몇분 걸립니다)
</FORM>
HTML
}

sub GuildCommonForm
{
my $i.=<<"HTML";
$TR$TDB<b>길드 정식명칭</b><br>(30 캐릭터 이내)
<td colspan=2>상세표\시 시에 사용되는 이름<br><INPUT TYPE=TEXT NAME=name SIZE=24 VALUE="$GUILD_DETAIL{$code}->{name}">$TRE
$TR$TDB<b>길드 통칭</b><br>(12 캐릭터 이내)
<td colspan=2>통상 사용되는 이름<br><INPUT TYPE=TEXT NAME=shortname SIZE=12 VALUE="$GUILD_DETAIL{$code}->{shortname}">$TRE
$TR$TDB<b>길드간 할증율</b><br>(반각 숫자만)
<td colspan=2>10배의 값을 지정(30%로 하려면  300으로 기입.10~500)<br><INPUT TYPE=TEXT NAME=dealrate SIZE=6 VALUE="$GUILD_DETAIL{$code}->{dealrate}">$TRE
$TR$TDB<b>길드간 회비율</b><br>(반각 숫자만)
<td colspan=2>10배의 값을 지정(3%로 하려면  30으로 기입.10~500)<br><INPUT TYPE=TEXT NAME=feerate SIZE=6 VALUE="$GUILD_DETAIL{$code}->{feerate}">$TRE
$TR$TDB<b>멤버 호칭</b><br>(6 캐릭터 이내)
<td colspan=2>「회원」 「동지」 등<br><INPUT TYPE=TEXT NAME=member SIZE=6 VALUE="$GUILD_DETAIL{$code}->{member}">$TRE
$TR$TDB<b>결정 대사</b><br>(30 캐릭터 이내)
<td colspan=2>일람표에 나타나는 간판<br><INPUT TYPE=TEXT NAME=comment SIZE=24 VALUE="$GUILD_DETAIL{$code}->{comment}">$TRE
$TR$TDB<b>활동 소개</b><br>(120 캐릭터 이내)
<td colspan=2>길드의 활동 목적이나 내용<br><INPUT TYPE=TEXT NAME=appeal SIZE=60 VALUE="$GUILD_DETAIL{$code}->{appeal}">$TRE
$TR$TDB<b>입단 조건</b><br>(120 캐릭터 이내)
<td colspan=2>「들어가고 싶은 분은 단장에게 편지를」 등<br><INPUT TYPE=TEXT NAME=needed SIZE=60 VALUE="$GUILD_DETAIL{$code}->{needed}">$TRE
HTML
return $i;
}


