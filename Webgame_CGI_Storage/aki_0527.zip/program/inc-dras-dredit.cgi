# 드라곤레이스드라곤멘테 2005/03/30 유래

ReadDragon();
$disp.="<BIG>●드래곤 레이스：목장</BIG><br><br>";

my $functionname=$Q{code};
OutError("bad request") if !defined(&$functionname);
&$functionname;

WriteDragon();
CoDataCA();
1;

sub new
{
	#목장 체크
	ReadRanch();
	OutError("bad request") if ($MYRC==-1);

	OutError('자금의 여유가 없습니다.') if ($DT->{money} < $DRbuy);
	OutError('더 이상 드래곤을 소유할 수 없습니다.') if (scalar @MYDR >= $MYDRmax);

	# 이름의 정당성을 체크
	if(!$Q{name})
	{
		OutError('이름을 입력해 주세요.');
	}
	if($Q{name} =~ /([,:;\t\r\n<>&])/ || CheckNGName($Q{name}) )
	{
		OutError('이름에 사용할 수 없는 문자가 포함되어 있습니다.');
	}

	#한 번 EUC에 변환
	OutError('이름이 너무 깁니다.') if length($Q{name})>20;
	OutError('이름이 너무 짧습니다.') if length($Q{name})<6;

	@DR=reverse(@DR);
	$DRcount++;
	my $i=$DRcount;
	$DR[$i]->{no}=($i > 0) ? ($DR[$i-1]->{no} + 1) : 1 ;
	$DR[$i]->{birth}=$NOW_TIME - 5 * 86400;
	$DR[$i]->{fm}=$Q{fm};
	$DR[$i]->{color}=int(rand(scalar @DRCOLOR));
	$DR[$i]->{name}=$Q{name};
	$DR[$i]->{town}=$MYDIR;
	$DR[$i]->{owner}=$DT->{id};
	$DR[$i]->{apt}=1400 + ($Q{dist} * 600) + int(rand(3))*100;
	$DR[$i]->{sp}=10 + int(rand(20));
	$DR[$i]->{sr}=5 + int(rand(20));
	$DR[$i]->{ag}=5 + int(rand(20));
	$DR[$i]->{pw}=10 + int(rand(20));
	$DR[$i]->{hl}=10 + int(rand(40));
	$DR[$i]->{fl}=10 + int(rand(20));
	$DR[$i]->{con}=70 + int(rand(20));
	$DR[$i]->{wt}=49 + int(rand(3));

	# 특징이 없다든가 원 있을 것 같아서 특징 부여
	if ($DR[$i]->{sr} > $DR[$i]->{ag})
		{
		$DR[$i]->{sr}+=15;
		}
		else
		{
		$DR[$i]->{ag}+=15;
		}
	@DR=reverse(@DR);

WritePayLog($MYDIR,$DT->{id},-$DRbuy);
$disp.="새로운 드래곤 「<b>".$Q{name}."</b>」(을)를 구입했습니다.";
}

sub ent
{
my $cnt=$id2dra{$Q{dr}};
OutError("bad request") if ($DR[$cnt]->{town} ne $MYDIR || $DR[$cnt]->{owner} != $DT->{id});

ReadStable();
OutError("bad request") if (!scalar @ST);
OutError("bad request") if (!defined $id2st{$Q{ent}});
$DR[$cnt]->{stable}=$Q{ent};
my $i=$id2st{$Q{ent}};
$disp.="드래곤을 마굿간 「".$ST[$i]->{name}."」에 예탁했습니다.";
}

sub torace
{
	#드래곤 체크
	my $cnt=$id2dra{$Q{dr}};
	OutError("bad request") if ($DR[$cnt]->{town} ne $MYDIR || $DR[$cnt]->{owner} != $DT->{id});
	OutError("bad request") if ($DR[$cnt]->{race} > 1);

	#목장 체크
	ReadRanch();
	OutError("bad request") if ($MYRC==-1);

	#레이스 체크
	my $rcode=$Q{rcode};
	ReadRace($rcode);
	OutError("현재".$RACETERM[$rcode]."(은)는 출주 등록을 받지 않습니다") if ($RDS[0]);

	my @MYRACE=@{$RACE[$rcode]};
	my @R=@{$MYRACE[$RDS[1]]};
	undef @RACE;
	undef @MYRACE;	#불필요한 배열은 해방

	OutError("다음번의 ".$R[0]."(은)는 상금미획득의 드래곤만 출주할 수 있다") if ($R[1]==5 && $DR[$cnt]->{prize} > 0);

	#소속 마굿간을 조사한다
	ReadStable();
	my $stname="";
	if (scalar @ST)
	{
	foreach(0..$STcount)
		{
		$stname=$ST[$_]->{name},last if ($ST[$_]->{no}==$DR[$cnt]->{stable});
		}
	}

	my $lose="실력 부족";
	my ($sp,$sr,$ag,$pw)=($DR[$cnt]->{sp},$DR[$cnt]->{sr},$DR[$cnt]->{ag},$DR[$cnt]->{pw});

	# 파워 배분
	my $pwp=$R[3] * 4 + $RDS[2] * 3 + 1;
	$lose="파워 부족" if ($pwp > 1 && $sp < $pw);
	$sp=int(($sp * (10 - $pwp) + $pw * $pwp) / 10);

	# 컨디션에 의한 영향 최대로 스피드 5할
	$sp-=int($sp*(100 - $DR[$cnt]->{con})/200);
	$lose="컨디션 부진" if ($DR[$cnt]->{con} < 60);

	# 체중과 핸디캡에 의한 영향 10톤으로 스피드 5할
	my $wt=$DR[$cnt]->{wt} - 50;
	$wt=-$wt if ($wt < 0);
	$wt+=int($DR[$cnt]->{prize} / $R[2]) if $R[2];
	$sp-=int($sp*$wt/20);
	$lose="체중조절 실패" if ($wt > 2);

	my $sp1=$sp2=$sp3=$sp4=$sp * 6 + 1000;		#기준 속도 1000 - 1600

	# 종반에 비탈이 있는 경우
	$sp4=$sp * 4 + $pw * 2 + 950 if $R[4];

	if (!$Q{str})
		{
		#도주의 경우
		$sp1+=$sr * 6 - $ag * 4 + 40;
		$sp2+=$sr * 2 + 50;
		$sp1=$sp2 if ($sp1 < $sp2);
		}
	elsif ($Q{str}==1)
		{
		#선행의 경우
		$sp1+=$sr * 2 + 50;
		$sp2+=$sr * 4 + 100;
		}
	elsif ($Q{str}==2)
		{
		#선입의 경우
		$sp3+=$ag * 4 + 100;
		$sp4+=$ag * 2 + 50;
		}
	else
		{
		#추입의 경우
		$sp3+=$ag * 2 + 50;
		$sp4+=$ag * 6 - $sr * 4 + 40;
		$sp4=$sp3 if ($sp4 < $sp3);
		} 

	# 거리 적성에 의한 영향
	my $m=GetRaceApt($DR[$cnt]->{apt},$DR[$cnt]->{fl},$R[5]);
	if ($m > 0)
		{
		$lose="거리가 너무 짧아";
		$m=300 if $m > 300;
		$sp1-=$m * 2;
		$sp2-=$m;
		}
	elsif ($m < 0)
		{
		$lose="거리가 너무 길어";
		$m=-300 if $m < -300;
		$sp1+=$m * 2;
		$sp2+=$m;
		}

	#기수를 조사한다
	my $jkname="";
	if ($Q{jock})
	{
	ReadJock();
	if (scalar @JK)
		{
		foreach(0..$JKcount)
			{
			next if ($JK[$_]->{no}!=$Q{jock});
			OutError("그 기수는 이미 다른 용에 승마하고 있습니다") if ($JK[$_]->{race} > 1);
			$jkname=$JK[$_]->{name};
			$JK[$_]->{race}=2;

			#기수에 의한 보정
			$sp1+=int($sp1 * $JK[$_]->{ahead} / 20 / 100);
			$sp2+=int($sp2 * $JK[$_]->{ahead} / 20 / 100);
			$sp3+=int($sp3 * $JK[$_]->{back} / 20 / 100);
			$sp4+=int($sp4 * $JK[$_]->{back} / 20 / 100);

			WriteJock();
			last;
			}
		}
	}

	my $i=$RDcount;
	$RDcount++;
	$RD[$i]->{no}=($i > 0) ? ($RD[$i-1]->{no} + 1) : 1 ;
	$RD[$i]->{dr}=$Q{dr};

	$RD[$i]->{birth}=$DR[$cnt]->{birth};
	$RD[$i]->{fm}=$DR[$cnt]->{fm};
	$RD[$i]->{color}=$DR[$cnt]->{color};
	$RD[$i]->{name}=$DR[$cnt]->{name};
	$RD[$i]->{ranch}=$RC[$MYRC]->{no};
	$RD[$i]->{rcname}=$RC[$MYRC]->{name};
	$RD[$i]->{stable}=$DR[$cnt]->{stable};
	$RD[$i]->{stname}=$stname;
	$RD[$i]->{jock}=$Q{jock};
	$RD[$i]->{jkname}=$jkname;
	$RD[$i]->{prize}=$DR[$cnt]->{prize};
	$RD[$i]->{strate}=GetRaceStrate($DR[$cnt]->{sr},$DR[$cnt]->{ag});
	$RD[$i]->{sp1}=$sp1;
	$RD[$i]->{sp2}=$sp2;
	$RD[$i]->{sp3}=$sp3;
	$RD[$i]->{sp4}=$sp4;
	$RD[$i]->{str}=$Q{str};
	$lose="작전 미스" if ($Q{str} != $RD[$i]->{strate});
	$RD[$i]->{lose}=$lose;

	WriteRace($rcode);

	$DR[$cnt]->{race}=2;
$disp.="드래곤 「".$DR[$cnt]->{name}."」(을)를 ".$R[0]."에 출주 등록했습니다.";
}


