# 장원종 매입 처리 2005/03/30 유래

$NOITEM=1;
$NOMENU=1;
Lock();
DataRead();
CheckUserPass();
OutError("영주가 없기 때문에 장원제도가 정지합니다") if !defined($id2idx{$STATE->{leader}});
RequireFile('inc-manor.cgi');

	# 장원 설정을 취득
	my $id=$id2idx{$STATE->{leader}};
	ReadDTSub($DT[$id],"lord");
	my $MANORLORD=$DT[$id]->{_lord};

	ReadDTSub($DT,"seed");

foreach my $i(0..$#MANOR)
	{
	my @MYMANOR=@{$MANOR[$i]};
	my $stock=$DT->{_seed}->{"ripe$i"};
	next if !$stock;
	my $price=$MANORLORD->{"cost$i"};

	delete $DT->{_seed}->{"ripe$i"};
	$DT->{money}+=$stock*$price;
	$DT->{saletoday}+=$stock*$price;

	$MANORLORD->{"stock$i"}+=$stock;
	$STATE->{money}-=$stock*$price;
	$STATE->{out}+=$stock*$price;
	$STATE->{develop}+=$stock;
	$STATE->{develop}=10000 if $STATE->{develop} > 10000;
	OutError("거리의 자금이 부족하기 때문에 매입할 수 없습니다") if ($STATE->{money} < 0);

	my $ret=$MYMANOR[2]."(을)를 ".$stock.'개@'.GetMoneyString($price)."(합계".GetMoneyString($price*$stock).")로 장원에 매각";
	$disp.=$ret."<br>";
	PushLog(0,$DT->{id},$ret);
	}

	WriteDTSub($DT[$id],"lord");
	WriteDTSub($DT,"seed");
RenewLog();
DataWrite();
DataCommitOrAbort();
UnLock();
OutSkin();
1;

