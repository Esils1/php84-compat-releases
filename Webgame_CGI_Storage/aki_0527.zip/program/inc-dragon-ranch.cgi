# 드래곤 레이스 목장 메뉴 표시 2005/03/30 유래

ReadRanch();
$disp.="<BIG>●드래곤 레이스：목장</BIG><br><br>";

if ($MYRC==-1)
{
$disp.="$TB$TR$TD".GetTagImgKao("드래곤 노사","slime1").$TD;
$disp.="<SPAN>드래곤 노사</SPAN>：자신의 목장을 가지고 있지 않구만.<br>";
$disp.="목장을 가지면, 자신의 드래곤을 기를 수가 있다네.".$TRE.$TBE;
my $estmsg=GetMoneyString($RCest);
$disp.=<<STR;
<br>
<FORM ACTION="action.cgi" $METHOD>
<INPUT TYPE=HIDDEN NAME=key VALUE="slime-s">
<INPUT TYPE=HIDDEN NAME=bk VALUE="slime">
$USERPASSFORM
<INPUT TYPE=HIDDEN NAME=mode VALUE="rcedit">
<INPUT TYPE=HIDDEN NAME=code VALUE="new">
<BIG>●목장 설립</BIG>： <INPUT TYPE=TEXT NAME=name SIZE=20> 이라고 이름 붙여서 
<INPUT TYPE=SUBMIT VALUE='설립'>
</FORM>
<br>
$TB$TR$TD
·목장을 설립하려면 ,자금 <b>$estmsg</b>가 걸립니다.<br>
·드래곤의 육성에는 별도로 자금이 들므로,여유가 있는지 생각해 주세요.<br>
$TBE
STR
}
else
{
$disp.="$TB$TR$TDB 명칭$TDB 창립$TDB 평균 상금$TDB총상금$TDB 성적 $TRE";
$disp.=$TR;
$disp.=$TD.$RC[$MYRC]->{name};
$disp.=$TD.GetTime2found($NOW_TIME-$RC[$MYRC]->{birth});
$disp.=$TD.($RC[$MYRC]->{aprize} + 0)."만";
$disp.=$TD.($RC[$MYRC]->{prize} + 0)."만";
$disp.=$TD.($RC[$MYRC]->{g1win} + 0)." - ".($RC[$MYRC]->{g2win} + 0)." - ".($RC[$MYRC]->{g3win} + 0)." - ".($RC[$MYRC]->{sdwin} + 0);
$disp.=$TRE.$TBE;
$disp.="<br><BIG>●소유 경쟁룡</BIG><br><br>";
ReadDragon();
if (!scalar @MYDR)
	{
	$disp.="소유한 경쟁룡은 없습니다<br><br>";
	}
	else
	{
$disp.="$TB$TR$TDB 명칭$TDB 연령$TDB 성별$TDB 스피드$TDB 승부$TDB순발$TDB 파워$TDB 컨디션$TDB 체중$TDB 거리 적성$TDB총상금$TDB 성적 $TRE";
	foreach (@MYDR)
		{
$disp.=$TR;
$disp.=$TD."<a href=\"action.cgi?key=slime&mode=detail&dr=$DR[$_]->{no}&$USERPASSURL\">"
	.GetTagImgDra($DR[$_]->{fm},$DR[$_]->{color}).$DR[$_]->{name}."</a> ";
$disp.=$TD.GetTime2found($NOW_TIME-$DR[$_]->{birth});
$disp.=$TD.$FM[$DR[$_]->{fm}];
$disp.=$TD.$VALUE[int($DR[$_]->{sp} /100*6)];
$disp.=$TD.$VALUE[int($DR[$_]->{sr} /100*6)];
$disp.=$TD.$VALUE[int($DR[$_]->{ag} /100*6)];
$disp.=$TD.$VALUE[int($DR[$_]->{pw} /100*6)];
$disp.=$TD.$EVALUE[int($DR[$_]->{con} /100*4)];
$disp.=$TD.$DR[$_]->{wt};
$disp.=$TD.GetRaceApt($DR[$_]->{apt},$DR[$_]->{fl});
$disp.=$TD.($DR[$_]->{prize} + 0)."만";
$disp.=$TD.($DR[$_]->{g1win} + 0)." - ".($DR[$_]->{g2win} + 0)." - ".($DR[$_]->{g3win} + 0)." - ".($DR[$_]->{sdwin} + 0);
$disp.=$TRE;
		}
$disp.=$TBE."<br>";
	}

ReadParent();

if (scalar @MYPR)
	{
	$disp.="<BIG>●소유 번식".$FM[1]."룡</BIG><br><br>";
$disp.="$TB$TR$TDB 명칭$TDB 연령$TDB 유전$TDB 스피드$TDB 승부$TDB순발$TDB 파워$TDB 건강$TDB 유연$TDB 거리 적성$TDB 현역 상금$TDB 현역 성적 $TRE";
	foreach (@MYPR)
		{
$disp.=$TR;
$disp.=$TD."<a href=\"action.cgi?key=slime&mode=pr&dr=$PR[$_]->{no}&$USERPASSURL\">"
	.GetTagImgDra($PR[$_]->{fm},$PR[$_]->{color},1).$PR[$_]->{name}."</a> ";
$disp.=$TD.GetTime2found($NOW_TIME-$PR[$_]->{birth});
$disp.=$TD.$VALUE[int($PR[$_]->{hr} /100*6)];
$disp.=$TD.$VALUE[int($PR[$_]->{sp} /100*6)];
$disp.=$TD.$VALUE[int($PR[$_]->{sr} /100*6)];
$disp.=$TD.$VALUE[int($PR[$_]->{ag} /100*6)];
$disp.=$TD.$VALUE[int($PR[$_]->{pw} /100*6)];
$disp.=$TD.$VALUE[int($PR[$_]->{hl} /100*6)];
$disp.=$TD.$VALUE[int($PR[$_]->{fl} /100*6)];
$disp.=$TD.GetRaceApt($PR[$_]->{apt},$PR[$_]->{fl});
$disp.=$TD.($PR[$_]->{prize} + 0)."만";
$disp.=$TD.($PR[$_]->{g1win} + 0)." - ".($PR[$_]->{g2win} + 0)." - ".($PR[$_]->{g3win} + 0)." - ".($PR[$_]->{sdwin} + 0);
$disp.=$TRE;
		}
$disp.=$TBE."<br>";
	}



if (scalar @MYDR < $MYDRmax)
	{
my @dist=('단거리룡','중거리룡','장거리룡');
my $formdist="";
foreach(0..$#dist) {$formdist.=qq|<OPTION VALUE="$_">$dist[$_]|; }
my $buymsg=GetMoneyString($DRbuy);
$disp.=<<STR;
<FORM ACTION="action.cgi" $METHOD>
<INPUT TYPE=HIDDEN NAME=key VALUE="slime-s">
<INPUT TYPE=HIDDEN NAME=bk VALUE="slime">
$USERPASSFORM
<INPUT TYPE=HIDDEN NAME=mode VALUE="dredit">
<INPUT TYPE=HIDDEN NAME=code VALUE="new">
<BIG>●드래곤 구입</BIG>： <SELECT NAME=fm SIZE=1>
<OPTION VALUE="0">$FM[0]<OPTION VALUE="1">$FM[1]
</SELECT> 의 <SELECT NAME=dist SIZE=1>
$formdist
</SELECT> (을)를 
<INPUT TYPE=TEXT NAME=name SIZE=20> (이)라고 이름 붙여 
<INPUT TYPE=SUBMIT VALUE='구입'>
</FORM>
<br>
$TB$TR$TD
·경쟁룡은, <b>$MYDRmax</b>마리까지 가질 수가 있습니다.<br>
·구입하려면, 자금 <b>$buymsg</b>가 듭니다.<br>
·이름은, <b>한글 10자</b>이내입니다.
$TBE
STR
	}
}
1;




