# 드래곤 레이스 기수 편집 2005/03/30 유래

ReadJock();
$disp.="<BIG>●드래곤 레이스：기수</BIG><br><br>";

my $functionname=$Q{code};
OutError("bad request") if !defined(&$functionname);
&$functionname;

WriteJock();
RenewDraLog();
CoDataCA();
1;


sub new
{
OutError("bad request") if ($MYJK!=-1);
OutError("bad request") if (scalar @JK >= $JKmax);
OutError('자금의 여유가 없습니다.') if ($DT->{money} < $JKest);

	# 이름의 정당성을 체크

	if(!$Q{name})
	{
		OutError('이름을 입력해 주세요.');
	}
	if($Q{name} =~ /([,:;\t\r\n<>&])/ || CheckNGName($Q{name}) )
	{
		OutError('이름에 사용할 수 없는 문자가 포함되어 있습니다.');
	}
	OutError('이름이 너무 깁니다.') if length($Q{name})>20;
	OutError('이름이 너무 짧습니다.') if length($Q{name})<6;

	@JK=reverse(@JK);
	$JKcount++;
	my $i=$JKcount;
	$JK[$i]->{no}=($i > 0) ? ($JK[$i-1]->{no} + 1) : 1 ;
	$JK[$i]->{birth}=$NOW_TIME;
	$JK[$i]->{name}=$Q{name};
	$JK[$i]->{town}=$MYDIR;
	$JK[$i]->{owner}=$DT->{id};
	$JK[$i]->{ahead}=int(rand(15));
	$JK[$i]->{back}=int(rand(15));

	# 특징 부여
	if ($JK[$i]->{ahead} > $JK[$i]->{back})
		{
		$JK[$i]->{ahead}+=15;
		}
		else
		{
		$JK[$i]->{back}+=15;
		}
	@JK=reverse(@JK);

WritePayLog($MYDIR,$DT->{id},-$JKest);
PushDraLog(0,"새로운 기수 「".$Q{name}."」(이)가 데뷔했습니다.");
$disp.="새로운 기수 「<b>".$Q{name}."</b>」(을)를 고용했습니다.";
}


