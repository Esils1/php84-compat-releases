# 드래곤 레이스 은거 드래곤 상세 표시 2005/03/30 유래

$disp.="<BIG>●드래곤 레이스：목장</BIG><br><br>";

ReadParent();
my $cnt=$id2pr{$Q{dr}};
OutError("bad request") if ($MYDIR ne $PR[$cnt]->{town});
OutError("bad request") if ($PR[$cnt]->{owner}!=$DT->{id});
OutError("bad request") if (!$PR[$cnt]->{fm});

$forment="";
foreach(0..$PRcount)
	{
	next if $PR[$_]->{fm};
	$forment.="<OPTION VALUE=\"$PR[$_]->{no}\">$PR[$_]->{name}";
	}

$disp.="$TB$TR$TDB 명칭$TDB 연령$TDB 모색$TDB각질$TDB 거리 적성$TDB 현역 상금$TDB 현역 성적$TDB 전회의 출산 $TRE";
$disp.=$TR;
$disp.=$TD."<b>".GetTagImgDra($PR[$cnt]->{fm},$PR[$cnt]->{color},1).$PR[$cnt]->{name}."</b>";
$disp.=$TD.GetTime2found($NOW_TIME-$PR[$cnt]->{birth});
$disp.=$TD.$DRCOLOR[$PR[$cnt]->{color}];
$disp.=$TD.$STRATE[ GetRaceStrate($PR[$cnt]->{sr},$PR[$cnt]->{ag}) ];
$disp.=$TD.GetRaceApt($PR[$cnt]->{apt},$PR[$cnt]->{fl})."km";
$disp.=$TD.($PR[$cnt]->{prize} + 0)."만";
$disp.=$TD.($PR[$cnt]->{g1win} + 0)." - ".($PR[$cnt]->{g2win} + 0)." - ".($PR[$cnt]->{g3win} + 0)." - ".($PR[$cnt]->{sdwin} + 0);
$disp.=$TD.GetTime2FormatTime($PR[$cnt]->{preg});
$disp.=$TRE;
$disp.=$TBE."<br>";
$disp.="<BIG>●능\력의 상세</BIG><br><br>";
$disp.=$TB;
$disp.=$TR.$TDB."유전력".$TD.GetParentBar($PR[$cnt]->{hr}).$TRE;
$disp.=$TR.$TDB."스피드".$TD.GetParentBar($PR[$cnt]->{sp}).$TRE;
$disp.=$TR.$TDB."승부 근성".$TD.GetParentBar($PR[$cnt]->{sr}).$TRE;
$disp.=$TR.$TDB."순발력".$TD.GetParentBar($PR[$cnt]->{ag}).$TRE;
$disp.=$TR.$TDB."파워".$TD.GetParentBar($PR[$cnt]->{pw}).$TRE;
$disp.=$TR.$TDB."건강".$TD.GetParentBar($PR[$cnt]->{hl}).$TRE;
$disp.=$TR.$TDB."유연성".$TD.GetParentBar($PR[$cnt]->{fl}).$TRE;
$disp.=$TBE."<br>";
if ($forment && ($NOW_TIME-$PR[$cnt]->{preg} > $PRcycle))
	{
	FormPreg();
	}
1;

sub GetParentBar
{
	my($per)=@_;
	
	my $bar="";
	$bar ="<nobr>";
	$bar.=qq|<img src="$IMAGE_URL/b.gif" width="|.($per).qq|" height="12">| if $per;
	$bar.=qq|<img src="$IMAGE_URL/t.gif" width="|.(100-$per).qq|" height="12">| if $per!=100;
	$bar.=" ".($per + 0);
	$bar.="</nobr>";
	return $bar;
}

sub FormPreg
{
my $prmsg=GetTime2found($PRcycle);
$disp.=<<STR;
<FORM ACTION="action.cgi" $METHOD>
<INPUT TYPE=HIDDEN NAME=key VALUE="slime-s">
<INPUT TYPE=HIDDEN NAME=bk VALUE="slime">
$USERPASSFORM
<INPUT TYPE=HIDDEN NAME=mode VALUE="predit">
<INPUT TYPE=HIDDEN NAME=code VALUE="preg">
<INPUT TYPE=HIDDEN NAME=dr VALUE="$Q{dr}">
<BIG>●교배</BIG>： 태어날 드래곤을 
<INPUT TYPE=TEXT NAME=name SIZE=20> (이)라고 이름 붙인다 
<SELECT NAME=pr SIZE=1>
$forment
</SELECT> (을)를 
<INPUT TYPE=SUBMIT VALUE='교배한다'>
</FORM>
<br>
$TB$TR$TD
·경쟁용이 이미 <b>$MYDRmax</b>마리 있을 때는, 교배를 실행할 수 없습니다.<br>
·이름은, <b>우리말 10자</b> 이내입니다.<br>
·종 $FM[0]용의 소유자에게, 교배료를 지불합니다.<br>
·출산하면, <b>$prmsg</b>간은 다음 교배를 할 수 없습니다.
$TBE<br>
STR
}

