# 길드 인사 2004/01/20 유래

Lock(),$Q{mode}=$Q{edit} if $Q{edit};
DataRead();
CheckUserPass();
RequireFile('inc-gd.cgi');

$Q{er}='gd';
my $functionname=$Q{mode};
$functionname||="leave";
OutError("bad request") if !defined(&$functionname);
&$functionname;

OutSkin();
1;


sub leave
{
OutError("bad request") if (!$DT->{guild});
$disp.=<<"HTML";
$TB$TR
$TD$image[0]$TD
<SPAN>길드 접수</SPAN>：길드를 탈퇴합니까?<br>
멤버에게 연락하고 나서 탈퇴하는 것을 추천합니다.
$TRE$TBE<br>
HTML
$disp.="길드전중에 탈퇴할 수 없습니다",return if ($DTevent{guildbattle});
$disp.=<<STR;
	<form action="action.cgi" $METHOD>
	<INPUT TYPE=HIDDEN NAME=key VALUE="user">
	<INPUT TYPE=HIDDEN NAME=mode SIZE=10 VALUE="guild">
	$USERPASSFORM
	<SPAN>길드 탈퇴</SPAN>
	<INPUT TYPE=TEXT NAME=guild SIZE=10 VALUE="">
	(leave라고 입력)
	<INPUT TYPE=SUBMIT VALUE="탈퇴한다"></FORM>
STR
}

sub submit
{
OutError("bad request") if (!$DT->{guild});
my $checkok;
$ckeckok=1 if ($GUILD_DETAIL{$DT->{guild}}->{leadt} eq $MYDIR && $GUILD_DETAIL{$DT->{guild}}->{leader} == $DT->{id});
$ckeckok=1 if ($GUILD_DETAIL{$DT->{guild}}->{$MYDIR} == $DT->{id});
OutError("bad request") if (!$ckeckok);
$disp.=<<"HTML";
$TB$TR
$TD$image[0]$TD
<SPAN>길드 접수</SPAN>：인사실에서는, 멤버에게 직함을 부여, 탈퇴시킬 수 있습니다.<br>
다만, 이 거리의 멤버에게만 한정되기 때문에 주의해 주십시오.
$TRE$TBE<br>
HTML

my $formmember;
foreach(@DT)
{
	next if ($_->{guild} ne $DT->{guild});
	$formmember.="<OPTION VALUE=\"$_->{id}\">$_->{shopname}";
}

$disp.=<<STR;
<form action="action.cgi" $METHOD>
$MYFORM$USERPASSFORM
<BIG>●직함 명명</BIG>：
<INPUT TYPE=HIDDEN NAME=edit VALUE="name">
<SELECT NAME=id SIZE=1>
<OPTION VALUE="">선택
$formmember
</SELECT> 의 직함을
<INPUT TYPE=TEXT NAME=name SIZE=16 VALUE="">
(이)라고 <INPUT TYPE=SUBMIT VALUE="명명한다"> (20 캐릭터 이내)
</FORM>
<hr width=500 noshade size=1>
<form action="action.cgi" $METHOD>
$MYFORM$USERPASSFORM
<SPAN>탈퇴 처분</SPAN>：
<INPUT TYPE=HIDDEN NAME=edit VALUE="fire">
<SELECT NAME=id SIZE=1>
<OPTION VALUE="">선택
$formmember
</SELECT> (을)를 <INPUT TYPE=SUBMIT VALUE="탈퇴시킨다">
<INPUT TYPE=TEXT NAME=guild SIZE=10 VALUE="">
(leave와 입력)
</FORM>
STR
}

sub name
{
OutError("bad request") if (!$DT->{guild});
my $checkok;
$ckeckok=1 if ($GUILD_DETAIL{$DT->{guild}}->{leadt} eq $MYDIR && $GUILD_DETAIL{$DT->{guild}}->{leader} == $DT->{id});
$ckeckok=1 if ($GUILD_DETAIL{$DT->{guild}}->{$MYDIR} == $DT->{id});
OutError("bad request") if (!$ckeckok);

OutError('명명하는 상대를 선택해 주세요.') if !$Q{id};
OutError('존재하지 않는 가게입니다.') if !defined($id2idx{$Q{id}});
my $tg=$id2idx{$Q{id}};
OutError('명명 권한이 없습니다.') if ($DT[$tg]->{guild} ne $DT->{guild});
OutError('직함이 너무 깁니다.') if length($Q{name})>20;

$DT[$tg]->{user}{_so_e}=$Q{name};
my $ret=$DT[$tg]->{shopname}."(을)를 「".$Q{name}."」로 임명했습니다.";
PushLog(2,0,"길드 「".$GUILD{$DT->{guild}}->[$GUILDIDX_name]."」(은)는 ".$ret);
$disp.=$ret;

RenewLog();
DataWrite();
DataCommitOrAbort();
UnLock();
}

sub fire
{
OutError("bad request") if (!$DT->{guild});
my $checkok;
$ckeckok=1 if ($GUILD_DETAIL{$DT->{guild}}->{leadt} eq $MYDIR && $GUILD_DETAIL{$DT->{guild}}->{leader} == $DT->{id});
$ckeckok=1 if ($GUILD_DETAIL{$DT->{guild}}->{$MYDIR} == $DT->{id});
OutError("bad request") if (!$ckeckok);

OutError('탈퇴시키는 멤버를 선택해 주세요.') if !$Q{id};
OutError('존재하지 않는 가게입니다.') if !defined($id2idx{$Q{id}});
my $tg=$id2idx{$Q{id}};
OutError('권한이 없습니다.') if ($DT[$tg]->{guild} ne $DT->{guild});
OutError('단장을 탈퇴시킬 수 없습니다.') if ($GUILD_DETAIL{$DT->{guild}}->{leadt} eq $MYDIR && $GUILD_DETAIL{$DT->{guild}}->{leader} == $Q{id});
OutError('탈퇴시키려면  leave와 입력해 주세요') if $Q{guild} ne 'leave';

delete $DT[$tg]->{user}{_so_e};
$DT[$tg]->{guild}="";
my $name=$GUILD{$DT->{guild}}->[$GUILDIDX_name];
PushLog(1,0,$DT[$tg]->{shopname}."가 길드 「".$name."」(으)로부터 제명되었습니다.");
$disp.=$DT[$tg]->{shopname}."(을)를 탈퇴시켰습니다.";

RenewLog();
DataWrite();
DataCommitOrAbort();
UnLock();
}


