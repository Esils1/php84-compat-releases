# 궁전 2004/01/20 유래

RequireFile("inc-palace.cgi");	#설정 파일 read

$image[0]=GetTagImgKao("임금님","king",'align="left" ');
$image[1]=GetTagImgKao("대신","minister",'align="left" ');

DataRead();
CheckUserPass();

$evt=GetTownData('evt');
$evt=0 if (!$evt);
$level=DignityDefine($DT->{dignity});

$disp.="<BIG>●궁전</BIG><br><br>";

$shopname=$DT->{shopname};
$name=$DT->{name};
$need=$itemno[$evt];

if ($DT->{point} <  $deny_point )
	{
	$disp.='<TABLE cellpadding="26" width="570"><tr>';
	$disp.=qq|<TD style="background-repeat : repeat-x;background-image : url($IMAGE_URL/palace.png);" valign="top"><br><br>|;
	$disp.=$image[1].'이런 궁전에 무슨 용무입니까?<b> '.$shopname.'</b>의<b> '.$name.'</b>씨.<br>';
	$disp.='그러나 국왕 폐하는 '.$name.'씨와는 면회할 수 없다는 분부입니다.';
	$disp.='<br>좀 더 경영의 수완을 높이고 나서 와보시는게 어떻습니까.'.$TRE;
	$disp.=$TBE."<br>";
	}
	else
	{
	KingMain();
	}

OutSkin();
1;


sub KingMain
{
$disp.='<TABLE cellpadding="26" width="570"><tr>';
$disp.=qq|<TD style="background-repeat : repeat-x;background-image : url($IMAGE_URL/palace.png);" valign="top"><br><br>|;
$disp.=$image[0].'잘 참여했다<b> '.$shopname.'</b>의<b> '.$name.$level.'</b>.<br>';
$disp.='활약은 전부터 들어서 잘 알고 있다. 그점에, 너를 믿고 사명을 주마.<br><br>';
$disp.=$msg[$evt].'<br>궁전을 떠나면 <b>'.GetTagImgItemType($need).$ITEM[$need]->{name}.'를 '.$count[$evt].$ITEM[$need]->{scale}.'</b> 구해 와라.';
$disp.='<br>이 사명을 훌륭히 완수할 수 있다면 너에게 '.DignityDefine(1,1).'<b> 작위 경험치</b>를 준다. 해줄 것인가?'.$TRE;
$disp.=$TBE;

$disp.=<<"HTML";
<br><FORM ACTION="action.cgi" $METHOD>
<INPUT TYPE=HIDDEN NAME=key VALUE="palace-s">
$USERPASSFORM
<BIG>●사명 달성</BIG>： 임금님이 의뢰하는 상품을
<INPUT TYPE=SUBMIT VALUE="건네준다"></FORM>
HTML
}
