# 주택 데이터 편집 2003/10/08 유래

if ($Q{mode} eq 'new')
{
ProposeEdit();
DataWrite();
}
else
{
$i=SearchBride($Q{idx});
OutError('지정된 정보는 존재하지 않습니다') if ($i==-1);
($ida,$idb)=($BRIDE[$i]->{ida},$BRIDE[$i]->{idb});
}

$Q{mode}='mplus' if ($Q{mode} eq 'plus')&&($Q{it} == -1);	#머니 모드에 전환
$Q{mode}='mminus' if ($Q{mode} eq 'minus')&&($Q{it} == -1);	#머니 모드에 전환

if ($Q{mode} eq 'agree') {
	OutError($image[3].'결혼에 필요한 자금이 충분하지 않습니다.') if ($DT->{money} < 5000000) ;
	$DT->{money}-=5000000;
	($BRIDE[$i]->{tm},$BRIDE[$i]->{mode},$BRIDE[$i]->{money})=($NOW_TIME,1,10000000);
	PushLog(3,0,$DT->{name}.' ('.$DT->{shopname}.')는 '.$DT[$id2idx{$ida}]->{name}.' ('.$DT[$id2idx{$ida}]->{shopname}.')의 결혼의 신청을 받았습니다.');
	PushLog(1,0,$DT[$id2idx{$ida}]->{name}.' ('.$DT[$id2idx{$ida}]->{shopname}.')와 '.$DT->{name}.' ('.$DT->{shopname}.')가 결혼했습니다.');
	DataWrite();
}
if ($Q{mode} eq 'end') {
	$DT->{money}+=5000000;	#자금을 반환.
	PushLog(3,0,$DT->{name}.' ('.$DT->{shopname}.')는 '.$DT[$id2idx{$idb}]->{name}.' ('.$DT[$id2idx{$idb}]->{shopname}.')에의 결혼의 신청을 취소했습니다.');
	$BRIDE[$i]->{mode}=-1;
	DataWrite();
}
if ($Q{mode} eq 'con') {
	OutError($image[3].'주택 건설에 필요한 자금이 충분하지 않습니다.') if ($BRIDE[$i]->{money} < 15000000) ;
	my $check=0;
	foreach (0..$Scount) {
		$check=1 if ($BRIDE[$_]->{place}==$Q{place});
		}
	OutError($image[3].'이미 주택이 지어지고 있는 것 같습니다.') if ($check || $BRIDE[$i]->{place}) ;
	$BRIDE[$i]->{money}-=15000000;
	($BRIDE[$i]->{place},$BRIDE[$i]->{mode},$BRIDE[$i]->{reform})=($Q{place},3,'a');
	PushLog(2,0,$DT[$id2idx{$ida}]->{name}.'＆'.$DT[$id2idx{$idb}]->{name}.'부부가 주택을 지었습니다.');
}
if ($Q{mode} eq 'more') {
	OutError('증축할 수 없습니다.') if ($BRIDE[$i]->{mode} < 2 || $BRIDE[$i]->{mode} > 7) ;
	OutError('주택 증축에 필요한 자금이 충분하지 않습니다.') if ($BRIDE[$i]->{money} < $BRIDE[$i]->{mode} * 10000000);
	$BRIDE[$i]->{money}-=($BRIDE[$i]->{mode} * 10000000);
	$BRIDE[$i]->{mode}+=2;
	PushLog(2,0,$DT[$id2idx{$ida}]->{name}.'＆'.$DT[$id2idx{$idb}]->{name}.'부부가 주택을 증축했습니다.');
}
if ($Q{mode} eq 'plus') {
	$itemno=$Q{it};
	my $n=SearchBstock($Q{it});
	OutError('보관 스페이스가 없습니다.') if ($n == -1) ;
	my $space=$ITEM[$itemno]->{limit}*$HouseMax - $BRIDE[$i]->{cnt}[$n];
	OutError('보관 스페이스가 없습니다.') if ($space < 1) ;
	$Q{num}=$DT->{item}[$itemno-1] if ($Q{num} > $DT->{item}[$itemno-1]);
	$num=CheckCount($DT->{item}[$itemno-1],int($Q{num}),0,$space);
	OutError('무효인 수치 지정입니다.') if !$num;
	$DT->{item}[$itemno-1]-=$num;
	$BRIDE[$i]->{stock}[$n]=$itemno;
	$BRIDE[$i]->{cnt}[$n]+=$num;
	DataWrite();
}
if ($Q{mode} eq 'minus') {
	my $n=$Q{it};
	my $itemno=$BRIDE[$i]->{stock}[$n];
	my $space=$ITEM[$itemno]->{limit} - $DT->{item}[$itemno-1];
	OutError('창고가 가득해 꺼낼 수 없습니다.') if ($space < 1) ;
	$Q{num}=$BRIDE[$i]->{cnt}[$n] if ($Q{num} > $BRIDE[$i]->{cnt}[$n]);
	$num=CheckCount($BRIDE[$i]->{cnt}[$n],int($Q{num}),0,$space);
	OutError('무효인 수치 지정입니다.') if !$num;
	$DT->{item}[$itemno-1]+=$num;
	$BRIDE[$i]->{cnt}[$n]-=$num;
	$BRIDE[$i]->{stock}[$n]=0 if !($BRIDE[$i]->{cnt}[$n]);
	DataWrite();
}
if ($Q{mode} eq 'mplus') {
	my $space=$BRIDE[$i]->{mode}*20000000 - $BRIDE[$i]->{money};
	OutError('보관 스페이스가 없습니다.') if ($space < 1) ;
	$Q{num}=$DT->{money} if ($Q{num} > $DT->{money});
	$num=CheckCount($DT->{money},int($Q{num}),0,$space);
	OutError('무효인 수치 지정입니다.') if !$num;
	$DT->{money}-=$num;
	$BRIDE[$i]->{money}+=$num;
	DataWrite();
}
if ($Q{mode} eq 'mminus') {
	my $space=$MAX_MONEY - $DT->{money};
	OutError('창고가 가득해 꺼낼 수 없습니다.') if ($space < 1) ;
	$Q{num}=$BRIDE[$i]->{money} if ($Q{num} > $BRIDE[$i]->{money});
	$num=CheckCount($BRIDE[$i]->{money},int($Q{num}),0,$space);
	OutError('무효인 수치 지정입니다.') if !$num;
	$DT->{money}+=$num;
	$BRIDE[$i]->{money}-=$num;
	DataWrite();
}
if ($Q{mode} eq 'divorce') {
	$BRIDE[$i]->{mode}=-1;
	PushLog(1,0,$DT[$id2idx{$ida}]->{name}.' ('.$DT[$id2idx{$ida}]->{shopname}.')와 '.$DT[$id2idx{$idb}]->{name}.' ('.$DT[$id2idx{$idb}]->{shopname}.')가 이혼했습니다.');
}
if ($Q{mode} eq 'dis') {
	$BRIDE[$i]->{mode}=-1;
	PushLog(3,0,$DT->{name}.' ('.$DT->{shopname}.')는 '.$DT[$id2idx{$ida}]->{name}.' ('.$DT[$id2idx{$ida}]->{shopname}.')의 결혼의 신청을 거절했습니다.');
}
WriteBride();
RenewLog();
DataCommitOrAbort();
UnLock();
1;


sub ProposeEdit
{
	my $check=0;
	OutError($image[3].'바람기는 금물이에요.') if ($married) ;
	OutError($image[3].'결혼에 필요한 자금이 충분하지 않습니다.') if ($DT->{money} < 5000000) ;
	my $tg=$Q{tg};
	OutError($image[3].'자신과 결혼할 수 없습니다.') if ($DT->{id} == $tg) ;
	foreach (0..$Scount) {
		$check=1 if ($tg==$BRIDE[$_]->{ida}) || ($tg==$BRIDE[$_]->{idb});
		}
	OutError($image[3].'그 사람을 선택하는 것은 이젠 할 수 없어요.') if ($check) ;
	$DT->{money}-=5000000;
	PushLog(3,0,$DT->{name}.' ('.$DT->{shopname}.')가 '.$DT[$id2idx{$tg}]->{name}.' ('.$DT[$id2idx{$tg}]->{shopname}.')에게 결혼을 신청했습니다.');
	@BRIDE=reverse(@BRIDE);
	$Scount++;
	my $i=$Scount;
	$BRIDE[$i]->{point}=0;
	$BRIDE[$i]->{no}=($i > 0) ? ($BRIDE[$i-1]->{no} + 1) : 1;
	($BRIDE[$i]->{tm},$BRIDE[$i]->{mode},$BRIDE[$i]->{ida},$BRIDE[$i]->{idb},$BRIDE[$i]->{money},$BRIDE[$i]->{place},$BRIDE[$i]->{reform})=($NOW_TIME,0,$DT->{id},$tg,0,0,0);
	$BRIDE[$i]->{stock}=(); $BRIDE[$i]->{stock}[0]=0;
	$BRIDE[$i]->{cnt}=(); $BRIDE[$i]->{cnt}[0]=0;
	@BRIDE=reverse(@BRIDE);
}

sub SearchBstock
{
	my($no)=@_;
	foreach(0..$BRIDE[$i]->{mode}-1)
	{
		return $_ if($no == $BRIDE[$i]->{stock}[$_]);	# 우선 벌써 보관되고 있는 것과 같은가 조사한다
	}
	foreach(0..$BRIDE[$i]->{mode}-1)
	{
		return $_ if !($BRIDE[$i]->{stock}[$_]);	# 다음에 빈 곳이 있을까 조사한다
	}
	return -1;
}

sub WriteBride
{
	my @buf;
	foreach my $i(0..$Scount)
		{
		next if ($BRIDE[$i]->{mode}==-1) || !defined($BRIDE[$i]->{no});
		$BRIDE[$i]->{stbase}=join(":",@{$BRIDE[$i]->{stock}});
		$BRIDE[$i]->{ctbase}=join(":",@{$BRIDE[$i]->{cnt}});
		$buf[$i]=join(",",map{$BRIDE[$i]->{$_}}@BRIDEnamelist)."\n";
		}
	OpenAndCheck(GetPath($TEMP_DIR,"bride"));
	print OUT @buf;
	close(OUT);
}

