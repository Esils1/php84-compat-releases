# BGM 2003/09/25 유래

$NOMENU=1;
$Q{bk}="none";
$USERPASSURL="u=$Q{u}" if $Q{u};

print "Content-type: text/html; charset=UTF-8\n\n";
print <<"EOM";
<html lang="ja">
<head><title>$HTML_TITLE</title>
</head>
<frameset rows="0,*" border="0" frameborder="NO">
<frame name="bgm" src="action.cgi?key=midi&$USERPASSURL" noresize>
<frame name="game" src="action.cgi?key=$Q{mode}&$USERPASSURL">
<noframes>
<body>프레임비대응의 브라우저는 이용하실 수 없습니다</body>
</noframes>
</frameset>
</html>
EOM
exit;
1;
