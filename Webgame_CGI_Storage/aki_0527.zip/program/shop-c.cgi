# 시세 조사 2005/01/06 유래

DataRead();
CheckUserPass(1);

$disp.="<BIG>●상가：시세표시</BIG><br><br>";

# 수요/공급 밸런스 계산
GetMarketStatus();

#점별 추가 버전
my $itemlist="";
$itemlist="<select name=itn>";
foreach($ITEM[0],grep(!$tp || $_->{type}==$tp,sort{$a->{sort} <=> $b->{sort}}values(%marketitemlist)))
{
	$itemlist.="<option value=\"$_->{no}\"".($_->{no}==$itn?' SELECTED':'').">".$_->{name};
}
$itemlist.="</select>";

my $shoplist="";
$shoplist="<select name=ds><option value=\"\">모두";
foreach (@DT)
{
	$shoplist.="<OPTION VALUE=\"$_->{id}\"".($Q{senditem}==$_->{id}?' SELECTED':'').">$_->{shopname}" if $DT->{id}!=$_->{id};
}
	$shoplist.="</select>";

$disp.=<<"HTML";
$TBT$TRT
<td valign="bottom">
<form action="action.cgi" $METHOD>
<input type=hidden name=key value="shop-a">
$USERPASSFORM
<input type=hidden name=tp value=\"$tp\">
$itemlist
<input type=submit value="상품으로 검색"> 
</form>
<td valign="bottom">
<form action="action.cgi" $METHOD>
<input type=hidden name=key value="shop-b">
$USERPASSFORM
$shoplist
<input type=submit value="점명으로 검색"> 
</form>
<td valign="bottom">
<form action="action.cgi" $METHOD>
<input type=hidden name=key value="shop-c">
$USERPASSFORM
<input type=submit value="시세를 조사">
</form>
$TRE$TBE
<br>
HTML

my($page,$pagestart,$pageend,$pagenext,$pageprev,$pagemax)
	=GetPage($Q{pg},$LIST_PAGE_ROWS,scalar(keys(%marketitemlist)));

$disp.=GetPageControl($pageprev,$pagenext,"t=3","",$pagemax,$page);

$disp.=$TB;
$disp.=$TR;
$disp.=$TDB.'상품명';
$disp.=$TDB.'금기<small>/전기</small><br>총매상수';
$disp.=$TDB.'최저가';
$disp.=$TDB.'최고가';
$disp.=$TDB.'판매 시세';
$disp.=$TDB.'표준 가격';
$disp.=$TDB.'수요공급 밸런스';
$disp.=$TRE;
foreach my $ITEM ((sort{$a->{sort} <=> $b->{sort}} values(%marketitemlist))[$pagestart..$pageend])
{
	my $itemno=$ITEM->{no};
	$disp.=$TR;
	$disp.=$TDNW."<A HREF='action.cgi?key=shop-a&$USERPASSURL&itn=".$itemno."'>";
	$disp.=GetTagImgItemType($itemno).$ITEM->{name}."</A> ";
	$disp.=$TDNW.$ITEM->{todaysale}."<small>/".$ITEM->{yesterdaysale}."</small>";
	$disp.=$TDNW.($ITEM->{marketprice} ? GetMoneyString($ITEM->{marketpricelow}) : ($MOBILE?'0':' '));
	$disp.=$TDNW.($ITEM->{marketprice} ? GetMoneyString($ITEM->{marketpricehigh}) : ($MOBILE?'0':' '));
	$disp.=$TDNW.($ITEM->{marketprice} ? GetMoneyString($ITEM->{marketprice}) : ($MOBILE?'0':' '));
	$disp.=$TDNW.GetMoneyString($ITEM->{price});
	$disp.=$TDNW.GetMarketStatusGraph($ITEM->{uppoint});
	#$disp.=$TDNW.$todaystock{$itemno};
	$disp.=$TRE;
}
$disp.=$TBE;
$disp.=GetPageControl($pageprev,$pagenext,"t=3","",$pagemax,$page);

OutSkin();
1;

