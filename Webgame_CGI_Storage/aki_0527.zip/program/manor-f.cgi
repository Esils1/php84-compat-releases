# 장원 관리 2005/03/30 유래

Lock() if $Q{mode};
$image[0]=GetTagImgKao("대신","minister",'align="left" ');
DataRead();
CheckUserPass();
OutError('장원 관리를 실시할 수 있는 것은 영주뿐입니다') if $STATE->{leader}!=$DT->{id};
RequireFile('inc-manor.cgi');

ReadDTSub($DT,"lord");#
my $functionname=$Q{mode};
&$functionname if defined(&$functionname);


# 장원 설정을 취득
my $MANORLORD=$DT->{_lord};

my $shoplist="";
my $taxsum=0;
foreach (@DT) {#
$shoplist.="<OPTION VALUE=\"$_->{id}\">$_->{shopname}";
$taxsum+=$_->{taxtoday};
}

my $now=$DTlasttime+$TZ_JST-$DATE_REVISE_TIME;
my $ii=($now % $ONE_DAY_TIME);
$ii=1 if $ii < 1;
$taxsum=GetMoneyString(int($taxsum * $ONE_DAY_TIME / $ii / 10000) * 10000);
#
$disp.="<BIG>●장원 관리실</BIG><br><br>";
$disp.=$TB.$TR.$TD.$image[0]."<SPAN>대신</SPAN>：재정상태를 조심해 운영하지 않으면 안됩니다.<br>";
$disp.="·판매 재고는, 한 번당 1000개까지.<br>";
$disp.="·종의 판매 가격은, ".GetMoneyString(1000)." ~ ".GetMoneyString(10000).".<br>";
$disp.="·수확물의 매입 가격은, ".GetMoneyString(5000)." ~ ".GetMoneyString(40000).".<br>";
$disp.="·판매 가격을 매입 가격보다 비싸게 하면, 아무도 사용하고 싶어하지 않으므로 주의를.".$TRE.$TBE;

$disp.="<hr width=500 noshade size=1><BIG>●현재의 재정상태</BIG><br><br>";
$disp.="$TB$TDB거리 자금$TDB 세수입 전망$TDB 전기 세수입$TDB 전기 세출 $TRE";
$disp.=$TR.$TD.GetMoneyString($STATE->{money}).$TD.$taxsum;#
$disp.=$TD.GetMoneyString($STATE->{in}).$TD.GetMoneyString($STATE->{out}).$TRE.$TBE;


$disp.=<<"HTML";
<hr width=500 noshade size=1><BIG>●장원 설정</BIG><br><br>
<FORM ACTION="action.cgi" $METHOD>
$MYFORM$USERPASSFORM
<INPUT TYPE=hidden NAME=mode VALUE="inside">
$TB$TR
$TDB종$TDB 판매 재고$TDB 판매 가격$TD$TDB 수확물$TDB 매입 가격$TDB 매입수$TDB 설명 $TRE#
HTML

my $balance=0;
foreach my $i(0..$#MANOR)
	{
	my @MYMANOR=@{$MANOR[$i]};
	$disp.=$TR.$TD.GetTagImgManor($MYMANOR[1]).$MYMANOR[0];
	my $c=$MANORLORD->{"count$i"} + 0;
	$disp.=qq|$TD<INPUT TYPE=TEXT NAME=count$i SIZE=8 VALUE="$c"> 개|;
	my $t=$MANORLORD->{"price$i"} + 0;#
	$balance-=$c*$t;
	$disp.=$TD."@".qq|$term[0]<INPUT TYPE=TEXT NAME=price$i SIZE=8 VALUE="$t">$term[1]|;
	$disp.=$TD."→".$TD.GetTagImgManor($MYMANOR[3]).$MYMANOR[2];
	$t=$MANORLORD->{"cost$i"} + 0;
	$balance+=$c*$t;
	$disp.=$TD."@".qq|$term[0]<INPUT TYPE=TEXT NAME=cost$i SIZE=8 VALUE="$t">$term[1]|;
	$disp.=$TD.($MANORLORD->{"stock$i"} +0)." 개";
	$disp.=$TD."<small>매입수 $MYMANOR[5]개로 ".GetTagImgItemType($MYMANOR[4]).$ITEM[$MYMANOR[4]]->{name}."(을)를 ".$MYMANOR[6].$ITEM[$MYMANOR[4]]->{scale}." 생성</small>".$TRE;
	}
$disp.=$TBE."<br>※상기의 장원 설정에서는, ".GetMoneyString($balance)."의 재정 지출이 전망됩니다.<br><br>";#

$disp.=<<"HTML";
<INPUT TYPE=SUBMIT VALUE="이상의 내용으로 결정">
</FORM>
<hr width=500 noshade size=1>
	<FORM ACTION="action.cgi" $METHOD>
	$MYFORM$USERPASSFORM
	<INPUT TYPE=hidden NAME=mode VALUE="outside">
<BIG>●산물 생성</BIG>： 매입한 수확물로부터 산물을 
<INPUT TYPE=SUBMIT VALUE="생성한다">#
	</FORM>
HTML

OutSkin();
1;


sub inside
{
foreach my $i(0..$#MANOR)
	{
	$DT->{_lord}->{"count$i"}=CheckCount($Q{"count$i"},0,0,1000);
	$DT->{_lord}->{"price$i"}=CheckCount($Q{"price$i"},0,1000,10000);
	$DT->{_lord}->{"cost$i"}=CheckCount($Q{"cost$i"},0,5000,40000);
	}
WriteDTSub($DT,"lord");
DataCommitOrAbort();
UnLock();
}

sub outside
{
my $flag=0;
foreach my $i(0..$#MANOR)
	{
	my @MYMANOR=@{$MANOR[$i]};
	my $num=0;
	$num=int($DT->{_lord}->{"stock$i"} / $MYMANOR[5]) if $MYMANOR[5];
	next if !$num;	#생성 가능수없음

	my $itemno=$MYMANOR[4];
	my $count=CheckCount($num,0,0,$ITEM[$itemno]->{limit} - $DT->{item}[$itemno-1]);
	$product = $count * $MYMANOR[6];
	$disp.=$ITEM[$itemno]->{name}."(은)는 창고에 가득해서 생성을 취소했습니다.<br>" ,next if $count<=0;

	$flag++;
	$DT->{item}[$itemno-1]+=$product;
	$DT->{_lord}->{"stock$i"}-=$count * $MYMANOR[5];
	my $ret=$ITEM[$itemno]->{name}."(을)를 ".$product.$ITEM[$itemno]->{scale}." 생성";
	$disp.=$ret."했습니다.<br>";
	PushLog(0,$DT->{id},"장원에서 ".$ret);
	}

if ($flag)
	{
	WriteDTSub($DT,"lord");
	RenewLog();
	DataWrite();
	DataCommitOrAbort();
	}
	else
	{
	$disp.='생성 가능한 것이 없었습니다.';
	}
UnLock();
OutSkin();
exit;
}
