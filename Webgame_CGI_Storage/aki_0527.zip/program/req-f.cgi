# 의뢰 폼 2005/03/30 유래

DataRead();
CheckUserPass();
RequireFile('inc-req.cgi');
RequireFile('inc-html-ownerinfo.cgi');

$disp.="<BIG>●의뢰소</BIG><br><br>";

ReqSet();
my $limit=GetTime2HMS($REQUEST_LIMIT);
$disp.=<<STR;
$TB$TR$TD
$AucImg
새로운 의뢰서를 쓰는구나? 그렇다면 주의 사항을 잘 읽어 줘.<br>
·의뢰는 동시에 <b>$REQUEST_CAPACITY개</b>밖에 할 수가 없습니다.<br>
·의뢰를 달성되면 <SPAN>받으러 와주세요</SPAN>.<br>
·유효기간 <b> $limit</b>이내에 잡기에 오지 않는다고 의뢰는 파기됩니다.<br>
·판매/매입에서는 가격의 <b>$DTTaxrate%</b>의 세금이 의뢰자에게 걸립니다.
$TRE$TBE
<hr width=500 noshade size=1>
<FORM ACTION="action.cgi" $METHOD>
<INPUT TYPE=HIDDEN NAME=key VALUE="req-s">
$USERPASSFORM
<INPUT TYPE=HIDDEN NAME=mode VALUE="new">
<INPUT TYPE=HIDDEN NAME=id VALUE="$DT->{id}">
<BIG>●교환 타입</BIG>：의뢰품 <SELECT NAME=prn SIZE=1>
$formlist
</SELECT> (을)를 수량 <INPUT TYPE=TEXT NAME=pr SIZE=7> 가지고 와준 분에게는<br>
답례 <SELECT NAME=it SIZE=1>
$formitem
</SELECT> (을)를 수량 <INPUT TYPE=TEXT NAME=num SIZE=7> 드립니다.
<INPUT TYPE=SUBMIT VALUE='작성'>
</FORM>
<hr width=500 noshade size=1>
<FORM ACTION="action.cgi" $METHOD>
<INPUT TYPE=HIDDEN NAME=key VALUE="req-s">
$USERPASSFORM
<INPUT TYPE=HIDDEN NAME=mode VALUE="new">
<INPUT TYPE=HIDDEN NAME=id VALUE="$DT->{id}">
<BIG>●판매 타입</BIG>：판매품 <SELECT NAME=it SIZE=1>
$formitem
</SELECT> (을)를 수량 <INPUT TYPE=TEXT NAME=num SIZE=7> 팔므로<br>
가격 <INPUT TYPE=TEXT NAME=pr SIZE=7> $term[2](
<INPUT TYPE=CHECKBOX NAME=unit>단가 지정)에서 사 주세요.
<INPUT TYPE=HIDDEN NAME=prn VALUE="-1">
<INPUT TYPE=SUBMIT VALUE='작성'>
</FORM>
<hr width=500 noshade size=1>
<FORM ACTION="action.cgi" $METHOD>
<INPUT TYPE=HIDDEN NAME=key VALUE="req-s">
$USERPASSFORM
<INPUT TYPE=HIDDEN NAME=mode VALUE="new">
<INPUT TYPE=HIDDEN NAME=id VALUE="$DT->{id}">
<BIG>●매입 타입</BIG>：의뢰품 <SELECT NAME=prn SIZE=1>
$formlist
</SELECT> (을)를 수량 <INPUT TYPE=TEXT NAME=pr SIZE=7> 가지고 와준 분에게는<br>
가격 <INPUT TYPE=TEXT NAME=num SIZE=7> $term[2](
<INPUT TYPE=HIDDEN NAME=it VALUE="-1">
<INPUT TYPE=CHECKBOX NAME=unit>단가 지정)으로 매입합니다.
<INPUT TYPE=SUBMIT VALUE='작성'>
</FORM>
STR
OutSkin();
1;


sub ReqSet
{
	my @sort;
	foreach(1..$MAX_ITEM){$sort[$_]=$ITEM[$_]->{sort}};
	my @itemlist=sort { $sort[$a] <=> $sort[$b] } (1..$MAX_ITEM);
	$formitem="";
	$formlist="";		#전체의 리스트
	foreach my $idx (@itemlist)
	{
		next if !$ITEM[$idx]->{name};
		next if $ITEM[$idx]->{flag}=~/r/;	# r 의뢰 불가
		my $cnt=$DT->{item}[$idx-1];
		my $scale=$ITEM[$idx]->{scale};
		my $price=$ITEM[$idx]->{price};
		$formlist.="<OPTION VALUE=\"$idx\">$ITEM[$idx]->{name}(@".GetMoneyString($price).")" if $ITEM[$idx]->{flag}!~/o/;		# o 의뢰는 출품만
		$formitem.="<OPTION VALUE=\"$idx\">$ITEM[$idx]->{name}($cnt$scale@".GetMoneyString($price).")" if $cnt;
	}
}


