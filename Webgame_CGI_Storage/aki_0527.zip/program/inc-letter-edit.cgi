# 편지 편집 2003/07/19 유래

if ($Q{mode} eq 'new')
{
	$Q{old} = "list";	#송신이 끝난 트레이를 표시.
	$Q{form} = "";
	NewLetter();
}
else
{
	undef @RECLETTER;
	$NeverR=0;
	undef @SENLETTER;
	$NeverS=0;
	foreach my $i(0..$Lcount)
	{
	my $delete="del_".$LETTER[$i]->{no};
	$LETTER[$i]->{mode}=2 ,next if ($Q{$delete});
	if ($MYDIR eq $LETTER[$i]->{tot} && $LETTER[$i]->{toid}==$DT->{id})
		{
		push(@RECLETTER,$i);
		$NeverR++ if ($LETTER[$i]->{mode}==1);
		}
	if ($MYDIR eq $LETTER[$i]->{fromt} && $LETTER[$i]->{fromid}==$DT->{id})
		{
		push(@SENLETTER,$i);
		$NeverS++ if ($LETTER[$i]->{mode}==1);
		}
	}
}

$WriteFlag=1;		# 데이터 갱신을 지시.
1;


sub NewLetter
{
my $sendmail="";
my $sendto="";
foreach my $pg(@OtherDir)
	{
	$sendmail=$Q{$pg},$sendto=$pg if ($Q{$pg})
	}
OutError('행선지를 지정해 주세요.') if !$sendto;

	CheckNewBoxArg();

	@LETTER=reverse(@LETTER);
	$Lcount++;
	my $i=$Lcount;
	$LETTER[$i]->{no}=($i) ?($LETTER[$i-1]->{no} + 1) : 1 ;
	$LETTER[$i]->{time}=$NOW_TIME;
	$LETTER[$i]->{fromt}=$MYDIR;
	$LETTER[$i]->{fromid}=$DT->{id};
	$LETTER[$i]->{tot}=$sendto;
	$LETTER[$i]->{toid}=$sendmail;
	$LETTER[$i]->{title}=$Q{title};
	$LETTER[$i]->{msg}=$Q{msg};
	$LETTER[$i]->{mode}=1;	#미독설정
	$LETTER[$i]->{other}=$DT->{shopname};
	@LETTER=reverse(@LETTER);

	undef @SENLETTER;	# 다시 읽어
	$NeverS=0;
	foreach my $i(0..$Lcount)
	{
	if ($MYDIR eq $LETTER[$i]->{fromt} && $LETTER[$i]->{fromid}==$DT->{id})
		{
		push(@SENLETTER,$i);
		$NeverS++ if ($LETTER[$i]->{mode}==1);
		}
	}
}

sub CheckNewBoxArg
{
	$Q{msg}=CutStr($Q{msg},400);
	$Q{title}=CutStr($Q{title},40);
	OutError('내용이 없습니다') if $Q{msg}eq'';
	$Q{title}="(무제)" if $Q{title}eq'';
}

