# 구입 처리 2005/03/30 유래

$NOMENU=1;
$id=int($Q{id}+0);
$showcase=int($Q{sc}+0);
$itemno=int($Q{it}+0);
$price=int($Q{pr}+0);
$Q{er}=(($id==0)?'shop-m':'shop-a');

Lock();
DataRead();
CheckUserPass();

$num=CheckCount($Q{num1},$Q{num2},0,$ITEM[$itemno]->{limit}-$DT->{item}[$itemno-1]);
OutError('수량을 지정해 주세요.') if !$num;

if($id==0)
{
	# 시장
	$DTS=GetWholeStore();
	$DTS->{_wholestore_}=1;
}
else
{
	# 일반점
	OutError('가게가 망했을지도 모릅니다') if !defined($id2idx{$id});
	$DTS=$DT[$id2idx{$id}];
}
OutError('자신의 가게로부터 살 수 없습니다') if $DT->{id}==$DTS->{id};
CheckShowCaseNumber($DTS,$showcase);
CheckItemNo($itemno,$DTS);

my $baseprice=$DTS->{price}[$showcase];
my($guild,$guildrate,$guildmargin) =CheckGuild($DT,$DTS,$baseprice);
my $saleprice=$baseprice+($guild==1 ? -$guildmargin : $guildmargin);

if($itemno!= $DTS->{showcase}[$showcase]
|| $price != $saleprice
|| !$DTS->{item}[$itemno-1]
)
{
	OutError('상품이나 가격이 변화한 것 같습니다');
}

$num=$DTS->{item}[$itemno-1] if $DTS->{item}[$itemno-1]<$num;
$num=int($DT->{money}/$price) if ($DT->{money}<$num*$price && $price > 0);
$num=0 if $num<0;

OutError('놀림입니까?') if !$num;

$TIME_SEND_ITEM=int($TIME_SEND_ITEM/2) if !$id;
my $usetime=GetTimeDeal($baseprice*$num,$itemno,$num);
UseTime($usetime);
my($taxrate,$tax) =GetSaleTax($itemno,$num,$baseprice*$num,GetUserTaxRate($DTS,$DTTaxrate));

$DTS->{item}[$itemno-1]-=$num;
$DTS->{itemtoday}{$itemno}+=$num;
$DT->{item}[$itemno-1]+=$num;
$DTS->{money}+=$num*$baseprice-$tax;
$DTS->{trush}+=int($num*$baseprice/2);
$DT->{money}-=$num*$price;
$DT->{paytoday}+=$num*$price;
$DTS->{saletoday}+=$num*$baseprice;
$DTS->{taxtoday}+=$tax;

EditGuildMoney($DT->{guild} ,-$guildmargin*$num) if $guild==1;
EditGuildMoney($DTS->{guild},$guildmargin*$num) if $guild==2;

#품절시의 인기 DOWN(상대 가게) ※동길드의 경우는 SKIP
if($DTS->{item}[$itemno-1]==0 && $guild!=1 && $guild!=-1)
{
	my $rankdown+=($DTS->{rank}/100)**3/1000; #인기에 응해 다운
	#$rankdown+=70*4/($nowranking+3); #랭킹에 응해 다운

	if($rankdown<1 && $rankdown>0)
		{$rankdown=1 if rand(1/$rankdown)<1;}
	$DTS->{rank}-=int($rankdown);
	$DTS->{rank}=0 if $DTS->{rank}<0;
}

$ret=$DTS->{shopname}."에서 ".$ITEM[$itemno]->{name}."(을)를 ".$num.$ITEM[$itemno]->{scale}.'@'.GetMoneyString($price)."(합계 ".GetMoneyString($price*$num).")";
$ret.=(($ITEM[$itemno]->{flag}=~/h/) ? "으로 고용했습니다" : "에서 구매했습니다");
$ret.="/".GetTime2HMS($usetime)." 소비";
$ret.="/".('길드내 할인','길드간 할증')[$guild-1].'@'.GetMoneyString($guildmargin) if $guild>0;
$ret.="/길드내 할인 보조 없음" if $guild==-1;
PushLog(0,$DT->{id},$ret);

@item::DT=@DT;
$item::DT=$DT;
@item::ITEM=@ITEM;
$item::ITEM=$ITEM;
$item::BUY={
	dt		=>	$DT,
	dts		=>	$DTS,
	whole	=>	$DTS->{_wholestore_},
	item	=>	$ITEM[$itemno],
	itemno	=>	$itemno,
	num		=>	$num,
	price	=>	$price,
	baseprice=>	$baseprice,
	tax		=>	$tax,
	guild	=>	$guild,
	guildmargin	=>	$guildmargin,
};
RequireFile("inc-item.cgi");
require "$ITEM_DIR/funcbuy.cgi" if $DEFINE_FUNCBUY;

if($ITEM[$itemno]->{funcbuy})
{
	#@@item funcb 처리
	my $item=$ITEM[$itemno];
	my $file="$ITEM_DIR/item-b/$item->{no}$FILE_EXT";
	my $func="item::".$item->{funcsale};
	my $funcexists=defined &$func;
	require $file if -e $file;
	&$func($item::BUY);
	undef &$func if !$funcexists;
	delete $INC{$file};
	undef @item::DT;
	undef $item::DT;
	undef @item::ITEM;
	undef $item::ITEM;
}

SetWholeStore($DTS) if $id==0;

WriteGuildData() if $guild>0;
RenewLog();
DataWrite();
DataCommitOrAbort();
UnLock();

$disp.=$TBT.$TRT.$TD.GetTagImgJob($DT->{job},$DT->{icon});
$disp.=$TD.GetMenuTag('stock',	'[창고에]');
$disp.=($id==0) ? GetMenuTag('shop-m','[매입을 계속한다]') : GetMenuTag('shop-a','[쇼핑을 계속한다]','&t=2');
$disp.=$TRE.$TBE;
$disp.="<br>".$ret;

OutSkin();
1;

