# 영주 시정 2005/01/06 유래

$image[0]=GetTagImgKao("대신","minister");
DataRead();
CheckUserPass();
OutError('정치를 실시할 수 있는 것은 영주뿐입니다') if $STATE->{leader}!=$DT->{id};

my $shoplist="";
my $taxsum=0;
foreach (@DT) {
$shoplist.="<OPTION VALUE=\"$_->{id}\">$_->{shopname}";
$taxsum+=$_->{taxtoday};
}

my $now=$DTlasttime+$TZ_JST-$DATE_REVISE_TIME;
my $ii=($now % $ONE_DAY_TIME);
$ii=1 if $ii < 1;
$taxsum=GetMoneyString(int($taxsum * $ONE_DAY_TIME / $ii / 10000) * 10000);

$disp.="<BIG>●정무실</BIG><br><br>";
$disp.=$TB.$TR.$TD.$image[0].$TD."<SPAN>대신</SPAN>：안녕하십니까 영주님. 기분은 어떠신지요.<br>";
$disp.="정치는 저에게 맡겨 주십시오. 열심히 하겠습니다. 흠".$TRE.$TBE;
my $money=GetMoneyString($STATE->{money}+0);
my $army=$STATE->{army} + $STATE->{robina};
my $armycost=200-int($STATE->{safety} / 100); 	# 100 - 200
my $armyc=GetMoneyString($STATE->{army} * $armycost);

$disp.=<<"HTML";
<hr width=500 noshade size=1><BIG>●내정 설정</BIG><br><br>
<FORM ACTION="action.cgi" $METHOD>
<INPUT TYPE=hidden NAME=key VALUE="lord-s">
$USERPASSFORM
<INPUT TYPE=hidden NAME=mode VALUE="inside">
$TB$TDB거리 자금$TDB 세수입 전망$TDB 세율
$TDB 개척 대책비$TDB 치안 대책비 $TRE
$TR$TD<b>$money</b>
$TD$taxsum
$TD<INPUT TYPE=TEXT NAME=taxrate SIZE=5 VALUE="$DTTaxrate"> %<br><small>(표준 20%)</small>
$TD$term[0]<INPUT TYPE=TEXT NAME=devem SIZE=10 VALUE="$STATE->{devem}">$term[1]<br><small>(표준 $term[0]5,000,000$term[1])</small>
$TD$term[0]<INPUT TYPE=TEXT NAME=safem SIZE=10 VALUE="$STATE->{safem}">$term[1]<br><small>(표준 $term[0]5,000,000$term[1])</small>
$TRE$TBE
<br><INPUT TYPE=SUBMIT VALUE="이상의 내용으로 결정">
</FORM>

<hr width=500 noshade size=1><BIG>●상벌</BIG><br><br>
<FORM ACTION="action.cgi" $METHOD>
<INPUT TYPE=hidden NAME=key VALUE="lord-s">
$USERPASSFORM
<INPUT TYPE=hidden NAME=mode VALUE="taxside">
<BIG>●개별 세율</BIG>： 
<SELECT NAME=tg>$shoplist</select>
 의 세율을
<SELECT NAME=md><OPTION VALUE="normal">통상
<OPTION VALUE="free">면제
<OPTION VALUE="double">2배
</select> (으)로 <INPUT TYPE=SUBMIT VALUE="설정한다">
</FORM>
<FORM ACTION="action.cgi" $METHOD>
<INPUT TYPE=hidden NAME=key VALUE="lord-s">
$USERPASSFORM
<INPUT TYPE=hidden NAME=mode VALUE="treset">
<BIG>●세율 리셋트</BIG>： 
모든 가게의 세율을 통상으로 <INPUT TYPE=SUBMIT VALUE="리셋트 한다">
</FORM>
HTML

if ($DTevent{rebel})
{
$disp.="<BIG>●가게 단속</BIG>： 반란중이기 때문에 실행할 수 없습니다";
}
elsif ($STATE->{army} < 2000)
{
$disp.="<BIG>●가게 단속</BIG>： 단속에 필요한 병사수가 충분하지 않습니다";
}
elsif ($STATE->{money} < 1000000)
{
$disp.="<BIG>●가게 단속</BIG>： 비용이 충분하지 않습니다";
}
else
{
$disp.=<<"STR";
<FORM ACTION="action.cgi" $METHOD>
<INPUT TYPE=hidden NAME=key VALUE="lord-s">
$USERPASSFORM
<INPUT TYPE=hidden NAME=mode VALUE="expose">
<BIG>●가게 단속</BIG>： 
<SELECT NAME=tg>$shoplist</select>
 (을)를 군대에서 
 <INPUT TYPE=SUBMIT VALUE="단속한다"> (비용 $term[0]1,000,000$term[1])
</FORM>
STR
}

$disp.=<<"HTML";
<hr width=500 noshade size=1><BIG>●군사 설정</BIG><br><br>
$TB$TR$TDB 현재의 병력
$TD<b>$army인</b><small>(정규군 $STATE->{army}인, 의용군 $STATE->{robina}인) $TRE
$TR$TDB 병력 유지비
$TD<b>$armyc</b><small>(정규군 1명에 대해 $term[0]$armycost$term[1]) $TRE
$TBE
HTML

if ($STATE->{money}>0 && !$DTevent{rebel})
{
	$disp.=<<STR;
	<FORM ACTION="action.cgi" $METHOD>
	<INPUT TYPE=hidden NAME=key VALUE="lord-s">
	$USERPASSFORM
	<INPUT TYPE=hidden NAME=mode VALUE="outside">
	<BIG>●병력 증강</BIG>： 병사를 
	<SELECT NAME=cnt1>
	<OPTION VALUE="0" SELECTED>
STR
	my $stock=int($STATE->{money} / 1200);
	$msg{1000}=1000;
	$msg{5000}=5000;
	$msg{10000}=10000;
	$msg{20000}=20000;
	$msg{$stock}="$stock(자금 최대)";
	my $oldcnt=0;
	foreach my $cnt (sort { $a <=> $b } (1000,5000,10000,20000,$stock))
	{
		last if $stock<$cnt || $cnt==$oldcnt;
		$disp.="<OPTION VALUE=\"$cnt\">$msg{$cnt}";
		$oldcnt=$cnt;
	}
	$disp.=<<STR;
	</SELECT>
	 인, 혹은 
	<INPUT TYPE=TEXT SIZE=7 NAME=cnt2> 인
	<INPUT TYPE=SUBMIT VALUE="증강한다"> @$term[0]1,200$term[1]
	</FORM>
STR
	$disp.=<<STR;
	<FORM ACTION="action.cgi" $METHOD>
	<INPUT TYPE=hidden NAME=key VALUE="lord-s">
	$USERPASSFORM
	<INPUT TYPE=hidden NAME=mode VALUE="outdel">
	<BIG>●병력 삭감</BIG>： 병사를 
	<SELECT NAME=cnt1>
	<OPTION VALUE="0" SELECTED>
STR
	my $army=$STATE->{army}+0;
	$msg{1000}=1000;
	$msg{5000}=5000;
	$msg{10000}=10000;
	$msg{20000}=20000;
	$msg{$army}="$army(병사 최대)";
	my $oldcnt=0;
	foreach my $cnt (sort { $a <=> $b } (1000,5000,10000,20000,$army))
	{
		last if $army<$cnt || $cnt==$oldcnt;
		$disp.="<OPTION VALUE=\"$cnt\">$msg{$cnt}";
		$oldcnt=$cnt;
	}
	$disp.=<<STR;
	</SELECT>
	 인, 혹은 
	<INPUT TYPE=TEXT SIZE=7 NAME=cnt2> 인
	<INPUT TYPE=SUBMIT VALUE="해고한다"> @$term[0]0$term[1]
	</FORM>
STR
}

OutSkin();
1;

