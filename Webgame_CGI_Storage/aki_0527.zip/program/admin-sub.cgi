# 개별 사용자 관리 2005/03/30 유래
Lock();
DataRead();
CheckUserPass();
OutError('') if !$MASTER_USER || $USER ne 'soldoutadmin';

OutError('사용자가 발견되지 않습니다') if !defined($name2idx{$Q{user}});
my $DT=$DT[$name2idx{$Q{user}}];

#중복 등록 자동 액세스 제한의 개별 대응
if($Q{nocheckip})
{
	$disp.='중복 등록 체크 대상외로 했습니다',$DT->{nocheckip}=1 if $Q{nocheckip} eq 'nocheck';
	$disp.='중복 등록 체크 대상으로 했습니다',$DT->{nocheckip}='' if $Q{nocheckip} eq 'check';
}

#액세스 제한 제어
if($Q{blocklogin})
{
	if($Q{blocklogin} eq 'off')
	{
		$disp.='액세스 제한을 해제했습니다';
		$DT->{blocklogin}='';
		$DT->{lastlogin}=$NOW_TIME;
	}
	elsif($Q{blocklogin} eq 'stop')
	{
		$disp.='경영 휴지로 설정했습니다['.$Q{blocklogin}.']';
		$DT->{blocklogin}=$Q{blocklogin};
	}
	elsif($Q{blocklogin} ne '')
	{
		$disp.='액세스 제한을 했습니다['.$Q{blocklogin}.']';
		$DT->{blocklogin}=$Q{blocklogin};
	}
}

#추방
if($Q{closeshop} eq 'closeshop')
{
	CloseShop($DT->{id},'추방');
	PushLog(1,0,"$Q{comment} $DT->{shopname}는 추방되었습니다.") if (!$Q{log});

	$disp.="추방 완료";
	$DTblockip=$DT->{remoteaddr};
}

#상품 수여(디버그에도 사용할 수 있습니다)
if($Q{senditem})
{
	my $itemno=$Q{senditem};
	my $ITEM=$ITEM[$itemno];
	my $itemcount=$Q{count};
	$itemcount+=$DT->{item}->[$itemno-1];
	$itemcount=$ITEM->{limit} if $itemcount>$ITEM[$itemno]->{limit};
	$DT->{item}->[$itemno-1]=$itemcount;
	
	PushLog(2,0,"$Q{comment} $DT->{shopname}에 $ITEM->{name}가 주어졌습니다.") if $Q{comment};
	$disp.="$ITEM->{name} $Q{count}$ITEM->{scale} 상품 수여 완료";
}

#상금 수여(디버그에도 사용할 수 있습니다)
if($Q{sendmoney})
{
	$DT->{money}+=$Q{sendmoney};
	#$DT->{saletoday}+=$Q{sendmoney};
	
	PushLog(2,0,"$Q{comment} $DT->{shopname}에 상금이 주어졌습니다.") if $Q{comment};
	$disp.=GetMoneyString($Q{sendmoney})." 상금 수여 완료";
}

#제한시간 수여(디버그에도 사용할 수 있습니다)
if($Q{sendtime})
{
	$disp.=$Q{sendtime}."시간 제한시간 수여 완료";
	$Q{sendtime}=$Q{sendtime} * 3600;
	$DT->{time}-=$Q{sendtime};
	
	PushLog(2,0,"$Q{comment} $DT->{shopname}에 「".GetTime2HMS($Q{sendtime})."」(이)가 주어졌습니다.") if $Q{comment};
}

#작위 수여(디버그에도 사용할 수 있습니다)
if($Q{senddig})
{
	$disp.=$Q{senddig}."포인트 작위 경험치 수여 완료";
	$DT->{dignity}+=$Q{senddig};
	
	PushLog(2,0,"$Q{comment} $DT->{shopname}에 작위 경험치".($Q{senddig}+0)."포인트가 주어졌습니다.") if $Q{comment};
}

RenewLog();
DataWrite();
DataCommitOrAbort();
UnLock();

$disp="실시하고 싶은 처리와 그 파라미터를 올바르게 선택/기술해 주세요" if $disp eq '';
$disp.=" <-- $DT->{shopname} [$DT->{name}] $Q{comment}";

$NOMENU=1;
$Q{bk}="none";
OutSkin();
1;
