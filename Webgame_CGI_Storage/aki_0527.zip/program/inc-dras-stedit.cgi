# 드래곤 레이스 마굿간 편집 2005/03/30 유래

ReadStable();
$disp.="<BIG>●드래곤 레이스：마굿간</BIG><br><br>";

my $functionname=$Q{code};
OutError("bad request") if !defined(&$functionname);
&$functionname;

WriteStable();
RenewDraLog();
CoDataCA();
1;


sub new
{
OutError("bad request") if ($MYST!=-1);
OutError("bad request") if (scalar @ST >= $STmax);
OutError('자금의 여유가 없습니다.') if ($DT->{money} < $STest);

	# 이름의 정당성을 체크
	if(!$Q{name})
	{
		OutError('이름을 입력해 주세요.');
	}
	if($Q{name} =~ /([,:;\t\r\n<>&])/ || CheckNGName($Q{name}) )
	{
		OutError('이름에 사용할 수 없는 문자가 포함되어 있습니다.');
	}
	OutError('이름이 너무 깁니다.') if length($Q{name})>20;
	OutError('이름이 너무 짧습니다.') if length($Q{name})<6;

	@ST=reverse(@ST);
	$STcount++;
	my $i=$STcount;
	$ST[$i]->{no}=($i > 0) ? ($ST[$i-1]->{no} + 1) : 1 ;
	$ST[$i]->{birth}=$NOW_TIME;
	$ST[$i]->{name}=$Q{name};
	$ST[$i]->{town}=$MYDIR;
	$ST[$i]->{owner}=$DT->{id};
	$ST[$i]->{emp}=$Q{emp};
	$ST[$i]->{sp}=1;
	$ST[$i]->{tr}=int(rand(15));
	$ST[$i]->{con}=int(rand(15));
	$ST[$i]->{wt}=int(rand(15));
	@ST=reverse(@ST);

WritePayLog($MYDIR,$DT->{id},-$STest);
PushDraLog(0,"새로운 마굿간 「".$Q{name}."」(이)가 설립되었습니다.");
$disp.="새로운 마굿간 「<b>".$Q{name}."</b>」(을)를 설립했습니다.";
}

sub large
{
OutError("bad request") if ($MYST==-1);
OutError('자금의 여유가 없습니다.') if ($DT->{money} < $STest);
my $n=int(($NOW_TIME - $ST[$MYST]->{birth})/86400/2) + 1;
my $cost=($ST[$MYST]->{sp} + $ST[$MYST]->{sr} + $ST[$MYST]->{ag} + $ST[$MYST]->{pw} + $ST[$MYST]->{hl} + $ST[$MYST]->{fl});
OutError("bad request") if ($n < $cost);

	my @large=qw(
		sp sr ag pw hl fl
		);

	my $lar=$large[$Q{lar}];

	$ST[$MYST]->{$lar}++;
	OutError('더 이상, 이 시설은 증축할 수 없습니다') if ($ST[$MYST]->{$lar} > 3);

WritePayLog($MYDIR,$DT->{id},-$STest);
$disp.="마굿간을 증축했습니다.";
}


