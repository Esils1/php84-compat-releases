# 의뢰 일람표시 2005/01/06 유래

DataRead();
CheckUserPass(1);
RequireFile('inc-req.cgi');
RequireFile('inc-html-ownerinfo.cgi');

$disp.="<BIG>●의뢰소</BIG><br><br>";

$enum=0;
if ($REQNONE)
	{
	$disp.=<<STR;
	$TBT$TRT$TD$AucImg
	$TD<SPAN>의뢰소의 접수</SPAN><br>
	현재 의뢰는 없는데. 의뢰를 내볼까?$TRE$TBE<br>
STR
	}
	else
	{
	ReqList();
	}
if (!$GUEST_USER && $enum < $REQUEST_CAPACITY)
	{
	$disp.=<<STR;
	<br>
	<FORM ACTION="action.cgi" $METHOD>
	<INPUT TYPE=HIDDEN NAME=key VALUE="req-f">
	$USERPASSFORM
	<INPUT TYPE=SUBMIT VALUE='새로운 의뢰서를 작성한다'>
	</FORM>
STR
	}
OutSkin();
1;


sub ReqList
{
$disp.=<<STR;
	$TBT$TRT$TD$AucImg
	$TD<SPAN>의뢰소의 접수</SPAN><br>
	이만큼의 의뢰가 나와 있군.$TRE$TBE<br>
$TB$TR
$TDB 의뢰품
$TDB 보수품
$TDB 의뢰자
$TDB 상태
$TDB 기한
$TRE
STR

foreach my $i(0..$Scount)
{
	next unless defined($REQ[$i]->{no});
	my($no,$id,$itemno,$num,$prn,$pr,$mode)=($REQ[$i]->{no},$REQ[$i]->{id},$REQ[$i]->{itemno},$REQ[$i]->{num},$REQ[$i]->{prn},$REQ[$i]->{pr},$REQ[$i]->{mode});
	$disp.=$TR.$TD;
	if (!$GUEST_USER)
		{
		$disp.=($mode && $id == $DT->{id}) ? "<a href=\"action.cgi?key=req-s&mode=thank&idx=$no&$USERPASSURL\">" : "<a href=\"action.cgi?key=req-l&no=$no&$USERPASSURL\">";
		}
	if ($prn > 0)
		{
		$disp.=GetTagImgItemType($prn).$ITEM[$prn]->{name}.' '.$pr.$ITEM[$prn]->{scale};
		$disp.=    "</a> " if (!$GUEST_USER);
		$disp.='<br><small>(정가 '.GetMoneyString($ITEM[$prn]->{price} * $pr).')</small>';
		}
		else
		{
		$disp.='자금 '.GetMoneyString($pr);
		$disp.=    "</a> " if (!$GUEST_USER);
		}
	$disp.=$TD;
	if ($itemno > 0)
		{
		$disp.=GetTagImgItemType($itemno).$ITEM[$itemno]->{name}.' '.$num.$ITEM[$itemno]->{scale};
		$disp.='<br><small>(정가 '.GetMoneyString($ITEM[$itemno]->{price} * $num).')</small>';
		}
		else
		{
		$disp.='자금 '.GetMoneyString($num);
		}
	$disp.=($DT->{id} == $REQ[$i]->{id}) ? $TDB : $TD;
	$disp.=defined($id2idx{$id}) ? ($DT[$id2idx{$id}]->{shopname}) : '없음';
	$disp.=defined($id2idx{$mode}) ? "$TD<SPAN>달성</b></SPAN>" : "$TD ";
	$disp.="$TD 최대 ".GetTime2HMS($REQ[$i]->{tm}-$NOW_TIME);
	$enum++ if ($id == $DT->{id});	#출품수를 카운트
	}
$disp.=$TRE.$TBE;
}


