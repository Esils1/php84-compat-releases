# 청소 2005/01/06 유래

Lock();
DataRead();
CheckUserPass();

$time=int(GetStockTime($DT->{time})/ 3600);
$count=CheckCount($Q{cnt1},$Q{cnt2},0,$time);
OutError('시간을 지정해 주세요') if ($count < 1);
my $usetime=GetTimeDeal($DT->{trush});
$usetime=$count * 3600 if ($usetime > $count * 3600);
my $deal=$count * 3600 / $TIME_SEND_MONEY * $TIME_SEND_MONEY_PLUS;
$deal=$DT->{trush} if ($DT->{trush} < $deal);

$DT->{trush}-=$deal;
UseTime($usetime);

RequireFile('inc-html-ownerinfo.cgi');

$disp.="<BIG>●청소 리포트</BIG><br><br>청소를 실시했습니다.<br><br>";
$disp.=$TB.$TR.$TD;
$disp.="<SPAN>예정소요 시간</SPAN>：".$count."시간<br>";
$disp.="<SPAN>실제 걸린 시간</SPAN>：".GetTime2HMS($usetime)."<br>";
$disp.="<SPAN>최초 있던 쓰레기의 양</SPAN>：".int(($DT->{trush}+$deal)/10000)."kg<br>";
$disp.="<SPAN>정리한 쓰레기의 양</SPAN>：".int($deal/10000)."kg<br>";
$disp.="<SPAN>남은 쓰레기의 양</SPAN>：".int($DT->{trush}/10000)."kg";
$disp.=$TRE.$TBE;

DataWrite();
DataCommitOrAbort();
UnLock();

OutSkin();
1;

