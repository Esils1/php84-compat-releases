# 장원 2005/03/30 유래

$NOITEM=1;
DataRead();
CheckUserPass();
RequireFile('inc-manor.cgi');

$disp.="<BIG>●영주 정보</BIG><br><br>";

my $MANORLORD;

if (defined($id2idx{$STATE->{leader}}))
	{
	my $i=$id2idx{$STATE->{leader}};
	$disp.=$TB.$TR.$TD.GetTagImgKao($DT[$i]->{name},$DT[$i]->{icon});
	$disp.=$TD."<SPAN>영주</SPAN> ： <b>".$DT[$i]->{name}."</b>";
	$disp.=DignityDefine($DT[$i]->{dignity})." <small>(".$DT[$i]->{shopname}.")</small><br>";
	$disp.=">> ".$DT[$i]->{comment};
	$disp.=$TRE.$TBE;

	# 장원 설정을 취득
	ReadDTSub($DT[$i],"lord");
	$MANORLORD=$DT[$i]->{_lord};
	}
	else
	{
$disp.=$TB.$TR.$TD.GetTagImgKao($BAL_NAME,"bal");
$disp.=$TD."영주 ： <b>$BAL_NAME</b> <small>($BAL_JOB)</small><br>";
$disp.=">> 장원? 뭣인지 알까보냐. 으하하하!";
$disp.=$TRE.$TBE;
	}

	ReadDTSub($DT,"seed");
	my $seedlock=0;
	my $ripeflag=0;

$disp.="<br><BIG>●장원 상황</BIG><br><br>";
$disp.=$TB.$TR;
$disp.=$TDB."종".$TDB."판매 재고".$TDB."판매 가격".$TDB."자점 보유".$TD.$TDB."수확물".$TDB."매입 가격".$TDB."자점 보유".$TRE;

foreach my $i(0..$#MANOR)
	{
	my @MYMANOR=@{$MANOR[$i]};
	if ($DT->{_seed}->{"base$i"} && $DT->{_seed}->{"time$i"} < $NOW_TIME)
		{
		#성숙
		$DT->{_seed}->{"ripe$i"}+=$DT->{_seed}->{"base$i"};
		delete $DT->{_seed}->{"base$i"};
		delete $DT->{_seed}->{"time$i"};
		$seedlock++;
		}
	$disp.=$TR.$TD;
	$disp.=($MANORLORD->{"count$i"}) ? "<a href=\"action.cgi?key=manor-m&$USERPASSURL&buy=".$i."&bk=manor\">" : "<b>";
	$disp.=GetTagImgManor($MYMANOR[1]).$MYMANOR[0];
	$disp.=($MANORLORD->{"count$i"}) ? "</a> " : "</b>";
	$disp.=$TD.($MANORLORD->{"count$i"} + 0)." 개";
	$disp.=$TD."@".GetMoneyString($MANORLORD->{"price$i"});
	$disp.=$TD.($DT->{_seed}->{"base$i"} + 0)." 개";
	$disp.=$TD."→".$TD.GetTagImgManor($MYMANOR[3]).$MYMANOR[2];
	$disp.=$TD."@".GetMoneyString($MANORLORD->{"cost$i"});
	$disp.=$TD.($DT->{_seed}->{"ripe$i"} + 0)." 개".$TRE;
	$ripeflag+=$DT->{_seed}->{"ripe$i"};
	}
$disp.=$TBE;

if ($ripeflag)
	{
$disp.=<<"HTML";
	<br>
	<FORM ACTION="action.cgi" $METHOD>
	<INPUT TYPE=HIDDEN NAME=key VALUE="manor-r">
	<INPUT TYPE=HIDDEN NAME=bk VALUE="manor">
	$USERPASSFORM
<BIG>●수확물 매각</BIG>： 수확물을 영주의 장원에 
<INPUT TYPE=SUBMIT VALUE="매각한다">
	</FORM>
HTML
	}

if ($seedlock)
	{
	Lock();		#타인은 같은 파일에 액세스 하지 않기 때문에 락은 늦고 좋다
	WriteDTSub($DT,"seed");
	DataCommitOrAbort();
	UnLock();
	}

if ($STATE->{leader}==$DT->{id})
	{
	$disp.=<<STR;
	<br>
	<FORM ACTION="action.cgi" $METHOD>
	<INPUT TYPE=HIDDEN NAME=key VALUE="manor-f">
	$USERPASSFORM
	<INPUT TYPE=HIDDEN NAME=form VALUE="plus">
	<INPUT TYPE=SUBMIT VALUE='장원을 관리한다'>
	</FORM>
STR
	}

OutSkin();
1;


