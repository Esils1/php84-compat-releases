# 길드 설립 처리 2004/01/20 유래

CoLock();
DataRead();
CheckUserPass();
ReadGuild();
ReadGuildData();
$image[0]=GetTagImgKao("길드 접수","guild");
$Q{er}='gd-f';

$disp.="<BIG>●길드 공관</BIG><br><br>";

$Q{url}="http://" if $Q{url} eq "";
$Q{leadt}=$MYDIR;
$Q{leader}=$DT->{id};
@GLIST=(name,shortname,dealrate,feerate,member,comment,appeal,needed,leadt,leader,url);
@MAX=(30,12,4,4,6,30,120,120,10,10,60);
foreach my $i(0..$#GLIST)
	{
	OutError('기입되어 있지 않은 항목이 있습니다 - '.$GLIST[$i]) if (!$Q{$GLIST[$i]});
	$Q{$GLIST[$i]}=CutStr($Q{$GLIST[$i]},$MAX[$i]);
	$Q{$GLIST[$i]}=~s/&/&amp;/g;
	$Q{$GLIST[$i]}=~s/>/&gt;/g;
	$Q{$GLIST[$i]}=~s/</&lt;/g;
	}
$Q{url}="" if $Q{url} eq "http://";
OutError('회비율이나 할인증율에 사용할 수 없는 캐릭터가 포함되어 있습니다') if ($Q{dealrate} =~ /([^0-9])/)||($Q{feerate} =~ /([^0-9])/);
OutError('할증율은 10~500의 사이의 수치로 지정해 주세요') if ($Q{dealrate} > 500) || ($Q{dealrate} < 10);
OutError('회비율은 10~500의 사이의 수치로 지정해 주세요') if ($Q{feerate} > 500) || ($Q{feerate} < 10);
OutError('길드 코드에 사용할 수 없는 캐릭터가 포함되어 있습니다') if ($Q{code} =~ /([^a-z])/);
OutError('길드 설립에 화상 파일은 필수입니다') if (!$Q{upfile})&&($Q{mode} ne "edit");

OutError('같은 길드 코드가 벌써 존재하고 있습니다') if (-e $COMMON_DIR."/".$Q{code}.".pl")&&($Q{mode} ne "edit");

GuildImgUp() if ($Q{upfile});
BuildGuild();
CoUnLock();

if ($Q{mode} ne "edit")
{
	Lock();
	DataRead();
	CheckUserPass();
	$DT->{guild}=$Q{code};
	DataWrite();
	DataCommitOrAbort();
	UnLock();
}

$disp.=<<"HTML";
$TB$TR
$TD$image[0]$TD
길드 접수：수속이 완료되었습니다. 몇분 후에 반영될 것입니다.<br>
즐거운 길드가 되면 좋겠네요. 노력해 주세요.
$TRE$TBE
HTML
OutSkin();
1;


sub GuildImgUp
{
	if ($MIMETYPE{upfile} = ~/gif/i)
	{
	my $ImgFile = $COMMON_DIR."/".$Q{code}.".gif";
	my $upfile=$Q{upfile};
	open(OUT,"> $ImgFile");
	binmode(OUT);
	binmode(STDOUT);
	print OUT $upfile;
	close(OUT);
	chmod (0666,$ImgFile);
	}
	else
	{
	OutError('gif 화상 파일은 아닌 것 같습니다.'.$MIMETYPE{upfile});
	}
}

sub BuildGuild
{
	my @MESSAGE=();
	push(@GLIST,@OtherDir);
	foreach my $i(0..$#GLIST)
		{
		$MESSAGE[$i]=$GLIST[$i]."=".$Q{$GLIST[$i]}."\n";
		}
	OpenAndCheck($COMMON_DIR."/".$Q{code}.".pl");
	print OUT @MESSAGE;
	close(OUT);
}


