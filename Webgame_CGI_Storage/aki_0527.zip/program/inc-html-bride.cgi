# 주택 일람표시 2005/03/30 유래

if ($Q{form} eq "pro" && !$GUEST_USER)
{
ProposeForm();
}
elsif ($Q{form} && !$GUEST_USER)
{
ConstForm();
}
else
{
BrideList();
}
1;

sub BrideList
{
my $i;
if (!$GUEST_USER && !$married)
{
$i="<br><a href=\"action.cgi?key=bride&form=pro&$USERPASSURL\">[프로포즈한다]</a> ";
}

$disp.=<<STR;
$TBT$TRT$TD
<IMG width="96" height="192" SRC="$IMAGE_URL/map/church.png"><td width=10>$TD
$image[3]
<SPAN>신부</SPAN><br>
결혼에 대해 알고 계십니까?<br>
결혼해 주택을 지으면, 거기에 소지품을 둘 수가 있어요.<br>
주택을 가질 때까지는, 이 교회의 소지품 두는 곳을 사용해도 괜찮습니다.<br>
그렇지만 가장 소중한 것은, 역시 두 명의 강한 사랑이군요.$i
$TRE$TBE<br>
$TB$TR
$TDB 점수
$TDB 상태
$TDB 상세
$TDB 날짜
$TDB 보관품
$TRE
STR
@BRIDE=sort{$b->{point}<=>$a->{point}}@BRIDE;
foreach my $i(0..$Scount) {
	next if ($BRIDE[$i]->{mode}==-1) || !defined($BRIDE[$i]->{no});
	my ($ida,$idb)=($BRIDE[$i]->{ida},$BRIDE[$i]->{idb});
	$disp.=($DT->{id} == $ida || $DT->{id} == $idb) ? $TR.$TDB : $TR.$TD;
	$disp.='<b>No.'.($i+1).'</b><br>'.$BRIDE[$i]->{point}.'<td>';
	$disp.=    "<a href=\"action.cgi?key=bride&no=$BRIDE[$i]->{no}&$USERPASSURL\">" if (!$GUEST_USER);

	if (!$BRIDE[$i]->{mode})
	{
	$disp.=$image[2];
	$disp.=    "</a> " if (!$GUEST_USER);
	$disp.='<td>'.$DT[$id2idx{$ida}]->{shopname}.'로부터 <SPAN>'.$DT[$id2idx{$idb}]->{shopname}."</SPAN> 으로";
	}
	else
	{
	$disp.=($BRIDE[$i]->{mode}==1)?$image[0]:$image[1];
	$disp.=    "</a> " if (!$GUEST_USER);
	$disp.='<td>'.$DT[$id2idx{$ida}]->{shopname}.' ＆ '.$DT[$id2idx{$idb}]->{shopname};
	}
	$disp.="<td align=center>".GetTime2found($NOW_TIME-$BRIDE[$i]->{tm});
	$disp.='<td>'.GetMoneyMessage($BRIDE[$i]->{money}).'<br>';
	foreach (0..$BRIDE[$i]->{mode}-1) { $disp.=GetTagImgItemType($BRIDE[$i]->{stock}[$_]);}
	}
$disp.=$TRE.$TBE;
}

sub ProposeForm
{
	OutError("bad request") if $married;
	$userselect="";
	foreach my $DTS (@DT)
	{
		$userselect.="<OPTION VALUE=\"$DTS->{id}\">$DTS->{name} ($DTS->{shopname})";
	}
$disp.=<<STR;
$TB$TR$TD
$image[3]
신부：가족을 가지는 것을 소망합니까? 그렇다면 다음의 주의사항을 잘 들어 주세요.<br>
·서로 결혼자금이 <b>500만$term[2] </b>듭니다.<br>
·결혼상대는 신중하게 선택하세요. 그 사람과 서로 도와 갈 수 있을지 잘 생각해주세요.<br>
·사전에 서로 자주 이야기하세요. 갑자기 프로포즈를 해도 상대는 곤란하겠지요.<br>
·프로포즈를 한 쪽이 남편이 되어, 받은 쪽이 아내가 됩니다.
$TRE$TBE<br>
<form action="action.cgi" $METHOD>
$MYFORM$USERPASSFORM
<INPUT TYPE=HIDDEN NAME=mode VALUE="new">
<BIG>●프로포즈</BIG>：나 $DT->{name} ($DT->{shopname})는
<SELECT NAME=tg>$userselect</SELECT>
(을)를 아내로 해<br>
건강한 때도 병든 때도 그 몸을 함께 하는 일을
<INPUT TYPE=SUBMIT VALUE='맹세합니다'>
</FORM>
STR
}

sub ConstForm
{
$disp.=<<STR;
$TB$TR$TD
$image[3]
신부：주택을 짓습니까? 그렇다면 다음의 주의사항을 잘 들어 주세요.<br>
·자금이 <b>1500만 $term[2]</b> 듭니다. 공용 창고로부터 지출됩니다.<br>
·한 번 세우면 장소를 옮길 수 없습니다.<br>
$TRE$TBE
<form action="action.cgi" $METHOD>
$MYFORM$USERPASSFORM
<INPUT TYPE=HIDDEN NAME=mode VALUE="con">
<INPUT TYPE=HIDDEN NAME=idx VALUE="$Q{idx}">
<INPUT TYPE=HIDDEN NAME=place VALUE="$Q{form}">
<BIG>●주택 건축</BIG>：지정 장소에 주택을
<INPUT TYPE=SUBMIT VALUE='건축한다'>
</FORM>
STR
}

