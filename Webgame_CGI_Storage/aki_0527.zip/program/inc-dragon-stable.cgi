# 드래곤 레이스 마굿간 메뉴 표시 2005/03/30 유래

ReadStable();
$disp.="<BIG>●드래곤 레이스：마굿간</BIG><br><br>";

if ($MYST==-1)
{
$disp.="$TB$TR$TD". GetTagImgKao("드래곤 조련사","slime3").$TD;
$disp.="<SPAN>드래곤 조련사</SPAN>：자신의 마굿간을 가지고 있지 않은 것 같다.<br>";
$disp.="마굿간을 가지면, 자신이나 타인의 드래곤을 조교할 수가 있다. ".$TRE.$TBE."<br>";
if (scalar @ST < $STmax)
	{
	FormStable();
	}
	else
	{
	$disp.="<BIG>●마굿간 설립</BIG>： 정해진 수에 이르렀기 때문에, 더 이상 설립할 수 없습니다.";
	}
}
else
{
	$disp.="$TB$TR$TDB 명칭$TDB 방침$TDB 조교$TDB 컨디션$TDB 체중$TDB 코스$TDB병룡$TDB판로$TDB더트$TDB 온천$TDB계양$TDB 성적$TDB 유지비$TDB 노후화 $TRE";
	$disp.=$TR;
	$disp.=$TD.$ST[$MYST]->{name};
	$disp.=$TD.$EMPHA[$ST[$MYST]->{emp}];
	$disp.=$TD.$VALUE[int($ST[$MYST]->{tr} /100*6)];
	$disp.=$TD.$VALUE[int($ST[$MYST]->{con} /100*6)];
	$disp.=$TD.$VALUE[int($ST[$MYST]->{wt} /100*6)];
	$disp.=$TD.$EVALUE[$ST[$MYST]->{sp}];
	$disp.=$TD.$EVALUE[$ST[$MYST]->{sr}];
	$disp.=$TD.$EVALUE[$ST[$MYST]->{ag}];
	$disp.=$TD.$EVALUE[$ST[$MYST]->{pw}];
	$disp.=$TD.$EVALUE[$ST[$MYST]->{hl}];
	$disp.=$TD.$EVALUE[$ST[$MYST]->{fl}];
	$disp.=$TD.($ST[$MYST]->{g1win} + 0)." - ".($ST[$MYST]->{g2win} + 0)." - ".($ST[$MYST]->{g3win} + 0)." - ".($ST[$MYST]->{sdwin} + 0);
	$cost=($ST[$MYST]->{sp} + $ST[$MYST]->{sr} + $ST[$MYST]->{ag} + $ST[$MYST]->{pw} + $ST[$MYST]->{hl} + $ST[$MYST]->{fl});
	$disp.=$TD.GetMoneyString($cost * $STcost);
	my $limit=$ST[$MYST]->{birth} + $STtime - $NOW_TIME;
	$disp.=$TD. "까지 ". (($limit > 0) ? GetTime2found($limit) : "불과");
	$disp.=$TRE.$TBE."<br>";
	StableDragon();
	FormLarge();
}
1;

sub FormStable
{
my $estmsg=GetMoneyString($STest);
my $costmsg=GetMoneyString($STcost);
my $formemp;
	foreach (0..$#EMPHA)
	{
	$formemp.="<OPTION VALUE=\"$_\">$EMPHA[$_]";
	}
$disp.=<<STR;
<FORM ACTION="action.cgi" $METHOD>
<INPUT TYPE=HIDDEN NAME=key VALUE="slime-s">
<INPUT TYPE=HIDDEN NAME=bk VALUE="slime">
$USERPASSFORM
<INPUT TYPE=HIDDEN NAME=mode VALUE="stedit">
<INPUT TYPE=HIDDEN NAME=code VALUE="new">
<BIG>●마굿간 설립</BIG>： <SELECT NAME=emp SIZE=1>
$formemp
</SELECT> (을)를 조교 방침으로 하는 마굿간을 <INPUT TYPE=TEXT NAME=name SIZE=20> 이라고 이름 붙여서
<INPUT TYPE=SUBMIT VALUE='설립'>
</FORM>
<br>
$TB$TR$TD
·마굿간을 설립하려면 ,자금 <b>$estmsg</b>가 걸립니다. <br>
·유지비가 최악이어도 매일<b>$costmsg</b>걸립니다. <br>
·조교 방침을 선택할 수 있습니다. 나중에 변경할 수 없습니다. <br>
·마굿간은 전체로 <b>$STmax</b>채의 상한이 있어, 모두 채우면 설립할 수 없습니다.
$TBE
STR
}

sub StableDragon
{
	$disp.="<BIG>●입구중인 용</BIG><br><br>";
	ReadDragon();
	$disp.="$TB$TR$TDB 명칭$TDB 연령$TDB 성별$TDB 컨디션$TDB 체중$TDB총상금$TDB 성적 $TRE";
	foreach(0..$#DR)
	{
	next if ($DR[$_]->{stable} != $ST[$MYST]->{no});
$disp.=$TR;
$disp.=$TD.GetTagImgDra($DR[$_]->{fm},$DR[$_]->{color}). $DR[$_]->{name};
$disp.=$TD.GetTime2found($NOW_TIME-$DR[$_]->{birth});
$disp.=$TD.$FM[$DR[$_]->{fm}];
$disp.=$TD.$EVALUE[int($DR[$_]->{con} /100*4)];
$disp.=$TD.$DR[$_]->{wt};
$disp.=$TD.($DR[$_]->{prize} + 0)."만";
$disp.=$TD.($DR[$_]->{g1win} + 0)." - ".($DR[$_]->{g2win} + 0)." - ".($DR[$_]->{g3win} + 0)." - ".($DR[$_]->{sdwin} + 0);
$disp.=$TRE;
	}
$disp.=$TBE."<br>";
}


sub FormLarge
{
my $n=int(($NOW_TIME - $ST[$MYST]->{birth})/86400/2) + 1;
if ($n < $cost)
	{
	$disp.="<BIG>●마굿간 증축</BIG>： 아직 더 이상의 증축은 할 수 없습니다";
	return;
	}
my $estmsg=GetMoneyString($STest);
my @LARGE=(
	'트랙코스 (스피드 상승)',
	'병룡시설 (승부 근성 상승)',
	'판로시설 (순발력 상승)',
	'더트트랙 (파워 상승)',
	'온천시설 (건강 상승)',
	'계양시설 (유연성 상승)'
);
my $formemp;
	foreach (0..$#LARGE)
	{
	$formemp.="<OPTION VALUE=\"$_\">$LARGE[$_]";
	}
$disp.=<<STR;
<FORM ACTION="action.cgi" $METHOD>
<INPUT TYPE=HIDDEN NAME=key VALUE="slime-s">
<INPUT TYPE=HIDDEN NAME=bk VALUE="slime">
$USERPASSFORM
<INPUT TYPE=HIDDEN NAME=mode VALUE="stedit">
<INPUT TYPE=HIDDEN NAME=code VALUE="large">
<BIG>●마굿간 증축</BIG>： <SELECT NAME=lar SIZE=1>
$formemp
</SELECT> (을)를 <INPUT TYPE=SUBMIT VALUE='증축'>
</FORM>
<br>
$TB$TR$TD
·마굿간을 증축하려면, 자금<b>$estmsg</b>가 듭니다. <br>
·증축하면 유지비가 많이 걸리게 됩니다. <br>
·예탁료의 수입보다 유지비가 웃돌면,적자가 되므로 주의해 주십시오.
$TBE
STR
}


