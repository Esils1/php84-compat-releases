# 아이템 상세 표시 2005/01/06 유래

$NOMENU=1;
Turn();
DataRead();
CheckUserPass();

$itemno=$Q{no};
$showcase=$Q{sc};
CheckItemNo($itemno);

RequireFile('inc-html-ownerinfo.cgi');

GetMarketStatus();

$disp.="<BIG>●창고</BIG><br><br>";

my $ITEM=$ITEM[$itemno];
$disp.= GetTagImgItemType($itemno,0,2).$ITEM->{name};
$disp.= GetTagImgItemType(0,$ITEM[$itemno]->{type})."<br><br>";

$disp.=$TB;
$disp.="$TR$TDB 재고 $TD$DT->{item}[$itemno-1] $ITEM->{scale}$TRE";
$disp.="$TR$TDB 표준 가격 $TD".GetMoneyString($ITEM->{price}).$TRE;
$disp.="$TR$TDB 유지비 $TD".GetMoneyString($ITEM->{cost}).$TRE;
$disp.="$TR$TDB 설명 $TD$ITEM->{info}$TRE";

unless ($ITEM->{flag}=~/s/) {	# 진열 불가
	if($ITEM->{marketprice})
	{
	$disp.="$TR$TDB 시세 $TD".GetMoneyString($ITEM->{marketprice}).$TRE;
	$disp.="$TR$TDB 최저가 $TD".GetMoneyString($ITEM->{marketpricelow}).$TRE;
	$disp.="$TR$TDB 최고가 $TD".GetMoneyString($ITEM->{marketpricehigh}).$TRE;
	}
	else
	{
	$disp.="$TR$TDB 시세$TD판매가게없음 $TRE";
	}
	$disp.="$TR$TDB수공$TD".GetMarketStatusGraph($ITEM->{uppoint})."$TRE";
}
$disp.=$TBE;

if($ITEM->{flag}=~/s/)
	{
	$disp.="<hr width=500 noshade size=1>";
	$disp.='※'.$ITEM[$itemno]->{name}.'를 판매할 수 없습니다<br>';
	}
	else
	{
	$disp.="※이 상품은 진열해도 팔리지 않습니다<br>" if ( $ITEM->{popular}==0);
	$disp.="※이 상품은 진열해도 거의 팔리지 않습니다<br>" if ( $ITEM->{popular} > 800000);
	$disp.="<hr width=500 noshade size=1>";
	RequireFile('inc-item-show.cgi');
	}

$disp.="<hr width=500 noshade size=1>";
if($ITEM->{flag}=~/t/)
	{
	$disp.='※'.$ITEM[$itemno]->{name}.'를'.(($ITEM->{flag}=~/h/)? "해고" : "파기").'할 수 없습니다<br>';
	}
	else
	{
	RequireFile('inc-item-throw.cgi');
	}

$disp.="<hr width=500 noshade size=1>";
$itemcode=GetPath($ITEM_DIR,"use",$ITEM[$itemno]->{code});
if($itemcode ne '' && -e $itemcode)
{
	my $ITEM=$ITEM[$itemno];
	@item::DT=@DT;
	$item::DT=$DT;
	@item::ITEM=@ITEM;
	$item::ITEM=$ITEM;
	RequireFile('inc-item.cgi');
	require $itemcode;
	@USE=GetUseItemList();

	if($USE[0]->{name} ne '')
	{
	foreach my $USE (@USE)
		{
	$disp.="●";
	$disp.=qq|<a href="action.cgi?key=item-m&item=$itemno&no=$USE->{no}&$USERPASSURL&bk=$Q{bk}">| if $USE->{useok};
	$disp.=($USE->{useok} || $USE->{dispok}) ? $USE->{name} : "?";
	$disp.="</a> " if $USE->{useok};
	$disp.="<br>";
		}
	}
}
OutSkin();
1;

