# 진열장 처리 2005/01/06 유래

$NOMENU=1;
$Q{er}=(($Q{bk} eq "sc")?'main':'stock');
OutError('부정한 호출입니다') if $Q{no}eq'';

Lock();
DataRead();
CheckUserPass();

$no=int($Q{no});
$itemno=int($Q{item});
$per=CheckCount($Q{per},0,1,200);
$prc=CheckCount($Q{prc},0,0,$MAX_MONEY);
$price=0;

UseTime($TIME_EDIT_SHOWCASE);

if($no<0 || $no>=$DT->{showcasecount}
|| $itemno<0 || $itemno>$MAX_ITEM
|| ($per<=0 && $prc<=0)
|| $per>200
|| $ITEM[$itemno]->{flag}=~/s/
)
{
	OutError('부정한 요구입니다');
}

$price=0;
if($itemno>0)
{
	OutError('그 아이템은 재고 없음입니다') if !$DT->{item}[$itemno-1];
	$price=$prc!=0 ? $prc : int($ITEM[$itemno]->{price} / 100 * $per);
}
$price=$MAX_MONEY if $price>$MAX_MONEY;

if($itemno && $price)
{
	$ret="선반".($no+1)."에 $ITEM[$itemno]->{name}를".GetMoneyString($price)."으로 진열했습니다.";
	PushLog(0,$DT->{id},$ret);
}
else
{
	$itemno=0;
	$price=0;
	$ret="선반".($no+1)."에의 진열을 그만두었습니다.";
	PushLog(0,$DT->{id},$ret);
}

$DT->{showcase}[$no]=$itemno;
$DT->{price}[$no]=$price;

RenewLog();
DataWrite();
DataCommitOrAbort();
UnLock();

$disp.=$TBT.$TRT.$TD.GetTagImgJob($DT->{job},$DT->{icon});
$disp.=$TD.GetMenuTag('stock',	'[창고에 간다]');
$disp.=GetMenuTag('main','[점내로 돌아간다]');
$disp.=$TRE.$TBE;
$disp.="<br>".$ret;

OutSkin();
1;

