# 점내 표시 2005/01/06 유래

ReadLetter();

# 화상 정의
my $space='<IMG class="i" SRC="'.$IMAGE_URL.'/map/dummy.png">';
my $vspace='<IMG WIDTH="64" HEIGHT="16" SRC="'.$IMAGE_URL.'/map/dummy.png">';
$gold='<IMG width="24" height="24" SRC="'.$IMAGE_URL.'/map/c-sg.png">';
$trush='<IMG class="c" SRC="'.$IMAGE_URL.'/map/c-st.png">';
my $post=GetMenuTag('letter','<acronym title="우체통"><IMG class="c" SRC="'.$IMAGE_URL.'/map/c-sp.png"></acronym>');
my $news=GetMenuTag('log','<acronym title="신문"><IMG width="24" height="26" SRC="'.$IMAGE_URL.'/map/c-sn.png"></acronym>');
my $stock=GetMenuTag('stock','<acronym title="창고"><IMG WIDTH="90" HEIGHT="42" SRC="'.$IMAGE_URL.'/map/shops.png"></acronym>');
my $dwarf=GetMenuTag('dwarf','<acronym title="드워프 택배우편"><IMG class="c" SRC="'.$IMAGE_URL.'/map/c-s11.png"></acronym>');

$image[0]='<td WIDTH="208" HEIGHT="64" style="background-image : url('.$IMAGE_URL.'/map/shop1a.png)">';
$image[1]='<td valign=bottom WIDTH="96" style="background-image : url('.$IMAGE_URL.'/map/shop2a.png)">';
$image[2]='<td HEIGHT="80" align=center valign=top style="background-image : url('.$IMAGE_URL.'/map/shop1b.png)">';
$image[3]='<td style="background-image : url('.$IMAGE_URL.'/map/shop2b.png)">';
$image[4]='<td HEIGHT="48" align=center valign=top style="background-image : url('.$IMAGE_URL.'/map/shop1c.png)">';
$image[5]='<td valign=top style="background-image : url('.$IMAGE_URL.'/map/shop2c.png)">';

$disp.="<BIG>●".$DT->{shopname}."점내</BIG><br><br>";

DevelopImage();
HelpMessage();

CharaDefine();
StyleDefine();

$disp.=<<"HTML";
<FORM ACTION="action.cgi" $METHOD>
<INPUT TYPE=HIDDEN NAME=key VALUE=user>
<INPUT TYPE=HIDDEN NAME=mode VALUE=comment>
$USERPASSFORM
<table class=t cellpadding=0 cellspacing=0>
$TRT$image[0]$image[1]$dwarf
<td rowspan=3 valign=bottom>
$post
<td rowspan=3>
HTML

OwnerInfo();

$disp.=<<"HTML";
$TRE
$TRT$image[2]$news$gold<br>$helper<br>$show$image[3]$trush
$TRE
$TRT$image[4]$chara$image[5]$stock
$TRE$TBE
</FORM>
HTML

1;


sub OwnerInfo
{
	my $tm=$NOW_TIME-$DT->{time};
	if($tm<0)
	{
		$tm=-$tm;
		$tm='행동 가능까지 나머지 '.GetTime2HMS($tm);
	}
	else
	{
		$tm=$MAX_STOCK_TIME if $tm>$MAX_STOCK_TIME;
		$tm=GetTime2HMS($tm);
	}
	my $moneymsg=GetMoneyString($DT->{money});
	my $rankmsg=GetRankMessage($DT->{rank});
	my $cleanmsg=GetCleanMessage($DT->{trush});

	$disp.=<<STR;
	<table align=center>$TR<td width=48>
STR
	$disp.=GetTagImgKao($DT->{name},$DT->{icon})."<br>";
	$disp.=$TD."<SPAN>RANK</SPAN> ".($id2idx{$DT->{id}}+1).GetTopCountImage($DT->{rankingcount}).DignityDefine($DT->{dignity},1)."<br>";
	$disp.=GetTagImgGuild($DT->{guild})."<b>".$DT->{shopname}."</b>".$TRE;
	$disp.=<<STR;
	$TR$TDB자금$TD$moneymsg$TRE
	$TR$TDB시간$TD$tm$TRE
	$TR$TDB인기$TD$rankmsg$TRE
	$TR$TDB쓰레기$TD$cleanmsg$TRE
	$TR$TDB댓글$TD<INPUT TYPE=TEXT NAME=cmt SIZE=20 VALUE="$DT->{comment}">
	<INPUT TYPE=SUBMIT VALUE="변경">$TRE$TBE
STR
}


sub StyleDefine
{
	my $ii=<<'HTML';
<Style Type="text/css">
<!--
HTML
	my $i=<<"HTML";
<Style Type="text/css">
<!--
acronym  { border-style:none;}
HTML
	$DISP{TOP} =~ s/$ii/$i/;
}

sub CharaDefine
{
$chara="";
my $i=int($NOW_TIME / 3600) % 3;
if (!$show)
	{
	$helper=TagChara("재고를 다 써버렸습니다. 죄송합니다…","0");
	if ($i == 0)
		{
		$chara=TagChara("이런, 아무것도 팔지 않는군. 곤란한데..?","1").$vspace;
		}
	elsif ($i == 1)
		{
		$chara=$vspace.TagChara("모처럼 사러 왔는데 아무것도 없네…. 어떻게 하지?","2").TagChara("어쩔 수 없군. 좀 더 기다려 볼까?","3");
		}
	else
		{
		$chara=TagChara("음 언니, 왜 여기에는 아무것도 없는거야?","4");
		}
	}
else
	{
	$helper=TagChara("어서오십시오","0");
	if ($i == 0)
		{
		$chara=$vspace.TagChara("이것도 있고 저것도 있고.. 오늘은 뭘 살까…","5");
		}
	elsif ($i == 1)
		{
		$chara=TagChara("음.., 이걸로 주세요.","6").$vspace;
		}
	elsif ($DT->{rank} < 5500)
		{
		$chara=TagChara("음, 꽤 좋은 가게로군…","7").TagChara("이 가게가 뜰것같은 기분이야 …","8").$vspace;
		}
	else
		{
		$chara=$vspace.TagChara("여기는 꽤 좋은 곳이야.","9").TagChara("그렇지. 나도 자주 오는 가게야.","10");
		}
	}
}

sub TagChara
{
	my($ii,$i)=@_;
	return qq|<acronym title="$ii"><IMG class="c" SRC="$IMAGE_URL/map/c-s$i.png"></acronym>|;
}

sub HelpMessage
{
$disp.=$TB.$TR.$TD.GetTagImgKao("도우미","help").$TD;

 if ($NeverR)
	{
$disp.=<<"HTML";
	<SPAN>도우미</SPAN>：새로운 편지가 $NeverR통 왔습니다.<br>
	우체통을 열어 보세요.
HTML
	}
	elsif ( ($NOW_TIME-$DT->{foundation}) < 3600*3 )
	{
$disp.=<<'HTML';
	<SPAN>도우미</SPAN>：처음 뵙겠습니다. 제가 가게의 도우미를 맡고 있습니다.<br>
	실례입니다만 점주님, <A HREF="action.cgi?key=library&t=1" TARGET=_blank>
	[게임의 방식]</A> 은 알고 계십니까?
HTML
	}
	elsif ($DT->{trush} > 4000000)
	{
$disp.=<<'HTML';
	<SPAN>도우미</SPAN>：점주님, 돌아오셨습니까.<br>
	가게가 더러워졌습니다. 이제 청소하는게 낫을것 같네요.
HTML
	}
	elsif (!$show)
	{
$disp.=<<'HTML';
	<SPAN>도우미</SPAN>：점주님, 물건을 다팔았습니다.<br>
	빨리 재고를 보충하든지, 다른 것을 진열장에 올립시다.
HTML
	}
	else
	{
$disp.=<<'HTML';
	<SPAN>도우미</SPAN>：점주님, 돌아오셨습니까.<br>
	가게는 현재 순조로워요.
HTML
	}
$disp.=$TRE.$TBE."<br>";
}

sub DevelopImage
{
my $i=int($DT->{money} / 5000000);
if ($i < 1)
	{
	$gold=""
	}
	else
	{
	$i=6 if $i > 6;
	$gold x= $i;
	}
$i=int(0.9 + $DT->{trush} / 1000000);
if ($i < 1)
	{
	$trush=""
	}
	elsif ($i > 3)
	{
	$i -=3;
	$i=3 if $i > 3;
	$trush = ($trush x $i)."<br>".($trush x 3);
	}
	else
	{
	$trush x= $i;
	}
$trush=GetMenuTag('sweep','<acronym title="쓰레기봉투">'.$trush.'<acronym>') if $trush;
$show="";
for(my $cnt=0; $cnt<$DT->{showcasecount}; $cnt++)
{
	my $itemno=$DT->{showcase}[$cnt];
	my $ITEM=$ITEM[$itemno];
	my $stock=$itemno ? $DT->{item}[$itemno-1]:0;
	next if !$stock;
	$show.=GetTagImgItemType($itemno)
}
}

