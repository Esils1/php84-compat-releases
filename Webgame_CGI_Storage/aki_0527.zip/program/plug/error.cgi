# error 플러그인 2004/01/20 유래

sub OverLoad
{
	print <<"HTML";
Cache-Control: no-cache, must-revalidate
Pragma: no-cache
Content-type: text/html; charset=UTF-8

<html>
<head>
<title>과부하</title>
</head>
<body>
현재 서버가 고부하 상태입니다.
죄송합니다만 당분간 액세스를 보류해 주세요.<br>
부하도 $_[0] CPUs
</body></html>
HTML
	exit;
}

sub OutError
{
	UnLock() if $LOCKED;
	CoUnLock() if $COLOCKED;
	my %msg=
	(
		"not defined function"=>
			'정의되어 있지 않은 함수를 호출했습니다.관리자에게 이하의 정보를 연락해 주세요.<hr>'.
			"not defined function '$_[1]'",
		"busy"=>
			'액세스가<SPAN>혼잡</SPAN>해있습니다.<br>'.
			'수고스럽겠지만<SPAN>반드시 5초 이상 기다리고 나서</SPAN>돌아와 한번 더 액세스 해 주세요.<br>'.
			($AUTO_UNLOCK_TIME*2).'초이상 지나도 접속할 수 없는 경우는'.
			'<a href="mailto:'.$ADMIN_EMAIL.'">관리자에게 연락</a>해 주십시오.',
		"no data"=>
			'<SPAN>데이터가 발견되지 않았습니다</SPAN>수고스럽겠지만 돌아와 다시 해 주세요.'.
			'이 메시지가 계속 되는 경우는<a href="mailto:'.$ADMIN_EMAIL.'">관리자에게 연락</a>해 주십시오.',
		"stop"=>
			'이 가게는<SPAN>휴가중</SPAN>입니다.'.
			'플레이를 재개할 때는<a href="mailto:'.$ADMIN_EMAIL.'">관리자에게 연락</a>해 주십시오.',
		"no user"=>
			'존재하지 않는 ID입니다.ID를 확인해 주십시오.→'.$_[1],
		"incorrect"=>
			'비밀번호가 잘못되어 있습니다.확인해 주십시오→'.$_[1],
		"error rename"=>
			'데이터 갱신에 실패했습니다',
		"timeout"=>
			'로그인으로부터 장시간이 경과했기 때문에<SPAN>타임 아웃</SPAN>했습니다.<br>수고스럽겠지만 한번 더 톱으로부터 다시 로그인해 주세요.',
		"bad request"=>
			'<SPAN>부정한 호출</SPAN>입니다.브라우저의 「돌아오는/진행된다」를 사용하고 있는 경우는 사용하지 않게 해 주세요.',
	);
	my $msg=defined $msg{$_[0]} ? $msg{$_[0]} : $_[0];
	$NOMENU=0;$Q{bk}="";
	$disp=<<"HTML";
	<BIG>에러 리포트</BIG><br><br>
	$msg
HTML
	OutSkin();
	exit;
}

sub WriteErrorLog
{
	eval(<<'__function__');
	my($msg,$file)=@_;
	
	return if !$LOG_SIZE_MAX || $file eq '';
	
	my $fn=GetPath($LOG_DIR,$file);
	rename($fn,GetPath($LOG_DIR,$file."-old")) if (stat($fn))[7]>$LOG_SIZE_MAX;
	open(ERR,">>$fn") or return;
	print ERR
		join("\t",
			(
				$NOW_TIME,
				$ENV{SCRIPT_NAME},
				$ENV{REMOTE_ADDR},
				$ENV{REMOTE_HOST},
				GetTrueIP(),
				$USER,
				$msg,
			)
		)."\n";
	close(ERR);
__function__
}

sub OutErrorBlockLogin
{
	OutError('
		지정의 ID는<SPAN>'.$_[0].'</SPAN>때문에 액세스 제한되고 있습니다.<br>
		플레이중의 「가명」 「사용자명」 「가게명」을 더해<a href="mailto:'.$ADMIN_EMAIL.'">관리자에게 연락</a>해 주십시오.
	');
}
1;
