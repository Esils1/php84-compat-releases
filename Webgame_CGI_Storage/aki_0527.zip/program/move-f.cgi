# 이전 폼 2005/01/06 유래

OutError('사용 불가입니다') if !$MOVETOWN_ENABLE || !$TOWN_CODE;
my $townmaster=ReadTown($TOWN_CODE,'getown');
OutError('사용 불가입니다') if !$townmaster;

DataRead();
CheckUserPass();

OutError('이전 가능한 거리가 발견되지 않습니다') if !$Q{towncode};
$disp.=GetMoveShopForm($Q{towncode});
OutSkin();
1;

sub GetMoveShopForm
{
	my($towncode)=@_;
	
	my($town) =ReadTown($towncode);
	return '<b>이전 가능한 거리가 발견되지 않습니다</b>' if !$town;
	
	my $disp="";
	
	my $dist=GetTownDistance($townmaster->{position},$town->{position});
	my $movetime=GetMoveTownTime($DT,$townmaster,$town);
	
	$disp.=$TB;
	$disp.="$TR$TDB 이전처 $TD$town->{name}$TRE";
	$disp.="$TR$TDB 댓글 $TD$town->{comment}$TRE";
	$disp.="$TR$TDB 거리 $TD".($dist*80)."m$TRE";
	$disp.="$TR$TDB 이동 시간 $TD".GetTime2HMS($movetime).' (예정)'.$TRE;
	$deny=0;
	
	sub GetMarkDeny
	{
		$deny=1,return " ←조건을 채우고 있지 않습니다" if ($_[0]);
		return "";
	}
	my @flag=();
	push(@flag,"이전의 이전으로부터 10 일 이상".GetMarkDeny($NOW_TIME-GetUserDataEx($DT,'_so_move_in')<864000));	#추가
	push(@flag,"자금 ".GetMoneyString($town->{allowmoney})." 이상".GetMarkDeny($town->{allowmoney}>$DT->{money}+$DT->{moneystock})) if $town->{allowmoney} ne '';
	push(@flag,"자금 ".GetMoneyString($town->{denymoney})." 이하".GetMarkDeny($town->{denymoney}<$DT->{money}+$DT->{moneystock}))  if $town->{denymoney} ne '';
	push(@flag,"길드 ".join("/",map{GetTagImgGuild($_,1,1)}split(/\W/,$town->{allowguild})).($town->{onlyguild} ? '':' 및 길드 무소속')." 마셔".GetMarkDeny($DT->{guild} ne '' && !scalar(grep($_ eq $DT->{guild},split(/[^\w]+/,$town->{allowguild}))))) if $town->{allowguild} ne '';
	push(@flag,"길드 ".join("/",map{GetTagImgGuild($_,1,1)}split(/\W/,$town->{denyguild})).($town->{onlyguild} ? ' 및 길드 무소속':'')." 이외".GetMarkDeny($DT->{guild} ne '' && scalar(grep($_ eq $DT->{guild},split(/[^\w]+/,$town->{denyguild}))))) if $town->{denyguild} ne '';
	push(@flag,"상위 획득 회수 $town->{allowtopcount} 회이상".GetMarkDeny($town->{allowtopcount}>$DT->{rankingcount})) if $town->{allowtopcount} ne '';
	push(@flag,"상위 획득 회수 $town->{denytopcount} 회이하".GetMarkDeny($town->{denytopcount}<$DT->{rankingcount}))  if $town->{denytopcount} ne '';
	push(@flag,"개업 기간 ".GetTime2HMS($town->{allowfoundation})." 이상".GetMarkDeny($town->{allowfoundation}>$NOW_TIME-$DT->{foundation})) if $town->{allowfoundation} ne '';
	push(@flag,"개업 기간 ".GetTime2HMS($town->{denyfoundation})." 이하".GetMarkDeny($town->{denyfoundation}<$NOW_TIME-$DT->{foundation}))  if $town->{denyfoundation} ne '';
	push(@flag,"길드 소속만 ".GetMarkDeny($DT->{guild} eq '')) if $town->{onlyguild} ne '';
	push(@flag,"길드 무소속만 ".GetMarkDeny($DT->{guild} ne '')) if $town->{noguild} ne '';
	push(@flag,"직업 ".join("/",map{$JOBTYPE{$_}}split(/\W+/,$town->{allowjob})).($town->{onlyjob} ? '':' 및 직업 부정')." 마셔".GetMarkDeny($DT->{job} ne '' && !scalar(grep($_ eq $DT->{job},split(/\W+/,$town->{allowjob}))))) if $town->{allowjob} ne '';
	push(@flag,"직업 ".join("/",map{$JOBTYPE{$_}}split(/\W+/,$town->{denyjob})).($town->{onlyjob} ? ' 및 직업 부정':'')." 이외".GetMarkDeny($DT->{job} ne '' && scalar(grep($_ eq $DT->{job},split(/\W+/,$town->{denyjob}))))) if $town->{denyjob} ne '';
	push(@flag,"직업 가게만 ".GetMarkDeny($DT->{job} eq '')) if $town->{onlyjob} ne '';
	push(@flag,"직업 부정 가게만 ".GetMarkDeny($DT->{job} ne '')) if $town->{nojob} ne '';
	$disp.="$TR$TDB 이전 조건$TD·".join("<br>·",@flag)."$TRE" if scalar(@flag);
	$disp.=$TBE;
	
	return $disp if $deny;
	$disp.=<<"HTML";
		<hr width=500 noshade size=1>
		<form action="action.cgi" $METHOD>
		<input type=hidden name=key value="move-s">
		$USERPASSFORM
		<input type=hidden name=towncode value="$towncode">
		$TB$TR
		$TDB 이전처에서의 이름(ID) $TD<input type=text name=name value="$DT->{name}">(반각 전각 OK) $TRE
		$TR$TDB 현재의 비밀번호 $TD<input type=password name=pass value="">$TRE$TBE
		<br><input type=submit value="이전 수속 개시">
		</form>
		<hr width=500 noshade size=1>
		<table><tr><td>이전으로 인계되지 않는 데이터는 아래와 같은 대로입니다.그 이외는 거의 그대로 인계됩니다.
		<ul>
		<li>전기의 순위 정보
		<li>도착해 있던 편지(모두 파기)
		</ul>
		이하의 경우는 이전때 가게 데이터가 일부 없어집니다.
		<ul>
		<li>시스템 개조등으로 가게 데이터에 호환성이 없는 경우
		</ul>
		이하의 경우는 이전할 수 없습니다.
		<ul>
		<li>이전처가 만원의 경우
		<li>이전처에 같은 이름(ID)이나 가게명이 있는 경우
		</ul></td></tr></table>
HTML
	return $disp;
}


