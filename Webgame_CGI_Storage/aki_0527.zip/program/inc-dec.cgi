# 특수 디코드 2003/09/25 유래

OutError("송신 사이즈가 너무 큽니다") if ($ENV{'CONTENT_LENGTH'} > 10240);

binmode(STDIN);
my $Boundary = <STDIN>;
$Boundary =~ s/\x0D\x0A//;
while (<STDIN>) {
	if (/^\s*Content-Disposition:/i) {
		my $Name;
		# 폼의 항목명을 얻는다
		if (/\bname="([^"]+)"/i or /\bname=([^\s:;]+) /i) {
			$Name = $1;
		}
		# 파일명을 취득
		if (/\bfilename="([^"]*)"/i or /\bfilename=([^\s:;]*) /i) {
			$FILENAME{$Name} = $1 || 'unknown';
		}
		# 헤더 내용을 읽어낸다
		# 헤더의 종료를 나타내는 공행을 검출하면 루프를 빠진다
		while (<STDIN>) {
			last if (not /\w/);
			if (
				/^\s*Content-Type:\s*"([^"]+)"/i
				or /^\s*Content-Type:\s*([^\s:;]+) /i
			) {
			$MIMETYPE{$Name} = $1;
			}
		}
		# 데이터 본체를 읽어낸다
		# 데이터의 종료를 나타내는 Boundary를 검출하면 루프를 빠진다
		while (<STDIN>) {
			last if (/^\Q$Boundary\E/);
			$Q{$Name} .= $_;
		}
		$Q{$Name} =~s /\x0D\x0A$//; # 말미의\r\n를 없앤다
		if ($Q{$Name}) {
			# 파일의 경우
			if ($FILENAME{$Name} or $MIMETYPE{$Name}) {
				# MacBinary를 검출해 삭제
				if (
					$MIMETYPE{$Name}
					=~ /^application\/(x-)?macbinary$/i
				) {
				# Header와 말미의 리소스를 삭제
					$Q{$Name} = substr(
						$Q{$Name},
						128,
						unpack("N",substr($Q{$Name},83,4))
					);
				}
			}
			# 파일 이외의 경우
			else {
				$Q{$Name} =~ s/&/&amp;/g;
				$Q{$Name} =~ s/"/&quot;/g;
				$Q{$Name} =~ s/</&lt;/g;
				$Q{$Name} =~ s/>/&gt;/g;
				$Q{$Name} =~ s/\x0D\x0A/<br>/g;
				$Q{$Name} =~ s/\x0D/<br>/g;
				$Q{$Name} =~ s/\x0A/<br>/g;
			}
		}
	}
	# Boundary를 검출하면 루프를 빠진다
	last if (/^\Q$Boundary--\E/);
}
	@Q{qw(nm pw ss)}=split(/!/,$Q{u},3) if exists $Q{u};
1;

