# 드래곤 레이스 설정 2005/03/30 유래

# -------- 설정 부분 ---------

# 레이스 설정
@WEATHER=('맑음','비');
@RACERANK=('G1','G2','G3','OP','100하','미승리');
@FIELDTYPE=('잔디','더트');

@RACETERM=("신룡경주","대상경주");

@RACE=(
	# 0 명칭		1 랭크	2 핸디캡	3 바바종	4 종반비탈	5 거리	6 1벌	7 2벌	8 3벌 9 정원
	[
	['약엽 신룡'	,5	,0	,0	,1	,1600	,50	,30	,20	,10],
	['카사블랑카 배',4	,20	,0	,0	,1600	,100	,50	,30	,10],
	['카사블랑카 더트배',4,20	,1	,1	,1600	,100	,50	,30	,10],
	['미승리 2600 더트',5	,0	,1	,0	,2600	,50	,30	,20	,10],
	['수국화 컵',3	,50	,0	,0	,2800	,150	,70	,50	,10],
	['수국화 더트컵',3,50	,1	,0	,2800	,150	,70	,50	,10],
	['채화 신룡'	,5	,0	,0	,0	,2200	,50	,30	,20	,10],
	['단풍나무 배'	,4	,20	,0	,0	,2000	,100	,50	,30	,10],
	['단풍나무 더트배',4	,20	,1	,1	,2000	,100	,50	,30	,10],
	['미승리 1600 더트',5	,0	,1	,1	,1600	,50	,30	,20	,10],
	['승부 컵',3	,50	,0	,1	,1400	,150	,70	,50	,10],
	['승부 더트컵',3	,50	,1	,0	,1400	,150	,70	,50	,10],
	],
	[
	['술집 배 핸디캡'	,2	,100	,0	,0	,2600	,200	,100	,80	,10],
	['수화 상'	,2	,100	,1	,0	,2200	,200	,100	,80	,10],
	['초승달 배'	,2	,100	,0	,0	,1600	,200	,100	,80	,10],
	['창천 배'	,2	,100	,0	,0	,2000	,200	,100	,80	,10],
	['영주 챌린지 컵',1,200	,0	,1	,2800	,300	,150	,100	,10],
	['복숭아꽃 상'	,1	,200	,1	,0	,2200	,300	,150	,100	,10],
	['명월 트라이얼 컵',1,200	,0	,0	,1400	,300	,150	,100	,10],
	['황천 트라이얼 컵',1,200	,0	,1	,2000	,300	,150	,100	,10],
	['신천년 국왕상'	,0	,0	,0	,0	,3000	,400	,200	,100	,10],
	['봄꽃 상'	,0	,0	,1	,1	,2400	,400	,200	,100	,10],
	['가을달 상'	,0	,0	,0	,1	,1600	,400	,200	,100	,10],
	['천둥 상'	,0	,0	,0	,0	,2000	,400	,200	,100	,10],
	],
);

# 목장
$RCest=1000000;

# 경쟁 드래곤
$MYDRmax=3;
$DRbuy=500000;

# 은퇴
$DRretire=86400 * 10;
$PRentry=300;
$PRcycle=86400 * 3;

# 마굿간
$STest=500000;
$STcost=100000;
$STmax=10;
$STtime=86400 * 50;

# 기수
$JKest=500000;
$JKmax=20;
$JKtime=86400 * 50;

# 기수 능력
@JKSP=(
	'없음',
	'빈룡 승마에 능한',
	'모룡 승마에 능한',
	'잔디 레이스에 강한',
	'더트 레이스에 강한',
	'대무대에 강한',
	'비의 레이스에 강한',
	'승리하면 용의 성장을 촉진하는',
);

# 용어의 정의

@STRATE=('도주','선행','선입','추입','자유');

@EMPHA=('스피드','승부 근성','순발력','파워','건강','유연성');

@VALUE=('E','D','C','B','A','S','S');

@EVALUE=('×','△','○','◎','◎');

@FM=('모','빈');

@ONRACE=('대기','<b>낙선</b>','<SPAN>등록</SPAN>','<SPAN>출주</SPAN>');

@DRCOLOR=('홍색 모','청색 모','녹색 모','빛나는 모','옻색 모');

# 갱신 시각 (조교시각 등룡출주합계 중상출주합계)

@DRTIMESET=(3,23,22);

# -------- 설정 완료 ---------

@DLOG=();

@DRnamelist=qw(
		no birth fm color name town owner stable race apt
		sp spp sr srp ag agp pw pwp hl hlp fl flp
		con wt gr
		prize sdwin g3win g2win g1win
		);

@PRnamelist=qw(
		no birth fm color name town owner apt hr preg
		sp sr ag pw hl fl
		prize sdwin g3win g2win g1win
		);

@RCnamelist=qw(
		no birth name town owner
		prize sdwin g3win g2win g1win
		);

@STnamelist=qw(
		no birth name town owner
		emp tr con wt
		sp sr ag pw hl fl
		sdwin g3win g2win g1win
		);

@JKnamelist=qw(
		no birth name town owner race
		ahead back sp
		sdwin g3win g2win g1win
		);

@RDnamelist=qw(
		no dr birth fm color name ranch rcname stable stname jock jkname prize strate
		sp1 sp2 sp3 sp4
		pop time str lose
		);
1;

sub GetTagImgDra
{
	my($i,$ii,$old)=@_;
	$i++;
	$ii++;
	$i+=2 if $old;
	return qq|<IMG class="i" SRC="$IMAGE_URL/dragon$i$ii$IMAGE_EXT">|;
}

