그러면 <b>봄꽃 상</b>의 출주입니다<br>
영관을 손에 넣는 것은 과연 어느 용이 될 것인가<br>
이 코스의 종반은 비탈이 있습니다. 제 1의 변수가 있을지도 모릅니다<br>
이제 시작입니다<br>
선두에 있는 용은 <b><IMG class="i" SRC="./image/dragon15.png">삼번용</b><br>
대부분이 예상한 일입니까<br>
현재 2번째로 달리고 있는 것은 2화 <b><IMG class="i" SRC="./image/dragon21.png">이번용</b><br>
3지켜 보는 사람의 기대를 접수. 이 정도의 사람이 승리를 원합니다<br>
최초의 코너를 돌았습니다<br>
현재 선두는 변함없이 <b><IMG class="i" SRC="./image/dragon15.png">삼번용</b><br>
이 기세는 끝까지 계속될 것인가<br>
중간 1200km의 통과 타임은 16.42<br>
거의 평상대로라고 할 수 있겠지요. 전개에 그다지 영향은 없을 것 같습니다<br>
<b><IMG class="i" SRC="./image/dragon21.png">이번용</b> 좋은 위치에요 여기부터 선두를 노리는 것인가<br>
후속룡이 차이를 좁혀갑니다<br>
자 과연...</b> 선두는 변함없이 <b><IMG class="i" SRC="./image/dragon15.png">삼번용</b><br>
이대로 잘 도주할 수 있을 것인가뒤를 쫓는 것은 <b><IMG class="i" SRC="./image/dragon21.png">이번용</b><br>
<b><IMG class="i" SRC="./image/dragon11.png">일번용</b> 좋은 페이스지만...<br>
마지막 코너를 돌아 직선에 들어갑니다<br>
자 과연 <IMG class="i" SRC="./image/dragon21.png"><b>이번용</b>가 추입을 시도합니다<br>
<IMG class="i" SRC="./image/dragon15.png"><b>삼번용</b>가 도주합니다 이대로 잘 도주할 것인가<br>
<IMG class="i" SRC="./image/dragon15.png"><b>삼번용</b> 차이를 벌였습니다!<br>
<IMG class="i" SRC="./image/dragon15.png"><b>삼번용</b>! 이 용은 강합니다! 이긴 용은 <IMG class="i" SRC="./image/dragon15.png"><b>삼번용</b>!<br>
<br>1착 34.35 선행 <IMG class="i" SRC="./image/dragon15.png">삼번용<br>2착 36.19 선행 <IMG class="i" SRC="./image/dragon21.png">이번용 <small>(작전 미스)</small><br>3착 36.42 선행 <IMG class="i" SRC="./image/dragon11.png">일번용 <small>(거리가 너무 길어)</small><br>