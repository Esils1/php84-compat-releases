@OtherDir=("akimono");
$Tname{akimono}="기본 마을";
