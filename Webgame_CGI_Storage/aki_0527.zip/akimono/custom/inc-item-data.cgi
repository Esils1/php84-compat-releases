# 표준판 아이템 데이터 2005/01/06 유래

# 이 파일은 아이템 데이터의 정의 파일입니다.
# 원하는 대로 사용자 지정 할 수 있습니다.자세한 것은 매뉴얼을 봐 주세요.

@@DEFINE
	version	05-01-06(SD)		#★상품 데이터 버전 표기
					# 마지막 「SD」는 표준판인 것을 나타냅니다.
					# 만약 당신이 독자 아이템을 눈으로 한 상인 이야기를 만든다면,
					# 이 기호를 바꾸는 것이 좋을 것입니다.

	scale	개			#★기본의 계산 단위
	type0	전			#전체 아이템의 집합
	type1	원료
	type2	책
	type3	약
	type4	검
	type5	갑옷
	type6	방패
	type7	지팡이
	type8	악세사리
	type9	지도
	type10	도구
	
	job	drug		약국		#★직업 코드는 영소문자 10 문자 이내
	job	tool		잡화상
	job	weapon		무기가게
	job	armor		방어구가게
	job	material	산인
	job	book		책방
	job	cow		낙농가
	job	peddle		행상인
	
	# 직업별 시간 단축용 변수 설정
	set job_drug_time_rate		1.5	#★직업에 붙어 있으면(자) 1.5배 빨리 된다
	set job_tool_time_rate		1.5
	set job_weapon_time_rate	1.5
	set job_armor_time_rate		1.5
	set job_material_time_rate	1.5
	set job_book_time_rate		1.5
	set job_cow_time_rate		1.5
	set job_peddle_time_rate	1.5

	MaxMoney	999999999	#★최대 자금
	
	set NewShopMoney	100000					#초기 자금 (@@FUNCNEW에서 사용)
	set NewShopTime		12*60*60				#초기 제한 시간(초) (@@FUNCNEW에서 사용)
	set NewShopItem		진열장&nbsp;증축취괴킷:1:상품권:5	#초기 소지 상품 (@@FUNCNEW에서 사용) 서식 상품명:개수:상품명:개수:...
	
	TimeEditShowcase	10m		#★진열장 조작 시간
	TimeShopping		20m		#★구입 시간( 구SOLD OUT와의 호환성 확보.지금은 사용하지 않고)
	TimeSendItem		20m		#★아이템 구입/이동 시간(기본)
	TimeSendItemPlus	20s		#★아이템 구입/이동 시간(1개 근처의 추가 시간)
	TimeSendMoney		20m		#★자금 이동 시간(기본)
	TimeSendMoneyPlus	100000		#★쓰레기 처리 시간 계산 공금액(이 금액에 대해 TimeSendMoney 시간을 소비)
	
	CostShowcase1		0		#★진열장 1개시 유지비
	CostShowcase2		2000	#진열장 2개시 유지비
	CostShowcase3		4000	#진열장 3개시 유지비
	CostShowcase4		8000	#진열장 4개시 유지비
	CostShowcase5		16000	#진열장 5개시 유지비
	CostShowcase6		32000	#진열장 6개시 유지비
	CostShowcase7		64000	#진열장 7개시 유지비
	CostShowcase8		128000	#진열장 8개시 유지비
	
	ItemUseTimeRate		0.5		#★아이템 사용시 시간 계산 보정 배율(@USE내 time,exptime에 유효)
	

#------ 여기로부터 아이템 정의 ---------------------------------


@@ITEM					#★아이템 데이터 정의 선언
	no		10		#★아이템 번호(중복 하지 않게)
	type	도구			#★아이템 분류(@@DEFINE의 type?의 정의를 사용)
	code	book-make		#★코드(중복 하지 않게)
	name	책&nbsp;집필&nbsp;킷			#★명칭(중복 하지 않게)
	info	책을 집필하기 위한 기본 킷	#★설명
	price	5000				#★표준 가격
	cost	100
	limit	20/10
	pop	20d			#★매출율 기준(20일에 1개 팔리는 확률)
	scale	세트			#★계산 단위
	plus	20m			#★시장 입하율(20분에 1개 입하하는 확률)
	@@USE				#★아이템 사용 데이터 정의 선언
		time	3h
		exp	2%
		exptime	1h
		job		책방	times/job_book_time_rate
		scale	회
		action	쓴다
		name	「약조제 입문」을 집필한다
		info	약을 만드는 방법을 공부해, 책으로 하려고 생각합니다
		okmsg	「약조제 입문」을 집필했습니다
		ngmsg	집필에 실패했습니다…
			use		1	책&nbsp;집필&nbsp;킷
			use		30	약초
			use		10	포션
			use		10	에테르
			get		5	약조제&nbsp;입문	40%
	@@USE
		time	3h
		exp	2%
		exptime	1h
		name	「가죽 세공 입문」을 집필한다
		info	혁세공을 만드는 방법을 공부해, 책으로 하려고 생각합니다
		okmsg	「가죽 세공 입문」을 집필했습니다
		ngmsg	집필에 실패했습니다…
			use		1	책&nbsp;집필&nbsp;킷
			use		50	짐승의&nbsp;가죽
			get		5	가죽&nbsp;세공&nbsp;입문	40%
	@@USE
		time	3h
		exp	2%
		exptime	1h
		name	「목세공 입문」을 집필한다
		info	목공을 만드는 방법을 공부해, 책으로 하려고 생각합니다
		okmsg	「목세공 입문」을 집필했습니다
		ngmsg	집필에 실패했습니다…
			use		1	책&nbsp;집필&nbsp;킷
			use		50	나뭇가지
			use		10	통나무
			get		5	목세공&nbsp;입문	40%
	@@USE
		time	6h
		exp	2%
		exptime	2h
		name	「장식&nbsp;세공&nbsp;입문」을 집필한다
		info	장식 세공의 기술을 공부해, 책으로 하려고 생각합니다
		okmsg	「장식&nbsp;세공&nbsp;입문」을 집필했습니다
		ngmsg	집필에 실패했습니다…
			use		1	책&nbsp;집필&nbsp;킷
			need		1	가죽&nbsp;세공&nbsp;입문
			need		1	목세공&nbsp;입문
			use		20	철괴
			use		5	미스릴덩어리
			use		5	오리하르콘덩어리
			get		5	장식&nbsp;세공&nbsp;입문	40%
	@@USE
		time	6h
		exp	2%
		exptime	2h
		name	「검&nbsp;단련법」을 집필한다
		info	검&nbsp;단련법을 공부해, 책으로 하려고 생각합니다
		okmsg	「검&nbsp;단련법」을 집필했습니다
		ngmsg	집필에 실패했습니다…
			needexp	20%
			need		1	대장간의&nbsp;기술
			use		1	책&nbsp;집필&nbsp;킷
			use		20	철괴
			use		1	목검
			get		5	검&nbsp;단련법	40%
	@@USE
		time	6h
		exp	2%
		exptime	2h
		name	「방패&nbsp;제조법」을 집필한다
		info	방패의 구조를 공부해, 책으로 하려고 생각합니다
		okmsg	「방패&nbsp;제조법」을 집필했습니다
		ngmsg	집필에 실패했습니다…
			needexp	20%
			use		1	책&nbsp;집필&nbsp;킷
			need		1	대장간의&nbsp;기술
			use		20	철괴
			use		1	가죽방패
			get		5	방패&nbsp;제조법	40%
	@@USE
		time	6h
		exp	2%
		exptime	2h
		name	「갑옷&nbsp;제조법」을 집필한다
		info	갑옷의 구조를 공부해, 책으로 하려고 생각합니다
		okmsg	「갑옷&nbsp;제조법」을 집필했습니다
		ngmsg	집필에 실패했습니다…
			needexp	20%
			need		1	대장간의&nbsp;기술
			use		1	책&nbsp;집필&nbsp;킷
			use		20	철괴
			use		1	가죽흉갑
			get		5	갑옷&nbsp;제조법	40%
	@@USE
		time	6h
		exp	2%
		exptime	2h
		name	「지팡이&nbsp;제조법」을 집필한다
		info	지팡이의 구조를 공부해, 책으로 하려고 생각합니다
		okmsg	「지팡이&nbsp;제조법」을 집필했습니다
		ngmsg	집필에 실패했습니다…
			needexp	20%
			need		1	마법의&nbsp;지식
			use		1	책&nbsp;집필&nbsp;킷
			use		20	철괴
			use		1	나무지팡이
			get		5	지팡이&nbsp;제조법	40%

@@ITEM
	no		37
	type	도구
	code	book-syugyou
	name	수행&nbsp;킷
	info	여러가지 수행을하기 위한 킷
	price	5000
	cost	500
	limit	1/1
	pop	0
	scale	세트
	plus	1d
	flag	noshowcase|norequest
	@@USE
		time	12h
		exp		5%
		scale	수행
		action	수행한다
		name	대장간&nbsp;입문
		info	대장간의&nbsp;기술을 공부해,몸에 익히려고 생각합니다
		okmsg	대장간의&nbsp;기술을 몸에 익혔습니다
			use		1	수행&nbsp;킷
			use		20	철괴
			use		5	미스릴덩어리
			use		3	오리하르콘덩어리
			get		1	대장간의&nbsp;기술
	@@USE
		time	12h
		exp		5%
		scale	공부
		action	수행한다
		name	마법 기초 강좌
		info	마법의 기초에 대해 공부해,몸에 익히려고 생각합니다
		okmsg	마법 기초를 주입당했습니다
			use		1	수행&nbsp;킷
			use		30	마석
			get		1	마법의&nbsp;지식
	@@USE
		time	12h
		exp		5%
		scale	개안
		action	개안한다
		name	차이를 알 수 있는 남자(여자)가 된다
		info	상품의 차이를 지켜봐 물건을 보는 눈을 기르려고 생각합니다
		okmsg	차이를 알 수 있는 남자(여자)가 된 것 같다
			needexp	20%
			use		1	수행&nbsp;킷
			use		3	약초
			use		3	짐승의&nbsp;가죽
			use		3	나뭇가지
			use		3	통나무
			use		3	철괴
			use		3	미스릴덩어리
			use		3	오리하르콘덩어리
			use		3	마석
			get		1	감정의&nbsp;진수
	@@USE
		time	12h
		exp		5%
		scale	수행
		action	수행한다
		name	해체의 비법을 배워 본다
		info	분해하는 것에 생명을 걸어 보지 않겠습니까?
		okmsg	뭐든지 해체할 수 있을 것 같은 걸
			use		1	수행&nbsp;킷
			use		20	가죽흉갑
			use		20	가죽방패
			use		20	나무지팡이
			use		20	목검
			get		1	해체가게의&nbsp;영혼

@@ITEM
	no		39
	type	도구
	code	book-kaitai
	name	해체/곤포&nbsp;킷
	info	해체나 곤포 작업에 필요한 킷
	price	500
	limit	10/3
	pop		2d
	scale	세트
	plus	5h
	@@USE
		name	목검/나무지팡이를 해체한다
		time	4h
		exptime	2h
		exp		1%
		job		무기가게	times/job_weapon_time_rate
		use		1	해체/곤포&nbsp;킷
		need	1	해체가게의&nbsp;영혼
		use		10	목검
		use		10	나무지팡이
		get		50	나뭇가지	80%
	@@USE
		name	가죽방패/흉갑을 해체한다
		time	4h
		exptime	2h
		exp		1%
		job		방어구가게	times/job_armor_time_rate
		use		1	해체/곤포&nbsp;킷
		need	1	해체가게의&nbsp;영혼
		use		10	가죽방패
		use		10	가죽흉갑
		get		50	짐승의&nbsp;가죽	80%
	@@USE
		name	나무방패/흉갑을 해체한다
		time	4h
		exptime	2h
		exp		1%
		job		방어구가게	times/job_armor_time_rate
		use		1	해체/곤포&nbsp;킷
		need	1	해체가게의&nbsp;영혼
		use		10	나무방패
		use		10	나무흉갑
		get		50	나뭇가지	80%
	@@USE
		name	철검/지팡이을 해체한다
		time	4h
		exptime	3h
		exp		1%
		job		무기가게	times/job_weapon_time_rate
		use		1	해체/곤포&nbsp;킷
		need	1	해체가게의&nbsp;영혼
		use		10	철검
		use		10	철지팡이
		get		50	철괴	80%
		get		10	마석	50%
	@@USE
		name	철방패/갑옷를 해체한다
		time	4h
		exptime	3h
		exp		1%
		job		방어구가게	times/job_armor_time_rate
		use		1	해체/곤포&nbsp;킷
		need	1	해체가게의&nbsp;영혼
		use		10	철방패
		use		10	철갑옷
		get		50	철괴	80%
	@@USE
		name	강철검/지팡이을 해체한다
		time	5h
		exptime	3.5h
		exp		1%
		job		무기가게	times/job_weapon_time_rate
		use		1	해체/곤포&nbsp;킷
		need	1	해체가게의&nbsp;영혼
		use		10	강철검
		use		10	강철지팡이
		get		100	철괴	80%
		get		10	마석	50%
	@@USE
		name	강철방패/갑옷를 해체한다
		time	5h
		exptime	3.5h
		exp		1%
		job		방어구가게	times/job_armor_time_rate
		use		1	해체/곤포&nbsp;킷
		need	1	해체가게의&nbsp;영혼
		use		10	강철방패
		use		10	강철갑옷
		get		100	철괴	80%
	@@USE
		name	미스릴검/지팡이을 해체한다
		time	6h
		exptime	4h
		exp		1%
		job		무기가게	times/job_weapon_time_rate
		use		1	해체/곤포&nbsp;킷
		need	1	해체가게의&nbsp;영혼
		use		10	미스릴검
		use		10	미스릴지팡이
		get		50	미스릴덩어리	70%
		get		20	마석	50%
	@@USE
		name	미스릴방패/갑옷를 해체한다
		time	6h
		exptime	4h
		exp		1%
		job		방어구가게	times/job_armor_time_rate
		use		1	해체/곤포&nbsp;킷
		need	1	해체가게의&nbsp;영혼
		use		10	미스릴방패
		use		10	미스릴갑옷
		get		50	미스릴덩어리	70%
	@@USE
		name	오리하르콘검/지팡이을 해체한다
		time	7h
		exptime	5h
		exp		1%
		job		무기가게	times/job_weapon_time_rate
		use		1	해체/곤포&nbsp;킷
		need	1	해체가게의&nbsp;영혼
		use		10	오리하르콘검
		use		10	오리하르콘지팡이
		get		50	오리하르콘덩어리	60%
		get		30	마석	50%
	@@USE
		name	오리하르콘방패/갑옷를 해체한다
		time	7h
		exptime	5h
		exp		1%
		job		방어구가게	times/job_armor_time_rate
		use		1	해체/곤포&nbsp;킷
		need	1	해체가게의&nbsp;영혼
		use		10	오리하르콘방패
		use		10	오리하르콘갑옷
		get		50	오리하르콘덩어리	60%
	@@USE
		name	로보트를 해체한다
		time	12h
		use		1	해체/곤포&nbsp;킷
		need	1	해체가게의&nbsp;영혼
		use		1	가게&nbsp;보는&nbsp;인형로봇
		get		300	철괴
		get		50	미스릴덩어리
		get		10	오리하르콘덩어리
		get		30	마석
		get		1	금단의&nbsp;책
		get		1	통나무
	@@USE
		name	가죽제&nbsp;장비&nbsp;모음을 꾸린다
		time	4h
		exptime	2h
		exp		1%
		job		잡화상	times/job_tool_time_rate
		use		1	해체/곤포&nbsp;킷
		use		10	가죽방패
		use		10	가죽흉갑
		get		10	가죽제&nbsp;장비&nbsp;모음
	@@USE
		name	목제&nbsp;장비&nbsp;모음을 꾸린다
		time	5h
		exptime	3h
		exp		1%
		job		잡화상	times/job_tool_time_rate
		use		1	해체/곤포&nbsp;킷
		use		10	목검
		use		10	나무방패
		use		10	나무흉갑
		use		10	나무지팡이
		get		10	목제&nbsp;장비&nbsp;모음
	@@USE
		name	철제&nbsp;장비&nbsp;모음을 꾸린다
		time	6h
		exptime	4h
		exp		1%
		job		잡화상	times/job_tool_time_rate
		use		1	해체/곤포&nbsp;킷
		use		10	철검
		use		10	철방패
		use		10	철갑옷
		use		10	철지팡이
		get		10	철제&nbsp;장비&nbsp;모음
	@@USE
		name	강철제&nbsp;장비&nbsp;모음을 꾸린다
		time	7h
		exptime	4.5h
		exp		1%
		job		잡화상	times/job_tool_time_rate
		use		1	해체/곤포&nbsp;킷
		use		10	강철검
		use		10	강철방패
		use		10	강철갑옷
		use		10	강철지팡이
		get		10	강철제&nbsp;장비&nbsp;모음
	@@USE
		name	미스릴제&nbsp;장비&nbsp;모음을 꾸린다
		time	8h
		exptime	5h
		exp		1%
		job		잡화상	times/job_tool_time_rate
		use		1	해체/곤포&nbsp;킷
		use		10	미스릴검
		use		10	미스릴방패
		use		10	미스릴갑옷
		use		10	미스릴지팡이
		get		10	미스릴제&nbsp;장비&nbsp;모음
	@@USE
		name	오리하르콘제&nbsp;장비&nbsp;모음을 꾸린다
		time	9h
		exptime	6h
		exp		1%
		job		잡화상	times/job_tool_time_rate
		use		1	해체/곤포&nbsp;킷
		use		10	오리하르콘검
		use		10	오리하르콘방패
		use		10	오리하르콘갑옷
		use		10	오리하르콘지팡이
		get		10	오리하르콘제&nbsp;장비&nbsp;모음
	@@USE
		name	축하 상품을 꾸린다
		time	8h
		job		잡화상	times/job_tool_time_rate
		use		1	해체/곤포&nbsp;킷
		use		1	칠면조&nbsp;통구이
		use		1	조건의&nbsp;럼주
		use		1	멋쟁이&nbsp;부츠
		get		1	축하&nbsp;세트

@@ITEM
	no		15
	type	책
	code	book-tyougou
	name	약조제&nbsp;입문
	info	약을 조제하기 위한 기술서입니다
	price	25000
	limit	40/1	#★소지 최대수/시장 입하 최대수(1 가게 근처)
			#  10 가게의 게임이라고,이 예에서는 시장에는 최대 10개 입하한다.
			#  또,음수의 경우는 절대수가 된다.(10/-2라면 시장에는 최대 2개)
			#  시장 최대수를 지정하지 않는 서식 패턴 1의 경우는,소지 최대수와 같다.
	pop	2d
	plus	20h
	scale	권
	cost	200
	@@use
		time	30m
		exp		2%
		exptime	10m
		job		약국	times/job_drug_time_rate
		scale	세트
		action	마구 만든다
		name	포션를 작성한다
		info	포션를 마구 작성합니다
		okmsg	포션를 많이 만들었습니다
		ngmsg	작성에 실패했습니다…
			use		10	약초
			get		20	포션	80%
	@@use
		time	30m
		exp		2%
		exptime	10m
		name	하이&nbsp;포션을 작성한다
		info	하이&nbsp;포션을 마구 작성합니다
		okmsg	하이&nbsp;포션을 만들었습니다
		ngmsg	작성에 실패했습니다…
		func	lostbook
		param	25
			needexp	20%
			use		10	포션
			get		20	하이&nbsp;포션	80%
	@@use
		time	30m
		exp		2%
		exptime	10m
		name	에테르를 작성한다
		info	에테르를 마구 작성합니다
		okmsg	에테르를 만들었습니다
		ngmsg	작성에 실패했습니다…
			needexp	20%
			use		20	약초
			get		20	에테르	64%
	@@use
		time	30m
		exp		2%
		exptime	10m
		name	하이&nbsp;에테르를 작성한다
		info	하이&nbsp;에테르를 마구 작성합니다
		okmsg	하이&nbsp;에테르를 만들었습니다
		ngmsg	작성에 실패했습니다…
		func	lostbook
		param	25
			needexp	40%
			use		10	에테르
			get		10	하이&nbsp;에테르	90%
	@@use
		time	30m
		exp		2%
		exptime	10m
		name	에리풀을 작성한다
		info	에리풀을 마구 작성합니다
		okmsg	에리풀을 재배했습니다
		ngmsg	작성에 실패했습니다…
		func	lostbook
		param	50
			needexp	60%
			use		10	하이&nbsp;포션
			use		10	하이&nbsp;에테르
			get		5	에리풀
@@ITEM
	no		16
	type	책
	code	book-kawazaiku
	name	가죽&nbsp;세공&nbsp;입문
	info	혁세공사를 목표로 하는 사람에게
	price	25000
	limit	40/1
	pop	2d
	plus	20h
	scale	권
	cost	500
	@@use
		time	1h
		exp		2%
		exptime	20m
		job		방어구가게	times/job_armor_time_rate
		scale	세트
		action	마구 만든다
		name	가죽방패를 작성한다
		info	가죽방패를 작성합니다
		okmsg	가죽방패를 만들었습니다
		ngmsg	작성에 실패했습니다…
			use		24	짐승의&nbsp;가죽
			get		30	가죽방패	80%
	@@use
		time	1h
		exp		2%
		exptime	20m
		scale	세트
		action	마구 만든다
		name	가죽흉갑을 작성한다
		info	가죽흉갑을 작성합니다
		okmsg	가죽흉갑을 만들었습니다
		ngmsg	작성에 실패했습니다…
			use		24	짐승의&nbsp;가죽
			get		32	가죽흉갑	80%

@@ITEM
	no		17
	type	책
	code	book-mokkouzaiku
	name	목세공&nbsp;입문
	info	목세공사를 목표로 하는 사람에게
	price	25000
	limit	40/1
	pop	2d
	plus	20h
	scale	권
	cost	500
	@@use
		time	1h
		exp		2%
		exptime	20m
		job		무기가게	times/job_weapon_time_rate
		scale	세트
		action	마구 만든다
		name	목검을 작성한다
		info	목검을 작성합니다
		okmsg	목검을 만들었습니다
		ngmsg	작성에 실패했습니다…
			use		20	나뭇가지
			get		20	목검	80%
	@@use
		time	1h
		exp		2%
		exptime	20m
		name	나무지팡이를 작성한다
		info	나무지팡이를 작성합니다
		okmsg	나무지팡이를 만들었습니다
		ngmsg	작성에 실패했습니다…
			use		20	나뭇가지
			get		20	나무지팡이	80%
	@@use
		time	2h
		exp		2%
		exptime	40m
		job		방어구가게	times/job_armor_time_rate
		name	나무방패를 작성한다
		info	나무방패를 작성합니다
		okmsg	나무방패를 만들었습니다
		ngmsg	작성에 실패했습니다…
			use		10	통나무
			get		20	나무방패	80%
	@@use
		time	2h
		exp		2%
		exptime	40m
		job		방어구가게	times/job_armor_time_rate
		name	나무흉갑을 작성한다
		info	나무흉갑을 작성합니다
		okmsg	나무흉갑을 만들었습니다
		ngmsg	작성에 실패했습니다…
			use		10	통나무
			get		24	나무흉갑	80%

@@ITEM
	no		66
	type	책
	code	book-sousyoku
	name	장식&nbsp;세공&nbsp;입문
	info	장식 세공인을 목표로 하는 사람에게
	price	50000
	limit	20/0.5
	pop	2d
	plus	20h
	scale	권
	cost	1000
	@@use
		time	90m
		exp		2%
		exptime	30m
		job		잡화상	times/job_tool_time_rate
		scale	세트
		action	마구 만든다
		name	철귀걸이를 작성한다
		info	철귀걸이를 마구 작성합니다
		okmsg	철귀걸이를 많이 만들었습니다
		ngmsg	작성에 실패했습니다…
			need	1	대장간의&nbsp;기술
			need	1	마법의&nbsp;지식
			use		20	철괴
			get		20	철귀걸이	80%
	@@use
		time	3h
		exp		2%
		exptime	1h
		scale	세트
		action	마구 만든다
		name	미스릴반지를 작성한다
		info	미스릴반지를 마구 작성합니다
		okmsg	미스릴반지를 많이 만들었습니다
		ngmsg	작성에 실패했습니다…
		func	lostbook
		param	50
			needexp	25%
			need	1	대장간의&nbsp;기술
			need	1	마법의&nbsp;지식
			use		20	미스릴덩어리
			use		2	마석
			get		20	미스릴반지	60%
	@@use
		time	4h
		exp		2%
		exptime	80m
		scale	세트
		action	마구 만든다
		name	오리하르콘팔찌를 작성한다
		info	오리하르콘팔찌를 마구 작성합니다
		okmsg	오리하르콘팔찌를 많이 만들었습니다
		ngmsg	작성에 실패했습니다…
		func	lostbook
		param	50
			needexp	50%
			need	1	대장간의&nbsp;기술
			need	1	마법의&nbsp;지식
			use		20	오리하르콘덩어리
			use		2	마석
			get		20	오리하르콘팔찌	40%
	@@use
		time	6h
		exp	2%
		exptime	5h
		scale	세트
		action	만들어낸다
		name	나유타의 목걸이를 작성한다
		info	나유타의 목걸이를 만들어냅니다
		okmsg	전설이 지금,눈앞에!
		ngmsg	작성에 실패했습니다…
		func	lostbook
		param	200
			needexp	50%
			need	1	대장간의&nbsp;기술
			need	1	마법의&nbsp;지식
			need	1	감정의&nbsp;진수
			use		20	철괴
			use		20	미스릴덩어리
			use		20	오리하르콘덩어리
			use		6	마석
			get		1	나유타의&nbsp;목걸이
	
@@ITEM
	no		20
	type	책
	code	book-ken
	name	검&nbsp;단련법
	info	무기의 대표 「검」의 단련하는 방법
	price	50000
	limit	20/0.5
	pop	2d
	plus	20h
	scale	권
	cost	1000
	@@use
		time	90m
		exp		2%
		exptime	30m
		job		무기가게	times/job_weapon_time_rate
		scale	세트
		action	단련한다
		name	철검을 단련한다
		info	전통적인 철검을 단련해 봅시다
		okmsg	철검을 단련했습니다
		ngmsg	단련하는데 실패했습니다…
			need	1	대장간의&nbsp;기술
			use		20	철괴
			get		20	철검	80%
	@@use
		time	3h
		exptime	1h
		name	강철검을 단련한다
		info	강철검을 단련해 봅시다
		okmsg	강철검을 단련했습니다
		ngmsg	단련하는데 실패했습니다…
			needexp	20%
			need	1	대장간의&nbsp;기술
			use		40	철괴
			get		20	강철검	80%
	@@use
		time	3h
		exptime	1h
		name	미스릴검을 단련한다
		info	상급 모험자의 납품업자,미스릴검을 단련해 봅시다
		okmsg	미스릴검을 단련했습니다
		ngmsg	단련하는데 실패했습니다…
		func	lostbook
		param	50
			needexp	40%
			need	1	대장간의&nbsp;기술
			use		20	미스릴덩어리
			get		20	미스릴검	60%
	@@use
		time	4h
		exptime	80m
		name	오리하르콘검을 단련한다
		info	좀처럼 손에 들어 오지 않는,오리하르콘검을 단련해 봅시다
		okmsg	오리하르콘검을 단련했습니다
		ngmsg	단련하는데 실패했습니다…
		func	lostbook
		param	50
			needexp	60%
			need	1	대장간의&nbsp;기술
			use		20	오리하르콘덩어리
			get		20	오리하르콘검	40%
@@ITEM
	no		21
	type	책
	code	book-tate
	name	방패&nbsp;제조법
	info	회피계 방어 장비 「방패」를 만드는 방법
	price	50000
	limit	20/0.5
	pop	2d
	plus	20h
	scale	권
	cost	1000
	@@use
		time	90m
		exp		2%
		exptime	30m
		job		방어구가게	times/job_armor_time_rate
		scale	세트
		action	작성한다
		name	철방패를 작성한다
		info	전통적인 철방패를 작성해 봅시다
		okmsg	철방패를 작성했습니다
		ngmsg	작성에 실패했습니다…
			need	1	대장간의&nbsp;기술
			use		20	철괴
			get		20	철방패	80%
	@@use
		time	3h
		exptime	1h
		name	강철방패를 작성한다
		info	강철방패를 작성해 봅시다
		okmsg	강철방패를 작성했습니다
		ngmsg	작성에 실패했습니다…
			needexp	20%
			need	1	대장간의&nbsp;기술
			use		40	철괴
			get		20	강철방패	80%
	@@use
		time	3h
		exptime	1h
		name	미스릴방패를 작성한다
		info	상급 모험자의 납품업자,미스릴방패를 작성해 봅시다
		okmsg	미스릴방패를 작성했습니다
		ngmsg	작성에 실패했습니다…
		func	lostbook
		param	50
			needexp	40%
			need	1	대장간의&nbsp;기술
			use		20	미스릴덩어리
			get		20	미스릴방패	60%
	@@use
		time	4h
		exptime	80m
		name	오리하르콘방패를 작성한다
		info	좀처럼 손에 들어 오지 않는,오리하르콘방패를 작성해 봅시다
		okmsg	오리하르콘방패를 작성했습니다
		ngmsg	작성에 실패했습니다…
		func	lostbook
		param	50
			needexp	60%
			need	1	대장간의&nbsp;기술
			use		20	오리하르콘덩어리
			get		20	오리하르콘방패	40%
@@ITEM
	no		22
	type	책
	code	book-yoroi
	name	갑옷&nbsp;제조법
	info	내격계 방어 장비 「갑옷」를 만드는 방법
	price	50000
	limit	20/0.5
	pop	2d
	plus	20h
	scale	권
	cost	1000
	@@use
		time	120m
		exp		2%
		exptime	40m
		job		방어구가게	times/job_armor_time_rate
		scale	세트
		action	작성한다
		name	철갑옷를 작성한다
		info	전통적인 철갑옷를 작성해 봅시다
		okmsg	철갑옷를 작성했습니다
		ngmsg	작성에 실패했습니다…
			need	1	대장간의&nbsp;기술
			use		20	철괴
			get		20	철갑옷	80%
	@@use
		time	210m
		exptime	70m
		name	강철갑옷를 작성한다
		info	강철갑옷를 작성해 봅시다
		okmsg	강철갑옷를 작성했습니다
		ngmsg	작성에 실패했습니다…
			needexp	20%
			need	1	대장간의&nbsp;기술
			use		40	철괴
			get		20	강철갑옷	80%
	@@use
		time	210m
		exptime	70m
		name	미스릴갑옷를 작성한다
		info	상급 모험자의 납품업자,미스릴갑옷를 작성해 봅시다
		okmsg	미스릴갑옷를 작성했습니다
		ngmsg	작성에 실패했습니다…
		func	lostbook
		param	50
			needexp	40%
			need	1	대장간의&nbsp;기술
			use		20	미스릴덩어리
			get		20	미스릴갑옷	60%
	@@use
		time	270m
		exptime	90m
		name	오리하르콘갑옷를 작성한다
		info	좀처럼 손에 들어 오지 않는,오리하르콘갑옷를 작성해 봅시다
		okmsg	오리하르콘갑옷를 작성했습니다
		ngmsg	작성에 실패했습니다…
		func	lostbook
		param	50
			needexp	60%
			need	1	대장간의&nbsp;기술
			use		20	오리하르콘덩어리
			get		20	오리하르콘갑옷	40%

@@ITEM
	no		23
	type	책
	code	book-tue
	name	지팡이&nbsp;제조법
	info	마법계 공격 장비 「지팡이」를 만드는 방법
	price	50000
	limit	20/0.5
	pop	2d
	plus	20h
	scale	권
	cost	1000
	@@use
		time	90m
		exp		2%
		exptime	30m
		job		무기가게	times/job_weapon_time_rate
		scale	세트
		action	작성한다
		name	철지팡이를 작성한다
		info	전통적인 철지팡이를 작성해 봅시다
		okmsg	철지팡이를 작성했습니다
		ngmsg	작성에 실패했습니다…
			need	1	마법의&nbsp;지식
			use		20	철괴
			use		2	마석
			get		20	철지팡이	80%
	@@use
		time	3h
		exptime	1h
		name	강철지팡이를 작성한다
		info	강철지팡이를 작성해 봅시다
		okmsg	강철지팡이를 작성했습니다
		ngmsg	작성에 실패했습니다…
			needexp	25%
			need	1	마법의&nbsp;지식
			use		40	철괴
			use		4	마석
			get		20	강철지팡이	80%
	@@use
		time	3h
		exptime	1h
		name	미스릴지팡이를 작성한다
		info	상급 모험자의 납품업자,미스릴지팡이를 작성해 봅시다
		okmsg	미스릴지팡이를 작성했습니다
		ngmsg	작성에 실패했습니다…
		func	lostbook
		param	50
			needexp	50%
			need	1	마법의&nbsp;지식
			use		20	미스릴덩어리
			use		6	마석
			get		20	미스릴지팡이	60%
	@@use
		time	4h
		exptime	80m
		name	오리하르콘지팡이를 작성한다
		info	좀처럼 손에 들어 오지 않는,오리하르콘지팡이를 작성해 봅시다
		okmsg	오리하르콘지팡이를 작성했습니다
		ngmsg	작성에 실패했습니다…
		func	lostbook
		param	50
			needexp	70%
			need	1	마법의&nbsp;지식
			use		20	오리하르콘덩어리
			use		10	마석
			get		20	오리하르콘지팡이	40%

@@ITEM
	no		12
	type	지도
	code	book-mtsearch
	name	가까운&nbsp;산의&nbsp;지도
	info	재료 조달에는 안성맞춤의 산입니다
	price	10000
	limit	3/3
	pop	0
	plus	1h
	base	50/150
	scale	권
	cost	500
	flag	noshowcase
	@@use
		time	2h
		exp		2%
		exptime	30m
		job		산인	times/job_material_time_rate
		scale	왕복
		action	탐색하러 간다
		name	산기슭을 탐색
		info	여러가지 재료를 조달할 수 있을지도 모릅니다
		func	lostbook
		param	10
		ngmsg	아무것도 발견되지 않았습니다…
			get		80	약초	90%	약초가&nbsp;많이&nbsp;나&nbsp;있었습니다
			get		2	짐승의&nbsp;가죽	90%
			get		2	나뭇가지	90%
			get		2	통나무	45%
	@@use
		time	2h
		exp		2%
		exptime	30m
		scale	왕복
		action	탐색하러 간다
		name	산길을 탐색
		info	여러가지 재료를 조달할 수 있을지도 모릅니다
		ngmsg	아무것도 발견되지 않았습니다…
		func	lostbook
		param	10
			get		4	약초	90%
			get		2	짐승의&nbsp;가죽	90%
			get		40	나뭇가지	90%	나뭇가지가&nbsp;많이&nbsp;떨어지고&nbsp;있었습니다
			get		2	통나무	45%
	@@use
		time	2h
		exp		2%
		exptime	30m
		scale	왕복
		action	탐색하러 간다
		name	수도를 탐색
		info	재료를 조달할 수 있을지도 모릅니다
		ngmsg	아무것도 발견되지 않았습니다…
		func	lostbook
		param	10
			get		4	약초	90%
			get		40	짐승의&nbsp;가죽	90%	짐승을&nbsp;많이&nbsp;사냥했습니다
			get		2	나뭇가지	90%
			get		2	통나무	45%
	@@use
		time	2h
		exp		2%
		exptime	30m
		scale	왕복
		action	탐색하러 간다
		name	잡목림 안쪽을 탐색
		info	재료를 조달할 수 있을지도 모릅니다
		ngmsg	아무것도 발견되지 않았습니다…
		func	lostbook
		param	10
			get		4	약초	90%
			get		2	짐승의&nbsp;가죽	90%
			get		2	나뭇가지	90%
			get		40	통나무	45%		통나무가&nbsp;많이&nbsp;발견되었습니다
	
@@ITEM
	no		9
	type	지도
	code	book-metalsearch
	name	가까운&nbsp;광산의&nbsp;지도
	info	각종 광물의 채취를 할 수 있을 것 같습니다
	price	10000
	limit	3/3
	pop	0
	plus	1h
	base	50/150
	scale	권
	cost	500
	flag	noshowcase
	@@use
		time	2h
		exp		2%
		exptime	30m
		job		산인	times/job_material_time_rate
		scale	왕복
		action	채취하러 간다
		name	철광산에 간다
		info	여러가지 광물을 조달할 수 있을지도 모릅니다
		ngmsg	아무것도 발견되지 않았습니다…
		func	lostbook
		param	10
			get		30	철괴			80%
			get		2	미스릴덩어리		60%
			get		1	오리하르콘덩어리	80%
	@@use
		time	2h
		exp		2%
		exptime	30m
		scale	왕복
		action	채취하러 간다
		name	미스릴 광산에 간다
		info	여러가지 광물을 조달할 수 있을지도 모릅니다
		ngmsg	아무것도 발견되지 않았습니다…
		func	lostbook
		param	10
			get		3	철괴			80%
			get		20	미스릴덩어리		60%
			get		1	오리하르콘덩어리	80%
	@@use
		time	2h
		exp		2%
		exptime	30m
		scale	왕복
		action	채취하러 간다
		name	오리하르콘 광산에 간다
		info	여러가지 광물을 조달할 수 있을지도 모릅니다
		ngmsg	아무것도 발견되지 않았습니다…
		func	lostbook
		param	10
			get		3	철괴			80%
			get		2	미스릴덩어리		60%
			get		10	오리하르콘덩어리	80%

@@ITEM
	no		14
	type	지도
	code	shiire-ken
	name	검의&nbsp;도시의&nbsp;지도
	info	검의 시장까지의 지도
	price	10000
	limit	3/3
	pop	0
	plus	1h
	base	50/150
	scale	권
	cost	500
	flag	noshowcase
	@@use
		time	4h
		exp	2%
		exptime	2h
		job		행상인	times/job_peddle_time_rate
		scale	왕복
		action	구입하러 간다
		price	12000					#★사용시 비용액
		name	검의 시장에 구입하러 간다
		info	검을 구입하러 갑니다
		func	lostbook
		param	100
		ngmsg	아무것도 매입할 수 없었습니다…
			get		10	목검			40%
			get		10	철검			35%
			get		10	강철검		15%
			get		10	미스릴검		6%	미스릴검이&nbsp;쌌습니다
			get		10	오리하르콘검	3%	오리하르콘검이&nbsp;귀한&nbsp;물건으로서&nbsp;나오고&nbsp;있었습니다!
		funcb	_local_
			# 1/10의 확률로 수확량이  2배가 된다
			return 0 if rand(1000)>100;
			
			my $USE=$_[0];
			
			# $USE->{result}->{create}->[0..?]->{count} 를 2배로 한다
			foreach(@{$USE->{result}->{create}})
			{
				$_->{count}*=2;
			}
			
			# okmsg 를 설정한다
			$USE->{result}->{message}->{resultok}='이번은 수확이 평소보다 많았습니다';
			return 0;
		_local_
	

@@ITEM
	no		30
	type	약
	code	posyon
	name	포션
	info	체력을 회복시키는 약
	price	100
	limit	5000/500
	pop	20m
	plus	2h
	base	10/1000
	scale	개
	cost	5
	point	10%
@@ITEM
	no		31
	type	약
	code	posyon-hi
	name	하이&nbsp;포션
	info	약의 일종
	price	200
	limit	2500/250
	base	400/1000
	plus	-1h
	pop	30m
	scale	개
	point	10%
@@ITEM
	no		32
	type	약
	code	eteru
	name	에테르
	info	마력을 회복시키는 약
	price	250
	limit	2000/200
	pop	50m
	plus	5h
	base	10/500
	scale	개
	cost	10
	point	20%
@@ITEM
	no		33
	type	약
	code	eteru-hi
	name	하이&nbsp;에테르
	info	약의 일종
	price	500
	limit	1000/100
	base	200/500
	plus	-1h
	pop	60m
	scale	개
	cost	50
	point	20%
@@ITEM
	no		34
	type	약
	code	erikusa
	name	에리풀
	info	약의 일종
	price	2500
	plus	-1h
	limit	400/40
	base	40/100
	pop	4h
	scale	개
	cost	100
	point	40%
@@ITEM
	no		40
	type	검
	code	ken-ki
	name	목검
	info	선물로 최적
	price	1200
	limit	600
	base	100/200
	plus	-1h
	pop	3h
	scale	개
@@ITEM
	no		41
	type	검
	code	ken-tetu
	name	철검
	info	철검
	price	1500
	limit	500
	base	50/100
	plus	-1h
	pop	3h
	scale	개
@@ITEM
	no		42
	type	검
	code	ken-hagane
	name	강철검
	info	강철검
	price	3200
	limit	300
	base	30/60
	plus	-1h
	pop	5h
	scale	개
	point	80%
@@ITEM
	no		43
	type	검
	code	ken-misuriru
	name	미스릴검
	info	미스릴검
	price	8000
	limit	100
	base	20/40
	plus	-1h
	pop	10h
	scale	개
	point	70%
@@ITEM
	no		44
	type	검
	code	ken-oriharukon
	name	오리하르콘검
	info	오리하르콘검
	price	12000
	limit	75
	base	12/24
	plus	-1h
	pop	16h
	scale	개
	point	60%

@@ITEM
	no		51
	type	갑옷
	code	yoroi-kawa
	name	가죽흉갑
	info	방한 효과조차 없음
	price	750
	limit	1000
	base	150/300
	plus	-1h
	pop	110m
	scale	개
	point	40%
@@ITEM
	no		52
	type	갑옷
	code	yoroi-ki
	name	나무흉갑
	info	간신히 흉갑
	price	1000
	limit	750
	base	100/200
	plus	-1h
	pop	150m
	scale	개
	point	50%
@@ITEM
	no		53
	type	갑옷
	code	yoroi-tetu
	name	철갑옷
	info	철갑옷
	price	1600
	limit	500
	base	50/100
	plus	-1h
	pop	190m
	scale	개
	point	80%
@@ITEM
	no		54
	type	갑옷
	code	yoroi-hagane
	name	강철갑옷
	info	강철갑옷
	price	3400
	limit	300
	base	30/60
	plus	-1h
	pop	320m
	scale	개
	point	80%
@@ITEM
	no		55
	type	갑옷
	code	yoroi-misuriru
	name	미스릴갑옷
	info	미스릴갑옷
	price	9000
	limit	100
	base	20/40
	plus	-1h
	pop	680m
	scale	개
	point	75%
@@ITEM
	no		56
	type	갑옷
	code	yoroi-oriharukon
	name	오리하르콘갑옷
	info	오리하르콘갑옷
	price	12500
	limit	75
	base	12/24
	plus	-1h
	pop	17h
	scale	개
	point	60%

@@ITEM
	no		45
	type	방패
	code	tate-kawa
	name	가죽방패
	info	없는 것 보다야 낫겠지
	price	800
	limit	1000
	base	100/200
	plus	-1h
	pop	120m
	scale	개
	point	75%
@@ITEM
	no		46
	type	방패
	code	tate-ki
	name	나무방패
	info	아이들의 연습용
	price	1200
	limit	600
	base	100/200
	plus	-1h
	pop	3h
	scale	개
@@ITEM
	no		47
	type	방패
	code	tate-tetu
	name	철방패
	info	철방패
	price	1500
	limit	500
	base	50/100
	plus	-1h
	pop	3h
	scale	개
@@ITEM
	no		48
	type	방패
	code	tate-hagane
	name	강철방패
	info	강철방패
	price	3200
	limit	300
	base	30/60
	plus	-1h
	pop	5h
	scale	개
	point	80%
@@ITEM
	no		49
	type	방패
	code	tate-misuriru
	name	미스릴방패
	info	미스릴방패
	price	7500
	limit	100
	base	20/40
	plus	-1h
	pop	10h
	scale	개
	point	70%
@@ITEM
	no		50
	type	방패
	code	tate-oriharukon
	name	오리하르콘방패
	info	오리하르콘방패
	price	11000
	limit	75
	base	12/24
	plus	-1h
	pop	15h
	scale	개
	point	60%

@@ITEM
	no		57
	type	지팡이
	code	tue-ki
	name	나무지팡이
	info	장난감 지팡이
	price	1200
	limit	600
	base	100/200
	plus	-1h
	pop	3h
	scale	개
@@ITEM
	no		58
	type	지팡이
	code	tue-tetu
	name	철지팡이
	info	철지팡이
	price	2000
	limit	500
	base	50/100
	plus	-1h
	pop	5h
	scale	개
@@ITEM
	no		59
	type	지팡이
	code	tue-hagane
	name	강철지팡이
	info	강철지팡이
	price	4000
	limit	300
	base	30/60
	plus	-1h
	pop	8h
	scale	개
	point	80%
@@ITEM
	no		60
	type	지팡이
	code	tue-misuriru
	name	미스릴지팡이
	info	미스릴지팡이
	price	10000
	limit	100
	base	20/40
	plus	-1h
	pop	15h
	scale	개
	point	70%
@@ITEM
	no		61
	type	지팡이
	code	tue-oriharukon
	name	오리하르콘지팡이
	info	오리하르콘지팡이
	price	16000
	limit	75
	base	12/24
	plus	-1h
	pop	24h
	scale	개
	point	60%

@@ITEM
	no		67
	type	악세사리
	code	sousyoku-tetu
	name	철귀걸이
	info	손수 만든 느낌이 흘러넘치는 귀걸이
	price	1500
	limit	500/0
	pop	4h
	base	20/30
	scale	개
@@ITEM
	no		68
	type	악세사리
	code	sousyoku-misuriru
	name	미스릴반지
	info	미스릴반지
	price	8000
	limit	100/0
	pop	14h
	base	20/40
	plus	-1h
	scale	개
@@ITEM
	no		69
	type	악세사리
	code	sousyoku-oriharukon
	name	오리하르콘팔찌
	info	오리하르콘팔찌
	price	12000
	limit	75/0
	pop	20h
	base	12/24
	plus	-1h
	scale	개
@@ITEM
	no		70
	type	악세사리
	code	sousyoku-nayuta
	name	나유타의&nbsp;목걸이
	info	전설의 영웅을 칭한 목걸이
	price	50000
	limit	1/0
	pop		2d
	scale	개
	cost	200
	funct	_local_
		#표준 가격 미만으로 진열중의 경우 1일10%의 무조건 인기 업
		my($ITEM,@DT)=@_;
		my $rankup=$TIMESPAN/86.4;
		$rankup=$rankup<1 && rand(1)<$rankup ? 1 : int($rankup);
		return if !$rankup;
		foreach my $DT (@DT)
		{
			next if $DT->{showcase}[0]!=$ITEM->{no} || $DT->{price}[0]>$ITEM->{price};
			
			$DT->{rank}+=$rankup;
			$DT->{rank}=10000 if $DT->{rank}>10000;
			DebugLog("item $ITEM->{name} $DT->{shopname} 인기 +".($rankup/100)."\%");
		}
	_local_

@@ITEM
	no		71
	type	도구
	code	soubiset-kawa
	name	가죽제&nbsp;장비&nbsp;모음
	info	가죽제 장비를 정리한 세트 상품
	price	3000
	limit	300/0
	pop	6h
	scale	세트
@@ITEM
	no		72
	type	도구
	code	soubiset-ki
	name	목제&nbsp;장비&nbsp;모음
	info	목제 장비를 정리한 세트 상품
	price	9000
	limit	100/0
	pop	18h
	scale	세트
@@ITEM
	no		73
	type	도구
	code	soubiset-tetu
	name	철제&nbsp;장비&nbsp;모음
	info	철제 장비를 정리한 세트 상품
	price	12000
	limit	80/0
	pop	24h
	scale	세트
@@ITEM
	no		74
	type	도구
	code	soubiset-hagane
	name	강철제&nbsp;장비&nbsp;모음
	info	강철제 장비를 정리한 세트 상품
	price	27000
	limit	40/0
	pop	54h
	scale	세트
@@ITEM
	no		75
	type	도구
	code	soubiset-misuriru
	name	미스릴제&nbsp;장비&nbsp;모음
	info	미스릴제 장비를 정리한 세트 상품
	price	60000
	limit	20/0
	pop	108h
	scale	세트
@@ITEM
	no		76
	type	도구
	code	soubiset-oriharukon
	name	오리하르콘제&nbsp;장비&nbsp;모음
	info	오리하르콘제 장비를 정리한 세트 상품
	price	81000
	limit	10/0
	pop	148h
	scale	세트

@@ITEM
	no		1
	type	원료
	code	yakusou
	name	약초
	info	약이 되는 풀
	price	50
	limit	4000/1000
	pop	10d
	plus	-20m
	base	200/1400
	scale	개
	cost	10
	point	25%
@@ITEM
	no		2
	type	원료
	code	kemononokawa
	name	짐승의&nbsp;가죽
	info	이름없는 한 짐승의 모피
	price	100
	limit	2000/500
	pop	10d
	plus	-20m
	base	100/700
	scale	장
	cost	30
	point	50%
@@ITEM
	no		3
	type	원료
	code	kinoeda
	name	나뭇가지
	info	팔뚝 굵기 정도의 가지
	price	120
	limit	1500/500
	pop	10d
	plus	-20m
	base	200/600
	scale	개
	cost	40
	point	50%
@@ITEM
	no		4
	type	원료
	code	maruta
	name	통나무
	info	통나무
	price	240
	limit	500/100
	pop	10d
	plus	-20m
	base	100/500
	scale	개
	cost	100
@@ITEM
	no		8
	type	원료
	code	magicstone
	name	마석
	info	마력을 봉할 수 있는 광석
	price	250
	limit	200/50
	pop	10d
	plus	6h
	base	500/2500
	scale	개
	cost	100
@@ITEM
	no		5
	type	원료
	code	tetu
	name	철괴
	info	철덩어리
	price	200
	limit	1000/250
	pop	10d
	plus	-20m
	base	300/800
	scale	kg
	cost	60
@@ITEM
	no		6
	type	원료
	code	misuriru
	name	미스릴덩어리
	info	미스릴덩어리
	price	400
	limit	800/200
	pop	10d
	plus	-20m
	base	300/600
	scale	kg
	cost	80
@@ITEM
	no		7
	type	원료
	code	oriharukon
	name	오리하르콘덩어리
	info	오리하르콘덩어리
	price	600
	limit	600/150
	pop	10d
	plus	-20m
	base	300/600
	scale	kg
	cost	90

@@ITEM
	no		62
	type	도구
	code	cm
	name	광고&nbsp;팩
	info	인기가 거론됩니다만 실패하는 일도…
	price	100000
	limit	1/1
	pop	10d
	plus	5d
	base	10/50
	scale	팩
	cost	10000
	@@use
		time	10h
		exp	10%
		job		행상인	times/job_peddle_time_rate
		scale	회
		action	광고 한다
		name	자점의 광고를 낸다
		info	자신의 가게의 인기가 거론됩니다
		arg		nocount
			use		1	광고&nbsp;팩
		func	_local_
				my $up=int(500*(2-$DT->{rank}/5000));
				if ( rand(1000)<250 ) {
					$DT->{rank}-=$up;
					$DT->{rank}=1000 if $DT->{rank}<1000;
					my $ret="광고는 화근이 되어 버렸습니다：인기 ".int($up/100)."%다운";
					WriteLog(0,$DT->{id},$ret);
					WriteLog(3,0,$DT->{shopname}."가 광고를 냈습니다만 오히려 역효과였습니다.");
					return $ret;
				}
				$DT->{rank}+=$up;
				$DT->{rank}=10000 if $DT->{rank}>10000;
				my $ret="광고를 냈습니다：인기 ".int($up/100)."%업";
				WriteLog(0,$DT->{id},$ret);
				WriteLog(3,0,$DT->{shopname}."가 광고를 냈습니다.");
				return $ret;
			_local_
	@@use
		time	10h
		exp	0%
		name	다른 상점의 광고를 낸다
		info	다른 상점의 인기가 거론됩니다
		arg		target|nocount
			use		1	광고&nbsp;팩
		func	_local_
				return '자점을 지정할 수 없습니다' if ($DT==$DTS);
				my $up=int(500*(2-$DTS->{rank}/5000));
				$DTS->{rank}+=$up;
				$DTS->{rank}=10000 if $DTS->{rank}>10000;
				my $ret="광고를 냈습니다：".$DTS->{shopname}."의 인기 ".int($up/100)."%업";
				WriteLog(0,$DT->{id},$ret);
				WriteLog(3,0,$DT->{shopname}."가 ".$DTS->{shopname}."의 광고를 냈습니다.");
				return $ret;
			_local_
	@@use
		time	16h
		exp	0%
		name	길드의 광고를 낸다
		info	동길드 소속점 모든 인기가 거론됩니다
		arg		nocount
			use		1	광고&nbsp;팩
		func	_local_
				return '길드에 소속해 있지 않기 때문에 광고를 낼 수 없었습니다' if !$DT->{guild};

				WriteLog(3,0,$DT->{shopname}."가 길드 「".$main::GUILD{$DT->{guild}}->[$GUILDIDX_name]."」의 광고를 냈습니다.");
				foreach my $DTS (@DT)
				{
				next if ($DTS->{guild} ne $DT->{guild});
				my $up=int(500*(2-$DTS->{rank}/5000));
				$DTS->{rank}+=$up;
				$DTS->{rank}=10000 if $DTS->{rank}>10000;
				my $ret="길드 광고를 냈습니다：".$DTS->{shopname}."의 인기 ".int($up/100)."%업";
				WriteLog(0,$DT->{id},$ret);
				}
				return '길드 광고를 냈습니다';
			_local_

@@ITEM
	no		13
	type	책
	code	book-work
	name	자금조달의&nbsp;방법
	info	급하게 돈이 필요한 땐 이것
	price	0
	limit	1/1
	pop	0
	plus	10h
	scale	권
	flag	noshowcase
	@@use
		time	4h
		job		행상인	times/job_peddle_time_rate
		scale	회
		action	일한다
		name	티슈를 나누어 주는 사람으로 자금 돈벌이
		info	간단히 법시다
		param	3000
		func	_local_
			# ★바이트
			#   param1 취득액
			$DT->{money}+=$USE->{param1}*$count;
			
			my $ret=GetMoneyString($USE->{param1}*$count).' 벌었습니다';
			
			WriteLog(0,$DT->{id},"아르바이트 했습니다,$ret");
			WriteLog(3,0,$DT->{shopname}."가 아르바이트를 한 것 같습니다");
			
			return $ret;
		_local_
	@@use
		time	8h
		job		행상인	times/job_peddle_time_rate
		scale	회
		action	일한다
		name	일용 토목 작업으로 자금 돈벌이
		info	조금 힘들지만 적당한 돈벌이입니다
		param	10000
		func	_local_1

@@ITEM
	no		63
	type	도구
	code	edit-showcase
	name	진열장&nbsp;증축취괴킷
	info	진열장의 증축이나 취괴 등에 필요한 도구 한세트입니다
	price	0
	limit	1/1
	pop	0
	plus	1d
	scale	킷
	flag	noshowcase|norequest
	@@use
		time	1h
		scale	회
		action	작업한다
		price	10000
		name	진열장을 1개로 한다
		info	진열장을 1개로 한다
		arg		nocount		#★사용시의 선택사항 지정.
							#  nocount -> 사용 회수 선택 없음
		param	1			#★독자 함수용 파라미터
			use	1	진열장&nbsp;증축취괴킷
		func	_local_
			# ★진열장수변경
			#   param1 변경 후의 선반의 수
			my $oldcnt=$DT->{showcasecount};
			my $newcnt=$USE->{param1};
			$DT->{showcasecount}=$newcnt;
			
			if($oldcnt<$newcnt)
			{
				foreach ($oldcnt..$newcnt-1)
				{
					$DT->{showcase}[$_]=0;
					$DT->{price}[$_]=0;
				}
			}
			if($oldcnt>$newcnt)
			{
				splice(@{$DT->{showcase}},$newcnt);
				splice(@{$DT->{price}},$newcnt);
			}
			my $ret="진열장을 $DT->{showcasecount}개로 했습니다";
			WriteLog(0,$DT->{id},$ret);
			WriteLog(0,0,$DT->{shopname}."의 진열장이 $DT->{showcasecount}개가 되었습니다.");
			
			return $ret;
		_local_
	@@use
		time	2h
		price	20000
		name	진열장을 2개로 한다
		info	진열장을 2개로 한다
		func	_local_1
		arg		nocount
		param	2
			use	1	진열장&nbsp;증축취괴킷
	@@use
		time	3h
		price	30000
		name	진열장을 3개로 한다
		info	진열장을 3개로 한다
		func	_local_1
		arg		nocount
		param	3
			use	1	진열장&nbsp;증축취괴킷
	@@use
		time	4h
		price	40000
		name	진열장을 4개로 한다
		info	진열장을 4개로 한다
		func	_local_1
		arg		nocount
		param	4
			use	1	진열장&nbsp;증축취괴킷
	@@use
		time	5h
		price	50000
		name	진열장을 5개로 한다
		info	진열장을 5개로 한다
		func	_local_1
		arg		nocount
		param	5
			use	1	진열장&nbsp;증축취괴킷
	@@use
		time	6h
		price	60000
		name	진열장을 6개로 한다
		info	진열장을 6개로 한다
		func	_local_1
		arg		nocount
		param	6
			use	1	진열장&nbsp;증축취괴킷
	@@use
		time	7h
		price	70000
		name	진열장을 7개로 한다
		info	진열장을 7개로 한다
		func	_local_1
		arg		nocount
		param	7
			use	1	진열장&nbsp;증축취괴킷
	@@use
		time	8h
		price	80000
		name	진열장을 8개로 한다
		info	진열장을 8개로 한다
		func	_local_1
		arg		nocount
		param	8
			use	1	진열장&nbsp;증축취괴킷
		
@@ITEM
	no		65
	type	책
	code	badgossip
	name	금단의&nbsp;책
	info	해서는 안 되지만 하지 않으면 안 될 때에…
	price	50000
	cost	5000
	limit	1/1
	pop		0
	plus	1d
	scale	권
	@@use
		time	10h
		exp	20%
		exptime	8h
		scale	회
		price	50000
		scale	회
		action	나쁜 소문을 흘린다
		price	0
		name	나쁜 소문을 흘린다
		info	성공하면 상대의 가게의 인기를 내릴 수 있습니다만 ,실패하는 일도…
		arg	target|nocount
			needpoint	20000
			use		1	금단의&nbsp;책
		func	_local_
			my $ret;
			if(rand(1000)<800 && !$DTS->{exp}{@@ITEMNO"광고&nbsp;팩"})
			{
				$DTS->{rank}-=int($DTS->{rank}/3);
				$ret=$DTS->{shopname}.'의 나쁜 소문을 흘리는 작전이 성공했습니다';
				WriteLog(0,$DT->{id},$ret);
				WriteLog(2,0,$DTS->{shopname}.'의 나쁜 소문이 퍼져 인기가 내렸습니다.');
			}
			else
			{
				$DTS->{exp}{@@ITEMNO"광고&nbsp;팩"}-=100;
				$DTS->{exp}{@@ITEMNO"광고&nbsp;팩"}=0 if ($DTS->{exp}{@@ITEMNO"광고&nbsp;팩"} < 0);
				$DT->{rank}-=int($DT->{rank}/4);
				$ret=$DTS->{shopname}.'의 나쁜 소문을 흘리는 작전은 실패했습니다';
				WriteLog(0,$DT->{id},$ret);
				WriteLog(3,0,$DT->{shopname}."가 ".$DTS->{shopname}.'의 나쁜 소문을 걸려 했던 것 같습니다.');
			}
			return $ret;
			_local_
	@@use
		time	10h
		exp	25%
		exptime	8h
		scale	회
		action	도둑질한다
		price	50000
		name	도둑질한다
		info	거기까지 몰렸다면, 어쩔 수 없다…
		arg	target|nocount
			needpoint	20000
			use		1	금단의&nbsp;책
		func	_local_
			return '자신에게 도둑할 수 없습니다. 도둑질은 실패입니다.' if  ($DT->{id} eq $DTS->{id});
			my $ret="도둑질은 실패했습니다. 배상금 ".GetMoneyString(500000)." 뺏겨 버렸습니다.";
			if($DTS->{item}[@@ITEMNO"가게&nbsp;보는&nbsp;인형로봇"-1])
			{
			$DTS->{item}[@@ITEMNO"가게&nbsp;보는&nbsp;인형로봇"-1]--;
			$DT->{rank}-=int($DT->{rank}/4);
			$DTS->{money}+=500000;
			$DTS->{saletoday}+=500000;
			$DT->{money}-=500000;
			$DT->{paytoday}+=500000;
			WriteLog(3,0,$DT->{shopname}."가 ".$DTS->{shopname}."에 도둑에 들어와 가게&nbsp;보는&nbsp;인형로봇를 파괴했습니다만 잡혔습니다.");
			WriteLog(3,0,$DT->{shopname}."는 ".$DTS->{shopname}."에 배상금 ".GetMoneyString(500000)."(을)를 지불했습니다.");
			WriteLog(0,$DT->{id},$ret);
			return $ret;
			}
			if(rand(1000)>900)
			{
			$DTS->{money}+=500000;
			$DTS->{saletoday}+=500000;
			$DT->{money}-=500000;
			$DT->{paytoday}+=500000;
			$DT->{rank}-=int($DT->{rank}/4);
			WriteLog(3,0,$DT->{shopname}."가 ".$DTS->{shopname}."에 도둑에 들어왔습니다만 실패했습니다.");
			WriteLog(3,0,$DT->{shopname}."는 ".$DTS->{shopname}."에 배상금 ".GetMoneyString(500000)."(을)를 지불했습니다.");
			WriteLog(0,$DT->{id},$ret);
			return $ret;
			}
			$ret="도둑은 성공했습니다";
			my $manbiki_count=0;
			foreach my $idx (0..$DTS->{showcasecount}-1)
			{
				my $itemno=$DTS->{showcase}[$idx];
				if($itemno)
				{
					my $cnt=int($DTS->{item}[$itemno-1]*3/4);
					$cnt=$ITEM[$itemno]->{limit}-$DT->{item}[$itemno-1] if $DT->{item}[$itemno-1]+$cnt>$ITEM[$itemno]->{limit};
					$DTS->{item}[$itemno-1]-=$cnt;
					$DT->{item}[$itemno-1]+=$cnt;
					$manbiki_count+=$cnt*$DTS->{price}[$idx];
				}
			}
		$main::STATE->{safety}=int($main::STATE->{safety} * 18 / 19);
		WriteLog(2,0,$DTS->{shopname}."가 총액 ".GetMoneyString($manbiki_count)."에 상당한 도둑 피해를 당했습니다.") if $manbiki_count;
		WriteLog(2,0,$DTS->{shopname}."에 들어간 도둑범은 아무것도 훔치지 않고 도망쳤습니다.") if !$manbiki_count;
		WriteLog(0,$DT->{id},$ret);
		return $ret;
		_local_
	@@use
		time	16h
		exp	5%
		exptime	14h
		scale	회
		action	취급상품의 나쁜 소문을 흘린다
		price	50000
		name	취급상품의 나쁜 소문을 흘린다
		info	전문점 킬러
		arg		target|nocount
			needpoint	20000
			use		1	금단의&nbsp;책
		func	_local_
			my %category=qw(4 ken 5 yoroi 6 tate 7 tue); #분류 번호와 이벤트 코드의 대응
			my $ret;
			my $itemno=$DTS->{showcase}->[int rand($DTS->{showcasecount})];
			my $itemtype=$ITEM[$itemno]->{type};
			my $category=$category{$itemtype};
			my $eventkey="kill-$category";
			
			#진열장의 상품이%category외였거나,이미 발동중이라면 실패.
			return '소문을 흘리는데 실패했습니다' if !$category || grep($_ eq $eventkey,keys(%main::DTevent));
			
			#8시간 지속으로 이벤트 발동
			$main::DTevent{$eventkey}=$main::NOW_TIME+8*60*60;
			$ret=$main::ITEMTYPE[$itemtype].'시장에 나쁜 소문을 퍼뜨렸습니다';
			WriteLog(0,$DT->{id},$ret);
			WriteLog(2,0,$main::ITEMTYPE[$itemtype].'시장에 나쁜 소문이 퍼지고 있는 것 같습니다.');
			return $ret;
		_local_
@@event
	start		-1 #이벤트 자연 발동 없음
	code		kill-ken
	endmsg		반 검운동이 들어갔습니다
	info		반 검운동이 일어나고 있습니다
		param	목검				point=0    #+-0%
		param	철검				point=-100 #-10%
		param	강철검			point=-200 #-20%
		param	미스릴검		point=-300 #-30%
		param	오리하르콘검	point=-400 #-40%
@@event
	start		-1
	code		kill-yoroi
	endmsg		반 갑옷 운동이 들어갔습니다
	info		반 갑옷 운동이 일어나고 있습니다
		param	가죽흉갑			point=0
		param	나무흉갑			point=0
		param	철갑옷				point=-100
		param	강철갑옷			point=-200
		param	미스릴갑옷		point=-300
		param	오리하르콘갑옷	point=-400
@@event
	start		-1
	code		kill-tate
	endmsg		반 방패운동이 들어갔습니다
	info		반 방패운동이 일어나고 있습니다
		param	가죽방패				point=0
		param	나무방패				point=0
		param	철방패				point=-100
		param	강철방패			point=-200
		param	미스릴방패		point=-300
		param	오리하르콘방패	point=-400
@@event
	start		-1
	code		kill-tue
	endmsg		반 지팡이운동이 들어갔습니다
	info		반 지팡이운동이 일어나고 있습니다
		param	나무지팡이				point=0
		param	철지팡이				point=-100
		param	강철지팡이			point=-200
		param	미스릴지팡이		point=-300
		param	오리하르콘지팡이	point=-400

@@ITEM
	no		18
	type	악세사리
	code	skill-kajiya
	name	대장간의&nbsp;기술
	info	대장간의 아버지 나오타다
	price	50000
	cost	1000
	limit	1/0
	pop	0
	scale	기술
	flag	noshowcase|norequest
@@ITEM
	no		19
	type	악세사리
	code	skill-magic
	name	마법의&nbsp;지식
	info	마법의 기초지식입니다
	price	50000
	cost	1000
	limit	1/0
	pop	0
	scale	지식
	flag	noshowcase|norequest
@@ITEM
	no		24
	type	악세사리
	code	skill-mekiki
	name	감정의&nbsp;진수
	info	차이를 아는 데에 빠르게 된다
	price	50000
	cost	1000
	limit	1/0
	pop	0
	scale	진수
	flag	noshowcase|norequest
@@ITEM
	no		38
	type	악세사리
	code	skill-kaitai
	name	해체가게의&nbsp;영혼
	info	분해에 생명을 건다
	price	50000
	cost	1000
	limit	1/0
	pop	0
	scale	영혼
	flag	noshowcase|norequest

@@ITEM
	no		64
	type	악세사리
	code	defence-manbiki
	name	가게&nbsp;보는&nbsp;인형로봇
	info	점내의 감시를 해 줍니다
	price	500000
	cost	5000
	limit	1/0.5
	pop	1d
	plus	30m
	scale	체
	flag	noshowcase|onlysend

@@ITEM
	no		11
	type	악세사리
	code	loto
	name	복권
	info	일확천금도 꿈이 아니다(추첨일은 2일에 1회의<B>확률</B>)
	price	2000
	cost	10
	limit	50/20
	plus	10m
	scale	장
	pop	0
	flag	noshowcase|norequest

@@ITEM
	no		25
	type	도구
	code	mino
	name	미노타우로스♀
	info	조금 무서운 가축
	price	10000
	cost	1000
	limit	20/1.5
	plus	1d
	scale	두
	pop		1d
	@@use
		time	2h
		exp		1%
		job		낙농가	times/job_cow_time_rate
		scale	착유
		action	짠다
		price	0
		name	젖을 짠다
		info	미노씨에게서 젖을 짭니다
		param	1
			need		1	미노타우로스♀
		func	_local_
			# ★미노타우로스 착유
			#   param1 착유 레벨(1~)
			my $val=$USE->{param1}*$count;
			
			$val*=$DT->{item}[25-1];
			$val=int(rand($val))+1;
			AddItem(26,$val,'미노&nbsp;우유를 정제 했습니다');
			
			my $useproba=$USE->{param1}*$USE->{param1};
			my $usecount=0;
			foreach(1..$count)
			{
				$usecount++ if rand(1000)<$useproba;
			}
			UseItem(25,$usecount,$ITEM[25]->{name}.'가 '.($USE->{param1}==1?'수명':'과로').'때문에 하늘로 돌아가셨습니다') if $usecount;
			
			my $ret='미노&nbsp;우유를 '.$val.'개 정제 했습니다';
			WriteLog(0,$DT->{id},$ret);
			return $ret;
		_local_
		
	@@use
		time	2h
		exp		1%
		job		낙농가	times/job_cow_time_rate
		scale	착유
		action	짠다
		price	0
		name	하드하게 젖을 짠다
		info	미노씨로부터 하드하게 젖을 짭니다
		param	2
		func	_local_1
			need		1	미노타우로스♀

@@ITEM
	no		26
	type	약
	code	mino_milk
	name	미노&nbsp;우유
	info	마시면 건강해요. 경영튼튼
	price	200
	cost	50
	pop		30m
	limit	2500/0
	scale	개
	point	15%
	@@use
		time	3m
		job		낙농가	times/job_cow_time_rate
		scale	개
		action	마신다
		price	0
		name	마신다
		info	미노&nbsp;우유를 마셔 보겠습니다
			use		1	미노&nbsp;우유
		func	_local_
			# ★미노&nbsp;우유를 마신다
			my $val=$count;
			my $ret="";
			
			if($count>=30)
			{
				$DT->{rank}-=$count*2;
				$DT->{rank}=0 if $DT->{rank}<0;
				WriteLog(2,0,$DT->{shopname}.'의 점주가 구급차로 옮겨졌습니다');
				WriteLog(2,0,'한번에 미노&nbsp;우유 '.$count.'통을 마신다는 것은 맨정신으로 할일이 아닙니다.');
				$ret="…일어나 보니 병원의 침대 위였습니다";
			}
			elsif($count>=10)
			{
				$ret='위장를 손상시켰습니다 한번에 미노&nbsp;우유 '.$count.'통은 과음입니다';
				WriteLog(0,$DT->{id},$ret);
			}
			else
			{
				$DT->{rank}+=int(rand($count+1)) +$count;
				$DT->{rank}=10000 if $DT->{rank}>10000;
				$ret='미노&nbsp;우유를 마셔 건강하게 된 것 같습니다';
				WriteLog(0,$DT->{id},$ret);
			}
			return $ret;
		_local_
	@@use
		time	72m
		job		낙농가	times/job_cow_time_rate
		scale	세트
		action	라이트 발효 시킨다
		price	0
		name	라이트 발효
		info	미노&nbsp;우유를 가볍고 발효 시켜 보겠습니다
			need	5	미노타우로스♀
			use		15	미노&nbsp;우유
			get		2	미노요구르트
	@@use
		time	144m
		job		낙농가	times/job_cow_time_rate
		scale	세트
		action	헤비 발효 시킨다
		price	0
		name	헤비 발효
		info	미노&nbsp;우유를 꽤 발효 시켜 보겠습니다
			need	10	미노타우로스♀
			use		15	미노&nbsp;우유
			get		1	미노치즈

@@ITEM
	no		35
	type	약
	code	mino_yogurt
	name	미노요구르트
	info	미노&nbsp;우유로부터 만든 고급 요구르트. 조금 미노 냄새가 난다
	price	3000
	cost	100
	pop	6h
	limit	300/0
	scale	개
	@@use
		time	10m
		job		낙농가	times/job_cow_time_rate
		scale	개
		action	먹는다
		price	0
		name	먹는다
		info	미노요구르트를 먹어 보겠습니다
		ngmsg	서민의 입맛에는 맞지 않는 것 같다…
			use		1	미노요구르트

@@ITEM
	no		36
	type	약
	code	mino_cheese
	name	미노치즈
	info	미노&nbsp;우유로부터 만든 고급 치즈 끝내주게 미노 냄새가 난다
	price	6000
	cost	200
	pop	10h
	limit	150/0
	scale	개
	@@use
		time	20m
		job		낙농가	times/job_cow_time_rate
		scale	개
		action	먹는다
		price	0
		name	먹는다
		info	미노치즈를 먹어 보겠습니다
		ngmsg	맛없어 토했다…
			use		1	미노치즈


@@ITEM
	no		27
	type	약
	code	seven_face
	name	칠면조&nbsp;통구이
	info	축하때 빠질 수 없어요
	price	10000
	cost	0
	limit	1/0
	scale	마리
	pop		1d
	@@use
		time	1h
		scale	마리
		action	먹는다
		price	0
		name	먹는다
		info	축하 할까요
		arg		nocount
			use		1	칠면조&nbsp;통구이	100%	배가&nbsp;부르게&nbsp;되었습니다

@@ITEM
	no		28
	type	약
	code	ramusyu
	name	조건의&nbsp;럼주
	info	그 전설의 용사를 좋아했다고 말하는 럼주입니다
	price	20000
	cost	0
	limit	1/0
	scale	개
	pop		1d
	@@use
		time	1h
		scale	개
		action	마신다
		price	0
		name	마신다
		info	축하 할까요
		arg		nocount
			use		1	조건의&nbsp;럼주	100%	좋은&nbsp;기분이&nbsp;되었습니다

@@ITEM
	no		29
	type	악세사리
	code	boots
	name	멋쟁이&nbsp;부츠
	info	이름처럼 세련된 부츠입니다
	price	20000
	cost	0
	limit	1/0
	scale	쌍
	pop		1d
	@@use
		time	1h
		scale	다리
		action	신는다
		price	0
		name	신고 외출한다
		info	거리를 다니며 축하 할까요
		arg		nocount
			use		1	멋쟁이&nbsp;부츠	100%	모두의&nbsp;시선을&nbsp;한사람이&nbsp;차지했습니다

@@ITEM
	no		77
	type	도구
	code	party
	name	축하&nbsp;세트
	info	뻑하고 가고 싶을 때에는 이것
	price	200000
	cost	0
	limit	1/0
	scale	세트
	@@use
		time	4h
		action	파티 개시
		price	0
		name	축하 파티
		info	오늘 밤은 술자리입니다
		func	popup
		param	1000,파티를&nbsp;열었습니다
		arg		nocount
			use		1	축하&nbsp;세트	100%	내일을&nbsp;향한&nbsp;활력이&nbsp;올라왔습니다

@@ITEM
	no		78
	type	개
	code	port-exp
	name	전직의&nbsp;한걸음
	info	전직하고 싶은 사람을 위해
	price	10000
	limit	1
	pop		1d
	scale	세트
	plus	1h
	@@USE
		time	6h
		action	전직 수행 개시
		arg		nocount
		name	약국으로 전직하고 싶다
		info	다른 직업의 기술 경험을 모두 버려 약을 취급하는 기술을 습득합니다
		okmsg	약국이 될 수 있던 것 같습니다
		param	15,9:10:12:14:15:16:17:66:20:21:22:23:25,0.5,drug
			use		1	전직의&nbsp;한걸음
		func	_local_
			######################################################################
			# ★숙련도 교환(지정 아이템에,다른 아이템의 숙련도를 이동시킨다)
			#   param1 숙련도를 플러스 하고 싶은 아이템의 번호(1~)
			#   param2 숙련도를 마이너스 하는 아이템의 번호(1~) (:단락으로 복수 지정화)
			#   param3 숙련도를 이동할 때의 계수(0~) (0.5라면 반으로 해 이동)
			#   주의：숙련도의 합계 체크는 하고 있지 않기 때문에,계수를 1보다 크게 하는 것은 그만두는 것이 좋습니다.
			######################################################################
			my $ret="";
			
			if($USE->{param1})
			{
				my $exp1=$DT->{exp}{$USE->{param1}};
				my $exp2=0;
				
				foreach my $exps (split(/:/,$USE->{param2}))
				{
					my $exp=$DT->{exp}{$exps};
					next if !$exp || $exps==$exp1;
					$exp2+=$exp;
					delete($DT->{exp}{$exps});
					my $msg=$ITEM[$exps]->{name}."의 숙련도 ".int($exp/10)."%가 0%이 되었습니다";
					$ret.=$msg."<br>";
					WriteLog(0,$DT->{id},$msg);
				}
				$exp2=int($exp2*$USE->{param3});
				$exp1+=$exp2;
				$exp1=1000 if $exp1>1000;
				my $msg=$ITEM[$USE->{param1}]->{name}."의 숙련도 ".int($DT->{exp}{$USE->{param1}}/10)."%가 ".int($exp1/10)."%이 되었습니다";
				$ret.=$msg."<br>";
				WriteLog(0,$DT->{id},$msg);
				$DT->{exp}{$USE->{param1}}=$exp1;
			}
			$DT->{job}=$USE->{param4},$ret.='직업이 「'.$main::JOBTYPE{$USE->{param4}}.'」로 되었습니다' if $USE->{param4} && $USE->{param4} ne '_default_';
			$DT->{job}='',$ret.='직업이 「부정」이 되었습니다' if $USE->{param4} eq '_default_';
			
			return $ret;
		_local_
	@@USE
		time	6h
		action	전직 수행 개시
		arg		nocount
		name	혁세공가게로 전직하고 싶다
		info	다른 직업의 기술 경험을 모두 버려 혁세공의 기술을 습득합니다
		okmsg	혁세공가게가 될 수 있던 것 같습니다
		func	_local_1
		param	16,9:10:12:14:15:16:17:66:20:21:22:23:25,0.5,tool
			use		1	전직의&nbsp;한걸음
	@@USE
		time	6h
		action	전직 수행 개시
		arg		nocount
		name	목세공가게로 전직하고 싶다
		info	다른 직업의 기술 경험을 모두 버려 목세공의 기술을 습득합니다
		okmsg	목세공가게가 될 수 있던 것 같습니다
		func	_local_1
		param	17,9:10:12:14:15:16:17:66:20:21:22:23:25,0.5,tool
			use		1	전직의&nbsp;한걸음
	@@USE
		time	6h
		action	전직 수행 개시
		arg		nocount
		name	장식 세공가게로 전직하고 싶다
		info	다른 직업의 기술 경험을 모두 버려 장식 세공의 기술을 습득합니다
		okmsg	장식 세공가게가 될 수 있던 것 같습니다
		func	_local_1
		param	66,9:10:12:14:15:16:17:66:20:21:22:23:25,0.5,tool
			use		1	전직의&nbsp;한걸음
	@@USE
		time	6h
		action	전직 수행 개시
		arg		nocount
		name	검 가게로 전직하고 싶다
		info	다른 직업의 기술 경험을 모두 버려 검 가게에 필요한 기술을 습득합니다
		okmsg	검 가게가 될 수 있던 것 같습니다
		func	_local_1
		param	20,9:10:12:14:15:16:17:66:20:21:22:23:25,0.5,weapon
			use		1	전직의&nbsp;한걸음
	@@USE
		time	6h
		action	전직 수행 개시
		arg		nocount
		name	방패 가게로 전직하고 싶다
		info	다른 직업의 기술 경험을 모두 버려 방패 가게에 필요한 기술을 습득합니다
		okmsg	방패 가게가 될 수 있던 것 같습니다
		func	_local_1
		param	21,9:10:12:14:15:16:17:66:20:21:22:23:25,0.5,armor
			use		1	전직의&nbsp;한걸음
	@@USE
		time	6h
		action	전직 수행 개시
		arg		nocount
		name	갑옷가게로 전직하고 싶다
		info	다른 직업의 기술 경험을 모두 버려 갑옷가게에 필요한 기술을 습득합니다
		okmsg	갑옷가게가 될 수 있던 것 같습니다
		func	_local_1
		param	22,9:10:12:14:15:16:17:66:20:21:22:23:25,0.5,armor
			use		1	전직의&nbsp;한걸음
	@@USE
		time	6h
		action	전직 수행 개시
		arg		nocount
		name	지팡이 가게로 전직하고 싶다
		info	다른 직업의 기술 경험을 모두 버려 장 가게에 필요한 기술을 습득합니다
		okmsg	지팡이 가게가 될 수 있던 것 같습니다
		func	_local_1
		param	23,9:10:12:14:15:16:17:66:20:21:22:23:25,0.5,weapon
			use		1	전직의&nbsp;한걸음
	@@USE
		time	6h
		action	전직 수행 개시
		arg		nocount
		name	탐광부로 전직하고 싶다
		info	다른 직업의 기술 경험을 모두 버려 탐광부에게 필요한 기술을 습득합니다
		okmsg	탐광부가 될 수 있던 것 같습니다
		func	_local_1
		param	9,9:10:12:14:15:16:17:66:20:21:22:23:25,0.5,material
			use		1	전직의&nbsp;한걸음
	@@USE
		time	6h
		action	전직 수행 개시
		arg		nocount
		name	나무꾼으로 전직하고 싶다
		info	다른 직업의 기술 경험을 모두 버려 나무꾼에 필요한 기술을 습득합니다
		okmsg	나무꾼이 될 수 있던 것 같습니다
		func	_local_1
		param	12,9:10:12:14:15:16:17:66:20:21:22:23:25,0.5,material
			use		1	전직의&nbsp;한걸음
	@@USE
		time	6h
		action	전직 수행 개시
		arg		nocount
		name	책방으로 전직하고 싶다
		info	다른 직업의 기술 경험을 모두 버려 책방에 필요한 기술을 습득합니다
		okmsg	책방이 될 수 있던 것 같습니다
		func	_local_1
		param	10,9:10:12:14:15:16:17:66:20:21:22:23:25,0.5,book
			use		1	전직의&nbsp;한걸음
	@@USE
		time	6h
		action	전직 수행 개시
		arg		nocount
		name	낙농가로 전직하고 싶다
		info	다른 직업의 기술 경험을 모두 버려 낙농가에 필요한 기술을 습득합니다
		okmsg	낙농가가 될 수 있던 것 같습니다
		func	_local_1
		param	25,9:10:12:14:15:16:17:66:20:21:22:23:25,0.5,cow
			use		1	전직의&nbsp;한걸음
	@@USE
		time	6h
		action	전직 수행 개시
		arg		nocount
		name	행상인으로 전직하고 싶다
		info	다른 직업의 기술 경험을 모두 버려 행상인에 필요한 기술을 습득합니다
		okmsg	행상인이 될 수 있던 것 같습니다
		func	_local_1
		param	14,9:10:12:14:15:16:17:66:20:21:22:23:25,0.5,peddle
			use		1	전직의&nbsp;한걸음
	@@USE
		time	6h
		action	전직 수행 개시
		arg		nocount
		name	간판을 구제하고 싶다
		info	당신의 어깨에 무겁게 짓누르고 있는 그 간판을 구제합니다
		func	_local_1
		param	0,,0,_default_
			use		1	전직의&nbsp;한걸음

@@ITEM
	no		79
	type	도구
	code	gift
	name	상품권
	info	갖고 싶은 것을 손에 넣자!
	price	10000
	cost	10
	limit	10/0
	scale	장
	@@USE
		time	1h
		action	교환
		name	지도 세트와 교환
		info	여러가지 지도를 모아 교환합니다
		okmsg	이용 감사합니다
			use		2	상품권
			get		1	가까운&nbsp;산의&nbsp;지도
			get		1	가까운&nbsp;광산의&nbsp;지도
			get		1	검의&nbsp;도시의&nbsp;지도
	@@USE
		time	1h
		action	교환
		name	입문본세트와 교환
		info	여러가지 책을 모아 교환합니다
		okmsg	이용 감사합니다
			use		5	상품권
			get		1	15
			get		1	16
			get		1	17
	@@USE
		time	1h
		action	교환
		name	상급본세트와 교환
		info	여러가지 책을 모아 교환합니다
		okmsg	이용 감사합니다
			use		10	상품권
			get		1	20
			get		1	21
			get		1	22
			get		1	23
	@@USE
		time	1h
		action	교환
		name	수행&nbsp;킷과 교환
		info	스스로를 닦고 싶은 사람에게
		okmsg	이용 감사합니다
			use		2	상품권
			get		1	수행&nbsp;킷
	@@USE
		time	1h
		action	교환
		name	미노타우로스와 교환
		info	미노타우로스를 사랑하는 분께
		okmsg	이용 감사합니다
			use		1	상품권
			get		1	25

@@event
	start		10%
	basetime	5h
	plustime	5h
	code		happy
	startmsg	감사제가 이 거리에서 시작되었습니다.
	endmsg		감사제는 막을 닫았습니다.
	info		감사제로 거리는 떠들썩하고 있습니다.
	func		_local_
		my $time=$main::TIMESPAN;
		$time=10*3600 if $time>10*3600; # 최대10% 제한
		$time=int($time/36);
		
		foreach(@DT)
		{
			$_->{rank}+=int(rand($time));
			$_->{rank}=10000 if $_->{rank}>10000;
		}
		return 0;
	_local_

@@EVENT				#★이벤트 정의 선언
	start		7%		#★이벤트 발동 확률(1일)
	basetime	12h		#★이벤트 지속 시간 베이스
	plustime	24h		#★이벤트 지속 시간 랜덤 증가.(랜덤으로 0~24 h플러스)
	code		boom-posyon	#★코드(유니크)
	startmsg	항구에서는 약간의 포션 붐입니다	#★이벤트 발동시 메시지
	endmsg		포션 붐이 끝난 것 같습니다		#★이벤트 종료시 메시지
	info		포션 관련 상품이 인기입니다			#★이벤트 발동중 메시지
		param	약초			pop/1.5	#★이벤트 내용(아이템 파라미터 증감 지시)
		param	포션		pop/1.5	#  서식:아이템 명칭,파라미터명[+-/*]수치
		param	하이&nbsp;포션	pop/1.5 #  각각의 아이템의 파라미터를 증감시킵니다.
		param	에테르		pop/1.5 #  파라미터명은 customize.txt 와 item.cgi 로 확인해 주세요.
		param	하이&nbsp;에테르	pop/1.5 #  덧붙여 pop==popular,money==price,base==pricebase,half==pricehalf
		param	에리풀			pop/1.5 #  로 자동변역됩니다.
		param	약초			point*2 #  주의점으로서 pop 등은 값이 시간(초수)이므로,
		param	포션		point*2 #  매출율을 올리고 싶은 경우는,값을 감소시키게 됩니다.
		param	하이&nbsp;포션	point*3 #  덧붙여서 이 예에서는,약초계의 아이템의 매출율을 1.5배.
		param	에테르		point*2 #  매각시의 인기 상승률을 2~4배에 올리고 있습니다.
		param	하이&nbsp;에테르	point*3
		param	에리풀			point*4

@@EVENT
	start		10%
	basetime	6h
	plustime	24h
	code		ken-sale
	startmsg	검의 수요가 높아지고 있는 것 같습니다
	endmsg		검의 수요가 통상 레벨에 돌아왔습니다
	info		검의 수요가 높아지고 있습니다
		param	목검				pop/2
		param	철검				pop/2
		param	강철검			pop/2
		param	미스릴검		pop/2
		param	오리하르콘검	pop/2
@@EVENT
	start		10%
	basetime	6h
	plustime	24h
	code		tate-sale
	startmsg	방패의 수요가 높아지고 있는 것 같습니다
	endmsg		방패의 수요가 통상 레벨에 돌아왔습니다
	info		방패의 수요가 높아지고 있습니다
		param	가죽방패				pop/2
		param	나무방패				pop/2
		param	철방패				pop/2
		param	강철방패			pop/2
		param	미스릴방패		pop/2
		param	오리하르콘방패	pop/2
@@EVENT
	start		10%
	basetime	6h
	plustime	24h
	code		yoroi-sale
	startmsg	갑옷의 수요가 높아지고 있는 것 같습니다
	endmsg		갑옷의 수요가 통상 레벨에 돌아왔습니다
	info		갑옷의 수요가 높아지고 있습니다
		param	가죽흉갑			pop/2
		param	나무흉갑			pop/2
		param	철갑옷				pop/2
		param	강철갑옷			pop/2
		param	미스릴갑옷		pop/2
		param	오리하르콘갑옷	pop/2
@@EVENT
	start		10%
	basetime	6h
	plustime	24h
	code		tue-sale
	startmsg	지팡이의 수요가 높아지고 있는 것 같습니다
	endmsg		지팡이의 수요가 통상 레벨에 돌아왔습니다
	info		지팡이의 수요가 높아지고 있습니다
		param	나무지팡이				pop/2
		param	철지팡이				pop/2
		param	강철지팡이			pop/2
		param	미스릴지팡이		pop/2
		param	오리하르콘지팡이	pop/2
@@EVENT
	start		50%		#★발동 확률은50%이지만,발동은 아래의 「startfunc」나름.
	start		-1		#발동하지 않는다
	basetime	12h		#★12 h로 이벤트 종료이지만,실제 종료할지 어떨지는 아래의 「endfunc」나름.
	plustime	0		#
	code		priceup-yakusou
	startmsg	약초가 부족합니다
	endmsg		약초 부족이 해소되었습니다
	info		약초가 부족해 관련 상품의 가격이 상승하고 있습니다
	startfunc	stock_le(1,70)		#★이벤트 발동 조건 판단의 함수 호출.(inc-event-function.cgi)
	#endfunc		stock_ge(1,71)		#★이벤트 종료 조건 판단의 함수 호출.(inc-event-function.cgi)
		param	약초			price*2		#★표준 가격이  2배가 됩니다.
		param	포션		price*1.5
		param	하이&nbsp;포션	price*1.5
		param	에테르		price*1.5
		param	하이&nbsp;에테르	price*1.5
		param	에리풀			price*1.5
		param	약초			pop*2		#★이 경우는 매출율이1/2에 내립니다.
		param	포션		pop*1.5
		param	하이&nbsp;포션	pop*1.5
		param	에테르		pop*1.5
		param	하이&nbsp;에테르	pop*1.5
		param	에리풀			pop*1.5
@@EVENT
	start		50%
	start		-1
	basetime	12h
	plustime	0
	code		priceup-tetu
	startmsg	철이 부족합니다
	endmsg		철부족이 해소되었습니다
	info		철이 부족해 관련 상품의 가격이 상승하고 있습니다
	startfunc	stock_le(5,70)
	#endfunc		stock_ge(5,71)
		param	철괴			price*2
		param	철검			price*1.5
		param	강철검		price*1.5
		param	철방패			price*1.5
		param	강철방패		price*1.5
		param	철갑옷			price*1.5
		param	강철갑옷		price*1.5
		param	철지팡이			price*1.5
		param	강철지팡이		price*1.5
		param	철괴			pop*2
		param	철검			pop*1.5
		param	강철검		pop*1.5
		param	철방패			pop*1.5
		param	강철방패		pop*1.5
		param	철갑옷			pop*1.5
		param	강철갑옷		pop*1.5
		param	철지팡이			pop*1.5
		param	강철지팡이		pop*1.5
@@EVENT
	start		50%
	start		-1
	basetime	12h
	plustime	0
	code		priceup-misuriru
	startmsg	미스릴이 부족합니다
	endmsg		미스릴 부족이 해소되었습니다
	info		미스릴이 부족해 관련 상품의 가격이 상승하고 있습니다
	startfunc	stock_le(6,70)
	#endfunc		stock_ge(6,71)
		param	미스릴덩어리			price*2
		param	미스릴검		price*1.5
		param	미스릴방패		price*1.5
		param	미스릴갑옷		price*1.5
		param	미스릴지팡이		price*1.5
		param	미스릴덩어리			pop*2
		param	미스릴검		pop*1.5
		param	미스릴방패		pop*1.5
		param	미스릴갑옷		pop*1.5
		param	미스릴지팡이		pop*1.5
@@EVENT
	start		50%
	start		-1
	basetime	12h
	plustime	0
	code		priceup-oriharukon
	startmsg	오리하르콘이 부족합니다
	endmsg		오리하르콘 부족이 해소되었습니다
	info		오리하르콘이 부족해 관련 상품의 가격이 상승하고 있습니다
	startfunc	stock_le(7,70)
	#endfunc		stock_ge(7,71)
		param	오리하르콘덩어리			price*2
		param	오리하르콘검		price*1.5
		param	오리하르콘방패		price*1.5
		param	오리하르콘갑옷		price*1.5
		param	오리하르콘지팡이		price*1.5
		param	오리하르콘덩어리			pop*2
		param	오리하르콘검		pop*1.5
		param	오리하르콘방패		pop*1.5
		param	오리하르콘갑옷		pop*1.5
		param	오리하르콘지팡이		pop*1.5

@@EVENT
	start		10%
	basetime	48h
	plustime	24h
	code		plusdown-yakusou
	startmsg	약초 재배 업자가 약초의 판매를 거부하고 있는 것 같습니다
	endmsg		약초 재배 업자가 약초의 판매를 재개했습니다
	info		시장의 약초 공급이 멈추어 있습니다
		param	약초			plus=-180		#★시장 감소
@@EVENT
	start		10%
	basetime	12h
	plustime	12h
	code		plusup-tetu
	startmsg	새롭게 철광맥이 발견되었습니다
	endmsg		새로운 철광맥이 폐산했습니다
	info		철유통량이 급격하게 증가하고 있습니다
		param	철괴			plus=720		#★시장에의 입하 페이스가 480s.
@@EVENT
	start		7%
	basetime	9h
	plustime	16h
	code		plusup-misuriru
	startmsg	새롭게 미스릴 광맥이 발견되었습니다
	endmsg		새로운 미스릴 광맥이 폐산했습니다
	info		미스릴유통량이 급격하게 증가하고 있습니다
		param	미스릴덩어리			plus=960
@@EVENT
	start		5%
	basetime	6h
	plustime	18h
	code		plusup-oriharukon
	startmsg	새롭게 오리하르콘 광맥이 발견되었습니다
	endmsg		새로운 오리하르콘 광맥이 폐산했습니다
	info		오리하르콘유통량이 급격하게 증가하고 있습니다
		param	오리하르콘덩어리			plus=1200


# 상위 우선으로 도둑 이벤트
@@EVENT
	start		100% #old50%
	basetime	0h		#★지속계의 이벤트는 아니기 때문에 시간은 0.
	plustime	0h
	code		manbiki
	info		도둑
	startfunc	_local_(400,200)
		#★실은 이 함수가 이벤트의 본체가 되어 있다
		my($hitproba,$breakproba)=@_;
		#노려지는 확률,로보트 파괴 확률
		
		foreach my $DT (@DT)
		{
			next if rand(1000)>$hitproba;
			
			if($DT->{item}[@@ITEMNO"가게&nbsp;보는&nbsp;인형로봇"-1])
			{
				return (0,$DT->{shopname}.'에 도둑이 들어왔습니다만 저지되었습니다') if rand(1000)>$breakproba;
				
				$DT->{item}[@@ITEMNO"가게&nbsp;보는&nbsp;인형로봇"-1]--;
				return (0,$DT->{shopname}.'에 도둑이 들어와 '.$ITEM[@@ITEMNO"가게&nbsp;보는&nbsp;인형로봇"]->{name}.'가 파괴되었습니다');
			}
			
			my $count=0;
			foreach my $idx (0..$DT->{showcasecount}-1)
			{
				my $itemno=$DT->{showcase}[$idx];
				next if !$itemno;
				
				my $cnt=int($DT->{item}[$itemno-1]/10);
				$DT->{item}[$itemno-1]-=$cnt;
				$count+=$cnt*$DT->{price}[$idx];
			}
			return (0,$DT->{shopname}.'가 총액 '.GetMoneyString($count).'에 상당한 도둑 피해를 당했습니다') if $count;
			return (0,$DT->{shopname}.'에 들어간 도둑범은 아무것도 훔치지 않고 도망쳤습니다');
		}
		return 0;
	_local_

@@EVENT
	start		20%
	basetime	0h
	plustime	0h
	code		goutou
	info		강도
	startfunc	_local_(700)
		#★실은 이 함수가 이벤트의 본체가 되어 있다
		my($hitproba)=@_;
		#노려지는 확률
		
		foreach my $DT (@DT)
		{
			next if rand(1000)>$hitproba;
			
			if($DT->{item}[@@ITEMNO"가게&nbsp;보는&nbsp;인형로봇"-1])
			{
				$DT->{item}[@@ITEMNO"가게&nbsp;보는&nbsp;인형로봇"-1]--;
				return (0,$DT->{shopname}.'에 강도가 들어와 '.$ITEM[@@ITEMNO"가게&nbsp;보는&nbsp;인형로봇"]->{name}.'가 파괴되었습니다');
			}
			
			$DT->{rank}-=int($DT->{rank}/5);
			
			my $count=0;
			foreach my $idx (0..$DT->{showcasecount}-1)
			{
				my $itemno=$DT->{showcase}[$idx];
				next if !$itemno;
				
				my $cnt=int($DT->{item}[$itemno-1]/4);
				$DT->{item}[$itemno-1]-=$cnt;
				$count+=$cnt*$DT->{price}[$idx];
			}
			return (0,$DT->{shopname}.'가 총액'.GetMoneyString($count).'상당한 강도 피해를 당했습니다') if $count;
			return (0,$DT->{shopname}.'에 들어간 강도범은 아무것도 취하지 않고 도망쳤습니다');
		}
		return 0;
	_local_


# 저자금 우선으로 자금원조 이벤트
@@EVENT
	start		30%
	code		getmoney
	info		자금원조
	startfunc	_local_(100000)
		my($money)=@_;
		
		foreach(reverse(@DT))
		{
			next if rand(1000)>300;
			
			$_->{money}+=$money;
			$_->{money}=$main::MAX_MONEY if $_->{money}>$main::MAX_MONEY;
			return (0,$_->{shopname}.'에 '.GetMoneyString($money).'의 보조금이 지급되었습니다');
		}
		return 0;
	_local_

# 하위 우선으로 인기 업 이벤트
@@EVENT
	start		30%
	basetime	0h
	plustime	0h
	code		getpop
	info		인기 업
	startfunc	_local_(1000)
		my($pop)=@_;
		
		foreach(reverse(@DT))
		{
			next if rand(1000)>300;
			
			$_->{rank}+=$pop;
			$_->{rank}=10000 if $_->{rank}>10000;
			return (0,$_->{shopname}.'가 잡지로 소개되고 인기가 오른 것 같습니다');
		}
		return 0;
	_local_

# 복권 이벤트
@@EVENT
	start		50%
	basetime	0h
	plustime	0h
	code		loto
	info		복권 추첨
	startfunc	_local_
		WriteLog(2,0,"복권의 추첨을 했습니다");
		foreach my $DT (@DT)
		{
			my $count=$DT->{item}[11-1];
			$DT->{item}[11-1]=0;
			next if !$count;
			
			foreach(1..$count)
			{
				my $rnd=rand(6096454);
				my $hit=0;
				
				$hit=5 if $rnd<152411;
				$hit=4 if $rnd<10000;
				$hit=3 if $rnd<216;
				$hit=2 if $rnd<6;
				$hit=1 if $rnd<1;
				
				if($hit)
				{
					my $getmoney=(0,1000000000,150000000,5000000,100000,10000)[$hit];
					
					$DT->{money}+=$getmoney;
					$DT->{money}=$main::MAX_MONEY if $DT->{money}>$main::MAX_MONEY;
					WriteLog(($hit<=3?1:2),0,$DT->{shopname}."가 $hit등 ".GetMoneyString($getmoney)."(을)를 맞혔습니다!");
				}
			}
		}
		return 0;
	_local_

@@FUNCINIT
#감정의&nbsp;진수를 가지고 있는 경우,쇼핑에 필요한 시간을3/4로 한다.
$TIME_SEND_ITEM=int($TIME_SEND_ITEM/4*3) if $DT->{item}[@@ITEMNO"감정의&nbsp;진수"-1];

#직업이 「행상인」의 경우,쇼핑에 필요한 시간을1/2로 한다.
$TIME_SEND_ITEM=int($TIME_SEND_ITEM/2) if $DT->{job} eq 'peddle';

@@FUNCITEM
######################################################################
# ★본or지도가 너덜너덜이 되어 파기한다고 하는 처리
######################################################################
sub lostbook
{
	my $itemno=$USE->{itemno};
	if(rand(1000)<$USE->{param1})
	{
		UseItem($itemno,1,$ITEM[$itemno]->{name}.'를 읽을 수 없을 정도로 너덜너덜이 되었으므로 파기했습니다');
	}
	return "";
}
######################################################################
# ★인기 업(범용)
#   param1 업 포인트
#   param2 최근의 사건용 댓글 표시 방식:●●상점이 param2
######################################################################
sub popup
{
	my $up=int($USE->{param1}*(2-$DT->{rank}/5000));
	$DT->{rank}+=$up;
	$DT->{rank}=10000 if $DT->{rank}>10000;
	
	my $ret=$USE->{param2}."：인기 ".int($up/100)."%업";
	WriteLog(0,$DT->{id},$ret);
	WriteLog(3,0,$DT->{shopname}."가 ".$USE->{param2});
	
	return $ret;
}

@@FUNCUPDATE
sub UpdateResetBefore #결산 직전의 처리(함수명 고정)
{
	UpdateTodayPrize();
	
	sub UpdateTodayPrize
	{
		#상품 수여
		my @TOP123=(
			[
				['상품권',	[[@@ITEMNO "상품권",5],			],],
				['상품권',	[[@@ITEMNO "상품권",4],			],],
				['상품권',	[[@@ITEMNO "상품권",3],			],],
				['상품권',	[[@@ITEMNO "상품권",2],			],],
				['상품권',	[[@@ITEMNO "상품권",1],			],],
				['로보트',	[[@@ITEMNO "가게&nbsp;보는&nbsp;인형로봇",1],		],],
				['축하 상품',[[@@ITEMNO "칠면조&nbsp;통구이",1],	],],
				['축하 상품',[[@@ITEMNO "조건의&nbsp;럼주",1],	],],
				['축하 상품',[[@@ITEMNO "멋쟁이&nbsp;부츠",1],	],],
			],
			[
				['상품권',	[[@@ITEMNO "상품권",3],			],],
				['상품권',	[[@@ITEMNO "상품권",3],			],],
				['상품권',	[[@@ITEMNO "상품권",2],			],],
				['상품권',	[[@@ITEMNO "상품권",2],			],],
				['상품권',	[[@@ITEMNO "상품권",1],			],],
				['금단의&nbsp;책',	[[@@ITEMNO "금단의&nbsp;책",1],			],],
				['축하 상품',[[@@ITEMNO "칠면조&nbsp;통구이",1],	],],
				['축하 상품',[[@@ITEMNO "조건의&nbsp;럼주",1],	],],
				['축하 상품',[[@@ITEMNO "멋쟁이&nbsp;부츠",1],	],],
			],
			[
				['상품권',	[[@@ITEMNO "상품권",2],			],],
				['상품권',	[[@@ITEMNO "상품권",2],			],],
				['상품권',	[[@@ITEMNO "상품권",2],			],],
				['상품권',	[[@@ITEMNO "상품권",1],			],],
				['상품권',	[[@@ITEMNO "상품권",1],			],],
				['광고&nbsp;팩',	[[@@ITEMNO "광고&nbsp;팩",1],		],],
				['축하 상품',[[@@ITEMNO "칠면조&nbsp;통구이",1],	],],
				['축하 상품',[[@@ITEMNO "조건의&nbsp;럼주",1],	],],
				['축하 상품',[[@@ITEMNO "멋쟁이&nbsp;부츠",1],	],],
			],
			[
				['상품권',	[[@@ITEMNO "상품권",2],			],],
				['상품권',	[[@@ITEMNO "상품권",1],			],],
				['상품권',	[[@@ITEMNO "상품권",1],			],],
				['광고&nbsp;팩',	[[@@ITEMNO "광고&nbsp;팩",1],		],],
				['광고&nbsp;팩',	[[@@ITEMNO "광고&nbsp;팩",1],		],],
				['광고&nbsp;팩',	[[@@ITEMNO "광고&nbsp;팩",1],		],],
				['축하 상품',[[@@ITEMNO "칠면조&nbsp;통구이",1],	],],
				['축하 상품',[[@@ITEMNO "조건의&nbsp;럼주",1],	],],
				['축하 상품',[[@@ITEMNO "멋쟁이&nbsp;부츠",1],	],],
			],
		);
		
		TopGetItem($DT[0],$TOP123[0],"이번 우승한 ") if defined($DT[0]);
		TopGetItem($DT[1],$TOP123[1],"아깝게도 2위한 ") if defined($DT[1]);
		TopGetItem($DT[2],$TOP123[2],"빠듯이 입상한 ") if defined($DT[2]);
	
		for(my $i=9; $i<$#DT; $i+=10)
		{
			TopGetItem($DT[$i],$TOP123[3],"특별상으로 해서 ".($i+1)."위한 ") if defined($DT[$i]);
		}
		
		sub TopGetItem
		{
			my($DT,$itemlist,$head)=@_;
			
			my @list=@{$itemlist};
			my @getitem=@{$list[int(rand($#list+1))]};
			
			my $msg=$head.$DT->{shopname}."씨에게는 ".$getitem[0]."가 주어졌습니다";
			WriteLog(2,0,0,$msg,1);
			foreach (@{$getitem[1]})
			{
				my @itemnocount=@{$_};
				
				my $cnt=AddItem($DT,$itemnocount[0],$itemnocount[1]);
				my $ITEM=$ITEM[$itemnocount[0]];
				WriteLog(0,$DT->{id},0,$head."상품으로서 ".$ITEM->{name}."(을)를 ".$itemnocount[1].$ITEM->{scale}." 획득했습니다",1);
				$cnt=$itemnocount[1]-$cnt;
				WriteLog(0,$DT->{id},0,"그러나 최대 소지수이상이었으므로 ".$cnt.$ITEM->{scale}." 파기했습니다",1) if $cnt;
			}
		}
	}
}

sub UpdateResetAfter #결산 직후의 처리(함수명 고정)
{
	UpdateTodayEraseTech();
	
	sub UpdateTodayEraseTech
	{
		foreach my $DT (@DT)
		{
			my $expsum=0;
			foreach(values(%{$DT->{exp}}))
			{
				$expsum+=$_;
			}
			#$expsum=5000 if $expsum>5000;
			
			next if $expsum<=4000;
			$expsum-=4000;
			
			foreach my $itemno (@@ITEMNO"대장간의&nbsp;기술",@@ITEMNO"마법의&nbsp;지식",@@ITEMNO"해체가게의&nbsp;영혼",@@ITEMNO"감정의&nbsp;진수")
			{
				if($DT->{item}[$itemno-1] && rand(14000)<$expsum)
				{
					my $msg="초심을 잊어 ".$DT->{shopname}."씨의 ".$ITEM[$itemno]->{name}."가 없어졌습니다";
					WriteLog(2,0,0,$msg,1);
					WriteLog(0,$DT->{id},0,$ITEM[$itemno]->{name}."(을)를 잃었습니다",1);
					$DT->{item}[$itemno-1]--;
				}
			}
		}
	}
}

@@FUNCNEW

# @@DEFINE Set NewShopMoney NewShopTime NewShopItem 의 처리
$DT->{money}=@@VALUE"NewShopMoney" if @@VALUE"NewShopMoney";
$DT->{time}=$NOW_TIME-eval(@@VALUE"NewShopTime") if @@VALUE"NewShopTime";
if(@@VALUE"NewShopItem")
{
	my %item=split /:/,@@VALUE"NewShopItem";
	while(my($key,$val) =each %item)
	{
		foreach my $item (@ITEM)
		{
			 $DT->{item}[$item->{no}-1]+=$val,last if $key eq $item->{code} or $key eq $item->{name};
		}
	}
}

# $DEFINE_FUNCNEW_NOLOG=1 를 설정하면,시스템측의 최근의 사건 새로운 치장 개점 메시지를 억제합니다.
# $DEFINE_FUNCNEW_NOLOG=1;
# WriteLog(1,0,0,$DT->{shopname}."가 엔트리 했습니다",1);

# 그 외,새로운 치장 개점시에 독자적인 처리를 추가할 수 있습니다.

@@FUNCSHOPIN

SetUserDataEx($DT,'_so_move_in',$NOW_TIME); # 이전 시각을 기록
if($DT->{job} eq 'peddle')
{
	# 행상인(peddle)에게는 이전 소비 시간의 것1/2을 반환
	$DT->{_MoveTownTime}=int($DT->{_MoveTownTime}/2);
	EditTime($DT,$DT->{_MoveTownTime});
	WriteLog(0,$DT->{id},0,'이전 시간이 절반인 '.GetTime2HMS($DT->{_MoveTownTime}).'로 끝난 것 같습니다',1);
}
if(GetUserDataEx($DT,'_so_present_money'))
{
	WriteLog(0,$DT->{id},0,'이전원의 거리로부터 전별 금품으로서 '.GetMoneyString(GetUserDataEx($DT,'_so_present_money')).'를 받았습니다',1);
	SetUserDataEx($DT,'_so_present_money','');
}

@@FUNCSHOPOUT

if(GetUserDataEx($DT,'_so_move_in'))
{
	my $present_money=int(($NOW_TIME-GetUserDataEx($DT,'_so_move_in'))/86400)*5000;
	EditMoney($DT,$present_money); # 체재 기간 1일에 부착\5000을 전별 금품으로서 자금에
	SetUserDataEx($DT,'_so_present_money',$present_money);
	SetUserDataEx($DT,'_so_move_in',''); # $DT->{user}{_so_move_in} 를 삭제
}

@@FUNCBUY
# package item 입니다.
# 
# $item::BUY 를 이용할 수 있습니다.$item::BUY 의 구조는 매뉴얼의 @@ITEM funcb 를 봐 주세요.
# 상품 마다의 처리는 @@ITEM funcb 를 이용해 주세요.

if($BUY->{whole})
{
	# 시장으로부터의 구입의 경우,\500000에 부착 1매의 상품권을 증정 한다.
	my $price=$BUY->{num}*$BUY->{price};
	my $count=int $price/500000;
	
	$count=AddItemSub(@@ITEMNO"상품권",$count,$BUY->{dt}) if $count;
	WriteLog(0,$BUY->{dt}{id},'시장으로부터 상품권을'.$count.'매 받았습니다') if $count;
}

@@END #정의 종료 선언(이후 댓글 취급)

------------
●간단한 설명
------------

모든 상품/이벤트는 이 파일을 변환해 작성됩니다.

이 파일을 사용자 지정 하는 것으로,완전히 다른 세계의 SOLD OUT 도
만들 수가 있습니다.그야말로,게임의 방향성도 바꿀 수가 있을 것
입니다.(예를 들면,monster 합성 게임이라든지,무역 게임이라든지)

그러한 개성적인 사용자 지정가 나오면(자) 재미있을 것이고 기쁘다라고 생각해,
스크립트의 프리 공개와 사용자 지정 방법을 준비한 나름입니다.

이 표준 아이템 데이터는,샘플이라고 하는 이유가 강합니다.(이)라고는 말해
도 밸런스 조정은 1년에 걸쳐서 가고 있기 때문에 그 나름대로 놀 수 있는 레벨이라면
생각합니다만,시스템의 퍼텐셜을 충분히 꺼내고 있다고는 말할 수 없는가
도 알려지지 않습니다.

그러므로,부디,사용자 지정 해 보세요.단순하게 상품명을 바꿀 뿐
그렇지만 재미있습니다만,독자적인 상품/개발 방법/이벤트를 추가하는 일도 비교적간
단지 할 수 있습니다.도전해 보세요.

상품 데이터의 갱신은,본파일을 변경해 업 로드 후,관리 메뉴로
「상품 데이터 생성/갱신」을 실시하는 것으로 가능합니다.그 때,에러등이 있으면
표시됩니다.

데이터 정의의 서식은,설명서안의 사용자 지정 문서와 실제로 이 파
일을 참조해,연구해 보세요.특히,이 파일은 샘플이 된다
(이)라고 생각합니다.

프로그램 읽을 수 있는 사람은 makeitem.cgi 를 해석해 보세요.상품 데이터를
편집하기에 즈음해 불편한 점은 makeitem.cgi 를 개조하면 편해질지도 모르고
선.

덧붙여 SOLD OUT 는 앞으로도 진화시켜 몇개(살) 숲입니다.그 때,정의 데이터
의 호환성이 손상될 가능성이 있습니다.물론,그러한 일이 오코시 이거 참
없게 노력합니다만,그러한 가능성이 있다고 하는 것을 양해해 주십시오.

추신

사용자 지정에 흥미를 가져 주는 여러분의 덕분에,여러가지 타입의
SOLD OUT 를 보게 되었습니다.몹시 기쁘다고 생각하고 있습니다.고마워요
있습니다.

