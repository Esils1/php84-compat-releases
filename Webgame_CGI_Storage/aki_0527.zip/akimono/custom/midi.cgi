# MIDIの설정フｫ｡イル 2005/03/30 유래

# -------- 먠믦븫빁 ----------
# MIDIのフｫ｡イル名を変更できます。
# CGI빶긖ー긫ー궻궴궞귣궳궼갅궞궞귩 http:// 궔귞럑귏귡긬긚궸럚믦궢귏궥갃

$MIDI_URL = "midi.mid";

# ----------------------------

$NOMENU=1;
$Q{bk}="none";
print "Content-type: text/html; charset=UTF-8\n\n";

my $bgmtag;

if ($ENV{HTTP_USER_AGENT}=~ /MSIE/ && $ENV{HTTP_USER_AGENT}!~ /Opera/)
	{
	$bgmtag=qq|<BGSOUND src="$MIDI_URL" loop=infinite>|;
	}
	else
	{
	$bgmtag=qq|<EMBED src="$MIDI_URL" width=2 height=2 autostart=true loop=true>|;
	}
print "Content-type: text/html; charset=UTF-8\n\n";
print <<"EOM";
<html lang="ja">
<HEAD>
<TITLE>BGM</TITLE>
$bgmtag
</HEAD>
<BODY>
</HTML>
EOM
exit;
1;