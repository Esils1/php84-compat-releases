# 긚タ긞긲깓ー깑 2005/03/30 뾕샮
#
# 各種著作権示用です。新たな素材・プログラｫ烽gみ込む際に，ここに追加しましょう。
# HTMLの知識があれば，見よう見まねでできると思います。
#
# 긚タ긞긲깓ー깑귉궻깏깛긏귩둖궢궫귟갅뽞뿧궫궶궘궢궲궼궋궚귏궧귪갃
# 著作権示は目立つよう適切に行う必要があり，これを怠るとﾛI問題になる場合があります。

DataRead();
CheckUserPass(1);
OutError("비밀번호 누락의 위험이 있으므로 표시 중지합니다.") if $Q{u};
$disp.="<BIG>●개발 스탭 롤</BIG><br><br>";
$disp.=$TB.$TR.$TD.GetTagImgKao("안내인","guide").$TD;
$disp.='게임의 각 부분에 대한 저작권은, 각각 아래와 같은 분들에게 귀속합니다.<br>';
$disp.='덧붙여 소재를 게임으로부터 직접 꺼내 이용하지 말아 주세요.'.$TRE.$TBE;
$disp.="<br>".$TBT.$TRT.$TD;

# ----------- ここから下をいろいろ書き換える。-----------------------------

$disp.=<<"HTML";
<SPAN>제작·저작</SPAN> ： 유래 ... <A HREF="http://akimono.org/" target="_blank">상인 이야기</A>
<br><br>
<SPAN>원작</SPAN> ： MU 모양 ... <A HREF="http://mutoys.com/" target="_blank">MUTOYS</A> , <SPAN>상품 아이콘</SPAN> ： NAYUTA 모양
<br><br>
<SPAN>로고·작업 일러스트</SPAN> ： 해 두 모양 ... <A HREF="http://www2.holon.dyndns.org/musou/" target="_blank">벽지의 집 해않고 치</A>
<br><br>
<SPAN>아이콘(추가)</SPAN> ： 모양·아슈모양
<br><br>
<SPAN>맵·캐릭터</SPAN> ： REFMAP 모양 ... <A HREF="http://www.mogunet.net/fsm/" target="_blank">FIRST SEED MATERIAL</A>
<br><br>
<SPAN>음악</SPAN> ： 다몽 모양 ... <A HREF="http://www.tam-music.com/" target="_blank">TAM Music Factory</A>
<br><br>
<SPAN>번역</SPAN> :  소모키 ... <A HREF="http://somokey.mireene.com" target="_blank">somokey네 집</A>
HTML
# ----------- ここまで。最後の「HTML」を消さないよう注意。-----------------

require "skin.pl" if -e "skin.pl";
$disp.=$TRE.$TBE;
OutSkin();
1;
