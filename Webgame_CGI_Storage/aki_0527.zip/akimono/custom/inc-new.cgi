# 新規開店사용자 지정用 2004/01/20 유래

# 新規開店時の注意事奣の示などを사용자 지정できます。
# ただし，ある程度のHTMLの知識とプログラｫ烽ﾌ理解が必要です。

$disp.=<<"HTML";
<BIG>처음에</BIG><br><br>
$TB$TR
$TD$image[0]$TD
이 게임은, 브라우저에서 플레이 할수 있는 경영 시뮬레이션 RPG입니다.<br>
참가하기 전에, 도서관에서 룰으로 플레이방법을 읽어 주시기 바랍니다.
$TRE$TBE
<hr width=500 noshade size=1>
HTML

$i_rand=int(rand($ICON_NUMBER))+1;
$disp.="<BIG>신규가게 오픈 : 남은 수".($MAX_USER-$DTusercount)."명</BIG><br>";
$disp.=<<"HTML";
<small>등록은<b>1인당 1가게</b>로</small><br>
<FORM ACTION="action.cgi" $METHOD>
<INPUT TYPE=HIDDEN NAME=key VALUE="new">
<INPUT TYPE=HIDDEN NAME=admin VALUE="$Q{admin}">
<TABLE>
  <TR>
    <TD>
<SPAN>이름</SPAN>:<INPUT TYPE=TEXT NAME=name> 반각전각OK<BR>
<SPAN>가게명</SPAN>:<INPUT TYPE=TEXT NAME=sname> 반각전각OK<BR>

<SPAN>아이콘</SPAN>:<SELECT NAME=icon>
<OPTION value="$i_rand" selected>랜덤</OPTION>
HTML

foreach my $i(1..$ICON_NUMBER)
	{
	$disp.=qq|<OPTION value="$i">아이콘$i</OPTION>|;
	}

$disp.=<<"HTML";
</SELECT> 
<input type="button" value="아이콘일람" onclick="javascript:window.open('action.cgi?key=icon','_blank','width=450,height=380,scrollbars')">
<br>
<SPAN>비밀번호</SPAN>:<INPUT TYPE=PASSWORD maxlength=12 NAME=pass1> 반각영수로<BR>
<SPAN>비밀번호 확인</SPAN>:<INPUT TYPE=PASSWORD maxlength=12 NAME=pass2><BR>
HTML

$disp.="<SPAN>키워드</SPAN>는 <INPUT TYPE=TEXT NAME=newkey><BR>" if ($NEW_SHOP_KEYWORD);

$disp.=<<"HTML";
<center><INPUT TYPE=SUBMIT VALUE="등록"></center>
</TD></TR>
</TABLE>
<small>※겹칠것 같은 이름은 피합시다.<br>
※비밀번호는 타인이 추측할 수 없을 듯한 것을..</small>
</FORM>
HTML
1;
