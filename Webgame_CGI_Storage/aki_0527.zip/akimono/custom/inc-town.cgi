# 성시 설정 파일 2003/10/08 유래

# 성시의 풍경을 사용자 지정 할 수 있습니다.
# 다만, 「영주저」라고, 최하단의 「상가」 「현재 활동중의 가게」의 위치는 변경할 수 없습니다.
# 장소의 번호는, 다음과 같이 되어 있습니다.
#
#   [No.0]  [   영주저   ] [No.1]
#   [No.2]  [No.3]  [No.4] [No.5]
#   [No.6]  [No.7]  [No.8] [No.9]
#                 ·
#                 ·
#   [   상가   ] [ 활동중의 가게 ]
#   
#  ※No.10 이하를 정의하면, 한층 더 도로가 증가하고 아래에 늘릴 수 있습니다.

#  ＜기술 문법＞
#  ·「이름」, 「화상」, 「링크」, 「게스트 권한으로의 링크」의 순서입니다.
#  ·화상에서는, $i[0](통상 건물), $i[1](가게 건물), $space(작은 공간), $vspace(큰 공간)가 유효합니다.
#  ·링크는, 서브 프로그램명외 주소를 지정 가능합니다.공난이라면 링크를 만들지 않습니다.
#  ·아무것도 정의하지 않는 장소는, 수목이라고 해석합니다.

# --- No.0 의 장소 정의 ---

($Pname[0],$Pimage[0],$Plink[0],$Pguest[0])=(
	"경기장",
	qq|<IMG WIDTH=16 HEIGHT=64 SRC="$IMAGE_URL/map/mapsignslime.png">$i[0]|,
	"slime",
	"slime"
	);

# --- No.1 궻뤾룋믦義 ---

($Pname[1],$Pimage[1],$Plink[1],$Pguest[1])=(
	"장원",
	qq|$space<IMG WIDTH=112 HEIGHT=80 SRC="$IMAGE_URL/map/manor.png">|,
	"manor",
	""
	);

# --- No.2 궻뤾룋믦義 ---

($Pname[2],$Pimage[2],$Plink[2],$Pguest[2])=(
	"의뢰소",
	qq|$space<IMG WIDTH=16 HEIGHT=64 SRC=\"$IMAGE_URL/map/mapsignrequest.png\">$i[1]|,
	"req",
	"req"
	);

# --- No.3 궻뤾룋믦義 ---

($Pname[3],$Pimage[3],$Plink[3],$Pguest[3])=(
	"시장",
	qq|$space<IMG WIDTH=16 HEIGHT=64 SRC=\"$IMAGE_URL/map/mapsignmarket.png\">$i[1]|,
	"shop-m",
	"shop-m"
	);

# --- No.4 궻뤾룋믦義 ---

# 樹木のため省略

# --- No.5 궻뤾룋믦義 ---

($Pname[5],$Pimage[5],$Plink[5],$Pguest[5])=(
	"길드",
	qq|<IMG WIDTH=16 HEIGHT=64 SRC="$IMAGE_URL/map/mapsignguild.png">$i[0]|,
	"gd",
	"gd"
	);

# --- No.6 궻뤾룋믦義 ---

# 樹木のため省略

# --- No.7 궻뤾룋믦義 ---

($Pname[7],$Pimage[7],$Plink[7],$Pguest[7])=(
	"병사주둔소",
	qq|<IMG WIDTH=16 HEIGHT=64 SRC="$IMAGE_URL/map/mapsignarmy.png">$i[0]|,
	"army",
	""
	);

# --- No.8 궻뤾룋믦義 ---

($Pname[8],$Pimage[8],$Plink[8],$Pguest[8])=(
	"도서관",
	qq|$space<IMG WIDTH=112 HEIGHT=80 SRC="$IMAGE_URL/map/house1c.png">|,
	"action.cgi?key=library",
	"action.cgi?key=library"
	);

# --- No.9 궻뤾룋믦義 ---

($Pname[9],$Pimage[9],$Plink[9],$Pguest[9])=(
	"게시판",
	qq|<br><br><IMG WIDTH=32 HEIGHT=32 SRC="$IMAGE_URL/map/mapboard.png">|.GetTime2FormatTime((stat($COMMON_DIR.'/treelog.cgi'))[9]+0,1),
	"treebbs",
	""
	);

# --- 以下，No.10，11…と増やしていくことができます。


# --- 긌긿깋긏ター궻긜깏긲 ---
# 見よう見まねで사용자 지정してください（ぉ

sub CharaDefine
{
@chara=();
	if ($DTevent{rebel})
		{
		$chara[1]=TagChara('큰 일이다···.원군을 부르지 않으면!',"d2");
		$chara[2]=TagChara('반란이다!가세하러 간다',"d1");
		$chara[5]=TagChara('영주를 넘기 위해',"d1")."<br>".TagChara('단번에 결판을 내자',"d1");
		return;
		}
my $i=int($NOW_TIME / 3600) % 4;
	if ($i == 0)
		{
		$chara[0]=TagChara("우리의 드래곤이 또 져 버렸다···","e1").$vspace.$vspace;
		$chara[4]=$space.TagChara("식사의 재료 사러 가지 않지 않으면.","e2");
		}
	elsif ($i == 1)
		{
		$chara[7]=$vspace.$vspace.TagChara("도서관의 정보는 중요해","b2").$space
			.TagChara("게시판을 체크하는 것도 중요해","b1");
		}
	elsif ($i == 2)
		{
		$chara[4]=$vspace.TagChara("따뜻한 기분...","c2");
		$chara[6]=TagChara("쇼핑은 역시 ".$DT[0]->{shopname}."이군요","c1").$space;
		}
	elsif ($STATE->{safety} < 4000)
		{
		my $lid=$id2idx{$STATE->{leader}};
		$chara[0]=TagChara(($STATE->{leader} ? $DT[$lid]->{name} : $BAL_NAME).'의 폭정에 단호히 반대!',"a1")
			.TagChara('더욱 시민의 안전을 생각해라!!!',"a2");
		}
}
1;

