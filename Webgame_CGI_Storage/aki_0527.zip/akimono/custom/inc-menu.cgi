# 긽긦깄ー먠믦긲ァ귽깑 2005/03/30 뾕샮

# 긽긦깄ー궸表렑궠궧귡깏긚긣귩먠믦궳궖귏궥갃
# 띍룊궻덇뛱궕걏긽긦깄ー項뽞뼹걐갅
# 렅궻뛱궔귞궼걏긖긳긽긦깄ー뼹걐갅걏긵깓긐깋ム뼹걐궳궥갃
#   ※プログラｫ燒ｼにはアドレスも指定可ﾒﾅす。

my @MENU=(
	# 긒긚긣뙛뙽궻뤾뜃궻긽긦깄ー
	['거리안내',[
		['풍경',	'town'],
		['신문',	'log'],
		['도서관',	'action.cgi?key=library',	"_blank"],
	]],

	# 댥돷긵깒귽깂ー뙛뙽궻뤾뜃궻긽긦깄ー
	['내가게',[
		['점내',	'main'],
		['창고',	'stock'],
		['청소',	'sweep'],
		['수지',	'balance'],
		['수속',	'other'],
		['LogOut',	'index.cgi'],
	]],
	['거래',[
		['시장',	'shop-m'],
		['상가',	'shop-a'],
		['의뢰소',	'req'],
		['궁전',	'palace'],
	]],
	['정보',[
		['풍경',	'town'],
		['신문',	'log'],
		['도서관',	'action.cgi?key=library',	"_blank"],
	]],
	['시설',[
		['영주의 저택',	'lord'],
		['장원',	'manor'],
		['길드',	'gd'],
		['경기장',	'slime'],
		['용병소',	'army'],
		['주택지',	'hometown'],
#		['이삿짐센터',	'move'],
	]],
	['교류',[
		['우편소',	'letter'],
		['택배소',	'dwarf'],
		['게시판'.GetTime2FormatTime((stat($COMMON_DIR.'/treelog.cgi'))[9]+0,1),	'treebbs'],
		['wis',	'wis'],
	]],
);

# 以下はプログラｫ烽ﾅす。編集するには技術が必要です。------------------------------

my $now=$DTlasttime+$TZ_JST-$DATE_REVISE_TIME;
my $nextday=$now+$ONE_DAY_TIME-($now % $ONE_DAY_TIME);
$DISP{MENU} =~ s/#SKINMENUTITLE#/$TOWN_TITLE/;

if($USER && $USER ne 'soldoutadmin')
	{
	$DISP{MENU} =~ s/#SKINJOB#/GetTagImgJob($DT->{job},$DT->{icon})/e;
	my $i;
	my $MENUMSG;
	my $file=GetPath($SUBDATA_DIR,$DT->{id}."-wis");
	$MENUMSG.=<<"STR";
<i id="lay"></i>
<SCRIPT LANGUAGE="JavaScript">
<!--
menudata=[
STR
	$MENUMSG.="'";
	$MENUMSG.=(-e $file) ? WisRead($file) : '<BIG>활동중</BIG> &gt; <small>'.LoginMember().'</small>';
	$MENUMSG.="',";
	foreach(1..$#MENU)
		{
		my $msg=@{$MENU[$_]}[0];
		my @list=@{@{$MENU[$_]}[1]};
		$i.=qq|<A href="javascript:mymenu($_)">[$msg]</A> |;
		$MENUMSG.="'";
		$MENUMSG.="<BIG>$msg</BIG> &gt; ";
		foreach my $sublist(@list)
			{
			my @SUBMENU=@{$sublist};
			$MENUMSG.=(($SUBMENU[1] =~ /\./) ? GetTagA("[".$SUBMENU[0]."]",$SUBMENU[1],0,$SUBMENU[2]) : GetMenuTag($SUBMENU[1],"[".$SUBMENU[0]."]"));
			}
		$MENUMSG.=qq|<A href="javascript:mymenu(0)">【×】</A> |;
		$MENUMSG.="',";
		}
	$MENUMSG.=<<"STR";
];
function mymenu(i){
document.getElementById("lay").innerHTML = menudata[i];
}
mymenu(0);
// -->
</SCRIPT>
STR
	$i.=qq|<A HREF="action.cgi?key=bgm&$USERPASSURL&mode=$Q{key}">[♪]</a> |;
	$i.='[차회결산 '.GetTime2FormatTime($nextday-$TZ_JST+$DATE_REVISE_TIME).' 까지 나머지'.GetTime2HMS(int(($nextday-$now)/60)*60+59).']';
	$DISP{MENU} =~ s/#SKINMENU#/$i/;
	$DISP{MENU} =~ s/#SKINMENUSUB#/$MENUMSG/;
	}
	else
	{
	$DISP{MENU} =~ s/#SKINTITLE#/$HTML_TITLE/;
	$DISP{MENU} =~ s/#SKINJOB#/GetTagImgJob("guest",0)/e;
	my $i;
	my $MENUMSG;
	my $msg=@{$MENU[0]}[0];
	my @list=@{@{$MENU[0]}[1]};
	$MENUMSG.=qq|<BIG>$msg</BIG> > |;
	foreach my $sublist(@list)
		{
		my @SUBMENU=@{$sublist};
		$MENUMSG.=(($SUBMENU[1] =~ /\./) ? GetTagA("[".$SUBMENU[0]."]",$SUBMENU[1],0,"_blank") : GetMenuTag($SUBMENU[1],"[".$SUBMENU[0]."]"));
		}
	$i.=($MYNAME eq 'index.cgi')? qq|<A HREF="$HOME_PAGE" TARGET=_top>[홈]</A> | : qq|<A HREF="index.cgi">[탑]</A> |;
	$i.='[차회결산 '.GetTime2FormatTime($nextday-$TZ_JST+$DATE_REVISE_TIME).' 까지 나머지'.GetTime2HMS(int(($nextday-$now)/60)*60+59).']';
	$DISP{MENU} =~ s/#SKINMENU#/$i/;
	$DISP{MENU} =~ s/#SKINMENUSUB#/$MENUMSG/;
	}
print $DISP{MENU};
1;


sub LoginMember
{
my $logmemb="";
my $i=0;
foreach(@DT)
	{
	next if ($_->{lastlogin} < $NOW_TIME - 120);
	$logmemb .= " , ".$_->{shopname};
	$i++;
	$logmemb .= "외", last if ($i > 3);
	}
$logmemb = substr($logmemb,3) if ($logmemb);
$logmemb = "없음" if !$logmemb;
return $logmemb
}

sub WisRead
{
	my ($file)=@_;
	open(IN,$file) or return;
	read(IN,my $buf,-s $file);
	close(IN);
	unlink $file;
	return $buf;
}
