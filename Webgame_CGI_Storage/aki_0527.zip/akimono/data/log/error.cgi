1776837492	/aki/akimono/action.cgi	125.188.246.129		112.175.50.227!125.188.246.129		ip file read error 
