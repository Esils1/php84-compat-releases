package item;
 if($BUY->{whole}) { my  $price=$BUY->{num}*$BUY->{price}; my  $count=int  $price/500000; $count=AddItemSub(79,$count,$BUY->{dt})  if  $count; WriteLog(0,$BUY->{dt}{id},'시장으로부터  상품권을'.$count.'매  받았습니다')  if  $count; } 
1;
