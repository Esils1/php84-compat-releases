package event;
sub _local_start {
my($hitproba)=@_;
foreach  my  $DT  (@DT)
{
next  if  rand(1000)>$hitproba;
if($DT->{item}[64-1])
{
$DT->{item}[64-1]--;
return  (0,$DT->{shopname}.'에  강도가  들어와  '.$ITEM[64]->{name}.'가  파괴되었습니다');
}
$DT->{rank}-=int($DT->{rank}/5);
my  $count=0;
foreach  my  $idx  (0..$DT->{showcasecount}-1)
{
my  $itemno=$DT->{showcase}[$idx];
next  if  !$itemno;
my  $cnt=int($DT->{item}[$itemno-1]/4);
$DT->{item}[$itemno-1]-=$cnt;
$count+=$cnt*$DT->{price}[$idx];
}
return  (0,$DT->{shopname}.'가  총액'.GetMoneyString($count).'상당한  강도  피해를  당했습니다')  if  $count;
return  (0,$DT->{shopname}.'에  들어간  강도범은  아무것도  취하지  않고  도망쳤습니다');
}
return  0;

}
1;
