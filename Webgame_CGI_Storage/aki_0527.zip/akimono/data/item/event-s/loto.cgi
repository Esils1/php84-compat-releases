package event;
sub _local_start {
WriteLog(2,0,"복권의  추첨을  했습니다");
foreach  my  $DT  (@DT)
{
my  $count=$DT->{item}[11-1];
$DT->{item}[11-1]=0;
next  if  !$count;
foreach(1..$count)
{
my  $rnd=rand(6096454);
my  $hit=0;
$hit=5  if  $rnd<152411;
$hit=4  if  $rnd<10000;
$hit=3  if  $rnd<216;
$hit=2  if  $rnd<6;
$hit=1  if  $rnd<1;
if($hit)
{
my  $getmoney=(0,1000000000,150000000,5000000,100000,10000)[$hit];
$DT->{money}+=$getmoney;
$DT->{money}=$main::MAX_MONEY  if  $DT->{money}>$main::MAX_MONEY;
WriteLog(($hit<=3?1:2),0,$DT->{shopname}."가  $hit등  ".GetMoneyString($getmoney)."(을)를  맞혔습니다!");
}
}
}
return  0;

}
1;
