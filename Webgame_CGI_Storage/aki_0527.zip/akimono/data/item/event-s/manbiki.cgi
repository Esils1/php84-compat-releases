package event;
sub _local_start {
my($hitproba,$breakproba)=@_;
foreach  my  $DT  (@DT)
{
next  if  rand(1000)>$hitproba;
if($DT->{item}[64-1])
{
return  (0,$DT->{shopname}.'에  도둑이  들어왔습니다만  저지되었습니다')  if  rand(1000)>$breakproba;
$DT->{item}[64-1]--;
return  (0,$DT->{shopname}.'에  도둑이  들어와  '.$ITEM[64]->{name}.'가  파괴되었습니다');
}
my  $count=0;
foreach  my  $idx  (0..$DT->{showcasecount}-1)
{
my  $itemno=$DT->{showcase}[$idx];
next  if  !$itemno;
my  $cnt=int($DT->{item}[$itemno-1]/10);
$DT->{item}[$itemno-1]-=$cnt;
$count+=$cnt*$DT->{price}[$idx];
}
return  (0,$DT->{shopname}.'가  총액  '.GetMoneyString($count).'에  상당한  도둑  피해를  당했습니다')  if  $count;
return  (0,$DT->{shopname}.'에  들어간  도둑범은  아무것도  훔치지  않고  도망쳤습니다');
}
return  0;

}
1;
