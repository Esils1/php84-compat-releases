package event;
sub _local_start {
my($money)=@_;
foreach(reverse(@DT))
{
next  if  rand(1000)>300;
$_->{money}+=$money;
$_->{money}=$main::MAX_MONEY  if  $_->{money}>$main::MAX_MONEY;
return  (0,$_->{shopname}.'에  '.GetMoneyString($money).'의  보조금이  지급되었습니다');
}
return  0;

}
1;
