 $DT->{money}='100000'if  '100000'; $DT->{time}=$NOW_TIME-eval('12*60*60')  if  '12*60*60'; if('진열장&nbsp;증축취괴킷:1:상품권:5') { my  %item=split  /:/,'진열장&nbsp;증축취괴킷:1:상품권:5'; while(my($key,$val)  =each  %item) { foreach  my  $item  (@ITEM) { $DT->{item}[$item->{no}-1]+=$val,last  if  $key  eq  $item->{code}  or  $key  eq  $item->{name}; } } } 
1;
