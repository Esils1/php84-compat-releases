 $TIME_SEND_ITEM=int($TIME_SEND_ITEM/4*3)  if  $DT->{item}[24-1]; $TIME_SEND_ITEM=int($TIME_SEND_ITEM/2)  if  $DT->{job}  eq  'peddle'; 
1;
