package item;
$USE[0]={'code'=>'seven_face','no'=>0,'itemno'=>'27','name'=>'먹는다','info'=>'축하  할까요','scale'=>'마리','action'=>'먹는다','money'=>0,'time'=>1800,'exptime'=>'1800','arg'=>'nocount','use'=>[{'no'=>27,'count'=>1,'proba'=>1000,'message'=>'배가&nbsp;부르게&nbsp;되었습니다'},],'result'=>{},};

1;
