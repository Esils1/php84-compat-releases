package item;
$USE[0]={'code'=>'boots','no'=>0,'itemno'=>'29','name'=>'신고  외출한다','info'=>'거리를  다니며  축하  할까요','scale'=>'다리','action'=>'신는다','money'=>0,'time'=>1800,'exptime'=>'1800','arg'=>'nocount','use'=>[{'no'=>29,'count'=>1,'proba'=>1000,'message'=>'모두의&nbsp;시선을&nbsp;한사람이&nbsp;차지했습니다'},],'result'=>{},};

1;
