package item;
$USE[0]={'code'=>'book-kawazaiku','no'=>0,'itemno'=>'16','name'=>'가죽방패를  작성한다','info'=>'가죽방패를  작성합니다','scale'=>'세트','action'=>'마구  만든다','money'=>0,'time'=>1800,'exptime'=>'600','exp'=>'20','use'=>[{'no'=>2,'count'=>24,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'가죽방패를  만들었습니다','resultng'=>'작성에  실패했습니다…',},'create'=>[{'no'=>45,'count'=>30,'proba'=>800},],},};
sub _job_use_0_armor_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[1]={'code'=>'book-kawazaiku','no'=>1,'itemno'=>'16','name'=>'가죽흉갑을  작성한다','info'=>'가죽흉갑을  작성합니다','scale'=>'세트','action'=>'마구  만든다','money'=>0,'time'=>1800,'exptime'=>'600','exp'=>'20','use'=>[{'no'=>2,'count'=>24,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'가죽흉갑을  만들었습니다','resultng'=>'작성에  실패했습니다…',},'create'=>[{'no'=>51,'count'=>32,'proba'=>800},],},};

1;
