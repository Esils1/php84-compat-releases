package item;
$USE[0]={'code'=>'book-yoroi','no'=>0,'itemno'=>'22','name'=>'철갑옷를  작성한다','info'=>'전통적인  철갑옷를  작성해  봅시다','scale'=>'세트','action'=>'작성한다','money'=>0,'time'=>3600,'exptime'=>'1200','exp'=>'20','use'=>[{'no'=>18,'count'=>1,'proba'=>0},{'no'=>5,'count'=>20,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'철갑옷를  작성했습니다','resultng'=>'작성에  실패했습니다…',},'create'=>[{'no'=>53,'count'=>20,'proba'=>800},],},};
sub _job_use_0_armor_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[1]={'code'=>'book-yoroi','no'=>1,'itemno'=>'22','name'=>'강철갑옷를  작성한다','info'=>'강철갑옷를  작성해  봅시다','scale'=>'세트','action'=>'작성한다','money'=>0,'time'=>6300,'exptime'=>'2100','exp'=>'20','needexp'=>'200','use'=>[{'no'=>18,'count'=>1,'proba'=>0},{'no'=>5,'count'=>40,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'강철갑옷를  작성했습니다','resultng'=>'작성에  실패했습니다…',},'create'=>[{'no'=>54,'count'=>20,'proba'=>800},],},};
$USE[2]={'code'=>'book-yoroi','no'=>2,'itemno'=>'22','name'=>'미스릴갑옷를  작성한다','info'=>'상급  모험자의  납품업자미스릴갑옷를  작성해  봅시다','scale'=>'세트','action'=>'작성한다','money'=>0,'time'=>6300,'exptime'=>'2100','exp'=>'20','param1'=>'50','needexp'=>'400','use'=>[{'no'=>18,'count'=>1,'proba'=>0},{'no'=>6,'count'=>20,'proba'=>1000},],'result'=>{'function'=>'lostbook','message'=>{'resultok'=>'미스릴갑옷를  작성했습니다','resultng'=>'작성에  실패했습니다…',},'create'=>[{'no'=>55,'count'=>20,'proba'=>600},],},};
$USE[3]={'code'=>'book-yoroi','no'=>3,'itemno'=>'22','name'=>'오리하르콘갑옷를  작성한다','info'=>'좀처럼  손에  들어  오지  않는오리하르콘갑옷를  작성해  봅시다','scale'=>'세트','action'=>'작성한다','money'=>0,'time'=>8100,'exptime'=>'2700','exp'=>'20','param1'=>'50','needexp'=>'600','use'=>[{'no'=>18,'count'=>1,'proba'=>0},{'no'=>7,'count'=>20,'proba'=>1000},],'result'=>{'function'=>'lostbook','message'=>{'resultok'=>'오리하르콘갑옷를  작성했습니다','resultng'=>'작성에  실패했습니다…',},'create'=>[{'no'=>56,'count'=>20,'proba'=>400},],},};

1;
