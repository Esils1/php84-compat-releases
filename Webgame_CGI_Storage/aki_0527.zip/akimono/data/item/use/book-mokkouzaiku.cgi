package item;
$USE[0]={'code'=>'book-mokkouzaiku','no'=>0,'itemno'=>'17','name'=>'목검을  작성한다','info'=>'목검을  작성합니다','scale'=>'세트','action'=>'마구  만든다','money'=>0,'time'=>1800,'exptime'=>'600','exp'=>'20','use'=>[{'no'=>3,'count'=>20,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'목검을  만들었습니다','resultng'=>'작성에  실패했습니다…',},'create'=>[{'no'=>40,'count'=>20,'proba'=>800},],},};
sub _job_use_0_weapon_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[1]={'code'=>'book-mokkouzaiku','no'=>1,'itemno'=>'17','name'=>'나무지팡이를  작성한다','info'=>'나무지팡이를  작성합니다','scale'=>'세트','action'=>'마구  만든다','money'=>0,'time'=>1800,'exptime'=>'600','exp'=>'20','use'=>[{'no'=>3,'count'=>20,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'나무지팡이를  만들었습니다','resultng'=>'작성에  실패했습니다…',},'create'=>[{'no'=>57,'count'=>20,'proba'=>800},],},};
$USE[2]={'code'=>'book-mokkouzaiku','no'=>2,'itemno'=>'17','name'=>'나무방패를  작성한다','info'=>'나무방패를  작성합니다','scale'=>'세트','action'=>'마구  만든다','money'=>0,'time'=>3600,'exptime'=>'1200','exp'=>'20','use'=>[{'no'=>4,'count'=>10,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'나무방패를  만들었습니다','resultng'=>'작성에  실패했습니다…',},'create'=>[{'no'=>46,'count'=>20,'proba'=>800},],},};
sub _job_use_2_armor_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[3]={'code'=>'book-mokkouzaiku','no'=>3,'itemno'=>'17','name'=>'나무흉갑을  작성한다','info'=>'나무흉갑을  작성합니다','scale'=>'세트','action'=>'마구  만든다','money'=>0,'time'=>3600,'exptime'=>'1200','exp'=>'20','use'=>[{'no'=>4,'count'=>10,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'나무흉갑을  만들었습니다','resultng'=>'작성에  실패했습니다…',},'create'=>[{'no'=>52,'count'=>24,'proba'=>800},],},};
sub _job_use_3_armor_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}

1;
