package item;
$USE[0]={'code'=>'mino_cheese','no'=>0,'itemno'=>'36','name'=>'먹는다','info'=>'미노치즈를  먹어  보겠습니다','scale'=>'개','action'=>'먹는다','money'=>0,'time'=>600,'exptime'=>'600','use'=>[{'no'=>36,'count'=>1,'proba'=>1000},],'result'=>{'message'=>{'resultng'=>'맛없어  토했다…',},},};
sub _job_use_0_cow_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}

1;
