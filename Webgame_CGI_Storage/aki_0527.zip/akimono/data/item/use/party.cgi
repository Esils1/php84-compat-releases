package item;
$USE[0]={'code'=>'party','no'=>0,'itemno'=>'77','name'=>'축하  파티','info'=>'오늘  밤은  술자리입니다','scale'=>'세트','action'=>'파티  개시','money'=>0,'time'=>7200,'exptime'=>'7200','arg'=>'nocount','param1'=>'1000','param2'=>'파티를&nbsp;열었습니다','use'=>[{'no'=>77,'count'=>1,'proba'=>1000,'message'=>'내일을&nbsp;향한&nbsp;활력이&nbsp;올라왔습니다'},],'result'=>{'function'=>'popup',},};

1;
