package item;
$USE[0]={'code'=>'book-mtsearch','no'=>0,'itemno'=>'12','name'=>'산기슭을  탐색','info'=>'여러가지  재료를  조달할  수  있을지도  모릅니다','scale'=>'왕복','action'=>'탐색하러  간다','money'=>0,'time'=>3600,'exptime'=>'900','exp'=>'20','param1'=>'10','result'=>{'function'=>'lostbook','message'=>{'resultng'=>'아무것도  발견되지  않았습니다…',},'create'=>[{'no'=>1,'count'=>80,'proba'=>900,'message'=>'약초가&nbsp;많이&nbsp;나&nbsp;있었습니다'},{'no'=>2,'count'=>2,'proba'=>900},{'no'=>3,'count'=>2,'proba'=>900},{'no'=>4,'count'=>2,'proba'=>450},],},};
sub _job_use_0_material_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[1]={'code'=>'book-mtsearch','no'=>1,'itemno'=>'12','name'=>'산길을  탐색','info'=>'여러가지  재료를  조달할  수  있을지도  모릅니다','scale'=>'왕복','action'=>'탐색하러  간다','money'=>0,'time'=>3600,'exptime'=>'900','exp'=>'20','param1'=>'10','result'=>{'function'=>'lostbook','message'=>{'resultng'=>'아무것도  발견되지  않았습니다…',},'create'=>[{'no'=>1,'count'=>4,'proba'=>900},{'no'=>2,'count'=>2,'proba'=>900},{'no'=>3,'count'=>40,'proba'=>900,'message'=>'나뭇가지가&nbsp;많이&nbsp;떨어지고&nbsp;있었습니다'},{'no'=>4,'count'=>2,'proba'=>450},],},};
$USE[2]={'code'=>'book-mtsearch','no'=>2,'itemno'=>'12','name'=>'수도를  탐색','info'=>'재료를  조달할  수  있을지도  모릅니다','scale'=>'왕복','action'=>'탐색하러  간다','money'=>0,'time'=>3600,'exptime'=>'900','exp'=>'20','param1'=>'10','result'=>{'function'=>'lostbook','message'=>{'resultng'=>'아무것도  발견되지  않았습니다…',},'create'=>[{'no'=>1,'count'=>4,'proba'=>900},{'no'=>2,'count'=>40,'proba'=>900,'message'=>'짐승을&nbsp;많이&nbsp;사냥했습니다'},{'no'=>3,'count'=>2,'proba'=>900},{'no'=>4,'count'=>2,'proba'=>450},],},};
$USE[3]={'code'=>'book-mtsearch','no'=>3,'itemno'=>'12','name'=>'잡목림  안쪽을  탐색','info'=>'재료를  조달할  수  있을지도  모릅니다','scale'=>'왕복','action'=>'탐색하러  간다','money'=>0,'time'=>3600,'exptime'=>'900','exp'=>'20','param1'=>'10','result'=>{'function'=>'lostbook','message'=>{'resultng'=>'아무것도  발견되지  않았습니다…',},'create'=>[{'no'=>1,'count'=>4,'proba'=>900},{'no'=>2,'count'=>2,'proba'=>900},{'no'=>3,'count'=>2,'proba'=>900},{'no'=>4,'count'=>40,'proba'=>450,'message'=>'통나무가&nbsp;많이&nbsp;발견되었습니다'},],},};

1;
