package item;
$USE[0]={'code'=>'mino','no'=>0,'itemno'=>'25','name'=>'젖을  짠다','info'=>'미노씨에게서  젖을  짭니다','scale'=>'착유','action'=>'짠다','money'=>0,'time'=>3600,'exptime'=>'3600','exp'=>'10','param1'=>'1','use'=>[{'no'=>25,'count'=>1,'proba'=>0},],'result'=>{'function'=>'_local_1',},};
sub _local_1 {eval(<<'_eval_code_');
my  $val=$USE->{param1}*$count;$val*=$DT->{item}[25-1];$val=int(rand($val))+1;AddItem(26,$val,'미노&nbsp;우유를  정제  했습니다');my  $useproba=$USE->{param1}*$USE->{param1};my  $usecount=0;foreach(1..$count){$usecount++  if  rand(1000)<$useproba;}UseItem(25,$usecount,$ITEM[25]->{name}.'가  '.($USE->{param1}==1?'수명':'과로').'때문에  하늘로  돌아가셨습니다')  if  $usecount;my  $ret='미노&nbsp;우유를  '.$val.'개  정제  했습니다';WriteLog(0,$DT->{id},$ret);return  $ret;
_eval_code_
}
sub _job_use_0_cow_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[1]={'code'=>'mino','no'=>1,'itemno'=>'25','name'=>'하드하게  젖을  짠다','info'=>'미노씨로부터  하드하게  젖을  짭니다','scale'=>'착유','action'=>'짠다','money'=>0,'time'=>3600,'exptime'=>'3600','exp'=>'10','param1'=>'2','use'=>[{'no'=>25,'count'=>1,'proba'=>0},],'result'=>{'function'=>'_local_1',},};
sub _job_use_1_cow_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}

1;
