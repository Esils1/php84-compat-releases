package item;
$USE[0]={'code'=>'book-tate','no'=>0,'itemno'=>'21','name'=>'철방패를  작성한다','info'=>'전통적인  철방패를  작성해  봅시다','scale'=>'세트','action'=>'작성한다','money'=>0,'time'=>2700,'exptime'=>'900','exp'=>'20','use'=>[{'no'=>18,'count'=>1,'proba'=>0},{'no'=>5,'count'=>20,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'철방패를  작성했습니다','resultng'=>'작성에  실패했습니다…',},'create'=>[{'no'=>47,'count'=>20,'proba'=>800},],},};
sub _job_use_0_armor_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[1]={'code'=>'book-tate','no'=>1,'itemno'=>'21','name'=>'강철방패를  작성한다','info'=>'강철방패를  작성해  봅시다','scale'=>'세트','action'=>'작성한다','money'=>0,'time'=>5400,'exptime'=>'1800','exp'=>'20','needexp'=>'200','use'=>[{'no'=>18,'count'=>1,'proba'=>0},{'no'=>5,'count'=>40,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'강철방패를  작성했습니다','resultng'=>'작성에  실패했습니다…',},'create'=>[{'no'=>48,'count'=>20,'proba'=>800},],},};
$USE[2]={'code'=>'book-tate','no'=>2,'itemno'=>'21','name'=>'미스릴방패를  작성한다','info'=>'상급  모험자의  납품업자미스릴방패를  작성해  봅시다','scale'=>'세트','action'=>'작성한다','money'=>0,'time'=>5400,'exptime'=>'1800','exp'=>'20','param1'=>'50','needexp'=>'400','use'=>[{'no'=>18,'count'=>1,'proba'=>0},{'no'=>6,'count'=>20,'proba'=>1000},],'result'=>{'function'=>'lostbook','message'=>{'resultok'=>'미스릴방패를  작성했습니다','resultng'=>'작성에  실패했습니다…',},'create'=>[{'no'=>49,'count'=>20,'proba'=>600},],},};
$USE[3]={'code'=>'book-tate','no'=>3,'itemno'=>'21','name'=>'오리하르콘방패를  작성한다','info'=>'좀처럼  손에  들어  오지  않는오리하르콘방패를  작성해  봅시다','scale'=>'세트','action'=>'작성한다','money'=>0,'time'=>7200,'exptime'=>'2400','exp'=>'20','param1'=>'50','needexp'=>'600','use'=>[{'no'=>18,'count'=>1,'proba'=>0},{'no'=>7,'count'=>20,'proba'=>1000},],'result'=>{'function'=>'lostbook','message'=>{'resultok'=>'오리하르콘방패를  작성했습니다','resultng'=>'작성에  실패했습니다…',},'create'=>[{'no'=>50,'count'=>20,'proba'=>400},],},};

1;
