package item;
$USE[0]={'code'=>'ramusyu','no'=>0,'itemno'=>'28','name'=>'마신다','info'=>'축하  할까요','scale'=>'개','action'=>'마신다','money'=>0,'time'=>1800,'exptime'=>'1800','arg'=>'nocount','use'=>[{'no'=>28,'count'=>1,'proba'=>1000,'message'=>'좋은&nbsp;기분이&nbsp;되었습니다'},],'result'=>{},};

1;
