package item;
$USE[0]={'code'=>'book-tyougou','no'=>0,'itemno'=>'15','name'=>'포션를  작성한다','info'=>'포션를  마구  작성합니다','scale'=>'세트','action'=>'마구  만든다','money'=>0,'time'=>900,'exptime'=>'300','exp'=>'20','use'=>[{'no'=>1,'count'=>10,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'포션를  많이  만들었습니다','resultng'=>'작성에  실패했습니다…',},'create'=>[{'no'=>30,'count'=>20,'proba'=>800},],},};
sub _job_use_0_drug_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[1]={'code'=>'book-tyougou','no'=>1,'itemno'=>'15','name'=>'하이&nbsp;포션을  작성한다','info'=>'하이&nbsp;포션을  마구  작성합니다','scale'=>'세트','action'=>'마구  만든다','money'=>0,'time'=>900,'exptime'=>'300','exp'=>'20','param1'=>'25','needexp'=>'200','use'=>[{'no'=>30,'count'=>10,'proba'=>1000},],'result'=>{'function'=>'lostbook','message'=>{'resultok'=>'하이&nbsp;포션을  만들었습니다','resultng'=>'작성에  실패했습니다…',},'create'=>[{'no'=>31,'count'=>20,'proba'=>800},],},};
$USE[2]={'code'=>'book-tyougou','no'=>2,'itemno'=>'15','name'=>'에테르를  작성한다','info'=>'에테르를  마구  작성합니다','scale'=>'세트','action'=>'마구  만든다','money'=>0,'time'=>900,'exptime'=>'300','exp'=>'20','needexp'=>'200','use'=>[{'no'=>1,'count'=>20,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'에테르를  만들었습니다','resultng'=>'작성에  실패했습니다…',},'create'=>[{'no'=>32,'count'=>20,'proba'=>640},],},};
$USE[3]={'code'=>'book-tyougou','no'=>3,'itemno'=>'15','name'=>'하이&nbsp;에테르를  작성한다','info'=>'하이&nbsp;에테르를  마구  작성합니다','scale'=>'세트','action'=>'마구  만든다','money'=>0,'time'=>900,'exptime'=>'300','exp'=>'20','param1'=>'25','needexp'=>'400','use'=>[{'no'=>32,'count'=>10,'proba'=>1000},],'result'=>{'function'=>'lostbook','message'=>{'resultok'=>'하이&nbsp;에테르를  만들었습니다','resultng'=>'작성에  실패했습니다…',},'create'=>[{'no'=>33,'count'=>10,'proba'=>900},],},};
$USE[4]={'code'=>'book-tyougou','no'=>4,'itemno'=>'15','name'=>'에리풀을  작성한다','info'=>'에리풀을  마구  작성합니다','scale'=>'세트','action'=>'마구  만든다','money'=>0,'time'=>900,'exptime'=>'300','exp'=>'20','param1'=>'50','needexp'=>'600','use'=>[{'no'=>31,'count'=>10,'proba'=>1000},{'no'=>33,'count'=>10,'proba'=>1000},],'result'=>{'function'=>'lostbook','message'=>{'resultok'=>'에리풀을  재배했습니다','resultng'=>'작성에  실패했습니다…',},'create'=>[{'no'=>34,'count'=>5,'proba'=>1000},],},};

1;
