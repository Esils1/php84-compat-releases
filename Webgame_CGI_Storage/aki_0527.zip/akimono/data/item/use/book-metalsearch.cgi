package item;
$USE[0]={'code'=>'book-metalsearch','no'=>0,'itemno'=>'9','name'=>'철광산에  간다','info'=>'여러가지  광물을  조달할  수  있을지도  모릅니다','scale'=>'왕복','action'=>'채취하러  간다','money'=>0,'time'=>3600,'exptime'=>'900','exp'=>'20','param1'=>'10','result'=>{'function'=>'lostbook','message'=>{'resultng'=>'아무것도  발견되지  않았습니다…',},'create'=>[{'no'=>5,'count'=>30,'proba'=>800},{'no'=>6,'count'=>2,'proba'=>600},{'no'=>7,'count'=>1,'proba'=>800},],},};
sub _job_use_0_material_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[1]={'code'=>'book-metalsearch','no'=>1,'itemno'=>'9','name'=>'미스릴  광산에  간다','info'=>'여러가지  광물을  조달할  수  있을지도  모릅니다','scale'=>'왕복','action'=>'채취하러  간다','money'=>0,'time'=>3600,'exptime'=>'900','exp'=>'20','param1'=>'10','result'=>{'function'=>'lostbook','message'=>{'resultng'=>'아무것도  발견되지  않았습니다…',},'create'=>[{'no'=>5,'count'=>3,'proba'=>800},{'no'=>6,'count'=>20,'proba'=>600},{'no'=>7,'count'=>1,'proba'=>800},],},};
$USE[2]={'code'=>'book-metalsearch','no'=>2,'itemno'=>'9','name'=>'오리하르콘  광산에  간다','info'=>'여러가지  광물을  조달할  수  있을지도  모릅니다','scale'=>'왕복','action'=>'채취하러  간다','money'=>0,'time'=>3600,'exptime'=>'900','exp'=>'20','param1'=>'10','result'=>{'function'=>'lostbook','message'=>{'resultng'=>'아무것도  발견되지  않았습니다…',},'create'=>[{'no'=>5,'count'=>3,'proba'=>800},{'no'=>6,'count'=>2,'proba'=>600},{'no'=>7,'count'=>10,'proba'=>800},],},};

1;
