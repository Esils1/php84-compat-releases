package item;
$USE[0]={'code'=>'mino_yogurt','no'=>0,'itemno'=>'35','name'=>'먹는다','info'=>'미노요구르트를  먹어  보겠습니다','scale'=>'개','action'=>'먹는다','money'=>0,'time'=>300,'exptime'=>'300','use'=>[{'no'=>35,'count'=>1,'proba'=>1000},],'result'=>{'message'=>{'resultng'=>'서민의  입맛에는  맞지  않는  것  같다…',},},};
sub _job_use_0_cow_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}

1;
