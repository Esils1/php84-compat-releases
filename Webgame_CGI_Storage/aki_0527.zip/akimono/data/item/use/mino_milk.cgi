package item;
$USE[0]={'code'=>'mino_milk','no'=>0,'itemno'=>'26','name'=>'마신다','info'=>'미노&nbsp;우유를  마셔  보겠습니다','scale'=>'개','action'=>'마신다','money'=>0,'time'=>90,'exptime'=>'90','use'=>[{'no'=>26,'count'=>1,'proba'=>1000},],'result'=>{'function'=>'_local_1',},};
sub _local_1 {eval(<<'_eval_code_');
my  $val=$count;my  $ret="";if($count>=30){$DT->{rank}-=$count*2;$DT->{rank}=0  if  $DT->{rank}<0;WriteLog(2,0,$DT->{shopname}.'의  점주가  구급차로  옮겨졌습니다');WriteLog(2,0,'한번에  미노&nbsp;우유  '.$count.'통을  마신다는  것은  맨정신으로  할일이  아닙니다.');$ret="…일어나  보니  병원의  침대  위였습니다";}elsif($count>=10){$ret='위장를  손상시켰습니다  한번에  미노&nbsp;우유  '.$count.'통은  과음입니다';WriteLog(0,$DT->{id},$ret);}else{$DT->{rank}+=int(rand($count+1))  +$count;$DT->{rank}=10000  if  $DT->{rank}>10000;$ret='미노&nbsp;우유를  마셔  건강하게  된  것  같습니다';WriteLog(0,$DT->{id},$ret);}return  $ret;
_eval_code_
}
sub _job_use_0_cow_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[1]={'code'=>'mino_milk','no'=>1,'itemno'=>'26','name'=>'라이트  발효','info'=>'미노&nbsp;우유를  가볍고  발효  시켜  보겠습니다','scale'=>'세트','action'=>'라이트  발효  시킨다','money'=>0,'time'=>2160,'exptime'=>'2160','use'=>[{'no'=>25,'count'=>5,'proba'=>0},{'no'=>26,'count'=>15,'proba'=>1000},],'result'=>{'create'=>[{'no'=>35,'count'=>2,'proba'=>1000},],},};
sub _job_use_1_cow_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[2]={'code'=>'mino_milk','no'=>2,'itemno'=>'26','name'=>'헤비  발효','info'=>'미노&nbsp;우유를  꽤  발효  시켜  보겠습니다','scale'=>'세트','action'=>'헤비  발효  시킨다','money'=>0,'time'=>4320,'exptime'=>'4320','use'=>[{'no'=>25,'count'=>10,'proba'=>0},{'no'=>26,'count'=>15,'proba'=>1000},],'result'=>{'create'=>[{'no'=>36,'count'=>1,'proba'=>1000},],},};
sub _job_use_2_cow_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}

1;
