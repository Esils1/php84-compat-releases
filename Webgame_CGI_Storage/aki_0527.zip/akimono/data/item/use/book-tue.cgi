package item;
$USE[0]={'code'=>'book-tue','no'=>0,'itemno'=>'23','name'=>'철지팡이를  작성한다','info'=>'전통적인  철지팡이를  작성해  봅시다','scale'=>'세트','action'=>'작성한다','money'=>0,'time'=>2700,'exptime'=>'900','exp'=>'20','use'=>[{'no'=>19,'count'=>1,'proba'=>0},{'no'=>5,'count'=>20,'proba'=>1000},{'no'=>8,'count'=>2,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'철지팡이를  작성했습니다','resultng'=>'작성에  실패했습니다…',},'create'=>[{'no'=>58,'count'=>20,'proba'=>800},],},};
sub _job_use_0_weapon_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[1]={'code'=>'book-tue','no'=>1,'itemno'=>'23','name'=>'강철지팡이를  작성한다','info'=>'강철지팡이를  작성해  봅시다','scale'=>'세트','action'=>'작성한다','money'=>0,'time'=>5400,'exptime'=>'1800','exp'=>'20','needexp'=>'250','use'=>[{'no'=>19,'count'=>1,'proba'=>0},{'no'=>5,'count'=>40,'proba'=>1000},{'no'=>8,'count'=>4,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'강철지팡이를  작성했습니다','resultng'=>'작성에  실패했습니다…',},'create'=>[{'no'=>59,'count'=>20,'proba'=>800},],},};
$USE[2]={'code'=>'book-tue','no'=>2,'itemno'=>'23','name'=>'미스릴지팡이를  작성한다','info'=>'상급  모험자의  납품업자미스릴지팡이를  작성해  봅시다','scale'=>'세트','action'=>'작성한다','money'=>0,'time'=>5400,'exptime'=>'1800','exp'=>'20','param1'=>'50','needexp'=>'500','use'=>[{'no'=>19,'count'=>1,'proba'=>0},{'no'=>6,'count'=>20,'proba'=>1000},{'no'=>8,'count'=>6,'proba'=>1000},],'result'=>{'function'=>'lostbook','message'=>{'resultok'=>'미스릴지팡이를  작성했습니다','resultng'=>'작성에  실패했습니다…',},'create'=>[{'no'=>60,'count'=>20,'proba'=>600},],},};
$USE[3]={'code'=>'book-tue','no'=>3,'itemno'=>'23','name'=>'오리하르콘지팡이를  작성한다','info'=>'좀처럼  손에  들어  오지  않는오리하르콘지팡이를  작성해  봅시다','scale'=>'세트','action'=>'작성한다','money'=>0,'time'=>7200,'exptime'=>'2400','exp'=>'20','param1'=>'50','needexp'=>'700','use'=>[{'no'=>19,'count'=>1,'proba'=>0},{'no'=>7,'count'=>20,'proba'=>1000},{'no'=>8,'count'=>10,'proba'=>1000},],'result'=>{'function'=>'lostbook','message'=>{'resultok'=>'오리하르콘지팡이를  작성했습니다','resultng'=>'작성에  실패했습니다…',},'create'=>[{'no'=>61,'count'=>20,'proba'=>400},],},};

1;
