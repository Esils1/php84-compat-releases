package item;
$USE[0]={'code'=>'book-ken','no'=>0,'itemno'=>'20','name'=>'철검을  단련한다','info'=>'전통적인  철검을  단련해  봅시다','scale'=>'세트','action'=>'단련한다','money'=>0,'time'=>2700,'exptime'=>'900','exp'=>'20','use'=>[{'no'=>18,'count'=>1,'proba'=>0},{'no'=>5,'count'=>20,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'철검을  단련했습니다','resultng'=>'단련하는데  실패했습니다…',},'create'=>[{'no'=>41,'count'=>20,'proba'=>800},],},};
sub _job_use_0_weapon_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[1]={'code'=>'book-ken','no'=>1,'itemno'=>'20','name'=>'강철검을  단련한다','info'=>'강철검을  단련해  봅시다','scale'=>'세트','action'=>'단련한다','money'=>0,'time'=>5400,'exptime'=>'1800','exp'=>'20','needexp'=>'200','use'=>[{'no'=>18,'count'=>1,'proba'=>0},{'no'=>5,'count'=>40,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'강철검을  단련했습니다','resultng'=>'단련하는데  실패했습니다…',},'create'=>[{'no'=>42,'count'=>20,'proba'=>800},],},};
$USE[2]={'code'=>'book-ken','no'=>2,'itemno'=>'20','name'=>'미스릴검을  단련한다','info'=>'상급  모험자의  납품업자미스릴검을  단련해  봅시다','scale'=>'세트','action'=>'단련한다','money'=>0,'time'=>5400,'exptime'=>'1800','exp'=>'20','param1'=>'50','needexp'=>'400','use'=>[{'no'=>18,'count'=>1,'proba'=>0},{'no'=>6,'count'=>20,'proba'=>1000},],'result'=>{'function'=>'lostbook','message'=>{'resultok'=>'미스릴검을  단련했습니다','resultng'=>'단련하는데  실패했습니다…',},'create'=>[{'no'=>43,'count'=>20,'proba'=>600},],},};
$USE[3]={'code'=>'book-ken','no'=>3,'itemno'=>'20','name'=>'오리하르콘검을  단련한다','info'=>'좀처럼  손에  들어  오지  않는오리하르콘검을  단련해  봅시다','scale'=>'세트','action'=>'단련한다','money'=>0,'time'=>7200,'exptime'=>'2400','exp'=>'20','param1'=>'50','needexp'=>'600','use'=>[{'no'=>18,'count'=>1,'proba'=>0},{'no'=>7,'count'=>20,'proba'=>1000},],'result'=>{'function'=>'lostbook','message'=>{'resultok'=>'오리하르콘검을  단련했습니다','resultng'=>'단련하는데  실패했습니다…',},'create'=>[{'no'=>44,'count'=>20,'proba'=>400},],},};

1;
