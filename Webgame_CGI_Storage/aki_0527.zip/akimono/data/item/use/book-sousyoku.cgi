package item;
$USE[0]={'code'=>'book-sousyoku','no'=>0,'itemno'=>'66','name'=>'철귀걸이를  작성한다','info'=>'철귀걸이를  마구  작성합니다','scale'=>'세트','action'=>'마구  만든다','money'=>0,'time'=>2700,'exptime'=>'900','exp'=>'20','use'=>[{'no'=>18,'count'=>1,'proba'=>0},{'no'=>19,'count'=>1,'proba'=>0},{'no'=>5,'count'=>20,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'철귀걸이를  많이  만들었습니다','resultng'=>'작성에  실패했습니다…',},'create'=>[{'no'=>67,'count'=>20,'proba'=>800},],},};
sub _job_use_0_tool_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[1]={'code'=>'book-sousyoku','no'=>1,'itemno'=>'66','name'=>'미스릴반지를  작성한다','info'=>'미스릴반지를  마구  작성합니다','scale'=>'세트','action'=>'마구  만든다','money'=>0,'time'=>5400,'exptime'=>'1800','exp'=>'20','param1'=>'50','needexp'=>'250','use'=>[{'no'=>18,'count'=>1,'proba'=>0},{'no'=>19,'count'=>1,'proba'=>0},{'no'=>6,'count'=>20,'proba'=>1000},{'no'=>8,'count'=>2,'proba'=>1000},],'result'=>{'function'=>'lostbook','message'=>{'resultok'=>'미스릴반지를  많이  만들었습니다','resultng'=>'작성에  실패했습니다…',},'create'=>[{'no'=>68,'count'=>20,'proba'=>600},],},};
$USE[2]={'code'=>'book-sousyoku','no'=>2,'itemno'=>'66','name'=>'오리하르콘팔찌를  작성한다','info'=>'오리하르콘팔찌를  마구  작성합니다','scale'=>'세트','action'=>'마구  만든다','money'=>0,'time'=>7200,'exptime'=>'2400','exp'=>'20','param1'=>'50','needexp'=>'500','use'=>[{'no'=>18,'count'=>1,'proba'=>0},{'no'=>19,'count'=>1,'proba'=>0},{'no'=>7,'count'=>20,'proba'=>1000},{'no'=>8,'count'=>2,'proba'=>1000},],'result'=>{'function'=>'lostbook','message'=>{'resultok'=>'오리하르콘팔찌를  많이  만들었습니다','resultng'=>'작성에  실패했습니다…',},'create'=>[{'no'=>69,'count'=>20,'proba'=>400},],},};
$USE[3]={'code'=>'book-sousyoku','no'=>3,'itemno'=>'66','name'=>'나유타의  목걸이를  작성한다','info'=>'나유타의  목걸이를  만들어냅니다','scale'=>'세트','action'=>'만들어낸다','money'=>0,'time'=>10800,'exptime'=>'9000','exp'=>'20','param1'=>'200','needexp'=>'500','use'=>[{'no'=>18,'count'=>1,'proba'=>0},{'no'=>19,'count'=>1,'proba'=>0},{'no'=>24,'count'=>1,'proba'=>0},{'no'=>5,'count'=>20,'proba'=>1000},{'no'=>6,'count'=>20,'proba'=>1000},{'no'=>7,'count'=>20,'proba'=>1000},{'no'=>8,'count'=>6,'proba'=>1000},],'result'=>{'function'=>'lostbook','message'=>{'resultok'=>'전설이  지금눈앞에!','resultng'=>'작성에  실패했습니다…',},'create'=>[{'no'=>70,'count'=>1,'proba'=>1000},],},};

1;
