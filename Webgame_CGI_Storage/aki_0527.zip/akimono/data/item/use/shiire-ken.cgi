package item;
$USE[0]={'code'=>'shiire-ken','no'=>0,'itemno'=>'14','name'=>'검의  시장에  구입하러  간다','info'=>'검을  구입하러  갑니다','scale'=>'왕복','action'=>'구입하러  간다','money'=>12000,'time'=>7200,'exptime'=>'3600','exp'=>'20','param1'=>'100','functionbefore'=>'_local_b1','result'=>{'function'=>'lostbook','message'=>{'resultng'=>'아무것도  매입할  수  없었습니다…',},'create'=>[{'no'=>40,'count'=>10,'proba'=>400},{'no'=>41,'count'=>10,'proba'=>350},{'no'=>42,'count'=>10,'proba'=>150},{'no'=>43,'count'=>10,'proba'=>60,'message'=>'미스릴검이&nbsp;쌌습니다'},{'no'=>44,'count'=>10,'proba'=>30,'message'=>'오리하르콘검이&nbsp;귀한&nbsp;물건으로서&nbsp;나오고&nbsp;있었습니다!'},],},};
sub _local_b1 {eval(<<'_eval_code_');
return  0  if  rand(1000)>100;my  $USE=$_[0];foreach(@{$USE->{result}->{create}}){$_->{count}*=2;}$USE->{result}->{message}->{resultok}='이번은  수확이  평소보다  많았습니다';return  0;
_eval_code_
}
sub _job_use_0_peddle_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}

1;
