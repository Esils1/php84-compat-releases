package item;
$USE[0]={'code'=>'book-kaitai','no'=>0,'itemno'=>'39','name'=>'목검/나무지팡이를  해체한다','info'=>'','scale'=>'세트','action'=>'','money'=>0,'time'=>7200,'exptime'=>'3600','exp'=>'10','use'=>[{'no'=>39,'count'=>1,'proba'=>1000},{'no'=>38,'count'=>1,'proba'=>0},{'no'=>40,'count'=>10,'proba'=>1000},{'no'=>57,'count'=>10,'proba'=>1000},],'result'=>{'create'=>[{'no'=>3,'count'=>50,'proba'=>800},],},};
sub _job_use_0_weapon_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[1]={'code'=>'book-kaitai','no'=>1,'itemno'=>'39','name'=>'가죽방패/흉갑을  해체한다','info'=>'','scale'=>'세트','action'=>'','money'=>0,'time'=>7200,'exptime'=>'3600','exp'=>'10','use'=>[{'no'=>39,'count'=>1,'proba'=>1000},{'no'=>38,'count'=>1,'proba'=>0},{'no'=>45,'count'=>10,'proba'=>1000},{'no'=>51,'count'=>10,'proba'=>1000},],'result'=>{'create'=>[{'no'=>2,'count'=>50,'proba'=>800},],},};
sub _job_use_1_armor_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[2]={'code'=>'book-kaitai','no'=>2,'itemno'=>'39','name'=>'나무방패/흉갑을  해체한다','info'=>'','scale'=>'세트','action'=>'','money'=>0,'time'=>7200,'exptime'=>'3600','exp'=>'10','use'=>[{'no'=>39,'count'=>1,'proba'=>1000},{'no'=>38,'count'=>1,'proba'=>0},{'no'=>46,'count'=>10,'proba'=>1000},{'no'=>52,'count'=>10,'proba'=>1000},],'result'=>{'create'=>[{'no'=>3,'count'=>50,'proba'=>800},],},};
sub _job_use_2_armor_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[3]={'code'=>'book-kaitai','no'=>3,'itemno'=>'39','name'=>'철검/지팡이을  해체한다','info'=>'','scale'=>'세트','action'=>'','money'=>0,'time'=>7200,'exptime'=>'5400','exp'=>'10','use'=>[{'no'=>39,'count'=>1,'proba'=>1000},{'no'=>38,'count'=>1,'proba'=>0},{'no'=>41,'count'=>10,'proba'=>1000},{'no'=>58,'count'=>10,'proba'=>1000},],'result'=>{'create'=>[{'no'=>5,'count'=>50,'proba'=>800},{'no'=>8,'count'=>10,'proba'=>500},],},};
sub _job_use_3_weapon_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[4]={'code'=>'book-kaitai','no'=>4,'itemno'=>'39','name'=>'철방패/갑옷를  해체한다','info'=>'','scale'=>'세트','action'=>'','money'=>0,'time'=>7200,'exptime'=>'5400','exp'=>'10','use'=>[{'no'=>39,'count'=>1,'proba'=>1000},{'no'=>38,'count'=>1,'proba'=>0},{'no'=>47,'count'=>10,'proba'=>1000},{'no'=>53,'count'=>10,'proba'=>1000},],'result'=>{'create'=>[{'no'=>5,'count'=>50,'proba'=>800},],},};
sub _job_use_4_armor_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[5]={'code'=>'book-kaitai','no'=>5,'itemno'=>'39','name'=>'강철검/지팡이을  해체한다','info'=>'','scale'=>'세트','action'=>'','money'=>0,'time'=>9000,'exptime'=>'6300','exp'=>'10','use'=>[{'no'=>39,'count'=>1,'proba'=>1000},{'no'=>38,'count'=>1,'proba'=>0},{'no'=>42,'count'=>10,'proba'=>1000},{'no'=>59,'count'=>10,'proba'=>1000},],'result'=>{'create'=>[{'no'=>5,'count'=>100,'proba'=>800},{'no'=>8,'count'=>10,'proba'=>500},],},};
sub _job_use_5_weapon_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[6]={'code'=>'book-kaitai','no'=>6,'itemno'=>'39','name'=>'강철방패/갑옷를  해체한다','info'=>'','scale'=>'세트','action'=>'','money'=>0,'time'=>9000,'exptime'=>'6300','exp'=>'10','use'=>[{'no'=>39,'count'=>1,'proba'=>1000},{'no'=>38,'count'=>1,'proba'=>0},{'no'=>48,'count'=>10,'proba'=>1000},{'no'=>54,'count'=>10,'proba'=>1000},],'result'=>{'create'=>[{'no'=>5,'count'=>100,'proba'=>800},],},};
sub _job_use_6_armor_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[7]={'code'=>'book-kaitai','no'=>7,'itemno'=>'39','name'=>'미스릴검/지팡이을  해체한다','info'=>'','scale'=>'세트','action'=>'','money'=>0,'time'=>10800,'exptime'=>'7200','exp'=>'10','use'=>[{'no'=>39,'count'=>1,'proba'=>1000},{'no'=>38,'count'=>1,'proba'=>0},{'no'=>43,'count'=>10,'proba'=>1000},{'no'=>60,'count'=>10,'proba'=>1000},],'result'=>{'create'=>[{'no'=>6,'count'=>50,'proba'=>700},{'no'=>8,'count'=>20,'proba'=>500},],},};
sub _job_use_7_weapon_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[8]={'code'=>'book-kaitai','no'=>8,'itemno'=>'39','name'=>'미스릴방패/갑옷를  해체한다','info'=>'','scale'=>'세트','action'=>'','money'=>0,'time'=>10800,'exptime'=>'7200','exp'=>'10','use'=>[{'no'=>39,'count'=>1,'proba'=>1000},{'no'=>38,'count'=>1,'proba'=>0},{'no'=>49,'count'=>10,'proba'=>1000},{'no'=>55,'count'=>10,'proba'=>1000},],'result'=>{'create'=>[{'no'=>6,'count'=>50,'proba'=>700},],},};
sub _job_use_8_armor_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[9]={'code'=>'book-kaitai','no'=>9,'itemno'=>'39','name'=>'오리하르콘검/지팡이을  해체한다','info'=>'','scale'=>'세트','action'=>'','money'=>0,'time'=>12600,'exptime'=>'9000','exp'=>'10','use'=>[{'no'=>39,'count'=>1,'proba'=>1000},{'no'=>38,'count'=>1,'proba'=>0},{'no'=>44,'count'=>10,'proba'=>1000},{'no'=>61,'count'=>10,'proba'=>1000},],'result'=>{'create'=>[{'no'=>7,'count'=>50,'proba'=>600},{'no'=>8,'count'=>30,'proba'=>500},],},};
sub _job_use_9_weapon_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[10]={'code'=>'book-kaitai','no'=>10,'itemno'=>'39','name'=>'오리하르콘방패/갑옷를  해체한다','info'=>'','scale'=>'세트','action'=>'','money'=>0,'time'=>12600,'exptime'=>'9000','exp'=>'10','use'=>[{'no'=>39,'count'=>1,'proba'=>1000},{'no'=>38,'count'=>1,'proba'=>0},{'no'=>50,'count'=>10,'proba'=>1000},{'no'=>56,'count'=>10,'proba'=>1000},],'result'=>{'create'=>[{'no'=>7,'count'=>50,'proba'=>600},],},};
sub _job_use_10_armor_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[11]={'code'=>'book-kaitai','no'=>11,'itemno'=>'39','name'=>'로보트를  해체한다','info'=>'','scale'=>'세트','action'=>'','money'=>0,'time'=>21600,'exptime'=>'21600','exp'=>'10','use'=>[{'no'=>39,'count'=>1,'proba'=>1000},{'no'=>38,'count'=>1,'proba'=>0},{'no'=>64,'count'=>1,'proba'=>1000},],'result'=>{'create'=>[{'no'=>5,'count'=>300,'proba'=>1000},{'no'=>6,'count'=>50,'proba'=>1000},{'no'=>7,'count'=>10,'proba'=>1000},{'no'=>8,'count'=>30,'proba'=>1000},{'no'=>65,'count'=>1,'proba'=>1000},{'no'=>4,'count'=>1,'proba'=>1000},],},};
$USE[12]={'code'=>'book-kaitai','no'=>12,'itemno'=>'39','name'=>'가죽제&nbsp;장비&nbsp;모음을  꾸린다','info'=>'','scale'=>'세트','action'=>'','money'=>0,'time'=>7200,'exptime'=>'3600','exp'=>'10','use'=>[{'no'=>39,'count'=>1,'proba'=>1000},{'no'=>45,'count'=>10,'proba'=>1000},{'no'=>51,'count'=>10,'proba'=>1000},],'result'=>{'create'=>[{'no'=>71,'count'=>10,'proba'=>1000},],},};
sub _job_use_12_tool_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[13]={'code'=>'book-kaitai','no'=>13,'itemno'=>'39','name'=>'목제&nbsp;장비&nbsp;모음을  꾸린다','info'=>'','scale'=>'세트','action'=>'','money'=>0,'time'=>9000,'exptime'=>'5400','exp'=>'10','use'=>[{'no'=>39,'count'=>1,'proba'=>1000},{'no'=>40,'count'=>10,'proba'=>1000},{'no'=>46,'count'=>10,'proba'=>1000},{'no'=>52,'count'=>10,'proba'=>1000},{'no'=>57,'count'=>10,'proba'=>1000},],'result'=>{'create'=>[{'no'=>72,'count'=>10,'proba'=>1000},],},};
sub _job_use_13_tool_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[14]={'code'=>'book-kaitai','no'=>14,'itemno'=>'39','name'=>'철제&nbsp;장비&nbsp;모음을  꾸린다','info'=>'','scale'=>'세트','action'=>'','money'=>0,'time'=>10800,'exptime'=>'7200','exp'=>'10','use'=>[{'no'=>39,'count'=>1,'proba'=>1000},{'no'=>41,'count'=>10,'proba'=>1000},{'no'=>47,'count'=>10,'proba'=>1000},{'no'=>53,'count'=>10,'proba'=>1000},{'no'=>58,'count'=>10,'proba'=>1000},],'result'=>{'create'=>[{'no'=>73,'count'=>10,'proba'=>1000},],},};
sub _job_use_14_tool_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[15]={'code'=>'book-kaitai','no'=>15,'itemno'=>'39','name'=>'강철제&nbsp;장비&nbsp;모음을  꾸린다','info'=>'','scale'=>'세트','action'=>'','money'=>0,'time'=>12600,'exptime'=>'8100','exp'=>'10','use'=>[{'no'=>39,'count'=>1,'proba'=>1000},{'no'=>42,'count'=>10,'proba'=>1000},{'no'=>48,'count'=>10,'proba'=>1000},{'no'=>54,'count'=>10,'proba'=>1000},{'no'=>59,'count'=>10,'proba'=>1000},],'result'=>{'create'=>[{'no'=>74,'count'=>10,'proba'=>1000},],},};
sub _job_use_15_tool_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[16]={'code'=>'book-kaitai','no'=>16,'itemno'=>'39','name'=>'미스릴제&nbsp;장비&nbsp;모음을  꾸린다','info'=>'','scale'=>'세트','action'=>'','money'=>0,'time'=>14400,'exptime'=>'9000','exp'=>'10','use'=>[{'no'=>39,'count'=>1,'proba'=>1000},{'no'=>43,'count'=>10,'proba'=>1000},{'no'=>49,'count'=>10,'proba'=>1000},{'no'=>55,'count'=>10,'proba'=>1000},{'no'=>60,'count'=>10,'proba'=>1000},],'result'=>{'create'=>[{'no'=>75,'count'=>10,'proba'=>1000},],},};
sub _job_use_16_tool_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[17]={'code'=>'book-kaitai','no'=>17,'itemno'=>'39','name'=>'오리하르콘제&nbsp;장비&nbsp;모음을  꾸린다','info'=>'','scale'=>'세트','action'=>'','money'=>0,'time'=>16200,'exptime'=>'10800','exp'=>'10','use'=>[{'no'=>39,'count'=>1,'proba'=>1000},{'no'=>44,'count'=>10,'proba'=>1000},{'no'=>50,'count'=>10,'proba'=>1000},{'no'=>56,'count'=>10,'proba'=>1000},{'no'=>61,'count'=>10,'proba'=>1000},],'result'=>{'create'=>[{'no'=>76,'count'=>10,'proba'=>1000},],},};
sub _job_use_17_tool_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[18]={'code'=>'book-kaitai','no'=>18,'itemno'=>'39','name'=>'축하  상품을  꾸린다','info'=>'','scale'=>'세트','action'=>'','money'=>0,'time'=>14400,'exptime'=>'14400','exp'=>'10','use'=>[{'no'=>39,'count'=>1,'proba'=>1000},{'no'=>27,'count'=>1,'proba'=>1000},{'no'=>28,'count'=>1,'proba'=>1000},{'no'=>29,'count'=>1,'proba'=>1000},],'result'=>{'create'=>[{'no'=>77,'count'=>1,'proba'=>1000},],},};
sub _job_use_18_tool_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}

1;
