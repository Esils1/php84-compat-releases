push(@EVENTMSG,'검의  수요가  높아지고  있습니다');
$ITEM[40]->{popular}=int($ITEM[40]->{popular}/2);
$ITEM[41]->{popular}=int($ITEM[41]->{popular}/2);
$ITEM[42]->{popular}=int($ITEM[42]->{popular}/2);
$ITEM[43]->{popular}=int($ITEM[43]->{popular}/2);
$ITEM[44]->{popular}=int($ITEM[44]->{popular}/2);
1;
