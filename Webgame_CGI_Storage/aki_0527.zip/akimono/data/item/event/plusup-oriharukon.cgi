push(@EVENTMSG,'오리하르콘유통량이  급격하게  증가하고  있습니다');
$ITEM[7]->{plus}=1200;
1;
