push(@EVENTMSG,'반  검운동이  일어나고  있습니다');
$ITEM[40]->{point}=0;
$ITEM[41]->{point}=-100;
$ITEM[42]->{point}=-200;
$ITEM[43]->{point}=-300;
$ITEM[44]->{point}=-400;
1;
