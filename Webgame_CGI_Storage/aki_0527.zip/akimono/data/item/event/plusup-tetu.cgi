push(@EVENTMSG,'철유통량이  급격하게  증가하고  있습니다');
$ITEM[5]->{plus}=720;
1;
