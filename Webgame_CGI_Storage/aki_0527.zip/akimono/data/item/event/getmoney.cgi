push(@EVENTMSG,'자금원조');
1;
