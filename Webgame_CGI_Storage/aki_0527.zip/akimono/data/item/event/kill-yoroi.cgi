push(@EVENTMSG,'반  갑옷  운동이  일어나고  있습니다');
$ITEM[51]->{point}=0;
$ITEM[52]->{point}=0;
$ITEM[53]->{point}=-100;
$ITEM[54]->{point}=-200;
$ITEM[55]->{point}=-300;
$ITEM[56]->{point}=-400;
1;
