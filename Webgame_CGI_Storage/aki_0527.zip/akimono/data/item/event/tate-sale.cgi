push(@EVENTMSG,'방패의  수요가  높아지고  있습니다');
$ITEM[45]->{popular}=int($ITEM[45]->{popular}/2);
$ITEM[46]->{popular}=int($ITEM[46]->{popular}/2);
$ITEM[47]->{popular}=int($ITEM[47]->{popular}/2);
$ITEM[48]->{popular}=int($ITEM[48]->{popular}/2);
$ITEM[49]->{popular}=int($ITEM[49]->{popular}/2);
$ITEM[50]->{popular}=int($ITEM[50]->{popular}/2);
1;
