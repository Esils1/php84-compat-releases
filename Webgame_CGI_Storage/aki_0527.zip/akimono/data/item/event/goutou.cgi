push(@EVENTMSG,'강도');
1;
