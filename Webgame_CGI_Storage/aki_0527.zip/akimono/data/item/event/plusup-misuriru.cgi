push(@EVENTMSG,'미스릴유통량이  급격하게  증가하고  있습니다');
$ITEM[6]->{plus}=960;
1;
