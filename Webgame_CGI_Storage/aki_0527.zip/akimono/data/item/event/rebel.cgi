push(@EVENTMSG,'반란이  일어나고  있습니다.');
1;
