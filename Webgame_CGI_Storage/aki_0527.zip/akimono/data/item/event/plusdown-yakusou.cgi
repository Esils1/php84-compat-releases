push(@EVENTMSG,'시장의  약초  공급이  멈추어  있습니다');
$ITEM[1]->{plus}=-180;
1;
