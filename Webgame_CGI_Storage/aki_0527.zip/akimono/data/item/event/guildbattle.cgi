push(@EVENTMSG,'길드  대항전이  전개되고  있습니다.');
1;
