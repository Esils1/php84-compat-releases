push(@EVENTMSG,'갑옷의  수요가  높아지고  있습니다');
$ITEM[51]->{popular}=int($ITEM[51]->{popular}/2);
$ITEM[52]->{popular}=int($ITEM[52]->{popular}/2);
$ITEM[53]->{popular}=int($ITEM[53]->{popular}/2);
$ITEM[54]->{popular}=int($ITEM[54]->{popular}/2);
$ITEM[55]->{popular}=int($ITEM[55]->{popular}/2);
$ITEM[56]->{popular}=int($ITEM[56]->{popular}/2);
1;
