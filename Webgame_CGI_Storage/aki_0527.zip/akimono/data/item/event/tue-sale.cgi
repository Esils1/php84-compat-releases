push(@EVENTMSG,'지팡이의  수요가  높아지고  있습니다');
$ITEM[57]->{popular}=int($ITEM[57]->{popular}/2);
$ITEM[58]->{popular}=int($ITEM[58]->{popular}/2);
$ITEM[59]->{popular}=int($ITEM[59]->{popular}/2);
$ITEM[60]->{popular}=int($ITEM[60]->{popular}/2);
$ITEM[61]->{popular}=int($ITEM[61]->{popular}/2);
1;
