push(@EVENTMSG,'반  방패운동이  일어나고  있습니다');
$ITEM[45]->{point}=0;
$ITEM[46]->{point}=0;
$ITEM[47]->{point}=-100;
$ITEM[48]->{point}=-200;
$ITEM[49]->{point}=-300;
$ITEM[50]->{point}=-400;
1;
