push(@EVENTMSG,'감사제로  거리는  떠들썩하고  있습니다.');
1;
