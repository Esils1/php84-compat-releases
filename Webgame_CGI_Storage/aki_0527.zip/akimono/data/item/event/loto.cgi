push(@EVENTMSG,'복권  추첨');
1;
