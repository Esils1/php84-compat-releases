push(@EVENTMSG,'반  지팡이운동이  일어나고  있습니다');
$ITEM[57]->{point}=0;
$ITEM[58]->{point}=-100;
$ITEM[59]->{point}=-200;
$ITEM[60]->{point}=-300;
$ITEM[61]->{point}=-400;
1;
