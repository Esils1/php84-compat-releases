push(@EVENTMSG,'도둑');
1;
