package item;

sub lostbook { my  $itemno=$USE->{itemno}; if(rand(1000)<$USE->{param1}) { UseItem($itemno,1,$ITEM[$itemno]->{name}.'를  읽을  수  없을  정도로  너덜너덜이  되었으므로  파기했습니다'); } return  ""; }
sub popup { my  $up=int($USE->{param1}*(2-$DT->{rank}/5000)); $DT->{rank}+=$up; $DT->{rank}=10000  if  $DT->{rank}>10000; my  $ret=$USE->{param2}."：인기  ".int($up/100)."%업"; WriteLog(0,$DT->{id},$ret); WriteLog(3,0,$DT->{shopname}."가  ".$USE->{param2}); return  $ret; } 
1;
