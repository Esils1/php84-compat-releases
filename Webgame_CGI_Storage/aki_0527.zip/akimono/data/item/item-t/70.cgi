package item;
sub _local_ {eval(<<'_eval_code_');
my($ITEM,@DT)=@_;
my  $rankup=$TIMESPAN/86.4;
$rankup=$rankup<1  &&  rand(1)<$rankup  ?  1  :  int($rankup);
return  if  !$rankup;
foreach  my  $DT  (@DT)
{
next  if  $DT->{showcase}[0]!=$ITEM->{no}  ||  $DT->{price}[0]>$ITEM->{price};
$DT->{rank}+=$rankup;
$DT->{rank}=10000  if  $DT->{rank}>10000;
DebugLog("item  $ITEM->{name}  $DT->{shopname}  인기  +".($rankup/100)."\%");
}

_eval_code_
}
1;
