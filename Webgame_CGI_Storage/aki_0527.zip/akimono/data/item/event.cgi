foreach(
'happy	5	100					18000	18000	감사제가  이  거리에서  시작되었습니다.	감사제는  막을  닫았습니다.	_local_now	',
'boom-posyon	6	70					43200	86400	항구에서는  약간의  포션  붐입니다	포션  붐이  끝난  것  같습니다		',
'ken-sale	7	100					21600	86400	검의  수요가  높아지고  있는  것  같습니다	검의  수요가  통상  레벨에  돌아왔습니다		',
'tate-sale	8	100					21600	86400	방패의  수요가  높아지고  있는  것  같습니다	방패의  수요가  통상  레벨에  돌아왔습니다		',
'yoroi-sale	9	100					21600	86400	갑옷의  수요가  높아지고  있는  것  같습니다	갑옷의  수요가  통상  레벨에  돌아왔습니다		',
'tue-sale	10	100					21600	86400	지팡이의  수요가  높아지고  있는  것  같습니다	지팡이의  수요가  통상  레벨에  돌아왔습니다		',
'plusdown-yakusou	15	100					172800	86400	약초  재배  업자가  약초의  판매를  거부하고  있는  것  같습니다	약초  재배  업자가  약초의  판매를  재개했습니다		',
'plusup-tetu	16	100					43200	43200	새롭게  철광맥이  발견되었습니다	새로운  철광맥이  폐산했습니다		',
'plusup-misuriru	17	70					32400	57600	새롭게  미스릴  광맥이  발견되었습니다	새로운  미스릴  광맥이  폐산했습니다		',
'plusup-oriharukon	18	50					21600	64800	새롭게  오리하르콘  광맥이  발견되었습니다	새로운  오리하르콘  광맥이  폐산했습니다		',
'manbiki	19	1000	_local_start	400,200			0	0				',
'goutou	20	200	_local_start	700			0	0				',
'getmoney	21	300	_local_start	100000								',
'getpop	22	300	_local_start	1000			0	0				',
'loto	23	500	_local_start				0	0				',
'rebel	24	0									_local_now	',
'guildbattle	25	0			_local_end							',
)
{
	my $hash={};
	(
		$hash->{code},
		$hash->{group},
		$hash->{startproba},
		$hash->{startfunc},
		$hash->{startfuncparam},
		$hash->{endfunc},
		$hash->{endfuncparam},
		$hash->{basetime},
		$hash->{plustime},
		$hash->{startmsg},
		$hash->{endmsg},
		$hash->{func},
		$hash->{funcparam},
	) =split(/\t/);
	$EVENT{$hash->{code}}=$hash;
}
1;
