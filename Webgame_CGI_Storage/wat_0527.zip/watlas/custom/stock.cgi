# 창고 2005/01/06 유래
# 월드 아틀라스 사양

DataRead();
CheckUserPass();

$MENUSAY=GetMenuTag('log','[신문]')
	.GetMenuTag('shop-a',	'[상가]')
	.GetMenuTag('shop-m',	'[시장에]')
	.GetMenuTag('main',	'[점내로 돌아간다]');

RequireFile('inc-html-ownerinfo.cgi');

if ($DT->{trush} > 5000000)
	{
	$disp.="<BIG>●창고</BIG><br><br>";
	$disp.=$TB.$TR.$TD.GetTagImgKao("도우미","help").$TD;
	$disp.="<SPAN>도우미</SPAN>：상품이 쓰레기안에 파묻혀 있어, 찾아낼 수 없습니다.";
	$disp.="<br>먼저 청소해, 쓰레기를 정리합시다.".$TRE.$TBE;
	$disp.="<br>".GetMenuTag('sweep','[청소에]');
	OutSkin();
	exit;
	}

my $tp=$Q{tp};
my $pg=$Q{pg};

my $DTitem=$DT->{item};
my $DTitemtoday=$DT->{itemtoday};
my $DTitemyesterday=$DT->{itemyesterday};
my $DTexp=$DT->{exp};

foreach my $no(1..$MAX_ITEM)
{
	$ITEM=$ITEM[$no];
	next if (!$DTitem->[$no-1] && !$DTitemtoday->{$no} && !$DTexp->{$no});

	if ($no > 25 && $no < 38)
	{
	$ITEM[$no]->{name}.="(출항중)" if -e(GetPath($SUBDATA_DIR,$DT->{id}."-exp".$no));
	}

	if ($ITEM->{flag}=~/s/)	# s 진열 불가
	{
	$itema{$no}=$ITEM;
	}
	else
	{
	next if ($ITEM->{type} != $tp)&&($tp != 0);;
	$itemb{$no}=$ITEM;
	}
}

GetMarketStatus();

my %showcase=();
my $itemno;
foreach(0..$DT->{showcasecount}-1)
{
	next if !($itemno=$DT->{showcase}[$_]);
	$showcase{$itemno}.="진".($_+1).GetMoneyString($DT->{price}[$_])." ";
}

if(%itema)
{
	$disp.="<BIG>●보관 창고</BIG><br><br>";
	$disp.=$TB;
	if($MOBILE)
	{
		$tdh_sp="표준:";
		$tdh_cs="유지:";
		$tdh_st="재고:";
		$tdh_ex="숙련:";
	}
	else
	{
		$disp.=$TR.$TDB.
			join($TDB,
				qw(
					명칭
					표준가격
					유지비
					수량<small>/최대</small>
					숙련
				)
			).$TRE;
	}
	
	foreach my $ITEM (sort{$a->{sort} <=> $b->{sort}} values(%itema))
	{
		my $cnt=$ITEM->{no};
		my $name=GetTagImgItemType($cnt).$ITEM->{name};
		$name="<A HREF=\"action.cgi?key=item&no=$cnt&bk=s&$USERPASSURL\">".$name."</A> " if $DTitem->[$cnt-1];
		
		$disp.=$TR.$TD.
			join($TD,
				$name,
				$tdh_sp.GetMoneyString($ITEM->{price}),
				$tdh_cs.GetMoneyString($ITEM->{cost}),
				$tdh_st.$DTitem->[$cnt-1]."<small>/".$ITEM->{limit}."</small>",
				$tdh_ex.($DTexp->{$cnt} ? int($DTexp->{$cnt}/10)."%" : '　'),
			);
	}
	$disp.=$TBE."<hr width=500 noshade size=1>";
}

$disp.="<BIG>●판매 창고</BIG><br><br>";
foreach my $cnt (0..$#ITEMTYPE)
{
	$disp.=$cnt==$tp ? "[" : "<A HREF=\"action.cgi?key=stock&$USERPASSURL&tp=$cnt\">";
	$disp.=GetTagImgItemType(0,$cnt) if $cnt && !$MOBILE;
	$disp.=$ITEMTYPE[$cnt];
	$disp.=$cnt==$tp ? "]" :"</A> ";
	$disp.=" ";
}

if(!%itemb)
{
	$disp.="<hr width=500 noshade size=1>재고가 없습니다";
}
else
{
	$disp.=$TB;
	if($MOBILE)
	{
		$tdh_sp="표준:";
		$tdh_cs="유지:";
		$tdh_ts="본작매:";
		$tdh_ex="숙련:";
		$tdh_sc="진열:";
		$tdh_mp="시세:";
		$tdh_mb="수급:";
	}
	else
	{
		$disp.=$TR.$TDB.
			join($TDB,
				qw(
					명칭
					표준가격
					유지비
					수량<small>/최대</small>
					매상수<small>/전기</small>
					숙련
					진열
					판매시세
					수요공급 균형
				)
			).$TRE;
	}
	
	foreach my $ITEM (sort{$a->{sort} <=> $b->{sort}} values(%itemb))
	{
		my $cnt=$ITEM->{no};
		my $name=GetTagImgItemType($cnt).$ITEM->{name};
		$name="<A HREF=\"action.cgi?key=item&no=$cnt&bk=s&$USERPASSURL\">".$name."</A> " if $DTitem->[$cnt-1];
		
		$disp.=$TR.$TD.
			join($TD,
				$name,
				$tdh_sp.GetMoneyString($ITEM->{price}),
				$tdh_cs.GetMoneyString($ITEM->{cost}),
				$tdh_st.$DTitem->[$cnt-1]."<small>/".$ITEM->{limit}."</small>",
				$tdh_ts.($DTitemtoday->{$cnt} || $DTitemyesterday->{$cnt} ? ($DTitemtoday->{$cnt}||0)."<small>/".($DTitemyesterday->{$cnt}||0)."</small>" : '　'),
				$tdh_ex.($DTexp->{$cnt} ? int($DTexp->{$cnt}/10)."%" : '　'),
				$tdh_sc.($showcase{$cnt}||'　'),
				$tdh_mp.($ITEM->{marketprice} ? GetMoneyString($ITEM->{marketprice}) : '　'),
			);
		$disp.=$TDNW.$tdh_mb.GetMarketStatusGraph($ITEM->{uppoint}||=10).$TRE;
	}
	$disp.=$TBE;
}
OutSkin();
1;
