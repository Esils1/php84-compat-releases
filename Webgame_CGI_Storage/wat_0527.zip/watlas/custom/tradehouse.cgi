# 상관 2005/01/06 유래
# 월드 아틀라스판

DataRead();
CheckUserPass(1);
RequireFile('inc-sea.cgi');

$disp.=GetMenuTag('tradehouse',		'[유럽]')
	.GetMenuTag('tradehouse',	'[아프리카]','&sea=2')
	.GetMenuTag('tradehouse',	'[중동]','&sea=3')
	.GetMenuTag('tradehouse',	'[인도]','&sea=4')
	.GetMenuTag('tradehouse',	'[아시아]','&sea=5')
	.GetMenuTag('tradehouse',	'[신대륙]','&sea=6');
$disp.="<hr width=500 noshade size=1>";
$Q{sea}||=1;
ReadSea($Q{sea});
my @AREA=("","유럽","아프리카","중동","인도","아시아","신대륙");

$disp.="<BIG>●상관</BIG><br><br>";

$disp.="$TB$TR$TDB".$AREA[$Q{sea}];
$disp.="$TD<SPAN>미답파영역</SPAN>：".(100 - $Civ)." %";
$disp.="$TD<SPAN>해적 출현률</SPAN>：".($Pir + 0)." %";
$disp.="$TD<SPAN>해군 정찰률</SPAN>：".($Pro + 0)." %";
$disp.=$TRE.$TBE;

$disp.=<<STR;
<br>
$TB$TR
$TDB 도시명
$TDB 발견자
$TDB 산물
$TDB 구입치
$TDB 산출량
$TDB 항로
$TRE
STR

foreach(1..$#SEA)
	{
	my @buf=split(',',$main::SEA[$_]);
	next if !$buf[0];
	$disp.=$TR;
	$disp.=$TD.$buf[1];
	$disp.=defined($id2idx{$buf[2]}) ?'<td>'.$DT[$id2idx{$buf[2]}]->{shopname} : '<td>없음';
	$disp.=$TD.GetTagImgItemType($buf[3]).$ITEM[$buf[3]]->{name}."<br>";
	$disp.="<small>(정가 ".GetMoneyString($ITEM[$buf[3]]->{price}).")</small>";
	$disp.=$TD.GetMoneyString($buf[4])."<br>";
	$disp.="<small>(정가의 ".int($buf[4] / $ITEM[$buf[3]]->{price} * 100)."%)</small>";
	$disp.=$TD.GetAmountMessage($buf[0]);
	$disp.=$TD."(".($buf[5] + 0)."개)";
	$disp.=$TRE;
	}
	$disp.=$TBE;

OutSkin();
1;


sub GetAmountMessage
{
	my($rank)=@_;
	my $per=int(($rank - $NOW_TIME)/8640);
	$per=100 if $per > 100;
	$per=0 if $per < 0;
	my $i="제품 부족";
	$i="보통" if $per>=30;
	$i="풍부" if $per>=60;
	$i="널림" if $per>=80;
	my $bar="";
	$bar ="<nobr>";
	$bar.=qq|<img src="$IMAGE_URL/b.gif" width="|.(    $per).qq|" height="12">| if $per;
	$bar.=qq|<img src="$IMAGE_URL/t.gif" width="|.(100-$per).qq|" height="12">| if $per!=100;
	$bar.=" ".$i;
	$bar.="</nobr><br>";
	
	return $bar;
}

