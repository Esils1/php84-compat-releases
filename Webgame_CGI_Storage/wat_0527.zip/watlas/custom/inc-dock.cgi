# 도크 편성 처리 2004/02/28 유래
# 월드 아틀라스판

OutError("출항중의 선단은 편성 변경할 수 없습니다.") if -e (GetPath($SUBDATA_DIR,$DT->{id}."-exp".$Q{ship}));

# 설정
my @SHIP=(
	[20,8,0,0,0,0,6,3,6],
	[12,20,8,0,0,0,10,5,10],
	[0,12,20,8,0,0,12,6,12],
	[0,0,12,20,8,0,14,7,14],
	[0,0,0,12,20,8,16,8,16],
	[0,0,0,0,12,20,18,9,18],
	[0,0,0,0,20,20,20,10,20],
);

# 현상에서의 선박 보관 유지수를 계산
foreach(0..4)
	{
	next if !$subdata[$_];
	$DT->{item}[$subdata[$_]-1]++;
	}

undef @subdata;
my $csr=0;	# 기입 위치

foreach my $num(5..11)
	{
	foreach my $cnt(1..5)
		{
		my $data=$num."_".$cnt;
		next if !$Q{$data};
		OutError("5개 이상 선택되고 있습니다") if $scr > 4;
		$subdata[$scr]=$num;
		$scr++;
		$DT->{item}[$num-1]--;
		my @buf=@{$SHIP[$num-5]};
		foreach my $i(0..8)
			{
			$subdata[$i+5]+=$buf[$i];
			}
		}
	OutError("배가 소지수를 넘어서 선택되었습니다") if $DT->{item}[$num-1] < 0;
	}

if (!$scr)
{
$DT->{item}[$Q{ship}-1]=0;
unlink (GetPath($SUBDATA_DIR,$DT->{id}."-abi".$Q{ship}));
}
else
{
if ($DT->{job} eq "pirate" || $DT->{job} eq "pros")
	{
	$subdata[11]*=2;
	$subdata[12]*=4;
	$subdata[13]*=2;
	}
$DT->{item}[$Q{ship}-1]=1;
WriteShipSub($DT->{id}."-abi".$Q{ship},@subdata);
}
DataWrite();
DataCommitOrAbort();
UnLock();


sub WriteShipSub
{
	my($filename,@subdata)=@_;
	OpenAndCheck(GetPath($SUBDATA_DIR,$filename));
	print OUT join(",",@subdata);
	close(OUT);
}
1;

