# 신규 개점 2004/02/28 유래
# 월드 아틀라스용

$image[0]=GetTagImgKao("안내인","guide");
$image[1]=GetTagImgKao("임금님","king",'align="left" ');
DataRead();

if($Q{admin} ne $MASTER_PASSWORD)
{
	OutError('신규 가게 등록 권한이 없습니다.') if $NEW_SHOP_ADMIN;
	OutError('당신은 벌써 가게를 가지고 있습니다.') if GetIPList(GetTrueIP());
	OutError('당신은 다른 거리에서 벌써 가게를 가지고 있습니다.') if $NEW_OTHERTOWN_BLOCK && GetDoubleIP(GetTrueIP());
	OutError('당신은 현재 등록제한 되고 있습니다.') if $NEW_SHOP_BLOCKIP && GetTrueIP() eq $DTblockip;
	OutError('출점 키워드가 올바르지는 않습니다.') if $NEW_SHOP_KEYWORD && $Q{sname} && $Q{newkey} ne $NEW_SHOP_KEYWORD;
	checkMaxUser();
}

if($Q{sname}.$Q{name}.$Q{pass1}.$Q{pass2})
{

	if(($Q{sname}.$Q{name}.$Q{pass1}.$Q{pass2}) =~ /([,:;\t\r\n<>&])/
	|| ($Q{pass1}.$Q{pass2}) =~ /([^A-Za-z0-9_\-])/  #.$Q{name}를 삭제
	|| $Q{name} eq 'soldoutadmin'
	|| CheckNGName($Q{sname})
	|| CheckNGName($Q{name})  #이름의 체크를 추가
	)
	{
		OutError('이름·점명·비밀번호에 사용할 수 없는 '.
		         '문자가 포함되어 있습니다.');
	}
	if(!$Q{sname} || !$Q{name} || !$Q{pass1} || !$Q{pass2})
	{
		OutError('이름·점명·비밀번호를 입력해 주세요.');
	}
	if($Q{pass1} ne $Q{pass2})
	{
		OutError('확인 비밀번호가 차이가 납니다.');
	}
	if(length($Q{sname})<4)
	{
		OutError('점명의 문자수가 적습니다.');
	}
	if(length($Q{name})>12 || length($Q{sname})>20
	|| length($Q{pass1})>12 || length($Q{pass2})>8)
	{
		OutError('이름(전각 6 문자)·점명(전각 10 문자)·비밀번호(8 문자)의 문자수가 많습니다.');
	}
	if( $Q{name} eq $Q{pass1} )
	{
		OutError('이름과 비밀번호는 같게 하지 말아 주세요.');
	}
	
	Lock();
	DataRead();
	OutError('이미 존재하는 이름입니다.-> '.$Q{name}) if $name2pass{$Q{name}};
	OutError('이미 존재하는 점명입니다.-> '.$Q{sname}) if GetDoubleName($Q{sname});;
	
	$idx=$DTusercount;
	$DTlasttime=$NOW_TIME if !$idx;
	$DT[$idx]={};
	$DT=$DT[$idx];
	$DT->{status}	    =1;
	$DT->{id}           =$DTnextid;
	$DT->{lastlogin}    =$NOW_TIME;
	$DT->{name}         =$Q{name};
	$DT->{shopname}     =$Q{sname};
	$DT->{icon}     =$Q{icon};
	$DT->{pass}         =$PASSWORD_CRYPT ? crypt($Q{pass1},GetSalt()) : $Q{pass1};
	$DT->{money}        =100000;
	$DT->{moneystock}   =0;
	$DT->{time}         =$NOW_TIME-12*60*60;
	$DT->{rank}         =5010;
	$DT->{saleyesterday}=0;
	$DT->{saletoday}    =0;
	$DT->{costtoday}    =0;
	$DT->{costyesterday}=0;
	$DT->{paytoday}     =0;
	$DT->{payyesterday} =0;
	$DT->{showcasecount}=1;
	$DT->{itemyesterday}={};
	$DT->{itemtoday}	={};
	$DT->{remoteaddr}   =GetTrueIP();
	$DT->{rankingyesterday}='';
	$DT->{taxtoday}     =0;
	$DT->{taxyesterday} =0;
	$DT->{foundation}   =$NOW_TIME;
	foreach $cnt (0..$DT->{showcasecount}-1)
	{
		$DT->{showcase}[$cnt]=0;
		$DT->{price}[$cnt]=0;
	}
	foreach $cnt (0..$MAX_ITEM-1)
	{
		$DT->{item}[$cnt]=0;
	}

	$DTblockip=$DT->{remoteaddr};

	require "$ITEM_DIR/funcnew.cgi" if $DEFINE_FUNCNEW;
	PushLog(1,0,$Q{sname}."가 신장개점했습니다.") if !$DEFINE_FUNCNEW || !$DEFINE_FUNCNEW_NOLOG;

	RenewLog();
	DataWrite();
	DataCommitOrAbort();
	UnLock();

	$disp=<<STR;
거리에 새로운 가게가 탄생했습니다.<br><br>
<TABLE cellpadding="26" width="570"><tr>
<TD style="background-repeat : repeat-x;background-image : url($IMAGE_URL/palace.png);" valign="top"><br><br>
$image[1]잘 참여했다. <b>$Q{name}</b>야. 너의 가게 「<b>$Q{sname}</b>」의 출점을 인정하도록한다.<br>
너의 출점에 대해, 왕국이 묶는 계약은 이하와 같다.<br>
<ul><li>
만약, <SPAN>조선</SPAN>을 원한다면, 타국에서 만들 수 없는 배와 대포를 만들 것.
</li>
<li>
만약, <SPAN>모험</SPAN>을 원한다면, 세계의 발견을 왕국에 보고해라.<br> 발견한 사실은 누구에게도 발설하지 않을 것.
</li>
<li>
만약, <SPAN>교역</SPAN>을 원한다면, 세계의 상품을 모두 왕국으로 모을 것.
</li>
<li>
만약, <SPAN>해적</SPAN>을 원한다면, 타국의 상선을 공격해라.<br> 다만, 왕국의 이름을 자칭하지 않을 것.
</li>
<li>
만약, <SPAN>해군</SPAN>을 원한다면, 타국의 해적을 소탕해라.<br> 해적의 소지품은 원하는대로 처분해도 좋다.
</li>
</ul>
너의 <SPAN>비밀번호</SPAN>는 「<b>$Q{pass1}</b>」이다. 반드시 메모 하도록.<br>
우리 왕국은, 대륙의 영토로는 소국이다. 그러나, 바다의 패권이라면, 어느 나라에게도 지지 않는다.<br>
왕국의 영광이기 때문에, 너의 활약이 있기를 빈다.
$TRE$TBE
<BR>
$TB$TR
$TD$image[0]$TD
스타트 하면, 우선 <SPAN>[게시판]</SPAN>으로 인사를 하면 좋을 것입니다.<br>
또 <SPAN>[도서관]</SPAN>에 경영의 힌트가 있기 때문에 대충 봐두세요.
$TRE$TBE
<BR>
<A HREF=\"index.cgi?u=$Q{name}!$Q{pass1}\">게임 스타트</A> <BR><BR>
로그인 후의 [♪]를 누르면 BGM를 연주할 수가 있습니다.
STR
	OutSkin();
	exit;
}

RequireFile("inc-new.cgi");
OutSkin();
1;

sub checkMaxUser
{
	OutError($TB.$TR.$TD.$image[0].$TD.'죄송합니다만, 현재 만원이 되었습니다. <BR>빈 곳이 나오기를 기다려 주세요.'.$TRE.$TBE)
		if $DTusercount>=$MAX_USER;
}

sub GetDoubleIP
{
	foreach my $pg(@OtherDir)
	{
	my $datafile='../'.$pg.'/data/user.cgi';
	my($ip)=@_;
	open(IN,$datafile) or return();
	my @data=<IN>;
	close(IN);
	my @list=map{(split(/\t/,$_))[4]}@data;
	@list=grep($_ eq $ip,@list) if $ip ne '';
	return @list if (@list);
	}
}
