# 신규 개점 사용자 지정용 2004/01/20 유래

# 신규 개점시의 주의 사항의 표시등을 사용자 지정 할 수 있습니다.
# 다만,어느 정도의 HTML의 지식과 프로그램의 이해가 필요합니다.

$disp.=<<"HTML";
<BIG>●처음에</BIG><br><br>
$TB$TR
$TD$image[0]$TD
이 게임은, 브라우저로 플레이 할 수 있는 경영 시뮬레이션 RPG입니다.<br>
참가하기 전에, 도서관에서 룰이나 플레이 방법을 잘 읽어 주세요.
$TRE$TBE
<hr width=500 noshade size=1>
HTML

$i_rand=int(rand($ICON_NUMBER))+1;
$disp.="<BIG>●신규 가게 오픈：남은 수 ".($MAX_USER-$DTusercount)."명</BIG><br>";
$disp.=<<"HTML";
<small>등록은 <b>1명 1 가게</b>로</small><br>
<FORM ACTION="action.cgi" $METHOD>
<INPUT TYPE=HIDDEN NAME=key VALUE="new">
<INPUT TYPE=HIDDEN NAME=admin VALUE="$Q{admin}">
<TABLE>
  <TR>
    <TD>
<SPAN>이름</SPAN>：<INPUT TYPE=TEXT NAME=name> 반각 전각 OK<BR>
<SPAN>점명</SPAN>：<INPUT TYPE=TEXT NAME=sname> 반각 전각 OK<BR>

<SPAN>아이콘</SPAN>：<SELECT NAME=icon>
<OPTION value="$i_rand" selected>랜덤</OPTION>
HTML

foreach my $i(1..$ICON_NUMBER)
	{
	$disp.=qq|<OPTION value="$i">아이콘 $i</OPTION>|;
	}

$disp.=<<"HTML";
</SELECT> 
<input type="button" value="아이콘 일람" onclick="javascript:window.open('action.cgi?key=icon','_blank','width=450,height=380,scrollbars')">
<br>
<SPAN>비밀번호</SPAN>：<INPUT TYPE=PASSWORD maxlength=12 NAME=pass1> 반각영수만<BR>
<SPAN>비밀번호 확인</SPAN>：<INPUT TYPE=PASSWORD maxlength=12 NAME=pass2><BR>
HTML

$disp.="<SPAN>출점 키워드</SPAN>：<INPUT TYPE=TEXT NAME=newkey><BR>" if ($NEW_SHOP_KEYWORD);

$disp.=<<"HTML";
<center><INPUT TYPE=SUBMIT VALUE="등록"></center>
</TD></TR>
</TABLE>
<small>※겹칠 것 같은 이름은 피합시다.<br>
※비밀번호는 타인이 추측할 수 없을 듯한 것을..</small>
</FORM>
HTML
1;
