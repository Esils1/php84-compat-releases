# MIDI의 설정 파일 2005/03/30 유래

# -------- 설정 부분 ----------
# MIDI의 파일명을 변경할 수 있습니다.
# CGI별 서버의 곳에서는,여기를 http:// 로부터 시작되는 패스로 지정합니다.

$MIDI_URL = "midi.mid";

# ----------------------------

$NOMENU=1;
$Q{bk}="none";
print "Content-type: text/html; charset=UTF-8\n\n";

my $bgmtag;

if ($ENV{HTTP_USER_AGENT}=~ /MSIE/ && $ENV{HTTP_USER_AGENT}!~ /Opera/)
	{
	$bgmtag=qq|<BGSOUND src="$MIDI_URL" loop=infinite>|;
	}
	else
	{
	$bgmtag=qq|<EMBED src="$MIDI_URL" width=2 height=2 autostart=true loop=true>|;
	}
print "Content-type: text/html; charset=UTF-8\n\n";
print <<"EOM";
<HEAD>
<TITLE>BGM</TITLE>
$bgmtag
</HEAD>
<BODY>
</HTML>
EOM
exit;
1;