# 메뉴 설정 파일 2005/03/30 유래
# 월드 아틀라스판

# 메뉴에 표시시키는 리스트를 설정할 수 있습니다.
# 최초의 일행이 「메뉴 항목명」,
# 다음의 행으로부터는 「부메뉴명」,「프로그램명」입니다.
#   ※프로그램명에는 주소도 지정 가능합니다.

my @MENU=(
	# 게스트 권한의 경우의 메뉴
	['거리 안내',[
		['풍경',	'town'],
		['신문',	'log'],
		['도서관',	'action.cgi?key=library',	"_blank"],
	]],

	# 이하 플레이어 권한의 경우의 메뉴
	['내가게',[
		['점내',	'main'],
		['창고',	'stock'],
		['청소',	'sweep'],
		['수지',	'balance'],
		['수속',	'other'],
		['LogOut',	'index.cgi'],
	]],
	['거래',[
		['시장',	'shop-m'],
		['상가',	'shop-a'],
		['의뢰소',	'req'],
		['궁전',	'palace'],
		['상관',	'tradehouse'],
	]],
	['정보',[
		['풍경',	'town'],
		['신문',	'log'],
		['도서관',	'action.cgi?key=library',	"_blank"],
	]],
	['시설',[
		['영주의 저택',	'lord'],
		['길드',	'gd'],
		['경기장',	'slime'],
		['용병소',	'army'],
		['주택지',	'hometown'],
		['도크',	'dock'],
	]],
	['교류',[
		['우체국',	'letter'],
		['택배우편',	'dwarf'],
		['게시판 '.GetTime2FormatTime((stat($COMMON_DIR.'/treelog.cgi'))[9]+0,1),	'treebbs'],
		['wis',	'wis'],
	]],
);

# 이하는 프로그램입니다.편집하려면  기술이 필요합니다.------------------------------

my $now=$DTlasttime+$TZ_JST-$DATE_REVISE_TIME;
my $nextday=$now+$ONE_DAY_TIME-($now % $ONE_DAY_TIME);
$DISP{MENU} =~ s/#SKINMENUTITLE#/$TOWN_TITLE/;

if($USER && $USER ne 'soldoutadmin')
	{
	$DISP{MENU} =~ s/#SKINJOB#/GetTagImgJob($DT->{job},$DT->{icon}) /e;
	my $i;
	my $MENUMSG;
	my $file=GetPath($SUBDATA_DIR,$DT->{id}."-wis");
	$MENUMSG.=<<"STR";
<i id="lay"></i>
<SCRIPT LANGUAGE="JavaScript">
<!--
menudata=[
STR
	$MENUMSG.="'";
	$MENUMSG.=(-e $file) ?WisRead($file) : "<BIG>활동중</BIG> &gt; <small>".LoginMember()."</small>";
	$MENUMSG.="',";
	foreach(1..$#MENU)
		{
		my $msg=@{$MENU[$_]}[0];
		my @list=@{@{$MENU[$_]}[1]};
		$i.=qq|<A href="javascript:mymenu($_)">【$msg】</A>  |;
		$MENUMSG.="'";
		$MENUMSG.="<BIG>$msg</BIG> &gt; ";
		foreach my $sublist(@list)
			{
			my @SUBMENU=@{$sublist};
			$MENUMSG.=(($SUBMENU[1] =~ /\./) ? GetTagA("[".$SUBMENU[0]."]",$SUBMENU[1],0,$SUBMENU[2]) : GetMenuTag($SUBMENU[1],"[".$SUBMENU[0]."]"));
			}
		$MENUMSG.=qq|<A href="javascript:mymenu(0)">【×】</A>  |;
		$MENUMSG.="',";
		}
	$MENUMSG.=<<"STR";
];
function mymenu(i){
document.getElementById("lay").innerHTML = menudata[i];
}
mymenu(0);
// -->
</SCRIPT>
STR
	$i.=qq|<A HREF="action.cgi?key=bgm&$USERPASSURL&mode=$Q{key}" target="_self">[♪]</a>  |;
	$i.='[다음번 결산 '.GetTime2FormatTime($nextday-$TZ_JST+$DATE_REVISE_TIME).'까지 나머지'.GetTime2HMS(int(($nextday-$now)/60)*60+59).']';
	$DISP{MENU} =~ s/#SKINMENU#/$i/;
	$DISP{MENU} =~ s/#SKINMENUSUB#/$MENUMSG/;
	}
	else
	{
	$DISP{MENU} =~ s/#SKINTITLE#/$HTML_TITLE/;
	$DISP{MENU} =~ s/#SKINJOB#/GetTagImgJob("guest",0) /e;
	my $i;
	my $MENUMSG;
	my $msg=@{$MENU[0]}[0];
	my @list=@{@{$MENU[0]}[1]};
	$MENUMSG.=qq|<BIG>$msg</BIG> > |;
	foreach my $sublist(@list)
		{
		my @SUBMENU=@{$sublist};
		$MENUMSG.=(($SUBMENU[1] =~ /\./) ? GetTagA("[".$SUBMENU[0]."]",$SUBMENU[1],0,"_blank") : GetMenuTag($SUBMENU[1],"[".$SUBMENU[0]."]"));
		}
	$i.=($MYNAME eq 'index.cgi')? qq|<A HREF="$HOME_PAGE" TARGET=_top>[홈]</A>  | : qq|<A HREF="index.cgi" TARGET=_top>[탑]</A>  |;
	$i.='[다음번 결산 '.GetTime2FormatTime($nextday-$TZ_JST+$DATE_REVISE_TIME).'까지 나머지'.GetTime2HMS(int(($nextday-$now)/60)*60+59).']';
	$DISP{MENU} =~ s/#SKINMENU#/$i/;
	$DISP{MENU} =~ s/#SKINMENUSUB#/$MENUMSG/;
	}
print $DISP{MENU};
1;


sub LoginMember
{
my $logmemb="";
my $i=0;
foreach(@DT)
	{
	next if ($_->{lastlogin} < $NOW_TIME - 120);
	$logmemb .= " , ".$_->{shopname};
	$i++;
	$logmemb .= " 외",last if ($i > 3);
	}
$logmemb = substr($logmemb,3) if ($logmemb);
$logmemb = "없음" if !$logmemb;
return $logmemb
}

sub WisRead
{
	my ($file)=@_;
	open(IN,$file) or return;
	read(IN,my $buf,-s $file);
	close(IN);
	unlink $file;
	return $buf;
}

