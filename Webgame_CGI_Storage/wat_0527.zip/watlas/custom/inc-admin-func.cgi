# 관리 기능 하청 2003/09/25 유래
# 월드 아틀라스판(유럽 해역의 초기설정)

my $functionname=$Q{mode};
OutError("부정한 리퀘스트입니다") if !defined(&$functionname);
&$functionname;

sub menteon
{
	if(-d "$DATA_DIR/lock")
		{push(@log,'현재 점검 모드입니다');}
	elsif(mkdir("$DATA_DIR/lock",$DIR_PERMISSION))
		{push(@log,'점검 모드에 들어갔습니다');}
	else
		{push(@log,'점검 모드로 이행할 수 없었습니다',$checkdatadir);}
}

sub menteoff
{
	if(!-d "$DATA_DIR/lock")
		{push(@log,'현재 점검 모드가 아닙니다');}
	elsif(rmdir("$DATA_DIR/lock"))
		{push(@log,'점검 모드를 해제했습니다');}
	else
		{push(@log,'점검 모드의 해제에 실패했습니다',$checkdatadir);}
}

sub errdel
{
	unlink("$DATA_DIR/error.log");
	push(@log,'오류 정보를 삭제했습니다.');
}

sub init
{
	CheckLock();
	#각종 디렉토리＆더미 index.html 작성
	foreach my $dir ($COMMON_DIR,$DATA_DIR,$SESSION_DIR,$COTEMP_DIR,$TEMP_DIR,$LOG_DIR,$SUBDATA_DIR,$BACKUP_DIR)
	{
		if(!-d $dir)
		{
			if(mkdir($dir,$DIR_PERMISSION))
				{push(@log,'디렉토리 '.$dir.'를 작성했습니다');}
			else
			{
				push(@log,'디렉토리 '.$dir.'는 작성 할 수 없었습니다');
				push(@log,'설정을 다시 보던지, 수동으로 작성해 주세요');
			}
		}
		if(!-e "$dir/index.html")
		{
			if(open(OUT,">$dir/index.html"))
			{
				print OUT "<html></html>";
				close(OUT);
				push(@log,'디렉토리 '.$dir.'에 더미의 index.html를 작성했습니다');
			}
			else
			{
				push(@log,'디렉토리 '.$dir.'에의 더미 index.html 작성에 실패했습니다');
				push(@log,'디렉토리 '.$dir.'의 권한을 다시 봐 주세요');
			}
		}
	}
	
	#락 파일 작성
	if(!GetFileList($DATA_DIR,"^$LOCK_FILE"))
	{
		if(open(DATA,">$DATA_DIR/$LOCK_FILE"))
		{
			print DATA '락 파일입니다.삭제 해서는 안됩니다.';
			close(DATA);
			push(@log,'락 파일을 작성했습니다');
		}
		else
		{
			push(@log,'락 파일의 작성에 실패했습니다');
		}
	}
	if(!GetFileList($COMMON_DIR,"^$LOCK_FILE"))
	{
		if(open(DATA,">$COMMON_DIR/$LOCK_FILE"))
		{
			print DATA '락 파일입니다.삭제 해서는 안됩니다.';
			close(DATA);
			push(@log,'공유 락 파일을 작성했습니다');
		}
		else
		{
			push(@log,'공유 락 파일의 작성에 실패했습니다');
		}
	}
	
	#타운 데이터 작성
	MakeTownFile();
	
	#신규 게임 데이터 작성
	if(!-e "$DATA_DIR/$DATA_FILE$FILE_EXT")
	{
		if(open(DATA,">$DATA_DIR/$DATA_FILE$FILE_EXT"))
		{
			print DATA time()."\n500000,100,,0,0:0:0:0:5001:0:5001:0:0:2000:0\n\n\n//\n"; #초기 상태
			close(DATA);
			unlink(map{"$DATA_DIR/$_$FILE_EXT"}grep($_ ne $DATA_FILE,@BACKUP_FILES)); #관련 파일을 소거 초기화
			push(@log,'게임 데이터를 신규 작성했습니다');
		}
		else
			{push(@log,'게임 데이터의 신규 작성에 실패했습니다',$checkdatadir);}
	}
	
	#유럽 해역 데이터 작성(월드 아틀라스)
	if(!-e "$DATA_DIR/sea1$FILE_EXT")
	{
		if(open(DATA,">$DATA_DIR/sea1$FILE_EXT"))
		{
			print DATA "5,5,0\n".(time() + 86400 * 5).",런던 시티,0,55,800,0\n"; #초기 상태
			close(DATA);
			push(@log,'유럽 해역 데이터를 신규 작성했습니다');
		}
		else
			{push(@log,'유럽 해역 데이터의 신규 작성에 실패했습니다',$checkdatadir);}
	}

	#최종 갱신 시각 검사용 파일 작성
	MakeFile("$DATA_DIR/$LASTTIME_FILE$FILE_EXT",'최종 갱신 시각 검사용 파일','');
	#길드 정의 파일 베이스 작성
	MakeFile("$DATA_DIR/$GUILD_FILE$FILE_EXT",'길드 정의 파일','1;');
	
	sub MakeFile
	{
		if(!-e $_[0])
		{
			if(open(DATA,">$_[0]"))
			{
				print DATA $_[2];
				close(DATA);
				utime(1,1,$_[0]);
				push(@log,$_[1].'를 작성했습니다');
			}
			else
				{push(@log,$_[1].'작성에 실패했습니다',$checkdatadir);}
		}
	}
	push(@log,'초기화/수복의 필요는 없었습니다.') if !scalar(@log);
}

sub delunit
{
	CheckLock();
	delete_dir($DATA_DIR);
	push(@log,'삭제해야 할 데이터가 없었습니다.') if !scalar(@log);
}

sub piece
{
	CheckLock();
	delete_evt();
	delete_dir($LOG_DIR,1);
	delete_dir($ITEM_DIR,1);
	delete_dir($SESSION_DIR,1);
	delete_dir($TEMP_DIR,1);
	delete_dir($SUBDATA_DIR,1);
	push(@log,'삭제해야 할 데이터가 없었습니다.') if !scalar(@log);
}

sub mini
{
	CheckLock();
	delete_evt();
	delete_dir($ITEM_DIR,1);
	push(@log,'삭제해야 할 데이터가 없었습니다.') if !scalar(@log);
}

sub timeedit
{
	CheckLock();
	$Q{tlyear}-=1900 if $Q{tlyear}>=2000;
	$time=0;
	$time=GetTimeLocal($Q{tlsec},$Q{tlmin},$Q{tlhour},$Q{tlday},$Q{tlmon}-1,$Q{tlyear});
	if(!$time) { push(@log,'일자 시각 설정이 부정합니다');}
	elsif(open(IN,"$DATA_DIR/$DATA_FILE$FILE_EXT"))
	{
		my @data=<IN>;
		close(IN);
		$data[0]=$time."\n";
		open(OUT,">$DATA_DIR/$DATA_FILE$FILE_EXT");
		print OUT @data;
		close(OUT);
		my($s,$min,$h,$d,$m,$y) =gmtime($time+$TZ_JST);
		my $timestr=sprintf("%04d-%02d-%02d %02d:%02d:%02d",$y+1900,$m+1,$d,$h,$min,$s);
		push(@log,'최종 갱신 시각을['.$timestr.']로 설정했습니다');
	}
	else
	{
		push(@log,'데이터 파일을 변경 할 수 없었습니다');
	}
}

sub backup
{
	CheckLock();
	#백업을 현역에게 복원
	my @files=map{"$_$FILE_EXT"}@BACKUP_FILES;
	my @errorfiles=grep(!-e $_,map{"$Q{backup}/$_"}@files);
	
	if(scalar(@errorfiles))
	{
		push(@log,map{$_.'가 존재하지 않았습니다'}@errorfiles);
		push(@log,'백업 데이터가 불완전해서 처리를 중지했습니다');
	}
	else
	{
		my $time=(stat("$Q{backup}/$DATA_FILE$FILE_EXT"))[9];
		my($s,$min,$h,$d,$m,$y) =gmtime($time+$TZ_JST);
		my $timestr=sprintf("%04d-%02d-%02d %02d:%02d",$y+1900,$m+1,$d,$h,$min);
		
		foreach my $file (@files)
		{
			my $inok=open(IN,"$Q{backup}/$file");
			my $outok=open(OUT,">$DATA_DIR/$file");
			if($inok && $outok)
			{
				my @data=<IN>;
				close(IN);
				if($file eq $DATA_FILE.$FILE_EXT)
				{
					#play.cgi의 경우는 갱신 시각을 현재에
					$data[0]=time()."\n";
					push(@log,'최종 갱신 시각을 현재로 설정했습니다');
				}
				if($file eq $LOG_FILE."-s0".$FILE_EXT || $file eq $PERIOD_FILE.$FILE_EXT)
				{
					#period.cgi와 log-s0.cgi의 경우는 백업 복원 아나운스를 부가
					unshift(@data,time().",1,0,0,백업 데이터 복원을 위해[$timestr]시점으로 돌아갔습니다 \n");
				}
				print OUT @data;
				close(OUT);
				push(@log,$file.'의 복원에 성공했습니다');
			}
			else
			{
				close(IN) if $inok;
				push(@log,$file.'의 복원에 실패했습니다','재차 처리를 실시해 주세요');
			}
		}
	}
}

sub CheckLock
{
	return if -e "./lock" or -e "$DATA_DIR/lock";
	if(mkdir("$DATA_DIR/lock",$DIR_PERMISSION))
		{
		return;
		}
		else
		{
		OutError('이 조작은 점검 모드로 밖에 실시할 수 없습니다','noerror');
		}
}

sub GetTimeLocal {
    my($Sec,$Min,$Hour,$Date,$Mon,$Year) = @_;
    my($sec,$min,$hour,$date,$mon,$year,$day,$yday,$isdst);

    my($cnt) = 0;
    my($Now) = time;
    while($cnt < 20) {
        ($sec,$min,$hour,$date,$mon,$year,$day,$yday,$isdst) = gmtime($Now+$TZ_JST);
        if ($year != $Year) {
            $Now -= ($year - $Year) * 31536000;
        } elsif ($mon != $Mon) {
            $Now -= ($mon - $Mon) * 2592000;
        } elsif ($date != $Date) {
            $Now -= ($date - $Date) * 86400;
        } elsif ($hour != $Hour) {
            $Now -= ($hour - $Hour) * 3600;
        } elsif ($min != $Min) {
            $Now -= ($min - $Min) * 60;
        } elsif ($sec != $Sec) {
            $Now -= ($sec - $Sec);
        } else {
            last;
        }
        $cnt++;
    }
    $Now = 0 if $cnt == 20;

    return $Now;
}

sub delete_evt
{
	if(open(IN,"$DATA_DIR/$DATA_FILE$FILE_EXT"))
	{
	my @data=<IN>;
	close(IN);
	$data[3]="\n";
	open(OUT,">$DATA_DIR/$DATA_FILE$FILE_EXT");
	print OUT @data;
	close(OUT);
	push(@log,$DATA_FILE.$FILE_EXT.' 안의 이벤트 데이터를 삭제했습니다');
	}
	else
	{
	push(@log,' '.$DATA_FILE.$FILE_EXT.' 안이벤트 데이터 삭제에 실패했습니다');
	}
}

sub delete_dir
{
	my($dir,$owndelete)=@_;
	
	return if !-d $dir;
	
	opendir(DIR,$dir);
	my @filelist=grep(!/^\.\.?$/,readdir(DIR));
	closedir(DIR);
	foreach my $file (@filelist)
	{
		$file="$dir/$file";
		if(-f $file)
		{
			if(unlink($file))
				{push(@log,$file.'를 삭제했습니다');}
			else
				{push(@log,' '.$file.'의 삭제에 실패했습니다');}
		}
		delete_dir($file,1) if -d $file;
	}
	if($owndelete)
	{
		if(rmdir($dir))
			{push(@log,'디렉토리 '.$dir.'를 삭제했습니다');}
		else
			{push(@log,'디렉토리'.$dir.'의 삭제에 실패했습니다');}
	}
}

sub MakeTownFile
{
my $townfile="$COMMON_DIR/towndata$FILE_EXT";
require $townfile if -e $townfile;

return if ($Tname{$MYDIR} eq $TOWN_TITLE);

	if(open(OUT,">".$townfile))
		{
		$Tname{$MYDIR}=$TOWN_TITLE;
		undef @OtherDir;
		@OtherDir=keys(%Tname);
		print OUT '@OtherDir=("',join('","',@OtherDir),'");',"\n";
		foreach(keys(%Tname))
			{
			print OUT '$Tname{',$_,'}="',$Tname{$_},'";',"\n";
			}
			close(OUT);
			push(@log,'거리 리스트를 작성했습니다');
		}
		else
		{
			push(@log,'거리 리스트의 작성에 실패했습니다'.$townfile);
		}
}
1;
