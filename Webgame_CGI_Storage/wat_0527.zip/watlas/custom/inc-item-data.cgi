# 월드 아틀라스판 아이템 데이터 2005/01/20 유래

# 이 파일은 아이템 데이터의 정의 파일입니다.
# 좋아하는 대로 사용자 지정 할 수 있습니다.자세한 것은 매뉴얼을 봐 주세요.

@@DEFINE
	version	05-01-20(WA)		#★상품 데이터 버전 표기
					# 마지막 「WA」는 월드 아틀라스판인 것을 나타냅니다.
					# 만약 당신이 독자 아이템을 눈으로 한 상인 이야기를 만든다면,
					# 이 기호를 바꾸는 것이 좋을 것입니다.

	scale	개			#★기본의 셈단위
	type0	전			#전아이템의 집합
	type1	소재
	type2	식품
	type3	조미료
	type4	직물
	type5	공예
	type6	선박
	type7	선단
	type8	항해
	type9	도구
	
	job	shipb		조선가게		#★직업 코드는 영소문자 10 문자 이내
	job	pirate		해적
	job	pros		해군사령
	job	explore		탐험가
	job	trader		무역상

	MaxMoney	999999999	#★최대 자금
	
	set NewShopMoney	200000					#초기 자금 (@@FUNCNEW에서 사용)
	set NewShopTime		14*60*60				#초기 제한 시간(초) (@@FUNCNEW에서 사용)
	set NewShopItem		진열장&nbsp;증축취괴킷:1:상품권:10	#초기 소지 상품 (@@FUNCNEW에서 사용) 서식 상품명:개수:상품명:개수:...
	
	TimeEditShowcase	10m		#★진열장 조작 시간
	TimeShopping		20m		#★구입 시간( 구SOLD OUT와의 호환성 확보.지금은 사용하지 않고)
	TimeSendItem		20m		#★아이템 구입/이동 시간(기본)
	TimeSendItemPlus	20s		#★아이템 구입/이동 시간(1개 근처의 추가 시간)
	TimeSendMoney		20m		#★자금 이동 시간(기본)
	TimeSendMoneyPlus	100000		#★쓰레기 처리 시간 계산 공금액(이 금액에 대해 TimeSendMoney 시간을 소비)
	
	CostShowcase1		0		#★진열장 1개시 유지비
	CostShowcase2		2000	#진열장 2개시 유지비
	CostShowcase3		4000	#진열장 3개시 유지비
	CostShowcase4		8000	#진열장 4개시 유지비
	CostShowcase5		16000	#진열장 5개시 유지비
	CostShowcase6		32000	#진열장 6개시 유지비
	CostShowcase7		64000	#진열장 7개시 유지비
	CostShowcase8		128000	#진열장 8개시 유지비
	
	ItemUseTimeRate		0.5		#★아이템 사용시 시간 계산 보정 배율(@USE내 time,exptime에 유효)
	

#------ 여기로부터 아이템 정의 ---------------------------------


@@ITEM
	no		18
	type	항해
	code	bread
	name	빵
	info	항해의 필수품
	price	100
	limit	1000/1000
	pop	20m
	plus	20m
	base	100/100000
	scale	식
	cost	20
	point	5%
@@ITEM
	no		19
	type	항해
	code	lamb
	name	럼주
	info	항해의 필수품
	price	200
	limit	500/500
	pop	40m
	plus	20m
	base	100/50000
	scale	병
	cost	20
	point	10%

@@ITEM
	no		20
	type	항해
	code	seaman
	name	선원
	info	배를 작동시키는 일손
	price	1200
	limit	800/800
	pop	1d
	plus	20m
	base	10000/100000
	scale	인
	flag	noshowcase|human|norequest

@@ITEM
	no		1
	type	도구
	code	book-bd
	name	조선법
	info	조선의 방법을 해설한 무예지도서
	price	10000
	limit	1/0.1
	pop	1d
	plus	2h
	scale	권
	flag	noshowcase
	@@use
		time	120m
		exp		2%
		exptime	40m
		job		조선가게	times/1.5
		scale	회
		action	제조한다
		name	바르카를 제조한다
		info	바르카를 제조합니다
		okmsg	바르카를 제조했습니다
			use		1	목재
			use		1	범포
			get		1	바르카
	@@use
		time	3h
		exp		2%
		exptime	1h
		scale	회
		action	제조한다
		name	콕크를 제조한다
		info	콕크를 제조합니다
		okmsg	콕크를 제조했습니다
		ngmsg	제조에 실패했습니다…
			needjob	조선가게
			needexp	10%
			use		1	목재
			use		1	범포
			get		1	콕크	90%
	@@use
		time	6h
		exp		4%
		exptime	2h
		scale	회
		action	제조한다
		name	갤리를 제조한다
		info	갤리를 제조합니다
		okmsg	갤리를 제조했습니다
		ngmsg	제조에 실패했습니다…
			needjob	조선가게
			needexp	30%
			use		3	목재
			use		1	범포
			get		1	갤리	90%
	@@use
		time	12h
		exp		4%
		exptime	4h
		scale	회
		action	제조한다
		name	캐러벨을 제조한다
		info	캐러벨을 제조합니다
		okmsg	캐러벨을 제조했습니다
		ngmsg	제조에 실패했습니다…
			needjob	조선가게
			needexp	30%
			use		5	목재
			use		3	범포
			get		1	캐러벨	90%
	@@use
		time	24h
		exp		8%
		exptime	8h
		scale	회
		action	제조한다
		name	카락를 제조한다
		info	카락를 제조합니다
		okmsg	카락를 제조했습니다
		ngmsg	제조에 실패했습니다…
			needjob	조선가게
			needexp	50%
			use		10	목재
			use		6	범포
			get		1	카락	90%
	@@use
		time	24h
		exp		8%
		exptime	8h
		scale	회
		action	제조한다
		name	갈레온을 제조한다
		info	갈레온을 제조합니다
		okmsg	갈레온을 제조했습니다
		ngmsg	제조에 실패했습니다…
			needjob	조선가게
			needexp	50%
			use		10	목재
			use		6	범포
			get		1	갈레온	90%
	@@use
		time	36h
		exp		10%
		exptime	12h
		scale	회
		action	제조한다
		name	갤리어스를 제조한다
		info	갤리어스를 제조합니다
		okmsg	갤리어스를 제조했습니다
		ngmsg	제조에 실패했습니다…
			needjob	조선가게
			needexp	60%
			use		18	목재
			use		7	범포
			get		1	갤리어스	90%

@@ITEM
	no		26
	type	선단
	code	convoy-aa
	name	제1탐험선단
	info	탐험전용 선단
	price	0
	limit	1
	plus	-10m
	pop	0
	scale	부대
	flag	noshowcase|notrash|norequest
	@@use
		time	16h
		exp		10%
		scale	회
		action	파견한다
		name	유럽탐험에 파견한다
		info	유럽해역에 맞는 사람
		param	26,1
		funcb	beforeexp
		func	exploring
		arg	nocount
	@@use
		time	16h
		exp		10%
		scale	회
		action	파견한다
		name	아프리카탐험에 파견한다
		info	아프리카해역에 맞는 사람
		param	26,2
		funcb	beforeexp
		func	exploring
		arg	nocount
	@@use
		time	16h
		exp		10%
		scale	회
		action	파견한다
		name	중동탐험에 파견한다
		info	중동해역에 맞는 사람
		param	26,3
		funcb	beforeexp
		func	exploring
		arg	nocount
	@@use
		time	16h
		exp		10%
		scale	회
		action	파견한다
		name	인도탐험에 파견한다
		info	인도해역에 맞는 사람
		param	26,4
		funcb	beforeexp
		func	exploring
		arg	nocount
	@@use
		time	16h
		exp		10%
		scale	회
		action	파견한다
		name	아시아탐험에 파견한다
		info	아시아해역에 맞는 사람
		param	26,5
		funcb	beforeexp
		func	exploring
		arg	nocount
	@@use
		time	16h
		exp		10%
		scale	회
		action	파견한다
		name	신대륙탐험에 파견한다
		info	신대륙해역에 맞는 사람
		param	26,6
		funcb	beforeexp
		func	exploring
		arg	nocount
	@@use
		time	20m
		exp		0
		scale	회
		action	마중나간다
		name	탐험 선단을 마중나간다
		info	선단이 돌아오고 있는지 항구를 확인합니다
		param	26
		funcb	onlyexp
		func	meetexp
		arg	nocount
@@ITEM
	no		27
	type	선단
	code	convoy-ab
	name	제2탐험선단
	info	탐험전용 선단
	price	0
	limit	1
	plus	-10m
	pop	0
	scale	부대
	flag	noshowcase|notrash|norequest
	@@use
		time	16h
		exp		10%
		scale	회
		action	파견한다
		name	유럽탐험에 파견한다
		info	유럽해역에 맞는 사람
		param	27,1
		funcb	beforeexp
		func	exploring
		arg	nocount
	@@use
		time	16h
		exp		10%
		scale	회
		action	파견한다
		name	아프리카탐험에 파견한다
		info	아프리카해역에 맞는 사람
		param	27,2
		funcb	beforeexp
		func	exploring
		arg	nocount
	@@use
		time	16h
		exp		10%
		scale	회
		action	파견한다
		name	중동탐험에 파견한다
		info	중동해역에 맞는 사람
		param	27,3
		funcb	beforeexp
		func	exploring
		arg	nocount
	@@use
		time	16h
		exp		10%
		scale	회
		action	파견한다
		name	인도탐험에 파견한다
		info	인도해역에 맞는 사람
		param	27,4
		funcb	beforeexp
		func	exploring
		arg	nocount
	@@use
		time	16h
		exp		10%
		scale	회
		action	파견한다
		name	아시아탐험에 파견한다
		info	아시아해역에 맞는 사람
		param	27,5
		funcb	beforeexp
		func	exploring
		arg	nocount
	@@use
		time	16h
		exp		10%
		scale	회
		action	파견한다
		name	신대륙탐험에 파견한다
		info	신대륙해역에 맞는 사람
		param	27,6
		funcb	beforeexp
		func	exploring
		arg	nocount
	@@use
		time	20m
		exp		0
		scale	회
		action	마중나간다
		name	탐험 선단을 마중나간다
		info	선단이 돌아오고 있는 지 항구를 확인합니다
		param	27
		funcb	onlyexp
		func	meetexp
		arg	nocount
@@ITEM
	no		28
	type	선단
	code	convoy-ac
	name	제3탐험선단
	info	탐험전용 선단
	price	0
	limit	1
	plus	-10m
	pop	0
	scale	부대
	flag	noshowcase|notrash|norequest
	@@use
		time	16h
		exp		10%
		scale	회
		action	파견한다
		name	유럽탐험에 파견한다
		info	유럽해역에 맞는 사람
		param	28,1
		funcb	beforeexp
		func	exploring
		arg	nocount
	@@use
		time	16h
		exp		10%
		scale	회
		action	파견한다
		name	아프리카탐험에 파견한다
		info	아프리카해역에 맞는 사람
		param	28,2
		funcb	beforeexp
		func	exploring
		arg	nocount
	@@use
		time	16h
		exp		10%
		scale	회
		action	파견한다
		name	중동탐험에 파견한다
		info	중동해역에 맞는 사람
		param	28,3
		funcb	beforeexp
		func	exploring
		arg	nocount
	@@use
		time	16h
		exp		10%
		scale	회
		action	파견한다
		name	인도탐험에 파견한다
		info	인도해역에 맞는 사람
		param	28,4
		funcb	beforeexp
		func	exploring
		arg	nocount
	@@use
		time	16h
		exp		10%
		scale	회
		action	파견한다
		name	아시아탐험에 파견한다
		info	아시아해역에 맞는 사람
		param	28,5
		funcb	beforeexp
		func	exploring
		arg	nocount
	@@use
		time	16h
		exp		10%
		scale	회
		action	파견한다
		name	신대륙탐험에 파견한다
		info	신대륙해역에 맞는 사람
		param	28,6
		funcb	beforeexp
		func	exploring
		arg	nocount
	@@use
		time	20m
		exp		0
		scale	회
		action	마중나간다
		name	탐험 선단을 마중나간다
		info	선단이 돌아오고 있는 지 항구를 확인합니다
		param	28
		funcb	onlyexp
		func	meetexp
		arg	nocount
@@ITEM
	no		29
	type	선단
	code	convoy-ad
	name	제4탐험선단
	info	탐험전용 선단
	price	0
	limit	1
	plus	-10m
	pop	0
	scale	부대
	flag	noshowcase|notrash|norequest
	@@use
		time	16h
		exp		10%
		scale	회
		action	파견한다
		name	유럽탐험에 파견한다
		info	유럽해역에 맞는 사람
		param	29,1
		funcb	beforeexp
		func	exploring
		arg	nocount
	@@use
		time	16h
		exp		10%
		scale	회
		action	파견한다
		name	아프리카탐험에 파견한다
		info	아프리카해역에 맞는 사람
		param	29,2
		funcb	beforeexp
		func	exploring
		arg	nocount
	@@use
		time	16h
		exp		10%
		scale	회
		action	파견한다
		name	중동탐험에 파견한다
		info	중동해역에 맞는 사람
		param	29,3
		funcb	beforeexp
		func	exploring
		arg	nocount
	@@use
		time	16h
		exp		10%
		scale	회
		action	파견한다
		name	인도탐험에 파견한다
		info	인도해역에 맞는 사람
		param	29,4
		funcb	beforeexp
		func	exploring
		arg	nocount
	@@use
		time	16h
		exp		10%
		scale	회
		action	파견한다
		name	아시아탐험에 파견한다
		info	아시아해역에 맞는 사람
		param	29,5
		funcb	beforeexp
		func	exploring
		arg	nocount
	@@use
		time	16h
		exp		10%
		scale	회
		action	파견한다
		name	신대륙탐험에 파견한다
		info	신대륙해역에 맞는 사람
		param	29,6
		funcb	beforeexp
		func	exploring
		arg	nocount
	@@use
		time	20m
		exp		0
		scale	회
		action	마중나간다
		name	탐험 선단을 마중나간다
		info	선단이 돌아오고 있는 지 항구를 확인합니다
		param	29
		funcb	onlyexp
		func	meetexp
		arg	nocount

@@ITEM
	no		30
	type	선단
	code	convoy-ba
	name	제1무역선단
	info	무역전용 선단
	price	0
	limit	1
	plus	-10m
	pop	0
	scale	부대
	flag	noshowcase|notrash|norequest
	@@use
		time	12h
		exp		10%
		scale	회
		action	에 파견한다
		name	유럽무역에 파견한다
		info	유럽해역에 맞는 사람
		param	30,1
		funcb	routesel
		func	route
		arg	nocount|select
	@@use
		time	12h
		exp		10%
		scale	회
		action	에 파견한다
		name	아프리카무역에 파견한다
		info	아프리카해역에 맞는 사람
		param	30,2
		funcb	routesel
		func	route
		arg	nocount|select
	@@use
		time	12h
		exp		10%
		scale	회
		action	에 파견한다
		name	중동무역에 파견한다
		info	중동해역에 맞는 사람
		param	30,3
		funcb	routesel
		func	route
		arg	nocount|select
	@@use
		time	12h
		exp		10%
		scale	회
		action	에 파견한다
		name	인도무역에 파견한다
		info	인도해역에 맞는 사람
		param	30,4
		funcb	routesel
		func	route
		arg	nocount|select
	@@use
		time	12h
		exp		10%
		scale	회
		action	에 파견한다
		name	아시아무역에 파견한다
		info	아시아해역에 맞는 사람
		param	30,5
		funcb	routesel
		func	route
		arg	nocount|select
	@@use
		time	12h
		exp		10%
		scale	회
		action	에 파견한다
		name	신대륙무역에 파견한다
		info	신대륙해역에 맞는 사람
		param	30,6
		funcb	routesel
		func	route
		arg	nocount|select
	@@use
		time	20m
		exp		0
		scale	회
		action	마중나간다
		name	무역 선단을 마중나간다
		info	선단이 돌아오고 있는 지 항구를 확인합니다
		param	30
		funcb	onlyexp
		func	meetrtp
		arg	nocount
@@ITEM
	no		31
	type	선단
	code	convoy-bb
	name	제2무역선단
	info	무역전용 선단
	price	0
	limit	1
	plus	-10m
	pop	0
	scale	부대
	flag	noshowcase|notrash|norequest
	@@use
		time	12h
		exp		10%
		scale	회
		action	에 파견한다
		name	유럽무역에 파견한다
		info	유럽해역에 맞는 사람
		param	31,1
		funcb	routesel
		func	route
		arg	nocount|select
	@@use
		time	12h
		exp		10%
		scale	회
		action	에 파견한다
		name	아프리카무역에 파견한다
		info	아프리카해역에 맞는 사람
		param	31,2
		funcb	routesel
		func	route
		arg	nocount|select
	@@use
		time	12h
		exp		10%
		scale	회
		action	에 파견한다
		name	중동무역에 파견한다
		info	중동해역에 맞는 사람
		param	31,3
		funcb	routesel
		func	route
		arg	nocount|select
	@@use
		time	12h
		exp		10%
		scale	회
		action	에 파견한다
		name	인도무역에 파견한다
		info	인도해역에 맞는 사람
		param	31,4
		funcb	routesel
		func	route
		arg	nocount|select
	@@use
		time	12h
		exp		10%
		scale	회
		action	에 파견한다
		name	아시아무역에 파견한다
		info	아시아해역에 맞는 사람
		param	31,5
		funcb	routesel
		func	route
		arg	nocount|select
	@@use
		time	12h
		exp		10%
		scale	회
		action	에 파견한다
		name	신대륙무역에 파견한다
		info	신대륙해역에 맞는 사람
		param	31,6
		funcb	routesel
		func	route
		arg	nocount|select
	@@use
		time	20m
		exp		0
		scale	회
		action	마중나간다
		name	무역 선단을 마중나간다
		info	선단이 돌아오고 있는 지 항구를 확인합니다
		param	31
		funcb	onlyexp
		func	meetrtp
		arg	nocount
@@ITEM
	no		32
	type	선단
	code	convoy-bc
	name	제3무역선단
	info	무역전용 선단
	price	0
	limit	1
	plus	-10m
	pop	0
	scale	부대
	flag	noshowcase|notrash|norequest
	@@use
		time	12h
		exp		10%
		scale	회
		action	에 파견한다
		name	유럽무역에 파견한다
		info	유럽해역에 맞는 사람
		param	32,1
		funcb	routesel
		func	route
		arg	nocount|select
	@@use
		time	12h
		exp		10%
		scale	회
		action	에 파견한다
		name	아프리카무역에 파견한다
		info	아프리카해역에 맞는 사람
		param	32,2
		funcb	routesel
		func	route
		arg	nocount|select
	@@use
		time	12h
		exp		10%
		scale	회
		action	에 파견한다
		name	중동무역에 파견한다
		info	중동해역에 맞는 사람
		param	32,3
		funcb	routesel
		func	route
		arg	nocount|select
	@@use
		time	12h
		exp		10%
		scale	회
		action	에 파견한다
		name	인도무역에 파견한다
		info	인도해역에 맞는 사람
		param	32,4
		funcb	routesel
		func	route
		arg	nocount|select
	@@use
		time	12h
		exp		10%
		scale	회
		action	에 파견한다
		name	아시아무역에 파견한다
		info	아시아해역에 맞는 사람
		param	32,5
		funcb	routesel
		func	route
		arg	nocount|select
	@@use
		time	12h
		exp		10%
		scale	회
		action	에 파견한다
		name	신대륙무역에 파견한다
		info	신대륙해역에 맞는 사람
		param	32,6
		funcb	routesel
		func	route
		arg	nocount|select
	@@use
		time	20m
		exp		0
		scale	회
		action	마중나간다
		name	무역 선단을 마중나간다
		info	선단이 돌아오고 있는 지 항구를 확인합니다
		param	32
		funcb	onlyexp
		func	meetrtp
		arg	nocount
@@ITEM
	no		33
	type	선단
	code	convoy-bd
	name	제4무역선단
	info	무역전용 선단
	price	0
	limit	1
	plus	-10m
	pop	0
	scale	부대
	flag	noshowcase|notrash|norequest
	@@use
		time	12h
		exp		10%
		scale	회
		action	에 파견한다
		name	유럽무역에 파견한다
		info	유럽해역에 맞는 사람
		param	33,1
		funcb	routesel
		func	route
		arg	nocount|select
	@@use
		time	12h
		exp		10%
		scale	회
		action	에 파견한다
		name	아프리카무역에 파견한다
		info	아프리카해역에 맞는 사람
		param	33,2
		funcb	routesel
		func	route
		arg	nocount|select
	@@use
		time	12h
		exp		10%
		scale	회
		action	에 파견한다
		name	중동무역에 파견한다
		info	중동해역에 맞는 사람
		param	33,3
		funcb	routesel
		func	route
		arg	nocount|select
	@@use
		time	12h
		exp		10%
		scale	회
		action	에 파견한다
		name	인도무역에 파견한다
		info	인도해역에 맞는 사람
		param	33,4
		funcb	routesel
		func	route
		arg	nocount|select
	@@use
		time	12h
		exp		10%
		scale	회
		action	에 파견한다
		name	아시아무역에 파견한다
		info	아시아해역에 맞는 사람
		param	33,5
		funcb	routesel
		func	route
		arg	nocount|select
	@@use
		time	12h
		exp		10%
		scale	회
		action	에 파견한다
		name	신대륙무역에 파견한다
		info	신대륙해역에 맞는 사람
		param	33,6
		funcb	routesel
		func	route
		arg	nocount|select
	@@use
		time	20m
		exp		0
		scale	회
		action	마중나간다
		name	무역 선단을 마중나간다
		info	선단이 돌아오고 있는 지 항구를 확인합니다
		param	33
		funcb	onlyexp
		func	meetrtp
		arg	nocount

@@ITEM
	no		34
	type	선단
	code	convoy-ca
	name	제1무장함대
	info	전투전용 함대
	price	0
	limit	1
	plus	-10m
	pop	0
	scale	부대
	flag	noshowcase|notrash|norequest
	@@use
		time	16h
		exp		10%
		scale	회
		action	파견한다
		name	유럽에
		info	유럽해역에 맞는 사람
		param	34,1
		funcb	nowpp
		func	attack
		arg	nocount
	@@use
		time	16h
		exp		10%
		scale	회
		action	파견한다
		name	아프리카에
		info	아프리카해역에 맞는 사람
		param	34,2
		funcb	nowpp
		func	attack
		arg	nocount
	@@use
		time	16h
		exp		10%
		scale	회
		action	파견한다
		name	중동에
		info	중동해역에 맞는 사람
		param	34,3
		funcb	nowpp
		func	attack
		arg	nocount
	@@use
		time	16h
		exp		10%
		scale	회
		action	파견한다
		name	인도에
		info	인트해역에 맞는 사람
		param	34,4
		funcb	nowpp
		func	attack
		arg	nocount
	@@use
		time	16h
		exp		10%
		scale	회
		action	파견한다
		name	아시아에
		info	아시아해역에 맞는 사람
		param	34,5
		funcb	nowpp
		func	attack
		arg	nocount
	@@use
		time	16h
		exp		10%
		scale	회
		action	파견한다
		name	신대륙에
		info	신대륙해역에 맞는 사람
		param	34,6
		funcb	nowpp
		func	attack
		arg	nocount
	@@use
		time	20m
		exp		0
		scale	회
		action	마중나간다
		name	무장 함대를 마중나간다
		info	함대가 돌아오고 있는 지 항구를 확인합니다
		param	34
		funcb	onlyexp
		func	meetpp
		arg	nocount
@@ITEM
	no		35
	type	선단
	code	convoy-cb
	name	제2무장함대
	info	전투전용 함대
	price	0
	limit	1
	plus	-10m
	pop	0
	scale	부대
	flag	noshowcase|notrash|norequest
	@@use
		time	16h
		exp		10%
		scale	회
		action	파견한다
		name	유럽에
		info	유럽해역에 맞는 사람
		param	35,1
		funcb	nowpp
		func	attack
		arg	nocount
	@@use
		time	16h
		exp		10%
		scale	회
		action	파견한다
		name	아프리카에
		info	아프리카해역에 맞는 사람
		param	35,2
		funcb	nowpp
		func	attack
		arg	nocount
	@@use
		time	16h
		exp		10%
		scale	회
		action	파견한다
		name	중동에
		info	중동해역에 맞는 사람
		param	35,3
		funcb	nowpp
		func	attack
		arg	nocount
	@@use
		time	16h
		exp		10%
		scale	회
		action	파견한다
		name	인도에
		info	인트해역에 맞는 사람
		param	35,4
		funcb	nowpp
		func	attack
		arg	nocount
	@@use
		time	16h
		exp		10%
		scale	회
		action	파견한다
		name	아시아에
		info	아시아해역에 맞는 사람
		param	35,5
		funcb	nowpp
		func	attack
		arg	nocount
	@@use
		time	16h
		exp		10%
		scale	회
		action	파견한다
		name	신대륙에
		info	신대륙해역에 맞는 사람
		param	35,6
		funcb	nowpp
		func	attack
		arg	nocount
	@@use
		time	20m
		exp		0
		scale	회
		action	마중나간다
		name	무장 함대를 마중나간다
		info	함대가 돌아오고 있는 지 항구를 확인합니다
		param	35
		funcb	onlyexp
		func	meetpp
		arg	nocount
@@ITEM
	no		36
	type	선단
	code	convoy-cc
	name	제3무장함대
	info	전투전용 함대
	price	0
	limit	1
	plus	-10m
	pop	0
	scale	부대
	flag	noshowcase|notrash|norequest
	@@use
		time	16h
		exp		10%
		scale	회
		action	파견한다
		name	유럽에
		info	유럽해역에 맞는 사람
		param	36,1
		funcb	nowpp
		func	attack
		arg	nocount
	@@use
		time	16h
		exp		10%
		scale	회
		action	파견한다
		name	아프리카에
		info	아프리카해역에 맞는 사람
		param	36,2
		funcb	nowpp
		func	attack
		arg	nocount
	@@use
		time	16h
		exp		10%
		scale	회
		action	파견한다
		name	중동에
		info	중동해역에 맞는 사람
		param	36,3
		funcb	nowpp
		func	attack
		arg	nocount
	@@use
		time	16h
		exp		10%
		scale	회
		action	파견한다
		name	인도에
		info	인트해역에 맞는 사람
		param	36,4
		funcb	nowpp
		func	attack
		arg	nocount
	@@use
		time	16h
		exp		10%
		scale	회
		action	파견한다
		name	아시아에
		info	아시아해역에 맞는 사람
		param	36,5
		funcb	nowpp
		func	attack
		arg	nocount
	@@use
		time	16h
		exp		10%
		scale	회
		action	파견한다
		name	신대륙에
		info	신대륙해역에 맞는 사람
		param	36,6
		funcb	nowpp
		func	attack
		arg	nocount
	@@use
		time	20m
		exp		0
		scale	회
		action	마중나간다
		name	무장 함대를 마중나간다
		info	함대가 돌아오고 있는 지 항구를 확인합니다
		param	36
		funcb	onlyexp
		func	meetpp
		arg	nocount
@@ITEM
	no		37
	type	선단
	code	convoy-cd
	name	제4무장함대
	info	전투전용 함대
	price	0
	limit	1
	plus	-10m
	pop	0
	scale	부대
	flag	noshowcase|notrash|norequest
	@@use
		time	16h
		exp		10%
		scale	회
		action	파견한다
		name	유럽에
		info	유럽해역에 맞는 사람
		param	37,1
		funcb	nowpp
		func	attack
		arg	nocount
	@@use
		time	16h
		exp		10%
		scale	회
		action	파견한다
		name	아프리카에
		info	아프리카해역에 맞는 사람
		param	37,2
		funcb	nowpp
		func	attack
		arg	nocount
	@@use
		time	16h
		exp		10%
		scale	회
		action	파견한다
		name	중동에
		info	중동해역에 맞는 사람
		param	37,3
		funcb	nowpp
		func	attack
		arg	nocount
	@@use
		time	16h
		exp		10%
		scale	회
		action	파견한다
		name	인도에
		info	인트해역에 맞는 사람
		param	37,4
		funcb	nowpp
		func	attack
		arg	nocount
	@@use
		time	16h
		exp		10%
		scale	회
		action	파견한다
		name	아시아에
		info	아시아해역에 맞는 사람
		param	37,5
		funcb	nowpp
		func	attack
		arg	nocount
	@@use
		time	16h
		exp		10%
		scale	회
		action	파견한다
		name	신대륙에
		info	신대륙해역에 맞는 사람
		param	37,6
		funcb	nowpp
		func	attack
		arg	nocount
	@@use
		time	20m
		exp		0
		scale	회
		action	마중나간다
		name	무장 함대를 마중나간다
		info	함대가 돌아오고 있는 지 항구를 확인합니다
		param	37
		funcb	onlyexp
		func	meetpp
		arg	nocount

@@ITEM
	no		39
	type	항해
	code	discover-a
	name	발견보고서(유럽)
	info	탐험으로 발견한 귀한 것
	price	0
	limit	3
	plus	-1h
	pop	0
	scale	통
	flag	noshowcase|norequest
	@@use
		time	2h
		scale	회
		action	신고한다
		name	왕국에 신고한다
		info	발견물을 왕국에 신고합니다
		func	disc
		param	1
		arg	nocount
			use		1	발견보고서(유럽)
@@ITEM
	no		40
	type	항해
	code	discover-b
	name	발견보고서(아프리카)
	info	탐험으로 발견한 귀한 것
	price	0
	limit	3
	plus	-1h
	pop	0
	scale	통
	flag	noshowcase|norequest
	@@use
		time	2h
		scale	회
		action	신고한다
		name	왕국에 신고한다
		info	발견물을 왕국에 신고합니다
		func	disc
		param	2
		arg	nocount
			use		1	발견보고서(아프리카)
@@ITEM
	no		41
	type	항해
	code	discover-c
	name	발견보고서(중동)
	info	탐험으로 발견한 귀한 것
	price	0
	limit	3
	plus	-1h
	pop	0
	scale	통
	flag	noshowcase|norequest
	@@use
		time	2h
		scale	회
		action	신고한다
		name	왕국에 신고한다
		info	발견물을 왕국에 신고합니다
		func	disc
		param	3
		arg	nocount
			use		1	발견보고서(중동)
@@ITEM
	no		42
	type	항해
	code	discover-d
	name	발견보고서(인도)
	info	탐험으로 발견한 귀한 것
	price	0
	limit	3
	plus	-1h
	pop	0
	scale	통
	flag	noshowcase|norequest
	@@use
		time	2h
		scale	회
		action	신고한다
		name	왕국에 신고한다
		info	발견물을 왕국에 신고합니다
		func	disc
		param	4
		arg	nocount
			use		1	발견보고서(인도)
@@ITEM
	no		43
	type	항해
	code	discover-e
	name	발견보고서(아시아)
	info	탐험으로 발견한 귀한 것
	price	0
	limit	3
	plus	-1h
	pop	0
	scale	통
	flag	noshowcase|norequest
	@@use
		time	2h
		scale	회
		action	신고한다
		name	왕국에 신고한다
		info	발견물을 왕국에 신고합니다
		func	disc
		param	5
		arg	nocount
			use		1	발견보고서(아시아)
@@ITEM
	no		44
	type	항해
	code	discover-f
	name	발견보고서(신대륙)
	info	탐험으로 발견한 귀한 것
	price	0
	limit	3
	plus	-1h
	pop	0
	scale	통
	flag	noshowcase|norequest
	@@use
		time	2h
		scale	회
		action	신고한다
		name	왕국에 신고한다
		info	발견물을 왕국에 신고합니다
		func	disc
		param	6
		arg	nocount
			use		1	발견보고서(신대륙)

@@ITEM
	no		45
	type	항해
	code	town-a
	name	신도시의&nbsp;지도(유럽)
	info	탐험으로 발견한 무역 도시
	price	0
	limit	1
	plus	-1h
	pop	0
	scale	통
	flag	noshowcase|norequest
	@@USE
		time	2h
		arg	nocount|message18
		argmessage	도시의&nbsp;이름
		scale	회
		action	라고 이름 붙여 건설
		name	상관을 건설한다
		info	도시를 명명해 무역을 할 수 있도록 합니다
		param	1
		func	newtown
			use		1	신도시의&nbsp;지도(유럽)
@@ITEM
	no		46
	type	항해
	code	town-b
	name	신도시의&nbsp;지도(아프리카)
	info	탐험으로 발견한 무역 도시
	price	0
	limit	1
	plus	-1h
	pop	0
	scale	통
	flag	noshowcase|norequest
	@@USE
		time	2h
		arg	nocount|message18
		argmessage	도시의&nbsp;이름
		scale	회
		action	라고 이름 붙여 건설
		name	상관을 건설한다
		info	도시를 명명해 무역을 할 수 있도록 합니다
		param	2
		func	newtown
			use		1	신도시의&nbsp;지도(아프리카)
@@ITEM
	no		47
	type	항해
	code	town-c
	name	신도시의&nbsp;지도(중동)
	info	탐험으로 발견한 무역 도시
	price	0
	limit	1
	plus	-1h
	pop	0
	scale	통
	flag	noshowcase|norequest
	@@USE
		time	2h
		arg	nocount|message18
		argmessage	도시의&nbsp;이름
		scale	회
		action	라고 이름 붙여 건설
		name	상관을 건설한다
		info	도시를 명명해 무역을 할 수 있도록 합니다
		param	3
		func	newtown
			use		1	신도시의&nbsp;지도(중동)
@@ITEM
	no		48
	type	항해
	code	town-d
	name	신도시의&nbsp;지도(인도)
	info	탐험으로 발견한 무역 도시
	price	0
	limit	1
	plus	-1h
	pop	0
	scale	통
	flag	noshowcase|norequest
	@@USE
		time	2h
		arg	nocount|message18
		argmessage	도시의&nbsp;이름
		scale	회
		action	라고 이름 붙여 건설
		name	상관을 건설한다
		info	도시를 명명해 무역을 할 수 있도록 합니다
		param	4
		func	newtown
			use		1	신도시의&nbsp;지도(인도)
@@ITEM
	no		49
	type	항해
	code	town-e
	name	신도시의&nbsp;지도(아시아)
	info	탐험으로 발견한 무역 도시
	price	0
	limit	1
	plus	-1h
	pop	0
	scale	통
	flag	noshowcase|norequest
	@@USE
		time	2h
		arg	nocount|message18
		argmessage	도시의&nbsp;이름
		scale	회
		action	라고 이름 붙여 건설
		name	상관을 건설한다
		info	도시를 명명해 무역을 할 수 있도록 합니다
		param	5
		func	newtown
			use		1	신도시의&nbsp;지도(아시아)
@@ITEM
	no		50
	type	항해
	code	town-f
	name	신도시의&nbsp;지도(신대륙)
	info	탐험으로 발견한 무역 도시
	price	0
	limit	1
	plus	-1h
	pop	0
	scale	통
	flag	noshowcase|norequest
	@@USE
		time	2h
		arg	nocount|message18
		argmessage	도시의&nbsp;이름
		scale	회
		action	라고 이름 붙여 건설
		name	상관을 건설한다
		info	도시를 명명해 무역을 할 수 있도록 합니다
		param	6
		func	newtown
			use		1	신도시의&nbsp;지도(신대륙)

@@ITEM
	no		51
	type	공예
	code	coin
	name	금화
	info	왕국 발행의 금화. 판매해서 환금
	price	10000
	limit	500
	base	10/20
	plus	-1h
	pop	2h
	scale	닢
	point	75%
@@ITEM
	no		52
	type	식품
	code	wine
	name	와인
	info	유럽 특산의 식품
	price	10000
	limit	100
	base	10/20
	plus	-1h
	pop	16h
	scale	병
	point	300%
@@ITEM
	no		53
	type	식품
	code	cheese
	name	치즈
	info	유럽 특산의 식품
	price	2000
	limit	500
	base	10/20
	plus	-1h
	pop	3h
	scale	병
	point	60%
@@ITEM
	no		54
	type	조미료
	code	olive
	name	올리브유
	info	유럽 특산의 조미료
	price	1000
	limit	1000
	base	10/20
	plus	-1h
	pop	90m
	scale	병
	point	30%
@@ITEM
	no		55
	type	직물
	code	woolen
	name	모직물
	info	유럽 특산의 직물
	price	5000
	limit	200
	base	10/20
	plus	-1h
	pop	8h
	scale	상자
	point	150%
@@ITEM
	no		56
	type	공예
	code	stained
	name	스테인드&nbsp;글라스
	info	유럽 특산의 공예품
	price	8000
	limit	120
	base	10/20
	plus	-1h
	pop	12h
	scale	상자
	point	200%
@@ITEM
	no		57
	type	공예
	code	sculpture
	name	조각
	info	유럽 특산의 공예품
	price	4000
	limit	250
	base	10/20
	plus	-1h
	pop	6h
	scale	상자
	point	120%
@@ITEM
	no		58
	type	공예
	code	gun
	name	총
	info	유럽 특산의 공예품
	price	3000
	limit	300
	base	10/20
	plus	-1h
	pop	5h
	scale	상자
	point	80%

@@ITEM
	no		59
	type	소재
	code	gold
	name	금
	info	아프리카 특산의 소재
	price	5000
	limit	200
	base	10/20
	plus	-1h
	pop	10h
	scale	상자
	point	300%
@@ITEM
	no		60
	type	소재
	code	diamond
	name	다이아몬드
	info	아프리카 특산의 소재
	price	10000
	limit	100
	base	10/20
	plus	-1h
	pop	20h
	scale	상자
	point	600%
@@ITEM
	no		61
	type	소재
	code	coral
	name	산호
	info	아프리카 특산의 소재
	price	2500
	limit	400
	base	10/20
	plus	-1h
	pop	5h
	scale	상자
	point	140%
@@ITEM
	no		62
	type	소재
	code	ivory
	name	상아
	info	아프리카 특산의 소재
	price	1000
	limit	1000
	base	10/20
	plus	-1h
	pop	2h
	scale	상자
	point	50%
@@ITEM
	no		63
	type	식품
	code	coffee
	name	커피
	info	아프리카 특산의 식품
	price	500
	limit	2000
	base	10/20
	plus	-1h
	pop	1h
	scale	상자
	point	40%
@@ITEM
	no		64
	type	조미료
	code	salt
	name	소금
	info	아프리카 특산의 조미료
	price	400
	limit	2500
	base	10/20
	plus	-1h
	pop	40m
	scale	상자
	point	15%
@@ITEM
	no		65
	type	조미료
	code	tamarindo
	name	타마린드
	info	아프리카 특산의 조미료
	price	500
	limit	2000
	base	10/20
	plus	-1h
	pop	1h
	scale	상자
	point	30%

@@ITEM
	no		66
	type	소재
	code	ironore
	name	철광석
	info	중동 특산의 소재
	price	1000
	limit	1000
	base	10/20
	plus	-1h
	pop	2h
	scale	상자
	point	50%
@@ITEM
	no		67
	type	소재
	code	sulfur
	name	유황
	info	중동 특산의 소재
	price	1000
	limit	1000
	base	10/20
	plus	-1h
	pop	2h
	scale	상자
	point	50%
@@ITEM
	no		68
	type	식품
	code	honey
	name	벌꿀
	info	중동 특산의 식품
	price	500
	limit	2000
	base	10/20
	plus	-1h
	pop	1h
	scale	상자
	point	25%
@@ITEM
	no		69
	type	조미료
	code	sugar
	name	설탕
	info	중동 특산의 조미료
	price	500
	limit	2000
	base	10/20
	plus	-1h
	pop	1h
	scale	상자
	point	25%
@@ITEM
	no		70
	type	직물
	code	carpet
	name	융단
	info	중동 특산의 직물
	price	2500
	limit	400
	base	10/20
	plus	-1h
	pop	5h
	scale	상자
	point	180%
@@ITEM
	no		71
	type	직물
	code	hemptext
	name	마직물
	info	중동 특산의 직물
	price	2000
	limit	500
	base	10/20
	plus	-1h
	pop	4h
	scale	상자
	point	120%
@@ITEM
	no		72
	type	공예
	code	bicornis
	name	무소뿔
	info	중동 특산의 공예품
	price	2000
	limit	500
	base	10/20
	plus	-1h
	pop	4h
	scale	상자
	point	100%

@@ITEM
	no		73
	type	소재
	code	saltpeter
	name	초석
	info	인도 특산의 소재
	price	1000
	limit	1000
	base	10/20
	plus	-1h
	pop	2h
	scale	상자
	point	50%
@@ITEM
	no		74
	type	소재
	code	sapphire
	name	사파이어
	info	인도 특산의 소재
	price	5000
	limit	200
	base	10/20
	plus	-1h
	pop	10h
	scale	상자
	point	300%
@@ITEM
	no		75
	type	조미료
	code	pepper
	name	후추
	info	인도 특산의 조미료
	price	2500
	limit	400
	base	10/20
	plus	-1h
	pop	200m
	scale	상자
	point	150%
@@ITEM
	no		76
	type	조미료
	code	cinnamon
	name	신나몬
	info	인도 특산의 조미료
	price	500
	limit	2000
	base	10/20
	plus	-1h
	pop	1h
	scale	상자
	point	25%
@@ITEM
	no		77
	type	직물
	code	cottonfab
	name	면직물
	info	인도 특산의 직물
	price	1000
	limit	1000
	base	10/20
	plus	-1h
	pop	2h
	scale	상자
	point	50%
@@ITEM
	no		78
	type	직물
	code	printing
	name	경사
	info	인도 특산의 직물
	price	2000
	limit	500
	base	10/20
	plus	-1h
	pop	4h
	scale	상자
	point	100%
@@ITEM
	no		79
	type	공예
	code	tortoiseshell
	name	별갑
	info	인도 특산의 공예품
	price	2000
	limit	500
	base	10/20
	plus	-1h
	pop	4h
	scale	상자
	point	100%

@@ITEM
	no		80
	type	소재
	code	pearl
	name	진주
	info	아시아 특산의 소재
	price	5000
	limit	200
	base	10/20
	plus	-1h
	pop	10h
	scale	상자
	point	250%
@@ITEM
	no		81
	type	식품
	code	sake
	name	청주
	info	아시아 특산의 식품
	price	5000
	limit	200
	base	10/20
	plus	-1h
	pop	10h
	scale	병
	point	250%
@@ITEM
	no		82
	type	식품
	code	greentea
	name	차
	info	아시아 특산의 식품
	price	1000
	limit	1000
	base	10/20
	plus	-1h
	pop	2h
	scale	상자
	point	50%
@@ITEM
	no		83
	type	직물
	code	silkfab
	name	견직물
	info	아시아 특산의 직물
	price	10000
	limit	100
	base	10/20
	plus	-1h
	pop	20h
	scale	상자
	point	750%
@@ITEM
	no		84
	type	공예
	code	ukiyoe
	name	강호시대의&nbsp;풍속화
	info	아시아 특산의 공예품
	price	2000
	limit	500
	base	10/20
	plus	-1h
	pop	4h
	scale	상자
	point	120%
@@ITEM
	no		85
	type	공예
	code	lacquer
	name	칠기
	info	아시아 특산의 공예품
	price	4000
	limit	250
	base	10/20
	plus	-1h
	pop	8h
	scale	상자
	point	200%
@@ITEM
	no		86
	type	공예
	code	katana
	name	도
	info	아시아 특산의 공예품
	price	8000
	limit	120
	base	10/20
	plus	-1h
	pop	16h
	scale	상자
	point	400%

@@ITEM
	no		17
	type	소재
	code	silver
	name	은
	info	신대륙 특산의 소재
	price	4000
	limit	250
	base	10/20
	plus	-1h
	pop	8h
	scale	상자
	point	200%
@@ITEM
	no		12
	type	소재
	code	emerald
	name	에메랄드
	info	신대륙 특산의 소재
	price	10000
	limit	100
	base	10/20
	plus	-1h
	pop	20h
	scale	상자
	point	500%
@@ITEM
	no		13
	type	식품
	code	cacao
	name	카카오
	info	신대륙 특산의 식품
	price	500
	limit	2000
	base	10/20
	plus	-1h
	pop	1h
	scale	병
	point	25%
@@ITEM
	no		14
	type	식품
	code	corn
	name	옥수수
	info	신대륙 특산의 식품
	price	500
	limit	2000
	base	10/20
	plus	-1h
	pop	1h
	scale	병
	point	25%
@@ITEM
	no		38
	type	식품
	code	tamato
	name	토마토
	info	신대륙 특산의 식품
	price	500
	limit	2000
	base	10/20
	plus	-1h
	pop	1h
	scale	병
	point	25%
@@ITEM
	no		23
	type	식품
	code	tobacco
	name	담배
	info	신대륙 특산의 식품
	price	2000
	limit	500
	base	10/20
	plus	-1h
	pop	4h
	scale	상자
	point	150%
@@ITEM
	no		21
	type	식품
	code	pumpkin
	name	호박
	info	신대륙 특산의 식품
	price	500
	limit	2000
	base	10/20
	plus	-1h
	pop	1h
	scale	병
	point	25%

@@ITEM
	no		5
	type	선박
	code	ship-a
	name	바르카
	info	소규모 범선.
	price	20000
	limit	50
	base	5/10
	plus	-1h
	pop	32h
	scale	척
	point	2h
@@ITEM
	no		6
	type	선박
	code	ship-c
	name	콕크
	info	소규모 범선.
	price	40000
	limit	25
	base	5/10
	plus	-1h
	pop	72h
	scale	척
	point	4h
@@ITEM
	no		7
	type	선박
	code	ship-b
	name	갤리
	info	중규모 조선.
	price	60000
	limit	16
	base	5/10
	plus	-1h
	pop	108h
	scale	척
	point	6h
@@ITEM
	no		8
	type	선박
	code	ship-d
	name	캐러벨
	info	중규모 범선.
	price	80000
	limit	12
	base	5/10
	plus	-1h
	pop	150h
	scale	척
	point	8h
@@ITEM
	no		9
	type	선박
	code	ship-e
	name	카락
	info	대규모 범선.
	price	160000
	limit	10
	base	5/10
	plus	-1h
	pop	300h
	scale	척
	point	16h
@@ITEM
	no		10
	type	선박
	code	ship-f
	name	갈레온
	info	대규모 범선.
	price	320000
	limit	10
	base	5/10
	plus	-1h
	pop	600h
	scale	척
	point	50h
@@ITEM
	no		11
	type	선박
	code	ship-g
	name	갤리어스
	info	거대 조선.
	price	480000
	limit	10
	base	5/10
	plus	-1h
	pop	900h
	scale	척
	point	80h

@@ITEM
	no		15
	type	도구
	code	wood
	name	목재
	info	배의 재료
	price	5000
	limit	100/100
	pop	10d
	plus	10m
	base	100/10000
	scale	다발
	cost	100
@@ITEM
	no		16
	type	도구
	code	cloth
	name	범포
	info	마스트의 재료
	price	3000
	limit	100/100
	pop	10d
	plus	10m
	base	100/10000
	scale	장
	cost	100

@@ITEM
	no		2
	type	도구
	code	jobchange
	name	직업의&nbsp;비밀
	info	여러가지 직업이 되기 위한 책
	price	25000
	limit	1/1
	pop	0
	base	10/200
	scale	권
	plus	2h
	@@USE
		time	20m
		scale	회
		action	확인한다
		name	현재의 직업 부족 상황을 본다
		info	지금 부족한 직업을 한눈에 압니다
		arg	nocount
		func	jobwant
	@@USE
		time	6h
		action	직업 체인지
		scale	회
		arg		nocount
		name	조선가게가 된다
		info	조선가게로 직업 체인지 합니다
		param	1,26:27:28:29:30:31:32:33:34:35:36:37,0.2,shipb
		funcb	jobcheck
			need		1	조선법
			use		1	직업의&nbsp;비밀
		func	jobport
	@@USE
		time	6h
		action	직업 체인지
		scale	회
		arg		nocount
		name	무역상이 된다
		info	무역상으로 직업 체인지 합니다
		param	30,1:26:27:28:29:34:35:36:37,0.2,trader
		funcb	jobcheck
			use		1	직업의&nbsp;비밀
		func	jobport
	@@USE
		time	6h
		action	직업 체인지
		scale	회
		arg		nocount
		name	탐험가가 된다
		info	탐험가로 직업 체인지 합니다
		param	26,1:30:31:32:33:34:35:36:37,0.2,explore
		funcb	jobcheck
			use		1	직업의&nbsp;비밀
		func	jobport
	@@USE
		time	6h
		action	직업 체인지
		scale	회
		arg		nocount
		name	해적이 된다
		info	해적으로 직업 체인지 합니다
		param	34,1:26:27:28:29:30:31:32:33,0.2,pirate
		funcb	jobcheck
			use		1	직업의&nbsp;비밀
		func	jobport
	@@USE
		time	6h
		action	직업 체인지
		scale	회
		arg		nocount
		name	해군사령이 된다
		info	해군사령으로 직업 체인지 합니다
		param	34,1:26:27:28:29:30:31:32:33,0.2,pros
		funcb	jobcheck
			use		1	직업의&nbsp;비밀
		func	jobport

@@ITEM
	no		3
	type	도구
	code	cm
	name	광고&nbsp;팩
	info	인기를 거론합니다만 실패하는 일도…
	price	100000
	limit	1/0.1
	pop	10d
	plus	5d
	base	10/50
	scale	팩
	cost	10000
	@@use
		time	10h
		exp	10%
		scale	회
		action	광고 한다
		name	자점의 광고를 낸다
		info	자신의 가게의 인기를 거론합니다
		arg		nocount
			use		1	광고&nbsp;팩
		func	_local_
				my $up=int(500*(2-$DT->{rank}/5000));
				if ( rand(1000)<250 ) {
					$DT->{rank}-=$up;
					$DT->{rank}=1000 if $DT->{rank}<1000;
					my $ret="광고는 화근이 되어 버렸습니다：인기 ".int($up/100)."%다운";
					WriteLog(0,$DT->{id},$ret);
					WriteLog(3,0,$DT->{shopname}."가 광고를 냈습니다만 오히려 역효과였습니다.");
					return $ret;
				}
				$DT->{rank}+=$up;
				$DT->{rank}=10000 if $DT->{rank}>10000;
				my $ret="광고를 냈습니다：인기 ".int($up/100)."%업";
				WriteLog(0,$DT->{id},$ret);
				WriteLog(3,0,$DT->{shopname}."가 광고를 냈습니다.");
				return $ret;
			_local_
	@@use
		time	10h
		exp	0%
		name	다른 상점의 광고를 낸다
		info	다른 상점의 인기를 거론합니다
		arg		target|nocount
			use		1	광고&nbsp;팩
		func	_local_
				return '자점을 지정할 수 없습니다' if ($DT==$DTS);
				my $up=int(500*(2-$DTS->{rank}/5000));
				$DTS->{rank}+=$up;
				$DTS->{rank}=10000 if $DTS->{rank}>10000;
				my $ret="광고를 냈습니다：".$DTS->{shopname}."의 인기 ".int($up/100)."%업";
				WriteLog(0,$DT->{id},$ret);
				WriteLog(3,0,$DT->{shopname}."가 ".$DTS->{shopname}."의 광고를 냈습니다.");
				return $ret;
			_local_
	@@use
		time	16h
		exp	0%
		name	길드의 광고를 낸다
		info	동길드 소속점 모든 인기를 거론됩니다
		arg		nocount
			use		1	광고&nbsp;팩
		func	_local_
				return '길드에 들어가 있지 않기 때문에 광고를 낼 수 없었습니다' if !$DT->{guild};

				WriteLog(3,0,$DT->{shopname}."가 길드 「".$main::GUILD{$DT->{guild}}->[$GUILDIDX_name]."」의 광고를 냈습니다.");
				foreach my $DTS (@DT)
				{
				next if ($DTS->{guild} ne $DT->{guild});
				my $up=int(500*(2-$DTS->{rank}/5000));
				$DTS->{rank}+=$up;
				$DTS->{rank}=10000 if $DTS->{rank}>10000;
				my $ret="길드 광고를 냈습니다：".$DTS->{shopname}."의 인기 ".int($up/100)."%업";
				WriteLog(0,$DT->{id},$ret);
				}
				return '길드 광고를 냈습니다';
			_local_
@@ITEM
	no		4
	type	도구
	code	edit-showcase
	name	진열장&nbsp;증축취괴킷
	info	진열장의 증축이나 취괴 등에 필요한 도구세트입니다
	price	0
	limit	1/1
	pop	0
	plus	1d
	scale	킷
	flag	noshowcase|norequest
	@@use
		time	1h
		scale	회
		action	작업한다
		price	10000
		name	진열장을 1개로 한다
		info	진열장을 1개로 한다
		arg		nocount		#★사용시의 선택사항 지정.
							#  nocount -> 사용 회수 선택 없음
		param	1			#★독자 함수용 파라미터
			use	1	진열장&nbsp;증축취괴킷
		func	_local_
			# ★진열장수변경
			#   param1 변경 후의 책장의 수
			my $oldcnt=$DT->{showcasecount};
			my $newcnt=$USE->{param1};
			$DT->{showcasecount}=$newcnt;
			
			if($oldcnt<$newcnt)
			{
				foreach ($oldcnt..$newcnt-1)
				{
					$DT->{showcase}[$_]=0;
					$DT->{price}[$_]=0;
				}
			}
			if($oldcnt>$newcnt)
			{
				splice(@{$DT->{showcase}},$newcnt);
				splice(@{$DT->{price}},$newcnt);
			}
			my $ret="진열장을 $DT->{showcasecount}개로 했습니다";
			WriteLog(0,$DT->{id},$ret);
			WriteLog(0,0,$DT->{shopname}."의 진열장이 $DT->{showcasecount}개가 되었습니다.");
			
			return $ret;
		_local_
	@@use
		time	2h
		price	20000
		name	진열장을 2개로 한다
		info	진열장을 2개로 한다
		func	_local_1
		arg		nocount
		param	2
			use	1	진열장&nbsp;증축취괴킷
	@@use
		time	3h
		price	30000
		name	진열장을 3개로 한다
		info	진열장을 3개로 한다
		func	_local_1
		arg		nocount
		param	3
			use	1	진열장&nbsp;증축취괴킷
	@@use
		time	4h
		price	40000
		name	진열장을 4개로 한다
		info	진열장을 4개로 한다
		func	_local_1
		arg		nocount
		param	4
			use	1	진열장&nbsp;증축취괴킷
	@@use
		time	5h
		price	50000
		name	진열장을 5개로 한다
		info	진열장을 5개로 한다
		func	_local_1
		arg		nocount
		param	5
			use	1	진열장&nbsp;증축취괴킷
	@@use
		time	6h
		price	60000
		name	진열장을 6개로 한다
		info	진열장을 6개로 한다
		func	_local_1
		arg		nocount
		param	6
			use	1	진열장&nbsp;증축취괴킷
	@@use
		time	7h
		price	70000
		name	진열장을 7개로 한다
		info	진열장을 7개로 한다
		func	_local_1
		arg		nocount
		param	7
			use	1	진열장&nbsp;증축취괴킷
	@@use
		time	8h
		price	80000
		name	진열장을 8개로 한다
		info	진열장을 8개로 한다
		func	_local_1
		arg		nocount
		param	8
			use	1	진열장&nbsp;증축취괴킷
@@ITEM
	no		22
	type	도구
	code	book-help
	name	고민해결책
	info	고민이 이것으로 해결될지도
	price	0
	limit	1/1
	pop	0
	plus	4h
	scale	권
	flag	noshowcase
	@@USE
		time	20m
		scale	회
		action	확인한다
		name	어느 직업이 기회인가를 알고 싶다
		info	지금 부족한 직업을 한눈에 알 수 있습니다
		arg	nocount
		func	jobwant
	@@use
		time	40m
		scale	회
		action	매입한다
		price	1200
		name	빵이 시장에 나와 있지 않아서 살 수 없다
		info	빵을 특별 루트로 매입합니다(10 상자 단위)
		okmsg	빵을 조달했습니다
			get		10	빵
	@@use
		time	40m
		scale	회
		action	매입한다
		price	2400
		name	럼주가 시장에 나와 있지 않아서 살 수 없다
		info	럼주를 특별 루트로 매입합니다(10병 단위)
		okmsg	럼주를 조달했습니다
			get		10	럼주
	@@use
		time	40m
		scale	회
		action	고용한다
		price	15000
		name	선원이 시장에 나와 있지 않아서 고용할 수 없다
		info	선원을 특별 루트로 고용합니다(10명 단위)
		okmsg	선원을 고용했습니다
			get		10	선원
	@@use
		time	10m
		scale	회
		action	팔아 치운다
		name	금화가 팔리지 않고 대량으로 남아 버렸다
		info	금화를 특별 루트로 팔아 치웁니다
		okmsg	금화를 팔아 치웠습니다
			use		1	금화
		func	_local_
			$DT->{money}+=8000 * $count;
			return "환금액：".GetMoneyString(8000 * $count);
		_local_
	@@use
		time	8h
		scale	회
		action	일한다
		name	자금부족으로 곤란해 하고 있다
		info	일용 토목 작업으로 금화를 법시다
		okmsg	열심히 일해 금화를 받았습니다
			get		2	금화

@@ITEM
	no		24
	type	도구
	code	gift
	name	상품권
	info	갖고 싶은 것을 손에 넣자!
	price	10000
	cost	10
	limit	10/0
	scale	장
	@@USE
		time	20m
		scale	회
		action	어드바이스를 받는다
		name	상품권을 교환해 버리기 전에
		info	해탈한 자에게 어드바이스를 받습니다
		arg	nocount
		func	advice
			need		10	상품권
	@@USE
		time	20m
		scale	회
		action	확인한다
		name	현재의 직업 부족 상황을 본다
		info	지금 부족한 직업을 한눈에 알 수 있습니다
		arg	nocount
		func	jobwant
			need		10	상품권
	@@USE
		time	20m
		scale	회
		action	교환
		name	조선 상품과 교환
		info	조선가게로서 생활하는데 필요한 상품입니다
		okmsg	이용 감사합니다
			use		10	상품권
			get		1	조선법
	@@USE
		time	20m
		scale	회
		action	교환
		name	무역 상품과 교환
		info	무역상으로서 생활하는데 필요한 상품입니다
		okmsg	이용 감사합니다
			use		10	상품권
			get		5	바르카
			get		20	금화
			get		1	직업의&nbsp;비밀
			get		1	고민해결책
	@@USE
		time	20m
		scale	회
		action	교환
		name	탐험 상품과 교환
		info	탐험가로서 생활하는데 필요한 상품입니다
		okmsg	이용 감사합니다
			use		10	상품권
			get		5	바르카
			get		20	금화
			get		1	직업의&nbsp;비밀
			get		1	고민해결책
	@@USE
		time	20m
		scale	회
		action	교환
		name	해적 상품과 교환
		info	해적으로서 생활하는데 필요한 상품입니다
		okmsg	이용 감사합니다
			use		10	상품권
			get		5	바르카
			get		10	금화
			get		1	직업의&nbsp;비밀
			get		1	고민해결책
	@@USE
		time	20m
		scale	회
		action	교환
		name	해군 상품과 교환
		info	해군사령으로서 생활하는데 필요한 상품입니다
		okmsg	이용 감사합니다
			use		10	상품권
			get		5	바르카
			get		10	금화
			get		1	직업의&nbsp;비밀
			get		1	고민해결책

@@ITEM
	no		25
	type	도구
	code	slot
	name	제비뽑기권
	info	귀한 아이템에 당첨될지도
	price	20000
	cost	100
	limit	10/1.2
	plus	-10h
	scale	장
	pop	10d
	flag	noshowcase
	@@use
		time	20m
		scale	회
		action	뽑는다
		name	제비뽑기를 해본다
		info	당첨되는 것도 당첨되지 않는 것도 운에 따릅니다
		arg		nocount
		ngmsg	아무것도 당첨되지 않았습니다…
			use		1	제비뽑기권
			get		1	상품권		5%		상품권이&nbsp;당첨되었습니다!
			get		1	광고&nbsp;팩		10%		광고&nbsp;팩이&nbsp;당첨되었습니다!
			get		1	직업의&nbsp;비밀		5%		직업의&nbsp;비밀이&nbsp;당첨되었습니다!
			get		1	집지키는&nbsp;개			5%		집지키는&nbsp;개가&nbsp;당첨되었습니다!
			get		1	금단의&nbsp;해피베리	10%		금단의&nbsp;해피베리가&nbsp;당첨되었습니다!
			get		1	빵			5%		빵이&nbsp;당첨되었습니다!
			get		1	럼주			5%		럼주이&nbsp;당첨되었습니다!

@@ITEM
	no		87
	type	도구
	code	defence-manbiki
	name	집지키는&nbsp;개
	info	가게를 지키는 고급 혈통개
	price	500000
	cost	5000
	limit	1/0.5
	pop	1d
	plus	30m
	scale	마리
	flag	noshowcase|onlysend|human

@@ITEM
	no		88
	type	도구
	code	badgossip
	name	금단의&nbsp;해피베리
	info	금단의 과실은 달콤한 향기
	price	50000
	cost	5000
	limit	1/1
	pop	0
	plus	1d
	scale	권
	@@use
		time	10h
		exp	20%
		exptime	8h
		scale	회
		price	50000
		scale	회
		action	건다
		price	0
		name	로니레이크의 방해공작
		info	성공하면 상대의 가게의 인기를 내릴 수 있습니다만, 실패할 수도…
		arg	target|nocount
			needpoint	20000
		func	_local_
			my $ret;
			if(rand(1000)<800 && !$DTS->{exp}{@@ITEMNO"광고&nbsp;팩"})
			{
				$DTS->{rank}-=int($DTS->{rank}/3);
				$ret=$DTS->{shopname}.'의 나쁜 소문을 흘리는 작전이 성공했습니다';
				WriteLog(0,$DT->{id},$ret);
				WriteLog(2,0,$DTS->{shopname}.'의 나쁜 소문이 퍼져 인기가 내렸습니다.');
			}
			else
			{
				$DTS->{exp}{@@ITEMNO"광고&nbsp;팩"}-=100;
				$DTS->{exp}{@@ITEMNO"광고&nbsp;팩"}=0 if ($DTS->{exp}{@@ITEMNO"광고&nbsp;팩"} < 0);
				$DT->{rank}-=int($DT->{rank}/4);
				$ret=$DTS->{shopname}.'의 나쁜 소문을 흘리는 작전은 실패했습니다';
				WriteLog(0,$DT->{id},$ret);
				WriteLog(3,0,$DT->{shopname}."가 ".$DTS->{shopname}.'의 나쁜 소문을 걸려고 했던 것 같습니다.');
			}
			return $ret;
			_local_
	@@use
		time	10h
		exp	25%
		exptime	8h
		scale	회
		action	도둑한다
		price	50000
		name	케이시니아의 도둑질
		info	거기까지 몰렸다면, 어쩔 수 없다…
			needpoint	20000
		func	stole
		arg		target|nocount


#------------------------------이벤트
@@event
	start		10%
	basetime	5h
	plustime	5h
	code		happy
	startmsg	감사제가 이 거리에서 시작되었습니다.
	endmsg		감사제는 막을 닫았습니다.
	info		감사제로 거리는 떠들썩합니다.
	func		_local_
		my $time=$main::TIMESPAN;
		$time=10*3600 if $time>10*3600; # 최대10% 제한
		$time=int($time/36);
		
		foreach(@DT)
		{
			$_->{rank}+=int(rand($time));
			$_->{rank}=10000 if $_->{rank}>10000;
		}
		return 0;
	_local_

@@EVENT
	start		150%
	basetime	0h
	plustime	0h
	code		message
	info		메시지
	startfunc	_local_
		my @message=(
		'철학자 「이 대지는, 아래에서 큰 남자가 손으로 지지하고 있다.」',
		'종교가 「세계는, 체장 500 km에 이르는 거북이가 지지하고 있다.」',
		'천문학자 「대지는 둥근 공과 같은 형태를 하고 있을 것이 틀림없다.」',
		'모험가 「세계는 둥글다. 여기에서 서쪽으로 가면 바로 인도에 도착할 것이다.」',
		'선원 「너무 서쪽으로 가면, 대지에서 떨어져.」',
		'술집아가씨 「대지가 둥글다면, 귀퉁이에 있는 사람은 떨어져 버렸겠지요.」',
		'항해사 「아득한 동쪽에는,  전부 황금으로 세운 나라가 있는 것 같아.」',
		'항해사 「아득한 서쪽의 숲에는,  그리스도의 낙원이 있는 것 같아.」',
		'선원 「남쪽의 산골짜기에 있는 요정은, 목소리로 배를 침몰시켜버려.」',
		'선원 「온기가 없는 빛을 내는 배를 주의해라. 그것은 유령선이다.」',
		'모험가 「배보다 큰 낙지가 덮쳐서 배가 가라앉는 일도 있어.」',
		);
		my $cnt=int(rand(scalar(@message)));
		return (0,$message[$cnt]);
	_local_


@@FUNCINIT
#직업이 「탐험가」의 경우,쇼핑에 필요한 시간을1/2로 한다.
$TIME_SEND_ITEM=int($TIME_SEND_ITEM/2) if $DT->{job} eq 'explore';

@@FUNCITEM
######################################################################
# ★직업 체인지 체크
######################################################################
sub jobcheck
{
my($USE)=@_;
return 1 if ($DT->{job} eq $USE->{param4});
return 0;
}

######################################################################
# ★직업 체인지
######################################################################
sub jobport
{
	$DT->{job}=$USE->{param4};
	WriteLog(3,0,$DT->{shopname}.'의 직업이 「'.$main::JOBTYPE{$USE->{param4}}.'」가 되었습니다.');
	main::RequireFile('inc-sea.cgi');

	my $ret;
	my $exp1=$DT->{exp}{$USE->{param1}};
	my $exp2=0;
	$ret.="책을 한 손에 들고 전직의 신전으로 향했다.<br><br>";
	$ret.="<TABLE><tr><td>";
	$ret.=main::GetTagImgKao('암자','amza')."신관 암자：<br>";
	$ret.="….".$main::JOBTYPE{$USE->{param4}}."(이)가 되고 싶습니다.<br>";
	$ret.='전지전능의 신이여! <br>지금 여기있는<b> '.$DT->{shopname}."</b>가<br>";
	$ret.=$main::JOBTYPE{$USE->{param4}}."의 길을 걷는 것을 허락해주소서!";
	$ret.="</td></tr></table><br>";
	$ret.="직업이 ".$main::JOBTYPE{$USE->{param4}}."(이)가 되었습니다.<br>";
	
	foreach my $exps (split(/:/,$USE->{param2}))
	{
		my $exp=$DT->{exp}{$exps};
		next if (!$DT->{item}[$exps-1] && !$exp);
		$exp2+=$exp;
		delete($DT->{exp}{$exps});
		main::DeleteSeaSub("$DT->{id}-abi$exps");
		main::DeleteSeaSub("$DT->{id}-exp$exps");
		my $msg=$ITEM[$exps]->{name}.'는 없어졌습니다';
		if ($DT->{item}[$exps-1])
			{
			$DT->{item}[$exps-1]=0;
			$msg.="(인수료 ".GetMoneyString(50000).")";
			$DT->{money}+=50000;
			}
		$msg.=".";
		WriteLog(0,$DT->{id},$msg);
		$ret.=$msg."<br>";
	}
	$exp2=int($exp2*$USE->{param3});
	$exp1+=$exp2;
	$exp1=1000 if $exp1>1000;
	$msg=$ITEM[$USE->{param1}]->{name}."의 숙련도가 ".int($exp1/10)."% 가 되었습니다.";
	WriteLog(0,$DT->{id},$msg);
	$ret.=$msg."<br>";
	$DT->{exp}{$USE->{param1}}=$exp1;
	return $ret;
}

######################################################################
#★탐험 선단의 파견
######################################################################
sub exploring
{
	my $itemno=$USE->{param1};	#파견하는 배
	my $data=$USE->{param2};	#파견 해역
	my $ability=$ship[$data+4];	#능력
	main::ReadSea($data);
	my @subdata;
	$subdata[0]=$main::NOW_TIME + 3600*11 + int(rand(7200));
	$subdata[1]=$data;

	# 생존 판정
	if ($main::Pir * 12 > 100 + rand(1900 - $DT->{exp}{$itemno}))
		{
		$subdata[2]=1;	#해의 말 부스러기
		}
		else
		{
		$subdata[2]=0;
		
		# 발견물 판정
		if ($main::Civ + 20 < rand($ability) + int($DT->{exp}{$itemno} / 50))
			{
			$subdata[3]=1;
			$main::Civ+=int(rand(3) + 1);
			$main::Civ=100 if ($main::Civ > 100);
			}
		# 도시 발견 판정
		$subdata[4]=1 if (rand(100)+ ($main::Townnum * 12) < $ability + int($DT->{exp}{$itemno} / 50));
		}
	main::WriteSea($data);
	main::WriteSeaSub("$DT->{id}-exp$itemno",@subdata);
	my $ret;
	$ret.=qq|<IMG width="112" height="150" SRC="$main::IMAGE_URL/map/ship1.png"><br>|;
	my @AREA=("","유럽","아프리카","중동","인도","아시아","신대륙");
	$ret.=$AREA[$data]."에 탐험 선단을 파견했습니다.";
	WriteLog(0,0,$DT->{shopname}."가 ".$AREA[$data]."에 탐험 선단을 파견했습니다.");
	return $ret;
}

######################################################################
# ★탐험 선단 파견 전체크
######################################################################
sub beforeexp
{
my($USE)=@_;
my $itemno=$USE->{param1};	#파견하는 배
my $data=$USE->{param2};	#파견 해역
return 1 if ($DT->{job} ne 'explore');
return 1 if -e(main::GetPath($main::SUBDATA_DIR,$DT->{id}."-exp".$itemno));
if (!$ship[0])
	{
	main::RequireFile('inc-sea.cgi');
	@ship=main::ReadSeaSub("$DT->{id}-abi$itemno");
	}
return 1 if $ship[$data+4] < 1;
$USE->{info}.="<b>".$ship[$data+4]."</b>%";
$USE->{use}[0]->{no}=@@ITEMNO "빵";
$USE->{use}[0]->{count}=$ship[11];
$USE->{use}[0]->{proba}=1000;
$USE->{use}[1]->{no}=@@ITEMNO "럼주";
$USE->{use}[1]->{count}=$ship[12];
$USE->{use}[1]->{proba}=1000;
$USE->{use}[2]->{no}=@@ITEMNO "선원";
$USE->{use}[2]->{count}=$ship[13];
$USE->{use}[2]->{proba}=1000;
return 0;
}

######################################################################
# ★파견중 때만 가능
######################################################################
sub onlyexp
{
my($USE)=@_;
my $itemno=$USE->{param1};	#파견한 배
return 0 if -e(main::GetPath($main::SUBDATA_DIR,$DT->{id}."-exp".$itemno));
return 1;
}

######################################################################
#★탐험 선단의 마중
######################################################################
sub meetexp
{
	my $itemno=$USE->{param1};	#파견한 배
	main::RequireFile('inc-sea.cgi');
	my @subdata=main::ReadSeaSub("$DT->{id}-exp$itemno");
	my @ship=main::ReadSeaSub("$DT->{id}-abi$itemno");
	my $seaman=$ship[13];		#선원
	my $ret;
	$ret.=qq|<TABLE cellpadding="26" width="570"><tr>|;
	$ret.=qq|<TD style="background-repeat : repeat-x;background-image : url($main::IMAGE_URL/harbor.png);" valign="top"><br><br>|;

	if ($main::NOW_TIME < $subdata[0])
		{
		$ret.="항구에 나와 보았지만, 아직 선단이 돌아오지 않았다.<br>";
		$ret.="좀 더 느긋하게 기다려 보자.</tr></table>";
		return $ret;
		}
	main::DeleteSeaSub("$DT->{id}-exp$itemno");
	if ($subdata[2])
		{
		$ret.=qq|<IMG width="112" height="150" align="left" SRC="$main::IMAGE_URL/map/ship2.png">|;
		$ret.="이제 슬슬 선단이 돌아올 무렵이다.<br>";
		$ret.="그러나, 아무리 기다려도 선단의 모습은 보이지 않았다.<br><br>";
		$ret.="아무래도, 바다의 말에 가루가 되어 사라져버린 것 같다.<br>";  # 역주 : 바다의 말이란 포세이돈의 말을 말하는것같습니다
		$ret.="해적에게라도 당한 것일까···.<br>";
		$ret.="</tr></table>";
		UseItem($itemno,1);
		delete $DT->{exp}{$itemno};
		main::DeleteSeaSub("$DT->{id}-abi$itemno");
		WriteLog(2,0,$DT->{shopname}.'의 탐험 선단은 바다의 말에 가루가 되어 사라졌습니다.');
		return $ret;
		}
	$seaman=int($seaman * (70 + rand(30)) / 100);
	AddItem(@@ITEMNO "선원",$seaman);
	$ret.=qq|<IMG width="112" height="150" align="left" SRC="$main::IMAGE_URL/map/ship1.png">|;
	$ret.=main::GetTagImgKao('제독','exp','align="left" ')."<SPAN>제독</SPAN>：오오, 정확히 지금 도착한 참이다.<br>";
	$ret.="태풍이나 해적이나 눈보라에 시달렸지만, <br>$seaman인의 선원이 무사하다.<br>";
	if ($subdata[3])
		{
		$ret.="이번 항해의 도중, 귀한 것을 발견했네.<br>";
		$ret.="<SPAN>보고서</SPAN>를 써 두었으니, 꼭 읽어두게나.<br>";
		AddItem((38 + $subdata[1]),1);
		}
		else
		{
		$ret.="이번 항해에서는, 특별히 귀한 것은 발견되지 않았어.<br>";
		}
	if ($subdata[4])
		{
		$ret.="그것보다 중요한 것은, <b>새로운 육지를 발견했다</b>는 거야.<br>";
		$ret.="<SPAN>새로운 무역 도시</SPAN>를 건설할 수 있을 것 같구나!<br>";
		AddItem((44 + $subdata[1]),1);
		}
		else
		{
		$ret.="이번 항해에서는, 특별히 새로운 육지는 발견되지 않았어.<br>";
		}
	$ret.="이상으로 보고는 끝이다. 다음 항해까지는 조금 쉬도록 해주게.";
	$ret.="</tr></table>";
	return $ret;
}

######################################################################
#★발견물
######################################################################
sub disc
{
	my $no=$USE->{param1} - 1;
	my @DISCOVER=(
		[
		['연금술','모든 물건을 돈으로 변화시키는 기술. 다만, 재료가 수중에 들어 오지 않는다.',55],
		['미노타우르스의 도끼','맹수 미노타우르스가 사용했던 도끼. 손잡이의 부분에 낑낑거리는 소리가 난다.',72],
		['프랭크왕의 샤브르','프랭크왕이 사용했던 샤브르. 보석이 아로새겨져 있다.',75],
		['유다의 마의','그리스도를 배반한 유다가 입고 있던 옷. 가진 사람을 저주한다.',65],
		['아틸라의 요로이','아틸라왕이 입었던 갑옷. 무거워서 들어 올릴 수가 없다.',65],
		['역주하는 회중 시계','반시계회전에 바늘이 진행되는 시계. 태엽을 감지 않아도 자신의 의사로 움직인다.',75],
		['멸의 십자가','그리스도가 처형 시에 못박혀 몸이 붙여진 십자가.',60],
		['스톤헨지','돌기둥을 고리처럼 둘러싼 유적.',60],
		],
		[
		['기린','몸으로부터 오색의 인광을 발하는 영수. 소의 꼬리와 말의 굽을 가지고, 아랫배는 황색이다.',90],
		['인초','지면에 풀처럼 나와 있는 인간의 종족.',65],
		['머리에 눈이 달린 사람','머리의 부분이 모두 눈이 된 인간의 종족.',70],
		['보행브나','보행하는 브나의 나무. 모습을 보면 재수가 좋다고 한다.',75],
		['하마페카의 검','고대의 왕의 검.모두 순금으로 되어 있다.',100],
		['재앙의 신의 조각상','뱀의 모습을 한 재앙의 신을 제사 지내는 조각상.',60],
		['스핑크스','반인반사자의 마수. 수수께끼 내기를 좋아해, 풀지 못한 사람을 먹는다.',70],
		['빅토리아 폭포','대지의 갈라진 곳으로 흐르는 거대한 폭포.',60],
		],
		[
		['살라딘의 갑옷','고대의 왕의 갑옷. 검소하지만, 어떤 공격도 통하지 않는다.',60],
		['천구의','밤하늘의 모습을 둥근 구체에 그려낸 예술품.',80],
		['클레오파트라의 융단','아름다운 자수의 융단. 절세의 미녀가 이것을 두르고 있었다고 한다.',100],
		['램프의 거인','램프 안에서 사는 인간의 종족.',75],
		['코란','이 지역의 민족이 필수품으로 여기는 서적. 무엇인가 중요한 일이 쓰여져 있는 것 같다.',50],
		['슈메이르의 점토판','고대의 인간이 적은 문자. 우리의 언어와 많이 비슷하다.',50],
		['포권인','전신을 옷감으로 빙빙 감은 인간의 종족.',60],
		['십자군의 보검','십자군의 대장이 원정 시에 이용한 보검.',80],
		],
		[
		['코끼리','코가 긴 거대한 영수. 동체는 굵고, 다리가 8개 있다.',80],
		['수장족','목의 부분이 1미터 가깝게 있는 인간의 종족.',60],
		['금식충','금을 먹고 사는 벌레.',60],
		['금두운','사람을 실어 날 수 있는 구름.',75],
		['스토우버','돌로 만든 거대한 탑. 안에 현지의 신이 모셔져 있다.',50],
		['무갈의 보순','고대 왕국에 전해지는 전설의 방패. 사파이어가 아로새겨져다.',100],
		['용사의 시미터','고대의 영웅이 이용했다고 하는 시미터.',80],
		['타지마하르','고대의 왕이 여성을 모시기 위해 세운 거대 사원.',70],
		],
		[
		['주판','이 지역의 민족의 놀이 도구. 구슬을 연주하며 논다.',90],
		['요도촌정','요기를 띤 검. 소유자의 마음을 지배해, 복수심으로 가득채운다.',70],
		['포도의 보물함','해중의 낙원으로부터 가지고 온 보물. 이 근처에 용궁이 있는 것 같다.',100],
		['배를 베는 사람','배를 스스로 자르는 것을 좋아하는 인간의 종족.',75],
		['도원향의 지도','전설의 낙원의 위치를 나타내는 지도. 이 근처에 도원향이 있는 것 같다.',100],
		['동충하초','반충반식물. 겨울에는 벌레의 모습을 하고 있지만, 여름이 되면 풀로 변한다.',80],
		['고려 인삼','만병을 치유한다고 알려진 전설의 당근.',80],
		['만리장성','고대의 왕이 외적의 침입을 막기 위해 쌓아 올린 벽.',70],
		],
		[
		['금개구리','살아 있는 개구리지만, 몸이 황금으로 되어 있다.',90],
		['좌절의 유적','그리스도를 모신 시설의 잔해. 전설의 성지 플레이스테이션·죠안의 영락한 모습과 같다.',120],
		['황금의 강','물 대신에 황금이 흐르는 강. 근처에 황금의 나라 엘·드라드가 있는 것 같다.',100],
		['나스카의 지상회','지상에 그려진 거대한 새의 그림.',75],
		['모아이의 석상','해안에 늘어진 거대한 사람의 얼굴의 석상.',100],
		['문신한 사람','얼굴이나 몸을 청색 또는 홍색 등으로 바르는 것을 좋아하는 인간의 종족.',75],
		['인어','허리부터 아랫부분이 물고기가 되어 있는 인간의 종족.',90],
		['공중 유적','공중에 존재하는 도시의 유적. 사람은 사멸해있다.',80],
		],
	);
	my @MYDIS=@{$DISCOVER[$no]};
	my $num=int(rand(scalar(@MYDIS))) + 0;
	my @msg=@{$MYDIS[$num]};
	my $ret;
	$ret.=qq|<TABLE cellpadding="26" width="455"><tr>|;
	$ret.=qq|<TD style="background-repeat : repeat-x;background-image : url($main::IMAGE_URL/discover.png);" valign="top"><br><br>|;
	$no++;
	$num++;
	$ret.=qq|<IMG width="60" height="80" align="left" SRC="$main::IMAGE_URL/disc/$no-$num.png">|;
	$ret.="<SPAN>$msg[0]</SPAN><br><br>";
	$ret.="$msg[1]</tr></table>";
	$ret.="<br>포상으로서 임금님으로부터 ".main::GetTagImgItemType(51)."금화 ".($msg[2])."</b>닢 받았다.";
	AddItem(51,$msg[2]);
	return $ret;
}

######################################################################
#★도시 건설
######################################################################
sub newtown
{
	my $data=$USE->{param1};	#파견 해역
	$name=$USE->{arg}->{message};
	main::RequireFile('inc-sea.cgi');
	main::ReadSea($data);
	my $ret;
	if ($main::Townnum > 9)
		{
		$ret.='뭐야! 새롭게 발견한 이 도시에는 이미 상관이 건설되어있어.<br>';
		$ret.='아무래도, 상관의 건설에서 추월당한 것 같아.<br>';
		$ret.='누구냐! 먼저 건설한 놈은!';
		return $ret;
		}
	main::OutError('도시의&nbsp;이름을 붙여 주세요.') if !$name;
	main::OutError('도시의&nbsp;이름에 사용할 수 없는 문자가 사용되고 있습니다.') if ($name =~ /([,:;\t\r\n<>&])/);
	my @TOWN=(
		[
		[@@ITEMNO "와인",20,10],
		[@@ITEMNO "치즈",15,10],
		[@@ITEMNO "올리브유",25,5],
		[@@ITEMNO "모직물",10,15],
		[@@ITEMNO "스테인드&nbsp;글라스",20,10],
		[@@ITEMNO "조각",20,10],
		[@@ITEMNO "총",15,10],
		],
		[
		[@@ITEMNO "금",10,5],
		[@@ITEMNO "다이아몬드",10,10],
		[@@ITEMNO "산호",15,10],
		[@@ITEMNO "상아",15,15],
		[@@ITEMNO "커피",10,10],
		[@@ITEMNO "소금",20,10],
		[@@ITEMNO "타마린드",20,10],
		],
		[
		[@@ITEMNO "철광석",10,10],
		[@@ITEMNO "유황",10,10],
		[@@ITEMNO "벌꿀",15,10],
		[@@ITEMNO "설탕",15,15],
		[@@ITEMNO "융단",8,7],
		[@@ITEMNO "마직물",10,5],
		[@@ITEMNO "무소뿔",5,15],
		],
		[
		[@@ITEMNO "초석",10,10],
		[@@ITEMNO "사파이어",10,5],
		[@@ITEMNO "후추",1,4],
		[@@ITEMNO "신나몬",10,15],
		[@@ITEMNO "면직물",15,10],
		[@@ITEMNO "경사",10,10],
		[@@ITEMNO "별갑",10,5],
		],
		[
		[@@ITEMNO "진주",10,10],
		[@@ITEMNO "청주",10,10],
		[@@ITEMNO "차",5,10],
		[@@ITEMNO "견직물",5,15],
		[@@ITEMNO "강호시대의&nbsp;풍속화",10,5],
		[@@ITEMNO "칠기",5,15],
		[@@ITEMNO "도",5,10],
		],
		[
		[@@ITEMNO "은",5,10],
		[@@ITEMNO "에메랄드",5,10],
		[@@ITEMNO "카카오",5,15],
		[@@ITEMNO "옥수수",5,15],
		[@@ITEMNO "토마토",10,5],
		[@@ITEMNO "담배",5,5],
		[@@ITEMNO "호박",5,10],
		],
	);
	$no=$data - 1;
	my @MYDIS=@{$TOWN[$no]};
	my $num=int(rand(scalar(@MYDIS))) + 0;
	my @msg=@{$MYDIS[$num]};
	my $price=int($ITEM[$msg[0]]->{price} * ($msg[1] + rand($msg[2])) / 100);
	my $life=$main::NOW_TIME + 86400*8 + int(rand(86400) * 4);
	foreach(1..$#main::SEA)
		{
		my @buf=split(',',$main::SEA[$_]);
		$life++ if $buf[0] == $life;
		main::OutError('같은 이름의 도시가 있습니다. 다른 이름으로 해 주세요.') if $buf[1] eq $name;
		}
	push (@main::SEA,"$life,$name,$DT->{id},$msg[0],$price,0\n");
	$main::Civ+=int(rand(3));
	$main::Civ=100 if ($main::Civ > 100);
	$main::Pir+=int(rand(4));
	$main::Pir=100 if ($main::Pir > 100);
	main::WriteSea($data);
	$ret.=qq|<IMG width="255" height="153" SRC="$main::IMAGE_URL/map/trade.jpg"><br><br>|;
	$ret.='상관을 건설했습니다. <br>도시 「<b>'.$USE->{arg}->{message}.'</b>」과 무역 가능하게 되었습니다.';
	WriteLog(2,0,$DT->{shopname}.'가 도시 「'.$USE->{arg}->{message}.'」를 발견했습니다.');
	return $ret;
}

######################################################################
# ★무역 선단 파견 전체크
######################################################################
sub routesel
{
my($USE)=@_;
my $itemno=$USE->{param1};	#파견하는 배
my $data=$USE->{param2};	#파견 해역
return 1 if ($DT->{job} ne 'trader');
return 1 if -e(main::GetPath($main::SUBDATA_DIR,$DT->{id}."-exp".$itemno));
if (!$ship[0])
	{
	main::RequireFile('inc-sea.cgi');
	@ship=main::ReadSeaSub("$DT->{id}-abi$itemno");
	}
return 1 if $ship[$data+4] < 1;
$USE->{info}.="<b>".$ship[$data+4]."</b>%";
main::ReadSea($data);
return 1 if $main::Townnum < 1;
$USE->{argselect}=';';
foreach(1..$main::Townnum)
	{
	my($date,$name,$other) =split(',',$main::SEA[$_],3);
	$USE->{argselect}.=$_.';'.$name.';';
	}
$USE->{use}[0]->{no}=@@ITEMNO "빵";
$USE->{use}[0]->{count}=$ship[11];
$USE->{use}[0]->{proba}=1000;
$USE->{use}[1]->{no}=@@ITEMNO "럼주";
$USE->{use}[1]->{count}=$ship[12];
$USE->{use}[1]->{proba}=1000;
$USE->{use}[2]->{no}=@@ITEMNO "선원";
$USE->{use}[2]->{count}=$ship[13];
$USE->{use}[2]->{proba}=1000;
return 0;
}

######################################################################
#★무역 선단의 파견
######################################################################
sub route
{
	my $itemno=$USE->{param1};	#파견한 배
	my $data=$USE->{param2};	#파견 해역
	my $ability=int($ship[$data+4] / 2);	#적재량(x만엔 상당)
	my $sel=$USE->{arg}->{select};

	#파견수를 늘린다
	my @buf=split(',',$main::SEA[$sel]);
	main::OutError("「$buf[1]」의 산물은 바닥나 있으므로 파견할 수 없습니다.<br>파견처를 변경해 주세요.") if ($buf[0] < $main::NOW_TIME);
	$main::SEA[$sel]="$buf[0],$buf[1],$buf[2],$buf[3],$buf[4],".($buf[5] + 1)."\n";
	main::WriteSea($data);

	my @subdata;
	$subdata[0]=$main::NOW_TIME + 3600*11 + int(rand(7200));

	# 생존 판정
	$subdata[1]=1 if ($main::Pir * 12 > 100 + rand(1900 - $DT->{exp}{$itemno}));

	#무역량
	$subdata[2]=$buf[1];
	$subdata[3]=$buf[3];
	$subdata[4]=int($ITEM[$buf[3]]->{limit} * $ability / 100);
	$subdata[5]=$buf[4] * $subdata[4];

	# 발견자에게 이익 발생
	if (defined($main::id2idx{$buf[2]}))
		{
		$DT[$main::id2idx{$buf[2]}]->{money}+=int($subdata[5] / 2);
		$DT[$main::id2idx{$buf[2]}]->{saletoday}+=int($subdata[5] / 2);
		}
	main::WriteSeaSub("$DT->{id}-exp$itemno",@subdata);
	my $ret;
	$ret.=qq|<IMG width="112" height="150" SRC="$main::IMAGE_URL/map/ship1.png"><br>|;
	$ret.="「$buf[1]」에 무역 선단을 파견했습니다.";
	return $ret;
}

######################################################################
#★무역 선단의 마중
######################################################################
sub meetrtp
{
	my $itemno=$USE->{param1};	#파견한 배
	main::RequireFile('inc-sea.cgi');
	my @subdata=main::ReadSeaSub("$DT->{id}-exp$itemno");
	my @ship=main::ReadSeaSub("$DT->{id}-abi$itemno");
	my $seaman=$ship[13];		#선원
	my $ret;
	$ret.=qq|<TABLE cellpadding="26" width="570"><tr>|;
	$ret.=qq|<TD style="background-repeat : repeat-x;background-image : url($main::IMAGE_URL/harbor.png);" valign="top"><br><br>|;

	if ($main::NOW_TIME < $subdata[0])
		{
		$ret.="항구에 나와 보았지만, 아직 선단이 돌아올 기색이 없다.<br>";
		$ret.="좀 더 느긋하게 기다려 보자.</tr></table>";
		return $ret;
		}
	main::DeleteSeaSub("$DT->{id}-exp$itemno");
	if ($subdata[1])
		{
		$ret.=qq|<IMG width="112" height="150" align="left" SRC="$main::IMAGE_URL/map/ship2.png">|;
		$ret.="이제 슬슬, 선단이 돌아와도 괜찮을 무렵이다.<br>";
		$ret.="그러나, 아무리 기다려도 선단의 모습은 보이지 않는다.<br><br>";
		$ret.="아무래도, 바다의 말에 부스러기가 되어 사라져 버린 것 같다.<br>";
		$ret.="해적에게라도 당한 것일까···.<br>";
		$ret.="</tr></table>";
		UseItem($itemno,1);
		delete $DT->{exp}{$itemno};
		main::DeleteSeaSub("$DT->{id}-abi$itemno");
		WriteLog(2,0,$DT->{shopname}.'의 무역 선단은 바다의 말에 부스러기가 되어 사라졌습니다.');
		return $ret;
		}
	$seaman=int($seaman * (70 + rand(30)) / 100);
	AddItem(@@ITEMNO "선원",$seaman);
	$ret.=qq|<IMG width="112" height="150" align="left" SRC="$main::IMAGE_URL/map/ship1.png">|;
	$ret.=main::GetTagImgKao('제독','rtp','align="left" ')."<SPAN>제독</SPAN>：지금 귀환했습니다.<br>";
	$ret.="도중에, 태풍이나 해적에게 골치를 썩였습니다만, <br>$seaman인의 선원이 무사합니다.<br>";
	$ret.="이번 무역에서는, 도시 「$subdata[2]」에서, <br>";
	$ret.=main::GetTagImgItemType($subdata[3]).$ITEM[$subdata[3]]->{name}."(을)를 ";
	$ret.=$subdata[4].$ITEM[$subdata[3]]->{scale}."매입할 수 있었습니다.<br>";
	$ret.="매입의 비용으로서 ".GetMoneyString($subdata[5])."들었습니다.<br>";
	$DT->{money}-=$subdata[5];
	$DT->{paytoday}+=$subdata[5];
	AddItem($subdata[3],$subdata[4]);
	$ret.="보고는 이상대로입니다.";
	$ret.="</tr></table>";
	return $ret;
}

######################################################################
# ★무장 함대 파견 전체크
######################################################################
sub nowpp
{
my($USE)=@_;
my $itemno=$USE->{param1};	#파견한 배
my $data=$USE->{param2};	#파견 해역
if ($DT->{job} eq 'pirate') {$USE->{name}.="약탈으로 파견한다";}
elsif ($DT->{job} eq 'pros') {$USE->{name}.="정찰으로 파견한다";}
else {return 0;}
return 1 if -e(main::GetPath($main::SUBDATA_DIR,$DT->{id}."-exp".$itemno));
if (!$ship[0])
	{
	main::RequireFile('inc-sea.cgi');
	@ship=main::ReadSeaSub("$DT->{id}-abi$itemno");
	}
return 1 if $ship[$data+4] < 1;
$USE->{info}.="<b>".$ship[$data+4]."</b>%";
$USE->{use}[0]->{no}=@@ITEMNO "빵";
$USE->{use}[0]->{count}=$ship[11];
$USE->{use}[0]->{proba}=1000;
$USE->{use}[1]->{no}=@@ITEMNO "럼주";
$USE->{use}[1]->{count}=$ship[12];
$USE->{use}[1]->{proba}=1000;
$USE->{use}[2]->{no}=@@ITEMNO "선원";
$USE->{use}[2]->{count}=$ship[13];
$USE->{use}[2]->{proba}=1000;
return 0;
}

######################################################################
#★무장 함대의 파견
######################################################################
sub attack
{
	my $itemno=$USE->{param1};	#파견하는 배
	my $data=$USE->{param2};	#파견 해역
	my $ability=$ship[$data+4];	#능력
	main::ReadSea($data);
	my @subdata;
	$subdata[0]=$main::NOW_TIME + 3600*11 + int(rand(7200));
	$subdata[1]=$data;
	my $ret;
	$ret.=qq|<IMG width="112" height="150" SRC="$main::IMAGE_URL/map/ship1.png"><br>|;
	my @AREA=("","유럽","아프리카","중동","인도","아시아","신대륙");

	if ($DT->{job} eq 'pros')
	{
	# 해군의 처리
	# 생존 판정
	if ($main::Pir * 6 > 100 + rand(1900 - $DT->{exp}{$itemno}))
		{
		$subdata[2]=1;	#해의 말 부스러기
		}
		else
		{
		# 해적 출현율 저하
		$main::Pir-=int(rand(5)) + 6;
		$main::Pir=0 if ($main::Pir < 0);
		# 해군 정찰율 상승
		$main::Pro+=int(rand(5)) + 4;
		$main::Pro=100 if ($main::Pro > 100);
		}
	$ret.=$AREA[$data]."에 해군을 파견했습니다.";
	WriteLog(0,0,$DT->{shopname}."가 ".$AREA[$data]."에 해군을 파견했습니다.");
	}
	else
	{
	# 해적의 처리
	# 생존 판정
	if ($main::Pro * 16 > 100 + rand(1900 - $DT->{exp}{$itemno}))
		{
		$subdata[2]=1;	#해의 말 부스러기
		}
		else
		{
		# 해적 출현율 상승
		$main::Pir+=int(rand(5)) + 4;
		$main::Pir=100 if ($main::Pir > 100);
		}
	$ret.=$AREA[$data]."에 해적선을 파견했습니다.";
	WriteLog(2,0,$AREA[$data]."에서 해적이 출몰해 있는 것 같습니다.");
	}
	if (!$subdata[2])
		{
		$subdata[2]=0;
		# 금화
		$subdata[3]=int(($ability / 4) + ($DT->{exp}{$itemno} / 100) + rand(5));
		# 무역품
		if ($main::Townnum > 0 && $main::Pir > rand(20))
			{
			my $sel=int(rand($main::Townnum)) + 1;
			my @buf=split(',',$main::SEA[$sel]);
			$subdata[4]=$buf[3];
			$subdata[5]=int($ITEM[$buf[3]]->{limit} * $ability / 200);
			}
		}
	main::WriteSea($data);
	main::WriteSeaSub("$DT->{id}-exp$itemno",@subdata);
	return $ret;
}

######################################################################
#★무장 함대의 마중
######################################################################
sub meetpp
{
	my $itemno=$USE->{param1};	#파견한 배
	main::RequireFile('inc-sea.cgi');
	my @subdata=main::ReadSeaSub("$DT->{id}-exp$itemno");
	my @ship=main::ReadSeaSub("$DT->{id}-abi$itemno");
	my $seaman=$ship[13];		#선원
	my $ret;
	$ret.=qq|<TABLE cellpadding="26" width="570"><tr>|;
	$ret.=qq|<TD style="background-repeat : repeat-x;background-image : url($main::IMAGE_URL/harbor.png);" valign="top"><br><br>|;

	if ($main::NOW_TIME < $subdata[0])
		{
		$ret.="항구에 나와 보았지만, 아직 함대가 돌아올 기색은 없는 것 같다.<br>";
		$ret.="좀 더 느긋하게 기다려 보자.</tr></table>";
		return $ret;
		}
	main::DeleteSeaSub("$DT->{id}-exp$itemno");
	if ($DT->{job} eq 'pros')
	{
	# 해군의 처리
	if ($subdata[2])
		{
		$ret.=qq|<IMG width="112" height="150" align="left" SRC="$main::IMAGE_URL/map/ship2.png">|;
		$ret.="이제 슬슬 함대가 돌아와도 괜찮은 무렵이다.<br>";
		$ret.="그러나 아무리 기다려도 함대의 모습은 안보였다.<br><br>";
		$ret.="아무래도, 바다의 말에 부스러기가 되어 사라져 간 것 같다.<br>";
		$ret.="해적에게 패배해 버린 것일까···.<br>";
		$ret.="</tr></table>";
		UseItem($itemno,1);
		delete $DT->{exp}{$itemno};
		main::DeleteSeaSub("$DT->{id}-abi$itemno");
		WriteLog(2,0,$DT->{shopname}.'의 해군은 해적에게 패해 침몰했습니다.');
		return $ret;
		}
	$seaman=int($seaman * (40 + rand(30)) / 100);
	AddItem(@@ITEMNO "선원",$seaman);
	$ret.=qq|<IMG width="112" height="150" align="left" SRC="$main::IMAGE_URL/map/ship1.png">|;
	$ret.=main::GetTagImgKao('제독','pro','align="left" ')."<SPAN>제독</SPAN>：오오, 지금 귀환한 참이다.<br>";
	$ret.="도중, 태풍이나 전투에 말려 들었지만, <br>$seaman인의 선원이 무사하다.<br>";

	if ($subdata[3])
		{
		$ret.="이번,해적의 숙영지를 발견, 소탕 했다.<br>";
		$ret.=main::GetTagImgItemType(51)."금화 $subdata[3]닢을 몰수했다.<br>";
		AddItem(51,$subdata[3]);
		}
	if ($subdata[4])
		{
		$ret.="도중 우연히 지나가던 해적선을 공격, 이것을 토벌해,<br>";
		$ret.=main::GetTagImgItemType($subdata[4]).$ITEM[$subdata[4]]->{name}."(을)를 ";
		$ret.=$subdata[5].$ITEM[$subdata[4]]->{scale}." 몰수했다.<br>";
		AddItem($subdata[4],$subdata[5]);
		}
	$ret.="이상으로 보고를 끝마친다. 치안에 공헌할 수 있던 것을 영광으로 생각한다.";
	$ret.="</tr></table>";
	return $ret;
	}
	# 해적의 처리
	if ($subdata[2])
		{
		$ret.=qq|<IMG width="112" height="150" align="left" SRC="$main::IMAGE_URL/map/ship2.png">|;
		$ret.="이제 슬슬 함대가 돌아와도 괜찮은 무렵이다.<br>";
		$ret.="그러나 아무리 기다려도 함대의 모습은 안보였다.<br><br>";
		$ret.="아무래도 바다의 말에 부스러기가 되어 사라져 버린 것 같다.<br>";
		$ret.="해군이라도 당한 것일까···.<br>";
		$ret.="</tr></table>";
		UseItem($itemno,1);
		delete $DT->{exp}{$itemno};
		main::DeleteSeaSub("$DT->{id}-abi$itemno");
		WriteLog(2,0,$DT->{shopname}.'의 해적선은 해군에게 토벌 되었습니다.');
		return $ret;
		}
	$seaman=int($seaman * (40 + rand(30)) / 100);
	AddItem(@@ITEMNO "선원",$seaman);
	$ret.=qq|<IMG width="112" height="150" align="left" SRC="$main::IMAGE_URL/map/ship1.png">|;
	$ret.=main::GetTagImgKao('제독','pir','align="left" ')."<SPAN>제독</SPAN>：여어, 마침 귀환한 참이다.<br>";
	$ret.="도중, 태풍이나 전투같은 것도 있었지만, <br>$seaman인의 선원이 무사하다.<br>";

	if ($subdata[3])
		{
		$ret.="이번, 탐험으로 배회하고 있던 선단을 가라앉혀 주었다.<br>";
		$ret.=main::GetTagImgItemType(51)."금화 $subdata[3]닢을 취했다.<br>";
		AddItem(51,$subdata[3]);
		}
	if ($subdata[4])
		{
		$ret.="도중 우연히 지나가던 무역배로부터는, 돌아갈 곳을 가늠해,<br>";
		$ret.=main::GetTagImgItemType($subdata[4]).$ITEM[$subdata[4]]->{name}."(을)를 ";
		$ret.=$subdata[5].$ITEM[$subdata[4]]->{scale}." 받았다구.<br>";
		AddItem($subdata[4],$subdata[5]);
		}
	$ret.="어때, 나의 실력은? 이 맛은 잊을 수 없다구!";
	$ret.="</tr></table>";
	return $ret;
}

######################################################################
#★개시시의 어드바이스
######################################################################
sub advice
{
	my $ret;
	$ret.=qq|<TABLE cellpadding="26" width="570"><tr>|;
	$ret.=qq|<TD style="background-repeat : repeat-x;background-image : url($main::IMAGE_URL/harbor.png);" valign="top"><br><br>|;
	$ret.=main::GetTagImgKao('하이레딘','bal','align="left" ')."<SPAN>하이레딘</SPAN>：이런 시각에 상담하러 오다니 좋은 담력이구나.<br>";
	$ret.="이 상품권 교환은, <BIG>매우 중대한 선택</BIG>이다.<br>";
	$ret.="처음의 인생은 이것으로 결정된다, 지금 무슨 직업이 유리한가를 지켜보아라.<br><br>";
	$ret.="1. <BIG>조선</BIG>은 초심자전용이지만, <b>동업자</b>가 너무 많으면 장사가 되지 않는다.<br>";
	$ret.="2. <BIG>무역</BIG>은, 유럽의<b>해적 출현율</b>이 너무 높으면 적자가 된다.<br>";
	$ret.="3. <BIG>탐험</BIG>은, 유럽의<b>해적 출현율</b>이 낮고, <b>미답파영역</b>이 귀하면 유리할 것이다.<br>";
	$ret.="4. <BIG>해적</BIG>은, 유럽의<b>해군 정찰율</b>이 높으면 성공하지 못한다.<br>";
	$ret.="5. <BIG>해군</BIG>은, 유럽의<b>해적 출현율</b>이 너무 낮으면 적자가 된다.<br>";
	$ret.="<br>알았는가? 그리고 실패하지 않는 최대의 요령은, <SPAN>도서관</SPAN>을 자주 읽는 것이다.";
	$ret.="</tr></table>";
	return $ret;
}

######################################################################
#★직업 부족·포화 상황
######################################################################
sub jobwant
{
	my %jobwant;
	my $sum;
	foreach my $DT(@DT)
		{
		next if !$DT->{job};
		$jobwant{$DT->{job}}++;
		$sum++;
		}
	my $ret;
	$ret.=qq|<TABLE cellpadding="26" width="570"><tr>|;
	$ret.=qq|<TD style="background-repeat : repeat-x;background-image : url($main::IMAGE_URL/harbor.png);" valign="top" align="center"><br><br>|;
	$ret.=$main::TB;

	my %jobneed=qw(shipb 10 explore 15 trader 55 pirate 10 pros 10);
	foreach("shipb","explore","trader","pirate","pros")
		{
		$ret.=$main::TR.$main::TDB.$main::JOBTYPE{$_};
		my $i=($sum) ? ($jobwant{$_} / $sum / $jobneed{$_} * 100 * 100) : 100;
		$ret.=$main::TD.main::GetMarketStatusGraph($i).$main::TRE;
		}
	$ret.="</tr></table></tr></table>";
	return $ret;
}

######################################################################
#★도둑
######################################################################
sub stole
{
	return '자신에게 도둑질할 수 없습니다. 도둑질은 실패입니다.' if  ($DT->{id} eq $DTS->{id});
	my $ret="도둑질은 실패했습니다. 배상금 ".GetMoneyString(500000)."(을)를 빼앗겨 버렸습니다.";
	if($DTS->{item}[@@ITEMNO"집지키는&nbsp;개"-1])
	{
		$DT->{rank}-=int($DT->{rank}/4);
		$DTS->{money}+=500000;
		$DTS->{saletoday}+=500000;
		$DT->{money}-=500000;
		$DT->{paytoday}+=500000;
		WriteLog(3,0,$DT->{shopname}."가 ".$DTS->{shopname}."에 도둑질하러 들어왔습니다만 집지키는&nbsp;개에 발견되었습니다.");
		WriteLog(3,0,$DT->{shopname}."는 ".$DTS->{shopname}."에게 배상금 ".GetMoneyString(500000)."(을)를 지불했습니다.");
		WriteLog(0,$DT->{id},$ret);
		return $ret;
	}
	if(rand(1000)>900)
	{
		$DTS->{money}+=500000;
		$DTS->{saletoday}+=500000;
		$DT->{money}-=500000;
		$DT->{paytoday}+=500000;
		$DT->{rank}-=int($DT->{rank}/4);
		WriteLog(3,0,$DT->{shopname}."가 ".$DTS->{shopname}."에 도둑질하러 들어왔습니다만 실패했습니다.");
		WriteLog(3,0,$DT->{shopname}."는 ".$DTS->{shopname}."에게 배상금 ".GetMoneyString(500000)."(을)를 지불했습니다.");
		WriteLog(0,$DT->{id},$ret);
		return $ret;
	}
	$ret="도둑은 성공했습니다";
	my $manbiki_count=0;
	foreach my $idx (0..$DTS->{showcasecount}-1)
	{
		my $itemno=$DTS->{showcase}[$idx];
		if($itemno)
		{
			my $cnt=int($DTS->{item}[$itemno-1]*3/4);
			$cnt=$ITEM[$itemno]->{limit}-$DT->{item}[$itemno-1] if $DT->{item}[$itemno-1]+$cnt>$ITEM[$itemno]->{limit};
			$DTS->{item}[$itemno-1]-=$cnt;
			$DT->{item}[$itemno-1]+=$cnt;
			$manbiki_count+=$cnt*$DTS->{price}[$idx];
		}
	}
	$main::STATE->{safety}=int($main::STATE->{safety} * 18 / 19);
	WriteLog(2,0,$DTS->{shopname}."가 총액 ".GetMoneyString($manbiki_count)." 상당의 도둑 피해를 당했습니다.") if $manbiki_count;
	WriteLog(2,0,$DTS->{shopname}."에 들어간 도둑범은 아무것도 취하지 않고 도망쳤습니다.") if !$manbiki_count;
	WriteLog(0,$DT->{id},$ret);
	return $ret;
}


@@FUNCUPDATE
sub UpdateResetBefore #결산 직전의 처리(함수명 고정)
{
	UpdateTodayPrize();
	
	sub UpdateTodayPrize
	{
		#상품 수여
		my @TOP123=(
			[
				['금단의&nbsp;해피베리',	[[@@ITEMNO "금단의&nbsp;해피베리",1],			],],
				['집지키는&nbsp;개',	[[@@ITEMNO "집지키는&nbsp;개",1],			],],
				['빵',	[[@@ITEMNO "빵",400],			],],
				['럼주',	[[@@ITEMNO "럼주",200],			],],
				['광고&nbsp;팩',	[[@@ITEMNO "광고&nbsp;팩",1],			],],
				['상품권',	[[@@ITEMNO "상품권",5],			],],
				['제비뽑기권',	[[@@ITEMNO "제비뽑기권",5],			],],
			],
			[
				['금단의&nbsp;해피베리',	[[@@ITEMNO "금단의&nbsp;해피베리",1],			],],
				['빵',	[[@@ITEMNO "빵",400],			],],
				['럼주',	[[@@ITEMNO "럼주",200],			],],
				['광고&nbsp;팩',	[[@@ITEMNO "광고&nbsp;팩",1],			],],
				['상품권',	[[@@ITEMNO "상품권",4],			],],
				['제비뽑기권',	[[@@ITEMNO "제비뽑기권",4],			],],
			],
			[
				['직업의&nbsp;비밀',	[[@@ITEMNO "직업의&nbsp;비밀",1],			],],
				['빵',	[[@@ITEMNO "빵",200],			],],
				['럼주',	[[@@ITEMNO "럼주",100],			],],
				['광고&nbsp;팩',	[[@@ITEMNO "광고&nbsp;팩",1],			],],
				['상품권',	[[@@ITEMNO "상품권",3],			],],
				['제비뽑기권',	[[@@ITEMNO "제비뽑기권",3],			],],
			],
			[
				['직업의&nbsp;비밀',	[[@@ITEMNO "직업의&nbsp;비밀",1],			],],
				['빵',	[[@@ITEMNO "빵",100],			],],
				['럼주',	[[@@ITEMNO "럼주",50],			],],
				['상품권',	[[@@ITEMNO "상품권",2],			],],
				['제비뽑기권',	[[@@ITEMNO "제비뽑기권",2],			],],
			],
		);
		
		TopGetItem($DT[0],$TOP123[0],"이번 우승의") if defined($DT[0]);
		TopGetItem($DT[1],$TOP123[1],"아깝게도 2위의") if defined($DT[1]);
		TopGetItem($DT[2],$TOP123[2],"빠듯하게 입상의") if defined($DT[2]);
	
		for(my $i=9; $i<$#DT; $i+=10)
		{
			TopGetItem($DT[$i],$TOP123[3],"특별상으로 해서 ".($i+1)."위의") if defined($DT[$i]);
		}
		
		sub TopGetItem
		{
			my($DT,$itemlist,$head)=@_;
			
			my @list=@{$itemlist};
			my @getitem=@{$list[int(rand($#list+1))]};
			
			my $msg=$head.$DT->{shopname}."씨에게는 ".$getitem[0]."가 주어졌습니다";
			WriteLog(0,0,0,$msg,1);
			foreach (@{$getitem[1]})
			{
				my @itemnocount=@{$_};
				
				my $cnt=AddItem($DT,$itemnocount[0],$itemnocount[1]);
				my $ITEM=$ITEM[$itemnocount[0]];
				WriteLog(0,$DT->{id},0,$head."상품으로서 ".$ITEM->{name}."(을)를 ".$itemnocount[1].$ITEM->{scale}."획득했습니다",1);
				$cnt=$itemnocount[1]-$cnt;
				WriteLog(0,$DT->{id},0,"그러나 최대 소지수이상이었으므로 ".$cnt.$ITEM->{scale}." 파기했습니다",1) if $cnt;
			}
		}
	}
}

sub UpdateResetAfter #결산 직후의 처리(함수명 고정)
{
	foreach my $DT (@DT)
		{
		$DT->{profitstock}=5000000 if ($DT->{profitstock} > 5000000);
		$DT->{profitstock}=-1000000 if ($DT->{profitstock} < -1000000);
		if ($DT->{money} > 50000000)
			{
			$DT->{money} -= int( ($DT->{money} - 20000000)/2 );
			$DT->{rank} += int( (10000 - $DT->{rank})/2 );
			$DT->{rank}=10000 if $DT->{rank}>10000;
			PushLog(2,0,$DT->{shopname}.'에서 축하회가 거행되었습니다.');
			}
		}
	main::RequireFile('inc-atlas.cgi');
}

@@FUNCNEW

# @@DEFINE Set NewShopMoney NewShopTime NewShopItem 의 처리
$DT->{money}=@@VALUE"NewShopMoney" if @@VALUE"NewShopMoney";
$DT->{time}=$NOW_TIME-eval(@@VALUE"NewShopTime") if @@VALUE"NewShopTime";
if(@@VALUE"NewShopItem")
{
	my %item=split /:/,@@VALUE"NewShopItem";
	while(my($key,$val) =each %item)
	{
		foreach my $item (@ITEM)
		{
			 $DT->{item}[$item->{no}-1]+=$val,last if $key eq $item->{code} or $key eq $item->{name};
		}
	}
}

# $DEFINE_FUNCNEW_NOLOG=1 를 설정하면,시스템측의 최근의 사건 새로운 치장 개점 메시지를 억제합니다.
# $DEFINE_FUNCNEW_NOLOG=1;
# WriteLog(1,0,0,$DT->{shopname}."가 엔트리 했습니다",1);

# 그 외,새로운 치장 개점시에 독자적인 처리를 추가할 수 있습니다.

@@FUNCSHOPIN

SetUserDataEx($DT,'_so_move_in',$NOW_TIME); # 이전 시각을 기록
if($DT->{job} eq 'peddle')
{
	# 행상인(peddle)에게는 이전 소비 시간의 것1/2을 반환
	$DT->{_MoveTownTime}=int($DT->{_MoveTownTime}/2);
	EditTime($DT,$DT->{_MoveTownTime});
	WriteLog(0,$DT->{id},0,'이전 시간이 절반인 '.GetTime2HMS($DT->{_MoveTownTime}).'로 끝난 것 같습니다',1);
}
if(GetUserDataEx($DT,'_so_present_money'))
{
	WriteLog(0,$DT->{id},0,'이전원의 거리로부터 전별 금품으로서 '.GetMoneyString(GetUserDataEx($DT,'_so_present_money')).'를 받았습니다',1);
	SetUserDataEx($DT,'_so_present_money','');
}

@@FUNCSHOPOUT

if(GetUserDataEx($DT,'_so_move_in'))
{
	my $present_money=int(($NOW_TIME-GetUserDataEx($DT,'_so_move_in'))/86400)*5000;
	EditMoney($DT,$present_money); # 체재 기간 1일에 부착\5000을 전별 금품으로서 자금에
	SetUserDataEx($DT,'_so_present_money',$present_money);
	SetUserDataEx($DT,'_so_move_in',''); # $DT->{user}{_so_move_in} 를 삭제
}

@@FUNCBUY
# package item 입니다.
# 
# $item::BUY 를 이용할 수 있습니다.$item::BUY 의 구조는 매뉴얼의 @@ITEM funcb 를 봐 주세요.
# 상품 마다의 처리는 @@ITEM funcb 를 이용해 주세요.

if($BUY->{whole})
{
	if (rand(1000) > 990 && $BUY->{num} > 10)
	{
	$count=AddItemSub(@@ITEMNO"상품권",1,$BUY->{dt});
	WriteLog(0,$BUY->{dt}{id},'시장의 추첨으로 상품권을 '.$count.'장 맞았습니다.');
	$main::ret.='<br>추첨으로 상품권을 '.$count.'장 맞았습니다!';
	}
}

@@END #정의 종료 선언(이후 댓글 취급)

