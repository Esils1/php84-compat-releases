# 도크 2004/02/28 유래
# 월드 아틀라스판

Lock() if ($Q{mode});	# 가능한 한 빨리 락.
DataRead();
CheckUserPass();

$disp.=GetMenuTag('dock',	'[제1 선단]')
	.GetMenuTag('dock',	'[제2 선단]','&plus=1')
	.GetMenuTag('dock',	'[제3 선단]','&plus=2')
	.GetMenuTag('dock',	'[제4 선단]','&plus=3');
$disp.="<hr width=500 noshade size=1>";
$disp.="<BIG>●도크</BIG><br><br>";

my %itemnum=qw(explore 26 trader 30 pirate 34 pros 34);
if (!$itemnum{$DT->{job}})
	{
	$disp.="도크를 이용하려면, 관계된 직업에 종사할 필요가 있습니다.";
	OutSkin();
	exit;
	}
$Q{ship}=($itemnum{$DT->{job}}+$Q{plus});
my @AREA=("","유럽","아프리카","중동","인도","아시아","신대륙");
$disp.=GetTagImgItemType($Q{ship}).$ITEM[$Q{ship}]->{name}."<br><br>";

undef @subdata;
@subdata=ReadShipSub($DT->{id}."-abi".$Q{ship});
RequireFile('inc-dock.cgi') if ($Q{mode});

$disp.="$TB$TR$TDB 편성<td colspan=6>";
foreach(0..4)
	{
	next if !$subdata[$_];
	$disp.=GetTagImgItemType($subdata[$_]);
	$DT->{item}[$subdata[$_]-1]++;
	}
$disp.="$TRE$TR$TDB 해역 적성";
foreach(0..5)
	{
	$disp.="$TD<SPAN>".$AREA[$_+1]."</SPAN>：".($subdata[$_+5] + 0)." %";
	}
$disp.="$TRE$TR$TDB 파견 조건";
$disp.="<td colspan=2>".GetTagImgItemType(18)."<SPAN>빵</SPAN>：".($subdata[11] + 0)."식";
$disp.="<td colspan=2>".GetTagImgItemType(19)."<SPAN>럼주</SPAN>：".($subdata[12] + 0)."잔";
$disp.="<td colspan=2>".GetTagImgItemType(20)."<SPAN>선원</SPAN>：".($subdata[13] + 0)."인";
$disp.=$TRE.$TBE;

$disp.="<hr width=500 noshade size=1>";
$disp.="<BIG>●선단의 편성</BIG><br><br>";

my $shipform;
foreach my $num(5..11)
	{
	my $amt=$DT->{item}[$num-1];
	next if !$amt;
	$amt=5 if $amt > 5;
	$shipform.=$TR;
	$shipform.=$TD.GetTagImgItemType($num).$ITEM[$num]->{name}.$TD;
	foreach my $cnt(1..$amt)
		{
		$shipform.='<input type=checkbox name="'.$num.'_'.$cnt.'" value="1"> ';
		}
	$shipform.=$TRE;
	}

if (!$shipform)
	{
	$disp.="배를 가지고 있지 않기 때문에,선단을 편성할 수 없습니다.";
	}
	else
	{
$disp.=<<STR;
<FORM ACTION="action.cgi" $METHOD>
$MYFORM$USERPASSFORM
<INPUT TYPE=HIDDEN NAME=plus VALUE="$Q{plus}">
<INPUT TYPE=HIDDEN NAME=mode VALUE="make">
$TB
$shipform
$TR<td colspan=2>최대 5개까지 선택할 수 있습니다.<br>
아무것도 선택하지 않으면 선단을 해체합니다.$TRE
$TBE
<br><INPUT TYPE=SUBMIT VALUE="선단을 편성한다">
</FORM>
STR
	}

OutSkin();
1;


sub ReadShipSub
{
	my($file)=@_;
	my $filename=GetPath($SUBDATA_DIR,$file);
	open(IN,$filename) or return;
	read(IN,my $buf,-s $filename);
	close(IN);
	my @buf=split(',',$buf);
	return @buf;
}


