# 스탭 롤 2005/03/30 유래
# 월드 아틀라스판
#
# 각종 저작권 표시용입니다.새로운 소재·프로그램을 짜넣을 때에,여기에 추가합시다.
# HTML의 지식이 있으면,눈동냥으로 완성된다고 생각합니다.
#
# 스탭 롤에의 링크를 제외하거나 눈에 띄고없이는 안됩니다.
# 저작권 표시는 눈에 띄도록(듯이) 적절히 실시할 필요가 있어,이것을 게을리하면 법적 문제가 되는 경우가 있습니다.

DataRead();
CheckUserPass(1);
OutError("비밀번호 누락의 위험이 있으므로 표시 중지합니다.") if $Q{u};
$disp.="<BIG>●개발 스탭 롤</BIG><br><br>";
$disp.=$TB.$TR.$TD.GetTagImgKao("안내인","guide").$TD;
$disp.='게임의 각 부분에 대한 저작권은, 각각 아래와 같은 분들에게 귀속합니다.<br>';
$disp.='덧붙여 소재를 게임으로부터 직접 꺼내 이용하지 말아 주세요.'.$TRE.$TBE;
$disp.="<br>".$TBT.$TRT.$TD;

# ----------- 여기에서 아래를 여러 가지 고쳐 쓴다.-----------------------------

$disp.=<<"HTML";
<SPAN>제작·저작</SPAN> ： 유래 ...<A HREF="http://akimono.org/" target="_blank">상인 이야기</A> 
<br><br>
<SPAN>원작</SPAN> ： MU 님 ...<A HREF="http://mutoys.com/" target="_blank">MUTOYS</A> 
<br><br>
<SPAN>아이콘(아이템)</SPAN> ： 개님 ...<A HREF="http://www.momo.dyndns.org/~sweetpunch/" target="_blank">Sweet Punch</A> 
<br><br>
<SPAN>아이콘(작업·도구)</SPAN> ： 해 두님 ...<A HREF="http://www2.holon.dyndns.org/~musou/" target="_blank">벽지의 집 해않고 치</A> 
<br><br>
<SPAN>아이콘(종류·전문점)</SPAN> ： YOU 님 ...<A HREF="http://foryou.cside.com/" target="_blank">Net-you`s Homepage</A> 
<br><br>
<SPAN>아이콘(추가)</SPAN> ： 님·아슈님
<br><br>
<SPAN>맵·캐릭터</SPAN> ： REFMAP 님 ...<A HREF="http://www.mogunet.net/~fsm/" target="_blank">FIRST SEED MATERIAL</A> 
<br><br>
<SPAN>음악</SPAN> ： 다몽님 ...<A HREF="http://www.tam-music.com/" target="_blank">TAM Music Factory</A> 
<SPAN>번역</SPAN> : 소모키 ...<a href="http://somokey.mireene.com" target=_blank>소모키의 집</a>
HTML

# ----------- 여기까지.마지막 「HTML」를 지우지 않게 주의.-----------------

require "skin.pl" if -e "skin.pl";
$disp.=$TRE.$TBE;
OutSkin();
1;
