e9T4o
03/13 19:20	221.6.76.145	Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)	image/gif, image/x-xbitmap, image/jpeg, image/pjpeg, application/x-shockwave-flash, application/vnd.ms-excel, application/vnd.ms-powerpoint, application/msword, */*
