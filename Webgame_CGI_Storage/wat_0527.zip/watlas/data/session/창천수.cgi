c0XDQ
07/22 21:50	115.161.12.52	Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1)	image/gif, image/x-xbitmap, image/jpeg, image/pjpeg, application/vnd.ms-powerpoint, application/vnd.ms-excel, application/msword, application/x-shockwave-flash, */*
