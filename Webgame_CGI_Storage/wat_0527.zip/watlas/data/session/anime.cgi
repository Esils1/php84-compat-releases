KjFiE
03/31 20:52	58.239.227.136	Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1)	image/gif, image/x-xbitmap, image/jpeg, image/pjpeg, application/vnd.ms-powerpoint, application/vnd.ms-excel, application/msword, */*
03/29 01:37	58.239.227.48	Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1)	image/gif, image/x-xbitmap, image/jpeg, image/pjpeg, application/vnd.ms-powerpoint, application/vnd.ms-excel, application/msword, */*
03/27 09:59	58.239.227.48	Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1)	*/*
02/28 01:14	58.239.227.15	Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1)	image/gif, image/x-xbitmap, image/jpeg, image/pjpeg, application/vnd.ms-powerpoint, application/vnd.ms-excel, application/msword, */*
02/22 16:16	58.239.227.15	Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1)	*/*
02/21 00:48	58.239.227.7	Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1)	image/gif, image/x-xbitmap, image/jpeg, image/pjpeg, application/vnd.ms-powerpoint, application/vnd.ms-excel, application/msword, */*
02/17 01:25	58.239.227.86	Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1)	image/gif, image/x-xbitmap, image/jpeg, image/pjpeg, application/vnd.ms-powerpoint, application/vnd.ms-excel, application/msword, */*
