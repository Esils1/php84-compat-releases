txupM
04/18 13:34	221.160.154.68	Mozilla/5.0 (Windows; U; Windows NT 6.0; ko; rv:1.9.2.3) Gecko/20100401 Firefox/3.6.3 (.NET CLR 3.5.30729)	text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
