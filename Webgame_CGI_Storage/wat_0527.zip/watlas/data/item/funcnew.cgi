 $DT->{money}='200000'if  '200000'; $DT->{time}=$NOW_TIME-eval('14*60*60')  if  '14*60*60'; if('진열장&nbsp;증축취괴킷:1:상품권:10') { my  %item=split  /:/,'진열장&nbsp;증축취괴킷:1:상품권:10'; while(my($key,$val)  =each  %item) { foreach  my  $item  (@ITEM) { $DT->{item}[$item->{no}-1]+=$val,last  if  $key  eq  $item->{code}  or  $key  eq  $item->{name}; } } } 
1;
