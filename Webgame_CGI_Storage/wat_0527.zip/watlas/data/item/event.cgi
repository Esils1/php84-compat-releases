foreach(
'happy	1	100					18000	18000	감사제가  이  거리에서  시작되었습니다.	감사제는  막을  닫았습니다.	_local_now	',
'message	2	1500	_local_start				0	0				',
'rebel	3	0									_local_now	',
'guildbattle	4	0			_local_end							',
)
{
	my $hash={};
	(
		$hash->{code},
		$hash->{group},
		$hash->{startproba},
		$hash->{startfunc},
		$hash->{startfuncparam},
		$hash->{endfunc},
		$hash->{endfuncparam},
		$hash->{basetime},
		$hash->{plustime},
		$hash->{startmsg},
		$hash->{endmsg},
		$hash->{func},
		$hash->{funcparam},
	) =split(/\t/);
	$EVENT{$hash->{code}}=$hash;
}
1;
