 $TIME_SEND_ITEM=int($TIME_SEND_ITEM/2)  if  $DT->{job}  eq  'explore'; 
1;
