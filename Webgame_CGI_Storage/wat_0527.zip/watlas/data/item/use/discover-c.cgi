package item;
$USE[0]={'code'=>'discover-c','no'=>0,'itemno'=>'41','name'=>'왕국에  신고한다','info'=>'발견물을  왕국에  신고합니다','scale'=>'회','action'=>'신고한다','money'=>0,'time'=>3600,'exptime'=>'3600','arg'=>'nocount','param1'=>'3','use'=>[{'no'=>41,'count'=>1,'proba'=>1000},],'result'=>{'function'=>'disc',},};

1;
