package item;
$USE[0]={'code'=>'town-b','no'=>0,'itemno'=>'46','name'=>'상관을  건설한다','info'=>'도시를  명명해  무역을  할  수  있도록  합니다','scale'=>'회','action'=>'라고  이름  붙여  건설','money'=>0,'time'=>3600,'exptime'=>'3600','arg'=>'nocount|message18','argmessage'=>'도시의&nbsp;이름','param1'=>'2','use'=>[{'no'=>46,'count'=>1,'proba'=>1000},],'result'=>{'function'=>'newtown',},};

1;
