package item;
$USE[0]={'code'=>'cm','no'=>0,'itemno'=>'3','name'=>'자점의  광고를  낸다','info'=>'자신의  가게의  인기를  거론합니다','scale'=>'회','action'=>'광고  한다','money'=>0,'time'=>18000,'exptime'=>'18000','exp'=>'100','arg'=>'nocount','use'=>[{'no'=>3,'count'=>1,'proba'=>1000},],'result'=>{'function'=>'_local_1',},};
sub _local_1 {eval(<<'_eval_code_');
my  $up=int(500*(2-$DT->{rank}/5000));if  (  rand(1000)<250  )  {$DT->{rank}-=$up;$DT->{rank}=1000  if  $DT->{rank}<1000;my  $ret="광고는  화근이  되어  버렸습니다：인기  ".int($up/100)."%다운";WriteLog(0,$DT->{id},$ret);WriteLog(3,0,$DT->{shopname}."가  광고를  냈습니다만  오히려  역효과였습니다.");return  $ret;}$DT->{rank}+=$up;$DT->{rank}=10000  if  $DT->{rank}>10000;my  $ret="광고를  냈습니다：인기  ".int($up/100)."%업";WriteLog(0,$DT->{id},$ret);WriteLog(3,0,$DT->{shopname}."가  광고를  냈습니다.");return  $ret;
_eval_code_
}
$USE[1]={'code'=>'cm','no'=>1,'itemno'=>'3','name'=>'다른  상점의  광고를  낸다','info'=>'다른  상점의  인기를  거론합니다','scale'=>'회','action'=>'광고  한다','money'=>0,'time'=>18000,'exptime'=>'18000','arg'=>'target|nocount','use'=>[{'no'=>3,'count'=>1,'proba'=>1000},],'result'=>{'function'=>'_local_2',},};
sub _local_2 {eval(<<'_eval_code_');
return  '자점을  지정할  수  없습니다'  if  ($DT==$DTS);my  $up=int(500*(2-$DTS->{rank}/5000));$DTS->{rank}+=$up;$DTS->{rank}=10000  if  $DTS->{rank}>10000;my  $ret="광고를  냈습니다：".$DTS->{shopname}."의  인기  ".int($up/100)."%업";WriteLog(0,$DT->{id},$ret);WriteLog(3,0,$DT->{shopname}."가  ".$DTS->{shopname}."의  광고를  냈습니다.");return  $ret;
_eval_code_
}
$USE[2]={'code'=>'cm','no'=>2,'itemno'=>'3','name'=>'길드의  광고를  낸다','info'=>'동길드  소속점  모든  인기를  거론됩니다','scale'=>'회','action'=>'광고  한다','money'=>0,'time'=>28800,'exptime'=>'28800','arg'=>'nocount','use'=>[{'no'=>3,'count'=>1,'proba'=>1000},],'result'=>{'function'=>'_local_3',},};
sub _local_3 {eval(<<'_eval_code_');
return  '길드에  들어가  있지  않기  때문에  광고를  낼  수  없었습니다'  if  !$DT->{guild};WriteLog(3,0,$DT->{shopname}."가  길드  「".$main::GUILD{$DT->{guild}}->[$GUILDIDX_name]."」의  광고를  냈습니다.");foreach  my  $DTS  (@DT){next  if  ($DTS->{guild}  ne  $DT->{guild});my  $up=int(500*(2-$DTS->{rank}/5000));$DTS->{rank}+=$up;$DTS->{rank}=10000  if  $DTS->{rank}>10000;my  $ret="길드  광고를  냈습니다：".$DTS->{shopname}."의  인기  ".int($up/100)."%업";WriteLog(0,$DT->{id},$ret);}return  '길드  광고를  냈습니다';
_eval_code_
}

1;
