package item;
$USE[0]={'code'=>'badgossip','no'=>0,'itemno'=>'88','name'=>'로니레이크의  방해공작','info'=>'성공하면  상대의  가게의  인기를  내릴  수  있습니다만실패할  수도…','scale'=>'회','action'=>'건다','money'=>0,'time'=>18000,'exptime'=>'14400','exp'=>'200','arg'=>'target|nocount','needpoint'=>'20000','result'=>{'function'=>'_local_1',},};
sub _local_1 {eval(<<'_eval_code_');
my  $ret;if(rand(1000)<800  &&  !$DTS->{exp}{3}){$DTS->{rank}-=int($DTS->{rank}/3);$ret=$DTS->{shopname}.'의  나쁜  소문을  흘리는  작전이  성공했습니다';WriteLog(0,$DT->{id},$ret);WriteLog(2,0,$DTS->{shopname}.'의  나쁜  소문이  퍼져  인기가  내렸습니다.');}else{$DTS->{exp}{3}-=100;$DTS->{exp}{3}=0  if  ($DTS->{exp}{3}  <  0);$DT->{rank}-=int($DT->{rank}/4);$ret=$DTS->{shopname}.'의  나쁜  소문을  흘리는  작전은  실패했습니다';WriteLog(0,$DT->{id},$ret);WriteLog(3,0,$DT->{shopname}."가  ".$DTS->{shopname}.'의  나쁜  소문을  걸려고  했던  것  같습니다.');}return  $ret;
_eval_code_
}
$USE[1]={'code'=>'badgossip','no'=>1,'itemno'=>'88','name'=>'케이시니아의  도둑질','info'=>'거기까지  몰렸다면어쩔  수  없다…','scale'=>'회','action'=>'도둑한다','money'=>50000,'time'=>18000,'exptime'=>'14400','exp'=>'250','arg'=>'target|nocount','needpoint'=>'20000','result'=>{'function'=>'stole',},};

1;
