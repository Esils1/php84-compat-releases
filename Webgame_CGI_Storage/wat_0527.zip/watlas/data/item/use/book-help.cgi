package item;
$USE[0]={'code'=>'book-help','no'=>0,'itemno'=>'22','name'=>'어느  직업이  기회인가를  알고  싶다','info'=>'지금  부족한  직업을  한눈에  알  수  있습니다','scale'=>'회','action'=>'확인한다','money'=>0,'time'=>600,'exptime'=>'600','arg'=>'nocount','result'=>{'function'=>'jobwant',},};
$USE[1]={'code'=>'book-help','no'=>1,'itemno'=>'22','name'=>'빵이  시장에  나와  있지  않아서  살  수  없다','info'=>'빵을  특별  루트로  매입합니다(10  상자  단위)','scale'=>'회','action'=>'매입한다','money'=>1200,'time'=>1200,'exptime'=>'1200','result'=>{'message'=>{'resultok'=>'빵을  조달했습니다',},'create'=>[{'no'=>18,'count'=>10,'proba'=>1000},],},};
$USE[2]={'code'=>'book-help','no'=>2,'itemno'=>'22','name'=>'럼주가  시장에  나와  있지  않아서  살  수  없다','info'=>'럼주를  특별  루트로  매입합니다(10병  단위)','scale'=>'회','action'=>'매입한다','money'=>2400,'time'=>1200,'exptime'=>'1200','result'=>{'message'=>{'resultok'=>'럼주를  조달했습니다',},'create'=>[{'no'=>19,'count'=>10,'proba'=>1000},],},};
$USE[3]={'code'=>'book-help','no'=>3,'itemno'=>'22','name'=>'선원이  시장에  나와  있지  않아서  고용할  수  없다','info'=>'선원을  특별  루트로  고용합니다(10명  단위)','scale'=>'회','action'=>'고용한다','money'=>15000,'time'=>1200,'exptime'=>'1200','result'=>{'message'=>{'resultok'=>'선원을  고용했습니다',},'create'=>[{'no'=>20,'count'=>10,'proba'=>1000},],},};
$USE[4]={'code'=>'book-help','no'=>4,'itemno'=>'22','name'=>'금화가  팔리지  않고  대량으로  남아  버렸다','info'=>'금화를  특별  루트로  팔아  치웁니다','scale'=>'회','action'=>'팔아  치운다','money'=>0,'time'=>300,'exptime'=>'300','use'=>[{'no'=>51,'count'=>1,'proba'=>1000},],'result'=>{'function'=>'_local_5','message'=>{'resultok'=>'금화를  팔아  치웠습니다',},},};
sub _local_5 {eval(<<'_eval_code_');
$DT->{money}+=8000  *  $count;return  "환금액：".GetMoneyString(8000  *  $count);
_eval_code_
}
$USE[5]={'code'=>'book-help','no'=>5,'itemno'=>'22','name'=>'자금부족으로  곤란해  하고  있다','info'=>'일용  토목  작업으로  금화를  법시다','scale'=>'회','action'=>'일한다','money'=>0,'time'=>14400,'exptime'=>'14400','result'=>{'message'=>{'resultok'=>'열심히  일해  금화를  받았습니다',},'create'=>[{'no'=>51,'count'=>2,'proba'=>1000},],},};

1;
