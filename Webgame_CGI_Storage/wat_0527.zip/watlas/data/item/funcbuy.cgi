package item;
 if($BUY->{whole}) { if  (rand(1000)  >  990  &&  $BUY->{num}  >  10) { $count=AddItemSub(24,1,$BUY->{dt}); WriteLog(0,$BUY->{dt}{id},'시장의  추첨으로  상품권을  '.$count.'장  맞았습니다.'); $main::ret.='<br>추첨으로  상품권을  '.$count.'장  맞았습니다!'; } } 
1;
