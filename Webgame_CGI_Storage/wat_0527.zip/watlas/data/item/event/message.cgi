push(@EVENTMSG,'메시지');
1;
