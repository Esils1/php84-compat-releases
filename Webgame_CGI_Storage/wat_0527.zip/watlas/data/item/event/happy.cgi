push(@EVENTMSG,'감사제로  거리는  떠들썩합니다.');
1;
