world	out	0	in	0	def	6	atk	10	money	17911062
