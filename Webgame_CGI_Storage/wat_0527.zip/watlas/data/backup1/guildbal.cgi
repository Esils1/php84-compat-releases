world	out	0	def	6	in	0	atk	10	money	17911062
