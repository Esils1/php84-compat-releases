1235410713	/Modgames/kogame/watlas/watlas/action.cgi	59.20.121.13		59.20.121.13		ip file read error 
1235410972	/Modgames/kogame/watlas/watlas/action.cgi	59.20.121.13		59.20.121.13		write mode open error
1235410977	/Modgames/kogame/watlas/watlas/action.cgi	59.20.121.13		59.20.121.13		write mode open error
1235410989	/Modgames/kogame/watlas/watlas/action.cgi	59.20.121.13		59.20.121.13		write mode open error
1235531751	/Modgames/kogame/watlas/watlas/action.cgi	116.126.36.103		116.126.36.103		write mode open error
1235917206	/Modgames/kogame/watlas/watlas/action.cgi	116.126.36.103		116.126.36.103		write mode open error
1236092174	/Modgames/kogame/watlas/watlas/action.cgi	122.42.196.96		122.42.196.96		write mode open error
1236171957	/Modgames/kogame/watlas/watlas/action.cgi	116.126.36.103		116.126.36.103		write mode open error
1236446077	/Modgames/kogame/watlas/watlas/action.cgi	59.20.121.13		59.20.121.13		write mode open error
1236823629	/Modgames/kogame/watlas/watlas/action.cgi	59.20.121.13		59.20.121.13		write mode open error
1236849962	/Modgames/kogame/watlas/watlas/action.cgi	211.63.139.26		211.63.139.26		write mode open error
1236850189	/Modgames/kogame/watlas/watlas/action.cgi	211.63.139.26		211.63.139.26		write mode open error
1236930301	/Modgames/kogame/watlas/watlas/action.cgi	211.193.35.101		211.193.35.101		write mode open error
1238121113	/Modgames/kogame/watlas/watlas/action.cgi	59.20.121.13		59.20.121.13		write mode open error
1238151363	/Modgames/kogame/watlas/watlas/action.cgi	211.219.105.111		211.219.105.111		write mode open error
1238324171	/Modgames/kogame/watlas/watlas/action.cgi	220.91.34.254		220.91.34.254		write mode open error
1238324176	/Modgames/kogame/watlas/watlas/action.cgi	220.91.34.254		220.91.34.254		write mode open error
1238416499	/Modgames/kogame/watlas/watlas/action.cgi	116.126.36.103		116.126.36.103		write mode open error
1238659191	/Modgames/kogame/watlas/watlas/action.cgi	121.168.115.178		121.168.115.178		write mode open error
1238670539	/Modgames/kogame/watlas/watlas/action.cgi	121.168.115.178		121.168.115.178		write mode open error
1239039701	/Modgames/kogame/watlas/watlas/action.cgi	121.168.115.178		121.168.115.178	disaster	write mode open error
1239039876	/Modgames/kogame/watlas/watlas/action.cgi	121.168.115.178		121.168.115.178	disaster	write mode open error
1239039886	/Modgames/kogame/watlas/watlas/action.cgi	121.168.115.178		121.168.115.178	disaster	write mode open error
1239039989	/Modgames/kogame/watlas/watlas/action.cgi	121.168.115.178		121.168.115.178	disaster	write mode open error
1239116721	/Modgames/kogame/watlas/watlas/action.cgi	121.168.115.178		121.168.115.178		write mode open error
1239642482	/Modgames/kogame/watlas/watlas/action.cgi	121.168.115.178		121.168.115.178		write mode open error
1239960039	/Modgames/kogame/watlas/watlas/action.cgi	121.168.115.178		121.168.115.178		write mode open error
1240311599	/Modgames/kogame/watlas/watlas/action.cgi	211.54.73.177		211.54.73.177		write mode open error
1241004523	/Modgames/kogame/watlas/watlas/action.cgi	121.168.115.178		121.168.115.178	disaster	write mode open error
1241080077	/Modgames/kogame/watlas/watlas/action.cgi	211.54.71.186		211.54.71.186		write mode open error
1241080089	/Modgames/kogame/watlas/watlas/action.cgi	211.54.71.186		211.54.71.186		write mode open error
1241504530	/Modgames/kogame/watlas/watlas/action.cgi	211.219.105.163		211.219.105.163		write mode open error
1244722944	/Modgames/kogame/watlas/watlas/action.cgi	121.254.193.225		121.254.193.225		write mode open error
1245001624	/Modgames/kogame/watlas/watlas/action.cgi	121.254.193.226		121.254.193.226		write mode open error
1246288928	/Modgames/kogame/watlas/watlas/action.cgi	66.249.67.10		googlebot(at)googlebot.com!66.249.67.10		write mode open error
1247464581	/Modgames/kogame/watlas/watlas/action.cgi	211.233.79.168		211.233.79.168		write mode open error
1248351850	/watlas/watlas/action.cgi	66.249.67.234		googlebot(at)googlebot.com!66.249.67.234		write mode open error
1249286243	/watlas/watlas/action.cgi	64.191.50.64		64.191.50.64		write mode open error
1249599354	/watlas/watlas/action.cgi	72.22.64.193		72.22.64.193		write mode open error
1249957349	/watlas/watlas/action.cgi	66.249.67.240		googlebot(at)googlebot.com!66.249.67.240		write mode open error
1250729526	/watlas/watlas/action.cgi	66.249.67.240		googlebot(at)googlebot.com!66.249.67.240		write mode open error
1251598510	/watlas/watlas/action.cgi	118.223.208.154		118.223.208.154		write mode open error
1251825947	/watlas/watlas/action.cgi	66.249.65.151		googlebot(at)googlebot.com!66.249.65.151		write mode open error
1252005283	/watlas/watlas/action.cgi	74.6.22.182		74.6.22.182		write mode open error
1252610690	/watlas/watlas/action.cgi	74.6.22.168		74.6.22.168		write mode open error
1252710253	/watlas/watlas/action.cgi	66.249.67.205		googlebot(at)googlebot.com!66.249.67.205		write mode open error
1253279968	/watlas/watlas/action.cgi	72.30.142.161		72.30.142.161		write mode open error
1253360099	/watlas/watlas/action.cgi	222.107.187.163		222.107.187.163		write mode open error
1253603756	/watlas/watlas/action.cgi	58.29.136.106		58.29.136.106		write mode open error
1253604015	/watlas/watlas/action.cgi	58.29.136.106		58.29.136.106		write mode open error
1254009678	/watlas/watlas/action.cgi	72.30.65.60		72.30.65.60		write mode open error
1254140334	/watlas/watlas/action.cgi	121.175.133.123		121.175.133.123		write mode open error
1254443672	/watlas/watlas/action.cgi	222.107.187.163		222.107.187.163		write mode open error
1254505597	/watlas/watlas/action.cgi	66.249.67.228		googlebot(at)googlebot.com!66.249.67.228		write mode open error
1254548828	/watlas/watlas/action.cgi	194.8.75.214		194.8.75.214		write mode open error
1254704184	/watlas/watlas/action.cgi	222.107.187.163		222.107.187.163		write mode open error
1254813880	/watlas/watlas/action.cgi	58.29.136.106		58.29.136.106		write mode open error
1254814674	/watlas/watlas/action.cgi	58.29.136.106		58.29.136.106	Cuma	write mode open error
1254821418	/watlas/watlas/action.cgi	58.29.136.106		58.29.136.106		write mode open error
1254880333	/watlas/watlas/action.cgi	91.214.46.18		91.214.46.18		write mode open error
1254897465	/watlas/watlas/action.cgi	194.8.75.251		194.8.75.251		write mode open error
1255088312	/watlas/watlas/action.cgi	222.107.187.163		222.107.187.163		write mode open error
1255347175	/watlas/watlas/action.cgi	58.29.136.106		58.29.136.106		write mode open error
1256965674	/watlas/watlas/action.cgi	66.249.67.246		googlebot(at)googlebot.com!66.249.67.246		write mode open error
1257344849	/watlas/watlas/action.cgi	67.195.115.58		67.195.115.58		write mode open error
1257399790	/watlas/watlas/action.cgi	125.241.203.253		125.241.203.253		write mode open error
1257429083	/watlas/watlas/action.cgi	116.126.110.138		116.126.110.138		write mode open error
1257429084	/watlas/watlas/action.cgi	116.126.110.138		116.126.110.138		write mode open error
1257482761	/watlas/watlas/action.cgi	112.145.234.20		112.145.234.20		write mode open error
1257488530	/watlas/watlas/action.cgi	112.145.234.20		112.145.234.20		write mode open error
1257496147	/watlas/watlas/action.cgi	112.145.234.20		112.145.234.20		write mode open error
1257496726	/watlas/watlas/action.cgi	58.141.110.177		58.141.110.177		write mode open error
1257502879	/watlas/watlas/action.cgi	112.145.234.20		112.145.234.20		write mode open error
1257603190	/watlas/watlas/action.cgi	116.43.99.90		116.43.99.90		write mode open error
1257606503	/watlas/watlas/action.cgi	112.145.234.20		112.145.234.20		write mode open error
1257624046	/watlas/watlas/action.cgi	112.145.234.20		112.145.234.20		write mode open error
1257738023	/watlas/watlas/action.cgi	58.141.101.250		58.141.101.250		write mode open error
1257836577	/watlas/watlas/action.cgi	58.141.101.250		58.141.101.250		write mode open error
1257879485	/watlas/watlas/action.cgi	61.111.151.83		61.111.151.83		write mode open error
1257879869	/watlas/watlas/action.cgi	61.111.151.83		61.111.151.83		write mode open error
1257912213	/watlas/watlas/action.cgi	112.145.234.20		112.145.234.20		write mode open error
1257940676	/watlas/watlas/action.cgi	211.169.32.60		211.169.32.60		write mode open error
1258185385	/watlas/watlas/action.cgi	112.145.234.20		112.145.234.20		write mode open error
1258193054	/watlas/watlas/action.cgi	211.208.205.91		211.208.205.91		write mode open error
1258203550	/watlas/watlas/action.cgi	210.94.41.89		210.94.41.89		write mode open error
1258203551	/watlas/watlas/action.cgi	210.94.41.89		210.94.41.89		write mode open error
1258275362	/watlas/watlas/action.cgi	116.43.99.90		116.43.99.90		write mode open error
1258424822	/watlas/watlas/action.cgi	121.158.238.191		121.158.238.191	soldoutadmin	write mode open error
1258590002	/watlas/watlas/action.cgi	212.117.183.125		212.117.183.125		write mode open error
1258654392	/watlas/watlas/action.cgi	116.126.110.138		116.126.110.138		write mode open error
1258723922	/watlas/watlas/action.cgi	116.126.110.138		116.126.110.138		write mode open error
1258787845	/watlas/watlas/action.cgi	116.126.110.138		116.126.110.138		write mode open error
1258850127	/watlas/watlas/action.cgi	112.145.234.20		112.145.234.20		write mode open error
1258901788	/watlas/watlas/action.cgi	112.145.234.20		112.145.234.20		write mode open error
1258907973	/watlas/watlas/action.cgi	116.126.110.138		116.126.110.138		write mode open error
1258908130	/watlas/watlas/action.cgi	116.126.110.138		116.126.110.138		write mode open error
1258908317	/watlas/watlas/action.cgi	116.126.110.138		116.126.110.138	대륙 상인	write mode open error
1258908347	/watlas/watlas/action.cgi	116.126.110.138		116.126.110.138	대륙 상인	write mode open error
1258908379	/watlas/watlas/action.cgi	116.126.110.138		116.126.110.138	대륙 상인	write mode open error
1258908476	/watlas/watlas/action.cgi	116.126.110.138		116.126.110.138		write mode open error
1258960504	/watlas/watlas/action.cgi	220.124.228.44		220.124.228.44		write mode open error
1258960723	/watlas/watlas/action.cgi	220.124.228.44		220.124.228.44		write mode open error
1258966246	/watlas/watlas/action.cgi	58.141.100.126		58.141.100.126		write mode open error
1258966255	/watlas/watlas/action.cgi	58.141.100.126		58.141.100.126		write mode open error
1259034683	/watlas/watlas/action.cgi	58.141.100.126		58.141.100.126		write mode open error
1259034693	/watlas/watlas/action.cgi	58.141.100.126		58.141.100.126		write mode open error
1259046306	/watlas/watlas/action.cgi	112.145.234.20		112.145.234.20		write mode open error
1259051745	/watlas/watlas/action.cgi	220.124.228.44		220.124.228.44		write mode open error
1259069683	/watlas/watlas/action.cgi	220.124.228.44		220.124.228.44		write mode open error
1259070836	/watlas/watlas/action.cgi	112.145.234.20		112.145.234.20		write mode open error
1259156416	/watlas/watlas/action.cgi	116.126.110.138		116.126.110.138		write mode open error
1259212927	/watlas/watlas/action.cgi	112.145.234.20		112.145.234.20		write mode open error
1259219709	/watlas/watlas/action.cgi	110.35.228.222		110.35.228.222		write mode open error
1259219714	/watlas/watlas/action.cgi	110.35.228.222		110.35.228.222		write mode open error
1259219806	/watlas/watlas/action.cgi	110.35.228.222		110.35.228.222		write mode open error
1259246627	/watlas/watlas/action.cgi	220.124.228.44		220.124.228.44		write mode open error
1259251943	/watlas/watlas/action.cgi	116.126.110.138		116.126.110.138		write mode open error
1259323871	/watlas/watlas/action.cgi	220.255.7.243		220.255.235.60!220.255.7.243		write mode open error
1259329941	/watlas/watlas/action.cgi	116.126.110.138		116.126.110.138		write mode open error
1259366075	/watlas/watlas/action.cgi	110.35.228.222		110.35.228.222		write mode open error
1259378877	/watlas/watlas/action.cgi	220.255.7.146		220.255.235.60!220.255.7.146		write mode open error
1259760375	/watlas/watlas/action.cgi	121.189.97.183		121.189.97.183		write mode open error
1259990235	/watlas/watlas/action.cgi	122.40.96.163		122.40.96.163	스자크	write mode open error
1259990599	/watlas/watlas/action.cgi	122.40.96.163		122.40.96.163		write mode open error
1259991628	/watlas/watlas/action.cgi	122.40.96.163		122.40.96.163		write mode open error
1259991648	/watlas/watlas/action.cgi	122.40.96.163		122.40.96.163		write mode open error
1259991664	/watlas/watlas/action.cgi	122.40.96.163		122.40.96.163		write mode open error
1259995885	/watlas/watlas/action.cgi	121.152.17.40		121.152.17.40	인인	write mode open error
1259995932	/watlas/watlas/action.cgi	121.152.17.40		121.152.17.40	인인	write mode open error
1259998002	/watlas/watlas/action.cgi	122.40.96.163		122.40.96.163		write mode open error
1260074788	/watlas/watlas/action.cgi	121.189.97.183		121.189.97.183		write mode open error
1260111778	/watlas/watlas/action.cgi	112.145.234.20		112.145.234.20		write mode open error
1260116604	/watlas/watlas/action.cgi	122.40.96.163		122.40.96.163		write mode open error
1260177133	/watlas/watlas/action.cgi	110.12.36.187		110.12.36.187		write mode open error
1260177147	/watlas/watlas/action.cgi	110.12.36.187		110.12.36.187		write mode open error
1260198382	/watlas/watlas/action.cgi	116.126.110.138		116.126.110.138	대륙 상인	write mode open error
1260236230	/watlas/watlas/action.cgi	125.241.203.253		125.241.203.253	대륙 상인	write mode open error
1260240035	/watlas/watlas/action.cgi	58.141.103.226		58.141.103.226		write mode open error
1260285402	/watlas/watlas/action.cgi	112.145.234.20		112.145.234.20		write mode open error
1260285518	/watlas/watlas/action.cgi	112.145.234.20		112.145.234.20		write mode open error
1260323273	/watlas/watlas/action.cgi	112.145.234.20		112.145.234.20	꿈속여행	write mode open error
1260330763	/watlas/watlas/action.cgi	67.195.115.242		67.195.115.242		write mode open error
1260339128	/watlas/watlas/action.cgi	112.145.234.20		112.145.234.20		write mode open error
1260353486	/watlas/watlas/action.cgi	116.126.110.138		116.126.110.138	대륙 상인	write mode open error
1260353492	/watlas/watlas/action.cgi	116.126.110.138		116.126.110.138		write mode open error
1260359102	/watlas/watlas/action.cgi	122.40.96.163		122.40.96.163	스자크	write mode open error
1260359666	/watlas/watlas/action.cgi	116.126.110.138		116.126.110.138		write mode open error
1260417519	/watlas/watlas/action.cgi	58.141.103.226		58.141.103.226		write mode open error
1260438584	/watlas/watlas/action.cgi	116.126.110.138		116.126.110.138	대륙 상인	write mode open error
1260442588	/watlas/watlas/action.cgi	122.40.96.163		122.40.96.163		write mode open error
1260453155	/watlas/watlas/action.cgi	116.126.110.138		116.126.110.138	대륙 상인	write mode open error
1260453163	/watlas/watlas/action.cgi	116.126.110.138		116.126.110.138	대륙 상인	write mode open error
1260455420	/watlas/watlas/action.cgi	121.189.97.183		121.189.97.183		write mode open error
1260456670	/watlas/watlas/action.cgi	112.145.234.20		112.145.234.20		write mode open error
1260691078	/sub-domain/watlas/1/watlas/index.cgi	121.158.238.202		121.158.238.202		busy
1260691082	/sub-domain/watlas/1/watlas/index.cgi	121.158.238.202		121.158.238.202		busy
1263815221	/1/watlas/action.cgi	121.152.11.31		121.152.11.31		busy
1266495227	/1/watlas/action.cgi	119.202.51.31		119.202.51.31		busy
1266495239	/1/watlas/index.cgi	119.202.51.31		119.202.51.31		busy
1266760505	/1/watlas/action.cgi	58.121.236.224		58.121.236.224		busy
1271661113	/sub-domain/watlas/1/watlas/action.cgi	211.49.103.43		211.49.103.43	풍우	rename error ./data/temp/play.cgi->./data/play.cgi
1278678315	/watlas/watlas/index.cgi	116.43.213.40		116.43.213.40		busy
1278678319	/watlas/watlas/index.cgi	116.43.213.40		116.43.213.40		busy
1278678322	/watlas/watlas/action.cgi	116.43.213.40		116.43.213.40		busy
1278678330	/watlas/watlas/index.cgi	116.43.213.40		116.43.213.40		busy
1278678332	/watlas/watlas/index.cgi	116.43.213.40		116.43.213.40		busy
