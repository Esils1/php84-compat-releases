# 설정 파일 2005/01/06 유래
# 이 파일의 권한을 설정할 필요는 특별히 없습니다.설정한다면 644등으로 OK.

#-----------------------
# ◆처음에 하는 설정
#-----------------------
$MASTER_PASSWORD	='1064';			# 관리 비밀번호
$ADMIN_EMAIL		='dmona@dmona.com';			# 관리자 메일 주소

$HTML_TITLE	='월드 아틀라스';		# 거리의 정식명칭

$TOWN_TITLE	='월드';			# 거리의 명칭(전각 2 문자 정도로 짧고)
						# 나중이 되어 거리의 명칭을 바꾸었을 때는,관리실에서
						# 「초기화/파손 수복」버튼을 누를 필요가 있습니다.


#-----------------------
# ◆거리의 설정
#-----------------------
$TOWN_CODE	='atlas';			# 거리의 코드(식별 기호)
						# 반각영수소문자 10 문자 이내에서 적당하게 설정합시다.
						# 다른 거리와 같은 코드가 되지 않게.

$TITLE_COMMENT	='새 버전입니다';				# 로그인 화면에 싣는 댓글.태그 사용할 수 있습니다.

$HOME_PAGE	='./';		# 「홈」의 링크처

$MOVETOWN_ENABLE	=1;			# 이전 기능의 유효화 1:유효 0:무효
						# 서버가 socket에 대응하고 있지 않으면 이전 기능은 사용할 수 없습니다.


#------------------------
# 기본적인 게임 설정
#------------------------
$MAX_USER	=100;				# 새로운 치장 개점 최대수：너무 크게 설정하면 안 됩니다.
$MAX_MOVE_USER	=105;				# 이전 최대수(외로부터 이전해 왔을 경우의 수락 가능수)

$EXPIRE_TIME	=3600*24*365;			# 운영자 부재 기한(초)
						# 이 기간 동안 접속이 없으면 데이터가 삭제됩니다.

$ONE_DAY_TIME		=3600*24;		# 정산 주기(초)
$DATE_REVISE_TIME	=3600*7;		# 정산 시각을 조정하는 초 수(-3600로 1시간 앞당김)

$MAX_STOCK_TIME		=72*60*60;		# 최대 제한시간(초)

$LIMIT_EXP	=3600;				# 숙련도 합계 제한(10배의 수치를 지정)
						# 3600이라면360%가 상한.0으로 한다고 상한 없음.

$REQUEST_LIMIT		=48*60*60;		# 「의뢰소」의 의뢰가 유효한 시간(초)
$REQUEST_CAPACITY	=1;			# 동시에 의뢰할 수 있는 수

$HouseMax	=5;				# 「주택」에 보관할 수 있는 개수：
						# 5 로 하면,각각의 아이템이 창고 최대수의 5배까지 보관할 수 있다.

$MAX_BOX	=5;				# 편지 최대 발송 수
$BOX_STOCK_TIME	=48*60*60;			# 편지 보관 시간(초)

@DIGNITY=(					# 작위의 이름.오른쪽으로 갈수록 지위가 비싸집니다.
	"평민","사작","자작","백작","후작","공작","대공"
	);
@DIG_POINT=(					# 필요한 작위 포인트.위와 대응시켜 주세요.
	0,1,2,4,8,16,32
	);
$DIG_FORGUILD=16;				# 길드 결성에 필요한 작위 포인트

$BAL_NAME	='하이레딘';		# 반란 NPC의 이름
$BAL_JOB	='해적왕';			# 반란 NPC의 직업


#-------------------------------
# 용어에 관한 설정 : 게임내에 나오는 용어를 단번에 변경할 수 있습니다.
#-------------------------------

@term=(
	'\\',			#전에 붙이는 통화단위
	'',			#후에 붙이는 통화단위
	'원',			#일본어 표기되는 경우의 통화단위(순위등으로 사용한다)
	'빚쟁이',		#자금 마이너스시(순위로 사용한다)

);


#-------------------------------
# 액세스의 제한에 관한 설정
#-------------------------------
$NEW_SHOP_ADMIN		=0;			# 신규 오픈 권한 0:일반 1:관리자만
						# 1 으로 하면 관리 화면으로부터 밖에 가게를 열지 않게 됩니다.

$NEW_SHOP_KEYWORD	='';			# 신규 가게 오픈에 필요한 키워드
						# 키워드를 설정하면,그 말을 모르면 개점할 수 없게 됩니다.

$NEW_SHOP_BLOCKIP	=0;			# 1으로 동일 IP에 의한 연속 등록(폐점 후의 재등록도 포함한다)을 저지
$CHECK_IP		=0;			# 동일 IP＆USER_AGENT의 액세스를 자동적으로 제한하는 1:제한하는 0:제한하지 않는다
@NG_SHOP_NAME		=qw(관리지 11 12 aa http ?);	# 가게명으로서 사용할 수 없는 문자(스페이스에서 단락짓는다)

$NEW_OTHERTOWN_BLOCK	=0;			# 1 으로 거리 그룹 전체로 중복 등록을 검출.
						# 거리 그룹 전체로 1개 밖에 가게를 가질 수 있지 않게 됩니다.



#********************** 일반적인 설정 항목은 여기까지입니다 **********************



#--------------------------------------------------------------------
# 화상에 관한 설정 ： 화상을 갈아넣거나 특수한 장소에 두는 사람용.
#--------------------------------------------------------------------
$IMAGE_URL		='./image';		# 화상 디렉토리가 있는 장소(주소)
						# CGI가 별서버가 되는 곳은 변경의 필요 있어.
$IMAGE_DIR		='./image';		# 화상 디렉토리(서버의 풀 패스)
						# nifty 등이 특수한 서버에서는 변경의 필요 있어.

$ICON_NUMBER		=25;			# 점주얼굴 아이콘의 수
$ICON_SIZE		='WIDTH=48 HEIGHT=48';	# 얼굴 아이콘의 사이즈

$IMAGE_EXT		='.png';		# 화상 확장자(extension)

$COMMON_URL		='../common';		# 글로벌 데이터 디렉토리(길드등 )
						# CGI가 별서버가 되는 곳은 변경의 필요 있어.
$COMMON_DIR		='../common';		# 글로벌 데이터 디렉토리(서버의 풀 패스)
						# nifty 등이 특수한 서버에서는 변경의 필요 있어.

#---------------------------------------------------------
# 고도의 게임 밸런스 설정 ： 밸런스를 숙지한 사람용.
#---------------------------------------------------------
$UPDATE_TIME		=60*5;			# 최단 갱신 사이클(초)

$PROFIT_DAY_COUNT	=3;			# 점수 계산때 고려하는 과거의 순이익(기)
$SALE_SPEED		=12;			# 매출 배율(inc-item-data.cgi에서의 설정을 1으로서)
$POP_DOWN_RATE	=5;				# 현재의 인기에 응한 상하폭

$EXP_DOWN_POINT		=5;			# 결산시에 감소하는 숙련도 포인트(1%==10)
$EXP_DOWN_RATE		=60;			# 결산시에 감소하는 숙련도 비율(6%==60)
						# 예:현재의 숙련도50%의 경우,고정의 0.5%과50%의6%로3%,합해 3.5%감소


#---------------------------------------------------------
# 세세한 표시 설정 ： 함부로 변경하면 볼품이 무너집니다.
#---------------------------------------------------------
$TOP_RANKING_PAGE_ROWS	=5;			# 「탑」랭킹표시건수
$MAIN_LOG_PAGE_ROWS	=10;			# 「점주실」최근의 사건 표시 건수
$SHOP_PAGE_ROWS		=5;			# 「다른 상점」가게 표시 건수
$RANKING_PAGE_ROWS	=10;			# 랭킹표시건수
$LIST_PAGE_ROWS_PC	=25;			# 각종 리스트 표시 건수(통상)
$LIST_PAGE_ROWS_MOBILE	=5;			# 각종 리스트 표시 건수(휴대)



#********************** 이것보다 아래의 설정은 가능한 한 그대로 **********************

$DATA_DIR		='./data';
$LOG_DIR		=$DATA_DIR.'/log';
$ITEM_DIR		=$DATA_DIR.'/item';
$SESSION_DIR		=$DATA_DIR.'/session';
$BACKUP_DIR		=$DATA_DIR.'/backup';
$TEMP_DIR		=$DATA_DIR.'/temp';
$SUBDATA_DIR		=$DATA_DIR.'/subdata';

$COTEMP_DIR		=$COMMON_DIR.'/temp';

$INCLUDE_DIR		='../program';
$AUTOLOAD_DIR		=$INCLUDE_DIR.'/plug';
$TOWN_DIR		=$INCLUDE_DIR.'/town';
$CUSTOM_DIR		='./custom';

$DIR_PERMISSION		=0777;
$TZ_JST			=60*60*9;

$FILE_EXT		='.cgi';

$COMMIT_FILE		='commit';
$LASTTIME_FILE		='lasttime';
$LOCK_FILE		='lockfile';
$DATA_FILE		='play';
$LOG_FILE		='log';
$BBS_FILE		='treelog';
$BOX_FILE		='box';
$GUILDBAL_FILE		='guildbal';
$GUILD_FILE		='guild';
$ERROR_COUNT_FILE	='errorcnt';

$LOG_ERROR_FILE		='error';
$LOG_DELETESHOP_FILE	='delete';
$LOG_MOVESHOP_FILE	='moveshop';
$LOG_LOGIN_FILE		='login';
$LOG_DEBUG_FILE		='debug';
$LOG_MARK_FILE		='mark';
$LOG_SIZE_MAX		=30000;

$PASSWORD_CRYPT	=1;
$CHAR_SHIFT_JIS		=1;

$AUTO_UNLOCK_TIME		=60;
$SESSION_TIMEOUT_TIME		=3600;
$LOG_EXPIRE_TIME		=3600*36;
$PASSWORD_HASH_EXPIRE_TIME	=60*15;

$BACKUP_TIME		=3600;
$BACKUP		=3;
@BACKUP_FILES		=(
		$LOG_FILE.'0',
		$LOG_FILE.'1',
		$LOG_FILE.'2',
		$GUILDBAL_FILE,
		$DATA_FILE,
			);

# 기술자전용 디버그용 
$DEBUG_MOBILE		=0;			# 1으로 휴대단말 처리 고정
$DEBUG_LOG_ENABLE	=0;			# 1으로 item::DebugLog()와 event::DebugLog()를 유효화

# set umask
umask(~$DIR_PERMISSION & 0777);
require './_config-local.cgi' if -e './_config-local.cgi';

sub RequireFile
{
	my $customfile="$CUSTOM_DIR/$_[0]";
	require $customfile,return if -e $customfile;
	my $fname="$INCLUDE_DIR/$_[0]";
	OutError('파일이 발견되지 않습니다 - '.$fname) unless -e $fname;
	require $fname;
}
1;