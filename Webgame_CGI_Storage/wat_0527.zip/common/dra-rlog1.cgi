그러면 <b>가을달 상</b>의 출주입니다<br>
영관을 손에 넣는 것은 과연 어느 용이 될 것인가<br>
이 코스의 종반은 비탈이 있습니다. 제 1의 변수가 있을지도 모릅니다<br>
이제 시작입니다<br>
선두에 있는 용은 <b><IMG class="i" SRC="./image/dragon14.png">풍단200</b><br>
대부분이 예상한 일입니까<br>
현재 3번째로 달리고 있는 것은 2화 <b><IMG class="i" SRC="./image/dragon25.png">마라톤8세</b><br>
1지켜 보는 사람의 기대를 접수. 이 정도의 사람이 승리를 원합니다<br>
최초의 코너를 돌았습니다<br>
현재 선두는 변함없이 <b><IMG class="i" SRC="./image/dragon14.png">풍단200</b><br>
이 기세는 끝까지 계속될 것인가<br>
중간 800km의 통과 타임은 10.02<br>
거의 평상대로라고 할 수 있겠지요. 전개에 그다지 영향은 없을 것 같습니다<br>
<b><IMG class="i" SRC="./image/dragon13.png">다크엠페러a</b> 좋은 위치에요 여기부터 선두를 노리는 것인가<br>
후속룡이 차이를 좁혀갑니다<br>
자 과연...</b> 선두는 변함없이 <b><IMG class="i" SRC="./image/dragon14.png">풍단200</b><br>
이대로 잘 도주할 수 있을 것인가뒤를 쫓는 것은 <b><IMG class="i" SRC="./image/dragon13.png">다크엠페러a</b><br>
<b><IMG class="i" SRC="./image/dragon25.png">마라톤8세</b> 좋은 페이스지만...<br>
