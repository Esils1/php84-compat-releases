@OtherDir=("watlas");
$Tname{watlas}="월드";
