#-----------------------------------------------------------#
#  �߂Ɣ�++ �񗥔w�� 										#
#  Copyright(C) 2001-2002 by Vivid Studio. BLANK BOARD		#
#  Vivid Studio.[ http://www17.big.or.jp/~obochan/vivid/ ]	#
#  BLANK BOARD [ http://pom.to/ ]							#
#-----------------------------------------------------------#
# �Q���l���擾�E�����p�[�c	Version 1.0						#
#--- [���ӎ���] --------------------------------------------#
# 1.���̃X�N���v�g�͈ȉ��̗��p�K���ɏ]���Ĕz�z���Ă��܂��B	#
#   http://www24.big.or.jp/~obo/game/ore_/gild/				#
#-----------------------------------------------------------#

#-------------------------------------------------------------------------------
# �Q���l���擾
sub member_list{

	$all_mem=$#tdat+1;

	# �Q���ҍ��v�擾
	$c0 = grep(/camp;0/, @tdat);
	$c1 = grep(/camp;1/, @tdat);
	$c2 = grep(/camp;2/, @tdat);
	$c3 = grep(/camp;3/, @tdat);
	$c4 = grep(/camp;4/, @tdat);
	$c5 = grep(/camp;5/, @tdat);

	if($limit_mode){
		$c1a = $c2a = $c3a = $c4a = $c5a = ($all_mem<18) ?  3 : int($all_mem/6)+1 ;
		&member_adjust if(!$member_flag);
	}

	&cdat_write;
}

#-------------------------------------------------------------------------------
# �O�񓝈�̗D��ݒ�(�Q���l��)
sub member_adjust{

	$c1a = $c2a = $c3a = $c4a = $c5a = ($all_mem<18) ?  3 : int($all_mem/6)+1 ;

	local($rca_p,$rca_m);
	$rca_p=1 if($all_mem<50);
	$rca_p=2 if($all_mem=>50 && $all_mem<100);
	$rca_p=3 if($all_mem=>100 && $all_mem<150);
	$rca_p=4 if($all_mem=>150 && $all_mem<200);
	$rca_p=5 if($all_mem=>200);

	if($all_mem<50){
		$rca_p=0;
		$rca_m=-1;
	}
	elsif($all_mem=>50 && $all_mem<100){
		$rca_p=0;
		$rca_m=-2;
	}
	elsif($all_mem=>100 && $all_mem<150){
		$rca_p=1;
		$rca_m=-3;
	}
	elsif($all_mem=>150 && $all_mem<200){
		$rca_p=1;
		$rca_m=-4;
	}
	elsif($all_mem=>200){
		$rca_p=2;
		$rca_m=-5;
	}

	if($cn1>=$data_reset || $hcamp==1){
		$c1a +=$rca_m;
		$c2a +=$rca_p;
		$c3a +=$rca_p;
		$c4a +=$rca_p;
		$c5a +=$rca_p;
	}elsif($cn2>=$data_reset || $hcamp==2){
		$c1a +=$rca_p;
		$c2a +=$rca_m;
		$c3a +=$rca_p;
		$c4a +=$rca_p;
		$c5a +=$rca_p;
	}elsif($cn3>=$data_reset || $hcamp==3){
		$c1a +=$rca_p;
		$c2a +=$rca_p;
		$c3a +=$rca_m;
		$c4a +=$rca_p;
		$c5a +=$rca_p;
	}elsif($cn4>=$data_reset || $hcamp==4){
		$c1a +=$rca_p;
		$c2a +=$rca_p;
		$c3a +=$rca_p;
		$c4a +=$rca_m;
		$c5a +=$rca_p;
	}elsif($cn5>=$data_reset || $hcamp==5){
		$c1a +=$rca_p;
		$c2a +=$rca_p;
		$c3a +=$rca_p;
		$c4a +=$rca_p;
		$c5a +=$rca_m;
	}
}





1;
