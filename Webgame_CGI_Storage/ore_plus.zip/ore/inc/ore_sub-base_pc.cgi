#-----------------------------------------------------------#
#  �˿͹�++ �������										#
#  Copyright(C) 2001-2002 by Vivid Studio.  BLANK BOARD		#
#  Vivid Studio. [ http://www17.big.or.jp/~obochan/vivid/ ]	#
#  BLANK BOARD [ http://pom.to/ ]							#
#-----------------------------------------------------------#
# PC�� ����ƾ	Version 1.1								#
#--- [���ǻ���] --------------------------------------------#
# 1. �� ��ũ��Ʈ�� ������ �̿������ ���� �����ϰ� �ֽ��ϴ�.#
#   http://www24.big.or.jp/~obo/game/ore_/gild/				#
#-----------------------------------------------------------#

#-------------------------------------------------------------------------------
# ȭ�� ���̾ƿ�
sub html{

	# ���&���� ���� ����
	&content_type;

	# ���콺 �ڵ� ���� ġƮ ���� �����ÿ�4/400 �� Ȯ������ �ߵ�
	my $no_mouse = ($no_mouse && $type eq '������') ? int(rand(400)) : 100 ;

	print <<EOM;
<html>
<head>
<title>$titleh</title>
<link rel=stylesheet type="text/css" href="$css" title="style">
EOM

# Javascript �ڵ� ���� ġƮ ����(frame ȥ�� ����)
if($no_js){
	print <<EOM;
<script language="javascript">
<!--
	if(self!=top){
		top.location = self.location;
	}
//-->
</script>
EOM
}

	print <<EOM;
</head>
<body $body class="bar">
<center>
<table width="740" border="0" cellspacing="0" cellpadding="0">
<tr>
<td align="left">
$title
</td>
</tr>
</table>

<table width="740" border="0" cellspacing="0" cellpadding="0" height="300">
<tr>
<td align="center" valign="middle" width="500">

<table width="540" border="0" cellspacing="6" cellpadding="6" height="285" bgcolor="#444466">
<tr>
<td bgcolor="#000000" align="left" valign="top">
$log1
</td>
</tr>
</table>

</td>
<td align="right" valign="middle" width="200">

<table border="0" cellspacing="0" cellpadding="5" height="285">
<tr>
<form method="get" action="$index">
<td bgcolor="#000000" valign="middle">
<input type="submit" value=" Ÿ��Ʋ�� ���ƿ´� " class="button1">
</td>
</form>
</tr>
EOM
	if($no_mouse==0){
		print qq|<tr>$log2</tr>|;
	}
	print<<EOM;
<tr>
<form method="$method" action="$park">
<td valilgn="middle">
<input type="hidden" name="id" value="$id">
<input type="hidden" name="pw" value="$pw">
<input type="hidden" name="camp" value="$camp">
<input type="hidden" name="sogo" value="$sogo">
<input type="submit" value="   ���� ���� ����   " class="button1">
</td>
</form>
</tr>
EOM
	if($no_mouse==1){
		print qq|<tr>$log2</tr>|;
	}
	print<<EOM;
<tr>
<form method="$method" action="$hist">
<td valilgn="middle">
<input type="hidden" name="id" value="$id">
<input type="hidden" name="pw" value="$pw">
<input type="submit" value=" �� ������ ���� �� " class="button1">
</td>
</form>
</tr>
EOM

if(!$type && $cmd<=0){
	print <<"EOM";
<tr>
<form method="$method" action="$script">
<td valilgn="middle">
<input type="hidden" name="id" value="$id">
<input type="hidden" name="pw" value="$pw">
<input type="hidden" name="cmd" value="20">
<input type="submit" value=" ���� ������ ���� " class="button1">
</td>
</form>
</tr>
EOM
}
	print <<"EOM";
<tr>
<form method="$method" action="$public">
<td valilgn="middle">
<input type="hidden" name="id" value="$id">
<input type="hidden" name="pw" value="$pw">
<input type="submit" value="    ������ ���ࡡ   " class="button1">
</td>
</form>
</tr>
EOM
	if($no_mouse==2){
		print qq|<tr>$log2</tr>|;
	}
	print<<EOM;
<tr>
<form method="$method" action="$campbbs">
<td>
<input type="hidden" name="id" value="$id">
<input type="hidden" name="pw" value="$pw">
<input type="submit" value="  ���� ���� ȸ�ǽ�  " class="button1">
</td>
</form>
</tr>
EOM
	if($no_mouse>=3){
		print qq|<tr>$log2</tr>|;
	}
	print<<EOM;
</table>

</td>
</tr>
</table>
<br>
EOM

	my($uti, $sti, $cuti, $csti) = times();
	$uti += $cuti;
	$sti += $csti;
	my($cpu) = $uti + $sti;
	my $disp="CPUs($cpu): User($uti) System($sti)<br>";

	if($layout_flag==1){
		print <<EOM;
<table width="740" border="0" cellspacing="4" cellpadding="4" bgcolor="#444466">
<tr>
<td bgcolor="#000000" align="center" valign="top" height="120">
<tt class="moji1">
$log
</tt>
</td>
</tr>
</table>
<br><br>
EOM
	}elsif(!$layout_flag){
		require './inc/ore_sub-base-p1_pc.cgi';&layout_flag_0;
	}

	print <<"EOM";
$disp<br>
<br>
$kakiko
EOM

}

#-------------------------------------------------------------------------------
#�������ͽ� ǥ��
sub status{

	&settei;#���� read

	my(
		$hp_v,$hp_c,$hp_y,
		$mp_v,$mp_c,$mp_y,
		$ua_v,$ua_c,
		$ud_v,$ud_c,
		$lr_v,$lr_c,
	);

	#HP�׷���
	if($max_hp <= 75){
		$hp_v = $hp*2;
		$hp_c = "#00bbff";
		$hp_y = $max_hp*2-$hp*2;
	}elsif($max_hp <= 300){
		$hp_v = $hp;
		$hp_c = "#0099ff";
		$hp_y = $max_hp-$hp;
	}elsif($max_hp <= 600){
		$hp_v = int($hp/2);
		$hp_c = "#0077ff";
		$hp_y = int($max_hp/2-$hp/2);
	}elsif($max_hp <= 1200){
		$hp_v = int($hp/4);
		$hp_c = "#0055ff";
		$hp_y = int($max_hp/4-$hp/4);
	}elsif($max_hp <= 2400){
		$hp_v = int($hp/8);
		$hp_c = "#0033ff";
		$hp_y = int($max_hp/8-$hp/8);
	}elsif($max_hp <= 4800){
		$hp_v = int($hp/16);
		$hp_c = "#0011ff";
		$hp_y = int($max_hp/16-$hp/16);
	}else{
		$hp_v = int($hp/32);
		$hp_c = "#0011ff";
		$hp_y = int($max_hp/32-$hp/32);
	}
	#MP�׷���
	if($max_mp <= 75){
		$mp_v = $mp*2;
		$mp_c = "#00ffcc";
		$mp_y = $max_mp*2-$mp*2;
	}elsif($max_mp <= 300){
		$mp_v = $mp;
		$mp_c = "#00ddcc";
		$mp_y = $max_mp-$mp;
	}elsif($max_mp <= 600){
		$mp_v = int($mp/2);
		$mp_c = "#00bbcc";
		$mp_y = int($max_mp/2-$mp/2);
	}elsif($max_mp <= 1200){
		$mp_v = int($mp/4);
		$mp_c = "#0099cc";
		$mp_y = int($max_mp/4-$mp/4);
	}elsif($max_mp <= 2400){
		$mp_v = int($mp/8);
		$mp_c = "#0077cc";
		$mp_y = int($max_mp/8-$mp/8);
	}elsif($max_mp <= 4800){
		$mp_v = int($mp/16);
		$mp_c = "#0055cc";
		$mp_y = int($max_mp/16-$mp/16);
	}else{
		$mp_v = int($mp/32);
		$mp_c = "#0033cc";
		$mp_y = int($max_mp/32-$mp/32);
	}
	#UA�׷���
	if($ua <= 25){
		$ua_v = $ua*4;
		$ua_c = "#99ccff";
	}elsif($ua <= 50){
		$ua_v = $ua*2;
		$ua_c = "#9999ff";
	}elsif($ua <= 100){
		$ua_v = $ua;
		$ua_c = "#9966ff";
	}elsif($ua <= 500){
		$ua_v = int($ua/2);
		$ua_c = "#9933ff";
	}else{
		$ua_v = int($ua/4);
		$ua_c = "#9900ff";
	}
	#UD�׷���
	if($ud <= 25){
		$ud_v = $ud*4;
		$ud_c = "#33ffff";
	}elsif($ud <= 50){
		$ud_v = $ud*2;
		$ud_c = "#33ccff";
	}elsif($ud <= 100){
		$ud_v = $ud;
		$ud_c = "#3399ff";
	}elsif($ud <= 500){
		$ud_v = int($ud/2);
		$ud_c = "#3366ff";
	}else{
		$ud_v = int($ud/4);
		$ud_c = "#3333ff";
	}
	#LR�׷���
	if($lr <= 25){
		$lr_v = $lr*4;
		$lr_c = "#ccccff";
	}elsif($lr <= 50){
		$lr_v = $lr*2;
		$lr_c = "#cc99ff";
	}elsif($lr <= 100){
		$lr_v = $lr;
		$lr_c = "#cc66ff";
	}elsif($lr <= 500){
		$lr_v = int($lr/2);
		$lr_c = "#cc33ff";
	}else{
		$lr_v = int($lr/4);
		$lr_c = "#cc00ff";
	}
	#LR�׷���
	if($ag <= 25){
		$ag_v = $ag*4;
		$ag_c = "#ccccff";
	}elsif($ag <= 50){
		$ag_v = $ag*2;
		$ag_c = "#cc99ff";
	}elsif($ag <= 100){
		$ag_v = $ag;
		$ag_c = "#cc66ff";
	}elsif($ag <= 500){
		$ag_v = int($ag/2);
		$ag_c = "#cc33ff";
	}else{
		$ag_v = int($ag/4);
		$ag_c = "#cc00ff";
	}

	$hp_y = (!$hp_y) ? "" : "<img src=\"$imgs/spc.gif\" height=\"8\" width=\"$hp_y\" style=\"background-color:#555555\">";
	$mp_y = (!$mp_y) ? "" : "<img src=\"$imgs/spc.gif\" height=\"8\" width=\"$mp_y\" style=\"background-color:#555555\">";
	$ua_y = (!$dg_a) ? "" : "<img src=\"$imgs/spc.gif\" height=\"8\" width=\"$dg_data[$dg_a][4]\" style=\"background-color:#6666cc\">";
	$ud_y = (!$df_a) ? "" : "<img src=\"$imgs/spc.gif\" height=\"8\" width=\"$df_data[$df_a][4]\" style=\"background-color:#6666cc\">";

	$cimg=$cimg;
	$log1.=<<EOM;

<table border="0">
    <tr>
        <td>
            <p><img src=$cimgs/$cimg.gif></p>
        </td>
        <td rowspan="2">
<tt class="moji1">
<b>$nm</b>������<span style="font-size:12px">$seibetu[$sei]</span>&nbsp;&nbsp;&nbsp;&nbsp;ID: $id<br>
���� <b>$lv</b>����� <b>$cl[$rank]</b>��Īȣ [<b>$sogo_p[$sogo]</b>]���Ƿε� <b>$act_cnt/$act_cnt_limit</b><br>
<br>
ü��[HP] <img src="$imgs/spc.gif" height="8" width="$hp_v" style="background-color:$hp_c">$hp_y $hp/$max_hp<br>
����[MP] <img src="$imgs/spc.gif" height="8" width="$mp_v" style="background-color:$mp_c">$mp_y $mp/$max_mp<br>
���ݷ�[UA] <img src="$imgs/spc.gif" height="8" width="$ua_v" style="background-color:$ua_c">$ua_y $ua + $dg_data[$dg_a][4]<br>
����[UD] <img src="$imgs/spc.gif" height="8" width="$ud_v" style="background-color:$ud_c">$ud_y $ud + $df_data[$df_a][4]<br>
���ַ�[LR] <img src="$imgs/spc.gif" height="8" width="$lr_v" style="background-color:$lr_c"> $lr<br>
��ø��[AG] <img src="$imgs/spc.gif" height="8" width="$ag_v" style="background-color:$ag_c"> $ag<br>
<br>
�ڱ� <b>$gold</b>������ġ <b>$exe/$next_lv</b>������ġ <b>$rank_exe</b><br>
<br>
�Ҽ� <b>$cmp[$camp]</b>���δ� <b>$g_p[$rank]</b>���Ʒõ� <b>$sol_lv</b><br>
<br>
���� [<b>$dg_data[$dg_a][1]</b>]�����ݷ� [<b>$dg_data[$dg_a][4]</b>]  ���� Ƚ�� [<b>$dg_cnt</b>]<br>
�� [<b>$df_data[$df_a][1]</b>]������ [<b>$df_data[$df_a][4]</b>]  ���� Ƚ�� [<b>$df_cnt</b>]<br>
���� [<b>$di_data[$di_a][1]</b>]������ Ƚ�� [<b>$di_cnt</b>]
</tt>
        </td>
    </tr>
    <tr align=center height=150>
        <td width=85>
        </td>
    </tr>
</table>
EOM

}





1;#�����Ұ�
