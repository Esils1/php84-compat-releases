#-----------------------------------------------------------#
#  ����++ �������										#
#  Copyright(C) 2001-2002 by Vivid Studio. BLANK BOARD		#
#  Vivid Studio.[ http://www17.big.or.jp/~obochan/vivid/ ]	#
#  BLANK BOARD [ http://pom.to/ ]							#
#-----------------------------------------------------------#
# ���� ����Ͽ� ����ƾ	Version 1.0						#
#--- [�������] --------------------------------------------#
# 1.���Ϋ�����׫Ȫ����������Ю���?�ê����֪��ƪ��ު���	#
#   http://www24.big.or.jp/~obo/game/ore_/gild/				#
#-----------------------------------------------------------#

#-------------------------------------------------------------------------------
# ����
sub infomation_com{
	$log .= qq|������ $cmp[$camp] �� �庴 �϶�<br>\n|;

	local(@usrfile,@tdat);

	# ������ ������ ���� �϶� ���/�б�
	&usrdata_read;
	&usrdata_open;
	require './inc/ore_sub-members-p1.cgi';&member_list;

	if($camp eq'' || $camp < 1 || $camp > 5){

		foreach (0 .. $#tdat){

			%R = '';
			my @prats = split(/,/,$tdat[$_]);
			foreach $prats (@prats){
				my($y,$x) = split(/;/,$prats);
				$R{$y} = $x;
			}

			$NM_V				= $R{'nm'};
			$HP_MAX_V			= $R{'max_hp'};
			$MP_MAX_V			= $R{'max_mp'};
			$LV_V				= $R{'rank'};
			$TM_V				= $R{'lv'};
			$UA_V				= $R{'ua'};
			$UD_V				= $R{'ud'};
			$LR_V				= $R{'lr'};
			$AG_V				= $R{'ag'};
			$DG_A_V				= $R{'dg_a'};#����
			$DF_A_V				= $R{'df_a'};#����
			$SOGO_V				= $R{'sogo'};#??
			$SEI_V				= $R{'sei'};#��ܬ
			$MES_V				= $R{'info_mes'};

			$TYPE_V				= ($R{'type'}) ? "$R{'type'}" : "�����";

			$cnt				= $_+1;

			if($R{'camp'} == 0){
				$log .=qq|$cnt�� Lv$TM_V|;

				# ??
				$log .= ($SOGO_V > 0) ? "$NM_V [$sogo_p[$SOGO_V]]" : "$NM_V";

				$log .=qq|HP$HP_MAX_V/MP$MP_MAX_V/UA$UA_V/UD$UD_V/LR$LR_V/AG$AG_V $cl[$LV_V]<hr color="white">\n|;

			}
		}

	}else{

		foreach(0 .. $#tdat){
			%R = '';
			my @prats = split(/,/,$tdat[$_]);
			foreach $prats (@prats){
				my($y,$x) = split(/;/,$prats);
				$R{$y} = $x;
			}

			if($camp == $R{'camp'}){
				$NM_V{$R{'nm'}}		= $R{'nm'};
				$HP_MAX_V{$R{'nm'}}	= $R{'max_hp'};
				$MP_MAX_V{$R{'nm'}}	= $R{'max_mp'};
				$LV_V{$R{'nm'}}		= $R{'rank'};
				$TM_V{$R{'nm'}}		= $R{'lv'};
				$UA_V{$R{'nm'}}		= $R{'ua'};
				$UD_V{$R{'nm'}}		= $R{'ud'};
				$LR_V{$R{'nm'}}		= $R{'lr'};
				$AG_V{$R{'nm'}}		= $R{'ag'};
				$DG_A{$R{'nm'}}		= $R{'dg_a'};#����
				$DF_A{$R{'nm'}}		= $R{'df_a'};#����
				$SOGO_V{$R{'nm'}}	=$R{'sogo'};#??
				$SEI_V{$R{'nm'}}	=$R{'sei'};#��ܬ
				$MES_V{$R{'nm'}}	=$R{'info_mes'};

				$TYPE_V{$R{'nm'}}	= ($R{'type'}) ? "$R{'type'}" : "�����";

				$N_M{$R{'nm'}}		= $_;
			}
		}

		$l = $rk = 1;
		foreach $nm (sort sclv keys(%LV_V)){
			$lv_v = $LV_V{$nm};
			next if($lv_v<=0);
			if($lv_v<$prv_lv){ $rk = $l; }

			$log .="$rk�� Lv$TM_V{$nm} ";

			#??
			$log .= ($SOGO_V{$nm} > 0) ? "$NM_V{$nm} [$sogo_p[$SOGO_V{$nm}]]" : "$NM_V{$nm}";

			$log .=qq| HP$HP_MAX_V{$nm}/MP$MP_MAX_V{$nm}/UA$UA_V{$nm}/UD$UD_V{$nm}/LR$LR_V{$nm}/AG$AG_V{$nm} $cl[$lv_v]<hr color="white">\n|;

			$prv_lv = $lv_v;
			$l++;
		}
	}

	$tm = $cmd = 0;
	$layout_flag=1;
	&call_main_st;
}





1;#�����ʦ