#-----------------------------------------------------------#
#  �˿͹�++ ������� 										#
#  Copyright(C) 2001-2002 by Vivid Studio.  BLANK BOARD		#
#  Vivid Studio. [ http://www17.big.or.jp/~obochan/vivid/ ]	#
#  BLANK BOARD [ http://pom.to/ ]							#
#-----------------------------------------------------------#
# �ɷ� Version 1.0
#--- [���� ����] --------------------------------------------#
# 1. �� ��ũ��Ʈ�� ������ �̿������ ���� �����ϰ� �ֽ��ϴ�.#
#   http://www24.big.or.jp/~obo/game/ore_/gild/				#
#-----------------------------------------------------------#

#-------------------------------------------------------------------------------
# �ɷ� �޴�

sub ability{

	if(!$type){

		&abi_up_data;

		$log .= "UA $va G UD $vd G LR $vl G AG $vg G HP $vha G, MP $vma G,<br>
UA5 $vaa G UD5 $vda G LR5 $vla G AG5 $vga G<br>  HP50 $vh G ��MP50 $vm G<br>
UA10 $vaab G UD10 $vdab G LR10 $vlab G AG10 $vgab G<br>  HP100 $vhb G ��MP100 $vmb G �� ����� �ɷ��� ����ŵ�ϴ�.
 <br>\n";
		$tm=0;
		$type='�ɷ�';

		&ability_menu;
	}

	&dat_write;
}

sub ability_menu{

	# �ɷ� Ŀ���
	@st		 = ('�׸��д�','HP 1','MP 1','UA 1','UD 1','LR 1','AG 1',
'UA 5','UD 5','LR 5','AG 5','HP 50','MP 50',
'UA 10','UD 10','LR 10','AG 10','HP 100','MP 100',
);

	$log2 .=qq|<form action="$script" method="$method" name="ore_">\n|;
	$log2 .=qq|<td align="center" valign="middle">\n| if($mv_mode eq 'pc');
	$log2 .=qq|<input type="hidden" name="id" value="$id">\n<input type="hidden" name="pw" value="$pw">\n|;

	$log2 .=qq|<select name="cmd" size="1">\n|;
	foreach(0 .. $#st){ $log2 .= "<option value=$_>$st[$_]</option>\n";}
	$log2 .=qq|</select><br>\n|;
	$log2 .=qq|<input type="submit" $button1 value="NEXT">$td_end</form>\n|;
}

#-------------------------------------------------------------------------------
# �ɷ� ó��
sub ability_exe{

	if(!$tm){

		&abi_up_data;

		if($cmd<=0){
			$log .= "�׸��Ӵϴ�.<br>\n";
			$tm = $cmd = 0;
			$type='';
			&call_main_st;
		}elsif($cmd==1){
			if($gold<$vha){
				$log .= "���� �����մϴ�.<br>\n";
				$tm = $cmd = 0;
				$type='';
				&ability_menu;
			}else{
				$log .= "�ִ� HP �� 1 �ö���!<br>\n";
				$max_hp+=1;
				$gold-=$vha;
				$tm = $cmd = 0;
				$type='';
				&call_main_st;
			}
		}elsif($cmd==2){
			if($gold<$vma){
				$log .= "���� �����մϴ�.<br>\n";
				$tm = $cmd = 0;
				$type='';
				&ability_menu;
			}else{
				$log .= "�ִ� MP �� 1 �ö���!<br>\n";
				$max_mp+=1;
				$gold-=$vma;
				$tm = $cmd = 0;
				$type='';
				&call_main_st;
			}
		}elsif($cmd==3){
			if($gold<$va){
				$log .= "���� �����մϴ�.<br>\n";
				$tm = $cmd = 0;
				&ability_menu;
			}else{
				$log .= "���ݷ��� 1 �ö���!<br>\n";
				$ua++;
				$gold-=$va;
				$tm = $cmd = 0;
				$type='';
				&call_main_st;
			}
		}elsif($cmd==4){
			if($gold<$vd){
				$log .= "���� �����մϴ�.<br>\n";
				$tm = $cmd = 0;
				&ability_menu;
			}else{
				$log .= "������ 1 �ö���!<br>\n";
				$ud++;
				$gold-=$vd;
				$tm = $cmd = 0;
				$type='';
				&call_main_st;
			}
		}elsif($cmd==5){
			if($gold<$vl){
				$log .= "���� �����մϴ�.<br>\n";
				$tm = $cmd = 0;
				&ability_menu;
			}else{
				$log .= "���ַ��� 1 �ö���!<br>\n";
				$lr++;
				$gold-=$vl;
				$tm = $cmd = 0;
				$type='';
				&call_main_st;
			}
		}elsif($cmd==6){
			if($gold<$vg){
				$log .= "���� �����մϴ�.<br>\n";
				$tm = $cmd = 0;
				&ability_menu;
			}else{
				$log .= "��ø�� 1 �ö���!<br>\n";
				$ag++;
				$gold-=$vg;
				$tm = $cmd = 0;
				$type='';
				&call_main_st;
			}


	}elsif($cmd==7){
			if($gold<$vaa){
				$log .= "���� �����մϴ�.<br>\n";
				$tm = $cmd = 0;
				&ability_menu;
			}else{
				$log .= "���ݷ��� 5 �ö���!<br>\n";
				$ua+=5;
				$gold-=$vaa;
				$tm = $cmd = 0;
				$type='';
				&call_main_st;
			}
	}elsif($cmd==8){
			if($gold<$vda){
				$log .= "���� �����մϴ�.<br>\n";
				$tm = $cmd = 0;
				&ability_menu;
			}else{
				$log .= "������ 5 �ö���!<br>\n";
				$ud+=5;
				$gold-=$vda;
				$tm = $cmd = 0;
				$type='';
				&call_main_st;
			}
		}elsif($cmd==9){
			if($gold<$vla){
				$log .= "���� �����մϴ�.<br>\n";
				$tm = $cmd = 0;
				&ability_menu;
			}else{
				$log .= "���ַ��� 5 �ö���!<br>\n";
				$lr+=5;
				$gold-=$vla;
				$tm = $cmd = 0;
				$type='';
				&call_main_st;
			}
		}elsif($cmd==10){
			if($gold<$vga){
				$log .= "���� �����մϴ�.<br>\n";
				$tm = $cmd = 0;
				&ability_menu;
			}else{
				$log .= "��ø�� 5 �ö���!<br>\n";
				$ag+=5;
				$gold-=$vga;
				$tm = $cmd = 0;
				$type='';
				&call_main_st;
			}
					}elsif($cmd==11){
			if($gold<$vh){
				$log .= "���� �����մϴ�.<br>\n";
				$tm = $cmd = 0;
				$type='';
				&ability_menu;
			}else{
				$log .= "�ִ� HP �� 50 �ö���!<br>\n";
				$max_hp+=50;
				$gold-=$vh;
				$tm = $cmd = 0;
				$type='';
				&call_main_st;
			}
					}elsif($cmd==12){
			if($gold<$vm){
				$log .= "���� �����մϴ�.<br>\n";
				$tm = $cmd = 0;
				$type='';
				&ability_menu;
			}else{
				$log .= "�ִ� MP �� 50 �ö���!<br>\n";
				$max_mp+=50;
				$gold-=$vm;
				$tm = $cmd = 0;
				$type='';
				&call_main_st;
			}
	}elsif($cmd==13){
			if($gold<$vaab){
				$log .= "���� �����մϴ�.<br>\n";
				$tm = $cmd = 0;
				&ability_menu;
			}else{
				$log .= "���ݷ��� 10 �ö���!<br>\n";
				$ua+=10;
				$gold-=$vaab;
				$tm = $cmd = 0;
				$type='';
				&call_main_st;
			}
	}elsif($cmd==14){
			if($gold<$vdab){
				$log .= "���� �����մϴ�.<br>\n";
				$tm = $cmd = 0;
				&ability_menu;
			}else{
				$log .= "������ 10 �ö���!<br>\n";
				$ud+=10;
				$gold-=$vdab;
				$tm = $cmd = 0;
				$type='';
				&call_main_st;
			}
		}elsif($cmd==15){
			if($gold<$vlab){
				$log .= "���� �����մϴ�.<br>\n";
				$tm = $cmd = 0;
				&ability_menu;
			}else{
				$log .= "���ַ��� 10 �ö���!<br>\n";
				$lr+=10;
				$gold-=$vlab;
				$tm = $cmd = 0;
				$type='';
				&call_main_st;
			}
		}elsif($cmd==16){
			if($gold<$vgab){
				$log .= "���� �����մϴ�.<br>\n";
				$tm = $cmd = 0;
				&ability_menu;
			}else{
				$log .= "��ø�� 10 �ö���!<br>\n";
				$ag+=10;
				$gold-=$vgab;
				$tm = $cmd = 0;
				$type='';
				&call_main_st;
			}
					}elsif($cmd==17){
			if($gold<$vhb){
				$log .= "���� �����մϴ�.<br>\n";
				$tm = $cmd = 0;
				$type='';
				&ability_menu;
			}else{
				$log .= "�ִ� HP �� 100 �ö���!<br>\n";
				$max_hp+=100;
				$gold-=$vhb;
				$tm = $cmd = 0;
				$type='';
				&call_main_st;
			}
					}elsif($cmd==18){
			if($gold<$vmb){
				$log .= "���� �����մϴ�.<br>\n";
				$tm = $cmd = 0;
				$type='';
				&ability_menu;
			}else{
				$log .= "�ִ� MP �� 100 �ö���!<br>\n";
				$max_mp+=100;
				$gold-=$vmb;
				$tm = $cmd = 0;
				$type='';
				&call_main_st;
			}
		}
	}

	&dat_write;

}

# �ɷ� ���ġ ���
sub abi_up_data{

	$va=int($ua*$ua)*100;
	$va=1000 if($va<1000);
	$va=1000000 if($va>1000000);
	$vd=int($ud*$ud)*100;
	$vd=1000 if($vd<1000);
	$vd=1000000 if($vd>1000000);
	$vl=int($lr*$lr)*100;
	$vl=1000 if($vl<1000);
	$vl=1000000 if($vl>1000000);
	$vg=int($ag*$ag)*100;
	$vg=1000 if($vg<1000);
	$vg=1000000 if($vg>1000000);


$vaa=int($ua*$ua)*400;
if($ua>25){
  $vaa=int($ua*$ua)*420;}
elsif($ua>50){
$vaa=int($ua*$ua)*440;}
elsif($ua>75){
$vaa=int($ua*$ua)*460;}

		$vaa=5000 if($vaa<5000);
		$vaa=6000000 if($vaa>6000000);
		
$vda=int($ud*$ud)*400;
if($ud>25){
  $vda=int($ud*$ud)*420;}
elsif($ud>50){
$vda=int($ud*$ud)*440;}
elsif($ud>75){
$vda=int($ud*$ud)*460;}
	$vda=5000 if($vda<5000);
	$vda=6000000 if($vda>6000000);
	
$vla=int($lr*$lr)*400;
if($lr>25){
  $vla=int($lr*$lr)*420;}
elsif($lr>50){
$vla=int($lr*$lr)*440;}
elsif($lr>75){
$vla=int($lr*$lr)*460;}
	$vla=5000 if($vla<5000);
	$vla=6000000 if($vla>6000000);
	
$vga=int($ag*$ag)*400;
if($ag>25){
  $vga=int($ag*$ag)*420;}
elsif($ag>50){
$vga=int($ag*$ag)*440;}
elsif($ag>75){
$vga=int($ag*$ag)*460;}
	$vga=5000 if($vga<5000);
	$vga=6000000 if($vga>6000000);

	$vha=int($max_hp*$max_hp)*1;
	$vha=5000 if($vha<5000);
	$vha=5000 if($vha>5000);
	$vma=int($max_mp*$max_hp)*1;
	$vma=5000 if($vma<5000);
	$vma=5000 if($vma>5000);
	$vh=int($max_hp*$max_hp)*50;
	$vh=250000 if($vh<250000);
	$vh=250000 if($vh>250000);
	$vm=int($max_mp*$max_mp)*50;
	$vm=250000 if($vm<250000);
	$vm=250000 if($vm>250000);

$vaab=int($ua*$ua)*900;
if($ua>25){
  $vaab=int($ua*$ua)*950;}
elsif($ua>50){
$vaab=int($ua*$ua)*1000;}
elsif($ua>75){
$vaab=int($ua*$ua)*1050;}
	$vaab=10000 if($vaab < 10000);
	$vaab=13000000 if($vaab>13000000);

$vdab=int($ud*$ud)*900;
if($ud>25){
  $vdab=int($ud*$ud)*950;}
elsif($ud>50){
$vdab=int($ud*$ud)*1000;}
elsif($ud>75){
$vdab=int($ud*$ud)*1050;}
	$vdab=10000 if($vdab < 10000);
	$vdab=13000000 if($vdab>13000000);

$vlab=int($lr*$lr)*900;
if($lr>25){
  $vlab=int($lr*$lr)*950;}
elsif($lr>50){
$vlab=int($lr*$lr)*1000;}
elsif($lr>75){
$vlab=int($lr*$lr)*1050;}
	$vlab=10000 if($vlab<10000);
	$vlab=13000000 if($vlab>13000000);

$vgab=int($ag*$ag)*900;
if($ag>25){
  $vgab=int($ag*$ag)*950;}
elsif($ag>50){
$vgab=int($ag*$ag)*1000;}
elsif($ag>75){
$vgab=int($ag*$ag)*1050;}
	$vgab=10000 if($vgab<10000);
	$vgab=13000000 if($vgab>13000000);

	$vhb=int($max_hp*$max_hp)*100;
	$vhb=500000 if($vhb<500000);
	$vhb=500000 if($vhb>500000)
;
	$vmb=int($max_mp*$max_mp)*100;
	$vmb=500000 if($vmb<500000);
	$vmb=500000 if($vmb>500000);

	return ($va,$vd,$vl,$vg,$vh,$vm,$vha,$vma,$vaa,$vga,$vla,$vda,$vaab,$vdab,$vlab,$vgab,$vhb,$vmb);

}





1;