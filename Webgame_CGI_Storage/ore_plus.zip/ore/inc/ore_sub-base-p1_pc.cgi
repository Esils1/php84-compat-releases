#-----------------------------------------------------------#
#  �˿͹�++ ������� 										#
#  Copyright(C) 2001-2002 by Vivid Studio.  BLANK BOARD		#
#  Vivid Studio. [ http://www17.big.or.jp/~obochan/vivid/ ]	#
#  BLANK BOARD [ http://pom.to/ ]							#
#-----------------------------------------------------------#
# ǥ�� PC�� ���� 1 Version 1.0	     						#
#--- [���ǻ���] --------------------------------------------#
# 1. �� ��ũ��Ʈ�� ������ �̿������ ���� �����ϰ� �ֽ��ϴ�.#
#   http://www24.big.or.jp/~obo/game/ore_/gild/				#
#-----------------------------------------------------------#

#-------------------------------------------------------------------------------
# ��� ǥ�ÿ�
sub layout_flag_0{
	print <<EOM;
<table width="740" border="0" cellspacing="0" cellpadding="0">
<tr>
<td align="left" valign="top" width="540">
EOM

	if($log){
		print <<"EOM";
<table width="100%" border="0" cellspacing="4" cellpadding="10" height="100" bgcolor="#444466">
<tr>
<td bgcolor="#000000" align="left" valign="top">
<tt class="moji1">
$log
</tt>
</td>
</tr>
</table>

<br>
EOM
}

	my @metu=('','(��)');
	my $reset_time_out = int(($set-$time)/(3600*24));
	print <<"EOM";
<table width="100%" border="0" cellspacing="4" cellpadding="4" bgcolor="#444466">
<tr>
<td bgcolor="#000000" align="center">
<tt class="moji1">
$bmes
</tt>
</td>
</tr>
</table>

<br>

<table width="100%" border="0" cellspacing="4" cellpadding="0" bgcolor="#444466">
<tr>
<td bgcolor="#000000" align="left" valign="top">
<!-- $rst�׸��� ����� �ִ� ǥ�� -->
<table border=0 cellpadding=2 cellspacing=2 width=100% align=center>
<tr>
<td bgcolor=#CCCCFF width=72>&nbsp;</td>
<td bgcolor=$color[1] align=center width=92>$cmp[1]$metu[$ce1]</td>
<td bgcolor=$color[2] align=center width=92>$cmp[2]$metu[$ce2]</td>
<td bgcolor=$color[3] align=center width=92>$cmp[3]$metu[$ce3]</td>
<td bgcolor=$color[4] align=center width=92>$cmp[4]$metu[$ce4]</td>
<td bgcolor=$color[5] align=center width=92>$cmp[5]$metu[$ce5]</td>
</tr>
<tr>
<td bgcolor=#CCCCFF>����</td>
<td bgcolor=$color[1] align=center>$cn1</td>
<td bgcolor=$color[2] align=center>$cn2</td>
<td bgcolor=$color[3] align=center>$cn3</td>
<td bgcolor=$color[4] align=center>$cn4</td>
<td bgcolor=$color[5] align=center>$cn5</td>
</tr>
<tr>
<td bgcolor=#CCCCFF>����</td>
<td bgcolor=$color[1] align=center>$cg1</td>
<td bgcolor=$color[2] align=center>$cg2</td>
<td bgcolor=$color[3] align=center>$cg3</td>
<td bgcolor=$color[4] align=center>$cg4</td>
<td bgcolor=$color[5] align=center>$cg5</td>
</tr>
<tr>
<td bgcolor=#CCCCFF>�ķ�</td>
<td bgcolor=$color[1] align=center>$cf1</td>
<td bgcolor=$color[2] align=center>$cf2</td>
<td bgcolor=$color[3] align=center>$cf3</td>
<td bgcolor=$color[4] align=center>$cf4</td>
<td bgcolor=$color[5] align=center>$cf5</td>
</tr>
<tr><td bgcolor=#CCCCFF>����</td>
<td bgcolor=$color[1] align=center>$cs1</td>
<td bgcolor=$color[2] align=center>$cs2</td>
<td bgcolor=$color[3] align=center>$cs3</td>
<td bgcolor=$color[4] align=center>$cs4</td>
<td bgcolor=$color[5] align=center>$cs5</td>
</tr>
<tr>
<td bgcolor=#CCCCFF>�ο�</td>
<td bgcolor=$color[1] align=center>$c1/$c1a</td>
<td bgcolor=$color[2] align=center>$c2/$c2a</td>
<td bgcolor=$color[3] align=center>$c3/$c3a</td>
<td bgcolor=$color[4] align=center>$c4/$c4a</td>
<td bgcolor=$color[5] align=center>$c5/$c5a</td>
</tr>
<tr>
<td bgcolor=#CCCCFF>�ν�</td>
<td bgcolor=$color[1] align=center>$pm1/100</td>
<td bgcolor=$color[2] align=center>$pm2/100</td>
<td bgcolor=$color[3] align=center>$pm3/100</td>
<td bgcolor=$color[4] align=center>$pm4/100</td>
<td bgcolor=$color[5] align=center>$pm5/100</td>
</tr>

</table>
<!-- ������� -->
</td>
</tr>
</table>

</td>
<td align="right" valign="top" width="190">

<table width="190" border="0" cellspacing="4" cellpadding="4" bgcolor="#444466" height="140">
<tr>
<td bgcolor="#000000" align="left" valign="top" class="moji2">
<div align="center">- System Infomation -</div>
<hr size="2" noshade color="#9999bb" width="100%">
&nbsp;&nbsp;�� $goal_no ��<br>
&nbsp;&nbsp;���� ���ѱ��� $reset_time_out ��
</div>
</td>
</tr>
</table>

<br>

<table width="190" border="0" cellspacing="4" cellpadding="4" bgcolor="#444466">
<tr>
<td bgcolor="#000000" align="left" valign="top" class="moji2">
���� �Ѽ�: $all_mem �� / $sanka �� ����<br>
���� ����: $data_reset&nbsp;&nbsp;���̵�: $reset_point
<hr size="2" noshade color="#9999bb"width=160>
��ȸ�� ����: $hasya [$cmp[$hcamp]]
</td>
</tr>
</table>

</td>
</tr>
</table>

EOM
}





1;