#!/usr/bin/perl -w

require "ore_config.cgi";

print "Content-type: text/html\n\n";
print <<"_HERE_";
<HTML>
<HEAD>
<meta http-equiv="content-type" content="text/html; charset=euc-kr">
<title>Icon Preview</title>
<link rel="stylesheet" type="text/css" href="$css">
<style>
<!--
body {margin:0 0 0 0}
//-->
</style>
</HEAD>
<BODY $body>
<CENTER>
_HERE_

      print "<table border=1 cellspacing=0 bordercolordark=black bordercolorlight=white align=center>\n";
      print "<tr align=center>\n";
	$i=0;$y=0;
	foreach (0..$CHARA_IMAGE){
		$t++;
		if($t eq 1){print "<tr>"}
		if($t < 11){print "<td align=center><img src=\"$cimgs/$_.gif\"><br><font color=white>$_</font></td>"}
		if($t eq 10){print "</tr>\n";$t=0;}
	}
      print "</tr></table>\n";

print <<"_HERE_";
</center>
</body>
</html>
_HERE_
