#!/usr/bin/perl

$ver = "v1.08";
#| SLIME BREEDER plus
#| by tatuta (2000/05/27-2002/03/25)
#| tatuta@geocities.co.jp
#| HomePageUrl http://www2j.biglobe.ne.jp/~tatuta/_MENU.htm

# ----------------------------------------------------------
# 각종 설정
# ----------------------------------------------------------

$backurl   = '../';					# 복귀 페이지 URL
$backtitle = '홈';		# 복귀 페이지 제목

$ps_god = 'dna';		# 유전자 해석용 비밀번호
$ps_usr = 'usr';		# 사용자 파일 열람용 비밀번호
$ps_mna = 'sys';	# 시스템 해설 페이지용 비밀번호
# 관리자 영역에 비밀번호를 입력해 사용합니다.

$comtmax  = 50;	# 댓글 파일 최대 보관 수
$rankmax  = 70;	# 랭킹 최대 보관 수
$dendo    = 4;	# 명예의 전당 입성 방어 횟수
$rensen   = 5;	# $rensen위이상은포인트에관계없이전투
$wait     = 30;	# 다음 교배까지 대기 시간(분)
$ipwait   = 5;	# 같은 IP의 다른 사용자 대기 시간(분)
$userwait = 7;	# 사용자 파일 보존 기간(일)
$lockwait = 25;	# 잠금 파일 최대 대기 시간(초)
$usermax  = 300;# 최대 사용자 수. 300명을 넘으면 로그 손실 위험이 커집니다
$files_bk = 3;	# 백업 파일 수(사용하지 않을 경우$files_bk = 0)
$interval_bk = 20;	# 백업 간격(시간)
$tmp_autodel = 1;	# tmp 파일 자동 정리 기능(사용=1 사용 안 함=0)

$cginame     = 'slm.cgi';				# 이 CGI 파일 이름
$userfile    = 'slmuser.cgi';		# 사용자 관리
$rankfile    = 'slmrank.cgi';		# 랭킹
$kingfile    = 'slmking.cgi';		# 명예의 전당
$comtfile    = 'slmcomt.cgi';		# 댓글 파일
$sirefile    = 'slmsire.cgi';		# 부계 계통 파일
$wgtfile     = 'slmwgt.cgi';		# 평균 체중 파일
$deffile     = 'slmdef.cgi';		# 방어전 결과 파일
$timefile    = 'slmtime.cgi';		# 백업 시간 기록 파일
# 위 파일 이름에는 ./ 등을 붙이지 마세요.
# 모두 slm.cgi와 같은 위치에 두세요.

$imgdir = "./";
# 이미지가 있는 디렉터리(마지막 /까지 넣어 주세요)
# slm.cgi와 같은 위치라면 그대로 두세요

$bg_gif       = 'slmbg.gif';		# 배경 GIF
$bg_gif2      = 'slmbg2.gif';		# 명예의 전당용배경 GIF
$char_normal  = "slmnormal.gif";
$char_aura    = "slmaura.gif";
$char_hider   = "slmhider.gif";
$char_wing    = "slmwing.gif";
$char_ribbon  = "slmribbon.gif";
$char_ribbonw = "slmribbonw.gif";
$char_crown   = "slmcrown.gif";
$char_crownw  = "slmcrownw.gif";
$char_angel   = "slmangel.gif";
$char_devil   = "slmdevil.gif";
$char_aho     = "slmaho.gif";
$char_oyaji   = "slmoyaji.gif";
$char_musi    = "slmmusi.gif";
$char_zombie  = "slmzombie.gif";

# ----------------------------------------------------------
# 초기 변수
# ----------------------------------------------------------

$seed_gage = $rankmax * 10;	# 씨앗 생성 속도(작을수록 빠르고 클수록 느림)
$henka = 200;	# 돌연변이 확률 1/$henka(변이체 출현율이 아닙니다)

@stat = ("H P","STM","STR","DEX","AGL","SPD");
$eve =<<"_EOF_";
0<p><p>이브<p>0<p><p><p>#7f7f7f<p>$char_normal<p>50<>500<>500<>50<>50<>50<>50<>50<>50<>50<p>50<>50<s>50<>50<s>50<>50<s>50<>50<s>50<>50<s>50<>50<s>30<>50<s>50<>50<s>50<>50<s>50<>50<s>0<s>0<s>0<s>0<s>0<s>0<s>0<s>0<s>0<m>50<>50<s>50<>50<s>50<>50<s>50<>50<s>50<>50<s>50<>50<s>30<>50<s>50<>50<s>50<>50<s>50<>50<s>1<s>1<s>1<s>1<s>1<s>1<s>1<s>1<s>1<p><><><s><><><s><><><s><><><s><><><s><><><s><><><s><><><s><><><s><><><s><><><s>0<><>0000000<s><><><s>0<><>0000000<p><p>1<p>d
_EOF_

# ----------------------------------------------------------
# 초기 설정
# ----------------------------------------------------------

&check_code;
&read_form;
srand (time ^ ($$ + ($$ << 15)));

# ----------------------------------------------------------
# HTML
# ----------------------------------------------------------

$html_head=<<"_EOF_";
Content-type: text/html; charset=UTF-8

<HTML>
<HEAD>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
<TITLE>SLIME BREEDER plus</TITLE>
</HEAD>
<BODY BGCOLOR="#000000" TEXT="#eeeeee" LINK="#00FFFF" VLINK="#7FFFFF">
<BASEFONT SIZE=3 FACE="Arial, sans-serif">
_EOF_

$html_foot=<<"_EOF_";
<HR>
<!-- 저작권표시 (생략 금지, 반드시 표시할 것) -->
<DIV ALIGN="right">
<FONT color="#7f7fff" FACE="Times New Roman"><i><B>SLIME BREEDER<sup>+</sup></B> $ver </FONT>Copyright &copy;1999-2002 <A HREF="http://www2j.biglobe.ne.jp/~tatuta/_MENU.htm" target="_top">tatuta</A>.</i><BR>
</DIV>

</BODY></HTML>
_EOF_

$navibar0=<<"_EOF_";
[<A HREF="$backurl" target="_top">$backtitle</A>][<A HREF="$cginame?mode=title" target="top">제목</A>][<A HREF="$cginame?mode=rank" target="bottom">랭킹</A>][<A HREF="$cginame?mode=klist" target="bottom">계통 목록</A>][<A HREF="$cginame?mode=king" target="bottom">명예의 전당</A>][<A HREF="$cginame?mode=skill" target="bottom">참가자</A>][<A HREF="$cginame?mode=guide" target="bottom">안내서</A>]
_EOF_

$navibar = "<DIV align=\"right\">$navibar0</DIV>";

# ----------------------------------------------------------
# 메인
# ----------------------------------------------------------

unless ($FORM{'mode'}) {
	&frame_set;
	if ($files_bk) {
		$time_backup = (&read ($timefile))[0];
		if ($time_backup < (time - $interval_bk * 3600)) { # 백업 시간
			$time_backup = (&read ($timefile,1))[0];
			&backup ($userfile);
			&backup ($kingfile);
			&backup ($sirefile);
			&backup ($deffile);
			&save ($timefile,time);
		}
	}
	&quit;
}
if ($FORM{'mode'} eq 'title') { &title_print; &quit; }
if ($FORM{'mode'} eq 'com') { &add_comt; &title_print; &quit; }
if ($FORM{'mode'} eq 'guide') { &guide; &quit; }
if ($FORM{'mode'} eq 'mania') { &mania; &quit; }
if ($FORM{'mode'} eq 'skill') { &skill; &quit; }

@rank = &read ($rankfile);
&wgt_set;

if ($FORM{'mode'} eq 'rank') { &rank_print; &quit; }
if ($FORM{'mode'} eq 'enter') { &enter_print; &quit; }
if ($FORM{'mode'} eq 'create') { &create; &quit; }
if ($FORM{'mode'} eq 'fight') { &fight; &quit; }
if ($FORM{'mode'} eq 'king') { &king_print; &quit; }
if ($FORM{'mode'} eq 'god') {
	if ($FORM{'pass'} eq $ps_god) { &rank_print; &quit; }
	if ($FORM{'pass'} eq $ps_usr) { &userfile; &quit; }
	if ($FORM{'pass'} eq $ps_mna) { &mania; &quit; }
	&king_print; &quit;
}
if ($FORM{'mode'} eq 'k') { &sire_print; &quit; }
if ($FORM{'mode'} eq 'kl') { &k_list; &quit; }
if ($FORM{'mode'} eq 'klist') { &k_list; &quit; }
if ($FORM{'mode'} eq 'def') { &def; &quit; }
&quit;

# ----------------------------------------------------------
# 프레임
# ----------------------------------------------------------

sub frame_set{
	print "Content-type: text/html; charset=UTF-8\n\n";
	print <<"_EOF_";
<HTML>
<HEAD>
<TITLE>SLIME BREEDER plus</TITLE>
</HEAD>

<FRAMESET ROWS="240,*">
	<FRAME SRC="$cginame?mode=title" NAME="top">
	<FRAME SRC="$cginame?mode=rank" NAME="bottom">
</FRAMESET>

<NOFRAMES>
<BODY BGCOLOR="#003f3f" TEXT="#eeeeee" LINK="#00FFFF" VLINK="#7FFFFF">
<CENTER>
<font size=5>프레임을 지원하지 않는 브라우저에서는 사용할 수 없습니다 m(__)m </font>
</BODY>
</NOFRAMES>
</HTML>
_EOF_
}

# ----------------------------------------------------------
# 평균 체중 결정
# ----------------------------------------------------------

sub wgt_set {
	if ($FORM{'mode'} eq 'create') {
		$wgt_sum = 0;
		foreach $line (@rank) {
			$status = (split(/<p>/,$line))[8];
			$wgt_sum += (split (/<>/,$status))[0];
		}
		if (@rank) { $wgt_ave = int ($wgt_sum / @rank);
		} else { $wgt_ave = 50;
		}
		&save ($wgtfile,"$wgt_ave");
	} else {
		@wgt = &read ($wgtfile);
		$wgt_ave = $wgt[0];
		unless ($wgt_ave) { $wgt_ave = 50; }
	}
	$disp_cut = length($wgt_ave) - 2;
	$tumble = 8;
	$range = int ($wgt_ave / 20) + 1;
# 위의 / 20에서 20을 변경하면 유전자의 안정도와 진화 속도가 달라집니다.
# 작게 하면 변화율이 커지고 진화 속도가 빨라집니다.
# 크게 하면 변화율이 작아지고 진화 속도가 느려집니다.
# 전승이 잘 나오지 않으면 조금 작게 조정해 보세요.
}

# ----------------------------------------------------------
# 타이틀 화면
# ----------------------------------------------------------

sub title_print {
	&get_cookie;
	if ($c_name eq '') {
		$comtname = "<INPUT type=\"text\" name=\"user\" size=16 value=\"이름\">";
	} else {
		$comtname = "$c_name<input type=\"hidden\" name=\"pass\" value=\"$c_pwd\"><INPUT TYPE=\"hidden\" NAME=\"user\" VALUE=\"$c_name\">";
	}
	print $html_head;
	print<<"_EOF_";
<FORM ACTION="$cginame" METHOD=post>
$navibar0
<TABLE BORDER=0 width="100%" background="$imgdir$bg_gif">
<TR><TD>
<CENTER>
<FONT size=7 color="#7f7fff" FACE="Times New Roman"><i>SLIME BREEDER<sup>+</sup></i></FONT><BR>
<FONT SIZE=3 color="red" FACE="Times New Roman"><i>Endless Evolution</i></FONT><BR>
<BR>
<INPUT TYPE="hidden" NAME="mode" VALUE="enter">
사용자명<INPUT type="text" name="user" size=16 value="$c_name">
 비밀번호<input type="password" name="pass" size=8 maxlength=8 value="$c_pwd">
<INPUT TYPE="submit" VALUE="Enter">
</CENTER>
</FORM>
<FORM ACTION="$cginame" METHOD=post>
<small>
처음 이용하는 분은 여기에 입력한 정보로 등록됩니다. 중요한 비밀번호는 사용하지 마세요.<BR>
</small>
</TD></TR>
</TABLE>
<HR>
<INPUT TYPE="hidden" NAME="mode" VALUE="com">
한마디 댓글：$comtname<INPUT type="text" name="comt" size=60>
<INPUT TYPE="submit" VALUE="등록">(150자 이내)
<HR>
_EOF_

	@comt = &read ($comtfile);
	foreach $line (@comt) {
		($date,$name,$comt,$dmy) = split(/<>/,$line);

$comt_date = "<FONT COLOR=\"#ffb0ff\">$date</FONT>";				# 날짜
$comt_name = "<FONT COLOR=\"#b0ffff\"><B>$name</B></FONT>";	# 이름
$comt_text = "<B>「$comt」</B>";														# 본문

		print "$comt_date $comt_name$comt_text<HR>\n";
	}	
	print<<"_EOF_";
</FORM>
<FORM ACTION="$cginame" METHOD="post" target="bottom">
<DIV align="right">
<INPUT TYPE="hidden" NAME="mode" VALUE="god">
관리자 영역<INPUT TYPE="password" NAME="pass" SIZE=8>
<INPUT TYPE="submit" VALUE="열기">
</DIV>
</FORM>

_EOF_
	print $html_foot;
}

sub add_comt {
	@comt = &read ($comtfile,1);
	$date = &date(time);
	$name = $FORM{'user'};
	$comt = $FORM{'comt'};
	$ipad = $ENV{'REMOTE_ADDR'};
	($d,$checkname,$checktext) = split (/<>/,$comt[0]);
	if (length($comt) > 300) { $comt = substr($comt,0,300); }
	if (length($name) > 16) { $name = substr($name,0,16); }
	unless ($FORM{'pass'}) { $name .= "?"; }
	if ($comt eq '') {
		&error(1,'내용을 입력해 주세요.');
	}
	if ($comt eq $checktext && $name eq $checkname) {
		&error(1,'중복 등록입니다.');
	}
	unshift(@comt,"$date<>$name<>$comt<>$ipad\n");
	while (@comt > $comtmax) { pop @comt; }
	&save ($comtfile,@comt);
}

# ----------------------------------------------------------
# 랭킹 화면
# ----------------------------------------------------------

sub rank_print {
	$rank_end = int ($rankmax / 2);
	$rank_str = int ($rankmax / 2) + 1;
	$ranknavi=<<"_EOF_";
[<a href="$cginame?mode=rank">1〜$rank_end위</a>][<a href="$cginame?mode=rank&page=1">$rank_str〜$rankmax위</a>][<a href="$cginame?mode=rank&page=all">ALL</a>]<br>
_EOF_
	$link[1] = "[<a href=\"$cginame?mode=def\">방어전</a>]";
	print $html_head;
	print<<"_EOF_";
$navibar
<FONT SIZE=5 COLOR=yellow>랭킹</FONT><br>
$ranknavi<br>
_EOF_
	if ($FORM{'page'} eq "all" || $FORM{'mode'} eq 'god') {
		$rank = 1;
		$last = @rank;
	} elsif ($FORM{'page'} && @rank > $rank_end) {
		$rank = int ($rankmax / 2) + 1;
		$last = @rank;
	} else {
		$rank = 1;
		if (@rank > $rank_end) {
			$last = $rank_end;
		} else {
			$last = @rank;
		}
	}
	until ($rank > $last) {
		&stp1 ($rank[$rank - 1]);
		$rank++;
	}
	print "<CENTER>$ranknavi<hr>$navibar0</CENTER>";
	print $html_foot;
}

sub stp1 {
	local ($line) = $_[0];
	($pts,$no,$name,$sedai,$d,$d,$color,$d,$d,$d,$d,$seed,$child,$result,$d,$highrank) = split (/<p>/,$line);
	if ($seed != 0) { $seed = "<FONT COLOR=\"yellow\">$seed</FONT>"; }
	($win,$lose) = split(/<>/,$result);
	print "<a name=\"$no\"></A>\n";
	print "<big><B>제$rank위 <FONT COLOR=\"\#ffb0ff\">$name</B></FONT></big><small>$sedai</small> 씨앗$seed개 자식$child마리 $win승$lose패 최고$highrank$pts<small>pts.</small> $link[$rank]$print_variety<BR>\n";
	if ($FORM{'mode'} eq 'god') {
		$print = &god_print ($line);
	} else { $print = &status_print ($line); }
	print $print;
	print "<HR>\n\n";
}

sub status_print {
	local ($data) = $_[0];
	($d,$d,$name,$sedai,$owner,$time,$color,$gif,$status,$d,$blood) = split (/<p>/,$data);
	$birth = &date ($time);
	@status = split (/<>/,$status);

	$i = 0;
	$yuko = 4 - (length ($status[0]) - $disp_cut);
	foreach $line (@status) {
		$statusp[$i] = int ($status[$i] / (10 ** $disp_cut) + 0.5);
		if ($FORM{'mode'} eq 'king' && $statusp[$i] < 3) {
			$statusp[$i] = $status[$i] / (10 ** $disp_cut);
			$statusp[$i] = substr ($statusp[$i],0,$yuko);
		}
		$i++;
	}
# 0=WGT 1=HP 2=STM 3=STR 4=DEX 5=AGL 6=CST 7=SEX 8=SPD
	@blood = split (/<s>/,$blood);
	for ($i = 0; $i < 14; $i++) {
		($b_no[$i],$b_name1[$i],$b_sedai[$i]) = split (/<>/,$blood[$i]);
		$b_name[$i] = "<FONT COLOR=\"#00ffff\">$b_name1[$i]</FONT>";
		if ($FORM{'mode'} eq 'rank') {
			$b_name[$i] = "<A href=\"\#$b_no[$i]\">$b_name1[$i]</A>";
		}
		if ($FORM{'mode'} eq 'create' || $FORM{'mode'} eq 'enter') {
			$b_name[$i] = "<A href=\"$cginame?mode=rank\#$b_no[$i]\" target=\"bottom\">$b_name1[$i]</A>";
		}
	}
	$gif_size = int (($status[0] / $wgt_ave) ** (1/2) * 100);
	if ($gif_size < 33) { $gif_size = 33; }
	if ($FORM{'mode'} eq 'create') {
		$kfit = "<FONT SIZE=2>혈통 상성：$status[9]</FONT><BR>";
	}
$html_status=<<"_EOF_";
<TABLE BORDER=1 BGCOLOR="#003f3f" bordercolordark="lightblue">
<TR><TD align="center" valign="middle" width=140>
	<TABLE BORDER=0 bgcolor="$color" cellpadding=0 cellspacing=0>
	<TR><TD><IMG SRC="$imgdir$gif" width=$gif_size height=$gif_size></TD></TR>
	</TABLE>
	<FONT SIZE=2>weight:$status[0]<BR>$b_name1[13]계<BR></FONT>
	</TD>
	<TD background="$imgdir$bg_gif">
	<TABLE BORDER=1 width=100%>
	<TR><TH>제$sedai대: $birth 출생</TH><TH>H P</TH><TH>STM</TH><TH>STR</TH><TH>DEX</TH><TH>AGL</TH><TH>SPD</TH></TR>
	<TR><TH>오너：$owner</TH><TH>$statusp[1]</TH><TH>$statusp[2]</TH><TH>$statusp[3]</TH><TH>$statusp[4]</TH><TH>$statusp[5]</TH><TH>$statusp[8]</TH></TR>
	</TABLE>
	<TABLE BORDER=1 width=100%>
	<TR><TD valign="middle">
		$b_name[0]<small><FONT COLOR="pink">$b_sedai[0]</FONT></small><BR>
		</TD>
	<TD valign="middle">
		<FONT SIZE=2>$b_name[2] <FONT COLOR="pink">$b_sedai[2]</FONT></FONT><BR>
		<FONT SIZE=2>$b_name[3] $b_sedai[3]</FONT><BR>
		</TD>
	<TD valign="middle">
		<FONT SIZE=2>$b_name[6] $b_sedai[6]</FONT><BR>
		<FONT SIZE=2>$b_name[7] $b_sedai[7]</FONT><BR>
		</TD>
	<TD valign="middle">
		<FONT SIZE=2>$b_name1[10] $b_no[10]계</FONT><BR>
		<FONT SIZE=2 color="orange">$b_name1[11] $b_no[11]계</FONT><BR>
		</TD>
	</TR>
	<TR><TD valign="middle">
		$b_name[1]<small>$b_sedai[1]</small><BR>
		</TD>
	<TD valign="middle">
		<FONT SIZE=2>$b_name[4] <FONT COLOR="pink">$b_sedai[4]</FONT></FONT><BR>
		<FONT SIZE=2>$b_name[5] $b_sedai[5]</FONT><BR>
		</TD>
	<TD valign="middle">
		<FONT SIZE=2>$b_name[8] $b_sedai[8]</FONT><BR>
		<FONT SIZE=2>$b_name[9] $b_sedai[9]</FONT><BR>
		</TD>
	<TD valign="middle">
		<FONT SIZE=2>$b_name1[12] $b_no[12]계</FONT><BR>
		<a href="$cginame?mode=k&kno=$b_no[13]" target="bottom">
		<FONT SIZE=2 color="yellow">$b_name1[13] $b_no[13]계</FONT></a><BR>
		</TD>
	</TR>
	</TABLE>
	</TD>
</TR>
</TABLE>
$kfit
_EOF_
	return $html_status;
}

# 명예의 전당

sub king_print {
	@king = &read ($kingfile);
	$bg_gif = $bg_gif2;
	print $html_head;
	print<<"_EOF_";
$navibar
<FONT SIZE=6 color=\"#7f7fff\" FACE=\"serif\">명예의 전당</FONT><BR><BR>
_EOF_
	foreach $line (@king) {
		&stp2 ($line);
	}
	print $html_foot;
}

sub stp2 {
	local ($line) = $_[0];
	($pts,$no,$name,$sedai,$d,$d,$color,$d,$d,$d,$d,$d,$child,$result,$d,$highrank) = split(/<p>/,$line);
	($win,$lose) = split(/<>/,$result);
	$lose--;
	($d,$defend) = split(/<sup>/,$highrank);
	$defend += 0;
	$star = substr("★★★★★★★★★★★★★★★★★★★★★★★★★",0,$defend * 2);
	$daime = "";
	($bdai,$point) = split(/<>/,$pts);
	if ($point) {
		$daime = "<FONT FACE=\"serif\">$bdai대째</font><FONT FACE=\"Times New Roman\"><big>Champion</big></FONT> ";
	}
	print "<B><FONT COLOR=\"\#dfcf3f\">$daime<big>$name</B></big><small>$sedai</small> 제$no자식 자식$child마리 $win승$lose패 방어회수$star<small>$defend</small></FONT><BR>\n";
	$print = &status_print ($line);
	print $print;
	print "<HR>\n\n";
}


# 유전자해석

sub god_print {
	local ($data) = $_[0];
	($d,$d,$name,$sedai,$owner,$time,$color,$gif,$status,$dna,$blood) = split (/<p>/,$data);
	$birth = &date ($time);
	@status = split (/<>/,$status);
# 0=WGT 1=HP 2=STM 3=STR 4=DEX 5=SPD 6=CST 7=SEX 
	@dna = split (/<m>/,$dna);
	for ($i = 0; $i < 2; $i++) {
		($hrd[$i],$msl[$i],$brn[$i],$net[$i],$fat[$i],$men[$i],$sex[$i],$sft[$i],$air[$i],$sns[$i],$r[$i],$g[$i],$b[$i],$x[$i],$y[$i],$z[$i],$u[$i],$v[$i],$w[$i])  = split (/<s>/,$dna[$i]);
	}
	@blood = split (/<s>/,$blood);
# 0=자신의 부모 1=상대 부모 2=자신의 부모부모 345=상대 부모부모 6=자신의 부모부모부모 7-13=상대 부모부모부모 
	for ($i = 0; $i < 14; $i++) {
		($b_no[$i],$b_name1[$i],$b_sedai[$i]) = split (/<>/,$blood[$i]);
		$b_name[$i] = "<A href=\"\#$b_no[$i]\">$b_name1[$i]</A>";
	}
	$gif_size = int (($status[0] / $wgt_ave) ** (1/3) * 100);

$html_status=<<"_EOF_";
<TABLE BORDER=1 BGCOLOR="#003f3f" bordercolordark="lightblue">
<TR><TD align="center" valign="middle">
	<TABLE BORDER=0 bgcolor="$color" cellpadding=0 cellspacing=0>
	<TR><TD><IMG SRC="$imgdir$gif" width=$gif_size height=$gif_size></TD></TR>
	</TABLE>
	<FONT SIZE=2>$color</FONT><BR>
	<FONT SIZE=2>weight:$status[0]</FONT><BR>
	<TABLE BORDER=1 BGCOLOR="#000000">
	<TR><TH>X</TH><TH>Y</TH><TH>Z</TH><TH>RBN</TH><TH>CRW</TH><TH>WNG</TH></TR>
	<TR><TH>$x[0]</TH><TH>$y[0]</TH><TH>$z[0]</TH><TH>$u[0]</TH><TH>$v[0]</TH><TH>$w[0]</TH></TR>
	<TR><TH>$x[1]</TH><TH>$y[1]</TH><TH>$z[1]</TH><TH>$u[1]</TH><TH>$v[1]</TH><TH>$w[1]</TH></TR>
	</TABLE>
	</TD>
	<TD BGCOLOR="#000000">
	<TABLE BORDER=1>
	<TR><TH>제$sedai대: $birth 출생</TH><TH>HP</TH><TH>STM</TH><TH>STR</TH><TH>DEX</TH><TH>AGL</TH><TH>SPD</TH><TH>CST</TH><TH>SEX</TH><TH>혈통 상성</TH></TR>
	<TR><TH>오너：$owner</TH><TH>$status[1]</TH><TH>$status[2]</TH><TH>$status[3]</TH><TH>$status[4]</TH><TH>$status[5]</TH><TH>$status[8]</TH><TH>$status[6]</TH><TH>$status[7]</TH><TH>$status[9]</TH></TR>
	</TABLE>
	<TABLE BORDER=1>
	<TR><TH>HRD</TH><TH>MSL</TH><TH>BRN</TH><TH>NET</TH><TH>FAT</TH><TH>MEN</TH><TH>SEX</TH><TH>SFT</TH><TH>AIR</TH><TH>SNS</TH></TR>
	<TR><TH>$hrd[0]</TH><TH>$msl[0]</TH><TH>$brn[0]</TH><TH>$net[0]</TH><TH>$fat[0]</TH><TH>$men[0]</TH><TH>$sex[0]</TH><TH>$sft[0]</TH><TH>$air[0]</TH><TH>$sns[0]</TH></TR>
	<TR><TH>$hrd[1]</TH><TH>$msl[1]</TH><TH>$brn[1]</TH><TH>$net[1]</TH><TH>$fat[1]</TH><TH>$men[1]</TH><TH>$sex[1]</TH><TH>$sft[1]</TH><TH>$air[1]</TH><TH>$sns[1]</TH></TR>
	</TABLE>
	<TABLE BORDER=1>
	<TR><TD valign="middle">
		$b_name[0]<sub>$b_sedai[0]</sub><BR>
		<HR>
		$b_name[1]<sub>$b_sedai[1]</sub><BR>
		</TD>
	<TD valign="middle">
		<FONT SIZE=2>$b_name[2] $b_sedai[2]</FONT><BR>
		<FONT SIZE=2>$b_name[3] $b_sedai[3]</FONT><BR>
		<HR>
		<FONT SIZE=2>$b_name[4] $b_sedai[4]</FONT><BR>
		<FONT SIZE=2>$b_name[5] $b_sedai[5]</FONT><BR>
		</TD>
	<TD valign="middle">
		<FONT SIZE=2>$b_name[6] $b_sedai[6]</FONT><BR>
		<FONT SIZE=2>$b_name[7] $b_sedai[7]</FONT><BR>
		<HR>
		<FONT SIZE=2>$b_name[8] $b_sedai[8]</FONT><BR>
		<FONT SIZE=2>$b_name[9] $b_sedai[9]</FONT><BR>
		</TD>
	<TD valign="middle">
		<FONT SIZE=2>$b_name1[10] $b_no[10]계 $b_sedai[10]</FONT><BR>
		<FONT SIZE=2 color="orange">$b_name1[11] $b_no[11]계 $b_sedai[11]</FONT><BR>
		<HR>
		<FONT SIZE=2>$b_name1[12] $b_no[12]계 $b_sedai[12]</FONT><BR>
		<FONT SIZE=2 color="yellow">$b_name1[13] $b_no[13]계 $b_sedai[13]</FONT><BR>
		</TD>
	</TR>
	</TABLE>
	</TD>
</TR>
</TABLE>

_EOF_
	return $html_status;
}

# 사용자 파일

sub userfile {
	@user = &read ($userfile);
	$usersuu = @user;
	$rnd_range = ($tumble * $range - $tumble) / 2;
	print $html_head;
	print "$navibar<B>사용자 파일</B><BR>\n";
	print "사용자 수: $usersuu 평균 체중: $wgt_ave 주사위: $range면체 $tumble개 ±$rnd_range<BR><BR>\n";
	foreach $line (@user) {
		($no,$ip,$name,$sedai,$owner,$time,$color,$gif,$status,$d,$blood) = split(/<p>/,$line);
		$birth = &date ($time);
		@status = split (/<>/,$status);
		$i = 0;
		foreach $line (@status) {
			$statusp[$i] = int ($status[$i] / (10 ** $disp_cut) + 0.5);
			$i++;
		}
# 0=WGT 1=HP 2=STM 3=STR 4=DEX 5=SPD 6=CST 7=SEX 
	@blood = split (/<s>/,$blood);
# 0=자신의 부모 1=상대 부모 2=자신의 부모부모 345=상대 부모부모 6=자신의 부모부모부모 7-13=상대 부모부모부모 
	for ($i = 0; $i < 2; $i++) {
		($b_no[$i],$b_name1[$i],$b_sedai[$i]) = split (/<>/,$blood[$i]);
		$b_name[$i] = "$b_name1[$i] $b_sedai[$i]";
	}
	print<<"_EOF_";
<TABLE BORDER=1 BGCOLOR="#003f3f" bordercolordark="lightblue">
<TR><TD align="center" valign="middle">
	<TABLE BORDER=0 bgcolor="$color" cellpadding=0 cellspacing=0>
	<TR><TD><IMG SRC="$imgdir$gif" width=40 height=40></TD></TR>
	</TABLE>
	<FONT SIZE=2>weight:$status[0]</FONT><BR>
	</TD>
	<TD bgcolor="black">
	<TABLE BORDER=1>
	<TR><TH>$birth $name</TH><TH>HP</TH><TH>STM</TH><TH>STR</TH><TH>DEX</TH><TH>AGL</TH><TH>SPD</TH><TH>$b_name[1]</TH></TR>
	<TR><TH>$sedai대 "$owner" 제$no자식</TH><TH>$statusp[1]</TH><TH>$statusp[2]</TH><TH>$statusp[3]</TH><TH>$statusp[4]</TH><TH>$statusp[5]</TH><TH>$statusp[8]</TH><TH>$ip</TH></TR>
	</TABLE>
	</TD>
</TR>
</TABLE>
<HR>
_EOF_
	}
	print<<"_EOF_";
<CENTER>
[<A HREF="$backurl" target="_top">$backtitle</A>][<A HREF="$cginame?mode=title" target="top">제목</A>][<A HREF="$cginame?mode=rank">랭킹</A>]<BR>
</CENTER>
_EOF_
	print $html_foot;
}

# 계통목록

sub k_list {
	@king = &read ($kingfile);
	print $html_head;
	print $navibar;
	if ($FORM{'mode'} eq 'kl') {
		print "<FONT SIZE=5 COLOR=yellow>계통 대표 슬라임</FONT><BR><BR>";
		@sire = &read ($sirefile);
	} else { @sire = &read ($sirefile,1);
	}
	%klist =();
	$rank = 1;
	foreach $line (@rank) {
		$blood = (split (/<p>/,$line))[10];
		@blood = split (/<s>/,$blood);
		($kno,$kname,$knx) = split (/<>/,$blood[13]);
		if ($klist{"$kno"}) {
			($k_cnt,$k_no,$k_name,$k_nx,$k_old) = split (/<>/,$klist{"$kno"});
			$k_cnt++;
			$klist{"$kno"} = "$k_cnt<>$k_no<>$k_name<>$k_nx<>$k_old<>\n";
		} else {
			$old = '';
			foreach $sire (@sire) {
				if ($kno eq (split (/<>/,$sire))[1]) {
					$old = (split (/<>/,$sire))[4];
				}
			}
			if (length($knx) < 7) { $knx = &seven ($knx); }
			$klist{"$kno"} = "1<>$kno<>$kname<>$knx<>$old<>\n";
			if ($FORM{'mode'} eq 'kl') {
				print "<a name=\"$kno\"></A>\n";
				&stp1 ($line);
			}
		}
		$rank++;
	}
	$bg_gif = $bg_gif2;
	foreach $line (@king) {
		$blood = (split (/<p>/,$line))[10];
		@blood = split (/<s>/,$blood);
		($kno,$kname,$knx) = split (/<>/,$blood[13]);
		unless ($klist{"$kno"}) {
			$old = '';
			foreach $sire (@sire) {
				if ($kno eq (split (/<>/,$sire))[1]) {
					$old = (split (/<>/,$sire))[4];
				}
			}
			if (length($knx) < 7) { $knx = &seven ($knx); }
			$klist{"$kno"} = "0<>$kno<>$kname<>$knx<>$old<>\n";
			if ($FORM{'mode'} eq 'kl') {
				print "<a name=\"$kno\"></A>\n";
				&stp2 ($line);
			}
		}
	}
	print<<"_EOF_";
<CENTER>
<br>
<FONT SIZE=5 COLOR=yellow>계통 목록</FONT><BR>
<form>
<TABLE BORDER=1 BGCOLOR="#003f3f">
<TR BGCOLOR="#003f7f" background=""><TH>순위</TH><TH>계통명</TH><TH>타입</TH><TH>총수</TH><TH>％</TH><TH>계보</TH></TR>
_EOF_
	@k_list = values %klist;
	@k_list = sort {$b <=> $a} @k_list;
	unless ($FORM{'mode'} eq 'kl') {
		&save ($sirefile,@k_list);
		$klink = "[<A HREF=\"$cginame?mode=kl\">계통 대표 슬라임목록</A>]";
	}
	$rank = 1;
	foreach $line (@k_list) {
		($cnt,$no,$name,$nx,$old) = split (/<>/,$line);
		$mup = $stat[substr ($nx,6,1)];
		$per = int ($cnt / @rank * 100);
		$pold = "<select>\n";
		if ($old) {
			@temp = split (/<p>/,$old);
			$pre = 1;
			foreach $temp (@temp) {
				($ono,$oname,$onx) = split (/<s>/,$temp);
				if ($pre == 1) { $pold .= "<option> 시조 $oname $ono계\n";
				} else { $pold .= "<option>$pre대째 $oname $ono계\n";
				}
				$pre++;
			}
			$pold .= "<option>$pre대째 $name $no계\n";	
		} else { $pold .= "<option> 시조 $name $no계\n";
		}
		$pold .= "</select>\n";
		if ($FORM{'mode'} eq 'kl') {
			print "<TR><TH>$rank</TH><TD><A href=\"\#$no\">$name $no</A></TD><TD align=\"center\">$mup</TD><TD align=\"right\">$cnt마리</TD><TD align=\"right\">$per%</TD><TD>$pold</TD></TR>\n";
		} elsif($cnt > 0) {
			print "<TR><TH>$rank</TH><TD><A HREF=\"$cginame?mode=k&kno=$no\">$name $no</A></TD><TD align=\"center\">$mup</TD><TD align=\"right\">$cnt마리</TD><TD align=\"right\">$per%</TD><TD>$pold</TD></TR>\n";
		}
		$rank++;
	}
	print "</TABLE></form>$klink<BR></CENTER><BR>\n";
	print $html_foot;
}

# 계통추출표시

sub sire_print {
	print $html_head;
	print<<"_EOF_";
$navibar
<br>
_EOF_
	%mom_variety = ();
	$mom_variety = 0;
	foreach $line ($FORM{"mmd"},$FORM{"mom"},$FORM{"dmd"},$FORM{"dad"}) {
		unless ($mom_variety{$line}) {
			$mom_variety{$line} = 1;
			$mom_variety += 1;
		}
	}
	local ($i);
	$rank = 1;
	$found = 0;
	foreach $line (@rank) {
		$blood = (split (/<p>/,$line))[10];
		@blood = split (/<s>/,$blood);
		($kno,$kname,$knx) = split (/<>/,$blood[13]);
		if ($kno eq $FORM{"kno"}) {
			if ($blood[11] == $FORM{"mom"} || $blood[11] == $FORM{"dad"} || $blood[11] == $blood[13]) {
				print "<font color=\"orange\">\n";
				$fontend = "</font>\n";
			} else { $fontend = "";
			}
			if ($FORM{"dad"}) {
				$print_variety = "";
				%seed_variety = ();
				$variety = $mom_variety;
				for ($i = 10; $i <= 13; $i++) {
					if ($mom_variety{($blood[$i] + 0)} || $seed_variety{($blood[$i] + 0)}) {
					} else {
						$seed_variety{($blood[$i] + 0)} = 1;
						$variety += 1;
					}
				}
				$print_variety = "계통$variety씨앗";
			}
			&stp1 ($line);
			print $fontend;
			$found = 1;
		}
		$rank++;
	}
	unless ($found) {
		@king = &read ($kingfile);
		foreach $line (@king) {
			$blood = (split (/<p>/,$line))[10];
			@blood = split (/<s>/,$blood);
			($kno,$kname,$knx) = split (/<>/,$blood[13]);
			if ($kno eq $FORM{"kno"}) {
				&stp2 ($line);
			}
		}
	}
	if ($FORM{"dad"}) {
		print "<small>첫 줄이 <font color=\"orange\">오렌지색</font>으로 표시된 교배 상대와는 충분한 닉스 효과를 얻을 수 없습니다.</small>\n";
	}
	print $html_foot;
}

# 브리더 랭킹

sub skill {
	@users = &read ($userfile);
	foreach $line (@users) {
		($play,$wins,$winz,$skill,$rate) = split(/<>/,(split(/<p>/,$line))[13]);
		if ($skill) {
			$name = (split (/<p>/,$line))[4];
			push (@line,"$skill<>$name<>$play<>$wins<>$rate<>\n");
		}
	}
	@line = sort {$b <=> $a} @line;
	print $html_head;
	print $navibar;
	print<<"_EOF_";
<CENTER>
<br>
<FONT size=5 color="yellow" FACE="Times New Roman">Breeder Ranking</FONT><BR>
<TABLE BORDER=1 BGCOLOR="#003f3f">
<TR BGCOLOR="#003f7f" background=""><TH>RANK</TH><TH>NAME</TH><TH>SKILL</TH><TH>PLAY</TH><TH>WIN</TH><TH>RATE</TH></TR>
_EOF_
	$rank = 1;
	foreach $line (@line) {
		($skill,$name,$play,$wins,$rate) = split(/<>/,$line);
		if ($rank > 20) {
			print "<option>$rank위 $name [$skill] P[$play] W[$wins] R[$rate]\n";
		} else {
			print "<TR><TH>$rank</TH><TD><b>$name</b></TD><TD align=\"center\"><b>$skill</b></TD><TD align=\"center\">$play</TD><TD align=\"center\">$wins</TD><TD>$rate</TD></TR>\n";
		}
		if ($rank == 20) {
			print "</table><form><select>\n";
		}
		$rank++;
	}
	if ($rank < 21) { print "</table>\n";
	} else { print "</select></form>\n";
	}
	print<<"_EOF_";
</center>
<br><br>
<small>
SKILL：높을수록 플레이가 능숙하다고 볼 수 있습니다. 연승할수록 높아집니다.<br>
PLAY ：슬라임을 낳은 횟수입니다.<br>
WIN　：승리 횟수입니다.<br>
RATE ：WIN / PLAY 출산 1회당 승리 비율입니다.<br>
<br>
성적 집계는 출산 직후 전투만 대상으로 하며, 랭킹에 오른 뒤의 전투는 포함하지 않습니다.<br>
</small>
_EOF_
	print $html_foot;
}

# 방어전결과

sub def {
	@def = &read ($deffile,1);
	unless ($def[0] == 0) {
		($fdate,$bcnt,$bdai) = split (/<>/,$def[0]);
		$fdate = &date ($fdate);
		($u_pts,$u1,$u_name,$u_sedai,$u4,$u5,$u_color,$u7,$u_status,$u9,$v0,$v1,$v2,$u_result,$v4,$v5) = split(/<p>/,$def[1]);
		($u_win,$u_lose) = split(/<>/,$u_result);
		$print1 = &status_print ($def[1]);
		($e_pts,$a1,$e_name,$e_sedai,$a4,$a5,$e_color,$a7,$e_status,$a9,$b0,$b1,$b2,$e_result,$b4,$b5) = split(/<p>/,$def[2]);
		($e_win,$e_lose) = split(/<>/,$e_result);
		($dmy,$defend) = split(/<sup>/,$b5);
		$defend += 0;
		$print2 = &status_print ($def[2]);
		($hp[0],$maxhp[0],$pow[0],$hit[0],$attack[0],$dmg_ave[0],$luck_atk[0],$luck_hit[0]) = split(/<>/,$def[3]);
		($hp[1],$maxhp[1],$pow[1],$hit[1],$attack[1],$dmg_ave[1],$luck_atk[1],$luck_hit[1]) = split(/<>/,$def[4]);
		$fightlog = $def[5];
		if ($hp[0] < 1) {
			$pdai = $bdai;
			$star = substr("★★★★★★★★★★★★★★★★★★★★★★★★★",0,$defend * 2);
			$result_msg=<<"_EOF_";
<FONT SIZE=7 color="yellow" FACE="Times New Roman"><i>CHAMPION WIN!</i></FONT><BR>
<FONT color="yellow">$star</font><br>
_EOF_
			$bgdw = " bgcolor=\"#00007f\"";
			$cmup = "<FONT COLOR=\"blue\"  FACE=\"Times New Roman\"><b><i>LOSE</i></b></FONT>";
			$cmdw = "<FONT COLOR=\"red\"  FACE=\"Times New Roman\"><b><i>WIN!</i></b></FONT>";
		} else {
			$pdai = $bdai - 1;
			$result_msg=<<"_EOF_";
<FONT SIZE=7 color="red" FACE="Times New Roman"><i>CHALLENGER WIN!</i></FONT><BR>
_EOF_
			$bgup = " bgcolor=\"#00007f\"";
			$cmup = "<FONT COLOR=\"red\"  FACE=\"Times New Roman\"><b><i>WIN!</i></b></FONT>";
			$cmdw = "<FONT COLOR=\"blue\"  FACE=\"Times New Roman\"><b><i>LOSE</i></b></FONT>";
		}
		$data=<<"_EOF_";
<!-- <>$bcnt<>$bdai<> -->
제$bcnt회 <FONT SIZE=5 COLOR=yellow FACE="serif"><b>왕좌방어전</b></FONT> ($fdate)<BR><BR>
<BIG><B><FONT COLOR="red"  FACE="Times New Roman">Challenger</FONT> <FONT COLOR="#ffb0ff">$u_name</FONT></B></BIG><small>$u_sedai</small> $u_win승$u_lose패 최고$v5$u_pts<small>pts.</small> $cmup<BR>
$print1
<hr>
<TABLE BORDER=0 cellspacing=0 cellpadding=2>
<TR$bgup><TD><FONT COLOR="red"  FACE="Times New Roman"><b>Challenger</b></FONT></TD><TD>$u_name </TD><TD>HP:<FONT COLOR="yellow">$hp[0]</FONT>/<sub>$maxhp[0]</sub> </TD><TD>STM:$pow[0]% </TD><TD>HIT$hit[0]</TD><TD>/ATTACK$attack[0]회 </TD><TD>DmgAve$dmg_ave[0] </TD><TD>LUCK:$luck_atk[0]($luck_hit[0])</TD></TR>
<TR$bgdw><TD><FONT COLOR="yellow"  FACE="Times New Roman"><b>Champion</b></FONT></TD><TD>$e_name </TD><TD>HP:<FONT COLOR="yellow">$hp[1]</FONT>/<sub>$maxhp[1]</sub> </TD><TD>STM:$pow[1]% </TD><TD>HIT$hit[1]</TD><TD>/ATTACK$attack[1]회 </TD><TD>DmgAve$dmg_ave[1] </TD><TD>LUCK:$luck_atk[1]($luck_hit[1])</TD></TR>
</TABLE>
<hr>
<B><FONT COLOR=yellow FACE="serif">$pdai대째</font><BIG><FONT COLOR="yellow"  FACE="Times New Roman">Champion</FONT> <FONT COLOR="#ffb0ff">$e_name</FONT></B></BIG><small>$e_sedai</small> $e_win승$e_lose패 최고$b5$e_pts<small>pts.</small> $cmdw<BR>
$print2
<BR>
<CENTER>
$result_msg
</CENTER>
<BR>
$fightlog
<HR>
<FONT SIZE=2>[COX]=<font color="red">Challenger's</font> [cox]=<font color="yellow">Champion's</font> [Oo]=HIT [Xx]=MISS [Cc]=Critical HIT</FONT>
_EOF_
		&save ($deffile,$data);
		@def = ();
	}
	print $html_head;
	print $navibar;
	print $data;
	print @def;
	print $html_foot;
}

# ----------------------------------------------------------
# 입장 처리
# ----------------------------------------------------------

# 입장 화면

sub enter_print {
	@users = &read ($userfile);
	@king = &read ($kingfile);
	@sire = &read ($sirefile);
	$userdata = &user_set; 
	($d,$d,$name,$sedai) = split (/<p>/,$userdata);
	print $html_head;
	print<<"_EOF_";
<FORM METHOD="post" ACTION="$cginame">
$user님, 환영합니다.$name의 교배 상대를 선택하세요.<BR>
<INPUT TYPE="hidden" NAME="mode" VALUE="create">
<INPUT TYPE="hidden" NAME="user" VALUE="$user">
<INPUT TYPE="hidden" NAME="pass" VALUE="$FORM{'pass'}">
<big><FONT COLOR="#ffb0ff"><B>$name</B></FONT></big><small>$sedai</small> × 
_EOF_

	if ($ipflag == 0) {
		print "<SELECT NAME=\"sel\">\n";
		print "<OPTION VALUE=\"\">교배 상대\n";
		%klist =();
		$rank=1;
		foreach $line (@rank) {
			($d,$no,$name,$sedai,$d,$d,$d,$d,$d,$d,$blood,$seed) = split (/<p>/,$line);
			@blood = split (/<s>/,$blood);
			$kcheck = (split(/<>/,$blood[13]))[0];
			$klist{"$kcheck"} = 1;
			if ($seed > 0) {
				print "<OPTION VALUE=\"$no\">$rank위 $name $sedai\n";
			}
			$rank++;
		}
		foreach $line (@king) {
			$blood = (split (/<p>/,$line))[10];
			@blood = split (/<s>/,$blood);
			$kcheck = (split(/<>/,$blood[13]))[0];
			unless ($klist{"$kcheck"}) {
				($d,$no,$name,$sedai) = split (/<p>/,$line);
				print "<OPTION VALUE=\"$no\">명예의 전당 $name $sedai\n";
			}
		}
		print<<"_EOF_";
<OPTION VALUE="no">알 수 없는 씨앗(새 계통 작성)
</SELECT>
<INPUT TYPE=submit VALUE="교배">
_EOF_
	} else {
		print "이용은 $wait분1회까지.<BR>\n";
	}
	$print = &status_print ($userdata);
	print<<"_EOF_";
<TABLE border=0 cellspacing=0 cellpadding=0>
<TR><TD>
$print
</TD><TD>
</FORM><FORM METHOD="post" ACTION="$cginame" target="bottom">
<INPUT TYPE="hidden" NAME="mode" VALUE="k">
</TD></TR>
</TABLE>
_EOF_

# 상성표시
	print<<"_EOF_";
<SELECT NAME="kno">
<OPTION VALUE="">↓혈통 상성목록↓
_EOF_
	($kno,$kname,$knx) = split (/<>/,$blood[13]);
	($kno2,$kname2,$knx2) = split (/<>/,$blood[11]);
	$mmd_kno = $blood[10] + 0;
	$dmd_kno = $blood[12] + 0;
	$kup = substr ($knx,6,1);
	$flag_zero = 1;
	foreach $sire (@sire) {
		($k_cnt,$k_no,$k_name,$k_nx,$k_old) = split (/<>/,$sire);
		$sup = substr ($k_nx,6,1);
		@nxpoint = "";
		$nxprint = "";
		$nxhit = 0;
		if ($kno == $kno2 && $kno == $k_no) {
			$nxprint = "××××××";
		} else {
			for ($i = 0; $i < 6; $i++) {
				$nxa[$i] = substr ($knx,$i,1) + substr ($k_nx,$i,1);
				if ($nxa[$i] == 5) {
					$nxhit++;
					if ($kno == $k_no || $kno2 == $k_no || $kno == $kno2) {
						$nxpoint[$i] = 1;
					} else {
						$nxpoint[$i] = 2;
					}
				} else {
					$nxpoint[$i] = 0;
				}
			}
			if ($nxhit < 6) {
				if ($nxhit == 0) { $nxpoint[$kup] += 3; $nxpoint[$sup] += 2; }
				if ($nxhit == 1) { $nxpoint[$kup] += 3; $nxpoint[$sup] += 2; }
				if ($nxhit == 2) { $nxpoint[$kup] += 2; $nxpoint[$sup] += 2; }
				if ($nxhit == 3) { $nxpoint[$kup] += 2; $nxpoint[$sup] += 1; }
				if ($nxhit == 4) { $nxpoint[$kup] += 1; $nxpoint[$sup] += 1; }
				if ($nxhit == 5) { $nxpoint[$kup] += 1; }
			}
			foreach $point (@nxpoint) {
				if ($point == 1) { $nxprint .= "△";
				} elsif ($point == 2) { $nxprint .= "○";
				} elsif ($point == 3) { $nxprint .= "◎";
				} elsif ($point == 4) { $nxprint .= "☆";
				} elsif ($point == 5) { $nxprint .= "★";
				} elsif ($point == 6) { $nxprint .= "♪";
				} elsif ($point == 7) { $nxprint .= "∞";
				} else { $nxprint .= "×";
				}
			}
		}
		if ($k_cnt == 0 && $flag_zero) {
			print "<OPTION VALUE=\"\">−−−−−−\n";
			$flag_zero = 0;
		}
		$mup = $stat[substr ($k_nx,6,1)];
		print "<OPTION VALUE=\"$k_no\">$nxprint $k_name $k_no계 ($mup)\n";
	}
	print<<"_EOF_";
</SELECT>
<INPUT TYPE=submit VALUE="표시"><BR>
<small>「표시」를 누르면 해당 계통의 슬라임을 아래 화면에 목록으로 표시합니다.</small>
<INPUT TYPE="hidden" NAME="mmd" VALUE="$mmd_kno">
<INPUT TYPE="hidden" NAME="mom" VALUE="$kno2">
<INPUT TYPE="hidden" NAME="dmd" VALUE="$dmd_kno">
<INPUT TYPE="hidden" NAME="dad" VALUE="$kno">
</FORM>
_EOF_
	print $html_foot;
}

sub user_set {
	$user = $FORM{'user'};
	if ($user eq '') {
		&error(1,'사용자명을 입력해야 등록할 수 있습니다.');
	}
	if (length($user) > 16) { $user = substr($user,0,16); }

	$match = 0;
	$time = time;
	$ipflag = 0;
	$ipad = $ENV{'REMOTE_ADDR'};
	$userdata = '';

	$time_wait = $time - $wait * 60;
	$time_ip = $time - $ipwait * 60;
	$user_data = &seek_user (@users);
	unless ($user_data) {
		($filename,$fileext) = split(/\./,$userfile);
		for ($i=1; $i <= $files_bk; $i++) {
			@bk_user = &read ("$filename$i\.$fileext");
			$user_data = &seek_user (@bk_user);
			if ($user_data) { last; }
		}
	}
	$newbie = 0;
	if ($userdata eq '') {
		if (@users < $usermax) {
			$newbie = 1;
			$userdata = $eve;
		} else {
			$endtime = (split(/<p>/,$users[$usermax - 1]))[5];
			$endtime += $userwait * 86400;
			$fdate = &date ($endtime);
			&error(1,"현재 참가자가 너무 많아 신규 등록할 수 없습니다.$fdate 이후 다시 등록해 주세요.");
		}
	}
	&set_cookie;
	return $userdata;
}

sub seek_user {
	local (@users) = @_;
	$i = 0;
	until (($userdata && $time_ip > $checktime) || ($i > @users - 1)) {
		$line = $users[$i];
		($d,$checkip,$d,$d,$checkuser,$checktime,$d,$d,$d,$d,$d,$checkpass) = split (/<p>/,$line);
		if ($checkuser eq $user && $userdata eq "") {
			$match = &pass_match ($FORM{'pass'},$checkpass);
			if ($time_wait < $checktime) {
				$ipflag = 1;
				if ($FORM{'mode'} eq 'create') {
					&error(1,'캐릭터를 다시 만들려고 하지 마세요.');
				}
			}
			if ($match) { $userdata = $line; }
			else { 
				&error(1,'비밀번호가 틀렸거나 해당 이름을 다른 사람이 이미 사용 중입니다.');
			}
		}
		if ($checkip eq $ipad && $time_ip < $checktime) { 
			$ipflag = 1;
			if ($FORM{'mode'} eq 'create') {
				&error(1,'캐릭터를 다시 만들려고 하지 마세요.');
			}
		}
		$i++;
	}
	return $userdata;
}

# ----------------------------------------------------------
# 새 캐릭터 생성
# ----------------------------------------------------------

sub create {
	@users = &read ($userfile,1);
	$userdata = &user_set;
	$halfdata = &seed_set;
	$newdata = &create_char ($userdata,$halfdata);
	&user_save ($newdata);
	&create_print;
}

# 캐릭터 합성

sub create_char {
	local ($userdata,$halfdata) = @_;
	$dna1 = (split(/<p>/,$userdata))[9];
	$dna2 = (split(/<p>/,$halfdata))[9];
	$seed1 = &seed_create ($dna1);
	if ($halfdata) {
		$halfwgt = (split (/<>/,(split (/<p>/,$halfdata))[8]))[0];
		if ($halfwgt < $wgt_ave) {
			$range = int ($range * (2 - $halfwgt / $wgt_ave) + 0.5);
		} else {
			$range = int ($range * (0.5 + 0.5 * $wgt_ave / $halfwgt) + 0.5);
		}
		$seed2 = &seed_create ($dna2);
	} else {
		for ($i = 0; $i < 19; $i++) {
			if ($i < 10) {
				if ($i == 6) { $para = 20 + int (rand (21));
				} elsif ($i == 0 || $i == 4) { $para = 10 + int (rand (51));
				} else { $para = 40 + int (rand (21));
				}
				$parap = 40 + int (rand (21));
				$part = "$para<>$parap";
			} else { $part = int (rand (2)); }
			$seed2 .= "$part";
			if ($i < 18) { $seed2 .= '<s>'; }
		}
	}
	$new_dna = "$seed1<m>$seed2";
	$new_no = (split(/<p>/,$users[0]))[0] + 1;
	$name = (split(/<p>/,$userdata))[2];
	$new_sedai = (split(/<p>/,$userdata))[3] + 1;
	$new_blood = &blood_mix ($userdata,$halfdata);
	($status,$color,$gif) = &status_set ($new_dna,$new_blood);
	$time = time;
	$ango = &encode_pass ($FORM{'pass'});
	($play,$wins,$winz,$skill,$rate) = split(/<>/,(split(/<p>/,$userdata))[13]);
	$play += 1;
	if ($newbie) {
		$name = "아직 이름 없음";
		$new_sedai = 1;
	}
	$newdata = "$new_no<p>$ipad<p>$name<p>$new_sedai<p>$user<p>$time<p>$color<p>$gif<p>$status<p>$new_dna<p>$new_blood<p>$ango<p>0<p>$play<>$wins<>$winz<>$skill<>$rate<p>\n";
	return $newdata;
}

# 사용자 파일 저장 및 만료 데이터 삭제

sub user_save {
	local (@save) = '';
	push (@save,$_[0]);
	$time_out = $time - $userwait * 86400;
	@temp = @users;
	$hitflag = 0;
	$linetime = (split(/<p>/,$temp[@temp - 1]))[5];
	while ($linetime < $time_out && @temp) { # 만료삭제
		pop @temp;
		$linetime = (split(/<p>/,$temp[@temp - 1]))[5];
	}
	while ($hitflag == 0 && @temp) {
		$lineowner = (split(/<p>/,$temp[0]))[4];
		if ($user eq $lineowner) {
			shift @temp;
			$hitflag = 1;
		} else {
			push (@save,$temp[0]);
			shift @temp;
		}
	}
	@save = (@save,@temp);
	&save ($userfile,@save);
}

# 새 캐릭터 표시

sub create_print {
	print $html_head;
	print<<"_EOF_";
<FORM METHOD="post" ACTION="$cginame" target="bottom">
$name의 아이가 태어났습니다. 이름을 붙이고 랭킹에 도전하세요!<BR>
<INPUT TYPE="hidden" NAME="mode" VALUE="fight">
<INPUT TYPE="hidden" NAME="user" VALUE="$user">
<INPUT TYPE="hidden" NAME="pass" VALUE="$FORM{'pass'}">
이름:<INPUT type="text" name="name" size=18 value="$name">
<INPUT TYPE="submit" VALUE="전투 시작">
_EOF_

	$print = &status_print ($newdata);
	print $print;
	print<<"_EOF_";
<FONT SIZE=2>이 아이는 세계가 창조된 뒤$new_no번째로 태어난 슬라임입니다.</FONT><BR>
</FORM>
_EOF_
	print $html_foot;
}

# 새 혈통 데이터 작성

sub blood_mix {
	local ($data1,$data2) = @_;
	$blood1 = (split(/<p>/,$data1))[10];
	$blood2 = (split(/<p>/,$data2))[10];
	@blood1 = split (/<s>/,$blood1);
	@blood2 = split (/<s>/,$blood2);
# 0=자신의 부모 1=상대 부모 2=자신의 부모부모 345=상대 부모부모 6=자신의 부모부모부모 7-13=상대 부모부모부모 

	($no1,$d,$name1,$sedai1) = split (/<p>/,$userdata);
	($d,$no2,$name2,$sedai2) = split (/<p>/,$halfdata);

	$p0 = "$no1<>$name1<>$sedai1";
	$p1 = "$no2<>$name2<>$sedai2";

	$p2 = $blood1[0];
	$p3 = $blood1[1];
	$p4 = $blood2[0];
	$p5 = $blood2[1];

	$p6 = $blood1[3];
	$p7 = $blood1[5];
	$p8 = $blood2[3];
	$p9 = $blood2[5];

	$pa = $blood1[11];
	$pb = $blood1[13];
	$pc = $blood2[11];
	$pd = $blood2[13];

	unless ($halfdata) {
		$kpart = &new_k;
		$p1 = "0<>알 수 없는 씨앗<>0";
		$pc = "0<><>0000000";
		$pd = "$new_no<><>$kpart";
	}
	if (length ((split(/<>/,$pd))[2]) < 7) {
		($t0,$t1,$t2) = split(/<>/,$pd);
		$t2 = &seven ($t2);
		$pd = "$t0<>$t1<>$t2";
	}

# $pa-$pd 는 계통
	$new_blood = "$p0<s>$p1<s>$p2<s>$p3<s>$p4<s>$p5<s>$p6<s>$p7<s>$p8<s>$p9<s>$pa<s>$pb<s>$pc<s>$pd";

# 계통 씨앗 보너스 합산($blood_variety)
# 11=외조부 13=부계 (10=모계외조부 12=부계외조부)
	local ($i,%variety);
	$blood_variety = 0;
	for ($i = 10; $i <= 13; $i++) {
		unless ($variety{$blood1[$i]}) {
			$variety{$blood1[$i]} = 1;
			$blood_variety += 1;
		}
		unless ($variety{$blood2[$i]}) {
			$variety{$blood2[$i]} = 1;
			$blood_variety += 1;
		}
	}
	return $new_blood;
}

# 새 계통 데이터

sub new_k {
	$kpart = "";
	for ($i = 0; $i < 6; $i++) {
		$krand = int (rand (6));
		$kpart .= "$krand";
	}
	$kpart = &seven ($kpart);
	return $kpart;
}

sub newchamp {
	local ($no,$name,$blood) = @_;
	@bl = split (/<s>/,$blood);
	($o_no,$o_name,$o_nx) = split (/<>/,$bl[13]);
	$oldk[0] = $o_nx;
	$oldk[1] = &new_k;
	$newk = '';
	for ($i = 0; $i < 6; $i++) {
		$newk .= substr ($oldk[int (rand (2))],$i,1);
	}
	$newk = &seven ($newk);
	$newb = "$bl[0]<s>$bl[1]<s>$bl[2]<s>$bl[3]<s>$bl[4]<s>$bl[5]<s>$bl[6]<s>$bl[7]<s>$bl[8]<s>$bl[9]<s>$bl[10]<s>$bl[11]<s>$bl[12]<s>$no<>$name<>$newk";

	@sire = &read ($sirefile,1);
	$old = '';
	foreach $sire (@sire) {
		if ($o_no eq (split (/<>/,$sire))[1]) {
			$old = (split (/<>/,$sire))[4];
		}
	}
	push(@sire,"1<>$no<>$name<>$newk<>$old$o_no<s>$o_name<s>$o_nx<p><>\n");
	&save ($sirefile,@sire);

	return $newb;
}

# 계통 타입 합산

sub seven {
	local ($temp) = $_[0];
	$seven = 0;
	for ($i = 0; $i < 6; $i++) {
		$seven += substr ($temp,$i,1);
	}
	$seven = $seven % 6;
	$return = "$temp$seven";
	return $return;
}

# 교배 상대 데이터 읽기

sub seed_set {
	@lines = &read ($rankfile,1);
	$seekno = $FORM{'sel'};
	if ($seekno eq '') { &error(1,'교배 상대를 선택해 주세요.'); }
	@new = ();
	foreach $line (@lines) {
		($a0,$no,$a2,$a3,$a4,$a5,$a6,$a7,$status,$a9,$b0,$seedrest,$child,$b3,$sperm,$b5) = split(/<p>/,$line);
		if ($no eq $seekno && $halfdata eq "") {
			if ($seedrest < 1) {
				&error(1,'그 상대의 씨앗은 누군가가 먼저 사용한 것 같습니다.');
			}
			$halfdata = $line;
			$seedrest -= 1;
			$child += 1;
		}
		$sex = (split(/<>/,$status))[7];
		$sperm += $sex;
		if ($sperm > $seed_gage) {
			$sperm -= $seed_gage;
			$seedrest += 1;
		}
		push(@new,"$a0<p>$no<p>$a2<p>$a3<p>$a4<p>$a5<p>$a6<p>$a7<p>$status<p>$a9<p>$b0<p>$seedrest<p>$child<p>$b3<p>$sperm<p>$b5");
	}
	unless ($halfdata) {
		@king = &read ($kingfile);
		foreach $line (@king) {
			($a0,$no,$a2,$a3,$a4,$a5,$a6,$a7,$status,$a9,$b0,$seedrest,$child,$b3,$sperm,$b5) = split(/<p>/,$line);
			if ($no eq $seekno) {
				$halfdata = $line;
			}
		}
	}
	if ($halfdata eq '' && $seekno ne 'no') {
		&error(1,'그 상대는 랭킹 밖으로 밀려났습니다.');
	}
	&save ($rankfile,@new);
	return $halfdata;
}

# 씨앗 생성

sub seed_create {
	local ($dna) = $_[0];
	local ($seed,$part,$dna1,$dna2,$rnd,$dice,$para,$parap);
	$seed = '';
	($dna1,$dna2) = split (/<m>/,$dna);
	($dp1[0],$dp1[1],$dp1[2],$dp1[3],$dp1[4],$dp1[5],$dp1[6],$dp1[7],$dp1[8],$dp1[9],$dp1[10],$dp1[11],$dp1[12],$dp1[13],$dp1[14],$dp1[15],$dp1[16],$dp1[17],$dp1[18]) = split (/<s>/,$dna1);
	($dp2[0],$dp2[1],$dp2[2],$dp2[3],$dp2[4],$dp2[5],$dp2[6],$dp2[7],$dp2[8],$dp2[9],$dp2[10],$dp2[11],$dp2[12],$dp2[13],$dp2[14],$dp2[15],$dp2[16],$dp2[17],$dp2[18]) = split (/<s>/,$dna2);
	for ($i = 0; $i < 19; $i++) {
		$rnd = int (rand (2));
		if ($rnd) { $part = $dp1[$i]; }
		else { $part = $dp2[$i]; }
		if ($i < 10) {
			($para,$parap) = split (/<>/,$part);
			$dice = &dice;
			$para += $dice - ($tumble * (1 + $range) / 2);
			$para = $para * ($para > 0) + ($para < 1);
			$dice = &dice;
			$parap += $dice - ($tumble * (1 + $range) / 2);
			$part = "$para<>$parap";
		}
		$seed .= "$part";
		if ($i < 18) { $seed .= '<s>'; }
	}
	return $seed;
}

# 능력치 설정

sub status_set {
	local ($dna,$blood) = @_;
	@para = &dna_trans($dna);

# 닉스
# 11=외조부 13=부계 (10=모계외조부 12=부계외조부)

	@blood = split (/<s>/,$blood);
	for ($i = 10; $i < 14; $i++) {
		($k_no[$i],$k_name[$i],$k_nx[$i]) = split (/<>/,$blood[$i]);
		foreach $line (@nxlist) {
			if ($k_no[$i] == $line) { $nxflag[$i] = 1; }
		}
		unless ($nxflag[$i]) { push (@nxlist,$k_no[$i]); }
	}
	if (length ($k_nx[11]) < 7) { $k_nx[11] = &seven ($k_nx[11]); }
	$nxhit = 0;
	for ($i = 0; $i < 6; $i++) { # 닉스 계산
		$nxa[$i] = substr ($k_nx[11],$i,1) + substr ($k_nx[13],$i,1);
		$nxb[$i] = substr ($k_nx[10],$i,1) + substr ($k_nx[11],$i,1) + substr ($k_nx[12],$i,1) + substr ($k_nx[13],$i,1);
		$nx[$i] = 1;
		if ($nxa[$i] == 5) { $nx[$i] += 0.1; $nxhit++; }
		if ($nxb[$i] % 3 == 0) { $nx[$i] += 0.05; }
		if (@nxlist < 3) { $nx[$i] -= 0.05; }
		if (@nxlist < 4 && $nx[$i] > 1) { $nx[$i] -= 0.05; }
	}
	$mup = substr ($k_nx[11],6,1); # 외조부 계통 타입
	$fup = substr ($k_nx[13],6,1); # 부계 계통 타입
	if ($nxhit < 6 && @nxlist > 2) { # 계통 타입 효과
		if ($nxhit == 0) { $nx[$mup] += 0.15; $nx[$fup] += 0.10; } # 25
		if ($nxhit == 1) { $nx[$mup] += 0.15; $nx[$fup] += 0.10; } # 35
		if ($nxhit == 2) { $nx[$mup] += 0.10; $nx[$fup] += 0.10; } # 40
		if ($nxhit == 3) { $nx[$mup] += 0.10; $nx[$fup] += 0.05; } # 45
		if ($nxhit == 4) { $nx[$mup] += 0.05; $nx[$fup] += 0.05; } # 50
		if ($nxhit == 5) { $nx[$mup] += 0.05; } # 55
	}
	if ($blood_variety == 5) { $nx[$fup] += 0.05; }
	if ($blood_variety == 6) { $nx[$fup] += 0.05; $nx[$mup] += 0.05; }
	if ($blood_variety == 7) { $nx[$fup] += 0.10; $nx[$mup] += 0.05; }
	if ($blood_variety == 8) { $nx[$fup] += 0.15; $nx[$mup] += 0.10; }
	foreach $point (@nx) {
		if ($point >= 1.40) { $nxprint .= ($point * 100 - 100);
		} elsif ($point >= 1.35) { $nxprint .= "∞";
		} elsif ($point >= 1.30) { $nxprint .= "♪";
		} elsif ($point >= 1.25) { $nxprint .= "★";
		} elsif ($point >= 1.20) { $nxprint .= "☆";
		} elsif ($point >= 1.15) { $nxprint .= "◎";
		} elsif ($point >= 1.10) { $nxprint .= "○";
		} elsif ($point >= 1.05) { $nxprint .= "△";
		} else { $nxprint .= "×";
		}
	}

# 능력치
# @para:0=HRD 1=MSL 2=BRN 3=NET 4=FAT 5=MEN 6=SEX 7=SFT 8=AIR 9=SNS
# 	10=RED 11=GRN 12=BLU 13=X  14=Y  15=Z  16=리본 17=왕관  18=날개

	$wgt = int (($para[0] * 24 + $para[1]  * 12 + $para[7] * 12 + $para[4] * 24 + $para[2] * 3 + $para[8] * 3 + $para[3] + $para[9]) / 80) + 1;
	$hp  = int ($nx[0] * (($para[0] * 5 + $para[1] + $para[7] + $para[4] * 3) * 10 / 9)) + 1;
	$stm = int ($nx[1] * (($para[4] * 6 + $para[5] * 4) / 10 * sqrt ($para[8] / $wgt)) * 10) + 1;
	$str = int ($nx[2] * (sqrt (($wgt + sqrt ($wgt * $para[0])) / 2 * ($para[1] + $para[7]) / 2))) + 1;
	$dex = int ($nx[3] * (($para[2] ** 2) / ($wgt ** 2) * $para[9] * $para[1] * $para[7] * $para[3]) ** 0.25) + 1;
	$agl = int ($nx[4] * (($para[1] ** 2) * $para[7] / ($wgt ** 2) * ($para[3] ** 2) / ($wgt ** 2) * ($para[9] ** 3)) ** 0.25) + 1;
	$spd = int ($nx[5] * ($para[1] * ($para[7] ** 2) / ($wgt ** 2) * ($para[2] ** 2) / ($wgt ** 2) * ($para[3] ** 3)) ** 0.25) + 1;
	$cst = int (($wgt * 10 + $para[2] * 2 + $para[3] * 3 + $para[6] * 2 + $para[8] * 2 + $para[9] * 3) / 22) + 1;
	$sex = int ($para[6] / $cst * 50) + 1;
#여기까지
	$status = "$wgt<>$hp<>$stm<>$str<>$dex<>$agl<>$cst<>$sex<>$spd<>$nxprint";

# 돌연변이

	$dnaflag = 0; $rgbflag = 0; $xyzflag = 0; $uvwflag = 0;
	if (int (rand ($henka)) == 0) { $dnaflag = 1; $rgbflag = 1; }
	if (int (rand ($henka)) == 0) { $dnaflag = 1; $xyzflag = 1; }
	if (int (rand ($henka)) == 0) { $dnaflag = 1; $uvwflag = 1; }
	if ($dnaflag) {
		($dna[0],$dna[1]) = split (/<m>/,$dna);
		for ($i = 0; $i < 2; $i++) {
			($d0,$d1,$d2,$d3,$d4,$d5,$d6,$d7,$d8,$d9,$r,$g,$b,$x,$y,$z,$u,$v,$w) = split (/<s>/,$dna[$i]);
			if ($rgbflag) { $r = 1 - $r; $g = 1 - $g; $b = 1 - $b; }
			if ($xyzflag) { $x = 1 - $x; $y = 1 - $y; $z = 1 - $z; }
			if ($uvwflag) { $u = 1 - $u; $v = 1 - $v; $w = 1 - $w; }
			$change[$i] = "$d0<s>$d1<s>$d2<s>$d3<s>$d4<s>$d5<s>$d6<s>$d7<s>$d8<s>$d9<s>$r<s>$g<s>$b<s>$x<s>$y<s>$z<s>$u<s>$v<s>$w";
		}
		$new_dna = "$change[0]<m>$change[1]";
		@para = &dna_trans($new_dna);
	}
	$rgb = $para[10] + $para[11] + $para[12];
	$xyz = $para[13] + $para[14] + $para[15];
	$uvw = $para[16] + $para[17] + $para[18];


# 색상 결정

	if ($para[10] == 0) {
		$red = '00';
		if ($para[13] == 1) { $red = '3f'; }
	}	elsif ($para[10] == 1) {
		$red = '7f';
	}	else {
		$red = 'ff';
		if ($para[13] == 1) { $red = 'bf'; }
	}
	if ($para[11] == 0) {
		$grn = '00';
		if ($para[14] == 1) { $grn = '3f'; }
	}	elsif ($para[11] == 1) {
		$grn = '7f';
	}	else {
		$grn = 'ff';
		if ($para[14] == 1) { $grn = 'bf'; }
	}
	if ($para[12] == 0) {
		$blu = '00';
		if ($para[15] == 1) { $blu = '3f'; }
	}	elsif ($para[12] == 1) {
		$blu = '7f';
	}	else {
		$blu = 'ff';
		if ($para[15] == 1) { $blu = 'bf'; }
	}
	$color = "#$red$grn$blu";

	$gif = $char_normal;
	if ($xyz == 6) {	# 변이체 출현율을늘리기에은여기을 $xyz > 4 등변경
		$gif = $char_aura;
		if ($uvw == 3) { $gif = $char_hider; }
		if ($para[18] == 2) { $gif = $char_wing; }
		if ($para[16] == 2) {
			$gif = $char_ribbon;
			if ($para[18] == 2) { $gif = $char_ribbonw; }
		}
		if ($para[17] == 2) {
			$gif = $char_crown;
			if ($para[16] == 2) {
				$gif = $char_aho;
				if ($rgb < 2) { $gif = $char_zombie; }
				if ($rgb == 6) { $gif = $char_oyaji; }
			}
			if ($para[18] == 2) { $gif = $char_crownw; }
		}
		if ($uvw == 6) {
			$gif = $char_musi;
			if ($rgb > 3) { $gif = $char_angel; }
			if ($rgb < 1) { $gif = $char_devil; }
		}
	}
	return ($status,$color,$gif);
}

# DNA 해석

sub dna_trans {
	local ($dna) = $_[0];
	local ($part1,$part2,$dna1,$dna2,$parap1,$para1,$parap2,$para2);
	@para = ();
	($dna1,$dna2) = split (/<m>/,$dna);
	for ($i = 0; $i < 19; $i++) {
		$part1 = (split (/<s>/,$dna1))[$i];
		$part2 = (split (/<s>/,$dna2))[$i];
		if ($i < 10) {
			($para1,$parap1) = split (/<>/,$part1);
			($para2,$parap2) = split (/<>/,$part2);
			if ($parap1 > ($parap2 + ($range - 1) * $tumble * 0.05)) { $para[$i] = $para1; }
			elsif (($parap1 + ($range - 1) * $tumble * 0.05) < $parap2) { $para[$i] = $para2; }
			else { $para[$i] = int (($para1 + $para2) / 2) + 1; }
		} else { $para[$i] = $part1 + $part2; }
	}
	return @para;
}

# ----------------------------------------------------------
# 전투
# ----------------------------------------------------------

sub fight {
	@users = &read ($userfile,1);
	$userdata = &user_set;
		($u_no,$u1,$u_name,$u3,$u4,$u5,$u6,$u7,$u_status,$u9,$ua,$ub,$check,$ud,$ue) = split(/<p>/,$userdata);
	if ($check) {
		&error(1,'전투는 다시 시작할 수 없습니다. 또는 서버 혼잡으로 저장되지 않았으니 교배부터 다시 진행해 주세요.');
	}

	print $html_head;
	if ($FORM{'name'} ne '') { $u_name = $FORM{'name'}; }
	if (length ($u_name) > 18) { $u_name = substr ($u_name,0,18); }
	@kblood = split (/<s>/,$ua);
	($k_no,$k_name,$k_sedai) = split (/<>/,$kblood[13]);
	unless ($k_name) {
		$ua ="$kblood[0]<s>$kblood[1]<s>$kblood[2]<s>$kblood[3]<s>$kblood[4]<s>$kblood[5]<s>$kblood[6]<s>$kblood[7]<s>$kblood[8]<s>$kblood[9]<s>$kblood[10]<s>$kblood[11]<s>$kblood[12]<s>$k_no<>$u_name<>$k_sedai";
	}

	@rank = &read ($rankfile,1);
	$u_pts = 1;
	$u_win = 0;
	$u_lose = 0;
	$loseflag = 0;
	$result_text = '';

	@new = ();
	$rankend_pts = (split(/<p>/,$rank[@rank - 1]))[0];
	$cut_length = length ($rankend_pts) - 2;
	$cut_length *= ($cut_length > 0);
	$r = @rank;
	$boueisen = 0;
	$changef = 0;
	$lrank = $rankmax;

	while ($r > 0) {
		($e_pts,$a1,$e_name,$e_sedai,$a4,$a5,$e_color,$a7,$e_status,$a9,$b0,$b1,$b2,$e_result,$b4,$b5) = split(/<p>/,$rank[$r - 1]);
		($e_win,$e_lose) = split(/<>/,$e_result);
		$e_pts = int ($e_pts / (10 ** $cut_length));
		unless ($loseflag) {
			if ($e_pts >= $u_pts || $r < ($rensen + 1)) {
				$lrank = $r;
				&fight_set ($u_status,$e_status);
				if ($r == 1) { # 전승으로 챔피언 도전
					$boueisen = 1;
					if ($loseflag) { # 챔피언방어
						($b5_rank,$b5_defend) = split(/<sup>/,$b5);
						$b5_defend += 1;
						$b5 = "1위<sup>$b5_defend</sup>\n";
					} else { # 전승, 새 계통 탄생
						$lrank = 0;
						$changef = 1;
						if ($k_name) { $ua = &newchamp ($u_no,$u_name,$ua); }
					}
				}
				print $result_text;
				$result_text = '';
			}
		}
		$e_result = "$e_win<>$e_lose";
		if ($b5 > $r || $b5 == 0) { $b5 = $r . "위\n"; }
		$newline = "$e_pts<p>$a1<p>$e_name<p>$e_sedai<p>$a4<p>$a5<p>$e_color<p>$a7<p>$e_status<p>$a9<p>$b0<p>$b1<p>$b2<p>$e_result<p>$b4<p>$b5";
		push(@new,$newline);
		$r--;
	}
	$lrank++;
	$iniseed = int ((split(/<>/,$u_status))[7] / 10);
	$u_data = "$u_pts<p>$u_no<p>$u_name<p>$u3<p>$u4<p>$u5<p>$u6<p>$u7<p>$u_status<p>$u9<p>$ua<p>$iniseed<p>0<p>$u_win<>$u_lose<p>0<p>$lrank위\n";
	unshift (@new,$u_data);

	($play,$wins,$winz) = split(/<>/,$ud);
	$play += 0;
	$wins += $u_win;
	if (@rank < $rankmax) { $winz += $u_win;
	} elsif ($u_no < $rankmax * 4) {
		$winz += int ($u_win ** (1 + ($u_no - $rankmax) / ($rankmax * 3)));
	} else { $winz += $u_win ** 2;
	}
	$skill = int (($wins + $winz) / (25 + $play) * 20);
	$rate = $wins / $play;
	$rate = substr ($rate,0,5);
	$checkeduser = "$u_no<p>$u1<p>$u_name<p>$u3<p>$u4<p>$u5<p>$u6<p>$u7<p>$u_status<p>$u9<p>$ua<p>$ub<p>1<p>$play<>$wins<>$winz<>$skill<>$rate<p>\n";
	&user_save ($checkeduser);

# 챔피언 방어 및 랭킹 저장

	$champ = @new[@new-1];
	pop @new;

	@new = sort {$b <=> $a} @new;

	$ranger = $new[0]; # 챔피언을 제외한 랭킹 최상위
	$champ_pts = (split(/<p>/,$champ))[0];
	$ranger_pts = (split(/<p>/,$ranger))[0];
	$king_flag = 0;
	if ($champ_pts < $ranger_pts) { # 챔피언부터포인트가 많음
		($u_pts,$a1,$u_name,$u_sedai,$a4,$a5,$u_color,$a7,$u_status,$a9,$b0,$b1,$b2,$u_result,$b4,$b5) = split(/<p>/,$ranger);
		($e_pts,$u1,$e_name,$e_sedai,$u4,$u5,$e_color,$u7,$e_status,$u9,$v0,$v1,$v2,$e_result,$v4,$v5) = split(/<p>/,$champ);
		($u_win,$u_lose) = split(/<>/,$u_result);
		($e_win,$e_lose) = split(/<>/,$e_result);
		($v5_rank,$v5_defend) = split(/<sup>/,$v5);
		if ($loseflag == 0) { # 도전자 = 전승으로 1위
			shift @new;
			unshift (@new,$champ);
			unshift (@new,$ranger);
			if ($v5_defend > ($dendo - 1)) { $king_flag = 1; }
		} else { # 도전자 = 연승을 멈춘 슬라임
			$boueisen = 1;
			$loseflag = 0;
			&fight_set ($u_status,$e_status);
			$u_result = "$u_win<>$u_lose";
			$e_result = "$e_win<>$e_lose";
			$ranger = "$u_pts<p>$a1<p>$u_name<p>$u_sedai<p>$a4<p>$a5<p>$u_color<p>$a7<p>$u_status<p>$a9<p>$b0<p>$b1<p>$b2<p>$u_result<p>$b4<p>$b5";
			$champ = "$e_pts<p>$u1<p>$e_name<p>$e_sedai<p>$u4<p>$u5<p>$e_color<p>$u7<p>$e_status<p>$u9<p>$v0<p>$v1<p>$v2<p>$e_result<p>$v4<p>$v5";
			if ($loseflag) { # 챔피언방어
				$v5_defend += 1;
				$v5 = "1위<sup>$v5_defend</sup>\n";
				$champ = "$e_pts<p>$u1<p>$e_name<p>$e_sedai<p>$u4<p>$u5<p>$e_color<p>$u7<p>$e_status<p>$u9<p>$v0<p>$v1<p>$v2<p>$e_result<p>$v4<p>$v5";
				shift @new;
				unshift (@new,$ranger);
				unshift (@new,$champ);
			} else { # 챔피언패배
				shift @new;
				unshift (@new,$champ);
				unshift (@new,$ranger);
				if ($v5_defend > ($dendo - 1)) { $king_flag = 1; }
				$changef = 1;
			}
		}
	} else {
		unshift (@new,$champ);
	}

	while (@new > $rankmax) { pop @new; }
	&save ($rankfile,@new);

# 명예의 전당 입성
	if ($king_flag) {
		@king = &read ($kingfile,1);
		@def = &read ($deffile,1);
		($d,$bcnt,$bdai) = split (/<>/,$def[0]);
		$champs = "$bdai<>$champ";
		if ((split(/<p>/,$king[0]))[1] == (split (/<p>/,$champ))[1]) {
			shift @king;
			unshift (@king,$champs);
			&save ($kingfile,@king);
		} else {
			unshift (@king,$champs);
			$FORM{'user'} = "축하-명예의 전당 입성";
			$FORM{'comt'} = "$e_name $e_sedai 가 명예의 전당에 입성했습니다.$u4님, 축하합니다.";
			&save ($kingfile,@king);
			&add_comt;
		}
	}

# 방어전결과
	if ($boueisen) {
		unless (@def) {
			@def = &read ($deffile,1);
			($d,$bcnt,$bdai) = split (/<>/,$def[0]);
		}
		$bcnt++;
		$bdai += $changef;
		$time = time;
		$boueidata = "$time<>$bcnt<>$bdai<>\n$ranger$champ";
		$boueidata .= "$hp[0]<>$maxhp[0]<>$pow[0]<>$hit[0]<>$attack[0]<>$dmg_ave[0]<>$luck_atk[0]<>$luck_hit[0]<>\n";
		$boueidata .= "$hp[1]<>$maxhp[1]<>$pow[1]<>$hit[1]<>$attack[1]<>$dmg_ave[1]<>$luck_atk[1]<>$luck_hit[1]<>\n";
		$boueidata .= "$fightlog\n";
		&save ($deffile,$boueidata);
	}

	if ($u3 > 99) {
		$mania = "[<A HREF=\"$cginame?mode=mania\">시스템 해설</A>]";
	} else { $mania = ''; }

	print<<"_EOF_";
<FONT SIZE=2>[COX]=내 공격 [cox]=상대 공격 [Oo]=HIT [Xx]=MISS [Cc]=Critical HIT</FONT>
<HR>
<CENTER>
$navibar0
$mania
</CENTER>
_EOF_
	print $html_foot;
}

sub fight_set {
	local (@status) = @_;
	for ($i = 0; $i < 2; $i++) {
		($wgt[$i],$maxhp[$i],$maxst[$i],$str[$i],$dex[$i],$agl[$i],$cst[$i],$sex[$i],$spd[$i]) = split (/<>/,$status[$i]);
	}
# 자신[$turn != 0]
# 상대[$turn == 0]
	@gage = ();
	$turn = 0;
	$hit[0] = 0; $hit[1] = 0;
	$attack[0] = 0; $attack[1] = 0;
	$maxst[0] *= 8; $maxst[1] *= 8;
	$hp[0] = $maxhp[0]; $hp[1] = $maxhp[1];
	$st[0] = $maxst[0]; $st[1] = $maxst[1];
	$prs[0] = sqrt ($str[0] * $cst[0]); $prs[1] = sqrt ($str[1] * $cst[1]);
	$pow[0] = 1; $pow[1] = 1;
	$powx[0] = 1; $powx[1] = 1;
	$powy[0] = 1; $powy[1] = 1;
	$sum_rndhit[0] = 0; $sum_rndhit[1] = 0;
	$sum_hitper[0] = 0; $sum_hitper[1] = 0;
	$spd_gage = ($spd[0] >= $spd[1]) * $spd[0] + ($spd[0] < $spd[1]) * $spd[1] - 1;
	$fightlog = '';
	$combo_agl = 1;
	$round = 1;
	until ($hp[0] < 1 || $hp[1] < 1) {
		if ($gage[$turn != 0] > $spd_gage) {
			$gage[$turn != 0] -= $spd_gage;
			$attack[$turn != 0] += 1;
			$my_dex = $dex[$turn != 0] * $powx[$turn != 0];
			if ($turn == $combo_turn && $combo_agl != 1) {
				$ur_agl = $agl[$turn == 0] * $powx[$turn == 0] * $combo_agl;
			} else {
				$ur_agl = $agl[$turn == 0] * $powx[$turn == 0];
			}
			if ($my_dex < 1) { $my_dex = 1 };
			if ($ur_agl < 1) { $ur_agl = 1 };
			$rnd_hit = rand ($my_dex);
			$rnd_pry = rand ($ur_agl);
			$hit_judge = $rnd_hit - $rnd_pry;
			$sum_rndhit[$turn != 0] += ($rnd_hit / $my_dex);
			$sum_rndhit[$turn == 0] += ($rnd_pry / $ur_agl);
			$combo_turn = $turn;
			if ($hit_judge > 0) {	# HIT
				$x = $hit_judge / $my_dex;
				$hit_per = (2 * $x - 1) ** 3 + 1;
				$hit[$turn != 0] += 1;
				$sum_hitper[$turn != 0] += $hit_per;
				$dmg = int ($str[$turn != 0] * $hit_per * $powx[$turn != 0]);
				$hp[$turn == 0] -= $dmg;
				$st[$turn == 0] -= int ($prs[$turn != 0] * $powy[$turn != 0] * (0.5 + $hit_per * 0.5) + $str[$turn != 0] * $powx[$turn != 0] * ($hit_per * 0.75));
				$dmg_hp = $dmg / $maxhp[$turn == 0];
				$spd_down = 1 - ($dmg_hp * 1); $spd_down *= ($spd_down > 0);
				$gage[$turn == 0] = int ($gage[$turn == 0] * $spd_down);
				$combo_agl = 1 - (10 * $dmg_hp ** 2); $combo_agl *= ($combo_agl > 0);
				if ($turn == 0) {
					if ($hit_per > 1.5) {
						$fightlog .= "C";
					} else { $fightlog .= "O"; }
				} else { 
					if ($hit_per > 1.5) {
						$fightlog .= "c";
					} else { $fightlog .= "o"; }
				}
			} else {	# MISS
				$combo_agl = 1;
				$y = (-1) * $hit_judge / $ur_agl;
				$st[$turn == 0] -= int ($prs[$turn != 0] * $powy[$turn != 0] * (0.5 * ($y - 1) ** 2));
				if ($turn == 0) {
					$fightlog .= "X";
				} else { 
					$fightlog .= "x";
				}
			}
			$st[$turn != 0] -= $cst[$turn != 0] * $powy[$turn != 0];
			$st[$turn != 0] *= ($st[$turn != 0] > 0);
			$st[$turn == 0] *= ($st[$turn == 0] > 0);
			$pow[$turn != 0] = $st[$turn != 0] / $maxst[$turn != 0];
			$pow[$turn == 0] = $st[$turn == 0] / $maxst[$turn == 0];
			$powx[$turn != 0] = 0.4 + 0.6 * (1 - (1 - $pow[$turn != 0]) ** 2);
			$powx[$turn == 0] = 0.4 + 0.6 * (1 - (1 - $pow[$turn == 0]) ** 2);
			$powy[$turn != 0] = 0.6 + 0.4 * (1 - (1 - $pow[$turn != 0]) ** 2);
			$powy[$turn == 0] = 0.6 + 0.4 * (1 - (1 - $pow[$turn == 0]) ** 2);
			if (!($round % 10)) {
				$fightlog .= " ";
			}
			$round++;
		}
		$gage[$turn != 0] += int ($spd[$turn != 0] * $powx[$turn != 0]);
		$turn = ($turn == 0);
	}
	if ($turn) { &fight_win; }
	else { &fight_lose; }
}

sub fight_win {
	$u_pts += $e_pts;
	$u_win += 1;
	$e_lose += 1;
	$result_msg=<<"_EOF_";
<FONT SIZE=7 color="red" FACE="Times New Roman"><i>YOU WIN!</i></FONT><BR>
NOW $u_pts<small>pts.</small><BR>
_EOF_
	if ($r == 1) {
		$cong=<<"_EOF_";
<BR>
<FONT SIZE=7 color="yellow" FACE="Times New Roman"><i>
Congratulations!<BR>
You are the new CHAMPION!<BR>
</i></FONT>
_EOF_
		$result_msg .= $cong;
	}
	&fight_print;
}

sub fight_lose {
	$e_pts += $u_pts;
	$e_win += 1;
	$u_lose += 1;
	$result_msg=<<"_EOF_";
<FONT SIZE=7 color="blue" FACE="Times New Roman"><i>YOU LOSE!</i></FONT><BR>
TOTAL $u_pts<small>pts.</small><BR>
_EOF_
	$loseflag = 1;
	&fight_print;
}

sub fight_print {
	$print1=<<"_EOF_";
<BIG><B><FONT COLOR="yellow">VS</FONT> 제$r위 <FONT COLOR="#ffb0ff">$e_name</FONT></B></BIG><small>$e_sedai</small> 씨앗$b1개 자식$b2마리 $e_win승$e_lose패 최고$b5$e_pts<small>pts.</small><BR>
_EOF_

	$print2 = &status_print ($rank[$r - 1]);

	$pow[0] = int ($pow[0] * 100);
	$pow[1] = int ($pow[1] * 100);
	$dmg_ave[0] = 0; $dmg_ave[1] = 0;
	$luck_hit[0] = 0; $luck_hit[1] = 0;
	if ($hit[0]) { $dmg_ave[0] = int (($maxhp[1] - $hp[1]) / $hit[0]); }
	if ($hit[1]) { $dmg_ave[1] = int (($maxhp[0] - $hp[0]) / $hit[1]); }
	if ($hit[0]) { $luck_hit[0] = int (100 * $sum_hitper[0] / $hit[0]); }
	if ($hit[1]) { $luck_hit[1] = int (100 * $sum_hitper[1] / $hit[1]); }
	$luck_atk[0] = int (100 * $sum_rndhit[0] / $round);
	$luck_atk[1] = int (100 * $sum_rndhit[1] / $round);
	$print3=<<"_EOF_";
<TABLE BORDER=0 cellspacing=0 cellpadding=2>
<TR bgcolor="#00007f"><TD>$u_name </TD><TD>HP:<FONT COLOR="yellow">$hp[0]</FONT>/<sub>$maxhp[0]</sub> </TD><TD>STM:$pow[0]% </TD><TD>HIT$hit[0]</TD><TD>/ATTACK$attack[0]회 </TD><TD>DmgAve$dmg_ave[0] </TD><TD>LUCK:$luck_atk[0]($luck_hit[0])</TD></TR>
<TR><TD>$e_name </TD><TD>HP:<FONT COLOR="yellow">$hp[1]</FONT>/<sub>$maxhp[1]</sub> </TD><TD>STM:$pow[1]% </TD><TD>HIT$hit[1]</TD><TD>/ATTACK$attack[1]회 </TD><TD>DmgAve$dmg_ave[1] </TD><TD>LUCK:$luck_atk[1]($luck_hit[1])</TD></TR>
</TABLE>
<BR>
<CENTER>
$result_msg
</CENTER>
<BR>
$fightlog
<HR>
_EOF_

	$result_text .= "$print1$print2$print3";
}

# ----------------------------------------------------------
# 난수 생성
# ----------------------------------------------------------

# 주사위
sub dice {
	local ($dice,$j);
	$dice = 0;
	for ($j = 0; $j < $tumble; $j++) {
		$dice += int (1 + rand ($range));
	}
	return $dice;
}

# ----------------------------------------------------------
# 쿠키
# ----------------------------------------------------------

sub set_cookie {
	# 쿠키는 $userwait일간 유효
	($secg,$ming,$hourg,$mdayg,$mong,$yearg,$wdayg,$ydayg,$isdstg)
		 				= gmtime(time + $userwait*24*60*60);

	$yearg += 1900;
	if ($secg  < 10) { $secg  = "0$secg";  }
	if ($ming  < 10) { $ming  = "0$ming";  }
	if ($hourg < 10) { $hourg = "0$hourg"; }
	if ($mdayg < 10) { $mdayg = "0$mdayg"; }

	$month = ('Jan','Feb','Mar','Apr','May','Jun','Jul',
				'Aug','Sep','Oct','Nov','Dec')[$mong];
	$youbi = ('Sunday','Monday','Tuesday','Wednesday',
				'Thursday','Friday','Saturday')[$wdayg];

	$date_gmt = "$youbi, $mdayg\-$month\-$yearg $hourg:$ming:$secg GMT";
	$cook="user\:$user\,pwd\:$FORM{'pass'}";
	print "Set-Cookie: slime=$cook; expires=$date_gmt\n";
}

sub get_cookie { 
	@pairs = split(/;/, $ENV{'HTTP_COOKIE'});
	foreach $pair (@pairs) {
		local($name, $value) = split(/=/, $pair);
		$name =~ s/ //g;
		$DUMMY{$name} = $value;
	}
	@pairs = split(/,/, $DUMMY{'slime'});
	foreach $pair (@pairs) {
		local($name, $value) = split(/:/, $pair);
		$COOKIE{$name} = $value;
	}
	$c_name  = $COOKIE{'user'};
	$c_pwd   = $COOKIE{'pwd'};
}

# ----------------------------------------------------------
# 비밀번호
# ----------------------------------------------------------

sub encode_pass {
	$now = time;
	($pack1, $pack2) = unpack("C2", $now);
	$wk = $now / (60*60*24*7) + $pack1 + $pack2 - 8;
	@saltset = ('a'..'z','A'..'Z','0'..'9','.','/');
	$nsalt = $saltset[$wk % 64] . $saltset[$now % 64];
	$ango = crypt($_[0], $nsalt);
	return $ango;
}

sub pass_match {
	local ($inputpass,$checkpass) = @_;
	if ($checkpass eq crypt ($inputpass,substr ($checkpass,0,2))) {
# FreeBSD서버는substr ($checkpass,3,2)에변경
		$match = 1;
	} else { $match = 0; }
	return $match;
}

# ----------------------------------------------------------
# 날짜 가져오기
# ----------------------------------------------------------

sub date {
	local ($time) = $_[0];
	($sec,$min,$hour,$day,$mon) = localtime($time);
	$mon++;
	if ($sec < 10)  { $sec  = "0$sec";  }
	if ($min < 10)  { $min  = "0$min";  }
	if ($hour < 10) { $hour = "0$hour"; }
	if ($day < 10)  { $day  = "0$day";  }
	if ($mon < 10)  { $mon  = "0$mon";  }

	$date = "$mon/$day $hour:$min";
	return $date;
}

# ----------------------------------------------------------
# 기록 파일 처리
# ----------------------------------------------------------

sub read {
	local($logfile,$lockfile) = @_;
	unless ($lockwait) { $lockwait = 25; }
	local (@div) = split(/\//,$logfile);
	local ($filedir,$i);
	for ($i = 0; $i < @div - 1; $i++) {
		$filedir .= $div[$i] . "\/";
	}
	local ($filename,$fileext) =  split(/\./,$div[@div - 1]);
	if ($lockfile) {
		foreach (1 .. $lockwait) {
			unless (-f "$filedir$filename\.loc") {
				open(LOC,">$filedir$filename\.loc") || die "Can't create lock file.\n";
				close(LOC);
				push(@locklist,"$filedir$filename\.loc");
				last;
			}
			sleep(1);
		}
	}
	if (!open(IN,$logfile)) { return (); }
	local(@files) = <IN>;
	close(IN);
	return @files;
}

sub save {
	local($logfile,@lines) = @_;
	unless ($lockwait) { $lockwait = 25; }
	local (@div) = split(/\//,$logfile);
	local ($filedir,$i);
	for ($i = 0; $i < @div - 1; $i++) {
		$filedir .= $div[$i] . "\/";
	}
	local ($filename,$fileext) =  split(/\./,$div[@div - 1]);
	$tmp_dummy = "$filedir$$\.tmp";
# tmpfile자동삭제처리
	if ($tmp_autodel) {
		$tmp_list = $filedir . "tmplist\.cgi";
		unless (-e $tmp_list) {
			open (LST,">$tmp_list") || die "Can't create tmplist.\n";
			close (LST);
			chmod 0666,$tmp_list;
		}
		open (LST,">>$tmp_list") || die "Can't open tmplist.\n";
		print LST "$tmp_dummy\n";
		close(LST);
	}
# 
	open(TMP,">$tmp_dummy") || die "Can't create tmp file.\n";
	close(TMP);
	chmod 0666,$tmp_dummy;
	open(TMP,">$tmp_dummy") || die "Can't open tmp file.\n";
	print TMP @lines;
	close(TMP);
	foreach (1 .. $lockwait) {
		if (link($tmp_dummy,"$filedir$filename\.tmp") == 1) {
			last;
		}
		sleep(1);
	}
	rename("$filedir$filename\.tmp",$logfile); 
	chmod 0644,$logfile;
	unlink $tmp_dummy;
	if (-f "$filedir$filename\.loc") { unlink "$filedir$filename\.loc"; }
}

sub backup { # 백업 ※ $files_bk 필요
	local($logfile) = $_[0];
	local ($filename,$fileext) = split(/\./,$logfile);
	local ($origin,$i);
	for ($i=$files_bk; $i >= 1; $i--) {
		$origin = $i - 1; # 복사 원본 파일 번호
		unless ($origin) { $origin = ""; } # 파일 번호 0은 빈칸으로
		if (-e "$filename$origin\.$fileext") {
			foreach (1 .. $lockwait) { # tmp 파일로 복사
				if (link("$filename$origin\.$fileext","$filename$i\.tmp") == 1) {
					last;
				}
				sleep(1);
			}
			rename("$filename$i\.tmp","$filename$i\.$fileext"); 
			chmod 0644,"$filename$i\.$fileext";
			if (-e "$filename$i\.tmp") { unlink "$filename$i\.tmp"; }
		}
	}
}

# ----------------------------------------------------------
# 폼 데이터 읽기
# ----------------------------------------------------------

sub read_form {
    local($pair,$buffer);
    if ($ENV{'REQUEST_METHOD'} eq "POST") { read(STDIN, $buffer, $ENV{'CONTENT_LENGTH'}); } else { $buffer = $ENV{'QUERY_STRING'}; }
    local(@pairs) = split(/&/,$buffer);
    foreach $pair (@pairs) {
        local($name,$value) = split(/=/,$pair);
        $value =~ tr/+/ /;
        $value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C",hex($1))/eg;
        $FORM{$name} = &change_code($value);
    }
}

# ----------------------------------------------------------
# 문자 코드 관련
# ----------------------------------------------------------

sub check_code {
    $mojicode = "utf8";
    $charset_code = "UTF-8";
}

sub change_code {
    local($text)=$_[0];
    $text =~ s/\&/&amp;/g;
    $text =~ s/</&lt;/g;
    $text =~ s/>/&gt;/g;
    $text =~ s/
//g;
    return $text;
}

# ----------------------------------------------------------
# 종료 처리
# ----------------------------------------------------------

sub error {
	($err,$err_msg) = @_;
	if ($err) {
		print $html_head;
		print $navibar;
		print "<hr><center><FONT COLOR=\"red\"><B>$err_msg</B></FONT></center>";
		print $html_foot;
	}
	&quit;
}

sub quit {
	if ($tmp_autodel && $tmp_list && (-s $tmp_list) > 5000) {
		@tmplist = &read ($tmp_list,1);
		if (@tmplist > 300) {
			for ($i = 0; $i < 100; $i++) { # 남은 tmp 파일 삭제(500중 오래된 100개)
				substr ($tmplist[$i],-1,1) = "";
				if (-e $tmplist[$i]) { unlink $tmplist[$i]; }
				$tmplist[$i] = "";
			}
			&save ($tmp_list,@tmplist);
		}
	}
	foreach $line (@locklist) { # 남은 잠금 파일 삭제
		if (-f $line) { unlink $line; }
	}
	exit;
}

# ----------------------------------------------------------
# 안내서
# ----------------------------------------------------------

sub guide {
	print $html_head;
	print<<"_EOF_";
$navibar
<br>
★글자 수 제한<BR>
사용자명은 한글 기준 8자, 영문 기준 16자까지입니다.<BR>
슬라임 이름은 한글 기준 9자, 영문 기준 18자까지입니다.<BR>
<BR>
★게임 흐름<BR>
1. 타이틀 화면에서 사용자명과 비밀번호를 입력하고 Enter를 누릅니다.<BR>
2. 자신의 슬라임이 표시되면 교배 상대를 고르고 교배를 실행합니다. 씨앗이 없는 슬라임은 선택할 수 없습니다.<BR>
3. 새 슬라임이 태어나면 이름을 붙이고 전투 시작을 누릅니다.<BR>
4. 전투는 자동으로 진행됩니다. 랭킹 하위부터 포인트 조건에 따라 패배할 때까지 도전합니다.<BR>
5. 결과가 나오면 랭킹과 혈통 정보를 확인하고 다음 교배를 준비합니다.<BR>
<BR>
서버 부하를 줄이기 위해 $wait분에 1회만 플레이할 수 있습니다. $userwait일 동안 플레이되지 않은 슬라임은 삭제됩니다.<BR>
한 번 교배한 슬라임은 한 세대가 진행되며, 사용자는 자손에게 계속 교배를 이어 가는 방식으로만 플레이합니다.<BR>
<BR>
★플레이 방법<BR>
할 수 있는 일은 교배 상대를 고르는 것뿐입니다. 조작은 단순하지만, 혈통·상성·능력치 정보를 읽을수록 전략성이 깊어집니다.<BR>
강한 슬라임을 만들려면 교배를 반복하고 결과를 분석하세요.<BR>
<BR>
★능력치<BR>
HP는 체력, STM은 스태미나, STR은 공격력, DEX는 명중과 손재주, AGL은 회피, SPD는 공격 속도입니다.<BR>
체중이 무거운 개체는 HP와 STR이 높아지기 쉽고, 가벼운 개체는 DEX, AGL, SPD가 높아지기 쉽습니다.<BR>
<BR>
★혈통과 상성<BR>
혈통표에서는 부모, 조부모, 증조부, 계통을 확인할 수 있습니다. 이름을 누르면 랭킹에 남아 있는 해당 슬라임을 볼 수 있습니다.<BR>
계통 상성은 HP, STM, STR, DEX, AGL, SPD에 대응하며, 네 계통이 모두 다르게 조합될수록 닉스 효과를 크게 끌어낼 수 있습니다.<BR>
계통 타입은 특정 능력치가 오르기 쉬워지는 효과를 줍니다. 다양한 계통을 섞을수록 다음 세대 전략의 폭이 넓어집니다.<BR>
<BR>
★새 계통<BR>
알 수 없는 씨앗을 사용하거나, 무패로 1위가 되면 새 계통을 만들 수 있습니다. 계통명은 태어난 슬라임의 이름을 따릅니다.<BR>
<BR>
★전투 결과<BR>
전투 로그의 COX는 내 공격, cox는 상대 공격입니다. O/o는 명중, X/x는 빗나감, C/c는 치명타입니다.<BR>
HP, STM, HIT/ATTACK, DmgAve, LUCK을 통해 전투 내용을 분석할 수 있습니다.<BR>
<BR>
★랭킹과 명예의 전당<BR>
랭킹은 포인트제로 운영됩니다. 상대를 쓰러뜨리면 포인트를 얻고, 1위 방어전에 성공한 슬라임은 방어 횟수가 표시됩니다.<BR>
1위를 $dendo회 이상 방어한 슬라임은 전설의 슬라임으로 명예의 전당에 등록됩니다. 명예의 전당 계통은 랭킹에서 사라져도 교배 상대로 다시 활용할 수 있습니다.<BR>
<BR>
★유전자와 진화<BR>
모든 슬라임은 유전자를 가지고 있으며 능력치와 외형은 유전자로 결정됩니다. 강한 개체가 더 자주 선택되기 때문에 도태압이 생기고, 전체 종이 진화하는 모습을 볼 수 있습니다.<BR>
<BR>
★기타<BR>
조건이 맞으면 숨겨진 변이체가 등장합니다. 여러 종류가 있으니 혈통과 유전자 조합을 살펴보세요.<BR>
_EOF_
	print $html_foot;
}
sub mania {
	print $html_head;
	print<<"_EOF_";
$navibar
<br>
이 페이지는 100회 이상 플레이한 숙련 브리더를 위한 시스템 해설입니다.<BR>
<BR>
★유전 파라미터<BR>
HRD, MSL, SFT, BRN, NET, FAT, MEN, SEX, AIR, SNS의 10개 파라미터가 슬라임의 신체 특성을 결정합니다.<BR>
각 파라미터는 능력값과 자기 주장도로 구성되며, 자기 주장도가 높은 유전자가 우성으로 작용합니다.<BR>
유전자는 교배될 때 일정 폭으로 변화합니다. 변화 폭은 랭킹 전체의 평균 체중에 영향을 받으며, 작은 개체의 씨앗은 변화가 크고 큰 개체의 씨앗은 변화가 작습니다.<BR>
<BR>
★파라미터 의미<BR>
HRD는 표피의 단단함, MSL과 SFT는 근육, BRN은 두뇌, NET은 신경, FAT는 지방, MEN은 정신력, AIR는 심폐 기능, SNS는 감각 기관, SEX는 번식력입니다.<BR>
<BR>
★능력치 공식<BR>
weight, HP, STM, STR, DEX, AGL, SPD, CST, 번식력은 여러 유전 파라미터의 조합으로 계산됩니다. 능력이 높을수록 전투력은 올라가지만 공격 시 소비하는 스태미나도 커집니다.<BR>
번식력 / 10의 정수부가 초기 씨앗 수가 되며, 누군가 플레이할 때마다 번식력만큼 씨앗 생성 게이지가 차오릅니다.<BR>
<BR>
★계통과 닉스<BR>
기본 상성은 아버지 계통과 외조부 계통의 조합으로 결정됩니다. 네 계통이 모두 다르게 조합될수록 닉스 효과를 최대한 발휘합니다.<BR>
계통 타입은 특정 능력치 상승에 영향을 주며, 8계통 중 더 많은 종류를 확보할수록 타입 효과가 강화됩니다.<BR>
이 요소 때문에 다음 세대까지 고려한 교배 전략이 가능합니다.<BR>
<BR>
★전투 프로그램<BR>
전투 내부에서는 STM 감소에 따른 계수 A와 B가 적용됩니다. SPD 게이지가 가득 차면 공격하고, DEX와 AGL 난수 비교로 명중 여부를 정합니다.<BR>
명중하면 HP, STM, 속도 게이지에 피해를 주며, 큰 피해를 주면 상대의 자세가 무너져 연속 공격이 쉬워집니다. 빗나간 공격도 압박으로 STM 피해를 줄 수 있습니다.<BR>
<BR>
★외형과 변이<BR>
색 유전자, 변이 스위치, 변이체 결정 유전자가 있습니다. 특정 조합이 맞으면 변이체가 태어나고, 돌연변이가 일어나면 유전자 그룹이 반전됩니다.<BR>
<BR>
★어린 세대가 강해질 수 있는 이유<BR>
초기 유전자와 알 수 없는 씨앗의 유전자는 자기 주장도가 낮은 편이어서 교배 상대의 좋은 유전자를 잘 드러나게 합니다. 그래서 초반 세대에서도 강한 슬라임이 나올 수 있습니다.<BR>
<BR>
★브리더 랭킹<BR>
승리는 운의 영향을 받지만, 교배 전략을 통해 승률을 높일 수 있습니다. SKILL은 누적 포인트와 플레이 횟수를 바탕으로 계산되며, 플레이 수가 많아질수록 실제 실력에 가까워지도록 보정됩니다.<BR>
<BR>
시스템 구조를 이해했다면, 계속 슬라임 브리더를 즐겨 주세요.<BR>
_EOF_
	print $html_foot;
}
