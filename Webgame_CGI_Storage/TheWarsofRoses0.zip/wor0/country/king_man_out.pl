#_/_/_/_/_/_/_/_/_/_/_/_/#
#_/      �ذ�      _/#
#_/_/_/_/_/_/_/_/_/_/_/_/#

sub KING_MAN_OUT {

	&CHARA_MAIN_OPEN;

	&COUNTRY_DATA_OPEN("$kcon");
	&TOWN_DATA_OPEN("$kpos");

	$cpoint = $COUNTRY_POINT*2;
	&HEADER;

	print <<"EOM";
<TABLE WIDTH="100%" height=100% bgcolor=$TABLE_C>
<TBODY><TR>
<TD BGCOLOR=$TD_C1 WIDTH=100% height=5> <font size=4> ����<B> * �ذ� *</B>����</font></TD>
</TR><TR>
<TD bgcolor=$TD_C4 height=5>
<TABLE border="0"><TBODY>
<TR>
<TD bgcolor=$TD_C1><img src="$IMG/$kchara.gif"></TD>
<TD bgcolor=$TD_C4 WIDTH=100% align=center>
<TABLE bgcolor=$TABLE_C border="0">
<TBODY>
<TR>
<TD bgcolor=$TD_C2>�̸�</TD>
<TD bgcolor=$TD_C2>�Ӽ�</TD>
<TD bgcolor=$TD_C3>����</TD>
</TR>
<TR>
<TD bgcolor=$TD_C2>$kunit��</TD>
<TD bgcolor=$TD_C2>$ELE[$kele]</TD>
<TD bgcolor=$TD_C3>$SYOKU[$kclass]</TD>
</TR>
<TR>
<TD bgcolor=$TD_C2>������</TD>
<TD bgcolor=$TD_C1 colspan=3 align=right>$kgold G</TD>
</TR>
</TBODY></TABLE>
</TD>
</TR>
</TBODY></TABLE>
</TD>
</TR>
<TR>
<TD bgcolor=$TD_C4 height="5">
<TABLE bgcolor=$TABLE_C  border="0" width=100%><TBODY>
<TR><TD width="100%" bgcolor=$TALK_BG><font color=$TALK_FONT>������ ĳ���͸� ���󿡼� ������ �� �ֽ��ϴ�.<BR></font></TD>
</TR>
</TBODY></TABLE>
</TD>
</TR>
<TR>
<TD bgcolor=$TD_C4>
<CENTER>
���� $xxname���� �ڱ� : <font color=red size=3>$xxgold G</font><p>
<br><form action="$FILE_COUNTRY" method="post">
EOM
	print "<TABLE BGCOLOR=$TABLE_C align=\"top\"><TBODY><TR><TD colspan=2 BGCOLOR=$TD_C4 align=\"center\">�ذ��� ����� ����</TD></TR>";
	open(IN,"$CHARA_DATA_LIST") or &ERR('���� �б� ����');
	@S_CHARA = <IN>;
	close(IN);

	@tmp = map {(split /<>/)[19]} @S_CHARA;
	@S_CHARA = @S_CHARA[sort {$tmp[$b] <=> $tmp[$a]} 0 .. $#tmp];

	foreach(@S_CHARA) {
		($jid,$jpass,$jname,$jurl,$jchara,$jsex,$jhp,$jmaxhp,$jmp,$jmaxmp,$jele,$jstr,$jvit,$jint,$jmen,$jagi,$jcom,$jgold,$j_ex,$jcex,$junit,$jcon) = split(/<>/);
		if($kid eq $jid){next;}
		if("$jcon" eq "$kcon") {
			$con .= "<option value=$jid>$jname��\n";
		}
	}

	print "<TR><TD><select name=out>$con</select></TD></TR>";
	print "</TBODY></TABLE>";

print <<"EOM";
<input type=hidden name=id value=$kid>
<input type=hidden name=pass value=$kpass>
<input type=hidden name=mode value=KING_MAN_OUT2>
<input type=submit value="�ذ��Ѵ�">
</form>
</font></CENTER>

<form action="$FILE_STATUS" method="post">
<input type=hidden name=id value=$kid>
<input type=hidden name=pass value=$kpass>
<input type=hidden name=mode value=STATUS>
<input type=submit value="������ ���ư���"></form>
</TD>
</TR>
</TBODY></TABLE>
EOM

	&FOOTER;
	exit;
}
1;