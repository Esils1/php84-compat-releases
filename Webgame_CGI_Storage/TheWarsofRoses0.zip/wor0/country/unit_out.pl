#_/_/_/_/_/_/_/_/_/#
#_/    �δ� ���  _/#
#_/_/_/_/_/_/_/_/_/#

sub UNIT_OUT {

	&CHARA_OPEN;

	if($in{'did'} eq $kid){&ERR("�ڽ��� ������ �� �����ϴ�.");}

	open(IN,"$UNIT_LIST") or &ERR("���� �б� ����");
	@UNI_DATA = <IN>;
	close(IN);

	$mhit=0;$hit=0;@NEW_UNI_DATA=();
	foreach(@UNI_DATA){
		($unit_id,$uunit_name,$ucon,$ureader,$uid,$uname,$uchara,$umes,$uflg)=split(/<>/);
		if("$unit_id" eq "$kid"){
			$hit=1;
			last;
		}
	}

	if(!$hit){
		&ERR("���常 ������ �� �ֽ��ϴ�.");
	}

	@NEW_UNI_DATA=();
	foreach(@UNI_DATA){
		($unit_id,$uunit_name,$ucon,$ureader,$uid,$uname,$uchara,$umes,$uflg)=split(/<>/);
			if("$uid" eq "$in{'did'}"){
				open(IN,"./charalog/main/$in{'did'}.cgi");
				@E_DATA = <IN>;
				close(IN);
				($eid,$epass,$ename,$eurl,$echara,$esex,$ehp,$emaxhp,$emp,$emaxmp,$eele,$estr,$evit,$eint,$emen,$eagi,$ecom,$egold,$e_ex,$ecex,$eunit,$econ,$earm,$epro,$eacc,$esub1,$esub2,$etac,$esta,$epos,$emes,$ehost,$edate,$esyo,$eclass,$etotal,$ekati) = split(/<>/,$E_DATA[0]);
				$eunit = "���Ҽ�";
				$esub1 = "";
				@NEW_DATA=();
				unshift(@NEW_DATA,"$eid<>$epass<>$ename<>$eurl<>$echara<>$esex<>$ehp<>$emaxhp<>$emp<>$emaxmp<>$eele<>$estr<>$evit<>$eint<>$emen<>$eagi<>$ecom<>$egold<>$e_ex<>$ecex<>$eunit<>$econ<>$earm<>$epro<>$eacc<>$esub1<>$esub2<>$etac<>$esta<>$epos<>$emes<>$ehost<>$edate<>$esyo<>$eclass<>$etotal<>$ekati<>\n");
				open(OUT,">./charalog/main/$eid.cgi");
				print OUT @NEW_DATA;
				close(OUT);
				$mess = "$uunit_name �δ뿡�� $ename(��)�� ���Ѿҽ��ϴ�.";
			}else{
				push(@NEW_UNI_DATA,"$_");
			}
	}

			open(IN,"$MESSAGE_LIST") or &ERR('���� �б� ����');
			@MES_REG = <IN>;
			close(IN);

			$mes_num = @MES_REG;
			if($mes_num > $MES_MAX) { pop(@MES_REG); }
			unshift(@MES_REG,"$unit_id<>$kid<>$kname<><font color=FF0000>����: $mess<>$uname<>$daytime<>$kchara<>0<>\n");

			$mes_num = @MES_REG;
			if($mes_num > $MES_MAX) { pop(@MES_REG); }
			unshift(@MES_REG,"$eid<>$kid<>$kname<><font color=FF0000>����: $mess<>$ename<>$daytime<>$kchara<>0<>\n");
			open(OUT,">$MESSAGE_LIST") or &ERR('���� �б� ����');
			print OUT @MES_REG;
			close(OUT);

	open(OUT,">$UNIT_LIST") or &ERR('UNIT3 ���ο� ����Ÿ�� �� �� �����ϴ�.');
	print OUT @NEW_UNI_DATA;
	close(OUT);

	&CHARA_INPUT;
	&CHARA_DATA_LIST_INPUT;
	&HEADER;
	print <<"EOM";
<CENTER><hr size=0><h2>$mess</h2><p>

<form action="$FILE_STATUS" method="post">
<input type=hidden name=id value=$kid>
<input type=hidden name=pass value=$kpass>
<input type=hidden name=mode value=STATUS>
<input type=submit value="������ ���ư���"></form></CENTER>
EOM
	&FOOTER;
	exit;
}
1;