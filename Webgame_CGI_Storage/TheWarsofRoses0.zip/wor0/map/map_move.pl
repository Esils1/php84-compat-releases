#_/_/_/_/_/_/_/_/_/_/_/#
#_/    F MAP ȭ��    _/#
#_/_/_/_/_/_/_/_/_/_/_/#

sub MAP_MOVE {

	&CHARA_MAIN_OPEN;
	&MAKE_GUEST_LIST;
	if(!@m_list){@m_list = 'No PLAYER'; $num = 0;}
	$num = @m_list;
	$sb_member = "PLAYER ($num��) : @m_list";

	if($mode eq "MAP_MOVE"){
		open(IN,"$MAP_LOG_LIST");
		@S_MOVE = <IN>;
		close(IN);

		open(MOVE,"$MAP_MOVE_LIST") or &ERR('������ �� �� �����ϴ�.');
		@M_LIST=<MOVE>;
		close(MOVE);
	}

	&TIME_DATA;
	if($hour < 6){$time_img = 2;
	}elsif($hour > 20){$time_img = 2;
	}elsif($hour > 13){$time_img = 1;
	}else{$time_img = 0;}

	open(IN,"./charalog/map/$in{'id'}.cgi");
	@P_MOVE = <IN>;
	close(IN);

	($s_kid,$s_kx,$s_ky) = split(/<>/,$P_MOVE[0]);
	if($s_ky + 1 <= 15){
		$s_move  ="<option value=\"0\">�������� �̵�";}
	if($s_kx + 1 <= 15){
		$s_move .="<option value=\"1\">�������� �̵�";}
	if($s_ky - 1 >= 0){
		$s_move .="<option value=\"2\">�������� �̵�";}
	if($s_kx - 1 >= 0){
    	$s_move .="<option value=\"3\">�������� �̵�";}

	if($s_kx >7 && $s_ky >7){
		$map_img = "$DESERT[$time_img]";
	}elsif($s_kx >7 && $s_ky >0){
		$map_img = "$LIVER[$time_img]";
	}elsif($s_kx >0 && $s_ky >7){
		$map_img = "$PRAIRIE[$time_img]";
	}elsif($s_kx >0 && $s_ky >0){
		$map_img = "$HILL[$time_img]";
	}else{
		$map_img = "$ARECHI[$time_img]";
	}

	open(IN,"$TOWN_LIST") or &ERR("������ �� �� �����ϴ�.");
	@TOWN_DATA = <IN>;
	close(IN);
	$hit=0;
	foreach(@TOWN_DATA){
		($zcid,$zname,$zele,$zcon,$zmoney,$zmes,$zx,$zy)=split(/<>/);
		if("$zx" eq "$s_kx" && "$zy" eq "$s_ky"){$hit=1;$map_img = "$TOWN[$time_img]";last;}
	}

	$e_hit=0;
	foreach(@M_LIST){
		($m_id,$mx,$my,$munit,$mcon) = split(/<>/);
		if("$s_kx" eq "$mx" && "$s_ky" eq "$my" && "$kid" ne "$m_id"){
			$e_hit=1;last;
		}
	}


	if($hit){
		if($zname eq "���" && "$zcon" ne "$kcon"){
			$map_img = "$FORT[$time_img]";
			$zmes .= "����� �����մϴ�.<BR>�����ϱ�?<BR><form action=$FILE_BATTLE method=post><input type=hidden name=id value=$kid><input type=hidden name=pass value=$kpass><input type=hidden name=conid value=$zcon><input type=hidden name=yousai value=1><input type=hidden name=mode value=BATTLE2><input type=submit value=����� ����></form>";
		}elsif($zname ne "���"){
			$zmes .= "<form action=$FILE_STATUS method=post><input type=hidden name=id value=$kid><input type=hidden name=pass value=$kpass><input type=hidden name=townid value=$zcid><input type=hidden name=mode value=MOVE><input type=submit value=���� ����></form>";
		}elsif($e_hit && "$mcon" ne "$kcon"){
			$map_img = "$FORT[$time_img]";
			$zmes = "$munit �δ븦 �߰�! ��� �Ͻðڽ��ϱ�?<BR><form action=\"$FILE_BATTLE\" method=\"post\"><input type=hidden name=id value=$kid><input type=hidden name=pass value=$kpass><input type=hidden name=eid value=$m_id><input type=hidden name=mode value=\"BATTLE\"><input type=hidden name=navi value=$in{navi}><input type=\"submit\" value=\"����\"></form>";
		}else{
			$map_img = "$FORT[$time_img]";
			$zmes="";
		}
	}elsif($e_hit && "$mcon" ne "$kcon"){
		$zmes = "$munit($ELE[$mcon]) �δ븦 �߰�! ��� �Ͻðڽ��ϱ�?<BR><form action=\"$FILE_BATTLE\" method=\"post\"><input type=hidden name=id value=$kid><input type=hidden name=pass value=$kpass><input type=hidden name=eid value=$m_id><input type=hidden name=mode value=\"BATTLE\"><input type=hidden name=navi value=$in{navi}><input type=\"submit\" value=\"����\"></form>";
	}else{
		$zmes="";
	}

	&HEADER;
print <<"EOM";
<TABLE bgcolor=$TABLE_C width=100% border="0">
  <TBODY>
    <TR>
      <TD bgcolor=$TD_C4 colspan=2 width=100%>$sb_member
      </TD>
    </TR>
    <TR>
      <TD bgcolor=$TD_C4 width=60%>
      <TABLE width=60% border="0">
        <TBODY>
          <TR>
            <TH>MAP($kunit ��)</TH>
          </TR>
        </TBODY>
      </TABLE>
      <TABLE bgcolor=$TD_C2 background="$IMG/mapbg.gif" width=100% height=5 border="0">
        <TBODY>
          <TR>
            <TD width=20 bgcolor=$TD_C2>-</TD>
            <TD width=20 bgcolor=$TD_C1>0</TD>
            <TD width=20 bgcolor=$TD_C1>1</TD>
            <TD width=20 bgcolor=$TD_C1>2</TD>
            <TD width=20 bgcolor=$TD_C1>3</TD>
            <TD width=20 bgcolor=$TD_C1>4</TD>
            <TD width=20 bgcolor=$TD_C1>5</TD>
            <TD width=20 bgcolor=$TD_C1>6</TD>
            <TD width=20 bgcolor=$TD_C1>7</TD>
            <TD width=20 bgcolor=$TD_C1>8</TD>
            <TD width=20 bgcolor=$TD_C1>9</TD>
            <TD width=20 bgcolor=$TD_C1>10</TD>
            <TD width=20 bgcolor=$TD_C1>11</TD>
            <TD width=20 bgcolor=$TD_C1>12</TD>
            <TD width=20 bgcolor=$TD_C1>13</TD>
            <TD width=20 bgcolor=$TD_C1>14</TD>
            <TD width=20 bgcolor=$TD_C1>15</TD>
          </TR>
EOM

     for($i=15;$i>=0;$i--){
		print "<TR><TD bgcolor=$TD_C3>$i</td>";
		for($j=0;$j<=15;$j++){
			if($s_kx eq $j && $s_ky eq $i){
				print "<td ><font color=red>��</font></td>";
			}elsif($in{'navi'} eq "on"){
				$m_hit=0;
				foreach(@TOWN_DATA){
				($zzcid,$zzname,$zzele,$zzcon,$zzmoney,$zzmes,$zzx,$zzy)=split(/<>/);
				if("$zzx" eq "$j" && "$zzy" eq "$i"){$m_hit=1;last;}
				}
				if($m_hit){
					if($zzname eq "���"){
						print "<td bgcolor=$ELE_C[$zzcon]><img src=$IMG/m_1.gif width=16 height=16 border=0 alt=$zzmes></td>";
					}else{
						print "<td bgcolor=$ELE_C[$zzcon]><img src=$IMG/m_2.gif width=16 height=16 border=0 alt=$zzname></td>";
					}
				}else{
				$m2_hit=0;
				foreach(@M_LIST){
					($m2_id,$m2x,$m2y,$m2unit,$m2con) = split(/<>/);
					if("$m2x" eq "$j" && "$m2y" eq "$i" ){
						$m2_hit=1;last;
					}
				}
				if($m2_hit){
					if($m2con eq "1"){
						print "<td><font size=3 color=$ELE_C[$m2con]>��</td>";
					}elsif($m2con eq "2"){
						print "<td><font size=3 color=$ELE_C[$m2con]>��</td>";
					}elsif($m2con eq "3"){
						print "<td><font size=3 color=$ELE_C[$m2con]>��</td>";
					}elsif($m2con eq "4"){
						print "<td><font size=3 color=$ELE_C[$m2con]>��</td>";
					}else{
						print "<td><font size=3 color=888888>��</td>";
					}
				}else{print "<td><font color=\"#9d9d72\">&nbsp;</font></td>";}
				}
			}else{
				$m2_hit=0;
				foreach(@M_LIST){
					($m2_id,$m2x,$m2y,$m2unit,$m2con) = split(/<>/);
					if("$m2x" eq "$j" && "$m2y" eq "$i" ){
						$m2_hit=1;last;
					}
				}
				if($m2_hit){
					if($m2con eq "1"){
						print "<td><font size=3 color=$ELE_C[$m2con]>��</td>";
					}elsif($m2con eq "2"){
						print "<td><font size=3 color=$ELE_C[$m2con]>��</td>";
					}elsif($m2con eq "3"){
						print "<td><font size=3 color=$ELE_C[$m2con]>��</td>";
					}elsif($m2con eq "4"){
						print "<td><font size=3 color=$ELE_C[$m2con]>��</td>";
					}else{
						print "<td><font size=3 color=888888>��</td>";
					}
				}else{print "<td><font color=\"#9d9d72\">&nbsp;</font></td>";}
			}
		}
		print "</TR>";
	}


print <<"EOM";
        </TBODY>
      </TABLE>
      </TD>
      <TD bgcolor=$TD_C3>
      <TABLE width=100% border="0">
        <TBODY>
          <TR>
            <TH bgcolor=$TD_C4>MAP LOG</TH></TR><TR>
<TD bgcolor=$TD_1>@S_MOVE</TD>
          </TR>
        </TBODY>
      </TABLE>
</TD>
    </TR>
    <TR>
      <TD bgcolor=$TALK_BG><TABLE width=100%><TBODY><TR><TD width=30%><img src=$IMG/$IMG_GROUND/$map_img width=160 height=120></TD>
<TD><font color=$TALK_FONT>$zmes</font></TD></TR></TBODY></TABLE></TD>
      <TD bgcolor=$TD_C4>���� ��ġ ($s_kx,$s_ky)<form action="$FILE_MAP" method="post">
<input type=hidden name=id value=$kid>
<input type=hidden name=pass value=$kpass>
<input type=hidden name=unit value=$kunit>
<input type=hidden name=con value=$kcon>
<input type=hidden name=navi value=$in{navi}>
<input type=hidden name=mode value="CHARA_MOVE">
<select name="chara_m">
    <option >--�̵�--
$s_move
</select><input type="submit" value="�̵�">
</form>
      </TD>
    </TR>
  </TBODY>
</TABLE>
$daytime
EOM
	if($MORE_MONEY){
print <<"EOM";
		<form action="$FILE_STATUS" method="post">
		<input type=hidden name=id value=$kid>
		<input type=hidden name=pass value=$kpass>
		<input type=hidden name=mode value=GET_MONEY>
		<input type="submit" value="�� ����-">
		</form>
EOM
	}
	&FOOTER;
	exit;

}
1;