#_/_/_/_/_/_/_/_/_/_/_/_/#
#_/      ������ ����     _/#
#_/_/_/_/_/_/_/_/_/_/_/_/#

sub GET_TOWN {

	&CHARA_OPEN;
	if($scid){
        $sstatus ="<TR><TD bgcolor=$TD_C2>$sname</TD><TD bgcolor=$TD_C3 align=right>$slv</TD><TD bgcolor=$TD_C2>$ELE[$sele]</TD><TD bgcolor=$TD_C3>$SYOKU[$sclass]</TD></TR>";
	}
	if($tcid){
        $tstatus ="<TR><TD bgcolor=$TD_C2>$tname</TD><TD bgcolor=$TD_C3 align=right>$tlv</TD><TD bgcolor=$TD_C2>$ELE[$tele]</TD><TD bgcolor=$TD_C3>$SYOKU[$tclass]</TD></TR>";
	}

	open(IN,"$TOWN_LIST") or &ERR("������ �� �� �����ϴ�.");
	@TOWN_DATA = <IN>;
	close(IN);
	foreach(@TOWN_DATA){
		($zcid,$zname,$zele,$zcon,$zmoney,$zmes,$zx,$zy)=split(/<>/);
		if("$zcid" eq "$in{town}"){last;}
	}
	$s_bit = 1;

	$Value=int(($kmaxhp/3)+($kmaxmp/3)+$kstr+$kvit+$kint+$kmen+$kagi)*$s_bit*$SALARY;
	&HEADER;

	print <<"EOM";
<TABLE WIDTH="100%" height=100% bgcolor=$TABLE_C>
<TBODY><TR>
<TD BGCOLOR=$TD_C1 WIDTH=100% height=5> <font size=4> ���� <B> * ������ ���� *</B> ����</font></TD>
</TR><TR>
<TD bgcolor=$TD_C4 height=5>
<TABLE border="0"><TBODY>
<TR>
<TD bgcolor=$TD_C1><img src="$IMG/$kchara.gif"></TD>
<TD bgcolor=$TD_C2>$simg</TD>
<TD bgcolor=$TD_C3>$timg</TD>
<TD bgcolor=$TD_C4 WIDTH=100% align=center>
<TABLE bgcolor=$TABLE_C border="0">
<TBODY>
<TR>
<TD bgcolor=$TD_C2>�̸�</TD>
<TD bgcolor=$TD_C3>LV</TD>
<TD bgcolor=$TD_C2>�Ӽ�</TD>
<TD bgcolor=$TD_C3>����</TD>
</TR>
<TR>
<TD bgcolor=$TD_C2>$kname</TD>
<TD bgcolor=$TD_C3 align=right>$klv</TD>
<TD bgcolor=$TD_C2>$ELE[$kele]</TD>
<TD bgcolor=$TD_C3>$SYOKU[$kclass]</TD>
</TR>
$sstatus$tstatus
<TR>
<TD bgcolor=$TD_C2>������</TD>
<TD bgcolor=$TD_C1 colspan=3 align=right>$kgold G</TD>
</TR>
</TBODY></TABLE>
</TD>
</TR>
</TBODY></TABLE>
</TD>
</TR>
<TR>
<TD bgcolor=$TD_C4 height="5">
<TABLE bgcolor=$TABLE_C  border="0"><TBODY>
<TR><TD width="100%" bgcolor=$TALK_BG><font color=$TALK_FONT>����� �ı������Ƿ� ���� 1���� ���� �� �ֽ��ϴ�. ��� ������ �����Ͻðڽ��ϱ�?</font></TD>
<TD bgcolor=$TD_C4></TD>
</TR>
</TBODY></TABLE>
</TD>
</TR>
<TR>
<TD bgcolor=$TD_C4>
<CENTER>
<form action="$FILE_MAP" method="post">
<input type=hidden name=id value=$kid>
<input type=hidden name=pass value=$kpass>
<input type=hidden name=mode value="CHANGE_TOWN">
<select name="townid">
<option value="">--����--
EOM
	open(IN,"$TOWN_LIST");
	@MOVE_TOWN=<IN>;
	close(IN);
	foreach(@MOVE_TOWN){
		($town_id,$town_name,$town_ele,$town_con)=split(/<>/);
		if($town_name eq "���" || "$town_con" ne "$in{'con'}"){next;}
		print "<option value=\"$town_id\">$town_name";
	}
	print <<"EOM";

</select><BR><BR>
<input type="submit" value="����"></form>
</CENTER>

<form action=$FILE_MAP method=post><input type=hidden name=id value=$kid><input type=hidden name=pass value=$kpass><input type=hidden name=navi value=$in{navi}><input type=hidden name=mode value=MAP_MOVE>
<input type=submit value="���д�"></form>
</TD>
</TR>
</TBODY></TABLE>
EOM

	&FOOTER;
	exit;
}
1;