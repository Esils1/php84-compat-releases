#_/_/_/_/_/_/_/_/_/_/_/#
#_/    F MAP ȭ��    _/#
#_/_/_/_/_/_/_/_/_/_/_/#

sub OPEN_MAP {


	open(IN,"$MAP_LOG_LIST");
	@S_MOVE = <IN>;
	close(IN);

	$p=0;
	while($p<15){
		$S_MES .= "<font color=green>��</font>$S_MOVE[$p]";
		$p++;
	}

	&TIME_DATA;
	if($hour < 6){$time_img = 2;$table_font = "#FFFFFF";$table_color = "#000000";
	}elsif($hour > 18){$time_img = 2;$table_font = "#FFFFFF";$table_color = "#000000";
	}elsif($hour > 15){$time_img = 2;$table_font = "#FFFFFF";$table_color = "#804020";
	}elsif($hour > 12){$time_img = 1;$table_font = "#000000";$table_color = "#FFFFDC";
	}else{$time_img = 0;$table_font = "#000000";$table_color = "#FFEFCC";}

	open(IN,"./charalog/map/$in{'id'}.cgi");
	@P_MOVE = <IN>;
	close(IN);

	open(IN,"$TOWN_LIST") or &ERR("������ �� �� �����ϴ�.");
	@TOWN_DATA = <IN>;
	close(IN);
	$hit=0;
	foreach(@TOWN_DATA){
		($zcid,$zname,$zele,$zcon,$zmoney,$zmes,$zx,$zy)=split(/<>/);
		if("$zx" eq "$s_kx" && "$zy" eq "$s_ky"){$hit=1;$map_img = "$TOWN[$time_img]";last;}
	}

	$e_hit=0;
	foreach(@M_LIST){
		($m_id,$mx,$my,$munit,$mcon) = split(/<>/);
		if("$s_kx" eq "$mx" && "$s_ky" eq "$my" && "$kid" ne "$m_id"){
			$e_hit=1;last;
		}
	}

	open(IN,"$COUNTRY_LIST") or &ERR2('������ �� �� �����ϴ�. err no :country');
	@COU_DATA = <IN>;
	close(IN);

	foreach(@COU_DATA){
		($xxcid,$xxname,$xxele,$xxnum,$xxins,$xxind,$xxall,$xxgold,$xxhp,$xxmaxhp,$xxstr,$xxvit,$xxagi)=split(/<>/);
		$all_num += $xxnum;
		$all_gold += $xxgold;
	}


	$data_mes .= "<TR><Th colspan=3 bgcolor=$TD_C2>�� ���� ����Ÿ</Th></tr><TR><Th bgcolor=$TD_C4>������</Th><Th bgcolor=$TD_C4>�ڱ�</Th><Th bgcolor=$TD_C4>����� HP</Th></TR>";
	$country_no=0;$i=1;
	foreach(@COU_DATA){
		($xxcid,$xxname,$xxele,$xxnum,$xxins,$xxind,$xxall,$xxgold,$xxhp,$xxmaxhp,$xxstr,$xxvit,$xxagi)=split(/<>/);
		if($all_gold){
		$n_gold = int(($xxgold/($all_gold))*1000)/10;
		}else{
		$n_gold = 0;
		}
		if($all_num){
		$n_num  = int(($xxnum/($all_num))*1000)/10;
		}else{
		$n_num  = 0;
		}
		$data_mes .= "<TR><Th bgcolor=$ELE_BG[$xxele] colspan=3><font color=$ELE_C[$xxele]>$xxname ��</Th></TR><TR><Th bgcolor=$TD_C4>$xxnum��($n_num\%)</Th><Th bgcolor=$TD_C4>$xxgold G($n_gold\%)</Th><Th bgcolor=$TD_C4>$xxhp/$xxmaxhp</Th></TR>";
		$c_gold[$i] = $xxgold;
		$c_num[$i] = $xxnum;
		$i++;
	}

	$zmes="";

	&HEADER;
print <<"EOM";
<TABLE bgcolor=$TABLE_C width=100% border="0">
  <TBODY>
    <TR>
      <TD bgcolor=$TD_C4 colspan=2 width=100%>$sb_member
      </TD>
    </TR>
    <TR>
      <TD bgcolor=$table_color width=40%>
      <TABLE width=70% border="0">
        <TBODY>
          <TR>
            <TH><font color=$table_font><font size=4>$GAME_TITLE</font> <BR>WORLD MAP</font></TH>
          </TR>
        </TBODY>
      </TABLE>
      <TABLE bgcolor=$TD_C2 background="$IMG/mapbg.gif" width=100% height=5 border="0">
        <TBODY>
          <TR>
            <TD width=20 bgcolor=$TD_C2>-</TD>
            <TD width=20 bgcolor=$TD_C1>0</TD>
            <TD width=20 bgcolor=$TD_C1>1</TD>
            <TD width=20 bgcolor=$TD_C1>2</TD>
            <TD width=20 bgcolor=$TD_C1>3</TD>
            <TD width=20 bgcolor=$TD_C1>4</TD>
            <TD width=20 bgcolor=$TD_C1>5</TD>
            <TD width=20 bgcolor=$TD_C1>6</TD>
            <TD width=20 bgcolor=$TD_C1>7</TD>
            <TD width=20 bgcolor=$TD_C1>8</TD>
            <TD width=20 bgcolor=$TD_C1>9</TD>
            <TD width=20 bgcolor=$TD_C1>10</TD>
            <TD width=20 bgcolor=$TD_C1>11</TD>
            <TD width=20 bgcolor=$TD_C1>12</TD>
            <TD width=20 bgcolor=$TD_C1>13</TD>
            <TD width=20 bgcolor=$TD_C1>14</TD>
            <TD width=20 bgcolor=$TD_C1>15</TD>
          </TR>
EOM

     for($i=15;$i>=0;$i--){
		print "<TR><TD bgcolor=$TD_C3>$i</td>";
		for($j=0;$j<=15;$j++){
				$m_hit=0;
				foreach(@TOWN_DATA){
				($zzcid,$zzname,$zzele,$zzcon,$zzmoney,$zzmes,$zzx,$zzy)=split(/<>/);
				if("$zzx" eq "$j" && "$zzy" eq "$i"){$m_hit=1;last;}
				}
				if($m_hit){
					if($zzname eq "���"){
						print "<td bgcolor=$ELE_C[$zzcon]><img src=$IMG/m_1.gif width=16 height=16 border=0 alt=$zzmes></td>";
					}else{
						print "<td bgcolor=$ELE_C[$zzcon]><img src=$IMG/m_2.gif width=16 height=16 border=0 alt=$zzname></td>";
					}
				}else{
					print "<td>&nbsp;</td>";
				}
		}
		print "</TR>";
	}


print <<"EOM";
        </TBODY>
      </TABLE>
      </TD>
      <TD bgcolor=$TD_C3>
      <TABLE width=100% border="0">
        <TBODY>
          <TR>
            <TH bgcolor=$TD_C4>MAP LOG</TH></TR><TR>
<TD bgcolor=$TD_1>$S_MES</TD>
          </TR>
        </TBODY>
      </TABLE>
</TD>
    </TR>
  </TBODY>
</TABLE>
<CENTER><TABLE width=50% bgcolor=$TABLE_C border=0 cellspacing=1><TBODY>
$data_mes 
  </TBODY>
</TABLE>

�� ����� ��: $all_num��
<p>
$daytime
EOM
	&FOOTER;
	exit;

}
1;