#_/_/_/_/_/_/_/_/_/_/_/_/#
#   CHARA MAIN OPEN      #
#_/_/_/_/_/_/_/_/_/_/_/_/#

sub CHARA_OPEN {&CHARA_MAIN_OPEN;}
sub CHARA_MAIN_OPEN {

	open(IN,"./charalog/main/$in{'id'}.cgi") or &ERR2('������ �� �� �����ϴ�. err no :main_chara');
	@CN_DATA = <IN>;
	close(IN);
	($kid,$kpass,$kname,$kurl,$kchara,$ksex,$khp,$kmaxhp,$kmp,$kmaxmp,$kele,$kstr,$kvit,$kint,$kmen,$kagi,$kcom,$kgold,$k_ex,$kcex,$kunit,$kcon,$karm,$kpro,$kacc,$ksub1,$ksub2,$ktac,$ksta,$kpos,$kmes,$khost,$kdate,$ksyo,$kclass,$ktotal,$kkati) = split(/<>/,$CN_DATA[0]);
	$klv = int($k_ex/100)+1;
	if($in{'id'} ne "$kid" or $in{'pass'} ne "$kpass"){&ERR2("ID �� ��ȣ�� Ʋ���ϴ�.");}

}

#_/_/_/_/_/_/_/_/_/_/_/_/#
#   CHARA MAIN INPUT     #
#_/_/_/_/_/_/_/_/_/_/_/_/#
sub CHARA_INPUT {&CHARA_MAIN_INPUT;}
sub CHARA_MAIN_INPUT {

	if($lockkey) { &F_LOCK; }
	&SET_COOKIE;
	&HOST_NAME;

	if($REFREE){
		if($ENV{'HTTP_REFERER'} !~ /$ROSER_URL/){ &ERR2("ERR No.002<BR>�� ĳ���ʹ� ���� �� �����ϴ�.<BR>�����ڿ��� �������ּ���.<BR>P1:$ROSER_URL <BR>P2$ENV{'HTTP_REFERER'}"); }
	}
	$date = time();
	unshift(@NEW_DATA,"$kid<>$kpass<>$kname<>$kurl<>$kchara<>$ksex<>$khp<>$kmaxhp<>$kmp<>$kmaxmp<>$kele<>$kstr<>$kvit<>$kint<>$kmen<>$kagi<>$kcom<>$kgold<>$k_ex<>$kcex<>$kunit<>$kcon<>$karm<>$kpro<>$kacc<>$ksub1<>$ksub2<>$ktac<>$ksta<>$kpos<>$kmes<>$host<>$date<>$ksyo<>$kclass<>$ktotal<>$kkati<>\n");
	open(OUT,">./charalog/main/$in{'id'}.cgi") or &ERR('MAIN ���ο� ����Ÿ�� �� �� �����ϴ�.');
	print OUT @NEW_DATA;
	close(OUT);
	if (-e $lockfile) { unlink($lockfile); }
}

#_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/#
#     ENEMY DATA ALL OPEN      #
#_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/#

sub ENEMY_OPEN {

	open(IN,"./charalog/main/$in{'eid'}.cgi") or &ERR2('ID �� ��ȣ�� Ʋ���ϴ�.');
	@E_DATA = <IN>;
	close(IN);
	($eid,$epass,$ename,$eurl,$echara,$esex,$ehp,$emaxhp,$emp,$emaxmp,$eele,$estr,$evit,$eint,$emen,$eagi,$ecom,$egold,$e_ex,$ecex,$eunit,$econ,$earm,$epro,$eacc,$esub1,$esub2,$etac,$esta,$epos,$emes,$ehost,$edate,$esyo,$eclass,$etotal,$ekati) = split(/<>/,$E_DATA[0]);
	$elv = int($e_ex/$EX)+1;
	if($in{'eid'} ne "$eid" ){&ERR2("ID �� ��ȣ�� Ʋ���ϴ�.");}

}

#_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/#
#    ENEMY DATA ALL INPUT      #
#_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/#
sub ENEMY_INPUT {

	if($lockkey) { &F_LOCK; }
	if($REFREE){
		if($ENV{'HTTP_REFERER'} !~ /$ROSER_URL/){ &ERR2("ERR No.002<BR>�� ĳ���ʹ� ���� �� �����ϴ�.<BR>�����ڿ��� �������ּ���.<BR>P1:$ROSER_URL <BR>P2$ENV{'HTTP_REFERER'}"); }
	}

	&HOST_NAME;
	$date = time();
	@NEW_DATA=();
	unshift(@NEW_DATA,"$eid<>$epass<>$ename<>$eurl<>$echara<>$esex<>$ehp<>$emaxhp<>$emp<>$emaxmp<>$eele<>$estr<>$evit<>$eint<>$emen<>$eagi<>$ecom<>$egold<>$e_ex<>$ecex<>$eunit<>$econ<>$earm<>$epro<>$eacc<>$esub1<>$esub2<>$etac<>$esta<>$epos<>$emes<>$host<>$date<>$esyo<>$eclass<>$etotal<>$ekati<>\n");
	open(OUT,">./charalog/main/$in{'eid'}.cgi") or &ERR2('ENEMY ���ο� ����Ÿ�� �� �� �����ϴ�.');
	print OUT @NEW_DATA;
	close(OUT);

	if (-e $lockfile) { unlink($lockfile); }

}

#_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/#
#_/       LOG ���      _/#
#_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/#

sub MAP_LOG {

	if($lockkey) { &F_LOCK; }
	open(IN,"$MAP_LOG_LIST");
	@S_MOVE = <IN>;
	close(IN);
	&TIME_DATA;

	unshift(@S_MOVE,"$_[0]($mday��$hour��$min��)<BR>\n");

	$ive = int(rand(1500));

	if($xxcid ne 0 && ($ive eq "2" || $ive eq "5" || $ive eq "7")){
		open(IN,"$COUNTRY_LIST");
		@COUN_DATA = <IN>;
		close(IN);
		$country_no=0;$hit=0;
		@NEW_COUNT_DATA=();
		if($ive eq "2"){
		foreach(@COUN_DATA){
			($vcid,$vname,$vele,$vnum,$vins,$vind,$vall,$vgold,$vhp,$vmaxhp,$vstr,$vvit,$vagi)=split(/<>/);
			if("$kcon" eq "$vcid"){
			$sgold = int($vgold/4);
			$vgold -= $sgold;
			push(@NEW_COUNT_DATA,"$vcid<>$vname<>$vele<>$vnum<>$vins<>$vind<>$vall<>$vgold<>$vhp<>$vmaxhp<>$vstr<>$vvit<>$vagi<>\n");
$ggname=$vname;
			}else{
			push(@NEW_COUNT_DATA,"$_");
			}
		}
			unshift(@S_MOVE,"<font color=red><b>[�̺�Ʈ]</b></font>���ο� ���� ������ �߻�! ���ε��� $ggname���� �ڱ� <font color=red>$sgold</font>G�� ��Ż�ذ���! ($mday��$hour��$min��)<BR>\n");
		}elsif($ive eq "5"){
		foreach(@COUN_DATA){
			($vcid,$vname,$vele,$vnum,$vins,$vind,$vall,$vgold,$vhp,$vmaxhp,$vstr,$vvit,$vagi)=split(/<>/);
			if("$kcon" eq "$vcid"){
			$vstr = int($vstr/2);
			$vvit = int($vvit/2);
			$vagi = int($vagi/2);
			push(@NEW_COUNT_DATA,"$vcid<>$vname<>$vele<>$vnum<>$vins<>$vind<>$vall<>$vgold<>$vhp<>$vmaxhp<>$vstr<>$vvit<>$vagi<>\n");
$ggname=$vname;
			}else{
			push(@NEW_COUNT_DATA,"$_");
			}
		}
			unshift(@S_MOVE,"<font color=red><b>[�̺�Ʈ]</b></font>�ϴÿ��� ������ ��������! $ggname���� ����� �ı��Ǿ� ���ȴ�! ($mday��$hour��$min��)<BR>\n");
		}elsif($ive eq "7"){
		foreach(@COUN_DATA){
			($vcid,$vname,$vele,$vnum,$vins,$vind,$vall,$vgold,$vhp,$vmaxhp,$vstr,$vvit,$vagi)=split(/<>/);
			if("$kcon" eq "$vcid"){
			$vgold += 10000000;
			push(@NEW_COUNT_DATA,"$vcid<>$vname<>$vele<>$vnum<>$vins<>$vind<>$vall<>$vgold<>$vhp<>$vmaxhp<>$vstr<>$vvit<>$vagi<>\n");
$ggname=$vname;
			}else{
			push(@NEW_COUNT_DATA,"$_");
			}
		}
			unshift(@S_MOVE,"<font color=red><b>[�̺�Ʈ]</b></font>�ݱ��� �߰�! $ggname���� 1000��G�� �տ� �־��� ($mday��$hour��$min��)<BR>\n");
		}
		open(OUT,">$COUNTRY_LIST");
		print OUT @NEW_COUNT_DATA;
		close(OUT);
	}
	splice(@S_MOVE,20);

	open(OUT,">$MAP_LOG_LIST") or &ERR2('LOG ���ο� ����Ÿ�� �� �� �����ϴ�.');
	print OUT @S_MOVE;
	close(OUT);
	if (-e $lockfile) { unlink($lockfile); }

}

#_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/#
#    BATTLE ITEM ALL OPEN      #
#_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/#

sub CHARA_ITEM_OPEN {

	open(IN,"$ARM_LIST") or &ERR('������ �� �� �����ϴ�.');
	@ARM_DATA = <IN>;
	close(IN);
	open(IN,"$PRO_LIST") or &ERR('������ �� �� �����ϴ�.');
	@PRO_DATA = <IN>;
	close(IN);
	open(IN,"$ACC_LIST") or &ERR('������ �� �� �����ϴ�.');
	@ACC_DATA = <IN>;
	close(IN);

	($karmname,$karmval,$karmdmg,$karmwei,$karmele,$karmsta,$karmclass,$karmtownid) = split(/<>/,$ARM_DATA[$karm]);
	if($karmsta eq "use"){
		open(IN,"./charalog/arm/$in{'id'}.cgi");
		@MY_ARM_DATA = <IN>;
		close(IN);
		($karmname,$karmval,$karmdmg,$karmwei,$karmele,$karmsta,$karmclass,$karmtownid) = split(/<>/,$MY_ARM_DATA[0]);
	}
	if($kele eq "$karmele" && $kele ne "0"){$karmdmg = int($karmdmg*1.5);}

	($kproname,$kproval,$kprodmg,$kprowei,$kproele,$kprosta,$kproclass,$kprotownid) = split(/<>/,$PRO_DATA[$kpro]);
	if($kele eq "$kproele" && $kele ne "0"){$kprodmg = int($kprodmg*1.5);}
	($kaccname,$kaccval,$kaccdmg,$kaccwei,$kaccele,$kaccsta,$kaccclass,$kacctownid) = split(/<>/,$ACC_DATA[$kacc]);
	if($kele eq "$kaccele" && $kele ne "0"){$kaccdmg = int($kaccdmg*1.5);}

	if($in{'eid'}){
		($earmname,$earmval,$earmdmg,$earmwei,$earmele,$earmsta,$earmclass,$earmtownid) = split(/<>/,$ARM_DATA[$earm]);
		if($earmsta eq "use"){
			open(IN,"./charalog/arm/$in{'eid'}.cgi");
			@MY_ARM_DATA = <IN>;
			close(IN);
			($earmname,$earmval,$earmdmg,$earmwei,$earmele,$earmsta,$earmclass,$earmtownid) = split(/<>/,$MY_ARM_DATA[0]);
		}
		if($eele eq "$earmele" && $eele ne "0"){$earmdmg = int($earmdmg*1.5);}

		($eproname,$eproval,$eprodmg,$eprowei,$eproele,$eprosta,$eproclass,$eprotownid) = split(/<>/,$PRO_DATA[$epro]);
		if($eele eq "$eproele" && $eele ne "0"){$eprodmg = int($eprodmg*1.5);}
		($eaccname,$eaccval,$eaccdmg,$eaccwei,$eaccele,$eaccsta,$eaccclass,$eacctownid) = split(/<>/,$ACC_DATA[$eacc]);
		if($eele eq "$eaccele" && $eele ne "0"){$eaccdmg = int($eaccdmg*1.5);}

	}

}

#_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/#
#      TAC DATA ALL OPEN       #
#_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/#

sub TAC_DATA_OPEN {

	open(IN,"$TEC_DATA") or &ERR('������ �� �� �����ϴ�.');
	@TEC = <IN>;
	close(IN);

	foreach(@TEC){
		($ktec_no,$ktec_name,$ktec_str,$ktec_hit,$ktec_sta,$ktec_cho,$ktec_class) = split(/<>/);
		if( $ktec_no eq "$ktac"){last;}
	}

	if($in{'eid'}){
		foreach(@TEC){
			($etec_no,$etec_name,$etec_str,$etec_hit,$etec_sta,$etec_cho,$etec_class) = split(/<>/);
			if( $etec_no eq "$etac"){last;}
		}

	}

}


#_/_/_/_/_/_/_/_/_/_/_/_/#
#       �ð� ���        #
#_/_/_/_/_/_/_/_/_/_/_/_/#

sub TIME_DATA {
$tt = time ;
($sec,$min,$hour,$mday,$mon,$year,$wday,$yday) = localtime(time);
$year += 1900;
$mon++;
$ww = (Sun,Mon,Tue,Wed,Thu,Fri,Sat)[$wday];
$daytime = sprintf("%4d\/%02d\/%02d\/(%s) %02d:%02d:%02d", $year,$mon,$mday,$ww,$hour,$min,$sec);

}

#_/_/_/_/_/_/_/_/_/_/_/_/#
#   CHARA MAIN OPEN      #
#_/_/_/_/_/_/_/_/_/_/_/_/#

sub CHARA_MAIN_OPEN {

	open(IN,"./charalog/main/$in{'id'}.cgi") or &ERR2('������ �� �� �����ϴ�. err no :main_chara');
	@CN_DATA = <IN>;
	close(IN);
	($kid,$kpass,$kname,$kurl,$kchara,$ksex,$khp,$kmaxhp,$kmp,$kmaxmp,$kele,$kstr,$kvit,$kint,$kmen,$kagi,$kcom,$kgold,$k_ex,$kcex,$kunit,$kcon,$karm,$kpro,$kacc,$ksub1,$ksub2,$ktac,$ksta,$kpos,$kmes,$khost,$kdate,$ksyo,$kclass,$ktotal,$kkati) = split(/<>/,$CN_DATA[0]);
	$klv = int($k_ex/100)+1;
	if($in{'id'} ne "$kid" or $in{'pass'} ne "$kpass"){&ERR2("ID �� ��ȣ�� Ʋ���ϴ�.");}

}

#_/_/_/_/_/_/_/_/_/_/_/_/#
#   CHARA MAIN INPUT     #
#_/_/_/_/_/_/_/_/_/_/_/_/#
sub CHARA_MAIN_INPUT {

	if($lockkey) { &F_LOCK; }
	&SET_COOKIE;
	&HOST_NAME;

	if($REFREE){
		if($ENV{'HTTP_REFERER'} !~ /$ROSER_URL/){ &ERR2("ERR No.002<BR>�� ĳ���ʹ� ���� �� �����ϴ�.<BR>�����ڿ��� �������ּ���.<BR>P1:$ROSER_URL <BR>P2$ENV{'HTTP_REFERER'}"); }
	}
	$date = time();
	unshift(@NEW_DATA,"$kid<>$kpass<>$kname<>$kurl<>$kchara<>$ksex<>$khp<>$kmaxhp<>$kmp<>$kmaxmp<>$kele<>$kstr<>$kvit<>$kint<>$kmen<>$kagi<>$kcom<>$kgold<>$k_ex<>$kcex<>$kunit<>$kcon<>$karm<>$kpro<>$kacc<>$ksub1<>$ksub2<>$ktac<>$ksta<>$kpos<>$kmes<>$host<>$date<>$ksyo<>$kclass<>$ktotal<>$kkati<>\n");
	open(OUT,">./charalog/main/$in{'id'}.cgi") or &ERR('MAIN ���ο� ����Ÿ�� �� �� �����ϴ�.');
	print OUT @NEW_DATA;
	close(OUT);
	if (-e $lockfile) { unlink($lockfile); }
}

#_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/#
#        COUNTRY DATA OPEN       #
#_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/#

sub COUNTRY_DATA_OPEN {

	if($C_DATA_WRITE){&ERR("���� ����Ÿ�� �����ϴ� ���Դϴ�.");}
	open(IN,"$COUNTRY_LIST") or &ERR2('������ �� �� �����ϴ�. err no :country');
	@COU_DATA = <IN>;
	close(IN);
	$country_no=0;$hit=0;
	foreach(@COU_DATA){
		($xxcid,$xxname,$xxele,$xxnum,$xxins,$xxind,$xxall,$xxgold,$xxhp,$xxmaxhp,$xxstr,$xxvit,$xxagi)=split(/<>/);
		if("$_[0]" eq "$xxcid"){$hit=1;last;}
		$country_no++;
	}

	if(!$hit){
		$xxcid = 0;
		$xxname = "���Ҽ�";
		$xxele = 0;
		$xxnum = 0;
		$xxins = 0;
		$xxind = 0;
		$xxall = 0;
		$xxgold = 0;
		$xxhp = 0;
		$xxmaxhp = 0;
		$xxstr = 0;
		$xxvit = 0;
		$xxagi = 0;
	}

	$c = 1;
	$country[0] = "���Ҽ�";
	foreach(@COU_DATA){
		($x2cid,$x2name,$x2ele,$x2num)=split(/<>/);
		$country[$x2cid] = "$x2name";
		$max_num += $x2num;
		$c++;
	}
}

#_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/#
#      COUNTRY DATA INPUT      #
#_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/#
sub COUNTRY_DATA_INPUT {

	if($C_DATA_WRITE){&ERR("���� ����Ÿ�� �����ϴ� ���Դϴ�.");}
	$C_DATA_WRITE = 1;
	if($lockkey) { &F_LOCK; }
	&SET_COOKIE;

	if("$xxcid" ne "0" && "$xxcid" ne ""){
	splice(@COU_DATA,$country_no,1,"$xxcid<>$xxname<>$xxele<>$xxnum<>$xxins<>$xxind<>$xxall<>$xxgold<>$xxhp<>$xxmaxhp<>$xxstr<>$xxvit<>$xxagi<>\n");
	open(OUT,">$COUNTRY_LIST") or &ERR('COUNTRY ���ο� ����Ÿ�� �� �� �����ϴ�.');
	print OUT @COU_DATA;
	close(OUT);
	}

	if($xxcid eq ""){
		open(IN,"$COUNTRY_LIST2") or &ERR2('������ �� �� �����ϴ�. err no :country');
		@COU_DATA2 = <IN>;
		close(IN);

		open(OUT,">$COUNTRY_LIST") or &ERR('COUNTRY ���ο� ����Ÿ�� �� �� �����ϴ�.');
		print OUT @COU_DATA2;
		close(OUT);
	}
	$s_i = int(rand(10));
	if($s_i eq "0" && $xxcid ne ""){
		open(OUT,">$COUNTRY_LIST2") or &ERR('COUNTRY2 ���ο� ����Ÿ�� �� �� �����ϴ�.');
		print OUT @COU_DATA;
		close(OUT);
	}
	if (-e $lockfile) { unlink($lockfile); }
	$C_DATA_WRITE = 0;
}

#_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/#
#        TOWN DATA OPEN          #
#_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/#

sub TOWN_DATA_OPEN {

	if($T_DATA_WRITE){&ERR("���� ����Ÿ�� �����ϴ� ���Դϴ�.");}
	open(IN,"$TOWN_LIST") or &ERR("������ �� �� �����ϴ�.");
	@TOWN_DATA = <IN>;
	close(IN);

	$town_no = 0;
	foreach(@TOWN_DATA){
		($zcid,$zname,$zele,$zcon,$zmoney,$zmes,$zx,$zy,$zarm,$zpro,$zacc,$zuni,$zdis,$zbat)=split(/<>/);
		if("$zcid" eq "$kpos"){last;}
		$town_no++;
	}

}

#_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/#
#       TOWN DATA INPUT        #
#_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/#
sub TOWN_DATA_INPUT {

	if($T_DATA_WRITE){&ERR("���� ����Ÿ�� �����ϴ� ���Դϴ�.");}
	$T_DATA_WRITE = 1;
	if($lockkey) { &F_LOCK; }
	&SET_COOKIE;

	if($zcid ne ""){
	@NEW_T_DATA=();
	foreach(@TOWN_DATA){
		($zcid2,$zname2,$zele2,$zcon2,$zmoney2,$zmes2,$zx2,$zy2,$zarm2,$zpro2,$zacc2,$zuni2,$zdis2,$zbat2)=split(/<>/);
		if("$zcid" eq "$zcid2"){
			push(@NEW_T_DATA,"$zcid<>$zname<>$zele<>$zcon<>$zmoney<>$zmes<>$zx<>$zy<>$zarm<>$zpro<>$zacc<>$zuni<>$zdis<>$zbat<>\n");
		}elsif($zcid2 eq "" || $zname2 eq ""){
			next;
		}else{
			push(@NEW_T_DATA,"$_");
		}
	}

	open(OUT,">$TOWN_LIST") or &ERR('TOWN ���ο� ����Ÿ�� �� �� �����ϴ�.');
	print OUT @NEW_T_DATA;
	close(OUT);
	}

	if($zcid eq ""){
		open(IN,"$TOWN_LIST2") or &ERR2('������ �� �� �����ϴ�. err no :country');
		@TOWN_DATA2 = <IN>;
		close(IN);

		open(OUT,">$TOWN_LIST") or &ERR('COUNTRY ���ο� ����Ÿ�� �� �� �����ϴ�.');
		print OUT @TOWN_DATA2;
		close(OUT);
	}
	$s_it = int(rand(10));
	if($s_it eq "0" && $zcid ne ""){
		open(OUT,">$TOWN_LIST2") or &ERR('TOWN2 ���ο� ����Ÿ�� �� �� �����ϴ�.');
		print OUT @TOWN_DATA;
		close(OUT);
	}
	if (-e $lockfile) { unlink($lockfile); }
	$T_DATA_WRITE = 0;
}


#_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/#
#       ������ ����Ʈ ����      #
#_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/#
sub CHARA_DATA_LIST_INPUT {

    &F_LOCK();
	&SET_COOKIE;

	open(IN,"$CHARA_DATA_LIST");
	@CL_DATA = <IN>;
	close(IN);
	&HOST_NAME;
	$date = time();$flg=0;$i=0;
	foreach(@CL_DATA) {
		($bid,$bpass,$bname,$burl,$bchara,$bsex,$bhp,$bmaxhp,$bmp,$bmaxmp,$bele,$bstr,$bvit,$bint,$bmen,$bagi,$bcom,$bgold,$b_ex,$bcex,$bunit,$bcon,$barm,$bpro,$bacc,$bsub1,$bsub2,$btac,$bsta,$bpos,$bmes,$bhost,$bdate,$bsyo,$bclass,$btotal,$bkati) = split(/<>/);
		if("$bid" eq "$in{'id'}"){
			splice(@CL_DATA,$i,1,"$kid<>$kpass<>$kname<>$kurl<>$kchara<>$ksex<>$khp<>$kmaxhp<>$kmp<>$kmaxmp<>$kele<>$kstr<>$kvit<>$kint<>$kmen<>$kagi<>$kcom<>$kgold<>$k_ex<>$kcex<>$kunit<>$kcon<>$karm<>$kpro<>$kacc<>$ksub1<>$ksub2<>$ktac<>$ksta<>$kpos<>$kmes<>$host<>$date<>$ksyo<>$kclass<>$ktotal<>$kkati<>\n");
			$flg=1;
			$last;
		}
		$i++;
	}

	if(!$flg){
		unshift(@CL_DATA,"$kid<>$kpass<>$kname<>$kurl<>$kchara<>$ksex<>$khp<>$kmaxhp<>$kmp<>$kmaxmp<>$kele<>$kstr<>$kvit<>$kint<>$kmen<>$kagi<>$kcom<>$kgold<>$k_ex<>$kcex<>$kunit<>$kcon<>$karm<>$kpro<>$kacc<>$ksub1<>$ksub2<>$ktac<>$ksta<>$kpos<>$kmes<>$host<>$date<>$ksyo<>$kclass<>$ktotal<>$kkati<>\n");
	}
	open(OUT,">$CHARA_DATA_LIST") or &ERR('CHARA DATA ���ο� �����͸� �� �� �����ϴ�.');
	print OUT @CL_DATA;
	close(OUT);
    &UNLOCK_FILE();

}

#_/_/_/_/_/_/_/_/#
#     DECODE     #
#_/_/_/_/_/_/_/_/#

sub DECODE {

	if ($ENV{'REQUEST_METHOD'} eq "POST") {
		if ($ENV{'CONTENT_LENGTH'} > 51200) { &ERR("������ �ʹ� ��ϴ�."); }
		read(STDIN, $buffer, $ENV{'CONTENT_LENGTH'});
	} else { $buffer = $ENV{'QUERY_STRING'}; }
	@pairs = split(/&/, $buffer);
	foreach (@pairs) {
		($name,$value) = split(/=/, $_);
		$value =~ tr/+/ /;
		$value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;

		# �±� ó��
		$value =~ s/</&lt;/g;
		$value =~ s/>/&gt;/g;
		$value =~ s/\"/&quot;/g;

		# �ٹٲ޵� ó��
		if ($name eq "ins") {
			$value =~ s/\r\n/<br>/g;
			$value =~ s/\r/<br>/g;
			$value =~ s/\n/<br>/g;
		} else {
			$value =~ s/\r//g;
			$value =~ s/\n//g;
		}

		# �ϰ� ������
		if ($name eq 'del') { push(@DEL,$value); }

		$in{$name} = $value;
	}
	$mode = $in{'mode'};
	$in{'url'} =~ s/^http\:\/\///;
	$cookie_pass = $in{'pass'};
	$cookie_id = $in{'id'};
}


#_/_/_/_/_/_/_/_/#
#   HOST NAME    #
#_/_/_/_/_/_/_/_/#

sub HOST_NAME {
	$host = $ENV{'REMOTE_HOST'};
	$ad = $ENV{'REMOTE_ADDR'};
	if ($get_remotehost) {
		if ($host eq "" || $host eq "$ad") {
			$host = gethostbyaddr(pack("C4",split(/\./,$ad)),2);
		}
	}
	if ($host eq "") { $host = $ad }
}

#_/_/_/_/_/_/_/_/#
#  ERROR PRINT   #
#_/_/_/_/_/_/_/_/#

sub ERR {

	&CHARA_MAIN_OPEN;
	&HEADER;
	if (-e $lockfile) { unlink($lockfile); }
	print "<center><hr size=0><h3>ERROR !</h3>\n";
	print "<P><font color=red><B>$_[0]</B></font>\n";
print "<form action=\"./i-status.cgi\" method=\"post\"><input type=hidden name=id value=$kid><input type=hidden name=pass value=$kpass><input type=hidden name=mode value=STATUS><input type=submit value=\"������ ���ư���\"></form>";
	print "<P><hr size=0></center>\n</body></html>\n";
	exit;
}

#_/_/_/_/_/_/_/_/_/#
#   ERROR PRINT2   #
#_/_/_/_/_/_/_/_/_/#

sub ERR2 {

	&HEADER;
	if (-e $lockfile) { unlink($lockfile); }
	print "<center><hr size=0><h3>ERROR !</h3>\n";
	print "<P><font color=red><B>$_[0]</B></font>\n";
	print "<P><hr size=0></center>\n</body></html>\n";
	exit;
}

#_/_/_/_/_/_/_/_/_/_/_/_/#
#       FILE LOCK        #
#_/_/_/_/_/_/_/_/_/_/_/_/#

sub F_LOCK {

	$qhit=0;
	for($qp=0;$qp<2;$qp++){
		if(!mkdir($lockfile, 0755)) {
			$qhit=1;
			sleep(1);
			last;
 		} 
	}

	if(!$qhit){
     	UNLOCK_FILE();
	 	&ERR("File lock error!<BR>�ٸ� ����� ó���� ���ƽ��ϴ�. ����Ŀ� �������ּ���.");
	}
}

#_/_/_/_/_/_/_/_/_/_/_/_/#
#     FILE UNLOCK        #
#_/_/_/_/_/_/_/_/_/_/_/_/#

sub UNLOCK_FILE
{
  rmdir("$lockfile");
}

#_/_/_/_/_/_/_/_/_/_/_/_/#
#       HTML HEADER      #
#_/_/_/_/_/_/_/_/_/_/_/_/#

sub HEADER {

	print "Cache-Control: no-cache\n";
	print "Pragma: no-cache\n";
	print "Content-type: text/html\n\n";
	print <<"EOM";
<html>
<head>
<META HTTP-EQUIV="Content-type" CONTENT="text/html; charset=euc-kr">
EOM
	print <<"EOM";
<STYLE type="text/css">
<!--
BODY,TR,TD,TH{
font-family : "tahoma";
font-size: $FONT_SIZE
}
A:HOVER{
 color: $ALINK
}
.S1 {color:#fff; border-style: double; border-width: 3px;BACKGROUND: #633;}
.S2 {color:#fff; border-style: double; border-width: 3px;BACKGROUND: #844;}
.S3 {background: #006;border-color: #99c #336 #336 #99c;color:#fff; border-style: solid; border-width: 1px; text-align: center}
.dmg { color: #FF0000; font-size: 18pt }
.clit { color: #0000FF; font-size: 18pt }
-->
</STYLE>

EOM
	if($mode eq "STATUS" || $mode eq "MOVE"){

	if($s_time > 0){
print << "_TIMER_";
<SCRIPT LANGUAGE="JavaScript">
<!--
var flag = 0;
function check() {
 if(flag == 0){ flag = 1; }
 else{ return false; }
}
//-->
</SCRIPT>
<SCRIPT LANGUAGE="JavaScript">
<!--
	var start=new Date();
	start=Date.parse(start)/1000;
	var counts=$s_time;
	function CountDown(){
		var now=new Date();
		now=Date.parse(now)/1000;
		var x=parseInt(counts-(now-start),10);
		if(document.form1){document.form1.clock.value = x;}
		if(x>0){
			timerID=setTimeout("CountDown()", 100)
		}
	}

//-->
</SCRIPT>
_TIMER_
	}

}
	print "<title>$GAME_TITLE</title></head>\n";
	print <<"EOM";
<body background="$BACKGROUND" bgcolor="$BGCOLOR" text="$TEXT" link="$LINK" vlink="$VLINK" alink="$ALINK" leftmargin="0" marginwidth="0" marginheight="0">
EOM

}

#_/_/_/_/_/_/_/_/_/_/_/_/#
#       HTML FOOTER      #
#_/_/_/_/_/_/_/_/_/_/_/_/#

sub FOOTER {
	print "<HR SIZE=0 WIDTH=\"100%\"><DIV align=center>\n";
	print "The Wars of Roses $VER <a href=\"http://myan.xo.st/\" target=\"_top\">Korea(midGetyAn)</a> <a href=\"http://www20.pos.to/~maccyu/\" target=\"_top\">Japan(maccyu)</a><br>\n";
	print "��GAME CREATING STAFF�� <a href=\"./thanks/thanks.htm\">[MEMBER]</a><br>\n";	   print "</DIV></body></html>\n";
}

#_/_/_/_/_/_/_/_/_/_/_/_/#
#    COOKIE ���� ���     #
#_/_/_/_/_/_/_/_/_/_/_/_/#
sub GET_COOKIE {
	@pairs = split(/;/, $ENV{'HTTP_COOKIE'});
	foreach (@pairs) {
		local($key,$val) = split(/=/);
		$key =~ s/\s//g;
		$GET{$key} = $val;
	}
	@pairs = split(/,/, $GET{'WOR'});
	foreach (@pairs) {
		local($key,$val) = split(/<>/);
		$COOK{$key} = $val;
	}
	$_id  = $COOK{'id'};
	$_pass = $COOK{'pass'};
}

#_/_/_/_/_/_/_/_/_/_/_/_/#
#        SET COOKIE      #
#_/_/_/_/_/_/_/_/_/_/_/_/#
sub SET_COOKIE {

	local($sec,$min,$hour,$mday,$mon,$year,$wday) = gmtime(time+60*24*60*60);
	@month=('Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec');
	$gmt = sprintf("%s, %02d-%s-%04d %02d:%02d:%02d GMT",
			$week[$wday],$mday,$month[$mon],$year+1900,$hour,$min,$sec);
	$cook="id<>$cookie_id\,pass<>$cookie_pass";
	print "Set-Cookie: WOR=$cook; expires=$gmt\n";
}

#_/_/_/_/_/_/_/_/_/_/#
#   GUEST ��������    #
#_/_/_/_/_/_/_/_/_/_/#

sub MAKE_GUEST_LIST {

	if($lockkey) { &F_LOCK; }
	&HOST_NAME;
	open(GUEST,"$GUEST_LIST") or &ERR2('������ �� �� �����ϴ�.');
	@GUEST=<GUEST>;close(GUEST);

	$times = time();@m_list = ();$hit=0;@New_guest_list=();
	foreach (@GUEST){($timer,$name,$con,$oid) = split(/<>/);
		if( $times - 180 > $timer){next;
		}elsif($kname eq $name){if( $times-5 <= $timer){ &ERR("���� ������ 5�� �̻� ������ �մϴ�.<BR>������� ������ �ΰ� ������ �ּ���."); }
			push (@New_guest_list,"$times<>$kname<>$xele<>$kid<>\n");push (@m_list, "<font size=1 color=$ELE_BG[$xele]>��$kname </font>");$hit = 1;
		}else{push (@New_guest_list,"$timer<>$name<>$con<>$oid<>\n");push (@m_list, "<font size=1 color=$ELE_BG[$con]>��$name </font>")}}
	if(!$hit){push(@New_guest_list,"$times<>$kname<>$xele<>$kid<>\n");push(@m_list, "<font size=1 color=888888>��$kname </font>");}

	open(GUEST,">$GUEST_LIST") or &ERR('������ �� �� �����ϴ�.');
	print GUEST @New_guest_list;close(GUEST);
	if (-e $lockfile) { unlink($lockfile); }
}

#_/_/_/_/_/_/_/_/_/_/#
#     ���� ���� ���     #
#_/_/_/_/_/_/_/_/_/_/#

sub SERVER_STOP {

	&HOST_NAME;
	open(GUEST,"./log_file/stop.cgi") or &ERR2('������ �� �� �����ϴ�.');
	@STOP=<GUEST>;close(GUEST);
if($host eq ""){&ERR("ȣ��Ʈ���� ��ȿ�ϰ� �� �ּ���.");}
	$times = time();@m_list = ();$hit=0;@New_stop=();
	foreach (@STOP){
		($stimer,$shost) = split(/<>/);
		if( $times - 180 > $stimer){
			next;
		}elsif($shost eq $host){
			if( $times-5 <= $stimer){

				if($in{'id'} eq ""){
				&ERR2("���� ���� ������ ���� ������,<BR>5���̻� ������ �ΰ� ������ �ּ���.<BR>Your host name : $host"); 
				}else{
				&ERR("���� ���� ������ ���� ������,<BR>5���̻� ������ �ΰ� ������ �ּ���.<BR>Your host name : $host"); 
				}
			}
			push (@New_stop,"$times<>$host<>\n");
			$hit = 1;
		}else{
			push (@New_stop,"$stimer<>$shost<>\n");
		}
	}

	if(!$hit){
		push(@New_stop,"$times<>$host<>\n");
	}

	open(GUEST,">./log_file/stop.cgi") or &ERR('������ �� �� �����ϴ�.');
	print GUEST @New_stop;close(GUEST);
}


1;

