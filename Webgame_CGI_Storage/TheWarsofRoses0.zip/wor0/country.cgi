#!/usr/bin/perl

#################################################################
#   ������ ���ס�
#    �� ��ũ��Ʈ�� ���� ����Ʈ�Դϴ�. �� ��ũ��Ʈ�� ����ϴٰ�
#    �Ͼ �Ͽ� ���ؼ� �����ڴ� å���� ���� �ʽ��ϴ�.
#    ��ġ�� ���� ������ ����Ʈ �Խ������� ���ֽñ� �ٶ��ϴ�.
#    �̸����� ���� ����Ʈ�� ���� �ʽ��ϴ�.
#    �ѱ۹��� : midGetyAn (http://myan.xo.st/)
#################################################################

require './ini_file/index.ini';
require 'suport.pl';

if($MENTE) { &ERR2("�������Դϴ�. ����Ŀ� ������ �ּ���."); }
&DECODE;
if($ENV{'HTTP_REFERER'} !~ /i/ && $CHEACKER){ &ERR2("�������� ��η� ������ �ּ���."); }

if($mode eq 'GIVE_MONEY') { require 'country/give_money.pl';&GIVE_MONEY; }
elsif($mode eq 'MAKE_COUNTRY') { require 'country/make_country.pl';&MAKE_COUNTRY; }
elsif($mode eq 'FORT_STRENGTH') { require 'country/fort_strength.pl';&FORT_STRENGTH; }
elsif($mode eq 'COUNTRY_ATTACK') { require 'country/country_attack.pl';&COUNTRY_ATTACK; }
elsif($mode eq 'TOWN_ATTACK') { require 'country/town_attack.pl';&TOWN_ATTACK; }
elsif($mode eq 'COUNTRY_STR') { require 'country/country_str.pl';&COUNTRY_STR; }
elsif($mode eq 'COUNTRY_DOWN') { require 'country/country_down.pl';&COUNTRY_DOWN; }
elsif($mode eq 'TOWN_DOWN') { require 'country/town_down.pl';&TOWN_DOWN; }
elsif($mode eq 'MAKE_TOWN') { require 'country/make_town.pl';&MAKE_TOWN; }
elsif($mode eq 'FORT_RESTORATION') { require 'country/fort_restoration.pl';&FORT_RESTORATION; }
elsif($mode eq 'COUNTRY_ALL_TALK') { require 'country/country_all_talk.pl';&COUNTRY_ALL_TALK; }
elsif($mode eq 'COUNTRY_TALK') { require 'country/country_talk.pl';&COUNTRY_TALK; }
elsif($mode eq 'COUNTRY_WRITE') { require 'country/country_write.pl';&COUNTRY_WRITE; }
elsif($mode eq 'UNIT_ENTRY') { require 'country/unit_entry.pl';&UNIT_ENTRY; }
elsif($mode eq 'UNIT_SELECT') { require 'country/unit_select.pl';&UNIT_SELECT; }
elsif($mode eq 'UNIT_OUT') { require 'country/unit_out.pl';&UNIT_OUT; }
elsif($mode eq 'MAKE_UNIT') { require 'country/make_unit.pl';&MAKE_UNIT; }
elsif($mode eq 'UNIT_DELETE') { require 'country/unit_delete.pl';&UNIT_DELETE; }
elsif($mode eq 'DEF_SET') { require 'country/def_set.pl';&DEF_SET; }
elsif($mode eq 'DEF_OUT') { require 'country/def_out.pl';&DEF_OUT; }
elsif($mode eq 'COUNTRY_CHANGE') { require 'country/country_change.pl';&COUNTRY_CHANGE; }
elsif($mode eq 'COUNTRY_MOVE') { require 'country/country_move.pl';&COUNTRY_MOVE; }
elsif($mode eq 'TOWN_STRENGTH') { require 'country/town_str.pl';&TOWN_STRENGTH; }
elsif($mode eq 'TOWN_REMAKE') { require 'country/town_remake.pl';&TOWN_REMAKE; }
elsif($mode eq 'TOWN_MAKE') { require 'country/town_make.pl';&TOWN_MAKE; }
elsif($mode eq 'TOWN_MAKE2') { require 'country/town_make2.pl';&TOWN_MAKE2; }
elsif($mode eq 'TOWN_ARM') { require 'country/town_arm.pl';&TOWN_ARM; }
elsif($mode eq 'TOWN_ARM2') { require 'country/town_arm2.pl';&TOWN_ARM2; }
elsif($mode eq 'LOCAL_RULE') { require 'country/local_rule.pl';&LOCAL_RULE; }
elsif($mode eq 'L_RULE_WRITE') { require 'country/l_rule_write.pl';&L_RULE_WRITE; }
elsif($mode eq 'L_RULE_DEL') { require 'country/l_rule_del.pl';&L_RULE_DEL; }
elsif($mode eq 'KING') { require 'country/king.pl';&KING; }
elsif($mode eq 'KING2') { require 'country/king2.pl';&KING2; }
elsif($mode eq 'KING_COM') { require 'country/king_com.pl';&KING_COM; }
elsif($mode eq 'KING_PASSPORT') { require 'country/king_passport.pl';&KING_PASSPORT; }
elsif($mode eq 'KING_MAN_OUT') { require 'country/king_man_out.pl';&KING_MAN_OUT; }
elsif($mode eq 'KING_MAN_OUT2') { require 'country/king_man_out2.pl';&KING_MAN_OUT2; }
elsif($mode eq 'KING_ENTRY_STOP') { require 'country/king_entry_stop.pl';&KING_ENTRY_STOP; }
elsif($mode eq 'UNIT_CHANGE') { require 'country/unit_change.pl';&UNIT_CHANGE; }
else { &ERR("������ �����Դϴ�."); }
