#_/_/_/_/_/_/_/_/_/_/_/#
#_/    ����  ȭ��    _/#
#_/_/_/_/_/_/_/_/_/_/_/#

sub BATTLE3 {

	open(IN,"$TEAM_OK_LIST") or &ERR("������ �� �� �����ϴ�. [OK_LIST]");
	@OK_DATA = <IN>;
	close(IN);

	$o_num = @OK_DATA;
	if($o_num <= 1){&ERR("�����ڰ� �����մϴ�. (2���̻�)");}

	$ran_no1 = int(rand(@OK_DATA));
	while(1){
		$ran_no2 = int(rand(@OK_DATA));
		if($ran_no1 ne $ran_no2){last;}
	}

	($fid[0],$fname[0],$fchara[0],$fid[1],$fname[1],$fchara[1],$fid[2],$fname[2],$fchara[2],$funit)=split(/<>/,$OK_DATA[$ran_no1]);
	($eid[0],$ename[0],$echara[0],$eid[1],$ename[1],$echara[1],$eid[2],$ename[2],$echara[2],$eunit)=split(/<>/,$OK_DATA[$ran_no2]);


	&CHARA_DATA_OPEN;
	&ENEMY_DATA_OPEN;


	&ITEM_DATA_OPEN;
	&TAC_DATA_ALL_OPEN;

	&MAP_LOG("<font color=green><B>[õ��]</B></font><font color=$ELE_BG[$wcon]>$funit ��</font> vs <font color=$ELE_BG[$econ]>$eunit ��</font>�� ������ �����մϴ�!");
	$wnum=3;
	$enum=3;

	$ehp = $emaxhp;
	$eshp = $esmaxhp;
	$ethp = $etmaxhp;
	$emp = $emaxmp;
	$esmp = $esmaxmp;
	$etmp = $etmaxmp;
	$khp = $kmaxhp;
	$shp = $smaxhp;
	$thp = $tmaxhp;
	$kmp = $kmaxmp;
	$smp = $smaxmp;
	$tmp = $tmaxmp;
	if($shp eq ""){ $shp = 0;$wnum--;}
	if($thp eq ""){ $thp = 0;$wnum--;}
	if($eshp eq ""){ $eshp = 0;$enum--;}
	if($ethp eq ""){ $ethp = 0;$enum--;}

	$s_ehp = $ehp;
	$s_khp = $whp;
	$s_emp = $emp;
	$s_kmp = $wmp;

	$wdef = int(($wvit+$wprodmg + $waccdmg)/4);
	$sdef = int(($svit+$sprodmg + $saccdmg)/4);
	$tdef = int(($tvit+$tprodmg + $taccdmg)/4);
	$edef = int(($evit+$eprodmg + $eaccdmg)/4);
	$esdef = int(($esvit+$esprodmg + $esaccdmg)/4);
	$etdef = int(($etvit+$etprodmg + $etaccdmg)/4);

	$flg=0;
	$wflg=0;
	$number=1;

	$wpoint=int(($wmaxhp+$wmaxmp)/3)+$wstr+$wvit+$wint+$wmen+$wagi;
	$spoint=int(($smaxhp+$smaxmp)/3)+$sstr+$svit+$sint+$smen+$sagi;
	$tpoint=int(($tmaxhp+$tmaxmp)/3)+$tstr+$tvit+$tint+$tmen+$tagi;
	$epoint=int(($emaxhp+$emaxmp)/3)+$estr+$evit+$eint+$emen+$eagi;
	$espoint=int(($esmaxhp+$esmaxmp)/3)+$esstr+$esvit+$esint+$esmen+$esagi;
	$etpoint=int(($etmaxhp+$etmaxmp)/3)+$etstr+$etvit+$etint+$etmen+$etagi;

	$wget_kgold=0;
	$wget_k_ex=0;
	$wget_s_ex=0;
	$wget_t_ex=0;
	$wget_cex=0;

	$wget_egold=0;
	$wget_e_ex=0;
	$wget_es_ex=0;
	$wget_et_ex=0;
	$wget_e_cex=0;

	$wbar1 = int(($whp/$wmaxhp)*50);
	$wbar2 = 50-$wbar1;
	$whpimg2 = "<img src=\"$IMG/$IMG_GROUND/bar1.gif\"  height=\"7\" width=$wbar1><img src=\"$IMG/$IMG_GROUND/bar2.gif\"  height=\"7\" width=$wbar2>";

	$wbar1 = int(($wmp/$wmaxmp)*50);
	$wbar2 = 50-$wbar1;
	$wmpimg2 = "<img src=\"$IMG/$IMG_GROUND/bar4.gif\"  height=\"7\" width=$wbar1><img src=\"$IMG/$IMG_GROUND//bar2.gif\"  height=\"7\" width=$wbar2>";

	$ebar1 = int(($ehp/$emaxhp)*50);
	$ebar2 = 50-$ebar1;
	$ehpimg2 = "<img src=\"$IMG/$IMG_GROUND/bar1.gif\"  height=\"7\" width=$ebar1><img src=\"$IMG/$IMG_GROUND/bar2.gif\"  height=\"7\" width=$ebar2>";

	$ebar1 = int(($emp/$emaxmp)*50);
	$ebar2 = 50-$ebar1;
	$empimg2 = "<img src=\"$IMG/$IMG_GROUND/bar4.gif\"  height=\"7\" width=$ebar1><img src=\"$IMG/$IMG_GROUND/bar2.gif\"  height=\"7\" width=$ebar2>";

		$sbar1 = int(($shp/$smaxhp)*50);
		$sbar2 = 50-$sbar1;
		$shpimg2 = "<img src=\"$IMG/$IMG_GROUND/bar1.gif\"  height=\"7\" width=$sbar1><img src=\"$IMG/$IMG_GROUND/bar2.gif\"  height=\"7\" width=$sbar2>";
		$sbar1 = int(($smp/$smaxmp)*50);
		$sbar2 = 50-$sbar1;
		$smpimg2 = "<img src=\"$IMG/$IMG_GROUND/bar4.gif\"  height=\"7\" width=$sbar1><img src=\"$IMG/$IMG_GROUND/bar2.gif\"  height=\"7\" width=$sbar2>";
		$s_sstatus = "<TR><TD bgcolor=$TD_C3>$sname</TD><TD bgcolor=$TD_C3>$shp/$smaxhp<BR>$shpimg2</TD><TD bgcolor=$TD_C3>$smp/$smaxmp<BR>$smpimg2</TD><TD bgcolor=$TD_C3>$sarmname</TD><TD bgcolor=$TD_C3>$sproname</TD><TD bgcolor=$TD_C3>$sstr(+$sarmdmg)</TD><TD bgcolor=$TD_C3>$svit(+$sprodmg+$saccdmg)</TD><TD bgcolor=$TD_C3>$SYOKU[$sclass]</TD><TD bgcolor=$TD_C3>$spoint</TD></TR>";

		$tbar1 = int(($thp/$tmaxhp)*50);
		$tbar2 = 50-$tbar1;
		$thpimg2 = "<img src=\"$IMG/$IMG_GROUND/bar1.gif\"  height=\"7\" width=$tbar1><img src=\"$IMG/$IMG_GROUND/bar2.gif\"  height=\"7\" width=$tbar2>";
		$tbar1 = int(($tmp/$tmaxmp)*50);
		$tbar2 = 50-$tbar1;
		$tmpimg2 = "<img src=\"$IMG/$IMG_GROUND/bar4.gif\"  height=\"7\" width=$tbar1><img src=\"$IMG/$IMG_GROUND/bar2.gif\"  height=\"7\" width=$tbar2>";
		$t_sstatus = "<TR><TD bgcolor=$TD_C3>$tname</TD><TD bgcolor=$TD_C3>$thp/$tmaxhp<BR>$thpimg2</TD><TD bgcolor=$TD_C3>$tmp/$tmaxmp<BR>$tmpimg2</TD><TD bgcolor=$TD_C3>$tarmname</TD><TD bgcolor=$TD_C3>$tproname</TD><TD bgcolor=$TD_C3>$tstr(+$tarmdmg)</TD><TD bgcolor=$TD_C3>$tvit(+$tprodmg+$taccdmg)</TD><TD bgcolor=$TD_C3>$SYOKU[$tclass]</TD><TD bgcolor=$TD_C3>$tpoint</TD></TR>";

		$esbar1 = int(($eshp/$esmaxhp)*50);
		$esbar2 = 50-$esbar1;
		$eshpimg2 = "<img src=\"$IMG/$IMG_GROUND/bar1.gif\"  height=\"7\" width=$esbar1><img src=\"$IMG/$IMG_GROUND/bar2.gif\"  height=\"7\" width=$esbar2>";
		$esbar1 = int(($esmp/$esmaxmp)*50);
		$esbar2 = 50-$esbar1;
		$esmpimg2 = "<img src=\"$IMG/$IMG_GROUND/bar4.gif\"  height=\"7\" width=$esbar1><img src=\"$IMG/$IMG_GROUND/bar2.gif\"  height=\"7\" width=$esbar2>";
		$es_sstatus = "<TR><TD bgcolor=$TD_C3>$esname</TD><TD bgcolor=$TD_C3>$eshp/$esmaxhp<BR>$eshpimg2</TD><TD bgcolor=$TD_C3>$esmp/$esmaxmp<BR>$esmpimg2</TD><TD bgcolor=$TD_C3>$esarmname</TD><TD bgcolor=$TD_C3>$esproname</TD><TD bgcolor=$TD_C3>$esstr(+$esarmdmg)</TD><TD bgcolor=$TD_C3>$esvit(+$esprodmg+$esaccdmg)</TD><TD bgcolor=$TD_C3>$SYOKU[$esclass]</TD><TD bgcolor=$TD_C3>$espoint</TD></TR>";

		$etbar1 = int(($ethp/$etmaxhp)*50);
		$etbar2 = 50-$etbar1;
		$ethpimg2 = "<img src=\"$IMG/$IMG_GROUND/bar1.gif\"  height=\"7\" width=$etbar1><img src=\"$IMG/$IMG_GROUND/bar2.gif\"  height=\"7\" width=$etbar2>";
		$etbar1 = int(($etmp/$etmaxmp)*50);
		$etbar2 = 50-$etbar1;
		$etmpimg2 = "<img src=\"$IMG/$IMG_GROUND/bar4.gif\"  height=\"7\" width=$etbar1><img src=\"$IMG/$IMG_GROUND/bar2.gif\"  height=\"7\" width=$etbar2>";
		$et_sstatus = "<TR><TD bgcolor=$TD_C3>$etname</TD><TD bgcolor=$TD_C3>$ethp/$etmaxhp<BR>$ethpimg2</TD><TD bgcolor=$TD_C3>$etmp/$etmaxmp<BR>$etmpimg2</TD><TD bgcolor=$TD_C3>$etarmname</TD><TD bgcolor=$TD_C3>$etproname</TD><TD bgcolor=$TD_C3>$etstr(+$etarmdmg)</TD><TD bgcolor=$TD_C3>$etvit(+$etprodmg+$etaccdmg)</TD><TD bgcolor=$TD_C3>$SYOKU[$etclass]</TD><TD bgcolor=$TD_C3>$etpoint</TD></TR>";

	$count=1;
	while($count < $BATTLE_MAX_TURN){
	$com1="";
	$com2="";
	$com3="";
	$com4="";
	$com5="";
	$com6="";
	$message1="";
	$message2="";
	$message3="";
	$message4="";
	$message5="";
	$message6="";

	if($whp ne "0"){
		$i=0;
		$watt = $wstr+$warmdmg;
		$w_hit = int(($wagi - ($warmwei + $wprowei + $waccwei))/50);
		if($w_hit <= 0){$w_hit = 1;}
		$com1 .= "<BR><font size=5 color=\"$ELE_BG[$wele]\">$wname�� ����! </font><b class=\"clit\">$w_hit</b> HIT!<BR>";
		while($i < $w_hit){
			$r_no = int(rand(3));
			$randam_no = int(rand(100));
			if($r_no eq "0"){
				if($ehp eq "0"){
					if($ehp eq "0" && $eshp eq "0" && $ethp eq "0"){
						last;
					}else{
						$r_no++;
						next;
					}
				}else{
						$w_mpdown = int($wtec_str/2);
					if($wtec_hit  > $randam_no && $wmp > $w_mpdown){
						$com1 .= "<b class=\"clit\"> $wtec_name </b>";
						$wmp -= $w_mpdown;
						if($wtec_cho){
							$whp += $wtec_str;
							if($wmaxhp < $whp){$whp = $wmaxhp;}
							$com1 .= "$wname�� ü���� <b class=\"dmg\">$wtec_str</b>ȸ���ƴ�.";
						}else{
							$clit = int(rand($wtec_str))-$emen+$wint;
						}
						$com1 .= "<BR>";
					}
					$s1_kdmg = int(rand($watt)) + $clit - $edef;
					if($s1_kdmg<0){$s1_kdmg=0;}
					$ehp -= $s1_kdmg;
					$com1 .= "$ename���� <b class=\"dmg\">$s1_kdmg</b>�� ������!<BR>";
					if($ehp eq "0" || $ehp < 0){
						$ehp = 0;
						$whit+=1;
						$com1 .= "<b class=\"dmg\">$ename(��)�� ���� ���ߴ�..</b><BR>"
					}
				}
			}elsif($r_no eq "1"){
				if($eshp eq "0"){
					if($ehp eq "0" && $eshp eq "0" && $ethp eq "0"){
						last;
					}else{
						$r_no++;
						next;
					}
				}else{
						$w_mpdown = int($wtec_str/2);
					if($wtec_hit  > $randam_no && $wmp > $w_mpdown){
						$com1 .= "<b class=\"clit\"> $wtec_name </b>";
						$wmp -= $w_mpdown;
						if($wtec_cho){
							$whp += $wtec_str;
							if($wmaxhp < $whp){$whp = $wmaxhp;}
							$com1 .= "$wname�� ü���� <b class=\"dmg\">$wtec_str</b>ȸ���ƴ�.";
						}else{
							$clit = int(rand($wtec_str))+$wint-$esmen;
						}
						$com1 .= "<BR>";
					}
					$s2_kdmg = int(rand($watt)) - $esdef;
					if($s2_kdmg<0){$s2_kdmg=0;}
					$eshp -= $s2_kdmg;
					$com1 .= "$esname���� <b class=\"dmg\">$s2_kdmg</b>�� ������!<BR>";
					if($eshp eq "0" || $eshp < 0){
						$eshp = 0;
						$whit+=1;
						$com1 .= "<b class=\"dmg\">$esname(��)�� ���� ���ߴ�..</b><BR>"
					}
				}
			}else{
				if($ethp eq "0"){
					if($ehp eq "0" && $eshp eq "0" && $ethp eq "0"){
						last;
					}else{
						$r_no -=2;
						next;
					}
				}else{
						$w_mpdown = int($wtec_str/2);
					if($wtec_hit  > $randam_no && $wmp > $w_mpdown){
						$com1 .= "<b class=\"clit\"> $wtec_name </b>";
						$wmp -= $w_mpdown;
						if($wtec_cho){
							$whp += $wtec_str;
							if($wmaxhp < $whp){$whp = $wmaxhp;}
							$com1 .= "$wname�� ü���� <b class=\"dmg\">$wtec_str</b> ȸ���ƴ�.";
						}else{
							$clit = int(rand($wtec_str))+$wint-$etmen;
						}
						$com1 .= "<BR>";
					}
					$s3_kdmg = int(rand($watt)) - $etdef;
					if($s3_kdmg < 0){$s3_kdmg=0;}
					$ethp -= $s3_kdmg;
					$com1 .= "$etname���� <b class=\"dmg\">$s3_kdmg</b>�� ������!<BR>";
					if($ethp eq "0" || $ethp < 0){
						$ethp = 0;
						$whit+=1;
						$com1 .= "$etname(��)�� ���� ���ߴ�..<BR>"
					}
				}
			}
			$i++;
		}
		if($ehp eq "0" && $eshp eq "0" && $ethp eq "0"){
			$flg=1;
			$com1 .= "<b class=\"dmg\">$wunit ���� $eunit ���� ������״�!</b><BR>";
		}
		$message1 .= "$com1";
		$number++;
	}

	if($ehp ne "0"){
		$i=0;
		$eatt = $estr+$earmdmg;
		$e_hit = int(($eagi - ($earmwei + $eprowei + $eaccwei))/50);
		if($e_hit <= 0){$e_hit = 1;}
		$com4 = "<BR><font size=5 color=\"$ELE_BG[$eele]\">$ename�� ����! </font><b class=\"clit\">$e_hit</b> HIT!<BR>";
		while($i < $e_hit){
			$r_no = int(rand(3));
			$randam_no = int(rand(100));
			if($r_no eq "0"){
				if($whp eq "0" ){
					if($whp > 0 || $shp > 0 || $thp > 0){
						$r_no++;
						next;
					}else{
						last;
					}
				}else{
						$e_mpdown = int($etec_str/2);
					if($etec_hit  > $randam_no && $emp > $e_mpdown){
						$com4 .= "<b class=\"clit\"> $etec_name </b>";
						$emp -= $e_mpdown;
						if($etec_cho){
							$ehp += $etec_str;
							if($emaxhp < $ehp){$ehp = $emaxhp;}
							$com4 .= "$ename�� ü���� <b class=\"dmg\">$etec_str</b> ȸ���ƴ�.";
						}else{
							$clit = int(rand($etec_str))+$eint-$wmen;
						}
						$com4 .= "<BR>";
					}
					$s1_edmg = int(rand($eatt)) + $clit - $wdef;
					if($s1_edmg<0){$s1_edmg=0;}
					$whp -= $s1_edmg;
					$com4 .= "$wname���� <b class=\"dmg\">$s1_edmg</b>�� ������!<BR>";
					if($whp eq "0" || $whp < 0){
						$whp = 0;
						$ehit+=1;
						$com4 .= "<b class=\"dmg\">$wname(��)�� ���� ���ߴ�..</b><BR>"
					}
				}
			}elsif($r_no eq "1"){
				if($shp eq "0"){
					if($whp > 0 || $shp > 0 || $thp > 0){
						$r_no++;
						next;
					}else{
						last;
					}
				}else{
						$e_mpdown = int($etec_str/2);
					if($etec_hit  > $randam_no && $emp > $e_mpdown){
						$com4 .= "<b class=\"clit\"> $etec_name </b>";
						$emp -= $e_mpdown;
						if($etec_cho){
							$ehp += $etec_str;
							if($emaxhp < $ehp){$ehp = $emaxhp;}
							$com4 .= "$ename�� ü���� <b class=\"dmg\">$etec_str</b> ȸ���ƴ�.";
						}else{
							$clit = int(rand($etec_str))+$eint-$smen;
						}
						$com4 .= "<BR>";
					}
					$s2_edmg = int(rand($eatt)) + $clit - $sdef;
					if($s2_edmg<0){$s2_edmg=0;}
					$shp -= $s2_edmg;
					$com4 .= "$sname���� <b class=\"dmg\">$s2_edmg</b>�� ������!<BR>";
					if($shp eq "0" || $shp < 0){
						$shp = 0;
						$ehit+=1;
						$com4 .= "<b class=\"dmg\">$sname(��)�� ���� ���ߴ�..</b><BR>"
					}
				}
			}else{
				if($thp eq "0"){
					if($whp > 0 || $shp > 0 || $thp > 0){
						$r_no -= 2;
						next;
					}else{
						last;
					}
				}else{
						$e_mpdown = int($etec_str/2);
					if($etec_hit  > $randam_no && $emp > $e_mpdown){
						$com4 .= "<b class=\"clit\"> $etec_name </b>";
						$emp -= $e_mpdown;
						if($etec_cho){
							$ehp += $etec_str;
							if($emaxhp < $ehp){$ehp = $emaxhp;}
							$com4 .= "$ename�� ü���� <b class=\"dmg\">$etec_str</b> ȸ���ƴ�.";
						}else{
							$clit = int(rand($etec_str))+$eint-$tmen;
						}
						$com4 .= "<BR>";
					}
					$s3_edmg = int(rand($eatt)) + $clit - $tdef;
					if($s3_edmg < 0){$s3_edmg=0;}
					$thp -= $s3_edmg;
					$com4 .= "$tname���� <b class=\"dmg\">$s3_edmg</b>�� ������!<BR>";
					if($thp eq "0" || $thp < 0){
						$thp = 0;
						$ehit+=1;
						$com4 .= "<b class=\"dmg\">$tname(��)�� ���� ���ߴ�..</b><BR>"
					}
				}
			}
			$i++;
			$clit=0;
		}
		if($whp eq "0" && $shp eq "0" && $thp eq "0"){
			$wflg=1;
			$com4 .= "<b class=\"dmg\">$wunit ���� �����ߴ�.</b><BR>";
		}
		$message4 = "$com4";
		$number++;
	}

	if($flg ne "1" && $shp ne "0"){
		$i=0;
		$satt = $sstr+$sarmdmg;
		$s_hit = int(($sagi - ($sarmwei + $sprowei + $saccwei))/50);
		if($s_hit <= 0){$s_hit = 1;}
		$com2 .= "<BR><font size=5 color=\"$ELE_BG[$wele]\">$sname�� ����! </font><b class=\"clit\">$s_hit</b> HIT!<BR>";
		while($i < $s_hit){
			$r_no = int(rand(3));
			$randam_no = int(rand(100));
			if($r_no eq "0"){
				if($ehp eq "0"){
					if($ehp eq "0" && $eshp eq "0" && $ethp eq "0"){
						last;
					}else{
						$r_no++;
						next;
					}
				}else{
						$s_mpdown = int($stec_str/2);
					if($stec_hit  > $randam_no && $smp > $s_mpdown){
						$com2 .= "<b class=\"clit\"> $stec_name </b>";
						$smp -= $s_mpdown;
						if($stec_cho){
							$shp += $stec_str;
							if($smaxhp < $shp){$shp = $smaxhp;}
							$com2 .= "$sname�� ü���� <b class=\"dmg\">$stec_str</b> ȸ���ƴ�.";
						}else{
							$clit = int(rand($stec_str))+$sint-$emen;
						}
						$com2 .= "<BR>";
					}
					$s1_sdmg = int(rand($satt)) + $clit - $edef;
					if($s1_sdmg<0){$s1_sdmg=0;}
					$ehp -= $s1_sdmg;
					$com2 .= "$ename���� <b class=\"dmg\">$s1_sdmg</b>�� ������!<BR>";
					if($ehp eq "0" || $ehp < 0){
						$ehp = 0;
						$shit+=1;
						$com2 .= "<b class=\"dmg\">$ename(��)�� ���� ���ߴ�..</b><BR>"
					}
				}
			}elsif($r_no eq "1"){
				if($eshp eq "0"){
					if($ehp eq "0" && $eshp eq "0" && $ethp eq "0"){
						last;
					}else{
						$r_no++;
						next;
					}
				}else{
						$s_mpdown = int($stec_str/2);
					if($stec_hit  > $randam_no && $smp > $s_mpdown){
						$com2 .= "<b class=\"clit\"> $stec_name </b>";
						$smp -= $s_mpdown;
						if($stec_cho){
							$shp += $stec_str;
							if($smaxhp < $shp){$shp = $smaxhp;}
							$com2 .= "$sname�� ü���� <b class=\"dmg\">$stec_str</b> ȸ���ƴ�.";
						}else{
							$clit = int(rand($stec_str))+$sint-$esmen;
						}
						$com2 .= "<BR>";
					}
					$s2_sdmg = int(rand($satt)) + $clit - $esdef;
					if($s2_sdmg<0){$s2_sdmg=0;}
					$eshp -= $s2_sdmg;
					$com2 .= "$esname���� <b class=\"dmg\">$s2_sdmg</b>�� ������!<BR>";
					if($eshp eq "0" || $eshp < 0){
						$eshp = 0;
						$shit+=1;
						$com2 .= "<b class=\"dmg\">$esname(��)�� ���� ���ߴ�..</b><BR>"
					}
				}
			}else{
				if($ethp eq "0"){
					if($ehp eq "0" && $eshp eq "0" && $ethp eq "0"){
						last;
					}else{
						$r_no -=2;
						next;
					}
				}else{
						$s_mpdown = int($stec_str/2);
					if($stec_hit  > $randam_no && $smp > $s_mpdown){
						$com2 .= "<b class=\"clit\"> $stec_name </b>";
						$smp -= $s_mpdown;
						if($stec_cho){
							$shp += $stec_str;
							if($smaxhp < $shp){$shp = $smaxhp;}
							$com2 .= "$sname�� ü���� <b class=\"dmg\">$stec_str</b> ȸ���ƴ�.";
						}else{
							$clit = int(rand($stec_str))+$sint-$etmen;
						}
						$com2 .= "<BR>";
					}
					$s3_sdmg = int(rand($satt)) + $clit - $etdef;
					if($s3_sdmg<0){$s3_sdmg=0;}
					$ethp -= $s3_sdmg;
					$com2 .= "$etname���� <b class=\"dmg\">$s3_sdmg</b>�� ������!<BR>";
					if($ethp eq "0" || $ethp < 0){
						$ethp = 0;
						$shit+=1;
						$com2 .= "<b class=\"dmg\">$etname(��)�� ���� ���ߴ�..</b><BR>"
					}
				}
			}
			$i++;
			$clit = 0;
		}
		if($ehp eq "0" && $eshp eq "0" && $ethp eq "0"){
			$flg=1;
			$com2 .= "<b class=\"dmg\">$wunit ���� $eunit ���� ������״�!</b><BR>";
		}
		$message2 = "$com2";
		$number++;
	}

	if($wflg ne "1" && $eshp ne "0"){
		$i=0;
		$esatt = $esstr+$esarmdmg;
		$es_hit = int(($esagi - ($esarmwei + $esprowei + $esaccwei))/50);
		if($es_hit <= 0){$es_hit = 1;}
		$com5 = "<BR><font size=5 color=\"$ELE_BG[$eele]\">$esname�� ����! </font><b class=\"clit\">$es_hit</b> HIT!<BR>";
		while($i < $es_hit){
			$r_no = int(rand(3));
			$randam_no = int(rand(100));
			if($r_no eq "0"){
				if($whp eq "0"){
					if($whp eq "0" && $shp eq "0" && $thp eq "0"){
						last;
					}else{
						$r_no++;
						next;
					}
				}else{
						$es_mpdown = int($estec_str/2);
					if($estec_hit  > $randam_no && $esmp > $es_mpdown){
						$com5 .= "<b class=\"clit\"> $estec_name </b>";
						$esmp -= $es_mpdown;
						if($estec_cho){
							$eshp += $estec_str;
							if($esmaxhp < $eshp){$eshp = $esmaxhp;}
							$com5 .= "$esname�� ü���� <b class=\"dmg\">$estec_str</b> ȸ���ƴ�.";
						}else{
							$clit = int(rand($estec_str))+$esint-$wmen;
						}
						$com5 .= "<BR>";
					}
					$s1_esdmg = int(rand($esatt)) + $clit - $wdef;
					if($s1_esdmg<0){$s1_esdmg=0;}
					$whp -= $s1_esdmg;
					$com5 .= "$wname���� <b class=\"dmg\">$s1_esdmg</b>�� ������!<BR>";
					if($whp eq "0" || $whp < 0){
						$whp = 0;
						$eshit+=1;
						$com5 .= "<b class=\"dmg\">$wname(��)�� ���� ���ߴ�..</b><BR>"
					}
				}
			}elsif($r_no eq "1"){
				if($shp eq "0"){
					if($whp eq "0" && $shp eq "0" && $thp eq "0"){
						last;
					}else{
						$r_no++;
						next;
					}
				}else{
						$es_mpdown = int($estec_str/2);
					if($estec_hit  > $randam_no && $esmp > $es_mpdown){
						$com5 .= "<b class=\"clit\"> $estec_name </b>";
						$esmp -= $es_mpdown;
						if($estec_cho){
							$eshp += $estec_str;
							if($esmaxhp < $eshp){$eshp = $esmaxhp;}
							$com5 .= "$esname�� ü���� <b class=\"dmg\">$estec_str</b>ȸ���ƴ�.";
						}else{
							$clit = int(rand($estec_str))+$esint-$smen;
						}
						$com5 .= "<BR>";
					}
					$s2_esdmg = int(rand($esatt)) + $clit - $sdef;
					if($s2_esdmg<0){$s2_esdmg=0;}
					$shp -= $s2_esdmg;
					$com5 .= "$sname���� <b class=\"dmg\">$s2_esdmg</b>�� ������!<BR>";
					if($shp eq "0" || $shp < 0){
						$shp = 0;
						$eshit+=1;
						$com5 .= "<b class=\"dmg\">$sname(��)�� ���� ���ߴ�..</b><BR>"
					}
				}
			}else{
				if($thp eq "0"){
					if($whp eq "0" && $shp eq "0" && $thp eq "0"){
						last;
					}else{
						$r_no -=2;
						next;
					}
				}else{
						$es_mpdown = int($estec_str/2);
					if($estec_hit  > $randam_no && $esmp > $es_mpdown){
						$com5 .= "<b class=\"clit\"> $estec_name </b>";
						$esmp -= $es_mpdown;
						if($estec_cho){
							$eshp += $estec_str;
							if($esmaxhp < $eshp){$eshp = $esmaxhp;}
							$com5 .= "$esname�� ü���� <b class=\"dmg\">$estec_str</b> ȸ���ƴ�.";
						}else{
							$clit = int(rand($estec_str))+$esint-$tmen;
						}
						$com5 .= "<BR>";
					}
					$s3_esdmg = int(rand($esatt)) + $clit - $tdef;
					if($s3_esdmg<0){$s3_esdmg=0;}
					$thp -= $s3_esdmg;
					$com5 .= "$tname���� <b class=\"dmg\">$s3_esdmg</b>�� ������!<BR>";
					if($thp eq "0" || $thp < 0){
						$thp = 0;
						$eshit+=1;
						$com5 .= "<b class=\"dmg\">$tname(��)�� ���� ���ߴ�..</b><BR>"
					}
				}
			}
			$clit=0;
			$i++;
		}
		if($whp eq "0" && $shp eq "0" && $thp eq "0"){
			$wflg=1;
			$com5 .= "<b class=\"dmg\">$wunit ���� �����ߴ�.</b><BR>";
		}
		$message5 = "$com5";
		$number++;
	}

	if($flg ne "1" && $thp ne "0"){
		$i=0;
		$tatt = $tstr+$tarmdmg;
		$t_hit = int(($tagi - ($tarmwei + $tprowei + $taccwei))/50);
		if($t_hit <= 0){$t_hit = 1;}
		$com3 = "<BR><font size=5 color=\"$ELE_BG[$wele]\">$tname�� ����! </font><b class=\"clit\">$t_hit</b> HIT!<BR>";
		while($i < $t_hit){
			$r_no = int(rand(3));
			$randam_no = int(rand(100));
			if($r_no eq "0"){
				if($ehp eq "0"){
					if($ehp eq "0" && $eshp eq "0" && $ethp eq "0"){
						last;
					}else{
						$r_no++;
						next;
					}
				}else{
						$t_mpdown = int($ttec_str/2);
					if($ttec_hit  > $randam_no && $tmp > $t_mpdown){
						$com3 .= "<b class=\"clit\"> $ttec_name </b>";
						$tmp -= $t_mpdown;
						if($ttec_cho){
							$thp += $ttec_str;
							if($tmaxhp < $thp){$thp = $tmaxhp;}
							$com3 .= "$tname�� ü���� <b class=\"dmg\">$ttec_str</b>ȸ���ƴ�.";
						}else{
							$clit = int(rand($ttec_str))+$tint-$emen;
						}
						$com3 .= "<BR>";
					}
					$s1_tdmg = int(rand($tatt)) + $clit - $edef;
					if($s1_tdmg<0){$s1_tdmg=0;}
					$ehp -= $s1_tdmg;
					$com3 .= "$ename���� <b class=\"dmg\">$s1_tdmg</b>�� ������!<BR>";
					if($ehp eq "0" || $ehp < 0){
						$ehp = 0;
						$thit+=1;
						$com3 .= "<b class=\"dmg\">$ename(��)�� ���� ���ߴ�..</b><BR>"
					}
				}
			}elsif($r_no eq "1"){
				if($eshp eq "0"){
					if($ehp eq "0" && $eshp eq "0" && $ethp eq "0"){
						last;
					}else{
						$r_no++;
						next;
					}
				}else{
						$t_mpdown = int($ttec_str/2);
					if($ttec_hit  > $randam_no && $tmp > $t_mpdown){
						$com3 .= "<b class=\"clit\"> $ttec_name </b>";
						$tmp -= $t_mpdown;
						if($ttec_cho){
							$thp += $ttec_str;
							if($tmaxhp < $thp){$thp = $tmaxhp;}
							$com3 .= "$tname�� ü���� <b class=\"dmg\">$ttec_str</b> ȸ���ƴ�.";
						}else{
							$clit = int(rand($ttec_str))+$tint-$esmen;
						}
						$com3 .= "<BR>";
					}
					$s2_tdmg = int(rand($tatt)) + $clit - $esdef;
					if($s2_tdmg<0){$s2_tdmg=0;}
					$eshp -= $s2_tdmg;
					$com3 .= "$esname���� <b class=\"dmg\">$s2_tdmg</b>�� ������!<BR>";
					if($eshp eq "0" || $eshp < 0){
						$eshp = 0;
						$thit+=1;
						$com3 .= "<b class=\"dmg\">$esname(��)�� ���� ���ߴ�..</b><BR>"
					}
				}
			}else{
				if($ethp eq "0"){
					if($ehp eq "0" && $eshp eq "0" && $ethp eq "0"){
						last;
					}else{
						$r_no -=2;
						next;
					}
				}else{
						$t_mpdown = int($ttec_str/2);
					if($ttec_hit  > $randam_no && $tmp > $t_mpdown){
						$com3 .= "<b class=\"clit\"> $ttec_name </b>";
						$tmp -= $t_mpdown;
						if($ttec_cho){
							$thp += $ttec_str;
							if($tmaxhp < $thp){$thp = $tmaxhp;}
							$com3 .= "$tname�� ü���� <b class=\"dmg\">$ttec_str</b> ȸ���ƴ�.";
						}else{
							$clit = int(rand($ttec_str))+$tint-$etmen;
						}
						$com3 .= "<BR>";
					}
					$s3_tdmg = int(rand($tatt)) + $clit - $etdef;
					if($s3_tdmg<0){$s3_tdmg=0;}
					$ethp -= $s3_tdmg;
					$com3 .= "$etname���� <b class=\"dmg\">$s3_tdmg</b>�� ������!<BR>";
					if($ethp eq "0" || $ethp < 0){
						$ethp = 0;
						$thit+=1;
						$com3 .= "<b class=\"dmg\">$etname(��)�� ���� ���ߴ�..</b><BR>"
					}
				}
			}
			$i++;
			$clit = 0;
		}
		if($ehp eq "0" && $eshp eq "0" && $ethp eq "0"){
			$flg=1;
			$com3 .= "<b class=\"dmg\">$wunit ���� $eunit ���� ������״�!</b><BR>";
		}
		$message3 = "$com3";
		$number++;
	}


	if($wflg ne "1" && $ethp ne "0"){
		$i=0;
		$etatt = $etstr+$etarmdmg;
		$et_hit = int(($etagi - ($etarmwei + $etprowei + $etaccwei))/50);
		if($et_hit <= 0){$et_hit = 1;}
		$com6 = "<BR><font size=5 color=\"$ELE_BG[$eele]\">$etname�� ����! </font><b class=\"clit\">$et_hit</b> HIT!<BR>";
		while($i < $et_hit){
			$r_no = int(rand(3));
			$randam_no = int(rand(100));
			if($r_no eq "0"){
				if($whp eq "0"){
					if($whp eq "0" && $shp eq "0" && $thp eq "0"){
						last;
					}else{
						$r_no++;
						next;
					}
				}else{
						$et_mpdown = int($ettec_str/2);
					if($ettec_hit  > $randam_no && $etmp > $et_mpdown){
						$com6 .= "<b class=\"clit\"> $ettec_name </b>";
						$etmp -= $et_mpdown;
						if($ettec_cho){
							$ethp += $ettec_str;
							if($etmaxhp < $ethp){$ethp = $etmaxhp;}
							$com6 .= "$etname�� ü���� <b class=\"dmg\">$ettec_str</b>ȸ���ƴ�.";
						}else{
							$clit = int(rand($ettec_str))+$etint-$wmen;
						}
						$com6 .= "<BR>";
					}
					$s1_etdmg = int(rand($etatt)) + $clit - $wdef;
					if($s1_etdmg<0){$s1_etdmg=0;}
					$whp -= $s1_etdmg;
					$com6 .= "$wname���� <b class=\"dmg\">$s1_etdmg</b>�� ������!<BR>";
					if($whp eq "0" || $whp < 0){
						$whp = 0;
						$ethit+=1;
						$com6 .= "<b class=\"dmg\">$wname(��)�� ���� ���ߴ�..</b><BR>"
					}
				}
			}elsif($r_no eq "1"){
				if($shp eq "0"){
					if($whp eq "0" && $shp eq "0" && $thp eq "0"){
						last;
					}else{
						$r_no++;
						next;
					}
				}else{
						$et_mpdown = int($ettec_str/2);
					if($ettec_hit  > $randam_no && $etmp > $et_mpdown){
						$com6 .= "<b class=\"clit\"> $ettec_name </b>";
						$etmp -= $et_mpdown;
						if($ettec_cho){
							$ethp += $ettec_str;
							if($etmaxhp < $ethp){$ethp = $etmaxhp;}
							$com6 .= "$etname�� ü���� <b class=\"dmg\">$ettec_str</b> ȸ���ƴ�.";
						}else{
							$clit = int(rand($ettec_str))+$etint-$smen;
						}
						$com6 .= "<BR>";
					}
					$s2_etdmg = int(rand($etatt)) + $clit - $sdef;
					if($s2_etdmg<0){$s2_etdmg=0;}
					$shp -= $s2_etdmg;
					$com6 .= "$sname���� <b class=\"dmg\">$s2_etdmg</b> �� ������!<BR>";
					if($shp eq "0" || $shp < 0){
						$shp = 0;
						$ethit+=1;
						$com6 .= "$sname(��)�� ���� ���ߴ�..<BR>"
					}
				}
			}else{
				if($thp eq "0"){
					if($whp eq "0" && $shp eq "0" && $thp eq "0"){
						last;
					}else{
						$r_no -=2;
						next;
					}
				}else{
						$et_mpdown = int($ettec_str/2);
					if($ettec_hit  > $randam_no && $etmp > $et_mpdown){
						$com6 .= "<b class=\"clit\"> $ettec_name </B>";
						$etmp -= $et_mpdown;
						if($ettec_cho){
							$ethp += $ettec_str;
							if($etmaxhp < $ethp){$ethp = $etmaxhp;}
							$com6 .= "$etname�� ü���� <b class=\"dmg\">$ettec_str</b> ȸ���ƴ�.";
						}else{
							$clit = int(rand($ettec_str))+$etint-$tmen;
						}
						$com6 .= "<BR>";
					}
					$s3_etdmg = int(rand($etatt)) + $clit - $tdef;
					if($s3_etdmg<0){$s3_etdmg=0;}
					$thp -= $s3_etdmg;
					$com6 .= "$tname��<b class=\"dmg\">$s3_etdmg</b> �� ������!<BR>";
					if($thp eq "0" || $thp < 0){
						$thp = 0;
						$ethit+=1;
						$com6 .= "<b class=\"dmg\">$tname(��)�� ���� ���ߴ�..</b><BR>"
					}
				}
			}
			$clit=0;
			$i++;
		}
		if($whp eq "0" && $shp eq "0" && $thp eq "0"){
			$wflg=1;
			$com6 .= "<b class=\"dmg\">$wunit ���� �����ߴ�.</b><BR>";
		}
		$message6 = "$com6";
		$number++;
	}
		$all_message .= "<p><font size=5 color=008800>$count ��</font><BR>$message1$message4$message2$message5$message3$message6";

	$max_bar = 100;
	$wbar1 = int(($whp/$wmaxhp)*$max_bar);
	$wbar2 = $max_bar-$wbar1;
	$whpimg = "<img src=\"$IMG/$IMG_GROUND/bar1.gif\"  height=\"7\" width=$wbar1><img src=\"$IMG/$IMG_GROUND/bar2.gif\"  height=\"7\" width=$wbar2>";

	$wbar1 = int(($wmp/$wmaxmp)*$max_bar);
	$wbar2 = $max_bar-$wbar1;
	$wmpimg = "<img src=\"$IMG/$IMG_GROUND/bar4.gif\"  height=\"7\" width=$wbar1><img src=\"$IMG/$IMG_GROUND//bar2.gif\"  height=\"7\" width=$wbar2>";

	$ebar1 = int(($ehp/$emaxhp)*$max_bar);
	$ebar2 = $max_bar-$ebar1;
	$ehpimg = "<img src=\"$IMG/$IMG_GROUND/bar1.gif\"  height=\"7\" width=$ebar1><img src=\"$IMG/$IMG_GROUND/bar2.gif\"  height=\"7\" width=$ebar2>";

	$ebar1 = int(($emp/$emaxmp)*$max_bar);
	$ebar2 = $max_bar-$ebar1;
	$empimg = "<img src=\"$IMG/$IMG_GROUND/bar4.gif\"  height=\"7\" width=$ebar1><img src=\"$IMG/$IMG_GROUND/bar2.gif\"  height=\"7\" width=$ebar2>";

		$sbar1 = int(($shp/$smaxhp)*$max_bar);
		$sbar2 = $max_bar-$sbar1;
		$shpimg = "<img src=\"$IMG/$IMG_GROUND/bar1.gif\"  height=\"7\" width=$sbar1><img src=\"$IMG/$IMG_GROUND/bar2.gif\"  height=\"7\" width=$sbar2>";
		$sbar1 = int(($smp/$smaxmp)*$max_bar);
		$sbar2 = $max_bar-$sbar1;
		$smpimg = "<img src=\"$IMG/$IMG_GROUND/bar4.gif\"  height=\"7\" width=$sbar1><img src=\"$IMG/$IMG_GROUND/bar2.gif\"  height=\"7\" width=$sbar2>";

		$tbar1 = int(($thp/$tmaxhp)*$max_bar);
		$tbar2 = $max_bar-$tbar1;
		$thpimg = "<img src=\"$IMG/$IMG_GROUND/bar1.gif\"  height=\"7\" width=$tbar1><img src=\"$IMG/$IMG_GROUND/bar2.gif\"  height=\"7\" width=$tbar2>";
		$tbar1 = int(($tmp/$tmaxmp)*$max_bar);
		$tbar2 = $max_bar-$tbar1;
		$tmpimg = "<img src=\"$IMG/$IMG_GROUND/bar4.gif\"  height=\"7\" width=$tbar1><img src=\"$IMG/$IMG_GROUND/bar2.gif\"  height=\"7\" width=$tbar2>";

		$esbar1 = int(($eshp/$esmaxhp)*$max_bar);
		$esbar2 = $max_bar-$esbar1;
		$eshpimg = "<img src=\"$IMG/$IMG_GROUND/bar1.gif\"  height=\"7\" width=$esbar1><img src=\"$IMG/$IMG_GROUND/bar2.gif\"  height=\"7\" width=$esbar2>";
		$esbar1 = int(($esmp/$esmaxmp)*$max_bar);
		$esbar2 = $max_bar-$esbar1;
		$esmpimg = "<img src=\"$IMG/$IMG_GROUND/bar4.gif\"  height=\"7\" width=$esbar1><img src=\"$IMG/$IMG_GROUND/bar2.gif\"  height=\"7\" width=$esbar2>";

		$etbar1 = int(($ethp/$etmaxhp)*$max_bar);
		$etbar2 = $max_bar-$etbar1;
		$ethpimg = "<img src=\"$IMG/$IMG_GROUND/bar1.gif\"  height=\"7\" width=$etbar1><img src=\"$IMG/$IMG_GROUND/bar2.gif\"  height=\"7\" width=$etbar2>";
		$etbar1 = int(($etmp/$etmaxmp)*$max_bar);
		$etbar2 = $max_bar-$etbar1;
		$etmpimg = "<img src=\"$IMG/$IMG_GROUND/bar4.gif\"  height=\"7\" width=$etbar1><img src=\"$IMG/$IMG_GROUND/bar2.gif\"  height=\"7\" width=$etbar2>";

		$all_message .= "<TABLE bgcolor=$TABLE_C border=\"0\" cellspacing=0>
  <TBODY>
    <TR>
      <TD bgcolor=\"$ELE_BG[$wele]\"><font size=3 color=\"$ELE_C[$wele]\">��$wunit ����</font></TD>
      <Th width=100 bgcolor=$ELE_C[$wele]>HP</Th>
      <Th width=100 bgcolor=$ELE_C[$wele]>MP</Th>
      <TD bgcolor=\"$ELE_BG[$eele]\"><font size=3 color=\"$ELE_C[$eele]\">��$eunit ����</font></TD>
      <Th width=100 bgcolor=$ELE_C[$eele]>HP</Th>
      <Th width=100 bgcolor=$ELE_C[$eele]>MP</Th>
    </TR>
    <TR>
      <Th bgcolor=$TD_C3>$wname</Th>
      <Th bgcolor=$ELE_C[$wele]><font size=4 color=navy>$whp / $wmaxhp<BR>$whpimg</font></Th>
      <Th bgcolor=$ELE_C[$wele]><font size=4 color=navy>$wmp / $wmaxmp<BR>$wmpimg</font></Th>
      <Th bgcolor=$TD_C3>$ename</Th>
      <Th bgcolor=$ELE_C[$eele]><font size=4 color=red>$ehp / $emaxhp<BR>$ehpimg</font></Th>
      <Th bgcolor=$ELE_C[$eele]><font size=4 color=red>$emp / $emaxmp<BR>$empimg</font></Th>
    </TR>
    <TR>
      <Th bgcolor=$TD_C3>$sname</Th>
      <Th bgcolor=$ELE_C[$wele]><font size=4 color=navy>$shp / $smaxhp<BR>$shpimg</font></Th>
      <Th bgcolor=$ELE_C[$wele]><font size=4 color=navy>$smp / $smaxmp<BR>$smpimg</font></Th>
      <Th bgcolor=$TD_C3>$esname</Th>
      <Th bgcolor=$ELE_C[$eele]><font size=4 color=red>$eshp / $esmaxhp<BR>$eshpimg</font></Th>
      <Th bgcolor=$ELE_C[$eele]><font size=4 color=red>$esmp / $esmaxmp<BR>$esmpimg</font></Th>
    </TR>
    <TR>
      <Th bgcolor=$TD_C3>$tname</Th>
      <Th bgcolor=$ELE_C[$wele]><font size=4 color=navy>$thp / $tmaxhp<BR>$thpimg</font></Th>
      <Th bgcolor=$ELE_C[$wele]><font size=4 color=navy>$tmp / $tmaxmp<BR>$tmpimg</font></Th>
      <Th bgcolor=$TD_C3>$etname</Th>
      <Th bgcolor=$ELE_C[$eele]><font size=4 color=red>$ethp / $etmaxhp<BR>$ethpimg</font></Th>
      <Th bgcolor=$ELE_C[$eele]><font size=4 color=red>$etmp / $etmaxmp<BR>$etmpimg</font></Th>
    </TR>
";

	  $all_message .= "</TBODY></TABLE>";

		$count++;
		if($wflg || $flg){last;}
	}


	if($wflg){
		$message7 = "$eunit���� $wunit ������ �¸��ߴ�!";
		&MAP_LOG("<font color=green><b>[õ��]</b></font><b>$eunit ��</b>�� <b>$wunit ��</b>���� �¸��ߴ�!");
		$win_id = $eid;
		$lost_id = $wid;
		$c_name1 = $ename;
		$c_name2 = $esname;
		$c_name3 = $etname;
		$c_id[1] = $eid;
		$c_id[2] = $esid;
		$c_id[3] = $etid;
		$c_chara1 = $echara;
		$c_chara2 = $eschara;
		$c_chara3 = $etchara;
		$c_unit = $eunit;
		$c_con = $econ;
	}elsif($flg){
		&MAP_LOG("<font color=green><b>[õ��]</b></font><b>$wunit ��</b>�� <b>$eunit ��</b>���� �¸��ߴ�!");
		$message7 = "$wunit���� $eunit ������ �¸��ߴ�!";
		$win_id = $wid;
		$lost_id = $eid;
		$c_name1 = $wname;
		$c_name2 = $sname;
		$c_name3 = $tname;
		$c_id[1] = $wid;
		$c_id[2] = $sid;
		$c_id[3] = $tid;
		$c_chara1 = $wchara;
		$c_chara2 = $schara;
		$c_chara3 = $tchara;
		$c_unit = $wunit;
		$c_con = $wcon;
	}else{
		$message7 = "$eunit���� $wunit ������ ������ �¸��ߴ�!";
		$lost_id = $eid;
	}

	open(IN,"$TEAM_OK_LIST") or &ERR("������ �� �� �����ϴ�. [OK_LIST]");
	@OK_DATA = <IN>;
	close(IN);

	@new_ok_list=();
	foreach(@OK_DATA){
		($cid,$cname,$cchara)=split(/<>/);
		if($lost_id eq "$cid"){next;}else{
		push(@new_ok_list,"$_");
		}
	}
	open(OUT,">$TEAM_OK_LIST") or &ERR("������ �� �� �����ϴ�. [OK_LIST]");
	print OUT @new_ok_list;
	close(OUT);

	$w_num = @new_ok_list;
	
	if($w_num eq "1"){
		open(IN,"$TEAM_WINNER_LIST");
		@WINNER_LIST = <IN>;
		close(IN);
		$win_num = @WINNER_LIST;
		if($win_num > 10) { pop(@WINNER_LIST); }

		unshift(@WINNER_LIST,"$win_id<>$c_name1<>$c_name2<>$c_name3<>$c_chara1<>$c_chara2<>$c_chara3<>$c_unit<>$c_con<>\n");

		
		for($i=1;$i<4;$i++){
			$BANK_LIST = "./charalog/bank/$c_id[$i].cgi";
			open(IN,"$BANK_LIST");
			@BANK_DATA = <IN>;
			close(IN);
			($k_no,$k_pass,$k_gold) = split(/<>/,$BANK_DATA[0]);
			$k_gold = $k_gold + 3000000;
			$NEW_BANK_DATA="$c_id[$i]<>$k_pass<>$k_gold<>\n";

			open(OUT,">$BANK_LIST");
			print OUT $NEW_BANK_DATA;
			close(OUT);
		}

		&COUNTRY_DATA_OPEN("$c_con");
		$xxgold += 10000000;
		&COUNTRY_DATA_INPUT;

		&MAP_LOG("<font color=green><b>[õ��]</b></font><b>$c_unit ��</b>�� ��$ccountȸ õ��������ȸ���� ���! ������� �� ������ ���� ���¿� <font color=red>300��G</font>�� $xxname���� <font color=red><b>1000��G</font></b>�� �۱ݵƽ��ϴ�.");

		open(OUT,">$TEAM_WINNER_LIST") or &ERR("������ �� �� �����ϴ�. [WINNER_LIST]");
		print OUT @WINNER_LIST;
		close(OUT);
	}

	$number++;
	$all_message .= "<BR>$message7$message8$message9$message10$message14 ";


	$header = <<"EOM";
<html>
<head>
<META HTTP-EQUIV="Content-type" CONTENT="text/html; charset=euc-kr">
<STYLE type="text/css">
<!--
BODY,TR,TD,TH{
font-family : "tahoma";
font-size: $FONT_SIZE
}
A:HOVER{
 color: $ALINK
}
.S1 {color:#fff; border-style: double; border-width: 3px;BACKGROUND: #633;}
.S2 {color:#fff; border-style: double; border-width: 3px;BACKGROUND: #844;}
.S3 {color:#fff; border-style: double; border-width: 3px;BACKGROUND: #363;}
.dmg { color: #FF0000; font-size: 18pt }
.clit { color: #0000FF; font-size: 18pt }
-->
</STYLE>
<title>$GAME_TITLE</title></head>
<body background="$BACKGROUND" bgcolor="$BGCOLOR" text="$TEXT" link="$LINK" vlink="$VLINK" alink="$ALINK">
EOM

$pri = <<"EOM";
<TABLE width=100% height=100% bgcolor=$TABLE_C>
  <TBODY>
    <TR>
      <TD bgcolor=$TD_C1 height=5> <font size=4><B> ���� - $wunit�� vs $eunit�� - ����<BR></font> ���սð�: $daytime </B>
      </TD>
    </TR>
    <TR>
      <TD bgcolor=$TD_C4>
      <TABLE width=100% border="0">
        <TBODY>
          <TR>
            <TD bgcolor=$TD_C1><img src="$IMG/$wchara.gif"></TD>
            <TD bgcolor=$TD_C1>$simg</TD>
            <TD bgcolor=$TD_C1>$timg</TD>
            <TD align=center width=100%>
<TABLE bgcolor=$TABLE_C>
  <TBODY>
    <TR>
      <TH bgcolor=\"$ELE_BG[$wele]\" colspan=9><font size=3 color=\"$ELE_C[$wele]\">��$wunit ����</font></TH>
    </TR>
    <TR>
      <TD bgcolor=$TD_C2>�̸�</TD>
      <Th bgcolor=$TD_C2 width=50>HP</Th>
      <Th bgcolor=$TD_C2 width=50>MP</Th>
      <TD bgcolor=$TD_C2>����</TD>
      <TD bgcolor=$TD_C2>��</TD>
      <TD bgcolor=$TD_C2>���ݷ�</TD>
      <TD bgcolor=$TD_C2>����</TD>
      <TD bgcolor=$TD_C2>����</TD>
      <TD bgcolor=$TD_C2>�ɷ�ġ</TD>
    </TR>
    <TR>
      <TD bgcolor=$TD_C3>$wname</TD>
      <TD bgcolor=$TD_C3>$s_khp/$wmaxhp<BR>$whpimg2</TD>
      <TD bgcolor=$TD_C3>$s_kmp/$wmaxmp<BR>$wmpimg2</TD>
      <TD bgcolor=$TD_C3>$warmname</TD>
      <TD bgcolor=$TD_C3>$wproname</TD>
      <TD bgcolor=$TD_C3>$wstr(+$warmdmg)</TD>
      <TD bgcolor=$TD_C3>$wvit(+$wprodmg+$waccdmg)</TD>
      <TD bgcolor=$TD_C3>$SYOKU[$wclass]</TD>
      <TD bgcolor=$TD_C3>$wpoint</TD>
    </TR>$s_sstatus$t_sstatus
  </TBODY>
</TABLE>

</TD>
          </TR>
        </TBODY>
      </TABLE>
      </TD>
    </TR>
    <TR>
      <TD bgcolor=$TD_C4>
      <TABLE width=100% border=0>
        <TBODY>
          <TR>
            <TD align=center width=100%>
<TABLE bgcolor=$TABLE_C>
  <TBODY>
    <TR>
      <Th bgcolor=\"$ELE_BG[$eele]\" colspan=9><font size=3 color=\"$ELE_C[$eele]\">��$eunit ����</font></Th>
    </TR>
    <TR>
      <TD bgcolor=$TD_C2>�̸�</TD>
      <Th bgcolor=$TD_C2 width=50>HP</Th>
      <Th bgcolor=$TD_C2 width=50>MP</Th>
      <TD bgcolor=$TD_C2>����</TD>
      <TD bgcolor=$TD_C2>��</TD>
      <TD bgcolor=$TD_C2>���ݷ�</TD>
      <TD bgcolor=$TD_C2>����</TD>
      <TD bgcolor=$TD_C2>����</TD>
      <TD bgcolor=$TD_C2>�ɷ�ġ</TD>
    </TR>
    <TR>
      <TD bgcolor=$TD_C3>$ename</TD>
      <TD bgcolor=$TD_C3>$s_ehp/$emaxhp<BR>$ehpimg2</TD>
      <TD bgcolor=$TD_C3>$s_ehp/$emaxmp<BR>$empimg2</TD>
      <TD bgcolor=$TD_C3>$earmname</TD>
      <TD bgcolor=$TD_C3>$eproname</TD>
      <TD bgcolor=$TD_C3>$estr(+$earmdmg)</TD>
      <TD bgcolor=$TD_C3>$evit(+$eprodmg+$eaccdmg)</TD>
      <TD bgcolor=$TD_C3>$SYOKU[$eclass]</TD>
      <TD bgcolor=$TD_C3>$epoint</TD>
    </TR>$es_sstatus$et_sstatus
  </TBODY>
</TABLE>
</TD>
            <TD bgcolor=$TD_C1><img src="$IMG/$echara.gif"></TD>
            <TD bgcolor=$TD_C1>$esimg</TD>
            <TD bgcolor=$TD_C1>$etimg</TD>
          </TR>
        </TBODY>
      </TABLE>
      </TD>
    </TR>
    <TR>
      <TD bgcolor=$TD_C4 width=100%>
      <TABLE width=100% bgcolor=$TABLE_C>
        <TBODY>
          <TR>
            <TD bgcolor=$TD_C4>
<CENTER><h1>���� - $wunit�� vs $eunit�� - ����<h1>
<BR>
<table width=80% border=0><TBODY>
<TR><Td width=50%><font color=$ELE_BG[$wcon] size=4><b>$wmes</font></Td><Td><font color=$ELE_BG[$econ] size=4><b>$emes</Td></TR>
<TR><Td><font color=$ELE_BG[$wcon] size=4><b>&nbsp;&nbsp;$smes</Td><Td><font color=$ELE_BG[$econ] size=4><b>&nbsp;&nbsp;$esmes</Td></TR>
<TR><Td><font color=$ELE_BG[$wcon] size=4><b>&nbsp;&nbsp;&nbsp;&nbsp;$tmes</Td><Td><font color=$ELE_BG[$econ] size=4><b>&nbsp;&nbsp;&nbsp;&nbsp;$etmes</Td></TR>
</TBODY></TABLE>
<font size=3><B>$all_message</font></B>
</TD>            <TD bgcolor=$TD_C3></TD>
          </TR>
        </TBODY>
      </TABLE>
      </TD>
    </TR>
  </TBODY>
</TABLE>

EOM

#	&CHARA_INPUT;

#	&ENEMY_INPUT;

	open(IN,"$TEAM_TIME_LIST");
	@time_check = <IN>;
	close(IN);

	($lasttime,$ccount,$c_count,$last_battle) = split(/<>/,$time_check[0]);
	
	
	if($c_count eq ""){$c_count = 1;}else{$c_count++;}
	if($c_count eq "1"){
		open(OUT,">$HTML_FILE/battle1.htm") or &ERR('������ �� �� �����ϴ�. [HTML]');
	}elsif($c_count eq "2"){
		open(OUT,">$HTML_FILE/battle2.htm") or &ERR('������ �� �� �����ϴ�. [HTML]');
	}elsif($c_count eq "3"){
		open(OUT,">$HTML_FILE/battle3.htm") or &ERR('������ �� �� �����ϴ�. [HTML]');
	}elsif($c_count eq "4"){
		open(OUT,">$HTML_FILE/battle4.htm") or &ERR('������ �� �� �����ϴ�. [HTML]');
	}elsif($c_count eq "5"){
		open(OUT,">$HTML_FILE/battle5.htm") or &ERR('������ �� �� �����ϴ�. [HTML]');
	}elsif($c_count eq "6"){
		open(OUT,">$HTML_FILE/battle6.htm") or &ERR('������ �� �� �����ϴ�. [HTML]');
	}else{
		open(OUT,">$HTML_FILE/battle7.htm") or &ERR('������ �� �� �����ϴ�. [HTML]');
	}
	print OUT $header;
	print OUT $pri;
	print OUT "</BODY></HTML>";
	close(OUT);
	if($w_num eq "1"){if($ccount eq ""){$ccount = 2;}else{$ccount++;}$last_battle=$c_count;$c_count=0;}
	$new_time_list = "$tt<>$ccount<>$c_count<>$last_battle<>\n";

	open(OUT,">$TEAM_TIME_LIST") or &ERR("������ �� �� �����ϴ�. [TIME_LIST]");
	print OUT $new_time_list;
	close(OUT);

}

#_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/#
#      CHARA DATA ALL OPEN     #
#_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/#

sub CHARA_DATA_OPEN {
	$wid = $fid[0];
	open(IN,"./charalog/main/$wid.cgi") or &ERR("������ �� �� �����ϴ�. \[CHARA_DATA1\]");
	@W_DATA = <IN>;
	close(IN);
	($wid,$wpass,$wname,$wurl,$wchara,$wsex,$whp,$wmaxhp,$wmp,$wmaxmp,$wele,$wstr,$wvit,$wint,$wmen,$wagi,$wcom,$wgold,$w_ex,$wcex,$wunit,$wcon,$warm,$wpro,$wacc,$wsub1,$wsub2,$wtac,$wsta,$wpos,$wmes,$whost,$wdate,$wsyo,$wclass,$wtotal,$wkati) = split(/<>/,$W_DATA[0]);

	$wlv = int($w_ex/$EX)+1;

	open(IN,"./charalog/main/$fid[1].cgi") or &ERR('������ �� �� �����ϴ�. [CHARA_DATA2]');
	@S1_DATA = <IN>;
	close(IN);

	($sid,$spass,$sname,$surl,$schara,$ssex,$shp,$smaxhp,$smp,$smaxmp,$sele,$sstr,$svit,$sint,$smen,$sagi,$scom,$sgold,$s_ex,$scex,$sunit,$scon,$sarm,$spro,$sacc,$ssub1,$ssub2,$stac,$ssta,$spos,$smes,$shost,$sdate,$ssyo,$sclass,$stotal,$skati) = split(/<>/,$S1_DATA[0]);
	$slv = int($s_ex/$EX)+1;
	$simg = "<img src=\"$IMG/$schara.gif\" width=$img_wid height=$img_height alt=$sname>";

	open(IN,"./charalog/main/$fid[2].cgi") or &ERR('������ �� �� �����ϴ�. [CHARA_DATA3]');
	@S2_DATA = <IN>;
	close(IN);
	($tid,$tpass,$tname,$turl,$tchara,$tsex,$thp,$tmaxhp,$tmp,$tmaxmp,$tele,$tstr,$tvit,$tint,$tmen,$tagi,$tcom,$tgold,$t_ex,$tcex,$tunit,$tcon,$tarm,$tpro,$tacc,$tsub1,$tsub2,$ttac,$tsta,$tpos,$tmes,$thost,$tdate,$tsyo,$tclass,$ttotal,$tkati) = split(/<>/,$S2_DATA[0]);
	$timg = "<img src=\"$IMG/$tchara.gif\" width=$img_wid height=$img_height alt=$tname>";
	$tlv = int($t_ex/$EX)+1;
}

#_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/#
#     ENEMY DATA ALL OPEN      #
#_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/#

sub ENEMY_DATA_OPEN {

	open(IN,"./charalog/main/$eid[0].cgi") or &ERR('������ �� �� �����ϴ�. [E_DATA1]');
	@E_DATA = <IN>;
	close(IN);
	($eid,$epass,$ename,$eurl,$echara,$esex,$ehp,$emaxhp,$emp,$emaxmp,$eele,$estr,$evit,$eint,$emen,$eagi,$ecom,$egold,$e_ex,$ecex,$eunit,$econ,$earm,$epro,$eacc,$esub1,$esub2,$etac,$esta,$epos,$emes,$ehost,$edate,$esyo,$eclass,$etotal,$ekati) = split(/<>/,$E_DATA[0]);
	$elv = int($e_ex/$EX)+1;

	open(IN,"./charalog/main/$eid[1].cgi") or &ERR('������ �� �� �����ϴ�. [E_DATA2]');
	@E1_DATA = <IN>;
	close(IN);
	($esid,$espass,$esname,$esurl,$eschara,$essex,$eshp,$esmaxhp,$esmp,$esmaxmp,$esele,$esstr,$esvit,$esint,$esmen,$esagi,$escom,$esgold,$es_ex,$escex,$esunit,$escon,$esarm,$espro,$esacc,$essub1,$essub2,$estac,$essta,$espos,$esmes,$eshost,$esdate,$essyo,$esclass,$estotal,$eskati) = split(/<>/,$E1_DATA[0]);
	$eslv = int($es_ex/$EX)+1;
	$esimg = "<img src=\"$IMG/$eschara.gif\">";

	open(IN,"./charalog/main/$eid[2].cgi") or &ERR('������ �� �� �����ϴ�. [E_DATA3]');
	@E2_DATA = <IN>;
	close(IN);
	($etid,$etpass,$etname,$eturl,$etchara,$etsex,$ethp,$etmaxhp,$etmp,$etmaxmp,$etele,$etstr,$etvit,$etint,$etmen,$etagi,$etcom,$etgold,$et_ex,$etcex,$etunit,$etcon,$etarm,$etpro,$etacc,$etsub1,$etsub2,$ettac,$etsta,$etpos,$etmes,$ethost,$etdate,$etsyo,$etclass,$ettotal,$etkati) = split(/<>/,$E2_DATA[0]);
	$etimg = "<img src=\"$IMG/$etchara.gif\">";
	$etlv = int($et_ex/$EX)+1;

}

#_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/#
#        ITEM DATA OPEN        #
#_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/#

sub ITEM_DATA_OPEN {

	open(IN,"$ARM_LIST") or &ERR('������ �� �� �����ϴ�. [ITEM1]');
	@ARM_DATA = <IN>;
	close(IN);
	open(IN,"$PRO_LIST") or &ERR('������ �� �� �����ϴ�. [ITEM2]');
	@PRO_DATA = <IN>;
	close(IN);
	open(IN,"$ACC_LIST") or &ERR('������ �� �� �����ϴ�. [ITEM3]');
	@ACC_DATA = <IN>;
	close(IN);

	($warmname,$warmval,$warmdmg,$warmwei,$warmele,$warmsta,$warmclass,$warmtownid) = split(/<>/,$ARM_DATA[$warm]);
	if($warmsta eq "use"){
		open(IN,"./charalog/arm/$wid.cgi");
		@MY_ARM_DATA = <IN>;
		close(IN);
		($warmname,$warmval,$warmdmg,$warmwei,$warmele,$warmsta,$warmclass,$warmtownid) = split(/<>/,$MY_ARM_DATA[0]);
	}
	($wproname,$wproval,$wprodmg,$wprowei,$wproele,$wprosta,$wproclass,$wprotownid) = split(/<>/,$PRO_DATA[$wpro]);
	($waccname,$waccval,$waccdmg,$waccwei,$waccele,$waccsta,$waccclass,$wacctownid) = split(/<>/,$ACC_DATA[$wacc]);

	($sarmname,$sarmval,$sarmdmg,$sarmwei,$sarmele,$sarmsta,$sarmclass,$sarmtownid) = split(/<>/,$ARM_DATA[$sarm]);
	if($sarmsta eq "use"){
		open(IN,"./charalog/arm/$sid.cgi");
		@MY_ARM_DATA = <IN>;
		close(IN);
		($sarmname,$sarmval,$sarmdmg,$sarmwei,$sarmele,$sarmsta,$sarmclass,$sarmtownid) = split(/<>/,$MY_ARM_DATA[0]);
	}

	($sproname,$sproval,$sprodmg,$sprowei,$sproele,$sprosta,$sproclass,$sprotownid) = split(/<>/,$PRO_DATA[$spro]);
	($saccname,$saccval,$saccdmg,$saccwei,$saccele,$saccsta,$saccclass,$sacctownid) = split(/<>/,$ACC_DATA[$sacc]);

	($tarmname,$tarmval,$tarmdmg,$tarmwei,$tarmele,$tarmsta,$tarmclass,$tarmtownid) = split(/<>/,$ARM_DATA[$tarm]);
	if($tarmsta eq "use"){
		open(IN,"./charalog/arm/$tid.cgi");
		@MY_ARM_DATA = <IN>;
		close(IN);
		($tarmname,$tarmval,$tarmdmg,$tarmwei,$tarmele,$tarmsta,$tarmclass,$tarmtownid) = split(/<>/,$MY_ARM_DATA[0]);
	}
	($tproname,$tproval,$tprodmg,$tprowei,$tproele,$tprosta,$tproclass,$tprotownid) = split(/<>/,$PRO_DATA[$tpro]);
	($taccname,$taccval,$taccdmg,$taccwei,$taccele,$taccsta,$taccclass,$tacctownid) = split(/<>/,$ACC_DATA[$tacc]);

	($earmname,$earmval,$earmdmg,$earmwei,$earmele,$earmsta,$earmclass,$earmtownid) = split(/<>/,$ARM_DATA[$earm]);
	if($earmsta eq "use"){
		open(IN,"./charalog/arm/$eid.cgi");
		@MY_ARM_DATA = <IN>;
		close(IN);
		($earmname,$earmval,$earmdmg,$earmwei,$earmele,$earmsta,$earmclass,$earmtownid) = split(/<>/,$MY_ARM_DATA[0]);
	}
	($eproname,$eproval,$eprodmg,$eprowei,$eproele,$eprosta,$eproclass,$eprotownid) = split(/<>/,$PRO_DATA[$epro]);
	($eaccname,$eaccval,$eaccdmg,$eaccwei,$eaccele,$eaccsta,$eaccclass,$eacctownid) = split(/<>/,$ACC_DATA[$eacc]);

	($esarmname,$esarmval,$esarmdmg,$esarmwei,$esarmele,$esarmsta,$esarmclass,$esarmtownid) = split(/<>/,$ARM_DATA[$esarm]);
	if($esarmsta eq "use"){
		open(IN,"./charalog/arm/$esid.cgi");
		@MY_ARM_DATA = <IN>;
		close(IN);
		($esarmname,$esarmval,$esarmdmg,$esarmwei,$esarmele,$esarmsta,$esarmclass,$esarmtownid) = split(/<>/,$MY_ARM_DATA[0]);
	}
	($esproname,$esproval,$esprodmg,$esprowei,$esproele,$esprosta,$esproclass,$esprotownid) = split(/<>/,$PRO_DATA[$espro]);
	($esaccname,$esaccval,$esaccdmg,$esaccwei,$esaccele,$esaccsta,$esaccclass,$esacctownid) = split(/<>/,$ACC_DATA[$esacc]);

	($etarmname,$etarmval,$etarmdmg,$etarmwei,$etarmele,$etarmsta,$etarmclass,$etarmtownid) = split(/<>/,$ARM_DATA[$etarm]);
	if($etarmsta eq "use"){
		open(IN,"./charalog/arm/$etid.cgi");
		@MY_ARM_DATA = <IN>;
		close(IN);
		($etarmname,$etarmval,$etarmdmg,$etarmwei,$etarmele,$etarmsta,$etarmclass,$etarmtownid) = split(/<>/,$MY_ARM_DATA[0]);
	}
	($etproname,$etproval,$etprodmg,$etprowei,$etproele,$etprosta,$etproclass,$etprotownid) = split(/<>/,$PRO_DATA[$etpro]);
	($etaccname,$etaccval,$etaccdmg,$etaccwei,$etaccele,$etaccsta,$etaccclass,$etacctownid) = split(/<>/,$ACC_DATA[$etacc]);

}

#_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/#
#      TAC DATA ALL OPEN       #
#_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/#

sub TAC_DATA_ALL_OPEN {

	open(IN,"$TEC_DATA") or &ERR('������ �� �� �����ϴ�. [TAC]');
	@TEC = <IN>;
	close(IN);

	foreach(@TEC){
		($wtec_no,$wtec_name,$wtec_str,$wtec_hit,$wtec_sta,$wtec_cho,$wtec_class) = split(/<>/);
		if( $wtec_no eq "$wtac"){last;}
	}

	foreach(@TEC){
		($stec_no,$stec_name,$stec_str,$stec_hit,$stec_sta,$stec_cho,$stec_class) = split(/<>/);
		if( $stec_no eq "$stac"){last;}
	}

	foreach(@TEC){
		($ttec_no,$ttec_name,$ttec_str,$ttec_hit,$ttec_sta,$ttec_cho,$ttec_class) = split(/<>/);
		if( $ttec_no eq "$ttac"){last;}
	}

	foreach(@TEC){
		($etec_no,$etec_name,$etec_str,$etec_hit,$etec_sta,$etec_cho,$etec_class) = split(/<>/);
		if( $etec_no eq "$etac"){last;}
	}

	foreach(@TEC){
		($estec_no,$estec_name,$estec_str,$estec_hit,$estec_sta,$estec_cho,$estec_class) = split(/<>/);
		if( $estec_no eq "$estac"){last;}
	}

	foreach(@TEC){
		($ettec_no,$ettec_name,$ettec_str,$ettec_hit,$ettec_sta,$ettec_cho,$ettec_class) = split(/<>/);
		if( $ettec_no eq "$ettac"){last;}
	}

}

1;