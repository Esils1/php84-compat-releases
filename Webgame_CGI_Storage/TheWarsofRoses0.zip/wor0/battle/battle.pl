#_/_/_/_/_/_/_/_/_/_/_/#
#_/    ����  ȭ��    _/#
#_/_/_/_/_/_/_/_/_/_/_/#

sub BATTLE {

	&CHARA_OPEN;
	$date = time();
	$s_time = $date - $kdate;
	if($s_time < $BATTLE_TIME){$s_time = $BATTLE_TIME - $s_time;&ERR("���� �������� $s_time �� ��ٷ� �ּ���.");}

	if($in{"type"} eq "chanp_battle"){
		open(IN,"$CHANP_LIST") or &ERR('������ �� �� �����ϴ�.');
		@E_DATA = <IN>;
		close(IN);
		($eid,$epass,$ename,$eurl,$echara,$esex,$ehp,$emaxhp,$emp,$emaxmp,$eele,$estr,$evit,$eint,$emen,$eagi,$ecom,$egold,$e_ex,$ecex,$eunit,$econ,$earm,$epro,$eacc,$esub1,$esub2,$etac,$esta,$epos,$emes,$ehost,$edate,$esyo,$eclass,$etotal,$ekati,$lcount,$lname,$lurl,$lunit) = split(/<>/,$E_DATA[0]);
		$elv = int($e_ex/$EX)+1;
		if($in{'eid'} ne "$eid" ){&ERR("�ùٸ� ID�� �ƴմϴ�.");}

		$kgold -= $CHANP_MONEY;
	}else{
		&ENEMY_OPEN;
	}

	&CHARA_ITEM_OPEN;
	&TAC_DATA_OPEN;

	if($in{"type"} ne "chanp_battle"){
		&MAP_LOG(" $kunit ���� $eunit ���� ������ �����ߴ�! ");
	}
	$knum=3;
	$enum=3;
	if($shp eq ""){ $shp = 0;$knum--;}
	if($thp eq ""){ $thp = 0;$knum--;}
	if($eshp eq ""){ $eshp = 0;$enum--;}
	if($ethp eq ""){ $ethp = 0;$enum--;}

	$s_ehp = $ehp;
	$s_khp = $khp;
	$s_emp = $emp;
	$s_kmp = $kmp;

	$kdef = int(($kvit+$kprodmg)/3);
	$edef = int(($evit+$eprodmg)/3);

	$flg=0;
	$kflg=0;
	$number=1;

	$kpoint=int(($kmaxhp+$kmaxmp)/3)+$kstr+$kvit+$kint+$kmen+$kagi;
	$epoint=int(($emaxhp+$emaxmp)/3)+$estr+$evit+$eint+$emen+$eagi;

	$kget_kgold=0;
	$kget_k_ex=0;
	$kget_s_ex=0;
	$kget_t_ex=0;
	$kget_cex=0;

	$kget_egold=0;
	$kget_e_ex=0;
	$kget_es_ex=0;
	$kget_et_ex=0;
	$kget_e_cex=0;

	$kbar1 = int(($khp/$kmaxhp)*50);
	$kbar2 = 50-$kbar1;
	$khpimg = "<img src=\"$IMG/$IMG_GROUND/bar1.gif\"  height=\"7\" width=$kbar1><img src=\"$IMG/$IMG_GROUND/bar2.gif\"  height=\"7\" width=$kbar2>";

	$kbar1 = int(($kmp/$kmaxmp)*50);
	$kbar2 = 50-$kbar1;
	$kmpimg = "<img src=\"$IMG/$IMG_GROUND/bar1.gif\"  height=\"7\" width=$kbar1><img src=\"$IMG/$IMG_GROUND//bar2.gif\"  height=\"7\" width=$kbar2>";

	$ebar1 = int(($ehp/$emaxhp)*50);
	$ebar2 = 50-$ebar1;
	$ehpimg = "<img src=\"$IMG/$IMG_GROUND/bar1.gif\"  height=\"7\" width=$ebar1><img src=\"$IMG/$IMG_GROUND/bar2.gif\"  height=\"7\" width=$ebar2>";

	$ebar1 = int(($emp/$emaxmp)*50);
	$ebar2 = 50-$ebar1;
	$empimg = "<img src=\"$IMG/$IMG_GROUND/bar1.gif\"  height=\"7\" width=$ebar1><img src=\"$IMG/$IMG_GROUND/bar2.gif\"  height=\"7\" width=$ebar2>";



	if($khp ne "0"){
		$i=0;
		$katt = $kstr+$karmdmg;
		$k_hit = int(($kagi - ($karmwei + $kprowei + $kaccwei))/50);
		if($k_hit <= 0){$k_hit = 1;}
		$com1 .= "$kname�� ����!<font color=red>$k_hit</font> HIT!<BR>";
		while($i < $k_hit){
			$r_no = int(rand(3));
			$randam_no = int(rand(100));
			if($r_no eq "0"){
				if($ehp eq "0"){
					if($ehp eq "0" && $eshp eq "0" && $ethp eq "0"){
						last;
					}else{
						$r_no++;
						next;
					}
				}else{
						$k_mpdown = int($ktec_str/2);
					if($ktec_hit  > $randam_no && $kmp > $k_mpdown){
						$com1 .= "<font color=red> $ktec_name </font>";
						$kmp -= $k_mpdown;
						if($ktec_cho){
							$khp += $ktec_str;
							if($kmaxhp < $khp){$khp = $kmaxhp;}
							$com1 .= "$kname�� ü���� $ktec_str ȸ���ƴ�.";
						}else{
							$clit = int(rand($ktec_str))-$emen+$kint;
						}
						$com1 .= "<BR>";
					}
					$s1_kdmg = int(rand($katt)) + $clit - $edef;
					if($s1_kdmg<0){$s1_kdmg=0;}
					$ehp -= $s1_kdmg;
					$com1 .= "$kname�� ����! $ename���� $s1_kdmg�� ������!<BR>";
					if($ehp eq "0" || $ehp < 0){
						$ehp = 0;
						$khit+=1;
						$com1 .= "$ename(��)�� ���� ���� ��������.<BR>"
					}
				}
			}elsif($r_no eq "1"){
				if($eshp eq "0"){
					if($ehp eq "0" && $eshp eq "0" && $ethp eq "0"){
						last;
					}else{
						$r_no++;
						next;
					}
				}else{
						$k_mpdown = int($ktec_str/2);
					if($ktec_hit  > $randam_no && $kmp > $k_mpdown){
						$com1 .= "<font color=red> $ktec_name </font>";
						$kmp -= $k_mpdown;
						if($ktec_cho){
							$khp += $ktec_str;
							if($kmaxhp < $khp){$khp = $kmaxhp;}
							$com1 .= "$kname�� ü���� $ktec_str ȸ���ƴ�.";
						}else{
							$clit = int(rand($ktec_str))+$kint-$esmen;
						}
						$com1 .= "<BR>";
					}
					$s2_kdmg = int(rand($katt)) - $esdef;
					if($s2_kdmg<0){$s2_kdmg=0;}
					$eshp -= $s2_kdmg;
					$com1 .= "$kname�� ����! $esname���� $s2_kdmg�� ������!<BR>";
					if($eshp eq "0" || $eshp < 0){
						$eshp = 0;
						$khit+=1;
						$com1 .= "$esname(��)�� ���� ���� ��������.<BR>"
					}
				}
			}else{
				if($ethp eq "0"){
					if($ehp eq "0" && $eshp eq "0" && $ethp eq "0"){
						last;
					}else{
						$r_no -=2;
						next;
					}
				}else{
						$k_mpdown = int($ktec_str/2);
					if($ktec_hit  > $randam_no && $kmp > $k_mpdown){
						$com1 .= "<font color=red> $ktec_name </font>";
						$kmp -= $k_mpdown;
						if($ktec_cho){
							$khp += $ktec_str;
							if($kmaxhp < $khp){$khp = $kmaxhp;}
							$com1 .= "$kname�� ü���� $ktec_str ȸ���ƴ�.";
						}else{
							$clit = int(rand($ktec_str))+$kint-$etmen;
						}
						$com1 .= "<BR>";
					}
					$s3_kdmg = int(rand($katt)) - $etdef;
					if($s3_kdmg < 0){$s3_kdmg=0;}
					$ethp -= $s3_kdmg;
					$com1 .= "$kname�� ����! $etname���� $s3_kdmg�� ������!<BR>";
					if($ethp eq "0" || $ethp < 0){
						$ethp = 0;
						$khit+=1;
						$com1 .= "$etname(��)�� ���� ���� ��������.<BR>"
					}
				}
			}
			$i++;
		}
		if($ehp eq "0" && $eshp eq "0" && $ethp eq "0"){
			$flg=1;
			$com1 .= "$kunit ���� $eunit ���� ������״�!<BR>";
		}
		$message1 = "st[$number]=\"$com1\"";
		$number++;
	}


	if($ehp ne "0"){
		$i=0;
		$eatt = $estr+$earmdmg;
		$e_hit = int(($eagi - ($earmwei + $eprowei+$eaccdmg))/50);
		if($e_hit <= 0){$e_hit = 1;}
		$com4 = "$ename�� ����!<font color=red>$e_hit</font> HIT!<BR>";
		while($i < $e_hit){
			$r_no = int(rand(3));
			$randam_no = int(rand(100));
			if($r_no eq "0"){
				if($khp eq "0" ){
					if($khp > 0 || $shp > 0 || $thp > 0){
						$r_no++;
						next;
					}else{
						last;
					}
				}else{
						$e_mpdown = int($etec_str/2);
					if($etec_hit  > $randam_no && $emp > $e_mpdown){
						$com4 .= "<font color=red> $etec_name </font>";
						$emp -= $e_mpdown;
						if($etec_cho){
							$ehp += $etec_str;
							if($emaxhp < $ehp){$ehp = $emaxhp;}
							$com4 .= "$ename�� ü���� $etec_str ȸ���ƴ�.";
						}else{
							$clit = int(rand($etec_str))+$eint-$kmen;
						}
						$com4 .= "<BR>";
					}
					$s1_edmg = int(rand($eatt)) + $clit - $kdef;
					if($s1_edmg<0){$s1_edmg=0;}
					$khp -= $s1_edmg;
					$com4 .= "$ename�� ����! $kname���� $s1_edmg�� ������!<BR>";
					if($khp eq "0" || $khp < 0){
						$khp = 0;
						$ehit+=1;
						$com4 .= "$kname(��)�� ���� ���� ��������.<BR>"
					}
				}
			}elsif($r_no eq "1"){
				if($shp eq "0"){
					if($khp > 0 || $shp > 0 || $thp > 0){
						$r_no++;
						next;
					}else{
						last;
					}
				}else{
						$e_mpdown = int($etec_str/2);
					if($etec_hit  > $randam_no && $emp > $e_mpdown){
						$com4 .= "<font color=red> $etec_name </font>";
						$emp -= $e_mpdown;
						if($etec_cho){
							$ehp += $etec_str;
							if($emaxhp < $ehp){$ehp = $emaxhp;}
							$com4 .= "$ename�� ü���� $etec_str ȸ���ƴ�.";
						}else{
							$clit = int(rand($etec_str))+$eint-$smen;
						}
						$com4 .= "<BR>";
					}
					$s2_edmg = int(rand($eatt)) + $clit - $sdef;
					if($s2_edmg<0){$s2_edmg=0;}
					$shp -= $s2_edmg;
					$com4 .= "$ename�� ����! $sname���� $s2_edmg�� ������!<BR>";
					if($shp eq "0" || $shp < 0){
						$shp = 0;
						$ehit+=1;
						$com4 .= "$sname(��)�� ���� ���� ��������.<BR>"
					}
				}
			}else{
				if($thp eq "0"){
					if($khp > 0 || $shp > 0 || $thp > 0){
						$r_no -= 2;
						next;
					}else{
						last;
					}
				}else{
						$e_mpdown = int($etec_str/2);
					if($etec_hit  > $randam_no && $emp > $e_mpdown){
						$com4 .= "<font color=red> $etec_name </font>";
						$emp -= $e_mpdown;
						if($etec_cho){
							$ehp += $etec_str;
							if($emaxhp < $ehp){$ehp = $emaxhp;}
							$com4 .= "$ename�� ü���� $etec_str ȸ���ƴ�.";
						}else{
							$clit = int(rand($etec_str))+$eint-$tmen;
						}
						$com4 .= "<BR>";
					}
					$s3_edmg = int(rand($eatt)) + $clit - $tdef;
					if($s3_edmg < 0){$s3_edmg=0;}
					$thp -= $s3_edmg;
					$com4 .= "$ename�� ����! $tname���� $s3_edmg�� ������!<BR>";
					if($thp eq "0" || $thp < 0){
						$thp = 0;
						$ehit+=1;
						$com4 .= "$tname(��)�� ���� ���� ��������.<BR>"
					}
				}
			}
			$i++;
			$clit=0;
		}
		if($khp eq "0" && $shp eq "0" && $thp eq "0"){
			$kflg=1;
			$com4 .= "$kunit ���� �����ߴ�..<BR>";
		}
		$message4 = "st[$number]=\"$com4\"";
		$number++;
	}
	if($khp eq "0"){$kflg=1;}
	if($ehp eq "0"){$flg=1;}

	$kgetgold=($epoint+$espoint+$etpoint)*5;
	$egetgold=($kpoint+$spoint+$tpoint)*5;

	$kget_ex = int(($s1_kdmg+$s2_kdmg+$s3_kdmg+$s1_sdmg+$s2_sdmg+$s3_sdmg+$s1_tdmg+$s2_tdmg+$s3_tdmg)/$knum*($kgetgold/$egetgold)/3)+int(rand(10));

	if($kget_ex > 80){
		$kget_ex = 80+int(rand(10));
	}

	if($k_ex < $EX * 99 && $khp ne "0"){
		$k_ex_fol=($k_ex % $EX) + $kget_ex;
		$k_ex+=$kget_ex;
	}
	if($s_ex < $EX * 99 && $shp ne "0"){
		$s_ex_fol=($s_ex % $EX) + $kget_ex;
		$s_ex+=$kget_ex;
	}
	if($t_ex < $EX * 99 && $thp ne "0"){
		$t_ex_fol=($t_ex % $EX) + $kget_ex;
		$t_ex+=$kget_ex;
	}
	if($e_ex < $EX * 99 && $ehp ne "0"){
		$e_ex_fol=($e_ex % $EX) + $eget_ex;
		$e_ex+=$eget_ex;
	}
	if($es_ex < $EX * 99 && $eshp ne "0"){
		$es_ex_fol=($es_ex % $EX) + $eget_ex;
		$es_ex+=$eget_ex;
	}
	if($et_ex < $EX * 99 && $ethp ne "0"){
		$et_ex_fol=($et_ex % $EX) + $eget_ex;
		$et_ex+=$eget_ex;
	}
	


	if($kflg){
		$kgold =int($kgold/2);
		$ktotal++;
		$ekati++;
		$etotal++;
		$message7 = "st[$number]=\"$kunit���� �����Ͽ� ���� �������� �پ���.\"";
		$number++;
		if($in{"type"} ne "chanp_battle"){
			&MAP_LOG(" $kunit ���� $eunit ���� ���� �����ߴ�.");
			open(IN,"$ACCESS_POINT_LIST") or &ERR("������ �� �� �����ϴ�.");
			@A_POINT_DATA = <IN>;
			close(IN);
			$a_hit = 0;
			foreach(@A_POINT_DATA){
				($qcid,$qx,$qy,$qid)=split(/<>/);
				if($kid eq "$qcid"){$a_hit =1;last;}
			}
			if(!$a_hit){$qx = 8;$qy = 8;$qid = 2;}
			$kpos = $qid;
			@NEW_DATA=();
			unshift(@NEW_DATA,"$kid<>$qx<>$qy<>$kunit<>$kcon<>\n");
			open(OUT,">./charalog/map/$in{'id'}.cgi");
			print OUT @NEW_DATA;
			close(OUT);
			open(MOVE,"$MAP_MOVE_LIST") or &ERR('������ �� �� �����ϴ�.');
			@M_LIST=<MOVE>;close(MOVE);
			$hit=0;
			$i=0;
			foreach (@M_LIST){
				($m_id,$mx,$my,$munit,$mcon) = split(/<>/);
				if($m_id eq $kid){
					splice (@M_LIST,$i,1,"$kid<>$qx<>$qy<>$kunit<>$kcon<>\n");
					$hit = 1;
				}
				$i++;
			}
			if(!$hit){
				push(@M_LIST,"$kid<>$qx<>$qy<>$kunit<>$kcon<>\n");
			}
			open(MOVE,">$MAP_MOVE_LIST") or &ERR('������ �� �� �����ϴ�.');
			print MOVE @M_LIST;
			close(MOVE);
		}
	}elsif($flg){
		if($in{'type'} eq "chanp_battle"){
			$get_chanp_money = $lcount * $CHANP_MONEY + 10000;
			$kgold += $get_chanp_money;
			$s_mess = "<BR>è���� �¸��Ͽ� <font color=orange>$get_chanp_money G</font>�� �տ� �־���!";
		}else{
			&MAP_LOG(" $eunit ���� $kunit ���� ���� �����ߴ�.");
			open(IN,"$ACCESS_POINT_LIST") or &ERR("������ �� �� �����ϴ�.");
			@A_POINT_DATA = <IN>;
			close(IN);
			$a_hit = 0;
			foreach(@A_POINT_DATA){
				($qcid,$qx,$qy,$qid)=split(/<>/);
				if($eid eq "$qcid"){$a_hit =1;last;}
			}
			if(!$a_hit){$qx = 8;$qy = 8;$qid = 2;}
			$epos = $pid;
			@NEW_DATA=();
			unshift(@NEW_DATA,"$eid<>$qx<>$qy<>$eunit<>$econ<>\n");
			open(OUT,">./charalog/map/$eid.cgi");
			print OUT @NEW_DATA;
			close(OUT);
			open(MOVE,"$MAP_MOVE_LIST") or &ERR('������ �� �� �����ϴ�.');
			@M_LIST=<MOVE>;close(MOVE);
			$hit=0;
			$i=0;
			foreach (@M_LIST){
				($m_id,$mx,$my,$munit) = split(/<>/);
				if($m_id eq $eid){
					splice (@M_LIST,$i,1,"$eid<>$qx<>$qy<>$eunit<>$econ<>\n");
					$hit = 1;
				}
				$i++;
			}
			if(!$hit){
				push(@M_LIST,"$eid<>$qx<>$qy<>$eunit<>$econ<>\n");
			}
			open(MOVE,">$MAP_MOVE_LIST") or &ERR('������ �� �� �����ϴ�.');
			print MOVE @M_LIST;
			close(MOVE);
		}
		$egold = int($egold/2);
		$kgold+=$kgetgold;
		$ktotal++;
		$etotal++;
		$kati++;
		$message7 = "st[$number]=\"$kunit���� $kgetgold G�� �տ� �־���!<BR>$kget_ex�� ����ġ�� ȹ���ߴ�!$s_mess\"";
		$number++;
	}else{
		$kgold+=$kgetgold;
		$message7 = "st[$number]=\"$kunit���� $kgetgold G�� �տ� �־���!<BR>$kget_ex�� ����ġ�� ȹ���ߴ�!\"";
		$number++;
	}

	if($k_ex_fol >= $EX ){
		open(IN,"./charalog/chara_max/$in{'id'}.cgi");
		@C_MAX = <IN>;
		close(IN);
		($mx_hp,$mx_mp,$mx_str,$mx_vit,$mx_int,$mx_men,$mx_agi,$mx_flg) = split(/<>/,$C_MAX[0]);
		$no1 = int(rand(5));
		$no2 = int(rand(5));
		$no3 = int(rand(5));
		$com8 .= "$kname�� ������ �ö���!<BR>";
		$khpup=int(rand(20));
		$kmaxhp+=$khpup;
		if($kmaxhp > $mx_hp){$kmaxhp = $mx_hp;}
		$com8 .= "$kname�� HP�� $khpup �ö���!<BR>";
		$s_kint = int($kint/30);
		$kmpup=int(rand($s_kint));
		$kmaxmp+=$kmpup;
		if($kmaxmp > $mx_mp){$kmaxmp = $mx_mp;}
		$com8 .= "$kname�� MP�� $kmpup �ö���!<BR>";
		if($no1 eq "0" || $no2 eq "0" || $no3 eq "0"){
			$kstr +=1;
			if($kstr > $mx_str){$kstr = $mx_str;}
			$com8 .= "$kname�� ���� 1 �ö���!<BR>";
		}
		if($no1 eq "1" || $no2 eq "1" || $no3 eq "1"){
			$kvit +=1;
			if($kvit > $mx_vit){$kvit = $mx_vit;}
			$com8 .= "$kname�� �������� 1 �ö���!<BR>";
		}
		if($no1 eq "2" || $no2 eq "2" || $no3 eq "2"){
			$kint +=1;
			if($kint > $mx_int){$kint = $mx_int;}
			$com8 .= "$kname�� ������ 1 �ö���!<BR>";
		}
		if($no1 eq "3" || $no2 eq "3" || $no3 eq "3"){
			$kmen +=1;
			if($kmen > $mx_men){$kmen = $mx_men;}
			$com8 .= "$kname�� ���ŷ��� 1 �ö���!<BR>";
		}
		if($no1 eq "4" || $no2 eq "4" || $no3 eq "4"){
			$kagi +=1;
			if($kagi > $mx_agi){$kagi = $mx_agi;}
			$com8 .= "$kname�� ��ø���� 1 �ö���!<BR>";
		}
		$message8 = "st[$number]=\"$com8\"";
		$number++;
	}

	if($in{"type"} eq "chanp_battle"){
		$move_form = "<form action=$FILE_STATUS method=post><input type=hidden name=id value=$kid><input type=hidden name=pass value=$kpass><input type=hidden name=mode value=STATUS>";
		$message14 = "st[$number]=\"<input type=submit value=������ ���ư���>\"";
	}else{
		$move_form =  "<form action=$FILE_MAP method=post><input type=hidden name=id value=$kid><input type=hidden name=pass value=$kpass><input type=hidden name=mode value=MAP_MOVE>";
		$message14 = "st[$number]=\"<input type=submit value=���� �̵��Ѵ�>\"";
	}
	$number++;

	&CHARA_INPUT;
	&HEADER;
print <<"EOM";
<TABLE width=100% height=100% bgcolor=$TABLE_C>
  <TBODY>
    <TR>
      <TD bgcolor=$TD_C1 height=5> <font size=4><B> ���� - $kunit�� vs $eunit�� - ����</B></font>
      </TD>
    </TR>
    <TR>
      <TD bgcolor=$TD_C4>
      <TABLE width=100% border="0">
        <TBODY>
          <TR>
            <TD bgcolor=$TD_C1><img src="$IMG/$kchara.gif"></TD>
            <TD bgcolor=$TD_C2>$simg</TD>
            <TD bgcolor=$TD_C3>$timg</TD>
            <TD align=center width=100%>
<TABLE bgcolor=$TABLE_C>
  <TBODY>
    <TR>
      <TH bgcolor=$TD_C1 colspan="9"> ����  $kunit��  ����</TH>
    </TR>
    <TR>
      <TD bgcolor=$TD_C2>�̸�</TD>
      <Th bgcolor=$TD_C2 width=50>HP</Th>
      <Th bgcolor=$TD_C2 width=50>MP</Th>
      <TD bgcolor=$TD_C2>����</TD>
      <TD bgcolor=$TD_C2>��</TD>
      <TD bgcolor=$TD_C2>���ݷ�</TD>
      <TD bgcolor=$TD_C2>����</TD>
      <TD bgcolor=$TD_C2>����</TD>
      <TD bgcolor=$TD_C2>�ɷ�ġ</TD>
    </TR>
    <TR>
      <TD bgcolor=$TD_C3>$kname</TD>
      <TD bgcolor=$TD_C3>$s_khp/$kmaxhp<BR>$khpimg</TD>
      <TD bgcolor=$TD_C3>$s_kmp/$kmaxmp<BR>$kmpimg</TD>
      <TD bgcolor=$TD_C3>$karmname</TD>
      <TD bgcolor=$TD_C3>$kproname</TD>
      <TD bgcolor=$TD_C3>$kstr(+$karmdmg)</TD>
      <TD bgcolor=$TD_C3>$kvit(+$kprodmg)</TD>
      <TD bgcolor=$TD_C3>$SYOKU[$kclass]</TD>
      <TD bgcolor=$TD_C3>$kpoint</TD>
    </TR>$s_sstatus$t_sstatus
  </TBODY>
</TABLE>

</TD>
          </TR>
        </TBODY>
      </TABLE>
      </TD>
    </TR>
    <TR>
      <TD bgcolor=$TD_C4 width=100%>
      <TABLE width=100% bgcolor=$TABLE_C>
        <TBODY>
          <TR>
            <TD bgcolor=$TD_C2></TD>
$move_form
<SCRIPT LANGUAGE="JavaScript"><!---
var st = new Array();
st[0] =
"���� - $kunit�� vs $eunit�� - ����<BR><font size=3 color=blue>$kmes<BR><BR>$emes";
$message1
$message2
$message3
$message4
$message5
$message6
$message7
$message8
$message9
$message10
$message14
var typeStyle = "font-size:15px; line-height:16px; color:#000000; font-weight:bold;";
var typeSpeed = 1;
var tugi = "";
var loop = false;
var msgWait = 2;
_dom=(document.all?3:(document.getElementById?1:(document.layers?2:0)));
function writeTypeMsg(mes) {
    if (_dom == 1) {
        var div = document.getElementById("type");
        while(div.hasChildNodes()) div.removeChild(div.lastChild);
        var range=document.createRange();
        range.selectNodeContents(div);
        range.collapse(true);
        var cf=range.createContextualFragment(mes);
        div.appendChild(cf);
    }
    if (_dom == 2) {
        var div = document.layers["typeN4"].layers["type"];
        div.document.open();
        div.document.write(mes);
        div.document.close();
    }
    if (_dom == 3) document.all("type").innerHTML = mes;
}
charsuu=0;
if (("��".length) == 1) charsuu = 1;
else charsuu = 2;
cct = 0;
msgNo = 0;
mct = st[0].length;
function typing(){
    cct += charsuu;
    if (cct > mct) cct = mct;
    Typeout = '<SPAN style="' + typeStyle + '">'
           + st[msgNo].substring(0,cct).replace(/<BR>/g, '<BR>')
           + (cct < mct ? tugi : '')
           + '</SPAN>';
    writeTypeMsg(Typeout);
    if (cct < mct) setTimeout('typing()', typeSpeed);
    else {
        msgNo = (msgNo >= st.length-1) ? 0 : msgNo + 1;
        mct = st[msgNo].length; cct = 0;
        if (!(!loop && msgNo == 0)) setTimeout('typing()', msgWait);
    }
}
window.onload = typing;
// ---></script><TD bgcolor="#ffffff" WIDTH="600" HEIGHT="300" VALIGN="TOP"><ILAYER name="typeN4" width="700" height="300"> <DIV id="type" style="position:absolute; width:400px; height:300px; clip:rect(0px 400px 300px 0px);"></DIV></ILAYER></TD></form>
            <TD bgcolor=$TD_C3></TD>
          </TR>
        </TBODY>
      </TABLE>
      </TD>
    </TR>
    <TR>
      <TD bgcolor=$TD_C4>
      <TABLE width=100% border=0>
        <TBODY>
          <TR>
            <TD align=center width=100%>
<TABLE bgcolor=$TABLE_C>
  <TBODY>
    <TR>
      <TH bgcolor=$TD_C1 colspan="9">����  $eunit��  ����</TH>
    </TR>
    <TR>
      <TD bgcolor=$TD_C2>�̸�</TD>
      <Th bgcolor=$TD_C2 width=50>HP</Th>
      <Th bgcolor=$TD_C2 width=50>MP</Th>
      <TD bgcolor=$TD_C2>����</TD>
      <TD bgcolor=$TD_C2>��</TD>
      <TD bgcolor=$TD_C2>���ݷ�</TD>
      <TD bgcolor=$TD_C2>����</TD>
      <TD bgcolor=$TD_C2>����</TD>
      <TD bgcolor=$TD_C2>�ɷ�ġ</TD>
    </TR>
    <TR>
      <TD bgcolor=$TD_C3>$ename</TD>
      <TD bgcolor=$TD_C3>$s_ehp/$emaxhp<BR>$ehpimg</TD>
      <TD bgcolor=$TD_C3>$s_ehp/$emaxmp<BR>$empimg</TD>
      <TD bgcolor=$TD_C3>$earmname</TD>
      <TD bgcolor=$TD_C3>$eproname</TD>
      <TD bgcolor=$TD_C3>$estr(+$earmdmg)</TD>
      <TD bgcolor=$TD_C3>$evit(+$eprodmg)</TD>
      <TD bgcolor=$TD_C3>$SYOKU[$eclass]</TD>
      <TD bgcolor=$TD_C3>$epoint</TD>
    </TR>$es_sstatus$et_sstatus
  </TBODY>
</TABLE>
</TD>
            <TD bgcolor=$TD_C1><img src="$IMG/$echara.gif"></TD>
            <TD bgcolor=$TD_C2>$esimg</TD>
            <TD bgcolor=$TD_C3>$etimg</TD>
          </TR>
        </TBODY>
      </TABLE>
      </TD>
    </TR>
  </TBODY>
</TABLE>

EOM

	if($in{"type"} eq "chanp_battle" && $flg){
		@NEW_DATA=();
			unshift(@NEW_DATA,"\n");
			unshift(@NEW_DATA,"\n");
		unshift(@NEW_DATA,"$kid<>$kpass<>$kname<>$kurl<>$kchara<>$ksex<>$kmaxhp<>$kmaxhp<>$kmaxmp<>$kmaxmp<>$kele<>$kstr<>$kvit<>$kint<>$kmen<>$kagi<>$kcom<>$kgold<>$k_ex<>$kcex<>$kunit<>$kcon<>$karm<>$kpro<>$kacc<>$ksub1<>$ksub2<>$ktac<>$ksta<>$kpos<>$kmes<>$khost<>$kdate<>$ksyo<>$kclass<>$ktotal<>$kkati<>1<>$ename<>$eurl<>$eunit<>\n");
		open(OUT,">$CHANP_LIST") or &ERR('CHANP ���ο� ����Ÿ�� �� �� �����ϴ�.');
		print OUT @NEW_DATA;
		close(OUT);
	}elsif($in{"type"} eq "chanp_battle"){
		$lcount++;
		@NEW_DATA=();
			unshift(@NEW_DATA,"\n");
			unshift(@NEW_DATA,"\n");
		unshift(@NEW_DATA,"$eid<>$epass<>$ename<>$eurl<>$echara<>$esex<>$ehp<>$emaxhp<>$emp<>$emaxmp<>$eele<>$estr<>$evit<>$eint<>$emen<>$eagi<>$ecom<>$egold<>$e_ex<>$ecex<>$eunit<>$econ<>$earm<>$epro<>$eacc<>$esub1<>$esub2<>$etac<>$esta<>$epos<>$emes<>$host<>$date<>$esyo<>$eclass<>$etotal<>$ekati<>$lcount<>$kname<>$kurl<>$kunit<>\n");
		open(OUT,">$CHANP_LIST") or &ERR('CHANP ���ο� ����Ÿ�� �� �� �����ϴ�.');
		print OUT @NEW_DATA;
		close(OUT);
	}else{
		&ENEMY_INPUT;
	}
	&FOOTER;
	exit;

}
1;