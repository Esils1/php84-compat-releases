#!/usr/bin/perl

#################################################################
#   ������ ���ס�
#    �� ��ũ��Ʈ�� ���� ����Ʈ�Դϴ�. �� ��ũ��Ʈ�� ����ϴٰ�
#    �Ͼ �Ͽ� ���ؼ� �����ڴ� å���� ���� �ʽ��ϴ�.
#    ��ġ�� ���� ������ ����Ʈ �Խ������� ���ֽñ� �ٶ��ϴ�.
#    �̸����� ���� ����Ʈ�� ���� �ʽ��ϴ�.
#    �ѱ۹��� : midGetyAn (http://myan.xo.st/)
#################################################################

require './ini_file/index.ini';
require 'suport.pl';

if($MENTE) { &ERR2("�������Դϴ�. ����Ŀ� ������ �ּ���."); }
&DECODE;
&STATUS_PRINT2;

sub STATUS_PRINT2 {

	&SERVER_STOP;
	$chid = decrypt($in{'id'});

	open(IN,"./charalog/main/$chid.cgi") or &ERR2("������ �� �� �����ϴ�. err no :main_chara");
	@CN_DATA = <IN>;
	close(IN);
	($kid,$kpass,$kname,$kurl,$kchara,$ksex,$khp,$kmaxhp,$kmp,$kmaxmp,$kele,$kstr,$kvit,$kint,$kmen,$kagi,$kcom,$kgold,$k_ex,$kcex,$kunit,$kcon,$karm,$kpro,$kacc,$ksub1,$ksub2,$ktac,$ksta,$kpos,$kmes,$khost,$kdate,$ksyo,$kclass,$ktotal,$kkati) = split(/<>/,$CN_DATA[0]);
	$klv = int($k_ex/100)+1;

	open(IN,"$ARM_LIST") or &ERR('������ �� �� �����ϴ�.');
	@ARM_DATA = <IN>;
	close(IN);
	open(IN,"$PRO_LIST") or &ERR('������ �� �� �����ϴ�.');
	@PRO_DATA = <IN>;
	close(IN);
	open(IN,"$ACC_LIST") or &ERR('������ �� �� �����ϴ�.');
	@ACC_DATA = <IN>;
	close(IN);

	($karmname,$karmval,$karmdmg,$karmwei,$karmele,$karmsta,$karmclass,$karmtownid) = split(/<>/,$ARM_DATA[$karm]);
	if($karmsta eq "use"){
		open(IN,"./charalog/arm/$chid.cgi");
		@MY_ARM_DATA = <IN>;
		close(IN);
		($karmname,$karmval,$karmdmg,$karmwei,$karmele,$karmsta,$karmclass,$karmtownid) = split(/<>/,$MY_ARM_DATA[0]);
	}
	if($kele eq "$karmele" && $kele ne "0"){$karmdmg = int($karmdmg*1.5);}

	($kproname,$kproval,$kprodmg,$kprowei,$kproele,$kprosta,$kproclass,$kprotownid) = split(/<>/,$PRO_DATA[$kpro]);
	if($kele eq "$kproele" && $kele ne "0"){$kprodmg = int($kprodmg*1.5);}
	($kaccname,$kaccval,$kaccdmg,$kaccwei,$kaccele,$kaccsta,$kaccclass,$kacctownid) = split(/<>/,$ACC_DATA[$kacc]);
	if($kele eq "$kaccele" && $kele ne "0"){$kaccdmg = int($kaccdmg*1.5);}

	open(IN,"$BOSS_DOWN_LIST");
	@D_BODD_DATA = <IN>;
	close(IN);
	$b_hit=0;
	foreach(@D_BODD_DATA){
		($b_id,$b_get_clistal)=split(/<>/);
		if("$kid" eq "$b_id"){$b_hit=1;last;}
	}
	if(!$b_hit){$b_get_clistal=0;}

	$bi = 0;
	foreach(@CLISTAL){
		$s_num = 2 ** $bi;
		if($b_get_clistal & $s_num){$clistal_mes .= "$CLISTAL[$bi] ";}
		$bi++;
	}

	open(IN,"$TEC_DATA") or &ERR2('������ �� �� �����ϴ�.');
	@TEC = <IN>;
	close(IN);
	foreach(@TEC){
		($tec_no,$tec_name,$tec_str,$tec_hit,$tec_sta,$tec_cho,$tec_class) = split(/<>/);
		if( $tec_no eq "$ktac"){
			$k_tec_mes .= "$tec_name(����: $tec_str Ȯ��: $tec_hit)";
		}
	}

	open(IN,"$TOWN_LIST") or &ERR("������ �� �� �����ϴ�.");
	@TOWN_DATA = <IN>;
	close(IN);
	foreach(@TOWN_DATA){
		($zcid,$zname,$zele,$zcon,$zmoney,$zmes,$zx,$zy)=split(/<>/);
		if("$zcid" eq "$kpos"){last;}
	}

	open(IN,"$COUNTRY_LIST") or &ERR2("������ �� �� �����ϴ�.");
	@COU = <IN>;
	close(IN);

	$count = 0;$hit=0;
	foreach(@COU){
		($xxcid,$xxname,$xxele,$xxnum,$xxins,$xxind,$xxall,$xxgold,$xxhp,$xxmaxhp,$xxstr,$xxvit,$xxagi)=split(/<>/);
		$con_name[$count] = "$xxname";
		if($xxcid eq $kcon){
			$hit=1;
			($xcid,$xname,$xele,$xnum,$xins,$xind,$xall,$xgold,$xhp,$xmaxhp,$xstr,$xvit,$xagi)=split(/<>/)
		}
		if($xxcid eq $zcon){
			($t_xcid,$t_xname,$t_xele,$t_xnum,$t_xins,$t_xind,$t_xall,$t_xgold,$t_xhp,$t_xmaxhp,$t_xstr,$t_xvit,$t_xagi)=split(/<>/)
		}
	}
	if(!$hit){$xname="���Ҽ�";}

	$t_xkoku = int(($t_xmaxhp)/100+$t_xstr+$t_xvit+$t_xagi)/10+$t_xnum;
	$xkoku = int(($xmaxhp)/100+$xstr+$xvit+$xagi)/10+$xnum;

	if($xins eq ""){$s_xins = "Ư�� ����";}
	if(!@m_list){@m_list = 'No PLAYER'; $num = 0;}
	$num = @m_list;
	$sb_member = "PLAYER ($num��) : @m_list";

	&TIME_DATA;
	if($hour < 6){$town_img = 3;
	}elsif($hour > 20){$town_img = 2;
	}elsif($hour > 17){$town_img = 1;
	}else{$town_img = 0;}

	$i = 0;
	foreach(@SYOKU){
		$s_syoku = 2 ** $i;
		if($ksyo & $s_syoku){
			$k_master_class .= "��$SYOKU[$i]��";
		}
		if($i > 30){last;}
		$i++;
	}


	if($ksex){$sk_sex = "��";}else{$sk_sex = "��";}
	if($kcom>127) { $com_name = "�ż�"; } else { $com_name = "ī����"; }
	&HEADER;

print <<"EOM";
<CENTER>
<TABLE border="0">
  <TBODY>
    <TR>
      <TD>
      <TABLE bgcolor=$TABLE_C border="0" align="center" width="100%">
        <TBODY>
          <TR>
            <TD bgcolor=$TD_C1 align="center" colspan="5">�̸� : <font size=4><B> $kname </B></font>($sk_sex)</TD>
          </TR>
          <TR>
            <TD align="center" bgcolor=$TD_C4 width="89">Lv $klv</TD>
            <TD colspan="4" align="center" width="243" bgcolor=$TD_C2>�Ҽ� : <B><font size=3 color="navy">$xname��</font></B>($kunit ��)</TD>
          </TR>
          <TR>
            <TD align="center" valign="middle" rowspan="6" bgcolor=$TD_C1><img src="$IMG/$kchara.gif" width="$img_wid" height="$img_height" border=0>
            </TD>
            <td align="center" bgcolor=$TD_C2>HP</td>
            <td align=center bgcolor=$TD_C3>$khp/$kmaxhp</td>
            <TD align="center" bgcolor=$TD_C2>MP</TD>
            <TD align=center bgcolor=$TD_C3>$kmp/$kmaxmp</TD>
          </TR>
          <TR>
            <td align="center" bgcolor=$TD_C2>���</td>
            <td colspan=3 align="center" bgcolor=$TD_C4>$k_tec_mes</td>
          </TR>
          <TR>
            <TD bgcolor=$TD_C2 align="center">��</TD>
            <TD bgcolor=$TD_C3 align="center">$kstr</TD>
            <TD bgcolor=$TD_C2 align="center">������</TD>
            <TD bgcolor=$TD_C3 align="center">$kvit</TD>
          </TR>
          <TR>
            <TD bgcolor=$TD_C2 align="center">����</TD>
            <TD bgcolor=$TD_C3 align="center">$kint</TD>
            <TD bgcolor=$TD_C2 align="center">���ŷ�</TD>
            <TD bgcolor=$TD_C3 align="center">$kmen</TD>
          </TR>
          <TR>
            <TD bgcolor=$TD_C2 align="center">��ø��</TD>
            <TD bgcolor=$TD_C3 align="center">$kagi</TD>
            <TD bgcolor=$TD_C2 align="center">����</TD>
            <TD bgcolor=$TD_C3 align="center">$com_name</TD>
          </TR>
          <TR>
            <TD bgcolor=$TD_C2 align="center">�Ӽ�</TD>
            <TD bgcolor=$TD_C3 align="center">$ELE[$kele]</TD>
            <TD bgcolor=$TD_C2 align="center">���� ��ġ</TD>
            <TD bgcolor=$TD_C3 align="center">$zname</TD>
          </TR>
          <TR>
            <TD bgcolor=$TD_C1 align="center">$ktotal �� $kkati ��</TD>
            <TD bgcolor=$TD_C2 align="center">����ġ</TD>
            <TD bgcolor=$TD_C3 align="center">$k_ex</TD>
            <TD bgcolor=$TD_C2 align="center">��</TD>
            <TD bgcolor=$TD_C3 align="center">$kgold G</TD>
          </TR>
          <TR>
            <TD align="center" bgcolor=$TD_C4> &nbsp;</TD>
            <TD bgcolor=$TD_C4 colspan="2" align="center">�̸�</TD>
            <TD bgcolor=$TD_C4 align="center">����</TD>
            <TD bgcolor=$TD_C4 align="center">����</TD>
          </TR>
          <TR>
            <TD align="center" bgcolor=$TD_C1>����</TD>
            <TD align=right bgcolor=$TD_C1 colspan="2">$karmname($ELE[$karmele])</TD>
            <TD align=right bgcolor=$TD_C1>$karmdmg</TD>
            <TD align=right bgcolor=$TD_C1>$karmwei</TD>
          </TR>
          <TR>
            <TD align="center" bgcolor=$TD_C2>��</TD>
            <TD align=right bgcolor=$TD_C2 colspan="2">$kproname($ELE[$kproele])</TD>
            <TD align=right bgcolor=$TD_C2>$kprodmg</TD>
            <TD align=right bgcolor=$TD_C2>$kprowei</TD>
          </TR>
          <TR>
            <TD align="center" bgcolor=$TD_C3>�Ǽ��縮</TD>
            <TD align=right bgcolor=$TD_C3 colspan="2">$kaccname($ELE[$kaccele])</TD>
            <TD align=right bgcolor=$TD_C3>$kaccdmg</TD>
            <TD align=right bgcolor=$TD_C3>$kaccwei</TD>
          </TR>
          <TR>
            <TD align=center bgcolor=$TD_C1 colspan="5">���� : <font color=orange size=3><B>$SYOKU[$kclass]</B></font></TD>
          </TR>
          <TR>
            <TD colspan="5" bgcolor=$TD_C4>�������� ���� : <font color="#FF9998"><B>$k_master_class</B></font></TD>
          </TR>
		<TR><TD colspan="5" bgcolor=$TD_C3><font size=1>ũ����Ż : <font color=$ELE_BG[$t_xele]>$clistal_mes</font></TD></TR>
        </TBODY>
      </TABLE>
      </TD>
    
    <TR>
  </TBODY>
</table>
<p></p>
</CENTER>

EOM
	&FOOTER;
	exit;
}

#----------------#
#  ��ȣ ���� ó��  #
#----------------#
sub decrypt {
	local($inpw) = @_;
	$encrypt = reverse($inpw);
	@dec = split(/\,/,"$encrypt");
	$inpw = pack("C*", @dec);
	
	return $inpw;
}
