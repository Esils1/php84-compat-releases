#_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/#
#_/       ������ ���       _/#
#_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/#

sub USE_ITEM {

	&CHARA_OPEN;
	&CHARA_ITEM_OPEN;

	&HEADER;

	print <<"EOM";
<TABLE WIDTH="100%" height=100% bgcolor=$TABLE_C><TBODY><TR><TD BGCOLOR=$TD_C1 WIDTH=100% height=5> <font size=4>������||| <B>������ ��롤���</B>|||������</font> $arm_mes</TD></TR><TR><TD bgcolor=$TD_C4 height=5><TABLE border="0"><TBODY><TR><TD bgcolor=$TD_C1><img src="$IMG/$kchara.gif"></TD><TD bgcolor=$TD_C4 WIDTH=35% align=center><TABLE bgcolor=$TABLE_C border="0"><TBODY><TR><TD bgcolor=$TD_C2>�̸�</TD><TD bgcolor=$TD_C3>LV</TD><form action="$FILE_MYDATA" method="post">
<TD bgcolor=$TD_C2>HP</TD><TD bgcolor=$TD_C3>MP</TD><TD bgcolor=$TD_C2>�Ӽ�</TD><TD bgcolor=$TD_C3>����</TD></TR>
<TR><input type=hidden name=chara value=1><TD bgcolor=$TD_C2>$kname</TD><TD bgcolor=$TD_C3 align=right>$klv</TD><TD bgcolor=$TD_C2>$khp/$kmaxhp</TD><TD bgcolor=$TD_C3>$kmp/$kmaxmp</TD><TD bgcolor=$TD_C2>$ELE[$kele]</TD><TD bgcolor=$TD_C3>$SYOKU[$kclass]</TD></TR>$sstatus$tstatus<TR><TD bgcolor=$TD_C2>������</TD><TD bgcolor=$TD_C1 colspan=5 align=right>$kgold GOLD</TD></TR></TBODY></TABLE></TD>

<TD bgcolor=$TD_C4 WIDTH=100% align=center><TABLE bgcolor=$TABLE_C border="0"><TBODY bgcolor=$TD_C4><TR><Th bgcolor=$TD_C1>����</Th><Th bgcolor=$TD_C3>���</Th><Th bgcolor=$TD_C2>���� ������</Th>
<Th bgcolor=$TD_C3>����</Th><Th bgcolor=$TD_C2>ȿ��</Th><Th bgcolor=$TD_C3>����</Th><Th bgcolor=$TD_C3>����</Th></TR>
EOM
	open(IN,"./charalog/item/$in{'id'}.cgi");
	@C_ITEM = <IN>;close(IN);$i=0;
	foreach(@C_ITEM){($it_mark,$it_no,$it_name,$it_val,$it_dmg,$it_sta,$it_wei) = split(/<>/);
		if($it_mark eq 3 && $it_no eq 0 || $it_mark eq 3 && $it_no eq 1){$it_val=1;}
		if($it_sta eq "11"){
			$star = "��";
		}else{
			$star = "";
		}
		print "<TR><TD bgcolor=$TD_C1><input type=radio name=select value=$i></TD><TH bgcolor=$TD_C3>$star</TH><TD bgcolor=$TD_C2>$it_name</TD><TD bgcolor=$TD_C3>$ITEM_NO[$it_mark]</TD><TD align=right bgcolor=$TD_C2>$it_dmg</TD><TD align=right bgcolor=$TD_C3>$it_wei</TD><TD align=right bgcolor=$TD_C3>$it_val</TD></TR>";$i++;}

	print <<"EOM";
<TR><TD colspan=7><input type=hidden name=id value=$kid><input type=hidden name=pass value=$kpass><input type=hidden name=mode value=USE><input type=submit value="���"></TR></TD></TBODY></TABLE></TD></TR></TBODY></TABLE></TD></TR></form><TR><TD bgcolor=$TD_C4 height="5">


<TABLE bgcolor=$TABLE_C border="0"><TBODY><TR><TD bgcolor=$TD_C1>�̸�</TD><TD bgcolor=$TD_C2>����</TD><TD bgcolor=$TD_C3>�ı���/����/�ִ� ������</TD><TD bgcolor=$TD_C2>��</TD><TD bgcolor=$TD_C3>����/����/�ִ� ������</TD><TD bgcolor=$TD_C2>�Ǽ��縮</TD><TD bgcolor=$TD_C3>����/����/�ִ� ������</TD></TR>
<TR><TD bgcolor=$TD_C1>$kname</TD><TD bgcolor=$ELE_BG[$karmele] align=right><font color=$ELE_C[$karmele]>$karmname</TD><TD bgcolor=$TD_C3 align=right>$karmdmg/$karmwei/$karmval</TD><TD bgcolor=$ELE_BG[$kproele]><font color=$ELE_C[$kproele]>$kproname</font></TD><TD bgcolor=$TD_C3 align=right>$kprodmg/$kprowei/$kproval</TD><TD bgcolor=$ELE_BG[$kaccele]><font color=$ELE_C[$kaccele]>$kaccname</font></TD><TD bgcolor=$TD_C3 align=right>$kaccdmg/$kaccwei/$kaccval</TD></TR>$sitem$titem
</TBODY></TABLE>


<form action="$FILE_STATUS" method="post"><input type=hidden name=id value=$kid><input type=hidden name=pass value=$kpass><input type=hidden name=mode value=STATUS><input type=submit value="���� ȭ������"></form></TD></TR></TBODY></TABLE>
EOM

	&FOOTER;
	exit;
}
1;