sub STATUS_PRINT {

	&CHARA_OPEN;
	&CHARA_ITEM_OPEN;
	open(IN,"$BOSS_DOWN_LIST");
	@D_BODD_DATA = <IN>;
	close(IN);
	$b_hit=0;
	foreach(@D_BODD_DATA){
		($b_id,$b_get_clistal)=split(/<>/);
		if("$kid" eq "$b_id"){$b_hit=1;last;}
	}
	if(!$b_hit){$b_get_clistal=0;}

	$bi = 0;
	foreach(@CLISTAL){
		$s_num = 2 ** $bi;
		if($b_get_clistal & $s_num){$clistal_mes .= "$CLISTAL[$bi] ";}
		$bi++;
	}

	open(IN,"$TEC_DATA") or &ERR('���� �б� ����');
	@TEC = <IN>;
	close(IN);
	foreach(@TEC){
		($tec_no,$tec_name,$tec_str,$tec_hit,$tec_sta,$tec_cho,$tec_class) = split(/<>/);
		if( $tec_no eq "$ktac"){
			$k_tec_mes .= "$tec_name(����: $tec_str Ȯ��: $tec_hit)";
		}
	}

	open(IN,"$TOWN_LIST") or &ERR("���� �б� ����");
	@TOWN_DATA = <IN>;
	close(IN);
	foreach(@TOWN_DATA){
		($zcid,$zname,$zele,$zcon,$zmoney,$zmes,$zx,$zy)=split(/<>/);
		if("$zcid" eq "$kpos"){last;}
	}

	open(IN,"$COUNTRY_LIST") or &ERR("���� �б� ����");
	@COU = <IN>;
	close(IN);

	$count = 0;$hit=0;
	foreach(@COU){
		($xxcid,$xxname,$xxele,$xxnum,$xxins,$xxind,$xxall,$xxgold,$xxhp,$xxmaxhp,$xxstr,$xxvit,$xxagi)=split(/<>/);
		$con_name[$count] = "$xxname";
		if($xxcid eq $kcon){
			$hit=1;
			($xcid,$xname,$xele,$xnum,$xins,$xind,$xall,$xgold,$xhp,$xmaxhp,$xstr,$xvit,$xagi)=split(/<>/)
		}
		if($xxcid eq $zcon){
			($t_xcid,$t_xname,$t_xele,$t_xnum,$t_xins,$t_xind,$t_xall,$t_xgold,$t_xhp,$t_xmaxhp,$t_xstr,$t_xvit,$t_xagi)=split(/<>/)
		}
	}
	if(!$hit){$xname="���Ҽ�";}

	$t_xkoku = int(($t_xmaxhp)/100+$t_xstr+$t_xvit+$t_xagi)/10+$t_xnum;
	$xkoku = int(($xmaxhp)/100+$xstr+$xvit+$xagi)/10+$xnum;

	if($xins eq ""){$s_xins = "����";}
	if(!@m_list){@m_list = 'No PLAYER'; $num = 0;}
	$num = @m_list;
	$sb_member = "PLAYER ($num��): @m_list";

	&TIME_DATA;
	if($hour < 6){$town_img = 3;
	}elsif($hour > 20){$town_img = 2;
	}elsif($hour > 17){$town_img = 1;
	}else{$town_img = 0;}

	$i = 0;
	foreach(@SYOKU){
		$s_syoku = 2 ** $i;
		if($ksyo & $s_syoku){
			$k_master_class .= "��$SYOKU[$i]��";
		}
		# bit�� �Ѱ�
		if($i > 30){last;}
		$i++;
	}

	open(IN,"./charalog/item/$in{'id'}.cgi");
	@K_ITEM = <IN>;
	close(IN);
	foreach(@K_ITEM){
		($k_mark,$k_no,$k_name,$k_val,$k_dmg,$k_sta,$k_wei) = split(/<>/);
		if($k_sta eq "11"){
			if($k_mark eq 0){
				$karmtai = $k_val;
			}elsif($k_mark eq 1){
				$kprotai = $k_val;
			}elsif($k_mark eq 2){
				$kacctai = $k_val;
			}
		}
	}

	if($ksex){$sk_sex = "��";}else{$sk_sex = "��";}
	if($kcom>127) { $com_name = "�ż�"; } else { $com_name = "ī����"; }
	&HEADER;

print <<"EOM";
<CENTER>
<TABLE border="0" width="450">
  <TBODY>
    <TR>
      <TD>
      <TABLE bgcolor=$TABLE_C border="0" align="center" width="100%">
        <TBODY>
          <TR>
            <TD bgcolor=$TD_C1 align="center" colspan="5">�̸�: <font size=4><B> $kname </B></font>($sk_sex)</TD>
          </TR>
          <TR>
            <TD align="center" bgcolor=$TD_C4 width="89">LV $klv</TD>
            <TD colspan="4" align="center" width="243" bgcolor=$TD_C2>�Ҽ�: <B><font size=3 color="navy">$xname��</font></B>($kunit ��)</TD>
          </TR>
          <TR>
            <TD align="center" valign="middle" rowspan="6" bgcolor=$TD_C1><img src="$IMG/$kchara.gif" width="$img_wid" height="$img_height" border=0>
            </TD>
            <td align="center" bgcolor=$TD_C2>HP</td>
            <td align=center bgcolor=$TD_C3>$khp/$kmaxhp</td>
            <TD align="center" bgcolor=$TD_C2>MP</TD>
            <TD align=center bgcolor=$TD_C3>$kmp/$kmaxmp</TD>
          </TR>
          <TR>
            <td align="center" bgcolor=$TD_C2>���</td>
            <td colspan=3 align="center" bgcolor=$TD_C4>$k_tec_mes</td>
          </TR>
          <TR>
            <TD bgcolor=$TD_C2 align="center">��</TD>
            <TD bgcolor=$TD_C3 align="center">$kstr</TD>
            <TD bgcolor=$TD_C2 align="center">������</TD>
            <TD bgcolor=$TD_C3 align="center">$kvit</TD>
          </TR>
          <TR>
            <TD bgcolor=$TD_C2 align="center">����</TD>
            <TD bgcolor=$TD_C3 align="center">$kint</TD>
            <TD bgcolor=$TD_C2 align="center">���ŷ�</TD>
            <TD bgcolor=$TD_C3 align="center">$kmen</TD>
          </TR>
          <TR>
            <TD bgcolor=$TD_C2 align="center">��ø��</TD>
            <TD bgcolor=$TD_C3 align="center">$kagi</TD>
            <TD bgcolor=$TD_C2 align="center">����</TD>
            <TD bgcolor=$TD_C3 align="center">$com_name</TD>
          </TR>
          <TR>
            <TD bgcolor=$TD_C2 align="center">�Ӽ�</TD>
            <TD bgcolor=$TD_C3 align="center">$ELE[$kele]</TD>
            <TD bgcolor=$TD_C2 align="center">���� ��ġ</TD>
            <TD bgcolor=$TD_C3 align="center">$zname</TD>
          </TR>
          <TR>
            <TD bgcolor=$TD_C1 align="center">$ktotal �� $kkati ��</TD>
            <TD bgcolor=$TD_C2 align="center">����ġ</TD>
            <TD bgcolor=$TD_C3 align="center">$k_ex</TD>
            <TD bgcolor=$TD_C2 align="center">��</TD>
            <TD bgcolor=$TD_C3 align="center">$kgold G</TD>
          </TR>
          <TR>
            <TD align="center" bgcolor=$TD_C4>&nbsp;</TD>
            <TD bgcolor=$TD_C4 colspan="2" align="center">�̸�</TD>
            <TD bgcolor=$TD_C4 align="center">����(����)</TD>
            <TD bgcolor=$TD_C4 align="center">����/�ִ�</TD>
          </TR>
          <TR>
            <TD align="center" bgcolor=$TD_C1>����</TD>
            <TH bgcolor=$ELE_C[$karmele] colspan="2">$karmname</TH>
            <TD align=right bgcolor=$TD_C1>$karmdmg($karmwei)</TD>
            <TD align=right bgcolor=$TD_C1>$karmtai/$karmval</TD>
          </TR>
          <TR>
            <TD align="center" bgcolor=$TD_C2>��</TD>
            <TH bgcolor=$ELE_C[$kproele] colspan="2">$kproname</TH>
            <TD align=right bgcolor=$TD_C2>$kprodmg($kprowei)</TD>
            <TD align=right bgcolor=$TD_C2>$kprotai/$kproval</TD>
          </TR>
          <TR>
            <TD align="center" bgcolor=$TD_C3>�Ǽ��縮</TD>
            <TH bgcolor=$ELE_C[$kaccele] colspan="2">$kaccname</TH>
            <TD align=right bgcolor=$TD_C3>$kaccdmg($kaccwei)</TD>
            <TD align=right bgcolor=$TD_C3>$kacctai/$kaccval</TD>
          </TR>
          <TR>
            <TD align=center bgcolor=$TD_C1 colspan="5">����: <font color=orange size=3><B>$SYOKU[$kclass]</B></font></TD>
          </TR>
          <TR>
            <TD colspan="5" bgcolor=$TD_C4>�������� ����: <font color="#FF9998"><B>$k_master_class</B></font></TD>
          </TR>
		<TR><TD colspan="5" bgcolor=$TD_C3><font size=1>ũ����Ż: <font color=$ELE_BG[$t_xele]>$clistal_mes</font></TD></TR>
        </TBODY>
      </TABLE>
      </TD>
    
    <TR>
  </TBODY>
</table>
<p></p>
<TABLE>
  <TBODY>
    <TR>
      <TD>
$sstatus
<p></p>
      </TD>
    </TR>

    <TR>
      <TD>
$tstatus
      </TD>
    </TR>
  </TBODY>
</TABLE>
<form action="$FILE_STATUS" method="post">
<input type=hidden name=id value=$kid>
<input type=hidden name=pass value=$kpass>
<input type=hidden name=mode value=STATUS>
<input type=submit value="������ ���ư���"></form>
</CENTER>

EOM
	&FOOTER;
	exit;
}
1;