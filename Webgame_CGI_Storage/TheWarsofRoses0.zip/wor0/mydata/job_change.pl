#_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/#
#_/          �� ��          _/#
#_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/#

sub JOB_CHANGE {

	if($in{'chara'} eq ""){&ERR('������ ĳ���Ͱ� ���õ��� �ʾҽ��ϴ�.');}
	if($in{'syoku_no'} eq ""){&ERR('������ ������ ���õ��� �ʾҽ��ϴ�.');}
	&CHARA_OPEN;

	$s_c = $in{'chara'};
	$s_s = $in{'syoku_no'};

	open(IN,"$CLASS_DATA");
	@CLASS_DATA=<IN>;
	close(IN);

	if($s_s eq "1"){
		$armup = 40;
		$vitup = 20;
		$intup = 0;
		$menup = 30;
		$agiup = 0;
	}elsif($s_s eq "2"){
		$armup = 30;
		$vitup = 0;
		$intup = 80;
		$menup = 60;
		$agiup = 0;
	}elsif($s_s eq "3"){
		$armup = 140;
		$vitup = 140;
		$intup = -40;
		$menup = -80;
		$agiup = -50;
	}elsif($s_s eq "4"){
		$armup = 120;
		$vitup = 80;
		$intup = 20;
		$menup = 60;
		$agiup = 20;
	}elsif($s_s eq "5"){
		$armup = 100;
		$vitup = 80;
		$intup = -10;
		$menup = 60;
		$agiup = 50;
	}elsif($s_s eq "6"){
		$armup = 60;
		$vitup = 120;
		$intup = 120;
		$menup = 80;
		$agiup = 20;
	}elsif($s_s eq "7"){
		$armup = 80;
		$vitup = 80;
		$intup = 60;
		$menup = 60;
		$agiup = 60;
	}elsif($s_s eq "8"){
		$armup = 100;
		$vitup = 100;
		$intup = 10;
		$menup = 50;
		$agiup = 80;
	}elsif($s_s eq "9"){
		$armup = 140;
		$vitup = 100;
		$intup = 10;
		$menup = 100;
		$agiup = 60;
	}elsif($s_s eq "10"){
		$armup = 140;
		$vitup = 100;
		$intup = 140;
		$menup = 100;
		$agiup = 100;
	}elsif($s_s eq "11"){
		$armup = 40;
		$vitup = 10;
		$intup = 0;
		$menup = 0;
		$agiup = 40;
	}elsif($s_s eq "12"){
		$armup = 60;
		$vitup = 20;
		$intup = 20;
		$menup = 60;
		$agiup = 60;
	}elsif($s_s eq "13"){
		$armup = 120;
		$vitup = 120;
		$intup = 0;
		$menup = 0;
		$agiup = 0;
	}elsif($s_s eq "14"){
		$armup = 100;
		$vitup = 80;
		$intup = -20;
		$menup = -20;
		$agiup = 100;
	}elsif($s_s eq "15"){
		$armup = 40;
		$vitup = 50;
		$intup = 0;
		$menup = 0;
		$agiup = 0;
	}elsif($s_s eq "16"){
		$armup = 100;
		$vitup = 100;
		$intup = -10;
		$menup = 60;
		$agiup = 40;
	}elsif($s_s eq "17"){
		$armup = 125;
		$vitup = 140;
		$intup = -30;
		$menup = 100;
		$agiup = 60;
	}elsif($s_s eq "18"){
		$armup = 0;
		$vitup = 0;
		$intup = 50;
		$menup = 40;
		$agiup = 0;
	}elsif($s_s eq "19"){
		$armup = 20;
		$vitup = -20;
		$intup = 140;
		$menup = 100;
		$agiup = 40;
	}elsif($s_s eq "20"){
		$armup = -20;
		$vitup = 80;
		$intup = 100;
		$menup = 100;
		$agiup = -20;
	}elsif($s_s eq "21"){
		$armup = 60;
		$vitup = 60;
		$intup = 120;
		$menup = 100;
		$agiup = 60;
	}elsif($s_s eq "22"){
		$armup = 0;
		$vitup = 40;
		$intup = 50;
		$menup = 0;
		$agiup = 0;
	}elsif($s_s eq "23"){
		$armup = 40;
		$vitup = 60;
		$intup = 80;
		$menup = 60;
		$agiup = 20;
	}elsif($s_s eq "24"){
		$armup = 60;
		$vitup = 100;
		$intup = 100;
		$menup = 60;
		$agiup = 20;
	}elsif($s_s eq "25"){
		$armup = 20;
		$vitup = 0;
		$intup = 0;
		$menup = 40;
		$agiup = 40;
	}elsif($s_s eq "26"){
		$armup = 100;
		$vitup = 0;
		$intup = 0;
		$menup = 80;
		$agiup = 100;
	}elsif($s_s eq "27"){
		$armup = 100;
		$vitup = 10;
		$intup = 20;
		$menup = 120;
		$agiup = 100;
	}elsif($s_s eq "28"){
		$armup = 50;
		$vitup = 0;
		$intup = 0;
		$menup = 0;
		$agiup = 50;
	}elsif($s_s eq "29"){
		$armup = 100;
		$vitup = 0;
		$intup = 60;
		$menup = 20;
		$agiup = 100;
	}elsif($s_s eq "30"){
		$armup = 100;
		$vitup = 0;
		$intup = 100;
		$menup = 0;
		$agiup = 140;
	}elsif($s_s eq "31"){
		$armup = 160;
		$vitup = 160;
		$intup = 160;
		$menup = 160;
		$agiup = 160;
	}elsif($s_s eq "32"){
		$armup = 50;
		$vitup = 50;
		$intup = 50;
		$menup = 50;
		$agiup = 50;
	}else{
		$armup = 0;
		$vitup = 0;
		$intup = 0;
		$menup = 0;
		$agiup = 0;
	}

	if($s_c eq "1"){
		($cl_str,$cl_vit,$cl_int,$cl_men,$cl_agi,$cl_ex,$cl_master) = split(/<>/,$CLASS_DATA[$s_s]);
		$s_no = int($cl_master);
		if (($kstr >= $cl_str && $kvit >= $cl_vit && $kint >= $cl_int && $kmen >= $cl_men && $kagi >= $cl_agi && $ksyo & $s_no && $k_ex > $MASTER_LV * 100) || ($ksyo >= 2147483647)|| ($ksyo eq 4294967295 && $k_ex > $MASTER_LV * 100)){
			$s_masterlv = $EX * $MASTER_LV;
			if($k_ex > $s_masterlv){
				$ksyo |= 2 ** $kclass;
				$ss_mes = "$kname���� <font color=red>$SYOKU[$kclass]</font>(��)�� �������߽��ϴ�.<p>";
			}
			$kclass = $s_s;
			$k_ex = 0;
			$kstr = int(rand($kstr)) + $armup;
			open(IN,"./charalog/chara_max/$in{'id'}.cgi");
			@C_MAX = <IN>;
			close(IN);
			($mx_hp,$mx_mp,$mx_str,$mx_vit,$mx_int,$mx_men,$mx_agi,$mx_flg) = split(/<>/,$C_MAX[0]);
			$mx_str2 = int($mx_str*0.8);
			$mx_vit2 = int($mx_vit*0.8);
			$mx_int2 = int($mx_int*0.8);
			$mx_men2 = int($mx_men*0.8);
			$mx_agi2 = int($mx_agi*0.8);
		if($kstr <10){$kstr = 10;}elsif($kstr > $mx_str2){$kstr = $mx_str2;}
		$kvit = int(rand($kvit)) + $vitup;
		if($kvit <10){$kvit = 10;}elsif($kvit > $mx_vit2){$kvit = $mx_vit2;}
		$kint = int(rand($kint)) + $intup;
		if($kint <10){$kint = 10;}elsif($kint > $mx_int2){$kint = $mx_int2;}
		$kmen = int(rand($kmen)) + $menup;
		if($kmen <10){$kmen = 10;}elsif($kmen > $mx_men2){$kmen = $mx_men2;}
		$kagi = int(rand($kagi)) + $agiup;
		if($kagi <10){$kagi = 10;}elsif($kagi > $mx_agi2){$kagi = $mx_agi2;}
			$ktec = 0;
			$kmaxhp = int(rand($kmaxhp));
			if($kmaxhp <50){$kmaxhp = 50;}
			$khp = $kmaxhp;
			$kmaxmp = int(rand($kmaxmp));
			if($kmaxmp <30){$kmaxmp = 30;}
			$kmp = $kmaxmp;
			$ss_mes .= "$kname���� <font color=red>$SYOKU[$s_s]</font>(��)�� �����߽��ϴ�.";
			$ktac=0;
		}else{&ERR('�� �������� ������ �� �����ϴ�.');}
	}

	&CHARA_INPUT;

	&HEADER;
	print <<"EOM";
<CENTER><hr size=0><h2>$ss_mes</h2><p>

<form action="$FILE_STATUS" method="post">
<input type=hidden name=id value=$kid>
<input type=hidden name=pass value=$kpass>
<input type=hidden name=mode value=STATUS>
<input type=submit value="������ ���ư���"></form>
EOM
	&FOOTER;
	exit;
	
}
1;