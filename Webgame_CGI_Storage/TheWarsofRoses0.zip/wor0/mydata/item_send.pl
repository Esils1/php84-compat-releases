#_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/#
#_/       ������ ���       _/#
#_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/#

sub ITEM_SEND {

	&CHARA_MAIN_OPEN;
	&CHARA_ITEM_OPEN;

	&HEADER;

	print <<"EOM";
<TABLE WIDTH="100%" height=100%><TBODY><TR><TD WIDTH=100% height=5>
<TABLE WIDTH="100%"><TBODY><TR><TD WIDTH=100% height=5> <font size=4> ������||| <B>������ ���</B>��|||������</font> $arm_mes</TD></TR><TR><TD height=5><TABLE border="0"><TBODY><TR><TD bgcolor=$TD_C1><img src="$IMG/$kchara.gif"></TD><TD WIDTH=35% align=center><TABLE bgcolor=$TABLE_C border="0"><TBODY><TR><TD bgcolor=$TD_C2>�̸�</TD><TD bgcolor=$TD_C3>LV</TD><form action="$FILE_MYDATA" method="post">
<TD bgcolor=$TD_C2>HP</TD><TD bgcolor=$TD_C3>MP</TD><TD bgcolor=$TD_C2>�Ӽ�</TD><TD bgcolor=$TD_C3>����</TD></TR>
<TR><TD bgcolor=$TD_C2>$kname</TD><TD bgcolor=$TD_C3 align=right>$klv</TD><TD bgcolor=$TD_C2>$khp/$kmaxhp</TD><TD bgcolor=$TD_C3>$kmp/$kmaxmp</TD><TD bgcolor=$TD_C2>$ELE[$kele]</TD><TD bgcolor=$TD_C3>$SYOKU[$kclass]</TD></TR>$sstatus$tstatus<TR><TD bgcolor=$TD_C2>������</TD><TD bgcolor=$TD_C1 colspan=5 align=right>$kgold G</TD></TR></TBODY></TABLE></TD>

<TD WIDTH=100% align=center><TABLE bgcolor=$TABLE_C border="0"><TBODY><TR><Th bgcolor=$TD_C1>����</Th><Th bgcolor=$TD_C2>���� ������</Th>
<Th bgcolor=$TD_C3>����</Th><Th bgcolor=$TD_C2>ȿ��</Th><Th bgcolor=$TD_C3>����</Th></TR>
EOM
	open(IN,"./charalog/item/$in{'id'}.cgi");
	@C_ITEM = <IN>;close(IN);$i=0;
	foreach(@C_ITEM){($it_mark,$it_no,$it_name,$it_val,$it_dmg,$it_sta,$it_wei) = split(/<>/);
		print "<TR><TD bgcolor=$TD_C1><input type=radio name=select value=$i></TD><TD bgcolor=$TD_C2>$it_name</TD><TD bgcolor=$TD_C3>$ITEM_NO[$it_mark]</TD><TD align=right bgcolor=$TD_C2>$it_dmg</TD><TD align=right bgcolor=$TD_C3>$it_wei</TD></TR>";$i++;}

	print <<"EOM";
<TR><TD colspan=3>

<select name=eid>
<option value="">���� ��� ����
EOM

	open(IN,"$CHARA_DATA_LIST") or &ERR('���� �б� ����');
	@S_CHARA = <IN>;
	close(IN);

	@tmp = map {(split /<>/)[19]} @S_CHARA;
	@S_CHARA = @S_CHARA[sort {$tmp[$b] <=> $tmp[$a]} 0 .. $#tmp];

	foreach(@S_CHARA) {
		($jid,$jpass,$jname,$jurl,$jchara,$jsex,$jhp,$jmaxhp,$jmp,$jmaxmp,$jele,$jstr,$jvit,$jint,$jmen,$jagi,$jcom,$jgold,$j_ex,$jcex,$junit,$jcon) = split(/<>/);
		if($jid eq $kid) { next; }
		$con[$jcon] .= "<option value=$jid>$jname�Կ���\n";
	}

	open(IN,"$COUNTRY_NO_LIST") or &ERR2('���� �б� ����err no :country');
	@COU_NO = <IN>;
	close(IN);
	$no_con = "$con[0]";
	foreach(@COU_NO){
		($xxcid,$xxname,$xxele,$xxnum,$xxins,$xxind,$xxall,$xxgold,$xxhp,$xxmaxhp,$xxstr,$xxvit,$xxagi,$xxat)=split(/<>/);
		if($xxat){
			print "<option>==== $xxname ====\n";
			print "$con[$xxcid]";
		}else{
			$no_con .= "$con[$xxcid]";
		}
	}
	$c_num = @COU_DATA;
print <<"EOM";
<option>==== ���Ҽӱ� ====\n
$no_con
</select>

<input type=hidden name=id value=$kid><input type=hidden name=pass value=$kpass><input type=hidden name=mode value=ITEM_SEND2><input type=submit value="������"></TR></TD></TBODY></TABLE></TD></TR></TBODY></TABLE></TD></TR></form><TR><TD height="5">


<TABLE bgcolor=$TABLE_C border="0"><TBODY><TR><TD bgcolor=$TD_C1>�̸�</TD><TD bgcolor=$TD_C2>����</TD><TD bgcolor=$TD_C3>�ı���/����</TD><TD bgcolor=$TD_C2>��</TD><TD bgcolor=$TD_C3>����/����</TD><TD bgcolor=$TD_C2>�Ǽ��縮</TD><TD bgcolor=$TD_C3>����/����</TD></TR>
<TR><TD bgcolor=$TD_C1>$kname</TD><TD bgcolor=$TD_C2 align=right>$karmname</TD><TD bgcolor=$TD_C3 align=right>$karmdmg/$karmwei</TD><TD bgcolor=$TD_C2>$kproname</TD><TD bgcolor=$TD_C3 align=right>$kprodmg/$kprowei</TD><TD bgcolor=$TD_C2>$kaccname</TD><TD bgcolor=$TD_C3 align=right>$kaccdmg/$kaccwei</TD></TR>
</TBODY></TABLE>


<form action="$FILE_STATUS" method="post"><input type=hidden name=id value=$kid><input type=hidden name=pass value=$kpass><input type=hidden name=mode value=STATUS><input type=submit value="���� ȭ������"></form></TD></TR></TBODY></TABLE>
</TD></TR></TBODY></TABLE>
EOM

	&FOOTER;
	exit;
}
1;