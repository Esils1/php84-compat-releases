#_/_/_/_/_/_/_/_/_/#
#_/    ��  ��    _/#
#_/_/_/_/_/_/_/_/_/#

sub MAX_RANK{

	&CHARA_OPEN;

	if($lockkey) { &F_LOCK; }

	if($C_DATA_MAKE){&ERR2("ĳ���� ����Ÿ�� �������Դϴ�. ��� ��ٷ��ּ���.")}
	$C_DATA_MAKE = 1;

	open(IN,"$CHARA_LANK_LIST");
	@CL_DATA = <IN>;
	close(IN);
	&HOST_NAME;

	$num = @CL_DATA-1;

	($bid,$bpass,$bname,$burl,$bchara,$bsex,$bhp,$bmaxhp,$bmp,$bmaxmp,$bele,$bstr,$bvit,$bint,$bmen,$bagi,$bcom,$bgold,$b_ex,$bcex,$bunit,$bcon,$barm,$bpro,$bacc,$bsub1,$bsub2,$btac,$bsta,$bpos,$bmes,$bhost,$bdate,$bsyo,$bclass,$btotal,$bkati,$lpoint) = split(/<>/,$CL_DATA[$num]);

	$kpoint=int(($kmaxhp+$kmaxmp)/3)+$kstr+$kvit+$kint+$kmen+$kagi;

	if($lpoint > $kpoint && $num > 8){
		&ERR("�ɷ�ġ�� �����մϴ�. (�ʿ� �ɷ�ġ $lpoint\point �̻�) ���� : $kpoint\n")
	}

	$date = time();$flg=0;$i=0;
	foreach(@CL_DATA) {
		($bid,$bpass,$bname,$burl,$bchara,$bsex,$bhp,$bmaxhp,$bmp,$bmaxmp,$bele,$bstr,$bvit,$bint,$bmen,$bagi,$bcom,$bgold,$b_ex,$bcex,$bunit,$bcon,$barm,$bpro,$bacc,$bsub1,$bsub2,$btac,$bsta,$bpos,$bmes,$bhost,$bdate,$bsyo,$bclass,$btotal,$bkati,$bpoint) = split(/<>/);

		if("$bid" eq "$in{'id'}"){
			splice(@CL_DATA,$i,1,"$kid<>$kpass<>$kname<>$kurl<>$kchara<>$ksex<>$khp<>$kmaxhp<>$kmp<>$kmaxmp<>$kele<>$kstr<>$kvit<>$kint<>$kmen<>$kagi<>$kcom<>$kgold<>$k_ex<>$kcex<>$kunit<>$kcon<>$karm<>$kpro<>$kacc<>$ksub1<>$ksub2<>$ktac<>$ksta<>$kpos<>$kmes<>$host<>$date<>$ksyo<>$kclass<>$ktotal<>$kkati<>$kpoint<>\n");
			$flg=1;
			$last;
		}
		$i++;
	}

	if(!$flg){
		unshift(@CL_DATA,"$kid<>$kpass<>$kname<>$kurl<>$kchara<>$ksex<>$khp<>$kmaxhp<>$kmp<>$kmaxmp<>$kele<>$kstr<>$kvit<>$kint<>$kmen<>$kagi<>$kcom<>$kgold<>$k_ex<>$kcex<>$kunit<>$kcon<>$karm<>$kpro<>$kacc<>$ksub1<>$ksub2<>$ktac<>$ksta<>$kpos<>$kmes<>$host<>$date<>$ksyo<>$kclass<>$ktotal<>$kkati<>$kpoint<>\n");
	}

	@tmp = map {(split /<>/)[37]} @CL_DATA;
	@CL_DATA = @CL_DATA[sort {$tmp[$b] <=> $tmp[$a]} 0 .. $#tmp];

	$num = @CL_DATA;
	if($num > 10) { pop(@CL_DATA); }


	open(OUT,">$CHARA_LANK_LIST") or &ERR('CHARA LANK ���ο� ����Ÿ�� �� �� �����ϴ�.');
	print OUT @CL_DATA;
	close(OUT);
	$C_DATA_MAKE = 0;
	if (-e $lockfile) { unlink($lockfile); }


	&HEADER;
	print <<"EOM";
<CENTER><hr size=0><font color=red><h2>������ �������� ��ϵƽ��ϴ�.</h2></font><p>

<form action="$FILE_STATUS" method="post">
<input type=hidden name=id value=$kid>
<input type=hidden name=pass value=$kpass>
<input type=hidden name=mode value=STATUS>
<input type=submit value="������ ���ư���"></form></CENTER>
EOM
	&FOOTER;
	exit;
	
}
1;