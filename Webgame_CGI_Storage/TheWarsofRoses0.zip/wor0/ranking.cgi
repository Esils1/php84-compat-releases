#!/usr/bin/perl

#################################################################
#   ������ ���ס�
#    �� ��ũ��Ʈ�� ���� ����Ʈ�Դϴ�. �� ��ũ��Ʈ�� ����ϴٰ�
#    �Ͼ �Ͽ� ���ؼ� �����ڴ� å���� ���� �ʽ��ϴ�.
#    ��ġ�� ���� ������ ����Ʈ �Խ������� ���ֽñ� �ٶ��ϴ�.
#    �̸����� ���� ����Ʈ�� ���� �ʽ��ϴ�.
#    �ѱ۹��� : midGetyAn (http://myan.xo.st/)
#################################################################

require './ini_file/index.ini';
require 'suport.pl';

if($MENTE) { &ERR2("�������Դϴ�. ����Ŀ� ������ �ּ���."); }
&DECODE;
if($ENV{'HTTP_REFERER'} !~ /i/ && $CHEACKER){ &ERR2("�������� ��η� ������ �ּ���."); }
if($mode eq 'C_RAN') { &C_RAN; }
else{&RANKING;}


#_/_/_/_/_/_/_/_/_/_/_/_/_/_/#
#      ������ ����Ʈ OPEN       #
#_/_/_/_/_/_/_/_/_/_/_/_/_/_/#

sub RANKING {

	&SERVER_STOP;

	open(IN,"$CHARA_DATA");
	@DL_DATA = <IN>;
	close(IN);

	open(IN,"$COUNTRY_LIST") or &ERR2('������ �� �� �����ϴ�.');
	@COU_DATA = <IN>;
	close(IN);
	$country_no=0;
	foreach(@COU_DATA){
		($xxcid,$xxname,$xxele,$xxnum,$xxins,$xxind,$xxall,$xxgold,$xxhp,$xxmaxhp,$xxstr,$xxvit,$xxagi)=split(/<>/);
		$country_name[$country_no]="$xxname";
		$c[$country_no]=0;
		$c_no[$country_no]=$xxcid;
		$c_king[$country_no]=$xxall;
		$country_no++;
	}

	open(IN,"$TOWN_LIST");
	@T_LIST = <IN>;
	close(IN);
	$town_c0=0;$town_c1=0;$town_c2=0;$town_c3=0;
	foreach(@T_LIST){
		($zcid,$zname,$zele,$zcon,$zmoney,$zmes)=split(/<>/);
		$TOWN_NAME[$zcid]="$zname";
		if($zname ne "���"){
			for($p=0;$p<$country_no;$p++){
				if($zcon eq "$c_no[$p]"){$town_c[$p]++;$mes[$p].="$zname ";}
			}
		}
	}

	$dir="./charalog/main";
	opendir(dirlist,"$dir");
	while($file = readdir(dirlist)){
		if($file =~ /\.cgi/i){
			if(!open(page,"$dir/$file")){
				&ERR("������ �� �� �����ϴ�.");
			}
			@page = <page>;
			close(page);
			push(@CL_DATA,"@page<br>");
		}
	}
	closedir(dirlist);

	@tmp = map {(split /<>/)[19]} @CL_DATA;
	@CL_DATA = @CL_DATA[sort {$tmp[$b] <=> $tmp[$a]} 0 .. $#tmp];
	$num = @CL_DATA;
	$i=0;
	$date = time;

	foreach(@CL_DATA) {
		($kid,$kpass,$kname,$kurl,$kchara,$ksex,$khp,$kmaxhp,$kmp,$kmaxmp,$kele,$kstr,$kvit,$kint,$kmen,$kagi,$kcom,$kgold,$k_ex,$kcex,$kunit,$kcon,$karm,$kpro,$kacc,$ksub1,$ksub2,$ktac,$ksta,$kpos,$kmes,$khost,$kdate,$ksyo,$kclass,$ktotal,$kkati) = split(/<>/);
		$klv = int($k_ex/100)+1;
		if($ksex){$_s="��";}else{$_s="��";}
		$s_num = int($kcex / $LANK_UP);
		if($s_num > 20){$s_num = 20;}

		$chit=0;
		for($j=0;$j<$country_no;$j++){
			if($kcon eq "$c_no[$j]"){
			$chit=1;
			if($kid eq "$c_king[$j]"){
				$c_k_name[$j] = $kname;
			}
			if($c[$j] <= 10 && $kcon ne 0){
			$ldate = int(($kdate + (3600 * 24 * 31) - $date)  / (3600 * 24));
			if($ldate <= 0 || ($ldate < 24 && $ktotal < 50)){
				$rm = "<font color=red>���� ���</font>";
			}else{
				$rm = "<font color=blue>$ldate</font>��";
			}
			$list[$j] .= "<TR><TD bgcolor=$TD_C2><a href=\"http://$kurl\" target=\"_top\">$kname</a><BR>($LANK[$s_num])</TD><TD bgcolor=$TD_C3><img src=\"$IMG/$kchara.gif\"></TD><TD bgcolor=$TD_C2>$_s</TD><TD bgcolor=$TD_C3>Lv $klv</TD><TD bgcolor=$TD_C2>$ELE[$kele]</TD><TD bgcolor=$TD_C3>$khp/$kmaxhp</TD><TD bgcolor=$TD_C2>$kmp/$kmaxmp</TD><TD bgcolor=$TD_C3>$kstr</TD><TD bgcolor=$TD_C2>$kvit</TD><TD bgcolor=$TD_C3>$kint</TD><TD bgcolor=$TD_C2>$kmen</TD><TD bgcolor=$TD_C3>$kagi</TD><TD bgcolor=$TD_C2>$kcex</TD><TD bgcolor=$TD_C3>$SYOKU[$kclass]</TD><TD bgcolor=$TD_C2>$ktotal��$kkati��</TD><TD bgcolor=$TD_C2>$rm</TD></TR>";
			}else{
				$lista[$j] .= "<a href=\"http://$kurl\" target=\"_top\">$kname</a>($LANK[$s_num]) ";
			}
			$c[$j]++;
			}
		}

		if(!$chit){
				$list_etc .= "<a href=\"http://$kurl\" target=\"_top\">$kname</a> ";
		}
	}



	&HEADER;

        $l_rank = " <TR><TH bgcolor=$TD_C2>�̸�(URL)</TH><TH bgcolor=$TD_C3>ĳ����</TH><TH bgcolor=$TD_C2>����</TH><TH bgcolor=$TD_C3>����</TH><TH bgcolor=$TD_C2>�Ӽ�</TH><TH bgcolor=$TD_C3>HP</TH><TH bgcolor=$TD_C2>MP</TH><TH bgcolor=$TD_C3 width=29>��</TH><TH bgcolor=$TD_C2>������</TH><TH bgcolor=$TD_C3>����</TH><TH bgcolor=$TD_C2>���ŷ�</TH><TH bgcolor=$TD_C3>��ø��</TH><TH bgcolor=$TD_C2>���嵵</TH><TH bgcolor=$TD_C3>����</TH><TH bgcolor=$TD_C2>����</TH><TH bgcolor=$TD_C2>��������</TH></TR>";

	print <<"EOM";
<TABLE WIDTH="100%" height=100% bgcolor=$TABLE_C>
  <TBODY>
    <TR>
      <TD BGCOLOR=$TD_C1 WIDTH=100% height=5> <font size=4> ���� <B> - RANKING - </B> ����</font></TD>
    </TR>
    <TR>
      <TD bgcolor=$TD_C4><CENTER>
<BR>
EOM

	$c_c=0;
	foreach(@COU_DATA){
		($xxcid,$xxname,$xxele,$xxnum,$xxins,$xxind,$xxall,$xxgold,$xxhp,$xxmaxhp,$xxstr,$xxvit,$xxagi)=split(/<>/);
if($xxall ne "" && $c_k_name[$c_c] eq ""){
	open(IN,"./charalog/main/$xxall.cgi") or &ERR2("������ �� �� �����ϴ�. err no :main_chara $xxall");
	@CN_DATA = <IN>;
	close(IN);
	($lid,$lpass,$lname) = split(/<>/,$CN_DATA[0]);
$c_k_name[$c_c] = "$lname";
}
print<<"EOM";
<TABLE bgcolor=$ELE_BG[$xxele] width=60%><TBODY><TR><TD colspan=5 bgcolor=$ELE_BG[$xxele] align=center><font color=$ELE_C[$xxele] size=4><B>$xxname</font></TD></TR><TR><TH bgcolor=$ELE_C[$xxele]><font color=$ELE_BG[$xxele]>��</TH><TH bgcolor=FFFFFF><font size=3 color=$ELE_BG[$xxele]>$c_k_name[$c_c]</TH><TD bgcolor=$ELE_C[$xxele]><font color=$ELE_BG[$xxele]>�����</TD><TD bgcolor=$ELE_C[$xxele]><font color=$ELE_BG[$xxele]> $c[$c_c] ��</TD><TD bgcolor=$ELE_C[$xxele]><a href=$ROSER_URL/$FILE_RANK?mode=C_RAN&con_no=$xxcid>���θ��</a></TD></TR><TR><TD bgcolor=$ELE_C[$xxele]><font color=$ELE_BG[$xxele]>���� ���ü�</TD><TD colspan=4 bgcolor=$ELE_C[$xxele]><font color=$ELE_BG[$xxele]>$town_c[$c_c]����($mes[$c_c])</TD></TR></TBODY></TABLE><BR>
      <TABLE bgcolor=$ELE_BG[$k] border="0">
        <TBODY>
$l_rank $list[$c_c] 
         </TR>
		<TR><TD bgcolor=$ELE_C[$xxele] align=center colspan=20><font color=$ELE_BG[$xxele]>$lista[$c_c]
		</TD></TR>
        </TBODY>
      </TABLE><br><br><br><br><br>
EOM
		$c_c++;
}

print <<"EOM";
<TABLE bgcolor=$ELE_BG[0] width=60%><TBODY><TR><TD colspan=5 bgcolor=$ELE_BG[0] align=center><font color=$ELE_C[0] size=4><B>���Ҽӱ�</font></TD></TR><TR><TD align=center bgcolor=$ELE_C[0]><a href=$ROSER_URL/$FILE_RANK?mode=C_RAN&con_no=0>���θ��</a></TD></TR></TBODY></TABLE><BR>
      <TABLE width=100% bgcolor=$ELE_BG[$k] border="0">
        <TBODY>
		<TR><TD bgcolor=$ELE_C[0] align=center><font color=$ELE_BG[0]>$list_etc
		</TD></TR>
        </TBODY>
      </TABLE><br><br><br><br><br>
<p>���� �� �α� $num ��
<form action="$FILE_TOP" method="post">
<input type=submit value="�޴���"></form>

      </TD>
    </TR>
  </TBODY>
</TABLE>
EOM

	&FOOTER;

	exit;
}


sub C_RAN{

	&SERVER_STOP;

	$C_NEXT_NUM = 100;

	open(IN,"$CHARA_DATA");
	@DL_DATA = <IN>;
	close(IN);
	$date = time;

	open(IN,"$COUNTRY_LIST") or &ERR2('������ �� �� �����ϴ�.');
	@COU_DATA = <IN>;
	close(IN);
	$country_no=0;
	foreach(@COU_DATA){
		($xxcid,$xxname,$xxele,$xxnum,$xxins,$xxind,$xxall,$xxgold,$xxhp,$xxmaxhp,$xxstr,$xxvit,$xxagi)=split(/<>/);
		$country_name[$country_no]="$xxname";
		$c[$country_no]=0;
		$c_no[$country_no]=$xxcid;
		$c_king[$country_no]=$xxall;
		$country_no++;
	}

	$dir="./charalog/main";
	opendir(dirlist,"$dir");
	while($file = readdir(dirlist)){
		if($file =~ /\.cgi/i){
			if(!open(page,"$dir/$file")){
				&ERR("������ �� �� �����ϴ�.");
			}
			@page = <page>;
			close(page);
			push(@CL_DATA,"@page<br>");
		}
	}
	closedir(dirlist);

	@tmp = map {(split /<>/)[19]} @CL_DATA;
	@CL_DATA = @CL_DATA[sort {$tmp[$b] <=> $tmp[$a]} 0 .. $#tmp];
	$num = @CL_DATA;
	$i=0;

	if($in{'c_num'} eq ""){
		$c_num = 0;
	}else{
		$c_num = $in{'c_num'};
	}

		$j=0;
	if($in{'con_no'} ne "0"){
		foreach(@CL_DATA) {
			($kid,$kpass,$kname,$kurl,$kchara,$ksex,$khp,$kmaxhp,$kmp,$kmaxmp,$kele,$kstr,$kvit,$kint,$kmen,$kagi,$kcom,$kgold,$k_ex,$kcex,$kunit,$kcon,$karm,$kpro,$kacc,$ksub1,$ksub2,$ktac,$ksta,$kpos,$kmes,$khost,$kdate,$ksyo,$kclass,$ktotal,$kkati) = split(/<>/);
			$klv = int($k_ex/100)+1;
			if($ksex){$_s="��";}else{$_s="��";}
			$s_num = int($kcex / $LANK_UP);
			if($s_num > 20){$s_num = 20;}

			if($kcon eq "$in{'con_no'}"){
			if($c[$j] >= $c_num && $c[$j] < $c_num + $C_NEXT_NUM){
			if($kid eq "$c_king[$j]"){
					$c_k_name[$j] = $kname;
			}
			$ldate = int(($kdate + (3600 * 24 * 31) - $date)  / (3600 * 24));
			if($ldate <= 0  || ($ldate < 24 && $ktotal < 50)){
				$rm = "<font color=red>�������</font>";
			}else{
				$rm = "<font color=blue>$ldate</font>��";
			}

				$list[$j] .= "<TR><TD bgcolor=$TD_C2><a href=\"http://$kurl\" target=\"_top\">$kname</a><BR>($LANK[$s_num])</TD><TD bgcolor=$TD_C3><img src=\"$IMG/$kchara.gif\"></TD><TD bgcolor=$TD_C2>$_s</TD><TD bgcolor=$TD_C3>Lv $klv</TD><TD bgcolor=$TD_C2>$ELE[$kele]</TD><TD bgcolor=$TD_C3>$khp/$kmaxhp</TD><TD bgcolor=$TD_C2>$kmp/$kmaxmp</TD><TD bgcolor=$TD_C3>$kstr</TD><TD bgcolor=$TD_C2>$kvit</TD><TD bgcolor=$TD_C3>$kint</TD><TD bgcolor=$TD_C2>$kmen</TD><TD bgcolor=$TD_C3>$kagi</TD><TD bgcolor=$TD_C2>$kcex</TD><TD bgcolor=$TD_C3>$SYOKU[$kclass]</TD><TD bgcolor=$TD_C2>$ktotal��$kkati��</TD><TD bgcolor=$TD_C2>$rm</TD></TR>";
			}
				$c[$j]++;

			}
		}
	}else{
		foreach(@CL_DATA) {
			($kid,$kpass,$kname,$kurl,$kchara,$ksex,$khp,$kmaxhp,$kmp,$kmaxmp,$kele,$kstr,$kvit,$kint,$kmen,$kagi,$kcom,$kgold,$k_ex,$kcex,$kunit,$kcon,$karm,$kpro,$kacc,$ksub1,$ksub2,$ktac,$ksta,$kpos,$kmes,$khost,$kdate,$ksyo,$kclass,$ktotal,$kkati) = split(/<>/);
			$klv = int($k_ex/100)+1;
			if($ksex){$_s="��";}else{$_s="��";}
			$s_num = int($kcex / $LANK_UP);
			if($s_num > 20){$s_num = 20;}

			$chit=0;
			for($j=0;$j<$country_no;$j++){
				if($kcon eq "$c_no[$j]"){
				$chit=1;
				last;
				}
			}
			$ldate = int(($kdate + (3600 * 24 * 31) - $date)  / (3600 * 24));
			if($ldate <= 0 || ($ldate < 24 && $ktotal < 50)){
				$rm = "<font color=red>�������</font>";
			}else{
				$rm = "<font color=blue>$ldate</font>��";
			}

			if(!$chit){
			if($c[0] >= $c_num && $c[0] < $c_num + $C_NEXT_NUM){
				$list[0] .= "<TR><TD bgcolor=$TD_C2><a href=\"http://$kurl\" target=\"_top\">$kname</a><BR>($LANK[$s_num])</TD><TD bgcolor=$TD_C3><img src=\"$IMG/$kchara.gif\"></TD><TD bgcolor=$TD_C2>$_s</TD><TD bgcolor=$TD_C3>Lv $klv</TD><TD bgcolor=$TD_C2>$ELE[$kele]</TD><TD bgcolor=$TD_C3>$khp/$kmaxhp</TD><TD bgcolor=$TD_C2>$kmp/$kmaxmp</TD><TD bgcolor=$TD_C3>$kstr</TD><TD bgcolor=$TD_C2>$kvit</TD><TD bgcolor=$TD_C3>$kint</TD><TD bgcolor=$TD_C2>$kmen</TD><TD bgcolor=$TD_C3>$kagi</TD><TD bgcolor=$TD_C2>$kcex</TD><TD bgcolor=$TD_C3>$SYOKU[$kclass]</TD><TD bgcolor=$TD_C2>$ktotal��$kkati��</TD><TD bgcolor=$TD_C2>$rm</TD></TR>";
			}
				$c[0]++;
			}
		}
	}

	&HEADER;

        $l_rank = " <TR><TH bgcolor=$TD_C2>�̸�(URL)</TH><TH bgcolor=$TD_C3>ĳ����</TH><TH bgcolor=$TD_C2>����</TH><TH bgcolor=$TD_C3>����</TH><TH bgcolor=$TD_C2>�Ӽ�</TH><TH bgcolor=$TD_C3>HP</TH><TH bgcolor=$TD_C2>MP</TH><TH bgcolor=$TD_C3 width=29>��</TH><TH bgcolor=$TD_C2>������</TH><TH bgcolor=$TD_C3>����</TH><TH bgcolor=$TD_C2>���ŷ�</TH><TH bgcolor=$TD_C3>��ø��</TH><TH bgcolor=$TD_C2>���嵵</TH><TH bgcolor=$TD_C3>����</TH><TH bgcolor=$TD_C2>����</TH><TH bgcolor=$TD_C2>��������</TH></TR>";

	print <<"EOM";
<TABLE WIDTH="100%" height=100% bgcolor=$TABLE_C>
  <TBODY>
    <TR>
      <TD BGCOLOR=$TD_C1 WIDTH=100% height=5> <font size=4> ���� <B> - RANKING - </B> ����</font></TD>
    </TR>
    <TR>
      <TD bgcolor=$TD_C4><CENTER>
<BR>
EOM

	$c_c=0;
	if($in{'con_no'} ne "0"){

		foreach(@COU_DATA){
			($xxcid,$xxname,$xxele,$xxnum,$xxins,$xxind,$xxall,$xxgold,$xxhp,$xxmaxhp,$xxstr,$xxvit,$xxagi)=split(/<>/);
			if($xxcid eq $in{'con_no'}){
			if($xxall ne "" && $c_k_name[$c_c] eq ""){
				open(IN,"./charalog/main/$xxall.cgi");
				@CN_DATA = <IN>;
				close(IN);
				($lid,$lpass,$lname) = split(/<>/,$CN_DATA[0]);
				$c_k_name[$c_c] = "$lname";
			}
	print<<"EOM";
	<TABLE bgcolor=$ELE_BG[$xxele] width=60%><TBODY><TR><TD colspan=4 bgcolor=$ELE_BG[$xxele] align=center><font color=$ELE_C[$xxele] size=4><B>$xxname</font></TD></TR><TR><TH bgcolor=$ELE_C[$xxele]><font color=$ELE_BG[$xxele]>��</TH><TH bgcolor=FFFFFF><font size=3 color=$ELE_BG[$xxele]>$c_k_name[$c_c]</TH><TD bgcolor=$ELE_C[$xxele]><font color=$ELE_BG[$xxele]>�����</TD><TD bgcolor=$ELE_C[$xxele]><font color=$ELE_BG[$xxele]> $c[$c_c] ��</TD></TR></TBODY></TABLE><BR>
	      <TABLE bgcolor=$ELE_BG[$k] border="0">
	        <TBODY>
	$l_rank $list[$c_c] 
	         </TR>
			<TR><TD bgcolor=$ELE_C[$xxele] align=center colspan=20><font color=$ELE_BG[$xxele]>$lista[0]
			</TD></TR>
	        </TBODY>
	      </TABLE><br><br><br><br><br>
EOM
			$c_c++;
			}
		}

	}else{

	$xxele=0;

	print<<"EOM";
	<TABLE bgcolor=$ELE_BG[$xxele] width=60%><TBODY><TR><TD colspan=2 bgcolor=$ELE_BG[$xxele] align=center><font color=$ELE_C[$xxele] size=4><B>���Ҽ�</font></TD></TR><TR><TD bgcolor=$ELE_C[$xxele]><font color=$ELE_BG[$xxele]>�����</TD><TD bgcolor=$ELE_C[$xxele]><font color=$ELE_BG[$xxele]> $c[$c_c] ��</TD></TR></TBODY></TABLE><BR>
	      <TABLE bgcolor=$ELE_BG[$k] border="0">
	        <TBODY>
	$l_rank $list[$c_c] 
	         </TR>
	        </TBODY>
	      </TABLE><br><br><br><br><br>
EOM
	}

	$q=0;
	for($p=0;$p<$c[0];$p+=$C_NEXT_NUM){
		$next_mes .= "\[<a href=$ROSER_URL/$FILE_RANK?mode=C_RAN&con_no=$in{'con_no'}&c_num=$p>$q</a>\] ";
		$q++;
	}

print <<"EOM";
$next_mes
<form action="$FILE_RANK" method="post">
<input type=submit value="RANKING TOP"></form>

      </TD>
    </TR>
  </TBODY>
</TABLE>
EOM

	&FOOTER;

	exit;

}
