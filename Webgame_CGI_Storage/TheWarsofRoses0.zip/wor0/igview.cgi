#!/usr/bin/perl

# �̹��� �̸�����
# ���� : ������(http://myan.xo.st/)

require './ini_file/index.ini';

&top;

sub top {
	print "Cache-Control: no-cache\n";
	print "Pragma: no-cache\n";
	print "Content-type: text/html\n\n";
	print <<"EOM";
<html>
<head>
<META HTTP-EQUIV="Content-type" CONTENT="text/html; charset=euc-kr">
<body background="$BACKGROUND" bgcolor="$BGCOLOR" text="$TEXT" link="$LINK" vlink="$VLINK" alink="$ALINK" leftmargin="0" marginwidth="0" marginheight="0">
<table>
EOM
	foreach (0..$CHARA_IMAGE){
		$t++;
		if($t eq 1){print "<tr>"}
		if($t < 11){print "<td align=center><img src=\"$IMG/$_.gif\"><br>$_</td>"}
		if($t eq 10){print "</tr>\n";$t=0;}
	}
}