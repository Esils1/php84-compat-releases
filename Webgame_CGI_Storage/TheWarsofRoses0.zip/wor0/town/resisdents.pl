#_/_/_/_/_/_/_/_/_/#
#_/   ��   ��    _/#
#_/_/_/_/_/_/_/_/_/#

sub RESISDENTS {

	&CHARA_OPEN;
	if($scid){
        $sstatus ="<TR><TD bgcolor=$TD_C2>$sname</TD><TD bgcolor=$TD_C3 align=right>$slv</TD><TD bgcolor=$TD_C2>$ELE[$sele]</TD><TD bgcolor=$TD_C3>$SYOKU[$sclass]</TD></TR>";
	}
	if($tcid){
        $tstatus ="<TR><TD bgcolor=$TD_C2>$tname</TD><TD bgcolor=$TD_C3 align=right>$tlv</TD><TD bgcolor=$TD_C2>$ELE[$tele]</TD><TD bgcolor=$TD_C3>$SYOKU[$tclass]</TD></TR>";
	}

	open(IN,"$TOWN_LIST") or &ERR("���� �б� ����");
	@TOWN_DATA = <IN>;
	close(IN);
	foreach(@TOWN_DATA){
		($zcid,$zname,$zele,$zcon,$zmoney,$zmes)=split(/<>/);
		if("$zcid" eq "$in{town}"){last;}
	}

	if($zcid eq 2){$s_i = int(rand(@S_MES));$s_mes = "$S_MES[$s_i]";}
	elsif($zcid eq 3){$s_i = int(rand(@G_MES));$s_mes = "$G_MES[$s_i]";}
	elsif($zcid eq 4){$s_i = int(rand(@R_MES));$s_mes = "$R_MES[$s_i]";}
	else{$s_i = int(rand(@S_MES));$s_mes = "$S_MES[$s_i]";}
	&HEADER;

	print <<"EOM";
<TABLE WIDTH="100%" height=100% bgcolor=$TABLE_C>
<TBODY><TR>
<TD BGCOLOR=$TD_C1 WIDTH=100% height=5> <font size=4> ����<B> * �� �� *</B>����</font></TD>
</TR><TR>
<TD bgcolor=$TD_C4 height=5>
<TABLE border="0"><TBODY>
<TR>
<TD bgcolor=$TD_C1><img src="$IMG/$kchara.gif"></TD>
<TD bgcolor=$TD_C2>$simg</TD>
<TD bgcolor=$TD_C3>$timg</TD>
<TD bgcolor=$TD_C4 WIDTH=100% align=center>
<TABLE bgcolor=$TABLE_C border="0">
<TBODY>
<TR>
<TD bgcolor=$TD_C2>�̸�</TD>
<TD bgcolor=$TD_C3>LV</TD>
<TD bgcolor=$TD_C2>�Ӽ�</TD>
<TD bgcolor=$TD_C3>����</TD>
</TR>
<TR>
<TD bgcolor=$TD_C2>$kname</TD>
<TD bgcolor=$TD_C3 align=right>$klv</TD>
<TD bgcolor=$TD_C2>$ELE[$kele]</TD>
<TD bgcolor=$TD_C3>$SYOKU[$kclass]</TD>
</TR>
$sstatus$tstatus
<TR>
<TD bgcolor=$TD_C2>������</TD>
<TD bgcolor=$TD_C1 colspan=3 align=right>$kgold G</TD>
</TR>
</TBODY></TABLE>
</TD>
</TR>
</TBODY></TABLE>
</TD>
</TR>
<TR>
<TD bgcolor=$TD_C4 height="5">
<TABLE bgcolor=$TABLE_C  border="0"><TBODY>
<TR><TD width="100%" bgcolor=$TALK_BG><font color=$TALK_FONT>$s_mes</font></TD>
<TD bgcolor=$TD_C4><img src="$IMG/etc/$s_i.gif"></TD>
</TR>
</TBODY></TABLE>
</TD>
</TR>
<TR>
<TD bgcolor=$TD_C4>
<form action="$FILE_STATUS" method="post">
<input type=hidden name=id value=$kid>
<input type=hidden name=pass value=$kpass>
<input type=hidden name=mode value=STATUS>
<input type=submit value="������ ���ư���"></form>
</TD>
</TR>
</TBODY></TABLE>
EOM

	&FOOTER;
	exit;
}
1;