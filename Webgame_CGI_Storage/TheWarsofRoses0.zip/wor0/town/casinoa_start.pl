#_/_/_/_/_/_/_/_/_/#
#_/ High and Low_/ #
#_/_/_/_/_/_/_/_/_/#

sub CASINOA_START {

	if(!$CASINO_SWITCH){&ERR("���� �����Դϴ�.");}
	&CHARA_OPEN;
	if($kgold < 10000){&ERR2("���� �����մϴ�.");}
	open(IN,"$TOWN_LIST") or &ERR("���� �б� ����");
	@TOWN_DATA = <IN>;
	close(IN);
	foreach(@TOWN_DATA){
		($zcid,$zname,$zele,$zcon,$zmoney,$zmes)=split(/<>/);
		if("$zcid" eq "$in{town}"){last;}
	}

$kakegold = int($in{'kakegold'});
$suu = int(rand(51));

if($in{'new'} ne "yes"){
	if($in{'hantei'} ne "STOP"){

		if(($ksub2 & 1<<25) eq 0){$kcex=0;$kgold=0;&CHARA_MAIN_INPUT;&MAP_LOG("<font color=red><B>\[����\]</B></font>$kname���� ī���뿡�� ���������� �õ�������, �����߽��ϴ�.");&ERR("���������Դϴ�!");}
		if($in{'hantei'} eq "High" && $in{'oldsuu'} < $suu or $in{'hantei'} eq "Low" && $in{'oldsuu'} > $suu){
		$kakegold = int($kakegold *1.5);
		$casino_mes = "�ɷȴ�!";
		}else{$kakegold = 0;$w=$ksub2-(1<<25);$ksub2&=$w;&CHARA_INPUT;$casino_mes = "Ż���̴�.";}
	
	}else{$kgold += $kakegold;$w=$ksub2-(1<<25);$ksub2&=$w;&CHARA_INPUT;}

}else{int($kakegold/=2);$kgold -= 10000;$ksub2|=1<<25;&CHARA_INPUT;}


if($kakegold > 1){$sen_mes = "���� ���� $suu���� Ŭ��? �ƴϸ� �������?<BR>���� ��� : <font color=red size=5>$kakegold</font>Gold";}

	&HEADER;

	print <<"EOM";
<table width="100%" cellpadding="0" cellspacing="0" border=0><tr><td bgcolor=$TABLE_C>
<TABLE WIDTH="100%" bgcolor=$TABLE_C border=0>
<TBODY><TR>
<TD BGCOLOR=$TD_C1 WIDTH=100% height=5> <font size=4> ����<B> * High and Low *</B>����</font></TD>
</TR><TR>
<TD bgcolor=$TD_C4 height=5>
<TABLE border="0"><TBODY>
<TR>
<TD bgcolor=$TD_C1><img src="$IMG/$kchara.gif" width="$img_wid" height="$img_height" alt="$kname"></TD>
<TD bgcolor=$TD_C2>$simg</TD>
<TD bgcolor=$TD_C3>$timg</TD>
<TD bgcolor=$TD_C4 WIDTH=100% align=center>
<table cellpadding="0" cellspacing="0" border=0><tr><td bgcolor=$TABLE_C>
<TABLE border="0" cellspacing="2">
<TBODY>
<TR>
<TD bgcolor=$TD_C2>�̸�</TD>
<TD bgcolor=$TD_C3>LV</TD>
<TD bgcolor=$TD_C2>�Ӽ�</TD>
<TD bgcolor=$TD_C3>����</TD>
</TR>
<TR>
<TD bgcolor=$TD_C2>$kname</TD>
<TD bgcolor=$TD_C3 align=right>$klv</TD>
<TD bgcolor=$TD_C2>$ELE[$kele]</TD>
<TD bgcolor=$TD_C3>$SYOKU[$kclass]</TD>
</TR>
$sstatus$tstatus
<TR>
<TD bgcolor=$TD_C2>������</TD>
<TD bgcolor=$TD_C1 colspan=3 align=right>$kgold GOLD</TD>
</TR>
</TBODY></TABLE>
</td></tr></table>

</TD>
</TR>
</TBODY></TABLE>
</TD>
</TR>
<TR>
<TD bgcolor=$TD_C4 height="5">
<TABLE bgcolor=$TABLE_C  border="0"><TBODY>
<TR><TD width="100%" bgcolor=$TALK_BG><font color=$TALK_FONT><center>$casino_mes<BR><font size=5 color=red>$suu</font></center><BR>$sen_mes<BR></font></TD>
<TD bgcolor=$TD_C4><img src="$IMG/etc/25.gif" width="$img_wid" height="$img_height" alt="������"></TD>
</TR>
</TBODY></TABLE>
</TD>
</TR>
<TR>
<TD bgcolor=$TD_C4>
EOM
if($in{'hantei'} ne "STOP"){
if($kakegold > 1){
print <<"EOM";

<form action="$FILE_TOWN" method="post">
<input type=hidden name=id value=$kid>
<input type=hidden name=pass value=$kpass>
<input type=hidden name=mode value=CASINOA_START>
<input type=hidden name=hantei value=High>
<input type=hidden name=oldsuu value=$suu>
<input type=hidden name=kakegold value=$kakegold>
<input type=hidden name=moto value=$in{'moto'}>
<input type=submit value="ũ��"></form>
<form action="$FILE_TOWN" method="post">
<input type=hidden name=id value=$kid>
<input type=hidden name=pass value=$kpass>
<input type=hidden name=mode value=CASINOA_START>
<input type=hidden name=hantei value=Low>
<input type=hidden name=oldsuu value=$suu>
<input type=hidden name=kakegold value=$kakegold>
<input type=hidden name=moto value=$in{'moto'}>
<input type=submit value="�۴�"></form>
<form action="$FILE_TOWN" method="post">
<input type=hidden name=id value=$kid>
<input type=hidden name=pass value=$kpass>
<input type=hidden name=mode value=CASINOA_START>
<input type=hidden name=hantei value=STOP>
<input type=hidden name=oldsuu value=$suu>
<input type=hidden name=kakegold value=$kakegold>
<input type=hidden name=moto value=$in{'moto'}>
<input type=submit value="�׸�~"></form>
EOM
}}
print <<"EOM";

<form action="$FILE_STATUS" method="post">
<input type=hidden name=id value=$kid>
<input type=hidden name=pass value=$kpass>
<input type=hidden name=mode value=STATUS>
<input type=submit value="������ ���ư���"></form>
</TD>
</TR>
</TBODY></TABLE>
</td></tr></table>
EOM

	&FOOTER;
	exit;
}
1;