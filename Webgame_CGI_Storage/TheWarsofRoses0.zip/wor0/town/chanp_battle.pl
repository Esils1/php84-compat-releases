#_/_/_/_/_/_/_/_/_/#
#_/    ������    _/#
#_/_/_/_/_/_/_/_/_/#

sub CHANP_BATTLE {

	&CHARA_OPEN;
	if($scid){
        $sstatus ="<TR><TD bgcolor=$TD_C2>$sname</TD><TD bgcolor=$TD_C3 align=right>$slv</TD><TD bgcolor=$TD_C2>$ELE[$sele]</TD><TD bgcolor=$TD_C3>$SYOKU[$sclass]</TD></TR>";
	}
	if($tcid){
        $tstatus ="<TR><TD bgcolor=$TD_C2>$tname</TD><TD bgcolor=$TD_C3 align=right>$tlv</TD><TD bgcolor=$TD_C2>$ELE[$tele]</TD><TD bgcolor=$TD_C3>$SYOKU[$tclass]</TD></TR>";
	}

	&COUNTRY_DATA_OPEN("$kcon");
	open(IN,"$TOWN_LIST") or &ERR("���� �б� ����");
	@TOWN_DATA = <IN>;
	close(IN);
	foreach(@TOWN_DATA){
		($zcid,$zname,$zele,$zcon,$zmoney,$zmes)=split(/<>/);
		if("$zcid" eq "$in{town}"){last;}
	}
	if($CHANP_MONEY > $kgold){
		$inn_mes = "�̷�? ���� �����鼭 �� �ϰڴٴ°ž�?<BR>����� ������ �ڰ��� ����.<BR>�� ���ư�!";
	}

	open(IN,"$CHANP_LIST");
	@CHANP_DATA = <IN>;
	close(IN);
	($wid,$wpass,$wname,$wurl,$wchara,$wsex,$whp,$wmaxhp,$wmp,$wmaxmp,$wele,$wstr,$wvit,$wint,$wmen,$wagi,$wcom,$wgold,$w_ex,$wcex,$wunit,$wcon,$warm,$wpro,$wacc,$wsub1,$wsub2,$wtac,$wsta,$wpos,$wmes,$whost,$wdate,$wsyo,$wclass,$wtotal,$wkati,$lcount,$lname,$lurl,$lunit) = split(/<>/,$CHANP_DATA[0]);
	&COUNTRY_DATA_OPEN("$wcon");
	$wlv = int($w_ex/$EX)+1;
	$wfriend = 0;

	open(IN,"$TEC_DATA") or &ERR('���� �б� ����');
	@TEC = <IN>;
	close(IN);
	foreach(@TEC){
		($tec_no,$tec_name,$tec_str,$tec_hit,$tec_sta,$tec_cho,$tec_class) = split(/<>/);
		if( $tec_no eq "$wtac"){
			$w_tec_mes .= "$tec_name(����: $tec_str Ȯ��: $tec_hit)";
		}
	}
	$i = 0;
	foreach(@SYOKU){
		$s_syoku = 2 ** $i;
		if($wsyo & $s_syoku){
			$w_master_class .= " $SYOKU[$i] ";
		}
		# bit �Ѱ�
		if($i > 30){last;}
		$i++;
	}

	if($wsex){$sw_sex = "��";}else{$sw_sex = "��";}
	if($wcom>127) { $com_name = "�ż�"; } else { $com_name = "ī����"; }

	open(IN,"$ARM_LIST") or &ERR('���� �б� ����');
	@ARM_DATA = <IN>;
	close(IN);
	open(IN,"$PRO_LIST") or &ERR('���� �б� ����');
	@PRO_DATA = <IN>;
	close(IN);
	open(IN,"$ACC_LIST") or &ERR('���� �б� ����');
	@ACC_DATA = <IN>;
	close(IN);

	($warmname,$warmval,$warmdmg,$warmwei,$warmele,$warmsta,$warmclass,$warmtownid) = split(/<>/,$ARM_DATA[$warm]);
	if($warmsta eq "use"){
		open(IN,"./charalog/arm/$wid.cgi");
		@MY_ARM_DATA = <IN>;
		close(IN);
		($warmname,$warmval,$warmdmg,$warmwei,$warmele,$warmsta,$warmclass,$warmtownid) = split(/<>/,$MY_ARM_DATA[0]);
	}

	($wproname,$wproval,$wprodmg,$wprowei,$wproele,$wprosta,$wproclass,$wprotownid) = split(/<>/,$PRO_DATA[$wpro]);
	($waccname,$waccval,$waccdmg,$waccwei,$waccele,$waccsta,$waccclass,$wacctownid) = split(/<>/,$ACC_DATA[$wacc]);

	$get_money = $lcount * $CHANP_MONEY + 10000;
	&HEADER;

	print <<"EOM";
<table width="100%" cellpadding="0" cellspacing="0" border=0><tr><td bgcolor=$TABLE_C>
<TABLE WIDTH="100%" bgcolor=$TABLE_C border=0>
<TBODY><TR>
<TD BGCOLOR=$TD_C1 WIDTH=100% height=5> <font size=4> ����<B> * �� �� �� *</B>����</font></TD>
</TR><TR>
<TD bgcolor=$TD_C4 height=5>
<TABLE border="0"><TBODY>
<TR>
<TD bgcolor=$TD_C1><img src="$IMG/$kchara.gif" width="$img_wid" height="$img_height" alt="$kname"></TD>
<TD bgcolor=$TD_C2>$simg</TD>
<TD bgcolor=$TD_C3>$timg</TD>
<TD bgcolor=$TD_C4 WIDTH=100% align=center>
<table cellpadding="0" cellspacing="0" border=0><tr><td bgcolor=$TABLE_C>
<TABLE border="0" cellspacing="2">
<TBODY>
<TR>
<TD bgcolor=$TD_C2>�̸�</TD>
<TD bgcolor=$TD_C3>LV</TD>
<TD bgcolor=$TD_C2>�Ӽ�</TD>
<TD bgcolor=$TD_C3>����</TD>
</TR>
<TR>
<TD bgcolor=$TD_C2>$kname</TD>
<TD bgcolor=$TD_C3 align=right>$klv</TD>
<TD bgcolor=$TD_C2>$ELE[$kele]</TD>
<TD bgcolor=$TD_C3>$SYOKU[$kclass]</TD>
</TR>
$sstatus$tstatus
<TR>
<TD bgcolor=$TD_C2>������</TD>
<TD bgcolor=$TD_C1 colspan=3 align=right>$kgold G</TD>
</TR>
</TBODY></TABLE>
</td></tr></table>
</TD>
</TR>
</TBODY></TABLE>
</TD>
</TR>
<TR>
<TD bgcolor=$TD_C4 height="5">
<TABLE bgcolor=$TABLE_C  border="0"><TBODY>
<TR><TD width="100%" bgcolor=$TALK_BG><font color=$TALK_FONT>���� �������̾�. è���� �����Ϸ� ����?<BR>���⼱ ���� �ɰ� ���տ� ������ �� ����.<BR>���� è�Ǿ��� ��<font color=orange>$wname</font>�����̰�,��<font color=red>$lcount</font>���������̴�.<BR>����� è�Ǿ𿡰� �̱�� ����� <font color=yellow>$get_money G</font>�� �ǰڳ�..<BR>������� $CHANP_MONEY G�ε�, �����Ұǰ�?<BR>$inn_mes</font></TD>
<TD bgcolor=$TD_C4><img src="$IMG/etc/25.gif" width="$img_wid" height="$img_height" alt="���"></TD>
</TR>
</TBODY></TABLE>
</TD>
</TR>
<TR>
<TD bgcolor=$TD_C4><p><BR>
<CENTER><FONT COLOR=RED SIZE=5><B>�ڡڡ� WANTED �ڡڡ�<BR>�� $get_money Gold!</B></font><BR><FONT COLOR=orange SIZE=4><B>�� ���� è�Ǿ� ��</B></font>
<TABLE border="0" width="345">
  <TBODY>
    <TR>
      <TD>
      <TABLE bgcolor=$TABLE_C border="0" align="center" width="100%">
        <TBODY>
          <TR>
            <TD bgcolor=$TD_C1 align="center" colspan="5">�̸� : <font size=4><B> $wname </B></font>($sw_sex)</TD>
          </TR>
          <TR>
            <TD align="center" bgcolor=$TD_C4 width="89">LV $wlv</TD>
            <TD colspan="4" align="center" width="243" bgcolor=$TD_C2>�Ҽ�: <B><font size=3 color="navy">$xxname��</font></B>($wunit ��)</TD>
          </TR>
          <TR>
            <TD align="center" valign="middle" rowspan="6" bgcolor=$TD_C1><img src="$IMG/$wchara.gif" width="$img_wid" height="$img_height" border=0>
            </TD>
            <td align="center" bgcolor=$TD_C2>HP</td>
            <td align=center bgcolor=$TD_C3>$whp/$wmaxhp</td>
            <TD align="center" bgcolor=$TD_C2>MP</TD>
            <TD align=center bgcolor=$TD_C3>$wmp/$wmaxmp</TD>
          </TR>
          <TR>
            <td align="center" bgcolor=$TD_C2>���</td>
            <td colspan=3 align="center" bgcolor=$TD_C4>$w_tec_mes</td>
          </TR>
          <TR>
            <TD bgcolor=$TD_C2 align="center">��</TD>
            <TD bgcolor=$TD_C3 align="center">$wstr</TD>
            <TD bgcolor=$TD_C2 align="center">������</TD>
            <TD bgcolor=$TD_C3 align="center">$wvit</TD>
          </TR>
          <TR>
            <TD bgcolor=$TD_C2 align="center">����</TD>
            <TD bgcolor=$TD_C3 align="center">$wint</TD>
            <TD bgcolor=$TD_C2 align="center">���ŷ�</TD>
            <TD bgcolor=$TD_C3 align="center">$wmen</TD>
          </TR>
          <TR>
            <TD bgcolor=$TD_C2 align="center">��ø��</TD>
            <TD bgcolor=$TD_C3 align="center">$wagi</TD>
            <TD bgcolor=$TD_C2 align="center">����</TD>
            <TD bgcolor=$TD_C3 align="center">$com_name</TD>
          </TR>
          <TR>
            <TD bgcolor=$TD_C2 align="center">�Ӽ�</TD>
            <TD bgcolor=$TD_C3 align="center">$ELE[$wele]</TD>
            <TD bgcolor=$TD_C2 align="center">���� ��</TD>
            <TD bgcolor=$TD_C3 align="center">$wfriend��</TD>
          </TR>
          <TR>
            <TD bgcolor=$TD_C1 align="center">$wtotal �� $wkati ��</TD>
            <TD bgcolor=$TD_C2 align="center">����ġ</TD>
            <TD bgcolor=$TD_C3 align="center">$w_ex</TD>
            <TD bgcolor=$TD_C2 align="center">��</TD>
            <TD bgcolor=$TD_C3 align="center">$wgold G</TD>
          </TR>
          <TR>
            <TD align="center" bgcolor=$TD_C4>&nbsp;</TD>
            <TD bgcolor=$TD_C4 colspan="2" align="center">�̸�</TD>
            <TD bgcolor=$TD_C4 align="center">����</TD>
            <TD bgcolor=$TD_C4 align="center">����</TD>
          </TR>
          <TR>
            <TD align="center" bgcolor=$TD_C1>����</TD>
            <TD align=right bgcolor=$TD_C1 colspan="2">$warmname</TD>
            <TD align=right bgcolor=$TD_C1>$warmdmg</TD>
            <TD align=right bgcolor=$TD_C1>$warmwei</TD>
          </TR>
          <TR>
            <TD align="center" bgcolor=$TD_C2>��</TD>
            <TD align=right bgcolor=$TD_C2 colspan="2">$wproname</TD>
            <TD align=right bgcolor=$TD_C2>$wprodmg</TD>
            <TD align=right bgcolor=$TD_C2>$wprowei</TD>
          </TR>
          <TR>
            <TD align="center" bgcolor=$TD_C3>�Ǽ��縮</TD>
            <TD align=right bgcolor=$TD_C3 colspan="2">$waccname</TD>
            <TD align=right bgcolor=$TD_C3>$waccdmg</TD>
            <TD align=right bgcolor=$TD_C3>$waccwei</TD>
          </TR>
          <TR>
            <TH bgcolor=$TD_C1 colspan="5">���� ����</TH>
          </TR>
          <TR>
            <TD bgcolor=$TD_C4 align="center" colspan="5">$SYOKU[$wclass]</TD>
          </TR>
          <TR>
            <TH bgcolor=$TD_C2 colspan="5">�������� ����</TH>
          </TR>
          <TR>
            <TD colspan="5" align="center" bgcolor=$TD_C4><font color="#FF9998"><B>$w_master_class</B></font></TD>
          </TR>
          <TR>
            <TH colspan="5" bgcolor=$TD_C2>�ڸ�Ʈ</TH>
          </TR>
          <TR>
            <TD colspan="5" align="center" bgcolor=$TD_C3>$wmes</TD>
          </TR>
        </TBODY>
      </TABLE>
      </TD>
    
    <TR>
  </TBODY>
</table>
�ڡ� ���� <font size=3 color=red>$lcount</font> ������, ���������� <A HREF=\"http\:\/\/$lurl\" TARGET=\"_blank\">$lname</a>�� <font color=blue>$lunit ��</font>���� �¸��߾����ϴ�! �١�


<form action="$FILE_BATTLE" method="post">
<input type=hidden name=id value=$kid>
<input type=hidden name=pass value=$kpass>
<input type=hidden name=eid value=$wid>
<input type=hidden name=type value=chanp_battle>
<input type=hidden name=mode value=BATTLE>
EOM

	if($CHANP_MONEY > $kgold){
		print "������ �غ��ؿ����~";
	}elsif($wid ne $kid){
		print "<input type=submit value=\"è������ ����\">";
	}else{
		print "����� è�Ǿ��Դϴ�.";
	}
print <<"EOM";
</form>
<form action="$FILE_STATUS" method="post">
<input type=hidden name=id value=$kid>
<input type=hidden name=pass value=$kpass>
<input type=hidden name=mode value=STATUS>
<input type=submit value="������ ���ư���"></form>
</TD>
</TR>
</TBODY></TABLE>
</td></tr></table>
EOM

	&FOOTER;
	exit;
}
1;