#_/_/_/_/_/_/_/_/_/#
#_/  ���� ��ũ  _/#
#_/_/_/_/_/_/_/_/_/#

sub EMPLOY {

	&CHARA_OPEN;
	if($scid){
        $sstatus ="<TR><TD bgcolor=$TD_C2>$sname</TD><TD bgcolor=$TD_C3 align=right>$slv</TD><TD bgcolor=$TD_C2>$ELE[$sele]</TD><TD bgcolor=$TD_C3>$SYOKU[$sclass]</TD></TR>";
	}
	if($tcid){
        $tstatus ="<TR><TD bgcolor=$TD_C2>$tname</TD><TD bgcolor=$TD_C3 align=right>$tlv</TD><TD bgcolor=$TD_C2>$ELE[$tele]</TD><TD bgcolor=$TD_C3>$SYOKU[$tclass]</TD></TR>";
	}
	$townid = $in{'town'}%10;
	open(IN,"$CHARA_DATA");
	@O_DATA = <IN>;
	close(IN);
	foreach(@O_DATA){
		($scid,$sname,$ssex,$smaxhp,$smaxmp,$sele,$sstr,$svit,$sint,$smen,$sagi,$scom,$s_ex,$sarm,$spro,$sacc,$ssta,$sclass) = split(/<>/);
		if($townid eq $scid%10){
			$slv = int($s_ex/100)+1;
			if($ssex){$_s="��";}else{$_s="��";}
			$Value=int(($smaxhp/2)+($smaxmp/2)+($sstr*10)+($svit*5)+($sint*5)+($smen*3)+($sagi*10))*$SALARY;
			$Salary=int($Value/100);
			$list .= "<TR><TD bgcolor=$TD_C1><input type=radio name=select value=$scid></TD><TD bgcolor=$TD_C2>$sname</TD><TD bgcolor=$TD_C3><img src=\"$IMG/$scid.gif\" width=\"$img_wid\" height=\"$img_height\"></TD><TD bgcolor=$TD_C2 align=\"center\">$_s</TD><TD bgcolor=$TD_C3 align=\"right\">Lv $slv</TD><TD bgcolor=$TD_C2 align=\"center\">$ELE[$sele]</TD><TD bgcolor=$TD_C3>$smaxhp/$smaxhp</TD><TD bgcolor=$TD_C2>$smaxmp/$smaxmp</TD><TD bgcolor=$TD_C3>$sstr</TD><TD bgcolor=$TD_C2>$svit</TD><TD bgcolor=$TD_C3>$sint</TD><TD bgcolor=$TD_C2>$smen</TD><TD bgcolor=$TD_C3>$sagi</TD><TD bgcolor=$TD_C2>$Value Gold</TD><TD bgcolor=$TD_C3>$Salary</TD></TR>";
		}
	}
	&HEADER;
	print <<"EOM";
<table width="100%" height=100% cellpadding="0" cellspacing="0" border=0><tr><td bgcolor=$TABLE_C>
<TABLE WIDTH="100%" height=100% border=0 cellpadding="3" cellspacing="2"><TBODY>
<TR>
<TD BGCOLOR=$TD_C1 WIDTH=100% height=5> <font size=4> ����<B>���� �Ұ� �ȳ���</B>����</font></TD>
</TR>
<TR>
<TD bgcolor=$TD_C4 height=5>
<TABLE border="0"><TBODY>
<TR>
<TD bgcolor=$TD_C1><img src="$IMG/$kchara.gif" width="$img_wid" height="$img_height" alt="$kname"></TD>
<TD bgcolor=$TD_C2>$simg</TD>
<TD bgcolor=$TD_C3>$timg</TD>
<TD bgcolor=$TD_C4 align=center>
<table cellpadding="0" cellspacing="0" border=0><tr><td bgcolor=$TABLE_C>
<TABLE border="0" cellpadding="3" cellspacing="1"><TBODY>
<TR>
<TD bgcolor=$TD_C2>�̸�</TD>
<TD bgcolor=$TD_C3>LV</TD>
<TD bgcolor=$TD_C2>�Ӽ�</TD>
<TD bgcolor=$TD_C3>����</TD>
</TR>
<TR>
<TD bgcolor=$TD_C2>$kname</TD>
<TD bgcolor=$TD_C3 align=right>$klv</TD>
<TD bgcolor=$TD_C2>$ELE[$kele]</TD>
<TD bgcolor=$TD_C3>$SYOKU[$kclass]</TD>
</TR>
$sstatus$tstatus<TR>
<TD bgcolor=$TD_C2>������</TD>
<TD bgcolor=$TD_C1 colspan=3 align=right>$kgold G</TD>
</TR>
</TBODY></TABLE>
</td></tr></table>
</TD>
</TR>
</TBODY></TABLE>
</TD>
</TR>
<TR>
<TD bgcolor=$TD_C4 height="5">
<TABLE bgcolor=$TABLE_C  border="0">
<TBODY>
<TR>
<TD width="100%" bgcolor=$TALK_BG><font color=$TALK_FONT>$ALL_MES[2]</font></TD>
<TD bgcolor=$TD_C1><img src="$IMG/etc/29.gif" width="$img_wid" height="$img_height"></TD>
</TR>
</TBODY>
</TABLE>
</TD>
</TR><form action="$FILE_TOWN" method="post">
<TR>
<TD bgcolor=$TD_C4>
<table cellpadding="0" cellspacing="0" border=0><tr><td bgcolor=$TABLE_C>
<TABLE border="0">
<TBODY>
<TR><TR><TD bgcolor=$TD_C1>����</TD><TD bgcolor=$TD_C2>�̸�</TD><TD bgcolor=$TD_C3>ĳ����</TD><TD bgcolor=$TD_C2>����</TD><TD bgcolor=$TD_C3>����</TD><TD bgcolor=$TD_C2>�Ӽ�</TD><TD bgcolor=$TD_C3>HP</TD><TD bgcolor=$TD_C2>MP</TD><TD bgcolor=$TD_C3>��</TD><TD bgcolor=$TD_C2>������</TD><TD bgcolor=$TD_C3>����</TD><TD bgcolor=$TD_C2>���ŷ�</TD><TD bgcolor=$TD_C3>��ø��</TD><TD bgcolor=$TD_C2>���� �ݾ�</TD><TD bgcolor=$TD_C3>��</TD></TR>
$list
</TR>
<TR><TD align=center colspan=16>
<input type=hidden name=id value=$kid>
<input type=hidden name=pass value=$kpass>
<input type=hidden name=mode value=SUB_MAKE>
<input type=submit value="�����Ѵ�">
</TD></TR></form>
</TBODY></TABLE>
</td></tr></table>
<form action="$FILE_STATUS" method="post">
<input type=hidden name=id value=$kid>
<input type=hidden name=pass value=$kpass>
<input type=hidden name=mode value=STATUS>
<input type=submit value="���� ȭ������"></form>
</TD>
</TR>
</TBODY></TABLE>
</td></tr></table>
EOM

	&FOOTER;
	exit;
}
1;