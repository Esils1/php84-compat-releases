#_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/#
#_/  �ٸ� ������ ���ῡ �ִ´�  _/#
#_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/#

sub EMPLOY_GUEST {

	&CHARA_OPEN;
	if($scid){
        $sstatus ="<TR><TD bgcolor=$TD_C2>$sname</TD><TD bgcolor=$TD_C3 align=right>$slv</TD><TD bgcolor=$TD_C2>$ELE[$sele]</TD><TD bgcolor=$TD_C3>$SYOKU[$sclass]</TD></TR>";
	}
	if($tcid){
        $tstatus ="<TR><TD bgcolor=$TD_C2>$tname</TD><TD bgcolor=$TD_C3 align=right>$tlv</TD><TD bgcolor=$TD_C2>$ELE[$tele]</TD><TD bgcolor=$TD_C3>$SYOKU[$tclass]</TD></TR>";
	}
	$townid = $in{'town'}%10;
	open(IN,"$CHARA_DATA_LIST");
	@O_DATA = <IN>;
	close(IN);

	@tmp = map {(split /<>/)[18]} @O_DATA;
	@O_DATA = @O_DATA[sort {$tmp[$b] <=> $tmp[$a]} 0 .. $#tmp];
	$j=0;
	foreach(@O_DATA){
	($scid,$scpass,$scname,$scurl,$scchara,$scsex,$schp,$scmaxhp,$scmp,$scmaxmp,$scele,$scstr,$scvit,$scint,$scmen,$scagi,$sccom,$scgold,$sc_ex,$sccex,$scunit,$sccon,$scarm,$scpro,$scacc,$scsub1,$scsub2,$sctac,$scsta,$scpos,$scmes,$schost,$scdate,$scsyo,$scclass,$sctotal,$sckati) = split(/<>/);
		if($kid ne $scid){
			$slv = int($sc_ex/100)+1;
			if($scsex){$_s="��";}else{$_s="��";}
		$Value=int(($scmaxhp/2)+($scmaxmp/2)+($scstr*50)+($scvit*50)+($scint*30)+($scmen*5)+($scagi*50))*$SALARY*3;
			$Salary=int($Value/100);
			$list .= "<TR><TD bgcolor=$TD_C1><input type=radio name=select value=$scid></TD><TD bgcolor=$TD_C2>$scname</TD><TD bgcolor=$TD_C3><img src=\"$IMG/$scchara.gif\" width=\"$img_wid\" height=\"$img_height\"></TD><TD bgcolor=$TD_C2 align=\"center\">$_s</TD><TD bgcolor=$TD_C3 align=\"right\">Lv $slv</TD><TD bgcolor=$TD_C2 align=\"center\">$ELE[$scele]</TD><TD bgcolor=$TD_C3>$scmaxhp/$scmaxhp</TD><TD bgcolor=$TD_C2>$scmaxmp/$scmaxmp</TD><TD bgcolor=$TD_C3>$scstr</TD><TD bgcolor=$TD_C2>$scvit</TD><TD bgcolor=$TD_C3>$scint</TD><TD bgcolor=$TD_C2>$scmen</TD><TD bgcolor=$TD_C3>$scagi</TD><TD bgcolor=$TD_C2>$Value Gold</TD><TD bgcolor=$TD_C3>$Salary</TD></TR>";
		}
		if($j > 100){last;}
		$j++;
	}
	&HEADER;
	print <<"EOM";
<table width="100%" height=100% cellpadding="0" cellspacing="0" border=0><tr><td bgcolor=$TABLE_C>
<TABLE WIDTH="100%" height=100% border=0 cellpadding="3" cellspacing="2"><TBODY>
<TR>
<TD BGCOLOR=$TD_C1 WIDTH=100% height=5> <font size=4> ����<B>���� ���� �Ұ� �ȳ���</B>����</font></TD>
</TR>
<TR>
<TD bgcolor=$TD_C4 height=5>
<TABLE border="0"><TBODY>
<TR>
<TD bgcolor=$TD_C1><img src="$IMG/$kchara.gif" width="$img_wid" height="$img_height" alt="$kname"></TD>
<TD bgcolor=$TD_C2>$simg</TD>
<TD bgcolor=$TD_C3>$timg</TD>
<TD bgcolor=$TD_C4 align=center>
<table cellpadding="0" cellspacing="0" border=0><tr><td bgcolor=$TABLE_C>
<TABLE border="0" cellpadding="3" cellspacing="1"><TBODY>
<TR>
<TD bgcolor=$TD_C2>�̸�</TD>
<TD bgcolor=$TD_C3>LV</TD>
<TD bgcolor=$TD_C2>�Ӽ�</TD>
<TD bgcolor=$TD_C3>����</TD>
</TR>
<TR>
<TD bgcolor=$TD_C2>$kname</TD>
<TD bgcolor=$TD_C3 align=right>$klv</TD>
<TD bgcolor=$TD_C2>$ELE[$kele]</TD>
<TD bgcolor=$TD_C3>$SYOKU[$kclass]</TD>
</TR>
$sstatus$tstatus<TR>
<TD bgcolor=$TD_C2>������</TD>
<TD bgcolor=$TD_C1 colspan=3 align=right>$kgold G</TD>
</TR>
</TBODY></TABLE>
</td></tr></table>
</TD>
</TR>
</TBODY></TABLE>
</TD>
</TR>
<TR>
<TD bgcolor=$TD_C4 height="5">
<TABLE bgcolor=$TABLE_C  border="0">
<TBODY>
<TR>
<TD width="100%" bgcolor=$TALK_BG><font color=$TALK_FONT>$ALL_MES[7]</font></TD>
<TD bgcolor=$TD_C1><img src="$IMG/etc/29.gif" width="$img_wid" height="$img_height"></TD>
</TR>
</TBODY>
</TABLE>
</TD>
</TR><form action="$FILE_TOWN" method="post">
<TR>
<TD bgcolor=$TD_C4>
<table cellpadding="0" cellspacing="0" border=0><tr><td bgcolor=$TABLE_C>
<TABLE border="0">
<TBODY>
<TR><TR><TD bgcolor=$TD_C1>����</TD><TD bgcolor=$TD_C2>�̸�</TD><TD bgcolor=$TD_C3>ĳ����</TD><TD bgcolor=$TD_C2>����</TD><TD bgcolor=$TD_C3>����</TD><TD bgcolor=$TD_C2>�Ӽ�</TD><TD bgcolor=$TD_C3>HP</TD><TD bgcolor=$TD_C2>MP</TD><TD bgcolor=$TD_C3>��</TD><TD bgcolor=$TD_C2>������</TD><TD bgcolor=$TD_C3>����</TD><TD bgcolor=$TD_C2>���ŷ�</TD><TD bgcolor=$TD_C3>��ø��</TD><TD bgcolor=$TD_C2>���� �ݾ�</TD><TD bgcolor=$TD_C3>��</TD></TR>
$list
</TR>
<TR><TD align=center colspan=16>
<input type=hidden name=id value=$kid>
<input type=hidden name=pass value=$kpass>
<input type=hidden name=mode value=SUB_MAKE_GUEST>
<input type=submit value="�����Ѵ�">
</TD></TR></form>
</TBODY></TABLE>
</td></tr></table>
<form action="$FILE_STATUS" method="post">
<input type=hidden name=id value=$kid>
<input type=hidden name=pass value=$kpass>
<input type=hidden name=mode value=STATUS>
<input type=submit value="���� ȭ������"></form>
</TD>
</TR>
</TBODY></TABLE>
</td></tr></table>
EOM

	&FOOTER;
	exit;
}
1;