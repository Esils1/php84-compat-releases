#_/_/_/_/_/_/_/_/_/#
#_/  ü��ȸ��    _/#
#_/_/_/_/_/_/_/_/_/#

sub RECOVERY{

	&CHARA_OPEN;
	if($in{'inn_gold'} > $kgold){$kgold = 0;}else{
		$kgold-=$in{'inn_gold'};
	&TOWN_DATA_OPEN;
	$zmoney += $in{'inn_gold'};
	&TOWN_DATA_INPUT;
	}

	$khp=$kmaxhp;
	$shp=$smaxhp;
	$thp=$tmaxhp;

	$kmp=$kmaxmp;
	$smp=$smaxmp;
	$tmp=$tmaxmp;

	&CHARA_INPUT;
	&HEADER;
	print <<"EOM";
<CENTER><hr size=0><h2>ü���� ȸ���߽��ϴ�.</h2><p>

<form action="$FILE_STATUS" method="post">
<input type=hidden name=id value=$kid>
<input type=hidden name=pass value=$kpass>
<input type=hidden name=mode value=STATUS>
<input type=submit value="������ ���ư���"></form></CENTER>
EOM
	&FOOTER;
	exit;
	
}
1;