#_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/#
#_/      ������ȸ ���ȸ��      _/#
#_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/#

sub TEAM_BATTLE_ENTRY {

	&CHARA_OPEN;
	if($scid){
        $sstatus ="<TR><TD bgcolor=$TD_C2>$sname</TD><TD bgcolor=$TD_C3 align=right>$slv</TD><TD bgcolor=$TD_C2>$ELE[$sele]</TD><TD bgcolor=$TD_C3>$SYOKU[$sclass]</TD></TR>";
	}
	if($tcid){
        $tstatus ="<TR><TD bgcolor=$TD_C2>$tname</TD><TD bgcolor=$TD_C3 align=right>$tlv</TD><TD bgcolor=$TD_C2>$ELE[$tele]</TD><TD bgcolor=$TD_C3>$SYOKU[$tclass]</TD></TR>";
	}
	$townid = $in{'town'}%10;
	&HEADER;
	print <<"EOM";
<table width="100%" height=100% cellpadding="0" cellspacing="0" border=0><tr><td bgcolor=$TABLE_C>
<TABLE WIDTH="100%" height=100% border=0 cellpadding="3" cellspacing="2"><TBODY>
<TR>
<TD BGCOLOR=$TD_C1 WIDTH=100% height=5> <font size=4> ����<B>õ�� ������ȸ ��� ������</B>����</font></TD>
</TR>
<TR>
<TD bgcolor=$TD_C4 height=5>
<TABLE border="0"><TBODY>
<TR>
<TD bgcolor=$TD_C1><img src="$IMG/$kchara.gif" width="$img_wid" height="$img_height" alt="$kname"></TD>
<TD bgcolor=$TD_C2>$simg</TD>
<TD bgcolor=$TD_C3>$timg</TD>
<TD bgcolor=$TD_C4 align=center>
<table cellpadding="0" cellspacing="0" border=0><tr><td bgcolor=$TABLE_C>
<TABLE border="0" cellpadding="3" cellspacing="1"><TBODY>
<TR>
<TD bgcolor=$TD_C2>�̸�</TD>
<TD bgcolor=$TD_C3>LV</TD>
<TD bgcolor=$TD_C2>�Ӽ�</TD>
<TD bgcolor=$TD_C3>����</TD>
</TR>
<TR>
<TD bgcolor=$TD_C2>$kname</TD>
<TD bgcolor=$TD_C3 align=right>$klv</TD>
<TD bgcolor=$TD_C2>$ELE[$kele]</TD>
<TD bgcolor=$TD_C3>$SYOKU[$kclass]</TD>
</TR>
$sstatus$tstatus<TR>
<TD bgcolor=$TD_C2>������</TD>
<TD bgcolor=$TD_C1 colspan=3 align=right>$kgold G</TD>
</TR>
</TBODY></TABLE>
</td></tr></table>
</TD>
</TR>
</TBODY></TABLE>
</TD>
</TR>
<TR>
<TD bgcolor=$TD_C4 height="5">
<TABLE bgcolor=$TABLE_C  border="0">
<TBODY>
<TR>
<TD width="100%" bgcolor=$TALK_BG><font color=$TALK_FONT>$ALL_MES[8]<BR>1����� 1���� ������ ��ϵ˴ϴ�.</font></TD>
<TD bgcolor=$TD_C1><img src="$IMG/etc/31.gif" width="$img_wid" height="$img_height"></TD>
</TR>
</TBODY>
</TABLE>
</TD>
</TR>
<TR>
<TD bgcolor=$TD_C4>��õ�� ������ȸ�ڵ����<BR>
<table cellpadding="0" cellspacing="0" border=0><tr><td bgcolor=$TABLE_C>
<table bgcolor=$TABLE_C><TBODY><TR><TD bgcolor=$TD_C3>�δ��</TD><TD bgcolor=$TD_C1>����</TD><TD bgcolor=$TD_C2>�̸�</TD><TD bgcolor=$TD_C1>����1</TD><TD bgcolor=$TD_C2>�̸�</TD><TD bgcolor=$TD_C1>����2</TD><TD bgcolor=$TD_C2>�̸�</TD>
EOM
	open(IN,"$TEAM_OK_LIST") or &ERR("���� �б� ����");
	@OK_DATA = <IN>;
	close(IN);

	foreach(@OK_DATA){
		($fid1,$fname1,$fchara1,$fid2,$fname2,$fchara2,$fid3,$fname3,$fchara3,$funit)=split(/<>/);
		$pain .= "<TR><TD BGCOLOR=$TD_C4>$funit �δ�</TD><TD BGCOLOR=$TD_C1><img src=\"$IMG/$fchara1.gif\" width=\"$img_wid\" height=\"$img_height\" alt=\"$fname1\"></TD><TD BGCOLOR=$TD_C3>$fname1</TD><TD BGCOLOR=$TD_C1><img src=\"$IMG/$fchara2.gif\" width=\"$img_wid\" height=\"$img_height\" alt=\"$fname2\"></TD><TD BGCOLOR=$TD_C3>$fname2</TD><TD BGCOLOR=$TD_C1><img src=\"$IMG/$fchara3.gif\" width=\"$img_wid\" height=\"$img_height\" alt=\"$fname3\"></TD><TD BGCOLOR=$TD_C3>$fname3</TD></TR>";
	}

print <<"EOM";
$pain</TR></TBODY></TABLE>
</td></tr></table>

<hr size=0>
<form action="$FILE_TOWN" method="post">
<h3>$kunit �δ뿡 ����� ����</h3>

EOM

	open(IN,"$CHARA_DATA_LIST") or &ERR('���� �б� ����');
	@S_CHARA = <IN>;
	close(IN);

	open(IN,"$UNIT_LIST") or &ERR("���� �б� ����");
	@UNI_DATA = <IN>;
	close(IN);

	open(IN,"$COUNTRY_LIST") or &ERR("���� �б� ����");
	@COU = <IN>;
	close(IN);

	$rhit=0;
	foreach(@UNI_DATA){
		($unit_id,$uunit_name,$ucon,$ureader,$uid,$uname,$uchara,$umes)=split(/<>/);
		if("$unit_id" eq "$kid"){$rhit=1;}
		if($kid eq "$unit_id" && $kcon eq "$ucon" && !$ureader){
			$mess1 .= "<option value=$uid>$uname��\n";
			$mess2 .= "<option value=$uid>$uname��\n";
		}
	}

	$chit=0;
	foreach(@COU){
		($xxcid,$xxname,$xxele,$xxnum,$xxins,$xxind,$xxall,$xxgold,$xxhp,$xxmaxhp,$xxstr,$xxvit,$xxagi)=split(/<>/);
		if($xxcid eq $kcon){
			$chit=1;
		}
	}

	if($kunit ne "���Ҽ�" && $chit && $rhit){
		print "<select name=ok_id1>";
		print "$mess1";
		print "</select>\n��";
		print "<select name=ok_id2>";
		print "$mess2";
		print "</select>\n";
	}else{
		print "<font color=red>�δ���ܿ� ����� �� �����ϴ�. (���Ҽӱ� ��ϺҰ�)</font><BR>";
	}


print <<"EOM";
<input type=hidden name=id value=$kid>
<input type=hidden name=name value=$kname>
<input type=hidden name=pass value=$kpass>
<input type=hidden name=mode value=TEAM_OK>
<BR><input type=submit value="��ʸ�Ʈ�� ���"><br>
</form>
<HR size=0>
EOM
if($rhit){
print <<"_WOR_";
	<form action="$FILE_TOWN" method="post">
	<input type=hidden name=id value=$kid>
	<input type=hidden name=name value=$kname>
	<input type=hidden name=pass value=$kpass>
	<input type=hidden name=mode value=TEAM_OFF>
	<BR><input type=submit value="������"><br></form>
	<HR size=0>
_WOR_
	}
print <<"EOM";
<form action="$FILE_STATUS" method="post">
<input type=hidden name=id value=$kid>
<input type=hidden name=pass value=$kpass>
<input type=hidden name=mode value=STATUS>
<input type=submit value="������ ���ư���"></form>
</TD>
</TR>
</TBODY></TABLE>
</td></tr></table>
EOM

	&FOOTER;
	exit;
}
1;