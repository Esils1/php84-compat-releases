#_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/#
#_/          ������ȸ��        _/#
#_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/#

sub TEAM_BATTLE {

	&CHARA_OPEN;
	$townid = $in{'town'}%10;
	
	&TEAM_BATTLE_TIME;

	open(IN,"$TEAM_WINNER_LIST");
	@WINNER_LIST = <IN>;
	close(IN);
	$win_num = @WINNER_LIST;

	$i=0;
	foreach(@WINNER_LIST){
		($pwin_id,$p_name1,$p_name2,$p_name3,$p_chara1,$p_chara2,$p_chara3,$p_unit,$p_con)=split(/<>/);			if($i eq "0"){$last_unit = $p_unit;}
		$w_table .= "<TR><TD bgcolor=$TD_C4><TABLE width=100% BGCOLOR=$TD_C1><TBODY><TR><TD bgcolor=$TD_C1 colspan=3><B>$p_unit �δ�</TD></TR><TH bgcolor=$TD_C4><img src=\"$IMG/$p_chara1.gif\" width=\"$img_wid\" height=\"$img_height\" alt=\"$p_name1\"><BR>$p_name1</TH><TH bgcolor=$TD_C2><img src=\"$IMG/$p_chara2.gif\" width=\"$img_wid\" height=\"$img_height\" alt=\"$p_name2\"><BR>$p_name2</TH><TH bgcolor=$TD_C3><img src=\"$IMG/$p_chara3.gif\" width=\"$img_wid\" height=\"$img_height\" alt=\"$p_name3\"><BR>$p_name3</TH></TBODY></TABLE></TD></TR>";
		if($i >= 5){last;}
		$i++;
	}
	if(!$wday){$entry = "��ȸ�Ⱓ�߿� ����� �� �����ϴ�.";}else{$entry = "<input type=submit value=\"���ȸ��\">";}

	if($last_unit eq ""){$last_unit = " ______ ";}
	&HEADER;
	print <<"EOM";
<table width="100%" height=100% cellpadding="0" cellspacing="0" border=0><tr><td>
<TABLE WIDTH="100%" height=100% border=0 cellpadding="3" cellspacing="2"><TBODY>
<TR>
<TD BGCOLOR=$TD_C1 WIDTH=100% height=5> <font size=4> ����<B> õ �� �� �� �� ȸ �� </B>����</font></TD>
</TR>
<TR>
<TD bgcolor=$TD_C4 height=5>
<TABLE border="0"><TBODY>
<TR>
<TD bgcolor=$TD_C1><img src="$IMG/$kchara.gif" width="$img_wid" height="$img_height" alt="$kname"></TD>
<TD bgcolor=$TD_C2>$simg</TD>
<TD bgcolor=$TD_C3>$timg</TD>
<TD bgcolor=$TD_C4 align=center>
<table cellpadding="0" cellspacing="0" border=0><tr><td bgcolor=$TABLE_C>
<TABLE border="0" cellpadding="3" cellspacing="1"><TBODY>
<TR>
<TD bgcolor=$TD_C2>�̸�</TD>
<TD bgcolor=$TD_C3>LV</TD>
<TD bgcolor=$TD_C2>�Ӽ�</TD>
<TD bgcolor=$TD_C3>����</TD>
</TR>
<TR>
<TD bgcolor=$TD_C2>$kname</TD>
<TD bgcolor=$TD_C3 align=right>$klv</TD>
<TD bgcolor=$TD_C2>$ELE[$kele]</TD>
<TD bgcolor=$TD_C3>$SYOKU[$kclass]</TD>
</TR>
<TR>
<TD bgcolor=$TD_C2>������</TD>
<TD bgcolor=$TD_C1 colspan=3 align=right>$kgold G</TD>
</TR>
</TBODY></TABLE>
</td></tr></table>
</TD>
</TR>
</TBODY></TABLE>
</TD>
</TR>
<TR>
<TD bgcolor=$TD_C4 height="5">
<TABLE bgcolor=$TABLE_C  border="0">
<TBODY>
<TR>
<TD width="100%" bgcolor=$TALK_BG><font color=$TALK_FONT>$ALL_MES[8]</font></TD>
<TD bgcolor=$TD_C1><img src="$IMG/etc/31.gif" width="$img_wid" height="$img_height"></TD>
</TR>
</TBODY>
</TABLE>
</TD>
</TR>
<TR>
<TD><p align=center>$battle_mes<BR><p align=center><B class=dmg>�����</B><BR>
<table align=center cellpadding="0" cellspacing="0" border=0><tr><td>
<table cellspacing=10><TBODY>
EOM
	open(IN,"$TEAM_OK_LIST") or &ERR("���� �б� ����");
	@OK_DATA = <IN>;
	close(IN);

	$pain = "<TR><Th bgcolor=$TD_C3 colspan=3>���� ��� ���<font color=red>(�ؼ�������)</font></Th></TR><TR>";
	$i=0;
	foreach(@OK_DATA){
		($fid1,$fname1,$fchara1,$fid2,$fname2,$fchara2,$fid3,$fname3,$fchara3,$funit)=split(/<>/);
		$pain .= "<TD bgcolor=$TD_C4><TABLE width=100% BGCOLOR=$TD_C1><TBODY><TR><TD bgcolor=$TD_C1 colspan=3><B>$funit �δ�</TD></TR><TH bgcolor=$TD_C4><img src=\"$IMG/$fchara1.gif\" width=\"$img_wid\" height=\"$img_height\" alt=\"$fname1\"><BR>$fname1</TH><TH bgcolor=$TD_C2><img src=\"$IMG/$fchara2.gif\" width=\"$img_wid\" height=\"$img_height\" alt=\"$fname2\"><BR>$fname2</TH><TH bgcolor=$TD_C3><img src=\"$IMG/$fchara3.gif\" width=\"$img_wid\" height=\"$img_height\" alt=\"$fname3\"><BR>$fname3</TH></TBODY></TABLE></TD>";
		if($i % 2){
			$pain .= "</TR><TR>";
		}
		$i++;
	}
	while($i < 8){
		$pain .= "<TD BGCOLOR=$TD_C2> - </TD>";
		if($i % 2){
			$pain .= "</TR><TR>";
		}
		$i++;
	}
	$pain .= "</TR>";

print <<"EOM";
$pain</TBODY></TABLE>$ran_no
</td></tr></table>
<TABLE bgcolor=$TABLE_C><TBODY><TR>
EOM
	$i=1;
while($last_battle>=$i || $c_count>=$i){
	$battle_link .= "<TD bgcolor=$TD_C2>$maru[$i]<a href=$HTML_FILE/battle$i.htm target=\"_blank\">��$i����</a></TD>";
	$i++;
}
print <<"EOM";
$battle_link</TR></TBODY></TABLE>
<font color=blue size=3><b>�� $next_mes</b><BR><BR><b class=dmg>��ȸ ����ڴ� <font color=orange>$last_unit��</font>�Դϴ�.</b></font>
<hr size=0>
<CENTER>
<table cellspacing=10 bgcolor=$TD_C4><TBODY>
<TR><Th bgcolor=$TD_C2><font color=red>-- ���� ����� --</font></Th></TR>
$w_table
</TBODY></TABLE>
</CENTER>
<hr size=0>
<form action="$FILE_TOWN" method="post">
<input type=hidden name=id value=$kid>
<input type=hidden name=name value=$kname>
<input type=hidden name=pass value=$kpass>
<input type=hidden name=mode value=TEAM_BATTLE_ENTRY>
<BR>$entry<br>
</form>
<HR size=0>
<form action="$FILE_STATUS" method="post">
<input type=hidden name=id value=$kid>
<input type=hidden name=pass value=$kpass>
<input type=hidden name=mode value=STATUS>
<input type=submit value="������ ���ư���"></form>
</TD>
</TR>
</TBODY></TABLE>
</td></tr></table>
EOM

	&FOOTER;
	exit;
}

#_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/#
#_/   ������ȸ�� ���� ī��Ʈ _/#
#_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/#

sub TEAM_BATTLE_TIME {

	require './battle/battle3.pl';

	&TIME_DATA;

	open(IN,"$TEAM_TIME_LIST");
	@time_check = <IN>;
	close(IN);
	($lasttime,$battle_count,$c_count,$last_battle) = split(/<>/,$time_check[0]);

	$battle3_time = 12;
	if(!$wday && $hour > $battle3_time){
#	if($hour > $battle3_time){

		open(IN,"$TEAM_OK_LIST") or &ERR("���� �б� ����");
		@OK_DATA = <IN>;
		close(IN);
		$bum = @OK_DATA;

		if($bum > 1){
			$next_time = $TEN_BATTLE_TIME + ($lasttime - $tt);
			if($battle_count eq ""){$battle_count = 1;}
			$battle_mes = "<b class=clit>�� $battle_count ȸ õ�� ������ȸ</b>";
			if($next_time > 0){
				$next_min = int($next_time/60);
				if($lasttime ne ""){
					$next_bat = $c_count+1;
					$next_mes = "���� �� $next_bat ���ձ��� $next_time��(<font color=red>�� $next_min��</font>) ��ٷ� �ּ���.";
				}else{
					$next_mes = "���� ���ձ��� ��ø� ��ٷ� �ּ���.";
				}
			}else{
				&BATTLE3;
				$next_mes = "���� ����!";
			}
			$maru[$c_count] = "<font color=blue>��</font>";
		}else{
			$next_mes = "���� ������ ��� ����ƽ��ϴ�.";
		}
	}else{
		$next_mes = "���� ������ �Ͽ��� $battle3_time���Ŀ� �ǽõ˴ϴ�.";	
	}

}
1;