#_/_/_/_/_/_/_/_/_/#
#_/    ����    _/#
#_/_/_/_/_/_/_/_/_/#

sub PRO_SHOP {

	&CHARA_OPEN;&TIME_DATA;&TOWN_DATA_OPEN($kpos);

	if($hour<=7 && $hour>=1 || $hour<=15 && $hour>=13){$val_off= 0.95;$pro_mes="<B><font color=red size=4>5% ����!</font></B>";
	}elsif($hour>=20 && $hour<= 21){$val_off = 1.1;$pro_mes = "<B><font color=red size=4>10% �λ�!</font></B>";
	}elsif($hour>17){$val_off = 1.05;$pro_mes = "<B><font color=red size=4>5% �λ�!</font></B>";
	}else{$val_off = 1;}


	open(IN,"$PRO_LIST");@PRO_DATA = <IN>;close(IN);$s_i = 0;
	foreach(@PRO_DATA){
		($proname,$protai,$prodmg,$prowei,$proele,$prosta,$proclass,$protownid) = split(/<>/);
		if($protownid eq $in{'town'} || $protownid eq "0"){
			if($protai eq ""){
				$list .= "<TR><TH align=center colspan=7 bgcolor=$TD_C4>$proname</TH></TR>";
			}else{
				if($prodmg/2 <= $prowei){$wei=0;}else{$wei=($prodmg-$prowei);}
				$proval = int(((5000000*($prodmg**2))+(50000000*($wei**2)))/(255**2));
				if($zpro * 1000 > $protai || $zpro >= 999){
					$proval = int($proval * $val_off * $SHOP_BUY / 5);
					$list .= "<TR><TD bgcolor=$TD_C1><input type=radio name=select value=$s_i></TD><TH bgcolor=$ELE_C[$proele]>$proname</TH><TD align=right bgcolor=$TD_C3>$proval Gold</TD><TD bgcolor=$TD_C2>$prodmg</TD><TD bgcolor=$TD_C3>$prowei</TD><TD bgcolor=$TD_C3>$protai</TD><TD bgcolor=$TD_C2>$ELE[$proele]</TD></TR>";
				}
			}
		}
	$s_i++;
	}

	open(IN,"$ARM_LIST") or &ERR('���� �б� ���� [ITEM1]');
	@ARM_DATA = <IN>;
	close(IN);
	open(IN,"$PRO_LIST") or &ERR('���� �б� ���� [ITEM2]');
	@PRO_DATA = <IN>;
	close(IN);
	open(IN,"$ACC_LIST") or &ERR('���� �б� ���� [ITEM3]');
	@ACC_DATA = <IN>;
	close(IN);
	open(IN,"$ITEM_LIST") or &ERR('���� �б� ���� [ITEM3]');
	@ITEM_DATA = <IN>;
	close(IN);

	open(IN,"./charalog/item/$in{'id'}.cgi");
	@C_ITEM = <IN>;close(IN);$i=0;
	foreach(@C_ITEM){
		($it_mark,$it_no,$it_name,$it_tai,$it_dmg,$it_sta,$it_wei) = split(/<>/);
		if($it_dmg/2 <= $it_wei){$wei=0;}else{$wei=($it_dmg-$it_wei);}
		$it_val = int(((5000000*($it_dmg**2))+(50000000*($wei**2)))/(255**2));

		if($it_mark eq 0){
			$list_name = $ARM_DATA[$it_no];
		}elsif($it_mark eq 1){
			$list_name = $PRO_DATA[$it_no];
		}elsif($it_mark eq 2){
			$list_name = $ACC_DATA[$it_no];
		}elsif($it_mark eq 3){
			$list_name = $ITEM_DATA[$it_no];
		}
		($wname,$wval,$wdmg,$wwei,$wele,$wsta,$wclass,$wtownid) = split(/<>/,$list_name);
		if($wval eq 0 || $wval eq ""){$wval = 1;}
		$s_val = int($it_val*$SHOP_SELL*$val_off*($it_tai/$wval));
		if($it_sta eq 11){
			$star = "��";
		}else{
			$star = "";
		}

		if($it_mark eq 3 && $it_no eq 0 || $it_mark eq 3 && $it_no eq 1){$it_tai=1;}
		$pro_p .= "<TR><TD bgcolor=$TD_C1><input type=radio name=select value=$i></TD><TH bgcolor=$TD_C2>$star</TH><TD bgcolor=$TD_C2>$it_name</TD><TD bgcolor=$TD_C3>$ITEM_NO[$it_mark]</TD><TD bgcolor=$TD_C1 align=right>$it_dmg</TD><TD bgcolor=$TD_C1 align=right>$it_wei</TD><TD bgcolor=$TD_C1 align=right>$it_tai/$wval</TD><TD align=right bgcolor=$TD_C4>$s_val Gold</TD></TR>";
		$i++;
	}
	$it_num = @C_ITEM;
	$it_num = $ITEM_MAX -$it_num;
	for($z=1;$z<$it_num;$z++){
		$it_num .= "<option value=$z>$z";
	}

	&HEADER;


	print <<"EOM";
<table width="100%" cellpadding="0" cellspacing="0" border=0><tr><td>
<TABLE WIDTH="100%" border=0><TBODY><TR><TD BGCOLOR=$TD_C1 WIDTH=100% height=5> <font size=4>�������� <B>����</B> �ӡ�����</font> $pro_mes</TD></TR><TR><TD height=5><TABLE border="0"><TBODY><TR><TD><img src="$IMG/$kchara.gif" width="$img_wid" height="$img_height" alt="$kname"></TD><TD WIDTH=25% align=center>
<table cellpadding="0" cellspacing="0" border=0><tr><td>
<TABLE bgcolor=$TABLE_C border="0" cellspacing=1><TBODY><TR><TD bgcolor=$TD_C2>�̸�</TD><TD bgcolor=$TD_C3>LV</TD><TD bgcolor=$TD_C2>�Ӽ�</TD><TD bgcolor=$TD_C3>����</TD></TR><TR><TD bgcolor=$TD_C2>$kname</TD><TD bgcolor=$TD_C3 align=right>$klv</TD><TD bgcolor=$TD_C2>$ELE[$kele]</TD><TD bgcolor=$TD_C3>$SYOKU[$kclass]</TD></TR>$sstatus$tstatus<TR><TD bgcolor=$TD_C2>������</TD><TD bgcolor=$TD_C1 colspan=3 align=right>$kgold GOLD</TD></TR></TBODY></TABLE></td></tr></table></TD>

<TD WIDTH=100% align=center><form action="$FILE_TOWN" method="post"><TABLE bgcolor=$TABLE_C border="0" cellspacing=1><TBODY bgcolor=$TD_C4><TR><Th bgcolor=$TD_C1>����</Th><Th bgcolor=$TD_C2>���</Th><Th bgcolor=$TD_C2>���� ������</Th>
<Th bgcolor=$TD_C3>����</Th><Th bgcolor=$TD_C1>����</Th><Th bgcolor=$TD_C1>����</Th><Th bgcolor=$TD_C1>����</Th><Th bgcolor=$TD_C4>�ǸŰ�</Th></TR>

$pro_p

<TR><TD colspan=8><input type=hidden name=id value=$kid><input type=hidden name=pass value=$kpass><input type=hidden name=val_off value=$val_off><input type=hidden name=mode value=SELL><input type=submit value="�������� �Ǵ�"></TR></TD></TBODY></TABLE></TD></TR></TBODY></TABLE></TD></TR></form><TR><TD bgcolor=$TD_C4 height="5"><TABLE bgcolor=$TABLE_C  border="0"><TBODY><TR><TD width="100%" bgcolor=$TALK_BG><font color=$TALK_FONT>$ALL_MES[3]</font></TD><TD bgcolor=$TD_C4><img src="$IMG/etc/21.gif" width="$img_wid" height="$img_height" alt="���� ����"></TD></TR>
</TBODY></TABLE></TD></TR><form action="$FILE_TOWN" method="post">

<TR><TD align=center>
<table cellpadding="0" cellspacing="0" border=0><tr><td bgcolor=$TABLE_C>
<TABLE bgcolor=$TABLE_C border="0" cellspacing=1><TBODY bgcolor=$TD_C1><TR><TH bgcolor=$TD_C1>����</TH><TH bgcolor=$TD_C2>�̸�</TH><TH bgcolor=$TD_C3>����</TH><TH bgcolor=$TD_C2>����</TH><TH bgcolor=$TD_C3>����</TH><TH bgcolor=$TD_C3>����</TH><TH bgcolor=$TD_C2>�Ӽ�</TH></TR>
$list
</TR>
<TR><TD align=center colspan=7><input type=hidden name=townid value=$in{'town'}><input type=hidden name=id value=$kid><input type=hidden name=pass value=$kpass><input type=hidden name=val_off value=$val_off><input type=hidden name=mark value=1><input type=hidden name=mode value=BUY><select name=num>$it_num</select><input type=submit value="���"></TD></TR></form></TBODY></TABLE></td></tr></table>

<form action="$FILE_STATUS" method="post"><input type=hidden name=id value=$kid><input type=hidden name=pass value=$kpass><input type=hidden name=mode value=STATUS><input type=submit value="������ ���ư���"></form></TD></TR></TBODY></TABLE>
</td></tr></table>
EOM
	&FOOTER;
	exit;
}
1;