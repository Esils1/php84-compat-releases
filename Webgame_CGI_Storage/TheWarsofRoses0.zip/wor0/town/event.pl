#_/_/_/_/_/_/_/_/_/#
#_/  �̺�Ʈ  _/#
#_/_/_/_/_/_/_/_/_/#

sub EVENT{

	&CHARA_MAIN_OPEN;
	&COUNTRY_DATA_OPEN("$kcon");

	open(IN,"./charalog/item/$in{'id'}.cgi");
	@C_ITEM = <IN>;
	close(IN);
	$it_num = @C_ITEM;

		@NEW_ITEM=();
		foreach(@C_ITEM){
			($it_mark,$it_no,$it_name,$it_val,$it_dmg,$it_sta,$it_wei) = split(/<>/);
			if($it_mark eq 3 && $it_no eq 2){
			$item_mes = "$it_name(��)�� ����߽��ϴ�.<br>";
			push(@NEW_ITEM,"3<>10<>�¾��� ��<>0<>0<>0<>0<>\n");
			}else{
			push(@NEW_ITEM,"$_");
			}
		}

	open(OUT,">./charalog/item/$in{'id'}.cgi");
	print OUT @NEW_ITEM;
	close(OUT);


	&HEADER;
	print <<"EOM";
<CENTER><hr size=0><h2>$item_mes<font color=red>�¾��� ���� �տ� �־����ϴ�.</font></h2><p>

<form action="$FILE_STATUS" method="post">
<input type=hidden name=id value=$kid>
<input type=hidden name=pass value=$kpass>
<input type=hidden name=mode value=STATUS>
<input type=submit value="������ ���ư���"></form></CENTER>
EOM
	&FOOTER;
	exit;
	
}
1;