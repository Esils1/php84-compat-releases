#_/_/_/_/_/_/_/_/_/#
#_/   ���� �ۼ�   _/#
#_/_/_/_/_/_/_/_/_/#
sub ARM_MAKE {
	&CHARA_MAIN_OPEN;
	$date = time();
	$s_time = $date - $kdate;
	if($s_time < $BATTLE_TIME){$s_time = $BATTLE_TIME - $s_time;&ERR("���� �������� $s_time �� ��ٷ� �ּ���.");}

	if(length($in{'newname'}) > 16) { &ERR("������� �ʹ� ��ϴ�. (8���̳�)"); }

	open(IN,"./charalog/item/$in{'id'}.cgi");
	@C_ITEM = <IN>;close(IN);$hit=0;
	$i=0;
	foreach(@C_ITEM){
		if($in{"select$i"} ne ""){$hit=1;}
		$i++;
	}
	if(!$hit){&ERR("�� ���� ���� �����ϴ�.");}

	$arm_id = $in{'id'};
	$arm_pass = $in{'pass'};
	$azuke = $in{'azukeru'};

	if($azuke < 0) { &ERR("������ �Է��� �� �����ϴ�."); }
	else { $azukeru = int($azuke) * 10000; }
	&HOST_NAME;


	if(int($azuke) * 10000 > $kgold) { &ERR("���� �����մϴ�."); }
	else { $kgold = $kgold - $azukeru; }

	$date = time();

	if($lockkey) { &F_LOCK; }

	open(IN,"./charalog/arm/$in{'id'}.cgi");
	@MY_ARM_DATA = <IN>;
	close(IN);

	$si = 0;


	@NEW_C_ITEM = @C_ITEM;
	for($i=0;$i<$ITEM_MAX;$i++){
		$select[$i] =$in{"select$i"};
		if("$select[$i]" eq ""){next;}
		@C_ITEM = @NEW_C_ITEM;
		@NEW_C_ITEM=();$hit=0;
		foreach(@C_ITEM){
			($i_no,$i_id,$i_name,$i_val,$i_dmg,$i_sta,$i_wei) = split(/<>/);
			if($select[$i] eq "$i_id" && "$i_sta" eq "99" && $hit eq "0"){
				$dmgpoint += $i_dmg;
				$weipoint += $i_wei;
				$hit=1;
			}else{
				push(@NEW_C_ITEM,"$_");
			}
		}
	}

	$dmgpoint = int(($dmgpoint + $azuke)/20);
	$weipoint = int(($weipoint + $azuke)/20);

	$lack = int(rand(2));
	if($lack){
		$dmgup = int(rand($dmgpoint));
		$weiup = int(rand($weipoint));
		$dmgup = $dmgpoint;
		$weiup = $weipoint;
		$com .= "<font color=red>���� ���ۿ� �����߽��ϴ�.</font><BR>";
	}else{
		$dmgup = int(-(rand($dmgpoint)));
		$weiup = int(-(rand($weipoint)));
		$com .= "<font color=blue>���� ���ۿ� �����߽��ϴ�.</font><BR>";
	}

	$hit=0;
	@NEW_ARM_DATA=();
	foreach(@MY_ARM_DATA){
		($narmname,$narmval,$narmdmg,$narmwei,$narmele,$narmsta,$narmclass,$narmtownid) = split(/<>/);
		if($narmsta eq "$arm_id") {
			$narmdmg += $dmgup;
			$narmwei += $weiup;
			$hi = $narmdmg - $narmwei;
			if($hi <= 0){ $hi = 1;}
			$narmval = 1;
			if($narmdmg > 255){$narmdmg = 255;}
			if($narmdmg < 0){$narmdmg = 0;}
			if($narmwei < 0){$narmwei = 0;}
			$narmdmg2 = $narmdmg;
			$narmwei2 = $narmwei;
			if($in{'newname'} ne ""){$narmname2 = "$in{'newname'}";}else{$narmname2 = "$narmname";}
			push(@NEW_ARM_DATA,"$narmname2<>$narmval<>$narmdmg<>$narmwei<>$narmele<>$narmsta<>$narmclass<>$narmtownid<>\n");
			$hit=1;
		}else{
			push(@NEW_ARM_DATA,"$_");
		}
	}

	@NEW_C_ITEM2=();
	foreach(@NEW_C_ITEM){
		($i_no,$i_id,$i_name,$i_val,$i_dmg,$i_sta,$i_wei) = split(/<>/);
		if($i_no eq 0 && $i_id eq 1){
			push(@NEW_C_ITEM2,"0<>$i_id<>$narmname2<>$narmval<>$narmdmg<>$i_sta<>$narmwei<>\n");
		}else{
			push(@NEW_C_ITEM2,"$_");
		}
	}


	open(OUT,">./charalog/item/$in{'id'}.cgi");
	print OUT @NEW_C_ITEM2;
	close(OUT);

	if(!$hit){
		open(IN,"./charalog/item/$in{'id'}.cgi");
		@C2_ITEM = <IN>;
		close(IN);
		$it_num = @C2_ITEM;
		if($it_num >= $ITEM_MAX) {&ERR('�� �̻� �������� ���� �� �����ϴ�.');}

		if($dmgup < 0){$dmgup = 0;}
		if($weiup < 0){$weiup = 0;}
		$narmdmg = $dmgup;
		$narmwei = $weiup;
		$hi = $narmdmg - $narmwei;
		if($hi <= 0){ $hi = 1;}
		$narmval = 1;
		if($in{'newname'} eq ""){ $narmname2 = "$kname�� ��";
		}else{$narmname2 = "$in{'newname'}";}
		if($narmdmg > 255){$narmdmg = 255;}
		if($narmdmg < 0){$narmdmg = 0;}
		if($narmwei < 0){$narmwei = 0;}
		$narmdmg2 = $narmdmg;
		$narmwei2 = $narmwei;
		unshift(@NEW_ARM_DATA,"$narmname2<>$narmval<>$dmgup<>$weiup<>0<>$kid<>0<>1000<>\n");
		$ss_no = 1;
		push(@C2_ITEM,"0<>$ss_no<>$narmname2<>$narmval<>$dmgup<>0<>$weiup<>\n");

		open(OUT,">./charalog/item/$in{'id'}.cgi");
		print OUT @C2_ITEM;
		close(OUT);

	}



	&CHARA_MAIN_INPUT;

	open(OUT,">./charalog/arm/$in{'id'}.cgi");
	print OUT @NEW_ARM_DATA;
	close(OUT);

	# �� ����
	if (-e $lockfile) { unlink($lockfile); }

	&HEADER;

print <<"EOM";
<h1>$com <font color=blue>$narmname2</font>(��)�� ���� : $narmdmg2(<font color=red>$dmgup</font>) ���� : $narmwei2(<font color=red>$weiup</font>)�� �Ǿ����ϴ�.</h1>
<hr size=0>
<p>
<form action="$FILE_STATUS" method="post">
<input type=hidden name=id value=$kid>
<input type=hidden name=pass value=$kpass>
<input type=hidden name=mode value=STATUS>
<input type=submit value="������ ���ư���"></form>
EOM

	&FOOTER;
	exit;
}
1;