#―――――――――――――――――――――――――――――――
#※이 스크립트는 갓필드의 신기정보파일 입니다.
#
#	著作:グウジ
#	번역:MAI
#
#	http://red.sakura.ne.jp/~guji/
#	guji@red.sakura.ne.jp
#―――――――――――――――――――――――――――――――
#
#―――――――――――――――――――――――――――――
#신기정보리스트
#―――――――――――――――――――――――――――――
#신기정보의 예
#$Jname[0] = '기도한다';						#이름(한글 9자이하)
#$Jexp[0] = '태양신에게 기도드린다.<BR><BR>';	#설명(한글30자에서 45자이하)
#$Jfirst[0] = "";								#사용시 문장
#$Jsecond[0] = "";								#사용 직후의 문장
#$Jthird[0] = "";								#사용후의 문장(공격명중)
#$Jmiss[0] = "";								#사용후의 문장(공격빗나감)
#$Jtype[0] = 'Solo';							#종류1 (신기의 사용법별)
#$Jkind[0] = 'Pray';							#종류2 (신기의 성질별)
#$Jdetail[0] = "";								#종류3 (더 구체적으로)
#$Jattribute[0] = "";							#속성
#$Jmp[0] = 0;									#기적의 소비MP
#$Jpoint[0] = 0;								#수치1(메인)
#$Jfree[0] = 0;									#수치2(서브)
#$Jprice[0] = 0;								#가격
#$Jtotal[0] = 0;								#총갯수
#$Jimage[0] = 'inoru.jpg';						#이미지명

$I = 0;	#$I = 0;
$Jname[0] = '기도한다';						
$Jexp[0] = '태양신에게 기도드린다.<BR><BR>';	
$Jfirst[0] = "";								
$Jsecond[0] = "";								
$Jthird[0] = "";								
$Jmiss[0] = "";								
$Jtype[0] = 'Solo';							
$Jkind[0] = 'Pray';							
$Jdetail[0] = "";								
$Jattribute[0] = "";							
$Jmp[0] = 0;									
$Jpoint[0] = 0;								
$Jfree[0] = 0;									
$Jprice[0] = 0;								
$Jtotal[0] = 0;								
$Jimage[0] = 'inoru.jpg';						

$I++;	#$I = 1;
$Jname[$I] = '환전';
$Jexp[$I] = 'HP, MP, 돈을 마음대로 분배한다.<BR><BR>';
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'Exchange';
$Jprice[$I] = 150;
$Jtotal[$I] = 20;
$Jimage[$I] = 'ryougae.jpg';

$I++;	#$I = 2;
$Jname[$I] = '판다';
$Jexp[$I] = '자신의 神器 1개를 임의상대에게 강제로 팔아버린다.';
$Jtype[$I] = 'OneMore';
$Jkind[$I] = 'Sell';
$Jprice[$I] = 100;
$Jtotal[$I] = 14;
$Jimage[$I] = 'uru.jpg';

$I++;	#$I = 3;
$Jname[$I] = '산다';
$Jexp[$I] = '상대의 신기중 한개를 랜덤으로 선택해서 살 수가 있다. 선택한 신기를 안사도 된다.';
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'Buy';
$Jprice[$I] = 100;
$Jtotal[$I] = 14;
$Jimage[$I] = 'kau.jpg';

$I++;	#$I = 4;
$Jname[$I] = '금의 곤봉';
$Jexp[$I] = '순금으로된 사치적인 곤봉. 공격력은 낮지만 가격이 높다.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 10;
$Jprice[$I] = 300;
$Jtotal[$I] = 1;
$Jimage[$I] = 'kin_no_kombou.jpg';

$I++;	#$I = 5;
$Jname[$I] = '은의 곤봉';
$Jexp[$I] = '은으로 된 약간 사치적인 곤봉. 공격력이 최저인것에 비해 비싸다.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 10;
$Jprice[$I] = 100;
$Jtotal[$I] = 1;
$Jimage[$I] = 'gin_no_kombou.jpg';

$I++;	#$I = 6;
$Jname[$I] = '동의 곤봉';
$Jexp[$I] = '동으로 만들어진 곤봉. 공격력이 최저이며 가격도 최저이다. 한마디로 무용지물.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 10;
$Jprice[$I] = 10;
$Jtotal[$I] = 1;
$Jimage[$I] = 'dou_no_kombou.jpg';

$I++;	#$I = 7;
$Jname[$I] = '지팡이';
$Jexp[$I] = '단순한 지팡이 약하다. 정말 쓸모없다는 것외에는 특징이 없다.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 10;
$Jprice[$I] = 10;
$Jtotal[$I] = 1;
$Jimage[$I] = 'tsue.jpg';

$I++;	#$I = 8;
$Jname[$I] = '페이퍼나이프';
$Jexp[$I] = '종이로된 나이프이니까 페이퍼나이프. 공격이 낮은 무기중 한개. 타지않게 조심';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 10;
$Jprice[$I] = 10;
$Jtotal[$I] = 1;
$Jimage[$I] = 'paper_knife.jpg';

$I++;	#$I = 9;
$Jname[$I] = '뿅뿅해머';
$Jexp[$I] = '누군가가 신계에 두고간 하계의 장난감. 공격력은 없는것 같다.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 10;
$Jprice[$I] = 10;
$Jtotal[$I] = 1;
$Jimage[$I] = 'pikopiko_hammer.jpg';

$I++;	#$I = 10;
$Jname[$I] = '리틀보우건';
$Jexp[$I] = '조그만 보우건. 화살도작지만 공격력도 작다. 그리고 중요도도 작다. 원거리공격';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jdetail[$I] = 'Fly';
$Jpoint[$I] = 20;
$Jprice[$I] = 20;
$Jtotal[$I] = 1;
$Jimage[$I] = 'little_bowgun.jpg';

$I++;	#$I = 11;
$Jname[$I] = '나이프';
$Jexp[$I] = '보통의 나이프. 누구나 간단하게 쓸 수 있는 원시적인 무기다. 위력은 없다.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 20;
$Jprice[$I] = 20;
$Jtotal[$I] = 1;
$Jimage[$I] = 'knife.jpg';

$I++;	#$I = 12;
$Jname[$I] = '레이피어';
$Jexp[$I] = '결투에 많이 사용된 도신이 가늘다란 단검. 베기보다는 찌르기로 공격한다.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 20;
$Jprice[$I] = 20;
$Jtotal[$I] = 1;
$Jimage[$I] = 'rapier.jpg';

$I++;	#$I = 13;
$Jname[$I] = '브론즈소드';
$Jexp[$I] = '브론즈제 검. 베는 맛이 둔하고 검중에서 공격력이 최저의 분류에 속한다.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 20;
$Jprice[$I] = 20;
$Jtotal[$I] = 1;
$Jimage[$I] = 'bronze_sword.jpg';

$I++;	#$I = 14;
$Jname[$I] = '메이스';
$Jexp[$I] = '적의 갑옷을 쳐부술 수 있는 곤봉계 무기. 그러나 이 약함으로 쳐부수기는 좀....';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 20;
$Jprice[$I] = 20;
$Jtotal[$I] = 1;
$Jimage[$I] = 'mace.jpg';

$I++;	#$I = 15;
$Jname[$I] = '배틀해머';
$Jexp[$I] = '전투용으로 만들어진 해머. 그러나 실제로는 약해서 전투용이 아니다.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 20;
$Jprice[$I] = 20;
$Jtotal[$I] = 1;
$Jimage[$I] = 'battle_hammer.jpg';

$I++;	#$I = 16;
$Jname[$I] = '가죽채찍';
$Jexp[$I] = '가죽제으로 만들어진 채찍. 가볍고 경쾌하다. 공격력의 낮음에 세간의 눈은 차갑다.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 20;
$Jprice[$I] = 20;
$Jtotal[$I] = 1;
$Jimage[$I] = 'kawa_no_muchi.jpg';

$I++;	#$I = 17;
$Jname[$I] = '세이버롯트';
$Jexp[$I] = '상대의 공격도 방어할 수도 있는 롯트. 방어력도 공격력보다 높다. DF60';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jdetail[$I] = 'OtherP';
$Jpoint[$I] = 20;
$Jfree[$I] = 60;
$Jprice[$I] = 80;
$Jtotal[$I] = 1;
$Jimage[$I] = 'saver_rod.jpg';

$I++;	#$I = 18;
$Jname[$I] = '부메랑';
$Jexp[$I] = '던져서 공격하는 무기. 뱅글뱅글 회전하면서 날아간다. 원거리공격';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jdetail[$I] = 'Fly';
$Jpoint[$I] = 30;
$Jprice[$I] = 30;
$Jtotal[$I] = 1;
$Jimage[$I] = 'boomerang.jpg';

$I++;	#$I = 19;
$Jname[$I] = '아이론나이프';
$Jexp[$I] = '철제 나이프. 손재주가 좋은 자나 힘이 없는 자가 애용한다.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 30;
$Jprice[$I] = 30;
$Jtotal[$I] = 1;
$Jimage[$I] = 'iron_knife.jpg';

$I++;	#$I = 20;
$Jname[$I] = '샤벨';
$Jexp[$I] = '칼날이 꽤 넓은 칼. 외견에서 알 수 있듯이 꺽여서 위력이 있다.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 30;
$Jprice[$I] = 30;
$Jtotal[$I] = 1;
$Jimage[$I] = 'saber.jpg';

$I++;	#$I = 21;
$Jname[$I] = '토끼검';
$Jexp[$I] = '안뇽하세요. 저는 아주 귀여운 토끼에용. 괴롭히지 말아주세요. 깡총~';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 30;
$Jprice[$I] = 30;
$Jtotal[$I] = 1;
$Jimage[$I] = 'usagi_no_ken.jpg';

$I++;
$Jname[$I] = '사슬낫';
$Jexp[$I] = '사슬을 단 낫. 보통의 낫과는 틀린 맛이 난다. 휘둘러서 공격한다.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 30;
$Jprice[$I] = 30;
$Jtotal[$I] = 1;
$Jimage[$I] = 'kusarigama.jpg';

$I++;
$Jname[$I] = '헤비넉클';
$Jexp[$I] = '손에 장비해서 적을 때린다. 이름처럼 무게가 있으니 사용시 주의';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 30;
$Jprice[$I] = 30;
$Jtotal[$I] = 1;
$Jimage[$I] = 'heavy_knuckle.jpg';

$I++;
$Jname[$I] = '대형도끼';
$Jexp[$I] = '나무를 자를때 사용하는 도끼. 전투에서도 사용될때도 있다.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 30;
$Jprice[$I] = 30;
$Jtotal[$I] = 1;
$Jimage[$I] = 'masakari.jpg';

$I++;
$Jname[$I] = '벽돌망치';
$Jexp[$I] = '벽돌로 된 망치. 물건을 때리면 망치가 부서지겠지...';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 30;
$Jprice[$I] = 30;
$Jtotal[$I] = 1;
$Jimage[$I] = 'renga_no_tonkachi.jpg';

$I++;
$Jname[$I] = '神界안내판';
$Jexp[$I] = '神界입구에 있는 안내판을 누군가가 뽑았다. 무기로 사용하면 왠지 혼날것 같다.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 30;
$Jprice[$I] = 30;
$Jtotal[$I] = 1;
$Jimage[$I] = 'shinkai_annaiban.jpg';

$I++;
$Jname[$I] = '프라치나볼';
$Jexp[$I] = '적에게 던져서 공격하는 프라치나제 공. 던지면 왠지 아깝다는 느낌이. 원거리공격';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jdetail[$I] = 'Fly';
$Jpoint[$I] = 40;
$Jprice[$I] = 100;
$Jtotal[$I] = 1;
$Jimage[$I] = 'platinum_ball.jpg';

$I++;
$Jname[$I] = '이빌슬레이어';
$Jexp[$I] = '이름은 [악을 멸한다]의 뜻. 그러나 이정도의 파괴력으로 악을 멸하려들다니.... 결국 언어적 오류로 판정';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 40;
$Jprice[$I] = 40;
$Jtotal[$I] = 1;
$Jimage[$I] = 'evil_slayer.jpg';

$I++;
$Jname[$I] = '샤크';
$Jexp[$I] = '샤크를 모델로한 검. 그러나 그렇게 위험해 보이지는 않는다.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 40;
$Jprice[$I] = 40;
$Jtotal[$I] = 1;
$Jimage[$I] = 'shark.jpg';

$I++;
$Jname[$I] = '성검레푸리카';
$Jexp[$I] = '레푸리카라는 이름의 성검인지 성검의 레푸리카인지...공격력이 낮은걸로 봐서는 후자의 설이 유력';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 40;
$Jprice[$I] = 40;
$Jtotal[$I] = 1;
$Jimage[$I] = 'seiken_replica.jpg';

$I++;
$Jname[$I] = '붕붕톱';
$Jexp[$I] = '강력한 전투용 양날톱. 그 이름 그대로 붕붕 휘둘러서 사용';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 40;
$Jprice[$I] = 40;
$Jtotal[$I] = 1;
$Jimage[$I] = 'nokobunbun.jpg';

$I++;
$Jname[$I] = '아이론스피어';
$Jexp[$I] = '철제 스피어. 의외로 사용하기 편함. 잘잡은 다음 푹~! 하고 찔러서 공격.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 40;
$Jprice[$I] = 40;
$Jtotal[$I] = 1;
$Jimage[$I] = 'iron_spear.jpg';

$I++;
$Jname[$I] = '배틀엑스';
$Jexp[$I] = '두꺼운 날을 가진 전투용 도끼. 물러터진 적이라면 두동강을 낼 수 있다.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 40;
$Jprice[$I] = 40;
$Jtotal[$I] = 1;
$Jimage[$I] = 'battle_ax.jpg';

$I++;
$Jname[$I] = '구석기';
$Jexp[$I] = '아주 먼 옛날의 시대의 무기. 돌로 되어있지만 긴 세월동안 토속성이 사라졌다.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 40;
$Jprice[$I] = 40;
$Jtotal[$I] = 1;
$Jimage[$I] = 'kyusekki.jpg';

$I++;
$Jname[$I] = '구슬지팡이';
$Jexp[$I] = '구슬이 지팡이 끝에 박힌 지팡이. 이 구슬에 어떤 효과가 있는지 모르는게 컴플렉스.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 40;
$Jprice[$I] = 40;
$Jtotal[$I] = 1;
$Jimage[$I] = 'tama_no_tsue.jpg';

$I++;
$Jname[$I] = '가시벨트';
$Jexp[$I] = '가시가 붙은 벨트. 채찍처럼 사용한다. 허리에 차면 좋은 방어구도 된다. DF20';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jdetail[$I] = 'Armor';
$Jpoint[$I] = 40;
$Jfree[$I] = 20;
$Jprice[$I] = 60;
$Jtotal[$I] = 1;
$Jimage[$I] = 'toge_belt.jpg';

$I++;
$Jname[$I] = '전사의 활';
$Jexp[$I] = '숙련된 전사라면 반드시 표적에게 명중할 수 있다는 활. 원거리공격';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jdetail[$I] = 'Fly';
$Jpoint[$I] = 50;
$Jprice[$I] = 50;
$Jtotal[$I] = 1;
$Jimage[$I] = 'senshi_no_yumi.jpg';

$I++;
$Jname[$I] = '매지컬대거';
$Jexp[$I] = 'MP20을 소비하면 기적의 힘과 공명하여 공격력이 2배가 되는 매력적인 대거';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jdetail[$I] = 'MagicalW';
$Jpoint[$I] = 50;
$Jfree[$I] = 20;
$Jprice[$I] = 80;
$Jtotal[$I] = 1;
$Jimage[$I] = 'magical_dagger.jpg';

$I++;
$Jname[$I] = '그레이트소드';
$Jexp[$I] = '神界에선 무기로서 중급에 위치하는 검. 그레이트까지는 아니지만.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 50;
$Jprice[$I] = 50;
$Jtotal[$I] = 1;
$Jimage[$I] = 'great_sword.jpg';

$I++;
$Jname[$I] = '반월도';
$Jexp[$I] = '반월처럼 아름다운 도. 부드러운 움직임과 그 화사함이 적을 매료한다.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 50;
$Jprice[$I] = 50;
$Jtotal[$I] = 1;
$Jimage[$I] = 'hangetsutou.jpg';

$I++;
$Jname[$I] = '언월도';
$Jexp[$I] = '긴 봉의 끝에 날이 달린 무기. 상대와의 간격을 한순간에 좁혀 공격이 가능하다.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 50;
$Jprice[$I] = 50;
$Jtotal[$I] = 1;
$Jimage[$I] = 'naginata.jpg';

$I++;
$Jname[$I] = '레옹크로';
$Jexp[$I] = '전설의 사자의 발톱. 손에 끼면 사자가된 느낌이다.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 50;
$Jprice[$I] = 50;
$Jtotal[$I] = 1;
$Jimage[$I] = 'leo_claw.jpg';

$I++;
$Jname[$I] = '힘의 철판';
$Jexp[$I] = '힘으로 적을 때려눕히는 무기. 면이 넓어서 방패로도 사용이 가능하다. DF70';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jdetail[$I] = 'Shield';
$Jpoint[$I] = 50;
$Jfree[$I] = 70;
$Jprice[$I] = 120;
$Jtotal[$I] = 1;
$Jimage[$I] = 'chikara_no_teppan.jpg';

$I++;				#$I = 44;
$Jname[$I] = '난탄무검';
$Jexp[$I] = '마치 살아있는것 같은 신비한 검 상대방의 공격을 날려버릴 수 있다.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jdetail[$I] = 'WeaponR';
$Jpoint[$I] = 50;
$Jfree[$I] = 50;
$Jprice[$I] = 50;
$Jtotal[$I] = 6;
$Jimage[$I] = 'randammuken.jpg';

$I++;
$Jname[$I] = '싸이코카드';
$Jexp[$I] = '마력을 입은 카드. 사용자의 의지대로 날아간다. 원거리공격';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jdetail[$I] = 'Fly';
$Jpoint[$I] = 60;
$Jprice[$I] = 60;
$Jtotal[$I] = 1;
$Jimage[$I] = 'psycho_card.jpg';

$I++;
$Jname[$I] = '에너지나이프';
$Jexp[$I] = '기를 가지는 나이프. 공격시에 내포된 에너지를 일시에 방출한다.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 60;
$Jprice[$I] = 60;
$Jtotal[$I] = 1;
$Jimage[$I] = 'energy_knife.jpg';

$I++;
$Jname[$I] = '진공검';
$Jexp[$I] = '한번 휘둘르면 진공의 소용돌이가 일어나 상대를 공격하는 대단한 검. 검자체의 파괴력은 없다.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 60;
$Jprice[$I] = 60;
$Jtotal[$I] = 1;
$Jimage[$I] = 'shinkuken.jpg';

$I++;
$Jname[$I] = '로맨스소드';
$Jexp[$I] = '검의 흔들림은 마음의 흔들림. 외로워서 녹슬것 같애. 검을 휘둘러도 나를 휘둘지는 말아죠.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 60;
$Jprice[$I] = 60;
$Jtotal[$I] = 1;
$Jimage[$I] = 'romance_sword.jpg';

$I++;
$Jname[$I] = '언월도스폐셜';
$Jexp[$I] = '긴 봉의 끝에 날이 달린 무기. 상대와의 간격을 한순간에 좁혀 공격이 가능하다.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 60;
$Jprice[$I] = 60;
$Jtotal[$I] = 1;
$Jimage[$I] = 'naginata_special.jpg';

$I++;
$Jname[$I] = '납의 망치';
$Jexp[$I] = '그 무게로 적을 분쇄하는 망치. 무겁기 때문에 쓰는쪽도 힘들다.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 60;
$Jprice[$I] = 60;
$Jtotal[$I] = 1;
$Jimage[$I] = 'namari_no_tsuchi.jpg';

$I++;
$Jname[$I] = '메탈클럽';
$Jexp[$I] = '단단한 금속으로 된 곤봉. 끝에서 끝까지 균일한 굵기. 균일한 밀도가 강력함의 비결';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 60;
$Jprice[$I] = 60;
$Jtotal[$I] = 1;
$Jimage[$I] = 'metal_club.jpg';

$I++;
$Jname[$I] = '체인웹';
$Jexp[$I] = '체인으로 만들어진 그물로 적을 덮쳐서 공격하는 무기. 꽤 공격력이 있다.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 60;
$Jprice[$I] = 60;
$Jtotal[$I] = 1;
$Jimage[$I] = 'chain_web.jpg';

$I++;
$Jname[$I] = '엘보삭크';
$Jexp[$I] = '팔꿈치에 장비해서 상대에게 팔꿈치찍기를 한다. 장갑으로 사용할 수 있다. DF30';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jdetail[$I] = 'Gauntlet';
$Jpoint[$I] = 60;
$Jfree[$I] = 30;
$Jprice[$I] = 90;
$Jtotal[$I] = 1;
$Jimage[$I] = 'elbow_sack.jpg';

$I++;
$Jname[$I] = '젯트요요';
$Jexp[$I] = '원래는 완구였지만 무기로 개조했다. 실부분을 손가락에 껴서 사용한다.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 60;
$Jprice[$I] = 60;
$Jtotal[$I] = 1;
$Jimage[$I] = 'jet_yohyoh.jpg';

$I++;
$Jname[$I] = '열성고무의 활';
$Jexp[$I] = '긴 세월이 흘러 열성된 강한 탄력을 가진 고무로 만든 활. 원거리공격';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jdetail[$I] = 'Fly';
$Jpoint[$I] = 70;
$Jprice[$I] = 70;
$Jtotal[$I] = 1;
$Jimage[$I] = 'jukuseigomu_no_yumi.jpg';

$I++;
$Jname[$I] = '매드소드';
$Jexp[$I] = '광기가 깃든 무시무시한 검. 공격을 받으면 弱風病에 감염한다.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jdetail[$I] = 'AddWeakWind';
$Jpoint[$I] = 80;
$Jprice[$I] = 70;
$Jtotal[$I] = 1;
$Jimage[$I] = 'mad_kogatana.jpg';

$I++;
$Jname[$I] = '판톰소드';
$Jexp[$I] = '강한영기를 받은 검. 공격한 상대의 HP를 흡수해 자신의 것으로 하는 효과가 있다.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jdetail[$I] = 'HPabsorb';
$Jpoint[$I] = 70;
$Jprice[$I] = 130;
$Jtotal[$I] = 1;
$Jimage[$I] = 'phantom_sword.jpg';

$I++;
$Jname[$I] = '웨이브소드';
$Jexp[$I] = '도신이 파동치는 검. 파동이 충격을 증폭하기때문에 무시할 수 없다.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 70;
$Jprice[$I] = 70;
$Jtotal[$I] = 1;
$Jimage[$I] = 'wave_sword.jpg';

$I++;
$Jname[$I] = '수호의 창';
$Jexp[$I] = '끝에 특수한 돌이 박힌 창.그 돌에는 창을 가진자를 지켜주는 힘이 있다. DF40';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jdetail[$I] = 'OtherP';
$Jpoint[$I] = 70;
$Jfree[$I] = 40;
$Jprice[$I] = 110;
$Jtotal[$I] = 1;
$Jimage[$I] = 'mamori_no_hoko.jpg';

$I++;
$Jname[$I] = '강철도끼';
$Jexp[$I] = '단련된 강철로된 도끼. 그 위력은 바위도 으깨버린다.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 70;
$Jprice[$I] = 70;
$Jtotal[$I] = 1;
$Jimage[$I] = 'hagane_no_ono.jpg';

$I++;
$Jname[$I] = '하드프레일';
$Jexp[$I] = '두개의 곤봉이 사슬로 연결된 무기. 싸움이외에는 콩트로 사용하기도 한다.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 70;
$Jprice[$I] = 70;
$Jtotal[$I] = 1;
$Jimage[$I] = 'hard_flail.jpg';

$I++;
$Jname[$I] = '러브리스틱';
$Jexp[$I] = '어째서인지 귀여움과는 달리 그 공격력은 꽤 쎄다. 그런 사랑스러운 스틱';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 70;
$Jprice[$I] = 70;
$Jtotal[$I] = 1;
$Jimage[$I] = 'lovely_stick.jpg';

$I++;
$Jname[$I] = '열선거울';
$Jexp[$I] = '열을 모아서 반사하는 무기. 그 원리는 잘모른다.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 70;
$Jprice[$I] = 70;
$Jtotal[$I] = 1;
$Jimage[$I] = 'nessenkyou.jpg';

$I++;
$Jname[$I] = '휴대드릴';
$Jexp[$I] = '가지고 다니기 편리하게 소형화, 경량화된 드릴. 상대에게 가볍게 찔러주세요.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 70;
$Jprice[$I] = 70;
$Jtotal[$I] = 1;
$Jimage[$I] = 'keitai_drill.jpg';

$I++;
$Jname[$I] = '로켓펀치';
$Jexp[$I] = '시공을 넘어 신계에 섞여온 무기. 주먹의 모양을한 물체가 적을 향해 날아간다. 원거리공격';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jdetail[$I] = 'Fly';
$Jpoint[$I] = 80;
$Jprice[$I] = 80;
$Jtotal[$I] = 1;
$Jimage[$I] = 'rocket_punch.jpg';

$I++;
$Jname[$I] = '매지컬소드';
$Jexp[$I] = 'MP40을 소비하면 기적의 힘과 공명하여 공격력이 2배가 되는 매력적인 검';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jdetail[$I] = 'MagicalW';
$Jpoint[$I] = 80;
$Jfree[$I] = 40;
$Jprice[$I] = 110;
$Jtotal[$I] = 1;
$Jimage[$I] = 'magical_sword.jpg';

$I++;
$Jname[$I] = '파워블레이드';
$Jexp[$I] = '힘이 넘쳐나도록 세공이된 검. 어떤 적이든 힘으로 베어버린다.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 80;
$Jprice[$I] = 80;
$Jtotal[$I] = 1;
$Jimage[$I] = 'power_blade.jpg';

$I++;
$Jname[$I] = '지옥의 날';
$Jexp[$I] = '원래는 지옥에서 사용되었다는 무기. 공격을 받은 자는 地獄病에 감염된다.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jdetail[$I] = 'AddHell';
$Jpoint[$I] = 80;
$Jprice[$I] = 80;
$Jtotal[$I] = 1;
$Jimage[$I] = 'jigoku_no_yaiba.jpg';

$I++;
$Jname[$I] = '할버드';
$Jexp[$I] = '도끼창. 창으로 찌르기보다는 도끼로 내리찍어 공격할수도 있다.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 80;
$Jprice[$I] = 80;
$Jtotal[$I] = 1;
$Jimage[$I] = 'halbert.jpg';

$I++;
$Jname[$I] = '스네이크윕';
$Jexp[$I] = '뱀으로 착각할수도 있는 채찍. 뱀처럼 민첩한 움직임을 한다.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 80;
$Jprice[$I] = 80;
$Jtotal[$I] = 1;
$Jimage[$I] = 'snake_whip.jpg';

$I++;
$Jname[$I] = '액티브글로브';
$Jexp[$I] = '생기가 도는 글로브. 완력이 없어도 정신력을 공격의 힘으로 전환한다.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 80;
$Jprice[$I] = 80;
$Jtotal[$I] = 1;
$Jimage[$I] = 'active_glove.jpg';

$I++;
$Jname[$I] = '마술지팡이';
$Jexp[$I] = '마술에의해서 능력이 높아진 지팡이. 생김새만으로 상대를 위협한다.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 80;
$Jprice[$I] = 80;
$Jtotal[$I] = 1;
$Jimage[$I] = 'majutsu_no_tsue.jpg';

$I++;
$Jname[$I] = '낙하바늘';
$Jexp[$I] = '자유낙하하는 바늘. 초가속으로 그 스피드는 무시무시하다.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 80;
$Jprice[$I] = 80;
$Jtotal[$I] = 1;
$Jimage[$I] = 'rakkabari.jpg';

$I++;
$Jname[$I] = '스카이하픈';
$Jexp[$I] = '대공을 날아오르는 거대한 작살. 멀리서 공격받은 상대는 놀랄것이다. 원거리공격';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jdetail[$I] = 'Fly';
$Jpoint[$I] = 90;
$Jprice[$I] = 90;
$Jtotal[$I] = 1;
$Jimage[$I] = 'sky_harpoon.jpg';

$I++;
$Jname[$I] = '풍운검';
$Jexp[$I] = '고요한 풍운을 부르는 검. 공격당한 상대는 弱風病에 감염된다.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jdetail[$I] = 'AddWeakWind';
$Jpoint[$I] = 100;
$Jprice[$I] = 90;
$Jtotal[$I] = 1;
$Jimage[$I] = 'fuunken.jpg';

$I++;
$Jname[$I] = '퇴마검';
$Jexp[$I] = '마물을 퇴치하는 신성한 검. 더러혀진 마음의 소유자가 사용하면 스스로를 퇴치하게 된다.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 90;
$Jprice[$I] = 90;
$Jtotal[$I] = 1;
$Jimage[$I] = 'taima_no_ken.jpg';

$I++;
$Jname[$I] = '바스타드소드';
$Jexp[$I] = '높은 공격을 자랑하는 검. 날이 크고 무겁다. 상대에게 명중시키면 큰 데미지는 분명.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 90;
$Jprice[$I] = 90;
$Jtotal[$I] = 1;
$Jimage[$I] = 'bastard_sword.jpg';

$I++;
$Jname[$I] = '인비지블';
$Jexp[$I] = '날이 전혀 안보이는 신비의 검. 그림자로 그 존재를 간신히 확인이 가능하다.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 90;
$Jprice[$I] = 90;
$Jtotal[$I] = 1;
$Jimage[$I] = 'invisible.jpg';

$I++;
$Jname[$I] = '스피어트랩';
$Jexp[$I] = '어디까지나 트랩이지 창이 아닌 요상한 무기.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 90;
$Jprice[$I] = 90;
$Jtotal[$I] = 1;
$Jimage[$I] = 'spear_jikake.jpg';

$I++;
$Jname[$I] = '문액스';
$Jexp[$I] = '장엄한 달의 빛이 기적까지도 튕겨낸다. 반짝반짝둥글둥글달님';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jdetail[$I] = 'MiracleM';
$Jpoint[$I] = 90;
$Jprice[$I] = 150;
$Jtotal[$I] = 1;
$Jimage[$I] = 'moon_ax.jpg';

$I++;
$Jname[$I] = '그리폰크로우';
$Jexp[$I] = '전설의 괴수 그리폰의 발톱. 손에 끼면 마치 그리폰이 부활한것 같다.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 90;
$Jprice[$I] = 90;
$Jtotal[$I] = 1;
$Jimage[$I] = 'griffin_claw.jpg';

$I++;
$Jname[$I] = '사슬구슬';
$Jexp[$I] = '가시가 붙은 큰 구슬에 사슬이 붙어있고 그 끝에 손잡이가 있는 무기. 던지기금지 위험!!';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 90;
$Jprice[$I] = 90;
$Jtotal[$I] = 1;
$Jimage[$I] = 'kusaritsuki_kikenkyu.jpg';

$I++;
$Jname[$I] = '소드쉴드';
$Jexp[$I] = '검과 방패가 합체된 무기. 검으로나 방패로나 어정쩡해 보이지만 그렇지도 않다. DF100';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jdetail[$I] = 'Shield';
$Jpoint[$I] = 100;
$Jfree[$I] = 100;
$Jprice[$I] = 200;
$Jtotal[$I] = 1;
$Jimage[$I] = 'sword_shield.jpg';

$I++;
$Jname[$I] = '어난심';
$Jexp[$I] = '잡으면 이상한 기분이 드는 전설의 검. 이검으로 상처를 입으면 환각상태에 빠진다.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jdetail[$I] = 'AddIllusion';
$Jpoint[$I] = 100;
$Jprice[$I] = 120;
$Jtotal[$I] = 1;
$Jimage[$I] = 'goranshin.jpg';

$I++;
$Jname[$I] = '하트브레이크';
$Jexp[$I] = '이 공격은 몸뿐만 아니라 마음까지도 상처입힌다. 정신차리지 않으면 환각을 본다.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jdetail[$I] = 'AddIllusion';
$Jpoint[$I] = 100;
$Jprice[$I] = 120;
$Jtotal[$I] = 1;
$Jimage[$I] = 'heart_break.jpg';

$I++;
$Jname[$I] = '육각흉';
$Jexp[$I] = '흉을 부른다는 검. 공격을 받은 상대에게는 암운이 깔릴것이다.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jdetail[$I] = 'AddDarkCloud';
$Jpoint[$I] = 100;
$Jprice[$I] = 90;
$Jtotal[$I] = 1;
$Jimage[$I] = 'rokkakukyou.jpg';

$I++;
$Jname[$I] = '이온블레이드';
$Jexp[$I] = '이온의 구조에서 면밀히 만들어진 검. 그 구조는 과학적으로 설명이 안된다.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 100;
$Jprice[$I] = 100;
$Jtotal[$I] = 1;
$Jimage[$I] = 'ion_blade.jpg';

$I++;
$Jname[$I] = '만월도';
$Jexp[$I] = '만월의 아름다움의 도. 매끄러운 움직임과 우아함이 적을 매료한다.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 100;
$Jprice[$I] = 100;
$Jtotal[$I] = 1;
$Jimage[$I] = 'mangetsutou.jpg';

$I++;
$Jname[$I] = '공포의 차륜';
$Jexp[$I] = '사악함에 찌든 바퀴가 굴러간다. 그 모습만 봐도 공포를 느낀다.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 100;
$Jprice[$I] = 100;
$Jtotal[$I] = 1;
$Jimage[$I] = 'kyoufu_no_sharin.jpg';

$I++;
$Jname[$I] = '고스트소드';
$Jexp[$I] = '아주강한 영기를 입은 검. 상대의 HP를 흡수해서 자신의 것으로 하는 효과가 있다.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jdetail[$I] = 'HPabsorb';
$Jpoint[$I] = 110;
$Jprice[$I] = 170;
$Jtotal[$I] = 1;
$Jimage[$I] = 'ghost_sword.jpg';

$I++;
$Jname[$I] = '오우거바스터';
$Jexp[$I] = '어떤 괴물이든 뭉개버리는 강력한 검. 지금까지 수없이 많은 괴물을 퇴치했다.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 110;
$Jprice[$I] = 110;
$Jtotal[$I] = 1;
$Jimage[$I] = 'ogre_buster.jpg';

$I++;
$Jname[$I] = '홀리랜스';
$Jexp[$I] = '축복을 받은 성스러운창. 손에 드는 것만으로 마음이 청결해 진다고 한다.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 110;
$Jprice[$I] = 110;
$Jtotal[$I] = 1;
$Jimage[$I] = 'holy_lance.jpg';

$I++;
$Jname[$I] = '그라비티메이스';
$Jexp[$I] = '극적으로 큰질량을 가지는 메이스. 하계에서는 드는것조차 불가능하지만 신계에서는 겨우 쓸수가 있다.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 110;
$Jprice[$I] = 110;
$Jtotal[$I] = 1;
$Jimage[$I] = 'gravity_mace.jpg';

$I++;
$Jname[$I] = '프라즈마봉';
$Jexp[$I] = '고체도 액체도 기체도 아닌 물질의 상태. 그것이 프라즈마. 초고온이다.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 110;
$Jprice[$I] = 110;
$Jtotal[$I] = 1;
$Jimage[$I] = 'plasma_bou.jpg';

$I++;
$Jname[$I] = '격렬풍운검';
$Jexp[$I] = '감당할 수 없을 정도의 격렬한풍운을 부르는 검. 공격당한 상대는 弱風病에 감염된다.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jdetail[$I] = 'AddWeakWind';
$Jpoint[$I] = 130;
$Jprice[$I] = 120;
$Jtotal[$I] = 1;
$Jimage[$I] = 'gekiretsu_fuunken.jpg';

$I++;
$Jname[$I] = '레인보우블레이드';
$Jexp[$I] = '무지개색의 날을 가지는 아름다운 검. 무지개를 좋아하던 신이 무지개를 갈아서 만들었다.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 120;
$Jprice[$I] = 120;
$Jtotal[$I] = 1;
$Jimage[$I] = 'rainbow_blade.jpg';

$I++;
$Jname[$I] = '마법선';
$Jexp[$I] = '거품에 감싼 마법의 배가 적을 향해 돌진한다. 타지는 못한다.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 120;
$Jprice[$I] = 120;
$Jtotal[$I] = 1;
$Jimage[$I] = 'mahousen.jpg';

$I++;
$Jname[$I] = '기적의 지팡이';
$Jexp[$I] = '기적을 이루는 지팡이. MP소비없이 한번만 기적을 일으킬 수 있다.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jdetail[$I] = 'UseMiracle';
$Jpoint[$I] = 120;
$Jprice[$I] = 120;
$Jtotal[$I] = 1;
$Jimage[$I] = 'kiseki_no_tsue.jpg';

$I++;
$Jname[$I] = '오리온의 창';
$Jexp[$I] = '일찌기 엄청난 파괴력때문에 봉인되었다는 창. 긴세월동안에 봉인이 풀린 것 같다.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 130;
$Jprice[$I] = 130;
$Jtotal[$I] = 1;
$Jimage[$I] = 'orion_no_yari.jpg';

$I++;
$Jname[$I] = '자전팽이';
$Jexp[$I] = '지구자전의 근원. 주변의 모든 것을 파괴하는 이 무기. 한때 장난감으로 유행';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 130;
$Jprice[$I] = 130;
$Jtotal[$I] = 1;
$Jimage[$I] = 'koma_combat.jpg';

$I++;
$Jname[$I] = '코스믹원드';
$Jexp[$I] = '어떤 현자가 이렇게 말했다. [이 지팡이는 우주 그 자체이다.]';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 130;
$Jprice[$I] = 130;
$Jtotal[$I] = 1;
$Jimage[$I] = 'cosmic_wand.jpg';

$I++;
$Jname[$I] = '류성검';
$Jexp[$I] = '유성의 결정체가 검이 되었다. 흐르는 검술, 별빛은 힘.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 140;
$Jprice[$I] = 140;
$Jtotal[$I] = 1;
$Jimage[$I] = 'ryuseiken.jpg';

$I++;
$Jname[$I] = '드래곤크로우';
$Jexp[$I] = '전설의 드래곤의 발톱. 손에 끼면 마치 드래곤이 재래한것 같다.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 140;
$Jprice[$I] = 140;
$Jtotal[$I] = 1;
$Jimage[$I] = 'dragon_claw.jpg';

$I++;
$Jname[$I] = '邪神의 대검';
$Jexp[$I] = '무시무시한 위력을 가진 검. 그러나 사신의 저주가 걸려있어서 사용하면 HP50데미지를 입는다.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jdetail[$I] = 'SelfDamage';
$Jpoint[$I] = 140;
$Jfree[$I] = '50';
$Jprice[$I] = 140;
$Jtotal[$I] = 1;
$Jimage[$I] = 'jashin_no_taiken.jpg';

$I++;
$Jname[$I] = '천사의 활';
$Jexp[$I] = '천사의 활. 신계에서도 선택받은 천사밖에 쓰지 못했다. 원거리공격';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jdetail[$I] = 'Fly';
$Jpoint[$I] = 150;
$Jprice[$I] = 150;
$Jtotal[$I] = 1;
$Jimage[$I] = 'angel_arrow.jpg';

$I++;
$Jname[$I] = '천사의 나이프';
$Jexp[$I] = '천사의 나이프. 나이프로 이정도의 공격력이라니 역시 천사다.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 150;
$Jprice[$I] = 150;
$Jtotal[$I] = 1;
$Jimage[$I] = 'angel_knife.jpg';

$I++;
$Jname[$I] = '천사의 검';
$Jexp[$I] = '천사의 검. 천사도 물론 검을 쓴다. 가볍고 쓰기편한게 특징.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 150;
$Jprice[$I] = 150;
$Jtotal[$I] = 1;
$Jimage[$I] = 'angel_sword.jpg';

$I++;
$Jname[$I] = '천사의 도끼';
$Jexp[$I] = '천사의 도끼. 사랑스런 둥근형태의 날이 도끼같지가 않지만 이게 천사들 사이에서 유행이다.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 150;
$Jprice[$I] = 150;
$Jtotal[$I] = 1;
$Jimage[$I] = 'angel_ax.jpg';

$I++;
$Jname[$I] = '신검';
$Jexp[$I] = '신이 쓴다는 궁극의 검. 지나친 신의 품격에 꺼림직한 마음의 소유자는 엉겁결에 엎드린다.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jpoint[$I] = 300;
$Jprice[$I] = 300;
$Jtotal[$I] = 1;
$Jimage[$I] = 'kami_no_ken.jpg';

$I++;				#$I = 110;
$Jname[$I] = '매지컬롯트';
$Jexp[$I] = '기적의 힘과 공명하여 공격력을 만들어 내는 신비의 롯트. 소비MP의 2배의 공격력.';
$Jtype[$I] = 'NormalW';
$Jkind[$I] = 'Weapon';
$Jdetail[$I] = 'MagicalRod';
$Jprice[$I] = 150;
$Jtotal[$I] = 1;
$Jimage[$I] = 'magical_rod.jpg';

$I++;
$Jname[$I] = '횃불';
$Jexp[$I] = '몽둥이 끝에서 잘타고 있다. 잘못잡으면 뜨겁다. 화속성';
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'Weapon';
$Jattribute[$I] = 'Mars';
$Jpoint[$I] = 10;
$Jprice[$I] = 10;
$Jtotal[$I] = 1;
$Jimage[$I] = 'taimatsu.jpg';

$I++;
$Jname[$I] = '고드름';
$Jexp[$I] = '고드름을 무기로 한것은 좋지만 차가워서 오래 잡지 못하는 점이 난점. 수속성';
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'Weapon';
$Jattribute[$I] = 'Mercury';
$Jpoint[$I] = 10;
$Jprice[$I] = 10;
$Jtotal[$I] = 1;
$Jimage[$I] = 'tsurara.jpg';

$I++;
$Jname[$I] = '목도';
$Jexp[$I] = '나무로 된 도. 베는게 아니라 치기용이다. 반대로 그 약함에 완전 뻗어버리기도. 목속성';
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'Weapon';
$Jattribute[$I] = 'Jupiter';
$Jpoint[$I] = 10;
$Jprice[$I] = 10;
$Jtotal[$I] = 1;
$Jimage[$I] = 'bokutou.jpg';

$I++;
$Jname[$I] = '죽창';
$Jexp[$I] = '대나무로 된 창. 먹으면 안됩니다. 목속성';
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'Weapon';
$Jattribute[$I] = 'Jupiter';
$Jpoint[$I] = 10;
$Jprice[$I] = 10;
$Jtotal[$I] = 1;
$Jimage[$I] = 'takeyari.jpg';

$I++;
$Jname[$I] = '검구이';
$Jexp[$I] = '신계명산의 검구이. 본래는 무기가 아니라 장식품이다. 기념품으로 좋습니다. 토속성';
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'Weapon';
$Jattribute[$I] = 'Saturn';
$Jpoint[$I] = 10;
$Jprice[$I] = 10;
$Jtotal[$I] = 1;
$Jimage[$I] = 'tsurugiyaki.jpg';

$I++;
$Jname[$I] = '광나는돌멩이';
$Jexp[$I] = '은은하게 빛나는 조그만 돌. 던지면 누군가가 맞겠지. 원거리공격. 천속성';
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'Weapon';
$Jdetail[$I] = 'Fly';
$Jattribute[$I] = 'Uranus';
$Jpoint[$I] = 10;
$Jprice[$I] = 10;
$Jtotal[$I] = 1;
$Jimage[$I] = 'kagayaku_koishi.jpg';

$I++;
$Jname[$I] = '불길한 바늘';
$Jexp[$I] = '공격력은 낮지만 그 불길함은 끔직하다. 살짝 찌르는 무기. 명속성';
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'Weapon';
$Jattribute[$I] = 'Pluto';
$Jpoint[$I] = 10;
$Jprice[$I] = 10;
$Jtotal[$I] = 1;
$Jimage[$I] = 'bukimibari.jpg';

$I++;
$Jname[$I] = '불붙은 봉';
$Jexp[$I] = '끝에 불이 붙어있다. 그 불은 절대 꺼지지 않을 것이다. 화속성';
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'Weapon';
$Jattribute[$I] = 'Mars';
$Jpoint[$I] = 20;
$Jprice[$I] = 20;
$Jtotal[$I] = 1;
$Jimage[$I] = 'tomosareta_hoko.jpg';

$I++;
$Jname[$I] = '파이어롯트';
$Jexp[$I] = '불을 뿜어내는 마법의 롯트. 속성이 없는 무기를 화속성으로 바꾸기도 한다. 화속성';
$Jtype[$I] = 'SoloAdd';
$Jkind[$I] = 'Weapon';
$Jdetail[$I] = 'AddAttribute';
$Jattribute[$I] = 'Mars';
$Jpoint[$I] = 20;
$Jprice[$I] = 20;
$Jtotal[$I] = 1;
$Jimage[$I] = 'fire_rod.jpg';

$I++;
$Jname[$I] = '아이스대거';
$Jexp[$I] = '얼음으로 된 대거. 꽤 이쁘기때문에 신전에 장식해도 좋다. 수속성';
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'Weapon';
$Jattribute[$I] = 'Mercury';
$Jpoint[$I] = 20;
$Jprice[$I] = 20;
$Jtotal[$I] = 1;
$Jimage[$I] = 'ice_dagger.jpg';

$I++;
$Jname[$I] = '얼음의 해머';
$Jexp[$I] = '얼음으로 된 해머. 따듯해도 절대 녹을 일이 없다. 수속성';
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'Weapon';
$Jattribute[$I] = 'Mercury';
$Jpoint[$I] = 20;
$Jprice[$I] = 20;
$Jtotal[$I] = 1;
$Jimage[$I] = 'koori_no_hammer.jpg';

$I++;
$Jname[$I] = '낙엽수리검';
$Jexp[$I] = '낙엽으로 된 수리검. 멀리까지 날아가 상대를 공겨한다. 원거리공격. 목속성';
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'Weapon';
$Jdetail[$I] = 'Fly';
$Jattribute[$I] = 'Jupiter';
$Jpoint[$I] = 20;
$Jprice[$I] = 20;
$Jtotal[$I] = 1;
$Jimage[$I] = 'happa_shuriken.jpg';

$I++;
$Jname[$I] = '가시채찍';
$Jexp[$I] = '가시들을 묶어서 만든 채찍. 가시가 공격력을 높이고 있다. 목속성';
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'Weapon';
$Jattribute[$I] = 'Jupiter';
$Jpoint[$I] = 20;
$Jprice[$I] = 20;
$Jtotal[$I] = 1;
$Jimage[$I] = 'ibara_no_muchi.jpg';

$I++;
$Jname[$I] = '스파이크컷터';
$Jexp[$I] = '강한 섬광을 내뿜는 스파이크컷터. 공격을 받은 자는 섬광상태에 빠진다. 천속성';
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'Weapon';
$Jdetail[$I] = 'AddFlash';
$Jattribute[$I] = 'Uranus';
$Jpoint[$I] = 20;
$Jprice[$I] = 20;
$Jtotal[$I] = 1;
$Jimage[$I] = 'spark_cutter.jpg';

$I++;
$Jname[$I] = '화염의 손톱';
$Jexp[$I] = '화염이 계속해서 나오고 있다. 손에 끼면 뜨겁지 않을까? 화속성';
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'Weapon';
$Jattribute[$I] = 'Mars';
$Jpoint[$I] = 30;
$Jprice[$I] = 30;
$Jtotal[$I] = 1;
$Jimage[$I] = 'honoo_no_tsume.jpg';

$I++;
$Jname[$I] = '화염의 채찍';
$Jexp[$I] = '불타는 채찍. 이런것에 감기면 울 수밖에 없다. 화속성';
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'Weapon';
$Jattribute[$I] = 'Mars';
$Jpoint[$I] = 30;
$Jprice[$I] = 30;
$Jtotal[$I] = 1;
$Jimage[$I] = 'honoo_no_muchi.jpg';

$I++;
$Jname[$I] = '안개포';
$Jexp[$I] = '상대에게 안개를 뿌리는 무기. 공격을 받으면 안개에 쌓이게 된다. 수속성';
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'Weapon';
$Jdetail[$I] = 'AddFog';
$Jattribute[$I] = 'Mercury';
$Jpoint[$I] = 30;
$Jprice[$I] = 30;
$Jtotal[$I] = 1;
$Jimage[$I] = 'kirideppou.jpg';

$I++;
$Jname[$I] = '신목의 활';
$Jexp[$I] = '신목을 조각해 만들었다고 말해지는 고마운 궁. 원거리공격. 목속성';
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'Weapon';
$Jdetail[$I] = 'Fly';
$Jattribute[$I] = 'Jupiter';
$Jpoint[$I] = 30;
$Jprice[$I] = 30;
$Jtotal[$I] = 1;
$Jimage[$I] = 'shimboku_no_yumi.jpg';

$I++;
$Jname[$I] = '스톤액스';
$Jexp[$I] = '돌도끼. 결국 단단한 돌이라서 그정도의 힘은 있다. 토속성';
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'Weapon';
$Jattribute[$I] = 'Saturn';
$Jpoint[$I] = 30;
$Jprice[$I] = 30;
$Jtotal[$I] = 1;
$Jimage[$I] = 'stone_ax.jpg';

$I++;
$Jname[$I] = '별의 지팡이';
$Jexp[$I] = '별을 잡아서 지팡이 끝에 붙여봤다. 별도 가짜는 아닌것 같다. 천속성';
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'Weapon';
$Jattribute[$I] = 'Uranus';
$Jpoint[$I] = 30;
$Jprice[$I] = 30;
$Jtotal[$I] = 1;
$Jimage[$I] = 'star_staff.jpg';

$I++;
$Jname[$I] = '코브라';
$Jexp[$I] = '맹독을 가진 코브라를 모델을 해서 만들어진 무서운 무기. 명속성';
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'Weapon';
$Jattribute[$I] = 'Pluto';
$Jpoint[$I] = 30;
$Jprice[$I] = 30;
$Jtotal[$I] = 1;
$Jimage[$I] = 'cobra.jpg';

$I++;
$Jname[$I] = '파이어보우건';
$Jexp[$I] = '불의 화살을 쏘는 보우건. 그 사람의 하트를 향해 하트에 불을 붙여라. 원거리공격. 화속성';
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'Weapon';
$Jdetail[$I] = 'Fly';
$Jattribute[$I] = 'Mars';
$Jpoint[$I] = 40;
$Jprice[$I] = 40;
$Jtotal[$I] = 1;
$Jimage[$I] = 'fire_bowgun.jpg';

$I++;
$Jname[$I] = '프레임소드';
$Jexp[$I] = '흔들리는 화염을 봉인한 마검. 고온의 일격은 믿음직스럽다. 화속성';
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'Weapon';
$Jattribute[$I] = 'Mars';
$Jpoint[$I] = 40;
$Jprice[$I] = 40;
$Jtotal[$I] = 1;
$Jimage[$I] = 'flame_sword.jpg';

$I++;
$Jname[$I] = '프리즈블레이드';
$Jexp[$I] = '백색의 얼어붙은 마검. 저온의 일격의 냉기까지도 느껴진다. 수속성';
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'Weapon';
$Jattribute[$I] = 'Mercury';
$Jpoint[$I] = 40;
$Jprice[$I] = 40;
$Jtotal[$I] = 1;
$Jimage[$I] = 'freeze_blade.jpg';

$I++;
$Jname[$I] = '꿈의 나무망치';
$Jexp[$I] = '떠도는 아련한 꿈의 향기. 그 마력은 환각을 만들어낸다. 목속성';
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'Weapon';
$Jdetail[$I] = 'AddIllusion';
$Jattribute[$I] = 'Jupiter';
$Jpoint[$I] = 40;
$Jprice[$I] = 40;
$Jtotal[$I] = 1;
$Jimage[$I] = 'yume_no_kizuchi.jpg';

$I++;
$Jname[$I] = '썬더액스';
$Jexp[$I] = '번개를 도끼로 만들었다. 가끔 휘둘으면 천둥이 일어난다. 감전주의. 천속성';
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'Weapon';
$Jattribute[$I] = 'Uranus';
$Jpoint[$I] = 40;
$Jprice[$I] = 40;
$Jtotal[$I] = 1;
$Jimage[$I] = 'thunder_ax.jpg';

$I++;
$Jname[$I] = '진홍도';
$Jexp[$I] = '심지의 꽃술까지 진홍의 칼. 왜냐하면 진홍의 화염으로 묽들였기 때문. 화속성';
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'Weapon';
$Jattribute[$I] = 'Mars';
$Jpoint[$I] = 50;
$Jprice[$I] = 50;
$Jtotal[$I] = 1;
$Jimage[$I] = 'shinkutou.jpg';

$I++;
$Jname[$I] = '수신의 지팡이';
$Jexp[$I] = '수신이 만들어낸 마법의 지팡이. 속성이 없는 무기를 수속성으로 만들 수 있다. 수속성';
$Jtype[$I] = 'SoloAdd';
$Jkind[$I] = 'Weapon';
$Jdetail[$I] = 'AddAttribute';
$Jattribute[$I] = 'Mercury';
$Jpoint[$I] = 50;
$Jprice[$I] = 50;
$Jtotal[$I] = 1;
$Jimage[$I] = 'suijin_no_tsue.jpg';

$I++;
$Jname[$I] = '라임라이트';
$Jexp[$I] = '행운을 부르는 밝은 검. 그러나 행복을 파괴하려는 자는 용서하지 않는다. 천속성';
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'Weapon';
$Jattribute[$I] = 'Uranus';
$Jpoint[$I] = 50;
$Jprice[$I] = 50;
$Jtotal[$I] = 1;
$Jimage[$I] = 'limelight.jpg';

$I++;
$Jname[$I] = '冥화살';
$Jexp[$I] = '멀리서 적을 공격하고 숨통까지 끝어 놓는 성격나쁜 무기. 원거리공격. 명속성';
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'Weapon';
$Jdetail[$I] = 'Fly';
$Jattribute[$I] = 'Pluto';
$Jpoint[$I] = 50;
$Jprice[$I] = 50;
$Jtotal[$I] = 1;
$Jimage[$I] = 'meiya.jpg';

$I++;
$Jname[$I] = '본소드';
$Jexp[$I] = '생물의 뼈가 뭉쳐서 만들어진 사악한 검. 뾰족하지는 않지만 상당히 날카롭다. 명속성';
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'Weapon';
$Jattribute[$I] = 'Pluto';
$Jpoint[$I] = 50;
$Jprice[$I] = 50;
$Jtotal[$I] = 1;
$Jimage[$I] = 'bone_sword.jpg';

$I++;
$Jname[$I] = '데빌포크';
$Jexp[$I] = '악마가 손에 들고 있는 포크형태의 무기. 그대로 식기로 사용하는 경우도 있다. 명속성';
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'Weapon';
$Jattribute[$I] = 'Pluto';
$Jpoint[$I] = 50;
$Jprice[$I] = 50;
$Jtotal[$I] = 1;
$Jimage[$I] = 'devil_fork.jpg';

$I++;
$Jname[$I] = '호박의 망치';
$Jexp[$I] = '琥珀(호박)으로 된 망치. 은은하게 빛나는것이 예쁘다. 토속성';
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'Weapon';
$Jattribute[$I] = 'Saturn';
$Jpoint[$I] = 70;
$Jprice[$I] = 120;
$Jtotal[$I] = 1;
$Jimage[$I] = 'kohaku_no_tsuchi.jpg';

$I++;
$Jname[$I] = '화룡의 검';
$Jexp[$I] = '화룡의 혼이 담긴 검. 그 일격은 화룡의 일격과 동등하다. 화속성';
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'Weapon';
$Jattribute[$I] = 'Mars';
$Jpoint[$I] = 80;
$Jprice[$I] = 100;
$Jtotal[$I] = 1;
$Jimage[$I] = 'karyu_no_ken.jpg';

$I++;
$Jname[$I] = '수룡의 검';
$Jexp[$I] = '수룡의 혼이 담긴 검. 그 일격은 수룡의 일격과 동등하다. 수속성';
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'Weapon';
$Jattribute[$I] = 'Mercury';
$Jpoint[$I] = 80;
$Jprice[$I] = 100;
$Jtotal[$I] = 1;
$Jimage[$I] = 'suiryu_no_ken.jpg';

$I++;
$Jname[$I] = '빛의 검';
$Jexp[$I] = '빛나는 하늘의 검. 모든 악을 베고 모든 견고한 방어를 뚫어버린다. 천속성';
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'Weapon';
$Jattribute[$I] = 'Uranus';
$Jpoint[$I] = 90;
$Jprice[$I] = 150;
$Jtotal[$I] = 1;
$Jimage[$I] = 'hikari_no_ken.jpg';

$I++;
$Jname[$I] = '사신의 낫';
$Jexp[$I] = '너무나도 악하기 때문에 사신외에는 손대는 것조차 금지 된 낫. 명속성';
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'Weapon';
$Jattribute[$I] = 'Pluto';
$Jpoint[$I] = 100;
$Jprice[$I] = 200;
$Jtotal[$I] = 1;
$Jimage[$I] = 'shinigami_no_kama.jpg';

$I++;
$Jname[$I] = '다이어몬드소드';
$Jexp[$I] = '다이아몬드로 만들어진 사치검. 단단해서 공격력도 상당히 높다. 물론 가격도 높다. 토속성';
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'Weapon';
$Jattribute[$I] = 'Saturn';
$Jpoint[$I] = 130;
$Jprice[$I] = 250;
$Jtotal[$I] = 1;
$Jimage[$I] = 'diamond_sword.jpg';

$I++;				#$I = 149;
$Jname[$I] = '위험한방아';
$Jexp[$I] = '아주 위험한 방아. 누구를 공격할지 모른다. 위험한절구와는 서로 끌어당기는 힘이 있다. 천속성';
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'Weapon';
$Jdetail[$I] = 'Kine';
$Jattribute[$I] = 'Uranus';
$Jpoint[$I] = 300;
$Jprice[$I] = 50;
$Jtotal[$I] = 1;
$Jimage[$I] = 'abunai_kine.jpg';

$I++;
$Jname[$I] = '불의 가루주머니';
$Jexp[$I] = '불의 가루가 잔득 들어간 주머니. 풀면 안의 불의 가루가 퍼진다. 명중률:고 화속성';
$Jfirst[$I] = "를 열었다.";
$Jsecond[$I] = "많은 <FONT COLOR=$ColorMars><B>불의 가루</B></FONT>가 퍼지기 시작했다!!";
$Jthird[$I] = "는 <FONT COLOR=$ColorMars><B>불의 가루</B></FONT>를 만지고 말았다.";
$Jmiss[$I] = "는 <FONT COLOR=$ColorMars><B>불의 가루</B></FONT>를 피했다.";
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'Weapon';
$Jattribute[$I] = 'Mars';
$Jpoint[$I] = 3010;
$Jprice[$I] = 20;
$Jtotal[$I] = 1;
$Jimage[$I] = 'hinoko_bukuro.jpg';

$I++;
$Jname[$I] = '히트대거';
$Jexp[$I] = '고온의 대거. 한번 휘둘르면 열파가 적전체를 공격한다. 명중률:고 화속성';
$Jfirst[$I] = "을 휘둘렀다.";
$Jsecond[$I] = "주변에 <FONT COLOR=$ColorMars><B>열파</B></FONT>가 퍼지기 시작한다!!";
$Jthird[$I] = "는 <FONT COLOR=$ColorMars><B>열파</B></FONT>를 정통으로 맞았다.";
$Jmiss[$I] = "에게는 <FONT COLOR=$ColorMars><B>열파</B></FONT>가 닿지 않았다.";
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'Weapon';
$Jattribute[$I] = 'Mars';
$Jpoint[$I] = 3020;
$Jprice[$I] = 40;
$Jtotal[$I] = 1;
$Jimage[$I] = 'heat_dagger.jpg';

$I++;
$Jname[$I] = '데몬핸드';
$Jexp[$I] = '끔찍한 악의 손이 날아 올라 적전체를 공격한다. 명중률:중 명속성';
$Jfirst[$I] = "를 꺼냈다.";
$Jsecond[$I] = "<FONT COLOR=$ColorPluto><B>데몬핸드</B></FONT>가 불길하게 날아오른다!!";
$Jthird[$I] = "는 <FONT COLOR=$ColorPluto><B>데몬핸드</B></FONT>에게 긁혔다!!";
$Jmiss[$I] = "는 <FONT COLOR=$ColorPluto><B>데몬핸드</B></FONT>를 피했다.";
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'Weapon';
$Jattribute[$I] = 'Pluto';
$Jpoint[$I] = 2020;
$Jprice[$I] = 40;
$Jtotal[$I] = 1;
$Jimage[$I] = 'demon_hand.jpg';

$I++;
$Jname[$I] = '안개의 부채';
$Jexp[$I] = '안개가 일어나는 신비한 부채. 명중률:중 수속성';
$Jfirst[$I] = "를 부쳤다.";
$Jsecond[$I] = "부채에서 <FONT COLOR=$ColorMercury><B>안개</B></FONT>가 일기 시작했다!!";
$Jthird[$I] = "는 <FONT COLOR=$ColorMercury><B>안개</B></FONT>를 정통으로 맞았다!!";
$Jmiss[$I] = "에게는 <FONT COLOR=$ColorMercury><B>안개</B></FONT>가 닿지 않았다.";
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'Weapon';
$Jdetail[$I] = 'AddFog';
$Jattribute[$I] = 'Mercury';
$Jpoint[$I] = 2030;
$Jprice[$I] = 60;
$Jtotal[$I] = 1;
$Jimage[$I] = 'kiri_no_ougi.jpg';

$I++;
$Jname[$I] = '아이비랜스';
$Jexp[$I] = '찌르면 덩굴이 늘어나서 적전체에서 HP를 흡수한다. 명중율:고 목속성';
$Jfirst[$I] = "를 찔렀다.";
$Jsecond[$I] = "수십개의 <FONT COLOR=$ColorJupiter><B>덩굴</B></FONT>이 늘어난다!!";
$Jthird[$I] = "는 <FONT COLOR=$ColorJupiter><B>덩굴</B></FONT>에 쏘였다!!";
$Jmiss[$I] = "는 <FONT COLOR=$ColorJupiter><B>덩굴</B></FONT>을 피했다.";
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'Weapon';
$Jdetail[$I] = 'HPabsorb';
$Jattribute[$I] = 'Jupiter';
$Jpoint[$I] = 3030;
$Jprice[$I] = 60;
$Jtotal[$I] = 1;
$Jimage[$I] = 'ivy_lance.jpg';

$I++;
$Jname[$I] = '천둥키드';
$Jexp[$I] = '뇌의 꼬마가 떨어트렸다는 장난감검. 휘둘르면 번개가 발생한다. 명중률:저 천속성';
$Jfirst[$I] = "을 휘둘렀다.";
$Jsecond[$I] = "<FONT COLOR=$ColorUranus><B>번개</B></FONT>가 발생했다!!";
$Jthird[$I] = "는 <FONT COLOR=$ColorUranus><B>번개</B></FONT>에 맞았다!!";
$Jmiss[$I] = "는 <FONT COLOR=$ColorUranus><B>번개</B></FONT>에 맞지 않았다.";
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'Weapon';
$Jattribute[$I] = 'Uranus';
$Jpoint[$I] = 1030;
$Jprice[$I] = 60;
$Jtotal[$I] = 1;
$Jimage[$I] = 'inazuma_kids.jpg';

$I++;
$Jname[$I] = '화염잔';
$Jexp[$I] = '火炎의 힘이 담긴 잔. 잔을 기울이면 그 힘을 발휘한다. 명중율:고 화속성';
$Jfirst[$I] = "을 기울렸다.";
$Jsecond[$I] = "<FONT COLOR=$ColorMars><B>화염의 힘</B></FONT>이 잔에서 흘러내린다!!";
$Jthird[$I] = "는 <FONT COLOR=$ColorMars><B>화염의 힘</B></FONT>을 받았다!!";
$Jmiss[$I] = "는 <FONT COLOR=$ColorMars><B>화염의 힘</B></FONT>에 맞지 않았다.";
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'Weapon';
$Jattribute[$I] = 'Mars';
$Jpoint[$I] = 3040;
$Jprice[$I] = 80;
$Jtotal[$I] = 1;
$Jimage[$I] = 'kaenhai.jpg';

$I++;
$Jname[$I] = '냉기의 잔';
$Jexp[$I] = '冷氣의 힘이 담긴 잔. 잔을 기울이면 그 힘을 발휘한다. 명중율:고 수속성';
$Jfirst[$I] = "을 기울렸다.";
$Jsecond[$I] = "<FONT COLOR=$ColorMercury><B>냉기의 힘</B></FONT>이 잔에서 흘러내린다!!";
$Jthird[$I] = "는 <FONT COLOR=$ColorMercury><B>냉기의 힘</B></FONT>을 받았다!!";
$Jmiss[$I] = "는 <FONT COLOR=$ColorMercury><B>냉기의 힘</B></FONT>에 맞지 않았다.";
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'Weapon';
$Jattribute[$I] = 'Mercury';
$Jpoint[$I] = 3040;
$Jprice[$I] = 80;
$Jtotal[$I] = 1;
$Jimage[$I] = 'reikihai.jpg';

$I++;
$Jname[$I] = '삼림의 잔';
$Jexp[$I] = '森林의 힘이 담긴 잔. 잔을 기울이면 그 힘을 발휘한다. 명중율:고 목속성';
$Jfirst[$I] = "을 기울렸다.";
$Jsecond[$I] = "<FONT COLOR=$ColorJupiter><B>삼림의 힘</B></FONT>이 잔에서 흘러내린다!!";
$Jthird[$I] = "는 <FONT COLOR=$ColorJupiter><B>삼림의 힘</B></FONT>을 받았다!!";
$Jmiss[$I] = "는 <FONT COLOR=$ColorJupiter><B>삼림의 힘</B></FONT>에 맞지 않았다.";
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'Weapon';
$Jattribute[$I] = 'Jupiter';
$Jpoint[$I] = 3040;
$Jprice[$I] = 80;
$Jtotal[$I] = 1;
$Jimage[$I] = 'shinrinhai.jpg';

$I++;
$Jname[$I] = '대지의 잔';
$Jexp[$I] = '大地의 힘이 담긴 잔. 잔을 기울이면 그 힘을 발휘한다. 명중율:고 토속성';
$Jfirst[$I] = "을 기울렸다.";
$Jsecond[$I] = "<FONT COLOR=$ColorSaturn><B>대지의 힘</B></FONT>이 잔에서 흘러내린다!!";
$Jthird[$I] = "는 <FONT COLOR=$ColorSaturn><B>대지의 힘</B></FONT>을 받았다!!";
$Jmiss[$I] = "는 <FONT COLOR=$ColorSaturn><B>대지의 힘</B></FONT>에 맞지 않았다.";
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'Weapon';
$Jattribute[$I] = 'Saturn';
$Jpoint[$I] = 3040;
$Jprice[$I] = 80;
$Jtotal[$I] = 1;
$Jimage[$I] = 'daichihai.jpg';

$I++;
$Jname[$I] = '거대한눈덩이';
$Jexp[$I] = '떼굴떼굴 굴러서 적전체를 짓밟고 지나가는 거대한 눈덩이. 명중률:중 수속성';
$Jfirst[$I] = "를 굴렸다.";
$Jsecond[$I] = "<FONT COLOR=$ColorMercury><B>거대한눈덩이</B></FONT>가 떼굴떼굴 굴러간다!!";
$Jthird[$I] = "는 <FONT COLOR=$ColorMercury><B>거대한눈덩이</B></FONT>에게 짓밟혔다!!";
$Jmiss[$I] = "는 <FONT COLOR=$ColorMercury><B>거대한눈덩이</B></FONT>를 피했다.";
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'Weapon';
$Jattribute[$I] = 'Mercury';
$Jpoint[$I] = 2050;
$Jprice[$I] = 100;
$Jtotal[$I] = 1;
$Jimage[$I] = 'kyodaina_yukidama.jpg';

$I++;
$Jname[$I] = '태고의 채찍';
$Jexp[$I] = '아주 먼 과거의 시대때부터 존재했다. 적전체를 공격할 수 있다. 명중류:고 목속성';
$Jfirst[$I] = "을 크게 휘둘렀다.";
$Jsecond[$I] = "<FONT COLOR=$ColorJupiter><B>태고의 채찍</B></FONT>이 전적체를 가격한다!!";
$Jthird[$I] = "는 <FONT COLOR=$ColorJupiter><B>태고의 채찍</B></FONT>에 맞았다!!";
$Jmiss[$I] = "는 <FONT COLOR=$ColorJupiter><B>태고의 채찍</B></FONT>을 피했다.";
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'Weapon';
$Jattribute[$I] = 'Jupiter';
$Jpoint[$I] = 3050;
$Jprice[$I] = 100;
$Jtotal[$I] = 1;
$Jimage[$I] = 'taiko_no_muchi.jpg';

$I++;
$Jname[$I] = '절벽망치';
$Jexp[$I] = '절벽을 만드는 망치. 적의 후방이 절벽이 되는 초자연적인 힘을 가진다. 명중률:저 토속성';
$Jfirst[$I] = "을 사용했다.";
$Jsecond[$I] = "예언자의 뒤로 계속해서 <FONT COLOR=$ColorSaturn><B>절벽</B></FONT>이 생긴다!!";
$Jthird[$I] = "는 <FONT COLOR=$ColorSaturn><B>절벽</B></FONT>에서 떨어졌다!!";
$Jmiss[$I] = "는 <FONT COLOR=$ColorSaturn><B>절벽</B></FONT>에서 떨어지지 않았다.";
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'Weapon';
$Jattribute[$I] = 'Saturn';
$Jpoint[$I] = 1060;
$Jprice[$I] = 120;
$Jtotal[$I] = 1;
$Jimage[$I] = 'gakettsuchi.jpg';

$I++;
$Jname[$I] = '빛의 오브';
$Jexp[$I] = '빛의 힘이 담긴 오브. 오브를 바치면 그 힘을 발휘한다. 명중율:고 천속성';
$Jfirst[$I] = "을 바쳤다.";
$Jsecond[$I] = "<FONT COLOR=$ColorUranus><B>빛의 힘</B></FONT>이 주변을 비췬다!!";
$Jthird[$I] = "는 <FONT COLOR=$ColorUranus><B>빛의 힘</B></FONT>을 받았다!!";
$Jmiss[$I] = "는 <FONT COLOR=$ColorUranus><B>빛의 힘</B></FONT>이 닿지 않았다.";
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'Weapon';
$Jattribute[$I] = 'Uranus';
$Jpoint[$I] = 3060;
$Jprice[$I] = 120;
$Jtotal[$I] = 1;
$Jimage[$I] = 'hikari_no_orb.jpg';

$I++;
$Jname[$I] = '사라만다의 활';
$Jexp[$I] = '활을 쏘면 하늘에서 화염의 비가 내려 적전체를 공격한다. 명중률:고 화속성';
$Jfirst[$I] = "을 하늘을 향해 쐈다.";
$Jsecond[$I] = "<FONT COLOR=$ColorMars><B>화염의 비</B></FONT>가 쏟아진다!!";
$Jthird[$I] = "에게 <FONT COLOR=$ColorMars><B>화염의 비</B></FONT>가 명중했다!!";
$Jmiss[$I] = "는 <FONT COLOR=$ColorMars><B>화염의 비</B></FONT>을 피했다.";
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'Weapon';
$Jattribute[$I] = 'Mars';
$Jpoint[$I] = 3070;
$Jprice[$I] = 140;
$Jtotal[$I] = 1;
$Jimage[$I] = 'salamander_arrow.jpg';

$I++;
$Jname[$I] = '마신의 목마';
$Jexp[$I] = '스스로 움직이는 목마. 주인의 몸을 지키기도 한다. 명중률:고 목속성 DF100';
$Jfirst[$I] = "가 달려간다.";
$Jsecond[$I] = "<FONT COLOR=$ColorJupiter><B>마신의 목마</B></FONT>가 마구 설친다!!";
$Jthird[$I] = "는 <FONT COLOR=$ColorJupiter><B>마신의 목마</B></FONT>에게 돌격당했다!!";
$Jmiss[$I] = "는 <FONT COLOR=$ColorJupiter><B>마신의 목마</B></FONT>를 피했다.";
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'Weapon';
$Jdetail[$I] = 'OtherP';
$Jattribute[$I] = 'Jupiter';
$Jpoint[$I] = 3080;
$Jfree[$I] = '100';
$Jprice[$I] = 260;
$Jtotal[$I] = 1;
$Jimage[$I] = 'majin_no_mokuba.jpg';

$I++;
$Jname[$I] = '우신도';
$Jexp[$I] = '비의 신이 머무는 도(刀). 비구름을 불러 豪雨(호우)를 내린다. 명중률:중 수속성';
$Jfirst[$I] = "을 휘둘렀다.";
$Jsecond[$I] = "갑자기 <FONT COLOR=$ColorMercury><B>호우</B></FONT>가 내리기 시작했다!!";
$Jthird[$I] = "는 <FONT COLOR=$ColorMercury><B>호우</B></FONT>에 습격당했다!!";
$Jmiss[$I] = "는 <FONT COLOR=$ColorMercury><B>호우</B></FONT>에 습격당하지 않았다.";
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'Weapon';
$Jattribute[$I] = 'Mercury';
$Jpoint[$I] = 2090;
$Jprice[$I] = 180;
$Jtotal[$I] = 1;
$Jimage[$I] = 'ujintou.jpg';

$I++;
$Jname[$I] = '프레아액스';
$Jexp[$I] = '灼熱(작열)의 불길을 뿜어내는 도끼. 만물을 불태워버리는 무서운 무기. 명중률:중 화속성';
$Jfirst[$I] = "를 휘둘렀다.";
$Jsecond[$I] = "<FONT COLOR=$ColorMars><B>작열의 화염</B></FONT>을 내뿜는다!!";
$Jthird[$I] = "는 <FONT COLOR=$ColorMars><B>작열의 화염</B></FONT>에 감싸여 타들어간다!!";
$Jmiss[$I] = "는 <FONT COLOR=$ColorMars><B>작열의 화염</B></FONT>을 피했다.";
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'Weapon';
$Jattribute[$I] = 'Mars';
$Jpoint[$I] = 2100;
$Jprice[$I] = 200;
$Jtotal[$I] = 1;
$Jimage[$I] = 'flare_ax.jpg';

$I++;
$Jname[$I] = '새턴링';
$Jexp[$I] = '硬質(경질)의 원석으로된 고리형태의 무기. 던지면 잘난다. 명중률:저 토속성';
$Jfirst[$I] = "을 던졌다.";
$Jsecond[$I] = "<FONT COLOR=$ColorSaturn><B>새턴링</B></FONT>이 날아간다!!";
$Jthird[$I] = "는 <FONT COLOR=$ColorSaturn><B>새턴링</B></FONT>에 직격했다!!";
$Jmiss[$I] = "는 <FONT COLOR=$ColorSaturn><B>새턴링</B></FONT>을 피했다.";
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'Weapon';
$Jattribute[$I] = 'Saturn';
$Jpoint[$I] = 1200;
$Jprice[$I] = 150;
$Jtotal[$I] = 1;
$Jimage[$I] = 'saturn_ring.jpg';

$I++;				#$I = 169;
$Jname[$I] = '승천궁';
$Jexp[$I] = '승천시에 활은 적전체를 향해 날아간다. 그 공격력은 평상시의 30배가 된다. 명중율:고 천속성';
$Jfirst[$I] = "을 하늘을 향해 쐈다.";
$Jsecond[$I] = "무시무시한 수의 <FONT COLOR=$ColorUranus><B>빛의 화살</B></FONT>이 쏟아내린다!!";
$Jthird[$I] = "에게 <FONT COLOR=$ColorUranus><B>빛의 화살</B></FONT>이 명중했다!!";
$Jmiss[$I] = "는 <FONT COLOR=$ColorUranus><B>빛의 화살</B></FONT>을 피했다.";
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'Weapon';
$Jdetail[$I] = 'LostAT';
$Jattribute[$I] = 'Uranus';
$Jpoint[$I] = 3010;
$Jfree[$I] = 3300;
$Jprice[$I] = 20;
$Jtotal[$I] = 1;
$Jimage[$I] = 'shoutenkyu.jpg';

$I++;
$Jname[$I] = '가죽방패';
$Jexp[$I] = '가죽으로 만든 방패. 상대의 공격을 약하게나마 경감시키는게 겨우. 슬프지만 최약의 방패';
$Jkind[$I] = 'Shield';
$Jpoint[$I] = 10;
$Jprice[$I] = 10;
$Jtotal[$I] = 1;
$Jimage[$I] = 'kawa_no_tate.jpg';

$I++;
$Jname[$I] = '나무방패';
$Jexp[$I] = '나무로된 방패. 방패로 하기에는 너무 믿음직스럽지 못한다. 목속성';
$Jkind[$I] = 'Shield';
$Jattribute[$I] = 'Jupiter';
$Jpoint[$I] = 10;
$Jprice[$I] = 10;
$Jtotal[$I] = 1;
$Jimage[$I] = 'ki_no_tate.jpg';

$I++;
$Jname[$I] = '석판';
$Jexp[$I] = '단순한 석판을 방패로 사용하고 있다. 새겨진 문자는 누구도 읽지 못한다. 토속성';
$Jkind[$I] = 'Shield';
$Jattribute[$I] = 'Saturn';
$Jpoint[$I] = 10;
$Jprice[$I] = 10;
$Jtotal[$I] = 1;
$Jimage[$I] = 'sekiban.jpg';

$I++;
$Jname[$I] = '가죽옷';
$Jexp[$I] = '감촉이 매끈한 가죽으로 된 옷. 추위는 막아도 공격은 막지 못하겠지.';
$Jkind[$I] = 'Armor';
$Jpoint[$I] = 10;
$Jprice[$I] = 10;
$Jtotal[$I] = 1;
$Jimage[$I] = 'kawa_no_fuku.jpg';

$I++;
$Jname[$I] = '면의 옷';
$Jexp[$I] = '면으로 된 옷. 그냥 보통 옷이네. 물론 전투에는 어울리지 않다.';
$Jkind[$I] = 'Armor';
$Jpoint[$I] = 10;
$Jprice[$I] = 10;
$Jtotal[$I] = 1;
$Jimage[$I] = 'nuno_no_fuku.jpg';

$I++;
$Jname[$I] = '가죽모자';
$Jexp[$I] = '끈도 달려있다.、좀 분위기나는 모자. 방어구로서는 한심할뿐.';
$Jkind[$I] = 'Helm';
$Jpoint[$I] = 10;
$Jprice[$I] = 10;
$Jtotal[$I] = 1;
$Jimage[$I] = 'kawa_no_boushi.jpg';

$I++;
$Jname[$I] = '밀짚모자';
$Jexp[$I] = '더운 날에는 역시 이거죠. 그러나 뜨거운 불에는 이걸론 안돼.';
$Jkind[$I] = 'Helm';
$Jpoint[$I] = 10;
$Jprice[$I] = 10;
$Jtotal[$I] = 1;
$Jimage[$I] = 'mugiwara_boushi.jpg';

$I++;
$Jname[$I] = '브론즈장갑';
$Jexp[$I] = '브론즈제 장갑. 중량이 있으면서 강도는 없다. 상대의 공격이 강하면 포기.';
$Jkind[$I] = 'Gauntlet';
$Jpoint[$I] = 10;
$Jprice[$I] = 10;
$Jtotal[$I] = 1;
$Jimage[$I] = 'bronze_no_kote.jpg';

$I++;
$Jname[$I] = '아쿠아글로브';
$Jexp[$I] = '성분의 대부분이 물로 된 글로브. 손에 끼면 기분이 좋다. 수속성';
$Jkind[$I] = 'Gauntlet';
$Jattribute[$I] = 'Mercury';
$Jpoint[$I] = 10;
$Jprice[$I] = 10;
$Jtotal[$I] = 1;
$Jimage[$I] = 'aqua_glove.jpg';

$I++;
$Jname[$I] = '아쿠아슈즈';
$Jexp[$I] = '성분의 대부분이 물로된 신발. 신으면 조금 미끈미끈. 수속성';
$Jkind[$I] = 'Boots';
$Jattribute[$I] = 'Mercury';
$Jpoint[$I] = 10;
$Jprice[$I] = 10;
$Jtotal[$I] = 1;
$Jimage[$I] = 'aqua_shoes.jpg';

$I++;
$Jname[$I] = '브론즈쉴드';
$Jexp[$I] = '브론즈제 방패. 방어력이 낮기때문에 위안밖에 되지않는다.';
$Jkind[$I] = 'Shield';
$Jpoint[$I] = 20;
$Jprice[$I] = 20;
$Jtotal[$I] = 1;
$Jimage[$I] = 'bronze_no_tate.jpg';

$I++;
$Jname[$I] = '정신의 방패';
$Jexp[$I] = '精神이 머무는 방패. 물리적인 방어력은 별로지만 사용하면 정신이 든다.';
$Jkind[$I] = 'Shield';
$Jattribute[$I] = 'Jupiter';
$Jpoint[$I] = 20;
$Jprice[$I] = 20;
$Jtotal[$I] = 1;
$Jimage[$I] = 'seishin_no_tate.jpg';

$I++;
$Jname[$I] = '바위방패';
$Jexp[$I] = '단단한 바위를 깍아서 만든 방패. 거칠게 깍아서 까칠까칠하다. 토속성';
$Jkind[$I] = 'Shield';
$Jattribute[$I] = 'Saturn';
$Jpoint[$I] = 20;
$Jprice[$I] = 20;
$Jtotal[$I] = 1;
$Jimage[$I] = 'iwa_no_tate.jpg';

$I++;
$Jname[$I] = '가죽갑옷';
$Jexp[$I] = '가죽으로 만들어진 갑옷. 움직이기는 편하지만 방어력은 영~ 아니다.';
$Jkind[$I] = 'Armor';
$Jpoint[$I] = 20;
$Jprice[$I] = 20;
$Jtotal[$I] = 1;
$Jimage[$I] = 'kawa_no_yoroi.jpg';

$I++;
$Jname[$I] = '귀여운앞치마';
$Jexp[$I] = '요리를 할때는 꼭 필요한 귀여운 앞치마. 그러나 이 방어력으로는 반대로 요리당한다.';
$Jkind[$I] = 'Armor';
$Jpoint[$I] = 20;
$Jprice[$I] = 20;
$Jtotal[$I] = 1;
$Jimage[$I] = 'kawaii_apron.jpg';

$I++;
$Jname[$I] = '브론즈투구';
$Jexp[$I] = '브론즈제 투구. 꽤 무겁기때문에 장시간 장비하면 목아프다.';
$Jkind[$I] = 'Helm';
$Jpoint[$I] = 20;
$Jprice[$I] = 20;
$Jtotal[$I] = 1;
$Jimage[$I] = 'bronze_no_kabuto.jpg';

$I++;
$Jname[$I] = '아쿠아캡';
$Jexp[$I] = '성분의 대부분이 물로된 모자. 쓰면 머리가 맑아진다. 수속성';
$Jkind[$I] = 'Helm';
$Jattribute[$I] = 'Mercury';
$Jpoint[$I] = 20;
$Jprice[$I] = 20;
$Jtotal[$I] = 1;
$Jimage[$I] = 'aqua_cap.jpg';

$I++;
$Jname[$I] = '아이론렛트';
$Jexp[$I] = '철제 장갑. 녹슬면 손이 안움직인다. 손질을 잘해야한다.';
$Jkind[$I] = 'Gauntlet';
$Jpoint[$I] = 20;
$Jprice[$I] = 20;
$Jtotal[$I] = 1;
$Jimage[$I] = 'iron_let.jpg';

$I++;
$Jname[$I] = '불꽃의 장갑';
$Jexp[$I] = '불꽃이 튀는 장갑. 냉기공격에 대해 확실히 가드해준다. 화속성';
$Jkind[$I] = 'Gauntlet';
$Jattribute[$I] = 'Mars';
$Jpoint[$I] = 20;
$Jprice[$I] = 20;
$Jtotal[$I] = 1;
$Jimage[$I] = 'hibana_no_kote.jpg';

$I++;
$Jname[$I] = '사랑의 슬리퍼';
$Jexp[$I] = '커플로 신고 싶은 사랑의 슬리퍼. 손님에게는 빌려주지 말자.';
$Jkind[$I] = 'Boots';
$Jpoint[$I] = 20;
$Jprice[$I] = 20;
$Jtotal[$I] = 1;
$Jimage[$I] = 'ai_no_slipper.jpg';

$I++;
$Jname[$I] = '스몰가드';
$Jexp[$I] = '아주작은 방패. 그러나 크든 작든 쓰기 나름이다. 용기를 내자';
$Jkind[$I] = 'Shield';
$Jpoint[$I] = 30;
$Jprice[$I] = 30;
$Jtotal[$I] = 1;
$Jimage[$I] = 'small_guard.jpg';

$I++;
$Jname[$I] = '라지가드';
$Jexp[$I] = '아주 큰방패. 그러나 크든 작든 쓰기 나름이다. 방심은 금물';
$Jkind[$I] = 'Shield';
$Jpoint[$I] = 30;
$Jprice[$I] = 30;
$Jtotal[$I] = 1;
$Jimage[$I] = 'large_guard.jpg';

$I++;
$Jname[$I] = '브론즈아머';
$Jexp[$I] = '브론즈제 갑옷. 간단하게 만들어진 갑옷인 만큼 간단하게 뚫을 수 있다.';
$Jkind[$I] = 'Armor';
$Jpoint[$I] = 30;
$Jprice[$I] = 30;
$Jtotal[$I] = 1;
$Jimage[$I] = 'bronze_armor.jpg';

$I++;
$Jname[$I] = '아이론헬름';
$Jexp[$I] = '철제 투구. 누구나 쓰기 편한 표준적 투구이다. 표면은 매끈매끈';
$Jkind[$I] = 'Helm';
$Jpoint[$I] = 30;
$Jprice[$I] = 30;
$Jtotal[$I] = 1;
$Jimage[$I] = 'iron_helm.jpg';

$I++;
$Jname[$I] = '아이스헬름';
$Jexp[$I] = '얼음을 가공해서 만든 투구. 쓰면 이마가 시원해서 잠이 다 깬다. 수속성';
$Jkind[$I] = 'Helm';
$Jattribute[$I] = 'Mercury';
$Jpoint[$I] = 30;
$Jprice[$I] = 30;
$Jtotal[$I] = 1;
$Jimage[$I] = 'ice_helm.jpg';

$I++;
$Jname[$I] = '대지의 장갑';
$Jexp[$I] = '대지에서 만들어진 장갑. 이 대지의 마력이 목속성의 힘을 봉한다. 토속성';
$Jkind[$I] = 'Gauntlet';
$Jattribute[$I] = 'Saturn';
$Jpoint[$I] = 30;
$Jprice[$I] = 30;
$Jtotal[$I] = 1;
$Jimage[$I] = 'daichi_no_kote.jpg';

$I++;
$Jname[$I] = '강귀의 구두';
$Jexp[$I] = '그 옛날 신계에서 난동을 부렸다는 강귀의 구두. 무기의 공격력을 AT50만큼 올려주는 효과가 있다.';
$Jtype[$I] = 'Adds';
$Jkind[$I] = 'Boots';
$Jdetail[$I] = 'ATup';
$Jpoint[$I] = 30;
$Jfree[$I] = 50;
$Jprice[$I] = 80;
$Jtotal[$I] = 1;
$Jimage[$I] = 'gouki_no_kutsu.jpg';

$I++;
$Jname[$I] = '프레임부츠';
$Jexp[$I] = '화염의 날개를 장식한 부츠. 신어도 뜨겁지않다. 화속성';
$Jkind[$I] = 'Boots';
$Jattribute[$I] = 'Mars';
$Jpoint[$I] = 30;
$Jprice[$I] = 30;
$Jtotal[$I] = 1;
$Jimage[$I] = 'flame_boots.jpg';

$I++;
$Jname[$I] = '아이스부츠';
$Jexp[$I] = '얼음을 가공해서 만든 부츠. 미끄러우니까 뛰지 않도록. 수속성';
$Jkind[$I] = 'Boots';
$Jattribute[$I] = 'Mercury';
$Jpoint[$I] = 30;
$Jprice[$I] = 30;
$Jtotal[$I] = 1;
$Jimage[$I] = 'ice_boots.jpg';

$I++;
$Jname[$I] = '대지의 신발';
$Jexp[$I] = '대지에서 만들어진 신발. 제대로 서있으세요. 토속성';
$Jkind[$I] = 'Boots';
$Jattribute[$I] = 'Saturn';
$Jpoint[$I] = 30;
$Jprice[$I] = 30;
$Jtotal[$I] = 1;
$Jimage[$I] = 'daichi_no_kutsu.jpg';

$I++;
$Jname[$I] = '아이론쉴드';
$Jexp[$I] = '철제방패. 방패같은 방패다. 실전적이면 일방적. 보통이며 평범';
$Jkind[$I] = 'Shield';
$Jpoint[$I] = 40;
$Jprice[$I] = 40;
$Jtotal[$I] = 1;
$Jimage[$I] = 'iron_shield.jpg';

$I++;
$Jname[$I] = '프레임쉴드';
$Jexp[$I] = '화염의 깃털로 장식한 방패. 격렬한 눈보라도 막을 수가 있다 화속성';
$Jkind[$I] = 'Shield';
$Jattribute[$I] = 'Mars';
$Jpoint[$I] = 40;
$Jprice[$I] = 40;
$Jtotal[$I] = 1;
$Jimage[$I] = 'flame_shield.jpg';

$I++;
$Jname[$I] = '초목의 방패';
$Jexp[$I] = '풀과 나무로 된 방패. 풀과 나무가 많이 모여서 방어력을 높이고 있다. 목속성';
$Jkind[$I] = 'Shield';
$Jattribute[$I] = 'Jupiter';
$Jpoint[$I] = 40;
$Jprice[$I] = 40;
$Jtotal[$I] = 1;
$Jimage[$I] = 'hayashi_no_tate.jpg';

$I++;
$Jname[$I] = '사슬갑옷';
$Jexp[$I] = '움직이기 편함을 중요시하면서 방어력까지 생각해서 만들어진 갑옷. 신계에서 대인기품';
$Jkind[$I] = 'Armor';
$Jpoint[$I] = 40;
$Jprice[$I] = 40;
$Jtotal[$I] = 1;
$Jimage[$I] = 'kusarikatabira.jpg';

$I++;
$Jname[$I] = '투구벌레투구';
$Jexp[$I] = '투구벌레의 투구인지 투구의 투구벌레인지. 뭐 전자가 명백하지만';
$Jkind[$I] = 'Helm';
$Jpoint[$I] = 40;
$Jprice[$I] = 40;
$Jtotal[$I] = 1;
$Jimage[$I] = 'kabutomushi_kabuto.jpg';

$I++;
$Jname[$I] = '매지컬햇';
$Jexp[$I] = 'MP10을 소비하면 기적의 힘과 공명하여 방어력이 2배가 되는 매력적인 모자';
$Jkind[$I] = 'Helm';
$Jdetail[$I] = 'MagicalP';
$Jpoint[$I] = 40;
$Jfree[$I] = 10;
$Jprice[$I] = 70;
$Jtotal[$I] = 1;
$Jimage[$I] = 'magical_hat.jpg';

$I++;
$Jname[$I] = '프레임멧트';
$Jexp[$I] = '화염의 깃털로 장식한 투구. 차가운 비를 막기에는 최적일지도 모른다. 화속성';
$Jkind[$I] = 'Helm';
$Jattribute[$I] = 'Mars';
$Jpoint[$I] = 40;
$Jprice[$I] = 40;
$Jtotal[$I] = 1;
$Jimage[$I] = 'flame_met.jpg';

$I++;
$Jname[$I] = '강철의 장갑';
$Jexp[$I] = '단련된 강철로 만들어진 장갑. 원형의 무늬부분에서 공격을 막고 싶은 기분';
$Jkind[$I] = 'Gauntlet';
$Jpoint[$I] = 40;
$Jprice[$I] = 40;
$Jtotal[$I] = 1;
$Jimage[$I] = 'hagane_no_kote.jpg';

$I++;
$Jname[$I] = '부리키의 장화';
$Jexp[$I] = '부리키라는 재료이긴 하지만 방어력은 급제점. 다만 발목이 고정되어 있어서 신으면 걷지 못한다.';
$Jkind[$I] = 'Boots';
$Jpoint[$I] = 40;
$Jprice[$I] = 40;
$Jtotal[$I] = 1;
$Jimage[$I] = 'buriki_no_nagagutsu.jpg';

$I++;
$Jname[$I] = '강철방패';
$Jexp[$I] = '단련된 강철로 만들어진 방패. 특별히 좋지도 나쁘지도 않다.';
$Jkind[$I] = 'Shield';
$Jpoint[$I] = 50;
$Jprice[$I] = 50;
$Jtotal[$I] = 1;
$Jimage[$I] = 'hagane_no_tate.jpg';

$I++;
$Jname[$I] = '초경석방패';
$Jexp[$I] = '무지막지하게 단단한 돌로된 방패. 너무나도 단단해서 방패로 가공못해 들고다니기 힘들다.';
$Jkind[$I] = 'Shield';
$Jattribute[$I] = 'Saturn';
$Jpoint[$I] = 50;
$Jprice[$I] = 50;
$Jtotal[$I] = 1;
$Jimage[$I] = 'choukouseki_no_tate.jpg';

$I++;
$Jname[$I] = '아이론아머';
$Jexp[$I] = '철제갑옷. 다소 무겁지만 평상시 동작에는 아무지장 없다. 이거 입고 물에 들어가면 잠긴다.';
$Jkind[$I] = 'Armor';
$Jpoint[$I] = 50;
$Jprice[$I] = 50;
$Jtotal[$I] = 1;
$Jimage[$I] = 'iron_armor.jpg';

$I++;
$Jname[$I] = '영웅의 갑옷';
$Jexp[$I] = '하계의 영웅이 입었다는 갑옷. 더욱이 신계에서는 영웅이라해서 별로 존경받지 못한다.';
$Jkind[$I] = 'Armor';
$Jpoint[$I] = 50;
$Jprice[$I] = 50;
$Jtotal[$I] = 1;
$Jimage[$I] = 'yusha_no_yoroi.jpg';

$I++;
$Jname[$I] = '따듯한코트';
$Jexp[$I] = '입으면 아주 편하고 따듯하다. 코트를 안고 이대로 영원히 잠들고 싶다.';
$Jkind[$I] = 'Armor';
$Jpoint[$I] = 50;
$Jprice[$I] = 50;
$Jtotal[$I] = 1;
$Jimage[$I] = 'attaka_coat.jpg';

$I++;
$Jname[$I] = '아쿠아슈츠';
$Jexp[$I] = '성분의 대부분이 물로된 슈츠. 보온효과가 있어서 따듯하다. 수속성';
$Jkind[$I] = 'Armor';
$Jattribute[$I] = 'Mercury';
$Jpoint[$I] = 50;
$Jprice[$I] = 50;
$Jtotal[$I] = 1;
$Jimage[$I] = 'aqua_suit.jpg';

$I++;
$Jname[$I] = '강철투구';
$Jexp[$I] = '단련된 강철로 된 투구. 이마의 마크에 금이가면 재수가 없다고 한다.';
$Jkind[$I] = 'Helm';
$Jpoint[$I] = 50;
$Jprice[$I] = 50;
$Jtotal[$I] = 1;
$Jimage[$I] = 'hagane_no_kabuto.jpg';

$I++;
$Jname[$I] = '풀관';
$Jexp[$I] = '풀을 독특한 방법으로 짜서 만든 관이다. 대나무 잎이 아니다. 목속성';
$Jkind[$I] = 'Helm';
$Jattribute[$I] = 'Jupiter';
$Jpoint[$I] = 50;
$Jprice[$I] = 50;
$Jtotal[$I] = 1;
$Jimage[$I] = 'kusa_kammuri.jpg';

$I++;
$Jname[$I] = '대지의 투구';
$Jexp[$I] = '대지에서 만들어진 투구. 대지의 침착함이 느껴진다. 토속성';
$Jkind[$I] = 'Helm';
$Jattribute[$I] = 'Saturn';
$Jpoint[$I] = 50;
$Jprice[$I] = 50;
$Jtotal[$I] = 1;
$Jimage[$I] = 'daichi_no_kabuto.jpg';

$I++;
$Jname[$I] = '숲의 방패';
$Jexp[$I] = '숲으로 된 방패. 숲의 수호신이 만들었다고 한다. 향기로운 숲의 냄새가 난다. 목속성';
$Jkind[$I] = 'Shield';
$Jattribute[$I] = 'Jupiter';
$Jpoint[$I] = 60;
$Jprice[$I] = 60;
$Jtotal[$I] = 1;
$Jimage[$I] = 'mori_no_tate.jpg';

$I++;
$Jname[$I] = '강철의 갑옷';
$Jexp[$I] = '단련된 강철로 된 갑옷. 시시한 공격에는 꿈적도 안한다.';
$Jkind[$I] = 'Armor';
$Jpoint[$I] = 60;
$Jprice[$I] = 60;
$Jtotal[$I] = 1;
$Jimage[$I] = 'hagane_no_yoroi.jpg';

$I++;
$Jname[$I] = '비단의 로브';
$Jexp[$I] = '비단으로 잘짜여진 로브. 촉감은 시원해서 막 비벼대고 싶어진다.';
$Jkind[$I] = 'Armor';
$Jpoint[$I] = 60;
$Jprice[$I] = 60;
$Jtotal[$I] = 1;
$Jimage[$I] = 'kinu_no_robe.jpg';

$I++;
$Jname[$I] = '프레임메일';
$Jexp[$I] = '화염의 깃털로 장식한 갑옷. 불타는 화염은 장비하는자의 마음까지도 태워버린다. 화속성';
$Jkind[$I] = 'Armor';
$Jattribute[$I] = 'Mars';
$Jpoint[$I] = 60;
$Jprice[$I] = 60;
$Jtotal[$I] = 1;
$Jimage[$I] = 'flame_mail.jpg';

$I++;
$Jname[$I] = '아이스아머';
$Jexp[$I] = '얼음을 가공해사 만든 갑옷. 고열에 대해서 우수한 내성을 가진다. 수속성';
$Jkind[$I] = 'Armor';
$Jattribute[$I] = 'Mercury';
$Jpoint[$I] = 60;
$Jprice[$I] = 60;
$Jtotal[$I] = 1;
$Jimage[$I] = 'ice_armor.jpg';

$I++;
$Jname[$I] = '강귀의 투구';
$Jexp[$I] = '그 옛날 신계에서 난동을 부렸다는 강귀의 투구. 무기의 공격력을 AT50만큼 높여주는 효과가 있다.';
$Jtype[$I] = 'Adds';
$Jkind[$I] = 'Helm';
$Jdetail[$I] = 'ATup';
$Jpoint[$I] = 60;
$Jfree[$I] = 50;
$Jprice[$I] = 110;
$Jtotal[$I] = 1;
$Jimage[$I] = 'gouki_no_kabuto.jpg';

$I++;
$Jname[$I] = '페어리캡';
$Jexp[$I] = '신계의 구석에 사는 페어리의 모자. 모자가게의 페어리가 열심히 만들었다.';
$Jkind[$I] = 'Helm';
$Jpoint[$I] = 60;
$Jprice[$I] = 60;
$Jtotal[$I] = 1;
$Jimage[$I] = 'fairy_cap.jpg';

$I++;
$Jname[$I] = '강귀의 장갑';
$Jexp[$I] = '그 옛날 신계에서 난동을 부렸다는 강귀의 장갑. 무기의 공격력을 AT50만큼 올려주는 효과가 있다.';
$Jtype[$I] = 'Adds';
$Jkind[$I] = 'Gauntlet';
$Jdetail[$I] = 'ATup';
$Jpoint[$I] = 60;
$Jfree[$I] = 50;
$Jprice[$I] = 110;
$Jtotal[$I] = 1;
$Jimage[$I] = 'gouki_no_kote.jpg';

$I++;
$Jname[$I] = '빛나는 구두';
$Jexp[$I] = '눈부시게 빛나는 구두. 가벼우면서도 튼튼하다. 쓸곳에 고민하는 방어구. 천속성';
$Jkind[$I] = 'Boots';
$Jattribute[$I] = 'Uranus';
$Jpoint[$I] = 60;
$Jprice[$I] = 60;
$Jtotal[$I] = 1;
$Jimage[$I] = 'kagayaki_no_kutsu.jpg';

$I++;
$Jname[$I] = '스카이쉴드';
$Jexp[$I] = '천공에서 태어나 천공을 떠도는 신비의 방패. 기적을 날려버릴 수 있다.';
$Jkind[$I] = 'Shield';
$Jdetail[$I] = 'MiracleR';
$Jpoint[$I] = 70;
$Jprice[$I] = 130;
$Jtotal[$I] = 1;
$Jimage[$I] = 'sky_shield.jpg';

$I++;
$Jname[$I] = '사라만다쉴드';
$Jexp[$I] = '화염의 신수가 머무는 마의 방패. 중심의 화염 속에 신수의 모습이 있다고 한다. 화속성';
$Jkind[$I] = 'Shield';
$Jattribute[$I] = 'Mars';
$Jpoint[$I] = 70;
$Jprice[$I] = 70;
$Jtotal[$I] = 1;
$Jimage[$I] = 'salamander_shield.jpg';

$I++;
$Jname[$I] = '아이스쉴드';
$Jexp[$I] = '얼음으로 가공한 방패. 그 예술적 모습은 불을 잠재우며 사람의 마음도 잠재운다. 수속성';
$Jkind[$I] = 'Shield';
$Jattribute[$I] = 'Mercury';
$Jpoint[$I] = 70;
$Jprice[$I] = 70;
$Jtotal[$I] = 1;
$Jimage[$I] = 'ice_shield.jpg';

$I++;
$Jname[$I] = '강귀의 갑옷';
$Jexp[$I] = '그 옛날 신계에서 난동을 부렸다는 강귀의 갑옷. 무기의 공격력을 AT80까지 높이는 효과가 있다.';
$Jtype[$I] = 'Adds';
$Jkind[$I] = 'Armor';
$Jdetail[$I] = 'ATup';
$Jpoint[$I] = 70;
$Jfree[$I] = 80;
$Jprice[$I] = 150;
$Jtotal[$I] = 1;
$Jimage[$I] = 'gouki_no_yoroi.jpg';

$I++;
$Jname[$I] = '매지컬아머';
$Jexp[$I] = 'MP30을 소비하면 기적의 힘과 공명하여 방어력을 2배로하는 매력적인 갑옷';
$Jkind[$I] = 'Armor';
$Jdetail[$I] = 'MagicalP';
$Jpoint[$I] = 70;
$Jfree[$I] = 30;
$Jprice[$I] = 100;
$Jtotal[$I] = 1;
$Jimage[$I] = 'magical_armor.jpg';

$I++;
$Jname[$I] = '마도사의 주술복';
$Jexp[$I] = '마도사가 주문을 외울때 입는 주술복. 술의 영창을 방해받지 않을려고 견고하게 만들어졌다.';
$Jkind[$I] = 'Armor';
$Jpoint[$I] = 70;
$Jprice[$I] = 70;
$Jtotal[$I] = 1;
$Jimage[$I] = 'madoushi_no_jutsugi.jpg';

$I++;
$Jname[$I] = '강화밴드';
$Jexp[$I] = '전투용으로 강화된 헤어밴드. 면적은 좁지만 방어력은 있다.';
$Jkind[$I] = 'Helm';
$Jpoint[$I] = 70;
$Jprice[$I] = 70;
$Jtotal[$I] = 1;
$Jimage[$I] = 'kyouka_band.jpg';

$I++;
$Jname[$I] = '스노우마스크';
$Jexp[$I] = '눈의 결정을 모아서 만들어진 마스크. 눈을 피할때쓰는 마스크는 아니다. 수속성';
$Jkind[$I] = 'Helm';
$Jattribute[$I] = 'Mercury';
$Jpoint[$I] = 70;
$Jprice[$I] = 70;
$Jtotal[$I] = 1;
$Jimage[$I] = 'snow_mask.jpg';

$I++;
$Jname[$I] = '검사의 장갑';
$Jexp[$I] = '검사용 장갑. 방어력도 무시할 수 없지만 검을 사용하기 편하게 만들어졌다.';
$Jkind[$I] = 'Gauntlet';
$Jpoint[$I] = 70;
$Jprice[$I] = 70;
$Jtotal[$I] = 1;
$Jimage[$I] = 'kenshi_no_kote.jpg';

$I++;
$Jname[$I] = '하드가더';
$Jexp[$I] = '견고한 전투용방패. 적의 공격을 막기편한 크기, 모양을 하고 있다.';
$Jkind[$I] = 'Shield';
$Jpoint[$I] = 80;
$Jprice[$I] = 80;
$Jtotal[$I] = 1;
$Jimage[$I] = 'hard_guarder.jpg';

$I++;
$Jname[$I] = '마법방패';
$Jexp[$I] = '마법을 걸어서 방어능력을 향상시킨 방패. 사용자의 반응은 최상이다.';
$Jkind[$I] = 'Shield';
$Jpoint[$I] = 80;
$Jprice[$I] = 80;
$Jtotal[$I] = 1;
$Jimage[$I] = 'mahou_no_tate.jpg';

$I++;
$Jname[$I] = '몬스터메일';
$Jexp[$I] = '퇴치한 괴물을 신선한 상태로 갑옷으로 만들었다. 괴물의 몸때문에 까칠까칠하다.';
$Jkind[$I] = 'Armor';
$Jpoint[$I] = 80;
$Jprice[$I] = 80;
$Jtotal[$I] = 1;
$Jimage[$I] = 'monster_mail.jpg';

$I++;
$Jname[$I] = '고대의 스톨';
$Jexp[$I] = '의복이라곤 領帶(영대)밖에 없던 시절의 스톨. 당시에는 고가여서 가난한자는 못 샀다.';
$Jkind[$I] = 'Armor';
$Jpoint[$I] = 80;
$Jprice[$I] = 80;
$Jtotal[$I] = 1;
$Jimage[$I] = 'kodai_no_stole.jpg';

$I++;
$Jname[$I] = '수지로 짠 법의';
$Jexp[$I] = '섬세하게 잘짜여진것이 법력을 높이다. 노력을 아끼지않았던 직인에게 박수를 보내고 싶다.';
$Jkind[$I] = 'Armor';
$Jattribute[$I] = 'Jupiter';
$Jpoint[$I] = 80;
$Jprice[$I] = 80;
$Jtotal[$I] = 1;
$Jimage[$I] = 'jushi_de_anda_houi.jpg';

$I++;
$Jname[$I] = '웃음모자';
$Jexp[$I] = '생활에 필요함 웃음. 웃고있을때 살아있다는 느낌이들죠. 자 다같이 웃읍시다!!';
$Jkind[$I] = 'Helm';
$Jpoint[$I] = 80;
$Jprice[$I] = 80;
$Jtotal[$I] = 1;
$Jimage[$I] = 'warai_no_boushi.jpg';

$I++;
$Jname[$I] = '법술사의 장갑';
$Jexp[$I] = '어떤 법술사가 친구 법술사를 위해서 개발한 장갑. 그런데 친구는 써주질 않았다.';
$Jkind[$I] = 'Gauntlet';
$Jpoint[$I] = 80;
$Jprice[$I] = 80;
$Jtotal[$I] = 1;
$Jimage[$I] = 'houjutsushi_no_kote.jpg';

$I++;
$Jname[$I] = '아름다운유리세공';
$Jexp[$I] = '투명하며 아름답다. 보는 이의 넋을 나가게 하는 유리세공. 방패로 쓰다니 말도 안돼';
$Jkind[$I] = 'Shield';
$Jpoint[$I] = 90;
$Jprice[$I] = 160;
$Jtotal[$I] = 1;
$Jimage[$I] = 'utsukushii_garasuzaiku.jpg';

$I++;
$Jname[$I] = '드래곤의 갑옷';
$Jexp[$I] = '전설의 드래곤의 몸에서 태어난 갑옷. 용의 비늘이 기적을 막는다.';
$Jkind[$I] = 'Armor';
$Jdetail[$I] = 'MiracleB';
$Jpoint[$I] = 90;
$Jprice[$I] = 120;
$Jtotal[$I] = 1;
$Jimage[$I] = 'dragon_no_yoroi.jpg';

$I++;
$Jname[$I] = '스카이아머';
$Jexp[$I] = '천공에서 태어나 천공을 떠도는 신비의 갑옷. 기적을 날려버릴 수 있다.';
$Jkind[$I] = 'Armor';
$Jdetail[$I] = 'MiracleR';
$Jpoint[$I] = 90;
$Jprice[$I] = 150;
$Jtotal[$I] = 1;
$Jimage[$I] = 'sky_armor.jpg';

$I++;
$Jname[$I] = '메테오라이트헬름';
$Jexp[$I] = '운석을 사용하여 만든 투구. 그 운석은 미지의 물질을 성분으로 포함하고 있었다고 한다.';
$Jkind[$I] = 'Helm';
$Jpoint[$I] = 90;
$Jprice[$I] = 90;
$Jtotal[$I] = 1;
$Jimage[$I] = 'meteorite_helm.jpg';

$I++;
$Jname[$I] = '버섯모자';
$Jexp[$I] = '버섯모양을 하고있는 투구. 기묘한 모양이지만 그 방어력은 높다.';
$Jkind[$I] = 'Helm';
$Jpoint[$I] = 90;
$Jprice[$I] = 90;
$Jtotal[$I] = 1;
$Jimage[$I] = 'kinokonokatachi.jpg';

$I++;
$Jname[$I] = '미라클부츠';
$Jexp[$I] = '기적을 일으키는 부츠. MP소비없이 한번만 기적을 일으킬수 있다.';
$Jkind[$I] = 'Boots';
$Jdetail[$I] = 'UseMiracle';
$Jpoint[$I] = 90;
$Jprice[$I] = 90;
$Jtotal[$I] = 1;
$Jimage[$I] = 'miracle_boots.jpg';

$I++;
$Jname[$I] = '더블쉴드';
$Jexp[$I] = '이중구조로 된 방패. 한장이 꽤 두겁기때문에 전체적으로 강고하다.';
$Jkind[$I] = 'Shield';
$Jpoint[$I] = 100;
$Jprice[$I] = 100;
$Jtotal[$I] = 1;
$Jimage[$I] = 'double_shield.jpg';

$I++;
$Jname[$I] = '패왕의 갑옷';
$Jexp[$I] = '먼 옛날 패왕이 몸에 지니고 있었다는 갑옷. 천한자는 접근조차 할 수 없다.';
$Jkind[$I] = 'Armor';
$Jpoint[$I] = 100;
$Jprice[$I] = 100;
$Jtotal[$I] = 1;
$Jimage[$I] = 'haou_no_yoroi.jpg';

$I++;
$Jname[$I] = '청춘의 교복';
$Jexp[$I] = '숭고한 뜻을 가슴으로~~ 바람부는 언덕을 향해 서서~~ 영광있으리~~ 아 우리들의 청춘고등학교~♪';
$Jkind[$I] = 'Armor';
$Jpoint[$I] = 100;
$Jprice[$I] = 100;
$Jtotal[$I] = 1;
$Jimage[$I] = 'seishun_no_seifuku.jpg';

$I++;
$Jname[$I] = '대지의 투구';
$Jexp[$I] = '대지에서 만들어진 투구. 강력한 대지의 수호를 느끼지 않을 수가 없다. 토속성';
$Jkind[$I] = 'Armor';
$Jattribute[$I] = 'Saturn';
$Jpoint[$I] = 100;
$Jprice[$I] = 100;
$Jtotal[$I] = 1;
$Jimage[$I] = 'daichi_no_yoroi.jpg';

$I++;
$Jname[$I] = '반짝반짝드레스';
$Jexp[$I] = '반짝반짝 빛나는 예쁜 드레스. 지극히 방어효과가 높은 방어구이기도 하다. 천속성';
$Jkind[$I] = 'Armor';
$Jattribute[$I] = 'Uranus';
$Jpoint[$I] = 100;
$Jprice[$I] = 200;
$Jtotal[$I] = 1;
$Jimage[$I] = 'kirakira_dress.jpg';

$I++;
$Jname[$I] = '레인보우쉴드';
$Jexp[$I] = '무지개색으로 빛나는 예쁜 방패. 무지개를 너무 좋아하던 신이 무지개를 닦아서 만들었다.';
$Jkind[$I] = 'Shield';
$Jpoint[$I] = 110;
$Jprice[$I] = 110;
$Jtotal[$I] = 1;
$Jimage[$I] = 'rainbow_shield.jpg';

$I++;
$Jname[$I] = '레인보우헬름';
$Jexp[$I] = '무지개색의 빛을 반사하는 예쁜 투구. 무지개를 너무 좋아하던 신이 무지개를 반죽해서 만들었다.';
$Jkind[$I] = 'Helm';
$Jpoint[$I] = 110;
$Jprice[$I] = 110;
$Jtotal[$I] = 1;
$Jimage[$I] = 'rainbow_helm.jpg';

$I++;
$Jname[$I] = '레인보우렛트';
$Jexp[$I] = '무지개의 신비를 느끼게 하는 예쁜 장갑. 무지개를 너무 좋아하던 신이 무지개를 뽑아서 만들었다.';
$Jkind[$I] = 'Gauntlet';
$Jpoint[$I] = 110;
$Jprice[$I] = 110;
$Jtotal[$I] = 1;
$Jimage[$I] = 'rainbow_let.jpg';

$I++;
$Jname[$I] = '드래곤의 방패';
$Jexp[$I] = '전설의 드래곤의 몸에서 태어난 방패. 용의 비늘이 기적을 막는다.';
$Jkind[$I] = 'Shield';
$Jdetail[$I] = 'MiracleB';
$Jpoint[$I] = 120;
$Jprice[$I] = 150;
$Jtotal[$I] = 1;
$Jimage[$I] = 'dragon_no_tate.jpg';

$I++;
$Jname[$I] = '배틀아머';
$Jexp[$I] = '전투용을 특화한 갑옷. 그만큼 견고하다. 그러나 전투이외의 갑옷으론?';
$Jkind[$I] = 'Armor';
$Jpoint[$I] = 120;
$Jprice[$I] = 120;
$Jtotal[$I] = 1;
$Jimage[$I] = 'battle_armor.jpg';

$I++;
$Jname[$I] = '원더망토';
$Jexp[$I] = '세상에서도 기괴한 망토. 수수께끼에 쌓이는 수수께끼가 수수께끼를 불러, 무엇이 수수께끼인지조차 이미 수수께끼';
$Jkind[$I] = 'Armor';
$Jpoint[$I] = 120;
$Jprice[$I] = 120;
$Jtotal[$I] = 1;
$Jimage[$I] = 'wonder_mantle.jpg';

$I++;
$Jname[$I] = '양염의 갑옷';
$Jexp[$I] = '갑옷에서 발생하는 초고열때문에 陽炎(양염)이 생기는 갑옷. 화속성';
$Jkind[$I] = 'Armor';
$Jattribute[$I] = 'Mars';
$Jpoint[$I] = 120;
$Jprice[$I] = 120;
$Jtotal[$I] = 1;
$Jimage[$I] = 'kagerou_no_yoroi.jpg';

$I++;
$Jname[$I] = '천사의 방패';
$Jexp[$I] = '천사의 방패. 적에게서 어떤 공격을 받든 어떤 상처를 입든 단번에 회복한다. 기적도 막는다.';
$Jkind[$I] = 'Shield';
$Jdetail[$I] = 'MiracleB';
$Jpoint[$I] = 130;
$Jprice[$I] = 160;
$Jtotal[$I] = 1;
$Jimage[$I] = 'angel_shield.jpg';

$I++;
$Jname[$I] = '레인보우메일';
$Jexp[$I] = '무지개의 저력을 숨긴 예쁜 갑옷. 무지개를 너무 좋아하던 신이 무지개를 뭉쳐서 만들었다.';
$Jkind[$I] = 'Armor';
$Jpoint[$I] = 130;
$Jprice[$I] = 130;
$Jtotal[$I] = 1;
$Jimage[$I] = 'rainbow_mail.jpg';

$I++;
$Jname[$I] = '천사의 모자';
$Jexp[$I] = '천사의 모자. 그 어떤 충격도 완전히 흡수하는 부드러움을 가진다. 기적도 막는다.';
$Jkind[$I] = 'Helm';
$Jdetail[$I] = 'MiracleB';
$Jpoint[$I] = 130;
$Jprice[$I] = 160;
$Jtotal[$I] = 1;
$Jimage[$I] = 'angel_no_boushi.jpg';

$I++;
$Jname[$I] = '천사의 장갑';
$Jexp[$I] = '천사의 장갑. 무겁고 강렬한 공격에도 가볍게 막아낸다. 기적도 막는다.';
$Jkind[$I] = 'Gauntlet';
$Jdetail[$I] = 'MiracleB';
$Jpoint[$I] = 130;
$Jprice[$I] = 160;
$Jtotal[$I] = 1;
$Jimage[$I] = 'angel_no_kote.jpg';

$I++;
$Jname[$I] = '꿈꾸는 모자';
$Jexp[$I] = '환상적으로 수비능력도 높은 모자지만 이 모자를 쓴자는 환각을 보게 된다.';
$Jkind[$I] = 'Helm';
$Jdetail[$I] = 'SelfIllusion';
$Jattribute[$I] = 'Jupiter';
$Jpoint[$I] = 140;
$Jprice[$I] = 170;
$Jtotal[$I] = 1;
$Jimage[$I] = 'yumemiru_boushi.jpg';

$I++;
$Jname[$I] = '천사의 갑옷';
$Jexp[$I] = '천사의 갑옷. 사악한 공격을 모두 흘러보내며 상처하나 남기지 않는 경이적인 방어구. 기적도 막는다.';
$Jkind[$I] = 'Armor';
$Jdetail[$I] = 'MiracleB';
$Jpoint[$I] = 150;
$Jprice[$I] = 180;
$Jtotal[$I] = 1;
$Jimage[$I] = 'angel_armor.jpg';

$I++;
$Jname[$I] = '결계석';
$Jexp[$I] = '공격을 막는 결계를 치는 돌. 결계의 방어력은 높아 다소의 공격에는 꿈적도 않는다.';
$Jkind[$I] = 'OtherP';
$Jpoint[$I] = 200;
$Jprice[$I] = 200;
$Jtotal[$I] = 1;
$Jimage[$I] = 'kekkaiseki.jpg';

$I++;				#$I = 268;
$Jname[$I] = '신의 방패';
$Jexp[$I] = '신이 사용한다는 궁극의 방패. 지나친 신의 품격에 꺼림직한 마음의 소유자는 엉겁결에 도망간다.';
$Jkind[$I] = 'Shield';
$Jpoint[$I] = 300;
$Jprice[$I] = 300;
$Jtotal[$I] = 1;
$Jimage[$I] = 'kami_no_tate.jpg';

$I++;
$Jname[$I] = '화성의 반지';
$Jexp[$I] = '공격을 받으면 불의 정령이 나와 받은 데미지만큼 적전체로 반격. 명중률:중 화속성';
$Jsecond[$I] = "<FONT COLOR=$ColorMars><B>화성의 반지</B></FONT>에서 <FONT COLOR=$ColorMars><B>불의 정령</B></FONT>이 나타나 <FONT COLOR=$ColorMars><B>화염</B></FONT>을 뿜었다.";
$Jthird[$I] = "는 <FONT COLOR=$ColorMars><B>화염</B></FONT>을 맞았다!!";
$Jmiss[$I] = "는 <FONT COLOR=$ColorMars><B>화염</B></FONT>을 피했다.";
$Jkind[$I] = 'Ring';
$Jdetail[$I] = 'AllAct';
$Jattribute[$I] = 'Mars';
$Jprice[$I] = 100;
$Jtotal[$I] = 1;
$Jimage[$I] = 'kasei_no_yubiwa.jpg';

$I++;
$Jname[$I] = '수성의 반지';
$Jexp[$I] = '물의 정령이 머무는 반지. 공격을 받으면 물의 정령이 나와서 공격한자에게 안개를 선물한다. 수속성';
$Jsecond[$I] = "<FONT COLOR=$ColorMercury><B>수성의 반지</B></FONT>에서 <FONT COLOR=$ColorMercury><B>물의 정령</B></FONT>이 나타나 <FONT COLOR=$ColorMercury><B>안개</B></FONT>를 내뿜는다.";
$Jkind[$I] = 'Ring';
$Jdetail[$I] = 'Fog';
$Jattribute[$I] = 'Mercury';
$Jprice[$I] = 100;
$Jtotal[$I] = 1;
$Jimage[$I] = 'suisei_no_yubiwa.jpg';

$I++;
$Jname[$I] = '목성의 반지';
$Jexp[$I] = '나무의 정령이 머무는 반지. 공격을 받으면 나무의 정령이 나타나 공격한자에게 환각을 보여준다. 목속성';
$Jsecond[$I] = "<FONT COLOR=$ColorJupiter><B>목성의 반지</B></FONT>에서 <FONT COLOR=$ColorJupiter><B>나무의 정령</B></FONT>이 나타나 <FONT COLOR=$ColorJupiter><B>환각</B></FONT>을 보여준다.";
$Jkind[$I] = 'Ring';
$Jdetail[$I] = 'Illusion';
$Jattribute[$I] = 'Jupiter';
$Jprice[$I] = 100;
$Jtotal[$I] = 1;
$Jimage[$I] = 'mokusei_no_yubiwa.jpg';

$I++;
$Jname[$I] = '토성의 반지';
$Jexp[$I] = '공격을 받으면 흙의 정령이 나타나 공격한자에게 데미지의 2배로 반격한다. 토속성';
$Jsecond[$I] = "<FONT COLOR=$ColorSaturn><B>토성의 반지</B></FONT>에서 <FONT COLOR=$ColorSaturn><B>흙의 정령</B></FONT>이 나타나 <FONT COLOR=$ColorSaturn><B>초경질의 검</B></FONT>으로 반격했다.";
$Jkind[$I] = 'Ring';
$Jdetail[$I] = 'TargetAct';
$Jattribute[$I] = 'Saturn';
$Jprice[$I] = 100;
$Jtotal[$I] = 1;
$Jimage[$I] = 'dosei_no_yubiwa.jpg';

$I++;
$Jname[$I] = '천왕의 반지';
$Jexp[$I] = '天王이 머무는 반지. 공격을 받으면 천왕이 나타나 공격한자에게 섬광을 퍼붓는다. 천속성';
$Jsecond[$I] = "<FONT COLOR=$ColorUranus><B>천왕의 반지</B></FONT>에서 <FONT COLOR=$ColorUranus><B>天王</B></FONT>이 나타나 <FONT COLOR=$ColorUranus><B>섬광</B></FONT>을 퍼붓는다.";
$Jkind[$I] = 'Ring';
$Jdetail[$I] = 'Flash';
$Jattribute[$I] = 'Uranus';
$Jprice[$I] = 100;
$Jtotal[$I] = 1;
$Jimage[$I] = 'tennou_no_yubiwa.jpg';

$I++;
$Jname[$I] = '명왕의 반지';
$Jexp[$I] = '冥王이 머무는 반지. 공격을 받으면 명왕이 나타나 공격한자에게 암운을 부른다. 명속성';
$Jsecond[$I] = "<FONT COLOR=$ColorPluto><B>명왕의 반지</B></FONT>에서 <FONT COLOR=$ColorPluto><B>冥王</B></FONT>이 나타나 <FONT COLOR=$ColorPluto><B>암운</B></FONT>을 불렀다.";
$Jkind[$I] = 'Ring';
$Jdetail[$I] = 'DarkCloud';
$Jattribute[$I] = 'Pluto';
$Jprice[$I] = 100;
$Jtotal[$I] = 1;
$Jimage[$I] = 'meiou_no_yubiwa.jpg';

$I++;
$Jname[$I] = '금성의 반지';
$Jexp[$I] = '공격을 받으면 금의 정령이 나타 공격한자에게서 데미지의 2배분의 돈을 빼앗는다. 금속성';
$Jsecond[$I] = "<FONT COLOR=$ColorVenus><B>금성의 반지</B></FONT>에서 <FONT COLOR=$ColorVenus><B>금의 정령</B></FONT>이 나타나 <FONT COLOR=$ColorVenus><B>돈초대</B></FONT>를 시도한다.";
$Jkind[$I] = 'Ring';
$Jdetail[$I] = 'GPabsorb';
$Jattribute[$I] = 'Venus';
$Jprice[$I] = 100;
$Jtotal[$I] = 1;
$Jimage[$I] = 'kinsei_no_yubiwa.jpg';

$I++;
$Jname[$I] = '해왕의 반지';
$Jexp[$I] = '海王이 머무는 반지. 반지의 소유자의 MP를 받은 데미지의 2배분 회복시킨다. 해속성';
$Jsecond[$I] = "<FONT COLOR=$ColorNeptune><B>해왕의 반지</B></FONT>에서 <FONT COLOR=$ColorNeptune><B>海王</B></FONT>이 나타나 <FONT COLOR=$ColorNeptune><B>기적의 향기</B></FONT>을 내뿜는다.";
$Jkind[$I] = 'Ring';
$Jdetail[$I] = 'MPup';
$Jattribute[$I] = 'Neptune';
$Jprice[$I] = 100;
$Jtotal[$I] = 1;
$Jimage[$I] = 'kaiou_no_yubiwa.jpg';

$I++;
$Jname[$I] = '신비의 옷';
$Jexp[$I] = '신의 힘이 담긴 옷. 적에게서 받은 무속성공격을 흡수해서 HP를 회복한다.';
$Jkind[$I] = 'SoloP';
$Jdetail[$I] = 'ATabsorb';
$Jprice[$I] = 100;
$Jtotal[$I] = 2;
$Jimage[$I] = 'shimpi_no_koromo.jpg';

$I++;
$Jname[$I] = '웨폰미러';
$Jexp[$I] = '상대에게서 받은 무속성공격을 반사하는 거울. 혼신의 일격을 반사당하면 끝장이다.';
$Jkind[$I] = 'SoloP';
$Jdetail[$I] = 'WeaponM';
$Jprice[$I] = 100;
$Jtotal[$I] = 4;
$Jimage[$I] = 'weapon_mirror.jpg';

$I++;
$Jname[$I] = '미라클미러';
$Jexp[$I] = '상대에서 받은 기적을 반사하는 거울. 어떤 기적이든 그대로 돌려준다.';
$Jkind[$I] = 'SoloP';
$Jdetail[$I] = 'MiracleM';
$Jprice[$I] = 100;
$Jtotal[$I] = 4;
$Jimage[$I] = 'miracle_mirror.jpg';

$I++;				#$I = 280;
$Jname[$I] = '슈퍼미러';
$Jexp[$I] = '상대에게서 받은 모든 공격을 반사한다. 그야말로 갓필드 최후의 히든카드';
$Jkind[$I] = 'SoloP';
$Jdetail[$I] = 'SuperM';
$Jprice[$I] = 200;
$Jtotal[$I] = 2;
$Jimage[$I] = 'super_mirror.jpg';

$I++;
$Jname[$I] = '≪화염구≫';
$Jexp[$I] = '조그만 화염의 구슬이 날아가 상대를 공격하는 기적. 원거리공격. 화속성';
$Jsecond[$I] = "<FONT COLOR=$ColorMars><B>불의 구슬</B></FONT>이 날아간다!!";
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'TargetAct';
$Jdetail[$I] = 'Fly';
$Jattribute[$I] = 'Mars';
$Jmp[$I] = 20;
$Jpoint[$I] = 20;
$Jprice[$I] = 20;
$Jtotal[$I] = 1;
$Jimage[$I] = 'hinotama.jpg';

$I++;
$Jname[$I] = '≪氷≫';
$Jexp[$I] = '얼음뭉치가 출현해서 적에게 돌격하는 기적. 수속성';
$Jsecond[$I] = "<FONT COLOR=$ColorMercury><B>얼음뭉치</B></FONT>가 출련해서 돌격한다!!";
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'TargetAct';
$Jattribute[$I] = 'Mercury';
$Jmp[$I] = 20;
$Jpoint[$I] = 40;
$Jprice[$I] = 30;
$Jtotal[$I] = 1;
$Jimage[$I] = 'koori.jpg';

$I++;
$Jname[$I] = '≪안개≫';
$Jexp[$I] = '짙은 안개가 발생해서 상대의 주변에 머무는 기적. 상대는 자신의 위치를 알 수없게 된다. 수속성';
$Jsecond[$I] = "<FONT COLOR=$ColorMercury><B>안개</B></FONT>가 발생했다.";
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'TargetAct';
$Jdetail[$I] = 'Fog';
$Jattribute[$I] = 'Mercury';
$Jmp[$I] = 30;
$Jprice[$I] = 40;
$Jtotal[$I] = 1;
$Jimage[$I] = 'kiri.jpg';

$I++;
$Jname[$I] = '≪거목≫';
$Jexp[$I] = '거대한 나무가 적의 곁에서 넘어지는 기적. 나무에 깔리면 무사하지는 못한다. 목속성';
$Jsecond[$I] = "<FONT COLOR=$ColorJupiter><B>거목</B></FONT>이 넘어진다!!";
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'TargetAct';
$Jattribute[$I] = 'Jupiter';
$Jmp[$I] = 30;
$Jpoint[$I] = 50;
$Jprice[$I] = 30;
$Jtotal[$I] = 1;
$Jimage[$I] = 'touboku.jpg';

$I++;
$Jname[$I] = '≪음색≫';
$Jexp[$I] = '기분 좋은 음색이 들려오면서 弱風病, 强風病, 안개, 섬광의 상태이상을 치료하는 기적';
$Jsecond[$I] = "기분 좋은 <B>음색</B>이 들려온다.";
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'ToneCure';
$Jmp[$I] = 30;
$Jprice[$I] = 100;
$Jtotal[$I] = 1;
$Jimage[$I] = 'neiro.jpg';

$I++;
$Jname[$I] = '≪모래폭풍≫';
$Jexp[$I] = '격렬한 모래폭풍이 일어나 적전체를 공격하는 기적. 명중률:중 토속성';
$Jsecond[$I] = "격렬한 <FONT COLOR=$ColorSaturn><B>모래폭풍</B></FONT>이 일어난다!!";
$Jthird[$I] = "는 <FONT COLOR=$ColorSaturn><B>모래폭풍</B></FONT>에 빨려들어갔다!!";
$Jmiss[$I] = "는 <FONT COLOR=$ColorSaturn><B>모래폭풍</B></FONT>에 말려들지 않았다.";
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'AllAct';
$Jattribute[$I] = 'Saturn';
$Jmp[$I] = 40;
$Jpoint[$I] = 2050;
$Jprice[$I] = 30;
$Jtotal[$I] = 1;
$Jimage[$I] = 'sunaarashi.jpg';

$I++;
$Jname[$I] = '≪섬광≫';
$Jexp[$I] = '강렬한 섬광이 발생해서 적전체를 공격하는 기적. 명중률:저 천속성';
$Jsecond[$I] = "강렬한 <FONT COLOR=$ColorUranus><B>섬광</B></FONT>이 발생했다!!";
$Jthird[$I] = "는 <FONT COLOR=$ColorUranus><B>섬광</B></FONT>을 정통으로 맞았다!!";
$Jmiss[$I] = "에게는 <FONT COLOR=$ColorUranus><B>섬광</B></FONT>이 닿지 않았다.";
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'AllAct';
$Jdetail[$I] = 'AddFlash';
$Jattribute[$I] = 'Uranus';
$Jmp[$I] = 40;
$Jpoint[$I] = 1020;
$Jprice[$I] = 30;
$Jtotal[$I] = 1;
$Jimage[$I] = 'senkou.jpg';

$I++;
$Jname[$I] = '≪재보≫';
$Jexp[$I] = '재물과 보물이 내려오는 기쁜 기적. 100G를 입수하게 된다. 금속성';
$Jsecond[$I] = "<FONT COLOR=$ColorVenus><B>재보</B></FONT>가 내려온다.";
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'GPup';
$Jattribute[$I] = 'Venus';
$Jmp[$I] = 40;
$Jpoint[$I] = 100;
$Jprice[$I] = 80;
$Jtotal[$I] = 1;
$Jimage[$I] = 'zaihou.jpg';

$I++;
$Jname[$I] = '≪낙석≫';
$Jexp[$I] = '거대한 바위가 적을 향해 떨어지는 기적. 바위에 깔리면 데미지는 면하지 못할 것이다. 토속성';
$Jsecond[$I] = "<FONT COLOR=$ColorSaturn><B>거대한 바위</B></FONT>가 떨어진다!!";
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'TargetAct';
$Jattribute[$I] = 'Saturn';
$Jmp[$I] = 50;
$Jpoint[$I] = 80;
$Jprice[$I] = 30;
$Jtotal[$I] = 1;
$Jimage[$I] = 'rakuseki.jpg';

$I++;
$Jname[$I] = '≪암운≫';
$Jexp[$I] = '적의 근처에 암운을 부르는 기적. 불러진 암운은 적의 머리위에서 불길하게 소용돌이 친다. 명속성';
$Jsecond[$I] = "<FONT COLOR=$ColorPluto><B>암운</B></FONT>이 떠돌아 왔다!!";
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'TargetAct';
$Jdetail[$I] = 'DarkCloud';
$Jattribute[$I] = 'Pluto';
$Jmp[$I] = 50;
$Jprice[$I] = 50;
$Jtotal[$I] = 1;
$Jimage[$I] = 'anun.jpg';

$I++;
$Jname[$I] = '≪가성≫';
$Jexp[$I] = '마음에 울리는 예쁜 가성이 들려오면서 모든 상태이상을 치료하는 기적.';
$Jsecond[$I] = "마음에 울리는 <B>예쁜 가성</B>이 들려온다.";
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'SongCure';
$Jmp[$I] = 50;
$Jprice[$I] = 150;
$Jtotal[$I] = 1;
$Jimage[$I] = 'utagoe.jpg';

$I++;
$Jname[$I] = '≪난기류≫';
$Jexp[$I] = '돌연 난기류가 발생해서 상대에게 받은 기적을 날려버리는 기적.';
$Jsecond[$I] = "돌연히 발생한 <B>난기류</B>기 기적을 날려버렸다!!";
$Jkind[$I] = 'SoloP';
$Jdetail[$I] = 'MiracleR';
$Jmp[$I] = 50;
$Jprice[$I] = 80;
$Jtotal[$I] = 1;
$Jimage[$I] = 'rankiryu.jpg';

$I++;
$Jname[$I] = '≪風≫';
$Jexp[$I] = '적에게 짜증나는 바람을 보내는 기적. 弱風病에 감염되거나 또는 병이 악화한다.';
$Jsecond[$I] = "<B>짜증나는 바람</B>이 분다.";
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'TargetAct';
$Jdetail[$I] = 'WeakWind';
$Jmp[$I] = 60;
$Jprice[$I] = 70;
$Jtotal[$I] = 1;
$Jimage[$I] = 'kaze.jpg';

$I++;
$Jname[$I] = '≪炎≫';
$Jexp[$I] = '뜨거운 불길이 상대방을 덮치는 기적. 만지면 화상을 입는다. 화속성';
$Jsecond[$I] = "<FONT COLOR=$ColorMars><B>화염</B></FONT>이 덮쳐온다!!";
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'TargetAct';
$Jattribute[$I] = 'Mars';
$Jmp[$I] = 60;
$Jpoint[$I] = 100;
$Jprice[$I] = 30;
$Jtotal[$I] = 1;
$Jimage[$I] = 'honoo.jpg';

$I++;
$Jname[$I] = '≪열선≫';
$Jexp[$I] = '고온의 熱線(열선)을 퍼부어 적전체를 공격하는 기적. 명중률:고 화속성';
$Jsecond[$I] = "고온의 <FONT COLOR=$ColorMars><B>열선</B></FONT>이 발생했다!!";
$Jthird[$I] = "는 <FONT COLOR=$ColorMars><B>열선</B></FONT>에 맞았다!!";
$Jmiss[$I] = "는 <FONT COLOR=$ColorMars><B>열선</B></FONT>을 피했다.";
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'AllAct';
$Jattribute[$I] = 'Mars';
$Jmp[$I] = 60;
$Jpoint[$I] = 3040;
$Jprice[$I] = 30;
$Jtotal[$I] = 1;
$Jimage[$I] = 'nessen.jpg';

$I++;
$Jname[$I] = '≪泉≫';
$Jexp[$I] = '샘이 솟아나면서 회복의 물이 되어 쏟아지는 기적. HP100회복한다. 해속성';
$Jsecond[$I] = "<FONT COLOR=$ColorNeptune><B>샘</B></FONT>이 솟아나면서 회복의 물이 되어 쏟아진다.";
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'HPup';
$Jattribute[$I] = 'Neptune';
$Jmp[$I] = 60;
$Jpoint[$I] = 100;
$Jprice[$I] = 40;
$Jtotal[$I] = 1;
$Jimage[$I] = 'izumi.jpg';

$I++;
$Jname[$I] = '≪벽≫';
$Jexp[$I] = '수비의 벽이 나타나 적의 무속성공격을 완전히 방어하는 기적.';
$Jsecond[$I] = "갑자기 나타난 <B>수비의 벽</B>이 공격을 막았다!!";
$Jkind[$I] = 'SoloP';
$Jdetail[$I] = 'WeaponB';
$Jmp[$I] = 60;
$Jprice[$I] = 80;
$Jtotal[$I] = 1;
$Jimage[$I] = 'kabe.jpg';

$I++;
$Jname[$I] = '≪환각≫';
$Jexp[$I] = '떠오르는 환각의 하늘을 상대에게 보여주어 환각상태에 빠지게 만드는 기적. 목속성';
$Jsecond[$I] = "<FONT COLOR=$ColorJupiter><B>환각의 하늘</B></FONT>이 떠오른다!!";
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'TargetAct';
$Jdetail[$I] = 'Illusion';
$Jattribute[$I] = 'Jupiter';
$Jmp[$I] = 60;
$Jprice[$I] = 100;
$Jtotal[$I] = 1;
$Jimage[$I] = 'genkaku.jpg';

$I++;
$Jname[$I] = '≪雷≫';
$Jexp[$I] = '뇌운을 불러 번개를 떨어트려 적전체를 공격하는 기적. 명중률:저 천속성';
$Jsecond[$I] = "뇌운이 발생하여 <FONT COLOR=$ColorUranus><B>번개</B></FONT>를 떨어트렸다!!";
$Jthird[$I] = "에게 <FONT COLOR=$ColorUranus><B>번개</B></FONT>가 떨어졌다!!";
$Jmiss[$I] = "에게는 <FONT COLOR=$ColorUranus><B>번개</B></FONT>가 떨어지지 않았다.";
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'AllAct';
$Jattribute[$I] = 'Uranus';
$Jmp[$I] = 70;
$Jpoint[$I] = 1100;
$Jprice[$I] = 120;
$Jtotal[$I] = 1;
$Jimage[$I] = 'kaminari.jpg';

$I++;
$Jname[$I] = '≪흡수≫';
$Jexp[$I] = '흡수의 빛이 비취면서 상대에게서 HP를 100만큼 흡수하는 기적. 천속성';
$Jsecond[$I] = "<FONT COLOR=$ColorUranus><B>흡수의 빛</B></FONT>이 비친다!!";
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'TargetAct';
$Jdetail[$I] = 'HPabsorb';
$Jattribute[$I] = 'Uranus';
$Jmp[$I] = 80;
$Jpoint[$I] = 100;
$Jprice[$I] = 70;
$Jtotal[$I] = 1;
$Jimage[$I] = 'kyushu.jpg';

$I++;
$Jname[$I] = '≪눈사태≫';
$Jexp[$I] = '눈사태가 일어나 적전체를 노도의 기세로 공격하는 기적. 명중률:고 수속성';
$Jsecond[$I] = "<FONT COLOR=$ColorMercury><B>눈사태</B></FONT>가 일어났다!!";
$Jthird[$I] = "는 <FONT COLOR=$ColorMercury><B>눈사태</B></FONT>에 말려들었다!!";
$Jmiss[$I] = "는 <FONT COLOR=$ColorMercury><B>눈사태</B></FONT>에서 도망쳤다.";
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'AllAct';
$Jattribute[$I] = 'Mercury';
$Jmp[$I] = 90;
$Jpoint[$I] = 3070;
$Jprice[$I] = 140;
$Jtotal[$I] = 1;
$Jimage[$I] = 'nadare.jpg';

$I++;
$Jname[$I] = '≪星≫';
$Jexp[$I] = '적전체에게 무수한 별이 쏟아지는 공격을 하는 기적. 명중률:중 천속성';
$Jsecond[$I] = "<FONT COLOR=$ColorUranus><B>별</B></FONT>이 쏟아진다!!";
$Jthird[$I] = "는 <FONT COLOR=$ColorUranus><B>별</B></FONT>에 직격했다!!";
$Jmiss[$I] = "는 <FONT COLOR=$ColorUranus><B>별</B></FONT>을 피했다.";
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'AllAct';
$Jattribute[$I] = 'Uranus';
$Jmp[$I] = 100;
$Jpoint[$I] = 2120;
$Jprice[$I] = 200;
$Jtotal[$I] = 1;
$Jimage[$I] = 'hoshi.jpg';

$I++;
$Jname[$I] = '≪闇≫';
$Jexp[$I] = '어둠이 상대를 덮치는 기적. 잘못하면 한방에 승천할 수도 있는 공포의 기적이다. 명속성';
$Jsecond[$I] = "<FONT COLOR=$ColorPluto><B>어둠</B></FONT>이 깔린다!!";
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'TargetAct';
$Jattribute[$I] = 'Pluto';
$Jmp[$I] = 100;
$Jpoint[$I] = 50;
$Jprice[$I] = 100;
$Jtotal[$I] = 1;
$Jimage[$I] = 'yami.jpg';

$I++;
$Jname[$I] = '≪오로라≫';
$Jexp[$I] = '성스러운 오로라가 신기를 감싸면서 파워업을 해 공격력이 2배가 되는 기적.';
$Jtype[$I] = 'Add';
$Jdetail[$I] = 'ATtimes';
$Jmp[$I] = 100;
$Jpoint[$I] = 2;
$Jprice[$I] = 100;
$Jtotal[$I] = 1;
$Jimage[$I] = 'aura.jpg';

$I++;
$Jname[$I] = '≪폭포≫';
$Jexp[$I] = '하늘 아득한 먼곳에서 폭포가 떨어지면서 상대에게 큰데미지를 입히는 기적. 수속성';
$Jsecond[$I] = "하늘 아득한 먼곳에서 <FONT COLOR=$ColorMercury><B>폭포</B></FONT>가 떨어진다!!";
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'TargetAct';
$Jattribute[$I] = 'Mercury';
$Jmp[$I] = 120;
$Jpoint[$I] = 250;
$Jprice[$I] = 200;
$Jtotal[$I] = 1;
$Jimage[$I] = 'taki.jpg';

$I++;
$Jname[$I] = '≪마그마≫';
$Jexp[$I] = '고온의 마그마를 뿌려서 적전체를 공격하는 기적. 명중률:고 화속성';
$Jsecond[$I] = "고온의 <FONT COLOR=$ColorMars><B>마그마</B></FONT>가 쏟아진다!!";
$Jthird[$I] = "는 <FONT COLOR=$ColorMars><B>마그마</B></FONT>를 뒤집어 썼다!!";
$Jmiss[$I] = "는 <FONT COLOR=$ColorMars><B>마그마</B></FONT>를 피했다.";
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'AllAct';
$Jattribute[$I] = 'Mars';
$Jmp[$I] = 130;
$Jpoint[$I] = 3150;
$Jprice[$I] = 200;
$Jtotal[$I] = 1;
$Jimage[$I] = 'magma.jpg';

$I++;
$Jname[$I] = '≪부활≫';
$Jexp[$I] = 'HP가0이 되면 기적이 일어나서 HP200으로 부활한다. MP전부를 소비하며 최소한 MP140이 필요';
$Jkind[$I] = 'Revive';
$Jmp[$I] = 140;
$Jpoint[$I] = 200;
$Jprice[$I] = 220;
$Jtotal[$I] = 1;
$Jimage[$I] = 'fukkatsu.jpg';

$I++;
$Jname[$I] = '≪천국풍≫';
$Jexp[$I] = '적에게 천국에서 부는 바람을 가져다 주는 기적. 天國病에 감염되거나 아니면 天國病의 발작이 일어난다.';
$Jsecond[$I] = "<B>천국에서 바람</B>이 분다.";
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'TargetAct';
$Jdetail[$I] = 'Heaven';
$Jmp[$I] = 150;
$Jprice[$I] = 150;
$Jtotal[$I] = 1;
$Jimage[$I] = 'tengokufu.jpg';

$I++;
$Jname[$I] = '≪빙하기≫';
$Jexp[$I] = '적전체에게 빙하기가 오는 기적. 얼어붙는 추위에 큰데미지를 입는다. 명중률:고 수속성';
$Jsecond[$I] = "<FONT COLOR=$ColorMercury><B>빙하기</B></FONT>가 온다!!";
$Jthird[$I] = "앞으로 <FONT COLOR=$ColorMercury><B>빙하기</B></FONT>가 왔다!!";
$Jmiss[$I] = "앞으로 <FONT COLOR=$ColorMercury><B>빙하기</B></FONT>는 오지않았다.";
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'AllAct';
$Jattribute[$I] = 'Mercury';
$Jmp[$I] = 300;
$Jpoint[$I] = 3300;
$Jprice[$I] = 60;
$Jtotal[$I] = 1;
$Jimage[$I] = 'hyougaki.jpg';

$I++;				#$I = 310;
$Jname[$I] = '≪해방≫';
$Jexp[$I] = '신기에 종속하는 신의 힘을 해방하여 수호에 붙어주는 기적. 신기의 가격만큼의 MP를 소비한다.';
$Jtype[$I] = 'OneMore';
$Jkind[$I] = 'Release';
$Jmp[$I] = 10;
$Jprice[$I] = 120;
$Jtotal[$I] = 1;
$Jimage[$I] = 'kaihou.jpg';

$I++;
$Jname[$I] = '케페우스의 물방울';
$Jexp[$I] = '뿌리면 몸의 깊은 곳에서부터 생명력이 넘쳐나는 신비의 물방울. HP50회복';
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'HPup';
$Jpoint[$I] = 50;
$Jprice[$I] = 50;
$Jtotal[$I] = 14;
$Jimage[$I] = 'cepheus_no_shizuku.jpg';

$I++;
$Jname[$I] = '카시오페아의 물방울';
$Jexp[$I] = '뿌리면 몸의 깊은 곳에서부터 생명력이 넘쳐나는 신비의 물방울. HP100회복';
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'HPup';
$Jpoint[$I] = 100;
$Jprice[$I] = 100;
$Jtotal[$I] = 9;
$Jimage[$I] = 'cassiopeia_no_shizuku.jpg';

$I++;
$Jname[$I] = '안드로메다의 물';
$Jexp[$I] = '전신에 뿌리면 몸의 깊은 곳에서부터 생명력이 넘쳐나는 신비의 물. HP150회복';
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'HPup';
$Jpoint[$I] = 150;
$Jprice[$I] = 150;
$Jtotal[$I] = 5;
$Jimage[$I] = 'andromeda_no_mizu.jpg';

$I++;
$Jname[$I] = '은하수';
$Jexp[$I] = '전신에 뿌리면 몸의 깊은 곳에서부터 생명력이 넘쳐나는 신비의 물. HP200회복';
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'HPup';
$Jpoint[$I] = 200;
$Jprice[$I] = 200;
$Jtotal[$I] = 2;
$Jimage[$I] = 'amanogawa_no_oishii_mizu.jpg';

$I++;
$Jname[$I] = '케페우스의 꽃';
$Jexp[$I] = '향을 맡으면 마음의 깊은 곳에서 기적의 힘이 넘쳐오는 신비의 꽃. MP50회복';
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'MPup';
$Jpoint[$I] = 50;
$Jprice[$I] = 50;
$Jtotal[$I] = 8;
$Jimage[$I] = 'cepheus_no_hana.jpg';

$I++;
$Jname[$I] = '카시오페아의 꽃';
$Jexp[$I] = '향을 맡으면 마음의 깊은 곳에서 기적의 힘이 넘쳐오는 신비의 꽃. MP100회복';
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'MPup';
$Jpoint[$I] = 100;
$Jprice[$I] = 100;
$Jtotal[$I] = 5;
$Jimage[$I] = 'cassiopeia_no_hana.jpg';

$I++;
$Jname[$I] = '안드로메다의 향목';
$Jexp[$I] = '기적의 힘이 넘쳐나는 감미로운 방향을 품기는 신비의 향목. MP150회복';
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'MPup';
$Jpoint[$I] = 150;
$Jprice[$I] = 150;
$Jtotal[$I] = 3;
$Jimage[$I] = 'andromeda_no_kouboku.jpg';

$I++;
$Jname[$I] = '천국초';
$Jexp[$I] = '기적의 힘이 넘쳐나는 요염한 향을 내는 신비의 초. 향을 맡으면 天國病에 감염된다. MP200회복';
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'MPup';
$Jdetail[$I] = 'SelfHeaven';
$Jpoint[$I] = 200;
$Jprice[$I] = 200;
$Jtotal[$I] = 1;
$Jimage[$I] = 'tengokusou.jpg';

$I++;
$Jname[$I] = '케페우스의 소라';
$Jexp[$I] = '소라에서 흐미하게 들리는 파도의 소리를 들으면 弱風病, 强風病, 안개, 섬광의 상태이상이 치료된다.';
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'ToneCure';
$Jprice[$I] = 50;
$Jtotal[$I] = 12;
$Jimage[$I] = 'cepheus_no_kaigara.jpg';

$I++;
$Jname[$I] = '카시오페아의 소라';
$Jexp[$I] = '소라에서 흐미하게 들리는 파도의 소리를 들으면 모든 상태이상이 치료된다.';
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'SongCure';
$Jprice[$I] = 100;
$Jtotal[$I] = 5;
$Jimage[$I] = 'cassiopeia_no_kaigara.jpg';

$I++;
$Jname[$I] = '금성의 주전자';
$Jexp[$I] = '돈을 넣으면 회복의 물이 흘러나는 주전자. 집어넣은 돈의 2배만큼 HP회복';
$Jsecond[$I] = "<B>주전자</B>에서 회복의 물이 흘러내린다.";
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'Jug';
$Jprice[$I] = 200;
$Jtotal[$I] = 4;
$Jimage[$I] = 'kinsei_no_mizusashi.jpg';

$I++;
$Jname[$I] = '두근두근눈물';
$Jexp[$I] = '뿌리면 HP100회복하거나 100데미지를 입는 눈물. 확률은 반반. 마음속은 두근두근';
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'HPupDown';
$Jpoint[$I] = 100;
$Jfree[$I] = 100;
$Jprice[$I] = 10;
$Jtotal[$I] = 3;
$Jimage[$I] = 'dokidoki_namida.jpg';

$I++;
$Jname[$I] = '즐거운장갑';
$Jexp[$I] = '상대에게서 돈100G을 달라는 즐거운장갑. 그러나 돈 뺏긴쪽은 안즐겁다.';
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'TargetAct';
$Jdetail[$I] = 'GPabsorb';
$Jpoint[$I] = 100;
$Jprice[$I] = 20;
$Jtotal[$I] = 3;
$Jimage[$I] = 'tanoshii_tebukuro.jpg';

$I++;
$Jname[$I] = '밤하늘의 빗자루';
$Jexp[$I] = '상대가 가지고있는 신기중 3개를 쓸어서 날려버린다. 밤하늘을 달리는 빗자루.';
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'TargetAct';
$Jdetail[$I] = 'Broom';
$Jpoint[$I] = 3;
$Jprice[$I] = 50;
$Jtotal[$I] = 2;
$Jimage[$I] = 'yozora_no_houki.jpg';

$I++;
$Jname[$I] = '여신의 비누';
$Jexp[$I] = '비누에 다리가 미끄러져 그 순간에 기적을 2개 잃어버린다.';
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'TargetAct';
$Jdetail[$I] = 'Soap';
$Jpoint[$I] = 2;
$Jprice[$I] = 50;
$Jtotal[$I] = 2;
$Jimage[$I] = 'megami_no_sekken.jpg';

$I++;
$Jname[$I] = '힘의 모래';
$Jexp[$I] = '그릇에서 흘러나와 무기에 달라붙어 공격력을 AT100만큼 높이는 마법의 모래';
$Jtype[$I] = 'Adds';
$Jdetail[$I] = 'ATup';
$Jfree[$I] = 100;
$Jprice[$I] = 50;
$Jtotal[$I] = 4;
$Jimage[$I] = 'chikara_no_suna.jpg';

$I++;
$Jname[$I] = '미라클인형';
$Jexp[$I] = '기적을 일으키는 인형. MP소비없이 한번만 기적을 일으킬 수 있다.';
$Jkind[$I] = 'Mirac';
$Jdetail[$I] = 'UseMiracle';
$Jprice[$I] = 80;
$Jtotal[$I] = 3;
$Jimage[$I] = 'miracle_nuigurumi.jpg';

$I++;
$Jname[$I] = '태양의 부적';
$Jexp[$I] = '소유자가 HP0이 되면 따듯하게 빛나면서 HP100까지 회복하고 부활하는 아주 고마운 부적.';
$Jfirst[$I] = "이 따듯하게 빛나는 것을 봤다.";
$Jkind[$I] = 'Revive';
$Jpoint[$I] = 100;
$Jprice[$I] = 300;
$Jtotal[$I] = 4;
$Jimage[$I] = 'taiyou_no_omamori.jpg';

$I++;
$Jname[$I] = '수호봉인항아리';
$Jexp[$I] = '봉인을 풀면 수호신이 나타나 수호해준다. 그러나 악마가 들어있는 경우도 있다.';
$Jfirst[$I] = "의 봉인을 풀었다.";
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'Pot';
$Jprice[$I] = 150;
$Jtotal[$I] = 4;
$Jimage[$I] = 'shugofuin_no_tsubo.jpg';

$I++;
$Jname[$I] = '운명의 끈';
$Jexp[$I] = '하늘에서부터 이어진 운명의 끈. 잡아당기면 무슨 엄청난 일이 일어나는것 같다.';
$Jfirst[$I] = "을 당겼다.";
$Jtype[$I] = 'Solo';
$Jkind[$I] = 'Rope';
$Jprice[$I] = 30;
$Jtotal[$I] = 1;
$Jimage[$I] = 'ummei_no_himo.jpg';

$I++;
$Jname[$I] = '위험한절구';
$Jexp[$I] = '들고 있으면 위험한방아의 공격이 반드시 날아오는 위험한절구.';
$Jkind[$I] = 'Usu';
$Jprice[$I] = 0;
$Jtotal[$I] = 1;
$Jimage[$I] = 'abunai_usu.jpg';

$I++;
$Jname[$I] = '地球神의 像';
$Jexp[$I] = '호기심의 신, 지구신의 신상. 신기를 바치면 수년후 신기의 가격과 동등한 돈으로 바꿔준다.';
$Jtype[$I] = 'OneMore';
$Jkind[$I] = 'AllS';
$Jdetail[$I] = 'Earth';
$Jprice[$I] = 150;
$Jtotal[$I] = 4;
$Jimage[$I] = 'chikyushin_no_zou.jpg';

$I++;
$Jname[$I] = '武神의 像';
$Jexp[$I] = '무기의 신, 무신의 신상. 무기를 공양하면 수년후 신기의 가격의 2배의 돈으로 바꿔준다.';
$Jtype[$I] = 'OneMore';
$Jkind[$I] = 'WeaponS';
$Jprice[$I] = 100;
$Jtotal[$I] = 3;
$Jimage[$I] = 'bushin_no_zou.jpg';

$I++;
$Jname[$I] = '衛神의 像';
$Jexp[$I] = '방어구의 신, 위신의 신상. 방어구를 공양하면 수년후 신기의 가격의 2배의 돈으로 바꿔준다.';
$Jtype[$I] = 'OneMore';
$Jkind[$I] = 'ProtectorS';
$Jprice[$I] = 100;
$Jtotal[$I] = 3;
$Jimage[$I] = 'eishin_no_zou.jpg';

$I++;
$Jname[$I] = '雜神의 像';
$Jexp[$I] = '잡화의 신, 잡신의 신상. 무기, 방어구이외의 신기를 공양하면 수년후 신기의 가격의 2배의 돈으로 바꿔준다.';
$Jtype[$I] = 'OneMore';
$Jkind[$I] = 'SundryS';
$Jprice[$I] = 100;
$Jtotal[$I] = 3;
$Jimage[$I] = 'zasshin_no_zou.jpg';

$I++;
$Jname[$I] = '하급악마';
$Jexp[$I] = '신기들에 섞여서 숨어든 하급악마. 예언자에게 약한데미지를 입힌다.';
$Jkind[$I] = 'Creature';
$Jdetail[$I] = 'Devil';
$Jpoint[$I] = 100;
$Jtotal[$I] = 1;
$Jimage[$I] = 'koakuma.jpg';

$I++;
$Jname[$I] = '중급악마';
$Jexp[$I] = '신기들에 섞여서 숨어든 중급악마. 예언자에게 강한데미지를 입힌다.';
$Jkind[$I] = 'Creature';
$Jdetail[$I] = 'Devil';
$Jpoint[$I] = 200;
$Jtotal[$I] = 1;
$Jimage[$I] = 'chuakuma.jpg';

$I++;
$Jname[$I] = '상급악마';
$Jexp[$I] = '신기들에 섞여서 숨어든 상급악마. 예언자에게 아주 강한데미지를 입힌다.';
$Jkind[$I] = 'Creature';
$Jdetail[$I] = 'Devil';
$Jpoint[$I] = 300;
$Jtotal[$I] = 1;
$Jimage[$I] = 'daiakuma.jpg';

$I++;
$Jname[$I] = '장난꾸러기맨';
$Jexp[$I] = '신기들에 섞여서 숨어든 사람외의 존재. 예언자에게 장난치는걸 좋아한다.';
$Jkind[$I] = 'Creature';
$Jdetail[$I] = 'Itazuraman';
$Jtotal[$I] = 3;
$Jimage[$I] = 'itazuraman.jpg';

$I++;	#$I = 340;
$Jname[$I] = '가루의 요정';
$Jexp[$I] = '신기속에 섞여서 숨어든 요정. 예언자에게 신비한 가루를 뿌리는걸 좋아한다.';
$Jkind[$I] = 'Creature';
$Jdetail[$I] = 'PowderFairy';
$Jtotal[$I] = 3;
$Jimage[$I] = 'kona_no_yousei.jpg';


#―――――――――――――――――――――――――――――
#그림파일의 패스에 관한 처리
#―――――――――――――――――――――――――――――

foreach (0..$I) {
	if ($Jmp[$_] > 0) {
		$Jimage[$_] = "$JimageMiracle"."$Jimage[$_]";
	}
	elsif ($Jkind[$_] eq 'Weapon') {
		$Jimage[$_] = "$JimageWeapon"."$Jimage[$_]";
	}
	elsif ($Jkind[$_] eq 'Shield' || $Jkind[$_] eq 'Armor' || $Jkind[$_] eq 'Helm' || $Jkind[$_] eq 'Gauntlet' || $Jkind[$_] eq 'Boots' || $Jkind[$_] eq 'Ring' || $Jkind[$_] eq 'OtherP' || $Jkind[$_] eq 'SoloP') {
		$Jimage[$_] = "$JimageProtector"."$Jimage[$_]";
	}
	else {
		$Jimage[$_] = "$JimageItem"."$Jimage[$_]";
	}
}

1;

