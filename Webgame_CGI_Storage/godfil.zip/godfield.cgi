#!/usr/bin/perl

BEGIN {
	use FindBin;
	chdir $FindBin::Bin if $FindBin::Bin;
}

binmode(STDOUT, ":raw");


#------------------------------------
#갓필드는 프리웨어 입니다.
#이 스크립트를 사용할시 모든 책임은 자기자신에게 있습니다.
#
#	저작:グウジ
#	번역:MAI
#	http://red.sakura.ne.jp/~guji/
#	guji@red.sakura.ne.jp
#
#------------------------------------


#------------------------------------
#이하 필요설정
#------------------------------------
#관리자 이름
$AdminName = '관리자';

#관리자 이메일 주소
$AdminEmail = 'xxxx@xxx.xxx';

#관리자패스8자까지
#이 패스워드는 모든 패스워드를 통과합니다.
$AdminPass = '1064';

#돌아갈 URL
$HomePage = '/';

#규칙 설명파일 패스
$RuleFile = './gf_rule.html';

#게시판 주소
$BBSfile = '../gf_bbs/gf_bbs.cgi'; #게시판 소스는 없음

#이 파일의 위치
$ThisFile = './godfield.cgi';

#신기정보파일의 위치
$ListFile = './gf_list.cgi';

#메인 로그파일의 위치
$LogFile = './godfield.log';

#승패기록 로그파일의 위치
$JudgmentFile = './gf_judgment.log';

#락 파일의 위치
$LockFile = './lockfile';

#이미지 파일의 폴더
$JimageFolder = './gf_image/';

#메인 타이틀 그림파일 
$ImgTitle = 'gf_title.jpg';

#배경화면의 파일명
$BackGround = 'gf_bg.jpg';

#배경색
$BGcolor = '#ffffff';

#상태이상 아이콘들
$ImgCondition{'Disease1'} = 'weakwind.jpg';			#약풍병
$ImgCondition{'Disease2'} = 'weakwind_fit.jpg';		#약풍병(발작)
$ImgCondition{'Disease3'} = 'strongwind.jpg';		#강풍병
$ImgCondition{'Disease4'} = 'strongwind_fit.jpg';	#강풍병(발작)
$ImgCondition{'Disease5'} = 'hell.jpg';				#지옥병
$ImgCondition{'Disease6'} = 'hell_fit.jpg';			#지옥병(발작)
$ImgCondition{'Disease7'} = 'heaven.jpg';			#천국병
$ImgCondition{'Fog'} = 'fog.jpg';					#안개
$ImgCondition{'Flash'} = 'flash.jpg';				#섬광
$ImgCondition{'Illusion'} = 'illusion.jpg';			#환각
$ImgCondition{'DarkCloud'} = 'darkcloud.jpg';		#암흑

#상의 아이콘그림
$ImgStatue{'Blank'} = 'statue_blank.jpg';			#상없음
$ImgStatue{'AllS'} = 'chikyushin_no_zou.jpg';		#지구신의 상
$ImgStatue{'WeaponS'} = 'bushin_no_zou.jpg';		#무신의 상
$ImgStatue{'ProtectorS'} = 'eishin_no_zou.jpg';		#위신의 상
$ImgStatue{'SundryS'} = 'zasshin_no_zou.jpg';		#잡신의 상

#수호신의 아이콘 그림
$ImgGuardian{'Blank'} = 'guardian_blank.jpg';		#수호신없음
$ImgGuardian{'Mercury'} = 'suiseishin.jpg';			#수성신
$ImgGuardian{'Venus'} = 'kinseishin.jpg';			#금성신
$ImgGuardian{'Earth'} = 'chikyushin.jpg';			#지구신
$ImgGuardian{'Mars'} = 'kaseishin.jpg';				#화성신
$ImgGuardian{'Jupiter'} = 'mokuseishin.jpg';		#목성신
$ImgGuardian{'Saturn'} = 'doseishin.jpg';			#토성신
$ImgGuardian{'Uranus'} = 'tennoushin.jpg';			#천왕신
$ImgGuardian{'Neptune'} = 'kaioushin.jpg';			#해왕신
$ImgGuardian{'Pluto'} = 'meioushin.jpg';			#명왕신
$ImgGuardian{'Mirac'} = 'mirac.jpg';				#미락크
$ImgGuardian{'DevilS'} = 'koakuma.jpg';				#소악마
$ImgGuardian{'DevilM'} = 'chuakuma.jpg';			#중악마
$ImgGuardian{'DevilL'} = 'daiakuma.jpg';			#대악마

#------------------------------------
#이상 필수항목 , 이하 자유선택상황
#------------------------------------
#최대참가인원 (최대30)
$PlayerMax = 20;

#뉴스의 화면표시 수
$NewsShow = 20;

#뉴스의 화면보관수
$NewsMax = 300;

#신계사의 한페이지 표시수
$AllNewsOnePage = 100;

#초기HP,MP,돈
$StartHP = 500;
$StartMP = 100;
$StartGP = 300;

#시작시 소유 신기수 최대 16
$StartJingi = 8;

#신기를 샀을 경우 상대에게 돈이 들어갈지의 여부(off=0,on=1)
$CanBuyGold = 0;

#한번 행동후 다음 행동까지의 시간(단위:시간)
#생갓필드는 아무거나
$NextTime = 20;

#하계할때까지의 시간(이 시간까지 아무것도 안하면 하계=삭제 단위:시간)
#생갓필드는 아무거나
$RemoveTime = 100;

#예배물이 돈으로 변하는 시간(단위:시간)
#생갓필드는 아무거나
$StatueTime = 100;

#생갓필드의 여부(off=0,on=1)
$NamaMode = 0;

#생갓필드의 시간설정
#살아남은 인원수별 기다릴 시간([ ]내의 남은 사람수. 단위:초)
$NamaNextTime[2] = 30;
$NamaNextTime[3] = 45;
$NamaNextTime[4] = 60;
$NamaNextTime[5] = 75;
$NamaNextTime[6] = 90;
$NamaNextTime[7] = 90;
$NamaNextTime[8] = 90;
$NamaNextTime[9] = 120;
$NamaNextTime[10] = 120;
$NamaNextTime[11] = 150;
$NamaNextTime[12] = 150;
$NamaNextTime[13] = 180;
$NamaNextTime[14] = 180;
$NamaNextTime[15] = 180;
$NamaNextTime[16] = 300;
$NamaNextTime[17] = 300;
$NamaNextTime[18] = 300;
$NamaNextTime[19] = 300;
$NamaNextTime[20] = 300;
$NamaNextTime[21] = 300;
$NamaNextTime[22] = 300;
$NamaNextTime[23] = 300;
$NamaNextTime[24] = 300;
$NamaNextTime[25] = 300;
$NamaNextTime[26] = 300;
$NamaNextTime[27] = 300;
$NamaNextTime[28] = 300;
$NamaNextTime[29] = 300;
$NamaNextTime[30] = 300;

$NamaRemoveTime = 720;	#삭제시간
$NamaStatueTime = 360;	#예배물 돈되는 시간

#------------------------------------
#이상 설정 종료
#------------------------------------
#문자색
$Text = '#4F4F4F';				#基本文字色
$Link = '#1177BB';				#リンク（未訪問）
$Vlink = '#1177BB';				#リンク（?訪問）
$Alink = '#88AAFF';				#リンク（訪問中）
$ColorButton = '#FFEEBB';		#ボタンの背景色
$ColorButtonBorder = '#CCBB88';	#ボタンの?線の色
$ColorForm = '#EEFFBB';			#フォ?ムの背景色
$ColorFormBorder = '#DDEEAA';	#フォ?ムの?線の色
$ColorCheckBox = '#DDEEAA';		#チェックボックスの?線の色
$ColorHR = '#CCEEDD';			#HR COLOR
$ColorTable = '#DEFFBF';		#TABLE BGCOLOR（全?表）
$ColorTR = '#6699EE';			#TR BGCOLOR 項目（全?表）
$ColorTRfont = '#FFFFFF';		#TR FONT COLOR（全?表）
$ColorTDup = '#DDFFDD';			#(TR) BGCOLOR 上段（全?表）
$ColorTDdown = '#CDFFDC';		#TD BGCOLOR 下段（全?表）
$ColorShTableUp = '#FFAAAA';	#TABLE BGCOLOR 上部（神殿）
$ColorShTH = '#FFBBBB';			#TH BGCOLOR（神殿）
$ColorShTableDown = '#BBEEBB';	#TABLE BGCOLOR 下部（神殿）
$ColorShTDleft = '#DFFFCC';		#TD BGCOLOR 左部分（神殿）
$ColorShTDup = '#DEFFBF';		#TD BGCOLOR 右上部分（神殿）
$ColorShTDdown = '#E0FFE0';		#TD BGCOLOR 右下部分（神殿）
$ColorShTableExp = '#6F6F6F';	#TABLE BGCOLOR 神器の?明（神殿）
$ColorShTDexp = '#EEFFEE';		#TD BGCOLOR 神器の?明（神殿）
$ColorAtTable = '#FFCCCC';		#TABLE BGCOLOR（-攻?-）
$ColorAtTH = '#FFEEEE';			#TH BGCOLOR（-攻?-）
$ColorAtTHfont = '#4F4F4F';		#TH FONT COLOR（-攻?-）
$ColorAtTD = '#FFFEFF';			#TD BGCOLOR（-攻?-）
$ColorDfTable = '#DDEEBB';		#TABLE BGCOLOR（-防御-）
$ColorDfTH = '#FFFFDD';			#TH BGCOLOR（-防御-）
$ColorDfTHfont = '#4F4F4F';		#TH FONT COLOR（-防御-）
$ColorDfTD = '#FFFEEE';			#TD BGCOLOR（-防御-）
$ColorDfTHother = '#FFFFDD';	#TH BGCOLOR その他（-防御-）
$ColorDfTDother = '#FFFFFC';	#TD BGCOLOR その他（-防御-）
$ColorViTable = '#DDEEF3';		#TABLE BGCOLOR（訪問）
$ColorViTD = '#FAFFFF';			#TD BGCOLOR（訪問）
$ColorProphet = '#008F6F';		#預言者
$ColorLost = '#AAAAAA';			#預言者（昇天）
$ColorEraA = '#CC6644';			#神界年（パタ?ンA）
$ColorEraB = '#DD7799';			#神界年（パタ?ンB）
$ColorAttack = '#FF0099';		#攻?
$ColorDefense = '#007700';		#防御
$ColorWait = '#888800';			#待機
$ColorDamage = '#DD0000';		#ダメ?ジ
$ColorAscension = '#FF0000';	#昇天
$ColorVenus = '#008800';		#金星神
$ColorEarth = '#EEAAAA';		#地球神
$ColorNeptune = '#00AAEE';		#海王神
$ColorMars = '#FF6666';			#火?性
$ColorMercury = '#6666FF';		#水?性
$ColorJupiter = '#FF9900';		#木?性
$ColorSaturn = '#6688AA';		#土?性
$ColorUranus = '#C5C500';		#天?性
$ColorPluto = '#AA55CC';		#冥?性
$ColorNormal = '#4F4F4F';		#無?性

#상태이상의 명칭
$ConditionName{'Disease1'} = '弱風病';
$ConditionName{'Disease2'} = '弱風病(발작)';
$ConditionName{'Disease3'} = '强風病';
$ConditionName{'Disease4'} = '弱風病(발작)';
$ConditionName{'Disease5'} = '地獄病';
$ConditionName{'Disease6'} = '地獄病(발작)';
$ConditionName{'Disease7'} = '天國病';
$ConditionName{'Fog'} = '안개';
$ConditionName{'Flash'} = '섬광';
$ConditionName{'Illusion'} = '환각';
$ConditionName{'DarkCloud'} = '암운';

#수호신의 명칭(한글9자이내)
$GuardianName{'Mercury'} = '水星神';
$GuardianName{'Venus'} = '金星神';
$GuardianName{'Earth'} = '地球神';
$GuardianName{'Mars'} = '火星神';
$GuardianName{'Jupiter'} = '木神';
$GuardianName{'Saturn'} = '土星神';
$GuardianName{'Uranus'} = '天王神';
$GuardianName{'Neptune'} = '海王神';
$GuardianName{'Pluto'} = '冥王神';
$GuardianName{'Mirac'} = '미락크';
$GuardianName{'DevilS'} = '하급악마';
$GuardianName{'DevilM'} = '중급악마';
$GuardianName{'DevilL'} = '상급악마';

#수호신의 설명 (한글로 35~40자이내)
$GuardianExp{'Mercury'} = '水을 다루는 神. 물,얼음등을 사용한 다양한 공격을 한다.또한, 안개를 내뿜기도 한다.';
$GuardianExp{'Venus'} = '金을 다루는 神. 금을 퍼트리거나 富의 이동을 하기도 한다.익살스런 수호신?';
$GuardianExp{'Earth'} = '호기심의 神. 모든 물건에 대해 관심이 있어서 神器를 모으고 있다.';
$GuardianExp{'Mars'} = '火를 다루는 神. 입을 열면 불이 나온다. 오로지 화염으로 광범위공격을 하는게 취미';
$GuardianExp{'Jupiter'} = '木을 다루는 神. 공격력은 약하지만 사람의 마음을 흔들며 환각을 보여주기도 한다.';
$GuardianExp{'Saturn'} = '土를 다루는 神. 파괴력있는 공격이 주특기. 광범위가 아닌 집중공격만 한다.';
$GuardianExp{'Uranus'} = '天王의 神. 光이며 雷이며 섬광이며 밸런스잡힌 공격을 한다.';
$GuardianExp{'Neptune'} = '海王의 神. 어머니의 바다의 힘으로 회복과 치료를 한다. 얼굴은 무섭지만 속은 착하다.';
$GuardianExp{'Pluto'} = '冥王의 神. 조금이라도 움직이면 생명의 불을 꺼버릴지도 몰라 평소에는 안움직인다.';
$GuardianExp{'Mirac'} = '神界에서 어딘가에서 살고 있는 기적의 생물. 자기는 놀고 있지만 남들은 피해만 입는다.';
$GuardianExp{'DevilS'} = '神器속에 섞여 숨어있는 하급악마. 예언자에게 약한 데미지를 입힌다.';
$GuardianExp{'DevilM'} = '神器속에 섞여 숨어있는 중급악마. 예언자에게 강한 데미지를 입힌다.';
$GuardianExp{'DevilL'} = '神器속에 섞여 숨어있는 상급악마. 예언자에게 아주 강한 데미지를 입힌다.';

#수호신의 초기HP
$GuardianHP{'Mercury'} = 200;
$GuardianHP{'Venus'} = 200;
$GuardianHP{'Earth'} = 300;
$GuardianHP{'Mars'} = 200;
$GuardianHP{'Jupiter'} = 200;
$GuardianHP{'Saturn'} = 200;
$GuardianHP{'Uranus'} = 200;
$GuardianHP{'Neptune'} = 200;
$GuardianHP{'Pluto'} = 200;
$GuardianHP{'Mirac'} = 200;
$GuardianHP{'DevilS'} = 100;	#HP가 아닌 예언자에게 입힐 데미지
$GuardianHP{'DevilM'} = 200;	#HP가 아닌 예언자에게 입힐 데미지
$GuardianHP{'DevilL'} = 300;	#HP가 아닌 예언자에게 입힐 데미지

#스페셜 모드 (복수 선택 가능)
$AllDiseaseMode = 0;		#전원 병걸린 상태(off=0,on=1?7)
$AllFogMode = 0;			#전원 안개모드(off=0,on=1)
$AllFlashMode = 0;			#전원 섬광모드(off=0,on=1)
$AllIllusionMode = 0;		#전원 환각모드(off=0,on=1)
$AllDarkCloudMode = 0;		#전원 암흑모드(off=0,on=1)

#관리용의 키워드
$AdminWord = '관리용';

#예약어 이름으로 사용 할 수 없다.
@ReservedName = (
	'갓필드','태양신','예언자','예언자들','???','먼곳에서 누군가','안개저편에서 누군가','안개저편에서'
);

#그림이 있는 폴더
$JimageWeapon = "$JimageFolder".'weapon/';			#무기
$JimageProtector = "$JimageFolder".'protector/';	#방어구
$JimageMiracle = "$JimageFolder".'miracle/';		#기적
$JimageItem = "$JimageFolder".'item/';				#아이템
$JimageIcon = "$JimageFolder".'icon/';				#아이콘
$JimageOther = "$JimageFolder".'other/';			#그외

#그림 폴더 패스 처리
$ImgTitle = "$JimageOther"."$ImgTitle";
if ($BackGround) {$BackGround = "$JimageOther"."$BackGround";}
while ($Key = each(%ImgCondition)) {
	$ImgCondition{"$Key"} = "$JimageIcon"."$ImgCondition{\"$Key\"}";
}
while ($Key = each(%ImgStatue)) {
	$ImgStatue{"$Key"} = "$JimageIcon"."$ImgStatue{\"$Key\"}";
}
while ($Key = each(%ImgGuardian)) {
	if ($Key eq 'DevilS' || $Key eq 'DevilM' || $Key eq 'DevilL') {
		$ImgGuardian{"$Key"} = "$JimageItem"."$ImgGuardian{\"$Key\"}";
	}
	else {
		$ImgGuardian{"$Key"} = "$JimageIcon"."$ImgGuardian{\"$Key\"}";
	}
}

#BODY태그
if ($BackGround) {
	$Body = "<BODY BACKGROUND=\"$BackGround\" BGCOLOR=\"$BGcolor\" TEXT=\"$Text\" LINK=\"$Link\" VLINK=\"$Vlink\" ALINK=\"$Alink\">";
	$BodyShrine = "<BODY BACKGROUND=\"$BackGround\" BGCOLOR=\"$BGcolor\" TEXT=\"$Text\" LINK=\"$Link\" VLINK=\"$Vlink\" ALINK=\"$Alink\" onLoad=\"ResetButton(); Reset('All')\">";
}
else {
	$Body = "<BODY BGCOLOR=\"$BGcolor\" TEXT=\"$Text\" LINK=\"$Link\" VLINK=\"$Vlink\" ALINK=\"$Alink\">";
	$BodyShrine = "<BODY BGCOLOR=\"$BGcolor\" TEXT=\"$Text\" LINK=\"$Link\" VLINK=\"$Vlink\" ALINK=\"$Alink\" onLoad=\"ResetButton(); Reset('All')\">";
}

#스타일 시트
$Style = <<END_OF_STYLE;
<STYLE TYPE="text/css">
<!--
A.normal {text-decoration: none;}
A.link {text-decoration: none; font-weight: bold;}
A.link:hover {color: $Alink; text-decoration: underline;}
INPUT.button {color: $Text; background-color: $ColorButton; border-color: $ColorButtonBorder;}
INPUT.form {color: $Text; background-color: $ColorForm; border-color: $ColorFormBorder; border-style: ridge;}
INPUT.checkbox {border-color: $ColorCheckBox; border-style: ridge; border-width: 3;}
SELECT {color: $Text; background-color: $ColorForm;}
-->
</STYLE>
END_OF_STYLE

#META태그
$Meta = '<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">'."\n".'<META charset="UTF-8">'."\n".'<META HTTP-EQUIV="Content-Language" CONTENT="ko">';

#로그/락 파일 자동 보정
foreach $InitFile ($LogFile, $JudgmentFile) {
	if (!-e $InitFile) {
		open(INITFILE, ">>$InitFile") || &Message('에러', "초기 파일을 생성할 수 없습니다.<BR>$InitFile<BR>$!");
		close(INITFILE);
		chmod 0666, $InitFile;
	}
}
if (-d $LockFile) {
	rmdir($LockFile) || &Message('에러', "락 파일 경로가 디렉터리입니다.<BR>$LockFile<BR>디렉터리를 삭제한 뒤 파일로 생성해야 합니다.<BR>$!");
}

#락 개시
open(LOCK, "+>>$LockFile") || &Message('에러', "락 파일을 열거나 생성할 수 없습니다.<BR>$LockFile<BR>$!");
chmod 0666, $LockFile;
flock(LOCK,2) || &Message('에러', "락 파일 잠금에 실패했습니다.<BR>$LockFile<BR>$!");

#URL디코딩
&Decode;

#입력불가처리
&InputCheck;

#신기 정보파일 참고
require($ListFile);

#난수의 씨 셋팅
srand;

#로그파일 읽기
&ReadLog;

#리얼 타임모드 일때
if ($NamaMode) {
	$I = 0;
	foreach (1..$PlayerMax) {
		if ($HP[$_] > 0) {
			$I++;
		}
	}
	
	#대기시간
	$NextTime = $NamaNextTime[$I];
	
	#삭제시간
	$RemoveTime = $NamaRemoveTime;
	
	#공물환금시간
	$StatueTime = $NamaStatueTime;
}
else {
	#(단위:시간)을 (단위:초)로 바꾼다.
	$NextTime *= 3600;
	$RemoveTime *= 3600;
	$StatueTime *= 3600;
}

#각종처리
$X = $in{'Number'};	#괷괽괿렳뛱롌
if ($StopTime && $X) {&Error;}
if ($GFyear >= 2) {
	&WinnerCheck;		#긒??뢎뿹?긃긞긏
	if ($X) {
		&GetIP;			#괿굊귺긤깒긚롦벦
		&MyData($X);		#괷괽괿렳뛱롌궻긢??
		&InputModify;		#볺쀍뢇맫
		$Jcount = 25;		#?밶긦깄?긚궻궫귕궻긇긂깛?
	}
}

#모드 판별
if ($in{'Mode'} eq 'Shrine') {
	&PassCheck;
	&HPcheck;
	&CookieOut;
	&Shrine;
}
elsif ($in{'Mode'} eq 'Defense') {
	&PassCheck;
	&HPcheck;
	&GetPresent;
	&DFcheck;
	&EatPresent;
	&Shrine;
}
elsif ($in{'Mode'} eq 'Attack') {
	&PassCheck;
	&HPcheck;
	&SendPresent;
	&Shrine;
}
elsif ($in{'Mode'} eq 'AllNews') {
	&AllNews;
}
elsif ($in{'Mode'} eq 'Visit') {
	&Visit;
}
elsif ($in{'Mode'} eq 'VisitBuy') {
	&PassCheck;
	&HPcheck;
	&VisitBuy;
	&Shrine;
}
elsif ($in{'Mode'} eq 'Judgment') {
	&ReadJudgment;
	&Judgment;
}
elsif ($in{'Mode'} eq 'Entry') {
	&Entry;
}
elsif ($in{'Mode'} eq 'Edit') {
	&Edit;
}
elsif ($in{'Mode'} eq 'CommentChange') {
	&PassCheck;
	&CookieOut;
	&CommentChange;
	&WriteLog;
	&Menu;
}
elsif ($in{'Mode'} eq 'AdminEdit') {
	&AdminEdit;
}
elsif ($in{'Mode'} eq 'GameStart') {
	&GameStart;
}
else {
	&Menu;
}

#-------------
#메뉴 화면
#-------------

sub Menu {
	#JavaScript
	&JSmenu;
	
	#게임 시작전과 후의 판별
	if (!$GFyear || $GFyear == 1) {
		if (!$GFyear) {
			$GFyear = 1;
			&WriteLog;
		}
		&EntryForm;
		&GFnews;
		$GoButton = "";
		$NameCform = '  새로운이름'."\n".'<INPUT TYPE="text" NAME="Name" MAXLENGTH=20 CLASS="form">';
	}
	else {
		$JSentry = "";
		$EntryForm = "";
		&GFnews;
		$GoButton = '<INPUT TYPE="button" VALUE="     신전으로     " onClick="PassCheck(this.form, \'Shrine\')" CLASS="button">';
		$NameCform = "";
	}
	
	#일시정지
	if ($StopTime) {
		$EntryForm = '<B>神界의 시간은 멈췄습니다.</B><BR>';
		$GoButton = "";
	}
	
	#비겼을 경우
	if ($DrawFlag) {
		$GoButton = "";
	}
	
	#쿠키 습득
	&CookieIn;
	
	#시간경과로 자동패퇴
	if ($GFyear >= 2 && !$Winner && !$DrawFlag && !$StopTime) {
		#참가자 확인
		&PlayerCheck;
		
		@Player = sort by_LastAccess (@Player);
		foreach $Remove (@Player) {
			$RemoveFlag = 0;
			if ($Name[$Remove] && time - $LastAccess[$Remove] >= $RemoveTime && $HP[$Remove] > 0) {
				#선물 전부 처리
				$RemoveFlag = 1;
				$X = $Remove;
				&MyData($X);
				while ($MyPresent[1]) {
					&GetPresent;
					if ($Pcheck[1] eq 'Give') {
						@MyPresent = split(/==/, $Present[$X]);
						splice(@MyPresent, 1, 1);
						$Present[$X] = join("==", @MyPresent);
						next;
					}
					&DFcheck;
					&EatPresent;
				}
				
				if ($HP[$X] > 0) {
					$Jingi[$X] = join(",", @MyJ);
					$Statue[$X] = join(",", @MyStatue);
					$Present[$X] = join(",", @MyPresent);
					&MyClean($X);
					&WriteJudgment("$GFyear:$X:$X,Remove");
					&NewsChange("$X,Remove");
					
					if ($AfterPresent[0]) {
						foreach (@AfterPresent) {
							&NewsChange($_);
						}
						@AfterPresent = ();
					}
				}
				
				&WriteLog;
				&GFnews;
				&WinnerCheck;
				$EatNews = "";
				$MenuNews = "";
				$X = $in{'Number'};
			}
		}
	}
	
	#참가자 확인
	&PlayerCheck;
	
	#예언자표와 옵션태그
	@Player = sort by_HP (@Player);
	$PlayerData = "<TABLE BORDER=1 BGCOLOR=$ColorTable CELLPADDING=4 WIDTH=98%><TR BGCOLOR=$ColorTR><TH WIDTH=20% NOWRAP><FONT COLOR=$ColorTRfont>예언자</FONT></TH><TH><FONT COLOR=$ColorTRfont>HP</FONT></TH><TH><FONT COLOR=$ColorTRfont>MP</FONT></TH><TH><FONT COLOR=$ColorTRfont>돈</FONT></TH><TH WIDTH=100%><FONT COLOR=$ColorTRfont>상태</FONT></TH><TH><FONT COLOR=$ColorTRfont>상</FONT></TH><TH NOWRAP><FONT COLOR=$ColorTRfont>수호</FONT></TH></TR>\n";
	$PlayerOption = "";
	foreach (@Player) {
		&ConditionDeco($_);
		&StatueDeco($_);
		&GuardianDeco($_);
		if ($_ == $Winner) {
			$Judgment = "$ThisFile"."?Mode=Judgment";
			$PlayerData .= "<TR BGCOLOR=$ColorTDup><TH ROWSPAN=2 NOWRAP><FONT COLOR=$ColorAttack>★</FONT><A HREF=\"$Judgment\" CLASS=\"link\">$Name[$_]</A><FONT COLOR=$ColorAttack>★</FONT></TH><TD ALIGN=\"right\">$HP[$_]</TD><TD ALIGN=\"right\">$MP[$_]</TD><TD ALIGN=\"right\">$GP[$_]G</TD><TD>$ConditionDeco</TD><TH ROWSPAN=2>$StatueDeco</TH><TH ROWSPAN=2>$GuardianDeco</TH></TR>\n<TR><TD COLSPAN=4 BGCOLOR=$ColorTDdown>$Comment[$_]</TD></TR>\n";
		}
		elsif ($HP[$_] >= 100) {
			$PlayerData .= "<TR BGCOLOR=$ColorTDup><TH ROWSPAN=2 NOWRAP><FONT COLOR=$ColorProphet>$Name[$_]</FONT></TH><TD ALIGN=\"right\">$HP[$_]</TD><TD ALIGN=\"right\">$MP[$_]</TD><TD ALIGN=\"right\">$GP[$_]G</TD><TD>$ConditionDeco</TD><TH ROWSPAN=2>$StatueDeco</TH><TH ROWSPAN=2>$GuardianDeco</TH></TR>\n<TR><TD COLSPAN=4 BGCOLOR=$ColorTDdown>$Comment[$_]</TD></TR>\n";
		}
		elsif ($HP[$_] > 0) {
			$PlayerData .= "<TR BGCOLOR=$ColorTDup><TH ROWSPAN=2 NOWRAP><FONT COLOR=$ColorProphet>$Name[$_]</FONT></TH><TD ALIGN=\"right\"><FONT COLOR=$ColorDamage>$HP[$_]</FONT></TD><TD ALIGN=\"right\">$MP[$_]</TD><TD ALIGN=\"right\">$GP[$_]G</TD><TD>$ConditionDeco</TD><TH ROWSPAN=2>$StatueDeco</TH><TH ROWSPAN=2>$GuardianDeco</TH></TR>\n<TR><TD COLSPAN=4 BGCOLOR=$ColorTDdown>$Comment[$_]</TD></TR>\n";
		}
		else {
			$PlayerData .= "<TR BGCOLOR=$ColorTDup><TH ROWSPAN=2 NOWRAP><FONT COLOR=$ColorLost>$Name[$_]</FONT></TH><TD ALIGN=\"right\"><FONT COLOR=$ColorLost>$HP[$_]</FONT></TD><TD ALIGN=\"right\"><FONT COLOR=$ColorLost>$MP[$_]</FONT></TD><TD ALIGN=\"right\"><FONT COLOR=$ColorLost>$GP[$_]G</FONT></TD><TD>$ConditionDeco</TD><TH ROWSPAN=2>$StatueDeco</TH><TH ROWSPAN=2>$GuardianDeco</TH></TR>\n<TR><TD COLSPAN=4 BGCOLOR=$ColorTDdown>$Comment[$_]</TD></TR>\n";
		}
		
		if ($_ == $CookieNum) {
			$PlayerOption .= "<OPTION VALUE=\"$_\" SELECTED>$Name[$_]\n";
		}
		else {
			$PlayerOption .= "<OPTION VALUE=\"$_\">$Name[$_]\n";
		}
	}
	$PlayerData .= "</TABLE>";
	$EditOption .= "$PlayerOption"."<OPTION VALUE=\"0\">$AdminWord\n";
	
	#주문의 저장 체크박스
	if ($CookiePsave eq 'off') {
		$PsaveCbox = '<INPUT TYPE="checkbox" NAME="PassSave" VALUE="on" CLASS="checkbox">';
	}
	else {
		$PsaveCbox = '<INPUT TYPE="checkbox" NAME="PassSave" VALUE="on" CHECKED CLASS="checkbox">';
	}
	
	#게시판링크
	if ($BBSfile) {
		$GoToBBS = "<BR><A HREF=\"$BBSfile\" CLASS=\"link\">게시판</A>";
	}
	
	#신계사
	if ($GFyear > 1) {
		$AllNews = '<A HREF="'."$ThisFile".'?Mode=AllNews" CLASS="link">神界史</A>';
	}
	
	#신전격학과 대왕생기
	if (&VisitCheck) {$Visit = '<A HREF="'."$ThisFile".'?Mode=Visit" CLASS="link">신전견학</A>';}
	elsif ($DrawFlag) {$Visit = '<A HREF="'."$ThisFile".'?Mode=Judgment" CLASS="link">大往生記</A>';}
	
	#메뉴 화면 출력
	print <<END_OF_MENU;
Content-type: text/html; charset=utf-8

<HTML>

<HEAD>

$Meta

<TITLE>갓!! 필드</TITLE>

$Style

<SCRIPT LANGUAGE="JavaScript">
<!--
$JSentry
$JSpass
$JSedit
// -->
</SCRIPT>

</HEAD>

$Body

<IMG SRC="$ImgTitle" ALT="갓필드" TITLE="갓필드" WIDTH="500" HEIGHT="80"><BR>
<BR>
$EntryForm
<BR>
$GFnews

<BR>

<CENTER>

$PlayerData

<BR>

<FORM ACTION="$ThisFile" METHOD="POST">
<B>이름</B>
<SELECT NAME="Number">
$PlayerOption</SELECT>
   <B>주문</B>
<INPUT TYPE="password" NAME="NowPass" VALUE="$CookiePass" SIZE=10 MAXLENGTH=8 CLASS="form">
   주문을 저장
$PsaveCbox
   
$GoButton<BR>
<BR>
<B>예언</B>
<INPUT TYPE="text" NAME="Comment" SIZE=80 MAXLENGTH=80 CLASS="form">
   
<INPUT TYPE="button" VALUE="예언한다." onClick="PassCheck(this.form, 'CommentChange')" CLASS="button"><BR>
<BR>
<INPUT TYPE="hidden" NAME="Mode">
</FORM>

<BR>

<HR>
<B>변경용 폼</B>(현재의 주문을 변경시 꼭 입력. 변경안할시에는 공백으로)<BR>
<BR>
<FORM ACTION="$ThisFile" METHOD="POST">
현재의 신전
<SELECT NAME="Number">
$EditOption</SELECT>
  현재의 주문
<INPUT TYPE="password" NAME="NowPass" SIZE=10 MAXLENGTH=8 CLASS="form">
$NameCform<BR>
<BR>
  새로운 주문
<INPUT TYPE="password" NAME="Password" SIZE=10 MAXLENGTH=8 CLASS="form">
  새로운 주문(다시 한번 확인)
<INPUT TYPE="password" NAME="PassAgain" SIZE=10 MAXLENGTH=8 CLASS="form">
   
<INPUT TYPE="button" VALUE="    변경한다    " onClick="EditCheck(this.form)" CLASS="button"><BR>
<INPUT TYPE="hidden" NAME="Mode" VALUE="Edit">
</FORM>

</CENTER>

<HR>

<TABLE WIDTH=100%>
<TR>
<TD VALIGN="top" WIDTH=25% NOWRAP><A HREF="$ThisFile" CLASS="link">갓필드TOP</A><BR><A HREF="$HomePage" CLASS="link">홈페이지TOP</A></TD>
<TD VALIGN="top" WIDTH=20% NOWRAP><A HREF="$RuleFile" TARGET="_blank" CLASS="link">게임설명</A>$GoToBBS</TD>
<TD VALIGN="top" NOWRAP>$AllNews<BR>$Visit</TD>
<TD VALIGN="top" ALIGN="center" NOWRAP>관리자 : <A HREF="mailto:$AdminEmail" CLASS="link">$AdminName</A></TD>
<TD VALIGN="top" ALIGN="right" WIDTH=30% NOWRAP>
게임디자인&프로그램 : <A HREF="http://red.sakura.ne.jp/~guji/" CLASS="link" TARGET="_top">グウジ</A><BR>
일러스트디자인 : <A HREF="http://red.sakura.ne.jp/~guji/" CLASS="link" TARGET="_top">あみ</A>
한글화 : <A HREF="http://mai.ye.ro/net/" CLASS="link" TARGET="_top">마이</A>
</TD>
</TR>
</TABLE>

</BODY>

</HTML>
END_OF_MENU
	
	&End;
}

#---------------
#신전
#---------------

sub Shrine {
	#HP랑MP랑GP의 합계
	$TotalP = $HP[$X] + $MP[$X] + $GP[$X];
	
	#승리 모드
	if ($X == $Winner) {&ATshrine;}
	
	#생존자 확인
	$Exist = 0;
	foreach (1..$PlayerMax) {
		if ($HP[$_] > 0) {$Exist++;}
	}
	
	#대기모드
	if (time - $LastAccess[$X] < $NextTime && $Exist > 1) {
		&ATshrine;
	}
	
	while ($MyPresent[1]) {
		#선물받는다.
		&GetPresent;
		
		#자기에게 선물, 공격미스, 공물관련은 무시한다.
		if (
			$Pcheck[0] == $X
			 || $Pcheck[1] eq 'Miss' || ($Pcheck[3] eq 'LostATmiss' && !$MyCondition[4])
			 || $Pcheck[1] eq 'Throw' || $Pcheck[1] eq 'Rope' || $Pcheck[1] eq 'Contribute'
			 || (
				(
					($Pcheck[1] eq 'GuardianAct' && $Pcheck[2] eq 'AllAct')
					 || $Jkind[$Pcheck[2]] eq 'Jug'
					 || $Jdetail[$Pcheck[2]] eq 'MagicalRod'
					 || $Jpoint[$Pcheck[2]] >= 1000 || $Jfree[$Pcheck[2]] >= 1000
					 || $Jdetail[$Pcheck[2]] eq 'AllAct'
					 || $Jdetail[$Pcheck[2]] eq 'TargetAct'
					 || $Jdetail[$Pcheck[2]] eq 'GPabsorb'
				)
				 && !$Pcheck[3]
			 )
			 || (
				$Jkind[$Pcheck[2]] eq 'Buy' && $Pcheck[1] eq 'Second'
				 && ($Jprice[$Pcheck[3]] > $GP[$X] || $Jprice[$Pcheck[3]] == 0)
			)
		) {
			$in{'Shield'} = 0; $in{'Armor'} = 0; $in{'Helm'} = 0; $in{'Gauntlet'} = 0;
			$in{'Boots'} = 0; $in{'Ring'} = 0; $in{'OtherP'} = 0;
			$in{'HP'} = 0; $in{'MP'} = 0; $in{'GP'} = 0;
			&DFcheck;
			&EatPresent;
		}
		else {last;}
	}
	
	#HP랑MP랑GP의 합계치
	$TotalP = $HP[$X] + $MP[$X] + $GP[$X];
	
	#신전에 표시할 뉴스
	&ShrineNews($EatNews);
	
	#데이터의 총합과 로그저장
	&SortJingi;
	$Jingi[$X] = join(",", @MyJ);
	$Condition[$X] = join(",", @MyCondition);
	$Present[$X] = join("==", @MyPresent);
	&WriteLog;
	
	#방어모드랑 공격모드
	if ($MyPresent[1]) {
		#공격의 종류(무기냐 기적이냐 그외)랑 속성
		&ATvariety;
		
		#방어모드
		&DFshrine;
	}
	else {
		#공물 환금
		if ($MyStatue[1]) {
			while ($MyStatue[1] && time - $MyStatue[5] >= $StatueTime) {
				if ($Jkind[$MyStatue[0]] eq 'AllS') {
					$Charity = $Jprice[$MyStatue[1]];
					$GP[$X] += $Charity;
				}
				else {
					$Charity = $Jprice[$MyStatue[1]] * 2;
					$GP[$X] += $Charity;
				}
				&JnowUseAdd($MyStatue[1]);
				&ShrineNews("$X,Charity,$MyStatue[0],$MyStatue[1],$Charity");
				&NewsChange("$X,Charity,$MyStatue[0],$MyStatue[1],$Charity");
				@MyStatue = (
					$MyStatue[0],
					$MyStatue[2],$MyStatue[3],$MyStatue[4],0,
					$MyStatue[6],$MyStatue[7],$MyStatue[8],0
				);
			}
			$Statue[$X] = join(",", @MyStatue);
			if ($GP[$X] > 990) {$GP[$X] = 990;}
			&WriteLog;
		}
		
		#승리 체크
		if ($Exist == 1 && !$Present[$X] && $Winner != $X) {
			&YearDeco($GFyear);
			&EventDeco("$X,Win");
			$ShrineNews .= "$EventDeco<BR>\n<BR>\n";
			&NewsChange("$X,Win");
			&WriteLog;
			&WinnerCheck;
		}
		
		#HP랑MP랑GP의 합계치
		$TotalP = $HP[$X] + $MP[$X] + $GP[$X];
		
		#공격모드
		&ATshrine;
	}
}

#신전(방어)
sub DFshrine {
	#뻞뚥긾?긤궻덐
	$DefenseFlag = 1;
	
	#HP갂MP갂GP귩몧륕
	&HPdeco($X);
	
	#륉뫴갂몴갂롧뚯?귩몧륕
	&ConditionDeco($X);
	&StatueDeco($X);
	&GuardianDeco($X);
	
	#딉먘럊뾭?딇궻뾎뼰
	$UMcheck = 0;
	&UseMiracleCheck;
	if ($UMJ[0]) {$UMcheck = 1;}
	
	#JavaScript
	$RestMP = 'TotalDFopen()';
	&JSshrine;
	&JSdefense;
	
	#걏럄귟걐??깛뾭긜깒긏긣?긞긏긚
	$OnChangeMP = ' onChange="TotalDFopen()"';
	&RestPselect;
	
	#?밶걁뻞뚥걂됪뽋뢯쀍
	print <<END_OF_DEFENSE;
Content-type: text/html; charset=utf-8

<HTML>

<HEAD>

$Meta

<TITLE>$Name[$X]신전</TITLE>

$Style

<SCRIPT LANGUAGE="JavaScript">
<!--
$JStotalP
$JSinfo
$JSjname
$JSjexp
$JSjexpNews
$JSjkind
$JSjdetail
$JSjattribute
$JSjpoint
$JSjfree
$JSjexpOpen
$JSjnameOpen
$JSresetButton
$JSreset
$JStotalDFopen
$JSsoloDFcheck
$JSdfColorOpen
$JStextChange
$JSvalueChange
$JSrestP
// -->
</SCRIPT>

</HEAD>

$BodyShrine

$ShrineNews

<CENTER>

<FORM ACTION="$ThisFile" METHOD="POST">

<TABLE BGCOLOR=$ColorShTableUp CELLPADDING=4 WIDTH=100%>
<TR><TH COLSPAN=2 BGCOLOR=$ColorShTH>
<FONT COLOR=$ColorProphet><BIG>$Name[$X]신전</FONT><FONT COLOR=$ColorDefense> - 방어 - </BIG></FONT><BR>
</TH></TR>
</TABLE>

<TABLE BGCOLOR=$ColorShTableDown CELLPADDING=4 WIDTH=100%>

<TR><TD ROWSPAN=2 BGCOLOR=$ColorShTDleft VALIGN="top">

<TABLE WIDTH=100%>
<TR><TD WIDTH=50%>$Jshow[1]</TD><TD WIDTH=50%>$Jshow[2]</TD></TR>
<TR><TD WIDTH=50%>$Jshow[3]</TD><TD WIDTH=50%>$Jshow[4]</TD></TR>
<TR><TD WIDTH=50%>$Jshow[5]</TD><TD WIDTH=50%>$Jshow[6]</TD></TR>
<TR><TD WIDTH=50%>$Jshow[7]</TD><TD WIDTH=50%>$Jshow[8]</TD></TR>
<TR><TD WIDTH=50%>$Jshow[9]</TD><TD WIDTH=50%>$Jshow[10]</TD></TR>
<TR><TD WIDTH=50%>$Jshow[11]</TD><TD WIDTH=50%>$Jshow[12]</TD></TR>
<TR><TD WIDTH=50%>$Jshow[13]</TD><TD WIDTH=50%>$Jshow[14]</TD></TR>
<TR><TD WIDTH=50%>$Jshow[15]</TD><TD WIDTH=50%>$Jshow[16]</TD></TR>
</TABLE>

</TD><TD BGCOLOR=$ColorShTDup ALIGN="center" VALIGN="top" WIDTH=40%>

<TABLE borderColor=#66b3ff BORDER=1 BGCOLOR=$ColorShTDup CELLPADDING=4 WIDTH=95%>
<TR BGCOLOR=$ColorTR><TH><FONT COLOR=$ColorTRfont>HP</FONT></TH><TH><FONT COLOR=$ColorTRfont>MP</FONT></TH><TH><FONT COLOR=$ColorTRfont>금</FONT></TH><TH><FONT COLOR=$ColorTRfont>神象</FONT></TH><TH><FONT COLOR=$ColorTRfont>수호</FONT></TH></TR>
<TR BGCOLOR=$ColorTDdown><TD ALIGN="right">$HPdeco</TD><TD ALIGN="right">$MPdeco</TD><TD ALIGN="right">$GPdeco</TD><TH ROWSPAN=2>$Jshow[23]</TH><TH ROWSPAN=2>$GuardianDeco</TH></TR>
<TR BGCOLOR=$ColorTDdown><TD ALIGN="right">
$RestPselect
</TD></TR>
<TR BGCOLOR=$ColorTDdown><TD COLSPAN=5>$ConditionDeco</TD></TR>
</TABLE>

<BR>
<BR>

<TABLE BGCOLOR=$ColorDfTable CELLPADDING=3 WIDTH=95%>
<TR><TH>　</TH><TH BGCOLOR=$ColorDfTH><FONT COLOR=$ColorDfTHfont>방패</FONT></TH><TD BGCOLOR=$ColorDfTD WIDTH=100%>
<A HREF="javascript:void(0)" onClick="Reset('Protector1')" CLASS="normal"><DIV ID="Protector1"></DIV></A>
</TD><TH>　</TH></TR>
<TR><TH>　</TH><TH BGCOLOR=$ColorDfTH><FONT COLOR=$ColorDfTHfont>갑옷</FONT></TH><TD BGCOLOR=$ColorDfTD>
<A HREF="javascript:void(0)" onClick="Reset('Protector2')" CLASS="normal"><DIV ID="Protector2"></DIV></A>
</TD><TH>　</TH></TR>
<TR><TH>　</TH><TH BGCOLOR=$ColorDfTH><FONT COLOR=$ColorDfTHfont>투구</FONT></TH><TD BGCOLOR=$ColorDfTD>
<A HREF="javascript:void(0)" onClick="Reset('Protector3')" CLASS="normal"><DIV ID="Protector3"></DIV></A>
</TD><TH>　</TH></TR>
<TR><TH>　</TH><TH BGCOLOR=$ColorDfTH><FONT COLOR=$ColorDfTHfont>장갑</FONT></TH><TD BGCOLOR=$ColorDfTD>
<A HREF="javascript:void(0)" onClick="Reset('Protector4')" CLASS="normal"><DIV ID="Protector4"></DIV></A>
</TD><TH>　</TH></TR>
<TR><TH>　</TH><TH BGCOLOR=$ColorDfTH><FONT COLOR=$ColorDfTHfont>신발</FONT></TH><TD BGCOLOR=$ColorDfTD>
<A HREF="javascript:void(0)" onClick="Reset('Protector5')" CLASS="normal"><DIV ID="Protector5"></DIV></A>
</TD><TH>　</TH></TR>
<TR><TH>　</TH><TH BGCOLOR=$ColorDfTH><FONT COLOR=$ColorDfTHfont>반지</FONT></TH><TD BGCOLOR=$ColorDfTD>
<A HREF="javascript:void(0)" onClick="Reset('Protector6')" CLASS="normal"><DIV ID="Protector6"></DIV></A>
</TD><TH>　</TH></TR>
<TR><TH>　</TH><TH BGCOLOR=$ColorDfTHother NOWRAP><FONT COLOR=$ColorDfTHfont>그외</FONT></TH><TD BGCOLOR=$ColorDfTDother>
<A HREF="javascript:void(0)" onClick="Reset('Protector7')" CLASS="normal"><DIV ID="Protector7"></DIV></A>
</TD><TH>　</TH></TR>
</TABLE>
<BR>
<TABLE WIDTH=90%>
<TR><TD>합계 : </TD><TD ALIGN="center" NOWRAP><B><DIV ID="TotalDefense">-</DIV></B></TD>
<TD ALIGN="right" WIDTH=30%><INPUT TYPE="submit" VALUE="     OK     " CLASS="button"></TD><TD ALIGN="right" WIDTH=30%><INPUT TYPE="button" VALUE="  Reset  " onClick="ResetButton(); Reset('All')" CLASS="button"></TD></TR>
</TABLE>
<BR>
<INPUT TYPE="hidden" NAME="Shield" VALUE="0">
<INPUT TYPE="hidden" NAME="Armor" VALUE="0">
<INPUT TYPE="hidden" NAME="Helm" VALUE="0">
<INPUT TYPE="hidden" NAME="Gauntlet" VALUE="0">
<INPUT TYPE="hidden" NAME="Boots" VALUE="0">
<INPUT TYPE="hidden" NAME="Ring" VALUE="0">
<INPUT TYPE="hidden" NAME="OtherP" VALUE="0">

<INPUT TYPE="hidden" NAME="Number" VALUE="$X">
<INPUT TYPE="hidden" NAME="NowPass" VALUE="$CryptedPass">
<INPUT TYPE="hidden" NAME="Mode" VALUE="Defense">

<TABLE BORDER=0 BGCOLOR=$ColorShTableExp CELLPADDING=3 WIDTH=95%><TR><TD BGCOLOR=$ColorShTDexp>
<DIV ID="Jexp">(神器의 설명)<BR><BR><BR></DIV>
</TD></TR></TABLE>

</TD></TR>

<TR><TD VALIGN="top" BGCOLOR=$ColorShTDdown>

<TABLE WIDTH=100%>
<TR><TD WIDTH=50%>$Jshow[17]</TD><TD WIDTH=50%>$Jshow[18]</TD></TR>
<TR><TD WIDTH=50%>$Jshow[19]</TD><TD WIDTH=50%>$Jshow[20]</TD></TR>
<TR><TD WIDTH=50%>$Jshow[21]</TD><TD WIDTH=50%>$Jshow[22]</TD></TR>
</TABLE>

</TD></TR>

</TABLE>

</FORM>

</CENTER>

<A HREF="$ThisFile" CLASS="link">갓필드TOP</A><BR>
<BR>
<A HREF="$HomePage" CLASS="link">홈페이지TOP</A>

</BODY>

</HTML>
END_OF_DEFENSE
	
	&End;
}

#신전(공격)
sub ATshrine {
	#뷄뻞뚥긾?긤궻덐
	$DefenseFlag = 0;
	
	#HP갂MP갂GP귩몧륕
	&HPdeco($X);
	
	#륉뫴갂몴갂롧뚯?귩몧륕
	&ConditionDeco($X);
	&StatueDeco($X);
	&GuardianDeco($X);
	
	#딉먘럊뾭?딇궻뾎뼰
	$UMcheck = 0;
	$UMcheckSub = 0;
	&UseMiracleCheck;
	if ($UMJ[0]) {$UMcheck = 1;}
	if ($UMJ[1]) {$UMcheckSub = 1;}
	
	#JavaScript
	$RestMP = 'TotalATopen()';
	&JSshrine;
	&JSattack;
	
	#긾?긤?렑
	$Scolor = $ColorProphet;
	if ($X == $Winner) {
		$ModeShow = "<FONT COLOR=$ColorWait>- 공개중 -</FONT>";
	}
	elsif ($HP[$X] == 0) {
		$ModeShow = "<FONT COLOR=$ColorAscension>- 파괴 -</FONT>";
		$Scolor = $ColorLost;
	}
	elsif (time - $LastAccess[$X] >= $NextTime) {
		$ModeShow = "<FONT COLOR=$ColorAttack>- 공격 -</FONT>";
		
		if (&VisitCheck) {
			$VisitButton = "<FORM ACTION=\"$ThisFile\" METHOD=\"POST\">\n";
			$VisitButton .= "<INPUT TYPE=\"submit\" VALUE=\"  신전방문  \" CLASS=\"button\">\n";
			$VisitButton .= "<INPUT TYPE=\"hidden\" NAME=\"Number\" VALUE=\"$X\">\n";
			$VisitButton .= "<INPUT TYPE=\"hidden\" NAME=\"NowPass\" VALUE=\"$CryptedPass\">\n";
			$VisitButton .= "<INPUT TYPE=\"hidden\" NAME=\"Mode\" VALUE=\"Visit\">\n";
			$VisitButton .= "</FORM>";
		}
	}
	else {
		$ModeShow = "<FONT COLOR=$ColorWait>- 대기 -</FONT>";
	}
	
	#걏럄귟걐??깛뾭긜깒긏긣?긞긏긚
	$OnChangeMP = ' onChange="TotalATopen()"';
	$OnChangeGP = ' onChange="TotalATopen()"';
	&RestPselect;
	
	#??긒긞긣OPTION?긐
	&PlayerCheck;
	@Player = sort by_HP (@Player);
	$TargetOption = "";
	foreach (@Player) {
		if ($_ == $X) {
			$TargetOption .= "<OPTION VALUE=\"$_\" SELECTED>$Name[$_]\n";
		}
		elsif (!$MyCondition[1] && $HP[$_] > 0) {
			$TargetOption .= "<OPTION VALUE=\"$_\">$Name[$_]\n";
		}
	}
	if ($MyCondition[1]) {
		$TargetOption .= "<OPTION VALUE=\"0\">안개의 저편\n";
	}
	
	#?밶걁뛘똼걂됪뽋뢯쀍
	print <<END_OF_ATTACK;
Content-type: text/html; charset=utf-8

<HTML>

<HEAD>

$Meta

<TITLE>$Name[$X]신전</TITLE>

$Style

<SCRIPT LANGUAGE="JavaScript">
<!--
$JStotalP
$JSinfo
$JSjname
$JSjexp
$JSjexpNews
$JSjtype
$JSjkind
$JSjdetail
$JSjattribute
$JSjmp
$JSjpoint
$JSjfree
$JSjprice
$JSjexpOpen
$JSjnameOpen
$JSresetButton
$JSreset
$JStotalATopen
$JScheckPselect
$JSatColorOpen
$JStextChange
$JSvalueChange
$JSrestP
$JSsubmit
// -->
</SCRIPT>

</HEAD>

$BodyShrine

$ShrineNews

<CENTER>

<FORM ACTION="$ThisFile" METHOD="POST">

<TABLE BGCOLOR=$ColorShTableUp CELLPADDING=4 WIDTH=100%>
<TR><TH COLSPAN=2 BGCOLOR=$ColorShTH>
<FONT COLOR=$Scolor><BIG>$Name[$X]신전</BIG></FONT>　　
$ModeShow<BR>
</TH></TR>
</TABLE>

<TABLE BGCOLOR=$ColorShTableDown CELLPADDING=4 WIDTH=100%>

<TR><TD ROWSPAN=2 BGCOLOR=$ColorShTDleft VALIGN="top">

<TABLE WIDTH=100%>
<TR><TD WIDTH=50%>$Jshow[1]</TD><TD WIDTH=50%>$Jshow[2]</TD></TR>
<TR><TD WIDTH=50%>$Jshow[3]</TD><TD WIDTH=50%>$Jshow[4]</TD></TR>
<TR><TD WIDTH=50%>$Jshow[5]</TD><TD WIDTH=50%>$Jshow[6]</TD></TR>
<TR><TD WIDTH=50%>$Jshow[7]</TD><TD WIDTH=50%>$Jshow[8]</TD></TR>
<TR><TD WIDTH=50%>$Jshow[9]</TD><TD WIDTH=50%>$Jshow[10]</TD></TR>
<TR><TD WIDTH=50%>$Jshow[11]</TD><TD WIDTH=50%>$Jshow[12]</TD></TR>
<TR><TD WIDTH=50%>$Jshow[13]</TD><TD WIDTH=50%>$Jshow[14]</TD></TR>
<TR><TD WIDTH=50%>$Jshow[15]</TD><TD WIDTH=50%>$Jshow[16]</TD></TR>
</TABLE>

</TD><TD BGCOLOR=$ColorShTDup ALIGN="center" VALIGN="top" WIDTH=40%>

<TABLE borderColor=#66b3ff BORDER=1 BGCOLOR=$ColorShTDup CELLPADDING=4 WIDTH=95%>
<TR BGCOLOR=$ColorTR><TH><FONT COLOR=$ColorTRfont>HP</FONT></TH><TH><FONT COLOR=$ColorTRfont>MP</FONT></TH><TH><FONT COLOR=$ColorTRfont>금</FONT></TH><TH><FONT COLOR=$ColorTRfont>神象</FONT></TH><TH><FONT COLOR=$ColorTRfont>수호</FONT></TH></TR>
<TR BGCOLOR=$ColorTDdown><TD ALIGN="right">$HPdeco</TD><TD ALIGN="right">$MPdeco</TD><TD ALIGN="right">$GPdeco</TD><TH ROWSPAN=2>$Jshow[23]</TH><TH ROWSPAN=2>$GuardianDeco</TH></TR>
<TR BGCOLOR=$ColorTDdown><TD ALIGN="right">
$RestPselect
</TD></TR>
<TR BGCOLOR=$ColorTDdown><TD COLSPAN=5>$ConditionDeco</TD></TR>
</TABLE>

<BR>
<B>타겟</B>
<SELECT NAME="Target">
$TargetOption</SELECT>
<BR>
<BR>

<TABLE BGCOLOR=$ColorAtTable CELLPADDING=3 WIDTH=95%>
<TR><TH>　</TH><TH BGCOLOR=$ColorAtTH ROWSPAN=5><FONT COLOR=$ColorAtTHfont>공<BR>격</FONT></TH><TD BGCOLOR=$ColorAtTD COLSPAN=2 WIDTH=100%>
<A HREF="javascript:void(0)" onClick="Reset('All')" CLASS="normal"><DIV ID="Weapon1"></DIV></A>
</TD><TH>　</TH></TR>
<TR><TH>　</TH><TH ROWSPAN=4>　</TH><TD BGCOLOR=$ColorAtTD WIDTH=100%>
<A HREF="javascript:void(0)" onClick="Reset('Weapon2')" CLASS="normal"><DIV ID="Weapon2"></DIV></A>
</TD><TH>　</TH></TR>
<TR><TH>　</TH><TD BGCOLOR=$ColorAtTD>
<A HREF="javascript:void(0)" onClick="Reset('Weapon3')" CLASS="normal"><DIV ID="Weapon3"></DIV></A>
</TD><TH>　</TH></TR>
<TR><TH>　</TH><TD BGCOLOR=$ColorAtTD>
<A HREF="javascript:void(0)" onClick="Reset('Weapon4')" CLASS="normal"><DIV ID="Weapon4"></DIV></A>
</TD><TH>　</TH></TR>
<TR><TH>　</TH><TD BGCOLOR=$ColorAtTD>
<A HREF="javascript:void(0)" onClick="Reset('Weapon5')" CLASS="normal"><DIV ID="Weapon5"></DIV></A>
</TD><TH>　</TH></TR>
</TABLE>
<BR>
<TABLE WIDTH=90%>
<TR><TD NOWRAP>합계 : </TD><TD ALIGN="center" NOWRAP><B><DIV ID="TotalAttack">-</DIV></B></TD>
<TD ALIGN="right" WIDTH=30%><INPUT TYPE="button" VALUE="     OK     " onClick="Submit()" CLASS="button"></TD><TD ALIGN="right" WIDTH=30%><INPUT TYPE="button" VALUE="  Reset  " onClick="ResetButton(); Reset('All')" CLASS="button"></TD></TR>
</TABLE>
<BR>
<INPUT TYPE="hidden" NAME="Act1" VALUE="0">
<INPUT TYPE="hidden" NAME="Act2" VALUE="0">
<INPUT TYPE="hidden" NAME="Act3" VALUE="0">
<INPUT TYPE="hidden" NAME="Act4" VALUE="0">
<INPUT TYPE="hidden" NAME="Act5" VALUE="0">

<INPUT TYPE="hidden" NAME="Number" VALUE="$X">
<INPUT TYPE="hidden" NAME="NowPass" VALUE="$CryptedPass">
<INPUT TYPE="hidden" NAME="Mode" VALUE="Attack">

<TABLE BORDER=0 BGCOLOR=$ColorShTableExp CELLPADDING=3 WIDTH=95%><TR><TD BGCOLOR=$ColorShTDexp>
<DIV ID="Jexp">(神器의 설명)<BR><BR><BR></DIV>
</TD></TR></TABLE>

</TD></TR>

<TR><TD VALIGN="top" BGCOLOR=$ColorShTDdown>

<TABLE WIDTH=100%>
<TR><TD WIDTH=50%>$Jshow[17]</TD><TD WIDTH=50%>$Jshow[18]</TD></TR>
<TR><TD WIDTH=50%>$Jshow[19]</TD><TD WIDTH=50%>$Jshow[20]</TD></TR>
<TR><TD WIDTH=50%>$Jshow[21]</TD><TD WIDTH=50%>$Jshow[22]</TD></TR>
</TABLE>

</TD></TR>

</TABLE>

</FORM>

</CENTER>

<TABLE WIDTH=50%>
<TR><TD>
<A HREF="$ThisFile" CLASS="link">갓필드TOP</A><BR>
<BR>
<A HREF="$HomePage" CLASS="link">홈페이지TOP</A>
</TD><TD ALIGN="right">
$VisitButton
</TD></TR>
</TABLE>

</BODY>

</HTML>
END_OF_ATTACK
	
	&End;
}

#-------------
#뉴스
#-------------

#긦깄?긚궻뛛륷
sub NewsChange {
	for ($NC = $NewsMax; $NC >= 2; $NC--) {
		$News[$NC] = $News[$NC - 1];
	}
	$News[1] = $_[0];
	
	$GFyear++;
}

#긦깄?긚궻?렑
sub GFnews {
	$GFnews = '';
	
	for ($GFN = $NewsShow; $GFN >= 1; $GFN--) {
		if ($News[$GFN]) {
			$J = $GFyear - $GFN;
			&NewsDeco($J,$News[$GFN]);
			$GFnews .= "$NewsDeco<HR COLOR=$ColorHR>\n";
		}
	}
}

#긦깄?긚귩몧륕
#걏:걐궳귽긹깛긣빶궸뗦먛귞귢귡
sub NewsDeco {
	$YDcheck = $_[0];
	&YearDeco($_[0]);
	
	@Event = split(/:/, $_[1]);
	
	$NewsDeco = "";
	foreach (@Event) {
		if ($_) {
			&EventDeco($_);
			if (!$BlankFlag) {$NewsDeco .= "$EventDeco<BR>\n";}
		}
	}
	$NewsDeco .= "<BR>\n";
}

#긦깄?긚궻둫귽긹깛긣귩몧륕
#걏,걐궳궠귞궸뗦먛귞귢귡걁겓댰뼞걂
#뾴멹0=뛱벍귩뛱궯궫뾞뙻롌궻붥뜂
#뾴멹1=뛱벍귩렑궥빒럻쀱
#뾴멹2댥돷궼?궦귡?딇귘릶뭠궶궵갂뾴멹1궸댨뫔궥귡
sub EventDeco {
	$BlankFlag = 0;
	$TargetShowFlag = 0;
	
	@Element = split(/,/, $_[0]);
	$N = $Element[0];
	if ($Element[4] eq 'Fog') {
		if ($in{'Mode'} eq 'Judgment') {
			$Prophet = "<FONT COLOR=$ColorMercury>안개의 저편에서 누군가</FONT>(<FONT COLOR=$ColorProphet><B>$Name[$N]</B></FONT>)";
		}
		else {
			$Prophet = "<FONT COLOR=$ColorMercury>안개의 저편에서 누군가</FONT>";
		}
	}
	elsif ($Element[7] eq 'Earth' && $Element[8] eq 'Use') {
		&GuardianNameDeco($Element[7]);
		$Prophet = $GuardianNameDeco;
	}
	else {
		$Prophet = "<FONT COLOR=$ColorProphet><B>$Name[$N]</B></FONT>";
	}
	
	$EventDeco = "$YearDeco";
	if ($Element[3] eq 'NewsOnly') {$EventDeco = "";}
	
	if ($Element[1] eq 'Entry') {
		$EventDeco .= "$Prophet 神界에 와서 새로운 신전을 건립했다.";
	}
	elsif ($Element[1] eq 'Start') {
		$EventDeco .= "<FONT COLOR=$ColorAttack><B>$GuardianName{'Earth'}이 영원히 잠들었다....!</B></FONT>";
	}
	elsif ($Element[1] eq 'Remove') {
		$EventDeco .= "$Prophet는<FONT COLOR=$ColorAscension>하계했다.</FONT>";
		$JMremoveFlag = 1;
	}
	elsif ($Element[1] eq 'Lost') {
		$EventDeco .= "$Prophet는<FONT COLOR=$ColorAscension><B>승천</B></FONT>했다!";
	}
	elsif ($Element[1] eq 'Draw') {
		$EventDeco .= "<BIG>$Prophet<B>는 무념의<FONT COLOR=$ColorAscension>大往生</FONT>을 이뤘다!!</B></BIG>";
	}
	elsif ($Element[1] eq 'Win') {
		$EventDeco .= "<BIG><FONT COLOR=$ColorAttack><B>★</B></FONT>$Prophet<B>는 싸움에서 이겼다!!</B><FONT COLOR=$ColorAttack><B>★</B></FONT></BIG>";
	}
	elsif ($Element[1] eq 'BeNot') {
		$EventDeco .= "그러나 $Prophet는 이미 神界에 없었다.";
	}
	elsif ($Element[1] eq 'DoNot') {
		$EventDeco .= "그러나 $Prophet는 아무이상 없었다.";
	}
	elsif ($Element[1] eq 'HPzero') {
		$EventDeco .= "$Prophet는<B>HP</B>가<FONT COLOR=$ColorDamage><B>0</B></FONT>되었다.";
	}
	elsif ($Element[1] eq 'Damage') {
		$EventDeco .= "$Prophet에게<FONT COLOR=$ColorDamage><B>$Element[2]</B></FONT>데미지!!";
	}
	elsif ($Element[1] eq 'NoDamage') {
		$EventDeco .= "$Prophet는 데미지를 안입었다.";
	}
	elsif ($Element[1] eq 'SelfDamage') {
		$EventDeco .= "$Prophet는 사악한 神器를 사용할려고 하자 <B>저주</B>를 받았다.";
		if ($Element[2]) {$EventDeco .= "?<FONT COLOR=$ColorDamage><B>$Element[2]</B></FONT>데미지";}
	}
	elsif ($Element[1] eq 'Sinister') {
		$EventDeco .= "<FONT COLOR=$ColorPluto>그러자, 불길한 기운과 함께<B>死神</B>이 강림!! <B>HP</B>를 뺏어간다!!</FONT>(<FONT COLOR=$ColorDamage><B>$Element[2]</B></FONT>데미지)";
	}
	elsif ($Element[1] eq 'LostAT') {
		$EventDeco .= "$Prophet는 의식이 멀어지면서도 모든 기력과 함께 공격을 펼쳤다!!";
	}
	elsif ($Element[1] eq 'WeakWind' || $Element[1] eq 'StrongWind' || $Element[1] eq 'Hell' || $Element[1] eq 'Heaven') {
		#병명
		if ($Element[1] eq 'WeakWind') {
			$Disease = "<FONT COLOR=$ColorNormal><B>弱風病</B></FONT>";
			$Worse = "<FONT COLOR=$ColorNormal><B>强風病</B></FONT>";
		}
		elsif ($Element[1] eq 'StrongWind') {
			$Disease = "<FONT COLOR=$ColorNormal><B>强風病</B></FONT>";
			$Worse = "<FONT COLOR=$ColorNormal><B>地獄病</B></FONT>";
		}
		elsif ($Element[1] eq 'Hell') {
			$Disease = "<FONT COLOR=$ColorNormal><B>地獄病</B></FONT>";
			$Worse = "<FONT COLOR=$ColorNormal><B>天國病</B></FONT>";
		}
		else {
			$Disease = "<FONT COLOR=$ColorNormal><B>天國病</B></FONT>";
		}
		
		#병세
		if ($Element[3] eq 'GetDisease') {
			$EventDeco .= "$Prophet는 $Disease에 걸리고 말았다!!";
		}
		elsif ($Element[3] eq 'Infect') {
			$EventDeco .= "$Prophet는 $Disease에 감염되고 말았다!!";
		}
		elsif ($Element[3] eq 'Damage') {
			$EventDeco .= "$Prophet는 $Disease에 걸려있다!! <FONT COLOR=$ColorDamage><B>$Element[4]</B></FONT>데미지!!";
		}
		elsif ($Element[3] eq 'HPup') {
			$EventDeco .= "$Prophet는 $Disease에 걸려있다!!<B>HP$Element[4]</B>회복!!";
		}
		elsif ($Element[3] eq 'Fit') {
			$EventDeco .= "$Prophet는 $Disease의 발작이 일어났다!!";
		}
		elsif ($Element[3] eq 'FitDamage') {
			$EventDeco .= "$Prophet는 $Disease의 발작이 일어나고 있다!!<FONT COLOR=$ColorDamage><B>$Element[4]</B></FONT>데미지!!";
		}
		elsif ($Element[3] eq 'Worse') {
			$EventDeco .= "$Prophet는 $Disease가 도져서 $Worse가 되어 버렸다!!";
		}
		elsif ($Element[3] eq 'CureDisease') {
			$EventDeco .= "$Prophet는 $Disease가 치료되었다.";
		}
	}
	elsif ($Element[1] eq 'GetFog') {
		$EventDeco .= "$Prophet의 주위에 <FONT COLOR=$ColorMercury><B>안개</B></FONT>가 둘러 쌓았다.";
	}
	elsif ($Element[1] eq 'CureFog') {
		$EventDeco .= "$Prophet의 주위에 있던 <FONT COLOR=$ColorMercury><B>안개</B></FONT>가 걷혔다.";
	}
	elsif ($Element[1] eq 'GetFlash') {
		$EventDeco .= "$Prophet는 <FONT COLOR=$ColorUranus><B>섬광상태</B></FONT>가 되어버렸다!!";
	}
	elsif ($Element[1] eq 'CureFlash') {
		$EventDeco .= "$Prophet는 <FONT COLOR=$ColorUranus><B>섬광상태</B></FONT>에서 회복되었다.";
	}
	elsif ($Element[1] eq 'GetIllusion') {
		$EventDeco .= "$Prophet는 <FONT COLOR=$ColorJupiter><B>환각상태</B></FONT>에 빠져들었다!!";
	}
	elsif ($Element[1] eq 'IllusionAT') {
		$EventDeco .= "$Prophet는 <FONT COLOR=$ColorJupiter><B>환각</B></FONT>을 보고 있다!!";
	}
	elsif ($Element[1] eq 'Throw') {
		&Jdeco($Element[2]);
		&JdecoEvent;
		$EventDeco .= "$Prophet는 $JeventDeco를 던졌다.";
	}
	elsif ($Element[1] eq 'IllusionDF') {
		$EventDeco .= "…생각했지만 $Prophet는 <FONT COLOR=$ColorJupiter><B>환각</B></FONT>을 보고 있었던거 뿐이다.";
	}
	elsif ($Element[1] eq 'CureIllusion') {
		$EventDeco .= "$Prophet는 <FONT COLOR=$ColorJupiter><B>환각상태</B></FONT>에서 빠져나왔다.";
	}
	elsif ($Element[1] eq 'GetDarkCloud') {
		$EventDeco .= "$Prophet의 머리위로 <FONT COLOR=$ColorPluto><B>먹구름</B></FONT>이 끼기 시작했다.";
	}
	elsif ($Element[1] eq 'CureDarkCloud') {
		$EventDeco .= "$Prophet의 머리위로 끼고 있던 <FONT COLOR=$ColorPluto><B>먹구름</B></FONT>이 사라졌다.";
	}
	elsif ($Element[1] eq 'DoGive') {
		&Jdeco($Element[2]);
		&JdecoEvent;
		$EventDeco = "$Prophet는 <B>태양신</B>에게서 $JeventDeco를 받았다.";
		if (!$in{'Mode'} || $in{'Mode'} eq 'AllNews' || $in{'Mode'} eq 'Judgment' || $in{'Mode'} eq 'CommentChange' || $DrawFlag) {
			$EventDeco = "$YearDeco"."$EventDeco";
		}
	}
	elsif ($Element[1] eq 'NotGive') {
		$EventDeco = "$Prophet는 <B>태양신</B>에게서 아무것도 받지 못했다.";
	}
	elsif ($Element[1] eq 'Gift') {
		&Jdeco($Element[2]);
		&JdecoEvent;
		if (!$in{'Mode'} || $in{'Mode'} eq 'AllNews' || $in{'Mode'} eq 'Judgment' || $in{'Mode'} eq 'CommentChange' || $DrawFlag) {
			$EventDeco .= "<B>태양신</B>으로부터 $Prophet의 위문품으로 $JeventDeco를 주셨다.";
		}
		else {
			$EventDeco = "<BR>\n<B>태양신</B>으로부터 $Prophet의 위문품으로 $JeventDeco를 주셨다.<BR>\n";
		}
	}
	elsif ($Element[1] eq 'NotGift') {
		$EventDeco = "<BR>\n<B>태양신</B>으로부터 $Prophet에게 위문품은 없었다.<BR>\n";
	}
	elsif ($Element[1] eq 'Full') {
		&Jdeco($Element[2]);
		&JdecoEvent;
		$EventDeco .= "$Prophet는 神器가 가득이라서 $JeventDeco를 버렸다.";
	}
	elsif ($Element[1] eq 'HPup') {
		$EventDeco .= "$Prophet는 <B>HP$Element[2]</B>회복했다.";
	}
	elsif ($Element[1] eq 'MPup') {
		$EventDeco .= "$Prophet는 <B>MP$Element[2]</B>회복했다.";
	}
	elsif ($Element[1] eq 'GPup') {
		$EventDeco .= "$Prophet는 <B>$Element[2]G</B>입수했다.";
	}
	elsif ($Element[1] eq 'GPdown') {
		$EventDeco .= "$Prophet는 <B>$Element[2]G</B>빼앗겼다.";
		if ($Element[3]) {$EventDeco .= "(<FONT COLOR=$ColorDamage><B>$Element[3]</B></FONT>데미지)";}
	}
	elsif ($Element[1] eq 'LoseJ') {
		if ($Element[2] eq 'Some') {
			if (!$in{'Mode'} || $in{'Mode'} eq 'AllNews' || $in{'Mode'} eq 'CommentChange' || $in{'Mode'} eq 'Judgment' || $DrawFlag) {
				$EventDeco .= "$Prophet는 神器를 몇개 잃었다.";
			}
			else  {
				$BlankFlag = 1;
			}
		}
		elsif ($Element[3] eq 'Hidden' && (!$in{'Mode'} || $in{'Mode'} eq 'AllNews' || $in{'Mode'} eq 'CommentChange' || $in{'Mode'} eq 'Judgment' || $DrawFlag)) {
			$BlankFlag = 1;
		}
		else {
			&Jdeco($Element[2]);
			&JdecoEvent;
			$EventDeco .= "$Prophet는 $JeventDeco를 잃었다.";
		}
	}
	elsif ($Element[1] eq 'LoseM') {
		&Jdeco($Element[2]);
		&JdecoEvent;
		$EventDeco .= "$Prophet는 그 순간에 $JeventDeco를 잃어버렸다.";
	}
	elsif ($Element[1] eq 'Buy') {
		$EventDeco .= "$Prophet는 <B>$Jprice[$Element[2]]G</B>에 샀다.";
	}
	elsif ($Element[1] eq 'NotBuy') {
		$EventDeco .= "$Prophet는 사지않고 버렸다.";
	}
	elsif ($Element[1] eq 'MakeBuy') {
		$EventDeco .= "$Prophet는 <B>$Jprice[$Element[2]]G</B>에 강매당했다.";
		if ($Element[3]) {$EventDeco .= "(<FONT COLOR=$ColorDamage><B>$Element[3]</B></FONT>데미지)";}
	}
	elsif ($Element[1] eq 'Contribute') {
		if ($ShrineNewsFlag) {$EventDeco = "";}
		&Jdeco($Element[2]);
		&JdecoEvent;
		$EventDeco .= "$Prophet는 <FONT COLOR=$ColorProphet><B>$Name[$Element[3]]신전</B></FONT>에서 $JbuyDeco을 샀다.";
	}
	elsif ($Element[1] eq 'Charity') {
		if ($ShrineNewsFlag) {$EventDeco = "";}
		&Jdeco($Element[2]);
		&JdecoEvent;
		$EventDeco .= "$Prophet<FONT COLOR=$ColorProphet><B>신전</B></FONT>의 $JeventDeco에 바쳐진";
		&Jdeco($Element[3]);
		&JdecoEvent;
		$EventDeco .= "$JbuyDeco가 <B>$Element[4]G</B>에 환금되었다.";
	}
	elsif ($Element[1] eq 'Guardian') {
		&GuardianNameDeco($Element[2]);
		if ($Element[3] eq 'Come') {
			$EventDeco .= "$GuardianNameDeco가 나타나 $Prophet수호로 붙었다.";
		}
		elsif ($Element[3] eq 'Appear') {
			$EventDeco .= "$GuardianNameDeco가 나타났다.";
		}
		elsif ($Element[3] eq 'Attack') {
			$EventDeco .= "$GuardianNameOnly가 $Prophet를 <FONT COLOR=$ColorDamage><B>공격!!</B></FONT>";
		}
		elsif ($Element[3] eq 'Guard') {
			$EventDeco .= "$GuardianNameDeco는 $Prophet를 지켰다.(<FONT COLOR=$ColorDamage><B>$Element[4]</B></FONT>데미지)";
		}
		elsif ($Element[3] eq 'Lost') {
			$EventDeco .= "$GuardianNameOnly는 <B>태양신</B>의 곁으로 역소환되었다.";
		}
	}
	elsif ($Element[1] eq 'GuardianAct') {
		$TargetShowFlag = 0;
		&GuardianNameDeco($Element[7]);
		if ($Element[7] eq 'Mercury') {
			if ($Element[8] eq 'Fog') {
				$EventDeco .= "$GuardianNameDeco는 <FONT COLOR=$Jcolor><B>안개</B></FONT>를 불어넣었다.";
			}
			elsif ($Element[8] eq 'TargetWater') {
				$EventDeco .= "$GuardianNameDeco의 <FONT COLOR=$Jcolor><B>수정공격!!</B></FONT>";
			}
			elsif ($Element[8] eq 'AllWater') {
				if ($Element[2] eq 'AllAct') {
					$EventDeco .= "$GuardianNameDeco는 <FONT COLOR=$Jcolor><B>물보라</B></FONT>를 일으켰다!!";
				}
				elsif ($Element[2] eq 'Third') {
					$EventDeco .= "$Prophet는 <FONT COLOR=$Jcolor><B>물보라</B></FONT>를 받았다!!";
				}
				elsif ($Element[2] eq 'Miss') {
					$EventDeco .= "$Prophet는 <FONT COLOR=$Jcolor><B>물보라</B></FONT>를 피했다.";
				}
			}
			elsif ($Element[8] eq 'TargetIce') {
				$EventDeco .= "$GuardianNameDeco는 <FONT COLOR=$Jcolor><B>얼음덩어리</B></FONT>를 던졌다.";
			}
			elsif ($Element[8] eq 'AllIce') {
				if ($Element[2] eq 'AllAct') {
					$EventDeco .= "$GuardianNameDeco는 <FONT COLOR=$Jcolor><B>격렬한눈보라</B></FONT>를 뿜어냈다.";
				}
				elsif ($Element[2] eq 'Third') {
					$EventDeco .= "$Prophet는 <FONT COLOR=$Jcolor><B>격렬한눈보라</B></FONT>에 습격당했다.";
				}
				elsif ($Element[2] eq 'Miss') {
					$EventDeco .= "$Prophet는 <FONT COLOR=$Jcolor><B>격렬한눈보라</B></FONT>에게서 도망쳤다.";
				}
			}
		}
		elsif ($Element[7] eq 'Venus') {
			if ($Element[8] eq 'Scatter') {
				$EventDeco .= "$GuardianNameDeco는 <FONT COLOR=$Jcolor><B>동전</B></FONT>을 퍼트렸다.";
			}
			elsif ($Element[8] eq 'GPgiveYou') {
				$EventDeco .= "$GuardianNameDeco는 <FONT COLOR=$Jcolor><B>선물</B></FONT>을 줬다.";
			}
			elsif ($Element[8] eq 'Transfer') {
				$EventDeco .= "$GuardianNameDeco는 <FONT COLOR=$Jcolor><B>부의 이동</B></FONT>을 시도했다.";
			}
			elsif ($Element[8] eq 'GPgiveMe') {
				$EventDeco .= "$GuardianNameDeco는 $Prophet에게 <FONT COLOR=$Jcolor><B>돈</B></FONT>을 건넸다.";
			}
			elsif ($Element[8] eq 'Jewelry') {
				$EventDeco .= "$GuardianNameDeco는 $Prophet에게 <FONT COLOR=$Jcolor><B>호화스러운 악세서리</B></FONT>를 내밀었다.";
			}
		}
		elsif ($Element[7] eq 'Mars') {
			if ($Element[2] eq 'Third') {
				$EventDeco .= "$Prophet는 <FONT COLOR=$Jcolor><B>화염</B></FONT>을 받았다!!";
			}
			elsif ($Element[2] eq 'Miss') {
				$EventDeco .= "$Prophet는 <FONT COLOR=$Jcolor><B>화염</B></FONT>을 피했다.";
			}
			elsif ($Element[8] eq 'FireSS') {
				$EventDeco .= "$GuardianNameDeco는 <FONT COLOR=$Jcolor><B>화염</B></FONT>을 흘렸다!!";
			}
			elsif ($Element[8] eq 'FireS') {
				$EventDeco .= "$GuardianNameDeco는 <FONT COLOR=$Jcolor><B>화염</B></FONT>을 속삭였다!!";
			}
			elsif ($Element[8] eq 'FireM') {
				$EventDeco .= "$GuardianNameDeco는 <FONT COLOR=$Jcolor><B>화염</B></FONT>을 중얼거렸다!!";
			}
			elsif ($Element[8] eq 'FireL') {
				$EventDeco .= "$GuardianNameDeco는 <FONT COLOR=$Jcolor><B>화염</B></FONT>을 말했다!!";
			}
			elsif ($Element[8] eq 'FireLL') {
				$EventDeco .= "$GuardianNameDeco는 <FONT COLOR=$Jcolor><B>화염</B></FONT>을 외쳤다!!";
			}
		}
		elsif ($Element[7] eq 'Jupiter') {
			if ($Element[8] eq 'Branch') {
				$EventDeco .= "$GuardianNameDeco는 <FONT COLOR=$Jcolor><B>가지</B>로 <B>공격!!</B></FONT>";
			}
			elsif ($Element[8] eq 'Root') {
				$EventDeco .= "$GuardianNameDeco는 <FONT COLOR=$Jcolor><B>뿌리</B>로 <B>공격!!</B></FONT>";
			}
			elsif ($Element[8] eq 'Ivy') {
				if ($Element[2] eq 'AllAct') {
					$EventDeco .= "$GuardianNameDeco는 <FONT COLOR=$Jcolor><B>촉수</B></FONT>를 사방으로 뻗었다";
				}
				elsif ($Element[2] eq 'Third') {
					$EventDeco .= "$Prophet는 <FONT COLOR=$Jcolor><B>촉수</B></FONT>에게 잡혔다!!";
				}
				elsif ($Element[2] eq 'Miss') {
					$EventDeco .= "$Prophet는 <FONT COLOR=$Jcolor><B>촉수</B></FONT>에게 안잡혔다.";
				}
			}
			elsif ($Element[8] eq 'RedLeaves') {
				$EventDeco .= "$GuardianNameDeco의 <FONT COLOR=$Jcolor><B>단풍</B></FONT>이 현혹적인 모양을 만든다!!";
			}
			elsif ($Element[8] eq 'FallingLeaves') {
				if ($Element[2] eq 'AllAct') {
					$EventDeco .= "$GuardianNameDeco에게서 <FONT COLOR=$Jcolor><B>의심스러운 낙엽</B></FONT>이 춤을 춘다!!";
				}
				elsif ($Element[2] eq 'Third') {
					$EventDeco .= "$Prophet는 <FONT COLOR=$Jcolor><B>의심스러운 낙엽</B></FONT>에게 정신이 빠졌다!!";
				}
				elsif ($Element[2] eq 'Miss') {
					$EventDeco .= "$Prophet는 <FONT COLOR=$Jcolor><B>의심스러운 낙엽</B></FONT>에게 현혹되지 않았다.";
				}
			}
		}
		elsif ($Element[7] eq 'Saturn') {
			if ($Element[8] eq 'Sand') {
				$EventDeco .= "$GuardianNameDeco는 <FONT COLOR=$Jcolor><B>모래</B></FONT>를 뿌렸다.";
			}
			elsif ($Element[8] eq 'Stone') {
				$EventDeco .= "$GuardianNameDeco는 <FONT COLOR=$Jcolor><B>돌</B></FONT>을 찼다!!";
			}
			elsif ($Element[8] eq 'Rock') {
				$EventDeco .= "$GuardianNameDeco는 <FONT COLOR=$Jcolor><B>바위</B></FONT>를 집어던졌다!!";
			}
			elsif ($Element[8] eq 'Hurl') {
				$EventDeco .= "$GuardianNameDeco는 <FONT COLOR=$Jcolor><B>몸통박치기</B></FONT>했다!!";
			}
			elsif ($Element[8] eq 'DiamondAx') {
				$EventDeco .= "$GuardianNameDeco는 <FONT COLOR=$Jcolor><B>다이아몬드액스</B>로 <B>공격!!</B></FONT>";
			}
		}
		elsif ($Element[7] eq 'Uranus') {
			if ($Element[8] eq 'Shine') {
				$EventDeco .= "$GuardianNameDeco는 <FONT COLOR=$Jcolor><B>빛났다!!</B></FONT>";
			}
			elsif ($Element[8] eq 'Electricity') {
				$EventDeco .= "$GuardianNameDeco는 <FONT COLOR=$Jcolor><B>뇌격</B></FONT>을 발했다!!";
			}
			elsif ($Element[8] eq 'Flash') {
				$EventDeco .= "$GuardianNameDeco는 <FONT COLOR=$Jcolor><B>섬광</B></FONT>을 냈다!!";
			}
			elsif ($Element[8] eq 'Light') {
				$EventDeco .= "$GuardianNameDeco는 <FONT COLOR=$Jcolor><B>天의 빛</B></FONT>이 내리쬔다!!";
			}
			elsif ($Element[8] eq 'LaserBeam') {
				if ($Element[2] eq 'AllAct') {
					$EventDeco .= "$GuardianNameDeco의 <FONT COLOR=$Jcolor><B>레이져빔 공격!!</B></FONT>";
				}
				elsif ($Element[2] eq 'Third') {
					$EventDeco .= "$Prophet는 <FONT COLOR=$Jcolor><B>레이져빔</B></FONT>이 직격했다!!";
				}
				elsif ($Element[2] eq 'Miss') {
					$EventDeco .= "$Prophet는 <FONT COLOR=$Jcolor><B>레이져빔</B></FONT>을 피했다.";
				}
			}
		}
		elsif ($Element[7] eq 'Neptune') {
			if ($Element[8] eq 'Ripple') {
				$EventDeco .= "$GuardianNameDeco는 $Prophet에게 <FONT COLOR=$Jcolor><B>잔물결의 소리</B></FONT>를 울리게했다.";
			}
			elsif ($Element[8] eq 'HPup50') {
				$EventDeco .= "$GuardianNameDeco는 $Prophet에게 <FONT COLOR=$Jcolor><B>예쁜 이슬</B></FONT>를 떨어트렸다.";
			}
			elsif ($Element[8] eq 'MPup50') {
				$EventDeco .= "$GuardianNameDeco는 $Prophet에게 <FONT COLOR=$Jcolor><B>좋은향기</B></FONT>를 주었다.";
			}
			elsif ($Element[8] eq 'HPup100') {
				$EventDeco .= "$GuardianNameDeco는 $Prophet에게 <FONT COLOR=$Jcolor><B>아주예쁜 이슬</B></FONT>를 떨어트렸다.";
			}
			elsif ($Element[8] eq 'MPup100') {
				$EventDeco .= "$GuardianNameDeco는 $Prophet에게 <FONT COLOR=$Jcolor><B>아주좋은향기</B></FONT>를 주었다.";
			}
		}
		elsif ($Element[7] eq 'Pluto') {
			if ($Element[8] eq 'DoNot') {
				$EventDeco .= "$GuardianNameDeco는 <FONT COLOR=$Jcolor>꿈적도 않는다.</FONT>";
			}
			elsif ($Element[8] eq 'DarkCloud') {
				$EventDeco .= "$GuardianNameDeco는 <FONT COLOR=$Jcolor><B>먹구름</B></FONT>을 눈으로 불렀다.";
			}
			elsif ($Element[8] eq 'Finger') {
				$EventDeco .= "$GuardianNameDeco는 <FONT COLOR=$Jcolor>손가락을 움직였다!!</FONT>";
			}
			elsif ($Element[8] eq 'Hand') {
				$EventDeco .= "$GuardianNameDeco는 <FONT COLOR=$Jcolor>손을 움직였다!!</FONT>";
			}
			elsif ($Element[8] eq 'Arm') {
				$EventDeco .= "$GuardianNameDeco는 <FONT COLOR=$Jcolor>팔을 들어올렸다!!</FONT>";
			}
		}
		elsif ($Element[7] eq 'Mirac') {
			if ($Element[8] eq 'Play') {
				$EventDeco .= "$GuardianNameDeco는 <FONT COLOR=$Jcolor>천진난만하게 뛰고있다.</FONT>";
			}
			elsif ($Element[8] eq 'Cheer') {
				$EventDeco .= "$GuardianNameDeco는 $Prophet를 위해서 <FONT COLOR=$Jcolor><B>응원의 노래</B></FONT>를 불렀다.";
			}
			elsif ($Element[8] eq 'Tornado') {
				$EventDeco .= "$GuardianNameDeco는 <FONT COLOR=$Jcolor><B>회오리바람</B></FONT>속에서 기분좋게 돌고있다.";
			}
			elsif ($Element[8] eq 'Tsunami') {
				if ($Element[2] eq 'AllAct') {
					$EventDeco .= "$GuardianNameDeco는 <FONT COLOR=$Jcolor><B>해일</B></FONT>에 타서 즐겁게 놀고있다.";
				}
				elsif ($Element[2] eq 'Third') {
					$EventDeco .= "$Prophet는 <FONT COLOR=$Jcolor><B>해일</B></FONT>에 습격당했다!!";
				}
				elsif ($Element[2] eq 'Miss') {
					$EventDeco .= "$Prophet는 <FONT COLOR=$Jcolor><B>해일</B></FONT>에서 벗어났다.";
				}
			}
			elsif ($Element[8] eq 'Sneeze') {
				$EventDeco .= "$GuardianNameDeco는....에 에 에 <FONT COLOR=$Jcolor SIZE=7>에엑엣!!! 취!!!!!</FONT>";
			}
		}
		elsif ($Element[7] eq 'Earth') {
			if ($Element[8] eq 'Sleep') {
				$EventDeco .= "$GuardianNameDeco는 <FONT COLOR=$Jcolor>는 자고 있다.</FONT>";
			}
		}
		
		if ($Element[3] && $Element[2] ne 'AllAct' && $Element[7] ne 'Venus' && $Element[7] ne 'Neptune') {
			$EventDeco .= " <FONT COLOR=$Jcolor><B>→(AT$Element[3])</B></FONT>";
		}
	}
	elsif ($Element[1] eq 'Rope') {
		if ($Element[2] eq 'GiveMany') {
			$EventDeco .= "$Prophet는 <B>태양신</B>에게서 많은 神器를 받았다!!";
		}
		elsif ($Element[2] eq 'AllHPmin') {
			$EventDeco .= "모든 예언자의 <B>HP</B>가 <FONT COLOR=$ColorDamage><B>10</B></FONT>이 되어버렸다.";
		}
		elsif ($Element[2] eq 'AllStrongWind') {
			$EventDeco .= "모든 예언자는 <B>强風病</B>에 걸렸다!!";
		}
		elsif ($Element[2] eq 'AllFog') {
			$EventDeco .= "모든 예언자는 <FONT COLOR=$ColorMercury><B>안개</B></FONT>에 둘러쌓였다!!";
		}
		elsif ($Element[2] eq 'AllIllusion') {
			$EventDeco .= "모든 예언자는 <FONT COLOR=$ColorJupiter><B>환각상태</B></FONT>에 빠졌다!!";
		}
		elsif ($Element[2] eq 'Equalize') {
			$EventDeco .= "모든 예언자의 <B>HP</B>, <B>MP</B>, <B>금</B>이 균등해졌다!!";
		}
		elsif ($Element[2] eq 'Jshuffle') {
			$EventDeco .= "모든 예언자의 神器가 적당하게 바뀌었다!!";
		}
		elsif ($Element[2] eq 'StatueVanish') {
			$EventDeco .= "신전에 배치된 신상이 모두 소멸했다!!";
		}
		elsif ($Element[2] eq 'Tub') {
			$EventDeco .= "하늘 높이서 가느다란 소리가 들린다.";
		}
		elsif ($Element[2] eq 'TubFall') {
			$EventDeco .= "하늘 높이서 <FONT COLOR=$ColorNormal SIZE=5><B>거대한 대야</B></FONT>가 떨어졌다!!";
		}
	}
	elsif ($Element[1] eq 'UseMiracle') {
		&Jdeco($Element[3]);
		&JdecoEvent;
		if (
			$Jdetail[$Element[2]] eq 'Fly' && $Element[4] ne 'Fog'
			 && (
			 	($in{'Mode'} ne 'Judgment' && $Element[0] != $X)
			 	 || ($in{'Mode'} eq 'Judgment' && $Element[0] != $JMprophet)
			 )
		) {
			if ($in{'Mode'} eq 'Judgment') {
				$EventDeco .= "누군가($Prophet)의 $JeventDeco가 빛나고 있다.";
			}
			else {
				$EventDeco .= "누군가의 $JeventDeco가 빛나고 있다.";
			}
		}
		else {
			$EventDeco .= "$Prophet의 $JeventDeco가 빛나고 있다.";
		}
		$TargetShowFlag = 0;
	}
	elsif ($Element[1] eq 'First') {
		$TargetShowFlag = 1;
		if ($Element[3] eq 'LostAT') {
			$LostATflag = 1;
			&Jdeco($Element[2]);
			&JdecoEvent;
			$EventDeco .= "$Prophet는 $JeventDeco";
			$EventDeco .= "$Jfirst[$Element[2]]";
			if ($Jsecond[$Element[2]]) {$TargetShowFlag = 0;}
		}
		elsif ($Jfirst[$Element[2]]) {
			&Jdeco($Element[2]);
			&JdecoEvent;
			$EventDeco .= "$Prophet는 $JeventDeco";
			$EventDeco .= "$Jfirst[$Element[2]]";
			if ($Jsecond[$Element[2]]) {$TargetShowFlag = 0;}
		}
		elsif ($Jdetail[$Element[2]] eq 'Devil') {
			$EventDeco .= "<B>$Jname[$Element[2]]</B>는 $Prophet를 <FONT COLOR=$ColorDamage><B>공격!!</B></FONT>";
		}
		
		elsif ($Jdetail[$Element[2]] eq 'Itazuraman') {
			$EventDeco .= "<B>$Jname[$Element[2]]</B>는 $Prophet<FONT COLOR=$ColorProphet><B>신전</B></FONT>에서 <B>도둑질</B>을 하고 도망갔다.";
		}
		elsif ($Jdetail[$Element[2]] eq 'PowderFairy') {
			$EventDeco .= "<B>$Jname[$Element[2]]</B>는 $Prophet에게 <B>신비한가루</B>를 뿌리고 어디론가 가버렸다.";
		}
		elsif ($Jkind[$Element[2]] eq 'Pray') {
			&Jdeco($Element[2]);
			&JdecoEvent;
			$EventDeco = "$Prophet는 $JeventDeco로 <B>태양신</B>에게 기도했다.";
			$TargetShowFlag = 0;
		}
		elsif ($Jkind[$Element[2]] eq 'Sell') {
			&Jdeco($Element[2]);
			&JdecoEvent;
			$EventDeco .= "$Prophet이 $JeventDeco에게 ";
			&Jdeco($Element[3]);
			&JdecoEvent;
			$EventDeco .= "$JbuyDeco를 강제로 팔았다.";
		}
		elsif ($Jkind[$Element[2]] eq 'AllS' || $Jkind[$Element[2]] eq 'WeaponS' || $Jkind[$Element[2]] eq 'ProtectorS' || $Jkind[$Element[2]] eq 'SundryS') {
			&Jdeco($Element[2]);
			&JdecoEvent;
			$EventDeco .= "$Prophet는 $JeventDeco에게 ";
			&Jdeco($Element[3]);
			&JdecoEvent;
			$EventDeco .= "$JbuyDeco를 바쳤다.";
		}
		elsif ($Jmp[$Element[2]]) {
			&Jdeco($Element[2]);
			&JdecoEvent;
			if (
				$Jdetail[$Element[2]] eq 'Fly' && $Element[4] ne 'Fog'
				 && (
				 	($in{'Mode'} ne 'Judgment' && $Element[0] != $X)
				 	 || ($in{'Mode'} eq 'Judgment' && $Element[0] != $JMprophet)
				 )
			) {
				if ($in{'Mode'} eq 'Judgment') {
					$EventDeco .= "누군가($Prophet)가<B>기적</B>$JeventDeco을 믿었다.";
				}
				else {
					$EventDeco .= "누군가가<B>기적</B>$JeventDeco을 믿었다.";
				}
			}
			else {
				$EventDeco .= "$Prophet는 <B>기적</B>$JeventDeco을 믿었다.";
			}
			
			if (
				$AddMiracleNews
				 || $Jkind[$Element[2]] eq 'AllAct'
				 || $Jkind[$Element[2]] eq 'Revive'
				 || $Jdetail[$Element[2]] eq 'ATtimes'
			) {
				$TargetShowFlag = 0;
			}
		}
		elsif ($Jkind[$Element[2]] eq 'Weapon') {
			&Jdeco($Element[2]);
			&JdecoEvent;
			if (
				$Jdetail[$Element[2]] eq 'Fly' && $Element[4] ne 'Fog'
				 && (
				 	($in{'Mode'} ne 'Judgment' && $Element[0] != $X)
				 	 || ($in{'Mode'} eq 'Judgment' && $Element[0] != $JMprophet)
				 )
			) {
				if ($in{'Mode'} eq 'Judgment') {
					$EventDeco .= "멀리서 누군가($Prophet)가 $JeventDeco로 <FONT COLOR=$ColorAttack><B>공격!!</B></FONT>";
				}
				else {
					$EventDeco .= "멀리서 누군가가 $JeventDeco로 <FONT COLOR=$ColorAttack><B>공격!!</B></FONT>";
				}
			}
			else {
				$EventDeco .= "$Prophet가 $JeventDeco로 <FONT COLOR=$ColorAttack><B>공격!!</B></FONT>";
			}
			
			if ($Element[3] ne "") {$EventDeco .= " <FONT COLOR=$Jcolor><B>→(AT$Element[3])</B></FONT>";}
			else {$TargetShowFlag = 0;}
		}
		elsif ($Jkind[$Element[2]] eq 'Jug') {
			&Jdeco($Element[2]);
			&JdecoEvent;
			$EventDeco .= "$Prophet는 $JeventDeco에게 <B>$Element[3]G</B>를 넣었다.";
		}
		elsif ($Jkind[$Element[2]] eq 'Usu') {
			&Jdeco($Element[2]);
			&JdecoEvent;
			$EventDeco .= "$Prophet의 $JeventDeco가 산산히 부서졌다.";
		}
		else {
			&Jdeco($Element[2]);
			&JdecoEvent;
			$EventDeco .= "$Prophet는 $JeventDeco을 사용했다";
			if ($Jkind[$Element[2]] eq 'Exchange' && $Target && !$MyCondition[3]) {
				$EventDeco .= " (HP$Element[3], MP$Element[4], $Element[5]G)→(HP$Element[6], MP$Element[7], $Element[8]G)";
			}
			if ($Jsecond[$Element[2]]) {$TargetShowFlag = 0;}
		}
	}
	elsif ($Element[1] eq 'Defense') {
		$DefenseEventFlag = 1;
		&Jdeco($Element[2]);
		&JdecoEvent;
		$DefenseEventFlag = 0;
		$EventDeco .= "$Prophet는 $JeventDeco로 <FONT COLOR=$ColorDefense><B>방어!!</B></FONT>";
	}
	elsif ($Element[1] eq 'SoloDF') {
		if ($Jmp[$Element[2]]) {
			&Jdeco($Element[2]);
			&JdecoEvent;
			$EventDeco .= "$Prophet는 <B>기적</B>$JeventDeco을 믿었다.";
			$TargetShowFlag = 0;
		}
		elsif ($Jdetail[$Element[2]] eq 'SuperM' || $Jdetail[$Element[2]] eq 'WeaponM' || $Jdetail[$Element[2]] eq 'MiracleM') {
			&Jdeco($Element[2]);
			&JdecoEvent;
			$EventDeco .= "$Prophet는 $JeventDeco로 <FONT COLOR=$ColorDefense><B>방어!!</B></FONT>";
			if ($Jdetail[$Element[2]] eq 'MiracleM' || $Element[5] eq 'Miracle') {
				$EventDeco .= " 기적을 반사했다.";
			}
			else {
				$EventDeco .= " 공격을 반사했다.";
			}
		}
		elsif ($Jdetail[$Element[2]] eq 'WeaponR' && $Jfree[$Element[2]] == 50) {
			&Jdeco($Element[2]);
			&JdecoEvent;
			$EventDeco .= "$Prophet을 조종하는 $JeventDeco의 움직임을 잡아서 일섬에 날려버렸다!!";
		}
		else {
			&Jdeco($Element[2]);
			&JdecoEvent;
			$EventDeco .= "$Prophet는 $JeventDeco로 <FONT COLOR=$ColorDefense><B>방어!!</B></FONT>";
			if ($Jdetail[$Element[2]] eq 'ATabsorb') {
				$EventDeco .= " 공격을 흡수했다!!";
			}
			elsif ($Jdetail[$Element[2]] eq 'WeaponR') {
				$EventDeco .= " 공격을 날려버렸다!!";
			}
			elsif ($Jdetail[$Element[2]] eq 'MiracleR') {
				$EventDeco .= " 기적을 날려버렸다!!";
			}
			elsif ($Jdetail[$Element[2]] eq 'WeaponB') {
				$EventDeco .= " 공격을 막았다!!";
			}
			elsif ($Jdetail[$Element[2]] eq 'MiracleB') {
				$EventDeco .= " 기적을 막았다!!";
			}
		}
	}
	elsif ($Element[1] eq 'Second') {
		if ($Jsecond[$Element[2]]) {
			$EventDeco .= "$Jsecond[$Element[2]]";
			if ($Jkind[$Element[2]] eq 'TargetAct' || $Jdetail[$Element[2]] eq 'TargetAct') {
				if ($Element[3] ne "") {
					&Jdeco($Element[2]);
					$EventDeco .= " <FONT COLOR=$Jcolor><B>→(AT$Element[3])</B></FONT>";
				}
				$TargetShowFlag = 1;
			}
			elsif (
				$Jkind[$Element[2]] eq 'Ring'
				 && $Jdetail[$Element[2]] ne 'AllAct' && $Jdetail[$Element[2]] ne 'HPup'
				 && $Jdetail[$Element[2]] ne 'MPup' && $Jdetail[$Element[2]] ne 'GPup'
			) {
				$TargetShowFlag = 1;
			}
		}
		elsif ($Jdetail[$Element[2]] eq 'Itazuraman') {
			$EventDeco .= "<B>$Jname[$Element[2]]</B>는 $Prophet의 <B>돈</B>을 빼앗아 도망갔다.";
		}
		elsif ($Jkind[$Element[2]] eq 'Exchange') {
			$EventDeco .= "$Prophet의 (HP$Element[3], MP$Element[4], $Element[5]G)  (HP$Element[6], MP$Element[7], $Element[8]G)로 <B>환전</B>되었다.";
		}
		elsif ($Jkind[$Element[2]] eq 'Buy') {
			&Jdeco($Element[3]);
			&JdecoEvent;
			$EventDeco .= "$Prophet의 $JbuyDeco가 선택되었다.";
		}
		elsif ($Jkind[$Element[2]] eq 'Release') {
			&Jdeco($Element[3]);
			&JdecoEvent;
			$EventDeco .= "$JbuyDeco가 강하게 빛나기 시작한다.";
		}
		elsif ($Jkind[$Element[2]] eq 'Revive') {
			$EventDeco .= "아니?!  "."$Prophet는 <B>HP$Jpoint[$Element[2]]</B>로 <B>부활</B>했다!!";
		}
		elsif ($Jdetail[$Element[2]] eq 'Broom') {
			if ($Element[3]) {$EventDeco .= "$Prophet의 神器가 날아갔다.";}
			else {$EventDeco .= "$Prophet는 아무것도 날아가지 않았다.";}
		}
		elsif ($Jdetail[$Element[2]] eq 'Soap') {
			if ($Element[3]) {$EventDeco .= "$Prophet는 다리를 잡혀서 넘어졌다.";}
			else {$EventDeco .= "$Prophet는 다리를 잡혀서 넘어졌지만 아무것도 잃어버리지 않았다.";}
		}
		elsif ($Jdetail[$Element[2]] eq 'AddAttribute') {
			&Jdeco($Element[2]);
			&JdecoEvent;
			$EventDeco .= "그리고 $JeventDeco의 마력이 공격의 속성을 변화시킨다!!";
			$EventDeco .= " <FONT COLOR=$Jcolor><B>→(AT$Element[3])</B></FONT>";
			$TargetShowFlag = 1;
		}
		elsif ($Jdetail[$Element[2]] eq 'ATtimes') {
			$EventDeco .= "성스러운 오오라가 神器를 감싸여 공격력이 증폭했다!!";
			$EventDeco .= " <FONT COLOR=$Jcolor><B>→(AT$Element[3])</B></FONT>";
			$TargetShowFlag = 1;
		}
		elsif ($Jdetail[$Element[2]] eq 'ATup') {
			$ATupFlag = 1;
			&Jdeco($Element[2]);
			&JdecoEvent;
			$ATupFlag = 0;
			$EventDeco .= "더욱이 $JeventDeco의 효과로 공격력이 상승했다!!";
			if ($Element[3]) {
				$EventDeco .= " <FONT COLOR=$Jcolor><B>→(AT$Element[3])</B></FONT>";
				$TargetShowFlag = 1;
			}
		}
		elsif ($Jdetail[$Element[2]] eq 'MagicalW' || $Jdetail[$Element[2]] eq 'MagicalRod') {
			&Jdeco($Element[2]);
			$EventDeco .= "기적의 힘과 神器가 공명한다!!";
			if ($Jdetail[$Element[2]] eq 'MagicalW') {
				$EventDeco .= " <FONT COLOR=$Jcolor><B>$Jname[$Element[2]]</B></FONT>의 공격력이 두배가 되었다!!";
			}
			if ($Element[3]) {
				$EventDeco .= "　<FONT COLOR=$Jcolor><B>→ ( AT$Element[3] ) </B></FONT>";
				$TargetShowFlag = 1;
			}
		}
		elsif ($Jdetail[$Element[2]] eq 'MagicalP') {
			&Jdeco($Element[2]);
			$EventDeco .= "기적의 힘과 神器가 공명한다!!";
			$EventDeco .= " <FONT COLOR=$Jcolor><B>$Jname[$Element[2]]</B></FONT>의 방어력이 두배가 되었다!!";
			$TargetShowFlag = 1;
		}
		else {
			$BlankFlag = 1;
		}
	}
	elsif ($Element[1] eq 'Third') {
		if ($Jthird[$Element[2]]) {
			&Jdeco($Element[2]);
			$EventDeco .= "$Prophet";
			$EventDeco .= "$Jthird[$Element[2]]";
			$EventDeco .= " <FONT COLOR=$Jcolor><B>→(AT$Element[3])</B></FONT>";
		}
		elsif ($Jdetail[$Element[2]] eq 'Itazuraman') {
			$EventDeco .= "<B>$Jname[$Element[2]]</B>가 $Prophet의 뒤에서 <FONT SIZE=7>「 왓!!! 」</FONT>하고 놀래켰다...";
		}
		elsif ($Jkind[$Element[2]] eq 'Release') {
			&Jdeco($Element[3]);
			&JdecoEvent;
			$EventDeco .= "神器에 종속한 神이 그 힘을 해방한다!!";
		}
		elsif ($Jdetail[$Element[2]] eq 'SuperM' || $Jdetail[$Element[2]] eq 'WeaponM' || $Jdetail[$Element[2]] eq 'MiracleM') {
			if ($detail[$Element[2]] eq 'MiracleM' || $Element[5] eq 'Miracle') {
				$EventDeco .= "반사된 기적이 $Prophet을 덮친다!!";
			}
			else {
				$EventDeco .= "반사된 공격이 $Prophet을 덮친다!!";
			}
			
			if ($Element[3]) {
				if ($Element[7] ne 'Mirac') {
					&JcolorCheck($Element[4]);
				}
				else {
					$Jcolor = $ColorNormal;
				}
				$EventDeco .= " <FONT COLOR=$Jcolor><B>→(AT$Element[3])</B></FONT>";
			}
		}
		elsif ($Jdetail[$Element[2]] eq 'WeaponR' || $Jdetail[$Element[2]] eq 'MiracleR') {
			if ($detail[$Element[2]] eq 'MiracleR' || $Element[5] eq 'Miracle') {
				$EventDeco .= "날려간 기적이 $Prophet을 습격한다!!";
			}
			else {
				$EventDeco .= "날려간 공격이 $Prophet을 습격한다!!";
			}
			if ($Element[3]) {
				if ($Element[7] ne 'Mirac') {
					&JcolorCheck($Element[4]);
				}
				else {
					$Jcolor = $ColorNormal;
				}
				$EventDeco .= " <FONT COLOR=$Jcolor><B>→(AT$Element[3])</B></FONT>";
			}
		}
	}
	elsif ($Element[1] eq 'Miss') {
		$TargetShowFlag = 0;
		if ($Jmiss[$Element[2]]) {
			$EventDeco .= "$Prophet";
			$EventDeco .= "$Jmiss[$Element[2]]";
		}
		elsif ($Jdetail[$Element[2]] eq 'Itazuraman') {
			$EventDeco .= "<B>$Jname[$Element[2]]</B>는 $Prophet에게 장난칠려고 했으나 실패해서 아쉬운 표정으로 사라졌다.";
		}
		elsif ($Jkind[$Element[2]] eq 'Buy') {
			$EventDeco .= "그러나 $Prophet는 아무것도 사지 않았다.";
		}
		elsif ($Jkind[$Element[2]] eq 'Release') {
			&Jdeco($Element[3]);
			&JdecoEvent;
			$EventDeco .= "神器는 산산히 부서졌다.";
		}
		else {
			$EventDeco .= "그러나 공격은 <FONT COLOR=$ColorProphet><B>$Name[$Element[3]]</B></FONT>에게서 빗나가고 말았다.";
		}
	}
	elsif ($Element[1] eq 'Mirror') {
		$BlankFlag = 1;
	}
	
	#돈흡수
	if (
		($Element[1] eq 'First' || $Element[1] eq 'Second' || $Element[1] eq 'Mirror' || $Element[1] eq 'GuardianAct')
		 && ($Jdetail[$Element[2]] eq 'GPabsorb' || $Element[2] eq 'GPabsorb')
		 && ($Element[3] ne "" || ($Element[2] ne 'GPabsorb' && $Jpoint[$Element[2]]))
	) {
		if ($Element[3]) {
			$AbsorbGP = $Element[3];
		}
		else {
			$AbsorbGP = $Jpoint[$Element[2]];
		}
		$EventDeco .= "?<FONT COLOR=$ColorNormal><B>→($AbsorbGP".'G)</B></FONT>';
	}
	
	#타겟 표시
	if (!$EatPresentFlag && $TargetShowFlag && $TargetShow) {
		if ($TargetShow eq 'Secret') {
			$EventDeco .= "  ＞<FONT COLOR=$ColorProphet><B>？？？</B></FONT>";
		}
		elsif ($TargetShow ne 'No') {
			$EventDeco .= "  ＞<FONT COLOR=$ColorProphet><B>$Name[$TargetShow]</B></FONT>";
		}
	}
}

#?둉봏귩몧륕
sub YearDeco {
	if ($YDcheck % 2 == 0) {
		$YDcolor = $ColorEraA;
	}
	else {
		$YDcolor = $ColorEraB;
	}
	
	if ($_[0] < 0) {$CountDeco = '0000';}
	elsif ($_[0] < 10) {$CountDeco = '000'."$_[0]";}
	elsif ($_[0] < 100) {$CountDeco = '00'."$_[0]";}
	elsif ($_[0] < 1000) {$CountDeco = '0'."$_[0]";}
	else {$CountDeco = $_[0];}
	
	$YearDeco = "<FONT COLOR=\"$YDcolor\"><B>GF$CountDeco : </B></FONT>";
}

#?밶됪뽋궸?렑궠귢귡긦깄?긚
sub ShrineNews {
	$ShrineNewsFlag = 1;
	if ($_[0]) {
		&NewsDeco($GFyear, $_[0]);
		$ShrineNews .= $NewsDeco;
		$EatNews = "";
	}
	
	if ($LeaveEatFlag) {
		$ShrineNews = "<B>미소화의 행동이 있었기 때문에 공격턴이 취소되었습니다.</B><BR>\n<BR>\n"."$ShrineNews";
		$LeaveEatFlag = 0;
	}
}

#-------------
#선물
#-------------
#긵깒?깛긣귩몼귡
sub SendPresent {
	#럊뾭궢궫?딇궻붥뜂귩롦벦
	if ($in{'Act1'} <= 16) {
		$UseJ = $MyJ[$in{'Act1'}];
		
		#륷궢궘몴귩먠뭫궥귡궴뚀궋몴궴떉궑븿궼뤑궑귡
		if ($Jkind[$UseJ] eq 'AllS' || $Jkind[$UseJ] eq 'WeaponS' || $Jkind[$UseJ] eq 'ProtectorS' || $Jkind[$UseJ] eq 'SundryS') {
			foreach (1..4) {
				if ($MyStatue[$_]) {&JnowUseAdd($MyStatue[$_]);}
			}
			@MyStatue = ();
		}
	}
	elsif ($in{'Act1'} <= 22) {
		$UseJ = $MyM[$in{'Act1'} - 16];
	}
	elsif ($in{'Act1'} == 23) {
		$UseJ = $MyStatue[0];
	}
	else {
		&Error;
	}
	#걏딣귡걐귩럊궯궫궴궖궼븉맫?긃긞긏
	if ($Jkind[$UseJ] eq 'Pray' && !($AllIllusionMode && $MyCondition[3])) {
		if ($MyJ[16]) {&Error;}
		foreach (@MyJ) {
			if ($Jkind[$_] eq 'Weapon') {&Error;}
		}
	}
	
	if ($in{'Act2'} <= 16) {$UseJ2 = $MyJ[$in{'Act2'}];}
	else {$UseJ2 = $MyM[$in{'Act2'} - 16];}
	if ($in{'Act3'} <= 16) {$UseJ3 = $MyJ[$in{'Act3'}];}
	else {$UseJ3 = $MyM[$in{'Act3'} - 16];}
	if ($in{'Act4'} <= 16) {$UseJ4 = $MyJ[$in{'Act4'}];}
	else {$UseJ4 = $MyM[$in{'Act4'} - 16];}
	if ($in{'Act5'} <= 16) {$UseJ5 = $MyJ[$in{'Act5'}];}
	else {$UseJ5 = $MyM[$in{'Act5'} - 16];}
	
	#딉먘럊뾭?딇궻룋렃귩?긃긞긏
	&UseMiracleCheck;
	
	#뼳
	if ($MyCondition[1] && $in{'Target'} != $X) {
		do {
			$Target = &RandomPlayer;
		}
		while ($Target == $X);
		
		$TargetShow = 'Secret';
	}
	#뙳둶
	$ThrowFlag = 0;
	if ($MyCondition[3]) {
		#렔멢렊뾀
		if (!$AllIllusionMode && rand(100) < 30) {
			$MyCondition[3] = 0;
			&ShrineNews("$X,CureIllusion");
			&NewsChange("$X,CureIllusion");
		}
		#뙳둶뛱벍
		else {
			$IllusionNews = "$X,IllusionAT";
			$SendPresent .= ":$IllusionNews";
			
			#럊뾭궳궖귡?딇릶궕궇귡궔?긃긞긏
			$CanUseFlag = 0;
			$CanUseStatue = 0;
			foreach (@MyJ) {
				if (
					$_
					 && ($Jmp[$_] <= $MP[$X] || $UMJ[0])
					 && ($Jtype[$_] eq 'OneMore' || $Jtype[$_] eq 'Solo' || $Jtype[$_] eq 'NormalW' || $Jtype[$_] eq 'SoloAdd')
				) {
					$CanUseFlag = 1;
					last;
				}
			}
			if (!$CanUseFlag) {
				foreach (@MyM) {
					if ($Jkind[$_] eq 'Release') {
						foreach $I (@MyJ) {
							if (
								($Jattribute[$I] || $Jkind[$I] eq 'Mirac' || $Jdetail[$I] eq 'Earth')
								 && (
									$Jprice[$I] <= $MP[$X]
									 || $UMJ[1]
									 || ($UMJ[0] && $UMJ[0] != $I)
								)
							) {
								$CanUseFlag = 1;
								last;
							}
						}
					}
					elsif (
						$_
						 && ($Jmp[$_] <= $MP[$X] || $UMJ[0])
						 && ($Jtype[$_] eq 'OneMore' || $Jtype[$_] eq 'Solo' || $Jtype[$_] eq 'NormalW' || $Jtype[$_] eq 'SoloAdd')
					) {
						$CanUseFlag = 1;
						last;
					}
				}
			}
			if ($MyStatue[0]) {
				foreach (1..16) {
					if (
						$MyJ[$_]
						 && (
							$Jkind[$MyStatue[0]] eq 'AllS'
							 || ($Jkind[$MyStatue[0]] eq 'WeaponS' && $Jkind[$MyJ[$_]] eq 'Weapon')
							 || ($Jkind[$MyStatue[0]] eq 'ProtectorS' && $Jmp[$MyJ[$_]] == 0 && ($Jkind[$MyJ[$_]] eq 'Shield' || $Jkind[$MyJ[$_]] eq 'Armor' || $Jkind[$MyJ[$_]] eq 'Helm' || $Jkind[$MyJ[$_]] eq 'Gauntlet' || $Jkind[$MyJ[$_]] eq 'Boots' || $Jkind[$MyJ[$_]] eq 'Ring' || $Jkind[$MyJ[$_]] eq 'OtherP' || $Jkind[$MyJ[$_]] eq 'SoloP'))
							 || ($Jkind[$MyStatue[0]] eq 'SundryS' && !($Jmp[$MyJ[$_]] == 0 && ($Jkind[$MyJ[$_]] eq 'Weapon' || $Jkind[$MyJ[$_]] eq 'Shield' || $Jkind[$MyJ[$_]] eq 'Armor' || $Jkind[$MyJ[$_]] eq 'Helm' || $Jkind[$MyJ[$_]] eq 'Gauntlet' || $Jkind[$MyJ[$_]] eq 'Boots' || $Jkind[$MyJ[$_]] eq 'Ring' || $Jkind[$MyJ[$_]] eq 'OtherP' || $Jkind[$MyJ[$_]] eq 'SoloP')))
						)
					) {
						$CanUseFlag = 1;
						$CanUseStatue = 1;
						last;
					}
				}
			}
			
			#럊뾭궳궖귡?딇궔귞깋깛??궳덇궰멗귆
			if ($CanUseFlag) {
				do {
					$I = int(rand(23)) + 1;
					$in{'Act1'} = $I;
					if ($I <= 16) {
						$UseJ = $MyJ[$I];
					}
					elsif ($I <= 22) {
						$UseJ = $MyM[$I - 16];
						if ($Jkind[$UseJ] eq 'Release') {
							$K = 0;
							foreach (@MyJ) {
								if (
									($Jattribute[$_] || $Jkind[$_] eq 'Mirac' || $Jdetail[$_] eq 'Earth')
									 && (
										$Jprice[$_] <= $MP[$X]
										 || $UMJ[1]
										 || ($UMJ[0] && $UMJ[0] != $_)
									)
								) {
									$K++;
								}
							}
							if ($K == 0) {
								$UseJ = "";
							}
						}
					}
					elsif ($CanUseStatue) {
						$UseJ = $MyStatue[0];
					}
					else {
						$UseJ = "";
					}
				}
				while (
					!$UseJ
					 || ($Jmp[$UseJ] > $MP[$X] && !$UMJ[0])
					 || !($Jtype[$UseJ] eq 'OneMore' || $Jtype[$UseJ] eq 'Solo' || $Jtype[$UseJ] eq 'NormalW' || $Jtype[$UseJ] eq 'SoloAdd')
				);
			}
			#뻞뗰궢궔궶궋뤾뜃궼걏딣귡걐
			elsif (!$MyJ[16]) {
				$in{'Act1'} = 16;
				$UseJ = 0;
			}
			#뻞뗰궢궔궶궘궲룋렃?딇궕뼖?깛궻궴궖궼돺궔덇궰뺳귟뱤궛귡
			else {
				$I = int(rand(16)) + 1;
				$in{'Act1'} = $I;
				$UseJ = $MyJ[$I];
				
				$ThrowFlag = 1;
			}
			
			#돀뺴뛘똼궻뤾뜃궼뙳둶륃뺪귩덨궥
			if ($Jdetail[$UseJ] eq 'Fly') {
				&ShrineNews($SendPresent);
				$SendPresent = "";
			}
			
			#몴
			if ($Jkind[$UseJ] eq 'AllS' || $Jkind[$UseJ] eq 'WeaponS' || $Jkind[$UseJ] eq 'ProtectorS' || $Jkind[$UseJ] eq 'SundryS') {
				@Kcheck = ();
				$K = 0;
				foreach (1..16) {
					if (
						$MyJ[$_]
						 && (
							$Jkind[$UseJ] eq 'AllS'
							 || ($Jkind[$UseJ] eq 'WeaponS' && $Jkind[$MyJ[$_]] eq 'Weapon')
							 || ($Jkind[$UseJ] eq 'ProtectorS' && $Jmp[$MyJ[$_]] == 0 && ($Jkind[$MyJ[$_]] eq 'Shield' || $Jkind[$MyJ[$_]] eq 'Armor' || $Jkind[$MyJ[$_]] eq 'Helm' || $Jkind[$MyJ[$_]] eq 'Gauntlet' || $Jkind[$MyJ[$_]] eq 'Boots' || $Jkind[$MyJ[$_]] eq 'Ring' || $Jkind[$MyJ[$_]] eq 'OtherP' || $Jkind[$MyJ[$_]] eq 'SoloP'))
							 || ($Jkind[$UseJ] eq 'SundryS' && !($Jmp[$MyJ[$_]] == 0 && ($Jkind[$MyJ[$_]] eq 'Weapon' || $Jkind[$MyJ[$_]] eq 'Shield' || $Jkind[$MyJ[$_]] eq 'Armor' || $Jkind[$MyJ[$_]] eq 'Helm' || $Jkind[$MyJ[$_]] eq 'Gauntlet' || $Jkind[$MyJ[$_]] eq 'Boots' || $Jkind[$MyJ[$_]] eq 'Ring' || $Jkind[$MyJ[$_]] eq 'OtherP' || $Jkind[$MyJ[$_]] eq 'SoloP')))
						)
					) {
						$Kcheck[$_] = 1;
						$K++;
					}
				}
				
				if ($K >= 1) {
					$TargetShow = 'No';
					
					if ($K > 4) {$K = 4;}
					$K = int(rand($K)) + 2;
					foreach (2..5) {
						if ($_ <= $K) {
							do {
								$J = int(rand(16)) + 1;
								$in{"Act$_"} = $J;
								
								$KcheckFlag = 0;
								if ($Kcheck[$J]) {
									$Kcheck[$J] = 0;
									$KcheckFlag = 1;
								}
							}
							while (!$MyJ[$J] || $J == $I || !$KcheckFlag);
						}
						else {
							$in{"Act$_"} = "";
						}
					}
					
					$UseJ2 = $MyJ[$in{'Act2'}];
					$UseJ3 = $MyJ[$in{'Act3'}];
					$UseJ4 = $MyJ[$in{'Act4'}];
					$UseJ5 = $MyJ[$in{'Act5'}];
				}
				else {
					$ThrowFlag = 1;
				}
			}
			#봽귡
			elsif ($Jkind[$UseJ] eq 'Sell') {
				$K = @MyJ;
				if ($K >= 3) {
					$Target = &RandomPlayer;
					$TargetShow = 'Secret';
					
					do {
						$J = int(rand(16)) + 1;
						$in{'Act2'} = $J;
						$UseJ2 = $MyJ[$J];
					}
					while (!$UseJ2 || $J == $I);
				}
				else {
					$ThrowFlag = 1;
				}
				
				$in{'Act3'} = ""; $UseJ3 = "";
				$in{'Act4'} = ""; $UseJ4 = "";
				$in{'Act5'} = ""; $UseJ5 = "";
			}
			#곢됶뺳곣
			elsif ($Jkind[$UseJ] eq 'Release') {
				@Kcheck = ();
				$K = 0;
				foreach (@MyJ) {
					if (
						($Jattribute[$_] || $Jkind[$_] eq 'Mirac' || $Jdetail[$_] eq 'Earth')
						 && (
						 	$Jprice[$_] <= $MP[$X]
						 	 || $UMJ[1]
						 	 || ($UMJ[0] && $UMJ[0] != $_)
						 )
					) {
						$Kcheck[$_] = 1;
						$K++;
					}
				}
				
				if ($K >= 1) {
					$Target = $X;
					$TargetShow = 'No';
					
					do {
						$J = int(rand(16)) + 1;
						$in{'Act2'} = $J;
						$UseJ2 = $MyJ[$J];
						
						$KcheckFlag = 0;
						if ($Kcheck[$J]) {
							$Kcheck[$J] = 0;
							$KcheckFlag = 1;
						}
					}
					while (!$UseJ2 || $J == $I || !$KcheckFlag);
					
					if ($MP[$X] < $Jprice[$UseJ2] || rand(2) < 1) {
						$in{'MP'} = 0;
					}
					else {
						$in{'MP'} = $Jprice[$UseJ2];
					}
				}
				else {
					$ThrowFlag = 1;
				}
				
				$in{'Act3'} = ""; $UseJ3 = "";
				$in{'Act4'} = ""; $UseJ4 = "";
				$in{'Act5'} = ""; $UseJ5 = "";
			}
			else {
				$in{'Act2'} = ""; $UseJ2 = "";
				$in{'Act3'} = ""; $UseJ3 = "";
				$in{'Act4'} = ""; $UseJ4 = "";
				$in{'Act5'} = ""; $UseJ5 = "";
				
				#뿼뫶
				if ($Jkind[$UseJ] eq 'Exchange') {
					$Target = 0;
					
					#뿼뫶뚣궻HP갂MP갂GP궻뭠귩깋깛??궸멗귆
					$I = $TotalP / 10;
					$J = 0;
					foreach (1..$I) {
						$J += $_;
					}
					
					$CaseP = int(rand($J)) + 1;
					
					$K = 0;
					foreach (1..$J) {
						$CaseP -= $_;
						if ($CaseP <= 0) {last;}
						else {$K++;}
					}
					
					$in{'HP'} = ($I - $K) * 10;
					if ($CaseP < 0) {
						$in{'MP'} = $CaseP * (-10);
					}
					else {			#$CaseP궕0궻궴궖$in{'MP'}궕-0궸궶귡궞궴귩뻞궙
						$in{'MP'} = 0;
					}
					$in{'GP'} = $TotalP - $in{'HP'} - $in{'MP'};
				}
				elsif ($Jtype[$UseJ] ne 'OneMore' && $Jtype[$UseJ] ne 'Solo' && $Jtype[$UseJ] ne 'NormalW' && $Jtype[$UseJ] ne 'SoloAdd') {
					$ThrowFlag = 1;
				}
				#걏딣귡걐댥둖
				elsif ($Jkind[$UseJ] ne 'Pray') {
					if ($Jpoint[$UseJ] < 1000 && $Jfree[$UseJ] < 1000) {
						$Target = &RandomPlayer;
						$TargetShow = 'Secret';
					}
					if ($Jmp[$UseJ] > 0) {
						if ($MP[$X] < $Jmp[$UseJ] || rand(2) < 1) {
							$in{'MP'} = 0;
						}
						else {
							$in{'MP'} = $Jmp[$UseJ];
						}
					}
					if ($Jdetail[$UseJ] eq 'MagicalW') {
						if ($MP[$X] < $Jfree[$UseJ] || rand(2) < 1) {
							$in{'MP'} = 0;
						}
						else {
							$in{'MP'} = $Jfree[$UseJ];
						}
					}
					elsif ($Jdetail[$UseJ] eq 'MagicalRod') {
						$in{'MP'} = int(rand($MP[$X] / 10 + 1)) * 10;
					}
					if ($Jkind[$UseJ] eq 'Jug') {
						$in{'GP'} = int(rand($GP[$X] / 10 + 1)) * 10;
					}
				}
				
				#뼰뫌맜븧딇
				if ($Jtype[$UseJ] eq 'NormalW') {
					$K = 0;
					foreach (@MyJ) {
						if (
							($Jtype[$_] eq 'SoloAdd' || $Jtype[$_] eq 'Add' || $Jtype[$_] eq 'Adds')
							 && ($Jmp[$_] <= $MP[$X] || $UMJ[0])
						) {
							$K++;
						}
					}
					foreach (@MyM) {
						if (
							($Jtype[$_] eq 'SoloAdd' || $Jtype[$_] eq 'Add' || $Jtype[$_] eq 'Adds')
							 && ($Jmp[$_] <= $MP[$X] || $UMJ[0])
						) {
							$K++;
						}
					}
					
					foreach (2..5) {
						if ($K == 0 || rand(2) < 1) {
							$I = $_ - 1;
							last;
						}
						else {
							do {
								$J = int(rand(22)) + 1;
								$in{"Act$_"} = $J;
								if ($J <= 16) {
									$AddJ[$_] = $MyJ[$J];
								}
								else {
									$AddJ[$_] = $MyM[$J - 16];
								}
							}
							while (
								!($Jtype[$AddJ[$_]] eq 'SoloAdd' || $Jtype[$AddJ[$_]] eq 'Add' || $Jtype[$AddJ[$_]] eq 'Adds')
								 || !($Jmp[$AddJ[$_]] <= $MP[$X] || $UMJ[0])
							);
							$K--;
							$I = $_;
						}
						if ($Jtype[$AddJ[$_]] eq 'SoloAdd' || $Jtype[$AddJ[$_]] eq 'Add') {
							last;
						}
					}
					
					if ($I >= 2) {
						$UseJ2 = $AddJ[2];
						if ($I >= 3) {
							$UseJ3 = $AddJ[3];
							if ($I >= 4) {
								$UseJ4 = $AddJ[4];
								if ($I >= 5) {
									$UseJ5 = $AddJ[5];
								}
							}
						}
					}
				}
			}
		}
	}
	
	#맫륂
	if ($TargetShow ne 'Secret') {
		$Target = $in{'Target'};
		if (!($HP[$Target] > 0)) {&Error;}
	}
	
	#딣귡
	if ($Jkind[$UseJ] eq 'Pray') {
		$Target = $X;
	}
	
	#궇귆궶궋긌긨
	if ($Jdetail[$UseJ] eq 'Kine') {
		$Usu = 0;
		@Player = sort by_HP (@Player);
		foreach (@Player) {
			if ($HP[$_] > 0) {
				@YourJ = split(/,/, $Jingi[$_]);
				foreach $I (@YourJ) {
					if ($Jkind[$I] eq 'Usu') {
						$Usu = $_;
						last;
					}
				}
			}
			if ($Usu) {
				last;
			}
			else {
				@YourStatue = split(/,/, $Statue[$_]);
				foreach $I (1..4) {
					if ($Jkind[$YourStatue[$I]] eq 'Usu') {
						$Usu = $_;
						last;
					}
				}
			}
			if ($Usu) {
				last;
			}
		}
		
		if ($Usu) {
			$Target = $Usu;
		}
		else {
			$Target = &RandomPlayer;
		}
		$TargetShow = 'Secret';
	}
	
	#롧뚯븬덐궻궰귍갂?뼺궻궿귖
	if ($Jkind[$UseJ] eq 'Rope') {
		$Target = $X;
		$TargetShow = 'No';
	}
	
	#딉먘럊뾭?딇궻럊뾭귩?긃긞긏
	$UMflag = 0;
	if (
		($Jkind[$UseJ] eq 'Release' && $Jprice[$UseJ2] > $in{'MP'} && $UMJ[0])
		 || ($Jmp[$UseJ] > $in{'MP'} && $UMJ[0])
	) {
		if ($UMJ[0] != $in{'Act1'} && $UMJ[0] != $in{'Act2'}) {
			$UMflag = 1;
			$SendPresent .= ":$X,UseMiracle,$UseJ,$MyJ[$UMJ[0]]";
			$UseMiracleNews = "$X,UseMiracle,$UseJ,$MyJ[$UMJ[0]]";
		}
		elsif ($UMJ[1]) {
			$UMflag = 2;
			$SendPresent .= ":$X,UseMiracle,$UseJ,$MyJ[$UMJ[1]]";
		}
		else {
			&Error;
		}
	}
	
	#?딇궻롰쀞빶궸룉뿚걁븉맫?긃긞긏븊걂
	
	#뙳둶뛱벍궳?딇귩뺳귟뱤궛귡궴궖
	if ($ThrowFlag) {
		$SendPresent .= ":$X,Throw,$UseJ";
		$Target = $X;
		$GetJingi = 1;
	}
	#몴걁뫂뤑돸걂
	elsif ($Jkind[$UseJ] eq 'AllS' || $Jkind[$UseJ] eq 'WeaponS' || $Jkind[$UseJ] eq 'ProtectorS' || $Jkind[$UseJ] eq 'SundryS') {
		#뭤땯?궻몴갂븧?궻몴갂뎢?궻몴갂랦?궻몴갂궩귢궪귢궻븉맫?긃긞긏
		if ($in{'Act2'} > 16 || $in{'Act3'} > 16 || $in{'Act4'} > 16 || $in{'Act5'} > 16) {&Error;}
		elsif ($Jkind[$UseJ] eq 'AllS') {
			if (!$Jname[$UseJ2]) {&Error;}
		}
		elsif ($Jkind[$UseJ] eq 'WeaponS') {
			if ($Jmp[$UseJ2] > 0 || $Jkind[$UseJ2] ne 'Weapon') {&Error;}
			elsif ($UseJ3 && ($Jmp[$UseJ3] > 0 || $Jkind[$UseJ3] ne 'Weapon')) {&Error;}
			elsif ($UseJ4 && ($Jmp[$UseJ4] > 0 || $Jkind[$UseJ4] ne 'Weapon')) {&Error;}
			elsif ($UseJ5 && ($Jmp[$UseJ5] > 0 || $Jkind[$UseJ5] ne 'Weapon')) {&Error;}
		}
		elsif ($Jkind[$UseJ] eq 'ProtectorS') {
			if (!($Jmp[$UseJ2] == 0 || $Jkind[$UseJ2] eq 'Shield' || $Jkind[$UseJ2] eq 'Armor' || $Jkind[$UseJ2] eq 'Helm' || $Jkind[$UseJ2] eq 'Gauntlet' || $Jkind[$UseJ2] eq 'Boots' || $Jkind[$UseJ2] eq 'Ring' || $Jkind[$UseJ2] eq 'OtherP' || $Jkind[$UseJ2] eq 'SoloP')) {&Error;}
			elsif ($UseJ3 && !($Jmp[$UseJ2] == 0 || $Jkind[$UseJ3] eq 'Shield' || $Jkind[$UseJ3] eq 'Armor' || $Jkind[$UseJ3] eq 'Helm' || $Jkind[$UseJ3] eq 'Gauntlet' || $Jkind[$UseJ3] eq 'Boots' || $Jkind[$UseJ3] eq 'Ring' || $Jkind[$UseJ3] eq 'OtherP' || $Jkind[$UseJ3] eq 'SoloP')) {&Error;}
			elsif ($UseJ4 && !($Jmp[$UseJ2] == 0 || $Jkind[$UseJ4] eq 'Shield' || $Jkind[$UseJ4] eq 'Armor' || $Jkind[$UseJ4] eq 'Helm' || $Jkind[$UseJ4] eq 'Gauntlet' || $Jkind[$UseJ4] eq 'Boots' || $Jkind[$UseJ4] eq 'Ring' || $Jkind[$UseJ4] eq 'OtherP' || $Jkind[$UseJ4] eq 'SoloP')) {&Error;}
			elsif ($UseJ5 && !($Jmp[$UseJ2] == 0 || $Jkind[$UseJ5] eq 'Shield' || $Jkind[$UseJ5] eq 'Armor' || $Jkind[$UseJ5] eq 'Helm' || $Jkind[$UseJ5] eq 'Gauntlet' || $Jkind[$UseJ5] eq 'Boots' || $Jkind[$UseJ5] eq 'Ring' || $Jkind[$UseJ5] eq 'OtherP' || $Jkind[$UseJ5] eq 'SoloP')) {&Error;}
		}
		elsif ($Jkind[$UseJ] eq 'SundryS') {
			if ($Jmp[$UseJ2] == 0 && ($Jkind[$UseJ2] eq 'Weapon' || $Jkind[$UseJ2] eq 'Shield' || $Jkind[$UseJ2] eq 'Armor' || $Jkind[$UseJ2] eq 'Helm' || $Jkind[$UseJ2] eq 'Gauntlet' || $Jkind[$UseJ2] eq 'Boots' || $Jkind[$UseJ2] eq 'Ring' || $Jkind[$UseJ2] eq 'OtherP' || $Jkind[$UseJ2] eq 'SoloP')) {&Error;}
			elsif ($UseJ3 && ($Jmp[$UseJ3] == 0 && ($Jkind[$UseJ3] eq 'Weapon' || $Jkind[$UseJ3] eq 'Shield' || $Jkind[$UseJ3] eq 'Armor' || $Jkind[$UseJ3] eq 'Helm' || $Jkind[$UseJ3] eq 'Gauntlet' || $Jkind[$UseJ3] eq 'Boots' || $Jkind[$UseJ3] eq 'Ring' || $Jkind[$UseJ3] eq 'OtherP' || $Jkind[$UseJ3] eq 'SoloP'))) {&Error;}
			elsif ($UseJ4 && ($Jmp[$UseJ4] == 0 && ($Jkind[$UseJ4] eq 'Weapon' || $Jkind[$UseJ4] eq 'Shield' || $Jkind[$UseJ4] eq 'Armor' || $Jkind[$UseJ4] eq 'Helm' || $Jkind[$UseJ4] eq 'Gauntlet' || $Jkind[$UseJ4] eq 'Boots' || $Jkind[$UseJ4] eq 'Ring' || $Jkind[$UseJ4] eq 'OtherP' || $Jkind[$UseJ4] eq 'SoloP'))) {&Error;}
			elsif ($UseJ5 && ($Jmp[$UseJ5] == 0 && ($Jkind[$UseJ5] eq 'Weapon' || $Jkind[$UseJ5] eq 'Shield' || $Jkind[$UseJ5] eq 'Armor' || $Jkind[$UseJ5] eq 'Helm' || $Jkind[$UseJ5] eq 'Gauntlet' || $Jkind[$UseJ5] eq 'Boots' || $Jkind[$UseJ5] eq 'Ring' || $Jkind[$UseJ5] eq 'OtherP' || $Jkind[$UseJ5] eq 'SoloP'))) {&Error;}
		}
		
		#?딇귩떉궑귡
		$MyStatue[0] = $UseJ;
		
		foreach $I (2..5) {
			if (!$MyJ[$in{"Act$I"}]) {last;}
			
			$OfferFlag = 0;
			foreach (1..4) {
				if (!$MyStatue[$_]) {
					$MyStatue[$_] = $MyJ[$in{"Act$I"}];
					$MyStatue[$_ + 4] = time;
					$OfferFlag = 1;
					last;
				}
			}
			#떉궑븿궕띍묈릶궻궴궖궼뚀궋떉궑븿귩랁룣
			if (!$OfferFlag) {
				&JnowUseAdd($MyStatue[1]);
				@MyStatue = (
					$MyStatue[0],
					$MyStatue[2],$MyStatue[3],$MyStatue[4],$MyJ[$in{"Act$I"}],
					$MyStatue[6],$MyStatue[7],$MyStatue[8],time
				);
			}
			
			$SendPresent .= ":$X,First,$UseJ,$MyJ[$in{\"Act$I\"}]";
		}
		
		$Statue[$X] = join(",", @MyStatue);
		&NewsChange($SendPresent);
		$Target = 0;
		$MyJ[$in{'Act2'}] = "";
		$MyJ[$in{'Act3'}] = "";
		$MyJ[$in{'Act4'}] = "";
		$MyJ[$in{'Act5'}] = "";
		if ($in{'Act1'} <= 16) {
			$GetJingi = 2;
		}
		else {
			$GetJingi = 1;
		}
	}
	#봽귡
	elsif ($Jkind[$UseJ] eq 'Sell') {
		if ($in{'Act2'} > 16) {&Error;}
		elsif (!$Jname[$UseJ2]) {&Error;}
		$SendPresent .= ":$X,First,$UseJ,$UseJ2";
		$MyJ[$in{'Act2'}] = "";
		$GetJingi = 1;
	}
	#곢됶뺳곣
	elsif ($Jkind[$UseJ] eq 'Release') {
		if ($in{'Act2'} > 16) {
			&Error;
		}
		elsif (!$Jattribute[$UseJ2] && $Jkind[$UseJ2] ne 'Mirac' && $Jdetail[$UseJ2] ne 'Earth') {
			&Error;
		}
		elsif ($MP[$X] < $Jprice[$UseJ2] && !$UMflag) {
			&Error;
		}
		$SendPresent .= ":$X,First,$UseJ:$X,Second,$UseJ,$UseJ2";
		$Target = $X;
		$GetJingi = 2;
	}
	#뿼뫶
	elsif ($Jkind[$UseJ] eq 'Exchange') {
		if ($in{'HP'} + $in{'MP'} + $in{'GP'} != $TotalP) {&Error;}
		&JnowUseAdd($UseJ);
		$SendPresent .= ":$X,First,$UseJ:$X,Second,$UseJ,$HP[$X],$MP[$X],$GP[$X],$in{'HP'},$in{'MP'},$in{'GP'}";
		$HP[$X] = $in{'HP'};
		$MP[$X] = $in{'MP'};
		$GP[$X] = $in{'GP'};
		&NewsChange($SendPresent);
		$Target = 0;
		$GetJingi = 1;
	}
	#궩궻뫜궻뛘똼
	elsif ($Jtype[$UseJ] eq 'Solo' || $Jtype[$UseJ] eq 'NormalW' || $Jtype[$UseJ] eq 'SoloAdd') {
		#MP궕뫉귟궶궋궴긄깋?
		if ($MP[$X] < $Jmp[$UseJ] && !$UMJ[0]) {&Error;}
		
		#HP뤑뷂뛘똼
		if ($Jdetail[$UseJ] eq 'SelfDamage') {
			$I = "$X,SelfDamage";
			if ($MyGuardian[0]) {
				$I .= ":$X,Guardian,$MyGuardian[0],Guard,$Jfree[$UseJ]";
				$MyGuardian[1] -= $Jfree[$UseJ];
				if ($MyGuardian[1] <= 0) {
					$I .= ":$X,Guardian,,$MyGuardian[0],Lost";
					$MyGuardian[0] = "";
					$MyGuardian[1] = 0;
				}
				$Guardian[$X] = join(",", @MyGuardian);
			}
			else {
				if ($HP[$X] > $Jfree[$UseJ]) {
					$SelfDamage = $Jfree[$UseJ];
				}
				else {
					$SelfDamage = $HP[$X] - 10;
				}
				$I .= ",$SelfDamage";
				$HP[$X] -= $SelfDamage;
			}
			&ShrineNews($I);
			&NewsChange($I);
		}
		
		#멣뫬뛘똼
		if ($Jpoint[$UseJ] >= 1000) {
			$AllAttackP = int($Jpoint[$UseJ] / 1000) * 25;
			foreach (1..$PlayerMax) {
				if ($HP[$_] > 0 && $_ != $X) {
					if ($AllAttackP > rand(100)) {
						$Hit = $Jpoint[$UseJ] % 1000;
						$Present[$_] .= "==$IllusionNews:$UseMiracleNews:$X,First,$UseJ:$X,Second,$UseJ,$Hit";
					}
					else {
						$Present[$_] .= "==$IllusionNews:$UseMiracleNews:$X,First,$UseJ:$X,Second,$UseJ";
					}
				}
			}
			$SendPresent .= ":$X,First,$UseJ:$X,Second,$UseJ";
			$Target = 0;
			&NewsChange($SendPresent);
			$GetJingi = 1;
		}
		#뭁뫬뛘똼
		else {
			$SendPresent .= ":$X,First,$UseJ";
			$TotalAT = $Jpoint[$UseJ];
			$GetJingi = 1;
			
			#MP뤑뷂?
			if ($Jdetail[$UseJ] eq 'MagicalW' && $in{'MP'} >= $Jfree[$UseJ]) {
				if ($MP[$X] < $Jfree[$UseJ]) {&Error;}
				$MP[$X] -= $Jfree[$UseJ];
				$SendPresent .= ":$X,Second,$UseJ";
				$TotalAT = $Jpoint[$UseJ] * 2;
			}
			elsif ($Jdetail[$UseJ] eq 'MagicalRod') {
				$MP[$X] -= $in{'MP'};
				$SendPresent .= ":$X,Second,$UseJ";
				$TotalAT = $in{'MP'} * 2;
			}
			
			#뗠맦궻릣뜼궢
			if ($Jkind[$UseJ] eq 'Jug') {
				$GP[$X] -= $in{'GP'};
				$SendPresent .= ",$in{'GP'}";
			}
			
			#뼰뫌맜븧딇궸뛘똼쀍븊돿궕궇귡궴궖
			if ($Jtype[$UseJ] eq 'NormalW') {
				if ($Jtype[$UseJ2] eq 'SoloAdd' || $Jtype[$UseJ2] eq 'Add') {
					if ($Jmp[$UseJ2] > 0) {
						if ($in{'MP'} < $Jmp[$UseJ2] && $UMJ[0]) {
							$UMflag = 1;
							$SendPresent .= ":$X,UseMiracle,$UseJ2,$MyJ[$UMJ[0]]";
						}
						else {
							if ($MP[$X] < $Jmp[$UseJ2]) {&Error;}
							$MP[$X] -= $Jmp[$UseJ2];
						}
						$SendPresent .= ":$X,First,$UseJ2";
					}
					$SendPresent .= ":$X,Second,$UseJ2";
					$TotalAT += $Jpoint[$UseJ2];
					$GetJingi = 2;
				}
				elsif ($Jtype[$UseJ2] eq 'Adds') {
					$SendPresent .= ":$X,Second,$UseJ2";
					$TotalAT += $Jfree[$UseJ2];
					$GetJingi = 2;
					
					if ($Jtype[$UseJ3] eq 'SoloAdd' || $Jtype[$UseJ3] eq 'Add') {
						if ($Jmp[$UseJ3] > 0) {
							if ($in{'MP'} < $Jmp[$UseJ3] && $UMJ[0]) {
								$UMflag = 1;
								$SendPresent .= ":$X,UseMiracle,$UseJ3,$MyJ[$UMJ[0]]";
							}
							else {
								if ($MP[$X] < $Jmp[$UseJ3]) {&Error;}
								$MP[$X] -= $Jmp[$UseJ3];
							}
							$SendPresent .= ":$X,First,$UseJ3";
						}
						$SendPresent .= ":$X,Second,$UseJ3";
						$TotalAT += $Jpoint[$UseJ3];
						$GetJingi = 3;
					}
					elsif ($Jtype[$UseJ3] eq 'Adds') {
						$SendPresent .= ":$X,Second,$UseJ3";
						$TotalAT += $Jfree[$UseJ3];
						$GetJingi = 3;
						
						if ($Jtype[$UseJ4] eq 'SoloAdd' || $Jtype[$UseJ4] eq 'Add') {
							if ($Jmp[$UseJ4] > 0) {
								if ($in{'MP'} < $Jmp[$UseJ4] && $UMJ[0]) {
									$UMflag = 1;
									$SendPresent .= ":$X,UseMiracle,$UseJ4,$MyJ[$UMJ[0]]";
								}
								else {
									if ($MP[$X] < $Jmp[$UseJ4]) {&Error;}
									$MP[$X] -= $Jmp[$UseJ4];
								}
								$SendPresent .= ":$X,First,$UseJ4";
							}
							$SendPresent .= ":$X,Second,$UseJ4";
							$TotalAT += $Jpoint[$UseJ4];
							$GetJingi = 4;
						}
						elsif ($Jtype[$UseJ4] eq 'Adds') {
							$SendPresent .= ":$X,Second,$UseJ4";
							$TotalAT += $Jfree[$UseJ4];
							$GetJingi = 4;
							
							if ($Jtype[$UseJ5] eq 'SoloAdd' || $Jtype[$UseJ5] eq 'Add') {
								if ($Jmp[$UseJ5] > 0) {
									if ($in{'MP'} < $Jmp[$UseJ5] && $UMJ[0]) {
										$UMflag = 1;
										$SendPresent .= ":$X,UseMiracle,$UseJ5,$MyJ[$UMJ[0]]";
									}
									else {
										if ($MP[$X] < $Jmp[$UseJ5]) {&Error;}
										$MP[$X] -= $Jmp[$UseJ5];
									}
									$SendPresent .= ":$X,First,$UseJ5";
								}
								$SendPresent .= ":$X,Second,$UseJ5";
								$TotalAT += $Jpoint[$UseJ5];
								$GetJingi = 5;
							}
							elsif ($Jtype[$UseJ5] eq 'Adds') {
								$SendPresent .= ":$X,Second,$UseJ5";
								$TotalAT += $Jfree[$UseJ5];
								$GetJingi = 5;
							}
						}
					}
				}
			}
			
			#뜃똶뛘똼쀍륃뺪귩긵깒?깛긣궸븊궚뫉궥
			if ($TotalAT) {
				if ($TotalAT % 10 == 2) {$TotalAT = ($TotalAT - 2) * 2;}
				$SendPresent .= ",$TotalAT";
			}
			
			#븊돿뚼됈륃뺪귩긵깒?깛긣궸븊궚뫉궥
			if ($Jdetail[$UseJ]) {
				$SendPresent .= ",,,$Jdetail[$UseJ]";
			}
			
			#멝뚹궻뎓떯궸귝귡뛘똼?긚
			if ($Jkind[$UseJ] eq 'Weapon' && $MyCondition[2] && rand(100) < 50) {
				$MissPresent = ":$X,Miss,,$Target";
			}
		}
	}
	#Act1궸궼럊궑궶궋?딇귩럊궯궫귞긄깋?
	else {
		&Error;
	}
	
	#긵깒?깛긣귩몼귡
	if ($Target) {$Present[$Target] .= "==$SendPresent";}
	if ($MissPresent) {$Present[$Target] .= $MissPresent;}
	if (!$TargetShow) {$TargetShow = $Target;}
	
	#뷲
	$DiseasePresent = "";
	$I = int(rand(100)) + 1;
	if ($MyCondition[0] == 1) {
		if ($I <= 20) {
			$DiseasePresent = ":$X,WeakWind,$MyCondition[0],Fit,WeakWind,FitDamage,10";
		}
		else {
			if ($I <= 24) {&InfectDisease(1);}
			$DiseasePresent = ":$X,WeakWind,1,Damage,10";
		}
	}
	elsif ($MyCondition[0] == 2) {
		if ($I <= 20) {
			$DiseasePresent = ":$X,WeakWind,$MyCondition[0],Worse,StrongWind,Damage,10";
		}
		else {
			if ($I <= 24) {&InfectDisease(1);}
			$DiseasePresent = ":$X,WeakWind,2,FitDamage,10";
		}
	}
	elsif ($MyCondition[0] == 3) {
		if ($I <= 15) {
			$DiseasePresent = ":$X,StrongWind,$MyCondition[0],Fit,StrongWind,FitDamage,20";
		}
		else {
			if ($I <= 30) {&InfectDisease(3);}
			$DiseasePresent = ":$X,StrongWind,3,Damage,10";
		}
	}
	elsif ($MyCondition[0] == 4) {
		if ($I <= 15) {
			$DiseasePresent = ":$X,StrongWind,$MyCondition[0],Worse,Hell,Damage,20";
		}
		else {
			if ($I <= 30) {&InfectDisease(3);}
			$DiseasePresent = ":$X,StrongWind,4,FitDamage,20";
		}
	}
	elsif ($MyCondition[0] == 5) {
		if ($I <= 10) {
			$DiseasePresent = ":$X,Hell,$MyCondition[0],Fit,Hell,FitDamage,50";
		}
		else {
			if ($I <= 12) {&InfectDisease(5);}
			$DiseasePresent = ":$X,Hell,5,Damage,20";
		}
	}
	elsif ($MyCondition[0] == 6) {
		if ($I <= 10) {
			$DiseasePresent = ":$X,Hell,$MyCondition[0],Worse,Heaven,HPup,50";
		}
		else {
			if ($I <= 12) {&InfectDisease(5);}
			$DiseasePresent = ":$X,Hell,6,FitDamage,50";
		}
	}
	elsif ($MyCondition[0] == 7) {
		if ($I <= 10) {
			$DiseasePresent = ":$X,Heaven,$MyCondition[0],Fit";
		}
		else {
			if ($I <= 12) {&InfectDisease(7);}
			$DiseasePresent = ":$X,Heaven,7,HPup,50";
		}
	}
	
	if ($DiseasePresent) {
		$Present[$X] .= "==$DiseasePresent";
	}
	
	#?밶긦깄?긚
	&ShrineNews($SendPresent);
	
	#딉먘럊뾭?딇귩럊궯궫궴궖
	if ($UMflag == 1) {
		&JnowUseAdd($MyJ[$UMJ[0]]);
		$MyJ[$UMJ[0]] = "";
		$GetJingi++;
	}
	elsif ($UMflag == 2) {
		&JnowUseAdd($MyJ[$UMJ[1]]);
		$MyJ[$UMJ[1]] = "";
		$GetJingi++;
	}
	
	#몼궯궫빁귩궩귢궪귢뙵귞궥
	#?딇귩럊궯궫궴궖궼룋렃?딇귩뙵귞궥
	#뢐벦딉먘귩럊궯궫궴궖궼MP귩뙵귞궥
	#몴귩럊궯궫궴궖궼돺귖뙵귞궠궶궋
	if ($in{'Act1'} <= 16) {
		#딉먘귩럊궯궫궴궖
		if ($Jmp[$UseJ] > 0 && !$ThrowFlag) {
			if (!$UMflag) {
				if ($Jkind[$UseJ] eq 'Release') {
					$MP[$X] -= $Jprice[$UseJ2];
				}
				else {
					$MP[$X] -= $Jmp[$UseJ];
				}
			}
			&MiracleChange($UseJ);
		}
		
		#룋렃?딇귩뙵귞궥
		if ($GetJingi > 0) {
			&JnowUseAdd($UseJ);
			$MyJ[$in{'Act1'}] = "";
		}
		foreach (2..$GetJingi) {
			if ($in{"Act$_"} <= 16) {
				if ($Jmp[$MyJ[$in{"Act$_"}]] > 0 && $Jkind[$UseJ] ne 'Release') {
					&MiracleChange($MyJ[$in{"Act$_"}]);
				}
				&JnowUseAdd($MyJ[$in{"Act$_"}]);
				$MyJ[$in{"Act$_"}] = "";
			}
		}
	}
	elsif ($in{'Act1'} <= 22) {
		if (!$UMflag) {
			if ($Jkind[$UseJ] eq 'Release') {
				$MP[$X] -= $Jprice[$UseJ2];
			}
			else {
				$MP[$X] -= $Jmp[$UseJ];
			}
		}
		if ($Jkind[$UseJ] eq 'Release') {
			&JnowUseAdd($UseJ2);
			$MyJ[$in{'Act2'}] = "";
		}
	}
	elsif ($in{'Act1'} == 23) {
		$MyJ[$in{'Act2'}] = "";
	}
	
	#롻??딇
	if ($Jkind[$UseJ] eq 'Sell') {$GetJingi++;}
	$Present[$X] .= "==$X,Give,$GetJingi";
	
	#롧뚯?궻뛱벍
	if ($MyGuardian[0]) {
		$I = int(rand(100)) + 1;
		$Gtarget = "";
		$AllActP = 0;
		
		#롧뚯?빶궸몼귡긵깒?깛긣귩뙂믦
		if ($MyGuardian[0] eq 'Mercury') {
			if ($I <= 30) {
				$GuardianSend = "$X,GuardianAct,,20,Mercury,Weapon,AddFog,Mercury,Fog";
			}
			elsif ($I <= 55) {
				$GuardianSend = "$X,GuardianAct,,30,Mercury,Weapon,,Mercury,TargetWater";
			}
			elsif ($I <= 80) {
				$GuardianSend = "$X,GuardianAct,AllAct,20,Mercury,Weapon,,Mercury,AllWater";
				$GuardianMiss = "$X,GuardianAct,AllAct,,,,,Mercury,AllWater,20,Mercury,Weapon,";
				$AllActP = 50;
			}
			elsif ($I <= 95) {
				$GuardianSend = "$X,GuardianAct,,60,Mercury,Weapon,,Mercury,TargetIce";
			}
			elsif ($I <= 100) {
				$GuardianSend = "$X,GuardianAct,AllAct,70,Mercury,Weapon,,Mercury,AllIce";
				$GuardianMiss = "$X,GuardianAct,AllAct,,,,,Mercury,AllIce,70,Mercury,Weapon,";
				$AllActP = 50;
			}
		}
		elsif ($MyGuardian[0] eq 'Venus') {
			if ($I <= 20) {
				$GuardianSend = "$X,GuardianAct,GPup,10,,,,Venus,Scatter";
				$AllActP = 'All';
			}
			elsif ($I <= 40) {
				$GuardianSend = "$X,GuardianAct,GPup,50,,,,Venus,GPgiveYou";
			}
			elsif ($I <= 60) {
				$GuardianSend = "$X,GuardianAct,GPabsorb,30,,,GPabsorb,Venus,Transfer";
			}
			elsif ($I <= 80) {
				$GuardianSend = "$X,GuardianAct,GPup,80,,,,Venus,GPgiveMe";
				$Gtarget = $X;
			}
			elsif ($I <= 100) {
				$GuardianSend = "$X,GuardianAct,GPup,200,,,,Venus,Jewelry";
				$Gtarget = $X;
			}
		}
		elsif ($MyGuardian[0] eq 'Mars') {
			if ($I <= 35) {
				$GuardianSend = "$X,GuardianAct,AllAct,10,Mars,Weapon,,Mars,FireSS";
				$GuardianMiss = "$X,GuardianAct,AllAct,,,,,Mars,FireSS,10,Mars,Weapon,";
				$AllActP = 75;
			}
			elsif ($I <= 65) {
				$GuardianSend = "$X,GuardianAct,AllAct,20,Mars,Weapon,,Mars,FireS";
				$GuardianMiss = "$X,GuardianAct,AllAct,,,,,Mars,FireS,20,Mars,Weapon,";
				$AllActP = 75;
			}
			elsif ($I <= 85) {
				$GuardianSend = "$X,GuardianAct,AllAct,30,Mars,Weapon,,Mars,FireM";
				$GuardianMiss = "$X,GuardianAct,AllAct,,,,,Mars,FireM,30,Mars,Weapon,";
				$AllActP = 75;
			}
			elsif ($I <= 95) {
				$GuardianSend = "$X,GuardianAct,AllAct,40,Mars,Weapon,,Mars,FireL";
				$GuardianMiss = "$X,GuardianAct,AllAct,,,,,Mars,FireL,40,Mars,Weapon,";
				$AllActP = 75;
			}
			elsif ($I <= 100) {
				$GuardianSend = "$X,GuardianAct,AllAct,50,Mars,Weapon,,Mars,FireLL";
				$GuardianMiss = "$X,GuardianAct,AllAct,,,,,Mars,FireLL,50,Mars,Weapon,";
				$AllActP = 75;
			}
		}
		elsif ($MyGuardian[0] eq 'Jupiter') {
			if ($I <= 25) {
				$GuardianSend = "$X,GuardianAct,,10,Jupiter,Weapon,,Jupiter,Branch";
			}
			elsif ($I <= 50) {
				$GuardianSend = "$X,GuardianAct,,20,Jupiter,Weapon,,Jupiter,Root";
			}
			elsif ($I <= 70) {
				$GuardianSend = "$X,GuardianAct,AllAct,10,Jupiter,Weapon,HPabsorb,Jupiter,Ivy";
				$GuardianMiss = "$X,GuardianAct,AllAct,,,,,Jupiter,Ivy,10,Jupiter,Weapon,HPabsorb";
				$AllActP = 75;
			}
			elsif ($I <= 85) {
				$GuardianSend = "$X,GuardianAct,Illusion,,Jupiter,OtherW,Illusion,Jupiter,RedLeaves";
			}
			elsif ($I <= 100) {
				$GuardianSend = "$X,GuardianAct,AllAct,20,Jupiter,Weapon,AddIllusion,Jupiter,FallingLeaves";
				$GuardianMiss = "$X,GuardianAct,AllAct,,,,,Jupiter,FallingLeaves,20,Jupiter,Weapon,AddIllusion";
				$AllActP = 25;
			}
		}
		elsif ($MyGuardian[0] eq 'Saturn') {
			if ($I <= 35) {
				$GuardianSend = "$X,GuardianAct,,10,Saturn,Weapon,,Saturn,Sand";
			}
			elsif ($I <= 65) {
				$GuardianSend = "$X,GuardianAct,,30,Saturn,Weapon,,Saturn,Stone";
			}
			elsif ($I <= 85) {
				$GuardianSend = "$X,GuardianAct,,50,Saturn,Weapon,,Saturn,Rock";
			}
			elsif ($I <= 95) {
				$GuardianSend = "$X,GuardianAct,,70,Saturn,Weapon,,Saturn,Hurl";
			}
			elsif ($I <= 100) {
				$GuardianSend = "$X,GuardianAct,,150,Saturn,Weapon,,Saturn,DiamondAx";
			}
		}
		elsif ($MyGuardian[0] eq 'Uranus') {
			if ($I <= 35) {
				$GuardianSend = "$X,GuardianAct,,20,Uranus,Weapon,,Uranus,Shine";
			}
			elsif ($I <= 60) {
				$GuardianSend = "$X,GuardianAct,,30,Uranus,Weapon,,Uranus,Electricity";
			}
			elsif ($I <= 80) {
				$GuardianSend = "$X,GuardianAct,Flash,,Uranus,OtherW,Flash,Uranus,Flash";
			}
			elsif ($I <= 95) {
				$GuardianSend = "$X,GuardianAct,,50,Uranus,Weapon,HPabsorb,Uranus,Light";
			}
			elsif ($I <= 100) {
				$GuardianSend = "$X,GuardianAct,AllAct,100,Uranus,Weapon,,Uranus,LaserBeam";
				$GuardianMiss = "$X,GuardianAct,AllAct,,,,,Uranus,LaserBeam,100,Uranus,Weapon,";
				$AllActP = 75;
			}
		}
		elsif ($MyGuardian[0] eq 'Neptune') {
			if ($I <= 40) {
				$GuardianSend = "$X,GuardianAct,SongCure,,,,,Neptune,Ripple";
				$Gtarget = $X;
			}
			elsif ($I <= 60) {
				$GuardianSend = "$X,GuardianAct,HPup,50,,,,Neptune,HPup50";
				$Gtarget = $X;
			}
			elsif ($I <= 80) {
				$GuardianSend = "$X,GuardianAct,MPup,50,,,,Neptune,MPup50";
				$Gtarget = $X;
			}
			elsif ($I <= 90) {
				$GuardianSend = "$X,GuardianAct,HPup,100,,,,Neptune,HPup100";
				$Gtarget = $X;
			}
			elsif ($I <= 100) {
				$GuardianSend = "$X,GuardianAct,MPup,100,,,,Neptune,MPup100";
				$Gtarget = $X;
			}
		}
		elsif ($MyGuardian[0] eq 'Pluto') {
			if ($I <= 35) {
				$GuardianSend = "$X,GuardianAct,,,,,,Pluto,DoNot";
				$Gtarget = 'No';
			}
			elsif ($I <= 65) {
				$GuardianSend = "$X,GuardianAct,DarkCloud,,Pluto,OtherW,DarkCloud,Pluto,DarkCloud";
			}
			elsif ($I <= 85) {
				$GuardianSend = "$X,GuardianAct,,10,Pluto,Weapon,,Pluto,Finger";
			}
			elsif ($I <= 95) {
				$GuardianSend = "$X,GuardianAct,,30,Pluto,Weapon,,Pluto,Hand";
			}
			elsif ($I <= 100) {
				$GuardianSend = "$X,GuardianAct,,50,Pluto,Weapon,,Pluto,Arm";
			}
		}
		elsif ($MyGuardian[0] eq 'Mirac') {
			if ($I <= 50) {
				$GuardianSend = "$X,GuardianAct,,,,,,Mirac,Play";
				$Gtarget = 'No';
			}
			elsif ($I <= 70) {
				$GuardianSend = "$X,GuardianAct,SongCure,,,,,Mirac,Cheer";
				$Gtarget = $X;
			}
			elsif ($I <= 85) {
				$GuardianSend = "$X,GuardianAct,,80,Uranus,Miracle,,Mirac,Tornado";
			}
			elsif ($I <= 95) {
				$GuardianSend = "$X,GuardianAct,AllAct,60,Uranus,Miracle,,Mirac,Tsunami";
				$GuardianMiss = "$X,GuardianAct,AllAct,,,,,Mirac,Tsunami,60,Uranus,Miracle,";
				$AllActP = 75;
			}
			elsif ($I <= 100) {
				$GuardianSend = "$X,GuardianAct,Sneeze,,,Miracle,Sneeze,Mirac,Sneeze";
			}
		}
		elsif ($MyGuardian[0] eq 'Earth') {
			&NewJingi;
			if ($NJ == 0) {
				$JemptyFlag = 1;
			}
			elsif ($Jkind[$NJ] eq 'Sell') {
				$NJtemp = $NJ;
				&NewJingi;
				if ($NJ == 0 || $Jkind[$NJ] eq 'Creature') {
					$JemptyFlag = 1;
					
					@JnowNum = split(/,/, $JnowNumLine);
					$JnowNum[$NJtemp]++;
					$JnowNumLine = join(",", @JnowNum);
					
					if ($Jkind[$NJ] eq 'Creature') {
						@JnowNum = split(/,/, $JnowNumLine);
						$JnowNum[$NJ]++;
						$JnowNumLine = join(",", @JnowNum);
					}
				}
				else {
					&JnowUseAdd($NJtemp);
					$SellNJ = $NJtemp;
					$GuardianSend = "$X,First,$SellNJ,$NJ,,,,Earth,Use";
				}
			}
			elsif ($Jkind[$NJ] eq 'Jug') {
				&JnowUseAdd($NJ);
				$J = int(rand(100)) * 10;
				$GuardianSend = "$X,First,$NJ,$J,,,,Earth,Use";
				$Gtarget = $X;
			}
			elsif ($Jdetail[$NJ] eq 'MagicalW') {
				&JnowUseAdd($NJ);
				if (rand(2) < 1) {
					$GtotalAT = $Jpoint[$NJ];
					$GuardianSend = "$X,First,$NJ,$GtotalAT,,,,Earth,Use";
				}
				else {
					$GtotalAT = $Jpoint[$NJ] * 2;
					$GuardianSend = "$X,First,$NJ,,,,,Earth,Use:$X,Second,$NJ,$GtotalAT";
				}
			}
			elsif ($Jdetail[$NJ] eq 'MagicalRod') {
				$GtotalAT = int(rand(100)) * 10 * 2;
				$GuardianSend = "$X,First,$NJ,,,,,Earth,Use:$X,Second,$NJ,$GtotalAT";
			}
			elsif (
				($Jtype[$NJ] eq 'NormalW' || $Jtype[$NJ] eq 'Solo')
				 && $Jkind[$NJ] ne 'Exchange'
				 && $Jmp[$NJ] == 0
			) {
				&JnowUseAdd($NJ);
				if ($Jpoint[$NJ] >= 1000) {
					$AllActP = int($Jpoint[$NJ] / 1000) * 25;
					$Hit = $Jpoint[$NJ] % 1000;
					$GuardianSend = "$X,First,$NJ,,,,,Earth,Use:$X,Second,$NJ,$Hit";
					$GuardianMiss = "$X,First,$NJ,,,,,Earth,Use:$X,Second,$NJ";
				}
				else {
					$GuardianSend = "$X,First,$NJ,,,,,Earth,Use";
					if (
						$Jkind[$NJ] eq 'HPup' || $Jkind[$NJ] eq 'MPup'
						 || $Jkind[$NJ] eq 'ToneCure' || $Jkind[$NJ] eq 'SongCure'
						 || $Jkind[$NJ] eq 'HPupDown'
						 || $Jkind[$NJ] eq 'Pot' || $Jkind[$NJ] eq 'Rope'
					) {
						$Gtarget = $X;
					}
					elsif ($Jdetail[$NJ] eq 'Kine') {
						$KineFlag = 1;
					}
				}
			}
			else {
				@JnowNum = split(/,/, $JnowNumLine);
				$JnowNum[$NJ]++;
				$JnowNumLine = join(",", @JnowNum);
				
				$GuardianSend = "$X,GuardianAct,,,,,,Earth,Sleep";
				$Gtarget = 'No';
			}
			
			if ($JemptyFlag) {
				$GuardianSend = "$X,GuardianAct,,,,,,Earth,Sleep";
				$Gtarget = 'No';
			}
		}
		
		#롧뚯?궔귞궻긵깒?깛긣귩몼귡
		if ($AllActP eq 'All') {
			foreach (1..$PlayerMax) {
				if ($HP[$_] > 0) {
					$Present[$_] .= "==$GuardianSend";
				}
			}
		}
		elsif ($AllActP > 0) {
			foreach (1..$PlayerMax) {
				if ($HP[$_] > 0 && $_ != $X) {
					if ($AllActP > rand(100)) {
						$Present[$_] .= "==$GuardianSend";
					}
					else {
						$Present[$_] .= "==$GuardianMiss";
					}
				}
			}
		}
		else {
			if (!$Gtarget) {
				do {
					$Gtarget = &RandomPlayer;
				}
				while ($Gtarget == $X && !$KineFlag);
			}
			
			if ($Gtarget ne 'No') {
				$Present[$Gtarget] .= "==$GuardianSend";
			}
		}
		
		#긦깄?긚
		$TargetShow = 'No';
		&ShrineNews($GuardianSend);
		if ($AllActP ne 'All' && $AllActP > 0) {
			&NewsChange($GuardianSend);
		}
	}
	
	#띍뢎귺긏긜긚귩딯?
	$LastAccess[$X] = time;
	
	#룋렃?딇궻뙅뜃궴깓긐긲?귽깑귉궻룕궖뜛귒
	&SortJingi;
	$Jingi[$X] = join(",", @MyJ);
	$Condition[$X] = join(",", @MyCondition);
	&WriteLog;
}

#뷲궻?먺
sub InfectDisease {
	if ($_[0] == 1) {$Infect = 'WeakWind';}
	elsif ($_[0] == 3) {$Infect = 'StrongWind';}
	elsif ($_[0] == 5) {$Infect = 'Hell';}
	elsif ($_[0] == 7) {$Infect = 'Heaven';}
	
	if ($Target && $Target != $X) {
		$InfectPlayer = $Target;
	}
	else {
		do {
			$InfectPlayer = &RandomPlayer;
		}
		while ($InfectPlayer == $X);
	}
	
	$Present[$InfectPlayer] .= "==$InfectPlayer,$Infect,$_[0],Infect";
}

#띍귖뚀궋긵깒?깛긣궻띍륷륉뫴귩롦벦
sub GetPresent {
	@OldPresent = split(/:/, $MyPresent[1]);
	$I = pop(@OldPresent);
	@Pcheck = split(/,/, $I);
	
	#뼳
	if ($MyCondition[1] && $Pcheck[0] != $X && $Pcheck[1] ne 'Mirror' && $Pcheck[1] ne 'GuardianAct') {
		@OldPresent = split(/:/, $MyPresent[1]);
		$K = @OldPresent;
		foreach (0..$K) {
			if ($OldPresent[$_]) {
				@FogCheck = split(/,/, $OldPresent[$_]);
				if (
					$FogCheck[0] != $X
					 && ($FogCheck[1] eq 'First' || $FogCheck[1] eq 'Second' || $FogCheck[1] eq 'UseMiracle')
					 && $Jkind[$FogCheck[2]] ne 'Ring'
					 && $Jpoint[$FogCheck[2]] < 1000
				) {
					#[4]궼?뿀뫌맜륃뺪궻룋귩롔귟궲궋귡
					$FogCheck[4] = 'Fog';
					$OldPresent[$_] = join(",", @FogCheck);
				}
				elsif ($FogCheck[0] != $X && $FogCheck[1] eq 'IllusionAT') {
					$OldPresent[$_] = "";
				}
			}
		}
		$MyPresent[1] = join(":", @OldPresent);
		$Present[$X] = join("==", @MyPresent);
		
		@OldPresent = split(/:/, $MyPresent[1]);
		$I = pop(@OldPresent);
		@Pcheck = split(/,/, $I);
	}
	
	$AddNews = "";
	if ($Pcheck[1] eq 'WeakWind' || $Pcheck[1] eq 'StrongWind' || $Pcheck[1] eq 'Hell' || $Pcheck[1] eq 'Heaven') {
		if (
			($Pcheck[3] eq 'Infect' && $MyCondition[0] >= $Pcheck[2])
			 || (
			 	(
			 		$Pcheck[3] eq 'Fit' || $Pcheck[3] eq 'Worse'
			 		 || $Pcheck[3] eq 'Damage' || $Pcheck[3] eq 'FitDamage' || $Pcheck[3] eq 'HPup'
			 	)
			 	 && $MyCondition[0] != $Pcheck[2]
			 )
		) {
			#?먺멟궸뒾먺띙귒갂귏궫궼뷲깒긹깑귺긞긵멟궸깒긹깑귺긞긵띙귒궻뤾뜃궼긵깒?깛긣뼰뤑돸
			@MyPresent = split(/==/, $Present[$X]);
			splice(@MyPresent, 1, 1);
			$Present[$X] = join("==", @MyPresent);
			
			#렅궻긵깒?깛긣귩롦벦
			&GetPresent;
		}
		else {
			$EatNews .= ":$MyPresent[1]";
		}
	}
	elsif ($Pcheck[1] ne 'Give') {
		if (!$LastPresentFlag) {$LastPresent = $MyPresent[1];}
		$EatNews .= ":$MyPresent[1]";
		
		#럚쀖뛘똼궼긽긦깄?됪뽋궻긦깄?긚궻??귩뤙뿪
		if ($Jkind[$Pcheck[2]] eq 'Ring' && $Pcheck[1] ne 'Mirror') {
			$AddNews .= ":$Pcheck[0],Second,$Pcheck[2]";
			if ($Pcheck[3]) {$AddNews .= ",$Pcheck[3]";}
			$RingATflag = 1; 
		}
		
		#멣뫬뛘똼궼뼺뭷륃뺪귩븊돿
		if (
			$Pcheck[1] ne 'Mirror' && $Pcheck[1] ne 'GuardianAct' && $Pcheck[1] ne 'Contribute'
			 && (
				$Jpoint[$Pcheck[2]] >= 1000 || $Jfree[$Pcheck[2]] >= 1000
				 || $Jdetail[$Pcheck[2]] eq 'AllAct'
			)
		) {
			if (($Pcheck[3] ne "" && $Pcheck[3] ne 'LostATmiss') || $MyCondition[4]) {
				if ($Pcheck[3] eq 'LostATmiss') {
					$AllActAT = $Jfree[$Pcheck[2]] % 1000;
				}
				elsif ($Pcheck[3] ne "") {
					$AllActAT = $Pcheck[3];
				}
				else {
					$AllActAT = $Jpoint[$Pcheck[2]] % 1000;
					$Pcheck[3] = $AllActAT;
				}
				$AddNews .= ":$X,Third,$Pcheck[2],$AllActAT";
				$EatNews .= ":$X,Third,$Pcheck[2],$AllActAT";
			}
			else {
				$AddNews .= ":$X,Miss,$Pcheck[2]";
				$EatNews .= ":$X,Miss,$Pcheck[2]";
			}
		}
		elsif ($Pcheck[1] eq 'GuardianAct' && $Pcheck[2] eq 'AllAct') {
			if ($Pcheck[3] || $MyCondition[4]) {
				if (!$Pcheck[3]) {
					$Pcheck[3] = $Pcheck[9]; $Pcheck[9] = "";
					$Pcheck[4] = $Pcheck[10]; $Pcheck[10] = "";
					$Pcheck[5] = $Pcheck[11]; $Pcheck[11] = "";
					$Pcheck[6] = $Pcheck[12]; $Pcheck[12] = "";
				}
				$AddNews .= ":$X,GuardianAct,Third,$Pcheck[3],$Pcheck[4],$Pcheck[5],$Pcheck[6],$Pcheck[7],$Pcheck[8]";
				$EatNews .= ":$X,GuardianAct,Third,$Pcheck[3],$Pcheck[4],$Pcheck[5],$Pcheck[6],$Pcheck[7],$Pcheck[8]";
			}
			else {
				$AddNews .= ":$X,GuardianAct,Miss,,,,,$Pcheck[7],$Pcheck[8]";
				$EatNews .= ":$X,GuardianAct,Miss,,,,,$Pcheck[7],$Pcheck[8]";
			}
		}
		
		#딉먘궸궼긦깄?긚귩븊궚뫉궥
		if (
			$Jmp[$Pcheck[2]] > 0
			 && $Pcheck[1] eq 'First'
			 && $Jtype[$Pcheck[2]] ne 'OneMore' && $Jtype[$Pcheck[2]] ne 'Add'
			 && $Jkind[$Pcheck[2]] ne 'AllAct'
		) {
			@PcheckSub = @Pcheck;
			$PcheckSub[0] = $X;
			$PcheckSub[1] = 'Second';
			$PcheckSubJoin = join(",", @PcheckSub);
			$EatNews .= ":$PcheckSubJoin";
			$AddMiracleNews = ":$PcheckSubJoin";
		}
		
		#걏봼궎멗묖걐궶귞??긒긞긣?렑궼궶궢
		#?깋?궶궵궳궼궺뺅궠귢궫뤾뜃귖?렑궶궢
		#렔벍봲뫿귖?렑궶궢
		#궩귢댥둖궶귞렔빁
		if (
			!($Pcheck[1] eq 'Second' && $Jkind[$Pcheck[2]] eq 'Buy')
			 && $Pcheck[1] ne 'Mirror' && !$RemoveFlag
		) {
			$TargetShow = $X;
		}
	}
}

#뛘똼궻롰쀞걁븧딇궔딉먘궔궩궻뫜걂궴뫌맜궴븊뫌뚼됈귩뮧귊귡
sub ATvariety {
	#뛘똼궻롰쀞
	if ($Pcheck[5] eq 'Weapon' || $Pcheck[5] eq 'Miracle') {
		$ATvariety = $Pcheck[5];
	}
	elsif (
		$Jkind[$Pcheck[2]] eq 'Weapon' || $Jtype[$Pcheck[2]] eq 'Add' || $Jtype[$Pcheck[2]] eq 'Adds'
		 || ($Jkind[$Pcheck[2]] eq 'Ring' && ($Jdetail[$Pcheck[2]] eq 'AllAct' || $Jdetail[$Pcheck[2]] eq 'TargetAct'))
	) {
		$ATvariety = 'Weapon';
	}
	elsif ($Jmp[$Pcheck[2]]) {
		$ATvariety = 'Miracle';
	}
	else {
		$ATvariety = 'OtherW';
	}
	
	#뛘똼궻뫌맜
	if ($Pcheck[4] eq 'Mars' || $Pcheck[4] eq 'Mercury' || $Pcheck[4] eq 'Jupiter' || $Pcheck[4] eq 'Saturn' || $Pcheck[4] eq 'Uranus' || $Pcheck[4] eq 'Pluto') {
		$ATattribute = $Pcheck[4];
	}
	else {
		$ATattribute = $Jattribute[$Pcheck[2]];
	}
	
	#뛘똼궻븊뫌뚼됈
	if (
		$Pcheck[6] eq 'AddWeakWind' || $Pcheck[6] eq 'AddStrongWind' || 
		$Pcheck[6] eq 'AddHell' || $Pcheck[6] eq 'AddHeaven' || 
		$Pcheck[6] eq 'AddFog' || $Pcheck[6] eq 'AddFlash' || 
		$Pcheck[6] eq 'AddIllusion' || $Pcheck[6] eq 'AddDarkCloud' || 
		$Pcheck[6] eq 'HPabsorb' || 
		$Pcheck[6] eq 'WeakWind' || $Pcheck[6] eq 'StrongWind' || 
		$Pcheck[6] eq 'Hell' || $Pcheck[6] eq 'Heaven' || 
		$Pcheck[6] eq 'Fog' || $Pcheck[6] eq 'Flash' || 
		$Pcheck[6] eq 'Illusion' || $Pcheck[6] eq 'DarkCloud' || 
		$Pcheck[6] eq 'Sneeze'
	) {
		$ATdetail = $Pcheck[6];
	}
	elsif (
		$Jdetail[$Pcheck[2]] eq 'AddWeakWind' || $Jdetail[$Pcheck[2]] eq 'AddStrongWind' || 
		$Jdetail[$Pcheck[2]] eq 'AddHell' || $Jdetail[$Pcheck[2]] eq 'AddHeaven' || 
		$Jdetail[$Pcheck[2]] eq 'AddFog' || $Jdetail[$Pcheck[2]] eq 'AddFlash' || 
		$Jdetail[$Pcheck[2]] eq 'AddIllusion' || $Jdetail[$Pcheck[2]] eq 'AddDarkCloud' || 
		$Jdetail[$Pcheck[2]] eq 'HPabsorb' || 
		$Jdetail[$Pcheck[2]] eq 'WeakWind' || $Jdetail[$Pcheck[2]] eq 'StrongWind' || 
		$Jdetail[$Pcheck[2]] eq 'Hell' || $Jdetail[$Pcheck[2]] eq 'Heaven' || 
		$Jdetail[$Pcheck[2]] eq 'Fog' || $Jdetail[$Pcheck[2]] eq 'Flash' || 
		$Jdetail[$Pcheck[2]] eq 'Illusion' || $Jdetail[$Pcheck[2]] eq 'DarkCloud' || 
		$Jdetail[$Pcheck[2]] eq 'Sneeze'

	) {
		$ATdetail = $Jdetail[$Pcheck[2]];
	}
	else {
		$ATdetail = "";
	}
}

#긵깒?깛긣궻롰쀞빶궸갂?딇궕뻞뗰궴궢궲럊뾭됀?궔궵궎궔귩뵽빶
sub PossibleDF {
	if ($Jdetail[$_[0]] eq 'SuperM') {
		$PossibleDF = 1;
	}
	elsif (!(
		$Jkind[$_[0]] eq 'Shield' || $Jkind[$_[0]] eq 'Armor' || $Jkind[$_[0]] eq 'Helm' || 
		$Jkind[$_[0]] eq 'Gauntlet' || $Jkind[$_[0]] eq 'Boots' || $Jkind[$_[0]] eq 'Ring' || 
		$Jkind[$_[0]] eq 'OtherP' || $Jkind[$_[0]] eq 'SoloP' || 
		$Jdetail[$_[0]] eq 'Shield' || $Jdetail[$_[0]] eq 'Armor' || $Jdetail[$_[0]] eq 'Helm' || 
		$Jdetail[$_[0]] eq 'Gauntlet' || $Jdetail[$_[0]] eq 'Boots' || $Jdetail[$_[0]] eq 'Ring' || 
		$Jdetail[$_[0]] eq 'OtherP' ||
		$Jdetail[$_[0]] eq 'WeaponM' || $Jdetail[$_[0]] eq 'WeaponR' || $Jdetail[$_[0]] eq 'WeaponB' || 
		$Jdetail[$_[0]] eq 'MiracleM' || $Jdetail[$_[0]] eq 'MiracleR' || $Jdetail[$_[0]] eq 'MiracleB'
	)) {
		$PossibleDF = 0;
	}
	elsif ($ATvariety eq 'Weapon') {
		if (
			($Jdetail[$_[0]] eq 'MiracleM' || $Jdetail[$_[0]] eq 'MiracleR' || $Jdetail[$_[0]] eq 'MiracleB')
			 && (
			 	($Jkind[$_[0]] ne 'Weapon' && !$Jpoint[$_[0]])
				 || $Jkind[$_[0]] eq 'Weapon'
			)
		) {
			$PossibleDF = 0;
		}
		elsif (!$ATattribute) {
			$PossibleDF = 1;
		}
		else {
			&AttributeCheck($Jattribute[$_[0]]);
		}
	}
	elsif ($ATvariety eq 'Miracle') {
		if (
			($Jdetail[$_[0]] eq 'WeaponM' || $Jdetail[$_[0]] eq 'WeaponR' || $Jdetail[$_[0]] eq 'WeaponB' || $Jdetail[$_[0]] eq 'ATabsorb')
			 && (
			 	($Jkind[$_[0]] ne 'Weapon' && !$Jpoint[$_[0]])
				 || $Jkind[$_[0]] eq 'Weapon'
			)
		) {
			$PossibleDF = 0;
		}
		elsif ($Jdetail[$_[0]] eq 'MiracleM' || $Jdetail[$_[0]] eq 'MiracleR' || $Jdetail[$_[0]] eq 'MiracleB') {
			$PossibleDF = 1;
		}
		elsif (
			$ATdetail eq 'WeakWind' || $ATdetail eq 'StrongWind' || 
			$ATdetail eq 'Hell' || $ATdetail eq 'Heaven' || 
			$ATdetail eq 'Fog' || $ATdetail eq 'Flash' || 
			$ATdetail eq 'Illusion' || $ATdetail eq 'DarkCloud' || 
			$ATdetail eq 'Sneeze'
		) {
			$PossibleDF = 0;
		}
		elsif (!$ATattribute) {
			$PossibleDF = 0;
		}
		else {
			&AttributeCheck($Jattribute[$_[0]]);
		}
	}
	else {
		if (!$ATattribute || $Jkind[$_[0]] ne 'Ring') {
			$PossibleDF = 0;
		}
		elsif (
			$ATdetail eq 'WeakWind' || $ATdetail eq 'StrongWind' || 
			$ATdetail eq 'Hell' || $ATdetail eq 'Heaven' || 
			$ATdetail eq 'Fog' || $ATdetail eq 'Flash' || 
			$ATdetail eq 'Illusion' || $ATdetail eq 'DarkCloud' || 
			$ATdetail eq 'Sneeze'
		) {
			$PossibleDF = 0;
		}
		else {
			&AttributeCheck($Jattribute[$_[0]]);
		}
	}
}

#뫌맜궸귝궯궲뻞뚥됀?궔궵궎궔뵽믦
sub AttributeCheck {
	if ($ATattribute eq 'Mars') {
		if ($_[0] eq 'Mercury' || $_[0] eq 'Uranus') {$PossibleDF = 1;}
		else {$PossibleDF = 0;}
	}
	elsif ($ATattribute eq 'Mercury') {
		if ($_[0] eq 'Mars' || $_[0] eq 'Uranus') {$PossibleDF = 1;}
		else {$PossibleDF = 0;}
	}
	elsif ($ATattribute eq 'Jupiter') {
		if ($_[0] eq 'Saturn' || $_[0] eq 'Uranus') {$PossibleDF = 1;}
		else {$PossibleDF = 0;}
	}
	elsif ($ATattribute eq 'Saturn') {
		if ($_[0] eq 'Jupiter' || $_[0] eq 'Uranus') {$PossibleDF = 1;}
		else {$PossibleDF = 0;}
	}
	elsif ($ATattribute eq 'Uranus') {
		if ($_[0] eq 'Pluto') {$PossibleDF = 1;}
		else {$PossibleDF = 0;}
	}
	elsif ($ATattribute eq 'Pluto') {
		if ($ATdetail eq 'DarkCloud') {$PossibleDF = 0;}
		else {$PossibleDF = 1;}
	}
}

#뻞뚥긓?깛긤궻븉맫?긃긞긏걁딉먘귩럊뾭궢궫뤾뜃궼MP귩뙵귞궥걂
sub DFcheck {
	#뻞뚥긓?깛긤궕롷궚궫뛘똼궸뫮돒궢궲궋궶궚귢궽긄깋?
	&ATvariety;
	
	if ($in{'OtherP'}) {
		if ($in{'OtherP'} > 16) {
			$I = $MyM[$in{'OtherP'} - 16];
		}
		else {
			$I = $MyJ[$in{'OtherP'}];
		}
		&PossibleDF($I);
		if (!$PossibleDF) {&Error;}
	}
	
	&DFcheckSub('Shield');
	&DFcheckSub('Armor');
	&DFcheckSub('Helm');
	&DFcheckSub('Gauntlet');
	&DFcheckSub('Boots');
	&DFcheckSub('Ring');
}

#뻞뚥긓?깛긤궻븉맫?긃긞긏걁'OtherP'댥둖귩귏궴귕궲걂
sub DFcheckSub {
	if ($in{"$_[0]"}) {
		&PossibleDF($MyJ[$in{"$_[0]"}]);
		if (!$PossibleDF) {&Error;}
	}
}

#긵깒?깛긣귩뤑돸궥귡
sub EatPresent {
	$EatPresentFlag = 1;
	
	$Shield = $MyJ[$in{'Shield'}];
	$Armor = $MyJ[$in{'Armor'}];
	$Helm = $MyJ[$in{'Helm'}];
	$Gauntlet = $MyJ[$in{'Gauntlet'}];
	$Boots = $MyJ[$in{'Boots'}];
	$Ring = $MyJ[$in{'Ring'}];
	if ($in{'OtherP'} <= 16) {
		$OtherP = $MyJ[$in{'OtherP'}];
		if ($Jmp[$OtherP] > 0) {
			&MiracleChange($OtherP);
		}
	}
	else {
		$OtherP = $MyM[$in{'OtherP'} - 16];
	}
	
	#뭁벲뻞뗰궻븉맫?긃긞긏
	if ($OtherP && $Jkind[$OtherP] ne 'OtherP' && $Jdetail[$OtherP] ne 'OtherP') {
		if ($Shield) {&Error;}
		elsif ($Armor) {&Error;}
		elsif ($Helm) {&Error;}
		elsif ($Gauntlet) {&Error;}
		elsif ($Boots) {&Error;}
		elsif ($Ring) {&Error;}
	}
	
	#딉먘럊뾭?딇궻룋렃귩?긃긞긏
	$UMflag = 0;
	if ($Jmp[$OtherP] > $in{'MP'}) {
		&UseMiracleCheck;
		if ($UMJ[0]) {
			$UMflag = 1;
			$UMdfNews = ":$X,UseMiracle,$OtherP,$MyJ[$UMJ[0]]";
			$EatNews .= $UMdfNews;
		}
	}
	
	#MP뤑뷂
	if ($Jmp[$OtherP] > 0 && !$UMflag) {
		$MP[$X] -= $Jmp[$OtherP];
	}
	
	#뛘똼쀍귩롦벦
	if ($Pcheck[3]) {
		$ATpoint = $Pcheck[3];
	}
	elsif ($Jpoint[$Pcheck[2]] >= 1000) {
		$ATpoint = 0;
	}
	else {
		$ATpoint = $Jpoint[$Pcheck[2]];
	}
	
	#긵깒?깛긣궻롰쀞빶궸뤑돸
	#댥돷궔귞뤑돸룉뿚걁?갂놞갂놟궻룈궸빁딌걂
	#??딇롻?
	#놞뭁벲뻞뗰귩럊뾭궥귡뤾뜃궻긵깒?깛긣뤑돸
	#놟믅륂궻긵깒?깛긣뤑돸
	
	$NotEatFlag = 0;
	#?딇롻?
	if ($Pcheck[1] eq 'Give') {
		$NotEatFlag = 1;
		if ($Pcheck[2]) {
			&SortJingi;
			if (!$MyJ[16]) {
				&NewJingi;
				
				$GiveNews = "";
				if ($GiftFlag) {
					if ($NJ > 0) {
						$GiveNews .= ":$X,Gift,$NJ";
						if ($Jkind[$NJ] eq 'Revive') {
							$GiveNewsPlus = ":$X,Gift,$NJ";
						}
					}
					else {
						$GiveNews .= ":$X,NotGift";
					}
				}
				else {
					if ($NJ > 0) {
						$GiveNews .= ":$X,DoGive,$NJ";
					}
					else {
						$GiveNews .= ":$X,NotGive";
					}
				}
				
				#닽뻷
				if ($Jdetail[$NJ] eq 'Devil') {
					$GiveNews .= ":$X,First,$NJ";
					&DamageGuard($Jpoint[$NJ]);
					$GiveNews .= $GuardNews;
				}
				#귽?긛깋?깛
				elsif ($Jdetail[$NJ] eq 'Itazuraman') {
					$I = int(rand(6)) + 1;
					$J = int(rand(10)) + 1;
					if ($I <= 3) {
						$I = 0;
						foreach (@MyJ) {
							if ($_) {$I++;}
						}
						
						if ($J <= 1) {$K = 16;}
						elsif ($J <= 3) {$K = 3;}
						elsif ($J <= 6) {$K = 2;}
						elsif ($J <= 10) {$K = 1;}
						
						if ($K > $I) {$K = $I;}
						
						if ($K > 0) {
							$GiveNews .= ":$X,First,$NJ:$X,LoseJ,Some";
							foreach (1..$K) {
								do {
									$I = int(rand(16));
								}
								while (!$MyJ[$I]);
								
								$GiveNews .= ":$X,LoseJ,$MyJ[$I],Hidden";
								&JnowUseAdd($MyJ[$I]);
								$MyJ[$I] = "";
							}
							&SortJingi;
						}
						else {
							$GiveNews .= ":$X,Miss,$NJ";
						}
					}
					elsif ($I <= 5) {
						if ($J <= 1) {$K = 990;}
						else {$K = $J * 20;}
						
						if ($K > $GP[$X]) {$K = $GP[$X];}
						
						if ($K > 0) {
							$GP[$X] -= $K;
							$GiveNews .= ":$X,Second,$NJ:$X,GPdown,$K";
						}
						else {
							$GiveNews .= ":$X,Miss,$NJ";
						}
					}
					elsif ($I <= 6) {
						$I = 0;
						foreach (@MyM) {
							if ($_) {$I++;}
						}
						
						if ($J <= 1) {$K = 6;}
						elsif ($J <= 4) {$K = 2;}
						else {$K = 1;}
						
						if ($K > $I) {$K = $I;}
						
						if ($K > 0) {
							$GiveNews .= ":$X,Third,$NJ";
							foreach (1..$K) {
								if (!$MyM[1]) {last;}
								
								$GiveNews .= ":$X,LoseM,$MyM[1]";
								splice(@MyM, 1, 1);
							}
							$Miracle[$X] = join(",", @MyM);
						}
						else {
							$GiveNews .= ":$X,Miss,$NJ";
						}
					}
				}
				#빍궻뾡맱
				elsif ($Jdetail[$NJ] eq 'PowderFairy') {
					$GiveNews .= ":$X,First,$NJ";
					$I = int(rand(4)) + 1;
					$J = int(rand(20)) * 10 + 10;
					if ($I == 1) {
						if (
							($MyCondition[0] && !$AllDiseaseMode)
							 || ($MyCondition[1] && !$AllFogMode)
							 || ($MyCondition[2] && !$AllFlashMode)
							 || ($MyCondition[3] && !$AllIllusionMode)
							 || ($MyCondition[4] && !$AllDarkCloudMode)
						) {
							if ($MyCondition[0] >= 7 && !$AllDiseaseMode) {
								$GiveNews .= ":$X,Heaven,$MyCondition[0],CureDisease";
							}
							elsif ($MyCondition[0] >= 5 && !$AllDiseaseMode) {
								$GiveNews .= ":$X,Hell,$MyCondition[0],CureDisease";
							}
							elsif ($MyCondition[0] >= 3 && !$AllDiseaseMode) {
								$GiveNews .= ":$X,StrongWind,$MyCondition[0],CureDisease";
							}
							elsif ($MyCondition[0] >= 1 && !$AllDiseaseMode) {
								$GiveNews .= ":$X,WeakWind,$MyCondition[0],CureDisease";
							}
							
							if ($MyCondition[0] && !$AllDiseaseMode) {
								$MyCondition[0] = 0;
							}
							if ($MyCondition[1] && !$AllFogMode) {
								$GiveNews .= ":$X,CureFog";
								$MyCondition[1] = 0;
							}
							if ($MyCondition[2] && !$AllFlashMode) {
								$GiveNews .= ":$X,CureFlash";
								$MyCondition[2] = 0;
							}
							if ($MyCondition[3] && !$AllIllusionMode) {
								$GiveNews .= ":$X,CureIllusion";
								$MyCondition[3] = 0;
							}
							if ($MyCondition[4] && !$AllDarkCloudMode) {
								$GiveNews .= ":$X,CureDarkCloud";
								$MyCondition[4] = 0;
							}
						}
						else {
							$GiveNews .= ":$X,DoNot";
						}
					}
					elsif ($I == 2) {
						$HP[$X] += $J;
						$GiveNews .= ":$X,HPup,$J";
					}
					elsif ($I == 3) {
						$MP[$X] += $J;
						$GiveNews .= ":$X,MPup,$J";
					}
					elsif ($I == 4) {
						$GP[$X] += $J;
						$GiveNews .= ":$X,GPup,$J";
					}
				}
				#믅륂?딇
				elsif ($NJ > 0) {
					$MyJ[16] = $NJ;
					&SortJingi;
				}
				
				if ($Jkind[$NJ] eq 'Creature') {
					&JnowUseAdd($NJ);
					$CreatureNews .= $GiveNews;
				}
				
				$EatNews .= $GiveNews;
			}
			else {
				if ($GiftFlag) {
					$EatNews .= ":$X,NotGift";
				}
				else {
					$EatNews .= ":$X,NotGive";
				}
			}
			
			$Pcheck[2]--;
			$MyPresent[1] = join(",", @Pcheck);
		}
		else {
			splice(@MyPresent, 1, 1);
			$Present[$X] = join("==", @MyPresent);
		}
	}
	#뙳둶뻞뚥
	elsif (
		$MyCondition[3]
		 && ($Pcheck[1] eq 'First' || $Pcheck[1] eq 'Second' || $Pcheck[1] eq 'Third' || $Pcheck[1] eq 'Mirror')
		 && !(
			$Pcheck[0] == $X || $Pcheck[1] eq 'Miss' || $Pcheck[1] eq 'Throw' || $Pcheck[1] eq 'Rope' || $Pcheck[1] eq 'Contribute'
			 || (
				(
					$Jdetail[$Pcheck[2]] eq 'MagicalRod'
					 || $Jpoint[$Pcheck[2]] >= 1000 || $Jfree[$Pcheck[2]] >= 1000
					 || $Jdetail[$Pcheck[2]] eq 'AllAct'
					 || $Jdetail[$Pcheck[2]] eq 'TargetAct'
					 || $Jdetail[$Pcheck[2]] eq 'GPabsorb'
				)
				 && !$Pcheck[3]
			)
		)
		 && ($OtherP || $Shield || $Armor || $Helm || $Gauntlet || $Boots || $Ring)
		 && rand(100) < 10
	) {
		$NotEatFlag = 1;
		$I = "";
		if ($OtherP) {
			if ($Jkind[$OtherP] eq 'OtherP' || $Jdetail[$OtherP] eq 'OtherP') {
				$I .= ":$X,Defense,$OtherP";
			}
			else {
				$I .= ":$X,Defense,$OtherP:$X,Second,$OtherP";
			}
		}
		if ($Shield) {$I .= ":$X,Defense,$Shield";}
		if ($Armor) {$I .= ":$X,Defense,$Armor";}
		if ($Helm) {$I .= ":$X,Defense,$Helm";}
		if ($Gauntlet) {$I .= ":$X,Defense,$Gauntlet";}
		if ($Boots) {$I .= ":$X,Defense,$Boots";}
		if ($Ring) {$I .= ":$X,Defense,$Ring";}
		
		&EatNews("$I:$X,IllusionDF");
	}
	#?깋?똭뻞뗰
	elsif (
		$Jdetail[$OtherP] eq 'SuperM'
		 || ($Jdetail[$OtherP] eq 'WeaponM' && $ATvariety eq 'Weapon')
		 || ($Jdetail[$OtherP] eq 'MiracleM' && $ATvariety eq 'Miracle')
	) {
		if ($Jfree[$OtherP]) {$ATpoint += $Jfree[$OtherP];}
		if ($ATvariety eq 'Weapon' || $ATvariety eq 'Miracle') {
			if ($AddNews && !$RingATflag) {
				$Present[$Pcheck[0]] .= "==$MyPresent[1]$AddNews";
			}
			else {
				$Present[$Pcheck[0]] .= "==$MyPresent[1]";
			}
			if ($AddMiracleNews) {
				$Present[$Pcheck[0]] .= $AddMiracleNews;
			}
			$Present[$Pcheck[0]] .= "$UMdfNews:$X,SoloDF,$OtherP:$X,Second,$OtherP:$Pcheck[0],Third,$OtherP,$ATpoint,$ATattribute:$X,Mirror,$Pcheck[2],$ATpoint,$ATattribute,$ATvariety,$ATdetail,$Pcheck[7]";
		}
		else {
			$N = $Pcheck[0];
			$Pcheck[0] = $X;
			$Pcheck[1] = 'Mirror';
			$PcheckJoin = join(",", @Pcheck);
			if ($AddNews && !$RingATflag) {
				$Present[$N] .= "==$MyPresent[1]$AddNews";
			}
			else {
				$Present[$N] .= "==$MyPresent[1]";
			}
			if ($AddMiracleNews) {
				$Present[$N] .= $AddMiracleNews;
			}
			$Present[$N] .= "$UMdfNews:$X,SoloDF,$OtherP:$X,Second,$OtherP:$PcheckJoin";
			
			$Pcheck[0] = $N;
		}
		
		#궼궺뺅궥몜롨궕궥궳궸뤈밮궢궲궋귡뤾뜃
		if ($HP[$Pcheck[0]] == 0) {
			&EatNews("$X,SoloDF,$OtherP:$X,Second,$OtherP:$Pcheck[0],Third,$OtherP,$ATpoint,$ATattribute:$Pcheck[0],BeNot");
			$Present[$Pcheck[0]] = "";
		}
		else {
			$EatNews .= ":$X,SoloDF,$OtherP:$X,Second,$OtherP";
			&UseProtector;
		}
	}
	#뭙궘똭뻞뗰
	elsif (
		($Jdetail[$OtherP] eq 'WeaponR' && $ATvariety eq 'Weapon')
		 || ($Jdetail[$OtherP] eq 'MiracleR' && $ATvariety eq 'Miracle')
	) {
		if ($Jfree[$OtherP]) {$ATpoint += $Jfree[$OtherP];}
		$N = &RandomPlayer;
		if ($AddNews && !$RingATflag) {
			$Present[$N] .= "==$MyPresent[1]$AddNews";
		}
		else {
			$Present[$N] .= "==$MyPresent[1]";
		}
		if ($AddMiracleNews) {
			$Present[$N] .= $AddMiracleNews;
		}
		$Present[$N] .= "$UMdfNews:$X,SoloDF,$OtherP:$X,Second,$OtherP:$N,Third,$OtherP,$ATpoint,$ATattribute:$X,Mirror,$Pcheck[2],$ATpoint,$ATattribute,$ATvariety,$ATdetail,$Pcheck[7]";
		$EatNews .= ":$X,SoloDF,$OtherP:$X,Second,$OtherP";
		&UseProtector;
	}
	#땪뢁똭뻞뗰
	elsif ($Jdetail[$OtherP] eq 'ATabsorb') {
		$HP[$X] += $ATpoint;
		&EatNews("$X,SoloDF,$OtherP:$X,Second,$OtherP:$X,HPup,$ATpoint");
	}
	#긳깓긞긏똭뻞뗰
	elsif ($Jdetail[$OtherP] eq 'WeaponB' || $Jdetail[$OtherP] eq 'MiracleB') {
		&EatNews("$X,SoloDF,$OtherP:$X,Second,$OtherP:$X,NoDamage");
	}
	#궩궻뫜
	elsif ($Pcheck[1] eq 'First' || $Pcheck[1] eq 'Second' || $Pcheck[1] eq 'Third' || $Pcheck[1] eq 'Mirror' || $Pcheck[1] eq 'GuardianAct') {
		#긵깒?깛긣궻롰쀞뵽믦귩믦?
		if (
			($Pcheck[1] eq 'GuardianAct' || $Pcheck[1] eq 'Mirror')
			 && $Pcheck[7] && $Pcheck[7] ne 'Earth'
		) {
			$Pkind = $Pcheck[2];
			$Pdetail = $Pcheck[2];
			$Ppoint = $Pcheck[3];
		}
		else {
			if ($Pcheck[2] || $Pcheck[1] ne 'Mirror') {
				$Pkind = $Jkind[$Pcheck[2]];
			}
			
			if ($ATdetail) {
				$Pdetail = $ATdetail;
			}
			else {
				$Pdetail = $Jdetail[$Pcheck[2]];
			}
			
			if ($Pkind eq 'Ring') {
				$Ppoint = $Pcheck[3];
			}
			else {
				$Ppoint = $Jpoint[$Pcheck[2]];
			}
			
			if ($Pkind eq 'Pray' && $Pdetail) {
				$Pkind = "";
			}
		}
		
		#긵깒?깛긣궻롰쀞빶궸뤑돸
		if ($Pkind eq 'Miss') {
			&EatNews();
		}
		elsif ($Pkind eq 'Pray') {
			$MenuNews = "";
		}
		elsif ($Pkind eq 'Sell') {
			$GP[$X] -= $Jprice[$Pcheck[3]];
			$GP[$Pcheck[0]] += $Jprice[$Pcheck[3]];
			if ($GP[$Pcheck[0]] > 990) {$GP[$Pcheck[0]] = 990;}
			
			&GPshortage;
			
			if (!$MyJ[16]) {
				$MyJ[16] = $Pcheck[3];
				&SortJingi;
				
				$I = "$X,MakeBuy,$Pcheck[3],$Damage";
			}
			else {
				&JnowUseAdd($Pcheck[3]);
				$I = "$X,MakeBuy,$Pcheck[3],$Damage:$X,Full,$Pcheck[3]";
			}
			
			&EatNews($I);
		}
		elsif ($Pkind eq 'Buy') {
			if ($Pcheck[1] eq 'Mirror') {
				if (!$Pcheck[3]) {$BuyCheck = 'First';}
				else {$BuyCheck = 'Second';}
			}
			if ($Pcheck[1] eq 'First' || $BuyCheck eq 'First') {
				if ($MyJ[1]) {
					do {
						$I = int(rand(16)) + 1;
					}
					while (!$MyJ[$I]);
					
					$Present[$Pcheck[0]] .= "==$MyPresent[1]:$X,Second,$Pcheck[2],$MyJ[$I]";
					if ($Pcheck[4] eq 'Fog') {$Present[$Pcheck[0]] .= ",,BuyFog";}
					$EatNews .= ":$X,Second,$Pcheck[2],$MyJ[$I]";
					$MyJ[$I] = "";
				}
				else {
					$EatNews .= ":$X,Miss,$Pcheck[2]";
				}
			}
			elsif ($Pcheck[1] eq 'Second' || $BuyCheck eq 'Second') {
				if ($in{'GP'} >= $Jprice[$Pcheck[3]] && !$MyJ[16]) {
					$GP[$X] -= $Jprice[$Pcheck[3]];
					$GP[$Pcheck[0]] += $Jprice[$Pcheck[3]];
					if ($GP[$Pcheck[0]] > 990) {$GP[$Pcheck[0]] = 990;}
					
					$MyJ[16] = $Pcheck[3];
					&SortJingi;
					
					if ($Pcheck[5] eq 'BuyFog') {$I = "$X,Buy,$Pcheck[3],,Fog";}
					else {$I = "$X,Buy,$Pcheck[3]";}
				}
				else {
					&JnowUseAdd($Pcheck[3]);
					
					if ($Pcheck[5] eq 'BuyFog') {$I = "$X,NotBuy,,,Fog";}
					else {$I = "$X,NotBuy";}
				}
				
				&EatNews($I);
			}
			else {&Error;}
		}
		elsif ($Pkind eq 'Release') {
			if ($Jattribute[$Pcheck[3]]) {
				$NewGuardian = $Jattribute[$Pcheck[3]];
			}
			elsif ($Jkind[$Pcheck[3]] eq 'Mirac') {
				$NewGuardian = 'Mirac';
			}
			elsif ($Jdetail[$Pcheck[3]] eq 'Earth') {
				$NewGuardian = 'Earth';
			}
			&GuardianFree($NewGuardian);
			if ($GuardianFree && $Jprice[$Pcheck[3]] > rand(100)) {
				$MyGuardian[0] = $NewGuardian;
				$MyGuardian[1] = $GuardianHP{"$NewGuardian"} + 50 - int(rand(11)) * 10;
				$Guardian[$X] = join(",", @MyGuardian);
				&EatNews("$X,Third,$Pcheck[2],$Pcheck[3]:$X,Guardian,$NewGuardian,Come");
			}
			else {
				&EatNews("$X,Miss,$Pcheck[2],$Pcheck[3]");
			}
		}
		elsif ($Pkind eq 'HPup') {
			$HP[$X] += $Ppoint;
			&EatNews("$X,HPup,$Ppoint");
		}
		elsif ($Pkind eq 'HPupDown') {
			if (rand(2) < 1) {
				$HP[$X] += $Ppoint;
				&EatNews("$X,HPup,$Ppoint");
			}
			else {
				$HP[$X] -= $Jfree[$Pcheck[2]];
				&EatNews("$X,Damage,$Jfree[$Pcheck[2]]");
			}
		}
		elsif ($Pkind eq 'MPup') {
			if ($Ppoint > 0) {
				$MP[$X] += $Ppoint;
				$K = "$X,MPup,$Ppoint";
			}
			else {
				$K = "$X,DoNot";
			}
			
			#밮뜎몢
			if ($Pdetail eq 'SelfHeaven') {
				$I = "";
				&GetDisease(7);
				$K .= $I;
			}
			
			&EatNews($K);
		}
		elsif ($Pkind eq 'GPup') {
			$GP[$X] += $Ppoint;
			&EatNews("$X,GPup,$Ppoint");
		}
		elsif ($Pkind eq 'ToneCure' || $Pkind eq 'SongCure') {
			$I = "";
			if ($MyCondition[0] && !$AllDiseaseMode) {
				if ($MyCondition[0] && $MyCondition[0] <= 2) {
					$I .= ":$X,WeakWind,$MyCondition[0],CureDisease";
					$MyCondition[0] = 0;
				}
				elsif ($MyCondition[0] && $MyCondition[0] <= 4) {
					$I .= ":$X,StrongWind,$MyCondition[0],CureDisease";
					$MyCondition[0] = 0;
				}
				
				if ($Pkind eq 'SongCure') {
					if ($MyCondition[0] && $MyCondition[0] <= 6) {
						$I .= ":$X,Hell,$MyCondition[0],CureDisease";
						$MyCondition[0] = 0;
					}
					elsif ($MyCondition[0] && $MyCondition[0] <= 7) {
						$I .= ":$X,Heaven,$MyCondition[0],CureDisease";
						$MyCondition[0] = 0;
					}
				}
			}
			
			if ($MyCondition[1] && !$AllFogMode) {
				$MyCondition[1] = 0;
				$I .= ":$X,CureFog";
			}
			if ($MyCondition[2] && !$AllFlashMode) {
				$MyCondition[2] = 0;
				$I .= ":$X,CureFlash";
			}
			
			if ($Pkind eq 'SongCure') {
				if ($MyCondition[3] && !$AllIllusionMode) {
					$MyCondition[3] = 0;
					$I .= ":$X,CureIllusion";
				}
				if ($MyCondition[4] && !$AllDarkCloudMode) {
					$MyCondition[4] = 0;
					$I .= ":$X,CureDarkCloud";
				}
			}
			
			if (!$I) {$I .= ":$X,DoNot";}
			&EatNews($I);
		}
		elsif ($Pdetail eq 'WeakWind') {
			$I = "";
			&GetDisease(1);
			&EatNews($I);
		}
		elsif ($Pdetail eq 'StrongWind') {
			$I = "";
			&GetDisease(3);
			&EatNews($I);
		}
		elsif ($Pdetail eq 'Hell') {
			$I = "";
			&GetDisease(5);
			&EatNews($I);
		}
		elsif ($Pdetail eq 'Heaven') {
			$I = "";
			&GetDisease(7);
			&EatNews($I);
		}
		elsif ($Pdetail eq 'Fog') {
			if (!$MyCondition[1]) {
				$MyCondition[1] = 1;
				&EatNews("$X,GetFog");
			}
			else {
				&EatNews("$X,DoNot");
			}
		}
		elsif ($Pdetail eq 'Flash') {
			if (!$MyCondition[2]) {
				$MyCondition[2] = 1;
				&EatNews("$X,GetFlash");
			}
			else {
				&EatNews("$X,DoNot");
			}
		}
		elsif ($Pdetail eq 'Illusion') {
			if (!$MyCondition[3]) {
				$MyCondition[3] = 1;
				&EatNews("$X,GetIllusion");
			}
			else {
				&EatNews("$X,DoNot");
			}
		}
		elsif ($Pdetail eq 'DarkCloud') {
			if (!$MyCondition[4]) {
				$MyCondition[4] = 1;
				&EatNews("$X,GetDarkCloud");
			}
			else {
				&EatNews("$X,DoNot");
			}
		}
		elsif ($Pdetail eq 'Sneeze') {
			$I = "";
			&GetDisease(5);
			if (!$MyCondition[1]) {
				$MyCondition[1] = 1;
				$I .= ":$X,GetFog";
			}
			if (!$MyCondition[2]) {
				$MyCondition[2] = 1;
				$I .= ":$X,GetFlash";
			}
			if (!$MyCondition[3]) {
				$MyCondition[3] = 1;
				$I .= ":$X,GetIllusion";
			}
			if (!$MyCondition[4]) {
				$MyCondition[4] = 1;
				$I .= ":$X,GetDarkCloud";
			}
			&EatNews($I);
		}
		elsif ($Pdetail eq 'GPabsorb') {
			if ($Ppoint > 0) {
				$GP[$X] -= $Ppoint;
				$GP[$Pcheck[0]] += $Ppoint;
				if ($GP[$Pcheck[0]] > 990) {$GP[$Pcheck[0]] = 990;}
				&GPshortage;
				&EatNews("$X,GPdown,$Ppoint,$Damage:$Pcheck[0],GPup,$Ppoint");
			}
			else {
				&EatNews("$X,DoNot");
			}
		}
		elsif ($Pkind eq 'Jug') {
			$I = $Pcheck[3] * 2;
			$HP[$X] += $I;
			&EatNews("$X,Second,$Pcheck[2]:$X,HPup,$I");
		}
		elsif ($Pdetail eq 'Broom') {
			$J = "$X,Second,$Pcheck[2]";
			if ($MyJ[1]) {$J .= ",1";}
			foreach (1..$Ppoint) {
				if (!$MyJ[1]) {last;}
				do {
					$I = int(rand(15)) + 1;
				}
				while (!$MyJ[$I]);
				
				$J .= ":$X,LoseJ,$MyJ[$I]";
				&JnowUseAdd($MyJ[$I]);
				splice(@MyJ, $I, 1);
			}
			&EatNews($J);
		}
		elsif ($Pdetail eq 'Soap') {
			$J = "$X,Second,$Pcheck[2]";
			if ($MyM[1]) {$J .= ",1";}
			foreach (1..$Ppoint) {
				if (!$MyM[1]) {last;}
				
				$J .= ":$X,LoseM,$MyM[1]";
				splice(@MyM, 1, 1);
			}
			$Miracle[$X] = join(",", @MyM);
			&EatNews($J);
		}
		elsif ($Pkind eq 'Pot') {
			do {
				$I = int(rand(100)) + 1;
				if ($I <= 70) {
					if ($I <= 3) {$Guardian = 'Mirac';}
					elsif ($I <= 6) {$Guardian = 'Earth';}
					elsif ($I <= 14) {$Guardian = 'Mercury';}
					elsif ($I <= 22) {$Guardian = 'Venus';}
					elsif ($I <= 30) {$Guardian = 'Mars';}
					elsif ($I <= 38) {$Guardian = 'Jupiter';}
					elsif ($I <= 46) {$Guardian = 'Saturn';}
					elsif ($I <= 54) {$Guardian = 'Uranus';}
					elsif ($I <= 62) {$Guardian = 'Neptune';}
					elsif ($I <= 70) {$Guardian = 'Pluto';}
					&GuardianFree($Guardian);
				}
				else {
					if ($I <= 80) {$Guardian = 'DevilS';}
					elsif ($I <= 90) {$Guardian = 'DevilM';}
					elsif ($I <= 100) {$Guardian = 'DevilL';}
					$GuardianFree = 1;
				}
			}
			while (!$GuardianFree);
			
			if ($I <= 70) {
				$MyGuardian[0] = $Guardian;
				$MyGuardian[1] = $GuardianHP{"$Guardian"} + 50 - int(rand(11)) * 10;
				$Guardian[$X] = join(",", @MyGuardian);
				&EatNews("$X,Guardian,$Guardian,Come");
			}
			else {
				&DamageGuard($GuardianHP{"$Guardian"});
				&EatNews("$X,Guardian,$Guardian,Appear:$X,Guardian,$Guardian,Attack$GuardNews");
			}
		}
		#?뼺궻궿귖
		elsif ($Pkind eq 'Rope') {
			$I = int(rand(100)) + 1;
			
			#HP500됷븳
			if ($I <= 10) {
				$HP[$X] += 500;
				&EatNews("$X,HPup,500");
			}
			#?딇5궰롻?
			elsif ($I <= 20) {
				$BonusGJ = 5;
				&EatNews("$X,Rope,GiveMany");
			}
			#멣덒HP10
			elsif ($I <= 30) {
				foreach (1..$PlayerMax) {
					if ($HP[$_] > 0) {
						$HP[$_] = 10;
						if ($_ != $X) {
							$Present[$_] = "==$X,First,$Pcheck[2],NewsOnly:$X,Rope,AllHPmin,NewsOnly"."$Present[$_]";
						}
					}
				}
				&EatNews("$X,Rope,AllHPmin");
			}
			#멣덒떗븮뷲
			elsif ($I <= 40) {
				foreach (1..$PlayerMax) {
					if ($_ == $X) {
						$MyCondition[0] = 3;
					}
					elsif ($HP[$_] > 0) {
						@YourCondition = split(/,/, $Condition[$_]);
						$YourCondition[0] = 3;
						$Condition[$_] = join(",", @YourCondition);
						
						$Present[$_] = "==$X,First,$Pcheck[2],NewsOnly:$X,Rope,AllStrongWind,NewsOnly"."$Present[$_]";
					}
				}
				&EatNews("$X,Rope,AllStrongWind");
			}
			#멣덒뼳
			elsif ($I <= 50) {
				foreach (1..$PlayerMax) {
					if ($_ == $X) {
						$MyCondition[1] = 1;
					}
					elsif ($HP[$_] > 0) {
						@YourCondition = split(/,/, $Condition[$_]);
						$YourCondition[1] = 1;
						$Condition[$_] = join(",", @YourCondition);
						
						$Present[$_] = "==$X,First,$Pcheck[2],NewsOnly:$X,Rope,AllFog,NewsOnly"."$Present[$_]";
					}
				}
				&EatNews("$X,Rope,AllFog");
			}
			#멣덒뙳둶
			elsif ($I <= 60) {
				foreach (1..$PlayerMax) {
					if ($_ == $X) {
						$MyCondition[3] = 1;
					}
					elsif ($HP[$_] > 0) {
						@YourCondition = split(/,/, $Condition[$_]);
						$YourCondition[3] = 1;
						$Condition[$_] = join(",", @YourCondition);
						
						$Present[$_] = "==$X,First,$Pcheck[2],NewsOnly:$X,Rope,AllIllusion,NewsOnly"."$Present[$_]";
					}
				}
				&EatNews("$X,Rope,AllIllusion");
			}
			#멣덒궻HP갂MP갂GP귩뗉뱳돸
			elsif ($I <= 70) {
				$HPsum = 0;
				$MPsum = 0;
				$GPsum = 0;
				$J = 0;
				foreach (1..$PlayerMax) {
					if ($HP[$_] > 0) {
						$HPsum += $HP[$_];
						$MPsum += $MP[$_];
						$GPsum += $GP[$_];
						$J++;
						$HPget[$_] = 0;
						$MPget[$_] = 0;
						$GPget[$_] = 0;
					}
				}
				
				$HPnew = int(($HPsum / 10) / $J) * 10;
				$HPremainder = ($HPsum / 10) % $J;
				while ($HPremainder > 0) {
					do {
						$K = &RandomPlayer;
					}
					while ($HPget[$K]);
					$HP[$K] = $HPnew + 10;
					$HPget[$K] = 1;
					$HPremainder--;
				}
				
				$MPnew = int(($MPsum / 10) / $J) * 10;
				$MPremainder = ($MPsum / 10) % $J;
				while ($MPremainder > 0) {
					do {
						$K = &RandomPlayer;
					}
					while ($MPget[$K]);
					$MP[$K] = $MPnew + 10;
					$MPget[$K] = 1;
					$MPremainder--;
				}
				
				$GPnew = int(($GPsum / 10) / $J) * 10;
				$GPremainder = ($GPsum / 10) % $J;
				while ($GPremainder > 0) {
					do {
						$K = &RandomPlayer;
					}
					while ($GPget[$K]);
					$GP[$K] = $GPnew + 10;
					$GPget[$K] = 1;
					$GPremainder--;
				}
				
				foreach (1..$PlayerMax) {
					if ($HP[$_] > 0) {
						if (!$HPget[$_]) {$HP[$_] = $HPnew;}
						if (!$MPget[$_]) {$MP[$_] = $MPnew;}
						if (!$GPget[$_]) {$GP[$_] = $GPnew;}
						
						if ($_ != $X) {
							$Present[$_] = "==$X,First,$Pcheck[2],NewsOnly:$X,Rope,Equalize,NewsOnly"."$Present[$_]";
						}
					}
				}
				
				&EatNews("$X,Rope,Equalize");
			}
			#멣덒궻룋렃?딇귩긘긿긞긲깑
			elsif ($I <= 80) {
				@Jshuffle = ();			#둫?딇궻릶
				$J = 0;				#뾞뙻롌궻릶
				$ShuffleJmax = 0;		#?딇궻몟릶
				foreach (1..$PlayerMax) {
					if ($HP[$_] > 0) {
						@YourJ = split(/,/, $Jingi[$_]);
						foreach $K (@YourJ) {
							if ($K) {
								$Jshuffle[$K]++;
								$ShuffleJmax++;
							}
						}
						$J++;
						$Jget[$_] = 0;
					}
				}
				
				$Jnew = int($ShuffleJmax / $J);
				$Jremainder = $ShuffleJmax % $J;
				
				#?딇궻몟릶궕뾞뙻롌궻릶궳뒆귟먛귢궶궋궶귞
				#돺릐궔궕1궰뫝궘?딇귩봹귞귢귡
				while ($Jremainder > 0) {
					do {
						$K = &RandomPlayer;
					}
					while ($Jget[$K] > 0);
					$Jget[$K] = $Jnew + 1;
					$Jremainder--;
				}
				
				#?딇귩봹귡
				foreach (1..$PlayerMax) {
					if ($HP[$_] > 0) {
						@YourJ = ();
						$YJ = 1;
						if ($Jget[$_] == 0) {$Jget[$_] = $Jnew;}
						
						while ($Jget[$_] > 0) {
							$RJ = int(rand($ShuffleJmax)) + 1;
							
							$K = @Jshuffle;
							foreach $L (1..$K) {
								$RJ -= $Jshuffle[$L];
								if ($RJ <= 0) {
									$YourJ[$YJ] = $L;
									$YJ++;
									$Jshuffle[$L]--;
									$ShuffleJmax--;
									$Jget[$_]--;
									last;
								}
							}
						}
						
						shift(@YourJ);
						@YourJ = sort by_Jnum (@YourJ);
						unshift(@YourJ, "");
						
						$Jingi[$_] = join(",", @YourJ);
						
						if ($_ != $X) {
							$Present[$_] = "==$X,First,$Pcheck[2],NewsOnly:$X,Rope,Jshuffle,NewsOnly"."$Present[$_]";
						}
					}
				}
				
				@MyJ = split(/,/, $Jingi[$X]);
				
				&EatNews("$X,Rope,Jshuffle");
			}
			#멣?밶궻몴뤑뽅
			elsif ($I <= 90) {
				foreach (1..$PlayerMax) {
					if ($HP[$_] > 0) {
						@YourStatue = split(/,/, $Statue[$_]);
						if ($YourStatue[0]) {
							foreach $J (1..4) {
								if ($YourStatue[$J]) {&JnowUseAdd($YourStatue[$J]);}
							}
						}
						$Statue[$_] = "";
						
						if ($_ == $X) {
							@MyStatue = ();
						}
						else {
							$Present[$_] = "==$X,First,$Pcheck[2],NewsOnly:$X,Rope,StatueVanish,NewsOnly"."$Present[$_]";
						}
					}
				}
				&EatNews("$X,Rope,StatueVanish");
			}
			#묿궔1릐궸?깋귽뿇돷걁AT500걂
			elsif ($I <= 100) {
				$J = &RandomPlayer;
				$Present[$J] .= "==$X,First,$Pcheck[2]:$X,Rope,Tub:$J,Rope,TubFall,500,$X,$Pcheck[2]";
				&EatNews("$X,Rope,Tub");
			}
		}
		#댥돷궼뛘똼쀍궻궇귡?딇
		else {
			$Damage = $ATpoint;
			$I = "";
			
			if ($OtherP) {
				$I .= ":$X,Defense,$OtherP";
				if ($Jkind[$OtherP] eq 'OtherP') {
					if ($Jdetail[$OtherP] eq 'MagicalP' && $in{'MP'} >= $Jfree[$OtherP]) {
						$MP[$X] -= $Jfree[$OtherP];
						$I .= ":$X,Second,$OtherP";
						$Damage -= $Jpoint[$OtherP] * 2;
					}
					else {$Damage -= $Jpoint[$OtherP];}
				}
				else {$Damage -= $Jfree[$OtherP];}
			}
			if ($Shield) {
				$I .= ":$X,Defense,$Shield";
				if ($Jkind[$Shield] eq 'Shield') {
					if ($Jdetail[$Shield] eq 'MagicalP' && $in{'MP'} >= $Jfree[$Shield]) {
						$MP[$X] -= $Jfree[$Shield];
						$I .= ":$X,Second,$Shield";
						$Damage -= $Jpoint[$Shield] * 2;
					}
					else {$Damage -= $Jpoint[$Shield];}
				}
				else {$Damage -= $Jfree[$Shield];}
			}
			if ($Armor) {
				$I .= ":$X,Defense,$Armor";
				if ($Jkind[$Armor] eq 'Armor') {
					if ($Jdetail[$Armor] eq 'MagicalP' && $in{'MP'} >= $Jfree[$Armor]) {
						$MP[$X] -= $Jfree[$Armor];
						$I .= ":$X,Second,$Armor";
						$Damage -= $Jpoint[$Armor] * 2;
					}
					else {$Damage -= $Jpoint[$Armor];}
				}
				else {$Damage -= $Jfree[$Armor];}
			}
			if ($Helm) {
				$I .= ":$X,Defense,$Helm";
				if ($Jkind[$Helm] eq 'Helm') {
					if ($Jdetail[$Helm] eq 'MagicalP' && $in{'MP'} >= $Jfree[$Helm]) {
						$MP[$X] -= $Jfree[$Helm];
						$I .= ":$X,Second,$Helm";
						$Damage -= $Jpoint[$Helm] * 2;
					}
					else {$Damage -= $Jpoint[$Helm];}
				}
				else {$Damage -= $Jfree[$Helm];}
				
				#뼯뙥귡뻏럔
				if ($Jdetail[$Helm] eq 'SelfIllusion' && !$MyCondition[3]) {
					$MyCondition[3] = 1;
					$I .= ":$X,Second,$Helm:$X,GetIllusion";
				}
			}
			if ($Gauntlet) {
				$I .= ":$X,Defense,$Gauntlet";
				if ($Jkind[$Gauntlet] eq 'Gauntlet') {
					if ($Jdetail[$Gauntlet] eq 'MagicalP' && $in{'MP'} >= $Jfree[$Gauntlet]) {
						$MP[$X] -= $Jfree[$Gauntlet];
						$I .= ":$X,Second,$Gauntlet";
						$Damage -= $Jpoint[$Gauntlet] * 2;
					}
					else {$Damage -= $Jpoint[$Gauntlet];}
				}
				else {$Damage -= $Jfree[$Gauntlet];}
			}
			if ($Boots) {
				$I .= ":$X,Defense,$Boots";
				if ($Jkind[$Boots] eq 'Boots') {
					if ($Jdetail[$Boots] eq 'MagicalP' && $in{'MP'} >= $Jfree[$Boots]) {
						$MP[$X] -= $Jfree[$Boots];
						$I .= ":$X,Second,$Boots";
						$Damage -= $Jpoint[$Boots] * 2;
					}
					else {$Damage -= $Jpoint[$Boots];}
				}
				else {$Damage -= $Jfree[$Boots];}
			}
			if ($Ring) {
				$I .= ":$X,Defense,$Ring";
				if ($Jkind[$Ring] eq 'Ring') {
					if ($Jdetail[$Ring] eq 'MagicalP' && $in{'MP'} >= $Jfree[$Ring]) {
						$MP[$X] -= $Jfree[$Ring];
						$I .= ":$X,Second,$Ring";
						$Damage -= $Jpoint[$Ring] * 2;
					}
					else {$Damage -= $Jpoint[$Ring];}
				}
				else {$Damage -= $Jfree[$Ring];}
			}
			
			#?긽?긙궕궇귡뤾뜃
			if ($Damage > 0) {
				&DamageGuard($Damage);
				$I .= $GuardNews;
				
				if ($ATdetail eq 'HPabsorb') {
					$HP[$Pcheck[0]] += $Damage;
					if ($HP[$Pcheck[0]] > 990) {$HP[$Pcheck[0]] = 990;}
					$I .= ":$Pcheck[0],HPup,$Damage";
				}
				
				if ($HP[$X] > 0) {
					if ($ATattribute eq 'Pluto') {
						if ($MyGuardian[0]) {
							$SinisterDamage = $MyGuardian[1];
							$MyGuardian[1] -= $SinisterDamage;
							$I .= ":$X,Sinister,$SinisterDamage";
							$I .= ":$X,Guardian,$MyGuardian[0],Lost";
							$MyGuardian[0] = "";
							$Guardian[$X] = ',0';
						}
						else {
							$SinisterDamage = $HP[$X];
							$HP[$X] -= $SinisterDamage;
							$I .= ":$X,Sinister,$SinisterDamage";
						}
					}
					elsif (!$MyGuardian[0] && !$DamageGuardFlag) {
						if ($ATdetail eq 'AddWeakWind') {
							&GetDisease(1);
						}
						elsif ($ATdetail eq 'AddStrongWind') {
							&GetDisease(3);
						}
						elsif ($ATdetail eq 'AddHell') {
							&GetDisease(5);
						}
						elsif ($ATdetail eq 'AddHeaven') {
							&GetDisease(7);
						}
						elsif ($ATdetail eq 'AddFog' && !$MyCondition[1]) {
							$MyCondition[1] = 1;
							$I .= ":$X,GetFog";
						}
						elsif ($ATdetail eq 'AddFlash' && !$MyCondition[2]) {
							$MyCondition[2] = 1;
							$I .= ":$X,GetFlash";
						}
						elsif ($ATdetail eq 'AddIllusion' && !$MyCondition[3]) {
							$MyCondition[3] = 1;
							$I .= ":$X,GetIllusion";
						}
						elsif ($ATdetail eq 'AddDarkCloud' && !$MyCondition[4]) {
							$MyCondition[4] = 1;
							$I .= ":$X,GetDarkCloud";
						}
					}
				}
			}
			#?긽?긙궕궶궋뤾뜃
			else {
				$I .= ":$X,NoDamage";
				$Damage = 0;
			}
			
			#궇귆궶궋긂긚
			if ($Pdetail eq 'Kine') {
				foreach (1..16) {
					if ($Jkind[$MyJ[$_]] eq 'Usu') {
						$I .= ":$X,First,$MyJ[$_]";
						&JnowUseAdd($MyJ[$_]);
						splice(@MyJ, $_, 1);
					}
				}
			}
			
			#럚쀖궻뚼됈
			if ($Ring) {
				$RingFree = $Damage;
				
				if ($Jdetail[$Ring] eq 'HPup') {
					$RingFree *= 2;
					$HP[$X] += $RingFree;
					$I .= ":$X,Second,$Ring:$X,HPup,$RingFree";
				}
				elsif ($Jdetail[$Ring] eq 'MPup') {
					$RingFree *= 2;
					$MP[$X] += $RingFree;
					$I .= ":$X,Second,$Ring:$X,MPup,$RingFree";
				}
				elsif ($Jdetail[$Ring] eq 'GPup') {
					$RingFree *= 2;
					$GP[$X] += $RingFree;
					$I .= ":$X,Second,$Ring:$X,GPup,$RingFree";
				}
				elsif ($Jdetail[$Ring] eq 'AllAct') {
					$AllAttackP = 50;
					foreach (1..$PlayerMax) {
						if ($HP[$_] > 0 && $_ != $X) {
							if ($_ == $Pcheck[0] || $AllAttackP > rand(100)) {
								$Hit = $RingFree;
								$Present[$_] .= "==$X,Defense,$Ring:$X,Second,$Ring,$Hit";
							}
							else {
								$Present[$_] .= "==$X,Defense,$Ring:$X,Second,$Ring";
							}
						}
					}
				}
				elsif ($Jdetail[$Ring] eq 'TargetAct') {
					$RingFree *= 2;
					$Present[$Pcheck[0]] .= "==$X,Defense,$Ring:$X,Second,$Ring,$RingFree";
				}
				elsif ($Jdetail[$Ring] eq 'GPabsorb') {
					$RingFree *= 2;
					$Present[$Pcheck[0]] .= "==$X,Defense,$Ring:$X,Second,$Ring,$RingFree";
				}
				else {
					$Present[$Pcheck[0]] .= "==$X,Defense,$Ring:$X,Second,$Ring";
				}
			}
			
			&EatNews($I);
		}
	}
	#뷲
	elsif ($Pcheck[1] eq 'WeakWind' || $Pcheck[1] eq 'StrongWind' || $Pcheck[1] eq 'Hell' || $Pcheck[1] eq 'Heaven') {
		$I = "";
		if ($Pcheck[3] eq 'Infect') {
			$MyCondition[0] = $Pcheck[2];
		}
		elsif (($Pcheck[3] eq 'Fit' || $Pcheck[3] eq 'Worse') && $Pcheck[2] == $MyCondition[0]) {
			$MyCondition[0]++;
			
			if ($MyCondition[0] <= 7) {
				$I .= ":$X,$Pcheck[4],$MyCondition[0],$Pcheck[5],$Pcheck[6]";
				
				if ($Pcheck[5] eq 'Damage' || $Pcheck[5] eq 'FitDamage') {
					$HP[$X] -= $Pcheck[6];
				}
				elsif ($Pcheck[5] eq 'HPup') {
					$HP[$X] += $Pcheck[6];
				}
			}
			else {
				$I .= ":$X,Heaven,8,FitDamage,$HP[$X]";
				$HP[$X] = 0;
			}
		}
		elsif ($Pcheck[3] eq 'Damage' || $Pcheck[3] eq 'FitDamage') {
			$HP[$X] -= $Pcheck[4];
		}
		elsif ($Pcheck[3] eq 'HPup') {
			$HP[$X] += $Pcheck[4];
		}
		&EatNews($I);
	}
	#?뼺궻궿귖
	elsif ($Pcheck[1] eq 'Rope') {
		if ($Pcheck[2] eq 'TubFall') {
			&DamageGuard($Pcheck[3]);
			&EatNews($GuardNews);
		}
	}
	#뺳귟뱤궛귡
	elsif ($Pcheck[1] eq 'Throw') {
		&EatNews("$X,DoNot");
	}
	#뛘똼?긚갂떉궑븿듫똚
	elsif ($Pcheck[1] eq 'Miss' || $Pcheck[1] eq 'Contribute') {
		&EatNews();
	}
	
	#뤑돸궢궫긵깒?깛긣귩뙵귞궥
	if (!$NotEatFlag) {
		@MyPresent = split(/==/, $Present[$X]);
		splice(@MyPresent, 1, 1);
		$Present[$X] = join("==", @MyPresent);
	}
	
	#딉먘럊뾭?딇귩럊궯궫궴궖
	if ($UMflag) {
		&JnowUseAdd($MyJ[$UMJ[0]]);
		$MyJ[$UMJ[0]] = "";
		$GetJingi++;
	}
	
	#??긥긚?딇
	if ($BonusGJ) {
		$GetJingi += $BonusGJ;
		$BonusGJ = 0;
	}
	
	#롻??딇
	if ($GetJingi > 0) {
		shift(@MyPresent);
		unshift(@MyPresent, "$X,Give,$GetJingi");
		unshift(@MyPresent, "");
		$GetJingi = 0;
	}
	
	#HP궕0궸궶궯궫궴궖궴1000댥뤵궸궶궯궫궴궖궶궵
	if ($HP[$X] <= 0 && !$LostCheckFlag) {&LostCheck;}
	if ($HP[$X] > 990) {$HP[$X] = 990;}
	if ($MP[$X] > 990) {$MP[$X] = 990;}
	if ($GP[$X] > 990) {$GP[$X] = 990;}
	
	#롻??딇걁븳뒋궢궫궴궖궻빁걂
	if ($GetJingi > 0) {
		shift(@MyPresent);
		unshift(@MyPresent, "$X,Give,$GetJingi");
		unshift(@MyPresent, "");
		$GetJingi = 0;
	}
	
	#긽긦깄?됪뽋궸?렑궠귢귡긦깄?긚
	$TargetShow = 'No';
	if (!$LostCheckFlag) {
		&ShrineNews($EatNews);
		if ($CreatureNews) {
			&NewsChange($CreatureNews);
			$CreatureNews = "";
		}
	}
	if (
		$Pcheck[1] ne 'Give'
		 && !($Pcheck[1] eq 'Rope' && $Pcheck[2] ne 'TubFall')
		 && $Pcheck[1] ne 'Contribute'
		 && !$LostNewsFlag
	) {
		if ($MenuNews) {
			&NewsChange($MenuNews);
			$MenuNews = "";
		}
	}
	
	#븉뾴궶긦깄?긚귩뤑궥
	if ($AddMiracleNews) {
		$AddMiracleNews = "";
	}
	
	$EatPresentFlag = 0;
}

#긵깒?깛긣궻뤑돸귩긦깄?긚궸딯?갂궶궵
sub EatNews {
	$EatNews .= ":$_[0]";
	
	#긽긦깄?됪뽋궸?렑궠귢귡긦깄?긚
	if ($Pcheck[2] eq 'TubFall') {
		$MenuNews = "$X,Rope,TubFall:$_[0]";
		$TubFallNews = "$Pcheck[4],First,$Pcheck[5]:$Pcheck[4],Rope,Tub";
	}
	elsif ($Pcheck[1] eq 'Mirror') {		#멣뫬뛘똼귩궼궺뺅궢궫궴궖긦깄?긚궻??귩뤙뿪
		$MirrorNews = "$MyPresent[1]";
		$MirrorCount = 0;
		@MirrorPresent = split(/:/, $MyPresent[1]);
		foreach (@MirrorPresent) {
			$MirrorCount++;
			@MirrorCheck = split(/,/, $_);
			if (
				(
					$MirrorCheck[1] eq 'Second'
					 && ($Jpoint[$MirrorCheck[2]] >= 1000 || $Jfree[$MirrorCheck[2]] >= 1000)
				)
				 || ($MirrorCheck[1] eq 'GuardianAct' && $MirrorCheck[2] eq 'AllAct')
			) {
				@MirrorRemove = splice(@MirrorPresent, 0, $MirrorCount);
				$MirrorNews = join(":", @MirrorPresent);
				last;
			}
		}
		
		$MenuNews = "$MirrorNews$UMdfNews:$_[0]";
	}
	elsif ($AddNews) {
		$MenuNews = "$AddNews$UMdfNews:$_[0]";
		$LastRingNews = $_[0];
	}
	elsif ($AddMiracleNews) {
		$MenuNews = "$MyPresent[1]$AddMiracleNews$UMdfNews:$_[0]";
		$AddMiracleNews = "";
	}
	else {
		$MenuNews = "$MyPresent[1]$UMdfNews:$_[0]";
	}
	
	&UseProtector;
}

#?딇궻럊뾭띙귒릶귩딯?갂룋렃?딇궔귞뙵귞궥갂롻??딇귩몵귘궥
sub UseProtector {
	$GetJingi = 0;
	if ($Shield) {&JnowUseAdd($Shield); $MyJ[$in{'Shield'}] = ""; $in{'Shield'} = 0; $Shield = ""; $GetJingi++;}
	if ($Armor) {&JnowUseAdd($Armor); $MyJ[$in{'Armor'}] = ""; $in{'Armor'} = 0; $Armor = ""; $GetJingi++;}
	if ($Helm) {&JnowUseAdd($Helm); $MyJ[$in{'Helm'}] = ""; $in{'Helm'} = 0; $Helm = ""; $GetJingi++;}
	if ($Gauntlet) {&JnowUseAdd($Gauntlet); $MyJ[$in{'Gauntlet'}] = ""; $in{'Gauntlet'} = 0; $Gauntlet = ""; $GetJingi++;}
	if ($Boots) {&JnowUseAdd($Boots); $MyJ[$in{'Boots'}] = ""; $in{'Boots'} = 0; $Boots = ""; $GetJingi++;}
	if ($Ring) {&JnowUseAdd($Ring); $MyJ[$in{'Ring'}] = ""; $in{'Ring'} = 0; $Ring = ""; $GetJingi++;}
	if ($OtherP) {
		if ($in{'OtherP'} <= 16) {
			&JnowUseAdd($OtherP);
			$MyJ[$in{'OtherP'}] = "";
		}
		$in{'OtherP'} = 0;
		$OtherP = "";
		$GetJingi++;
	}
	
	#딉먘럊뾭?딇귩럊뾭궢궫궴궖궻긦깄?긚귩뤑궥
	$UMdfNews = "";
}

#GP궕븉뫉궢궲궋귡뤾뜃
sub GPshortage {
	$Damage = 0;
	if ($GP[$X] < 0) {
		$Shortage = $GP[$X] * (-1);
		$GP[$X] = 0;
		
		if ($in{'MP'} >= $Shortage) {
			$MP[$X] -= $Shortage;
			
			if ($MP[$X] < 0) {
				$Damage = $MP[$X] * (-1);
			}
		}
		else {
			$MP[$X] -= $in{'MP'};
			$Shortage -= $in{'MP'};
			
			$Damage = $Shortage;
		}
	}
	$HP[$X] -= $Damage;
}

#뷲궸궔궔궯궫뤾뜃
sub GetDisease {
	if ($MyCondition[0] < $_[0]) {
		if ($_[0] == 1) {
			$MyCondition[0] = $_[0];
			$I .= ":$X,WeakWind,$MyCondition[0],GetDisease";
		}
		elsif ($_[0] == 3) {
			$MyCondition[0] = $_[0];
			$I .= ":$X,StrongWind,$MyCondition[0],GetDisease";
		}
		elsif ($_[0] == 5) {
			$MyCondition[0] = $_[0];
			$I .= ":$X,Hell,$MyCondition[0],GetDisease";
		}
		else {
			$MyCondition[0] = $_[0];
			$I .= ":$X,Heaven,$MyCondition[0],GetDisease";
		}
	}
	else {
		if ($MyCondition[0] == 1) {$I .= ":$X,WeakWind,$MyCondition[0],Fit";}
		elsif ($MyCondition[0] == 2) {$I .= ":$X,WeakWind,$MyCondition[0],Worse";}
		elsif ($MyCondition[0] == 3) {$I .= ":$X,StrongWind,$MyCondition[0],Fit";}
		elsif ($MyCondition[0] == 4) {$I .= ":$X,StrongWind,$MyCondition[0],Worse";}
		elsif ($MyCondition[0] == 5) {$I .= ":$X,Hell,$MyCondition[0],Fit";}
		elsif ($MyCondition[0] == 6) {$I .= ":$X,Hell,$MyCondition[0],Worse";}
		elsif ($MyCondition[0] == 7) {
			$J = $MyCondition[0] + 1;
			$I .= ":$X,Heaven,$MyCondition[0],Fit:$X,Heaven,$J,FitDamage,$HP[$X]";
			$HP[$X] = 0;
		}
		$MyCondition[0]++;
	}
}

#HP궕0궸궶궯궫궴궖
sub LostCheck {
	$LostCheckFlag = 1;
	$HP[$X] = 0;
	&ConditionReset;
	
	$LastPresentFlag = 1;
	
	#둫롰긦깄?긚
	if ($CreatureNews) {
		$MenuNews .= $CreatureNews;
		$CreatureNews = "";
	}
	if (!$GiftFlag) {
		$EatNews .= ":$X,HPzero";
		$MenuNews .= ":$X,HPzero";
	}
	
	#븳뒋룉뿚
	&Revive;
	
	#?딇롻?긵깒?깛긣궼뤑돸
	while ($MyPresent[1] && $HP[$X] <= 0) {
		@OldPresent = split(/:/, $MyPresent[1]);
		$I = pop(@OldPresent);
		@Pcheck = split(/,/, $I);
		
		if ($Pcheck[0] == $X && $Pcheck[1] eq 'Give') {
			&EatPresent;
			&Revive;
		}
		else {
			last;
		}
	}
	
	#뫞뾸?궔귞궓뙥븨궋
	@MyPresentSub = @MyPresent;
	if ($HP[$X] <= 0 && !$GiftFlag && !$RemoveFlag) {
		$HP[$X] = 0;
		&ConditionReset;
		
		$GiftFlag = 1;
		@Pcheck = ("$X","Give","1");
		&EatPresent;
		$MenuNews .= $GiveNewsPlus;
		$GiveNewsPlus = "";
		&Revive;
	}
	@MyPresent = @MyPresentSub;
	
	#둫롰긦깄?긚
	if ($CreatureNews) {
		$MenuNews .= $CreatureNews;
		$CreatureNews = "";
	}
	
	#뤈밮뙂믦
	if ($HP[$X] <= 0) {
		#뤈밮?
		if (!$RemoveFlag) {
			foreach (@MyJ) {
				if ($Jdetail[$_] eq 'LostAT') {
					$EatNews .= ":$X,LostAT:$X,First,$_,LostAT:$X,Second,$_";
					$MenuNews .= ":$X,LostAT:$X,First,$_,LostAT:$X,Second,$_";
					
					$AllAttackP = int($Jfree[$_] / 1000) * 25;
					foreach $I (1..$PlayerMax) {
						if ($HP[$I] > 0 && $I != $X) {
							if ($AllAttackP > rand(100)) {
								$Hit = $Jfree[$_] % 1000;
								$Present[$I] .= "==$X,LostAT:$X,First,$_,LostAT:$X,Second,$_,$Hit";
							}
							else {
								$Present[$I] .= "==$X,LostAT:$X,First,$_,LostAT:$X,Second,$_,LostATmiss";
							}
						}
					}
				}
			}
		}
		
		#룋렃뷼궻?룣
		$Jingi[$X] = join(",", @MyJ);
		$Statue[$X] = join(",", @MyStatue);
		$Present[$X] = join("==", @MyPresent);
		&MyClean($X);
		@MyPresent = ();
		@MyCondition = ();
		
		$I = 0;
		foreach (1..$PlayerMax) {
			if ($HP[$_] > 0) {$I++;}
		}
		
		if ($I > 0) {
			$EatNews .= ":$X,Lost";
			$MenuNews .= ":$X,Lost";
			$LastRingLost = ":$X,Lost";
		}
		else {
			$EatNews .= ":$X,Draw";
			$MenuNews .= ":$X,Draw";
			$LastRingLost = ":$X,Draw";
		}
		&ShrineNews($EatNews);
		&NewsChange($MenuNews);
		
		if ($AfterPresent[0]) {
			foreach (@AfterPresent) {
				&NewsChange($_);
			}
			@AfterPresent = ();
		}
		
		&WriteLog;
		
		#맟봲딯긲?귽깑궸룕궖뜛귒
		$I = $GFyear - 1;
		if ($AddNews) {
			if ($RingATflag) {
				&WriteJudgment("$I:$X:$LastPresent$UMdfNews:$LastRingNews:$X,HPzero$LastRingLost");
			}
			else {
				&WriteJudgment("$I:$X:$LastPresent$MenuNews");
			}
			$LastPresentFlag = 0;
		}
		elsif ($TubFallNews) {
			&WriteJudgment("$I:$X:$TubFallNews:$MenuNews");
		}
		elsif ($MirrorNews) {
			$MirrorRemoveNews = join(":", @MirrorRemove);
			&WriteJudgment("$I:$X:$MirrorRemoveNews:$MenuNews");
		}
		else {
			&WriteJudgment("$I:$X:$MenuNews");
		}
		
		if (!$RemoveFlag) {
			&ATshrine;
		}
		else {
			$EatNews = "";
			$MenuNews = "";
			$LostNewsFlag = 0;
			$LostCheckFlag = 0;
			$GiftFlag = 0;
			$X = $in{'Number'};
			&Menu;
		}
	}
	elsif (!$LostNewsFlag) {
		&ShrineNews($EatNews);
		&NewsChange($MenuNews);
		$MenuNews = "";
		$LostNewsFlag = 1;
	}
	
	$LostNewsFlag = 0;
	$LostCheckFlag = 0;
	$GiftFlag = 0;
}

#븳뒋룉뿚
sub Revive {
	#딉먘럊뾭?딇궻룋렃귩?긃긞긏
	&UseMiracleCheck;
	
	#븳뒋룉뿚걁룋렃?딇걂
	if ($HP[$X] <= 0) {
		$HP[$X] = 0;
		&ConditionReset;
		foreach (0..16) {
			$_ = 16 - $_;
			if (
				$Jkind[$MyJ[$_]] eq 'Revive'
				 && ($MP[$X] >= $Jmp[$MyJ[$_]] || $UMJ[0])
			) {
				$HP[$X] = $Jpoint[$MyJ[$_]];
				if (
					$UMJ[0]
					 && ($in{'MP'} < $Jmp[$MyJ[$_]] || $MP[$X] < $Jmp[$MyJ[$_]])
				) {
					$EatNews .= ":$X,UseMiracle,$MyJ[$_],$MyJ[$UMJ[0]]";
					$MenuNews .= ":$X,UseMiracle,$MyJ[$_],$MyJ[$UMJ[0]]";
					
					&JnowUseAdd($MyJ[$UMJ[0]]);
					$MyJ[$UMJ[0]] = "";
					
					&MiracleChange($MyJ[$_]);
				}
				elsif ($Jmp[$MyJ[$_]] > 0) {
					$MP[$X] = 0;
					&MiracleChange($MyJ[$_]);
				}
				$GetJingi++;
				$EatNews .= ":$X,First,$MyJ[$_]:$X,Second,$MyJ[$_]";
				$MenuNews .= ":$X,First,$MyJ[$_]:$X,Second,$MyJ[$_]";
				&JnowUseAdd($MyJ[$_]);
				$MyJ[$_] = "";
				last;
			}
		}
	}
	#븳뒋룉뿚걁뢐벦딉먘걂
	if ($HP[$X] <= 0) {
		$HP[$X] = 0;
		&ConditionReset;
		foreach (1..6) {
			if (
				$Jkind[$MyM[$_]] eq 'Revive'
				 && ($MP[$X] >= $Jmp[$MyM[$_]] || $UMJ[0])
			) {
				$HP[$X] = $Jpoint[$MyM[$_]];
				if (
					$UMJ[0]
					 && ($in{'MP'} < $Jmp[$MyM[$_]] || $MP[$X] < $Jmp[$MyM[$_]])
				) {
					$EatNews .= ":$X,UseMiracle,$MyJ[$_],$MyJ[$UMJ[0]]";
					$MenuNews .= ":$X,UseMiracle,$MyJ[$_],$MyJ[$UMJ[0]]";
					
					&JnowUseAdd($MyJ[$UMJ[0]]);
					$MyJ[$UMJ[0]] = "";
				}
				else {
					$MP[$X] = 0;
				}
				$GetJingi++;
				$EatNews .= ":$X,First,$MyM[$_]:$X,Second,$MyM[$_]";
				$MenuNews .= ":$X,First,$MyM[$_]:$X,Second,$MyM[$_]";
				last;
			}
		}
	}
}

#륉뫴댶륂궻룊딖돸
sub ConditionReset {
	if (!$AllDiseaseMode || $MyCondition[0] > 7) {$MyCondition[0] = 0;}
	if (!$AllFogMode) {$MyCondition[1] = 0;}
	if (!$AllFlashMode) {$MyCondition[2] = 0;}
	if (!$AllIllusionMode) {$MyCondition[3] = 0;}
	if (!$AllDarkCloudMode) {$MyCondition[4] = 0;}
	$Condition[$X] = join(",", @MyCondition);
}

#봲뫿렄궻룋렃뷼궻?룣
sub MyClean {
	$HP[$_[0]] = 0;
	
	#룋렃?딇궻봨딙
	@YourJ = split(/,/, $Jingi[$_[0]]);
	foreach (@YourJ) {
		if ($_) {&JnowUseAdd($_);}
	}
	$Jingi[$_[0]] = "";
	
	#몴궻봨딙
	@YourStatue = split(/,/, $Statue[$_[0]]);
	foreach (1..4) {
		if ($YourStatue[$_]) {&JnowUseAdd($YourStatue[$_]);}
	}
	$Statue[$_[0]] = "";
	
	#롧뚯?궻봨딙
	$Guardian[$_[0]] = "";
	
	#긵깒?깛긣궻봨딙
	@YourPresent = split(/==/, $Present[$_[0]]);
	foreach (@YourPresent) {
		@EachPresent = split(/:/, $_);
		$I = pop(@EachPresent);
		@Pclean = split(/,/, $I);
		
		#봽귡갂봼궎궸귝귟댷벍뭷궻?딇귩긇긂깛긣
		if ($Jkind[$Pclean[2]] eq 'Sell' || ($Jkind[$Pclean[2]] eq 'Buy' && $Pclean[3])) {
			if ($Pclean[3]) {&JnowUseAdd($Pclean[3]);}
		}
		
		#?깋?똭갂뭙궘똭궻긵깒?깛긣궕뤑돸멟궸뤈밮궢궫뤾뜃
		$AP = 0;
		if ($Pclean[1] eq 'Mirror') {
			$AfterPresent[$AP] = "$_:$_[0],BeNot";
			$AP++;
		}
	}
	$Present[$_[0]] = "";
	
	#뢐벦딉먘궻봨딙
	$Miracle[$_[0]] = "";
	
	#륉뫴댶륂궻봨딙
	$Condition[$_[0]] = "";
}

#--------------
#각종 서브루틴
#--------------

#륷딮랷돿긲긅??
sub EntryForm {
	&PlayerCheck;
	
	if ($I < $PlayerMax) {
		$EntryForm = <<END_OF_ENTRYFORM;
<B>새로운 신전을 건립할 수 있습니다.</B><BR>
<BR>
<FORM ACTION="$ThisFile" METHOD="POST">
이름<BR>
<INPUT TYPE="text" NAME="Name" MAXLENGTH=20 CLASS="form"><BR>
<BR>
주문<BR>
<INPUT TYPE="password" NAME="Password" SIZE=10 MAXLENGTH=8 CLASS="form"><BR>
<BR>
주문(확인을 위해 다시한번)<BR>
<INPUT TYPE="password" NAME="PassAgain" SIZE=10 MAXLENGTH=8 CLASS="form"><BR>
<BR>
<INPUT TYPE="hidden" NAME="Mode" VALUE="Entry">
<INPUT TYPE="button" VALUE="  신전을 건립한다.  " onClick="EntryCheck(this.form)" CLASS="button"><BR>
</FORM>
END_OF_ENTRYFORM
	}
	else {
		$EntryForm = '<B>신전의 수는 이미 충분합니다. 새로운 신전을 건립할 수 없습니다.</B><BR>';
	}
}

#긒??뢎뿹?긃긞긏
sub WinnerCheck {
	$I = 0;
	$J = 0;
	foreach (1..$PlayerMax) {
		if ($HP[$_] > 0) {$I++; $J = $_;}
	}
	
	if ($I == 1 && !$Present[$J] && $News[1] eq "$J,Win") {$Winner = $J;}
	else {$Winner = 0;}
	
	if ($I == 0) {$DrawFlag = 1;}
}

#룉뿚궻뫮뤭궴궶귡랷돿롌궻룋렃륃뺪
sub MyData {
	$TotalP = $HP[$_[0]] + $MP[$_[0]] + $GP[$_[0]];		#HP궴MP궴GP궻뜃똶뭠
	@MyJ = split(/,/, $Jingi[$_[0]]);			#룋렃?딇귩롦벦
	@MyM = split(/,/, $Miracle[$_[0]]);			#뢐벦딉먘귩롦벦
	@MyCondition = split(/,/, $Condition[$_[0]]);		#륉뫴댶륂귩롦벦
	@MyStatue = split(/,/, $Statue[$_[0]]);			#몴귩롦벦
	@MyGuardian = split(/,/, $Guardian[$_[0]]);		#롧뚯?귩롦벦
	@MyPresent = split(/==/, $Present[$_[0]]);		#긵깒?깛긣귩롦벦
}

#랷돿롌궻둴봃
sub PlayerCheck {
	$I = 0;
	foreach (1..$PlayerMax) {
		if ($Name[$_]) {
			$Player[$I] = $_;
			$I++;
		}
	}
}

#랷돿롌궻뭷궔귞깋깛??궳덇릐멗귆
sub RandomPlayer {
	do {
		$RP = int(rand($PlayerMax)) + 1;
	}
	while (!($HP[$RP] > 0));
	
	return $RP;
}

#HP갂MP갂GP귩몧륕
sub HPdeco {
	$HPdeco = "";
	$MPdeco = "";
	$GPdeco = "";
	
	if ($HP[$_[0]] > 0) {
		if ($HP[$_[0]] >= 100) {$HPdeco = $HP[$_[0]];}
		else {$HPdeco = "<FONT COLOR=$ColorDamage>$HP[$_[0]]</FONT>";}
		$MPdeco = $MP[$_[0]];
		$GPdeco = $GP[$_[0]];
	}
	else {
		$HPdeco = "<FONT COLOR=$ColorLost>$HP[$_[0]]</FONT>";
		$MPdeco = "<FONT COLOR=$ColorLost>$MP[$_[0]]</FONT>";
		$GPdeco = "<FONT COLOR=$ColorLost>$GP[$_[0]]</FONT>";
	}
}

#륉뫴귩몧륕
sub ConditionDeco {
	$ConditionDeco = "";
	
	@YourCondition = split(/,/, $Condition[$_[0]]);
	if ($YourCondition[0]) {			#뷲
		$I = $YourCondition[0];
		$ConditionDeco = "<IMG SRC=\"$ImgCondition{\"Disease$I\"}\" ALT=\"$ConditionName{\"Disease$I\"}\" TITLE=\"$ConditionName{\"Disease$I\"}\" WIDTH=\"50\" HEIGHT=\"20\">  ";
	}
	if ($YourCondition[1]) {			#뼳
		$ConditionDeco .= "<IMG SRC=\"$ImgCondition{\"Fog\"}\" ALT=\"$ConditionName{\"Fog\"}\" TITLE=\"$ConditionName{\"Fog\"}\" WIDTH=\"50\" HEIGHT=\"20\">  ";
	}
	if ($YourCondition[2]) {			#멝뚹
		$ConditionDeco .= "<IMG SRC=\"$ImgCondition{\"Flash\"}\" ALT=\"$ConditionName{\"Flash\"}\" TITLE=\"$ConditionName{\"Flash\"}\" WIDTH=\"50\" HEIGHT=\"20\">  ";
	}
	if ($YourCondition[3]) {			#뙳둶
		$ConditionDeco .= "<IMG SRC=\"$ImgCondition{\"Illusion\"}\" ALT=\"$ConditionName{\"Illusion\"}\" TITLE=\"$ConditionName{\"Illusion\"}\" WIDTH=\"50\" HEIGHT=\"20\">  ";
	}
	if ($YourCondition[4]) {			#댠?
		$ConditionDeco .= "<IMG SRC=\"$ImgCondition{\"DarkCloud\"}\" ALT=\"$ConditionName{\"DarkCloud\"}\" TITLE=\"$ConditionName{\"DarkCloud\"}\" WIDTH=\"50\" HEIGHT=\"20\">  ";
	}
	
	if (!$ConditionDeco) {$ConditionDeco = '-';}
}

#몴귩몧륕
sub StatueDeco {
	$StatueDeco = "";
	
	if ($_[0] == $X) {
		@YourStatue = @MyStatue;
	}
	else {
		@YourStatue = split(/,/, $Statue[$_[0]]);
	}
	
	if ($YourStatue[0]) {
		$I = $YourStatue[0];
		$StatueDeco = "<IMG SRC=\"$ImgStatue{\"$Jkind[$I]\"}\" ALT=\"$Jname[$I]\" TITLE=\"$Jname[$I]\" BORDER=0 WIDTH=\"50\" HEIGHT=\"40\">";
	}
	else {
		$StatueDeco = "<IMG SRC=\"$ImgStatue{'Blank'}\" ALT='신상없음' TITLE='신상없음' WIDTH=\"50\" HEIGHT=\"40\">";
	}
}

#롧뚯?귩몧륕
sub GuardianDeco {
	$GuardianDeco = "";
	
	if ($_[0] == $X) {
		@YourGuardian = @MyGuardian;
	}
	else {
		@YourGuardian = split(/,/, $Guardian[$_[0]]);
	}
	
	if ($YourGuardian[0]) {
		$I = $YourGuardian[0];
		$GuardianDeco = "<IMG SRC=\"$ImgGuardian{\"$I\"}\" ALT=\"$GuardianName{\"$I\"}\" TITLE=\"$GuardianName{\"$I\"}\" BORDER=0 WIDTH=\"50\" HEIGHT=\"40\">";
		
		if (!(!$in{'Mode'} || $in{'Mode'} eq 'CommentChange' || $in{'Mode'} eq 'Visit' || $DrawFlag)) {
			$GuardianDeco = "<A HREF=\"javascript:void(0)\" onMouseOver=\"JexpOpen(24)\" CLASS=\"normal\">$GuardianDeco</A>";
			&JcolorCheck($I);
			$JexpDeco = "<FONT COLOR=$Jcolor><B>$GuardianName{\"$I\"}</B></FONT><BR>$GuardianExp{\"$I\"}";
			$JSjexpNews .= "Jexp[24] = '$JexpDeco';\n";
		}
	}
	else {
		$GuardianDeco = "<IMG SRC=\"$ImgGuardian{'Blank'}\" ALT='수호신없음' TITLE='수호신없음' WIDTH=\"50\" HEIGHT=\"40\">";
	}
}

#롧뚯?궻뼹멟귩몧륕
sub GuardianNameDeco {
	&JcolorCheck($_[0]);
	$GuardianNameOnly = "<FONT COLOR=$Jcolor><B>$GuardianName{\"$_[0]\"}</B></FONT>";
	$GuardianNameDeco = "<IMG SRC=\"$ImgGuardian{\"$_[0]\"}\" ALT=\"$GuardianName{\"$_[0]\"}\" TITLE=\"$GuardianName{\"$_[0]\"}\" BORDER=0 WIDTH=\"50\" HEIGHT=\"40\"><FONT COLOR=$Jcolor><B>$GuardianName{\"$_[0]\"}</B></FONT>";
	
	if (!(!$in{'Mode'} || $in{'Mode'} eq 'AllNews' || $in{'Mode'} eq 'CommentChange' || $DrawFlag)) {
		$GuardianNameDeco = "<A HREF=\"javascript:void(0)\" onMouseOver=\"JexpOpen($Jcount)\" CLASS=\"normal\">$GuardianNameDeco</A>";
		
		$JexpDeco = "<FONT COLOR=$Jcolor><B>$GuardianName{\"$_[0]\"}</B></FONT><BR>$GuardianExp{\"$_[0]\"}";
		$JSjexpNews .= "Jexp[$Jcount] = '$JexpDeco';\n";
		$Jcount++;
	}
}

#롧뚯?궕궥궳궸롧뚯궢궲궋궶궋궔?긃긞긏
sub GuardianFree {
	$GuardianFree = 1;
	foreach (1..$PlayerMax) {
		@YourGuardian = split(/,/, $Guardian[$_]);
		if ($YourGuardian[0] eq $_[0]) {
			$GuardianFree = 0;
			last;
		}
	}
}

#?긽?긙귩롷궚귡궴궖갂롧뚯?궕궋귡궶귞롧뚯궥귡
sub DamageGuard {
	$GuardNews = '';
	if ($MyGuardian[0]) {
		$DamageGuardFlag = 1;
		$GuardNews .= ":$X,Guardian,$MyGuardian[0],Guard,$_[0]";
		$MyGuardian[1] -= $_[0];
		if ($MyGuardian[1] <= 0) {
			$GuardNews .= ":$X,Guardian,$MyGuardian[0],Lost";
			$MyGuardian[0] = "";
			$MyGuardian[1] = 0;
		}
		$Guardian[$X] = join(",", @MyGuardian);
	}
	else {
		$GuardNews .= ":$X,Damage,$_[0]";
		$HP[$X] -= $_[0];
		if ($HP[$X] < 0) {$HP[$X] = 0;}
	}
}

#뻂뽦궳궖귡궔?긃긞긏
sub VisitCheck {
	$VisitFlag = 0;
	
	foreach (1..$PlayerMax) {
		if ($HP[$_] > 0) {
			@YourStatue = split(/,/, $Statue[$_]);
			if ($YourStatue[1]) {$VisitFlag = 1; last;}
		}
	}
	
	return $VisitFlag;
}

#걏럄귟걐??깛뾭긜깒긏긣?긞긏긚
sub RestPselect {
	#릶뭠궻OPTION?긐
	$HPoption = "";
	$I = 10;
	while ($I <= $TotalP && $I <= 990) {
		if ($I == $HP[$X]) {
			$HPoption .= "<OPTION VALUE=\"$I\" SELECTED>$I\n";
		}
		else {
			$HPoption .= "<OPTION VALUE=\"$I\">$I\n";
		}
		$I += 10;
	}
	$MPoption = "";
	$I = 0;
	while ($I < $TotalP && $I <= 990) {
		if ($I == $MP[$X]) {
			$MPoption .= "<OPTION VALUE=\"$I\" SELECTED>$I\n";
		}
		else {
			$MPoption .= "<OPTION VALUE=\"$I\">$I\n";
		}
		$I += 10;
	}
	$GPoption = "";
	$I = 0;
	while ($I < $TotalP && $I <= 990) {
		if ($I == $GP[$X]) {
			$GPoption .= "<OPTION VALUE=\"$I\" SELECTED>$I\n";
		}
		else {
			$GPoption .= "<OPTION VALUE=\"$I\">$I\n";
		}
		$I += 10;
	}
	
	$RestPselect = <<END_OF_RESTPSELECT;
<SELECT NAME="HP">
$HPoption</SELECT><BR>
<INPUT TYPE="button" VALUE="나머지" onClick="RestP('HP')" CLASS="button">
</TD><TD ALIGN="right">
<SELECT NAME="MP"$OnChangeMP>
$MPoption</SELECT><BR>
<INPUT TYPE="button" VALUE="나머지" onClick="RestP('MP')" CLASS="button">
</TD><TD ALIGN="right">
<SELECT NAME="GP"$OnChangeGP>
$GPoption</SELECT><BR>
<INPUT TYPE="button" VALUE="나머지" onClick="RestP('GP')" CLASS="button">
END_OF_RESTPSELECT
}

#륷궢궋?딇귩멗귆
sub NewJingi {
	#?딇궻깏긚긣릶귩롦벦
	$JlistMax = 1;
	while ($Jname[$JlistMax]) {
		$JlistMax++;
	}
	$JlistMax -= 1;
	
	#?딇궻럄귟릶륃뺪귩롦벦
	@JnowNum = split(/,/, $JnowNumLine);
	
	#?딇궻럄귟몟릶귩똶럁
	$I = 0;
	foreach (1..$JlistMax) {
		$I += $JnowNum[$_];
	}
	#?딇궕멣궲궶궘궶궯궫뤾뜃갂멣뺚?
	if ($I == 0) {
		#봲뫿롌궻룋렃뷼귩?룣
		foreach (1..$PlayerMax) {
			if ($HP[$_] == 0) {
				&MyClean($_);
			}
		}
		
		#뺚?
		@JnowUse = split(/,/, $JnowUseLine);
		foreach (1..$JlistMax) {
			$JnowNum[$_] = $JnowUse[$_];
			$I += $JnowNum[$_];
			$JnowUse[$_] = 0;
		}
		$JnowUseLine = join(",", @JnowUse);
	}
	
	#뺚?궢궲귖럄귟몟릶0궻뤾뜃
	if ($I == 0) {
		$NJ = 0;
	}
	else {
		#렔멢릶걏1??딇궻럄귟몟릶걐궔귞깋깛??궳덇궰멗묖
		$J = int(rand($I)) + 1;
		
		#륷궢궋?딇귩뙂믦
		foreach (1..$JlistMax) {
			$J -= $JnowNum[$_];
			if ($J <= 0) {
				$NJ = $_;	#뙂믦궢궫륷궢궋?딇
				last;
			}
		}
		
		#뙂믦궢궫?딇궻럄귟릶귩뙵귞궥
		$JnowNum[$NJ]--;
		
		#?딇궻럄귟릶륃뺪귩뙅뜃
		$JnowNumLine = join(",", @JnowNum);
	}
}

#럊뾭띙귒궻?딇귩딯?
sub JnowUseAdd {
	@JnowUse = split(/,/, $JnowUseLine);
	$JnowUse[$_[0]]++;
	$JnowUse[0] = "";
	$JnowUseLine = join(",", @JnowUse);
}

#룋렃?딇궻??긣
sub SortJingi {
	shift(@MyJ);
	@MyJ = sort by_Jnum (@MyJ);
	unshift(@MyJ, "");
}

#뢐벦딉먘궻볺귢뫶궑
sub MiracleChange {
	#뢐벦딉먘궻볺귢뫶궑
	if ($MyM[6]) {
		@MyM = ("",$MyM[2],$MyM[3],$MyM[4],$MyM[5],$MyM[6],$_[0],);
	}
	elsif ($MyM[1]) {
		push(@MyM, $_[0]);
	}
	else {
		$MyM[1] = $_[0];
	}
	
	#뢐벦딉먘귩뙅뜃
	$Miracle[$X] = join(",", @MyM);
}

#딉먘럊뾭?딇궻룋렃귩?긃긞긏
sub UseMiracleCheck {
	@UMJ = ();
	$I = 0;
	foreach (1..16) {
		if ($Jdetail[$MyJ[$_]] eq 'UseMiracle') {
			$UMJ[$I] = $_;
			$I++;
		}
	}
	
	@UMJ = sort by_JpriceUM (@UMJ);
}

#?딇궻뼹멟궴먣뼻귩몧륕궥귡?뷈
sub Jdeco {
	$JD = $_[0];
	
	#빒럻궻륡귩뫌맜궸귝귟뵽빶
	&JcolorCheck($Jattribute[$JD]);
	
	#?렑궥귡릶뭠귩릶뭠궴롰쀞궸귝귟뵽빶
	if ($LostATflag) {
		$JpointUse = $Jfree[$JD] % 1000;
		$JpointTemp = "전AT$JpointUse";
		$LostATflag = 0;
	}
	elsif ($Jpoint[$JD] >= 1000) {
		$JpointUse = $Jpoint[$JD] % 1000;
		$JpointTemp = "전AT$JpointUse";
	}
	elsif (
		$Jpoint[$JD]
		 && ($Jkind[$JD] eq 'Weapon' || $Jkind[$JD] eq 'TargetAct')
		 && $Jdetail[$JD] ne 'GPabsorb' && $Jdetail[$JD] ne 'Broom' && $Jdetail[$JD] ne 'Soap'
	) {
		$JpointTemp = "AT$Jpoint[$JD]";
	}
	elsif (	
		$Jpoint[$JD] && (
			$Jkind[$JD] eq 'Shield' || $Jkind[$JD] eq 'Armor' || $Jkind[$JD] eq 'Helm' || 
			$Jkind[$JD] eq 'Gauntlet' || $Jkind[$JD] eq 'Boots' || $Jkind[$JD] eq 'Ring' || 
			$Jkind[$JD] eq 'OtherP' || $Jkind[$JD] eq 'SoloP'
		)
	) {
		$JpointTemp = "DF$Jpoint[$JD]";
	}
	else {
		$JpointTemp = "";
	}
	
	#걏?딇궻뼹멟걐?렑뾭궻릶뭠궴걏?딇궻먣뼻걐?렑뾭궻릶뭠
	if ($Jmp[$JD] > 0) {
		$PdecoJname = "";
		if ($Jkind[$JD] eq 'Release') {
			$PdecoJexp = "( MP--, $Jprice[$JD]G )";
		}
		elsif ($JpointTemp) {
			$PdecoJexp = "( MP$Jmp[$JD], $JpointTemp, $Jprice[$JD]G )";
		}
		else {
			$PdecoJexp = "( MP$Jmp[$JD], $Jprice[$JD]G )";
		}
	}
	elsif ($JpointTemp) {
		$PdecoJname = "( $JpointTemp )";
		$PdecoJexp = "( $JpointTemp, $Jprice[$JD]G )";
	}
	elsif ($Jkind[$JD] ne 'Pray') {
		$PdecoJname = "";
		$PdecoJexp = "( $Jprice[$JD]G )";
	}
	else {
		$PdecoJname = "";
		$PdecoJexp = "";
	}
	
	#&JdecoShrine귏궫궼&JdecoEvent궸뫏궘
}

#?딇궻뼹멟궴먣뼻귩몧륕걁?밶똭긖긳깑??깛궔귞뚁귂뢯궠귢궫뤾뜃걂
sub JdecoShrine {
	$JnameDeco = "<FONT COLOR=$Jcolor><B>$Jname[$JD]</B>$PdecoJname</FONT>";
	$JexpDeco = "<FONT COLOR=$Jcolor><B>$Jname[$JD]</B>$PdecoJexp</FONT><BR>$Jexp[$JD]";
	
	#걏?딇궻릶뭠걐?렑
	if ($DefenseFlag) {
		if (
			$Jdetail[$JD] eq 'Shield' || $detail[$JD] eq 'Armor' || $detail[$JD] eq 'Helm' || 
			$Jdetail[$JD] eq 'Gauntlet' || $Jdetail[$JD] eq 'Boots' || $Jdetail[$JD] eq 'Ring' || 
			$Jdetail[$JD] eq 'OtherP'
		) {
			$JpointDeco = $Jfree[$JD];
		}
		elsif ($Jkind[$JD] eq 'SoloP' || $Jdetail[$JD] eq 'WeaponR') {
			$JpointDeco = "'-'";
		}
		elsif (!$Jpoint[$JD]) {
			$JpointDeco = 0;
		}
		else {
			$JpointDeco = $Jpoint[$JD];
		}
	}
	elsif ($Jkind[$JD] eq 'HPup') {
		$JpointDeco = "'HP$Jpoint[$JD]'";
	}
	elsif ($Jkind[$JD] eq 'MPup') {
		$JpointDeco = "'MP$Jpoint[$JD]'";
	}
	elsif ($Jkind[$JD] eq 'GPup') {
		$JpointDeco = "'$Jpoint[$JD]G'";
	}
	elsif (
		!$Jpoint[$JD] || $Jdetail[$JD] eq 'GPabsorb' || $Jdetail[$JD] eq 'Broom' || $Jdetail[$JD] eq 'Soap'
		 || (
			(!$Jtype[$JD] || $Jtype[$JD] eq 'OneMore' || $Jtype[$JD] eq 'Solo')
			 && ($Jkind[$JD] ne 'Weapon' && $Jkind[$JD] ne 'TargetAct' && $Jkind[$JD] ne 'AllAct')
		)
	) {
		$JpointDeco = "'-'";
	}
	else {
		$JpointDeco = $Jpoint[$JD];
	}
}

#?딇궻뼹멟궴먣뼻귩몧륕걁귽긹깛긣몧륕긖긳깑??깛궔귞뚁귂뢯궠귢궫뤾뜃걂
sub JdecoEvent {
	if ($DefenseEventFlag && $Jkind[$JD] eq 'Weapon') {
		$PdecoJname = "( DF$Jfree[$JD] )";
	}
	elsif ($ATupFlag && $Jkind[$JD] ne 'Weapon') {
		$PdecoJname = "( AT$Jfree[$JD] )";
	}
	
	if (!$in{'Mode'} || $in{'Mode'} eq 'AllNews' || $in{'Mode'} eq 'CommentChange' || $DrawFlag) {
		$JeventDeco = "<IMG SRC=\"$Jimage[$JD]\" ALT=\"$Jname[$JD]\" TITLE=\"$Jname[$JD]\" BORDER=0 WIDTH=\"80\" HEIGHT=\"80\"><FONT COLOR=$Jcolor><B>$Jname[$JD]</B>$PdecoJname</FONT>";
		$JbuyDeco = "<IMG SRC=\"$Jimage[$JD]\" ALT=\"$Jname[$JD]\" TITLE=\"$Jname[$JD]\" BORDER=0 WIDTH=\"80\" HEIGHT=\"80\"><FONT COLOR=$Jcolor><B>$Jname[$JD]</B>$PdecoJexp</FONT>";
	}
	else {
		$JeventDeco = "<A HREF=\"javascript:void(0)\" onMouseOver=\"JexpOpen($Jcount)\" CLASS=\"normal\"><IMG SRC=\"$Jimage[$JD]\" ALT=\"$Jname[$JD]\" TITLE=\"$Jname[$JD]\" BORDER=0 WIDTH=\"80\" HEIGHT=\"80\"><FONT COLOR=$Jcolor><B>$Jname[$JD]</B>$PdecoJname</FONT></A>";
		$JbuyDeco = "<A HREF=\"javascript:void(0)\" onMouseOver=\"JexpOpen($Jcount)\" CLASS=\"normal\"><IMG SRC=\"$Jimage[$JD]\" ALT=\"$Jname[$JD]\" TITLE=\"$Jname[$JD]\" BORDER=0 WIDTH=\"80\" HEIGHT=\"80\"><FONT COLOR=$Jcolor><B>$Jname[$JD]</B>$PdecoJexp</FONT></A>";
		
		$JexpDeco = "<FONT COLOR=$Jcolor><B>$Jname[$JD]</B>$PdecoJexp</FONT><BR>$Jexp[$JD]";
		$JSjexpNews .= "Jexp[$Jcount] = '$JexpDeco';\n";
		$Jcount++;
	}
}

#뫌맜빶궸빒럻륡귩뙂믦
sub JcolorCheck {
	if ($_[0] eq 'Mars') {$Jcolor = $ColorMars;}		#됌뫌맜
	elsif ($_[0] eq 'Mercury') {$Jcolor = $ColorMercury;}	#릣뫌맜
	elsif ($_[0] eq 'Jupiter') {$Jcolor = $ColorJupiter;}	#뽜뫌맜
	elsif ($_[0] eq 'Saturn') {$Jcolor = $ColorSaturn;}	#뱘뫌맜
	elsif ($_[0] eq 'Uranus') {$Jcolor = $ColorUranus;}	#밮뫌맜
	elsif ($_[0] eq 'Pluto') {$Jcolor = $ColorPluto;}	#뼸뫌맜
	elsif ($_[0] eq 'Venus') {$Jcolor = $ColorVenus;}	#뗠맦?
	elsif ($_[0] eq 'Earth') {$Jcolor = $ColorEarth;}	#뭤땯?
	elsif ($_[0] eq 'Neptune') {$Jcolor = $ColorNeptune;}	#둇돞?
	else {$Jcolor = $ColorNormal;}				#뼰뫌맜
}

#뻞뗰궻롰쀞궔귞몧뷈댧뭫걁붥뜂걂귩뙂믦
sub PositionP {
	if (
		$Jkind[$_[0]] eq 'SoloP'
		 || $Jdetail[$_[0]] eq 'SuperM'
		 || (
			$ATvariety eq 'Weapon'
			 && ($Jdetail[$_[0]] eq 'WeaponM' || $Jdetail[$_[0]] eq 'WeaponR' || $Jdetail[$_[0]] eq 'WeaponB' || $Jdetail[$_[0]] eq 'ATabsorb')
		)
		 || (
			$ATvariety eq 'Miracle'
			 && ($Jdetail[$_[0]] eq 'MiracleM' || $Jdetail[$_[0]] eq 'MiracleR' || $Jdetail[$_[0]] eq 'MiracleB')
		)
	) {
		$PositionP = 7;
	}
	elsif ($Jkind[$_[0]] eq 'Shield' || $Jdetail[$_[0]] eq 'Shield') {$PositionP = 1;}
	elsif ($Jkind[$_[0]] eq 'Armor' || $Jdetail[$_[0]] eq 'Armor') {$PositionP = 2;}
	elsif ($Jkind[$_[0]] eq 'Helm' || $Jdetail[$_[0]] eq 'Helm') {$PositionP = 3;}
	elsif ($Jkind[$_[0]] eq 'Gauntlet' || $Jdetail[$_[0]] eq 'Gauntlet') {$PositionP = 4;}
	elsif ($Jkind[$_[0]] eq 'Boots' || $Jdetail[$_[0]] eq 'Boots') {$PositionP = 5;}
	elsif ($Jkind[$_[0]] eq 'Ring' || $Jdetail[$_[0]] eq 'Ring') {$PositionP = 6;}
	else {$PositionP = 7;}
}

#-------------
#神界史
#-------------

sub AllNews {
	#긒??둎럑멟궶귞긄깋?
	if ($GFyear <= 1) {&Error;}
	
	$AllNewsShow = "<CENTER>\n";
	$AllNewsShow .= "<BIG><B><FONT COLOR=$ColorNormal>∼</FONT><FONT COLOR=$ColorNormal>神界史</FONT><FONT COLOR=$ColorNormal>∼</FONT></B></BIG>\n";
	$AllNewsShow .= "\n</CENTER>\n<BR>\n";
	
	if (!$in{'Page'}) {$NowPage = 1;}
	else {$NowPage = $in{'Page'};}
	$AllNewsMax = $NowPage * $AllNewsOnePage;
	$AllNewsMin = ($NowPage - 1) * $AllNewsOnePage;
	for ($AN = $AllNewsMax; $AN > $AllNewsMin; $AN--) {
		if ($News[$AN]) {
			$J = $GFyear - $AN;
			&NewsDeco($J,$News[$AN]);
			$AllNewsShow .= "<HR COLOR=$ColorHR>\n$NewsDeco";
		}
	}
	
	$NewsLength = @News;
	if ($NowPage * $AllNewsOnePage < $NewsLength - 1) {
		$NextPage = $NowPage + 1;
		$NextPageShow = "<A HREF=\"$ThisFile?Mode=AllNews&Page=$NextPage\" CLASS=\"link\">좀 더 옛날것을 본다.</A><BR>\n<BR>\n";
	}
	
	&Message('神界史');
}

#-------------
#방문
#-------------

sub Visit {
	#렔빁궻?밶궔귞뿀궫궴궖
	if ($X) {
		&PassCheck;
		&HPcheck;
		if (!$Present[$X] && (time - $LastAccess[$X] >= $NextTime)) {
			$BuyButton = '<INPUT TYPE="button" VALUE="   산다   " onClick="Submit()" CLASS="button"><BR><BR>';
		}
	}
	
	#JavaScript
	$JSjname = "Jname = new Array();\n";
	$JSjexp = "Jexp = new Array();\n";
	$JSjprice = "Jprice = new Array();\n";
	
	#?밶?궻궫귕궻긇긂깛?
	$ShrineCount = 1;
	
	#랷돿롌궻둴봃
	&PlayerCheck;
	
	#?밶?
	@Player = sort by_HP (@Player);
	$ShrineData = "<TABLE WIDTH=100%><TR><TD>\n\n";
	foreach (@Player) {
		if ($HP[$_] > 0) {
			$ShrineData .= "<TABLE BORDER=1 BGCOLOR=$ColorTable CELLPADDING=4 WIDTH=100%><TR BGCOLOR=$ColorTR><TH WIDTH=20% NOWRAP><FONT COLOR=$ColorTRfont>예언자</FONT></TH><TH><FONT COLOR=$ColorTRfont>HP</FONT></TH><TH><FONT COLOR=$ColorTRfont>MP</FONT></TH><TH><FONT COLOR=$ColorTRfont>금</FONT></TH><TH WIDTH=100%><FONT COLOR=$ColorTRfont>상태</FONT></TH><TH><FONT COLOR=$ColorTRfont>신상</FONT></TH><TH NOWRAP><FONT COLOR=$ColorTRfont>수호</FONT></TH></TR>\n";
			&ConditionDeco($_);
			&StatueDeco($_);
			&GuardianDeco($_);
			if ($HP[$_] >= 100) {
				$ShrineData .= "<TR BGCOLOR=$ColorTDup><TH ROWSPAN=2 NOWRAP><FONT COLOR=$ColorProphet>$Name[$_]</FONT></TH><TD ALIGN=\"right\">$HP[$_]</TD><TD ALIGN=\"right\">$MP[$_]</TD><TD ALIGN=\"right\">$GP[$_]G</TD><TD>$ConditionDeco</TD><TH ROWSPAN=2>$StatueDeco</TH><TH ROWSPAN=2>$GuardianDeco</TH></TR>\n<TR><TD COLSPAN=4 BGCOLOR=$ColorTDdown>$Comment[$_]</TD></TR>\n";
			}
			elsif ($HP[$_] > 0) {
				$ShrineData .= "<TR BGCOLOR=$ColorTDup><TH ROWSPAN=2 NOWRAP><FONT COLOR=$ColorProphet>$Name[$_]</FONT></TH><TD ALIGN=\"right\"><FONT COLOR=$ColorDamage>$HP[$_]</FONT></TD><TD ALIGN=\"right\">$MP[$_]</TD><TD ALIGN=\"right\">$GP[$_]G</TD><TD>$ConditionDeco</TD><TH ROWSPAN=2>$StatueDeco</TH><TH ROWSPAN=2>$GuardianDeco</TH></TR>\n<TR><TD COLSPAN=4 BGCOLOR=$ColorTDdown>$Comment[$_]</TD></TR>\n";
			}
			
			#떉궑븿
			if ($YourStatue[1]) {
				if ($X && !$Present[$X] && (time - $LastAccess[$X] >= $NextTime)) {
					$JSresetTC .= "TextChange('Jname$_', \"\")\n\t";
				}
				
				foreach $I (1..4) {
					$Offering[$I] = "";
					if ($YourStatue[$I]) {
						&Jdeco($YourStatue[$I]);
						
						if ($X && !$MyJ[16] && $GP[$X] >= $Jprice[$YourStatue[$I]]) {
							$OnClick = " onClick=\"Reset(); JnameOpen($ShrineCount, $_, $I, $YourStatue[$I])\"";
						}
						else {
							$OnClick = "";
						}
						
						$Offering[$I] = "<A HREF=\"javascript:void(0)\" onMouseOver=\"JexpOpen($ShrineCount, $_)\"$OnClick CLASS=\"normal\"><IMG SRC=\"$Jimage[$JD]\" ALT=\"$Jname[$JD]\" TITLE=\"$Jname[$JD]\" BORDER=0 WIDTH=\"80\" HEIGHT=\"80\"><FONT COLOR=$Jcolor><B>$Jname[$JD]</B>$PdecoJname</FONT></A>";
						$JnameDeco = "<FONT COLOR=$Jcolor><B>$Jname[$JD]</B>$PdecoJname</FONT>";
						$JSjname .= "Jname[$ShrineCount] = '$JnameDeco';\n";
						$JexpDeco = "<FONT COLOR=$Jcolor><B>$Jname[$JD]</B>$PdecoJexp</FONT><BR>$Jexp[$JD]";
						$JSjexp .= "Jexp[$ShrineCount] = '$JexpDeco';\n";
						$JSjprice .= "Jprice[$ShrineCount] = '$Jprice[$YourStatue[$I]]';\n";
						$ShrineCount++;
					}
				}
				
				if ($X && !$Present[$X] && (time - $LastAccess[$X] >= $NextTime)) {
					$BuyTable = "<TABLE BGCOLOR=$ColorViTable CELLPADDING=3 WIDTH=95%>\n";
					$BuyTable .= "<TR><TH>　</TH><TD BGCOLOR=$ColorViTD WIDTH=100%>\n";
					$BuyTable .= "<A HREF=\"javascript:void(0)\" onClick=\"Reset()\" CLASS=\"normal\"><DIV ID=\"Jname$_\"></DIV></A>\n";
					$BuyTable .= "</TD><TH>　</TH></TR>\n";
					$BuyTable .= "</TABLE>\n";
				}
				
				$OfferingData = <<END_OF_OFFERINGDATA;
<TR BGCOLOR=$ColorShTableDown><TD COLSPAN=7>

<TABLE WIDTH=100%>
<TR><TD BGCOLOR=$ColorShTDleft VALIGN="top">

<TABLE WIDTH=100%>
<TR><TD WIDTH=50%>$Offering[1]</TD><TD WIDTH=50%>$Offering[2]</TD></TR>
<TR><TD WIDTH=50%>$Offering[3]</TD><TD WIDTH=50%>$Offering[4]</TD></TR>
</TABLE>

</TD><TD BGCOLOR=$ColorShTDup ALIGN="center" VALIGN="top" WIDTH=40%>

<BR>
$BuyTable
<BR>
$BuyButton

<TABLE BORDER=0 BGCOLOR=$ColorShTableExp CELLPADDING=3 WIDTH=95%><TR><TD BGCOLOR=$ColorShTDexp>
<DIV ID="Jexp$_">(神器의 설명)<BR><BR><BR></DIV>
</TD></TR></TABLE>

</TD></TR>
</TABLE>

</TD></TR>
END_OF_OFFERINGDATA
				
				$ShrineData .= $OfferingData;
			}
			
			$ShrineData .= "</TABLE>\n\n<BR>\n\n";
		}
	}
	$ShrineData .= "</TABLE>";
	
	#JavaScript
	&JSshrine;
	&JSvisit;
	
	#?밶뻂뽦됪뽋뢯쀍
	print <<END_OF_VISIT;
Content-type: text/html; charset=utf-8

<HTML>

<HEAD>

$Meta

<TITLE>예언자들의 신전</TITLE>

$Style

<SCRIPT LANGUAGE="JavaScript">
<!--
$JSjname
$JSjexp
$JSjexpOpen
$JSjnameOpen
$JSresetButton
$JSreset
$JStextChange
$JSvalueChange
$JSsubmit
// -->
</SCRIPT>

</HEAD>

$BodyShrine

<CENTER>

<H3>예언자들의 신전</H3>

<FORM ACTION="$ThisFile" METHOD="POST">

$ShrineData

<INPUT TYPE="hidden" NAME="Seller" VALUE="0">
<INPUT TYPE="hidden" NAME="SellStatue" VALUE="0">
<INPUT TYPE="hidden" NAME="Jnum" VALUE="0">
<INPUT TYPE="hidden" NAME="Number" VALUE="$X">
<INPUT TYPE="hidden" NAME="NowPass" VALUE="$CryptedPass">
<INPUT TYPE="hidden" NAME="Mode" VALUE="VisitBuy">

</FORM>

</CENTER>

<A HREF="$ThisFile" CLASS="link">갓필드TOP</A><BR>
<BR>
<A HREF="$HomePage" CLASS="link">홈페이지TOP</A>

</BODY>

</HTML>
END_OF_VISIT
	
	&End;
}

sub VisitBuy {
	$Seller = $in{'Seller'};
	$SellStatue = $in{'SellStatue'};
	$Jnum = $in{'Jnum'};
	
	#븉맫?긃긞긏
	if ($Present[$X] || (time - $LastAccess[$X] < $NextTime) || $MyJ[16] || $GP[$X] < $Jprice[$Jnum]) {
		&Error;
	}
	
	#뫜궻묿궔궸긎깏긎깏궳먩귩뎭궠귢궫뤾뜃
	@YourStatue = split(/,/, $Statue[$Seller]);
	if ($YourStatue[$SellStatue] != $Jnum) {&Error;}
	
	#봽봼룉뿚
	$GP[$X] -= $Jprice[$Jnum];
	
	if ($CanBuyGold) {
	$GP[$Seller] += $Jprice[$Jnum];
	if ($GP[$Seller] > 990) {$GP[$Seller] = 990;}
	}
	
	$I = $SellStatue + 4;
	splice(@YourStatue, $I, 1);
	splice(@YourStatue, $SellStatue, 1);
	@YourStatue = (
		$YourStatue[0],
		$YourStatue[1],$YourStatue[2],$YourStatue[3],"",
		$YourStatue[4],$YourStatue[5],$YourStatue[6],"",
	);
	$Statue[$Seller] = join(",", @YourStatue);
	if ($Seller == $X) {@MyStatue = @YourStatue;}
	
	$MyJ[16] = $Jnum;
	&SortJingi;
	
	$EatNews = "$X,Contribute,$Jnum,$Seller";
	if ($Seller != $X) {$Present[$Seller] .= "==$EatNews";}
	&NewsDeco($GFyear, $EatNews);
	$ShrineNews .= $NewsDeco;
	&NewsChange($EatNews);
	$EatNews = "";
}

#-------------
#성패기
#-------------

sub Judgment {
	if (!$GFyear || $GFyear == 1 || (!$Winner && !$DrawFlag)) {&Error;}
	
	$ShrineNews = "<CENTER>\n";
	if (!$DrawFlag) {
		$X = $Winner;
		
		&MyData($X);
		$Jcount = 25;	#?밶긦깄?긚궻궫귕궻긇긂깛?
		
		$ShrineNews .= "<BIG><B><FONT COLOR=$ColorAttack>★</FONT><FONT COLOR=$ColorProphet>$Name[$X]의 성패기</FONT><FONT COLOR=$ColorAttack>★</FONT></B></BIG>\n";
	}
	else {
		$ShrineNews .= "<BIG><B><FONT COLOR=$ColorDefense>★</FONT><FONT COLOR=$ColorAscension>대왕생기</FONT><FONT COLOR=$ColorDefense>★</FONT></B></BIG>\n";
	}
	$ShrineNews .= "</CENTER>\n";
	$ShrineNews .= "\n<BR>\n";
	
	foreach (1..(@Judgment - 1)) {
		if (!$Judgment[$_]) {last;}
		
		#돷둉귉돷궯궫뤾뜃궸떇봏궻?렑귩긇긞긣궥귡궫귕궻긲깋긐
		$JMremoveFlag = 0;
		
		@Event = split(/:/, $Judgment[$_]);
		$JMyear = shift(@Event);	#?둉봏륃뺪귩롦귟룣궘
		$JMprophet = shift(@Event);	#뾞뙻롌륃뺪귩롦귟룣궘
		
		$YDcheck = $_;
		&YearDeco($JMyear);
		
		$NewsDeco = "";
		foreach $E (@Event) {
			if ($E) {
				&EventDeco($E);
				if (!$BlankFlag) {$NewsDeco .= "$EventDeco<BR>\n";}
			}
		}
		
		$ShrineNews .= "<HR COLOR=$ColorHR>\n$NewsDeco";
		if (!$JMremoveFlag) {
			$ShrineNews .= "<B>( 예언자<FONT COLOR=$ColorProphet>$Name[$JMprophet]</FONT> 향년$JMyear세 )</B><BR>\n";
		}
		$ShrineNews .= "<BR>\n";
	}
	
	if (!$DrawFlag) {&ATshrine;}
	else {&Message('대왕생기');}
}

#----------------
#소트용 서브루틴
#----------------

#릶럻궻룷궠궋룈궸빥귊뫶궑귡
sub by_Number {
	$a <=> $b;
}

#HP룈
sub by_HP {
	if ($HP[$b] != $HP[$a]) {
		$HP[$b] <=> $HP[$a];
	}
	elsif ($HP[$b] != 0 && $HP[$b] + $MP[$b] + $GP[$b] != $HP[$a] + $MP[$a] + $GP[$a]) {
		$HP[$b] + $MP[$b] + $GP[$b] <=> $HP[$a] + $MP[$a] + $GP[$a];
	}
	elsif ($HP[$b] == 0 && $LastAccess[$b] != $LastAccess[$a]) {
		$LastAccess[$b] <=> $LastAccess[$a];
	}
	else {
		$a <=> $b;
	}
}

#띍뢎귺긏긜긚룈
sub by_LastAccess {
	if ($LastAccess[$b] != $LastAccess[$a]) {
		$LastAccess[$a] <=> $LastAccess[$b];
	}
	else {
		$a <=> $b;
	}
}

#?딇궻뭠뭝궕댝궋룈
sub by_JpriceUM {
	if ($Jprice[$MyJ[$b]] != $Jprice[$MyJ[$a]]) {
		$Jprice[$MyJ[$a]] <=> $Jprice[$MyJ[$b]];
	}
	else {
		$a <=> $b;
	}
}

#?딇궻?밶?렑뾆먩룈
sub by_Jnum {
	if (!$a || !$b) {
		$b <=> $a;
	}
	else {
		$a <=> $b;
	}
}

#-------------
#JavaScript
#-------------

#긽긦깄?됪뽋
sub JSmenu {
	#랷돿긲긅??궻둫롰?긃긞긏
	$JSentry = <<END_OF_JSENTRY;
function EntryCheck(ThisForm) {
	if (ThisForm.Name.value == "") {
		alert("이름을 입력해 주세요.");
		ThisForm.Name.focus();
	}
	else if (ThisForm.Password.value == "") {
		alert("패스워드를 입력해 주세요.");
		ThisForm.Password.focus();
		ThisForm.PassAgain.value = "";
	}
	else if (ThisForm.Password.value != ThisForm.PassAgain.value) {
		alert("2개의 패스워드가 일치하지 않습니다.");
		ThisForm.Password.focus();
		ThisForm.Password.select();
		ThisForm.PassAgain.value = "";
	}
	else {
		ThisForm.submit();
	}
}
END_OF_JSENTRY
	
	#걏?밶귉뛱궘걐걏궓뜍궛귩뜍궛귡걐궴궖궻긬긚깗?긤?긃긞긏
	$JSpass = <<END_OF_JSPASS;
function PassCheck(ThisForm, Mode) {
	if (ThisForm.NowPass.value == "") {
		alert("패스워드를 입력해 주세요.");
	}
	else if (Mode == 'CommentChange' && ThisForm.Comment.value == "") {
		alert("코멘트를 입력해 주세요.");
	}
	else {
		ThisForm.Mode.value = Mode;
		ThisForm.submit();
	}
}
END_OF_JSPASS
	
	#빾뛛뾭긲긅??궻둫롰?긃긞긏
	if ($GFyear <= 1) {
		$NameEditCheck = ' && ThisForm.Name.value == ""';
	}
	$JSedit = <<END_OF_JSEDIT;
function EditCheck(ThisForm) {
	if (ThisForm.NowPass.value == "") {
		alert("패스워드를 입력해 주세요.");
	}
	else if (ThisForm.Number.value != "0"$NameEditCheck && ThisForm.Password.value == "") {
		alert("변경할 항목에 입력해 주세요.");
	}
	else if (ThisForm.Password.value != ThisForm.PassAgain.value) {
		alert("2개의 패스워드가 일치하지 않습니다.");
		ThisForm.Password.focus();
		ThisForm.Password.select();
		ThisForm.PassAgain.value = "";
	}
	else {
		ThisForm.submit();
	}
}
END_OF_JSEDIT

}

#?밶됪뽋걁떎믅걂
sub JSshrine {
	#HP갂MP갂GP궻뜃똶
	$JStotalP = "var TotalP = $TotalP;\n";
	
	#먣뼻귩?렑궥귡
	$JSjexpOpen = <<END_OF_JEXPOPEN;
function JexpOpen(I) {
	TextChange('Jexp', Jexp[I]);
}
END_OF_JEXPOPEN
	
	#?렑궥귡빒귩빾뛛궥귡
	$JStextChange = <<END_OF_TEXTCHANGE;
function TextChange(P, Text) {
	if (document.all) {
		document.all(P).innerHTML = Text;
		document.all(P).style.visibility = "visible";
	}
}
END_OF_TEXTCHANGE
	
	#걏럄귟걐??깛궻룉뿚
	$JSrestP = <<END_OF_RESTP;
function RestP(Parameter) {
	if (Parameter == 'HP') {
		document.forms[0].HP.value = TotalP - document.forms[0].MP.value - document.forms[0].GP.value;
		if (document.forms[0].HP.value > 990) {document.forms[0].HP.value = 990;}
	}
	else if (Parameter == 'MP') {
		document.forms[0].MP.value = TotalP - document.forms[0].HP.value - document.forms[0].GP.value;
		if (document.forms[0].MP.value > 990) {document.forms[0].MP.value = 990;}
		$RestMP;
	}
	else if (Parameter == 'GP') {
		document.forms[0].GP.value = TotalP - document.forms[0].HP.value - document.forms[0].MP.value;
		if (document.forms[0].GP.value > 990) {document.forms[0].GP.value = 990;}
	}
}
END_OF_RESTP
	
}

#?밶됪뽋걁뻞뚥걂
sub JSdefense {
	#뻞뚥쀍궻뜃똶갂뻞뚥쀍궻뜃똶궻빒럻륡
	$JSinfo = "var TotalDF = \"\";\n";
	$JSinfo .= "var DFcolor = '$ColorNormal';\n";
	$JSinfo .= "var UMcheck = $UMcheck;\n";
	$JSinfo .= "var ATvariety = '$ATvariety';\n";
	$JSinfo .= "var SoloDFflag = 0;\n";
	
	#?딇궻뼹멟갂먣뼻갂릶뭠갂?딇궻?렑
	$JSjname = "Jname = new Array();\n";
	$JSjexp = "Jexp = new Array();\n";
	$JSjkind = "Jkind = new Array();\n";
	$JSjdetail = "Jdetail = new Array();\n";
	$JSjattribute = "Jattribute = new Array();\n";
	$JSjpoint = "Jpoint = new Array();\n";
	$JSjpoint .= "Jpoint[0] = 0;\n";
	$JSjfree = "Jfree = new Array();\n";
	
	$I = 1;
	foreach (@MyJ) {
		if ($_) {
			&Jdeco($_);
			&JdecoShrine;
			$JSjname .= "Jname[$I] = '$JnameDeco';\n";
			$JSjexp .= "Jexp[$I] = '$JexpDeco';\n";
			$JSjkind .= "Jkind[$I] = '$Jkind[$_]';\n";
			$JSjdetail .= "Jdetail[$I] = '$Jdetail[$_]';\n";
			$JSjattribute .= "Jattribute[$I] = '$Jattribute[$_]';\n";
			$JSjpoint .= "Jpoint[$I] = $JpointDeco;\n";
			if ($Jfree[$_]) {$JSjfree .= "Jfree[$I] = $Jfree[$_];\n";}
			
			#?딇궕뻞뗰궴궢궲럊뾭됀?궔?긃긞긏
			&PossibleDF($_);
			if ($PossibleDF && ($MP[$X] >= $Jmp[$_] || $UMcheck)) {
				&PositionP($_);
				$OnClick = " onClick=\"JnameOpen('Protector$PositionP', $I)\"";
			}
			else {
				$OnClick = "";
			}
			
			$Jshow[$I] = "<A HREF=\"javascript:void(0)\" onMouseOver=\"JexpOpen($I)\"$OnClick CLASS=\"normal\"><IMG SRC=\"$Jimage[$_]\" ALT=\"$Jname[$_]\" TITLE=\"$Jname[$_]\" BORDER=0 WIDTH=\"80\" HEIGHT=\"80\">$JnameDeco</A>";
			
			$I++;
		}
	}
	#딉먘궻뼹멟갂먣뼻갂롰쀞갂릶뭠갂딉먘궻?렑
	$I = 17;
	foreach (@MyM) {
		if ($_) {
			&Jdeco($_);
			&JdecoShrine;
			$JSjname .= "Jname[$I] = '$JnameDeco';\n";
			$JSjexp .= "Jexp[$I] = '$JexpDeco';\n";
			$JSjkind .= "Jkind[$I] = '$Jkind[$_]';\n";
			$JSjattribute .= "Jattribute[$I] = '$Jattribute[$_]';\n";
			$JSjpoint .= "Jpoint[$I] = $JpointDeco;\n";
			
			#딉먘궕뻞뗰궴궢궲럊뾭됀?궔?긃긞긏
			&PossibleDF($_);
			if ($PossibleDF && ($MP[$X] >= $Jmp[$_] || $UMcheck)) {
				&PositionP($_);
				$OnClick = " onClick=\"Reset('All'); JnameOpen('Protector$PositionP',$I)\"";
			}
			else {
				$OnClick = "";
			}
			
			$Jshow[$I] = "<A HREF=\"javascript:void(0)\" onMouseOver=\"JexpOpen($I)\"$OnClick CLASS=\"normal\"><IMG SRC=\"$Jimage[$_]\" ALT=\"$Jname[$_]\" TITLE=\"$Jname[$_]\" BORDER=0 WIDTH=\"80\" HEIGHT=\"80\"><B>$JnameDeco</B></A>";
			
			$I++;
		}
	}
	#몴궻뼹멟갂먣뼻갂롰쀞갂릶뭠갂몴궻?렑
	$I = 23;
	if ($MyStatue[0]) {
		&Jdeco($MyStatue[0]);
		&JdecoShrine;
		$JSjname .= "Jname[$I] = '$JnameDeco';\n";
		$JSjexp .= "Jexp[$I] = '$JexpDeco';\n";
		$JSjkind .= "Jkind[$I] = '$Jkind[$MyStatue[0]]';\n";
		$JSjattribute .= "Jattribute[$I] = '$Jattribute[$MyStatue[0]]';\n";
		$JSjpoint .= "Jpoint[$I] = $JpointDeco;\n";
		
		$Jshow[$I] = "<A HREF=\"javascript:void(0)\" onMouseOver=\"JexpOpen($I)\" CLASS=\"normal\">$StatueDeco</A>";
	}
	else {
		$Jshow[$I] = $StatueDeco;
	}
	
	#?딇궻뼹멟귩긓?깛긤뿎궸?렑궥귡
	$JSjnameOpen = <<END_OF_JNAMEOPEN;
function JnameOpen(Place, I) {
	SoloDFcheck(document.forms[0].OtherP.value);
	if (SoloDFflag) {Reset('All');}
	SoloDFcheck(I);
	if (SoloDFflag) {Reset('All');}
	
	TextChange(Place, Jname[I]);
	ValueChange(Place, I);
	TotalDFopen();
}
END_OF_JNAMEOPEN
	
	#깏긜긞긣??깛궻룉뿚
	$JSresetButton = <<END_OF_RESETBUTTON;
function ResetButton() {
	document.forms[0].HP.value = $HP[$X];
	document.forms[0].MP.value = $MP[$X];
	document.forms[0].GP.value = $GP[$X];
}
END_OF_RESETBUTTON
	
	#긓?깛긤궻깏긜긞긣룉뿚
	$JSreset = <<END_OF_RESET;
function Reset(Place) {
	if (Place == 'All') {
		TextChange('Protector1', ""); ValueChange('Protector1', 0);
		TextChange('Protector2', ""); ValueChange('Protector2', 0);
		TextChange('Protector3', ""); ValueChange('Protector3', 0);
		TextChange('Protector4', ""); ValueChange('Protector4', 0);
		TextChange('Protector5', ""); ValueChange('Protector5', 0);
		TextChange('Protector6', ""); ValueChange('Protector6', 0);
		TextChange('Protector7', ""); ValueChange('Protector7', 0);
	}
	else {
		TextChange(Place, ""); ValueChange(Place, 0);
	}
	
	TotalDFopen();
}
END_OF_RESET
	
	#뻞뚥쀍궻뜃똶귩똶럁궥귡
	$JStotalDFopen = <<END_OF_TOTALDFOPEN;
function TotalDFopen() {
	SoloDFcheck(document.forms[0].OtherP.value);
	if (SoloDFflag) {
		TotalDF = '-';
	}
	else {
		if (Jdetail[document.forms[0].Shield.value] == 'MagicalP' && document.forms[0].MP.value >= Jfree[document.forms[0].Shield.value]) {var ShieldDF = Jpoint[document.forms[0].Shield.value] * 2;}
		else if (Jdetail[document.forms[0].Shield.value] == 'Shield') {var ShieldDF = Jfree[document.forms[0].Shield.value];}
		else {var ShieldDF = Jpoint[document.forms[0].Shield.value];}
		
		if (Jdetail[document.forms[0].Armor.value] == 'MagicalP' && document.forms[0].MP.value >= Jfree[document.forms[0].Armor.value]) {var ArmorDF = Jpoint[document.forms[0].Armor.value] * 2;}
		else if (Jdetail[document.forms[0].Armor.value] == 'Armor') {var ArmorDF = Jfree[document.forms[0].Armor.value];}
		else {var ArmorDF = Jpoint[document.forms[0].Armor.value];}
		
		if (Jdetail[document.forms[0].Helm.value] == 'MagicalP' && document.forms[0].MP.value >= Jfree[document.forms[0].Helm.value]) {var HelmDF = Jpoint[document.forms[0].Helm.value] * 2;}
		else if (Jdetail[document.forms[0].Helm.value] == 'Helm') {var HelmDF = Jfree[document.forms[0].Helm.value];}
		else {var HelmDF = Jpoint[document.forms[0].Helm.value];}
		
		if (Jdetail[document.forms[0].Gauntlet.value] == 'MagicalP' && document.forms[0].MP.value >= Jfree[document.forms[0].Gauntlet.value]) {var GauntletDF = Jpoint[document.forms[0].Gauntlet.value] * 2;}
		else if (Jdetail[document.forms[0].Gauntlet.value] == 'Gauntlet') {var GauntletDF = Jfree[document.forms[0].Gauntlet.value];}
		else {var GauntletDF = Jpoint[document.forms[0].Gauntlet.value];}
		
		if (Jdetail[document.forms[0].Boots.value] == 'MagicalP' && document.forms[0].MP.value >= Jfree[document.forms[0].Boots.value]) {var BootsDF = Jpoint[document.forms[0].Boots.value] * 2;}
		else if (Jdetail[document.forms[0].Boots.value] == 'Boots') {var BootsDF = Jfree[document.forms[0].Boots.value];}
		else {var BootsDF = Jpoint[document.forms[0].Boots.value];}
		
		if (Jdetail[document.forms[0].Ring.value] == 'MagicalP' && document.forms[0].MP.value >= Jfree[document.forms[0].Ring.value]) {var RingDF = Jpoint[document.forms[0].Ring.value] * 2;}
		else if (Jdetail[document.forms[0].Ring.value] == 'Ring') {var RingDF = Jfree[document.forms[0].Ring.value];}
		else {var RingDF = Jpoint[document.forms[0].Ring.value];}
		
		if (Jdetail[document.forms[0].OtherP.value] == 'MagicalP' && document.forms[0].MP.value >= Jfree[document.forms[0].OtherP.value]) {var OtherPdf = Jpoint[document.forms[0].OtherP.value] * 2;}
		else if (Jdetail[document.forms[0].OtherP.value] == 'OtherP') {var OtherPdf = Jfree[document.forms[0].OtherP.value];}
		else {var OtherPdf = Jpoint[document.forms[0].OtherP.value];}
		
		var T = ShieldDF + ArmorDF + HelmDF + GauntletDF + BootsDF + RingDF + OtherPdf;
		
		DFcolor = '$ColorNormal';
		DFcolorOpen();
		
		if (T == 0) {TotalDF = '-';}
		else {TotalDF = '<FONT COLOR=' + DFcolor + '>DF' + T + '</FONT>';}
	}
	
	TextChange('TotalDefense', TotalDF);
}
END_OF_TOTALDFOPEN
	
	#볺쀍띙귒뻞뗰궕뭁벲럊뾭뻞뗰궔?긃긞긏
	$JSsoloDFcheck = <<END_OF_SOLODFCHECK;
function SoloDFcheck(P) {
	if (
		Jkind[P] == 'SoloP'
		 || Jdetail[P] == 'SuperM'
		 || (
			ATvariety == 'Weapon'
			&& (
				Jdetail[P] == 'WeaponM'
				 || Jdetail[P] == 'WeaponR'
				 || Jdetail[P] == 'WeaponB'
				 || Jdetail[P] == 'ATabsorb'
			)
		)
		 || (
			ATvariety == 'Miracle'
			&& (
				Jdetail[P] == 'MiracleM'
				 || Jdetail[P] == 'MiracleR'
				 || Jdetail[P] == 'MiracleB'
			)
		)
	) {
		SoloDFflag = 1;
	}
	else {
		SoloDFflag = 0;
	}
}
END_OF_SOLODFCHECK
	
	#뻞뚥쀍궻뜃똶?렑궻륡귩뵽믦궥귡
	$JSdfColorOpen = <<END_OF_DFCOLOROPEN;
function DFcolorOpen() {
	var Attribute = "";
	if (document.forms[0].Shield.value != 0) {Attribute = Jattribute[document.forms[0].Shield.value];}
	else if (document.forms[0].Armor.value != 0) {Attribute = Jattribute[document.forms[0].Armor.value];}
	else if (document.forms[0].Helm.value != 0) {Attribute = Jattribute[document.forms[0].Helm.value];}
	else if (document.forms[0].Gauntlet.value != 0) {Attribute = Jattribute[document.forms[0].Gauntlet.value];}
	else if (document.forms[0].Boots.value != 0) {Attribute = Jattribute[document.forms[0].Boots.value];}
	else if (document.forms[0].Ring.value != 0) {Attribute = Jattribute[document.forms[0].Ring.value];}
	else if (document.forms[0].OtherP.value != 0) {Attribute = Jattribute[document.forms[0].OtherP.value];}
	else {return;}
	
	if (document.forms[0].Shield.value != 0 && Jattribute[document.forms[0].Shield.value] != Attribute) {return;}
	else if (document.forms[0].Armor.value != 0 && Jattribute[document.forms[0].Armor.value] != Attribute) {return;}
	else if (document.forms[0].Helm.value != 0 && Jattribute[document.forms[0].Helm.value] != Attribute) {return;}
	else if (document.forms[0].Gauntlet.value != 0 && Jattribute[document.forms[0].Gauntlet.value] != Attribute) {return;}
	else if (document.forms[0].Boots.value != 0 && Jattribute[document.forms[0].Boots.value] != Attribute) {return;}
	else if (document.forms[0].Ring.value != 0 && Jattribute[document.forms[0].Ring.value] != Attribute) {return;}
	else if (document.forms[0].OtherP.value != 0 && Jattribute[document.forms[0].OtherP.value] != Attribute) {return;}
	
	if (Attribute == 'Mars') {DFcolor = '$ColorMars';}
	else if (Attribute == 'Mercury') {DFcolor = '$ColorMercury';}
	else if (Attribute == 'Jupiter') {DFcolor = '$ColorJupiter';}
	else if (Attribute == 'Saturn') {DFcolor = '$ColorSaturn';}
	else if (Attribute == 'Uranus') {DFcolor = '$ColorUranus';}
	else if (Attribute == 'Pluto') {DFcolor = '$ColorPluto';}
}
END_OF_DFCOLOROPEN
	
	#뭠귩빾뛛궥귡
	$JSvalueChange = <<END_OF_VALUECHANGE;
function ValueChange(P, V) {
	if (P == 'Protector1') {document.forms[0].Shield.value = V;}
	else if (P == 'Protector2') {document.forms[0].Armor.value = V;}
	else if (P == 'Protector3') {document.forms[0].Helm.value = V;}
	else if (P == 'Protector4') {document.forms[0].Gauntlet.value = V;}
	else if (P == 'Protector5') {document.forms[0].Boots.value = V;}
	else if (P == 'Protector6') {document.forms[0].Ring.value = V;}
	else if (P == 'Protector7') {document.forms[0].OtherP.value = V;}
}
END_OF_VALUECHANGE
	
}

#?밶됪뽋걁뛘똼걂
sub JSattack {
	#뛘똼쀍궻뜃똶갂뛘똼쀍궻뜃똶궻빒럻륡갂MP
	$JSinfo = "var TotalAT = \"\";\n";
	$JSinfo .= "var ATcolor = '$ColorNormal';\n";
	$JSinfo .= "var MP = $MP[$X];\n";
	$JSinfo .= "var GP = $GP[$X];\n";
	$JSinfo .= "var UMcheck = $UMcheck;\n";
	$JSinfo .= "var UMcheckSub = $UMcheckSub;\n";
	
	#?딇궻뼹멟갂먣뼻갂롰쀞갂릶뭠갂?딇궻?렑
	$JSjname = "Jname = new Array();\n";
	$JSjexp = "Jexp = new Array();\n";
	$JSjtype = "Jtype = new Array();\n";
	$JSjkind = "Jkind = new Array();\n";
	$JSjdetail = "Jdetail = new Array();\n";
	$JSjattribute = "Jattribute = new Array();\n";
	$JSjmp = "Jmp = new Array();\n";
	$JSjpoint = "Jpoint = new Array();\n";
	$JSjpoint .= "Jpoint[0] = 0;\n";
	$JSjfree = "Jfree = new Array();\n";
	$JSjprice = "Jprice = new Array();\n";
	$JSjprice .= "Jprice[0] = 0;\n";
	
	$I = 1;
	foreach (@MyJ) {
		if ($_) {
			&Jdeco($_);
			&JdecoShrine;
			$JSjname .= "Jname[$I] = '$JnameDeco';\n";
			$JSjexp .= "Jexp[$I] = '$JexpDeco';\n";
			$JSjtype .= "Jtype[$I] = '$Jtype[$_]';\n";
			$JSjkind .= "Jkind[$I] = '$Jkind[$_]';\n";
			$JSjdetail .= "Jdetail[$I] = '$Jdetail[$_]';\n";
			$JSjattribute .= "Jattribute[$I] = '$Jattribute[$_]';\n";
			if ($Jmp[$_] > 0) {$JSjmp .= "Jmp[$I] = $Jmp[$_];\n";}
			else {$JSjmp .= "Jmp[$I] = 0;\n";}
			$JSjpoint .= "Jpoint[$I] = $JpointDeco;\n";
			if ($Jfree[$_]) {$JSjfree .= "Jfree[$I] = $Jfree[$_];\n";}
			$JSjprice .= "Jprice[$I] = $Jprice[$_];\n";
			
			$Jshow[$I] = "<A HREF=\"javascript:void(0)\" onMouseOver=\"JexpOpen($I)\" onClick=\"JnameOpen($I)\" CLASS=\"normal\"><IMG SRC=\"$Jimage[$_]\" ALT=\"$Jname[$_]\" TITLE=\"$Jname[$_]\" BORDER=0 WIDTH=\"80\" HEIGHT=\"80\">$JnameDeco</A>";
			
			$I++;
		}
	}
	#븧딇궕궶궚귢궽걏딣귡걐귩믁돿걁뫲?긾?긤귩룣궘걂
	if ($I <= 16 && time - $LastAccess[$X] >= $NextTime) {
		$J = 0;
		foreach (@MyJ) {
			if ($Jkind[$_] eq 'Weapon') {$J++;}
		}
		if ($J == 0) {
			&Jdeco(0);
			&JdecoShrine;
			$JSjname .= "Jname[$I] = '$JnameDeco';\n";
			$JSjexp .= "Jexp[$I] = '$JexpDeco';\n";
			$JSjtype .= "Jtype[$I] = '$Jtype[0]';\n";
			$JSjkind .= "Jkind[$I] = '$Jkind[0]';\n";
			$JSjpoint .= "Jpoint[$I] = $JpointDeco;\n";
			
			$Jshow[$I] = "<A HREF=\"javascript:void(0)\" onMouseOver=\"JexpOpen($I)\" onClick=\"JnameOpen($I)\" CLASS=\"normal\"><IMG SRC=\"$Jimage[0]\" ALT=\"$Jname[0]\" TITLE=\"$Jname[0]\" BORDER=0 WIDTH=\"80\" HEIGHT=\"80\">$JnameDeco</A>";
		}
	}
	
	#딉먘궻뼹멟갂먣뼻갂롰쀞갂릶뭠갂딉먘궻?렑
	$I = 17;
	foreach (@MyM) {
		if ($_) {
			&Jdeco($_);
			&JdecoShrine;
			$JSjname .= "Jname[$I] = '$JnameDeco';\n";
			$JSjexp .= "Jexp[$I] = '$JexpDeco';\n";
			$JSjtype .= "Jtype[$I] = '$Jtype[$_]';\n";
			$JSjkind .= "Jkind[$I] = '$Jkind[$_]';\n";
			$JSjdetail .= "Jdetail[$I] = '$Jdetail[$_]';\n";
			$JSjattribute .= "Jattribute[$I] = '$Jattribute[$_]';\n";
			if ($Jmp[$_] > 0) {$JSjmp .= "Jmp[$I] = $Jmp[$_];\n";}
			else {$JSjmp .= "Jmp[$I] = 0;\n";}
			$JSjpoint .= "Jpoint[$I] = $JpointDeco;\n";
			
			#딉먘궕럊뾭됀?궔?긃긞긏
			if ($Jtype[$_] eq 'Add') {
				$OnClick = " onClick=\"JnameOpen($I)\"";
			}
			elsif ($Jkind[$_] ne 'Revive' && $Jkind[$_] ne 'SoloP') {
				$OnClick = " onClick=\"Reset('All'); JnameOpen($I)\"";
			}
			else {
				$OnClick = "";
			}
			$Jshow[$I] = "<A HREF=\"javascript:void(0)\" onMouseOver=\"JexpOpen($I)\"$OnClick CLASS=\"normal\"><IMG SRC=\"$Jimage[$_]\" ALT=\"$Jname[$_]\" TITLE=\"$Jname[$_]\" BORDER=0 WIDTH=\"80\" HEIGHT=\"80\"><B>$JnameDeco</B></A>";
			
			$I++;
		}
	}
	#몴궻뼹멟갂먣뼻갂롰쀞갂릶뭠갂몴궻?렑
	$I = 23;
	if ($MyStatue[0]) {
		&Jdeco($MyStatue[0]);
		&JdecoShrine;
		$JSjname .= "Jname[$I] = '$JnameDeco';\n";
		$JSjexp .= "Jexp[$I] = '$JexpDeco';\n";
		$JSjtype .= "Jtype[$I] = '$Jtype[$MyStatue[0]]';\n";
		$JSjkind .= "Jkind[$I] = '$Jkind[$MyStatue[0]]';\n";
		$JSjdetail .= "Jdetail[$I] = '$Jdetail[$MyStatue[0]]';\n";
		$JSjattribute .= "Jattribute[$I] = '$Jattribute[$MyStatue[0]]';\n";
		if ($Jmp[$MyStatue[0]] > 0) {$JSjmp .= "Jmp[$I] = $Jmp[$MyStatue[0]];\n";}
		else {$JSjmp .= "Jmp[$I] = 0;\n";}
		$JSjpoint .= "Jpoint[$I] = $JpointDeco;\n";
		
		$Jshow[$I] = "<A HREF=\"javascript:void(0)\" onMouseOver=\"JexpOpen($I)\" onClick=\"JnameOpen($I)\" CLASS=\"normal\">$StatueDeco</A>";
	}
	else {
		$Jshow[$I] = $StatueDeco;
	}
	
	#?딇궻뼹멟귩긓?깛긤뿎궸?렑궥귡
	$JSjnameOpen = <<END_OF_JNAMEOPEN;
function JnameOpen(I) {
	if (I == document.forms[0].Act1.value) {return;}
	else if (I == document.forms[0].Act2.value) {return;} 
	else if (I == document.forms[0].Act3.value) {return;} 
	else if (I == document.forms[0].Act4.value) {return;}
	else if (I == document.forms[0].Act5.value) {return;}
	
	if (document.forms[0].Act1.value == 0) {		//Act1궕뼟볺쀍
		if (Jtype[I] == 'OneMore' || Jtype[I] == 'Solo' || Jtype[I] == 'NormalW' || Jtype[I] == 'SoloAdd') {
			if (MP < Jmp[I] && UMcheck == 0) {return;}
			var Place = 'Weapon1';
		}
		else {
			return;
		}
	}
	else if (Jtype[document.forms[0].Act1.value] == 'OneMore') {
								//Act1궕믁돿뷠뾴?
		if (Jkind[document.forms[0].Act1.value] == 'AllS') {		//Act1궕뭤땯?궻몴
			if (I <= 16 && Jkind[I] != 'Pray') {
				if (document.forms[0].Act2.value == 0) {var Place = 'Weapon2';}
				else if (document.forms[0].Act3.value == 0) {var Place = 'Weapon3';}
				else if (document.forms[0].Act4.value == 0) {var Place = 'Weapon4';}
				else {var Place = 'Weapon5';}
			}
			else if (Jtype[I] == 'OneMore' || Jtype[I] == 'Solo' || Jtype[I] == 'NormalW' || Jtype[I] == 'SoloAdd') {
				if (MP < Jmp[I] && UMcheck == 0) {return;}
				Reset('Weapon2'); var Place = 'Weapon1';
			}
			else {return;}
		}
		else if (Jkind[document.forms[0].Act1.value] == 'WeaponS') {		//Act1궕븧?궻몴
			if (I <= 16 && Jmp[I] == 0 && Jkind[I] == 'Weapon') {
				if (document.forms[0].Act2.value == 0) {var Place = 'Weapon2';}
				else if (document.forms[0].Act3.value == 0) {var Place = 'Weapon3';}
				else if (document.forms[0].Act4.value == 0) {var Place = 'Weapon4';}
				else {var Place = 'Weapon5';}
			}
			else if (Jtype[I] == 'OneMore' || Jtype[I] == 'Solo' || Jtype[I] == 'NormalW' || Jtype[I] == 'SoloAdd') {
				if (MP < Jmp[I] && UMcheck == 0) {return;}
				Reset('Weapon2'); var Place = 'Weapon1';
			}
			else {return;}
		}
		else if (Jkind[document.forms[0].Act1.value] == 'ProtectorS') {		//Act1궕뎢?궻몴
			if (I <= 16 && Jmp[I] == 0 && (Jkind[I] == 'Shield' || Jkind[I] == 'Armor' || Jkind[I] == 'Helm' || Jkind[I] == 'Gauntlet' || Jkind[I] == 'Boots' || Jkind[I] == 'Ring' || Jkind[I] == 'OtherP' || Jkind[I] == 'SoloP')) {
				if (document.forms[0].Act2.value == 0) {var Place = 'Weapon2';}
				else if (document.forms[0].Act3.value == 0) {var Place = 'Weapon3';}
				else if (document.forms[0].Act4.value == 0) {var Place = 'Weapon4';}
				else {var Place = 'Weapon5';}
			}
			else if (Jtype[I] == 'OneMore' || Jtype[I] == 'Solo' || Jtype[I] == 'NormalW' || Jtype[I] == 'SoloAdd') {
				if (MP < Jmp[I] && UMcheck == 0) {return;}
				Reset('Weapon2'); var Place = 'Weapon1';
			}
			else {return;}
		}
		else if (Jkind[document.forms[0].Act1.value] == 'SundryS') {		//Act1궕랦?궻몴
			if (I <= 16 && Jkind[I] != 'Pray' && (Jmp[I] > 0 || !(Jkind[I] == 'Weapon' || Jkind[I] == 'Shield' || Jkind[I] == 'Armor' || Jkind[I] == 'Helm' || Jkind[I] == 'Gauntlet' || Jkind[I] == 'Boots' || Jkind[I] == 'Ring' || Jkind[I] == 'OtherP' || Jkind[I] == 'SoloP'))) {
				if (document.forms[0].Act2.value == 0) {var Place = 'Weapon2';}
				else if (document.forms[0].Act3.value == 0) {var Place = 'Weapon3';}
				else if (document.forms[0].Act4.value == 0) {var Place = 'Weapon4';}
				else {var Place = 'Weapon5';}
			}
			else if (Jtype[I] == 'OneMore' || Jtype[I] == 'Solo' || Jtype[I] == 'NormalW' || Jtype[I] == 'SoloAdd') {
				if (MP < Jmp[I] && UMcheck == 0) {return;}
				Reset('Weapon2'); var Place = 'Weapon1';
			}
			else {return;}
		}
		else if (Jkind[document.forms[0].Act1.value] == 'Sell') {
											//Act1궕봽귡
			if (I <= 16 && Jkind[I] != 'Pray') {var Place = 'Weapon2';}
			else if (Jtype[I] == 'OneMore' || Jtype[I] == 'Solo' || Jtype[I] == 'NormalW' || Jtype[I] == 'SoloAdd') {
				if (MP < Jmp[I] && UMcheck == 0) {return;}
				Reset('Weapon2'); var Place = 'Weapon1';
			}
			else {return;}
		}
		else if (Jkind[document.forms[0].Act1.value] == 'Release') {		//Act1궕곢됶뺳곣
			if (
				I <= 16
				 && (Jattribute[I] || Jdetail[I] == 'Earth')
				 && (MP >= Jprice[I] || UMcheck == 1)
			) {
				var Place = 'Weapon2';
			}
			else if (
				I <= 16
				 && Jkind[I] == 'Mirac'
				 && (
					(MP >= Jprice[I] && document.forms[0].MP.value >= Jprice[I])
					 || UMcheckSub == 1
				)
			) {
				var Place = 'Weapon2';
			}
			else if (Jtype[I] == 'OneMore' || Jtype[I] == 'Solo' || Jtype[I] == 'NormalW' || Jtype[I] == 'SoloAdd') {
				if (MP < Jmp[I] && UMcheck == 0) {return;}
				Reset('Weapon2'); var Place = 'Weapon1';
			}
			else {return;}
		}
		else {return;}
	}
	else if (Jtype[document.forms[0].Act1.value] == 'Solo' || Jtype[document.forms[0].Act1.value] == 'SoloAdd') {
								//Act1궕뭁벲?갂뭁벲갋띍뢎믁돿?
		if (Jtype[I] == 'OneMore' || Jtype[I] == 'Solo'|| Jtype[I] == 'NormalW' || Jtype[I] == 'SoloAdd') {
			var Place = 'Weapon1';
		}
		else {return;}
	}
	else {							//Act1궕뼰뫌맜븧딇
		if (!(Jtype[I] == 'SoloAdd' || Jtype[I] == 'Add' || Jtype[I] == 'Adds')) {
									//볺쀍궕믁돿?궳궶궋뤾뜃
			if (Jtype[I] == 'OneMore' || Jtype[I] == 'Solo' || Jtype[I] == 'NormalW') {
				Reset('Weapon2'); var Place = 'Weapon1';
			}
			else {return;}
		}
		else {							//볺쀍궕믁돿?
			if (UMcheck == 0) {
				if (Jdetail[document.forms[0].Act1.value] == 'MagicalW') {	//Act1궕MP뤑뷂?
					if (MP < Jmp[I]) {
						return;
					}
					else if (
						document.forms[0].MP.value >= Jfree[document.forms[0].Act1.value]
						 && MP - Jfree[document.forms[0].Act1.value] < Jmp[I]
					) {
						return;
					}
				}
				else if (Jdetail[document.forms[0].Act1.value] == 'MagicalRod') {
					if (MP - document.forms[0].MP.value < Jmp[I]) {return;}
				}
			}
			
			if (Jtype[document.forms[0].Act2.value] != 'Adds') {		//Act2궕븸릶믁돿?궳궶궋뤾뜃
				var Place = 'Weapon2';
			}
			else if (Jtype[document.forms[0].Act3.value] != 'Adds') {	//Act3궕븸릶믁돿?궳궶궋뤾뜃
				var Place = 'Weapon3';
			}
			else if (Jtype[document.forms[0].Act4.value] != 'Adds') {	//Act4궕븸릶믁돿?궳궶궋뤾뜃
				var Place = 'Weapon4';
			}
			else {
				var Place = 'Weapon5';
			}
		}
	}
	
	TextChange(Place, Jname[I]);
	ValueChange(Place, I);
	TotalATopen();
}
END_OF_JNAMEOPEN
	
	#깏긜긞긣??깛궻룉뿚
	$JSresetButton = <<END_OF_RESETBUTTON;
function ResetButton() {
	document.forms[0].HP.value = $HP[$X];
	document.forms[0].MP.value = $MP[$X];
	document.forms[0].GP.value = $GP[$X];
	
	document.forms[0].Target.value = $X;
}
END_OF_RESETBUTTON
	
	#긓?깛긤궻깏긜긞긣룉뿚
	$JSreset = <<END_OF_RESET;
function Reset(Place) {
	TextChange('Weapon5', ""); ValueChange('Weapon5', 0);
	
	if (Place != 'Weapon5') {
		TextChange('Weapon4', ""); ValueChange('Weapon4', 0);
		
		if (Place != 'Weapon4') {
			TextChange('Weapon3', ""); ValueChange('Weapon3', 0);
			
			if (Place != 'Weapon3') {
				TextChange('Weapon2', ""); ValueChange('Weapon2', 0);
				
				if (Place != 'Weapon2') {
					TextChange('Weapon1', ""); ValueChange('Weapon1', 0);
				}
			}
		}
	}
	
	TotalATopen();
}
END_OF_RESET
	
	#뛘똼쀍궻뜃똶귩똶럁궥귡
	$JStotalATopen = <<END_OF_TOTALATOPEN;
function TotalATopen() {
	CheckPselect();
	
	if (
		document.forms[0].Act1.value != 0
		 && Jkind[document.forms[0].Act1.value] != 'Weapon'
		 && Jkind[document.forms[0].Act1.value] != 'TargetAct'
		 && Jkind[document.forms[0].Act1.value] != 'AllAct'
	) {
		if (Jkind[document.forms[0].Act1.value] == 'Jug') {
			if (document.forms[0].GP.value <= GP) {var HPup = document.forms[0].GP.value * 2;}
			else {var HPup = GP * 2;}
			
			TotalAT = '<FONT COLOR=$ColorNormal>HP' + HPup + '</FONT>';
		}
		else {
			TotalAT = Jpoint[document.forms[0].Act1.value];
		}
	}
	else {
		if (Jdetail[document.forms[0].Act1.value] == 'MagicalW' && document.forms[0].MP.value >= Jfree[document.forms[0].Act1.value]) {
			var FirstAct = Jpoint[document.forms[0].Act1.value] * 2;
		}
		else if (Jdetail[document.forms[0].Act1.value] == 'MagicalRod') {
			if (document.forms[0].MP.value <= MP) {var FirstAct = document.forms[0].MP.value * 2;}
			else {var FirstAct = MP * 2;}
		}
		else {
			var FirstAct = Jpoint[document.forms[0].Act1.value];
		}
		
		ATcolor = '$ColorNormal';
		ATcolorOpen();
		
		if (FirstAct >= 1000 && Jdetail[document.forms[0].Act1.value] != 'MagicalRod') {
			var T = FirstAct % 1000;
			TotalAT = '<FONT COLOR=' + ATcolor + '>전AT' + T + '</FONT>';
		}
		else {
			var T = FirstAct;
			if (Jtype[document.forms[0].Act2.value] == 'Adds') {T += Jfree[document.forms[0].Act2.value];}
			else {T += Jpoint[document.forms[0].Act2.value];}
			if (Jtype[document.forms[0].Act3.value] == 'Adds') {T += Jfree[document.forms[0].Act3.value];}
			else {T += Jpoint[document.forms[0].Act3.value];}
			if (Jtype[document.forms[0].Act4.value] == 'Adds') {T += Jfree[document.forms[0].Act4.value];}
			else {T += Jpoint[document.forms[0].Act4.value];}
			if (Jtype[document.forms[0].Act5.value] == 'Adds') {T += Jfree[document.forms[0].Act5.value];}
			else {T += Jpoint[document.forms[0].Act5.value];}
			
			if (T % 10 == 2) {
				T = (T - 2) * 2;
			}
			
			if (T == 0) {TotalAT = '-';}
			else {TotalAT = '<FONT COLOR=' + ATcolor + '>AT' + T + '</FONT>';}
		}
	}
	
	TextChange('TotalAttack', TotalAT);
}
END_OF_TOTALATOPEN
	
	#긓?깛긤귩볺쀍궢궫륉뫴궳P긜깒긏긣귩빾뛛궢궫띧궸맯궣귡빾돸
	$JScheckPselect = <<END_OF_CHECKPSELECT;
function CheckPselect() {
	if (
		Jkind[document.forms[0].Act1.value] == 'Release' && Jkind[document.forms[0].Act2.value] == 'Mirac'
		 && (
			(
				MP < Jprice[document.forms[0].Act2.value]
				 || document.forms[0].MP.value < Jprice[document.forms[0].Act2.value]
			)
			 && UMcheckSub == 0
		)
	) {
		Reset('Weapon2');
	}
	else if (UMcheck == 0) {
		var CPSflag = 0;
		
		if (Jtype[document.forms[0].Act2.value] == 'Add') {var CPSvalue = document.forms[0].Act2.value; var CPSplace = 'Weapon2';}
		else if (Jtype[document.forms[0].Act3.value] == 'Add') {var CPSvalue = document.forms[0].Act3.value; var CPSplace = 'Weapon3';}
		else if (Jtype[document.forms[0].Act4.value] == 'Add') {var CPSvalue = document.forms[0].Act4.value; var CPSplace = 'Weapon4';}
		else if (Jtype[document.forms[0].Act5.value] == 'Add') {var CPSvalue = document.forms[0].Act5.value; var CPSplace = 'Weapon5';}
		
		if (Jdetail[document.forms[0].Act1.value] == 'MagicalW') {
			if (MP < Jmp[CPSvalue]) {
				var CPSflag = 1;
			}
			else if (
				document.forms[0].MP.value >= Jfree[document.forms[0].Act1.value]
				 && MP - Jfree[document.forms[0].Act1.value] < Jmp[CPSvalue]
			) {
				var CPSflag = 1;
			}
		}
		else if (Jdetail[document.forms[0].Act1.value] == 'MagicalRod') {
			if (MP - document.forms[0].MP.value < Jmp[CPSvalue]) {var CPSflag = 1;}
		}
		
		if (CPSflag == 1) {
			Reset(CPSplace);
		}
	}
}
END_OF_CHECKPSELECT
	
	#뛘똼쀍궻뜃똶?렑궻륡귩뵽믦궥귡
	$JSatColorOpen = <<END_OF_ATCOLOROPEN;
function ATcolorOpen() {
	var Attribute = "";
	if (Jattribute[document.forms[0].Act1.value] != 0) {Attribute = Jattribute[document.forms[0].Act1.value];}
	else if (Jattribute[document.forms[0].Act2.value] != 0) {Attribute = Jattribute[document.forms[0].Act2.value];}
	else if (Jattribute[document.forms[0].Act3.value] != 0) {Attribute = Jattribute[document.forms[0].Act3.value];}
	else if (Jattribute[document.forms[0].Act4.value] != 0) {Attribute = Jattribute[document.forms[0].Act4.value];}
	else if (Jattribute[document.forms[0].Act5.value] != 0) {Attribute = Jattribute[document.forms[0].Act5.value];}
	else {return;}
	
	if (Attribute == 'Mars') {ATcolor = '$ColorMars';}
	else if (Attribute == 'Mercury') {ATcolor = '$ColorMercury';}
	else if (Attribute == 'Jupiter') {ATcolor = '$ColorJupiter';}
	else if (Attribute == 'Saturn') {ATcolor = '$ColorSaturn';}
	else if (Attribute == 'Uranus') {ATcolor = '$ColorUranus';}
	else if (Attribute == 'Pluto') {ATcolor = '$ColorPluto';}
}
END_OF_ATCOLOROPEN
	
	#뭠귩빾뛛궥귡
	$JSvalueChange = <<END_OF_VALUECHANGE;
function ValueChange(P, V) {
	if (P == 'Weapon1') {document.forms[0].Act1.value = V;}
	else if (P == 'Weapon2') {document.forms[0].Act2.value = V;}
	else if (P == 'Weapon3') {document.forms[0].Act3.value = V;}
	else if (P == 'Weapon4') {document.forms[0].Act4.value = V;}
	else if (P == 'Weapon5') {document.forms[0].Act5.value = V;}
}
END_OF_VALUECHANGE
	
	#몭륪??깛
	if (
		time - $LastAccess[$X] >= $NextTime
		 && $HP[$X] > 0
		 && !$Winner
		 && !($AllIllusionMode && $MyCondition[3])
	) {
		$JSsubmit = <<END_OF_SUBMIT_ON;
function Submit() {
	if (document.forms[0].Act1.value == 0) {
		alert('神器를 선택해주세요.');
	}
	else if (Jtype[document.forms[0].Act1.value] == 'OneMore' && document.forms[0].Act2.value == 0) {
		alert('또 한개의 神器를 선택해주세요.');
	}
	else if (
		Jkind[document.forms[0].Act1.value] == 'Exchange'
		 && TotalP - document.forms[0].HP.value - document.forms[0].MP.value - document.forms[0].GP.value != 0
	) {
		alert('파라메터 선택이 정확하지 않습니다.');
	}
	else if (
		document.forms[0].Target.value == $X && 
		(
			(
				Jkind[document.forms[0].Act1.value] == 'Weapon'
				 && !(Jdetail[document.forms[0].Act1.value] == 'Kine')
				 && !(Jpoint[document.forms[0].Act1.value] >= 1000)
			)
			 || Jkind[document.forms[0].Act1.value] == 'Sell'
			 || Jkind[document.forms[0].Act1.value] == 'Buy'
			 || Jkind[document.forms[0].Act1.value] == 'TargetAct'
		)
	) {
		res = confirm("자신에게 공격합니다. 괜찮습니까?");
		if (res == true) {document.forms[0].submit();}
		else {return;}
	}
	else {
		document.forms[0].submit();
	}
}
END_OF_SUBMIT_ON
	}
	elsif ($AllIllusionMode && $MyCondition[3]) {
		$JSsubmit = <<END_OF_SUBMIT_ALLILLUSION;
function Submit() {
	document.forms[0].submit();
}
END_OF_SUBMIT_ALLILLUSION
	}
	else {
		$JSsubmit = <<END_OF_SUBMIT_OFF;
function Submit() {
	alert('행동할 수 없습니다.');
}
END_OF_SUBMIT_OFF
	}
}

#?밶뻂뽦됪뽋
sub JSvisit {
	#먣뼻귩?렑궥귡
	$JSjexpOpen = <<END_OF_JEXPOPEN;
function JexpOpen(Count, Seller) {
	var Place = 'Jexp' + Seller;
	TextChange(Place, Jexp[Count]);
}
END_OF_JEXPOPEN
	
	#?딇궻뼹멟귩긓?깛긤뿎궸?렑궥귡
	$JSjnameOpen = <<END_OF_JNAMEOPEN;
function JnameOpen(Count, Seller, SellStatue, Jnum) {
	var Place = 'Jname' + Seller;
	TextChange(Place, Jname[Count]);
	ValueChange(Seller, SellStatue, Jnum);
}
END_OF_JNAMEOPEN
	
	#깏긜긞긣??깛걁?렜궻귒걂
	$JSresetButton = <<END_OF_RESETBUTTON;
function ResetButton() {
	return;
}
END_OF_RESETBUTTON
	
	#긓?깛긤궻깏긜긞긣룉뿚
	$JSreset = <<END_OF_RESET;
function Reset() {
	$JSresetTC
	ValueChange(0, 0, 0);
}
END_OF_RESET
	
	#뭠귩빾뛛궥귡
	$JSvalueChange = <<END_OF_VALUECHANGE;
function ValueChange(Seller, SellStatue, Jnum) {
	document.forms[0].Seller.value = Seller;
	document.forms[0].SellStatue.value = SellStatue;
	document.forms[0].Jnum.value = Jnum;
}
END_OF_VALUECHANGE
	
	#몭륪??깛
	$JSsubmit = <<END_OF_SUBMIT;
function Submit() {
	if (document.forms[0].Jnum.value == 0) {
		alert('神器를 선택해 주십시오.');
	}
	else {
		document.forms[0].submit();
	}
}
END_OF_SUBMIT
	
}

#-----------------------
#성패기 파일 읽기
#-----------------------

sub ReadJudgment {
	open(JUDGMENT,"$JudgmentFile") || &Message('에러','성패기파일이 안열립니다.');
	flock(JUDGMENT, 2);
	
	$I = 1;
	while ($Judgment[$I] = <JUDGMENT>) {
		chomp($Judgment[$I]);
		$I++;
	}
	
	flock(JUDGMENT, 8);
	close(JUDGMENT);
}

#--------------------------
#성패기파일 쓰기
#--------------------------

sub WriteJudgment {
	open(JUDGMENT,">>$JudgmentFile") || &Message('에러','성패기파일이 안열립니다.');
	flock(JUDGMENT, 2);
	
	print JUDGMENT "$_[0]\n";
	
	flock(JUDGMENT, 8);
	close(JUDGMENT);
}

#--------------------------
#로그파일을 읽기
#--------------------------

sub ReadLog {
	open(LOG,"$LogFile") || &Message('에러','로그파일이 안열립니다.');
	flock(LOG, 2);
	
	#뙸띪궻?둉봏
	$GFyear = <LOG>; chomp($GFyear);
	
	#?딇궻럄귟릶륃뺪갂?딇궻럊뾭띙귒릶륃뺪
	$JnowNumLine = <LOG>; chomp($JnowNumLine);
	$JnowUseLine = <LOG>; chomp($JnowUseLine);
	
	#랷돿롌궻뼹멟갂롹빒
	$NameLine = <LOG>; chomp($NameLine); @Name = split(/<>/, $NameLine);
	$PasswordLine = <LOG>; chomp($PasswordLine); @Password = split(/<>/, $PasswordLine);
	
	#HP갂MP갂GP
	$HPline = <LOG>; chomp($HPline); @HP = split(/<>/, $HPline);
	$MPline = <LOG>; chomp($MPline); @MP = split(/<>/, $MPline);
	$GPline = <LOG>; chomp($GPline); @GP = split(/<>/, $GPline);
	
	#륉뫴갂몴갂롧뚯?
	$ConditionLine = <LOG>; chomp($ConditionLine); @Condition = split(/<>/, $ConditionLine);
	$StatueLine = <LOG>; chomp($StatueLine); @Statue = split(/<>/, $StatueLine);
	$GuardianLine = <LOG>; chomp($GuardianLine); @Guardian = split(/<>/, $GuardianLine);
	
	#룋렃?딇갂딉먘
	$JingiLine = <LOG>; chomp($JingiLine); @Jingi = split(/<>/, $JingiLine);
	$MiracleLine = <LOG>; chomp($MiracleLine); @Miracle = split(/<>/, $MiracleLine);
	
	#긵깒?깛긣
	$PresentLine = <LOG>; chomp($PresentLine); @Present = split(/<>/, $PresentLine);
	
	#괿굊귺긤깒긚갂띍뢎귺긏긜긚갂궓뜍궛
	$IPaddressLine = <LOG>; chomp($IPaddressLine); @IPaddress = split(/<>/, $IPaddressLine);
	$LastAccessLine = <LOG>; chomp($LastAccessLine); @LastAccess = split(/<>/, $LastAccessLine);
	$CommentLine = <LOG>; chomp($CommentLine); @Comment = split(/<>/, $CommentLine);
	
	#긦깄?긚
	$NewsLine = <LOG>; chomp($NewsLine); @News = split(/<>/, $NewsLine);
	
	#덇렄뭷뭚궢궫렄뜌
	$StopTime = <LOG>; chomp($StopTime);
	
	flock(LOG, 8);
	close(LOG);
}

#-------------
#로그파일 쓰기
#-------------

sub WriteLog {
	open(LOG, ">$LogFile") || &Message('에러','로그파일이 안열립니다.');
	flock(LOG, 2);
	
	print LOG "$GFyear\n";
	print LOG "$JnowNumLine\n";
	print LOG "$JnowUseLine\n";
	
	foreach (1..$PlayerMax) {print LOG "<>$Name[$_]";}
	print LOG "\n";
	foreach (1..$PlayerMax) {print LOG "<>$Password[$_]";}
	print LOG "\n";
	foreach (1..$PlayerMax) {print LOG "<>$HP[$_]";}
	print LOG "\n";
	foreach (1..$PlayerMax) {print LOG "<>$MP[$_]";}
	print LOG "\n";
	foreach (1..$PlayerMax) {print LOG "<>$GP[$_]";}
	print LOG "\n";
	foreach (1..$PlayerMax) {print LOG "<>$Condition[$_]";}
	print LOG "\n";
	foreach (1..$PlayerMax) {print LOG "<>$Statue[$_]";}
	print LOG "\n";
	foreach (1..$PlayerMax) {print LOG "<>$Guardian[$_]";}
	print LOG "\n";
	foreach (1..$PlayerMax) {print LOG "<>$Jingi[$_]";}
	print LOG "\n";
	foreach (1..$PlayerMax) {print LOG "<>$Miracle[$_]";}
	print LOG "\n";
	foreach (1..$PlayerMax) {print LOG "<>$Present[$_]";}
	print LOG "\n";
	foreach (1..$PlayerMax) {print LOG "<>$IPaddress[$_]";}
	print LOG "\n";
	foreach (1..$PlayerMax) {print LOG "<>$LastAccess[$_]";}
	print LOG "\n";
	foreach (1..$PlayerMax) {print LOG "<>$Comment[$_]";}
	print LOG "\n";
	foreach (1..$NewsMax) {print LOG "<>$News[$_]";}
	print LOG "\n";
	
	print LOG "$StopTime\n";
	
	flock(LOG, 8);
	close(LOG);
}

#----------------
#게임스타트 준비
#----------------

sub GameStart {
	#긬긚깗?긤봃뤪
	if ($in{'Password'} ne $AdminPass) {&Error;}
	
	#랷돿롌궕2릐뼟뼖궬궴긄깋?
	$I = 0;
	foreach (1..$PlayerMax) {
		if ($Name[$_]) {$I++;}
	}
	if ($I < 2) {&Error;}
	
	#?딇궻럄귟릶귩뼖?깛궸
	$I = 1;
	while ($Jname[$I]) {
		$JnowNum[$I] = $Jtotal[$I];
		$JnowUse[$I] = 0;
		$I++;
	}
	$JnowNumLine = join(",", @JnowNum);
	$JnowUseLine = join(",", @JnowUse);
	
	#멣덒궻띍뢎귺긏긜긚귩빾뛛
	foreach (1..$PlayerMax) {
		if ($Name[$_]) {
			$LastAccess[$_] = int(time - $NextTime * (int(rand(100)) / 100));
		}
	}
	
	&NewsChange('0,Start');
	
	&WriteLog;
	&Message('게임스타트','게임이 시작되었습니다.');
}

#-------------
#참가등록
#-------------

sub Entry {
	$EntryFlag = 1;
	&Echeck;
	
	#둎럑?긃긞긏
	if ($GFyear >= 2) {&Error;}
	
	#뼖덒?긃긞긏
	$Flag = 0;
	foreach (1..$PlayerMax) {
		if (!$Name[$_]) {$Flag = 1; last;}
	}
	if (!$Flag) {
		&Error;
	}
	
	#륷딮랷돿롌궻뱋?붥뜂뒆귟뱰궲
	$X = 1;
	while ($Name[$X]) {
		$X++;
	}
	
	#둫뭠귩룊딖돸
	$Name[$X] = $Name;
	$Password[$X] = crypt($Pass, 'gf');
	
	$HP[$X] = $StartHP;
	$MP[$X] = $StartMP;
	$GP[$X] = $StartGP;
	
	#뷲걁0=궶궢갂1=롢븮뷲갂2=롢븮뷲뵯띿갂3=떗븮뷲갂4=떗븮뷲뵯띿갂5=뭤뜓뷲갂6=뭤뜓뷲뵯띿갂7=밮뜎뷲걂
	#뼳갂멝뚹갂뙳둶갂댠?걁0=궶궢갂1=궇귟걂
	#$Condition[$X] = '0,0,0,0,0';	뷲갂뼳갂멝뚹갂뙳둶갂댠?
	if ($AllDiseaseMode) {$MyCondition[0] = $AllDiseaseMode;} else {$MyCondition[0] = 0;}
	if ($AllFogMode) {$MyCondition[1] = 1;} else {$MyCondition[1] = 0;}
	if ($AllFlashMode) {$MyCondition[2] = 1;} else {$MyCondition[2] = 0;}
	if ($AllIllusionMode) {$MyCondition[3] = 1;} else {$MyCondition[3] = 0;}
	if ($AllDarkCloudMode) {$MyCondition[4] = 1;} else {$MyCondition[4] = 0;}
	$Condition[$X] = join(",", @MyCondition);
	
	$Statue[$X] = ',0,0,0,0,0,0,0,0';	#몴궻롰쀞갂떉궑븿1?4갂떉궑궫렄뜌1?4
	$Guardian[$X] = ',0';		#롧뚯?궻롰쀞갂롧뚯?궻HP
	
	$Jingi[$X] = "";
	$Miracle[$X] = "";
	
	$Present[$X] = "";
	
	#룊귕궻?딇귩봹귡
	$Present[$X] .= "==$X,Give,$StartJingi";
	
	&GetIP;
	$LastAccess[$X] = time;
	$Comment[$X] = '...';
	
	$News[1] .= ":$X,Entry";
	
	&WriteLog;
	&Message('참가등록완료',"<FONT COLOR=$ColorProphet><B>$Name</B></FONT>님 참가등록을 완료하셨습니다.");
}

sub Echeck {
	#뼹멟궸럊귦귢궫벫롪딯뜂궶궵귩빾듂
	$Name = $in{'Name'};
	$Name =~ s/&/&amp;/g;
	$Name =~ s/"/&quot;/g;
	$Name =~ s/</&lt;/g;
	$Name =~ s/>/&gt;/g;
	
	#긬긚깗?긤궸럊귦귢궫벫롪딯뜂궶궵귩?긃긞긏
	$Pass = $in{'Password'};
	$Pass =~ s/&/&amp;/g;
	$Pass =~ s/"/&quot;/g;
	$Pass =~ s/</&lt;/g;
	$Pass =~ s/>/&gt;/g;
	if ($Pass ne $in{'Password'}) {&Error;}
	
	#뼹멟궴긬긚깗?긤궻?딼?긃긞긏
	if ($EntryFlag) {
		if (!$Name || !$in{'Password'}) {&Error;}
	}
	
	#뼹멟궻뮮궠?긃긞긏
	if (length($Name) > 20) {
		&Message('에러','이름이 너무 깁니다.');
	}
	
	#벏뼹?긃긞긏
	foreach (1..$PlayerMax) {
		if ($Name[$_] && $Name[$_] eq $Name) {
			&Message('에러','이미 존재하는 이름입니다.');
		}
	}
	
	#?뽵뼹멟?긃긞긏
	if ($Name eq $AdminWord) {&NameError;}
	foreach (@ReservedName) {
		if ($Name eq $_) {&NameError;}
	}
	@ConditionName = values(%ConditionName);
	foreach (@ConditionName) {
		if ($Name eq $_) {&NameError;}
	}
	@GuardianName = values(%GuardianName);
	foreach (@GuardianName) {
		if ($Name eq $_) {&NameError;}
	}
	foreach (@Jname) {
		if ($Name eq $_) {&NameError;}
	}
	
	#긬긚깗?긤궻뮮궠?긃긞긏
	if (length($Pass) > 8) {
		&Error;
	}
}

#------------------
#이름과 주문의 변경
#------------------

sub Edit {
	if (!$in{'Number'}) {&Admin;}
	
	#긬긚깗?긤봃뤪
	$CryptedPass = crypt($in{'NowPass'}, 'gf');
	if ($CryptedPass ne $Password[$X] && $in{'NowPass'} ne $AdminPass) {
		&Message('에러','패스워드가 틀립니다.');
	}
	
	&Echeck;
	
	#빾뛛룉뿚
	if ($Name) {
		if ($GFyear == 1) {$Name[$X] = $Name;}
		else {&Error;}
	}
	if ($Pass) {$Password[$X] = crypt($Pass, 'gf');}
	
	&WriteLog;
	&Message('변경완료','변경이 완료되었습니다.');
}

#-------------
#코멘트 변경
#-------------

sub CommentChange {
	#긓긽깛긣궻뮮궠?긃긞긏
	$I = length($in{'Comment'});
	if ($I > 80) {
		&Message('에러',"최대 40바이트까지 가능합니다.<BR>입력된 길이는 $I바이트 입니다.");
	}
	
	#긓긽깛긣궸럊귦귢궫벫롪딯뜂궶궵귩빾듂
	$NewCom = $in{'Comment'};
	$NewCom =~ s/&/&amp;/g;
	$NewCom =~ s/"/&quot;/g;
	$NewCom =~ s/</&lt;/g;
	$NewCom =~ s/>/&gt;/g;
	
	if ($NewCom) {$Comment[$X] = $NewCom;}
	else {&Error;}
}

#-------------
#관리모드
#-------------

#듖뿚긾?긤됪뽋
sub Admin {
	#긬긚깗?긤봃뤪
	if ($in{'NowPass'} ne $AdminPass) {&Error;}
	
	#긒??궻긚??긣??깛
	$I = 0;
	foreach (1..$PlayerMax) {
		if ($Name[$_]) {$I++;}
	}
	if ($GFyear == 1 && $I >= 2) {
		$StartButton = <<END_OF_STARTBUTTON;
<FORM ACTION="$ThisFile" METHOD="POST">
<INPUT TYPE="hidden" NAME="Password" VALUE="$AdminPass">
<INPUT TYPE="hidden" NAME="Mode" VALUE="GameStart">
<INPUT TYPE="submit" VALUE="  ☆게임 스타트☆  " CLASS="button">
</FORM>
END_OF_STARTBUTTON
	}
	elsif ($StopTime) {
		$StartButton = <<END_OF_STARTBUTTON;
<FORM ACTION="$ThisFile" METHOD="POST">
<INPUT TYPE="hidden" NAME="Password" VALUE="$AdminPass">
<INPUT TYPE="hidden" NAME="StopTime" VALUE="Off">
<INPUT TYPE="hidden" NAME="Mode" VALUE="AdminEdit">
<INPUT TYPE="submit" VALUE="  神界의 시간이 흐른다.  " CLASS="button">
</FORM>
END_OF_STARTBUTTON
	}
	else {
		$StartButton = <<END_OF_STARTBUTTON;
<FORM ACTION="$ThisFile" METHOD="POST">
<INPUT TYPE="hidden" NAME="Password" VALUE="$AdminPass">
<INPUT TYPE="hidden" NAME="StopTime" VALUE="On">
<INPUT TYPE="hidden" NAME="Mode" VALUE="AdminEdit">
<INPUT TYPE="submit" VALUE="  神界의 시간을 멈춘다.  " CLASS="button">
</FORM>
END_OF_STARTBUTTON
	}
	
	#랷돿롌뤬띢?
	$AdminOption = "";
	$AdminTable = "<TABLE BORDER=1 BGCOLOR=$ColorTable>\n<TR BGCOLOR=$ColorTR><TH><FONT COLOR=$ColorTRfont>No.</FONT></TH><TH><FONT COLOR=$ColorTRfont>이름</FONT></TH><TH><FONT COLOR=$ColorTRfont>IP주소</FONT></TH><TH><FONT COLOR=$ColorTRfont>최종접속</FONT></TH></TR>\n";
	foreach (1..$PlayerMax) {
		if ($Name[$_]) {
			$AdminOption .= "<OPTION VALUE=\"$_\">$Name[$_]\n";
			
			#뼹멟궻륡
			if ($HP[$_] > 0) {
				$NameColor = $ColorProphet;
			}
			else {
				$NameColor = $ColorLost;
			}
			
			#띍뢎귺긏긜긚궻몧륕
			$LAdeco = &DateDeco($LastAccess[$_]);
			if ($GFyear >= 2) {
				if ($HP[$_] == 0) {
					$LAdeco = "<FONT COLOR=$ColorLost>$LAdeco</FONT>";
				}
				elsif (time - $LastAccess[$_] >= ($RemoveTime * 3/4)) {
					$LAdeco = "<FONT COLOR=$ColorDamage><B>$LAdeco</B></FONT>";
				}
				elsif (time - $LastAccess[$_] >= ($RemoveTime * 1/2)) {
					$LAdeco = "<FONT COLOR=$ColorDamage>$LAdeco</FONT>";
				}
			}
			
			$AdminTable .= "<TR BGCOLOR=$ColorTDup><TH>$_</TH><TH><FONT COLOR=$NameColor>$Name[$_]</FONT></TH><TD>$IPaddress[$_]</TD><TD>$LAdeco</TD></TR>\n";
		}
	}
	$AdminTable .= "</TABLE>";
	
	#긒??깏긜긞긣??깛
	$GameReset = <<END_OF_GAMERESET;
<FORM ACTION="$ThisFile" METHOD="POST">
<INPUT TYPE="hidden" NAME="Password" VALUE="$AdminPass">
<INPUT TYPE="hidden" NAME="GameReset" VALUE="On">
<INPUT TYPE="hidden" NAME="Mode" VALUE="AdminEdit">
<INPUT TYPE="submit" VALUE="  ▼게임 리셋▼  " CLASS="button">
</FORM>
END_OF_GAMERESET
	
	#듖뿚긾?긤됪뽋뢯쀍
	print <<END_OF_ADMINEDIT;
Content-type: text/html; charset=utf-8

<HTML>

<HEAD>

$Meta

<TITLE>관리모드</TITLE>

$Style

</HEAD>

$Body

<CENTER>

<BIG><B>관리모드</B></BIG>

$StartButton

<FORM ACTION="$ThisFile" METHOD="POST">
<SELECT NAME="Number">
$AdminOption</SELECT>  
<INPUT TYPE="hidden" NAME="Mode" VALUE="AdminEdit">
<INPUT TYPE="hidden" NAME="Password" VALUE="$AdminPass">
<INPUT TYPE="submit" VALUE=" 神界에서 추방한다. " CLASS="button"><BR>
</FORM>
<BR>
$AdminTable
<BR><BR>
$GameReset

</CENTER>

<HR>

<A HREF="$ThisFile" CLASS="link">갓필드TOP</A><BR>
<BR>
<A HREF="$HomePage" CLASS="link">홈페이지TOP</A>

</BODY>

</HTML>
END_OF_ADMINEDIT

	&End;
}

#듖뿚긾?긤룉뿚궴뢎뿹됪뽋
sub AdminEdit {
	#긬긚깗?긤봃뤪
	if ($in{'Password'} ne $AdminPass) {&Error;}
	
	if ($in{'StopTime'} eq 'On') {
		$StopTime = time;
		&WriteLog;
		&Message('게임일시정지', '게임을 일시정지 했습니다.');
	}
	elsif ($in{'StopTime'} eq 'Off') {
		$LossTime = time - $StopTime;
		foreach (1..$PlayerMax) {
			if ($HP[$_] > 0) {
				$LastAccess[$_] += $LossTime;
				
				if ($Statue[$_]) {
					@YourStatue = split(/,/, $Statue[$_]);
					foreach $I (5..8) {
						if ($YourStatue[$I]) {
							$YourStatue[$I] += $LossTime;
						}
					}
				}
			}
		}
		
		$StopTime = "";
		&WriteLog;
		&Message('게임재개', '게임을 재개했습니다.');
	}
	elsif ($in{'GameReset'} eq 'On') {
		open(LOG, ">$LogFile") || &Message('에러','로그파일이 안열립니다.');
		flock(LOG, 2);
		print LOG "";
		flock(LOG, 8);
		close(LOG);
		
		open(JUDGMENT,">$JudgmentFile") || &Message('에러','성패기가 안열립니다.');
		flock(JUDGMENT, 2);
		print JUDGMENT "";
		flock(JUDGMENT, 8);
		close(JUDGMENT);
		
		$DrawFlag = 0;
		
		&Message('게임리셋', '게임을 리셋했습니다.');
	}
	else {
		#떗맕랁룣
		&MyClean($X);
		
		#긒??둎럑멟궶귞궽뼹멟궴긦깄?긚귖랁룣
		if ($GFyear == 1) {
			$Name[$X] = "";
			@EntryNews = split(/:/, $News[1]);
			foreach (1..$PlayerMax) {
				@J = split(/,/, $EntryNews[$_]);
				if ($J[0] == $X) {
					splice(@EntryNews, $_, 1);
					last;
				}
			}
			$News[1] = join(":", @EntryNews);
		}
		
		&WriteLog;
		&Message('삭제완료', '삭제를 완료했습니다.');
	}
}

#--------------
#패스워드확인
#--------------

sub PassCheck {
	#뼹멟궻?딼?긃긞긏
	if (!$Name[$X]) {&Error;}
	
	#긬긚깗?긤봃뤪
	if (($in{'Mode'} eq 'Shrine' || $in{'Mode'} eq 'CommentChange') && $in{'NowPass'} ne $AdminPass) {$CryptedPass = crypt($in{'NowPass'}, 'gf');}
	else {$CryptedPass = $in{'NowPass'};}
	
	if ($CryptedPass ne $Password[$X] && $in{'NowPass'} ne $AdminPass) {
		&Message('에러','패스워드가 틀립니다.');
	}
}

#--------------
#HP체크
#--------------

sub HPcheck {
	#HP궕0궶귞긄깋?
	if ($HP[$X] == 0) {&Message('에러','신전은 더이상 없습니다.');}
	
	#?밶궳궻븉맫?긃긞긏
	if ($in{'Mode'} eq 'Defense' || $in{'Mode'} eq 'Attack') {
		#맯뫔롌궻둴봃
		$Exist = 0;
		foreach (1..$PlayerMax) {
			if ($HP[$_] > 0) {$Exist++;}
		}
		#?뿀뫲???깛궶귞긄깋?
		if (time - $LastAccess[$X] < $NextTime && $Exist > 1) {&Error;}
		
		if ($Present[$X] && $in{'Mode'} eq 'Attack') {
			$LeaveEatFlag = 1;
			&Shrine;
		}
		elsif (!$Present[$X] && $in{'Mode'} eq 'Defense') {&Error;}
	}
}

#-----------------
#입력부정체크
#-----------------

sub InputCheck {
	if ($in{'Number'} =~ /[^0-9]/ || $in{'Number'} > $PlayerMax) {&Error;}
	if ($in{'Shield'} =~ /[^0-9]/ || $in{'Shield'} > 16) {&Error;}
	if ($in{'Armor'} =~ /[^0-9]/ || $in{'Armor'} > 16) {&Error;}
	if ($in{'Helm'} =~ /[^0-9]/ || $in{'Helm'} > 16) {&Error;}
	if ($in{'Gauntlet'} =~ /[^0-9]/ || $in{'Gauntlet'} > 16) {&Error;}
	if ($in{'Boots'} =~ /[^0-9]/ || $in{'Boots'} > 16) {&Error;}
	if ($in{'Ring'} =~ /[^0-9]/ || $in{'Ring'} > 16) {&Error;}
	if ($in{'OtherP'} =~ /[^0-9]/ || $in{'OtherP'} > 22) {&Error;}
	if ($in{'Target'} =~ /[^0-9]/ || $in{'Target'} > $PlayerMax) {&Error;}
	if ($in{'Act1'} =~ /[^0-9]/ || $in{'Act1'} > 23) {&Error;}
	if ($in{'Act2'} =~ /[^0-9]/ || $in{'Act2'} > 22) {&Error;}
	if ($in{'Act3'} =~ /[^0-9]/ || $in{'Act3'} > 22) {&Error;}
	if ($in{'Act4'} =~ /[^0-9]/ || $in{'Act4'} > 22) {&Error;}
	if ($in{'Act5'} =~ /[^0-9]/ || $in{'Act5'} > 22) {&Error;}
	if ($in{'HP'} =~ /[^0-9]/ || $in{'HP'} % 10 != 0 || $in{'HP'} > 990) {&Error;}
	if ($in{'MP'} =~ /[^0-9]/ || $in{'MP'} % 10 != 0 || $in{'MP'} > 990) {&Error;}
	if ($in{'GP'} =~ /[^0-9]/ || $in{'GP'} % 10 != 0 || $in{'GP'} > 990) {&Error;}
}

#---------------
#입력수정
#---------------

sub InputModify {
	if ($Jkind[$MyJ[$in{'Act1'}]] eq 'Exchange') {
		if ($in{'HP'} eq "") {&Error;}
		if ($in{'MP'} eq "") {&Error;}
		if ($in{'GP'} eq "") {&Error;}
	}
	else {
		if ($in{'HP'} eq "") {$in{'HP'} = 0;}
		elsif ($in{'HP'} > $HP[$X]) {$in{'HP'} = $HP[$X];}
		if ($in{'MP'} eq "") {$in{'MP'} = 0;}
		elsif ($in{'MP'} > $MP[$X]) {$in{'MP'} = $MP[$X];}
		if ($in{'GP'} eq "") {$in{'GP'} = 0;}
		elsif ($in{'GP'} > $GP[$X]) {$in{'GP'} = $GP[$X];}
		
		if ($in{'HP'} =~ /[^0-9]/ || $in{'HP'} % 10 != 0 || $in{'HP'} > 990) {&Error;}
		if ($in{'MP'} =~ /[^0-9]/ || $in{'MP'} % 10 != 0 || $in{'MP'} > 990) {&Error;}
		if ($in{'GP'} =~ /[^0-9]/ || $in{'GP'} % 10 != 0 || $in{'GP'} > 990) {&Error;}
	}
}

#---------------
#메세지
#---------------

sub Message {
	if ($in{'Mode'} eq 'AllNews') {
		$MainMessage = $AllNewsShow;
	}
	elsif ($DrawFlag) {
		$MainMessage = $ShrineNews;
	}
	else {
		$MainMessage = <<END_OF_MAINMESSAGE;
<CENTER>

<BR>

<H3>$_[0]</H3>

<BR>
$_[1]
<BR>
<BR>
<BR>

</CENTER>
END_OF_MAINMESSAGE
	
	}
	
	print <<END_OF_MESSAGE;
Content-type: text/html; charset=utf-8

<HTML>

<HEAD>

$Meta

<TITLE>$_[0]</TITLE>

$Style

</HEAD>

$Body

$MainMessage

<HR>

$NextPageShow<A HREF="$ThisFile" CLASS="link">갓필드TOP</A><BR>
<BR>
<A HREF="$HomePage" CLASS="link">홈페이지TOP</A>

</BODY>

</HTML>
END_OF_MESSAGE

	&End;
}

sub Error {
	&Message('에러','부정적인 처리가 행해졌습니다.');
}

sub NameError {
	&Message('에러','그 이름은 사용할 수 없습니다. 다른 이름으로 해주세요.');
}

#--------------
#일시를 습득
#--------------

sub DateDeco {
	@Week = ('日','月','火','水','木','金','土');
	@Months = ('01','02','03','04','05','06','07','08','09','10','11','12');
	($Sec, $Min, $Hour, $Mday, $Mon, $Year, $Wday) = localtime($_[0]);
	if ($Mday < 10) {$Mday = '0'."$Mday";}
	if ($Hour < 10) {$Hour = '0'."$Hour";}
	if ($Min < 10) {$Min = '0'."$Min";}
	if ($Sec < 10) {$Sec = '0'."$Sec";}
	$Year += 1900;
	$DateDeco = "$Year/$Months[$Mon]/$Mday($Week[$Wday]) $Hour:$Min:$Sec";
}

sub DateDeco2 {
	@Week = ('日','月','火','水','木','金','土');
	@Months = ('01','02','03','04','05','06','07','08','09','10','11','12');
	($Sec, $Min, $Hour, $Mday, $Mon, $Year, $Wday) = localtime($_[0]);
	if ($Mday < 10) {$Mday = '0'."$Mday";}
	if ($Hour < 10) {$Hour = '0'."$Hour";}
	if ($Min < 10) {$Min = '0'."$Min";}
	if ($Sec < 10) {$Sec = '0'."$Sec";}
	$Year += 1900;
	$DateDeco = "$Months[$Mon]/$Mday $Hour:$Min:$Sec";
}

#-----------------
#IP주소 습득
#-----------------

sub GetIP {
	if ($in{'NowPass'} ne $AdminPass) {
		$Host = $ENV{'REMOTE_HOST'};
		$Addr = $ENV{'REMOTE_ADDR'};
		if ($Host ne "") {
			$IPaddress[$X] = $Host;
		}
		elsif ($Addr ne "") {
			$IPaddress[$X] = $Addr;
		}
	}
}

#-----------------
#쿠키습득
#-----------------

#긏긞긌?뢯쀍
sub CookieOut {
	local(@Date);
	local(@Week) = ('Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday');
	local(@Month) = ('Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec');
	@Date = gmtime(time + 30 * 86400);
	$Date[5] += 1900;
	
	foreach (0..3) {
		$Date[$_] = sprintf("%.2d",$Date[$_]);
	}
	
	$Expires = "$Week[$Date[6]], $Date[3]-$Month[$Date[4]]-$Date[5] $Date[2]:$Date[1]:$Date[0] GMT";
	
	if ($in{'PassSave'} ne 'on') {
		$in{'NowPass'} = "";
		$in{'PassSave'} = 'off';
	}
	$I = "$in{'Number'}<>$in{'NowPass'}<>$in{'PassSave'}";
	print "Set-Cookie: GODFIELD=$I; expires=$Expires\n";
}

#긏긞긌?롦벦
sub CookieIn {
	$CookieNum = 0;
	$CookiePass = '';
	$CookiePsave = '';
	foreach (split(/; /, $ENV{'HTTP_COOKIE'})) {
		($Key, $Value) = split(/=/);
		if ($Key eq 'GODFIELD') {
			($CookieNum, $CookiePass, $CookiePsave) = split(/<>/, $Value);
			last;
		}
	}
	
	if ($in{'Number'}) {$CookieNum = $in{'Number'};}
	if ($in{'NowPass'}) {$CookiePass = $in{'NowPass'};}
	if ($in{'PassSave'}) {$CookiePsave = $in{'PassSave'};}
}

#--------------------
#URL디코딩
#--------------------

sub Decode {
	if ($ENV{'REQUEST_METHOD'} eq 'GET') {
		$Buffer = $ENV{'QUERY_STRING'};
	}
	elsif ($ENV{'REQUEST_METHOD'} eq 'POST') {
		read(STDIN, $Buffer, $ENV{'CONTENT_LENGTH'});
	}
	else {
		&Error;
	}
	
	@Pairs = split(/&/, $Buffer);
	foreach $Pair (@Pairs) {
		($Key, $Value) = split(/=/, $Pair);
		$Key =~ tr/+/ /;
		$Key =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
		$Value =~ tr/+/ /;
		$Value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
		$in{"$Key"} = $Value;
	}
}

#--------------------
#락파일과 스크립트 종료
#--------------------

sub End {
	flock(LOCK,8);
	close(LOCK);
	
	exit;
}