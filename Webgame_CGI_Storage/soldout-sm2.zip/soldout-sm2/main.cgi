#!/usr/bin/perl
# $Id: main.cgi,v 1.5 2002/02/02 12:27:30 mu Exp $

require './_base.cgi';
GetQuery();

Turn();

#Lock();
DataRead();
CheckUserPass();
($Q{ck} ? SetCookie($Q{nm},$Q{pw}) : SetCookie("","")) if $Q{pw};
#DataWrite();
#UnLock();


RequireFile('inc-html-owner.cgi');
$disp.="<BR>";
RequireFile('inc-html-showcase.cgi');
$disp.="<BR>";
ReadLog($DT->{id},0,'','');
RequireFile('inc-html-log.cgi');

OutHTML('�����',$disp);

exit;

sub SetCookie
{
	my($nm,$pw)=@_;
	my $time=$nm ne "" ? $NOW_TIME+($EXPIRE_TIME<60*60*24*365 ? $EXPIRE_TIME*2 : 60*60*24*365) : 0;
	my($sec,$min,$hour,$mday,$mon,$year,$wday)=gmtime($time);
	my $expire=
		sprintf("%s, %02d-%s-%04d %02d:%02d:%02d GMT",
			('Sunday','Monday','Tuesday','Wednesday',
			 'Thursday','Friday','Saturday')[$wday],
			$mday,
			('Jan','Feb','Mar','Apr','May','Jun',
			 'Jul','Aug','Sep','Oct','Nov','Dec')[$mon],
			$year+1900,
			$hour,
			$min,
			$sec
		);
	print "Set-Cookie: USERNAME=$nm; expires=$expire;\n";
	print "Set-Cookie: PASSWORD=$pw; expires=$expire;\n";
	#print "Set-Cookie: shop=;\n";
}
