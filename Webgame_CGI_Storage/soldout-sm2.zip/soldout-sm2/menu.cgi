#!/usr/bin/perl
# $Id: menu.cgi,v 1.3 2001/12/31 12:59:30 mu Exp $

$NOITEM=1;
require './_base.cgi';
GetQuery();
DataRead();
CheckUserPass(1);

OutHTML('�޴�','');

exit;
