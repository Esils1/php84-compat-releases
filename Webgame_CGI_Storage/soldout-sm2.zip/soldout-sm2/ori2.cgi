#!/usr/bin/perl
# $Id: ori.cgi,v 1.3 2001/12/31 12:59:30 homing Exp $
#SM�����Դϴ�(ȣ��)

require './_base.cgi';

GetQuery();

DataRead();
CheckUserPass(1);

	hurulist();
	$disp.="<HR SIZE=1>";

	kokulist();
	$disp.="<HR SIZE=1>";

	zyulist();
	$disp.="<HR SIZE=1>";

	ryulist();
	$disp.="<HR SIZE=1>";

	supilist();

OutHTML('��������',$disp);
exit;

sub hurulist
{
	my $rank=1;
	my @huruDT=grep $_->{user}->{huru},map{$_->{_now_rank}=$rank++,$_}@DT;

	$disp.="��������� ���� ������<hr>";
	
	$disp.=join "",$TB,$TR,$TDNW,'����',$TDNW,'����',$TDNW,'����',$TDNW,'�������� ���ϸ�',$TRE,"\n";
	
	foreach my $DT (@huruDT)
	{
		my $itemtype=-1;
		my $itempro="";
		my $salelist="";
		foreach my $no (@{$DT->{showcase}})
		{
			$salelist.=GetTagImgItemType($no);
			$itemtype=0,next if $itemtype!=-1 && $ITEM[$no]->{type}!=$itemtype;
			$itemtype=$ITEM[$no]->{type};
		}
		$itempro=GetTagImgItemType(0,$itemtype,1)." " if $itemtype;
		my $job=$JOBTYPE{$DT->{job}};
		$job="��$job��" if $job;
		
		$disp.=join "",$TR,$TD,$DT->{_now_rank},$TD,$DT->{point},$TD,GetTagImgGuild($DT->{guild}).$itempro.$job.$DT->{shopname}."[$DT->{name}]",$TDNW,$DT->{user}->{huru},$TRE,"\n";

	}
	$disp.=$TBE;
	
	return 1;
}

sub kokulist
{
	my $rank=1;
	my @kokuDT=grep $_->{user}->{koku},map{$_->{_now_rank}=$rank++,$_}@DT;

	$disp.="��Ư�� � ������<hr>";
	
	$disp.=join "",$TB,$TR,$TDNW,'����',$TDNW,'����',$TDNW,'����',$TDNW,'Ư�� ���',$TRE,"\n";
	
	foreach my $DT (@kokuDT)
	{
		my $itemtype=-1;
		my $itempro="";
		my $salelist="";
		foreach my $no (@{$DT->{showcase}})
		{
			$salelist.=GetTagImgItemType($no);
			$itemtype=0,next if $itemtype!=-1 && $ITEM[$no]->{type}!=$itemtype;
			$itemtype=$ITEM[$no]->{type};
		}
		$itempro=GetTagImgItemType(0,$itemtype,1)." " if $itemtype;
		my $job=$JOBTYPE{$DT->{job}};
		$job="��$job��" if $job;

		$disp.=join "",$TR,$TD,$DT->{_now_rank},$TD,$DT->{point},$TD,GetTagImgGuild($DT->{guild}).$itempro.$job.$DT->{shopname}."[$DT->{name}]",$TDNW,$DT->{user}->{koku},$TRE,"\n";
	}
	$disp.=$TBE;
	
	return 1;
}

sub zyulist
{
	my $rank=1;
	my @zyuDT=grep $_->{user}->{zyu},map{$_->{_now_rank}=$rank++,$_}@DT;

	$disp.="��ͽ� �꽺 ������<hr>";
	
	$disp.=join "",$TB,$TR,$TDNW,'����',$TDNW,'����',$TDNW,'����',$TDNW,'�~�b�N�X�W���[�X��',$TRE,"\n";
	
	foreach my $DT (@zyuDT)
	{
		my $itemtype=-1;
		my $itempro="";
		my $salelist="";
		foreach my $no (@{$DT->{showcase}})
		{
			$salelist.=GetTagImgItemType($no);
			$itemtype=0,next if $itemtype!=-1 && $ITEM[$no]->{type}!=$itemtype;
			$itemtype=$ITEM[$no]->{type};
		}
		$itempro=GetTagImgItemType(0,$itemtype,1)." " if $itemtype;
		my $job=$JOBTYPE{$DT->{job}};
		$job="��$job��" if $job;

		$disp.=join "",$TR,$TD,$DT->{_now_rank},$TD,$DT->{point},$TD,GetTagImgGuild($DT->{guild}).$itempro.$job.$DT->{shopname}."[$DT->{name}]",$TDNW,$DT->{user}->{zyu},$TRE,"\n";
	}
	$disp.=$TBE;
	
	return 1;
}

sub ryulist
{
	my $rank=1;
	my @ryuDT=grep $_->{user}->{ryu},map{$_->{_now_rank}=$rank++,$_}@DT;

	$disp.="��Ư�� ��ť�� ������<hr>";
	
	$disp.=join "",$TB,$TR,$TDNW,'����',$TDNW,'����',$TDNW,'����',$TDNW,'Ư�� ��ť���',$TRE,"\n";
	
	foreach my $DT (@ryuDT)
	{
		my $itemtype=-1;
		my $itempro="";
		my $salelist="";
		foreach my $no (@{$DT->{showcase}})
		{
			$salelist.=GetTagImgItemType($no);
			$itemtype=0,next if $itemtype!=-1 && $ITEM[$no]->{type}!=$itemtype;
			$itemtype=$ITEM[$no]->{type};
		}
		$itempro=GetTagImgItemType(0,$itemtype,1)." " if $itemtype;
		my $job=$JOBTYPE{$DT->{job}};
		$job="��$job��" if $job;

		$disp.=join "",$TR,$TD,$DT->{_now_rank},$TD,$DT->{point},$TD,GetTagImgGuild($DT->{guild}).$itempro.$job.$DT->{shopname}."[$DT->{name}]",$TDNW,$DT->{user}->{ryu},$TRE,"\n";
	}
	$disp.=$TBE;
	
	return 1;
}

sub supilist
{
	my $rank=1;
	my @supiDT=grep $_->{user}->{supi},map{$_->{_now_rank}=$rank++,$_}@DT;

	$disp.="��Ư�� ���Ǹ��� ������<hr>";
	
	$disp.=join "",$TB,$TR,$TDNW,'����',$TDNW,'����',$TDNW,'����',$TDNW,'Ư�� ���Ǹ�����',$TRE,"\n";
	
	foreach my $DT (@supiDT)
	{
		my $itemtype=-1;
		my $itempro="";
		my $salelist="";
		foreach my $no (@{$DT->{showcase}})
		{
			$salelist.=GetTagImgItemType($no);
			$itemtype=0,next if $itemtype!=-1 && $ITEM[$no]->{type}!=$itemtype;
			$itemtype=$ITEM[$no]->{type};
		}
		$itempro=GetTagImgItemType(0,$itemtype,1)." " if $itemtype;
		my $job=$JOBTYPE{$DT->{job}};
		$job="��$job��" if $job;

		$disp.=join "",$TR,$TD,$DT->{_now_rank},$TD,$DT->{point},$TD,GetTagImgGuild($DT->{guild}).$itempro.$job.$DT->{shopname}."[$DT->{name}]",$TDNW,$DT->{user}->{supi},$TRE,"\n";
	}
	$disp.=$TBE;
	
	return 1;
}

