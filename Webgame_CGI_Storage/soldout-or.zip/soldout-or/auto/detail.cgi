# $Id: detail.cgi,v 1.4 2001/12/31 13:00:10 mu Exp $

sub SortDT
{
	my($mode)=@_;
	
	@DT=grep($_->{status},@DT);
	foreach(@DT){$_->{point}=GetDTPoint($_);}
	@DT=sort{(!$a->{rankingyesterday})<=>(!$b->{rankingyesterday}) or $b->{point}<=>$a->{point}}@DT;
	
	%id2idx  =map{($DT[$_]->{id},$_)}(0..$#DT);
	%name2idx=map{($DT[$_]->{name},$_)}(0..$#DT);
}

sub GetItemUseTime
{
	my($USE)=@_;
	my $exp=$USE->{result}->{expold}ne'' ? $USE->{result}->{expold} : $DT->{exp}->{$USE->{itemno}};
	return $USE->{time}-int(($USE->{time}-$USE->{exptime})*$exp/1000);
}

sub GetRankMessage
{
	my($rank,$mode)=@_;
	my $per=int($rank/100);
	
	return $per.(!$mode?"%":"") if $MOBILE;
	
	my $bar="";
	$bar ="<nobr>";
	$bar.="<img src=\"$IMAGE_URL/b$IMAGE_EXT\" width=\"".(    $per)."\" height=\"12\">" if $per;
	$bar.="<img src=\"$IMAGE_URL/r$IMAGE_EXT\" width=\"".(100-$per)."\" height=\"12\">" if $per!=100 && !$mode;
	$bar.=" ".$per;
	$bar.="%" if !$mode;
	$bar.="</nobr><br>";
	
	return $bar;
}

#�X�ܔ��p�ŗ��v�Z
sub GetUserTaxRate
{
	my($DT)=@_;
	
	my $taxrate=int($DT->{profitstock}/20000);
	$taxrate=0 if $taxrate<0;
	$taxrate=50 if $taxrate>50;
	return $taxrate;
}

sub CheckShowCaseNumber
{
	my($DT,$sc)=@_;
	
	$sc+=0;
	OutError('�׷� �������� �����ϴ�') if $sc<0 || $DT->{showcasecount}<=$sc;

	return $sc;
}

sub GetTopCountImage
{
	my($count)=@_;
	
	return $count."ȸ ���" if $MOBILE;
	
	my $ret="";
	my $num=1;
	foreach my $cnt (1,3,6,10,20)
	{
		my $fn=$IMAGE_URL."/rank".$num.$IMAGE_EXT;
		#$ret.="<IMG BORDER=\"0\" SRC=\"".$fn."\" HEIGHT=\"16\" WIDTH=\"16\">" if $count>=$cnt;
		$ret.="<IMG class=\"i\" SRC=\"$fn\" ALT=\"$cntȸ ���\">" if $count>=$cnt;
		$num++;
	}
	return $ret;
}

sub GetMoneyMessage
{
	my($money)=@_;
	
	$money=int(($money+9999)/10000);
	foreach my $rank (10,20,50,100,500,1000,5000,10000,50000,100000)
	{
		return $rank."<FONT SIZE=\"-3\">���� ����</FONT>" if $money<=$rank;
	}
}

sub GetTaxToday
{
	my($DT)=@_;
	
	my $tax=$DT->{moneystock}-1000000;
	my $taxrate=0;
	
	$tax=0 if $tax<0;
	if($tax)
	{
		$taxrate=10+int($tax/1000000);
		$taxrate=80 if $taxrate>80;
		$tax=int($tax*$taxrate/100);
	}
	return ($tax,$taxrate);
	
	#my $tax=$DT->{saleyesterday}-$DT->{paytoday}-100000;
	#my $taxrate=0;
	#$tax=0 if $tax<0;
	#if($tax)
	#{
	#	$taxrate=50+int($tax/58000);
	#	$taxrate=80 if $taxrate>80;
	#	$tax=int($tax*$taxrate/100);
	#}
	#return ($tax,$taxrate);
}

1;
