#! /usr/bin/perl
# $Id: item-use.cgi,v 1.12 2002/06/23 07:19:59 mu Exp $

$NOMENU=1;
require './_base.cgi';
GetQuery();

$Q{cnt}=int($Q{cnt2} ? $Q{cnt2} : $Q{cnt1});
$Q{cnt}=0 if $Q{cnt}<=0;

Lock() if $Q{cnt} || $Q{tg}ne'';
DataRead();
CheckUserPass();

$itemno=$Q{item};
$no=$Q{no};
$target=$Q{tg};
$message=$Q{msg};
CheckItemNo($itemno);
OutError('ǥ���� �߰ߵ��� �ʽ��ϴ�.') if $target && !defined($id2idx{$target});

$itemcode=GetPath($ITEM_DIR,"use",$ITEM[$itemno]->{code});
OutError('����� �� �����ϴ�.') if $itemcode eq '' || !(-e $itemcode);

$ITEM=$ITEM[$itemno];
@item::DT=@DT;
$item::DT=$DT;
@item::ITEM=@ITEM;
$item::ITEM=$ITEM;
RequireFile('inc-item.cgi');
require $itemcode;
#require "$ITEM_DIR/funcuse.cgi" if $DEFINE_FUNCUSE;
#require(GetPath($ITEM_DIR,"use-s",$ITEM->{code})) if $DEFINE_FUNCUSE_SUB;
#@USE=@item::USE;
#$func=$ITEM->{func};
#&$func($ITEM->{param}) if $func;

$USE=GetUseItem($no,GetUseItemList());
OutError('����� �� �����ϴ�.') if !$USE || !$USE->{useok};

if($Q{cnt} || $Q{tg}ne'')
{
	if($USE->{arg}=~/message(\d*)/)
	{
		my $limit=$1||80;
		require $JCODE_FILE;
		$message=EscapeHTML(jcode::sjis($message));
		OutError('�Է��� ���ڼ��� �ʹ� �����ϴ�. (<>&"�� 4~6���ڷ� ȯ��˴ϴ�.)') if length $message>$limit;
	}
	$USE->{arg}={};
	$USE->{arg}->{target}=$target;
	$USE->{arg}->{targetidx}=$id2idx{$target};
	$USE->{arg}->{count}=$Q{cnt};
	$USE->{arg}->{message}=$message;
	UseItem($USE,$Q{cnt});
	DataWrite();
	DataCommitOrAbort();
	UnLock();
	RequireFile('inc-html-item-use.cgi');
}
else
{
	RequireFile('inc-html-item-usemode.cgi');
}
OutHTML('â��',$disp);

