# $Id: inc-html-moneystock.cgi 18 2004-02-28 12:49:53Z mu $

RequireFile('inc-html-ownerinfo.cgi');

$disp.="���Ա�ó��<HR>";

if($Q{conf}ne'' && $errormsg eq '' && $money>0 && $money<=$DT->{moneystock})
{
	$disp.="����� \\".$money."<br>�Һ� �ð���".GetTime2HMS(GetTimeDeal($money))."<br>";
	$disp.=<<"HTML";
	<FORM ACTION="moneystock.cgi" $METHOD>
	$USERPASSFORM
	<INPUT TYPE=HIDDEN NAME=money VALUE="$money">
	<INPUT TYPE=SUBMIT NAME=ok VALUE="����">
	<INPUT TYPE=SUBMIT VALUE="���">
	</FORM>
HTML
}
else
{
	my $maxmoney=$DT->{moneystock};
	my $usetime=GetTimeDeal($maxmoney)-$TIME_SEND_MONEY;
	my $stocktime=GetStockTime($DT->{time})-$TIME_SEND_MONEY;
	$maxmoney=0 if $stocktime<0;
	$maxmoney=int($maxmoney/$usetime*$stocktime) if $usetime>0 && $stocktime>0 && $stocktime<$usetime;

	$disp.=<<"HTML";
	<FORM ACTION="moneystock.cgi" $METHOD>
	$USERPASSFORM$errormsg
	������ �ݾ�
	<INPUT TYPE=TEXT NAME=money SIZE=10 VALUE="$money">
	<INPUT TYPE=HIDDEN NAME=conf VALUE="conf">
	<INPUT TYPE=SUBMIT VALUE="�ݾ� ����">
	</FORM>
	<FORM ACTION="moneystock.cgi" $METHOD>
	$USERPASSFORM
	<INPUT TYPE=HIDDEN NAME=money VALUE="$maxmoney">
	<INPUT TYPE=HIDDEN NAME=conf VALUE="conf">
	<INPUT TYPE=SUBMIT VALUE="�������� �ִ��">
	</FORM>
HTML
	$disp.="(�Һ� �ð�:�⺻ " .GetTime2HMS($TIME_SEND_MONEY)." + \\$TIME_SEND_MONEY_PLUS�� ".GetTime2HMS($TIME_SEND_MONEY)." �߰�)";
}
1;
