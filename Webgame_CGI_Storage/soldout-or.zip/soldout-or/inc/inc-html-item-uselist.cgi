# $Id: inc-html-item-uselist.cgi,v 1.4 2001/12/31 13:00:59 mu Exp $

RequireFile('inc-html-ownerinfo.cgi');

foreach my $USE (@USE)
{
	$disp.="��";
	$disp.=qq|<a href="item-use.cgi?item=$itemno&no=$USE->{no}&$USERPASSURL&bk=$Q{bk}">| if $USE->{useok};
	$disp.=($USE->{useok} || $USE->{dispok}) ? $USE->{name} : "����������������";
	$disp.="</a>" if $USE->{useok};
	$disp.="<br>";
}
1;
