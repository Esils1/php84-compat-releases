# $Id: inc-html-guild.cgi 18 2004-02-28 12:49:53Z mu $

my ($page,$pagestart,$pageend,$pagenext,$pageprev,$pagemax)
	=GetPage($Q{pg},$LIST_PAGE_ROWS,scalar(@guildlist));

$disp.="�ܱ��<HR>";

my $pagecontrol=GetPageControl($pageprev,$pagenext,"","",$pagemax,$page);
$disp.=$pagecontrol."<BR>";

my $rank=$pagestart+1;

$disp.=$TB;
foreach my $guild (@guildlist[$pagestart..$pageend])
{
	my $code    =$guild->{guild};
	my $name    =$GUILD{$code}->[$GUILDIDX_name];
	my $dealrate=$GUILD{$code}->[$GUILDIDX_dealrate];
	my $feerate =$GUILD{$code}->[$GUILDIDX_feerate];
	my $url     =$GUILD_DETAIL{$code}->{url};
	my $comment =$GUILD_DETAIL{$code}->{comment};
	
	$disp.=$TR;
	$disp.=$TD.$rank++."��&nbsp;";
	$disp.=$TD.qq|<a target="_blank" href="jump.cgi?guild=$code">|.GetTagImgGuild($code).$name."</a>";
	$disp.=$TD."��� �ڵ� $code";
	$disp.=$TD."ȸ�� ".($guildcount{$code}+0)."��";
	$disp.=$TD."�ڱ� \\".($guild->{money}+0);
	$disp.=    "(����)" if $guild->{money}<0;
	$disp.=$TD."���� \\".($guild->{in}+0);
	$disp.=$TD."���� \\".($guild->{out}+0);
	$disp.=$TD."������ ".($dealrate/10)."%";
	$disp.=$TD."ȸ���� ".($feerate/10)."%";
	$disp.=$TD.$comment;
	$disp.=$TRE;
}
$disp.=$TBE;

$disp.=$pagecontrol;
1;
