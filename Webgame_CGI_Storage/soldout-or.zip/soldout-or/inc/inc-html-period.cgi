# $Id: inc-html-period.cgi,v 1.3 2001/12/31 13:00:58 mu Exp $

$disp.="<br><br>����ȸ�� ���<HR>";

open(IN,GetPath($PERIOD_FILE));
my @log=<IN>;
close(IN);

foreach(@log)
{
	my($tm,$mode,$id,$to,$message,$no)=split(/,/);
	next if $id;
	
	$disp.=$message.("<br>","<hr>")[$MOBILE];
}
1;
