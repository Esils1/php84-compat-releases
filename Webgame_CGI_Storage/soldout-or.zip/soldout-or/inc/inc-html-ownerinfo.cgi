# $Id: inc-html-ownerinfo.cgi,v 1.3 2001/12/31 13:00:58 mu Exp $

if(!$GUEST_USER)
{
	my $tm=$NOW_TIME-$DT->{time};
	if($tm<0)
	{
		$tm=-$tm;
		$tm='�ൿ���ɱ��� '.GetTime2HMS($tm);
	}
	else
	{
		$tm=$MAX_STOCK_TIME if $tm>$MAX_STOCK_TIME;
		$tm=GetTime2HMS($tm);
	}
	my $rankmsg=GetRankMessage($DT->{rank});
	
	$disp.=<<STR;
	�ܰ��� ����<BR>
	$TB$TR
	$TD
	RANK ${\($id2idx{$DT->{id}}+1)}$TDE
	$TD����:$DT->{shopname}$TDE
	$TD�ڱ�:\\$DT->{money}$TDE
	$TD�Աݾ�:\\$DT->{moneystock}$TDE
	$TD�ð�:$tm$TDE
	$TRE$TBE
	<HR SIZE=1>
STR
}
1;
