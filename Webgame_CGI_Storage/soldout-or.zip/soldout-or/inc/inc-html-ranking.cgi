# $Id: inc-html-ranking.cgi,v 1.5 2002/03/03 14:07:15 mu Exp $

my ($page,$pagestart,$pageend,$pagenext,$pageprev,$pagemax)
	=GetPage($Q{pg},($MYNAME eq 'index.cgi' ?$TOP_RANKING_PAGE_ROWS:$RANKING_PAGE_ROWS),$DTusercount);

$disp.="�ܻ����� ����<HR>";
$disp.="�α�:".int($DTpeople/10)."<BR>";

my $pagecontrol=GetPageControl($pageprev,$pagenext,"","",$pagemax,$page);
$disp.=$pagecontrol."<BR>";

$disp.=$TB;

if(!$MOBILE)
{
	$disp.=$TR;
	$disp.=$TDNW."����<BR><SMALL>(�� ȸ��)</SMALL><br>����";
	$disp.=$TDNW."����<BR>�α�";
	$disp.=$TDNW."�ݱ�Ż�";
	$disp.=$TDNW."�ڱ�<BR>����Ż�";
	$disp.=$TDNW."����<BR>������<BR>����";
	$disp.=$TD."��޻�ǰ�϶�<BR>������ �����衽��â���� �ڸ�Ʈ";
	$disp.=$TRE;
}
else
{
	$tdh_rk="RANK:";
	$tdh_pt="����:";
	$tdh_nm="����:";
	$tdh_pp="�α�:";
	$tdh_mo="�ڱ�:";
	$tdh_ts="����:";
	$tdh_ys="�۸�:";
	$tdh_cs="����:";
	$tdh_sc="�Ͼ�:";
	$tdh_cm="�Ͼ�:";
	$tdh_tx="�ۼ�:";
	$tdh_ex="����:";
	$tdh_fd="â��:";
}

foreach my $idx ($pagestart..$pageend)
{
	my $DT=$DT[$idx];
	
	my $rankupdown="";
	if($DT->{rankingyesterday})
	{
		$rankupdown=$DT->{rankingyesterday}-$idx-1;
		$rankupdown=$rankupdown==0 ? "��": $rankupdown<0 ? "��".(-$rankupdown) : "��".$rankupdown;
		$rankupdown="<small>($rankupdown)</small>";
	}
	my $itemtype=-1;
	my $itempro="";
	my $salelist="";
	foreach my $no (@{$DT->{showcase}})
	{
		$salelist.=GetTagImgItemType($no);
		$itemtype=0,next if $itemtype!=-1 && $ITEM[$no]->{type}!=$itemtype;
		$itemtype=$ITEM[$no]->{type};
	}
	$itempro=GetTagImgItemType(0,$itemtype,1)." " if $itemtype;
	my $itemno=$DT->{showcase}[0];
	$salelist.=" ".$ITEM[$itemno]->{name}." \\".$DT->{price}[0] if $itemno;
	
	my $expsum=0;
	foreach(values(%{$DT->{exp}})){$expsum+=$_;}
	$expsum="��".int($expsum/10)."%��";
	
	my $job=$JOBTYPE{$DT->{job}};
	$job="��$job��" if $job;
	
	$disp.=$TR;
	$disp.=$TDNW.$tdh_rk."<b>".($idx+1)."</b>".$rankupdown."<br>";
	$disp.=    $tdh_pt.$DT->{point};
	$disp.=$TD.$tdh_nm;
	$disp.=    "<a href=\"shop.cgi?ds=$DT->{id}&$USERPASSURL\">" if !$GUEST_USER;
	$disp.=    GetTagImgGuild($DT->{guild}).$itempro.$job.$DT->{shopname}."[".$DT->{name}."]";
	$disp.=    "</a>" if !$GUEST_USER;
	$disp.=GetTopCountImage($DT->{rankingcount}+0) if $DT->{rankingcount};
	$disp.="<BR>";
	$disp.=    $tdh_pp.GetRankMessage($DT->{rank});
	$disp.=$TDNW.$tdh_ts."\\".$DT->{saletoday};
	$disp.=$TDNW.$tdh_mo.GetMoneyMessage($DT->{money})."<BR>";
	$disp.=    $tdh_ys."\\".$DT->{saleyesterday};
	$disp.=$TDNW.$tdh_cs."\\".($DT->{costyesterday}+0)."<br>";
	$disp.=    $tdh_tx."\\".($DT->{taxyesterday}+0);
	
	$disp.=$TD;
	
	$disp.=$tdh_sc.$salelist;
	
	$disp.="<BR>";
	
	$disp.=$tdh_ex.$expsum;
	$disp.=$tdh_fd."��".GetTime2HMS($NOW_TIME-$DT->{foundation})."��";
	$disp.=$tdh_cm.$DT->{comment} if $DT->{comment};
	$disp.=$TRE;
}
$disp.=$TBE;

$disp.=$pagecontrol;
1;
