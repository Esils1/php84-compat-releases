# $Id: inc-html-chat.cgi,v 1.4 2002/07/05 14:28:56 mu Exp $

my $linemax=$MOBILE?10:$MAX_CHAT_MESSAGE;

my %printed=();

$disp.="��$CHAT_TITLE(CHAT��)<HR>";

if(!$GUEST_USER)
{
	$disp.=<<"STR";
	$CHAT_INFO
	<FORM ACTION="$MYNAME" $METHOD>
	$USERPASSFORM
	$errormsg
	<INPUT TYPE=TEXT NAME=msg SIZE=50 VALUE="$Q{msg}">
	<INPUT TYPE=SUBMIT VALUE="����">
	</FORM><HR>
STR
}
else
{
	$disp.="������ �ܴ̿� ������ �����մϴ�.<HR>";
}

$disp.=$TB if !$MOBILE;
foreach(@MESSAGE)
{
	chop;
	my($tm,$mode,$id,$to,$msg,$no)=split(/,/);
	my($message,$sname,$name)=split(/\t/,$msg);
	
	$tm=GetTime2FormatTime($tm);
	if(!$to)
	{
		$sname="<B>������</B>";
		$name ="";
	}
	else
	{
		if(defined($id2idx{$to}))
		{
			my $DT=$DT[$id2idx{$to}];
			$sname=GetTagImgGuild($DT->{guild}).$DT->{shopname};
			$name =$DT->{name};
			$sname="<a href=\"shop.cgi?ds=$to&$USERPASSURL\">".$sname."</a>" if !$printed{$to}++ && !$GUEST_USER;
		}
		else
		{
			$sname="<SMALL>closed</SMALL> ".$sname;
		}
	}
	
	if($MOBILE)
	{
		$disp.=$tm."<BR>".$no.":".$sname.":".$name."<BR>".$message;
		$disp.="<HR SIZE=1>";
	}
	else
	{
		$disp.=$TR.$TD.$tm.$TD.$sname.$TD.$name.$TD.$no.$TD.$message.$TRE;
	}
}
$disp.=$TBE if !$MOBILE;

1;
