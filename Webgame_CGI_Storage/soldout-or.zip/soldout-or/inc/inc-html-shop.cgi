# $Id: inc-html-shop.cgi,v 1.4 2002/03/01 15:32:33 mu Exp $

RequireFile('inc-html-ownerinfo.cgi');

my($page,$pagestart,$pageend,$pagenext,$pageprev,$pagemax);

if($Q{ds}!=0)
{
	my($id,$idx)=CheckUserID($Q{ds});
	($page,$pagestart,$pageend,$pagenext,$pageprev,$pagemax)=
		(0,$idx,$idx,0,0,0)
}
else
{
	($page,$pagestart,$pageend,$pagenext,$pageprev,$pagemax)=
		GetPage($Q{pg},$SHOP_PAGE_ROWS,$DTusercount);
}

$disp.="�ܴٸ� ����";
$disp.="<HR SIZE=\"1\">";

my $pagecontrol=GetPageControl($pageprev,$pagenext,"","",$pagemax,$page);
$disp.=$pagecontrol."<HR SIZE=\"1\">" if $pagecontrol ne '';

foreach my $cnt ($pagestart .. $pageend)
{
	my $DT=$DT[$cnt];
	next if !$DT->{status};
	
	$disp.="RANK ".($cnt+1)." ";
	$disp.="<BR>" if $MOBILE;
	$disp.=GetTagImgGuild($DT->{guild})." ".$DT->{shopname}."<BR>";
	$disp.="�Ѹ���$DT->{comment}<BR>" if $DT->{comment};
	
	$disp.=$TB;
	foreach my $idx (0..$DT->{showcasecount}-1)
	{
		my $itemno=$DT->{showcase}[$idx];
		if($itemno)
		{
			my $ITEM=$ITEM[$itemno];
			$stock=$DT->{item}[$itemno-1];
			$disp.=$TR.$TD;
			$disp.="<A HREF=\"buy.cgi?buy=$DT->{id}!$idx!$itemno&bk=p!$page&$USERPASSURL\">" if $stock && !$GUEST_USER;
			$disp.=GetTagImgItemType($itemno).$ITEM->{name};
			$disp.="</A>" if $stock && !$GUEST_USER;
			$disp.=$TD."\@\\".$DT->{price}[$idx];
			my $msg=$stock ? "�ܿ�".$stock.$ITEM->{scale} : "SOLD OUT";
			$disp.=$TD.$msg;
			$disp.=$TD.($DT->{itemtoday}{$itemno}+0).$ITEM->{scale}."�Ż�";
			$disp.=$TRE;
		}
	}
	$disp.=$TBE;
	$disp.="<HR SIZE=1>";
}

$disp.=$pagecontrol;

1;
