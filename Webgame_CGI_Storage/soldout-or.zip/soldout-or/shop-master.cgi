#! /usr/bin/perl
# $Id: shop-master.cgi,v 1.3 2001/12/31 12:59:28 mu Exp $

require './_base.cgi';
GetQuery();

DataRead();
$DT={};
CheckUserPass(1);

RequireFile('inc-html-shop-master.cgi');

OutHTML('����',$disp);

exit;
