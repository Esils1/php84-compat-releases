#! /usr/bin/perl
# $Id: ranking.cgi,v 1.3 2001/12/31 12:59:28 mu Exp $

require './_base.cgi';

GetQuery();

DataRead();
CheckUserPass(1);

RequireFile('inc-html-ranking.cgi');

OutHTML('��ŷ',$disp);
exit;
