#! /usr/bin/perl
# $Id: custom.cgi,v 1.3 2002/07/17 08:47:18 mu Exp $

require './_base.cgi';
Deny() if !$USE_CUSTOM || !$DEFINE_FUNCCUSTOM;

GetQuery();

DataRead();
CheckUserPass(1);
Deny() if $GUEST_USER && $DENY_GUEST_CUSTOM;

require "$ITEM_DIR/funccustom.cgi";

my $cmd=lc($Q{cmd}||'');
$cmd=~s/[^a-z_]//g;

my $result=1;
$result=CustomPageInit($cmd) if defined(&CustomPageInit);
Deny() if !$result;
$cmd=$result if $result!~/[^a-z_]/;

foreach(1..10) # �ő�10��?�v
{
	$result=1;
	$result=&{"CustomPage_$cmd"}() if defined(&{"CustomPage_$cmd"});
	Deny() if !$result;
	last if $result=~/[^a-z_]/;
	$cmd=$result;
}

Deny() if !$disp;

OutHTML($CUSTOM_TITLE,$disp);
exit;

sub Deny{OutError('����� �� �����ϴ�.')}
