#! /usr/bin/perl
# $Id: stock.cgi,v 1.3 2001/12/31 12:59:27 mu Exp $

require './_base.cgi';
GetQuery();

DataRead();
CheckUserPass();

RequireFile('inc-html-stock.cgi');

OutHTML('â��',$disp);
