#! /usr/bin/perl
# $Id: guild.cgi,v 1.3 2001/12/31 12:59:31 mu Exp $

$NOITEM=1;
require './_base.cgi';

GetQuery();
DataRead();
CheckUserPass(1);

ReadGuild();
ReadGuildData();
undef %guildcount;
foreach(@DT)
{
	$guildcount{$_->{guild}}++;
}
@guildlist=sort{$b->{money}<=>$a->{money}}map{$GUILD_DATA{$_}->{guild}=$_;$GUILD_DATA{$_}}keys(%GUILD);

RequireFile('inc-html-guild.cgi');

OutHTML('���',$disp);
exit;
