#! /usr/bin/perl
# $Id: showcase.cgi,v 1.3 2001/12/31 12:59:28 mu Exp $

require './_base.cgi';
GetQuery();

DataRead();
CheckUserPass();

RequireFile('inc-html-ownerinfo.cgi');

RequireFile('inc-html-showcase.cgi');

OutHTML('������',$disp);
