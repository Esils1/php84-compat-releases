#! /usr/bin/perl
# $Id: other.cgi,v 1.3 2001/12/31 12:59:29 mu Exp $

require './_base.cgi';
GetQuery();

DataRead();
CheckUserPass();

RequireFile('inc-html-other.cgi');

OutHTML('���� ����',$disp);

exit;