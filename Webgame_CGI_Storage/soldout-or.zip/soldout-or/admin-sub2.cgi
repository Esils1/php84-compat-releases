#! /usr/bin/perl
# $Id: admin-sub2.cgi,v 1.11 2002/07/17 13:56:33 mu Exp $

require './_base.cgi';
GetQuery();
CheckUserPass();

OutError("") if !$MASTER_USER;

$NOMENU=1;
$Q{bk}="none";
if($Q{targz})
{
	my $filename="backup.tar.gz";
	
	Lock();
	my $body=`tar pcvzf - $DATA_DIR/*$FILE_EXT $SUBDATA_DIR`;
	UnLock();
	
	print "Content-type: application/download\n";
	print "Content-disposition: filename=\"$filename\"\n";
	print "Content-Length: ",(length $body),"\n";
	print "\n";
	print $body;
}
elsif($Q{usercheck})
{
	my $filename="usercheck.tar.gz";
	
	my $body=`tar pcvzf - $SESSION_DIR/*$FILE_EXT $DATA_DIR/$DATA_FILE$FILE_EXT $DATA_DIR/$IP_FILE$FILE_EXT`;
	
	print "Content-type: application/download\n";
	print "Content-disposition: filename=\"$filename\"\n";
	print "Content-Length: ",(length $body),"\n";
	print "\n";
	print $body;
}
elsif($Q{log})
{
	GetLog();
	OutHTML('���� �α�',$disp);
}
elsif($Q{towndata})
{
	GetTownData();
	OutHTML('�Ÿ� ������ �϶�($DTtown)',$disp);
}
else
{
	GetMember();
	OutHTML('��� ����Ʈ',$disp);
}

exit;

sub GetFileList
{
	my($dir,$file)=@_;
	opendir(DIR,$dir);
	my @list=map{$dir."/".$_}sort grep(/$file/ && !/^\.\.?$/,readdir(DIR));
	closedir(DIR);

	return @list;
}

sub GetLog
{
	$disp.=GetTagA("[loglist]","$MYNAME?log=.&$USERPASSURL")." ";
	foreach(GetFileList($LOG_DIR,"\\$FILE_EXT\$"))
	{
		/([\w\-]+)$FILE_EXT$/;
		$disp.=GetTagA("[$1 ".GetTime2FormatTime((stat($_))[9]+0,1)."]","$MYNAME?log=$1&$USERPASSURL")." ";
	}

	if($Q{log}eq'.')
	{
		$disp.="<hr>��� �ǿ��� �����ϰ� ���� �α׸� ������ �ּ���.<br>";
		$disp.="[$LOG_DELETESHOP_FILE] ����/���� �� ������ �α�<br>";
		$disp.="[$LOG_ERROR_FILE] ���� ������ �α�<br>";
		$disp.="[$LOG_LOGIN_FILE] �α��� ������ �α�<br>";
		$disp.="[$LOG_MOVESHOP_FILE] ���� ������ �α�<br>";
		$disp.="[$LOG_TRADE_FILE] ���� �������� �α�<br>";
		$disp.="[$LOG_DEBUG_FILE] ����� �α�<br>";
		$disp.="[$LOG_GLOBAL_MSG_FILE] ���� �Խ��� �α�<br>";
		$disp.="<hr>���ٿ�, ǥ�õ� ���뿡�� �н����尡 ���ԵǴ� ���ɼ��� �ֱ� ������, ������ �ּ���.";
	}
	else
	{
		open(IN,GetPath($LOG_DIR,$Q{log})) or OutError('�������� �ʽ��ϴ�. '.$Q{log});
		my @data=reverse(<IN>);
		close(IN);

		my($page,$pagestart,$pageend,$pagenext,$pageprev,$pagemax)
			=GetPage($Q{pg},30,scalar(@data));
		my $pagecontrol=GetPageControl($pageprev,$pagenext,"&log=$Q{log}","pg",$pagemax,$page);

		$disp.="<hr>$Q{log}<br>".$pagecontrol;
		$disp.="<table width=\"100%\">";
		$disp.="<tr><th>time<th>user<th>message<th>script<th>remoteaddr<th>remotehost<th>trueip</tr>";
		my $buf="";
		foreach(@data[$pagestart..$pageend])
		{
			chop;
			if(/^\d+\t/)
			{
				/^(\d+)\t.*\/(.+\.cgi)\t(.*?)\t(.*?)\t(.*?)\t(.*?)\t(.*)$/;
				my $msg=$7;
				if(index($msg,"\t")!=-1)
				{
					$msg=~s/\t/<BR>/g;
				}
				$disp.="<tr><td>".GetTime2FormatTime($1)."<td>$6<td>$msg<td>$2<td>$3<td>$4<td>$5</tr>";
				$disp.="<tr><td colspan=\"20\"><small>$buf</small></tr>" if $buf ne '';
				$buf="";
			}
			else
			{
				$buf="$_<br>$buf";
			}
		}
		$disp.="</table>";
		$disp.="<hr>".$pagecontrol;
	}
}

sub GetMember
{
	DataRead();
	if(open(IN,GetPath($IP_FILE)))
	{
		while(<IN>)
		{
			chop;
			@_=split(/\t/);
			my $DT=$DT[$name2idx{$_[0]}];
			#$disp.=$_[2];
			$DT->{remoteaddr}=$_[2];
			$DT->{last}=$_[1];
			$DT->{ua}=$_[3];
		}
		close(IN);
	}

	$disp.=$TB;
	$disp.=$TR;
	foreach(qw(IP No ID �̸� ������ â�� ����login �ڱ� �ݰ� �ൿtime �α� �Ż� ���� ��� �ؼ� ���� IP�ߺ��㰡))
	{
		$disp.=$TD.$_;
	}
	$disp.=$TRE;
	$cnt=1;

	foreach my $DT (@DT)
	{
		$count{$DT->{remoteaddr}}++ if $DT->{remoteaddr};
		open(SESS,"$SESSION_DIR/$DT->{name}.cgi");
		$DT->{clientinfo}=[<SESS>];
		close(SESS);
		shift(@{$DT->{clientinfo}});

		undef %sameAcount;
		undef %sameBcount;
		undef %sameCcount;
		undef %sameDcount;
		%samecount=();
		foreach(@{$DT->{clientinfo}})
		{
			chop;
			last if $_ eq "";
			my($date,$ip,$agent,$referer,$accept)=split(/\t/);
			$sameA{"$ip\t$agent\t$referer\t$accept"}++ if !($samecount{"$ip\t$agent\t$referer\t$accept"}++);
			$sameB{"$ip\t$agent\t$accept"}++           if !($samecount{"$ip\t$agent\t$accept"}++);
			$sameC{"$ip\t$agent"}++                    if !($samecount{"$ip\t$agent"}++);
			$sameD{"$ip"}++                            if !($samecount{"$ip"}++);
		}
	}

	foreach my $DT (@DT)
	{
		$disp.=$TR;

		$disp.=$TD.$DT->{remoteaddr};
		if($Q{host}ne'')
		{
			foreach(split(/!/,$DT->{remoteaddr}))
			{
				$disp.="[".gethostbyaddr(pack("C4",split(/\./)),2)."]";
			}
		}
		$disp.=$TD.$cnt++;
		$disp.=$TD.$DT->{id};
		$disp.=$TD.$DT->{name};
		$disp.=$TD.qq|<a href="#$DT->{id}">$DT->{shopname}</a>|;
		$disp.=$TD.GetTime2FormatTime($DT->{foundation});
		#$disp.=$TD.GetTime2FormatTime($DT->{lastlogin});
		$disp.=$TD.$DT->{last};
		$disp.=$TD.$DT->{money};
		$disp.=$TD.$DT->{moneystock};
		$disp.=$TD.GetTime2FormatTime($DT->{time});
		$disp.=$TD.$DT->{rank};
		$disp.=$TD.$DT->{saletoday};
		$disp.=$TD.$DT->{paytoday};
		$disp.=$TD.$DT->{profitstock};
		$disp.=$TD.$DT->{showcasecount};
		$disp.=$TD.$DT->{blocklogin};
		$disp.=$TD.($DT->{nocheckip} ? '�ߺ� �㰡':'');
		#$disp.=$TD.$DT->{comment};
		$disp.=$TRE;

		#my $warning=$DT->{ua}."<br>";
		my $warning="";
		undef %sameAcount;
		undef %sameBcount;
		undef %sameCcount;
		undef %sameDcount;
		%samecount=();
		foreach(@{$DT->{clientinfo}})
		{
			chop;
			last if $_ eq "";
			my($date,$ip,$agent,$referer,$accept)=split(/\t/);
			if($sameA{"$ip\t$agent\t$referer\t$accept"}>1 && !$samecount{"$ip\t$agent\t$referer\t$accept"})
			{
				$warning.="��IP[$ip]&AGENT&ACCEPT&REFERER�ߺ� ";
			}
			elsif($sameB{"$ip\t$agent\t$accept"}>1 && !$samecount{"$ip\t$agent\t$accept"})
			{
				$warning.="��IP[$ip]&AGENT&ACCEPT�ߺ� ";
			}
			elsif($sameC{"$ip\t$agent"}>1 && !$samecount{"$ip\t$agent"})
			{
				$warning.="��IP[$ip]&AGENT�ߺ� ";
			}
			elsif($sameD{"$ip"}>1 && !$samecount{"$ip"})
			{
				$warning.="��IP[$ip]�ߺ� ";
			}
			$samecount{"$ip\t$agent\t$referer\t$accept"}++;
			$samecount{"$ip\t$agent\t$accept"}++;
			$samecount{"$ip\t$agent"}++;
			$samecount{"$ip"}++;
		}
		if($count{$DT->{remoteaddr}}>1)
		{
			$warning.="��TRUE IP[$DT->{remoteaddr}]�ߺ� ";
		}

		if($warning ne '')
		{
			#$list=~s/\t/<br>/g;
			$disp.=$TR."<td colspan=\"20\"><a href=\"#$DT->{id}\">��".$warning."</a>";
			$disp.="".$TRE;
		}
		my $list=join("<br>",grep($_ ne "\n",@{$DT->{clientinfo}}));
		$detail.="<pre><hr><a name=\"$DT->{id}\">��$DT->{shopname} $DT->{name}<hr>$list</pre>";
	}
	$disp.=$TBE;

	$disp.=$detail;
}

sub GetTownData
{
	DataRead();
	
	$disp.="�Ÿ� ������ �϶�<hr>\n";
	$disp.="<dl>\n";
	while(my($key,$val)=each %$DTtown)
	{
		$key=~s/%([\dA-Fa-f]{2})/pack("H2",$1)/eg;
		$val=~s/%([\dA-Fa-f]{2})/pack("H2",$1)/eg;
		$disp.=join "","<dt>",EscapeHTML($key)," </dt>","<dd>",EscapeHTML($val)," </dd>","\n";
	}
	$disp.="</dl>\n";
}
