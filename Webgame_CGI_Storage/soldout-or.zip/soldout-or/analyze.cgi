#! /usr/bin/perl
# $Id: analyze.cgi,v 1.3 2001/12/31 12:59:33 mu Exp $

require './_base.cgi';
GetQuery();

DataRead();
CheckUserPass(1);

RequireFile('inc-html-analyze.cgi');

OutHTML('���� �м�',$disp);
