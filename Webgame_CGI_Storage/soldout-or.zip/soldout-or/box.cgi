#! /usr/bin/perl
# $Id: box.cgi,v 1.3 2001/12/31 12:59:32 mu Exp $

require './_base.cgi';
GetQuery();

DataRead();
CheckUserPass();

ReadBox();

GetInBox();
GetOutBox();
GetRetBox();
RequireFile('inc-html-box.cgi');

OutHTML('��ü��',$disp);
exit;
