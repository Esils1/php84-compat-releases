#! /usr/bin/perl
# $Id: commentlist.cgi,v 1.3 2001/12/31 12:59:32 mu Exp $

require './_base.cgi';

GetQuery();

DataRead();
CheckUserPass(1);

RequireFile('inc-html-commentlist.cgi');

OutHTML('�ڸ�Ʈ�϶� ',$disp);
exit;
