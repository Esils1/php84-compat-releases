#! /usr/bin/perl
# $Id: log.cgi,v 1.3 2001/12/31 12:59:30 mu Exp $

$NOITEM=1;
require './_base.cgi';
GetQuery();

DataRead();
CheckUserPass(1);

ReadLog($DT->{id},$Q{lmd}+0,$Q{key},$Q{tgt});
RequireFile('inc-html-log.cgi');

OutHTML('�ֱ��� ���',$disp);
