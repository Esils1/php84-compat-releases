#! /usr/bin/perl
# $Id: shop.cgi,v 1.3 2001/12/31 12:59:28 mu Exp $

require './_base.cgi';
GetQuery();

DataRead();
CheckUserPass(1);

RequireFile('inc-html-shop.cgi') if $Q{t}!=2;
RequireFile('inc-html-shop-2.cgi') if $Q{t}==2;

OutHTML(($Q{t}!=2?'�ٸ�����':'�ü�'),$disp);

exit;
