#! /usr/bin/perl
# $Id: counter.cgi,v 1.3 2001/12/31 12:59:31 mu Exp $

require './_base.cgi';
GetQuery();
DataRead();
CheckUserPass();

OutError("") if !$MASTER_USER;

my $lsize=-s GetPath($COUNTER_FILE."-l");
my $hsize=-s GetPath($COUNTER_FILE."-h");

$disp.=$hsize*1000+$lsize;

$Q{bk}="none",$NOMENU=1;
OutHTML('ī����',$disp);
1;
