#!/usr/bin/perl

#----------------------------------------------------------------------
#	 VirtualBoss online ver 2.10 (Free)
#	 AUTHOR	: ������ ����
#	 URL	: http://www.abi-station.com/
#	 ����������/��Ʋ �ο� ver 1.10 (Free)
#	 AUTHOR	: Alpha-kou.
#	 URL	: http://www.grn.mmtr.or.jp/~dabo/
#
#          �ѱ۹��� : jjangg96@hanmail.net
#          �ѱ۹��� : http://www.x2-dr.com
#
#	�� ��ũ��Ʈ�� �����Դϴٸ�, ��� �̿��� ����, �� ������� �������� �����Ƿ� ������ �ֽʽÿ�.
#	��ũ��Ʈ�� ���� ������ ������ �� ������ ��Ź�մϴ�. (�߸��ص� Alpha-kou���� ���� �ʰ�^^;)
#	�� ��ũ��Ʈ�� ����� �Ͼ�� �����ΰ� �Ǵ� ���ؿ��� å���� ���� �ʽ��ϴ�.
#	�� ��ũ��Ʈ�� ������ �̿� ������ ���� �����ǰ� �ֽ��ϴ�.
#	http://dabo.pobox.ne.jp/cgiroom/kitei.html
#
#	�������� �����ϴٸ�, �۹̼��� ���ϰ� �˴ϴ�.
#	vbonline.cgi(755)
#	Ȯ����(extension)��. dat�� ��(666)
#----------------------------------------------------------------------

$| = 1;
require './jcode.pl';
require './custom.cgi';

$viewbr = "Win InternetExplorer6, Win Mozilla<br>Mac InternetExplorer5";
$ver = "ver2. 10";

&kankyou;

if($filelockuse ==1){&lock;}
&blbase;

&decode;
&readlog;

# ���̸� �Դ� ó��
if((int($hour/$oldtime) ne $times[0])&&($lines[3])){&oldplus;}

# �����ī��Ʈ
open(DB,"$logfile") ;close(DB) ;$syainsu = $#lines +1;
if($#lines < 3){
	$kaisaiinfo = "<br>����� 4�� ������ ���� ���� �ð��� ������� �ʽ��ϴ�<br>";
}elsif($#lines+1 >= $max_chara){
	$kaisaiinfo = "<br>�� �̻� �Ի��� �� �����ϴ�<br>";
}else{
	$kaisaiinfo="";
}

# ���� ó��
if((int($timemin/$kaigi) ne $times2)&&($lines[3])){&syori;}

# ��� ó��
if($form{'del2'}){&del2;&html;if($filelockuse ==1){if (-e, $lockfile){unlink($lockfile);}}exit;}
if($form{'record'}) {&record;&rec;if($filelockuse ==1){if (-e, $lockfile){unlink($lockfile);}}exit;}
if($form{'mode'} eq "ssi"){&ssi;if($filelockuse ==1){if (-e, $lockfile){unlink($lockfile);}}exit;}
if($form{'mode'}){&imagevw;if($filelockuse ==1){if (-e, $lockfile){unlink($lockfile);}}exit;}
if($form{'no'}){&fight;if($filelockuse ==1){if (-e, $lockfile){unlink($lockfile);}}exit;}
if($form{'rule'}){&rule;if($filelockuse ==1){if (-e, $lockfile){unlink($lockfile);}}exit;}
if($form{'rec'}){&rec;if($filelockuse ==1){if (-e, $lockfile){unlink($lockfile);}}exit;}
if($form{'rank'}){&rank;if($filelockuse ==1){if (-e, $lockfile){unlink($lockfile);}}exit;}
if($form{'log'}){&log;if($filelockuse ==1){if (-e, $lockfile){unlink($lockfile);}}exit;}
if($form{'pass'}){
	&edit;
	if($filelockuse ==1){if (-e, $lockfile){unlink($lockfile);}}
	exit;
}
&html;

if($filelockuse ==1){if (-e, $lockfile){unlink($lockfile);}}
exit;


##### ���ڵ壦���� ������ �ְ� �޾�
sub decode{

#�Էµ� ���� ���ڵ�
	if ($ENV{'REQUEST_METHOD'} eq "GET") {
		$buffer = $ENV{'QUERY_STRING'};
	} elsif ($ENV{'REQUEST_METHOD'} eq "POST") {
		read(STDIN, $buffer, $ENV{'CONTENT_LENGTH'});
	}
@pairs = split(/&/,$buffer);
foreach $pair (@pairs) {
	($key, $value) = split(/=/, $pair);
	$value =~ tr/+/ /;
	$value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
	&jcode'convert(*value, "euc");
	$value =~ s/</&lt;/g;
	$value =~ s/>/&gt;/g;
	$value =~ s/ //g;
	$value =~ s/ //g;
	$form{$key} = $value;

	}

}#end decode

##### �α� read
sub readlog{
	open(DB,"$logfile");
	seek(DB, 0,0);  @lines = <DB>;  close(DB);
	($lno, $lname, $lsakusya, $lhomepage, $llif, $lpow, $ldef, $lspe, $ldate, $lip, $lwin, $lplus1, $lplus2, $lplus3, $lplus4, $lplus5, $lold, $limgtype, $lmail, $lmailopen, $ltaisyokumail, $lpass, $dmy) = split(/<>/, $lines[0]);

	open(TM,"$timefile");
	seek(TM, 0,0);  @times = <TM>;  close(TM);
	open(KTM,"$ktimefile");
	seek(KTM, 0,0);  $times2 = <KTM>;  close(KTM);

# �ð��� ���
	
	$timemin = time();		# �ʽð��� ���
	$times =time;
	($sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst) = localtime($times);
	$year += 1900;
	$month = sprintf("%02d", $mon +1);
	$mday = sprintf("%02d", $mday);
	$hour = sprintf("%02d", $hour);
	$min = sprintf("%02d", $min);
	$sec = sprintf("%02d", $sec);
	$jikan2 = "$month/$mday $hour:$min";
	
# �ð� ������ �ϴö��� ���⼭ ���

	if($times[0] eq ""){
	$times[0] = int($hour/$oldtime);
	open(TM,">$timefile") ;
		eval 'flock(TM, 2);';
		seek(TM, 0,0);	print TM @times;
		eval 'flock(TM, 8);';
	close(TM);
		}

	if($times2 eq ""){
	$times2 = int($timemin/$kaigi);
	open(KTM,">$ktimefile") ;
		eval 'flock(KTM, 2);';
		seek(KTM, 0,0);	print KTM $times2;
		eval 'flock(KTM, 8);';
	close(KTM);
		}


}#end readlog

##### ���̸� �԰� �ϴ� ó��
sub oldplus{
	open(DB,"$logfile");
	seek(DB, 0,0) ;@lines = <DB>;  close(DB);
	foreach $lines (@lines){
		($lno, $lname, $lsakusya, $lhomepage, $llif, $lpow, $ldef, $lspe, $ldate, $lip, $lwin, $plus1, $plus2, $plus3, $plus4, $plus5, $lold, $limgtype, $mail, $lmailopen, $ltaisyokumail, $lpass, $dmy) = split(/<>/, $lines);
		$lold++;
		$mail =~ s/\s*$//;
		$lines = "$lno<>$lname<>$lsakusya<>$lhomepage<>$llif<>$lpow<>$ldef<>$lspe<>$ldate<>$lip<>$lwin<>$plus1<>$plus2<>$plus3<>$plus4<>$plus5<>$lold<>$limgtype<>$mail<>$lmailopen<>$ltaisyokumail<>$lpass<>\n";
			#���⿡ �� ��ģ ����� ��� ���´�
			if($lold < $teinen){
				push(@ikinokori, $lines);
			}else{
				#������ �ִ� ������ ����
				$winkekka = "$kata3[0]";

				#���� ����
				for ($i=0; $i<50; $i++){
					if($lwin == $i){
						$winkekka = "$kata3[$i]";
						if($i >= 18){$winkekka = "$kata3[18]";}
						if($lwin <= 12){
							$bonus=0;
						}elsif($lwin == 13){
							$bonus=$syokina;
						}elsif($lwin == 14){
							$bonus=$syokinb;
						}elsif($lwin == 15){
							$bonus=$syokinc;
						}elsif($lwin == 16){
							$bonus=$syokind;
						}elsif($lwin == 17){
							$bonus=$syokine;
						}elsif($lwin >= 18){
							$bonus=$syokinf;
						}
						last;
					}
				}

				#���� ����
				if($abiyause == 1 && $bonus > 0){#������ ���� ������ ������ �߰�
					$times =time;
					open(SAIFU,"$osaifufile") || print "Content-type: text/html\n\n$osaifufile�� ������ �ʾҽ��ϴ�";
					seek(SAIFU, 0,0) ;@saifu = <SAIFU>;close(SAIFU);
					$ita = 0;
					for ($ii=0; $ii<$#saifu+1; $ii++){
						($oname, $ocount, $odate, $ohost, $oraitenkaisu, $osankaimg, $opw, $intime2, $jikan2t, $totaltime2, $llwgn, $abicorp, $vboss, $mahjong, $dmy1, $dmy2, $dmy3, $dmy4) = split(/<>/, $saifu[$ii]);
						if($lsakusya eq $oname){
							$ocounttmp = $bonus / 10000;
							$ocount = $ocount + $bonus;
							$vboss = $vboss + int($ocounttmp);
							$newline = "$oname<>$ocount<>$times<>$ohost<>$oraitenkaisu<>$osankaimg<>$opw<><>$jikan2t<>$totaltime2<>$llwgn<>$abicorp<>$vboss<>$mahjong<>$dmy1<>$dmy2<>$dmy3<>\n";
							splice(@saifu, $ii, 1, $newline);
							$ita = 1;
							last;
						}
					}
					if($abiyafilelockuse ==1){&abiyalock;}
					open(SAIFU,">$osaifufile") ;seek(SAIFU, 0,0) ;print SAIFU @saifu;close(SAIFU);
					if (-e, $abiyalockfile){unlink($abiyalockfile);}

				}
				if(($bonus)&&($ita)){
					$whatnew = "$jikan2 $lsakusya�����Դ� �Ұ���<font color=green>$ocounttmp ����</font>�� ���ҵǾ����ϴ�. <br>$jikan2 $lname$winkekka�� <font color=red>�������� </font>�Ǿ����ϴ�. <br>\n";
				}else{
					$whatnew = "$jikan2 $lname$winkekka�� <font color=red>�������� </font>�Ǿ����ϴ�. <br>\n";
				}

				# �纸���� ������
				open(BOOK,"$whatnewfile");
				seek(BOOK, 0,0);  @syanaiho = <BOOK>;  close(BOOK);

				unshift (@syanaiho , join('' , $whatnew));
				splice( @syanaiho, $max_syanaiho);

				open(BOOK,">$whatnewfile") ;
					eval 'flock(BOOK, 2);';
					print BOOK @syanaiho;
					eval 'flock(BOOK, 8);';
				close(BOOK);

				if($sendmail && $ltaisyokumail == 1){
					$mail =~ s/mailto://g;
					$rideonmailcomment2 = "$lname$winkekka�� �Ұ��� $lsakusya��. ". "$rideonmailcomment";
					&jcode'convert(*rideonmailtitle, 'euc');
					&jcode'convert(*rideonmailcomment2, 'euc');
					&jcode'convert(*mailto, 'euc');

					if (open(MAIL,"| $sendmail -t")) {

						print MAIL "To: $mail\n";

						#������ ������ ���
						print MAIL "From: $mailto\n";
						print MAIL "Subject: $rideonmailtitle\n";
						print MAIL "Content-Transfer-Encoding: 7bit\n";
						print MAIL "MIME-Version: 1.0\n";
						print MAIL "Content-type: text/plain; charset=Euc_kr\n";
						print MAIL "$rideonmailcomment2\n\n";
						print MAIL "$mailfooter\n";

						#sendmail�� �ݴ´�
						close(MAIL);

					}
				}
			}
	}

@lines = @ikinokori;
	open(DB,">$logfile") ;
		eval 'flock(DB, 2);';
		seek(DB, 0,0);	print DB @ikinokori;
		eval 'flock(DB, 8);';
	close(DB);

	#���̸� �԰� �� �ð��� ���
	if ($oldtime){$times[0] = int($hour/$oldtime);}
	open(TM,">$timefile") ;
		eval 'flock(TM, 2);';
		seek(TM, 0,0);	print TM @times;
		eval 'flock(TM, 8);';
	close(TM);

}#end readlog

##### ���� ó��

sub syori{
	
	srand;
	@new=();
	@oldkeisan=0..$#lines;    #ȸ�� ��� ���� ����
	while(@oldkeisan) {
	    push(@new, splice(@oldkeisan, rand @oldkeisan, 1));
	}
	$a = $lines[$new[0]];
	$b = $lines[$new[1]];
	$c = $lines[$new[2]];
	$d = $lines[$new[3]];

	# ���� ���� ����
	for ($i=0; $i<2; $i++){
	($lno0, $lname0, $lsakusya0, $lhomepage0, $llif0, $lpow0, $ldef0, $lspe0, $ldate0, $lip0, $dmy, $plus10, $plus20, $plus30, $plus40, $plus50, $lold0, $limgtype0, $lmail0, $lmailopen0, $ltaisyokumail0, $lpass0, $dmy) = split(/<>/, $a);
	($lno1, $lname1, $lsakusya1, $lhomepage1, $llif1, $lpow1, $ldef1, $lspe1, $ldate1, $lip1, $dmy, $plus11, $plus21, $plus31, $plus41, $plus51, $lold1, $limgtype1, $lmail1, $lmailopen1, $ltaisyokumail1, $lpass1, $dmy) = split(/<>/, $b);
		if($lspe0 < $lspe1){
		$e = $a; $f= $b; $a = $f; $b = $e;
		}
	($lno2, $lname2, $lsakusya2, $lhomepage2, $llif2, $lpow2, $ldef2, $lspe2, $ldate2, $lip2, $dmy, $plus12, $plus22, $plus32, $plus42, $plus52, $lold2, $limgtype2, $lmail2, $lmailopen2, $ltaisyokumail2, $lpass2, $dmy) = split(/<>/, $c);
	($lno3, $lname3, $lsakusya3, $lhomepage3, $llif3, $lpow3, $ldef3, $lspe3, $ldate3, $lip3, $dmy, $plus13, $plus23, $plus33, $plus43, $plus53, $lold3, $limgtype3, $lmail3, $lmailopen3, $ltaisyokumail3, $lpass3, $dmy) = split(/<>/, $d);
		if($lspe2 < $lspe3){
		$e = $c; $f= $d; $c = $f; $d = $e;
		}
	($lno1, $lname1, $lsakusya1, $lhomepage1, $llif1, $lpow1, $ldef1, $lspe1, $ldate1, $lip1, $dmy, $plus11, $plus21, $plus31, $plus41, $plus51, $lold1, $limgtype1, $lmail1, $lmailopen1, $ltaisyokumail1, $lpass1, $dmy) = split(/<>/, $b);
	($lno2, $lname2, $lsakusya2, $lhomepage2, $llif2, $lpow2, $ldef2, $lspe2, $ldate2, $lip2, $dmy, $plus12, $plus22, $plus32, $plus42, $plus52, $lold2, $limgtype2, $lmail2, $lmailopen2, $ltaisyokumail2, $lpass2, $dmy) = split(/<>/, $c);
		if($lspe1 < $lspe2){
		$e = $b; $f= $c; $b = $f; $c = $e;
		}
	}


	# ������ �϶�

	@buckup = ($a, $b, $c, $d);
	($sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst) = localtime($times);


	$month = sprintf("%02d", $mon + 1);
	$mday = sprintf("%02d", $mday);
	$hour = sprintf("%02d", $hour);
	$min = sprintf("%02d", $min);
	$log[$m] = "$month��$mday��$hour��$min ���� ȸ�Ƿ�<>";
	$m++;
	
	@a = split(/<>/, $a);
	@b = split(/<>/, $b);
	@c = split(/<>/, $c);
	@d = split(/<>/, $d);

	$win = $a[10];
	$imgtype = $a[17];
	#������ �ִ� ������ ����
	$winkekka = "$kata2[0]";

	#���� ����
	for ($i=0; $i<50; $i++){
		if($win == $i){
			$winkekka = "$kata2[$i]";
			if($i >= 18){$winkekka = "$kata2[18]";}
			if($win == 0){
				$image = "$imgtype"."/1.gif";
				$backimage = "$imgfld/back1.gif";
			}elsif($win <= 2){
				$image = "$imgtype"."/2.gif";
				$backimage = "$imgfld/back1.gif";
			}elsif($win <= 4){
				$image = "$imgtype"."/3.gif";
				$backimage = "$imgfld/back1.gif";
			}elsif($win <= 7){
				$image = "$imgtype"."/4.gif";
				$backimage = "$imgfld/back1.gif";
			}elsif($win <= 12){
				$image = "$imgtype"."/5.gif";
				$backimage = "$imgfld/back2.gif";
			}elsif($win >= 13){
				$image = "$imgtype"."/6.gif";
				$backimage = "$imgfld/back3.gif";
			}
			$win = $winkekka;
			last;
		}
	}
	if($imgtype =~ /\.gif/ || $imgtype =~ /\.jpg/ || $imgtype =~ /\.png/){$image = $imgtype;}
	$wina = $win;
	$imagea = $image;
	$backimagea = $backimage; 
	$imagetag = "<img src=$image width=82 height=78>";
	$shiwaa = $imagetag;

	$win = $b[10];
	$imgtype = $b[17];
	#������ �ִ� ������ ����
	$winkekka = "$kata2[0]";

	#���� ����
	for ($i=0; $i<50; $i++){
		if($win == $i){
			$winkekka = "$kata2[$i]";
			if($i >= 18){$winkekka = "$kata2[18]";}
			if($win == 0){
				$image = "$imgtype"."/1.gif";
				$backimage = "$imgfld/back1.gif";
			}elsif($win <= 2){
				$image = "$imgtype"."/2.gif";
				$backimage = "$imgfld/back1.gif";
			}elsif($win <= 4){
				$image = "$imgtype"."/3.gif";
				$backimage = "$imgfld/back1.gif";
			}elsif($win <= 7){
				$image = "$imgtype"."/4.gif";
				$backimage = "$imgfld/back1.gif";
			}elsif($win <= 12){
				$image = "$imgtype"."/5.gif";
				$backimage = "$imgfld/back2.gif";
			}elsif($win >= 13){
				$image = "$imgtype"."/6.gif";
				$backimage = "$imgfld/back3.gif";
			}
			$win = $winkekka;
			last;
		}
	}
	if($imgtype =~ /\.gif/ || $imgtype =~ /\.jpg/ || $imgtype =~ /\.png/){$image = $imgtype;}
	$winb = $win;
	$imageb = $image;
	$backimageb = $backimage; 
	$imagetag = "<img src=$image width=82 height=78>";
	$shiwab = $imagetag;

	$win = $c[10];
	$imgtype = $c[17];
	#������ �ִ� ������ ����
	$winkekka = "$kata2[0]";

	#���� ����
	for ($i=0; $i<50; $i++){
		if($win == $i){
			$winkekka = "$kata2[$i]";
			if($i >= 18){$winkekka = "$kata2[18]";}
			if($win == 0){
				$image = "$imgtype"."/1.gif";
				$backimage = "$imgfld/back1.gif";
			}elsif($win <= 2){
				$image = "$imgtype"."/2.gif";
				$backimage = "$imgfld/back1.gif";
			}elsif($win <= 4){
				$image = "$imgtype"."/3.gif";
				$backimage = "$imgfld/back1.gif";
			}elsif($win <= 7){
				$image = "$imgtype"."/4.gif";
				$backimage = "$imgfld/back1.gif";
			}elsif($win <= 12){
				$image = "$imgtype"."/5.gif";
				$backimage = "$imgfld/back2.gif";
			}elsif($win >= 13){
				$image = "$imgtype"."/6.gif";
				$backimage = "$imgfld/back3.gif";
			}
			$win = $winkekka;
			last;
		}
	}
	if($imgtype =~ /\.gif/ || $imgtype =~ /\.jpg/ || $imgtype =~ /\.png/){$image = $imgtype;}
	$winc = $win;
	$backimagec = $backimage; 
	$imagetag = "<img src=$image width=82 height=78>";
	$shiwac = $imagetag;

	$win = $d[10];
	$imgtype = $d[17];
	#������ �ִ� ������ ����
	$winkekka = "$kata2[0]";

	#���� ����
	for ($i=0; $i<50; $i++){
		if($win == $i){
			$winkekka = "$kata2[$i]";
			if($i >= 18){$winkekka = "$kata2[18]";}
			if($win == 0){
				$image = "$imgtype"."/1.gif";
				$backimage = "$imgfld/back1.gif";
			}elsif($win <= 2){
				$image = "$imgtype"."/2.gif";
				$backimage = "$imgfld/back1.gif";
			}elsif($win <= 4){
				$image = "$imgtype"."/3.gif";
				$backimage = "$imgfld/back1.gif";
			}elsif($win <= 7){
				$image = "$imgtype"."/4.gif";
				$backimage = "$imgfld/back1.gif";
			}elsif($win <= 12){
				$image = "$imgtype"."/5.gif";
				$backimage = "$imgfld/back2.gif";
			}elsif($win >= 13){
				$image = "$imgtype"."/6.gif";
				$backimage = "$imgfld/back3.gif";
			}
			$win = $winkekka;
			last;
		}
	}
	if($imgtype =~ /\.gif/ || $imgtype =~ /\.jpg/ || $imgtype =~ /\.png/){$image = $imgtype;}
	$wind = $win;
	$backimaged = $backimage; 
	$imagetag = "<img src=$image width=82 height=78>";
	$shiwad = $imagetag;

		if($profileuse){
			local($edname) = &urlencode($a[2]);
			$a[2] = "<a href=\"$profileurl?mode=view&name=$edname\" target=\"_blank\">$a[2]</a> ";
		}
		if($a[3]){
			$a[3] = "[<a href=\"$a[3]\">HP</a> ]"
		}else{
			$a[3] = ""
		}
		$a[18] =~ s/\s*$//;
		if($a[18] && $a[19] == 1){
			$a[18] = "[<a href=\"$a[18]\">ML</a> ]"
		}else{
			$a[18] = ""
		}
	$log[$m] = "�⼮�ڣ�$a[1]$wina , $b[1]$winb , $c[1]$winc , $d[1]$wind<>";
	$m++;
	$log[$m] = "<table align=center><tr><td><table border=\"0\" cellspacing=\"0\" cellpadding=\"1\" bgcolor=\"#000000\"><tr><td><table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" bgcolor=\"#dddddd\"><tr><td valign=\"top\"><table border=\"0\" cellspacing=\"1\" cellpadding=\"1\" bgcolor=\"#dddddd\"><tr><td><table border=\"0\" cellspacing=\"1\" cellpadding=\"1\" width=\"100%\" background=$imgfld/titleback.jpg><tr><td nowrap><font size=\"2\" color=\"#ffffff\"><b>$a[1]</b></font></td></tr></table><table border=\"0\" cellspacing=\"1\" cellpadding=\"1\" width=\"100%\"><tr><td nowrap><font size=\"2\" face=\"MS ����\" style=\"line-height: 100%\">$tablelif<br>$tablepow<br>����<br>����<br>��� No<br>�Ի���</td><td nowrap><div align=\"right\"><font size=\"2\" face=\"MS ����\" style=\"line-height: 100%\">$a[4]P<br>$a[5]P<br>$a[16]��<br>$wina<br>$a[0]<br>$a[8]</div></td></tr></table><div align=\"right\"><font size=\"2\" face=\"MS ����\" style=\"line-height: 100%\">by $a[2] $a[3] $a[18]</font></div></td></tr></table></td><td bgcolor=\"#ffffff\" background=\"$backimage\" valign=\"bottom\" width=\"84\"><div align=\"center\">$shiwaa</div></td></tr></table></td></tr></table></td>";
	$m++;
		if($profileuse){
			local($edname) = &urlencode($b[2]);
			$b[2] = "<a href=\"$profileurl?mode=view&name=$edname\" target=\"_blank\">$b[2]</a> ";
		}
		if($b[3]){
			$b[3] = "[<a href=\"$b[3]\">HP</a> ]"
		}else{
			$b[3] = ""
		}
		$b[18] =~ s/\s*$//;
		if($b[18] && $b[19] == 1){
			$b[18] = "[<a href=\"$b[18]\">ML</a> ]"
		}else{
			$b[18] = ""
		}
	$log[$m] = "<td><table border=\"0\" cellspacing=\"0\" cellpadding=\"1\" bgcolor=\"#000000\"><tr><td><table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" bgcolor=\"#dddddd\"><tr><td valign=\"top\"><table border=\"0\" cellspacing=\"1\" cellpadding=\"1\" bgcolor=\"#dddddd\"><tr><td><table border=\"0\" cellspacing=\"1\" cellpadding=\"1\" width=\"100%\" background=$imgfld/titleback.jpg><tr><td nowrap><font size=\"2\" color=\"#ffffff\"><b>$b[1]</b></font></td></tr></table><table border=\"0\" cellspacing=\"1\" cellpadding=\"1\" width=\"100%\"><tr><td nowrap><font size=\"2\" face=\"MS ����\" style=\"line-height: 100%\">$tablelif<br>$tablepow<br>����<br>����<br>��� No<br>�Ի���</td><td nowrap><div align=\"right\"><font size=\"2\" face=\"MS ����\" style=\"line-height: 100%\">$b[4]P<br>$b[5]P<br>$b[16]��<br>$winb<br>$b[0]<br>$b[8]</div></td></tr></table><div align=\"right\"><font size=\"2\" face=\"MS ����\" style=\"line-height: 100%\">by $b[2] $b[3] $b[18]</font></div></td></tr></table></td><td bgcolor=\"#ffffff\" background=\"$backimage\" valign=\"bottom\" width=\"84\"><div align=\"center\">$shiwab</div></td></tr></table></td></tr></table></td></tr>";
	$m++;
		if($profileuse){
			local($edname) = &urlencode($c[2]);
			$c[2] = "<a href=\"$profileurl?mode=view&name=$edname\" target=\"_blank\">$c[2]</a> ";
		}
		if($c[3]){
			$c[3] = "[<a href=\"$c[3]\">HP</a> ]"
		}else{
			$c[3] = ""
		}
		$c[18] =~ s/\s*$//;
		if($c[18] && $c[19] == 1){
			$c[18] = "[<a href=\"$c[18]\">ML</a> ]"
		}else{
			$c[18] = ""
		}
	$log[$m] = "<tr><td><table border=\"0\" cellspacing=\"0\" cellpadding=\"1\" bgcolor=\"#000000\"><tr><td><table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" bgcolor=\"#dddddd\"><tr><td valign=\"top\"><table border=\"0\" cellspacing=\"1\" cellpadding=\"1\" bgcolor=\"#dddddd\"><tr><td><table border=\"0\" cellspacing=\"1\" cellpadding=\"1\" width=\"100%\" background=$imgfld/titleback.jpg><tr><td nowrap><font size=\"2\" color=\"#ffffff\"><b>$c[1]</b></font></td></tr></table><table border=\"0\" cellspacing=\"1\" cellpadding=\"1\" width=\"100%\"><tr><td nowrap><font size=\"2\" face=\"MS ����\" style=\"line-height: 100%\">$tablelif<br>$tablepow<br>����<br>����<br>��� No<br>�Ի���</td><td nowrap><div align=\"right\"><font size=\"2\" face=\"MS ����\" style=\"line-height: 100%\">$c[4]P<br>$c[5]P<br>$c[16]��<br>$winc<br>$c[0]<br>$c[8]</div></td></tr></table><div align=\"right\"><font size=\"2\" face=\"MS ����\" style=\"line-height: 100%\">by $c[2] $c[3] $c[18]</font></div></td></tr></table></td><td bgcolor=\"#ffffff\" background=\"$backimage\" valign=\"bottom\" width=\"84\"><div align=\"center\">$shiwac</div></td></tr></table></td></tr></table></td>";
	$m++;
		if($profileuse){
			local($edname) = &urlencode($d[2]);
			$d[2] = "<a href=\"$profileurl?mode=view&name=$edname\" target=\"_blank\">$d[2]</a> ";
		}
		if($d[3]){
			$d[3] = "[<a href=\"$d[3]\">HP</a> ]"
		}else{
			$d[3] = ""
		}
		$d[18] =~ s/\s*$//;
		if($d[18] && $d[19] == 1){
			$d[18] = "[<a href=\"$d[18]\">ML</a> ]"
		}else{
			$d[18] = ""
		}
	$log[$m] = "<td><table border=\"0\" cellspacing=\"0\" cellpadding=\"1\" bgcolor=\"#000000\"><tr><td><table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" bgcolor=\"#dddddd\"><tr><td valign=\"top\"><table border=\"0\" cellspacing=\"1\" cellpadding=\"1\" bgcolor=\"#dddddd\"><tr><td><table border=\"0\" cellspacing=\"1\" cellpadding=\"1\" width=\"100%\" background=$imgfld/titleback.jpg><tr><td nowrap><font size=\"2\" color=\"#ffffff\"><b>$d[1]</b></font></td></tr></table><table border=\"0\" cellspacing=\"1\" cellpadding=\"1\" width=\"100%\"><tr><td nowrap><font size=\"2\" face=\"MS ����\" style=\"line-height: 100%\">$tablelif<br>$tablepow<br>����<br>����<br>��� No<br>�Ի���</td><td nowrap><div align=\"right\"><font size=\"2\" face=\"MS ����\" style=\"line-height: 100%\">$d[4]P<br>$d[5]P<br>$d[16]��<br>$wind<br>$d[0]<br>$d[8]</div></td></tr></table><div align=\"right\"><font size=\"2\" face=\"MS ����\" style=\"line-height: 100%\">by $d[2] $d[3] $d[18]</font></div></td></tr></table></td><td bgcolor=\"#ffffff\" background=\"$backimage\" valign=\"bottom\" width=\"84\"><div align=\"center\">$shiwad</div></td></tr></table></td></tr></table></td></tr></table>";
	$m++;
	
	$log[$m] = "<P><hr size=\"1\"></P>";
	$m++;


	# �������� �ִ� ó��.

	@fight = ($a, $b, $c, $d);
	$number = 4;
	srand(time+$$);
	srand(time+$$);
	while($number > 1){
		for ($i=0; $i<$number; $i++){
		($lno[$i], $lname[$i], $lsakusya[$i], $lhomepage[$i], $llif[$i], $lpow[$i], $ldef[$i], $lspe[$i], $ldate[$i], $lip[$i], $dmy, $plus1[$i], $plus2[$i], $plus3[$i], $plus4[$i], $plus5[$i], $lold[$i], $limgtype[$i], $lmail[$i], $lmailopen[$i], $ltaisyokumail[$i], $lpass[$i], $dmy) = split(/<>/, $fight[$i]);
		}
	if($number > 2){
	$j = $number-1;
	$k = int(rand($j))+1;
	}else{$k=1;}


	if(int(rand($rate2)) < $lspe[$k]){ # ȸ������ ���

	$log[$m] = "$plus1[0]<font color=\"$ccolor\"><B>$lname[0]</B></font>�� ����, �׷���<font color=\"$ccolor\"><B>$lname[$k]</B></font>�� �ݷ��ߴ�. <BR>$plus2[$k]";
	$m++;

	}else{ # �������� �־��� ���


	@syusei1 = (0.9 , 1 , 1 , 1.1 );
	$y = int(rand(3));
	@syusei2 = (0.7 , 0.7 , 0.8 , 0.8 , 0.8 , 0.9 , 1.0 );
	$z = int(rand(6));

	$bpow = int($lpow[0] * $syusei1[$y]);
	$bdef = int($ldef[$k] * $syusei2[$z]);

	$damege = $bpow - $bdef;

	$sounyu = "";
	$kaishin = 50 - $llif[0];
	if(int(rand($rate1)) < $kaishin){
		$damege = $lpow[0];
		$sounyu = "�Դٰ� �װ��� ������ ���� ȹ������ ������ �� �Դ�! <br>";
		$plus1[0] = $plus5[0];
		}


	if($damege<1){$damege = 1;}
	$llif[$k] = $llif[$k] - $damege;

	$lmail[$k] =~ s/\s*$//;
	$fight[$k] = "$lno[$k]<>$lname[$k]<>$lsakusya[$k]<>$lhomepage[$k]<>$llif[$k]<>$lpow[$k]<>$ldef[$k]<>$lspe[$k]<>$ldate[$k]<>$lip[$k]<><>$plus1[$k]<>$plus2[$k]<>$plus3[$k]<>$plus4[$k]<>$plus5[$k]<>$lold[$k]<>$limgtype[$k]<>$lmail[$k]<>$lmailopen[$k]<>$ltaisyokumail[$k]<>$lpass[$k]<>\n";

	$log[$m] = "$plus1[0]<font color=\"$ccolor\"><B>$lname[0]</B></font>�� �����ߴ�. $sounyu<font color=\"$ccolor\"><B>$lname[$k]</B></font>�� <B>$damege</B>������ �Ҿ���. <BR>";
	$m++;

	}



	# ��� ó��
	if ($llif[$k] < 1){
		$number--;
		splice(@fight, $k, 1);
		$log[$m] = "<font color=\"$ccolor\"><B>$lname[$k]</B></font>�� ��ħ�� ������ ������, �߾��ϴ� ���� �׸��ξ���. <BR>$plus4[$k]";
		$m++;
		}

		@life = '';
		for ($i=0; $i<$number; $i++){
		($kno[$i], $kname[$i], $ksakusya[$i], $khomepage[$i], $klif[$i], $kpow[$i], $kdef[$i], $kspe[$i], $kdate[$i], $kip[$i], $kwin[$i], $plus1[$i], $plus2[$i], $plus3[$i], $plus4[$i], $plus5[$i], $kold[$i], $kimgtype[$i], $kmail[$i], $kmailopen[$i], $ktaisyokumail[$i], $kpass[$i], $dmy) = split(/<>/, $fight[$i]);
		$life[$i] = "<B>$kname[$i]</B>��<B>$klif[$i]</B> , ";
		}
	$log[$m] = "<BR>�⼮���� ����(@life)<BR>";
	$m++;


	$log[$m] = "<BR>";
	$m++;
	$irekae = shift(@fight);
	push(@fight, $irekae);
	}
	$syainsu = $#lines + 1; #������ ����
	for ($i=0; $i<$syainsu; $i++){
	if($lines[$i] =~ /^$lno[0]<>/){
	($lno[$i], $lname[$i], $lsakusya[$i], $lhomepage[$i], $llif[$i], $lpow[$i], $ldef[$i], $lspe[$i], $ldate[$i], $lip[$i], $lwin[$i], $plus1[$i], $plus2[$i], $plus3[$i], $plus4[$i], $plus5[$i], $lold[$i], $limgtype[$i], $lmail[$i], $lmailopen[$i], $ltaisyokumail[$i], $lpass[$i], $dmy) = split(/<>/, $lines[$i]);
	$lmail[$i] =~ s/\s*$//;
	$lwin[$i]++;
	$winner = "$lno[$i]<>$lname[$i]<>$lsakusya[$i]<>$lhomepage[$i]<>$llif[$i]<>$lpow[$i]<>$ldef[$i]<>$lspe[$i]<>$ldate[$i]<>$lip[$i]<>$lwin[$i]<>$plus1[$i]<>$plus2[$i]<>$plus3[$i]<>$plus4[$i]<>$plus5[$i]<>$lold[$i]<>$limgtype[$i]<>$lmail[$i]<>$lmailopen[$i]<>$ltaisyokumail[$i]<>$lpass[$i]<>\n";
	$log[$m] = "ä��� ����<font color=\"$ccolor\"><B>$lname[$i]</B></font>�� ��������, �̰����� ���<font color=\"$ccolor\"><B>$lwin[$i]</B></font>ȸä��Ǿ����ϴ�. $plus3[$i]\n";
	$winname = $lname[$i];
	$winkekka = $lwin[$i];
	$m++
	}
	}


	# ���� ��� ������ ����
	open(FG,"$fightfile");
	seek(FG, 0,0);  @fg = <FG>;  close(FG);

	unshift (@fg , join('' , @log));
	splice( @fg, $max_fight);

	open(FG,">$fightfile") ;
		eval 'flock(FG, 2);';
		seek(FG, 0,0);	print FG @fg;
		eval 'flock(FG, 8);';
	close(FG);

	# �纸�� �����ϴ� ��Ÿ���� ����
	#������ �ִ� ������ ����

	#���� ����
	for ($i=1; $i<19; $i++){
		if($winkekka == $i){
			$ii = $i-1;
			$winkekkan = "$kata3[$i]";
			$winmae = "$kata3[$ii]";
			last;
		}
	}
	if($winkekka < 19){$whatnew = "$jikan2 $winname$winmae��$winkekkan��<font color=green>����</font>�Ǿ����ϴ�. <br>\n";}

# �纸���� ������
	open(BOOK,"$whatnewfile");
	seek(BOOK, 0,0);  @syanaiho = <BOOK>;  close(BOOK);

	unshift (@syanaiho , join('' , $whatnew));
	splice( @syanaiho, $max_syanaiho);

	open(BOOK,">$whatnewfile") ;
		eval 'flock(BOOK, 2);';
		print BOOK @syanaiho;
		eval 'flock(BOOK, 8);';
	close(BOOK);

	# ĳ���� ��� ������ ����
	for ($linecount=0; $linecount<($#lines+1); $linecount++){
		if($lines[$linecount] == $winner){$lines[$linecount]=$winner};#�ǰ� ä��� ����� ����
	}

#�Ǹ��� ������ �ټ� �ٲ۴�
	foreach $i (0..(@lines-1)) {
	@Buf = split('<>', @lines[$i]);
	$SData{$i} = $Buf[10];
	}

	@SortData = sort {($SData{$b} <=> $SData{$a}) || ($b cmp $a)} keys(%SData);
	foreach $i (@SortData) {
	push(@newline, $lines[$i]);
	}

	@lines = @newline;
	open(DB,">$logfile") ;
		eval 'flock(DB, 2);';
		seek(DB, 0,0);	print DB @newline;
		eval 'flock(DB, 8);';
	close(DB);

	# ��ŷ ������ ����

	open(RK,"$rankfile");
	seek(RK, 0,0);  @rank = <RK>;  close(RK);

		@win = split(/<>/, $winner);
		
		foreach $check (@rank){
		@check = split(/<>/, $check);
		if($win[0] eq $check[0]){$check = '';}
		}

	if($rank[0] eq ''){$rank[0] = $winner;}
	else{
		foreach $check (@rank){
		@check = split(/<>/, $check);
		if($win[10] > $check[10]){$check = "$winner$check";$flag=1;last;}	
		elsif($win[10] eq $check[10]){$check = "$winner$check";$flag=1;last;}	
		}
		if($flag ne "1"){push(@rank, $winner);}
	}
	splice(@rank, $max_rank);
	
	open(RK,">$rankfile") ;
		eval 'flock(RK, 2);';
		seek(RK, 0,0);	print RK @rank;
		eval 'flock(RK, 8);';
	close(RK);


	# �ð� ������ ����
	if ($kaigi){$times2 = int($timemin/$kaigi);}
	open(KTM,">$ktimefile") ;
		eval 'flock(KTM, 2);';
		seek(KTM, 0,0);	print KTM $times2;
		eval 'flock(KTM, 8);';
	close(KTM);

}#end syori


##### ĳ���� ��� ó��

sub record{

	if($syainsu >= $max_chara){&error(0);}

# ������ �Űܳ��´�
	$formchara = $form{'chara'};
	$formname = $form{'name'};
	$formentrypass = $form{'entrypass'};
	$formhp = $form{'hp'};
	$formmail = $form{'mail'};
	$formlif = $form{'life'};
	$formpow = $form{'power'};
	$formdef = $form{'defence'};
	$formspe = $form{'speed'};
	if($form{'imode'} eq "f"){
		$formimg = $form{'ficon'};
	}else{
		$formimg = $form{'img'};
	}
	
# �ɷ�ġ üũ
	if(($formlif >50)||($formlif < 5)){&error(1)};
	if(($formpow >50)||($formpow < 5)){&error(1)};
	if(($formdef >50)||($formdef < 5)){&error(1)};
	if(($formspe >50)||($formspe < 5)){&error(1)};
	$total = $formlif + $formpow + $formdef + $formspe ;
	if($total ne 100){&error(2)};

# �̸��� ���� üũ
	if((length($formchara) < 1)||(length($formchara) > $nameleng *2)){&error(3)};
	if((length($formname) < 1)||(length($formname) > $nameleng *2)){&error(3)};
	if($formhp =~ /http/){
		($formhp =~ /^http:\/\/[a-zA-Z0-9]+/) || ($formhp = '');	#HP�� ����
	}else{
		$formhp = '';
	}
	if($formmail =~ /@/){
		if($formmail !~ /mailto/){
			$formmail = "mailto:$formmail"
		}
		$formmailopen  = $form{'mailopen'};
		$formtaisyokumail  = $form{'taisyokumail'};
	}else{
		$formmail = '';
		$formmailopen  = 0;
		$formtaisyokumail  = 0;
	}

# ����Ʈ ȣ��Ʈ ���
	$host = $ENV{'REMOTE_HOST'} || $ENV{'REMOTE_ADDR'};
	if($doubleentry == 1){
		@checkip = split(/<>/, $lines[$#lines]);
		if($host eq $checkip[9]){&error(4);} 
	}elsif($doubleentry == 2){
		for ($i=0; $i<$#lines +1; $i++){
			@checkip = split(/<>/, $lines[$i]);
			if($host eq $checkip[9]){&error(7);} #IP�ּҿ����� ��
			if($formname eq $checkip[2]){&error(7);} #�̸������� ��
		}
	}

# ĳ���� ��� �ѹ�

#��� ��ȣ�� ���ĸ� �����Ѵ�
	open(DBTMP,"$logfile");
	seek(DBTMP, 0,0);  @linestmp = <DBTMP>;  close(DBTMP);
	foreach $i (0..(@linestmp-1)) {
	@Buftmp = split('<>', @linestmp[$i]);
	$SDatatmp{$i} = $Buftmp[0];
	}

	@SortDatatmp = sort {($SDatatmp{$b} <=> $SDatatmp{$a}) || ($b cmp $a)} keys(%SDatatmp);

	$lno = $linestmp[$SortDatatmp[0]] +1;

# ��Ͻð�
	$year += 1900;
	$month = sprintf("%02d", $mon +1);
	$mday = sprintf("%02d", $mday);
	$hour = sprintf("%02d", $hour);
	$min = sprintf("%02d", $min);
	$sec = sprintf("%02d", $sec);
	$jikan = "$month/$mday $hour:$min";

	$hantei = "$form{'chara'}_$form{'plus1'}-$form{'plus2'}_$form{'plus3'}-$form{'plus4'}_$form{'plus5'}_$form{'hp'}_in_vbonline";
	$blname = "$form{'name'}";
	&autobl;

	&set_cookie;

# �����信 ����� ��ǥ��

	$recflag = '1';

}#end record

#####���۱� ǥ��
#####�ƺ��׿� ��ŷ ����ϰ� �ִ� �����, �ƺ��׿��� ��ũ �ּҸ� ��ŷ���� ������ �ٲپ �����ƿ�!
sub chosaku{
&secretcopyright;
print <<"_CHOSAKU_";

<hr size="1">
<table width=100%><tr><td style="font-size: 80%;color: #9b9b9b;">Check environment of operation<br>$viewbr</td>
<td><div align="right" style="font-size: 80%">
<a href="http://www.abi-station.com/rank/vboss.shtml" target="_top">VirtualBoss �⼼ ���� ��ġ ����Ʈ �Ұ���</a> <br>
<br>
<a href="http://www.abi-station.com/" target="_top">VirtualBoss online $ver(Free)<br><img src="$imgfld/banner.gif" width="88" height="31" border="0"></a> <br>
<a href="http://www.grn.mmtr.or.jp/~dabo/" target="_top">����������/��Ʋ �ο� ver1. 10(Free)</a> <br>
<a href="http://www.x2-dr.com/" target="_blank">X2-DR.com ������ Ŀ�´�Ƽ : �ѱ��� ����</a><br>
</div></td></tr></table>
</body>
</html>

_CHOSAKU_

}#end chosaku

sub ssi{
	open(DB,"$logfile");
	seek(DB, 0,0);  @lines = <DB>;  close(DB);
	($no, $name, $sakusya, $homepage, $lif, $pow, $def, $spe, $date, $ip, $win, $plus1, $plus2, $plus3, $plus4, $plus5, $old, $imgtype, $mail, $mailopen, $taisyokumail, $dmy) = split(/<>/, $lines[0]);
		if($profileuse){
			local($edname) = &urlencode($sakusya);
			$sakusya = "<a href=\"$profileurl?mode=view&name=$edname\" target=\"_blank\">$sakusya</a> ";
		}
		if($homepage){
			$hp = "[<a href=\"$homepage\">HP</a> ]"
		}else{
			$hp = ""
		}
		if($mail && $mailopen == 1){
			$ml = "[<a href=\"$mail\">ML</a> ]"
		}else{
			$ml = ""
		}

	#������ �ִ� ������ ����
	$winkekka = "$kata2[0]";

	#���� ����
	for ($i=0; $i<50; $i++){
		if($win == $i){
			$winkekka = "$kata2[$i]";
			if($i >= 18){$winkekka = "$kata2[18]";}
			if($win == 0){
				$image = "$imgtype"."/1.gif";
				$backimage = "$imgfld/back1.gif";
			}elsif($win <= 2){
				$image = "$imgtype"."/2.gif";
				$backimage = "$imgfld/back1.gif";
			}elsif($win <= 4){
				$image = "$imgtype"."/3.gif";
				$backimage = "$imgfld/back1.gif";
			}elsif($win <= 7){
				$image = "$imgtype"."/4.gif";
				$backimage = "$imgfld/back1.gif";
			}elsif($win <= 12){
				$image = "$imgtype"."/5.gif";
				$backimage = "$imgfld/back2.gif";
			}elsif($win >= 13){
				$image = "$imgtype"."/6.gif";
				$backimage = "$imgfld/back3.gif";
			}
			$win = $winkekka;
			last;
		}
	}
	if($imgtype =~ /\.gif/ || $imgtype =~ /\.jpg/ || $imgtype =~ /\.png/){$image = $imgtype;}
	print "Content-type: text/html\n\n";
	print "<table border=\"0\" cellspacing=\"0\" cellpadding=\"1\" bgcolor=$flamecol><tr><td>\n";
	print "<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" bgcolor=\"#dddddd\"><tr><td valign=\"top\">\n";
	print "<table border=\"0\" cellspacing=\"1\" cellpadding=\"1\" bgcolor=\"#dddddd\"><tr><td>\n";
	print "<table border=\"0\" cellspacing=\"1\" cellpadding=\"1\" width=\"100%\" background=$imgfld/titleback.jpg><tr><td nowrap><font size=\"2\" color=\"#ffffff\"><b>$name</b></font></td></tr></table>\n";
	print "<table border=\"0\" cellspacing=\"1\" cellpadding=\"1\" width=\"100%\"><tr><td nowrap><font size=\"2\" face=\"MS ����\" style=\"line-height: 100%\">$tablelif<br>$tablepow<br>����<br>����<br>��� No<br>�Ի���</td><td nowrap><div align=\"right\"><font size=\"2\" face=\"MS ����\" style=\"line-height: 100%\">$lifP<br>$powP<br>$old��<br>$win<br>$no<br>$date</div></td></tr></table>\n";
	print "<div align=\"right\"><font size=\"2\" style=\"line-height: 100%\">by $sakusya $hp $ml</font></div></td></tr></table>\n";

	print "</td><td bgcolor=\"#ffffff\" background=\"$backimage\" valign=\"bottom\" width=\"84\"><div align=\"center\">";
	$imagetag = "<img src=$image width=82 height=78>";
	$imagetag1 = "";
	$imagetag2 = "";
	$shiwaimagetag = "";

	if(($old > 34)&&($imgtype !~ /\.gif/)&&($ENV{'HTTP_USER_AGENT'} =~ /(. +)\/(\d)\. (\d+). *compatible\; MSIE (\d)\. (\d+)/)){
		$aposision = 25;
		$bposision = 5;
		if($imgtype =~ /violet/){$bposision = $bposision+5;}
		if(($imgtype =~ /brown/)&&($image =~ /3/)){$bposision = $bposision-4;}
		$shiwaimagetag = "<span id=Layer$i style=\"width:3px; height:3px; position:relative; z-index:1; left: $bposision px; top: $aposision px\"><img src=$imgfld/shiwa.gif width=3 height=3></span>";
		$imagetag1 = "<span id=Layer$i style=\"width:82px; height:78px; position: relative; z-index:0; left: 0px; top: 0px\">";
		$imagetag2 = "</span>";
		$i++;
	}
	print "$shiwaimagetag$imagetag1$imagetag$imagetag2";
	print "</div></td></tr></table>\n";
	print "</td></tr></table>\n";

}

##### ���
sub html{

	if ($title){$comment = "<BR><BR>$comment";}
	open(BOOK,"$whatnewfile");
	seek(BOOK, 0,0);  @syanaiho = <BOOK>;  close(BOOK);

	if($abiyause == 1){
		$edit_a = &addcamma($syokina);
		$edit_b = &addcamma($syokinb);
		$edit_c = &addcamma($syokinc);
		$edit_d = &addcamma($syokind);
		$edit_e = &addcamma($syokine);
		$edit_f = &addcamma($syokinf);

		$abiyahowto = "1, ������� ������ ���� �Ұ��ڿ��Դ� �Ұ��ᰡ ���ҵ˴ϴ�. <br>$tablefuchitag1<table border=1 cellspacing=1 cellpadding=3 bordercolor=$flamecol bordercolordark=$flamecol bordercolorlight=$flamecol bgcolor=$flamecol><tr bgcolor=$datacol><td background=$tableheadimg>$kata3[13]</td><td align=right background=$tabledataimg>$edit_a��</td></tr><tr bgcolor=$datacol><td background=$tableheadimg>$kata3[14]</td><td align=right background=$tabledataimg>$edit_b��</td></tr><tr bgcolor=$datacol><td background=$tableheadimg>$kata3[15]</td><td align=right background=$tabledataimg>$edit_c��</td></tr><tr bgcolor=$datacol><td background=$tableheadimg>$kata3[16]</td><td align=right background=$tabledataimg>$edit_d��</td></tr><tr bgcolor=$datacol><td background=$tableheadimg>$kata3[17]</td><td align=right background=$tabledataimg>$edit_e��</td></tr><tr bgcolor=$datacol><td background=$tableheadimg>$kata3[18]</td><td align=right background=$tabledataimg>$edit_f��</td></tr></table>$tablefuchitag2<br>";
		$abiyasetumei = "1, �Ұ����<a href=$abiya_url target=_$abiya_name>$abiya_name</a> �� ������ �ݿ��˴ϴ�. <br>";
	}

if($ENV{'HTTP_ACCEPT_ENCODING'}=~/gzip/ && $gzipuse){
	print "Content-type: text/html\n";
	print "Content-encoding: gzip\n\n";
	open(STDOUT,"| $gzippass -1 -c");
}else{
	print "Content-type: text/html\n\n";
}

print <<"_HTML1_";
<html><head><title>$title2</title><META HTTP-EQUIV="Content-type" CONTENT="text/html; charset=euc">$style</head>
$body
$menu
$headbanner
<center>
<br>
<img src=\"$title\" width=\"$titlew\" height=\"$titleh\"><br>
<br>
������ ����� $syainsu��<br>$kaisaiinfo
<form action="$cgifile" method="$method">
$tablefuchitag1<table border="1" cellpadding="3" bordercolor=$flamecol bordercolordark=$flamecol bordercolorlight=$flamecol bgcolor=$flamecol>
            <tr bgcolor="$iroformwaku">
              <td> 
                <div align="center">
                  <input type="submit" name="rec" value="$mesrec">
                  <input type="submit" name="rank" value="$mesrank">
                  <input type="submit" name="log" value="$meslog">
                  <input type="button" value="$meshome" onClick="location.href='$url'">
                </div>
              </td></tr></table>$tablefuchitag2
</form>
<table border="0" cellspacing="0" cellpadding="5">
    <tr>
      <td valign="top" align="left">
	$tablefuchitag1<table border="1" cellspacing="1" bgcolor="$flamecol" bordercolor="$flamecol" bordercolordark="$flamecol" bordercolorlight="$flamecol">
      <tr valign="top"> 
        <td bgcolor="$headcol" background=$tableheadimg align=center>�纸��~<b>$syanaihoname</b>~</td>
	  </tr>
	  <tr>
		<td nowrap bgcolor=$datacol style="line-height: 130%">@syanaiho</td>
      </tr>
     </table>$tablefuchitag2
	<br>
	$tablefuchitag1<table border="1" cellspacing="1" bgcolor="$flamecol" bordercolor="$flamecol" bordercolordark="$flamecol" bordercolorlight="$flamecol">
            <tr>
              <td bgcolor="$headcol" background=$tableheadimg align=center>ȸ�� �Ծ�</td>
			  </tr>
			  <tr>
			  <td nowrap bgcolor=$datacol style="line-height: 130%">
1, �� ������ ���ϸ� ����� �⼼��Ű�� �����Դϴ�. <BR>
1, ���Ͽ��� 100����Ʈ�� ��\��ġ�� ����� �ּ���. <BR>
1, �� ��\��ġ�� 5~50�� ���̷� �� �ּ���. <BR>
1, �ұ�Ģ�� 4���� ����� ������ ���۵˴ϴ�. <BR>
1, ����� �ִ�$max_chara�α��� ����� �� �ֽ��ϴ�. <BR>
1, ������ �밳 1��$kaisuȸ���ֵ˴ϴ�. <BR>
1, ȸ�ǿ��� �ǰ� ä��� ����� �����մϴ�. <BR>
1, $teinen���� �Ǹ� �������� �մϴ�. <BR>$abiyahowto$abiyasetumei
              </td>
            </tr>
          </table>$tablefuchitag2
	</td>
      <td valign="top">
	  <table border="0" cellspacing="2">

_HTML1_
open(DB,"$logfile");
seek(DB, 0,0);  @lines = <DB>;  close(DB);
foreach $line (@lines) {
	($no, $name, $sakusya, $homepage, $lif, $pow, $def, $spe, $date, $ip, $win, $plus1, $plus2, $plus3, $plus4, $plus5, $old, $imgtype, $mail, $mailopen, $taisyokumail, $dmy) = split(/<>/, $line);
		if($profileuse){
			local($edname) = &urlencode($sakusya);
			$sakusya = "<a href=\"$profileurl?mode=view&name=$edname\" target=\"_blank\">$sakusya</a> ";
		}
		if($homepage){
			$hp = "[<a href=\"$homepage\">HP</a> ]"
		}else{
			$hp = ""
		}
		if($mail && $mailopen == 1){
			$ml = "[<a href=\"$mail\">ML</a> ]"
		}else{
			$ml = ""
		}

	#������ �ִ� ������ ����
	$winkekka = "$kata2[0]";

	#���� ����
	for ($i=0; $i<50; $i++){
		if($win == $i){
			$winkekka = "$kata2[$i]";
			if($i >= 18){$winkekka = "$kata2[18]";}
			if($win == 0){
				$image = "$imgtype"."/1.gif";
				$backimage = "$imgfld/back1.gif";
			}elsif($win <= 2){
				$image = "$imgtype"."/2.gif";
				$backimage = "$imgfld/back1.gif";
			}elsif($win <= 4){
				$image = "$imgtype"."/3.gif";
				$backimage = "$imgfld/back1.gif";
			}elsif($win <= 7){
				$image = "$imgtype"."/4.gif";
				$backimage = "$imgfld/back1.gif";
			}elsif($win <= 12){
				$image = "$imgtype"."/5.gif";
				$backimage = "$imgfld/back2.gif";
			}elsif($win >= 13){
				$image = "$imgtype"."/6.gif";
				$backimage = "$imgfld/back3.gif";
			}
			$win = $winkekka;
			last;
		}
	}
	if($imgtype =~ /\.gif/ || $imgtype =~ /\.jpg/ || $imgtype =~ /\.png/){$image = $imgtype;}
	print "<tr><td>\n";
	print "<table border=\"0\" cellspacing=\"0\" cellpadding=\"1\" bgcolor=$flamecol><tr><td>\n";
	print "<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" bgcolor=\"#dddddd\"><tr><td valign=\"top\">\n";
	print "<table border=\"0\" cellspacing=\"1\" cellpadding=\"1\" bgcolor=\"#dddddd\"><tr><td>\n";
	print "<table border=\"0\" cellspacing=\"1\" cellpadding=\"1\" width=\"100%\" background=$imgfld/titleback.jpg><tr><td nowrap><font size=\"2\" color=\"#ffffff\"><b>$name</b></font></td></tr></table>\n";
	print "<table border=\"0\" cellspacing=\"1\" cellpadding=\"1\" width=\"100%\"><tr><td nowrap><font size=\"2\" face=\"MS ����\" style=\"line-height: 100%\">$tablelif<br>$tablepow<br>����<br>����<br>��� No<br>�Ի���</td><td nowrap><div align=\"right\"><font size=\"2\" face=\"MS ����\" style=\"line-height: 100%\">$lifP<br>$powP<br>$old��<br>$win<br>$no<br>$date</div></td></tr></table>\n";
	print "<div align=\"right\"><font size=\"2\" style=\"line-height: 100%\">by $sakusya $hp $ml</font></div></td></tr></table>\n";

	print "</td><td bgcolor=\"#ffffff\" background=\"$backimage\" valign=\"bottom\" width=\"84\"><div align=\"center\">";
	$imagetag = "<img src=$image width=82 height=78>";
	$imagetag1 = "";
	$imagetag2 = "";
	$shiwaimagetag = "";

	if(($old > 34)&&($imgtype !~ /\.gif/)&&($ENV{'HTTP_USER_AGENT'} =~ /(. +)\/(\d)\. (\d+). *compatible\; MSIE (\d)\. (\d+)/)){
		$aposision = 25;
		$bposision = 5;
		if($imgtype =~ /violet/){$bposision = $bposision+5;}
		if(($imgtype =~ /brown/)&&($image =~ /3/)){$bposision = $bposision-4;}
		$shiwaimagetag = "<span id=Layer$i style=\"width:3px; height:3px; position:relative; z-index:1; left: $bposision px; top: $aposision px\"><img src=$imgfld/shiwa.gif width=3 height=3></span>";
		$imagetag1 = "<span id=Layer$i style=\"width:82px; height:78px; position: relative; z-index:0; left: 0px; top: 0px\">";
		$imagetag2 = "</span>";
		$i++;
	}
	print "$shiwaimagetag$imagetag1$imagetag$imagetag2";
	print "</div></td></tr></table>\n";
	print "</td></tr></table>\n";

}

	&get_cookie;
print <<"_HTML2_";

        </td></tr></table>
      </td>
    </tr>
  </table>
  <br>
</center>
<div align="center">
<form action="$cgifile" method="$method">
$tablefuchitag1<table border="1" cellpadding="3" bordercolor=$flamecol bordercolordark=$flamecol bordercolorlight=$flamecol bgcolor=$flamecol>
            <tr bgcolor="$iroformwaku">
              <td> 
                <div align="center">
                  <input type="submit" name="rec" value="$mesrec">
                  <input type="submit" name="rank" value="$mesrank">
                  <input type="submit" name="log" value="$meslog">
                  <input type="button" value="$meshome" onClick="location.href='$url'">
                </div>
              </td></tr></table>$tablefuchitag2
</form>
<form action="$cgifile" method="$method">
$tablefuchitag1<table border="1" cellpadding="3" bordercolor="$flamecol" bordercolordark="$flamecol" bordercolorlight="$flamecol" bgcolor="$flamecol">
            <tr bgcolor="$iroformwaku">
              <td nowrap> 
�̸�<input type="text" name="name" size="15" value="$COOKIE{'name'}">
�н�����<input type="password" name="pass" size="8" value="$COOKIE{'entrypass'}"><input type="submit" value="��� ����">
              </td></tr></table>$tablefuchitag2
</form>
$footbanner

_HTML2_

&chosaku;
}#end html



##### ĳ���� ��� ���
sub rec{

if($recflag == 1){

	if(($profileuse)&&($profilemust)){#������ CGI�� �н��� �д´�
		open(PROFILE,"$profiledata") ;@prof = @LIST = <PROFILE>;close(PROFILE);

		$prozumi=0;
		for ($pri=0; $pri<$#prof+1; $pri++){
			$prof[$pri] =~ s/\x0D? \x0A? $//;
			if ($prof[$pri] =~ /^1\:\@\Q$formname\E\:\@/){
				@data_1 = split(/\:\@/, $prof[$pri]);
				if("$formname" eq "$data_1[1]"){
					$prozumi = 1;
					if("$formentrypass" eq "$data_1[2]"){

						if($profilelastuse){#��Ʈ ���� �ð��� �����ʿ� ���
							$lastuse = time();# �ʽð��� ���
							$prokakiko = "1\:\@";
							for($iii=0;$iii<=17;$iii++){
								$data_1[$iii] =~ s/\s*$//;
							}
							for($iii=1;$iii<=$#data_1;$iii++){
								if($iii == 11){
									$prokakiko = "$prokakiko". "$lastuse\:\@";
								}else{
									$prokakiko = "$prokakiko". "$data_1[$iii]\:\@";
								}
							}
							$prokakiko = "$prokakiko". "\n";

							local($md)=@_;

							@OLD=();

							if($profilefilelockuse == 1){
								$tlockretry = $abiyalockretry;
								$abiyalockretry = $profilelockretry;
								$tlockfile = $abiyalockfile;
								$abiyalockfile = $profilelockfile;
								&abiyalock;
							}
							open(DATA,">$profiledata") || die("can't open DAT $profiledata:$! \n");

							local($com) = 0;
							local($hit) = 0;
							local($del_memb);
							foreach $line (@LIST){
								if ($line =~ /^1\:\@\Q$formname\E\:\@$formentrypass\:\@/){
									$hit=1;
									$del_memb = $line;
									push(@OLD, $line);
									print DATA $prokakiko;
								}elsif ($line =~ /^3\:\@\Q$formname\E\:\@/){
									push(@OLD, $line);
									print DATA $line;
								}elsif ($line =~ /^2\:\@\Q$formname\E\:\@/){
									push(@OLD, $line);
									$com = 1;
									print DATA $line;
								}elsif ($com == 1 && $line =~ /^end/){
									push(@OLD, $line);
									$com = 0;
									print DATA $line;
								}elsif ($com == 1){
									push(@OLD, $line);
									print DATA $line;
								}elsif ($line =~ /^1\:\@\Q$formname\E\:\@/){
									push(@OLD, $line);
									print DATA $line;
								} else {
									print DATA $line;
								}
							}
							close(DATA);
							if($profilefilelockuse ==1){
								if (-e, $abiyalockfile){unlink($abiyalockfile);}
								$abiyalockretry = $tlockretry;
								$abiyalockfile = $tlockfile;
							}
						}

					}else{
						&error(8);
					}
					last;
				}
			}
		}
		if($profilemust == 1 && $prozumi != 1){
			&error(9);
		}
	}

if($ENV{'HTTP_ACCEPT_ENCODING'}=~/gzip/ && $gzipuse){
	print "Content-type: text/html\n";
	print "Content-encoding: gzip\n\n";
	open(STDOUT,"| $gzippass -1 -c");
}else{
	print "Content-type: text/html\n\n";
}
	if($formimg =~ /\.gif/ || $formimg =~ /\.jpg/ || $formimg =~ /\.png/){
		$image = $formimg;
	}else{
		$image = "$formimg/1.gif";
	}

	print <<"_HTML_";
<html>
<head>
<title>$title2</title>
<META HTTP-EQUIV="Content-type" CONTENT="text/html; charset=euc">
$style
</head>
$body
$menu
<center><br>
<img src=\"$title\" width=\"$titlew\" height=\"$titleh\"><br>
<br>
$mesrec<br>
<br>
�� �������� Ʋ�����°� Ȯ�� ��Ź�մϴ�. <br>
<br>
<form action="$cgifile" method="$method">
$tablefuchitag1<table border="1" cellspacing="1" bgcolor="$flamecol" bordercolor="$flamecol" bordercolordark="$flamecol" bordercolorlight="$flamecol" width="400"><tr><td bgcolor="#ffffff">

<center><table widtn="100%"><tr><td valign="bottom" bgcolor="#ffffff"><center>�̷¼�</center><br>
<center><table border="1" cellspacing="0" bgcolor="$flamecol" bordercolor="$flamecol" bordercolordark="$flamecol" bordercolorlight="$flamecol">
<tr><td bgcolor="#ffffff">�������� �̹���
      <table align="center" width=82 height=78>
	   <tr>
	    <td align="center" background=$imgfld/back1.gif valign="bottom">
		 <img src=$image width="82" height="78">
		</td>
	   </tr>
	  </table>
</center>
</td>
</tr>
</table><br>
<table border="1" cellspacing="0" width="100%" bgcolor="$flamecol" bordercolor="$flamecol" bordercolordark="$flamecol" bordercolorlight="$flamecol">
<tr><td bgcolor="#ffffff" nowrap>������ �̸���$formchara</td>
<td bgcolor="#ffffff" nowrap>����� �̸���$formname</td></tr>
</table>
</td>
</tr>
<tr>
<td colspan="2">
<table border="1" cellspacing="0" width="100%" bgcolor="$flamecol" bordercolor="$flamecol" bordercolordark="$flamecol" bordercolorlight="$flamecol">
<tr>
	<td bgcolor="#ffffff" style="line-height: 130%">���� �ּң�$formmail<br>
_HTML_
	if($formmailopen){
		print "���� ����<br>";
	}else{
		print "���� �����<br>";
	}
	if($formtaisyokumail >= 1){
		print "�����ϸ� ���Ϸ� �ҽ�<br>";
	}else{
		print "�����ϸ� ���Ϸ� �˷� ���� �ʴ´�<br>";
	}
print <<"_HTML_";

</td><tr><td bgcolor="#ffffff">Ȩ ��������$formhp</td></tr></table>
</td></tr><tr><td colspan="2">
<table border="1" cellspacing="0" width="100%" bgcolor="$flamecol"
bordercolor="$flamecol" bordercolordark="$flamecol"
bordercolorlight="$flamecol">
<tr><td bgcolor="#ffffff" style="line-height: 130%">
������ ��<BR>
$tablelif��$formlif<br>
$tablepow��$formpow<br>
$tabledef��$formdef<br>
$tablespe��$formspe<br>
</td></tr></table>
</td></tr><tr><td colspan="2">
<table border="1" cellspacing="0" width="100%" bgcolor="$flamecol" bordercolor="$flamecol" bordercolordark="$flamecol" bordercolorlight="$flamecol"><tr><td bgcolor="#ffffff" style="line-height: 130%" nowrap>
������ Ư¡<br>
�ٸ� �ǰ��� ������ ���� ���<br>
<font color="$colserifu"><B>$formchara</B></font>��$form{'plus1'}��<br>
���ǿ� ���ؼ� �ݷ��� ���� ���<br>
<font color="$colserifu"><B>$formchara</B></font>��$form{'plus2'}��<br>
�ǰ� ä��Ǿ��� ���� ���<br>
<font color="$colserifu"><B>$formchara</B></font>��$form{'plus3'}��<br>
������ �Ҿ��� ���� ���<br>
<font color="$colserifu"><B>$formchara</B></font>��$form{'plus4'}��<br>
ȹ���� ������ ���� ���� ���<br>
<font color="$colserifu"><B>$formchara</B></font>��$form{'plus5'}��<br>
</td></tr></table>
</td></tr></table>
<input type="hidden" name="rec" value="2">
<input type="hidden" name="chara" value="$formchara">
<input type="hidden" name="name" value="$formname">
<input type="hidden" name="entrypass" value="$formentrypass">
<input type="hidden" name="hp" value="$formhp">
<input type="hidden" name="mail" value="$formmail">
<input type="hidden" name="mailopen" value="$formmailopen">
<input type="hidden" name="taisyokumail" value="$formtaisyokumail">
<input type="hidden" name="life" value="$formlif">
<input type="hidden" name="speed" value="$formspe">
<input type="hidden" name="defence" value="$formdef">
<input type="hidden" name="power" value="$formpow">
<input type="hidden" name="img" value="$formimg">
<input type="hidden" name="plus1" value="$form{'plus1'}">
<input type="hidden" name="plus2" value="$form{'plus2'}">
<input type="hidden" name="plus3" value="$form{'plus3'}">
<input type="hidden" name="plus4" value="$form{'plus4'}">
<input type="hidden" name="plus5" value="$form{'plus5'}">
<div align="center"><input type="submit" value="�̰����� OK! "></div>
</td></tr>
</table>$tablefuchitag2
</form>

</P>

_HTML_

}elsif($form{'rec'} == 2){

if($syainsu >= $max_chara){&error(0);}

# ������ �Űܳ��´�
	$formchara = $form{'chara'};
	$formname = $form{'name'};
	$formentrypass = $form{'entrypass'};
	$formhp = $form{'hp'};
	$formmail = $form{'mail'};
	$formlif = $form{'life'};
	$formpow = $form{'power'};
	$formdef = $form{'defence'};
	$formspe = $form{'speed'};
	if($form{'imode'} eq "f"){
		$formimg = $form{'ficon'};
	}else{
		$formimg = $form{'img'};
	}
	
# �ɷ�ġ üũ
	if(($formlif >50)||($formlif < 5)){&error(1)};
	if(($formpow >50)||($formpow < 5)){&error(1)};
	if(($formdef >50)||($formdef < 5)){&error(1)};
	if(($formspe >50)||($formspe < 5)){&error(1)};
	$total = $formlif + $formpow + $formdef + $formspe ;
	if($total ne 100){&error(2)};

# �̸��� ���� üũ
	if((length($formchara) < 1)||(length($formchara) > $nameleng *2)){&error(3)};
	if((length($formname) < 1)||(length($formname) > $nameleng *2)){&error(3)};
	if($formhp =~ /http/){
		($formhp =~ /^http:\/\/[a-zA-Z0-9]+/) || ($formhp = '');	#HP�� ����
	}else{
		$formhp = '';
	}
	if($formmail =~ /@/){
		if($formmail !~ /mailto/){
			$formmail = "mailto:$formmail"
		}
		$formmailopen  = $form{'mailopen'};
		$formtaisyokumail  = $form{'taisyokumail'};
	}else{
		$formmail = '';
		$formmailopen  = 0;
		$formtaisyokumail  = 0;
	}

# ����Ʈ ȣ��Ʈ ���
	$host = $ENV{'REMOTE_HOST'} || $ENV{'REMOTE_ADDR'};
	if($doubleentry == 1){
		@checkip = split(/<>/, $lines[$#lines]);
		if($host eq $checkip[9]){&error(4);} 
	}elsif($doubleentry == 2){
		for ($i=0; $i<$#lines +1; $i++){
			@checkip = split(/<>/, $lines[$i]);
			if($host eq $checkip[9]){&error(7);} #IP�ּҿ����� ��
			if($formname eq $checkip[2]){&error(7);} #�̸������� ��
		}
	}

# ĳ���� ��� �ѹ�

#��� ��ȣ�� ���ĸ� �����Ѵ�
	open(DBTMP,"$logfile");
	seek(DBTMP, 0,0);  @linestmp = <DBTMP>;  close(DBTMP);
	foreach $i (0..(@linestmp-1)) {
	@Buftmp = split('<>', @linestmp[$i]);
	$SDatatmp{$i} = $Buftmp[0];
	}

	@SortDatatmp = sort {($SDatatmp{$b} <=> $SDatatmp{$a}) || ($b cmp $a)} keys(%SDatatmp);

	$lno = $linestmp[$SortDatatmp[0]] +1;

# ��Ͻð�
	$year += 1900;
	$month = sprintf("%02d", $mon +1);
	$mday = sprintf("%02d", $mday);
	$hour = sprintf("%02d", $hour);
	$min = sprintf("%02d", $min);
	$sec = sprintf("%02d", $sec);
	$jikan = "$month/$mday $hour:$min";
	

# ����� ó��

	if($form{'plus1'}){$formplus1 = qq|<font color="$colserifu"><B>$formchara</B></font>��$form{'plus1'}��<BR>|;}
	if($form{'plus2'}){$formplus2 = qq|<font color="$colserifu"><B>$formchara</B></font>��$form{'plus2'}��<BR>|;}
	if($form{'plus3'}){$formplus3 = qq|<BR><font color="$colserifu"><B>$formchara</B></font>��$form{'plus3'}��|;}
	if($form{'plus4'}){$formplus4 = qq|<font color="$colserifu"><B>$formchara</B></font>��$form{'plus4'}��<BR>|;}
	if($form{'plus5'}){$formplus5 = qq|<font color="$colserifu"><B>$formchara</B></font>��$form{'plus5'}��<BR>|;}

	$hantei = "$form{'chara'}_$form{'plus1'}-$form{'plus2'}_$form{'plus3'}-$form{'plus4'}_$form{'plus5'}_$form{'hp'}_in_vbonline";
	$blname = "$form{'name'}";
	&autobl;

# �α׿� �����ϴ� ��Ÿ���� ����
	$formtaisyokumail =~ s/\s*$//;
	$kakiko = "$lno<>$formchara<>$formname<>$formhp<>$formlif<>$formpow<>$formdef<>$formspe<>$jikan<>$host<><>$formplus1<>$formplus2<>$formplus3<>$formplus4<>$formplus5<>22<>$formimg<>$formmail<>$formmailopen<>$formtaisyokumail<>$formentrypass<>\n";

# �α׿��� ������
#BL�� �Ǹ��� ������ ��� �㰡
if($addbl != 1){

# �α׿��� ������
	open(DB,">>$logfile") ;
		eval 'flock(DB, 2);';
		print DB $kakiko;
		eval 'flock(DB, 8);';
	close(DB);
push(@lines, $kakiko);

# �纸�� �����ϴ� ��Ÿ���� ����
	$whatnew = "$jikan $formchara���� <font color=blue>�Ի�</font>�Ǿ����ϴ�. <br>\n";
	
# �纸���� ������
	open(BOOK,"$whatnewfile");
	seek(BOOK, 0,0);  @syanaiho = <BOOK>;  close(BOOK);

	unshift (@syanaiho , join('' , $whatnew));
	splice( @syanaiho, $max_syanaiho);

	open(BOOK,">$whatnewfile") ;
		eval 'flock(BOOK, 2);';
		print BOOK @syanaiho;
		eval 'flock(BOOK, 8);';
	close(BOOK);

}

if($ENV{'HTTP_ACCEPT_ENCODING'}=~/gzip/ && $gzipuse){
	print "Content-type: text/html\n";
	print "Content-encoding: gzip\n\n";
	open(STDOUT,"| $gzippass -1 -c");
}else{
	print "Content-type: text/html\n\n";
}
print <<"_HTML1_";

<html><head><title>$title2</title><META HTTP-EQUIV="Content-type" CONTENT="text/html; charset=euc">
$style
</head>
$body
$menu
<center>
<br>
<img src=\"$title\" width=\"$titlew\" height=\"$titleh\"><br>
<br>
�Ի� ������ �Ϸ��߽��ϴ�. <br>
���ϰ� �⼼�� ���� ������ ���, ���� ���� �� �ּ���. <br>
<br>
$mesrec

_HTML1_

}else{

	&get_cookie;

	$imageselect1 = "<select name=\"img\">";
	foreach (0 .. $#imgfile) {
		$tmpimg = "$imgchara/$imgfile[$_]";
		if("$COOKIE{'img'}" eq "$tmpimg") {
			$imageselect1 = "$imageselect1". "<option value=\"$tmpimg\" selected>$imgname[$_]";
			$facehit = 1;
		}else{
			$imageselect1 = "$imageselect1". "<option value=\"$tmpimg\">$imgname[$_]";
		}
	}
	$imageselect1 = "$imageselect1". "</select>";

	if($COOKIE{'img'} && ! $facehit){
		$imgval = "$COOKIE{'img'}";
		$bck = "checked";
		$cimg = "<img src=\"$COOKIE{'img'}\" width=\"82\" height=\"78\" alt=\"\">"
	}else{
		$imgval = 'http://****.gif';
		$ack = "checked";
	}

	if($ENV{'HTTP_ACCEPT_ENCODING'}=~/gzip/ && $gzipuse){
		print "Content-type: text/html\n";
		print "Content-encoding: gzip\n\n";
		open(STDOUT,"| $gzippass -1 -c");
	}else{
		print "Content-type: text/html\n\n";
	}
	print <<"_HTML_";
<html><head><title>$title2</title><META HTTP-EQUIV="Content-type" CONTENT="text/html; charset=euc">
$style
<script language='JavaScript'>
<!--
function checkurl(){
window.open(document.M.ficon.value,"URLCHECK");
}
//-->
</script></head>
$body
$menu
<center>
<br>
<img src=\"$title\" width=\"$titlew\" height=\"$titleh\"><br>
<br>
<form action="$cgifile" method="$method" name="M">
$tablefuchitag1<table border="1" cellspacing="1" cellpadding="5" bgcolor="$flamecol" bordercolor="$flamecol" bordercolordark="$flamecol" bordercolorlight="$flamecol" width="300"><tr><td bgcolor="#ffffff" align="center">

�̷¼�<br>
<table border="1" cellspacing="0" cellpadding="5" bgcolor="$flamecol" bordercolor="$flamecol" bordercolordark="$flamecol" bordercolorlight="$flamecol">
<tr><td bgcolor="#ffffff">�������� ��
<table><tr><td nowrap valign="top"><input type=radio name=imode value='n' $ack>ǥ�� �̹���</td>
<td>
$imageselect1 [<a href="$cgifile?mode=imagevw" target="_blank">ȭ�� �̹��� ����</a> ]</td></tr>
<tr>
<td nowrap valign="top"><input type=radio name=imode value='f' $bck>���� �̹���<br>$cimg</td><td valign="top"><input type=text name=ficon size=50 value="$imgval"><input type="button" value="URLȮ��" onClick="checkurl()"><br>
[<a href="http://www.abi-station.com/icon/make/imagemake.cgi" target="imagelist">������ ����</a> ]���֣�������� 82��78
</td>
</tr>
</table>
<br>
</td>
</tr>
</table><br>
<table border="1" cellspacing="0" cellpadding="5" width="100%" bgcolor="$flamecol" bordercolor="$flamecol" bordercolordark="$flamecol" bordercolorlight="$flamecol">
<tr><td bgcolor="#ffffff" nowrap>������ �̸�($nameleng �ڱ���)<BR><input type="text" name="chara" size="15" value="$COOKIE{'chara'}"></td>
<td bgcolor="#ffffff" nowrap>����� �̸�($nameleng �ڱ���)<BR><input type="text" name="name" size="15" value="$COOKIE{'name'}"></td></tr>
<tr><td colspan="2" bgcolor="#ffffff">
�н�����<input type="password" name="entrypass" size="8" value="$COOKIE{'entrypass'}"> ������ ����մϴ�
</td></tr>
</table>
<br>
<table border="1" cellspacing="0" cellpadding="5" width="100%" bgcolor="$flamecol" bordercolor="$flamecol" bordercolordark="$flamecol" bordercolorlight="$flamecol">
<tr>
	<td bgcolor="#ffffff">���� �ּ�<br>
	<input type="text" name="mail" size="60" value="$COOKIE{'mail'}"><br>
_HTML_
	if($COOKIE{'mailopen'} == 1){$a = "checked";}else{$a = "";}
	print "<input type=checkbox name=mailopen value=1 checked $a>üũ�ϸ� ���� ����";
	if($sendmail){
		if($COOKIE{'taisyokumail'} == 1){$a = "checked";}else{$a = "";}
		print "<br><input type=checkbox name=taisyokumail value=1 checked $a>�����ϸ� ���Ϸ� �ҽ�";
	}
print <<"_HTML_";

</td><tr><td bgcolor="#ffffff">Ȩ ������(�ִٸ�)<BR><input type="text" name="hp" size="60" value="$COOKIE{'hp'}"></td></tr></table>
<br>
<table border="1" cellspacing="0" cellpadding="5" width="100%" bgcolor="$flamecol" bordercolor="$flamecol" bordercolordark="$flamecol" bordercolorlight="$flamecol">
<tr><td bgcolor="#ffffff">
������ ��(�հ� 100�� �ǵ��� ����� �ּ���)<BR>
<input type="text" name="life" size="5" value="$COOKIE{'life'}">��$tablelif(5~50)<BR>
<input type="text" name="power" size="5" value="$COOKIE{'power'}">��$tablepow(5~50)<BR>
<input type="text" name="defence" size="5" value="$COOKIE{'defence'}">��$tabledef(5~50)<BR>
<input type="text" name="speed" size="5" value="$COOKIE{'speed'}">��$tablespe(5~50)<BR>
</font>
</td></tr></table>
<br>
<table border="1" cellspacing="0" cellpadding="5" width="100%" bgcolor="$flamecol" bordercolor="$flamecol" bordercolordark="$flamecol" bordercolorlight="$flamecol">
$formplus</table>
<br>
<input type="submit" value="���">
</td></tr>
</table>$tablefuchitag2
<input type="hidden" name="record" value="1">
</form>

</P>

_HTML_
}

# ǥ�� �̹���
#
sub imagevw {

if($ENV{'HTTP_ACCEPT_ENCODING'}=~/gzip/ && $gzipuse){
	print "Content-type: text/html\n";
	print "Content-encoding: gzip\n\n";
	open(STDOUT,"| $gzippass -1 -c");
}else{
	print "Content-type: text/html\n\n";
}
	print <<"EOM";
<html lang="ja"><head>
<meta http-equiv="Content-Type" content="text/html; charset=euc">
<title>ǥ�� �̹��� ȭ�� �϶�</title>
<meta http-equiv="Content-Style-Type" content="text/css">
$style
</head>
$body
$menu
EOM
	print "<center><hr size=1 width=70%>";
	print "<big>ǥ�� �̹��� ȭ�� �϶�</big><br><br>";
	print "<hr size=1 width=70%><br>";
	print "$tablefuchitag1<table border=2 cellpadding=2 cellspacing=0 bordercolor=$flamecol bordercolordark=$flamecol bordercolorlight=$flamecol bgcolor=$datacol><tr>";
	$i=0; $j=0;
	$stop = @imgfile;
	foreach (0 .. $#imgfile) {
		$i++; $j++;
		print "<td align=center background=$tabledataimg2><img src=\"$imgchara/$imgfile[$_]/1.gif\" align=middle onmousedown=\"alert('ī������ �ʵ���! ');\"><br>$imgname[$_]</td>";
		if ($i >= 6) { print "</tr><tr>"; $i=0; }
		if ($j eq "$stop") {
			if ($i == 0) { last; }
			while ($i < 6) { print "<td><br></td>"; $i++; }
		}
	}
	print "</tr></table>$tablefuchitag2<table width=95% border=0 cellpadding=1 cellspacing=0>";
	print "<tr><td nowrap align=center width=100%>(C) 2001 <a href=http://members8.cool.ne.jp/~yurix/ target=_blank>���� ��</a>  / (C) 2001 <a href=http://www.abi-station.com/ target=_blank>Abi-Station</a> </td>";
	$i=0; $j=0;
	print "</tr></table><br><input type='button' value=\"  �ݴ´�  \" onClick='top.close();'></center>";
	print "</body></html>\n";
	if($filelockuse ==1){if (-e, $lockfile){unlink($lockfile);}}
	exit;
}

sub set_cookie {
	local(@mon, @week, $gmt, $cook);
	local($sec, $min, $hour, $mday, $mon, $year, $wday) = gmtime(time + 60*24*60*60);
	@mon  = ('Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec');
	@week = ('Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat');

	$gmt = sprintf("%s, %02d-%s-%04d %02d:%02d:%02d GMT",
			$week[$wday], $mday, $mon[$mon], $year+1900, $hour, $min, $sec);
	$cook="charaa<>$form{'chara'}<>namea<>$form{'name'}<>imga<>$formimg<>sexa<>$form{'sex'}<>olda<>$form{'old'}<>joba<>$form{'job'}<>entrypassa<>$form{'entrypass'}<>hpa<>$form{'hp'}<>maila<>$form{'mail'}<>mailopena<>$form{'mailopen'}<>taisyokumaila<>$form{'taisyokumailmail'}<>sendstorya<>$form{'sendstory'}<>lifea<>$form{'life'}<>powera<>$form{'power'}<>defencea<>$form{'defence'}<>speeda<>$form{'speed'}<>jikana<>$jikan<>hosta<>$host<>plus1a<>$form{'plus1'}<>plus2a<>$form{'plus2'}<>plus3a<>$form{'plus3'}<>plus4a<>$form{'plus4'}<>plus5a<>$form{'plus5'}<>reload<>$reload";
	print "Set-Cookie: $cookname=$cook; expires=$gmt\n";
}

sub get_cookie {
	local($key, $val, @cook, %tmp);
	@cook = split(/;/, $ENV{'HTTP_COOKIE'});
	foreach (@cook) {
		($key, $val) = split(/=/);
		$key =~ s/\s//g;
		$tmp{$key} = $val;
	}
	%ck = split(/<>/, $tmp{"$cookname"});
    $COOKIE{chara} = $ck{'charaa'};
    $COOKIE{name} = $ck{'namea'};
    $COOKIE{img} = $ck{'imga'};
    $COOKIE{sex} = $ck{'sexa'};
    $COOKIE{old} = $ck{'olda'};
    $COOKIE{job} = $ck{'joba'};
    $COOKIE{entrypass} = $ck{'entrypassa'};
    $COOKIE{hp} = $ck{'hpa'};
    $COOKIE{mail} = $ck{'maila'};
    $COOKIE{mailopen} = $ck{'mailopena'};
    $COOKIE{taisyokumail} = $ck{'taisyokumaila'};
    $COOKIE{sendstory} = $ck{'sendstorya'};
    $COOKIE{life} = $ck{'lifea'};
    $COOKIE{power} = $ck{'powera'};
    $COOKIE{defence} = $ck{'defencea'};
    $COOKIE{speed} = $ck{'speeda'};
    $COOKIE{reload} = $ck{'reload'};
}

print <<"_HTML4_";
<P>
$tablefuchitag1<table border="1" cellspacing="1" width="$ysize" bgcolor=$flamecol bordercolor=$flamecol bordercolordark=$flamecol bordercolorlight=$flamecol>
<tr bgcolor=$headcol nowrap><td align=center background=$tableheadimg nowrap>����</td><td align=center background=$tableheadimg nowrap>$tableno</td><td align=center background=$tableheadimg nowrap>$tableold</td><td align=center background=$tableheadimg nowrap>$tablenam</td><td align=center background=$tableheadimg nowrap>$tableaut</td><td align=center background=$tableheadimg nowrap>$tablelif</td><td align=center background=$tableheadimg nowrap>$tablepow</td><td align=center background=$tableheadimg nowrap>$tabledat</td></tr>

_HTML4_


foreach $line (@lines) {
	($no, $name, $sakusya, $homepage, $lif, $pow, $def, $spe, $date, $ip, $win, $plus1, $plus2, $plus3, $plus4, $plus5, $old, $imgtype, $mail, $mailopen, $taisyokumail, $dmy) = split(/<>/, $line);

		if($profileuse){
			local($edname) = &urlencode($sakusya);
			$sakusya = "<a href=\"$profileurl?mode=view&name=$edname\" target=\"_blank\">$sakusya</a> ";
		}
		if($homepage){
			$hp = "[<a href=\"$homepage\">HP</a> ]"
		}else{
			$hp = ""
		}
		$mail =~ s/\s*$//;
		if($mail && $mailopen == 1){
			$ml = "[<a href=\"$mail\">ML</a> ]"
		}else{
			$ml = ""
		}

	if($homepage){$sakusya = "<a href=\"$homepage\">$sakusya</a> "}
	#���� ����
	for ($i=0; $i<50; $i++){
		if($win == $i){
			$win = "$kata2[$i]";
			if($i >= 18){$win = "$kata2[18]";}
			last;
		}
	}

	print "<tr bgcolor=$datacol><td background=$tabledataimg nowrap>$win</td><td align=right background=$tabledataimg>$no</td><td align=right background=$tabledataimg>$old</td><td nowrap background=$tabledataimg>$name</td><td nowrap background=$tabledataimg>$sakusya $hp $ml</td><td align=right background=$tabledataimg>$lif</td><td align=right background=$tabledataimg>$pow</td><td align=center background=$tabledataimg nowrap>$date</td></tr>";
	}


print <<"_HTML2_";
</table>$tablefuchitag2
</P>
</center>
<div align="center">
$tablefuchitag1<form action="$cgifile" method="$method">
<table border="1" cellpadding="3" bordercolor=$flamecol bordercolordark=$flamecol bordercolorlight=$flamecol bgcolor=$flamecol>
<tr><td bgcolor="$iroformwaku">
<input type="submit" value="$mestop">
<input type="submit" name="rank" value="$mesrank">
<input type="submit" name="log" value="$meslog">
<input type="button" value="$meshome" onClick="location.href='$url'">
</td></tr></table>$tablefuchitag2
</form>
_HTML2_
&chosaku;
}#end rec


##### ��ŷ ���
sub rank{

if($ENV{'HTTP_ACCEPT_ENCODING'}=~/gzip/ && $gzipuse){
	print "Content-type: text/html\n";
	print "Content-encoding: gzip\n\n";
	open(STDOUT,"| $gzippass -1 -c");
}else{
	print "Content-type: text/html\n\n";
}

print <<"_HTML1_";
<html><head><title>$title2</title><META HTTP-EQUIV="Content-type" CONTENT="text/html; charset=euc">$style</head>
$body
$menu
<center>
<img src=\"$title\" width=\"$titlew\" height=\"$titleh\"><br>
$mesrank

$tablefuchitag1<table border="1" cellspacing="1" width="$ysize" bgcolor=$flamecol bordercolor=$flamecol bordercolordark=$flamecol bordercolorlight=$flamecol>
<tr bgcolor=$headcol nowrap><td align=center background=$tableheadimg nowrap>����</td><td align=center background=$tableheadimg>�̹���</td><td align=center background=$tableheadimg nowrap>$tableno</td><td align=center background=$tableheadimg nowrap>$tableold</td><td align=center background=$tableheadimg nowrap>$tablenam</td><td align=center background=$tableheadimg nowrap>$tableaut</td><td align=center background=$tableheadimg nowrap>$tablelif</td><td align=center background=$tableheadimg nowrap>$tablepow</td><td align=center background=$tableheadimg nowrap>$tabledat</td></tr>

_HTML1_

	open(RK,"$rankfile");
	seek(RK, 0,0);  @ranks = <RK>;  close(RK);
	

foreach $rank (@ranks) {
	($no, $name, $sakusya, $homepage, $lif, $pow, $def, $spe, $date, $ip, $win, $plus1, $plus2, $plus3, $plus4, $plus5, $old, $imgtype, $mail, $mailopen, $taisyokumail, $dmy) = split(/<>/, $rank);
		if($profileuse){
			local($edname) = &urlencode($sakusya);
			$sakusya = "<a href=\"$profileurl?mode=view&name=$edname\">$sakusya</a> ";
		}
		if($homepage){
			$hp = "[<a href=\"$homepage\">HP</a> ]"
		}else{
			$hp = ""
		}
		$mail =~ s/\s*$//;
		if($mail && $mailopen == 1){
			$ml = "[<a href=\"$mail\">ML</a> ]"
		}else{
			$ml = ""
		}
	#���� ����
	for ($i=0; $i<50; $i++){
		if($win == $i){
			$winkekka = "$kata2[$i]";
			if($i >= 18){$winkekka = "$kata2[18]";}
			if($win == 0){
				$image = "$imgtype"."/1.gif";
			}elsif($win <= 2){
				$image = "$imgtype"."/2.gif";
			}elsif($win <= 4){
				$image = "$imgtype"."/3.gif";
			}elsif($win <= 7){
				$image = "$imgtype"."/4.gif";
			}elsif($win <= 12){
				$image = "$imgtype"."/5.gif";
			}elsif($win >= 13){
				$image = "$imgtype"."/6.gif";
			}
			$win = $winkekka;
			last;
		}
	}
	if($imgtype =~ /\.gif/ || $imgtype =~ /\.jpg/ || $imgtype =~ /\.png/){$image = $imgtype;}
	print "<tr bgcolor=$datacol><td background=$tabledataimg2 nowrap>$win</td><td align=center background=$tabledataimg2><img src=$image width=82 height=78></td><td align=right background=$tabledataimg2>$no</td><td align=right background=$tabledataimg2>$old</td><td nowrap background=$tabledataimg2>$name</td><td nowrap background=$tabledataimg2>$sakusya $hp $ml</td><td align=right background=$tabledataimg2>$lif</td><td align=right background=$tabledataimg2>$pow</td><td align=center background=$tabledataimg2>$date</td></tr>";

	}

print <<"_HTML2_";
</table>$tablefuchitag2
</center>
<div align="center">
<form action="$cgifile" method="$method">
$tablefuchitag1<table border="1" cellpadding="3" bordercolor=$flamecol bordercolordark=$flamecol bordercolorlight=$flamecol bgcolor=$flamecol>
<tr><td bgcolor="$iroformwaku">
<input type="submit" value="$mestop">
<input type="submit" name="rec" value="$mesrec">
<input type="submit" name="log" value="$meslog">
<input type="button" value="$meshome" onClick="location.href='$url'">
</td></tr></table>$tablefuchitag2
</form>
_HTML2_
&chosaku;
}#end rank


##### ȸ�Ƿ�
sub log{

if($ENV{'HTTP_ACCEPT_ENCODING'}=~/gzip/ && $gzipuse){
	print "Content-type: text/html\n";
	print "Content-encoding: gzip\n\n";
	open(STDOUT,"| $gzippass -1 -c");
}else{
	print "Content-type: text/html\n\n";
}

print <<"_HTML1_";
<html><head><title>$title2</title><META HTTP-EQUIV="Content-type" CONTENT="text/html; charset=euc">$style</head>
$body
$menu
<div align="center">
<img src=\"$title\" width=\"$titlew\" height=\"$titleh\"><br>
<table border="0" cellspacing="0" cellpadding="0">

_HTML1_

	open(FG,"$fightfile");
	seek(FG, 0,0);  @fg = <FG>;  close(FG);

	for ($i=0 ; $i<$max_fight ; $i++){
	$fgno = $i +1;
	
	if($fg[$i]){
	($time , $name , $fight) = split(/<>/, $fg[$i]);
	print "      <td background=\"$imgfld/gjback2.gif\">��</td>
      <td background=\"$imgfld/gjback1.gif\"><font size=\"-1\"><a href=\"$cgifile?no=$fgno\">$time</a> <br>[$name]</font></td>
      <td background=\"$imgfld/gjback3.gif\">��</td>
    </tr>\n";
	}
	}

print <<"_HTML2_";
  <tr> 
    <td><img src="$imgfld/gjback4.gif" width="20" height="64"></td>
    <td background="$imgfld/gjback5.gif">
      <div align="center"><font color="#FFFFFF" size="4">���� ���� ȸ�Ƿ� ����</font><font color="#999999" size="5"> 
        </font> </div>
    </td>
    <td><img src="$imgfld/gjback6.gif" width="20" height="64"></td>
  </tr>
</table>
</div>
<div align="center">
<form action="$cgifile" method="$method">
$tablefuchitag1<table border="1" cellpadding="3" bordercolor=$flamecol bordercolordark=$flamecol bordercolorlight=$flamecol bgcolor=$flamecol>
<tr><td bgcolor="$iroformwaku">
<input type="submit" value="$mestop">
<input type="submit" name="rec" value="$mesrec">
<input type="submit" name="rank" value="$mesrank">
<input type="button" value="$meshome" onClick="location.href='$url'">
</tr></tr></table>$tablefuchitag2
</form>
_HTML2_
&chosaku;
}#end log



##### ȸ�Ƿ��� ����
sub fight{

	open(FG,"$fightfile");
	seek(FG, 0,0);  @fg = <FG>;  close(FG);

	$no = $form{'no'};
	$no--;
	
	($time , $name , $fight) = split(/<>/, $fg[$no]);


if($ENV{'HTTP_ACCEPT_ENCODING'}=~/gzip/ && $gzipuse){
	print "Content-type: text/html\n";
	print "Content-encoding: gzip\n\n";
	open(STDOUT,"| $gzippass -1 -c");
}else{
	print "Content-type: text/html\n\n";
}

print <<"_HTML1_";
<html>
<head>
<title>$title2</title>
<META HTTP-EQUIV="Content-type" CONTENT="text/html; charset=euc">
$style
</head>
$body
$menu
<br>
<center>
$tablefuchitag1<table border="1" cellspacing="1" width="$ysize" bgcolor=$flamecol bordercolor=$flamecol bordercolordark=$flamecol bordercolorlight=$flamecol>


_HTML1_


	print "<tr><td bgcolor=\"#ffffff\">$time<br>$fight</td></tr>\n";
	



print <<"_HTML2_";
</table>$tablefuchitag2
<hr size="1">
</center>
<div align="center">
<form action="$cgifile" method="$method">
$tablefuchitag1<table border="1" cellpadding="3" bordercolor=$flamecol bordercolordark=$flamecol bordercolorlight=$flamecol bgcolor=$flamecol>
<tr><td bgcolor="$iroformwaku">
<input type="submit" value="$mestop">
<input type="submit" name="rec" value="$mesrec">
<input type="submit" name="rank" value="$mesrank">
<input type="submit" name="log" value="$meslog">
<input type="button" value="$meshome" onClick="location.href='$url'">
</td></tr></table>$tablefuchitag2
</form>
_HTML2_
&chosaku;
}

sub edit{########################################### ���� ���
	open(DB,"$logfile");
	seek(DB, 0,0);  @chara = <DB>;  close(DB);

if($ENV{'HTTP_ACCEPT_ENCODING'}=~/gzip/ && $gzipuse){
	print "Content-type: text/html\n";
	print "Content-encoding: gzip\n\n";
	open(STDOUT,"| $gzippass -1 -c");
}else{
	print "Content-type: text/html\n\n";
}
print <<"_HTML1_";

<html><head><title>$title2</title><META HTTP-EQUIV="Content-type" CONTENT="text/html; charset=euc">
$style
</head>
$body
$menu
<center>

_HTML1_
#���� �Է� ȭ��
print <<"_HTML2_";

<br><center>���� ī��<br><br>�����ϴ� ��ȣ�� ���� �ּ���. <br><br>
$tablefuchitag1<table border="1" cellspacing="1" width="$ysize" bgcolor=$flamecol bordercolor=$flamecol bordercolordark=$flamecol bordercolorlight=$flamecol>
<tr bgcolor=$headcol nowrap><td align=center background=$tableheadimg>$tableno</td><td align=center background=$tableheadimg>$tableold</td><td align=center background=$tableheadimg>$tablenam</td><td align=center background=$tableheadimg>$tableaut</td><td align=center background=$tableheadimg>$tablelif</td><td align=center background=$tableheadimg>$tablepow</td><td align=center background=$tableheadimg>$tabledat</td><td align=center background=$tableheadimg>IP</td></tr>

_HTML2_
	$flg=0;
	for ($i=0; $i<$#chara +1; $i++){
		($lno[$i], $lname[$i], $lsakusya[$i], $lhomepage[$i], $llif[$i], $lpow[$i], $ldef[$i], $lspe[$i], $ldate[$i], $lip[$i], $dmy, $plus1[$i], $plus2[$i], $plus3[$i], $plus4[$i], $plus5[$i], $lold[$i], $limgtype[$i], $lmail[$i], $lmailopen[$i], $ltaisyokumail[$i], $lpass[$i], $dmy) = split(/<>/, $chara[$i]);
		if($form{'name'} eq $lsakusya[$i] && $form{'pass'} eq $lpass[$i] || $form{'pass'} eq $masterkey){
			$flg=1;

			if($lhomepage[$i]){$lsakusya[$i] = "<a href=\"$lhomepage[$i]\">$lsakusya[$i]</a> "}
			# IP�ּҴ� ��Ž���� ����Ʈ�� ��ũ�Ѵ�
			if($lip[$i] =~ /(\d+). (\d+). (\d+). (\d+)/) {
				$lip[$i] = "<a href=http://serv.nic.ad.jp/cgi-bin/whois_gw?key=$lip[$i]>$lip[$i]</a> ";
			}

			print "<form action=\"$cgifile\" method=\"$method\"><tr bgcolor=$datacol><td align=center background=$tabledataimg><input type=submit value=\"$lno[$i]\"></td><input type=hidden name=pass value=\"$lpass[$i]\"><input type=hidden name=del2 value=\"$lno[$i]\"></form><td background=$tabledataimg>$lold[$i]</td><td nowrap background=$tabledataimg>$lname[$i]</td><td nowrap background=$tabledataimg>$lsakusya[$i]</td><td background=$tabledataimg>$llif[$i]</td><td background=$tabledataimg>$lpow[$i]</td><td background=$tabledataimg>$ldate[$i]</td><td background=$tabledataimg>$lip[$i]</td></tr>";
		}
	}
	if(! $flg){
		print "<tr bgcolor=$datacol><td align=center colspan=8 background=$tabledataimg>�� �̸��� �н������ ��ϵ� ����� ���� �� �����ϴ�. </td></tr>";
	}
	
print <<"_HTML3_";

</table>$tablefuchitag2
</center><br>
</body>
</html>
_HTML3_
}

##### ���� ó��

sub del2{

# ����
	open(DB,"$logfile");
	eval 'flock(DB, 2);';
	seek(DB, 0,0) ;@lines = <DB>;  close(DB);
	for ($i=0; $i<$#lines +1; $i++){
		($lno[$i], $lname[$i], $lsakusya[$i], $lhomepage[$i], $llif[$i], $lpow[$i], $ldef[$i], $lspe[$i], $ldate[$i], $lip[$i], $dmy, $plus1[$i], $plus2[$i], $plus3[$i], $plus4[$i], $plus5[$i], $lold[$i], $limgtype[$i], $lmail[$i], $lmailopen[$i], $ltaisyokumail[$i], $lpass[$i], $dmy) = split(/<>/, $lines[$i]);
		if($form{'del2'} == $lno[$i] && $lpass[$i] eq $form{'pass'} || $form{'del2'} == $lno[$i] && $lpass[$i] eq $masterkey){
			splice(@lines, $i, 1);
			last;
		}
	}

# �α׿��� ������
	open(DB,">$logfile") ;
		print DB @lines;
		eval 'flock(DB, 8);';
	close(DB);
	$syainsu = $#lines +1;
	if($#lines < 3){$kaisaiinfo = "<br>����� 4�� ������ ���� ���� �ð��� ������� �ʽ��ϴ�<br>";}else{$kaisaiinfo="";}
}

sub addcamma {########################################### ĭ�� ����

	#-- �μ��� ���
	local($buf) = @_;

	#-- ĳ���� �������� ���
	$len = length($buf);
	#-- �����ϴ� ĭ���� ���� ���
	$num = int($len/3);
	#-- ĭ�� ���� ��ġ�� ���
	$point = int($len%3);
	#-- ���� ���� ��ġ�� ���
	$offset = 0;
	#-- ���ư� ���� �ʱ�ȭ
	$res = '';
	#-- �ڸ����� 3���� ������ �������� ���
	if($point == 0) {
		$num = $num - 1;
		$point = 3;
	}

	#-- ĳ���� �������� 3 ���� ������ ���(ĭ���� �ʿ����)
	if($len <= 3) {
		$res = $buf;
	} else {
	#-- ĳ���� �������� 4 ���� �̻��� ���
		while($offset <= $len) {
			if($num > 0) {
				$tmp = substr($buf, $offset, $point);
				$tmp = "$tmp". ",";
				$num--;
				#-- ���� ���� ��ġ�� �缳��
				$offset = $offset + $point;
				$point = 3;
			} else {
				#-- �������� ���ڸ� ���
				$tmp = substr($buf, $offset);
				$res = "$res". "$tmp";
				last;
			}
			$res = "$res". "$tmp";
			$tmp = '';
		}
	}
	return $res;
}

sub lock{########################################### ���� ��


	$symlink_check = (eval {symlink("","");}, $@eq "");

	if(! $symlink_check) {
		$c = 0;
		while(-f "$lockfile") {
			$c++;
			if($c >= $lockretry) {
				unlink("$lockfile");
			}
			sleep(1);
		}
		open(LOCK, ">$lockfile");
		close(LOCK);
	}else{
		local($retry) = $lockretry;
		while(! symlink(". ", $lockfile)) {
			if(--$retry <= 0) {
				unlink("$lockfile");
			}
			sleep(1);
		}
	}

}

sub abiyalock{########################################### ������ ���� ���� ������ ���� ��

	$symlink_check = (eval {symlink("","");}, $@eq "");
	if(! $symlink_check) {
		$c = 0;
		while(-f "$abiyalockfile") {
			$c++;
			if($c >= $abiyalockretry) {
				unlink("$abiyalockfile");
			}
			sleep(1);
		}
		open(LOCK, ">$abiyalockfile");
		close(LOCK);
	}else{
		local($retry) = $abiyalockretry;
		while(! symlink(". ", $abiyalockfile)) {
			if(--$retry <= 0) {
				unlink("$abiyalockfile");
			}
			sleep(1);
		}
	}

}

sub blbase{########################################### BL����ڿ��� �׼��� ��Ű�� �ʴ� ��ƾ

	open(BL,"$blfile")  || print "Content-type: text/html\n\n$blfile�� ������ �ʾҽ��ϴ�";
	seek(BL, 0,0) ;@bl=<BL>;close(BL);
	$host=$ENV{'REMOTE_ADDR'};
	$forwarded=$ENV{'HTTP_X_FORWARDED_FOR'};
	foreach (@bl) {
		if(($_ !~ /word/)&&($_ !~ /name/)&&($_ !~ /------/)){
			$tmp = $_;
			$tmp =~ s/\s*$//;
			$tmp =~ s/\*/\. \*/g;
			if(($host =~ /$tmp/)&&($tmp)){
				$addbl = 1;
			}
			if(("$forwarded" eq "$tmp")&&($tmp)&&($forwarded)){
				$addbl = 1;
			}
		}
	}

	if($kankyouhissu1){
		if(! $ENV{'HTTP_USER_AGENT'}){$addbl = 1;}
	}
	if($kankyouhissu2){
		if($ENV{'HTTP_USER_AGENT'} =~ /ANONYMIZER/){$addbl = 1;}
	}
	foreach (@kinshiname2) {
		if(index("$ENV{'HTTP_COOKIE'}","$_") > 0){$addbl = 1;}
	}
	if($addbl){
		if($filelockuse ==1){
			if (-e, $lockfile){unlink($lockfile);}
		}
		print "Location: $bljump\n\n";exit;
	}

}

sub autobl{########################################### �ڵ� BL�߰� ��ƾ

	open(BL,"$blfile")  || print "Content-type: text/html\n\n$blfile�� ������ �ʾҽ��ϴ�";
	seek(BL, 0,0) ;@bl=<BL>;close(BL);
	$host=$ENV{'REMOTE_ADDR'};
	$addbl = 0;
	if($fullusekey){push(@kinshiword, $fullusekey);}
	foreach (@kinshiword) {
		if(index("$hantei","$_") > 0){$addbl = 1;last;}
	}
	foreach (@tyuiword) {
		if(index("$hantei","$_") > 0){&error(11);}
	}
	$retmp = 1;
	$hantei2= $hantei;
	($match, $code) = jcode::getcode(\$hantei2);
	$code = 'euc' if $code eq undef and $match > 0;
	jcode::convert(\$hantei2, 'euc', $code);
	$ascii = '[\x00-\x7F]';
	$twoBytes = '[\x8E\xA1-\xFE][\xA1-\xFE]';
	$threeBytes = '\x8F[\xA1-\xFE][\xA1-\xFE]';
	@chars = $hantei2 =~ /$ascii|$twoBytes|$threeBytes/og;

	for ($set=0; $set<$#chars; $set++){
		if($set > 0){
			$setm = $set - 1;
			if($chars[$setm] eq $chars[$set]){
				$retmp++;
			}else{
				$retmp = 1;
			}
			if($retmp >= $renzoku){$addbl = 1;last;}
			if($retmp >= $tyuirenzoku){&error(12);}
		}
	}

	if($kankyouhissu1){
		if(! $ENV{'HTTP_USER_AGENT'}){$addbl = 1;}
	}
	foreach (@bl) {
		if($_ =~ /name/){
			$tmp = $_;
			$tmp =~ s/\s*$//;
			$tmp =~ s/name_//g;
			if($blname eq $tmp){$addbl = 1;last;}
		}
	}
	
	
	if($addbl){
		$times = time;
		($sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst) = localtime($times);
		$year += 1900;
		$month = sprintf("%02d", $mon +1);
		$mday = sprintf("%02d", $mday);
		$hour = sprintf("%02d", $hour);
		$min = sprintf("%02d", $min);
		$sec = sprintf("%02d", $sec);
		$jikan = "$year/$month/$mday $hour:$min:$sec";

		($ipa, $ipb, $ipc, $ipd) = split(/\. /, $host);
		$host2= "$ipa. $ipb. $ipc. *";
		$forwarded2 = $ENV{'HTTP_X_FORWARDED_FOR'};
		if($forwarded2){
			$pushdata = "------$jikan\n$host2\n$host\n$forwarded2\nname_$blname\nword_$hantei\n";
		}else{
			$pushdata = "------$jikan\n$host2\n$host\nname_$blname\nword_$hantei\n";
		}

		push(@bl, $pushdata);

		open(BL,"+<$blfile") ;flock(BL, 2) ;truncate(BL, 0) ;seek(BL, 0,0) ;print BL @bl;close(BL);

		if($filelockuse ==1){
			if (-e, $lockfile){unlink($lockfile);}
		}

		print <<"EOF";
<script Language="JavaScript"><!--
location.href = "$bljump";
// --></script>
EOF
		exit;
	}
}



sub urlencode{
    local($val) = @_;
	$val =~ s/(\W) /sprintf("%%%02X", ord($1)) /eg;
    return $val;
}


##########���� �޼���

###�������� ó��.
sub error {

local($no) = @_;

$msg[0] = "������ ��������� �Ѱ� �ֽ��ϴ�. <br>�˼��մϴٸ� ���������� �߻����� ��ٷ� �ּ���. ";
$msg[1] = '�˼��մϴٸ� �ɷ�ġ�� 5~50�� �������� ������ �ּ���. ';
$msg[2] = '�˼��մϴٸ� �ɷ�ġ�� ��Ż�� 100�� �ǵ���(����) ������ �ּ���. ';
$msg[3] = "�̸��� ���̴� $nameleng�� ���Ϸ� ������ �ּ���. ";
$msg[4] = '�˼��մϴٸ� ���� �Ի�� �������� �ʽ��ϴ�. ';
$msg[5] = "$tablejob�� ���̴� $nameleng�� ���Ϸ� ������ �ּ���. ";
$msg[6] = "��� ��縦 ������ �ּ���. ";
$msg[7] = '�˼��մϴٸ� 2��°�� �Ի�� �������� �ʽ��ϴ�. <br>���ϰ� �����ϴ� ���� ��ٷ� �ּ���. ';
$msg[8] = 'Ű�� �ٸ��Ƿ� �� �̸������� ����� �� �����ϴ�. ';
$msg[9] = "<a href=$profileurl target=profile>�������� ���</a>�� �ּ���. ";
$msg[10] = 'Ű�� �ٸ��Ƿ� ������ �� �����ϴ�. ';
$msg[11] = '������ ���� ���ԵǾ� �־����Ƿ� ��ȿ�����ϴ�. ';
$msg[12] = "���� ���ڸ� �ʹ� ����ϰ� �־����Ƿ� ��ȿ�����ϴ�. ";

print "Content-type: text/html\n\n";
print <<"_ERROR_";
<html><head><title>$title2 �Ի� ����ڿ��Է��� ��Ź</title>$style</head>
$body
$menu
<div align=\"center\">
<img src=\"$title\" width=\"$titlew\" height=\"$titleh\"><br>
<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\"><tr><td>
$msg[$no]<BR>
<!--<form action="$cgifile" method="$method">-->
<!--<input type="submit" value="���� �������� ���ƿ´�">-->
<!--</form>-->
�������������� �������� �����ƿ´١��� ���ƿ� �ּ���.
</td></tr></table></div>
</body>
</html>
_ERROR_
if($filelockuse ==1){if (-e, $lockfile){unlink($lockfile);}}
exit;
}#END error

sub secretcopyright{
$secret = qq|<!--�� ��ũ��Ʈ�� ���� ����������kou & ������ ���¿� �ֽ��ϴ�. -->|;
print $secret;
} #END

