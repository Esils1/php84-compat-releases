@OtherDir=("drago");
$Tname{drago}="약칭";
