#!/usr/bin/perl
# 영주 농원 관리 2005/03/30 유래

Lock() if $Q{mode};
$image[0]=GetTagImgKao("대신","minister",'align="left" ');
DataRead();
CheckUserPass();
OutError('농원 관리는 영주만 할 수 있습니다') if $STATE->{leader}!=$DT->{id};
RequireFile('inc-manor.cgi');

ReadDTSub($DT,"lord");
my $functionname=$Q{mode};
&$functionname if defined(&$functionname);


# 농원 설정을 가져옴
my $MANORLORD=$DT->{_lord};

my $shoplist="";
my $taxsum=0;
foreach (@DT) {
$shoplist.="<OPTION VALUE=\"$_->{id}\">$_->{shopname}";
$taxsum+=$_->{taxtoday};
}

my $now=$DTlasttime+$TZ_JST-$DATE_REVISE_TIME;
my $ii=($now % $ONE_DAY_TIME);
$ii=1 if $ii < 1;
$taxsum=GetMoneyString(int($taxsum * $ONE_DAY_TIME / $ii / 10000) * 10000);

$disp.="<BIG>●영주 농원 관리실</BIG><br><br>";
$disp.=$TB.$TR.$TD.$image[0]."<SPAN>대신</SPAN>:시세에 주의해서 운영하지 않으면 안 됩니다.<br>";
$disp.="·판매 재고는 품목당 1000개까지 설정할 수 있습니다.<br>";
$disp.="·종자의 판매 가격은 ".GetMoneyString(1000)." ～ ".GetMoneyString(10000).".<br>";
$disp.="·수확물의 매입 가격은 ".GetMoneyString(5000)." ～ ".GetMoneyString(40000).".<br>";
$disp.="·판매 가격이 매입 가격보다 높으면 아무도 사지 않으니 주의하세요.".$TRE.$TBE;

$disp.="<hr width=500 noshade size=1><BIG>●현재 영지 상태</BIG><br><br>";
$disp.="$TB$TDB마을 자금$TDB세수 전망$TDB전일 세수$TDB전일 지출$TRE";
$disp.=$TR.$TD.GetMoneyString($STATE->{money}).$TD.$taxsum;
$disp.=$TD.GetMoneyString($STATE->{in}).$TD.GetMoneyString($STATE->{out}).$TRE.$TBE;


$disp.=<<"HTML";
<hr width=500 noshade size=1><BIG>●농원 설정</BIG><br><br>
<FORM ACTION="action.cgi" $METHOD>
$MYFORM$USERPASSFORM
<INPUT TYPE=hidden NAME=mode VALUE="inside">
$TB$TR
$TDB종자$TDB판매 재고$TDB판매 가격$TD$TDB수확물$TDB매입 가격$TDB매입 수$TDB설명$TRE
HTML

my $balance=0;
foreach my $i(0..$#MANOR)
	{
	my @MYMANOR=@{$MANOR[$i]};
	$disp.=$TR.$TD.GetTagImgManor($MYMANOR[1]).$MYMANOR[0];
	my $c=$MANORLORD->{"count$i"} + 0;
	$disp.=qq|$TD<INPUT TYPE=TEXT NAME=count$i SIZE=8 VALUE="$c"> 개|;
	my $t=$MANORLORD->{"price$i"} + 0;
	$balance-=$c*$t;
	$disp.=$TD."@".qq|$term[0]<INPUT TYPE=TEXT NAME=price$i SIZE=8 VALUE="$t">$term[1]|;
	$disp.=$TD."→".$TD.GetTagImgManor($MYMANOR[3]).$MYMANOR[2];
	$t=$MANORLORD->{"cost$i"} + 0;
	$balance+=$c*$t;
	$disp.=$TD."@".qq|$term[0]<INPUT TYPE=TEXT NAME=cost$i SIZE=8 VALUE="$t">$term[1]|;
	$disp.=$TD.($MANORLORD->{"stock$i"} +0)." 개";
	$disp.=$TD."<small>매입 수 $MYMANOR[5]개로 ".GetTagImgItemType($MYMANOR[4]).$ITEM[$MYMANOR[4]]->{name}." 생성</small>".$TRE;
	}
$disp.=$TBE."<br>※위의 농원 설정에서는 ".GetMoneyString($balance)."의 지출이 예상됩니다.<br><br>";

$disp.=<<"HTML";
<INPUT TYPE=SUBMIT VALUE="위 내용으로 설정">
</FORM>
<hr width=500 noshade size=1>
	<FORM ACTION="action.cgi" $METHOD>
	$MYFORM$USERPASSFORM
	<INPUT TYPE=hidden NAME=mode VALUE="outside">
<BIG>●산물 생성</BIG>: 매입한 수확물로 산물을 
<INPUT TYPE=SUBMIT VALUE="생성하기">
	</FORM>
HTML

OutSkin();
1;


sub inside
{
foreach my $i(0..$#MANOR)
	{
	$DT->{_lord}->{"count$i"}=CheckCount($Q{"count$i"},0,0,1000);
	$DT->{_lord}->{"price$i"}=CheckCount($Q{"price$i"},0,1000,10000);
	$DT->{_lord}->{"cost$i"}=CheckCount($Q{"cost$i"},0,5000,40000);
	}
WriteDTSub($DT,"lord");
DataCommitOrAbort();
UnLock();
}

sub outside
{
my $flag=0;
foreach my $i(0..$#MANOR)
	{
	my @MYMANOR=@{$MANOR[$i]};
	my $num=0;
	$num=int($DT->{_lord}->{"stock$i"} / $MYMANOR[5]) if $MYMANOR[5];
	next if !$num;	#생성 가능 수 없음

	my $itemno=$MYMANOR[4];
	my $count=CheckCount($num,0,0,$ITEM[$itemno]->{limit} - $DT->{item}[$itemno-1]);
	$disp.=$ITEM[$itemno]->{name}."은 창고가 가득 차 생성하지 못했습니다.<br>", next if !$count;

	$flag++;
	$DT->{item}[$itemno-1]+=$count;
	$DT->{_lord}->{"stock$i"}-=$count * $MYMANOR[5];
	my $ret=$ITEM[$itemno]->{name}."을".$count.$ITEM[$itemno]->{scale}."생성";
	$disp.=$ret."했습니다.<br>";
	PushLog(0,$DT->{id},"영주 농원에서 ".$ret);
	}

if ($flag)
	{
	WriteDTSub($DT,"lord");
	RenewLog();
	DataWrite();
	DataCommitOrAbort();
	}
	else
	{
	$disp.='생성 가능한 산물이 없습니다.';
	}
UnLock();
OutSkin();
exit;
}





