#!/usr/bin/perl
# 의뢰 처리 2005/03/30 유래

Lock();
DataRead();
CheckUserPass();
RequireFile('inc-req.cgi');

$disp.="<BIG>●의뢰소</BIG><br><br>";

my $functionname=$Q{mode};
OutError("bad request") if !defined(&$functionname);
&$functionname;

$disp.="<br><br>".$TBT.$TRT.$TD.GetTagImgJob($DT->{job},$DT->{icon});
$disp.=$TD.GetMenuTag('stock',	'[창고에]');
$disp.=GetMenuTag('req','[계속해서 의뢰를 본다]');
$disp.=$TRE.$TBE;

WriteAuc();
DataWrite();
DataCommitOrAbort();
UnLock();
OutSkin();
1;


sub new
{
	my ($numrate,$prrate);
	$itemno=$Q{it};
	$num=CheckCount($Q{num},0,0,$MAX_MONEY);
	$prn=$Q{prn};
	$pr=CheckCount($Q{pr},0,0,$MAX_MONEY);
	$pr=$pr * $num if ($Q{unit})&&($prn < 0);
	$num=$num * $pr if ($Q{unit})&&($itemno < 0);
	OutError($AucImg.'의뢰품의 개수나 가격의 지정을 잊고 있는 것 같구나.') if ($pr < 1) ;
	OutError($AucImg.'보수품의 개수나 가격의 지정을 잊고 있는 것 같구나.') if ($num < 1) ;
	if ($itemno > 0) {
		OutError($AucImg.'이봐 이봐, 없는 소매는 흔들리지 않는거야!') if ($DT->{item}[$itemno-1] < $num) ;
		OutError($AucImg.'그 물건은 출품할 수 없는거야.') if ($ITEM[$itemno]->{flag}=~/r/) ;	# r 의뢰 불가
		$numrate=$ITEM[$itemno]->{price} * $num;
		} else {
		OutError($AucImg.'이봐 이봐,없는 소매는 흔들리지 않는거야!') if ($DT->{money} < $num);
		$numrate=$num;
		}
	OutError($AucImg.'의뢰품과 보수품이 같아선 거래가 성립되지않아!') if ($itemno == $prn) ;
	if ($prn > 0) {
		OutError($AucImg.'의뢰품의 개수가 너무 많아서 달성할 수 있을 것 같지 않아.') if ($pr > $ITEM[$prn]->{limit}) ;
		OutError($AucImg.'그 물건은 의뢰할 수 없는거야.') if ($ITEM[$prn]->{flag}=~/r/)||($ITEM[$prn]->{flag}=~/o/);	# o 출품만
		$prrate=$ITEM[$prn]->{price} * $pr;
		} else {
		$prrate=$pr;
		}
	OutError($AucImg.'의뢰와 보수의 가치가 평형을 않아. 조건을 다시 봐 줘.') if ($prrate > $numrate * 2) || ($numrate > $prrate * 2);

	my @list=map{$_->{id}}@REQ;
	@list=grep($_ eq $DT->{id},@list);
	OutError($AucImg.'더 이상 의뢰를 낼 수 없는거야!') if (scalar(@list) >= $REQUEST_CAPACITY);

	@REQ=reverse(@REQ);
	$Scount++;
	my $i=$Scount;
	$REQ[$i]->{no}=($i > 0) ? ($REQ[$i-1]->{no} + 1) : 1;
	$REQ[$i]->{id}=$Q{id};
	$REQ[$i]->{mode}=0;
	$REQ[$i]->{tm}=$NOW_TIME + $REQUEST_LIMIT;
	($REQ[$i]->{itemno},$REQ[$i]->{num},$REQ[$i]->{prn},$REQ[$i]->{pr})=($itemno,$num,$prn,$pr);
	@REQ=reverse(@REQ);

	$DT->{item}[$itemno-1]-=$num if ($itemno > 0);
	$DT->{money}-=$num ,$DT->{paytoday}+=$num if ($itemno < 0);

	my $cost=0;
	$cost=int($num * $DTTaxrate / 100) if ($itemno < 0);
	$cost=int($pr * $DTTaxrate / 100) if ($prn < 0);
	OutError($AucImg.'이런,자금이 부족해서 세금을 지불할 수 없는 것 같구나.') if ($cost > $DT->{money});
	$DT->{taxtoday}+=$cost;
	$DT->{money}-=$cost;
	$disp.=$AucImg.'의뢰를 작성했다구.빨리 달성되면 좋겠다!';
}

sub plus
{
	$i=SearchReqIndex($Q{idx});
	OutError('지정된 거래는 존재하지 않습니다') if ($i==-1);
	my($itemno,$num,$prn,$pr,$mode)=($REQ[$i]->{itemno},$REQ[$i]->{num},$REQ[$i]->{prn},$REQ[$i]->{pr},$REQ[$i]->{mode});
	OutError($AucImg.'이 거래는 이미 달성되어 있어. 또 아무쪼록 부탁하지 말아라.') if defined($id2idx{$mode});
	OutError($AucImg.'이봐 이봐, 없는 소매는 흔들리지 않는거야!') if ($prn > 0)&&($DT->{item}[$prn-1] < $pr) ;
	OutError($AucImg.'이봐 이봐, 없는 소매는 흔들리지 않는거야!') if ($prn < 0)&&($DT->{money} < $pr) ;

	$DT->{item}[$prn-1]-=$pr if ($prn > 0);
	$DT->{money}-=$pr,$DT->{paytoday}+=$pr if ($prn < 0);

	if ($itemno > 0)
		{
		$DT->{item}[$itemno-1]+=$num;
		$DT->{item}[$itemno-1]=$ITEM[$itemno]->{limit} if ($DT->{item}[$itemno-1]>$ITEM[$itemno]->{limit});
		$disp.=$AucImg.'이것이 보수인 '.$ITEM[$itemno]->{name}.' '.$num.$ITEM[$itemno]->{scale}.'다. 수고해!';
		}
	else
		{
		$DT->{money}+=$num;
		$DT->{saletoday}+=$num;
		$DT[$id2idx{$id}]->{paytoday}+=$pr if defined($id2idx{$id});
		$disp.=$AucImg.'이것이 보수인 '.GetMoneyString($num).'다. 수고해!';
		}
	$REQ[$i]->{mode}=$DT->{id};
}

sub end
{
	$i=SearchReqIndex($Q{idx});
	OutError('지정된 거래는 존재하지 않습니다') if ($i==-1);
	my($itemno,$num)=($REQ[$i]->{itemno},$REQ[$i]->{num});

	if ($itemno > 0)
		{
		$DT->{item}[$itemno-1]+=$num;
		$DT->{item}[$itemno-1]=$ITEM[$itemno]->{limit} if ($DT->{item}[$itemno-1]>$ITEM[$itemno]->{limit});
		}
		else
		{
	$DT->{money}+=$num;
		}

	undef $REQ[$i];
	$disp.=$AucImg.'이번 의뢰를 중지했다구. 또 이런 일로 부탁하지 말아라.';
}

sub thank
{
	$i=SearchReqIndex($Q{idx});
	OutError('지정된 거래는 존재하지 않습니다') if ($i==-1);
	OutError('부정한 요구입니다') if ($REQ[$i]->{id} != $DT->{id});
	my($no,$itemno,$num,$prn,$pr,$mode)=($REQ[$i]->{no},$REQ[$i]->{itemno},$REQ[$i]->{num},$REQ[$i]->{prn},$REQ[$i]->{pr},$REQ[$i]->{mode});

	if ($prn > 0) {
		$DT->{item}[$prn-1]+=$pr;
		$DT->{item}[$prn-1]=$ITEM[$prn]->{limit} if ($DT->{item}[$prn-1]>$ITEM[$prn]->{limit});
		$disp.=$AucImg.'이것이 의뢰품인 '.$ITEM[$prn]->{name}.' '.$pr.$ITEM[$prn]->{scale}.'다.<br>';
		$disp.=$DT[$id2idx{$mode}]->{shopname}.'씨가 보내 주었다구!';
		}
		else
		{
		$DT->{money}+=$pr;
		$DT->{saletoday}+=$pr;
		$disp.=$AucImg.'이것이 대금인 '.GetMoneyString($pr).'다.<br>';
		$disp.=$DT[$id2idx{$mode}]->{shopname}.'씨가 지불해 주었다구!';
		}
	undef $REQ[$i];
}

sub WriteAuc
{
	my @buf;
	foreach my $i(0..$Scount)
		{
		next unless defined($REQ[$i]->{no});
		$buf[$i]=join(",",map{$REQ[$i]->{$_}}@REQnamelist)."\n";
		}
	OpenAndCheck(GetPath($TEMP_DIR,"request"));
	print OUT @buf;
	close(OUT);
}


