#!/usr/bin/perl
# 스쿠리푸토버전표기

# 지원·갱신 안내용 표기이므로 수정하지 마세요.
# 자체 개조를 했더라도 inc-item-data 안의 버전만 변경하세요.

$BASE_VERSION="05-03-30";
$VERSION="상인 이야기 ".$BASE_VERSION;
