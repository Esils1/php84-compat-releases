#!/usr/bin/perl
# 드래곤 경주 아키스포표시 2005/03/30 유래

$disp.="<BIG>●드래곤 경주 : 스포츠 신문</BIG><br><br>";
$disp.="$TB$TR$TD".GetTagImgKao("편집장","slime4").$TD;
$disp.="<SPAN>편집장</SPAN>:스포츠 신문에서는 경주에 도움이 되는 정보를 제공합니다.<br>";
$disp.="버튼을 누르면 별도 창이 열리므로, 정보를 보면서 조작할 수 있습니다.".$TRE.$TBE;
$disp.=<<STR;
<br><FORM>
<input type="button" value="일정" onclick="javascript:window.open('action.cgi?key=slime-l&mode=sche','_blank','width=760,height=580,scrollbars')">
<input type="button" value="드래곤 목록" onclick="javascript:window.open('action.cgi?key=slime-l&mode=dra','_blank','width=760,height=580,scrollbars')">
<input type="button" value="은퇴 드래곤 목록" onclick="javascript:window.open('action.cgi?key=slime-l&mode=pr','_blank','width=760,height=580,scrollbars')">
<input type="button" value="목장 목록" onclick="javascript:window.open('action.cgi?key=slime-l&mode=rc','_blank','width=760,height=580,scrollbars')">
<input type="button" value="마구간 목록" onclick="javascript:window.open('action.cgi?key=slime-l&mode=st','_blank','width=760,height=580,scrollbars')">
<input type="button" value="기수 목록" onclick="javascript:window.open('action.cgi?key=slime-l&mode=jk','_blank','width=760,height=580,scrollbars')">
</FORM>
STR
ReadDraLog();

my($page,$pagestart,$pageend,$pagenext,$pageprev,$pagemax);
my $pagecontrol="";
($page,$pagestart,$pageend,$pagenext,$pageprev,$pagemax)
	=GetPage($Q{lpg},$LIST_PAGE_ROWS,scalar(@MESSAGE));
	
	$pagecontrol=GetPageControl($pageprev,$pagenext,"mode=info","lpg",$pagemax,$page);
	$disp.=$pagecontrol;
	
	$disp.="<BR>";

$disp.=$TB;
$disp.=$TR.$TD;
foreach my $cnt ($pagestart..$pageend)
{
	my $msg=$MESSAGE[$cnt];
	next if $msg eq '';
	my($tm,$mode,$message)=split('\t',$msg);
	chop($message);

	if ($mode==1)
	{$disp.="<small>".GetTime2FormatTime($tm)."</small> <SPAN>[신입]".$message."</SPAN>";}
	elsif ($mode==2)
	{$disp.="<small>".GetTime2FormatTime($tm)."</small> <BIG>[전문]".$message."</BIG>";}
	else
	{$disp.="<small>".GetTime2FormatTime($tm)."</small> ".$message;}
	$disp.="<BR>";
}
$disp.=$TRE.$TBE;
$disp.=$pagecontrol;
1;

sub ReadDraLog
{
	undef @MESSAGE;
	open(IN,GetPath($COMMON_DIR,"dra-log0"));
	push(@MESSAGE,<IN>);
	close(IN);
	open(IN,GetPath($COMMON_DIR,"dra-log1"));
	push(@MESSAGE,<IN>);
	close(IN);
	@MESSAGE=("0\t0\t정보는 없습니다\n") if !scalar(@MESSAGE);
}

