#!/usr/bin/perl
# 궁전 2004/01/20 유래

RequireFile("inc-palace.cgi");	#설정 파일 읽기

$image[0]=GetTagImgKao("왕","king",'align="left" ');
$image[1]=GetTagImgKao("대신","minister",'align="left" ');

DataRead();
CheckUserPass();

$evt=GetTownData('evt');
$evt=0 if (!$evt);
$level=DignityDefine($DT->{dignity});

$disp.="<BIG>●궁전</BIG><br><br>";

$shopname=$DT->{shopname};
$name=$DT->{name};
$need=$itemno[$evt];

if ($DT->{point} <  $deny_point )
	{
	$disp.='<TABLE cellpadding="26" width="570"><tr>';
	$disp.=qq|<TD style="background-repeat : repeat-x;background-image : url($IMAGE_URL/palace.png);" valign="top"><br><br>|;
	$disp.=$image[1].'왕궁에 무슨 용무입니까, <b>'.$shopname.'</b>의 <b>'.$name.'</b>님.<br>';
	$disp.='그러나 국왕 폐하께서는 '.$name.'님과 아직 면회할 수 없다고 하셨습니다.';
	$disp.='<br>조금 더 경영 실력을 쌓은 뒤 다시 와 보세요.'.$TRE;
	$disp.=$TBE."<br>";
	}
	else
	{
	KingMain();
	}

OutSkin();
1;


sub KingMain
{
$disp.='<TABLE cellpadding="26" width="570"><tr>';
$disp.=qq|<TD style="background-repeat : repeat-x;background-image : url($IMAGE_URL/palace.png);" valign="top"><br><br>|;
$disp.=$image[0].'잘 왔다, <b>'.$shopname.'</b>의 <b>'.$name.$level.'</b>여.<br>';
$disp.='그대의 활약은 익히 들었다. 그래서 그대에게 사명을 내리겠다.<br><br>';
$disp.=$msg[$evt].'<br>그렇다면 <b>'.GetTagImgItemType($need).$ITEM[$need]->{name}.'을 '.$count[$evt].$ITEM[$need]->{scale}.'</b> 모아 오너라.';
$disp.='<br>이 사명을 훌륭히 완수하면 그대에게 '.DignityDefine(1,1).'<b>작위 경험치</b>를 주겠다. 해 보겠느냐?'.$TRE;
$disp.=$TBE;

$disp.=<<"HTML";
<br><FORM ACTION="action.cgi" $METHOD>
<INPUT TYPE=HIDDEN NAME=key VALUE="palace-s">
$USERPASSFORM
<BIG>●사명 달성</BIG>: 왕이 의뢰한 상품을
<INPUT TYPE=SUBMIT VALUE="전달하기"></FORM>
HTML
}
