#!/usr/bin/perl
# 특수 디코딩 2003/09/25 유래

OutError("전송 크기가 너무 큽니다") if ($ENV{'CONTENT_LENGTH'} > 10240);

binmode(STDIN);
my $Boundary = <STDIN>;
$Boundary =~ s/\x0D\x0A//;
while (<STDIN>) {
	if (/^\s*Content-Disposition:/i) {
		my $Name;
		# 폼 항목 이름을 가져옵니다
		if (/\bname="([^"]+)"/i or /\bname=([^\s:;]+)/i) {
			$Name = $1;
		}
		# 파일 이름을 가져옵니다
		if (/\bfilename="([^"]*)"/i or /\bfilename=([^\s:;]*)/i) {
			$FILENAME{$Name} = $1 || 'unknown';
		}
		# 헤더 내용을 읽습니다
		# 헤더 종료를 나타내는 빈 줄을 찾으면 루프를 빠져나갑니다
		while (<STDIN>) {
			last if (not /\w/);
			if (
				/^\s*Content-Type:\s*"([^"]+)"/i
				or /^\s*Content-Type:\s*([^\s:;]+)/i
			) {
			$MIMETYPE{$Name} = $1;
			}
		}
		# 데이터 본문을 읽습니다
		# 데이터 종료를 나타내는Boundary을검출한라루프를 빠져나갑니다
		while (<STDIN>) {
			last if (/^\Q$Boundary\E/);
			$Q{$Name}.= $_;
		}
		$Q{$Name} =~s /\x0D\x0A$//; # 끝의\r\n을제거합니다
		if ($Q{$Name}) {
			# 파일인 경우
			if ($FILENAME{$Name} or $MIMETYPE{$Name}) {
				# MacBinary을검출하고삭제
				if (
					$MIMETYPE{$Name}
					=~ /^application\/(x-)?macbinary$/i
				) {
				# Header와끝의리소-스을삭제
					$Q{$Name} = substr(
						$Q{$Name},
						128,
						unpack("N", substr($Q{$Name}, 83, 4))
					);
				}
			}
			# 파일이밖의장합
			else {
				$Q{$Name} =~ s/&/&amp;/g;
				$Q{$Name} =~ s/"/&quot;/g;
				$Q{$Name} =~ s/</&lt;/g;
				$Q{$Name} =~ s/>/&gt;/g;
				$Q{$Name} =~ s/\x0D\x0A/<br>/g;
				$Q{$Name} =~ s/\x0D/<br>/g;
				$Q{$Name} =~ s/\x0A/<br>/g;
			}
		}
	}
	# Boundary을검출한라루프를 빠져나갑니다
	last if (/^\Q$Boundary--\E/);
}
	@Q{qw(nm pw ss)}=split(/!/,$Q{u},3) if exists $Q{u};
1;
