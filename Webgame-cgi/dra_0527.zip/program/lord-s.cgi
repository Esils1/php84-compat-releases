#!/usr/bin/perl
# 영주 저택 2004/01/20 유래

$image[0]=GetTagImgKao("대신","minister");
Lock();
DataRead();
CheckUserPass();

my $functionname=$Q{mode};
OutError("bad request") if !defined(&$functionname);
&$functionname;
RenewLog();
DataWrite();
DataCommitOrAbort();
UnLock();

OutSkin();
1;

sub inside
{
if ($Q{taxrate} =~ /([^0-9])/
	|| $Q{devem} =~ /([^0-9])/
	|| $Q{safem} =~ /([^0-9])/
	) { OutError('사용할 수 있는 문자는 숫자뿐입니다'); }
OutError($image[0].'아무리 그래도 너무 높은 세율입니다.') if ($Q{taxrate} > 40) ;
OutError($image[0].'그렇게 많은 예산을 한 번에 투입할 수는 없습니다.') if ($Q{devem} > 10000000 || $Q{safem} > 10000000) ;

$Q{taxrate}=0 if $Q{taxrate}<0;
$Q{devem}=0 if $Q{devem}<0;
$Q{safem}=0 if $Q{safem}<0;
my $taxrate=int($Q{taxrate});
$disp.="마을의 운영 방침을 변경했습니다.";

if ($DTTaxrate != $taxrate )
	{
	my $i="인상했습니다";
	$i="인하했습니다" if $DTTaxrate > $taxrate;
	$DTTaxrate=int($Q{taxrate});
	PushLog(2,0,"영주".$DT->{name}."은마을의 세율을$taxrate%에$i.");
	$disp.="<br>마을의 세율을$taxrate%에$i.";
	}
$STATE->{devem}=int($Q{devem});
$STATE->{safem}=int($Q{safem});
}

sub outside
{
OutError('반란 중에는 고용할 수 없습니다.') if $DTevent{rebel};
my $stock=int($STATE->{money} / 1200);
$count=CheckCount($Q{cnt1},$Q{cnt2},0,$stock);
OutError('고용할 인원을 지정해 주세요') if !$count;
$STATE->{money}-=$count * 1200;
$STATE->{army}+=$count;
$disp.="병사 $count명을 고용했습니다.";
}

sub outdel
{
OutError('반란 중에는 해고할 수 없습니다.') if $DTevent{rebel};
$count=CheckCount($Q{cnt1},$Q{cnt2},0,$STATE->{army});
OutError('해고할 인원을 지정해 주세요') if !$count;
$STATE->{army}-=$count;
$disp.="병사 $count명을 해고했습니다.";
}

sub taxside
{
OutError('대상 가게를 선택해 주세요.') if !defined($id2idx{$Q{tg}});
my $i=$id2idx{$Q{tg}};
if ($Q{md} eq "free")
	{
	PushLog(2,0,"영주".$DT->{name}."은".$DT[$i]->{shopname}."의 세금을 면제했습니다.") if ($DT[$i]->{taxmode}!=1);
	$DT[$i]->{taxmode}=1;
	$disp.=$DT[$i]->{shopname}."의 세금을 면제했습니다.";
	}
elsif ($Q{md} eq "double")
	{
	PushLog(2,0,"영주".$DT->{name}."은".$DT[$i]->{shopname}."의 세율을 중과세로 설정했습니다.") if ($DT[$i]->{taxmode}!=2);
	$DT[$i]->{taxmode}=2;
	$disp.=$DT[$i]->{shopname}."의 세율을 중과세로 설정했습니다.";
	}
	else
	{
	PushLog(2,0,"영주".$DT->{name}."은".$DT[$i]->{shopname}."의 세금 특례를 해제했습니다.") if ($DT[$i]->{taxmode}==1);
	PushLog(2,0,"영주".$DT->{name}."은".$DT[$i]->{shopname}."의 세금 특례를 해제했습니다.") if ($DT[$i]->{taxmode}==2);
	delete $DT[$i]->{taxmode};
	$disp.=$DT[$i]->{shopname}."의 세율을 일반으로 되돌렸습니다.";
	}
}

sub treset
{
foreach (@DT) {
	delete $_->{taxmode};
}
PushLog(2,0,"영주".$DT->{name}."은모든 세금 특례를 해제했습니다.");
$disp.="전체 가게의 세율을 일반으로 되돌렸습니다.";
}

sub expose
{
OutError('반란 중에는 실행할 수 없습니다.') if $DTevent{rebel};
OutError('대상 가게를 선택해 주세요.') if !defined($id2idx{$Q{tg}});
OutError('비용이 부족합니다.') if ($STATE->{money} < 1000000);
my $i=$id2idx{$Q{tg}};
OutError($image[0].'그 가게에 대한 평판은 이미 충분히 낮은 것 같습니다.') if ($DT[$i]->{rank} < 2000) ;
$STATE->{money}-=1000000;
$DT[$i]->{rank}=int($DT[$i]->{rank} / 10);
$STATE->{safety}+=500;
$STATE->{safety}=10000 if $STATE->{safety} > 10000;
PushLog(2,0,"영주".$DT->{name}."은".$DT[$i]->{shopname}."에 대한 평판을 낮췄습니다.");
$disp.=$DT[$i]->{shopname}."에 대한 평판을 낮췄습니다.";
}

