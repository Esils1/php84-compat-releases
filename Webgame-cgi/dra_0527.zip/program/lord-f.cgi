#!/usr/bin/perl
# 영주 설정 2005/01/06 유래

$image[0]=GetTagImgKao("대신","minister");
DataRead();
CheckUserPass();
OutError('이 명령을 내릴 수 있는 것은 영주뿐입니다') if $STATE->{leader}!=$DT->{id};

my $shoplist="";
my $taxsum=0;
foreach (@DT) {
$shoplist.="<OPTION VALUE=\"$_->{id}\">$_->{shopname}";
$taxsum+=$_->{taxtoday};
}

my $now=$DTlasttime+$TZ_JST-$DATE_REVISE_TIME;
my $ii=($now % $ONE_DAY_TIME);
$ii=1 if $ii < 1;
$taxsum=GetMoneyString(int($taxsum * $ONE_DAY_TIME / $ii / 10000) * 10000);

$disp.="<BIG>●영주</BIG><br><br>";
$disp.=$TB.$TR.$TD.$image[0].$TD."<SPAN>대신</SPAN>:어서 오십시오, 영주님. 오늘도 평안하신지요.<br>";
$disp.="거리의 일은 이 대신에게 맡겨 주시면 됩니다. 안심하십시오.".$TRE.$TBE;
my $money=GetMoneyString($STATE->{money}+0);
my $army=$STATE->{army} + $STATE->{robina};
my $armycost=200-int($STATE->{safety} / 100); 	# 100 - 200
my $armyc=GetMoneyString($STATE->{army} * $armycost);

$disp.=<<"HTML";
<hr width=500 noshade size=1><BIG>●도시 운영 설정</BIG><br><br>
<FORM ACTION="action.cgi" $METHOD>
<INPUT TYPE=hidden NAME=key VALUE="lord-s">
$USERPASSFORM
<INPUT TYPE=hidden NAME=mode VALUE="inside">
$TB$TDB마을 자금$TDB예상 세수$TDB세율
$TDB개발 투자비$TDB치안 유지비$TRE
$TR$TD<b>$money</b>
$TD$taxsum
$TD<INPUT TYPE=TEXT NAME=taxrate SIZE=5 VALUE="$DTTaxrate"> %<br><small>(표준 20%)</small>
$TD$term[0]<INPUT TYPE=TEXT NAME=devem SIZE=10 VALUE="$STATE->{devem}">$term[1]<br><small>(표준 $term[0]5,000,000$term[1])</small>
$TD$term[0]<INPUT TYPE=TEXT NAME=safem SIZE=10 VALUE="$STATE->{safem}">$term[1]<br><small>(표준 $term[0]5,000,000$term[1])</small>
$TRE$TBE
<br><INPUT TYPE=SUBMIT VALUE="위 내용으로 설정">
</FORM>

<hr width=500 noshade size=1><BIG>●영주</BIG><br><br>
<FORM ACTION="action.cgi" $METHOD>
<INPUT TYPE=hidden NAME=key VALUE="lord-s">
$USERPASSFORM
<INPUT TYPE=hidden NAME=mode VALUE="taxside">
<BIG>●개별 세율</BIG>: 
<SELECT NAME=tg>$shoplist</select>
 의 세율을
<SELECT NAME=md><OPTION VALUE="normal">통상
<OPTION VALUE="free">면제
<OPTION VALUE="double">2배
</select> 에 <INPUT TYPE=SUBMIT VALUE="설정하기">
</FORM>
<FORM ACTION="action.cgi" $METHOD>
<INPUT TYPE=hidden NAME=key VALUE="lord-s">
$USERPASSFORM
<INPUT TYPE=hidden NAME=mode VALUE="treset">
<BIG>●세율 리셋</BIG>: 
모든 가게의 세율을 통상으로 <INPUT TYPE=SUBMIT VALUE="리세트하기">
</FORM>
HTML

if ($DTevent{rebel})
{
$disp.="<BIG>●가게 단속</BIG>: 반란 중이므로 실행할 수 없습니다";
}
elsif ($STATE->{army} < 2000)
{
$disp.="<BIG>●가게 단속</BIG>: 단속에 필요한 병력이 부족합니다";
}
elsif ($STATE->{money} < 1000000)
{
$disp.="<BIG>●가게 단속</BIG>: 비용이 부족합니다";
}
else
{
$disp.=<<"STR";
<FORM ACTION="action.cgi" $METHOD>
<INPUT TYPE=hidden NAME=key VALUE="lord-s">
$USERPASSFORM
<INPUT TYPE=hidden NAME=mode VALUE="expose">
<BIG>●가게 단속</BIG>: 
<SELECT NAME=tg>$shoplist</select>
 을 대상으로 
 <INPUT TYPE=SUBMIT VALUE="단속하기"> (비용$term[0]1,000,000$term[1])
</FORM>
STR
}

$disp.=<<"HTML";
<hr width=500 noshade size=1><BIG>●치안 설정</BIG><br><br>
$TB$TR$TDB현재 병력
$TD<b>$army인</b><small>(정규군 $STATE->{army}명, 의용군 $STATE->{robina}명)$TRE
$TR$TDB병력 유지비
$TD<b>$armyc</b><small>(정규군 1명당$term[0]$armycost$term[1])$TRE
$TBE
HTML

if ($STATE->{money}>0 && !$DTevent{rebel})
{
	$disp.=<<STR;
	<FORM ACTION="action.cgi" $METHOD>
	<INPUT TYPE=hidden NAME=key VALUE="lord-s">
	$USERPASSFORM
	<INPUT TYPE=hidden NAME=mode VALUE="outside">
	<BIG>●병력 고용</BIG>: 병사를 
	<SELECT NAME=cnt1>
	<OPTION VALUE="0" SELECTED>
STR
	my $stock=int($STATE->{money} / 1200);
	$msg{1000}=1000;
	$msg{5000}=5000;
	$msg{10000}=10000;
	$msg{20000}=20000;
	$msg{$stock}="$stock(자금최대)";
	my $oldcnt=0;
	foreach my $cnt (sort { $a <=> $b } (1000,5000,10000,20000,$stock))
	{
		last if $stock<$cnt || $cnt==$oldcnt;
		$disp.="<OPTION VALUE=\"$cnt\">$msg{$cnt}";
		$oldcnt=$cnt;
	}
	$disp.=<<STR;
	</SELECT>
	 인,또는 
	<INPUT TYPE=TEXT SIZE=7 NAME=cnt2> 인
	<INPUT TYPE=SUBMIT VALUE="고용하기"> @$term[0]1,200$term[1]
	</FORM>
STR
	$disp.=<<STR;
	<FORM ACTION="action.cgi" $METHOD>
	<INPUT TYPE=hidden NAME=key VALUE="lord-s">
	$USERPASSFORM
	<INPUT TYPE=hidden NAME=mode VALUE="outdel">
	<BIG>●병력 해고</BIG>: 병사를 
	<SELECT NAME=cnt1>
	<OPTION VALUE="0" SELECTED>
STR
	my $army=$STATE->{army}+0;
	$msg{1000}=1000;
	$msg{5000}=5000;
	$msg{10000}=10000;
	$msg{20000}=20000;
	$msg{$army}="$army(병력최대)";
	my $oldcnt=0;
	foreach my $cnt (sort { $a <=> $b } (1000,5000,10000,20000,$army))
	{
		last if $army<$cnt || $cnt==$oldcnt;
		$disp.="<OPTION VALUE=\"$cnt\">$msg{$cnt}";
		$oldcnt=$cnt;
	}
	$disp.=<<STR;
	</SELECT>
	 인,또는 
	<INPUT TYPE=TEXT SIZE=7 NAME=cnt2> 인
	<INPUT TYPE=SUBMIT VALUE="해고하기"> @$term[0]0$term[1]
	</FORM>
STR
}

OutSkin();
1;
