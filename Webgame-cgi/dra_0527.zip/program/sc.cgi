#!/usr/bin/perl
# 진열대 설정 2004/01/20 유래

DataRead();
CheckUserPass();

RequireFile('inc-html-ownerinfo.cgi');
RequireFile('inc-sc.cgi');

OutSkin();
1;
