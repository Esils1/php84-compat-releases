#!/usr/bin/perl
# 의뢰상세표시 2005/01/06 유래

DataRead();
CheckUserPass();
RequireFile('inc-req.cgi');
RequireFile('inc-html-ownerinfo.cgi');

$disp.="<BIG>●의뢰소</BIG><br><br>";

$i=SearchReqIndex($Q{no});
OutError('지정한 의뢰는 존재하지 않습니다') if ($i==-1);
my($no,$id,$itemno,$num,$prn,$pr,$mode)=($REQ[$i]->{no},$REQ[$i]->{id},$REQ[$i]->{itemno},$REQ[$i]->{num},$REQ[$i]->{prn},$REQ[$i]->{pr},$REQ[$i]->{mode});
ReqDataSet();
ReqEnd() if defined($id2idx{$mode});
ReqLast() if !defined($id2idx{$mode});

OutSkin();
1;


sub ReqDataSet
{
$tex=<<STR;
$TB$TR
$TDB의뢰품
$TDB보상 상품
$TDB의뢰자
$TDB상태
$TDB기한
$TRE
STR

	$tex.='<tr><td>';
	if ($prn > 0) {
	$tex.=GetTagImgItemType($prn).$ITEM[$prn]->{name}.' '.$pr.$ITEM[$prn]->{scale};
	$tex.='<br><small>(정가 '.GetMoneyString($ITEM[$prn]->{price} * $pr).')</small>';
	} else {
	$tex.='자금 '.GetMoneyString($pr);
	}
	$tex.='<td>';
	if ($itemno > 0) {
	$tex.=GetTagImgItemType($itemno).$ITEM[$itemno]->{name}.' '.$num.$ITEM[$itemno]->{scale};
	$tex.='<br><small>(정가 '.GetMoneyString($ITEM[$itemno]->{price} * $num).')</small>';
	} else {
	$tex.='자금 '.GetMoneyString($num);
	}
	$tex.=defined($id2idx{$id}) ?'<td>'.$DT[$id2idx{$id}]->{shopname} : '<td>없음';
	$tex.=defined($id2idx{$mode}) ? "<td><SPAN>달성</SPAN>" : '<td> ';
	$tex.='<td>남은 시간 '.GetTime2HMS($REQ[$i]->{tm}-$NOW_TIME);
$tex.=$TRE.$TBE;
}

sub ReqEnd
{
$disp.=$AucImg.'이 의뢰는 이미 달성되었습니다. 확인해 주세요.<br><br>'.$tex;
}

sub ReqLast
{
if ($id != $DT->{id}) {
	# 의뢰달성폼
	$disp.=<<STR;
$AucImg
이 의뢰를 달성하시겠습니까?<br><br>
$tex
<hr width=500 noshade size=1>
<FORM ACTION="action.cgi" $METHOD>
<INPUT TYPE=HIDDEN NAME=key VALUE="req-s">
$USERPASSFORM
<INPUT TYPE=HIDDEN NAME=mode VALUE="plus">
<INPUT TYPE=HIDDEN NAME=id VALUE="$DT->{id}">
<INPUT TYPE=HIDDEN NAME=idx VALUE="$no">
<BIG>●의뢰 달성</BIG>:이 의뢰를
 <INPUT TYPE=SUBMIT VALUE='달성하기'>
</FORM>
STR
} else {
	# 취소 처리
	$disp.=<<STR;
$AucImg
이 의뢰는 아직 달성되지 않았습니다. 취소하시겠습니까?<br><br>
$tex
<hr width=500 noshade size=1>
<FORM ACTION="action.cgi" $METHOD>
<INPUT TYPE=HIDDEN NAME=key VALUE="req-s">
$USERPASSFORM
<INPUT TYPE=HIDDEN NAME=mode VALUE="end">
<INPUT TYPE=HIDDEN NAME=id VALUE="$DT->{id}">
<INPUT TYPE=HIDDEN NAME=idx VALUE="$no">
<BIG>●의뢰 취소</BIG>:이 의뢰를
 <INPUT TYPE=SUBMIT VALUE='취소하기'>
</FORM>
STR
	}
}

