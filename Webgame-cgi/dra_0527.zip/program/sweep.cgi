#!/usr/bin/perl
# 청소 2004/01/20 유래

DataRead();
CheckUserPass();
RequireFile('inc-html-ownerinfo.cgi');

$disp.="<BIG>●청소</BIG><br><br>";

my $usetime=GetTimeDeal($DT->{trush})-$TIME_SEND_MONEY+3599;	# 끝수를 올림
my $time=int($usetime/3600);
my $stocktime=int(GetStockTime($DT->{time})/3600);

if($DT->{trush} < 10000)
{
	$disp.=$TB.$TR;
	$disp.=$TD.GetTagImgKao("청소부","sweep").$TD;
	$disp.="청소부 : 현재 쓰레기가 없습니다.<br>";
	$disp.="쓰레기가 쌓이면 청소합시다.";
	$disp.=$TRE.$TBE;
HTML
}
else
{
	$disp.=$TB.$TR;
	$disp.=$TD.GetTagImgKao("청소부","sweep").$TD;
	$disp.="청소부 : ".int($DT->{trush}/10000)."kg 상당의 쓰레기가 있습니다.<br>";
	$disp.="전체 청소하기에는 ".GetTime2found($usetime)." 정도 걸립니다.";
	$disp.=$TRE.$TBE;

	if ($stocktime < 1)
	{
	$disp.=<<"HTML";
	<br><BIG>●시간 지정:</BIG>시간이 부족합니다
HTML
	}
	else
	{
	$disp.=<<"HTML";
	<br><FORM ACTION="action.cgi" $METHOD>
	<INPUT TYPE=HIDDEN NAME=key VALUE=sweep-s>
	$USERPASSFORM
	<BIG>●시간 지정:</BIG>
	<SELECT NAME=cnt1>
	<OPTION VALUE="0" SELECTED>
HTML
	$msg{1}=1; $msg{2}=2; $msg{3}=3; $msg{5}=5; $msg{10}=10;
	$msg{$stocktime}="$stocktime(시간최대)";
	$msg{$time}="$time(청소 최대)";
	my $oldcnt=0;
	foreach my $cnt (sort { $a <=> $b } (1,2,3,5,10,$time,$stocktime))
	{
		last if $time<$cnt || $stocktime<$cnt || $cnt==$oldcnt;
		$disp.="<OPTION VALUE=\"$cnt\">$msg{$cnt}";
		$oldcnt=$cnt;
	}
	$disp.=<<STR;
	</SELECT>
	시간,또는
	<INPUT TYPE=TEXT SIZE=7 NAME=cnt2>시간
	<INPUT TYPE=SUBMIT VALUE="청소하기"></FORM>
STR
	}
}

OutSkin();
1;
