#!/usr/bin/perl
# 게시판 글쓰기 처리 2003/09/25 유래

if ($Q{message} eq "" || $Q{message} =~ /^(\x81\x40|\s|<br>)+$/)
	{ OutError("메시지가 입력되어 있지 않습니다."); }
if ($Q{sub} eq "" || $Q{sub} =~ /^(\x81\x40|\s)+$/)
	{ OutError("제목이 입력되지 않았습니다."); }

# 관리자 글쓰기 처리
$Q{name}=$adminname,$Q{town}="" 	if ($MASTER_USER);

# 로그 파일 읽기
open(IN,$datafile);
@lines = <IN>;
close(IN);

# 글 번호
$top = shift(@lines);
($count,$ip,$tim) = split(/<>/, $top);
if ($count % 9999) { $count++; } else { $count=1; }

	# 원글
	if ($Q{no} eq 'new') {
		unshift (@lines,"$count<>no<>0<>$Q{sub}<>$Q{town}<>$Q{name}<>$Q{message}<>$NOW_TIME<>$host<>$count<>$Q{smail}<>0<>\n");
		@new = @lines;
	}
	# 답글
	else {
		# 답글이 달린 트리와 나머지 트리를 분리
		@new=();	# 위로 올라갈 트리
		@tmp=();	# 나머지 트리
		$flag=0;
		foreach (@lines) {
			chop;
			($no,$reno,$lx,$t,$e,$n,$m,$tm,$h,$OYA,$smail,$res) = split(/<>/);
			if ($flag == 1 && $lx2 > $lx && $OYA == $Q{oya}) {
				$flag=2;	# 그대로 이어 붙임
				push(@new,"$count<>$Q{no}<>$lx2<>$Q{sub}<>$Q{town}<>$Q{name}<>$Q{message}<>$NOW_TIME<>$host<>$Q{oya}<>$Q{smail}<>0<>\n");
			}
			if ($no == $Q{no}) {
				$res++;
			push(@new,"$no<>$reno<>$lx<>$t<>$e<>$n<>$m<>$tm<>$h<>$OYA<>$smail<>$res<>\n");
				}
			elsif ($Q{oya} == $OYA) { push(@new,"$_\n"); }
			else { push(@tmp,"$_\n"); }
				if ($no == $Q{no}) {
				$flag=1;
				$lx2 = $lx + 1;
			}
		}
		if ($flag != 2) {
			# 마지막에 이어 붙임
			push(@new,"$count<>$Q{no}<>$lx2<>$Q{sub}<>$Q{town}<>$Q{name}<>$Q{message}<>$NOW_TIME<>$host<>$Q{oya}<>$Q{smail}<>0<>\n");
		}
		push(@new,@tmp);
	}
	# 최대 글 수 처리
	if (@new > $max) {
		foreach (0.. $#new) {
			my($p_file) = pop(@new);
			local($no,$reno,$lx) = split(/<>/, $p_file);
			if ($#new+1 <= $max && $reno eq 'no') {
				last;
				}
		}
	}

	unshift(@new,"$count<>$addr<>$NOW_TIME<>\n");
	foreach (@new) { utf8::encode($_) if utf8::is_utf8($_); }
	OpenAndCheck(GetPath($COTEMP_DIR,'treelog'));
	print OUT @new;
	close(OUT);
	CoDataCA();
	CoUnLock();

	$disp.="글쓰기를 완료했습니다. --".GetMenuTag('treebbs','[글 목록으로 돌아가기]');
1;
