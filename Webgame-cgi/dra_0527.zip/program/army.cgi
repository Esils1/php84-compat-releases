#!/usr/bin/perl
# 병영 2005/01/06 유래

$image[0]=GetTagImgKao("병영 안내인","army");
DataRead();
CheckUserPass();
ReadArmy();
RequireFile('inc-html-ownerinfo.cgi');

my $price=($DTevent{rebel}) ? 1500 : 1000;
my $level=DignityDefine($DT->{dignity},2);
$level=$DIGNITY[0] if !$level;

$disp.="<BIG>●병영</BIG><br><br>";
$disp.=$TB.$TR.$TD.$image[0].$TD."<SPAN>병영 안내인</SPAN>:여기에는 드워프 병사들이 당신의 명령을 기다리고 있습니다.<br>";
$disp.="병사를 모아 반란을 일으킬 수도 있고, 영주의 편에 서서 거리를 지킬 수도 있습니다.".$TRE.$TBE;

$disp.="<hr width=500 noshade size=1><BIG>●$DT->{shopname}의 병력 정보</BIG><br><br>";
$disp.="$TB$TR$TDB작위$TD$level <small>(경험값 ".($DT->{dignity}+0)."pt)$TRE";
$disp.="$TR$TDB고용 가능 수$TD".(($DT->{dignity}+0)*1000)."명$TRE";
$disp.="$TR$TDB고용 비용$TD@".GetMoneyString($price)."$TRE";
$disp.="$TR$TDB고용 병력$TD".($ARMY{$DT->{id}}+0)."명$TRE";
$disp.="$TR$TDB상태$TD".($RIOT{$DT->{id}} ? "<SPAN>반란</SPAN>" : "평상").$TRE;
$disp.=$TBE;

ArmyBuy();
if ($ARMY{$DT->{id}})
	{
	ArmyFire();
	ArmyRebel() if !$DTevent{rebel};
	ArmyAction() if $DTevent{rebel} && !$RIOT{$DT->{id}};
	}
OutSkin();
1;


sub ArmyBuy
{
my $usetime=60*40;
my $limit= ($DT->{dignity}+0)*1000 - $ARMY{$DT->{id}};
$disp.="<hr width=500 noshade size=1>";
$disp.='<BIG>●고용</BIG>:병사를 고용하려면 작위를 올려야 합니다.<BR>',return if $limit <= 0;
$disp.='<BIG>●고용</BIG>:자금이 부족합니다<BR>',return if $DT->{money}<$price;
$disp.='<BIG>●고용</BIG>:시간이 부족합니다<BR>',return if GetStockTime($DT->{time})<$usetime;

	$disp.=<<STR;
	<FORM ACTION="action.cgi" $METHOD>
	<INPUT TYPE=hidden NAME=key VALUE="army-s">
	$USERPASSFORM
	<INPUT TYPE=HIDDEN NAME=bk VALUE="army">
	<INPUT TYPE=hidden NAME=mode VALUE="plus">
	<BIG>●고용</BIG>: 병사를 
	<SELECT NAME=cnt1>
	<OPTION VALUE="0" SELECTED>
STR
	$money=int($DT->{money}/$price);
	$msg{1000}=1000;
	$msg{5000}=5000;
	$msg{10000}=10000;
	$msg{20000}=20000;
	$msg{$limit}="$limit(고용최대)";
	$msg{$money}="$money(자금최대)";
	my $oldcnt=0;
	foreach my $cnt (sort { $a <=> $b } (1000,5000,10000,20000,$limit,$money))
	{
		last if $cnt>$money || $cnt>$limit || $cnt==$oldcnt;
		$disp.="<OPTION VALUE=\"$cnt\">$msg{$cnt}";
		$oldcnt=$cnt;
	}
	$disp.=<<STR;
	</SELECT>
	 인,또는 
	<INPUT TYPE=TEXT SIZE=7 NAME=cnt2> 인
	<INPUT TYPE=SUBMIT VALUE="고용하기">
STR
	$disp.="(소요 시간:".GetTime2HMS($usetime).")</FORM>";
}


sub ArmyFire
{
my $usetime=60*10;
my $stock=($ARMY{$DT->{id}}+0);
$disp.="<hr width=500 noshade size=1>";
$disp.='<BIG>●해고</BIG>:시간이 부족합니다<BR>',return if GetStockTime($DT->{time})<$usetime;

	$disp.=<<STR;
	<FORM ACTION="action.cgi" $METHOD>
	<INPUT TYPE=hidden NAME=key VALUE="army-s">
	$USERPASSFORM
	<INPUT TYPE=HIDDEN NAME=bk VALUE="army">
	<INPUT TYPE=hidden NAME=mode VALUE="fire">
	<BIG>●해고</BIG>: 병사를 
	<SELECT NAME=cnt1>
	<OPTION VALUE="0" SELECTED>
STR
	$msg{1000}=1000;
	$msg{5000}=5000;
	$msg{10000}=10000;
	$msg{20000}=20000;
	$msg{$stock}="$stock(병력최대)";
	my $oldcnt=0;
	foreach my $cnt (sort { $a <=> $b } (1000,5000,10000,20000,$stock))
	{
		last if $stock<$cnt || $cnt==$oldcnt;
		$disp.="<OPTION VALUE=\"$cnt\">$msg{$cnt}";
		$oldcnt=$cnt;
	}
	$disp.=<<STR;
	</SELECT>
	 인,또는 
	<INPUT TYPE=TEXT SIZE=7 NAME=cnt2> 인
	<INPUT TYPE=SUBMIT VALUE="해고하기">
STR
	$disp.="(소요 시간:".GetTime2HMS($usetime).")</FORM>";
}


sub ArmyRebel
{
return if ($STATE->{leader}==$DT->{id});
my $usetime=60*30;
$disp.="<hr width=500 noshade size=1>";
$disp.='<BIG>●반란 발생</BIG>:반란에 필요한 병력이 부족합니다.<BR>',return if ($ARMY{$DT->{id}} < 2500);
$disp.='<BIG>●반란 발생</BIG>:시간이 부족합니다<BR>',return if GetStockTime($DT->{time})<$usetime;

	$disp.=<<STR;
	<FORM ACTION="action.cgi" $METHOD>
	<INPUT TYPE=hidden NAME=key VALUE="army-s">
	$USERPASSFORM
	<INPUT TYPE=HIDDEN NAME=bk VALUE="army">
	<INPUT TYPE=hidden NAME=mode VALUE="rebelon">
	<BIG>●반란 발생</BIG>: 
	<INPUT TYPE=TEXT NAME=cmd SIZE=10 VALUE="">
	(rebel 라고 입력)
	반란을 <INPUT TYPE=SUBMIT VALUE="시작하기">
STR
	$disp.="(소요 시간:".GetTime2HMS($usetime).")</FORM>";
}


sub ArmyAction
{
my $usetime=60*20;
$disp.="<hr width=500 noshade size=1>";
$disp.='<BIG>●반란 가담</BIG>:시간이 부족합니다<BR>',return if GetStockTime($DT->{time})<$usetime;

	$disp.=<<STR;
	<FORM ACTION="action.cgi" $METHOD>
	<INPUT TYPE=hidden NAME=key VALUE="army-s">
	$USERPASSFORM
	<INPUT TYPE=HIDDEN NAME=bk VALUE="army">
	<INPUT TYPE=hidden NAME=mode VALUE="rside">
	<BIG>●반란 가담</BIG>: 
	<INPUT TYPE=TEXT NAME=cmd SIZE=10 VALUE="">
	(rebel 라고 입력)
	반란에 <INPUT TYPE=SUBMIT VALUE="가담하기">
STR
	$disp.="(소요 시간:".GetTime2HMS($usetime).")</FORM>";

$usetime=60*20;
$disp.="<hr width=500 noshade size=1>";
$disp.='<BIG>●영주군</BIG>:시간이 부족합니다<BR>',return if GetStockTime($DT->{time})<$usetime;

	$disp.=<<STR;
	<FORM ACTION="action.cgi" $METHOD>
	<INPUT TYPE=hidden NAME=key VALUE="army-s">
	$USERPASSFORM
	<INPUT TYPE=HIDDEN NAME=bk VALUE="army">
	<INPUT TYPE=hidden NAME=mode VALUE="lside">
	<BIG>●영주군</BIG>: 
	병사를 영주의 편에 <INPUT TYPE=SUBMIT VALUE="보내기">
STR
	$disp.="(소요 시간:".GetTime2HMS($usetime).")</FORM>";
}
