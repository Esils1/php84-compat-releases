#!/usr/bin/perl
# 전체 사용자 관리 2004/01/20 유래

CheckUserPass();
OutError("") if !$MASTER_USER;

$NOMENU=1;
$Q{bk}="none";

if($Q{log})
{
	GetLog();
	OutSkin();
}
elsif($Q{mode} eq "delitem")
{
	$num=CheckCount($Q{num1},$Q{num2},0,$MAX_MONEY);
	OutError('소거하기아이템을지정해 주세요.') if !$num;

	Lock();
	DataRead();
	foreach my $DT (@DT)
	{
	$DT->{item}[$num-1]="";
		for(my $cnt=0; $cnt<$DT->{showcasecount}; $cnt++)
		{
		$DT->{showcase}[$cnt]=0 if ($DT->{showcase}[$cnt] == $num);
		}
	delete $DT->{exp}{$num};
	delete $DT->{itemtoday}{$num};
	delete $DT->{itemyesterday}{$num};
	}
	DataWrite();
	DataCommitOrAbort();
	UnLock();
	$disp.="아이템 No.".$num."을 플레이어 데이터에서 삭제했습니다.";
	OutSkin();
}
elsif ($Q{ecode})
{
	$Q{tlyear}-=1900 if $Q{tlyear}>=2000;
	$time=0;
	$time=GetTimeLocal($Q{tlsec},$Q{tlmin},$Q{tlhour},$Q{tlday},$Q{tlmon}-1,$Q{tlyear});
	OutError('일시 설정이 올바르지 않습니다.') if !$time;
	Lock();
	DataRead();
	require (GetPath($ITEM_DIR,"event"));
	my $key=$Q{ecode};
	OutError('이벤트 코드를 지정해 주세요.') if !defined($EVENT{$key});
	$DTevent{$key}=$time;
	DataWrite();
	DataCommitOrAbort();
	UnLock();
	$disp.="이벤트 코드 ".$Q{ecode}."을 발생시켰습니다.";
	OutSkin();
}
else
{
	GetMember();
	OutSkin();
}
1;

sub GetFileList
{
	my($dir,$file)=@_;
	opendir(DIR,$dir);
	my @list=map{$dir."/".$_}sort grep(/$file/ && !/^\.\.?$/,readdir(DIR));
	closedir(DIR);

	return @list;
}

sub GetLog
{
	$disp.=GetTagA("[loglist]","action.cgi?key=admin-sub2&log=.&$USERPASSURL")." ";
	foreach(GetFileList($LOG_DIR,"\\$FILE_EXT\$"))
	{
		/([\w\-]+)$FILE_EXT$/;
		$disp.=GetTagA("[$1 ".GetTime2FormatTime((stat($_))[9]+0,1)."]","action.cgi?key=admin-sub2&log=$1&$USERPASSURL")." ";
	}

	if($Q{log}eq'.')
	{
		$disp.="<hr>위 탭에서 열람할 로그를 선택해 주세요<br>";
		$disp.="[$LOG_DELETESHOP_FILE] 폐점/이전한가게의로그<br>";
		$disp.="[$LOG_ERROR_FILE] 각종 오류 로그<br>";
		$disp.="[$LOG_MOVESHOP_FILE] 이전 수신 로그<br>";
		$disp.="[$LOG_DEBUG_FILE] 데바구로그<br>";
		$disp.="[$LOG_GLOBAL_MSG_FILE] 전체 게시판 로그<br>";
		$disp.="[$LOG_MARK_FILE] 마-쿠로그<br>";
		$disp.="<hr>참고로 표시되는 내용에는 실제 비밀번호가 포함될 가능성이 있으므로 주의해 주세요.";
	}
	else
	{
		open(IN,GetPath($LOG_DIR,$Q{log})) or OutError('존재하지 않습니다 '.$Q{log});
		my @data=reverse(<IN>);
		close(IN);

		my($page,$pagestart,$pageend,$pagenext,$pageprev,$pagemax)
			=GetPage($Q{pg},30,scalar(@data));
		my $pagecontrol=GetPageControl($pageprev,$pagenext,"&log=$Q{log}","pg",$pagemax,$page);

		$disp.="<hr>$Q{log}<br>".$pagecontrol;
		$disp.="<table width=\"100%\">";
		$disp.="<tr><th>time<th>user<th>message<th>script<th>remoteaddr<th>remotehost<th>trueip</tr>";
		my $buf="";
		foreach(@data[$pagestart..$pageend])
		{
			chop;
			if(/^\d+\t/)
			{
				/^(\d+)\t.*\/(.+\.cgi)\t(.*?)\t(.*?)\t(.*?)\t(.*?)\t(.*)$/;
				my $msg=$7;
				if(index($msg,"\t")!=-1)
				{
					$msg=~s/\t/<BR>/g;
				}
				$disp.="<tr><td>".GetTime2FormatTime($1)."<td>$6<td>$msg<td>$2<td>$3<td>$4<td>$5</tr>";
				$disp.="<tr><td colspan=\"20\"><small>$buf</small></tr>" if $buf ne '';
				$buf="";
			}
			else
			{
				$buf="$_<br>$buf";
			}
		}
		$disp.="</table>";
		$disp.="<hr>".$pagecontrol;
	}
}

sub GetMember
{
	DataRead();
	if(open(IN,GetPath("user")))
	{
		while(<IN>)
		{
			chop;
			@_=split(/\t/);
			my $DT=$DT[$id2idx{$_[2]}];
			$DT->{remoteaddr}=$_[4];
			$DT->{last}=$_[3];
			$DT->{ua}=$_[5];
		}
		close(IN);
	}

	$disp.=$TB;
	$disp.=$TR;
	foreach(qw(IP No ID 이름 가게 이름 창업 최종login 자금 쓰레기 처리 시간 인기 매출 지출 진열대 수 IP 중복 허가))
	{
		$disp.=$TD.$_;
	}
	$disp.=$TRE;
	$cnt=1;

	foreach my $DT (@DT)
	{
		$count{$DT->{remoteaddr}}++ if $DT->{remoteaddr};
		open(SESS,"$SESSION_DIR/$DT->{name}.cgi");
		$DT->{clientinfo}=[<SESS>];
		close(SESS);
		shift(@{$DT->{clientinfo}});

		undef %sameAcount;
		undef %sameBcount;
		undef %sameCcount;
		undef %sameDcount;
		%samecount=();
		foreach(@{$DT->{clientinfo}})
		{
			chop;
			last if $_ eq "";
			my($date,$ip,$agent,$referer,$accept)=split(/\t/);
			$sameA{"$ip\t$agent\t$referer\t$accept"}++ if !($samecount{"$ip\t$agent\t$referer\t$accept"}++);
			$sameB{"$ip\t$agent\t$accept"}++           if !($samecount{"$ip\t$agent\t$accept"}++);
			$sameC{"$ip\t$agent"}++                    if !($samecount{"$ip\t$agent"}++);
			$sameD{"$ip"}++                            if !($samecount{"$ip"}++);
		}
	}

	foreach my $DT (@DT)
	{
		$disp.=$TR;

		$disp.=$TD.$DT->{remoteaddr};
		if($Q{host}ne'')
		{
			foreach(split(/!/,$DT->{remoteaddr}))
			{
				$disp.="[".gethostbyaddr(pack("C4",split(/\./)),2)."]";
			}
		}
		$disp.=$TD.$cnt++;
		$disp.=$TD.$DT->{id};
		$disp.=$TD.$DT->{name};
		$disp.=$TD.qq|<a href="#$DT->{id}">$DT->{shopname}</a>|;
		$disp.=$TD.GetTime2FormatTime($DT->{foundation});
		#$disp.=$TD.GetTime2FormatTime($DT->{lastlogin});
		$disp.=$TD.$DT->{last};
		$disp.=$TD.$DT->{money};
		$disp.=$TD.$DT->{trush};
		$disp.=$TD.GetTime2FormatTime($DT->{time});
		$disp.=$TD.$DT->{rank};
		$disp.=$TD.$DT->{saletoday};
		$disp.=$TD.$DT->{paytoday};
		$disp.=$TD.$DT->{profitstock};
		$disp.=$TD.$DT->{showcasecount};
		$disp.=$TD.$DT->{blocklogin};
		$disp.=$TD.($DT->{nocheckip} ? '중복허가':'');
		#$disp.=$TD.$DT->{comment};
		$disp.=$TRE;

		#my $warning=$DT->{ua}."<br>";
		my $warning="";
		undef %sameAcount;
		undef %sameBcount;
		undef %sameCcount;
		undef %sameDcount;
		%samecount=();
		foreach(@{$DT->{clientinfo}})
		{
			last if $_ eq "";
			my($date,$ip,$agent,$referer,$accept)=split(/\t/);
			if($sameA{"$ip\t$agent\t$referer\t$accept"}>1 && !$samecount{"$ip\t$agent\t$referer\t$accept"})
			{
				$warning.="●IP[$ip]&AGENT&ACCEPT&REFERER중복 ";
			}
			elsif($sameB{"$ip\t$agent\t$accept"}>1 && !$samecount{"$ip\t$agent\t$accept"})
			{
				$warning.="●IP[$ip]&AGENT&ACCEPT중복 ";
			}
			elsif($sameC{"$ip\t$agent"}>1 && !$samecount{"$ip\t$agent"})
			{
				$warning.="●IP[$ip]&AGENT중복 ";
			}
			elsif($sameD{"$ip"}>1 && !$samecount{"$ip"})
			{
				$warning.="●IP[$ip]중복 ";
			}
			$samecount{"$ip\t$agent\t$referer\t$accept"}++;
			$samecount{"$ip\t$agent\t$accept"}++;
			$samecount{"$ip\t$agent"}++;
			$samecount{"$ip"}++;
		}
		if($count{$DT->{remoteaddr}}>1)
		{
			$warning.="●TRUE IP[$DT->{remoteaddr}]중복 ";
		}

		if($warning ne '')
		{
			#$list=~s/\t/<br>/g;
			$disp.=$TR."<td colspan=\"20\"><a href=\"#$DT->{id}\">↑".$warning."</a>";
			$disp.="".$TRE;
		}
		my $list=join("<br>",grep($_ ne "\n",@{$DT->{clientinfo}}));
		$detail.="<pre><hr><a name=\"$DT->{id}\">●$DT->{shopname} $DT->{name}<hr>$list</pre>";
	}
	$disp.=$TBE;
	$disp.=$detail if (!$Q{only});
}

# timelocal 함수(일부 값을 초로 변환)
sub GetTimeLocal {
    my($Sec, $Min, $Hour, $Date, $Mon, $Year) = @_;
    my($sec, $min, $hour, $date, $mon, $year, $day, $yday, $isdst);

    my($cnt) = 0;
    my($Now) = time;
    while($cnt < 20) {
        ($sec, $min, $hour, $date, $mon, $year, $day, $yday, $isdst) = gmtime($Now+$TZ_JST);
        if ($year != $Year) {
            $Now -= ($year - $Year) * 31536000;
        } elsif ($mon != $Mon) {
            $Now -= ($mon - $Mon) * 2592000;
        } elsif ($date != $Date) {
            $Now -= ($date - $Date) * 86400;
        } elsif ($hour != $Hour) {
            $Now -= ($hour - $Hour) * 3600;
        } elsif ($min != $Min) {
            $Now -= ($min - $Min) * 60;
        } elsif ($sec != $Sec) {
            $Now -= ($sec - $Sec);
        } else {
            last;
        }
        $cnt++;
    }
    $Now = 0 if $cnt == 20;

    return $Now;
}
