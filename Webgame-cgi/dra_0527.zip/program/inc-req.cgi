#!/usr/bin/perl
# 의뢰 하청 함수 2003/09/25 유래

$MENUSAY=GetMenuTag('stock',	'[창고를 확인한다]')
	.GetMenuTag('req','[의뢰 일람에 돌아온다]')
	.GetMenuTag('town',	'[의뢰소를 나온다]');
$AucImg=GetTagImgKao("접수","req");

@REQnamelist=qw(
		no tm id itemno num prn pr mode
		);
ReadReq();
1;

sub ReadReq
{
$REQNONE=1;
undef @REQ;
open(IN,GetPath("request")) or return;
my @req=<IN>;
close(IN);
$Scount=$#req;
return if $Scount < 0;
foreach my $cnt(0..$Scount)
	{
	chop $req[$cnt];
	my @buf=split(/,/,$req[$cnt]); my $i=0;
	foreach (@REQnamelist) { $REQ[$cnt]->{$_}=$buf[$i];$i++;}
	undef $REQ[$cnt],next if ($REQ[$cnt]->{tm} < $NOW_TIME);	# 기한 마감을 삭제.
	$REQNONE=0;
	}
}

sub SearchReqIndex
{
	my($no)=@_;
	foreach(0..$Scount)
		{
		return $_ if ($no==$REQ[$_]->{no});
		}
	return -1;
}


