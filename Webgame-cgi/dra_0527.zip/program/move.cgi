#!/usr/bin/perl
# 이주시센터 2004/01/20 유래

OutError('이전이불가에설정되어이합니다') if !$MOVETOWN_ENABLE;
OutError('마을 코드가 설정되어 있지 않습니다') if !$TOWN_CODE;
my $townmaster=ReadTown($TOWN_CODE,'getown');
OutError('이전 경로가 지정되어 있지 않습니다') if !$townmaster;

DataRead();
CheckUserPass();

$disp.=GetTownListHTML();
OutSkin();
1;


sub GetTownListHTML
{
	my @townlist=ReadTown();
	return '<b>이전 가능한 마을을 찾을 수 없습니다</b>' if !scalar(@townlist);
	
	my $ret;
	$ret.='<BIG>●다른 마을로 이주</BIG><br><br>';
	$ret.=$TBT.$TRT.$TD;
	foreach(@townlist)
	{
		$ret.="<SPAN>".$_->{name}."</SPAN><br>";
		$ret.=GetTagA("[확인]","action.cgi?key=jump&town=$_->{code}",0,"_blank");
		$ret.=GetTagA("[이전손해]","action.cgi?key=move-f&$USERPASSURL&towncode=$_->{code}") if !$GUEST_USER;
		$ret.="<br>".$_->{comment}."<br><br>";
	}
	$ret.=$TRE.$TBE;
	return $ret;
}

