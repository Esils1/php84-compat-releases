#!/usr/bin/perl
# 농원 종자 구입 2005/03/30 유래

$NOITEM=1;
$NOMENU=1;
DataRead();
CheckUserPass();
OutError("영주가 없어서 장원 운영이 불가능합니다") if !defined($id2idx{$STATE->{leader}});
RequireFile('inc-manor.cgi');

	# 농원 설정 취득
	my $i=$id2idx{$STATE->{leader}};
	ReadDTSub($DT[$i],"lord");
	$MANORLORD=$DT[$i]->{_lord};

	ReadDTSub($DT,"seed");

my $usetime=10*60;
$i=int($Q{buy});

my @MYMANOR=@{$MANOR[$i]};
$price=$MANORLORD->{"price$i"};
OutError("bad request") if !$price;

$stock=$MANORLORD->{"count$i"};
OutError("판매 재고가 부족합니다") if !$stock;

RequireFile('inc-html-ownerinfo.cgi');

$disp.="<BIG>●구입</BIG><br><br>";

$disp.=$TB.$TR.$TDB."상품".$TD;
$disp.=GetTagImgManor($MYMANOR[1]).$MYMANOR[0].$TRE;
$disp.=$TR.$TDB."가격".$TD.'@'.GetMoneyString($price).$TRE;
$disp.=$TR.$TDB."판매 재고 수".$TD.$stock." 개".$TRE;
$disp.=$TR.$TDB.'현재 보유수'.$TD.($DT->{_seed}->{"base$i"} + 0)." 개".$TRE;
$disp.=$TBE;
$disp.="<hr width=500 noshade size=1>";

if($DT->{_seed}->{"base$i"}>=$tlimit)
	{$disp.='<BR>더 이상 구입할 수 없습니다<BR>';}
elsif($DT->{money}<$price)
	{$disp.='<BR>자금이 부족합니다<BR>';}
elsif(GetStockTime($DT->{time})<$usetime)
	{$disp.='<BR>시간이 부족합니다<BR>';}
else
{
	$disp.="<FORM ACTION=\"action.cgi\" $METHOD>";
	$disp.="<INPUT TYPE=HIDDEN NAME=key VALUE=\"manor-s\">";
	$disp.="$USERPASSFORM";
	$disp.="<INPUT TYPE=HIDDEN NAME=bk VALUE=\"manor\">";
	$disp.="<INPUT TYPE=HIDDEN NAME=it VALUE=\"$i\">";
	$disp.="수량을 ";
	$limit=$tlimit - $DT->{_seed}->{"base$i"};
	$money=$MAX_MONEY;
	$money=int($DT->{money}/$price) if $price;
	$msg{1}=1;
	$msg{10}=10;
	$msg{100}=100;
	$msg{1000}=1000;
	$msg{10000}=10000;
	$msg{$stock}="$stock(재고 최대)";
	$msg{$limit}="$limit(보유 최대)";
	$msg{$money}="$money(자금 최대)";
	$disp.="<SELECT NAME=num1 SIZE=1>";
	my $oldcnt=0;
	foreach my $cnt (sort { $a <=> $b } (1,10,50,$stock,$limit,$money))
	{
		last if $stock<$cnt || $DT->{money}<$cnt*$price || $cnt>$limit || $cnt==$oldcnt;
	
		$disp.="<OPTION VALUE=\"$cnt\">$msg{$cnt}";
		$oldcnt=$cnt;
	}
	$disp.="</SELECT> 개,또는 ";
	$disp.="<INPUT TYPE=TEXT NAME=num2 SIZE=5> 개 ";

	$disp.="<INPUT TYPE=SUBMIT VALUE='산다'>";

	$disp.="<br>(소요 시간:".GetTime2HMS($usetime).")";
	$disp.="</FORM>";
}

OutSkin();
1;
