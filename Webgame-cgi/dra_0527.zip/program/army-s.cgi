#!/usr/bin/perl
# 드워프 반란 처리 2005/01/06 유래

$NOMENU=1;
Lock();
DataRead();
CheckUserPass();
ReadArmy();

my $functionname=$Q{mode};
OutError("bad request") if !defined(&$functionname);
&$functionname;

WriteArmy();
RenewLog();
DataWrite();
DataCommitOrAbort();
UnLock();

$disp.=$TBT.$TRT.$TD.GetTagImgJob($DT->{job},$DT->{icon});
$disp.=$TD.GetMenuTag('army',	'[고용소로]');
$disp.=GetMenuTag('main','[현재 가게로 돌아가기]');
$disp.=$TRE.$TBE;
$disp.="<br>".$ret;
OutSkin();
1;


sub plus
{
my $limit=($DT->{dignity}+0)*1000 - $ARMY{$DT->{id}};
my $price=($DTevent{rebel}) ? 1500 : 1000;
my $usetime=60*40;
UseTime($usetime);

$num=CheckCount($Q{cnt1},$Q{cnt2},0,$limit);
OutError('수를 지정해 주세요.') if !$num;

$num=int($DT->{money}/$price) if $DT->{money}<$num*$price;
$num=0 if $num<0;
OutError('자금이 부족합니다.') if !$num;

$ARMY{$DT->{id}}+=$num;
$DT->{money}-=$num*$price;

$ret="고용소에서 드워프 병사를 ".$num."명 @".GetMoneyString($price)."(합계 ".GetMoneyString($price*$num).")에 고용했습니다";
$ret.="/".GetTime2HMS($usetime)."소모";
PushLog(0,$DT->{id},$ret);
}

sub fire
{
$num=CheckCount($Q{cnt1},$Q{cnt2},0,$ARMY{$DT->{id}});
OutError('수를 지정해 주세요.') if !$num;

my $usetime=60*10;
UseTime($usetime);
$ARMY{$DT->{id}}-=$num;

$ret="드워프 병사를 ".$num."명 해고했습니다";
$ret.="/".GetTime2HMS($usetime)."소모";
PushLog(0,$DT->{id},$ret);
}

sub rebelon
{
OutError('반란을 시작하려면 rebel 이라고 입력하세요.') if ($Q{cmd} ne "rebel");
OutError('병력이 부족합니다.') if ($ARMY{$DT->{id}} < 2500);

my $usetime=60*30;
UseTime($usetime);
$DTevent{rebel}=$NOW_TIME+86400*3;
$RIOT{$DT->{id}}=1;
$STATE->{safety}=int($STATE->{safety} * 9 / 10) if ($STATE->{safety} > 5000);

$ret="드워프 반란이 발생했습니다. 반란이 시작되었습니다!";
PushLog(2,0,$DT->{shopname}."의 영지에서 ".$ret);
$ret.="/".GetTime2HMS($usetime)."소모";
}

sub rside
{
OutError('반란에 참가하려면 rebel 이라고 입력하세요.') if ($Q{cmd} ne "rebel");

my $usetime=60*20;
UseTime($usetime);
$RIOT{$DT->{id}}=1;

$ret="반란에 참가했습니다!";
PushLog(3,0,$DT->{shopname}."이".$ret);
$ret.="/".GetTime2HMS($usetime)."소모";
}

sub lside
{
OutError('반란에 참가한 상태에서는 영주 편에 설 수 없습니다.') if ($RIOT{$DT->{id}});

my $usetime=60*20;
UseTime($usetime);
if ($STATE->{leader}==$DT->{id})
	{
	$STATE->{army}+=$ARMY{$DT->{id}};
	}
	else
	{
	$STATE->{robina}+=$ARMY{$DT->{id}};
	PushLog(3,0,$DT->{shopname}.'은 영주 편에 서서 병력을 지원했습니다.');
	}

delete $ARMY{$DT->{id}};
$ret="병력을 영주의 군대에 보냈습니다";
$ret.="/".GetTime2HMS($usetime)."소모";
}
