#!/usr/bin/perl
# 편지 2004/01/20 유래

$Q{mode}='new',  if ($Q{form} eq "make")&&($Q{ok}); 	# 전송 모드 설정
CoLock() if $Q{mode};

$NOITEM=1;
DataRead();
CheckUserPass();

$image[0]=GetTagImgKao("오손전이","help");
$WriteFlag=0;						# 갱신후라구.

ReadLetterName();
ReadLetter();

RequireFile('inc-letter-edit.cgi') if ($Q{mode});	# 각종 처리

if ($Q{form})
{
RequireFile('inc-letter-form.cgi');
}
else
{
RequireFile('inc-letter.cgi');
}

	if ($WriteFlag)
	{
	CoLock() if !$COLOCKED;
	WriteLetter();
	CoDataCA();
	CoUnLock();
	}
OutSkin();
1;
