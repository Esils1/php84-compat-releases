#!/usr/bin/perl
# 가게 목록 처리 2003/07/19 유래

$disp.="<BIG>●신문:가게 목록</BIG><br><br>";

my @itemlist=();
my %msg;
my $bar;

foreach my $DT (@DT)
{
	my $shopname=$DT->{shopname};
	my $name=$DT->{name};
	my $count=$DT->{dignity};
	next if !$count;
	my $num=0;
	foreach(1..$#DIG_POINT)
	{
		last if $count<$DIG_POINT[$_];
		$num++;
	}
	$msg{$num}.=$shopname.", ";
}

my $ret;
foreach (1..$#DIG_POINT) {
	$msg{$_} = substr($msg{$_},0,(length($msg{$_})-3)) if ($msg{$_});
	$ret=$TR.$TDB.DignityDefine($DIG_POINT[$_],2).$TD.$msg{$_}.$TRE.$ret;
}
$disp.="$TB$TR<td width=50>순위<td class=b width=570>가게 이름$TRE";
$disp.=$ret.$TBE;
1;
