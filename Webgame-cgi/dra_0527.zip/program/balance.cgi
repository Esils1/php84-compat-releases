#!/usr/bin/perl
# 현재가게상세 2004/01/20 유래

DataRead();
CheckUserPass();
RequireFile('inc-info.cgi');
OutSkin();
1;
