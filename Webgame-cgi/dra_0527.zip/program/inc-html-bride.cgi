#!/usr/bin/perl
# 주택 목록 표시 2005/03/30 유래

if ($Q{form} eq "pro" && !$GUEST_USER)
{
ProposeForm();
}
elsif ($Q{form} && !$GUEST_USER)
{
ConstForm();
}
else
{
BrideList();
}
1;

sub BrideList
{
my $i;
if (!$GUEST_USER && !$married)
{
$i="<br><a href=\"action.cgi?key=bride&form=pro&$USERPASSURL\">[청혼하기]</a>";
}

$disp.=<<STR;
$TBT$TRT$TD
<IMG width="96" height="192" SRC="$IMAGE_URL/map/church.png"><td width=10>$TD
$image[3]
<SPAN>신부</SPAN><br>
결혼에 대해 알고 계신가요?<br>
결혼하고 주택을 건설하면, 그곳에 보유 물품을 보관할 수 있습니다.<br>
주택을 보유하기 전까지는 이 교회의 보관함을 사용할 수 없습니다.<br>
소중한 사람과 함께 지낼 수 있는 곳을 마련해 보세요.$i
$TRE$TBE<br>
$TB$TR
$TDB점수
$TDB상태
$TDB상세
$TDB일수
$TDB보관품
$TRE
STR
@BRIDE=sort{$b->{point}<=>$a->{point}}@BRIDE;
foreach my $i(0..$Scount) {
	next if ($BRIDE[$i]->{mode}==-1) || !defined($BRIDE[$i]->{no});
	my ($ida,$idb)=($BRIDE[$i]->{ida},$BRIDE[$i]->{idb});
	$disp.=($DT->{id} == $ida || $DT->{id} == $idb) ? $TR.$TDB : $TR.$TD;
	$disp.='<b>No.'.($i+1).'</b><br>'.$BRIDE[$i]->{point}.'<td>';
	$disp.=    "<a href=\"action.cgi?key=bride&no=$BRIDE[$i]->{no}&$USERPASSURL\">" if (!$GUEST_USER);

	if (!$BRIDE[$i]->{mode})
	{
	$disp.=$image[2];
	$disp.=    "</a>" if (!$GUEST_USER);
	$disp.='<td>'.$DT[$id2idx{$ida}]->{shopname}.' 부터 <SPAN>'.$DT[$id2idx{$idb}]->{shopname}."</SPAN> 로";
	}
	else
	{
	$disp.=($BRIDE[$i]->{mode}==1)?$image[0]:$image[1];
	$disp.=    "</a>" if (!$GUEST_USER);
	$disp.='<td>'.$DT[$id2idx{$ida}]->{shopname}.' ＆ '.$DT[$id2idx{$idb}]->{shopname};
	}
	$disp.="<td align=center>".GetTime2found($NOW_TIME-$BRIDE[$i]->{tm});
	$disp.='<td>'.GetMoneyMessage($BRIDE[$i]->{money}).'<br>';
	foreach (0..$BRIDE[$i]->{mode}-1) { $disp.=GetTagImgItemType($BRIDE[$i]->{stock}[$_]);}
	}
$disp.=$TRE.$TBE;
}

sub ProposeForm
{
	OutError("bad request") if $married;
	$userselect="";
	foreach my $DTS (@DT)
	{
		$userselect.="<OPTION VALUE=\"$DTS->{id}\">$DTS->{name} ($DTS->{shopname})";
	}
$disp.=<<STR;
$TB$TR$TD
$image[3]
신부: 가족을 갖기를 원하십니까? 그렇다면 다음 주의 사항을 잘 읽어 주세요.<br>
·새 가정을 꾸리려면 결혼 자금이 <b>500$term[2]</b> 필요합니다.<br>
·결혼 상대는 신중하게 선택하세요. 그 사람과 함께할 수 있을지 잘 생각해 보세요.<br>
·사전에 충분히 대화해 보세요. 갑자기 청혼하면 상대가 곤란할 수 있습니다.<br>
·청혼한 쪽이 남편, 청혼을 받은 쪽이 아내가 됩니다.
$TRE$TBE<br>
<form action="action.cgi" $METHOD>
$MYFORM$USERPASSFORM
<INPUT TYPE=HIDDEN NAME=mode VALUE="new">
<BIG>●청혼</BIG>: $DT->{name} ($DT->{shopname})은
<SELECT NAME=tg>$userselect</SELECT>
에게<br>
함께 살아가고 싶다는 마음을 전합니다.
<INPUT TYPE=SUBMIT VALUE='청혼합니다'>
</FORM>
STR
}

sub ConstForm
{
$disp.=<<STR;
$TB$TR$TD
$image[3]
신부: 주택을 건설하시겠습니까? 그렇다면 다음 주의 사항을 잘 읽어 주세요.<br>
·자금이 <b>1500$term[2]</b> 필요합니다. 교회 보관함에서 지불됩니다.<br>
·주택을 세운 뒤에는 장소를 옮길 수 없습니다.<br>
$TRE$TBE
<form action="action.cgi" $METHOD>
$MYFORM$USERPASSFORM
<INPUT TYPE=HIDDEN NAME=mode VALUE="con">
<INPUT TYPE=HIDDEN NAME=idx VALUE="$Q{idx}">
<INPUT TYPE=HIDDEN NAME=place VALUE="$Q{form}">
<BIG>●주택</BIG>:지정한 장소에 주택을
<INPUT TYPE=SUBMIT VALUE='건설하기'>
</FORM>
STR
}
