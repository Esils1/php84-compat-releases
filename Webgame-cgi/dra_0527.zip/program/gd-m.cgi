#!/usr/bin/perl
# 길드 입단 2004/01/20 유래

CoLock() if ($Q{edit});
Lock() if ($Q{edit} eq "join");
DataRead();
CheckUserPass();
RequireFile('inc-gd.cgi');

@ENTRYnamelist=qw(
		no tm town id guild
		);
ReadEntry();

$Q{er}='gd';
RequireFile('inc-gd-entry.cgi') if ($Q{edit});
my $functionname=$Q{mode};
$functionname||="join";
OutError("bad request") if !defined(&$functionname);
&$functionname;

OutSkin();
1;


sub join
{
OutError("bad request") if ($DT->{guild});
$disp.=<<"HTML";
$TB$TR
$TD$image[0]$TD
<SPAN>길드 접수</SPAN>：입단하려면, 단장 또는 참모의 허가가 필요합니다.<br>
들어가고 싶은 길드의 입단 조건을 참조해, 문의해 보면 좋을 것입니다.
$TRE$TBE<br>
HTML
$disp.="길드전중에 입단할 수 없습니다",return if ($DTevent{guildbattle});
my $join="";
	foreach my $cnt(0..$Ecount)
		{
		next if ($ENTRY[$cnt]->{town} ne $MYDIR || $ENTRY[$cnt]->{id} != $DT->{id});
		my $guild=$ENTRY[$cnt]->{guild};
$join.=<<"HTML";
<form action="action.cgi" $METHOD>
$MYFORM$USERPASSFORM
<BIG>●$GUILD_DETAIL{$guild}->{shortname}</BIG>：입단 허가가 나와 있습니다. 
<INPUT TYPE=HIDDEN NAME=edit VALUE="join">
<INPUT TYPE=HIDDEN NAME=guild VALUE="$guild">
<INPUT TYPE=SUBMIT VALUE="입단한다">
</form><br>
HTML
	}
$disp.=($join) ? $join : "입단 허가가 나와 있지 않습니다";
}

sub submit
{
OutError("bad request") if (!$DT->{guild});
my $checkok;
$ckeckok=1 if ($GUILD_DETAIL{$DT->{guild}}->{leadt} eq $MYDIR && $GUILD_DETAIL{$DT->{guild}}->{leader} == $DT->{id});
$ckeckok=1 if ($GUILD_DETAIL{$DT->{guild}}->{$MYDIR} == $DT->{id});
OutError("bad request") if (!$ckeckok);

ReadLetterName();
$disp.=<<"HTML";
$TB$TR
$TD$image[0]$TD
<SPAN>길드 접수</SPAN>：누구의 입단을 허가합니까?<br>
한 번 허가하면, 철회는 할 수 없기 때문에 주의해 주십시오.
$TRE$TBE<br>
HTML
$disp.="길드 전시중에 허가할 수 없습니다",return if ($DTevent{guildbattle});
EntryList() if scalar(@MYENTRY);
EntryForm();
}

sub EntryList
{
	$disp.=<<"HTML";
$TB$TR
$TDB점명
$TDB 소속거리
$TDB 유효기간
$TRE
HTML

foreach my $i(@MYENTRY)
	{
	my($no,$town,$id)=($ENTRY[$i]->{no},$ENTRY[$i]->{town},$ENTRY[$i]->{id});
	my $sname=SearchLetterName($id,$town);
	$disp.=$TR.$TD.$sname;
	$disp.=$TD.$Tname{$town};
	$disp.="$TD 후 ".GetTime2HMS($ENTRY[$i]->{tm}-$NOW_TIME);
	}
$disp.=$TRE.$TBE."<br>";
}

sub EntryForm
{
$disp.=<<"HTML";
<FORM ACTION="action.cgi" $METHOD>
$MYFORM$USERPASSFORM
$TB
$TR$TDB<b>입단 허가</b>(어느쪽이든 1개)
HTML

my $r=int(scalar(@OtherDir) / 2 + 0.5) ;$r||=1;
foreach(0..$#OtherDir)
	{
	my $pg=$OtherDir[$_];
	$disp.=( ($_ % $r) ? "<br>" : $TD);
	$disp.="$Tname{$pg} <SELECT NAME=$pg><OPTION VALUE=\"\">선택";
	foreach my $i(0..$Ncount{$pg})
		{
		$disp.="<OPTION VALUE=\"$LID{$pg}[$i]\"".($Q{$pg}==$LID{$pg}[$i] ?' SELECTED' : '').">$LNAME{$pg}[$i]";
		}
	$disp.="</SELECT>\n";
	}
$disp.=<<"HTML";
$TRE$TBE
<br><INPUT TYPE=HIDDEN NAME=edit VALUE="new">
<INPUT TYPE=SUBMIT VALUE="입단을 허가한다">
</FORM>
HTML
}

sub joind
{
$disp.=<<"HTML";
$TB$TR
$TD$image[0]$TD
<SPAN>길드 접수</SPAN>：입단 수속을 완료했습니다.<br>
길드의 작전실등에서 인사해 두면 좋을 겁니다.
$TRE$TBE<br>
HTML
}

sub ReadEntry
{
	undef @ENTRY;
	undef @MYENTRY;
	open(IN,GetPath($COMMON_DIR,"entry")) or return;
	my @ent=<IN>;
	close(IN);
	$Ecount=$#ent;
	return if $Ecount < 0;
	foreach my $cnt(0..$Ecount)
		{
		chop $ent[$cnt];
		my @buf=split(/,/,$ent[$cnt]); my $i=0;
		foreach (@ENTRYnamelist) { $ENTRY[$cnt]->{$_}=$buf[$i];$i++;}
		undef $ENTRY[$cnt],next if ($ENTRY[$cnt]->{tm} < $NOW_TIME);	# 기한 마감을 삭제.
		push(@MYENTRY,$cnt) if ($ENTRY[$cnt]->{guild} eq $DT->{guild});
	}
}


