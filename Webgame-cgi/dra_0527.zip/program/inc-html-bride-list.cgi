#!/usr/bin/perl
# 주택 조작 2005/01/06 유래

$i=SearchBride($Q{no});
OutError('지정된 정보는 존재하지 않습니다') if ($i==-1);
($ida,$idb)=($BRIDE[$i]->{ida},$BRIDE[$i]->{idb});

if (!$BRIDE[$i]->{mode})
{
Agree();
}
elsif ($Q{d})
{
DivCheck();
}
else
{
House();
}
1;

sub Agree
{
if ($idb == $DT->{id}) {
	# 프로포즈 승낙
	$disp.=<<STR;
$TB$TR$TD
$image[3]
신부：프로포즈를 받습니까? 그렇다면 다음의 주의사항을 잘 들어 주세요.<br>
·결혼자금이 <b>500만 $term[2]</b>걸립니다.<br>
·사전에 서로 자주 이야기하세요. 그 사람과 서로 도와 갈 수 있을지 잘 생각하세요.<br>
·프로포즈를 한 쪽이 남편이 되고, 받은 쪽이 아내가 됩니다.
$TRE$TBE
<form action="action.cgi" $METHOD>
$MYFORM$USERPASSFORM
<INPUT TYPE=HIDDEN NAME=mode VALUE="agree">
<INPUT TYPE=HIDDEN NAME=idx VALUE="$BRIDE[$i]->{no}">
<BIG>●프로포즈를 받는다</BIG>：나 $DT->{name} ($DT->{shopname})는
$DT[$id2idx{$ida}]->{name} ($DT[$id2idx{$ida}]->{shopname})를 남편으로 해<br>
건강한 때도 병든 때도 그 몸을 함께 하는 일을
<INPUT TYPE=SUBMIT VALUE='맹세합니다'>
</FORM>
<hr width=500 noshade size=1>
<form action="action.cgi" $METHOD>
$MYFORM$USERPASSFORM
<INPUT TYPE=HIDDEN NAME=mode VALUE="dis">
<INPUT TYPE=HIDDEN NAME=idx VALUE="$BRIDE[$i]->{no}">
<BIG>●프로포즈를 거절한다</BIG>：그런 일은 말해지면 곤란하므로
<INPUT TYPE=SUBMIT VALUE='미안해요'>
</FORM>
STR
}
elsif ($ida == $DT->{id}) {
	# 프로포즈 철회
	$disp.=<<STR;
$TB$TR$TD
$image[3]
신부：프로포즈를 취소할 생각입니까.<br>
조금 부끄러울지도 모릅니다만 어쩔 수 없겠네요.
$TRE$TBE
<form action="action.cgi" $METHOD>
$MYFORM$USERPASSFORM
<INPUT TYPE=HIDDEN NAME=mode VALUE="end">
<INPUT TYPE=HIDDEN NAME=idx VALUE="$BRIDE[$i]->{no}">
<BIG>●프로포즈를 취소한다</BIG>：역시 아직 사랑이 부족했기 때문에
<INPUT TYPE=SUBMIT VALUE='취소합니다'>
</FORM>
STR
}
else {
	# 구경꾼
	$disp.=<<STR;
$TB$TR$TD
$image[3]
신부：<b>$DT[$id2idx{$ida}]->{name}</b>씨의 
<b>$DT[$id2idx{$idb}]->{name}</b>씨를 향한 구상은 진지합니다. 아멘.<br>
지금은 두 명을 따뜻하게 지켜봐 주세요.
$TRE$TBE
STR
}
}

sub House
{
$disp.=($BRIDE[$i]->{mode}==1)?$image[0]:$image[1];
$btitle=($BRIDE[$i]->{mode}==1)?"교회 > 공용 창고":"주택";
	# 무관계한 사람
	if ($DT->{id} != $ida && $DT->{id} != $idb) {
	$disp.=<<STR;
：<BIG>$DT[$id2idx{$ida}]->{shopname} ＆ $DT[$id2idx{$idb}]->{shopname}</BIG><br><br>
$TB$TR$TD
결혼하면, 마이 홈으로서 두 명의 공용 창고를 받을 수 있습니다.<br>
자금이나 상품을 둘 수가 있고 유지비도 걸리지 않습니다.
$TRE$TBE
STR
	return;
	}
	my $moneymes=GetMoneyString($BRIDE[$i]->{money});
	my $moneymax=GetMoneyString($BRIDE[$i]->{mode}*20000000);
	$disp.=<<STR;
：<BIG>$DT[$id2idx{$ida}]->{shopname} ＆ $DT[$id2idx{$idb}]->{shopname}</BIG><br><br>
$TB$TR
$TDB 비품
$TDB 수량<small>/최대</small>
$TRE
$TR$TD자금
$TD$moneymes<small>/$moneymax</small>
$TRE
STR

$formstock="<OPTION VALUE=\"-1\">자금(".GetMoneyString($BRIDE[$i]->{money}).")";
foreach (0..$BRIDE[$i]->{mode}-1) {
	my $stock=$BRIDE[$i]->{stock}[$_];
	my $cnt=$BRIDE[$i]->{cnt}[$_];
	$disp.='<tr><td>';
	$disp.=GetTagImgItemType($stock).$ITEM[$stock]->{name}.'<td>';
	$disp.=($cnt) ? ($cnt.'<small>/'.($ITEM[$stock]->{limit}*$HouseMax).$ITEM[$stock]->{scale}) : ' ';
	$formstock.="<OPTION VALUE=\"$_\">$ITEM[$stock]->{name}($cnt$ITEM[$stock]->{scale})" if ($cnt);
	}
$disp.=$TRE.$TBE."<hr width=500 noshade size=1>";

	my @sort;
	foreach(1..$MAX_ITEM){$sort[$_]=$ITEM[$_]->{sort}};
	my @itemlist=sort { $sort[$a] <=> $sort[$b] } (1..$MAX_ITEM);
	$formitem="<OPTION VALUE=\"-1\">자금(".GetMoneyString($DT->{money}).")";
	foreach(@itemlist)
	{
		my $cnt=$DT->{item}[$_-1];
		$cnt=0 if ($ITEM[$_]->{flag}=~/r/);	# 의뢰할 수 없는 아이템은 둘 수 없다.
		my $scale=$ITEM[$_]->{scale};
		$formitem.="<OPTION VALUE=\"$_\">$ITEM[$_]->{name}($cnt$scale)" if $cnt;
	}

$disp.=<<STR;
<form action="action.cgi" $METHOD>
$MYFORM$USERPASSFORM
<INPUT TYPE=HIDDEN NAME=id VALUE="$DT->{id}">
<INPUT TYPE=HIDDEN NAME=idx VALUE="$BRIDE[$i]->{no}">
<INPUT TYPE=HIDDEN NAME=no VALUE="$BRIDE[$i]->{no}">
<INPUT TYPE=HIDDEN NAME=mode VALUE="plus">
<BIG>●보관</BIG>：주택에 <SELECT NAME=it SIZE=1>
$formitem
</SELECT> (을)를 수량 <INPUT TYPE=TEXT NAME=num SIZE=5> (무기입으로 최대)
 <INPUT TYPE=SUBMIT VALUE='보관한다'>
</FORM>
<hr width=500 noshade size=1>
<form action="action.cgi" $METHOD>
$MYFORM$USERPASSFORM
<INPUT TYPE=HIDDEN NAME=id VALUE="$DT->{id}">
<INPUT TYPE=HIDDEN NAME=idx VALUE="$BRIDE[$i]->{no}">
<INPUT TYPE=HIDDEN NAME=no VALUE="$BRIDE[$i]->{no}">
<INPUT TYPE=HIDDEN NAME=mode VALUE="minus">
<BIG>●토리데</BIG>：주택으로부터 <SELECT NAME=it SIZE=1>
$formstock
</SELECT> (을)를 수량 <INPUT TYPE=TEXT NAME=num SIZE=5> (무기입으로 최대)
 <INPUT TYPE=SUBMIT VALUE='꺼낸다'>
</FORM>
STR

Reform() if ($BRIDE[$i]->{mode} > 2 && $BRIDE[$i]->{mode} < 7);

$disp.=<<STR;
<hr width=500 noshade size=1>
<form action="action.cgi" $METHOD>
$MYFORM$USERPASSFORM
<INPUT TYPE=HIDDEN NAME=id VALUE="$DT->{id}">
<INPUT TYPE=HIDDEN NAME=no VALUE="$BRIDE[$i]->{no}">
<INPUT TYPE=HIDDEN NAME=d VALUE="1">
<SPAN>이혼</SPAN>：
<INPUT TYPE=SUBMIT VALUE='이혼한다'>
(비품은 모두 파기)
</FORM>
STR
}

sub Reform
{
if ($BRIDE[$i]->{money} > $BRIDE[$i]->{mode} * 10000000)
	{
$disp.=<<STR;
<hr width=500 noshade size=1>
<form action="action.cgi" $METHOD>
$MYFORM$USERPASSFORM
<INPUT TYPE=HIDDEN NAME=id VALUE="$DT->{id}">
<INPUT TYPE=HIDDEN NAME=idx VALUE="$BRIDE[$i]->{no}">
<INPUT TYPE=HIDDEN NAME=no VALUE="$BRIDE[$i]->{no}">
<INPUT TYPE=HIDDEN NAME=mode VALUE="more">
<BIG>●증축</BIG>：
<INPUT TYPE=SUBMIT VALUE='증축한다'>
STR
$disp.="(비용".GetMoneyString($BRIDE[$i]->{mode} * 10000000).")</form>";
	}
	else
	{
$disp.=<<STR;
<hr width=500 noshade size=1>
<BIG>●증축</BIG>：자금이 충분하지 않습니다
STR
	}
}

sub DivCheck
{
	# 이혼 확인
	$disp.=<<STR;
$TB$TR$TD
$image[3]
신부：정말로 이혼하는 것입니까?
$TRE$TBE
<form action="action.cgi" $METHOD>
$MYFORM$USERPASSFORM
<INPUT TYPE=HIDDEN NAME=id VALUE="$DT->{id}">
<INPUT TYPE=HIDDEN NAME=idx VALUE="$BRIDE[$i]->{no}">
<INPUT TYPE=HIDDEN NAME=mode VALUE="divorce">
<SPAN>●이혼</SPAN>：
<INPUT TYPE=SUBMIT VALUE='이혼한다'>
(비품은 모두 파기)
</FORM>
STR
}

