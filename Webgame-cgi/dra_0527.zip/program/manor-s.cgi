#!/usr/bin/perl
# 농원 종자 구입 처리 2005/03/30 유래

$NOITEM=1;
$NOMENU=1;
Lock();
DataRead();
CheckUserPass();
OutError("영주가 없어서 장원 운영이 불가능합니다") if !defined($id2idx{$STATE->{leader}});
RequireFile('inc-manor.cgi');

	# 농원 설정 취득
	my $id=$id2idx{$STATE->{leader}};
	ReadDTSub($DT[$id],"lord");
	my $MANORLORD=$DT[$id]->{_lord};

	ReadDTSub($DT,"seed");

my $usetime=10*60;
$i=int($Q{it});

my @MYMANOR=@{$MANOR[$i]};
$price=$MANORLORD->{"price$i"};
OutError("bad request") if !$price;

$stock=$MANORLORD->{"count$i"};
OutError("판매 재고가 부족합니다") if ($stock < 1);

$num=CheckCount($Q{num1},$Q{num2},0,$tlimit - $DT->{_seed}->{"base$i"});
$num=$stock if ($num > $stock);
OutError('수량을 지정해 주세요.') if !$num;

$num=int($DT->{money}/$price) if $DT->{money}<$num*$price;
$num=0 if $num<0;

OutError('구입할 수량이 없습니다.') if !$num;
UseTime($usetime);

$DT->{_seed}->{"base$i"}+=$num;
$DT->{_seed}->{"time$i"}=$NOW_TIME + $ripetime;
$DT->{money}-=$num*$price;
$DT->{paytoday}+=$num*$price;
OutError("구입할 자금이 부족합니다") if ($DT->{money} < 0);

$MANORLORD->{"count$i"}-=$num;
$STATE->{money}+=$num*$price;
$STATE->{in}+=$num*$price;

my $ret="영주 농원에서 ".$MYMANOR[0]." ".$num.'개 @'.GetMoneyString($price)."(합계 ".GetMoneyString($price*$num).")를 구입".
        " / ".GetTime2HMS($usetime)." 소모";
PushLog(0,$DT->{id},$ret);

$disp.=$ret;

	WriteDTSub($DT[$id],"lord");
	WriteDTSub($DT,"seed");
RenewLog();
DataWrite();
DataCommitOrAbort();
UnLock();
OutSkin();
1;
