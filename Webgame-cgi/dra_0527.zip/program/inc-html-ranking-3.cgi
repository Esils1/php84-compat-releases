#!/usr/bin/perl
# 입상 목록 표시 2005/01/06 유래

$disp.="<BIG>●신문:입상 목록</BIG><br><br>";
$disp.=$TB.$TR;

	@DT=sort{$b->{rankingcount}<=>$a->{rankingcount}}@DT;

$disp.=$TDNW.$tdh_pt.GetTagImgKao($DT[0]->{name},$DT[0]->{icon});
$disp.=$TD."<SPAN>최다 입상</SPAN><br><b>".$DT[0]->{shopname}."</b>";
$disp.="<td>입상 횟수<br>".($DT[0]->{rankingcount}+0)."회";
$disp.="<td>".$DT[0]->{comment};

	@DT=sort{$b->{taxyesterday}<=>$a->{taxyesterday}}@DT;

$disp.=$TRE.$TR;
$disp.=$TDNW.$tdh_pt.GetTagImgKao($DT[0]->{name},$DT[0]->{icon});
$disp.=$TD."<SPAN>최고 납세</SPAN><br><b>".$DT[0]->{shopname}."</b>";
$disp.="<td>전기 납세액<br>".GetMoneyString($DT[0]->{taxyesterday});
$disp.="<td>".$DT[0]->{comment};

	@DT=sort{$b->{money}<=>$a->{money}}@DT;

$disp.=$TRE.$TR;
$disp.=$TDNW.$tdh_pt.GetTagImgKao($DT[0]->{name},$DT[0]->{icon});
$disp.=$TD."<SPAN>대상</SPAN><br><b>".$DT[0]->{shopname}."</b>";
$disp.="<td>자금<br>".GetMoneyString($DT[0]->{money});
$disp.="<td>".$DT[0]->{comment};

	@DT=reverse(@DT);

$disp.=$TRE.$TR;
$disp.=$TDNW.$tdh_pt.GetTagImgKao($DT[0]->{name},$DT[0]->{icon});
$disp.=$TD."<SPAN>가장 바쁜 가게</SPAN><br><b>".$DT[0]->{shopname}."</b>";
$disp.="<td>자금<br>".GetMoneyString($DT[0]->{money});
$disp.="<td>".$DT[0]->{comment};

	@DT=sort{$b->{costyesterday}<=>$a->{costyesterday}}@DT;

$disp.=$TRE.$TR;
$disp.=$TDNW.$tdh_pt.GetTagImgKao($DT[0]->{name},$DT[0]->{icon});
$disp.=$TD."<SPAN>유지비인지인지리스기</SPAN><br><b>".$DT[0]->{shopname}."</b>";
$disp.="<td>이전일 유지비<br>".GetMoneyString($DT[0]->{costyesterday});
$disp.="<td>".$DT[0]->{comment};

	@DT=sort{$b->{trush}<=>$a->{trush}}@DT;

$disp.=$TRE.$TR;
$disp.=$TDNW.$tdh_pt.GetTagImgKao($DT[0]->{name},$DT[0]->{icon});
$disp.=$TD."<SPAN>가장 한가한 가게</SPAN><br><b>".$DT[0]->{shopname}."</b>";
$disp.="<td>쓰레기<br>".GetCleanMessage($DT[0]->{trush});
$disp.="<td>".$DT[0]->{comment};

	@DT=sort{$b->{rank}<=>$a->{rank}}@DT;

$disp.=$TRE.$TR;
$disp.=$TDNW.$tdh_pt.GetTagImgKao($DT[0]->{name},$DT[0]->{icon});
$disp.=$TD."<SPAN>단이마대인기</SPAN><br><b>".$DT[0]->{shopname}."</b>";
$disp.="<td>인기<br>".GetRankMessage($DT[0]->{rank});
$disp.="<td>".$DT[0]->{comment};

	@DT=reverse(@DT);

$disp.=$TRE.$TR;
$disp.=$TDNW.$tdh_pt.GetTagImgKao($DT[0]->{name},$DT[0]->{icon});
$disp.=$TD."<SPAN>손님 응대</SPAN><br><b>".$DT[0]->{shopname}."</b>";
$disp.="<td>인기<br>".GetRankMessage($DT[0]->{rank});
$disp.="<td>".$DT[0]->{comment};

$disp.="</td></tr></table>";
1;
