#!/usr/bin/perl
# 영주 농원 2005/03/30 유래

$NOITEM=1;
DataRead();
CheckUserPass();
RequireFile('inc-manor.cgi');

$disp.="<BIG>●영주정보</BIG><br><br>";

my $MANORLORD;

if (defined($id2idx{$STATE->{leader}}))
	{
	my $i=$id2idx{$STATE->{leader}};
	$disp.=$TB.$TR.$TD.GetTagImgKao($DT[$i]->{name},$DT[$i]->{icon});
	$disp.=$TD."<SPAN>영주</SPAN> ： <b>".$DT[$i]->{name}."</b>";
	$disp.=DignityDefine($DT[$i]->{dignity})." <small>(".$DT[$i]->{shopname}.")</small><br>";
	$disp.=">> ".$DT[$i]->{comment};
	$disp.=$TRE.$TBE;

	# 영주 농원설정을취득
	ReadDTSub($DT[$i],"lord");
	$MANORLORD=$DT[$i]->{_lord};
	}
	else
	{
$disp.=$TB.$TR.$TD.GetTagImgKao($BAL_NAME,"bal");
$disp.=$TD."영주 ： <b>$BAL_NAME</b> <small>($BAL_JOB)</small><br>";
$disp.=">> 영주가 없군요. 곤란합니다!";
$disp.=$TRE.$TBE;
	}

	ReadDTSub($DT,"seed");
	my $seedlock=0;
	my $ripeflag=0;

$disp.="<br><BIG>●영주 농원</BIG><br><br>";
$disp.=$TB.$TR;
$disp.=$TDB."종".$TDB."판매 재고".$TDB."판매 가격".$TDB."현재 보유".$TD.$TDB."수확물".$TDB."매입 가격".$TDB."현재 보유".$TRE;

foreach my $i(0..$#MANOR)
	{
	my @MYMANOR=@{$MANOR[$i]};
	if ($DT->{_seed}->{"base$i"} && $DT->{_seed}->{"time$i"} < $NOW_TIME)
		{
		#성장 처리
		$DT->{_seed}->{"ripe$i"}+=$DT->{_seed}->{"base$i"};
		delete $DT->{_seed}->{"base$i"};
		delete $DT->{_seed}->{"time$i"};
		$seedlock++;
		}
	$disp.=$TR.$TD;
	$disp.=($MANORLORD->{"count$i"}) ? "<a href=\"action.cgi?key=manor-m&$USERPASSURL&buy=".$i."&bk=manor\">" : "<b>";
	$disp.=GetTagImgManor($MYMANOR[1]).$MYMANOR[0];
	$disp.=($MANORLORD->{"count$i"}) ? "</a>" : "</b>";
	$disp.=$TD.($MANORLORD->{"count$i"} + 0)." 개";
	$disp.=$TD."@".GetMoneyString($MANORLORD->{"price$i"});
	$disp.=$TD.($DT->{_seed}->{"base$i"} + 0)." 개";
	$disp.=$TD."→".$TD.GetTagImgManor($MYMANOR[3]).$MYMANOR[2];
	$disp.=$TD."@".GetMoneyString($MANORLORD->{"cost$i"});
	$disp.=$TD.($DT->{_seed}->{"ripe$i"} + 0)." 개".$TRE;
	$ripeflag+=$DT->{_seed}->{"ripe$i"};
	}
$disp.=$TBE;

if ($ripeflag)
	{
$disp.=<<"HTML";
	<br>
	<FORM ACTION="action.cgi" $METHOD>
	<INPUT TYPE=HIDDEN NAME=key VALUE="manor-r">
	<INPUT TYPE=HIDDEN NAME=bk VALUE="manor">
	$USERPASSFORM
<BIG>●수확물 매입</BIG>: 수확물을 영주 농원에 
<INPUT TYPE=SUBMIT VALUE="매입 요청하기">
	</FORM>
HTML
	}

if ($seedlock)
	{
	Lock();		#다른 파일을 동시에 접근하지 않으므로 잠금은 짧게 처리
	WriteDTSub($DT,"seed");
	DataCommitOrAbort();
	UnLock();
	}

if ($STATE->{leader}==$DT->{id})
	{
	$disp.=<<STR;
	<br>
	<FORM ACTION="action.cgi" $METHOD>
	<INPUT TYPE=HIDDEN NAME=key VALUE="manor-f">
	$USERPASSFORM
	<INPUT TYPE=HIDDEN NAME=form VALUE="plus">
	<INPUT TYPE=SUBMIT VALUE='농원 관리하기'>
	</FORM>
STR
	}

OutSkin();
1;

