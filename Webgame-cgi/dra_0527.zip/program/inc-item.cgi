#!/usr/bin/perl
# 아이템함수 2005/01/06 유래

package item; #변경불가

######################################################################
# ★아이템용 함수:로그 기록
# usage: WriteLog(중요도,대상 가게 ID,메시지)
#           중요도     0==일반 1==중요
#           대상 가게 ID 0==전체 가게 가게ID==개인
#           메시지 로그메시지
# return: 0 지정
######################################################################
sub WriteLog
{
	main::PushLog($_[0],$_[1],$_[2]);
	return 0;
}

######################################################################
# ★데바구용로그책키코미
# usage: DebugLog(메시지)
#           메시지 로그메시지
# return: 0 지정
######################################################################
sub DebugLog
{
	my($msg)=@_;
	main::WriteErrorLog($msg,$main::LOG_DEBUG_FILE) if $main::DEBUG_LOG_ENABLE;
	return 0;
}

######################################################################
# ★아이템용 함수:아이템 소모
# usage: UseItem(아이템번호,소모개수,메시지)
#           아이템번호 1~
#           소모개수     1~
#           메시지   표시메시지
# return: 0 지정
######################################################################
sub UseItem
{
	my($itemno,$count,$msg)=@_;

	$count=UseItemSub($itemno,$count,$DT);
	push(@{$USE->{result}->{useitem}},[$itemno,$count]);
	push(@{$USE->{result}->{usemsg}},$msg);
	return 0;
}
sub UseItemSub
{
	my($itemno,$count,$DT)=@_;
	
	$count=$DT->{item}[$itemno-1] if $DT->{item}[$itemno-1]<$count;
	$DT->{item}[$itemno-1]-=$count;
	
	return $count;
}

######################################################################
# ★아이템용 함수:아이템 취득
# usage: AddItem(아이템번호,취득개수,메시지)
#           아이템번호 1~
#           취득개수     1~
#           메시지   표시메시지
# return: 0 지정
######################################################################
sub AddItem
{
	my($itemno,$count,$msg)=@_;

	$count=AddItemSub($itemno,$count,$DT);
	push(@{$USE->{result}->{additem}},[$itemno,$count]);
	push(@{$USE->{result}->{addmsg}},$msg);
	return 0;
}
sub AddItemSub
{
	my($itemno,$count,$DT)=@_;
	
	$count=$main::ITEM[$itemno]->{limit}-$DT->{item}[$itemno-1] if $main::ITEM[$itemno]->{limit}<$DT->{item}[$itemno-1]+$count;
	$DT->{item}[$itemno-1]+=$count;
	
	return $count;
}

sub GetUserData
{
	return &main::GetUserData;
}

sub GetMoneyString
{
	return &main::GetMoneyString;
}

require "$main::ITEM_DIR/funcitem.cgi" if $main::DEFINE_FUNCITEM;
1;
