#!/usr/bin/perl
# 개별 사용자 관리 2005/03/30 유래

Lock();
DataRead();
CheckUserPass();
OutError('') if !$MASTER_USER || $USER ne 'soldoutadmin';

OutError('사용자를 찾을 수 없습니다') if !defined($name2idx{$Q{user}});
my $DT=$DT[$name2idx{$Q{user}}];

$Q{comment}="[".$Q{comment}."]" if $Q{comment} ne '';

# 중복 등록 및 접속 제한 관련
if($Q{nocheckip})
{
	$disp.='중복 등록 검사대상에서 제외했습니다',$DT->{nocheckip}=1 if $Q{nocheckip} eq 'nocheck';
	$disp.='중복 등록 검사대상으로 지정했습니다',$DT->{nocheckip}='' if $Q{nocheckip} eq 'check';
}

# 접속 제한 처리
if($Q{blocklogin})
{
	$Q{blocklogin}=$Q{blocklogin};
	if($Q{blocklogin} eq 'off')
	{
		$disp.='접속 제한을 해제했습니다';
		$DT->{blocklogin}='';
		$DT->{lastlogin}=$NOW_TIME;
	}
	elsif($Q{blocklogin} eq 'stop')
	{
		$disp.='경영 중지로 설정했습니다['.$Q{blocklogin}.']';
		$DT->{blocklogin}=$Q{blocklogin};
	}
	elsif($Q{blocklogin} ne '')
	{
		$disp.='접속 제한을 설정했습니다['.$Q{blocklogin}.']';
		$DT->{blocklogin}=$Q{blocklogin};
	}
}

#폐점
if($Q{closeshop} eq 'closeshop')
{
	CloseShop($DT->{id},'폐점');
	PushLog(1,0,"$Q{comment}$DT->{shopname}은 폐점되었습니다.") if (!$Q{log});

	$disp.="폐점 처리 완료";
	$DTblockip=$DT->{remoteaddr};
}

#아이템 지급(데바구에도사용가능합니다)
if($Q{senditem})
{
	my $itemno=$Q{senditem};
	my $ITEM=$ITEM[$itemno];
	my $itemcount=$Q{count};
	$itemcount+=$DT->{item}->[$itemno-1];
	$itemcount=$ITEM->{limit} if $itemcount>$ITEM[$itemno]->{limit};
	$DT->{item}->[$itemno-1]=$itemcount;
	
	PushLog(2,0,"$Q{comment}$DT->{shopname}에$ITEM->{name}이 지급되었습니다.") if $Q{comment};
	$disp.="$ITEM->{name} $Q{count}$ITEM->{scale} 아이템 지급료";
}

#자금 지급(데바구에도사용가능합니다)
if($Q{sendmoney})
{
	$DT->{money}+=$Q{sendmoney};
	#$DT->{saletoday}+=$Q{sendmoney};
	
	PushLog(2,0,"$Q{comment}$DT->{shopname}에자금이 지급되었습니다.") if $Q{comment};
	$disp.=GetMoneyString($Q{sendmoney})." 자금 지급료";
}

#보유 시간 지급(데바구에도사용가능합니다)
if($Q{sendtime})
{
	$disp.=$Q{sendtime}."시간 보유 시간 지급료";
	$Q{sendtime}=$Q{sendtime} * 3600;
	$DT->{time}-=$Q{sendtime};
	
	PushLog(2,0,"$Q{comment}$DT->{shopname}에“".GetTime2HMS($Q{sendtime})."”이 지급되었습니다.") if $Q{comment};
}

# 주석 처리하면 디버그에도 사용할 수 있습니다
if($Q{senddig})
{
	$disp.=$Q{senddig}."포인트 작위 경험치 지급";
	$DT->{dignity}+=$Q{senddig};
	
	PushLog(2,0,"$Q{comment}$DT->{shopname}에게 작위 경험치 ".($Q{senddig}+0)."포인트가 지급되었습니다.") if $Q{comment};
}

RenewLog();
DataWrite();
DataCommitOrAbort();
UnLock();

$disp="실행할 처리와 파라미터를 올바르게 선택/입력해 주세요" if $disp eq '';
$disp.=" <-- $DT->{shopname} [$DT->{name}] $Q{comment}";

$NOMENU=1;
$Q{bk}="none";
OutSkin();
1;
