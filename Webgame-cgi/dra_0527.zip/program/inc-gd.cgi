#!/usr/bin/perl
# 길드 하청 2004/02/28 유래

ReadGuild();
ReadGuildData();

$image[0]=GetTagImgKao("길드 접수","guild");
$disp.=GetMenuTag('gd','[길드 일람]');
if (!$GUEST_USER && !$DT->{guild})
	{
	$disp.=GetMenuTag('gd-m','[입단 수속]');
	$disp.=GetMenuTag('gd-f','[결성 선언]');
	$disp.='<hr width=500 noshade size=1>';
	}

if ($DT->{guild})
	{
	$disp.=GetMenuTag('gd-bbs','[작전실 '.GetTime2FormatTime((stat($COMMON_DIR.'/bbslog-'.$DT->{guild}.'.cgi'))[9]+0,1).']');
	$disp.=GetMenuTag('gd-i','[탐정실]','&cmd=info');
	if ($GUILD_DETAIL{$DT->{guild}}->{leadt} eq $MYDIR && $GUILD_DETAIL{$DT->{guild}}->{leader} == $DT->{id})
		{
		$disp.=GetMenuTag('gd-f','[집무실]');
		$disp.=GetMenuTag('gd-e','[인사실]','&mode=submit');
		$disp.=GetMenuTag('gd-m','[입단 허가]','&mode=submit');
		}
		else
		{
		if ($GUILD_DETAIL{$DT->{guild}}->{$MYDIR} == $DT->{id})
			{
			$disp.=GetMenuTag('gd-e','[인사실]','&mode=submit');
			$disp.=GetMenuTag('gd-m','[입단 허가]','&mode=submit');
			}
		$disp.=GetMenuTag('gd-e','[탈퇴 수속]','&mode=leave');
		}
	$disp.='<hr width=500 noshade size=1>';
	}
$disp.="<BIG>●길드 공관</BIG><br><br>";
1;


