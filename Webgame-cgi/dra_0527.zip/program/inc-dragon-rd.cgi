#!/usr/bin/perl
# 드래곤 경주 경주 표시 2005/03/30 유래

my $rcode=$Q{code};
$rcode||=0;
ReadRace($rcode);
my @MYRACE=@{$RACE[$rcode]};
my @R=@{$MYRACE[$RDS[1]]};
undef @RACE;
undef @MYRACE;	# 불필요한 배열은 해제

$disp.="<BIG>●드래곤 경주:".$RACETERM[$rcode]."</BIG><br><br>";
$disp.="$TB$TR$TD".GetTagImgKao("경주 접수","slime2").$TD;
$disp.="<SPAN>경주 접수</SPAN>:";

if ($RDS[0]>1) {
$disp.="현재 경주가 진행 중입니다.<br>";
$disp.="다음 접수 마감은 ".GetTime2FormatTime($DRTIME[$rcode + 1])." 입니다.";
	}
elsif ($RDS[0]==1) {
$disp.="출전 드래곤은 아래와 같이 지정되었습니다.<br>";
$disp.="경주 시작 시각은 ".GetTime2FormatTime($DRTIME[$rcode + 1])." 입니다.";
	}
else {
$disp.="지금은 출전 등록을 접수 중입니다.<br>";
$disp.="등록 마감은 ".GetTime2FormatTime($DRTIME[$rcode + 1])." 입니다.";
	}

$disp.=$TRE.$TBE."<br>";
$disp.="<b>".$R[0]."</b> (".$RACERANK[$R[1]].") ".$FIELDTYPE[$R[3]].$R[5]."km";
$disp.='<IMG class="i" SRC="'.$IMAGE_URL.'/dragonw'.($RDS[2] + 1).$IMAGE_EXT.'"> ';
$disp.="정원 ".$R[9]." 핸디캡";
$disp.=($R[2] ? "$R[2]만" : "없음");
$disp.=qq|<br><IMG class="i" SRC="$IMAGE_URL/guildprize$IMAGE_EXT">|;
$disp.="상금 ".$R[6]."만 - ".$R[7]."만 - ".$R[8]."만";
$disp.=qq| <input type="button" value="출전 상세" onclick="javascript:window.open('action.cgi?key=slime-l&mode=rd&rcode=$rcode','_blank','width=760,height=580,scrollbars')">|;
$disp.="<br><br>$TB$TR$TDB번호$TDB이름$TDB나이$TDB성별$TDB핸디캡$TDB목장$TDB마구간$TDB기수$TDB상금$TDB각질$TDB인기$TDB통과 타임$TRE";

foreach (0..$#RD)
	{
	next if !$RD[$_]->{name};
	$disp.=$TR;
	$disp.=$TD.$RD[$_]->{no};
	$disp.=$TD.GetTagImgDra($RD[$_]->{fm},$RD[$_]->{color}).$RD[$_]->{name};
	$disp.=$TD.GetTime2found($NOW_TIME-$RD[$_]->{birth});
	$disp.=$TD.$FM[$RD[$_]->{fm}];
	$disp.=$TD.($R[2] ? int($RD[$_]->{prize} / $R[2]) : "0");
	$disp.=$TD.$RD[$_]->{rcname};
	$disp.=$TD.$RD[$_]->{stname};
	$disp.=$TD.$RD[$_]->{jkname};
	$disp.=$TD.($RD[$_]->{prize} + 0)."만";
	$disp.=$TD.$STRATE[ $RD[$_]->{strate} ];
	$disp.=$TD.$RD[$_]->{pop};
	$disp.=$TD.GetRaceTime($RD[$_]->{time});
	$disp.=$TRE;
	}
$disp.=$TBE."<br>";

ReadRaceLog($rcode);
$disp.=$TB.$TR.$TD.GetTagImgKao("경주 접수","slime6","align=left ")."<SPAN>경주 아나운서</SPAN><br>".$RACELOG.$TRE.$TBE if ($RACELOG);
1;

sub ReadRaceLog
{
	my($f)=@_;
	$f||=0;
	my $fn=GetPath($COMMON_DIR,"dra-rlog$f");
	undef $RACELOG;
	open(IN,$fn) or return;
	read(IN,$RACELOG,-s $fn);
	close(IN);
}

