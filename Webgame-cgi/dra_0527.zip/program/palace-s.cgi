#!/usr/bin/perl
# 궁전 달성 처리 2004/01/20 유래

Lock();
RequireFile("inc-palace.cgi");
$image[0]=GetTagImgKao("왕","king",'align="left" ');
$image[1]=GetTagImgKao("대신","minister",'align="left" ');

DataRead();
CheckUserPass();

$evt=GetTownData('evt');
$evt=0 if (!$evt);
$level=DignityDefine($DT->{dignity});

$disp.="<BIG>●궁전</BIG><br><br>";

$shopname=$DT->{shopname};
$name=$DT->{name};
$need=$itemno[$evt];

if ( $DT->{item}[$need-1] < $count[$evt] )
	{
	$disp.='<TABLE cellpadding="26" width="570"><tr>';
	$disp.=qq|<TD style="background-repeat : repeat-x;background-image : url($IMAGE_URL/palace.png);" valign="top"><br><br>|;
	$disp.=$image[0].'무슨 일이냐, <b>'.$shopname.'</b>의 <b>'.$name.$level.'</b>여.<br>';
	$disp.='<b>'.GetTagImgItemType($need).$ITEM[$need]->{name}.' '.$count[$evt].$ITEM[$need]->{scale}.'</b>이 아직 모이지 않았구나!<br>';
	$disp.='혹시 '.$name.'이 여분을 숨겨 두고 있는 것은 아니냐?';
	$disp.='<br>어서 사명을 달성하거라. 절대 잊어서는 안 된다.'.$TRE;
	$disp.=$TBE."<br>왕은 크게 노하여 돌아갔습니다."; 
	}
	else
	{
	$disp.='<TABLE cellpadding="26" width="570"><tr>';
	$disp.=qq|<TD style="background-repeat : repeat-x;background-image : url($IMAGE_URL/palace.png);" valign="top"><br><br>|;
	$disp.=$image[0].'훌륭하구나, <b>'.$shopname.'</b>의 <b>'.$name.$level.'</b>여.<br>';
	$disp.='<b>'.GetTagImgItemType($need).$ITEM[$need]->{name}.' '.$count[$evt].$ITEM[$need]->{scale}.'</b>은 확실히 받았다.<br>';
	$disp.='따라서 그대에게 포상으로 '.DignityDefine(1,1).'<b>작위 경험치</b>를 주겠다.'.$TRE;
	$disp.=$TBE."<br>";

	$DT->{item}[$need-1] -= $count[$evt];
	$DT->{dignity}++;
	$evt=int(rand(scalar(@itemno)));
	SetTownData('evt',$evt);

	PushLog(0,0,$DT->{shopname}.'이 왕의 사명을 달성했습니다.');
	RenewLog();
	DataWrite();
	DataCommitOrAbort();
	}
UnLock();
OutSkin();
1;
