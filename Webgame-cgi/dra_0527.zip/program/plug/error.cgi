#!/usr/bin/perl
# error 플러그인 2004/01/20 유래

sub OverLoad
{
	print <<"HTML";
Cache-Control: no-cache, must-revalidate
Pragma: no-cache
Content-type: text/html; charset=UTF-8

<html>
<head>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
<title>오류</title>
</head>
<body>
현재 서버 부하가 높은 상태입니다.
죄송하지만 잠시 후 다시 접속해 주세요.<br>
부하 $_[0] CPUs
</body></html>
HTML
	exit;
}

sub OutError
{
	UnLock() if $LOCKED;
	CoUnLock() if $COLOCKED;
	my %msg=
	(
		"not defined function"=>
			'정의되지 않은 함수를 호출했습니다. 관리자에게 아래 정보를 전달해 주세요.<hr>'.
			"not defined function '$_[1]'",
		"busy"=>
			'접속이<SPAN>집중</SPAN>되고 있습니다.<br>'.
			'번거롭지만 <SPAN>5초 이상 기다린 뒤</SPAN> 돌아가서 다시 접속해 주세요.<br>'.
			($AUTO_UNLOCK_TIME*2).'초 이상 지나도 접속할 수 없는 경우에는'.
			'<a href="mailto:'.$ADMIN_EMAIL.'">관리자에게 연락</a>해 주세요.',
		"no data"=>
			'<SPAN>데이터를 찾지 못했습니다</SPAN>. 번거롭지만 돌아가서 다시 시도해 주세요.'.
			'이 메시지가 계속 나오면 <a href="mailto:'.$ADMIN_EMAIL.'">관리자에게 연락</a>해 주세요.',
		"stop"=>
			'이 가게는<SPAN>점검 중</SPAN>입니다.'.
			'플레이를 재개하려면 <a href="mailto:'.$ADMIN_EMAIL.'">관리자에게 연락</a>해 주세요.',
		"no user"=>
			'존재하지 않는 ID입니다. ID를 확인해 주세요. →'.$_[1],
		"incorrect"=>
			'비밀번호가 틀렸습니다. 확인해 주세요. →'.$_[1],
		"error rename"=>
			'데이터갱신에실패했습니다',
		"timeout"=>
			'로그인 후 시간이 오래 지나 <SPAN>타임아웃</SPAN>되었습니다.<br>번거롭지만 상단에서 다시 로그인해 주세요.',
		"bad request"=>
			'<SPAN>잘못된 호출</SPAN>입니다. 브라우저의 “돌아가기/새로고침”을 사용한 경우에는 그렇게 하지 않도록 해 주세요.',
	);
	my $msg=defined $msg{$_[0]} ? $msg{$_[0]} : $_[0];
	$NOMENU=0;$Q{bk}="";
	$disp=<<"HTML";
	<BIG>●오류 보고</BIG><br><br>
	$msg
HTML
	OutSkin();
	exit;
}

sub WriteErrorLog
{
	eval(<<'__function__');
	my($msg,$file)=@_;
	
	return if !$LOG_SIZE_MAX || $file eq '';
	
	my $fn=GetPath($LOG_DIR,$file);
	rename($fn,GetPath($LOG_DIR,$file."-old")) if (stat($fn))[7]>$LOG_SIZE_MAX;
	open(ERR,">>$fn") or return;
	print ERR
		join("\t",
			(
				$NOW_TIME,
				$ENV{SCRIPT_NAME},
				$ENV{REMOTE_ADDR},
				$ENV{REMOTE_HOST},
				GetTrueIP(),
				$USER,
				$msg,
			)
		)."\n";
	close(ERR);
__function__
}

sub OutErrorBlockLogin
{
	OutError('
		지정한 ID는<SPAN>'.$_[0].'</SPAN> 때문에 접속이 제한되어 있습니다.<br>
		플레이 중인 “마을명”, “사용자명”, “가게 이름”을 적어서<a href="mailto:'.$ADMIN_EMAIL.'">관리자에게 연락</a>해 주세요.
	');
}
1;
