#!/usr/bin/perl
# use 플러그인 2004/02/28 유래

sub GetUseItemList
{
	return GetUseItemListSub(@item::USE);
}

sub GetUseItemListSub
{
	my(@USE)=@_;
	foreach my $USE (@USE)
	{
		my $ret=CheckUseItem($USE);
		$USE->{dispok}=1 if $ret==2;
		$USE->{useok}=1 if $ret==1;
	}
	return @USE;
}

sub CheckUseItem
{
	my($USE)=@_;
	my $jobfunc="item::_job_use_$USE->{no}_$DT->{job}_";
	if (defined &$jobfunc)
	{
	&$jobfunc($USE->{no});
	}
	else
	{
	$jobfunc="item::_job_use_0_$DT->{job}_";
	&$jobfunc($USE->{no}) if defined &$jobfunc;
	}
	
	my $funcbefore=$USE->{functionbefore};
	if($funcbefore)
	{
		my $ret=&{"item::".$funcbefore}($USE);
		return 2 if $ret==2;
		return 0 if $ret==1;
	}
	foreach my $item (@{$USE->{use}})
	{
		return 0 if $DT->{item}[$item->{no}-1]<$item->{count};
	}
	return 1;
}

sub GetUseItem
{
	my($no)=@_;

	foreach my $USE(@item::USE)
	{
		next if $USE->{no}!=$no;
		my $ret=CheckUseItem($USE);
		$USE->{dispok}=1 if $ret==2;
		$USE->{useok}=1 if $ret==1;
		return $USE;
	}
	return 0;
}

sub UseItem
{
	my($USE,$count)=@_;
	my $usetime=GetItemUseTime($USE);
	
	# 숙련도가 부족할 때 작업 가능 여부를 지정(불가능하면 count=0)
	$count=0 if $DT->{exp}{$USE->{itemno}}<$USE->{needexp};
	
	#필요직업
	$count=0 if ($USE->{needjob} && ($DT->{job} ne $USE->{needjob}));
	
	#필요점수
	$count=0 if ($USE->{needpoint} && ($DT->{point} < $USE->{needpoint}));
	
	#필요인기
	$count=0 if ($USE->{needpop} && ($DT->{rank} < $USE->{needpop}));
	
	#필요이벤트
	$count=0 if ($USE->{needevent} && !$DTevent{$USE->{needevent}});
	
	# 비용 부족 시 count를 조정
	$count=int($DT->{money}/$USE->{money}) if ($DT->{money}<$USE->{money}*$count)&&($USE->{money});
	
	# 시간 부족 시 count를 조정
	$count=int(($NOW_TIME-$DT->{time})/$usetime) if ($DT->{time}+$usetime* $count)>$NOW_TIME;
	
	# 수량 부족 시 count를 조정
	foreach my $item (@{$USE->{use}})
	{
		my $itemno=$item->{no};
		my $itemcount=$item->{count}*($item->{proba}==0 ? 1 : $count);
	
		if($DT->{item}[$itemno-1]<$itemcount)
		{
			$count=int($DT->{item}[$itemno-1]/$item->{count});
		}
	}
	
	#count확정
	$USE->{result}->{count}=$count;
	return if !$count; #count이0인라실패
	
	# 사용 변수 초기화
	$USE->{result}->{useitem}=[];
	$USE->{result}->{additem}=[];
	
	#시간와오금소모
	UseTime($usetime*$count);
	$DT->{money}-=$USE->{money}*$count;
	$DT->{paytoday}+=$USE->{money}*$count;
	
	#아이템소모
	foreach my $item (@{$USE->{use}})
	{
		my $itemno=$item->{no};
		my $itemcount=MakeAmount($item->{count}*$count,$item->{proba});
		if($itemcount)
		{
			$DT->{item}[$itemno-1]-=$itemcount;
			push(@{$USE->{result}->{useitem}},[$itemno,$itemcount]);
			push(@{$USE->{result}->{usemsg}},$item->{message});
		}
	}
	
	#아이템취득
	foreach my $item (@{$USE->{result}->{create}})
	{
		my $itemno=$item->{no};
		my $itemcount=MakeAmount($item->{count}*$count,$item->{proba});
		if($itemcount)
		{
			if($itemcount+$DT->{item}[$itemno-1]>$ITEM[$itemno]->{limit})
			{
				$itemcount-=$ITEM[$itemno]->{limit}-$DT->{item}[$itemno-1];
				my $trashitem="더 이상 보유하지 않으므로 ".$ITEM[$itemno]->{name}."을".($itemcount).$ITEM[$itemno]->{scale}." 폐기했습니다";
				$DTwholestore[$itemno-1]+=$itemcount;
				push(@{$USE->{result}->{trashmsg}},$trashitem);
				$itemcount=$ITEM[$itemno]->{limit}-$DT->{item}[$itemno-1];
			}
			$DT->{item}[$itemno-1]+=$itemcount;
			push(@{$USE->{result}->{additem}},[$itemno,$itemcount]);
			push(@{$USE->{result}->{addmsg}},$item->{message});
		}
	}
	
	# 시장 재고 체크
	CheckWholeStore();
	
	# 아이템 사용 함수 재확인
	RequireFile('inc-item.cgi');
	my $itemfunc="item::".$USE->{result}->{function};
	$itemfunc="" if !defined(&$itemfunc);
	
	# 아이템 사용 함수 호출
	if($itemfunc ne '')
	{
		# 변수 초기화
		@item::DT=@DT;
		$item::DTS=$DT[$USE->{arg}->{targetidx}]; #target가게
		$item::count=$USE->{result}->{count};
		$item::USE=$USE;
		$item::DT=$DT;
		@item::ITEM=@ITEM;
		
		$USE->{result}->{function_return}=&$itemfunc();
	}

	# 숙련도 처리
	if($USE->{exp})
	{
		# 숙련도 증가
		my $exp=$DT->{exp}->{$USE->{itemno}};
		$USE->{result}->{expold}=$exp+0;
		my $expplus=$USE->{exp}*$USE->{result}->{count};
		$expplus=1000-$exp if $exp+$expplus>1000;
		$DT->{exp}->{$USE->{itemno}}+=$expplus;
		
		# 숙련도 합계 체크
		my $expsum=0;
		foreach(values(%{$DT->{exp}}))
		{
			$expsum+=$_;
		}
		# 숙련도 초과 시 처리
		if($LIMIT_EXP>0 && $expsum>$LIMIT_EXP)
		{
			$expsum-=$LIMIT_EXP;
			
			my @key=sort { $DT->{exp}{$a} <=> $DT->{exp}{$b} }keys(%{$DT->{exp}});
			my $keycnt=$#key;
			foreach(@key)
			{
				next if $_==$USE->{itemno};
				my $expdown=int($expsum/$keycnt);
				$expdown=$DT->{exp}{$_} if $DT->{exp}{$_}<$expdown;
				$DT->{exp}{$_}-=$expdown;
				delete $DT->{exp}{$_} if !$DT->{exp}{$_};
				$expsum-=$expdown;
				$keycnt--;
			}
		}
	}
}

sub MakeAmount
{
	my($cnt,$p)=@_;
	return 0 if ($p <= 0);
	return $cnt if ($p >= 1000);
	if ($cnt < 20) {
		my $i=0;
		foreach(1..$cnt) { $i++ if rand(1000)<$p; }
		return $i;
		}
	# 난수
	$p = ($p / 1000);
	my $ave=$cnt*$p;
	my $sigma=$ave*(1-$p);
	my $t = (-2*$sigma*rand())*(sin(2*3.1415926535*rand()));
	return int( sqrt(($t < 0) ? -$t : $t)+$ave +0.5);
}

sub AddItem
{
	my($DT,$itemno,$count)=@_;
	
	$count=$ITEM[$itemno]->{limit}-$DT->{item}[$itemno-1] if $DT->{item}[$itemno-1]+$count>$ITEM[$itemno]->{limit};

	$DT->{item}[$itemno-1]+=$count;
	
	return $count;
}

sub GetBackUrl
{
	my($urltype,$page,$type)=split(/!/,$Q{bk} || $REFERER);
	return "" if $urltype eq 'none';
	
	my %url=(
		s	=>	"key=stock&$USERPASSURL",
		p	=>	"key=shop-b&$USERPASSURL&pg=$page",
		p2	=>	"key=shop-a&$USERPASSURL&pg=$page&t=2&itn=$type",
		m	=>	"key=shop-m&$USERPASSURL&pg=$page",
		sc	=>	"key=main&$USERPASSURL",
	);
	my $url=$url{$urltype}; $url||="key=$urltype&$USERPASSURL";
	
	return '<A HREF="action.cgi?'.$url.'">[돌아가기]</A>';
}

1;
