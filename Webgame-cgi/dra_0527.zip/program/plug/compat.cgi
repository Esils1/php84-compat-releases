#!/usr/bin/perl
# compat 플러그인 2004/01/20 유래

sub Compat
{
	OutError("호환되지 않는 프로그램이므로 실행할 수 없습니다");
}

sub OutHTML
{
	Compat();
}

1;
