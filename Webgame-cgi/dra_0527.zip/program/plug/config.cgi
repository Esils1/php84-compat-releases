#!/usr/bin/perl
# config 플러그인 2003/07/19 유래

sub ReadConfig
{
	open(IN,$_[0]) or return ();;
	my @data=();
	while(<IN>)
	{
		chop;
		s/#.*$//;
		# 각종 설정 파일에서는 보안상 “< > "”은 사용할 수 없고 “&”은 사용할 수 있습니다
		#s/&/&amp;/g;
		s/</&lt;/g;
		s/>/&gt;/g;
		s/"/&quot;/g;
		push(@data,$1,$2) if /^\s*(.+?)\s*=\s*(.+?)\s*$/;
	}
	close(IN);
	return @data;
}

1;
