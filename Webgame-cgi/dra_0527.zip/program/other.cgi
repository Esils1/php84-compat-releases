#!/usr/bin/perl
# 각종 수속 2005/01/06 유래

DataRead();
CheckUserPass();
RequireFile('inc-html-ownerinfo.cgi');

$disp.="<BIG>●각종 수속</BIG><br><br>";

$disp.=<<STR;
<FORM ACTION="action.cgi" $METHOD>
<INPUT TYPE=HIDDEN NAME=key VALUE=user>
<INPUT TYPE=HIDDEN NAME=mode VALUE=comment>
$USERPASSFORM
<SPAN>코멘트</SPAN>
<INPUT TYPE=TEXT NAME=cmt SIZE=36 VALUE="$DT->{comment}">
<INPUT TYPE=SUBMIT VALUE="변경한다">
</FORM>
STR

$i_rand=int(rand($ICON_NUMBER))+1;
$disp.=<<STR;
<hr width=500 noshade size=1>
<FORM ACTION="action.cgi" $METHOD>
<INPUT TYPE=HIDDEN NAME=key VALUE=user>
<INPUT TYPE=HIDDEN NAME=mode VALUE=icon>
$USERPASSFORM
<SPAN>점장 아이콘 변경</SPAN>：
<input type="button" value="아이콘 일람" onclick="javascript:window.open('action.cgi?key=icon','_blank','width=450,height=380,scrollbars')">
<SELECT NAME=icon>
<OPTION value="$i_rand" selected>랜덤</OPTION>
STR

foreach my $i(1..$ICON_NUMBER)
	{
	$disp.=qq|<OPTION value="$i">화상 $i</OPTION>|;
	}

$disp.=<<"STR";
</SELECT> 
<INPUT TYPE=SUBMIT VALUE="변경한다">
</FORM>
STR

$disp.=<<STR;
<hr width=500 noshade size=1>
<FORM ACTION="action.cgi" $METHOD>
<INPUT TYPE=HIDDEN NAME=key VALUE=user>
<INPUT TYPE=HIDDEN NAME=mode VALUE=shopname>
$USERPASSFORM
<SPAN>점포명 변경</SPAN>(개명 비용 $term[0]50,000$term[1])
<INPUT TYPE=TEXT NAME=rename SIZE=30 VALUE="">
<INPUT TYPE=SUBMIT VALUE="개명한다">
</FORM>
STR

$disp.=<<STR;
<hr width=500 noshade size=1>
<FORM ACTION="action.cgi" $METHOD>
<INPUT TYPE=HIDDEN NAME=key VALUE=user>
<INPUT TYPE=HIDDEN NAME=mode VALUE=owname>
$USERPASSFORM
<SPAN>점장명 변경</SPAN>(개명 비용 $term[0]50,000$term[1])
<INPUT TYPE=TEXT NAME=owname SIZE=20 VALUE="">
<INPUT TYPE=SUBMIT VALUE="개명한다">
</FORM>
STR

$disp.=<<STR;
<hr width=500 noshade size=1>
<FORM ACTION="action.cgi" $METHOD>
<INPUT TYPE=HIDDEN NAME=key VALUE=user>
<INPUT TYPE=HIDDEN NAME=mode VALUE=repass>
$USERPASSFORM
<SPAN>패스워드 변경</SPAN> ： 
<INPUT TYPE=TEXT NAME=pw1 SIZE=10 maxlength=12 VALUE="">신패스 
<INPUT TYPE=TEXT NAME=pw2 SIZE=10 maxlength=12 VALUE="">신패스재입력 
<INPUT TYPE=SUBMIT VALUE="변경한다">
</FORM>
STR


if ( ($NOW_TIME-$DT->{foundation}) > 3600*3 ) {
$disp.=<<STR;
<hr width=500 noshade size=1>
<FORM ACTION="action.cgi" $METHOD>
<INPUT TYPE=HIDDEN NAME=key VALUE=user>
<INPUT TYPE=HIDDEN NAME=mode VALUE=restart>
$USERPASSFORM
<BIG>●재출발(재시도)</BIG> ： 
<INPUT TYPE=TEXT NAME=rss SIZE=10 maxlength=12 VALUE="">확인을 위해 restart 라고 입력 
<INPUT TYPE=SUBMIT VALUE="다시 한다">
</FORM>
STR
} else {
$disp.=<<STR;
<hr width=500 noshade size=1>
<BIG>●재출발(재시도)</BIG> ： 
<b>창업 후 3시간 이내는 재출발할 수 없습니다</b>
STR
}

$disp.=<<STR;
<hr width=500 noshade size=1>
<FORM ACTION="action.cgi" $METHOD>
<INPUT TYPE=HIDDEN NAME=key VALUE=user>
<INPUT TYPE=HIDDEN NAME=mode VALUE=cls>
$USERPASSFORM
<BIG>●폐점(재등록 불가)</BIG> ： 
<INPUT TYPE=TEXT NAME=cls SIZE=10 maxlength=12 VALUE="">확인을 위해 closeshop 라고 입력 
<INPUT TYPE=SUBMIT VALUE="폐점">
</FORM>
STR

OutSkin();
1;

