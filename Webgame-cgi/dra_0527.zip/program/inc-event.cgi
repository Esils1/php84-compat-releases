#!/usr/bin/perl
# 이벤트함수 2005/01/06 유래

package event; #변경불가

######################################################################
# ★이벤트용 함수: 로그 기록
# usage:  WriteLog(중요도,대상 가게 ID,메시지)
#           중요도     0==일반 1==중요 2==정보
#           대상 가게 ID 0==전체 가게 가게ID==개인
#           메시지 로그메시지
# return: 0 지정
######################################################################
sub WriteLog
{
	main::PushLog($_[0],$_[1],$_[2]);
	return 0;
}

######################################################################
# ★데바구용로그책키코미
# usage: DebugLog(메시지)
#           메시지 로그메시지
# return: 0 지정
######################################################################
sub DebugLog
{
	my($msg)=@_;
	main::WriteErrorLog($msg,$main::LOG_DEBUG_FILE) if $main::DEBUG_LOG_ENABLE;
	return 0;
}

######################################################################
# ★시장 재고 확인: 이벤트 발생 판정용
# usage:  stock_le(아이템번호,개수)
# return: 1 시장 아이템 재고가 지정 개수 이하인 경우
#         0 위기이밖
######################################################################
sub stock_le
{
	my($itemno,$count)=@_;
	return 1 if $main::DTwholestore[$itemno-1]<=$count;
	return 0;
}

######################################################################
# ★시장 재고 확인: 이벤트 발생 판정용
# usage:  stock_ge(아이템번호,개수)
# return: 1 시장 아이템 재고가 지정 개수 이상인 경우
#         0 위기이밖
######################################################################
sub stock_ge
{
	my($itemno,$count)=@_;
	return 1 if $main::DTwholestore[$itemno-1]>=$count;
	return 0;
}

sub GetUserData
{
	return &main::GetUserData;
}

sub GetMoneyString
{
	return &main::GetMoneyString;
}

require "$main::ITEM_DIR/funcevent.cgi" if $main::DEFINE_FUNCEVENT;
1;
