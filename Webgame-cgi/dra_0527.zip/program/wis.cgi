#!/usr/bin/perl
# wis 2004/02/28 유래

$image[0]=GetTagImgKao("도우미","help");
DataRead();
CheckUserPass();
$disp.="<BIG>●wis</BIG><br><br>";

if ($Q{form})
{
WisWrite();
}
else
{
WisForm();
}
OutSkin();
1;


sub WisForm
{
	$disp.=<<"HTML";
$TB$TR
$TD$image[0]$TD
<SPAN>도우미</SPAN>: 상대에게 짧은 귓속말을 보낼 수 있습니다.<br>
실수하지 않도록 주의해 주세요.
$TRE$TBE<br>
<FORM ACTION="action.cgi" $METHOD>
$MYFORM$USERPASSFORM
<INPUT TYPE=HIDDEN NAME=mode VALUE="plus">
$TB
$TR$TDB<b>상대</b>
HTML

$disp.=$TD."<SELECT NAME=to><OPTION VALUE=\"-1\">－－상대선택－－";
	foreach (@DT)
	{
		$disp.="<OPTION VALUE=\"$_->{id}\">$_->{shopname}";
	}
$disp.="</SELECT>$TRE\n";

$disp.=<<"HTML";
$TR$TDB<b>내용</b>
$TD<INPUT TYPE=TEXT NAME=msg SIZE=60>$TRE
$TR$TD<SPAN>사용법</SPAN>$TD
·상대가 확인하기 전에 새 wis를 보내면 이전 wis는 사라집니다.<br>
·상대가 로그인하지 않은 경우 나중에 받을 수 있습니다.<br>
·채팅 대신 계속 사용하는 것은 피해주세요.
$TBE
<br><INPUT TYPE=HIDDEN NAME=form VALUE="plus">
<INPUT TYPE=SUBMIT VALUE="전송">
</FORM>
HTML
}

sub WisWrite
{
	my ($to,$msg)=($Q{to},$Q{msg});
	OutError("상대를 지정해 주세요.") if $to==-1;
	OutError("존재하지 않는 가게입니다.") if !defined($id2idx{$to});
	OutError("메시지를 입력해 주세요.") if !$msg;
	OutError('메시지가 너무 깁니다.') if length($msg)>72;
	$NOMENU=1;$Q{bk}="wis";
	$msg=~s/&/&amp;/g;
	$msg=~s/>/&gt;/g;
	$msg=~s/</&lt;/g;
	OpenAndCheck(GetPath($SUBDATA_DIR,$DT[$id2idx{$to}]->{id}."-wis"));
	print OUT "<SPAN>$DT->{name}</SPAN> > <b>$msg</b>";
	close(OUT);
	$disp.="wis를 전송했습니다.";
	return;
}

