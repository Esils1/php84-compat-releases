#!/usr/bin/perl
# 정산 처리 2005/03/30 유래

	foreach(keys(%GUILD))
	{
		$GUILD_DATA{$_}->{in}=0;
		$GUILD_DATA{$_}->{out}=0;
		delete($GUILD_DATA{$_}->{guild});
		unlink($COMMON_DIR."/".$_.".pl") if ($GUILD_DATA{$_}->{money} < 0);
	}
	
	if(defined($DT[0]))
	{
		# 해당 기수의 1위 가게 우승 횟수 증가
		$DT[0]->{rankingcount}++;
		
		# 우승자 발표
		my $DT=$DT[0];
		my $count=$DT->{rankingcount}==1 ? "첫 우승" : $DT->{rankingcount}."번째 우승";
		my $msg="이번 기수의 우승 점포는 ".$DT->{shopname}."님입니다. ".$count."을 축하드립니다.";
		PushLog(1,0,$msg);
		
		$msg="점수는 ".$DT->{point}."점";
		$msg.=", 2위와의 차이는 ".($DT->{point}-$DT[1]->{point})."점" if defined($DT[1]);
		$msg.="이었습니다.";
		PushLog(1,0,$msg);
	}
	
	require "$ITEM_DIR/funcupdate.cgi" if $DEFINE_FUNCUPDATE;
	
	# 정산 시 드래곤 경주 수익 처리
	DragonBalance();

	# 정산 시 사용자 지정 처리
	UpdateResetBefore() if defined(&UpdateResetBefore);

	# 정산 리셋(영주 관련)
	my $taxin=0;

	my $dtcount=0;
	foreach my $DT (@DT)
	{
		$dtcount++;
		
		# 운영자 부재
		if ($NOW_TIME-$DT->{foundation} > 43200 && $DT->{blocklogin} ne 'stop')
		{
			if ($DT->{lastlogin}+$EXPIRE_TIME<$NOW_TIME)
			{
			CloseShop($DT->{id},'운영자 부재');
			PushLog(1,0,$DT->{shopname}."이 운영자 부재로 폐점되었습니다.");
			}
		}

		# 드래곤 경주 수익
		if ($DT->{dragon})
			{
			PushLog(0,$DT->{id},"드래곤 경주 정산 ".GetMoneyString($DT->{dragon}));
			$DT->{money}+=$DT->{dragon};
			$DT->{drmoney}+=$DT->{dragon};
			$DT->{saletoday}+=$DT->{dragon} if ($DT->{dragon} > 0);
			$DT->{paytoday}-=$DT->{dragon} if ($DT->{dragon} < 0);
			}

		# 이전 기수 정보 보존
		$DT->{rankingyesterday}=$dtcount;
		$DT->{profitstock}=int(($DT->{profitstock}*$PROFIT_DAY_COUNT+$DT->{saletoday}-$DT->{paytoday})/($PROFIT_DAY_COUNT+1));
		$DT->{saleyesterday}=$DT->{saletoday};
		$DT->{saletoday}=0;
		$DT->{payyesterday}=$DT->{paytoday};
		$DT->{paytoday}=0;
		$DT->{itemyesterday}=$DT->{itemtoday};
		$DT->{itemtoday}={};
		$DT->{taxyesterday}=$DT->{taxtoday};
		$DT->{taxtoday}=0;
		
		# 보유 수량 초과 및 부정 값 보정
		foreach my $cnt (1..$MAX_ITEM)
		{
			$DT->{item}[$cnt-1]=$ITEM[$cnt]->{limit} if $DT->{item}[$cnt-1]>$ITEM[$cnt]->{limit};
			$DT->{item}[$cnt-1]=int($DT->{item}[$cnt-1]);
		}
		
		# 유지비 처리
		my $cost=int($DT->{costtoday});
		$cost+=$SHOWCASE_COST[$DT->{showcasecount}-1];
		$DT->{money}-=$cost;
		$DT->{paytoday}+=$cost;
		
		# 세입(영주 관련)
		$taxin+=$DT->{taxyesterday};

		#길드회비
		if($DT->{guild} ne '')
		{
			my $money=int($DT->{saleyesterday}*$GUILD{$DT->{guild}}->[$GUILDIDX_feerate]/1000);
			EditGuildMoney($DT->{guild},$money);
			$DT->{money}-=$money;
						# 길드 전력 변동
			$GUILD_DATA{$DT->{guild}}->{atk}=int($GUILD_DATA{$DT->{guild}}->{atk} *24 /25);
			$GUILD_DATA{$DT->{guild}}->{def}=int($GUILD_DATA{$DT->{guild}}->{def} *9 /10);
			$GUILD_DATA{$DT->{guild}}->{def}+=int($money/800);
			$GUILD_DATA{$DT->{guild}}->{def}=1000 if ($GUILD_DATA{$DT->{guild}}->{def}>1000);
		}
		
		$DT->{costyesterday}=$cost;
		$DT->{costtoday}=0;
		
		# 숙련도 감소 처리
		foreach my $key (keys(%{$DT->{exp}}))
		{
			$DT->{exp}{$key}-=int($DT->{exp}{$key}*$EXP_DOWN_RATE/1000) if $EXP_DOWN_RATE;
			$DT->{exp}{$key}-=$EXP_DOWN_POINT;
			delete $DT->{exp}{$key} if $DT->{exp}{$key}<=0;
		}

		# 작위 포인트 감소 처리
		if ($DT->{dignity} && rand(100) < 25)
		{
			my $i=int( ($DT->{dignity}) / 12) + 1;
			$DT->{dignity}-=$i;
		}
	}
	SortDT();
	
	# 영지 데이터 처리
	$STATE->{people}=$DTpeople;	# 이전 기수 인구를 보존.
	$DTpeople=(24000 * $DTusercount) + 100000 + ($STATE->{develop} * 30) + ($STATE->{safety} * 20);	#이전기상태에서인구지정.
	$STATE->{money}+=$taxin;
	$STATE->{in}=$taxin;
	$STATE->{develop}+=int(($STATE->{devem} / $STATE->{people} * 200) - ($STATE->{develop}/10) - rand(200));	# 500만 원 기준
	$STATE->{safety}+=int(($STATE->{safem} / $STATE->{people} * 200) - ($STATE->{safety}/10) - rand(200));	# 500만 원 기준

	if ($STATE->{army} + $STATE->{robina}< 10000)
		{
		# 병력이 부족할 때의 패널티
		$STATE->{safety}-=int( (10000 - $STATE->{army}- $STATE->{robina}) / 20);
		PushLog(2,0,"마을의 병력이 부족하여 치안이 악화되고 있습니다.");
		}
	$STATE->{develop}=1000 if $STATE->{develop} < 1000;
	$STATE->{safety}=1000 if $STATE->{safety} < 1000;
	my $armycost=200-int($STATE->{safety} / 100);
	$STATE->{out}=($STATE->{army}*$armycost) + $STATE->{devem} + $STATE->{safem};
	$STATE->{money}-=$STATE->{out};
	if ($DTevent{rebel})
		{
		$DTevent{rebel}=$NOW_TIME+86400*3;
		}
		else
		{
		RebelRobin();
		}
	$STATE->{army}+=$STATE->{robina};	# 예비 병력을 정규 병력으로 편입.
	if ($STATE->{money} < 0)
	{
		# 병력을 유지할 수 없음
		PushLog(2,0,"마을 자금이 바닥나 병력을 유지할 수 없게 되었습니다.");
		$STATE->{army}=int($STATE->{army} / 3);
		$STATE->{money}=0;
	}
	if (defined($id2idx{$STATE->{leader}}))
	{
	$STATE->{robina}=0;
	}
	else
	{
	$STATE->{robina}=$STATE->{army};
	$STATE->{army}=0;
	}

	# 정산 시 사용자 지정 처리(리세트후)
	UpdateResetAfter() if defined(&UpdateResetAfter);
	
	# 데이터 백업($BACKUP 값은 보관 기수 수)
	mkdir($BACKUP_DIR.$BACKUP,$DIR_PERMISSION) if !(-e $BACKUP_DIR.$BACKUP);
	rename($BACKUP_DIR.$BACKUP,$BACKUP_DIR."_work");
	foreach my $count (reverse(1..$BACKUP-1))
	{
		mkdir($BACKUP_DIR.$count,$DIR_PERMISSION) if !(-e $BACKUP_DIR.$count);
		rename($BACKUP_DIR.$count,$BACKUP_DIR.($count+1));
	}
	rename($BACKUP_DIR."_work",$BACKUP_DIR."1");
	
	foreach my $filetype (@BACKUP_FILES)
	{
		open(IN,GetPath($filetype));
		open(OUT,">".GetPath($BACKUP_DIR."1",$filetype));
		while(<IN>){print OUT $_;}
		close(OUT);
		close(IN);
	}
	
	# 비활성 세션 데이터(기한 만료)를 삭제
	opendir(SESS,$SESSION_DIR);
	my @dir=readdir(SESS);
	closedir(SESS);
	my $sessiontimeout=$NOW_TIME-$EXPIRE_TIME;
	foreach(map{"$SESSION_DIR/$_"}grep(/^.+\.cgi$/,@dir))
	{
		unlink $_ if (stat($_))[9]<$sessiontimeout; # $EXPIRE_TIME이 지나면 삭제
	}
	MakeGuildFile();
1;


sub RebelRobin
{
return if !defined($id2idx{$STATE->{leader}});
my $i=int(15000 - $STATE->{develop} - $STATE->{safety} - rand(2500));
my $ii=int(50000000 - $STATE->{money} - rand(5000000));
return if ($i > 1000)&&($ii > 5000000);
PushLog(2,0,$BAL_JOB.$BAL_NAME."이 수상한 움직임을 보이고 있습니다."),return if ($i > 0) && ($ii > 0);
if (rand(100) < 30)
	{
	$DTevent{rebel}=$NOW_TIME+86400*3;
	$STATE->{robinb}=10000;
	PushLog(2,0,$BAL_JOB.$BAL_NAME."이 마을에 잠입하여 반란을 일으켰습니다!");
	}
	else
	{
	PushLog(2,0,$BAL_JOB.$BAL_NAME."이 무언가를 꾸미고 있는 것 같습니다.");
	}
}

sub DragonBalance
{
	my $fn=GetPath($COMMON_DIR,"drapay-".$MYDIR);
	open(IN,$fn) or return;
	my @req=<IN>;
	close(IN);
	foreach (0..$#req)
		{
		chop $req[$_];
		my @buf=split(/\t/,$req[$_]);
		next if !defined($id2idx{$buf[0]});
		my $i=$id2idx{$buf[0]};
		$DT[$i]->{dragon}+=$buf[1];
		}
	unlink $fn;
}

