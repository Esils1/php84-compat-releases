#!/usr/bin/perl
# 이전폼 2005/01/06 유래

OutError('사용불가입니다') if !$MOVETOWN_ENABLE || !$TOWN_CODE;
my $townmaster=ReadTown($TOWN_CODE,'getown');
OutError('사용불가입니다') if !$townmaster;

DataRead();
CheckUserPass();

OutError('이전 가능한 마을을 찾을 수 없습니다') if !$Q{towncode};
$disp.=GetMoveShopForm($Q{towncode});
OutSkin();
1;

sub GetMoveShopForm
{
	my($towncode)=@_;
	
	my($town)=ReadTown($towncode);
	return '<b>이전 가능한 마을을 찾을 수 없습니다</b>' if !$town;
	
	my $disp="";
	
	my $dist=GetTownDistance($townmaster->{position},$town->{position});
	my $movetime=GetMoveTownTime($DT,$townmaster,$town);
	
	$disp.=$TB;
	$disp.="$TR$TDB이전할 마을$TD$town->{name}$TRE";
	$disp.="$TR$TDB댓글$TD$town->{comment}$TRE";
	$disp.="$TR$TDB거리$TD".($dist*80)."m$TRE";
	$disp.="$TR$TDB이동시간$TD".GetTime2HMS($movetime).' (지정)'.$TRE;
	$deny=0;
	
	sub GetMarkDeny
	{
		$deny=1,return " ←조건을 만족하지 않습니다" if ($_[0]);
		return "";
	}
	my @flag=();
	push(@flag,"이이전의이전부터 10 일이위".GetMarkDeny($NOW_TIME-GetUserDataEx($DT,'_so_move_in')<864000));	#추가
	push(@flag,"자금 ".GetMoneyString($town->{allowmoney})." 이위".GetMarkDeny($town->{allowmoney}>$DT->{money}+$DT->{moneystock})) if $town->{allowmoney} ne '';
	push(@flag,"자금 ".GetMoneyString($town->{denymoney})." 이아래".GetMarkDeny($town->{denymoney}<$DT->{money}+$DT->{moneystock}))  if $town->{denymoney} ne '';
	push(@flag,"길드 ".join("/",map{GetTagImgGuild($_,1,1)}split(/\W/,$town->{allowguild})).($town->{onlyguild} ? '':' 및 무소속 길드')." 의미".GetMarkDeny($DT->{guild} ne '' && !scalar(grep($_ eq $DT->{guild},split(/[^\w]+/,$town->{allowguild}))))) if $town->{allowguild} ne '';
	push(@flag,"길드 ".join("/",map{GetTagImgGuild($_,1,1)}split(/\W/,$town->{denyguild})).($town->{onlyguild} ? ' 및 무소속 길드':'')." 이밖".GetMarkDeny($DT->{guild} ne '' && scalar(grep($_ eq $DT->{guild},split(/[^\w]+/,$town->{denyguild}))))) if $town->{denyguild} ne '';
	push(@flag,"순위 입상 횟수 $town->{allowtopcount} 회이위".GetMarkDeny($town->{allowtopcount}>$DT->{rankingcount})) if $town->{allowtopcount} ne '';
	push(@flag,"순위 입상 횟수 $town->{denytopcount} 회이아래".GetMarkDeny($town->{denytopcount}<$DT->{rankingcount}))  if $town->{denytopcount} ne '';
	push(@flag,"개업 기간 ".GetTime2HMS($town->{allowfoundation})." 이위".GetMarkDeny($town->{allowfoundation}>$NOW_TIME-$DT->{foundation})) if $town->{allowfoundation} ne '';
	push(@flag,"개업 기간 ".GetTime2HMS($town->{denyfoundation})." 이아래".GetMarkDeny($town->{denyfoundation}<$NOW_TIME-$DT->{foundation}))  if $town->{denyfoundation} ne '';
	push(@flag,"길드 소속 필요 ".GetMarkDeny($DT->{guild} eq '')) if $town->{onlyguild} ne '';
	push(@flag,"길드 무소속 필요 ".GetMarkDeny($DT->{guild} ne '')) if $town->{noguild} ne '';
	push(@flag,"직업 ".join("/",map{$JOBTYPE{$_}}split(/\W+/,$town->{allowjob})).($town->{onlyjob} ? '':' 오요비직업불정')." 의미".GetMarkDeny($DT->{job} ne '' && !scalar(grep($_ eq $DT->{job},split(/\W+/,$town->{allowjob}))))) if $town->{allowjob} ne '';
	push(@flag,"직업 ".join("/",map{$JOBTYPE{$_}}split(/\W+/,$town->{denyjob})).($town->{onlyjob} ? ' 오요비직업불정':'')." 이밖".GetMarkDeny($DT->{job} ne '' && scalar(grep($_ eq $DT->{job},split(/\W+/,$town->{denyjob}))))) if $town->{denyjob} ne '';
	push(@flag,"직업가게의미 ".GetMarkDeny($DT->{job} eq '')) if $town->{onlyjob} ne '';
	push(@flag,"직업이 없는 가게만 가능 ".GetMarkDeny($DT->{job} ne '')) if $town->{nojob} ne '';
	$disp.="$TR$TDB이전할 마을건$TD·".join("<br>·",@flag)."$TRE" if scalar(@flag);
	$disp.=$TBE;
	
	return $disp if $deny;
	$disp.=<<"HTML";
		<hr width=500 noshade size=1>
		<form action="action.cgi" $METHOD>
		<input type=hidden name=key value="move-s">
		$USERPASSFORM
		<input type=hidden name=towncode value="$towncode">
		$TB$TR
		$TDB이전할 마을에서의 이름(ID)$TD<input type=text name=name value="$DT->{name}">(한글 입력 가능)$TRE
		$TR$TDB현재의비밀번호$TD<input type=password name=pass value="">$TRE$TBE
		<br><input type=submit value="이전손해시작">
		</form>
		<hr width=500 noshade size=1>
		<table><tr><td>이전 시 인계되지 않는 데이터는 아래와 같습니다. 그 외에는 대부분 그대로 인계됩니다.
		<ul>
		<li>이전 기수의 순위 정보
		<li>쓰레기 데이터(전체 폐기)
		</ul>
		아래 경우에는 이전한 가게 데이터가 손실될 수 있습니다.
		<ul>
		<li>시스템 개조 등으로 가게 데이터가 호환되지 않는 경우
		</ul>
		이아래의장합은이전할 수 없습니다.
		<ul>
		<li>이전할 마을이만원의장합
		<li>이전할 마을에동지이름(ID)및가게 이름이아루장합
		</ul></td></tr></table>
HTML
	return $disp;
}

