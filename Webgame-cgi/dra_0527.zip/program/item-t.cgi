#!/usr/bin/perl
# 아이템 처분 2005/01/06 유래

$NOMENU=1;
$Q{er}='stock';
Lock();
DataRead();
CheckUserPass();

$itemno=CheckItemNo($Q{item});
$itemname=$ITEM[$itemno]->{name};
$scale=$ITEM[$itemno]->{scale};
$count=CheckCount($Q{cnt1},$Q{cnt2},0,$DT->{item}[$itemno-1]);

if ($ITEM[$itemno]->{flag}=~/h/) {

OutError('잘못된 요청입니다') if ($ITEM[$itemno]->{flag}=~/t/);
OutError('해체할 수량을 지정해 주세요') if !$count;

$ret=$itemname."을".$count.$scale."해체했습니다";
$disp.=$ret;
$DT->{item}[$itemno-1]-=$count;

 }	else	{

OutError('잘못된 요청입니다') if ($ITEM[$itemno]->{flag}=~/t/);
OutError('폐기할 수량을 지정해 주세요') if !$count;

$ret=$itemname."을".$count.$scale."폐기했습니다";
$disp.=$ret;
$DT->{item}[$itemno-1]-=$count;
$DT->{trush}+=int($ITEM[$itemno]->{price} * $count / 5);	#쓰레기

$DTwholestore[$itemno-1]+=$count;
my $limit=0;
foreach $DT (@DT)
	{$limit+=$DT->{item}[$itemno-1];}

my $ITEM=$ITEM[$itemno];
my $limitcount=$ITEM->{wslimit}<0 ? -$ITEM->{wslimit} : int($ITEM->{wslimit}*($#DT+1));

if($limit+$DTwholestore[$itemno-1]>$limitcount)
{
	$limit=$limitcount if $limitcount<$limit;
	$DTwholestore[$itemno-1]=$limitcount-$limit;
}
$DTwholestore[$itemno-1]=0 if $DTwholestore[$itemno-1]<0;

	if ( $DT->{guild} && $ITEM[$itemno]->{price}) {
	ReadGuild();
	ReadGuildData();
	if ( $GUILD_DATA{$DT->{guild}}->{money} <= 0 ) {
		$disp.="<br>길드 보조금은 없었습니다";
		} else {
		my $guildmargin = int( $ITEM[$itemno]->{price} * $GUILD{$DT->{guild}}->[$GUILDIDX_dealrate] * $count / 1000 );
		$guildmargin = $GUILD_DATA{$DT->{guild}}->{money} if ($guildmargin > $GUILD_DATA{$DT->{guild}}->{money});
		$disp.="<br>길드에서 ".GetMoneyString($guildmargin)."의 보조금을 받았습니다";
		$ret.="/길드에서 ".GetMoneyString($guildmargin)." 보조금";
		EditGuildMoney($DT->{guild},-$guildmargin);
		$DT->{money}+=$guildmargin;
		WriteGuildData() ;
		}
	}
}

PushLog(0,$DT->{id},$ret);
RenewLog();
DataWrite();
DataCommitOrAbort();
UnLock();

OutSkin();
1;
