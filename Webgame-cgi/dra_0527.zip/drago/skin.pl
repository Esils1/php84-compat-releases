#!/usr/bin/perl
# 스킨 파일의 저작권 표시용입니다.
#
# 스태프 목록에서 스킨 제작자와 스킨에 사용한 소재를 표시할 수 있습니다.
# 필요한 경우 이 파일을 수정하세요.
# 스킨을 배포할 때는 이 파일도 함께 배포해 주세요.
#
# ----------- 아래 내용을 자유롭게 수정할 수 있습니다. -----------------------------

$disp.=<<"HTML";
<br><br>
<SPAN>음악</SPAN> : 마리코 님... <A HREF="http://moe.que.jp/mariko/free/" target="_blank">소재 배포처</A>
<br><br>
<SPAN>제목 이미지</SPAN> : 류진 님... <A HREF="http://dragon.xrea.jp/" target="_blank">용의 둥지 - Dragons Planet</A>
HTML

# ----------- 여기까지. 마지막의 “HTML” 행을 지우지 않도록 주의하세요. -----------------
1;
