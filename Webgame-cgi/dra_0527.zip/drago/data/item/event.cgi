foreach(
'happy	1	100					18000	18000	불길이 이 마을을 뒤덮었습니다.	불길은 조용히 사라졌습니다.	_local_now	',
'fire-sale	sale	300					21600	86400	불 속성 몬스터가 활발하게 움직입니다.			',
'cold-sale	sale	300					21600	86400	물 속성 몬스터가 활발하게 움직입니다.			',
'earth-sale	sale	300					21600	86400	땅 속성 몬스터가 활발하게 움직입니다.			',
'thunder-sale	sale	300					21600	86400	바람 속성 몬스터가 활발하게 움직입니다.			',
'sale-item	bazar	300					21600	86400	시장에서 바자가 시작되었습니다.			',
'sale-book	bazar	300					21600	86400	시장에서 세일이 시작되었습니다.			',
'dragonborn	8	1500	_local_start				0	0				',
'rebel	9	0									_local_now	',
'guildbattle	10	0			_local_end							',
)
{
	my $hash={};
	(
		$hash->{code},
		$hash->{group},
		$hash->{startproba},
		$hash->{startfunc},
		$hash->{startfuncparam},
		$hash->{endfunc},
		$hash->{endfuncparam},
		$hash->{basetime},
		$hash->{plustime},
		$hash->{startmsg},
		$hash->{endmsg},
		$hash->{func},
		$hash->{funcparam},
	)=split(/\t/);
	$EVENT{$hash->{code}}=$hash;
}
1;
