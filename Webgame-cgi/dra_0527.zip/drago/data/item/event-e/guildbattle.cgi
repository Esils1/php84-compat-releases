package event;
sub _local_end {
main::ReadGuild();
main::ReadGuildData();
@guildlist=sort{$b->{money}<=>$a->{money}}map{$main::GUILD_DATA{$_}->{guild}=$_;$main::GUILD_DATA{$_}}keys(%main::GUILD);
my $Dguild=$guildlist[0]->{guild};
main::SetTownData('dominion',$Dguild);
return 1,"길드“".$main::GUILD{$Dguild}->[$GUILDIDX_name]."”이 대항전에서 승리했습니다. 축하합니다.";

}
1;
