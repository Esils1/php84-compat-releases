package item;
 if($BUY->{whole}) { if (rand(1000) > 990 && $BUY->{num} > 10) { $count=AddItemSub(28,1,$BUY->{dt}); WriteLog(0,$BUY->{dt}{id},'시장에서 상품권이 '.$count.'장 당첨되었습니다.'); $main::ret.='<br>시장에서 상품권이 '.$count.'장 당첨되었습니다！'; } } 
1;
