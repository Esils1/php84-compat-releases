package event;
sub _local_start {
my $itemno=62;
my $itemto=63;
foreach my $DT (@DT)
{
next if !$DT->{item}[$itemno-1];
my $cnt=$DT->{item}[$itemno-1];
$cnt=$ITEM[$itemto]->{limit}-$DT->{item}[$itemto-1] if $DT->{item}[$itemto-1]+$cnt>$ITEM[$itemto]->{limit};
$DT->{item}[$itemno-1]-=$cnt;
$DT->{item}[$itemto-1]+=$cnt;
}
return 0;

}
1;
