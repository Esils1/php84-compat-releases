push(@EVENTMSG,'바람 속성 몬스터의 수요가 높아집니다.');
$ITEM[10]->{popular}=int($ITEM[10]->{popular}/2);
$ITEM[16]->{popular}=int($ITEM[16]->{popular}/2);
$ITEM[34]->{popular}=int($ITEM[34]->{popular}/2);
$ITEM[40]->{popular}=int($ITEM[40]->{popular}/3);
$ITEM[46]->{popular}=int($ITEM[46]->{popular}/3);
$ITEM[52]->{popular}=int($ITEM[52]->{popular}/3);
$ITEM[58]->{popular}=int($ITEM[58]->{popular}/3);
1;
