push(@EVENTMSG,'불길 때문에 마을이 술렁입니다.');
1;
