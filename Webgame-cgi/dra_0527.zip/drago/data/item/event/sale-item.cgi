push(@EVENTMSG,'시장에서바자-이줄와레테이합니다.');
$ITEM[73]->{plus}=2400;
$ITEM[74]->{plus}=2400;
$ITEM[75]->{plus}=2400;
1;
