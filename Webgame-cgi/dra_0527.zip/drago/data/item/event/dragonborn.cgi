push(@EVENTMSG,'드래곤탄생');
1;
