push(@EVENTMSG,'불 속성 몬스터의 수요가 높아집니다.');
$ITEM[7]->{popular}=int($ITEM[7]->{popular}/2);
$ITEM[13]->{popular}=int($ITEM[13]->{popular}/2);
$ITEM[31]->{popular}=int($ITEM[31]->{popular}/2);
$ITEM[37]->{popular}=int($ITEM[37]->{popular}/3);
$ITEM[43]->{popular}=int($ITEM[43]->{popular}/3);
$ITEM[49]->{popular}=int($ITEM[49]->{popular}/3);
$ITEM[55]->{popular}=int($ITEM[55]->{popular}/3);
1;
