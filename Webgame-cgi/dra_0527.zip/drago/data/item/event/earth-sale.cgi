push(@EVENTMSG,'땅 속성 몬스터의 수요가 높아집니다.');
$ITEM[9]->{popular}=int($ITEM[9]->{popular}/2);
$ITEM[15]->{popular}=int($ITEM[15]->{popular}/2);
$ITEM[33]->{popular}=int($ITEM[33]->{popular}/2);
$ITEM[39]->{popular}=int($ITEM[39]->{popular}/3);
$ITEM[45]->{popular}=int($ITEM[45]->{popular}/3);
$ITEM[51]->{popular}=int($ITEM[51]->{popular}/3);
$ITEM[57]->{popular}=int($ITEM[57]->{popular}/3);
1;
