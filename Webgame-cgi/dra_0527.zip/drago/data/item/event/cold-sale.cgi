push(@EVENTMSG,'물 속성 몬스터의 수요가 높아집니다.');
$ITEM[8]->{popular}=int($ITEM[8]->{popular}/2);
$ITEM[14]->{popular}=int($ITEM[14]->{popular}/2);
$ITEM[32]->{popular}=int($ITEM[32]->{popular}/2);
$ITEM[38]->{popular}=int($ITEM[38]->{popular}/3);
$ITEM[44]->{popular}=int($ITEM[44]->{popular}/3);
$ITEM[50]->{popular}=int($ITEM[50]->{popular}/3);
$ITEM[56]->{popular}=int($ITEM[56]->{popular}/3);
1;
