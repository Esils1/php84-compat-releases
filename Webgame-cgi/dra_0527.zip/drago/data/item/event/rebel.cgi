push(@EVENTMSG,'반란이발생코테이합니다.');
1;
