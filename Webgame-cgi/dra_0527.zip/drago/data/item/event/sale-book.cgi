push(@EVENTMSG,'시장에서세-루이줄와레테이합니다.');
$ITEM[76]->{plus}=2400;
$ITEM[77]->{plus}=2400;
$ITEM[78]->{plus}=2400;
$ITEM[79]->{plus}=2400;
1;
