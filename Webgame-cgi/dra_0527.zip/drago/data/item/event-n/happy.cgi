package event;
sub _local_now {
my $time=$main::TIMESPAN;
$time=10*3600 if $time>10*3600;
$time=int($time/36);
foreach(@DT)
{
$_->{rank}+=int(rand($time));
$_->{rank}=10000 if $_->{rank}>10000;
}
return 0;

}
1;
