package item;
$USE[0]={'code'=>'badgossip','no'=>0,'itemno'=>'26','name'=>'나쁜 소문 퍼뜨리기','info'=>'성공하면 상대 가게의 인기를 낮춥니다. 실패할 수도 있습니다...','scale'=>'회','action'=>'나쁜 소문 퍼뜨리기','money'=>0,'time'=>18000,'exptime'=>'14400','exp'=>'200','arg'=>'target|nocount','needpoint'=>'20000','result'=>{'function'=>'_local_1',},};
sub _local_1 {eval(<<'_eval_code_');
my $ret;if(rand(1000)<800 && !$DTS->{exp}{23}){$DTS->{rank}-=int($DTS->{rank}/3);$ret=$DTS->{shopname}.'에 대한 나쁜 소문 퍼뜨리기 작전이 성공했습니다';WriteLog(0,$DT->{id},$ret);WriteLog(2,0,$DTS->{shopname}.'의 나쁜 소문이 퍼져 인기가 떨어졌습니다.');}else{$DTS->{exp}{23}-=100;$DTS->{exp}{23}=0 if ($DTS->{exp}{23} < 0);$DT->{rank}-=int($DT->{rank}/4);$ret=$DTS->{shopname}.'에 대한 나쁜 소문 퍼뜨리기 작전은 실패했습니다';WriteLog(0,$DT->{id},$ret);WriteLog(3,0,$DT->{shopname}."이 ".$DTS->{shopname}.'에 대한 나쁜 소문을 퍼뜨리려 했던 것 같습니다.');}return $ret;
_eval_code_
}
$USE[1]={'code'=>'badgossip','no'=>1,'itemno'=>'26','name'=>'소매치기','info'=>'그렇게까지 몰렸다면 쓰는 수밖에 없습니다...','scale'=>'회','action'=>'소매치기','money'=>50000,'time'=>18000,'exptime'=>'14400','exp'=>'250','arg'=>'target|nocount','needpoint'=>'20000','result'=>{'function'=>'stole',},};

1;
