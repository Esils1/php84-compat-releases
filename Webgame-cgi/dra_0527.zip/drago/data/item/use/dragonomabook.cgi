package item;
$USE[0]={'code'=>'dragonomabook','no'=>0,'itemno'=>'64','name'=>'드래곤을 낳는 방법 조사','info'=>'드래곤 육성 방법을 알고 싶을 때','scale'=>'회','action'=>'조사하기','money'=>0,'time'=>600,'exptime'=>'600','arg'=>'nocount','result'=>{'function'=>'_local_1',},};
sub _local_1 {eval(<<'_eval_code_');
my $ret;$ret.="그러자 책 사이에서 연기가 피어오르고 노인이 나타났습니다.<br><br>";$ret.="<TABLE><tr><td>";$ret.=main::GetTagImgKao('라무우','ram')."불꽃 노인:<br>";$ret.="…후무,드래곤의육성을시메타이라는의지야인.<br>";$ret.="먼저은,알을소환하고미타라도우지야.<br>";$ret.="촉매가 충분히 모였다면 이 책을 사용해,<br>";$ret.="마법진부터알을 불러내기코와이할 수 있는은즈다이의우.";$ret.="</td></tr></table><br>";$ret.="말을 마치자 노인은 연기 속으로 사라졌습니다.";return $ret;
_eval_code_
}
$USE[1]={'code'=>'dragonomabook','no'=>1,'itemno'=>'64','name'=>'먹이 수량 확인','info'=>'드래곤 먹이가 얼마나 남았는지 확인합니다','scale'=>'회','action'=>'조사하기','money'=>0,'time'=>600,'exptime'=>'600','arg'=>'nocount','result'=>{'function'=>'feedcheck',},};
$USE[2]={'code'=>'dragonomabook','no'=>2,'itemno'=>'64','name'=>'용의알을생미출스','info'=>'마법의힘에서용의알을생미출합니다','scale'=>'회','action'=>'생미출스','money'=>0,'time'=>1800,'exptime'=>'600','exp'=>'20','use'=>[{'no'=>19,'count'=>1,'proba'=>0},{'no'=>1,'count'=>3,'proba'=>1000},{'no'=>2,'count'=>3,'proba'=>1000},{'no'=>3,'count'=>3,'proba'=>1000},{'no'=>4,'count'=>3,'proba'=>1000},{'no'=>5,'count'=>3,'proba'=>1000},{'no'=>6,'count'=>3,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'불타는 알을생미출했습니다','resultng'=>'아무 일도 일어나지 않았습니다...',},'create'=>[{'no'=>61,'count'=>20,'proba'=>850},],},};
sub _job_use_2_shaman_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
sub _job_use_2_warlock_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}

1;
