package item;
$USE[0]={'code'=>'book-make','no'=>0,'itemno'=>'20','name'=>'“기행문”을집필하기','info'=>'주변 지역을 돌아다닌 기억을 글로 남깁니다','scale'=>'회','action'=>'쓰기','money'=>0,'time'=>2700,'exptime'=>'900','exp'=>'20','use'=>[{'no'=>20,'count'=>1,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'여러 지도 시리즈가 완성되었습니다','resultng'=>'집필에 실패했습니다…',},'create'=>[{'no'=>21,'count'=>2,'proba'=>500},{'no'=>22,'count'=>2,'proba'=>500},],},};
sub _job_use_0_warlock_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[1]={'code'=>'book-make','no'=>1,'itemno'=>'20','name'=>'“군자 표변”을집필하기','info'=>'자신의 새로운 가능성을 책으로 정리합니다','scale'=>'회','action'=>'쓰기','money'=>0,'time'=>5400,'exptime'=>'1800','exp'=>'40','needexp'=>'100','use'=>[{'no'=>20,'count'=>1,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'“직업의 비밀”이 완성되었습니다','resultng'=>'집필에 실패했습니다…',},'create'=>[{'no'=>65,'count'=>3,'proba'=>500},],},};
$USE[2]={'code'=>'book-make','no'=>2,'itemno'=>'20','name'=>'“소환 연구”을집필하기','info'=>'소환 연구 성과를 책으로 정리합니다','scale'=>'회','action'=>'쓰기','money'=>0,'time'=>5400,'exptime'=>'1800','exp'=>'40','needexp'=>'200','use'=>[{'no'=>20,'count'=>1,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'“촉매의 비법”이 완성되었습니다','resultng'=>'집필에 실패했습니다…',},'create'=>[{'no'=>30,'count'=>4,'proba'=>500},],},};
$USE[3]={'code'=>'book-make','no'=>3,'itemno'=>'20','name'=>'“추리 소설”을집필하기','info'=>'치밀한 서스펜스는 의외로 실용적입니다','scale'=>'회','action'=>'쓰기','money'=>0,'time'=>5400,'exptime'=>'1800','exp'=>'40','needexp'=>'300','use'=>[{'no'=>20,'count'=>1,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'“금단의 책”이 완성되었습니다','resultng'=>'집필에 실패했습니다…',},'create'=>[{'no'=>26,'count'=>5,'proba'=>400},],},};
$USE[4]={'code'=>'book-make','no'=>4,'itemno'=>'20','name'=>'“용의 탄생”을집필하기','info'=>'용을 탄생시키는 방법을 책으로 정리합니다','scale'=>'회','action'=>'쓰기','money'=>0,'time'=>7200,'exptime'=>'3600','exp'=>'20','needexp'=>'500','needjob'=>'warlock','use'=>[{'no'=>20,'count'=>1,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'“드래고노마 법전”이 완성되었습니다','resultng'=>'집필에 실패했습니다…',},'create'=>[{'no'=>64,'count'=>2,'proba'=>500},],},};

1;
