package item;
$USE[0]={'code'=>'basilisk','no'=>0,'itemno'=>'33','name'=>'알 껍질 깨기 도움받기','info'=>'곧 부화할 알의 껍질을 바실리스크이 깨 줍니다','scale'=>'개','action'=>'시작','money'=>0,'time'=>300,'exptime'=>'100','exp'=>'10','use'=>[{'no'=>63,'count'=>1,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'알에서 바실리스크이 태어났습니다',},'create'=>[{'no'=>33,'count'=>1,'proba'=>1000},],},};
sub _job_use_0_btamer_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[1]={'code'=>'basilisk','no'=>1,'itemno'=>'33','name'=>'블록 놀이 가르치기','info'=>'블록으로 노는 법을 가르칩니다','scale'=>'회','action'=>'교육하기','money'=>0,'time'=>3600,'exptime'=>'3600','exp'=>'10','arg'=>'nocount','param1'=>'33','param2'=>'39','param3'=>'블록유비','use'=>[{'no'=>73,'count'=>1,'proba'=>0},],'result'=>{'function'=>'education',},};
$USE[2]={'code'=>'basilisk','no'=>2,'itemno'=>'33','name'=>'꾸미는 법 가르치기','info'=>'거울을 사용해 꾸미는 법을 가르칩니다','scale'=>'회','action'=>'교육하기','money'=>0,'time'=>3600,'exptime'=>'3600','exp'=>'10','arg'=>'nocount','use'=>[{'no'=>74,'count'=>1,'proba'=>0},],'result'=>{'function'=>'_local_3','create'=>[{'no'=>3,'count'=>50,'proba'=>1000},],},};
sub _local_3 {eval(<<'_eval_code_');
my $ret;$ret.="바실리스크은 거울 때문에 자기 자신을 석화시켜 버렸습니다!";UseItem(33,1);return $ret;
_eval_code_
}
$USE[3]={'code'=>'basilisk','no'=>3,'itemno'=>'33','name'=>'나는 법 가르치기','info'=>'하늘을 나는 법을 가르칩니다','scale'=>'회','action'=>'교육하기','money'=>0,'time'=>3600,'exptime'=>'3600','exp'=>'10','arg'=>'nocount','use'=>[{'no'=>77,'count'=>1,'proba'=>0},],'result'=>{'message'=>{'resultng'=>'비행 연습에는 별로 관심이 없는 것 같습니다...',},},};

1;
