package item;
$USE[0]={'code'=>'holydragon','no'=>0,'itemno'=>'47','name'=>'알 껍질 깨기 도움받기','info'=>'곧 부화할 알의 껍질을 홀리 드래곤이 깨 줍니다','scale'=>'개','action'=>'시작','money'=>0,'time'=>450,'exptime'=>'150','exp'=>'10','use'=>[{'no'=>63,'count'=>1,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'알에서 홀리 드래곤이 태어났습니다',},'create'=>[{'no'=>47,'count'=>1,'proba'=>1000},],},};
sub _job_use_0_dmaster_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
sub _job_use_0_dtamer_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[1]={'code'=>'holydragon','no'=>1,'itemno'=>'47','name'=>'꾸미는 법 가르치기','info'=>'거울을 사용해 꾸미는 법을 가르칩니다','scale'=>'회','action'=>'교육하기','money'=>0,'time'=>3600,'exptime'=>'3600','exp'=>'10','arg'=>'nocount','use'=>[{'no'=>74,'count'=>1,'proba'=>0},],'result'=>{'message'=>{'resultng'=>'거울에는 별로 관심이 없는 것 같습니다...',},},};
$USE[2]={'code'=>'holydragon','no'=>2,'itemno'=>'47','name'=>'화장실 훈련하기','info'=>'유아용 변기 사용법을 가르칩니다','scale'=>'회','action'=>'교육하기','money'=>0,'time'=>3600,'exptime'=>'3600','exp'=>'10','arg'=>'nocount','use'=>[{'no'=>75,'count'=>1,'proba'=>0},],'result'=>{'message'=>{'resultng'=>'유아용 변기에는 별로 관심이 없는 것 같습니다...',},},};
$USE[3]={'code'=>'holydragon','no'=>3,'itemno'=>'47','name'=>'국제 대화을가르치기','info'=>'다른 존재와 소통하는 법을 가르칩니다','scale'=>'회','action'=>'교육하기','money'=>0,'time'=>3600,'exptime'=>'3600','exp'=>'10','arg'=>'nocount','param1'=>'47','param2'=>'53','param3'=>'회화의사방','use'=>[{'no'=>78,'count'=>1,'proba'=>0},],'result'=>{'function'=>'education',},};

1;
