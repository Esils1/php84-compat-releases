package item;
$USE[0]={'code'=>'crystal','no'=>0,'itemno'=>'5','name'=>'하급 소환마 부르기','info'=>'성스러운 힘으로 소환을 시도합니다','scale'=>'회','action'=>'소환하기','money'=>0,'time'=>2700,'exptime'=>'900','exp'=>'20','needexp'=>'100','use'=>[{'no'=>19,'count'=>1,'proba'=>0},{'no'=>5,'count'=>10,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'스피릿을 소환했습니다','resultng'=>'소환에 실패했습니다…',},'create'=>[{'no'=>11,'count'=>12,'proba'=>800},],},};
sub _job_use_0_shaman_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[1]={'code'=>'crystal','no'=>1,'itemno'=>'5','name'=>'상급 소환마 부르기','info'=>'성스러운 힘으로 소환을 시도합니다','scale'=>'회','action'=>'소환하기','money'=>0,'time'=>2700,'exptime'=>'900','exp'=>'20','needexp'=>'250','use'=>[{'no'=>19,'count'=>1,'proba'=>0},{'no'=>5,'count'=>10,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'유니콘을 소환했습니다','resultng'=>'소환에 실패했습니다…',},'create'=>[{'no'=>17,'count'=>10,'proba'=>800},],},};

1;
