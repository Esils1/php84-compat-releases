package item;
$USE[0]={'code'=>'golem','no'=>0,'itemno'=>'15','name'=>'알 껍질 깨기 도움받기','info'=>'곧 부화할 알의 껍질을 골렘이 깨 줍니다','scale'=>'개','action'=>'시작','money'=>0,'time'=>3600,'exptime'=>'3600','arg'=>'nocount','param1'=>'알에서 바실리스크이 태어났습니다!','use'=>[{'no'=>63,'count'=>1,'proba'=>1000},],'result'=>{'function'=>'memo','create'=>[{'no'=>33,'count'=>1,'proba'=>1000},],},};
sub _job_use_0_btamer_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}

1;
