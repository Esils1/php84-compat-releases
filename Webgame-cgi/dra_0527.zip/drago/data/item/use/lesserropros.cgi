package item;
$USE[0]={'code'=>'lesserropros','no'=>0,'itemno'=>'37','name'=>'알 껍질 깨기 도움받기','info'=>'곧 부화할 알의 껍질을 레서 로프로스이 깨 줍니다','scale'=>'개','action'=>'시작','money'=>0,'time'=>375,'exptime'=>'125','exp'=>'10','use'=>[{'no'=>63,'count'=>1,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'알에서 레서 로프로스이 태어났습니다',},'create'=>[{'no'=>37,'count'=>1,'proba'=>1000},],},};
sub _job_use_0_dtamer_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
sub _job_use_0_btamer_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[1]={'code'=>'lesserropros','no'=>1,'itemno'=>'37','name'=>'꾸미는 법 가르치기','info'=>'거울을 사용해 꾸미는 법을 가르칩니다','scale'=>'회','action'=>'교육하기','money'=>0,'time'=>3600,'exptime'=>'3600','exp'=>'10','arg'=>'nocount','use'=>[{'no'=>74,'count'=>1,'proba'=>0},],'result'=>{'message'=>{'resultng'=>'거울에는 별로 관심이 없는 것 같습니다...',},},};
$USE[2]={'code'=>'lesserropros','no'=>2,'itemno'=>'37','name'=>'걷는 법 가르치기','info'=>'걷는 법을 가르칩니다','scale'=>'회','action'=>'교육하기','money'=>0,'time'=>3600,'exptime'=>'3600','exp'=>'10','arg'=>'nocount','use'=>[{'no'=>76,'count'=>1,'proba'=>0},],'result'=>{'message'=>{'resultng'=>'걸음마에는 별로 관심이 없는 것 같습니다...',},},};
$USE[3]={'code'=>'lesserropros','no'=>3,'itemno'=>'37','name'=>'국제 대화을가르치기','info'=>'다른 존재와 소통하는 법을 가르칩니다','scale'=>'회','action'=>'교육하기','money'=>0,'time'=>3600,'exptime'=>'3600','exp'=>'10','arg'=>'nocount','param1'=>'37','param2'=>'43','param3'=>'회화의사방','use'=>[{'no'=>78,'count'=>1,'proba'=>0},],'result'=>{'function'=>'education',},};

1;
