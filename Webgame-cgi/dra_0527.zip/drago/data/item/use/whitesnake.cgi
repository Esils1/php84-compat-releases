package item;
$USE[0]={'code'=>'whitesnake','no'=>0,'itemno'=>'35','name'=>'알 껍질 깨기 도움받기','info'=>'곧 부화할 알의 껍질을 화이트 스네이크이 깨 줍니다','scale'=>'개','action'=>'시작','money'=>0,'time'=>300,'exptime'=>'100','exp'=>'10','use'=>[{'no'=>63,'count'=>1,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'알에서 화이트 스네이크이 태어났습니다',},'create'=>[{'no'=>35,'count'=>1,'proba'=>1000},],},};
sub _job_use_0_btamer_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[1]={'code'=>'whitesnake','no'=>1,'itemno'=>'35','name'=>'화장실 훈련하기','info'=>'유아용 변기 사용법을 가르칩니다','scale'=>'회','action'=>'교육하기','money'=>0,'time'=>3600,'exptime'=>'3600','exp'=>'10','arg'=>'nocount','use'=>[{'no'=>75,'count'=>1,'proba'=>0},],'result'=>{'message'=>{'resultng'=>'유아용 변기에는 별로 관심이 없는 것 같습니다...',},},};
$USE[2]={'code'=>'whitesnake','no'=>2,'itemno'=>'35','name'=>'걷는 법 가르치기','info'=>'걷는 법을 가르칩니다','scale'=>'회','action'=>'교육하기','money'=>0,'time'=>3600,'exptime'=>'3600','exp'=>'10','arg'=>'nocount','use'=>[{'no'=>76,'count'=>1,'proba'=>0},],'result'=>{'message'=>{'resultng'=>'걸음마에는 별로 관심이 없는 것 같습니다...',},},};
$USE[3]={'code'=>'whitesnake','no'=>3,'itemno'=>'35','name'=>'나는 법 가르치기','info'=>'하늘을 나는 법을 가르칩니다','scale'=>'회','action'=>'교육하기','money'=>0,'time'=>3600,'exptime'=>'3600','exp'=>'10','arg'=>'nocount','param1'=>'35','param2'=>'41','param3'=>'공을비부코와','use'=>[{'no'=>77,'count'=>1,'proba'=>0},],'result'=>{'function'=>'education',},};

1;
