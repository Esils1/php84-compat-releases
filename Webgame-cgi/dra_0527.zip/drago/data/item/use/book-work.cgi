package item;
$USE[0]={'code'=>'book-work','no'=>0,'itemno'=>'24','name'=>'정석대로 자금 마련','info'=>'손해를 감수하고 자금을 마련합니다','scale'=>'회','action'=>'받기','money'=>0,'time'=>7200,'exptime'=>'7200','param1'=>'3000','result'=>{'function'=>'_local_1',},};
sub _local_1 {eval(<<'_eval_code_');
$DT->{money}+=$USE->{param1}*$count;my $ret=GetMoneyString($USE->{param1}*$count).'을 벌었습니다';WriteLog(0,$DT->{id},"아르바이트로 $ret");WriteLog(3,0,$DT->{shopname}."이 아르바이트를 한 것 같습니다");return $ret;
_eval_code_
}
sub _job_use_0_peddle_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[1]={'code'=>'book-work','no'=>1,'itemno'=>'24','name'=>'하루 벌이 현장 작업으로 자금 마련','info'=>'조금 힘들지만 그럭저럭 벌 수 있습니다','scale'=>'회','action'=>'받기','money'=>0,'time'=>14400,'exptime'=>'14400','param1'=>'10000','result'=>{'function'=>'_local_1',},};
sub _job_use_1_peddle_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}

1;
