package item;
$USE[0]={'code'=>'book-dk','no'=>0,'itemno'=>'21','name'=>'용암 광산 탐색','info'=>'여러 촉매를 구할 수 있을지도 모릅니다','scale'=>'왕복','action'=>'탐색하러 가기','money'=>0,'time'=>3600,'exptime'=>'900','exp'=>'20','result'=>{'message'=>{'resultng'=>'아무것도 찾지 못했습니다…',},'create'=>[{'no'=>1,'count'=>40,'proba'=>900,'message'=>'디즈멀이많이 발견했습니다'},{'no'=>3,'count'=>2,'proba'=>900},{'no'=>6,'count'=>3,'proba'=>450},],},};
sub _job_use_0_thunter_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[1]={'code'=>'book-dk','no'=>1,'itemno'=>'21','name'=>'지하 수맥 탐색','info'=>'여러 촉매를 구할 수 있을지도 모릅니다','scale'=>'왕복','action'=>'탐색하러 가기','money'=>0,'time'=>3600,'exptime'=>'900','exp'=>'20','result'=>{'message'=>{'resultng'=>'아무것도 찾지 못했습니다…',},'create'=>[{'no'=>2,'count'=>40,'proba'=>900,'message'=>'젬스톤이많이 발견했습니다'},{'no'=>4,'count'=>2,'proba'=>900},{'no'=>5,'count'=>3,'proba'=>450},],},};
$USE[2]={'code'=>'book-dk','no'=>2,'itemno'=>'21','name'=>'굴착지 탐색','info'=>'여러 촉매를 구할 수 있을지도 모릅니다','scale'=>'왕복','action'=>'탐색하러 가기','money'=>0,'time'=>3600,'exptime'=>'900','exp'=>'20','result'=>{'message'=>{'resultng'=>'아무것도 찾지 못했습니다…',},'create'=>[{'no'=>1,'count'=>2,'proba'=>900},{'no'=>3,'count'=>40,'proba'=>900,'message'=>'크로나임이많이 발견했습니다'},{'no'=>6,'count'=>3,'proba'=>450},],},};
$USE[3]={'code'=>'book-dk','no'=>3,'itemno'=>'21','name'=>'통풍구 탐색','info'=>'여러 촉매를 구할 수 있을지도 모릅니다','scale'=>'왕복','action'=>'탐색하러 가기','money'=>0,'time'=>3600,'exptime'=>'900','exp'=>'20','result'=>{'message'=>{'resultng'=>'아무것도 찾지 못했습니다…',},'create'=>[{'no'=>2,'count'=>2,'proba'=>900},{'no'=>4,'count'=>40,'proba'=>900,'message'=>'피엘이많이 발견했습니다'},{'no'=>5,'count'=>3,'proba'=>450},],},};
$USE[4]={'code'=>'book-dk','no'=>4,'itemno'=>'21','name'=>'종유동 탐색','info'=>'여러 촉매를 구할 수 있을지도 모릅니다','scale'=>'왕복','action'=>'탐색하러 가기','money'=>0,'time'=>3600,'exptime'=>'900','exp'=>'20','needexp'=>'100','result'=>{'message'=>{'resultng'=>'아무것도 찾지 못했습니다…',},'create'=>[{'no'=>2,'count'=>2,'proba'=>900},{'no'=>4,'count'=>2,'proba'=>900},{'no'=>5,'count'=>40,'proba'=>450,'message'=>'크리스탈이많이 발견했습니다'},],},};
$USE[5]={'code'=>'book-dk','no'=>5,'itemno'=>'21','name'=>'봉마벽 탐색','info'=>'여러 촉매를 구할 수 있을지도 모릅니다','scale'=>'왕복','action'=>'탐색하러 가기','money'=>0,'time'=>3600,'exptime'=>'900','exp'=>'20','needexp'=>'100','result'=>{'message'=>{'resultng'=>'아무것도 찾지 못했습니다…',},'create'=>[{'no'=>1,'count'=>2,'proba'=>900},{'no'=>3,'count'=>2,'proba'=>900},{'no'=>6,'count'=>40,'proba'=>450,'message'=>'베르뒤르이많이 발견했습니다'},],},};

1;
