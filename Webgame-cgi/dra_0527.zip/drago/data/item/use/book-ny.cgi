package item;
$USE[0]={'code'=>'book-ny','no'=>0,'itemno'=>'22','name'=>'들판 탐색','info'=>'여러 먹이를 구할 수 있을지도 모릅니다','scale'=>'왕복','action'=>'탐색하러 가기','money'=>0,'time'=>3600,'exptime'=>'900','exp'=>'20','result'=>{'message'=>{'resultng'=>'아무것도 찾지 못했습니다…',},'create'=>[{'no'=>66,'count'=>60,'proba'=>700,'message'=>'뱀딸기이많이 발견했습니다'},{'no'=>67,'count'=>3,'proba'=>700},{'no'=>68,'count'=>3,'proba'=>350},{'no'=>69,'count'=>3,'proba'=>350},{'no'=>70,'count'=>3,'proba'=>350},],},};
sub _job_use_0_thunter_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[1]={'code'=>'book-ny','no'=>1,'itemno'=>'22','name'=>'숲 탐색','info'=>'여러 먹이를 구할 수 있을지도 모릅니다','scale'=>'왕복','action'=>'탐색하러 가기','money'=>0,'time'=>3600,'exptime'=>'900','exp'=>'20','result'=>{'message'=>{'resultng'=>'아무것도 찾지 못했습니다…',},'create'=>[{'no'=>66,'count'=>3,'proba'=>700},{'no'=>67,'count'=>60,'proba'=>700,'message'=>'달꽃 고사리를 많이 발견했습니다'},{'no'=>68,'count'=>3,'proba'=>350},{'no'=>69,'count'=>3,'proba'=>350},{'no'=>70,'count'=>3,'proba'=>350},],},};
$USE[2]={'code'=>'book-ny','no'=>2,'itemno'=>'22','name'=>'해변 탐색','info'=>'여러 먹이를 구할 수 있을지도 모릅니다','scale'=>'왕복','action'=>'탐색하러 가기','money'=>0,'time'=>3600,'exptime'=>'900','exp'=>'20','result'=>{'message'=>{'resultng'=>'아무것도 찾지 못했습니다…',},'create'=>[{'no'=>66,'count'=>3,'proba'=>700},{'no'=>67,'count'=>3,'proba'=>700},{'no'=>68,'count'=>30,'proba'=>700,'message'=>'눈사람 다시마이많이 발견했습니다'},{'no'=>69,'count'=>3,'proba'=>350},{'no'=>70,'count'=>3,'proba'=>350},],},};
$USE[3]={'code'=>'book-ny','no'=>3,'itemno'=>'22','name'=>'바위산 탐색','info'=>'여러 먹이를 구할 수 있을지도 모릅니다','scale'=>'왕복','action'=>'탐색하러 가기','money'=>0,'time'=>3600,'exptime'=>'900','exp'=>'20','result'=>{'message'=>{'resultng'=>'아무것도 찾지 못했습니다…',},'create'=>[{'no'=>66,'count'=>3,'proba'=>700},{'no'=>67,'count'=>3,'proba'=>700},{'no'=>68,'count'=>3,'proba'=>350},{'no'=>69,'count'=>30,'proba'=>700,'message'=>'도마뱀 꼬리을 많이 손에 넣었습니다'},{'no'=>70,'count'=>3,'proba'=>350},],},};
$USE[4]={'code'=>'book-ny','no'=>4,'itemno'=>'22','name'=>'공원 탐색','info'=>'여러 먹이를 구할 수 있을지도 모릅니다','scale'=>'왕복','action'=>'탐색하러 가기','money'=>0,'time'=>3600,'exptime'=>'900','exp'=>'20','result'=>{'message'=>{'resultng'=>'아무것도 찾지 못했습니다…',},'create'=>[{'no'=>66,'count'=>3,'proba'=>700},{'no'=>67,'count'=>3,'proba'=>700},{'no'=>68,'count'=>3,'proba'=>350},{'no'=>69,'count'=>3,'proba'=>350},{'no'=>70,'count'=>30,'proba'=>700,'message'=>'고양이 수염을 많이 손에 넣었습니다'},],},};

1;
