package item;
$USE[0]={'code'=>'flarebrass','no'=>0,'itemno'=>'49','name'=>'알 껍질 깨기 도움받기','info'=>'곧 부화할 알의 껍질을 후레아부라스이 깨 줍니다','scale'=>'개','action'=>'시작','money'=>0,'time'=>480,'exptime'=>'160','exp'=>'10','use'=>[{'no'=>63,'count'=>1,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'알에서 후레아부라스이 태어났습니다',},'create'=>[{'no'=>49,'count'=>1,'proba'=>1000},],},};
sub _job_use_0_dmaster_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[1]={'code'=>'flarebrass','no'=>1,'itemno'=>'49','name'=>'신종 개발하기','info'=>'다양한 교육으로 오리지널 드래곤으로 키웁니다','scale'=>'회','action'=>'라는 드래곤을 개발','money'=>0,'time'=>10800,'exptime'=>'10800','exp'=>'10','arg'=>'nocount|message20','param1'=>'dmaster','param2'=>'49','param3'=>'55','needjob'=>'dmaster','use'=>[{'no'=>73,'count'=>1,'proba'=>0},{'no'=>74,'count'=>1,'proba'=>0},{'no'=>75,'count'=>1,'proba'=>0},{'no'=>76,'count'=>1,'proba'=>0},{'no'=>77,'count'=>1,'proba'=>0},{'no'=>78,'count'=>1,'proba'=>0},{'no'=>79,'count'=>1,'proba'=>0},],'result'=>{'function'=>'newdragon',},};

1;
