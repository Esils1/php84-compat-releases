package item;
$USE[0]={'code'=>'verdure','no'=>0,'itemno'=>'6','name'=>'하급 소환마 부르기','info'=>'사악한 힘으로 소환을 시도합니다','scale'=>'회','action'=>'소환하기','money'=>0,'time'=>2700,'exptime'=>'900','exp'=>'20','needexp'=>'100','use'=>[{'no'=>19,'count'=>1,'proba'=>0},{'no'=>6,'count'=>10,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'셰이드을 소환했습니다','resultng'=>'소환에 실패했습니다…',},'create'=>[{'no'=>12,'count'=>12,'proba'=>800},],},};
sub _job_use_0_shaman_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[1]={'code'=>'verdure','no'=>1,'itemno'=>'6','name'=>'상급 소환마 부르기','info'=>'사악한 힘으로 소환을 시도합니다','scale'=>'회','action'=>'소환하기','money'=>0,'time'=>2700,'exptime'=>'900','exp'=>'20','needexp'=>'250','use'=>[{'no'=>19,'count'=>1,'proba'=>0},{'no'=>6,'count'=>10,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'데몬을 소환했습니다','resultng'=>'소환에 실패했습니다…',},'create'=>[{'no'=>18,'count'=>10,'proba'=>800},],},};

1;
