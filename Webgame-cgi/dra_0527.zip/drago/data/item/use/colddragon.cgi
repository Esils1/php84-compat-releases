package item;
$USE[0]={'code'=>'colddragon','no'=>0,'itemno'=>'44','name'=>'알 껍질 깨기 도움받기','info'=>'곧 부화할 알의 껍질을 콜드 드래곤이 깨 줍니다','scale'=>'개','action'=>'시작','money'=>0,'time'=>450,'exptime'=>'150','exp'=>'10','use'=>[{'no'=>63,'count'=>1,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'알에서 콜드 드래곤이 태어났습니다',},'create'=>[{'no'=>44,'count'=>1,'proba'=>1000},],},};
sub _job_use_0_dmaster_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
sub _job_use_0_dtamer_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[1]={'code'=>'colddragon','no'=>1,'itemno'=>'44','name'=>'블록 놀이 가르치기','info'=>'블록으로 노는 법을 가르칩니다','scale'=>'회','action'=>'교육하기','money'=>0,'time'=>3600,'exptime'=>'3600','exp'=>'10','arg'=>'nocount','use'=>[{'no'=>73,'count'=>1,'proba'=>0},],'result'=>{'message'=>{'resultng'=>'블록에는 별로 관심이 없는 것 같습니다...',},},};
$USE[2]={'code'=>'colddragon','no'=>2,'itemno'=>'44','name'=>'화장실 훈련하기','info'=>'유아용 변기 사용법을 가르칩니다','scale'=>'회','action'=>'교육하기','money'=>0,'time'=>3600,'exptime'=>'3600','exp'=>'10','arg'=>'nocount','use'=>[{'no'=>75,'count'=>1,'proba'=>0},],'result'=>{'message'=>{'resultng'=>'유아용 변기에는 별로 관심이 없는 것 같습니다...',},},};
$USE[3]={'code'=>'colddragon','no'=>3,'itemno'=>'44','name'=>'꾸미는 법 가르치기','info'=>'거울을 사용해 꾸미는 법을 가르칩니다','scale'=>'회','action'=>'교육하기','money'=>0,'time'=>3600,'exptime'=>'3600','exp'=>'10','arg'=>'nocount','param1'=>'44','param2'=>'50','param3'=>'오시야레','use'=>[{'no'=>74,'count'=>1,'proba'=>0},],'result'=>{'function'=>'education',},};

1;
