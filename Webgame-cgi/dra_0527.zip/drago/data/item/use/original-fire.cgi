package item;
$USE[0]={'code'=>'original-fire','no'=>0,'itemno'=>'55','name'=>'알 껍질 깨기 도움받기','info'=>'곧 부화할 알의 껍질을 오리지널 드래곤(불)이 깨 줍니다','scale'=>'개','action'=>'시작','money'=>0,'time'=>480,'exptime'=>'160','exp'=>'10','use'=>[{'no'=>63,'count'=>1,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'알에서 오리지널 드래곤(불)이 태어났습니다',},'create'=>[{'no'=>55,'count'=>1,'proba'=>1000},],},};
sub _job_use_0_dmaster_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}

1;
