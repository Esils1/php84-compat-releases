package item;
$USE[0]={'code'=>'earthdragon','no'=>0,'itemno'=>'45','name'=>'알 껍질 깨기 도움받기','info'=>'곧 부화할 알의 껍질을 어스 드래곤이 깨 줍니다','scale'=>'개','action'=>'시작','money'=>0,'time'=>450,'exptime'=>'150','exp'=>'10','use'=>[{'no'=>63,'count'=>1,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'알에서 어스 드래곤이 태어났습니다',},'create'=>[{'no'=>45,'count'=>1,'proba'=>1000},],},};
sub _job_use_0_dmaster_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
sub _job_use_0_dtamer_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[1]={'code'=>'earthdragon','no'=>1,'itemno'=>'45','name'=>'화장실 훈련하기','info'=>'유아용 변기 사용법을 가르칩니다','scale'=>'회','action'=>'교육하기','money'=>0,'time'=>3600,'exptime'=>'3600','exp'=>'10','arg'=>'nocount','use'=>[{'no'=>75,'count'=>1,'proba'=>0},],'result'=>{'message'=>{'resultng'=>'유아용 변기에는 별로 관심이 없는 것 같습니다...',},},};
$USE[2]={'code'=>'earthdragon','no'=>2,'itemno'=>'45','name'=>'나는 법 가르치기','info'=>'하늘을 나는 법을 가르칩니다','scale'=>'회','action'=>'교육하기','money'=>0,'time'=>3600,'exptime'=>'3600','exp'=>'10','arg'=>'nocount','param1'=>'45','param2'=>'51','param3'=>'공을비부코와','use'=>[{'no'=>77,'count'=>1,'proba'=>0},],'result'=>{'function'=>'education',},};
$USE[3]={'code'=>'earthdragon','no'=>3,'itemno'=>'45','name'=>'고차방정식 가르치기','info'=>'고급 수학을 가르칩니다','scale'=>'회','action'=>'교육하기','money'=>0,'time'=>3600,'exptime'=>'3600','exp'=>'10','arg'=>'nocount','use'=>[{'no'=>79,'count'=>1,'proba'=>0},],'result'=>{'message'=>{'resultng'=>'수학에는 별로 관심이 없는 것 같습니다...',},},};

1;
