package item;
$USE[0]={'code'=>'circle','no'=>0,'itemno'=>'19','name'=>'소환 방법 조사','info'=>'몬스터 소환 방법을 알고 싶을 때','scale'=>'회','action'=>'조사하기','money'=>0,'time'=>600,'exptime'=>'600','arg'=>'nocount','result'=>{'function'=>'_local_1',},};
sub _local_1 {eval(<<'_eval_code_');
my $ret;$ret.="그러자 마법진에서 연기가 피어오르고 노인이 나타났습니다.<br><br>";$ret.="<TABLE><tr><td>";$ret.=main::GetTagImgKao('라무우','ram')."불꽃 노인:<br>";$ret.="...소환 방법을 알고 싶구나. 도서관에 책이 있을 게다.<br>";$ret.="먼저 근처 동굴 지도를 사용해 촉매를 찾아야 한다.<br>";$ret.="그다음 찾은 촉매를 사용해 소환을 하면 된다.<br>";$ret.="자세한 내용은 아래 도서관에서 잘 조사해 보거라.";$ret.="</td></tr></table><br>";$ret.="말을 마치자 노인은 연기 속으로 사라졌습니다.";return $ret;
_eval_code_
}

1;
