package item;
$USE[0]={'code'=>'stoorworm','no'=>0,'itemno'=>'39','name'=>'알 껍질 깨기 도움받기','info'=>'곧 부화할 알의 껍질을 스톰 웜이 깨 줍니다','scale'=>'개','action'=>'시작','money'=>0,'time'=>375,'exptime'=>'125','exp'=>'10','use'=>[{'no'=>63,'count'=>1,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'알에서 스톰 웜이 태어났습니다',},'create'=>[{'no'=>39,'count'=>1,'proba'=>1000},],},};
sub _job_use_0_dtamer_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
sub _job_use_0_btamer_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[1]={'code'=>'stoorworm','no'=>1,'itemno'=>'39','name'=>'꾸미는 법 가르치기','info'=>'거울을 사용해 꾸미는 법을 가르칩니다','scale'=>'회','action'=>'교육하기','money'=>0,'time'=>3600,'exptime'=>'3600','exp'=>'10','arg'=>'nocount','use'=>[{'no'=>74,'count'=>1,'proba'=>0},],'result'=>{'message'=>{'resultng'=>'거울에는 별로 관심이 없는 것 같습니다...',},},};
$USE[2]={'code'=>'stoorworm','no'=>2,'itemno'=>'39','name'=>'걷는 법 가르치기','info'=>'걷는 법을 가르칩니다','scale'=>'회','action'=>'교육하기','money'=>0,'time'=>3600,'exptime'=>'3600','exp'=>'10','arg'=>'nocount','param1'=>'39','param2'=>'45','param3'=>'보줄의방법','use'=>[{'no'=>76,'count'=>1,'proba'=>0},],'result'=>{'function'=>'education',},};
$USE[3]={'code'=>'stoorworm','no'=>3,'itemno'=>'39','name'=>'고차방정식 가르치기','info'=>'고급 수학을 가르칩니다','scale'=>'회','action'=>'교육하기','money'=>0,'time'=>3600,'exptime'=>'3600','exp'=>'10','arg'=>'nocount','use'=>[{'no'=>79,'count'=>1,'proba'=>0},],'result'=>{'message'=>{'resultng'=>'수학에는 별로 관심이 없는 것 같습니다...',},},};

1;
