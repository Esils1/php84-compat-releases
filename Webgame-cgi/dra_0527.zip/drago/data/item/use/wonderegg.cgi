package item;
$USE[0]={'code'=>'wonderegg','no'=>0,'itemno'=>'61','name'=>'알을 부화시키는 방법 조사','info'=>'드래곤 육성 방법을 알고 싶을 때','scale'=>'회','action'=>'조사하기','money'=>0,'time'=>600,'exptime'=>'600','arg'=>'nocount','result'=>{'function'=>'_local_1',},};
sub _local_1 {eval(<<'_eval_code_');
my $ret;$ret.="그러자 알 주변에서 연기가 피어오르고 노인이 나타났습니다.<br><br>";$ret.="<TABLE><tr><td>";$ret.=main::GetTagImgKao('라무우','ram')."불꽃 노인:<br>";$ret.="…후무,알부터드래곤을육테타이라는의지야인.<br>";$ret.="불을 피워 알을 데우면 이 알은 부화할 게다.<br>";$ret.="그 뒤의 일은 도서관에서 직접 알아보거라.<br>";$ret.="서두르면 키우는 데 실패해서 큰일이 날 수도 있다.";$ret.="</td></tr></table><br>";$ret.="말을 마치자 노인은 연기 속으로 사라졌습니다.";return $ret;
_eval_code_
}
$USE[1]={'code'=>'wonderegg','no'=>1,'itemno'=>'61','name'=>'알 데우기','info'=>'불을 피워 알을 데웁니다','scale'=>'개','action'=>'시작','money'=>0,'time'=>270,'exptime'=>'90','exp'=>'10','use'=>[{'no'=>61,'count'=>1,'proba'=>1000},{'no'=>67,'count'=>1,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'이제 알이 부화하기를 기다리면 됩니다',},'create'=>[{'no'=>62,'count'=>1,'proba'=>1000},],},};
sub _job_use_1_btamer_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}

1;
