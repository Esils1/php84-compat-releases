package item;
$USE[0]={'code'=>'edit-showcase','no'=>0,'itemno'=>'25','name'=>'진열대을1츠에하기','info'=>'진열대을1츠에하기','scale'=>'회','action'=>'작업하기','money'=>10000,'time'=>1800,'exptime'=>'1800','arg'=>'nocount','param1'=>'1','use'=>[{'no'=>25,'count'=>1,'proba'=>1000},],'result'=>{'function'=>'_local_1',},};
sub _local_1 {eval(<<'_eval_code_');
my $oldcnt=$DT->{showcasecount};my $newcnt=$USE->{param1};$DT->{showcasecount}=$newcnt;if($oldcnt<$newcnt){foreach ($oldcnt..$newcnt-1){$DT->{showcase}[$_]=0;$DT->{price}[$_]=0;}}if($oldcnt>$newcnt){splice(@{$DT->{showcase}},$newcnt);splice(@{$DT->{price}},$newcnt);}my $ret="진열대을$DT->{showcasecount}개에했습니다";WriteLog(0,$DT->{id},$ret);WriteLog(0,0,$DT->{shopname}."의진열대이$DT->{showcasecount}개이 되었습니다.");return $ret;
_eval_code_
}
$USE[1]={'code'=>'edit-showcase','no'=>1,'itemno'=>'25','name'=>'진열대을2츠에하기','info'=>'진열대을2츠에하기','scale'=>'회','action'=>'작업하기','money'=>20000,'time'=>3600,'exptime'=>'3600','arg'=>'nocount','param1'=>'2','use'=>[{'no'=>25,'count'=>1,'proba'=>1000},],'result'=>{'function'=>'_local_1',},};
$USE[2]={'code'=>'edit-showcase','no'=>2,'itemno'=>'25','name'=>'진열대을3츠에하기','info'=>'진열대을3츠에하기','scale'=>'회','action'=>'작업하기','money'=>30000,'time'=>5400,'exptime'=>'5400','arg'=>'nocount','param1'=>'3','use'=>[{'no'=>25,'count'=>1,'proba'=>1000},],'result'=>{'function'=>'_local_1',},};
$USE[3]={'code'=>'edit-showcase','no'=>3,'itemno'=>'25','name'=>'진열대을4츠에하기','info'=>'진열대을4츠에하기','scale'=>'회','action'=>'작업하기','money'=>40000,'time'=>7200,'exptime'=>'7200','arg'=>'nocount','param1'=>'4','use'=>[{'no'=>25,'count'=>1,'proba'=>1000},],'result'=>{'function'=>'_local_1',},};
$USE[4]={'code'=>'edit-showcase','no'=>4,'itemno'=>'25','name'=>'진열대을5츠에하기','info'=>'진열대을5츠에하기','scale'=>'회','action'=>'작업하기','money'=>50000,'time'=>9000,'exptime'=>'9000','arg'=>'nocount','param1'=>'5','use'=>[{'no'=>25,'count'=>1,'proba'=>1000},],'result'=>{'function'=>'_local_1',},};
$USE[5]={'code'=>'edit-showcase','no'=>5,'itemno'=>'25','name'=>'진열대을6츠에하기','info'=>'진열대을6츠에하기','scale'=>'회','action'=>'작업하기','money'=>60000,'time'=>10800,'exptime'=>'10800','arg'=>'nocount','param1'=>'6','use'=>[{'no'=>25,'count'=>1,'proba'=>1000},],'result'=>{'function'=>'_local_1',},};
$USE[6]={'code'=>'edit-showcase','no'=>6,'itemno'=>'25','name'=>'진열대을7츠에하기','info'=>'진열대을7츠에하기','scale'=>'회','action'=>'작업하기','money'=>70000,'time'=>12600,'exptime'=>'12600','arg'=>'nocount','param1'=>'7','use'=>[{'no'=>25,'count'=>1,'proba'=>1000},],'result'=>{'function'=>'_local_1',},};
$USE[7]={'code'=>'edit-showcase','no'=>7,'itemno'=>'25','name'=>'진열대을8츠에하기','info'=>'진열대을8츠에하기','scale'=>'회','action'=>'작업하기','money'=>80000,'time'=>14400,'exptime'=>'14400','arg'=>'nocount','param1'=>'8','use'=>[{'no'=>25,'count'=>1,'proba'=>1000},],'result'=>{'function'=>'_local_1',},};

1;
