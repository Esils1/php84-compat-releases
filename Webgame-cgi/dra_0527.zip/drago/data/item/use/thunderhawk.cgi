package item;
$USE[0]={'code'=>'thunderhawk','no'=>0,'itemno'=>'40','name'=>'알 껍질 깨기 도움받기','info'=>'곧 부화할 알의 껍질을 썬더 호크이 깨 줍니다','scale'=>'개','action'=>'시작','money'=>0,'time'=>375,'exptime'=>'125','exp'=>'10','use'=>[{'no'=>63,'count'=>1,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'알에서 썬더 호크이 태어났습니다',},'create'=>[{'no'=>40,'count'=>1,'proba'=>1000},],},};
sub _job_use_0_dtamer_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
sub _job_use_0_btamer_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[1]={'code'=>'thunderhawk','no'=>1,'itemno'=>'40','name'=>'화장실 훈련하기','info'=>'유아용 변기 사용법을 가르칩니다','scale'=>'회','action'=>'교육하기','money'=>0,'time'=>3600,'exptime'=>'3600','exp'=>'10','arg'=>'nocount','param1'=>'40','param2'=>'46','param3'=>'토이레의시츠케','use'=>[{'no'=>75,'count'=>1,'proba'=>0},],'result'=>{'function'=>'education',},};
$USE[2]={'code'=>'thunderhawk','no'=>2,'itemno'=>'40','name'=>'국제 대화을가르치기','info'=>'다른 존재와 소통하는 법을 가르칩니다','scale'=>'회','action'=>'교육하기','money'=>0,'time'=>3600,'exptime'=>'3600','exp'=>'10','arg'=>'nocount','use'=>[{'no'=>78,'count'=>1,'proba'=>0},],'result'=>{'message'=>{'resultng'=>'대화에는 별로 관심이 없는 것 같습니다...',},},};
$USE[3]={'code'=>'thunderhawk','no'=>3,'itemno'=>'40','name'=>'고차방정식 가르치기','info'=>'고급 수학을 가르칩니다','scale'=>'회','action'=>'교육하기','money'=>0,'time'=>3600,'exptime'=>'3600','exp'=>'10','arg'=>'nocount','use'=>[{'no'=>79,'count'=>1,'proba'=>0},],'result'=>{'message'=>{'resultng'=>'수학에는 별로 관심이 없는 것 같습니다...',},},};

1;
