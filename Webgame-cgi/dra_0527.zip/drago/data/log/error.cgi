1779793614	/korhako/dra/dra/drago/action.cgi	::1		::1		ip file read error 
