#!/usr/bin/perl
# 매입 상세 2005/01/06 유래
# 드래고노마사님(몬스터전매금지)

$NOMENU=1;
DataRead();
CheckUserPass();

($id,$showcase,$mstno)=split('!',$Q{buy},3);
$id=int($id+0);
$showcase=int($showcase+0);

if($id==0)
{
	# 시장
	$DTS=GetWholeStore();
}
else
{
	# 일반가게
	$DTS=$DT[(CheckUserID($id))[1]];
}

$showcase=CheckShowCaseNumber($DTS,$showcase);
($itemno,$price,$stock)=CheckShowCaseItem($DTS,$showcase);

OutError("진열대에는 아무것도 없습니다") if !$itemno || !$stock;
OutError("진열이 변경된 것 같습니다") if $itemno!=$mstno;

RequireFile('inc-html-ownerinfo.cgi');

$TIME_SEND_ITEM=int($TIME_SEND_ITEM/2) if !$id;
my $usetime=GetTimeDeal($price,$itemno,1);

my $baseprice=$price;
my($guild,$guildrate,$guildmargin)=CheckGuild($DT,$DTS,$baseprice);
my $saleprice=$baseprice+($guild==1 ? -$guildmargin : $guildmargin);
$price=$saleprice;

$disp.="<BIG>●구입</BIG><br><br>";

my $ITEM=$ITEM[$itemno];

$disp.=$TB.$TR.$TDB."가게 이름".$TD.GetTagImgGuild($DTS->{guild}).$DTS->{shopname}.$TRE;
$disp.=$TR.$TDB;
$disp.=(($ITEM->{flag}=~/h/)? "이름" : "상품");
$disp.=$TD.GetTagImgItemType($itemno).$ITEM->{name}.$TRE;
$disp.=$TR.$TDB.$TD.$ITEM->{info}.$TRE;
$disp.=$TR.$TDB."가격".$TD.'@'.GetMoneyString($baseprice).$TRE;
$disp.=$TR.$TDB.("길드내 할인 가격","길드간 할증 가격")[$guild-1].$TD.'@'.GetMoneyString($saleprice).$TRE if $guild>0;
$disp.=$TR.$TDB."길드 자금 부족".$TD."길드내 할인 보조는 없습니다".$TRE if $guild==-1;
$disp.=$TR.$TDB."판매 재고 수".$TD.$stock.$ITEM->{scale}.$TRE;
$disp.=$TR.$TDB.'현재 가게 보유 수'.$TD.($DT->{item}[$itemno-1]+0).$ITEM->{scale}.$TRE;
$disp.=$TBE;

if ($ITEM->{flag}!~/s/) {		# s 진열불가
	$disp.="<SPAN>※".$ITEM->{name}."은 진열해도 팔리지 않습니다</SPAN><br>" if ($ITEM->{popular}==0);
	$disp.="<SPAN>※".$ITEM->{name}."은 진열해도 거의 팔리지 않습니다</SPAN><br>" if ($ITEM->{popular} > 800000);	}
$disp.="<hr width=500 noshade size=1>";

if($DT->{item}[$itemno-1]>=$ITEM->{limit})
	{$disp.='<BR>이미 창고에 '.$ITEM->{name}.'이 가득합니다<BR>';}
elsif($DT->{money}<$price && $price > 0)
	{$disp.='<BR>자금이 부족합니다<BR>';}
elsif(GetStockTime($DT->{time})<$usetime)
	{$disp.='<BR>시간이 부족합니다<BR>';}
elsif($ITEM->{type} > 2 && $ITEM->{type} < 9)
	{$disp.='<BR>다른 가게에서 몬스터를 구입할 수 없습니다<BR>';}
else
{
	$disp.="<FORM ACTION=\"action.cgi\" $METHOD>";
	$disp.="<INPUT TYPE=HIDDEN NAME=key VALUE=\"buy-s\">";
	$disp.="$USERPASSFORM";
	$disp.="<INPUT TYPE=HIDDEN NAME=bk VALUE=\"$Q{bk}\">";
	$disp.="<INPUT TYPE=HIDDEN NAME=id VALUE=\"$id\">";
	$disp.="<INPUT TYPE=HIDDEN NAME=pr VALUE=\"$price\">";
	$disp.="<INPUT TYPE=HIDDEN NAME=sc VALUE=\"$showcase\">";
	$disp.="<INPUT TYPE=HIDDEN NAME=it VALUE=\"$itemno\">";
	$disp.="위 상품을 ";
	$limit=$ITEM[$itemno]->{limit}-$DT->{item}[$itemno-1];
	my $money=$MAX_MONEY;
	$money=int($DT->{money}/$price) if $price;
	$msg{1}=1;
	$msg{10}=10;
	$msg{100}=100;
	$msg{1000}=1000;
	$msg{10000}=10000;
	$msg{$stock}="$stock(전부)";
	$msg{$limit}="$limit(창고 최대)";
	$msg{$money}="$money(자금 최대)";
	$disp.="<SELECT NAME=num1 SIZE=1>";
	my $oldcnt=0;
	foreach my $cnt (sort { $a <=> $b } (1,10,100,1000,10000,$stock,$limit,$money))
	{
		last if $stock<$cnt || $cnt>$money || $cnt>$limit || $cnt==$oldcnt;
	
		$disp.="<OPTION VALUE=\"$cnt\">$msg{$cnt}";
		$oldcnt=$cnt;
	}
	$disp.="</SELECT> $ITEM[$itemno]->{scale},또는 ";
	$disp.="<INPUT TYPE=TEXT NAME=num2 SIZE=5> $ITEM[$itemno]->{scale} ";

  if ($ITEM->{flag}=~/h/) {  $disp.="<INPUT TYPE=SUBMIT VALUE='고용한다'>";  }
         else 	{ $disp.="<INPUT TYPE=SUBMIT VALUE='산다'>"; }

	$disp.="<br>(소요 시간:".GetTime2HMS($usetime).")";
	$disp.="</FORM>";
}

OutSkin();
1;
