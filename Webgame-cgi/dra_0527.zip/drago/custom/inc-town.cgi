#!/usr/bin/perl
# 거리 시설 설정 파일 2003/10/08 유래

# 거리 풍경을 사용자 지정할 수 있습니다.
# 단, “영주 저택”과 하단의 “상점가”, “현재 활동 중인 가게” 항목은 변경할 수 없습니다.
# 장소 번호는 다음과 같이 배치됩니다.
#
#   [No.0]  [   영주 저택   ] [No.1]
#   [No.2]  [No.3]  [No.4] [No.5]
#   [No.6]  [No.7]  [No.8] [No.9]
#                 ·
#                 ·
#   [   상점가   ] [ 활동 중인 가게 ]
#   
#  ※ No.10 이하를 정의하면 시설을 더 추가할 수 있습니다.

#  ＜기본 문법＞
#  ·“이름”, “이미지”, “링크”, “게스트 접속 시 링크” 순서로 작성합니다.
#  ·이미지에는 $i[0](일반 건물), $i[1](가게 건물), $space(작은 빈칸), $vspace(큰 빈칸)을 사용할 수 있습니다.
#  ·링크에는 서브 프로그램명 또는 주소를 지정할 수 있습니다. 비워 두면 링크를 만들지 않습니다.
#  ·정의하지 않은 장소는 빈 칸으로 처리됩니다.

# --- No.0 의장소정의 ---

($Pname[0],$Pimage[0],$Plink[0],$Pguest[0])=(
	"드래곤 경주장",
	qq|<IMG WIDTH=16 HEIGHT=64 SRC="$IMAGE_URL/map/mapsignslime.png">$i[0]|,
	"slime",
	"slime"
	);

# --- No.1 의장소정의 ---

# 예비 공간

# --- No.2 의장소정의 ---

($Pname[2],$Pimage[2],$Plink[2],$Pguest[2])=(
	"의뢰소",
	qq|$space<IMG WIDTH=16 HEIGHT=64 SRC=\"$IMAGE_URL/map/mapsignrequest.png\">$i[1]|,
	"req",
	"req"
	);

# --- No.3 의장소정의 ---

($Pname[3],$Pimage[3],$Plink[3],$Pguest[3])=(
	"시장",
	qq|$space<IMG WIDTH=16 HEIGHT=64 SRC=\"$IMAGE_URL/map/mapsignmarket.png\">$i[1]|,
	"shop-m",
	"shop-m"
	);

# --- No.4 의장소정의 ---

# 예비 공간

# --- No.5 의장소정의 ---

($Pname[5],$Pimage[5],$Plink[5],$Pguest[5])=(
	"길드",
	qq|<IMG WIDTH=16 HEIGHT=64 SRC="$IMAGE_URL/map/mapsignguild.png">$i[0]|,
	"gd",
	"gd"
	);

# --- No.6 의장소정의 ---

# 예비 공간

# --- No.7 의장소정의 ---

($Pname[7],$Pimage[7],$Plink[7],$Pguest[7])=(
	"병사 고용소",
	qq|<IMG WIDTH=16 HEIGHT=64 SRC="$IMAGE_URL/map/mapsignarmy.png">$i[0]|,
	"army",
	""
	);

# --- No.8 의장소정의 ---

($Pname[8],$Pimage[8],$Plink[8],$Pguest[8])=(
	"도서관",
	qq|$space<IMG WIDTH=112 HEIGHT=80 SRC="$IMAGE_URL/map/house1c.png">|,
	"action.cgi?key=library",
	"action.cgi?key=library"
	);

# --- No.9 의장소정의 ---

($Pname[9],$Pimage[9],$Plink[9],$Pguest[9])=(
	"게시판",
	qq|<br><br><IMG WIDTH=32 HEIGHT=32 SRC="$IMAGE_URL/map/mapboard.png">|.GetTime2FormatTime((stat($COMMON_DIR.'/treelog.cgi'))[9]+0,1),
	"treebbs",
	""
	);

# --- 아래에 No.10, 11… 순서로 추가할 수 있습니다.


# --- 캐릭터 대사 ---
# 필요한 경우 자유롭게 수정하세요.

sub CharaDefine
{
@chara=();
	if ($DTevent{rebel})
		{
		$chara[1]=TagChara('큰일이야··· 이대로 두면 안 돼!',"d2");
		$chara[2]=TagChara('반란이다! 모두 조심해!',"d1");
		$chara[5]=TagChara('영주를 쓰러뜨리자',"d1")."<br>".TagChara('이번에 끝장을 내자',"d1");
		return;
		}
my $i=int($NOW_TIME / 3600) % 4;
	if ($i == 0)
		{
		$chara[0]=TagChara("우리 슬라임이 또 도망쳤어···","e1").$vspace.$vspace;
		$chara[4]=$space.TagChara("상인의 판매에 속지 않도록 조심하세요.","e2");
		}
	elsif ($i == 1)
		{
		$chara[7]=$vspace.$vspace.TagChara("도서관의 정보는 중요해요","b2").$space
			.TagChara("게시판 확인도 중요하군요. 흐음···","b1");
		}
	elsif ($i == 2)
		{
		$chara[4]=$vspace.TagChara("조금씩 모으면 큰 도움이 되지···","c2");
		$chara[6]=TagChara("구입은 역시 ".$DT[0]->{shopname}."에서 해야죠","c1").$space;
		}
	elsif ($STATE->{safety} < 4000)
		{
		my $lid=$id2idx{$STATE->{leader}};
		$chara[0]=TagChara(($STATE->{leader} ? $DT[$lid]->{name} : $BAL_NAME).'의 영지에 던전 헌터가!',"a1")
			.TagChara('도와서 마을 전체를 지키자!',"a2");
		}
}
1;

