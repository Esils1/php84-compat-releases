#!/usr/bin/perl
# 스태프 목록 2005/03/30 유래
# 드래고노마 관련 스태프 목록입니다.
#
# 저작권 표시용입니다. 추가한 소재나 프로그램이 있으면 여기에 기록하세요.
# HTML 형식이면 그대로 표시할 수 있습니다.
#
# 스태프 목록 링크를 삭제하거나 눈에 띄지 않게 만들면 안 됩니다.
# 저작권 표시는 적절한 위치에 표시해야 하며, 누락하면 법적 문제가 생길 수 있습니다.

DataRead();
CheckUserPass(1);
OutError("비밀번호가 포함되어 있어 표시하지 않습니다.") if $Q{u};
$disp.="<BIG>●개발 스태프 목록</BIG><br><br>";
$disp.=$TB.$TR.$TD.GetTagImgKao("안내인","guide").$TD;
$disp.='게임 각 부분의 저작권은 아래 명시된 권리자에게 있습니다.<br>';
$disp.='게임에서 자료를 무단 추출해 사용하지 마세요.'.$TRE.$TBE;
$disp.="<br>".$TBT.$TRT.$TD;

# ----------- 아래 내용을 자유롭게 수정할 수 있습니다. -----------------------------

$disp.=<<"HTML";
<SPAN>원작·제작</SPAN> : 유래... <A HREF="http://akimono.org/" target="_blank">상인 이야기</A>
<br><br>
<SPAN>제작</SPAN> : MU 님... <A HREF="http://mutoys.com/" target="_blank">MUTOYS</A>
<br><br>
<SPAN>아이콘</SPAN> : 센타 님... <A HREF="http://yuki-kon.cool.ne.jp/" target="_blank">눈사람 다시마</A>
<br><br>
<SPAN>아이콘(직업·도구)</SPAN> : 시즈 님... <A HREF="http://www2.holon.dyndns.org/~musou/" target="_blank">벽지의 공간 시즈치</A>
<br><br>
<SPAN>아이콘(종류·내용가게)</SPAN> : YOU 님... <A HREF="http://foryou.cside.com/" target="_blank">Net-you's Homepage</A>
<br><br>
<SPAN>아이콘(길드상태)</SPAN> :  아시유 님
<br><br>
<SPAN>지도·캐릭터</SPAN> : REFMAP 님... <A HREF="http://www.mogunet.net/~fsm/" target="_blank">FIRST SEED MATERIAL</A>
<br><br>
<SPAN>음악</SPAN> : 다무 님... <A HREF="http://www.tam-music.com/" target="_blank">ＴＡＭ Ｍｕｓｉｃ Ｆａｃｔｏｒｙ</A>
HTML

# ----------- 여기까지. 마지막의 “HTML” 행을 지우지 않도록 주의하세요. -----------------

require "skin.pl" if -e "skin.pl";
$disp.=$TRE.$TBE;
OutSkin();
1;
