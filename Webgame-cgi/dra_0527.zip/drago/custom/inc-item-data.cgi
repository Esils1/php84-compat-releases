#!/usr/bin/perl
# 드라고노마 아이템 데이터 2005/01/06 기준

# 이파일은아이템데이터의정의파일입니다.
# 원하는 대로 사용자 지정할 수 있습니다. 자세한 내용은 매뉴얼을 확인하세요.

@@DEFINE
	version	05-01-06(DN)		#★상품데이터버전표기
					# 마지막의 DN은 드라고노마용 데이터를 나타냅니다.
					# 도시당신이독자 아이템을핵심 요소에한상인 이야기을만든다면,
					# 이기호을바꾸는의이것이 좋습니다.

	scale	개			#★기본의단위
	type0	전체			# 전체 아이템 수
	type1	촉매
	type2	마법 먹이
	type3	불
	type4	물
	type5	땅
	type6	바람
	type7	성
	type8	사악
	type9	도구
	
	job	warlock		워록	#★직업코드은영소문자10자 이내
	job	dtamer		드래곤 테이머
	job	dmaster		드래곤 마스터
	job	btamer		비스트 테이머
	job	shaman		샤먼
	job	thunter		트레저 헌터
	job	peddle		트레이드 마스터

	MaxMoney	999999999	#★최대자금
	
	set NewShopMoney	100000					#초기자금 (@@FUNCNEW에서사용)
	set NewShopTime		12*60*60				#초기보유 시간(초) (@@FUNCNEW에서사용)
	set NewShopItem		진열대 증축/철거 키트:1:상품권:1	#초기보유 상품 (@@FUNCNEW에서사용) 형식 상품명:개수:상품명:개수:...
	
	TimeEditShowcase	10m		#★진열대조작시간
	TimeShopping		20m		# 매입 시간(이전 SOLD OUT과의 호환성 확보. 현재는 사용하지 않음)
	TimeSendItem		20m		#★아이템매입/이동시간(기본)
	TimeSendItemPlus	20s		#★아이템매입/이동시간(1개변리의추가시간)
	TimeSendMoney		20m		#★자금이동시간(기본)
	TimeSendMoneyPlus	100000		# 쓰레기 처리 시간용 기준 금액(이 금액마다 TimeSendMoney 시간을 소모)
	
	CostShowcase1		0		#★진열대1개일 때유지비
	CostShowcase2		2000	#진열대2개일 때유지비
	CostShowcase3		4000	#진열대3개일 때유지비
	CostShowcase4		8000	#진열대4개일 때유지비
	CostShowcase5		16000	#진열대5개일 때유지비
	CostShowcase6		32000	#진열대6개일 때유지비
	CostShowcase7		64000	#진열대7개일 때유지비
	CostShowcase8		128000	#진열대8개일 때유지비
	
	ItemUseTimeRate		0.5		# 아이템 사용 시 시간 단축률(@USE 안의 time, exptime에 적용)
	

#------ 여기부터아이템정의 ---------------------------------


@@ITEM					#★아이템데이터정의선언
	no		20		#★아이템번호(중복되지 않도록)
	type	도구			#★아이템분류(@@DEFINE의type?의정의을사용)
	code	book-make		#★코드(중복되지 않도록)
	name	책 집필 키트			#★명칭(중복되지 않도록)
	info	책을 쓰기 위한 기본 키트	#★설명
	price	5000				#★표준 가격
	cost	100
	limit	20/10
	pop	20d			#★판매 추세률기준(20일에1개매되는확률)
	scale	세트			#★단위
	plus	20m			#★시장입고률(20분에1개입고하기확률)
	@@USE				#★아이템사용데이터정의선언
		time	90m
		exp		2%
		exptime	30m
		job		워록	times/1.5
		scale	회
		action	쓰기
		name	“기행문”을집필하기
		info	주변 지역을 돌아다닌 기억을 글로 남깁니다
		okmsg	여러 지도 시리즈가 완성되었습니다
		ngmsg	집필에 실패했습니다…
			use		1	책 집필 키트
			get		2	근처 동굴 지도	50%
			get		2	근처 들산 지도	50%
	@@USE
		time	3h
		exp		4%
		exptime	1h
		name	“군자 표변”을집필하기
		info	자신의 새로운 가능성을 책으로 정리합니다
		okmsg	“직업의 비밀”이 완성되었습니다
		ngmsg	집필에 실패했습니다…
			needexp	10%
			use		1	책 집필 키트
			get		3	직업의 비밀	50%
	@@USE
		time	3h
		exp		4%
		exptime	1h
		name	“소환 연구” 집필하기
		info	소환 연구 성과를 책으로 정리합니다
		okmsg	“촉매의 비법”이 완성되었습니다
		ngmsg	집필에 실패했습니다…
			needexp	20%
			use		1	책 집필 키트
			get		4	촉매의 비법	50%
	@@USE
		time	3h
		exp		4%
		exptime	1h
		name	“추리 소설”을집필하기
		info	치밀한 서스펜스는 의외로 실용적입니다
		okmsg	“금단의 책”이 완성되었습니다
		ngmsg	집필에 실패했습니다…
			needexp	30%
			use		1	책 집필 키트
			get		5	금단의 책	40%
	@@USE
		time	4h
		exp		2%
		exptime	2h
		name	“용의 탄생”을집필하기
		info	용을 탄생시키는 방법을 책으로 정리합니다
		okmsg	“드래고노마 법전”이 완성되었습니다
		ngmsg	집필에 실패했습니다…
			needjob	워록
			needexp	50%
			use		1	책 집필 키트
			get		2	드래고노마 법전	50%

@@ITEM
	no		1
	type	촉매
	code	dizmal
	name	디즈멀
	info	불의 힘으로 소환할 때 사용합니다
	price	120
	limit	1500/500
	pop	10d
	plus	-20m
	base	200/600
	scale	개
	cost	40
	point	50%
	@@use
		time	90m
		exp		2%
		exptime	30m
		job		샤먼	times/1.5
		scale	회
		action	소환하기
		name	하급 소환마 부르기
		info	불의 힘으로 소환을 시도합니다
		okmsg	위스프를 소환했습니다
		ngmsg	소환에 실패했습니다…
			need		1	마법진
			use		20	디즈멀
			get		15	위스프	80%
	@@use
		time	1h
		exp		2%
		exptime	20m
		scale	회
		action	소환하기
		name	상급 소환마 부르기
		info	불의 힘으로 소환을 시도합니다
		okmsg	이프리트를 소환했습니다
		ngmsg	소환에 실패했습니다…
			needexp	25%
			need		1	마법진
			use		20	디즈멀
			get		10	이프리트	80%
@@ITEM
	no		2
	type	촉매
	code	jemstone
	name	젬스톤
	info	물의 힘으로 소환할 때 사용합니다
	price	120
	limit	1500/500
	pop	10d
	plus	-20m
	base	200/600
	scale	개
	cost	40
	point	50%
	@@use
		time	90m
		exp		2%
		exptime	30m
		job		샤먼	times/1.5
		scale	회
		action	소환하기
		name	하급 소환마 부르기
		info	물의 힘으로 소환을 시도합니다
		okmsg	슬라임을 소환했습니다
		ngmsg	소환에 실패했습니다…
			need		1	마법진
			use		20	젬스톤
			get		15	슬라임	80%
	@@use
		time	90m
		exp		2%
		exptime	30m
		scale	회
		action	소환하기
		name	상급 소환마 부르기
		info	물의 힘으로 소환을 시도합니다
		okmsg	예티를 소환했습니다
		ngmsg	소환에 실패했습니다…
			needexp	25%
			need		1	마법진
			use		20	젬스톤
			get		10	예티	80%
@@ITEM
	no		3
	type	촉매
	code	chronime
	name	크로나임
	info	땅의 힘으로 소환할 때 사용합니다
	price	120
	limit	1500/500
	pop	10d
	plus	-20m
	base	200/600
	scale	개
	cost	40
	point	50%
	@@use
		time	90m
		exp		2%
		exptime	30m
		job		샤먼	times/1.5
		scale	회
		action	소환하기
		name	하급 소환마 부르기
		info	땅의 힘으로 소환을 시도합니다
		okmsg	노움을 소환했습니다
		ngmsg	소환에 실패했습니다…
			need		1	마법진
			use		20	크로나임
			get		15	노움	80%
	@@use
		time	90m
		exp		2%
		exptime	30m
		scale	회
		action	소환하기
		name	상급 소환마 부르기
		info	땅의 힘으로 소환을 시도합니다
		okmsg	골렘을 소환했습니다
		ngmsg	소환에 실패했습니다…
			needexp	25%
			need		1	마법진
			use		20	크로나임
			get		10	골렘	80%
@@ITEM
	no		4
	type	촉매
	code	fiyel
	name	피엘
	info	바람의 힘으로 소환할 때 사용합니다
	price	120
	limit	1500/500
	pop	10d
	plus	-20m
	base	200/600
	scale	개
	cost	40
	point	50%
	@@use
		time	90m
		exp		2%
		exptime	30m
		job		샤먼	times/1.5
		scale	회
		action	소환하기
		name	하급 소환마 부르기
		info	바람의 힘으로 소환을 시도합니다
		okmsg	실프를 소환했습니다
		ngmsg	소환에 실패했습니다…
			need		1	마법진
			use		20	피엘
			get		15	실프	80%
	@@use
		time	90m
		exp		2%
		exptime	30m
		scale	회
		action	소환하기
		name	상급 소환마 부르기
		info	바람의 힘으로 소환을 시도합니다
		okmsg	그리폰을 소환했습니다
		ngmsg	소환에 실패했습니다…
			needexp	25%
			need		1	마법진
			use		20	피엘
			get		10	그리폰	80%
@@ITEM
	no		5
	type	촉매
	code	crystal
	name	크리스탈
	info	성스러운 힘으로 소환할 때 사용합니다
	price	240
	limit	500/100
	pop	10d
	plus	-20m
	base	100/500
	scale	개
	cost	100
	@@use
		time	90m
		exp		2%
		exptime	30m
		job		샤먼	times/1.5
		scale	회
		action	소환하기
		name	하급 소환마 부르기
		info	성스러운 힘으로 소환을 시도합니다
		okmsg	스피릿을 소환했습니다
		ngmsg	소환에 실패했습니다…
			needexp	10%
			need		1	마법진
			use		10	크리스탈
			get		12	스피릿	80%
	@@use
		time	90m
		exp		2%
		exptime	30m
		scale	회
		action	소환하기
		name	상급 소환마 부르기
		info	성스러운 힘으로 소환을 시도합니다
		okmsg	유니콘을 소환했습니다
		ngmsg	소환에 실패했습니다…
			needexp	25%
			need		1	마법진
			use		10	크리스탈
			get		10	유니콘	80%
@@ITEM
	no		6
	type	촉매
	code	verdure
	name	베르뒤르
	info	사악한 힘으로 소환할 때 사용합니다
	price	240
	limit	500/100
	pop	10d
	plus	-20m
	base	100/500
	scale	개
	cost	100
	@@use
		time	90m
		exp		2%
		exptime	30m
		job		샤먼	times/1.5
		scale	회
		action	소환하기
		name	하급 소환마 부르기
		info	사악한 힘으로 소환을 시도합니다
		okmsg	셰이드를 소환했습니다
		ngmsg	소환에 실패했습니다…
			needexp	10%
			need		1	마법진
			use		10	베르뒤르
			get		12	셰이드	80%
	@@use
		time	90m
		exp		2%
		exptime	30m
		scale	회
		action	소환하기
		name	상급 소환마 부르기
		info	사악한 힘으로 소환을 시도합니다
		okmsg	데몬을 소환했습니다
		ngmsg	소환에 실패했습니다…
			needexp	25%
			need		1	마법진
			use		10	베르뒤르
			get		10	데몬	80%

@@ITEM
	no		21
	type	도구
	code	book-dk
	name	근처 동굴 지도
	info	촉매를 구하기 좋은 동굴 지도입니다
	price	10000
	limit	100/1
	pop	24h
	plus	2h
	base	50/150
	scale	권
	cost	1000
	point	500%
	@@use
		time	2h
		exp		2%
		exptime	30m
		job		트레저 헌터	times/1.5
		scale	왕복
		action	탐색하러 가기
		name	용암 광산 탐색
		info	여러 촉매를 구할 수 있을지도 모릅니다
		ngmsg	아무것도 찾지 못했습니다…
			get		40	디즈멀	90%	디즈멀이많이 발견했습니다
			get		2	크로나임	90%
			get		3	베르뒤르	45%
	@@use
		time	2h
		exp		2%
		exptime	30m
		scale	왕복
		action	탐색하러 가기
		name	지하 수맥 탐색
		info	여러 촉매를 구할 수 있을지도 모릅니다
		ngmsg	아무것도 찾지 못했습니다…
			get		40	젬스톤	90%	젬스톤이많이 발견했습니다
			get		2	피엘	90%
			get		3	크리스탈	45%
	@@use
		time	2h
		exp		2%
		exptime	30m
		scale	왕복
		action	탐색하러 가기
		name	굴착지 탐색
		info	여러 촉매를 구할 수 있을지도 모릅니다
		ngmsg	아무것도 찾지 못했습니다…
			get		2	디즈멀	90%
			get		40	크로나임	90%	크로나임이많이 발견했습니다
			get		3	베르뒤르	45%
	@@use
		time	2h
		exp		2%
		exptime	30m
		scale	왕복
		action	탐색하러 가기
		name	통풍구 탐색
		info	여러 촉매를 구할 수 있을지도 모릅니다
		ngmsg	아무것도 찾지 못했습니다…
			get		2	젬스톤	90%
			get		40	피엘	90%	피엘이많이 발견했습니다
			get		3	크리스탈	45%
	@@use
		time	2h
		exp		2%
		exptime	30m
		scale	왕복
		action	탐색하러 가기
		name	종유동 탐색
		info	여러 촉매를 구할 수 있을지도 모릅니다
		ngmsg	아무것도 찾지 못했습니다…
			needexp	10%
			get		2	젬스톤	90%
			get		2	피엘	90%
			get		40	크리스탈	45%	크리스탈이많이 발견했습니다
	@@use
		time	2h
		exp		2%
		exptime	30m
		scale	왕복
		action	탐색하러 가기
		name	봉마벽 탐색
		info	여러 촉매를 구할 수 있을지도 모릅니다
		ngmsg	아무것도 찾지 못했습니다…
			needexp	10%
			get		2	디즈멀	90%
			get		2	크로나임	90%
			get		40	베르뒤르	45%	베르뒤르이많이 발견했습니다
	
@@ITEM
	no		22
	type	도구
	code	book-ny
	name	근처 들산 지도
	info	몬스터가 좋아하는 먹이를 채집할 수 있을 듯합니다
	price	10000
	limit	100/1
	pop	24h
	plus	-1h
	base	50/150
	scale	권
	cost	1000
	point	500%
	@@use
		time	2h
		exp		2%
		exptime	30m
		job		트레저 헌터	times/1.5
		scale	왕복
		action	탐색하러 가기
		name	들판 탐색
		info	여러 먹이를 구할 수 있을지도 모릅니다
		ngmsg	아무것도 찾지 못했습니다…
			get		60	뱀딸기	70%	뱀딸기이많이 발견했습니다
			get		3	달꽃 고사리	70%
			get		3	눈사람 다시마	35%
			get		3	도마뱀 꼬리	35%
			get		3	고양이 수염	35%
	@@use
		time	2h
		exp		2%
		exptime	30m
		scale	왕복
		action	탐색하러 가기
		name	숲 탐색
		info	여러 먹이를 구할 수 있을지도 모릅니다
		ngmsg	아무것도 찾지 못했습니다…
			get		3	뱀딸기	70%
			get		60	달꽃 고사리	70%	달꽃 고사리를 많이 발견했습니다
			get		3	눈사람 다시마	35%
			get		3	도마뱀 꼬리	35%
			get		3	고양이 수염	35%
	@@use
		time	2h
		exp		2%
		exptime	30m
		scale	왕복
		action	탐색하러 가기
		name	해변 탐색
		info	여러 먹이를 구할 수 있을지도 모릅니다
		ngmsg	아무것도 찾지 못했습니다…
			get		3	뱀딸기	70%
			get		3	달꽃 고사리	70%
			get		30	눈사람 다시마	70%	눈사람 다시마이많이 발견했습니다
			get		3	도마뱀 꼬리	35%
			get		3	고양이 수염	35%
	@@use
		time	2h
		exp		2%
		exptime	30m
		scale	왕복
		action	탐색하러 가기
		name	바위산 탐색
		info	여러 먹이를 구할 수 있을지도 모릅니다
		ngmsg	아무것도 찾지 못했습니다…
			get		3	뱀딸기	70%
			get		3	달꽃 고사리	70%
			get		3	눈사람 다시마	35%
			get		30	도마뱀 꼬리	70%	도마뱀 꼬리을 많이 손에 넣었습니다
			get		3	고양이 수염	35%
	@@use
		time	2h
		exp		2%
		exptime	30m
		scale	왕복
		action	탐색하러 가기
		name	공원 탐색
		info	여러 먹이를 구할 수 있을지도 모릅니다
		ngmsg	아무것도 찾지 못했습니다…
			get		3	뱀딸기	70%
			get		3	달꽃 고사리	70%
			get		3	눈사람 다시마	35%
			get		3	도마뱀 꼬리	35%
			get		30	고양이 수염	70%	고양이 수염을 많이 손에 넣었습니다


@@ITEM
	no		7
	type	불
	code	wisp
	name	위스프
	info	하급 소환마. 떠다니는 불덩이
	price	1200
	limit	600
	base	50/100
	plus	-1h
	pop	3h
	scale	마리
	point	120%
	flag	norequest
@@ITEM
	no		8
	type	물
	code	slime
	name	슬라임
	info	하급 소환마. 끈적끈적한 생물
	price	1200
	limit	600
	base	50/100
	plus	-1h
	pop	3h
	scale	마리
	point	120%
	flag	norequest
@@ITEM
	no		9
	type	땅
	code	gnome
	name	노움
	info	하급 소환마. 땅속의 작은 사람
	price	1200
	limit	600
	base	50/100
	plus	-1h
	pop	3h
	scale	마리
	point	120%
	flag	norequest
@@ITEM
	no		10
	type	바람
	code	sylph
	name	실프
	info	하급 소환마. 작은 바람의 정령
	price	1200
	limit	600
	base	50/100
	plus	-1h
	pop	3h
	scale	마리
	point	120%
	flag	norequest
@@ITEM
	no		11
	type	성
	code	spirit
	name	스피릿
	info	하급 소환마. 떠다니는 정령
	price	1500
	limit	500
	base	50/100
	plus	-1h
	pop	225m
	scale	마리
	point	150%
	flag	norequest
@@ITEM
	no		12
	type	사악
	code	shade
	name	셰이드
	info	하급 소환마. 어둠 속을 떠도는 그림자
	price	1500
	limit	500
	base	50/100
	plus	-1h
	pop	225m
	scale	마리
	point	150%
	flag	norequest

@@ITEM
	no		13
	type	불
	code	efreet
	name	이프리트
	info	상급 소환마. 불의 마신
	price	2400
	limit	300
	base	50/100
	plus	-1h
	pop	6h
	scale	마리
	point	200%
	flag	norequest
	@@use
		time	2h
		job		비스트 테이머	times/1.5
		scale	개
		action	시작
		name	알 껍질 깨기 도움받기
		info	곧 부화할 알의 껍질을 이프리트이 깨 줍니다
		param	알에서 샐러맨더이 태어났습니다!
			use		1	곧 부화할 알
			get		1	샐러맨더
		arg		nocount
		func	memo
@@ITEM
	no		14
	type	물
	code	yeti
	name	예티
	info	상급 소환마. 눈 속에 사는 거인
	price	2400
	limit	300
	base	50/100
	plus	-1h
	pop	6h
	scale	마리
	point	200%
	flag	norequest
	@@use
		time	2h
		job		비스트 테이머	times/1.5
		scale	개
		action	시작
		name	알 껍질 깨기 도움받기
		info	곧 부화할 알의 껍질을 예티이 깨 줍니다
		param	알에서 요르문간드이 태어났습니다!
			use		1	곧 부화할 알
			get		1	요르문간드
		arg		nocount
		func	memo
@@ITEM
	no		15
	type	땅
	code	golem
	name	골렘
	info	상급 소환마. 땅에서 만들어진 거인
	price	2400
	limit	300
	base	50/100
	plus	-1h
	pop	6h
	scale	마리
	point	200%
	flag	norequest
	@@use
		time	2h
		job		비스트 테이머	times/1.5
		scale	개
		action	시작
		name	알 껍질 깨기 도움받기
		info	곧 부화할 알의 껍질을 골렘이 깨 줍니다
		param	알에서 바실리스크이 태어났습니다!
			use		1	곧 부화할 알
			get		1	바실리스크
		arg		nocount
		func	memo
@@ITEM
	no		16
	type	바람
	code	griffin
	name	그리폰
	info	상급 소환마. 독수리의 날개와 사자의 몸을 지님
	price	2400
	limit	300
	base	50/100
	plus	-1h
	pop	6h
	scale	마리
	point	200%
	flag	norequest
	@@use
		time	2h
		job		비스트 테이머	times/1.5
		scale	개
		action	시작
		name	알 껍질 깨기 도움받기
		info	곧 부화할 알의 껍질을 그리폰이 깨 줍니다
		param	알에서 타이폰이 태어났습니다!
			use		1	곧 부화할 알
			get		1	타이폰
		arg		nocount
		func	memo
@@ITEM
	no		17
	type	성
	code	unicorn
	name	유니콘
	info	상급 소환마. 성스러운 뿔을 지닌 말
	price	2400
	limit	300
	base	50/100
	plus	-1h
	pop	6h
	scale	마리
	point	200%
	flag	norequest
	@@use
		time	2h
		job		비스트 테이머	times/1.5
		scale	개
		action	시작
		name	알 껍질 깨기 도움받기
		info	곧 부화할 알의 껍질을 유니콘이 깨 줍니다
		param	알에서 화이트 스네이크이 태어났습니다!
			use		1	곧 부화할 알
			get		1	화이트 스네이크
		arg		nocount
		func	memo
@@ITEM
	no		18
	type	사악
	code	demon
	name	데몬
	info	상급 소환마. 지하에 사는 마물
	price	2400
	limit	300
	base	50/100
	plus	-1h
	pop	6h
	scale	마리
	point	200%
	flag	norequest
	@@use
		time	2h
		job		비스트 테이머	times/1.5
		scale	개
		action	시작
		name	알 껍질 깨기 도움받기
		info	곧 부화할 알의 껍질을 데몬이 깨 줍니다
		param	알에서 쁘띠 히드라이 태어났습니다!
			use		1	곧 부화할 알
			get		1	쁘띠 히드라
		arg		nocount
		func	memo

@@ITEM
	no		31
	type	불
	code	salamander
	name	샐러맨더
	info	기초 드래곤. 불꽃 속에서 태어난 용
	price	6000
	limit	150
	base	20/40
	plus	-1h
	pop	12h
	scale	마리
	point	400%
	flag	norequest
	@@use
		time	600
		exp		1%
		exptime	200
		job		비스트 테이머	times/1.5
		scale	개
		action	시작
		name	알 껍질 깨기 도움받기
		info	곧 부화할 알의 껍질을 샐러맨더이 깨 줍니다
		okmsg	알에서 샐러맨더이 태어났습니다
			use		1	곧 부화할 알
			get		1	샐러맨더
	@@use
		time	2h
		exp		1%
		arg	nocount
		scale	회
		action	교육하기
		name	블록 놀이 가르치기
		info	블록으로 노는 법을 가르칩니다
		ngmsg	블록에는 별로 관심이 없는 것 같습니다...
			need		1	블록
	@@use
		time	2h
		exp		1%
		arg	nocount
		scale	회
		action	교육하기
		name	나는 법 가르치기
		info	하늘을 나는 법을 가르칩니다
		param	31,37,공을비부코와
		func	education
			need		1	비행 기술
	@@use
		time	2h
		exp		1%
		arg	nocount
		scale	회
		action	교육하기
		name	국제 대화을가르치기
		info	다른 존재와 소통하는 법을 가르칩니다
		ngmsg	대화에는 별로 관심이 없는 것 같습니다...
			need		1	기초부터 배우는 ABC
@@ITEM
	no		32
	type	물
	code	jormungand
	name	요르문간드
	info	기초 드래곤. 바닷속에 사는 거대한 용
	price	6000
	limit	150
	base	20/40
	plus	-1h
	pop	12h
	scale	마리
	point	400%
	flag	norequest
	@@use
		time	600
		exp		1%
		exptime	200
		job		비스트 테이머	times/1.5
		scale	개
		action	시작
		name	알 껍질 깨기 도움받기
		info	곧 부화할 알의 껍질을 요르문간드이 깨 줍니다
		okmsg	알에서 요르문간드이 태어났습니다
			use		1	곧 부화할 알
			get		1	요르문간드
	@@use
		time	2h
		exp		1%
		arg	nocount
		scale	회
		action	교육하기
		name	블록 놀이 가르치기
		info	블록으로 노는 법을 가르칩니다
		ngmsg	블록에는 별로 관심이 없는 것 같습니다...
			need		1	블록
	@@use
		time	2h
		exp		1%
		arg	nocount
		scale	회
		action	교육하기
		name	꾸미는 법 가르치기
		info	거울을 사용해 꾸미는 법을 가르칩니다
		ngmsg	거울에는 별로 관심이 없는 것 같습니다...
			need		1	거울
	@@use
		time	2h
		exp		1%
		arg	nocount
		scale	회
		action	교육하기
		name	화장실 훈련하기
		info	유아용 변기 사용법을 가르칩니다
		param	32,38,배변 훈련
		func	education
			need		1	유아용 변기
@@ITEM
	no		33
	type	땅
	code	basilisk
	name	바실리스크
	info	기초 드래곤. 바라본 상대를 돌로 만드는 용
	price	6000
	limit	150
	base	20/40
	plus	-1h
	pop	12h
	scale	마리
	point	400%
	flag	norequest
	@@use
		time	600
		exp		1%
		exptime	200
		job		비스트 테이머	times/1.5
		scale	개
		action	시작
		name	알 껍질 깨기 도움받기
		info	곧 부화할 알의 껍질을 바실리스크이 깨 줍니다
		okmsg	알에서 바실리스크이 태어났습니다
			use		1	곧 부화할 알
			get		1	바실리스크
	@@use
		time	2h
		exp		1%
		arg	nocount
		scale	회
		action	교육하기
		name	블록 놀이 가르치기
		info	블록으로 노는 법을 가르칩니다
		param	33,39,블록유비
		func	education
			need		1	블록
	@@use
		time	2h
		exp		1%
		arg	nocount
		scale	회
		action	교육하기
		name	꾸미는 법 가르치기
		info	거울을 사용해 꾸미는 법을 가르칩니다
			need		1	거울
			get		50	크로나임
		func	_local_
			my $ret;
			$ret.="바실리스크은 거울 때문에 자기 자신을 석화시켜 버렸습니다!";
			UseItem(33,1);
			return $ret;
		_local_
	@@use
		time	2h
		exp		1%
		arg	nocount
		scale	회
		action	교육하기
		name	나는 법 가르치기
		info	하늘을 나는 법을 가르칩니다
		ngmsg	비행 연습에는 별로 관심이 없는 것 같습니다...
			need		1	비행 기술
@@ITEM
	no		34
	type	바람
	code	typhon
	name	타이폰
	info	기초 드래곤. 거센 바람을 일으키는 폭풍의 용
	price	6000
	limit	150
	base	20/40
	plus	-1h
	pop	12h
	scale	마리
	point	400%
	flag	norequest
	@@use
		time	600
		exp		1%
		exptime	200
		job		비스트 테이머	times/1.5
		scale	개
		action	시작
		name	알 껍질 깨기 도움받기
		info	곧 부화할 알의 껍질을 타이폰이 깨 줍니다
		okmsg	알에서 타이폰이 태어났습니다
			use		1	곧 부화할 알
			get		1	타이폰
	@@use
		time	2h
		exp		1%
		arg	nocount
		scale	회
		action	교육하기
		name	블록 놀이 가르치기
		info	블록으로 노는 법을 가르칩니다
		ngmsg	블록에는 별로 관심이 없는 것 같습니다...
			need		1	블록
	@@use
		time	2h
		exp		1%
		arg	nocount
		scale	회
		action	교육하기
		name	화장실 훈련하기
		info	유아용 변기 사용법을 가르칩니다
		ngmsg	유아용 변기에는 별로 관심이 없는 것 같습니다...
			need		1	유아용 변기
	@@use
		time	2h
		exp		1%
		arg	nocount
		scale	회
		action	교육하기
		name	꾸미는 법 가르치기
		info	거울을 사용해 꾸미는 법을 가르칩니다
		param	34,40,오시야레
		func	education
			need		1	거울
@@ITEM
	no		35
	type	성
	code	whitesnake
	name	화이트 스네이크
	info	기초 드래곤. 행운을 가져오는 흰 뱀
	price	6000
	limit	150
	base	20/40
	plus	-1h
	pop	12h
	scale	마리
	point	400%
	flag	norequest
	@@use
		time	600
		exp		1%
		exptime	200
		job		비스트 테이머	times/1.5
		scale	개
		action	시작
		name	알 껍질 깨기 도움받기
		info	곧 부화할 알의 껍질을 화이트 스네이크이 깨 줍니다
		okmsg	알에서 화이트 스네이크이 태어났습니다
			use		1	곧 부화할 알
			get		1	화이트 스네이크
	@@use
		time	2h
		exp		1%
		arg	nocount
		scale	회
		action	교육하기
		name	화장실 훈련하기
		info	유아용 변기 사용법을 가르칩니다
		ngmsg	유아용 변기에는 별로 관심이 없는 것 같습니다...
			need		1	유아용 변기
	@@use
		time	2h
		exp		1%
		arg	nocount
		scale	회
		action	교육하기
		name	걷는 법 가르치기
		info	걷는 법을 가르칩니다
		ngmsg	걸음마에는 별로 관심이 없는 것 같습니다...
			need		1	걸음마 잘하는 책
	@@use
		time	2h
		exp		1%
		arg	nocount
		scale	회
		action	교육하기
		name	나는 법 가르치기
		info	하늘을 나는 법을 가르칩니다
		param	35,41,공을비부코와
		func	education
			need		1	비행 기술
@@ITEM
	no		36
	type	사악
	code	petithydra
	name	쁘띠 히드라
	info	기초 드래곤. 여러 머리를 가진 용
	price	6000
	limit	150
	base	20/40
	plus	-1h
	pop	12h
	scale	마리
	point	400%
	flag	norequest
	@@use
		time	600
		exp		1%
		exptime	200
		job		비스트 테이머	times/1.5
		scale	개
		action	시작
		name	알 껍질 깨기 도움받기
		info	곧 부화할 알의 껍질을 쁘띠 히드라이 깨 줍니다
		okmsg	알에서 쁘띠 히드라이 태어났습니다
			use		1	곧 부화할 알
			get		1	쁘띠 히드라
	@@use
		time	2h
		exp		1%
		arg	nocount
		scale	회
		action	교육하기
		name	걷는 법 가르치기
		info	걷는 법을 가르칩니다
		ngmsg	걸음마에는 별로 관심이 없는 것 같습니다...
			need		1	걸음마 잘하는 책
	@@use
		time	2h
		exp		1%
		arg	nocount
		scale	회
		action	교육하기
		name	나는 법 가르치기
		info	하늘을 나는 법을 가르칩니다
		ngmsg	비행 연습에는 별로 관심이 없는 것 같습니다...
			need		1	비행 기술
	@@use
		time	2h
		exp		1%
		arg	nocount
		scale	회
		action	교육하기
		name	국제 대화을가르치기
		info	다른 존재와 소통하는 법을 가르칩니다
		param	36,42,회화의사방
		func	education
			need		1	기초부터 배우는 ABC
@@ITEM
	no		37
	type	불
	code	lesserropros
	name	레서 로프로스
	info	중급 드래곤. 날개를 펼쳐 하늘을 가르는 용
	price	9600
	limit	100
	base	10/30
	plus	-1h
	pop	18h
	scale	마리
	point	360%
	flag	norequest
	@@use
		time	750
		exp		1%
		exptime	250
		job		비스트 테이머	times/1.5
		job		드래곤 테이머	times/1.5
		scale	개
		action	시작
		name	알 껍질 깨기 도움받기
		info	곧 부화할 알의 껍질을 레서 로프로스이 깨 줍니다
		okmsg	알에서 레서 로프로스이 태어났습니다
			use		1	곧 부화할 알
			get		1	레서 로프로스
	@@use
		time	2h
		exp		1%
		arg	nocount
		scale	회
		action	교육하기
		name	꾸미는 법 가르치기
		info	거울을 사용해 꾸미는 법을 가르칩니다
		ngmsg	거울에는 별로 관심이 없는 것 같습니다...
			need		1	거울
	@@use
		time	2h
		exp		1%
		arg	nocount
		scale	회
		action	교육하기
		name	걷는 법 가르치기
		info	걷는 법을 가르칩니다
		ngmsg	걸음마에는 별로 관심이 없는 것 같습니다...
			need		1	걸음마 잘하는 책
	@@use
		time	2h
		exp		1%
		arg	nocount
		scale	회
		action	교육하기
		name	국제 대화을가르치기
		info	다른 존재와 소통하는 법을 가르칩니다
		param	37,43,회화의사방
		func	education
			need		1	기초부터 배우는 ABC
@@ITEM
	no		38
	type	물
	code	leviathan
	name	리바이어선
	info	중급 드래곤. 바다를 뒤흔드는 거대한 용
	price	9600
	limit	100
	base	10/30
	plus	-1h
	pop	18h
	scale	마리
	point	360%
	flag	norequest
	@@use
		time	750
		exp		1%
		exptime	250
		job		비스트 테이머	times/1.5
		job		드래곤 테이머	times/1.5
		scale	개
		action	시작
		name	알 껍질 깨기 도움받기
		info	곧 부화할 알의 껍질을 리바이어선이 깨 줍니다
		okmsg	알에서 리바이어선이 태어났습니다
			use		1	곧 부화할 알
			get		1	리바이어선
	@@use
		time	2h
		exp		1%
		arg	nocount
		scale	회
		action	교육하기
		name	걷는 법 가르치기
		info	걷는 법을 가르칩니다
		ngmsg	걸음마에는 별로 관심이 없는 것 같습니다...
			need		1	걸음마 잘하는 책
	@@use
		time	2h
		exp		1%
		arg	nocount
		scale	회
		action	교육하기
		name	나는 법 가르치기
		info	하늘을 나는 법을 가르칩니다
		ngmsg	비행 연습에는 별로 관심이 없는 것 같습니다...
			need		1	비행 기술
	@@use
		time	2h
		exp		1%
		arg	nocount
		scale	회
		action	교육하기
		name	고차방정식 가르치기
		info	고급 수학을 가르칩니다
		param	38,44,고급인수학
		func	education
			need		1	고차방정식 풀이
@@ITEM
	no		39
	type	땅
	code	stoorworm
	name	스톰 웜
	info	중급 드래곤. 단단한 껍질로 땅을 파고드는 용
	price	9600
	limit	100
	base	10/30
	plus	-1h
	pop	18h
	scale	마리
	point	360%
	flag	norequest
	@@use
		time	750
		exp		1%
		exptime	250
		job		비스트 테이머	times/1.5
		job		드래곤 테이머	times/1.5
		scale	개
		action	시작
		name	알 껍질 깨기 도움받기
		info	곧 부화할 알의 껍질을 스톰 웜이 깨 줍니다
		okmsg	알에서 스톰 웜이 태어났습니다
			use		1	곧 부화할 알
			get		1	스톰 웜
	@@use
		time	2h
		exp		1%
		arg	nocount
		scale	회
		action	교육하기
		name	꾸미는 법 가르치기
		info	거울을 사용해 꾸미는 법을 가르칩니다
		ngmsg	거울에는 별로 관심이 없는 것 같습니다...
			need		1	거울
	@@use
		time	2h
		exp		1%
		arg	nocount
		scale	회
		action	교육하기
		name	걷는 법 가르치기
		info	걷는 법을 가르칩니다
		param	39,45,보줄의방법
		func	education
			need		1	걸음마 잘하는 책
	@@use
		time	2h
		exp		1%
		arg	nocount
		scale	회
		action	교육하기
		name	고차방정식 가르치기
		info	고급 수학을 가르칩니다
		ngmsg	수학에는 별로 관심이 없는 것 같습니다...
			need		1	고차방정식 풀이
@@ITEM
	no		40
	type	바람
	code	thunderhawk
	name	썬더 호크
	info	중급 드래곤. 번개의 날개로 하늘을 도는 용
	price	9600
	limit	100
	base	10/30
	plus	-1h
	pop	18h
	scale	마리
	point	360%
	flag	norequest
	@@use
		time	750
		exp		1%
		exptime	250
		job		비스트 테이머	times/1.5
		job		드래곤 테이머	times/1.5
		scale	개
		action	시작
		name	알 껍질 깨기 도움받기
		info	곧 부화할 알의 껍질을 썬더 호크이 깨 줍니다
		okmsg	알에서 썬더 호크이 태어났습니다
			use		1	곧 부화할 알
			get		1	썬더 호크
	@@use
		time	2h
		exp		1%
		arg	nocount
		scale	회
		action	교육하기
		name	화장실 훈련하기
		info	유아용 변기 사용법을 가르칩니다
		param	40,46,배변 훈련
		func	education
			need		1	유아용 변기
	@@use
		time	2h
		exp		1%
		arg	nocount
		scale	회
		action	교육하기
		name	국제 대화을가르치기
		info	다른 존재와 소통하는 법을 가르칩니다
		ngmsg	대화에는 별로 관심이 없는 것 같습니다...
			need		1	기초부터 배우는 ABC
	@@use
		time	2h
		exp		1%
		arg	nocount
		scale	회
		action	교육하기
		name	고차방정식 가르치기
		info	고급 수학을 가르칩니다
		ngmsg	수학에는 별로 관심이 없는 것 같습니다...
			need		1	고차방정식 풀이
@@ITEM
	no		41
	type	성
	code	lindwurm
	name	린드브룸
	info	중급 드래곤. 하늘에 사는 비룡
	price	9600
	limit	100
	base	10/30
	plus	-1h
	pop	18h
	scale	마리
	point	360%
	flag	norequest
	@@use
		time	750
		exp		1%
		exptime	250
		job		비스트 테이머	times/1.5
		job		드래곤 테이머	times/1.5
		scale	개
		action	시작
		name	알 껍질 깨기 도움받기
		info	곧 부화할 알의 껍질을 린드브룸이 깨 줍니다
		okmsg	알에서 린드브룸이 태어났습니다
			use		1	곧 부화할 알
			get		1	린드브룸
	@@use
		time	2h
		exp		1%
		arg	nocount
		scale	회
		action	교육하기
		name	블록 놀이 가르치기
		info	블록으로 노는 법을 가르칩니다
		ngmsg	블록에는 별로 관심이 없는 것 같습니다...
			need		1	블록
	@@use
		time	2h
		exp		1%
		arg	nocount
		scale	회
		action	교육하기
		name	꾸미는 법 가르치기
		info	거울을 사용해 꾸미는 법을 가르칩니다
		param	41,47,오시야레
		func	education
			need		1	거울
	@@use
		time	2h
		exp		1%
		arg	nocount
		scale	회
		action	교육하기
		name	국제 대화을가르치기
		info	다른 존재와 소통하는 법을 가르칩니다
		ngmsg	대화에는 별로 관심이 없는 것 같습니다...
			need		1	기초부터 배우는 ABC
@@ITEM
	no		42
	type	사악
	code	Ladon
	name	라돈
	info	중급 드래곤. 여러 머리를 가진 드래곤
	price	9600
	limit	100
	base	10/30
	plus	-1h
	pop	18h
	scale	마리
	point	360%
	flag	norequest
	@@use
		time	750
		exp		1%
		exptime	250
		job		비스트 테이머	times/1.5
		job		드래곤 테이머	times/1.5
		scale	개
		action	시작
		name	알 껍질 깨기 도움받기
		info	곧 부화할 알의 껍질을 라돈이 깨 줍니다
		okmsg	알에서 라돈이 태어났습니다
			use		1	곧 부화할 알
			get		1	라돈
	@@use
		time	2h
		exp		1%
		arg	nocount
		scale	회
		action	교육하기
		name	블록 놀이 가르치기
		info	블록으로 노는 법을 가르칩니다
		param	42,48,블록유비
		func	education
			need		1	블록
	@@use
		time	2h
		exp		1%
		arg	nocount
		scale	회
		action	교육하기
		name	나는 법 가르치기
		info	하늘을 나는 법을 가르칩니다
		ngmsg	비행 연습에는 별로 관심이 없는 것 같습니다...
			need		1	비행 기술
	@@use
		time	2h
		exp		1%
		arg	nocount
		scale	회
		action	교육하기
		name	고차방정식 가르치기
		info	고급 수학을 가르칩니다
		ngmsg	수학에는 별로 관심이 없는 것 같습니다...
			need		1	고차방정식 풀이
@@ITEM
	no		43
	type	불
	code	firedragon
	name	파이어 드래곤
	info	상급 드래곤. 강력한 브레스를 내뿜는 용
	price	15000
	limit	60
	base	10/20
	plus	-1h
	pop	22h
	scale	마리
	point	240%
	flag	norequest
	@@use
		time	900
		exp		1%
		exptime	300
		job		드래곤 테이머	times/1.5
		job		드래곤 마스터	times/1.5
		scale	개
		action	시작
		name	알 껍질 깨기 도움받기
		info	곧 부화할 알의 껍질을 파이어 드래곤이 깨 줍니다
		okmsg	알에서 파이어 드래곤이 태어났습니다
			use		1	곧 부화할 알
			get		1	파이어 드래곤
	@@use
		time	2h
		exp		1%
		arg	nocount
		scale	회
		action	교육하기
		name	꾸미는 법 가르치기
		info	거울을 사용해 꾸미는 법을 가르칩니다
		ngmsg	거울에는 별로 관심이 없는 것 같습니다...
			need		1	거울
	@@use
		time	2h
		exp		1%
		arg	nocount
		scale	회
		action	교육하기
		name	국제 대화을가르치기
		info	다른 존재와 소통하는 법을 가르칩니다
		ngmsg	대화에는 별로 관심이 없는 것 같습니다...
			need		1	기초부터 배우는 ABC
	@@use
		time	2h
		exp		1%
		arg	nocount
		scale	회
		action	교육하기
		name	고차방정식 가르치기
		info	고급 수학을 가르칩니다
		param	43,49,고급인수학
		func	education
			need		1	고차방정식 풀이
@@ITEM
	no		44
	type	물
	code	colddragon
	name	콜드 드래곤
	info	상급 드래곤. 강력한 브레스를 내뿜는 용
	price	15000
	limit	60
	base	10/20
	plus	-1h
	pop	22h
	scale	마리
	point	240%
	flag	norequest
	@@use
		time	900
		exp		1%
		exptime	300
		job		드래곤 테이머	times/1.5
		job		드래곤 마스터	times/1.5
		scale	개
		action	시작
		name	알 껍질 깨기 도움받기
		info	곧 부화할 알의 껍질을 콜드 드래곤이 깨 줍니다
		okmsg	알에서 콜드 드래곤이 태어났습니다
			use		1	곧 부화할 알
			get		1	콜드 드래곤
	@@use
		time	2h
		exp		1%
		arg	nocount
		scale	회
		action	교육하기
		name	블록 놀이 가르치기
		info	블록으로 노는 법을 가르칩니다
		ngmsg	블록에는 별로 관심이 없는 것 같습니다...
			need		1	블록
	@@use
		time	2h
		exp		1%
		arg	nocount
		scale	회
		action	교육하기
		name	화장실 훈련하기
		info	유아용 변기 사용법을 가르칩니다
		ngmsg	유아용 변기에는 별로 관심이 없는 것 같습니다...
			need		1	유아용 변기
	@@use
		time	2h
		exp		1%
		arg	nocount
		scale	회
		action	교육하기
		name	꾸미는 법 가르치기
		info	거울을 사용해 꾸미는 법을 가르칩니다
		param	44,50,오시야레
		func	education
			need		1	거울
@@ITEM
	no		45
	type	땅
	code	earthdragon
	name	어스 드래곤
	info	상급 드래곤. 대지의 브레스를 내뿜는 용
	price	15000
	limit	60
	base	10/20
	plus	-1h
	pop	22h
	scale	마리
	point	240%
	flag	norequest
	@@use
		time	900
		exp		1%
		exptime	300
		job		드래곤 테이머	times/1.5
		job		드래곤 마스터	times/1.5
		scale	개
		action	시작
		name	알 껍질 깨기 도움받기
		info	곧 부화할 알의 껍질을 어스 드래곤이 깨 줍니다
		okmsg	알에서 어스 드래곤이 태어났습니다
			use		1	곧 부화할 알
			get		1	어스 드래곤
	@@use
		time	2h
		exp		1%
		arg	nocount
		scale	회
		action	교육하기
		name	화장실 훈련하기
		info	유아용 변기 사용법을 가르칩니다
		ngmsg	유아용 변기에는 별로 관심이 없는 것 같습니다...
			need		1	유아용 변기
	@@use
		time	2h
		exp		1%
		arg	nocount
		scale	회
		action	교육하기
		name	나는 법 가르치기
		info	하늘을 나는 법을 가르칩니다
		param	45,51,공을비부코와
		func	education
			need		1	비행 기술
	@@use
		time	2h
		exp		1%
		arg	nocount
		scale	회
		action	교육하기
		name	고차방정식 가르치기
		info	고급 수학을 가르칩니다
		ngmsg	수학에는 별로 관심이 없는 것 같습니다...
			need		1	고차방정식 풀이
@@ITEM
	no		46
	type	바람
	code	thunderdragon
	name	썬더 드래곤
	info	상급 드래곤. 강력한 브레스를 내뿜는 용
	price	15000
	limit	60
	base	10/20
	plus	-1h
	pop	22h
	scale	마리
	point	240%
	flag	norequest
	@@use
		time	900
		exp		1%
		exptime	300
		job		드래곤 테이머	times/1.5
		job		드래곤 마스터	times/1.5
		scale	개
		action	시작
		name	알 껍질 깨기 도움받기
		info	곧 부화할 알의 껍질을 썬더 드래곤이 깨 줍니다
		okmsg	알에서 썬더 드래곤이 태어났습니다
			use		1	곧 부화할 알
			get		1	썬더 드래곤
	@@use
		time	2h
		exp		1%
		arg	nocount
		scale	회
		action	교육하기
		name	걷는 법 가르치기
		info	걷는 법을 가르칩니다
		param	46,52,보줄의방법
		func	education
			need		1	걸음마 잘하는 책
	@@use
		time	2h
		exp		1%
		arg	nocount
		scale	회
		action	교육하기
		name	국제 대화을가르치기
		info	다른 존재와 소통하는 법을 가르칩니다
		ngmsg	대화에는 별로 관심이 없는 것 같습니다...
			need		1	기초부터 배우는 ABC
	@@use
		time	2h
		exp		1%
		arg	nocount
		scale	회
		action	교육하기
		name	고차방정식 가르치기
		info	고급 수학을 가르칩니다
		ngmsg	수학에는 별로 관심이 없는 것 같습니다...
			need		1	고차방정식 풀이
@@ITEM
	no		47
	type	성
	code	holydragon
	name	홀리 드래곤
	info	상급 드래곤. 강력한 브레스를 내뿜는 용
	price	15000
	limit	60
	base	10/20
	plus	-1h
	pop	22h
	scale	마리
	point	240%
	flag	norequest
	@@use
		time	900
		exp		1%
		exptime	300
		job		드래곤 테이머	times/1.5
		job		드래곤 마스터	times/1.5
		scale	개
		action	시작
		name	알 껍질 깨기 도움받기
		info	곧 부화할 알의 껍질을 홀리 드래곤이 깨 줍니다
		okmsg	알에서 홀리 드래곤이 태어났습니다
			use		1	곧 부화할 알
			get		1	홀리 드래곤
	@@use
		time	2h
		exp		1%
		arg	nocount
		scale	회
		action	교육하기
		name	꾸미는 법 가르치기
		info	거울을 사용해 꾸미는 법을 가르칩니다
		ngmsg	거울에는 별로 관심이 없는 것 같습니다...
			need		1	거울
	@@use
		time	2h
		exp		1%
		arg	nocount
		scale	회
		action	교육하기
		name	화장실 훈련하기
		info	유아용 변기 사용법을 가르칩니다
		ngmsg	유아용 변기에는 별로 관심이 없는 것 같습니다...
			need		1	유아용 변기
	@@use
		time	2h
		exp		1%
		arg	nocount
		scale	회
		action	교육하기
		name	국제 대화을가르치기
		info	다른 존재와 소통하는 법을 가르칩니다
		param	47,53,회화의사방
		func	education
			need		1	기초부터 배우는 ABC
@@ITEM
	no		48
	type	사악
	code	deathdragon
	name	데스드래곤
	info	상급 드래곤. 강력한 브레스를 내뿜는 용
	price	15000
	limit	60
	base	10/20
	plus	-1h
	pop	22h
	scale	마리
	point	240%
	flag	norequest
	@@use
		time	900
		exp		1%
		exptime	300
		job		드래곤 테이머	times/1.5
		job		드래곤 마스터	times/1.5
		scale	개
		action	시작
		name	알 껍질 깨기 도움받기
		info	곧 부화할 알의 껍질을 데스드래곤이 깨 줍니다
		okmsg	알에서 데스드래곤이 태어났습니다
			use		1	곧 부화할 알
			get		1	데스드래곤
	@@use
		time	2h
		exp		1%
		arg	nocount
		scale	회
		action	교육하기
		name	블록 놀이 가르치기
		info	블록으로 노는 법을 가르칩니다
		ngmsg	블록에는 별로 관심이 없는 것 같습니다...
			need		1	블록
	@@use
		time	2h
		exp		1%
		arg	nocount
		scale	회
		action	교육하기
		name	꾸미는 법 가르치기
		info	거울을 사용해 꾸미는 법을 가르칩니다
		ngmsg	거울에는 별로 관심이 없는 것 같습니다...
			need		1	거울
	@@use
		time	2h
		exp		1%
		arg	nocount
		scale	회
		action	교육하기
		name	화장실 훈련하기
		info	유아용 변기 사용법을 가르칩니다
		param	48,54,배변 훈련
		func	education
			need		1	유아용 변기
@@ITEM
	no		49
	type	불
	code	flarebrass
	name	후레아부라스
	info	최상급 드래곤. 깊은 어둠 속에서 변이를 거듭한 용
	price	24000
	limit	40
	base	6/12
	plus	-1h
	pop	32h
	scale	마리
	point	200%
	flag	norequest
	@@use
		time	960
		exp		1%
		exptime	320
		job		드래곤 마스터	times/1.5
		scale	개
		action	시작
		name	알 껍질 깨기 도움받기
		info	곧 부화할 알의 껍질을 후레아부라스이 깨 줍니다
		okmsg	알에서 후레아부라스이 태어났습니다
			use		1	곧 부화할 알
			get		1	후레아부라스
	@@USE
		time	6h
		exp	1%
		arg	nocount|message20
		scale	회
		action	라는 드래곤을 개발
		name	신종 개발하기
		info	다양한 교육으로 오리지널 드래곤으로 키웁니다
		param	dmaster,49,55		# 드래곤 마스터의아비리테이
		func	newdragon
			needjob	드래곤 마스터
			need		1	블록
			need		1	거울
			need		1	유아용 변기
			need		1	걸음마 잘하는 책
			need		1	비행 기술
			need		1	기초부터 배우는 ABC
			need		1	고차방정식 풀이
@@ITEM
	no		50
	type	물
	code	luciferclaw
	name	루시퍼 클로
	info	최상급 드래곤. 어둠의 힘으로 변이를 일으키는 용
	price	24000
	limit	40
	base	6/12
	plus	-1h
	pop	32h
	scale	마리
	point	200%
	flag	norequest
	@@use
		time	960
		exp		1%
		exptime	320
		job		드래곤 마스터	times/1.5
		scale	개
		action	시작
		name	알 껍질 깨기 도움받기
		info	곧 부화할 알의 껍질을 루시퍼 클로이 깨 줍니다
		okmsg	알에서 루시퍼 클로이 태어났습니다
			use		1	곧 부화할 알
			get		1	루시퍼 클로
	@@USE
		time	6h
		exp	1%
		arg	nocount|message20
		argmessage	드래곤의이름
		scale	회
		action	라는 드래곤을 개발
		name	신종 개발하기
		info	다양한 교육으로 오리지널 드래곤으로 키웁니다
		param	dmaster,50,56		# 드래곤 마스터의아비리테이
		func	newdragon
			needjob	드래곤 마스터
			need		1	블록
			need		1	거울
			need		1	유아용 변기
			need		1	걸음마 잘하는 책
			need		1	비행 기술
			need		1	기초부터 배우는 ABC
			need		1	고차방정식 풀이
@@ITEM
	no		51
	type	땅
	code	zahhaku
	name	자하크
	info	최상급 드래곤. 그 힘은 모든 것을 파괴합니다
	price	24000
	limit	40
	base	6/12
	plus	-1h
	pop	32h
	scale	마리
	point	200%
	flag	norequest
	@@use
		time	960
		exp		1%
		exptime	320
		job		드래곤 마스터	times/1.5
		scale	개
		action	시작
		name	알 껍질 깨기 도움받기
		info	곧 부화할 알의 껍질을 자하크가 깨 줍니다
		okmsg	알에서 자하크가 태어났습니다
			use		1	곧 부화할 알
			get		1	자하크
	@@USE
		time	6h
		exp	1%
		arg	nocount|message20
		argmessage	드래곤의이름
		scale	회
		action	라는 드래곤을 개발
		name	신종 개발하기
		info	다양한 교육으로 오리지널 드래곤으로 키웁니다
		param	dmaster,51,57		# 드래곤 마스터의아비리테이
		func	newdragon
			needjob	드래곤 마스터
			need		1	블록
			need		1	거울
			need		1	유아용 변기
			need		1	걸음마 잘하는 책
			need		1	비행 기술
			need		1	기초부터 배우는 ABC
			need		1	고차방정식 풀이
@@ITEM
	no		52
	type	바람
	code	quetzalcoatl
	name	케찰코아틀
	info	최상급 드래곤. 그 숨결은 모든 것을 되살립니다
	price	24000
	limit	40
	base	6/12
	plus	-1h
	pop	32h
	scale	마리
	point	200%
	flag	norequest
	@@use
		time	960
		exp		1%
		exptime	320
		job		드래곤 마스터	times/1.5
		scale	개
		action	시작
		name	알 껍질 깨기 도움받기
		info	곧 부화할 알의 껍질을 케찰코아틀이 깨 줍니다
		okmsg	알에서 케찰코아틀이 태어났습니다
			use		1	곧 부화할 알
			get		1	케찰코아틀
	@@USE
		time	6h
		exp	1%
		arg	nocount|message20
		argmessage	드래곤의이름
		scale	회
		action	라는 드래곤을 개발
		name	신종 개발하기
		info	다양한 교육으로 오리지널 드래곤으로 키웁니다
		param	dmaster,52,58		# 드래곤 마스터의아비리테이
		func	newdragon
			needjob	드래곤 마스터
			need		1	블록
			need		1	거울
			need		1	유아용 변기
			need		1	걸음마 잘하는 책
			need		1	비행 기술
			need		1	기초부터 배우는 ABC
			need		1	고차방정식 풀이
@@ITEM
	no		53
	type	성
	code	bahamut
	name	바하무트
	info	최상급 드래곤. 그 숨결은 모든 것을 잠재웁니다
	price	24000
	limit	40
	base	6/12
	plus	-1h
	pop	32h
	scale	마리
	point	200%
	flag	norequest
	@@use
		time	960
		exp		1%
		exptime	320
		job		드래곤 마스터	times/1.5
		scale	개
		action	시작
		name	알 껍질 깨기 도움받기
		info	곧 부화할 알의 껍질을 바하무트가 깨 줍니다
		okmsg	알에서 바하무트가 태어났습니다
			use		1	곧 부화할 알
			get		1	바하무트
	@@USE
		time	6h
		exp	1%
		arg	nocount|message20
		argmessage	드래곤의이름
		scale	회
		action	라는 드래곤을 개발
		name	신종 개발하기
		info	다양한 교육으로 오리지널 드래곤으로 키웁니다
		param	dmaster,53,59		# 드래곤 마스터의아비리테이
		func	newdragon
			needjob	드래곤 마스터
			need		1	블록
			need		1	거울
			need		1	유아용 변기
			need		1	걸음마 잘하는 책
			need		1	비행 기술
			need		1	기초부터 배우는 ABC
			need		1	고차방정식 풀이
@@ITEM
	no		54
	type	사악
	code	tiamat
	name	티아마트
	info	최상급 드래곤. 무한한 마법으로 모든 것에 영향을 줍니다
	price	24000
	limit	40
	base	6/12
	plus	-1h
	pop	32h
	scale	마리
	point	200%
	flag	norequest
	@@use
		time	960
		exp		1%
		exptime	320
		job		드래곤 마스터	times/1.5
		scale	개
		action	시작
		name	알 껍질 깨기 도움받기
		info	곧 부화할 알의 껍질을 티아마트이 깨 줍니다
		okmsg	알에서 티아마트이 태어났습니다
			use		1	곧 부화할 알
			get		1	티아마트
	@@USE
		time	6h
		exp	1%
		arg	nocount|message20
		argmessage	드래곤의이름
		scale	회
		action	라는 드래곤을 개발
		name	신종 개발하기
		info	다양한 교육으로 오리지널 드래곤으로 키웁니다
		param	dmaster,54,60		# 드래곤 마스터의아비리테이
		func	newdragon
			needjob	드래곤 마스터
			need		1	블록
			need		1	거울
			need		1	유아용 변기
			need		1	걸음마 잘하는 책
			need		1	비행 기술
			need		1	기초부터 배우는 ABC
			need		1	고차방정식 풀이
@@ITEM
	no		55
	type	불
	code	original-fire
	name	오리지널 드래곤(불)
	info	오리지널 드래곤
	price	30000
	limit	30
	base	5/10
	plus	-1h
	pop	40h
	scale	마리
	point	300%
	flag	norequest
	@@use
		time	960
		exp		1%
		exptime	320
		job		드래곤 마스터	times/1.5
		scale	개
		action	시작
		name	알 껍질 깨기 도움받기
		info	곧 부화할 알의 껍질을 오리지널 드래곤(불)이 깨 줍니다
		okmsg	알에서 오리지널 드래곤(불)이 태어났습니다
			use		1	곧 부화할 알
			get		1	오리지널 드래곤(불)
@@ITEM
	no		56
	type	물
	code	original-cold
	name	오리지널 드래곤(물)
	info	오리지널 드래곤
	price	30000
	limit	30
	base	5/10
	plus	-1h
	pop	40h
	scale	마리
	point	300%
	flag	norequest
	@@use
		time	960
		exp		1%
		exptime	320
		job		드래곤 마스터	times/1.5
		scale	개
		action	시작
		name	알 껍질 깨기 도움받기
		info	곧 부화할 알의 껍질을 오리지널 드래곤(물)이 깨 줍니다
		okmsg	알에서 오리지널 드래곤(물)이 태어났습니다
			use		1	곧 부화할 알
			get		1	오리지널 드래곤(물)
@@ITEM
	no		57
	type	땅
	code	original-earth
	name	오리지널 드래곤(땅)
	info	오리지널 드래곤
	price	30000
	limit	30
	base	5/10
	plus	-1h
	pop	40h
	scale	마리
	point	300%
	flag	norequest
	@@use
		time	960
		exp		1%
		exptime	320
		job		드래곤 마스터	times/1.5
		scale	개
		action	시작
		name	알 껍질 깨기 도움받기
		info	곧 부화할 알의 껍질을 오리지널 드래곤(땅)이 깨 줍니다
		okmsg	알에서 오리지널 드래곤(땅)이 태어났습니다
			use		1	곧 부화할 알
			get		1	오리지널 드래곤(땅)
@@ITEM
	no		58
	type	바람
	code	original-thunder
	name	오리지널 드래곤(바람)
	info	오리지널 드래곤
	price	30000
	limit	30
	base	5/10
	plus	-1h
	pop	40h
	scale	마리
	point	300%
	flag	norequest
	@@use
		time	960
		exp		1%
		exptime	320
		job		드래곤 마스터	times/1.5
		scale	개
		action	시작
		name	알 껍질 깨기 도움받기
		info	곧 부화할 알의 껍질을 오리지널 드래곤(바람)이 깨 줍니다
		okmsg	알에서 오리지널 드래곤(바람)이 태어났습니다
			use		1	곧 부화할 알
			get		1	오리지널 드래곤(바람)
@@ITEM
	no		59
	type	성
	code	original-holy
	name	오리지널 드래곤(성)
	info	오리지널 드래곤
	price	30000
	limit	30
	base	5/10
	plus	-1h
	pop	40h
	scale	마리
	point	300%
	flag	norequest
	@@use
		time	960
		exp		1%
		exptime	320
		job		드래곤 마스터	times/1.5
		scale	개
		action	시작
		name	알 껍질 깨기 도움받기
		info	곧 부화할 알의 껍질을 오리지널 드래곤(성)이 깨 줍니다
		okmsg	알에서 오리지널 드래곤(성)이 태어났습니다
			use		1	곧 부화할 알
			get		1	오리지널 드래곤(성)
@@ITEM
	no		60
	type	사악
	code	original-death
	name	오리지널 드래곤(사악)
	info	오리지널 드래곤
	price	30000
	limit	30
	base	5/10
	plus	-1h
	pop	40h
	scale	마리
	point	300%
	flag	norequest
	@@use
		time	960
		exp		1%
		exptime	320
		job		드래곤 마스터	times/1.5
		scale	개
		action	시작
		name	알 껍질 깨기 도움받기
		info	곧 부화할 알의 껍질을 오리지널 드래곤(사악)이 깨 줍니다
		okmsg	알에서 오리지널 드래곤(사악)이 태어났습니다
			use		1	곧 부화할 알
			get		1	오리지널 드래곤(사악)

@@ITEM
	no		61
	type	도구
	code	wonderegg
	name	불타는 알
	info	불의 힘으로 만들어진 드래곤 알
	price	900
	limit	500/1
	pop	1d
	plus	-1h
	base	200/1000
	scale	개
	@@USE
		time	20m
		scale	회
		action	조사하기
		arg	nocount
		name	알을 부화시키는 방법 조사
		info	드래곤 육성 방법을 알고 싶을 때
		func	_local_
			my $ret;
			$ret.="그러자 알 주변에서 연기가 피어오르고 노인이 나타났습니다.<br><br>";
			$ret.="<TABLE><tr><td>";
			$ret.=main::GetTagImgKao('라무우','ram')."불꽃 노인:<br>";
			$ret.="…후무,알부터드래곤을육테타이라는의지야인.<br>";
			$ret.="불을 피워 알을 데우면 이 알은 부화할 게다.<br>";
			$ret.="그 뒤의 일은 도서관에서 직접 알아보거라.<br>";
			$ret.="서두르면 키우는 데 실패해서 큰일이 날 수도 있다.";
			$ret.="</td></tr></table><br>";
			$ret.="말을 마치자 노인은 연기 속으로 사라졌습니다.";
			return $ret;
		_local_
	@@use
		time	9m
		exp		1%
		exptime	3m
		job		비스트 테이머	times/1.5
		scale	개
		action	시작
		name	알 데우기
		info	불을 피워 알을 데웁니다
		okmsg	이제 알이 부화하기를 기다리면 됩니다
			use		1	불타는 알
			use		1	달꽃 고사리
			get		1	데워진 알
@@ITEM
	no		62
	type	도구
	code	warmedegg
	name	데워진 알
	info	조금만 더 데우면 곧 태어날 것 같습니다
	price	0
	limit	500
	pop	10d
	plus	-1h
	scale	개
	cost	100
	flag	noshowcase|norequest
@@ITEM
	no		63
	type	도구
	code	borneegg
	name	곧 부화할 알
	info	마물이 껍질을 깨 주어야 합니다
	price	0
	limit	500
	pop	10d
	plus	-1h
	scale	개
	cost	100
	flag	noshowcase|norequest

@@ITEM
	no	19
	type	도구
	code	circle
	name	마법진
	info	촉매를 사용해 소환하기 위해 필요합니다.
	price	0
	cost	500
	limit	1/1
	pop	0
	scale	개
	plus	2h
	flag	noshowcase|norequest
	@@USE
		time	20m
		scale	회
		action	조사하기
		arg	nocount
		name	소환 방법 조사
		info	몬스터 소환 방법을 알고 싶을 때
		func	_local_
			my $ret;
			$ret.="그러자 마법진에서 연기가 피어오르고 노인이 나타났습니다.<br><br>";
			$ret.="<TABLE><tr><td>";
			$ret.=main::GetTagImgKao('라무우','ram')."불꽃 노인:<br>";
			$ret.="...소환 방법을 알고 싶구나. 도서관에 책이 있을 게다.<br>";
			$ret.="먼저 근처 동굴 지도를 사용해 촉매를 찾아야 한다.<br>";
			$ret.="그다음 찾은 촉매를 사용해 소환을 하면 된다.<br>";
			$ret.="자세한 내용은 아래 도서관에서 잘 조사해 보거라.";
			$ret.="</td></tr></table><br>";
			$ret.="말을 마치자 노인은 연기 속으로 사라졌습니다.";
			return $ret;
		_local_

@@ITEM
	no		30
	type	도구
	code	catalyst-trans
	name	촉매의 비법
	info	수행으로 촉매 숙련도를 이동시킵니다
	price	25000
	limit	50/2
	pop	48h
	base	80/200
	scale	권
	plus	-1h
	point	500%
	@@USE
		time	6h
		scale	회
		action	수련 시작
		arg	nocount
		name	디즈멀로이동시키기
		info	다른 촉매의 숙련도를 옮겨 디즈멀의 숙련도에합니다
		okmsg	디즈멀 사용법을 조금 이해한 것 같습니다
		param	1,2:3:4:5:6,0.5
			use		1	촉매의 비법
		func	_local_
			######################################################################
			# ★숙련도 전환(지정 아이템으로 다른 아이템의 숙련도를 이동)
			#   param1 숙련도를 더할 아이템 번호(1~)
			#   param2 숙련도를 뺄 아이템 번호(1~) (:구분으로 여러 개 지정 가능)
			#   param3 이동할 숙련도 비율(0~) (0.5면 절반 이동)
			#   주의:숙련도위 합내용체크은하고이아닌의에서,내용수을1요리대키쿠하기의은및메타방이이이입니다.
			######################################################################
			my $ret="";
			
			if($USE->{param1})
			{
				my $exp1=$DT->{exp}{$USE->{param1}};
				my $exp2=0;
				
				foreach my $exps (split(/:/,$USE->{param2}))
				{
					my $exp=$DT->{exp}{$exps};
					next if !$exp || $exps==$exp1;
					$exp2+=$exp;
					delete($DT->{exp}{$exps});
					my $msg=$ITEM[$exps]->{name}."의 숙련도 ".int($exp/10)."% 이 0% 이 되었습니다";
					$ret.=$msg."<br>";
					WriteLog(0,$DT->{id},$msg);
				}
				$exp2=int($exp2*$USE->{param3});
				$exp1+=$exp2;
				$exp1=1000 if $exp1>1000;
				my $msg=$ITEM[$USE->{param1}]->{name}."의 숙련도 ".int($DT->{exp}{$USE->{param1}}/10)."% 이 ".int($exp1/10)."% 이 되었습니다";
				$ret.=$msg."<br>";
				WriteLog(0,$DT->{id},$msg);
				$DT->{exp}{$USE->{param1}}=$exp1;
			}
			return $ret;
		_local_
	@@USE
		time	6h
		action	수련 시작
		arg	nocount
		name	젬스톤로이동시키기
		info	다른 촉매의 숙련도를 옮겨 젬스톤의 숙련도에합니다
		okmsg	젬스톤 사용법을 조금 이해한 것 같습니다
		func	_local_1
		param	2,1:3:4:5:6,0.5
			use		1	촉매의 비법
	@@USE
		time	6h
		action	수련 시작
		arg	nocount
		name	크로나임로이동시키기
		info	다른 촉매의 숙련도를 옮겨 크로나임의 숙련도에합니다
		okmsg	크로나임 사용법을 조금 이해한 것 같습니다
		func	_local_1
		param	3,1:2:4:5:6,0.5
			use		1	촉매의 비법
	@@USE
		time	6h
		action	수련 시작
		arg	nocount
		name	피엘로이동시키기
		info	다른 촉매의 숙련도를 옮겨 피엘의 숙련도에합니다
		okmsg	피엘 사용법을 조금 이해한 것 같습니다
		func	_local_1
		param	4,1:2:3:5:6,0.5
			use		1	촉매의 비법
	@@USE
		time	6h
		action	수련 시작
		arg	nocount
		name	크리스탈로이동시키기
		info	다른 촉매의 숙련도를 옮겨 크리스탈의 숙련도에합니다
		okmsg	크리스탈 사용법을 조금 이해한 것 같습니다
		func	_local_1
		param	5,1:2:3:4:6,0.5
			use		1	촉매의 비법
	@@USE
		time	6h
		action	수련 시작
		arg	nocount
		name	베르뒤르로이동시키기
		info	다른 촉매의 숙련도를 옮겨 베르뒤르의 숙련도에합니다
		okmsg	베르뒤르 사용법을 조금 이해한 것 같습니다
		func	_local_1
		param	6,1:2:3:4:5,0.5
			use		1	촉매의 비법

@@ITEM
	no		64
	type	도구
	code	dragonomabook
	name	드래고노마 법전
	info	드래곤을 낳는 방법이 적힌 최신 연구서
	price	50000
	cost	1000
	limit	25/1.2
	pop	80h
	plus	-1h
	base	40/100
	scale	권
	point	500%
	@@USE
		time	20m
		scale	회
		action	조사하기
		arg	nocount
		name	드래곤을 낳는 방법 조사
		info	드래곤 육성 방법을 알고 싶을 때
		func	_local_
			my $ret;
			$ret.="그러자 책 사이에서 연기가 피어오르고 노인이 나타났습니다.<br><br>";
			$ret.="<TABLE><tr><td>";
			$ret.=main::GetTagImgKao('라무우','ram')."불꽃 노인:<br>";
			$ret.="…후무,드래곤의육성을시메타이라는의지야인.<br>";
			$ret.="먼저 알을 소환해 보는 것이 좋겠네.<br>";
			$ret.="촉매가 충분히 모였다면 이 책을 사용해,<br>";
			$ret.="마법진부터알을 불러내기코와이할 수 있는은즈다이의우.";
			$ret.="</td></tr></table><br>";
			$ret.="말을 마치자 노인은 연기 속으로 사라졌습니다.";
			return $ret;
		_local_
	@@USE
		time	20m
		scale	회
		action	조사하기
		arg	nocount
		name	먹이 수량 확인
		info	드래곤 먹이가 얼마나 남았는지 확인합니다
		func	feedcheck
	@@use
		time	1h
		exp		2%
		exptime	20m
		job		샤먼	times/1.5
		job		워록	times/1.5
		scale	회
		action	생미출스
		name	용의알을생미출스
		info	마법의힘에서용의알을생미출합니다
		okmsg	불타는 알을생미출했습니다
		ngmsg	아무 일도 일어나지 않았습니다...
			need		1	마법진
			use		3	디즈멀
			use		3	젬스톤
			use		3	크로나임
			use		3	피엘
			use		3	크리스탈
			use		3	베르뒤르
			get		20	불타는 알	85%

@@ITEM
	no		65
	type	도구
	code	jobchange
	name	직업의 비밀
	info	다양한 직업에 오르기 위한 책
	price	25000
	limit	50/2
	pop	48h
	base	80/200
	scale	권
	plus	-1h
	point	500%
	@@USE
		time	6h
		action	직업 변경
		scale	회
		arg		nocount
		name	워록
		info	워록에직업 변경합니다
		param	0,20,warlock,base
		funcb	jobcheck
			use		1	직업의 비밀
		func	jobport
	@@USE
		time	6h
		action	직업 변경
		scale	회
		arg		nocount
		name	샤먼
		info	샤먼에직업 변경합니다
		param	0,1:2:3:4:5:6,shaman,base
		funcb	jobcheck
			use		1	직업의 비밀
		func	jobport
	@@USE
		time	6h
		action	직업 변경
		scale	회
		arg		nocount
		name	트레저 헌터
		info	트레저 헌터에직업 변경합니다
		param	0,21:22,thunter,base
		funcb	jobcheck
			use		1	직업의 비밀
		func	jobport
	@@USE
		time	6h
		action	직업 변경
		scale	회
		arg		nocount
		name	트레이드 마스터
		info	트레이드 마스터에직업 변경합니다
		param	0,23,peddle,base
		funcb	jobcheck
			use		1	직업의 비밀
		func	jobport
	@@USE
		time	6h
		action	직업 변경
		scale	회
		arg		nocount
		name	비스트 테이머
		info	비스트 테이머에직업 변경합니다
		param	0,31:32:33:34:35:36,btamer,base
		funcb	jobcheck
			use		1	직업의 비밀
		func	jobport
	@@USE
		time	6h
		action	직업 변경
		scale	회
		arg		nocount
		name	드래곤 테이머
		info	드래곤 테이머에직업 변경합니다
		param	0,37:38:39:40:41:42,dtamer,btamer
		funcb	jobcheck
			use		1	직업의 비밀
		func	jobport
	@@USE
		time	6h
		action	직업 변경
		scale	회
		arg		nocount
		name	드래곤 마스터
		info	드래곤 마스터에직업 변경합니다
		param	0,49:50:51:52:53:54,dmaster,dtamer
		funcb	jobcheck
			use		1	직업의 비밀
		func	jobport

@@ITEM
	no		66
	type	마법 먹이
	code	strawberry
	name	뱀딸기
	info	들판에서 자라는 작은 딸기
	price	100
	limit	2000/500
	pop	10d
	plus	-20m
	base	100/700
	scale	개
	cost	30
	point	50%
@@ITEM
	no		67
	type	마법 먹이
	code	bracken
	name	달꽃 고사리
	info	숲에서 자라는 고사리입니다.
	price	100
	limit	2000/500
	pop	10d
	plus	-20m
	base	100/700
	scale	책
	cost	30
	point	50%
@@ITEM
	no		68
	type	마법 먹이
	code	seatangle
	name	눈사람 다시마
	info	물가에서 자라는 작은 풀
	price	200
	limit	1000/250
	pop	10d
	plus	-20m
	base	100/700
	scale	개
	cost	50
	point	50%
@@ITEM
	no		69
	type	마법 먹이
	code	lizard
	name	도마뱀 꼬리
	info	도마뱀의 먹이
	price	200
	limit	1000/250
	pop	10d
	plus	-20m
	base	100/700
	scale	책
	cost	50
	point	50%
@@ITEM
	no		70
	type	마법 먹이
	code	mustache
	name	고양이 수염
	info	쥐의 먹이
	price	200
	limit	1000/250
	pop	10d
	plus	-20m
	base	100/700
	scale	책
	cost	50
	point	50%
@@ITEM
	no		71
	type	마법 먹이
	code	brownrice
	name	콘플레이크
	info	간단하게 먹일 수 있는 곡물 사료입니다.
	price	400
	limit	800/800
	pop	80m
	plus	2h
	base	100/10000
	scale	개
	cost	20
@@ITEM
	no		72
	type	마법 먹이
	code	curry
	name	카레라이스
	info	든든하게 먹일 수 있는 향신료 음식입니다.
	price	400
	limit	800/800
	pop	80m
	plus	2h
	base	100/10000
	scale	개
	cost	20


@@ITEM
	no		23
	type	도구
	code	cm
	name	광고 팩
	info	인기를 올립니다. 실패할 수도 있습니다. . .
	price	100000
	limit	1/0.1
	pop	10d
	plus	5d
	base	10/50
	scale	팩
	cost	10000
	@@use
		time	10h
		exp	10%
		job		트레이드 마스터	times/1.5
		scale	회
		action	광고하기
		name	현재 가게 광고 내기
		info	자기 가게 인기를 올립니다
		arg		nocount
			use		1	광고 팩
		func	_local_
				my $up=int(500*(2-$DT->{rank}/5000));
				if ( rand(1000)<250 ) {
					$DT->{rank}-=$up;
					$DT->{rank}=1000 if $DT->{rank}<1000;
					my $ret="광고는 역효과가 났습니다: 인기 ".int($up/100)."% 하락";
					WriteLog(0,$DT->{id},$ret);
					WriteLog(3,0,$DT->{shopname}."이 광고를 냈지만 역효과였습니다.");
					return $ret;
				}
				$DT->{rank}+=$up;
				$DT->{rank}=10000 if $DT->{rank}>10000;
				my $ret="광고를 냈습니다: 인기 ".int($up/100)."% 상승";
				WriteLog(0,$DT->{id},$ret);
				WriteLog(3,0,$DT->{shopname}."이 광고를 냈습니다.");
				return $ret;
			_local_
	@@use
		time	10h
		exp	0%
		name	다른 가게 광고 내기
		info	다른 가게의 인기를 낮춥니다
		arg		target|nocount
			use		1	광고 팩
		func	_local_
				return '현재 가게는 지정할 수 없습니다' if ($DT==$DTS);
				my $up=int(500*(2-$DTS->{rank}/5000));
				$DTS->{rank}+=$up;
				$DTS->{rank}=10000 if $DTS->{rank}>10000;
				my $ret="광고를 냈습니다:".$DTS->{shopname}."의인기".int($up/100)."% 상승";
				WriteLog(0,$DT->{id},$ret);
				WriteLog(3,0,$DT->{shopname}."이".$DTS->{shopname}."의광고를 냈습니다.");
				return $ret;
			_local_
	@@use
		time	16h
		exp	0%
		name	길드 광고 내기
		info	같은 길드에 속한 가게 전체의 인기를 올립니다
		arg		nocount
			use		1	광고 팩
		func	_local_
				return '길드에 가입하지 않아 광고를 낼 수 없었습니다' if !$DT->{guild};

				WriteLog(3,0,$DT->{shopname}."이길드“".$main::GUILD{$DT->{guild}}->[$GUILDIDX_name]."”의광고를 냈습니다.");
				foreach my $DTS (@DT)
				{
				next if ($DTS->{guild} ne $DT->{guild});
				my $up=int(500*(2-$DTS->{rank}/5000));
				$DTS->{rank}+=$up;
				$DTS->{rank}=10000 if $DTS->{rank}>10000;
				my $ret="길드광고를 냈습니다:".$DTS->{shopname}."의인기".int($up/100)."% 상승";
				WriteLog(0,$DT->{id},$ret);
				}
				return '길드광고를 냈습니다';
			_local_

@@ITEM
	no		24
	type	도구
	code	book-work
	name	자금조달의방법
	info	당장 돈이 필요할 때 사용하는 수단
	price	0
	limit	1/1
	pop	0
	plus	10h
	scale	권
	flag	noshowcase
	@@use
		time	4h
		job		트레이드 마스터	times/1.5
		scale	회
		action	받기
		name	정석대로 자금 마련
		info	손해를 감수하고 자금을 마련합니다
		param	3000
		func	_local_
			# ★바이토
			#   param1 취득내용
			$DT->{money}+=$USE->{param1}*$count;
			
			my $ret=GetMoneyString($USE->{param1}*$count).'을 벌었습니다';
			
			WriteLog(0,$DT->{id},"아르바이트로 $ret");
			WriteLog(3,0,$DT->{shopname}."이 아르바이트를 한 것 같습니다");
			
			return $ret;
		_local_
	@@use
		time	8h
		job		트레이드 마스터	times/1.5
		scale	회
		action	받기
		name	하루 벌이 현장 작업으로 자금 마련
		info	조금 힘들지만 그럭저럭 벌 수 있습니다
		param	10000
		func	_local_1

@@ITEM
	no		25
	type	도구
	code	edit-showcase
	name	진열대 증축/철거 키트
	info	진열대 추가와 철거 등에 필요한 도구 세트입니다
	price	0
	limit	1/1
	pop	0
	plus	1d
	scale	키트
	flag	noshowcase|norequest
	@@use
		time	1h
		scale	회
		action	작업하기
		price	10000
		name	진열대을1츠에하기
		info	진열대을1츠에하기
		arg		nocount		#★사용시의선택내용지정.
							#  nocount -> 사용회수선택없음
		param	1			#★독현재함수용파라메-타
			use	1	진열대 증축/철거 키트
		func	_local_
			# ★진열대수변경
			#   param1 변경후의대수
			my $oldcnt=$DT->{showcasecount};
			my $newcnt=$USE->{param1};
			$DT->{showcasecount}=$newcnt;
			
			if($oldcnt<$newcnt)
			{
				foreach ($oldcnt..$newcnt-1)
				{
					$DT->{showcase}[$_]=0;
					$DT->{price}[$_]=0;
				}
			}
			if($oldcnt>$newcnt)
			{
				splice(@{$DT->{showcase}},$newcnt);
				splice(@{$DT->{price}},$newcnt);
			}
			my $ret="진열대을$DT->{showcasecount}개에했습니다";
			WriteLog(0,$DT->{id},$ret);
			WriteLog(0,0,$DT->{shopname}."의진열대이$DT->{showcasecount}개이 되었습니다.");
			
			return $ret;
		_local_
	@@use
		time	2h
		price	20000
		name	진열대을2츠에하기
		info	진열대을2츠에하기
		func	_local_1
		arg		nocount
		param	2
			use	1	진열대 증축/철거 키트
	@@use
		time	3h
		price	30000
		name	진열대을3츠에하기
		info	진열대을3츠에하기
		func	_local_1
		arg		nocount
		param	3
			use	1	진열대 증축/철거 키트
	@@use
		time	4h
		price	40000
		name	진열대을4츠에하기
		info	진열대을4츠에하기
		func	_local_1
		arg		nocount
		param	4
			use	1	진열대 증축/철거 키트
	@@use
		time	5h
		price	50000
		name	진열대을5츠에하기
		info	진열대을5츠에하기
		func	_local_1
		arg		nocount
		param	5
			use	1	진열대 증축/철거 키트
	@@use
		time	6h
		price	60000
		name	진열대을6츠에하기
		info	진열대을6츠에하기
		func	_local_1
		arg		nocount
		param	6
			use	1	진열대 증축/철거 키트
	@@use
		time	7h
		price	70000
		name	진열대을7츠에하기
		info	진열대을7츠에하기
		func	_local_1
		arg		nocount
		param	7
			use	1	진열대 증축/철거 키트
	@@use
		time	8h
		price	80000
		name	진열대을8츠에하기
		info	진열대을8츠에하기
		func	_local_1
		arg		nocount
		param	8
			use	1	진열대 증축/철거 키트
		
@@ITEM
	no		26
	type	도구
	code	badgossip
	name	금단의 책
	info	해서는 안 될 일을 해 보고 싶을 때. . .
	price	25000
	limit	50/1.2
	pop	40h
	plus	-1h
	base	40/100
	scale	권
	point	500%
	@@use
		time	10h
		exp	20%
		exptime	8h
		scale	회
		price	50000
		scale	회
		action	나쁜 소문 퍼뜨리기
		price	0
		name	나쁜 소문 퍼뜨리기
		info	성공하면 상대 가게의 인기를 낮춥니다. 실패할 수도 있습니다...
		arg	target|nocount
			needpoint	20000
		func	_local_
			my $ret;
			if(rand(1000)<800 && !$DTS->{exp}{@@ITEMNO"광고 팩"})
			{
				$DTS->{rank}-=int($DTS->{rank}/3);
				$ret=$DTS->{shopname}.'에 대한 나쁜 소문 퍼뜨리기 작전이 성공했습니다';
				WriteLog(0,$DT->{id},$ret);
				WriteLog(2,0,$DTS->{shopname}.'의 나쁜 소문이 퍼져 인기가 떨어졌습니다.');
			}
			else
			{
				$DTS->{exp}{@@ITEMNO"광고 팩"}-=100;
				$DTS->{exp}{@@ITEMNO"광고 팩"}=0 if ($DTS->{exp}{@@ITEMNO"광고 팩"} < 0);
				$DT->{rank}-=int($DT->{rank}/4);
				$ret=$DTS->{shopname}.'에 대한 나쁜 소문 퍼뜨리기 작전은 실패했습니다';
				WriteLog(0,$DT->{id},$ret);
				WriteLog(3,0,$DT->{shopname}."이 ".$DTS->{shopname}.'에 대한 나쁜 소문을 퍼뜨리려 했던 것 같습니다.');
			}
			return $ret;
			_local_
	@@use
		time	10h
		exp	25%
		exptime	8h
		scale	회
		action	소매치기
		price	50000
		name	소매치기
		info	그렇게까지 몰렸다면 쓰는 수밖에 없습니다...
		func	stole
		arg		target|nocount
			needpoint	20000

@@ITEM
	no		27
	type	도구
	code	slot
	name	추첨권
	info	새 아이템이 당첨될지도 모릅니다
	price	20000
	cost	100
	limit	10/1.2
	plus	-10h
	scale	개
	pop	10d
	flag	noshowcase
	@@use
		time	20m
		scale	회
		action	않고
		name	쿠지인키을하고미루
		info	당첨될지 안 될지는 운에 달렸습니다
		arg		nocount
		ngmsg	아무것도 당첨되지 않았습니다...
			use		1	추첨권
			get		1	상품권			10%		상품권에 당첨되었습니다!
			get		1	광고 팩			10%		광고 팩에 당첨되었습니다!
			get		1	블록				10%		블록에 당첨되었습니다!
			get		1	거울				10%		거울에 당첨되었습니다!
			get		1	유아용 변기				10%		유아용 변기에 당첨되었습니다!
			get		1	걸음마 잘하는 책		10%		걸음마 잘하는 책에 당첨되었습니다!
			get		1	비행 기술		10%		비행 기술에 당첨되었습니다!
			get		1	기초부터 배우는 ABC		10%		기초부터 배우는 ABC에 당첨되었습니다!
			get		1	고차방정식 풀이		10%		고차방정식 풀이에 당첨되었습니다!

@@ITEM
	no		28
	type	도구
	code	gift
	name	상품권
	info	새로운 것을 손에 넣어 보세요!
	price	50000
	cost	10
	limit	10/0
	scale	개
	pop	10d
	flag	noshowcase
	@@USE
		time	20m
		action	교환하기
		name	소환 세트와 교환하기
		info	소환에 필요한 재료 조합입니다
		okmsg	이용해 주셔서 감사합니다
			use		1	상품권
			get		1	근처 동굴 지도
			get		1	마법진
	@@USE
		time	20m
		action	교환하기
		name	추첨권과 교환하기
		info	도박을 즐기고 싶을 때
		okmsg	이용해 주셔서 감사합니다
			use		2	상품권
			get		5	추첨권
	@@USE
		time	20m
		action	교환하기
		name	광고 팩과 교환하기
		info	가게 인기를 올리고 싶을 때
		okmsg	이용해 주셔서 감사합니다
			use		2	상품권
			get		1	광고 팩
	@@USE
		time	20m
		action	교환하기
		name	놀이 도구와 교환하기
		info	드래곤에게 놀이를 가르치고 싶을 때
		okmsg	이용해 주셔서 감사합니다
			use		2	상품권
			get		1	블록
	@@USE
		time	20m
		action	교환하기
		name	예절 도구와 교환하기
		info	드래곤에게 예절을 가르치고 싶을 때
		okmsg	이용해 주셔서 감사합니다
			use		3	상품권
			get		1	유아용 변기
			get		1	거울
	@@USE
		time	20m
		action	교환하기
		name	도구와 교환하기
		info	드래곤에게 훈련을 시키고 싶을 때
		okmsg	이용해 주셔서 감사합니다
			use		3	상품권
			get		1	걸음마 잘하는 책
			get		1	비행 기술
	@@USE
		time	20m
		action	교환하기
		name	도구와 교환하기
		info	드래곤에게 훈련을 시키고 싶을 때
		okmsg	이용해 주셔서 감사합니다
			use		3	상품권
			get		1	기초부터 배우는 ABC
			get		1	고차방정식 풀이

@@ITEM
	no		29
	type	도구
	code	defence-manbiki
	name	파수꾼
	info	가게를 지킬 수 있는 고급 경비원
	price	500000
	cost	5000
	limit	1/0.5
	pop	1d
	plus	30m
	scale	마리
	flag	noshowcase|onlysend|human

@@ITEM
	no		73
	type	도구
	code	tsumiki
	name	블록
	info	드래곤의 놀이 도구입니다.
	price	100000
	limit	1/1
	pop	0
	plus	-2m
	base	200/400
	scale	개
	cost	100
@@ITEM
	no		74
	type	도구
	code	kagami
	name	거울
	info	드래곤을 꾸미는 도구입니다.
	price	100000
	limit	1/1
	pop	0
	plus	-2m
	base	200/400
	scale	개
	cost	100
@@ITEM
	no		75
	type	도구
	code	omaru
	name	유아용 변기
	info	드래곤의 배변 훈련용 도구입니다
	price	100000
	limit	1/1
	pop	0
	plus	-2m
	base	200/400
	scale	개
	cost	100
@@ITEM
	no		76
	type	도구
	code	anyojouzu
	name	걸음마 잘하는 책
	info	드래곤의 보행 훈련 도구
	price	100000
	limit	1/1
	pop	0
	plus	-2m
	base	200/400
	scale	권
	cost	100
@@ITEM
	no		77
	type	도구
	code	flytech
	name	비행 기술
	info	드래곤의 비행 훈련 도구
	price	100000
	limit	1/1
	pop	0
	plus	-2m
	base	200/400
	scale	권
	cost	100
@@ITEM
	no		78
	type	도구
	code	abcbook
	name	기초부터 배우는 ABC
	info	드래곤의 훈련 도구
	price	100000
	limit	1/1
	pop	0
	plus	-2m
	base	200/400
	scale	권
	cost	100
@@ITEM
	no		79
	type	도구
	code	houteishiki
	name	고차방정식 풀이
	info	드래곤의 훈련 도구
	price	100000
	limit	1/1
	pop	0
	plus	-2m
	base	200/400
	scale	권
	cost	100


#------------------------------이벤트
@@event
	start		10%
	basetime	5h
	plustime	5h
	code		happy
	startmsg	불길이 이 마을을 뒤덮었습니다.
	endmsg		불길은 조용히 사라졌습니다.
	info		불길 때문에 마을이 술렁입니다.
	func		_local_
		my $time=$main::TIMESPAN;
		$time=10*3600 if $time>10*3600; # 최대10%내용한
		$time=int($time/36);
		
		foreach(@DT)
		{
			$_->{rank}+=int(rand($time));
			$_->{rank}=10000 if $_->{rank}>10000;
		}
		return 0;
	_local_

@@EVENT
	start		30%
	basetime	6h
	plustime	24h
	code		fire-sale
	group		sale
	startmsg	불 속성 몬스터가 활발하게 움직입니다.
	info		불 속성 몬스터의 수요가 높아집니다.
		param	위스프		pop/2
		param	이프리트		pop/2
		param	샐러맨더		pop/2
		param	레서 로프로스	pop/3
		param	파이어 드래곤	pop/3
		param	후레아부라스		pop/3
		param	오리지널 드래곤(불)	pop/3
@@EVENT
	start		30%
	basetime	6h
	plustime	24h
	code		cold-sale
	group		sale
	startmsg	물 속성 몬스터가 활발하게 움직입니다.
	info		물 속성 몬스터의 수요가 높아집니다.
		param	슬라임		pop/2
		param	예티		pop/2
		param	요르문간드		pop/2
		param	리바이어선		pop/3
		param	콜드 드래곤	pop/3
		param	루시퍼 클로	pop/3
		param	오리지널 드래곤(물)	pop/3
@@EVENT
	start		30%
	basetime	6h
	plustime	24h
	code		earth-sale
	group		sale
	startmsg	땅 속성 몬스터가 활발하게 움직입니다.
	info		땅 속성 몬스터의 수요가 높아집니다.
		param	노움			pop/2
		param	골렘		pop/2
		param	바실리스크		pop/2
		param	스톰 웜	pop/3
		param	어스 드래곤		pop/3
		param	자하크		pop/3
		param	오리지널 드래곤(땅)	pop/3
@@EVENT
	start		30%
	basetime	6h
	plustime	24h
	code		thunder-sale
	group		sale
	startmsg	바람 속성 몬스터가 활발하게 움직입니다.
	info		바람 속성 몬스터의 수요가 높아집니다.
		param	실프			pop/2
		param	그리폰		pop/2
		param	타이폰		pop/2
		param	썬더 호크		pop/3
		param	썬더 드래곤	pop/3
		param	케찰코아틀	pop/3
		param	오리지널 드래곤(바람)	pop/3

@@EVENT
	start		30%
	basetime	6h
	plustime	24h
	code		sale-item
	group		bazar
	startmsg	시장에서 바자가 시작되었습니다.
	info		시장에서바자-이줄와레테이합니다.
		param	블록			plus=2400		#★시장로의입고페-스.
		param	거울			plus=2400
		param	유아용 변기			plus=2400

@@EVENT
	start		30%
	basetime	6h
	plustime	24h
	code		sale-book
	group		bazar
	startmsg	시장에서 세일이 시작되었습니다.
	info		시장에서세-루이줄와레테이합니다.
		param	걸음마 잘하는 책			plus=2400		#★시장로의입고페-스.
		param	비행 기술			plus=2400
		param	기초부터 배우는 ABC			plus=2400
		param	고차방정식 풀이			plus=2400

@@EVENT
	start		150%
	basetime	0h		#★보유위 이벤트에서는아닌의에서시간은0.
	plustime	0h
	code		dragonborn
	info		드래곤탄생
	startfunc	_local_
		# ★이 함수는 이벤트 처리에서 사용함
		my $itemno=@@ITEMNO"데워진 알";
		my $itemto=@@ITEMNO"곧 부화할 알";
		foreach my $DT (@DT)
		{
			next if !$DT->{item}[$itemno-1];
			my $cnt=$DT->{item}[$itemno-1];
			$cnt=$ITEM[$itemto]->{limit}-$DT->{item}[$itemto-1] if $DT->{item}[$itemto-1]+$cnt>$ITEM[$itemto]->{limit};
			$DT->{item}[$itemno-1]-=$cnt;
			$DT->{item}[$itemto-1]+=$cnt;	#곧 부화할 알
		}
		return 0;
	_local_


@@FUNCINIT
# 관련 아이템을 보유한 경우 구입에 필요한 시간을 3/4로 줄입니다.
#$TIME_SEND_ITEM=int($TIME_SEND_ITEM/4*3) if $DT->{item}[@@ITEMNO"내용이키의내용"-1];

# 직업이 “트레이드 마스터”인 경우 구입에 필요한 시간을 1/2로 줄입니다.
$TIME_SEND_ITEM=int($TIME_SEND_ITEM/2) if $DT->{job} eq 'peddle';

@@FUNCITEM
######################################################################
# ★직업 변경체크
######################################################################
sub jobcheck
{
my($USE)=@_;
return 1 if ($DT->{job} eq $USE->{param3});
return 1 if ($USE->{param4} ne "base")&&($DT->{job} eq '');
return 1 if ($USE->{param4} ne "base")&&($USE->{param4} !~ /$DT->{job}/);
foreach my $exps (split(/:/,$USE->{param2}))
	{
	return 0 if ($DT->{exp}{$exps} > 750);
	}
return 1;
}

######################################################################
# ★직업 변경
######################################################################
sub jobport
{
	$DT->{job}=$USE->{param3};
	WriteLog(3,0,$DT->{shopname}.'의직업이“'.$main::JOBTYPE{$USE->{param3}}.'”이 되었습니다.');

	my $ret;
	$ret.="책을 펼치자 전직의 신이 나타났습니다.<br><br>";
	$ret.="<TABLE><tr><td>";
	$ret.=main::GetTagImgKao('아무자','amza')."전직의 신 아무자:<br>";
	$ret.="...흠. ".$main::JOBTYPE{$USE->{param3}}."이 되고 싶은 모양이군요.<br>";
	$ret.='그렇다면 전직의 힘을 내려 주겠습니다!<br>지금 여기서 <b>'.$DT->{shopname}."</b>이<br>";
	$ret.=$main::JOBTYPE{$USE->{param3}}."의 길을 걷게 하겠습니다!";
	$ret.="</td></tr></table><br>";

	$ret.="직업이".$main::JOBTYPE{$USE->{param3}}."이 되었습니다.";
	return $ret;
}

######################################################################
#★오손전이히와쿠치메모
######################################################################
sub memo
{
	my $ret;
	$ret.=$USE->{param1}."<br><br>";
	$ret.="<TABLE><tr><td>";
	$ret.=main::GetTagImgKao('도우미','help')."도우미:<br>";
	$ret.="점장님, 새로운 드래곤의 탄생을 축하드립니다.<br>";
	$ret.="새로운 드래곤 종이 탄생하면 어떻게 될지는<br>";
	$ret.="그 드래곤이 알의 껍질을 깨는 순간부터 같은 종류의<br>";
	$ret.="드래곤을 계속 늘려 가며 확인해 보세요.";
	$ret.="</td></tr></table>";
	return $ret;
}

######################################################################
#★오손전이에사체크
######################################################################
sub feedcheck
{
	my @FEED=(
		[
			@@ITEMNO "뱀딸기",
			[@@ITEMNO "화이트 스네이크",@@ITEMNO "린드브룸",@@ITEMNO "홀리 드래곤",
			@@ITEMNO "케찰코아틀",@@ITEMNO "오리지널 드래곤(성)",]
		],
		[
			@@ITEMNO "눈사람 다시마",
			[@@ITEMNO "요르문간드",@@ITEMNO "라돈",@@ITEMNO "데스드래곤",
			@@ITEMNO "루시퍼 클로",@@ITEMNO "오리지널 드래곤(사악)",]
		],
		[
			@@ITEMNO "도마뱀 꼬리",
			[@@ITEMNO "샐러맨더",@@ITEMNO "리바이어선",@@ITEMNO "어스 드래곤",
			@@ITEMNO "바하무트",@@ITEMNO "오리지널 드래곤(바람)",]
		],
		[
			@@ITEMNO "고양이 수염",
			[@@ITEMNO "쁘띠 히드라",@@ITEMNO "레서 로프로스",@@ITEMNO "콜드 드래곤",
			@@ITEMNO "후레아부라스",@@ITEMNO "오리지널 드래곤(땅)",]
		],
		[
			@@ITEMNO "콘플레이크",
			[@@ITEMNO "바실리스크",@@ITEMNO "썬더 호크",@@ITEMNO "썬더 드래곤",
			@@ITEMNO "티아마트",@@ITEMNO "오리지널 드래곤(불)",]
		],
		[
			@@ITEMNO "카레라이스",
			[@@ITEMNO "타이폰",@@ITEMNO "스톰 웜",@@ITEMNO "파이어 드래곤",
			@@ITEMNO "자하크",@@ITEMNO "오리지널 드래곤(물)",]
		],
	);
	my $nofeed=0;
	my $msg="";
	my $dragonexist=0;
	foreach(@FEED)
		{
		my @list=@{$_};
		my @needfeed=@{$list[1]};
		my $moneyrate=0;
		foreach(@needfeed)
			{
			$moneyrate+=($DT->{item}[$_-1] * $ITEM[$_]->{price});
			}
		next if $moneyrate < 500;
		$moneyrate=int($moneyrate / $ITEM[$list[0]]->{price} / 12 + 0.9);
		$dragonexist=1;
		next if $DT->{item}[$list[0]-1] >= $moneyrate;
		$msg.=$ITEM[$list[0]]->{name}."이".($moneyrate - $DT->{item}[$list[0]-1]).$ITEM[$list[0]]->{scale}." 부족합니다.<br>";
		$nofeed=1;
		}
	my $ret;
	$ret.="<TABLE><tr><td>";
	$ret.=main::GetTagImgKao('도우미','help')."도우미:<br>";
	if (!$dragonexist)
		{
		$ret.="...점장님, 우리 가게에는 드래곤이 한 마리도 없어서,<br>";
		$ret.="먹이 수량을 확인할 필요가 없었습니다.<br>";
		$ret.="소환마에게는 먹이가 필요 없는 것 같습니다.";
		}
	elsif (!$nofeed)
		{
		$ret.="점장님, 우리 가게의 드래곤들은 모두 기뻐하며<br>";
		$ret.="지내고 있습니다. 다음 정산까지 먹이 걱정은 없어 보입니다.";
		}
	else
		{
		$ret.="점장님, 우리 가게의 드래곤들은 조금 배고픈 것 같습니다.<br>";
		$ret.=$msg."다음 정산 전까지 준비해 두어야 할 것 같습니다.";
		}
		$ret.="</td></tr></table>";
		return $ret;
}

######################################################################
#★드래곤의교육
######################################################################
sub education
{
	my $itemno=$USE->{param1};
	my $ret;
	if (rand(4000) > $DT->{exp}{$itemno})
	{
	$ret.=$ITEM[$itemno]->{name}."은 열심히 배우고 있는 것 같습니다.<br>";
	$ret.="다만 아직 ".$USE->{param3}."을 익히지는 못했습니다.";
	return $ret;
	}
	my $itemto=$USE->{param2};
	$ret.="학습을 통해 ".$USE->{param3}."을 익혔습니다.<br>";
	$ret.=$ITEM[$itemno]->{name}."은,".$ITEM[$itemto]->{name}."로와성장했습니다！";

	if ($DT->{item}[$itemto-1])
	{
	$ret.="<br>하지만,".$ITEM[$itemto]->{name}."은 이미 키우고 있으므로 이번 성장은 없던 일이 되었습니다.";
	}
	else
	{
	$ret=qq|<IMG width="108" height="72" SRC="$main::IMAGE_URL/newpet.jpg"><br><br>|.$ret;
	AddItem($itemto,1);
	WriteLog(2,0,$DT->{shopname}.'이'.$ITEM[$itemto]->{name}.'의육성에성공했습니다.');
	}
	UseItem($itemno,1);
	return $ret;
}

######################################################################
#★드래곤의새종탄생
######################################################################
sub newdragon
{
	my $cnt=0;
	foreach(55..60) { $cnt+=$DT->{item}[$_-1];}
	main::OutError('개발할 수 있는 오리지널 드래곤은 1종류뿐입니다.<br>이미 오리지널 드래곤이 존재합니다.') if $cnt;
	main::OutError('새 종의 이름을 붙여 주세요.') if !$USE->{arg}->{message};
	my $itemno=$USE->{param2};
	my $itemto=$USE->{param3};
	my $ret;
	$DT->{user}->{ori}=$USE->{arg}->{message};
	$ret.=qq|<IMG width="108" height="72" SRC="$main::IMAGE_URL/newpet.jpg"><br><br>|;
	$ret.=$ITEM[$itemno]->{name}."은 드래곤에게 필요한 학습을 모두 마쳤습니다.<br>";
	$ret.="마침내 오리지널 드래곤 “".$USE->{arg}->{message}."”이 태어났습니다!";
	AddItem($itemto,1);
	WriteLog(1,0,$DT->{shopname}.'이 새 종 “'.$USE->{arg}->{message}.'”을 탄생시켰습니다.');
	UseItem($itemno,1);
	return $ret;
}

######################################################################
#★내용인키
######################################################################
sub stole
{
	return '자기 가게에는 소매치기를 할 수 없습니다. 소매치기는 실패입니다.' if  ($DT->{id} eq $DTS->{id});
	my $ret="소매치기는 실패했습니다. 벌금 ".GetMoneyString(500000)."을 빼앗겼습니다.";
	if($DTS->{item}[@@ITEMNO"파수꾼"-1])
	{
		$DT->{rank}-=int($DT->{rank}/4);
		$DTS->{money}+=500000;
		$DTS->{saletoday}+=500000;
		$DT->{money}-=500000;
		$DT->{paytoday}+=500000;
		WriteLog(3,0,$DT->{shopname}."이".$DTS->{shopname}."에 소매치기를 하러 들어갔지만 파수꾼에게 들켰습니다.");
		WriteLog(3,0,$DT->{shopname}."은".$DTS->{shopname}."에게 벌금 ".GetMoneyString(500000)."을 지불했습니다.");
		WriteLog(0,$DT->{id},$ret);
		return $ret;
	}
	if(rand(1000)>900)
	{
		$DTS->{money}+=500000;
		$DTS->{saletoday}+=500000;
		$DT->{money}-=500000;
		$DT->{paytoday}+=500000;
		$DT->{rank}-=int($DT->{rank}/4);
		WriteLog(3,0,$DT->{shopname}."이".$DTS->{shopname}."에 소매치기를 하러 들어갔지만 실패했습니다.");
		WriteLog(3,0,$DT->{shopname}."은".$DTS->{shopname}."에게 벌금 ".GetMoneyString(500000)."을 지불했습니다.");
		WriteLog(0,$DT->{id},$ret);
		return $ret;
	}
	$ret="소매치기는 성공했습니다";
	my $manbiki_count=0;
	foreach my $idx (0..$DTS->{showcasecount}-1)
	{
		my $itemno=$DTS->{showcase}[$idx];
		if($itemno)
		{
			my $cnt=int($DTS->{item}[$itemno-1]*3/4);
			$cnt=$ITEM[$itemno]->{limit}-$DT->{item}[$itemno-1] if $DT->{item}[$itemno-1]+$cnt>$ITEM[$itemno]->{limit};
			$DTS->{item}[$itemno-1]-=$cnt;
			$DT->{item}[$itemno-1]+=$cnt;
			$manbiki_count+=$cnt*$DTS->{price}[$idx];
		}
	}
	$main::STATE->{safety}=int($main::STATE->{safety} * 18 / 19);
	WriteLog(2,0,$DTS->{shopname}."이 ".GetMoneyString($manbiki_count)." 상당의 물건을 소매치기당했습니다.") if $manbiki_count;
	WriteLog(2,0,$DTS->{shopname}."에 들어온 소매치기는 아무것도 훔치지 못하고 도망쳤습니다.") if !$manbiki_count;
	WriteLog(0,$DT->{id},$ret);
	return $ret;
}

@@FUNCUPDATE
sub UpdateResetBefore #내용이전의처리(함수명지정)
{
	UpdateTodayPrize();
	
	sub UpdateTodayPrize
	{
		#내용품내용
		my @TOP123=(
			[
				['상품권',	[[@@ITEMNO "상품권", 5],			],],
				['추첨권',	[[@@ITEMNO "추첨권", 5],			],],
			],
			[
				['상품권',	[[@@ITEMNO "상품권", 4],			],],
				['추첨권',	[[@@ITEMNO "추첨권", 4],			],],
			],
			[
				['상품권',	[[@@ITEMNO "상품권", 3],			],],
				['추첨권',	[[@@ITEMNO "추첨권", 3],			],],
			],
			[
				['상품권',	[[@@ITEMNO "상품권", 2],			],],
				['기초부터 배우는 ABC',[[@@ITEMNO "기초부터 배우는 ABC", 1],	],],
				['고차방정식 풀이',[[@@ITEMNO "고차방정식 풀이", 1],	],],
				['추첨권',	[[@@ITEMNO "추첨권", 1],			],],
				['블록',	[[@@ITEMNO "블록", 1],			],],
				['거울',	[[@@ITEMNO "거울", 1],			],],
				['유아용 변기',	[[@@ITEMNO "유아용 변기", 1],			],],
				['걸음마 잘하는 책',[[@@ITEMNO "걸음마 잘하는 책", 1],	],],
			],
		);
		
		TopGetItem($DT[0],$TOP123[0],"이번 회차 1위 ") if defined($DT[0]);
		TopGetItem($DT[1],$TOP123[1],"이번 회차 2위 ") if defined($DT[1]);
		TopGetItem($DT[2],$TOP123[2],"아슬아슬하게 입상한 ") if defined($DT[2]);
	
		for(my $i=9; $i<$#DT; $i+=10)
		{
			TopGetItem($DT[$i],$TOP123[3],"특별상 ".($i+1)."위 ") if defined($DT[$i]);
		}
		
		sub TopGetItem
		{
			my($DT,$itemlist,$head)=@_;
			
			my @list=@{$itemlist};
			my @getitem=@{$list[int(rand($#list+1))]};
			
			my $msg=$head.$DT->{shopname}."님에게는 ".$getitem[0]."이 지급되었습니다";
			WriteLog(2,0,0,$msg,1);
			foreach (@{$getitem[1]})
			{
				my @itemnocount=@{$_};
				
				my $cnt=AddItem($DT,$itemnocount[0],$itemnocount[1]);
				my $ITEM=$ITEM[$itemnocount[0]];
				WriteLog(0,$DT->{id},0,$head."상품으로 ".$ITEM->{name}."을".$itemnocount[1].$ITEM->{scale}." 획득했습니다",1);
				$cnt=$itemnocount[1]-$cnt;
				WriteLog(0,$DT->{id},0,"하지만 최대 보유 수를 넘어서 ".$cnt.$ITEM->{scale}." 폐기했습니다",1) if $cnt;
			}
		}
	}
}

sub UpdateResetAfter #내용후의처리(함수명지정)
{
	my @FEED=(
		[
			@@ITEMNO "뱀딸기",
			[@@ITEMNO "화이트 스네이크",@@ITEMNO "린드브룸",@@ITEMNO "홀리 드래곤",
			@@ITEMNO "케찰코아틀",@@ITEMNO "오리지널 드래곤(성)",]
		],
		[
			@@ITEMNO "눈사람 다시마",
			[@@ITEMNO "요르문간드",@@ITEMNO "라돈",@@ITEMNO "데스드래곤",
			@@ITEMNO "루시퍼 클로",@@ITEMNO "오리지널 드래곤(사악)",]
		],
		[
			@@ITEMNO "도마뱀 꼬리",
			[@@ITEMNO "샐러맨더",@@ITEMNO "리바이어선",@@ITEMNO "어스 드래곤",
			@@ITEMNO "바하무트",@@ITEMNO "오리지널 드래곤(바람)",]
		],
		[
			@@ITEMNO "고양이 수염",
			[@@ITEMNO "쁘띠 히드라",@@ITEMNO "레서 로프로스",@@ITEMNO "콜드 드래곤",
			@@ITEMNO "후레아부라스",@@ITEMNO "오리지널 드래곤(땅)",]
		],
		[
			@@ITEMNO "콘플레이크",
			[@@ITEMNO "바실리스크",@@ITEMNO "썬더 호크",@@ITEMNO "썬더 드래곤",
			@@ITEMNO "티아마트",@@ITEMNO "오리지널 드래곤(불)",]
		],
		[
			@@ITEMNO "카레라이스",
			[@@ITEMNO "타이폰",@@ITEMNO "스톰 웜",@@ITEMNO "파이어 드래곤",
			@@ITEMNO "자하크",@@ITEMNO "오리지널 드래곤(물)",]
		],
	);

	foreach my $DT (@DT)
		{
		$DT->{profitstock}=5000000 if ($DT->{profitstock} > 5000000);
		$DT->{profitstock}=-1000000 if ($DT->{profitstock} < -1000000);
		if ($DT->{money} > 50000000)
			{
			$DT->{money} -= int( ($DT->{money} - 20000000)/2 );
			$DT->{rank} += int( (10000 - $DT->{rank})/2 );
			$DT->{rank}=10000 if $DT->{rank}>10000;
			PushLog(2,0,$DT->{shopname}.'에서 세금이 징수되었습니다.');
			}

		my $nofeed=0;
		foreach(@FEED)
			{
			my @list=@{$_};
			my @needfeed=@{$list[1]};
			my $moneyrate=0;
			foreach(@needfeed)
				{
				$moneyrate+=($DT->{item}[$_-1] * $ITEM[$_]->{price});
				}
			next if $moneyrate < 500;
			$moneyrate=int($moneyrate / $ITEM[$list[0]]->{price} / 12 + 0.9);
			$DT->{item}[$list[0]-1] -= $moneyrate;
			next if $DT->{item}[$list[0]-1] > 0;
			$nofeed=1;
			$DT->{item}[$list[0]-1] = 0;
			foreach(@needfeed) { $DT->{item}[$_-1]=0; }
			}
		if ($nofeed)
			{
			PushLog(0,0,$DT->{shopname}.'에 있던 드래곤은 먹이가 부족해 떠났습니다.') if $nofeed;
			$DT->{rank} = int($DT->{rank} / 2);
			}
		}
}

@@FUNCNEW

# @@DEFINE Set NewShopMoney NewShopTime NewShopItem 의처리
$DT->{money}=@@VALUE"NewShopMoney" if @@VALUE"NewShopMoney";
$DT->{time}=$NOW_TIME-eval(@@VALUE"NewShopTime") if @@VALUE"NewShopTime";
if(@@VALUE"NewShopItem")
{
	my %item=split /:/,@@VALUE"NewShopItem";
	while(my($key,$val)=each %item)
	{
		foreach my $item (@ITEM)
		{
			 $DT->{item}[$item->{no}-1]+=$val,last if $key eq $item->{code} or $key eq $item->{name};
		}
	}
}

# $DEFINE_FUNCNEW_NOLOG=1 을설정할 때,시스테무위 최근의출내용사신규 개점메시지을내용합니다.
# $DEFINE_FUNCNEW_NOLOG=1;
# WriteLog(1,0,0,$DT->{shopname}."이 엔트리했습니다",1);

# 그타,신규 개점시에독현재의처리을추가가능합니다.

@@FUNCSHOPIN

SetUserDataEx($DT,'_so_move_in',$NOW_TIME); # 이전시내용을기내용
if($DT->{job} eq 'peddle')
{
	# 줄상인(peddle)에은이전소요 시간의1/2을내용
	$DT->{_MoveTownTime}=int($DT->{_MoveTownTime}/2);
	EditTime($DT,$DT->{_MoveTownTime});
	WriteLog(0,$DT->{id},0,'이전 시간이 기존의 '.GetTime2HMS($DT->{_MoveTownTime}).'으로 줄어든 것 같습니다',1);
}
if(GetUserDataEx($DT,'_so_present_money'))
{
	WriteLog(0,$DT->{id},0,'이전한 마을에서 선물로 '.GetMoneyString(GetUserDataEx($DT,'_so_present_money')).'을 받았습니다',1);
	SetUserDataEx($DT,'_so_present_money','');
}

@@FUNCSHOPOUT

if(GetUserDataEx($DT,'_so_move_in'))
{
	my $present_money=int(($NOW_TIME-GetUserDataEx($DT,'_so_move_in'))/86400)*5000;
	EditMoney($DT,$present_money); # 내용재기내용1일에부키\5000을내용와하고자금로
	SetUserDataEx($DT,'_so_present_money',$present_money);
	SetUserDataEx($DT,'_so_move_in',''); # $DT->{user}{_so_move_in} 을삭제
}

@@FUNCBUY
# package item 입니다.
# 
# $item::BUY 을이용가능합니다.$item::BUY 의구내용은매뉴얼의 @@ITEM funcb 을고람주세요.
# 상품매의처리은 @@ITEM funcb 을이용해 주세요.

if($BUY->{whole})
{
	if (rand(1000) > 990 && $BUY->{num} > 10)
	{
	$count=AddItemSub(@@ITEMNO"상품권",1,$BUY->{dt});
	WriteLog(0,$BUY->{dt}{id},'시장에서 상품권이 '.$count.'장 당첨되었습니다.');
	$main::ret.='<br>시장에서 상품권이 '.$count.'장 당첨되었습니다！';
	}
}

@@END #정의종료선언(이 댓글내용이)

