#!/usr/bin/perl
# 신규 개점 사용자 지정용 2004/01/20 유래

# 신규 개점 때의 주의사항 표시 등을 사용자 지정할 수 있습니다.
# 단, 어느 정도의 HTML 지식과 프로그램 이해가 필요합니다.

$disp.=<<"HTML";
<BIG>●처음 오신 분께</BIG><br><br>
$TB$TR
$TD$image[0]$TD
이 게임은 브라우저에서 즐길 수 있는 경영 시뮬레이션 RPG입니다.<br>
참가하기 전에 도서관에서 규칙과 플레이 방법을 꼭 읽어 주세요.
$TRE$TBE
<hr width=500 noshade size=1>
HTML

$i_rand=int(rand($ICON_NUMBER))+1;
$disp.="<BIG>●새 가게 열기: 남은 자리 ".($MAX_USER-$DTusercount)."명</BIG><br>";
$disp.=<<"HTML";
<small>등록은 <b>1인 1가게</b>만 가능합니다.</small><br>
<FORM ACTION="action.cgi" $METHOD>
<INPUT TYPE=HIDDEN NAME=key VALUE="new">
<INPUT TYPE=HIDDEN NAME=admin VALUE="$Q{admin}">
<TABLE>
  <TR>
    <TD>
<SPAN>이름</SPAN>:<INPUT TYPE=TEXT NAME=name> 한글 입력 가능<BR>
<SPAN>가게 이름</SPAN>:<INPUT TYPE=TEXT NAME=sname> 한글 입력 가능<BR>

<SPAN>아이콘</SPAN>:<SELECT NAME=icon>
<OPTION value="$i_rand" selected>무작위</OPTION>
HTML

foreach my $i(1..$ICON_NUMBER)
	{
	$disp.=qq|<OPTION value="$i">이미지$i</OPTION>|;
	}

$disp.=<<"HTML";
</SELECT> 
<input type="button" value="아이콘 목록" onclick="javascript:window.open('action.cgi?key=icon','_blank','width=450,height=380,scrollbars')">
<br>
<SPAN>비밀번호</SPAN>:<INPUT TYPE=PASSWORD maxlength=12 NAME=pass1> 영문/숫자 권장<BR>
<SPAN>비밀번호 확인</SPAN>:<INPUT TYPE=PASSWORD maxlength=12 NAME=pass2><BR>
HTML

$disp.="<SPAN>개점 키워드</SPAN>:<INPUT TYPE=TEXT NAME=newkey><BR>" if ($NEW_SHOP_KEYWORD);

$disp.=<<"HTML";
<center><INPUT TYPE=SUBMIT VALUE="등록"></center>
</TD></TR>
</TABLE>
<small>※다른 사람에게 불쾌감을 줄 수 있는 이름은 피해주세요.<br>
※비밀번호는 다른 사람이 쉽게 추측할 수 없도록 설정해 주세요.</small>
</FORM>
HTML
1;
