#!/usr/bin/perl
# MIDI의설정 파일 2005/03/30 유래

# -------- 설정부분 ----------
# MIDI의파일명을변경가능합니다.
# CGI가 다른 서버에 있을 경우 여기에 http://로 시작하는 경로를 지정합니다.

$MIDI_URL = "midi.mid";

# ----------------------------

$NOMENU=1;
$Q{bk}="none";
print "Content-type: text/html\n\n";

my $bgmtag;

if ($ENV{HTTP_USER_AGENT}=~ /MSIE/ && $ENV{HTTP_USER_AGENT}!~ /Opera/)
	{
	$bgmtag=qq|<BGSOUND src="$MIDI_URL" loop=infinite>|;
	}
	else
	{
	$bgmtag=qq|<EMBED src="$MIDI_URL" width=2 height=2 autostart=true loop=true>|;
	}
print "Content-type: text/html\n\n";
print <<"EOM";
<html lang="ko">
<HEAD>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
<TITLE>BGM</TITLE>
$bgmtag
</HEAD>
<BODY>
</HTML>
EOM
exit;
1;
