#!/usr/bin/perl
# 펫 보관소 2003/12/28 유래

Lock() if ($Q{mode});	# 처리 중에는 가능한 한 잠급니다.
DataRead();
CheckUserPass();

my $image=GetTagImgKao("사육사","keeper",'align="left" ');
my @STOCK;
ReadDTSub($DT,"keeper");
$stock[0]=$DT->{_keeper}->{0};
$stock[1]=$DT->{_keeper}->{1};
$stock[2]=$DT->{_keeper}->{2};
EditKeeper() if ($Q{mode});	# 각종 데이터 처리

$disp.="<BIG>●펫 보관소</BIG><br><br>";
	$disp.='<TABLE cellpadding="26" width="500"><tr>';
	$disp.=qq|<TD style="background-repeat : repeat-x;background-image : url($IMAGE_URL/keeper.png);" valign="top"><br><br>|;
	$disp.=$image.'<SPAN>사육사</SPAN>:여기서는 펫을 최대 3종류까지 맡길 수 있습니다.<br>';
	$disp.='단, 같은 종류의 펫은 1마리씩만 맡길 수 있습니다.<br>';
	$disp.='찾아갈 때 보관료 50,000원이 필요합니다.'.$TRE;
	$disp.=$TBE."<br>";

$disp.=<<STR;
$TB$TR
<TD class=b NOWRAP colspan=3>보관 중인 펫
$TRE$TR
STR

my $formstock;
my $formitem;
foreach (0..2) {
	$disp.=$TD."(".($_ + 1).")";
	$disp.="없음",next if !$stock[$_];
	$disp.=GetTagImgItemType($stock[$_]).$ITEM[$stock[$_]]->{name};
	$formstock.="<OPTION VALUE=\"$_\">$ITEM[$stock[$_]]->{name}";
	}
$disp.=$TRE.$TBE."<hr width=500 noshade size=1>";

	my @sort;
	foreach(1..$MAX_ITEM){$sort[$_]=$ITEM[$_]->{sort}};
	my @itemlist=sort { $sort[$a] <=> $sort[$b] } (1..$MAX_ITEM);
	foreach(@itemlist)
	{
		next if !$DT->{item}[$_-1];
		next if $ITEM[$_]->{type} < 3;
		next if $ITEM[$_]->{type} > 8;
		$formitem.="<OPTION VALUE=\"$_\">$ITEM[$_]->{name}";
	}

$disp.=<<STR;
<form action="action.cgi" $METHOD>
$MYFORM$USERPASSFORM
<INPUT TYPE=HIDDEN NAME=id VALUE="$DT->{id}">
<INPUT TYPE=HIDDEN NAME=idx VALUE="$BRIDE[$i]->{no}">
<INPUT TYPE=HIDDEN NAME=no VALUE="$BRIDE[$i]->{no}">
<INPUT TYPE=HIDDEN NAME=mode VALUE="plus">
<BIG>●맡기기</BIG>:보관소에 <SELECT NAME=it SIZE=1>
$formitem
</SELECT> 을
 <INPUT TYPE=SUBMIT VALUE='맡기기'>
</FORM>
<hr width=500 noshade size=1>
<form action="action.cgi" $METHOD>
$MYFORM$USERPASSFORM
<INPUT TYPE=HIDDEN NAME=id VALUE="$DT->{id}">
<INPUT TYPE=HIDDEN NAME=idx VALUE="$BRIDE[$i]->{no}">
<INPUT TYPE=HIDDEN NAME=no VALUE="$BRIDE[$i]->{no}">
<INPUT TYPE=HIDDEN NAME=mode VALUE="minus">
<BIG>●찾기</BIG>:보관소에서 <SELECT NAME=it SIZE=1>
$formstock
</SELECT> 을
 <INPUT TYPE=SUBMIT VALUE='찾기'>
</FORM>
STR

OutSkin();
1;


sub EditKeeper
{
if ($Q{mode} eq 'plus') {
	$itemno=$Q{it};
	my $n=SearchKstock($Q{it});
	OutError('보관 공간이 없습니다.') if ($n == -1) ;
	OutError('지정한 펫이 없습니다.') if ($DT->{item}[$itemno-1] < 1);
	$DT->{item}[$itemno-1]-=1;
	$DT->{_keeper}->{$n}=$itemno;
	$stock[$n]=$itemno;
}
if ($Q{mode} eq 'minus') {
	my $n=$Q{it};
	my $itemno=$stock[$n];
	OutError('지정한 펫이 없습니다.') if (!$itemno);
	OutError('창고가 가득 차서 찾을 수 없습니다.') if ($ITEM[$itemno]->{limit} <= $DT->{item}[$itemno-1]);
	OutError('보관료를 지불할 자금이 부족합니다.') if ($DT->{money} < 50000);
	$DT->{money}-=50000;
	$DT->{item}[$itemno-1]+=1;
	delete($DT->{_keeper}->{$n});
	$stock[$n]=0;
}
WriteDTSub($DT,"keeper");
DataWrite();
DataCommitOrAbort();
UnLock();
}

sub SearchKstock
{
	my($no)=@_;
	foreach(0..2)
	{
		return -1 if($no == $stock[$_]);	# 이미 같은 펫을 맡겼는지 확인
	}
	foreach(0..2)
	{
		return $_ if !($stock[$_]);	# 빈 보관 공간 확인
	}
	return -1;
}



