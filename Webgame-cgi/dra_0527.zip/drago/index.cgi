#!/usr/bin/perl
# 첫 화면 2004/01/20 유래

require './_config.cgi';
RequireFile('inc-func.cgi');
RequireFile('inc-version.cgi');

Turn();

GetQuery();
GetCookie();
SetCookieSession();
DataRead();

$username=$Q{nm} ? $Q{nm} : $COOKIE{USERNAME};
$password=$Q{pw} ? $Q{pw} : $COOKIE{PASSWORD};
$lform="";
if (!$MOBILE)
	{
	$lform.=GetTagA('[새 가게 열기]<small>남은 자리  '.($MAX_USER-$DTusercount).'명</small>',"action.cgi?key=new") if $MAX_USER>$DTusercount;
	$lform.='[새 가게 열기]<small>현재 정원 초과</small>' if $MAX_USER<=$DTusercount;
	$lform.=($MAX_MOVE_USER>$DTusercount)?('<small>(이전:남은 자리'.($MAX_MOVE_USER-$DTusercount).'명)</small>'):('<small>(이전:현재 정원 초과)</small>') if $MOVETOWN_ENABLE;
	$lform.="<br>";
	}
$DISP{MENU} =~ s/#SKINNEW#/$lform/;
$DISP{MENU} =~ s/#SKINNAME#/$username/;
$DISP{MENU} =~ s/#SKINPW#/$password/;
$DISP{MENU} =~ s/#SKINCOMMENT#/$TITLE_COMMENT/;

$DT={};
$DT->{id}=-1;
$GUEST_USER=1;
RequireFile('inc-html-top.cgi') if (!$MOBILE);

$DISP{BOTTOM} =~ s/#SKINVER#/$BASE_VERSION/;
$DISP{BOTTOM} =~ s/#SKINEDIT#/$ITEM_VERSION/;
$DISP{BOTTOM} =~ s/#SKINMAIL#/$ADMIN_EMAIL/;

OutSkin();
exit;

sub GetCookie
{
	foreach(split(/\s*;\s*/,$ENV{HTTP_COOKIE}))
	{
		@_=split(/=/);
		$COOKIE{$_[0]}=$_[1];
		next if $_[0] ne 'shop';
		foreach(split(/,/,$_[1]))
		{
			@_=split(/:/);
			$COOKIE{$_[0]}=$_[1];
		}
	}
}
