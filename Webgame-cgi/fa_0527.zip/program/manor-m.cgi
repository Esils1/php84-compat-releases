#!/usr/bin/perl
# 장원종구매 2005/03/30 유래

$NOITEM=1;
$NOMENU=1;
DataRead();
CheckUserPass();
OutError("영주가 없어 장원 제도가 기능하지 않습니다") if !defined($id2idx{$STATE->{leader}});
RequireFile('inc-manor.cgi');

	# 장원 설정을 가져오기
	my $i=$id2idx{$STATE->{leader}};
	ReadDTSub($DT[$i],"lord");
	$MANORLORD=$DT[$i]->{_lord};

	ReadDTSub($DT,"seed");

my $usetime=10*60;
$i=int($Q{buy});

my @MYMANOR=@{$MANOR[$i]};
$price=$MANORLORD->{"price$i"};
OutError("bad request") if !$price;

$stock=$MANORLORD->{"count$i"};
OutError("판매재고가다 떨어 있습니다") if !$stock;

RequireFile('inc-html-ownerinfo.cgi');

$disp.="<BIG>●구매</BIG><br><br>";

$disp.=$TB.$TR.$TDB."상품".$TD;
$disp.=GetTagImgManor($MYMANOR[1]).$MYMANOR[0].$TRE;
$disp.=$TR.$TDB."가격".$TD.'@'.GetMoneyString($price).$TRE;
$disp.=$TR.$TDB."판매재고수".$TD.$stock." 개".$TRE;
$disp.=$TR.$TDB.'내 가게 보유 수'.$TD.($DT->{_seed}->{"base$i"} + 0)." 개".$TRE;
$disp.=$TBE;
$disp.="<hr width=500 noshade size=1>";

if($DT->{_seed}->{"base$i"}>=$tlimit)
	{$disp.='<BR>이것이상구매할 수 없습니다<BR>';}
elsif($DT->{money}<$price)
	{$disp.='<BR> 자금이 부족합니다<BR>';}
elsif(GetStockTime($DT->{time})<$usetime)
	{$disp.='<BR> 시간이 부족합니다<BR>';}
else
{
	$disp.="<FORM ACTION=\"action.cgi\" $METHOD>";
	$disp.="<INPUT TYPE=HIDDEN NAME=key VALUE=\"manor-s\">";
	$disp.="$USERPASSFORM";
	$disp.="<INPUT TYPE=HIDDEN NAME=bk VALUE=\"manor\">";
	$disp.="<INPUT TYPE=HIDDEN NAME=it VALUE=\"$i\">";
	$disp.="위 내용을 ";
	$limit=$tlimit - $DT->{_seed}->{"base$i"};
	$money=$MAX_MONEY;
	$money=int($DT->{money}/$price) if $price;
	$msg{1}=1;
	$msg{10}=10;
	$msg{100}=100;
	$msg{1000}=1000;
	$msg{10000}=10000;
	$msg{$stock}="$stock(재고최대)";
	$msg{$limit}="$limit(보유최대)";
	$msg{$money}="$money(자금최대)";
	$disp.="<SELECT NAME=num1 SIZE=1>";
	my $oldcnt=0;
	foreach my $cnt (sort { $a <=> $b } (1,10,50,$stock,$limit,$money))
	{
		last if $stock<$cnt || $DT->{money}<$cnt*$price || $cnt>$limit || $cnt==$oldcnt;

		$disp.="<OPTION VALUE=\"$cnt\">$msg{$cnt}";
		$oldcnt=$cnt;
	}
	$disp.="</SELECT> 개, 또는 ";
	$disp.="<INPUT TYPE=TEXT NAME=num2 SIZE=5> 개 ";

	$disp.="<INPUT TYPE=SUBMIT VALUE='산다'>";

	$disp.="<br>(소요 시간:".GetTime2HMS($usetime).")";
	$disp.="</FORM>";
}

OutSkin();
1;
