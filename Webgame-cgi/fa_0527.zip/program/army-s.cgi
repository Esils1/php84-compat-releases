#!/usr/bin/perl
# 고용반란처리 2005/01/06 유래

$NOMENU=1;
Lock();
DataRead();
CheckUserPass();
ReadArmy();

my $functionname=$Q{mode};
OutError("bad request") if !defined(&$functionname);
&$functionname;

WriteArmy();
RenewLog();
DataWrite();
DataCommitOrAbort();
UnLock();

$disp.=$TBT.$TRT.$TD.GetTagImgJob($DT->{job},$DT->{icon});
$disp.=$TD.GetMenuTag('army',	'[용병소로]');
$disp.=GetMenuTag('main','[내 가게로 돌아가기]');
$disp.=$TRE.$TBE;
$disp.="<br>".$ret;
OutSkin();
1;


sub plus
{
my $limit=($DT->{dignity}+0)*1000 - $ARMY{$DT->{id}};
my $price=($DTevent{rebel}) ? 1500 : 1000;
my $usetime=60*40;
UseTime($usetime);

$num=CheckCount($Q{cnt1},$Q{cnt2},0,$limit);
OutError('수량을 지정해 주세요.') if !$num;

$num=int($DT->{money}/$price) if $DT->{money}<$num*$price;
$num=0 if $num<0;
OutError('자금이 부족합니다.') if !$num;

$ARMY{$DT->{id}}+=$num;
$DT->{money}-=$num*$price;

$ret="병사 주둔소에서 드워프 병사를".$num."인@".GetMoneyString($price)."(계산".GetMoneyString($price*$num).")에서 고용했습니다";
$ret.="/".GetTime2HMS($usetime)."소비";
PushLog(0,$DT->{id},$ret);
}

sub fire
{
$num=CheckCount($Q{cnt1},$Q{cnt2},0,$ARMY{$DT->{id}});
OutError('수량을 지정해 주세요.') if !$num;

my $usetime=60*10;
UseTime($usetime);
$ARMY{$DT->{id}}-=$num;

$ret="드워프 병사를".$num."인해고했습니다";
$ret.="/".GetTime2HMS($usetime)."소비";
PushLog(0,$DT->{id},$ret);
}

sub rebelon
{
OutError('반란을 시작하다에는 rebel 라고 입력해 주세요.') if ($Q{cmd} ne "rebel");
OutError('병사수가 부족합니다.') if ($ARMY{$DT->{id}} < 2500);

my $usetime=60*30;
UseTime($usetime);
$DTevent{rebel}=$NOW_TIME+86400*3;
$RIOT{$DT->{id}}=1;
$STATE->{safety}=int($STATE->{safety} * 9 / 10) if ($STATE->{safety} > 5000);

$ret="드워프 병사가무장비벌발생. 반란이시작마되었습니다!";
PushLog(2,0,$DT->{shopname}."의지정지휘에서".$ret);
$ret.="/".GetTime2HMS($usetime)."소비";
}

sub rside
{
OutError('반란에호출응답하다에는 rebel 라고 입력해 주세요.') if ($Q{cmd} ne "rebel");

my $usetime=60*20;
UseTime($usetime);
$RIOT{$DT->{id}}=1;

$ret="반란에호출응답시, 참조전쟁했습니다!";
PushLog(3,0,$DT->{shopname}."가".$ret);
$ret.="/".GetTime2HMS($usetime)."소비";
}

sub lside
{
OutError('반란에 참가시나가라영주의 맛분을 하다것은 할 수 없습니다.') if ($RIOT{$DT->{id}});

my $usetime=60*20;
UseTime($usetime);
if ($STATE->{leader}==$DT->{id})
	{
	$STATE->{army}+=$ARMY{$DT->{id}};
	}
	else
	{
	$STATE->{robina}+=$ARMY{$DT->{id}};
	PushLog(3,0,$DT->{shopname}.'는영주에맛분시, 의용기병사를 파견했습니다.');
	}

delete $ARMY{$DT->{id}};
$ret="병사를 영주의 호위군에파견했습니다";
$ret.="/".GetTime2HMS($usetime)."소비";
}
