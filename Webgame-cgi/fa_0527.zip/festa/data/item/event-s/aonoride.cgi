package event;
sub _local_start {
foreach(@DT)
{
next if !$_->{item}[6-1];
my $flag;
foreach my $idx (0..$_->{showcasecount}-1)
{
my $itemno=$_->{showcase}[$idx];
$flag=1 if ($itemno==6);
}
next if !$flag;
$_->{rank}-=int($_->{rank}/6);
return (0,$_->{shopname}.'에서 파래가루 보관 문제 사건이 발생했습니다.?code'.$_->{id}.':3');
}
return 0;

}
1;
