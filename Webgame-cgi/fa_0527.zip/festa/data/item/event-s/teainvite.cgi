package event;
sub _local_start {
foreach(reverse@DT)
{
next if ($_->{job} eq "tea");
next if ($_->{item}[22-1] < 80);
next if !$_->{item}[1-1];
my $flag;
foreach my $idx (0..$_->{showcasecount}-1)
{
my $itemno=$_->{showcase}[$idx];
$flag=1 if ($itemno==1);
}
next if !$flag;
main::ReadDTSub($_,"data");
next if ($_->{_data}->{club} =~ /tea:/);
$_->{_data}->{club}.="tea:";
main::WriteDTSub($_,"data");
return (0,$_->{shopname}.'에서 다도부 권유 사건이 발생했습니다.?code'.$_->{id}.':5');
}
return 0;

}
1;
