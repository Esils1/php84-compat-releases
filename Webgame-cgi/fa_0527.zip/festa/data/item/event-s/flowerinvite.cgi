package event;
sub _local_start {
foreach(reverse@DT)
{
next if ($_->{job} eq "flower");
next if ($_->{item}[20-1] < 80);
next if ($_->{item}[21-1] > 40);
main::ReadDTSub($_,"data");
next if ($_->{_data}->{club} =~ /flower:/);
$_->{_data}->{club}.="flower:";
main::WriteDTSub($_,"data");
return (0,$_->{shopname}.'에서 꽃꽂이부 권유 사건이 발생했습니다.?code'.$_->{id}.':6');
}
return 0;

}
1;
