package event;
sub _local_start {
foreach(reverse@DT)
{
next if ($_->{job} eq "obake");
next if ($_->{item}[20-1] < 80);
next if ($_->{item}[21-1] < 80);
next if ($_->{item}[22-1] < 80);
main::ReadDTSub($_,"data");
next if ($_->{_data}->{club} =~ /obake:/);
$_->{_data}->{club}.="obake:";
main::WriteDTSub($_,"data");
return (0,$_->{shopname}.'에서 고전부 권유 사건이 발생했습니다.?code'.$_->{id}.':11');
}
return 0;

}
1;
