package event;
sub _local_start {
return if grep($_->{job} eq "boss",@DT);
foreach(reverse@DT)
{
next if ($_->{item}[20-1] < 85);
next if ($_->{item}[21-1] < 85);
next if ($_->{item}[22-1] < 85);
main::ReadDTSub($_,"data");
next if ($_->{_data}->{club} =~ /boss:/);
$_->{_data}->{club}.="boss:";
main::WriteDTSub($_,"data");
return (0,$_->{shopname}.'에서 실행위원회 권유 사건이 발생했습니다.?code'.$_->{id}.':12');
}
return 0;

}
1;
