package event;
sub _local_start {
foreach(reverse@DT)
{
next if ($_->{job} eq "magic");
next if ($_->{item}[21-1] < 80);
next if !$_->{item}[12-1];
my $flag;
foreach my $idx (0..$_->{showcasecount}-1)
{
my $itemno=$_->{showcase}[$idx];
$flag=1 if ($itemno==12);
}
next if !$flag;
main::ReadDTSub($_,"data");
next if ($_->{_data}->{club} =~ /magic:/);
$_->{_data}->{club}.="magic:";
main::WriteDTSub($_,"data");
return (0,$_->{shopname}.'에서 마술부 권유 사건이 발생했습니다.?code'.$_->{id}.':9');
}
return 0;

}
1;
