package event;
sub _local_start {
foreach(reverse@DT)
{
next if ($_->{job} eq "show");
next if ($_->{item}[21-1] > 40);
next if ($_->{item}[22-1] < 80);
main::ReadDTSub($_,"data");
next if ($_->{_data}->{club} =~ /show:/);
$_->{_data}->{club}.="show:";
main::WriteDTSub($_,"data");
return (0,$_->{shopname}.'에서 연극부 권유 사건이 발생했습니다.?code'.$_->{id}.':10');
}
return 0;

}
1;
