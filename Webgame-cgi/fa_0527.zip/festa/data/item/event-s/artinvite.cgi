package event;
sub _local_start {
foreach(reverse@DT)
{
next if ($_->{job} eq "art");
next if ($_->{item}[20-1] > 40);
next if ($_->{item}[21-1] > 40);
next if ($_->{item}[22-1] > 40);
main::ReadDTSub($_,"data");
next if ($_->{_data}->{club} =~ /art:/);
$_->{_data}->{club}.="art:";
main::WriteDTSub($_,"data");
return (0,$_->{shopname}.'에서 미술부 권유 사건이 발생했습니다.?code'.$_->{id}.':4');
}
return 0;

}
1;
