package event;
sub _local_start {
foreach(@DT)
{
next if $_->{money}<100000;
next if !$_->{item}[1-1];
next if $_->{item}[15-1];
my $flag;
foreach my $idx (0..$_->{showcasecount}-1)
{
my $itemno=$_->{showcase}[$idx];
$flag=1 if ($itemno==1);
}
next if !$flag;
$_->{money}-=50000;
$_->{paytoday}+=50000;
$_->{item}[15-1]++;
return (0,$_->{shopname}.'에서 아이스 보관 문제 사건이 발생했습니다.?code'.$_->{id}.':1');
}
return 0;

}
1;
