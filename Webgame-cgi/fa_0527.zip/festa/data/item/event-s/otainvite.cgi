package event;
sub _local_start {
foreach(reverse@DT)
{
next if ($_->{job} eq "otakkie");
next if ($_->{item}[20-1] < 80);
next if ($_->{item}[21-1] < 80);
main::ReadDTSub($_,"data");
next if ($_->{_data}->{club} =~ /otakkie:/);
$_->{_data}->{club}.="otakkie:";
main::WriteDTSub($_,"data");
return (0,$_->{shopname}.'에서 컴퓨터부 권유 사건이 발생했습니다.?code'.$_->{id}.':8');
}
return 0;

}
1;
