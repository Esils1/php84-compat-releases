package event;
sub _local_start {
foreach(@DT)
{
next if $_->{money}<100000;
next if !$_->{item}[7-1];
next if $_->{item}[16-1];
my $flag;
foreach my $idx (0..$_->{showcasecount}-1)
{
my $itemno=$_->{showcase}[$idx];
$flag=1 if ($itemno==7);
}
next if !$flag;
$_->{money}-=50000;
$_->{paytoday}+=50000;
$_->{item}[16-1]++;
return (0,$_->{shopname}.'에서 100% 문어 사건이 발생했습니다.?code'.$_->{id}.':2');
}
return 0;

}
1;
