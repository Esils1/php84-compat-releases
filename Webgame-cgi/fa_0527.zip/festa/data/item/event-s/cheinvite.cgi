package event;
sub _local_start {
foreach(reverse@DT)
{
next if ($_->{job} eq "chemist");
next if ($_->{item}[21-1] < 80);
next if ($_->{item}[22-1] > 40);
main::ReadDTSub($_,"data");
next if ($_->{_data}->{club} =~ /chemist:/);
$_->{_data}->{club}.="chemist:";
main::WriteDTSub($_,"data");
return (0,$_->{shopname}.'에서 화학부 권유 사건이 발생했습니다.?code'.$_->{id}.':7');
}
return 0;

}
1;
