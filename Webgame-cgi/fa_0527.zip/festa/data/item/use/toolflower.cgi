package item;
$USE[0]={'code'=>'toolflower','no'=>0,'itemno'=>'46','name'=>'동아리방 정리하기','info'=>'여러 재료가 나올 수 있습니다','scale'=>'회','action'=>'정리하기','money'=>0,'time'=>3600,'exptime'=>'900','exp'=>'10','result'=>{'message'=>{'resultok'=>'사용할 수 있는 재료가 표시되었습니다','resultng'=>'아무것도 찾을 수 없었습니다…',},'create'=>[{'no'=>47,'count'=>45,'proba'=>700},{'no'=>48,'count'=>3,'proba'=>700},{'no'=>49,'count'=>3,'proba'=>520},{'no'=>50,'count'=>3,'proba'=>700},],},};
sub _job_use_0_flower_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[1]={'code'=>'toolflower','no'=>1,'itemno'=>'46','name'=>'꽃다발 만들기','info'=>'꽃을 모아 꽃다발을 만듭니다','scale'=>'회','action'=>'만들기','money'=>0,'time'=>900,'exptime'=>'300','exp'=>'10','use'=>[{'no'=>47,'count'=>12,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'꽃다발를 만들었습니다','resultng'=>'제작에 실패했습니다…',},'create'=>[{'no'=>42,'count'=>12,'proba'=>800},],},};
sub _job_use_1_flower_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[2]={'code'=>'toolflower','no'=>2,'itemno'=>'46','name'=>'압화 만들기','info'=>'꽃을 눌러 말려 액자에 장식합니다','scale'=>'회','action'=>'만들기','money'=>0,'time'=>1800,'exptime'=>'600','exp'=>'20','needexp'=>'200','use'=>[{'no'=>47,'count'=>12,'proba'=>1000},{'no'=>48,'count'=>4,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'압화를 만들었습니다','resultng'=>'제작에 실패했습니다…',},'create'=>[{'no'=>43,'count'=>16,'proba'=>800},],},};
sub _job_use_2_flower_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[3]={'code'=>'toolflower','no'=>3,'itemno'=>'46','name'=>'드라이플라워 만들기','info'=>'꽃을 말려 오래 보관할 수 있게 만듭니다','scale'=>'회','action'=>'만들기','money'=>0,'time'=>1800,'exptime'=>'600','exp'=>'20','needexp'=>'400','use'=>[{'no'=>47,'count'=>12,'proba'=>1000},{'no'=>49,'count'=>3,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'드라이플라워를 만들었습니다','resultng'=>'제작에 실패했습니다…',},'create'=>[{'no'=>44,'count'=>3,'proba'=>800},],},};
sub _job_use_3_flower_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[4]={'code'=>'toolflower','no'=>4,'itemno'=>'46','name'=>'나만의 꽃꽂이 작품 만들기','info'=>'새 예술에 도합니다','scale'=>'회','action'=>'만들기','money'=>0,'time'=>1800,'exptime'=>'600','exp'=>'20','needexp'=>'600','use'=>[{'no'=>47,'count'=>12,'proba'=>1000},{'no'=>50,'count'=>4,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'응용 꽃꽂이 작품을 만들었습니다','resultng'=>'제작에 실패했습니다…',},'create'=>[{'no'=>45,'count'=>1,'proba'=>500},],},};
sub _job_use_4_flower_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}

1;
