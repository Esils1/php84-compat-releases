package item;
$USE[0]={'code'=>'badgossip','no'=>0,'itemno'=>'19','name'=>'칠판 지우개 장난치기','info'=>'성공하면 상대 점포의 인기를 내리지만실패할 수도 있습니다...','scale'=>'회','action'=>'장난치기','money'=>50000,'time'=>18000,'exptime'=>'14400','exp'=>'200','arg'=>'target|nocount','needpoint'=>'20000','result'=>{'function'=>'_local_1',},};
sub _local_1 {eval(<<'_eval_code_');
my $ret;if(rand(1000)<800 && !$DTS->{exp}{80}){$DTS->{rank}-=int($DTS->{rank}/3);$ret=$DTS->{shopname}.'에칠판 지우개 장난치기작전이성공했습니다';WriteLog(0,$DT->{id},$ret);WriteLog(2,0,$DTS->{shopname}.'에서 칠판 지우개가 고객의 머리 위로 떨어져 인기가 내려갔습니다.');}else{$DTS->{exp}{80}-=100;$DTS->{exp}{80}=0 if ($DTS->{exp}{80} < 0);$DT->{rank}-=int($DT->{rank}/4);$ret=$DTS->{shopname}.'에칠판 지우개 장난치기작전은 실패했습니다';WriteLog(0,$DT->{id},$ret);WriteLog(3,0,$DT->{shopname}."가".$DTS->{shopname}.'에칠판 지우개를 구조걸기해서있었던 것 같습니다.');}return $ret;
_eval_code_
}
sub _job_use_0_boss_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[1]={'code'=>'badgossip','no'=>1,'itemno'=>'19','name'=>'좀도둑질하기','info'=>'그곳까지추적이포함마되어루의 라면할 수 없네요…','scale'=>'회','action'=>'좀도둑질하기','money'=>50000,'time'=>18000,'exptime'=>'14400','exp'=>'250','arg'=>'target|nocount','needpoint'=>'20000','result'=>{'function'=>'stole',},};
$USE[2]={'code'=>'badgossip','no'=>2,'itemno'=>'19','name'=>'압정 뿌리기','info'=>'다른 점포의 진열대에 압정을 뿌리고 옵니다','scale'=>'회','action'=>'장난치기','money'=>50000,'time'=>25200,'exptime'=>'21600','exp'=>'200','arg'=>'target|nocount','needpoint'=>'20000','result'=>{'function'=>'fire',},};

1;
