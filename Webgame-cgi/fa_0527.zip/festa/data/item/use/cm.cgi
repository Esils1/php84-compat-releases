package item;
$USE[0]={'code'=>'cm','no'=>0,'itemno'=>'80','name'=>'내 가게 광고','info'=>'내 가게의 인기를 올립니다','scale'=>'회','action'=>'광고하기','money'=>0,'time'=>18000,'exptime'=>'18000','exp'=>'100','arg'=>'nocount','use'=>[{'no'=>80,'count'=>1,'proba'=>1000},],'result'=>{'function'=>'_local_1',},};
sub _local_1 {eval(<<'_eval_code_');
my $up=int(500*(2-$DT->{rank}/5000));if ( rand(1000)<250 ) {$DT->{rank}-=$up;$DT->{rank}=1000 if $DT->{rank}<1000;my $ret="광고가 역효과를 냈습니다: 인기".int($up/100)."%다운";WriteLog(0,$DT->{id},$ret);WriteLog(3,0,$DT->{shopname}."가 광고를 냈지만 역효과가 났습니다.");return $ret;}$DT->{rank}+=$up;$DT->{rank}=10000 if $DT->{rank}>10000;my $ret="광고를 냈습니다: 인기".int($up/100)."% 상승";WriteLog(0,$DT->{id},$ret);WriteLog(3,0,$DT->{shopname}."가 광고를 냈습니다.");return $ret;
_eval_code_
}
sub _job_use_0_boss_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[1]={'code'=>'cm','no'=>1,'itemno'=>'80','name'=>'다른 점포 광고','info'=>'다른 점포의 인기를 올립니다','scale'=>'회','action'=>'광고하기','money'=>0,'time'=>18000,'exptime'=>'18000','arg'=>'target|nocount','use'=>[{'no'=>80,'count'=>1,'proba'=>1000},],'result'=>{'function'=>'_local_2',},};
sub _local_2 {eval(<<'_eval_code_');
return '내 가게는 지정할 수 없습니다' if ($DT==$DTS);my $up=int(500*(2-$DTS->{rank}/5000));$DTS->{rank}+=$up;$DTS->{rank}=10000 if $DTS->{rank}>10000;my $ret="광고를 냈습니다: ".$DTS->{shopname}."의 인기".int($up/100)."% 상승";WriteLog(0,$DT->{id},$ret);WriteLog(3,0,$DT->{shopname}."가".$DTS->{shopname}."의 광고를 냈습니다.");return $ret;
_eval_code_
}
$USE[2]={'code'=>'cm','no'=>2,'itemno'=>'80','name'=>'길드 광고','info'=>'같은 길드 소속 점포 전체의 인기를 올립니다','scale'=>'회','action'=>'광고하기','money'=>0,'time'=>28800,'exptime'=>'28800','arg'=>'nocount','use'=>[{'no'=>80,'count'=>1,'proba'=>1000},],'result'=>{'function'=>'_local_3',},};
sub _local_3 {eval(<<'_eval_code_');
return '길드에 가입되어 있지 않아 광고를 낼 수 없습니다' if !$DT->{guild};WriteLog(3,0,$DT->{shopname}."가 길드 '".$main::GUILD{$DT->{guild}}->[$GUILDIDX_name]."'의 광고를 냈습니다.");foreach my $DTS (@DT){next if ($DTS->{guild} ne $DT->{guild});my $up=int(500*(2-$DTS->{rank}/5000));$DTS->{rank}+=$up;$DTS->{rank}=10000 if $DTS->{rank}>10000;my $ret="길드광고를 냈습니다: ".$DTS->{shopname}."의 인기".int($up/100)."% 상승";WriteLog(0,$DT->{id},$ret);}return '길드 광고를 냈습니다';
_eval_code_
}

1;
