package item;
$USE[0]={'code'=>'toolshow','no'=>0,'itemno'=>'73','name'=>'새 연극 각본 기획하기','info'=>'연극 공연의 스토리를 구상합니다','scale'=>'회','action'=>'공연을 기획하다','money'=>0,'time'=>21600,'exptime'=>'21600','exp'=>'100','arg'=>'nocount|message20','result'=>{'function'=>'newshow',},};
sub _job_use_0_show_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[1]={'code'=>'toolshow','no'=>1,'itemno'=>'73','name'=>'연극 공연권을 인쇄하기','info'=>'티켓을 만듭니다','scale'=>'회','action'=>'인쇄하기','money'=>2400,'time'=>1800,'exptime'=>'600','functionbefore'=>'ptcheck','result'=>{'message'=>{'resultok'=>'연극 공연권을 만들었습니다','resultng'=>'인쇄에 실패했습니다…',},'create'=>[{'no'=>72,'count'=>8,'proba'=>800},],},};
sub _job_use_1_show_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[2]={'code'=>'toolshow','no'=>2,'itemno'=>'73','name'=>'연극 공연을 열기','info'=>'준비한 공연을 열 수 있습니다','scale'=>'회','action'=>'개최하기','money'=>0,'time'=>14400,'exptime'=>'14400','exp'=>'30','functionbefore'=>'ptcheck','result'=>{'function'=>'showing',},};
sub _job_use_2_show_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}

1;
