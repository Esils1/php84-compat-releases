package item;
$USE[0]={'code'=>'testmat','no'=>0,'itemno'=>'21','name'=>'수학을 공부하기','info'=>'수학을 공부합니다','scale'=>'회','action'=>'공부하기','money'=>0,'time'=>3600,'exptime'=>'3600','exp'=>'50','result'=>{'function'=>'study',},};

1;
