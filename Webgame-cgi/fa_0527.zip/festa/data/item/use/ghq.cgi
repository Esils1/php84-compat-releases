package item;
$USE[0]={'code'=>'ghq','no'=>0,'itemno'=>'81','name'=>'화장실 이용권을 인쇄하기','info'=>'운영본부의 복사기로 인쇄합니다','scale'=>'회','action'=>'인쇄하기','money'=>1200,'time'=>900,'exptime'=>'300','exp'=>'10','result'=>{'message'=>{'resultok'=>'화장실 이용권을 만들었습니다','resultng'=>'제작에 실패했습니다…',},'create'=>[{'no'=>77,'count'=>12,'proba'=>800},],},};
sub _job_use_0_boss_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[1]={'code'=>'ghq','no'=>1,'itemno'=>'81','name'=>'주차장 이용권을 인쇄하기','info'=>'운영본부의 복사기로 인쇄합니다','scale'=>'회','action'=>'인쇄하기','money'=>2400,'time'=>1800,'exptime'=>'600','exp'=>'20','needexp'=>'200','result'=>{'message'=>{'resultok'=>'주차장 이용권을 만들었습니다','resultng'=>'제작에 실패했습니다…',},'create'=>[{'no'=>78,'count'=>8,'proba'=>800},],},};
$USE[2]={'code'=>'ghq','no'=>2,'itemno'=>'81','name'=>'팸플릿을 인쇄하기','info'=>'운영본부의 복사기로 인쇄합니다','scale'=>'회','action'=>'인쇄하기','money'=>2400,'time'=>1800,'exptime'=>'600','exp'=>'20','needexp'=>'400','result'=>{'message'=>{'resultok'=>'팸플릿을 만들었습니다','resultng'=>'제작에 실패했습니다…',},'create'=>[{'no'=>79,'count'=>3,'proba'=>800},],},};
$USE[3]={'code'=>'ghq','no'=>3,'itemno'=>'81','name'=>'포스터를 인쇄하기','info'=>'운영본부의 복사기로 인쇄합니다','scale'=>'회','action'=>'인쇄하기','money'=>2400,'time'=>1800,'exptime'=>'600','exp'=>'20','needexp'=>'600','result'=>{'message'=>{'resultok'=>'포스터를 만들었습니다','resultng'=>'제작에 실패했습니다…',},'create'=>[{'no'=>80,'count'=>1,'proba'=>500},],},};

1;
