package item;
$USE[0]={'code'=>'toolche','no'=>0,'itemno'=>'55','name'=>'동아리방 정리하기','info'=>'여러 재료가 나올 수 있습니다','scale'=>'회','action'=>'정리하기','money'=>0,'time'=>3600,'exptime'=>'900','exp'=>'10','result'=>{'message'=>{'resultok'=>'사용할 수 있는 재료가 표시되었습니다','resultng'=>'아무것도 찾을 수 없었습니다…',},'create'=>[{'no'=>56,'count'=>11,'proba'=>700},{'no'=>57,'count'=>18,'proba'=>700},{'no'=>58,'count'=>9,'proba'=>700},{'no'=>59,'count'=>3,'proba'=>700},{'no'=>60,'count'=>1,'proba'=>500},],},};
sub _job_use_0_chemist_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[1]={'code'=>'toolche','no'=>1,'itemno'=>'55','name'=>'염화나트륨을 화합하기','info'=>'화학 반응으로 염화나트륨을 만듭니다','scale'=>'회','action'=>'화합하기','money'=>0,'time'=>900,'exptime'=>'300','exp'=>'10','use'=>[{'no'=>56,'count'=>6,'proba'=>1000},{'no'=>57,'count'=>6,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'염화나트륨을 만들었습니다','resultng'=>'제작에 실패했습니다…',},'create'=>[{'no'=>51,'count'=>12,'proba'=>800},],},};
sub _job_use_1_chemist_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[2]={'code'=>'toolche','no'=>2,'itemno'=>'55','name'=>'알칼리 이온수를 화합하기','info'=>'화학 반응으로 알칼리 이온수를 만듭니다','scale'=>'회','action'=>'화합하기','money'=>0,'time'=>1800,'exptime'=>'600','exp'=>'20','needexp'=>'200','use'=>[{'no'=>57,'count'=>12,'proba'=>1000},{'no'=>58,'count'=>4,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'알칼리 이온수를 만들었습니다','resultng'=>'제작에 실패했습니다…',},'create'=>[{'no'=>52,'count'=>8,'proba'=>800},],},};
sub _job_use_2_chemist_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[3]={'code'=>'toolche','no'=>3,'itemno'=>'55','name'=>'도코사헥사엔산을 화합하기','info'=>'화학 반응으로 도코사헥사엔산을 만듭니다','scale'=>'회','action'=>'화합하기','money'=>0,'time'=>1800,'exptime'=>'600','exp'=>'20','needexp'=>'400','use'=>[{'no'=>58,'count'=>4,'proba'=>1000},{'no'=>59,'count'=>4,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'도코사헥사엔산을 만들었습니다','resultng'=>'제작에 실패했습니다…',},'create'=>[{'no'=>53,'count'=>3,'proba'=>800},],},};
sub _job_use_3_chemist_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[4]={'code'=>'toolche','no'=>4,'itemno'=>'55','name'=>'나만의 화학 반응 실험하기','info'=>'새로운 화합물 제작에 도전합니다','scale'=>'회','action'=>'화합하기','money'=>0,'time'=>1800,'exptime'=>'600','exp'=>'20','needexp'=>'600','use'=>[{'no'=>56,'count'=>6,'proba'=>1000},{'no'=>58,'count'=>4,'proba'=>1000},{'no'=>60,'count'=>1,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'신비한 화합물을 만들었습니다','resultng'=>'제작에 실패했습니다…',},'create'=>[{'no'=>54,'count'=>1,'proba'=>500},],},};
sub _job_use_4_chemist_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}

1;
