package item;
$USE[0]={'code'=>'toolobake','no'=>0,'itemno'=>'75','name'=>'새 귀신의 집 만들기','info'=>'귀신의 집 동선을 정합니다','scale'=>'회','action'=>'귀신의 집 운영하기','money'=>0,'time'=>21600,'exptime'=>'21600','exp'=>'100','arg'=>'nocount|message20','result'=>{'function'=>'newobake',},};
sub _job_use_0_obake_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[1]={'code'=>'toolobake','no'=>1,'itemno'=>'75','name'=>'귀신의 집 입장권을 인쇄하기','info'=>'티켓을 만듭니다','scale'=>'회','action'=>'인쇄하기','money'=>2400,'time'=>1800,'exptime'=>'600','functionbefore'=>'ptcheck','result'=>{'message'=>{'resultok'=>'귀신의 집 입장권을 만들었습니다','resultng'=>'인쇄에 실패했습니다…',},'create'=>[{'no'=>74,'count'=>8,'proba'=>800},],},};
sub _job_use_1_obake_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[2]={'code'=>'toolobake','no'=>2,'itemno'=>'75','name'=>'귀신 특별 쇼를 열기','info'=>'귀신 춤 이벤트를 열 수 있습니다','scale'=>'회','action'=>'개최하기','money'=>0,'time'=>14400,'exptime'=>'14400','exp'=>'30','functionbefore'=>'ptcheck','result'=>{'function'=>'obaking',},};
sub _job_use_2_obake_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}

1;
