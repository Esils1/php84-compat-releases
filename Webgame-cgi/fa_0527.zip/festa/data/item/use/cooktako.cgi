package item;
$USE[0]={'code'=>'cooktako','no'=>0,'itemno'=>'16','name'=>'타코야키를 조리하기','info'=>'타코야키를 만듭니다','scale'=>'회','action'=>'조리하기','money'=>0,'time'=>1800,'exptime'=>'600','exp'=>'20','use'=>[{'no'=>7,'count'=>1,'proba'=>1000},{'no'=>8,'count'=>1,'proba'=>1000},{'no'=>9,'count'=>1,'proba'=>1000},{'no'=>10,'count'=>1,'proba'=>1000},{'no'=>5,'count'=>1,'proba'=>1000},{'no'=>6,'count'=>1,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'타코야키를 만들었습니다','resultng'=>'조리에 실패했습니다...',},'create'=>[{'no'=>12,'count'=>48,'proba'=>800},],},};
sub _job_use_0_boss_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[1]={'code'=>'cooktako','no'=>1,'itemno'=>'16','name'=>'계란을 구워 보기','info'=>'알을 구워 봅니다','scale'=>'회','action'=>'조리하기','money'=>0,'time'=>1800,'exptime'=>'600','exp'=>'20','use'=>[{'no'=>8,'count'=>4,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'계란구이가 완성되었습니다','resultng'=>'조리에 실패했습니다...',},'create'=>[{'no'=>13,'count'=>40,'proba'=>800},],},};
$USE[2]={'code'=>'cooktako','no'=>2,'itemno'=>'16','name'=>'양배추를 구워 보기','info'=>'양배추를 구워 봅니다','scale'=>'회','action'=>'조리하기','money'=>0,'time'=>1800,'exptime'=>'600','exp'=>'20','use'=>[{'no'=>5,'count'=>6,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'구운 양배추가 완성되었습니다','resultng'=>'조리에 실패했습니다...',},'create'=>[{'no'=>14,'count'=>30,'proba'=>800},],},};

1;
