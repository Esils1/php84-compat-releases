package item;
$USE[0]={'code'=>'cooktable','no'=>0,'itemno'=>'15','name'=>'야키소바를 조리하기','info'=>'야키소바를 만듭니다','scale'=>'회','action'=>'조리하기','money'=>0,'time'=>1800,'exptime'=>'600','exp'=>'20','use'=>[{'no'=>3,'count'=>5,'proba'=>1000},{'no'=>4,'count'=>3,'proba'=>1000},{'no'=>5,'count'=>1,'proba'=>1000},{'no'=>6,'count'=>1,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'야키소바를 만들었습니다','resultng'=>'조리에 실패했습니다...',},'create'=>[{'no'=>11,'count'=>48,'proba'=>800},],},};
sub _job_use_0_boss_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[1]={'code'=>'cooktable','no'=>1,'itemno'=>'15','name'=>'계란을 구워 보기','info'=>'알을 구워 봅니다','scale'=>'회','action'=>'조리하기','money'=>0,'time'=>1800,'exptime'=>'600','exp'=>'20','use'=>[{'no'=>8,'count'=>4,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'계란구이가 완성되었습니다','resultng'=>'조리에 실패했습니다...',},'create'=>[{'no'=>13,'count'=>40,'proba'=>800},],},};
$USE[2]={'code'=>'cooktable','no'=>2,'itemno'=>'15','name'=>'양배추를 구워 보기','info'=>'양배추를 구워 봅니다','scale'=>'회','action'=>'조리하기','money'=>0,'time'=>1800,'exptime'=>'600','exp'=>'20','use'=>[{'no'=>5,'count'=>6,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'구운 양배추가 완성되었습니다','resultng'=>'조리에 실패했습니다...',},'create'=>[{'no'=>14,'count'=>30,'proba'=>800},],},};

1;
