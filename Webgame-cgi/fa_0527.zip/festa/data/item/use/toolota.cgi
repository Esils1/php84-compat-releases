package item;
$USE[0]={'code'=>'toolota','no'=>0,'itemno'=>'65','name'=>'동아리방 정리하기','info'=>'여러 재료가 나올 수 있습니다','scale'=>'회','action'=>'정리하기','money'=>0,'time'=>3600,'exptime'=>'900','exp'=>'10','result'=>{'message'=>{'resultok'=>'사용할 수 있는 재료가 표시되었습니다','resultng'=>'아무것도 찾을 수 없었습니다…',},'create'=>[{'no'=>66,'count'=>18,'proba'=>700},{'no'=>67,'count'=>10,'proba'=>700},{'no'=>68,'count'=>3,'proba'=>500},{'no'=>69,'count'=>1,'proba'=>500},],},};
sub _job_use_0_otakkie_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[1]={'code'=>'toolota','no'=>1,'itemno'=>'65','name'=>'스크린 세이버를 개발하기','info'=>'기본적인 프로그램을 만듭니다','scale'=>'회','action'=>'개발하기','money'=>0,'time'=>900,'exptime'=>'300','exp'=>'10','use'=>[{'no'=>66,'count'=>12,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'스크린 세이버를 만들었습니다','resultng'=>'제작에 실패했습니다…',},'create'=>[{'no'=>61,'count'=>12,'proba'=>800},],},};
sub _job_use_1_otakkie_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[2]={'code'=>'toolota','no'=>2,'itemno'=>'65','name'=>'상인 이야기를 개발하기','info'=>'요즘 유행하는 Perl 프로그램을 만듭니다','scale'=>'회','action'=>'개발하기','money'=>0,'time'=>1800,'exptime'=>'600','exp'=>'20','needexp'=>'200','use'=>[{'no'=>67,'count'=>8,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'상인 이야기를 만들었습니다','resultng'=>'제작에 실패했습니다…',},'create'=>[{'no'=>62,'count'=>8,'proba'=>800},],},};
sub _job_use_2_otakkie_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[3]={'code'=>'toolota','no'=>3,'itemno'=>'65','name'=>'바이러스 제작 지원 프로그램을 개발하기','info'=>'장난성 프로그램을 만들어 봅니다','scale'=>'회','action'=>'개발하기','money'=>0,'time'=>1800,'exptime'=>'600','exp'=>'20','needexp'=>'400','use'=>[{'no'=>68,'count'=>3,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'바이러스 제작 지원 프로그램을 만들었습니다','resultng'=>'제작에 실패했습니다…',},'create'=>[{'no'=>63,'count'=>3,'proba'=>800},],},};
sub _job_use_3_otakkie_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[4]={'code'=>'toolota','no'=>4,'itemno'=>'65','name'=>'자신만의 게임을 개발하기','info'=>'새로운 프로그램 개발에 도전합니다','scale'=>'회','action'=>'개발하기','money'=>0,'time'=>1800,'exptime'=>'600','exp'=>'20','needexp'=>'600','use'=>[{'no'=>67,'count'=>6,'proba'=>1000},{'no'=>69,'count'=>1,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'동인 게임을 만들었습니다','resultng'=>'제작에 실패했습니다…',},'create'=>[{'no'=>64,'count'=>1,'proba'=>500},],},};
sub _job_use_4_otakkie_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}

1;
