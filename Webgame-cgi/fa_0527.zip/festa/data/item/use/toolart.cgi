package item;
$USE[0]={'code'=>'toolart','no'=>0,'itemno'=>'28','name'=>'동아리방 정리하기','info'=>'여러 재료가 나올 수 있습니다','scale'=>'회','action'=>'정리하기','money'=>0,'time'=>3600,'exptime'=>'900','exp'=>'10','result'=>{'message'=>{'resultok'=>'사용할 수 있는 재료가 표시되었습니다','resultng'=>'아무것도 찾을 수 없었습니다…',},'create'=>[{'no'=>29,'count'=>18,'proba'=>700},{'no'=>30,'count'=>11,'proba'=>700},{'no'=>31,'count'=>3,'proba'=>500},{'no'=>32,'count'=>1,'proba'=>500},],},};
sub _job_use_0_art_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[1]={'code'=>'toolart','no'=>1,'itemno'=>'28','name'=>'그림엽서를 그리기','info'=>'엽서에 그림을 그립니다','scale'=>'회','action'=>'그리기','money'=>0,'time'=>900,'exptime'=>'300','exp'=>'10','use'=>[{'no'=>29,'count'=>12,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'그림엽서를 만들었습니다','resultng'=>'제작에 실패했습니다…',},'create'=>[{'no'=>24,'count'=>12,'proba'=>800},],},};
sub _job_use_1_art_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[2]={'code'=>'toolart','no'=>2,'itemno'=>'28','name'=>'모사화을 그리기','info'=>'유명한 그림을 따라 그려 봅니다','scale'=>'회','action'=>'그리기','money'=>0,'time'=>1800,'exptime'=>'600','exp'=>'20','needexp'=>'200','use'=>[{'no'=>30,'count'=>8,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'모사화을 만들었습니다','resultng'=>'제작에 실패했습니다…',},'create'=>[{'no'=>25,'count'=>8,'proba'=>800},],},};
sub _job_use_2_art_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[3]={'code'=>'toolart','no'=>3,'itemno'=>'28','name'=>'조각상 만들기','info'=>'입체적인 예술 작품에 도전합니다','scale'=>'회','action'=>'그리기','money'=>0,'time'=>1800,'exptime'=>'600','exp'=>'20','needexp'=>'400','use'=>[{'no'=>31,'count'=>3,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'조각상을 만들었습니다','resultng'=>'제작에 실패했습니다…',},'create'=>[{'no'=>26,'count'=>3,'proba'=>800},],},};
sub _job_use_3_art_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[4]={'code'=>'toolart','no'=>4,'itemno'=>'28','name'=>'자신만의 그림 그리기','info'=>'새 예술에 도합니다','scale'=>'회','action'=>'그리기','money'=>0,'time'=>1800,'exptime'=>'600','exp'=>'20','needexp'=>'600','use'=>[{'no'=>30,'count'=>6,'proba'=>1000},{'no'=>32,'count'=>1,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'아름다운 그림을 만들었습니다','resultng'=>'제작에 실패했습니다…',},'create'=>[{'no'=>27,'count'=>1,'proba'=>500},],},};
sub _job_use_4_art_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}

1;
