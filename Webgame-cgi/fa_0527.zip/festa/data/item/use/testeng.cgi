package item;
$USE[0]={'code'=>'testeng','no'=>0,'itemno'=>'20','name'=>'영어를 공부하기','info'=>'영어를 공부합니다','scale'=>'회','action'=>'공부하기','money'=>0,'time'=>3600,'exptime'=>'3600','exp'=>'50','result'=>{'function'=>'study',},};

1;
