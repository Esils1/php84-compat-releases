package item;
$USE[0]={'code'=>'tooltea','no'=>0,'itemno'=>'37','name'=>'동아리방 정리하기','info'=>'여러 재료가 나올 수 있습니다','scale'=>'회','action'=>'정리하기','money'=>0,'time'=>3600,'exptime'=>'900','exp'=>'10','result'=>{'message'=>{'resultok'=>'사용할 수 있는 재료가 표시되었습니다','resultng'=>'아무것도 찾을 수 없었습니다…',},'create'=>[{'no'=>38,'count'=>18,'proba'=>700},{'no'=>39,'count'=>10,'proba'=>700},{'no'=>40,'count'=>3,'proba'=>500},{'no'=>41,'count'=>1,'proba'=>400},],},};
sub _job_use_0_tea_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[1]={'code'=>'tooltea','no'=>1,'itemno'=>'37','name'=>'차 우리기','info'=>'먼저 한 잔을 올립니다','scale'=>'회','action'=>'잠김됨','money'=>0,'time'=>900,'exptime'=>'300','exp'=>'10','use'=>[{'no'=>38,'count'=>12,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'오차를 잠김되었습니다','resultng'=>'제작에 실패했습니다…',},'create'=>[{'no'=>33,'count'=>24,'proba'=>800},],},};
sub _job_use_1_tea_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[2]={'code'=>'tooltea','no'=>2,'itemno'=>'37','name'=>'찻과자 만들기','info'=>'남은 재료를 활용해 만듭니다','scale'=>'회','action'=>'만들기','money'=>0,'time'=>1800,'exptime'=>'600','exp'=>'20','needexp'=>'200','use'=>[{'no'=>39,'count'=>8,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'찻과자를 만들었습니다','resultng'=>'제작에 실패했습니다…',},'create'=>[{'no'=>34,'count'=>16,'proba'=>800},],},};
sub _job_use_2_tea_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[3]={'code'=>'tooltea','no'=>3,'itemno'=>'37','name'=>'차솥 굽기','info'=>'차솥 제작에 도전합니다','scale'=>'회','action'=>'굽기','money'=>0,'time'=>1800,'exptime'=>'600','exp'=>'20','needexp'=>'400','use'=>[{'no'=>40,'count'=>3,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'차솥을 만들었습니다','resultng'=>'제작에 실패했습니다…',},'create'=>[{'no'=>35,'count'=>6,'proba'=>800},],},};
sub _job_use_3_tea_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[4]={'code'=>'tooltea','no'=>4,'itemno'=>'37','name'=>'자신만의 찻그릇 굽기','info'=>'새 경지에 도합니다','scale'=>'회','action'=>'굽기','money'=>0,'time'=>1800,'exptime'=>'600','exp'=>'20','needexp'=>'600','use'=>[{'no'=>40,'count'=>6,'proba'=>1000},{'no'=>41,'count'=>1,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'와비사비의 찻그릇을 만들었습니다','resultng'=>'제작에 실패했습니다…',},'create'=>[{'no'=>36,'count'=>1,'proba'=>500},],},};
sub _job_use_4_tea_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}

1;
