package item;
$USE[0]={'code'=>'toolmagic','no'=>0,'itemno'=>'71','name'=>'새 마술 공연 기획하기','info'=>'마술 공연의 소재를 구상합니다','scale'=>'회','action'=>'공연을 기획하다','money'=>0,'time'=>21600,'exptime'=>'21600','exp'=>'100','arg'=>'nocount|message20','result'=>{'function'=>'newmagic',},};
sub _job_use_0_magic_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[1]={'code'=>'toolmagic','no'=>1,'itemno'=>'71','name'=>'마술 공연권을 인쇄하기','info'=>'티켓을 만듭니다','scale'=>'회','action'=>'인쇄하기','money'=>2400,'time'=>1800,'exptime'=>'600','functionbefore'=>'ptcheck','result'=>{'message'=>{'resultok'=>'마술 공연권을 만들었습니다','resultng'=>'인쇄에 실패했습니다…',},'create'=>[{'no'=>70,'count'=>8,'proba'=>800},],},};
sub _job_use_1_magic_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[2]={'code'=>'toolmagic','no'=>2,'itemno'=>'71','name'=>'마술 공연을 열기','info'=>'준비한 공연을 열 수 있습니다','scale'=>'회','action'=>'개최하기','money'=>0,'time'=>14400,'exptime'=>'14400','exp'=>'30','functionbefore'=>'ptcheck','result'=>{'function'=>'showing',},};
sub _job_use_2_magic_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}

1;
