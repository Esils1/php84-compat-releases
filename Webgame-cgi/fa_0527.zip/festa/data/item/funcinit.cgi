 $TIME_SEND_ITEM=int($TIME_SEND_ITEM/4*3) if $DT->{job} eq 'boss'; 
1;
