push(@EVENTMSG,'화학부 권유');
1;
