push(@EVENTMSG,'파래가루가 눅눅해졌습니다');
1;
