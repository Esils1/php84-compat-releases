push(@EVENTMSG,'연극부 권유');
1;
