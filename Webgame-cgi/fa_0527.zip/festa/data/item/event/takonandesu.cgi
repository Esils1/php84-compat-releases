push(@EVENTMSG,'안에는 문어가 듬뿍 들어 있습니다');
1;
