push(@EVENTMSG,'미술부 권유');
1;
