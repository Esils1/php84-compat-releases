push(@EVENTMSG,'컴퓨터부 권유');
1;
