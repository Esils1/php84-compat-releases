push(@EVENTMSG,'실행위원회 권유');
1;
