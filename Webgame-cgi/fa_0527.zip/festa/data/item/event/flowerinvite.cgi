push(@EVENTMSG,'꽃꽂이부 권유');
1;
