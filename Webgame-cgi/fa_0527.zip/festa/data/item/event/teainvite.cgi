push(@EVENTMSG,'다도부 권유');
1;
