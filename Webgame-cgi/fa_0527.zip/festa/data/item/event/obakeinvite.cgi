push(@EVENTMSG,'고전부 권유');
1;
