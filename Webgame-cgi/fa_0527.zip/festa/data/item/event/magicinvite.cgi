push(@EVENTMSG,'마술부 권유');
1;
