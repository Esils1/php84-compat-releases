push(@EVENTMSG,'아이스는 그대로 두면 녹아 버립니다');
1;
