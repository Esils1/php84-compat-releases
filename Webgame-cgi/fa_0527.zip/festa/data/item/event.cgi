foreach(
'icejataranai	1	1000	_local_start									',
'takonandesu	2	1000	_local_start									',
'aonoride	3	1000	_local_start									',
'artinvite	4	1000	_local_start									',
'teainvite	5	1000	_local_start									',
'flowerinvite	6	1000	_local_start									',
'cheinvite	7	1000	_local_start									',
'otainvite	8	1000	_local_start									',
'magicinvite	9	700	_local_start									',
'showinvite	10	700	_local_start									',
'obakeinvite	11	700	_local_start									',
'bossinvite	12	700	_local_start									',
'rebel	13	0									_local_now	',
'guildbattle	14	0			_local_end							',
)
{
	my $hash={};
	(
		$hash->{code},
		$hash->{group},
		$hash->{startproba},
		$hash->{startfunc},
		$hash->{startfuncparam},
		$hash->{endfunc},
		$hash->{endfuncparam},
		$hash->{basetime},
		$hash->{plustime},
		$hash->{startmsg},
		$hash->{endmsg},
		$hash->{func},
		$hash->{funcparam},
	)=split(/\t/);
	$EVENT{$hash->{code}}=$hash;
}
1;
