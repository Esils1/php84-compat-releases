1779790668	/korhako/fa/festa/action.cgi	::1		::1		ip file read error 
