#!/usr/bin/perl
# 행사평가처리 2005/01/14 유래
# 캠퍼스 페스타 사양

Lock();
DataRead();
CheckUserPass();

ShowBoo();
RenewLog();
DataWrite();
DataCommitOrAbort();
UnLock();

OutSkin();
1;

sub ShowBoo
{
OutError('대상점을 선택해 주세요.') if !defined($id2idx{$Q{tg}});
OutError('초대장이 없으면 행사를 평가할 수 없습니다.') if !($DT->{item}[76-1]);
$DT->{item}[76-1]--;
my $cnt=100;
$cnt=-$cnt if ($Q{md});

my @draDT=grep($_->{user}->{pt},@DT);
foreach my $DT (@draDT)
	{
	if ($DT->{id}==$Q{tg})
		{
		$DT->{user}->{pt}+=$cnt;
		PushLog(0,0,$DT->{shopname}."의행사시물에".($Q{md} ? "야유" : "박수손")."가송신라되었습니다.");
		$disp.=$DT->{shopname}."의행사시물에".($Q{md} ? "야유" : "박수손")."를송신되었습니다.";
		}
		else
		{
		$DT->{user}->{pt}-=int(($DT->{user}->{pt} - 4000) / 10) if $DT->{user}->{pt} > 4000 && !$Q{md};
		$DT->{user}->{pt}-=int($cnt / scalar(@draDT));
		}
	$DT->{user}->{pt}=10000 if $DT->{user}->{pt} > 10000;
	$DT->{user}->{pt}=1 if $DT->{user}->{pt} < 1;
	}
}

