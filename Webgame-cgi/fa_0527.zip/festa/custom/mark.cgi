#!/usr/bin/perl
# 시험성적 2004/01/20 유래
# 캠퍼스 페스타 전용

DataRead();
CheckUserPass(1);

$disp.=GetMenuTag('mark',	'[종합]')
	.GetMenuTag('mark',	'[영어]','&t=1')
	.GetMenuTag('mark',	'[수학]','&t=2')
	.GetMenuTag('mark',	'[국어]','&t=3');
$disp.="<hr width=500 noshade size=1>";

$disp.='<BIG>●정기시험성적표</BIG>';
my $i;

if ($Q{t}==1) {
$disp.=":영어<br><br>";
$i=20;
} elsif ($Q{t}==2) {
$disp.=":수학<br><br>";
$i=21;
} elsif ($Q{t}==3) {
$disp.=":국어<br><br>";
$i=22;
} else {
$disp.=":종합<br><br>";
foreach(@DT) { $_->{item}[1-1]=$_->{item}[20-1] + $_->{item}[21-1] + $_->{item}[22-1]; }
$i=1;
}
	@DT=sort{$b->{item}[$i-1]<=>$a->{item}[$i-1]}@DT;
$disp.=$TB;
foreach my $n(0,1,2)
	{
next if !$DT[$n]->{id};
$disp.=$TR.$TDNW.$tdh_pt.GetTagImgKao($DT[$n]->{name},$DT[$n]->{icon});
$disp.=$TD."<SPAN>제 ".($n+1)."위</SPAN> : <b>".$DT[$n]->{shopname}."</b>";
$disp.="<br>".$DT[$n]->{comment};
$disp.=$TD.($DT[$n]->{item}[$i-1])."점";
$disp.=$TRE;
	}
if ($DTusercount>6)
	{
	$disp.=$TR.'<td colspan="3" align="center">...';
	$disp.=$TRE;

	foreach my $n(($DTusercount-3),($DTusercount-2),($DTusercount-1))
		{
	$disp.=$TR.$TDNW.$tdh_pt.GetTagImgKao($DT[$n]->{name},$DT[$n]->{icon});
	$disp.=$TD."<SPAN>제 ".($n+1)."위</SPAN> : <b>".$DT[$n]->{shopname}."</b>";
	$disp.="<br>".$DT[$n]->{comment};
	$disp.=$TD.($DT[$n]->{item}[$i-1])."점";
	$disp.=$TRE;
		}
	}
$disp.=$TBE;
OutSkin();
1;
