#!/usr/bin/perl
# 신문 보조 처리 2003/07/19 유래
# 캠퍼스 페스타 사양

my $topic=$Q{key} ne "log";

$disp.=$topic ? "<BIG>".$DT->{shopname}."의사건</BIG><br><br>" : "<BIG>●신문:속보</BIG><br><br>";

my($page,$pagestart,$pageend,$pagenext,$pageprev,$pagemax);
my $pagecontrol="";

if($topic)
{
	($page,$pagestart,$pageend,$pagenext,$pageprev,$pagemax)=(0,0,$MAIN_LOG_PAGE_ROWS-1,0,0,0);
}
else
{
	($page,$pagestart,$pageend,$pagenext,$pageprev,$pagemax)
		=GetPage($Q{lpg},$LIST_PAGE_ROWS,scalar(@MESSAGE));

	my $formtarget="<OPTION VALUE=\"\"".($Q{tgt}eq""?" SELECTED":"").">전체";
	foreach (@DT)
	{
		my $name=$_->{shopname};
		$formtarget.="<OPTION".($name eq $Q{tgt}?' SELECTED':'').">$name";
	}
	my $formmode="";
	foreach (0..3)
	{
		my $name=('전체','중요','정보','줄동')[$_];
		$formmode.="<OPTION VALUE=\"$_\"".($Q{lmd}==$_?" SELECTED":"").">$name";
	}

	$disp.=<<"HTML";
<form action="action.cgi" $METHOD>
<input type=hidden name=lpg value="0">
$MYFORM$USERPASSFORM
<select name=tgt>
$formtarget
</select>
<input type=text name=kw value="$Q{kw}">
<select name=lmd>
$formmode
</select>
<input type=submit value="검색">
</form>
HTML

	my $key=$Q{kw};
	$key=~s/(\W)/'%'.unpack('H2',$1)/eg;
	my $tgt=$Q{tgt};
	$tgt=~s/(\W)/'%'.unpack('H2',$1)/eg;

	my $search="";
	$search.="&kw=".$key if $key ne '';
	$search.="&tgt=".$tgt if $tgt ne '';
	$search.="&lmd=".($Q{lmd}+0) if $Q{lmd};

	$pagecontrol=GetPageControl($pageprev,$pagenext,$search,"lpg",$pagemax,$page);
	$disp.=$pagecontrol;

	$disp.="<BR>";
}

$disp.=$TB;
if (!$topic && @EVENTMSG) {
	foreach (sort(@EVENTMSG))
		{$disp.=$TR.$TDB.'정보:'.$_.$TRE;}
	}
$disp.=$TR.$TD;
foreach my $cnt ($pagestart..$pageend)
{
	my $msg=$MESSAGE[$cnt];
	next if $msg eq '';
	my($tm,$mode,$id,$message)=split('\t',$msg);
	chop($message);

	my $detail;
	if ($message =~ /\?code(\d+):(\d+)$/)
		{
		my $i;
		($message,$i)=split('\?code',$message);
		$detail=" > ".GetMenuTag('flag','[상세]',"&class=$1&mode=$2&check=".crypt($1,$2));
		}

	if($MOBILE)
	{
		if($id==$DT->{id})
			{$disp.="비밀:".$message;}
		elsif($mode==1)
			{$disp.="★중요:".$message;}
		elsif($mode==2)
			{$disp.="●정보:".$message.$detail;}
		elsif($mode==3)
			{$disp.="○줄동:".$message;}
		else
			{$disp.=$message;}
	}
	else
	{
		if($id==$DT->{id})
			{$disp.="<FONT COLOR=\"#666666\">".$message."(비밀)</FONT>";}
		elsif($mode==1)
			{$disp.="<small>".GetTime2FormatTime($tm)."</small> <BIG>[중요]".$message."</BIG>";}
		elsif($mode==2)
			{$disp.="<small>".GetTime2FormatTime($tm)."</small> <SPAN>[정보]".$message."</SPAN>".$detail;}
		elsif($mode==3)
			{$disp.="<small>".GetTime2FormatTime($tm)."</small> [줄동]<B>".$message."</B>";}
		else
			{$disp.="<small>".GetTime2FormatTime($tm)."</small> ".$message;}
	}

	$disp.="<BR>";
}

$disp.=$TRE.$TBE;

$disp.=$pagecontrol;

1;
