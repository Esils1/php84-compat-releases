#!/usr/bin/perl
# 이벤트 알림 2003/10/10 유래
# 캠퍼스 페스타 전용

DataRead();
CheckUserPass(1);

$disp.=GetMenuTag('log',	'[속보]')
	.GetMenuTag('log',	'[입상]','&t=3')
	.GetMenuTag('log',	'[순위]','&t=4')
	.GetMenuTag('log',	'[작위]','&t=5');
$disp.="<hr width=500 noshade size=1>";
$disp.="<BIG>●신문:삼면글</BIG><br><br>";

OutError('숫자값에부정이 있습니다') if (crypt($Q{class},$Q{mode}) ne $Q{check});
my $functionname="story".$Q{mode};
OutError('현재의 상태에서는 이 명령을 실행할 수 없습니다') if !defined(&$functionname);
&$functionname if defined(&$functionname);

OutSkin();
1;

sub story1
{
	my $idx=$id2idx{$Q{class}};
	my $shopname="<SPAN>".$DT[$idx]->{shopname}."</SPAN>";
	my $name="<SPAN>".$DT[$idx]->{name}."</SPAN>";
	my $icon=GetTagImgKao($DT[$idx]->{name},$DT[$idx]->{icon});
	my $people=GetTagImgKao("손님","st1");

	$disp.=<<STR;
<TABLE cellpadding="26" width="570">$TR$TD
아이스크림을 판매하는$shopname 의 점주$name 에게, 어느 날 이런 손님이 찾아왔다.<br><br>
$people<SPAN>손님</SPAN>:실행합니다.<br>
$icon$name:어서 오세요. 아이스크림입니까?<br>
$people<SPAN>손님</SPAN>:음, 아이스는 이미많이먹었는 로 요…<br>
$icon$name:네? 그럼 어떻게 하지?<br>
$people<SPAN>손님</SPAN>:배가 고픈 것은 아니므로, 뭔가 없습니까?<br>
$icon$name:입니다아, 모와 아이스를 도우조.<br>
$people<SPAN>손님</SPAN>:아이스만으로 는 배가 안 불러요. 흑흑.<br>
$icon$name:음. 그럼 무엇을 드시겠습니까? (귀찮은 손님이네.)<br>
$people<SPAN>손님</SPAN>:야키소바가 먹고 싶어요. 흑흑.<br>
$icon$name:아, 야키소바는 판매라 없습니다. 만들기기계재료가없어서.<br>
$people<SPAN>손님</SPAN>:너무해요. 흑흑. 선생님에게 일러바칠 거야.<br>
$icon$name:....(곤란한 손님이네.)<br><br>
선생님에게 일러바치면 곤란하므로,<br>
$name 은나 키소바용 <SPAN>조리대</SPAN>를
STR
	$disp.=GetMoneyString(50000)."로 구매하기로 했습니다.<br>(이후, 야키소바를 조리할 수 있습니다.)$TRE$TBE";
}

sub story2
{
	my $idx=$id2idx{$Q{class}};
	my $shopname="<SPAN>".$DT[$idx]->{shopname}."</SPAN>";
	my $name="<SPAN>".$DT[$idx]->{name}."</SPAN>";
	my $icon=GetTagImgKao($DT[$idx]->{name},$DT[$idx]->{icon});
	my $people=GetTagImgKao("손님","st2");

	$disp.=<<STR;
<TABLE cellpadding="26" width="570">$TR$TD
문어를 그대로 판매하던$shopname 의 점주$name 에게, 어느 날 이런 손님이 찾아왔다.<br><br>
$people<SPAN>손님</SPAN>:실행합니다. 타코야키 주세요.<br>
$icon$name:어서 오세요. 네, 도우조.<br>
$people<SPAN>손님</SPAN>:....<br>
$icon$name:응?도우했습니다?<br>
$people<SPAN>손님</SPAN>:저기, 이건 그냥 문어인로 요.<br>
$icon$name:네, 안에는 문어가 듬뿍 들어 있습니다.<br>
$people<SPAN>손님</SPAN>:....<br>
$icon$name:....<br>
$people<SPAN>손님</SPAN>:... 제대로 구워 주세요.<br><br>
역시 굽는 과정이 필요하다는 것을 깨닫고,<br>
$name 은<SPAN>타코야키 기구</SPAN>를
STR
	$disp.=GetMoneyString(50000)."로 구매하기로 했습니다.<br>(이후, 타코야키를 조리할 수 있습니다.)$TRE$TBE";
}

sub story3
{
	my $idx=$id2idx{$Q{class}};
	my $shopname="<SPAN>".$DT[$idx]->{shopname}."</SPAN>";
	my $name="<SPAN>".$DT[$idx]->{name}."</SPAN>";
	my $icon=GetTagImgKao($DT[$idx]->{name},$DT[$idx]->{icon});
	my $people=GetTagImgKao("손님","st3");

	$disp.=<<STR;
<TABLE cellpadding="26" width="570">$TR$TD
파래가루를 그대로 판매하던$shopname 의 점주$name 에게, 어느 날 이런 손님이 찾아왔다.<br><br>
$people<SPAN>손님</SPAN>:에와 이점은 무엇을 파는 곳일까요?<br>
$icon$name:어서 오세요. 파래가루를 판매하고 있습니다만.<br>
$people<SPAN>손님</SPAN>:... 파래가루는 야키소바에끼치기나 츠입니다없는?<br>
$icon$name:아니요, 그대로 판매하는 중입니다.<br>
$people<SPAN>손님</SPAN>:... 맛있어 보이네요. 그럼 그걸 주세요.<br>
$icon$name:여기요.<br>
$people<SPAN>손님</SPAN>:우물우물.<br>
$icon$name:... 아.<br>
$people<SPAN>손님</SPAN>:응?무엇일까요?<br>
$icon$name:... 이에 파래가루가 묻었어요.<br>
$people<SPAN>손님</SPAN>:....<br>
$icon$name:....<br>
$people<SPAN>손님</SPAN>:....<br>
$icon$name:... 푸푸.<br>
$people<SPAN>손님</SPAN>:... 웃었죠! 으악!<br><br>
파래가루가이에츠있었음그대로 라면카코나쁨이이므로 주의를붙할 수 있도록.<br>
($shopname 의 인기가 조금 떨어졌다합니다.)
STR
	$disp.="$TRE$TBE";
}

sub story4
{
	my $idx=$id2idx{$Q{class}};
	my $shopname="<SPAN>".$DT[$idx]->{shopname}."</SPAN>";
	my $name="<SPAN>".$DT[$idx]->{name}."</SPAN>";
	my $icon=GetTagImgKao($DT[$idx]->{name},$DT[$idx]->{icon});
	my $people=GetTagImgKao("미술부원","st4");

	$disp.=<<STR;
<TABLE cellpadding="26" width="570">$TR$TD
성적이 좀처럼 오르지 않던 $shopname 의 점주 $name 에게, 어느 날 이런 손님이 찾아왔습니다.<br><br>
$people<SPAN>미술부원</SPAN>: 안녕하세요. 잠깐 이야기 좀 해도 될까요?<br>
$icon$name: 네? 무슨 일이신가요?<br>
$people<SPAN>미술부원</SPAN>: 당신, 시험 성적이 썩 좋지는 않군요.<br>
$icon$name: 우... 가끔은 그럴 수도 있죠.<br>
$people<SPAN>미술부원</SPAN>: 잘하는 과목이 하나도 없다면 오히려 예술에 집중하는 편이 낫습니다.<br>
$icon$name: 그건 너무한 말씀 아닌가요?<br>
$people<SPAN>미술부원</SPAN>: 공부가 전부는 아닙니다. 중요한 것은 눈앞의 풍경을 마음으로 보는 힘입니다.<br>
$icon$name: 마음으로 보는 힘이요?<br>
$people<SPAN>미술부원</SPAN>: 그렇습니다. 석양을 보고 감동할 수 있는 사람이라면 이미 훌륭한 감성을 가진 겁니다.<br>
$icon$name: 그건 조금 알 것 같습니다.<br>
$people<SPAN>미술부원</SPAN>: 그러니 망설일 필요가 없습니다. 지금 바로 미술부에 들어오세요.<br>
$icon$name: 결론이 너무 빠른데요...<br><br>
미술부에 입부할 수 있게 되었습니다.<br>
STR
	$disp.="$TRE$TBE";
}

sub story5
{
	my $idx=$id2idx{$Q{class}};
	my $shopname="<SPAN>".$DT[$idx]->{shopname}."</SPAN>";
	my $name="<SPAN>".$DT[$idx]->{name}."</SPAN>";
	my $icon=GetTagImgKao($DT[$idx]->{name},$DT[$idx]->{icon});
	my $people=GetTagImgKao("다도부원","st5");

	$disp.=<<STR;
<TABLE cellpadding="26" width="570">$TR$TD
어느 날, $shopname 의 점주 $name 에게 이런 손님이 찾아왔습니다.<br><br>
$people<SPAN>다도부원</SPAN>: 실례합니다. 아이스를 하나 주시겠습니까?<br>
$icon$name: 어서 오십시오. 여기 있습니다.<br>
$people<SPAN>다도부원</SPAN>: 음... 달콤하군요. 하지만 단맛만으로는 부족합니다.<br>
$icon$name: 네? 문화축제 가게에서 그런 평가를 받게 될 줄은 몰랐네요.<br>
$people<SPAN>다도부원</SPAN>: 단맛도 필요하지만, 그것을 받쳐 줄 쌉싸름함도 필요합니다.<br>
$icon$name: 쌉싸름함이라면... 일본적인 맛 말씀인가요?<br>
$people<SPAN>다도부원</SPAN>: 그렇습니다. 전통을 이해하는 감각이 필요하지요.<br>
$icon$name: 그럼... 안미츠?<br>
$people<SPAN>다도부원</SPAN>: 더 달아지면 어쩌자는 겁니까.<br>
$icon$name: 음... 그럼 녹차?<br>
$people<SPAN>다도부원</SPAN>: 이제야 조금 통하는군요. 다도부에 들어오세요.<br><br>
다도부에 입부할 수 있게 되었습니다.<br>
STR
	$disp.="$TRE$TBE";
}

sub story6
{
	my $idx=$id2idx{$Q{class}};
	my $shopname="<SPAN>".$DT[$idx]->{shopname}."</SPAN>";
	my $name="<SPAN>".$DT[$idx]->{name}."</SPAN>";
	my $icon=GetTagImgKao($DT[$idx]->{name},$DT[$idx]->{icon});
	my $people=GetTagImgKao("화도부원","st6");

	$disp.=<<STR;
<TABLE cellpadding="26" width="570">$TR$TD
어느 날, $shopname 의 점주 $name 에게 이런 손님이 찾아왔습니다.<br><br>
$people<SPAN>화도부원</SPAN>: 실례합니다.<br>
$icon$name: 어서 오십시오. 찾으시는 물건이 있으신가요?<br>
$people<SPAN>화도부원</SPAN>: 물건을 사러 온 것은 아닙니다.<br>
$icon$name: 그렇다면 다른 볼일이 있으신가요?<br>
$people<SPAN>화도부원</SPAN>: 꽃꽂이에는 지식과 감각이 모두 필요합니다. 예를 들어, 캐스케이드가 무슨 뜻인지 아십니까?<br>
$icon$name: Cascade... 폭포라는 뜻 아닌가요?<br>
$people<SPAN>화도부원</SPAN>: 정답입니다. 폭포처럼 흐르는 형태로 꽃을 배치하는 기법이죠.<br>
$icon$name: 이름 그대로군요.<br>
$people<SPAN>화도부원</SPAN>: 용어의 의미를 알면 꽃꽂이의 아름다움도 더 분명하게 보입니다.<br>
$icon$name: 그렇게 들으니 이해가 됩니다.<br>
$people<SPAN>화도부원</SPAN>: 그러니 그 감각을 꽃꽂이부에서 살려 주세요.<br>
$icon$name: 결국 권유였군요.<br><br>
꽃꽂이부에 입부할 수 있게 되었습니다.<br>
STR
	$disp.="$TRE$TBE";
}

sub story7
{
	my $idx=$id2idx{$Q{class}};
	my $shopname="<SPAN>".$DT[$idx]->{shopname}."</SPAN>";
	my $name="<SPAN>".$DT[$idx]->{name}."</SPAN>";
	my $icon=GetTagImgKao($DT[$idx]->{name},$DT[$idx]->{icon});
	my $people=GetTagImgKao("화학부원","st7");

	$disp.=<<STR;
<TABLE cellpadding="26" width="570">$TR$TD
어느 날, $shopname 의 점주 $name 에게 이런 손님이 찾아왔습니다.<br><br>
$people<SPAN>화학부원</SPAN>: 이번에는 이것들을 섞어 봐도 될까요?<br>
$icon$name: 어서 오십시오. 무엇을 찾으십니까?<br>
$people<SPAN>화학부원</SPAN>: 여기 있는 물건을 전부 섞으면 뭔가 새로 생기지 않을까요?<br>
$icon$name: 돈을 내고 하신다면... 아니, 그래도 위험합니다.<br>
$people<SPAN>화학부원</SPAN>: 실험해 보지 않으면 모르는 법입니다.<br>
$icon$name: 그래도 아무거나 섞으면 곤란하죠.<br>
$people<SPAN>화학부원</SPAN>: 맞습니다. 좋은 실험에는 치밀한 계산이 필요합니다.<br>
$icon$name: 계산이라면 어느 정도는 합니다.<br>
$people<SPAN>화학부원</SPAN>: 그럼 질문입니다. 코사인 제곱과 사인 제곱을 더하면?<br>
$icon$name: 1입니다.<br>
$people<SPAN>화학부원</SPAN>: 좋습니다. 그 정도면 기본은 충분하군요.<br>
$icon$name: 갑자기 안심하시는군요.<br>
$people<SPAN>화학부원</SPAN>: 실험은 감으로만 하는 것이 아닙니다. 계산과 관찰이 모두 필요합니다.<br>
$icon$name: 그 말은 맞네요.<br>
$people<SPAN>화학부원</SPAN>: 좋아요. 화학부에 들어와서 제대로 실험해 봅시다.<br><br>
화학부에 입부할 수 있게 되었습니다.<br>
STR
	$disp.="$TRE$TBE";
}

sub story8
{
	my $idx=$id2idx{$Q{class}};
	my $shopname="<SPAN>".$DT[$idx]->{shopname}."</SPAN>";
	my $name="<SPAN>".$DT[$idx]->{name}."</SPAN>";
	my $icon=GetTagImgKao($DT[$idx]->{name},$DT[$idx]->{icon});
	my $people=GetTagImgKao("컴퓨터부원","st8");

	$disp.=<<STR;
<TABLE cellpadding="26" width="570">$TR$TD
어느 날, $shopname 의 점주 $name 에게 이런 손님이 찾아왔습니다.<br><br>
$people<SPAN>컴퓨터부원</SPAN>: 안녕하세요.<br>
$icon$name: 어서 오십시오. 무엇을 찾으십니까?<br>
$people<SPAN>컴퓨터부원</SPAN>: 재미있는 문화 콘텐츠를 찾고 있습니다.<br>
$icon$name: 그런 물건은 취급하지 않습니다.<br>
$people<SPAN>컴퓨터부원</SPAN>: 없다면 직접 만들면 됩니다.<br>
$icon$name: 직접 만든다고요?<br>
$people<SPAN>컴퓨터부원</SPAN>: 그래서 컴퓨터부가 필요한 겁니다. 데이터를 읽고, 처리하고, 결과를 보여 주는 힘 말입니다.<br>
$icon$name: 예를 들면요?<br>
$people<SPAN>컴퓨터부원</SPAN>: DataRead는 데이터를 읽어 오는 함수입니다.<br>
$icon$name: 그 정도는 알겠습니다.<br>
$people<SPAN>컴퓨터부원</SPAN>: OutSkin은 화면을 출력하고, PushLog는 로그를 남깁니다.<br>
$icon$name: 설명을 들으니 이해가 되네요.<br>
$people<SPAN>컴퓨터부원</SPAN>: 좋습니다. 지금부터 컴퓨터부에서 같이 만들어 봅시다.<br>
$icon$name: 조금 갑작스럽지만요.<br><br>
컴퓨터부에 입부할 수 있게 되었습니다.<br>
STR
	$disp.="$TRE$TBE";
}

sub story9
{
	my $idx=$id2idx{$Q{class}};
	my $shopname="<SPAN>".$DT[$idx]->{shopname}."</SPAN>";
	my $name="<SPAN>".$DT[$idx]->{name}."</SPAN>";
	my $icon=GetTagImgKao($DT[$idx]->{name},$DT[$idx]->{icon});
	my $people=GetTagImgKao("마술부원","st9");

	$disp.=<<STR;
<TABLE cellpadding="26" width="570">$TR$TD
어느 날, $shopname 의 점주 $name 에게 이런 손님이 찾아왔습니다.<br><br>
$people<SPAN>마술부원</SPAN>: 타코야키 하나 만들어 주시겠습니까?<br>
$icon$name: 네, 잠시만 기다려 주세요.<br>
$people<SPAN>마술부원</SPAN>: ....<br>
$icon$name: 자, 여기 있습니다.<br>
$people<SPAN>마술부원</SPAN>: 훌륭합니다. 손놀림이 꽤 좋군요.<br>
$icon$name: 타코야키를 뒤집는 정도입니다만.<br>
$people<SPAN>마술부원</SPAN>: 바로 그 손놀림이 중요합니다. 카드를 뒤집는 기술에도 통하죠.<br>
$icon$name: 마술 이야기였군요.<br>
$people<SPAN>마술부원</SPAN>: 필요한 것은 손재주와 사전 계산입니다.<br>
$icon$name: 계산이라면 자신 있습니다.<br>
$people<SPAN>마술부원</SPAN>: 좋습니다. 그럼 마술부에 들어오세요.<br>
$icon$name: 이번 권유는 생각보다 차분하네요.<br>
$people<SPAN>마술부원</SPAN>: 제작자도 가끔은 자연스러운 이벤트를 만들고 싶어 하는 법입니다.<br>
$icon$name: 그런데 타코야키 값은요?<br><br>
마술부에 입부할 수 있게 되었습니다.<br>
STR
	$disp.="$TRE$TBE";
}

sub story10
{
	my $idx=$id2idx{$Q{class}};
	my $shopname="<SPAN>".$DT[$idx]->{shopname}."</SPAN>";
	my $name="<SPAN>".$DT[$idx]->{name}."</SPAN>";
	my $icon=GetTagImgKao($DT[$idx]->{name},$DT[$idx]->{icon});
	my $people=GetTagImgKao("연극부원","st10");

	$disp.=<<STR;
<TABLE cellpadding="26" width="570">$TR$TD
어느 날, $shopname 의 점주 $name 에게 이런 손님이 찾아왔습니다.<br><br>
$people<SPAN>연극부원</SPAN>: 오호호호호.<br>
$icon$name: 어서 오십시오... 무언가 분위기가 강렬하네요.<br>
$people<SPAN>연극부원</SPAN>: 이번 공연 포스터를 사 주시겠어요?<br>
$icon$name: 갑자기요?<br>
$people<SPAN>연극부원</SPAN>: 인기가 올라야 주연에 가까워질 수 있거든요.<br>
$icon$name: 아직 주연은 아니신가 보군요.<br>
$people<SPAN>연극부원</SPAN>: 지금은 조연이지만, 언젠가는 무대의 중심에 설 겁니다.<br>
$icon$name: 열정은 대단하시네요.<br>
$people<SPAN>연극부원</SPAN>: 그러니 당신도 연극부에 들어오세요.<br>
$icon$name: 저는 연극에 별 관심이 없는데요.<br>
$people<SPAN>연극부원</SPAN>: 관심은 무대에 오르면 생깁니다!<br>
$icon$name: 결국 그렇게 되는군요...<br><br>
연극부에 입부할 수 있게 되었습니다.<br>
STR
	$disp.="$TRE$TBE";
}

sub story11
{
	my $idx=$id2idx{$Q{class}};
	my $shopname="<SPAN>".$DT[$idx]->{shopname}."</SPAN>";
	my $name="<SPAN>".$DT[$idx]->{name}."</SPAN>";
	my $icon=GetTagImgKao($DT[$idx]->{name},$DT[$idx]->{icon});
	my $people=GetTagImgKao("고전부원","st11");

	$disp.=<<STR;
<TABLE cellpadding="26" width="570">$TR$TD
어느 날, $shopname 의 점주 $name 에게 이런 손님이 찾아왔습니다.<br><br>
$people<SPAN>고전부원</SPAN>: 실례합니다.<br>
$icon$name: 어서 오세... 으악!<br>
$people<SPAN>고전부원</SPAN>: 놀라셨나요? 귀신의 집 의상입니다.<br>
$icon$name: 그런 차림으로 오시면 누구나 놀랍니다.<br>
$people<SPAN>고전부원</SPAN>: 귀신의 집은 문화축제의 인기 행사입니다. 하지만 아무나 제대로 만들 수 있는 것은 아닙니다.<br>
$icon$name: 어떤 지식이 필요한가요?<br>
$people<SPAN>고전부원</SPAN>: 전통 괴담을 이해하려면 국어 지식이 필요하고, 서양 자료를 읽으려면 영어도 필요합니다.<br>
$icon$name: 국어와 영어라면 어느 정도 합니다.<br>
$people<SPAN>고전부원</SPAN>: 관객을 놀라게 할 동선과 타이밍을 계산하려면 수학도 필요합니다.<br>
$icon$name: 수학도 할 수 있습니다.<br>
$people<SPAN>고전부원</SPAN>: 그렇다면 충분합니다.<br>
$icon$name: 설마...<br><br>
고전부에 입부할 수 있게 되었습니다.<br>
STR
	$disp.="$TRE$TBE";
}

sub story12
{
	my $idx=$id2idx{$Q{class}};
	my $shopname="<SPAN>".$DT[$idx]->{shopname}."</SPAN>";
	my $name="<SPAN>".$DT[$idx]->{name}."</SPAN>";
	my $icon=GetTagImgKao($DT[$idx]->{name},$DT[$idx]->{icon});
	my $people=GetTagImgKao("실행위원","st12");

	$disp.=<<STR;
<TABLE cellpadding="26" width="570">$TR$TD
어느 날, $shopname 의 점주 $name 에게 이런 손님이 찾아왔습니다.<br><br>
$people<SPAN>실행위원</SPAN>: 실행위원회에서 왔습니다! 전원 정렬!<br>
$icon$name: 네? 갑자기요?<br>
$people<SPAN>실행위원</SPAN>: 예의를 갖추십시오!<br>
$icon$name: 아, 네.<br>
$people<SPAN>실행위원</SPAN>: 당신을 실행위원회 후보로 소환합니다.<br>
$icon$name: 후보요?<br>
$people<SPAN>실행위원</SPAN>: 그전에 확인할 것이 있습니다. 우리 문화축제의 구호는 무엇입니까?<br>
$icon$name: 글쎄요... 친구, 노력, 승리?<br>
$people<SPAN>실행위원</SPAN>: 아닙니다. 우리가 추구하는 것은 기획력, 실행력, 책임감입니다.<br>
$icon$name: 그건 꽤 정상적인데요.<br>
$people<SPAN>실행위원</SPAN>: 그리고 마지막으로 필요한 것은 현장 대응력입니다.<br>
$icon$name: 결국 일손이 부족한 거군요.<br>
$people<SPAN>실행위원</SPAN>: 정확합니다. 실행위원회에 들어오십시오.<br><br>
실행위원회에 입부할 수 있게 되었습니다.<br>
STR
	$disp.="$TRE$TBE";
}

sub story
{
	OutError('현재의 상태에서는 이 명령을 실행할 수 없습니다');
}


