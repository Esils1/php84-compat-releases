#!/usr/bin/perl
# 캠퍼스 페스타판 아이템 데이터 2005/01/29 유래

# 이 파일은 아이템 데이터 정의 파일입니다.
# 원하는 대로 사용자 지정할 수 있습니다. 자세한 내용은 설명서를 보세요.

@@DEFINE
	version	05-02-17(CF)		#★상품 데이터 버전 표기
					# 마지막의 'CF'는 캠퍼스 페스타판용임을 표시합니다.
					# 전용 아이템을 넣어 나만의 상인 이야기를 만들 때는,
					# 이 기호를 바꿔 두면 됩니다.

	scale	개			#★기본 수량 단위
	type0	전체			# 전체 아이템 모음
	type1	음식
	type2	예술
	type3	연구
	type4	행사
	type5	인쇄
	type6	도구
	type7	시험

	job	art		미술부		#★직업 코드는 영어 소문자 10자 이내
	job	tea		다도부
	job	flower		꽃꽂이부
	job	chemist		화학부
	job	otakkie		컴퓨터부
	job	magic		마술부
	job	show		연극부
	job	obake		고전부
	job	boss		실행위원회

	MaxMoney	999999999	#★최대 자금

	set NewShopMoney	100000					# 초기 자금(@@FUNCNEW에서 사용)
	set NewShopTime		12*60*60				# 초기 보유 시간(초)(@@FUNCNEW에서 사용)
	set NewShopItem		진열대 증축/철거 키트:1			# 초기 보유 상품(@@FUNCNEW에서 사용) 서식 상품명:개수:상품명:개수:...

	TimeEditShowcase	10m		#★진열대 조작 시간
	TimeShopping		20m		#★매입 시간(구 SOLD OUT과의 호환성 확보용. 현재는 사용하지 않음)
	TimeSendItem		20m		#★아이템 매입/이동 시간(기본)
	TimeSendItemPlus	20s		#★아이템 매입/이동 시간(1개당 추가 시간)
	TimeSendMoney		20m		#★자금 이동 시간(기본)
	TimeSendMoneyPlus	100000		#★쓰레기 처리 시간 계산용 금액(이 금액마다 TimeSendMoney 시간 소비)

	CostShowcase1		0		#★진열대 1개 유지비
	CostShowcase2		2000	# 진열대 2개 유지비
	CostShowcase3		4000	# 진열대 3개 유지비
	CostShowcase4		8000	# 진열대 4개 유지비
	CostShowcase5		16000	# 진열대 5개 유지비
	CostShowcase6		32000	# 진열대 6개 유지비
	CostShowcase7		64000	# 진열대 7개 유지비
	CostShowcase8		128000	# 진열대 8개 유지비

	ItemUseTimeRate		0.5		#★아이템 사용 시 시간 계산 보정 배율(@USE 안의 time, exptime에 유효)


#------ 여기부터 아이템 정의 ---------------------------------


@@ITEM
	no		82
	type	도구
	code	gabyou
	name	흩뿌려진 압정
	info	고객이 가까이 오기 어려운 데다 값어치도 전혀 없음
	price	0
	cost	500
	limit	500/0
	pop	0
	plus	-1m
	flag	noshowcase|norequest

@@ITEM
	no		1
	type	음식
	code	ice
	name	아이스
	info	학교에서 인기 있는 디저트
	price	300
	base	1000/100000
	plus	2h
	limit	lv2
	pop	lv3
	point	lv4
	scale	개
@@ITEM
	no		2
	type	음식
	code	lemonade
	name	라무네
	info	학교에서 인기 있는 음료
	price	250
	base	1000/100000
	plus	2h
	limit	lv2
	pop	lv3
	point	lv4
	scale	본
@@ITEM
	no		3
	type	음식
	code	noodle
	name	중화면
	info	야키소바용 면
	price	240
	base	1000/100000
	plus	2h
	limit	lv1
	pop	lv1
	point	lv1
	scale	주머니
@@ITEM
	no		4
	type	음식
	code	yakisauce
	name	야키소바 소스
	info	야키소바의 맛을 내는 소스
	price	200
	base	1000/100000
	plus	2h
	limit	lv1
	pop	lv1
	point	lv1
	scale	주머니
@@ITEM
	no		5
	type	음식
	code	kyabe
	name	양배추
	info	식감이 중요한 식재료입니다
	price	300
	base	1000/100000
	plus	2h
	limit	lv1
	pop	lv1
	point	lv1
	scale	구슬
@@ITEM
	no		6
	type	음식
	code	aonori
	name	파래가루
	info	풍미를 더하는 데 사용
	price	300
	base	1000/100000
	plus	2h
	limit	lv1
	pop	lv1
	point	lv1
	scale	매
@@ITEM
	no		7
	type	음식
	code	tako
	name	문어
	info	씹는 맛이 좋은 식재료
	price	900
	base	1000/100000
	plus	2h
	limit	lv1
	pop	lv1
	point	lv1
	scale	매
	scale	kg
@@ITEM
	no		8
	type	음식
	code	egg
	name	알
	info	맛에 윤기가 더해집니다
	price	500
	base	1000/100000
	plus	2h
	limit	lv1
	pop	lv1
	point	lv1
	scale	팩
@@ITEM
	no		9
	type	음식
	code	takonomoto
	name	타코야키 가루
	info	타코야키 반죽 재료
	price	200
	base	1000/100000
	plus	2h
	limit	lv1
	pop	lv1
	point	lv1
	scale	주머니
@@ITEM
	no		10
	type	음식
	code	takosauce
	name	타코야키 소스
	info	타코야키에 뿌리는 소스
	price	200
	base	1000/100000
	plus	2h
	limit	lv1
	pop	lv1
	point	lv1
	scale	본

@@ITEM
	no		11
	type	음식
	code	yakisoba
	name	야키소바
	info	축제의 대표 인기 메뉴입니다
	price	500
	plus	-1h
	pop	lv4
	point	lv4
	scale	팩
@@ITEM
	no		12
	type	음식
	code	takoyaki
	name	타코야키
	info	축제의 대표 인기 메뉴입니다
	price	500
	plus	-1h
	pop	lv4
	point	lv4
	scale	팩
@@ITEM
	no		13
	type	음식
	code	eggfire
	name	계란구이
	info	의외로 잘 팔릴지도 모릅니다.
	price	300
	plus	-1h
	pop	lv3
	point	lv2
	scale	팩
@@ITEM
	no		14
	type	음식
	code	yakikyabe
	name	구운 양배추
	info	이런 것도 팔릴까요?
	price	400
	plus	-1h
	pop	lv2
	point	lv1
	scale	구슬

@@ITEM
	no		15
	type	도구
	code	cooktable
	name	조리대
	info	야키소바를 만들 수 있습니다
	price	0
	cost	500
	limit	1
	plus	-1h
	flag	noshowcase|norequest
	scale	대
	@@use
		time	1h
		exp		2%
		exptime	20m
		job	실행위원회	times/1.5
		scale	회
		action	조리하기
		name	야키소바를 조리하기
		info	야키소바를 만듭니다
		okmsg	야키소바를 만들었습니다
		ngmsg	조리에 실패했습니다...
			use		5	중화면
			use		3	야키소바 소스
			use		1	양배추
			use		1	파래가루
			get		48	야키소바	80%
	@@use
		time	1h
		exp		2%
		exptime	20m
		scale	회
		action	조리하기
		name	계란을 구워 보기
		info	알을 구워 봅니다
		okmsg	계란구이가 완성되었습니다
		ngmsg	조리에 실패했습니다...
			use		4	알
			get		40	계란구이	80%
	@@use
		time	1h
		exp		2%
		exptime	20m
		scale	회
		action	조리하기
		name	양배추를 구워 보기
		info	양배추를 구워 봅니다
		okmsg	구운 양배추가 완성되었습니다
		ngmsg	조리에 실패했습니다...
			use		6	양배추
			get		30	구운 양배추	80%

@@ITEM
	no		16
	type	도구
	code	cooktako
	name	타코야키 기구
	info	타코야키를 만들 수 있습니다
	price	0
	cost	500
	limit	1
	plus	-1h
	flag	noshowcase|norequest
	scale	대
	@@use
		time	1h
		exp		2%
		exptime	20m
		job	실행위원회	times/1.5
		scale	회
		action	조리하기
		name	타코야키를 조리하기
		info	타코야키를 만듭니다
		okmsg	타코야키를 만들었습니다
		ngmsg	조리에 실패했습니다...
			use		1	문어
			use		1	알
			use		1	타코야키 가루
			use		1	타코야키 소스
			use		1	양배추
			use		1	파래가루
			get		48	타코야키	80%
	@@use
		time	1h
		exp		2%
		exptime	20m
		scale	회
		action	조리하기
		name	계란을 구워 보기
		info	알을 구워 봅니다
		okmsg	계란구이가 완성되었습니다
		ngmsg	조리에 실패했습니다...
			use		4	알
			get		40	계란구이	80%
	@@use
		time	1h
		exp		2%
		exptime	20m
		scale	회
		action	조리하기
		name	양배추를 구워 보기
		info	양배추를 구워 봅니다
		okmsg	구운 양배추가 완성되었습니다
		ngmsg	조리에 실패했습니다...
			use		6	양배추
			get		30	구운 양배추	80%

@@ITEM
	no		24
	type	예술
	code	posca
	name	그림엽서
	info	그림이 그려진 엽서
	price	1000
	plus	-1h
	pop	lv4
	point	lv7
	scale	매
@@ITEM
	no		25
	type	예술
	code	copyart
	name	모사화
	info	연습 삼아 따라 그려 보았습니다
	price	3000
	plus	-1h
	pop	lv5
	point	lv6
	scale	매
@@ITEM
	no		26
	type	예술
	code	kokucho
	name	조각상
	info	입체적인 예술 작품
	price	8000
	plus	-1h
	pop	lv6
	point	lv5
	scale	체
@@ITEM
	no		27
	type	예술
	code	superart
	name	아름다운 그림
	info	미술부 최고의 작품입니다
	price	50000
	plus	-1h
	pop	lv7
	point	lv4
	scale	매
@@ITEM
	no		28
	type	도구
	code	toolart
	name	미술 도구 세트
	info	그림 도구 등이 들어 있습니다
	price	0
	cost	500
	limit	1
	plus	-1h
	flag	noshowcase|norequest
	scale	설정
	@@use
		time	2h
		exp		1%
		exptime	30m
		job	미술부	times/1.5
		scale	회
		action	정리하기
		name	동아리방 정리하기
		info	여러 재료가 나올 수 있습니다
		okmsg	사용할 수 있는 재료가 표시되었습니다
		ngmsg	아무것도 찾을 수 없었습니다…
			get		18	화이트 카드	70%
			get		11	캔버스	70%
			get		3	석고		50%
			get		1	수상한 잡지	50%
	@@use
		time	30m
		exp		1%
		exptime	10m
		job	미술부	times/1.5
		scale	회
		action	그리기
		name	그림엽서를 그리기
		info	엽서에 그림을 그립니다
		okmsg	그림엽서를 만들었습니다
		ngmsg	제작에 실패했습니다…
			use		12	화이트 카드
			get		12	그림엽서	80%
	@@use
		time	1h
		exp		2%
		exptime	20m
		job	미술부	times/1.5
		scale	회
		action	그리기
		name	모사화을 그리기
		info	유명한 그림을 따라 그려 봅니다
		okmsg	모사화을 만들었습니다
		ngmsg	제작에 실패했습니다…
			needexp		20%
			use		8	캔버스
			get		8	모사화	80%
	@@use
		time	1h
		exp		2%
		exptime	20m
		job	미술부	times/1.5
		scale	회
		action	그리기
		name	조각상 만들기
		info	입체적인 예술 작품에 도전합니다
		okmsg	조각상을 만들었습니다
		ngmsg	제작에 실패했습니다…
			needexp		40%
			use		3	석고
			get		3	조각상	80%
	@@use
		time	1h
		exp		2%
		exptime	20m
		job	미술부	times/1.5
		scale	회
		action	그리기
		name	자신만의 그림 그리기
		info	새로운 예술 작품에 도전합니다
		okmsg	아름다운 그림을 만들었습니다
		ngmsg	제작에 실패했습니다…
			needexp		60%
			use		6	캔버스
			use		1	수상한 잡지
			get		1	아름다운 그림	50%

@@ITEM
	no		29
	type	도구
	code	whitecard
	name	화이트 카드
	info	아무것도 그려져 있지 않은 카드
	price	100
	plus	-1h
	pop	10d
	point	10%
	scale	매
@@ITEM
	no		30
	type	도구
	code	canvas
	name	캔버스
	info	아무것도 그려져 있지 않은 캔버스
	price	300
	plus	-1h
	pop	10d
	point	10%
	scale	매
@@ITEM
	no		31
	type	도구
	code	artstone
	name	석고
	info	굳히거나 조각할 때 사용합니다
	price	800
	plus	-1h
	pop	10d
	point	10%
	scale	개
@@ITEM
	no		32
	type	도구
	code	magazine
	name	수상한 잡지
	info	상상력을 자극한다고 합니다
	price	300
	plus	-1h
	pop	10d
	point	10%
	scale	책

@@ITEM
	no		33
	type	예술
	code	ujicha
	name	우지차
	info	연습용으로 우린 차
	price	500
	plus	-1h
	pop	lv4
	point	lv7
	scale	복장
@@ITEM
	no		34
	type	예술
	code	youkan
	name	찻과자
	info	차와 함께 내기 좋은 과자
	price	1500
	plus	-1h
	pop	lv5
	point	lv6
	scale	개
@@ITEM
	no		35
	type	예술
	code	chagama
	name	차솥
	info	차인임을 증명하는 도구
	price	4000
	plus	-1h
	pop	lv6
	point	lv5
	scale	체
@@ITEM
	no		36
	type	예술
	code	supertea
	name	와비사비의 찻그릇
	info	다도부 최고의 작품입니다
	price	25000
	plus	-1h
	pop	lv7
	point	lv4
	scale	매
@@ITEM
	no		37
	type	도구
	code	tooltea
	name	다도 도구 세트
	info	차를 내리는 데 필요한 도구 세트
	price	0
	cost	500
	limit	1
	plus	-1h
	flag	noshowcase|norequest
	scale	설정
	@@use
		time	2h
		exp		1%
		exptime	30m
		job	다도부	times/1.5
		scale	회
		action	정리하기
		name	동아리방 정리하기
		info	여러 재료가 나올 수 있습니다
		okmsg	사용할 수 있는 재료가 표시되었습니다
		ngmsg	아무것도 찾을 수 없었습니다…
			get		18	찻잎		70%
			get		10	먹다 남은 찻과자	70%
			get		3	점토		50%
			get		1	먼지		40%
	@@use
		time	30m
		exp		1%
		exptime	10m
		job	다도부	times/1.5
		scale	회
		action	잠김됨
		name	차 우리기
		info	먼저 한 잔을 올립니다
		okmsg	오차를 잠김되었습니다
		ngmsg	제작에 실패했습니다…
			use		12	찻잎
			get		24	우지차	80%
	@@use
		time	1h
		exp		2%
		exptime	20m
		job	다도부	times/1.5
		scale	회
		action	만들기
		name	찻과자 만들기
		info	남은 재료를 활용해 만듭니다
		okmsg	찻과자를 만들었습니다
		ngmsg	제작에 실패했습니다…
			needexp		20%
			use		8	먹다 남은 찻과자
			get		16	찻과자	80%
	@@use
		time	1h
		exp		2%
		exptime	20m
		job	다도부	times/1.5
		scale	회
		action	굽기
		name	차솥 굽기
		info	차솥 제작에 도전합니다
		okmsg	차솥을 만들었습니다
		ngmsg	제작에 실패했습니다…
			needexp		40%
			use		3	점토
			get		6	차솥	80%
	@@use
		time	1h
		exp		2%
		exptime	20m
		job	다도부	times/1.5
		scale	회
		action	굽기
		name	자신만의 찻그릇 굽기
		info	새로운 경지에 도전합니다
		okmsg	와비사비의 찻그릇을 만들었습니다
		ngmsg	제작에 실패했습니다…
			needexp		60%
			use		6	점토
			use		1	먼지
			get		1	와비사비의 찻그릇	50%

@@ITEM
	no		38
	type	도구
	code	chaba
	name	찻잎
	info	차를 우리는 잎
	price	100
	plus	-1h
	pop	10d
	point	10%
	scale	잔
@@ITEM
	no		39
	type	도구
	code	kashikuzu
	name	먹다 남은 찻과자
	info	재활용할 수 있을 지도 모릅니다
	price	300
	plus	-1h
	pop	10d
	point	10%
	scale	개
@@ITEM
	no		40
	type	도구
	code	nendo
	name	점토
	info	차 도구를 만드는 원료
	price	800
	plus	-1h
	pop	10d
	point	10%
	scale	개
@@ITEM
	no		41
	type	도구
	code	dust
	name	먼지
	info	쓰레기 같지만 쓰레기가 아닐지도 모릅니다
	price	300
	plus	-1h
	pop	10d
	point	10%
	scale	개

@@ITEM
	no		42
	type	예술
	code	bouquet
	name	꽃다발
	info	기본적인 꽃다발
	price	1000
	plus	-1h
	pop	lv4
	point	lv7
	scale	매
@@ITEM
	no		43
	type	예술
	code	prest
	name	압화
	info	눌러 말린 꽃입니다
	price	1500
	plus	-1h
	pop	lv5
	point	lv6
	scale	매
@@ITEM
	no		44
	type	예술
	code	dry
	name	드라이플라워
	info	건조 가공한 꽃입니다
	price	8000
	plus	-1h
	pop	lv6
	point	lv5
	scale	체
@@ITEM
	no		45
	type	예술
	code	superflower
	name	응용 꽃꽂이 작품
	info	꽃꽂이부 최고의 작품입니다
	price	50000
	plus	-1h
	pop	lv7
	point	lv4
	scale	묶음
@@ITEM
	no		46
	type	도구
	code	toolflower
	name	꽃꽂이 도구 세트
	info	꽃가위 등 꽃꽂이에 필요한 도구 세트입니다
	price	0
	cost	500
	limit	1
	plus	-1h
	flag	noshowcase|norequest
	scale	설정
	@@use
		time	2h
		exp		1%
		exptime	30m
		job	꽃꽂이부	times/1.5
		scale	회
		action	정리하기
		name	동아리방 정리하기
		info	여러 재료가 나올 수 있습니다
		okmsg	사용할 수 있는 재료가 표시되었습니다
		ngmsg	아무것도 찾을 수 없었습니다…
			get		45	꽃		70%
			get		3	액자		70%
			get		3	화병		52%
			get		3	색 테이프	70%
	@@use
		time	30m
		exp		1%
		exptime	10m
		job	꽃꽂이부	times/1.5
		scale	회
		action	만들기
		name	꽃다발 만들기
		info	꽃을 모아 꽃다발을 만듭니다
		okmsg	꽃다발를 만들었습니다
		ngmsg	제작에 실패했습니다…
			use		12	꽃
			get		12	꽃다발	80%
	@@use
		time	1h
		exp		2%
		exptime	20m
		job	꽃꽂이부	times/1.5
		scale	회
		action	만들기
		name	압화 만들기
		info	꽃을 눌러 말려 액자에 장식합니다
		okmsg	압화를 만들었습니다
		ngmsg	제작에 실패했습니다…
			needexp		20%
			use		12	꽃
			use		4	액자
			get		16	압화	80%
	@@use
		time	1h
		exp		2%
		exptime	20m
		job	꽃꽂이부	times/1.5
		scale	회
		action	만들기
		name	드라이플라워 만들기
		info	꽃을 말려 오래 보관할 수 있게 만듭니다
		okmsg	드라이플라워를 만들었습니다
		ngmsg	제작에 실패했습니다…
			needexp		40%
			use		12	꽃
			use		3	화병
			get		3	드라이플라워	80%
	@@use
		time	1h
		exp		2%
		exptime	20m
		job	꽃꽂이부	times/1.5
		scale	회
		action	만들기
		name	나만의 꽃꽂이 작품 만들기
		info	새로운 예술 작품에 도전합니다
		okmsg	응용 꽃꽂이 작품을 만들었습니다
		ngmsg	제작에 실패했습니다…
			needexp		60%
			use		12	꽃
			use		4	색 테이프
			get		1	응용 꽃꽂이 작품	50%

@@ITEM
	no		47
	type	도구
	code	flower
	name	꽃
	info	동아리방에서 찾은 아직 싱싱한 꽃입니다
	price	100
	plus	-1h
	pop	10d
	point	10%
	scale	륜
@@ITEM
	no		48
	type	도구
	code	gaku
	name	액자
	info	압화를 장식하는 액자입니다
	price	300
	plus	-1h
	pop	10d
	point	10%
	scale	매
@@ITEM
	no		49
	type	도구
	code	flwerglass
	name	화병
	info	꽃을 꽂아 보관하는 화병입니다
	price	400
	plus	-1h
	pop	10d
	point	10%
	scale	개
@@ITEM
	no		50
	type	도구
	code	colortape
	name	색 테이프
	info	부족한 부분을 얼버무리는 데 씁니다
	price	300
	plus	-1h
	pop	10d
	point	10%
	scale	개


@@ITEM
	no		51
	type	연구
	code	shoppai
	name	염화나트륨
	info	한마디로 소금입니다
	price	1000
	plus	-1h
	pop	lv4
	point	lv7
	scale	kg
@@ITEM
	no		52
	type	연구
	code	goodwater
	name	알칼리 이온수
	info	몸에 좋다는 물입니다
	price	3000
	plus	-1h
	pop	lv5
	point	lv6
	scale	kl
@@ITEM
	no		53
	type	연구
	code	sakana
	name	도코사헥사엔산
	info	먹으면 머리가 좋아질 것 같은 성분입니다
	price	8000
	plus	-1h
	pop	lv6
	point	lv5
	scale	ml
@@ITEM
	no		54
	type	연구
	code	superche
	name	신비한 화합물
	info	화학부 최고의 작품입니다
	price	50000
	plus	-1h
	pop	lv7
	point	lv4
	scale	매
@@ITEM
	no		55
	type	도구
	code	toolche
	name	과학 실험 세트
	info	실험 도구 등 화학부에 필요한 준비물입니다
	price	0
	cost	500
	limit	1
	plus	-1h
	flag	noshowcase|norequest
	scale	설정
	@@use
		time	2h
		exp		1%
		exptime	30m
		job	화학부	times/1.5
		scale	회
		action	정리하기
		name	동아리방 정리하기
		info	여러 재료가 나올 수 있습니다
		okmsg	사용할 수 있는 재료가 표시되었습니다
		ngmsg	아무것도 찾을 수 없었습니다…
			get		11	구연산	70%
			get		18	규산나트륨	70%
			get		9	양동이에 담긴 물	70%
			get		3	빵가루	70%
			get		1	그 벌레	50%
	@@use
		time	30m
		exp		1%
		exptime	10m
		job	화학부	times/1.5
		scale	회
		action	화합하기
		name	염화나트륨을 화합하기
		info	화학 반응으로 염화나트륨을 만듭니다
		okmsg	염화나트륨을 만들었습니다
		ngmsg	제작에 실패했습니다…
			use		6	구연산
			use		6	규산나트륨
			get		12	염화나트륨	80%
	@@use
		time	1h
		exp		2%
		exptime	20m
		job	화학부	times/1.5
		scale	회
		action	화합하기
		name	알칼리 이온수를 화합하기
		info	화학 반응으로 알칼리 이온수를 만듭니다
		okmsg	알칼리 이온수를 만들었습니다
		ngmsg	제작에 실패했습니다…
			needexp		20%
			use		12	규산나트륨
			use		4	양동이에 담긴 물
			get		8	알칼리 이온수	80%
	@@use
		time	1h
		exp		2%
		exptime	20m
		job	화학부	times/1.5
		scale	회
		action	화합하기
		name	도코사헥사엔산을 화합하기
		info	화학 반응으로 도코사헥사엔산을 만듭니다
		okmsg	도코사헥사엔산을 만들었습니다
		ngmsg	제작에 실패했습니다…
			needexp		40%
			use		4	양동이에 담긴 물
			use		4	빵가루
			get		3	도코사헥사엔산	80%
	@@use
		time	1h
		exp		2%
		exptime	20m
		job	화학부	times/1.5
		scale	회
		action	화합하기
		name	나만의 화학 반응 실험하기
		info	새로운 화합물 제작에 도전합니다
		okmsg	신비한 화합물을 만들었습니다
		ngmsg	제작에 실패했습니다…
			needexp		60%
			use		6	구연산
			use		4	양동이에 담긴 물
			use		1	그 벌레
			get		1	신비한 화합물	50%

@@ITEM
	no		56
	type	도구
	code	noteat
	name	구연산
	info	약품 재료입니다. 먹을 수 없습니다
	price	100
	plus	-1h
	pop	10d
	point	10%
	scale	mg
@@ITEM
	no		57
	type	도구
	code	sna
	name	규산나트륨
	info	규산나트륨
	price	100
	plus	-1h
	pop	10d
	point	10%
	scale	mg
@@ITEM
	no		58
	type	도구
	code	washwater
	name	양동이에 담긴 물
	info	지난번 청소 때 미처 정리하지 못한 물입니다
	price	300
	plus	-1h
	pop	10d
	point	10%
	scale	kl
@@ITEM
	no		59
	type	도구
	code	breadtrash
	name	빵가루
	info	급식 때 남은 빵가루입니다
	price	300
	plus	-1h
	pop	10d
	point	10%
	scale	mg
@@ITEM
	no		60
	type	도구
	code	are
	name	그 벌레
	info	그 이름을 부르기 꺼려지는 벌레입니다
	price	300
	plus	-1h
	pop	10d
	point	10%
	scale	마리


@@ITEM
	no		61
	type	연구
	code	scsaver
	name	스크린 세이버
	info	기본적인 프로그램
	price	1000
	plus	-1h
	pop	lv4
	point	lv7
	scale	CPUs
@@ITEM
	no		62
	type	연구
	code	akihako
	name	상인 이야기
	info	완성된 CGI 게임
	price	3000
	plus	-1h
	pop	lv5
	point	lv6
	scale	CPUs
@@ITEM
	no		63
	type	연구
	code	virus
	name	바이러스 제작 지원 프로그램
	info	왠지 인기가 높은 프로그램입니다
	price	8000
	plus	-1h
	pop	lv6
	point	lv5
	scale	CPUs
@@ITEM
	no		64
	type	연구
	code	superota
	name	동인 게임
	info	컴퓨터부 최고의 작품입니다
	price	50000
	plus	-1h
	pop	lv7
	point	lv4
	scale	CPUs
@@ITEM
	no		65
	type	도구
	code	toolota
	name	노트북 PC
	info	컴퓨터 한 세트입니다
	price	0
	cost	500
	limit	1
	plus	-1h
	flag	noshowcase|norequest
	scale	설정
	@@use
		time	2h
		exp		1%
		exptime	30m
		job	컴퓨터부	times/1.5
		scale	회
		action	정리하기
		name	동아리방 정리하기
		info	여러 재료가 나올 수 있습니다
		okmsg	사용할 수 있는 재료가 표시되었습니다
		ngmsg	아무것도 찾을 수 없었습니다…
			get		18	양초	70%
			get		10	GPL	70%
			get		3	채찍		50%
			get		1	메이드형 인형	50%
	@@use
		time	30m
		exp		1%
		exptime	10m
		job	컴퓨터부	times/1.5
		scale	회
		action	개발하기
		name	스크린 세이버를 개발하기
		info	기본적인 프로그램을 만듭니다
		okmsg	스크린 세이버를 만들었습니다
		ngmsg	제작에 실패했습니다…
			use		12	양초
			get		12	스크린 세이버	80%
	@@use
		time	1h
		exp		2%
		exptime	20m
		job	컴퓨터부	times/1.5
		scale	회
		action	개발하기
		name	상인 이야기를 개발하기
		info	요즘 유행하는 Perl 프로그램을 만듭니다
		okmsg	상인 이야기를 만들었습니다
		ngmsg	제작에 실패했습니다…
			needexp		20%
			use		8	GPL
			get		8	상인 이야기	80%
	@@use
		time	1h
		exp		2%
		exptime	20m
		job	컴퓨터부	times/1.5
		scale	회
		action	개발하기
		name	바이러스 제작 지원 프로그램을 개발하기
		info	장난성 프로그램을 만들어 봅니다
		okmsg	바이러스 제작 지원 프로그램을 만들었습니다
		ngmsg	제작에 실패했습니다…
			needexp		40%
			use		3	채찍
			get		3	바이러스 제작 지원 프로그램	80%
	@@use
		time	1h
		exp		2%
		exptime	20m
		job	컴퓨터부	times/1.5
		scale	회
		action	개발하기
		name	자신만의 게임을 개발하기
		info	새로운 프로그램 개발에 도전합니다
		okmsg	동인 게임을 만들었습니다
		ngmsg	제작에 실패했습니다…
			needexp		60%
			use		6	GPL
			use		1	메이드형 인형
			get		1	동인 게임	50%

@@ITEM
	no		66
	type	도구
	code	joousama
	name	양초
	info	강한 자극을 주는 소품입니다
	price	100
	plus	-1h
	pop	10d
	point	10%
	scale	본
@@ITEM
	no		67
	type	도구
	code	gnugpl
	name	GPL
	info	라이선스 문서입니다
	price	300
	plus	-1h
	pop	10d
	point	10%
	scale	통
@@ITEM
	no		68
	type	도구
	code	odamari
	name	채찍
	info	강한 자극을 주는 소품입니다
	price	800
	plus	-1h
	pop	10d
	point	10%
	scale	본
@@ITEM
	no		69
	type	도구
	code	moemoe
	name	메이드형 인형
	info	상상력을 자극한다고 합니다
	price	300
	plus	-1h
	pop	10d
	point	10%
	scale	체


@@ITEM
	no		70
	type	행사
	code	ticketmagic
	name	마술 공연권
	info	마술 공연을 보기 위한 티켓
	price	5000
	plus	-1h
	pop	lv10
	point	lv-1
	scale	매
@@ITEM
	no		71
	type	도구
	code	toolmagic
	name	마술 소품
	info	마술 공연에 필요한 소품입니다
	price	0
	cost	500
	limit	1
	plus	-1h
	flag	noshowcase|norequest
	scale	설정
	@@use
		time	12h
		exp		10%
		arg	nocount|message20
		job	마술부	times/1.5
		scale	회
		action	공연을 기획하다
		name	새 마술 공연 기획하기
		info	마술 공연의 소재를 구상합니다
		func	newmagic
	@@use
		time	1h
		exp	0%
		exptime	20m
		job	마술부	times/1.5
		scale	회
		action	인쇄하기
		name	마술 공연권을 인쇄하기
		info	티켓을 만듭니다
		okmsg	마술 공연권을 만들었습니다
		ngmsg	인쇄에 실패했습니다…
		price	2400
		funcb	ptcheck
			get		8	마술 공연권	80%
	@@use
		time	8h
		exp		3%
		job	마술부	times/1.5
		scale	회
		action	개최하기
		name	마술 공연을 열기
		info	준비한 공연을 열 수 있습니다
		funcb	ptcheck
		func	showing

@@ITEM
	no		72
	type	행사
	code	ticketshow
	name	연극 공연권
	info	연극 공연을 보기 위한 티켓
	price	5000
	plus	-1h
	pop	lv10
	point	lv-1
	scale	매
@@ITEM
	no		73
	type	도구
	code	toolshow
	name	무대 세트
	info	연극에 필요한 소품이 가득합니다
	price	0
	cost	500
	limit	1
	plus	-1h
	flag	noshowcase|norequest
	scale	설정
	@@use
		time	12h
		exp		10%
		arg	nocount|message20
		job	연극부	times/1.5
		scale	회
		action	공연을 기획하다
		name	새 연극 각본 기획하기
		info	연극 공연의 스토리를 구상합니다
		func	newshow
	@@use
		time	1h
		exp	0%
		exptime	20m
		job	연극부	times/1.5
		scale	회
		action	인쇄하기
		name	연극 공연권을 인쇄하기
		info	티켓을 만듭니다
		okmsg	연극 공연권을 만들었습니다
		ngmsg	인쇄에 실패했습니다…
		price	2400
		funcb	ptcheck
			get		8	연극 공연권	80%
	@@use
		time	8h
		exp		3%
		job	연극부	times/1.5
		scale	회
		action	개최하기
		name	연극 공연을 열기
		info	준비한 공연을 열 수 있습니다
		funcb	ptcheck
		func	showing

@@ITEM
	no		74
	type	행사
	code	ticketobake
	name	귀신의 집 입장권
	info	귀신의 집에 입장하기 위한 티켓
	price	5000
	plus	-1h
	pop	lv10
	point	lv-1
	scale	매
@@ITEM
	no		75
	type	도구
	code	toolobake
	name	귀신 분장 소품
	info	이것을 사용해 사람들을 놀라게 합니다
	price	0
	cost	500
	limit	1
	plus	-1h
	flag	noshowcase|norequest
	scale	설정
	@@use
		time	12h
		exp		10%
		arg	nocount|message20
		job	고전부	times/1.5
		scale	회
		action	귀신의 집 운영하기
		name	새 귀신의 집 만들기
		info	귀신의 집 동선을 정합니다
		func	newobake
	@@use
		time	1h
		exp	0%
		exptime	20m
		job	고전부	times/1.5
		scale	회
		action	인쇄하기
		name	귀신의 집 입장권을 인쇄하기
		info	티켓을 만듭니다
		okmsg	귀신의 집 입장권을 만들었습니다
		ngmsg	인쇄에 실패했습니다…
		price	2400
		funcb	ptcheck
			get		8	귀신의 집 입장권	80%
	@@use
		time	8h
		exp		3%
		job	고전부	times/1.5
		scale	회
		action	개최하기
		name	귀신 특별 쇼를 열기
		info	귀신 춤 이벤트를 열 수 있습니다
		funcb	ptcheck
		func	obaking

@@ITEM
	no		76
	type	도구
	code	invitecard
	name	초대장
	info	이것을 가지고 있으면 행사에 참가할 수 있습니다
	price	0
	cost	500
	limit	3
	plus	-1h
	flag	noshowcase|norequest
	scale	매

@@ITEM
	no		77
	type	인쇄
	code	toiletticket
	name	화장실 이용권
	info	이것이 없으면 화장실에 들어갈 수 없습니다
	price	1000
	plus	-1h
	pop	lv3
	point	lv5
	scale	매
@@ITEM
	no		78
	type	인쇄
	code	parkticket
	name	주차장 이용권
	info	이것이 없으면 주차장을 사용할 수 없습니다
	price	3000
	plus	-1h
	pop	lv3
	point	lv4
	scale	매
@@ITEM
	no		79
	type	인쇄
	code	panf
	name	팸플릿
	info	문화축제를 둘러볼 때 도움이 됩니다
	price	8000
	plus	-1h
	pop	lv4
	point	lv4
	scale	책
@@ITEM
	no		80
	type	인쇄
	code	cm
	name	포스터
	info	붙이면 광고가 됩니다
	price	50000
	plus	-1h
	pop	lv4
	point	lv3
	scale	매
	@@use
		time	10h
		exp	10%
		job		실행위원회	times/1.5
		scale	회
		action	광고하기
		name	내 가게 광고
		info	내 가게의 인기를 올립니다
		arg		nocount
			use		1	포스터
		func	_local_
				my $up=int(500*(2-$DT->{rank}/5000));
				if ( rand(1000)<250 ) {
					$DT->{rank}-=$up;
					$DT->{rank}=1000 if $DT->{rank}<1000;
					my $ret="광고가 역효과를 냈습니다: 인기".int($up/100)."%다운";
					WriteLog(0,$DT->{id},$ret);
					WriteLog(3,0,$DT->{shopname}."가 광고를 냈지만 역효과가 났습니다.");
					return $ret;
				}
				$DT->{rank}+=$up;
				$DT->{rank}=10000 if $DT->{rank}>10000;
				my $ret="광고를 냈습니다: 인기".int($up/100)."% 상승";
				WriteLog(0,$DT->{id},$ret);
				WriteLog(3,0,$DT->{shopname}."가 광고를 냈습니다.");
				return $ret;
			_local_
	@@use
		time	10h
		exp	0%
		name	다른 점포 광고
		info	다른 점포의 인기를 올립니다
		arg		target|nocount
			use		1	포스터
		func	_local_
				return '내 가게는 지정할 수 없습니다' if ($DT==$DTS);
				my $up=int(500*(2-$DTS->{rank}/5000));
				$DTS->{rank}+=$up;
				$DTS->{rank}=10000 if $DTS->{rank}>10000;
				my $ret="광고를 냈습니다: ".$DTS->{shopname}."의 인기".int($up/100)."% 상승";
				WriteLog(0,$DT->{id},$ret);
				WriteLog(3,0,$DT->{shopname}."가".$DTS->{shopname}."의 광고를 냈습니다.");
				return $ret;
			_local_
	@@use
		time	16h
		exp	0%
		name	길드 광고
		info	같은 길드 소속 점포 전체의 인기를 올립니다
		arg		nocount
			use		1	포스터
		func	_local_
				return '길드에 가입되어 있지 않아 광고를 낼 수 없습니다' if !$DT->{guild};

				WriteLog(3,0,$DT->{shopname}."가 길드 '".$main::GUILD{$DT->{guild}}->[$GUILDIDX_name]."'의 광고를 냈습니다.");
				foreach my $DTS (@DT)
				{
				next if ($DTS->{guild} ne $DT->{guild});
				my $up=int(500*(2-$DTS->{rank}/5000));
				$DTS->{rank}+=$up;
				$DTS->{rank}=10000 if $DTS->{rank}>10000;
				my $ret="길드광고를 냈습니다: ".$DTS->{shopname}."의 인기".int($up/100)."% 상승";
				WriteLog(0,$DT->{id},$ret);
				}
				return '길드 광고를 냈습니다';
			_local_
@@ITEM
	no		81
	type	도구
	code	ghq
	name	운영본부
	info	모두의 힘이 이곳에 모입니다
	price	0
	cost	500
	limit	1
	plus	-1h
	flag	noshowcase|norequest
	scale	설정
	@@use
		time	30m
		exp		1%
		exptime	10m
		job	실행위원회	times/1.5
		scale	회
		action	인쇄하기
		name	화장실 이용권을 인쇄하기
		info	운영본부의 복사기로 인쇄합니다
		okmsg	화장실 이용권을 만들었습니다
		ngmsg	제작에 실패했습니다…
		price	1200
			get		12	화장실 이용권	80%
	@@use
		time	1h
		exp		2%
		exptime	20m
		scale	회
		action	인쇄하기
		name	주차장 이용권을 인쇄하기
		info	운영본부의 복사기로 인쇄합니다
		okmsg	주차장 이용권을 만들었습니다
		ngmsg	제작에 실패했습니다…
			needexp		20%
		price	2400
			get		8	주차장 이용권	80%
	@@use
		time	1h
		exp		2%
		exptime	20m
		scale	회
		action	인쇄하기
		name	팸플릿을 인쇄하기
		info	운영본부의 복사기로 인쇄합니다
		okmsg	팸플릿을 만들었습니다
		ngmsg	제작에 실패했습니다…
			needexp		40%
		price	2400
			get		3	팸플릿	80%
	@@use
		time	1h
		exp		2%
		exptime	20m
		scale	회
		action	인쇄하기
		name	포스터를 인쇄하기
		info	운영본부의 복사기로 인쇄합니다
		okmsg	포스터를 만들었습니다
		ngmsg	제작에 실패했습니다…
			needexp		60%
		price	2400
			get		1	포스터	50%

@@ITEM
	no		17
	type	도구
	code	edit-showcase
	name	진열대 증축/철거 키트
	info	진열대 증축이나 철거 등에 필요한 도구 세트입니다
	price	0
	limit	1/1
	pop	0
	plus	1d
	scale	키트
	flag	noshowcase|norequest
	@@use
		time	1h
		scale	회
		action	작업하기
		price	10000
		name	진열대를 1개로 줄이기
		info	진열대를 1개로 줄이기
		arg		nocount		#★사용 때의 선택선택지지정.
							# nocount -> 사용횟수선택없음
		param	1			#★전용함수용매개변수
			use	1	진열대 증축/철거 키트
		func	_local_
			# ★진열대수변경
			# param1 변경후의 선반수
			my $oldcnt=$DT->{showcasecount};
			my $newcnt=$USE->{param1};
			$DT->{showcasecount}=$newcnt;

			if($oldcnt<$newcnt)
			{
				foreach ($oldcnt..$newcnt-1)
				{
					$DT->{showcase}[$_]=0;
					$DT->{price}[$_]=0;
				}
			}
			if($oldcnt>$newcnt)
			{
				splice(@{$DT->{showcase}},$newcnt);
				splice(@{$DT->{price}},$newcnt);
			}
			my $ret="진열대를 ".$DT->{showcasecount}."개로 변경했습니다";
			WriteLog(0,$DT->{id},$ret);
			WriteLog(0,0,$DT->{shopname}."의 진열대 수가 ".$DT->{showcasecount}."개가 되었습니다.");

			return $ret;
		_local_
	@@use
		time	2h
		price	20000
		name	진열대를 2개로 만들기
		info	진열대를 2개로 만들기
		func	_local_1
		arg		nocount
		param	2
			use	1	진열대 증축/철거 키트
	@@use
		time	3h
		price	30000
		name	진열대를 3개로 만들기
		info	진열대를 3개로 만들기
		func	_local_1
		arg		nocount
		param	3
			use	1	진열대 증축/철거 키트
	@@use
		time	4h
		price	40000
		name	진열대를 4개로 만들기
		info	진열대를 4개로 만들기
		func	_local_1
		arg		nocount
		param	4
			use	1	진열대 증축/철거 키트
	@@use
		time	5h
		price	50000
		name	진열대를 5개로 만들기
		info	진열대를 5개로 만들기
		func	_local_1
		arg		nocount
		param	5
			use	1	진열대 증축/철거 키트
	@@use
		time	6h
		price	60000
		name	진열대를 6개로 만들기
		info	진열대를 6개로 만들기
		func	_local_1
		arg		nocount
		param	6
			use	1	진열대 증축/철거 키트
	@@use
		time	7h
		price	70000
		name	진열대를 7개로 만들기
		info	진열대를 7개로 만들기
		func	_local_1
		arg		nocount
		param	7
			use	1	진열대 증축/철거 키트
	@@use
		time	8h
		price	80000
		name	진열대를 8개로 만들기
		info	진열대를 8개로 만들기
		func	_local_1
		arg		nocount
		param	8
			use	1	진열대 증축/철거 키트

@@ITEM
	no		23
	type	인쇄
	code	comejoinus
	name	입부 신청서
	info	동아리에 가입하기 위한 신청서입니다
	price	1000
	limit	1/1
	pop	lv0.1
	point	lv0.1
	plus	1h
	scale	매
	flag	noshowcase
	@@USE
		time	6h
		action	입부하기
		scale	회
		arg		nocount
		name	미술부에 입부하기
		info	미술부에 가입합니다
		param	28,37:46:55:65:71:73:75:81,0.2,art
		funcb	jobcheck
			use		1	입부 신청서
		func	jobport
	@@USE
		time	6h
		action	입부하기
		scale	회
		arg		nocount
		name	다도부에 입부하기
		info	다도부에 가입합니다
		param	37,28:46:55:65:71:73:75:81,0.2,tea
		funcb	jobcheck
			use		1	입부 신청서
		func	jobport
	@@USE
		time	6h
		action	입부하기
		scale	회
		arg		nocount
		name	꽃꽂이부에 입부하기
		info	꽃꽂이부에 가입합니다
		param	46,28:37:55:65:71:73:75:81,0.2,flower
		funcb	jobcheck
			use		1	입부 신청서
		func	jobport
	@@USE
		time	6h
		action	입부하기
		scale	회
		arg		nocount
		name	화학부에 입부하기
		info	화학부에 가입합니다
		param	55,28:37:46:65:71:73:75:81,0.2,chemist
		funcb	jobcheck
			use		1	입부 신청서
		func	jobport
	@@USE
		time	6h
		action	입부하기
		scale	회
		arg		nocount
		name	컴퓨터부에 입부하기
		info	컴퓨터부에 가입합니다
		param	65,28:37:46:55:71:73:75:81,0.2,otakkie
		funcb	jobcheck
			use		1	입부 신청서
		func	jobport
	@@USE
		time	6h
		action	입부하기
		scale	회
		arg		nocount
		name	마술부에 입부하기
		info	마술부에 가입합니다
		param	71,28:37:46:55:65:73:75:81,0.2,magic
		funcb	jobcheck
			use		1	입부 신청서
		func	jobport
	@@USE
		time	6h
		action	입부하기
		scale	회
		arg		nocount
		name	연극부에 입부하기
		info	연극부에 가입합니다
		param	73,28:37:46:55:65:71:75:81,0.2,show
		funcb	jobcheck
			use		1	입부 신청서
		func	jobport
	@@USE
		time	6h
		action	입부하기
		scale	회
		arg		nocount
		name	고전부에 입부하기
		info	고전부에 가입합니다
		param	75,28:37:46:55:65:71:73:81,0.2,obake
		funcb	jobcheck
			use		1	입부 신청서
		func	jobport
	@@USE
		time	6h
		action	입부하기
		scale	회
		arg		nocount
		name	실행위원회에 입부하기
		info	실행위원회에 가입합니다
		param	81,28:37:46:55:65:71:73:75,0.2,boss
		funcb	jobcheck
			use		1	입부 신청서
		func	jobport


@@ITEM
	no		18
	type	도구
	code	defence-manbiki
	name	생활지도위원
	info	괴롭힘을 발견하면 선생님에게 신고합니다
	price	500000
	cost	5000
	limit	1/0.5
	pop	lv0.1
	point	lv0.1
	plus	30m
	scale	인
	flag	noshowcase|onlysend|human

@@ITEM
	no		19
	type	도구
	code	badgossip
	name	괴롭힘 설명서
	info	절대 따라 해서는 안 되는 장난 방법이 적혀 있습니다
	price	25000
	limit	1/0.5
	pop	lv0.1
	point	lv0.1
	plus	1h
	base	40/100
	scale	책
	@@use
		time	10h
		exp	20%
		exptime	8h
		job		실행위원회	times/1.5
		price	50000
		scale	회
		action	장난치기
		name	칠판 지우개 장난치기
		info	성공하면 상대 점포의 인기를 내리지만, 실패할 수도 있습니다...
		arg	target|nocount
			needpoint	20000
		func	_local_
			my $ret;
			if(rand(1000)<800 && !$DTS->{exp}{@@ITEMNO"포스터"})
			{
				$DTS->{rank}-=int($DTS->{rank}/3);
				$ret=$DTS->{shopname}.'에칠판 지우개 장난치기작전이성공했습니다';
				WriteLog(0,$DT->{id},$ret);
				WriteLog(2,0,$DTS->{shopname}.'에서 칠판 지우개가 고객의 머리 위로 떨어져 인기가 내려갔습니다.');
			}
			else
			{
				$DTS->{exp}{@@ITEMNO"포스터"}-=100;
				$DTS->{exp}{@@ITEMNO"포스터"}=0 if ($DTS->{exp}{@@ITEMNO"포스터"} < 0);
				$DT->{rank}-=int($DT->{rank}/4);
				$ret=$DTS->{shopname}.'에칠판 지우개 장난치기작전은 실패했습니다';
				WriteLog(0,$DT->{id},$ret);
				WriteLog(3,0,$DT->{shopname}."가".$DTS->{shopname}.'에칠판 지우개를 구조걸기해서있었던 것 같습니다.');
			}
			return $ret;
			_local_
	@@use
		time	10h
		exp	25%
		exptime	8h
		scale	회
		action	좀도둑질하기
		price	50000
		name	좀도둑질하기
		info	그렇게까지 몰렸다면 어쩔 수 없겠지만, 실패할 수도 있습니다…
		func	stole
		arg		target|nocount
			needpoint	20000
	@@use
		time	14h
		exp	20%
		exptime	12h
		price	50000
		scale	회
		action	장난치기
		name	압정 뿌리기
		info	다른 점포의 진열대에 압정을 뿌리고 옵니다
		func	fire
		arg	target|nocount
			needpoint	20000

@@ITEM
	no		20
	type	시험
	code	testeng
	name	영어
	info	영어의 시험성적
	price	0
	limit	100/0
	pop	0
	plus	-1h
	flag	noshowcase|norequest|notrash
	scale	점
	@@use
		time	2h
		exp		5%
		scale	회
		action	공부하기
		name	영어를 공부하기
		info	영어를 공부합니다
		func	study

@@ITEM
	no		21
	type	시험
	code	testmat
	name	수학
	info	수학의 시험성적
	price	0
	limit	100/0
	pop	0
	plus	-1h
	flag	noshowcase|norequest|notrash
	scale	점
	@@use
		time	2h
		exp		5%
		scale	회
		action	공부하기
		name	수학을 공부하기
		info	수학을 공부합니다
		func	study

@@ITEM
	no		22
	type	시험
	code	testtan
	name	국어
	info	국어의 시험성적
	price	0
	limit	100/0
	pop	0
	plus	-1h
	flag	noshowcase|norequest|notrash
	scale	점
	@@use
		time	2h
		exp		5%
		scale	회
		action	공부하기
		name	국어를 공부하기
		info	국어를 공부합니다
		func	study


# 아이스는 그대로 두면 녹아 버립니다이벤트
@@EVENT
	start		100%
	code		icejataranai
	info		아이스는 그대로 두면 녹아 버립니다
	startfunc	_local_
		foreach(@DT)
		{
			next if $_->{money}<100000;
			next if !$_->{item}[@@ITEMNO"아이스"-1];
			next if $_->{item}[@@ITEMNO"조리대"-1];
			my $flag;					#아이스진열 확인
			foreach my $idx (0..$_->{showcasecount}-1)
			{
			my $itemno=$_->{showcase}[$idx];
			$flag=1 if ($itemno==@@ITEMNO"아이스");
			}
			next if !$flag;

			$_->{money}-=50000;
			$_->{paytoday}+=50000;
			$_->{item}[@@ITEMNO"조리대"-1]++;
			return (0,$_->{shopname}.'에서 아이스 보관 문제 사건이 발생했습니다.?code'.$_->{id}.':1');
		}
		return 0;
	_local_

# 100% 문어입니다이벤트
@@EVENT
	start		100%
	code		takonandesu
	info		안에는 문어가 듬뿍 들어 있습니다
	startfunc	_local_
		foreach(@DT)
		{
			next if $_->{money}<100000;
			next if !$_->{item}[@@ITEMNO"타코"-1];
			next if $_->{item}[@@ITEMNO"타코야키 기구"-1];
			my $flag;					#타코진열 확인
			foreach my $idx (0..$_->{showcasecount}-1)
			{
			my $itemno=$_->{showcase}[$idx];
			$flag=1 if ($itemno==@@ITEMNO"타코");
			}
			next if !$flag;

			$_->{money}-=50000;
			$_->{paytoday}+=50000;
			$_->{item}[@@ITEMNO"타코야키 기구"-1]++;
			return (0,$_->{shopname}.'에서 100% 문어 사건이 발생했습니다.?code'.$_->{id}.':2');
		}
		return 0;
	_local_

# 파래가루가 눅눅해졌습니다이벤트
@@EVENT
	start		100%
	code		aonoride
	info		파래가루가 눅눅해졌습니다
	startfunc	_local_
		foreach(@DT)
		{
			next if !$_->{item}[@@ITEMNO"파래가루"-1];
			my $flag;					#파래가루진열 확인
			foreach my $idx (0..$_->{showcasecount}-1)
			{
			my $itemno=$_->{showcase}[$idx];
			$flag=1 if ($itemno==@@ITEMNO"파래가루");
			}
			next if !$flag;

			$_->{rank}-=int($_->{rank}/6);
			return (0,$_->{shopname}.'에서 파래가루 보관 문제 사건이 발생했습니다.?code'.$_->{id}.':3');
		}
		return 0;
	_local_

# 미술부 권유이벤트
@@EVENT
	start		100%
	code		artinvite
	info		미술부 권유
	startfunc	_local_
		foreach(reverse@DT)
		{
			next if ($_->{job} eq "art");
			next if ($_->{item}[@@ITEMNO"영어"-1] > 40);
			next if ($_->{item}[@@ITEMNO"수학"-1] > 40);
			next if ($_->{item}[@@ITEMNO"국어"-1] > 40);
			main::ReadDTSub($_,"data");
			next if ($_->{_data}->{club} =~ /art:/);
			$_->{_data}->{club}.="art:";
			main::WriteDTSub($_,"data");
			return (0,$_->{shopname}.'에서 미술부 권유 사건이 발생했습니다.?code'.$_->{id}.':4');
		}
		return 0;
	_local_

# 다도부 권유이벤트
@@EVENT
	start		100%
	code		teainvite
	info		다도부 권유
	startfunc	_local_
		foreach(reverse@DT)
		{
			next if ($_->{job} eq "tea");
			next if ($_->{item}[@@ITEMNO"국어"-1] < 80);
			next if !$_->{item}[@@ITEMNO"아이스"-1];
			my $flag;					#아이스진열 확인
			foreach my $idx (0..$_->{showcasecount}-1)
			{
			my $itemno=$_->{showcase}[$idx];
			$flag=1 if ($itemno==@@ITEMNO"아이스");
			}
			next if !$flag;
			main::ReadDTSub($_,"data");
			next if ($_->{_data}->{club} =~ /tea:/);
			$_->{_data}->{club}.="tea:";
			main::WriteDTSub($_,"data");
			return (0,$_->{shopname}.'에서 다도부 권유 사건이 발생했습니다.?code'.$_->{id}.':5');
		}
		return 0;
	_local_

# 꽃꽂이부 권유이벤트
@@EVENT
	start		100%
	code		flowerinvite
	info		꽃꽂이부 권유
	startfunc	_local_
		foreach(reverse@DT)
		{
			next if ($_->{job} eq "flower");
			next if ($_->{item}[@@ITEMNO"영어"-1] < 80);
			next if ($_->{item}[@@ITEMNO"수학"-1] > 40);
			main::ReadDTSub($_,"data");
			next if ($_->{_data}->{club} =~ /flower:/);
			$_->{_data}->{club}.="flower:";
			main::WriteDTSub($_,"data");
			return (0,$_->{shopname}.'에서 꽃꽂이부 권유 사건이 발생했습니다.?code'.$_->{id}.':6');
		}
		return 0;
	_local_

# 화학부 권유이벤트
@@EVENT
	start		100%
	code		cheinvite
	info		화학부 권유
	startfunc	_local_
		foreach(reverse@DT)
		{
			next if ($_->{job} eq "chemist");
			next if ($_->{item}[@@ITEMNO"수학"-1] < 80);
			next if ($_->{item}[@@ITEMNO"국어"-1] > 40);
			main::ReadDTSub($_,"data");
			next if ($_->{_data}->{club} =~ /chemist:/);
			$_->{_data}->{club}.="chemist:";
			main::WriteDTSub($_,"data");
			return (0,$_->{shopname}.'에서 화학부 권유 사건이 발생했습니다.?code'.$_->{id}.':7');
		}
		return 0;
	_local_

# 컴퓨터부 권유이벤트
@@EVENT
	start		100%
	code		otainvite
	info		컴퓨터부 권유
	startfunc	_local_
		foreach(reverse@DT)
		{
			next if ($_->{job} eq "otakkie");
			next if ($_->{item}[@@ITEMNO"영어"-1] < 80);
			next if ($_->{item}[@@ITEMNO"수학"-1] < 80);
			main::ReadDTSub($_,"data");
			next if ($_->{_data}->{club} =~ /otakkie:/);
			$_->{_data}->{club}.="otakkie:";
			main::WriteDTSub($_,"data");
			return (0,$_->{shopname}.'에서 컴퓨터부 권유 사건이 발생했습니다.?code'.$_->{id}.':8');
		}
		return 0;
	_local_

# 마술부 권유이벤트
@@EVENT
	start		70%
	code		magicinvite
	info		마술부 권유
	startfunc	_local_
		foreach(reverse@DT)
		{
			next if ($_->{job} eq "magic");
			next if ($_->{item}[@@ITEMNO"수학"-1] < 80);
			next if !$_->{item}[@@ITEMNO"타코야키"-1];
			my $flag;					#타코야키진열 확인
			foreach my $idx (0..$_->{showcasecount}-1)
			{
			my $itemno=$_->{showcase}[$idx];
			$flag=1 if ($itemno==@@ITEMNO"타코야키");
			}
			next if !$flag;
			main::ReadDTSub($_,"data");
			next if ($_->{_data}->{club} =~ /magic:/);
			$_->{_data}->{club}.="magic:";
			main::WriteDTSub($_,"data");
			return (0,$_->{shopname}.'에서 마술부 권유 사건이 발생했습니다.?code'.$_->{id}.':9');
		}
		return 0;
	_local_

# 연극부 권유이벤트
@@EVENT
	start		70%
	code		showinvite
	info		연극부 권유
	startfunc	_local_
		foreach(reverse@DT)
		{
			next if ($_->{job} eq "show");
			next if ($_->{item}[@@ITEMNO"수학"-1] > 40);
			next if ($_->{item}[@@ITEMNO"국어"-1] < 80);
			main::ReadDTSub($_,"data");
			next if ($_->{_data}->{club} =~ /show:/);
			$_->{_data}->{club}.="show:";
			main::WriteDTSub($_,"data");
			return (0,$_->{shopname}.'에서 연극부 권유 사건이 발생했습니다.?code'.$_->{id}.':10');
		}
		return 0;
	_local_

# 고전부 권유이벤트
@@EVENT
	start		70%
	code		obakeinvite
	info		고전부 권유
	startfunc	_local_
		foreach(reverse@DT)
		{
			next if ($_->{job} eq "obake");
			next if ($_->{item}[@@ITEMNO"영어"-1] < 80);
			next if ($_->{item}[@@ITEMNO"수학"-1] < 80);
			next if ($_->{item}[@@ITEMNO"국어"-1] < 80);
			main::ReadDTSub($_,"data");
			next if ($_->{_data}->{club} =~ /obake:/);
			$_->{_data}->{club}.="obake:";
			main::WriteDTSub($_,"data");
			return (0,$_->{shopname}.'에서 고전부 권유 사건이 발생했습니다.?code'.$_->{id}.':11');
		}
		return 0;
	_local_

# 실행위원회 권유이벤트
@@EVENT
	start		70%
	code		bossinvite
	info		실행위원회 권유
	startfunc	_local_
		return if grep($_->{job} eq "boss",@DT);
		foreach(reverse@DT)
		{
			next if ($_->{item}[@@ITEMNO"영어"-1] < 85);
			next if ($_->{item}[@@ITEMNO"수학"-1] < 85);
			next if ($_->{item}[@@ITEMNO"국어"-1] < 85);
			main::ReadDTSub($_,"data");
			next if ($_->{_data}->{club} =~ /boss:/);
			$_->{_data}->{club}.="boss:";
			main::WriteDTSub($_,"data");
			return (0,$_->{shopname}.'에서 실행위원회 권유 사건이 발생했습니다.?code'.$_->{id}.':12');
		}
		return 0;
	_local_

@@FUNCINIT
#동아리가 '실행위원회'이 경우, 매입에필요한 시간을3/4에하다.
$TIME_SEND_ITEM=int($TIME_SEND_ITEM/4*3) if $DT->{job} eq 'boss';

@@FUNCITEM
######################################################################
# ★입부 확인
######################################################################
sub jobcheck
{
my($USE)=@_;
main::ReadDTSub($DT,"data");
return 1 if ($DT->{job} eq $USE->{param4});
return 0 if ($DT->{_data}->{club} =~ /$USE->{param4}:/);
return 1;
}

######################################################################
# ★직업 변경
######################################################################
sub jobport
{
	$DT->{job}=$USE->{param4};
	WriteLog(3,0,$DT->{shopname}.'가 '.$main::JOBTYPE{$USE->{param4}}.'에 에 가입했습니다.');

	my $ret;
	my $exp1=$DT->{exp}{$USE->{param1}};
	my $exp2=0;
	$ret.="입부 신청서를 제출하러 학원 사무국으로 갔습니다.<br><br>";
	$ret.="<TABLE><tr><td>";
	$ret.=main::GetTagImgKao('아무자','amza')."사무원 아무자:<br>";
	$ret.="…흠. ".$main::JOBTYPE{$USE->{param4}}."에 에 가입하고 싶다는 말씀이군요.<br>";
	$ret.='그렇다면 전지전능한 학교장님이 나설 차례입니다!<br>지금 여기서 <b>'.$DT->{shopname}."</b>이<br>";
	$ret.=$main::JOBTYPE{$USE->{param4}}."의 일원이 되는 것을 허가합니다!";
	$ret.="</td></tr></table><br>";
	$ret.="동아리가 ".$main::JOBTYPE{$USE->{param4}}."로 변경되었습니다.<br>";

	foreach my $exps (split(/:/,$USE->{param2}))
	{
		my $exp=$DT->{exp}{$exps};
		next if (!$DT->{item}[$exps-1] && !$exp);
		$exp2+=$exp;
		delete($DT->{exp}{$exps});
		my $msg=$ITEM[$exps]->{name}.'의 숙련도가 초기화되었습니다.';
		$DT->{item}[$exps-1]=0 if ($DT->{item}[$exps-1]);
		WriteLog(0,$DT->{id},$msg);
		$ret.=$msg."<br>";
	}
	$exp2=int($exp2*$USE->{param3});
	$exp1+=$exp2;
	$exp1=1000 if $exp1>1000;
	$msg=$ITEM[$USE->{param1}]->{name}."의 숙련도가 ".int($exp1/10)."%가 되었습니다.";
	WriteLog(0,$DT->{id},$msg);
	$ret.=$msg."<br>";
	$DT->{item}[$USE->{param1}-1]=1;	# 아이템이받음 가능.
	$DT->{exp}{$USE->{param1}}=$exp1;
	delete $DT->{user}->{pt};
	delete $DT->{user}->{tt};
	return $ret;
}

######################################################################
#★공부
######################################################################
sub study
{
	my $ret;
	if($count>7)
	{
	$ret.="요시!지금일은, 바리바리공부시차루... 라고 생각라고시작했던 것을 다가.<br><br>";
	$ret.="<TABLE><tr><td>";
	$ret.=main::GetTagImgKao('도움','help')."<td><SPAN>도움</SPAN>:";
	$ret.="주인님! 잠시 쉬어 주세요!<br>";
	$ret.="아무리 생각해도 공부를 너무 많이 했습니다...";
	$ret.="</td></tr></table><br>";
	WriteLog(0,0,$DT->{shopname}.'가 공부를 너무 많이 해서 보건실로 실려 갔습니다.');
	$ret.="어떻게 된 일인지 공부를 너무 많이 해서 쓰러져 버린 것 같습니다.<br>정신을 차려 보니 보건실 침대 위였습니다. 식은식은땀이 났습니다.이 났습니다.";
	}
	else
	{
	$ret.="<SPAN>도움</SPAN>에게 공부 요령을 배웠습니다.<br><br>";
	$ret.="<TABLE><tr><td>";
	$ret.=main::GetTagImgKao('도움','help')."<td><SPAN>도움</SPAN>:";
	my $i=int(rand(3));
	if ($i == 1)
		{
		$ret.="문제를 풀기 전에는 먼저 지문을 차분히 읽어야 합니다.<br>";
		$ret.="아, 그 문제는 제가 풀어 드릴게요. 다음 문제로 넘어가죠!";
		}
	elsif ($i == 2)
		{
		$ret.="음, 찍어서 맞히려는 건 아니죠?<br>";
		$ret.="직감을 좀 더 갈고닦아 보세요.";
		}
	else
		{
		$ret.="아, 설명하다 보니 조금 귀찮아졌습니다...<br>";
		$ret.="...아닙니다. 아무 일도 없었습니다.";
		}
	$ret.="</td></tr></table><br>";
	$ret.="조금은 이해한 것 같습니다.";
	}
	return $ret;
}

######################################################################
# ★공연 확인
######################################################################
sub ptcheck
{
my($USE)=@_;
return 1 if (!$DT->{user}->{pt});
return 0;
}

######################################################################
#★새 마술 공연
######################################################################
sub newmagic
{
	main::OutError('공연 제목을 입력해 주세요.') if !$USE->{arg}->{message};
	my $ret;
	$ret.="새 소재를 <SPAN>도움</SPAN>에게 보여 주었습니다.<br><br>";
	$ret.="<TABLE><tr><td>";
	$ret.=main::GetTagImgKao('도움','help')."<td><SPAN>도움</SPAN>:";
	my $i=int(rand(3));
	if ($i == 1)
		{
		$ret.="...흠... 흠... 그렇군요.<br>";
		$ret.="...아, 정말 재미있었어요! 아주요.";
		}
	elsif ($i == 2)
		{
		$ret.="어라, 그 마술은 어디선가 본 적 있지 않나요?<br>";
		$ret.="이상하네요... 데자뷔일까요?";
		}
	else
		{
		$ret.="생각해 보니, 늘 나오는 그것 같네요.<br>";
		$ret.="키우고 있나요? 아니, 그만큼 꾸준하다는 뜻입니다.";
		}
	$ret.="</td></tr></table><br>";
	$ret.="새 마술 공연'".$USE->{arg}->{message}."'를 개발했습니다.";

	$DT->{user}->{tt}=$USE->{arg}->{message};
	$DT->{user}->{pt}=2000 + int($DT->{exp}{@@ITEMNO"마술 소품"} * 4 + rand(500));

	WriteLog(1,0,$DT->{shopname}.'에서 새 마술 '.$USE->{arg}->{message}.'가 개막했습니다.');

	foreach my $DTS (@DT) { AddItemSub(@@ITEMNO"초대장",1,$DTS); }
	return $ret;
}

######################################################################
#★새 연극공연
######################################################################
sub newshow
{
	main::OutError('공연 제목을 입력해 주세요.') if !$USE->{arg}->{message};
	my $ret;
	$ret.="새 소재를 <SPAN>도움</SPAN>에게 보여 주었습니다.<br><br>";
	$ret.="<TABLE><tr><td>";
	$ret.=main::GetTagImgKao('도움','help')."<td><SPAN>도움</SPAN>:";
	my $i=int(rand(3));
	if ($i == 1)
		{
		$ret.="음, 결말이 약하네요.<br>";
		$ret.="어라, 이거 코미디 맞죠? 아닌가요?";
		}
	elsif ($i == 2)
		{
		$ret.="그 연극에 저도 나갈 수 없나요?<br>";
		$ret.="아, 나무 1번 같은 배역도 괜찮습니다.";
		}
	else
		{
		$ret.="...흠... 흠... 그렇군요.<br>";
		$ret.="...아, 정말 재미있었어요! 아주요.";
		}
	$ret.="</td></tr></table><br>";
	$ret.="새 연극공연'".$USE->{arg}->{message}."'를 개발했습니다.";

	$DT->{user}->{tt}=$USE->{arg}->{message};
	$DT->{user}->{pt}=2000 + int($DT->{exp}{@@ITEMNO"무대 세트"} * 4 + rand(500));

	WriteLog(1,0,$DT->{shopname}.'에서 새 연극 '.$USE->{arg}->{message}.'이 개막했습니다.');

	foreach my $DTS (@DT) { AddItemSub(@@ITEMNO"초대장",1,$DTS); }
	return $ret;
}

######################################################################
#★새 귀신의 집
######################################################################
sub newobake
{
	main::OutError('귀신의 집 이름을 입력해 주세요.') if !$USE->{arg}->{message};
	my $ret;
	$ret.="새 귀신의 집을 <SPAN>도움</SPAN>에게 체험시켜 보았습니다.<br><br>";
	$ret.="<TABLE><tr><td>";
	$ret.=main::GetTagImgKao('도움','help')."<td><SPAN>도움</SPAN>:";
	my $i=int(rand(3));
	if ($i == 1)
		{
		$ret.="캬!<br>";
		$ret.="아, 저 귀신은 진짜입니다!!";
		}
	elsif ($i == 2)
		{
		$ret.="아차, 깜짝 놀라서 그만,<br>";
		$ret.="귀신 역할 담당자를 세게 때려 버렸습니다. 미합니다.";
		}
	else
		{
		$ret.="어라, 귀신 역할 담당자가 잠든 것 같아서<br>";
		$ret.="아무 일도 일어나지 않았습니다...";
		}
	$ret.="</td></tr></table><br>";
	$ret.="새 귀신의 집'".$USE->{arg}->{message}."'를 개발했습니다.";

	$DT->{user}->{tt}=$USE->{arg}->{message};
	$DT->{user}->{pt}=2000 + int($DT->{exp}{@@ITEMNO"귀신 분장 소품"} * 4 + rand(500));

	WriteLog(1,0,$DT->{shopname}.'에서 새 귀신의 집 '.$USE->{arg}->{message}.'이 개장했습니다.');

	foreach my $DTS (@DT) { AddItemSub(@@ITEMNO"초대장",1,$DTS); }
	return $ret;
}

######################################################################
#★공연을 실시
######################################################################
sub showing
{
	my $up=int($DT->{user}->{pt}*(2-$DT->{rank}/5000)/5);
	$up=$up * $USE->{result}->{count};
	$DT->{rank}+=$up;
	$DT->{rank}=10000 if $DT->{rank}>10000;
	my $ret="공연을 열었습니다: 인기 ".int($up/100)."% 상승";
	WriteLog(0,$DT->{id},$ret);
	WriteLog(3,0,$DT->{shopname}.'에서 '.$DT->{user}->{tt}.'가 공연되었습니다.');

	if ($USE->{result}->{count} > rand(10))
		{
		$cnt=($DT->{user}->{pt} + int(rand(5))) * 1000;
		$DT->{money}+=$cnt;
		$DT->{saletoday}+=$cnt;
		$ret.="<br>".GetMoneyString($cnt)."의 임시 수입이 생겼습니다.";
		}
	return $ret;
}

######################################################################
#★공연을 실시
######################################################################
sub obaking
{
	my $up=int($DT->{user}->{pt}*(2-$DT->{rank}/5000)/10);
	$up=$up * $USE->{result}->{count};
	$DT->{rank}+=$up;
	$DT->{rank}=10000 if $DT->{rank}>10000;
	my $ret="특별 쇼를 열었습니다: 인기 ".int($up/100)."% 상승";
	WriteLog(0,$DT->{id},$ret);
	WriteLog(3,0,$DT->{shopname}.'에서 '.$DT->{user}->{tt}.'의 특별 쇼가 열렸습니다.');

	if ($USE->{result}->{count} > rand(10))
		{
		$cnt=($DT->{user}->{pt} + int(rand(5))) * 1000;
		$DT->{money}+=$cnt;
		$DT->{saletoday}+=$cnt;
		$ret.="<br>".GetMoneyString($cnt)."의 임시 수입이 생겼습니다.";
		}
	return $ret;
}

######################################################################
#★좀도둑질
######################################################################
sub stole
{
	return '내 가게에서는 좀도둑질할 수 없습니다. 좀도둑질은 실패입니다.' if ($DT->{id} eq $DTS->{id});
	my $ret="좀도둑질은 실패했습니다. 배상금".GetMoneyString(500000)."를 빼앗겼습니다.";
	if($DTS->{item}[@@ITEMNO"생활지도위원"-1])
	{
		$DT->{rank}-=int($DT->{rank}/4);
		$DTS->{money}+=500000;
		$DTS->{saletoday}+=500000;
		$DT->{money}-=500000;
		$DT->{paytoday}+=500000;
		WriteLog(3,0,$DT->{shopname}."가".$DTS->{shopname}."에 좀도둑질하러 침입했지만 생활지도위원에게 발각되었습니다.");
		WriteLog(3,0,$DT->{shopname}."는".$DTS->{shopname}."에 배상금".GetMoneyString(500000)."를 지불지금했습니다.");
		WriteLog(0,$DT->{id},$ret);
		return $ret;
	}
	if(rand(1000)>900)
	{
		$DTS->{money}+=500000;
		$DTS->{saletoday}+=500000;
		$DT->{money}-=500000;
		$DT->{paytoday}+=500000;
		$DT->{rank}-=int($DT->{rank}/4);
		WriteLog(3,0,$DT->{shopname}."가".$DTS->{shopname}."에 좀도둑질하러 침입했지만 실패했습니다.");
		WriteLog(3,0,$DT->{shopname}."는".$DTS->{shopname}."에 배상금".GetMoneyString(500000)."를 지불지금했습니다.");
		WriteLog(0,$DT->{id},$ret);
		return $ret;
	}
	$ret="좀도둑질은 성공했습니다";
	my $manbiki_count=0;
	foreach my $idx (0..$DTS->{showcasecount}-1)
	{
		my $itemno=$DTS->{showcase}[$idx];
		if($itemno)
		{
			my $cnt=int($DTS->{item}[$itemno-1]*3/4);
			$cnt=$ITEM[$itemno]->{limit}-$DT->{item}[$itemno-1] if $DT->{item}[$itemno-1]+$cnt>$ITEM[$itemno]->{limit};
			$DTS->{item}[$itemno-1]-=$cnt;
			$DT->{item}[$itemno-1]+=$cnt;
			$manbiki_count+=$cnt*$DTS->{price}[$idx];
		}
	}
	$main::STATE->{safety}=int($main::STATE->{safety} * 18 / 19);
	WriteLog(2,0,$DTS->{shopname}."가 총액 ".GetMoneyString($manbiki_count)."상당의 좀도둑 피해를 입었습니다.") if $manbiki_count;
	WriteLog(2,0,$DTS->{shopname}."에 침입한 좀도둑은 아무것도 훔치지 못하고 도망쳤습니다.") if !$manbiki_count;
	WriteLog(0,$DT->{id},$ret);
	return $ret;
}

######################################################################
#★압정
######################################################################
sub fire
{
	my $ret;

if ( (rand(1000)>800) || ($DTS->{item}[@@ITEMNO"생활지도위원"-1]) )
{
	$DT->{rank}-=int($DT->{rank}/10);
	$ret=$DTS->{shopname}.'에게 압정을 뿌리지 못했습니다';
	WriteLog(0,$DT->{id},$ret);
	WriteLog(3,0,$DT->{shopname}."가".$DTS->{shopname}.'에 압정을 뿌리려고 했던 것 같습니다.');
	return $ret;
}

my $cnt=int(rand(50))+45;	#압정 수무작위로45~95
my $price=10000;		#진됩니다와 강제적에\10000이 됨
$DTS->{item}[82-1]=$cnt;

foreach my $idx (0..$DTS->{showcasecount}-1)
{
my $itemno=$DTS->{showcase}[$idx];
$DTS->{item}[$itemno-1]=0 if ($itemno);
$DTS->{showcase}[$idx]=82;	#압정의 아이템 No.
$DTS->{price}[$idx]=$price;
}

$ret=$DTS->{shopname}.'에게 압정을 뿌렸습니다';
WriteLog(0,$DT->{id},$ret);
WriteLog(3,0,$DTS->{shopname}.'의 진열대에 압정이 뿌려졌습니다.');

return $ret;
}



@@FUNCUPDATE
sub UpdateResetBefore #결산직전의 처리(함수이름고정)
{
	foreach my $DT (@DT)
	{
		$DT->{testpoint}=0;
		foreach my $itemno(@@ITEMNO"영어",@@ITEMNO"수학",@@ITEMNO"국어")
		{
		$DT->{item}[$itemno-1]+=int(($DT->{exp}{$itemno}/5 - $DT->{item}[$itemno-1])/3 + rand(5));
		$DT->{item}[$itemno-1]=90 + int(rand(10)) if $DT->{item}[$itemno-1]>95;
		$DT->{item}[$itemno-1]=1 if $DT->{item}[$itemno-1]<1;
		$DT->{exp}{$itemno}=int($DT->{exp}{$itemno}/2);
		$DT->{testpoint}+=$DT->{item}[$itemno-1];
		}
	}
	my @DTS=sort{$b->{testpoint}<=>$a->{testpoint}}@DT;
	PushLog(1,0,"정기시험의 종합상단은".$DTS[0]->{shopname}.'님의'.$DTS[0]->{testpoint}."점이었습니다.");
	my $i=int(rand(4))+3;
	$DTS[0]->{time}-=3600*$i;
	PushLog(2,0,"상위 ".$DTS[0]->{shopname}.'님에게는 '.$i."시간의 자유 시간이 주어졌습니다.");

	@DTS=reverse(@DTS);
	PushLog(1,0,"정기시험 종합 1위는 ".$DTS[0]->{shopname}.'님의'.$DTS[0]->{testpoint}."점이었습니다.");
	PushLog(1,0,"또한 종합 2위는 ".$DTS[1]->{shopname}.'님의'.$DTS[1]->{testpoint}."점이었습니다.");
	$i=int(rand(5))+3;
	$DTS[0]->{time}+=3600*$i;
	PushLog(2,0,"1위 ".$DTS[0]->{shopname}.'님은'.$i."시간 더 공부하게 되었습니다.");
	$i=int(rand(4))+2;
	$DTS[1]->{time}+=3600*$i;
	PushLog(2,0,"2위 ".$DTS[1]->{shopname}.'님은'.$i."시간 더 공부하게 되었습니다.");
}

sub UpdateResetAfter #결산직후의 처리(함수이름고정)
{
	foreach my $DT (@DT)
		{
		$DT->{profitstock}=5000000 if ($DT->{profitstock} > 5000000);
		$DT->{profitstock}=-1000000 if ($DT->{profitstock} < -1000000);
		if ($DT->{money} > 50000000)
			{
			$DT->{money} -= int( ($DT->{money} - 20000000)/2 );
			$DT->{rank} += int( (10000 - $DT->{rank})/2 );
			$DT->{rank}=10000 if $DT->{rank}>10000;
			PushLog(2,0,$DT->{shopname}.'에서축하축하회가줄가 되었습니다.');
			}
		}
}

@@FUNCNEW

# @@DEFINE Set NewShopMoney NewShopTime NewShopItem 의처리
$DT->{money}=@@VALUE"NewShopMoney" if @@VALUE"NewShopMoney";
$DT->{time}=$NOW_TIME-eval(@@VALUE"NewShopTime") if @@VALUE"NewShopTime";
if(@@VALUE"NewShopItem")
{
	my %item=split /:/,@@VALUE"NewShopItem";
	while(my($key,$val)=each %item)
	{
		foreach my $item (@ITEM)
		{
			 $DT->{item}[$item->{no}-1]+=$val,last if $key eq $item->{code} or $key eq $item->{name};
		}
	}
}

# $DEFINE_FUNCNEW_NOLOG=1로 설정하면 시스템 최근 사건의 신규 개점 메시지를 숨깁니다.
$DEFINE_FUNCNEW_NOLOG=1;
WriteLog(1,0,0,"어서 오세요. ".$DT->{shopname}."이 개점했습니다.",1);

# 그 밖에 신규 개점 시 전용 처리를 추가할 수 있습니다.

foreach my $itemno(@@ITEMNO"영어",@@ITEMNO"수학",@@ITEMNO"국어")
{
	$DT->{item}[$itemno-1]=45+int(rand(10));
}

@@FUNCSHOPIN

SetUserDataEx($DT,'_so_move_in',$NOW_TIME); # 이전시각을 기록
if($DT->{job} eq 'peddle')
{
	# 줄상업인(peddle)에는 이전소요 시간의1/2을 반환반환
	$DT->{_MoveTownTime}=int($DT->{_MoveTownTime}/2);
	EditTime($DT,$DT->{_MoveTownTime});
	WriteLog(0,$DT->{id},0,'이전 시간이절반의'.GetTime2HMS($DT->{_MoveTownTime}).'로 완료된 것 같습니다',1);
}
if(GetUserDataEx($DT,'_so_present_money'))
{
	WriteLog(0,$DT->{id},0,'이전원래의 거리에서 전별금으로'.GetMoneyString(GetUserDataEx($DT,'_so_present_money')).'를 받았습니다',1);
	SetUserDataEx($DT,'_so_present_money','');
}

@@FUNCSHOPOUT

if(GetUserDataEx($DT,'_so_move_in'))
{
	my $present_money=int(($NOW_TIME-GetUserDataEx($DT,'_so_move_in'))/86400)*5000;
	EditMoney($DT,$present_money); # 체류 기간 1일마다\5000을 전별금으로 자금로
	SetUserDataEx($DT,'_so_present_money',$present_money);
	SetUserDataEx($DT,'_so_move_in',''); # $DT->{user}{_so_move_in}을삭제
}

@@END # 정의 종료 선언(이후 문장은 취급하지 않음)

