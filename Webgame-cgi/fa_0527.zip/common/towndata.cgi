@OtherDir=("festa");
$Tname{festa}="략명칭";
