#!/usr/bin/perl
# 드래곤 경주 목장 메뉴 표시 2005/03/30 유래

ReadRanch();
$disp.="<BIG>●드래곤 경주:목장</BIG><br><br>";

if ($MYRC==-1)
{
$disp.="$TB$TR$TD".GetTagImgKao("드래곤 목장주","slime1").$TD;
$disp.="<SPAN>드래곤 목장주</SPAN>:아직 자신의 목장을 보유하고 있지 않군요.<br>";
$disp.="목장을 보유하면 자신의 드래곤을 육성할 수 있습니다.".$TRE.$TBE;
my $estmsg=GetMoneyString($RCest);
$disp.=<<STR;
<br>
<FORM ACTION="action.cgi" $METHOD>
<INPUT TYPE=HIDDEN NAME=key VALUE="slime-s">
<INPUT TYPE=HIDDEN NAME=bk VALUE="slime">
$USERPASSFORM
<INPUT TYPE=HIDDEN NAME=mode VALUE="rcedit">
<INPUT TYPE=HIDDEN NAME=code VALUE="new">
<BIG>●목장 설립</BIG>: <INPUT TYPE=TEXT NAME=name SIZE=20> 라고 이름을 붙여
<INPUT TYPE=SUBMIT VALUE='설치'>
</FORM>
<br>
$TB$TR$TD
·목장을 설립하려면 자금 <b>$estmsg</b>이 필요합니다.<br>
·드래곤을 육성하려면 추가 자금이 필요하므로 여유를 두고 시작하세요.<br>
$TBE
STR
}
else
{
$disp.="$TB$TR$TDB 명칭$TDB 설립$TDB 평균 상금$TDB 총상금$TDB 성적$TRE";
$disp.=$TR;
$disp.=$TD.$RC[$MYRC]->{name};
$disp.=$TD.GetTime2found($NOW_TIME-$RC[$MYRC]->{birth});
$disp.=$TD.($RC[$MYRC]->{aprize} + 0)."만";
$disp.=$TD.($RC[$MYRC]->{prize} + 0)."만";
$disp.=$TD.($RC[$MYRC]->{g1win} + 0)." - ".($RC[$MYRC]->{g2win} + 0)." - ".($RC[$MYRC]->{g3win} + 0)." - ".($RC[$MYRC]->{sdwin} + 0);
$disp.=$TRE.$TBE;
$disp.="<br><BIG>●소유 드래곤</BIG><br><br>";
ReadDragon();
if (!scalar @MYDR)
	{
	$disp.="소유한 드래곤이 없습니다<br><br>";
	}
	else
	{
$disp.="$TB$TR$TDB 명칭$TDB 나이$TDB 성별$TDB 스피드$TDB 승부근성$TDB 순발력$TDB 파워$TDB 컨디션$TDB 체중$TDB 거리 적성$TDB 총상금$TDB 성적$TRE";
	foreach (@MYDR)
		{
$disp.=$TR;
$disp.=$TD."<a href=\"action.cgi?key=slime&mode=detail&dr=$DR[$_]->{no}&$USERPASSURL\">"
	.GetTagImgDra($DR[$_]->{fm},$DR[$_]->{color}).$DR[$_]->{name}."</a>";
$disp.=$TD.GetTime2found($NOW_TIME-$DR[$_]->{birth});
$disp.=$TD.$FM[$DR[$_]->{fm}];
$disp.=$TD.$VALUE[int($DR[$_]->{sp} /100*6)];
$disp.=$TD.$VALUE[int($DR[$_]->{sr} /100*6)];
$disp.=$TD.$VALUE[int($DR[$_]->{ag} /100*6)];
$disp.=$TD.$VALUE[int($DR[$_]->{pw} /100*6)];
$disp.=$TD.$EVALUE[int($DR[$_]->{con} /100*4)];
$disp.=$TD.$DR[$_]->{wt};
$disp.=$TD.GetRaceApt($DR[$_]->{apt},$DR[$_]->{fl});
$disp.=$TD.($DR[$_]->{prize} + 0)."만";
$disp.=$TD.($DR[$_]->{g1win} + 0)." - ".($DR[$_]->{g2win} + 0)." - ".($DR[$_]->{g3win} + 0)." - ".($DR[$_]->{sdwin} + 0);
$disp.=$TRE;
		}
$disp.=$TBE."<br>";
	}

ReadParent();

if (scalar @MYPR)
	{
	$disp.="<BIG>●소유 은퇴 드래곤</BIG><br><br>";
$disp.="$TB$TR$TDB 명칭$TDB 나이$TDB 유전력$TDB 스피드$TDB 승부근성$TDB 순발력$TDB 파워$TDB 건강$TDB 유연성$TDB 거리 적성$TDB 현역 상금$TDB 현역 성적$TRE";
	foreach (@MYPR)
		{
$disp.=$TR;
$disp.=$TD."<a href=\"action.cgi?key=slime&mode=pr&dr=$PR[$_]->{no}&$USERPASSURL\">"
	.GetTagImgDra($PR[$_]->{fm},$PR[$_]->{color},1).$PR[$_]->{name}."</a>";
$disp.=$TD.GetTime2found($NOW_TIME-$PR[$_]->{birth});
$disp.=$TD.$VALUE[int($PR[$_]->{hr} /100*6)];
$disp.=$TD.$VALUE[int($PR[$_]->{sp} /100*6)];
$disp.=$TD.$VALUE[int($PR[$_]->{sr} /100*6)];
$disp.=$TD.$VALUE[int($PR[$_]->{ag} /100*6)];
$disp.=$TD.$VALUE[int($PR[$_]->{pw} /100*6)];
$disp.=$TD.$VALUE[int($PR[$_]->{hl} /100*6)];
$disp.=$TD.$VALUE[int($PR[$_]->{fl} /100*6)];
$disp.=$TD.GetRaceApt($PR[$_]->{apt},$PR[$_]->{fl});
$disp.=$TD.($PR[$_]->{prize} + 0)."만";
$disp.=$TD.($PR[$_]->{g1win} + 0)." - ".($PR[$_]->{g2win} + 0)." - ".($PR[$_]->{g3win} + 0)." - ".($PR[$_]->{sdwin} + 0);
$disp.=$TRE;
		}
$disp.=$TBE."<br>";
	}



if (scalar @MYDR < $MYDRmax)
	{
my @dist=('단거리형','중거리형','장거리형');
my $formdist="";
foreach(0..$#dist) {$formdist.=qq|<OPTION VALUE="$_">$dist[$_]|; }
my $buymsg=GetMoneyString($DRbuy);
$disp.=<<STR;
<FORM ACTION="action.cgi" $METHOD>
<INPUT TYPE=HIDDEN NAME=key VALUE="slime-s">
<INPUT TYPE=HIDDEN NAME=bk VALUE="slime">
$USERPASSFORM
<INPUT TYPE=HIDDEN NAME=mode VALUE="dredit">
<INPUT TYPE=HIDDEN NAME=code VALUE="new">
<BIG>●드래곤 구입</BIG>: <SELECT NAME=fm SIZE=1>
<OPTION VALUE="0">$FM[0]<OPTION VALUE="1">$FM[1]
</SELECT> 의 <SELECT NAME=dist SIZE=1>
$formdist
</SELECT>을
<INPUT TYPE=TEXT NAME=name SIZE=20> 라고 이름을 붙여
<INPUT TYPE=SUBMIT VALUE='구입'>
</FORM>
<br>
$TB$TR$TD
·드래곤은 <b>$MYDRmax</b>마리까지 보유할 수 있습니다.<br>
·구입하려면 자금 <b>$buymsg</b>이 필요합니다.<br>
·이름은 <b>한글 10자 이내</b>로 입력해 주세요.
$TBE
STR
	}
}
1;



