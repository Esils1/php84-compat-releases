#!/usr/bin/perl
# 택배편집 2005/03/30 유래

my $functionname=$Q{mode};
OutError("bad request") if !defined(&$functionname);
&$functionname;

WriteDwarf();
DataCommitOrAbort();
UnLock();
1;


sub new
{
	my ($to,$item)=($Q{to},$Q{item});
	OutError("수신처를 지정해 주세요.") if $to==-1;
	OutError("자기 자신에게 택배를 보낼 수 없습니다.") if ($to == $DT->{id});
	if ($to==99)
		{
		OutError("무역이 연결되어 있지 않아 지정할 수 없습니다.") unless -e "trade.cgi";
		$Q{notice}=0;
		}
		else
		{
		OutError("존재하지 않는 점포입니다.") if !defined($id2idx{$to});
		}
	OutError("아이템 지정이 올바르지 않습니다.") if !$ITEM[$item]->{name};
	OutError("아이템 지정이 올바르지 않습니다.") if $ITEM[$item]->{flag}=~/r/;	# r 의뢰불가

	$Q{num}||=$DT->{item}[$item-1];
	$Q{num}=CheckCount($Q{num},0,0,$DT->{item}[$item-1]);
	OutError("아이템 재고가 없습니다.") if !$Q{num};
	my $price=CheckCount($Q{price},0,0,$MAX_MONEY);
	$price=$price * $Q{num} if $Q{unit};
	OutError("요금금을 지정해 주세요.") if !$price;
	my $numrate=$ITEM[$item]->{price} * $Q{num};
	OutError("상품과 요금의 가치가 맞지 않습니다.") if ($price > $numrate * 2) || ($numrate > $price * 2);

	NoticeDwarf() if $Q{notice};

	@DWF=reverse(@DWF);
	$Dcount++;
	my $i=$Dcount;
	$DWF[$i]->{no}=($i > 0) ? ($DWF[$i-1]->{no} + 1) : 1;
	$DWF[$i]->{tm}=$NOW_TIME;
	$DWF[$i]->{from}=$DT->{id};
	$DWF[$i]->{to}=$to;
	$DWF[$i]->{trade}=(($to==99) ? $DWF[$i]->{no} : "");
	$DWF[$i]->{mode}=1;
	($DWF[$i]->{item},$DWF[$i]->{num},$DWF[$i]->{price})=($item,$Q{num},$price);
	@DWF=reverse(@DWF);

	$DT->{item}[$item-1]-=$Q{num};

	my $cost=0;
	$cost=int($price * $DTTaxrate / 100);
	OutError("세금을 지불이것이할 수 없습니다.") if ($cost > $DT->{money});
	$DT->{taxtoday}+=$cost;
	$DT->{money}-=$cost;

	DataWrite();
	$Q{form}="";
}

sub plus
{
	if ($Q{ng})
	{
		# 받처리거부
		foreach my $i(0..$Dcount)
		{
		next unless $DWF[$i]->{to}==$DT->{id};
		next unless $DWF[$i]->{mode}==1;
		my $act="act_".$DWF[$i]->{no};
		$DWF[$i]->{mode}=3 , next if ($Q{$act});
		}
		return;
	}

	# 받처리
	foreach my $i(0..$Dcount)
	{
	next unless $DWF[$i]->{to}==$DT->{id};
	next unless $DWF[$i]->{mode}==1;
	my $act="act_".$DWF[$i]->{no};
	next unless ($Q{$act});
	$DWF[$i]->{mode}=2;
	my ($price,$from,$item,$num)=($DWF[$i]->{price},$DWF[$i]->{from},$DWF[$i]->{item},$DWF[$i]->{num});
	$DT->{paytoday}+=$price;
	$DT->{money}-=$price;
	$DT[$id2idx{$from}]->{money}+=$price;
	$DT[$id2idx{$from}]->{saletoday}+=$price;
	$DT->{item}[$item-1]+=$num;
	$DT->{item}[$item-1]=$ITEM[$item]->{limit} if ($DT->{item}[$item-1]>$ITEM[$item]->{limit});
	}
	OutError("대금을 지불우의 에필요한 자금이 부족합니다.") if ($DT->{money} < 0);
	DataWrite();
}

sub trade
{
	OutError("무역이 연결되어 있지 않아 지정할 수 없습니다.") unless -e "trade.cgi";
	OutError("무역품을 지정해 주세요.") if !defined($Q{code});

	my($boxno,$item,$num,$price)=split(/:/,$Q{code});
	OutError("아이템 지정이 올바르지 않습니다.") if !$ITEM[$item]->{name};
	OutError("아이템 지정이 올바르지 않습니다.") if $ITEM[$item]->{flag}=~/r/;	# r 의뢰불가

	$num=CheckCount($num,0,0,$MAX_MONEY);
	OutError("개수의 지정이부정입니다.".$num) if !$num;
	$price=CheckCount($price,0,0,$MAX_MONEY);
	OutError("요금금의 지정이부정입니다.") if !$price;
	OutError("자금을 준비하고오있고해 주세요.") if $price > $DT->{money};
	OutError("그무역품은 이미판매약속완료입니다.") if grep($_->{trade} eq $boxno,@DWF);

	@DWF=reverse(@DWF);
	$Dcount++;
	my $i=$Dcount;
	$DWF[$i]->{no}=($i > 0) ? ($DWF[$i-1]->{no} + 1) : 1;
	$DWF[$i]->{tm}=$NOW_TIME;
	$DWF[$i]->{from}=99;
	$DWF[$i]->{to}=$DT->{id};
	$DWF[$i]->{trade}=$boxno;
	$DWF[$i]->{mode}=0;
	($DWF[$i]->{item},$DWF[$i]->{num},$DWF[$i]->{price})=($item,$num,$price);
	@DWF=reverse(@DWF);
}

sub delete
{
	$WriteMode=0;
	foreach my $i(0..$Dcount)
	{
	next unless $DWF[$i]->{from}==$DT->{id};
	my $act="del_".$DWF[$i]->{no};
	next unless ($Q{$act});
	if ($DWF[$i]->{mode}!=2)	# 수취완료미라면반환거부의 필요없음
		{
		$WriteMode=1;
		my ($item,$num)=($DWF[$i]->{item},$DWF[$i]->{num});
		$DT->{item}[$item-1]+=$num;
		$DT->{item}[$item-1]=$ITEM[$item]->{limit} if ($DT->{item}[$item-1]>$ITEM[$item]->{limit});
		}
	undef $DWF[$i];
	}
	DataWrite() if $WriteMode;
}

sub WriteDwarf
{
	undef @RECDWF;	# 저장와 재정의 를동시에
	undef @SENDWF;
	$NeverD=0;
	my @buf;
	foreach my $i(0..$Dcount)
		{
		next unless defined($DWF[$i]->{no});
		$buf[$i]=join(",",map{$DWF[$i]->{$_}}@DWFnamelist)."\n";
		if ($DWF[$i]->{to}==$DT->{id})
			{
			push(@RECDWF, $i);
			$NeverD++ if $DWF[$i]->{mode}==1;
			}
		push(@SENDWF, $i) if ($DWF[$i]->{from}==$DT->{id});
		}
	OpenAndCheck(GetPath($TEMP_DIR,"dwarf"));
	print OUT @buf;
	close(OUT);
}

sub NoticeDwarf
{
	ReadLetter();

	@LETTER=reverse(@LETTER);
	$Lcount++;
	my $i=$Lcount;
	$LETTER[$i]->{no}=($i) ? ($LETTER[$i-1]->{no} + 1) : 1 ;
	$LETTER[$i]->{time}=$NOW_TIME;
	$LETTER[$i]->{fromt}=$MYDIR;
	$LETTER[$i]->{fromid}=1;
	$LETTER[$i]->{tot}=$MYDIR;
	$LETTER[$i]->{toid}=$Q{to};
	$LETTER[$i]->{title}="택배 도착 알림";
	$LETTER[$i]->{msg}="드워프 택배입니다. ".$DT->{shopname}."님에게서 소포가 도착했습니다. 확인해 주세요.";
	$LETTER[$i]->{mode}=1;	#미 확인 설정
	$LETTER[$i]->{other}=$DT->{shopname};
	@LETTER=reverse(@LETTER);

	WriteLetter();
	CoDataCA();
	CoUnLock();
}

