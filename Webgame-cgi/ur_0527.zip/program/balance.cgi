#!/usr/bin/perl
# 내 가계 상세 2004/01/20 유래

DataRead();
CheckUserPass();
RequireFile('inc-info.cgi');
OutSkin();
1;