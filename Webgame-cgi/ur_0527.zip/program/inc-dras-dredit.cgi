#!/usr/bin/perl
BEGIN {
	*Utf8Text = sub {
		my($s)=@_;
		return '' unless defined $s;
		utf8::decode($s) unless utf8::is_utf8($s);
		return $s;
	} unless defined &Utf8Text;

	*Utf8InPlace = sub {
		utf8::decode($_[0]) if defined $_[0] && !utf8::is_utf8($_[0]);
	} unless defined &Utf8InPlace;
}
# 드래곤 경주 드래곤 관리 2005/03/30 유래

ReadDragon();
$disp.="<BIG>●드래곤 경주:목장</BIG><br><br>";

my $functionname=$Q{code};
OutError("bad request") if !defined(&$functionname);
&$functionname;

WriteDragon();
CoDataCA();
1;

sub new
{
	#목장 확인
	ReadRanch();
	OutError("bad request") if ($MYRC==-1);

	OutError('자금이 부족합니다.') if ($DT->{money} < $DRbuy);
	OutError('더 이상 드래곤을 소유할 수 없습니다.') if (scalar @MYDR >= $MYDRmax);

	# 이름의 정당성을 확인

	if(!$Q{name})
	{
		OutError('이름을 입력해 주세요.');
	}
	$Q{name}=Utf8Text($Q{name});
	if($Q{name} =~ /([,:;\t\r\n<>&])/ || CheckNGName($Q{name}) )
	{
		OutError('이름에 사용할 수 없는 문자가 포함되어 있습니다.');
	}

	#UTF-8 문자열로 처리

	$ZkatakanaExt = '(?:\xA5[\xA1-\xF6]|\xA1[\xA6\xBC\xB3\xB4])';
	OutError('이름은 전각 가타카나로 지정해 주세요.') if ($Q{name} !~ /^($ZkatakanaExt)*$/);


	OutError('이름이 너무 깁니다.') if length($Q{name})>20;
	OutError('이름이 너무 짧습니다.') if length($Q{name})<6;

	@DR=reverse(@DR);
	$DRcount++;
	my $i=$DRcount;
	$DR[$i]->{no}=($i > 0) ? ($DR[$i-1]->{no} + 1) : 1 ;
	$DR[$i]->{birth}=$NOW_TIME - 5 * 86400;
	$DR[$i]->{fm}=$Q{fm};
	$DR[$i]->{color}=int(rand(scalar @DRCOLOR));
	$DR[$i]->{name}=$Q{name};
	$DR[$i]->{town}=$MYDIR;
	$DR[$i]->{owner}=$DT->{id};
	$DR[$i]->{apt}=1400 + ($Q{dist} * 600) + int(rand(3))*100;
	$DR[$i]->{sp}=10 + int(rand(20));
	$DR[$i]->{sr}=5 + int(rand(20));
	$DR[$i]->{ag}=5 + int(rand(20));
	$DR[$i]->{pw}=10 + int(rand(20));
	$DR[$i]->{hl}=10 + int(rand(40));
	$DR[$i]->{fl}=10 + int(rand(20));
	$DR[$i]->{con}=70 + int(rand(20));
	$DR[$i]->{wt}=49 + int(rand(3));

	# 특징이 약한 경우 보정
	if ($DR[$i]->{sr} > $DR[$i]->{ag})
		{
		$DR[$i]->{sr}+=15;
		}
		else
		{
		$DR[$i]->{ag}+=15;
		}
	@DR=reverse(@DR);

WritePayLog($MYDIR,$DT->{id},-$DRbuy);
$disp.="새 드래곤'<b>".$Q{name}."</b>'을 구매했습니다.";
}

sub ent
{
my $cnt=$id2dra{$Q{dr}};
OutError("bad request") if ($DR[$cnt]->{town} ne $MYDIR || $DR[$cnt]->{owner} != $DT->{id});

ReadStable();
OutError("bad request") if (!scalar @ST);
OutError("bad request") if (!defined $id2st{$Q{ent}});
$DR[$cnt]->{stable}=$Q{ent};
my $i=$id2st{$Q{ent}};
$disp.="드래곤을 마구간 '".$ST[$i]->{name}."'에 위탁했습니다.";
}

sub torace
{
	#드래곤 확인
	my $cnt=$id2dra{$Q{dr}};
	OutError("bad request") if ($DR[$cnt]->{town} ne $MYDIR || $DR[$cnt]->{owner} != $DT->{id});
	OutError("bad request") if ($DR[$cnt]->{race} > 1);

	#목장 확인
	ReadRanch();
	OutError("bad request") if ($MYRC==-1);

	#경주 확인
	my $rcode=$Q{rcode};
	ReadRace($rcode);
	OutError("현재 ".$RACETERM[$rcode]."는 출전 등록을 받고 있지 않습니다") if ($RDS[0]);

	my @MYRACE=@{$RACE[$rcode]};
	my @R=@{$MYRACE[$RDS[1]]};
	undef @RACE;
	undef @MYRACE;	#불필요한 배열은 해제

	OutError("다음 회의 " . $R[0] . "는 상금 미획득 드래곤만 출전할 수 있습니다") if ($R[1]==5 && $DR[$cnt]->{prize} > 0);

	#소속마구간을 조사하기
	ReadStable();
	my $stname="";
	if (scalar @ST)
	{
	foreach(0..$STcount)
		{
		$stname=$ST[$_]->{name},last if ($ST[$_]->{no}==$DR[$cnt]->{stable});
		}
	}

	my $lose="실력부족";
	my ($sp,$sr,$ag,$pw)=($DR[$cnt]->{sp},$DR[$cnt]->{sr},$DR[$cnt]->{ag},$DR[$cnt]->{pw});

	# 힘배분
	my $pwp=$R[3] * 4 + $RDS[2] * 3 + 1;
	$lose="힘부족" if ($pwp > 1 && $sp < $pw);
	$sp=int(($sp * (10 - $pwp) + $pw * $pwp) / 10);

	# 컨디션에 한영향 최대에서 속도5할
	$sp-=int($sp*(100 - $DR[$cnt]->{con})/200);
	$lose="컨디션 부족" if ($DR[$cnt]->{con} < 60);

	# 체중와 핸디캡에 한영향 10톤에서 속도5할
	my $wt=$DR[$cnt]->{wt} - 50;
	$wt=-$wt if ($wt < 0);
	$wt+=int($DR[$cnt]->{prize} / $R[2]) if $R[2];
	$sp-=int($sp*$wt/20);
	$lose="중량조정실패" if ($wt > 2);

	my $sp1=$sp2=$sp3=$sp4=$sp * 6 + 1000;		#기준속도 1000 - 1600

	# 종반에 언덕이있는 경우
	$sp4=$sp * 4 + $pw * 2 + 950 if $R[4];

	if (!$Q{str})
		{
		#도주의 경우
		$sp1+=$sr * 6 - $ag * 4 + 40;
		$sp2+=$sr * 2 + 50;
		$sp1=$sp2 if ($sp1 < $sp2);
		}
	elsif ($Q{str}==1)
		{
		#선줄의 경우
		$sp1+=$sr * 2 + 50;
		$sp2+=$sr * 4 + 100;
		}
	elsif ($Q{str}==2)
		{
		#차시의 경우
		$sp3+=$ag * 4 + 100;
		$sp4+=$ag * 2 + 50;
		}
	else
		{
		#추입의 경우
		$sp3+=$ag * 2 + 50;
		$sp4+=$ag * 6 - $sr * 4 + 40;
		$sp4=$sp3 if ($sp4 < $sp3);
		}

	# 거리적성에 한영향
	my $m=GetRaceApt($DR[$cnt]->{apt},$DR[$cnt]->{fl},$R[5]);
	if ($m > 0)
		{
		$lose="거리가 너무 짧음";
		$m=300 if $m > 300;
		$sp1-=$m * 2;
		$sp2-=$m;
		}
	elsif ($m < 0)
		{
		$lose="거리가 너무 김";
		$m=-300 if $m < -300;
		$sp1+=$m * 2;
		$sp2+=$m;
		}

	#기수를 조사하기
	my $jkname="";
	if ($Q{jock})
	{
	ReadJock();
	if (scalar @JK)
		{
		foreach(0..$JKcount)
			{
			next if ($JK[$_]->{no}!=$Q{jock});
			OutError("그 기수는 이미 다른 드래곤에 기승 중입니다") if ($JK[$_]->{race} > 1);
			$jkname=$JK[$_]->{name};
			$JK[$_]->{race}=2;

			#기수에 한보정
			$sp1+=int($sp1 * $JK[$_]->{ahead} / 20 / 100);
			$sp2+=int($sp2 * $JK[$_]->{ahead} / 20 / 100);
			$sp3+=int($sp3 * $JK[$_]->{back} / 20 / 100);
			$sp4+=int($sp4 * $JK[$_]->{back} / 20 / 100);

			WriteJock();
			last;
			}
		}
	}

	my $i=$RDcount;
	$RDcount++;
	$RD[$i]->{no}=($i > 0) ? ($RD[$i-1]->{no} + 1) : 1 ;
	$RD[$i]->{dr}=$Q{dr};

	$RD[$i]->{birth}=$DR[$cnt]->{birth};
	$RD[$i]->{fm}=$DR[$cnt]->{fm};
	$RD[$i]->{color}=$DR[$cnt]->{color};
	$RD[$i]->{name}=$DR[$cnt]->{name};
	$RD[$i]->{ranch}=$RC[$MYRC]->{no};
	$RD[$i]->{rcname}=$RC[$MYRC]->{name};
	$RD[$i]->{stable}=$DR[$cnt]->{stable};
	$RD[$i]->{stname}=$stname;
	$RD[$i]->{jock}=$Q{jock};
	$RD[$i]->{jkname}=$jkname;
	$RD[$i]->{prize}=$DR[$cnt]->{prize};
	$RD[$i]->{strate}=GetRaceStrate($DR[$cnt]->{sr},$DR[$cnt]->{ag});
	$RD[$i]->{sp1}=$sp1;
	$RD[$i]->{sp2}=$sp2;
	$RD[$i]->{sp3}=$sp3;
	$RD[$i]->{sp4}=$sp4;
	$RD[$i]->{str}=$Q{str};
	$lose="작전실수" if ($Q{str} != $RD[$i]->{strate});
	$RD[$i]->{lose}=$lose;

	WriteRace($rcode);

	$DR[$cnt]->{race}=2;
$disp.="드래곤'".$DR[$cnt]->{name}."'를".$R[0]."에출전 등록했습니다.";
}

