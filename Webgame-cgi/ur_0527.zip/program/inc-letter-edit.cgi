#!/usr/bin/perl
BEGIN {
	*Utf8Text = sub {
		my($s)=@_;
		return '' unless defined $s;
		utf8::decode($s) unless utf8::is_utf8($s);
		return $s;
	} unless defined &Utf8Text;

	*Utf8InPlace = sub {
		utf8::decode($_[0]) if defined $_[0] && !utf8::is_utf8($_[0]);
	} unless defined &Utf8InPlace;
}
# 편지편집 2003/07/19 유래

if ($Q{mode} eq 'new')
{
	$Q{old} = "list";	#보낸 편지함을 표시.
	$Q{form} = "";
	NewLetter();
}
else
{
	undef @RECLETTER;
	$NeverR=0;
	undef @SENLETTER;
	$NeverS=0;
	foreach my $i(0..$Lcount)
	{
	my $delete="del_".$LETTER[$i]->{no};
	$LETTER[$i]->{mode}=2 , next if ($Q{$delete});
	if ($MYDIR eq $LETTER[$i]->{tot} && $LETTER[$i]->{toid}==$DT->{id})
		{
		push(@RECLETTER, $i);
		$NeverR++ if ($LETTER[$i]->{mode}==1);
		}
	if ($MYDIR eq $LETTER[$i]->{fromt} && $LETTER[$i]->{fromid}==$DT->{id})
		{
		push(@SENLETTER, $i);
		$NeverS++ if ($LETTER[$i]->{mode}==1);
		}
	}
}

$WriteFlag=1;		# 데이터갱신을 지시.
1;


sub NewLetter
{
my $sendmail="";
my $sendto="";
foreach my $pg(@OtherDir)
	{
	$sendmail=$Q{$pg}, $sendto=$pg if ($Q{$pg})
	}
OutError('수신처를 지정해 주세요.') if !$sendto;

	CheckNewBoxArg();

	@LETTER=reverse(@LETTER);
	$Lcount++;
	my $i=$Lcount;
	$LETTER[$i]->{no}=($i) ? ($LETTER[$i-1]->{no} + 1) : 1 ;
	$LETTER[$i]->{time}=$NOW_TIME;
	$LETTER[$i]->{fromt}=$MYDIR;
	$LETTER[$i]->{fromid}=$DT->{id};
	$LETTER[$i]->{tot}=$sendto;
	$LETTER[$i]->{toid}=$sendmail;
	$LETTER[$i]->{title}=$Q{title};
	$LETTER[$i]->{msg}=$Q{msg};
	$LETTER[$i]->{mode}=1;	#미 확인 설정
	$LETTER[$i]->{other}=$DT->{shopname};
	@LETTER=reverse(@LETTER);

	undef @SENLETTER;	# 다시 읽기
	$NeverS=0;
	foreach my $i(0..$Lcount)
	{
	if ($MYDIR eq $LETTER[$i]->{fromt} && $LETTER[$i]->{fromid}==$DT->{id})
		{
		push(@SENLETTER, $i);
		$NeverS++ if ($LETTER[$i]->{mode}==1);
		}
	}
}

sub CheckNewBoxArg
{

	$Q{msg}=CutStr(Utf8Text($Q{msg}),400);
	$Q{title}=CutStr(Utf8Text($Q{title}),40);
	OutError('내용을 입력해 주세요') if $Q{msg}eq'';
	$Q{title}="(제목 없음)" if $Q{title}eq'';
}
