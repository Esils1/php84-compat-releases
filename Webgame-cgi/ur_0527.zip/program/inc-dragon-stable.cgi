#!/usr/bin/perl
# 드래곤 경주 마구간 메뉴 표시 2005/03/30 유래

ReadStable();
$disp.="<BIG>●드래곤 경주:마구간</BIG><br><br>";

if ($MYST==-1)
{
$disp.="$TB$TR$TD".GetTagImgKao("드래곤 조교사","slime3").$TD;
$disp.="<SPAN>드래곤 조교사</SPAN>:아직 자신의 마구간을 보유하고 있지 않군요.<br>";
$disp.="마구간을 보유하면 자신과 타인의 드래곤을 조교할 수 있습니다.".$TRE.$TBE."<br>";
if (scalar @ST < $STmax)
	{
	FormStable();
	}
	else
	{
	$disp.="<BIG>●마구간 설립</BIG>: 정원에 도달하여 더 이상 설립할 수 없습니다.";
	}
}
else
{
	$disp.="$TB$TR$TDB 명칭$TDB 훈련 방침$TDB 조교$TDB 컨디션$TDB 체중$TDB 코스$TDB 병합 훈련$TDB 언덕$TDB 더트$TDB 온천$TDB 유연성 훈련$TDB 성적$TDB 유지비$TDB 노후화$TRE";
	$disp.=$TR;
	$disp.=$TD.$ST[$MYST]->{name};
	$disp.=$TD.$EMPHA[$ST[$MYST]->{emp}];
	$disp.=$TD.$VALUE[int($ST[$MYST]->{tr} /100*6)];
	$disp.=$TD.$VALUE[int($ST[$MYST]->{con} /100*6)];
	$disp.=$TD.$VALUE[int($ST[$MYST]->{wt} /100*6)];
	$disp.=$TD.$EVALUE[$ST[$MYST]->{sp}];
	$disp.=$TD.$EVALUE[$ST[$MYST]->{sr}];
	$disp.=$TD.$EVALUE[$ST[$MYST]->{ag}];
	$disp.=$TD.$EVALUE[$ST[$MYST]->{pw}];
	$disp.=$TD.$EVALUE[$ST[$MYST]->{hl}];
	$disp.=$TD.$EVALUE[$ST[$MYST]->{fl}];
	$disp.=$TD.($ST[$MYST]->{g1win} + 0)." - ".($ST[$MYST]->{g2win} + 0)." - ".($ST[$MYST]->{g3win} + 0)." - ".($ST[$MYST]->{sdwin} + 0);
	$cost=($ST[$MYST]->{sp} + $ST[$MYST]->{sr} + $ST[$MYST]->{ag} + $ST[$MYST]->{pw} + $ST[$MYST]->{hl} + $ST[$MYST]->{fl});
	$disp.=$TD.GetMoneyString($cost * $STcost);
	my $limit=$ST[$MYST]->{birth} + $STtime - $NOW_TIME;
	$disp.=$TD."남은 ".(($limit > 0) ? GetTime2found($limit) : "조금");
	$disp.=$TRE.$TBE."<br>";
	StableDragon();
	FormLarge();
}
1;

sub FormStable
{
my $estmsg=GetMoneyString($STest);
my $costmsg=GetMoneyString($STcost);
my $formemp;
	foreach (0..$#EMPHA)
	{
	$formemp.="<OPTION VALUE=\"$_\">$EMPHA[$_]";
	}
$disp.=<<STR;
<FORM ACTION="action.cgi" $METHOD>
<INPUT TYPE=HIDDEN NAME=key VALUE="slime-s">
<INPUT TYPE=HIDDEN NAME=bk VALUE="slime">
$USERPASSFORM
<INPUT TYPE=HIDDEN NAME=mode VALUE="stedit">
<INPUT TYPE=HIDDEN NAME=code VALUE="new">
<BIG>●마구간 설립</BIG>: <SELECT NAME=emp SIZE=1>
$formemp
</SELECT> 을 훈련 방침으로 하는 마구간에 <INPUT TYPE=TEXT NAME=name SIZE=20> 라고 이름을 붙여
<INPUT TYPE=SUBMIT VALUE='설치'>
</FORM>
<br>
$TB$TR$TD
·마구간을 설립하려면 자금 <b>$estmsg</b>이 필요합니다.<br>
·유지비는 최소한 매일 <b>$costmsg</b>이 필요합니다.<br>
·훈련 방침을 선택합니다. 나중에 변경할 수 없습니다.<br>
·마구간은 전체 <b>$STmax</b>개까지이며, 정원이 차면 설립할 수 없습니다.
$TBE
STR
}

sub StableDragon
{
	$disp.="<BIG>●위탁 중인 드래곤</BIG><br><br>";
	ReadDragon();
	$disp.="$TB$TR$TDB 명칭$TDB 나이$TDB 성별$TDB 컨디션$TDB 체중$TDB 총상금$TDB 성적$TRE";
	foreach(0..$#DR)
	{
	next if ($DR[$_]->{stable} != $ST[$MYST]->{no});
$disp.=$TR;
$disp.=$TD.GetTagImgDra($DR[$_]->{fm},$DR[$_]->{color}).$DR[$_]->{name};
$disp.=$TD.GetTime2found($NOW_TIME-$DR[$_]->{birth});
$disp.=$TD.$FM[$DR[$_]->{fm}];
$disp.=$TD.$EVALUE[int($DR[$_]->{con} /100*4)];
$disp.=$TD.$DR[$_]->{wt};
$disp.=$TD.($DR[$_]->{prize} + 0)."만";
$disp.=$TD.($DR[$_]->{g1win} + 0)." - ".($DR[$_]->{g2win} + 0)." - ".($DR[$_]->{g3win} + 0)." - ".($DR[$_]->{sdwin} + 0);
$disp.=$TRE;
	}
$disp.=$TBE."<br>";
}


sub FormLarge
{
my $n=int(($NOW_TIME - $ST[$MYST]->{birth})/86400/2) + 1;
if ($n < $cost)
	{
	$disp.="<BIG>●마구간 확장</BIG>: 아직 더 확장할 수 없습니다";
	return;
	}
my $estmsg=GetMoneyString($STest);
my @LARGE=(
	'트랙 코스 (스피드 향상)',
	'근성 훈련장 (승부근성 향상)',
	'순발 훈련장 (순발력 향상)',
	'더트 트랙 (파워 향상)',
	'온천 시설 (건강 향상)',
	'유연성 시설 (유연성 향상)'
);
my $formemp;
	foreach (0..$#LARGE)
	{
	$formemp.="<OPTION VALUE=\"$_\">$LARGE[$_]";
	}
$disp.=<<STR;
<FORM ACTION="action.cgi" $METHOD>
<INPUT TYPE=HIDDEN NAME=key VALUE="slime-s">
<INPUT TYPE=HIDDEN NAME=bk VALUE="slime">
$USERPASSFORM
<INPUT TYPE=HIDDEN NAME=mode VALUE="stedit">
<INPUT TYPE=HIDDEN NAME=code VALUE="large">
<BIG>●마구간 확장</BIG>: <SELECT NAME=lar SIZE=1>
$formemp
</SELECT>을 <INPUT TYPE=SUBMIT VALUE='확장'>
</FORM>
<br>
$TB$TR$TD
·마구간을 확장하려면 자금 <b>$estmsg</b>이 필요합니다.<br>
·확장하면 유지비가 더 많이 듭니다.<br>
·위탁 요금 수입보다 유지비가 커질 수 있으니 주의해 주세요.
$TBE
STR
}

