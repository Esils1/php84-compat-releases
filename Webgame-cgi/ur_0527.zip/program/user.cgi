#!/usr/bin/perl
BEGIN {
	*Utf8Text = sub {
		my($s)=@_;
		return '' unless defined $s;
		utf8::decode($s) unless utf8::is_utf8($s);
		return $s;
	} unless defined &Utf8Text;

	*Utf8InPlace = sub {
		utf8::decode($_[0]) if defined $_[0] && !utf8::is_utf8($_[0]);
	} unless defined &Utf8InPlace;
}
# 사용자정보변경처리 2005/03/30 유래

Lock();
DataRead();
CheckUserPass();
$Q{er}='other';

my $functionname=$Q{mode};
OutError("bad request") if !defined(&$functionname);
&$functionname;

RenewLog();
DataWrite();
DataCommitOrAbort();
UnLock();

OutSkin();
1;


sub comment
{

	$comment=Utf8Text($Q{cmt});

	if(($comment) =~ /([,:;\t\r\n<>&])/
	|| CheckNGName($comment)
	)
		{
		OutError('댓글에 사용할 수 없는 문자가 포함되어 있습니다.');
		}
	OutError('댓글은 36자 이내로 입력해 주세요.') if length($comment)>36;
	$comment=~s/&/&amp;/g;
	$comment=~s/>/&gt;/g;
	$comment=~s/</&lt;/g;
	utf8::encode($comment) if utf8::is_utf8($comment);
	$DT->{comment}=$comment;
	$disp.="댓글을 변경했습니다";
}

sub icon
{
	$DT->{icon}=$Q{icon};
	$disp.="점장 아이콘을 변경했습니다";
}

sub shopname
{
	OutError('자금이 부족합니다.') if $DT->{money}<50000;

	$Q{rename}=Utf8Text($Q{rename});
	if(($Q{rename}) =~ /([,:;\t\r\n<>&])/
	|| CheckNGName($Q{rename})
	)
		{
		OutError('상점명에 사용할 수 없는 문자가 포함되어 있습니다.');
		}
	OutError('상점명은20자 이내입니다.') if length($Q{rename})>20;
	OutError('상점명이 너무 짧습니다.') if length($Q{rename})<4;
	OutError('이미 존재하는 상점명입니다. -> '.$Q{rename}) if GetDoubleName($Q{rename});;
	PushLog(1,0,$DT->{shopname}."가 상점명을 '".$Q{rename}."'로 변경했습니다.");
	$DT->{shopname}=$Q{rename};
	$DT->{money}-=50000;
	$disp.=$DT->{shopname}."으로 개명했습니다.<BR>처음 화면에서 다시 로그인해 주세요.<BR><BR>";
	$disp.="<A HREF='index.cgi'>처음 화면으로</A>";
}

sub owname
{
	OutError('자금이 부족합니다.') if $DT->{money}<50000;

	$Q{owname}=Utf8Text($Q{owname});
	if(($Q{owname}) =~ /([,:;\t\r\n<>&])/
	|| CheckNGName($Q{owname})
	)
		{
		OutError('이름에 사용할 수 없는 문자가 포함되어 있습니다.');
		}
	OutError('이름은12자 이내입니다.') if length($Q{owname})>12;
	OutError('이름이 너무 짧습니다.') if length($Q{owname})<2;
	OutError('이미 존재하는 이름입니다. -> '.$Q{owname}) if $name2pass{$Q{owname}};
	PushLog(1,0,$DT->{name}."가 '".$Q{owname}."'로 개명했습니다.");
	$DT->{name}=$Q{owname};
	$DT->{money}-=50000;
	$disp.=$DT->{name}."으로 개명했습니다.<BR>처음 화면에서 다시 로그인해 주세요.<BR><BR>";
	$disp.="<A HREF='index.cgi?u=$DT->{name}'>처음 화면으로</A>";
}

sub repass
{
	OutError('확인 입력이 일치하지 않아 변경을 중단합니다.') if $Q{pw1}ne$Q{pw2};
	OutError('변경할 비밀번호가 입력되지 않았습니다.') if $Q{pw1}eq'';
	OutError('비밀번호에 사용할 수 없는 문자가 있어 변경을 중단합니다.') if $Q{pw1}=~/[^a-zA-Z0-9_\-]/;
	OutError('비밀번호는 8자 이내로 입력해 주세요.') if length($Q{pw1})>8;
	$DT->{pass}=$PASSWORD_CRYPT ? crypt($Q{pw1},GetSalt()) : $Q{pw1};
	$disp.="비밀번호를 변경했습니다<BR>처음 화면에서 다시 로그인해 주세요<BR><BR>";
	$disp.="<A HREF='index.cgi?nm=$DT->{name}&pw=$Q{pw1}'>처음 화면으로</A>";
}

sub restart
{
	OutError('재출발하려면 restart 라고 입력해 주세요.') if $Q{rss} ne 'restart';
	OutError('창업 후 3시간 이내에는 재출발할 수 없습니다') if (($NOW_TIME-$DT->{foundation}) < 3600*3);

	my ($id,$name,$shopname,$pass,$icon)=($DT->{id},$DT->{name},$DT->{shopname},$DT->{pass},$DT->{icon});
	while(my($key,$val)=each %$DT) { delete $DT->{$key}; }
	($DT->{id},$DT->{name},$DT->{shopname},$DT->{pass},$DT->{icon},$DT->{time})=($id,$name,$shopname,$pass,$icon);
	$DT->{status}	 =1;
	$DT->{lastlogin} =$NOW_TIME;
	$DT->{money} =100000;
	$DT->{rank} =5010;
	$DT->{foundation} =$NOW_TIME;
	$DT->{showcasecount}=1;
	require "$ITEM_DIR/funcnew.cgi" if $DEFINE_FUNCNEW;
	opendir(SESS,$SUBDATA_DIR);
	my @dir=readdir(SESS);
	closedir(SESS);
	foreach(map{"$SUBDATA_DIR/$_"}grep(/^$DT->{id}\-.+\.cgi$/,@dir))
	{
		unlink $_;
	}
	PushLog(1,0,$DT->{shopname}."가 새로 출발했습니다.");
	$disp.="데이터가 초기화되었습니다.<BR><BR>새 마음으로 다시 시작해 주세요.";
}

sub cls
{
	OutError('폐점하려면 closeshop 이라고 입력해 주세요.') if $Q{cls}ne'closeshop';
	SetCookieSession();
	$USERPASSURL=$USERPASSFORM="";
	CloseShop($DT->{id},'자진 폐점');
	PushLog(1,0,$DT->{shopname}."가폐점했습니다.");
	$disp.="폐점 절차가 완료되었습니다.<BR><BR>"
		 ."그동안 이용해 주셔서 감사합니다.";
	$DTblockip=$DT->{remoteaddr};
}

sub guild
{
	OutError('탈퇴하다에는 leave 라고 입력해 주세요') if $Q{guild} ne 'leave';
	OutError('길드에 가입되어 있지 않아 탈퇴할 필요가 없습니다') if !$DT->{guild};
	ReadGuild();
	my $name=$GUILD{$DT->{guild}}->[$GUILDIDX_name];
	$name="해산된 길드" if $name eq '';;
	PushLog(1,0,$DT->{shopname}."가 길드'".$name."'에서 탈퇴했습니다.");
	$disp.=$name."에서 탈퇴했습니다.";
	delete $DT->{user}{_so_e};
	$DT->{guild}="";
}

