#!/usr/bin/perl
# 드래곤 경주 레이스 전개 2005/03/30 유래

if ($NOW_TIME > $DRTIME[2]) { $rcode=1; } else { $rcode=0; }

ReadRace($rcode);

@MYRACE=@{$RACE[$rcode]};
@R=@{$MYRACE[$RDS[1]]};
undef $RACELOG;
if (!$RDS[0])
	{
	Entry();
	}
	else
	{
	my $functionname="Race".$RDS[0];
	&$functionname;
	}
WriteRaceLog($rcode,$RACELOG) if $RACELOG;
WriteRace($rcode);
WriteDrLast();
RenewDraLog();
CoDataCA();
CoUnLock();
1;


sub WriteRaceLog
{
	my($f,$message)=@_;
	$f||=0;
	my $fn=GetPath($COMMON_DIR,"dra-rlog$f");
	open(OUT,">>$fn") or return;
	print OUT $message;
	close(OUT);
}

sub Entry
{
	# 출전 드래곤 확정 처리
	ReadDragon();
	ReadJock();

	if (scalar @RD < 3)
		{
		# 출전 수가 3마리에 미달하면 전체 취소 처리
		foreach(0..$#RD)
			{
			my $id=$RD[$_]->{dr};
			$DR[$id2dra{$id}]->{race}=1 if (defined $id2dra{$id});

			$id=$RD[$_]->{jock};
			$JK[$id2jk{$id}]->{race}=1 if (defined $id2jk{$id});

			undef $RD[$_];

			}
		PushDraLog($rcode+1,$R[0]." 경주는 출전 드래곤 부족으로 개최가 보류되었습니다.");
		$DRTIME[$rcode+1]+=86400*2;
		$RDS[1]++;
		$RDS[1]=0 if ($RDS[1] > $#MYRACE);
		$RDS[2]=int(rand(2));
		}
		else
		{
		PushDraLog($rcode+1,$R[0]."의 출전 등록이 마감되었습니다.");
		# 출전 수가 정원을 초과하는 경우 추첨
		if (scalar @RD > $R[9])
			{
			foreach(0..$#RD) { $RD[$_]->{rnd}=($RD[$_]->{prize} * 10000) + int(rand(10000));}
			if ($rcode)
				{
				@RD=sort{$b->{rnd}<=>$a->{rnd}}@RD;	#전문 경주는 상금순 우선
				}
				else
				{
				@RD=sort{$a->{rnd}<=>$b->{rnd}}@RD;	#신입 경주는 상금 낮은 순 우선
				}
			foreach($R[9]..$#RD)
				{
				#탈락
				my $id=$RD[$_]->{dr};
				$DR[$id2dra{$id}]->{race}=1 if (defined $id2dra{$id});

				$id=$RD[$_]->{jock};
				$JK[$id2jk{$id}]->{race}=1 if (defined $id2jk{$id});
				undef $RD[$_];
				}
			PushDraLog($rcode+1,"출전 드래곤이 정원을 초과하여 추첨을 진행했습니다.");
			}

		#출전 처리
		my $num=$R[9] - 1;
		foreach(0..$num)
			{
			next if !$RD[$_]->{name};
			$RD[$_]->{no}=$_ + 1;	#번호 배정
			my $id=$RD[$_]->{dr};
			$DR[$id2dra{$id}]->{race}=3 if (defined $id2dra{$id});

			$id=$RD[$_]->{jock};
			$JK[$id2jk{$id}]->{race}=3 if (defined $id2jk{$id});
			}

		$DRTIME[$rcode+1]+=3600*2;
		$RDS[0]++;
		}
	my $fn=GetPath($COMMON_DIR,"dra-rlog$rcode");
	unlink $fn if -e $fn;				#과거의 실상황로그 삭제
	WriteDragon();
	WriteJock();
}

sub Race1
{
	# 인기의 결정
	foreach(0..$#RD) { $RD[$_]->{sumsp}=$RD[$_]->{prize}*100 + int(rand(100)); }
	@RD=sort{$b->{sumsp}<=>$a->{sumsp}}@RD;

	foreach(0..$#RD)
		{
		$RD[$_]->{pop}=$_ + 1;		#인기를 출력
		$RD[$_]->{time}+=int($R[5] * 1000 / 4 / $RD[$_]->{sp1});
		}
	@RD=sort{$a->{time}<=>$b->{time}}@RD;

	$RACELOG.="그럼 <b>".$R[0]."</b> 경주가 시작됩니다<br>\n";
	$RACELOG.="첫 출전 드래곤들이 도전장을 내밀었습니다<br>\n" if $R[1]==5;
	$RACELOG.="영광을 손에 넣을 드래곤은 누구일까요<br>\n" if $R[1]==0;
	$RACELOG.="이 코스의 종반에는 언덕이 있어 난전이 될 수 있습니다<br>\n" if $R[4];
	$RACELOG.="지금 스타트합니다<br>\n";

	if ($RD[0]->{strate}< 2)
		{
		$RACELOG.="선두에 나선 것은 <b>".GetTagImgDra($RD[0]->{fm},$RD[0]->{color}).$RD[0]->{name}."</b><br>\n";
		$RACELOG.="대체로 예상대로의 전개입니다<br>\n";
		}
		else
		{
		$RACELOG.="무려 <b>".GetTagImgDra($RD[0]->{fm},$RD[0]->{color}).$RD[0]->{name}."</b>가 단숨에 선두로 나섰습니다<br>\n";
		$RACELOG.="이것은 작전일까요<br>\n";
		}

	#임의１머리를 소개
	my $i=int(rand($#RD))+1;
	$RACELOG.="현재 ".($i + 1)."번째로 달리고 있는 드래곤은 ".$RD[$i]->{no}."번 <b>".GetTagImgDra($RD[$i]->{fm},$RD[$i]->{color}).$RD[$i]->{name}."</b><br>\n";
	if ($RD[$i]->{pop} < 4)
		{
		$RACELOG.=$RD[$i]->{pop}."번 인기의 기대를 받으며 이 위치에서 승리를 노립니다<br>\n";
		}
		else
		{
		$RACELOG.="인기는 ".$RD[$i]->{pop}."번이지만 결과를 뒤집을 복병이 될 수 있을까요<br>\n";
		}

	$DRTIME[$rcode+1]+=3600*8;
	$RDS[0]++;
}

sub Race2
{
	my $no=$RD[0]->{no};	#이전의１위를 제어해서둠
	foreach(0..$#RD)
		{
		$RD[$_]->{time}+=int($R[5] * 1000 / 4 / $RD[$_]->{sp2});
		}
	@RD=sort{$a->{time}<=>$b->{time}}@RD;

	$RACELOG.="첫 번째 코너를 돌았습니다<br>\n";
	if ($no == $RD[0]->{no})
		{
		$RACELOG.="현재 선두는 변함없이 <b>".GetTagImgDra($RD[0]->{fm},$RD[0]->{color}).$RD[0]->{name}."</b><br>\n";
		$RACELOG.="이 기세가 마지막까지 이어질까요<br>\n";
		}
		else
		{
		$RACELOG.="여기서 선두가 바뀝니다. ";
		$RACELOG.="선두는 <b>".GetTagImgDra($RD[0]->{fm},$RD[0]->{color}).$RD[0]->{name}."</b><br>\n";
		}

	#경주 전개 판정 미구현
	$RACELOG.="중간 ".($R[5] / 2)."kmkm 통과 타임은 ".GetRaceTime($RD[0]->{time})."<br>\n";
	$RACELOG.="거의 평균적인 흐름입니다. 전개에 큰 영향은 없어 보입니다<br>\n";

	#차시말의１머리를 소개
	my $i=int(rand($#RD))+1;
	foreach(1..$#RD)
		{
		$i=$_,last if ($RD[$_]->{strate}==2 || $RD[$_]->{strate}==3);
		}
	$RACELOG.="<b>".GetTagImgDra($RD[$i]->{fm},$RD[$i]->{color}).$RD[$i]->{name}."</b> 좋은 위치입니다. 여기서 선두를 노릴 수 있을까요<br>\n";

	$DRTIME[$rcode+1]+=3600*8;
	$RDS[0]++;
}

sub Race3
{
	my $no=$RD[0]->{no};
	foreach(0..$#RD)
		{
		$RD[$_]->{time}+=int($R[5] * 1000 / 4 / $RD[$_]->{sp3});
		}
	@RD=sort{$a->{time}<=>$b->{time}}@RD;

	$RACELOG.="후속 드래곤들이 차이를 좁혀 옵니다<br>\n";
	if ($no == $RD[0]->{no})
		{
		$RACELOG.="자, 어떻게 될까요. ";
		$RACELOG.="선두는 변함없이 <b>".GetTagImgDra($RD[0]->{fm},$RD[0]->{color}).$RD[0]->{name}."</b><br>\n";
		$RACELOG.="이대로 도주할 수 있을까요. ";
		}
		else
		{
		$RACELOG.="<b>".GetTagImgDra($RD[0]->{fm},$RD[0]->{color}).$RD[0]->{name}."</b>가 앞질렀습니다!<br>\n";
		$RACELOG.="자, 어떻게 될까요. ";
		}
	$RACELOG.="뒤를 추격하는 것은 <b>".GetTagImgDra($RD[1]->{fm},$RD[1]->{color}).$RD[1]->{name}."</b><br>\n";

	#차시말의１머리를 소개
	my $i=int(rand($#RD))+1;
	foreach(2..$#RD)
		{
		$i=$_,last if ($RD[$_]->{strate}==2 || $RD[$_]->{strate}==3);
		}
	$RACELOG.="<b>".GetTagImgDra($RD[$i]->{fm},$RD[$i]->{color}).$RD[$i]->{name}."</b> 좋은 발놀림입니다. 승부가 어떻게 될까요<br>\n";

	$DRTIME[$rcode+1]+=3600*6;
	$RDS[0]++;
}

sub Race4
{
	my $no=$RD[0]->{no};
	foreach(0..$#RD)
		{
		$RD[$_]->{time}+=int($R[5] * 1000 / 4 / $RD[$_]->{sp4});
		}
	@RD=sort{$a->{time}<=>$b->{time}}@RD;

	my $name1=GetTagImgDra($RD[0]->{fm},$RD[0]->{color})."<b>".$RD[0]->{name}."</b>";
	my $name2=GetTagImgDra($RD[1]->{fm},$RD[1]->{color})."<b>".$RD[1]->{name}."</b>";

	$RACELOG.="마지막 코너를 돌아 직선에 들어섭니다<br>\n";
	if ($no == $RD[0]->{no})
			{
			# 선두 변동 없음
			$RACELOG.="자, 어떻게 될까요. ";
			$RACELOG.="$name2가 추격합니다<br>\n";
			$RACELOG.="$name1가 달아납니다. 이대로 도주할 수 있을까요<br>\n";

			if ($RD[1]->{time} - $RD[0]->{time} < 15)
				{
				$RACELOG.="$name2가 압박합니다! 그러나 $name1도 버팁니다!<br>\n";
				$RACELOG.="$name1입니다! 끝까지 도주에 성공했습니다! 승자는 $name1!<br>\n";
				}
				else
				{
				$RACELOG.="$name1가 차이를 벌립니다!<br>\n";
				$RACELOG.="$name1! 강했습니다! 승자는 $name1!<br>\n";
				}
			}
		elsif ($no == $RD[1]->{no})
			{
			# ２도착
			$RACELOG.="자, 어떻게 될까요. ";
			$RACELOG.="$name1가 추격합니다<br>\n";
			$RACELOG.="$name2가 달아납니다. 이대로 도주할 수 있을까요<br>\n";
			if ($RD[1]->{time} - $RD[0]->{time} < 15)
				{
				$RACELOG.="$name1가 압박합니다! $name2가 버팁니다!<br>\n";
				$RACELOG.="$name1가 앞질렀습니다!<br>\n";
				$RACELOG.="$name2 한 걸음 미치지 못했습니다! 승자는 $name1!<br>\n";
				}
				else
				{
				$RACELOG.="$name1가 앞질렀습니다!<br>\n";
				$RACELOG.="$name1 추가로가 차이를 벌립니다!<br>\n";
				$RACELOG.="$name1! 강했습니다! 승자는 $name1!<br>\n";
				}
			}
		else
			{
			# 선두 확정 후 전체 교대
			$RACELOG.="자, 어떻게 될까요. ";
			$RACELOG.="$name2가 앞질렀습니다!<br>\n";
			$RACELOG.="그리고 <b>$name1</b>이 뒤를 쫓습니다!<br>\n";
			if ($RD[1]->{time} - $RD[0]->{time} < 15)
				{
				$RACELOG.="$name1가 압박합니다! $name2가 버팁니다!<br>\n";
				$RACELOG.="$name1가 앞질렀습니다!<br>\n";
				$RACELOG.="$name2 한 걸음 미치지 못했습니다! 승자는 $name1!<br>\n";
				}
				else
				{
				$RACELOG.="$name1가 단숨에 앞질렀습니다!<br>\n";
				$RACELOG.="$name1 추가로가 차이를 벌립니다!<br>\n";
				$RACELOG.="$name1! 강했습니다! 승자는 $name1!<br>\n";
				}
			}

	ReadDragon();
	ReadJock();
	ReadRanch();
	ReadStable();

	# 선두
	PushDraLog($rcode+1,$R[0]."에서 '".$RD[0]->{name}."'가 우승했습니다.");

	my $id=$RD[0]->{dr};
	if (defined $id2dra{$id})
		{
		my $i=$id2dra{$id};
		$DR[$i]->{gr}+=80;
		$DR[$i]->{prize}+=$R[6];

		WritePayLog($DR[$i]->{town},$DR[$i]->{owner},$R[6]*10000);

		if ($R[1] > 2) { $DR[$i]->{sdwin}++;}
		elsif ($R[1]==2) { $DR[$i]->{g3win}++;}
		elsif ($R[1]==1) { $DR[$i]->{g2win}++;}
		else { $DR[$i]->{g1win}++;}
		}

	# 선두기수
	my $id=$RD[0]->{jock};
	if (defined $id2jk{$id})
		{
		my $i=$id2jk{$id};
		$JK[$i]->{sp}=int(rand(scalar @JKSP)) if !$JK[$i]->{sp};

		# 선택한 작전에 따라 능력 상승
		if ($RD[0]->{str} > 1)
			{
			$JK[$i]->{back}+=15;
			$JK[$i]->{back}=100 if ($JK[$i]->{back} > 100);
			}
			else
			{
			$JK[$i]->{ahead}+=15;
			$JK[$i]->{ahead}=100 if ($JK[$i]->{ahead} > 100);
			}
		if ($R[1] > 2) { $JK[$i]->{sdwin}++;}
		elsif ($R[1]==2) { $JK[$i]->{g3win}++;}
		elsif ($R[1]==1) { $JK[$i]->{g2win}++;}
		else { $JK[$i]->{g1win}++;}
		}

	# 선두목장
	my $id=$RD[0]->{ranch};
	if (defined $id2rc{$id})
		{
		my $i=$id2rc{$id};
		$RC[$i]->{prize}+=$R[6];
		if ($R[1] > 2) { $RC[$i]->{sdwin}++;}
		elsif ($R[1]==2) { $RC[$i]->{g3win}++;}
		elsif ($R[1]==1) { $RC[$i]->{g2win}++;}
		else { $RC[$i]->{g1win}++;}
		}

	# 선두마구간
	my $id=$RD[0]->{stable};
	if (defined $id2st{$id})
		{
		my $i=$id2st{$id};
		$ST[$i]->{tr}+=int(rand(20));
		$ST[$i]->{tr}=100 if ($ST[$i]->{tr} > 100);
		$ST[$i]->{con}+=int(rand(20));
		$ST[$i]->{con}=100 if ($ST[$i]->{con} > 100);
		$ST[$i]->{wt}+=int(rand(20));
		$ST[$i]->{wt}=100 if ($ST[$i]->{wt} > 100);

		if ($R[1] > 2) { $ST[$i]->{sdwin}++;}
		elsif ($R[1]==2) { $ST[$i]->{g3win}++;}
		elsif ($R[1]==1) { $ST[$i]->{g2win}++;}
		else { $ST[$i]->{g1win}++;}
		}

	# ２도착
	my $id=$RD[1]->{dr};
	if (defined $id2dra{$id})
		{
		my $i=$id2dra{$id};
		$DR[$i]->{gr}+=40;
		$DR[$i]->{prize}+=$R[7];

		WritePayLog($DR[$i]->{town},$DR[$i]->{owner},$R[7]*10000);
		}

	# ２도착목장
	my $id=$RD[1]->{ranch};
	if (defined $id2rc{$id})
		{
		my $i=$id2rc{$id};
		$RC[$i]->{prize}+=$R[7];
		}

	# ３도착
	my $id=$RD[2]->{dr};
	if (defined $id2dra{$id})
		{
		my $i=$id2dra{$id};
		$DR[$i]->{gr}+=20;
		$DR[$i]->{prize}+=$R[8];

		WritePayLog($DR[$i]->{town},$DR[$i]->{owner},$R[8]*10000);
		}

	# ３도착목장
	my $id=$RD[2]->{ranch};
	if (defined $id2rc{$id})
		{
		my $i=$id2rc{$id};
		$RC[$i]->{prize}+=$R[8];
		}

	$RACELOG.="<br>";
	foreach(0..$#RD)
		{
		$RACELOG.=($_ + 1)."착 ".GetRaceTime($RD[$_]->{time});
		$RACELOG.=" ".$STRATE[ $RD[$_]->{str} ]." ";
		$RACELOG.=GetTagImgDra($RD[$_]->{fm},$RD[$_]->{color}).$RD[$_]->{name};
		$RACELOG.=" <small>(".$RD[$_]->{lose}.")</small>" if $_;
		$RACELOG.="<br>";
		my $id=$RD[$_]->{dr};
		if (defined $id2dra{$id})
			{
			my $i=$id2dra{$id};
			$DR[$i]->{race}=0;
			$DR[$i]->{con}-=40;
			$DR[$i]->{con}=0 if ($DR[$i]->{con} < 0);

			$DR[$i]->{wt}-=4;
			$DR[$i]->{wt}=38 if ($DR[$i]->{wt} < 38);
			}
		$id=$RD[$_]->{jock};
		$JK[$id2jk{$id}]->{race}=0 if (defined $id2jk{$id});

		undef $RD[$_];
		}
	WriteDragon();
	WriteJock();
	WriteRanch();
	WriteStable();

	$DRTIME[$rcode+1]=$NOW_TIME + 86400 -(($NOW_TIME + $TZ_JST - $DRTIMESET[$rcode+1] * 3600) % 86400);
	$RDS[0]=0;
	$RDS[1]++;
	$RDS[1]=0 if ($RDS[1] > $#MYRACE);
	$RDS[2]=int(rand(2));
}

