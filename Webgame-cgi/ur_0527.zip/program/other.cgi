#!/usr/bin/perl
# 각종절차 2005/01/06 유래

DataRead();
CheckUserPass();
RequireFile('inc-html-ownerinfo.cgi');

$disp.="<BIG>●각종절차</BIG><br><br>";

$disp.=<<STR;
<FORM ACTION="action.cgi" $METHOD>
<INPUT TYPE=HIDDEN NAME=key VALUE=user>
<INPUT TYPE=HIDDEN NAME=mode VALUE=comment>
$USERPASSFORM
<SPAN>댓글</SPAN>
<INPUT TYPE=TEXT NAME=cmt SIZE=36 VALUE="$DT->{comment}">
<INPUT TYPE=SUBMIT VALUE="변경하다">
</FORM>
STR

$i_rand=int(rand($ICON_NUMBER))+1;
$disp.=<<STR;
<hr width=500 noshade size=1>
<FORM ACTION="action.cgi" $METHOD>
<INPUT TYPE=HIDDEN NAME=key VALUE=user>
<INPUT TYPE=HIDDEN NAME=mode VALUE=icon>
$USERPASSFORM
<SPAN>점장아이콘변경</SPAN>:
<input type="button" value="아이콘 목록" onclick="javascript:window.open('action.cgi?key=icon','_blank','width=450,height=380,scrollbars')">
<SELECT NAME=icon>
<OPTION value="$i_rand" selected>무작위</OPTION>
STR

foreach my $i(1..$ICON_NUMBER)
	{
	$disp.=qq|<OPTION value="$i">이미지$i</OPTION>|;
	}

$disp.=<<"STR";
</SELECT>
<INPUT TYPE=SUBMIT VALUE="변경하다">
</FORM>
STR

$disp.=<<STR;
<hr width=500 noshade size=1>
<FORM ACTION="action.cgi" $METHOD>
<INPUT TYPE=HIDDEN NAME=key VALUE=user>
<INPUT TYPE=HIDDEN NAME=mode VALUE=shopname>
$USERPASSFORM
<SPAN>상점 이름 변경</SPAN>(변경 비용 $term[0]50,000$term[1])
<INPUT TYPE=TEXT NAME=rename SIZE=30 VALUE="">
<INPUT TYPE=SUBMIT VALUE="개명하다">
</FORM>
STR

$disp.=<<STR;
<hr width=500 noshade size=1>
<FORM ACTION="action.cgi" $METHOD>
<INPUT TYPE=HIDDEN NAME=key VALUE=user>
<INPUT TYPE=HIDDEN NAME=mode VALUE=owname>
$USERPASSFORM
<SPAN>점장 이름 변경</SPAN>(변경 비용 $term[0]50,000$term[1])
<INPUT TYPE=TEXT NAME=owname SIZE=20 VALUE="">
<INPUT TYPE=SUBMIT VALUE="개명하다">
</FORM>
STR

$disp.=<<STR;
<hr width=500 noshade size=1>
<FORM ACTION="action.cgi" $METHOD>
<INPUT TYPE=HIDDEN NAME=key VALUE=user>
<INPUT TYPE=HIDDEN NAME=mode VALUE=repass>
$USERPASSFORM
<SPAN> 비밀번호 변경</SPAN> :
<INPUT TYPE=TEXT NAME=pw1 SIZE=10 maxlength=12 VALUE="">신경로
<INPUT TYPE=TEXT NAME=pw2 SIZE=10 maxlength=12 VALUE="">신경로 재입력
<INPUT TYPE=SUBMIT VALUE="변경하다">
</FORM>
STR


if ( ($NOW_TIME-$DT->{foundation}) > 3600*3 ) {
$disp.=<<STR;
<hr width=500 noshade size=1>
<FORM ACTION="action.cgi" $METHOD>
<INPUT TYPE=HIDDEN NAME=key VALUE=user>
<INPUT TYPE=HIDDEN NAME=mode VALUE=restart>
$USERPASSFORM
<BIG>●재출발(다시 시도시)</BIG> :
<INPUT TYPE=TEXT NAME=rss SIZE=10 maxlength=12 VALUE=""> 확인 때문에 restart 라고 입력
<INPUT TYPE=SUBMIT VALUE="다시 시도스">
</FORM>
STR
} else {
$disp.=<<STR;
<hr width=500 noshade size=1>
<BIG>●재출발(다시 시도시)</BIG> :
<b>창업 후 3시간 이내에는 재출발할 수 없습니다</b>
STR
}

$disp.=<<STR;
<hr width=500 noshade size=1>
<FORM ACTION="action.cgi" $METHOD>
<INPUT TYPE=HIDDEN NAME=key VALUE=user>
<INPUT TYPE=HIDDEN NAME=mode VALUE=cls>
$USERPASSFORM
<BIG>●폐점(재등록불가)</BIG> :
<INPUT TYPE=TEXT NAME=cls SIZE=10 maxlength=12 VALUE=""> 확인 때문에 closeshop 라고 입력
<INPUT TYPE=SUBMIT VALUE="점지마이">
</FORM>
STR

OutSkin();
1;
