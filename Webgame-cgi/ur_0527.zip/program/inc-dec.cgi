#!/usr/bin/perl
BEGIN {
	*Utf8Text = sub {
		my($s)=@_;
		return '' unless defined $s;
		utf8::decode($s) unless utf8::is_utf8($s);
		return $s;
	} unless defined &Utf8Text;

	*Utf8InPlace = sub {
		utf8::decode($_[0]) if defined $_[0] && !utf8::is_utf8($_[0]);
	} unless defined &Utf8InPlace;
}
# 특수 디코드 2003/09/25 유래

OutError("전송 크기가 너무 큽니다") if ($ENV{'CONTENT_LENGTH'} > 10240);

binmode(STDIN);
my $Boundary = <STDIN>;
$Boundary =~ s/\x0D\x0A//;
while (<STDIN>) {
	if (/^\s*Content-Disposition:/i) {
		my $Name;
		# 양식의 항목이름을 얻기루
		if (/\bname="([^"]+)"/i or /\bname=([^\s:;]+)/i) {
			$Name = $1;
		}
		# 파일 이름을 가져오기
		if (/\bfilename="([^"]*)"/i or /\bfilename=([^\s:;]*)/i) {
			$FILENAME{$Name} = $1 || 'unknown';
		}
		# 헤더 내용을 읽어들임
		# 헤더의 종료를 표시스공줄을 검출했다고루프를 빼기하기
		while (<STDIN>) {
			last if (not /\w/);
			if (
				/^\s*Content-Type:\s*"([^"]+)"/i
				or /^\s*Content-Type:\s*([^\s:;]+)/i
			) {
			$MIMETYPE{$Name} = $1;
			}
		}
		# 데이터본체를 읽어들임
		# 데이터의 종료를 표시스 Boundary 을검출했다고루프를 빼기하기
		while (<STDIN>) {
			last if (/^\Q$Boundary\E/);
			$Q{$Name} .= $_;
		}
		$Q{$Name} =~s /\x0D\x0A$//; # 끝의\r\n을 처리제외쿠
		if ($Q{$Name}) {
			# 파일의 경우
			if ($FILENAME{$Name} or $MIMETYPE{$Name}) {
				# MacBinary 을검출하고삭제
				if (
					$MIMETYPE{$Name}
					=~ /^application\/(x-)?macbinary$/i
				) {
				# Header 토끝의 리소스를 삭제
					$Q{$Name} = substr(
						$Q{$Name},
						128,
						unpack("N", substr($Q{$Name}, 83, 4))
					);
				}
			}
			# 파일이외의 경우
			else {
				Utf8InPlace($Q{$Name});
				$Q{$Name} =~ s/&/&amp;/g;
				$Q{$Name} =~ s/"/&quot;/g;
				$Q{$Name} =~ s/</&lt;/g;
				$Q{$Name} =~ s/>/&gt;/g;
				$Q{$Name} =~ s/\x0D\x0A/<br>/g;
				$Q{$Name} =~ s/\x0D/<br>/g;
				$Q{$Name} =~ s/\x0A/<br>/g;
			}
		}
	}
	# Boundary 을검출했다고루프를 빼기하기
	last if (/^\Q$Boundary--\E/);
}
	@Q{qw(nm pw ss)}=split(/!/,$Q{u},3) if exists $Q{u};
1;
