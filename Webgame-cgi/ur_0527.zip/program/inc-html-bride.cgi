#!/usr/bin/perl
# 주택 목록표시 2005/03/30 유래

if ($Q{form} eq "pro" && !$GUEST_USER)
{
ProposeForm();
}
elsif ($Q{form} && !$GUEST_USER)
{
ConstForm();
}
else
{
BrideList();
}
1;

sub BrideList
{
my $i;
if (!$GUEST_USER && !$married)
{
$i="<br><a href=\"action.cgi?key=bride&form=pro&$USERPASSURL\">[청혼하기]</a>";
}

$disp.=<<STR;
$TBT$TRT$TD
<IMG width="96" height="192" SRC="$IMAGE_URL/map/church.png"><td width=10>$TD
$image[3]
<SPAN>신부</SPAN><br>
결혼에 대해 알고 계신가요?<br>
결혼하고 주택을 건설하면, 그곳에 보유 물품을 보관할 수 있습니다.<br>
주택을 보유하기 전까지는 이 교회의 보관함을 사용할 수 없습니다.<br>
소중한 사람과 함께 지낼 수 있는 곳을 마련해 보세요.$i
$TRE$TBE<br>
$TB$TR
$TDB 점수
$TDB 상태
$TDB 상세
$TDB 일수
$TDB 보관품
$TRE
STR
@BRIDE=sort{$b->{point}<=>$a->{point}}@BRIDE;
foreach my $i(0..$Scount) {
	next if ($BRIDE[$i]->{mode}==-1) || !defined($BRIDE[$i]->{no});
	my ($ida,$idb)=($BRIDE[$i]->{ida},$BRIDE[$i]->{idb});
	$disp.=($DT->{id} == $ida || $DT->{id} == $idb) ? $TR.$TDB : $TR.$TD;
	$disp.='<b>No.'.($i+1).'</b><br>'.$BRIDE[$i]->{point}.'<td>';
	$disp.= "<a href=\"action.cgi?key=bride&no=$BRIDE[$i]->{no}&$USERPASSURL\">" if (!$GUEST_USER);

	if (!$BRIDE[$i]->{mode})
	{
	$disp.=$image[2];
	$disp.= "</a>" if (!$GUEST_USER);
	$disp.='<td>'.$DT[$id2idx{$ida}]->{shopname}.' 부터 <SPAN>'.$DT[$id2idx{$idb}]->{shopname}."</SPAN> 로";
	}
	else
	{
	$disp.=($BRIDE[$i]->{mode}==1)?$image[0]:$image[1];
	$disp.= "</a>" if (!$GUEST_USER);
	$disp.='<td>'.$DT[$id2idx{$ida}]->{shopname}.' ＆ '.$DT[$id2idx{$idb}]->{shopname};
	}
	$disp.="<td align=center>".GetTime2found($NOW_TIME-$BRIDE[$i]->{tm});
	$disp.='<td>'.GetMoneyMessage($BRIDE[$i]->{money}).'<br>';
	foreach (0..$BRIDE[$i]->{mode}-1) { $disp.=GetTagImgItemType($BRIDE[$i]->{stock}[$_]);}
	}
$disp.=$TRE.$TBE;
}

sub ProposeForm
{
	OutError("bad request") if $married;
	$userselect="";
	foreach my $DTS (@DT)
	{
		$userselect.="<OPTION VALUE=\"$DTS->{id}\">$DTS->{name} ($DTS->{shopname})";
	}
$disp.=<<STR;
$TB$TR$TD
$image[3]
신부: 가족을 갖기를 원하십니까? 그렇다면 다음 주의 사항을 잘 읽어 주세요.<br>
·새 집에는 결혼 자금이 <b>500만$term[2]</b>걸립니다.<br>
·결혼 상대는 신중하게 선택하세요. 그 사람과 함께할 수 있을지 잘 생각해 보세요.<br>
·사전에잘이나 기시합이나세요. 갑자기 청혼하면 상대가 곤란할 수 있습니다.<br>
·청혼을 했습니다측이부으로 리, 수자리측이아내가 됩니다.
$TRE$TBE<br>
<form action="action.cgi" $METHOD>
$MYFORM$USERPASSFORM
<INPUT TYPE=HIDDEN NAME=mode VALUE="new">
<BIG>●청혼</BIG>:나 $DT->{name} ($DT->{shopname})은
<SELECT NAME=tg>$userselect</SELECT>을 아내와 시<br>
건강할 때도 병들 때도 서로 함께할 것을
<INPUT TYPE=SUBMIT VALUE='맹 있습니다'>
</FORM>
STR
}

sub ConstForm
{
$disp.=<<STR;
$TB$TR$TD
$image[3]
신부: 주택을 건설해 두셨습니까? 그렇다면 다음 주의 사항을 잘 읽어 주세요.<br>
·자금 <b>1500만$term[2]</b>이 필요합니다. 공동 창고에서 지급됩니다.<br>
·한 번건설테하면장소를 이동루것은 할 수 없습니다.<br>
$TRE$TBE
<form action="action.cgi" $METHOD>
$MYFORM$USERPASSFORM
<INPUT TYPE=HIDDEN NAME=mode VALUE="con">
<INPUT TYPE=HIDDEN NAME=idx VALUE="$Q{idx}">
<INPUT TYPE=HIDDEN NAME=place VALUE="$Q{form}">
<BIG>●주택건설건축</BIG>:지정의 장소에주택을
<INPUT TYPE=SUBMIT VALUE='건설건축하다'>
</FORM>
STR
}
