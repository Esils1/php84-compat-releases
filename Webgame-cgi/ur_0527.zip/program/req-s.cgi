#!/usr/bin/perl
# 의뢰처리 2005/03/30 유래

Lock();
DataRead();
CheckUserPass();
RequireFile('inc-req.cgi');

$disp.="<BIG>●의뢰소</BIG><br><br>";

my $functionname=$Q{mode};
OutError("bad request") if !defined(&$functionname);
&$functionname;

$disp.="<br><br>".$TBT.$TRT.$TD.GetTagImgJob($DT->{job},$DT->{icon});
$disp.=$TD.GetMenuTag('stock',	'[창고로]');
$disp.=GetMenuTag('req','[계속 의뢰 보기]');
$disp.=$TRE.$TBE;

WriteAuc();
DataWrite();
DataCommitOrAbort();
UnLock();
OutSkin();
1;


sub new
{
	my ($numrate,$prrate);
	$itemno=$Q{it};
	$num=CheckCount($Q{num},0,0,$MAX_MONEY);
	$prn=$Q{prn};
	$pr=CheckCount($Q{pr},0,0,$MAX_MONEY);
	$pr=$pr * $num if ($Q{unit})&&($prn < 0);
	$num=$num * $pr if ($Q{unit})&&($itemno < 0);
	OutError($AucImg.'의뢰품의 개수나 가격을 입력해 주세요.') if ($pr < 1) ;
	OutError($AucImg.'보상 상품의 개수나 가격을 입력해 주세요.') if ($num < 1) ;
	if ($itemno > 0) {
		OutError($AucImg.'보유 수량이 부족합니다.') if ($DT->{item}[$itemno-1] < $num) ;
		OutError($AucImg.'그 물품은 출품할 수 없습니다.') if ($ITEM[$itemno]->{flag}=~/r/) ;	# r 의뢰불가
		$numrate=$ITEM[$itemno]->{price} * $num;
		} else {
		OutError($AucImg.'보유 수량이 부족합니다.') if ($DT->{money} < $num);
		$numrate=$num;
		}
	OutError($AucImg.'의뢰품과 보상 상품이 같으면 거래할 수 없습니다.') if ($itemno == $prn) ;
	if ($prn > 0) {
		OutError($AucImg.'의뢰품의 개수가 너무 많아 달성할 수 없습니다.') if ($pr > $ITEM[$prn]->{limit}) ;
		OutError($AucImg.'그 물품은 의뢰할 수 없습니다.') if ($ITEM[$prn]->{flag}=~/r/)||($ITEM[$prn]->{flag}=~/o/);	# o 출품의 미
		$prrate=$ITEM[$prn]->{price} * $pr;
		} else {
		$prrate=$pr;
		}
	OutError($AucImg.'의뢰품과 보상의 가치가 맞지 않습니다. 조건을 다시 확인해 주세요.') if ($prrate > $numrate * 2) || ($numrate > $prrate * 2);

	my @list=map{$_->{id}}@REQ;
	@list=grep($_ eq $DT->{id},@list);
	OutError($AucImg.'더 이상 의뢰를 등록할 수 없습니다.') if (scalar(@list) >= $REQUEST_CAPACITY);

	@REQ=reverse(@REQ);
	$Scount++;
	my $i=$Scount;
	$REQ[$i]->{no}=($i > 0) ? ($REQ[$i-1]->{no} + 1) : 1;
	$REQ[$i]->{id}=$Q{id};
	$REQ[$i]->{mode}=0;
	$REQ[$i]->{tm}=$NOW_TIME + $REQUEST_LIMIT;
	($REQ[$i]->{itemno},$REQ[$i]->{num},$REQ[$i]->{prn},$REQ[$i]->{pr})=($itemno,$num,$prn,$pr);
	@REQ=reverse(@REQ);

	$DT->{item}[$itemno-1]-=$num if ($itemno > 0);
	$DT->{money}-=$num , $DT->{paytoday}+=$num if ($itemno < 0);

	my $cost=0;
	$cost=int($num * $DTTaxrate / 100) if ($itemno < 0);
	$cost=int($pr * $DTTaxrate / 100) if ($prn < 0);
	OutError($AucImg.'자금이 부족하여 세금을 낼 수 없습니다.') if ($cost > $DT->{money});
	$DT->{taxtoday}+=$cost;
	$DT->{money}-=$cost;
	$disp.=$AucImg.'의뢰를 작성했습니다. 빨리 달성되면 좋겠습니다.';
}

sub plus
{
	$i=SearchReqIndex($Q{idx});
	OutError('지정한 거래는 존재하지 않습니다') if ($i==-1);
	my($itemno,$num,$prn,$pr,$mode)=($REQ[$i]->{itemno},$REQ[$i]->{num},$REQ[$i]->{prn},$REQ[$i]->{pr},$REQ[$i]->{mode});
	OutError($AucImg.'이 거래는 이미 달성되었습니다. 다음 의뢰를 이용해 주세요.') if defined($id2idx{$mode});
	OutError($AucImg.'보유 수량이 부족합니다.') if ($prn > 0)&&($DT->{item}[$prn-1] < $pr) ;
	OutError($AucImg.'보유 수량이 부족합니다.') if ($prn < 0)&&($DT->{money} < $pr) ;

	$DT->{item}[$prn-1]-=$pr if ($prn > 0);
	$DT->{money}-=$pr, $DT->{paytoday}+=$pr if ($prn < 0);

	if ($itemno > 0)
		{
		$DT->{item}[$itemno-1]+=$num;
		$DT->{item}[$itemno-1]=$ITEM[$itemno]->{limit} if ($DT->{item}[$itemno-1]>$ITEM[$itemno]->{limit});
		$disp.=$AucImg.'보상은 '.$ITEM[$itemno]->{name}.' '.$num.$ITEM[$itemno]->{scale}.'입니다. 감사합니다!';
		}
	else
		{
		$DT->{money}+=$num;
		$DT->{saletoday}+=$num;
		$DT[$id2idx{$id}]->{paytoday}+=$pr if defined($id2idx{$id});
		$disp.=$AucImg.'보상은 '.GetMoneyString($num).'입니다. 감사합니다!';
		}
	$REQ[$i]->{mode}=$DT->{id};
}

sub end
{
	$i=SearchReqIndex($Q{idx});
	OutError('지정한 거래는 존재하지 않습니다') if ($i==-1);
	my($itemno,$num)=($REQ[$i]->{itemno},$REQ[$i]->{num});

	if ($itemno> 0)
		{
		$DT->{item}[$itemno-1]+=$num;
		$DT->{item}[$itemno-1]=$ITEM[$itemno]->{limit} if ($DT->{item}[$itemno-1]>$ITEM[$itemno]->{limit});
		}
		else
		{
	$DT->{money}+=$num;
		}

	undef $REQ[$i];
	$disp.=$AucImg.'이번 의뢰를 취소했습니다. 다음에 또 이용해 주세요.';
}

sub thank
{
	$i=SearchReqIndex($Q{idx});
	OutError('지정한 거래는 존재하지 않습니다') if ($i==-1);
	OutError('잘못된 요청입니다') if ($REQ[$i]->{id} != $DT->{id});
	my($no,$itemno,$num,$prn,$pr,$mode)=($REQ[$i]->{no},$REQ[$i]->{itemno},$REQ[$i]->{num},$REQ[$i]->{prn},$REQ[$i]->{pr},$REQ[$i]->{mode});

	if ($prn > 0) {
		$DT->{item}[$prn-1]+=$pr;
		$DT->{item}[$prn-1]=$ITEM[$prn]->{limit} if ($DT->{item}[$prn-1]>$ITEM[$prn]->{limit});
		$disp.=$AucImg.'의뢰품은 '.$ITEM[$prn]->{name}.' '.$pr.$ITEM[$prn]->{scale}.'입니다.<br>';
		$disp.=$DT[$id2idx{$mode}]->{shopname}.'님이 도착했습니다!';
		}
		else
		{
		$DT->{money}+=$pr;
		$DT->{saletoday}+=$pr;
		$disp.=$AucImg.'대금은 '.GetMoneyString($pr).'입니다.<br>';
		$disp.=$DT[$id2idx{$mode}]->{shopname}.'님이 대금을 지불했습니다!';
		}
	undef $REQ[$i];
}

sub WriteAuc
{
	my @buf;
	foreach my $i(0..$Scount)
		{
		next unless defined($REQ[$i]->{no});
		$buf[$i]=join(",",map{$REQ[$i]->{$_}}@REQnamelist)."\n";
		}
	OpenAndCheck(GetPath($TEMP_DIR,"request"));
	print OUT @buf;
	close(OUT);
}

