#!/usr/bin/perl
# 장원종매입처리 2005/03/30 유래

$NOITEM=1;
$NOMENU=1;
Lock();
DataRead();
CheckUserPass();
OutError("영주가 없어서 농원 운영이 불가능합니다") if !defined($id2idx{$STATE->{leader}});
RequireFile('inc-manor.cgi');

	# 농원 설정을 가져옴
	my $id=$id2idx{$STATE->{leader}};
	ReadDTSub($DT[$id],"lord");
	my $MANORLORD=$DT[$id]->{_lord};

	ReadDTSub($DT,"seed");

foreach my $i(0..$#MANOR)
	{
	my @MYMANOR=@{$MANOR[$i]};
	my $stock=$DT->{_seed}->{"ripe$i"};
	next if !$stock;
	my $price=$MANORLORD->{"cost$i"};

	delete $DT->{_seed}->{"ripe$i"};
	$DT->{money}+=$stock*$price;
	$DT->{saletoday}+=$stock*$price;

	$MANORLORD->{"stock$i"}+=$stock;
	$STATE->{money}-=$stock*$price;
	$STATE->{out}+=$stock*$price;
	$STATE->{develop}+=$stock;
	$STATE->{develop}=10000 if $STATE->{develop} > 10000;
	OutError("마을 자금이 부족하여 매입할 수 없습니다") if ($STATE->{money} < 0);

	my $ret=$MYMANOR[2]."를".$stock.'개 @'.GetMoneyString($price)."(합계 ".GetMoneyString($price*$stock).")를 영주 농원에 매각했습니다";
	$disp.=$ret."<br>";
	PushLog(0,$DT->{id},$ret);
	}

	WriteDTSub($DT[$id],"lord");
	WriteDTSub($DT,"seed");
RenewLog();
DataWrite();
DataCommitOrAbort();
UnLock();
OutSkin();
1;
