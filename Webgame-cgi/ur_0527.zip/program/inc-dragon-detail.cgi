#!/usr/bin/perl
# 드래곤 경주 드래곤 상세 표시 2005/03/30 유래

$disp.="<BIG>●드래곤 경주:드래곤 상세</BIG><br><br>";

ReadDragon();
my $cnt=$id2dra{$Q{dr}};
OutError("bad request") if ($DR[$cnt]->{town} ne $MYDIR || $DR[$cnt]->{owner} != $DT->{id});
my $stname="";
$forment="";

ReadStable();
if (scalar @ST)
	{
	foreach(0..$STcount)
		{
		$stname=$ST[$_]->{name} if ($ST[$_]->{no}==$DR[$cnt]->{stable});
		$forment.="<OPTION VALUE=\"$ST[$_]->{no}\">$ST[$_]->{name}";
		}
	}

$disp.="$TB$TR$TDB 명칭$TDB 나이$TDB 성별$TDB 털색$TDB 위탁 마구간$TDB 주행 스타일$TDB 거리 적성$TDB 총상금$TDB 성적$TDB 출전$TRE";
$disp.=$TR;
$disp.=$TD."<b>".GetTagImgDra($DR[$cnt]->{fm},$DR[$cnt]->{color}).$DR[$cnt]->{name}."</b>";
$disp.=$TD.GetTime2found($NOW_TIME-$DR[$cnt]->{birth});
$disp.=$TD.$FM[$DR[$cnt]->{fm}];
$disp.=$TD.$DRCOLOR[$DR[$cnt]->{color}];
$disp.=$TD.$stname;
$disp.=$TD.$STRATE[ GetRaceStrate($DR[$cnt]->{sr},$DR[$cnt]->{ag}) ];
$disp.=$TD.GetRaceApt($DR[$cnt]->{apt},$DR[$cnt]->{fl})."km";
$disp.=$TD.($DR[$cnt]->{prize} + 0)."만";
$disp.=$TD.($DR[$cnt]->{g1win} + 0)." - ".($DR[$cnt]->{g2win} + 0)." - ".($DR[$cnt]->{g3win} + 0)." - ".($DR[$cnt]->{sdwin} + 0);
$disp.=$TD.$ONRACE[$DR[$cnt]->{race}];
$disp.=$TRE;
$disp.=$TBE."<br>";
$disp.="<BIG>●능\력 상세</BIG><br><br>";
$disp.=$TB;
$disp.=$TR.$TDB."속도".$TD.GetDragonBar($DR[$cnt]->{sp},$DR[$cnt]->{spp}).$TRE;
$disp.=$TR.$TDB."승부근성".$TD.GetDragonBar($DR[$cnt]->{sr},$DR[$cnt]->{srp}).$TRE;
$disp.=$TR.$TDB."순발력".$TD.GetDragonBar($DR[$cnt]->{ag},$DR[$cnt]->{agp}).$TRE;
$disp.=$TR.$TDB."힘".$TD.GetDragonBar($DR[$cnt]->{pw},$DR[$cnt]->{pwp}).$TRE;
$disp.=$TR.$TDB."건강".$TD.GetDragonBar($DR[$cnt]->{hl},$DR[$cnt]->{hlp}).$TRE;
$disp.=$TR.$TDB."유연성".$TD.GetDragonBar($DR[$cnt]->{fl},$DR[$cnt]->{flp}).$TRE;
$disp.=$TR.$TDB."컨디션".$TD.GetConBar($DR[$cnt]->{con}).$TRE;
$disp.=$TR.$TDB."체중".$TD.GetWtBar($DR[$cnt]->{wt}).$TRE;
$disp.=$TR.$TDB."성장도".$TD.GetConBar($DR[$cnt]->{gr},1).$TRE;
$disp.=$TBE."<br>";
if ($DR[$cnt]->{race} < 2)
	{
	FormEnt() if (scalar @ST);
	FormToRace();
	FormRetire() if ($NOW_TIME-$DR[$cnt]->{birth} > $DRretire);
	}
1;

sub GetDragonBar
{
	my($point,$up)=@_;
	my $per=$point - $up;

	my $bar="";
	$bar ="<nobr>";
	$bar.=qq|<img src="$IMAGE_URL/b.gif" width="|.($per).qq|" height="12">| if $per;
	$bar.=qq|<img src="$IMAGE_URL/r.gif" width="|.($up).qq|" height="12">| if $up;
	$bar.=qq|<img src="$IMAGE_URL/t.gif" width="|.(100-$point).qq|" height="12">| if $point!=100;
	$bar.=" ".($per + 0)." + ".($up + 0);
	$bar.="</nobr>";
	return $bar;
}

sub GetConBar
{
	my($per,$mode)=@_;

	$per=100 if $per > 100;
	my $bar="";
	$bar ="<nobr>";
	$bar.=qq|<img src="$IMAGE_URL/r.gif" width="|.($per).qq|" height="12">| if $per;
	$bar.=qq|<img src="$IMAGE_URL/t.gif" width="|.(100-$per).qq|" height="12">| if $per!=100;
	$bar.=" ".$EVALUE[int($per/100*4)] if !$mode;
	$bar.=" ".($per + 0)."%";
	$bar.="</nobr>";
	return $bar;
}

sub GetWtBar
{
	my($point)=@_;
	my $per=($point - 40) * 5;
	my $rank=int(($point - 50) / 2);
	$rank=-$rank if ($rank < 0);
	$rank=3 - $rank;
	$rank=0 if $rank < 0;

	my $bar="";
	$bar ="<nobr>";
	$bar.=qq|<img src="$IMAGE_URL/r.gif" width="|.($per).qq|" height="12">| if $per;
	$bar.=qq|<img src="$IMAGE_URL/t.gif" width="|.(100-$per).qq|" height="12">| if $per!=100;
	$bar.=" ".$EVALUE[int($rank)]." ".$point."톤";
	$bar.="</nobr>";
	return $bar;
}

sub FormEnt
{
my $costmsg=GetMoneyString($STcost);
$disp.=<<STR;
<FORM ACTION="action.cgi" $METHOD>
<INPUT TYPE=HIDDEN NAME=key VALUE="slime-s">
<INPUT TYPE=HIDDEN NAME=bk VALUE="slime">
$USERPASSFORM
<INPUT TYPE=HIDDEN NAME=mode VALUE="dredit">
<INPUT TYPE=HIDDEN NAME=code VALUE="ent">
<INPUT TYPE=HIDDEN NAME=dr VALUE="$Q{dr}">
<BIG>●마구간 위탁</BIG>: <SELECT NAME=ent SIZE=1>
$forment
</SELECT> 에 드래곤을
<INPUT TYPE=SUBMIT VALUE='위탁'>
</FORM>
<br>
$TB$TR$TD
·마구간에 드래곤을 위탁하면 조교를 통해 성장할 수 있습니다.<br>
·위탁 요금은 매일 <b>$costmsg</b>이 필요합니다.
$TBE<br>
STR
}

sub FormToRace
{
my $formrace="";
my $formjock="<OPTION VALUE=\"0\">--기수 없음--";
my $formstrate="";
foreach (0..$#RACETERM)
	{
	$formrace.="<OPTION VALUE=\"$_\">$RACETERM[$_]";
	}
foreach (0..3)
	{
	$formstrate.="<OPTION VALUE=\"$_\">$STRATE[$_]";
	}
ReadJock();
if (scalar @JK)
	{
	foreach(0..$JKcount)
		{
		next if $JK[$_]->{race} > 1;
		$formjock.="<OPTION VALUE=\"$JK[$_]->{no}\">$JK[$_]->{name}";
		}
	}


$disp.=<<STR;
<FORM ACTION="action.cgi" $METHOD>
<INPUT TYPE=HIDDEN NAME=key VALUE="slime-s">
<INPUT TYPE=HIDDEN NAME=bk VALUE="slime">
$USERPASSFORM
<INPUT TYPE=HIDDEN NAME=mode VALUE="dredit">
<INPUT TYPE=HIDDEN NAME=code VALUE="torace">
<INPUT TYPE=HIDDEN NAME=dr VALUE="$Q{dr}">
<BIG>●경주 출전 등록</BIG>: 드래곤을 <SELECT NAME=rcode SIZE=1>
$formrace
</SELECT> 에, 기수 <SELECT NAME=jock SIZE=1>
$formjock
</SELECT> 작전 <SELECT NAME=str SIZE=1>
$formstrate
</SELECT> 로
<INPUT TYPE=SUBMIT VALUE='출전'>
</FORM>
<br>
$TB$TR$TD
·정원을 초과하면 추첨 결과에 따라 출전하지 못할 수 있습니다.<br>
·출전하면 그동안 조교가 중단되며 컨디션과 체중이 감소합니다.<br>
·경주 거리, 핸디캡, 다른 출전 드래곤을 확인한 뒤 무리한 출전이 아닌지 판단하세요.
$TBE<br>
STR
}

sub FormRetire
{
my $remsg=GetTime2found($DRretire);
$disp.=<<STR;
<FORM ACTION="action.cgi" $METHOD>
<INPUT TYPE=HIDDEN NAME=key VALUE="slime-s">
<INPUT TYPE=HIDDEN NAME=bk VALUE="slime">
$USERPASSFORM
<INPUT TYPE=HIDDEN NAME=mode VALUE="predit">
<INPUT TYPE=HIDDEN NAME=code VALUE="retire">
<INPUT TYPE=HIDDEN NAME=dr VALUE="$Q{dr}">
<BIG>●은퇴</BIG>: 드래곤을
<INPUT TYPE=SUBMIT VALUE='은퇴시키기'>
<INPUT TYPE=TEXT NAME=check SIZE=10 VALUE="">
(retire라고 입력)
</FORM>
<br>
$TB$TR$TD
·나이 <b>$remsg</b> 이상의 드래곤은 은퇴시킬 수 있습니다.<br>
·총상금이 <b>$PRentry 만</b> 이상인 드래곤은 은퇴 후 번식 드래곤으로 등록됩니다.
$TBE
STR
}

