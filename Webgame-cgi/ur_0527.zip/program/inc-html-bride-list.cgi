#!/usr/bin/perl
# 주택조작 2005/01/06 유래

$i=SearchBride($Q{no});
OutError('지정된 정보가 존재하지 않습니다') if ($i==-1);
($ida,$idb)=($BRIDE[$i]->{ida},$BRIDE[$i]->{idb});

if (!$BRIDE[$i]->{mode})
{
Agree();
}
elsif ($Q{d})
{
DivCheck();
}
else
{
House();
}
1;

sub Agree
{
if ($idb == $DT->{id}) {
	# 청혼승낙
	$disp.=<<STR;
$TB$TR$TD
$image[3]
신부:청혼을 받아들이시겠습니까? 그렇다면 다음 주의 사항을 잘 읽어 주세요.<br>
·결혼 자금이<b>500만$term[2]</b>걸립니다.<br>
·사전에 충분히 대화해 보세요. 상대와 함께할 수 있을지 잘 생각해 보세요.<br>
·청혼을 했습니다측이부으로 리, 수자리측이아내가 됩니다.
$TRE$TBE
<form action="action.cgi" $METHOD>
$MYFORM$USERPASSFORM
<INPUT TYPE=HIDDEN NAME=mode VALUE="agree">
<INPUT TYPE=HIDDEN NAME=idx VALUE="$BRIDE[$i]->{no}">
<BIG>●청혼을 수하기</BIG>:나 $DT->{name} ($DT->{shopname})은
$DT[$id2idx{$ida}]->{name} ($DT[$id2idx{$ida}]->{shopname})을 부와 시<br>
건강할 때도 병들 때도 서로 함께할 것을
<INPUT TYPE=SUBMIT VALUE='맹 있습니다'>
</FORM>
<hr width=500 noshade size=1>
<form action="action.cgi" $METHOD>
$MYFORM$USERPASSFORM
<INPUT TYPE=HIDDEN NAME=mode VALUE="dis">
<INPUT TYPE=HIDDEN NAME=idx VALUE="$BRIDE[$i]->{no}">
<BIG>●청혼을 판단루</BIG>:그런것말됨해도곤란하므로
<INPUT TYPE=SUBMIT VALUE='죄합니다'>
</FORM>
STR
}
elsif ($ida == $DT->{id}) {
	# 청혼철수회
	$disp.=<<STR;
$TB$TR$TD
$image[3]
신부:청혼을 취소생각입니까.<br>
조금부끄러움즈합니다일 수 있지만방 없습니다네.
$TRE$TBE
<form action="action.cgi" $METHOD>
$MYFORM$USERPASSFORM
<INPUT TYPE=HIDDEN NAME=mode VALUE="end">
<INPUT TYPE=HIDDEN NAME=idx VALUE="$BRIDE[$i]->{no}">
<BIG>●청혼을 취소</BIG>:야는 됩니다다사랑이족라없었습니다이므로
<INPUT TYPE=SUBMIT VALUE='처리나 합니다'>
</FORM>
STR
}
else {
	# 들판다음말
	$disp.=<<STR;
$TB$TR$TD
$image[3]
신부:<b>$DT[$id2idx{$ida}]->{name}</b>님의
<b>$DT[$id2idx{$idb}]->{name}</b>님로 상대는 진심입니다. 아마.<br>
지금은 이인을 아타타카쿠보기지킴라고아게테해 주세요.
$TRE$TBE
STR
}
}

sub House
{
$disp.=($BRIDE[$i]->{mode}==1)?$image[0]:$image[1];
$btitle=($BRIDE[$i]->{mode}==1)?"교회 > 공동 창고":"주택";
	# 무관계나인
	if ($DT->{id} != $ida && $DT->{id} != $idb) {
	$disp.=<<STR;
:<BIG>$DT[$id2idx{$ida}]->{shopname} ＆ $DT[$id2idx{$idb}]->{shopname}</BIG><br><br>
$TB$TR$TD
결혼하면 두 사람의 공동 창고를 새 집으로 받습니다.<br>
자금이나 상품을 배치할 수 있습니다, 유지비도 들지 않습니다.
$TRE$TBE
STR
	return;
	}
	my $moneymes=GetMoneyString($BRIDE[$i]->{money});
	my $moneymax=GetMoneyString($BRIDE[$i]->{mode}*20000000);
	$disp.=<<STR;
:<BIG>$DT[$id2idx{$ida}]->{shopname} ＆ $DT[$id2idx{$idb}]->{shopname}</BIG><br><br>
$TB$TR
$TDB 준비품
$TDB 수량<small>/최대</small>
$TRE
$TR$TD 자금
$TD$moneymes<small>/$moneymax</small>
$TRE
STR

$formstock="<OPTION VALUE=\"-1\"> 자금(".GetMoneyString($BRIDE[$i]->{money}).")";
foreach (0..$BRIDE[$i]->{mode}-1) {
	my $stock=$BRIDE[$i]->{stock}[$_];
	my $cnt=$BRIDE[$i]->{cnt}[$_];
	$disp.='<tr><td>';
	$disp.=GetTagImgItemType($stock).$ITEM[$stock]->{name}.'<td>';
	$disp.=($cnt) ? ($cnt.'<small>/'.($ITEM[$stock]->{limit}*$HouseMax).$ITEM[$stock]->{scale}) : ' ';
	$formstock.="<OPTION VALUE=\"$_\">$ITEM[$stock]->{name}($cnt$ITEM[$stock]->{scale})" if ($cnt);
	}
$disp.=$TRE.$TBE."<hr width=500 noshade size=1>";

	my @sort;
	foreach(1..$MAX_ITEM){$sort[$_]=$ITEM[$_]->{sort}};
	my @itemlist=sort { $sort[$a] <=> $sort[$b] } (1..$MAX_ITEM);
	$formitem="<OPTION VALUE=\"-1\"> 자금(".GetMoneyString($DT->{money}).")";
	foreach(@itemlist)
	{
		my $cnt=$DT->{item}[$_-1];
		$cnt=0 if ($ITEM[$_]->{flag}=~/r/);	# 의뢰할 수 없 아이템은 배치케없음.
		my $scale=$ITEM[$_]->{scale};
		$formitem.="<OPTION VALUE=\"$_\">$ITEM[$_]->{name}($cnt$scale)" if $cnt;
	}

$disp.=<<STR;
<form action="action.cgi" $METHOD>
$MYFORM$USERPASSFORM
<INPUT TYPE=HIDDEN NAME=id VALUE="$DT->{id}">
<INPUT TYPE=HIDDEN NAME=idx VALUE="$BRIDE[$i]->{no}">
<INPUT TYPE=HIDDEN NAME=no VALUE="$BRIDE[$i]->{no}">
<INPUT TYPE=HIDDEN NAME=mode VALUE="plus">
<BIG>●보관</BIG>:주택에 <SELECT NAME=it SIZE=1>
$formitem
</SELECT>을 수량 <INPUT TYPE=TEXT NAME=num SIZE=5> (무기입에서 최대)
 <INPUT TYPE=SUBMIT VALUE='보관하다'>
</FORM>
<hr width=500 noshade size=1>
<form action="action.cgi" $METHOD>
$MYFORM$USERPASSFORM
<INPUT TYPE=HIDDEN NAME=id VALUE="$DT->{id}">
<INPUT TYPE=HIDDEN NAME=idx VALUE="$BRIDE[$i]->{no}">
<INPUT TYPE=HIDDEN NAME=no VALUE="$BRIDE[$i]->{no}">
<INPUT TYPE=HIDDEN NAME=mode VALUE="minus">
<BIG>●취출</BIG>:주택에서 <SELECT NAME=it SIZE=1>
$formstock
</SELECT>을 수량 <INPUT TYPE=TEXT NAME=num SIZE=5> (무기입에서 최대)
 <INPUT TYPE=SUBMIT VALUE='꺼내기'>
</FORM>
STR

Reform() if ($BRIDE[$i]->{mode} > 2 && $BRIDE[$i]->{mode} < 7);

$disp.=<<STR;
<hr width=500 noshade size=1>
<form action="action.cgi" $METHOD>
$MYFORM$USERPASSFORM
<INPUT TYPE=HIDDEN NAME=id VALUE="$DT->{id}">
<INPUT TYPE=HIDDEN NAME=no VALUE="$BRIDE[$i]->{no}">
<INPUT TYPE=HIDDEN NAME=d VALUE="1">
<SPAN>이혼</SPAN>:
<INPUT TYPE=SUBMIT VALUE='이혼하다'>
(준비품은 전체 폐기)
</FORM>
STR
}

sub Reform
{
if ($BRIDE[$i]->{money} > $BRIDE[$i]->{mode} * 10000000)
	{
$disp.=<<STR;
<hr width=500 noshade size=1>
<form action="action.cgi" $METHOD>
$MYFORM$USERPASSFORM
<INPUT TYPE=HIDDEN NAME=id VALUE="$DT->{id}">
<INPUT TYPE=HIDDEN NAME=idx VALUE="$BRIDE[$i]->{no}">
<INPUT TYPE=HIDDEN NAME=no VALUE="$BRIDE[$i]->{no}">
<INPUT TYPE=HIDDEN NAME=mode VALUE="more">
<BIG>●증축</BIG>:
<INPUT TYPE=SUBMIT VALUE='증축하다'>
STR
$disp.="(비용".GetMoneyString($BRIDE[$i]->{mode} * 10000000).")</form>";
	}
	else
	{
$disp.=<<STR;
<hr width=500 noshade size=1>
<BIG>●증축</BIG>:자금이 부족합니다
STR
	}
}

sub DivCheck
{
	# 이혼 확인
	$disp.=<<STR;
$TB$TR$TD
$image[3]
신부:정말에이혼하다의 입니다네?
$TRE$TBE
<form action="action.cgi" $METHOD>
$MYFORM$USERPASSFORM
<INPUT TYPE=HIDDEN NAME=id VALUE="$DT->{id}">
<INPUT TYPE=HIDDEN NAME=idx VALUE="$BRIDE[$i]->{no}">
<INPUT TYPE=HIDDEN NAME=mode VALUE="divorce">
<SPAN>●이혼</SPAN>:
<INPUT TYPE=SUBMIT VALUE='이혼하다'>
(준비품은 전체 폐기)
</FORM>
STR
}
