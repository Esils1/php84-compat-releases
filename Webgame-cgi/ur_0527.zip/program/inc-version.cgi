#!/usr/bin/perl
# 스크립트버전표기

# 지원 및 갱신판 안내용 표기이므로 절대 수정하지 마세요.
# 전용 개조를 적용했더라도,inc-item-data 내의 버전을 변경만 해 주세요.

$BASE_VERSION="05-03-30";
$VERSION="상인 이야기 ".$BASE_VERSION;
