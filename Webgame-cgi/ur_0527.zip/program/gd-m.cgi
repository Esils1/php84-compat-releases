#!/usr/bin/perl
# 길드가입 2004/01/20 유래

CoLock() if ($Q{edit});
Lock() if ($Q{edit} eq "join");
DataRead();
CheckUserPass();
RequireFile('inc-gd.cgi');

@ENTRYnamelist=qw(
		no tm town id guild
		);
ReadEntry();

$Q{er}='gd';
RequireFile('inc-gd-entry.cgi') if ($Q{edit});
my $functionname=$Q{mode};
$functionname||="join";
OutError("bad request") if !defined(&$functionname);
&$functionname;

OutSkin();
1;


sub join
{
OutError("bad request") if ($DT->{guild});
$disp.=<<"HTML";
$TB$TR
$TD$image[0]$TD
<SPAN>길드 접수</SPAN>:가입하다에는, 단장 또는 군사의 허가가 필요합니다.<br>
가입하려는 길드의 가입 조건을 보고 문의 해 보세요.
$TRE$TBE<br>
HTML
$disp.="길드전쟁안은 가입할 수 없습니다",return if ($DTevent{guildbattle});
my $join="";
	foreach my $cnt(0..$Ecount)
		{
		next if ($ENTRY[$cnt]->{town} ne $MYDIR || $ENTRY[$cnt]->{id} != $DT->{id});
		my $guild=$ENTRY[$cnt]->{guild};
$join.=<<"HTML";
<form action="action.cgi" $METHOD>
$MYFORM$USERPASSFORM
<BIG>●$GUILD_DETAIL{$guild}->{shortname}</BIG>:가입 허가가 나와 있습니다.
<INPUT TYPE=HIDDEN NAME=edit VALUE="join">
<INPUT TYPE=HIDDEN NAME=guild VALUE="$guild">
<INPUT TYPE=SUBMIT VALUE="가입하다">
</form><br>
HTML
	}
$disp.=($join) ? $join : "가입허가가 나오지 않았습니다";
}

sub submit
{
OutError("bad request") if (!$DT->{guild});
my $checkok;
$ckeckok=1 if ($GUILD_DETAIL{$DT->{guild}}->{leadt} eq $MYDIR && $GUILD_DETAIL{$DT->{guild}}->{leader} == $DT->{id});
$ckeckok=1 if ($GUILD_DETAIL{$DT->{guild}}->{$MYDIR} == $DT->{id});
OutError("bad request") if (!$ckeckok);

ReadLetterName();
$disp.=<<"HTML";
$TB$TR
$TD$image[0]$TD
<SPAN>길드 접수</SPAN>:누구의 가입을 허가합니까?<br>
한 번허가하다토, 철수회는 할 수 없의 입니다주의 해 주세요.
$TRE$TBE<br>
HTML
$disp.="길드전쟁안은 허가할 수 없습니다",return if ($DTevent{guildbattle});
EntryList() if scalar(@MYENTRY);
EntryForm();
}

sub EntryList
{
	$disp.=<<"HTML";
$TB$TR
$TDB 상점명
$TDB 소속거리
$TDB 유효기한
$TRE
HTML

foreach my $i(@MYENTRY)
	{
	my($no,$town,$id)=($ENTRY[$i]->{no},$ENTRY[$i]->{town},$ENTRY[$i]->{id});
	my $sname=SearchLetterName($id,$town);
	$disp.=$TR.$TD.$sname;
	$disp.=$TD.$Tname{$town};
	$disp.="$TD 남은".GetTime2HMS($ENTRY[$i]->{tm}-$NOW_TIME);
	}
$disp.=$TRE.$TBE."<br>";
}

sub EntryForm
{
$disp.=<<"HTML";
<FORM ACTION="action.cgi" $METHOD>
$MYFORM$USERPASSFORM
$TB
$TR$TDB<b>가입허가</b>(중 하나1개)
HTML

my $r=int(scalar(@OtherDir) / 2 + 0.5);$r||=1;
foreach(0..$#OtherDir)
	{
	my $pg=$OtherDir[$_];
	$disp.=( ($_ % $r) ? "<br>" : $TD);
	$disp.="$Tname{$pg} <SELECT NAME=$pg><OPTION VALUE=\"\">선택";
	foreach my $i(0..$Ncount{$pg})
		{
		$disp.="<OPTION VALUE=\"$LID{$pg}[$i]\"".($Q{$pg}==$LID{$pg}[$i] ? ' SELECTED' : '').">$LNAME{$pg}[$i]";
		}
	$disp.="</SELECT>\n";
	}
$disp.=<<"HTML";
$TRE$TBE
<br><INPUT TYPE=HIDDEN NAME=edit VALUE="new">
<INPUT TYPE=SUBMIT VALUE="가입을 허가하다">
</FORM>
HTML
}

sub joind
{
$disp.=<<"HTML";
$TB$TR
$TD$image[0]$TD
<SPAN>길드 접수</SPAN>:가입절차를 완료했습니다.<br>
길드 작전실 등에서 먼저 인사해 두면 좋습니다.
$TRE$TBE<br>
HTML
}

sub ReadEntry
{
	undef @ENTRY;
	undef @MYENTRY;
	open(IN,GetPath($COMMON_DIR,"entry")) or return;
	my @ent=<IN>;
	close(IN);
	$Ecount=$#ent;
	return if $Ecount < 0;
	foreach my $cnt(0..$Ecount)
		{
		chop $ent[$cnt];
		my @buf=split(/,/,$ent[$cnt]); my $i=0;
		foreach (@ENTRYnamelist) { $ENTRY[$cnt]->{$_}=$buf[$i];$i++;}
		undef $ENTRY[$cnt],next if ($ENTRY[$cnt]->{tm} < $NOW_TIME);	# 기한 만료를 삭제.
		push(@MYENTRY, $cnt) if ($ENTRY[$cnt]->{guild} eq $DT->{guild});
	}
}

