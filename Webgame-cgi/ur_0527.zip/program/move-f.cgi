#!/usr/bin/perl
# 이전양식 2005/01/06 유래

OutError('사용불가입니다') if !$MOVETOWN_ENABLE || !$TOWN_CODE;
my $townmaster=ReadTown($TOWN_CODE,'getown');
OutError('사용불가입니다') if !$townmaster;

DataRead();
CheckUserPass();

OutError('이전 가능나거리를 찾을 수 없습니다') if !$Q{towncode};
$disp.=GetMoveShopForm($Q{towncode});
OutSkin();
1;

sub GetMoveShopForm
{
	my($towncode)=@_;

	my($town)=ReadTown($towncode);
	return '<b>이전 가능나거리를 찾을 수 없습니다</b>' if !$town;

	my $disp="";

	my $dist=GetTownDistance($townmaster->{position},$town->{position});
	my $movetime=GetMoveTownTime($DT,$townmaster,$town);

	$disp.=$TB;
	$disp.="$TR$TDB 이전선$TD$town->{name}$TRE";
	$disp.="$TR$TDB 댓글$TD$town->{comment}$TRE";
	$disp.="$TR$TDB 거리$TD".($dist*80)."m$TRE";
	$disp.="$TR$TDB 이동 시간$TD".GetTime2HMS($movetime).' (예정)'.$TRE;
	$deny=0;

	sub GetMarkDeny
	{
		$deny=1,return " ←조건을 충족하지 않습니다" if ($_[0]);
		return "";
	}
	my @flag=();
	push(@flag,"이전의 이전에서 10 일이상".GetMarkDeny($NOW_TIME-GetUserDataEx($DT,'_so_move_in')<864000));	#추가
	push(@flag,"자금 ".GetMoneyString($town->{allowmoney})." 이상".GetMarkDeny($town->{allowmoney}>$DT->{money}+$DT->{moneystock})) if $town->{allowmoney} ne '';
	push(@flag,"자금 ".GetMoneyString($town->{denymoney})." 이하".GetMarkDeny($town->{denymoney}<$DT->{money}+$DT->{moneystock})) if $town->{denymoney} ne '';
	push(@flag,"길드 ".join("/",map{GetTagImgGuild($_,1,1)}split(/\W/,$town->{allowguild})).($town->{onlyguild} ? '':' 및길드무소속')." 의미".GetMarkDeny($DT->{guild} ne '' && !scalar(grep($_ eq $DT->{guild},split(/[^\w]+/,$town->{allowguild}))))) if $town->{allowguild} ne '';
	push(@flag,"길드 ".join("/",map{GetTagImgGuild($_,1,1)}split(/\W/,$town->{denyguild})).($town->{onlyguild} ? ' 및길드무소속':'')." 이외".GetMarkDeny($DT->{guild} ne '' && scalar(grep($_ eq $DT->{guild},split(/[^\w]+/,$town->{denyguild}))))) if $town->{denyguild} ne '';
	push(@flag,"상위권 횟수 $town->{allowtopcount} 회이상".GetMarkDeny($town->{allowtopcount}>$DT->{rankingcount})) if $town->{allowtopcount} ne '';
	push(@flag,"상위권 횟수 $town->{denytopcount} 회 이하".GetMarkDeny($town->{denytopcount}<$DT->{rankingcount})) if $town->{denytopcount} ne '';
	push(@flag,"개업기간 ".GetTime2HMS($town->{allowfoundation})." 이상".GetMarkDeny($town->{allowfoundation}>$NOW_TIME-$DT->{foundation})) if $town->{allowfoundation} ne '';
	push(@flag,"개업기간 ".GetTime2HMS($town->{denyfoundation})." 이하".GetMarkDeny($town->{denyfoundation}<$NOW_TIME-$DT->{foundation})) if $town->{denyfoundation} ne '';
	push(@flag,"길드소속의 미 ".GetMarkDeny($DT->{guild} eq '')) if $town->{onlyguild} ne '';
	push(@flag,"길드무소속의 미 ".GetMarkDeny($DT->{guild} ne '')) if $town->{noguild} ne '';
	push(@flag,"직업 ".join("/",map{$JOBTYPE{$_}}split(/\W+/,$town->{allowjob})).($town->{onlyjob} ? '':' 및직업부정')." 의미".GetMarkDeny($DT->{job} ne '' && !scalar(grep($_ eq $DT->{job},split(/\W+/,$town->{allowjob}))))) if $town->{allowjob} ne '';
	push(@flag,"직업 ".join("/",map{$JOBTYPE{$_}}split(/\W+/,$town->{denyjob})).($town->{onlyjob} ? ' 및직업부정':'')." 이외".GetMarkDeny($DT->{job} ne '' && scalar(grep($_ eq $DT->{job},split(/\W+/,$town->{denyjob}))))) if $town->{denyjob} ne '';
	push(@flag,"직업점포의 미 ".GetMarkDeny($DT->{job} eq '')) if $town->{onlyjob} ne '';
	push(@flag,"직업부정점포의 미 ".GetMarkDeny($DT->{job} ne '')) if $town->{nojob} ne '';
	$disp.="$TR$TDB 이전조건$TD·".join("<br>·",@flag)."$TRE" if scalar(@flag);
	$disp.=$TBE;

	return $disp if $deny;
	$disp.=<<"HTML";
		<hr width=500 noshade size=1>
		<form action="action.cgi" $METHOD>
		<input type=hidden name=key value="move-s">
		$USERPASSFORM
		<input type=hidden name=towncode value="$towncode">
		$TB$TR
		$TDB 이전선에서의 이름(ID)$TD<input type=text name=name value="$DT->{name}">(반각전체각 OK)$TRE
		$TR$TDB 현재의 비밀번호$TD<input type=password name=pass value="">$TRE$TBE
		<br><input type=submit value="이전절차시작">
		</form>
		<hr width=500 noshade size=1>
		<table><tr><td>이전 데이터에서 계승되지 않는 데이터는 아래 내용과 같습니다. 그 외는 대부분 그대로 계승됩니다.
		<ul>
		<li>전기의 순위정보
		<li>도착해 있던 편지(전체 폐기)
		</ul>
		아래 조건에서는 이전할 때 점포 데이터 일부가 실패 처리됩니다.
		<ul>
		<li>시스템개조등데점포데이터에호환성이없는 경우
		</ul>
		아래 조건에서는 이전할 수 없습니다.
		<ul>
		<li>이전선이정원 초과 이 경우
		<li>이전선에같은 이름(ID)야점포이름이있는 경우
		</ul></td></tr></table>
HTML
	return $disp;
}

