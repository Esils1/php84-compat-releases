#!/usr/bin/perl
# 영주 저택 2005/01/06 유래

DataRead();
CheckUserPass(1);
ReadArmy();

$disp.="<BIG>●영주정보</BIG><br><br>";

# 계산부분
my %msg; $msg{free}=""; $msg{double}="";
foreach my $DT (@DT)
	{
	$msg{free}.=$DT->{shopname}.", " , next if ($DT->{taxmode}==1);
	$msg{double}.=$DT->{shopname}.", " if ($DT->{taxmode}==2);
	}

$msg{free} = substr($msg{free},0,(length($msg{free})-3)) if ($msg{free});
$msg{double} = substr($msg{double},0,(length($msg{double})-3)) if ($msg{double});


if (defined($id2idx{$STATE->{leader}}))
{
my $i=$id2idx{$STATE->{leader}};
$disp.=$TB.$TR.$TD.GetTagImgKao($DT[$i]->{name},$DT[$i]->{icon});
$disp.=$TD."<SPAN>영주</SPAN> ： <b>".$DT[$i]->{name}."</b>";
$disp.=DignityDefine($DT[$i]->{dignity})." <small>(".$DT[$i]->{shopname}.")</small><br>";
$disp.=">> ".$DT[$i]->{comment};
$disp.=$TRE.$TBE;
}
else
{
$disp.=$TB.$TR.$TD.GetTagImgKao($BAL_NAME,"bal");
$disp.=$TD."영주 ： <b>$BAL_NAME</b> <small>($BAL_JOB)</small><br>";
$disp.=">> 이 거리는 나의 것이다. 으하하하하";
$disp.=$TRE.$TBE;
}

my $armycost=200-int($STATE->{safety} / 100); 	# 100 - 200
my $purpose="내정중보기";
if ($DTTaxrate < 20) { $purpose="저세율 정책"; }
elsif ($STATE->{army}*$armycost*2 > $STATE->{devem}+$STATE->{safem}) { $purpose="군사중보기"; }

$updown="(↑발전)";
my $peopleud=(24000 * $DTusercount) + 100000 + ($STATE->{develop} * 30) + ($STATE->{safety} * 20);
if ($DTpeople > $peopleud + 10000) { $updown="(↓쇠퇴)"; }
elsif ($DTpeople > $peopleud - 10000) { $updown="(→정지체류)"; }

$disp.="<br><BIG>●내정상황</BIG><br><br>";
$disp.="<table width=480>".$TR;
$disp.=$TDB."인구".$TD.int($DTpeople/10)."인 <small>".$updown."</small>";
$disp.=$TDB."운영 방침".$TD.$purpose.$TRE;
$disp.=$TR.$TDB."거리 자금".$TD.GetMoneyString($STATE->{money}+0);
$disp.=$TDB."세율".$TDNW.GetTaxMessage($DTTaxrate+0).$TRE;
$disp.=$TR.$TDB."전일 세수".$TD.GetMoneyString($STATE->{in}+0);
$disp.=$TDB."전기 지출".$TD.GetMoneyString($STATE->{out}+0).$TRE;
$disp.=$TR.$TDB."개척".$TDNW.GetRankMessage($STATE->{develop}+0) ;
$disp.=$TDB."개척 예산".$TD.GetMoneyString($STATE->{devem}+0).$TRE;
$disp.=$TR.$TDB."치안".$TDNW.GetRankMessage($STATE->{safety}+0) ;
$disp.=$TDB."치안 예산".$TD.GetMoneyString($STATE->{safem}+0).$TRE;
$disp.=$TR.$TDB."면세점<td colspan=3><small>".$msg{free}."</small>".$TRE;
$disp.=$TR.$TDB."중과세점<td colspan=3><small>".$msg{double}."</small>".$TRE;
$disp.=$TBE;

$disp.="<br><BIG>●군사상황</BIG><br><br>";
$disp.=$TB.$TR;
$disp.=$TDB."호위군".$TD.GetArmyMessage($STATE->{army}+$STATE->{robina}+0,"b");
$disp.=$TDB."병력 유지비".$TD.GetMoneyString($STATE->{army}*$armycost).$TRE;

if ($DTevent{rebel})
{
foreach(keys(%RIOT))
	{
	next if !defined($id2idx{$_});
	$STATE->{rebel}+=$ARMY{$_};
	$DT[$id2idx{$_}]->{army}=$ARMY{$_};
	}
$STATE->{rebel}+=$STATE->{robinb};
@DTS=sort{$b->{army}<=>$a->{army}}@DT;
my $rebelid=$DTS[0]->{id};
$rebelid=$DTS[1]->{id} if ($rebelid == $STATE->{leader});
$disp.=$TR.$TDB."반란군".$TD.GetArmyMessage($STATE->{rebel},"r");
$disp.=$TDB."상태".$TD."<SPAN>반란</SPAN>".$TRE;
	if ($STATE->{robinb} > $DT[$id2idx{$rebelid}]->{army})
	{
	$disp.=$TR.$TD.GetTagImgKao($BAL_NAME,"bal");
	$disp.="<td colspan=3><SPAN>반란리다</SPAN> : <b>$BAL_NAME</b> <small>($BAL_JOB)</small><br>";
	$disp.=">> 영주의 약한 병사쯤은 상대가 안 되지! 으하하하하";
	}
	else
	{
	$disp.=$TR.$TD.GetTagImgKao($DT[$id2idx{$rebelid}]->{name},$DT[$id2idx{$rebelid}]->{icon});
	$disp.="<td colspan=3><SPAN>반란리다</SPAN> : <b>".$DT[$id2idx{$rebelid}]->{name}."</b>";
	$disp.=DignityDefine($DT[$id2idx{$rebelid}]->{dignity})." <small>(".$DT[$id2idx{$rebelid}]->{shopname}.")</small><br>";
	$disp.=">> ".$DT[$id2idx{$rebelid}]->{comment};
	}
	$disp.=$TRE;
}
else
{
$disp.=$TR.$TDB."반란군".$TD."불명";
$disp.=$TDB."상태".$TD."평온".$TRE;
}
$disp.=$TBE;

if (!$GUEST_USER && $STATE->{leader}==$DT->{id})
	{
	$disp.=<<STR;
	<br>
	<FORM ACTION="action.cgi" $METHOD>
	<INPUT TYPE=HIDDEN NAME=key VALUE="lord-f">
	$USERPASSFORM
	<INPUT TYPE=HIDDEN NAME=form VALUE="plus">
	<INPUT TYPE=SUBMIT VALUE='정치무를 집행리줄우'>
	</FORM>
STR
	}

OutSkin();
1;


sub GetTaxMessage
{
	my($per)=@_;

	return $per."%" if $MOBILE;

	my $bar="";
	$bar ="<nobr>";
	$bar.=qq|<img src="$IMAGE_URL/r.gif" width="|.($per * 2).qq|" height="12">| if $per;
	$bar.=qq|<img src="$IMAGE_URL/t.gif" width="|.(100 - ($per * 2)).qq|" height="12">| if $per!=50;
	$bar.=" ".$per."%";
	$bar.="</nobr><br>";

	return $bar;
}

sub GetArmyMessage
{
	my($rank,$mode)=@_;
	return $rank."인" if $MOBILE;
	my $per=int($rank/500);
	$per=100 if $per>100;

	my $bar="";
	$bar ="<nobr>";
	$bar.=qq|<img src="$IMAGE_URL/$mode.gif" width="|.( $per).qq|" height="12">| if $per;
	$bar.=qq|<img src="$IMAGE_URL/t.gif" width="|.(100-$per).qq|" height="12">| if $per!=200;
	$bar.=" ".$rank."인";
	$bar.="</nobr><br>";

	return $bar;
}
