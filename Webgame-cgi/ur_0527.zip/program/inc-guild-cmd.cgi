#!/usr/bin/perl
# 길드 명령 2005/01/06 유래

my $usetime=3*60*60;
$disp.='<hr width=500 noshade size=1>';
GuildFundF();
$disp.='<hr width=500 noshade size=1>';
Break();
my $checkok;
$ckeckok=1 if ($GUILD_DETAIL{$DT->{guild}}->{leadt} eq $MYDIR && $GUILD_DETAIL{$DT->{guild}}->{leader} == $DT->{id});
$ckeckok=1 if ($GUILD_DETAIL{$DT->{guild}}->{$MYDIR} == $DT->{id});
Force() if ($ckeckok);
1;

sub GuildFundF
{
	$stock=($DT->{money} - 100000);
	$disp.="<BIG>●길드기부</BIG>: 자금의 여유 없습니다",return if ($stock < 100000);
$disp.=<<STR;
	<form action="action.cgi" $METHOD>
	<INPUT TYPE=HIDDEN NAME=key VALUE="gd-s">
	$USERPASSFORM
	<INPUT TYPE=HIDDEN NAME=mode VALUE="fund">
	<BIG>●길드기부</BIG>: $term[0]
	<SELECT NAME=cnt1>
	<OPTION VALUE="0" SELECTED>
STR
	$msg{1000}=1000;
	$msg{10000}=10000;
	$msg{100000}=100000;
	$msg{1000000}=1000000;
	$msg{$stock}="$stock(최대액)";
	my $oldcnt=0;
	foreach my $cnt (sort { $a <=> $b } (1000,10000,100000,1000000,$stock))
	{
		last if $stock<$cnt || $cnt==$oldcnt;
		$disp.="<OPTION VALUE=\"$cnt\">$msg{$cnt}";
		$oldcnt=$cnt;
	}
$disp.=<<STR;
	</SELECT>
	$term[1], 또는 $term[0]
	<INPUT TYPE=TEXT SIZE=7 NAME=cnt2>$term[1]
	<INPUT TYPE=SUBMIT VALUE="기부하다">
	</FORM>
STR
}

sub Break
{
	$disp.="<BIG>●길드 브레이크</BIG>: 직함이 없으면 실행할 수 없습니다",return if (!$DT->{user}{_so_e});
	$disp.='<BIG>●길드 브레이크</BIG>: 시간이 부족합니다',return if GetStockTime($DT->{time})<$usetime;
	$target="";
	foreach (keys(%GUILD))
	{
	$target.="<OPTION value=\"$_\">$GUILD{$_}->[$GUILDIDX_name]" if $GUILD_DATA{$_}->{money} > $GUILD_DATA{$DT->{guild}}->{money};
	}
	$disp.="<BIG>●길드 브레이크</BIG>: 상대 없습니다",return if (!$target);
$disp.=<<STR;
<form action="action.cgi" $METHOD>
<INPUT TYPE=HIDDEN NAME=key VALUE="gd-s">
$USERPASSFORM
<INPUT TYPE=HIDDEN NAME=mode VALUE="break">
<BIG>●길드 브레이크:</BIG>
<SELECT NAME=tg>
<OPTION value="">
$target
</SELECT>
에 대해
<INPUT TYPE=SUBMIT VALUE="공격하다">
STR
	$disp.="(소요 시간:".GetTime2HMS($usetime).")</FORM>";
}

sub Force
{
	$disp.='<hr width=500 noshade size=1>';
	$disp.="<BIG>●군준비증강</BIG>: 직함이 없으면 실행할 수 없습니다",return if (!$DT->{user}{_so_e});
	$disp.='<BIG>●군준비증강</BIG>: 시간이 부족합니다',return if GetStockTime($DT->{time})<$usetime;
	$disp.="<BIG>●군준비증강</BIG>: 증강의 필요 없습니다",return if ($GUILD_DATA{$DT->{guild}}->{atk} > 990);
$disp.=<<STR;
<form action="action.cgi" $METHOD>
<INPUT TYPE=HIDDEN NAME=key VALUE="gd-s">
$USERPASSFORM
<INPUT TYPE=HIDDEN NAME=mode VALUE="force">
<BIG>●군준비증강:</BIG>
$GUILD{$DT->{guild}}->[$GUILDIDX_name] 공격력을
<INPUT TYPE=SUBMIT VALUE="강화하다"> (길드 자금4분의1소비)
STR
	$disp.="(소요 시간:".GetTime2HMS($usetime).")</FORM>";
}

