#!/usr/bin/perl
# 결혼 2004/01/20 유래

@BRIDEnamelist=qw(
	no tm mode ida idb stbase ctbase money place reform
	);
$image[0]='<IMG ALT="주택" WIDTH="19" HEIGHT="22" BORDER="0" SRC="'.$IMAGE_URL.'/house1.gif">공동 창고';
$image[1]='<IMG ALT="주택" WIDTH="19" HEIGHT="22" BORDER="0" SRC="'.$IMAGE_URL.'/house1.gif">단독 주택';
$image[2]='<IMG ALT="청혼" WIDTH="16" HEIGHT="16" BORDER="0" SRC="'.$IMAGE_URL.'/house2.png">청혼';
$image[3]=GetTagImgKao("신부","father");

Lock() if ($Q{mode});	# 할 수 있만빨리잠금.
DataRead();
CheckUserPass(1);
ReadBride();
RequireFile('inc-html-bride-edit.cgi') if ($Q{mode});	# 각종데이터처리

if ($Q{no})
{
RequireFile('inc-html-bride-list.cgi');
}
else
{
$disp.="<BIG>●교회</BIG><br><br>";
RequireFile('inc-html-bride.cgi');
}

OutSkin();
1;


sub ReadBride
{
	open(IN,GetPath('bride')) or return;
	my @bride=<IN>;
	close(IN);
	$married=0;
	$Scount=$#bride;
	foreach my $cnt(0..$Scount)
		{
		chop $bride[$cnt];
		my @buf=split(/,/,$bride[$cnt]); my $i=0;
		foreach (@BRIDEnamelist) { $BRIDE[$cnt]->{$_}=$buf[$i];$i++;}
		undef $BRIDE[$cnt],next if !defined($id2idx{$BRIDE[$cnt]->{ida}}) || !defined($id2idx{$BRIDE[$cnt]->{idb}});	# 폐점 또는 이전으로 인한 소멸.
		@BRIDE[$cnt]->{stock}=[split(/:/,$BRIDE[$cnt]->{stbase})];
		@BRIDE[$cnt]->{cnt}=[split(/:/,$BRIDE[$cnt]->{ctbase})];
		$BRIDE[$cnt]->{point}=0;
		$BRIDE[$cnt]->{point}=$DT[$id2idx{$BRIDE[$cnt]->{ida}}]->{point}+$DT[$id2idx{$BRIDE[$cnt]->{idb}}]->{point} if ($BRIDE[$cnt]->{mode});
		$married=1 if ($DT->{id} == $BRIDE[$cnt]->{ida}) || ($DT->{id} == $BRIDE[$cnt]->{idb});
		}
}

sub SearchBride
{
	my($no)=@_;
	my $idx=-1;
	foreach(0..$Scount)
	{
		if($BRIDE[$_]->{no}==$no)
		{
			$idx=$_;
			last;
		}
	}
	return $idx;
}
