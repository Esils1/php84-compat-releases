#!/usr/bin/perl
# 주택데이터편집 2003/10/08 유래

if ($Q{mode} eq 'new')
{
ProposeEdit();
DataWrite();
}
else
{
$i=SearchBride($Q{idx});
OutError('지정된 정보가 존재하지 않습니다') if ($i==-1);
($ida,$idb)=($BRIDE[$i]->{ida},$BRIDE[$i]->{idb});
}

$Q{mode}='mplus' if ($Q{mode} eq 'plus')&&($Q{it} == -1);	#머니 모드로 전환
$Q{mode}='mminus' if ($Q{mode} eq 'minus')&&($Q{it} == -1);	#머니 모드로 전환

if ($Q{mode} eq 'agree') {
	OutError($image[3].'결혼에필요한 자금이 부족합니다.') if ($DT->{money} < 5000000) ;
	$DT->{money}-=5000000;
	($BRIDE[$i]->{tm},$BRIDE[$i]->{mode},$BRIDE[$i]->{money})=($NOW_TIME,1,10000000);
	PushLog(3,0,$DT->{name}.' ('.$DT->{shopname}.')는 '.$DT[$id2idx{$ida}]->{name}.' ('.$DT[$id2idx{$ida}]->{shopname}.')의 결혼의 신청시포함미를 받했습니다.');
	PushLog(1,0,$DT[$id2idx{$ida}]->{name}.' ('.$DT[$id2idx{$ida}]->{shopname}.')토 '.$DT->{name}.' ('.$DT->{shopname}.')가결혼했습니다.');
	DataWrite();
}
if ($Q{mode} eq 'end') {
	$DT->{money}+=5000000;	#자금을 반환거부.
	PushLog(3,0,$DT->{name}.' ('.$DT->{shopname}.')는 '.$DT[$id2idx{$idb}]->{name}.' ('.$DT[$id2idx{$idb}]->{shopname}.')로 의 결혼의 신청시포함미를 취소했습니다.');
	$BRIDE[$i]->{mode}=-1;
	DataWrite();
}
if ($Q{mode} eq 'con') {
	OutError($image[3].'주택건설에필요한 자금이 부족합니다.') if ($BRIDE[$i]->{money} < 15000000) ;
	my $check=0;
	foreach (0..$Scount) {
		$check=1 if ($BRIDE[$_]->{place}==$Q{place});
		}
	OutError($image[3].'이미주택이건설테라레하고 있는 것 같습니다.') if ($check || $BRIDE[$i]->{place}) ;
	$BRIDE[$i]->{money}-=15000000;
	($BRIDE[$i]->{place},$BRIDE[$i]->{mode},$BRIDE[$i]->{reform})=($Q{place},3,'a');
	PushLog(2,0,$DT[$id2idx{$ida}]->{name}.'＆'.$DT[$id2idx{$idb}]->{name}.'부아내가주택을 건설테했습니다.');
}
if ($Q{mode} eq 'more') {
	OutError('증축할 수 없습니다.') if ($BRIDE[$i]->{mode} < 2 || $BRIDE[$i]->{mode} > 7) ;
	OutError('주택증축에필요한 자금이 부족합니다.') if ($BRIDE[$i]->{money} < $BRIDE[$i]->{mode} * 10000000);
	$BRIDE[$i]->{money}-=($BRIDE[$i]->{mode} * 10000000);
	$BRIDE[$i]->{mode}+=2;
	PushLog(2,0,$DT[$id2idx{$ida}]->{name}.'＆'.$DT[$id2idx{$idb}]->{name}.'부아내가주택을 증축했습니다.');
}
if ($Q{mode} eq 'plus') {
	$itemno=$Q{it};
	my $n=SearchBstock($Q{it});
	OutError('보관공간 없습니다.') if ($n == -1) ;
	my $space=$ITEM[$itemno]->{limit}*$HouseMax - $BRIDE[$i]->{cnt}[$n];
	OutError('보관공간 없습니다.') if ($space < 1) ;
	$Q{num}=$DT->{item}[$itemno-1] if ($Q{num} > $DT->{item}[$itemno-1]);
	$num=CheckCount($DT->{item}[$itemno-1],int($Q{num}),0,$space);
	OutError('무효나숫자값지정입니다.') if !$num;
	$DT->{item}[$itemno-1]-=$num;
	$BRIDE[$i]->{stock}[$n]=$itemno;
	$BRIDE[$i]->{cnt}[$n]+=$num;
	DataWrite();
}
if ($Q{mode} eq 'minus') {
	my $n=$Q{it};
	my $itemno=$BRIDE[$i]->{stock}[$n];
	my $space=$ITEM[$itemno]->{limit} - $DT->{item}[$itemno-1];
	OutError('창고가 가득 차서 꺼낼 수않습니다.') if ($space < 1) ;
	$Q{num}=$BRIDE[$i]->{cnt}[$n] if ($Q{num} > $BRIDE[$i]->{cnt}[$n]);
	$num=CheckCount($BRIDE[$i]->{cnt}[$n],int($Q{num}),0,$space);
	OutError('무효나숫자값지정입니다.') if !$num;
	$DT->{item}[$itemno-1]+=$num;
	$BRIDE[$i]->{cnt}[$n]-=$num;
	$BRIDE[$i]->{stock}[$n]=0 if !($BRIDE[$i]->{cnt}[$n]);
	DataWrite();
}
if ($Q{mode} eq 'mplus') {
	my $space=$BRIDE[$i]->{mode}*20000000 - $BRIDE[$i]->{money};
	OutError('보관공간 없습니다.') if ($space < 1) ;
	$Q{num}=$DT->{money} if ($Q{num} > $DT->{money});
	$num=CheckCount($DT->{money},int($Q{num}),0,$space);
	OutError('무효나숫자값지정입니다.') if !$num;
	$DT->{money}-=$num;
	$BRIDE[$i]->{money}+=$num;
	DataWrite();
}
if ($Q{mode} eq 'mminus') {
	my $space=$MAX_MONEY - $DT->{money};
	OutError('창고가 가득 차서 꺼낼 수않습니다.') if ($space < 1) ;
	$Q{num}=$BRIDE[$i]->{money} if ($Q{num} > $BRIDE[$i]->{money});
	$num=CheckCount($BRIDE[$i]->{money},int($Q{num}),0,$space);
	OutError('무효나숫자값지정입니다.') if !$num;
	$DT->{money}+=$num;
	$BRIDE[$i]->{money}-=$num;
	DataWrite();
}
if ($Q{mode} eq 'divorce') {
	$BRIDE[$i]->{mode}=-1;
	PushLog(1,0,$DT[$id2idx{$ida}]->{name}.' ('.$DT[$id2idx{$ida}]->{shopname}.')토 '.$DT[$id2idx{$idb}]->{name}.' ('.$DT[$id2idx{$idb}]->{shopname}.')가이혼했습니다.');
}
if ($Q{mode} eq 'dis') {
	$BRIDE[$i]->{mode}=-1;
	PushLog(3,0,$DT->{name}.' ('.$DT->{shopname}.')는 '.$DT[$id2idx{$ida}]->{name}.' ('.$DT[$id2idx{$ida}]->{shopname}.')의 결혼의 신청시포함미를 판단되었습니다.');
}
WriteBride();
RenewLog();
DataCommitOrAbort();
UnLock();
1;


sub ProposeEdit
{
	my $check=0;
	OutError($image[3].'부상기는 금지물입니다요.') if ($married) ;
	OutError($image[3].'결혼에필요한 자금이 부족합니다.') if ($DT->{money} < 5000000) ;
	my $tg=$Q{tg};
	OutError($image[3].'자신와 결혼하다것은 할 수 없습니다.') if ($DT->{id} == $tg) ;
	foreach (0..$Scount) {
		$check=1 if ($tg==$BRIDE[$_]->{ida}) || ($tg==$BRIDE[$_]->{idb});
		}
	OutError($image[3].'그인을 선택부것은 이미할 수 없습니다요.') if ($check) ;
	$DT->{money}-=5000000;
	PushLog(3,0,$DT->{name}.' ('.$DT->{shopname}.')가 '.$DT[$id2idx{$tg}]->{name}.' ('.$DT[$id2idx{$tg}]->{shopname}.')에결혼을 신청시포함봄했습니다.');
	@BRIDE=reverse(@BRIDE);
	$Scount++;
	my $i=$Scount;
	$BRIDE[$i]->{point}=0;
	$BRIDE[$i]->{no}=($i > 0) ? ($BRIDE[$i-1]->{no} + 1) : 1;
	($BRIDE[$i]->{tm},$BRIDE[$i]->{mode},$BRIDE[$i]->{ida},$BRIDE[$i]->{idb},$BRIDE[$i]->{money},$BRIDE[$i]->{place},$BRIDE[$i]->{reform})=($NOW_TIME,0,$DT->{id},$tg,0,0,0);
	$BRIDE[$i]->{stock}=(); $BRIDE[$i]->{stock}[0]=0;
	$BRIDE[$i]->{cnt}=(); $BRIDE[$i]->{cnt}[0]=0;
	@BRIDE=reverse(@BRIDE);
}

sub SearchBstock
{
	my($no)=@_;
	foreach(0..$BRIDE[$i]->{mode}-1)
	{
		return $_ if($no == $BRIDE[$i]->{stock}[$_]);	# 먼저이미보관됨하고 있는 물와 같은 카조사하기
	}
	foreach(0..$BRIDE[$i]->{mode}-1)
	{
		return $_ if !($BRIDE[$i]->{stock}[$_]);	# 다음에빈자리가있는 지조사하기
	}
	return -1;
}

sub WriteBride
{
	my @buf;
	foreach my $i(0..$Scount)
		{
		next if ($BRIDE[$i]->{mode}==-1) || !defined($BRIDE[$i]->{no});
		$BRIDE[$i]->{stbase}=join(":",@{$BRIDE[$i]->{stock}});
		$BRIDE[$i]->{ctbase}=join(":",@{$BRIDE[$i]->{cnt}});
		$buf[$i]=join(",",map{$BRIDE[$i]->{$_}}@BRIDEnamelist)."\n";
		}
	OpenAndCheck(GetPath($TEMP_DIR,"bride"));
	print OUT @buf;
	close(OUT);
}
