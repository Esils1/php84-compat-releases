#!/usr/bin/perl
# error 플러그인 2004/01/20 유래

sub OverLoad
{
	print <<"HTML";
Cache-Control: no-cache, must-revalidate
Pragma: no-cache
Content-type: text/html; charset=UTF-8

<html>
<head><META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
<title>과 부하</title>
</head>
<body>
현재서버가고부하상태입니다.
신청\시번 없지만잠시접속을 다시 시도해 주세요.<br>
부하도 $_[0] CPUs
</body></html>
HTML
	exit;
}

sub OutError
{
	UnLock() if $LOCKED;
	CoUnLock() if $COLOCKED;
	my %msg=
	(
		"not defined function"=>
			'정의되지 않은 함수를 호출했습니다. 아래 정보를 관리자에게 알려 주세요.<hr>'.
			"not defined function '$_[1]'",
		"busy"=>
			'접근이<SPAN>혼잡</SPAN>하고됩니다.<br>'.
			'번거롭겠지만<SPAN>반드시５초이상기다렸다가 </SPAN>돌아가서 다시 접근해 주세요.<br>'.
			($AUTO_UNLOCK_TIME*2).'초이상경유라고도접속할 수 이 경우'.
			'<a href="mailto:'.$ADMIN_EMAIL.'">관리자에게 연락</a>해 주세요.',
		"no data"=>
			'<SPAN>데이터를 찾을 수 없었습니다</SPAN>. 번거롭겠지만돌아가 다시 시도해 주세요.'.
			'이메시지가계속이 경우<a href="mailto:'.$ADMIN_EMAIL.'">관리자에게 연락</a>해 주세요.',
		"stop"=>
			'이점포는<SPAN>오휴식미안</SPAN>입니다.'.
			'플레이를 재개하다 때는<a href="mailto:'.$ADMIN_EMAIL.'">관리자에게 연락</a>해 주세요.',
		"no user"=>
			'존재하지 않음 ID입니다.ID 을고 확인해 주세요.→'.$_[1],
		"incorrect"=>
			'비밀번호가 잘못되었습니다. 고 확인해 주세요→'.$_[1],
		"error rename"=>
			'데이터갱신에실패했습니다',
		"timeout"=>
			'로그인 후 시간이 오래 지나 <SPAN>타임아웃</SPAN>했습니다.<br>번거롭지만 처음 화면에서 다시 로그인해 주세요.',
		"bad request"=>
			"<SPAN>잘못된 호출</SPAN>입니다. 브라우저의 뒤로/앞으로 버튼을 사용한 경우 사용하지 말아 주세요.",
	);
	my $msg=defined $msg{$_[0]} ? $msg{$_[0]} : $_[0];
	$NOMENU=0;$Q{bk}="";
	$disp=<<"HTML";
	<BIG>●오류 보고서</BIG><br><br>
	$msg
HTML
	OutSkin();
	exit;
}

sub WriteErrorLog
{
	eval(<<'__function__');
	my($msg,$file)=@_;

	return if !$LOG_SIZE_MAX || $file eq '';

	my $fn=GetPath($LOG_DIR,$file);
	rename($fn,GetPath($LOG_DIR,$file."-old")) if (stat($fn))[7]>$LOG_SIZE_MAX;
	open(ERR,">>$fn") or return;
	print ERR
		join("\t",
			(
				$NOW_TIME,
				$ENV{SCRIPT_NAME},
				$ENV{REMOTE_ADDR},
				$ENV{REMOTE_HOST},
				GetTrueIP(),
				$USER,
				$msg,
			)
		)."\n";
	close(ERR);
__function__
}

sub OutErrorBlockLogin
{
	OutError('
		고지정의 ID 은<SPAN>'.$_[0].'</SPAN> 때문에 접근 제한되 있습니다.<br>
		플레이 중인 거리 이름, 사용자 이름, 점포 이름을 첨부해서 <a href="mailto:'.$ADMIN_EMAIL.'">관리자에게 연락</a>해 주세요.
	');
}
1;
