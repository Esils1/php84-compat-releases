#!/usr/bin/perl
# config 플러그인 2003/07/19 유래

sub ReadConfig
{
	open(IN,$_[0]) or return ();;
	my @data=();
	while(<IN>)
	{
		chop;
		s/#.*$//;
		#각종 설정 파일에서는 위험회피 때문에 '< > "'는사용불가'&'는사용 가능
		#s/&/&amp;/g;
		s/</&lt;/g;
		s/>/&gt;/g;
		s/"/&quot;/g;
		push(@data,$1,$2) if /^\s*(.+?)\s*=\s*(.+?)\s*$/;
	}
	close(IN);
	return @data;
}

1;
