#!/usr/bin/perl
# calc 플러그인 2005/01/06 유래

sub CheckCount
{
	my($cnt1,$cnt2,$min,$max)=@_;
	my $cnt;

	$cnt1+=0; $cnt2+=0;

	$cnt=$cnt2 ? $cnt2 : $cnt1;
	$cnt=$min if $cnt<$min;
	$cnt=$max if $cnt>$max;
	OutError('부정나값입니다.') if $cnt =~/(nan|inf)/i;
	return int($cnt);
}

sub GetStockTime
{
	my($tm)=@_;
	my $tmp=$NOW_TIME-$tm;
	$tmp=$MAX_STOCK_TIME if $tmp>$MAX_STOCK_TIME;

	return $tmp;
}

sub UseTime
{
	my($tm)=@_;

	if($DT->{status})
	{
		OutError('bad request') if $tm<0;
		my $tmp=$NOW_TIME-$DT->{time};
		$DT->{time}=$NOW_TIME-$MAX_STOCK_TIME if $tmp>$MAX_STOCK_TIME;

		OutError('시간이 부족합니다.') if $tmp<0 && $USER ne '';

		$DT->{time}+=$tm;
	}
}

sub EditMoney
{
	my($DT,$money)=@_;

	$DT->{money}+=int $money;
	$DT->{money}=$MAX_MONEY if $DT->{money}>$MAX_MONEY;
	$DT->{money}=0 if $DT->{money}<0;
}

sub EditTime
{
	my($DT,$time)=@_;

	my $stock=$DT->{time};
	$stock=$NOW_TIME-$MAX_STOCK_TIME if $stock<$NOW_TIME-$MAX_STOCK_TIME;
	$stock-=int $time;
	$stock=$NOW_TIME-$MAX_STOCK_TIME if $stock<$NOW_TIME-$MAX_STOCK_TIME;
	$DT->{time}=$stock;
}

sub GetItemUseTime
{
	my($USE)=@_;
	my $exp=$USE->{result}->{expold}ne'' ? $USE->{result}->{expold} : $DT->{exp}->{$USE->{itemno}};
	return $USE->{time}-int(($USE->{time}-$USE->{exptime})*$exp/1000);
}
1;
