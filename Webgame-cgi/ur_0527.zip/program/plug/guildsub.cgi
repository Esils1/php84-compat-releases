#!/usr/bin/perl
# guildsub 플러그인 2003/11/03 유래

sub ReadGuild
{
	my($code)=@_;

	undef %GUILD_DETAIL;

	my @guildlist=GetGuildDirFiles();

	return "" if !scalar(@guildlist);

	foreach my $code (@guildlist)
	{
		my @data=ReadConfig($COMMON_DIR."/".$code.".pl");	#길드 파일의 미확장자변경
		$GUILD_DETAIL{$code}={'code',$code,@data} if scalar(@data);
	}

	return ($code ne '' ? $GUILD_DETAIL{$code} : "");
}

sub GetGuildDirFiles
{
	opendir(DIR,$COMMON_DIR);
	my $FILE_PL='.pl';	#길드 파일의 미확장자변경
	my @guildlist=sort map{/^(\w+)$FILE_PL$/} grep(/^\w+$FILE_PL$/,readdir(DIR));
	closedir(DIR);
	return @guildlist;
}

sub MakeGuildFile
{
	my @guildlist=GetGuildDirFiles();

	OpenAndCheck(GetPath($TEMP_DIR,$GUILD_FILE));
	print OUT '$GUILDIDX_name=0;$GUILDIDX_dealrate=1;$GUILDIDX_feerate=2;';
	print OUT '%GUILD=(';
	foreach my $code (keys(%GUILD_DETAIL))
	{
		my $detail=$GUILD_DETAIL{$code};
		print OUT "'$code'=>[";
		print OUT (GetString($detail->{shortname})),",";
		print OUT $detail->{dealrate}.",";
		print OUT $detail->{feerate}.",";
		print OUT "],";
	}
	print OUT ');1;';
	close(OUT);

	my %okguild=map{($_,1)}keys(%GUILD_DETAIL);
	foreach my $code (grep(!$okguild{$_},keys(%GUILD)))
	{
		next if $code eq '';
		PushLog(1,0,"길드'".$GUILD{$code}->[$GUILDIDX_name]."'는멸망되었습니다.",1);
		foreach my $DT (@DT)
		{
			$DT->{guild}="",delete $DT->{user}{_so_e} if ($DT->{guild} eq $code);
		}
	}
	foreach my $code (grep(!$GUILD{$_},keys(%okguild)))
	{
		next if $code eq '';
		PushLog(1,0,"길드'".$GUILD_DETAIL{$code}->{shortname}."'가결성됨했습니다.",1);
	}
}
1;
