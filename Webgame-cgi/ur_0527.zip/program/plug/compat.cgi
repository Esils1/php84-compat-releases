#!/usr/bin/perl
# compat 플러그인 2004/01/20 유래

sub Compat
{
	OutError("호환성의 없음프로그램 때문에 , 실행할 수 없습니다");
}

sub OutHTML
{
	Compat();
}

1;
