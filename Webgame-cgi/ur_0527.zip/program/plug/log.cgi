#!/usr/bin/perl
BEGIN {
	*Utf8Text = sub {
		my($s)=@_;
		return '' unless defined $s;
		utf8::decode($s) unless utf8::is_utf8($s);
		return $s;
	} unless defined &Utf8Text;

	*Utf8InPlace = sub {
		utf8::decode($_[0]) if defined $_[0] && !utf8::is_utf8($_[0]);
	} unless defined &Utf8InPlace;
}
# log 플러그인 2003/07/19 유래

sub ReadLog
{
	my($id,$mode,$keyword,$target)=@_;
	$id=$DT->{id} if $id eq '';
	undef @MESSAGE;

	open(IN,GetPath("log0"));
	push(@MESSAGE,<IN>);
	close(IN);
	open(IN,GetPath("log1"));
	push(@MESSAGE,<IN>);
	close(IN);

	@MESSAGE=grep(/^\d+\t\d+\t($id|0)\t/o,@MESSAGE);
	if($mode)
	{
		$mode+=0;
		@MESSAGE=grep(/^\d+\t$mode\t/o,@MESSAGE);
	}
	if($keyword)
	{

		$keyword=Utf8Text($keyword);
		@MESSAGE=grep(/\Q$keyword\E/oi,@MESSAGE);
	}
	if($target)
	{

		$target=Utf8Text($target);
		@MESSAGE=grep(/\Q$target\E/o,@MESSAGE);
	}
	@MESSAGE=("0\t0\t0\t정보는 없습니다\n") if !scalar(@MESSAGE);
}

sub PushLog
{
	my($mode,$id,$msg)=@_;
	unshift(@LOG,"$NOW_TIME\t$mode\t$id\t$msg\n");
}

# 호환성확보
sub WriteLog
{
	PushLog($_[0],$_[1],$_[3]);
}

sub RenewLog
{
	return if !scalar(@LOG);
	my $s0=GetPath("log0");
	my $s1=GetPath("log1");
	my $s2=GetPath("log2");
	my $tempfile=GetPath($TEMP_DIR,"log0");

	if((stat($s1))[9]<$NOW_TIME-$LOG_EXPIRE_TIME)
	{
		RenameAndCheck($s1,$s2) if -e $s1;
		RenameAndCheck($s0,$s1) if -e $s0;
	}
	else
	{
		open(IN,(-e $tempfile ? $tempfile : $s0));
		push(@LOG,<IN>);
		close(IN);
	}
	OpenAndCheck($tempfile);
	print OUT @LOG;
	close(OUT);
}
1;
