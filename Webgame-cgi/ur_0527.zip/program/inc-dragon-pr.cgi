#!/usr/bin/perl
# 드래곤 경주 은퇴 드래곤 상세 표시 2005/03/30 유래

$disp.="<BIG>●드래곤 경주:은퇴 드래곤 상세</BIG><br><br>";

ReadParent();
my $cnt=$id2pr{$Q{dr}};
OutError("bad request") if ($MYDIR ne $PR[$cnt]->{town});
OutError("bad request") if ($PR[$cnt]->{owner}!=$DT->{id});
OutError("bad request") if (!$PR[$cnt]->{fm});

$forment="";
foreach(0..$PRcount)
	{
	next if $PR[$_]->{fm};
	$forment.="<OPTION VALUE=\"$PR[$_]->{no}\">$PR[$_]->{name}";
	}

$disp.="$TB$TR$TDB 명칭$TDB 나이$TDB 털색$TDB 주행 스타일$TDB 거리 적성$TDB 현역 상금$TDB 현역 성적$TDB 마지막 교배$TRE";
$disp.=$TR;
$disp.=$TD."<b>".GetTagImgDra($PR[$cnt]->{fm},$PR[$cnt]->{color},1).$PR[$cnt]->{name}."</b>";
$disp.=$TD.GetTime2found($NOW_TIME-$PR[$cnt]->{birth});
$disp.=$TD.$DRCOLOR[$PR[$cnt]->{color}];
$disp.=$TD.$STRATE[ GetRaceStrate($PR[$cnt]->{sr},$PR[$cnt]->{ag}) ];
$disp.=$TD.GetRaceApt($PR[$cnt]->{apt},$PR[$cnt]->{fl})."km";
$disp.=$TD.($PR[$cnt]->{prize} + 0)."만";
$disp.=$TD.($PR[$cnt]->{g1win} + 0)." - ".($PR[$cnt]->{g2win} + 0)." - ".($PR[$cnt]->{g3win} + 0)." - ".($PR[$cnt]->{sdwin} + 0);
$disp.=$TD.GetTime2FormatTime($PR[$cnt]->{preg});
$disp.=$TRE;
$disp.=$TBE."<br>";
$disp.="<BIG>●능\력 상세</BIG><br><br>";
$disp.=$TB;
$disp.=$TR.$TDB."유전 전달력".$TD.GetParentBar($PR[$cnt]->{hr}).$TRE;
$disp.=$TR.$TDB."속도".$TD.GetParentBar($PR[$cnt]->{sp}).$TRE;
$disp.=$TR.$TDB."승부근성".$TD.GetParentBar($PR[$cnt]->{sr}).$TRE;
$disp.=$TR.$TDB."순발력".$TD.GetParentBar($PR[$cnt]->{ag}).$TRE;
$disp.=$TR.$TDB."힘".$TD.GetParentBar($PR[$cnt]->{pw}).$TRE;
$disp.=$TR.$TDB."건강".$TD.GetParentBar($PR[$cnt]->{hl}).$TRE;
$disp.=$TR.$TDB."유연성".$TD.GetParentBar($PR[$cnt]->{fl}).$TRE;
$disp.=$TBE."<br>";
if ($forment && ($NOW_TIME-$PR[$cnt]->{preg} > $PRcycle))
	{
	FormPreg();
	}
1;

sub GetParentBar
{
	my($per)=@_;

	my $bar="";
	$bar ="<nobr>";
	$bar.=qq|<img src="$IMAGE_URL/b.gif" width="|.($per).qq|" height="12">| if $per;
	$bar.=qq|<img src="$IMAGE_URL/t.gif" width="|.(100-$per).qq|" height="12">| if $per!=100;
	$bar.=" ".($per + 0);
	$bar.="</nobr>";
	return $bar;
}

sub FormPreg
{
my $prmsg=GetTime2found($PRcycle);
$disp.=<<STR;
<FORM ACTION="action.cgi" $METHOD>
<INPUT TYPE=HIDDEN NAME=key VALUE="slime-s">
<INPUT TYPE=HIDDEN NAME=bk VALUE="slime">
$USERPASSFORM
<INPUT TYPE=HIDDEN NAME=mode VALUE="predit">
<INPUT TYPE=HIDDEN NAME=code VALUE="preg">
<INPUT TYPE=HIDDEN NAME=dr VALUE="$Q{dr}">
<BIG>●교배</BIG>: 태어날 드래곤을
<INPUT TYPE=TEXT NAME=name SIZE=20> 라고 이름 붙여
<SELECT NAME=pr SIZE=1>
$forment
</SELECT> 과
<INPUT TYPE=SUBMIT VALUE='교배하기'>
</FORM>
<br>
$TB$TR$TD
·소유 드래곤이 이미 <b>$MYDRmax</b>마리라면 교배를 실행할 수 없습니다.<br>
·이름은 <b>한글 10자 이내</b>로 입력해 주세요.<br>
·수컷 드래곤의 소유자에게 교배 요금이 지급됩니다.<br>
·출산 후 <b>$prmsg</b> 동안은 다음 교배를 할 수 없습니다.
$TBE<br>
STR
}

