#!/usr/bin/perl
BEGIN {
	*Utf8Text = sub {
		my($s)=@_;
		return '' unless defined $s;
		utf8::decode($s) unless utf8::is_utf8($s);
		return $s;
	} unless defined &Utf8Text;

	*Utf8InPlace = sub {
		utf8::decode($_[0]) if defined $_[0] && !utf8::is_utf8($_[0]);
	} unless defined &Utf8InPlace;
}
# 드래곤 경주 기수 편집 2005/03/30 유래

ReadJock();
$disp.="<BIG>●드래곤 경주:기수</BIG><br><br>";

my $functionname=$Q{code};
OutError("bad request") if !defined(&$functionname);
&$functionname;

WriteJock();
RenewDraLog();
CoDataCA();
1;


sub new
{
OutError("bad request") if ($MYJK!=-1);
OutError("bad request") if (scalar @JK >= $JKmax);
OutError('자금이 부족합니다.') if ($DT->{money} < $JKest);

	# 이름의 유효성을 확인

	$Q{name}=Utf8Text($Q{name});

	if(!$Q{name})
	{
		OutError('이름을 입력해 주세요.');
	}
	if($Q{name} =~ /([,:;\t\r\n<>&])/ || CheckNGName($Q{name}) )
	{
		OutError('이름에 사용할 수 없는 문자가 포함되어 있습니다.');
	}
	OutError('이름이 너무 깁니다.') if length($Q{name})>20;
	OutError('이름이 너무 짧습니다.') if length($Q{name})<6;

	@JK=reverse(@JK);
	$JKcount++;
	my $i=$JKcount;
	$JK[$i]->{no}=($i > 0) ? ($JK[$i-1]->{no} + 1) : 1 ;
	$JK[$i]->{birth}=$NOW_TIME;
	$JK[$i]->{name}=$Q{name};
	$JK[$i]->{town}=$MYDIR;
	$JK[$i]->{owner}=$DT->{id};
	$JK[$i]->{ahead}=int(rand(15));
	$JK[$i]->{back}=int(rand(15));

	# 특징부여
	if ($JK[$i]->{ahead} > $JK[$i]->{back})
		{
		$JK[$i]->{ahead}+=15;
		}
		else
		{
		$JK[$i]->{back}+=15;
		}
	@JK=reverse(@JK);

WritePayLog($MYDIR,$DT->{id},-$JKest);
PushDraLog(0,"새 기수 '".$Q{name}."'가 데뷔했습니다.");
$disp.="새 기수 '<b>".$Q{name}."</b>'을 고용했습니다.";
}

