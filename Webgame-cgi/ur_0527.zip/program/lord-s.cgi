#!/usr/bin/perl
# 영주 저택 2004/01/20 유래

$image[0]=GetTagImgKao("대신","minister");
Lock();
DataRead();
CheckUserPass();

my $functionname=$Q{mode};
OutError("bad request") if !defined(&$functionname);
&$functionname;
RenewLog();
DataWrite();
DataCommitOrAbort();
UnLock();

OutSkin();
1;

sub inside
{
if ($Q{taxrate} =~ /([^0-9])/
	|| $Q{devem} =~ /([^0-9])/
	|| $Q{safem} =~ /([^0-9])/
	) { OutError('사용 가능한 문자는 반각 숫자뿐입니다'); }
OutError($image[0].'갑니다라무엇이든그것은 고너무라는 것입니다조.') if ($Q{taxrate} > 40) ;
OutError($image[0].'한 번에 그렇게 많은 대책비를 쏟아도 무의 합니다.') if ($Q{devem} > 10000000 || $Q{safem} > 10000000) ;

$Q{taxrate}=0 if $Q{taxrate}<0;
$Q{devem}=0 if $Q{devem}<0;
$Q{safem}=0 if $Q{safem}<0;
my $taxrate=int($Q{taxrate});
$disp.="거리의 내정운영 방침을 변경했습니다.";

if ($DTTaxrate != $taxrate )
	{
	my $i="인키올렸습니다";
	$i="인키하게했습니다" if $DTTaxrate > $taxrate;
	$DTTaxrate=int($Q{taxrate});
	PushLog(2,0,"영주".$DT->{name}."는거리의 세율을$taxrate%에$i.");
	$disp.="<br>거리의 세율을$taxrate%에$i.";
	}
$STATE->{devem}=int($Q{devem});
$STATE->{safem}=int($Q{safem});
}

sub outside
{
OutError('반란 중에는 고용할 수 없습니다.') if $DTevent{rebel};
my $stock=int($STATE->{money} / 1200);
$count=CheckCount($Q{cnt1},$Q{cnt2},0,$stock);
OutError('고용 인원수를 지정해 주세요') if !$count;
$STATE->{money}-=$count * 1200;
$STATE->{army}+=$count;
$disp.="호위군을$count 인고용했습니다.";
}

sub outdel
{
OutError('반란안 때문에 해고할 수 없습니다.') if $DTevent{rebel};
$count=CheckCount($Q{cnt1},$Q{cnt2},0,$STATE->{army});
OutError('해고인원수를 지정해 주세요') if !$count;
$STATE->{army}-=$count;
$disp.="호위군을$count 인해고했습니다.";
}

sub taxside
{
OutError('대상점을 선택해 주세요.') if !defined($id2idx{$Q{tg}});
my $i=$id2idx{$Q{tg}};
if ($Q{md} eq "free")
	{
	PushLog(2,0,"영주".$DT->{name}."는".$DT[$i]->{shopname}."의세를 면제했습니다.") if ($DT[$i]->{taxmode}!=1);
	$DT[$i]->{taxmode}=1;
	$disp.=$DT[$i]->{shopname}."의세를 면제했습니다.";
	}
elsif ($Q{md} eq "double")
	{
	PushLog(2,0,"영주".$DT->{name}."는".$DT[$i]->{shopname}."의세율을 배에했습니다.") if ($DT[$i]->{taxmode}!=2);
	$DT[$i]->{taxmode}=2;
	$disp.=$DT[$i]->{shopname}."의세율을 배에했습니다.";
	}
	else
	{
	PushLog(2,0,"영주".$DT->{name}."는".$DT[$i]->{shopname}."의면세를 처리나 메했습니다.") if ($DT[$i]->{taxmode}==1);
	PushLog(2,0,"영주".$DT->{name}."는".$DT[$i]->{shopname}."의배 세금을 처리나 메했습니다.") if ($DT[$i]->{taxmode}==2);
	delete $DT[$i]->{taxmode};
	$disp.=$DT[$i]->{shopname}."의세를 일반에복귀했습니다.";
	}
}

sub treset
{
foreach (@DT) {
	delete $_->{taxmode};
}
PushLog(2,0,"영주".$DT->{name}."는배 세금나 면세를 모두처리나 메했습니다.");
$disp.="전체의 점의세율을 일반에복귀했습니다.";
}

sub expose
{
OutError('반란안 때문에 실행할 수 없습니다.') if $DTevent{rebel};
OutError('대상점을 선택해 주세요.') if !defined($id2idx{$Q{tg}});
OutError('비용이 부족합니다.') if ($STATE->{money} < 1000000);
my $i=$id2idx{$Q{tg}};
OutError($image[0].'그점포에 대한 마감는 별로 의 미가없는 것 같습니다조.') if ($DT[$i]->{rank} < 2000) ;
$STATE->{money}-=1000000;
$DT[$i]->{rank}=int($DT[$i]->{rank} / 10);
$STATE->{safety}+=500;
$STATE->{safety}=10000 if $STATE->{safety} > 10000;
PushLog(2,0,"영주".$DT->{name}."는".$DT[$i]->{shopname}."에 대한 평판을 낮췄습니다.");
$disp.=$DT[$i]->{shopname}."에 대한 평판을 낮췄습니다.";
}

