#!/usr/bin/perl
# 드래곤 경주처리 2005/03/30 유래

$NOITEM=1;
$NOMENU=1;
CoLock();
DataRead();
CheckUserPass();
RequireFile('inc-dragon.cgi');

RequireFile("inc-dras-$Q{mode}.cgi");
CoUnLock();
OutSkin();
1;

