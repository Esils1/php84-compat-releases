#!/usr/bin/perl
# 이사시센타 2004/01/20 유래

OutError('다른 마을로 이동할 수 없습니다') if !$MOVETOWN_ENABLE;
OutError('마을 코드가 설정되어 있지 않습니다') if !$TOWN_CODE;
my $townmaster=ReadTown($TOWN_CODE,'getown');
OutError('이전 대상 거리와 연결되어 있지 않습니다') if !$townmaster;

DataRead();
CheckUserPass();

$disp.=GetTownListHTML();
OutSkin();
1;


sub GetTownListHTML
{
	my @townlist=ReadTown();
	return '<b>이전 가능나거리를 찾을 수 없습니다</b>' if !scalar(@townlist);

	my $ret;
	$ret.='<BIG>●다른 도시로 이사시</BIG><br><br>';
	$ret.=$TBT.$TRT.$TD;
	foreach(@townlist)
	{
		$ret.="<SPAN>".$_->{name}."</SPAN><br>";
		$ret.=GetTagA("[확인]","action.cgi?key=jump&town=$_->{code}",0,"_blank");
		$ret.=GetTagA("[이전절차]","action.cgi?key=move-f&$USERPASSURL&towncode=$_->{code}") if !$GUEST_USER;
		$ret.="<br>".$_->{comment}."<br><br>";
	}
	$ret.=$TRE.$TBE;
	return $ret;
}

