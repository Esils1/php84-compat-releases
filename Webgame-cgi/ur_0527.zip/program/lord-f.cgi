#!/usr/bin/perl
# 영주시행정치 2005/01/06 유래

$image[0]=GetTagImgKao("대신","minister");
DataRead();
CheckUserPass();
OutError('정치를 할 수 있는 것은 영주뿐입니다') if $STATE->{leader}!=$DT->{id};

my $shoplist="";
my $taxsum=0;
foreach (@DT) {
$shoplist.="<OPTION VALUE=\"$_->{id}\">$_->{shopname}";
$taxsum+=$_->{taxtoday};
}

my $now=$DTlasttime+$TZ_JST-$DATE_REVISE_TIME;
my $ii=($now % $ONE_DAY_TIME);
$ii=1 if $ii < 1;
$taxsum=GetMoneyString(int($taxsum * $ONE_DAY_TIME / $ii / 10000) * 10000);

$disp.="<BIG>●정치무실</BIG><br><br>";
$disp.=$TB.$TR.$TD.$image[0].$TD."<SPAN>대신</SPAN>:이것은 이것은 영주님. 고기계싫음우루와 슈우고 있습니다.<br>";
$disp.="정무를 대신 맡길 사람을 임명해 주시면 좋겠군요. 흠.".$TRE.$TBE;
my $money=GetMoneyString($STATE->{money}+0);
my $army=$STATE->{army} + $STATE->{robina};
my $armycost=200-int($STATE->{safety} / 100); 	# 100 - 200
my $armyc=GetMoneyString($STATE->{army} * $armycost);

$disp.=<<"HTML";
<hr width=500 noshade size=1><BIG>●내정 설정</BIG><br><br>
<FORM ACTION="action.cgi" $METHOD>
<INPUT TYPE=hidden NAME=key VALUE="lord-s">
$USERPASSFORM
<INPUT TYPE=hidden NAME=mode VALUE="inside">
$TB$TDB 거리 자금$TDB 세수 전망$TDB 세율
$TDB 개척 예산$TDB 치안 예산$TRE
$TR$TD<b>$money</b>
$TD$taxsum
$TD<INPUT TYPE=TEXT NAME=taxrate SIZE=5 VALUE="$DTTaxrate"> %<br><small>(표준 20%)</small>
$TD$term[0]<INPUT TYPE=TEXT NAME=devem SIZE=10 VALUE="$STATE->{devem}">$term[1]<br><small>(표준 $term[0]5,000,000$term[1])</small>
$TD$term[0]<INPUT TYPE=TEXT NAME=safem SIZE=10 VALUE="$STATE->{safem}">$term[1]<br><small>(표준 $term[0]5,000,000$term[1])</small>
$TRE$TBE
<br><INPUT TYPE=SUBMIT VALUE="위 내용으로 설정">
</FORM>

<hr width=500 noshade size=1><BIG>●상벌</BIG><br><br>
<FORM ACTION="action.cgi" $METHOD>
<INPUT TYPE=hidden NAME=key VALUE="lord-s">
$USERPASSFORM
<INPUT TYPE=hidden NAME=mode VALUE="taxside">
<BIG>●개세율</BIG>:
<SELECT NAME=tg>$shoplist</select>
 의세율을
<SELECT NAME=md><OPTION VALUE="normal">일반
<OPTION VALUE="free">면제
<OPTION VALUE="double">２배
</select> 에 <INPUT TYPE=SUBMIT VALUE="설정하기">
</FORM>
<FORM ACTION="action.cgi" $METHOD>
<INPUT TYPE=hidden NAME=key VALUE="lord-s">
$USERPASSFORM
<INPUT TYPE=hidden NAME=mode VALUE="treset">
<BIG>●세율리 설정</BIG>:
모두의 점의세율을 일반 에 <INPUT TYPE=SUBMIT VALUE="리 설정하기">
</FORM>
HTML

if ($DTevent{rebel})
{
$disp.="<BIG>●점포마감</BIG>: 반란안 때문에 실행할 수 없습니다";
}
elsif ($STATE->{army} < 2000)
{
$disp.="<BIG>●점포마감</BIG>: 마감에필요한병사수가 부족합니다";
}
elsif ($STATE->{money} < 1000000)
{
$disp.="<BIG>●점포마감</BIG>: 비용이 부족합니다";
}
else
{
$disp.=<<"STR";
<FORM ACTION="action.cgi" $METHOD>
<INPUT TYPE=hidden NAME=key VALUE="lord-s">
$USERPASSFORM
<INPUT TYPE=hidden NAME=mode VALUE="expose">
<BIG>●점포마감</BIG>:
<SELECT NAME=tg>$shoplist</select>을 군부대에서
 <INPUT TYPE=SUBMIT VALUE="폐점하기"> (비용$term[0]1,000,000$term[1])
</FORM>
STR
}

$disp.=<<"HTML";
<hr width=500 noshade size=1><BIG>●군사 설정</BIG><br><br>
$TB$TR$TDB 현재의 병력
$TD<b>$army 인</b><small>(정규군 $STATE->{army}인, 의용군 $STATE->{robina}인)$TRE
$TR$TDB 병력 유지비
$TD<b>$armyc</b><small>(정규군 1명당 $term[0]$armycost$term[1])$TRE
$TBE
HTML

if ($STATE->{money}>0 && !$DTevent{rebel})
{
	$disp.=<<STR;
	<FORM ACTION="action.cgi" $METHOD>
	<INPUT TYPE=hidden NAME=key VALUE="lord-s">
	$USERPASSFORM
	<INPUT TYPE=hidden NAME=mode VALUE="outside">
	<BIG>●병력증강</BIG>: 병사를
	<SELECT NAME=cnt1>
	<OPTION VALUE="0" SELECTED>
STR
	my $stock=int($STATE->{money} / 1200);
	$msg{1000}=1000;
	$msg{5000}=5000;
	$msg{10000}=10000;
	$msg{20000}=20000;
	$msg{$stock}="$stock(자금최대)";
	my $oldcnt=0;
	foreach my $cnt (sort { $a <=> $b } (1000,5000,10000,20000,$stock))
	{
		last if $stock<$cnt || $cnt==$oldcnt;
		$disp.="<OPTION VALUE=\"$cnt\">$msg{$cnt}";
		$oldcnt=$cnt;
	}
	$disp.=<<STR;
	</SELECT>
	 인, 또는
	<INPUT TYPE=TEXT SIZE=7 NAME=cnt2> 인
	<INPUT TYPE=SUBMIT VALUE="증강하다"> @$term[0]1,200$term[1]
	</FORM>
STR
	$disp.=<<STR;
	<FORM ACTION="action.cgi" $METHOD>
	<INPUT TYPE=hidden NAME=key VALUE="lord-s">
	$USERPASSFORM
	<INPUT TYPE=hidden NAME=mode VALUE="outdel">
	<BIG>●병력삭감</BIG>: 병사를
	<SELECT NAME=cnt1>
	<OPTION VALUE="0" SELECTED>
STR
	my $army=$STATE->{army}+0;
	$msg{1000}=1000;
	$msg{5000}=5000;
	$msg{10000}=10000;
	$msg{20000}=20000;
	$msg{$army}="$army(병사최대)";
	my $oldcnt=0;
	foreach my $cnt (sort { $a <=> $b } (1000,5000,10000,20000,$army))
	{
		last if $army<$cnt || $cnt==$oldcnt;
		$disp.="<OPTION VALUE=\"$cnt\">$msg{$cnt}";
		$oldcnt=$cnt;
	}
	$disp.=<<STR;
	</SELECT>
	 인, 또는
	<INPUT TYPE=TEXT SIZE=7 NAME=cnt2> 인
	<INPUT TYPE=SUBMIT VALUE="해고하다"> @$term[0]0$term[1]
	</FORM>
STR
}

OutSkin();
1;
