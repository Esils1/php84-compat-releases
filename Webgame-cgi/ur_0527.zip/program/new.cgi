#!/usr/bin/perl
# 신규 개점 2004/01/20 유래

$image[0]=GetTagImgKao("안내인","guide");
DataRead();

if($Q{admin} ne $MASTER_PASSWORD)
{
	OutError('신규 점포 등록 권한이 없습니다.') if $NEW_SHOP_ADMIN;
	OutError('당신은 벌써 점포를 가지고 있습니다.') if GetIPList(GetTrueIP());
	OutError('당신은 다른 거리에서 벌써 점포를 가지고 있습니다.') if $NEW_OTHERTOWN_BLOCK && GetDoubleIP(GetTrueIP());
	OutError('당신은 현재 등록제한 되고 있습니다.') if $NEW_SHOP_BLOCKIP && GetTrueIP() eq $DTblockip;
	OutError('출점 키워드가 올바르지는 않습니다.') if $NEW_SHOP_KEYWORD && $Q{sname} && $Q{newkey} ne $NEW_SHOP_KEYWORD;
	checkMaxUser();
}

if($Q{sname}.$Q{name}.$Q{pass1}.$Q{pass2})
{
	if(($Q{sname}.$Q{name}.$Q{pass1}.$Q{pass2}) =~ /([,:;\t\r\n<>&])/
	|| ($Q{pass1}.$Q{pass2}) =~ /([^A-Za-z0-9_\-])/  #.$Q{name}를 삭제
	|| $Q{name} eq 'soldoutadmin'
	|| CheckNGName($Q{sname})
	|| CheckNGName($Q{name})  #이름의 체크를 추가
	)
	{
		OutError('이름·점명·패스워드에 사용할 수 없는'.
		         '캐릭터가 포함되어 있습니다.');
	}
	if(!$Q{sname} || !$Q{name} || !$Q{pass1} || !$Q{pass2})
	{
		OutError('이름·점명·패스워드를 입력해 주세요.');
	}
	if($Q{pass1} ne $Q{pass2})
	{
		OutError('확인 패스워드가 차이가 납니다.');
	}
	if(length($Q{sname})<4)
	{
		OutError('점명의 캐릭터수가 적습니다.');
	}
	if(length($Q{name})>12 || length($Q{sname})>20
	|| length($Q{pass1})>12 || length($Q{pass2})>8)
	{
		OutError('이름(전각 6 캐릭터)·점명(전각 10 캐릭터)·패스워드(8 캐릭터)의 캐릭터수가 많습니다.');
	}
	if( $Q{name} eq $Q{pass1} )
	{
		OutError('이름과 패스워드는 같게 하지 말아 주세요.');
	}
	
	Lock();
	DataRead();
	OutError('이미 존재하는 이름입니다.-> '.$Q{name}) if $name2pass{$Q{name}};
	OutError('이미 존재하는 점명입니다.-> '.$Q{sname}) if GetDoubleName($Q{sname});;
	
	$idx=$DTusercount;
	$DTlasttime=$NOW_TIME if !$idx;
	$DT[$idx]={};
	$DT=$DT[$idx];
	$DT->{status}	    =1;
	$DT->{id}           =$DTnextid;
	$DT->{lastlogin}    =$NOW_TIME;
	$DT->{name}         =$Q{name};
	$DT->{shopname}     =$Q{sname};
	$DT->{icon}     =$Q{icon};
	$DT->{pass}         =$PASSWORD_CRYPT ? crypt($Q{pass1},GetSalt()) : $Q{pass1};
	$DT->{money}        =100000;
	$DT->{moneystock}   =0;
	$DT->{time}         =$NOW_TIME-12*60*60;
	$DT->{rank}         =5010;
	$DT->{saleyesterday}=0;
	$DT->{saletoday}    =0;
	$DT->{costtoday}    =0;
	$DT->{costyesterday}=0;
	$DT->{paytoday}     =0;
	$DT->{payyesterday} =0;
	$DT->{showcasecount}=1;
	$DT->{itemyesterday}={};
	$DT->{itemtoday}	={};
	$DT->{remoteaddr}   =GetTrueIP();
	$DT->{rankingyesterday}='';
	$DT->{taxtoday}     =0;
	$DT->{taxyesterday} =0;
	$DT->{foundation}   =$NOW_TIME;
	foreach $cnt (0..$DT->{showcasecount}-1)
	{
		$DT->{showcase}[$cnt]=0;
		$DT->{price}[$cnt]=0;
	}
	foreach $cnt (0..$MAX_ITEM-1)
	{
		$DT->{item}[$cnt]=0;
	}

	$DTblockip=$DT->{remoteaddr};

	require "$ITEM_DIR/funcnew.cgi" if $DEFINE_FUNCNEW;
	PushLog(1,0,$Q{sname}."가 신장개점했습니다.") if !$DEFINE_FUNCNEW || !$DEFINE_FUNCNEW_NOLOG;

	RenewLog();
	DataWrite();
	DataCommitOrAbort();
	UnLock();

	$disp=<<STR;
거리에 새로운 가게가 탄생했습니다.<br><br>
$TB$TR$TD
<SPAN>이름</SPAN>：$Q{name}<BR>
<SPAN>점명</SPAN>：$Q{sname}<BR>
<SPAN>패스워드</SPAN>：$Q{pass1}
$TRE$TBE
<BR>※패스워드는 반드시 메모를 취해 둬 주세요.<BR><BR>
$TB$TR
$TD$image[0]$TD
스타트 하면(자),우선<SPAN>[게시판]</SPAN>으로 인사를 하면 좋을 것입니다.<br>
또<SPAN>[도서관]</SPAN>에 경영의 힌트가 있기 때문에 대충 봐 주세요.
$TRE$TBE
<BR>
<A HREF=\"index.cgi?u=$Q{name}!$Q{pass1}\">게임 스타트</A> <BR><BR>
로그인 후 [♪]를 누르면 BGM을 재생할 수 있습니다.
STR
	OutSkin();
	exit;
}

RequireFile("inc-new.cgi");
OutSkin();
1;

sub checkMaxUser
{
	OutError($TB.$TR.$TD.$image[0].$TD.'죄송합니다만,현재 만원이 되고 있습니다.<BR>빈 곳이 나오는 것을 기다려 주세요.'.$TRE.$TBE)
		if $DTusercount>=$MAX_USER;
}

sub GetDoubleIP
{
	foreach my $pg(@OtherDir)
	{
	my $datafile='../'.$pg.'/data/user.cgi';
	my($ip)=@_;
	open(IN,$datafile) or return();
	my @data=<IN>;
	close(IN);
	my @list=map{(split(/\t/,$_))[4]}@data;
	@list=grep($_ eq $ip,@list) if $ip ne '';
	return @list if (@list);
	}
}

