#!/usr/bin/perl
# 이벤트 함수 2005/01/06 유래

package event; #변경불가

######################################################################
# ★이벤트용보조 처리함수:로그 기록
# usage: WriteLog(중요도, 대상점포 ID, 메시지)
# 중요도 0==일반 1==중요 2==정보
# 대상점포 ID 0==전체 점포 대상 점포 ID==비공개
# 메시지 로그 메시지
# return: 0 고정
######################################################################
sub WriteLog
{
	main::PushLog($_[0],$_[1],$_[2]);
	return 0;
}

######################################################################
# ★디버그용로그 기록
# usage: DebugLog(메시지)
# 메시지 로그 메시지
# return: 0 고정
######################################################################
sub DebugLog
{
	my($msg)=@_;
	main::WriteErrorLog($msg,$main::LOG_DEBUG_FILE) if $main::DEBUG_LOG_ENABLE;
	return 0;
}

######################################################################
# ★시장재고조사:이벤트발동키카케판단용
# usage: stock_le(아이템번호, 개수)
# return: 1 시장의 아이템의 재고가 지정 개수 이하인 경우
# 0 위 항목 이외
######################################################################
sub stock_le
{
	my($itemno,$count)=@_;
	return 1 if $main::DTwholestore[$itemno-1]<=$count;
	return 0;
}

######################################################################
# ★시장재고조사:이벤트발동키카케판단용
# usage: stock_ge(아이템번호, 개수)
# return: 1 시장의 아이템의 재고가개수이상의 경우
# 0 위 항목 이외
######################################################################
sub stock_ge
{
	my($itemno,$count)=@_;
	return 1 if $main::DTwholestore[$itemno-1]>=$count;
	return 0;
}

sub GetUserData
{
	return &main::GetUserData;
}

sub GetMoneyString
{
	return &main::GetMoneyString;
}

require "$main::ITEM_DIR/funcevent.cgi" if $main::DEFINE_FUNCEVENT;
1;
