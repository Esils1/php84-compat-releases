#!/usr/bin/perl
# 의뢰양식 2005/03/30 유래

DataRead();
CheckUserPass();
RequireFile('inc-req.cgi');
RequireFile('inc-html-ownerinfo.cgi');

$disp.="<BIG>●의뢰소</BIG><br><br>";

ReqSet();
my $limit=GetTime2HMS($REQUEST_LIMIT);
$disp.=<<STR;
$TB$TR$TD
$AucImg
새로운 의뢰서를 쓰는구나? 그렇다면 주의 사항을 잘 읽어 줘.<br>
·의뢰는 동시에 <b>$REQUEST_CAPACITY개</b>까지만 등록할 수 있습니다.<br>
·의뢰가 달성되면 <SPAN>받으러 와주세요</SPAN>.<br>
·유효기간 <b>$limit</b>이내에 받으러 오지 않는다면 의뢰는 파기됩니다.<br>
·판매/매입에서는 가격의 <b>$DTTaxrate%</b>의 세금이 의뢰자에게 부과됩니다.
$TRE$TBE
<hr width=500 noshade size=1>
<FORM ACTION="action.cgi" $METHOD>
<INPUT TYPE=HIDDEN NAME=key VALUE="req-s">
$USERPASSFORM
<INPUT TYPE=HIDDEN NAME=mode VALUE="new">
<INPUT TYPE=HIDDEN NAME=id VALUE="$DT->{id}">
<BIG>●교환 타입</BIG>:의뢰품 <SELECT NAME=prn SIZE=1>
$formlist
</SELECT>을 수량 <INPUT TYPE=TEXT NAME=pr SIZE=7> 가지고 와준 분에게는<br>
답례 <SELECT NAME=it SIZE=1>
$formitem
</SELECT>을 수량 <INPUT TYPE=TEXT NAME=num SIZE=7> 드립니다.
<INPUT TYPE=SUBMIT VALUE='작성'>
</FORM>
<hr width=500 noshade size=1>
<FORM ACTION="action.cgi" $METHOD>
<INPUT TYPE=HIDDEN NAME=key VALUE="req-s">
$USERPASSFORM
<INPUT TYPE=HIDDEN NAME=mode VALUE="new">
<INPUT TYPE=HIDDEN NAME=id VALUE="$DT->{id}">
<BIG>●판매 타입</BIG>:판매품 <SELECT NAME=it SIZE=1>
$formitem
</SELECT>을 수량 <INPUT TYPE=TEXT NAME=num SIZE=7> 판매하려고 합니다.<br>
가격 <INPUT TYPE=TEXT NAME=pr SIZE=7> $term[2](
<INPUT TYPE=CHECKBOX NAME=unit>단가 지정)에서 사 주세요.
<INPUT TYPE=HIDDEN NAME=prn VALUE="-1">
<INPUT TYPE=SUBMIT VALUE='작성'>
</FORM>
<hr width=500 noshade size=1>
<FORM ACTION="action.cgi" $METHOD>
<INPUT TYPE=HIDDEN NAME=key VALUE="req-s">
$USERPASSFORM
<INPUT TYPE=HIDDEN NAME=mode VALUE="new">
<INPUT TYPE=HIDDEN NAME=id VALUE="$DT->{id}">
<BIG>●매입 의뢰</BIG>:의뢰품 <SELECT NAME=prn SIZE=1>
$formlist
</SELECT>을 수량 <INPUT TYPE=TEXT NAME=pr SIZE=7> 가지고 와준 분에게는<br>
가격 <INPUT TYPE=TEXT NAME=num SIZE=7> $term[2](
<INPUT TYPE=HIDDEN NAME=it VALUE="-1">
<INPUT TYPE=CHECKBOX NAME=unit>단가를 지정해 매입합니다.
<INPUT TYPE=SUBMIT VALUE='작성'>
</FORM>
STR
OutSkin();
1;


sub ReqSet
{
	my @sort;
	foreach(1..$MAX_ITEM){$sort[$_]=$ITEM[$_]->{sort}};
	my @itemlist=sort { $sort[$a] <=> $sort[$b] } (1..$MAX_ITEM);
	$formitem="";
	$formlist="";		#전체체의 목록
	foreach my $idx (@itemlist)
	{
		next if !$ITEM[$idx]->{name};
		next if $ITEM[$idx]->{flag}=~/r/;	# r 의뢰불가
		my $cnt=$DT->{item}[$idx-1];
		my $scale=$ITEM[$idx]->{scale};
		my $price=$ITEM[$idx]->{price};
		$formlist.="<OPTION VALUE=\"$idx\">$ITEM[$idx]->{name}(@".GetMoneyString($price).")" if $ITEM[$idx]->{flag}!~/o/;		# o 의뢰는 출품의 미
		$formitem.="<OPTION VALUE=\"$idx\">$ITEM[$idx]->{name}($cnt$scale@".GetMoneyString($price).")" if $cnt;
	}
}

