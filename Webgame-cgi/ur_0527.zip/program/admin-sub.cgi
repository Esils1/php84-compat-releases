#!/usr/bin/perl
BEGIN {
	*Utf8Text = sub {
		my($s)=@_;
		return '' unless defined $s;
		utf8::decode($s) unless utf8::is_utf8($s);
		return $s;
	} unless defined &Utf8Text;

	*Utf8InPlace = sub {
		utf8::decode($_[0]) if defined $_[0] && !utf8::is_utf8($_[0]);
	} unless defined &Utf8InPlace;
}
# 개 사용자 관리 2005/03/30 유래

Lock();
DataRead();
CheckUserPass();
OutError('') if !$MASTER_USER || $USER ne 'soldoutadmin';

OutError('사용자를 찾을 수 없습니다') if !defined($name2idx{$Q{user}});
my $DT=$DT[$name2idx{$Q{user}}];

$Q{comment}="[".Utf8Text($Q{comment})."]" if $Q{comment} ne '';

#중복등록 자동 접근 제한의 개 대응
if($Q{nocheckip})
{
	$disp.='중복등록 확인대상에서 제외했습니다',$DT->{nocheckip}=1 if $Q{nocheckip} eq 'nocheck';
	$disp.='중복등록 확인대상으로 설정했습니다',$DT->{nocheckip}='' if $Q{nocheckip} eq 'check';
}

#접근제한제어
if($Q{blocklogin})
{
	$Q{blocklogin}=Utf8Text($Q{blocklogin});
	if($Q{blocklogin} eq 'off')
	{
		$disp.='접근제한을 해제했습니다';
		$DT->{blocklogin}='';
		$DT->{lastlogin}=$NOW_TIME;
	}
	elsif($Q{blocklogin} eq 'stop')
	{
		$disp.='경영 휴지로 설정했습니다['.$Q{blocklogin}.']';
		$DT->{blocklogin}=$Q{blocklogin};
	}
	elsif($Q{blocklogin} ne '')
	{
		$disp.='접근제한을 했습니다['.$Q{blocklogin}.']';
		$DT->{blocklogin}=$Q{blocklogin};
	}
}

#추방
if($Q{closeshop} eq 'closeshop')
{
	CloseShop($DT->{id},'추방');
	PushLog(1,0,"$Q{comment}$DT->{shopname}은추방되었습니다.") if (!$Q{log});

	$disp.="추방완료";
	$DTblockip=$DT->{remoteaddr};
}

#상품 수여(디버그에도사용할 수 있습니다)
if($Q{senditem})
{
	my $itemno=$Q{senditem};
	my $ITEM=$ITEM[$itemno];
	my $itemcount=$Q{count};
	$itemcount+=$DT->{item}->[$itemno-1];
	$itemcount=$ITEM->{limit} if $itemcount>$ITEM[$itemno]->{limit};
	$DT->{item}->[$itemno-1]=$itemcount;

	PushLog(2,0,"$Q{comment}$DT->{shopname}에$ITEM->{name}이증정라되었습니다.") if $Q{comment};
	$disp.="$ITEM->{name} $Q{count}$ITEM->{scale} 상품 수여완료";
}

#상금수여(디버그에도사용할 수 있습니다)
if($Q{sendmoney})
{
	$DT->{money}+=$Q{sendmoney};
	#$DT->{saletoday}+=$Q{sendmoney};

	PushLog(2,0,"$Q{comment}$DT->{shopname}에상금이증정라되었습니다.") if $Q{comment};
	$disp.=GetMoneyString($Q{sendmoney})." 상금수여완료";
}

#보유하고 시간수여(디버그에도사용할 수 있습니다)
if($Q{sendtime})
{
	$disp.=$Q{sendtime}."시간 보유하고 시간수여완료";
	$Q{sendtime}=$Q{sendtime} * 3600;
	$DT->{time}-=$Q{sendtime};

	PushLog(2,0,"$Q{comment}$DT->{shopname}에'".GetTime2HMS($Q{sendtime})."'가증정라되었습니다.") if $Q{comment};
}

#작위수여(디버그에도사용할 수 있습니다)
if($Q{senddig})
{
	$disp.=$Q{senddig}."포인트 작위경험치수여완료";
	$DT->{dignity}+=$Q{senddig};

	PushLog(2,0,"$Q{comment}$DT->{shopname}에작위경험치".($Q{senddig}+0)."포인트가증정라되었습니다.") if $Q{comment};
}

RenewLog();
DataWrite();
DataCommitOrAbort();
UnLock();

$disp="줄있었음이처리와 그매개변수를 정하게선택/기술해 주세요" if $disp eq '';
$disp.=" <-- $DT->{shopname} [$DT->{name}] $Q{comment}";

$NOMENU=1;
$Q{bk}="none";
OutSkin();
1;
