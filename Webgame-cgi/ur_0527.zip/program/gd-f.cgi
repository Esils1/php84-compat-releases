#!/usr/bin/perl
# 길드편집양식 2004/01/20 유래

$NOITEM=1;
DataRead();
CheckUserPass(1);
RequireFile('inc-gd.cgi');

if ($DT->{guild})
{
GuildEditMenu();
}
elsif ($DT->{dignity} < $DIG_FORGUILD)
{
$disp.=$TB.$TR.$TD.$image[0].$TD."<SPAN>길드 접수</SPAN>: 여기는 길드를 만들 수 있습니다.<br>";
$disp.="길드를 만드는 데에는 $DIG_FORGUILD 포인트 이상의 작위가 필요합니다.".$TRE.$TBE."<br>";
$disp.="조건을 충족하지 않습니다";
}
else
{
GuildBuildMenu();
}
OutSkin();
1;


sub GuildEditMenu
{
my $leaderid=$GUILD_DETAIL{$DT->{guild}}->{leader};
OutError('길드를 변경할 수 있는 는단장만입니다') if (defined($id2idx{$leaderid}) && $leaderid != $DT->{id});
ReadLetterName();
$code=$DT->{guild};
$GUILD_DETAIL{$code}->{url}="http://" if !$GUILD_DETAIL{$code}->{url};
$disp.=$TB.$TR.$TD.$image[0].$TD."<SPAN>길드 접수</SPAN>:여기는".GetTagImgGuild($code);
$disp.="<BIG>".$GUILD{$code}->[$GUILDIDX_name]."</BIG> 집행무실입니다.<br>";
$disp.="단장님, 앞으로 의 길드를 도 수 있도록 나사루오생각입니까?".$TRE.$TBE."<br>";
my $i=GuildCommonForm();

$disp.=<<"HTML";
<FORM ACTION="action.cgi" enctype="multipart/form-data" $METHOD>
<INPUT TYPE=hidden NAME=key VALUE="gd-b">
$USERPASSFORM
<INPUT TYPE=hidden NAME=mode VALUE="edit">
$TB$TR$TDB<b>길드 코드</b>
<td colspan=2><b>$code</b><INPUT TYPE=HIDDEN NAME=code VALUE="$code">$TRE
$TR$TDB<b>길드이미지</b><br>(32*16pt)
<td colspan=2>gif 형식이미지의 미(지정하지 않으면현상태의 그대로)<br><input type=file name=upfile size=36>$TRE
$TR$TDB<b>길드홈페이지</b><br>(60자 이내)
<td colspan=2>일반향케홈페이지<br><INPUT TYPE=TEXT NAME=url SIZE=56 VALUE="$GUILD_DETAIL{$code}->{url}">$TRE
$i
$TR$TDB<b>군사임명</b><br>(각거리 1이름까지)
HTML

my $r=int(scalar(@OtherDir) / 2 + 0.5);$r||=1;
foreach(0..$#OtherDir)
	{
	my $pg=$OtherDir[$_];
	$disp.=( ($_ % $r) ? "<br>" : $TD);
	$disp.="$Tname{$pg} <SELECT NAME=$pg><OPTION VALUE=\"\">----";
	foreach my $i(0..$Ncount{$pg})
		{
		$disp.="<OPTION VALUE=\"$LID{$pg}[$i]\"".($GUILD_DETAIL{$code}->{$pg}==$LID{$pg}[$i] ? ' SELECTED' : '').">$LNAME{$pg}[$i]";
		}
	$disp.="</SELECT>\n";
	}

$disp.=<<"HTML";
$TRE$TBE
<br><INPUT TYPE=SUBMIT VALUE="위 내용으로 설정">
<br>(반영됩니다에는 수분걸립니다)
</FORM>
HTML
}


sub GuildBuildMenu
{
$code="";
$disp.=$TB.$TR.$TD.$image[0].$TD."<SPAN>길드 접수</SPAN>: 여기는 길드를 만들 수 있습니다.<br>";
$disp.="새 단장님, 도의 같은 길드를 결성나사루오생각입니까?".$TRE.$TBE."<br>";
my $i=GuildCommonForm();

$disp.=<<"HTML";
<FORM ACTION="action.cgi" enctype="multipart/form-data" $METHOD>
<INPUT TYPE=hidden NAME=key VALUE="gd-b">
$USERPASSFORM
<INPUT TYPE=hidden NAME=mode VALUE="make">
$TB$TR$TDB<b>길드 코드</b><br>(10자 이내)
<td colspan=2>반각영숫자<b>소문자의 미</b><br><INPUT TYPE=TEXT NAME=code SIZE=10 VALUE="">$TRE
$TR$TDB<b>길드이미지</b><br>(32*16pt)
<td colspan=2>gif 형식이미지의 미<br><input type=file name=upfile size=36>$TRE
$i
$TBE
<br><INPUT TYPE=SUBMIT VALUE="위 내용으로 설정">
<br>(반영됩니다에는 수분걸립니다)
</FORM>
HTML
}

sub GuildCommonForm
{
my $i.=<<"HTML";
$TR$TDB<b>길드정식명칭</b><br>(30자 이내)
<td colspan=2>상세표\표시의 때에 사용와 됨이름<br><INPUT TYPE=TEXT NAME=name SIZE=24 VALUE="$GUILD_DETAIL{$code}->{name}">$TRE
$TR$TDB<b>길드통명칭</b><br>(12자 이내)
<td colspan=2>약칭<br><INPUT TYPE=TEXT NAME=shortname SIZE=12 VALUE="$GUILD_DETAIL{$code}->{shortname}">$TRE
$TR$TDB<b>길드간할인 증가율</b><br>(반각숫자의 미)
<td colspan=2>10배의 값을 지정(30%에하다에는300와 기입.10~500)<br><INPUT TYPE=TEXT NAME=dealrate SIZE=6 VALUE="$GUILD_DETAIL{$code}->{dealrate}">$TRE
$TR$TDB<b>길드간회비율</b><br>(반각숫자의 미)
<td colspan=2>10배의 값을 지정(3%에하다에는30와 기입.10~500)<br><INPUT TYPE=TEXT NAME=feerate SIZE=6 VALUE="$GUILD_DETAIL{$code}->{feerate}">$TRE
$TR$TDB<b>멤버호출명칭</b><br>(6자 이내)
<td colspan=2>'회원''동일뜻'등<br><INPUT TYPE=TEXT NAME=member SIZE=6 VALUE="$GUILD_DETAIL{$code}->{member}">$TRE
$TR$TDB<b>결메대단어</b><br>(30자 이내)
<td colspan=2> 목록에표\표시됩니다게시판문구문<br><INPUT TYPE=TEXT NAME=comment SIZE=24 VALUE="$GUILD_DETAIL{$code}->{comment}">$TRE
$TR$TDB<b>활동소개</b><br>(120자 이내)
<td colspan=2>길드의 활동 목적이나 소개<br><INPUT TYPE=TEXT NAME=appeal SIZE=60 VALUE="$GUILD_DETAIL{$code}->{appeal}">$TRE
$TR$TDB<b>가입조건</b><br>(120자 이내)
<td colspan=2>'입리타이분은 단장수신테에편지를'등<br><INPUT TYPE=TEXT NAME=needed SIZE=60 VALUE="$GUILD_DETAIL{$code}->{needed}">$TRE
HTML
return $i;
}

