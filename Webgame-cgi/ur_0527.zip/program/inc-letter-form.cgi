#!/usr/bin/perl
# 폼 표시 2004/01/20 유래

$disp.=GetMenuTag('letter','[수신상자]')
	.GetMenuTag('letter','[송신상자]','&old=list')
	."<b>[편지를 쓴다]</b>";
$disp.="<hr width=500 noshade size=1>";
my $cnt=$MAX_BOX - scalar(@SENLETTER);
if ($cnt > 0)
{
$preerror="";
LFormCheck() if ($Q{form} eq 'check');
NewLform() if ($preerror || $Q{form} eq 'make');
}
else
{
$disp.=<<"HTML";
$TB$TR
$TD$image[0]$TD
<SPAN>도우미</SPAN>:  더 이상 편지를 보낼 수 없습니다.<br>
송신 끝난 편지를 삭제해 주세요.
$TRE$TBE
HTML

}


1;

sub NewLform
{
$disp.=<<"HTML";
$TB$TR
$TD$image[0]$TD
<SPAN>도우미</SPAN>:  편지는 최대 $cnt통까지 보낼 수 있습니다.<br>
매너를 지켜, 받는 입장의 사람을 생각하고 씁시다.
$TRE$TBE<br>$preerror
<FORM ACTION="action.cgi" $METHOD>
$MYFORM$USERPASSFORM
$TB
$TR$TDB<b>행선지</b>(어느쪽이든 1개)
HTML

my $r=int(scalar(@OtherDir) / 2 + 0.5) ;$r||=1;
foreach(0..$#OtherDir)
	{
	my $pg=$OtherDir[$_];
	$disp.=( ($_ % $r) ? "<br>" : $TD);
	$disp.="$Tname{$pg} <SELECT NAME=$pg><OPTION VALUE=\"-1\">행선지 선택";
	foreach my $i(0..$Ncount{$pg})
		{
		$disp.="<OPTION VALUE=\"$LID{$pg}[$i]\"".($Q{$pg}==$LID{$pg}[$i] ?' SELECTED' : '').">$LNAME{$pg}[$i]";
		}
	$disp.="</SELECT>\n";
	}

$disp.=<<"HTML";
$TRE
$TR$TDB<b>타이틀</b>(40자 이내)
<td colspan=2><INPUT TYPE=TEXT NAME=title SIZE=40 VALUE="$Q{title}">$TRE
$TR$TDB<b>편지 내용</b>(400자 이내)
<td colspan=2><INPUT TYPE=TEXT NAME=msg SIZE=60 VALUE="$Q{msg}">$TRE
$TBE
<br><INPUT TYPE=HIDDEN NAME=form VALUE="check">
<INPUT TYPE=SUBMIT VALUE="송신 확인">
</FORM>
HTML
}

sub LFormCheck
{
my $sendmail="";
my $sendto="";
foreach my $pg(@OtherDir)
	{
	$sendmail=$Q{$pg},$sendto=$pg if ($Q{$pg} != -1)
	}
$preerror="행선지를 지정해 주세요.",return if !$sendto;
my $Ln=SearchLetterName($sendmail,$sendto);
$preerror="존재하지 않는 점포입니다.",return if ($Ln == -1);
$preerror="메시지를 입력해 주세요.",return if (!$Q{msg});
$Q{title}="(무제)" if !$Q{title};
$preerror='제목은 반각 40자(전각 20자)까지입니다. 현재 반각 '.length($Q{title}).'자입니다.',return if length($Q{title})>40;
$preerror='편지 내용은 반각 400자(전각 200자)까지입니다. 현재 반각 '.length($Q{msg}).'자입니다.',return if length($Q{msg})>400;

$disp.=<<"HTML";
$TB$TR
$TD$image[0]$TD
도우미: 아래 내용으로 편지를 보냅니다.<br>
다음과 같은지 확인해 주십시오.
$TRE$TBE<br>
<table width=60%>$TR$TD
<SPAN>받는 사람</SPAN>:$Ln <small>($Tname{$sendto})</small><br>
<SPAN>제목</SPAN>: 「$Q{title}」<br>
<SPAN>내용</SPAN>:$Q{msg}<br>
$TRE$TBE
<FORM ACTION="action.cgi" $METHOD>
$MYFORM$USERPASSFORM
<INPUT TYPE=HIDDEN NAME=$sendto VALUE="$sendmail">
<INPUT TYPE=HIDDEN NAME=title VALUE="$Q{title}">
<INPUT TYPE=HIDDEN NAME=msg VALUE="$Q{msg}">
<INPUT TYPE=HIDDEN NAME=form VALUE="make">
<INPUT TYPE=SUBMIT NAME=ok VALUE="송신">
<INPUT TYPE=SUBMIT NAME=ng VALUE="재편집">
</FORM>
HTML
}

