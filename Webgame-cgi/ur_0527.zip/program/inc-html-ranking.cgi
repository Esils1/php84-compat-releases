#!/usr/bin/perl
# 신문(순위) 2005/01/06 유래

my ($page,$pagestart,$pageend,$pagenext,$pageprev,$pagemax)
	=GetPage($Q{pg},$RANKING_PAGE_ROWS,$DTusercount);

$disp.="<BIG>●신문:순위 목록</BIG><br><br>";
my $pagecontrol=GetPageControl($pageprev,$pagenext,"t=4","",$pagemax,$page);
$disp.=$pagecontrol."<BR>";
$disp.=$TB;

if(!$MOBILE)
{
	$disp.=$TR;
	$disp.=$TDB."점수";
	$disp.=$TDB."점장";
	$disp.=$TDB."직업";
	$disp.=$TDB."상점명 / 인기";
	$disp.=$TDB."이번 기수 매출";
	$disp.=$TDB."자금";
	$disp.=$TDB."숙련";
	$disp.=$TDB."상품 [창업] 댓글";
	$disp.=$TRE;
}
else
{
	$tdh_rk="RANK:";
	$tdh_pt="점수:";
	$tdh_nm="상점명:";
	$tdh_pp="인기:";
	$tdh_mo="자금:";
	$tdh_ts="본판매:";
	$tdh_ys="어제판매:";
	$tdh_cs="유지:";
	$tdh_sc="일누름:";
	$tdh_cm="일말:";
	$tdh_tx="어제세:";
	$tdh_ex="숙련:";
	$tdh_fd="창업:";
}

foreach my $idx ($pagestart..$pageend)
{
	my $DT=$DT[$idx];

	my $rankupdown="(신)";
	if($DT->{rankingyesterday})
	{
		$rankupdown=$DT->{rankingyesterday}-$idx-1;
		$rankupdown=$rankupdown==0 ? " → ": $rankupdown<0 ? "↓".(-$rankupdown) : "↑".$rankupdown;
		$rankupdown="<small>($rankupdown)</small>";
	}
	my $itemtype=-1;
	my $itempro="";
	my $salelist="";
	foreach(0..$DT->{showcasecount}-1)
	{
		my $no=$DT->{showcase}[$_];
		$salelist.=GetTagImgItemType($no);
		$itemtype=0,next if $itemtype!=-1 && $ITEM[$no]->{type}!=$itemtype;
		$itemtype=$ITEM[$no]->{type};
	}
	$itempro=GetTagImgItemType(0,$itemtype,1)." " if $itemtype;
	my $itemno=$DT->{showcase}[0];
	$salelist.=" ".$ITEM[$itemno]->{name}." ".GetMoneyString($DT->{price}[0]) if $itemno;

	my $expsum=0;
	foreach(values(%{$DT->{exp}})){$expsum+=$_;}
	$expsum=int($expsum/10)."%";

	$disp.=$TR;
	$disp.="<td align=right><b>No.".($idx+1)."</b>".$rankupdown;
	$disp.="<br>".$DT->{point};
	$disp.=$TDNW.$tdh_pt.GetTagImgKao($DT->{name},$DT->{icon});
	$disp.="<td align=center>".GetTagImgJob($DT->{job},$DT->{icon});
	$disp.=$TD.$tdh_nm;
	$disp.= "<a href=\"action.cgi?key=shop-b&ds=$DT->{id}&$USERPASSURL\">" if !$GUEST_USER;
	$disp.= GetTagImgGuild($DT->{guild}).$job.$DT->{shopname};
	$disp.= "</a>" if !$GUEST_USER;
	$disp.=GetTopCountImage($DT->{rankingcount}+0) if $DT->{rankingcount};
	$disp.="<BR>";
	$disp.=GetRankMessage($DT->{rank});
	$disp.=$TDNW.$tdh_ts.GetMoneyString($DT->{saletoday});
	$disp.=$TDNW.$tdh_mo.GetMoneyMessage($DT->{money});
	$disp.=$TDNW.$tdh_ex.$expsum;

	$disp.=$TD;

	$disp.=$tdh_sc.$itempro.$salelist;

	$disp.="<BR>";

	$disp.=$tdh_fd."[".GetTime2found($NOW_TIME-$DT->{foundation})."]";
	$disp.=$tdh_cm.$DT->{comment} if $DT->{comment};
	$disp.=$TRE;
}
$disp.=$TBE;

$disp.=$pagecontrol;
1;
