#!/usr/bin/perl
# 양식 표시 2005/03/30 유래

$disp.=GetMenuTag('dwarf','[택배 목록]')
	."<b>[택배 보내기]</b>";
$disp.=GetMenuTag('dwarf','[무역품 목록]','&trade=list') if -e "trade.cgi";
$disp.="<hr width=500 noshade size=1>";

my $cnt=$MAX_BOX - scalar(@SENDWF);
if ($cnt > 0)
{
$preerror="";
LFormCheck() if ($Q{form} eq 'check');
NewLform() if ($preerror || $Q{form} eq 'make');
}
else
{
$disp.=<<"HTML";
$TB$TR
$TD$image[0]$TD
<SPAN>상주 드워프</SPAN>: 더 이상 택배를 보낼 수 없습니다.<br>
필요 없는 택배를 정리해 주세요.
$TRE$TBE
HTML
}
1;

sub NewLform
{
FormSet();
$disp.=<<"HTML";
$TB$TR
$TD$image[0]$TD
<SPAN>상주 드워프</SPAN>: 앞으로 $cnt건까지 택배를 보낼 수 있습니다.<br>
받는 상대와 수량을 잘 확인해 주세요.
$TRE$TBE<br>$preerror
<FORM ACTION="action.cgi" $METHOD>
$MYFORM$USERPASSFORM
$TB
$TR$TDB<b>수신처</b>
HTML

$disp.=$TD."<SELECT NAME=to><OPTION VALUE=\"-1\">--수신처선택--";
$disp.="<OPTION VALUE=\"99\">◇다른 도시로 수출◇" if -e "trade.cgi";
	foreach (@DT)
	{
		$disp.="<OPTION VALUE=\"$_->{id}\"".($Q{to}==$_->{id} ? ' SELECTED' : '').">$_->{shopname}";
	}
$disp.="</SELECT>\n";
$disp.="<INPUT TYPE=CHECKBOX NAME=notice".(($preerror&&!$Q{notice}) ? '' : ' checked').">";

$disp.=<<"HTML";
우편으로 알림$TRE
$TR$TDB<b> 상품</b>
$TD<SELECT NAME=item SIZE=1>
$formitem
</SELECT>을 <INPUT TYPE=TEXT NAME=num SIZE=7 VALUE="$Q{num}"> 개$TRE
$TR$TDB<b>대금</b>
$TD<INPUT TYPE=TEXT NAME=price SIZE=12 VALUE="$Q{price}"> $term[2](
<INPUT TYPE=CHECKBOX NAME=unit>단값지정)
$TR$TD<SPAN>사용법</SPAN>$TD
·상품을 상대에게 보내면, 그 대금을 받을 수가 있습니다.<br>
·택배를 보낸 것을 자동으로 '우편으로 알림' 처리할 수 있습니다.<br>
·대금의 <b>$DTTaxrate%</b>가 세금으로 붙습니다.
$TBE
<br><INPUT TYPE=HIDDEN NAME=form VALUE="check">
<INPUT TYPE=SUBMIT VALUE="전송 확인">
</FORM>
HTML
}

sub LFormCheck
{
my $to=$Q{to};
my $toname;
$preerror="수신처를 지정해 주세요.", return if $to==-1;
OutError("자기 자신에게 택배를 보낼 수 없습니다.") if ($to == $DT->{id});
if ($to==99)
	{
	$preerror="무역이 연결되어 있지 않아 지정할 수 없습니다.", return unless -e "trade.cgi";
	$toname="다른 도시로 수출";
	$Q{notice}=0;
	}
	else
	{
	$preerror="존재하지 않는 점포입니다.", return if !defined($id2idx{$to});
	$toname=$DT[$id2idx{$to}]->{shopname};
	}
$preerror="아이템 지정이 올바르지 않습니다.", return if !$ITEM[$Q{item}]->{name};
$preerror="아이템 지정이 올바르지 않습니다.", return if $ITEM[$Q{item}]->{flag}=~/r/;	# r 의뢰불가

$Q{num}||=$DT->{item}[$Q{item}-1];
$Q{num}=CheckCount($Q{num},0,0,$DT->{item}[$Q{item}-1]);
$preerror="아이템 재고가 없습니다.", return if !$Q{num};
my $price=CheckCount($Q{price},0,0,$MAX_MONEY);
$price=$price * $Q{num} if $Q{unit};
$preerror="대금을 지정해 주세요.", return if !$price;
my $numrate=$ITEM[$Q{item}]->{price} * $Q{num};
$preerror="상품의 가치와 대금이 맞지 않습니다.", return if ($price > $numrate * 2) || ($numrate > $price * 2);
my $pricestring=GetMoneyString($price);

$disp.=<<"HTML";
$TB$TR
$TD$image[0]$TD
<SPAN>상주 드워프</SPAN>: 아래 내용으로 택배를 보내겠습니다.<br>
아래 내용에 문제가 없는지 확인해 주세요.
$TRE$TBE<br>
$TB$TR$TD
<SPAN>수신처</SPAN>:$toname<br>
<SPAN> 상품</SPAN>:$ITEM[$Q{item}]->{name} × $Q{num} $ITEM[$Q{item}]->{scale}<br>
<SPAN>대금</SPAN>:$pricestring
$TRE$TBE
<FORM ACTION="action.cgi" $METHOD>
$MYFORM$USERPASSFORM
<INPUT TYPE=HIDDEN NAME=to VALUE="$to">
<INPUT TYPE=HIDDEN NAME=notice VALUE="$Q{notice}">
<INPUT TYPE=HIDDEN NAME=item VALUE="$Q{item}">
<INPUT TYPE=HIDDEN NAME=num VALUE="$Q{num}">
<INPUT TYPE=HIDDEN NAME=price VALUE="$Q{price}">
<INPUT TYPE=HIDDEN NAME=unit VALUE="$Q{unit}">
<INPUT TYPE=HIDDEN NAME=form VALUE="make">
<INPUT TYPE=SUBMIT NAME=ok VALUE="전송">
<INPUT TYPE=SUBMIT NAME=ng VALUE="재편집">
</FORM>
HTML
}

sub FormSet
{
	my @sort;
	foreach(1..$MAX_ITEM){$sort[$_]=$ITEM[$_]->{sort}};
	my @itemlist=sort { $sort[$a] <=> $sort[$b] } (1..$MAX_ITEM);
	$formitem="";
	foreach my $idx (@itemlist)
	{
		next if !$ITEM[$idx]->{name};
		next if $ITEM[$idx]->{flag}=~/r/;	# r 의뢰불가
		my $cnt=$DT->{item}[$idx-1];
		my $scale=$ITEM[$idx]->{scale};
		my $price=$ITEM[$idx]->{price};
		$formitem.="<OPTION VALUE=\"$idx\"".($Q{item}==$idx ? ' SELECTED' : '').">$ITEM[$idx]->{name}($cnt$scale@".GetMoneyString($price).")" if $cnt;
	}
}


