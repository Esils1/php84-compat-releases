#!/usr/bin/perl
# 에러 분석과 안전한 종료 2005/03/30 유래

my($msg)=@_;
die($msg) if $ERROR_REENTRY;	# 루프 방지
$ERROR_REENTRY=1;

@_=(gmtime(time()+60*60*9))[5,4,3,2,1,0];
$_[0]+=1900; $_[1]++;
my $nowtime=sprintf("%d/%02d/%02d %02d:%02d:%02d",@_);

	open(OUT,">>$DATA_DIR/$ERROR_COUNT_FILE$FILE_EXT");
	print OUT "1";
	close(OUT);
	
my $er_m="분석할 수 없었습니다.";

$msg=~s/&/&amp;/g;
$msg=~s/"/&quot;/g;
$msg=~s/</&lt;/g;
$msg=~s/>/&gt;/g;
$msg=~s/\n/<br>/g;
if ($msg =~ /at\s(\S+)\sline/) {
	$er_s=$1;
	$er_sm="";
	$er_sm="<br>이 파일을 특히 개변하고 있지 않는 경우는 별도인 파일에 에러가 있습니다." if ($msg =~ /func/);
	$er_sm="<br>이것은 「<b>inc-item-data.cgi</b>」를 수정하는 것으로써 해결합니다." if ($msg =~ /data\/item/);
}
if ($msg =~ /line\s(\d+)[,\.]/) {
	$er_l=$1;
}
if ($msg =~ /syntax\serror/ || $msg =~ /Scalar\sfound/ || $msg =~ /Array\sfound/) {
	$er_m="문법 미스입니다.「\"」 「\'」 「\;」 「\}」등의 청구서 잊고인 것이 많습니다.";
}
if ($msg =~ /Unrecognized\scharacter/) {
	$er_m="처리할 수 없는 캐릭터가 포함되어 있습니다.잘못해 전각 캐릭터를 사용해 버렸는지,<br>전각 캐릭터를 「\"」이나 「\'」등으로 묶는 것을 잊고 있는 것이 많습니다.";
}
if ($msg =~ /Illegal\sdivision\sby\szero/) {
	$er_m="제로로 나누는 계산을 시키고 있습니다.<br>어느 변수로 나눌 때는,그 변수가 제로가 되는 경우는 계산을 회피해 주세요.";
}
if ($msg =~ /Can't\sfind\sstring\sterminator/) {
	$er_m="캐릭터 라인이 「\"」이나 「\'」등으로 닫혀지고 있지 않습니다.";
}
if ($msg =~ /Unmatched\sright/) {
	$er_m="문법 미스입니다.「\}」이나 「)」등이 불필요하게 많은 듯 합니다.";
}
if ($msg =~ /Missing\sright/) {
	$er_m="문법 미스입니다.「\}」이나 「)」 등을 붙이고 잊고 있는 것 같습니다.";
}
if ($msg =~ /not\sdefined\sfunction/) {
	$er_m="써브루틴의 명칭에 미스가 있는 것 같습니다.<br>원인으로서는,버전 업의 미스,아이템 데이터의 이벤트 관련의 미스등을 생각됩니다.";
}
if ($msg =~ /Can't\slocate/) {
	$er_m="파일이 존재하지 않습니다.이벤트나 아이템 데이터를 삭제했기 때문에일지도 모릅니다.";
}

PrintErr();

my $error_count=(-s "$DATA_DIR/$ERROR_COUNT_FILE$FILE_EXT");
if ($error_count > 9)
{
	mkdir("$DATA_DIR/lock",$DIR_PERMISSION) unless (-d "$DATA_DIR/lock")
}

UnLock() if $LOCKED;	#락 해제
CoUnLock() if $COLOCKED;
exit(-1);
1;


sub PrintErr
{
print "Cache-Control: no-cache,no-store\n";
print "Pragma: no-cache\n";
print "Content-type: text/html; charset=UTF-8\n\n";
print <<"STR";
<HTML><HEAD>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
<Style Type="text/css">
<!--
A:link   { font-weight: bold; text-decoration:none}
A:visited{ font-weight: bold; text-decoration:none}
A:hover  { font-weight: bold; text-decoration:underline;}
BODY,TR,TD,TH { font-family:"맑은 고딕"; font-size:11pt; }
SPAN { font-family:"Comic Sans MS"; font-size:16pt; color:#664499 ;}
input,input.button{color:#000000;background-color:#FFFFFF;border:1 #5f5f8c solid}
-->
</Style>
<TITLE>$HTML_TITLE:에러</TITLE>
</HEAD>
<BODY BGCOLOR="#FFFFFF" TEXT="#000000" LINK="#6050cc" VLINK="#6050cc" ALINK="#FF0000">
<center><br><SPAN>Sorry,An Error is Detected.</SPAN><br><br>
<TABLE cellspacing="0" cellpadding="0"><TBODY><TR><TD bgcolor="#6B6599">
<TABLE cellspacing="1" cellpadding="0" border="0" width="700"><TBODY><TR><TD bgcolor="#FFFFFF" align="center">
<br>에러가 발견되었기 때문에,실행이 중지되었습니다.<br><br>
플레이중에는 불편을 끼쳐드립니다만,해결까지 잠깐 기다려 주세요.<br>
좀처럼 해결하지 않는 경우는,수고스럽겠지만<a href="mailto:$ADMIN_EMAIL">관리인까지 연락</a>해 주십시오.<br><br>
<A HREF=\"$HOME_PAGE\" TARGET=_top>[홈으로 돌아간다]</A> 
<br><div align="right"><small>
<A HREF="http://akimono.org//">상인 이야기</A> </small></div>
</TD></TR></TBODY></TABLE>
</TD></TR></TBODY></TABLE>
<br><TABLE cellspacing="0" cellpadding="1" border="0">
<TBODY><TR vAlign=center align=middle><TD bgcolor="#6B6599">
<TABLE cellspacing="0" cellpadding="5" width="700" border="0">
<TBODY><TR><TD width="80" bgcolor="#ABA5FF" align="center">
<FONT color="#FFFFFF"><small>for Admin</small></FONT></TD>
<TD align="center" bgcolor="#DBD5FF">이하의 어드바이스에 따라 에러를 해결해 주세요. … 
<A HREF="http://akimono.org/">[에러 상담]</A> 
</TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE>
<br><TABLE cellspacing="0" cellpadding="5" width="700" border="0">
<TR><TD width="80" bgcolor="#ABA5FF" align="center">
<FONT color="#FFFFFF"><small>에러 상황</small></FONT></TD>
<td bgcolor="#DBD5FF">$MYNAME 의 실행에 의해 발생.<small>($nowtime)</small></tr>
<TR><TD width="80" bgcolor="#ABA5FF" align="center">
<FONT color="#FFFFFF"><small>에러 원인</small></FONT></TD>
<td bgcolor="#DBD5FF">「<b>$er_s</b>」의 $er_l행 위법감찰무사근에 원인이 있는 것 같습니다.$er_sm</tr>
<TR><TD width="80" bgcolor="#ABA5FF" align="center">
<FONT color="#FFFFFF"><small>에러 분석</small></FONT></TD>
<td bgcolor="#DBD5FF">$er_m</tr>
<TR><TD width="80" bgcolor="#ABA5FF" align="center">
<FONT color="#FFFFFF"><small>Error Data</small></FONT></TD>
<td bgcolor="#DBD5FF"><small>$msg</small></tr></table>
</CENTER><br><div align="right">
<FORM ACTION="admin.cgi" METHOD="POST"><INPUT TYPE=PASSWORD size=6 NAME=admin>
<INPUT TYPE=SUBMIT VALUE="Admin"></FORM></div>
</body></html>
STR

my $txt= <<"STR";
$MYNAME 의 실행에 의해 발생.($nowtime)
「$er_s」의 $er_l행 위법감찰무사근에 원인이 있는 것 같습니다.$er_sm
$er_m
$msg
STR

	my $ErrFile = $DATA_DIR."/error.log";
	open(OUT,"> $ErrFile");
	print OUT $txt;
	close(OUT);
	chmod (0666,$ErrFile);
}


