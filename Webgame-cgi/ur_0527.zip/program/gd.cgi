#!/usr/bin/perl
# 길드 목록 2005/01/06 유래

DataRead();
CheckUserPass(1);
RequireFile('inc-gd.cgi');

if (!$DT->{guild})
{
$disp.=<<"HTML";
$TB$TR
$TD$image[0]$TD
<SPAN>길드 접수</SPAN>:현재 있는 길드 목록입니다.<br>
클릭하면 자세한 정보를 볼 수 있습니다.
$TRE$TBE
HTML
GuildRanking();
}
elsif ($GUILD{$DT->{guild}}->[$GUILDIDX_name])
{
$disp.=$TB.$TR.$TD.$image[0].$TD."<SPAN>길드 접수</SPAN>:여기는".GetTagImgGuild($DT->{guild});
$disp.="<BIG>".$GUILD{$DT->{guild}}->[$GUILDIDX_name]."</BIG> 본부입니다.<br>";
$disp.="현재 길드 상황을 확인할 수 있습니다.".$TRE.$TBE;
GuildRanking();
RequireFile('inc-guild-cmd.cgi');
}
else
{
$disp.=<<"HTML";
$TB$TR
$TD$image[0]$TD
<SPAN>길드 접수</SPAN>:<b>$DT->{shopname}</b>님의 길드는, 현재 결성 처리 중입니다.<br>
몇 분 뒤에 처리될 수 있으니 잠시 기다려 주세요.
$TRE$TBE
<br>참고:결성 직후에는 기부 등을 해도 바로 효과가 나타나지 않을 수 있으니 주의하세요.
HTML
}

OutSkin();
1;


sub GuildRanking
{
$disp.='<br>[<BIG>길드대항전쟁</BIG>종료까지 남은 '.GetTime2HMS($DTevent{guildbattle}-$DTlasttime).']' if $DTevent{guildbattle};
undef %guildcount;
foreach(@DT)
{
	$guildcount{$_->{guild}}++;
}
@guildlist=sort{$b->{money}<=>$a->{money}}map{$GUILD_DATA{$_}->{guild}=$_;$GUILD_DATA{$_}}keys(%GUILD);
my $Dguild=GetTownData('dominion');

my ($page,$pagestart,$pageend,$pagenext,$pageprev,$pagemax)
	=GetPage($Q{pg},$LIST_PAGE_ROWS,scalar(@guildlist));

my $pagecontrol=GetPageControl($pageprev,$pagenext,"","",$pagemax,$page);
$disp.=$pagecontrol."<BR>";

my $rank=$pagestart+1;
my $writeflag=0;

$disp.=$TB;
foreach my $guild (@guildlist[$pagestart..$pageend])
{
	my $code =$guild->{guild};
	$writeflag=1 , next if !$GUILD_DETAIL{$code};
	my $name =$GUILD{$code}->[$GUILDIDX_name];
	my $dealrate=$GUILD{$code}->[$GUILDIDX_dealrate];
	my $feerate =$GUILD{$code}->[$GUILDIDX_feerate];
	my $comment =$GUILD_DETAIL{$code}->{comment};
	my $member =$GUILD_DETAIL{$code}->{member};

	$disp.=$TR;
	$disp.=$TDB."No.".$rank++."<td align=right>";
	$disp.="<A HREF=\"action.cgi?key=gd-o&$USERPASSURL&g=$code\">".GetTagImgGuild($code).$name."</a>";
	$disp.=qq|<IMG class="i" SRC="$IMAGE_URL/guildprize$IMAGE_EXT">| if ($code eq $Dguild);
	$disp.="<br><SPAN> 자금</SPAN> ".GetMoneyString($guild->{money});
	$disp.= "(적글자)" if $guild->{money}<0;
	$disp.=qq|$TD<IMG class="i" SRC="$IMAGE_URL/guild-a$IMAGE_EXT">|.DefTarent($guild->{atk}+0);
	$disp.=qq|<br><IMG class="i" SRC="$IMAGE_URL/guild-b$IMAGE_EXT">|.DefTarent($guild->{def}+0);
	$disp.=$TD."<SPAN>수입</SPAN> ".GetMoneyString($guild->{in});
	$disp.="<br><SPAN>지출</SPAN> ".GetMoneyString($guild->{out});
	$disp.=$TD."<SPAN>할인 증가율</SPAN> ".($dealrate/10)."%";
	$disp.="<br><SPAN>회비율</SPAN> ".($feerate/10)."%".$TD;
	$disp.="<SPAN>".$member."</SPAN> ".($guildcount{$code}+0)."이름";
	if ($GUILD_DETAIL{$code}->{url})
		{$disp.=qq| <a target="_blank" href="action.cgi?key=jump&guild=$code">[HP]</a> |;}
	$disp.="<br>".$comment;
	$disp.=$TRE;
}
$disp.=$TBE;
$disp.=$pagecontrol;

if ($writeflag)
	{
	Lock();
	MakeGuildFile();
	WriteGuildData();
	DataWrite();
	RenewLog();
	DataCommitOrAbort();
	UnLock();
	}
}

sub DefTarent
{
	my($i)=@_;
	my $per=int($i/10);
	$per=100 if $per > 100;

	my $bar="";
	$bar ="<nobr>";
	$bar.=qq|<img src="$IMAGE_URL/b.gif" width="|.( $per).qq|" height="12">| if $per;
	$bar.=qq|<img src="$IMAGE_URL/t.gif" width="|.(100-$per).qq|" height="12">| if $per!=100;
	$bar.="</nobr>";

	return $bar;
}

