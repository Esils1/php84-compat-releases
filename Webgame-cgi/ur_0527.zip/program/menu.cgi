#!/usr/bin/perl
# 휴대용 메뉴 2004/01/20 유래

$NOITEM=1;
DataRead();
CheckUserPass(1);

$disp.=$HTML_TITLE.'<A HREF="index.cgi" TARGET=_top>[탑]</A>  ';
my $now=$DTlasttime+$TZ_JST-$DATE_REVISE_TIME;
my $nextday=$now+$ONE_DAY_TIME-($now % $ONE_DAY_TIME);
$disp.='[다음번 결산 '.GetTime2FormatTime($nextday-$TZ_JST+$DATE_REVISE_TIME).'까지 나머지'.GetTime2HMS(int(($nextday-$now)/60)*60+59).']<br>';

$disp.=GetMenuTag('shop-m',	'[시장]');
$disp.=GetMenuTag('log',		'[신문]');

$disp.='<hr width=500 noshade size=1>';
if($USER && $USER ne 'soldoutadmin')
{
	$disp.=GetMenuTag('main',		'[점장실]');
	$disp.=GetMenuTag('stock',		'[창고]');
	$disp.=GetMenuTag('sc',		'[진열대]');
	$disp.=GetMenuTag('sweep',		'[청소]');
}

OutSkin();
1;

