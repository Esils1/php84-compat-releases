#!/usr/bin/perl
# 점포 정보 2005/01/06 유래

$disp.="<BIG>●점포 정보</BIG><br><br>";

my $tm=$NOW_TIME-$DT->{time};
if($tm<0)
{
	$tm=-$tm;
	$tm='행동 가능까지 나머지 '.GetTime2HMS($tm);
}else{
	if($tm>$MAX_STOCK_TIME){$tm=$MAX_STOCK_TIME;}
	$tm=GetTime2HMS($tm);
}
my $rankmsg=GetRankMessage($DT->{rank});

my $expsum=0;
foreach(values(%{$DT->{exp}})){$expsum+=$_;}
$expsum=int($expsum/10)."%";

my $job="백수";
$job=$JOBTYPE{$DT->{job}} if ($DT->{job});

my $level=DignityDefine($DT->{dignity},2);
$level=$DIGNITY[0] if !$level;

if(!$MOBILE)
{
	my @taxmode=('','(면세)','(중과세)');
	$disp.=$TB;
	$disp.=$TR;
	$disp.="<td width=48 rowspan=2>".GetTagImgKao($DT->{name},$DT->{icon});
	$disp.="<td align=center colspan=4><SPAN>RANK ".($id2idx{$DT->{id}}+1)."</SPAN> ： ".GetTagImgGuild($DT->{guild})."<b>".$DT->{shopname}."</b>";
	$disp.="<td align=center rowspan=2>".GetTagImgJob($DT->{job},$DT->{icon}).$TRE;
	$disp.=$TR."<td width=56 class=b>작위 $TD$level <small>(경험치 ".($DT->{dignity}+0)."pt)";
	$disp.=$TDB.'직업<td width=64>'.$job.$TRE;
	$disp.=$TR."<td colspan=2 class=b>점수".$TD.$DT->{point}.$TDB."자금";
	$disp.=$DT->{money}>=0 ? "<td colspan=2>".GetMoneyString($DT->{money}).$TRE : "<td colspan=2><font color=\"#cc2266\"><b>-".GetMoneyString(-$DT->{money})."</b></font>".$TRE;
	$disp.=$TR."<td colspan=2 class=b>제한시간".$TD.$tm.$TDB."창업<td colspan=2>".GetTime2HMS($NOW_TIME-$DT->{foundation}).$TRE;
	$disp.=$TR."<td colspan=2 class=b>인기".$TD.$rankmsg.$TDB."쓰레기<td colspan=2>".GetCleanMessage($DT->{trush}).$TRE;
	$disp.=$TR."<td colspan=2 class=b>금일 매출".$TD.GetMoneyString($DT->{saletoday}).$TDB."전일 매출<td colspan=2>\\".$DT->{saleyesterday}.$TRE;
	$disp.=$TR."<td colspan=2 class=b>금일 지출".$TD.GetMoneyString($DT->{paytoday}).$TDB."전일 지출<td colspan=2>\\".$DT->{payyesterday}.$TRE;
	$disp.=$TR."<td colspan=2 class=b>금일 유지비<BR><SMALL>(결산시 징수)</SMALL>".$TD.GetMoneyString(int($DT->{costtoday}))."+".GetMoneyString($SHOWCASE_COST[$DT->{showcasecount}-1]);
	$disp.=   $TDB."전일 유지비<td colspan=2>\\".$DT->{costyesterday}.$TRE;
	$disp.=$TR."<td colspan=2 class=b>금일 판매세".$TD.GetMoneyString($DT->{taxtoday}).$TDB."전일 판매세<td colspan=2>\\".($DT->{taxyesterday}+0).$TRE;
	$disp.=$TR."<td colspan=2 class=b>기본 판매 세율".$TD.GetUserTaxRate($DT,$DTTaxrate).'%'.$taxmode[$DT->{taxmode}+0].$TDB."숙련도 합계<td colspan=2>".$expsum.$TRE;
	$disp.=$TR."<td colspan=2 class=b>우승 회수".$TD.($DT->{rankingcount}+0)."회 ".GetTopCountImage($DT->{rankingcount}+0).$TRE;
	$disp.=$GUILD{$DT->{guild}} ? $TDB."길드 회비<br><SMALL>(결산시 징수)</SMALL><td colspan=2>\\".int($DT->{saletoday}*$GUILD{$DT->{guild}}->[$GUILDIDX_feerate]/1000)."<SMALL>/매출의".($GUILD{$DT->{guild}}->[$GUILDIDX_feerate]/10)."%</SMALL>" : $TD."　<td colspan=2>　";
	$disp.=$TRE.$TBE;
}
else
{
	$disp.="이름:".$DT->{name}."<BR>";
	$disp.="점명:".GetTagImgGuild($DT->{guild}).$DT->{shopname}."<BR>";
	$disp.="RANK:".($id2idx{$DT->{id}}+1)."<BR>";
	$disp.="인기:".$rankmsg."<BR>";
	$disp.="쓰레기:".GetCleanMessage($DT->{trush})."<BR>";
	$disp.="자금:".GetMoneyString($DT->{money})."<BR>";
	$disp.="이번 매출:".GetMoneyString($DT->{saletoday})."<BR>";
	$disp.="이번 지불:".GetMoneyString($DT->{paytoday})."<BR>";
	$disp.="소유금:".GetMoneyString(int($DT->{costtoday}))."+".GetMoneyString($SHOWCASE_COST[$DT->{showcasecount}-1])."<BR>";
	$disp.="시간:".$tm."<BR>";
	$disp.="점수:".$DT->{point}."<BR>";
	$disp.="직업:".$job."<BR>";
}
1;

