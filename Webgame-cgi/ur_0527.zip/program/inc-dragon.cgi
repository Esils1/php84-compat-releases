#!/usr/bin/perl
# 드래곤 경주 설정 2005/03/30 유래

# -------- 설정부분 ---------

# 경주 설정
@WEATHER=('맑음','비');
@RACERANK=('G1','G2','G3','OP','100만 이하','미승리');
@FIELDTYPE=('잔디','더트');

@RACETERM=("신입 경주","전문 경주");

@RACE=(
	# 0명칭		1랭크	2핸디캡	3주로	4종반언덕	5거리	6１도착	7２도착	8３도착 9정원
	[
	['새싹컵'	,5	,0	,0	,1	,1600	,50	,30	,20	,10],
	['카사블랑카컵',4	,20	,0	,0	,1600	,100	,50	,30	,10],
	['카사블랑카 더트컵',4,20	,1	,1	,1600	,100	,50	,30	,10],
	['미승리 2600 더트',5	,0	,1	,0	,2600	,50	,30	,20	,10],
	['수국컵',3	,50	,0	,0	,2800	,150	,70	,50	,10],
	['수국 더트컵',3,50	,1	,0	,2800	,150	,70	,50	,10],
	['채화컵'	,5	,0	,0	,0	,2200	,50	,30	,20	,10],
	['단풍컵'	,4	,20	,0	,0	,2000	,100	,50	,30	,10],
	['단풍 더트컵',4	,20	,1	,1	,2000	,100	,50	,30	,10],
	['미승리 1600 더트',5	,0	,1	,1	,1600	,50	,30	,20	,10],
	['창포컵',3	,50	,0	,1	,1400	,150	,70	,50	,10],
	['창포 더트컵',3	,50	,1	,0	,1400	,150	,70	,50	,10],
	],
	[
	['장거리 핸디캡'	,2	,100	,0	,0	,2600	,200	,100	,80	,10],
	['수련상'	,2	,100	,1	,0	,2200	,200	,100	,80	,10],
	['신월컵'	,2	,100	,0	,0	,1600	,200	,100	,80	,10],
	['청천컵'	,2	,100	,0	,0	,2000	,200	,100	,80	,10],
	['영주 챌린지컵',1,200	,0	,1	,2800	,300	,150	,100	,10],
	['복숭아꽃상'	,1	,200	,1	,0	,2200	,300	,150	,100	,10],
	['명월 트라이얼컵',1,200	,0	,0	,1400	,300	,150	,100	,10],
	['청천 트라이얼컵',1,200	,0	,1	,2000	,300	,150	,100	,10],
	['신천년 국왕상'	,0	,0	,0	,0	,3000	,400	,200	,100	,10],
	['봄꽃상'	,0	,0	,1	,1	,2400	,400	,200	,100	,10],
	['가을달상'	,0	,0	,0	,1	,1600	,400	,200	,100	,10],
	['번개상'	,0	,0	,0	,0	,2000	,400	,200	,100	,10],
	],
);

# 목장
$RCest=1000000;

# 경쟁쟁탈드래곤
$MYDRmax=3;
$DRbuy=500000;

# 은퇴
$DRretire=86400 * 10;
$PRentry=300;
$PRcycle=86400 * 3;

# 마구간
$STest=500000;
$STcost=100000;
$STmax=10;
$STtime=86400 * 50;

# 기수
$JKest=500000;
$JKmax=20;
$JKtime=86400 * 50;

# 기수능력
@JKSP=(
	'없음',
	'암컷용의 기승이얻기의',
	'수컷용의 기승이얻기의',
	'잔디 경주에 강함',
	'더트 경주에 강함',
	'대춤대에강이',
	'비 오는 경주에 강함',
	'승리하다와 용의 성장을 촉진스',
);

# 용어의 정의

@STRATE=('도주','선줄','차시','추입','자재');

@EMPHA=('스피드','승부근성','순발력','파워','건강','유연성');

@VALUE=('Ｅ','Ｄ','Ｃ','Ｂ','Ａ','Ｓ','Ｓ');

@EVALUE=('×','△','○','◎','◎');

@FM=('수컷','암컷');

@ONRACE=('대기','<b>제외</b>','<SPAN>등록</SPAN>','<SPAN>출전</SPAN>');

@DRCOLOR=('빨강털','청털','푸름털','갈대털','칠털');

# 갱신시각 (조교 시각, 신입 경주 출전 마감, 전문 경주 출전 마감)

@DRTIMESET=(3,23,22);

# -------- 설정완료 ---------

@DLOG=();

@DRnamelist=qw(
		no birth fm color name town owner stable race apt
		sp spp sr srp ag agp pw pwp hl hlp fl flp
		con wt gr
		prize sdwin g3win g2win g1win
		);

@PRnamelist=qw(
		no birth fm color name town owner apt hr preg
		sp sr ag pw hl fl
		prize sdwin g3win g2win g1win
		);

@RCnamelist=qw(
		no birth name town owner
		prize sdwin g3win g2win g1win
		);

@STnamelist=qw(
		no birth name town owner
		emp tr con wt
		sp sr ag pw hl fl
		sdwin g3win g2win g1win
		);

@JKnamelist=qw(
		no birth name town owner race
		ahead back sp
		sdwin g3win g2win g1win
		);

@RDnamelist=qw(
		no dr birth fm color name ranch rcname stable stname jock jkname prize strate
		sp1 sp2 sp3 sp4
		pop time str lose
		);
1;

sub GetTagImgDra
{
	my($i,$ii,$old)=@_;
	$i++;
	$ii++;
	$i+=2 if $old;
	return qq|<IMG class="i" SRC="$IMAGE_URL/dragon$i$ii$IMAGE_EXT">|;
}

