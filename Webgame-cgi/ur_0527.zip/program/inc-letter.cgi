#!/usr/bin/perl
# 수신 리스트 표시 2004/01/20 유래

if ($Q{old})
{
LetterSending();
}
else
{
LetterReading();
}
1;

sub LetterReading
{
$disp.="<b>[수신상자]</b> "
	.GetMenuTag('letter','[송신상자]','&old=list')
	.GetMenuTag('letter',		'[편지를 쓴다]','&form=make');
$disp.="<hr width=500 noshade size=1>";
my $cnt=scalar(@RECLETTER);
my $boxlimit=GetTime2HMS($BOX_STOCK_TIME);

if (!$cnt)
{
$disp.=<<"HTML";
$TB$TR
$TD$image[0]$TD
<SPAN>도우미</SPAN>:  현재 도착해 있는 편지는 없습니다.<br>
편지는 $boxlimit 지나면 없어지기 때문에 조심해 주세요.
$TRE$TBE
HTML
return;
}

$disp.=<<"HTML";
$TB$TR
$TD$image[0]$TD
<SPAN>도우미</SPAN>:  현재 $cnt통의 편지가 도착해 있으며, 그중 $NeverR통은 읽지 않았습니다.<br>
편지는 $boxlimit을 넘기면 없어지기 때문에 조심해 주세요.
$TRE$TBE<br>
<FORM ACTION="action.cgi" $METHOD>
$MYFORM$USERPASSFORM
<INPUT TYPE=HIDDEN NAME=mode VALUE="delete">
HTML

foreach my $i(@RECLETTER)
	{
	my $sname=SearchLetterName($LETTER[$i]->{fromid},$LETTER[$i]->{fromt});
	$disp.="<input type=checkbox name=\"del_".$LETTER[$i]->{no}."\" value=\"1\">";
	$disp.=($LETTER[$i]->{mode}==1) ? "<SPAN>미독</SPAN>：" : "수신：";
	$disp.=GetTime2FormatTime($LETTER[$i]->{time})." … from：<span>".$sname."</span>";
	$disp.=" <small>(".$Tname{$LETTER[$i]->{fromt}}.")</small> ";
	$disp.="<a href=\"action.cgi?key=letter&$USERPASSURL&form=make&";
	$disp.=$LETTER[$i]->{fromt}."=".$LETTER[$i]->{fromid}."\">[답신]</a> <br>";
	$disp.="<table width=60%><tr><td>";
	$disp.="「".$LETTER[$i]->{title}."」<BR>";
	$disp.=$LETTER[$i]->{msg}."<BR>";
	$disp.="</td></tr></table><hr width=500 noshade size=1>";
	$LETTER[$i]->{mode}=0,$WriteFlag=1 if ($LETTER[$i]->{mode}==1);	#미독을 기독에.
	$LETTER[$i]->{mode}=2 if ($LETTER[$i]->{fromid}==1);			#택배우편 통지는 삭제.
	}
$disp.=<<"HTML";
<INPUT TYPE=SUBMIT VALUE="선택한 편지를 삭제">
</FORM>
HTML
}

sub LetterSending
{
$disp.=GetMenuTag('letter','[수신상자]')
	."<b>[송신상자]</b> "
	.GetMenuTag('letter',		'[편지를 쓴다]','&form=make');
$disp.="<hr width=500 noshade size=1>";
my $cnt=scalar(@SENLETTER);

if (!$cnt)
{
$disp.=<<"HTML";
$TB$TR
$TD$image[0]$TD
<SPAN>도우미</SPAN>:  현재 보낸 편지는 없습니다.<br>
편지는 합계 $MAX_BOX통까지 보낼 수가 있습니다.
$TRE$TBE
HTML
return;
}

$disp.=<<"HTML";
$TB$TR
$TD$image[0]$TD
<SPAN>도우미</SPAN>:  지금까지 보낸 편지는 $cnt통입니다.<br>
이 중 상대가 읽지 않은 편지는 $NeverS통 있습니다.
$TRE$TBE<br>
<FORM ACTION="action.cgi" $METHOD>
$MYFORM$USERPASSFORM
<INPUT TYPE=HIDDEN NAME=mode VALUE="delete">
<INPUT TYPE=HIDDEN NAME=old VALUE="list">
HTML

foreach my $i(@SENLETTER)
	{
	my $sname=SearchLetterName($LETTER[$i]->{toid},$LETTER[$i]->{tot});
	$sname="(불명)" if $sname eq "-1";
	$disp.="<input type=checkbox name=\"del_".$LETTER[$i]->{no}."\" value=\"1\">";
	$disp.=($LETTER[$i]->{mode}==1) ? "<SPAN>미독</SPAN>：" : "송신：";
	$disp.=GetTime2FormatTime($LETTER[$i]->{time})." … to：<span>".$sname."</span>";
	$disp.=" <small>(".$Tname{$LETTER[$i]->{tot}}.")</small><BR>";
	$disp.="<table width=60%><tr><td>";
	$disp.="「".$LETTER[$i]->{title}."」<BR>";
	$disp.=$LETTER[$i]->{msg}."<BR>";
	$disp.="</td></tr></table><hr width=500 noshade size=1>";
	}
$disp.=<<"HTML";
<INPUT TYPE=SUBMIT VALUE="선택한 편지를 삭제">
<br>(상대의 곳으로부터도 삭제됩니다)
</FORM>
HTML
}

