#!/usr/bin/perl
# 진열대 하청 2005/01/06 유래

my $showcasecount=$DT->{showcasecount};

$disp.="<BIG>●진열대：현재$showcasecount개：유지비 ".GetMoneyString($SHOWCASE_COST[$showcasecount-1])."</BIG><br><br>";

my $usertaxrate=GetUserTaxRate($DT,$DTTaxrate);

$disp.=$TB;
if(!$MOBILE)
{
	my @taxmode=('','(면세)','(중과세)');
	$disp.=$TR;
	$disp.=$TDB."진열장";
	$disp.=$TDB."상품명";
	$disp.=$TDB."판매가";
	$disp.=$TDB."표준 가격";
	$disp.=$TDB."판매세".$taxmode[$DT->{taxmode}+0];
	$disp.=$TDB."재고";
	$disp.=$TDB."금일 판매량";
	$disp.=$TDB."전일 판매량";
	$disp.=$TD;
	$disp.=$TRE;
}
else
{
	$tdh_pr{$MOBILE}="판매가:";
	$tdh_sp{$MOBILE}="표준:";
	$tdh_tx{$MOBILE}="매세:";
	$tdh_st{$MOBILE}="재고:";
	$tdh_ts{$MOBILE}="금일:";
	$tdh_ys{$MOBILE}="전일:";
}

for(my $cnt=0; $cnt<$DT->{showcasecount}; $cnt++)
{
	my $itemno=$DT->{showcase}[$cnt];
	my $ITEM=$ITEM[$itemno];
	my $scale=$ITEM->{scale};
	my $stock=$itemno ? $DT->{item}[$itemno-1]:0;

	$disp.=$TR.$TD."<SPAN>진열장 ".($cnt+1)."</SPAN>";
	$disp.=$TD;
	$disp.="<A HREF=\"action.cgi?key=item&$USERPASSURL&no=$itemno&sc=".($cnt+1)."&pr=".$DT->{price}[$cnt]."&bk=$Q{key}\">" if $stock;
	$disp.=GetTagImgItemType($itemno).$ITEM->{name};
	$disp.="</A> " if $stock;
	
	if($itemno)
	{
		my($taxrate,$tax) =GetSaleTax($itemno,1,$DT->{price}[$cnt],$usertaxrate);
		$disp.=$TD.$tdh_pr{$MOBILE}.GetMoneyString($DT->{price}[$cnt]);
		$disp.=$TD.$tdh_sp{$MOBILE}.GetMoneyString($ITEM->{price});
		$disp.=$TD.$tdh_tx{$MOBILE}.GetMoneyString($tax)." (세율".$taxrate."%)";
		$disp.=$TD.$tdh_st{$MOBILE}.$stock.$scale;
		$disp.=$TD.$tdh_ts{$MOBILE}.($DT->{itemtoday}{$itemno}+0).$scale;
		$disp.=$TD.$tdh_ys{$MOBILE}.($DT->{itemyesterday}{$itemno}+0).$scale;
		$disp.=$TD.'<A HREF="action.cgi?key=sc-s&'.$USERPASSURL.'&item=0&no='.$cnt.'&bk=sc">진열 중지</a>';
	}
	else
	{
		$disp.=$TD.$TD.$TD.$TD.$TD.$TD;
	}
	$disp.=$TRE;
}
$disp.=$TBE;
1;

