#!/usr/bin/perl
# 택배 목록 표시 2005/01/06 유래

$disp.="<b>[택배 목록]</b> "
	.GetMenuTag('dwarf',		'[택배 보내기]','&form=make');
$disp.=GetMenuTag('dwarf','[무역품 목록]','&trade=list') if -e "trade.cgi";
$disp.="<hr width=500 noshade size=1>";

if (!$NeverD)
	{
	$disp.=<<"HTML";
$TB$TR
$TD$image[0]$TD
<SPAN>상주 드워프</SPAN>: 드워프 택배는 믿고 맡길 수 있는 조직입니다.<br>
저희에게 맡겨 주시면 언제든 상품을 안전하게 배송해 드립니다.
$TRE$TBE<br>
HTML
	}
	else
	{
	$disp.=<<"HTML";
$TB$TR
$TD$image[0]$TD
<SPAN>상주 드워프</SPAN>:새 택배가 $NeverD건 도착해 있습니다.<br>
받을지 거절할지 선택해 주세요.
$TRE$TBE<br>
<FORM ACTION="action.cgi" $METHOD>
$MYFORM$USERPASSFORM
<INPUT TYPE=HIDDEN NAME=mode VALUE="plus">
HTML
	}
DwarfReading() if scalar(@RECDWF);
DwarfSending() if scalar(@SENDWF);
1;


sub DwarfReading
{
	$disp.=<<"HTML";
<BIG>●도착한 택배</BIG><br><br>
$TB$TR
$TD/
$TDB 물품
$TDB 대금
$TDB 보낸 곳
$TDB 상태
$TDB 기한
$TRE
HTML

my @MODE;
$MODE[0]=qq|<IMG class="i" SRC="$IMAGE_URL/map/dwfsign4.png">수입 예약|;
$MODE[1]=qq|<IMG class="i" SRC="$IMAGE_URL/map/dwfsign1.png">새 도착|;
$MODE[2]=qq|<IMG class="i" SRC="$IMAGE_URL/map/dwfsign2.png">수취 완료|;
$MODE[3]=qq|<IMG class="i" SRC="$IMAGE_URL/map/dwfsign3.png">수취 거부|;
$MODE[4]=qq|<IMG class="i" SRC="$IMAGE_URL/map/dwfsign2.png">수입 완료|;
$MODE[5]=qq|<IMG class="i" SRC="$IMAGE_URL/map/dwfsign3.png">수입 실패|;

foreach my $i(@RECDWF)
	{
	my($no,$from,$item,$num,$price,$mode)=($DWF[$i]->{no},$DWF[$i]->{from},$DWF[$i]->{item},$DWF[$i]->{num},$DWF[$i]->{price},$DWF[$i]->{mode});
	$disp.=$TR.$TD;
	$disp.=($mode==1) ? "<input type=checkbox name=\"act_".$DWF[$i]->{no}."\" value=\"1\">" : " ";
	$disp.=$TD.GetTagImgItemType($item).$ITEM[$item]->{name}.' '.$num.$ITEM[$item]->{scale};
	$disp.='<br><small>(정가 '.GetMoneyString($ITEM[$item]->{price} * $num).')</small>';
	$disp.=$TD.GetMoneyString($price).$TD;
	if ($from==99)
		{
		$disp.='다른 도시';
		$mode+=2 if $mode>1;
		}
		else
		{
		$disp.=defined($id2idx{$from}) ? ($DT[$id2idx{$from}]->{shopname}) : '없음';
		}
	$disp.=$TD.$MODE[$mode].$TD;
	$disp.=($DWF[$i]->{trade} eq "") ? "남은 ".GetTime2HMS($DWF[$i]->{tm}-$NOW_TIME+$BOX_STOCK_TIME) : "------";
	$disp.=$TRE;


	}
$disp.=$TBE."<br>";
$disp.=<<"HTML" if ($NeverD);
선택한 택배에 대해 <INPUT TYPE=SUBMIT NAME=ok VALUE="대금을 지불하고 받기">
<INPUT TYPE=SUBMIT NAME=ng VALUE="수취 거절">
</FORM><br>
HTML
}

sub DwarfSending
{
	$disp.=<<"HTML";
<FORM ACTION="action.cgi" $METHOD>
$MYFORM$USERPASSFORM
<INPUT TYPE=HIDDEN NAME=mode VALUE="delete">
<BIG>●보낸 택배</BIG><br><br>
$TB$TR
$TD/
$TDB 물품
$TDB 대금
$TDB 받는 곳
$TDB 상태
$TDB 기한
$TRE
HTML

my @MODE;
$MODE[0]=qq|<IMG class="i" SRC="$IMAGE_URL/map/dwfsign4.png">수출 대기|;
$MODE[1]=qq|<IMG class="i" SRC="$IMAGE_URL/map/dwfsign4.png">수취 대기|;
$MODE[2]=qq|<IMG class="i" SRC="$IMAGE_URL/map/dwfsign2.png">수취 완료|;
$MODE[3]=qq|<IMG class="i" SRC="$IMAGE_URL/map/dwfsign3.png">수취 거부|;
$MODE[4]=qq|<IMG class="i" SRC="$IMAGE_URL/map/dwfsign2.png">수출 완료|;
$MODE[5]=qq|<IMG class="i" SRC="$IMAGE_URL/map/dwfsign3.png">수출 실패|;

my $tradeonly=1;
foreach my $i(@SENDWF)
	{
	my($no,$to,$item,$num,$price,$mode)=($DWF[$i]->{no},$DWF[$i]->{to},$DWF[$i]->{item},$DWF[$i]->{num},$DWF[$i]->{price},$DWF[$i]->{mode});
	$disp.=$TR.$TD;
	$disp.="<input type=checkbox name=\"del_".$DWF[$i]->{no}."\" value=\"1\">" if ($to!=99);
	$disp.=$TD.GetTagImgItemType($item).$ITEM[$item]->{name}.' '.$num.$ITEM[$item]->{scale};
	$disp.='<br><small>(정가 '.GetMoneyString($ITEM[$item]->{price} * $num).')</small>';
	$disp.=$TD.GetMoneyString($price).$TD;
	if ($to==99)
		{
		$disp.='다른 도시';
		$mode=0 if $mode==1;
		$mode+=2 if $mode>1;
		}
		else
		{
		$tradeonly=0;
		$disp.=defined($id2idx{$to}) ? ($DT[$id2idx{$to}]->{shopname}) : '없음';
		}
	$disp.=$TD.$MODE[$mode].$TD;
	$disp.=($DWF[$i]->{trade} eq "") ? "남은 ".GetTime2HMS($DWF[$i]->{tm}-$NOW_TIME+$BOX_STOCK_TIME) : "------";
	$disp.=$TRE;
	}
$disp.=$TBE."<br>";
$disp.=<<"HTML" if !$tradeonly;
선택한 택배를 <INPUT TYPE=SUBMIT VALUE="삭제하기">
</FORM>
HTML
}

