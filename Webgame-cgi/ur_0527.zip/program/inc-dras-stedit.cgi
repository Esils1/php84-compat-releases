#!/usr/bin/perl
BEGIN {
	*Utf8Text = sub {
		my($s)=@_;
		return '' unless defined $s;
		utf8::decode($s) unless utf8::is_utf8($s);
		return $s;
	} unless defined &Utf8Text;

	*Utf8InPlace = sub {
		utf8::decode($_[0]) if defined $_[0] && !utf8::is_utf8($_[0]);
	} unless defined &Utf8InPlace;
}
# 드래곤 경주 마구간 편집 2005/03/30 유래

ReadStable();
$disp.="<BIG>●드래곤 경주:마구간</BIG><br><br>";

my $functionname=$Q{code};
OutError("bad request") if !defined(&$functionname);
&$functionname;

WriteStable();
RenewDraLog();
CoDataCA();
1;


sub new
{
OutError("bad request") if ($MYST!=-1);
OutError("bad request") if (scalar @ST >= $STmax);
OutError('자금이 부족합니다.') if ($DT->{money} < $STest);

	# 이름의 유효성을 확인

	$Q{name}=Utf8Text($Q{name});

	if(!$Q{name})
	{
		OutError('이름을 입력해 주세요.');
	}
	if($Q{name} =~ /([,:;\t\r\n<>&])/ || CheckNGName($Q{name}) )
	{
		OutError('이름에 사용할 수 없는 문자가 포함되어 있습니다.');
	}
	OutError('이름이 너무 깁니다.') if length($Q{name})>20;
	OutError('이름이 너무 짧습니다.') if length($Q{name})<6;

	@ST=reverse(@ST);
	$STcount++;
	my $i=$STcount;
	$ST[$i]->{no}=($i > 0) ? ($ST[$i-1]->{no} + 1) : 1 ;
	$ST[$i]->{birth}=$NOW_TIME;
	$ST[$i]->{name}=$Q{name};
	$ST[$i]->{town}=$MYDIR;
	$ST[$i]->{owner}=$DT->{id};
	$ST[$i]->{emp}=$Q{emp};
	$ST[$i]->{sp}=1;
	$ST[$i]->{tr}=int(rand(15));
	$ST[$i]->{con}=int(rand(15));
	$ST[$i]->{wt}=int(rand(15));
	@ST=reverse(@ST);

WritePayLog($MYDIR,$DT->{id},-$STest);
PushDraLog(0,"새 마구간 '".$Q{name}."'이 설립되었습니다.");
$disp.="새 마구간 '<b>".$Q{name}."</b>'을 설립했습니다.";
}

sub large
{
OutError("bad request") if ($MYST==-1);
OutError('자금이 부족합니다.') if ($DT->{money} < $STest);
my $n=int(($NOW_TIME - $ST[$MYST]->{birth})/86400/2) + 1;
my $cost=($ST[$MYST]->{sp} + $ST[$MYST]->{sr} + $ST[$MYST]->{ag} + $ST[$MYST]->{pw} + $ST[$MYST]->{hl} + $ST[$MYST]->{fl});
OutError("bad request") if ($n < $cost);

	my @large=qw(
		sp sr ag pw hl fl
		);

	my $lar=$large[$Q{lar}];

	$ST[$MYST]->{$lar}++;
	OutError('더 이상 이 시설은 확장할 수 없습니다.') if ($ST[$MYST]->{$lar} > 3);

WritePayLog($MYDIR,$DT->{id},-$STest);
$disp.="마구간을 확장했습니다.";
}

