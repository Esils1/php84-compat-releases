#!/usr/bin/perl
# 점정보표시 2005/01/06 유래

if(!$GUEST_USER && !$MOBILE)
{
	my $tm=$NOW_TIME-$DT->{time};
	if($tm<0)
	{
		$tm=-$tm;
		$tm='행동 가능까지 남은 '.GetTime2HMS($tm);
	}
	else
	{
		$tm=$MAX_STOCK_TIME if $tm>$MAX_STOCK_TIME;
		$tm=GetTime2HMS($tm);
	}
	my $rankmsg=GetRankMessage($DT->{rank});
	my $moneymsg=GetMoneyString($DT->{money});
	$disp.=<<STR;
	$TB$TR
	$TD
	<SPAN>RANK</SPAN> ${\($id2idx{$DT->{id}}+1)}$TDE
	$TD<SPAN>상점명:</SPAN>$DT->{shopname}$TDE
	$TD<SPAN>점수:</SPAN>$DT->{point}$TDE
	$TD<SPAN> 자금:</SPAN>$moneymsg$TDE
	$TD<SPAN> 시간:</SPAN>$tm$TDE
	$TRE$TBE
<hr width=500 noshade size=1>
STR
}
1;
