#!/usr/bin/perl
# 듖뿚렭됪뽋돷맾궚 2003/09/25 뾕샮

if(-e "$DATA_DIR/$LASTTIME_FILE$FILE_EXT")
	{
		push(@log,'현재 멘테모드라서, 게임의 진행이 멈추어 있습니다.') if -e "./lock" or -e "$DATA_DIR/lock";
		push(@log,'게임 데이터가 없어져 있습니다.'," 백업을 복원하거나 초기화가 필요합니다.") if !-e "$DATA_DIR/$DATA_FILE$FILE_EXT";
		my $init=' 초기화 버튼(메뉴 하부)을 눌러 수복해 주세요.';
		push(@log,'길드 정의 파일이 없어져 있습니다.',$init) if !-e "$DATA_DIR/$GUILD_FILE$FILE_EXT";
		push(@log,'락 파일이 없어져 있습니다.',$init) if !GetFileList($DATA_DIR,"^$LOCK_FILE");
		push(@log,'공유 락 파일이 없어져 있습니다.',$init) if !GetFileList($COMMON_DIR,"^$LOCK_FILE");
		foreach my $dir ($SESSION_DIR,$TEMP_DIR,$COTEMP_DIR,$LOG_DIR,$SUBDATA_DIR,$BACKUP_DIR)
		{
			push(@log,$dir.' 이(가) 없어져 있습니다.',$init) if !-e $dir;
		}
		push(@log,' 상품 데이터를 작성해 주세요.') if !-e $ITEM_DIR;
	}
	else
	{
		push(@log,' 초기화를 실시해 주세요(메뉴 하부)');
	}
	
if(-e "$DATA_DIR/$ERROR_COUNT_FILE$FILE_EXT")
	{
	my $errorcount=(-s "$DATA_DIR/$ERROR_COUNT_FILE$FILE_EXT")+0;
	unlink("$DATA_DIR/$ERROR_COUNT_FILE$FILE_EXT");
	push(@log,'전회의 관리로부터 현재까지 '.$errorcount.'회의 에러를 검지했습니다.');
	}
	push(@log,"<A HREF=\"$DATA_DIR/error.log\">[에러 정보]</A> 가 보고되고 있습니다.") if(-e "$DATA_DIR/error.log");
	
	my $backupselect=qq|<option value="" selected>백업을 선택|;
	my $backupbasedir=$BACKUP_DIR;
	$backupbasedir=~s/\/([^\/]*)$//;
	foreach(GetFileList($backupbasedir,"^$1"))
	{
		my $file=$_;
		my $time=(stat("$file/$DATA_FILE$FILE_EXT"))[9];
		next if !$time;
		my($s,$min,$h,$d,$m,$y)=gmtime($time+$TZ_JST);
		my $timestr=sprintf("%04d-%02d-%02d %02d:%02d",$y+1900,$m+1,$d,$h,$min);
		$backupselect.=qq|<option value="$_">$timestr|;
	}
	
	my $userselect=qq|<option value= "" selected>유저를 선택|;
if(open(IN,"$DATA_DIR/$DATA_FILE$FILE_EXT"))
	{
		while(<IN>){s/[\r\n]//g; last if $_ eq '//';}
		my @data=<IN>;
		close(IN);
		if(scalar(@data))
		{
			for(my $idx=0; $idx<$#data; $idx+=2)
			{
				@_=split(/,/,$data[$idx],5);
				
				$userselect.=qq|<option value="$_[2]">$_[2] : $_[3]|;
			}
		}
	}
	eval {
	require "$ITEM_DIR/item.cgi" if -e "$ITEM_DIR/item.cgi";
	};
	if ($@)
	{
	push(@log,' inc-item-data.cgi에 에러가 있어, 데이터를 취득할 수 없습니다.');
	push(@log,'일부의 관리 기능이 정상적으로 동작하지 않을 가능성이 있습니다.');
	}
	else
	{
	foreach(1..$MAX_ITEM){$sort[$_]=$ITEM[$_]->{sort}};
	my @itemlist=sort { $sort[$a] <=> $sort[$b] } (1..$MAX_ITEM);
	$formitem="<OPTION VALUE=\"\">아이템을 선택";
	foreach my $idx (@itemlist)
		{
		$formitem.="<OPTION VALUE=\"$idx\">$ITEM[$idx]->{name}";
		}
	}
	eval {
	require "$INCLUDE_DIR/inc-version.cgi";
	};

	my($s,$min,$h,$d,$m,$y)=gmtime(time()+$TZ_JST);
	$y+=1900;$m++;

	$disp.="<hr width=700 noshade size=1><SPAN>기본관리기능\</SPAN>";
	$disp.="<table><tr><td bgcolor=\"#CBC5FF\"><table width=200>";
	$disp.="<tr><td>perl version</td><td>$]</td></tr>";
	foreach('.',$DATA_DIR,$INCLUDE_DIR,$AUTOLOAD_DIR,$TOWN_DIR,$COMMON_DIR,"_config.cgi","action.cgi",$MYNAME)
	{
		$disp.="<tr><td>".$_."<td>".substr(sprintf("%o",(stat($_))[2]),-3,3)."</tr>";
	}
	$disp.="</table><td bgcolor=\"#DBD5FF\">";
	
	$disp.=<<"HTML";
	<table width=500><tr><td colspan=2>
	<FORM ACTION="$MYNAME" METHOD="POST">
	<INPUT TYPE="HIDDEN" NAME=admin VALUE="$Q{admin}">
	<INPUT TYPE="HIDDEN" NAME=mode VALUE="menteon">
	<INPUT TYPE="SUBMIT" VALUE="◆ 멘테모드에 이행 ◆"></FORM>
	<td colspan=2><FORM ACTION="$MYNAME" METHOD="POST">
	<INPUT TYPE="HIDDEN" NAME=admin VALUE="$Q{admin}">
	<INPUT TYPE="HIDDEN" NAME=mode VALUE="menteoff">
	<INPUT TYPE="SUBMIT" VALUE="◆ 멘테모드를 해제 ◆">
	</FORM></tr><tr><td colspan=2>
	<FORM ACTION="admin.cgi" METHOD="POST">
	<INPUT TYPE="HIDDEN" NAME=key VALUE="makeitem">
	<INPUT TYPE="HIDDEN" NAME=admin VALUE="$Q{admin}">
	<INPUT TYPE="SUBMIT" VALUE="■ 상품 데이터를 작성 ■">
	</FORM>
	<td colspan=2><FORM TARGET="_blank" ACTION="action.cgi" METHOD="POST">
	<INPUT TYPE="HIDDEN" NAME=key VALUE="item-list">
	<INPUT TYPE="HIDDEN" NAME=u VALUE="soldoutadmin!$Q{admin}">
	<INPUT TYPE="SUBMIT" VALUE="□ 상품 데이터를 확인 □">
	</FORM></tr><tr><td>
	<FORM TARGET="_blank" ACTION="http://www.geocities.co.jp/Playtown-Bingo/8587/diff/$BASE_VERSION.htm" METHOD="GET">
	<INPUT TYPE="SUBMIT" VALUE="■ 갱신을 확인 ■">
	</FORM>
	<td>
	<FORM TARGET="_blank" ACTION="action.cgi" METHOD="POST">
	<INPUT TYPE="HIDDEN" NAME=key VALUE="treebbs">
	<INPUT TYPE="HIDDEN" NAME=nm VALUE="soldoutadmin">
	<INPUT TYPE="HIDDEN" NAME=pw VALUE="$Q{admin}">
	<INPUT TYPE="SUBMIT" VALUE="게시판">
	</FORM>
	<td>
	<FORM ACTION="$MYNAME" METHOD="POST">
	<INPUT TYPE="HIDDEN" NAME=admin VALUE="$Q{admin}">
	<INPUT TYPE="HIDDEN" NAME=mode VALUE="errdel">
	<INPUT TYPE="SUBMIT" VALUE="에러 정보삭제">
	</FORM>
	<td>
	<FORM TARGET="_blank" ACTION="action.cgi" METHOD="POST">
	<INPUT TYPE="HIDDEN" NAME=key VALUE="admin-sub2">
	<INPUT TYPE="HIDDEN" NAME=log VALUE=".">
	<INPUT TYPE="HIDDEN" NAME=nm VALUE="soldoutadmin">
	<INPUT TYPE="HIDDEN" NAME=pw VALUE="$Q{admin}">
	<INPUT TYPE="SUBMIT" VALUE="각종 로그 열람">
	</FORM></tr><tr><td colspan=3>
	<FORM TARGET="_blank" ACTION="action.cgi" METHOD="POST">
	<INPUT TYPE="HIDDEN" NAME=key VALUE="admin-sub2">
	<INPUT TYPE="HIDDEN" NAME=nm VALUE="soldoutadmin">
	<INPUT TYPE="HIDDEN" NAME=pw VALUE="$Q{admin}">
	<INPUT TYPE="SUBMIT" VALUE="멤버 리스트">
	<INPUT TYPE="CHECKBOX" NAME=host>주인 표\시
	<INPUT TYPE="CHECKBOX" NAME=only>일람만
	</FORM>
	<td>
	<FORM TARGET="_blank" ACTION="index.cgi" METHOD="POST">
	<INPUT TYPE="SUBMIT" VALUE="톱 화면에">
	</FORM></tr><tr><td colspan=4>
	<FORM TARGET="_blank" ACTION="action.cgi" METHOD="POST">
	<INPUT TYPE="HIDDEN" NAME=key VALUE="admin-sub2">
	<INPUT TYPE="HIDDEN" NAME=mode VALUE="delitem">
	<INPUT TYPE="HIDDEN" NAME=u VALUE="soldoutadmin!$Q{admin}">
	·플레이 데이터로부터 <SELECT NAME=num1>$formitem</SELECT> 또는 No.<INPUT TYPE=TEXT NAME=num2 SIZE=5> 을
	<INPUT TYPE="SUBMIT" VALUE="소거하기">
	</FORM></tr><tr><td colspan=4>
	<FORM TARGET="_blank" ACTION="action.cgi" METHOD="POST">
	<INPUT TYPE="HIDDEN" NAME=key VALUE="admin-sub2">
	<INPUT TYPE="HIDDEN" NAME=u VALUE="soldoutadmin!$Q{admin}">
	·이벤트 코드 <INPUT TYPE="TEXT" size=12 NAME=ecode> 를<br>
	종료시각 <INPUT TYPE="TEXT" NAME=tlyear SIZE=5 VALUE="$y">년<INPUT TYPE="TEXT" NAME=tlmon SIZE=3 VALUE="$m">월
	<INPUT TYPE="TEXT" NAME=tlday SIZE=3 VALUE="$d">일 <INPUT TYPE="TEXT" NAME=tlhour SIZE=3 VALUE="$h">시
	<INPUT TYPE="TEXT" NAME=tlmin SIZE=3 VALUE="$min">분<INPUT TYPE="TEXT" NAME=tlsec SIZE=3 VALUE="$s">초
	까지 <INPUT TYPE="SUBMIT" VALUE="발생시킨다">
	</FORM></tr></table>
	</tr></table><hr width=700 noshade size=1>
	<SPAN>멤버 상품 수여 기능\</SPAN>
	<table width=700 bgcolor="#DBD5FF"><tr><td>
	<FORM TARGET="_blank" ACTION="action.cgi" METHOD="POST">
	<INPUT TYPE="HIDDEN" NAME=key VALUE="admin-sub">
	<INPUT TYPE="HIDDEN" NAME=u VALUE="soldoutadmin!$Q{admin}">
	<INPUT TYPE="SUBMIT" VALUE="상품수여"> <SELECT NAME=user>$userselect</SELECT> 
	<INPUT TYPE="TEXT" size=46 NAME=comment VALUE="">←댓글(임의)<br>
	아이템 <SELECT NAME=senditem>$formitem</SELECT>:<INPUT TYPE="TEXT" size=3 NAME=count VALUE="1">개
	/·자금：<INPUT TYPE="TEXT" size=5 NAME=sendmoney VALUE="0">엔
	/·시간：<INPUT TYPE="TEXT" size=3 NAME=sendtime VALUE="0">시간
	/·작위：<INPUT TYPE="TEXT" size=3 NAME=senddig VALUE="0">포인트<br>
	※각각을 한 번으로 지정할 수도 있습니다.댓글를 공난으로 한다면 공표하지 않습니다.
	</FORM></tr></table><hr width=700 noshade size=1>
	<SPAN>멤버 관리기능\</SPAN>
	<table width=700 bgcolor="#DBD5FF"><tr><td width=280>
	<FORM TARGET="_blank" ACTION="action.cgi" METHOD="POST">
	<INPUT TYPE="HIDDEN" NAME=key VALUE="new">
	<INPUT TYPE="HIDDEN" NAME=admin VALUE="$Q{admin}">
	<INPUT TYPE="SUBMIT" VALUE="신규점포 오픈"><br>
	※정원에 관계없이 오픈 가능\.</FORM>
	<td><FORM TARGET="_blank" ACTION="action.cgi" METHOD="POST">
	<INPUT TYPE="HIDDEN" NAME=pw VALUE="$Q{admin}">
	<INPUT TYPE="SUBMIT" VALUE="유저 점포입점"> <SELECT NAME=nm>$userselect</SELECT><br>
	※본인이 입점하고 있어도 동시에 조작할 수 있습니다.
	</FORM></tr>
	<tr><td colspan=2>
	<FORM TARGET="_blank" ACTION="action.cgi" METHOD="POST">
	<INPUT TYPE="HIDDEN" NAME=key VALUE="user">
	<INPUT TYPE="HIDDEN" NAME=pw VALUE="$Q{admin}">
	<INPUT TYPE=HIDDEN NAME=mode VALUE=repass>
	<INPUT TYPE="SUBMIT" VALUE="패스워드 변경"> <SELECT NAME=nm>$userselect</SELECT>
	<INPUT TYPE="TEXT" size=5 NAME=pw1 VALUE=""><=새로운 패스워드
	<INPUT TYPE="TEXT" size=5 NAME=pw2 VALUE=""><=새로운 패스워드 한번 더
	</FORM></tr>
	<tr><td colspan=2>
	<FORM TARGET="_blank" ACTION="action.cgi" METHOD="POST">
	<INPUT TYPE="HIDDEN" NAME=key VALUE="admin-sub">
	<INPUT TYPE="HIDDEN" NAME=u VALUE="soldoutadmin!$Q{admin}">
	<INPUT TYPE="SUBMIT" VALUE="유저 점포동결"> <SELECT NAME=user>$userselect</SELECT>
	<INPUT TYPE="TEXT"   NAME=blocklogin VALUE=""><=동결이유<br>
	※「off」라고 입력으로 동결 해제：「mark」라고 입력으로 로그인 이력 로그：「stop」라고 입력으로 휴지 취급
	</FORM></tr>
	<tr><td colspan=2>
	<FORM TARGET="_blank" ACTION="action.cgi" METHOD="POST">
	<INPUT TYPE="HIDDEN" NAME=key VALUE="admin-sub">
	<INPUT TYPE="HIDDEN" NAME=u VALUE="soldoutadmin!$Q{admin}">
	<INPUT TYPE="SUBMIT" VALUE="중복 등록 허가/금지"> <SELECT NAME=user>$userselect</SELECT>
	<SELECT NAME=nocheckip><option value="nocheck">중복허가<option value="check">중복금지</SELECT>
	</FORM></tr>
	<tr><td colspan=2>
	<FORM TARGET="_blank" ACTION="action.cgi" METHOD="POST">
	<INPUT TYPE="HIDDEN" NAME=key VALUE="admin-sub">
	<INPUT TYPE="HIDDEN" NAME=u VALUE="soldoutadmin!$Q{admin}">
	<INPUT TYPE="SUBMIT" VALUE="유저 점포 추방"> <SELECT NAME=user>$userselect</SELECT> 
	<INPUT TYPE="TEXT" NAME=comment VALUE="">←댓글(임의)<br>
	<INPUT TYPE="CHECKBOX" NAME=log>←통지하지 않는다 
	<INPUT TYPE="TEXT" NAME=closeshop VALUE="">← 확인을 위해 closeshop 라고 입력
	</FORM></tr></table><hr width=700 noshade size=1>
	<SPAN>데이터 초기화·삭제 기능\</SPAN>
	<table width=700 bgcolor="#DBD5FF"><tr><td>
	<FORM ACTION="$MYNAME" METHOD="POST">
	<INPUT TYPE="HIDDEN" NAME=admin VALUE="$Q{admin}">
	<INPUT TYPE="HIDDEN" NAME=mode VALUE="init">
	<INPUT TYPE="SUBMIT" VALUE="초기화/파손 수복">복구 기능입니다.벌써 있는 데이터는 삭제되지 않습니다
	</FORM></tr><tr><td>
	<FORM ACTION="$MYNAME" METHOD="POST">
	게임 데이터 가운데, 상품 데이터·관련 디렉토리만을<INPUT TYPE="HIDDEN" NAME=mode VALUE="mini">
	<INPUT TYPE="SUBMIT" VALUE="최소 언인스톨한다"> <INPUT TYPE="PASSWORD" size=5 NAME=admin VALUE="">관리패스
	</FORM></tr>
	<tr><td>
	<FORM ACTION="$MYNAME" METHOD="POST">
	유저 데이터를 남기면서, 게임 데이터·관련 디렉토리를<INPUT TYPE="HIDDEN" NAME=mode VALUE="piece">
	<INPUT TYPE="SUBMIT" VALUE="부분 언인스톨한다."> <INPUT TYPE="PASSWORD" size=5 NAME=admin VALUE="">관리패스
	</FORM></tr>
	<tr><td>
	<FORM ACTION="$MYNAME" METHOD="POST">
	유저 데이터를 포함하고, 전게임 데이터·관련 디렉토리를<INPUT TYPE="HIDDEN" NAME=mode VALUE="delunit">
	<INPUT TYPE="SUBMIT" VALUE="완전 언인스톨한다"> <INPUT TYPE="PASSWORD" size=5 NAME=admin VALUE="">관리패스
	</FORM></tr>
	<tr><td>
	<FORM ACTION="$MYNAME" METHOD="POST">
	<INPUT TYPE="HIDDEN" NAME=mode VALUE="timeedit">
	최종 갱신 시각을<INPUT TYPE="TEXT" NAME=tlyear SIZE=5 VALUE="$y">년<INPUT TYPE="TEXT" NAME=tlmon SIZE=3 VALUE="$m">월
	<INPUT TYPE="TEXT" NAME=tlday SIZE=3 VALUE="$d">일 <INPUT TYPE="TEXT" NAME=tlhour SIZE=3 VALUE="$h">시
	<INPUT TYPE="TEXT" NAME=tlmin SIZE=3 VALUE="$min">분<INPUT TYPE="TEXT" NAME=tlsec SIZE=3 VALUE="$s">초
	에<INPUT TYPE="SUBMIT" VALUE="변경한다.">
	<INPUT TYPE="PASSWORD" size=5 NAME=admin VALUE="">관리패스
	</FORM></tr>
	<tr><td>
	<FORM ACTION="$MYNAME" METHOD="POST">
	<INPUT TYPE="HIDDEN" NAME=mode VALUE="backup">
	게임 데이터를<SELECT NAME=backup>$backupselect</SELECT>
	의 시점에<INPUT TYPE="SUBMIT" VALUE="복원한다">
	<INPUT TYPE="PASSWORD" size=5 NAME=admin VALUE="">관리 패스
	</FORM></tr></table><br><br>
HTML
1;
