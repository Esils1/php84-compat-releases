#!/usr/bin/perl
BEGIN {
	*Utf8Text = sub {
		my($s)=@_;
		return '' unless defined $s;
		utf8::decode($s) unless utf8::is_utf8($s);
		return $s;
	} unless defined &Utf8Text;

	*Utf8InPlace = sub {
		utf8::decode($_[0]) if defined $_[0] && !utf8::is_utf8($_[0]);
	} unless defined &Utf8InPlace;
}
# 길드설립처리 2004/01/20 유래

CoLock();
DataRead();
CheckUserPass();
ReadGuild();
ReadGuildData();
$image[0]=GetTagImgKao("길드 접수","guild");
$Q{er}='gd-f';

$disp.="<BIG>●길드공관</BIG><br><br>";

$Q{url}="http://" if $Q{url} eq "";
$Q{leadt}=$MYDIR;
$Q{leader}=$DT->{id};
@GLIST=(name,shortname,dealrate,feerate,member,comment,appeal,needed,leadt,leader,url);
@MAX=(30,12,4,4,6,30,120,120,10,10,60);
foreach my $i(0..$#GLIST)
	{
	OutError('입력되지 않은 항목이 있습니다 - '.$GLIST[$i]) if (!$Q{$GLIST[$i]});
	$Q{$GLIST[$i]}=CutStr(Utf8Text($Q{$GLIST[$i]}),$MAX[$i]);
	$Q{$GLIST[$i]}=~s/&/&amp;/g;
	$Q{$GLIST[$i]}=~s/>/&gt;/g;
	$Q{$GLIST[$i]}=~s/</&lt;/g;
	}
$Q{url}="" if $Q{url} eq "http://";
OutError('수수료율이나 할인율에 사용할 수 없는 문자가 포함되어 있습니다') if ($Q{dealrate} =~ /([^0-9])/)||($Q{feerate} =~ /([^0-9])/);
OutError('할인율은 10~500 사이의 숫자로 지정해 주세요') if ($Q{dealrate} > 500) || ($Q{dealrate} < 10);
OutError('회비율은 10~500 사이의 숫자로 지정해 주세요') if ($Q{feerate} > 500) || ($Q{feerate} < 10);
OutError('길드 코드에 사용할 수 없는 문자가 포함되어 있습니다') if ($Q{code} =~ /([^a-z])/);
OutError('길드 결성에는 이미지 파일이 필요합니다') if (!$Q{upfile})&&($Q{mode} ne "edit");

OutError('같은 길드 코드가 이미 존재합니다') if (-e $COMMON_DIR."/".$Q{code}.".pl")&&($Q{mode} ne "edit");

GuildImgUp() if ($Q{upfile});
BuildGuild();
CoUnLock();

if ($Q{mode} ne "edit")
{
	Lock();
	DataRead();
	CheckUserPass();
	$DT->{guild}=$Q{code};
	DataWrite();
	DataCommitOrAbort();
	UnLock();
}

$disp.=<<"HTML";
$TB$TR
$TD$image[0]$TD
길드 접수: 절차가 완료되었습니다. 잠시 후 반영됩니다.<br>
좋은 길드로 성장할 수 있도록 노력해 주세요.
$TRE$TBE
HTML
OutSkin();
1;


sub GuildImgUp
{
	if ($MIMETYPE{upfile} =~ /gif/i)
	{
	my $ImgFile = $COMMON_DIR."/".$Q{code}.".gif";
	my $upfile=$Q{upfile};
	open(OUT,"> $ImgFile");
	binmode(OUT);
	binmode(STDOUT);
	print OUT $upfile;
	close(OUT);
	chmod (0666,$ImgFile);
	}
	else
	{
	OutError('gif 이미지 파일이 아닌 것 같습니다.'.$MIMETYPE{upfile});
	}
}

sub BuildGuild
{
	my @MESSAGE=();
	push(@GLIST, @OtherDir);
	foreach my $i(0..$#GLIST)
		{
		$MESSAGE[$i]=$GLIST[$i]."=".$Q{$GLIST[$i]}."\n";
		}
	OpenAndCheck($COMMON_DIR."/".$Q{code}.".pl");
	print OUT @MESSAGE;
	close(OUT);
}

