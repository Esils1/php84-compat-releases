@OtherDir=("uron");
$Tname{uron}="략명칭";
