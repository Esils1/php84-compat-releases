#!/usr/bin/perl
# 설정 파일 2005/01/06 유래
# 이 파일의 권한을 설정할 필요는 특별히 없습니다. 설정한다면 644 등으로 충분합니다.

#-----------------------
# 시작 설정
#-----------------------
$MASTER_PASSWORD	='1064';			# 관리 비밀번호
$ADMIN_EMAIL		='loverofwind@naver.com';			# 관리자 메일 주소

$HTML_TITLE	='상인의 거리';		# 화면 제목

$TOWN_TITLE	='약칭';			# 거리의 짧은 이름
						# 나중에 도시 이름을 변경했을 때는, 관리실에서
						# '초기화/파손복구' 버튼을 눌러야 합니다.


#-----------------------
# ◆거리의 설정
#-----------------------
$TOWN_CODE	='uron';			# 거리 코드(식별 기호)
						# 영문 소문자와 숫자 10자 이내로 적절히 설정하세요.
						# 다른 도시와 같은 코드가 되지 않도록 설정하세요.

$TITLE_COMMENT	='';				# 로그인 화면에 표시할 설명입니다. 태그를 사용할 수 있습니다.

$HOME_PAGE	='../index.html';		# '홈' 링크 대상

$MOVETOWN_ENABLE	=0;			# 이전 기능 사용 여부 1:사용 0:사용 안 함
						# 서버가 socket을 지원하지 않으면 이전 기능을 사용할 수 없습니다.


#------------------------
# 기본 게임 설정
#------------------------
$MAX_USER	=50;				# 신규 개점 가능한 최대 수: 특별한 이유가 없으면 크게 늘리지 마세요.
$MAX_MOVE_USER	=55;				# 이전 최대 수(다른 거리에서 이전해 오는 점포의 수용 한도)

$EXPIRE_TIME	=3600*24*7;			# 점포 주인 부재 기한(초)
						# 이 기간 동안 접속이 없으면 데이터가 만료됩니다.

$ONE_DAY_TIME		=3600*36;		# 정산 주기(초)
$DATE_REVISE_TIME	=3600*6;		# 정산 시각 보정값(초). -3600이면 1시간 앞당김

$MAX_STOCK_TIME		=72*60*60;		# 최대 보유 시간(초)

$LIMIT_EXP	=3600;				# 숙련도 합계 제한(10배의 숫자값을 지정)
						# 3600이면 360% 제한입니다. 0이면 제한이 없습니다.

$REQUEST_LIMIT		=48*60*60;		# '의뢰소' 의뢰 유효 시간(초)
$REQUEST_CAPACITY	=1;			# 동시에 의뢰할 수 있는 수

$HouseMax	=5;				# '주택'에 보관할 수 있는 수:
						# 5로 설정하면 각 아이템을 창고 최대 수량의 5배까지 보관할 수 있습니다.

$MAX_BOX	=5;				# 편지 전송 최대 수
$BOX_STOCK_TIME	=48*60*60;			# 편지 유효 시간(초)

@DIGNITY=(					# 작위 이름입니다. 오른쪽으로 갈수록 지위가 낮아집니다.
	"평민","사작위","자작위","백작작위","후작위","공작위","대공"
	);
@DIG_POINT=(					# 필요한 작위 포인트입니다. 위 목록과 순서를 맞춰 주세요.
	0,1,2,4,8,16,32
	);
$DIG_FORGUILD=16;				# 길드 결성에 필요한 작위 포인트

$BAL_NAME	='발바로스';			# 반란 NPC 이름
$BAL_JOB	='산적';			# 반란 NPC의 직업


#-------------------------------
# 용어 설정: 게임 안에 표시되는 용어를 한 번에 변경할 수 있습니다.
#-------------------------------

@term=(
	'',			# 통화 단위 앞에 붙일 문자
	'원',			# 통화 단위 뒤에 붙일 문자
	'원',			# 순위 등에서 사용할 통화 단위
	'빚 있음',		# 자금이 마이너스일 때 표시

);


#-------------------------------
# 접근의 제한에 관한 설정
#-------------------------------
$NEW_SHOP_ADMIN		=0;			# 신규 개설 권한 0: 일반 1: 관리자만
						# 1로 설정하면 관리 화면에서만 점포를 개설할 수 있습니다.

$NEW_SHOP_KEYWORD	='';			# 신규 점포 개설에 필요한 키워드
						# 키워드를 설정하면 해당 단어를 모를 경우 개점할 수 없습니다.

$NEW_SHOP_BLOCKIP	=1;			# 1에서 동일 IP의 연속 등록을 차단합니다(폐점 후 재등록 포함).
$CHECK_IP		=1;			# 동일 IP와 USER_AGENT의 접근을 자동 제한 1:제한하다 0:제한하지 않음
@NG_SHOP_NAME		=qw(관리 지급 11 12 aa http ?);	# 점포 이름으로 사용할 수 없는 문자(공백으로 구분)

$NEW_OTHERTOWN_BLOCK	=0;			# 1 데거리 그룹 전체에서 중복 등록을 검사합니다.
						# 거리 그룹 전체에서 점포를 하나만 보유할 수 있습니다.



#********************** 일반 설정 항목은 여기까지입니다 **********************



#--------------------------------------------------------------------
# 이미지에 관한 설정 : 이미지를 바꿔 넣거나하거나, 특수한 장에 배치할 때.
#--------------------------------------------------------------------
$IMAGE_URL		='./image';		# 이미지 디렉터리 위치(URL)
						# CGI가 별도 서버에 있으면 변경이 필요합니다.
$IMAGE_DIR		='./image';		# 이미지 디렉터리(서버 전체 경로)
						# 특수한 서버 환경에서는 변경이 필요합니다.

$ICON_NUMBER		=25;			# 점장 얼굴 아이콘 수
$ICON_SIZE		='WIDTH=48 HEIGHT=48';	# 얼굴 아이콘 크기

$IMAGE_EXT		='.png';		# 이미지 확장자

$COMMON_URL		='../common';		# 공용 데이터 디렉터리(길드등)
						# CGI가 별도 서버에 있으면 변경이 필요합니다.
$COMMON_DIR		='../common';		# 공용 데이터 디렉터리(서버의 전체경로)
						# 특수한 서버 환경에서는 변경이 필요합니다.

#---------------------------------------------------------
# 고급 게임 밸런스 설정: 시스템을 잘 이해한 경우에만 조정하세요.
#---------------------------------------------------------
$UPDATE_TIME		=60*5;			# 최소 갱신 주기(초)

$PROFIT_DAY_COUNT	=3;			# 점수 계산 때 고려할 최근 순이익 기간
$SALE_SPEED		=12;			# 판매 속도 배율(inc-item-data.cgi 에서의 설정을1로서)
$POP_DOWN_RATE	=5;				# 현재 인기에 따른 변동폭

$EXP_DOWN_POINT		=5;			# 정산 때 감소할 숙련도 포인트(1%==10)
$EXP_DOWN_RATE		=60;			# 정산 때 감소할 숙련도 비율(6%==60)
						# 예:현재 숙련도가 50%인 경우, 고정의0.5%와 50%의6%로 3%, 맞춰3.5%감소


#---------------------------------------------------------
# 표시 건수 설정: 너무 크게 바꾸면 화면이 무거워집니다.
#---------------------------------------------------------
$TOP_RANKING_PAGE_ROWS	=5;			# '상단' 순위 표시 건수
$MAIN_LOG_PAGE_ROWS	=10;			# '점장실' 최근 사건 표시 건수
$SHOP_PAGE_ROWS		=5;			# '다른 점포' 표시 건수
$RANKING_PAGE_ROWS	=10;			# 순위표시건수
$LIST_PAGE_ROWS_PC	=25;			# 각종 목록 표시 건수(일반)
$LIST_PAGE_ROWS_MOBILE	=5;			# 각종 목록 표시 건수(휴대)



#********************** 아래 설정은 필요한 경우에만 변경하세요 **********************

$DATA_DIR		='./data';
$LOG_DIR		=$DATA_DIR.'/log';
$ITEM_DIR		=$DATA_DIR.'/item';
$SESSION_DIR		=$DATA_DIR.'/session';
$BACKUP_DIR		=$DATA_DIR.'/backup';
$TEMP_DIR		=$DATA_DIR.'/temp';
$SUBDATA_DIR		=$DATA_DIR.'/subdata';

$COTEMP_DIR		=$COMMON_DIR.'/temp';

$INCLUDE_DIR		='../program';
$AUTOLOAD_DIR		=$INCLUDE_DIR.'/plug';
$TOWN_DIR		=$INCLUDE_DIR.'/town';
# UTF-8 환경: 문자 변환 라이브러리 경로 설정은 사용하지 않습니다.
# UTF-8 환경: 기존 문자 변환을 네이티브 UTF-8 처리로 대합니다.
sub Utf8Text {
	my($s)=@_;
	return '' unless defined $s;
	utf8::decode($s) unless utf8::is_utf8($s);
	return $s;
}

sub Utf8InPlace {
	utf8::decode($_[0]) if defined $_[0] && !utf8::is_utf8($_[0]);
}$CUSTOM_DIR		='./custom';

$DIR_PERMISSION		=0777;
$TZ_JST			=60*60*9;

$FILE_EXT		='.cgi';

$COMMIT_FILE		='commit';
$LASTTIME_FILE		='lasttime';
$LOCK_FILE		='lockfile';
$DATA_FILE		='play';
$LOG_FILE		='log';
$BBS_FILE		='treelog';
$BOX_FILE		='box';
$GUILDBAL_FILE		='guildbal';
$GUILD_FILE		='guild';
$ERROR_COUNT_FILE	='errorcnt';

$LOG_ERROR_FILE		='error';
$LOG_DELETESHOP_FILE	='delete';
$LOG_MOVESHOP_FILE	='moveshop';
$LOG_LOGIN_FILE		='login';
$LOG_DEBUG_FILE		='debug';
$LOG_MARK_FILE		='mark';
$LOG_SIZE_MAX		=30000;

$PASSWORD_CRYPT	=1;
$AUTO_UNLOCK_TIME		=60;
$SESSION_TIMEOUT_TIME		=3600;
$LOG_EXPIRE_TIME		=3600*36;
$PASSWORD_HASH_EXPIRE_TIME	=60*15;

$BACKUP_TIME		=3600;
$BACKUP		=3;
@BACKUP_FILES		=(
		$LOG_FILE.'0',
		$LOG_FILE.'1',
		$LOG_FILE.'2',
		$GUILDBAL_FILE,
		$DATA_FILE,
			);

# 개발자용 디버그 설정
$DEBUG_MOBILE		=0;			# 1에서 휴대 단말 처리 고정
$DEBUG_LOG_ENABLE	=0;			# 1에서 item::DebugLog()토 event::DebugLog() 사용

# set umask
umask(~$DIR_PERMISSION & 0777);
require './_config-local.cgi' if -e './_config-local.cgi';

sub RequireFile
{
	my $customfile="$CUSTOM_DIR/$_[0]";
	require $customfile,return if -e $customfile;
	my $fname="$INCLUDE_DIR/$_[0]";
	OutError('파일을 찾을 수 없습니다 - '.$fname) unless -e $fname;
	require $fname;
}
1;
