#!/usr/bin/perl
# 처리창구프로그램 2003/11/03 유래

require './_config.cgi';
RequireFile('inc-func.cgi');
GetQuery();
OutError("bad request") if ($Q{key} =~ /inc/ || $Q{key} =~ /[^\w-]/);
$Q{key}||='main';
RequireFile($Q{key}.'.cgi');
exit;
