package item;
$USE[0]={'code'=>'udon-zanmai','no'=>0,'itemno'=>'39','name'=>'먹기','info'=>'따뜻한 우동을 먹습니다','scale'=>'설정','action'=>'먹기','money'=>0,'time'=>150,'exptime'=>'150','use'=>[{'no'=>39,'count'=>1,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'아주 맛있게 완성되었습니다',},'create'=>[{'no'=>63,'count'=>3,'proba'=>1000},{'no'=>58,'count'=>10,'proba'=>300},],},};

1;
