package item;
$USE[0]={'code'=>'tool-huku','no'=>0,'itemno'=>'59','name'=>'복권를 하다','info'=>'모음했습니다복권보조권에서 복권를 합니다','scale'=>'회','action'=>'복권를 하다','money'=>0,'time'=>150,'exptime'=>'150','use'=>[{'no'=>59,'count'=>5,'proba'=>1000},],'result'=>{'function'=>'_local_1',},};
sub _local_1 {eval(<<'_eval_code_');
my $ret;my $hit1=0;my $hit2=0;my $hit3=0;my $hit4=0;my $hit5=0;my $hit6=0;my $hit7=0;foreach(1..$count){if(rand(1000)<1){$hit1+=1;}elsif(rand(1000)<3){$hit2+=1;}elsif(rand(1000)<10){$hit3+=1;}elsif(rand(1000)<50){$hit4+=1;}elsif(rand(1000)<100){$hit5+=1;}elsif(rand(1000)<200){$hit6+=1;}}$hit7=$count-($hit1+$hit2+$hit3+$hit4+$hit5+$hit6);AddItem(83,$hit1,'무려!특등의 금색 마네키네코가'.$hit1.'회 당첨되었습니다') if ($hit1>=1);AddItem(82,$hit2,'무려!1등의 자동차가'.$hit2.'회 당첨되었습니다') if ($hit2>=1);AddItem(80,$hit3,'2등의 설거지 기계가'.$hit3.'회 당첨되었습니다') if ($hit3>=1);AddItem(79,$hit4,'3등의 자전거가'.$hit4.'회 당첨되었습니다') if ($hit4>=1);AddItem(67,$hit5,'4등의 힌트북이'.$hit5.'회 당첨되었습니다') if ($hit5>=1);AddItem(66,$hit6,'5등의 상품권이'.$hit6.'회 당첨되었습니다') if ($hit6>=1);AddItem(64,$hit7,'아쉽지만 깨끗한 그릇이'.$hit7.'회분 당첨되었습니다') if ($hit7>=1);$ret='복권 결과, 당첨된 상품이 없습니다';$ret='복권에서 경품이 당첨되었습니다' if ($hit7<$count);WriteLog(0,$DT->{id},$ret);return $ret;
_eval_code_
}

1;
