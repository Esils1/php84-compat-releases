package item;
$USE[0]={'code'=>'man-benri','no'=>0,'itemno'=>'7','name'=>'진열대를 1개로 줄이기','info'=>'진열대를 1개로 줄이기','scale'=>'회','action'=>'작업하기','money'=>0,'time'=>1800,'exptime'=>'1800','arg'=>'nocount','param1'=>'1','result'=>{'function'=>'_local_1',},};
sub _local_1 {eval(<<'_eval_code_');
my $oldcnt=$DT->{showcasecount};my $newcnt=$USE->{param1};$DT->{showcasecount}=$newcnt;if($oldcnt<$newcnt){foreach ($oldcnt..$newcnt-1){$DT->{showcase}[$_]=0;$DT->{price}[$_]=0;}}if($oldcnt>$newcnt){splice(@{$DT->{showcase}},$newcnt);splice(@{$DT->{price}},$newcnt);}my $ret="진열대를 ".$DT->{showcasecount}."개로 변경했습니다";WriteLog(0,$DT->{id},$ret);WriteLog(3,0,$DT->{shopname}."의 진열대 수가 $DT->{showcasecount}개가 되었습니다");return $ret;
_eval_code_
}
sub _job_use_0_man_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/2);$use->{exptime}=int($use->{exptime}/2);
_eval_code_
}
$USE[1]={'code'=>'man-benri','no'=>1,'itemno'=>'7','name'=>'진열대를 2개로 만들기','info'=>'진열대를 2개로 만들기','scale'=>'회','action'=>'작업하기','money'=>10000,'time'=>3600,'exptime'=>'3600','arg'=>'nocount','param1'=>'2','result'=>{'function'=>'_local_1',},};
sub _job_use_1_man_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/2);$use->{exptime}=int($use->{exptime}/2);
_eval_code_
}
$USE[2]={'code'=>'man-benri','no'=>2,'itemno'=>'7','name'=>'진열대를 3개로 만들기','info'=>'진열대를 3개로 만들기','scale'=>'회','action'=>'작업하기','money'=>50000,'time'=>7200,'exptime'=>'7200','arg'=>'nocount','param1'=>'3','use'=>[{'no'=>7,'count'=>2,'proba'=>0},],'result'=>{'function'=>'_local_1',},};
sub _job_use_2_man_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/2);$use->{exptime}=int($use->{exptime}/2);
_eval_code_
}
$USE[3]={'code'=>'man-benri','no'=>3,'itemno'=>'7','name'=>'진열대를 4개로 만들기','info'=>'진열대를 4개로 만들기','scale'=>'회','action'=>'작업하기','money'=>100000,'time'=>10800,'exptime'=>'10800','arg'=>'nocount','param1'=>'4','use'=>[{'no'=>7,'count'=>2,'proba'=>0},],'result'=>{'function'=>'_local_1',},};
sub _job_use_3_man_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/2);$use->{exptime}=int($use->{exptime}/2);
_eval_code_
}
$USE[4]={'code'=>'man-benri','no'=>4,'itemno'=>'7','name'=>'진열대를 5개로 만들기','info'=>'진열대를 5개로 만들기','scale'=>'회','action'=>'작업하기','money'=>200000,'time'=>18000,'exptime'=>'18000','arg'=>'nocount','param1'=>'5','use'=>[{'no'=>7,'count'=>3,'proba'=>0},],'result'=>{'function'=>'_local_1',},};
sub _job_use_4_man_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/2);$use->{exptime}=int($use->{exptime}/2);
_eval_code_
}
$USE[5]={'code'=>'man-benri','no'=>5,'itemno'=>'7','name'=>'진열대를 6개로 만들기','info'=>'진열대를 6개로 만들기','scale'=>'회','action'=>'작업하기','money'=>500000,'time'=>21600,'exptime'=>'21600','arg'=>'nocount','param1'=>'6','use'=>[{'no'=>7,'count'=>3,'proba'=>0},],'result'=>{'function'=>'_local_1',},};
sub _job_use_5_man_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/2);$use->{exptime}=int($use->{exptime}/2);
_eval_code_
}
$USE[6]={'code'=>'man-benri','no'=>6,'itemno'=>'7','name'=>'진열대를 7개로 만들기','info'=>'진열대를 7개로 만들기','scale'=>'회','action'=>'작업하기','money'=>1000000,'time'=>25200,'exptime'=>'25200','arg'=>'nocount','param1'=>'7','use'=>[{'no'=>7,'count'=>4,'proba'=>0},],'result'=>{'function'=>'_local_1',},};
sub _job_use_6_man_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/2);$use->{exptime}=int($use->{exptime}/2);
_eval_code_
}
$USE[7]={'code'=>'man-benri','no'=>7,'itemno'=>'7','name'=>'진열대를 8개로 만들기','info'=>'진열대를 8개로 만들기','scale'=>'회','action'=>'작업하기','money'=>2000000,'time'=>28800,'exptime'=>'28800','arg'=>'nocount','param1'=>'8','use'=>[{'no'=>7,'count'=>5,'proba'=>0},],'result'=>{'function'=>'_local_1',},};
sub _job_use_7_man_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/2);$use->{exptime}=int($use->{exptime}/2);
_eval_code_
}
$USE[8]={'code'=>'man-benri','no'=>8,'itemno'=>'7','name'=>'그릇을 씻기','info'=>'더러운 그릇을 씻습니다','scale'=>'회','action'=>'씻기','money'=>0,'time'=>900,'exptime'=>'300','exp'=>'10','param1'=>'10','use'=>[{'no'=>63,'count'=>10,'proba'=>1000},],'result'=>{'function'=>'lostman','message'=>{'resultng'=>'그릇을 모두 깨뜨려 버렸습니다...',},'create'=>[{'no'=>64,'count'=>10,'proba'=>900,'message'=>'그릇이 반짝반짝 깨끗해졌습니다'},{'no'=>58,'count'=>10,'proba'=>20},],},};
sub _job_use_8_man_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/2);$use->{exptime}=int($use->{exptime}/2);
_eval_code_
}
$USE[9]={'code'=>'man-benri','no'=>9,'itemno'=>'7','name'=>'설거지 기계에서 그릇을 씻기','info'=>'더러운 그릇을 설거지 기계에 넣습니다','scale'=>'회','action'=>'넣기','money'=>0,'time'=>1800,'exptime'=>'900','exp'=>'10','param1'=>'50','use'=>[{'no'=>80,'count'=>1,'proba'=>0},{'no'=>63,'count'=>50,'proba'=>1000},],'result'=>{'function'=>'lostman','message'=>{'resultng'=>'그릇을 모두 깨뜨려 버렸습니다...',},'create'=>[{'no'=>64,'count'=>50,'proba'=>950,'message'=>'그릇이 반짝반짝 깨끗해졌습니다'},{'no'=>58,'count'=>10,'proba'=>50},],},};
sub _job_use_9_man_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/2);$use->{exptime}=int($use->{exptime}/2);
_eval_code_
}
$USE[10]={'code'=>'man-benri','no'=>10,'itemno'=>'7','name'=>'[신문]에광고 게재하기','info'=>'아래 양식에 문구를 입력하고 버튼을 누르면<br>[신문]에 광고가 게됩니다','scale'=>'회','action'=>'광고 게재하기','money'=>0,'time'=>18000,'exptime'=>'10800','exp'=>'50','arg'=>'nocount|message100','param1'=>'300','use'=>[{'no'=>7,'count'=>1,'proba'=>1000},],'result'=>{'function'=>'_local_11',},};
sub _local_11 {eval(<<'_eval_code_');
main::OutError('광고문을 입력해 주세요') if !$USE->{arg}->{message};my $ret;my $up=int($USE->{param1}*(2-$DT->{rank}/5000));$DT->{rank}+=$up;$DT->{rank}=10000 if $DT->{rank}>10000;$ret='[신문]에 광고가 게재되어 주목받았습니다. 인기 '.int($up/100)."% 상승";WriteLog(2,0,"[광고]".$USE->{arg}{message});WriteLog(0,$DT->{id},$ret);return $ret;
_eval_code_
}
sub _job_use_10_man_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/2);$use->{exptime}=int($use->{exptime}/2);
_eval_code_
}
$USE[11]={'code'=>'man-benri','no'=>11,'itemno'=>'7','name'=>'게시판 열기','info'=>'전문 직업 게시판을 엽니다','scale'=>'회','action'=>'게시판 열기','money'=>0,'time'=>10800,'exptime'=>'10800','exp'=>'50','arg'=>'nocount','result'=>{'function'=>'_local_12',},};
sub _local_12 {eval(<<'_eval_code_');
my $ret="";main::OutError('전문 직업 게시판은 열려 있지 않습니다') if ($DT->{job} eq '');$DT->{money}+=30000;$DT->{job}='';$ret='게시판을 열어 보조금 \30000을 받았습니다';WriteLog(0,$DT->{id},"게시판을 열어 보조금을 받았습니다");WriteLog(3,0,"전문 직업 게시판을 연 ".$DT->{shopname}."에게 상업조합에서 보조금이 지급된 것 같습니다");return $ret;
_eval_code_
}

1;
