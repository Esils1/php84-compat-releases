package item;
$USE[0]={'code'=>'man-nou','no'=>0,'itemno'=>'2','name'=>'밭을 구하기','info'=>'관리하기 좋은 밭을 찾아 구합니다','scale'=>'반','action'=>'밭을 구하기','money'=>20000,'time'=>5400,'exptime'=>'1800','exp'=>'10','result'=>{'message'=>{'resultok'=>'곧 수확할 수 있을 듯한 밭을 구했고, 덤으로 퇴비도 나누어 받았습니다',},'create'=>[{'no'=>78,'count'=>1,'proba'=>1000},{'no'=>62,'count'=>100,'proba'=>1000},],},};
sub _job_use_0_agri_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[1]={'code'=>'man-nou','no'=>1,'itemno'=>'2','name'=>'밭 경작하기','info'=>'밭에 비료를 주고 경작해 작물의 씨앗을 심습니다','scale'=>'반','action'=>'밭 경작하기','money'=>0,'time'=>5400,'exptime'=>'1800','exp'=>'10','use'=>[{'no'=>76,'count'=>1,'proba'=>1000},{'no'=>62,'count'=>100,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'밭을 잘 경작해 작물의 씨앗을 심었습니다',},'create'=>[{'no'=>77,'count'=>1,'proba'=>1000},{'no'=>58,'count'=>10,'proba'=>100},],},};
sub _job_use_1_agri_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[2]={'code'=>'man-nou','no'=>2,'itemno'=>'2','name'=>'파 수확하기','info'=>'파밭에서 파를 수확합니다','scale'=>'회','action'=>'수확하기','money'=>0,'time'=>5400,'exptime'=>'1800','exp'=>'10','param1'=>'50','use'=>[{'no'=>78,'count'=>1,'proba'=>1000},],'functionbefore'=>'_local_b3','result'=>{'function'=>'lostman','message'=>{'resultng'=>'아무것도 수확할 수 없었습니다...',},'create'=>[{'no'=>12,'count'=>100,'proba'=>500,'message'=>'파를 수확했습니다'},{'no'=>17,'count'=>10,'proba'=>500,'message'=>'추가로 먹기 좋은 옥수수를 가져왔습니다'},{'no'=>59,'count'=>1,'proba'=>10,'message'=>'밭에서 복권보조권을 주웠습니다'},{'no'=>21,'count'=>1,'proba'=>50,'message'=>'밭에 들어온 야생 거위를 붙잡았습니다'},{'no'=>76,'count'=>1,'proba'=>1000},{'no'=>58,'count'=>10,'proba'=>100},],},};
sub _local_b3 {eval(<<'_eval_code_');
return 0 if rand(1000)>50;my $USE=$_[0];foreach(@{$USE->{result}->{create}}){$_->{count}*=2;}$USE->{result}->{message}->{resultok}='이번에는 꽤 풍작이었습니다<br>새 밭을 구했습니다';return 0;
_eval_code_
}
sub _job_use_2_agri_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[3]={'code'=>'man-nou','no'=>3,'itemno'=>'2','name'=>'밀 수확하기','info'=>'밀밭에서 밀을 수확합니다','scale'=>'회','action'=>'수확하기','money'=>0,'time'=>5400,'exptime'=>'1800','exp'=>'10','param1'=>'50','use'=>[{'no'=>78,'count'=>1,'proba'=>1000},],'functionbefore'=>'_local_b4','result'=>{'function'=>'lostman','message'=>{'resultng'=>'아무것도 수확할 수 없었습니다...',},'create'=>[{'no'=>13,'count'=>40,'proba'=>500,'message'=>'밀을 수확하고 추가로 제분했습니다'},{'no'=>15,'count'=>10,'proba'=>500,'message'=>'추가로 고추를 가져왔습니다'},{'no'=>59,'count'=>1,'proba'=>10,'message'=>'밭에서 복권보조권을 주웠습니다'},{'no'=>21,'count'=>1,'proba'=>50,'message'=>'밭에 들어온 야생 거위를 붙잡았습니다'},{'no'=>76,'count'=>1,'proba'=>1000},{'no'=>58,'count'=>10,'proba'=>100},],},};
sub _local_b4 {eval(<<'_eval_code_');
return 0 if rand(1000)>50;my $USE=$_[0];foreach(@{$USE->{result}->{create}}){$_->{count}*=2;}$USE->{result}->{message}->{resultok}='이번에는 꽤 풍작이었습니다<br>새 밭을 구했습니다';return 0;
_eval_code_
}
sub _job_use_3_agri_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[4]={'code'=>'man-nou','no'=>4,'itemno'=>'2','name'=>'메밀 수확하기','info'=>'메밀밭에서 메밀을 수확합니다','scale'=>'회','action'=>'수확하기','money'=>0,'time'=>5400,'exptime'=>'1800','exp'=>'10','param1'=>'50','use'=>[{'no'=>78,'count'=>1,'proba'=>1000},],'functionbefore'=>'_local_b5','result'=>{'function'=>'lostman','message'=>{'resultng'=>'아무것도 수확할 수 없었습니다...',},'create'=>[{'no'=>14,'count'=>40,'proba'=>500,'message'=>'메밀을 수확하고 추가로 메밀가루를 만들었습니다'},{'no'=>15,'count'=>20,'proba'=>500,'message'=>'추가로 고추를 가져왔습니다'},{'no'=>59,'count'=>1,'proba'=>10,'message'=>'밭에서 복권보조권을 주웠습니다'},{'no'=>22,'count'=>1,'proba'=>50,'message'=>'밭에 들어온 야생 돼지를 붙잡았습니다'},{'no'=>76,'count'=>1,'proba'=>1000},{'no'=>58,'count'=>10,'proba'=>100},],},};
sub _local_b5 {eval(<<'_eval_code_');
return 0 if rand(1000)>50;my $USE=$_[0];foreach(@{$USE->{result}->{create}}){$_->{count}*=2;}$USE->{result}->{message}->{resultok}='이번에는 꽤 풍작이었습니다<br>새 밭을 구했습니다';return 0;
_eval_code_
}
sub _job_use_4_agri_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[5]={'code'=>'man-nou','no'=>5,'itemno'=>'2','name'=>'대두 수확하기','info'=>'대두밭에서 대두를 수확합니다','scale'=>'회','action'=>'수확하기','money'=>0,'time'=>5400,'exptime'=>'1800','exp'=>'10','param1'=>'50','use'=>[{'no'=>78,'count'=>1,'proba'=>1000},],'functionbefore'=>'_local_b6','result'=>{'function'=>'lostman','message'=>{'resultng'=>'아무것도 수확할 수 없었습니다...',},'create'=>[{'no'=>16,'count'=>40,'proba'=>500,'message'=>'대두를 수확했습니다'},{'no'=>12,'count'=>30,'proba'=>500,'message'=>'추가로 파를 가져왔습니다'},{'no'=>59,'count'=>1,'proba'=>10,'message'=>'밭에서 복권보조권을 주웠습니다'},{'no'=>22,'count'=>1,'proba'=>50,'message'=>'밭에 들어온 야생 돼지를 붙잡았습니다'},{'no'=>76,'count'=>1,'proba'=>1000},{'no'=>58,'count'=>10,'proba'=>100},],},};
sub _local_b6 {eval(<<'_eval_code_');
return 0 if rand(1000)>50;my $USE=$_[0];foreach(@{$USE->{result}->{create}}){$_->{count}*=2;}$USE->{result}->{message}->{resultok}='이번에는 꽤 풍작이었습니다<br>새 밭을 구했습니다';return 0;
_eval_code_
}
sub _job_use_5_agri_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[6]={'code'=>'man-nou','no'=>6,'itemno'=>'2','name'=>'옥수수 수확하기','info'=>'옥수수밭에서 옥수수를 수확합니다','scale'=>'회','action'=>'수확하기','money'=>0,'time'=>5400,'exptime'=>'1800','exp'=>'10','param1'=>'50','use'=>[{'no'=>78,'count'=>1,'proba'=>1000},],'functionbefore'=>'_local_b7','result'=>{'function'=>'lostman','message'=>{'resultng'=>'아무것도 수확할 수 없었습니다...',},'create'=>[{'no'=>17,'count'=>27,'proba'=>500,'message'=>'옥수수를 수확했습니다'},{'no'=>16,'count'=>20,'proba'=>500,'message'=>'추가로 대두를 가져왔습니다'},{'no'=>59,'count'=>1,'proba'=>10,'message'=>'밭에서 복권보조권을 주웠습니다'},{'no'=>21,'count'=>1,'proba'=>50,'message'=>'밭에 들어온 야생 거위를 붙잡았습니다'},{'no'=>76,'count'=>1,'proba'=>1000},{'no'=>58,'count'=>10,'proba'=>100},],},};
sub _local_b7 {eval(<<'_eval_code_');
return 0 if rand(1000)>50;my $USE=$_[0];foreach(@{$USE->{result}->{create}}){$_->{count}*=2;}$USE->{result}->{message}->{resultok}='이번에는 꽤 풍작이었습니다<br>새 밭을 구했습니다';return 0;
_eval_code_
}
sub _job_use_6_agri_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[7]={'code'=>'man-nou','no'=>7,'itemno'=>'2','name'=>'닭 돌보기','info'=>'먹이를 충분히 준비하면 닭장을 청소한 뒤 닭에게 먹이를 줄 수 있습니다','scale'=>'회','action'=>'돌보기','money'=>0,'time'=>5400,'exptime'=>'1800','exp'=>'10','arg'=>'nocount','param1'=>'2','use'=>[{'no'=>20,'count'=>1,'proba'=>0},],'result'=>{'function'=>'_local_8',},};
sub _local_8 {eval(<<'_eval_code_');
my $val=$USE->{param1}*$count;my $ret="";my $niwatori=$DT->{item}[20-1];my $toumorokosi=$DT->{item}[17-1];if ($niwatori*$count>$toumorokosi){AddItem(58,$count,);$ret='닭의 먹이가 부족해서 닭장 청소만 했습니다';WriteLog(0,$DT->{id},$ret);}else{$val*=$DT->{item}[20-1];$val=int(rand($val) * 2)+1;AddItem(9,$val,);AddItem(58,$count,);UseItem(17,$niwatori*$count,'닭 1마리당 옥수수를 '.$count.'개 먹였습니다');my $useproba=$USE->{param1}*$USE->{param1};my $usecount=0;foreach(1..$count){$usecount++ if rand(1000)<$useproba;}UseItem(20,$usecount,$ITEM[20]->{name}.'가 배불리 먹은 뒤 하늘로 날아갔습니다') if $usecount;$ret='알을 '.$val.'개 얻었습니다';WriteLog(0,$DT->{id},$ret);}return $ret;
_eval_code_
}
sub _job_use_7_agri_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[8]={'code'=>'man-nou','no'=>8,'itemno'=>'2','name'=>'알 부화시키기','info'=>'알을 어미 새에게 품게 해서 부화시켜 봅니다','scale'=>'설정','action'=>'어미 새에게 알 품기','money'=>0,'time'=>5400,'exptime'=>'1800','exp'=>'10','param1'=>'50','use'=>[{'no'=>20,'count'=>1,'proba'=>0},{'no'=>9,'count'=>5,'proba'=>1000},],'result'=>{'function'=>'lostman','message'=>{'resultok'=>'부화 준비가 끝났습니다',},'create'=>[{'no'=>10,'count'=>5,'proba'=>1000},{'no'=>58,'count'=>10,'proba'=>100},],},};
sub _job_use_8_agri_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[9]={'code'=>'man-nou','no'=>9,'itemno'=>'2','name'=>'거위 돌보기','info'=>'거위에게 먹이를 충분히 줘 봅니다','scale'=>'날개','action'=>'돌보기','money'=>0,'time'=>5400,'exptime'=>'1800','exp'=>'10','param1'=>'50','use'=>[{'no'=>21,'count'=>1,'proba'=>1000},{'no'=>17,'count'=>10,'proba'=>1000},],'result'=>{'function'=>'lostman','message'=>{'resultok'=>'고급 푸아그라를 얻었습니다','resultng'=>'푸아그라가 되기 전에 거위가 날아가 버렸습니다...',},'create'=>[{'no'=>19,'count'=>48,'proba'=>500},{'no'=>58,'count'=>10,'proba'=>150},],},};
sub _job_use_9_agri_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[10]={'code'=>'man-nou','no'=>10,'itemno'=>'2','name'=>'돼지 돌보기','info'=>'먹이를 충분히 준비하면 돼지에게 먹이를 준 뒤 산책시킬 수 있습니다','scale'=>'회','action'=>'돌보기','money'=>0,'time'=>5400,'exptime'=>'1800','exp'=>'10','arg'=>'nocount','param1'=>'1','use'=>[{'no'=>22,'count'=>1,'proba'=>0},],'result'=>{'function'=>'_local_11',},};
sub _local_11 {eval(<<'_eval_code_');
my $val=$USE->{param1}*$count;my $ret="";my $buta=$DT->{item}[22-1];my $daizu=$DT->{item}[16-1];if ($buta*$count*5>$daizu){AddItem(58,$count*2,);$ret='먹이가 충분하지 않아 돼지우리 청소만 했습니다';WriteLog(0,$DT->{id},$ret);}else{$val*=$DT->{item}[22-1];$val=int(rand($val) * 3)+1;AddItem(18,$val,);AddItem(58,$count,);UseItem(16,$buta*$count*5,'돼지 1마리당 대두를 '.($count*5).'kg 먹였습니다');my $useproba=$USE->{param1}*$USE->{param1};my $usecount=0;foreach(1..$count){$usecount++ if rand(1000)<$useproba;}UseItem(22,$usecount,$ITEM[22]->{name}.'가 산속으로 도망가 버렸습니다') if $usecount;$ret='식후 산책을 하던 중, 돼지가 트러플을 '.$val.'개 찾았습니다';WriteLog(0,$DT->{id},$ret);}return $ret;
_eval_code_
}
sub _job_use_10_agri_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[11]={'code'=>'man-nou','no'=>11,'itemno'=>'2','name'=>'농업 전문가가 되기','info'=>'지금까지의 경험을 살려 농업 전문가가 됩니다','scale'=>'회','action'=>'농업 전문가가 되기','money'=>0,'time'=>10800,'exptime'=>'10800','exp'=>'10','arg'=>'nocount','needexp'=>'200','result'=>{'function'=>'_local_12',},};
sub _local_12 {eval(<<'_eval_code_');
my $ret="";main::OutError('이미 농업 전문가입니다') if ($DT->{job} eq 'agri');$DT->{job} = 'agri';$ret="농업 전문가가 되었습니다";WriteLog(0,$DT->{id},$ret);return $ret;
_eval_code_
}

1;
