package item;
$USE[0]={'code'=>'udon-yami','no'=>0,'itemno'=>'45','name'=>'먹기','info'=>'따뜻한 우동을 먹습니다','scale'=>'잔','action'=>'먹기','money'=>0,'time'=>150,'exptime'=>'150','use'=>[{'no'=>45,'count'=>1,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'세상에 이렇게 맛있는 음식은 없습니다',},'create'=>[{'no'=>63,'count'=>1,'proba'=>1000},],},};

1;
