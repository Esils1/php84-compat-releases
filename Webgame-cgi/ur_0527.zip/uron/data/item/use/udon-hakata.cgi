package item;
$USE[0]={'code'=>'udon-hakata','no'=>0,'itemno'=>'43','name'=>'먹기','info'=>'따뜻한 우동을 먹습니다','scale'=>'잔','action'=>'먹기','money'=>0,'time'=>150,'exptime'=>'150','use'=>[{'no'=>43,'count'=>1,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'깜짝 놀랄 만큼 맛있게 완성되었습니다',},'create'=>[{'no'=>63,'count'=>1,'proba'=>1000},{'no'=>58,'count'=>10,'proba'=>700},],},};

1;
