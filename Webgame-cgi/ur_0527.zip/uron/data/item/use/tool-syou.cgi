package item;
$USE[0]={'code'=>'tool-syou','no'=>0,'itemno'=>'66','name'=>'퇴비와 교환하기','info'=>'상품권을 원하는 상품과 교환합니다','scale'=>'회','action'=>'교환하기','money'=>0,'time'=>300,'exptime'=>'300','use'=>[{'no'=>66,'count'=>1,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'퇴비를 구했습니다',},'create'=>[{'no'=>62,'count'=>250,'proba'=>1000},],},};
$USE[1]={'code'=>'tool-syou','no'=>1,'itemno'=>'66','name'=>'깨끗한 그릇과 교환하기','info'=>'상품권을 원하는 상품과 교환합니다','scale'=>'회','action'=>'교환하기','money'=>0,'time'=>300,'exptime'=>'300','use'=>[{'no'=>66,'count'=>1,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'깨끗한 그릇을 구했습니다',},'create'=>[{'no'=>64,'count'=>100,'proba'=>1000},],},};
$USE[2]={'code'=>'tool-syou','no'=>2,'itemno'=>'66','name'=>'힌트북과 교환하기','info'=>'상품권을 원하는 상품과 교환합니다','scale'=>'회','action'=>'교환하기','money'=>0,'time'=>300,'exptime'=>'300','use'=>[{'no'=>66,'count'=>2,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'힌트북을 구했습니다',},'create'=>[{'no'=>67,'count'=>1,'proba'=>1000},],},};
$USE[3]={'code'=>'tool-syou','no'=>3,'itemno'=>'66','name'=>'경보기와 교환하기','info'=>'상품권을 원하는 상품과 교환합니다','scale'=>'회','action'=>'교환하기','money'=>0,'time'=>300,'exptime'=>'300','use'=>[{'no'=>66,'count'=>40,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'경보기를 구했습니다',},'create'=>[{'no'=>81,'count'=>1,'proba'=>1000},],},};
$USE[4]={'code'=>'tool-syou','no'=>4,'itemno'=>'66','name'=>'자동차와 교환하기','info'=>'상품권을 원하는 상품과 교환합니다','scale'=>'회','action'=>'교환하기','money'=>0,'time'=>300,'exptime'=>'300','use'=>[{'no'=>66,'count'=>100,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'자동차를 구했습니다',},'create'=>[{'no'=>82,'count'=>1,'proba'=>1000},],},};
$USE[5]={'code'=>'tool-syou','no'=>5,'itemno'=>'66','name'=>'금의 마네키네코와 교환하기','info'=>'상품권을 원하는 상품과 교환합니다','scale'=>'회','action'=>'교환하기','money'=>0,'time'=>300,'exptime'=>'300','use'=>[{'no'=>66,'count'=>200,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'금의 마네키네코를 구했습니다',},'create'=>[{'no'=>83,'count'=>1,'proba'=>1000},],},};
$USE[6]={'code'=>'tool-syou','no'=>6,'itemno'=>'66','name'=>'환전하기','info'=>'상품권을 금권숍에서 환전합니다','scale'=>'매','action'=>'환전하기','money'=>0,'time'=>300,'exptime'=>'300','param1'=>'500','param2'=>'2500','use'=>[{'no'=>66,'count'=>1,'proba'=>1000},],'result'=>{'function'=>'_local_7',},};
sub _local_7 {eval(<<'_eval_code_');
my $ret;if (rand(1000)<300){$DT->{money}+=$USE->{param1}*$count;$ret='금권숍의 매입가가 낮았던 것 같습니다<br>';$ret.=GetMoneyString($USE->{param1}*$count).'로 환전했습니다';}else{$DT->{money}+=$USE->{param2}*$count;$ret=GetMoneyString($USE->{param2}*$count).'로 환전했습니다';}WriteLog(0,$DT->{id},"상품권을 환전했습니다");return $ret;
_eval_code_
}

1;
