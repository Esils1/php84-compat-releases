package item;
$USE[0]={'code'=>'man-soba','no'=>0,'itemno'=>'6','name'=>'기본 메밀국수 만들기','info'=>'기본 메밀국수를 만듭니다','scale'=>'회','action'=>'만들기','money'=>0,'time'=>1800,'exptime'=>'600','exp'=>'10','use'=>[{'no'=>14,'count'=>3,'proba'=>1000},{'no'=>12,'count'=>2,'proba'=>1000},{'no'=>25,'count'=>2,'proba'=>1000},{'no'=>64,'count'=>40,'proba'=>1000},],'result'=>{'message'=>{'resultng'=>'기본 메밀국수 만들기에 실패하여 재료를 낭비했습니다‥',},'create'=>[{'no'=>46,'count'=>40,'proba'=>800,'message'=>'기본 메밀국수가 완성되었습니다'},{'no'=>58,'count'=>10,'proba'=>100},],},};
sub _job_use_0_soba_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[1]={'code'=>'man-soba','no'=>1,'itemno'=>'6','name'=>'미역메밀국수 만들기','info'=>'미역메밀국수를 만듭니다','scale'=>'회','action'=>'만들기','money'=>0,'time'=>1800,'exptime'=>'600','exp'=>'10','use'=>[{'no'=>14,'count'=>3,'proba'=>1000},{'no'=>12,'count'=>2,'proba'=>1000},{'no'=>24,'count'=>5,'proba'=>1000},{'no'=>64,'count'=>32,'proba'=>1000},],'result'=>{'message'=>{'resultng'=>'미역메밀국수 만들기에 실패하여 재료를 낭비했습니다‥',},'create'=>[{'no'=>47,'count'=>30,'proba'=>900,'message'=>'미역메밀국수가 완성되었습니다'},{'no'=>58,'count'=>10,'proba'=>100},],},};
sub _job_use_1_soba_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[2]={'code'=>'man-soba','no'=>2,'itemno'=>'6','name'=>'키츠네메밀국수 만들기','info'=>'키츠네메밀국수를 만듭니다','scale'=>'회','action'=>'만들기','money'=>0,'time'=>1800,'exptime'=>'600','exp'=>'10','use'=>[{'no'=>14,'count'=>3,'proba'=>1000},{'no'=>12,'count'=>2,'proba'=>1000},{'no'=>11,'count'=>10,'proba'=>1000},{'no'=>64,'count'=>25,'proba'=>1000},],'result'=>{'message'=>{'resultng'=>'키츠네메밀국수 만들기에 실패하여 재료를 낭비했습니다‥',},'create'=>[{'no'=>48,'count'=>25,'proba'=>800,'message'=>'키츠네메밀국수가 완성되었습니다'},{'no'=>58,'count'=>10,'proba'=>100},],},};
sub _job_use_2_soba_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[3]={'code'=>'man-soba','no'=>3,'itemno'=>'6','name'=>'마루텐메밀국수 만들기','info'=>'마루텐메밀국수를 만듭니다','scale'=>'회','action'=>'만들기','money'=>0,'time'=>1800,'exptime'=>'600','exp'=>'10','use'=>[{'no'=>14,'count'=>3,'proba'=>1000},{'no'=>12,'count'=>2,'proba'=>1000},{'no'=>26,'count'=>10,'proba'=>1000},{'no'=>64,'count'=>20,'proba'=>1000},],'result'=>{'message'=>{'resultng'=>'마루텐메밀국수 만들기에 실패하여 재료를 낭비했습니다‥',},'create'=>[{'no'=>49,'count'=>20,'proba'=>800,'message'=>'마루텐메밀국수가 완성되었습니다'},{'no'=>58,'count'=>10,'proba'=>100},],},};
sub _job_use_3_soba_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[4]={'code'=>'man-soba','no'=>4,'itemno'=>'6','name'=>'새우튀김메밀국수 만들기','info'=>'새우튀김메밀국수를 만듭니다','scale'=>'회','action'=>'만들기','money'=>0,'time'=>3600,'exptime'=>'1200','exp'=>'20','use'=>[{'no'=>14,'count'=>5,'proba'=>1000},{'no'=>12,'count'=>5,'proba'=>1000},{'no'=>27,'count'=>20,'proba'=>1000},{'no'=>64,'count'=>20,'proba'=>1000},],'result'=>{'message'=>{'resultng'=>'새우튀김메밀국수 만들기에 실패하여 재료를 낭비했습니다‥',},'create'=>[{'no'=>50,'count'=>20,'proba'=>800,'message'=>'새우튀김메밀국수가 완성되었습니다'},{'no'=>58,'count'=>20,'proba'=>100},],},};
sub _job_use_4_soba_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[5]={'code'=>'man-soba','no'=>5,'itemno'=>'6','name'=>'메밀국수 곱빼기 만들기','info'=>'메밀국수 곱빼기를 만듭니다','scale'=>'설정','action'=>'만들기','money'=>0,'time'=>600,'exptime'=>'300','needexp'=>'200','use'=>[{'no'=>48,'count'=>10,'proba'=>1000},{'no'=>49,'count'=>10,'proba'=>1000},{'no'=>50,'count'=>10,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'메밀국수 곱빼기가 완성되었습니다',},'create'=>[{'no'=>51,'count'=>10,'proba'=>1000},],},};
sub _job_use_5_soba_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[6]={'code'=>'man-soba','no'=>6,'itemno'=>'6','name'=>'캐비아메밀국수 만들기','info'=>'캐비아메밀국수를 만듭니다','scale'=>'회','action'=>'만들기','money'=>0,'time'=>5400,'exptime'=>'1800','exp'=>'40','param1'=>'50','needexp'=>'400','use'=>[{'no'=>14,'count'=>3,'proba'=>1000},{'no'=>32,'count'=>1,'proba'=>1000},{'no'=>31,'count'=>2,'proba'=>1000},{'no'=>64,'count'=>8,'proba'=>1000},],'result'=>{'function'=>'lostman','message'=>{'resultng'=>'캐비아메밀국수 만들기에 실패하여 재료를 낭비했습니다‥',},'create'=>[{'no'=>52,'count'=>8,'proba'=>800,'message'=>'캐비아메밀국수가 완성되었습니다'},{'no'=>58,'count'=>10,'proba'=>200},],},};
sub _job_use_6_soba_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[7]={'code'=>'man-soba','no'=>7,'itemno'=>'6','name'=>'트러플메밀국수 만들기','info'=>'트러플메밀국수를 만듭니다','scale'=>'회','action'=>'만들기','money'=>0,'time'=>5400,'exptime'=>'1800','exp'=>'40','param1'=>'50','needexp'=>'400','use'=>[{'no'=>14,'count'=>3,'proba'=>1000},{'no'=>32,'count'=>1,'proba'=>1000},{'no'=>18,'count'=>2,'proba'=>1000},{'no'=>64,'count'=>8,'proba'=>1000},],'result'=>{'function'=>'lostman','message'=>{'resultng'=>'트러플메밀국수 만들기에 실패하여 재료를 낭비했습니다‥',},'create'=>[{'no'=>53,'count'=>10,'proba'=>600,'message'=>'트러플메밀국수가 완성되었습니다'},{'no'=>58,'count'=>10,'proba'=>200},],},};
sub _job_use_7_soba_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[8]={'code'=>'man-soba','no'=>8,'itemno'=>'6','name'=>'푸아그라메밀국수 만들기','info'=>'푸아그라메밀국수를 만듭니다','scale'=>'회','action'=>'만들기','money'=>0,'time'=>5400,'exptime'=>'1800','exp'=>'40','param1'=>'50','needexp'=>'400','use'=>[{'no'=>14,'count'=>3,'proba'=>1000},{'no'=>32,'count'=>1,'proba'=>1000},{'no'=>19,'count'=>2,'proba'=>1000},{'no'=>64,'count'=>6,'proba'=>1000},],'result'=>{'function'=>'lostman','message'=>{'resultng'=>'푸아그라메밀국수 만들기에 실패하여 재료를 낭비했습니다‥',},'create'=>[{'no'=>54,'count'=>6,'proba'=>800,'message'=>'푸아그라메밀국수가 완성되었습니다'},{'no'=>58,'count'=>10,'proba'=>200},],},};
sub _job_use_8_soba_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[9]={'code'=>'man-soba','no'=>9,'itemno'=>'6','name'=>'하카타메밀국수 만들기','info'=>'하카타메밀국수를 만듭니다','scale'=>'회','action'=>'만들기','money'=>0,'time'=>10800,'exptime'=>'3600','exp'=>'50','param1'=>'50','needexp'=>'600','use'=>[{'no'=>14,'count'=>5,'proba'=>1000},{'no'=>22,'count'=>1,'proba'=>1000},{'no'=>30,'count'=>2,'proba'=>1000},{'no'=>64,'count'=>6,'proba'=>1000},],'result'=>{'function'=>'lostman','message'=>{'resultng'=>'하카타메밀국수 만들기에 실패하여 재료를 낭비했습니다‥',},'create'=>[{'no'=>55,'count'=>6,'proba'=>800,'message'=>'하카타메밀국수가 완성되었습니다'},{'no'=>58,'count'=>10,'proba'=>200},],},};
sub _job_use_9_soba_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[10]={'code'=>'man-soba','no'=>10,'itemno'=>'6','name'=>'오리지널 메밀국수 만들기','info'=>'오리지널 메밀국수를 만듭니다','scale'=>'회','action'=>'만들기','money'=>0,'time'=>10800,'exptime'=>'3600','exp'=>'50','needexp'=>'800','use'=>[{'no'=>61,'count'=>1,'proba'=>0},{'no'=>14,'count'=>5,'proba'=>1000},{'no'=>32,'count'=>1,'proba'=>1000},{'no'=>33,'count'=>1,'proba'=>1000},{'no'=>9,'count'=>15,'proba'=>1000},{'no'=>64,'count'=>3,'proba'=>1000},],'result'=>{'function'=>'_local_11','message'=>{'resultng'=>'오리지널 메밀국수 만들기에 실패하여 재료를 낭비했습니다‥',},'create'=>[{'no'=>56,'count'=>5,'proba'=>400,'message'=>'오리지널 메밀국수가 완성되었습니다'},{'no'=>58,'count'=>10,'proba'=>300},],},};
sub _local_11 {eval(<<'_eval_code_');
my $ret="";$DT->{user}->{sobacnt}+=1;if (rand(1000)<100){UseItem(6,1,"<br>일을 마친 메밀국수 장인이 조용히 떠났습니다");}if ((rand(1000)<100)&&($DT->{user}->{sobacnt}>50)){$DT->{user}->{sobacnt}=0;UseItem(61,1,"<br>오리지널 메밀국수 레시피에 불이 옮겨 붙어 타 버렸습니다");WriteLog(0,$DT->{id},"오리지널 메밀국수 레시피를 잃어버렸습니다");WriteLog(2,0,$DT->{shopname}."가오리지널 메밀국수 레시피를 태워 버린 것 같습니다.");}return $ret;
_eval_code_
}
sub _job_use_10_soba_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[11]={'code'=>'man-soba','no'=>11,'itemno'=>'6','name'=>'오리지널 메밀국수를 개발하기','info'=>'정밀혼포함해서만들기오리지널 메밀국수에이름을 붙합니다','scale'=>'회','action'=>'라는 이름의 메밀국수 만들기','money'=>0,'time'=>10800,'exptime'=>'7200','exp'=>'10','arg'=>'nocount|message30','use'=>[{'no'=>46,'count'=>1,'proba'=>1000},{'no'=>47,'count'=>1,'proba'=>1000},{'no'=>48,'count'=>1,'proba'=>1000},{'no'=>49,'count'=>1,'proba'=>1000},{'no'=>50,'count'=>1,'proba'=>1000},{'no'=>52,'count'=>1,'proba'=>1000},{'no'=>53,'count'=>1,'proba'=>1000},{'no'=>54,'count'=>1,'proba'=>1000},{'no'=>55,'count'=>1,'proba'=>1000},],'result'=>{'function'=>'_local_12','message'=>{'resultok'=>'잊기 전에 만드는 법을 메모해 두었습니다',},'create'=>[{'no'=>56,'count'=>1,'proba'=>1000},{'no'=>61,'count'=>1,'proba'=>1000},],},};
sub _local_12 {eval(<<'_eval_code_');
main::OutError('이름을 입력해 주세요') if !$USE->{arg}->{message};my $ret;$ret='오리지널 메밀국수['.$USE->{arg}->{message}.']가 완성되었습니다';WriteLog(3,0,$DT->{shopname}."가 특제 메밀국수 '".$USE->{arg}->{message}."'를 완성했습니다.");WriteLog(0,$DT->{id},$ret);$DT->{user}->{soba}=$USE->{arg}->{message};return $ret;
_eval_code_
}
sub _job_use_11_soba_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[12]={'code'=>'man-soba','no'=>12,'itemno'=>'6','name'=>'메밀국수 제작 전문가가 되기','info'=>'지금까지의 경험을 살려메밀국수제작 전문가가 됩니다','scale'=>'회','action'=>'메밀국수 제작 전문가가 되기','money'=>0,'time'=>10800,'exptime'=>'10800','exp'=>'10','arg'=>'nocount','needexp'=>'200','result'=>{'function'=>'_local_13',},};
sub _local_13 {eval(<<'_eval_code_');
my $ret="";main::OutError('이미 메밀국수 제작 전문가입니다') if ($DT->{job} eq 'soba');$DT->{job} = 'soba';$ret="메밀국수제작 전문가가 되었습니다";WriteLog(0,$DT->{id},$ret);return $ret;
_eval_code_
}

1;
