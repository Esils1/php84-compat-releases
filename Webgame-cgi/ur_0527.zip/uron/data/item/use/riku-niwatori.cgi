package item;
$USE[0]={'code'=>'riku-niwatori','no'=>0,'itemno'=>'20','name'=>'거위와 교환하기','info'=>'양성장에서 닭을 거위와 교환합니다','scale'=>'회','action'=>'교환하기','money'=>0,'time'=>900,'exptime'=>'900','use'=>[{'no'=>20,'count'=>2,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'거위를 구했습니다',},'create'=>[{'no'=>21,'count'=>1,'proba'=>1000},],},};
$USE[1]={'code'=>'riku-niwatori','no'=>1,'itemno'=>'20','name'=>'돼지와 교환하기','info'=>'양성장에서 닭을 돼지와 교환합니다','scale'=>'회','action'=>'교환하기','money'=>0,'time'=>900,'exptime'=>'900','use'=>[{'no'=>20,'count'=>3,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'돼지를 구했습니다',},'create'=>[{'no'=>22,'count'=>1,'proba'=>1000},],},};

1;
