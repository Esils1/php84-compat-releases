package item;
$USE[0]={'code'=>'man-ten','no'=>0,'itemno'=>'4','name'=>'유부 만들기','info'=>'대두에서 콩부패 만들기추가로 유부에가능합니다','scale'=>'회','action'=>'만들기','money'=>0,'time'=>2700,'exptime'=>'900','exp'=>'20','use'=>[{'no'=>16,'count'=>10,'proba'=>1000},],'result'=>{'message'=>{'resultng'=>'유부만들기에실패시재료를 낭비했습니다‥',},'create'=>[{'no'=>11,'count'=>100,'proba'=>800,'message'=>'유부가 완성되었습니다'},{'no'=>58,'count'=>10,'proba'=>200},],},};
sub _job_use_0_temp_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[1]={'code'=>'man-ten','no'=>1,'itemno'=>'4','name'=>'어묵 만들기','info'=>'어묵를 만듭니다','scale'=>'회','action'=>'만들기','money'=>0,'time'=>2700,'exptime'=>'900','exp'=>'20','use'=>[{'no'=>28,'count'=>4,'proba'=>1000},],'result'=>{'message'=>{'resultng'=>'어묵만들기에실패시재료를 낭비했습니다‥',},'create'=>[{'no'=>25,'count'=>100,'proba'=>800,'message'=>'어묵가 완성되었습니다'},{'no'=>58,'count'=>10,'proba'=>200},],},};
sub _job_use_1_temp_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[2]={'code'=>'man-ten','no'=>2,'itemno'=>'4','name'=>'마루텐 만들기','info'=>'마루텐을 만듭니다','scale'=>'회','action'=>'만들기','money'=>0,'time'=>2700,'exptime'=>'900','exp'=>'20','param1'=>'50','use'=>[{'no'=>29,'count'=>2,'proba'=>1000},],'result'=>{'function'=>'lostman','message'=>{'resultng'=>'마루텐만들기에실패시재료를 낭비했습니다‥',},'create'=>[{'no'=>26,'count'=>60,'proba'=>800,'message'=>'마루텐이 완성되었습니다'},{'no'=>58,'count'=>10,'proba'=>200},],},};
sub _job_use_2_temp_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[3]={'code'=>'man-ten','no'=>3,'itemno'=>'4','name'=>'새우튀김 만들기','info'=>'새우튀김을 만듭니다','scale'=>'회','action'=>'만들기','money'=>0,'time'=>2700,'exptime'=>'900','exp'=>'20','param1'=>'50','use'=>[{'no'=>23,'count'=>20,'proba'=>1000},{'no'=>13,'count'=>2,'proba'=>1000},{'no'=>9,'count'=>10,'proba'=>1000},],'result'=>{'function'=>'lostman','message'=>{'resultng'=>'새우튀김만들기에실패시재료를 낭비했습니다‥',},'create'=>[{'no'=>27,'count'=>50,'proba'=>800,'message'=>'새우튀김이 완성되었습니다'},{'no'=>58,'count'=>10,'proba'=>200},],},};
sub _job_use_3_temp_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[4]={'code'=>'man-ten','no'=>4,'itemno'=>'4','name'=>'튀김 전문가가 되기','info'=>'지금까지의 경험을 살려튀김 만들기의 전문가가 됩니다','scale'=>'회','action'=>'튀김 전문가가 되기','money'=>0,'time'=>10800,'exptime'=>'10800','exp'=>'20','arg'=>'nocount','needexp'=>'200','result'=>{'function'=>'_local_5',},};
sub _local_5 {eval(<<'_eval_code_');
my $ret="";main::OutError('이미 튀김 전문가입니다') if ($DT->{job} eq 'temp');$DT->{job} = 'temp';$ret="튀김 만들기의 전문가가 되었습니다";WriteLog(0,$DT->{id},$ret);return $ret;
_eval_code_
}

1;
