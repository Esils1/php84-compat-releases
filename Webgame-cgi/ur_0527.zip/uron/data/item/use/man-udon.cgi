package item;
$USE[0]={'code'=>'man-udon','no'=>0,'itemno'=>'5','name'=>'기본 우동 만들기','info'=>'기본 우동을 만듭니다','scale'=>'회','action'=>'만들기','money'=>0,'time'=>1800,'exptime'=>'600','exp'=>'10','use'=>[{'no'=>13,'count'=>3,'proba'=>1000},{'no'=>12,'count'=>2,'proba'=>1000},{'no'=>25,'count'=>2,'proba'=>1000},{'no'=>64,'count'=>40,'proba'=>1000},],'result'=>{'message'=>{'resultng'=>'기본 우동 만들기에 실패하여 재료를 낭비했습니다‥',},'create'=>[{'no'=>34,'count'=>40,'proba'=>800,'message'=>'기본 우동이 완성되었습니다'},{'no'=>58,'count'=>10,'proba'=>100},],},};
sub _job_use_0_udon_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[1]={'code'=>'man-udon','no'=>1,'itemno'=>'5','name'=>'미역우동 만들기','info'=>'미역우동을 만듭니다','scale'=>'회','action'=>'만들기','money'=>0,'time'=>1800,'exptime'=>'600','exp'=>'10','use'=>[{'no'=>13,'count'=>3,'proba'=>1000},{'no'=>12,'count'=>2,'proba'=>1000},{'no'=>24,'count'=>5,'proba'=>1000},{'no'=>64,'count'=>32,'proba'=>1000},],'result'=>{'message'=>{'resultng'=>'미역우동 만들기에 실패하여 재료를 낭비했습니다‥',},'create'=>[{'no'=>35,'count'=>30,'proba'=>900,'message'=>'미역우동이 완성되었습니다'},{'no'=>58,'count'=>10,'proba'=>100},],},};
sub _job_use_1_udon_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[2]={'code'=>'man-udon','no'=>2,'itemno'=>'5','name'=>'키츠네우동 만들기','info'=>'키츠네우동을 만듭니다','scale'=>'회','action'=>'만들기','money'=>0,'time'=>1800,'exptime'=>'600','exp'=>'10','use'=>[{'no'=>13,'count'=>3,'proba'=>1000},{'no'=>12,'count'=>2,'proba'=>1000},{'no'=>11,'count'=>10,'proba'=>1000},{'no'=>64,'count'=>25,'proba'=>1000},],'result'=>{'message'=>{'resultng'=>'키츠네우동 만들기에 실패하여 재료를 낭비했습니다‥',},'create'=>[{'no'=>36,'count'=>25,'proba'=>800,'message'=>'키츠네우동이 완성되었습니다'},{'no'=>58,'count'=>10,'proba'=>100},],},};
sub _job_use_2_udon_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[3]={'code'=>'man-udon','no'=>3,'itemno'=>'5','name'=>'마루텐우동 만들기','info'=>'마루텐우동을 만듭니다','scale'=>'회','action'=>'만들기','money'=>0,'time'=>1800,'exptime'=>'600','exp'=>'10','use'=>[{'no'=>13,'count'=>3,'proba'=>1000},{'no'=>12,'count'=>2,'proba'=>1000},{'no'=>26,'count'=>10,'proba'=>1000},{'no'=>64,'count'=>20,'proba'=>1000},],'result'=>{'message'=>{'resultng'=>'마루텐우동 만들기에 실패하여 재료를 낭비했습니다‥',},'create'=>[{'no'=>37,'count'=>20,'proba'=>800,'message'=>'마루텐우동이 완성되었습니다'},{'no'=>58,'count'=>10,'proba'=>100},],},};
sub _job_use_3_udon_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[4]={'code'=>'man-udon','no'=>4,'itemno'=>'5','name'=>'새우튀김우동 만들기','info'=>'새우튀김우동을 만듭니다','scale'=>'회','action'=>'만들기','money'=>0,'time'=>3600,'exptime'=>'1200','exp'=>'20','use'=>[{'no'=>13,'count'=>5,'proba'=>1000},{'no'=>12,'count'=>5,'proba'=>1000},{'no'=>27,'count'=>20,'proba'=>1000},{'no'=>64,'count'=>20,'proba'=>1000},],'result'=>{'message'=>{'resultng'=>'새우튀김우동 만들기에 실패하여 재료를 낭비했습니다‥',},'create'=>[{'no'=>38,'count'=>20,'proba'=>800,'message'=>'새우튀김우동이 완성되었습니다'},{'no'=>58,'count'=>20,'proba'=>100},],},};
sub _job_use_4_udon_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[5]={'code'=>'man-udon','no'=>5,'itemno'=>'5','name'=>'우동 곱빼기 만들기','info'=>'우동 곱빼기를 만듭니다','scale'=>'설정','action'=>'만들기','money'=>0,'time'=>600,'exptime'=>'300','needexp'=>'200','use'=>[{'no'=>36,'count'=>10,'proba'=>1000},{'no'=>37,'count'=>10,'proba'=>1000},{'no'=>38,'count'=>10,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'우동 곱빼기가 완성되었습니다',},'create'=>[{'no'=>39,'count'=>10,'proba'=>1000},],},};
sub _job_use_5_udon_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[6]={'code'=>'man-udon','no'=>6,'itemno'=>'5','name'=>'캐비아우동 만들기','info'=>'캐비아우동을 만듭니다','scale'=>'회','action'=>'만들기','money'=>0,'time'=>5400,'exptime'=>'1800','exp'=>'40','param1'=>'50','needexp'=>'400','use'=>[{'no'=>13,'count'=>3,'proba'=>1000},{'no'=>32,'count'=>1,'proba'=>1000},{'no'=>31,'count'=>2,'proba'=>1000},{'no'=>64,'count'=>8,'proba'=>1000},],'result'=>{'function'=>'lostman','message'=>{'resultng'=>'캐비아우동 만들기에 실패하여 재료를 낭비했습니다‥',},'create'=>[{'no'=>40,'count'=>8,'proba'=>800,'message'=>'캐비아우동이 완성되었습니다'},{'no'=>58,'count'=>10,'proba'=>200},],},};
sub _job_use_6_udon_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[7]={'code'=>'man-udon','no'=>7,'itemno'=>'5','name'=>'트러플우동 만들기','info'=>'트러플우동을 만듭니다','scale'=>'회','action'=>'만들기','money'=>0,'time'=>5400,'exptime'=>'1800','exp'=>'40','param1'=>'50','needexp'=>'400','use'=>[{'no'=>13,'count'=>3,'proba'=>1000},{'no'=>32,'count'=>1,'proba'=>1000},{'no'=>18,'count'=>2,'proba'=>1000},{'no'=>64,'count'=>8,'proba'=>1000},],'result'=>{'function'=>'lostman','message'=>{'resultng'=>'트러플우동 만들기에 실패하여 재료를 낭비했습니다‥',},'create'=>[{'no'=>41,'count'=>10,'proba'=>600,'message'=>'트러플우동이 완성되었습니다'},{'no'=>58,'count'=>10,'proba'=>200},],},};
sub _job_use_7_udon_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[8]={'code'=>'man-udon','no'=>8,'itemno'=>'5','name'=>'푸아그라우동 만들기','info'=>'푸아그라우동을 만듭니다','scale'=>'회','action'=>'만들기','money'=>0,'time'=>5400,'exptime'=>'1800','exp'=>'40','param1'=>'50','needexp'=>'400','use'=>[{'no'=>13,'count'=>3,'proba'=>1000},{'no'=>32,'count'=>1,'proba'=>1000},{'no'=>19,'count'=>2,'proba'=>1000},{'no'=>64,'count'=>6,'proba'=>1000},],'result'=>{'function'=>'lostman','message'=>{'resultng'=>'푸아그라우동 만들기에 실패하여 재료를 낭비했습니다‥',},'create'=>[{'no'=>42,'count'=>6,'proba'=>800,'message'=>'푸아그라우동이 완성되었습니다'},{'no'=>58,'count'=>10,'proba'=>200},],},};
sub _job_use_8_udon_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[9]={'code'=>'man-udon','no'=>9,'itemno'=>'5','name'=>'하카타우동 만들기','info'=>'하카타우동을 만듭니다','scale'=>'회','action'=>'만들기','money'=>0,'time'=>10800,'exptime'=>'3600','exp'=>'50','param1'=>'50','needexp'=>'600','use'=>[{'no'=>13,'count'=>5,'proba'=>1000},{'no'=>22,'count'=>1,'proba'=>1000},{'no'=>30,'count'=>2,'proba'=>1000},{'no'=>64,'count'=>6,'proba'=>1000},],'result'=>{'function'=>'lostman','message'=>{'resultng'=>'하카타우동 만들기에 실패하여 재료를 낭비했습니다‥',},'create'=>[{'no'=>43,'count'=>6,'proba'=>800,'message'=>'하카타우동이 완성되었습니다'},{'no'=>58,'count'=>10,'proba'=>200},],},};
sub _job_use_9_udon_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[10]={'code'=>'man-udon','no'=>10,'itemno'=>'5','name'=>'오리지널 우동 만들기','info'=>'오리지널 우동을 만듭니다','scale'=>'회','action'=>'만들기','money'=>0,'time'=>10800,'exptime'=>'3600','exp'=>'50','needexp'=>'800','use'=>[{'no'=>60,'count'=>1,'proba'=>0},{'no'=>13,'count'=>5,'proba'=>1000},{'no'=>32,'count'=>1,'proba'=>1000},{'no'=>21,'count'=>1,'proba'=>1000},{'no'=>15,'count'=>5,'proba'=>1000},{'no'=>64,'count'=>3,'proba'=>1000},],'result'=>{'function'=>'_local_11','message'=>{'resultng'=>'오리지널 우동 만들기에 실패하여 재료를 낭비했습니다‥',},'create'=>[{'no'=>44,'count'=>5,'proba'=>400,'message'=>'오리지널 우동이 완성되었습니다'},{'no'=>58,'count'=>10,'proba'=>200},],},};
sub _local_11 {eval(<<'_eval_code_');
my $ret="";$DT->{user}->{udoncnt}+=1;if (rand(1000)<100){UseItem(5,1,"<br>일을 마친 우동 장인이 조용히 떠났습니다");}if ((rand(1000)<100)&&($DT->{user}->{udoncnt}>50)){$DT->{user}->{udoncnt}=0;UseItem(60,1,"<br>오리지널 우동 레시피에 불이 옮겨 붙어 타 버렸습니다");WriteLog(0,$DT->{id},"오리지널 우동 레시피를 잃어버렸습니다");WriteLog(2,0,$DT->{shopname}."가오리지널 우동 레시피를 태워 버린 것 같습니다.");}return $ret;
_eval_code_
}
sub _job_use_10_udon_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[11]={'code'=>'man-udon','no'=>11,'itemno'=>'5','name'=>'오리지널 우동을 개발하기','info'=>'정성을 담아 만든 오리지널 우동에 이름을 붙입니다','scale'=>'회','action'=>'라는 이름의 우동 만들기','money'=>0,'time'=>10800,'exptime'=>'7200','exp'=>'10','arg'=>'nocount|message30','use'=>[{'no'=>34,'count'=>1,'proba'=>1000},{'no'=>35,'count'=>1,'proba'=>1000},{'no'=>36,'count'=>1,'proba'=>1000},{'no'=>37,'count'=>1,'proba'=>1000},{'no'=>38,'count'=>1,'proba'=>1000},{'no'=>40,'count'=>1,'proba'=>1000},{'no'=>41,'count'=>1,'proba'=>1000},{'no'=>42,'count'=>1,'proba'=>1000},{'no'=>43,'count'=>1,'proba'=>1000},],'result'=>{'function'=>'_local_12','message'=>{'resultok'=>'잊기 전에 만드는 법을 메모해 두었습니다',},'create'=>[{'no'=>44,'count'=>1,'proba'=>1000},{'no'=>60,'count'=>1,'proba'=>1000},],},};
sub _local_12 {eval(<<'_eval_code_');
main::OutError('이름을 입력해 주세요') if !$USE->{arg}->{message};my $ret;$ret='오리지널 우동['.$USE->{arg}->{message}.']가 완성되었습니다';WriteLog(3,0,$DT->{shopname}."가 특제 우동 '".$USE->{arg}->{message}."'를 완성했습니다.");WriteLog(0,$DT->{id},$ret);$DT->{user}->{udon}=$USE->{arg}->{message};return $ret;
_eval_code_
}
sub _job_use_11_udon_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[12]={'code'=>'man-udon','no'=>12,'itemno'=>'5','name'=>'우동 제작 전문가가 되기','info'=>'지금까지의 경험을 살려우동제작 전문가가 됩니다','scale'=>'회','action'=>'우동 제작 전문가가 되기','money'=>0,'time'=>10800,'exptime'=>'10800','exp'=>'10','arg'=>'nocount','needexp'=>'200','result'=>{'function'=>'_local_13',},};
sub _local_13 {eval(<<'_eval_code_');
my $ret="";main::OutError('이미 우동 제작 전문가입니다') if ($DT->{job} eq 'udon');$DT->{job} = 'udon';$ret="우동제작 전문가가 되었습니다";WriteLog(0,$DT->{id},$ret);return $ret;
_eval_code_
}

1;
