package item;
$USE[0]={'code'=>'man-black','no'=>0,'itemno'=>'8','name'=>'동료를 호출부','info'=>'동료가옴루확률은50%입니다','scale'=>'회','action'=>'동료를 호출부','money'=>0,'time'=>10800,'exptime'=>'7200','exp'=>'50','arg'=>'nocount','result'=>{'message'=>{'resultok'=>'동료가 찾아왔습니다','resultng'=>'동료는 옴않았습니다',},'create'=>[{'no'=>8,'count'=>1,'proba'=>500},],},};
sub _job_use_0_black_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/2);$use->{exptime}=int($use->{exptime}/2);
_eval_code_
}
$USE[1]={'code'=>'man-black','no'=>1,'itemno'=>'8','name'=>'어둠우동 만들기','info'=>'있는 재료를 적당히 섞어 우동을 만들어 봅니다','scale'=>'회','action'=>'만들기','money'=>0,'time'=>1800,'exptime'=>'900','exp'=>'10','param1'=>'50','use'=>[{'no'=>63,'count'=>10,'proba'=>1000},],'result'=>{'function'=>'lostman','message'=>{'resultng'=>'어둠우동만들기에실패했습니다‥',},'create'=>[{'no'=>45,'count'=>10,'proba'=>950,'message'=>'어둠우동을 만들었습니다'},{'no'=>58,'count'=>10,'proba'=>70},],},};
sub _job_use_1_black_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/2);$use->{exptime}=int($use->{exptime}/2);
_eval_code_
}
$USE[2]={'code'=>'man-black','no'=>2,'itemno'=>'8','name'=>'어둠메밀국수 만들기','info'=>'있는 재료를 적당히 섞어 메밀국수를 만들어 봅니다','scale'=>'회','action'=>'만들기','money'=>0,'time'=>1800,'exptime'=>'900','exp'=>'10','param1'=>'50','use'=>[{'no'=>63,'count'=>10,'proba'=>1000},],'result'=>{'function'=>'lostman','message'=>{'resultng'=>'어둠메밀국수만들기에실패했습니다‥',},'create'=>[{'no'=>57,'count'=>10,'proba'=>950,'message'=>'어둠메밀국수를 만들었습니다'},{'no'=>58,'count'=>10,'proba'=>70},],},};
sub _job_use_2_black_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/2);$use->{exptime}=int($use->{exptime}/2);
_eval_code_
}
$USE[3]={'code'=>'man-black','no'=>3,'itemno'=>'8','name'=>'바꿔치기 작전을 실행하다','info'=>'다른 점포의 진열대의 상품을몰래 다른 상품과 바꿔치합니다','scale'=>'회','action'=>'실행하다','money'=>0,'time'=>7200,'exptime'=>'3600','exp'=>'50','arg'=>'target|nocount','use'=>[{'no'=>8,'count'=>1,'proba'=>1000},{'no'=>45,'count'=>50,'proba'=>1000},{'no'=>57,'count'=>50,'proba'=>1000},{'no'=>58,'count'=>10,'proba'=>1000},],'result'=>{'function'=>'_local_4',},};
sub _local_4 {eval(<<'_eval_code_');
my $cnt=int(rand(100))+1;my $ret="바꿔치기 작전은 실패했고,점포의 인기가 내려갔습니다";if(rand(1000)<900){if($DTS->{item}[81-1]){if(rand(1000)<200){$DTS->{showcase}[0]=57;$DTS->{price}[0]=20;$DTS->{item}[57-1]+=$cnt;$DTS->{item}[57-1]=2000 if $DTS->{item}[$itemno2-1]>2000;$ret="바꿔치기 작전은 성공했습니다";$DTS->{item}[81-1]--;WriteLog(2,0,$DTS->{shopname}."의진열대의 상품이어둠메밀국수에바꿔치기되어,화가 난 점주가 경보기를 두드려 부쉈습니다");}elsif(rand(1000)<700){$DT->{rank}-=int($DT->{rank}/3);$DTS->{item}[81-1]--;WriteLog(3,0,$DTS->{shopname}."에 침입한 ".$DT->{shopname}."의 비밀 공작원이 경보기를 파괴했지만 결국 붙잡혔습니다");}else{$DT->{rank}-=int($DT->{rank}/3);WriteLog(3,0,$DTS->{shopname}."의 경보기가 요란하게 울려,침입해 있던 ".$DT->{shopname}."의 비밀 공작원이 붙잡혔습니다");}}else{$DTS->{showcase}[0]=45;$DTS->{price}[0]=20;$DTS->{item}[45-1]+=$cnt;$DTS->{item}[45-1]=2000 if $DTS->{item}[$itemno-1]>2000;$ret="바꿔치기 작전은 성공했습니다";WriteLog(2,0,$DTS->{shopname}."의진열대의 상품이어둠우동에바꿔치기되었습니다");}}else{$ret="바꿔치기 작전은 실패했습니다";WriteLog(3,0,$DTS->{shopname}."에 나타난 비밀 공작원이 왠지 아무것도 하지 않고 떠났습니다");}WriteLog(0,$DT->{id},$ret);return $ret;
_eval_code_
}
sub _job_use_3_black_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/2);$use->{exptime}=int($use->{exptime}/2);
_eval_code_
}
$USE[4]={'code'=>'man-black','no'=>4,'itemno'=>'8','name'=>'좀도둑질을 하다','info'=>'경보기가 있는 점포는 위합니다!?','scale'=>'회','action'=>'좀도둑질을 하다','money'=>0,'time'=>7200,'exptime'=>'7200','exp'=>'100','arg'=>'target|nocount','use'=>[{'no'=>58,'count'=>50,'proba'=>1000},],'result'=>{'function'=>'_local_5',},};
sub _local_5 {eval(<<'_eval_code_');
my $ret="좀도둑질은 실패시,점포의 인기가 내려갔습니다";if(rand(1000)<700){if($DTS->{item}[81-1]){$DT->{rank}-=int($DT->{rank}/2);if(rand(1000)<700){$DTS->{item}[81-1]--;WriteLog(3,0,$DT->{shopname}."의비밀 공작원이".$DTS->{shopname}."에 좀도둑질하러 침입해,$ITEM[81]->{name}을 파괴했지만 결국 붙잡혔습니다.");}else{WriteLog(3,0,$DT->{shopname}."의비밀 공작원이".$DTS->{shopname}."에 좀도둑질하러 침입했지만 실패했습니다.");}}else{my $manbiki_count=0;foreach my $idx (0..$DTS->{showcasecount}-1){my $itemno=$DTS->{showcase}[$idx];if($itemno){my $cnt=int($DTS->{item}[$itemno-1]/4);$cnt=$ITEM[$itemno]->{limit}-$DT->{item}[$itemno-1] if $DT->{item}[$itemno-1]+$cnt>$ITEM[$itemno]->{limit};$DTS->{item}[$itemno-1]-=$cnt;$DT->{item}[$itemno-1]+=$cnt;$manbiki_count+=$cnt*$DTS->{price}[$idx];}}$ret="좀도둑질은 성공했습니다";$ret="비밀 공작원은 마음이 바뀌어 좀도둑질을 그만두었습니다" if !$manbiki_count;WriteLog(2,0,$DTS->{shopname}."가 총액 ".GetMoneyString($manbiki_count)."의 좀도둑 피해를 입었습니다.") if $manbiki_count;WriteLog(2,0,$DTS->{shopname}."에 침입한 좀도둑은 아무것도 훔치지 못하고 도망쳤습니다.") if !$manbiki_count;}}else{$DT->{rank}-=int($DT->{rank}/3);WriteLog(3,0,$DT->{shopname}."의비밀 공작원이".$DTS->{shopname}."에 좀도둑질하러 침입했지만 실패했습니다.");}WriteLog(0,$DT->{id},$ret);return $ret;
_eval_code_
}
sub _job_use_4_black_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/2);$use->{exptime}=int($use->{exptime}/2);
_eval_code_
}
$USE[5]={'code'=>'man-black','no'=>5,'itemno'=>'8','name'=>'점포의 나쁜 소문을 퍼뜨리기','info'=>'근거 없는 소문을 퍼뜨려다른 점포의 인기를 내립니다','scale'=>'회','action'=>'나쁜 소문을 퍼뜨리기','money'=>0,'time'=>18000,'exptime'=>'18000','exp'=>'100','arg'=>'target|nocount','use'=>[{'no'=>8,'count'=>1,'proba'=>1000},{'no'=>58,'count'=>100,'proba'=>1000},],'result'=>{'function'=>'_local_6',},};
sub _local_6 {eval(<<'_eval_code_');
my $ret;if(rand(1000)<750){$DTS->{rank}-=int($DTS->{rank}/4);$ret=$DTS->{shopname}.'의나쁜 소문 퍼뜨리기 작전이성공했습니다.';WriteLog(0,$DT->{id},$ret);WriteLog(3,0,$DTS->{shopname}.'의나쁜 소문이 퍼져 인기가 내려갔습니다.');}else{$DT->{rank}-=int($DT->{rank}/2);$ret=$DTS->{shopname}.'의나쁜 소문 퍼뜨리기 작전이실패했습니다';WriteLog(0,$DT->{id},$ret);WriteLog(3,0,$DT->{shopname}."의비밀 공작원이".$DTS->{shopname}.'의 나쁜 소문을 퍼뜨리려는 계획을 세우고 있었던 것 같습니다.');}return $ret;
_eval_code_
}
sub _job_use_5_black_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/2);$use->{exptime}=int($use->{exptime}/2);
_eval_code_
}
$USE[6]={'code'=>'man-black','no'=>6,'itemno'=>'8','name'=>'상점력 해방하기','info'=>'상점력을 모두 해방해 가게의 인기를 올립니다','scale'=>'회','action'=>'해방하다','money'=>0,'time'=>3600,'exptime'=>'3600','exp'=>'100','arg'=>'nocount','result'=>{'function'=>'_local_7',},};
sub _local_7 {eval(<<'_eval_code_');
main::OutError('상점력이 100 이상이어야 사용할 수 있습니다') if ($DT->{item}[58-1]<100);my $ret="";my $power;my $cnt=$DT->{item}[58-1];$power=$DT->{item}[58-1]*3;my $up=int($power*(2-$DT->{rank}/5000));$DT->{rank}+=$up;$DT->{rank}=10000 if $DT->{rank}>10000;$ret="상점력을 모두 해방했습니다(인기".int($up/100)."% 상승)";UseItem(58,$cnt);WriteLog(0,$DT->{id},$ret);WriteLog(3,0,$DT->{shopname}."가 상점력을 모두 해방했습니다.");return $ret;
_eval_code_
}
sub _job_use_6_black_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/2);$use->{exptime}=int($use->{exptime}/2);
_eval_code_
}
$USE[7]={'code'=>'man-black','no'=>7,'itemno'=>'8','name'=>'시간 조작하기','info'=>'성공하면 시간을 되돌릴 수 있습니다!','scale'=>'회','action'=>'시간 조작하기','money'=>0,'time'=>0,'exp'=>'100','arg'=>'nocount','use'=>[{'no'=>8,'count'=>2,'proba'=>1000},],'result'=>{'function'=>'_local_8',},};
sub _local_8 {eval(<<'_eval_code_');
my $ret;my $cnt=int(rand(6))+1;if(rand(1000)<100){$ret='시간조작은 실패했습니다';WriteLog(3,0,$DT->{shopname}.'의비밀 공작원이,시간조작을 하게지했은 것 같습니다.');AddItem(8,1,'비밀 공작원의1인이,때공의 할레목에서 돌아옵니다했습니다');WriteLog(0,$DT->{id},'시간조작은 실패했습니다');}else{$DT->{time}-=3600*($cnt);$DT->{user}->{black}+=1;$ret='시간조작은 성공했습니다 (+'.($cnt).'시간)';WriteLog(3,0,$DT->{shopname}.'의비밀 공작원이,시간 조작을 시도한 것 같습니다.');WriteLog(0,$DT->{id},'시간조작의 결과,보유하고 시간이추가했습니다');}return $ret;
_eval_code_
}
$USE[8]={'code'=>'man-black','no'=>8,'itemno'=>'8','name'=>'뒷공작의 푸로 가 됨','info'=>'지금까지의 경험을 살려뒷공작의 전문가가 됩니다','scale'=>'회','action'=>'뒷공작의 푸로 가 됨','money'=>0,'time'=>10800,'exptime'=>'10800','exp'=>'100','arg'=>'nocount','needexp'=>'200','result'=>{'function'=>'_local_9',},};
sub _local_9 {eval(<<'_eval_code_');
my $ret="";main::OutError('이미 뒷공작 전문가입니다') if ($DT->{job} eq 'black');$DT->{job} = 'black';$ret="뒷공작 전문가가 되었습니다";WriteLog(0,$DT->{id},$ret);return $ret;
_eval_code_
}

1;
