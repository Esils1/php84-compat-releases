package item;
$USE[0]={'code'=>'man-free','no'=>0,'itemno'=>'1','name'=>'농업 시작하기','info'=>'아르바이트생이 농업을 시작합니다','scale'=>'인','action'=>'농업 시작하기','money'=>0,'time'=>7200,'exptime'=>'3600','exp'=>'10','use'=>[{'no'=>1,'count'=>1,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'아르바이트생이 농부가 되었습니다',},'create'=>[{'no'=>2,'count'=>1,'proba'=>1000},{'no'=>58,'count'=>10,'proba'=>200},],},};
sub _job_use_0_man_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/2);$use->{exptime}=int($use->{exptime}/2);
_eval_code_
}
$USE[1]={'code'=>'man-free','no'=>1,'itemno'=>'1','name'=>'어업 시작하기','info'=>'아르바이트생은 어업을 시작합니다','scale'=>'인','action'=>'어업 시작하기','money'=>0,'time'=>7200,'exptime'=>'3600','exp'=>'10','use'=>[{'no'=>1,'count'=>1,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'아르바이트생이 어부가 되었습니다',},'create'=>[{'no'=>3,'count'=>1,'proba'=>1000},{'no'=>58,'count'=>10,'proba'=>200},],},};
sub _job_use_1_man_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/2);$use->{exptime}=int($use->{exptime}/2);
_eval_code_
}
$USE[2]={'code'=>'man-free','no'=>2,'itemno'=>'1','name'=>'튀김 장인으로 수련하기','info'=>'아르바이트생이 튀김 장인이 되기 위한 수련을 합니다','scale'=>'인','action'=>'수련하기','money'=>0,'time'=>7200,'exptime'=>'3600','exp'=>'10','use'=>[{'no'=>1,'count'=>1,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'아르바이트생이 튀김 장인이 되었습니다',},'create'=>[{'no'=>4,'count'=>1,'proba'=>1000},{'no'=>58,'count'=>10,'proba'=>200},],},};
sub _job_use_2_man_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/2);$use->{exptime}=int($use->{exptime}/2);
_eval_code_
}
$USE[3]={'code'=>'man-free','no'=>3,'itemno'=>'1','name'=>'우동장인 수련하기','info'=>'아르바이트생은 우동 장인이 되기 위한 수련을 합니다','scale'=>'인','action'=>'수련하기','money'=>0,'time'=>7200,'exptime'=>'3600','exp'=>'10','use'=>[{'no'=>1,'count'=>1,'proba'=>1000},{'no'=>13,'count'=>10,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'아르바이트생은 우동 장인이 되었습니다',},'create'=>[{'no'=>5,'count'=>1,'proba'=>1000},{'no'=>58,'count'=>10,'proba'=>200},],},};
sub _job_use_3_man_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/2);$use->{exptime}=int($use->{exptime}/2);
_eval_code_
}
$USE[4]={'code'=>'man-free','no'=>4,'itemno'=>'1','name'=>'메밀국수장인 수련하기','info'=>'아르바이트생은 메밀국수 장인이 되기 위한 수련을 합니다','scale'=>'인','action'=>'수련하기','money'=>0,'time'=>7200,'exptime'=>'3600','exp'=>'10','use'=>[{'no'=>1,'count'=>1,'proba'=>1000},{'no'=>14,'count'=>10,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'아르바이트생은 메밀국수 장인이 되었습니다',},'create'=>[{'no'=>6,'count'=>1,'proba'=>1000},{'no'=>58,'count'=>10,'proba'=>200},],},};
sub _job_use_4_man_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/2);$use->{exptime}=int($use->{exptime}/2);
_eval_code_
}
$USE[5]={'code'=>'man-free','no'=>5,'itemno'=>'1','name'=>'도우미 되기','info'=>'아르바이트생은 도우미가 됩니다','scale'=>'인','action'=>'도우미 되기','money'=>0,'time'=>7200,'exptime'=>'3600','exp'=>'10','use'=>[{'no'=>1,'count'=>1,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'아르바이트생은 도우미가 되었습니다',},'create'=>[{'no'=>7,'count'=>1,'proba'=>1000},{'no'=>58,'count'=>10,'proba'=>200},],},};
sub _job_use_5_man_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/2);$use->{exptime}=int($use->{exptime}/2);
_eval_code_
}
$USE[6]={'code'=>'man-free','no'=>6,'itemno'=>'1','name'=>'전단지 배포로 자금 벌기','info'=>'조금씩 벌어 봅시다','scale'=>'회','action'=>'일하기','money'=>0,'time'=>7200,'exptime'=>'7200','exp'=>'10','param1'=>'7000','result'=>{'function'=>'_local_7',},};
sub _local_7 {eval(<<'_eval_code_');
$DT->{money}+=$USE->{param1}*$count;my $ret=GetMoneyString($USE->{param1}*$count).'을 벌었습니다';if (rand(1000)<200){UseItem(1,1,$ITEM[1]->{name}.'이 아르바이트 피로로 그만두었습니다');}WriteLog(0,$DT->{id},"아르바이트: $ret");WriteLog(3,0,$DT->{shopname}."의 아르바이트생이 일한 것 같습니다");return $ret;
_eval_code_
}
sub _job_use_6_man_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/2);$use->{exptime}=int($use->{exptime}/2);
_eval_code_
}
$USE[7]={'code'=>'man-free','no'=>7,'itemno'=>'1','name'=>'편의점에서 자금 벌기','info'=>'힘들지만 꽤 돈벌이가 됩니다','scale'=>'회','action'=>'일하기','money'=>0,'time'=>16200,'exptime'=>'16200','exp'=>'10','param1'=>'20000','result'=>{'function'=>'_local_7',},};
sub _job_use_7_man_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/2);$use->{exptime}=int($use->{exptime}/2);
_eval_code_
}
$USE[8]={'code'=>'man-free','no'=>8,'itemno'=>'1','name'=>'인력 파견 전문가가 되기','info'=>'지금까지의 경험을 살려인력 파견업의 전문가가 됩니다','scale'=>'회','action'=>'인력 파견 전문가가 되기','money'=>0,'time'=>10800,'exptime'=>'10800','exp'=>'10','arg'=>'nocount','needexp'=>'200','result'=>{'function'=>'_local_9',},};
sub _local_9 {eval(<<'_eval_code_');
my $ret="";main::OutError('이미 인력 파견 전문가입니다') if ($DT->{job} eq 'man');$DT->{job} = 'man';$ret="인력 파견업의 전문가가 되었습니다";WriteLog(0,$DT->{id},$ret);return $ret;
_eval_code_
}

1;
