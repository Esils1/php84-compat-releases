package item;
$USE[0]={'code'=>'riku-daizu','no'=>0,'itemno'=>'16','name'=>'퇴비통에 넣기','info'=>'오래된 식품을 퇴비통에 넣고퇴비를 만듭니다','scale'=>'kg','action'=>'퇴비통에 넣기','money'=>0,'time'=>30,'exptime'=>'30','use'=>[{'no'=>16,'count'=>1,'proba'=>1000},],'result'=>{'message'=>{'resultng'=>'퇴비 만들기에실패했습니다',},'create'=>[{'no'=>62,'count'=>10,'proba'=>350,'message'=>'상질 퇴비가 만들어졌습니다'},],},};

1;
