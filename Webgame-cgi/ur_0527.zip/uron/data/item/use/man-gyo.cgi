package item;
$USE[0]={'code'=>'man-gyo','no'=>0,'itemno'=>'3','name'=>'낚시하기','info'=>'가까운 해안에서 낚시해 봅니다','scale'=>'회','action'=>'낚시하기','money'=>0,'time'=>8100,'exptime'=>'2700','exp'=>'10','result'=>{'message'=>{'resultng'=>'낚시 결과가 없었습니다...',},'create'=>[{'no'=>28,'count'=>10,'proba'=>500,'message'=>'명태를 낚았습니다'},{'no'=>29,'count'=>2,'proba'=>500,'message'=>'에소를 낚았습니다'},{'no'=>23,'count'=>100,'proba'=>600,'message'=>'새우를 포획했습니다'},{'no'=>24,'count'=>40,'proba'=>500,'message'=>'추가로 미역도 채취했습니다'},{'no'=>21,'count'=>1,'proba'=>20,'message'=>'물에 빠진 거위를 구조했습니다'},{'no'=>58,'count'=>10,'proba'=>200},],},};
sub _job_use_0_fish_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[1]={'code'=>'man-gyo','no'=>1,'itemno'=>'3','name'=>'조업 나가기','info'=>'배를 타고 조업에 나가 봅니다','scale'=>'회','action'=>'조업 나가기','money'=>0,'time'=>7200,'exptime'=>'3600','exp'=>'10','param1'=>'50','use'=>[{'no'=>23,'count'=>50,'proba'=>1000},],'result'=>{'function'=>'lostman','message'=>{'resultng'=>'낚시 결과가 없었습니다...',},'create'=>[{'no'=>28,'count'=>8,'proba'=>300,'message'=>'명태를 낚았습니다'},{'no'=>29,'count'=>8,'proba'=>500,'message'=>'에소를 낚았습니다'},{'no'=>32,'count'=>10,'proba'=>500,'message'=>'다시마를 건졌습니다'},{'no'=>33,'count'=>2,'proba'=>300,'message'=>'대물 철갑상어를 낚았습니다'},{'no'=>22,'count'=>1,'proba'=>20,'message'=>'물에 빠진 돼지를 구조했습니다'},{'no'=>58,'count'=>10,'proba'=>200},],},};
sub _job_use_1_fish_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[2]={'code'=>'man-gyo','no'=>2,'itemno'=>'3','name'=>'명란젓 만들기','info'=>'명태 알을 양념해 명란젓을 만듭니다','scale'=>'회','action'=>'만들기','money'=>0,'time'=>3600,'exptime'=>'1800','exp'=>'10','param1'=>'50','use'=>[{'no'=>28,'count'=>1,'proba'=>1000},{'no'=>15,'count'=>5,'proba'=>1000},],'result'=>{'function'=>'lostman','message'=>{'resultok'=>'명란젓이 완성되었습니다','resultng'=>'명란젓 만들기에 실패하여 재료를 낭비했습니다...',},'create'=>[{'no'=>30,'count'=>20,'proba'=>800},{'no'=>58,'count'=>10,'proba'=>100},],},};
sub _job_use_2_fish_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[3]={'code'=>'man-gyo','no'=>3,'itemno'=>'3','name'=>'캐비아 얻기','info'=>'철갑상어의 배에서 캐비아를 꺼냅니다','scale'=>'회','action'=>'캐비아 얻기','money'=>0,'time'=>3600,'exptime'=>'1800','exp'=>'10','param1'=>'50','use'=>[{'no'=>33,'count'=>1,'proba'=>1000},],'result'=>{'function'=>'lostman','message'=>{'resultok'=>'캐비아를 얻었습니다','resultng'=>'철갑상어가 수컷이라 캐비아를 얻지 못했습니다...',},'create'=>[{'no'=>31,'count'=>40,'proba'=>600},{'no'=>58,'count'=>10,'proba'=>100},],},};
sub _job_use_3_fish_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}
$USE[4]={'code'=>'man-gyo','no'=>4,'itemno'=>'3','name'=>'어업 전문가가 되기','info'=>'지금까지의 경험을 살려 어업 전문가가 됩니다','scale'=>'회','action'=>'어업 전문가가 되기','money'=>0,'time'=>10800,'exptime'=>'10800','exp'=>'10','arg'=>'nocount','needexp'=>'200','result'=>{'function'=>'_local_5',},};
sub _local_5 {eval(<<'_eval_code_');
my $ret="";main::OutError('이미 어업 전문가입니다') if ($DT->{job} eq 'fish');$DT->{job} = 'fish';$ret="어업 전문가가 되었습니다";WriteLog(0,$DT->{id},$ret);return $ret;
_eval_code_
}

1;
