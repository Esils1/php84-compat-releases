package item;
$USE[0]={'code'=>'tool-neko','no'=>0,'itemno'=>'83','name'=>'참배하기','info'=>'장사가 번창하기를 기원하며 금 마네키네코에 참합니다','scale'=>'회','action'=>'참배하기','money'=>0,'time'=>90,'exptime'=>'90','use'=>[{'no'=>58,'count'=>1,'proba'=>1000},],'result'=>{'function'=>'_local_1',},};
sub _local_1 {eval(<<'_eval_code_');
my $val=$count;my $ret="";if($count>=50){$DT->{rank}-=$count*2;$DT->{rank}=0 if $DT->{rank}<0;WriteLog(2,0,$DT->{shopname}.'의 점주가기원을 너무 많이 해서 구급차에 실려 갔습니다.');WriteLog(2,0,'한 번에'.$count.'회나 금 마네키네코를 참배하는 것은 정상적인 상태가 아닙니다.');$ret="‥정신을 차려 보니 병원 침대 위였습니다";}elsif($count>=20){$ret='현기증이 나 버렸습니다. 한 번에 '.$count.'회 참배는 합니다.';WriteLog(0,$DT->{id},$ret);}else{$DT->{rank}+=int(rand($count+1))+$count;$DT->{rank}=10000 if $DT->{rank}>10000;$ret='금 마네키네코를 참배하니 오늘도 장사가 순조로울 것 같은 기분이 들었습니다.';WriteLog(0,$DT->{id},$ret);}return $ret;
_eval_code_
}

1;
