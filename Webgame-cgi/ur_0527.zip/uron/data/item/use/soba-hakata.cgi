package item;
$USE[0]={'code'=>'soba-hakata','no'=>0,'itemno'=>'55','name'=>'먹기','info'=>'따뜻한 메밀국수를 먹습니다','scale'=>'잔','action'=>'먹기','money'=>0,'time'=>150,'exptime'=>'150','use'=>[{'no'=>55,'count'=>1,'proba'=>1000},],'result'=>{'message'=>{'resultok'=>'깜짝 놀랄 만큼 맛있게 완성되었습니다',},'create'=>[{'no'=>63,'count'=>1,'proba'=>1000},{'no'=>58,'count'=>10,'proba'=>700},],},};

1;
