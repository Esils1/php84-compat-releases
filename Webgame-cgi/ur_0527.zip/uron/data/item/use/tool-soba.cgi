package item;
$USE[0]={'code'=>'tool-soba','no'=>0,'itemno'=>'61','name'=>'레시피를 보기','info'=>'오리지널 메밀국수의 재료와 만드는 법을 잊었을 때를 위해','scale'=>'회','action'=>'보기','money'=>0,'time'=>30,'exptime'=>'30','arg'=>'nocount','result'=>{'message'=>{'resultng'=>'[오리지널 메밀국수 만드는 법]<br>재료<br>·메밀국수가루<br>·다시마<br>·철갑상어<br>·알<br>·깨끗한 그릇<br><br>만드는 법<br><b> 비밀</b>',},},};
$USE[1]={'code'=>'tool-soba','no'=>1,'itemno'=>'61','name'=>'오리지널 메밀국수 이름 변경하기','info'=>'오리지널 메밀국수의 이름을 변경합니다','scale'=>'회','action'=>'이름 변경하기','money'=>0,'time'=>7200,'exptime'=>'7200','arg'=>'nocount|message30','result'=>{'function'=>'_local_2',},};
sub _local_2 {eval(<<'_eval_code_');
main::OutError('먼저 오리지널 메밀국수를 개발해 주세요') if !$DT->{user}->{soba};main::OutError('이름을 입력해 주세요') if !$USE->{arg}->{message};my $ret;$ret='오리지널 메밀국수의 이름을 ['.$USE->{arg}->{message}.']로 변경했습니다';WriteLog(3,0,$DT->{shopname}."가 오리지널 메밀국수의 이름을 변경한 것 같습니다");WriteLog(0,$DT->{id},$ret);$DT->{user}->{soba}=$USE->{arg}->{message};return $ret;
_eval_code_
}
sub _job_use_1_soba_ {eval(<<'_eval_code_');
my($i)=@_;
my $use=$USE[$i];$use->{time}=int($use->{time}/1.5);$use->{exptime}=int($use->{exptime}/1.5);
_eval_code_
}

1;
