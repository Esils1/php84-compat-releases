 $TIME_SEND_ITEM=int($TIME_SEND_ITEM/4*3) if (($DT->{item}[79-1])&&(!$DT->{item}[82-1])); $TIME_SEND_ITEM=int($TIME_SEND_ITEM/4) if $DT->{item}[82-1]; 
1;
