package item;
sub _local_ {eval(<<'_eval_code_');
my($ITEM,@DT)=@_;
my $birth_per_day=40;
my $val =1;
my $birth_rate=$birth_per_day && (86400/$birth_per_day);
foreach my $DT (@DT)
{
next if !$DT->{item}[77-1];
if(rand($birth_rate)<$TIMESPAN)
{
UseItemSub(77,$val,$DT);
AddItemSub(78,$val,$DT);
}
}

_eval_code_
}
1;
