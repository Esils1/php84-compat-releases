package item;
sub _local_ {eval(<<'_eval_code_');
my($ITEM,@DT)=@_;
my $gabirth_per_day=3;
my $nibirth_per_day=30;
my $val =1;
my $gabirth_rate=$gabirth_per_day && (86400/$gabirth_per_day);
my $nibirth_rate=$nibirth_per_day && (86400/$nibirth_per_day);
foreach my $DT (@DT)
{
next if !$DT->{item}[10-1];
if(rand($gabirth_rate)<$TIMESPAN)
{
UseItemSub(10,$val,$DT);
AddItemSub(21,$val,$DT);
WriteLog(0,$DT->{id},'무려!알에서 거위가 태어났습니다');
}
if(rand($nibirth_rate)<$TIMESPAN)
{
UseItemSub(10,$val,$DT);
AddItemSub(20,$val,$DT);
}
}

_eval_code_
}
1;
