package item;

sub lostman { my $itemno=$USE->{itemno}; if(rand(1000)<$USE->{param1}) { UseItem($itemno,1,'<br>일을 마친 '.$ITEM[$itemno]->{name}.'가 조용히 떠났습니다'); } return ""; } 
1;
