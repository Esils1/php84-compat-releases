 $DT->{money}='200000'if '200000'; $DT->{time}=$NOW_TIME-eval('24*60*60') if '24*60*60'; if('힌트북:1') { my %item=split /:/,'힌트북:1'; while(my($key,$val)=each %item) { foreach my $item (@ITEM) { $DT->{item}[$item->{no}-1]+=$val,last if $key eq $item->{code} or $key eq $item->{name}; } } } $DEFINE_FUNCNEW_NOLOG=1; WriteLog(1,0,0,$DT->{shopname}."가 리어카를 끌고 이 거리에 나타났습니다.",1); 
1;
