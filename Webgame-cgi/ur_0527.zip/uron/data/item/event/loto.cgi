push(@EVENTMSG,'복권추첨');
1;
