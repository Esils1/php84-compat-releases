push(@EVENTMSG,'오리지널 메밀국수 인기 급상승');
1;
