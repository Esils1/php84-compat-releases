push(@EVENTMSG,'강도둑');
1;
