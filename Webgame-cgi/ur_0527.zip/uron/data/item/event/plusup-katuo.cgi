push(@EVENTMSG,'다시마 유통량이 늘었습니다.');
$ITEM[32]->{plus}=300;
1;
