push(@EVENTMSG,'폐지차');
1;
