push(@EVENTMSG,'철갑상어 유통량이 늘었습니다.');
$ITEM[33]->{plus}=500;
1;
