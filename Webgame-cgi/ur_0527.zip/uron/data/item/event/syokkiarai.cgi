push(@EVENTMSG,'설거지 기계 수명명');
1;
