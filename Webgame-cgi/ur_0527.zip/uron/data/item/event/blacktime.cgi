push(@EVENTMSG,'때의 소용돌이');
1;
