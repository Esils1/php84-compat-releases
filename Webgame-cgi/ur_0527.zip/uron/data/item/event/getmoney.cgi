push(@EVENTMSG,'자금지원');
1;
