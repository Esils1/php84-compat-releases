push(@EVENTMSG,'좀도둑질');
1;
