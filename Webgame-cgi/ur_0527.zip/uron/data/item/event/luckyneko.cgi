push(@EVENTMSG,'금의 마네키네코의 초대운영');
1;
