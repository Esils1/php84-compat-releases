foreach(
'loto	1	500	loto				0	0				',
'luckyneko	2	300	_local_start	200			0	0				',
'yogoredon	3	1000	_local_start	500			0	0				',
'udonpop	4	500	_local_start				0	0				',
'sobapop	5	500	_local_start				0	0				',
'syokkiarai	6	300	_local_start	100			0	0				',
'haisya	7	300	_local_start	100			0	0				',
'happy	8	200					18000	18000	상점가의 대판매리출시가시작마되었습니다.	대판매리출시가끝가 되었습니다.	_local_now	',
'udon-boom	9	100					21600	86400	거리에서는 우동 붐의 것 같습니다.	우동 붐이 끝났습니다.		',
'soba-boom	10	100					21600	86400	거리에서는 메밀국수 붐의 것 같습니다.	메밀국수 붐이 끝났습니다.		',
'plusup-katuo	sui	50					32400	57600	다시마가 풍어입니다.	다시마의 유통량이 평상시로 돌아왔습니다.		',
'plusup-tyouzame	sui	10					21600	64800	철갑상어 떼가 해변으로 몰려왔습니다.	철갑상어의 유통량이 평상시로 돌아왔습니다.		',
'getmoney	13	300	_local_start	100000								',
'manbiki	14	1000	_local_start	400,200			0	0				',
'goutou	15	300	_local_start	700			0	0				',
'blacktime	16	150	_local_start	700			0	0				',
'getpop	17	300	_local_start	1000			0	0				',
'rebel	18	0									_local_now	',
'guildbattle	19	0			_local_end							',
)
{
	my $hash={};
	(
		$hash->{code},
		$hash->{group},
		$hash->{startproba},
		$hash->{startfunc},
		$hash->{startfuncparam},
		$hash->{endfunc},
		$hash->{endfuncparam},
		$hash->{basetime},
		$hash->{plustime},
		$hash->{startmsg},
		$hash->{endmsg},
		$hash->{func},
		$hash->{funcparam},
	)=split(/\t/);
	$EVENT{$hash->{code}}=$hash;
}
1;
