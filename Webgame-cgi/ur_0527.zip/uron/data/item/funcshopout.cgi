 if(GetUserDataEx($DT,'_so_move_in')) { my $present_money=int(($NOW_TIME-GetUserDataEx($DT,'_so_move_in'))/86400)*5000; EditMoney($DT,$present_money); SetUserDataEx($DT,'_so_present_money',$present_money); SetUserDataEx($DT,'_so_move_in',''); } 
1;
