package item;
 if($BUY->{whole}) { my $price=$BUY->{num}*$BUY->{price}; my $count=int $price/500000; $count=AddItemSub(59,$count,$BUY->{dt}) if $count; WriteLog(0,$BUY->{dt}{id},'시장에서 복권보조권을 '.$count.'장 받았습니다') if $count; } 
1;
