package event;
sub _local_start {
my($hitproba)=@_;
foreach my $DT (@DT)
{
next if rand(1000)>$hitproba;
{
foreach my $itemno (82)
{
if ($DT->{item}[82-1]==1) {
$DT->{item}[82-1]=0;
WriteLog(2,0,$DT->{shopname}."가고장장애의 많음이자동차를 폐지차했습니다것 같습니다.");
WriteLog(0,$DT->{id},"자동차를 폐지차했습니다");
}
}
}
}
return 0;

}
1;
