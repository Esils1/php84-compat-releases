package event;
sub _local_start {
foreach(reverse(@DT))
{
next if rand(1000)>200;
if ($_->{user}->{soba}&&($_->{user}->{soba} ne 'n'))
{
my $up=int(300*(2-$_->{rank}/5000));
$_->{rank}+=$up;
$_->{rank}=10000 if $_->{rank}>10000;
return (0,$_->{shopname}.'의 특제 메밀국수 '.$_->{user}->{soba}.'가 인기를 끌자,소문을 듣고 찾아온 고객이 점포 앞에 줄을 서고 있습니다.') ;
}
}
return 0;

}
1;
