package event;
sub _local_start {
my($hitproba)=@_;
foreach my $DT (@main::DT)
{
next if rand(1000)>$hitproba;
{
foreach my $itemno (83)
{
if ($DT->{item}[83-1])
{
$DT->{item}[83-1]=0;
my $up=int(1000*(2-$DT->{rank}/5000));
$DT->{rank}+=$up;
$DT->{rank}=10000 if $DT->{rank}>10000;
WriteLog(2,0,$DT->{shopname}."의 금색 마네키네코가 가게에 행운을 불러와 인기가 올랐습니다.");
WriteLog(0,$DT->{id},"금색 마네키네코의 신비한 힘으로 가게의 인기가 ".int($up/100)."% 상승했습니다");   }
}
}
}
return 0;

}
1;
