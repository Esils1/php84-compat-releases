package event;
sub _local_start {
my($pop)=@_;
foreach(reverse(@DT))
{
next if rand(1000)>300;
$_->{rank}+=$pop;
$_->{rank}=10000 if $_->{rank}>10000;
return (0,$_->{shopname}.'가 잡지에 소개되어 인기가 오른 것 같습니다.');
}
return 0;

}
1;
