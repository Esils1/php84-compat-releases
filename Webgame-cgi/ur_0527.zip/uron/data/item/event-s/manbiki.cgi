package event;
sub _local_start {
my($hitproba,$breakproba)=@_;
foreach my $DT (@DT)
{
next if rand(1000)>$hitproba;
if($DT->{item}[81-1])
{
return (0,$DT->{shopname}.'에 좀도둑이 들어왔지만 저지되었습니다.') if rand(1000)>$breakproba;
$DT->{item}[81-1]--;
return (0,$DT->{shopname}.'에 좀도둑이 침입해,'.$ITEM[81]->{name}.'가 파괴되었습니다.');
}
my $count=0;
foreach my $idx (0..$DT->{showcasecount}-1)
{
my $itemno=$DT->{showcase}[$idx];
next if !$itemno;
my $cnt=int($DT->{item}[$itemno-1]/10);
$DT->{item}[$itemno-1]-=$cnt;
$count+=$cnt*$DT->{price}[$idx];
}
return (0,$DT->{shopname}.'가 총액 '.GetMoneyString($count).'상당의 좀도둑 피해를 입었습니다.') if $count;
return (0,$DT->{shopname}.'에 침입한 좀도둑은 아무것도 훔치지 못하고 도망쳤습니다.');
}
return 0;

}
1;
