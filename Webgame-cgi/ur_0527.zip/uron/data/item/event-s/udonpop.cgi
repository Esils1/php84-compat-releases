package event;
sub _local_start {
foreach(reverse(@DT))
{
next if rand(1000)>200;
if ($_->{user}->{udon}&&($_->{user}->{udon} ne 'n'))
{
my $up=int(300*(2-$_->{rank}/5000));
$_->{rank}+=$up;
$_->{rank}=10000 if $_->{rank}>10000;
return (0,$_->{shopname}.'의 특제 우동 '.$_->{user}->{udon}.'이 거리에서 소문이 나,점포 앞은 기대에 부푼 고객으로 가능합니다.') ;
}
}
return 0;

}
1;
