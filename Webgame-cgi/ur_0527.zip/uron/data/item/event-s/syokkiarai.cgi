package event;
sub _local_start {
my($hitproba)=@_;
foreach my $DT (@DT)
{
next if rand(1000)>$hitproba;
{
foreach my $itemno (80)
{
if ($DT->{item}[80-1]==1)     {
$DT->{item}[80-1]=0;
WriteLog(2,0,$DT->{shopname}."의설거지 기계가고장장애했습니다것 같습니다.");
WriteLog(0,$DT->{id},"고장장애했습니다설거지 기계를 폐지폐기했습니다");
}
}
}
}
return 0;

}
1;
