package event;
sub _local_start {
my($hitproba)=@_;
foreach my $DT (@DT)
{
next if rand(1000)>$hitproba;
if($DT->{user}->{black}>10)
{
my $blackcnt=int($DT->{user}->{black}/10);
my $cnt=int(rand(10))+$blackcnt;
$cnt=12 if $cnt>12;
$DT->{time}+=3600*$cnt;
$DT->{user}->{black}=0;
WriteLog(0,$DT->{id},'때의 소용돌이에 시간을 흡수이포함마되었습니다 -'.$cnt.'시간');
return (0,'도중됨 시간조작 때문에 에 때의 소용돌이가발생시,'.$DT->{shopname}.'의 시간을 흡수이포함인 것 같습니다.');
}
}
return 0;

}
1;
