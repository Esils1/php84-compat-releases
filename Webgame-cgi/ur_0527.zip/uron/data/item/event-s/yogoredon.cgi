package event;
sub _local_start {
my($hitproba)=@_;
foreach my $DT (@main::DT)
{
next if rand(1000)>$hitproba;
{
foreach my $itemno (63)
{
if ($DT->{item}[63-1]>=1000)
{
my $down=int($DT->{rank}/5);
$DT->{rank}-=$down;
$DT->{rank}=0 if $DT->{rank}<0;
WriteLog(2,0,$DT->{shopname}."에 쌓여 있던 더러운 그릇에서 악취가 발생해 점포의 인기가 내려갔습니다.");
WriteLog(0,$DT->{id},"더러운 그릇 때문에,점포의 인기가".int($down/100)."% 내려갔습니다");   }
}
}
}
return 0;

}
1;
