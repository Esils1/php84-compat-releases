#!/usr/bin/perl
# 우동＆메밀국수판 아이템 데이터 2005/01/06 유래

# 이 파일은 아이템 데이터 정의 파일입니다.
# 원하는 대로 사용자 지정할 수 있습니다. 자세한 내용은 설명서를 보세요.

@@DEFINE
	version	05-01-06(URon)		#★상품 데이터 버전 표기
					# 마지막의'URon'은우동＆메밀국수판에서 있음을 표시합니다.
					# 전용 아이템을 넣어 나만의 상인 이야기를 만들 때는,
					# 이 기호를 바꿔 두면 됩니다.

	scale	잔			#★기본 수량 단위
	type0	전체			# 전체 아이템 모음
	type1	인재
	type2	농산물
	type3	해산물
	type4	우동
	type5	메밀국수
	type6	도구

	job	agri		농업		#★직업 코드는 영어 소문자 10자 이내
	job	fish		어업
	job	temp		튀김집
	job	udon		우동집
	job	soba		메밀국수집
	job	man		인력 파견업
	job	black		뒤가업

	# 직업별도 시간단축용변수 설정
	set job_agri_time_rate		1.5	#★직업에 대해있으면1.5배빨리됨
	set job_fish_time_rate		1.5
	set job_temp_time_rate		1.5
	set job_udon_time_rate		1.5
	set job_soba_time_rate		1.5
	set job_man_time_rate		2
	set job_black_time_rate		2

	MaxMoney	999999999	#★최대 자금

	set NewShopMoney	200000					# 초기 자금(@@FUNCNEW에서 사용)
	set NewShopTime		24*60*60				# 초기 보유 시간(초)(@@FUNCNEW에서 사용)
	set NewShopItem		힌트북:1	# 초기 보유 상품(@@FUNCNEW에서 사용) 서식 상품명:개수:상품명:개수:...

	TimeEditShowcase	10m		#★진열대 조작 시간
	TimeShopping		20m		#★매입 시간(구 SOLD OUT과의 호환성 확보용. 현재는 사용하지 않음)
	TimeSendItem		20m		#★아이템매입/전송 시간(기본)
	TimeSendItemPlus	20s		#★아이템매입/전송 시간(1개주변의 추가 시간)
	TimeSendMoney		20m		#★자금전송 시간(기본)
	TimeSendMoneyPlus	100000		#★입금장소필요 시간계산용금액(이금액에 관련 TimeSendMoney 시간을 소비)

	CostShowcase1		0		#★진열대 1개 유지비
	CostShowcase2		1000	# 진열대 2개 유지비
	CostShowcase3		2000	# 진열대 3개 유지비
	CostShowcase4		4000	# 진열대 4개 유지비
	CostShowcase5		8000	# 진열대 5개 유지비
	CostShowcase6		16000	# 진열대 6개 유지비
	CostShowcase7		32000	# 진열대 7개 유지비
	CostShowcase8		64000	# 진열대 8개 유지비

	ItemUseTimeRate		0.5		#★아이템 사용 시 시간 계산 보정 배율(@USE 안의 time, exptime에 유효)


#------ 여기부터 아이템 정의 ---------------------------------


@@ITEM
	no		1
	type	인재
	code	man-free
	name	아르바이트생
	info	가능성을 가진 인재입니다
	scale	인
	price	5000
	cost	100
	limit	5/5
	plus	2h
	pop	1d
	flag	noshowcase|norequest|human
	@@USE
		time	4h
		exp		1%
		exptime	2h
		job		인력 파견업	times/job_man_time_rate
		scale	인
		action	농업 시작하기
		name	농업 시작하기
		info	아르바이트생이 농업을 시작합니다
		okmsg	아르바이트생이 농부가 되었습니다
			use		1	아르바이트생
			get		1	농부
			get		10	상점력	20%
	@@USE
		time	4h
		exp		1%
		exptime	2h
		job		인력 파견업	times/job_man_time_rate
		scale	인
		action	어업 시작하기
		name	어업 시작하기
		info	아르바이트생은 어업을 시작합니다
		okmsg	아르바이트생이 어부가 되었습니다
			use		1	아르바이트생
			get		1	어부
			get		10	상점력	20%
	@@USE
		time	4h
		exp		1%
		exptime	2h
		job		인력 파견업	times/job_man_time_rate
		scale	인
		action	수련하기
		name	튀김 장인으로 수련하기
		info	아르바이트생이 튀김 장인이 되기 위한 수련을 합니다
		okmsg	아르바이트생이 튀김 장인이 되었습니다
			use		1	아르바이트생
			get		1	튀김 장인
			get		10	상점력	20%
	@@USE
		time	4h
		exp		1%
		exptime	2h
		job		인력 파견업	times/job_man_time_rate
		scale	인
		action	수련하기
		name	우동장인 수련하기
		info	아르바이트생은 우동 장인이 되기 위한 수련을 합니다
		okmsg	아르바이트생은 우동 장인이 되었습니다
			use		1	아르바이트생
			use		10	밀가루
			get		1	우동장인
			get		10	상점력	20%
	@@USE
		time	4h
		exp		1%
		exptime	2h
		job		인력 파견업	times/job_man_time_rate
		scale	인
		action	수련하기
		name	메밀국수장인 수련하기
		info	아르바이트생은 메밀국수 장인이 되기 위한 수련을 합니다
		okmsg	아르바이트생은 메밀국수 장인이 되었습니다
			use		1	아르바이트생
			use		10	메밀국수가루
			get		1	메밀국수장인
			get		10	상점력	20%
	@@USE
		time	4h
		exp		1%
		exptime	2h
		job		인력 파견업	times/job_man_time_rate
		scale	인
		action	도우미 되기
		name	도우미 되기
		info	아르바이트생은 도우미가 됩니다
		okmsg	아르바이트생은 도우미가 되었습니다
			use		1	아르바이트생
			get		1	도우미
			get		10	상점력	20%
	@@use
		time	4h
		job		인력 파견업	times/job_man_time_rate
		scale	회
		action	일하기
		name	전단지 배포로 자금 벌기
		info	조금씩 벌어 봅시다
		param	7000
		func	_local_
			$DT->{money}+=$USE->{param1}*$count;
			my $ret=GetMoneyString($USE->{param1}*$count).'을 벌었습니다';
			if (rand(1000)<200)
			{
			UseItem(1,1,$ITEM[1]->{name}.'이 아르바이트 피로로 그만두었습니다');
			}
			WriteLog(0,$DT->{id},"아르바이트: $ret");
			WriteLog(3,0,$DT->{shopname}."의 아르바이트생이 일한 것 같습니다");
			return $ret;
		_local_
	@@use
		time	9h
		job		인력 파견업	times/job_man_time_rate
		scale	회
		action	일하기
		name	편의점에서 자금 벌기
		info	힘들지만 꽤 돈벌이가 됩니다
		param	20000
		func	_local_7
	@@USE
		time	6h
		action	인력 파견 전문가가 되기
		arg		nocount
		name	인력 파견 전문가가 되기
		info	지금까지의 경험을 살려, 인력 파견업의 전문가가 됩니다
			needexp		20%
		func	_local_
			my $ret="";
			main::OutError('이미 인력 파견 전문가입니다') if ($DT->{job} eq 'man');
			$DT->{job} = 'man';
			$ret="인력 파견업의 전문가가 되었습니다";
			WriteLog(0,$DT->{id},$ret);
			return $ret;
		_local_

@@ITEM
	no		2
	type	인재
	code	man-nou
	name	농부
	info	가축을 기르면 수익을 얻을 수 있습니다
	scale	인
	price	30000
	cost	1000
	limit	3/0.5
	plus	1d
	pop	1d
	flag	noshowcase|human
	@@USE
		time	3h
		exp		1%
		exptime	1h
		price	20000
		job		농업	times/job_agri_time_rate
		scale	반
		action	밭을 구하기
		name	밭을 구하기
		info	관리하기 좋은 밭을 찾아 구합니다
		okmsg	곧 수확할 수 있을 듯한 밭을 구했고, 덤으로 퇴비도 나누어 받았습니다
			get		1	수확 대기 중인 밭
			get		100	퇴비
	@@USE
		time	3h
		exp		1%
		exptime	1h
		job		농업	times/job_agri_time_rate
		scale	반
		action	밭 경작하기
		name	밭 경작하기
		info	밭에 비료를 주고 경작해, 작물의 씨앗을 심습니다
		okmsg	밭을 잘 경작해 작물의 씨앗을 심었습니다
			use		1	경작 전의 밭
			use		100	퇴비
			get		1	잘 경작한 밭
			get		10	상점력	10%
	@@USE
		time	3h
		exp		1%
		exptime	1h
		job		농업	times/job_agri_time_rate
		scale	회
		action	수확하기
		name	파 수확하기
		info	파밭에서 파를 수확합니다
		func	lostman
		param	50
		ngmsg	아무것도 수확할 수 없었습니다...
			use		1	수확 대기 중인 밭
			get		100	파	50%	파를 수확했습니다
			get		10	옥수수	50%	추가로 먹기 좋은 옥수수를 가져왔습니다
			get		1	복권보조권	01%	밭에서 복권보조권을 주웠습니다
			get		1	거위	05%	밭에 들어온 야생 거위를 붙잡았습니다
			get		1	경작 전의 밭
			get		10	상점력	10%
		funcb	_local_
			# 1/20 확률로 수확량이2배가 됨
			return 0 if rand(1000)>50;

			my $USE=$_[0];

			foreach(@{$USE->{result}->{create}})
			{
				$_->{count}*=2;
			}

			$USE->{result}->{message}->{resultok}='이번에는 꽤 풍작이었습니다<br>새 밭을 구했습니다';
			return 0;
		_local_
	@@USE
		time	3h
		exp		1%
		exptime	1h
		job		농업	times/job_agri_time_rate
		scale	회
		action	수확하기
		name	밀 수확하기
		info	밀밭에서 밀을 수확합니다
		func	lostman
		param	50
		ngmsg	아무것도 수확할 수 없었습니다...
			use		1	수확 대기 중인 밭
			get		40	밀가루	50%	밀을 수확하고 추가로 제분했습니다
			get		10	고추	50%	추가로 고추를 가져왔습니다
			get		1	복권보조권	01%	밭에서 복권보조권을 주웠습니다
			get		1	거위	05%	밭에 들어온 야생 거위를 붙잡았습니다
			get		1	경작 전의 밭
			get		10	상점력	10%
		funcb	_local_
			return 0 if rand(1000)>50;

			my $USE=$_[0];

			foreach(@{$USE->{result}->{create}})
			{
				$_->{count}*=2;
			}

			$USE->{result}->{message}->{resultok}='이번에는 꽤 풍작이었습니다<br>새 밭을 구했습니다';
			return 0;
		_local_
@@USE
		time	3h
		exp		1%
		exptime	1h
		job		농업	times/job_agri_time_rate
		scale	회
		action	수확하기
		name	메밀 수확하기
		info	메밀밭에서 메밀을 수확합니다
		func	lostman
		param	50
		ngmsg	아무것도 수확할 수 없었습니다...
			use		1	수확 대기 중인 밭
			get		40	메밀국수가루	50%	메밀을 수확하고 추가로 메밀가루를 만들었습니다
			get		20	고추	50%	추가로 고추를 가져왔습니다
			get		1	복권보조권	01%	밭에서 복권보조권을 주웠습니다
			get		1	돼지	05%	밭에 들어온 야생 돼지를 붙잡았습니다
			get		1	경작 전의 밭
			get		10	상점력	10%
		funcb	_local_
			return 0 if rand(1000)>50;

			my $USE=$_[0];

			foreach(@{$USE->{result}->{create}})
			{
				$_->{count}*=2;
			}

			$USE->{result}->{message}->{resultok}='이번에는 꽤 풍작이었습니다<br>새 밭을 구했습니다';
			return 0;
		_local_
@@USE
		time	3h
		exp		1%
		exptime	1h
		job		농업	times/job_agri_time_rate
		scale	회
		action	수확하기
		name	대두 수확하기
		info	대두밭에서 대두를 수확합니다
		func	lostman
		param	50
		ngmsg	아무것도 수확할 수 없었습니다...
			use		1	수확 대기 중인 밭
			get		40	대두	50%	대두를 수확했습니다
			get		30	파	50%	추가로 파를 가져왔습니다
			get		1	복권보조권	01%	밭에서 복권보조권을 주웠습니다
			get		1	돼지	05%	밭에 들어온 야생 돼지를 붙잡았습니다
			get		1	경작 전의 밭
			get		10	상점력	10%
		funcb	_local_
			return 0 if rand(1000)>50;

			my $USE=$_[0];

			foreach(@{$USE->{result}->{create}})
			{
				$_->{count}*=2;
			}

			$USE->{result}->{message}->{resultok}='이번에는 꽤 풍작이었습니다<br>새 밭을 구했습니다';
			return 0;
		_local_
@@USE
		time	3h
		exp		1%
		exptime	1h
		job		농업	times/job_agri_time_rate
		scale	회
		action	수확하기
		name	옥수수 수확하기
		info	옥수수밭에서 옥수수를 수확합니다
		func	lostman
		param	50
		ngmsg	아무것도 수확할 수 없었습니다...
			use		1	수확 대기 중인 밭
			get		27	옥수수	50%	옥수수를 수확했습니다
			get		20	대두	50%	추가로 대두를 가져왔습니다
			get		1	복권보조권	01%	밭에서 복권보조권을 주웠습니다
			get		1	거위	05%	밭에 들어온 야생 거위를 붙잡았습니다
			get		1	경작 전의 밭
			get		10	상점력	10%
		funcb	_local_
			return 0 if rand(1000)>50;

			my $USE=$_[0];

			foreach(@{$USE->{result}->{create}})
			{
				$_->{count}*=2;
			}

			$USE->{result}->{message}->{resultok}='이번에는 꽤 풍작이었습니다<br>새 밭을 구했습니다';
			return 0;
		_local_
	@@USE
		time	3h
		exp		1%
		exptime	1h
		job		농업	times/job_agri_time_rate
		arg		nocount
		action	돌보기
		name	닭 돌보기
		info	먹이를 충분히 준비하면 닭장을 청소한 뒤 닭에게 먹이를 줄 수 있습니다
		param	2
			need		1	닭
		func	_local_
			my $val=$USE->{param1}*$count;
			my $ret="";
			my $niwatori=$DT->{item}[20-1];
			my $toumorokosi=$DT->{item}[17-1];

			if ($niwatori*$count>$toumorokosi)
			{
			AddItem(58,$count,);
			$ret='닭의 먹이가 부족해서 닭장 청소만 했습니다';
			WriteLog(0,$DT->{id},$ret);
			}
			else
			{
			$val*=$DT->{item}[20-1];
			$val=int(rand($val) * 2)+1;
			AddItem(9,$val,);
			AddItem(58,$count,);
			UseItem(17,$niwatori*$count,'닭 1마리당 옥수수를 '.$count.'개 먹였습니다');

			my $useproba=$USE->{param1}*$USE->{param1};
			my $usecount=0;
			foreach(1..$count)
			{
				$usecount++ if rand(1000)<$useproba;
			}
			UseItem(20,$usecount,$ITEM[20]->{name}.'가 배불리 먹은 뒤 하늘로 날아갔습니다') if $usecount;

			$ret='알을 '.$val.'개 얻었습니다';
			WriteLog(0,$DT->{id},$ret);
			}
			return $ret;
		_local_
	@@USE
		time	3h
		exp		1%
		exptime	1h
		job		농업	times/job_agri_time_rate
		scale	설정
		action	어미 새에게 알 품기
		name	알 부화시키기
		info	알을 어미 새에게 품게 해서 부화시켜 봅니다
		func	lostman
		param	50
		okmsg	부화 준비가 끝났습니다
			need		1	닭
			use		5	알
			get		5	부화 대기 중인 알
			get		10	상점력	10%
	@@USE
		time	3h
		exp		1%
		exptime	1h
		job		농업	times/job_agri_time_rate
		scale	날개
		action	돌보기
		name	거위 돌보기
		info 거위에게 먹이를 충분히 줘 봅니다
		func	lostman
		param	50
		ngmsg	푸아그라가 되기 전에 거위가 날아가 버렸습니다...
		okmsg	고급 푸아그라를 얻었습니다
			use		1	거위
			use		10	옥수수
			get		48	푸아그라	50%
			get		10	상점력	15%
	@@USE
		time	3h
		exp		1%
		exptime	1h
		job		농업	times/job_agri_time_rate
		scale	회
		arg		nocount
		action	돌보기
		name	돼지 돌보기
		info	먹이를 충분히 준비하면 돼지에게 먹이를 준 뒤 산책시킬 수 있습니다
		param	1
			need		1	돼지
		func	_local_
			my $val=$USE->{param1}*$count;
			my $ret="";
			my $buta=$DT->{item}[22-1];
			my $daizu=$DT->{item}[16-1];

			if ($buta*$count*5>$daizu)
			{
			AddItem(58,$count*2,);
			$ret='먹이가 충분하지 않아 돼지우리 청소만 했습니다';
			WriteLog(0,$DT->{id},$ret);
			}
			else
			{
			$val*=$DT->{item}[22-1];
			$val=int(rand($val) * 3)+1;
			AddItem(18,$val,);
			AddItem(58,$count,);
			UseItem(16,$buta*$count*5,'돼지 1마리당 대두를 '.($count*5).'kg 먹였습니다');

			my $useproba=$USE->{param1}*$USE->{param1};
			my $usecount=0;
			foreach(1..$count)
			{
				$usecount++ if rand(1000)<$useproba;
			}
			UseItem(22,$usecount,$ITEM[22]->{name}.'가 산속으로 도망가 버렸습니다') if $usecount;

			$ret='식후 산책을 하던 중, 돼지가 트러플을 '.$val.'개 찾았습니다';
			WriteLog(0,$DT->{id},$ret);
			}
			return $ret;
		_local_
	@@USE
		time	6h
		action	농업 전문가가 되기
		scale	회
		arg		nocount
		name	농업 전문가가 되기
		info	지금까지의 경험을 살려, 농업의 전문가가 됩니다
			needexp		20%
		func	_local_
			my $ret="";
			main::OutError('이미 농업 전문가입니다') if ($DT->{job} eq 'agri');
			$DT->{job} = 'agri';
			$ret="농업 전문가가 되었습니다";
			WriteLog(0,$DT->{id},$ret);
			return $ret;
		_local_

@@ITEM
	no		3
	type	인재
	code	man-gyo
	name	어부
	info	대물을 낚으려면 미끼가 필요합니다
	scale	인
	price	30000
	cost	1000
	limit	3/0.5
	plus	1d
	pop	3d
	flag	noshowcase|human
	@@USE
		time	4.5h
		exp		1%
		exptime	1.5h
		job		어업	times/job_fish_time_rate
		scale	회
		action	낚시하기
		name	낚시하기
		info	가까운 해안에서 낚시해 봅니다
		ngmsg	낚시 결과가 없었습니다...
			get		10	명태	50%	명태를 낚았습니다
			get		2	에소	50%	에소를 낚았습니다
			get		100	새우	60%	새우를 포획했습니다
			get		40	미역	50%	추가로 미역도 채취했습니다
			get		1	거위	02%	물에 빠진 거위를 구조했습니다
			get		10	상점력	20%
	@@USE
		time	4h
		exp		1%
		exptime	2h
		job		어업	times/job_fish_time_rate
		scale	회
		action	조업 나가기
		name	조업 나가기
		info	배를 타고 조업에 나가 봅니다
		func	lostman
		param	50
		ngmsg	낚시 결과가 없었습니다...
			use		50	새우
			get		8	명태	30%	명태를 낚았습니다
			get		8	에소	50%	에소를 낚았습니다
			get		10	다시마	50%	다시마를 건졌습니다
			get		2	철갑상어	30%	대물 철갑상어를 낚았습니다
			get		1	돼지	02%	물에 빠진 돼지를 구조했습니다
			get		10	상점력	20%
	@@USE
		time	2h
		exp		1%
		exptime	1h
		job		어업	times/job_fish_time_rate
		scale	회
		action	만들기
		name	명란젓 만들기
		info	명태 알을 양념해 명란젓을 만듭니다
		func	lostman
		param	50
		ngmsg	명란젓 만들기에 실패하여 재료를 낭비했습니다...
		okmsg	명란젓이 완성되었습니다
			use		1	명태
			use		5	고추
			get		20	명란젓	80%
			get		10	상점력	10%
	@@USE
		time	2h
		exp		1%
		exptime	1h
		job		어업	times/job_fish_time_rate
		scale	회
		action	구하기
		name	캐비아 얻기
		info	철갑상어의 배에서 캐비아를 꺼냅니다
		func	lostman
		param	50
		ngmsg	철갑상어가 수컷이라 캐비아를 얻지 못했습니다...
		okmsg	캐비아를 얻었습니다
			use		1	철갑상어
			get		40	캐비아	60%
			get		10	상점력	10%
	@@USE
		time	6h
		action	어업 전문가가 되기
		scale	회
		arg		nocount
		name	어업 전문가가 되기
		info	지금까지의 경험을 살려, 어업의 전문가가 됩니다
			needexp		20%
		func	_local_
			my $ret="";
			main::OutError('이미 어업 전문가입니다') if ($DT->{job} eq 'fish');
			$DT->{job} = 'fish';
			$ret="어업 전문가가 되었습니다";
			WriteLog(0,$DT->{id},$ret);
			return $ret;
		_local_

@@ITEM
	no		4
	type	인재
	code	man-ten
	name	튀김 장인
	info	유부와 어묵도 만듭니다
	scale	인
	price	30000
	cost	1000
	limit	3/0.5
	plus	2d
	pop	3d
	flag	noshowcase|human
	@@USE
		time	90m
		exp	2%
		exptime	30m
		job	튀김집	times/job_temp_time_rate
		scale	회
		action	만들기
		name	유부 만들기
		info	대두로 두부를 만들고, 추가로 유부도 만들 수 있습니다
		ngmsg	유부 만들기에 실패해 재료를 낭비했습니다…
			use		10	대두
			get		100	유부	80%	유부가 완성되었습니다
			get		10	상점력	20%
	@@USE
		time	90m
		exp	2%
		exptime	30m
		job		튀김집	times/job_temp_time_rate
		scale	회
		action	만들기
		name	어묵 만들기
		info	어묵를 만듭니다
		ngmsg	어묵만들기에실패시, 재료를 낭비했습니다‥
			use		4	명태
			get		100	어묵	80%	어묵가 완성되었습니다
			get		10	상점력	20%
	@@USE
		time	90m
		exp	2%
		exptime	30m
		job		튀김집	times/job_temp_time_rate
		scale	회
		action	만들기
		name	마루텐 만들기
		info	마루텐을 만듭니다
		func	lostman
		param	50
		ngmsg	마루텐만들기에실패시, 재료를 낭비했습니다‥
			use		2	에소
			get		60	마루텐	80%	마루텐이 완성되었습니다
			get		10	상점력	20%
	@@USE
		time	90m
		exp	2%
		exptime	30m
		job		튀김집	times/job_temp_time_rate
		scale	회
		action	만들기
		name	새우튀김 만들기
		info	새우튀김을 만듭니다
		func	lostman
		param	50
		ngmsg	새우튀김만들기에실패시, 재료를 낭비했습니다‥
			use		20	새우
			use		2	밀가루
			use		10	알
			get		50	새우튀김	80%	새우튀김이 완성되었습니다
			get		10	상점력	20%
	@@USE
		time	6h
		action	튀김 전문가가 되기
		arg		nocount
		name	튀김 전문가가 되기
		info	지금까지의 경험을 살려, 튀김 만들기의 전문가가 됩니다
			needexp		20%
		func	_local_
			my $ret="";
			main::OutError('이미 튀김 전문가입니다') if ($DT->{job} eq 'temp');
			$DT->{job} = 'temp';
			$ret="튀김 만들기의 전문가가 되었습니다";
			WriteLog(0,$DT->{id},$ret);
			return $ret;
		_local_

@@ITEM
	no		5
	type	인재
	code	man-udon
	name	우동장인
	info	각종 우동을 한 그릇씩 모아 새 우동을 개발합니다!
	scale	인
	price	30000
	cost	1000
	limit	3/0.3
	plus	2d
	pop	3d
	flag	noshowcase|human
	@@USE
		time	1h
		exp	1%
		exptime	20m
		job	우동집	times/job_udon_time_rate
		scale	회
		action	만들기
		name	기본 우동 만들기
		info	기본 우동을 만듭니다
		ngmsg	기본 우동 만들기에 실패하여 , 재료를 낭비했습니다‥
			use		3	밀가루
			use		2	파
			use		2	어묵
			use		40	깨끗한 그릇
			get		40	기본 우동	80%	기본 우동이 완성되었습니다
			get		10	상점력	10%
	@@USE
		time	1h
		exp	1%
		exptime	20m
		job	우동집	times/job_udon_time_rate
		scale	회
		action	만들기
		name	미역우동 만들기
		info	미역우동을 만듭니다
		ngmsg	미역우동 만들기에 실패하여 , 재료를 낭비했습니다‥
			use		3	밀가루
			use		2	파
			use		5	미역
			use		32	깨끗한 그릇
			get		30	미역우동	90%	미역우동이 완성되었습니다
			get		10	상점력	10%
	@@USE
		time	1h
		exp	1%
		exptime	20m
		job	우동집	times/job_udon_time_rate
		scale	회
		action	만들기
		name	키츠네우동 만들기
		info	키츠네우동을 만듭니다
		ngmsg	키츠네우동 만들기에 실패하여 , 재료를 낭비했습니다‥
			use		3	밀가루
			use		2	파
			use		10	유부
			use		25	깨끗한 그릇
			get		25	키츠네우동	80%	키츠네우동이 완성되었습니다
			get		10	상점력	10%
	@@USE
		time	1h
		exp	1%
		exptime	20m
		job	우동집	times/job_udon_time_rate
		scale	회
		action	만들기
		name	마루텐우동 만들기
		info	마루텐우동을 만듭니다
		ngmsg	마루텐우동 만들기에 실패하여 , 재료를 낭비했습니다‥
			use		3	밀가루
			use		2	파
			use		10	마루텐
			use		20	깨끗한 그릇
			get		20	마루텐우동	80%	마루텐우동이 완성되었습니다
			get		10	상점력	10%
	@@USE
		time	2h
		exp	2%
		exptime	40m
		job	우동집	times/job_udon_time_rate
		scale	회
		action	만들기
		name	새우튀김우동 만들기
		info	새우튀김우동을 만듭니다
		ngmsg	새우튀김우동 만들기에 실패하여 , 재료를 낭비했습니다‥
			use		5	밀가루
			use		5	파
			use		20	새우튀김
			use		20	깨끗한 그릇
			get		20	새우튀김우동	80%	새우튀김우동이 완성되었습니다
			get		20	상점력	10%
	@@USE
		time	20m
		exp	0%
		exptime	10m
		job	우동집	times/job_udon_time_rate
		scale	설정
		action	만들기
		name	우동 곱빼기 만들기
		info	우동 곱빼기를 만듭니다
		okmsg	우동 곱빼기가 완성되었습니다
			needexp		20%
			use		10	키츠네우동
			use		10	마루텐우동
			use		10	새우튀김우동
			get		10	우동 곱빼기
	@@USE
		time	3h
		exp	4%
		exptime	1h
		job	우동집	times/job_udon_time_rate
		scale	회
		action	만들기
		name	캐비아우동 만들기
		info	캐비아우동을 만듭니다
		func	lostman
		param	50
		ngmsg	캐비아우동 만들기에 실패하여 , 재료를 낭비했습니다‥
			needexp		40%
			use		3	밀가루
			use		1	다시마
			use		2	캐비아
			use		8	깨끗한 그릇
			get		8	캐비아우동	80%	캐비아우동이 완성되었습니다
			get		10	상점력	20%
	@@USE
		time	3h
		exp	4%
		exptime	1h
		job	우동집	times/job_udon_time_rate
		scale	회
		action	만들기
		name	트러플우동 만들기
		info	트러플우동을 만듭니다
		func	lostman
		param	50
		ngmsg	트러플우동 만들기에 실패하여 , 재료를 낭비했습니다‥
			needexp		40%
			use		3	밀가루
			use		1	다시마
			use		2	트러플
			use		8	깨끗한 그릇
			get		10	트러플우동	60%	트러플우동이 완성되었습니다
			get		10	상점력	20%
	@@USE
		time	3h
		exp	4%
		exptime	1h
		job		우동집	times/job_udon_time_rate
		scale	회
		action	만들기
		name	푸아그라우동 만들기
		info	푸아그라우동을 만듭니다
		func	lostman
		param	50
		ngmsg	푸아그라우동 만들기에 실패하여 , 재료를 낭비했습니다‥
			needexp		40%
			use		3	밀가루
			use		1	다시마
			use		2	푸아그라
			use		6	깨끗한 그릇
			get		6	푸아그라우동	80%	푸아그라우동이 완성되었습니다
			get		10	상점력	20%
	@@USE
		time	6h
		exp	5%
		exptime	2h
		job		우동집	times/job_udon_time_rate
		scale	회
		action	만들기
		name	하카타우동 만들기
		info	하카타우동을 만듭니다
		func	lostman
		param	50
		ngmsg	하카타우동 만들기에 실패하여 , 재료를 낭비했습니다‥
			needexp		60%
			use		5	밀가루
			use		1	돼지
			use		2	명란젓
			use		6	깨끗한 그릇
			get		6	하카타우동	80%	하카타우동이 완성되었습니다
			get		10	상점력	20%
	@@USE
		time	6h
		exp	5%
		exptime	2h
		job		우동집	times/job_udon_time_rate
		scale	회
		action	만들기
		name	오리지널 우동 만들기
		info	오리지널 우동을 만듭니다
		ngmsg	오리지널 우동 만들기에 실패하여 , 재료를 낭비했습니다‥
			needexp		80%
			need		1	오리지널 우동 레시피
			use		5	밀가루
			use		1	다시마
			use		1	거위
			use		5	고추
			use		3	깨끗한 그릇
			get		5	오리지널 우동	40%	오리지널 우동이 완성되었습니다
			get		10	상점력	20%
		func	_local_
			my $ret="";
			$DT->{user}->{udoncnt}+=1;
			if (rand(1000)<100)
			{
				UseItem(@@ITEMNO"우동장인",1,"<br>일을 마친 우동 장인이 조용히 떠났습니다");
			}
			if ((rand(1000)<100)&&($DT->{user}->{udoncnt}>50))
			{
				$DT->{user}->{udoncnt}=0;
				UseItem(@@ITEMNO"오리지널 우동 레시피",1,"<br>오리지널 우동 레시피에 불이 옮겨 붙어 타 버렸습니다");
				WriteLog(0,$DT->{id},"오리지널 우동 레시피를 잃어버렸습니다");
				WriteLog(2,0,$DT->{shopname}."가오리지널 우동 레시피를 태워 버린 것 같습니다.");
			}
			return $ret;
		_local_
	@@USE
		time	6h
		exp		1%
		exptime	4h
		job		우동집	times/job_udon_time_rate
		action	라는 이름의 우동 만들기
		name	오리지널 우동을 개발하기
		info	정성을 담아 만든 오리지널 우동에 이름을 붙입니다
		arg		nocount|message30
		okmsg	잊기 전에 만드는 법을 메모해 두었습니다
			use		1	기본 우동
			use		1	미역우동
			use		1	키츠네우동
			use		1	마루텐우동
			use		1	새우튀김우동
			use		1	캐비아우동
			use		1	트러플우동
			use		1	푸아그라우동
			use		1	하카타우동
			get		1	오리지널 우동
			get		1	오리지널 우동 레시피
		func	_local_
			# 오리지널 우동 만들기
			main::OutError('이름을 입력해 주세요') if !$USE->{arg}->{message};
			my $ret;
			$ret='오리지널 우동['.$USE->{arg}->{message}.']가 완성되었습니다';
			WriteLog(3,0,$DT->{shopname}."가 특제 우동 '".$USE->{arg}->{message}."'를 완성했습니다.");
			WriteLog(0,$DT->{id},$ret);
			$DT->{user}->{udon}=$USE->{arg}->{message};
			return $ret;
		_local_
	@@USE
		time	6h
		action	우동 제작 전문가가 되기
		arg		nocount
		name	우동 제작 전문가가 되기
		info	지금까지의 경험을 살려, 우동제작 전문가가 됩니다
			needexp		20%
		func	_local_
			my $ret="";
			main::OutError('이미 우동 제작 전문가입니다') if ($DT->{job} eq 'udon');
			$DT->{job} = 'udon';
			$ret="우동제작 전문가가 되었습니다";
			WriteLog(0,$DT->{id},$ret);
			return $ret;
		_local_

@@ITEM
	no		6
	type	인재
	code	man-soba
	name	메밀국수장인
	info	각종 메밀국수를 한 그릇씩 모아 새 메밀국수를 개발합니다!
	scale	인
	price	30000
	cost	1000
	limit	3/0.3
	plus	2d
	pop	3d
	flag	noshowcase|human
	@@USE
		time	1h
		exp	1%
		exptime	20m
		job	메밀국수집	times/job_soba_time_rate
		scale	회
		action	만들기
		name	기본 메밀국수 만들기
		info	기본 메밀국수를 만듭니다
		ngmsg	기본 메밀국수 만들기에 실패하여 , 재료를 낭비했습니다‥
			use		3	메밀국수가루
			use		2	파
			use		2	어묵
			use		40	깨끗한 그릇
			get		40	기본 메밀국수	80%	기본 메밀국수가 완성되었습니다
			get		10	상점력	10%
	@@USE
		time	1h
		exp	1%
		exptime	20m
		job		메밀국수집	times/job_soba_time_rate
		scale	회
		action	만들기
		name	미역메밀국수 만들기
		info	미역메밀국수를 만듭니다
		ngmsg	미역메밀국수 만들기에 실패하여 , 재료를 낭비했습니다‥
			use		3	메밀국수가루
			use		2	파
			use		5	미역
			use		32	깨끗한 그릇
			get		30	미역메밀국수	90%	미역메밀국수가 완성되었습니다
			get		10	상점력	10%
	@@USE
		time	1h
		exp	1%
		exptime	20m
		job		메밀국수집	times/job_soba_time_rate
		scale	회
		action	만들기
		name	키츠네메밀국수 만들기
		info	키츠네메밀국수를 만듭니다
		ngmsg	키츠네메밀국수 만들기에 실패하여 , 재료를 낭비했습니다‥
			use		3	메밀국수가루
			use		2	파
			use		10	유부
			use		25	깨끗한 그릇
			get		25	키츠네메밀국수	80%	키츠네메밀국수가 완성되었습니다
			get		10	상점력	10%
	@@USE
		time	1h
		exp	1%
		exptime	20m
		job	메밀국수집	times/job_soba_time_rate
		scale	회
		action	만들기
		name	마루텐메밀국수 만들기
		info	마루텐메밀국수를 만듭니다
		ngmsg	마루텐메밀국수 만들기에 실패하여 , 재료를 낭비했습니다‥
			use		3	메밀국수가루
			use		2	파
			use		10	마루텐
			use		20	깨끗한 그릇
			get		20	마루텐메밀국수	80%	마루텐메밀국수가 완성되었습니다
			get		10	상점력	10%
	@@USE
		time	2h
		exp	2%
		exptime	40m
		job	메밀국수집	times/job_soba_time_rate
		scale	회
		action	만들기
		name	새우튀김메밀국수 만들기
		info	새우튀김메밀국수를 만듭니다
		ngmsg	새우튀김메밀국수 만들기에 실패하여 , 재료를 낭비했습니다‥
			use		5	메밀국수가루
			use		5	파
			use		20	새우튀김
			use		20	깨끗한 그릇
			get		20	새우튀김메밀국수	80%	새우튀김메밀국수가 완성되었습니다
			get		20	상점력	10%
	@@USE
		time	20m
		exp	0%
		exptime	10m
		job		메밀국수집	times/job_soba_time_rate
		scale	설정
		action	만들기
		name	메밀국수 곱빼기 만들기
		info	메밀국수 곱빼기를 만듭니다
		okmsg	메밀국수 곱빼기가 완성되었습니다
			needexp		20%
			use		10	키츠네메밀국수
			use		10	마루텐메밀국수
			use		10	새우튀김메밀국수
			get		10	메밀국수 곱빼기
	@@USE
		time	3h
		exp	4%
		exptime	1h
		job	메밀국수집	times/job_soba_time_rate
		scale	회
		action	만들기
		name	캐비아메밀국수 만들기
		info	캐비아메밀국수를 만듭니다
		func	lostman
		param	50
		ngmsg	캐비아메밀국수 만들기에 실패하여 , 재료를 낭비했습니다‥
			needexp		40%
			use		3	메밀국수가루
			use		1	다시마
			use		2	캐비아
			use		8	깨끗한 그릇
			get		8	캐비아메밀국수	80%	캐비아메밀국수가 완성되었습니다
			get		10	상점력	20%
	@@USE
		time	3h
		exp	4%
		exptime	1h
		job	메밀국수집	times/job_soba_time_rate
		scale	회
		action	만들기
		name	트러플메밀국수 만들기
		info	트러플메밀국수를 만듭니다
		func	lostman
		param	50
		ngmsg	트러플메밀국수 만들기에 실패하여 , 재료를 낭비했습니다‥
			needexp		40%
			use		3	메밀국수가루
			use		1	다시마
			use		2	트러플
			use		8	깨끗한 그릇
			get		10	트러플메밀국수	60%	트러플메밀국수가 완성되었습니다
			get		10	상점력	20%
	@@USE
		time	3h
		exp	4%
		exptime	1h
		job	메밀국수집	times/job_soba_time_rate
		scale	회
		action	만들기
		name	푸아그라메밀국수 만들기
		func	lostman
		param	50
		info	푸아그라메밀국수를 만듭니다
		ngmsg	푸아그라메밀국수 만들기에 실패하여 , 재료를 낭비했습니다‥
			needexp		40%
			use		3	메밀국수가루
			use		1	다시마
			use		2	푸아그라
			use		6	깨끗한 그릇
			get		6	푸아그라메밀국수	80%	푸아그라메밀국수가 완성되었습니다
			get		10	상점력	20%
	@@USE
		time	6h
		exp	5%
		exptime	2h
		job	메밀국수집	times/job_soba_time_rate
		scale	회
		action	만들기
		name	하카타메밀국수 만들기
		info	하카타메밀국수를 만듭니다
		func	lostman
		param	50
		ngmsg	하카타메밀국수 만들기에 실패하여 , 재료를 낭비했습니다‥
			needexp		60%
			use		5	메밀국수가루
			use		1	돼지
			use		2	명란젓
			use		6	깨끗한 그릇
			get		6	하카타메밀국수	80%	하카타메밀국수가 완성되었습니다
			get		10	상점력	20%
	@@USE
		time	6h
		exp	5%
		exptime	2h
		job	메밀국수집	times/job_soba_time_rate
		scale	회
		action	만들기
		name	오리지널 메밀국수 만들기
		info	오리지널 메밀국수를 만듭니다
		ngmsg	오리지널 메밀국수 만들기에 실패하여 , 재료를 낭비했습니다‥
			needexp		80%
			need		1	오리지널 메밀국수 레시피
			use		5	메밀국수가루
			use		1	다시마
			use		1	철갑상어
			use		15	알
			use		3	깨끗한 그릇
			get		5	오리지널 메밀국수	40%	오리지널 메밀국수가 완성되었습니다
			get		10	상점력	30%
		func	_local_
			my $ret="";
			$DT->{user}->{sobacnt}+=1;
			if (rand(1000)<100)
			{
				UseItem(@@ITEMNO"메밀국수장인",1,"<br>일을 마친 메밀국수 장인이 조용히 떠났습니다");
			}
			if ((rand(1000)<100)&&($DT->{user}->{sobacnt}>50))
			{
				$DT->{user}->{sobacnt}=0;
				UseItem(@@ITEMNO"오리지널 메밀국수 레시피",1,"<br>오리지널 메밀국수 레시피에 불이 옮겨 붙어 타 버렸습니다");
				WriteLog(0,$DT->{id},"오리지널 메밀국수 레시피를 잃어버렸습니다");
				WriteLog(2,0,$DT->{shopname}."가오리지널 메밀국수 레시피를 태워 버린 것 같습니다.");
			}
			return $ret;
		_local_
	@@USE
		time	6h
		exp		1%
		exptime	4h
		job		메밀국수집	times/job_soba_time_rate
		action	라는 이름의 메밀국수 만들기
		name	오리지널 메밀국수를 개발하기
		info	정밀혼포함해서만들기오리지널 메밀국수에이름을 붙합니다
		arg		nocount|message30
		okmsg	잊기 전에 만드는 법을 메모해 두었습니다
			use		1	기본 메밀국수
			use		1	미역메밀국수
			use		1	키츠네메밀국수
			use		1	마루텐메밀국수
			use		1	새우튀김메밀국수
			use		1	캐비아메밀국수
			use		1	트러플메밀국수
			use		1	푸아그라메밀국수
			use		1	하카타메밀국수
			get		1	오리지널 메밀국수
			get		1	오리지널 메밀국수 레시피
		func	_local_
			# 오리지널 메밀국수 만들기
			main::OutError('이름을 입력해 주세요') if !$USE->{arg}->{message};
			my $ret;
			$ret='오리지널 메밀국수['.$USE->{arg}->{message}.']가 완성되었습니다';
			WriteLog(3,0,$DT->{shopname}."가 특제 메밀국수 '".$USE->{arg}->{message}."'를 완성했습니다.");
			WriteLog(0,$DT->{id},$ret);
			$DT->{user}->{soba}=$USE->{arg}->{message};
			return $ret;
		_local_
	@@USE
		time	6h
		action	메밀국수 제작 전문가가 되기
		arg		nocount
		name	메밀국수 제작 전문가가 되기
		info	지금까지의 경험을 살려, 메밀국수제작 전문가가 됩니다
			needexp		20%
		func	_local_
			my $ret="";
			main::OutError('이미 메밀국수 제작 전문가입니다') if ($DT->{job} eq 'soba');
			$DT->{job} = 'soba';
			$ret="메밀국수제작 전문가가 되었습니다";
			WriteLog(0,$DT->{id},$ret);
			return $ret;
		_local_

@@ITEM
	no		7
	type	인재
	code	man-benri
	name	도우미
	info	진열대 제작이나 그릇 세척 등을 맡는 인력입니다
	scale	인
	price	30000
	cost	1000
	limit	5/0.5
	plus	2h
	pop		3d
	flag	noshowcase|human
	@@USE
		time	1h
		job		인력 파견업	times/job_man_time_rate
		scale	회
		action	작업하기
		price	0
		name	진열대를 1개로 줄이기
		info	진열대를 1개로 줄이기
		arg		nocount
		param	1
		func	_local_
			# ★진열대수변경
			# param1 변경후의 선반수
			my $oldcnt=$DT->{showcasecount};
			my $newcnt=$USE->{param1};
			$DT->{showcasecount}=$newcnt;

			if($oldcnt<$newcnt)
			{
				foreach ($oldcnt..$newcnt-1)
				{
					$DT->{showcase}[$_]=0;
					$DT->{price}[$_]=0;
				}
			}
			if($oldcnt>$newcnt)
			{
				splice(@{$DT->{showcase}},$newcnt);
				splice(@{$DT->{price}},$newcnt);
			}
			my $ret="진열대를 ".$DT->{showcasecount}."개로 변경했습니다";
			WriteLog(0,$DT->{id},$ret);
			WriteLog(3,0,$DT->{shopname}."의 진열대 수가 $DT->{showcasecount}개가 되었습니다");

			return $ret;
		_local_
	@@USE
		time	2h
		job		인력 파견업	times/job_man_time_rate
		price	10000
		name	진열대를 2개로 만들기
		info	진열대를 2개로 만들기
		func	_local_1
		arg		nocount
		param	2
	@@USE
		time	4h
		job		인력 파견업	times/job_man_time_rate
		price	50000
		name	진열대를 3개로 만들기
		info	진열대를 3개로 만들기
		func	_local_1
		arg		nocount
		param	3
			need	2	도우미
	@@USE
		time	6h
		job		인력 파견업	times/job_man_time_rate
		price	100000
		name	진열대를 4개로 만들기
		info	진열대를 4개로 만들기
		func	_local_1
		arg		nocount
		param	4
			need	2	도우미
	@@USE
		time	10h
		job		인력 파견업	times/job_man_time_rate
		price	200000
		name	진열대를 5개로 만들기
		info	진열대를 5개로 만들기
		func	_local_1
		arg		nocount
		param	5
			need	3	도우미
	@@USE
		time	12h
		job		인력 파견업	times/job_man_time_rate
		price	500000
		name	진열대를 6개로 만들기
		info	진열대를 6개로 만들기
		func	_local_1
		arg		nocount
		param	6
			need	3	도우미
	@@USE
		time	14h
		job		인력 파견업	times/job_man_time_rate
		price	1000000
		name	진열대를 7개로 만들기
		info	진열대를 7개로 만들기
		func	_local_1
		arg		nocount
		param	7
			need	4	도우미
	@@USE
		time	16h
		job		인력 파견업	times/job_man_time_rate
		price	2000000
		name	진열대를 8개로 만들기
		info	진열대를 8개로 만들기
		func	_local_1
		arg		nocount
		param	8
			need	5	도우미
	@@USE
		time	30m
		exp		1%
		exptime	10m
		job		인력 파견업	times/job_man_time_rate
		scale	회
		action	세척우
		name	그릇을 씻기
		info	더러운 그릇을 씻습니다
		func	lostman
		param	10
		ngmsg	그릇을 모두 깨뜨려 버렸습니다...
			use		10	더러운 그릇
			get		10	깨끗한 그릇	90%	그릇이 반짝반짝 깨끗해졌습니다
			get		10	상점력	02%
	@@USE
		time	1h
		exp		1%
		exptime	30m
		job		인력 파견업	times/job_man_time_rate
		scale	회
		action	설정하기
		name	설거지 기계에서 그릇을 씻기
		info	더러운 그릇을 설거지 기계에 넣습니다
		func	lostman
		param	50
		ngmsg	그릇을 모두 깨뜨려 버렸습니다...
			need		1	설거지 기계
			use		50	더러운 그릇
			get		50	깨끗한 그릇	95%	그릇이 반짝반짝 깨끗해졌습니다
			get		10	상점력	05%
	@@use
		time	10h
		exp		5%
		exptime	6h
		job		인력 파견업	times/job_man_time_rate
		action	광고 게재하기
		name	[신문]에광고 게재하기
		info	아래 양식에 문구를 입력하고 버튼을 누르면<br>[신문]에 광고가 게됩니다
		param	300
		arg		nocount|message100
			use	1	도우미
		func	_local_
			main::OutError('광고문을 입력해 주세요') if !$USE->{arg}->{message};
			my $ret;
			my $up=int($USE->{param1}*(2-$DT->{rank}/5000));
			$DT->{rank}+=$up;
			$DT->{rank}=10000 if $DT->{rank}>10000;

			$ret='[신문]에 광고가 게재되어 주목받았습니다. 인기 '.int($up/100)."% 상승";
			WriteLog(2,0,"[광고]".$USE->{arg}{message});
			WriteLog(0,$DT->{id},$ret);
			return $ret;
		_local_
	@@USE
		time	6h
		action	게시판 열기
		arg		nocount
		name	게시판 열기
		info	전문 직업 게시판을 엽니다
		func	_local_
			my $ret="";
			main::OutError('전문 직업 게시판은 열려 있지 않습니다') if ($DT->{job} eq '');
			$DT->{money}+=30000;
			$DT->{job}='';
			$ret='게시판을 열어 보조금 \30000을 받았습니다';
			WriteLog(0,$DT->{id},"게시판을 열어 보조금을 받았습니다");
			WriteLog(3,0,"전문 직업 게시판을 연 ".$DT->{shopname}."에게 상업조합에서 보조금이 지급된 것 같습니다");
			return $ret;
		_local_

@@ITEM
	no		8
	type	인재
	code	man-black
	name	비밀 공작원
	info	쌓아 둔 상점력을 사용해 뒷공작을 합니다
	scale	인
	price	50000
	cost	2500
	limit	2/0.2
	plus	2d
	flag	noshowcase|human
	@@use
		time	6h
		exp	5%
		exptime	4h
		job		뒤가업	times/job_black_time_rate
		scale	회
		action	동료를 호출부
		name	동료를 호출부
		info	동료가옴루확률은50%입니다
		ngmsg	동료는 옴않았습니다
		okmsg	동료가 찾아왔습니다
		arg		nocount
			get		1	비밀 공작원	50%
	@@use
		time	1h
		exp	1%
		exptime	30m
		job		뒤가업	times/job_black_time_rate
		scale	회
		action	만들기
		name	어둠우동 만들기
		info	있는 재료를 적당히 섞어 우동을 만들어 봅니다
		func	lostman
		param	50
		ngmsg	어둠우동만들기에실패했습니다‥
			use		10	더러운 그릇
			get		10	어둠우동	95%	어둠우동을 만들었습니다
			get		10	상점력	07%
	@@use
		time	1h
		exp	1%
		exptime	30m
		job		뒤가업	times/job_black_time_rate
		scale	회
		action	만들기
		name	어둠메밀국수 만들기
		info	있는 재료를 적당히 섞어 메밀국수를 만들어 봅니다
		func	lostman
		param	50
		ngmsg	어둠메밀국수만들기에실패했습니다‥
			use		10	더러운 그릇
			get		10	어둠메밀국수	95%	어둠메밀국수를 만들었습니다
			get		10	상점력	07%
	@@use
		time	4h
		exp	5%
		exptime	2h
		job		뒤가업	times/job_black_time_rate
		scale	회
		action	실행하다
		name	바꿔치기 작전을 실행하다
		info	다른 점포의 진열대의 상품을, 몰래 다른 상품과 바꿔치합니다
		arg		target|nocount
			use		1	비밀 공작원
			use		50	어둠우동
			use		50	어둠메밀국수
			use		10	상점력
		func	_local_
		# ★바꿔치기 작전을 실행하다
			my $cnt=int(rand(100))+1;
			my $ret="바꿔치기 작전은 실패했고, 점포의 인기가 내려갔습니다";
			if(rand(1000)<900)
			{
				if($DTS->{item}[@@ITEMNO"경보기"-1])
				{
					if(rand(1000)<200)
					{
					$DTS->{showcase}[0]=57; # 어둠메밀국수의 아이템번호
					$DTS->{price}[0]=20; # 어둠메밀국수의 가격
					$DTS->{item}[@@ITEMNO"어둠메밀국수"-1]+=$cnt;
					$DTS->{item}[@@ITEMNO"어둠메밀국수"-1]=2000 if $DTS->{item}[$itemno2-1]>2000;
					$ret="바꿔치기 작전은 성공했습니다";
					$DTS->{item}[@@ITEMNO"경보기"-1]--;
					WriteLog(2,0,$DTS->{shopname}."의진열대의 상품이어둠메밀국수에바꿔치기되어, 화가 난 점주가 경보기를 두드려 부쉈습니다");
					}
					elsif(rand(1000)<700)
					{
					$DT->{rank}-=int($DT->{rank}/3);
					$DTS->{item}[@@ITEMNO"경보기"-1]--;
					WriteLog(3,0,$DTS->{shopname}."에 침입한 ".$DT->{shopname}."의 비밀 공작원이 경보기를 파괴했지만 결국 붙잡혔습니다");
					}
					else
					{
					$DT->{rank}-=int($DT->{rank}/3);
					WriteLog(3,0,$DTS->{shopname}."의 경보기가 요란하게 울려, 침입해 있던 ".$DT->{shopname}."의 비밀 공작원이 붙잡혔습니다");
					}
				}
				else
				{
				$DTS->{showcase}[0]=45; # 어둠우동의 아이템 번호
				$DTS->{price}[0]=20; # 어둠우동의 가격
				$DTS->{item}[@@ITEMNO"어둠우동"-1]+=$cnt;
				$DTS->{item}[@@ITEMNO"어둠우동"-1]=2000 if $DTS->{item}[$itemno-1]>2000;
				$ret="바꿔치기 작전은 성공했습니다";
				WriteLog(2,0,$DTS->{shopname}."의진열대의 상품이어둠우동에바꿔치기되었습니다");
				}
			}
			else
			{
			$ret="바꿔치기 작전은 실패했습니다";
			WriteLog(3,0,$DTS->{shopname}."에 나타난 비밀 공작원이 왠지 아무것도 하지 않고 떠났습니다");
			}
			WriteLog(0,$DT->{id},$ret);
			return $ret;
			_local_
	@@use
		time	4h
		exp	10%
		job		뒤가업	times/job_black_time_rate
		scale	회
		action	좀도둑질을 하다
		name	좀도둑질을 하다
		info	경보기가 있는 점포는 위합니다!?
		arg		target|nocount
			use		50	상점력
		func	_local_
			# ★좀도둑질 작전(성공 때는 이벤트와 같은 메시지를 출력)

			my $ret="좀도둑질은 실패시, 점포의 인기가 내려갔습니다";
			if(rand(1000)<700)
			{
				if($DTS->{item}[@@ITEMNO"경보기"-1])
				{
					$DT->{rank}-=int($DT->{rank}/2);
					if(rand(1000)<700)
					{
						$DTS->{item}[@@ITEMNO"경보기"-1]--;
						WriteLog(3,0,$DT->{shopname}."의비밀 공작원이".$DTS->{shopname}."에 좀도둑질하러 침입해,$ITEM[@@ITEMNO"경보기"]->{name}을 파괴했지만 결국 붙잡혔습니다.");
					}
					else
					{
						WriteLog(3,0,$DT->{shopname}."의비밀 공작원이".$DTS->{shopname}."에 좀도둑질하러 침입했지만 실패했습니다.");
					}
				}
				else
				{
					my $manbiki_count=0;
					foreach my $idx (0..$DTS->{showcasecount}-1)
					{
						my $itemno=$DTS->{showcase}[$idx];
						if($itemno)
						{
							my $cnt=int($DTS->{item}[$itemno-1]/4);
							$cnt=$ITEM[$itemno]->{limit}-$DT->{item}[$itemno-1] if $DT->{item}[$itemno-1]+$cnt>$ITEM[$itemno]->{limit};
							$DTS->{item}[$itemno-1]-=$cnt;
							$DT->{item}[$itemno-1]+=$cnt;
							$manbiki_count+=$cnt*$DTS->{price}[$idx];
						}
					}
					$ret="좀도둑질은 성공했습니다";
					$ret="비밀 공작원은 마음이 바뀌어 좀도둑질을 그만두었습니다" if !$manbiki_count;
					WriteLog(2,0,$DTS->{shopname}."가 총액 ".GetMoneyString($manbiki_count)."의 좀도둑 피해를 입었습니다.") if $manbiki_count;
					WriteLog(2,0,$DTS->{shopname}."에 침입한 좀도둑은 아무것도 훔치지 못하고 도망쳤습니다.") if !$manbiki_count;
				}
			}
			else
			{
				$DT->{rank}-=int($DT->{rank}/3);
				WriteLog(3,0,$DT->{shopname}."의비밀 공작원이".$DTS->{shopname}."에 좀도둑질하러 침입했지만 실패했습니다.");
			}
			WriteLog(0,$DT->{id},$ret);
			return $ret;
		_local_
	@@use
		time	10h
		exp	10%
		job		뒤가업	times/job_black_time_rate
		scale	회
		action	나쁜 소문을 퍼뜨리기
		name	점포의 나쁜 소문을 퍼뜨리기
		info	근거 없는 소문을 퍼뜨려, 다른 점포의 인기를 내립니다
		arg		target|nocount
			use		1	비밀 공작원
			use		100	상점력
		func	_local_
			# ★나쁜 소문 퍼뜨리기 작전
			my $ret;
			if(rand(1000)<750)
			{
				$DTS->{rank}-=int($DTS->{rank}/4);
				$ret=$DTS->{shopname}.'의나쁜 소문 퍼뜨리기 작전이성공했습니다.';
				WriteLog(0,$DT->{id},$ret);
				WriteLog(3,0,$DTS->{shopname}.'의나쁜 소문이 퍼져 인기가 내려갔습니다.');
			}
			else
			{
				$DT->{rank}-=int($DT->{rank}/2);
				$ret=$DTS->{shopname}.'의나쁜 소문 퍼뜨리기 작전이실패했습니다';
				WriteLog(0,$DT->{id},$ret);
				WriteLog(3,0,$DT->{shopname}."의비밀 공작원이".$DTS->{shopname}.'의 나쁜 소문을 퍼뜨리려는 계획을 세우고 있었던 것 같습니다.');
			}
			return $ret;
			_local_
	@@use
		time	2h
		exp	10%
		job		뒤가업	times/job_black_time_rate
		action	해방하다
		name	상점력 해방하기
		info	상점력을 모두 해방해, 점포의 인기를 올립니다
		arg		nocount
		func	_local_
			main::OutError('상점력이 100 이상이어야 사용할 수 있습니다') if ($DT->{item}[@@ITEMNO"상점력"-1]<100);
			my $ret="";
			my $power;
			my $cnt=$DT->{item}[@@ITEMNO"상점력"-1];
			$power=$DT->{item}[@@ITEMNO"상점력"-1]*3;
			my $up=int($power*(2-$DT->{rank}/5000));

			$DT->{rank}+=$up;
			$DT->{rank}=10000 if $DT->{rank}>10000;
			$ret="상점력을 모두 해방했습니다(인기".int($up/100)."% 상승)";
			UseItem(@@ITEMNO"상점력",$cnt);
			WriteLog(0,$DT->{id},$ret);
			WriteLog(3,0,$DT->{shopname}."가 상점력을 모두 해방했습니다.");
			return $ret;
			_local_
	@@USE
		time	0m
		action	시간 조작하기
		scale	회
		name	시간 조작하기
		info	성공하면 시간을 되돌릴 수 있습니다!
			use		2	비밀 공작원
		arg		nocount
		func	_local_
			# ★보유하고 시간증가
			my $ret;
			my $cnt=int(rand(6))+1;

			if(rand(1000)<100)
			{
				$ret='시간조작은 실패했습니다';
				WriteLog(3,0,$DT->{shopname}.'의비밀 공작원이, 시간조작을 하게지했은 것 같습니다.');
				AddItem(8,1,'비밀 공작원의1인이, 때공의 할레목에서 돌아옵니다했습니다');
				WriteLog(0,$DT->{id},'시간조작은 실패했습니다');
			}
			else
			{
				$DT->{time}-=3600*($cnt);
				$DT->{user}->{black}+=1;
				$ret='시간조작은 성공했습니다 (+'.($cnt).'시간)';
				WriteLog(3,0,$DT->{shopname}.'의비밀 공작원이, 시간 조작을 시도한 것 같습니다.');
				WriteLog(0,$DT->{id},'시간조작의 결과, 보유하고 시간이추가했습니다');
			}
			return $ret;
		_local_
	@@USE
		time	6h
		action	뒷공작의 푸로 가 됨
		arg		nocount
		name	뒷공작의 푸로 가 됨
		info	지금까지의 경험을 살려, 뒷공작의 전문가가 됩니다
			needexp		20%
		func	_local_
			my $ret="";
			main::OutError('이미 뒷공작 전문가입니다') if ($DT->{job} eq 'black');
			$DT->{job} = 'black';
			$ret="뒷공작 전문가가 되었습니다";
			WriteLog(0,$DT->{id},$ret);
			return $ret;
		_local_

@@ITEM
	no		9
	type	농산물
	code	riku-tamagoa
	name	알
	info	영양가가 높은 식품입니다
	scale	개
	price	100
	cost	10
	limit	5000/50
	base	2500/10000
	plus	5h
	pop	40m
	point	20%
	@@USE
		time	1m
		action	퇴비통에 넣기
		name	퇴비통에 넣기
		info	오래된 식품을 퇴비통에 넣고, 퇴비를 만듭니다
		ngmsg	퇴비 만들기에실패했습니다
			use		1	알
			get		10	퇴비	15%	상질 퇴비가 만들어졌습니다

@@ITEM
	no		10
	type	농산물
	code	riku-tamagob
	name	부화 대기 중인 알
	info	영양가가 높은 식품입니다
	scale	개
	price	100
	cost	50
	limit	50/0
	pop	10d
	funct	_local_
		my($ITEM,@DT)=@_;
		my $gabirth_per_day=3; # 1일에거위가3날개산된같은 확률(?)의 설정
		my $nibirth_per_day=30; # 1일에닭가30날개산된같은 확률(?)의 설정
		my $val =1; # 한 번에산된기본수

		my $gabirth_rate=$gabirth_per_day && (86400/$gabirth_per_day); # 0에서 할루의 를저지
		my $nibirth_rate=$nibirth_per_day && (86400/$nibirth_per_day);
		foreach my $DT (@DT)
		{
			next if !$DT->{item}[@@ITEMNO"부화 대기 중인 알"-1];
			if(rand($gabirth_rate)<$TIMESPAN) # 1점포에 관련'1일에$gabirth_per_day 회' 확률로 조건이진짜가 됨(하즈…)
			{
				UseItemSub(@@ITEMNO"부화 대기 중인 알",$val,$DT);
				AddItemSub(@@ITEMNO"거위",$val,$DT);
				WriteLog(0,$DT->{id},'무려!알에서 거위가 태어났습니다');
			}
			if(rand($nibirth_rate)<$TIMESPAN)
			{
				UseItemSub(@@ITEMNO"부화 대기 중인 알",$val,$DT);
				AddItemSub(@@ITEMNO"닭",$val,$DT);
			}
		}
	_local_

@@ITEM
	no		11
	type	농산물
	code	riku-age
	name	유부
	info	키츠네 우동과 키츠네 메밀국수에 자주 쓰이는 유부입니다
	scale	매
	price	300
	cost	10
	limit	10000/10
	base	500/2000
	plus	5h
	pop	40m
	point	20%
	@@USE
		time	1m
		action	퇴비통에 넣기
		name	퇴비통에 넣기
		info	오래된 식품을 퇴비통에 넣고, 퇴비를 만듭니다
		ngmsg	퇴비 만들기에실패했습니다
			use		1	유부
			get		10	퇴비	20%	상질 퇴비가 만들어졌습니다

@@ITEM
	no		12
	type	농산물
	code	riku-negi
	name	파
	info	우동이나 메밀국수에 빠질 수 없는 양념입니다
	scale	파악
	price	200
	limit	5000/10
	base	500/2000
	plus	3h
	pop	1h
	point	10%
	@@USE
		time	1m
		action	퇴비통에 넣기
		name	퇴비통에 넣기
		info	오래된 식품을 퇴비통에 넣고, 퇴비를 만듭니다
		ngmsg	퇴비 만들기에실패했습니다
			use		1	파
			get		10	퇴비	25%	상질 퇴비가 만들어졌습니다

@@ITEM
	no		13
	type	농산물
	code	riku-komugi
	name	밀가루
	info	우동이나 튀김의 재료가 됩니다
	scale	kg
	price	500
	cost	10
	limit	1000/10
	base	500/1000
	plus	4h
	pop	4h
	point	30%
	@@USE
		time	1m
		action	퇴비통에 넣기
		name	퇴비통에 넣기
		info	오래된 식품을 퇴비통에 넣고, 퇴비를 만듭니다
		ngmsg	퇴비 만들기에실패했습니다
			use		1	밀가루
			get		10	퇴비	30%	상질 퇴비가 만들어졌습니다

@@ITEM
	no		14
	type	농산물
	code	riku-soba
	name	메밀국수가루
	info	메밀국수의 재료가 됩니다
	scale	kg
	price	500
	cost	10
	limit	1000/10
	base	500/1000
	plus	4h
	pop	4h
	point	30%
	@@USE
		time	1m
		action	퇴비통에 넣기
		name	퇴비통에 넣기
		info	오래된 식품을 퇴비통에 넣고, 퇴비를 만듭니다
		ngmsg	퇴비 만들기에실패했습니다
			use		1	메밀국수가루
			get		10	퇴비	30%	상질 퇴비가 만들어졌습니다

@@ITEM
	no		15
	type	농산물
	code	riku-tougarasi
	name	고추
	info	하카타 명물 명란젓의 양념에 쓰입니다
	scale	kg
	price	800
	limit	1000/10
	base	500/1000
	plus	-1d
	pop	5h
	@@USE
		time	1m
		action	퇴비통에 넣기
		name	퇴비통에 넣기
		info	오래된 식품을 퇴비통에 넣고, 퇴비를 만듭니다
		ngmsg	퇴비 만들기에실패했습니다
			use		1	고추
			get		10	퇴비	35%	상질 퇴비가 만들어졌습니다

@@ITEM
	no		16
	type	농산물
	code	riku-daizu
	name	대두
	info	가공하면 유부를 만들 수 있습니다
	scale	kg
	price	400
	limit	1500/20
	base	1000/2000
	plus	-1d
	pop	5h
	@@USE
		time	1m
		action	퇴비통에 넣기
		name	퇴비통에 넣기
		info	오래된 식품을 퇴비통에 넣고, 퇴비를 만듭니다
		ngmsg	퇴비 만들기에실패했습니다
			use		1	대두
			get		10	퇴비	35%	상질 퇴비가 만들어졌습니다

@@ITEM
	no		17
	type	농산물
	code	riku-toukibi
	name	옥수수
	info	가축의 먹이로도 쓰입니다
	scale	kg
	price	600
	limit	1000/10
	base	500/1000
	plus	-1d
	pop	4h
	point	50%
	@@USE
		time	1m
		action	퇴비통에 넣기
		name	퇴비통에 넣기
		info	오래된 식품을 퇴비통에 넣고, 퇴비를 만듭니다
		ngmsg	퇴비 만들기에실패했습니다
			use		1	옥수수
			get		10	퇴비	35%	상질 퇴비가 만들어졌습니다

@@ITEM
	no		18
	type	농산물
	code	riku-toryuhu
	name	트러플
	info	돼지가 찾아낸 고급 버섯입니다
	scale	개
	price	2000
	limit	500
	base	50/200
	plus	-1d
	pop	8h
	@@USE
		time	1m
		action	퇴비통에 넣기
		name	퇴비통에 넣기
		info	오래된 식품을 퇴비통에 넣고, 퇴비를 만듭니다
		ngmsg	퇴비 만들기에실패했습니다
			use		1	트러플
			get		10	퇴비	35%	상질 퇴비가 만들어졌습니다

@@ITEM
	no		19
	type	농산물
	code	riku-foagura
	name	푸아그라
	info	살찌운 거위의 간입니다
	scale	개
	price	2000
	limit	500
	base	50/200
	plus	-1d
	pop	8h
	@@USE
		time	1m
		action	퇴비통에 넣기
		name	퇴비통에 넣기
		info	오래된 식품을 퇴비통에 넣고, 퇴비를 만듭니다
		ngmsg	퇴비 만들기에실패했습니다
			use		1	푸아그라
			get		10	퇴비	35%	상질 퇴비가 만들어졌습니다

@@ITEM
	no		20
	type	농산물
	code	riku-niwatori
	name	닭
	info	알을 낳게 하려면 먹이가 필요합니다
	scale	날개
	price	5000
	limit	30/3
	base	30/300
	plus	1d
	pop	10d
	@@USE
		time	30m
		action	교환하기
		scale	회
		name	거위와 교환하기
		info	양성장에서 닭을 거위와 교환합니다
		okmsg	거위를 구했습니다
			use		2	닭
			get		1	거위
	@@USE
		time	30m
		action	교환하기
		scale	회
		name	돼지와 교환하기
		info	양성장에서 닭을 돼지와 교환합니다
		okmsg	돼지를 구했습니다
			use		3	닭
			get		1	돼지

@@ITEM
	no		21
	type	농산물
	code	riku-gatyou
	name	거위
	info	먹이를 듬뿍 주고 키워 봅시다
	scale	날개
	price	7500
	limit	20/2
	base	20/200
	plus	-1d
	pop	10d

@@ITEM
	no		22
	type	농산물
	code	riku-buta
	name	돼지
	info	돌보기를 잘하면 보답을 받을 수도 있습니다
	scale	머리
	price	10000
	limit	20/2
	plus	1d
	pop	10d

@@ITEM
	no		23
	type	해산물
	code	umi-ebi
	name	새우
	info	살이 통통한 근해 새우입니다
	scale	마리
	price	100
	limit	5000/20
	base	1000/4000
	plus	3h
	pop	1h
	point	10%
	@@USE
		time	1m
		action	퇴비통에 넣기
		name	퇴비통에 넣기
		info	오래된 식품을 퇴비통에 넣고, 퇴비를 만듭니다
		ngmsg	퇴비 만들기에실패했습니다
			use		1	새우
			get		10	퇴비	25%	상질 퇴비가 만들어졌습니다

@@ITEM
	no		24
	type	해산물
	code	umi-wakame
	name	미역
	info	미네랄이 풍부한 해조류입니다
	scale	kg
	price	200
	limit	2500/10
	base	100/2000
	plus	4h
	pop	1h
	point	10%
	@@USE
		time	1m
		action	퇴비통에 넣기
		name	퇴비통에 넣기
		info	오래된 식품을 퇴비통에 넣고, 퇴비를 만듭니다
		ngmsg	퇴비 만들기에실패했습니다
			use		1	미역
			get		10	퇴비	30%	상질 퇴비가 만들어졌습니다

@@ITEM
	no		25
	type	해산물
	code	umi-kama
	name	어묵
	info	핑크의 어묵입니다
	scale	본
	price	300
	limit	1500/10
	plus	4h
	pop	90m
	point	30%
	@@USE
		time	1m
		action	퇴비통에 넣기
		name	퇴비통에 넣기
		info	오래된 식품을 퇴비통에 넣고, 퇴비를 만듭니다
		ngmsg	퇴비 만들기에실패했습니다
			use		1	어묵
			get		10	퇴비	30%	상질 퇴비가 만들어졌습니다

@@ITEM
	no		26
	type	해산물
	code	umi-maruten
	name	마루텐
	info	두툼한 마루텐입니다
	scale	매
	price	500
	limit	1000/10
	plus	6h
	pop	150m
	point	50%
	@@USE
		time	1m
		action	퇴비통에 넣기
		name	퇴비통에 넣기
		info	오래된 식품을 퇴비통에 넣고, 퇴비를 만듭니다
		ngmsg	퇴비 만들기에실패했습니다
			use		1	마루텐
			get		10	퇴비	35%	상질 퇴비가 만들어졌습니다

@@ITEM
	no		27
	type	해산물
	code	umi-ebiten
	name	새우튀김
	info	바삭하게 튀긴 새우튀김입니다
	scale	마리
	price	600
	limit	1000
	plus	-1h
	pop	180m
	point	50%
	@@USE
		time	1m
		action	퇴비통에 넣기
		name	퇴비통에 넣기
		info	오래된 식품을 퇴비통에 넣고, 퇴비를 만듭니다
		ngmsg	퇴비 만들기에실패했습니다
			use		1	새우튀김
			get		10	퇴비	35%	상질 퇴비가 만들어졌습니다

@@ITEM
	no		28
	type	해산물
	code	umi-suke
	name	명태
	info	명란젓의 원료가 되는 생선입니다. 알은 가공할 수 있습니다
	scale	마리
	price	1000
	limit	1000/10
	base	500/5000
	plus	5h
	pop	9h
	@@USE
		time	1m
		action	퇴비통에 넣기
		name	퇴비통에 넣기
		info	오래된 식품을 퇴비통에 넣고, 퇴비를 만듭니다
		ngmsg	퇴비 만들기에실패했습니다
			use		1	명태
			get		10	퇴비	50%	상질 퇴비가 만들어졌습니다

@@ITEM
	no		29
	type	해산물
	code	umi-eso
	name	에소
	info	마루텐의 원료가 되는 생선입니다
	scale	마리
	price	2000
	limit	500/5
	base	250/5000
	plus	7h
	pop	18h
	@@USE
		time	1m
		action	퇴비통에 넣기
		name	퇴비통에 넣기
		info	오래된 식품을 퇴비통에 넣고, 퇴비를 만듭니다
		ngmsg	퇴비 만들기에실패했습니다
			use		1	에소
			get		10	퇴비	50%	상질 퇴비가 만들어졌습니다

@@ITEM
	no		32
	type	해산물
	code	umi-katuo
	name	다시마
	info	고급우동(메밀국수)의 이고만들기에결여카세않습니다
	scale	마리
	price	2000
	limit	500
	base	250/5000
	plus	-1m
	pop	18h
	point	200%
	@@USE
		time	1m
		action	퇴비통에 넣기
		name	퇴비통에 넣기
		info	오래된 식품을 퇴비통에 넣고, 퇴비를 만듭니다
		ngmsg	퇴비 만들기에실패했습니다
			use		1	다시마
			get		10	퇴비	50%	상질 퇴비가 만들어졌습니다

@@ITEM
	no		33
	type	해산물
	code	umi-tyouzame
	name	철갑상어
	info	바다의 보물와 호출바됨물고기입니다
	scale	마리
	price	8000
	limit	100
	base	250/5000
	plus	-1m
	pop	4d
	point	200%
	@@USE
		time	1m
		action	퇴비통에 넣기
		name	퇴비통에 넣기
		info	오래된 식품을 퇴비통에 넣고, 퇴비를 만듭니다
		ngmsg	퇴비 만들기에실패했습니다
			use		1	철갑상어
			get		10	퇴비	80%	상질 퇴비가 만들어졌습니다

@@ITEM
	no		30
	type	해산물
	code	umi-mentai
	name	명란젓
	info	명태 알을 고추 양념에 절인 하카타 명물입니다
	scale	kg
	price	3000
	limit	300
	base	50/200
	plus	-1d
	pop	12h
	@@USE
		time	1m
		action	퇴비통에 넣기
		name	퇴비통에 넣기
		info	오래된 식품을 퇴비통에 넣고, 퇴비를 만듭니다
		ngmsg	퇴비 만들기에실패했습니다
			use		1	명란젓
			get		10	퇴비	35%	상질 퇴비가 만들어졌습니다

@@ITEM
	no		31
	type	해산물
	code	umi-kyabia
	name	캐비아
	info	검정이다이나 와 호출바되어희귀됩니다, 철갑상어의 알입니다
	scale	kg
	price	2000
	limit	500
	base	50/200
	plus	-1d
	pop	8h
	@@USE
		time	1m
		action	퇴비통에 넣기
		name	퇴비통에 넣기
		info	오래된 식품을 퇴비통에 넣고, 퇴비를 만듭니다
		ngmsg	퇴비 만들기에실패했습니다
			use		1	캐비아
			get		10	퇴비	35%	상질 퇴비가 만들어졌습니다

@@ITEM
	no		34
	type	우동
	code	udon-su
	name	기본 우동
	info	담백한 맛의 단순우동
	price	500
	limit	1000/0
	pop	75m
	point	40%
	@@USE
		time	5m
		action	먹기
		name	먹기
		info	따뜻한 우동을 먹습니다
		okmsg	아주 맛있게 완성되었습니다
			use		1	기본 우동
			get		1	더러운 그릇
			get		10	상점력	20%

@@ITEM
	no		35
	type	우동
	code	udon-wakame
	name	미역우동
	info	윤기 나는 건강 미역우동
	price	600
	limit	1000/0
	pop	90m
	point	50%
	@@USE
		time	5m
		action	먹기
		name	먹기
		info	따뜻한 우동을 먹습니다
		okmsg	아주 맛있게 완성되었습니다
			use		1	미역우동
			get		1	더러운 그릇
			get		10	상점력	20%

@@ITEM
	no		36
	type	우동
	code	udon-kitune
	name	키츠네우동
	info	국물이 잘 밴 유부가 일품인 우동입니다
	price	800
	limit	1000/0
	pop	120m
	point	60%
	@@USE
		time	5m
		action	먹기
		name	먹기
		info	따뜻한 우동을 먹습니다
		okmsg	아주 맛있게 완성되었습니다
			use		1	키츠네우동
			get		1	더러운 그릇
			get		10	상점력	20%

@@ITEM
	no		37
	type	우동
	code	udon-maruten
	name	마루텐우동
	info	먹음직한 마루텐이 올라간 우동
	price	1000
	limit	1000/0
	pop	120m
	point	75%
	@@USE
		time	5m
		action	먹기
		name	먹기
		info	따뜻한 우동을 먹습니다
		okmsg	아주 맛있게 완성되었습니다
			use		1	마루텐우동
			get		1	더러운 그릇
			get		10	상점력	20%

@@ITEM
	no		38
	type	우동
	code	udon-ebiten
	name	새우튀김우동
	info	바삭하게 튀긴 새우튀김을 올린 우동입니다
	price	2000
	limit	500/0
	pop	240m
	@@USE
		time	5m
		action	먹기
		name	먹기
		info	따뜻한 우동을 먹습니다
		okmsg	아주 맛있게 완성되었습니다
			use		1	새우튀김우동
			get		1	더러운 그릇
			get		10	상점력	20%

@@ITEM
	no		39
	type	우동
	code	udon-zanmai
	name	우동 곱빼기
	info	추천우동삼종 설정
	scale	설정
	price	5000
	limit	200
	pop	8h
	point	500%
	@@USE
		time	5m
		action	먹기
		name	먹기
		info	따뜻한 우동을 먹습니다
		okmsg	아주 맛있게 완성되었습니다
			use		1	우동 곱빼기
			get		3	더러운 그릇
			get		10	상점력	30%

@@ITEM
	no		40
	type	우동
	code	udon-kyabia
	name	캐비아우동
	info	세계삼대희귀맛우동의 하나
	price	7500
	limit	120/0
	pop	12h
	@@USE
		time	5m
		action	먹기
		name	먹기
		info	따뜻한 우동을 먹습니다
		okmsg	깜짝 놀랄 만큼 맛있게 완성되었습니다
			use		1	캐비아우동
			get		1	더러운 그릇
			get		10	상점력	50%

@@ITEM
	no		41
	type	우동
	code	udon-toryuhu
	name	트러플우동
	info	세계삼대희귀맛우동의 하나
	price	8000
	limit	120/0
	pop	13h
	@@USE
		time	5m
		action	먹기
		name	먹기
		info	따뜻한 우동을 먹습니다
		okmsg	깜짝 놀랄 만큼 맛있게 완성되었습니다
			use		1	트러플우동
			get		1	더러운 그릇
			get		10	상점력	50%

@@ITEM
	no		42
	type	우동
	code	udon-foagura
	name	푸아그라우동
	info	세계삼대희귀맛우동의 하나
	price	10000
	limit	100/0
	pop	15h
	@@USE
		time	5m
		action	먹기
		name	먹기
		info	따뜻한 우동을 먹습니다
		okmsg	깜짝 놀랄 만큼 맛있게 완성되었습니다
			use		1	푸아그라우동
			get		1	더러운 그릇
			get		10	상점력	50%

@@ITEM
	no		43
	type	우동
	code	udon-hakata
	name	하카타우동
	info	하카타식 특제 우동
	price	20000
	limit	50
	pop	25h
	point	200%
	@@USE
		time	5m
		action	먹기
		name	먹기
		info	따뜻한 우동을 먹습니다
		okmsg	깜짝 놀랄 만큼 맛있게 완성되었습니다
			use		1	하카타우동
			get		1	더러운 그릇
			get		10	상점력	70%

@@ITEM
	no		44
	type	우동
	code	udon-origi
	name	오리지널 우동
	info	정성을 담아 개발한 오리지널 우동입니다
	price	50000
	limit	20/0
	pop	60h
	point	200%
	@@USE
		time	5m
		action	먹기
		name	먹기
		info	따뜻한 우동을 먹습니다
		okmsg	꿈처럼 맛있게 완성되었습니다
			use		1	오리지널 우동
			get		1	더러운 그릇
			get		20	상점력	50%

@@ITEM
	no		45
	type	우동
	code	udon-yami
	name	어둠우동
	info	비밀 공작원이 만든 수상한 우동입니다
	price	100
	limit	5000/0
	pop	1h
	point	-10%
	@@USE
		time	5m
		action	먹기
		name	먹기
		info	따뜻한 우동을 먹습니다
		okmsg	세상에 이렇게 맛있는 음식은 없습니다
			use		1	어둠우동
			get		1	더러운 그릇

@@ITEM
	no		46
	type	메밀국수
	code	soba-kake
	name	기본 메밀국수
	info	담백한 맛의 단순메밀국수
	price	500
	limit	1000/0
	pop	75m
	point	40%
	@@USE
		time	5m
		action	먹기
		name	먹기
		info	따뜻한 메밀국수를 먹습니다
		okmsg	아주 맛있게 완성되었습니다
			use		1	기본 메밀국수
			get		1	더러운 그릇
			get		10	상점력	20%

@@ITEM
	no		47
	type	메밀국수
	code	soba-wakame
	name	미역메밀국수
	info	윤기 나는 건강 미역메밀국수
	price	600
	limit	1000/0
	pop	90m
	point	50%
	@@USE
		time	5m
		action	먹기
		name	먹기
		info	따뜻한 메밀국수를 먹습니다
		okmsg	아주 맛있게 완성되었습니다
			use		1	미역메밀국수
			get		1	더러운 그릇
			get		10	상점력	20%

@@ITEM
	no		48
	type	메밀국수
	code	soba-kitune
	name	키츠네메밀국수
	info	국물이 잘 밴 유부가 일품인 메밀국수입니다
	price	800
	limit	1000/0
	pop	120m
	point	60%
	@@USE
		time	5m
		action	먹기
		name	먹기
		info	따뜻한 메밀국수를 먹습니다
		okmsg	아주 맛있게 완성되었습니다
			use		1	키츠네메밀국수
			get		1	더러운 그릇
			get		10	상점력	20%

@@ITEM
	no		49
	type	메밀국수
	code	soba-maruten
	name	마루텐메밀국수
	info	먹음직한 마루텐이 올라간 메밀국수
	price	1000
	limit	1000/0
	pop	120m
	point	75%
	@@USE
		time	5m
		action	먹기
		name	먹기
		info	따뜻한 메밀국수를 먹습니다
		okmsg	아주 맛있게 완성되었습니다
			use		1	마루텐메밀국수
			get		1	더러운 그릇
			get		10	상점력	20%

@@ITEM
	no		50
	type	메밀국수
	code	soba-ebiten
	name	새우튀김메밀국수
	info	바삭하게 튀긴 새우튀김을 올린 메밀국수입니다
	price	2000
	limit	500/0
	pop	240m
	@@USE
		time	5m
		action	먹기
		name	먹기
		info	따뜻한 메밀국수를 먹습니다
		okmsg	아주 맛있게 완성되었습니다
			use		1	새우튀김메밀국수
			get		1	더러운 그릇
			get		10	상점력	20%

@@ITEM
	no		51
	type	메밀국수
	code	soba-zanmai
	name	메밀국수 곱빼기
	info	추천메밀국수삼종 설정
	scale	설정
	price	5000
	limit	200
	pop	8h
	point	500%
	@@USE
		time	5m
		action	먹기
		name	먹기
		info	따뜻한 메밀국수를 먹습니다
		okmsg	아주 맛있게 완성되었습니다
			use		1	메밀국수 곱빼기
			get		3	더러운 그릇
			get		10	상점력	30%

@@ITEM
	no		52
	type	메밀국수
	code	soba-kyabia
	name	캐비아메밀국수
	info	세계삼대희귀맛메밀국수의 하나
	price	7500
	limit	120/0
	pop	12h
	@@USE
		time	5m
		action	먹기
		name	먹기
		info	따뜻한 메밀국수를 먹습니다
		okmsg	깜짝 놀랄 만큼 맛있게 완성되었습니다
			use		1	캐비아메밀국수
			get		1	더러운 그릇
			get		10	상점력	50%

@@ITEM
	no		53
	type	메밀국수
	code	soba-toryuhu
	name	트러플메밀국수
	info	세계삼대희귀맛메밀국수의 하나
	price	8000
	limit	120/0
	pop	13h
	@@USE
		time	5m
		action	먹기
		name	먹기
		info	따뜻한 메밀국수를 먹습니다
		okmsg	깜짝 놀랄 만큼 맛있게 완성되었습니다
			use		1	트러플메밀국수
			get		1	더러운 그릇
			get		10	상점력	50%

@@ITEM
	no		54
	type	메밀국수
	code	soba-foagura
	name	푸아그라메밀국수
	info	세계삼대희귀맛메밀국수의 하나
	price	10000
	limit	100/0
	pop	15h
	@@USE
		time	5m
		action	먹기
		name	먹기
		info	따뜻한 메밀국수를 먹습니다
		okmsg	깜짝 놀랄 만큼 맛있게 완성되었습니다
			use		1	푸아그라메밀국수
			get		1	더러운 그릇
			get		10	상점력	50%

@@ITEM
	no		55
	type	메밀국수
	code	soba-hakata
	name	하카타메밀국수
	info	하카타식 특제 메밀국수
	price	20000
	limit	50
	pop	25h
	point	200%
	@@USE
		time	5m
		action	먹기
		name	먹기
		info	따뜻한 메밀국수를 먹습니다
		okmsg	깜짝 놀랄 만큼 맛있게 완성되었습니다
			use		1	하카타메밀국수
			get		1	더러운 그릇
			get		10	상점력	70%

@@ITEM
	no		56
	type	메밀국수
	code	soba-origi
	name	오리지널 메밀국수
	info	정성을 담아 개발한 오리지널 메밀국수입니다
	price	50000
	limit	20/0
	pop	60h
	point	200%
	@@USE
		time	5m
		action	먹기
		name	먹기
		info	따뜻한 메밀국수를 먹습니다
		okmsg	꿈처럼 맛있게 완성되었습니다
			use		1	오리지널 메밀국수
			get		1	더러운 그릇
			get		20	상점력	50%

@@ITEM
	no		57
	type	메밀국수
	code	soba-yami
	name	어둠메밀국수
	info	비밀 공작원이 만든 수상한 메밀국수입니다
	price	100
	limit	5000/0
	pop	1h
	point	-10%
	@@USE
		time	5m
		action	먹기
		name	먹기
		info	따뜻한 메밀국수를 먹습니다
		okmsg	세상에 이렇게 맛있는 음식은 없습니다
			use		1	어둠메밀국수

@@ITEM
	no		58
	type	도구
	code	tool-tikara
	name	상점력
	info	위급할 때 진가를 발휘할 수 있습니다[상점력]
	scale	력
	price	0
	limit	1000/0
	pop		0
	flag	noshowcase|norequest|notrash
	@@use
		time	10m
		scale	회
		action	상점력 받기
		name	상점력 받기
		info	기합을 넣어 상점력을 온몸으로 받아 봅니다
		arg		nocount
			use		500	상점력
		func	_local_
			my $ret='기합이 통했는지 상점력이 예상 밖의 힘을 발휘한 것 같습니다';

			if ((rand(1000)<20) && !$DT->{item}[@@ITEMNO"오리지널 우동 레시피"-1])
			{
				AddItem(@@ITEMNO"오리지널 우동 레시피",1,"돌풍에 날아온 종잇조각을 자세히 보니, 무려 어딘가의 가게의 '오리지널 우동 레시피'였습니다");
				WriteLog(0,$DT->{id},'오리지널 우동 레시피를 구했습니다');
			}
			elsif((rand(1000)<20) && !$DT->{item}[@@ITEMNO"오리지널 메밀국수 레시피"-1])
			{
				AddItem(@@ITEMNO"오리지널 메밀국수 레시피",1,"돌풍에 날아온 종잇조각을 자세히 보니, 무려 어딘가의 가게의 '오리지널 메밀국수 레시피'였습니다");
				WriteLog(0,$DT->{id},'오리지널 메밀국수 레시피를 구했습니다');
			}
			elsif ((rand(1000)<100) && ($DT->{item}[@@ITEMNO"돼지"-1]<=10))
			{
				AddItem(@@ITEMNO"돼지",10,"야생 돼지 무리가 점포에 뛰어들어 왔습니다");
				WriteLog(0,$DT->{id},'돼지를 구했습니다');
			}
			elsif ((rand(1000)<100) && ($DT->{item}[@@ITEMNO"거위"-1]<=10))
			{
				AddItem(@@ITEMNO"거위",10,"야생 거위 무리가 점포에 뛰어들어 왔습니다");
				WriteLog(0,$DT->{id},'거위를 구했습니다');
			}
			elsif ((rand(1000)<100) && ($DT->{item}[@@ITEMNO"고추"-1]<=500))
			{
				AddItem(@@ITEMNO"고추",500,"먼 친척이 고추의 소포를 보내 왔습니다");
				WriteLog(0,$DT->{id},'고추를 구했습니다');
			}
			elsif((rand(1000)<100) && $DT->{item}[@@ITEMNO"닭"-1] && ($DT->{item}[@@ITEMNO"알"-1]<=2700))
			{
				AddItem(@@ITEMNO"알",$DT->{item}[@@ITEMNO"닭"-1]*10,"사육 중인 닭이 일제히 알을 10개씩 낳았습니다");
				WriteLog(0,$DT->{id},'알을 구했습니다');
			}
			elsif((rand(1000)<100) && $DT->{item}[@@ITEMNO"돼지"-1] && ($DT->{item}[@@ITEMNO"트러플"-1]<=50))
			{
				AddItem(@@ITEMNO"트러플",$DT->{item}[@@ITEMNO"돼지"-1]*5,"사육 중인 돼지가 모두 트러플을 5개씩 물고 왔습니다");
				WriteLog(0,$DT->{id},'트러플을 구했습니다');
			}
			elsif ((rand(1000)<100) && ($DT->{item}[@@ITEMNO"비밀 공작원"-1]<2))
			{
				AddItem(@@ITEMNO"비밀 공작원",1,"비밀 공작원이 몰래 점포에 들어와 고용해 달라고 말했습니다");
				WriteLog(0,$DT->{id},'비밀 공작원을 구했습니다');
			}
			elsif((rand(1000)<20) && $DT->{user}->{udon} && ($DT->{user}->{udon}ne'톤누라우동') && ($DT->{user}->{udon}ne'하이파구레토UDON'))
			{
				if (rand(1000)<500)
				{
					$ret.="<br>문득 떠올라, 개발한 오리지널 우동의 이름을 '톤누라우동'으로 변경했습니다<br>";
					$DT->{user}->{udon}='톤누라우동';
				}
				else
				{
					$ret.="<br>문득 떠올라, 개발한 오리지널 우동의 이름을 '하이파구레토UDON'으로 변경했습니다<br>";
					$DT->{user}->{udon}='하이파구레토UDON';
				}
				WriteLog(0,$DT->{id},'오리지널 우동의 이름을 변경했습니다');
				WriteLog(3,0,$DT->{shopname}.'의 점주가 상점력을 받아 영감을 얻어, 오리지널 우동의 이름을 변경한 것 같습니다');
			}
			elsif((rand(1000)<20) && $DT->{user}->{soba} && ($DT->{user}->{soba}ne'사랑의 가난부족탈출메밀국수') && ($DT->{user}->{soba}ne'누라리횬소바'))
			{
				if (rand(1000)<500)
				{
					$ret.="<br>문득 떠올라, 개발한 오리지널 메밀국수의 이름을 '사랑의 가난부족탈출메밀국수'로 변경했습니다<br>";
					$DT->{user}->{soba}='사랑의 가난부족탈출메밀국수';
				}
				else
				{
					$ret.="<br>문득 떠올라, 개발한 오리지널 메밀국수의 이름을 '누라리횬소바'로 변경했습니다<br>";
					$DT->{user}->{soba}='누라리횬소바';
				}
				WriteLog(0,$DT->{id},'오리지널 메밀국수의 이름을 변경했습니다');
				WriteLog(3,0,$DT->{shopname}.'의 점주가 상점력을 받아 영감을 얻어, 오리지널 메밀국수의 이름을 변경한 것 같습니다');
			}
			else
			{
				$ret.='<br>상점력으로 시간 에너지가 증폭되어 활동할 수 있는 시간이 늘어났습니다';
				my $cnt=int(rand(6))+5;
				$DT->{time}-=3600*($cnt);
				$ret.='(+'.($cnt).'시간)<br>';
				WriteLog(0,$DT->{id},'상점력을 온몸으로 받은 결과, 보유 시간이 늘어났습니다');
			}
			return $ret;
		_local_

@@ITEM
	no		59
	type	도구
	code	tool-huku
	name	복권보조권
	info	5매에서1회추첨이할 수 있습니다
	scale	매
	price	0
	limit	1000/0
	pop		0
	@@USE
		time	5m
		action	복권를 하다
		name	복권를 하다
		info	모음했습니다복권보조권에서 복권를 합니다
		scale	회
			use		5	복권보조권
		func	_local_
			# ★복권
			my $ret;
			my $hit1=0; #구하루특등경품의 개수
			my $hit2=0; #구하루1등경품의 개수
			my $hit3=0; #구하루2등경품의 개수
			my $hit4=0; #구하루3등경품의 개수
			my $hit5=0; #구하루4등경품의 개수
			my $hit6=0; #구하루5등경품의 개수
			my $hit7=0; #구하루유감상의 개수

			foreach(1..$count)
			{
				if(rand(1000)<1)
				{
					$hit1+=1;
				}
				elsif(rand(1000)<3)
				{
					$hit2+=1;
				}
				elsif(rand(1000)<10)
				{
					$hit3+=1;
				}
				elsif(rand(1000)<50)
				{
					$hit4+=1;
				}
				elsif(rand(1000)<100)
				{
					$hit5+=1;
				}
				elsif(rand(1000)<200)
				{
					$hit6+=1;
				}
			}
			$hit7=$count-($hit1+$hit2+$hit3+$hit4+$hit5+$hit6);
			AddItem(83,$hit1,'무려!특등의 금색 마네키네코가'.$hit1.'회 당첨되었습니다') if ($hit1>=1);
			AddItem(82,$hit2,'무려!1등의 자동차가'.$hit2.'회 당첨되었습니다') if ($hit2>=1);
			AddItem(80,$hit3,'2등의 설거지 기계가'.$hit3.'회 당첨되었습니다') if ($hit3>=1);
			AddItem(79,$hit4,'3등의 자전거가'.$hit4.'회 당첨되었습니다') if ($hit4>=1);
			AddItem(67,$hit5,'4등의 힌트북이'.$hit5.'회 당첨되었습니다') if ($hit5>=1);
			AddItem(66,$hit6,'5등의 상품권이'.$hit6.'회 당첨되었습니다') if ($hit6>=1);
			AddItem(64,$hit7,'아쉽지만 깨끗한 그릇이'.$hit7.'회분 당첨되었습니다') if ($hit7>=1);
			$ret='복권 결과, 당첨된 상품이 없습니다';
			$ret='복권에서 경품이 당첨되었습니다' if ($hit7<$count);
			WriteLog(0,$DT->{id},$ret);
			return $ret;
		_local_

@@ITEM
	no		60
	type	도구
	code	tool-udon
	name	오리지널 우동 레시피
	info	오리지널 우동의 만드는 법이서있고 있습니다
	scale	매
	price	0
	limit	1/0
	pop		0
	@@USE
		time	1m
		action	보기
		name	레시피를 보기
		info	오리지널 우동의 재료와 만드는 법을 잊었을 때를 위해
		scale	회
		arg		nocount
		ngmsg	[오리지널 우동 만드는 법]<br>재료<br>·밀가루<br>·다시마<br>·거위<br>·고추<br>·깨끗한 그릇<br><br>만드는 법<br><b> 비밀</b>
	@@USE
		time	4h
		job		우동집	times/job_udon_time_rate
		action	이름 변경하기
		name	오리지널 우동 이름 변경하기
		info	오리지널 우동의 이름을 변경합니다
		arg		nocount|message30
		func	_local_
			# 오리지널 우동 이름 변경하기
			main::OutError('먼저 오리지널 우동을 개발해 주세요') if !$DT->{user}->{udon};
			main::OutError('이름을 입력해 주세요') if !$USE->{arg}->{message};
			my $ret;
			$ret='오리지널 우동의 이름을 ['.$USE->{arg}->{message}.']로 변경했습니다';
			WriteLog(3,0,$DT->{shopname}."가 오리지널 우동의 이름을 변경한 것 같습니다");
			WriteLog(0,$DT->{id},$ret);
			$DT->{user}->{udon}=$USE->{arg}->{message};
			return $ret;
		_local_

@@ITEM
	no		61
	type	도구
	code	tool-soba
	name	오리지널 메밀국수 레시피
	info	오리지널 메밀국수 만드는 법이 적혀 있습니다
	scale	매
	price	0
	limit	1/0
	pop		0
	@@USE
		time	1m
		action	보기
		name	레시피를 보기
		info	오리지널 메밀국수의 재료와 만드는 법을 잊었을 때를 위해
		scale	회
		arg		nocount
		ngmsg	[오리지널 메밀국수 만드는 법]<br>재료<br>·메밀국수가루<br>·다시마<br>·철갑상어<br>·알<br>·깨끗한 그릇<br><br>만드는 법<br><b> 비밀</b>
	@@USE
		time	4h
		job		메밀국수집	times/job_soba_time_rate
		action	이름 변경하기
		name	오리지널 메밀국수 이름 변경하기
		info	오리지널 메밀국수의 이름을 변경합니다
		arg		nocount|message30
		func	_local_
			main::OutError('먼저 오리지널 메밀국수를 개발해 주세요') if !$DT->{user}->{soba};
			main::OutError('이름을 입력해 주세요') if !$USE->{arg}->{message};
			my $ret;
			$ret='오리지널 메밀국수의 이름을 ['.$USE->{arg}->{message}.']로 변경했습니다';
			WriteLog(3,0,$DT->{shopname}."가 오리지널 메밀국수의 이름을 변경한 것 같습니다");
			WriteLog(0,$DT->{id},$ret);
			$DT->{user}->{soba}=$USE->{arg}->{message};
			return $ret;
		_local_

@@ITEM
	no		62
	type	도구
	code	tool-taihi
	name	퇴비
	info	밭의 비료요금입니다
	scale	kg
	price	5
	cost	0
	limit	5000/1000
	base	100/20000
	plus	20m
	pop		20m
	point	10%

@@ITEM
	no		63
	type	도구
	code	tool-yogore
	name	더러운 그릇
	info	사용 후 쌓인 더러운 그릇입니다
	scale	개
	price	10
	cost	0
	limit	10000/0
	pop		0

@@ITEM
	no		64
	type	도구
	code	tool-kirei
	name	깨끗한 그릇
	info	깨끗하게 씻은 그릇입니다
	scale	개
	price	50
	cost	10
	limit	3000/2000
	base	10000/100000
	plus	1h
	pop	10d

@@ITEM
	no		65
	type	도구
	code	tool-takara
	name	복권
	info	일확천금을 꿈꾸게 하는 복권입니다
	scale	매
	price	1000
	cost	10
	limit	100/20
	plus	3h
	pop		2h
	flag	noshowcase|norequest

@@ITEM
	no		66
	type	도구
	code	tool-syou
	name	상품권
	info	희망의 상품과 교환할 수 있습니다
	scale	매
	price	5000
	cost	10
	limit	500/0
	pop		0
	@@USE
		time	10m
		action	교환하기
		scale	회
		name	퇴비와 교환하기
		info	상품권을 원하는 상품과 교환합니다
		okmsg	퇴비를 구했습니다
			use		1	상품권
			get		250	퇴비
	@@USE
		time	10m
		action	교환하기
		scale	회
		name	깨끗한 그릇과 교환하기
		info	상품권을 원하는 상품과 교환합니다
		okmsg	깨끗한 그릇을 구했습니다
			use		1	상품권
			get		100	깨끗한 그릇
	@@USE
		time	10m
		action	교환하기
		scale	회
		name	힌트북과 교환하기
		info	상품권을 원하는 상품과 교환합니다
		okmsg	힌트북을 구했습니다
			use		2	상품권
			get		1	힌트북
	@@USE
		time	10m
		action	교환하기
		scale	회
		name	경보기와 교환하기
		info	상품권을 원하는 상품과 교환합니다
		okmsg	경보기를 구했습니다
			use		40	상품권
			get		1	경보기
	@@USE
		time	10m
		action	교환하기
		scale	회
		name	자동차와 교환하기
		info	상품권을 원하는 상품과 교환합니다
		okmsg	자동차를 구했습니다
			use		100	상품권
			get		1	자동차
	@@USE
		time	10m
		action	교환하기
		scale	회
		name	금의 마네키네코와 교환하기
		info	상품권을 원하는 상품과 교환합니다
		okmsg	금의 마네키네코를 구했습니다
			use		200	상품권
			get		1	금의 마네키네코
	@@use
		time	10m
		scale	매
		action	환전하기
		name	환전하기
		info	상품권을 금권숍에서 환전합니다
		param	500,2500
			use		1	상품권
		func	_local_
			my $ret;
			if (rand(1000)<300)
			{
				$DT->{money}+=$USE->{param1}*$count;
				$ret='금권숍의 매입가가 낮았던 것 같습니다<br>';
				$ret.=GetMoneyString($USE->{param1}*$count).'로 환전했습니다';
			}
			else
			{
			$DT->{money}+=$USE->{param2}*$count;
			$ret=GetMoneyString($USE->{param2}*$count).'로 환전했습니다';
			}
			WriteLog(0,$DT->{id},"상품권을 환전했습니다");
			return $ret;
		_local_

@@ITEM
	no		67
	type	도구
	code	tool-hint
	name	힌트북
	info	<b>주의! ★표시가 붙은 힌트를 읽으면 힌트북이 사라집니다</b>
	scale	책
	price	10000
	cost	10
	limit	5/0
	pop		0
	flag	noshowcase|norequest
	@@USE
		time	1m
		action	힌트 읽기
		name	처음 시작하는 분께
		info	먼저 무엇을 해야 할지 모를 때 보는 힌트입니다
		arg		nocount
		ngmsg	('도서관'을 확인한 뒤)<br><br>농부나 어부를 1명 시장이나 시세에서 구입해 봅시다.<br>(둘 다 없다면 아르바이트생을 구입해 농부나 어부로 전직시키세요)<br>어부는 바로 낚시를 시작할 수 있습니다.<br>농부는 밭을 구하면 수확할 수 있습니다.<br>수확이 끝난 밭은 '경작 전의 밭'으로 돌아가며, 보통 퇴비 100kg을 사용하면<br>'잘 경작한 밭'으로 만들 수 있습니다. 시간이 어느 정도 지나면<br>다음 단계인 '수확 대기 중인 밭'으로 합니다.
	@@USE
		time	10m
		action	힌트 읽기
		name	★아르바이트생의 비밀
		info	인력 파견업을 깊이 파고들 분께
		arg		nocount
		ngmsg	·우동장인으로 수련하려면 아르바이트생과 밀가루가 필요합니다.<br>·메밀국수장인으로 수련하려면 아르바이트생과 메밀국수 가루가 필요합니다.
			use		1	힌트북
	@@USE
		time	10m
		action	힌트 읽기
		name	★농부의 비밀
		info	농업을 깊이 파고들 분께
		arg		nocount
		ngmsg	·먹이로 동물을 키워 봅시다. 닭과 거위의 먹이는 옥수수, 돼지의 먹이는 대두입니다.<br>·알을 사용할 수 있을 때는 닭에게 알을 품게 해서 부화시킬 수 있습니다.<br>(부화 대기 중인 알은 시간이 지나면 닭이나 거위가 됩니다)<br>·닭을 사용하면 거위나 돼지로 교환할 수 있습니다.
			use		1	힌트북
	@@USE
		time	10m
		action	힌트 읽기
		name	★어부의 비밀
		info	어업을 깊이 파고들 분께
		arg		nocount
		ngmsg	·새우를 많이 준비하면 어업에 나갈 수 있습니다.<br>·명태와 고추를 준비하면 명란젓을 만들 수 있습니다.
			use		1	힌트북
	@@USE
		time	10m
		action	힌트 읽기
		name	★튀김 장인의 비밀
		info	튀김집을 깊이 파고들 분께
		arg		nocount
		ngmsg	·대두로 유부를 만들 수 있습니다.<br>·명태로 어묵을 만들 수 있습니다.<br>·에소로 마루텐을 만들 수 있습니다.<br>·새우, 밀가루, 알을 준비하면 새우튀김을 만들 수 있습니다.
			use		1	힌트북
	@@USE
		time	10m
		action	힌트 읽기
		name	★우동장인의 비밀
		info	우동집을 깊이 파고들 분께
		arg		nocount
		ngmsg	·만들 수 있는 우동은 표준 가격이 낮은 순서대로 '기본 우동', '미역우동', '키츠네우동',<br>'마루텐우동', '새우튀김우동', '우동 곱빼기', '캐비아우동', '트러플우동', '푸아그라우동',<br>'하카타우동', '오리지널 우동' 총 11종입니다.<br>·기본 우동의 재료는 밀가루, 파, 깨끗한 그릇입니다(우동 만들기의 기본).<br>·우동 곱빼기는 특정 우동 3종을 조합해 만듭니다.<br>·고급 우동에는 다시마가 필요한 경우가 많습니다.<br>·하카타우동은 돼지뼈 맛이며, 하카타 명물 해산 가공품이 들어갑니다.
			use		1	힌트북
	@@USE
		time	10m
		action	힌트 읽기
		name	★메밀국수장인의 비밀
		info	메밀국수집을 깊이 파고들 분께
		arg		nocount
		ngmsg	·만들 수 있는 메밀국수는 표준 가격이 낮은 순서대로 '기본 메밀국수', '미역메밀국수', '키츠네메밀국수',<br>'마루텐메밀국수', '새우튀김메밀국수', '메밀국수 곱빼기', '캐비아메밀국수', '트러플메밀국수', '푸아그라메밀국수',<br>'하카타메밀국수', '오리지널 메밀국수' 총 11종입니다.<br>·기본 메밀국수의 재료는 메밀국수가루, 파, 깨끗한 그릇입니다(메밀국수 만들기의 기본).<br>·메밀국수 곱빼기는 특정 메밀국수 3종을 조합해 만듭니다.<br>·고급 메밀국수에는 다시마가 필요한 경우가 많습니다.<br>·하카타메밀국수는 돼지뼈 맛이며, 하카타 명물 해산 가공품이 들어갑니다.
			use		1	힌트북
	@@USE
		time	10m
		action	힌트 읽기
		name	★도우미의 비밀
		info	인력 파견업을 깊이 파고들 분께
		arg		nocount
		ngmsg	·아르바이트생이 인재 파견 전문가가 되면 도우미의 각종 작업 시간이 짧아집니다.<br>·설거지 기계를 구하면 짧은 시간에 많은 더러운 그릇을 씻을 수 있습니다.<br>·전문 직업 게시판을 열면 상업조합에서 보조금이 지급됩니다.
			use		1	힌트북
	@@USE
		time	10m
		action	힌트 읽기
		name	★비밀 공작원의 비밀
		info	뒷공작을 깊이 파고들 분께
		arg		nocount
		ngmsg	·더러운 그릇이 어느 정도 있으면 어둠우동과 어둠메밀국수를 만들 수 있습니다.<br>·어둠우동과 어둠메밀국수를 많이 갖고 있고 상점력이 조금 있으면 바꿔치기 작전을 실행할 수 있습니다.<br>·나쁜 소문을 퍼뜨리려면 상점력 100이 필요합니다.<br>·비밀 공작원이 2명 있고 상점력 100이 더 있으면 시간 조작을 할 수 있습니다.<br>(시간 조작을 하면 보유 시간이 무작위로 증가합니다)
			use		1	힌트북
	@@USE
		time	1m
		action	힌트 읽기
		name	진열대에 대해
		info	진열대 증축과 유지비에 대한 설명입니다
		arg		nocount
		ngmsg	진열대 수를 변경하려면 도우미를 사용합니다.<br>단, 도우미 1명으로는 진열대를 2개까지만 늘릴 수 있습니다.<br>그 이상 늘리려면 도우미 수가 더 필요합니다.<br>진열대 유지비는 선반이 늘어날수록 단계적으로 증가합니다.
	@@USE
		time	1m
		action	힌트 읽기
		name	상점력에 대해
		info	상점력에 관한 설명입니다
		arg		nocount
		ngmsg	상점력은 생산적인 활동을 하거나<br>우동이나 메밀국수를 먹으면 얻을 수 있습니다.<br>비밀 공작원이나 금 마네키네코를 통해 그 힘을 사용할 수 있습니다.
	@@USE
		time	1m
		action	힌트 읽기
		name	오리지널 우동(메밀국수)에 대해
		info	오리지널 우동(메밀국수)의 만드는 법의 설명입니다
		arg		nocount
		ngmsg	우동(메밀국수) 몰두와 오리지널 우동(메밀국수)을 제외한 모든 종류의 우동(메밀국수)을 1그릇씩 준비하면,<br>우동(메밀국수)장인이 오리지널 우동(메밀국수)을 개발할 수 있습니다.<br>오리지널 우동(메밀국수)에는 원하는 이름을 붙일 수 있습니다.<br>이 이름은 쇼윈도우(진열대 1)에서 판매될 때 순위에 표시됩니다.
	@@USE
		time	1m
		action	힌트 읽기
		name	더러운 그릇에 대해
		info	더러운 그릇에 대한 설명입니다
		arg		nocount
		ngmsg	우동이나 메밀국수가 판매되면 더러운 그릇이 창고에 쌓입니다.<br>(다른 점포에서 구입된 경우 그릇은 돌아오지 않습니다)<br>단, 어둠우동과 어둠메밀국수는 예외입니다.<br>일반 시민은 '아, 맛없어!' 하고 화를 내며 그릇을 깨뜨려 버립니다.
	@@USE
		time	1m
		action	힌트 읽기
		name	힌트북에 대해
		info	힌트북을 구하는 방법에 관한 설명입니다
		arg		nocount
		ngmsg	힌트북은 상품권과 교환할 수 있습니다.<br>상품권은 결산 때 상품으로 받을 수 있습니다.<br>또한 힌트북은 복권 경품으로 당첨될 수도 있습니다.<br>복권보조권은 시장에서 매입하면 얻을 수 있습니다.
	@@use
		time	10m
		scale	책
		action	환전하기
		name	환전하기
		info	힌트북을 금권숍에서 환전합니다
		param	1000,5000
			use		1	힌트북
		func	_local_
			my $ret;
			if (rand(1000)<300)
			{
				$DT->{money}+=$USE->{param1}*$count;
				$ret='금권숍의 매입가가 낮았던 것 같습니다<br>';
				$ret.=GetMoneyString($USE->{param1}*$count).'로 환전했습니다';
			}
			else
			{
			$DT->{money}+=$USE->{param2}*$count;
			$ret=GetMoneyString($USE->{param2}*$count).'로 환전했습니다';
			}
			WriteLog(0,$DT->{id},"힌트북을 환전했습니다");
			return $ret;
		_local_

@@ITEM
	no		68
	type	도구
	code	tool-paintr
	name	적의 물감
	info	(사용할 수 없 아이템입니다. 폐기해 주세요)
	scale	캔
	price	10000
	cost	100
	limit	1/0
	pop	1d

@@ITEM
	no		69
	type	도구
	code	tool-paintb
	name	청의 물감
	info	(사용할 수 없 아이템입니다. 폐기해 주세요)
	scale	캔
	price	10000
	cost	100
	limit	1/0
	pop	1d

@@ITEM
	no		70
	type	도구
	code	tool-painto
	name	오렌지색 물감
	info	(사용할 수 없 아이템입니다. 폐기해 주세요)
	scale	캔
	price	10000
	cost	100
	limit	1/0
	pop	1d

@@ITEM
	no		71
	type	도구
	code	tool-painty
	name	노랑색의 물감
	info	(사용할 수 없 아이템입니다. 폐기해 주세요)
	scale	캔
	price	10000
	cost	100
	limit	1/0
	pop	1d

@@ITEM
	no		72
	type	도구
	code	tool-paintg
	name	녹색의 물감
	info	(사용할 수 없 아이템입니다. 폐기해 주세요)
	scale	캔
	price	10000
	cost	100
	limit	1/0
	pop	1d

@@ITEM
	no		73
	type	도구
	code	tool-paintp
	name	핑크색 물감
	info	(사용할 수 없 아이템입니다. 폐기해 주세요)
	scale	캔
	price	10000
	cost	100
	limit	1/0
	pop	1d

@@ITEM
	no		74
	type	도구
	code	tool-painte
	name	보라의 물감
	info	(사용할 수 없 아이템입니다. 폐기해 주세요)
	scale	캔
	price	10000
	cost	100
	limit	1/0
	pop	1d

@@ITEM
	no		75
	type	도구
	code	tool-paintk
	name	검정의 물감
	info	(사용할 수 없 아이템입니다. 폐기해 주세요)
	scale	캔
	price	10000
	cost	100
	limit	1/0
	pop	1d

@@ITEM
	no		76
	type	도구
	code	tool-hatakea
	name	경작 전의 밭
	info	비료를 충분히 뿌립시다
	scale	반
	price	5000
	limit	40/2
	plus	1d
	pop		2d
	flag	noshowcase|onlysend

@@ITEM
	no		77
	type	도구
	code	tool-hatakeb
	name	잘 경작한 밭
	info	잠시 지나면 수확할 수 있게 됩니다
	scale	반
	price	10000
	limit	20/0
	pop		1d
	flag	noshowcase|onlysend
	funct	_local_
		my($ITEM,@DT)=@_;
		my $birth_per_day=40; # 1일에수확 대기 중인 밭이40이 됨확률의 설정
		my $val =1; # 한 번에수확 대기 중인 밭이 됨기본수

		my $birth_rate=$birth_per_day && (86400/$birth_per_day); # 0에서 할루의 를저지
		foreach my $DT (@DT)
		{
			next if !$DT->{item}[@@ITEMNO"잘 경작한 밭"-1];
			if(rand($birth_rate)<$TIMESPAN) # 1점포에 관련'1일에$birth_per_day 회' 확률로 조건이진짜가 됨(하즈…)
			{
				UseItemSub(@@ITEMNO"잘 경작한 밭",$val,$DT);
				AddItemSub(@@ITEMNO"수확 대기 중인 밭",$val,$DT);
			}
		}
	_local_

@@ITEM
	no		78
	type	도구
	code	tool-hatakec
	name	수확 대기 중인 밭
	info	여러 가지 수확물을 기대할 수 있습니다
	scale	반
	price	20000
	limit	20/0
	pop		1d
	flag	noshowcase|onlysend

@@ITEM
	no		79
	type	도구
	code	tool-ziten
	name	자전거
	info	시장 매입이 조금 더 편해집니다
	scale	대
	price	30000
	cost	1000
	limit	1/0.5
	plus	10d
	pop		3d
	flag	noshowcase|onlysend

@@ITEM
	no		80
	type	도구
	code	tool-syokki
	name	설거지 기계
	info	설거지를 빠르게 처리할 수 있습니다
	scale	대
	price	100000
	cost	3000
	limit	1/0.8
	plus	10d
	pop		10d
	flag	noshowcase|onlysend

@@ITEM
	no		81
	type	도구
	code	tool-keihou
	name	경보기
	info	점포 안전 대책에 쓰입니다
	scale	대
	price	200000
	cost	5000
	limit	1/0.5
	plus	10d
	pop		20d
	flag	noshowcase|onlysend

@@ITEM
	no		82
	type	도구
	code	tool-kuruma
	name	자동차
	info	시장 매입이 크게 편해집니다
	scale	대
	price	500000
	cost	5000
	limit	1/0.3
	plus	10d
	pop	30d
	flag	noshowcase|onlysend

@@ITEM
	no		83
	type	도구
	code	tool-neko
	name	금의 마네키네코
	info	점의 지킴리신입니다
	scale	체
	price	1000000
	cost	1000
	limit	1/0.2
	plus	10d
	pop		50d
	flag	noshowcase|onlysend
	@@use
		time	3m
		scale	회
		action	참배하기
		name	참배하기
		info	장사가 번창하기를 기원하며 금 마네키네코에 참합니다
			use		1	상점력
		func	_local_
			my $val=$count;
			my $ret="";

			if($count>=50)
			{
				$DT->{rank}-=$count*2;
				$DT->{rank}=0 if $DT->{rank}<0;
				WriteLog(2,0,$DT->{shopname}.'의 점주가기원을 너무 많이 해서 구급차에 실려 갔습니다.');
				WriteLog(2,0,'한 번에'.$count.'회나 금 마네키네코를 참배하는 것은 정상적인 상태가 아닙니다.');
				$ret="‥정신을 차려 보니 병원 침대 위였습니다";
			}
			elsif($count>=20)
			{
				$ret='현기증이 나 버렸습니다. 한 번에 '.$count.'회 참배는 합니다.';
				WriteLog(0,$DT->{id},$ret);
			}
			else
			{
				$DT->{rank}+=int(rand($count+1))+$count;
				$DT->{rank}=10000 if $DT->{rank}>10000;
				$ret='금 마네키네코를 참배하니 오늘도 장사가 순조로울 것 같은 기분이 들었습니다.';
				WriteLog(0,$DT->{id},$ret);
			}
			return $ret;
		_local_

@@EVENT
	start		50%
	basetime	0h
	plustime	0h
	code		loto
	startfunc	loto
	info		복권추첨

@@EVENT
	start		30%
	basetime	0h
	plustime	0h
	code		luckyneko
	info		금의 마네키네코의 초대운영
	startfunc	_local_(200)
		my($hitproba)=@_;

		foreach my $DT (@main::DT)
		{
			next if rand(1000)>$hitproba;
			{
			foreach my $itemno (@@ITEMNO"금의 마네키네코")
			{
			if ($DT->{item}[@@ITEMNO"금의 마네키네코"-1])
			{
				$DT->{item}[@@ITEMNO"금의 마네키네코"-1]=0;
				my $up=int(1000*(2-$DT->{rank}/5000));
				$DT->{rank}+=$up;
				$DT->{rank}=10000 if $DT->{rank}>10000;
				WriteLog(2,0,$DT->{shopname}."의 금색 마네키네코가 가게에 행운을 불러와 인기가 올랐습니다.");
				WriteLog(0,$DT->{id},"금색 마네키네코의 신비한 힘으로 가게의 인기가 ".int($up/100)."% 상승했습니다");			}
			}
			}
		}
		return 0;
	_local_

@@EVENT
	start		100%
	basetime	0h
	plustime	0h
	code		yogoredon
	info		더러운 그릇의 악취
	startfunc	_local_(500)
		my($hitproba)=@_;

		foreach my $DT (@main::DT)
		{
			next if rand(1000)>$hitproba;
			{
			foreach my $itemno (@@ITEMNO"더러운 그릇")
			{
			if ($DT->{item}[@@ITEMNO"더러운 그릇"-1]>=1000)
			{
				my $down=int($DT->{rank}/5);
				$DT->{rank}-=$down;
				$DT->{rank}=0 if $DT->{rank}<0;
				WriteLog(2,0,$DT->{shopname}."에 쌓여 있던 더러운 그릇에서 악취가 발생해 점포의 인기가 내려갔습니다.");
				WriteLog(0,$DT->{id},"더러운 그릇 때문에, 점포의 인기가".int($down/100)."% 내려갔습니다");			}
			}
			}
		}
		return 0;
	_local_

# 오리지널 우동에서 인기업로드
@@EVENT
	start		50%
	basetime	0h
	plustime	0h
	code		udonpop
	info		오리지널 우동 인기 급상승
	startfunc	_local_
		foreach(reverse(@DT))
		{
			next if rand(1000)>200;
			if ($_->{user}->{udon}&&($_->{user}->{udon} ne 'n'))
			{
			my $up=int(300*(2-$_->{rank}/5000));
			$_->{rank}+=$up;
			$_->{rank}=10000 if $_->{rank}>10000;
			return (0,$_->{shopname}.'의 특제 우동 '.$_->{user}->{udon}.'이 거리에서 소문이 나, 점포 앞은 기대에 부푼 고객으로 가능합니다.') ;
			}
		}
		return 0;
	_local_

# 오리지널 메밀국수에서 인기업로드
@@EVENT
	start		50%
	basetime	0h
	plustime	0h
	code		sobapop
	info		오리지널 메밀국수 인기 급상승
	startfunc	_local_
		foreach(reverse(@DT))
		{
			next if rand(1000)>200;
			if ($_->{user}->{soba}&&($_->{user}->{soba} ne 'n'))
			{
			my $up=int(300*(2-$_->{rank}/5000));
			$_->{rank}+=$up;
			$_->{rank}=10000 if $_->{rank}>10000;
			return (0,$_->{shopname}.'의 특제 메밀국수 '.$_->{user}->{soba}.'가 인기를 끌자, 소문을 듣고 찾아온 고객이 점포 앞에 줄을 서고 있습니다.') ;
			}
		}
		return 0;
	_local_

@@EVENT
	start		30%
	basetime	0h
	plustime	0h
	code		syokkiarai
	info		설거지 기계 수명명
	startfunc	_local_(100)
		my($hitproba)=@_;

		foreach my $DT (@DT)
		{
			next if rand(1000)>$hitproba;
			{
			foreach my $itemno (@@ITEMNO"설거지 기계")
			{
				if ($DT->{item}[@@ITEMNO"설거지 기계"-1]==1)					{
				$DT->{item}[@@ITEMNO"설거지 기계"-1]=0;
				WriteLog(2,0,$DT->{shopname}."의설거지 기계가고장장애했습니다것 같습니다.");
				WriteLog(0,$DT->{id},"고장장애했습니다설거지 기계를 폐지폐기했습니다");
				}
			}
			}
		}
		return 0;
	_local_

@@EVENT
	start		30%
	basetime	0h
	plustime	0h
	code		haisya
	info		폐지차
	startfunc	_local_(100)
		my($hitproba)=@_;

		foreach my $DT (@DT)
		{
			next if rand(1000)>$hitproba;
			{
			foreach my $itemno (@@ITEMNO"자동차")
			{
				if ($DT->{item}[@@ITEMNO"자동차"-1]==1)	{
				$DT->{item}[@@ITEMNO"자동차"-1]=0;
				WriteLog(2,0,$DT->{shopname}."가고장장애의 많음이자동차를 폐지차했습니다것 같습니다.");
				WriteLog(0,$DT->{id},"자동차를 폐지차했습니다");
				}
			}
			}
		}
		return 0;
	_local_

#축하복이벤트를 대판매리출시이벤트에변경
@@event
	start		20%
	basetime	5h
	plustime	5h
	code		happy
	startmsg	상점가의 대판매리출시가시작마되었습니다.
	endmsg		대판매리출시가끝가 되었습니다.
	info		대규모 판매 행사로 상점가가 활기를 띠고 있습니다.
	func		_local_
		my $time=$TIMESPAN;
		$time=10*3600 if $time>10*3600; # 최대10%제한
		$time=int($time/36);

		foreach(@DT)
		{
			$_->{rank}+=int(rand($time));
			$_->{rank}=10000 if $_->{rank}>10000;
		}
		return 0;
	_local_

@@EVENT
	start		10%
	basetime	6h
	plustime	24h
	code		udon-boom
	startmsg	거리에서는 우동 붐의 것 같습니다.
	endmsg		우동 붐이 끝났습니다.
	info		우동의 인기가 높아지고 있습니다.
		param	기본 우동			pop/1.5
		param	미역우동			pop/1.5
		param	키츠네우동			pop/1.5
		param	마루텐우동			pop/1.5
		param	새우튀김우동			pop/2
		param	우동 곱빼기			pop/2
		param	캐비아우동			pop/2
		param	트러플우동			pop/2
		param	푸아그라우동		pop/2
		param	하카타우동			pop/2
		param	오리지널 우동		pop/2

@@EVENT
	start		10%
	basetime	6h
	plustime	24h
	code		soba-boom
	startmsg	거리에서는 메밀국수 붐의 것 같습니다.
	endmsg		메밀국수 붐이 끝났습니다.
	info		메밀국수의 인기가 높아지고 있습니다.
		param	기본 메밀국수			pop/1.5
		param	미역메밀국수			pop/1.5
		param	키츠네메밀국수			pop/1.5
		param	마루텐메밀국수			pop/1.5
		param	새우튀김메밀국수			pop/2
		param	메밀국수 곱빼기			pop/2
		param	캐비아메밀국수			pop/2
		param	트러플메밀국수			pop/2
		param	푸아그라메밀국수			pop/2
		param	하카타메밀국수			pop/2
		param	오리지널 메밀국수			pop/2

@@EVENT
	start		5%
	basetime	9h
	plustime	16h
	code		plusup-katuo
	group		sui
	startmsg	다시마가 풍어입니다.
	endmsg		다시마의 유통량이 평상시로 돌아왔습니다.
	info		다시마 유통량이 늘었습니다.
		param	다시마				plus=300

@@EVENT
	start		1%
	basetime	6h
	plustime	18h
	code		plusup-tyouzame
	group		sui
	startmsg	철갑상어 떼가 해변으로 몰려왔습니다.
	endmsg		철갑상어의 유통량이 평상시로 돌아왔습니다.
	info		철갑상어 유통량이 늘었습니다.
		param	철갑상어			plus=500

# 저 자금우선에서 길드미가맹점에 자금지원이벤트
@@EVENT
	start		30%
	code		getmoney
	info		자금지원
	startfunc	_local_(100000)
		my($money)=@_;

		foreach(reverse(@DT))
		{
			next if rand(1000)>300;

			if ($_->{guild} eq '')
			{
			$_->{money}+=$money;
			$_->{money}=$main::MAX_MONEY if $_->{money}>$main::MAX_MONEY;
			return (0,"상업조합에서 ".$_->{shopname}."에게 ".GetMoneyString($money)."의 보조금이 지급되었습니다");
			}
		}
		return 0;
	_local_

# 상위우선에서 좀도둑질이벤트
@@EVENT
	start		100% #old50%
	basetime	0h		#★보유계속계의 이벤트에서는 없으므로 시간은0.
	plustime	0h
	code		manbiki
	info		좀도둑질
	startfunc	_local_(400,200)
		#★실은 이함수가이벤트의 본체에되어루
		my($hitproba,$breakproba)=@_;
		#노림와 됨확률, 로보와 파괴확률

		foreach my $DT (@DT)
		{
			next if rand(1000)>$hitproba;

			if($DT->{item}[@@ITEMNO"경보기"-1])
			{
				return (0,$DT->{shopname}.'에 좀도둑이 들어왔지만 저지되었습니다.') if rand(1000)>$breakproba;

				$DT->{item}[@@ITEMNO"경보기"-1]--;
				return (0,$DT->{shopname}.'에 좀도둑이 침입해,'.$ITEM[@@ITEMNO"경보기"]->{name}.'가 파괴되었습니다.');
			}

			my $count=0;
			foreach my $idx (0..$DT->{showcasecount}-1)
			{
				my $itemno=$DT->{showcase}[$idx];
				next if !$itemno;

				my $cnt=int($DT->{item}[$itemno-1]/10);
				$DT->{item}[$itemno-1]-=$cnt;
				$count+=$cnt*$DT->{price}[$idx];
			}
			return (0,$DT->{shopname}.'가 총액 '.GetMoneyString($count).'상당의 좀도둑 피해를 입었습니다.') if $count;
			return (0,$DT->{shopname}.'에 침입한 좀도둑은 아무것도 훔치지 못하고 도망쳤습니다.');
		}
		return 0;
	_local_

@@EVENT
	start		30% #old15%
	basetime	0h
	plustime	0h
	code		goutou
	info		강도둑
	startfunc	_local_(700)
		#★실은 이함수가이벤트의 본체에되어루
		my($hitproba)=@_;
		#노림와 됨확률

		foreach my $DT (@DT)
		{
			next if rand(1000)>$hitproba;

			if($DT->{item}[@@ITEMNO"경보기"-1])
			{
				$DT->{item}[@@ITEMNO"경보기"-1]--;
				return (0,$DT->{shopname}.'에 강도가 침입해,'.$ITEM[@@ITEMNO"경보기"]->{name}.'가 파괴되었습니다.');
			}

			$DT->{rank}-=int($DT->{rank}/5);

			my $count=0;
			foreach my $idx (0..$DT->{showcasecount}-1)
			{
				my $itemno=$DT->{showcase}[$idx];
				next if !$itemno;

				my $cnt=int($DT->{item}[$itemno-1]/4);
				$DT->{item}[$itemno-1]-=$cnt;
				$count+=$cnt*$DT->{price}[$idx];
			}
			return (0,$DT->{shopname}.'가 총액 '.GetMoneyString($count).'상당의 강도 피해를 입었습니다.') if $count;
			return (0,$DT->{shopname}.'에 침입한 강도는 아무것도 훔치지 못하고 도망쳤습니다.');
		}
		return 0;
	_local_

@@EVENT
	start		15%
	basetime	0h
	plustime	0h
	code		blacktime
	info		때의 소용돌이
	startfunc	_local_(700)
		my($hitproba)=@_;
		foreach my $DT (@DT)
		{
			next if rand(1000)>$hitproba;

			if($DT->{user}->{black}>10)
			{
				my $blackcnt=int($DT->{user}->{black}/10);
				my $cnt=int(rand(10))+$blackcnt;
				$cnt=12 if $cnt>12;
				$DT->{time}+=3600*$cnt;
				$DT->{user}->{black}=0;
				WriteLog(0,$DT->{id},'때의 소용돌이에 시간을 흡수이포함마되었습니다 -'.$cnt.'시간');
				return (0,'도중됨 시간조작 때문에 에 때의 소용돌이가발생시,'.$DT->{shopname}.'의 시간을 흡수이포함인 것 같습니다.');
			}
		}
		return 0;
	_local_

# 하위우선에서 인기업로드이벤트
@@EVENT
	start		30%
	basetime	0h
	plustime	0h
	code		getpop
	info		인기업로드
	startfunc	_local_(1000)
		my($pop)=@_;

		foreach(reverse(@DT))
		{
			next if rand(1000)>300;

			$_->{rank}+=$pop;
			$_->{rank}=10000 if $_->{rank}>10000;
			return (0,$_->{shopname}.'가 잡지에 소개되어 인기가 오른 것 같습니다.');
		}
		return 0;
	_local_

@@FUNCEVENT
######################################################################
# ★복권이벤트
# usage: loto
# return: 0 고정
######################################################################
sub loto
{
	WriteLog(2,0,"복권 추첨이 진행되었습니다.");
	foreach my $DT (@main::DT)
	{
		my $count=$DT->{item}[65-1];
		$DT->{item}[65-1]=0;
		my $hit1=0;
		my $hit2=0;
		my $hit3=0;
		my $hit4=0;
		my $hit5=0;
		next if !$count;

		foreach(1..$count)
		{
			my $rnd=rand(6096454);
			my $hit=0;

			if ($rnd<152411) {$hit=5;$hit5++;}
			elsif ($rnd<10000) {$hit=4;$hit4++;}
			elsif ($rnd<216) {$hit=3;$hit3++;}
			elsif ($rnd<6) {$hit=2;$hit2++;}
			elsif ($rnd<1) {$hit=1;$hit1++;}

			if($hit)
			{
				my $getmoney=(0,1000000000,150000000,5000000,100000,10000)[$hit];

				$DT->{moneystock}+=$getmoney;
				$DT->{money}=$main::MAX_MONEY if $DT->{money}>$main::MAX_MONEY;
			}
		}
		my $hitlog=5;
		$hitlog=1;
		WriteLog(($hitlog<=3?1:2),0,$DT->{shopname}."가1등".GetMoneyString(1000000000)."에 당첨되었습니다!") if $hit1>0;
		$hitlog=2;
		WriteLog(($hitlog<=3?1:2),0,$DT->{shopname}."가2등".GetMoneyString(150000000)."에 $hit2회 당첨되었습니다") if $hit2>0;
		$hitlog=3;
		WriteLog(($hitlog<=3?1:2),0,$DT->{shopname}."가3등".GetMoneyString(5000000)."에 $hit3회 당첨되었습니다") if $hit3>0;
		$hitlog=4;
		WriteLog(($hitlog<=3?1:2),0,$DT->{shopname}."가4등".GetMoneyString(100000)."에 $hit4회 당첨되었습니다") if $hit4>0;
		my $hitlog=5;
		WriteLog(($hitlog<=3?1:2),0,$DT->{shopname}."가5등".GetMoneyString(10000)."에 $hit5회 당첨되었습니다") if $hit5>0;
	}
	return 0;
}

@@FUNCINIT
#자전거를 가지고 있는 경우, 매입에필요한 시간을3/4에하다.
$TIME_SEND_ITEM=int($TIME_SEND_ITEM/4*3) if (($DT->{item}[@@ITEMNO"자전거"-1])&&(!$DT->{item}[@@ITEMNO"자동차"-1]));

#자동차를 가지고 있는 경우, 매입에필요한 시간을1/4에하다.
$TIME_SEND_ITEM=int($TIME_SEND_ITEM/4) if $DT->{item}[@@ITEMNO"자동차"-1];

@@FUNCITEM
######################################################################
# ★인재가점을 제거루
######################################################################
sub lostman
{
	my $itemno=$USE->{itemno};
	if(rand(1000)<$USE->{param1})
	{
		UseItem($itemno,1,'<br>일을 마친 '.$ITEM[$itemno]->{name}.'가 조용히 떠났습니다');
	}
	return "";
}

@@FUNCUPDATE
sub UpdateResetBefore #결산직전의 처리(함수이름고정)
{
	UpdateTodayPrize();

	sub UpdateTodayPrize
	{
		#상품 수여
		my @TOP123=(
			[
				['상품권',	[[@@ITEMNO "상품권", 5],			],],
				['상품권',	[[@@ITEMNO "상품권", 4],			],],
				['상품권',	[[@@ITEMNO "상품권", 3],			],],
				['복권보조권',	[[@@ITEMNO "복권보조권", 5],		],],
				['방어범죄용품',	[[@@ITEMNO "경보기", 1],		],],
				['비료와 트럭 1대분',[[@@ITEMNO "퇴비", 1000],	],],
				['식기구',[[@@ITEMNO "깨끗한 그릇", 500],	],],
			],
			[
				['상품권',	[[@@ITEMNO "상품권", 3],			],],
				['상품권',	[[@@ITEMNO "상품권", 2],			],],
				['복권보조권',	[[@@ITEMNO "복권보조권", 3],		],],
				['식기구',[[@@ITEMNO "깨끗한 그릇", 300],	],],
			],
			[
				['복권보조권',	[[@@ITEMNO "복권보조권", 2],		],],
				['상품권',	[[@@ITEMNO "상품권", 2],			],],
				['상품권',	[[@@ITEMNO "상품권", 1],			],],
				['식기구',[[@@ITEMNO "깨끗한 그릇", 200],	],],
			],
			[
				['상품권',	[[@@ITEMNO "상품권", 2],			],],
				['상품권',	[[@@ITEMNO "상품권", 1],			],],
				['복권보조권',	[[@@ITEMNO "복권보조권", 1],		],],
			],
		);

		TopGetItem($DT[0],$TOP123[0],"이번 우승 점포 ") if defined($DT[0]);
		TopGetItem($DT[1],$TOP123[1],"아쉽게 2위인 ") if defined($DT[1]);
		TopGetItem($DT[2],$TOP123[2],"3위 입상 점포 ") if defined($DT[2]);

		for(my $i=9; $i<$#DT; $i+=10)
		{
			TopGetItem($DT[$i],$TOP123[3],"간신히 ".($i+1)."위인 ") if defined($DT[$i]);
		}

		sub TopGetItem
		{
			my($DT,$itemlist,$head)=@_;

			my @list=@{$itemlist};
			my @getitem=@{$list[int(rand($#list+1))]};

			my $msg=$head.$DT->{shopname}."에는 상점회에서 ".$getitem[0]."가 지급되었습니다.";
			WriteLog(2,0,0,$msg,1);
			foreach (@{$getitem[1]})
			{
				my @itemnocount=@{$_};

				my $cnt=AddItem($DT,$itemnocount[0],$itemnocount[1]);
				my $ITEM=$ITEM[$itemnocount[0]];
				WriteLog(0,$DT->{id},0,$head."상품으로 ".$ITEM->{name}."를".$itemnocount[1].$ITEM->{scale}." 획득했습니다.",1);
				$cnt=$itemnocount[1]-$cnt;
				WriteLog(0,$DT->{id},0,"그러나 최대 보유 수를 넘었으므로 ".$cnt.$ITEM->{scale}." 폐기했습니다",1) if $cnt;
			}
		}
	}
}

@@FUNCNEW

# @@DEFINE Set NewShopMoney NewShopTime NewShopItem 의처리
$DT->{money}=@@VALUE"NewShopMoney" if @@VALUE"NewShopMoney";
$DT->{time}=$NOW_TIME-eval(@@VALUE"NewShopTime") if @@VALUE"NewShopTime";
if(@@VALUE"NewShopItem")
{
	my %item=split /:/,@@VALUE"NewShopItem";
	while(my($key,$val)=each %item)
	{
		foreach my $item (@ITEM)
		{
			 $DT->{item}[$item->{no}-1]+=$val,last if $key eq $item->{code} or $key eq $item->{name};
		}
	}
}

# $DEFINE_FUNCNEW_NOLOG=1로 설정하면 시스템 최근 사건의 신규 개점 메시지를 숨깁니다.
$DEFINE_FUNCNEW_NOLOG=1;
WriteLog(1,0,0,$DT->{shopname}."가 리어카를 끌고 이 거리에 나타났습니다.",1);

# 그 밖에 신규 개점 시 전용 처리를 추가할 수 있습니다.

@@FUNCSHOPIN

SetUserDataEx($DT,'_so_move_in',$NOW_TIME); # 이전시각을 기록

$DT->{item}[67-1]=1;	# 힌트북을 선물
if($DT->{job} eq 'man')
{
	# 인력 파견업(man)에는 이전소요 시간의1/2을 반환반환
	$DT->{_MoveTownTime}=int($DT->{_MoveTownTime}/2);
	EditTime($DT,$DT->{_MoveTownTime});
	WriteLog(0,$DT->{id},0,'이전 시간이절반의'.GetTime2HMS($DT->{_MoveTownTime}).'로 완료된 것 같습니다',1);
}
if(GetUserDataEx($DT,'_so_present_money'))
{
	WriteLog(0,$DT->{id},0,'이전원래의 거리에서 전별금으로'.GetMoneyString(GetUserDataEx($DT,'_so_present_money')).'를 받았습니다',1);
	SetUserDataEx($DT,'_so_present_money','');
}

@@FUNCSHOPOUT

if(GetUserDataEx($DT,'_so_move_in'))
{
	my $present_money=int(($NOW_TIME-GetUserDataEx($DT,'_so_move_in'))/86400)*5000;
	EditMoney($DT,$present_money); # 체류 기간 1일마다\5000을 전별금으로 자금로
	SetUserDataEx($DT,'_so_present_money',$present_money);
	SetUserDataEx($DT,'_so_move_in',''); # $DT->{user}{_so_move_in}을삭제
}

@@FUNCBUY
# package item입니다.
#
# $item::BUY를 이용할 수 있습니다. $item::BUY의 구조는 설명서의 @@ITEM funcb를 참고해 주세요.
# 상품매의 처리는 @@ITEM funcb 을이용해 주세요.

if($BUY->{whole})
{
	# 시장에서의 매입의 경우,\500000마다 복권보조권 1장을 지합니다.
	my $price=$BUY->{num}*$BUY->{price};
	my $count=int $price/500000;

	$count=AddItemSub(@@ITEMNO"복권보조권",$count,$BUY->{dt}) if $count;
	WriteLog(0,$BUY->{dt}{id},'시장에서 복권보조권을 '.$count.'장 받았습니다') if $count;
}

@@END # 정의 종료 선언(이후 문장은 취급하지 않음)


