#!/usr/bin/perl
# 성하읍 설정 파일 2003/10/08 유래

# 성 아래 마을 풍경을 사용자 지정할 수 있습니다.
# 단,'영주 저택'토, 맨 아래 줄의'상점가''현재 활동 중인 가게'의위치는 변경할 수 없습니다.
# 위치 번호는, 다음과 같습니다.
#
# [No.0] [ 영주 저택 ] [No.1]
# [No.2] [No.3] [No.4] [No.5]
# [No.6] [No.7] [No.8] [No.9]
# ·
# ·
# [ 상점가 ] [ 활동 중인 점포 ]
#
# 참고: No.10 이하를 정의하면 거리를 계속 추가할 수 있습니다.

# <기술문법>
# ·'이름','이미지','링크','게스와 권한에서의 링크'의순입니다.
# ·이미지에서는,$i[0](일반건설물),$i[1](점포건설물),$space(소세요공간),$vspace(대큰공간)이유효입니다.
# ·링크는, 하위프로그램이름의 호카주소를 지정 가능합니다. 빈칸라면링크를 츠쿠리않습니다.
# ·무엇도정의 하지 않음장소는, 수목와 해합니다.

# --- No.0 의 위치 정의 ---

($Pname[0],$Pimage[0],$Plink[0],$Pguest[0])=(
	"드래곤 경주장",
	qq|<IMG WIDTH=16 HEIGHT=64 SRC="$IMAGE_URL/map/mapsignslime.png">$i[0]|,
	"slime",
	"slime"
	);

# --- No.1 의 위치 정의 ---

# 수목 때문에 생략

# --- No.2 의 위치 정의 ---

($Pname[2],$Pimage[2],$Plink[2],$Pguest[2])=(
	"의뢰소",
	qq|$space<IMG WIDTH=16 HEIGHT=64 SRC="$IMAGE_URL/map/mapsignrequest.png">$i[1]|,
	"req",
	"req"
	);

# --- No.3 의 위치 정의 ---

($Pname[3],$Pimage[3],$Plink[3],$Pguest[3])=(
	"시장",
	qq|$space<IMG WIDTH=16 HEIGHT=64 SRC="$IMAGE_URL/map/mapsignmarket.png">$i[1]|,
	"shop-m",
	"shop-m"
	);

# --- No.4 의 위치 정의 ---

# 수목 때문에 생략

# --- No.5 의 위치 정의 ---

($Pname[5],$Pimage[5],$Plink[5],$Pguest[5])=(
	"길드",
	qq|<IMG WIDTH=16 HEIGHT=64 SRC="$IMAGE_URL/map/mapsignguild.png">$i[0]|,
	"gd",
	"gd"
	);

# --- No.6 의 위치 정의 ---

# 수목 때문에 생략

# --- No.7 의 위치 정의 ---

($Pname[7],$Pimage[7],$Plink[7],$Pguest[7])=(
	"병사주둔소",
	qq|<IMG WIDTH=16 HEIGHT=64 SRC="$IMAGE_URL/map/mapsignarmy.png">$i[0]|,
	"army",
	""
	);

# --- No.8 의 위치 정의 ---

($Pname[8],$Pimage[8],$Plink[8],$Pguest[8])=(
	"도서관",
	qq|$space<IMG WIDTH=112 HEIGHT=80 SRC="$IMAGE_URL/map/house1c.png">|,
	"action.cgi?key=library",
	"action.cgi?key=library"
	);

# --- No.9 의 위치 정의 ---

($Pname[9],$Pimage[9],$Plink[9],$Pguest[9])=(
	"게시판",
	qq|<br><br><IMG WIDTH=32 HEIGHT=32 SRC="$IMAGE_URL/map/mapboard.png">|.GetTime2FormatTime((stat($COMMON_DIR.'/treelog.cgi'))[9]+0,1),
	"treebbs",
	""
	);

# --- 아래에 No.10, No.11처럼 계속 늘려 갈 수 있습니다.


# --- 캬라쿠타의 세리후 ---
# 보할 수 있도록보기마네에서 사용자 지정해 주세요(오

sub CharaDefine
{
@chara=();
	if ($DTevent{rebel})
		{
		$chara[1]=TagChara('대변다.... 지원군을 호출바없으면!',"d2");
		$chara[2]=TagChara('반란다!가세력에줄쿠조',"d1");
		$chara[5]=TagChara('영주를 쓰러짐세',"d1")."<br>".TagChara('단번에에케리를 붙할 수 있도록',"d1");
		return;
		}
my $i=int($NOW_TIME / 3600) % 4;
	if ($i == 0)
		{
		$chara[0]=TagChara("슬라임에게 당해 버렸어...","e1").$vspace.$vspace;
		$chara[4]=$space.TagChara("식사의 재료구매이에들르지 않고차.","e2");
		}
	elsif ($i == 1)
		{
		$chara[7]=$vspace.$vspace.TagChara("도서관의 정보는 중요다요","b2").$space
			.TagChara("게시판의 확인도중요다네. 후무후무...","b1");
		}
	elsif ($i == 2)
		{
		$chara[4]=$vspace.TagChara("포카포카하고기분치에에오...","c2");
		$chara[6]=TagChara("매입은 역시".$DT[0]->{shopname}."요네","c1").$space;
		}
	elsif ($STATE->{safety} < 4000)
		{
		my $lid=$id2idx{$STATE->{leader}};
		$chara[0]=TagChara(($STATE->{leader} ? $DT[$lid]->{name} : $BAL_NAME).'의폭정치에판단고정헌터이!',"a1")
			.TagChara('모와 시장민의 안정전체를 생각에로',"a2");
		}
}
1;

