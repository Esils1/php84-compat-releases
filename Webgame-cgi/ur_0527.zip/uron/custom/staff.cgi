#!/usr/bin/perl
# 스태프 롤 2005/03/30 유래
#
# 각종 저작권 표시용입니다. 새 소재나 프로그램을 추가할 때 여기에 기록하세요.
# HTML을 알고 있다면 표시 형식을 원하는 대로 조정할 수 있습니다.
#
# 스태프 롤의 링크를 삭제하거나 눈에 띄지 않게 만들면 안 됩니다.
# 저작권 표시는 적절한 위치에 표시해야 하며, 누락하면 법적 문제가 생길 수 있습니다.

DataRead();
CheckUserPass(1);
OutError("비밀번호가 노출될 위험이 있으므로 표시하지 않습니다.") if $Q{u};
$MENUSAY=GetMenuTag('town','[거리 안내]');
$disp.="<BIG>●개발 스태프 목록</BIG><br><br>";
$disp.=$TB.$TR.$TD.GetTagImgKao("안내인","guide").$TD;
$disp.='게임 각 부분의 저작권은 아래 명시된 권리자에게 있습니다.<br>';
$disp.='또한, 소재를 게임에서 직접 추출해 이용하지 마세요.'.$TRE.$TBE;
$disp.="<br>".$TBT.$TRT.$TD;

# ----------- 아래 내용을 자유롭게 수정할 수 있습니다. -----------------------------

$disp.=<<"HTML";
<SPAN>제작·저작</SPAN> : 유래 ... <A HREF="http://akimono.org/" target="_blank">상인 이야기</A>
<br><br>
<SPAN>원작</SPAN> : MU 님 ... <A HREF="http://mutoys.com/" target="_blank">MUTOYS</A>
<br><br>
<SPAN>우동·메밀국수 사양 원작</SPAN> : 루미코 님 ... <A HREF="http://rumiko.cside.tv/index.htm" target="_blank">SOLD OUT 번호외지</A>
<br><br>
<SPAN>로고·직업 일러스트</SPAN> : 시즈 님 ... <A HREF="http://www2.holon.dyndns.org/~musou/" target="_blank">벽지의 공간 시즈치</A>
<br><br>
<SPAN>아이콘(추가)</SPAN> : 센타 님 · 아슈 님
<br><br>
<SPAN>지도·캐릭터</SPAN> : 미와코 님 ... <A HREF="http://sweetpunch.or.tv/akimono1/index.html" target="_blank"> Ｓｗｅｅｔ Ｐｕｎｃｈ</A>
<br><br>
<SPAN>음악</SPAN> : 다무 님 ... <A HREF="http://www.tam-music.com/" target="_blank">ＴＡＭ Ｍｕｓｉｃ Ｆａｃｔｏｒｙ</A>
HTML

# ----------- 여기까지. 마지막의 'HTML' 행을 지우지 않도록 주의하세요. -----------------

require "skin.pl" if -e "skin.pl";
$disp.=$TRE.$TBE;
OutSkin();
1;
