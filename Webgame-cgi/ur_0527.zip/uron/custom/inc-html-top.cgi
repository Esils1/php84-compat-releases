#!/usr/bin/perl
# 상위표시 2005/01/06 유래

my ($page,$pagestart,$pageend,$pagenext,$pageprev,$pagemax)
	=GetPage($Q{pg},$TOP_RANKING_PAGE_ROWS,$DTusercount);

$disp.="<BIG>●상위 ${TOP_RANKING_PAGE_ROWS}개 점포</BIG>:".GetMenuTag('log','[상세]','&t=4')."<br><br>";
$disp.=$TB;

	$disp.=$TR;
	$disp.=$TDB."점수";
	$disp.=$TDB."점장";
	$disp.=$TDB."직업";
	$disp.=$TDB."상점명 / 인기";
	$disp.=$TDB."이번 기수 매출";
	$disp.=$TDB."자금";
	$disp.=$TDB."숙련";
	$disp.=$TDB."상품 [창업] 댓글";
	$disp.=$TRE;

foreach my $idx ($pagestart..$pageend)
{
	my $DT=$DT[$idx];

	my $rankupdown="(신)";
	if($DT->{rankingyesterday})
	{
		$rankupdown=$DT->{rankingyesterday}-$idx-1;
		$rankupdown=$rankupdown==0 ? " → ": $rankupdown<0 ? "↓".(-$rankupdown) : "↑".$rankupdown;
		$rankupdown="<small>($rankupdown)</small>";
	}
	my $itemtype=-1;
	my $itempro="";
	my $salelist="";
	foreach(0..$DT->{showcasecount}-1)
	{
		my $no=$DT->{showcase}[$_];
		$salelist.=GetTagImgItemType($no);
		$itemtype=0,next if $itemtype!=-1 && $ITEM[$no]->{type}!=$itemtype;
		$itemtype=$ITEM[$no]->{type};
	}
	$itempro=GetTagImgItemType(0,$itemtype,1)." " if $itemtype;
	my $itemno=$DT->{showcase}[0];
	if ($itemno==44)
	{
	$salelist.=($DT->{user}->{udon}) ? " $DT->{user}->{udon}" : " (다른 점포의 원본우동)";
	$salelist.=" ".GetMoneyString($DT->{price}[0]);
	}
	elsif ($itemno==56)
	{
	$salelist.=($DT->{user}->{soba}) ? " $DT->{user}->{soba}" : " (다른 점포의 원본메밀국수)";
	$salelist.=" ".GetMoneyString($DT->{price}[0]);
	}
	elsif ($itemno)
	{
	$salelist.=" ".$ITEM[$itemno]->{name}." ".GetMoneyString($DT->{price}[0]);
	}

	my $expsum=0;
	foreach(values(%{$DT->{exp}})){$expsum+=$_;}
	$expsum=int($expsum/10)."%";

	$disp.=$TR;
	$disp.="<td align=right><b>No.".($idx+1)."</b>".$rankupdown;
	$disp.="<br>".$DT->{point};
	$disp.=$TDNW.$tdh_pt.GetTagImgKao($DT->{name},$DT->{icon});
	$disp.="<td align=center>".GetTagImgJob($DT->{job},$DT->{icon});
	$disp.=$TD.$tdh_nm;
	$disp.= "<a href=\"shop.cgi?ds=$DT->{id}&$USERPASSURL\">" if !$GUEST_USER;
	$disp.= GetTagImgGuild($DT->{guild}).$job.$DT->{shopname};
	$disp.= "</a>" if !$GUEST_USER;
	$disp.=GetTopCountImage($DT->{rankingcount}+0) if $DT->{rankingcount};
	$disp.="<BR>";
	$disp.=GetRankMessage($DT->{rank});
	$disp.=$TDNW.$tdh_ts.GetMoneyString($DT->{saletoday});
	$disp.=$TDNW.$tdh_mo.GetMoneyMessage($DT->{money});
	$disp.=$TDNW.$tdh_ex.$expsum;

	$disp.=$TD;

	$disp.=$tdh_sc.$itempro.$salelist;

	$disp.="<BR>";

	$disp.=$tdh_fd."[".GetTime2found($NOW_TIME-$DT->{foundation})."]";
	$disp.=$tdh_cm.$DT->{comment} if $DT->{comment};
	$disp.=$TRE;
}
$disp.=$TBE;
1;
