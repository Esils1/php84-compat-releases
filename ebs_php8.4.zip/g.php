<?php
require_once __DIR__ . '/lib_ebs.php';
ebs_header_html();
ebs_touch_current_cookie_player_online();
ebs_bootstrap_runtime_counts();
$players = ebs_players_load();
$onlineRows = ebs_online_players($players, 900);
$active = count($onlineRows);
$onlineNames = ebs_online_names_text($players, 900);
$notice = trim(preg_replace('/\s+/u', ' ', strip_tags(str_replace(['<br>','<br/>','<br />'], ' ', (string)ebs_v('COMMENT_1', '')))));
$add = trim(preg_replace('/\s+/u', ' ', strip_tags(str_replace(['<br>','<br/>','<br />'], ' ', (string)ebs_v('adminad', '')))));
if ($notice === '') $notice = 'No';
if ($add === '') $add = 'No';
?>
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>ENDLESS BATTLE</title></head>
<body bgcolor="black" text="white" link="white" vlink="white" alink="white" leftmargin="0" marginwidth="0" topmargin="0" marginheight="0" style="margin:0;font-size:13px;line-height:20px;overflow:hidden;">
<table border="1" bordercolordark="black" bordercolorlight="black" width="100%" height="56" cellspacing="0" cellpadding="2" style="height:56px;table-layout:fixed;">
<tr bgcolor="black" bordercolordark="black" bordercolorlight="black" style="height:28px;line-height:22px;">
<td width="46%" nowrap>공지사항 : <marquee behavior="scroll" direction="left" scrollamount="3" style="display:inline-block;width:82%;vertical-align:middle;"><?php echo ebs_h($notice); ?></marquee></td>
<td width="38%" nowrap>추가사항 : <marquee behavior="scroll" direction="left" scrollamount="3" style="display:inline-block;width:78%;vertical-align:middle;"><?php echo ebs_h($add); ?></marquee></td>
<td width="16%" nowrap align="right">참전자 <?php echo ebs_h((string)count($players)); ?>명 / 접속 <?php echo ebs_h((string)$active); ?>명</td>
</tr>
<tr bgcolor="black" bordercolordark="black" bordercolorlight="black" style="height:28px;line-height:22px;">
<td colspan="3" nowrap>현재 접속자 : <marquee behavior="scroll" direction="left" scrollamount="3" style="display:inline-block;width:82%;vertical-align:middle;"><?php echo ebs_h($onlineNames); ?></marquee></td>
</tr>
</table>
</body></html>
