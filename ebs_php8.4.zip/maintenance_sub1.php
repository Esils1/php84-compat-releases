<?php
declare(strict_types=1);
require_once __DIR__ . '/lib_ebs.php';
/** 원본 legacy 파일: maintenance_sub1.php
 * PHP 8.4 보조 관리 처리. 원본의 히스토리/업데이트/백업 처리 명령을 파일 저장 방식으로 연결한다.
 */
$cmd = ebs_cmd('MAINTE2');
if (!ebs_admin_ok()) { ebs_admin_login_form(basename(__FILE__), '운영 관리'); return; }
switch ($cmd) {
    case 'HISTORYS':
    case 'HISMAKE':
    case 'HISMAKES':
        $hist = ebs_json_load('history_data');
        if (isset($_POST['his'])) $hist[date('YmdHis')] = ebs_param('his');
        ebs_json_save('history_data', $hist);
        ebs_admin_menu('maintenance.php'); break;
    case 'HISDELETE':
        $hist = ebs_json_load('history_data'); unset($hist[ebs_param('his')]); ebs_json_save('history_data',$hist); ebs_admin_menu('maintenance.php'); break;
    case 'UPDATA':
    case 'UPDMAKE':
    case 'UPDMAKES':
        $up = ebs_json_load('updata'); if (isset($_POST['upd'])) $up[date('YmdHis')] = ebs_param('upd'); ebs_json_save('updata',$up); ebs_admin_menu('maintenance.php'); break;
    case 'UPDDELETE':
        $up = ebs_json_load('updata'); unset($up[ebs_param('upd')]); ebs_json_save('updata',$up); ebs_admin_menu('maintenance.php'); break;
    case 'G_BBACKUP': ebs_admin_backup_run(); break;
    case 'G_BHUKUGEN':
    case 'K_G_BHUKUGEN': ebs_admin_restore_run(); break;
    case 'IPTEST':
    case 'FILECHECK': ebs_admin_cookies_screen('maintenance.php'); break;
    default: ebs_admin_menu('maintenance.php'); break;
}
?>
