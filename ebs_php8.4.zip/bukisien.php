<?php
declare(strict_types=1);
require_once __DIR__ . '/lib_ebs.php';

function ebs_bukisien_post(string $key, string $default=''): string { return trim(ebs_param($key, $default)); }
function ebs_bukisien_row(array $f): string {
    $id = $f['id'] !== '' ? $f['id'] : 'newweapon';
    $vals = [
        $f['bname'] !== '' ? $f['bname'] : '신규무기',
        (string)max(0, (int)$f['kougeki']),
        (string)max(0, (int)$f['meityuu']),
        (string)max(0, (int)$f['kaisuu']),
        (string)max(0, (int)$f['en']),
        (string)max(0, (int)$f['money']),
        (string)max(0, (int)$f['nyuusyu']),
        $f['kouka'],
        (string)max(0, (int)$f['kakuritu']),
    ];
    return '"'.$id.'"=>"'.implode(',', $vals).'",';
}
function ebs_PASS2(): void { ebs_MAIN2(); }
function ebs_PASS(): void { ebs_MAIN2(); }
function ebs_MAIN(): void { ebs_MAIN2(); }
function ebs_MAIN2(): void {
    ebs_header_html();
    ebs_record_post('bukisien.php::MAIN2');
    $f = [];
    foreach (['id','bname','kougeki','meityuu','kaisuu','en','money','nyuusyu','kouka','kakuritu'] as $k) $f[$k] = ebs_bukisien_post($k, '');
    $line = ebs_bukisien_row($f);
    $atkRank = ebs_status_rank((int)$f['kougeki']);
    $hitRank = ebs_status_rank((int)$f['meityuu']);
    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>무기작성 지원모드</title></head>';
    echo '<body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="font-size:13px;margin:0;"><center>';
    echo '<form action="bukisien.php" method="POST" name="main" target="Sub"><input type="hidden" name="cmd" value="MAIN2">';
    echo '<table border="1" cellpadding="4" cellspacing="0" bgcolor="#f7f7f7" style="color:#111111;font-size:13px;">';
    echo '<tr><td bgcolor="#666666" colspan="10" align="center"><font color="#ffffff">무기작성 지원모드</font></td></tr>';
    echo '<tr><td colspan="10" bgcolor="#cccccc">무기능력설정</td></tr>';
    $headers = ['무기아이디'=>'id','무기명'=>'bname','공격력'=>'kougeki','명중률'=>'meityuu','공격회수'=>'kaisuu','EN소비'=>'en','금액'=>'money','입수방법'=>'nyuusyu','특수효과'=>'kouka','입수확률'=>'kakuritu'];
    echo '<tr>'; foreach ($headers as $h=>$k) echo '<td bgcolor="#666666"><font color="#ffffff">'.ebs_h($h).'</font></td>'; echo '</tr><tr>';
    foreach ($headers as $h=>$k) echo '<td><input type="text" name="'.ebs_h($k).'" value="'.ebs_h($f[$k]).'" size="'.($k==='bname'?20:8).'"></td>';
    echo '</tr><tr><td colspan="10" align="center"><input type="submit" value="결정" '.ebs_v('STYLE_B1').'> <input type="reset" value="리셋" '.ebs_v('STYLE_B1').'></td></tr>';
    echo '<tr><td colspan="10" bgcolor="#cccccc">무기능력표시</td></tr><tr>';
    foreach ($headers as $h=>$k) echo '<td bgcolor="#666666"><font color="#ffffff">'.ebs_h($h).'</font></td>'; echo '</tr><tr>';
    echo '<td>'.ebs_h($f['id']).'</td><td>'.ebs_h($f['bname']).'</td><td align="center">'.$atkRank.'</td><td align="center">'.$hitRank.'</td><td>'.ebs_h($f['kaisuu']).'</td><td>'.ebs_h($f['en']).'</td><td>'.ebs_h($f['money']).'</td><td>'.ebs_h($f['nyuusyu']).'</td><td>'.ebs_weapon_effects($f['kouka'], '').'</td><td>'.ebs_h($f['kakuritu']).'</td></tr>';
    echo '<tr><td colspan="10">아래를 복사하여 <b>log/_buki.data</b>에 추가하세요.<br><input type="text" size="120" value="'.ebs_h($line).'"></td></tr>';
    echo '</table></form></center></body></html>';
}
$map = ['PASS'=>'ebs_PASS','PASS2'=>'ebs_PASS2','MAIN'=>'ebs_MAIN','MAIN2'=>'ebs_MAIN2'];
ebs_dispatch($map, 'ebs_MAIN2');
?>
