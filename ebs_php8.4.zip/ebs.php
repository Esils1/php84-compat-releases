<?php
declare(strict_types=1);
require_once __DIR__ . '/lib_ebs.php';
/**
 * 원본 legacy 파일: ebs.php
 * PHP 8.4 파일당 1:1 대응 변환 파일.
 * 원본 주석은 PHP // 주석으로 보존하고, 기존 실행 의존은 제거하고 PHP 8.4 파일 기반으로 동작시킨다.
 * 유지보수 시 원본 sub 이름과 아래 ebs_함수명을 대조한다.
 */
// _/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/
//
// The Endless Battle program Satellite
// Copyright Net Game Communications All Rights reserved
//
// _/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/

$routes = [
    'ADMIN_LOGOUT' => ['file' => 'ebs_sub7.php', 'cmd' => 'ADMIN_LOGOUT'],
    'AP' => ['file' => 'ebs_sub5.php', 'cmd' => 'AP2'],
    'BATTLE_1' => ['file' => 'ebs_sub4.php', 'cmd' => 'BATTLE1'],
    'BATTLE_2' => ['file' => 'ebs_sub4.php', 'cmd' => 'BATTLE2'],
    'BATTLE_3' => ['file' => 'wars.php', 'cmd' => 'STATUS'],
    'BOSS' => ['file' => 'ebs_sub5.php', 'cmd' => 'BOSS2'],
    'BOSS_LOOK' => ['file' => 'ebs_sub5.php', 'cmd' => 'BOSS_LOOK2'],
    'BOUGU' => ['file' => 'ebs_sub5.php', 'cmd' => 'BOUGU2'],
    'BOUGU_DATA' => ['file' => 'ebs_sub7.php', 'cmd' => 'BOUGU_DATA'],
    'BOUGU_SAVE' => ['file' => 'ebs_sub7.php', 'cmd' => 'BOUGU_SAVE'],
    'NOTICE' => ['file' => 'ebs_sub7.php', 'cmd' => 'NOTICE'],
    'NOTICE_SAVE' => ['file' => 'ebs_sub7.php', 'cmd' => 'NOTICE_SAVE'],
    'CONFIG_EDIT' => ['file' => 'ebs_sub7.php', 'cmd' => 'CONFIG_EDIT'],
    'CONFIG_SAVE' => ['file' => 'ebs_sub7.php', 'cmd' => 'CONFIG_SAVE'],
    'CHAT' => ['file' => 'ebs_sub2.php', 'cmd' => 'CHAT2'],
    'CHAT_FRAME' => ['file' => 'ebs_sub2.php', 'cmd' => 'CHAT2'],
    'CITY' => ['file' => 'ebs_sub5.php', 'cmd' => 'CITY2'],
    'CNSYUSEI' => ['file' => 'ebs_sub7.php', 'cmd' => 'CNSYUSEI2'],
    'COM' => ['file' => 'ebs_sub5.php', 'cmd' => 'COMMENT'],
    'CO_LIST' => ['file' => 'ebs_sub3.php', 'cmd' => 'CNTRY_LIST'],
    'CUSTOM' => ['file' => 'ebs_sub3.php', 'cmd' => 'CUSTOMIZE'],
    'CUSTOMING' => ['file' => 'ebs_sub5.php', 'cmd' => 'CUSTOMING2'],
    'C_LIST' => ['file' => 'ebs_sub2.php', 'cmd' => 'C_LIST2'],
    'DECODE' => ['file' => 'ebs_sub6.php', 'cmd' => 'INPORT4'],
    'DELETE' => ['file' => 'ebs_sub6.php', 'cmd' => 'DELETE3'],
    'DELETE2' => ['file' => 'ebs_sub6.php', 'cmd' => 'DELETE4'],
    'DEL_U' => ['file' => 'ebs_sub5.php', 'cmd' => 'DEL_U2'],
    'DEL_UNIT' => ['file' => 'ebs_sub5.php', 'cmd' => 'DEL_UNIT'],
    'ENTRY' => ['file' => 'ebs_sub6.php', 'cmd' => 'ENTRY2'],
    'EP' => ['file' => 'ebs_sub5.php', 'cmd' => 'EP2'],
    'EQUIPMENT' => ['file' => 'ebs_sub5.php', 'cmd' => 'EQUIP'],
    'EXPORT' => ['file' => 'ebs_sub6.php', 'cmd' => 'EXPORT2'],
    'FINANCE' => ['file' => 'ebs_finance.php', 'cmd' => 'FINANCE2'],
    'GAME_FRAME' => ['file' => 'ebs_sub3.php', 'cmd' => 'FRAME2'],
    'GOUSEI_PON' => ['file' => 'ebs_sub5.php', 'cmd' => 'CUSTOMING2'],
    'GOUSEI_PON3' => ['file' => 'ebs_sub5.php', 'cmd' => 'CUSTOMING2'],
    'HEA' => ['file' => 'ebs_sub5.php', 'cmd' => 'HEA2'],
    'HES' => ['file' => 'ebs_sub5.php', 'cmd' => 'HES2'],
    'HIS' => ['file' => 'ebs_sub5.php', 'cmd' => 'HISTORY'],
    'HISA' => ['file' => 'ebs_sub5.php', 'cmd' => 'HISALL2'],
    'HISTORY_EDIT' => ['file' => 'ebs_sub7.php', 'cmd' => 'HISTORY_EDIT2'],
    'HISTORY_EDIT2' => ['file' => 'ebs_sub7.php', 'cmd' => 'HISTORY_EDIT3'],
    'HISTORY_EDIT_SAVE' => ['file' => 'ebs_sub7.php', 'cmd' => 'HISTORY_EDIT2'],
    'UPDATE_EDIT' => ['file' => 'ebs_sub7.php', 'cmd' => 'UPDATE_EDIT2'],
    'UPDATE_EDIT2' => ['file' => 'ebs_sub7.php', 'cmd' => 'UPDATE_EDIT3'],
    'UPDATE_EDIT_SAVE' => ['file' => 'ebs_sub7.php', 'cmd' => 'UPDATE_EDIT2'],
    'ICON' => ['file' => 'ebs_sub2.php', 'cmd' => 'ICON_LIST'],
    'INPORT' => ['file' => 'ebs_sub6.php', 'cmd' => 'INPORT2'],
    'INPORT5' => ['file' => 'ebs_sub6.php', 'cmd' => 'INPORT3'],
    'KAKUNIN' => ['file' => 'ebs_sub6.php', 'cmd' => 'KAKUNIN2'],
    'KAMO2' => ['file' => 'ebs_sub5.php', 'cmd' => 'KAMO2'],
    'LGIN_RIREKI' => ['file' => 'ebs_sub7.php', 'cmd' => 'LGIN_RIREKI2'],
    'LIST' => ['file' => 'ebs_sub3.php', 'cmd' => 'MY_LIST'],
    'LOG0' => ['file' => 'ebs_sub2.php', 'cmd' => 'LOG01'],
    'LOGIN' => ['file' => 'ebs_sub2.php', 'cmd' => 'LOGIN2'],
    'LOGO' => ['file' => 'ebs_sub2.php', 'cmd' => 'LOGO2'],
    'LOTO' => ['file' => 'ebs_sub5.php', 'cmd' => 'LOTO2'],
    'MAINTE' => ['file' => 'ebs_sub7.php', 'cmd' => 'MAINTENANCE'],
    'MAINTE2' => ['file' => 'ebs_sub7.php', 'cmd' => 'MAINTENANCE2'],
    'MAIN_FRAME' => ['file' => 'ebs_sub3.php', 'cmd' => 'STATUS'],
    'MAKE_C' => ['file' => 'ebs_sub5.php', 'cmd' => 'MAKE_C2'],
    'MAKE_T' => ['file' => 'ebs_sub5.php', 'cmd' => 'MAKE_T2'],
    'MISSION' => ['file' => 'ebs_sub5.php', 'cmd' => 'MISSION2'],
    'MONEY' => ['file' => 'ebs_sub5.php', 'cmd' => 'KENKIN'],
    'MY_LIST' => ['file' => 'ebs_sub2.php', 'cmd' => 'MY_LIST2'],
    'NUMBERS' => ['file' => 'numbers.php', 'cmd' => 'NUMBERS2'],
    'NUMBERS3' => ['file' => 'numbers.php', 'cmd' => 'NUMBERS4'],
    'PEREE' => ['file' => 'ebs_sub5.php', 'cmd' => 'PEREE2'],
    'PL_DEL' => ['file' => 'ebs_sub7.php', 'cmd' => 'PL_DEL2'],
    'PL_DEL2' => ['file' => 'ebs_sub7.php', 'cmd' => 'PL_DEL3'],
    'POWER' => ['file' => 'ebs_sub5.php', 'cmd' => 'POWER2'],
    'PR' => ['file' => 'ebs_sub5.php', 'cmd' => 'PR2'],
    'PRE' => ['file' => 'ebs_sub5.php', 'cmd' => 'JOUTO'],
    'RESIST' => ['file' => 'ebs_sub6.php', 'cmd' => 'RESIST2'],
    'RR' => ['file' => 'ebs_sub5.php', 'cmd' => 'RR2'],
    'SPC' => ['file' => 'ebs_sub5.php', 'cmd' => 'SPECIAL'],
    'SPS' => ['file' => 'ebs_sub5.php', 'cmd' => 'SPS2'],
    'STATUSUP' => ['file' => 'ebs_sub5.php', 'cmd' => 'STATUSUP2'],
    'ST_RESET' => ['file' => 'ebs_sub5.php', 'cmd' => 'ST_RESET2'],
    'SUBBS_LOOK' => ['file' => 'ebs_sub5.php', 'cmd' => 'SUBBS_LOOK2'],
    'SYUSEI' => ['file' => 'ebs_sub7.php', 'cmd' => 'SYUSEI2'],
    'TOP' => ['file' => 'ebs_sub3.php', 'cmd' => 'FRAME'],
    'TRADE' => ['file' => 'ebs_sub5.php', 'cmd' => 'TRADE2'],
    'UPD' => ['file' => 'ebs_sub5.php', 'cmd' => 'UPDATA2'],
    'UPMENU' => ['file' => 'ebs_sub2.php', 'cmd' => 'UPMENU2'],
    'UP_G' => ['file' => 'ebs_sub5.php', 'cmd' => 'UP_G2'],
    'VAR' => ['file' => 'various.php', 'cmd' => 'TOP'],
    'WEAPON' => ['file' => 'ebs_sub2.php', 'cmd' => 'WEAPON_LIST'],
    'XCO_LIST' => ['file' => 'ebs_sub7.php', 'cmd' => 'XCO_LIST2'],
    'XPL_LIST' => ['file' => 'ebs_sub7.php', 'cmd' => 'XPL_LIST2'],
];
$cmd = ebs_cmd('TOP');
$route = $routes[$cmd] ?? $routes['TOP'];
$GLOBALS['EBS_FORCE_CMD'] = $route['cmd'];
$f = __DIR__ . '/' . $route['file'];
if (is_file($f)) { require $f; return; }
ebs_header_html(); echo '<html><body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'"><center>route not found: '.ebs_h((string)$cmd).'</center></body></html>';  
?>
