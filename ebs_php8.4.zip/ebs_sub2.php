<?php
declare(strict_types=1);
require_once __DIR__ . '/lib_ebs.php';
/**
 * 원본 legacy 파일: ebs_sub2.php
 * PHP 8.4 파일당 1:1 대응 변환 파일.
 * 원본 주석은 PHP // 주석으로 보존하고, 기존 실행 의존은 제거하고 PHP 8.4 파일 기반으로 동작시킨다.
 * 유지보수 시 원본 sub 이름과 아래 ebs_함수명을 대조한다.
 */
// // 역사 란
// 여기 삽입용
// ////////체팅 ///////////////////////////
// &CUSTOM_HEADER('Sub');
// 채팅방 option 주고 싶으면 아래 코맨트 제거 (예로 글씨 크게, 대화방 세로형)
// $chatroom = $chatroom . "&fontlarge=true&position=2";
// PHP 채팅/닉네임 연동 보정 시작 ###################
// $usernickz= 유저 별명/닉네임 변수; 없으면 그냥 my $usernickz = $userz; 해보세요.
// PHP 채팅/닉네임 연동 보정 끝 ###################

function ebs_LOGIN2(): void {
    ebs_header_html();
    ebs_record_post('ebs_sub2.php::LOGIN2');
    // 원본 연결 함수: nbsp
    echo '	<!DOCTYPE HTML PUBLIC -//IETF//DTD HTML//EN>
	<html><head>
	<script language="JavaScript">
		function showform(){login.style.visibility=\'visible\';}
		function hideform(){login.style.visibility=\'hidden\';}
		function showdata(){data.style.visibility=\'visible\';}
		function hidedata(){data.style.visibility=\'hidden\';}
	</script>
	<style type="text/css">
		a:link    {font-size: 17px; text-decoration:none; color:'.ebs_v('LINK').'; }
		a:visited {font-size: 17px; text-decoration:none; color:'.ebs_v('LINK').'; }
		a:active  {font-size: 17px; text-decoration:none; color:'.ebs_v('LINK').'; }
		a:hover   {font-size: 17px; text-decoration:none; color:'.ebs_v('HOVER').'; }
	</style>
	<meta http-equiv="Content-Type" content="text/html" >
	<META HTTP-EQUIV="Pragma" CONTENT="no-cache">
	<body '.ebs_bg_attr('BG_TOP').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" link="'.ebs_h(ebs_v('LINK')).'" style="margin:0px 0px 0px 0px;" oncontextmenu="return false;">
	<a name=#top>
	<table width=100% height=100% id="login" style="position:absolute;visibility:hidden;"><tr><td align=center>
		<table border=0 cellpadding=0 cellspacing=0 bgcolor="'.ebs_v('TABLE_COLOR1').'" align=center style="border:3px solid '.ebs_v('TABLE_BORDER').';font-size:16px;">
		<form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST" name=frm1 style="margin:0px 0px 0px 0px;">
		<tr><td style="background-color:'.ebs_v('TABLE_COLOR2').';" colspan=2>
		&nbsp;Log In</td>
		<td style="background-color:'.ebs_v('TABLE_COLOR2').';" align=right><a href="Javascript:hideform();"><b>Close</b></A></td></tr>
		<tr><td align=center>
			<input type=hidden name="cmd" value="MAIN_FRAME">
		<input type=hidden name="login" value="'.ebs_v('DATE').'">
		<b>ID</b></td>
		<td><input type=text name="pname" value="'.ebs_h(ebs_cookie_value('pname')).'" '.ebs_v('STYLE_L').'></td><td>&nbsp;</td></tr>
		<tr><td align=center><b>PASS</b></td>
		<td><input type=password name="pass" value="'.ebs_h(ebs_cookie_value('pass')).'" '.ebs_v('STYLE_L').'>
		</td><td>&nbsp;
	<input type=submit name=lgn value=로그인  style="height:21px; background:#808080;color:#ededed; font-size:15px;">	


		</td></tr></form></table>
	</td></tr></table>

	<table width=100% height=100% id="data" style="position:absolute;visibility:hidden;"><tr><td align=center>
		<table border=0 cellpadding=0 cellspacing=0 bgcolor="'.ebs_v('TABLE_COLOR1').'" align=center style="border:3px solid '.ebs_v('TABLE_BORDER').';font-size:16px;">
		<tr><td style="background-color:'.ebs_v('TABLE_COLOR2').';" colspan=2>
		&nbsp;Data</td>
		<td style="background-color:'.ebs_v('TABLE_COLOR2').';" align=right><a href="Javascript:hidedata();"><b>close</b></a></td></tr>
			<td></td><td>&nbsp;</td></tr>';
    if (ebs_v('SATELLITE_FLAG','0') === '1') {
        echo '		<tr><td><a href="'.ebs_v('MAIN_SCRIPT').'?EXPORT" target="_top" style="font-size:20px;"><b>DataExport</b></a></td>
			<td></td><td>&nbsp;</td></tr>
		<tr><td><a href="'.ebs_v('MAIN_SCRIPT').'?INPORT" target="_top" style="font-size:20px;"><b>DataImport</b></a></td>
			<td></td><td>&nbsp;</td></tr>';
    } else {
        echo '		<tr><td colspan="3" style="font-size:16px;line-height:1.6;">DataImport / DataExport : 관리자 설정에서 불가</td></tr>';
    }
    echo '		<tr><td><a href="'.ebs_v('MAIN_SCRIPT').'?WEAPON" target="_top" style="font-size:20px;"><b>WeaponList</b></a></td>
			<td></td><td>&nbsp;</td></tr>
		<tr><td><a href="'.ebs_v('MAIN_SCRIPT').'?ICON" target="_top" style="font-size:20px;"><b>IconList</b></a></td>
			<td></td><td>&nbsp;</td></tr>
		</table>
	</td></tr></table>

	<table border=0 width=100% height=100%>
	<tr><td align=center valign=middle>
	<div align=center style="font-size:55px;color:#ededed;filter:alpha(opacity=100,finishopacity=0,style=2);height:60px;background-color:#fff0f0;color:#555555;"><b>EBS 교~육방송~[탕!]</b></div>
		<br>';
    echo '<img src="'.ebs_v('IMG_FOLDER1').'/manu1.gif" name=m1> ';
    echo '<a href="Javascript:showform();" style="font-size:25px;" onMouseOver="document.m1.src=\''.ebs_v('IMG_FOLDER1').'/manu2.gif\'" onMouseOut="document.m1.src=\''.ebs_v('IMG_FOLDER1').'/manu1.gif\'"><font color=#3366ff><b>Continue</b></font></a>';
    echo '&nbsp;&nbsp;&nbsp;<img src="'.ebs_v('IMG_FOLDER1').'/manu1.gif" name=m4> ';
    echo '<a href="'.ebs_v('MAIN_SCRIPT').'?ENTRY" target="boardmain" style="font-size:25px;" onMouseOver="document.m4.src=\''.ebs_v('IMG_FOLDER1').'/manu2.gif\'" onMouseOut="document.m4.src=\''.ebs_v('IMG_FOLDER1').'/manu1.gif\'"><b>NewGame</b></a>';
    echo '&nbsp;&nbsp;&nbsp;<img src="'.ebs_v('IMG_FOLDER1').'/manu1.gif" name=m2> ';
    echo '<a href="Javascript:showdata();" style="font-size:25px;" onMouseOver="document.m2.src=\''.ebs_v('IMG_FOLDER1').'/manu2.gif\'" onMouseOut="document.m2.src=\''.ebs_v('IMG_FOLDER1').'/manu1.gif\'"><b>Data</b></a>';
    echo '<br><br><div align="center" style="font-size:14px;color:#ffffff;line-height:1.6;">'.ebs_v('COMMENT_1').'</div>';
    echo '<div align=right><a href="'.ebs_h(ebs_v('THIS_DIR')).'/maintenance.php" target="_top">Version '.ebs_h(ebs_v('VER')).'</a> / <a href="'.ebs_h(ebs_v('THIS_DIR')).'/d_mainte.php" target="_top">Dungeon</a></div>';
    echo '</td></tr></table></body></html>';
}

function ebs_UPMENU2(): void {
    ebs_header_html();
    ebs_record_post('ebs_sub2.php::UPMENU2');
    echo '<table border="1" bordercolordark="black" bordercolorlight="black" width="100%" height="100%">
    <tr bgcolor="black" bordercolordark="black" bordercolorlight="black">
        <td width="100%" height="100%" bordercolordark="black" bordercolorlight="black"><font color="#111111"> dkdkdkdk</td>
    </tr>
</table>';
}

function ebs_LOG01(): void {
    ebs_header_html();
    ebs_bootstrap_runtime_counts();
    $players = ebs_players_load();
    $entryCount = count($players);
    $dataMove = ebs_v('SATELLITE_FLAG','0') === '1' ? 'YES' : 'NO';
    $tc1=ebs_h(ebs_v('TABLE_COLOR1')); $tc2=ebs_h(ebs_v('TABLE_COLOR2'));
    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>ENDLESS BATTLE</title></head><body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="margin:0px;font-size:15px;">';
    echo '<table border="0" width="100%" cellspacing="0" cellpadding="0"><tr><td style="width:100%;">';
    echo '<table bgcolor="'.$tc1.'" style="border:1px solid #ffffff;font-size:15px;color:'.ebs_h(ebs_v('FONT_COLOR')).'">';
    echo '<tr><td nowrap bgcolor="'.$tc2.'" colspan="4">Site DATA</td></tr>';
    if (ebs_v('OWNER_NAME') !== '') echo '<tr><td nowrap bgcolor="'.$tc2.'">관리인</td><td nowrap colspan="3">'.ebs_h(ebs_v('OWNER_NAME')).'</td></tr>';
    echo '<tr><td nowrap bgcolor="'.$tc2.'">아이콘수</td><td align="right"><b>'.ebs_h(ebs_v('ICON')).'</b></td><td nowrap bgcolor="'.$tc2.'">현재등록인수</td><td nowrap align="right"><b>'.ebs_h((string)$entryCount).'명</b></td></tr>';
    echo '<tr><td nowrap bgcolor="'.$tc2.'">삭제방치기간</td><td nowrap align="right"><b>'.ebs_h(ebs_v('COOKIE_KEEP')).'일</b></td><td nowrap bgcolor="'.$tc2.'">최대등록인수</td><td nowrap align="right"><b>'.ebs_h(ebs_v('ENTRY_MAX')).'명</b></td></tr>';
    echo '<tr><td nowrap bgcolor="'.$tc2.'">HP회복</td><td nowrap align="right"><b>'.ebs_h(ebs_v('HP_REPAIR')).'+α/초</b></td><td nowrap bgcolor="'.$tc2.'">건국비</td><td nowrap align="right"><b>$'.ebs_h(ebs_v('MAKE_COUNTRY')).'</b></td></tr>';
    echo '<tr><td nowrap bgcolor="'.$tc2.'">EN회복</td><td nowrap align="right"><b>'.ebs_h(ebs_v('EN_REPAIR')).'+α/초</b></td><td nowrap bgcolor="'.$tc2.'">부대결성비</td><td nowrap align="right"><b>$'.ebs_h(ebs_v('MAKE_TEAM')).'</b></td></tr>';
    echo '<tr><td nowrap bgcolor="'.$tc2.'">최대나라수</td><td nowrap align="right"><b>'.ebs_h(ebs_v('COUNTRY_MAX')).'</b></td><td nowrap bgcolor="'.$tc2.'">데이타 이동</td><td nowrap align="right">'.ebs_h($dataMove).'</td></tr>';
    echo '</table><br>';
    echo '<iframe src="'.ebs_h(ebs_v('MAIN_SCRIPT')).'?HISA" width="100%" height="200" style="border:1px solid #ffffff;background:#000000;color:#ffffff;width:100%;max-width:100%;box-sizing:border-box;"></iframe>';
    echo '</td></tr></table>';
    echo ebs_v('COMMENT_2');
    echo '<br><br><div style="font-size:15px;font-weight:bold;color:#ffffff;margin-top:30px;">';
    echo 'The ENDLESS BATTLE Program Satellite '.ebs_h(ebs_v('VER')).'<br>Produce By ';
    echo '<a href="http://www.ngcoms.net/" style="font-size:15px;color:#c0c0c0;"><font face="Verdana">&copy NET GAME Communications</font></a> All Right Reserved.<br>';
    echo '<a href="http://adonas.com/" style="font-size:15px;color:#c0c0c0;">한글화 by adonas</a>';
    echo '</div>';
    echo '</body></html>';
}
function ebs_LOGO2(): void {
    ebs_header_html();
    ebs_record_post('ebs_sub2.php::LOGO2');
    // 원본 LOGO2는 로그인 타이틀 화면이 아니라 Sub 프레임을 비우고 COMMENT_3만 표시한다.
    // 전투 후 귀환 시 parent.Sub.location.replace(?LOGO)가 호출되므로 여기서 LOGIN2를 출력하면
    // 하단 프레임에 Continue/NewGame/Data 화면이 끼어드는 문제가 생긴다.
    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>ENDLESS BATTLE</title></head>';
    echo '<body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="margin:0px;font-size:13px;" oncontextmenu="return false;">';
    echo ebs_v('COMMENT_3');
    echo '</body></html>';
}

function ebs_MY_LIST2(): void {
    ebs_header_html();
    ebs_record_post('ebs_sub2.php::MY_LIST2');
    $players = ebs_players_load();
    $pname = ebs_cookie_value('pname', ebs_param('pname',''));
    $current = ($pname !== '' && isset($players[$pname]) && is_array($players[$pname])) ? $players[$pname] : [];
    $country = (string)($current['kuni'] ?? '');
    $countries = ebs_country_records();
    $countryInfo = ($country !== '' && isset($countries[$country]) && is_array($countries[$country])) ? $countries[$country] : [];
    $color = (string)($countryInfo['color'] ?? '#808080');
    $icon = ebs_country_icon((string)($countryInfo['icon'] ?? '1000'));
    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>ENDLESS BATTLE</title></head><body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="margin:0px;" oncontextmenu="return false;">';
    echo '<table border="8" cellspacing="0" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" style="font-size:15px;background:'.ebs_h(ebs_v('TABLE_COLOR1')).';color:'.ebs_h(ebs_v('FONT_COLOR')).';border:8px outset '.ebs_h($color).';">';
    $countryTextColor = ebs_contrast_text_color($color);
    echo '<tr><td colspan="4" bgcolor="'.ebs_h($color).'" style="color:'.ebs_h($countryTextColor).';font-size:30px;"><img src="'.ebs_h(ebs_v('IMG_FOLDER2')).'/'.ebs_h($icon).'.gif" width="40" height="40">&nbsp;&nbsp;'.ebs_h($country !== '' ? $country : ebs_v('NONE_NATIONALITY'));
    if ($country !== '') echo '<span style="font-size:15px;">&nbsp;&nbsp;국비&nbsp;<b>$'.ebs_h((string)($countryInfo['money'] ?? '0')).'</b>&nbsp;&nbsp;최대국민수&nbsp;<b>'.ebs_h((string)($countryInfo['max_member'] ?? '')).'</b></span>';
    echo '</td></tr>';
    foreach ($players as $name=>$pl) {
        if (!is_array($pl)) continue;
        $pkuni = (string)($pl['kuni'] ?? '');
        if ($country !== '' && $pkuni !== $country) continue;
        if ($country === '' && $pkuni !== '') continue;
        $comment = (string)($pl['comment'] ?? 'No-Comment');
        $pcolor = (string)($pl['color'] ?? '#000000');
        $picon = (string)($pl['icon'] ?? '1');
        echo '<tr bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'"><td nowrap style="color:'.ebs_h(ebs_visible_player_color($pcolor, ebs_v('TABLE_COLOR1'))).';">'.ebs_h((string)($pl['name'] ?? $name)).'</td><td>'.ebs_h((string)($pl['rank'] ?? '')).'</td><td><img src="'.ebs_h(ebs_v('IMG_FOLDER2')).'/'.ebs_h(ebs_normalize_icon($picon)).'.gif" width="32" height="32"></td><td style="color:'.ebs_h(ebs_visible_player_color($pcolor, ebs_v('TABLE_COLOR1'))).';">'.ebs_h($comment).'</td></tr>';
    }
    if ($country !== '') {
        $units = [];
        foreach ($players as $nm => $pl) {
            if (!is_array($pl)) continue;
            if ((string)($pl['kuni'] ?? '') !== $country) continue;
            $unitName = trim((string)($pl['unit'] ?? ebs_player_raw_get($pl, 28, '')));
            if ($unitName === '') continue;
            if (!isset($units[$unitName])) $units[$unitName] = [];
            $units[$unitName][$nm] = $pl;
        }
        $unitNo = 1;
        foreach ($units as $unitName => $members) {
            $leader = '';
            foreach ($members as $mn => $mp) {
                $ur = (string)($mp['unit_rank'] ?? '');
                $job = (string)($mp['job'] ?? ebs_player_raw_get($mp, 6, '0'));
                if ($ur === 'leader' || $ur === '1' || $job === '-1') { $leader = (string)($mp['name'] ?? $mn); break; }
            }
            echo '<tr><td colspan="4" bgcolor="'.ebs_h($color).'" style="color:'.ebs_h($countryTextColor).';font-size:25px;">&nbsp;<b>제'.$unitNo.'부대</b>&nbsp;'.ebs_h($unitName).'</td></tr>';
            echo '<tr bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'"><td colspan="4">대장&nbsp;'.ebs_h($leader !== '' ? $leader : '대장없음').'</td></tr>';
            foreach ($members as $mn => $mp) {
                $pcolor = (string)($mp['color'] ?? '#ededed');
                $picon = (string)($mp['icon'] ?? '1');
                echo '<tr bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'"><td nowrap style="color:'.ebs_h(ebs_visible_player_color($pcolor, ebs_v('TABLE_COLOR1'))).';">'.ebs_h((string)($mp['name'] ?? $mn)).'</td><td>'.ebs_h((string)($mp['level'] ?? '1')).'</td><td><img src="'.ebs_h(ebs_v('IMG_FOLDER2')).'/'.ebs_h(ebs_normalize_icon($picon)).'.gif" width="32" height="32"></td><td style="color:'.ebs_h(ebs_visible_player_color($pcolor, ebs_v('TABLE_COLOR1'))).';">'.ebs_h((string)($mp['comment'] ?? 'noComment')).'</td></tr>';
            }
            $unitNo++;
        }
        for ($i=$unitNo; $i<=3; $i++) {
            echo '<tr><td colspan="4" bgcolor="'.ebs_h($color).'" style="color:'.ebs_h($countryTextColor).';font-size:25px;">&nbsp;<b>제'.$i.'부대</b>&nbsp;미결성</td></tr>';
            echo '<tr bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'"><td colspan="4">대장없음</td></tr><tr bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'"><td colspan="4">NoPlayer</td></tr>';
        }
    }
    echo '</table><br><br><br><br><span style="font-size:15px;font-weight:bold;">The ENDLESS BATTLE Program Satellite '.ebs_h(ebs_v('VER')).'<br>Produce By <a href="http://www.ngcoms.net/" style="font-size:15px;color:#606060;">&copy NET GAME Communications</a> All Right Reserved.<br><a href="http://adonas.com/" style="font-size:15px;color:#606060;">한글화 by adonas</a></span></body></html>';
}


function ebs_TR(): void {
    ebs_header_html();
    ebs_record_post('ebs_sub2.php::TR');
    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>ENDLESS BATTLE</title></head><body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="margin:0;font-size:13px;">';
    echo '<center><table border="1" cellspacing="0" cellpadding="6" bordercolor="'.ebs_h(ebs_v('TABLE_BORDER')).'" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" style="min-width:420px;">';
    echo '<tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'" align="center"><b>랭킹 / 기록</b></td></tr>';
    echo '<tr><td align="center" style="line-height:2.0;">';
    echo '<a href="ranking.php" target="Sub">랭킹일람</a><br>';
    echo '<a href="winner.php" target="Sub">우승자/전적</a><br>';
    echo '<a href="ballance.php" target="Sub">세력도/국력도</a><br>';
    echo '<a href="casino.php?cmd=RANKING" target="Sub">카지노 랭킹</a><br>';
    echo '<a href="nextcard.php?cmd=RANKING" target="Sub">Next Card 랭킹</a>';
    echo '</td></tr></table></center></body></html>';
}

function ebs_C_LIST2(): void {
    ebs_header_html();
    ebs_record_post('ebs_sub2.php::C_LIST2');
    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>ENDLESS BATTLE</title></head><body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" link="'.ebs_h(ebs_v('LINK')).'" vlink="'.ebs_h(ebs_v('VLINK')).'" style="margin:0;font-size:13px;" oncontextmenu="return false;"><center><br>';
    // 원본 C_LIST2: file_INPORT(C) 후 국가 선택 버튼 전체 출력.
    ebs_render_country_buttons('Sub');
    echo '</center></body></html>';
}

function ebs_WEAPON_LIST(): void {
    ebs_header_html();
    ebs_record_post('ebs_sub2.php::WEAPON_LIST');
    $weapons = ebs_weapon_table();
    $selected = ebs_param('wname', '');
    if ($selected === '' && $weapons) {
        $keys = array_keys($weapons);
        $selected = (string)$keys[0];
    }
    $opt = '';
    foreach ($weapons as $key => $w) {
        if (!is_array($w)) continue;
        // 장비 화면의 무기구입 select와 동일한 원본 무기 테이블/동일 순서를 사용한다.
        // 가격이 있는 무기는 검색 리스트에도 가격을 같이 표시하여 두 목록을 육안상 동일하게 맞춘다.
        $price = max(0, (int)($w[5] ?? 0));
        if ($price <= 0) continue;
        $label = (string)($w[0] ?? $key).' $'.number_format($price);
        $opt .= '<option value="'.ebs_h((string)$key).'"'.((string)$key === (string)$selected ? ' selected' : '').'>'.ebs_h($label)."
";
    }
    if ($opt === '') {
        foreach ($weapons as $key => $w) {
            if (!is_array($w)) continue;
            $opt .= '<option value="'.ebs_h((string)$key).'"'.((string)$key === (string)$selected ? ' selected' : '').'>'.ebs_h((string)($w[0] ?? $key))."
";
        }
    }
    $cur = $weapons[$selected] ?? [];
    $pregen = '';
    $nextgen = '';
    $originName = '';
    $sedai = $selected !== '' ? strlen($selected) : 0;
    if ($selected !== '') {
        $preKey = substr($selected, 0, max(0, strlen($selected)-1));
        if ($preKey !== '' && isset($weapons[$preKey])) $pregen = ebs_h((string)($weapons[$preKey][0] ?? $preKey));
        $originKey = substr($selected, 0, 1);
        if ($originKey !== '' && isset($weapons[$originKey])) $originName = (string)($weapons[$originKey][0] ?? $originKey);
        foreach ($weapons as $key => $w) {
            if (strpos((string)$key, $selected) === 0 && strlen((string)$key) === strlen($selected)+1) {
                $n = (string)($w[0] ?? $key);
                $limit = (string)($w[6] ?? '');
                if (is_numeric($limit) && (int)$limit <= 3) $n = '<b style="color:ef8524;">None-Generation';
                $nextgen .= $n.'<br>';
            }
        }
    }
    if ($pregen === '') $pregen = '<b style="color:ef8524;">None-Generation</b>';
    if ($nextgen === '') $nextgen = '<b style="color:ef8524;">None-Generation</b>';
    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>ENDLESS BATTLE</title></head><body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="margin:0px;" oncontextmenu="return false;">';
    echo '<style type="text/css">
.left{background-color:#606060;border:1px solid #666;font-size:16px;text-align:center;font-weight:bold;color:#ffffff;}
.right{background-color:#202020;font-size:22px;color:#ffffff;border:1px solid #999;text-align:right;}
.b{font-weight:200;font-size:16px;}
</style>';
    echo '<table width="100%" height="100%"><tr><td align="center"><div style="font-size:35px;">EB-S 무기검색</div><table>';
    if ($selected === '') { echo '<b style="font-size:15pt;color:#778899;">모두검색</b>'; $pregen=$nextgen=''; }
    echo '<form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST">';
    echo '<tr><td class="left" width="220">전세대</td><td class="left" width="220" colspan="2">현세대</td><td class="left" width="220">차세대</td></tr>';
    echo '<tr><td class="right"><b class="b">'.$pregen.'</b></td><td class="right" colspan="2"><select name="wname" '.ebs_v('STYLE_L').'>'.$opt.'</select><br><input type="submit" value="검색" '.ebs_v('STYLE_B1').'></td><td class="right"><b class="b">'.$nextgen.'</b></td></tr>';
    if ($cur) {
        $name = (string)($cur[0] ?? $selected);
        $atk = (float)($cur[1] ?? 0); $hit=(float)($cur[2] ?? 0); $cnt=(float)($cur[3] ?? 0);
        $en = (string)($cur[4] ?? ''); $price=(string)($cur[5] ?? ''); $limit=(string)($cur[6] ?? ''); $eff=(string)($cur[7] ?? '0'); $img=(string)($cur[9] ?? '');
        echo '<tr><td rowspan="7"></td><td class="left">무기명</td><td class="right" nowrap><img src="'.ebs_h(ebs_v('buimg')).'/'.ebs_h($img).'.png">'.ebs_h($name).'<br><b class="b">('.ebs_h($originName).'계 제 '.ebs_h((string)$sedai).'세대)</b></td><td rowspan="7"></td></tr>';
        echo '<tr><td class="left">공격레벨</td><td class="right">'.ebs_status_rank($atk*$cnt/500).'<b class="b">랭크</b></td></tr>';
        echo '<tr><td class="left">소비EN</td><td class="right">'.ebs_h($en).'</td></tr>';
        echo '<tr><td class="left">명중정도</td><td class="right">'.ebs_status_rank($hit/4).'<b class="b">랭크</b></td></tr>';
        echo '<tr><td class="left">공격회수</td><td class="right">'.ebs_h((string)$cnt).'<b class="b">회</b></td></tr>';
        echo '<tr><td class="left">시장가격</td><td class="right">'.ebs_h($price).'</td></tr>';
        echo '<tr><td class="left">특수효과</td><td class="right">&nbsp;<b class="b">'.ebs_weapon_effects($eff, $limit).'</b></td></tr>';
    }
    echo '</table><input type="hidden" name="cmd" value="WEAPON"></form>';
    echo '<br><span style="font-size:15px;font-weight:bold;">The ENDLESS BATTLE Program Satellite '.ebs_h(ebs_v('VER')).'<br>Produce By <a href="http://www.ngcoms.net/" style="font-size:15px;color:#606060;">&copy NET GAME Communications</a> All Right Reserved.<br><a href="http://adonas.com/" style="font-size:15px;color:#606060;">한글화 by adonas</a></span>';
    echo '</td></tr></table></body></html>';
}


function ebs_CHAT2(): void {
    ebs_header_html();
    ebs_record_post('ebs_sub2.php::CHAT2');
    $pname = ebs_clean_login_value(ebs_param('pname', ebs_cookie_value('pname', '')));
    $pass = ebs_param('pass', ebs_cookie_value('pass', ''));
    $comment = trim(ebs_param('chat_comment', ''));
    if ($comment !== '' && $pname !== '') {
        $players = ebs_players_load();
        $key = ebs_find_player_key($pname, $players);
        if ($key !== null && isset($players[$key]) && is_array($players[$key]) && ebs_password_matches($players[$key], $pass)) {
            $log = ebs_json_load('chat_log');
            if (!isset($log['rows']) || !is_array($log['rows'])) $log['rows'] = [];
            $icon = ebs_normalize_icon((string)($players[$key]['icon'] ?? '1'), '1');
            $msg = function_exists('mb_substr') ? mb_substr($comment, 0, 120, 'UTF-8') : substr($comment, 0, 120);
            $log['rows'][] = ['name'=>$pname, 'icon'=>$icon, 'comment'=>$msg, 'time'=>date('Y-m-d H:i:s')];
            if (count($log['rows']) > 100) $log['rows'] = array_slice($log['rows'], -100);
            ebs_json_save('chat_log', $log);
        }
    }
    $log = ebs_json_load('chat_log');
    $rows = isset($log['rows']) && is_array($log['rows']) ? array_reverse($log['rows']) : [];
    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>ENDLESS BATTLE CHAT</title></head>';
    echo '<body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="margin:0;font-size:13px;" oncontextmenu="return false;">';
    echo '<table width="100%" height="95%"><tr><td width="100%" height="100%" valign="top">';
    echo '<form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST" target="Sub" style="margin:0 0 6px 0;"><input type="hidden" name="cmd" value="CHAT"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'">';
    echo '<table width="100%" cellspacing="1" cellpadding="4" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" style="font-size:13px;"><tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'"><b>채팅</b></td></tr>';
    echo '<tr><td>발언 <input type="text" name="chat_comment" size="70" maxlength="120" '.ebs_v('STYLE_L').'> <input type="submit" value="발언" '.ebs_v('STYLE_B1').'></td></tr></table></form>';
    echo '<table width="100%" cellspacing="1" cellpadding="4" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" style="font-size:13px;">';
    foreach (array_slice($rows, 0, 50) as $row) {
        if (!is_array($row)) continue;
        $icon = ebs_normalize_icon((string)($row['icon'] ?? '1'), '1');
        echo '<tr><td width="38" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'" align="center"><img src="'.ebs_h(ebs_v('IMG_FOLDER2')).'/'.ebs_h($icon).'.gif" width="32" height="32"></td>';
        echo '<td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'"><b>'.ebs_h((string)($row['name'] ?? '')).'</b> '.ebs_h((string)($row['comment'] ?? '')).'<div align="right" style="font-size:11px;">['.ebs_h((string)($row['time'] ?? '')).']</div></td></tr>';
    }
    if (!$rows) echo '<tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" align="center">채팅 로그가 없습니다.</td></tr>';
    echo '</table></td></tr></table></body></html>';
}

function ebs_userKey(): void {
    ebs_header_html();
    ebs_record_post('ebs_sub2.php::userKey');
    [$key, $me, $players, $err] = ebs_require_player();
    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>ENDLESS BATTLE</title></head><body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="margin:0;font-size:13px;">';
    echo '<center><table border="1" cellspacing="0" cellpadding="6" bordercolor="'.ebs_h(ebs_v('TABLE_BORDER')).'" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" style="min-width:420px;">';
    echo '<tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'" align="center"><b>로그인 정보 확인</b></td></tr>';
    if ($err !== '' || $key === null || !is_array($me)) {
        echo '<tr><td align="center">'.ebs_h($err ?: '로그인 정보가 없습니다.').'</td></tr>';
    } else {
        echo '<tr><td>파일럿: <b>'.ebs_h((string)($me['name'] ?? $key)).'</b></td></tr>';
        echo '<tr><td>국가: '.ebs_h((string)($me['kuni'] ?? '')).'</td></tr>';
        echo '<tr><td>레벨: '.number_format((int)($me['level'] ?? 1)).' / 소지금: '.number_format((int)($me['money'] ?? 0)).' G</td></tr>';
        echo '<tr><td>저장파일: user/'.ebs_h(ebs_user_safe_name((string)($me['name'] ?? $key))).'.json</td></tr>';
    }
    echo '</table></center></body></html>';
}

function ebs_ICON_LIST(): void {
    ebs_header_html();
    ebs_record_post('ebs_sub2.php::ICON_LIST');
    $start = max(0, (int)ebs_param('start', '0'));
    $icons = ebs_existing_icon_ids();
    $page = array_slice($icons, $start, 50);
    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>ENDLESS BATTLE</title></head><body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="margin:0px;" oncontextmenu="return false;">';
    echo '<table width="100%" height="100%"><tr><td align="center"><div style="font-size:35px;">EB-S 아이콘일람</div><table bgcolor="#f7f7f7" cellpadding="4" cellspacing="4" style="border:1px solid #808080;">';
    $c = 0;
    foreach ($page as $icon) {
        if ($c % 10 === 0) echo '<tr>';
        echo '<td><img src="'.ebs_h(ebs_v('IMG_FOLDER2')).'/'.ebs_h((string)$icon).'.gif"><div align="center" style="font-size:10px;color:#000000;">No.'.ebs_h((string)$icon).'</div></td>';
        $c++;
        if ($c % 10 === 0) echo '</tr>';
    }
    if ($c === 0) echo '<tr><td style="color:#000000;">표시할 아이콘 파일이 없습니다.</td></tr>';
    elseif ($c % 10 !== 0) echo '</tr>';
    echo '</table><table><tr>';
    $next = $start + 50; $back = $start - 50;
    if ($back >= 0) echo '<td><form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST"><input type="hidden" name="cmd" value="ICON"><input type="hidden" name="start" value="'.ebs_h((string)$back).'"><input type="submit" value="<<" '.ebs_v('STYLE_B1').'></form></td>';
    if ($next < count($icons)) echo '<td><form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST"><input type="hidden" name="cmd" value="ICON"><input type="hidden" name="start" value="'.ebs_h((string)$next).'"><input type="submit" value=">>" '.ebs_v('STYLE_B1').'></form></td>';
    echo '</tr></table><br><span style="font-size:15px;font-weight:bold;">The ENDLESS BATTLE Program Satellite '.ebs_h(ebs_v('VER')).'<br>Produce By <a href="http://www.ngcoms.net/" style="font-size:15px;color:#606060;">&copy NET GAME Communications</a> All Right Reserved.<br><a href="http://adonas.com/" style="font-size:15px;color:#606060;">한글화 by adonas</a></span>';
    echo '</td></tr></table></body></html>';
}


function ebs_top_level_output(): void {
    ebs_LOGIN2();
}

$map = [
    'LOGIN2' => 'ebs_LOGIN2',
    'UPMENU2' => 'ebs_UPMENU2',
    'LOG01' => 'ebs_LOG01',
    'LOGO2' => 'ebs_LOGO2',
    'MY_LIST2' => 'ebs_MY_LIST2',
    'TR' => 'ebs_TR',
    'C_LIST2' => 'ebs_C_LIST2',
    'WEAPON_LIST' => 'ebs_WEAPON_LIST',
    'CHAT2' => 'ebs_CHAT2',
    'userKey' => 'ebs_userKey',
    'ICON_LIST' => 'ebs_ICON_LIST',
    '__TOP__' => 'ebs_top_level_output',
];
ebs_dispatch($map, 'ebs_LOGIN2');
?>
