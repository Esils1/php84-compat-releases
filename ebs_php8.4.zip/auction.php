<?php
declare(strict_types=1);
require_once __DIR__ . '/lib_ebs.php';
/** 경매장: data/auction_market.json, data/auction_history.json 및 user/*.json 기반 구현. */
function ebs_auc_load(): array { $d = ebs_json_load('auction_market'); return is_array($d) ? array_values($d) : []; }
function ebs_auc_save(array $d): void { ebs_json_save('auction_market', array_values($d)); }
function ebs_auc_hist(array $row): void { $h=ebs_json_load('auction_history'); if(!is_array($h))$h=[]; $h[]=$row+['time'=>date('Y-m-d H:i:s')]; if(count($h)>100)$h=array_slice($h,-100); ebs_json_save('auction_history',$h); }
function ebs_auc_start(string $title='경매장'): void { ebs_header_html(); echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>EBS AUCTION</title></head><body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="margin:8px;font-size:13px;"><script>try{if(parent&&parent.Main&&parent.Main.location&&window.name=="Sub")parent.Main.location.reload();}catch(e){}</script><center><table border="1" cellspacing="0" cellpadding="5" bordercolor="'.ebs_h(ebs_v('TABLE_BORDER')).'" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" style="min-width:820px;font-size:13px;"><tr><td colspan="8" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'" align="center"><b>'.ebs_h($title).'</b></td></tr>'; }
function ebs_auc_end(): void { echo '</table></center></body></html>'; }
function ebs_auc_login_hidden(): string { return '<input type="hidden" name="pname" value="'.ebs_h(ebs_param('pname', ebs_cookie_value('pname',''))).'"><input type="hidden" name="pass" value="'.ebs_h(ebs_param('pass', ebs_cookie_value('pass',''))).'">'; }
function ebs_auc_slot_label(string $slot): string { return ['weapon'=>'장비중','weapon2'=>'예비1','weapon3'=>'예비2'][$slot] ?? '장비중'; }
function ebs_auc_return_weapon(array &$player, string $weapon): bool {
    if ($weapon === '') return true;
    if ((string)($player['weapon2'] ?? '') === '') { $player['weapon2'] = $weapon; return true; }
    if ((string)($player['weapon3'] ?? '') === '') { $player['weapon3'] = $weapon; return true; }
    if (!isset($player['warehouse_weapons']) || !is_array($player['warehouse_weapons'])) $player['warehouse_weapons'] = [];
    if (count($player['warehouse_weapons']) >= 30) return false;
    $player['warehouse_weapons'][] = $weapon;
    return true;
}
function ebs_COOKIE_IN(): void { ebs_MAINTE(); }
function ebs_SETUMEI(): void { ebs_auc_start('경매장 설명'); echo '<tr><td colspan="8">무기를 출품하고 다른 참가자가 입찰할 수 있습니다. 출품자는 낙찰 전까지 취소할 수 있으며, 입찰자가 있으면 입찰금은 자동 환불됩니다.</td></tr>'; ebs_auc_end(); }
function ebs_MAINTE(): void {
    $items = ebs_auc_load();
    $cur = ebs_current_player(); $myName = (string)($cur['name'] ?? '');
    ebs_auc_start('경매장');
    echo '<tr bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'"><td>출품자</td><td>무기</td><td>현재가</td><td>최고입찰자</td><td>마감</td><td>입찰</td><td>낙찰</td><td>취소</td></tr>';
    if (!$items) echo '<tr><td colspan="8" align="center">현재 출품되어 있지 않습니다</td></tr>';
    foreach ($items as $it) {
        if(!is_array($it)) continue;
        $id=(string)($it['id']??''); [$wid,$wname,$wlv] = ebs_calc_weapon_label((string)($it['weapon']??'')); $seller=(string)($it['seller']??'');
        echo '<tr><td>'.ebs_h($seller).'</td><td>'.ebs_h($wname).' Lv'.ebs_h((string)$wlv).'</td><td align="right">'.number_format((int)($it['price']??0)).' G</td><td>'.ebs_h((string)($it['bidder']??'-')).'</td><td>'.ebs_h((string)($it['created']??'')).'</td><td><form method="post" action="auction.php" target="Sub" style="margin:0">'.ebs_auc_login_hidden().'<input type="hidden" name="cmd" value="NYUSATU"><input type="hidden" name="id" value="'.ebs_h($id).'">금액 <input name="bid" size="8" '.ebs_v('STYLE_L').'> <input type="submit" value="입찰" '.ebs_v('STYLE_B1').'></form></td><td><form method="post" action="auction.php" target="Sub" style="margin:0">'.ebs_auc_login_hidden().'<input type="hidden" name="cmd" value="RAKUSATU"><input type="hidden" name="id" value="'.ebs_h($id).'"><input type="submit" value="낙찰처리" '.ebs_v('STYLE_B1').'></form></td>';
        echo '<td align="center"><form method="post" action="auction.php" target="Sub" style="margin:0">'.ebs_auc_login_hidden().'<input type="hidden" name="cmd" value="TORIKESHI"><input type="hidden" name="id" value="'.ebs_h($id).'"><input type="submit" value="취소" '.ebs_v('STYLE_B1').' onclick="return confirm(\'출품을 취소합니까?\')"></form></td></tr>';
    }
    echo '<tr><td colspan="8" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'"><b>무기 출품</b></td></tr><tr><td colspan="8"><form method="post" action="auction.php" target="Sub">'.ebs_auc_login_hidden().'<input type="hidden" name="cmd" value="INBUKI">출품무기 <select name="weapon_slot" '.ebs_v('STYLE_L').'>'; 
    foreach (['weapon','weapon2','weapon3'] as $slot) { $raw=(string)($cur[$slot] ?? ''); if($raw==='') continue; [, $nm, $lv] = ebs_calc_weapon_label($raw); echo '<option value="'.ebs_h($slot).'">'.ebs_h(ebs_auc_slot_label($slot).' : '.$nm.' Lv'.$lv); }
    echo '</select> 시작가 <input name="price" value="1000" size="8" '.ebs_v('STYLE_L').'> <input type="submit" value="출품" '.ebs_v('STYLE_B1').'> <a href="auction.php?cmd=REKISI">기록</a> | <a href="auction.php?cmd=SETUMEI">설명</a></form></td></tr>';
    ebs_auc_end();
}
function ebs_INBUKI(): void {
    if (empty($GLOBALS['EBS_AUCTION_TX'])) {
        $GLOBALS['EBS_AUCTION_TX'] = true;
        ebs_with_file_lock(ebs_file('data/auction_market_state'), LOCK_EX, static function (): void { ebs_INBUKI(); });
        $GLOBALS['EBS_AUCTION_TX'] = false;
        return;
    }
    [$key,$me,$players,$err] = ebs_require_player(); if($err!==''||$key===null||!is_array($me)){ ebs_error_page('경매 오류',$err); return; }
    $slot=ebs_param('weapon_slot','weapon'); if(!in_array($slot,['weapon','weapon2','weapon3'],true))$slot='weapon';
    $weapon=(string)($me[$slot]??''); if($weapon===''||$weapon==='0'){ ebs_error_page('경매 오류','출품할 무기가 없습니다.'); return; }
    $price=max(1,(int)ebs_param('price','0')); $items=ebs_auc_load();
    $items[]=['id'=>date('YmdHis').'-'.substr(hash('sha256',$key.$weapon.microtime(true)),0,8),'seller'=>(string)($me['name'] ?? $key),'seller_key'=>$key,'weapon'=>$weapon,'slot'=>$slot,'price'=>$price,'bidder'=>'','bidder_key'=>'','created'=>date('Y-m-d H:i:s')];
    $me[$slot]=''; if($slot==='weapon' && (string)($me['weapon2']??'')!==''){ $me['weapon']=$me['weapon2']; $me['weapon2']=''; } elseif($slot==='weapon' && (string)($me['weapon3']??'')!==''){ $me['weapon']=$me['weapon3']; $me['weapon3']=''; } elseif($slot==='weapon'){ $me['weapon']=ebs_default_weapon_id().'!0'; }
    ebs_player_sync_common($me); $players[$key]=$me; ebs_players_save($players); ebs_auc_save($items); ebs_auc_hist(['type'=>'출품','seller'=>(string)($me['name']??$key),'slot'=>$slot,'weapon'=>$weapon,'price'=>$price]); ebs_MAINTE();
}
function ebs_NYUSATU(): void {
    if (empty($GLOBALS['EBS_AUCTION_TX'])) {
        $GLOBALS['EBS_AUCTION_TX'] = true;
        ebs_with_file_lock(ebs_file('data/auction_market_state'), LOCK_EX, static function (): void { ebs_NYUSATU(); });
        $GLOBALS['EBS_AUCTION_TX'] = false;
        return;
    }
    [$key,$me,$players,$err] = ebs_require_player(); if($err!==''||$key===null||!is_array($me)){ ebs_error_page('입찰 오류',$err); return; }
    $id=ebs_param('id',''); $bid=max(0,(int)ebs_param('bid','0')); $items=ebs_auc_load();
    foreach($items as &$it){ if(!is_array($it) || (string)($it['id']??'')!==$id) continue; $sellerKey=(string)($it['seller_key']??''); $sellerName=(string)($it['seller']??''); if($sellerKey===$key || $sellerName===(string)($me['name']??'')){ ebs_error_page('입찰 오류','자신의 출품에는 입찰할 수 없습니다.'); return; } if($bid <= (int)($it['price']??0)){ ebs_error_page('입찰 오류','현재가보다 높은 금액을 입력해 주세요.'); return; } if((int)($me['money']??0)<$bid){ ebs_error_page('입찰 오류','소지금이 부족합니다.'); return; } $oldKey=(string)($it['bidder_key']??''); $oldName=(string)($it['bidder']??''); $oldprice=(int)($it['price']??0); $refundKey=$oldKey!==''?$oldKey:ebs_find_player_key($oldName,$players); if($refundKey!==null && isset($players[$refundKey]) && is_array($players[$refundKey])){ $players[$refundKey]['money']=(int)($players[$refundKey]['money']??0)+$oldprice; ebs_player_sync_common($players[$refundKey]); } $me['money']=(int)($me['money']??0)-$bid; ebs_player_sync_common($me); $players[$key]=$me; $it['price']=$bid; $it['bidder']=(string)($me['name']??$key); $it['bidder_key']=$key; $it['bid_time']=date('Y-m-d H:i:s'); ebs_players_save($players); ebs_auc_save($items); ebs_auc_hist(['type'=>'입찰','bidder'=>(string)($me['name']??$key),'price'=>$bid,'id'=>$id]); ebs_MAINTE(); return; }
    ebs_error_page('입찰 오류','출품 데이터를 찾을 수 없습니다.');
}
function ebs_RAKUSATU(): void {
    if (empty($GLOBALS['EBS_AUCTION_TX'])) {
        $GLOBALS['EBS_AUCTION_TX'] = true;
        ebs_with_file_lock(ebs_file('data/auction_market_state'), LOCK_EX, static function (): void { ebs_RAKUSATU(); });
        $GLOBALS['EBS_AUCTION_TX'] = false;
        return;
    }
    [$key,$me,$players,$err] = ebs_require_player(); if($err!==''||$key===null){ ebs_error_page('낙찰 오류',$err); return; }
    $id=ebs_param('id',''); $items=ebs_auc_load();
    foreach($items as $idx=>$it){ if(!is_array($it) || (string)($it['id']??'')!==$id) continue; $sellerKey=(string)($it['seller_key']??''); $seller=(string)($it['seller']??''); if($sellerKey==='' || !isset($players[$sellerKey])) $sellerKey=ebs_find_player_key($seller,$players) ?? $sellerKey; if($sellerKey!==$key && !ebs_admin_ok()){ ebs_error_page('낙찰 오류','출품자 또는 관리자만 낙찰 처리할 수 있습니다.'); return; } $bidderKey=(string)($it['bidder_key']??''); $bidder=(string)($it['bidder']??''); if($bidderKey==='' || !isset($players[$bidderKey])) $bidderKey=ebs_find_player_key($bidder,$players) ?? $bidderKey; if($bidderKey===''||!isset($players[$bidderKey])){ ebs_error_page('낙찰 오류','입찰자가 없습니다.'); return; } if(isset($players[$sellerKey]) && is_array($players[$sellerKey])){ $players[$sellerKey]['money']=(int)($players[$sellerKey]['money']??0)+(int)($it['price']??0); ebs_player_sync_common($players[$sellerKey]); } if(!isset($players[$bidderKey]['warehouse_weapons'])||!is_array($players[$bidderKey]['warehouse_weapons'])) $players[$bidderKey]['warehouse_weapons']=[]; $players[$bidderKey]['warehouse_weapons'][]=(string)($it['weapon']??''); ebs_player_sync_common($players[$bidderKey]); unset($items[$idx]); ebs_players_save($players); ebs_auc_save($items); ebs_auc_hist(['type'=>'낙찰','seller'=>$seller,'bidder'=>$bidder,'weapon'=>(string)($it['weapon']??''),'price'=>(int)($it['price']??0)]); ebs_MAINTE(); return; }
    ebs_error_page('낙찰 오류','출품 데이터를 찾을 수 없습니다.');
}
function ebs_TORIKESHI(): void {
    if (empty($GLOBALS['EBS_AUCTION_TX'])) {
        $GLOBALS['EBS_AUCTION_TX'] = true;
        ebs_with_file_lock(ebs_file('data/auction_market_state'), LOCK_EX, static function (): void { ebs_TORIKESHI(); });
        $GLOBALS['EBS_AUCTION_TX'] = false;
        return;
    }
    [$key,$me,$players,$err] = ebs_require_player(); if($err!==''||$key===null||!is_array($me)){ ebs_error_page('취소 오류',$err); return; }
    $id=ebs_param('id',''); $items=ebs_auc_load();
    foreach($items as $idx=>$it){ if(!is_array($it) || (string)($it['id']??'')!==$id) continue; $sellerKey=(string)($it['seller_key']??''); $seller=(string)($it['seller']??''); if($sellerKey==='' || !isset($players[$sellerKey])) $sellerKey=ebs_find_player_key($seller,$players) ?? $sellerKey; if($sellerKey!==$key && !ebs_admin_ok()){ ebs_error_page('취소 오류','출품자 또는 관리자만 취소할 수 있습니다.'); return; } $weapon=(string)($it['weapon']??''); if(isset($players[$sellerKey]) && is_array($players[$sellerKey])){ if(!ebs_auc_return_weapon($players[$sellerKey], $weapon)){ ebs_error_page('취소 오류','무기를 되돌릴 예비칸/창고 공간이 없습니다.'); return; } ebs_player_sync_common($players[$sellerKey]); }
        $bidderKey=(string)($it['bidder_key']??''); $bidder=(string)($it['bidder']??''); if($bidderKey==='' || !isset($players[$bidderKey])) $bidderKey=ebs_find_player_key($bidder,$players) ?? $bidderKey; if($bidderKey!=='' && isset($players[$bidderKey]) && is_array($players[$bidderKey])){ $players[$bidderKey]['money']=(int)($players[$bidderKey]['money']??0)+(int)($it['price']??0); ebs_player_sync_common($players[$bidderKey]); }
        unset($items[$idx]); ebs_players_save($players); ebs_auc_save($items); ebs_auc_hist(['type'=>'취소','seller'=>$seller,'weapon'=>$weapon,'refund'=>(string)($it['bidder']??'')]); ebs_MAINTE(); return; }
    ebs_error_page('취소 오류','출품 데이터를 찾을 수 없습니다.');
}
function ebs_REKISI(): void { $h=ebs_json_load('auction_history'); if(!is_array($h))$h=[]; ebs_auc_start('경매 기록'); echo '<tr><td colspan="2">시간</td><td colspan="6">내용</td></tr>'; foreach(array_reverse(array_slice($h,-50)) as $r) echo '<tr><td colspan="2">'.ebs_h((string)($r['time']??'')).'</td><td colspan="6">'.ebs_h(json_encode($r, JSON_UNESCAPED_UNICODE)).'</td></tr>'; ebs_auc_end(); }
function ebs_foot(): void { ebs_MAINTE(); }
$map=['COOKIE_IN'=>'ebs_COOKIE_IN','SETUMEI'=>'ebs_SETUMEI','REKISI'=>'ebs_REKISI','INBUKI'=>'ebs_INBUKI','MAINTE'=>'ebs_MAINTE','NYUSATU'=>'ebs_NYUSATU','RAKUSATU'=>'ebs_RAKUSATU','TORIKESHI'=>'ebs_TORIKESHI','foot'=>'ebs_foot'];
ebs_dispatch($map,'ebs_COOKIE_IN');
?>
