<?php
declare(strict_types=1);
require_once __DIR__ . '/lib_ebs.php';

function ebs_tougijou_log(): array {
    $d = ebs_json_load('tougijou_lounge');
    return is_array($d) ? $d : [];
}
function ebs_tougijou_save_log(array $rows): void {
    if (count($rows) > 100) $rows = array_slice($rows, -100);
    ebs_json_save('tougijou_lounge', $rows);
}
function ebs_tougijou_login(): array {
    [$key, $me, $players, $err] = ebs_require_player();
    return [$key, $me, $err];
}
function ebs_tougijou_menu(string $active='TOPGATE'): void {
    $pname = ebs_clean_login_value(ebs_param('pname', ebs_cookie_value('pname', '')));
    $pass = ebs_param('pass', ebs_cookie_value('pass', ''));
    echo '<form action="tougijou.php" method="POST" style="display:inline;" target="Sub"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'">';
    foreach (['TOPGATE'=>'입구','SETUMEI'=>'설명','BATTLE'=>'전투','HIKAESITU'=>'대기실','HIS'=>'전적'] as $cmd=>$label) {
        echo '<button name="cmd" value="'.$cmd.'" '.ebs_v('STYLE_B1').'>'.$label.'</button> ';
    }
    echo '</form>';
}
function ebs_tougijou_header(string $title): void {
    ebs_header_html();
    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>투기장</title></head><body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="font-size:13px;margin:0;"><center>';
    echo '<table border="1" bordercolor="'.ebs_h(ebs_v('TABLE_BORDER')).'" cellspacing="0" cellpadding="5" style="font-size:13px;width:90%;"><tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'"><b>'.ebs_h($title).'</b></td></tr><tr><td align="center" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'">';
    ebs_tougijou_menu($title);
    echo '</td></tr>';
}
function ebs_tougijou_footer(): void { echo '</table></center></body></html>'; }
function ebs_TOPGATE(): void {
    ebs_record_post('tougijou.php::TOPGATE');
    ebs_tougijou_header('투기장 입구');
    echo '<tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" align="center">자신의 강함을 시험하는 투기장입니다.<br>전투 버튼을 누르면 현재 등록 유저 목록에서 상대를 선택합니다.</td></tr>';
    ebs_tougijou_footer();
}
function ebs_BATTLE(): void {
    ebs_record_post('tougijou.php::BATTLE');
    $pname = ebs_clean_login_value(ebs_param('pname', ebs_cookie_value('pname', '')));
    $pass = ebs_param('pass', ebs_cookie_value('pass', ''));
    ebs_tougijou_header('투기장 전투');
    echo '<tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" align="center"><form action="tougibattle.php" method="POST" target="Sub"><input type="hidden" name="cmd" value="BATTLE"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'"><input type="submit" value="상대 선택" '.ebs_v('STYLE_B1').'></form></td></tr>';
    ebs_tougijou_footer();
}
function ebs_SETUMEI(): void {
    ebs_record_post('tougijou.php::SETUMEI');
    ebs_tougijou_header('투기장 설명');
    echo '<tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'">투기장은 등록 캐릭터끼리 전투를 진행하는 보조 화면입니다. 실제 전투 처리는 <b>tougibattle.php</b>에서 기존 BATTLE2 저장 로직을 사용합니다.</td></tr>';
    ebs_tougijou_footer();
}
function ebs_HIKAESITU(): void {
    ebs_record_post('tougijou.php::HIKAESITU');
    $pname = ebs_clean_login_value(ebs_param('pname', ebs_cookie_value('pname', '')));
    $pass = ebs_param('pass', ebs_cookie_value('pass', ''));
    ebs_tougijou_header('투기장 대기실');
    echo '<tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'"><form action="tougijou.php" method="POST" target="Sub"><input type="hidden" name="cmd" value="HATUGEN"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'">발언 <input type="text" name="msg" size="60"> <input type="submit" value="작성" '.ebs_v('STYLE_B1').'></form></td></tr>';
    echo '<tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'">';
    $rows = array_reverse(ebs_tougijou_log());
    if (!$rows) echo '발언 없음';
    foreach (array_slice($rows, 0, 30) as $r) if (is_array($r)) echo '['.ebs_h((string)($r['time'] ?? '')).'] <b>'.ebs_h((string)($r['name'] ?? '')).'</b> '.ebs_h((string)($r['msg'] ?? '')).'<br>';
    echo '</td></tr>';
    ebs_tougijou_footer();
}
function ebs_HATUGEN(): void {
    ebs_record_post('tougijou.php::HATUGEN');
    [$key, $me, $err] = ebs_tougijou_login();
    if ($err !== '' || $key === null || !is_array($me)) { ebs_error_page('투기장 대기실', $err ?: '로그인 정보가 없습니다.'); return; }
    $msg = trim(ebs_param('msg', ''));
    if ($msg !== '') {
        $msg = function_exists('mb_substr') ? mb_substr($msg, 0, 120, 'UTF-8') : substr($msg, 0, 120);
        $rows = ebs_tougijou_log();
        $rows[] = ['time'=>date('Y/m/d H:i'),'name'=>(string)($me['name'] ?? $key),'msg'=>$msg];
        ebs_tougijou_save_log($rows);
    }
    ebs_HIKAESITU();
}
function ebs_HIS(): void {
    ebs_record_post('tougijou.php::HIS');
    [$key, $me, $err] = ebs_tougijou_login();
    if ($err !== '' || $key === null || !is_array($me)) { ebs_error_page('투기장 전적', $err ?: '로그인 정보가 없습니다.'); return; }
    ebs_tougijou_header('투기장 전적');
    echo '<tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'">';
    $logs = isset($me['event_log']) && is_array($me['event_log']) ? array_reverse($me['event_log']) : [];
    $shown = 0;
    foreach ($logs as $log) {
        if (!is_array($log)) continue;
        $type = (string)($log['type'] ?? '');
        if (!in_array($type, ['battle','pvp','post','npc_battle'], true) && !str_contains($type, 'battle')) continue;
        echo ebs_h((string)($log['time'] ?? '')).' / '.ebs_h($type).' / '.ebs_h((string)($log['enemy'] ?? $log['vs'] ?? '')).' / '.ebs_h((string)($log['result'] ?? '')).'<br>';
        if (++$shown >= 30) break;
    }
    if ($shown === 0) echo '전적 기록이 없습니다.';
    echo '</td></tr>';
    ebs_tougijou_footer();
}
function ebs_INPORT(): void { ebs_TOPGATE(); }
function ebs_ENDSCRIPT(): void { ebs_TOPGATE(); }
$map = ['BATTLE'=>'ebs_BATTLE','INPORT'=>'ebs_INPORT','TOPGATE'=>'ebs_TOPGATE','SETUMEI'=>'ebs_SETUMEI','HIS'=>'ebs_HIS','HIKAESITU'=>'ebs_HIKAESITU','HATUGEN'=>'ebs_HATUGEN','ENDSCRIPT'=>'ebs_ENDSCRIPT'];
ebs_dispatch($map, 'ebs_TOPGATE');
?>
