<?php
declare(strict_types=1);
require_once __DIR__ . '/lib_ebs.php';

function ebs_ranking_players(): array {
    $players = ebs_players_load();
    $rows = [];
    foreach ($players as $key => $p) {
        if (!is_array($p)) continue;
        $name = (string)($p['name'] ?? $key);
        if ($name === '') continue;
        $rows[] = $p + ['name' => $name];
    }
    return $rows;
}

function ebs_rank_metric(array $p, string $metric): int {
    switch ($metric) {
        case 'money': return ebs_plv_int($p, 8, (int)($p['money'] ?? 0));
        case 'goldbar': return ebs_plv_int($p, 72, (int)($p['goldbar'] ?? 0));
        case 'power':
            $st = isset($p['st']) && is_array($p['st']) ? $p['st'] : [];
            return ebs_plv_int($p,16,0) + ebs_plv_int($p,18,0) + (int)array_sum(array_map('intval', $st)) * 100;
        case 'level': return ebs_plv_int($p, 29, ebs_plv_int($p, 0, (int)($p['level'] ?? 1)));
        case 'hp': return ebs_plv_int($p,16,(int)($p['max_hp'] ?? 0));
        case 'en': return ebs_plv_int($p,18,(int)($p['max_en'] ?? 0));
        case 'win': return ebs_plv_int($p,41,(int)($p['win'] ?? 0));
        case 'lose': return ebs_plv_int($p,42,(int)($p['lose'] ?? 0));
        case 'fortress': return ebs_plv_int($p,43,(int)($p['contrib'] ?? 0));
        case 'battle': return ebs_plv_int($p,41,0) + ebs_plv_int($p,42,0);
        case 'sandbag': return ebs_plv_int($p,42,0) + max(0, ebs_plv_int($p,16,0) - ebs_plv_int($p,15,0));
        default: return 0;
    }
}

function ebs_rank_weapon_name(array $p): string {
    $weapon = ebs_plv($p, 9, (string)($p['weapon'] ?? ''));
    [$weaponId] = array_pad(explode('!', $weapon, 2), 2, '0');
    $table = ebs_weapon_table();
    if (isset($table[$weaponId][0])) return (string)$table[$weaponId][0];
    if (isset($table[$weapon][0])) return (string)$table[$weapon][0];
    return $weapon !== '' ? $weapon : '무장비';
}

function ebs_rank_icon(array $p): string {
    return ebs_normalize_icon(ebs_plv($p, 27, (string)($p['icon'] ?? '1')), '1');
}

function ebs_ranking_header(string $title): void {
    ebs_header_html();
    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>ENDLESS BATTLE</title></head>';
    echo '<body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" link="'.ebs_h(ebs_v('LINK')).'" style="margin:0;font-size:13px;" oncontextmenu="return false;">';
    echo '<table width="100%" height="100%"><tr><td align="center">';
    echo '<table cellspacing="2" cellpadding="3" bgcolor="#909090" style="font-size:13px;" border="1">';
    echo '<tr><td bgcolor="#404040" colspan="7"><center><b>'.ebs_h($title).'</b></center></td></tr>';
}

function ebs_ranking_footer(): void {
    echo '<form action="ranking.php" method="POST"><input type="hidden" name="cmd" value="CHOICE">';
    echo '<tr><td colspan="7" align="center"><input type="submit" value="돌아간다" '.ebs_v('STYLE_B2').'></td></tr></form>';
    echo '</table><br><center>랭킹:EDIT BY <a href="http://members.jcom.home.ne.jp/masimaro/">MASIMARO</a></center>';
    echo '</td></tr></table></body></html>';
}

function ebs_ranking_table(string $title, string $valueTitle, string $metric): void {
    $rows = ebs_ranking_players();
    usort($rows, static function (array $a, array $b) use ($metric): int {
        $av = ebs_rank_metric($a, $metric);
        $bv = ebs_rank_metric($b, $metric);
        if ($av === $bv) return strcmp((string)($a['name'] ?? ''), (string)($b['name'] ?? ''));
        return $bv <=> $av;
    });
    ebs_ranking_header($title);
    echo '<tr><td>No.</td><td>플레이어명</td><td>소속국</td><td>'.ebs_h($valueTitle).'</td><td>기체</td><td>무기</td><td>아이콘</td></tr>';
    $rank = 1;
    foreach (array_slice($rows, 0, 100) as $p) {
        $name = (string)($p['name'] ?? '');
        $country = ebs_plv($p, 5, (string)($p['kuni'] ?? ''));
        $msname = ebs_plv($p, 3, (string)($p['msname'] ?? ''));
        $color = ebs_color(ebs_plv($p, 13, (string)($p['color'] ?? '#ffffff')));
        $icon = ebs_rank_icon($p);
        $value = ebs_rank_metric($p, $metric);
        echo '<tr><td align="right">'.$rank.'</td><td><font color="'.ebs_h($color).'">'.ebs_h($name).'</font></td><td><font color="BLACK">【'.ebs_h($country).'】</font></td><td align="right"><font color="RED"><b>'.ebs_h((string)$value).'</b></font></td><td><font color="BLUE">'.ebs_h($msname).'</font></td><td>'.ebs_h(ebs_rank_weapon_name($p)).'</td><td align="center"><img src="'.ebs_h(ebs_v('IMG_FOLDER2')).'/'.ebs_h($icon).'.gif" width="32" height="32"></td></tr>';
        $rank++;
    }
    ebs_ranking_footer();
}

function ebs_CHOICE(): void { ebs_CHOICE2(); }
function ebs_CHOICE2(): void {
    ebs_header_html();
    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>ENDLESS BATTLE</title></head><body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" link="'.ebs_h(ebs_v('LINK')).'" vlink="'.ebs_h(ebs_v('VLINK')).'" style="margin:0;font-size:13px;" oncontextmenu="return false;">';
    echo '<form action="ranking.php" method="POST" name="choice">
        <input type="hidden" name="cmd">
        <table width="100%" height="100%"><tr><td align="center">
        <table class="font9" cellspacing="2" cellpadding="3" bgcolor="#909090">
            <tr><td bgcolor="#404040" colspan="3"><center><b>랭킹</b></center></td></tr>
            <tr><td bgcolor="#404040" align="center">골드부자</td><td style="border:1px solid #404040;font-size:12px;color:#000000;">돈을 좋아하는 사람들</td><td style="border:1px solid #404040;"><input type="submit" value="GO" '.ebs_v('STYLE_B2').' onClick="choice.cmd.value=\'RANKING\'"></td></tr>
            <tr><td bgcolor="#404040" align="center">금괴부자</td><td style="border:1px solid #404040;font-size:12px;color:#000000;">금괴를 좋아하는 사람들</td><td style="border:1px solid #404040;"><input type="submit" value="GO" '.ebs_v('STYLE_B2').' onClick="choice.cmd.value=\'RANKING18\'"></td></tr>
            <tr><td bgcolor="#404040" align="center">천하무쌍</td><td style="border:1px solid #404040;font-size:12px;color:#000000;">전투의 달인들</td><td style="border:1px solid #404040;"><input type="submit" value="GO" '.ebs_v('STYLE_B2').' onClick="choice.cmd.value=\'RANKING3\'"></td></tr>
            <tr><td bgcolor="#404040" align="center">전당</td><td style="border:1px solid #404040;font-size:12px;color:#000000;">경지에 다다른 사람들</td><td style="border:1px solid #404040;"><input type="submit" value="GO" '.ebs_v('STYLE_B2').' onClick="choice.cmd.value=\'DENDOU\'"></td></tr>
            <tr><td bgcolor="#404040" align="center">노가다왕</td><td style="border:1px solid #404040;font-size:12px;color:#000000;">레벨이 가장 높은 사람들</td><td style="border:1px solid #404040;"><input type="submit" value="GO" '.ebs_v('STYLE_B2').' onClick="choice.cmd.value=\'RANKING15\'"></td></tr>
            <tr><td bgcolor="#404040" align="center">HP왕</td><td style="border:1px solid #404040;font-size:12px;color:#000000;">HP가 가장 높은 사람들</td><td style="border:1px solid #404040;"><input type="submit" value="GO" '.ebs_v('STYLE_B2').' onClick="choice.cmd.value=\'HP\'"></td></tr>
            <tr><td bgcolor="#404040" align="center">EN왕</td><td style="border:1px solid #404040;font-size:12px;color:#000000;">EN이 가장 높은 사람들</td><td style="border:1px solid #404040;"><input type="submit" value="GO" '.ebs_v('STYLE_B2').' onClick="choice.cmd.value=\'EN\'"></td></tr>
            <tr><td bgcolor="#404040" align="center">파괴왕</td><td style="border:1px solid #404040;font-size:12px;color:#000000;">대파를 가장 많이 시킨 사람들</td><td style="border:1px solid #404040;"><input type="submit" value="GO" '.ebs_v('STYLE_B2').' onClick="choice.cmd.value=\'RANKING5\'"></td></tr>
            <tr><td bgcolor="#404040" align="center">불쌍한이들</td><td style="border:1px solid #404040;font-size:12px;color:#000000;">대파를 가장 많이 당한 사람들</td><td style="border:1px solid #404040;"><input type="submit" value="GO" '.ebs_v('STYLE_B2').' onClick="choice.cmd.value=\'RANKING7\'"></td></tr>
            <tr><td bgcolor="#404040" align="center">유공자</td><td style="border:1px solid #404040;font-size:12px;color:#000000;">요새를 가장 많이 격추한 사람들</td><td style="border:1px solid #404040;"><input type="submit" value="GO" '.ebs_v('STYLE_B2').' onClick="choice.cmd.value=\'RANKING9\'"></td></tr>
            <tr><td bgcolor="#404040" align="center">전투왕</td><td style="border:1px solid #404040;font-size:12px;color:#000000;">전투를 가장 즐기는 사람들</td><td style="border:1px solid #404040;"><input type="submit" value="GO" '.ebs_v('STYLE_B2').' onClick="choice.cmd.value=\'RANKING11\'"></td></tr>
            <tr><td bgcolor="#404040" align="center">샌드백</td><td style="border:1px solid #404040;font-size:12px;color:#000000;">가장 많이 얻어맏는 사람들</td><td style="border:1px solid #404040;"><input type="submit" value="GO" '.ebs_v('STYLE_B2').' onClick="choice.cmd.value=\'RANKING13\'"></td></tr>
        </table></form>&nbsp;</td></tr></table>';
    echo '<br><center>랭킹:EDIT BY <a href="http://members.jcom.home.ne.jp/masimaro/">MASIMARO</a></center></body></html>';
}

function ebs_RANKING(): void { ebs_ranking_table('랭킹', '자금', 'money'); }
function ebs_RANKING2(): void { ebs_RANKING(); }
function ebs_RANKING18(): void { ebs_ranking_table('랭킹', '금괴', 'goldbar'); }
function ebs_RANKING3(): void { ebs_ranking_table('랭킹', '종합전투능력', 'power'); }
function ebs_RANKING4(): void { ebs_RANKING3(); }
function ebs_DENDOU(): void { ebs_ranking_table('랭킹', 'Rank', 'level'); }
function ebs_DENDOU2(): void { ebs_DENDOU(); }
function ebs_RANKING5(): void { ebs_ranking_table('랭킹', '대파수', 'win'); }
function ebs_RANKING6(): void { ebs_RANKING5(); }
function ebs_RANKING7(): void { ebs_ranking_table('랭킹', '대파당한수', 'lose'); }
function ebs_RANKING8(): void { ebs_RANKING7(); }
function ebs_RANKING9(): void { ebs_ranking_table('랭킹', '요새격추/공헌', 'fortress'); }
function ebs_RANKING10(): void { ebs_RANKING9(); }
function ebs_RANKING11(): void { ebs_ranking_table('랭킹', '전투수', 'battle'); }
function ebs_RANKING12(): void { ebs_RANKING11(); }
function ebs_RANKING13(): void { ebs_ranking_table('랭킹', '샌드백', 'sandbag'); }
function ebs_RANKING14(): void { ebs_RANKING13(); }
function ebs_RANKING15(): void { ebs_ranking_table('랭킹', '레벨', 'level'); }
function ebs_RANKING16(): void { ebs_RANKING15(); }
function ebs_RANKING17(): void { ebs_ranking_table('랭킹', '종합전투능력', 'power'); }
function ebs_HP(): void { ebs_ranking_table('랭킹', '최대 체력', 'hp'); }
function ebs_HP_2(): void { ebs_HP(); }
function ebs_EN(): void { ebs_ranking_table('랭킹', '최대 EN', 'en'); }
function ebs_EN_2(): void { ebs_EN(); }

$map = [
    'CHOICE' => 'ebs_CHOICE',
    'CHOICE2' => 'ebs_CHOICE2',
    'RANKING' => 'ebs_RANKING',
    'RANKING2' => 'ebs_RANKING2',
    'RANKING18' => 'ebs_RANKING18',
    'RANKING3' => 'ebs_RANKING3',
    'RANKING4' => 'ebs_RANKING4',
    'DENDOU' => 'ebs_DENDOU',
    'DENDOU2' => 'ebs_DENDOU2',
    'RANKING5' => 'ebs_RANKING5',
    'RANKING6' => 'ebs_RANKING6',
    'RANKING7' => 'ebs_RANKING7',
    'RANKING8' => 'ebs_RANKING8',
    'RANKING9' => 'ebs_RANKING9',
    'RANKING10' => 'ebs_RANKING10',
    'RANKING11' => 'ebs_RANKING11',
    'RANKING12' => 'ebs_RANKING12',
    'RANKING13' => 'ebs_RANKING13',
    'RANKING14' => 'ebs_RANKING14',
    'RANKING15' => 'ebs_RANKING15',
    'RANKING16' => 'ebs_RANKING16',
    'RANKING17' => 'ebs_RANKING17',
    'HP' => 'ebs_HP',
    'EN' => 'ebs_EN',
];
ebs_dispatch($map, 'ebs_CHOICE');
?>
