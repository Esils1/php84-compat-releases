<?php
declare(strict_types=1);
require_once __DIR__ . '/lib_ebs.php';
/**
 * 원본 legacy 파일: convert.php
 * PHP 8.4 파일당 1:1 대응 변환 파일.
 * 원본 주석은 PHP // 주석으로 보존하고, 기존 실행 의존은 제거하고 PHP 8.4 파일 기반으로 동작시킨다.
 * 유지보수 시 원본 sub 이름과 아래 ebs_함수명을 대조한다.
 */
// _/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/
//
// The Endless Battle sub program
// Produced by 끝나지 않는 싸움―ENDLESS-
// 기체 데이터 콘버터 Ver1. 03
//
// 프리 소프트웨어입니다만, 저작권은 방폐하고 있습니다.
// 재배포, 상용 이용하는 경우는 보고 바랍니다.
//
// _/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/
//
// ◆이 스크립트는 구식의 스크립트의 기록 형식을
// 최신의 기록 형식으로 변환하기 위한 전용 스크립트입니다.
// 낡은 편의 스크립트를 사용하고 있었을 경우는 이것을 기동시켜 변환하고 나서
// 새로운 스크립트를 올려 주세요.

function ebs_a(): void {
    ebs_header_html();
    ebs_record_post('convert.php::a');
    // 원본 연결 함수: HEADER, LOCK, UNLOCK
    echo '완료했습니다.';
}

$map = [
    'a' => 'ebs_a',
];
ebs_dispatch($map, 'ebs_a');
?>
