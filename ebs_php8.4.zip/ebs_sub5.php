<?php
declare(strict_types=1);
require_once __DIR__ . '/lib_ebs.php';
/**
 * 원본 legacy 파일: ebs_sub5.php
 * PHP 8.4 파일당 1:1 대응 변환 파일.
 * 원본 주석은 PHP // 주석으로 보존하고, 기존 실행 의존은 제거하고 PHP 8.4 파일 기반으로 동작시킨다.
 * 유지보수 시 원본 sub 이름과 아래 ebs_함수명을 대조한다.
 */
// 능력치별로
// 능력치별 여기까지
// //////////////////////////////////////////
// ////////도시 ///////////////////////////
// //////////////////////////////////////////
// ////////거래 ///////////////////////////
// //////////////////////////////////////////
// ////////특별 ///////////////////////////
// //////////////////////////////////////////
// ////////도박 ///////////////////////////
// //////////////////////////////////////////
// ////////전체프리 ///////////////////////////
// ////////경험치프리 ///////////////////////////
// //////////////////////////////////////////
// ////////환전 ///////////////////////////
// //////////////////////////////////////////
// ////////환전 ///////////////////////////
// //////////////////////////////////////////
// ////////회복 ///////////////////////////
// //////////////////////////////////////////
// -----성격개조------------------------------------------
// -----여기까지------------------------------------------
// ************************************************************
// 디폴트의경우↓##########################################################
// 디폴트의경우↑##########################################################
// <td><img src=$IMG_FOLDER3/$VALUES[38].gif><td style="color:$VALUES[13];">$VALUES[7]</td></tr>

function ebs_CUSTOM_HEADER(): void {
    // 단독 직접 접근 시 원본 FORM 치환 잔재를 출력하지 않고 도시 메뉴로 진입한다.
    ebs_CITY2();
}

function ebs_status_bonus_points(array $player): int {
    $st = $player['st'] ?? [6,6,6,6];
    if (!is_array($st)) $st = [6,6,6,6];
    $spent = 0;
    for ($i=0; $i<4; $i++) $spent += max(0, (int)($st[$i] ?? 6) - 6);
    $level = max(1, (int)($player['level'] ?? ebs_player_raw_get($player, 0, '1')));
    $pool = max(0, $level - 1 - $spent);
    $extra = (int)($player['total_free'] ?? ebs_player_raw_get($player, 75, '0'));
    if ($extra > 0) $pool += $extra;
    return max(0, $pool);
}

function ebs_ST_RESET2(): void {
    ebs_header_html();
    ebs_record_post('ebs_sub5.php::ST_RESET2');
    [$key, $me, $players, $err] = ebs_require_player();
    if ($err !== '' || !is_array($me) || $key === null) { ebs_error_page('Error', $err ?: '등록 데이터를 찾을 수 없습니다.'); return; }
    $pname=(string)($me['name'] ?? $key); $pass=ebs_param('pass', ebs_cookie_value('pass',''));
    $msg='';
    if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && ebs_param('Cmode','') === '스탯리셋') {
        $me['st'] = [6,6,6,6];
        ebs_player_sync_common($me); $players[$key]=$me; ebs_players_save($players);
        $msg = '스탯 초기화 완료';
    }
    $bonus = ebs_status_bonus_points($me);
    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>ENDLESS BATTLE</title></head><body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="margin:0;font-size:13px;">';
    echo '<center><form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST" name="Ms" target="Sub"><input type="hidden" name="cmd" value="ST_RESET"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'">';
    echo '<table border="1" cellspacing="0" cellpadding="6" bordercolor="'.ebs_h(ebs_v('TABLE_BORDER')).'" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" style="font-size:13px;min-width:360px;">';
    echo '<tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'"><b>스탯 초기화</b></td></tr>';
    if ($msg !== '') echo '<tr><td align="center"><b>'.ebs_h($msg).'</b></td></tr>';
    echo '<tr><td>리셋을 하시면 공격/방어/속도/명중이 6으로 돌아갑니다.<br>남은 포인트는 스탯찍기에서 다시 분배할 수 있습니다.</td></tr>';
    echo '<tr><td>현재 재분배 가능 포인트: <b>'.ebs_h((string)$bonus).'</b></td></tr>';
    echo '<tr><td align="center"><input name="Cmode" type="submit" value="스탯리셋" '.ebs_v('STYLE_B1').' onClick="return confirm(&quot;스탯을 초기화합니다. 괜찮습니까?&quot;)"></td></tr>';
    echo '</table></form></center></body></html>';
}

function ebs_STATUSUP2(): void {
    ebs_header_html();
    ebs_record_post('ebs_sub5.php::STATUSUP2');
    [$key, $me, $players, $err] = ebs_require_player();
    if ($err !== '' || !is_array($me) || $key === null) { ebs_error_page('Error', $err ?: '등록 데이터를 찾을 수 없습니다.'); return; }
    $pname=(string)($me['name'] ?? $key); $pass=ebs_param('pass', ebs_cookie_value('pass',''));
    $names = ebs_arr('STATUS_NAME');
    $st = $me['st'] ?? [6,6,6,6]; if (!is_array($st)) $st=[6,6,6,6];
    $bonus = ebs_status_bonus_points($me);
    $msg='';
    if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && ebs_param('Cmode','') === '스탯찍기') {
        $add = [max(0,(int)ebs_param('up_at','0')), max(0,(int)ebs_param('up_de','0')), max(0,(int)ebs_param('up_sp','0')), max(0,(int)ebs_param('up_hi','0'))];
        $need = array_sum($add);
        if ($need <= 0) $msg='분배할 포인트를 입력하세요.';
        elseif ($need > $bonus) $msg='보너스 스탯이 부족합니다.';
        else {
            for ($i=0; $i<4; $i++) $st[$i] = (int)($st[$i] ?? 6) + $add[$i];
            $me['st'] = $st;
            ebs_player_sync_common($me); $players[$key]=$me; ebs_players_save($players);
            $bonus -= $need; $msg='스탯 분배 완료';
        }
    }
    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>ENDLESS BATTLE</title></head><body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="margin:0;font-size:13px;">';
    echo '<center><form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST" name="Ms" target="Sub"><input type="hidden" name="cmd" value="STATUSUP"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'">';
    echo '<table border="1" cellspacing="0" cellpadding="6" bordercolor="'.ebs_h(ebs_v('TABLE_BORDER')).'" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" style="font-size:13px;min-width:420px;">';
    echo '<tr><td colspan="3" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'"><b>스탯찍기</b></td></tr>';
    if ($msg !== '') echo '<tr><td colspan="3" align="center"><b>'.ebs_h($msg).'</b></td></tr>';
    echo '<tr><td colspan="3">보너스스탯: <b>'.ebs_h((string)$bonus).'</b></td></tr>';
    $fields = [['up_at',$names[0] ?? '공격',0],['up_de',$names[1] ?? '방어',1],['up_sp',$names[2] ?? '속도',2],['up_hi',$names[3] ?? '명중',3]];
    foreach ($fields as [$field,$label,$idx]) echo '<tr><td>'.ebs_h($label).'</td><td align="right">'.ebs_h((string)($st[$idx] ?? 6)).'</td><td><input type="text" name="'.$field.'" value="0" size="4" '.ebs_v('STYLE_L').'></td></tr>';
    echo '<tr><td colspan="3" align="center"><input name="Cmode" type="submit" value="스탯찍기" '.ebs_v('STYLE_B1').' onClick="return confirm(&quot;스탯을 분배합니다. 괜찮습니까?&quot;)"></td></tr>';
    echo '</table></form></center></body></html>';
}

function ebs_EQUIP(): void {
    $GLOBALS['EBS_DISABLE_AUTO_POST_SAVE'] = true;
    ebs_header_html();
    [$key, $me, $players, $err] = ebs_require_player();
    if ($err !== '' || !is_array($me) || $key === null) { ebs_error_page('Error', $err ?: '자신의 등록 데이터를 찾을 수 없습니다.'); return; }
    $pname=(string)($me['name'] ?? $key); $pass=ebs_param('pass', ebs_cookie_value('pass',''));
    $cmode=ebs_param('Cmode',''); $msg=''; $table=ebs_weapon_table();
    $money=max(0,(int)($me['money'] ?? 0));
    $sync = false;

    if ($cmode === '장비' || $cmode === '장비변경') {
        $slot=ebs_param('soubi', ebs_param('wslot',''));
        if ($slot === 'B' && (string)($me['weapon2'] ?? '') !== '') { [$me['weapon'],$me['weapon2']] = [$me['weapon2'],$me['weapon'] ?? '']; $msg='예비1 무기를 장비했습니다.'; $sync=true; }
        elseif ($slot === 'C' && (string)($me['weapon3'] ?? '') !== '') { [$me['weapon'],$me['weapon3']] = [$me['weapon3'],$me['weapon'] ?? '']; $msg='예비2 무기를 장비했습니다.'; $sync=true; }
        else $msg='교체할 예비 무기가 없습니다.';
    }

    if ($cmode === '랭크업') {
        $new=ebs_param('wname','');
        if ($new !== '' && isset($table[$new])) { $me['weapon']=$new.'!0'; $msg='랭크업 완료'; $sync=true; }
        else $msg='랭크업 가능한 무기를 선택하세요.';
    }

    if ($cmode === '무기구입') {
        $buy=ebs_param('buyw','');
        if ($buy === '' || !isset($table[$buy])) $msg='구입할 무기를 선택하세요.';
        else {
            $row=$table[$buy]; $price=max(0,(int)($row[5] ?? 0));
            if ($price <= 0) $msg='판매 대상 무기가 아닙니다.';
            elseif ($money < $price) $msg='소지금이 부족합니다.';
            elseif ((string)($me['weapon2'] ?? '') === '') { $money-=$price; $me['money']=$money; $me['weapon2']=$buy.'!0'; $msg='무기를 예비1에 구입했습니다.'; $sync=true; }
            elseif ((string)($me['weapon3'] ?? '') === '') { $money-=$price; $me['money']=$money; $me['weapon3']=$buy.'!0'; $msg='무기를 예비2에 구입했습니다.'; $sync=true; }
            else $msg='예비 무기 칸이 비어 있지 않습니다. 먼저 매각하거나 장비를 교체하세요.';
        }
    }

    if ($cmode === '무기매각') {
        $slot=ebs_param('sell_slot','weapon2');
        if (!in_array($slot, ['weapon','weapon2','weapon3'], true)) $slot='weapon2';
        $raw=(string)($me[$slot] ?? ''); [$sid] = array_pad(explode('!', $raw, 2), 2, '');
        if ($raw === '' || !isset($table[$sid])) $msg='매각할 무기가 없습니다.';
        else {
            $price=(int)floor(max(0,(int)($table[$sid][5] ?? 0))/2); $money += $price; $me['money']=$money;
            if ($slot === 'weapon') {
                if ((string)($me['weapon2'] ?? '') !== '') { $me['weapon']=$me['weapon2']; $me['weapon2']=''; }
                elseif ((string)($me['weapon3'] ?? '') !== '') { $me['weapon']=$me['weapon3']; $me['weapon3']=''; }
                else { $me['weapon']=ebs_default_weapon_id().'!0'; }
            } else $me[$slot]='';
            $msg='무기 매각 완료: $'.number_format($price); $sync=true;
        }
    }

    if ($sync) { ebs_player_sync_common($me); $players[$key]=$me; ebs_players_save($players); }
    [$wa,$wb,$wc]=[(string)($me['weapon'] ?? ''),(string)($me['weapon2'] ?? ''),(string)($me['weapon3'] ?? '')];
    [$aid,$an,$alv,$aexp,$arow]=ebs_calc_weapon_label($wa); [$bid,$bn,$blv,$bexp,$brow]=ebs_calc_weapon_label($wb); [$cid,$cn,$clv,$cexp,$crow]=ebs_calc_weapon_label($wc);
    $rankable=[];
    if ($aid !== '' && $alv >= (int)ebs_v('WEAPON_RANKUP','50')) { foreach ($table as $wid=>$row) { if (str_starts_with((string)$wid,$aid) && strlen((string)$wid)===strlen($aid)+1) $rankable[(string)$wid]=(string)($row[0] ?? $wid); } }

    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>ENDLESS BATTLE</title></head><body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="margin:0;font-size:13px;" oncontextmenu="return false;">';
    echo '<script>try{if(parent&&parent.Main&&parent.Main.location&&window.name=="Sub")parent.Main.location.reload();}catch(e){}function checkEquip(){return confirm("장비를 변경합니다. 괜찮습니까?");}function checkRnkup(){return confirm("무기를 랭크업 시킵니다. 괜찮습니까?");}function checkBuy(){return confirm("무기를 구입합니다. 괜찮습니까?");}function checkSell(){return confirm("무기를 매각합니다. 괜찮습니까?");}</script>';
    echo '<form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST" name="Ms" target="Sub"><input type="hidden" name="cmd" value="EQUIPMENT"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'">';
    echo '<center><table border="1" cellspacing="0" cellpadding="5" bordercolor="'.ebs_h(ebs_v('TABLE_BORDER')).'" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" style="font-size:13px;min-width:520px;">';
    echo '<tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'" colspan="2"><b>장비변경 / 무기구입</b><span style="float:right">소지금 $'.ebs_h(number_format($money)).'</span></td></tr>';
    if ($msg !== '') echo '<tr><td colspan="2" align="center"><b>'.ebs_h($msg).'</b></td></tr>';
    echo '<tr><td width="120">장비중</td><td>'.ebs_h($an.'(Lv'.$alv.')').'</td></tr>';
    echo '<tr><td>예비1</td><td>'.($wb!=='' ? ebs_h($bn.'(Lv'.$blv.')') : '&nbsp;').'</td></tr>';
    echo '<tr><td>예비2</td><td>'.($wc!=='' ? ebs_h($cn.'(Lv'.$clv.')') : '&nbsp;').'</td></tr>';
    echo '<tr><td>장비교체</td><td>';
    if ($wb !== '' || $wc !== '') { echo '<select name="soubi" '.ebs_v('STYLE_L').'>'; if ($wb !== '') echo '<option value="B">'.ebs_h($bn.'(Lv'.$blv.')'); if ($wc !== '') echo '<option value="C">'.ebs_h($cn.'(Lv'.$clv.')'); echo '</select> <input type="submit" name="Cmode" value="장비" '.ebs_v('STYLE_B1').' onClick="return checkEquip()">'; }
    else echo '교체 가능한 예비 무기가 없습니다.';
    echo '</td></tr>';
    if ($rankable) { echo '<tr><td>랭크업</td><td>'; foreach ($rankable as $wid=>$nm) echo '<label><input type="radio" name="wname" value="'.ebs_h($wid).'"> <font color="#1e90ff"><b>→</b></font> '.ebs_h($nm).'</label><br>'; echo '<input type="submit" name="Cmode" value="랭크업" '.ebs_v('STYLE_B1').' onClick="return checkRnkup()"></td></tr>'; }
    echo '<tr><td>무기매각</td><td><select name="sell_slot" '.ebs_v('STYLE_L').'>';
    foreach (['weapon'=>'장비중: '.$an,'weapon2'=>'예비1: '.$bn,'weapon3'=>'예비2: '.$cn] as $slot=>$label) { if ((string)($me[$slot] ?? '') !== '') echo '<option value="'.ebs_h($slot).'">'.ebs_h($label); }
    echo '</select> <input type="submit" name="Cmode" value="무기매각" '.ebs_v('STYLE_B1').' onClick="return checkSell()"></td></tr>';
    echo '<tr><td valign="top">무기구입</td><td><select name="buyw" '.ebs_v('STYLE_L').' style="width:280px;">';
    $printed=0;
    foreach ($table as $wid=>$row) { if (!is_array($row)) continue; $price=max(0,(int)($row[5] ?? 0)); if ($price <= 0) continue; $printed++; echo '<option value="'.ebs_h((string)$wid).'">'.ebs_h((string)($row[0] ?? $wid)).' $'.ebs_h(number_format($price)); }
    if ($printed===0) echo '<option value="">판매 무기 데이터 없음';
    echo '</select> <input type="submit" name="Cmode" value="무기구입" '.ebs_v('STYLE_B1').' onClick="return checkBuy()"><br><span style="font-size:12px;color:#bbbbbb;">구입한 무기는 비어 있는 예비 슬롯에 들어갑니다.</span></td></tr>';
    echo '</table></center></form></body></html>';
}

function ebs_sub5_login_context(): array {
    [$key, $me, $players, $err] = ebs_require_player();
    if ($err !== '' || !is_array($me) || $key === null) {
        ebs_error_page('Error', $err ?: '등록 데이터를 찾을 수 없습니다.');
        return [null, null, null, null, $err ?: '등록 데이터를 찾을 수 없습니다.'];
    }
    return [$key, $me, $players, ebs_param('pass', ebs_cookie_value('pass','')), ''];
}

function ebs_render_sub5_menu(string $title, array $items): void {
    ebs_header_html();
    [$key, $me, $players, $pass, $err] = ebs_sub5_login_context();
    if ($err !== '' || !is_array($me)) return;
    $pname = (string)($me['name'] ?? $key);
    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>ENDLESS BATTLE</title></head>';
    echo '<body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="margin:0;font-size:13px;" oncontextmenu="return false;">';
    echo '<center><table border="1" cellspacing="0" cellpadding="6" bordercolor="'.ebs_h(ebs_v('TABLE_BORDER')).'" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" style="font-size:13px;min-width:460px;">';
    echo '<tr><td colspan="3" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'" align="center"><b>'.ebs_h($title).'</b></td></tr>';
    foreach ($items as $item) {
        $label = (string)($item['label'] ?? '');
        $desc = (string)($item['desc'] ?? '');
        echo '<tr><td width="120" align="center"><b>'.ebs_h($label).'</b></td><td>'.ebs_h($desc).'</td><td align="center">';
        if (isset($item['url'])) {
            $url = (string)$item['url'];
            echo '<form action="'.ebs_h($url).'" method="POST" target="Sub" style="margin:0;">';
            echo '<input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h((string)$pass).'">';
            if (isset($item['url_cmd'])) echo '<input type="hidden" name="cmd" value="'.ebs_h((string)$item['url_cmd']).'">';
            echo '<input type="submit" value="이동" '.ebs_v('STYLE_B1').'>';
            echo '</form>';
        } else {
            $cmd = (string)($item['cmd'] ?? 'MAIN_FRAME');
            $target = (string)($item['target'] ?? 'Sub');
            echo '<form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST" target="'.ebs_h($target).'" style="margin:0;">';
            echo '<input type="hidden" name="cmd" value="'.ebs_h($cmd).'"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h((string)$pass).'">';
            echo '<input type="submit" value="실행" '.ebs_v('STYLE_B1').'>';
            echo '</form>';
        }
        echo '</td></tr>';
    }
    echo '</table></center></body></html>';
}

function ebs_CITY2(): void {
    ebs_record_post('ebs_sub5.php::CITY2');
    ebs_render_sub5_menu('도시', [
        ['label'=>'수리','cmd'=>'RR','desc'=>'HP/EN을 현재 최대치까지 회복합니다.'],
        ['label'=>'은행','cmd'=>'FINANCE','desc'=>'소지금과 은행 예금을 입금/출금합니다.'],
        ['label'=>'송금','cmd'=>'MONEY','desc'=>'다른 캐릭터에게 소지금을 송금합니다.'],
        ['label'=>'양도','cmd'=>'PRE','desc'=>'장비중 또는 예비 무기를 다른 캐릭터에게 넘깁니다.'],
        ['label'=>'금괴환전','cmd'=>'HEA','desc'=>'골드로 금괴를 구입합니다.'],
        ['label'=>'금괴판매','cmd'=>'HES','desc'=>'보유 금괴를 골드로 판매합니다.'],
        ['label'=>'광고','url'=>'./ad_person.php','desc'=>'개인 광고/홍보 화면으로 이동합니다.'],
    ]);
}


function ebs_TRADE2(): void {
    ebs_record_post('ebs_sub5.php::TRADE2');
    ebs_render_sub5_menu('거래', [
        ['label'=>'경매','url'=>'auction.php','desc'=>'경매장으로 이동합니다.'],
        ['label'=>'창고','url'=>'bukiko.php','desc'=>'무기 창고와 판매장을 확인합니다.'],
        ['label'=>'무기 리스트','url'=>'./ebs.php?WEAPON','desc'=>'전체 무기 리스트를 확인합니다.'],
    ]);
}


function ebs_SPS2(): void {
    ebs_record_post('ebs_sub5.php::SPS2');
    ebs_render_sub5_menu('특별', [
        ['label'=>'스탯초기','cmd'=>'ST_RESET','desc'=>'공격/방어/속도/명중을 초기값으로 되돌립니다.'],
        ['label'=>'스탯찍기','cmd'=>'STATUSUP','desc'=>'레벨 기준 보너스 스탯을 분배합니다.'],
        ['label'=>'경험치 프리','cmd'=>'EP','desc'=>'금괴로 경험치 프리미엄을 구입합니다.'],
        ['label'=>'전체 프리','cmd'=>'AP','desc'=>'금괴로 전체 프리미엄을 구입합니다.'],
        ['label'=>'샌드백','cmd'=>'KAMO2','desc'=>'레벨 100 이상 전투 가능 캐릭터 목록을 표시합니다.'],
    ]);
}


function ebs_LOTO2(): void {
    ebs_record_post('ebs_sub5.php::LOTO2');
    ebs_render_sub5_menu('도박', [
        ['label'=>'포커','url'=>'./casino.php','desc'=>'포커 미니게임으로 이동합니다.'],
        ['label'=>'넥스트카드','url'=>'./nextcard.php','url_cmd'=>'START_GAME','desc'=>'카드 미니게임으로 이동합니다.'],
        ['label'=>'넘버즈','cmd'=>'NUMBERS','desc'=>'숫자 맞추기 화면으로 이동합니다.'],
    ]);
}


function ebs_AP2(): void {
    ebs_header_html();
    ebs_record_post('ebs_sub5.php::AP2');
    [$key, $me, $players, $err] = ebs_require_player();
    if ($err !== '' || !is_array($me) || $key === null) { ebs_error_page('Error', $err ?: '등록 데이터를 찾을 수 없습니다.'); return; }
    $pname=(string)($me['name'] ?? $key); $pass=ebs_param('pass', ebs_cookie_value('pass',''));
    $cost=450; $gold=max(0,(int)($me['goldbar'] ?? ebs_player_raw_get($me,72,'0'))); $msg='';
    if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && ebs_param('Cmode','') === '전체구입') {
        if ($gold < $cost) $msg='금괴가 부족합니다.';
        else {
            $gold -= $cost;
            $me['goldbar']=$gold;
            $me['exp_free']=(int)($me['exp_free'] ?? ebs_player_raw_get($me,73,'0')) + 100;
            $me['weapon_free']=(int)($me['weapon_free'] ?? ebs_player_raw_get($me,74,'0')) + 100;
            $me['total_free']=(int)($me['total_free'] ?? ebs_player_raw_get($me,75,'0')) + 1;
            ebs_player_raw_set($me,72,(string)$gold); ebs_player_raw_set($me,73,(string)$me['exp_free']); ebs_player_raw_set($me,74,(string)$me['weapon_free']); ebs_player_raw_set($me,75,(string)$me['total_free']);
            ebs_player_sync_common($me); $players[$key]=$me; ebs_players_save($players); $msg='전체 프리미엄 구입 완료';
        }
    }
    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>ENDLESS BATTLE</title></head><body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="margin:0;font-size:13px;">';
    echo '<center><form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST" target="Sub"><input type="hidden" name="cmd" value="AP"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'">';
    echo '<table border="1" cellspacing="0" cellpadding="6" bordercolor="'.ebs_h(ebs_v('TABLE_BORDER')).'" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" style="font-size:13px;min-width:390px;"><tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'" colspan="2"><b>전체 프리</b></td></tr>';
    if ($msg !== '') echo '<tr><td colspan="2" align="center"><b>'.ebs_h($msg).'</b></td></tr>';
    echo '<tr><td>보유 금괴</td><td align="right">'.ebs_h(number_format($gold)).'개</td></tr><tr><td>가격</td><td align="right">'.ebs_h(number_format($cost)).'개</td></tr>';
    echo '<tr><td colspan="2">경험치 프리 100개, 무기 프리 100개, 전체 프리 카운트를 함께 지급합니다.</td></tr>';
    echo '<tr><td colspan="2" align="center"><input name="Cmode" type="submit" value="전체구입" '.ebs_v('STYLE_B1').' onClick="return confirm(&quot;전체 프리미엄을 구입합니다. 괜찮습니까?&quot;)"></td></tr>';
    echo '</table></form></center></body></html>';
}


function ebs_EP2(): void {
    ebs_header_html();
    ebs_record_post('ebs_sub5.php::EP2');
    [$key, $me, $players, $err] = ebs_require_player();
    if ($err !== '' || !is_array($me) || $key === null) { ebs_error_page('Error', $err ?: '등록 데이터를 찾을 수 없습니다.'); return; }
    $pname=(string)($me['name'] ?? $key); $pass=ebs_param('pass', ebs_cookie_value('pass',''));
    $gold=max(0,(int)($me['goldbar'] ?? ebs_player_raw_get($me,72,'0'))); $msg='';
    if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
        $mode=ebs_param('Cmode',''); $qty=0; $cost=0;
        if ($mode === '경험치100개구입') { $qty=100; $cost=150; }
        if ($mode === '경험치500개구입') { $qty=500; $cost=750; }
        if ($qty > 0) {
            if ($gold < $cost) $msg='금괴가 부족합니다.';
            else {
                $gold -= $cost; $me['goldbar']=$gold; $me['exp_free']=(int)($me['exp_free'] ?? ebs_player_raw_get($me,73,'0')) + $qty;
                ebs_player_raw_set($me,72,(string)$gold); ebs_player_raw_set($me,73,(string)$me['exp_free']); ebs_player_sync_common($me); $players[$key]=$me; ebs_players_save($players); $msg='경험치 프리 '.$qty.'개 구입 완료';
            }
        }
    }
    $expFree=(int)($me['exp_free'] ?? ebs_player_raw_get($me,73,'0'));
    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>ENDLESS BATTLE</title></head><body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="margin:0;font-size:13px;">';
    echo '<center><form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST" target="Sub"><input type="hidden" name="cmd" value="EP"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'">';
    echo '<table border="1" cellspacing="0" cellpadding="6" bordercolor="'.ebs_h(ebs_v('TABLE_BORDER')).'" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" style="font-size:13px;min-width:390px;"><tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'" colspan="2"><b>경험치 프리</b></td></tr>';
    if ($msg !== '') echo '<tr><td colspan="2" align="center"><b>'.ebs_h($msg).'</b></td></tr>';
    echo '<tr><td>보유 금괴</td><td align="right">'.ebs_h(number_format($gold)).'개</td></tr><tr><td>경험치 프리</td><td align="right">'.ebs_h(number_format($expFree)).'개</td></tr>';
    echo '<tr><td>100개 가격</td><td align="right">150 금괴</td></tr><tr><td>500개 가격</td><td align="right">750 금괴</td></tr>';
    echo '<tr><td colspan="2" align="center"><input name="Cmode" type="submit" value="경험치100개구입" '.ebs_v('STYLE_B1').'> <input name="Cmode" type="submit" value="경험치500개구입" '.ebs_v('STYLE_B1').'></td></tr>';
    echo '</table></form></center></body></html>';
}


function ebs_HES2(): void {
    ebs_header_html();
    ebs_record_post('ebs_sub5.php::HES2');
    [$key, $me, $players, $err] = ebs_require_player();
    if ($err !== '' || !is_array($me) || $key === null) { ebs_error_page('Error', $err ?: '등록 데이터를 찾을 수 없습니다.'); return; }
    $pname=(string)($me['name'] ?? $key); $pass=ebs_param('pass', ebs_cookie_value('pass',''));
    $unit=max(1,(int)ebs_v('goldmoney','100000'));
    $money=max(0,(int)($me['money'] ?? 0));
    $gold=max(0,(int)($me['goldbar'] ?? ebs_player_raw_get($me,72,'0')));
    $msg='';
    if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
        $mode=ebs_param('Cmode','');
        $qty=0;
        if ($mode === '금괴100개판매') $qty=100;
        elseif ($mode === '금괴500개판매') $qty=500;
        elseif (is_numeric(ebs_param('gold_qty',''))) $qty=max(0,(int)ebs_param('gold_qty','0'));
        if ($qty > 0) {
            if ($qty > $gold) $msg='금괴가 부족합니다.';
            else { $gold-=$qty; $money+=$qty*$unit; $msg='금괴 '.number_format($qty).'개 판매 완료'; }
            $me['money']=$money; $me['goldbar']=$gold; ebs_player_raw_set($me,72,(string)$gold); ebs_player_sync_common($me); $players[$key]=$me; ebs_players_save($players);
        }
    }
    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>ENDLESS BATTLE</title></head><body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="margin:0;font-size:13px;">';
    echo '<center><form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST" name="Ms" target="Sub"><input type="hidden" name="cmd" value="HES"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'">';
    echo '<table border="1" cellspacing="0" cellpadding="6" bordercolor="'.ebs_h(ebs_v('TABLE_BORDER')).'" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" style="font-size:13px;min-width:360px;"><tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'" colspan="2"><b>금괴판매</b></td></tr>';
    if ($msg !== '') echo '<tr><td colspan="2" align="center"><b>'.ebs_h($msg).'</b></td></tr>';
    echo '<tr><td>소지금</td><td align="right">$'.ebs_h(number_format($money)).'</td></tr><tr><td>금괴</td><td align="right">'.ebs_h(number_format($gold)).'개</td></tr>';
    echo '<tr><td>1금괴 판매가</td><td align="right">$'.ebs_h(number_format($unit)).'</td></tr>';
    echo '<tr><td colspan="2" align="center"><input name="Cmode" type="submit" value="금괴100개판매" '.ebs_v('STYLE_B1').'> <input name="Cmode" type="submit" value="금괴500개판매" '.ebs_v('STYLE_B1').'></td></tr>';
    echo '<tr><td>직접 판매</td><td><input type="text" name="gold_qty" size="8" '.ebs_v('STYLE_L').'> 개 <input name="Cmode" type="submit" value="판매" '.ebs_v('STYLE_B1').'></td></tr>';
    echo '</table></form></center></body></html>';
}
function ebs_HEA2(): void {
    ebs_header_html();
    ebs_record_post('ebs_sub5.php::HEA2');
    [$key, $me, $players, $err] = ebs_require_player();
    if ($err !== '' || !is_array($me) || $key === null) { ebs_error_page('Error', $err ?: '등록 데이터를 찾을 수 없습니다.'); return; }
    $pname=(string)($me['name'] ?? $key); $pass=ebs_param('pass', ebs_cookie_value('pass',''));
    $unit=max(1,(int)ebs_v('goldmoney','100000'));
    $money=max(0,(int)($me['money'] ?? 0));
    $gold=max(0,(int)($me['goldbar'] ?? ebs_player_raw_get($me,72,'0')));
    $msg='';
    if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
        $mode=ebs_param('Cmode','');
        $qty=0;
        if ($mode === '금괴100개구입') $qty=100;
        elseif ($mode === '금괴500개구입') $qty=500;
        elseif (is_numeric(ebs_param('gold_qty',''))) $qty=max(0,(int)ebs_param('gold_qty','0'));
        if ($qty > 0) {
            $cost=$qty*$unit;
            if ($cost > $money) $msg='골드가 부족합니다.';
            else { $money-=$cost; $gold+=$qty; $msg='금괴 '.number_format($qty).'개 구입 완료'; }
            $me['money']=$money; $me['goldbar']=$gold; ebs_player_raw_set($me,72,(string)$gold); ebs_player_sync_common($me); $players[$key]=$me; ebs_players_save($players);
        }
    }
    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>ENDLESS BATTLE</title></head><body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="margin:0;font-size:13px;">';
    echo '<center><form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST" name="Ms" target="Sub"><input type="hidden" name="cmd" value="HEA"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'">';
    echo '<table border="1" cellspacing="0" cellpadding="6" bordercolor="'.ebs_h(ebs_v('TABLE_BORDER')).'" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" style="font-size:13px;min-width:360px;"><tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'" colspan="2"><b>금괴환전</b></td></tr>';
    if ($msg !== '') echo '<tr><td colspan="2" align="center"><b>'.ebs_h($msg).'</b></td></tr>';
    echo '<tr><td>소지금</td><td align="right">$'.ebs_h(number_format($money)).'</td></tr><tr><td>금괴</td><td align="right">'.ebs_h(number_format($gold)).'개</td></tr>';
    echo '<tr><td>1금괴 가격</td><td align="right">$'.ebs_h(number_format($unit)).'</td></tr>';
    echo '<tr><td colspan="2" align="center"><input name="Cmode" type="submit" value="금괴100개구입" '.ebs_v('STYLE_B1').'> <input name="Cmode" type="submit" value="금괴500개구입" '.ebs_v('STYLE_B1').'></td></tr>';
    echo '<tr><td>직접 구입</td><td><input type="text" name="gold_qty" size="8" '.ebs_v('STYLE_L').'> 개 <input name="Cmode" type="submit" value="구입" '.ebs_v('STYLE_B1').'></td></tr>';
    echo '</table></form></center></body></html>';
}
function ebs_RR2(): void {
    ebs_header_html();
    ebs_record_post('ebs_sub5.php::RR2');
    [$key, $me, $players, $err] = ebs_require_player();
    if ($err !== '' || !is_array($me) || $key === null) { ebs_error_page('Error', $err ?: '등록 데이터를 찾을 수 없습니다.'); return; }
    $pname=(string)($me['name'] ?? $key); $pass=ebs_param('pass', ebs_cookie_value('pass',''));
    $hp=max(0,(int)($me['hp'] ?? 0)); $maxHp=max($hp,(int)($me['max_hp'] ?? 4000));
    $en=max(0,(int)($me['en'] ?? 0)); $maxEn=max($en,(int)($me['max_en'] ?? 200));
    $money=max(0,(int)($me['money'] ?? 0));
    $hpCost=(int)ceil(max(0,$maxHp-$hp)*(float)ebs_v('HP_REPAIR2','0.5'));
    $enCost=(int)ceil(max(0,$maxEn-$en)*(float)ebs_v('EN_REPAIR2','0.5'));
    $allCost=$hpCost+$enCost;
    $msg='';
    if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
        $mode=ebs_param('Cmode','');
        $need=0;
        if ($mode === 'HP수리') $need=$hpCost;
        elseif ($mode === 'EN수리') $need=$enCost;
        elseif ($mode === '전부수리') $need=$allCost;
        if ($need > 0) {
            if ($need > $money) $msg='수리비가 부족합니다.';
            else {
                $money-=$need;
                if ($mode === 'HP수리' || $mode === '전부수리') $hp=$maxHp;
                if ($mode === 'EN수리' || $mode === '전부수리') $en=$maxEn;
                $msg=$mode.' 완료';
            }
            $me['money']=$money; $me['hp']=$hp; $me['en']=$en; ebs_player_sync_common($me); $players[$key]=$me; ebs_players_save($players);
            $hpCost=(int)ceil(max(0,$maxHp-$hp)*(float)ebs_v('HP_REPAIR2','0.5'));
            $enCost=(int)ceil(max(0,$maxEn-$en)*(float)ebs_v('EN_REPAIR2','0.5'));
            $allCost=$hpCost+$enCost;
        }
    }
    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>ENDLESS BATTLE</title></head><body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="margin:0;font-size:13px;">';
    echo '<center><form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST" name="Ms" target="Sub"><input type="hidden" name="cmd" value="RR"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'">';
    echo '<table border="1" cellspacing="0" cellpadding="6" bordercolor="'.ebs_h(ebs_v('TABLE_BORDER')).'" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" style="font-size:13px;min-width:380px;"><tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'" colspan="3"><b>수리</b></td></tr>';
    if ($msg !== '') echo '<tr><td colspan="3" align="center"><b>'.ebs_h($msg).'</b></td></tr>';
    echo '<tr><td>소지금</td><td colspan="2" align="right">$'.ebs_h(number_format($money)).'</td></tr>';
    echo '<tr><td>HP</td><td align="right">'.ebs_h(number_format($hp)).' / '.ebs_h(number_format($maxHp)).'</td><td align="right">$'.ebs_h(number_format($hpCost)).'</td></tr>';
    echo '<tr><td>EN</td><td align="right">'.ebs_h(number_format($en)).' / '.ebs_h(number_format($maxEn)).'</td><td align="right">$'.ebs_h(number_format($enCost)).'</td></tr>';
    echo '<tr><td>총 수리비</td><td colspan="2" align="right">$'.ebs_h(number_format($allCost)).'</td></tr>';
    echo '<tr><td colspan="3" align="center"><input name="Cmode" type="submit" value="HP수리" '.ebs_v('STYLE_B1').'> <input name="Cmode" type="submit" value="EN수리" '.ebs_v('STYLE_B1').'> <input name="Cmode" type="submit" value="전부수리" '.ebs_v('STYLE_B1').'></td></tr>';
    echo '</table></form></center></body></html>';
}
function ebs_CUSTOMING2(): void {
    $GLOBALS['EBS_DISABLE_AUTO_POST_SAVE'] = true;
    ebs_header_html();
    [$key, $me, $players, $err] = ebs_require_player();
    if ($err !== '' || !is_array($me) || $key === null) { ebs_error_page('Error', $err ?: '자신의 등록 데이터를 찾을 수 없습니다.'); return; }
    $pname=(string)($me['name'] ?? $key); $pass=ebs_param('pass', ebs_cookie_value('pass','')); $cmode=ebs_param('Cmode',''); $msg='';
    $money=max(0,(int)($me['money'] ?? 0));
    $charaNames=['0'=>'드셈','1'=>'소극','2'=>'보통','3'=>'격정','4'=>'냉정','5'=>'냉혹'];
    if ($cmode === '성격변경') {
        $newChara=(string)ebs_param('chara',(string)($me['chara'] ?? ebs_player_raw_get($me,12,'0')));
        if (!isset($charaNames[$newChara])) $newChara='0';
        if ($money < 20000) $msg='성격변경 비용이 부족합니다.';
        else {
            $money -= 20000;
            $me['money']=$money;
            $me['chara']=$newChara;
            ebs_player_raw_set($me,8,(string)$money);
            ebs_player_raw_set($me,12,$newChara);
            if (!isset($me['event_log']) || !is_array($me['event_log'])) $me['event_log']=[];
            $me['event_log'][]=['type'=>'custom','action'=>'chara','chara'=>$newChara,'time'=>date('YmdHis')];
            ebs_player_sync_common($me); $players[$key]=$me; ebs_players_save($players);
            $msg='성격변경 완료: '.$charaNames[$newChara];
        }
    }
    if ($cmode === ebs_arr('STATUS_NAME')[4].'업' || $cmode === 'HP업') {
        $n=max(1,min(30,(int)ebs_param('kai_kk','1'))); $cost=0; for($i=0;$i<$n;$i++) $cost += ((int)($me['max_hp'] ?? 4000)+5000)+200;
        if ((int)($me['max_hp'] ?? 0) >= (int)ebs_v('MAX_HP','5000000')) $msg='이미 HP 개조 한계입니다.';
        elseif ($money < $cost) $msg='자원이 부족합니다. 필요 금액 $'.number_format($cost).' / 보유 $'.number_format($money);
        else { $money-=$cost; $me['money']=$money; $me['max_hp']=(int)($me['max_hp'] ?? 4000)+5000*$n; $me['hp']=$me['max_hp']; $msg='HP 개조 완료'; ebs_player_sync_common($me); $players[$key]=$me; ebs_players_save($players); }
    }
    if ($cmode === ebs_arr('STATUS_NAME')[5].'업' || $cmode === 'EN업') {
        $n=max(1,min(30,(int)ebs_param('kai_kk2','1'))); $cost=0; for($i=0;$i<$n;$i++) $cost += ((int)($me['max_en'] ?? 200)*10+5000);
        if ((int)($me['max_en'] ?? 0) >= (int)ebs_v('MAX_EN','200000')) $msg='이미 EN 개조 한계입니다.';
        elseif ($money < $cost) $msg='자원이 부족합니다. 필요 금액 $'.number_format($cost).' / 보유 $'.number_format($money);
        else { $money-=$cost; $me['money']=$money; $me['max_en']=(int)($me['max_en'] ?? 200)+200*$n; $me['en']=$me['max_en']; $msg='EN 개조 완료'; ebs_player_sync_common($me); $players[$key]=$me; ebs_players_save($players); }
    }
    $hp=(int)($me['max_hp'] ?? 4000); $en=(int)($me['max_en'] ?? 200); $money=(int)($me['money'] ?? 0);
    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>ENDLESS BATTLE</title></head><body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="margin:0;font-size:13px;">';
    echo '<script>function YOSAN_h(){var hp='.(int)($hp+5000).';var n=document.Ms.kai_kk.selectedIndex+1;var total=n*hp+n*200;document.Ms.dmmy1.value=total;document.Ms.kai_1.value="$"+total;document.Ms.kai_1.style.color=(total<='.$money.')?"#ffffff":"red";}function YOSAN_e(){var en='.(int)($en*10+5000).';var n=document.Ms.kai_kk2.selectedIndex+1;var total=n*en;document.Ms.dmmy2.value=total;document.Ms.kai_2.value="$"+total;document.Ms.kai_2.style.color=(total<='.$money.')?"#ffffff":"red";}function checkHp(){return confirm("HP업의 '.ebs_h(ebs_v('CUSTOM_NAME','개조')).'을/를 합니다. 괜찮습니까?");}function checkEn(){return confirm("EN업의 '.ebs_h(ebs_v('CUSTOM_NAME','개조')).'을/를 합니다. 괜찮습니까?");}</script>';
    echo '<form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST" name="Ms" target="Sub"><input type="hidden" name="cmd" value="CUSTOMING"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'">';
    echo '<center><table border="1" cellspacing="0" cellpadding="4" bordercolor="'.ebs_h(ebs_v('TABLE_BORDER')).'" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" style="font-size:13px;min-width:430px;"><tr><td colspan="2" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'"><b>기체강화</b><span style="float:right">소지금 $'.ebs_h(number_format($money)).'</span></td></tr>';
    if ($msg !== '') echo '<tr><td colspan="2" align="center"><b>'.ebs_h($msg).'</b></td></tr>';
    echo '<tr>';
    echo '<td><b>HP업</b> 현재 '.ebs_h((string)$hp).'<br><input type="hidden" name="dmmy1"><select name="kai_kk" '.ebs_v('STYLE_L').' onChange="YOSAN_h()">'; for($i=1;$i<=30;$i++) echo '<option value="'.$i.'">'.$i.'회'; echo '</select><input type="text" name="kai_1" size="12" readonly style="border:none;background:#000000;color:#ffffff;text-align:right;"><br><input type="submit" name="Cmode" value="HP업" '.ebs_v('STYLE_B1').' onClick="return checkHp()"></td>';
    echo '<td><b>EN업</b> 현재 '.ebs_h((string)$en).'<br><input type="hidden" name="dmmy2"><select name="kai_kk2" '.ebs_v('STYLE_L').' onChange="YOSAN_e()">'; for($i=1;$i<=30;$i++) echo '<option value="'.$i.'">'.$i.'회'; echo '</select><input type="text" name="kai_2" size="12" readonly style="border:none;background:#000000;color:#ffffff;text-align:right;"><br><input type="submit" name="Cmode" value="EN업" '.ebs_v('STYLE_B1').' onClick="return checkEn()"></td>';
    echo '</tr>';
    $curChara=(string)($me['chara'] ?? ebs_player_raw_get($me,12,'0'));
    echo '<tr><td colspan="2"><b>성격변경</b> 현재 '.ebs_h($charaNames[$curChara] ?? $curChara).' / 비용 $20,000<br><select name="chara" '.ebs_v('STYLE_L').'>';
    foreach ($charaNames as $cv=>$cn) echo '<option value="'.ebs_h($cv).'"'.($cv===$curChara?' selected':'').'>'.ebs_h($cn);
    echo '</select> <input type="submit" name="Cmode" value="성격변경" '.ebs_v('STYLE_B1').' onClick="return confirm(\"성격을 변경합니다. 괜찮습니까?\")"></td></tr>';
    echo '</table></center></form><script>YOSAN_h();YOSAN_e();</script></body></html>';
}

function ebs_collect_history_rows(int $limit = 80): array {
    // 원본의 "역사"는 전투/접속 로그가 아니라 관리자가 작성한 역사 본문을 표시한다.
    // 자동 이벤트 로그, LASTBATTLE, 관리자 감사 로그는 여기서 출력하지 않는다.
    $rows = [];
    foreach (['history_data', 'history'] as $store) {
        $saved = ebs_json_load($store);
        if (!is_array($saved)) continue;
        foreach ($saved as $k=>$v) {
            if (is_array($v)) {
                $text = (string)($v['text'] ?? $v['body'] ?? $v['message'] ?? '');
                $time = (string)($v['time'] ?? $k);
            } elseif (is_scalar($v)) {
                $text = (string)$v;
                $time = (string)$k;
            } else continue;
            if (trim($text) !== '') $rows[] = ['time'=>$time, 'kind'=>'역사', 'text'=>$text];
        }
    }
    // 과거 수정본에서 수동 작성 역사도 admin_history.json에 저장된 경우가 있어, type 없는 항목만 호환 읽기한다.
    $legacy = ebs_json_load('admin_history');
    if (is_array($legacy)) {
        foreach ($legacy as $k=>$v) {
            if (!is_array($v)) continue;
            if (isset($v['type'])) continue; // 감사 로그 제외
            $text = (string)($v['text'] ?? $v['body'] ?? '');
            if (trim($text) !== '') $rows[] = ['time'=>(string)($v['time'] ?? $k), 'kind'=>'역사', 'text'=>$text];
        }
    }
    usort($rows, static function(array $a, array $b): int { return strcmp((string)($b['time'] ?? ''), (string)($a['time'] ?? '')); });
    return array_slice($rows, 0, $limit);
}

function ebs_collect_update_rows(int $limit = 80): array {
    // 원본의 "업뎃"은 관리자가 작성한 업데이트 목록만 출력한다.
    // 유저 이벤트 로그나 관리자 작업 로그는 섞지 않는다.
    $rows = [];
    foreach (['updata', 'update_data', 'updates'] as $store) {
        $up = ebs_json_load($store);
        if (!is_array($up)) continue;
        foreach ($up as $k=>$v) {
            if (is_array($v)) {
                $text = (string)($v['text'] ?? $v['body'] ?? $v['message'] ?? '');
                $time = (string)($v['time'] ?? $k);
            } elseif (is_scalar($v)) {
                $text = (string)$v;
                $time = (string)$k;
            } else continue;
            if (trim($text) !== '') $rows[] = ['time'=>$time, 'kind'=>'업데이트', 'text'=>$text];
        }
    }
    usort($rows, static function(array $a, array $b): int { return strcmp((string)($b['time'] ?? ''), (string)($a['time'] ?? '')); });
    return array_slice($rows, 0, $limit);
}

function ebs_render_rows_screen(string $title, array $rows): void {
    ebs_header_html();
    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>ENDLESS BATTLE</title></head><body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="margin:0;font-size:13px;overflow-x:hidden;">';
    echo '<table border="1" cellspacing="0" cellpadding="4" bordercolor="'.ebs_h(ebs_v('TABLE_BORDER')).'" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" style="font-size:13px;width:100%;max-width:100%;min-width:0;color:'.ebs_h(ebs_v('FONT_COLOR')).';table-layout:auto;">';
    echo '<tr><td colspan="3" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'"><b>'.ebs_h($title).'</b></td></tr>';
    echo '<tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'" style="width:130px;">일시</td><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'" style="width:70px;">구분</td><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'">내용</td></tr>';
    if (!$rows) echo '<tr><td colspan="3" align="center">표시할 기록이 없습니다.</td></tr>';
    foreach ($rows as $r) {
        $time=(string)($r['time'] ?? '');
        if (preg_match('/^\d{14}$/', $time)) $time = substr($time,0,4).'/'.substr($time,4,2).'/'.substr($time,6,2).' '.substr($time,8,2).':'.substr($time,10,2);
        echo '<tr bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'"><td style="white-space:nowrap;">'.ebs_h($time).'</td><td style="white-space:nowrap;">'.ebs_h((string)($r['kind'] ?? '')).'</td><td style="white-space:normal;word-break:break-all;overflow-wrap:anywhere;">'.ebs_h((string)($r['text'] ?? '')).'</td></tr>';
    }
    echo '</table></body></html>';
}

function ebs_render_history_screen(string $title='최근 역사'): void {
    ebs_render_rows_screen($title, ebs_collect_history_rows(100));
}

function ebs_render_update_screen(string $title='최근 업데이트'): void {
    ebs_render_rows_screen($title, ebs_collect_update_rows(100));
}

function ebs_HISALL2(): void {
    ebs_record_post('ebs_sub5.php::HISALL2');
    ebs_render_history_screen('최근 전체 역사');
}

function ebs_UPDATA2(): void {
    ebs_record_post('ebs_sub5.php::UPDATA2');
    ebs_render_update_screen('최근 업데이트');
}

function ebs_HISTORY(): void {
    ebs_record_post('ebs_sub5.php::HISTORY');
    ebs_render_history_screen('최근 역사');
}

function ebs_COMMENT(): void {
    ebs_header_html();
    ebs_record_post('ebs_sub5.php::COMMENT');
    [$key, $me, $players, $err] = ebs_require_player();
    if ($err !== '' || !is_array($me) || $key === null) { ebs_error_page('Error', $err ?: '등록 데이터를 찾을 수 없습니다.'); return; }
    $pname=(string)($me['name'] ?? $key); $pass=ebs_param('pass', ebs_cookie_value('pass',''));
    $msg='';
    if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && ebs_param('Cmode','') === '변경') {
        $comment = ebs_param('com','');
        $comment = function_exists('mb_substr') ? mb_substr($comment, 0, 80, 'UTF-8') : substr($comment, 0, 80);
        $me['comment'] = $comment !== '' ? $comment : 'noComment';
        ebs_player_sync_common($me); $players[$key]=$me; ebs_players_save($players);
        $msg='코멘트 변경 완료';
    }
    $current=(string)($me['comment'] ?? '');
    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>ENDLESS BATTLE</title></head><body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="margin:0;font-size:13px;">';
    echo '<center><form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST" name="Ms" target="Sub"><input type="hidden" name="cmd" value="COM"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'">';
    echo '<table border="1" cellspacing="0" cellpadding="6" bordercolor="'.ebs_h(ebs_v('TABLE_BORDER')).'" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" style="font-size:13px;min-width:520px;">';
    echo '<tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'"><b>코멘트 변경</b></td></tr>';
    if ($msg !== '') echo '<tr><td align="center"><b>'.ebs_h($msg).'</b></td></tr>';
    echo '<tr><td><span style="font-size:13px;">코멘트 입력 후 반드시 변경버튼을 눌러주세요. Enter키는 반영되지 않습니다.</span><br>';
    echo '&nbsp;&nbsp;<input type="text" name="com" size="70" maxlength="80" value="'.ebs_h($current).'" '.ebs_v('STYLE_L').'> ';
    echo '<input name="Cmode" type="submit" value="변경" '.ebs_v('STYLE_B1').' onClick="return confirm(&quot;코멘트를 변경합니다. 괜찮습니까?&quot;)"> ';
    echo '<input type="reset" value="클리어" '.ebs_v('STYLE_B1').'></td></tr>';
    echo '</table></form></center></body></html>';
}

function ebs_SPECIAL(): void {
    ebs_record_post('ebs_sub5.php::SPECIAL');
    ebs_header_html();
    [$key, $me, $players, $err] = ebs_require_player();
    $pname = is_array($me) ? (string)($me['name'] ?? $key) : ebs_param('pname', ebs_cookie_value('pname',''));
    $pass = ebs_param('pass', ebs_cookie_value('pass',''));
    if (is_array($me)) {
        ebs_player_normalize_legacy_fields($me);
    }
    $money = is_array($me) ? max(0, (int)($me['money'] ?? ebs_player_raw_get($me, 8, '0'))) : 0;
    $country = is_array($me) ? trim((string)($me['kuni'] ?? ebs_player_raw_get($me, 5, ''))) : '';
    $job = is_array($me) ? trim((string)($me['job'] ?? ebs_player_raw_get($me, 6, '0'))) : '0';

    $commands = [];
    $commands[] = ['건국', 'MAKE_C', is_array($me) && $money > (int)ebs_v('MAKE_COUNTRY','5000000') && ($job === '0' || $job === ''), '방랑자 + 건국비 필요'];
    $commands[] = ['격납', 'VAR', is_array($me), '무기/예비 장비 보관'];
    $commands[] = ['부대', 'MAKE_T', is_array($me) && $job !== '1' && $country !== '', '국가 소속 필요'];
    $commands[] = ['진급', 'UP_G', is_array($me), '국비/공헌/진급'];
    $commands[] = ['전략', 'MISSION', is_array($me) && $job === '1' && $country !== '', '국왕 전용'];
    $commands[] = ['요새강화', 'BOSS', is_array($me) && $job !== '0' && $job !== '' && $country !== '', '국가 직위 필요'];
    $commands[] = ['부대해산', 'DEL_U', is_array($me) && $job === '1' && $country !== '', '국왕 전용'];
    $commands[] = ['요새 상태', 'BOSS_LOOK', is_array($me) && $country !== '', '국가 소속 필요'];
    $commands[] = ['추방', 'DEL_UNIT', is_array($me) && $country !== '', '국가/부대 권한 필요'];

    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>ENDLESS BATTLE</title></head>';
    echo '<body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="margin:0;font-size:13px;" oncontextmenu="return false;">';
    echo '<form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST" name="Ms" target="Sub" style="margin:0;">';
    echo '<input type="hidden" name="cmd" value="SPC"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'">';
    echo '<table bordercolor="'.ebs_h(ebs_v('TABLE_BORDER')).'" border="1" cellspacing="0" cellpadding="4" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" style="font-size:10pt;width:auto;max-width:100%;">';
    echo '<tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'"><b>특수</b></td></tr><tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'"><br>&nbsp;&nbsp;';
    if ($err !== '') {
        echo '<font color="red">'.ebs_h($err).'</font>';
    } else {
        $printed = 0;
        foreach ($commands as $cmdInfo) {
            [$label, $targetCmd, $enabled, $reason] = $cmdInfo;
            if ($enabled) {
                $printed++;
                if ($targetCmd === 'VAR') {
                    echo '<input type="submit" name="st" value="'.ebs_h($label).'" '.ebs_v('STYLE_B1').' onclick="document.Ms.action=\'various.php\';document.Ms.cmd.value=\'TOP\';"> ';
                } else {
                    echo '<input name="custom" type="submit" value="'.ebs_h($label).'" '.ebs_v('STYLE_B1').' onclick="document.Ms.action=\''.ebs_h(ebs_v('MAIN_SCRIPT')).'\';document.Ms.cmd.value=\''.ebs_h($targetCmd).'\';"> ';
                }
            } else {
                echo '<span title="'.ebs_h($reason).'" style="display:inline-block;margin:2px;padding:2px 6px;border:1px solid #404040;color:#777;background:#101010;">'.ebs_h($label).'</span> ';
            }
        }
        if ($printed === 0) echo '<br>현재 조건에서 바로 실행 가능한 커맨드가 없습니다';
        echo '<br><br>';
        echo '<span style="font-size:12px;color:#cfcfcf;">현재 국가: '.ebs_h($country !== '' ? $country : '없음').' / 직위: '.ebs_h($job !== '' ? $job : '0').' / 소지금: $'.ebs_h(number_format($money)).'</span>';
    }
    echo '&nbsp;&nbsp;<br><br></td></tr></table></form></body></html>';
}



function ebs_MISSION2(): void {
    ebs_header_html();
    ebs_record_post('ebs_sub5.php::MISSION2');
    [$key, $me, $players, $err] = ebs_require_player();
    if ($err !== '' || !is_array($me) || $key === null) { ebs_error_page('Error', $err ?: '등록 데이터를 찾을 수 없습니다.'); return; }
    $pname=(string)($me['name'] ?? $key); $pass=ebs_param('pass', ebs_cookie_value('pass',''));
    $country=(string)($me['kuni'] ?? '');
    $rawCountries=ebs_json_load('countrydata'); $rawKey=ebs_country_find_raw_key($country, $rawCountries); $parts=$rawKey!==null ? ebs_country_raw_parts((string)$rawCountries[$rawKey]) : []; $msg='';
    if ($rawKey===null || $country==='') { ebs_error_page('전략', '소속 국가가 없거나 국가 데이터를 찾을 수 없습니다.'); return; }
    if ($parts[0]==='') $parts[0]='#808080'; if (!is_numeric($parts[1])) $parts[1]='0';
    $money=max(0,(int)$parts[1]);
    if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && ebs_param('Cmode','') === '발동') {
        $kikan=max(1,min(4,(int)ebs_param('kikan','1')));
        $cost=(int)preg_replace('/[^0-9]/','', ebs_param('sikin', (string)(8000*$kikan)));
        if ($cost <= 0) $cost=8000*$kikan;
        $mname=trim(ebs_param('mname',''));
        $main=trim(ebs_param('main',''));
        if ($mname==='') $msg='작전명이 입력되지 않았습니다.';
        elseif ($money < $cost) $msg='국비가 부족합니다.';
        else {
            $money-=$cost; $parts[1]=(string)$money; $parts[5]=$mname; $parts[6]=$main; $parts[7]=(string)(time()+21600*$kikan); $parts[8]=ebs_param('u1',''); $parts[9]=ebs_param('u2',''); $parts[10]=ebs_param('u3',''); $rawCountries[$rawKey]=ebs_country_raw_string($parts); ebs_json_save('countrydata',$rawCountries);
            $log=ebs_json_load('mission_log'); if (!is_array($log)) $log=[];
            $log[]=['country'=>$country,'pilot'=>$pname,'name'=>$mname,'main'=>$main,'cost'=>$cost,'hours'=>$kikan*6,'time'=>date('YmdHis')];
            if (count($log)>100) $log=array_slice($log,-100);
            ebs_json_save('mission_log',$log); $msg='전략 발동 완료';
        }
    }
    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>ENDLESS BATTLE</title></head><body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="margin:0;font-size:13px;">';
    echo '<center><form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST" name="Ms" target="Sub"><input type="hidden" name="cmd" value="MISSION"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'">';
    echo '<table border="1" cellspacing="0" cellpadding="6" bordercolor="'.ebs_h(ebs_v('TABLE_BORDER')).'" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" style="font-size:13px;min-width:420px;"><tr><td colspan="2" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'"><b>전략</b></td></tr>';
    if ($msg!=='') echo '<tr><td colspan="2" align="center"><b>'.ebs_h($msg).'</b></td></tr>';
    echo '<tr><td>국가</td><td>'.ebs_h($country).'</td></tr><tr><td>국비</td><td align="right">$'.ebs_h(number_format($money)).'</td></tr>';
    echo '<tr><td>전략 비용</td><td><input type="text" name="sikin" size="10" value="8000" '.ebs_v('STYLE_L').'></td></tr>';
    echo '<tr><td>작전명</td><td><input type="text" name="mname" size="25" maxlength="15" '.ebs_v('STYLE_L').'></td></tr>';
    $targets=[]; foreach (ebs_country_records() as $cn=>$cv) { if ($cn !== $country) $targets[]=$cn; } if (!$targets) $targets=['공격','방어','정찰']; $targetOptions=''; foreach ($targets as $t) $targetOptions.='<option value="'.ebs_h($t).'">'.ebs_h($t); echo '<tr><td>메인전략</td><td><select name="main" '.ebs_v('STYLE_L').'>'.$targetOptions.'</select></td></tr>'; $countryUnits=array_values(array_filter([(string)($parts[2]??''),(string)($parts[3]??''),(string)($parts[4]??'')], static fn(string $v): bool => $v!=='')); foreach ($countryUnits as $idx=>$unitName) { echo '<tr><td>제'.($idx+1).'부대 '.ebs_h($unitName).' 전략</td><td><select name="u'.($idx+1).'" '.ebs_v('STYLE_L').'>'.$targetOptions.'</select></td></tr>'; }
    echo '<tr><td>전략기간</td><td><select name="kikan" '.ebs_v('STYLE_L').'><option value="1">6시간<option value="2">12시간<option value="4">24시간</select></td></tr>';
    echo '<tr><td colspan="2" align="center"><input name="Cmode" type="submit" value="발동" '.ebs_v('STYLE_B1').' onClick="return confirm(&quot;전략을 발동합니다. 괜찮습니까?&quot;)"></td></tr>';
    echo '</table></form></center></body></html>';
}

function ebs_BOSS2(): void {
    ebs_header_html();
    ebs_record_post('ebs_sub5.php::BOSS2');
    [$key, $me, $players, $err] = ebs_require_player();
    if ($err !== '' || !is_array($me) || $key === null) { ebs_error_page('Error', $err ?: '등록 데이터를 찾을 수 없습니다.'); return; }
    $pname=(string)($me['name'] ?? $key); $pass=ebs_param('pass', ebs_cookie_value('pass',''));
    $country=(string)($me['kuni'] ?? ''); $rawCountries=ebs_json_load('countrydata'); $rawKey=ebs_country_find_raw_key($country, $rawCountries); $parts=$rawKey!==null ? ebs_country_raw_parts((string)$rawCountries[$rawKey]) : []; $msg='';
    if ($rawKey===null || $country==='') { ebs_error_page('국가', '소속 국가가 없거나 국가 데이터를 찾을 수 없습니다.'); return; }
    if ($parts[0]==='') $parts[0]='#808080'; if (!is_numeric($parts[1])) $parts[1]='0';
    if ($parts[11]==='') $parts[11]=ebs_v('YOUSAI_HP','600000').'!'.ebs_v('YOUSAI_HP','600000').'!'.time();
    if ($parts[12]==='') $parts[12]='30!30!30!'.$country;
    if ($parts[13]==='') $parts[13]='1000'; if ($parts[14]==='') $parts[14]=ebs_v('C_MAX_MEMBER','40');
    $money=max(0,(int)$parts[1]);
    [$yHp,$yMax,$yTime]=array_pad(explode('!', $parts[11], 3),3,'0'); $yHp=max(0,(int)$yHp); $yMax=max(1,(int)$yMax);
    [$yat,$yde,$yhi,$yname]=array_pad(explode('!', $parts[12], 4),4,'0');
    $icon=ebs_normalize_icon((string)$parts[13], '1000'); $maxMember=max(1,(int)$parts[14]);
    if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
        $mode=ebs_param('Cmode',''); $costs=['인구제한'=>5000,'문장변경'=>10000,'소회복'=>1000,'대회복'=>10000,'HP강화'=>50000,'공격력 강화'=>10000,'방어력 강화'=>10000,'명중력 강화'=>10000];
        if (isset($costs[$mode])) {
            $cost=$costs[$mode];
            if ($money < $cost) $msg='국비가 부족합니다.';
            else {
                $money-=$cost;
                if ($mode==='인구제한') $maxMember=max(1,min((int)ebs_v('C_MAX_MEMBER','40'),(int)ebs_param('ckisei',(string)$maxMember)));
                if ($mode==='문장변경') $icon=ebs_normalize_icon(ebs_param('yicon',(string)$icon), '1000');
                if ($mode==='소회복') $yHp=min($yMax,$yHp+(int)max(1,floor($yMax*0.1)));
                if ($mode==='대회복') $yHp=$yMax;
                if ($mode==='HP강화') { $yMax+=100000; $yHp+=100000; }
                if ($mode==='공격력 강화') $yat=(string)((int)$yat+5);
                if ($mode==='방어력 강화') $yde=(string)((int)$yde+5);
                if ($mode==='명중력 강화') $yhi=(string)((int)$yhi+5);
                $parts[1]=(string)$money; $parts[11]=$yHp.'!'.$yMax.'!'.time(); $parts[12]=$yat.'!'.$yde.'!'.$yhi.'!'.$yname; $parts[13]=(string)$icon; $parts[14]=(string)$maxMember;
                $rawCountries[$rawKey]=ebs_country_raw_string($parts); ebs_json_save('countrydata',$rawCountries); $msg=$mode.' 완료';
            }
        }
    }
    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>ENDLESS BATTLE</title></head><body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="margin:0;font-size:13px;">';
    echo '<center><form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST" name="Ms" target="Sub"><input type="hidden" name="cmd" value="BOSS"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'">';
    echo '<table border="1" cellspacing="0" cellpadding="6" bordercolor="'.ebs_h(ebs_v('TABLE_BORDER')).'" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" style="font-size:13px;min-width:460px;">';
    echo '<tr><td colspan="3" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'"><b>국가 관리 - '.ebs_h($country).'</b></td></tr>';
    if ($msg!=='') echo '<tr><td colspan="3" align="center"><b>'.ebs_h($msg).'</b></td></tr>';
    echo '<tr><td>국비</td><td colspan="2" align="right">$'.ebs_h(number_format($money)).'</td></tr>';
    echo '<tr><td>국경폐쇄</td><td><select name="ckisei" '.ebs_v('STYLE_L').'>'; for($i=1;$i<=(int)ebs_v('C_MAX_MEMBER','40');$i++){ echo '<option value="'.$i.'"'.($i===$maxMember?' selected':'').'>국민최대수를 '.$i.'명으로 제한'; } echo '</select></td><td><input name="Cmode" type="submit" value="인구제한" '.ebs_v('STYLE_B1').'></td></tr>';
    echo '<tr><td>문장</td><td><img src="'.ebs_h(ebs_v('IMG_FOLDER2')).'/'.ebs_h((string)$icon).'.gif" name="ymsImg"> <select name="yicon" '.ebs_v('STYLE_L').'> '; foreach (array_slice(ebs_existing_icon_ids(),0,80) as $id){ echo '<option value="'.ebs_h($id).'"'.((string)$id===(string)$icon?' selected':'').'>문장 No.'.ebs_h($id); } echo '</select></td><td><input name="Cmode" type="submit" value="문장변경" '.ebs_v('STYLE_B1').'></td></tr>';
    echo '<tr><td>요새 HP</td><td>'.ebs_h(number_format($yHp)).' / '.ebs_h(number_format($yMax)).'</td><td><input name="Cmode" type="submit" value="소회복" '.ebs_v('STYLE_B1').'> <input name="Cmode" type="submit" value="대회복" '.ebs_v('STYLE_B1').'> <input name="Cmode" type="submit" value="HP강화" '.ebs_v('STYLE_B1').'></td></tr>';
    echo '<tr><td>요새 능력</td><td>공격 '.ebs_h((string)$yat).' / 방어 '.ebs_h((string)$yde).' / 명중 '.ebs_h((string)$yhi).'</td><td><input name="Cmode" type="submit" value="공격력 강화" '.ebs_v('STYLE_B1').'> <input name="Cmode" type="submit" value="방어력 강화" '.ebs_v('STYLE_B1').'> <input name="Cmode" type="submit" value="명중력 강화" '.ebs_v('STYLE_B1').'></td></tr>';
    echo '</table></form></center></body></html>';
}

function ebs_MAKE_C2(): void {
    ebs_header_html();
    ebs_record_post('ebs_sub5.php::MAKE_C2');
    [$key, $me, $players, $err] = ebs_require_player();
    if ($err !== '' || !is_array($me) || $key === null) { ebs_error_page('Error', $err ?: '등록 데이터를 찾을 수 없습니다.'); return; }
    $pname=(string)($me['name'] ?? $key); $pass=ebs_param('pass', ebs_cookie_value('pass',''));
    $rawCountries = ebs_json_load('countrydata');
    $countries = ebs_country_records();
    $maxCountries = (int)ebs_v('COUNTRY_MAX','10');
    $cost = (int)ebs_v('MAKE_COUNTRY','5000000');
    $money = max(0,(int)($me['money'] ?? 0));
    $msg='';
    if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && ebs_param('Cmode','') === '건국') {
        $cname = trim(ebs_param('cname',''));
        $yname = trim(ebs_param('yname',''));
        $color = ebs_color(ebs_param('cl','C0C0C0'), '#C0C0C0');
        $icon = ebs_normalize_icon(ebs_param('yicon','1000'), '1000');
        if ($cname === '') $msg='국가명이 기입되지 않았습니다.';
        elseif (ebs_strlen($cname) > 20) $msg='국가명이 너무 깁니다.';
        elseif (isset($countries[$cname])) $msg='동명의 나라가 이미 존재합니다.';
        elseif (count($countries) >= $maxCountries) $msg=$maxCountries.'국 이상의 건국은 할 수 없습니다.';
        elseif ($money < $cost) $msg='건국 비용이 부족합니다.';
        else {
            $money -= $cost; $me['money']=$money; $me['kuni']=$cname; $me['job']='1'; $me['rank']=200;
            ebs_player_raw_set($me,0,'200'); ebs_player_raw_set($me,5,$cname); ebs_player_raw_set($me,6,'1');
            $fort = ebs_v('YOUSAI_HP','600000').'!'.ebs_v('YOUSAI_HP','600000').'!'.time();
            $st = '1!1!1!'.($yname !== '' ? $yname : $cname.'요새');
            $countryParts=[$color,'10000','','','','','0','0','','','',$fort,$st,$icon,'20'];
            $rawCountries[$cname.'.txt'] = ebs_country_raw_string($countryParts);
            ebs_json_save('countrydata', $rawCountries);
            ebs_player_sync_common($me); $players[$key]=$me; ebs_players_save($players);
            $countries = ebs_country_records();
            $msg='건국 완료';
        }
    }
    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>ENDLESS BATTLE</title></head><body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="margin:0;font-size:13px;">';
    echo '<script>function changeImg(){var num=document.Ms.yicon.value;document.ymsImg.src="'.ebs_h(ebs_v('IMG_FOLDER2')).'/"+num+".gif";}</script>';
    echo '<center><form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST" name="Ms" target="Sub"><input type="hidden" name="cmd" value="MAKE_C"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'">';
    echo '<table border="1" cellspacing="0" cellpadding="6" bordercolor="'.ebs_h(ebs_v('TABLE_BORDER')).'" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" style="font-size:13px;min-width:430px;">';
    echo '<tr><td colspan="2" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'"><b>건국</b></td></tr>';
    if ($msg !== '') echo '<tr><td colspan="2" align="center"><b>'.ebs_h($msg).'</b></td></tr>';
    echo '<tr><td>현재 국가 수</td><td>'.ebs_h((string)count($countries)).' / '.ebs_h((string)$maxCountries).'</td></tr>';
    echo '<tr><td>건국비용</td><td>$'.ebs_h(number_format($cost)).' / 소지금 $'.ebs_h(number_format($money)).'</td></tr>';
    echo '<tr><td>국가명</td><td><input type="text" name="cname" size="25" maxlength="20" '.ebs_v('STYLE_L').'></td></tr>';
    echo '<tr><td>요새 명칭</td><td><input type="text" name="yname" size="25" maxlength="20" '.ebs_v('STYLE_L').'></td></tr>';
    echo '<tr><td>문장</td><td><img src="'.ebs_h(ebs_v('IMG_FOLDER2')).'/1000.gif" name="ymsImg"> <select name="yicon" '.ebs_v('STYLE_L').' onChange="changeImg()">';
    foreach (ebs_existing_icon_ids() as $id) { if ((int)$id < 1000 || (int)$id > 1020) continue; echo '<option value="'.ebs_h($id).'">문장 No.'.ebs_h($id); }
    echo '</select></td></tr>';
    echo '<tr><td>국가색</td><td><input type="radio" name="cl" value="C0C0C0" checked><font color="#C0C0C0">■</font> ';
    foreach (array_slice(ebs_arr('COLOR'),0,12) as $c) echo '<input type="radio" name="cl" value="'.ebs_h((string)$c).'"><font color="#'.ebs_h((string)$c).'">■</font>';
    echo '</td></tr><tr><td colspan="2" align="center"><input name="Cmode" type="submit" value="건국" '.ebs_v('STYLE_B1').' onClick="return confirm(\'건국합니다. 괜찮습니까?\')"> <input type="reset" value="클리어" '.ebs_v('STYLE_B1').'></td></tr>';
    echo '</table></form></center></body></html>';
}

function ebs_MAKE_T2(): void {
    ebs_header_html();
    ebs_record_post('ebs_sub5.php::MAKE_T2');
    [$key, $me, $players, $err] = ebs_require_player();
    if ($err !== '' || !is_array($me) || $key === null) { ebs_error_page('Error', $err ?: '등록 데이터를 찾을 수 없습니다.'); return; }
    $pname=(string)($me['name'] ?? $key); $pass=ebs_param('pass', ebs_cookie_value('pass',''));
    $cost=(int)ebs_v('MAKE_TEAM','50000');
    $money=max(0,(int)($me['money'] ?? 0));
    $myCountry=(string)($me['kuni'] ?? '');
    $myUnit=trim((string)($me['unit'] ?? ebs_player_raw_get($me,28,'')));
    $job=(string)($me['job'] ?? ebs_player_raw_get($me,6,'0'));
    $level=max((int)($me['level'] ?? 1), (int)ebs_player_raw_get($me,29,'1'));
    $msg='';
    $units = [];
    foreach ($players as $p) {
        if (!is_array($p)) continue;
        if ((string)($p['kuni'] ?? '') !== $myCountry) continue;
        $u=trim((string)($p['unit'] ?? ebs_player_raw_get($p,28,'')));
        if ($u !== '') $units[$u] = true;
    }
    if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
        $cmode=ebs_param('Cmode','');
        if ($cmode === '부대작성') {
            $uname=trim(ebs_param('uname',''));
            if ($myCountry === '') $msg='국가에 소속되어야 부대를 작성할 수 있습니다.';
            elseif ($job === '1') $msg='국왕은 부대 커맨드를 사용할 수 없습니다.';
            elseif ($myUnit !== '') $msg='이미 소속된 부대가 있습니다.';
            elseif ($uname === '') $msg='부대명이 기입되지 않았습니다.';
            elseif (ebs_strlen($uname) > 15) $msg='부대명이 너무 깁니다.';
            elseif (isset($units[$uname])) $msg='동명의 부대가 이미 존재합니다.';
            elseif (count($units) >= 3) $msg='이미 3개 부대가 존재합니다.';
            elseif ($money < $cost) $msg='부대작성 비용이 부족합니다.';
            elseif ($level < 150 && (int)($me['rank'] ?? 0) < 150) $msg='부대작성 조건을 만족하지 못했습니다.';
            else {
                $money-=$cost;
                $me['money']=$money;
                $me['unit']=$uname;
                $me['unit_rank']='leader';
                $me['job']='-1';
                ebs_player_raw_set($me,8,(string)$money);
                ebs_player_raw_set($me,28,$uname);
                ebs_player_raw_set($me,6,'-1');
                if (!isset($me['event_log']) || !is_array($me['event_log'])) $me['event_log']=[];
                $me['event_log'][]=['type'=>'unit','action'=>'create','unit'=>$uname,'time'=>date('YmdHis')];
                $rawCountries = ebs_json_load('countrydata'); $rawKey = ebs_country_find_raw_key($myCountry, $rawCountries); if ($rawKey !== null) { $cp = ebs_country_raw_parts((string)$rawCountries[$rawKey]); for ($i=2; $i<=4; $i++) { if ($cp[$i] === '') { $cp[$i] = $uname; break; } } $rawCountries[$rawKey] = ebs_country_raw_string($cp); ebs_json_save('countrydata', $rawCountries); }
                $msg='부대작성 완료';
                $myUnit=$uname; $job='-1'; $units[$uname]=true;
            }
        } elseif ($cmode === '입대') {
            $in=trim(ebs_param('inunit',''));
            if ($myCountry === '') $msg='국가에 소속되어야 입대할 수 있습니다.';
            elseif ($job === '1') $msg='국왕은 부대 커맨드를 사용할 수 없습니다.';
            elseif ($myUnit !== '') $msg='이미 소속된 부대가 있습니다.';
            elseif ($in !== '' && isset($units[$in])) {
                $me['unit']=$in; $me['unit_rank']='0';
                ebs_player_raw_set($me,28,$in);
                if (!isset($me['event_log']) || !is_array($me['event_log'])) $me['event_log']=[];
                $me['event_log'][]=['type'=>'unit','action'=>'join','unit'=>$in,'time'=>date('YmdHis')];
                $msg='입대 완료'; $myUnit=$in;
            } else $msg='선택한 부대가 없습니다.';
        } elseif ($cmode === '제대') {
            if ($myUnit === '') $msg='소속 부대가 없습니다.';
            else {
                $me['unit']=''; $me['unit_rank']='0';
                if ($job === '-1') { $me['job']='0'; ebs_player_raw_set($me,6,'0'); }
                ebs_player_raw_set($me,28,'');
                if (!isset($me['event_log']) || !is_array($me['event_log'])) $me['event_log']=[];
                $me['event_log'][]=['type'=>'unit','action'=>'leave','unit'=>$myUnit,'time'=>date('YmdHis')];
                $msg='제대 완료'; $myUnit='';
            }
        }
        ebs_player_sync_common($me); $players[$key]=$me; ebs_players_save($players);
        $units=[];
        foreach ($players as $p) {
            if (!is_array($p)) continue;
            if ((string)($p['kuni'] ?? '') !== $myCountry) continue;
            $u=trim((string)($p['unit'] ?? ebs_player_raw_get($p,28,'')));
            if ($u !== '') $units[$u] = true;
        }
    }
    $canUse = ($myCountry !== '' && $job !== '1');
    $canCreate = ($canUse && $myUnit === '' && count($units) < 3 && $money >= $cost && ($level >= 150 || (int)($me['rank'] ?? 0) >= 150));
    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>ENDLESS BATTLE</title></head><body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="margin:0;font-size:13px;">';
    echo '<center><form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST" name="Ms" target="Sub"><input type="hidden" name="cmd" value="MAKE_T"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'">';
    echo '<table border="1" cellspacing="0" cellpadding="6" bordercolor="'.ebs_h(ebs_v('TABLE_BORDER')).'" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" style="font-size:13px;min-width:430px;">';
    echo '<tr><td colspan="2" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'"><b>부대</b></td></tr>';
    if ($msg !== '') echo '<tr><td colspan="2" align="center"><b>'.ebs_h($msg).'</b></td></tr>';
    echo '<tr><td>현재 국가</td><td>'.ebs_h($myCountry !== '' ? $myCountry : ebs_v('NONE_NATIONALITY')).'</td></tr>';
    echo '<tr><td>현재 부대</td><td>'.ebs_h($myUnit !== '' ? $myUnit : '무소속').'</td></tr>';
    echo '<tr><td>부대 수</td><td>'.ebs_h((string)count($units)).' / 3</td></tr>';
    if (!$canUse) {
        echo '<tr><td colspan="2" align="center"><b>부대커맨드는 사용할 수 없습니다</b></td></tr>';
    } else {
        if ($myUnit === '' && $units) {
            echo '<tr><td><b>입대</b></td><td><select name="inunit" '.ebs_v('STYLE_L').'>';
            foreach (array_keys($units) as $u) echo '<option value="'.ebs_h($u).'">'.ebs_h($u);
            echo '</select> <input name="Cmode" type="submit" value="입대" '.ebs_v('STYLE_B1').' onClick="return confirm(&quot;입대합니다. 괜찮습니까?&quot;)"></td></tr>';
        }
        if ($myUnit !== '') {
            echo '<tr><td><b>제대</b></td><td>부대&nbsp;'.ebs_h($myUnit).' <input name="Cmode" type="submit" value="제대" '.ebs_v('STYLE_B1').' onClick="return confirm(&quot;제대합니다. 괜찮습니까?&quot;)"></td></tr>';
        }
        if ($canCreate) {
            echo '<tr><td><b>부대작성</b><br>작성비용 $'.ebs_h(number_format($cost)).'</td><td>부대의 이름 <input type="text" name="uname" size="25" maxlength="15" '.ebs_v('STYLE_L').'> <input name="Cmode" type="submit" value="부대작성" '.ebs_v('STYLE_B1').' onClick="return confirm(&quot;부대를 작성합니다. 괜찮습니까?&quot;)"></td></tr>';
        } elseif ($myUnit === '') {
            echo '<tr><td><b>부대작성</b></td><td>조건: 국가 소속, Lv150 이상, 비용 $'.ebs_h(number_format($cost)).', 3개 미만</td></tr>';
        }
    }
    echo '</table></form></center></body></html>';
}

function ebs_UP_G2(): void {
    $GLOBALS['EBS_DISABLE_AUTO_POST_SAVE'] = true;
    ebs_header_html();
    ebs_record_post('ebs_sub5.php::UP_G2');
    [$key, $me, $players, $err] = ebs_require_player();
    if ($err !== '' || !is_array($me) || $key === null) { ebs_error_page('Error', $err ?: '등록 데이터를 찾을 수 없습니다.'); return; }
    $pname=(string)($me['name'] ?? $key); $pass=ebs_param('pass', ebs_cookie_value('pass',''));
    $country=(string)($me['kuni'] ?? ''); $rawCountries=ebs_json_load('countrydata'); $rawKey=ebs_country_find_raw_key($country, $rawCountries); $parts=$rawKey!==null ? ebs_country_raw_parts((string)$rawCountries[$rawKey]) : []; $msg='';
    $countryMoney = $rawKey !== null ? max(0,(int)($parts[1] ?? 0)) : 0;
    $money=max(0,(int)($me['money'] ?? 0));
    $contrib=max(0,(int)($me['contrib'] ?? ebs_player_raw_get($me,43,'0')));
    if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
        $mode=ebs_param('Cmode','');
        if ($mode === '기부') {
            $amt=(int)preg_replace('/[^0-9]/','', ebs_param('donate','0'));
            if ($country==='' || $rawKey===null) $msg='소속 국가가 없습니다.';
            elseif ($amt <= 0) $msg='기부할 금액을 입력하세요.';
            elseif ($money < $amt) $msg='소지금이 부족합니다.';
            else { $money-=$amt; $countryMoney+=$amt; $contrib += max(1,(int)floor($amt/100000)); $me['money']=$money; $me['contrib']=$contrib; ebs_player_raw_set($me,43,(string)$contrib); $parts[1]=(string)$countryMoney; $rawCountries[$rawKey]=ebs_country_raw_string($parts); ebs_json_save('countrydata',$rawCountries); ebs_player_sync_common($me); $players[$key]=$me; ebs_players_save($players); $msg='국비 기부 완료'; }
        } elseif (in_array($mode, ['백작진급','후작진급','공작진급'], true)) {
            $costMap=['백작진급'=>1,'후작진급'=>5,'공작진급'=>10];
            $classMap=['백작진급'=>80,'후작진급'=>90,'공작진급'=>100];
            $rankMap=['백작진급'=>'백작','후작진급'=>'후작','공작진급'=>'공작'];
            $need=$costMap[$mode];
            if ($contrib < $need) $msg='공헌도가 부족합니다.';
            else {
                $contrib-=$need;
                $me['contrib']=$contrib;
                $me['contribution']=$contrib;
                $me['job']=(string)$classMap[$mode];
                ebs_player_raw_set($me,6,(string)$classMap[$mode]);
                ebs_player_raw_set($me,43,(string)$contrib);
                ebs_player_sync_common($me); $players[$key]=$me; ebs_players_save($players); $msg=$rankMap[$mode].' 진급 완료';
            }
        }
    }
    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>ENDLESS BATTLE</title></head><body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="margin:0;font-size:13px;">';
    echo '<center><form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST" name="Ms" target="Sub"><input type="hidden" name="cmd" value="UP_G"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'">';
    echo '<table border="1" cellspacing="0" cellpadding="6" bordercolor="'.ebs_h(ebs_v('TABLE_BORDER')).'" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" style="font-size:13px;min-width:430px;">';
    echo '<tr><td colspan="2" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'" align="center"><b>국비 / 공헌</b></td></tr>';
    if ($msg !== '') echo '<tr><td colspan="2" align="center"><b>'.ebs_h($msg).'</b></td></tr>';
    echo '<tr><td>국가</td><td>'.ebs_h($country !== '' ? $country : '방랑자').'</td></tr><tr><td>소지금</td><td align="right">$'.ebs_h(number_format($money)).'</td></tr><tr><td>국비</td><td align="right">$'.ebs_h(number_format($countryMoney)).'</td></tr><tr><td>공헌도</td><td align="right">'.ebs_h((string)$contrib).'</td></tr>';
    echo '<tr><td>국비 기부</td><td><input type="text" name="donate" size="10" '.ebs_v('STYLE_L').'> <input type="submit" name="Cmode" value="기부" '.ebs_v('STYLE_B1').' onClick="return confirm(&quot;국비를 기부합니다. 괜찮습니까?&quot;)"></td></tr>';
    echo '<tr><td>진급</td><td>백작:공헌 1 / 후작:5 / 공작:10<br><input name="Cmode" type="submit" value="백작진급" '.ebs_v('STYLE_B1').'> <input name="Cmode" type="submit" value="후작진급" '.ebs_v('STYLE_B1').'> <input name="Cmode" type="submit" value="공작진급" '.ebs_v('STYLE_B1').'></td></tr>';
    echo '</table></form></center></body></html>';
}

function ebs_DEL_UNIT(): void {
    $GLOBALS['EBS_DISABLE_AUTO_POST_SAVE'] = true;
    ebs_header_html();
    ebs_record_post('ebs_sub5.php::DEL_UNIT');
    [$key, $me, $players, $err] = ebs_require_player();
    if ($err !== '' || !is_array($me) || $key === null) { ebs_error_page('Error', $err ?: '등록 데이터를 찾을 수 없습니다.'); return; }
    $pname=(string)($me['name'] ?? $key); $pass=ebs_param('pass', ebs_cookie_value('pass',''));
    $myCountry=(string)($me['kuni'] ?? '');
    $myUnit=(string)($me['unit'] ?? ebs_player_raw_get($me,28,''));
    $isLeader=((string)($me['unit_rank'] ?? '') === 'leader' || (string)($me['unit_rank'] ?? '') === '1' || (string)($me['rank'] ?? '') === '부대장');
    $msg='';
    if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && ebs_param('Cmode','') === '추방') {
        $target=trim(ebs_param('target_member',''));
        $targetKey=ebs_find_player_key($target, $players);
        if ($myUnit === '') $msg='소속 부대가 없습니다.';
        elseif (!$isLeader) $msg='부대장만 추방할 수 있습니다.';
        elseif ($target === '' || $targetKey === null || !isset($players[$targetKey]) || !is_array($players[$targetKey])) $msg='추방할 부대원을 선택하세요.';
        elseif ((string)($players[$targetKey]['name'] ?? $targetKey) === $pname) $msg='자기 자신은 추방할 수 없습니다.';
        elseif ((string)($players[$targetKey]['kuni'] ?? '') !== $myCountry || (string)($players[$targetKey]['unit'] ?? ebs_player_raw_get($players[$targetKey],28,'')) !== $myUnit) $msg='같은 부대원이 아닙니다.';
        else {
            $players[$targetKey]['unit']='';
            $players[$targetKey]['unit_rank']='0';
            ebs_player_raw_set($players[$targetKey], 28, '');
            if (!isset($players[$targetKey]['event_log']) || !is_array($players[$targetKey]['event_log'])) $players[$targetKey]['event_log']=[];
            $players[$targetKey]['event_log'][]=['type'=>'unit','action'=>'expelled','by'=>$pname,'unit'=>$myUnit,'time'=>date('YmdHis')];
            ebs_player_sync_common($players[$targetKey]);
            ebs_players_save($players);
            $msg='부대원 추방 완료: '.$target;
        }
    }
    $members=[];
    foreach ($players as $nm=>$pl) {
        if (!is_array($pl)) continue;
        $nm2=(string)($pl['name'] ?? $nm);
        if ($nm2 === $pname) continue;
        if ((string)($pl['kuni'] ?? '') !== $myCountry) continue;
        if ((string)($pl['unit'] ?? ebs_player_raw_get($pl,28,'')) !== $myUnit || $myUnit === '') continue;
        $members[$nm2]=$pl;
    }
    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>ENDLESS BATTLE</title></head><body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="margin:0;font-size:13px;">';
    echo '<center><form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST" target="Sub"><input type="hidden" name="cmd" value="DEL_UNIT"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'">';
    echo '<table border="1" cellspacing="0" cellpadding="6" bordercolor="'.ebs_h(ebs_v('TABLE_BORDER')).'" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" style="font-size:13px;min-width:460px;">';
    echo '<tr><td colspan="2" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'" align="center"><b>부대원 추방</b></td></tr>';
    if ($msg !== '') echo '<tr><td colspan="2" align="center"><b>'.ebs_h($msg).'</b></td></tr>';
    echo '<tr><td>현재 부대</td><td>'.ebs_h($myUnit !== '' ? $myUnit : '없음').'</td></tr><tr><td>권한</td><td>'.($isLeader ? '<font color="#00ff66">부대장</font>' : '<font color="red">부대장 아님</font>').'</td></tr>';
    echo '<tr><td>대상</td><td><select name="target_member" '.ebs_v('STYLE_L').'>';
    foreach ($members as $nm=>$pl) echo '<option value="'.ebs_h($nm).'">'.ebs_h($nm.' Lv.'.(string)($pl['level'] ?? '1'));
    if (!$members) echo '<option value="">추방 가능한 부대원 없음';
    echo '</select></td></tr><tr><td colspan="2" align="center"><input type="submit" name="Cmode" value="추방" '.ebs_v('STYLE_B1').' onclick="return confirm(&quot;선택한 부대원을 추방합니다. 괜찮습니까?&quot;)"> ';
    echo '<input type="submit" value="부대 메뉴" '.ebs_v('STYLE_B1').' onclick="this.form.cmd.value=&quot;MAKE_T&quot;;"></td></tr>';
    echo '</table></form></center></body></html>';
}

function ebs_DEL_U2(): void {
    $GLOBALS['EBS_DISABLE_AUTO_POST_SAVE'] = true;
    ebs_header_html();
    ebs_record_post('ebs_sub5.php::DEL_U2');
    [$key, $me, $players, $err] = ebs_require_player();
    if ($err !== '' || !is_array($me) || $key === null) { ebs_error_page('Error', $err ?: '등록 데이터를 찾을 수 없습니다.'); return; }
    $pname=(string)($me['name'] ?? $key); $pass=ebs_param('pass', ebs_cookie_value('pass',''));
    $myCountry=(string)($me['kuni'] ?? '');
    $myUnit=(string)($me['unit'] ?? ebs_player_raw_get($me,28,''));
    $isLeader=((string)($me['unit_rank'] ?? '') === 'leader' || (string)($me['unit_rank'] ?? '') === '1' || (string)($me['rank'] ?? '') === '부대장');
    $msg=''; $count=0;
    if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && ebs_param('Cmode','') === '해산') {
        if ($myUnit === '') $msg='소속 부대가 없습니다.';
        elseif (!$isLeader) $msg='부대장만 해산할 수 있습니다.';
        else {
            foreach ($players as $nm=>$pl) {
                if (!is_array($pl)) continue;
                if ((string)($pl['kuni'] ?? '') !== $myCountry) continue;
                if ((string)($pl['unit'] ?? ebs_player_raw_get($pl,28,'')) !== $myUnit) continue;
                $players[$nm]['unit']='';
                $players[$nm]['unit_rank']='0';
                ebs_player_raw_set($players[$nm], 28, '');
                if (!isset($players[$nm]['event_log']) || !is_array($players[$nm]['event_log'])) $players[$nm]['event_log']=[];
                $players[$nm]['event_log'][]=['type'=>'unit','action'=>'disband','by'=>$pname,'unit'=>$myUnit,'time'=>date('YmdHis')];
                ebs_player_sync_common($players[$nm]);
                $count++;
            }
            $rawCountries = ebs_json_load('countrydata'); $rawKey = ebs_country_find_raw_key($myCountry, $rawCountries); if ($rawKey !== null) { $cp = ebs_country_raw_parts((string)$rawCountries[$rawKey]); for ($i=2; $i<=4; $i++) { if ($cp[$i] === $myUnit) $cp[$i] = ''; } $rawCountries[$rawKey] = ebs_country_raw_string($cp); ebs_json_save('countrydata', $rawCountries); }
            ebs_players_save($players);
            $me = $players[$key] ?? $me;
            $myUnit='';
            $msg='부대 해산 완료: '.$count.'명 처리';
        }
    }
    $members=0;
    foreach ($players as $pl) if (is_array($pl) && (string)($pl['kuni'] ?? '')===$myCountry && (string)($pl['unit'] ?? ebs_player_raw_get($pl,28,''))===$myUnit && $myUnit!=='') $members++;
    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>ENDLESS BATTLE</title></head><body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="margin:0;font-size:13px;">';
    echo '<center><form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST" target="Sub"><input type="hidden" name="cmd" value="DEL_U"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'">';
    echo '<table border="1" cellspacing="0" cellpadding="6" bordercolor="'.ebs_h(ebs_v('TABLE_BORDER')).'" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" style="font-size:13px;min-width:460px;">';
    echo '<tr><td colspan="2" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'" align="center"><b>부대 해산</b></td></tr>';
    if ($msg !== '') echo '<tr><td colspan="2" align="center"><b>'.ebs_h($msg).'</b></td></tr>';
    echo '<tr><td>현재 부대</td><td>'.ebs_h($myUnit !== '' ? $myUnit : '없음').'</td></tr><tr><td>부대원 수</td><td>'.ebs_h((string)$members).'</td></tr><tr><td>권한</td><td>'.($isLeader ? '<font color="#00ff66">부대장</font>' : '<font color="red">부대장 아님</font>').'</td></tr>';
    echo '<tr><td colspan="2" align="center"><input type="submit" name="Cmode" value="해산" '.ebs_v('STYLE_B1').' onclick="return confirm(&quot;부대를 해산합니다. 모든 부대원이 무소속 처리됩니다. 괜찮습니까?&quot;)"> ';
    echo '<input type="submit" value="부대 메뉴" '.ebs_v('STYLE_B1').' onclick="this.form.cmd.value=&quot;MAKE_T&quot;;"></td></tr>';
    echo '</table></form></center></body></html>';
}

function ebs_BOUGU2(): void {
    $GLOBALS['EBS_DISABLE_AUTO_POST_SAVE'] = true;
    ebs_header_html();
    [$key, $me, $players, $err] = ebs_require_player();
    if ($err !== '' || !is_array($me) || $key === null) { ebs_error_page('Error', $err ?: '자신의 등록 데이터를 찾을 수 없습니다.'); return; }
    $pname=(string)($me['name'] ?? $key); $pass=ebs_param('pass', ebs_cookie_value('pass','')); $table=ebs_bougu_table(); $cmode=ebs_param('Cmode',''); $msg='';
    $money=max(0,(int)($me['money'] ?? 0));
    $changed=false;
    if ($cmode === '보강구입') {
        $buy=ebs_param('buyb','');
        if ($buy==='' || !isset($table[$buy])) $msg='구입할 보강장비를 선택하세요.';
        else { $row=$table[$buy]; $price=(int)($row[5] ?? 0); $dur=(string)($row[10] ?? ($row[6] ?? '100'));
            if ((string)($me['armor'] ?? '') !== '') $msg='이미 보강장비를 장비중입니다. 먼저 매각하세요.';
            elseif ($price <= 0) $msg='판매 대상 보강장비가 아닙니다.';
            elseif ($money < $price) $msg='소지금이 부족합니다.';
            else { $money-=$price; $me['money']=$money; $me['armor']=$buy.'!'.$dur; $msg='보강장비 구입 완료'; ebs_player_sync_common($me); $players[$key]=$me; ebs_players_save($players); $changed=true; }
        }
    }
    if ($cmode === '보강매각') {
        $armor=(string)($me['armor'] ?? ''); [$aid] = array_pad(explode('!', $armor, 2),2,'');
        if ($aid!=='' && isset($table[$aid])) { $price=(int)floor(max(0,(int)($table[$aid][5] ?? 0))/2); $money+=$price; $me['money']=$money; $me['armor']=''; $msg='보강장비 매각 완료: $'.number_format($price); ebs_player_sync_common($me); $players[$key]=$me; ebs_players_save($players); $changed=true; }
        else $msg='매각할 보강장비가 없습니다.';
    }
    $armor=(string)($me['armor'] ?? ''); [$aid,$dur]=array_pad(explode('!', $armor,2),2,'');
    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>ENDLESS BATTLE</title></head><body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="margin:0;font-size:13px;">';
    echo '<script>function checkMoney(){return confirm("보강장비를 매각합니다. 괜찮습니까?");}function checkBuy(){return confirm("보강장비를 구입합니다. 괜찮습니까?");}</script>';
    if ($changed) echo '<script>try{if(parent && parent.Main){parent.Main.location.reload();}}catch(e){}</script>';
    echo '<form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST" name="Ms" target="Sub"><input type="hidden" name="cmd" value="BOUGU"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'">';
    echo '<center><table border="1" cellspacing="0" cellpadding="5" bordercolor="'.ebs_h(ebs_v('TABLE_BORDER')).'" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" style="font-size:13px;min-width:520px;">';
    echo '<tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'" colspan="2"><b>보강장비</b><span style="float:right">소지금 $'.ebs_h(number_format($money)).'</span></td></tr>';
    if ($msg !== '') echo '<tr><td colspan="2" align="center"><b>'.ebs_h($msg).'</b></td></tr>';
    if ($aid!=='' && isset($table[$aid])) { $name=(string)($table[$aid][0] ?? $aid); $spec=(string)($table[$aid][9] ?? ''); echo '<tr><td width="120">장비중</td><td>'.ebs_h($name).' / 내구 '.ebs_h($dur).' / '.ebs_h($spec).' <input type="submit" name="Cmode" value="보강매각" '.ebs_v('STYLE_B1').' onClick="return checkMoney()"></td></tr>'; }
    else echo '<tr><td width="120">장비중</td><td>없음</td></tr>';
    echo '<tr><td valign="top">보강구입</td><td><select name="buyb" '.ebs_v('STYLE_L').' style="width:300px;">';
    $has=false; foreach ($table as $id=>$row) { if (!is_array($row)) continue; $price=(int)($row[5] ?? 0); if ($price <= 0) continue; $has=true; echo '<option value="'.ebs_h((string)$id).'">'.ebs_h((string)($row[0] ?? $id)).' $'.ebs_h(number_format($price)).' / '.ebs_h((string)($row[9] ?? '')); }
    if (!$has) echo '<option value="">보강장비 데이터 없음';
    echo '</select> <input type="submit" name="Cmode" value="보강구입" '.ebs_v('STYLE_B1').' onClick="return checkBuy()"></td></tr>';
    echo '</table></center></form></body></html>';
}

function ebs_BOSS_LOOK2(): void {
    ebs_header_html();
    ebs_record_post('ebs_sub5.php::BOSS_LOOK2');
    [$key, $me, $players, $err] = ebs_require_player();
    $pname = is_array($me) ? (string)($me['name'] ?? $key) : ebs_param('pname', ebs_cookie_value('pname',''));
    $pass = ebs_param('pass', ebs_cookie_value('pass',''));
    $countryName = ebs_param('CNTRY', ebs_param('country', is_array($me) ? (string)($me['kuni'] ?? '') : ''));
    $countries = ebs_country_records();
    if ($countryName === '' || !isset($countries[$countryName])) {
        $countryName = is_array($me) ? (string)($me['kuni'] ?? '') : '';
    }
    $c = ($countryName !== '' && isset($countries[$countryName])) ? $countries[$countryName] : null;
    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>ENDLESS BATTLE</title></head><body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="margin:0;font-size:13px;" oncontextmenu="return false;">';
    echo '<center><table border="1" cellspacing="0" cellpadding="5" bordercolor="'.ebs_h(ebs_v('TABLE_BORDER')).'" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" style="font-size:13px;min-width:650px;">';
    echo '<tr><td colspan="4" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'" align="center"><b>국가 요새 정보</b></td></tr>';
    if ($err !== '') echo '<tr><td colspan="4" align="center"><font color="red">'.ebs_h($err).'</font></td></tr>';
    if ($c === null) {
        echo '<tr><td colspan="4" align="center">표시할 국가를 선택하세요.</td></tr>';
        echo '<tr><td colspan="4" align="center">';
        ebs_render_country_buttons('Sub');
        echo '</td></tr>';
    } else {
        $fort = array_pad(explode('!', (string)($c['fortress'] ?? '0!0!0')), 3, '0');
        $cur = max(0, (int)$fort[0]);
        $max = max(1, (int)$fort[1]);
        $ftime = (string)$fort[2];
        $pct = max(0, min(100, (int)floor($cur / $max * 100)));
        $stats = array_pad(explode('!', (string)($c['stats'] ?? '0!0!0!')), 4, '');
        $members = [];
        foreach ($players as $nm=>$pl) if (is_array($pl) && (string)($pl['kuni'] ?? '') === (string)$c['name']) $members[] = $pl;
        echo '<tr><td width="120" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'">국가명</td><td colspan="3"><span style="display:inline-block;width:18px;height:12px;background:'.ebs_h((string)$c['color']).';border:1px solid #777;"></span> '.ebs_h((string)$c['name']).'</td></tr>';
        echo '<tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'">국비</td><td>$'.ebs_h(number_format((int)($c['money'] ?? 0))).'</td><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'">국민수</td><td>'.count($members).' / '.ebs_h((string)($c['max_member'] ?? ebs_v('C_MAX_MEMBER','40'))).'</td></tr>';
        echo '<tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'">요새 HP</td><td colspan="3"><div style="display:inline-block;width:260px;background:#303030;vertical-align:middle;"><div style="width:'.$pct.'%;height:9px;background:#00a0ff;"></div></div> '.ebs_h(number_format($cur)).' / '.ebs_h(number_format($max)).'</td></tr>';
        echo '<tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'">요새 능력</td><td colspan="3">공격 '.ebs_h((string)$stats[0]).' / 방어 '.ebs_h((string)$stats[1]).' / 명중 '.ebs_h((string)$stats[2]).' / 담당 '.ebs_h((string)$stats[3]).'</td></tr>';
        echo '<tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'">최근 갱신</td><td colspan="3">'.ebs_h($ftime).'</td></tr>';
        echo '<tr><td colspan="4" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'" align="center">국민 목록</td></tr>';
        echo '<tr bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'"><td>파일럿</td><td>기체</td><td>Lv</td><td>전적</td></tr>';
        $printed = 0;
        foreach ($members as $pl) {
            $printed++;
            echo '<tr><td>'.ebs_h((string)($pl['name'] ?? '')).'</td><td>'.ebs_h((string)($pl['msname'] ?? '')).'</td><td align="right">'.ebs_h((string)($pl['level'] ?? '1')).'</td><td>'.ebs_h((string)($pl['win'] ?? ebs_player_raw_get($pl,41,'0'))).'승 '.ebs_h((string)($pl['lose'] ?? ebs_player_raw_get($pl,42,'0'))).'패</td></tr>';
            if ($printed >= 80) break;
        }
        if ($printed === 0) echo '<tr><td colspan="4" align="center">소속 국민이 없습니다.</td></tr>';
    }
    echo '<tr><td colspan="4" align="center" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'">';
    echo '<form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST" target="Sub" style="display:inline"><input type="hidden" name="cmd" value="BOSS"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'"><input type="submit" value="국가 메뉴" '.ebs_v('STYLE_B1').'></form> ';
    echo '<form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST" target="Sub" style="display:inline"><input type="hidden" name="cmd" value="SPC"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'"><input type="submit" value="특수 메뉴" '.ebs_v('STYLE_B1').'></form>';
    echo '</td></tr></table></center></body></html>';
}

function ebs_SUBBS_LOOK2(): void {
    ebs_header_html();
    ebs_record_post('ebs_sub5.php::SUBBS_LOOK2');
    [$key, $me, $players, $err] = ebs_require_player();
    $pname = is_array($me) ? (string)($me['name'] ?? $key) : ebs_param('pname', ebs_cookie_value('pname',''));
    $pass = ebs_param('pass', ebs_cookie_value('pass',''));
    $myCountry = is_array($me) ? (string)($me['kuni'] ?? '') : '';
    $myUnit = is_array($me) ? (string)($me['unit'] ?? '') : '';
    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>ENDLESS BATTLE</title></head><body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="margin:0;font-size:13px;" oncontextmenu="return false;">';
    echo '<center><table border="1" cellspacing="0" cellpadding="5" bordercolor="'.ebs_h(ebs_v('TABLE_BORDER')).'" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" style="font-size:13px;min-width:620px;">';
    echo '<tr><td colspan="5" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'" align="center"><b>부대 관할 정보</b></td></tr>';
    if ($err !== '') echo '<tr><td colspan="5" align="center"><font color="red">'.ebs_h($err).'</font></td></tr>';
    echo '<tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'">자국</td><td colspan="4">'.ebs_h($myCountry !== '' ? $myCountry : ebs_v('NONE_NATIONALITY')).'</td></tr>';
    echo '<tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'">소속 부대</td><td colspan="4">'.ebs_h($myUnit !== '' ? $myUnit : '무소속').'</td></tr>';
    echo '<tr bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'"><td>부대</td><td>파일럿</td><td>기체</td><td>Lv</td><td>공헌</td></tr>';
    $printed = 0;
    foreach ($players as $nm=>$pl) {
        if (!is_array($pl)) continue;
        if ($myCountry !== '' && (string)($pl['kuni'] ?? '') !== $myCountry) continue;
        $unit = (string)($pl['unit'] ?? '');
        if ($unit === '') $unit = '무소속';
        echo '<tr><td>'.ebs_h($unit).'</td><td>'.ebs_h((string)($pl['name'] ?? $nm)).'</td><td>'.ebs_h((string)($pl['msname'] ?? '')).'</td><td align="right">'.ebs_h((string)($pl['level'] ?? '1')).'</td><td align="right">'.ebs_h((string)($pl['contrib'] ?? ebs_player_raw_get($pl,48,'0'))).'</td></tr>';
        $printed++;
        if ($printed >= 120) break;
    }
    if ($printed === 0) echo '<tr><td colspan="5" align="center">표시할 부대원이 없습니다.</td></tr>';
    echo '<tr><td colspan="5" align="center" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'">';
    echo '<form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST" target="Sub" style="display:inline"><input type="hidden" name="cmd" value="MAKE_T"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'"><input type="submit" value="부대 메뉴" '.ebs_v('STYLE_B1').'></form> ';
    echo '<form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST" target="Sub" style="display:inline"><input type="hidden" name="cmd" value="SPC"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'"><input type="submit" value="특수 메뉴" '.ebs_v('STYLE_B1').'></form>';
    echo '</td></tr></table></center></body></html>';
}


function ebs_KENKIN(): void {
    // 도시 > 송금. MONEY 라우트가 KENKIN으로 들어오므로 실제 송금 화면/처리를 제공한다.
    // 자동 POST 저장이 money류 필드를 임의 반영하지 못하도록 이 화면에서는 개별 검증 후 직접 저장한다.
    $GLOBALS['EBS_DISABLE_AUTO_POST_SAVE'] = true;
    ebs_header_html();
    ebs_record_post('ebs_sub5.php::KENKIN');
    [$key, $me, $players, $err] = ebs_require_player();
    if ($err !== '' || !is_array($me) || $key === null) { ebs_error_page('Error', $err ?: '등록 데이터를 찾을 수 없습니다.'); return; }

    $pname = (string)($me['name'] ?? $key);
    $pass = ebs_param('pass', ebs_cookie_value('pass',''));
    $money = max(0, (int)($me['money'] ?? ebs_player_raw_get($me, 8, '0')));
    $msg = '';

    if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && ebs_param('Cmode','') === '송금') {
        $to = ebs_clean_login_value(ebs_param('to_pname', ebs_param('target', ebs_param('plname', ebs_param('pname2', '')))));
        $amountRaw = ebs_param('send_money', ebs_param('money1', ebs_param('amount', ebs_param('kin', ebs_param('money', '0')))));
        $amount = (int)preg_replace('/[^0-9]/', '', (string)$amountRaw);

        if ($to === '') {
            $msg = '송금 상대를 입력하세요.';
        } elseif ($amount <= 0) {
            $msg = '송금 금액을 입력하세요.';
        } else {
            $result = ebs_with_file_lock(ebs_file('user/.players_state'), LOCK_EX, static function () use ($pname, $pass, $to, $amount): array {
                ebs_players_cache_clear();
                [$curKey, $curMe, $curPlayers, $curErr] = ebs_require_player($pname, $pass);
                if ($curErr !== '' || !is_array($curMe) || $curKey === null) return ['ok'=>false, 'msg'=>$curErr ?: '로그인 정보가 올바르지 않습니다.', 'money'=>0];

                $toKey = ebs_find_player_key($to, $curPlayers);
                if ($toKey === null || !isset($curPlayers[$toKey]) || !is_array($curPlayers[$toKey])) return ['ok'=>false, 'msg'=>'송금 상대를 찾을 수 없습니다.', 'money'=>max(0, (int)($curMe['money'] ?? ebs_player_raw_get($curMe, 8, '0')))];
                if ((string)$toKey === (string)$curKey) return ['ok'=>false, 'msg'=>'자기 자신에게 송금할 수 없습니다.', 'money'=>max(0, (int)($curMe['money'] ?? ebs_player_raw_get($curMe, 8, '0')))];

                $fromMoney = max(0, (int)($curMe['money'] ?? ebs_player_raw_get($curMe, 8, '0')));
                if ($amount > $fromMoney) return ['ok'=>false, 'msg'=>'소지금이 부족합니다.', 'money'=>$fromMoney];

                $toMe = $curPlayers[$toKey];
                $toMoney = max(0, (int)($toMe['money'] ?? ebs_player_raw_get($toMe, 8, '0')));
                $curMe['money'] = $fromMoney - $amount;
                $toMe['money'] = $toMoney + $amount;

                if (!isset($curMe['event_log']) || !is_array($curMe['event_log'])) $curMe['event_log'] = [];
                if (!isset($toMe['event_log']) || !is_array($toMe['event_log'])) $toMe['event_log'] = [];
                $now = date('YmdHis');
                $fromName = (string)($curMe['name'] ?? $curKey);
                $toName = (string)($toMe['name'] ?? $toKey);
                $curMe['event_log'][] = ['type'=>'money_transfer','direction'=>'send','to'=>$toName,'amount'=>$amount,'time'=>$now];
                $toMe['event_log'][] = ['type'=>'money_transfer','direction'=>'receive','from'=>$fromName,'amount'=>$amount,'time'=>$now];
                if (count($curMe['event_log']) > 100) $curMe['event_log'] = array_slice($curMe['event_log'], -100);
                if (count($toMe['event_log']) > 100) $toMe['event_log'] = array_slice($toMe['event_log'], -100);

                ebs_player_sync_common($curMe);
                ebs_player_sync_common($toMe);
                $ok1 = ebs_player_save_one($fromName, $curMe);
                $ok2 = ebs_player_save_one($toName, $toMe);
                $curPlayers[$curKey] = $curMe;
                $curPlayers[$toKey] = $toMe;
                ksort($curPlayers, SORT_NATURAL);
                ebs_players_cache_set($curPlayers);

                if (!$ok1 || !$ok2) return ['ok'=>false, 'msg'=>'송금 저장에 실패했습니다.', 'money'=>max(0, (int)$curMe['money'])];
                return ['ok'=>true, 'msg'=>$toName.' 님에게 $'.number_format($amount).' 송금 완료', 'money'=>max(0, (int)$curMe['money'])];
            });
            if (is_array($result)) {
                $msg = (string)($result['msg'] ?? '송금 처리 결과를 확인할 수 없습니다.');
                $money = max(0, (int)($result['money'] ?? $money));
            } else {
                $msg = '송금 처리 잠금을 얻지 못했습니다. 다시 시도하세요.';
            }
        }
    }

    $players = ebs_players_load();
    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>ENDLESS BATTLE</title></head><body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="margin:0;font-size:13px;" oncontextmenu="return false;">';
    echo '<script>function checkKenkin(f){var v=f.send_money.value.replace(/[^0-9]/g,"");if(f.to_pname.value===""){alert("송금 상대를 입력하세요.");return false;}if(v===""||parseInt(v,10)<=0){alert("송금 금액을 입력하세요.");return false;}return confirm("송금합니다. 괜찮습니까?");}</script>';
    echo '<center><form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST" name="Ms" target="Sub"><input type="hidden" name="cmd" value="MONEY"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'">';
    echo '<table border="1" cellspacing="0" cellpadding="6" bordercolor="'.ebs_h(ebs_v('TABLE_BORDER')).'" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" style="font-size:13px;min-width:430px;">';
    echo '<tr><td colspan="2" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'" align="center"><b>송금</b></td></tr>';
    if ($msg !== '') echo '<tr><td colspan="2" align="center"><b>'.ebs_h($msg).'</b></td></tr>';
    echo '<tr><td>소지금</td><td align="right">$'.ebs_h(number_format($money)).'</td></tr>';
    echo '<tr><td>송금 상대</td><td><input type="text" name="to_pname" size="24" list="kenkin_players" '.ebs_v('STYLE_L').'></td></tr>';
    echo '<tr><td>송금 금액</td><td><input type="text" name="send_money" size="12" maxlength="12" '.ebs_v('STYLE_L').'></td></tr>';
    echo '<tr><td colspan="2" align="center"><input name="Cmode" type="submit" value="송금" '.ebs_v('STYLE_B1').' onClick="return checkKenkin(this.form)"> ';
    echo '<input type="submit" value="도시 메뉴" '.ebs_v('STYLE_B1').' onClick="this.form.cmd.value=&quot;CITY&quot;;this.form.Cmode.value=&quot;&quot;;return true;"></td></tr>';
    echo '</table><datalist id="kenkin_players">';
    foreach ($players as $nm=>$pl) {
        if (!is_array($pl)) continue;
        $name = (string)($pl['name'] ?? $nm);
        if ($name === '' || $name === $pname) continue;
        echo '<option value="'.ebs_h($name).'">';
    }
    echo '</datalist></form></center></body></html>';
}

function ebs_JOUTO(): void {
    ebs_header_html();
    ebs_record_post('ebs_sub5.php::JOUTO');
    [$key, $me, $players, $err] = ebs_require_player();
    if ($err !== '' || !is_array($me) || $key === null) { ebs_error_page('Error', $err ?: '등록 데이터를 찾을 수 없습니다.'); return; }
    $pname=(string)($me['name'] ?? $key); $pass=ebs_param('pass', ebs_cookie_value('pass',''));
    $msg='';
    if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && ebs_param('Cmode','') === '양도') {
        $to=ebs_clean_login_value(ebs_param('to_pname', ebs_param('target','')));
        $slot=ebs_param('weapon_slot','weapon2');
        if (!in_array($slot, ['weapon','weapon2','weapon3'], true)) $slot='weapon2';
        $toKey=ebs_find_player_key($to, $players);
        $weapon=(string)($me[$slot] ?? '');
        if ($to === '' || $toKey === null || !isset($players[$toKey]) || !is_array($players[$toKey])) $msg='양도 상대를 찾을 수 없습니다.';
        elseif ($toKey === $key) $msg='자기 자신에게 양도할 수 없습니다.';
        elseif ($weapon === '') $msg='양도할 무기가 없습니다.';
        elseif ((string)($players[$toKey]['weapon2'] ?? '') !== '' && (string)($players[$toKey]['weapon3'] ?? '') !== '') $msg='상대의 예비 무기 칸이 비어 있지 않습니다.';
        else {
            if ((string)($players[$toKey]['weapon2'] ?? '') === '') $players[$toKey]['weapon2']=$weapon; else $players[$toKey]['weapon3']=$weapon;
            if ($slot === 'weapon') $me['weapon'] = (string)($me['weapon2'] ?? '') !== '' ? (string)$me['weapon2'] : ((string)($me['weapon3'] ?? '') !== '' ? (string)$me['weapon3'] : ebs_default_weapon_id().'!0');
            if ($slot === 'weapon' && (string)($me['weapon2'] ?? '') !== '') $me['weapon2']=''; elseif ($slot === 'weapon' && (string)($me['weapon3'] ?? '') !== '') $me['weapon3']=''; else $me[$slot]='';
            ebs_player_sync_common($me); ebs_player_sync_common($players[$toKey]);
            $players[$key]=$me; ebs_players_save($players);
            $msg='무기 양도 완료';
        }
    }
    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>ENDLESS BATTLE</title></head><body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="margin:0;font-size:13px;">';
    echo '<center><form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST" name="Ms" target="Sub"><input type="hidden" name="cmd" value="PRE"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'">';
    echo '<table border="1" cellspacing="0" cellpadding="6" bordercolor="'.ebs_h(ebs_v('TABLE_BORDER')).'" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" style="font-size:13px;min-width:430px;">';
    echo '<tr><td colspan="2" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'"><b>무기 양도</b></td></tr>';
    if ($msg !== '') echo '<tr><td colspan="2" align="center"><b>'.ebs_h($msg).'</b></td></tr>';
    echo '<tr><td>상대 캐릭터명</td><td><input type="text" name="to_pname" size="24" '.ebs_v('STYLE_L').'></td></tr><tr><td>양도 무기</td><td><select name="weapon_slot" '.ebs_v('STYLE_L').'>';
    foreach (['weapon'=>'장비중','weapon2'=>'예비1','weapon3'=>'예비2'] as $slot=>$label) { $raw=(string)($me[$slot] ?? ''); if ($raw==='') continue; [, $name] = ebs_calc_weapon_label($raw); echo '<option value="'.ebs_h($slot).'">'.ebs_h($label.' : '.$name); }
    echo '</select></td></tr><tr><td colspan="2" align="center"><input name="Cmode" type="submit" value="양도" '.ebs_v('STYLE_B1').' onClick="return confirm(&quot;무기를 양도합니다. 괜찮습니까?&quot;)"></td></tr>';
    echo '</table></form></center></body></html>';
}

function ebs_KAMO2(): void {
    ebs_header_html();
    ebs_record_post('ebs_sub5.php::KAMO2');
    [$key, $me, $players, $err] = ebs_require_player();
    $pname = is_array($me) ? (string)($me['name'] ?? $key) : ebs_param('pname', ebs_cookie_value('pname',''));
    $pass = ebs_param('pass', ebs_cookie_value('pass',''));
    $myLevel = is_array($me) ? (int)($me['level'] ?? 1) : 1;
    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>ENDLESS BATTLE</title></head><body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="margin:0;font-size:13px;">';
    echo '<center><table align="center" bordercolor="'.ebs_h(ebs_v('TABLE_BORDER')).'" border="1" cellspacing="0" cellpadding="4" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" style="font-size:12px;min-width:520px;">';
    echo '<tr><td colspan="5" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'" align="center"><b>샌드백리스트</b></td></tr>';
    echo '<tr><td colspan="5" style="color:#00ff33">샌드백리스트에 표시되고있는 캐릭터 이름을 누르면 전투할 수 있습니다.<br><font color="yellow">지원자격은 100렙 이상 기준으로 표시합니다.</font></td></tr>';
    echo '<tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'" align="center">캐릭터명</td><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'">소속국</td><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'">계급</td><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'">레벨</td><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'">장비무기</td></tr>';
    $printed=0;
    foreach ($players as $name=>$p) {
        if (!is_array($p)) continue;
        if ((string)($p['name'] ?? $name) === $pname) continue;
        $lv=(int)($p['level'] ?? ebs_player_raw_get($p,0,'1'));
        if ($lv < 100) continue;
        if ((int)($p['hp'] ?? 0) <= 0) continue;
        [$wid,$wname,$wlv] = ebs_calc_weapon_label((string)($p['weapon'] ?? ''));
        echo '<form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST" target="Sub">';
        echo '<input type="hidden" name="cmd" value="BATTLE_2"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'"><input type="hidden" name="vsname" value="'.ebs_h((string)($p['name'] ?? $name)).'">';
        echo '<tr><td><input type="submit" value="'.ebs_h((string)($p['name'] ?? $name)).'" '.ebs_v('STYLE_B1').'></td><td>'.ebs_h((string)($p['kuni'] ?? ebs_v('NONE_NATIONALITY'))).'</td><td>'.ebs_h((string)($p['job'] ?? '0')).'</td><td align="right">'.ebs_h((string)$lv).'</td><td>'.ebs_h($wname.' Lv'.$wlv).'</td></tr></form>';
        $printed++;
        if ($printed >= 100) break;
    }
    if ($printed === 0) echo '<tr><td colspan="5" align="center"><b>레벨 100 이상이거나 전투 가능한 샌드백 지원자가 없습니다.</b></td></tr>';
    if ($err !== '' || !is_array($me)) echo '<tr><td colspan="5" align="center"><font color="red">로그인 정보가 없으면 전투 버튼은 정상 처리되지 않습니다.</font></td></tr>';
    elseif ($myLevel >= 100) echo '<tr><td colspan="5" align="center">레벨 100 이상 캐릭터는 샌드백 이용 대상이 아닙니다.</td></tr>';
    echo '</table></center></body></html>';
}

function ebs_top_level_output(): void {
    // 단독 직접 접근 시에도 변환 잔재를 출력하지 않고 커스텀 메뉴로 진입한다.
    ebs_CUSTOM_HEADER();
}

function ebs_simple_action_screen(string $title, string $message, string $backCmd='CITY'): void {
    ebs_header_html();
    [$key, $me, $players, $err] = ebs_require_player();
    $pname = is_array($me) ? (string)($me['name'] ?? $key) : ebs_param('pname', ebs_cookie_value('pname',''));
    $pass = ebs_param('pass', ebs_cookie_value('pass',''));
    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>ENDLESS BATTLE</title></head><body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="margin:0;font-size:13px;" oncontextmenu="return false;">';
    echo '<center><table border="1" cellspacing="0" cellpadding="6" bordercolor="'.ebs_h(ebs_v('TABLE_BORDER')).'" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" style="font-size:13px;min-width:460px;">';
    echo '<tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'" align="center"><b>'.ebs_h($title).'</b></td></tr>';
    if ($err !== '') echo '<tr><td align="center"><font color="red">'.ebs_h($err).'</font></td></tr>';
    echo '<tr><td align="center" style="line-height:1.7;">'.ebs_h($message).'</td></tr>';
    echo '<tr><td align="center" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'"><form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST" target="Sub" style="display:inline"><input type="hidden" name="cmd" value="'.ebs_h($backCmd).'"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'"><input type="submit" value="돌아가기" '.ebs_v('STYLE_B1').'></form></td></tr>';
    echo '</table></center></body></html>';
}

function ebs_PEREE2(): void {
    // 원본 PEREE 계열 보조 처리. 자동 범용 POST 저장으로 돈/장비가 임의 변경되지 않도록 화면 처리만 수행한다.
    ebs_record_post('ebs_sub5.php::PEREE2');
    ebs_simple_action_screen('개인 보상', '개인 보상 처리는 현재 PHP 파일 저장 방식에서 별도 보상 로그만 사용합니다. 수치 변경은 전투/상점/국비 등 실제 처리 화면에서만 반영됩니다.', 'SPS');
}

function ebs_POWER2(): void {
    // 원본 POWER 계열 보조 처리. 임의 POST 수치 저장 금지.
    ebs_record_post('ebs_sub5.php::POWER2');
    ebs_simple_action_screen('출력 강화', '출력 강화 보조 화면입니다. 실제 HP/EN/자금 변경은 개조 화면의 비용 검증을 통과한 경우에만 저장됩니다.', 'SPS');
}

function ebs_PR2(): void {
    // 개인 광고는 ad_person.php의 파일 기반 광고 시스템으로 연결한다.
    ebs_header_html();
    [$key, $me, $players, $err] = ebs_require_player();
    $pname = is_array($me) ? (string)($me['name'] ?? $key) : ebs_param('pname', ebs_cookie_value('pname',''));
    $pass = ebs_param('pass', ebs_cookie_value('pass',''));
    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>ENDLESS BATTLE</title></head><body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="margin:0;font-size:13px;" oncontextmenu="return false;">';
    echo '<center><table border="1" cellspacing="0" cellpadding="6" bordercolor="'.ebs_h(ebs_v('TABLE_BORDER')).'" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" style="font-size:13px;min-width:460px;">';
    echo '<tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'" align="center"><b>개인 광고</b></td></tr>';
    if ($err !== '') echo '<tr><td align="center"><font color="red">'.ebs_h($err).'</font></td></tr>';
    echo '<tr><td align="center">개인 광고는 로컬 파일 기반 게시판으로 처리합니다.</td></tr>';
    echo '<tr><td align="center" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'"><form action="ad_person.php" method="POST" target="Sub" style="display:inline"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'"><input type="submit" value="광고 화면" '.ebs_v('STYLE_B1').'></form> <form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST" target="Sub" style="display:inline"><input type="hidden" name="cmd" value="CITY"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'"><input type="submit" value="도시 메뉴" '.ebs_v('STYLE_B1').'></form></td></tr>';
    echo '</table></center></body></html>';
}

$map = [
    'CUSTOM_HEADER' => 'ebs_CUSTOM_HEADER',
    'ST_RESET2' => 'ebs_ST_RESET2',
    'STATUSUP2' => 'ebs_STATUSUP2',
    'EQUIP' => 'ebs_EQUIP',
    'CITY2' => 'ebs_CITY2',
    'TRADE2' => 'ebs_TRADE2',
    'SPS2' => 'ebs_SPS2',
    'LOTO2' => 'ebs_LOTO2',
    'PEREE2' => 'ebs_PEREE2',
    'POWER2' => 'ebs_POWER2',
    'PR2' => 'ebs_PR2',
    'AP2' => 'ebs_AP2',
    'EP2' => 'ebs_EP2',
    'HES2' => 'ebs_HES2',
    'HEA2' => 'ebs_HEA2',
    'RR2' => 'ebs_RR2',
    'CUSTOMING2' => 'ebs_CUSTOMING2',
    'HISALL2' => 'ebs_HISALL2',
    'UPDATA2' => 'ebs_UPDATA2',
    'HISTORY' => 'ebs_HISTORY',
    'COMMENT' => 'ebs_COMMENT',
    'SPECIAL' => 'ebs_SPECIAL',
    'MISSION2' => 'ebs_MISSION2',
    'BOSS2' => 'ebs_BOSS2',
    'MAKE_C2' => 'ebs_MAKE_C2',
    'MAKE_T2' => 'ebs_MAKE_T2',
    'UP_G2' => 'ebs_UP_G2',
    'DEL_UNIT' => 'ebs_DEL_UNIT',
    'DEL_U2' => 'ebs_DEL_U2',
    'BOUGU2' => 'ebs_BOUGU2',
    'KENKIN' => 'ebs_KENKIN',
    'BOSS_LOOK2' => 'ebs_BOSS_LOOK2',
    'SUBBS_LOOK2' => 'ebs_SUBBS_LOOK2',
    'JOUTO' => 'ebs_JOUTO',
    'KAMO2' => 'ebs_KAMO2',
    '__TOP__' => 'ebs_top_level_output',
];
ebs_dispatch($map, 'ebs_CUSTOM_HEADER');
?>
