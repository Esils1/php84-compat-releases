<?php
declare(strict_types=1);
require_once __DIR__ . '/lib_ebs.php';
/** 개인 광고: PHP 8.4 파일 저장 방식(data/ad_person.json)으로 실제 등록/삭제/출력한다. */
function ebs_ad_data(): array { $d = ebs_json_load('ad_person'); return is_array($d) ? $d : []; }
function ebs_ad_save(array $d): void { ebs_json_save('ad_person', array_values($d)); }
function ebs_ad_layout_start(string $title='개인광고'): void {
    ebs_header_html();
    echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>'.ebs_h($title).'</title></head><body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="margin:8px;font-size:13px;">';
    echo '<center><table border="1" cellspacing="0" cellpadding="5" bordercolor="'.ebs_h(ebs_v('TABLE_BORDER')).'" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" style="min-width:680px;font-size:13px;">';
    echo '<tr><td colspan="5" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'" align="center"><b>'.ebs_h($title).'</b></td></tr>';
}
function ebs_ad_layout_end(): void { echo '</table></center></body></html>'; }
function ebs_ADLOG_IN(): void { ebs_AD_MAIN(); }
function ebs_AD_MAIN(): void {
    $ads = ebs_ad_data();
    $now = time();
    $changed = false;
    foreach ($ads as $i=>$ad) {
        $expire = (int)($ad['expire'] ?? 0);
        if ($expire > 0 && $expire < $now) { unset($ads[$i]); $changed = true; }
    }
    if ($changed) ebs_ad_save($ads);
    ebs_ad_layout_start('개인광고');
    echo '<tr bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'"><td>등록자</td><td>광고문</td><td>URL</td><td>등록일</td><td>관리</td></tr>';
    if (!$ads) echo '<tr><td colspan="5" align="center">등록된 광고가 없습니다.</td></tr>';
    foreach ($ads as $ad) {
        $id = (string)($ad['id'] ?? '');
        $url = (string)($ad['url'] ?? '');
        if ($url !== '' && !preg_match('/^https?:\/\//i', $url)) $url = 'http://'.$url;
        echo '<tr><td>'.ebs_h((string)($ad['name'] ?? '')).'</td><td>'.nl2br(ebs_h((string)($ad['comment'] ?? ''))).'</td><td>';
        echo $url !== '' ? '<a href="'.ebs_h($url).'">이동</a>' : '-';
        echo '</td><td>'.ebs_h((string)($ad['created'] ?? '')).'</td><td>';
        echo '<form method="post" action="ad_person.php" style="margin:0" target="Sub"><input type="hidden" name="cmd" value="ADDEL"><input type="hidden" name="id" value="'.ebs_h($id).'">관리PASS <input type="password" name="pass" size="6"> <input type="submit" value="삭제" '.ebs_v('STYLE_B1').'></form>';
        echo '</td></tr>';
    }
    echo '<tr><td colspan="5" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'"><b>광고 등록</b></td></tr>';
    echo '<tr><td colspan="5"><form method="post" action="ad_person.php" target="Sub"><input type="hidden" name="cmd" value="ADPRO">';
    echo '이름 <input name="name" size="12" '.ebs_v('STYLE_L').'> URL <input name="url" size="36" '.ebs_v('STYLE_L').'><br>광고문 <input name="comment" size="70" '.ebs_v('STYLE_L').'> <input type="submit" value="등록" '.ebs_v('STYLE_B1').'></form></td></tr>';
    ebs_ad_layout_end();
}
function ebs_ADPRO(): void {
    $name = trim(ebs_param('name', ebs_param('pname', ebs_cookie_value('pname',''))));
    $url = trim(ebs_param('url',''));
    $comment = trim(ebs_param('comment', ebs_param('ad_comment','')));
    if ($name === '') $name = 'NoName';
    if ($comment === '') { ebs_error_page('광고 등록 오류','광고문을 입력해 주세요.'); return; }
    $ads = ebs_ad_data();
    $ads[] = ['id'=>date('YmdHis').'-'.substr(hash('sha256',$name.$comment.microtime(true)),0,8), 'name'=>$name, 'url'=>$url, 'comment'=>function_exists('mb_substr') ? mb_substr($comment,0,120,'UTF-8') : substr($comment,0,120), 'created'=>date('Y-m-d H:i:s'), 'expire'=>time()+86400*30];
    ebs_ad_save($ads);
    ebs_AD_MAIN();
}
function ebs_ADDEL(): void {
    if (!ebs_admin_ok()) { ebs_error_page('패스워드 에러','관리자 패스워드가 필요합니다.'); return; }
    $id = ebs_param('id','');
    $ads = array_values(array_filter(ebs_ad_data(), static fn($a): bool => (string)($a['id'] ?? '') !== $id));
    ebs_ad_save($ads);
    ebs_AD_MAIN();
}
function ebs_AD_END(): void { ebs_AD_MAIN(); }
$map = ['ADLOG_IN'=>'ebs_ADLOG_IN','AD_MAIN'=>'ebs_AD_MAIN','ADPRO'=>'ebs_ADPRO','ADDEL'=>'ebs_ADDEL','AD_END'=>'ebs_AD_END'];
ebs_dispatch($map, 'ebs_ADLOG_IN');
?>
