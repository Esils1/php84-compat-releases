<?php
declare(strict_types=1);
require_once __DIR__ . '/lib_ebs.php';
/**
 * 원본 legacy 파일: d_config.php
 * 지하감옥 설정 관리. 기본값은 기존 PHP 동작과 동일하게 유지한다.
 */
$cmd = ebs_cmd('TOP');
$public = ['TOP','LOGOUT'];
if (!in_array($cmd, $public, true) && !ebs_admin_ok()) { ebs_admin_login_form(basename(__FILE__), '던전 설정 관리'); return; }
if ($cmd === 'LOGOUT') { ebs_admin_logout(); return; }
if (!ebs_admin_ok()) { ebs_admin_login_form('d_config.php', '던전 설정 관리'); return; }
$script = 'd_config.php';
$pass = ebs_h(ebs_admin_pass_value());
$message = '';
if ($cmd === 'SAVE') {
    $cfg = ebs_dungeon_config_load();
    foreach (['dungeon','dungeonss'] as $key) {
        foreach (['move_rate','stay_rate','trap_rate'] as $name) {
            $field = $key . '_' . $name;
            if (isset($_POST[$field])) $cfg[$key][$name] = max(0, min(100, (int)$_POST[$field]));
        }
    }
    ebs_dungeon_config_save($cfg);
    ebs_admin_audit('DUNGEON_CONFIG_SAVE', '던전 설정 저장');
    $message = '던전 설정을 저장했습니다.';
}
$cfg = ebs_dungeon_config_load();
ebs_admin_header('던전 설정 관리');
if ($message !== '') echo '<p class="ok">'.ebs_h($message).'</p>';
echo '<form method="post" action="'.ebs_h($script).'"><input type="hidden" name="pass" value="'.$pass.'"><input type="hidden" name="cmd" value="SAVE">';
echo '<table class="tbl" style="max-width:760px;margin:40px auto 8px auto">';
echo '<tr><th colspan="5">던전 설정 관리</th></tr>';
echo '<tr><th>구분</th><th>이동 중 조우율</th><th>탐색 조우율</th><th>트랩칸 조우율</th><th>사용 데이터</th></tr>';
$labels = ['dungeon'=>'지하 감옥','dungeonss'=>'어둠의 미궁'];
$files = ['dungeon'=>'log/_dungeon.data','dungeonss'=>'log/_dungeonss.data'];
foreach ($labels as $key=>$label) {
    echo '<tr><td align="center" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'">'.ebs_h($label).'</td>';
    foreach (['move_rate','stay_rate','trap_rate'] as $name) {
        $v = isset($cfg[$key][$name]) ? (int)$cfg[$key][$name] : 0;
        echo '<td align="center"><input class="inp" name="'.ebs_h($key.'_'.$name).'" value="'.$v.'" size="4" maxlength="3"> %</td>';
    }
    echo '<td>'.ebs_h($files[$key]).'</td></tr>';
}
echo '<tr><td colspan="5" align="center"><button class="btn" type="submit">저장</button></td></tr>';
echo '</table></form>';
echo '<table class="tbl" style="max-width:760px;margin:0 auto"><tr><th>설명</th></tr><tr><td>';
echo '이동 중 조우율은 위/아래/왼쪽/오른쪽 이동 후 몬스터를 만날 확률입니다.<br>';
echo '탐색 조우율은 현재 칸에서 탐색 버튼을 눌렀을 때의 확률입니다.<br>';
echo '트랩칸 조우율은 맵 코드 a 칸에서 우선 적용됩니다.<br>';
echo '0~100 범위 밖의 값은 자동 보정됩니다.';
echo '</td></tr></table>';
echo '<p style="text-align:center">';
ebs_admin_nav_form('d_mainte.php', 'MAINTE', '지하감옥 관리창');
ebs_admin_nav_form('d_mainte.php', 'MONSTER_DATA', '몬스터 데이터 편집');
ebs_admin_nav_form('maintenance.php', 'MAINTE2', '관리창 돌아가기');
echo '</p><div style="text-align:center;font-size:12px">던전 설정 스크립트</div>';
ebs_admin_footer();
?>
