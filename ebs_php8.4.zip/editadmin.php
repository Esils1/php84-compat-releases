<?php
declare(strict_types=1);
require_once __DIR__ . '/lib_ebs.php';
/**
 * 원본 legacy 파일: editadmin.php
 * PHP 8.4 관리자 데이터 조정 페이지.
 *
 * 원본의 MAINTE/MASTER/SYUSEI/TYOUSEI/BACKUP/DATAUP/COUNTRY/HENSYU/KAIZAN/COOKIES/DEL
 */
$cmd = ebs_cmd('MAINTE');
$public = ['MAINTE','MAINTENANCE','TOP','LOGOUT'];
if (!in_array($cmd, $public, true) && !ebs_admin_ok()) {
    ebs_error_page('패스워드 에러', '관리자 패스워드가 필요합니다.');
    return;
}
switch ($cmd) {
    case 'ADMIN_ACTION':
        $action = ebs_param('admin_action', 'PLAYER_EDIT');
        if ($action === 'USER_REPAIR') { ebs_admin_user_repair_screen(basename(__FILE__)); break; }
        if ($action === 'DEL') { ebs_admin_delete_player(); break; }
        ebs_admin_player_edit_screen(basename(__FILE__)); break;
    case 'PLAYER_EDIT':
        ebs_admin_player_edit_screen(basename(__FILE__)); break;
    case 'LOGOUT': ebs_admin_logout(); break;
    case 'MAINTE':
    case 'MAINTENANCE':
    case 'TOP':
        if (ebs_admin_ok()) { ebs_admin_menu('editadmin.php'); } else { ebs_admin_login_form('editadmin.php', 'Maintenance Mode'); }
        break;
    case 'MAINTE2':
    case 'MAINTENANCE2':
        if (ebs_admin_ok()) { ebs_admin_menu('editadmin.php'); } else { ebs_admin_login_form('editadmin.php', 'Maintenance Mode'); }
        break;
    case 'MASTER':
    case 'MASTER2':
    case 'HUKUGEN':
    case 'SYUUHUKU':
        ebs_admin_players('editadmin.php'); break;
    case 'SYUSEI':
    case 'SYUSEI2':
    case 'SYUSEI4':
        ebs_admin_player_edit_screen('editadmin.php'); break;
    case 'TYOUSEI':
    case 'TYOUSEI2':
        ebs_admin_update_player(); break;
    case 'DEL':
    case 'DEL2':
        if (ebs_param('plname') !== '') ebs_admin_delete_player(); else ebs_admin_players('editadmin.php'); break;
    case 'COUNTRY':
    case 'COUNTRY2':
    case 'COUNTRY_EDIT':
    case 'HENSYU':
    case 'HENSYU2':
        ebs_admin_countries('editadmin.php'); break;
    case 'COUNTRY_CREATE':
        ebs_admin_create_country(); break;
    case 'COUNTRY_DELETE':
        ebs_admin_delete_country(); break;
    case 'KAIZAN':
    case 'KAIZAN2':
        ebs_admin_update_country(); break;
    case 'BACKUP':
    case 'BACKUP2':
    case 'DATAUP':
    case 'DATAUP2':
        ebs_admin_backup_screen('editadmin.php'); break;
    case 'BACKUP_RUN':
        ebs_admin_backup_run(); break;
    case 'DATAUP_RUN':
        ebs_admin_restore_run(); break;
    case 'COOKIES':
    case 'COOKIES2':
        ebs_admin_cookies_screen('editadmin.php'); break;
    case 'HISTORY_EDIT':
    case 'HISTORY_EDIT2':
    case 'HISMAKE':
    case 'HISMAKES': ebs_admin_history_public_screen('editadmin.php'); break;
    case 'HISTORY_EDIT_SAVE':
    case 'HISMAKES_SAVE': ebs_admin_history_public_save('editadmin.php'); break;
    case 'UPDATE_EDIT':
    case 'UPDATE_EDIT2':
    case 'UPDATA':
    case 'UPDMAKE':
    case 'UPDMAKES': ebs_admin_update_public_screen('editadmin.php'); break;
    case 'UPDATE_EDIT_SAVE':
    case 'UPDMAKES_SAVE': ebs_admin_update_public_save('editadmin.php'); break;
    case 'USER_REPAIR':
        ebs_admin_user_repair_screen('editadmin.php'); break;
    case 'USER_REPAIR_RUN':
        ebs_admin_user_repair_run(); break;
    case 'MAINTE_LOG':
        ebs_admin_log_screen('editadmin.php'); break;
    default:
        ebs_admin_menu('editadmin.php'); break;
}
?>
