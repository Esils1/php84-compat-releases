<?php
declare(strict_types=1);
require_once __DIR__ . '/lib_ebs.php';
/** 범용 창고: 장비중/예비1/예비2와 warehouse_weapons 사이 이동을 처리한다. */
function ebs_var_start(string $title='창고'): void { ebs_header_html(); echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>'.ebs_h($title).'</title></head><body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="margin:8px;font-size:13px;"><script>try{if(parent&&parent.Main&&parent.Main.location&&window.name=="Sub")parent.Main.location.reload();}catch(e){}</script><center><table border="1" cellspacing="0" cellpadding="5" bordercolor="'.ebs_h(ebs_v('TABLE_BORDER')).'" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" style="min-width:760px;font-size:13px;"><tr><td colspan="6" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'" align="center"><b>'.ebs_h($title).'</b></td></tr>'; }
function ebs_var_end(): void { echo '</table></center></body></html>'; }
function ebs_var_hidden(): string { return '<input type="hidden" name="pname" value="'.ebs_h(ebs_param('pname', ebs_cookie_value('pname',''))).'"><input type="hidden" name="pass" value="'.ebs_h(ebs_param('pass', ebs_cookie_value('pass',''))).'">'; }
function ebs_var_slot_label(string $slot): string { return ['weapon'=>'장비중','weapon2'=>'예비1','weapon3'=>'예비2'][$slot] ?? '장비중'; }
function ebs_TOP(): void {
    [$key,$p,$players,$err]=ebs_require_player(); if($err!==''||$key===null||!is_array($p)){ ebs_error_page('창고 오류',$err ?: '등록 데이터를 찾을 수 없습니다.'); return; }
    if(!isset($p['warehouse_weapons'])||!is_array($p['warehouse_weapons'])) $p['warehouse_weapons']=[];
    $wh=$p['warehouse_weapons']; ebs_var_start('범용 창고');
    echo '<tr><td colspan="6" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'"><b>장비/예비 무기 입고</b></td></tr>';
    foreach(['weapon'=>'장비중','weapon2'=>'예비1','weapon3'=>'예비2'] as $slot=>$label){ $raw=(string)($p[$slot]??''); [, $name, $lv] = ebs_calc_weapon_label($raw); echo '<tr><td>'.ebs_h($label).'</td><td colspan="4">'.($raw!==''?ebs_h($name.' Lv'.$lv):'&nbsp;').'</td><td align="center">'; if($raw!=='') echo '<form method="post" action="various.php" target="Sub" style="margin:0">'.ebs_var_hidden().'<input type="hidden" name="cmd" value="START"><input type="hidden" name="mode" value="deposit"><input type="hidden" name="slot" value="'.ebs_h($slot).'"><input type="submit" value="입고" '.ebs_v('STYLE_B1').'></form>'; echo '</td></tr>'; }
    echo '<tr bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'"><td>No</td><td>무기</td><td>Lv</td><td>출고위치</td><td>출고</td><td>삭제</td></tr>';
    foreach($wh as $i=>$w){ [, $name, $lv] = ebs_calc_weapon_label((string)$w); echo '<tr><td>'.($i+1).'</td><td>'.ebs_h($name).'</td><td align="right">'.ebs_h((string)$lv).'</td><form method="post" action="various.php" target="Sub" style="margin:0"><td><select name="target_slot" '.ebs_v('STYLE_L').'><option value="weapon">장비중<option value="weapon2">예비1<option value="weapon3">예비2</select></td><td>'.ebs_var_hidden().'<input type="hidden" name="cmd" value="START"><input type="hidden" name="mode" value="withdraw"><input type="hidden" name="idx" value="'.(int)$i.'"><input type="submit" value="출고" '.ebs_v('STYLE_B1').'></td></form><form method="post" action="various.php" target="Sub" style="margin:0"><td>'.ebs_var_hidden().'<input type="hidden" name="cmd" value="START"><input type="hidden" name="mode" value="delete"><input type="hidden" name="idx" value="'.(int)$i.'"><input type="submit" value="삭제" '.ebs_v('STYLE_B1').' onclick="return confirm(\'창고의 이 무기를 삭제합니다. 괜찮습니까?\')"></td></form></tr>'; }
    if(!$wh) echo '<tr><td colspan="6" align="center">보관중인 무기가 없습니다.</td></tr>'; ebs_var_end();
}
function ebs_START(): void {
    $GLOBALS['EBS_DISABLE_AUTO_POST_SAVE'] = true;
    if (empty($GLOBALS['EBS_WAREHOUSE_TX'])) {
        $GLOBALS['EBS_WAREHOUSE_TX'] = true;
        ebs_with_file_lock(ebs_file('data/warehouse_state'), LOCK_EX, static function (): void { ebs_START(); });
        $GLOBALS['EBS_WAREHOUSE_TX'] = false;
        return;
    }
    [$key,$me,$players,$err]=ebs_require_player(); if($err!==''||$key===null||!is_array($me)){ ebs_error_page('창고 오류',$err); return; }
    if(!isset($me['warehouse_weapons'])||!is_array($me['warehouse_weapons'])) $me['warehouse_weapons']=[];
    $mode=ebs_param('mode','');
    if($mode==='deposit'){
        $slot=ebs_param('slot','weapon'); if(!in_array($slot,['weapon','weapon2','weapon3'],true))$slot='weapon';
        $w=(string)($me[$slot]??''); if($w===''){ ebs_error_page('창고 오류','입고할 무기가 없습니다.'); return; }
        if(count($me['warehouse_weapons'])>=30){ ebs_error_page('창고 오류','창고가 가득 찼습니다.'); return; }
        $me['warehouse_weapons'][]=$w;
        if($slot==='weapon'){ if((string)($me['weapon2']??'')!==''){ $me['weapon']=$me['weapon2']; $me['weapon2']=''; } elseif((string)($me['weapon3']??'')!==''){ $me['weapon']=$me['weapon3']; $me['weapon3']=''; } else $me['weapon']=ebs_default_weapon_id().'!0'; }
        else $me[$slot]='';
    } elseif($mode==='withdraw'){
        $idx=(int)ebs_param('idx','-1'); $target=ebs_param('target_slot','weapon'); if(!in_array($target,['weapon','weapon2','weapon3'],true))$target='weapon';
        if(!isset($me['warehouse_weapons'][$idx])){ ebs_error_page('창고 오류','출고할 무기가 없습니다.'); return; }
        $current=(string)($me[$target]??''); if($current!=='' && count($me['warehouse_weapons'])>=30){ ebs_error_page('창고 오류','교체할 기존 무기를 보관할 공간이 없습니다.'); return; }
        $take=(string)$me['warehouse_weapons'][$idx]; unset($me['warehouse_weapons'][$idx]); $me['warehouse_weapons']=array_values($me['warehouse_weapons']); if($current!=='') $me['warehouse_weapons'][]=$current; $me[$target]=$take;
    } elseif($mode==='delete' || $mode==='삭제' || $mode==='DEL' || $mode==='DELETE'){
        $idx=(int)ebs_param('idx','-1');
        if(!isset($me['warehouse_weapons'][$idx])){ ebs_error_page('창고 오류','삭제할 무기가 없습니다.'); return; }
        unset($me['warehouse_weapons'][$idx]);
        $me['warehouse_weapons']=array_values($me['warehouse_weapons']);
    }
    ebs_player_sync_common($me); $players[$key]=$me; ebs_players_save($players); ebs_TOP();
}
function ebs_ENDSCRIPT(): void { ebs_TOP(); }
$map=['TOP'=>'ebs_TOP','START'=>'ebs_START','ENDSCRIPT'=>'ebs_ENDSCRIPT'];
ebs_dispatch($map,'ebs_TOP');
?>
