<?php
declare(strict_types=1);
require_once __DIR__ . '/lib_ebs.php';

/** 보조 유지보수: PHP 파일 저장 구조(user/*.json, data/*.json) 전용 점검/정리 화면. */
function ebs_remake_header(string $title='보조 유지보수'): void {
    ebs_header_html();
    echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>'.ebs_h($title).'</title></head>';
    echo '<body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="margin:8px;font-size:13px;">';
    echo '<center><table border="1" cellspacing="0" cellpadding="5" bordercolor="'.ebs_h(ebs_v('TABLE_BORDER')).'" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" style="min-width:820px;font-size:13px;">';
    echo '<tr><td colspan="8" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'" align="center"><b>'.ebs_h($title).'</b></td></tr>';
}
function ebs_remake_footer(): void {
    echo '<tr><td colspan="8" align="center"><a href="remake.php">메뉴</a> | <a href="maintenance.php">운영 관리</a> | <a href="ebs.php" target="_top">메인</a></td></tr>';
    echo '</table></center></body></html>';
}
function ebs_remake_pass(): string { return ebs_h(ebs_admin_pass_value()); }
function ebs_remake_admin_required(): bool {
    if (ebs_admin_ok()) return true;
    ebs_admin_login_form('remake.php', '보조 유지보수');
    return false;
}
function ebs_remake_menu_form(string $cmd, string $label): string {
    return '<form method="post" action="remake.php" style="display:inline;margin:2px;"><input type="hidden" name="pass" value="'.ebs_remake_pass().'"><button name="cmd" value="'.ebs_h($cmd).'" '.ebs_v('STYLE_B1').'>'.ebs_h($label).'</button></form>';
}
function ebs_remake_menu(): void {
    if (!ebs_remake_admin_required()) return;
    ebs_remake_header('보조 유지보수');
    echo '<tr><td colspan="8" style="line-height:2;">';
    $items = [
        'TUKAIKATA'=>'사용법', 'IPLOOK'=>'접속 정보', 'LOGINS'=>'접속/등록 목록', 'DELETELIST'=>'삭제 후보', 'SINKILIST'=>'신규 목록',
        'BUKISOUJI'=>'무기 정리', 'GOUSEISOUJI'=>'창고 정리', 'BUKIJOUHOU'=>'무기 정보', 'HITOALL'=>'전체 캐릭터', 'KUNIALL'=>'전체 국가',
        'HITO'=>'캐릭터 검색', 'KUNI'=>'국가 검색', 'PUSHHITO'=>'캐릭터 JSON', 'PUSHKUNI'=>'국가 JSON',
    ];
    foreach ($items as $cmd=>$label) echo ebs_remake_menu_form($cmd,$label).' ';
    echo '</td></tr>';
    ebs_remake_footer();
}
function ebs_MAIN(): void { ebs_remake_menu(); }
function ebs_TUKAIKATA(): void {
    if (!ebs_remake_admin_required()) return;
    ebs_remake_header('사용법');
    echo '<tr><td colspan="8" style="line-height:1.7;">이 화면은 이전 보조 유지보수 스크립트를 PHP 파일 저장 방식으로 변환한 것입니다. 캐릭터는 <b>user/*.json</b>, 국가와 부가 데이터는 <b>data/*.json</b>을 사용하며 외부 저장소 파일은 생성하지 않습니다. 정리 버튼은 현재 JSON 구조를 보정하고, 목록/조회 버튼은 저장 데이터를 그대로 표시합니다.</td></tr>';
    ebs_remake_footer();
}
function ebs_IPKAIZOU(): void { ebs_TUKAIKATA(); }
function ebs_SAKUJOKAIZOU(): void { ebs_DELETELIST(); }
function ebs_SINKIKAIZOU(): void { ebs_SINKILIST(); }
function ebs_IPLOOK(): void {
    if (!ebs_remake_admin_required()) return;
    $players = ebs_players_load();
    ebs_remake_header('접속 정보');
    echo '<tr bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'"><td>이름</td><td>기체명</td><td>국가</td><td colspan="2">접속 정보</td><td colspan="3">최근 시각</td></tr>';
    foreach ($players as $name=>$p) {
        if (!is_array($p)) continue;
        echo '<tr><td>'.ebs_h((string)$name).'</td><td>'.ebs_h((string)($p['msname'] ?? '')).'</td><td>'.ebs_h((string)($p['kuni'] ?? '')).'</td><td colspan="2">'.ebs_h((string)($p['remote'] ?? '')).'</td><td colspan="3">'.ebs_h((string)($p['last_access'] ?? ($p['date'] ?? ''))).'</td></tr>';
    }
    ebs_remake_footer();
}
function ebs_LOGINS(): void {
    if (!ebs_remake_admin_required()) return;
    $players = ebs_players_load();
    uasort($players, static function($a,$b){ return strcmp((string)($b['last_access'] ?? $b['date'] ?? ''), (string)($a['last_access'] ?? $a['date'] ?? '')); });
    ebs_remake_header('접속/등록 목록');
    echo '<tr bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'"><td>이름</td><td>Lv</td><td>소지금</td><td>승</td><td>패</td><td colspan="3">최근/등록</td></tr>';
    foreach ($players as $name=>$p) {
        if (!is_array($p)) continue;
        echo '<tr><td>'.ebs_h((string)$name).'</td><td align="right">'.ebs_h((string)($p['level'] ?? '1')).'</td><td align="right">'.ebs_h(number_format((int)($p['money'] ?? 0))).'</td><td align="right">'.ebs_h((string)($p['win'] ?? ebs_plv_int($p,41,0))).'</td><td align="right">'.ebs_h((string)($p['lose'] ?? ebs_plv_int($p,42,0))).'</td><td colspan="3">'.ebs_h((string)($p['last_access'] ?? ($p['date'] ?? ''))).'</td></tr>';
    }
    ebs_remake_footer();
}
function ebs_DELETELIST(): void {
    if (!ebs_remake_admin_required()) return;
    $players = ebs_players_load();
    $limit = time() - 60*60*24*90;
    ebs_remake_header('삭제 후보');
    echo '<tr><td colspan="8">최근 접속 또는 등록 시각이 90일보다 오래된 캐릭터 후보입니다. 자동 삭제하지 않습니다.</td></tr>';
    echo '<tr bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'"><td>이름</td><td>기체명</td><td>국가</td><td>Lv</td><td colspan="4">기준 시각</td></tr>';
    foreach ($players as $name=>$p) {
        if (!is_array($p)) continue;
        $stamp = (string)($p['last_access'] ?? ($p['date'] ?? ''));
        $ts = preg_match('/^\d{14}$/', $stamp) ? strtotime(substr($stamp,0,4).'-'.substr($stamp,4,2).'-'.substr($stamp,6,2).' '.substr($stamp,8,2).':'.substr($stamp,10,2).':'.substr($stamp,12,2)) : strtotime($stamp);
        if ($ts !== false && $ts > $limit) continue;
        echo '<tr><td>'.ebs_h((string)$name).'</td><td>'.ebs_h((string)($p['msname'] ?? '')).'</td><td>'.ebs_h((string)($p['kuni'] ?? '')).'</td><td align="right">'.ebs_h((string)($p['level'] ?? '1')).'</td><td colspan="4">'.ebs_h($stamp).'</td></tr>';
    }
    ebs_remake_footer();
}
function ebs_SINKILIST(): void {
    if (!ebs_remake_admin_required()) return;
    $players = ebs_players_load();
    uasort($players, static function($a,$b){ return strcmp((string)($b['date'] ?? ''), (string)($a['date'] ?? '')); });
    ebs_remake_header('신규 목록');
    echo '<tr bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'"><td>이름</td><td>기체명</td><td>국가</td><td>Lv</td><td colspan="4">등록 시각</td></tr>';
    foreach (array_slice($players,0,100,true) as $name=>$p) {
        if (!is_array($p)) continue;
        echo '<tr><td>'.ebs_h((string)$name).'</td><td>'.ebs_h((string)($p['msname'] ?? '')).'</td><td>'.ebs_h((string)($p['kuni'] ?? '')).'</td><td align="right">'.ebs_h((string)($p['level'] ?? '1')).'</td><td colspan="4">'.ebs_h((string)($p['date'] ?? '')).'</td></tr>';
    }
    ebs_remake_footer();
}
function ebs_BUKISOUJI(): void {
    if (!ebs_remake_admin_required()) return;
    $players = ebs_players_load(); $fixed=0; $default = ebs_default_weapon_id().'!0';
    foreach ($players as $name=>$p) {
        if (!is_array($p)) continue;
        $w = (string)($p['weapon'] ?? '');
        if ($w === '' || !ebs_weapon_exists($w)) { $players[$name]['weapon'] = $default; ebs_player_raw_set($players[$name],9,$default); $fixed++; }
    }
    if ($fixed > 0) ebs_players_save($players);
    ebs_remake_header('무기 정리');
    echo '<tr><td colspan="8" align="center">현재 장비 무기 보정 완료: '.ebs_h((string)$fixed).'건</td></tr>';
    ebs_remake_footer();
}
function ebs_GOUSEISOUJI(): void {
    if (!ebs_remake_admin_required()) return;
    $players = ebs_players_load(); $fixed=0;
    foreach ($players as $name=>$p) {
        if (!is_array($p)) continue;
        $old = $p['warehouse_weapons'] ?? [];
        $new = [];
        if (is_array($old)) foreach ($old as $w) if (is_string($w) && $w !== '' && ebs_weapon_exists($w)) $new[] = $w;
        if ($new !== $old) { $players[$name]['warehouse_weapons'] = array_values($new); $fixed++; }
    }
    if ($fixed > 0) ebs_players_save($players);
    ebs_remake_header('창고 정리');
    echo '<tr><td colspan="8" align="center">창고 무기 보정 완료: '.ebs_h((string)$fixed).'명</td></tr>';
    ebs_remake_footer();
}
function ebs_BUKIJOUHOU(): void {
    if (!ebs_remake_admin_required()) return;
    $weapons = ebs_weapon_table();
    ebs_remake_header('무기 정보');
    echo '<tr bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'"><td>ID</td><td>이름</td><td>공격</td><td>명중</td><td>회수</td><td>EN</td><td>가격</td><td>특수</td></tr>';
    foreach ($weapons as $id=>$row) {
        if (!is_array($row)) continue;
        echo '<tr><td>'.ebs_h((string)$id).'</td><td>'.ebs_h((string)($row[0] ?? '')).'</td><td align="right">'.ebs_h((string)($row[1] ?? '')).'</td><td align="right">'.ebs_h((string)($row[2] ?? '')).'</td><td align="right">'.ebs_h((string)($row[3] ?? '')).'</td><td align="right">'.ebs_h((string)($row[4] ?? '')).'</td><td align="right">'.ebs_h((string)($row[6] ?? '')).'</td><td>'.ebs_weapon_effects((string)($row[7] ?? ''),(string)($row[8] ?? '')).'</td></tr>';
    }
    ebs_remake_footer();
}
function ebs_HITOALL(): void { ebs_LOGINS(); }
function ebs_KUNIALL(): void {
    if (!ebs_remake_admin_required()) return;
    $countries = ebs_country_records();
    ebs_remake_header('전체 국가');
    echo '<tr bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'"><td>국가</td><td>색</td><td>국비</td><td>최대국민수</td><td colspan="4">문장/요새</td></tr>';
    foreach ($countries as $name=>$c) echo '<tr><td>'.ebs_h((string)$name).'</td><td bgcolor="'.ebs_h((string)$c['color']).'">&nbsp;</td><td align="right">'.ebs_h((string)$c['money']).'</td><td align="right">'.ebs_h((string)$c['max_member']).'</td><td colspan="4">'.ebs_h((string)$c['icon']).' / '.ebs_h((string)$c['fortress']).'</td></tr>';
    ebs_remake_footer();
}
function ebs_HITO(): void {
    if (!ebs_remake_admin_required()) return;
    $target = ebs_param('target', ebs_param('pname',''));
    ebs_remake_header('캐릭터 검색');
    echo '<tr><td colspan="8"><form method="post" action="remake.php"><input type="hidden" name="pass" value="'.ebs_remake_pass().'"><input type="hidden" name="cmd" value="HITO">이름 <input name="target" value="'.ebs_h($target).'"> <input type="submit" value="검색" '.ebs_v('STYLE_B1').'></form></td></tr>';
    if ($target !== '') {
        $players = ebs_players_load(); $key = ebs_find_player_key($target,$players); $p = $key !== null ? ($players[$key] ?? null) : null;
        if (is_array($p)) echo '<tr><td colspan="8"><pre style="white-space:pre-wrap;color:inherit;">'.ebs_h(json_encode($p, JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT) ?: '').'</pre></td></tr>'; else echo '<tr><td colspan="8">대상이 없습니다.</td></tr>';
    }
    ebs_remake_footer();
}
function ebs_KUNI(): void {
    if (!ebs_remake_admin_required()) return;
    $target = ebs_param('target', ebs_param('CNTRY',''));
    ebs_remake_header('국가 검색');
    echo '<tr><td colspan="8"><form method="post" action="remake.php"><input type="hidden" name="pass" value="'.ebs_remake_pass().'"><input type="hidden" name="cmd" value="KUNI">국가 <input name="target" value="'.ebs_h($target).'"> <input type="submit" value="검색" '.ebs_v('STYLE_B1').'></form></td></tr>';
    if ($target !== '') {
        $countries = ebs_country_records();
        if (isset($countries[$target])) echo '<tr><td colspan="8"><pre style="white-space:pre-wrap;color:inherit;">'.ebs_h(json_encode($countries[$target], JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT) ?: '').'</pre></td></tr>'; else echo '<tr><td colspan="8">대상이 없습니다.</td></tr>';
    }
    ebs_remake_footer();
}
function ebs_PUSHHITO(): void { ebs_HITO(); }
function ebs_PUSHKUNI(): void { ebs_KUNI(); }
function ebs_KUNI_WRIGHT(): void { if (!ebs_remake_admin_required()) return; ebs_admin_countries('remake.php'); }
function ebs_HITO_WRIGHT(): void { if (!ebs_remake_admin_required()) return; ebs_admin_players('remake.php'); }
function ebs_BUKI_WRIGHT(): void { if (!ebs_remake_admin_required()) return; ebs_admin_weapon_screen('remake.php'); }
function ebs_GOUSEI_WRIGHT(): void { ebs_GOUSEISOUJI(); }
function ebs_INPORT(): void { ebs_HITOALL(); }
function ebs_INPORT_G(): void { ebs_KUNIALL(); }
function ebs_BUKI(): void { ebs_BUKIJOUHOU(); }
function ebs_GOUSEI(): void { ebs_GOUSEISOUJI(); }
function ebs_HITODELETE(): void { ebs_DELETELIST(); }
function ebs_BOTTOM(): void { ebs_remake_footer(); }

$map = [
    'MAIN'=>'ebs_MAIN','IPKAIZOU'=>'ebs_IPKAIZOU','SAKUJOKAIZOU'=>'ebs_SAKUJOKAIZOU','SINKIKAIZOU'=>'ebs_SINKIKAIZOU','TUKAIKATA'=>'ebs_TUKAIKATA',
    'IPLOOK'=>'ebs_IPLOOK','LOGINS'=>'ebs_LOGINS','DELETELIST'=>'ebs_DELETELIST','SINKILIST'=>'ebs_SINKILIST','BUKISOUJI'=>'ebs_BUKISOUJI','GOUSEISOUJI'=>'ebs_GOUSEISOUJI','BUKIJOUHOU'=>'ebs_BUKIJOUHOU',
    'OPENHITO'=>'ebs_HITO','OPENKUNI'=>'ebs_KUNI','PUSHHITO'=>'ebs_PUSHHITO','PUSHKUNI'=>'ebs_PUSHKUNI','KUNI_WRIGHT'=>'ebs_KUNI_WRIGHT','HITO_WRIGHT'=>'ebs_HITO_WRIGHT','BUKI_WRIGHT'=>'ebs_BUKI_WRIGHT','GOUSEI_WRIGHT'=>'ebs_GOUSEI_WRIGHT',
    'HITOALL'=>'ebs_HITOALL','KUNIALL'=>'ebs_KUNIALL','KUNI'=>'ebs_KUNI','HITO'=>'ebs_HITO','INPORT'=>'ebs_INPORT','INPORT_G'=>'ebs_INPORT_G','BUKI'=>'ebs_BUKI','GOUSEI'=>'ebs_GOUSEI','HITODELETE'=>'ebs_HITODELETE','BOTTOM'=>'ebs_BOTTOM',
];
ebs_dispatch($map, 'ebs_MAIN');
?>
