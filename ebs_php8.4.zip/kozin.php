<?php
declare(strict_types=1);
require_once __DIR__ . '/lib_ebs.php';

function ebs_kozin_price(array $w, string $mode): int {
    $level = (int)($w['level'] ?? 1);
    if ($mode === 'create') return 50000;
    if ($mode === 'name') return 10000;
    if ($mode === 'effect') return 200000 + $level * 10000;
    return 30000 + $level * 5000;
}
function ebs_kozin_default_weapon(array $me): array {
    [$wid, $wname] = ebs_calc_weapon_label((string)($me['weapon'] ?? ebs_default_weapon_id()));
    return ['id'=>'personal','name'=>$wname.'改','level'=>1,'attack'=>1,'hit'=>1,'count'=>1,'en'=>1,'effect'=>'','base'=>$wid];
}
function ebs_KOZIN(): void {
    ebs_header_html();
    ebs_record_post('kozin.php::KOZIN');
    [$key, $me, $players, $err] = ebs_require_player();
    if ($err !== '' || $key === null || !is_array($me)) { ebs_error_page('개인무기', $err ?: '로그인 정보가 없습니다.'); return; }
    $pname = (string)($me['name'] ?? $key);
    $pass = ebs_param('pass', ebs_cookie_value('pass', ''));
    $w = isset($me['personal_weapon']) && is_array($me['personal_weapon']) ? $me['personal_weapon'] : null;
    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>개인무기</title></head><body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="font-size:13px;margin:0;"><center>';
    echo '<table border="1" bordercolor="'.ebs_h(ebs_v('TABLE_BORDER')).'" cellspacing="0" cellpadding="5" style="font-size:13px;"><tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'"><b>개인무기</b></td></tr>';
    if (!$w) {
        echo '<tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'">현재 개인무기가 없습니다. 장비중인 무기를 기반으로 개인무기를 생성할 수 있습니다.<br>생성비용: '.number_format(ebs_kozin_price([], 'create')).' Gold</td></tr>';
        echo '<tr><td align="center"><form action="kozin.php" method="POST" target="Sub"><input type="hidden" name="cmd" value="KO_WEAPON"><input type="hidden" name="mode" value="create"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'"><input type="submit" value="개인무기 생성" '.ebs_v('STYLE_B1').'></form></td></tr>';
    } else {
        echo '<tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'">무기명: <b>'.ebs_h((string)$w['name']).'</b><br>Lv '.(int)$w['level'].' / 공격 +'.(int)$w['attack'].' / 명중 +'.(int)$w['hit'].' / 횟수 +'.(int)$w['count'].' / EN보정 '.(int)$w['en'].' / 효과 '.ebs_h((string)($w['effect'] ?? '')).'</td></tr>';
        echo '<tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'"><form action="kozin.php" method="POST" target="Sub"><input type="hidden" name="cmd" value="KO_WEAPON"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'">';
        echo '<button name="mode" value="attack" '.ebs_v('STYLE_B1').'>공격력업</button> <button name="mode" value="hit" '.ebs_v('STYLE_B1').'>명중력업</button> <button name="mode" value="count" '.ebs_v('STYLE_B1').'>공격회수업</button> <button name="mode" value="en" '.ebs_v('STYLE_B1').'>EN소비감소</button><br><br>';
        echo '무기명 <input type="text" name="newname" value="'.ebs_h((string)$w['name']).'"> <button name="mode" value="name" '.ebs_v('STYLE_B1').'>무기명 변경</button> ';
        echo '효과 <input type="text" name="effect" value="'.ebs_h((string)($w['effect'] ?? '')).'" size="8"> <button name="mode" value="effect" '.ebs_v('STYLE_B1').'>특수효과 설정</button>';
        echo '</form></td></tr>';
    }
    echo '<tr><td align="center"><form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST" target="Main"><input type="hidden" name="cmd" value="MAIN_FRAME"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'"><input type="submit" value="귀환" '.ebs_v('STYLE_B1').'></form></td></tr>';
    echo '</table></center></body></html>';
}
function ebs_KO_WEAPON(): void {
    ebs_header_html();
    ebs_record_post('kozin.php::KO_WEAPON');
    [$key, $me, $players, $err] = ebs_require_player();
    if ($err !== '' || $key === null || !is_array($me)) { ebs_error_page('개인무기', $err ?: '로그인 정보가 없습니다.'); return; }
    $mode = ebs_param('mode', '');
    $w = isset($me['personal_weapon']) && is_array($me['personal_weapon']) ? $me['personal_weapon'] : [];
    if (!$w) $w = ebs_kozin_default_weapon($me);
    $price = ebs_kozin_price($w, $mode === '' ? 'create' : $mode);
    $money = (int)($me['money'] ?? 0);
    $msg = '';
    if ($money < $price) {
        $msg = 'Gold가 부족합니다. 필요 Gold: '.number_format($price);
    } else {
        $money -= $price;
        switch ($mode) {
            case 'create': $w = ebs_kozin_default_weapon($me); $msg = '개인무기를 생성했습니다.'; break;
            case 'attack': $w['attack'] = (int)($w['attack'] ?? 0) + 1; $w['level'] = (int)($w['level'] ?? 1) + 1; $msg = '공격력을 강화했습니다.'; break;
            case 'hit': $w['hit'] = (int)($w['hit'] ?? 0) + 1; $w['level'] = (int)($w['level'] ?? 1) + 1; $msg = '명중력을 강화했습니다.'; break;
            case 'count': $w['count'] = (int)($w['count'] ?? 0) + 1; $w['level'] = (int)($w['level'] ?? 1) + 1; $msg = '공격회수를 강화했습니다.'; break;
            case 'en': $w['en'] = max(0, (int)($w['en'] ?? 1) - 1); $w['level'] = (int)($w['level'] ?? 1) + 1; $msg = 'EN소비를 보정했습니다.'; break;
            case 'name': $new = trim(ebs_param('newname', (string)($w['name'] ?? '개인무기'))); if ($new !== '') $w['name'] = function_exists('mb_substr') ? mb_substr($new, 0, 40, 'UTF-8') : substr($new,0,40); $msg = '무기명을 변경했습니다.'; break;
            case 'effect': $w['effect'] = preg_replace('/[^0-9A-Za-z가-힣_\-]/u', '', ebs_param('effect','')) ?: ''; $msg = '특수효과를 설정했습니다.'; break;
            default: $msg = '처리할 항목이 없습니다.'; $money += $price; break;
        }
        $me['money'] = $money;
        $me['personal_weapon'] = $w;
        if (!isset($me['event_log']) || !is_array($me['event_log'])) $me['event_log'] = [];
        $me['event_log'][] = ['type'=>'personal_weapon','mode'=>$mode,'price'=>$price,'time'=>date('YmdHis')];
        if (count($me['event_log']) > 80) $me['event_log'] = array_slice($me['event_log'], -80);
        ebs_player_save_one((string)($me['name'] ?? $key), $me);
    }
    ebs_render_sub_result('개인무기', ebs_h($msg).'<br><form action="kozin.php" method="POST" target="Sub"><input type="hidden" name="cmd" value="KOZIN"><input type="hidden" name="pname" value="'.ebs_h((string)($me['name'] ?? $key)).'"><input type="hidden" name="pass" value="'.ebs_h(ebs_param('pass', ebs_cookie_value('pass',''))).'"><input type="submit" value="돌아가기" '.ebs_v('STYLE_B1').'></form>');
}
$map = ['KOZIN'=>'ebs_KOZIN','KO_WEAPON'=>'ebs_KO_WEAPON'];
ebs_dispatch($map, 'ebs_KOZIN');
?>
