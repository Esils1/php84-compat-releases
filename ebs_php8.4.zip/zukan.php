<?php
declare(strict_types=1);
require_once __DIR__ . '/lib_ebs.php';

function ebs_zukan_load(): array { return ebs_json_load('zukan'); }
function ebs_zukan_save(array $data): bool { return ebs_json_save('zukan', $data); }
function ebs_zukan_player_name(): string { return ebs_clean_login_value(ebs_param('pname', ebs_cookie_value('pname', ''))); }
function ebs_zukan_known(string $pname): array {
    $data = ebs_zukan_load();
    $known = $data[$pname] ?? [];
    return is_array($known) ? array_values(array_unique(array_map('strval', $known))) : [];
}
function ebs_zukan_register_current(): string {
    [$key, $me, $players, $err] = ebs_require_player();
    if ($err !== '' || $key === null || !is_array($me)) return $err ?: '로그인 정보가 없습니다.';
    $pname = (string)($me['name'] ?? $key);
    [$id] = ebs_calc_weapon_label((string)($me['weapon'] ?? ebs_default_weapon_id()));
    if ($id === '') return '장비중인 무기가 없습니다.';
    $data = ebs_zukan_load();
    $known = isset($data[$pname]) && is_array($data[$pname]) ? array_map('strval', $data[$pname]) : [];
    if (!in_array($id, $known, true)) $known[] = $id;
    sort($known, SORT_NATURAL);
    $data[$pname] = $known;
    ebs_zukan_save($data);
    return '현재 장비 무기 ['.$id.']를 도감에 등록했습니다.';
}
function ebs_zukan_table(array $ids, bool $all): string {
    $weapons = ebs_weapon_table();
    $known = array_flip($ids);
    $html = '<table border="1" bordercolor="'.ebs_h(ebs_v('TABLE_BORDER')).'" cellpadding="3" cellspacing="0" style="font-size:13px;">';
    $html .= '<tr bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'"><th>상태</th><th>ID</th><th>무기명</th><th>공격</th><th>명중</th><th>횟수</th><th>EN</th><th>효과</th></tr>';
    foreach ($weapons as $id => $row) {
        if (!$all && !isset($known[(string)$id])) continue;
        $row = is_array($row) ? $row : [];
        $mark = isset($known[(string)$id]) ? '등록' : '미등록';
        $html .= '<tr bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'">';
        $html .= '<td align="center">'.ebs_h($mark).'</td><td>'.ebs_h((string)$id).'</td><td>'.ebs_h((string)($row[0] ?? $id)).'</td>';
        $html .= '<td align="center">'.ebs_status_rank((string)($row[1] ?? '0')).'</td><td align="center">'.ebs_status_rank((string)($row[2] ?? '0')).'</td>';
        $html .= '<td align="right">'.ebs_h((string)($row[3] ?? '0')).'</td><td align="right">'.ebs_h((string)($row[4] ?? '0')).'</td><td>'.ebs_weapon_effects((string)($row[7] ?? ''), (string)($row[8] ?? '')).'</td></tr>';
    }
    $html .= '</table>';
    return $html;
}
function ebs_ZUKAN2(): void {
    ebs_header_html();
    ebs_record_post('zukan.php::ZUKAN2');
    $pname = ebs_zukan_player_name();
    $pass = ebs_param('pass', ebs_cookie_value('pass', ''));
    $known = $pname !== '' ? ebs_zukan_known($pname) : [];
    $total = count(ebs_weapon_table());
    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>무기 도감</title></head><body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="font-size:13px;margin:0;"><center>';
    echo '<form action="zukan.php" method="POST" target="Sub"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'">';
    echo '<table border="1" bordercolor="'.ebs_h(ebs_v('TABLE_BORDER')).'" cellpadding="4" cellspacing="0" style="font-size:13px;">';
    echo '<tr><th bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'">무기 도감</th></tr>';
    echo '<tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" align="center">등록 '.count($known).' / 전체 '.$total.'</td></tr>';
    echo '<tr><td align="center" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'"><button name="cmd" value="TOUROKU2" '.ebs_v('STYLE_B1').'>현재 무기 등록</button> <button name="cmd" value="ETURAN2" '.ebs_v('STYLE_B1').'>등록 무기 보기</button> <button name="cmd" value="ETURAN3" '.ebs_v('STYLE_B1').'>전체 보기</button></td></tr>';
    echo '</table></form><br>';
    echo ebs_zukan_table($known, false);
    echo '</center></body></html>';
}
function ebs_ETURAN2(): void { ebs_header_html(); $p=ebs_zukan_player_name(); echo '<html><body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="font-size:13px;margin:0;"><center><h3>등록 무기 열람</h3>'.ebs_zukan_table($p!==''?ebs_zukan_known($p):[], false).'<br><form action="zukan.php" method="POST" target="Sub"><input type="hidden" name="cmd" value="ZUKAN2"><input type="hidden" name="pname" value="'.ebs_h($p).'"><input type="submit" value="돌아온다" '.ebs_v('STYLE_B1').'></form></center></body></html>'; }
function ebs_ETURAN3(): void { ebs_header_html(); $p=ebs_zukan_player_name(); echo '<html><body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="font-size:13px;margin:0;"><center><h3>전체 무기 열람</h3>'.ebs_zukan_table($p!==''?ebs_zukan_known($p):[], true).'<br><form action="zukan.php" method="POST" target="Sub"><input type="hidden" name="cmd" value="ZUKAN2"><input type="hidden" name="pname" value="'.ebs_h($p).'"><input type="submit" value="돌아온다" '.ebs_v('STYLE_B1').'></form></center></body></html>'; }
function ebs_TOUROKU2(): void { ebs_header_html(); $msg=ebs_zukan_register_current(); echo '<html><body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="font-size:13px;margin:0;"><center><table border="1" cellpadding="6" cellspacing="0"><tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'">도감 등록</td></tr><tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'">'.ebs_h($msg).'</td></tr></table><br><form action="zukan.php" method="POST" target="Sub"><input type="hidden" name="cmd" value="ZUKAN2"><input type="hidden" name="pname" value="'.ebs_h(ebs_zukan_player_name()).'"><input type="hidden" name="pass" value="'.ebs_h(ebs_param('pass', ebs_cookie_value('pass',''))).'"><input type="submit" value="돌아온다" '.ebs_v('STYLE_B1').'></form></center></body></html>'; }
function ebs_ZUKAN_READ(): void { ebs_ZUKAN2(); }
function ebs_RADIO(): void { ebs_ZUKAN2(); }
function ebs_JOUHOU(): void { ebs_ZUKAN2(); }
function ebs_KOUKA(): void { ebs_ETURAN2(); }
function ebs_KOUKA2(): void { ebs_ETURAN3(); }
$map = ['READ'=>'ebs_ZUKAN_READ','RADIO'=>'ebs_RADIO','JOUHOU'=>'ebs_JOUHOU','ZUKAN'=>'ebs_ZUKAN2','ZUKAN2'=>'ebs_ZUKAN2','ETURAN'=>'ebs_ETURAN2','ETURAN2'=>'ebs_ETURAN2','ETURAN3'=>'ebs_ETURAN3','KOUKA'=>'ebs_KOUKA','KOUKA2'=>'ebs_KOUKA2','TOUROKU'=>'ebs_TOUROKU2','TOUROKU2'=>'ebs_TOUROKU2'];
ebs_dispatch($map, 'ebs_ZUKAN2');
?>
