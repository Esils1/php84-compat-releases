<?php
declare(strict_types=1);
require_once __DIR__ . '/lib_ebs.php';
/**
 * 원본 legacy 파일: dungeonss.php - 랜덤 던전 PHP 저장 방식 구현.
 */
function ebs_dungeon_data_file(): string { return 'log/_dungeonss.data'; }
function ebs_dungeon_title(): string { return '어둠의 미궁'; }
function ebs_dungeon_state_key(): string { return 'dungeonss'; }
function ebs_dungeon_max_floor(): int {
    $max = 1;
    foreach (ebs_legacy_monsters(ebs_dungeon_data_file()) as $m) $max = max($max, (int)$m['floor']);
    return max(1, min(10, $max));
}
function ebs_dungeon_map_key(): string { return ebs_dungeon_state_key(); }
function ebs_dungeon_player_state(array $me): array {
    $key = ebs_dungeon_state_key();
    $max = ebs_dungeon_max_floor();
    $maps = ebs_dungeon_map_load(ebs_dungeon_map_key(), $max);
    $state = isset($me[$key]) && is_array($me[$key]) ? $me[$key] : [];
    $floor = max(1, min($max, (int)($state['floor'] ?? 1)));
    $map = ebs_dungeon_floor_map($maps, $floor);
    [$sx,$sy] = ebs_dungeon_find_start($map);
    $x = max(0, min(9, (int)($state['x'] ?? $sx)));
    $y = max(0, min(9, (int)($state['y'] ?? $sy)));
    $step = max(0, (int)($state['step'] ?? 0));
    $visited = isset($state['visited']) && is_array($state['visited']) ? $state['visited'] : [];
    if (!isset($visited[(string)$floor]) || !is_array($visited[(string)$floor])) $visited[(string)$floor] = [];
    $visited[(string)$floor][$x.','.$y] = 1;
    return ['floor'=>$floor,'x'=>$x,'y'=>$y,'step'=>$step,'visited'=>$visited];
}
function ebs_dungeon_state_store(array &$me, array $state): void {
    $me[ebs_dungeon_state_key()] = [
        'floor'=>(int)$state['floor'], 'x'=>(int)$state['x'], 'y'=>(int)$state['y'],
        'step'=>(int)$state['step'], 'visited'=>isset($state['visited']) && is_array($state['visited']) ? $state['visited'] : []
    ];
}
function ebs_dungeon_current_tile(array $map, int $x, int $y): string { return (string)($map[$y][$x] ?? '5'); }
function ebs_dungeon_move_delta(string $move): array {
    if ($move === 'up') return [0,-1];
    if ($move === 'down') return [0,1];
    if ($move === 'left') return [-1,0];
    if ($move === 'right') return [1,0];
    return [0,0];
}
function ebs_dungeon_opposite_dir(string $move): string {
    if ($move === 'up') return 'down';
    if ($move === 'down') return 'up';
    if ($move === 'left') return 'right';
    if ($move === 'right') return 'left';
    return '';
}
function ebs_dungeon_render_map(array $map, array $state): void {
    $floor = (int)$state['floor'];
    $x = (int)$state['x'];
    $y = (int)$state['y'];
    $visited = isset($state['visited'][(string)$floor]) && is_array($state['visited'][(string)$floor]) ? $state['visited'][(string)$floor] : [];
    echo '<table border="1" cellspacing="0" cellpadding="0" bordercolor="'.ebs_h(ebs_v('TABLE_BORDER')).'" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" style="border-collapse:collapse;font-size:11px;line-height:1">';
    echo '<tr><td colspan="10" align="center" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'">'.ebs_h(ebs_dungeon_title()).$floor.'층 지도</td></tr>';
    for ($yy=0; $yy<10; $yy++) {
        echo '<tr>';
        for ($xx=0; $xx<10; $xx++) {
            $tile = strtolower((string)($map[$yy][$xx] ?? '5'));
            $seen = isset($visited[$xx.','.$yy]);
            $label = '&nbsp;';
            if ($xx === $x && $yy === $y) $label = '<b>◎</b>';
            elseif ($seen) {
                if ($tile === '6') $label = '↑';
                elseif ($tile === '7') $label = '↓';
                elseif ($tile === '8') $label = 'S';
                elseif ($tile === '9') $label = '$';
                elseif ($tile === 'a') $label = 'T';
                elseif ($tile === 'b') $label = 'B';
                else $label = '·';
            }
            $bg = $seen ? '#303030' : '#151515';
            if ($xx === $x && $yy === $y) $bg = '#606060';
            echo '<td title="'.ebs_h($tile.' '.ebs_dungeon_tile_name($tile)).'" style="width:20px;height:20px;text-align:center;background:'.$bg.';padding:0">'.$label.'</td>';
        }
        echo '</tr>';
    }
    echo '</table>';
}
function ebs_dungeon_button(string $cmd, string $label, string $pname, string $pass, string $move=''): void {
    echo '<form action="'.ebs_h(basename(__FILE__)).'" method="POST" style="display:inline;margin:0 2px" target="Sub"><input type="hidden" name="cmd" value="'.ebs_h($cmd).'">';
    if ($move !== '') echo '<input type="hidden" name="move" value="'.ebs_h($move).'">';
    echo '<input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'"><input type="submit" value="'.ebs_h($label).'" '.ebs_v('STYLE_B1').'></form>';
}
function ebs_dungeon_menu(string $message=''): void {
    ebs_header_html();
    [$key,$me,$players,$err] = ebs_require_player();
    if ($err !== '' || $key === null || !is_array($me)) { ebs_error_page('Error', $err ?: '로그인 정보가 없습니다.'); return; }
    $pname=(string)($me['name'] ?? $key); $pass=ebs_param('pass', ebs_cookie_value('pass',''));
    $state = ebs_dungeon_player_state($me);
    $floor = (int)$state['floor'];
    $maps = ebs_dungeon_map_load(ebs_dungeon_map_key(), ebs_dungeon_max_floor());
    $map = ebs_dungeon_floor_map($maps, $floor);
    $tile = ebs_dungeon_current_tile($map, (int)$state['x'], (int)$state['y']);
    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>'.ebs_h(ebs_dungeon_title()).'</title></head>';
    echo '<body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="margin:0;font-size:13px;" oncontextmenu="return false;"><center>';
    echo '<table border="0" width="95%" cellspacing="1" cellpadding="5" bgcolor="'.ebs_h(ebs_v('TABLE_BORDER')).'">';
    echo '<tr><td colspan="2" align="center" bgcolor="#ff3300" style="color:#000000;font-size:24px;"><b>'.ebs_h(ebs_dungeon_title()).'</b></td></tr>';
    if ($message !== '') echo '<tr><td colspan="2" align="center" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'">'.$message.'</td></tr>';
    echo '<tr><td colspan="2" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" align="center">현재 '.$floor.'층 / 좌표 '.((int)$state['x']+1).','.((int)$state['y']+1).' / 이동 '.$state['step'].'회</td></tr>';
    echo '<tr><td valign="top" width="240" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'">';
    ebs_dungeon_render_map($map, $state);
    echo '</td><td valign="top" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'">';
    echo '<div style="margin-bottom:8px">현재 지점 : '.ebs_h(ebs_dungeon_tile_name($tile)).'</div>';
    echo '<div style="margin-bottom:8px">';
    ebs_dungeon_button('IDOU','위',$pname,$pass,'up');
    ebs_dungeon_button('IDOU','아래',$pname,$pass,'down');
    ebs_dungeon_button('IDOU','왼쪽',$pname,$pass,'left');
    ebs_dungeon_button('IDOU','오른쪽',$pname,$pass,'right');
    ebs_dungeon_button('IDOU','탐색',$pname,$pass,'stay');
    ebs_dungeon_button('WEAPONS','장비',$pname,$pass);
    echo '</div>';
    if ($tile === '6') ebs_dungeon_button('IDOU','상층',$pname,$pass,'floorup');
    if ($tile === '7') ebs_dungeon_button('IDOU','하층',$pname,$pass,'floordown');
    echo '<form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST" target="Main" style="display:inline;margin:0 2px"><input type="hidden" name="cmd" value="MAIN_FRAME"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'"><input type="submit" value="귀환" '.ebs_v('STYLE_B1').'></form>';
    echo '<div style="margin-top:12px;font-size:12px;color:#cccccc">지도를 탐사하다가 몬스터를 만나면 전투가 발생합니다. 계단 칸에서 다음 층으로 이동합니다.</div>';
    echo '</td></tr>';
    echo '</table></center></body></html>';
}
function ebs_dungeon_pick_boss(array $mons): array { return $mons ? $mons[count($mons)-1] : []; }
function ebs_dungeon_encounter_monster(int $floor, string $tile, string $move): array {
    $mons = ebs_monsters_by_floor(ebs_dungeon_data_file(), $floor);
    if (!$mons) return [];
    $tile = strtolower($tile);
    if ($tile === 'b') return ebs_dungeon_pick_boss($mons);
    $rate = ebs_dungeon_encounter_rate(ebs_dungeon_state_key(), $move, $tile);
    if (mt_rand(1,100) <= $rate) return ebs_pick_monster(ebs_dungeon_data_file(), $floor, '');
    return [];
}
function ebs_IDOU(): void {
    [$key,$me,$players,$err] = ebs_require_player();
    if ($err !== '' || $key === null || !is_array($me)) { ebs_error_page('Error', $err ?: '로그인 정보가 없습니다.'); return; }
    $state = ebs_dungeon_player_state($me);
    $move = ebs_param('move','stay');
    $max = ebs_dungeon_max_floor();
    $maps = ebs_dungeon_map_load(ebs_dungeon_map_key(), $max);
    $map = ebs_dungeon_floor_map($maps, (int)$state['floor']);
    $msg = '';
    if ($move === 'floorup' || $move === 'floordown') {
        $tile = ebs_dungeon_current_tile($map, (int)$state['x'], (int)$state['y']);
        if ($move === 'floorup' && $tile === '6') {
            $state['floor'] = max(1, (int)$state['floor'] - 1);
            $map = ebs_dungeon_floor_map($maps, (int)$state['floor']);
            [$state['x'],$state['y']] = ebs_dungeon_find_start($map);
            $msg = ebs_h($state['floor'].'층으로 이동했습니다.');
        } elseif ($move === 'floordown' && $tile === '7') {
            $state['floor'] = min($max, (int)$state['floor'] + 1);
            $map = ebs_dungeon_floor_map($maps, (int)$state['floor']);
            [$state['x'],$state['y']] = ebs_dungeon_find_start($map);
            $msg = ebs_h($state['floor'].'층으로 이동했습니다.');
        } else {
            $msg = '이 지점에는 계단이 없습니다.';
        }
    } elseif (in_array($move, ['up','down','left','right'], true)) {
        $tile = ebs_dungeon_current_tile($map, (int)$state['x'], (int)$state['y']);
        [$dx,$dy] = ebs_dungeon_move_delta($move);
        $nx = (int)$state['x'] + $dx; $ny = (int)$state['y'] + $dy;
        if ($nx < 0 || $nx > 9 || $ny < 0 || $ny > 9) {
            $msg = '더 이상 이동할 수 없습니다.';
        } elseif (!ebs_dungeon_tile_allows($tile, $move)) {
            $msg = '벽이 막고 있습니다.';
        } else {
            $nextTile = ebs_dungeon_current_tile($map, $nx, $ny);
            $opp = ebs_dungeon_opposite_dir($move);
            if ($opp !== '' && !ebs_dungeon_tile_allows($nextTile, $opp)) {
                $msg = '벽이 막고 있습니다.';
            } else {
                $state['x'] = $nx; $state['y'] = $ny; $msg = '이동했습니다.';
            }
        }
    } else {
        $msg = '주위를 탐색했습니다.';
    }
    $state['step'] = (int)$state['step'] + 1;
    if (!isset($state['visited'][(string)$state['floor']]) || !is_array($state['visited'][(string)$state['floor']])) $state['visited'][(string)$state['floor']] = [];
    $state['visited'][(string)$state['floor']][((int)$state['x']).','.((int)$state['y'])] = 1;
    ebs_dungeon_state_store($me, $state);
    if (!isset($me['event_log']) || !is_array($me['event_log'])) $me['event_log'] = [];
    $me['event_log'][] = ['type'=>ebs_dungeon_state_key(),'action'=>'map','floor'=>$state['floor'],'x'=>$state['x'],'y'=>$state['y'],'time'=>date('YmdHis')];
    if (count($me['event_log']) > 80) $me['event_log'] = array_slice($me['event_log'], -80);
    ebs_player_sync_common($me); $players[$key]=$me; ebs_players_save($players);
    $map = ebs_dungeon_floor_map($maps, (int)$state['floor']);
    $tile = ebs_dungeon_current_tile($map, (int)$state['x'], (int)$state['y']);
    $mon = ebs_dungeon_encounter_monster((int)$state['floor'], $tile, $move);
    if ($mon) { ebs_run_npc_battle(ebs_dungeon_title(), $mon, ebs_dungeon_state_key().'_battle'); return; }
    ebs_dungeon_menu(ebs_h($msg));
}
function ebs_BATTLE(): void {
    ebs_dungeon_menu('직접 전투는 사용하지 않습니다. 지도를 이동하거나 탐색해서 몬스터를 만나야 합니다.');
}
function ebs_START(): void { ebs_dungeon_menu(); }
function ebs_DUNGEON(): void { ebs_dungeon_menu(); }
function ebs_LOGIN(): void { ebs_dungeon_menu(); }
function ebs_TOP(): void { ebs_dungeon_menu(); }
function ebs_WEAPONS(): void {
    ebs_header_html();
    [$key,$me,$players,$err] = ebs_require_player();
    if ($err !== '' || $key === null || !is_array($me)) { ebs_error_page('Error', $err ?: '로그인 정보가 없습니다.'); return; }
    $pname=(string)($me['name'] ?? $key); $pass=ebs_param('pass', ebs_cookie_value('pass',''));
    $msg='';
    if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && ebs_param('Cmode','') === '장비교체') {
        $slot=ebs_param('slot','');
        if ($slot === 'weapon2' && (string)($me['weapon2'] ?? '') !== '') { [$me['weapon'],$me['weapon2']] = [$me['weapon2'], (string)($me['weapon'] ?? '')]; $msg='예비1 무기로 교체했습니다.'; }
        elseif ($slot === 'weapon3' && (string)($me['weapon3'] ?? '') !== '') { [$me['weapon'],$me['weapon3']] = [$me['weapon3'], (string)($me['weapon'] ?? '')]; $msg='예비2 무기로 교체했습니다.'; }
        else $msg='교체 가능한 예비 무기가 없습니다.';
        ebs_player_sync_common($me); $players[$key]=$me; ebs_players_save($players);
    }
    $slots=['weapon'=>'장비중','weapon2'=>'예비1','weapon3'=>'예비2'];
    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>'.ebs_h(ebs_dungeon_title()).' 장비</title></head><body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="margin:0;font-size:13px;"><center>';
    echo '<form action="'.ebs_h(basename(__FILE__)).'" method="POST" target="Sub"><input type="hidden" name="cmd" value="WEAPONS"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'">';
    echo '<table border="1" cellspacing="0" cellpadding="6" bordercolor="'.ebs_h(ebs_v('TABLE_BORDER')).'" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" style="font-size:13px;min-width:500px;">';
    echo '<tr><td colspan="4" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'" align="center"><b>'.ebs_h(ebs_dungeon_title()).' 장비 확인</b></td></tr>';
    if ($msg !== '') echo '<tr><td colspan="4" align="center"><b>'.ebs_h($msg).'</b></td></tr>';
    echo '<tr bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'"><td>구분</td><td>무기</td><td>성능</td><td>교체</td></tr>';
    foreach ($slots as $slot=>$label) {
        [$wid,$wname,$wlv,$wexp,$row]=ebs_calc_weapon_label((string)($me[$slot] ?? ''));
        $perf = $row ? ('공격 '.(string)($row[1] ?? '').' / 명중 '.(string)($row[2] ?? '').' / EN '.(string)($row[4] ?? '').' / 가격 $'.number_format((int)($row[5] ?? 0))) : '-';
        echo '<tr><td>'.ebs_h($label).'</td><td>'.ebs_h($wname.' Lv.'.$wlv.'/exp.'.$wexp).'</td><td>'.ebs_h($perf).'</td><td align="center">';
        if ($slot !== 'weapon' && (string)($me[$slot] ?? '') !== '') echo '<button type="submit" name="slot" value="'.ebs_h($slot).'" '.ebs_v('STYLE_B1').' onclick="this.form.Cmode.value=&quot;장비교체&quot;;return confirm(&quot;장비를 교체합니다. 괜찮습니까?&quot;);">장비</button>';
        echo '</td></tr>';
    }
    echo '<tr><td colspan="4" align="center" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'"><input type="hidden" name="Cmode" value=""><input type="submit" value="던전으로" '.ebs_v('STYLE_B1').' onclick="this.form.cmd.value=&quot;DUNGEON&quot;;this.form.Cmode.value=&quot;&quot;;"></td></tr>';
    echo '</table></form></center></body></html>';
}

function ebs_MONEYS(): void { ebs_dungeon_menu('던전 내 보상은 전투 승리 시 자동으로 지급됩니다.'); }
function ebs_MONSTER(): void { ebs_IDOU(); }
function ebs_MAPPING(): void { ebs_dungeon_menu('현재 위치를 지도에 기록했습니다.'); }
function ebs_WEAPS(): void { ebs_dungeon_menu('획득 무기는 전투 보상으로 처리됩니다.'); }
function ebs_ENDSCRIPT(): void { ebs_dungeon_menu('던전에서 나왔습니다.'); }
$map = ['BATTLE'=>'ebs_BATTLE','INPORT'=>'ebs_TOP','LOGIN'=>'ebs_LOGIN','START'=>'ebs_START','DUNGEON'=>'ebs_DUNGEON','IDOU'=>'ebs_IDOU','WEAPONS'=>'ebs_WEAPONS','MONEYS'=>'ebs_MONEYS','MONSTER'=>'ebs_MONSTER','MAPPING'=>'ebs_MAPPING','WEAPS'=>'ebs_WEAPS','ENDSCRIPT'=>'ebs_ENDSCRIPT','TOP'=>'ebs_TOP'];
ebs_dispatch($map, 'ebs_TOP');
?>
