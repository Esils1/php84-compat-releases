<?php
declare(strict_types=1);
require_once __DIR__ . '/lib_ebs.php';
/**
 * 던전 입구 선택 화면.
 * 메인 메뉴의 던전 버튼이 지하감옥/어둠의 미궁 중 하나를 선택하게 한다.
 */
ebs_header_html();
[$key, $me, $players, $err] = ebs_require_player();
$pname = '';
$pass = ebs_param('pass', ebs_cookie_value('pass',''));
if (is_array($me)) $pname = (string)($me['name'] ?? (string)$key);
if ($pname === '') $pname = ebs_param('pname', ebs_cookie_value('pname',''));
echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>ENDLESS BATTLE</title></head>';
echo '<body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="margin:0;font-size:13px;"><center>';
echo '<table border="1" cellspacing="0" cellpadding="6" bordercolor="'.ebs_h(ebs_v('TABLE_BORDER')).'" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" style="font-size:13px;min-width:420px;margin-top:18px;">';
echo '<tr><td colspan="2" align="center" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'"><b>던전 입구</b></td></tr>';
if ($err !== '' || !is_array($me)) {
    echo '<tr><td colspan="2" align="center">'.ebs_h($err ?: '로그인 정보가 없습니다.').'</td></tr>';
} else {
    echo '<tr><td colspan="2" align="center">입장할 던전을 선택하십시오.</td></tr>';
    echo '<tr><td width="50%" align="center">';
    echo '<form action="./dungeons.php" method="POST" target="Sub" style="margin:0"><input type="hidden" name="cmd" value="TOP"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'"><input type="submit" value="지하감옥" '.ebs_v('STYLE_B1').'></form>';
    echo '</td><td width="50%" align="center">';
    echo '<form action="./dungeonss.php" method="POST" target="Sub" style="margin:0"><input type="hidden" name="cmd" value="TOP"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'"><input type="submit" value="어둠의 미궁" '.ebs_v('STYLE_B1').'></form>';
    echo '</td></tr>';
    echo '<tr><td colspan="2" style="font-size:12px;line-height:1.5;color:#cccccc;">지하감옥은 1~10층 고정 맵을 탐사합니다.<br>어둠의 미궁은 별도 맵/몬스터 설정을 사용하는 미궁 던전입니다.</td></tr>';
}
echo '</table></center></body></html>';
?>
