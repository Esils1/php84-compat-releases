<?php
declare(strict_types=1);
require_once __DIR__ . '/lib_ebs.php';
/**
 * 원본 legacy 파일: kaigisitu.php
 * 회의실/전언 기능을 PHP 8.4 파일 저장 방식(data/kaigisitu_log.json)으로 구동한다.
 */

function ebs_kaigisitu_rows(): array {
    $data = ebs_json_load('kaigisitu_log');
    return isset($data['rows']) && is_array($data['rows']) ? $data['rows'] : [];
}
function ebs_kaigisitu_save_rows(array $rows): void {
    ebs_json_save('kaigisitu_log', ['rows'=>array_slice($rows, -200)]);
}
function ebs_kaigisitu_footer(): void {
    echo '<br><br><br><div align="center"><font size="2">PROGRAMING:(C) 2002 - 44NET FACTORY</font> <font size="2">- All Right Reserved.</font></div>';
    echo '<div align="right"><font size="2" color="white">KAIGISITU var.1.1 / PHP 8.4</font></div></body></html>';
}
function ebs_kaigisitu_header(string $title='회의실'): void {
    ebs_header_html();
    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>ENDLESS BATTLE - '.ebs_h($title).'</title></head>';
    echo '<body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" link="'.ebs_h(ebs_v('LINK')).'" style="margin:0;font-size:13px;" oncontextmenu="return false;">';
}
function ebs_kaigisitu_player(): array {
    $pname = ebs_clean_login_value(ebs_param('pname', ebs_cookie_value('pname', '')));
    $pass = ebs_param('pass', ebs_cookie_value('pass', ''));
    $players = ebs_players_load();
    $key = ebs_find_player_key($pname, $players);
    if ($key === null || !isset($players[$key]) || !is_array($players[$key])) return [null, null, $pname, $pass, '등록 데이터를 찾을 수 없습니다.'];
    if (!ebs_password_matches($players[$key], $pass)) return [$key, null, $pname, $pass, '패스워드가 틀립니다.'];
    return [$key, $players[$key], $pname, $pass, ''];
}

function ebs_COOKIE_IN(): void {
    [$key, $me, $pname, $pass, $err] = ebs_kaigisitu_player();
    if ($pname !== '' && $err === '' && is_array($me)) { ebs_MAIN_PAGE(); return; }
    ebs_kaigisitu_header('회의실입구');
    echo '<table border="0" width="100%" height="90%"><tr><td align="center" valign="middle"><form action="kaigisitu.php" method="POST">';
    echo '<input type="hidden" name="cmd" value="MAIN_PAGE"><table border="1" cellspacing="0" cellpadding="4" bordercolor="#404040" style="font-size:16pt" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'">';
    echo '<tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'" colspan="2">회의실입구</td></tr>';
    echo '<tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'">이름</td><td><input type="text" size="25" name="pname" '.ebs_v('STYLE_B1').'></td></tr>';
    echo '<tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'">패스워드</td><td><input type="password" size="25" name="pass" '.ebs_v('STYLE_B1').'></td></tr>';
    if ($err !== '' && $pname !== '') echo '<tr><td colspan="2"><font color="red">'.ebs_h($err).'</font></td></tr>';
    echo '<tr><td colspan="2" align="right"><input type="submit" value="결정" '.ebs_v('STYLE_B1').'></td></tr></table></form></td></tr></table>';
    ebs_kaigisitu_footer();
}

function ebs_SETUMEI(): void {
    ebs_kaigisitu_header('회의실 사용방법');
    echo '<table border="1" cellspacing="0" cellpadding="6" bordercolor="#404040" style="font-size:12pt" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'">';
    echo '<tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'" colspan="2">회의실의 사용 방법에 관하여</td></tr>';
    echo '<tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'">발언 국 선택</td><td>선택한 국가에 소속된 사람에게 보이는 발언입니다. 외교, 선전포고, 전쟁 종료 인사 등에 사용합니다.</td></tr>';
    echo '<tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'">발언 상대 선택</td><td>특정 플레이어에게만 보이는 발언입니다. 직접 이름을 입력할 수도 있습니다.</td></tr>';
    echo '<tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'">표시 색</td><td><font color="#ffaaaa">개인/자기앞</font> <font color="#aaaaff">자신→개인앞</font> <font color="#ffffff">전체 발언</font> <font color="#ffffaa">자국민 대상 발언</font></td></tr>';
    echo '</table><p align="center"><a href="kaigisitu.php">돌아가기</a></p>';
    ebs_kaigisitu_footer();
}

function ebs_OUTPUT(): void {
    [$key, $me, $pname, $pass, $err] = ebs_kaigisitu_player();
    if ($err !== '' || !is_array($me)) { ebs_COOKIE_IN(); return; }
    $comment = trim(ebs_param('comment', ''));
    if ($comment !== '') {
        $players = ebs_players_load();
        $to = ebs_param('aiteB', '') !== '' ? ebs_param('aiteB', '') : ebs_param('aiteA', '');
        if ($to !== '' && ebs_find_player_key($to, $players) === null) {
            $GLOBALS['EBS_KAIGISITU_ERROR'] = '발언상대가 없기에 발언이 취소되었습니다.';
        } else {
            $rows = ebs_kaigisitu_rows();
            $country = ebs_param('country', '');
            $icon = ebs_normalize_icon((string)($me['icon'] ?? '1'), '1');
            $msg = function_exists('mb_substr') ? mb_substr($comment, 0, 100, 'UTF-8') : substr($comment, 0, 100);
            array_unshift($rows, ['name'=>$pname, 'country'=>$country, 'comment'=>$msg, 'time'=>date('Y-m-d H:i:s'), 'icon'=>$icon, 'to'=>$to, 'looked'=>0]);
            ebs_kaigisitu_save_rows($rows);
        }
    }
    ebs_MAIN_PAGE();
}

function ebs_MAIN_PAGE(): void {
    [$key, $me, $pname, $pass, $err] = ebs_kaigisitu_player();
    if ($err !== '' || !is_array($me)) { ebs_COOKIE_IN(); return; }
    $players = ebs_players_load();
    $country = (string)($me['kuni'] ?? '');
    $countryLabel = $country !== '' ? $country : ebs_v('NONE_NATIONALITY');
    $countries = ebs_country_records();
    $countryInfo = $country !== '' && isset($countries[$country]) ? $countries[$country] : ['money'=>'0','color'=>'#808080'];
    ebs_kaigisitu_header('회의실');
    echo '<form action="kaigisitu.php" method="POST"><input type="hidden" name="cmd" value="OUTPUT"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'"><input type="hidden" name="icon" value="'.ebs_h(ebs_normalize_icon((string)($me['icon'] ?? '1'), '1')).'">';
    echo '<table border="1" cellspacing="0" cellpadding="2" bordercolor="#404040" style="font-size:16pt" width="100%"><tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'">';
    echo '<font color="white" style="font-size:12pt">'.ebs_h($countryLabel).'용 회의실&nbsp;&nbsp;&nbsp;캐릭명 : '.ebs_h((string)($me['msname'] ?? '')).'&nbsp;&nbsp;&nbsp;이름 : '.ebs_h($pname).'&nbsp;&nbsp;&nbsp;국비 '.ebs_h((string)($countryInfo['money'] ?? '0')).'원</font>';
    echo '<div align="right"><a href="kaigisitu.php?cmd=SETUMEI"><font style="font-size:10pt">회의실 사용방법</font></a></div></td></tr>';
    echo '<tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'"><table border="0" cellspacing="0" cellpadding="5" width="100%" style="font-size:12pt"><tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'">발언 국 선택 <select name="country" '.ebs_v('STYLE_B1').'><option value="">전국에게';
    foreach ($countries as $cname=>$c) echo '<option value="'.ebs_h($cname).'"'.($cname===$country?' selected':'').'>'.ebs_h($cname);
    echo '<option value="'.ebs_h(ebs_v('NONE_NATIONALITY')).'">'.ebs_h(ebs_v('NONE_NATIONALITY')).'</select> 발언상대 선택 <select name="aiteA" '.ebs_v('STYLE_B1').'><option value="">전원에게';
    foreach ($players as $name=>$pl) if ((string)$name !== $pname) echo '<option value="'.ebs_h((string)$name).'">'.ebs_h((string)$name);
    echo '</select> 발언 상대 기입 <input type="text" name="aiteB" '.ebs_v('STYLE_B1').'></td></tr>';
    echo '<tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'">발언 기입 <input type="text" name="comment" '.ebs_v('STYLE_B1').' size="50"> <input type="submit" value=" 발언 " '.ebs_v('STYLE_B1').'> <input type="reset" value="클리어" '.ebs_v('STYLE_B1').'></td></tr>';
    $errMsg = (string)($GLOBALS['EBS_KAIGISITU_ERROR'] ?? '');
    echo '<tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'">표시문자색 <font color="#ffaaaa">개인→자기앞</font> <font color="#aaaaff">자신→개인앞</font> <font color="#ffffff">전원에게의 발언</font> <font color="#ffffaa">자국민 대상 발언</font> <font color="red" size="5"><b>'.ebs_h($errMsg).'</b></font></td></tr></table></td></tr></form>';
    echo '<tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'"><table border="1" cellspacing="0" cellpadding="2" bordercolor="#404040" style="font-size:16pt" width="100%"><tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'">';
    $printed = 0;
    foreach (ebs_kaigisitu_rows() as $row) {
        if (!is_array($row)) continue;
        $rname = (string)($row['name'] ?? '');
        $rcountry = (string)($row['country'] ?? '');
        if ($rcountry === ebs_v('NONE_NATIONALITY')) $rcountry = '';
        $to = (string)($row['to'] ?? '');
        $visible = false; $fcolor = '#ffffff';
        if ($to !== '') {
            if ($to === $pname || $rname === $pname) { $visible = true; $fcolor = ($to === $pname) ? '#ffaaaa' : '#aaaaff'; }
        } elseif ($rcountry !== '') {
            if ($rcountry === $country || $rname === $pname) { $visible = true; $fcolor = '#ffffaa'; }
        } else { $visible = true; $fcolor = '#ffffff'; }
        if (!$visible) continue;
        $icon = ebs_normalize_icon((string)($row['icon'] ?? '1'), '1');
        $suffix = $to !== '' ? '&nbsp;&gt;'.ebs_h($to) : ($rcountry !== '' ? '&nbsp;&gt;'.ebs_h($rcountry).'의 국민' : '');
        echo '<table border="0" width="100%" style="font-size:10pt"><tr><td align="left" width="35"><img src="'.ebs_h(ebs_v('IMG_FOLDER2')).'/'.ebs_h($icon).'.gif" width="32" height="32"></td>';
        echo '<td align="left"><font color="'.$fcolor.'">'.ebs_h($rname).'&nbsp;[코드No.'.ebs_h($icon).']&nbsp;'.ebs_h((string)($row['comment'] ?? '')).$suffix.'</font></td><td align="right"><font style="font-size:9pt">[&nbsp;'.ebs_h((string)($row['time'] ?? '')).'&nbsp;]</font></td></tr></table><hr>';
        if (++$printed >= 100) break;
    }
    if ($printed === 0) echo '<div align="center">표시할 발언이 없습니다.</div>';
    echo '</td></tr></table></td></tr></table>';
    ebs_kaigisitu_footer();
}

function ebs_END_HTML(): void { ebs_kaigisitu_footer(); }

$map = [
    'COOKIE_IN' => 'ebs_COOKIE_IN',
    'MAIN_PAGE' => 'ebs_MAIN_PAGE',
    'SETUMEI' => 'ebs_SETUMEI',
    'OUTPUT' => 'ebs_OUTPUT',
    'END_HTML' => 'ebs_END_HTML',
];
ebs_dispatch($map, 'ebs_COOKIE_IN');
?>
