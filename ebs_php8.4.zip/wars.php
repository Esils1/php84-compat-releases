<?php
declare(strict_types=1);
require_once __DIR__ . '/lib_ebs.php';
/**
 * 원본 legacy 파일: wars.php
 * PHP 8.4 파일 기반 제압/점령 화면.
 */
function ebs_war_regions(): array {
    return [
        1=>'그린란드',2=>'영국',3=>'러시아',4=>'미국',5=>'중국',6=>'일본',7=>'멕시코',
        8=>'하와이',9=>'브라질',10=>'인도',11=>'아르헨티나',12=>'호주',13=>'아프리카',14=>'미지의 섬'
    ];
}
function ebs_war_load(): array {
    $rows = ebs_json_load('war_territory');
    if (!is_array($rows) || !$rows) {
        $rows = [];
        foreach (ebs_war_regions() as $id=>$name) $rows[(string)$id] = ['id'=>$id,'name'=>$name,'owner'=>'','color'=>'#808080','wins'=>0,'updated'=>''];
    }
    return $rows;
}
function ebs_war_save(array $rows): bool { return ebs_json_save('war_territory', $rows); }
function ebs_war_screen(string $message=''): void {
    ebs_header_html();
    [$key,$me,$players,$err] = ebs_require_player();
    if ($err !== '' || $key === null || !is_array($me)) { ebs_error_page('Error', $err ?: '로그인 정보가 없습니다.'); return; }
    $pname=(string)($me['name'] ?? $key); $pass=ebs_param('pass', ebs_cookie_value('pass',''));
    if (ebs_param('war_action') === 'attack') { ebs_war_attack(); return; }
    $rows = ebs_war_load();
    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>제압</title></head>';
    echo '<body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="margin:0;font-size:13px;" oncontextmenu="return false;"><center>';
    echo '<table border="0" cellspacing="1" cellpadding="4" bgcolor="'.ebs_h(ebs_v('TABLE_BORDER')).'" width="95%">';
    echo '<tr><td colspan="5" align="center" bgcolor="#ff3300" style="color:#000000;font-size:24px;"><b>■점령할 곳을 선택하세요.</b></td></tr>';
    if ($message !== '') echo '<tr><td colspan="5" align="center" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'">'.$message.'</td></tr>';
    echo '<tr bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'"><td>선택</td><td>지역</td><td>지배국</td><td>승리수</td><td>갱신</td></tr>';
    foreach (ebs_war_regions() as $id=>$name) {
        $r = $rows[(string)$id] ?? ['owner'=>'','color'=>'#808080','wins'=>0,'updated'=>''];
        echo '<tr bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'"><td align="center"><form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST" target="Sub"><input type="hidden" name="cmd" value="BATTLE_3"><input type="hidden" name="war_action" value="attack"><input type="hidden" name="country" value="'.(int)$id.'"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'"><input type="submit" value="제압" '.ebs_v('STYLE_B1').'></form></td>';
        echo '<td><b>'.ebs_h($name).'</b></td><td><span style="color:'.ebs_h((string)($r['color'] ?? '#808080')).';">'.ebs_h((string)($r['owner'] ?? '무소속')).'</span></td><td align="right">'.(int)($r['wins'] ?? 0).'</td><td>'.ebs_h((string)($r['updated'] ?? '')).'</td></tr>';
    }
    echo '</table></center></body></html>';
}
function ebs_war_attack(): void {
    [$key,$me,$players,$err] = ebs_require_player();
    if ($err !== '' || $key === null || !is_array($me)) { ebs_error_page('Error', $err ?: '로그인 정보가 없습니다.'); return; }
    $target = (int)ebs_param('country','0');
    $regions = ebs_war_regions();
    if (!isset($regions[$target])) { ebs_war_screen('지역 선택이 올바르지 않습니다.'); return; }
    $rows = ebs_war_load();
    $country = (string)($me['kuni'] ?? ebs_v('NONE_NATIONALITY'));
    $color = ebs_color((string)($me['color'] ?? '#ffffff'), '#ffffff');
    $enemy = [
        'name'=>$regions[$target].' 방위군', 'icon'=>(string)(200 + $target),
        'hp'=>5000 + $target * 300, 'at'=>18 + $target, 'de'=>14 + $target,
        'exp'=>120 + $target * 10, 'money'=>3000 + $target * 200, 'wexp'=>20
    ];
    $beforeOwner = (string)($rows[(string)$target]['owner'] ?? '');
    ob_start();
    ebs_run_npc_battle('제압전 - '.$regions[$target], $enemy, 'war_battle');
    $html = ob_get_clean();
    if ($html === false) $html = '';
    // ebs_run_npc_battle가 저장한 뒤 다시 읽어 승리 추정: 이벤트 로그에 win이면 점령 처리.
    $fresh = ebs_player_load_one((string)($me['name'] ?? $key));
    $last = [];
    if (isset($fresh['event_log']) && is_array($fresh['event_log']) && $fresh['event_log']) $last = end($fresh['event_log']);
    if (is_array($last) && (string)($last['type'] ?? '') === 'war_battle' && (string)($last['result'] ?? '') === 'win') {
        $rows[(string)$target] = ['id'=>$target,'name'=>$regions[$target],'owner'=>$country,'color'=>$color,'wins'=>(int)($rows[(string)$target]['wins'] ?? 0)+1,'updated'=>date('Y-m-d H:i')];
        ebs_war_save($rows);
        $fresh['contrib'] = (int)($fresh['contrib'] ?? 0) + 10;
        ebs_player_save_one((string)($fresh['name'] ?? $key), $fresh);
        $html = str_replace('</table></center>', '<tr><td colspan="2" align="center" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'">'.ebs_h($beforeOwner === '' ? $regions[$target] : $beforeOwner).' 지배지를 '.ebs_h($country).' 소속으로 점령했습니다.</td></tr></table></center>', $html);
    }
    echo $html;
}
function ebs_STATUS(): void { ebs_war_screen(); }
function ebs_BATTLE2(): void { ebs_war_attack(); }
function ebs_LOG0(): void { ebs_war_screen(); }
function ebs_LOGO(): void { ebs_war_screen(); }
function ebs_TOP(): void { ebs_war_screen(); }
function ebs_MAIN_FRAME(): void { ebs_war_screen(); }
function ebs_CUSTOM(): void { ebs_war_screen(); }
function ebs_BATTLE_2(): void { ebs_war_attack(); }
function ebs_SYUSEI(): void { ebs_war_screen(); }
function ebs_BONUS(): void { ebs_war_screen('보상은 제압전 전투 결과에서 자동 반영됩니다.'); }
function ebs_DOWN(): void { ebs_war_screen('제압전 결과 처리는 전투 화면에서만 수행됩니다.'); }
$map = ['STATUS'=>'ebs_STATUS','BATTLE2'=>'ebs_BATTLE2','BATTLE_2'=>'ebs_BATTLE_2','LOG0'=>'ebs_LOG0','LOGO'=>'ebs_LOGO','TOP'=>'ebs_TOP','MAIN_FRAME'=>'ebs_MAIN_FRAME','CUSTOM'=>'ebs_CUSTOM','SYUSEI'=>'ebs_SYUSEI','BONUS'=>'ebs_BONUS','DOWN'=>'ebs_DOWN'];
ebs_dispatch($map, 'ebs_STATUS');
?>
