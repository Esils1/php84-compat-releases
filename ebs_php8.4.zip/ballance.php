<?php
declare(strict_types=1);
require_once __DIR__ . '/lib_ebs.php';

function ebs_ballance_rows(bool $powerMode): array {
    $players = ebs_players_load();
    $countries = ebs_country_records();
    $rows = [];
    foreach ($countries as $name => $c) {
        $rows[$name] = [
            'name' => $name,
            'leader' => (string)($c['leader'] ?? $c['king'] ?? ''),
            'color' => ebs_color((string)($c['color'] ?? '#333333'), '#333333'),
            'count' => 0,
            'power' => 0,
        ];
    }
    $none = ebs_v('NONE_NATIONALITY', '방랑자');
    if (!isset($rows[$none])) $rows[$none] = ['name'=>$none,'leader'=>'','color'=>'#000000','count'=>0,'power'=>0];
    foreach ($players as $p) {
        if (!is_array($p)) continue;
        $kuni = trim((string)($p['kuni'] ?? ''));
        if ($kuni === '') $kuni = $none;
        if (!isset($rows[$kuni])) $rows[$kuni] = ['name'=>$kuni,'leader'=>'','color'=>'#333333','count'=>0,'power'=>0];
        $rows[$kuni]['count']++;
        $st = isset($p['st']) && is_array($p['st']) ? $p['st'] : [0,0,0,0];
        $rows[$kuni]['power'] += max(1, (int)($p['level'] ?? 1)) + array_sum(array_map('intval', $st)) + ((int)($p['win'] ?? 0) * 2) + ebs_player_contrib_value($p);
    }
    uasort($rows, static function (array $a, array $b) use ($powerMode): int {
        $ka = $powerMode ? (int)$a['power'] : (int)$a['count'];
        $kb = $powerMode ? (int)$b['power'] : (int)$b['count'];
        if ($ka === $kb) return strcmp((string)$a['name'], (string)$b['name']);
        return $kb <=> $ka;
    });
    return $rows;
}

function ebs_ballance_screen(bool $powerMode): void {
    ebs_header_html();
    $rows = ebs_ballance_rows($powerMode);
    $total = 0;
    foreach ($rows as $r) $total += $powerMode ? (int)$r['power'] : (int)$r['count'];
    if ($total <= 0) $total = 1;
    $title = $powerMode ? '국력도' : '세력도';
    $unit = $powerMode ? '포인트' : '명';
    $backCmd = $powerMode ? 'BALLANCE' : 'BALLANCE2';
    $backLabel = $powerMode ? '세력' : '국력';
    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>'.$title.'</title></head>';
    echo '<body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="font-size:13px;margin:0;"><center>';
    echo '<table width="100%" height="100%"><tr><td align="center"><table cellspacing="2" cellpadding="3" bgcolor="#909090" style="font-size:16px;" border="1">';
    echo '<tr><td bgcolor="#404040" colspan="5" align="center"><b>'.ebs_h($title).'</b></td></tr>';
    echo '<tr><td align="center">국명</td><td align="center"><font color="red">총수</font></td><td colspan="2">　</td><td>'.($powerMode ? '군사력' : '인구').'</td></tr>';
    foreach ($rows as $r) {
        $val = $powerMode ? (int)$r['power'] : (int)$r['count'];
        $ratio = round($val * 100 / $total, 1);
        $bar = max(1, min(250, (int)round($ratio * 2.5)));
        echo '<tr>';
        echo '<td align="center" bgcolor="'.ebs_h((string)$r['color']).'"><font color="BLACK">'.ebs_h((string)$r['name']).'</font></td>';
        echo '<td align="center">【'.ebs_h((string)$r['leader']).'】</td>';
        echo '<td><img src="'.ebs_h(ebs_v('IMG_FOLDER1')).'/hp.gif" hspace="0" height="7" width="'.$bar.'"></td>';
        echo '<td>'.ebs_h((string)$ratio).' %</td><td>'.ebs_h((string)$val).$unit.'</td></tr>';
    }
    echo '<tr><td colspan="5" align="center"><form action="ballance.php" method="POST" target="Sub"><input type="hidden" name="cmd" value="'.ebs_h($backCmd).'"><input type="submit" value="'.ebs_h($backLabel).'" '.ebs_v('STYLE_B2').'></form></td></tr>';
    echo '</table></td></tr></table></center></body></html>';
}
function ebs_BALLANCE(): void { ebs_record_post('ballance.php::BALLANCE'); ebs_ballance_screen(false); }
function ebs_BALLANCE2(): void { ebs_record_post('ballance.php::BALLANCE2'); ebs_ballance_screen(true); }
$map = ['BALLANCE'=>'ebs_BALLANCE','BALLANCE2'=>'ebs_BALLANCE2'];
ebs_dispatch($map, 'ebs_BALLANCE');
?>
