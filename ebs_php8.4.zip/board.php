<?php
declare(strict_types=1);
require_once __DIR__ . '/lib_ebs.php';
ebs_header_html();
$pname = ebs_clean_login_value(ebs_param('pname', ebs_cookie_value('pname', '')));
$pass = ebs_param('pass', ebs_cookie_value('pass', ''));
[$playerKey, $me, $playersForAuth, $authErr] = ebs_require_player($pname, $pass);
$loginOk = ($authErr === '' && is_array($me));
$currentName = $loginOk ? (string)($me['name'] ?? $pname) : '';
$authMessage = (!$loginOk && $pname !== '') ? '로그인 정보가 일치하지 않습니다. 본인 글 수정/삭제는 비밀번호 확인 후 가능합니다.' : '';
$isAdmin = ebs_admin_ok();
$posts = ebs_json_load('board_posts');
if (!is_array($posts)) $posts = [];
$msg = '';
function ebs_board_can_edit(array $row, string $currentName, bool $isAdmin, bool $loginOk = false): bool {
    if ($isAdmin) return true;
    $owner = (string)($row['name'] ?? '');
    return $loginOk && $currentName !== '' && $owner !== '' && hash_equals($owner, $currentName);
}
function ebs_board_find(array $posts, string $id): ?int {
    foreach ($posts as $i=>$row) if (is_array($row) && (string)($row['id'] ?? '') === $id) return (int)$i;
    return null;
}
$mode = ebs_param('mode','');
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    if ($mode === 'write') {
        $title = trim(ebs_param('title',''));
        $body = trim(ebs_param('body',''));
        if (!$loginOk || $currentName === '') $msg = '로그인 후 작성할 수 있습니다.';
        elseif ($title === '' || $body === '') $msg = '제목과 내용을 입력하세요.';
        else {
            $posts[] = [
                'id'=>date('YmdHis').'-'.substr(md5($currentName.$title.microtime(true)),0,6),
                'name'=>$currentName,
                'title'=>function_exists('mb_substr') ? mb_substr($title,0,60,'UTF-8') : substr($title,0,60),
                'body'=>function_exists('mb_substr') ? mb_substr($body,0,2000,'UTF-8') : substr($body,0,2000),
                'time'=>date('Y/m/d H:i'),
                'edit_time'=>'',
            ];
            if (count($posts) > 200) $posts = array_slice($posts, -200);
            ebs_json_save('board_posts', $posts);
            $msg = '등록되었습니다.';
        }
    } elseif ($mode === 'update') {
        $id = ebs_param('id','');
        $idx = ebs_board_find($posts, $id);
        if ($idx === null || !isset($posts[$idx]) || !is_array($posts[$idx])) $msg = '대상 글을 찾을 수 없습니다.';
        elseif (!ebs_board_can_edit($posts[$idx], $currentName, $isAdmin, $loginOk)) $msg = '본인 글만 수정할 수 있습니다.';
        else {
            $title = trim(ebs_param('title',''));
            $body = trim(ebs_param('body',''));
            if ($title === '' || $body === '') $msg = '제목과 내용을 입력하세요.';
            else {
                $posts[$idx]['title'] = function_exists('mb_substr') ? mb_substr($title,0,60,'UTF-8') : substr($title,0,60);
                $posts[$idx]['body'] = function_exists('mb_substr') ? mb_substr($body,0,2000,'UTF-8') : substr($body,0,2000);
                $posts[$idx]['edit_time'] = date('Y/m/d H:i');
                ebs_json_save('board_posts', $posts);
                $msg = '수정했습니다.';
            }
        }
    } elseif ($mode === 'delete') {
        $id = ebs_param('id','');
        $idx = ebs_board_find($posts, $id);
        if ($idx === null || !isset($posts[$idx]) || !is_array($posts[$idx])) $msg = '대상 글을 찾을 수 없습니다.';
        elseif (!ebs_board_can_edit($posts[$idx], $currentName, $isAdmin, $loginOk)) $msg = '본인 글만 삭제할 수 있습니다.';
        else {
            array_splice($posts, $idx, 1);
            ebs_json_save('board_posts', $posts);
            $msg = '삭제했습니다.';
        }
    }
}
$editId = ebs_param('edit','');
$editRow = null;
if ($editId !== '') {
    $idx = ebs_board_find($posts, $editId);
    if ($idx !== null && isset($posts[$idx]) && is_array($posts[$idx]) && ebs_board_can_edit($posts[$idx], $currentName, $isAdmin, $loginOk)) $editRow = $posts[$idx];
}
$display = array_reverse($posts);
echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>EBS Board</title><style>body,table,input,textarea{font-size:13px}.board-row td{background:'.ebs_h(ebs_v('TABLE_COLOR1')).';color:'.ebs_h(ebs_v('FONT_COLOR')).';}.board-edit{background:#000000;color:#ededed;border:1px solid #606060;font-size:13px;}</style></head><body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" link="'.ebs_h(ebs_v('LINK')).'" vlink="'.ebs_h(ebs_v('LINK')).'" style="margin:0;font-size:13px;">';
echo '<center><table border="1" cellspacing="0" cellpadding="5" bordercolor="'.ebs_h(ebs_v('TABLE_BORDER')).'" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" style="min-width:720px;font-size:13px;"><tr><td colspan="4" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'" align="center"><b>보드</b></td></tr>';
if ($authMessage !== '' && $msg === '') echo '<tr><td colspan="4" align="center"><b>'.ebs_h($authMessage).'</b></td></tr>';
if ($msg !== '') echo '<tr><td colspan="4" align="center"><b>'.ebs_h($msg).'</b></td></tr>';
echo '<tr bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'"><td width="120">작성자</td><td>제목/내용</td><td width="120">일시</td><td width="110">관리</td></tr>';
foreach (array_slice($display,0,50) as $row) {
    if (!is_array($row)) continue;
    $can = ebs_board_can_edit($row, $currentName, $isAdmin, $loginOk);
    $id = (string)($row['id'] ?? '');
    echo '<tr class="board-row"><td>'.ebs_h((string)($row['name'] ?? '')).'</td><td><b>'.ebs_h((string)($row['title'] ?? '')).'</b><br>'.nl2br(ebs_h((string)($row['body'] ?? '')));
    if ((string)($row['edit_time'] ?? '') !== '') echo '<br><span style="color:#999">수정: '.ebs_h((string)$row['edit_time']).'</span>';
    echo '</td><td>'.ebs_h((string)($row['time'] ?? '')).'</td><td align="center">';
    if ($can && $id !== '') {
        echo '<form method="post" action="board.php" target="Sub" style="display:inline;margin:0"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'"><input type="hidden" name="edit" value="'.ebs_h($id).'"><input type="submit" value="수정" '.ebs_v('STYLE_B2').'></form> ';
        echo '<form method="post" action="board.php" target="Sub" style="display:inline;margin:0"><input type="hidden" name="mode" value="delete"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'"><input type="hidden" name="id" value="'.ebs_h($id).'"><input type="submit" value="삭제" '.ebs_v('STYLE_B2').' onclick="return confirm(\'삭제합니까?\')"></form>';
    } else echo '&nbsp;';
    echo '</td></tr>';
}
if (!$posts) echo '<tr><td colspan="4" align="center">등록된 글이 없습니다.</td></tr>';
$formMode = $editRow ? 'update' : 'write';
$formTitle = $editRow ? (string)($editRow['title'] ?? '') : '';
$formBody = $editRow ? (string)($editRow['body'] ?? '') : '';
echo '<tr class="board-row"><td colspan="4"><form method="post" action="board.php" target="Sub"><input type="hidden" name="mode" value="'.ebs_h($formMode).'"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'">';
if ($editRow) echo '<input type="hidden" name="id" value="'.ebs_h((string)($editRow['id'] ?? '')).'"><b>글 수정</b><br>';
else echo '<b>글 작성</b><br>';
echo '제목 <input type="text" name="title" value="'.ebs_h($formTitle).'" size="50" class="board-edit"><br><textarea name="body" rows="5" cols="80" class="board-edit" style="width:96%;height:90px;">'.ebs_h($formBody).'</textarea><br><input type="submit" value="'.($editRow?'수정':'등록').'" '.ebs_v('STYLE_B1').'>';
echo '</form>';
if ($editRow) {
    echo ' <form method="post" action="board.php" target="Sub" style="display:inline"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'"><input type="submit" value="취소" '.ebs_v('STYLE_B1').'></form>';
}
echo '</td></tr>';
echo '</table></center></body></html>';
?>
