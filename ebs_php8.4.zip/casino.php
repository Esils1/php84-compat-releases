<?php
declare(strict_types=1);
require_once __DIR__ . '/lib_ebs.php';

/**
 * casino.php
 * PHP 8.4 파일 저장 방식 전용 카지노 포커.
 * - DB/CGI/외부 모듈 없음
 * - user/*.json 안의 casino 상태와 money를 직접 갱신
 */

function ebs_casino_hidden(string $pname='', string $pass=''): string {
    if ($pname === '') $pname = ebs_param('pname', ebs_cookie_value('pname',''));
    if ($pass === '') $pass = ebs_param('pass', ebs_cookie_value('pass',''));
    return '<input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'">';
}

function ebs_casino_load_player(): array {
    [$key, $me, $players, $err] = ebs_require_player();
    if ($err !== '' || $key === null || !is_array($me)) return [false, null, $err ?: '등록 데이터를 찾을 수 없습니다.', $players, null];
    return [true, $me, '', $players, $key];
}

function ebs_casino_header(string $title): void {
    ebs_header_html();
    echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>'.ebs_h($title).'</title></head>';
    echo '<body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="margin:8px;font-size:13px;" oncontextmenu="return false;">';
    echo '<center><table border="1" cellspacing="0" cellpadding="5" bordercolor="'.ebs_h(ebs_v('TABLE_BORDER')).'" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" style="min-width:700px;font-size:13px;">';
    echo '<tr><td colspan="6" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'" align="center"><b>'.ebs_h($title).'</b></td></tr>';
}

function ebs_casino_footer(string $pname='', string $pass=''): void {
    echo '<tr><td colspan="6" align="center">';
    echo '<form action="casino.php" method="POST" style="display:inline" target="Sub"><input type="hidden" name="cmd" value="START_GAME">'.ebs_casino_hidden($pname,$pass).'<input type="submit" value="포커" '.ebs_v('STYLE_B1').'></form> ';
    echo '<form action="casino.php" method="POST" style="display:inline" target="Sub"><input type="hidden" name="cmd" value="RANKING">'.ebs_casino_hidden($pname,$pass).'<input type="submit" value="랭킹" '.ebs_v('STYLE_B1').'></form> ';
    echo '<form action="casino.php" method="POST" style="display:inline" target="Sub"><input type="hidden" name="cmd" value="SETUMEI">'.ebs_casino_hidden($pname,$pass).'<input type="submit" value="설명" '.ebs_v('STYLE_B1').'></form>';
    echo '</td></tr></table></center></body></html>';
}

function ebs_casino_deck(): array {
    $deck = [];
    foreach (['S'=>'♠','H'=>'♥','D'=>'♦','C'=>'♣'] as $suit=>$mark) {
        for ($rank=2; $rank<=14; $rank++) $deck[] = ['rank'=>$rank, 'suit'=>$suit, 'mark'=>$mark];
    }
    for ($i=count($deck)-1; $i>0; $i--) {
        $j = random_int(0, $i);
        $tmp = $deck[$i]; $deck[$i] = $deck[$j]; $deck[$j] = $tmp;
    }
    return $deck;
}

function ebs_casino_card_name(array $card): string {
    $rank = (int)($card['rank'] ?? 0);
    $label = [11=>'J',12=>'Q',13=>'K',14=>'A'][$rank] ?? (string)$rank;
    return $label.(string)($card['mark'] ?? '');
}

function ebs_casino_render_cards(array $hand, bool $selectHold=false, array $held=[]): void {
    echo '<tr>';
    foreach (array_values($hand) as $idx=>$card) {
        $suit = (string)($card['suit'] ?? 'S');
        $color = ($suit === 'H' || $suit === 'D') ? '#ff4040' : '#e0e0e0';
        echo '<td align="center" bgcolor="#101010" style="font-size:28px;color:'.$color.';min-width:80px;height:70px;">'.ebs_h(ebs_casino_card_name($card));
        if ($selectHold) {
            $checked = in_array((string)$idx, $held, true) ? ' checked' : '';
            echo '<br><label style="font-size:12px;color:#ffffff;"><input type="checkbox" name="hold[]" value="'.$idx.'"'.$checked.'> HOLD</label>';
        }
        echo '</td>';
    }
    echo '</tr>';
}

function ebs_casino_evaluate(array $hand): array {
    $ranks = [];
    $suits = [];
    foreach ($hand as $card) {
        $rank = (int)($card['rank'] ?? 0);
        $suit = (string)($card['suit'] ?? '');
        $ranks[] = $rank;
        $suits[] = $suit;
    }
    sort($ranks);
    $counts = array_count_values($ranks);
    rsort($counts);
    $flush = count(array_unique($suits)) === 1;
    $unique = array_values(array_unique($ranks));
    sort($unique);
    $straight = false;
    if (count($unique) === 5) {
        $straight = ($unique[4] - $unique[0] === 4);
        if ($unique === [2,3,4,5,14]) $straight = true;
    }
    if ($straight && $flush && max($ranks) === 14 && min($ranks) === 10) return ['로열 스트레이트 플러시', 250];
    if ($straight && $flush) return ['스트레이트 플러시', 100];
    if (($counts[0] ?? 0) === 4) return ['포카드', 50];
    if (($counts[0] ?? 0) === 3 && ($counts[1] ?? 0) === 2) return ['풀하우스', 20];
    if ($flush) return ['플러시', 10];
    if ($straight) return ['스트레이트', 8];
    if (($counts[0] ?? 0) === 3) return ['트리플', 5];
    if (($counts[0] ?? 0) === 2 && ($counts[1] ?? 0) === 2) return ['투페어', 3];
    if (($counts[0] ?? 0) === 2) {
        foreach (array_count_values($ranks) as $rank=>$cnt) {
            if ($cnt === 2 && (int)$rank >= 11) return ['Jacks or Better', 2];
        }
    }
    return ['노페어', 0];
}

function ebs_casino_save_player(array $players, string $key, array $me): void {
    ebs_player_sync_common($me);
    $players[$key] = $me;
    ebs_players_save($players);
}

function ebs_casino_render_state(array $me, string $pass, string $message=''): void {
    $pname = (string)($me['name'] ?? '');
    $state = isset($me['casino']) && is_array($me['casino']) ? $me['casino'] : [];
    $hand = isset($state['hand']) && is_array($state['hand']) ? $state['hand'] : [];
    $phase = (string)($state['phase'] ?? '');
    $bet = max(0, (int)($state['bet'] ?? 0));
    $payout = max(0, (int)($state['payout'] ?? 0));
    $rankName = (string)($state['rank_name'] ?? '');
    ebs_casino_header('카지노 포커');
    echo '<tr><td colspan="6">파일럿: <b>'.ebs_h($pname).'</b> / 소지금: <b>'.number_format((int)($me['money'] ?? 0)).' G</b> / BET: <b>'.number_format($bet).' G</b></td></tr>';
    if ($message !== '') echo '<tr><td colspan="6" align="center" bgcolor="#202020"><b>'.ebs_h($message).'</b></td></tr>';
    if ($hand) {
        if ($phase === 'change') {
            echo '<form action="casino.php" method="POST" target="Sub"><input type="hidden" name="cmd" value="CHANGE">'.ebs_casino_hidden($pname,$pass);
            ebs_casino_render_cards($hand, true);
            echo '<tr><td colspan="6" align="center"><input type="submit" value="선택한 카드 보류 후 교환" '.ebs_v('STYLE_B1').'></td></tr></form>';
        } else {
            ebs_casino_render_cards($hand, false);
            echo '<tr><td colspan="6" align="center">결과: <b>'.ebs_h($rankName).'</b> / 지급 예정: <b>'.number_format($payout).' G</b></td></tr>';
            echo '<tr><td colspan="6" align="center">';
            echo '<form action="casino.php" method="POST" style="display:inline" target="Sub"><input type="hidden" name="cmd" value="PAY_OUT">'.ebs_casino_hidden($pname,$pass).'<input type="submit" value="정산" '.ebs_v('STYLE_B1').'></form> ';
            if ($payout > 0) echo '<form action="casino.php" method="POST" style="display:inline" target="Sub"><input type="hidden" name="cmd" value="DOUBLE_UP">'.ebs_casino_hidden($pname,$pass).'<input type="submit" value="더블업" '.ebs_v('STYLE_B1').'></form>';
            echo '</td></tr>';
        }
    } else {
        echo '<tr><td colspan="6" align="center">진행 중인 게임이 없습니다.</td></tr>';
    }
    ebs_casino_footer($pname,$pass);
}

function ebs_START_GAME(): void {
    $pname = ebs_param('pname', ebs_cookie_value('pname',''));
    $pass = ebs_param('pass', ebs_cookie_value('pass',''));
    $moneyText = '';
    [$ok,$me] = ebs_casino_load_player();
    if ($ok && is_array($me)) $moneyText = ' / 소지금 '.number_format((int)($me['money'] ?? 0)).' G';
    ebs_casino_header('카지노 포커');
    echo '<tr><td colspan="6" align="center" style="line-height:1.7;">5장 포커입니다. 베팅 후 카드를 한 번 교환하고 결과 배율만큼 정산합니다.'.ebs_h($moneyText).'</td></tr>';
    echo '<tr><td colspan="6" align="center"><form action="casino.php" method="POST" target="Sub"><input type="hidden" name="cmd" value="ON_BET">'.ebs_casino_hidden($pname,$pass).'BET <input type="text" name="bet" value="100" size="8" '.ebs_v('STYLE_L').'> <input type="submit" value="START" '.ebs_v('STYLE_B1').'></form></td></tr>';
    ebs_casino_footer($pname,$pass);
}

function ebs_ON_BET(): void {
    [$ok,$me,$err,$players,$key] = ebs_casino_load_player();
    if (!$ok || !is_array($me) || $key === null) { ebs_error_page('카지노', $err ?: '로그인 정보가 없습니다.'); return; }
    $pass = ebs_param('pass', ebs_cookie_value('pass',''));
    $bet = max(1, (int)ebs_param('bet','0'));
    $money = (int)($me['money'] ?? 0);
    if ($bet > $money) { ebs_error_page('카지노', '소지금이 부족합니다.'); return; }
    $deck = ebs_casino_deck();
    $hand = array_slice($deck, 0, 5);
    $remain = array_slice($deck, 5);
    $me['money'] = $money - $bet;
    $me['casino'] = ['bet'=>$bet, 'hand'=>$hand, 'deck'=>$remain, 'phase'=>'change', 'time'=>date('YmdHis')];
    ebs_casino_save_player($players, $key, $me);
    ebs_casino_render_state($me, $pass, '교환하지 않을 카드를 HOLD 하십시오.');
}

function ebs_IN_GAME(): void {
    [$ok,$me,$err] = ebs_casino_load_player();
    if (!$ok || !is_array($me)) { ebs_error_page('카지노', $err ?: '로그인 정보가 없습니다.'); return; }
    ebs_casino_render_state($me, ebs_param('pass', ebs_cookie_value('pass','')));
}

function ebs_CHANGE(): void {
    [$ok,$me,$err,$players,$key] = ebs_casino_load_player();
    if (!$ok || !is_array($me) || $key === null) { ebs_error_page('카지노', $err ?: '로그인 정보가 없습니다.'); return; }
    $pass = ebs_param('pass', ebs_cookie_value('pass',''));
    $state = isset($me['casino']) && is_array($me['casino']) ? $me['casino'] : [];
    if (($state['phase'] ?? '') !== 'change') { ebs_casino_render_state($me, $pass, '교환 가능한 게임이 없습니다.'); return; }
    $hand = isset($state['hand']) && is_array($state['hand']) ? array_values($state['hand']) : [];
    $deck = isset($state['deck']) && is_array($state['deck']) ? array_values($state['deck']) : [];
    $holdRaw = $_POST['hold'] ?? [];
    $hold = is_array($holdRaw) ? array_map('strval', $holdRaw) : [];
    for ($i=0; $i<5; $i++) {
        if (!in_array((string)$i, $hold, true) && !empty($deck)) $hand[$i] = array_shift($deck);
    }
    [$rankName, $multi] = ebs_casino_evaluate($hand);
    $bet = max(0, (int)($state['bet'] ?? 0));
    $payout = $bet * (int)$multi;
    $me['casino'] = ['bet'=>$bet, 'hand'=>$hand, 'deck'=>$deck, 'phase'=>'result', 'rank_name'=>$rankName, 'multiplier'=>(int)$multi, 'payout'=>$payout, 'time'=>date('YmdHis')];
    if (!isset($me['casino_play_count'])) $me['casino_play_count'] = 0;
    $me['casino_play_count'] = (int)$me['casino_play_count'] + 1;
    ebs_casino_save_player($players, $key, $me);
    ebs_casino_render_state($me, $pass, $rankName.' / '.$multi.'배');
}

function ebs_PAY_OUT(): void {
    [$ok,$me,$err,$players,$key] = ebs_casino_load_player();
    if (!$ok || !is_array($me) || $key === null) { ebs_error_page('카지노', $err ?: '로그인 정보가 없습니다.'); return; }
    $pass = ebs_param('pass', ebs_cookie_value('pass',''));
    $state = isset($me['casino']) && is_array($me['casino']) ? $me['casino'] : [];
    $win = max(0, (int)($state['payout'] ?? 0));
    if ($win > 0) {
        $me['money'] = (int)($me['money'] ?? 0) + $win;
        $me['casino_total_win'] = (int)($me['casino_total_win'] ?? 0) + $win;
        $log = ebs_json_load('casino_log');
        $log[] = ['time'=>date('Y-m-d H:i:s'), 'pname'=>(string)($me['name'] ?? $key), 'rank'=>(string)($state['rank_name'] ?? ''), 'win'=>$win];
        if (count($log) > 100) $log = array_slice($log, -100);
        ebs_json_save('casino_log', $log);
    }
    unset($me['casino']);
    ebs_casino_save_player($players, $key, $me);
    ebs_casino_header('카지노 정산');
    echo '<tr><td colspan="6" align="center">'.number_format($win).' G를 정산했습니다.</td></tr>';
    echo '<tr><td colspan="6" align="center">현재 소지금: '.number_format((int)($me['money'] ?? 0)).' G</td></tr>';
    ebs_casino_footer((string)($me['name'] ?? $key), $pass);
}

function ebs_DOUBLE_UP(): void {
    [$ok,$me,$err] = ebs_casino_load_player();
    if (!$ok || !is_array($me)) { ebs_error_page('카지노', $err ?: '로그인 정보가 없습니다.'); return; }
    $pass = ebs_param('pass', ebs_cookie_value('pass',''));
    $state = isset($me['casino']) && is_array($me['casino']) ? $me['casino'] : [];
    $payout = max(0, (int)($state['payout'] ?? 0));
    if ($payout <= 0) { ebs_casino_render_state($me, $pass, '더블업 가능한 지급 예정금이 없습니다.'); return; }
    $card = ebs_casino_deck()[0];
    $state['double_card'] = $card;
    $me['casino'] = $state;
    $players = ebs_players_load(); $key = ebs_find_player_key((string)($me['name'] ?? ''), $players);
    if ($key !== null) ebs_casino_save_player($players, $key, $me);
    ebs_casino_header('카지노 더블업');
    echo '<tr><td colspan="6" align="center">현재 카드: <span style="font-size:28px;">'.ebs_h(ebs_casino_card_name($card)).'</span> / 지급 예정 '.number_format($payout).' G</td></tr>';
    echo '<tr><td colspan="6" align="center">다음 카드가 높을지 낮을지 선택하십시오.</td></tr>';
    echo '<tr><td colspan="6" align="center"><form action="casino.php" method="POST" style="display:inline" target="Sub"><input type="hidden" name="cmd" value="DOUBLE">'.ebs_casino_hidden((string)($me['name'] ?? ''),$pass).'<input type="hidden" name="choice" value="HIGH"><input type="submit" value="HIGH" '.ebs_v('STYLE_B1').'></form> ';
    echo '<form action="casino.php" method="POST" style="display:inline" target="Sub"><input type="hidden" name="cmd" value="DOUBLE">'.ebs_casino_hidden((string)($me['name'] ?? ''),$pass).'<input type="hidden" name="choice" value="LOW"><input type="submit" value="LOW" '.ebs_v('STYLE_B1').'></form></td></tr>';
    ebs_casino_footer((string)($me['name'] ?? ''),$pass);
}

function ebs_DOUBLE(): void {
    [$ok,$me,$err,$players,$key] = ebs_casino_load_player();
    if (!$ok || !is_array($me) || $key === null) { ebs_error_page('카지노', $err ?: '로그인 정보가 없습니다.'); return; }
    $pass = ebs_param('pass', ebs_cookie_value('pass',''));
    $state = isset($me['casino']) && is_array($me['casino']) ? $me['casino'] : [];
    $base = isset($state['double_card']) && is_array($state['double_card']) ? $state['double_card'] : ebs_casino_deck()[0];
    $next = ebs_casino_deck()[1];
    $choice = strtoupper(ebs_param('choice','HIGH')) === 'LOW' ? 'LOW' : 'HIGH';
    $okChoice = ($choice === 'HIGH' && (int)$next['rank'] >= (int)$base['rank']) || ($choice === 'LOW' && (int)$next['rank'] <= (int)$base['rank']);
    if ($okChoice) {
        $state['payout'] = max(0, (int)($state['payout'] ?? 0)) * 2;
        unset($state['double_card']);
        $me['casino'] = $state;
        $msg = '성공: '.ebs_casino_card_name($base).' → '.ebs_casino_card_name($next).' / 지급 예정 '.number_format((int)$state['payout']).' G';
    } else {
        unset($me['casino']);
        $msg = '실패: '.ebs_casino_card_name($base).' → '.ebs_casino_card_name($next).' / 지급 예정금이 소멸했습니다.';
    }
    ebs_casino_save_player($players, $key, $me);
    ebs_casino_render_state($me, $pass, $msg);
}

function ebs_RANKING(): void {
    $players = ebs_players_load();
    uasort($players, static function(array $a, array $b): int { return ((int)($b['casino_total_win'] ?? 0)) <=> ((int)($a['casino_total_win'] ?? 0)); });
    ebs_casino_header('카지노 랭킹');
    echo '<tr bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'"><td>순위</td><td>파일럿</td><td>국가</td><td>누적정산</td><td>게임수</td><td>소지금</td></tr>';
    $rank = 1;
    foreach ($players as $name=>$p) {
        if (!is_array($p)) continue;
        $total = (int)($p['casino_total_win'] ?? 0);
        if ($total <= 0) continue;
        echo '<tr><td align="right">'.$rank.'</td><td>'.ebs_h((string)($p['name'] ?? $name)).'</td><td>'.ebs_h((string)($p['kuni'] ?? '')).'</td><td align="right">'.number_format($total).' G</td><td align="right">'.number_format((int)($p['casino_play_count'] ?? 0)).'</td><td align="right">'.number_format((int)($p['money'] ?? 0)).' G</td></tr>';
        if (++$rank > 50) break;
    }
    if ($rank === 1) echo '<tr><td colspan="6" align="center">랭킹 기록이 없습니다.</td></tr>';
    ebs_casino_footer();
}

function ebs_SETUMEI(): void {
    ebs_casino_header('카지노 설명');
    echo '<tr><td colspan="6" style="line-height:1.7;">베팅 금액은 게임 시작 시 차감됩니다. 카드 5장 중 HOLD 체크한 카드는 보존하고 나머지를 한 번 교환합니다. 결과 배율은 로열 스트레이트 플러시 250배, 스트레이트 플러시 100배, 포카드 50배, 풀하우스 20배, 플러시 10배, 스트레이트 8배, 트리플 5배, 투페어 3배, Jacks or Better 2배입니다. 지급 예정 금액은 정산해야 소지금에 반영됩니다.</td></tr>';
    ebs_casino_footer();
}

function ebs_HAITOUKIN(): void { ebs_SETUMEI(); }
function ebs_TABLE_HTML(): void { ebs_IN_GAME(); }
function ebs_HTML_EOF(): void { ebs_IN_GAME(); }
function ebs_ER_HTML(): void { ebs_START_GAME(); }
function ebs_FILE_OPEN(): void { ebs_START_GAME(); }
function ebs_LOCKA(): void { ebs_START_GAME(); }
function ebs_UNLOCKA(): void { ebs_START_GAME(); }
function ebs_RANK_CHECK(): void { ebs_RANKING(); }

$map = [
    'START_GAME' => 'ebs_START_GAME',
    'IN_GAME' => 'ebs_IN_GAME',
    'ON_BET' => 'ebs_ON_BET',
    'CHANGE' => 'ebs_CHANGE',
    'DOUBLE_UP' => 'ebs_DOUBLE_UP',
    'DOUBLE' => 'ebs_DOUBLE',
    'RANKING' => 'ebs_RANKING',
    'SETUMEI' => 'ebs_SETUMEI',
    'PAY_OUT' => 'ebs_PAY_OUT',
    'RANK_CHECK' => 'ebs_RANK_CHECK',
    'HAITOUKIN' => 'ebs_HAITOUKIN',
    'TABLE_HTML' => 'ebs_TABLE_HTML',
    'HTML_EOF' => 'ebs_HTML_EOF',
    'ER_HTML' => 'ebs_ER_HTML',
    'FILE_OPEN' => 'ebs_FILE_OPEN',
    'LOCKA' => 'ebs_LOCKA',
    'UNLOCKA' => 'ebs_UNLOCKA',
];
ebs_dispatch($map, 'ebs_START_GAME');
?>
