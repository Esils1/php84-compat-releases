<?php
declare(strict_types=1);
require_once __DIR__ . '/lib_ebs.php';
$GLOBALS['EBS_FORCE_CMD'] = 'WEAPON_LIST';
require __DIR__ . '/ebs_sub2.php';
?>
