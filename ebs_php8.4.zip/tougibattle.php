<?php
declare(strict_types=1);
require_once __DIR__ . '/lib_ebs.php';
/** 원본 legacy 파일: tougibattle.php - 투기장 PHP 저장 방식 구현. */
function ebs_tougi_list(string $message=''): void {
    ebs_header_html();
    [$key,$me,$players,$err] = ebs_require_player();
    if ($err !== '' || $key === null || !is_array($me)) { ebs_error_page('Error', $err ?: '로그인 정보가 없습니다.'); return; }
    $pname=(string)($me['name'] ?? $key); $pass=ebs_param('pass', ebs_cookie_value('pass',''));
    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>투기장</title></head>';
    echo '<body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="margin:0;font-size:13px;" oncontextmenu="return false;"><center>';
    echo '<table border="0" width="95%" cellspacing="1" cellpadding="5" bgcolor="'.ebs_h(ebs_v('TABLE_BORDER')).'">';
    echo '<tr><td colspan="5" align="center" bgcolor="#ff3300" style="color:#000000;font-size:24px;"><b>투기장</b></td></tr>';
    if ($message !== '') echo '<tr><td colspan="5" align="center" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'">'.$message.'</td></tr>';
    echo '<tr bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'"><td>도전</td><td>파일럿</td><td>기체</td><td>Lv</td><td>국가</td></tr>';
    $shown=0;
    foreach ($players as $name=>$p) {
        if (!is_array($p)) continue;
        $name=(string)($p['name'] ?? $name); if ($name===$pname) continue;
        if ($shown++ >= 40) break;
        echo '<tr bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'"><td align="center"><form action="'.ebs_h(basename(__FILE__)).'" method="POST" target="Sub"><input type="hidden" name="cmd" value="BATTLE"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'"><input type="hidden" name="vsname" value="'.ebs_h($name).'"><input type="submit" value="전투" '.ebs_v('STYLE_B1').'></form></td>';
        echo '<td><img src="'.ebs_h(ebs_v('IMG_FOLDER2')).'/'.ebs_h((string)($p['icon'] ?? '1')).'.gif" width="32" height="32"> '.ebs_h($name).'</td><td>'.ebs_h((string)($p['msname'] ?? '')).'</td><td align="right">'.(int)($p['level'] ?? 1).'</td><td>'.ebs_h((string)($p['kuni'] ?? '')).'</td></tr>';
    }
    if ($shown===0) echo '<tr><td colspan="5" align="center" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'">대전 상대가 없습니다.</td></tr>';
    echo '</table></center></body></html>';
}
function ebs_tougi_battle(): void {
    $vsname = ebs_param('vsname','');
    if ($vsname === '') { ebs_tougi_list('대전 상대를 선택하세요.'); return; }
    // 사용자 간 전투 저장 로직은 ebs_sub4.php의 BATTLE2와 동일 라우트를 재사용한다.
    $GLOBALS['EBS_FORCE_CMD'] = 'BATTLE2';
    require __DIR__ . '/ebs_sub4.php';
    return;
}
function ebs_BATTLE(): void { ebs_tougi_battle(); }
function ebs_SYUSEI(): void { ebs_tougi_list(); }
function ebs_TOP(): void { ebs_tougi_list(); }
$map = ['BATTLE'=>'ebs_BATTLE','SYUSEI'=>'ebs_SYUSEI','TOP'=>'ebs_TOP'];
ebs_dispatch($map, 'ebs_TOP');
?>
