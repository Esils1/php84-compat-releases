<?php
declare(strict_types=1);
require_once __DIR__ . '/lib_ebs.php';
/**
 * 원본 legacy 파일: ebs_sub6.php
 * PHP 8.4 파일당 1:1 대응 변환 파일.
 * 원본 주석은 PHP // 주석으로 보존하고, 기존 실행 의존은 제거하고 PHP 8.4 파일 기반으로 동작시킨다.
 * 유지보수 시 원본 sub 이름과 아래 ebs_함수명을 대조한다.
 */
// 등록내용확인화면생성루틴

function ebs_ENTRY2(): void {
    ebs_header_html();
    ebs_clear_login_cookie();
    if (!headers_sent()) { header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0'); header('Pragma: no-cache'); }
    $GLOBALS['EBS_SUPPRESS_SUB1_DISPATCH'] = true;
    require_once __DIR__ . '/ebs_sub1.php';
    unset($GLOBALS['EBS_SUPPRESS_SUB1_DISPATCH']);
    // 원본 ENTRY2: 신규 등록 입력 폼. file 조회/삭제 부분은 PHP JSON 파일 기반 저장소로 대체한다.
    ebs_HEADER();
    $styleL = ebs_v('STYLE_L');
    $styleB = ebs_v('STYLE_B1');
    $iconIds = ebs_existing_icon_ids(); if (!$iconIds) $iconIds = ['1'];
    $colors = ['#FFFFFF','#FF0000','#00FF00','#0000FF','#FFFF00','#FF00FF','#00FFFF','#FF9900','#9999FF','#99FF99','#FF9999','#CCCCCC'];
    echo '<script language="JavaScript">
';
    echo 'function changeImg(){num=document.entry.imgSelect.value;document.msImg.src="'.ebs_h(ebs_v('IMG_FOLDER2')).'/"+num+".gif";}
';
    echo 'function checkRiyou(){if(document.entry.pname.value==""){window.alert("플레이어 이름을 입력해주세요");return false;}else if(document.entry.msname.value==""){window.alert("기체명을 입력해주세요");return false;}else if(document.entry.pass.value==""){window.alert("패스워드를 입력해 주세요");return false;}else if(document.entry.pname.value.match("[\\"&! =.,<>]")!=null){window.alert("기호나 스페이스는 사용할 수 없습니다");return false;}else if(document.entry.msname.value.match("[\\"&! =.,<>]")!=null){window.alert("기호나 스페이스는 사용할 수 없습니다");return false;}else if(document.entry.pass.value.match("[\\"&! =.,<>]")!=null){window.alert("기호나 스페이스는 사용할 수 없습니다");return false;}else{return confirm("등록할까요?");}}
';
    echo '</script>';
    echo '<style type="text/css">.td1{text-align:center;background-color:'.ebs_h(ebs_v('TABLE_COLOR2')).';font-weight:bold;font-size:16px;}</style>';
    echo '<table width="100%" height="100%"><tr><td align="center">';
    echo '<div align="center" style="font-size:55px;color:#dcdcdc;filter:alpha(opacity=100,finishopacity=0,style=2);height:60px;background-color:#202020;"><b>등록확인</b></div>';
    echo '</td></tr><tr><td align="center">';
    echo '<form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST" name="entry" autocomplete="off">';
    echo '<input type="hidden" name="cmd" value="KAKUNIN">';
    echo '<img src="'.ebs_h(ebs_v('IMG_FOLDER2')).'/1.gif" name="msImg">';
    echo '<table cellspacing="1" style="font-size:10pt;" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'">';
    echo '<tr><td class="td1">파일럿 이름</td><td><input type="text" name="pname" size="30" maxlength="15" '.$styleL.'> <font style="font-size:12px;">파일럿이름과 기체이름은 마음대로 붙여주세요</font></td></tr>';
    echo '<tr><td class="td1">기체명</td><td><input type="text" name="msname" size="30" maxlength="20" '.$styleL.'></td></tr>';
    echo '<tr><td class="td1">패스워드</td><td><input type="password" maxlength="8" name="pass" size="15" '.$styleL.'> <font style="font-size:12px;">패스워드는 8자까지</font></td></tr>';
    echo '<tr><td class="td1">아이콘</td><td><select name="imgSelect" '.$styleL.' onChange="changeImg()">';
    foreach ($iconIds as $i) echo '<option value="'.ebs_h((string)$i).'">아이콘 No.'.ebs_h((string)$i)."
";
    echo '</select></td></tr>';
    echo '<tr><td class="td1">성격</td><td><select name="chara" '.$styleL.'><option value="0">드셈<option value="1">소극<option value="2">보통<option value="3">격정<option value="4">냉정<option value="5">냉혹</select></td></tr>';
    echo '<tr><td class="td1">무기</td><td><select name="w" '.$styleL.'>';
    $weaponTable = ebs_weapon_table();
    $defaultWeapon = ebs_default_weapon_id();
    foreach ($weaponTable as $wid=>$wrow) {
        $wname = (string)($wrow[0] ?? $wid);
        echo '<option value="'.ebs_h((string)$wid).'"'.(((string)$wid === $defaultWeapon) ? ' selected' : '').'>'.ebs_h($wname);
    }
    if (!$weaponTable) echo '<option value="0">빔샤벨';
    echo '</select></td></tr><tr><td class="td1">색</td><td>';
    foreach ($colors as $idx=>$c) { echo '<input type="radio" name="cl" value="'.$c.'"'.($idx===0?' checked':'').'><font color="'.$c.'">■</font>'; if (($idx+1)%10===0) echo '<br>'; }
    echo '</td></tr><tr><td class="td1">국적</td><td><select size="1" name="kuni" '.$styleL.'>';
    echo '<option value="">'.ebs_h(ebs_v('NONE_NATIONALITY')).'</select></td></tr>';
    echo '<tr><td colspan="2" align="center"><input type="submit" value="등록" '.$styleB.' onClick="return checkRiyou()"> <input type="reset" value="리셋" '.$styleB.'></td></tr>';
    echo '</table></form></td></tr></table>'; ebs_FOOTER(); echo '</body></html>';
}

function ebs_KAKUNIN2(): void {
    ebs_header_html();
    $GLOBALS['EBS_SUPPRESS_SUB1_DISPATCH'] = true;
    require_once __DIR__ . '/ebs_sub1.php';
    unset($GLOBALS['EBS_SUPPRESS_SUB1_DISPATCH']);
    // 원본 KAKUNIN2: 신규 등록 내용 확인 화면. FORM 해시를 PHP POST/GET 값으로 대체한다.
    $rawPname = ebs_param('pname');
    $rawPass = ebs_param('pass');
    $pname = ebs_clean_registration_name($rawPname);
    $msname = ebs_param('msname');
    $pass = ebs_clean_registration_password($rawPass);
    $kuni = ebs_param('kuni');
    $img = ebs_param('imgSelect', '1');
    $w = ebs_param('w', '0');
    $chara = ebs_param('chara', '0');
    $cl = ebs_param('cl', '#FFFFFF');
    $b = ebs_param('b', '');
    if ($pname === '' || $msname === '' || $pass === '') { ebs_error_page('공백이 있거나 사용할 수 없는 문자가 포함되어 있습니다', '파일럿 이름/패스워드는 따옴표, 공백, 특수문자를 사용할 수 없습니다.'); return; }
    if (ebs_strlen($pname) >= 30 || ebs_strlen($msname) >= 30) { ebs_error_page('글자수가 너무 깁니다'); return; }
    if (ebs_player_exists($pname)) { ebs_error_page('같은 이름이 이미 등록되어 있습니다', '다른 이름으로 등록해주세요'); return; }
    ebs_HEADER();
    echo '<style type="text/css">.td1{text-align:center;background-color:'.ebs_h(ebs_v('TABLE_COLOR2')).';font-weight:bold;font-size:16px;}</style>';
    echo '<script language="JavaScript">function checkEntry(){return confirm("등록명과 패스워드는 기억해 두셨나요?");}</script>';
    echo '<table width="100%" height="100%"><tr><td align="center"><div align="center" style="font-size:55px;color:#dcdcdc;filter:alpha(opacity=100,finishopacity=0,style=2);height:60px;background-color:#202020;"><b>신규등록</b></div></td></tr><tr><td align="center">';
    echo '<table cellspacing="1" style="font-size:10pt;" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'"><tr><td class="td1">이름</td><td>'.ebs_h($pname).'<font style="font-size:12px;">(잊지 않도록 주의하세요)</font></td></tr>';
    echo '<tr><td class="td1">당신의 패스워드</td><td>'.ebs_h($pass).'<font style="font-size:12px;">(잊지 않도록 주의하세요)</font></td></tr>';
    echo '<tr><td class="td1">국적</td><td>'.ebs_h($kuni).'</td></tr>';
    echo '<tr><td class="td1">아이콘</td><td><img src="'.ebs_h(ebs_v('IMG_FOLDER2')).'/'.ebs_h($img).'.gif"><font color="'.ebs_h($cl).'">'.ebs_h($msname).'</font></td></tr></table>';
    echo '<form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST" target="_top">';
    foreach (['cmd'=>'RESIST','pname'=>$pname,'msname'=>$msname,'msImg'=>$img,'pass'=>$pass,'kuni'=>$kuni,'w'=>$w,'chara'=>$chara,'cl'=>$cl,'b'=>$b] as $k=>$v) echo '<input type="hidden" name="'.ebs_h($k).'" value="'.ebs_h($v).'">';
    echo '<p align="center"><input type="submit" value="등록" '.ebs_v('STYLE_B1').' onClick="return checkEntry()"></form>';
    echo '<form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'?ENTRY" method="POST"><input type="submit" value="다시작성" '.ebs_v('STYLE_B1').'></form>';
    echo '</td></tr></table>'; ebs_FOOTER(); echo '</body></html>';
}

function ebs_RESIST2(): void {
    ebs_header_html();
    // 원본 RESIST2: file 플레이어 등록. PHP에서는 data/user/*.json에 저장하고 유저 로그는 user/*.json에 기록한다.
    $pname = ebs_clean_registration_name(ebs_param('pname'));
    $pass = ebs_clean_registration_password(ebs_param('pass'));
    if ($pname === '' || $pass === '') { ebs_error_page('공백이 있거나 사용할 수 없는 문자가 포함되어 있습니다', '파일럿 이름/패스워드는 따옴표, 공백, 특수문자를 사용할 수 없습니다.'); return; }
    if (ebs_player_exists($pname)) { ebs_error_page('같은 이름이 이미 등록되어 있습니다', '다른 이름으로 등록해주세요'); return; }
    $form = $_POST + $_GET;
    $form['pname'] = $pname;
    $form['pass'] = $pass;
    if (!ebs_add_player($form)) { ebs_error_page('등록 저장 실패'); return; }
    ebs_set_login_cookie($pname, $pass);
    ebs_user_event_log('newentry', ['pname' => $pname]);
    $loc = ebs_v('MAIN_SCRIPT');
    header('Location: '.$loc);
    echo '<html><body><a href="'.ebs_h(ebs_v('MAIN_SCRIPT')).'">등록완료</a></body></html>';
}

function ebs_DELETE4(): void {
    ebs_header_html();
    $GLOBALS['EBS_SUPPRESS_SUB1_DISPATCH'] = true;
    require_once __DIR__ . '/ebs_sub1.php';
    unset($GLOBALS['EBS_SUPPRESS_SUB1_DISPATCH']);
    // 원본 DELETE4: 등록 데이터 삭제 입력 화면. 쿠키 파싱은 PHP $_COOKIE 처리로 대체한다.
    ebs_HEADER();
    echo '<script language="JavaScript">
function checkRiyou(){
 if(document.del.pname.value==""){window.alert("ID를 입력해주세요");return false;}
 if(document.del.pass.value==""){window.alert("PASS를 입력해주세요");return false;}
 return confirm("등록을 말소합니다");
}
</script>';
    echo '<table width="100%" height="100%"><tr><td align="center">';
    echo '<table bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" border="0" style="font-size:12px;">';
    echo '<tr><td colspan="2" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'" align="center"><img src="'.ebs_h(ebs_v('IMG_FOLDER1')).'/w.gif"></td></tr>';
    echo '<tr><td colspan="2" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'">등록데이터를 삭제합니다<br>삭제한 데이터는 복구할 수 없습니다<br><br></td></tr>';
    echo '<tr><td align="right" style="height:21px;color:'.ebs_h(ebs_v('FONT_COLOR')).';font-size:16px;">파일럿 이름<br>패스워드</td>';
    echo '<td style="height:21px;color:'.ebs_h(ebs_v('FONT_COLOR')).';font-size:16px;">';
    echo '<form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST" target="_top" name="del" onSubmit="return checkRiyou()">';
    echo '<input type="hidden" name="cmd" value="DELETE">';
    echo '<input type="text" size="20" name="pname" value="'.ebs_h(ebs_cookie_value('pname')).'" '.ebs_v('STYLE_L').'><br>';
    echo '<input type="password" size="15" name="pass" value="'.ebs_h(ebs_cookie_value('pass')).'" '.ebs_v('STYLE_L').'>';
    echo '</td></tr><tr><td colspan="2" align="center"><br><br>삭제할까요?<br><input type="submit" value="삭제" '.ebs_v('STYLE_B1').'></td></tr>';
    echo '</form></table></td></tr></table></body></html>';
}

function ebs_DELETE3(): void {
    ebs_header_html();
    // 원본 DELETE3: file 플레이어 삭제. PHP에서는 user/*.json 개별 파일을 제거하고 EB 쿠키를 만료한다.
    $pname = ebs_param('pname');
    $pass = ebs_param('pass');
    if ($pname === '' || $pass === '') { ebs_error_page('Error', 'ID 또는 PASS를 입력해주세요'); return; }
    $players = ebs_players_load();
    $key = ebs_find_player_key($pname, $players);
    if ($key === null || !isset($players[$key]) || !is_array($players[$key])) { ebs_error_page('Error', '등록 데이터를 찾을 수 없습니다'); return; }
    if (!ebs_password_matches($players[$key], $pass)) { ebs_error_page('Error', '패스워드가 틀립니다'); return; }
    ebs_player_delete_one((string)($players[$key]['name'] ?? $key));
    unset($players[$key]);
    ebs_user_event_log('delete', ['pname' => $pname]);
    ebs_clear_login_cookie();
    echo '<html><body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'"><table width="100%" height="100%"><tr><td align="center">등록 데이터 삭제가 완료되었습니다.<br><a href="'.ebs_h(ebs_v('MAIN_SCRIPT')).'">TOP</a></td></tr></table></body></html>';
}

function ebs_EXPORT2(): void {
    ebs_header_html();
    if (!ebs_satellite_guard()) return;
    $GLOBALS['EBS_SUPPRESS_SUB1_DISPATCH'] = true;
    require_once __DIR__ . '/ebs_sub1.php';
    unset($GLOBALS['EBS_SUPPRESS_SUB1_DISPATCH']);
    // 원본 EXPORT2: 이동 데이터 추출. PHP에서는 user/*.json의 현재 사용자 데이터를 JSON 기반 문자열로 내보낸다.
    $pname = ebs_param('pname');
    $pass = ebs_param('pass');
    if ($pname === '' && $pass === '') {
        ebs_HEADER();
        echo '<script language="JavaScript">function checkRiyou(){if(document.del.pname.value==""){window.alert("ID를 입력해주세요");return false;}if(document.del.pass.value==""){window.alert("PASS를 입력해주세요");return false;}return confirm("OK를 누르면 이동데이터 추출을 시작합니다. 괜찮습니까?");}</script>';
        echo '<table width="100%" height="100%"><tr><td align="center"><table bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" border="0" style="font-size:12px;">';
        echo '<tr><td colspan="2" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'" align="center"><img src="'.ebs_h(ebs_v('IMG_FOLDER1')).'/w.gif"></td></tr>';
        echo '<tr><td colspan="2" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" align="center"><b style="font-size:20px;">Data Export Utility</b><br>다른 서버로 데이터를 옮길 때 사용하는 이동데이터를 추출합니다.<br><br></td></tr>';
        echo '<tr><td align="right" style="height:21px;color:'.ebs_h(ebs_v('FONT_COLOR')).';font-size:16px;">파일럿 이름<br>패스워드</td><td style="height:21px;color:'.ebs_h(ebs_v('FONT_COLOR')).';font-size:16px;">';
        echo '<form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST" target="_top" name="del" onSubmit="return checkRiyou()"><input type="hidden" name="cmd" value="EXPORT">';
        echo '<input type="text" size="20" name="pname" value="'.ebs_h(ebs_cookie_value('pname')).'" '.ebs_v('STYLE_L').'><br><input type="password" size="15" name="pass" value="'.ebs_h(ebs_cookie_value('pass')).'" '.ebs_v('STYLE_L').'></td></tr>';
        echo '<tr><td colspan="2" align="center"><br><input type="submit" value="Export" '.ebs_v('STYLE_B1').'></td></tr></form></table></td></tr></table></body></html>';
        return;
    }
    $players = ebs_players_load();
    $key = ebs_find_player_key($pname, $players);
    if ($key === null || !isset($players[$key]) || !is_array($players[$key])) { ebs_error_page('Error', '등록 데이터를 찾을 수 없습니다'); return; }
    if (!ebs_password_matches($players[$key], $pass)) { ebs_error_page('Error', '패스워드가 틀립니다'); return; }
    $payload = base64_encode(json_encode(['time'=>time(),'player'=>$players[$key]], JSON_UNESCAPED_UNICODE));
    ebs_HEADER();
    echo '<table width="100%" height="100%"><tr><td align="center"><table bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" border="0" style="font-size:12px;">';
    echo '<tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'" align="center"><img src="'.ebs_h(ebs_v('IMG_FOLDER1')).'/w.gif"></td></tr>';
    echo '<tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" align="center"><b style="font-size:20px;">Data Export Utility</b><br>아래 데이터를 보관하세요.</td></tr>';
    echo '<tr><td><textarea rows="5" cols="70">'.ebs_h($payload).'</textarea></td></tr></table></td></tr></table></body></html>';
}

function ebs_INPORT2(): void {
    ebs_header_html();
    if (!ebs_satellite_guard()) return;
    $GLOBALS['EBS_SUPPRESS_SUB1_DISPATCH'] = true;
    require_once __DIR__ . '/ebs_sub1.php';
    unset($GLOBALS['EBS_SUPPRESS_SUB1_DISPATCH']);
    // 원본 INPORT2: 이동 데이터 복원 입력 화면. PHP에서는 EXPORT2의 base64 JSON 문자열을 받는다.
    ebs_HEADER();
    echo '<script language="JavaScript">function checkRiyou(){if(document.del.pname.value==""){window.alert("ID를 입력해주세요");return false;}if(document.del.pass.value==""){window.alert("PASS를 입력해주세요");return false;}if(document.del.indata.value==""){window.alert("이동데이터를 입력해주세요");return false;}if(document.del.MsName.value==""){window.alert("기체명을 입력해주세요");return false;}return confirm("이동데이터 복원을 시작합니다\\n괜찮습니까?");}</script>';
    echo '<table width="100%" height="100%"><tr><td align="center"><table bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" border="0" style="font-size:12px;">';
    echo '<tr><td colspan="2" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'" align="center"><img src="'.ebs_h(ebs_v('IMG_FOLDER1')).'/w.gif"></td></tr>';
    echo '<tr><td colspan="2" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" align="center"><b style="font-size:20px;">Data Inport Utility</b><br>다른 서버에서 추출한 이동데이터를 입력합니다.<br><br></td></tr>';
    echo '<form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST" target="_top" name="del" onSubmit="return checkRiyou()"><input type="hidden" name="cmd" value="INPORT5">';
    echo '<tr><td align="right" style="height:21px;color:'.ebs_h(ebs_v('FONT_COLOR')).';font-size:16px;" valign="top">파일럿 이름<br>패스워드<br><br>이동데이터<br>기체명</td><td style="height:21px;color:'.ebs_h(ebs_v('FONT_COLOR')).';font-size:16px;">';
    echo '<input type="text" size="20" name="pname" '.ebs_v('STYLE_L').'><br><input type="password" size="15" name="pass" '.ebs_v('STYLE_L').'><br><textarea rows="5" cols="50" name="indata"></textarea><br><input type="text" name="MsName" size="30" maxlength="15" '.ebs_v('STYLE_L').'></td></tr>';
    echo '<tr><td colspan="2" align="center"><input type="submit" value="이동" '.ebs_v('STYLE_B1').'></td></tr></form></table></td></tr></table></body></html>';
}

function ebs_INPORT3(): void {
    ebs_header_html();
    if (!ebs_satellite_guard()) return;
    // 원본 INPORT3: 이동 데이터 복원 저장. PHP에서는 EXPORT2 payload를 user/*.json에 저장한다.
    $pname = ebs_param('pname');
    $pass = ebs_param('pass');
    $indata = ebs_param('indata');
    $decoded = ebs_json_decode_array((string)base64_decode($indata, true));
    if ($pname === '' || $pass === '' || !is_array($decoded) || !isset($decoded['player']) || !is_array($decoded['player'])) { ebs_error_page('Error', '이동데이터가 올바르지 않습니다'); return; }
    $players = ebs_players_load();
    if (ebs_find_player_key($pname, $players) !== null) { ebs_error_page('Error', '이미 같은 이름이 존재합니다'); return; }
    $player = $decoded['player'];
    $player['name'] = $pname;
    $player['pass'] = crypt($pass, 'eb');
    $player['msname'] = ebs_param('MsName', (string)($player['msname'] ?? $pname));
    ebs_player_raw_set($player, 2, (string)$player['pass']);
    ebs_player_raw_set($player, 3, (string)$player['msname']);
    $player['recovery_at'] = (string)time();
    unset($player['online_seen'], $player['last_action_time']);
    ebs_player_sync_common($player);
    $players[$pname] = $player;
    ebs_players_save($players);
    ebs_user_event_log('import', ['pname' => $pname]);
    ebs_set_login_cookie($pname, $pass);
    echo '<html><body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'"><table width="100%" height="100%"><tr><td align="center">이동 데이터 복원이 완료되었습니다.<br><a href="'.ebs_h(ebs_v('MAIN_SCRIPT')).'">TOP</a></td></tr></table></body></html>';
}

function ebs_top_level_output(): void {
    ebs_header_html();
    echo '	</select></td></tr>
	<tr><td class=td1>성격</td><td><select name=chara '.ebs_v('STYLE_L').'>
	<option value=0>드셈<br><option value=1>소극<br><option value=2>보통<br>
	<option value=3>격정<br><option value=4>냉정<br><option value=5>냉혹</select></td></tr>
	<tr><td class=td1>무기</td><td><select name=w '.ebs_v('STYLE_L').'>';
    echo '</select></tr><tr><td class=td1>색</td>';
    echo '<td><input type=radio name=cl value=#FFFFFF checked><font color=#111111>■</font>
';
    echo '<input type="radio" name="cl" value='.ebs_v('_').'><font color='.ebs_v('_').'>■</font>
';
    echo '</td></tr><tr><td class=td1>국적<td>
';
    echo '<select size=1 name="kuni" '.ebs_v('STYLE_L').'>
';
    echo '<option value='.ebs_v('key').'>'.ebs_v('key').'
';
    echo '<option value="">'.ebs_v('NONE_NATIONALITY');
    echo '		</select></td></tr>
			<tr><td colspan=2 align="center"> 
			<input type=submit value=등록 '.ebs_v('STYLE_B1').' onClick="return checkRiyou()">
			<input type=reset value=리셋 '.ebs_v('STYLE_B1').'>
		    </td></tr></table></td></tr><tr><td align=center>';
    echo '</td></tr></form></body>';
}

function ebs_INPORT4(): void {
    // 원본 DECODE/INPORT4: 이동데이터 복호화 확인 처리. PHP판은 INPORT3 처리 화면으로 연결한다.
    ebs_INPORT3();
}

$map = [
    'ENTRY2' => 'ebs_ENTRY2',
    'KAKUNIN2' => 'ebs_KAKUNIN2',
    'RESIST2' => 'ebs_RESIST2',
    'DELETE4' => 'ebs_DELETE4',
    'DELETE3' => 'ebs_DELETE3',
    'EXPORT2' => 'ebs_EXPORT2',
    'INPORT2' => 'ebs_INPORT2',
    'INPORT3' => 'ebs_INPORT3',
    'INPORT4' => 'ebs_INPORT4',
    '__TOP__' => 'ebs_top_level_output',
];
ebs_dispatch($map, 'ebs_ENTRY2');
?>
