<?php
declare(strict_types=1);
require_once __DIR__ . '/lib_ebs.php';
/** 원본 legacy 파일: dungeons_sub1.php - 지하 감옥 전투 보조 PHP 저장 방식 구현. */
function ebs_BATTLE(): void {
    $floor = max(1, (int)ebs_param('floor','1'));
    $mon = ebs_pick_monster('log/_dungeon.data', $floor, ebs_param('mon',''));
    if (!$mon) { ebs_feature_screen('어둠의동굴', '몬스터 데이터가 없습니다.'); return; }
    ebs_run_npc_battle('어둠의동굴', $mon, 'dungeon_sub_battle');
}
function ebs_SYUSEI(): void { ebs_MON_CHECK(); }
function ebs_MON_CHECK(): void {
    ebs_header_html();
    $mons = ebs_monsters_by_floor('log/_dungeon.data', max(1,(int)ebs_param('floor','1')));
    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>몬스터 확인</title></head><body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="font-size:13px;"><center><table border="1" cellspacing="0" cellpadding="4" bordercolor="'.ebs_h(ebs_v('TABLE_BORDER')).'" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'">';
    echo '<tr><td colspan="4" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'" align="center"><b>몬스터 확인</b></td></tr><tr><td>ID</td><td>이름</td><td>HP</td><td>보상</td></tr>';
    foreach ($mons as $m) echo '<tr><td>'.ebs_h((string)$m['id']).'</td><td>'.ebs_h((string)$m['name']).'</td><td align="right">'.(int)$m['hp'].'</td><td>EXP '.(int)$m['exp'].' / $'.(int)$m['money'].'</td></tr>';
    if (!$mons) echo '<tr><td colspan="4" align="center">몬스터 데이터가 없습니다.</td></tr>';
    echo '</table></center></body></html>';
}
function ebs_top_level_output(): void { ebs_BATTLE(); }
$map = ['BATTLE'=>'ebs_BATTLE','SYUSEI'=>'ebs_SYUSEI','MON_CHECK'=>'ebs_MON_CHECK','__TOP__'=>'ebs_top_level_output'];
ebs_dispatch($map, 'ebs_BATTLE');
?>
