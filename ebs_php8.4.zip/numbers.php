<?php
declare(strict_types=1);
require_once __DIR__ . '/lib_ebs.php';

function ebs_numbers_data(): array {
    $d = ebs_json_load('numbers_data');
    if (!$d) $d = ['jackpot'=>100000,'history'=>[]];
    if (!isset($d['history']) || !is_array($d['history'])) $d['history'] = [];
    $d['jackpot'] = max(100000, (int)($d['jackpot'] ?? 100000));
    return $d;
}
function ebs_numbers_save(array $d): bool { return ebs_json_save('numbers_data', $d); }
function ebs_numbers_pick(): string { return str_pad((string)random_int(0, 999), 3, '0', STR_PAD_LEFT); }
function ebs_numbers_input(): string {
    $direct = preg_replace('/\D/', '', ebs_param('number', '')) ?? '';
    if ($direct !== '') return str_pad(substr($direct, 0, 3), 3, '0', STR_PAD_LEFT);
    $n = '';
    for ($i=1; $i<=3; $i++) $n .= (string)max(0, min(9, (int)ebs_param('num'.$i, '0')));
    return $n;
}
function ebs_NUMBERS2(): void {
    ebs_header_html();
    ebs_record_post('numbers.php::NUMBERS2');
    $pname = ebs_clean_login_value(ebs_param('pname', ebs_cookie_value('pname', '')));
    $pass = ebs_param('pass', ebs_cookie_value('pass', ''));
    $d = ebs_numbers_data();
    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>넘버즈</title></head>';
    echo '<body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="font-size:13px;margin:0;"><center>';
    echo '<table border="1" bordercolor="'.ebs_h(ebs_v('TABLE_BORDER')).'" cellspacing="0" cellpadding="6" style="font-size:13px;">';
    echo '<form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST" target="Sub">';
    echo '<input type="hidden" name="cmd" value="NUMBERS3"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'">';
    echo '<tr><td align="center" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'"><b>넘버즈 3</b></td></tr>';
    echo '<tr><td align="center" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'">현재 상금 <span style="color:red;font-size:18px;">$'.number_format((int)$d['jackpot']).'</span><br>참가비 1,000 Gold</td></tr>';
    echo '<tr><td align="center" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'">';
    for ($i=1; $i<=3; $i++) echo '<select name="num'.$i.'">'.implode('', array_map(static function ($n) { return '<option value="'.$n.'">'.$n.'</option>'; }, range(0,9))).'</select> ';
    echo '<input type="submit" value="구입" '.ebs_v('STYLE_B1').'></td></tr></form>';
    echo '<tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'"><b>최근 결과</b><br>';
    $hist = array_slice(array_reverse($d['history']), 0, 10);
    if (!$hist) echo '기록 없음';
    foreach ($hist as $h) if (is_array($h)) echo ebs_h((string)($h['time'] ?? '')).' / '.ebs_h((string)($h['player'] ?? '')).' 선택 '.ebs_h((string)($h['pick'] ?? '')).' / 당첨 '.ebs_h((string)($h['win'] ?? '')).' / '.ebs_h((string)($h['result'] ?? '')).'<br>';
    echo '</td></tr><tr><td align="center"><form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST" target="Main"><input type="hidden" name="cmd" value="MAIN_FRAME"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'"><input type="submit" value="돌아가기" '.ebs_v('STYLE_B1').'></form></td></tr>';
    echo '</table></center></body></html>';
}
function ebs_NUMBERS4(): void {
    ebs_header_html();
    ebs_record_post('numbers.php::NUMBERS4');
    [$key, $me, $players, $err] = ebs_require_player();
    if ($err !== '' || $key === null || !is_array($me)) { ebs_error_page('Numbers', $err ?: '로그인 정보가 없습니다.'); return; }
    $cost = 1000;
    $money = (int)($me['money'] ?? 0);
    $pick = ebs_numbers_input();
    $d = ebs_numbers_data();
    $win = ebs_numbers_pick();
    $result = '실패';
    $payout = 0;
    if ($money < $cost) {
        $result = '자금부족';
    } else {
        $money -= $cost;
        if ($pick === $win) { $payout = (int)$d['jackpot']; $money += $payout; $d['jackpot'] = 100000; $result = '당첨'; }
        else { $d['jackpot'] = (int)$d['jackpot'] + $cost; }
        $me['money'] = $money;
        if (!isset($me['event_log']) || !is_array($me['event_log'])) $me['event_log'] = [];
        $me['event_log'][] = ['type'=>'numbers','pick'=>$pick,'win'=>$win,'result'=>$result,'payout'=>$payout,'time'=>date('YmdHis')];
        if (count($me['event_log']) > 80) $me['event_log'] = array_slice($me['event_log'], -80);
        ebs_player_save_one((string)($me['name'] ?? $key), $me);
    }
    $d['history'][] = ['time'=>date('YmdHis'),'player'=>(string)($me['name'] ?? $key),'pick'=>$pick,'win'=>$win,'result'=>$result,'payout'=>$payout];
    if (count($d['history']) > 100) $d['history'] = array_slice($d['history'], -100);
    ebs_numbers_save($d);
    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>넘버즈 결과</title></head><body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="font-size:13px;margin:0;"><center>';
    echo '<table border="1" cellpadding="6" cellspacing="0" bordercolor="'.ebs_h(ebs_v('TABLE_BORDER')).'"><tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'" align="center"><b>넘버즈 결과</b></td></tr>';
    echo '<tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" align="center">선택번호 '.$pick.'<br>당첨번호 '.$win.'<br>결과 '.ebs_h($result).'<br>상금 +'.number_format($payout).' Gold</td></tr>';
    echo '<tr><td align="center"><form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST" target="Sub"><input type="hidden" name="cmd" value="NUMBERS"><input type="hidden" name="pname" value="'.ebs_h((string)($me['name'] ?? $key)).'"><input type="hidden" name="pass" value="'.ebs_h(ebs_param('pass', ebs_cookie_value('pass',''))).'"><input type="submit" value="돌아가기" '.ebs_v('STYLE_B1').'></form></td></tr>';
    echo '</table></center></body></html>';
}
$map = ['NUMBERS'=>'ebs_NUMBERS2','NUMBERS2'=>'ebs_NUMBERS2','NUMBERS3'=>'ebs_NUMBERS4','NUMBERS4'=>'ebs_NUMBERS4'];
ebs_dispatch($map, 'ebs_NUMBERS2');
?>
