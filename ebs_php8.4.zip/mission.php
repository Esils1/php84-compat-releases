<?php
declare(strict_types=1);
require_once __DIR__ . '/lib_ebs.php';
/**
 * 원본 legacy 파일: mission.php
 * PHP 8.4 파일 기반 요새/전략 전투 화면.
 */
function ebs_mission_targets(): array {
    $countries = ebs_country_records();
    $rows = [];
    foreach ($countries as $c) {
        $name = (string)$c['name'];
        $parts = preg_split('/!/', (string)($c['fortress'] ?? '')) ?: [];
        $hp = max(1000, (int)($parts[0] ?? ebs_v('YOUSAI_HP','600000')));
        $rows[$name] = ['name'=>$name,'color'=>(string)$c['color'],'money'=>(int)($c['money'] ?? 0),'hp'=>$hp,'icon'=>(string)($c['icon'] ?? '2000')];
    }
    if (!$rows) $rows['무소속 요새'] = ['name'=>'무소속 요새','color'=>'#808080','money'=>0,'hp'=>50000,'icon'=>'2000'];
    return $rows;
}
function ebs_mission_screen(string $message=''): void {
    ebs_header_html();
    [$key,$me,$players,$err] = ebs_require_player();
    if ($err !== '' || $key === null || !is_array($me)) { ebs_error_page('Error', $err ?: '로그인 정보가 없습니다.'); return; }
    if (ebs_param('mission_action') === 'attack') { ebs_mission_battle(); return; }
    $pname=(string)($me['name'] ?? $key); $pass=ebs_param('pass', ebs_cookie_value('pass',''));
    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>요새전</title></head><body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="margin:0;font-size:13px;" oncontextmenu="return false;"><center>';
    echo '<table border="0" width="95%" cellspacing="1" cellpadding="5" bgcolor="'.ebs_h(ebs_v('TABLE_BORDER')).'">';
    echo '<tr><td colspan="5" align="center" bgcolor="#ff3300" style="color:#000000;font-size:24px;"><b>요새전</b></td></tr>';
    if ($message !== '') echo '<tr><td colspan="5" align="center" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'">'.$message.'</td></tr>';
    echo '<tr bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'"><td>전투</td><td>국가/요새</td><td>HP</td><td>국비</td><td>문장</td></tr>';
    foreach (ebs_mission_targets() as $target=>$c) {
        echo '<tr bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'"><td align="center"><form action="'.ebs_h(basename(__FILE__)).'" method="POST" target="Sub"><input type="hidden" name="cmd" value="BATTLE2"><input type="hidden" name="mission_action" value="attack"><input type="hidden" name="target" value="'.ebs_h($target).'"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'"><input type="submit" value="공격" '.ebs_v('STYLE_B1').'></form></td>';
        echo '<td><span style="color:'.ebs_h((string)$c['color']).';"><b>'.ebs_h((string)$c['name']).'</b></span></td><td align="right">'.(int)$c['hp'].'</td><td align="right">$'.(int)$c['money'].'</td><td><img src="'.ebs_h(ebs_v('IMG_FOLDER2')).'/'.ebs_h((string)$c['icon']).'.gif" width="32" height="32"></td></tr>';
    }
    echo '<tr><td colspan="5" align="center" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'"><form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST" target="Main"><input type="hidden" name="cmd" value="MAIN_FRAME"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'"><input type="submit" value="귀환" '.ebs_v('STYLE_B1').'></form></td></tr>';
    echo '</table></center></body></html>';
}
function ebs_mission_battle(): void {
    $target = ebs_param('target','');
    $targets = ebs_mission_targets();
    if ($target === '' || !isset($targets[$target])) { ebs_mission_screen('공격 대상이 올바르지 않습니다.'); return; }
    $c = $targets[$target];
    $enemy = ['name'=>(string)$c['name'].' 요새','icon'=>(string)$c['icon'],'hp'=>min(200000, max(3000, (int)$c['hp'])),'at'=>35,'de'=>35,'exp'=>200,'money'=>5000,'wexp'=>30];
    ob_start();
    ebs_run_npc_battle('요새전 - '.(string)$c['name'], $enemy, 'mission_battle');
    $html = ob_get_clean();
    if ($html === false) $html = '';
    $log = ebs_json_load('mission_log');
    if (!is_array($log)) $log = [];
    $log[] = ['time'=>date('YmdHis'),'pname'=>ebs_param('pname', ebs_cookie_value('pname','')),'target'=>$target,'type'=>'fortress_attack'];
    if (count($log) > 100) $log = array_slice($log, -100);
    ebs_json_save('mission_log', $log);
    echo $html;
}
function ebs_LOGIN(): void { ebs_mission_screen(); }
function ebs_LOG0(): void { ebs_mission_screen(); }
function ebs_LOGO(): void { ebs_mission_screen(); }
function ebs_TOP(): void { ebs_mission_screen(); }
function ebs_MAIN_FRAME(): void { ebs_mission_screen(); }
function ebs_BATTLE_2(): void { ebs_mission_battle(); }
function ebs_FRAME(): void { ebs_mission_screen(); }
function ebs_LOGIN2(): void { ebs_mission_screen(); }
function ebs_STATUS(): void { ebs_mission_screen(); }
function ebs_BORDER(): void { ebs_mission_screen(); }
function ebs_BATTLE2(): void { ebs_mission_battle(); }
function ebs_BONUS(): void { ebs_mission_screen('보상 처리는 요새전 전투 결과에서 자동 반영됩니다.'); }
function ebs_DOWN(): void { ebs_mission_screen('요새전 결과 처리는 전투 화면에서만 수행됩니다.'); }
function ebs_SYUSEI(): void { ebs_mission_screen(); }
function ebs_top_level_output(): void { ebs_mission_screen(); }
$map = ['LOGIN'=>'ebs_LOGIN','LOG0'=>'ebs_LOG0','LOGO'=>'ebs_LOGO','TOP'=>'ebs_TOP','MAIN_FRAME'=>'ebs_MAIN_FRAME','BATTLE_2'=>'ebs_BATTLE_2','FRAME'=>'ebs_FRAME','LOGIN2'=>'ebs_LOGIN2','STATUS'=>'ebs_STATUS','BORDER'=>'ebs_BORDER','BATTLE2'=>'ebs_BATTLE2','BONUS'=>'ebs_BONUS','DOWN'=>'ebs_DOWN','SYUSEI'=>'ebs_SYUSEI','__TOP__'=>'ebs_top_level_output'];
ebs_dispatch($map, 'ebs_LOGIN');
?>
