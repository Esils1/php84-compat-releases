<?php
declare(strict_types=1);
/**
 * EBS PHP 8.4 설정 파일.
 *
 * 원본 legacy: config.php
 * 변환 원칙:
 * - 서버형 저장소 없이 PHP 파일 저장 구조만 사용한다.
 * - 유저/국가/로그 데이터는 PHP 파일 기반 JSON 저장소를 사용한다.
 * - 깨진 일본어 주석은 제외하고, 원본에서 판독 가능한 한국어 주석은 PHP 주석으로 보존한다.
 * - 설정 의미를 바꾸지 않으며, PHP 출력 파일명만 .php에서 .php로 치환한다.
 */

$GLOBALS['EBS_VARS'] = array_replace($GLOBALS['EBS_VARS'] ?? [], [
    // (0) 관리자의 정보. 공백이면 표시하지 않는다. 태그 사용 가능.
    'OWNER_NAME' => 'Albert',
    'OWNER_EMAIL' => '',
    // 운영자의 아이디를 입력한다.
    'ADMIN' => 'Albert',

    // (1) 관리자용 패스워드. 설치 후 변경 필수.
    'MASTER_PWD' => '1064',

    // (2) 아이콘 No. 0.gif부터 연속된 아이콘 파일의 마지막 번호.
    'ICON' => '985',
    // 문장 아이콘은 1000.gif부터 사용하며 마지막 번호를 지정한다.
    'YMICON' => '1008',

    // (3) 로그 폴더명. PHP 변환본에서는 텍스트 로그를 만들지 않고 JSON 저장소를 우선 사용한다.
    'LOG_FOLDER' => 'log',

    // (4) 각종 로그 파일명. 원본은 확장자 없는 file 이름이지만 PHP에서는 JSON 저장소 이름으로만 참조한다.

    // (5) 이미지 폴더 패스. 마지막에 /를 붙이지 않는다.
    // 원본 legacy의 원격 URL은 설치 경로에 맞지 않으므로 동봉된 로컬 이미지 폴더를 사용한다.
    'IMG_FOLDER1' => './img1',
    'IMG_FOLDER2' => './img2',

    // (6) 링크. 종료 버튼/게시판/무기 이미지 경로.
    'YOUR_HOME' => './',
    'YOUR_BBS' => './board.php',
    'buimg' => './bukiimg',

    // (7) 스크립트를 설치한 디렉토리. PHP에서는 상대 경로로 처리한다.
    'THIS_DIR' => '.',

    // (8) 각종 설정.
    'COOKIE_KEEP' => '1400',      // 쿠키 보존일수 = 삭제 방치 기간.
    'HP_REPAIR2' => '0.5',        // 1초간 HP 회복량. 최대 HP에 대한 %.
    'EN_REPAIR2' => '0.5',        // 1초간 EN 회복량. 최대 EN에 대한 %.
    'HP_REPAIR_Y' => '20',        // 요새의 1초간 HP 회복량.
    'HP_REPAIR' => '30',          // 1초간 HP 회복량.
    'EN_REPAIR' => '1',           // 1초간 EN 회복량.
    'HISTORY_MAX' => '9999',      // 히스토리 표시 건수.
    'UPDATA_MAX' => '9999',       // 업데이트 표시 건수.
    'HISTORY_PAGE' => '10',       // 1페이지 역사 표시 건수.
    'HISTORY2_PAGE' => '1',       // 1페이지 역사 표시 건수.
    'HISTORY3_PAGE' => '2',       // 1페이지 역사 표시 건수.
    'COUNTRY_MAX' => '10',        // 최대 나라 존재 수.
    'ENTRY_MAX' => '1500',        // 최대 등록 수.
    'MAKE_COUNTRY' => '5000000',  // 건국에 필요한 비용.
    'MAKE_TEAM' => '50000',       // 부대 작성에 필요한 비용.
    'YOUSAI_HP' => '600000',      // 건국 시 초기 요새 HP.
    'WEAPON_RANKUP' => '50',      // 무기 랭크업 레벨.
    'WEAPON_LVUP' => '100',       // 무기 레벨업에 필요한 경험치.
    'MAX_WEAPONLV' => '100',      // 무기 레벨 최고치.
    'GET_MONEY' => '10',          // 전투 후 수입.
    'MAX_HP' => '5000000',        // HP 상한.
    'MAX_EN' => '200000',         // EN 상한.
    'hea' => '200000',
    'SATELLITE_FLAG' => '0',      // DataImport/DataExport 허가. 1=허가, 0=불가.
    'POOHLOVE' => '70',           // 푸의 축복을 받을 수 있는 레벨.
    'event' => '0',               // 이벤트 실행 여부.
    'eventco' => ' - ',           // 이벤트 코멘트.
    'adminad' => ' 운영자 : DarkWind // 다양한 이벤트 진행중 // 도우미 추가 ',
    'tip' => ' 렙업하면 [ 특별 - > 스텟찍기 ] 로 가서 스텟 분배하면 댄다 냥!. ',
    'STperLEVEL' => '1',          // 레벨당 보너스 스탯.
    'ST_limit' => '0.5',          // 스탯 제한. 총 스탯 중 각 스탯에 배분 가능한 비율.
    'ST_resetpay' => '0',         // 스탯 초기화 비용. 스탯 1당.

    // (9) 규제 시간. 로그인을 금지할 시간을 배열로 지정한다.
    // PHP 변환본에서는 EBS_ARRAYS['MAINTE_TIME']에서 관리한다.

    // (11) v1.04 추가 파라미터.
    'DIRECT_LINK' => '1',         // 직접 링크 금지. 1=금지, 0=허가. PHP에서는 IE 강제 실행 차단을 사용하지 않는다.
    'UPPER_FRAME' => '380',       // 상부 프레임 폭. 광고가 없으면 220 권장.
    'BANNER_DISPLAY' => '1',      // 광고가 있을 경우 상부 프레임 비표시. 1=비표시, 0=표시.
    'CONFIG_DISPLAY' => '1',      // TOP 하부 프레임에 최대 등록 인수 등 데이터 공개. 1=공개, 0=비공개.
    'SPECIAL_ICON' => '0',        // 일정 조건으로 특수 아이콘 개조. 0=사용 안 함.
    'S_ICON_NUMBER' => '514',     // 특수 아이콘 마지막 번호.
    'NAIRAN_MODE' => '1',         // 내란 커맨드. 1=허가, 0=불허.
    'NT_START' => '1',            // 각성 조건.
    'NT_END' => '1',              // 각성 종료 조건.

    // (12) 코멘트 추가. 태그 사용 가능.
    'COMMENT_1' => 'EBS 교육방송 Open<br>PvP를 전제로 한 게임입니다. PK당했다고 <font color=red>욕설/비방</font><font color=white>을 하지 맙시다.</font>',
    'COMMENT_2' => '',
    'COMMENT_3' => '',

    // 배포 이미지 사용 시 배포처 링크/제작자/저작권 표시.
    'COPYRIGHT_ICON' => '',

    // (13) HTML 커스텀.
    'LINK' => '#707070',           // 링크색.
    'HOVER' => '#dcdcdc',          // 링크에 마우스 커서가 위치했을 때 색.
    'BG_TOP' => '#000000',         // TOP 페이지 배경색.
    'BG_MAIN' => '#000000',        // 통상시 배경색.
    'BG_STATUS' => '#000000',      // 스테이터스 표시부 배경색.
    'FONT_COLOR' => '#ffffff',     // 문자색.
    'TABLE_COLOR1' => '#202020',   // 테이블 표시부 색.
    'TABLE_COLOR2' => '#606060',   // 테이블 헤더/강조 색.
    'TABLE_BORDER' => '#404040',   // 테이블 경계선 색.
    'BG_BUTTON' => '#000000',      // 폼 버튼 배경색.
    'FC_BUTTON' => '#ededed',      // 폼 버튼 글자색.
    'BG_LIST' => '#000000',        // 풀다운 메뉴/텍스트 폼 배경색.
    'FC_LIST' => '#ededed',        // 풀다운 메뉴/텍스트 폼 문자색.

    // (14) 세계관 설정.
    'CUSTOM_NAME' => '개조',
    'NONE_NATIONALITY' => '방랑자',
    'kk_time' => '0.2',            // 참가자 명단 갱신 주기. 분 단위.
    'C_MAX_MEMBER' => '40',        // 한 나라당 최고 인원 수.

    // PHP 변환본 내부 설정. 원본 legacy 출력 링크는 ebs.php로 대응한다.
    'MAIN_SCRIPT' => './ebs.php',
    // 원본 legacy의 SCRIPTNM 변수 대응. PHP에서는 메인 라우터 파일을 사용한다.
    'SCRIPTNM' => './ebs.php',
    'STYLE_B1' => 'style="height:24px; background:#000000;color:#ededed; font-size:15px;"',
    'STYLE_B2' => 'style="height:22px; background:#000000;color:#ededed; font-size:13px;"',
    'STYLE_L' => 'style="height:21px; background:#000000;color:#ededed; font-size:15px;"',
    'VER' => '1.05',
    'DATE' => '',
    'CL_VALUES' => '#ffffff',
    'ENTRYS' => '0',
]);

$GLOBALS['EBS_ARRAYS'] = array_replace($GLOBALS['EBS_ARRAYS'] ?? [], [
    // (9) 규제 시간. 로그인을 금지할 시간 목록.
    'MAINTE_TIME' => [],

    // (10) 선택색. 추가 색상은 반드시 16진수로 입력한다.
    'COLOR' => ['adeaea','00ffff','38b0de','3299cc','007fff','4d4dff','007fff','00ff00','32cd32','70db93','3366ff','99cc32','8fbc8f','6b8e23','a68064','b87333','e47833','ff7f00','e9c2a6','9f9f5f','cfb53b','cfb53b','ffff00','a8a8a8','c0d9d9','cdcdcd','e6e8fa','d8d8bf','d9d9f3','ffffff','d8bfd8','d8bfd8','ff2400','ff0000','dc143c','cc3299','ff1cae','ff00ff','ff00ff','ff6ec7','eaadea'],

    // 파라미터 명칭. 차례대로 공격력, 방어력, 민첩, 명중률, HP, EN, 성장 타입.
    'STATUS_NAME' => ['공격','방어','속도','명중','HP','EN','행운'],

    // 계급명. 계급 수는 원본 로직과 맞춰 고정한다.
    'CLASS_NAME' => ['거지','천민','농민','중민','부르주아 ','기사','성주','남작','백작','후작','공작','국왕'],
]);
?>
