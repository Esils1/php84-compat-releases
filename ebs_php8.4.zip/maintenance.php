<?php
declare(strict_types=1);
require_once __DIR__ . '/lib_ebs.php';
/**
 * 원본 legacy 파일: maintenance.php
 * PHP 8.4 운영 관리 페이지.
 * editadmin.php와 중복되는 관리 기능은 같은 PHP 파일 저장 함수를 사용한다.
 */
$cmd = ebs_cmd('MAINTE');
$public = ['TOP','MAINTE','MAINTENANCE','LOGOUT'];
if (!in_array($cmd, $public, true) && !ebs_admin_ok()) { ebs_admin_login_form(basename(__FILE__), '운영 관리'); return; }
switch ($cmd) {
    case 'ADMIN_ACTION':
        $action = ebs_param('admin_action', 'PLAYER_EDIT');
        if ($action === 'USER_REPAIR') { ebs_admin_user_repair_screen(basename(__FILE__)); break; }
        if ($action === 'DEL') { ebs_admin_delete_player(); break; }
        ebs_admin_player_edit_screen(basename(__FILE__)); break;
    case 'PLAYER_EDIT':
        ebs_admin_player_edit_screen(basename(__FILE__)); break;
    case 'LOGOUT': ebs_admin_logout(); break;
    case 'TOP':
    case 'MAINTE':
    case 'MAINTENANCE':
        if (ebs_admin_ok()) { ebs_admin_menu('maintenance.php'); } else { ebs_admin_login_form('maintenance.php','운영 관리'); }
        break;
    case 'MAINTE2':
    case 'MAINTENANCE2': ebs_admin_menu('maintenance.php'); break;
    case 'MASTER':
    case 'PLAYER': ebs_admin_players('maintenance.php'); break;
    case 'SYUSEI':
    case 'SYUSEI2': ebs_admin_player_edit_screen('maintenance.php'); break;
    case 'TYOUSEI': ebs_admin_update_player(); break;
    case 'BOUGU_DATA':
    case 'ARMOR': ebs_admin_bougu_screen('maintenance.php'); break;
    case 'BOUGU_SAVE': ebs_admin_bougu_save(); break;
    case 'NOTICE': ebs_admin_notice_screen('maintenance.php'); break;
    case 'NOTICE_SAVE': ebs_admin_notice_save(); break;
    case 'CONFIG_EDIT': ebs_admin_config_screen('maintenance.php'); break;
    case 'CONFIG_SAVE': ebs_admin_config_save(); break;
    case 'COUNTRY':
    case 'COUNTRY_EDIT': ebs_admin_countries('maintenance.php'); break;
    case 'COUNTRY_CREATE': ebs_admin_create_country(); break;
    case 'COUNTRY_DELETE': ebs_admin_delete_country(); break;
    case 'WEAPON':
    case 'ALLWEAPONS': ebs_admin_weapon_screen('maintenance.php'); break;
    case 'WEAPON_SAVE': ebs_admin_weapon_save(); break;
    case 'KAIZAN': ebs_admin_update_country(); break;
    case 'BACKUP': ebs_admin_backup_screen('maintenance.php'); break;
    case 'BACKUP_RUN': ebs_admin_backup_run(); break;
    case 'DATAUP': ebs_admin_backup_screen('maintenance.php'); break;
    case 'DATAUP_RUN': ebs_admin_restore_run(); break;
    case 'COOKIES': ebs_admin_cookies_screen('maintenance.php'); break;
    case 'DEL': ebs_admin_delete_player(); break;
    case 'HISTORY_EDIT':
    case 'HISTORY_EDIT2':
    case 'HISMAKE':
    case 'HISMAKES': ebs_admin_history_public_screen('maintenance.php'); break;
    case 'HISTORY_EDIT_SAVE':
    case 'HISMAKES_SAVE': ebs_admin_history_public_save('maintenance.php'); break;
    case 'UPDATE_EDIT':
    case 'UPDATE_EDIT2':
    case 'UPDATA':
    case 'UPDMAKE':
    case 'UPDMAKES': ebs_admin_update_public_screen('maintenance.php'); break;
    case 'UPDATE_EDIT_SAVE':
    case 'UPDMAKES_SAVE': ebs_admin_update_public_save('maintenance.php'); break;
    case 'USER_REPAIR': ebs_admin_user_repair_screen('maintenance.php'); break;
    case 'USER_REPAIR_RUN': ebs_admin_user_repair_run(); break;
    case 'MAINTE_LOG': ebs_admin_log_screen('maintenance.php'); break;
    default: ebs_admin_menu('maintenance.php'); break;
}
?>
