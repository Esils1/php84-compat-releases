<?php
declare(strict_types=1);
require_once __DIR__ . '/lib_ebs.php';

function ebs_admin_cmd_pass_hidden(): string {
    return '<input type="hidden" name="pass" value="'.ebs_h(ebs_admin_pass_value()).'">';
}

function ebs_admin_screen_start(string $title): void {
    ebs_header_html();
    echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>'.ebs_h($title).'</title></head>';
    echo '<body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="margin:8px;font-size:13px;" oncontextmenu="return false;"><center>';
    echo '<table border="1" cellspacing="0" cellpadding="5" bordercolor="'.ebs_h(ebs_v('TABLE_BORDER')).'" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" width="95%">';
    echo '<tr><td colspan="10" align="center" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'"><b>'.ebs_h($title).'</b></td></tr>';
}

function ebs_admin_screen_end(): void {
    echo '<tr><td colspan="10" align="center" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'">';
    echo '<form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST" style="display:inline"><input type="hidden" name="cmd" value="MAINTE2">'.ebs_admin_cmd_pass_hidden().'<input type="submit" value="관리 메뉴" '.ebs_v('STYLE_B2').'></form> ';
    echo '<form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST" target="_top" style="display:inline"><input type="hidden" name="cmd" value="TOP"><input type="submit" value="메인" '.ebs_v('STYLE_B2').'></form> ';
    echo '<form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST" target="_top" style="display:inline"><input type="hidden" name="cmd" value="ADMIN_LOGOUT"><input type="submit" value="관리자 로그아웃" '.ebs_v('STYLE_B2').'></form>';
    echo '</td></tr></table></center></body></html>';
}

function ebs_admin_need_login(string $title='Maintenance Mode'): bool {
    if (!ebs_admin_ok()) {
        ebs_admin_login_form(ebs_v('MAIN_SCRIPT'), $title);
        return false;
    }
    return true;
}

function ebs_ADMIN_LOGOUT_CMD(): void { ebs_admin_logout(); }

function ebs_MAINTENANCE(): void {
    ebs_admin_login_form(ebs_v('MAIN_SCRIPT'), 'Maintenance Mode');
}

function ebs_MAINTENANCE2(): void {
    if (!ebs_admin_need_login()) return;
    ebs_admin_screen_start('메인터넌스');
    $items = [
        'LGIN_RIREKI' => ['로그인 히스토리', '최근 접속 기준으로 플레이어 정보를 표시합니다.'],
        'XPL_LIST' => ['플레이어 데이터 검사', '필수 필드/무기/아이콘을 검사하고 수정 화면으로 연결합니다.'],
        'XCO_LIST' => ['국가 데이터 검사', '국가 JSON 데이터를 점검하고 수정 화면으로 연결합니다.'],
        'BOUGU_DATA' => ['보강장비 데이터 관리', '보강장비 목록/가격/효과/내구를 수정합니다.'],
        'NOTICE' => ['공지사항/추가사항 관리', '상단 공지사항과 추가사항을 작성/수정/삭제합니다.'],
        'CONFIG_EDIT' => ['config 설정 관리', 'config.php 주요 운영 수치를 화면에서 수정합니다.'],
        'PL_DEL' => ['플레이어 삭제', '지정한 플레이어 JSON 파일을 삭제합니다.'],
        'HISTORY_EDIT' => ['역사 편찬', '공개 역사 목록을 작성/삭제합니다.'],
        'UPDATE_EDIT' => ['업데이트 작성', '공개 업데이트 목록을 작성/삭제합니다.'],
    ];
    foreach ($items as $cmd=>$row) {
        echo '<tr><td bgcolor="#404040" align="center" width="180">'.ebs_h($row[0]).'</td><td style="color:#000000;background:#d8d8d8;">'.ebs_h($row[1]).'</td><td align="center" width="80"><form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST" style="margin:0"><input type="hidden" name="cmd" value="'.ebs_h($cmd).'">'.ebs_admin_cmd_pass_hidden().'<input type="submit" value="GO" '.ebs_v('STYLE_B2').'></form></td></tr>';
    }
    ebs_admin_screen_end();
}

function ebs_LGIN_RIREKI2(): void {
    if (!ebs_admin_need_login()) return;
    $players = ebs_players_load();
    uasort($players, static function(array $a, array $b): int { return strcmp((string)($b['last_access'] ?? ''), (string)($a['last_access'] ?? '')); });
    ebs_admin_screen_start('로그인 히스토리');
    echo '<tr bgcolor="#404040"><td>파일럿</td><td>국가</td><td>레벨</td><td>기체</td><td>최근접속</td><td>IP/Host</td><td>수정</td></tr>';
    $i=0;
    foreach ($players as $name=>$p) {
        if (!is_array($p)) continue;
        if ($i++ >= 100) break;
        $remote = (string)($p['remote'] ?? '');
        echo '<tr><td>'.ebs_h((string)($p['name'] ?? $name)).'</td><td>'.ebs_h((string)($p['kuni'] ?? '')).'</td><td align="right">'.ebs_h((string)($p['level'] ?? '1')).'</td><td>'.ebs_h((string)($p['msname'] ?? '')).'</td><td>'.ebs_h((string)($p['last_access'] ?? '')).'</td><td>'.ebs_h($remote).'</td><td align="center"><form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST" style="margin:0"><input type="hidden" name="cmd" value="SYUSEI"><input type="hidden" name="plname" value="'.ebs_h((string)($p['name'] ?? $name)).'">'.ebs_admin_cmd_pass_hidden().'<input type="submit" value="수정" '.ebs_v('STYLE_B2').'></form></td></tr>';
    }
    if ($i === 0) echo '<tr><td colspan="7" align="center">등록 데이터가 없습니다.</td></tr>';
    ebs_admin_screen_end();
}

function ebs_player_check_messages(array $p): array {
    $msgs=[];
    if ((string)($p['name'] ?? '') === '') $msgs[]='이름 없음';
    if ((string)($p['pass'] ?? '') === '') $msgs[]='패스 없음';
    if (!ebs_weapon_exists((string)($p['weapon'] ?? ''))) $msgs[]='장비 무기 없음';
    if (!ebs_icon_exists((string)($p['icon'] ?? '1'))) $msgs[]='아이콘 없음';
    if (!isset($p['raw_values']) || !is_array($p['raw_values'])) $msgs[]='raw_values 없음';
    return $msgs;
}

function ebs_XPL_LIST2(): void {
    if (!ebs_admin_need_login()) return;
    $players = ebs_players_load();
    ebs_admin_screen_start('플레이어 데이터 검사');
    echo '<tr bgcolor="#404040"><td>상태</td><td>파일럿</td><td>국가</td><td>레벨</td><td>무기</td><td>아이콘</td><td>수정</td></tr>';
    $printed=0;
    foreach ($players as $name=>$p) {
        if (!is_array($p)) continue;
        $msgs = ebs_player_check_messages($p);
        if (!$msgs) continue;
        $printed++;
        echo '<tr><td>'.ebs_h(implode(', ', $msgs)).'</td><td>'.ebs_h((string)($p['name'] ?? $name)).'</td><td>'.ebs_h((string)($p['kuni'] ?? '')).'</td><td align="right">'.ebs_h((string)($p['level'] ?? '1')).'</td><td>'.ebs_h((string)($p['weapon'] ?? '')).'</td><td>'.ebs_h((string)($p['icon'] ?? '')).'</td><td align="center"><form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST" style="margin:0"><input type="hidden" name="cmd" value="SYUSEI"><input type="hidden" name="plname" value="'.ebs_h((string)($p['name'] ?? $name)).'">'.ebs_admin_cmd_pass_hidden().'<input type="submit" value="수정" '.ebs_v('STYLE_B2').'></form></td></tr>';
    }
    if ($printed === 0) echo '<tr><td colspan="7" align="center">파손된 플레이어 데이터가 없습니다.</td></tr>';
    ebs_admin_screen_end();
}

function ebs_SYUSEI2(): void {
    if (!ebs_admin_need_login()) return;
    $target = ebs_param('plname', ebs_param('pname',''));
    $players = ebs_players_load();
    $key = ebs_find_player_key($target, $players);
    if ($key === null || !isset($players[$key]) || !is_array($players[$key])) { ebs_error_page('Error', '대상 플레이어를 찾을 수 없습니다.'); return; }
    $p = $players[$key];
    $msg = '';
    if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && ebs_param('mode','') === 'save') {
        foreach (['level','hp','max_hp','en','max_en','money','bank','goldbar','kuni','job','msname','comment','weapon','weapon2','weapon3','icon'] as $field) {
            if (isset($_POST[$field]) && is_scalar($_POST[$field])) $p[$field] = trim((string)$_POST[$field]);
        }
        if (!ebs_weapon_exists((string)($p['weapon'] ?? ''))) $p['weapon'] = ebs_default_weapon_id().'!0';
        $p['icon'] = ebs_normalize_icon((string)($p['icon'] ?? '1'), '1');
        ebs_player_sync_common($p);
        $players[$key] = $p;
        ebs_players_save($players);
        $msg = '저장했습니다.';
    }
    ebs_admin_screen_start('플레이어 수정');
    if ($msg !== '') echo '<tr><td colspan="4" align="center" bgcolor="#404040">'.ebs_h($msg).'</td></tr>';
    echo '<form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST"><input type="hidden" name="cmd" value="SYUSEI"><input type="hidden" name="mode" value="save"><input type="hidden" name="plname" value="'.ebs_h((string)($p['name'] ?? $key)).'">'.ebs_admin_cmd_pass_hidden();
    $fields = ['level'=>'레벨','hp'=>'HP','max_hp'=>'MAX HP','en'=>'EN','max_en'=>'MAX EN','money'=>'소지금','bank'=>'예금','goldbar'=>'금괴','kuni'=>'국가','job'=>'직위','msname'=>'기체명','comment'=>'코멘트','weapon'=>'장비','weapon2'=>'예비1','weapon3'=>'예비2','icon'=>'아이콘'];
    foreach ($fields as $f=>$label) {
        echo '<tr><td width="160" bgcolor="#404040">'.ebs_h($label).'</td><td colspan="3"><input name="'.ebs_h($f).'" value="'.ebs_h((string)($p[$f] ?? '')).'" size="60" '.ebs_v('STYLE_L').'></td></tr>';
    }
    echo '<tr><td colspan="4" align="center"><input type="submit" value="저장" '.ebs_v('STYLE_B2').'></td></tr></form>';
    ebs_admin_screen_end();
}

function ebs_XCO_LIST2(): void {
    if (!ebs_admin_need_login()) return;
    $countries = ebs_country_records();
    ebs_admin_screen_start('국가 데이터 검사');
    echo '<tr bgcolor="#404040"><td>상태</td><td>국가</td><td>국비</td><td>인구제한</td><td>문장</td><td>수정</td></tr>';
    $printed=0;
    foreach ($countries as $name=>$c) {
        if (!is_array($c)) continue;
        $msgs=[];
        if ((string)($c['name'] ?? '') === '') $msgs[]='국가명 없음';
        if (!is_numeric((string)($c['money'] ?? '0'))) $msgs[]='국비 비정상';
        if (!is_numeric((string)($c['max_member'] ?? ebs_v('C_MAX_MEMBER','40')))) $msgs[]='인구제한 비정상';
        if (!$msgs) $msgs[]='정상';
        $printed++;
        echo '<tr><td>'.ebs_h(implode(', ', $msgs)).'</td><td>'.ebs_h((string)($c['name'] ?? $name)).'</td><td align="right">'.number_format((int)($c['money'] ?? 0)).'</td><td align="right">'.ebs_h((string)($c['max_member'] ?? '')).'</td><td>'.ebs_h((string)($c['icon'] ?? '')).'</td><td><form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST" style="margin:0"><input type="hidden" name="cmd" value="CNSYUSEI"><input type="hidden" name="coname" value="'.ebs_h((string)($c['name'] ?? $name)).'">'.ebs_admin_cmd_pass_hidden().'<input type="submit" value="수정" '.ebs_v('STYLE_B2').'></form></td></tr>';
    }
    if ($printed === 0) echo '<tr><td colspan="6" align="center">국가 데이터가 없습니다.</td></tr>';
    ebs_admin_screen_end();
}

function ebs_country_store_load(): array { return ebs_json_load('countrydata'); }
function ebs_country_store_save(array $rows): bool { return ebs_json_save('countrydata', $rows); }

function ebs_CNSYUSEI2(): void {
    if (!ebs_admin_need_login()) return;
    $target = ebs_param('coname', ebs_param('cname',''));
    $rows = ebs_country_store_load();
    $foundKey = null;
    foreach ($rows as $k=>$v) {
        $recName = is_array($v) ? (string)($v['name'] ?? $k) : (string)$k;
        if ((string)$k === $target || $recName === $target) { $foundKey = $k; break; }
    }
    if ($foundKey === null) { ebs_error_page('Error', '대상 국가를 찾을 수 없습니다.'); return; }
    $row = $rows[$foundKey];
    if (!is_array($row)) {
        $parts = explode('<>', (string)$row);
        $row = ['name'=>(string)$foundKey,'money'=>$parts[1] ?? '0','comment'=>$parts[2] ?? '','icon'=>$parts[5] ?? '1','max_member'=>$parts[6] ?? ebs_v('C_MAX_MEMBER','40')];
    }
    $msg='';
    if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && ebs_param('mode','') === 'save') {
        foreach (['money','comment','icon','max_member','fortress_hp','atk','def','hit'] as $field) {
            if (isset($_POST[$field]) && is_scalar($_POST[$field])) $row[$field] = trim((string)$_POST[$field]);
        }
        $row['name'] = (string)($row['name'] ?? $foundKey);
        $rows[$foundKey] = $row;
        ebs_country_store_save($rows);
        $msg='저장했습니다.';
    }
    ebs_admin_screen_start('국가 수정');
    if ($msg !== '') echo '<tr><td colspan="4" align="center" bgcolor="#404040">'.ebs_h($msg).'</td></tr>';
    echo '<form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST"><input type="hidden" name="cmd" value="CNSYUSEI"><input type="hidden" name="mode" value="save"><input type="hidden" name="coname" value="'.ebs_h((string)($row['name'] ?? $foundKey)).'">'.ebs_admin_cmd_pass_hidden();
    foreach (['money'=>'국비','comment'=>'문장/설명','icon'=>'문장 아이콘','max_member'=>'인구제한','fortress_hp'=>'요새 HP','atk'=>'공격 강화','def'=>'방어 강화','hit'=>'명중 강화'] as $f=>$label) {
        echo '<tr><td width="160" bgcolor="#404040">'.ebs_h($label).'</td><td colspan="3"><input name="'.ebs_h($f).'" value="'.ebs_h((string)($row[$f] ?? '')).'" size="70" '.ebs_v('STYLE_L').'></td></tr>';
    }
    echo '<tr><td colspan="4" align="center"><input type="submit" value="저장" '.ebs_v('STYLE_B2').'></td></tr></form>';
    ebs_admin_screen_end();
}

function ebs_HISTORY_EDIT2(): void {
    if (!ebs_admin_need_login()) return;
    ebs_admin_history_public_screen(ebs_v('MAIN_SCRIPT'));
}

function ebs_HISTORY_EDIT3(): void {
    ebs_HISTORY_EDIT2();
}

function ebs_UPDATE_EDIT2(): void {
    if (!ebs_admin_need_login()) return;
    ebs_admin_update_public_screen(ebs_v('MAIN_SCRIPT'));
}

function ebs_UPDATE_EDIT3(): void {
    ebs_UPDATE_EDIT2();
}

function ebs_BOUGU_DATA(): void { if (!ebs_admin_need_login()) return; ebs_admin_bougu_screen(ebs_v('MAIN_SCRIPT')); }
function ebs_BOUGU_SAVE(): void { if (!ebs_admin_need_login()) return; ebs_admin_bougu_save(); }
function ebs_NOTICE(): void { if (!ebs_admin_need_login()) return; ebs_admin_notice_screen(ebs_v('MAIN_SCRIPT')); }
function ebs_NOTICE_SAVE(): void { if (!ebs_admin_need_login()) return; ebs_admin_notice_save(); }
function ebs_CONFIG_EDIT(): void { if (!ebs_admin_need_login()) return; ebs_admin_config_screen(ebs_v('MAIN_SCRIPT')); }
function ebs_CONFIG_SAVE(): void { if (!ebs_admin_need_login()) return; ebs_admin_config_save(); }

function ebs_PL_DEL2(): void {
    if (!ebs_admin_need_login()) return;
    ebs_admin_screen_start('플레이어 삭제');
    echo '<tr><td colspan="4" align="center">삭제한 플레이어 데이터는 복원할 수 없습니다.</td></tr>';
    echo '<tr><td colspan="4" align="center"><form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST"><input type="hidden" name="cmd" value="PL_DEL2">'.ebs_admin_cmd_pass_hidden().'파일럿 이름 <input name="pname" size="24" '.ebs_v('STYLE_L').'> <input type="submit" value="삭제" '.ebs_v('STYLE_B2').' onclick="return confirm(\'정말 삭제합니까?\')"></form></td></tr>';
    ebs_admin_screen_end();
}

function ebs_PL_DEL3(): void {
    if (!ebs_admin_need_login()) return;
    $target = ebs_param('pname','');
    $ok = false;
    if ($target !== '') $ok = ebs_player_delete_one($target);
    ebs_admin_screen_start('플레이어 삭제 결과');
    echo '<tr><td align="center">'.($ok ? ebs_h($target).' 삭제 완료' : '삭제 대상이 없거나 삭제하지 못했습니다.').'</td></tr>';
    ebs_admin_screen_end();
}

function ebs_admin_history_handle_post(): void {
    if (!ebs_admin_ok()) return;
    $cmd = ebs_cmd('');
    $store = '';
    if ($cmd === 'HISTORY_EDIT2' || $cmd === 'HISTORY_EDIT3') $store = 'history_data';
    if ($cmd === 'UPDATE_EDIT2' || $cmd === 'UPDATE_EDIT3') $store = 'updata';
    if ($store === '') return;
    $mode = ebs_param('mode','');
    if ($mode === '') return;
    $rows = ebs_json_load($store);
    if (!is_array($rows)) $rows=[];
    if ($mode === 'save') {
        $text = trim(ebs_param('text',''));
        if ($text !== '') {
            $rows[] = ['time'=>date('YmdHis'), 'text'=>$text];
            if (count($rows) > 300) $rows = array_slice($rows, -300);
            ebs_json_save($store, $rows);
        }
    } elseif ($mode === 'delete') {
        $idx = ebs_param('idx','');
        $deleted = false;
        if ($idx !== '' && isset($rows[$idx])) {
            unset($rows[$idx]);
            $deleted = true;
        } elseif ($idx !== '' && isset($rows[(int)$idx])) {
            unset($rows[(int)$idx]);
            $deleted = true;
        }
        if ($deleted) {
            $rows = array_values($rows);
            ebs_json_save($store, $rows);
        }
    }
}

ebs_admin_history_handle_post();

$map = [
    'ADMIN_LOGOUT' => 'ebs_ADMIN_LOGOUT_CMD',
    'MAINTENANCE' => 'ebs_MAINTENANCE',
    'MAINTENANCE2' => 'ebs_MAINTENANCE2',
    'LGIN_RIREKI2' => 'ebs_LGIN_RIREKI2',
    'XPL_LIST2' => 'ebs_XPL_LIST2',
    'SYUSEI2' => 'ebs_SYUSEI2',
    'XCO_LIST2' => 'ebs_XCO_LIST2',
    'CNSYUSEI2' => 'ebs_CNSYUSEI2',
    'HISTORY_EDIT2' => 'ebs_HISTORY_EDIT2',
    'HISTORY_EDIT3' => 'ebs_HISTORY_EDIT3',
    'UPDATE_EDIT2' => 'ebs_UPDATE_EDIT2',
    'UPDATE_EDIT3' => 'ebs_UPDATE_EDIT3',
    'BOUGU_DATA' => 'ebs_BOUGU_DATA',
    'BOUGU_SAVE' => 'ebs_BOUGU_SAVE',
    'NOTICE' => 'ebs_NOTICE',
    'NOTICE_SAVE' => 'ebs_NOTICE_SAVE',
    'CONFIG_EDIT' => 'ebs_CONFIG_EDIT',
    'CONFIG_SAVE' => 'ebs_CONFIG_SAVE',
    'PL_DEL2' => 'ebs_PL_DEL2',
    'PL_DEL3' => 'ebs_PL_DEL3',
];
ebs_dispatch($map, 'ebs_MAINTENANCE');
?>
