<?php
declare(strict_types=1);
require_once __DIR__ . '/lib_ebs.php';
/**
 * 원본 legacy 파일: ebs_sub4.php
 * PHP 8.4 파일당 1:1 대응 변환 파일.
 * 원본 주석은 PHP // 주석으로 보존하고, 기존 실행 의존은 제거하고 PHP 8.4 파일 기반으로 동작시킨다.
 * 유지보수 시 원본 sub 이름과 아래 ebs_함수명을 대조한다.
 */
// ===============================
// 참전자 표시
// ===============================
// ===============================
// 참전자 표시 끝
// ===============================
// -----------리플렉트-------------------
// -----------여기까지-------------------
// --------------돈 행운------------------------
// ---------------------------------------------
// -----------경험치 행운-------------
// -----------여기까지---------
// ---------------EXP 드레인-------------------
// -----------------여기까지---------------------------------
// 에너지 드레인
// --------------여기까지--------------------
// EN 드레인
// ---------------여기까지------------------------
// ---------------머니 드레인-------------------
// -----------------여기까지---------------------------------
// ---------------에너지 회복-----------------
// --------------여기까지---------------------


function ebs_battle_plan_names(): array {
    return [
        1 => ['통상공격', 0],
        2 => ['돌격', 5],
        3 => ['방어', 18],
        4 => ['치고빠지기', 25],
        5 => ['저격', 30],
        6 => ['필살', 40],
        7 => ['배수의진', 50],
        8 => ['일제사격', 70],
    ];
}
function ebs_battle_normalize_mode(string $selected): int {
    $map = ['normal'=>1,'attack'=>2,'defense'=>3,'speed'=>4,'conserve'=>5,'critical'=>6,'drain'=>7,'all'=>8];
    $selected = trim($selected);
    if (isset($map[$selected])) return $map[$selected];
    $n = (int)$selected;
    return ($n >= 1 && $n <= 8) ? $n : 1;
}
function ebs_battle_plan_select(string $selected='1', int $level=9999): string {
    $selectedNo = ebs_battle_normalize_mode($selected);
    $out = '작전<select size="1" name="mode" '.ebs_v('STYLE_L').">\n";
    foreach (ebs_battle_plan_names() as $no => $info) {
        [$label, $need] = $info;
        if ($level < $need) continue;
        $out .= '<option value="'.$no.'"'.($no === $selectedNo ? ' selected' : '').'>'.ebs_h($label).' </option>'."\n";
    }
    return $out.'</select>';
}

function ebs_BATTLE1(): void {
    ebs_header_html();
    ebs_bootstrap_runtime_counts();
    $pname = ebs_param('pname', ebs_cookie_value('pname', ''));
    $pass  = ebs_param('pass', ebs_cookie_value('pass', ''));
    $mode  = ebs_param('b_mode', '전투');
    [$key, $me, $players, $err] = ebs_require_player($pname, $pass);
    if ($err !== '' || !is_array($me)) { ebs_error_page('Error', $err ?: '로그인 정보 또는 등록 데이터가 없습니다.'); return; }
    $pname = (string)($me['name'] ?? $pname);
    $myCountry = (string)($me['kuni'] ?? '');
    $noneCountry = ebs_v('NONE_NATIONALITY');
    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>ENDLESS BATTLE</title></head>';
    echo '<body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="margin:0px;font-size:13px;" oncontextmenu="return false;">';
    echo '<div align="center"><table border="1" bordercolor="'.ebs_h(ebs_v('TABLE_BORDER')).'" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" cellspacing="0" cellpadding="3" style="font-size:13px;min-width:640px;color:'.ebs_h(ebs_v('FONT_COLOR')).';">';
    if ($mode === '망명') {
        $countries = ebs_country_records();
        echo '<tr><td colspan="4" align="center" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'" style="font-size:20px;"><b>망명</b></td></tr>';
        echo '<tr><td colspan="4">이동할 국가를 선택합니다. 망명하면 소속 부대와 직위는 초기화됩니다.</td></tr>';
        foreach ($countries as $c) {
            $cname=(string)$c['name']; if ($cname === (string)($me['kuni'] ?? '')) continue;
            echo '<tr bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'"><td bgcolor="'.ebs_h((string)$c['color']).'" style="color:'.ebs_h(ebs_contrast_text_color((string)$c['color'])).'">&nbsp;</td><td>'.ebs_h($cname).'</td><td>국비 $'.ebs_h((string)$c['money']).'</td><td><form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST" target="Sub"><input type="hidden" name="cmd" value="CUSTOM"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'"><input type="hidden" name="Cmode" value="망명"><input type="hidden" name="boumeiC" value="'.ebs_h($cname).'"><input type="submit" value="망명" '.ebs_v('STYLE_B1').'></form></td></tr>';
        }
        if (!$countries) echo '<tr><td colspan="4" align="center">망명 가능한 국가가 없습니다.</td></tr>';
        echo '</table></div></body></html>'; return;
    }
    if ($mode === '내란') {
        echo '<tr><td colspan="6" align="center" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'" style="font-size:20px;"><b>내란</b></td></tr>';
        echo '<tr><td colspan="6">자국민을 상대로 전투 대상을 선택합니다.</td></tr>';
        $printed=0;
        foreach ($players as $name=>$p) { if (!is_array($p)) continue; $name=(string)($p['name'] ?? $name); if ($name===$pname) continue; if ((string)($p['kuni'] ?? '') !== $myCountry) continue; $printed++;
            echo '<tr bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'"><td><form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST" target="Sub"><input type="hidden" name="cmd" value="BATTLE_2"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'"><input type="hidden" name="vsname" value="'.ebs_h($name).'"><input type="hidden" name="b_mode" value="내란">'.ebs_battle_plan_select('1', ebs_player_level_value($me)).' <input type="submit" value="내란" '.ebs_v('STYLE_B1').'></form></td><td>'.ebs_h($name).'</td><td>'.ebs_h((string)($p['level'] ?? 1)).'</td><td>'.ebs_h($myCountry !== '' ? $myCountry : $noneCountry).'</td><td align="right">'.ebs_h((string)($p['hp'] ?? '0')).'</td><td>휴식중</td></tr>'; }
        if ($printed===0) echo '<tr><td colspan="6" align="center">내란 대상이 없습니다.</td></tr>';
        echo '</table></div></body></html>'; return;
    }

    $selected = ebs_param('CNTRY', '');
    $countries = ebs_country_records();
    $allLabel = '전체';
    echo '<tr><td colspan="6" align="center" style="background:'.ebs_h(ebs_v('TABLE_COLOR2')).';color:'.ebs_h(ebs_v('FONT_COLOR')).';font-size:20px;"><b>전투 상대 선택</b></td></tr>';
    echo '<tr><td colspan="6" align="center" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'">';
    echo '<form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST" target="Sub" style="display:inline;margin:0"><input type="hidden" name="cmd" value="BATTLE_1"><input type="hidden" name="b_mode" value="전투"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'"><input type="submit" name="CNTRY" value="'.ebs_h($allLabel).'" '.ebs_v('STYLE_B2').'></form> ';
    foreach ($countries as $c) {
        echo '<form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST" target="Sub" style="display:inline;margin:0"><input type="hidden" name="cmd" value="BATTLE_1"><input type="hidden" name="b_mode" value="전투"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'"><input type="submit" name="CNTRY" value="'.ebs_h((string)$c['name']).'" style="'.ebs_h(ebs_country_button_style((string)$c['color'])).'"></form> ';
    }
    echo '<form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST" target="Sub" style="display:inline;margin:0"><input type="hidden" name="cmd" value="BATTLE_1"><input type="hidden" name="b_mode" value="전투"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'"><input type="submit" name="CNTRY" value="'.ebs_h($noneCountry).'" style="'.ebs_h(ebs_country_button_style('#606060')).'"></form>';
    echo '</td></tr>';
    if ($selected === $allLabel) $selected = '';
    $title = $selected === '' ? '전체 국가' : $selected;
    echo '<tr><td colspan="6" align="center" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'"><b>'.ebs_h($title).'</b> 전투 가능 인원</td></tr>';
    echo '<tr bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'"><td>선택</td><td>이름</td><td>레벨</td><td>국가</td><td>HP</td><td>상태</td></tr>';
    $printed = 0;
    foreach ($players as $name => $p) {
        if (!is_array($p)) continue;
        $name = (string)($p['name'] ?? $name);
        if ($name === $pname) continue;
        $pkuni = (string)($p['kuni'] ?? '');
        if ($selected !== '' && $selected !== $noneCountry && $pkuni !== $selected) continue;
        if ($selected === $noneCountry && $pkuni !== '') continue;
        $printed++;
        $color = ebs_visible_player_color((string)($p['color'] ?? '#ededed'), ebs_v('TABLE_COLOR1'));
        $country = $pkuni !== '' ? $pkuni : $noneCountry;
        echo '<tr bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'"><td><form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST" target="Sub"><input type="hidden" name="cmd" value="BATTLE_2"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'"><input type="hidden" name="vsname" value="'.ebs_h($name).'">'.ebs_battle_plan_select('1', ebs_player_level_value($me)).' <input type="submit" value="전투" '.ebs_v('STYLE_B1').'></form></td>';
        echo '<td><span style="color:'.ebs_h($color).';">'.ebs_h($name).'</span></td><td align="right">'.ebs_h((string)($p['level'] ?? '1')).'</td><td>'.ebs_h($country).'</td><td align="right">'.ebs_h((string)($p['hp'] ?? '0')).'</td><td>휴식중</td></tr>';
    }
    if ($printed === 0) echo '<tr><td colspan="6" align="center">대전상대가 존재하지 않습니다.</td></tr>';
    echo '</table></div></body></html>';
}

function ebs_battle_bar_img(int $before, int $after, int $max, string $kind='hp', int $width=150): string {
    $max = max(1, $max);
    $before = max(0, min($max, $before));
    $after = max(0, min($max, $after));
    $remain = (int)floor($after / $max * $width);
    $damage = (int)floor(max(0, $before - $after) / $max * $width);
    $recover = (int)floor(max(0, $after - $before) / $max * $width);
    $base = ebs_h(ebs_v('IMG_FOLDER1', './img1'));
    $out = '';
    if ($remain > 0) $out .= '<img src="'.$base.'/hp.gif" hspace="0" height="7" width="'.$remain.'">';
    if ($damage > 0) $out .= '<img src="'.$base.'/dmg.gif" hspace="0" height="7" width="'.$damage.'">';
    if ($recover > 0) $out .= '<img src="'.$base.'/zen.gif" hspace="0" height="7" width="'.$recover.'">';
    if ($out === '') $out = '<img src="'.$base.'/dmg.gif" hspace="0" height="7" width="1">';
    return $out;
}
function ebs_battle_effect_icons(int $attackCount, array $hits): string {
    $base = ebs_h(ebs_v('IMG_FOLDER1', './img1'));
    $out = '';
    for ($i = 0; $i < $attackCount; $i++) {
        $out .= '<img src="'.$base.'/'.(!empty($hits[$i]) ? 'hit.gif' : 'miss.gif').'" border="0">';
        if (($i + 1) % 10 === 0) $out .= '<br>';
    }
    return $out === '' ? '&nbsp;' : $out;
}
function ebs_battle_add_weapon_exp(string $raw, int $gain): string {
    [$id, $exp] = array_pad(explode('!', $raw, 2), 2, '0');
    if ($id === '') return $raw;
    return $id.'!'.max(0, (int)$exp + max(0, $gain));
}
function ebs_battle_weapon_image(array $row): string {
    $img = (string)($row[9] ?? '01');
    if ($img === '') $img = '01';
    if (!preg_match('/^[0-9A-Za-z_\-]+$/', $img)) $img = '01';
    return './bukiimg/'.$img.'.png';
}

function ebs_legacy_weapon_parts(array $player): array {
    [$id, $exp] = array_pad(explode('!', ebs_player_raw_get($player, 9, (string)($player['weapon'] ?? '')), 2), 2, '0');
    if ($id === '') $id = ebs_default_weapon_id();
    $table = ebs_weapon_table();
    $row = $table[$id] ?? ($table[ebs_default_weapon_id()] ?? []);
    $defaults = ['없음',1000,70,1,0,0,0,'0','0','01'];
    for ($i=0; $i<count($defaults); $i++) if (!array_key_exists($i, $row) || $row[$i] === '') $row[$i] = $defaults[$i];
    return [$id, max(0, (int)$exp), array_values($row)];
}
function ebs_legacy_bougu_parts(array $player): array {
    [$id, $dur] = array_pad(explode('!', ebs_player_raw_get($player, 32, (string)($player['armor'] ?? '')), 2), 2, '0');
    $table = ebs_bougu_table();
    $row = ($id !== '' && isset($table[$id])) ? $table[$id] : [];
    $defaults = ['',0,0,0,0,0,0,'0','7','',0];
    for ($i=0; $i<count($defaults); $i++) if (!array_key_exists($i, $row) || $row[$i] === '') $row[$i] = $defaults[$i];
    return [$id, max(0, (int)$dur), array_values($row)];
}
function ebs_legacy_apply_mission(int $mode, float &$atk, float &$def, float &$sp, float &$hit, int &$count, int &$en): string {
    $names = ebs_battle_plan_names();
    $label = $names[$mode][0] ?? $names[1][0];
    if ($mode === 2) { $atk *= 1.3; $def *= 0.7; }
    elseif ($mode === 3) { $atk *= 0.8; $def *= 2; }
    elseif ($mode === 4) { $atk *= 0.7; $sp *= 2; }
    elseif ($mode === 5) { $def *= 0.8; $hit += 20; }
    elseif ($mode === 6) { $atk *= 2; $def /= 5; }
    elseif ($mode === 7) { $atk *= 0.9; $sp *= 3; $hit += 10; }
    elseif ($mode === 8) { $hit -= 35; $count *= 2; $en *= 2; }
    if ($count < 1) $count = 1;
    if ($en < 0) $en = 0;
    return $label;
}
function ebs_legacy_apply_chara(string $chara, float &$atk, float &$def, float &$sp, float &$hit): void {
    if ($chara === '1') { $atk *= 1.2; $def -= 2; }
    elseif ($chara === '2') { $atk *= 1.2; }
    elseif ($chara === '3') { $atk *= 0.9; $sp += 3; }
    elseif ($chara === '4') { $hit += 5; }
    elseif ($chara === '5') { $atk *= 1.3; $hit += 10; $def -= 4; }
    elseif ($chara === '6') { $atk *= 1.5; $def *= 1.5; $sp *= 4; $hit *= 1.5; }
}
function ebs_legacy_hit_icons(int $count, array $hits): string {
    $base = ebs_h(ebs_v('IMG_FOLDER1', './img1'));
    $out = '';
    for ($i=0; $i<$count; $i++) {
        $out .= '<img src="'.$base.'/'.(!empty($hits[$i]) ? 'hit.gif' : 'miss.gif').'">';
        if ((($i + 1) % 10) === 0) $out .= "<br>\n";
    }
    return $out === '' ? '&nbsp;' : $out;
}
function ebs_legacy_rank_label(float $rank, string $country='', string $job='', string $skill=''): string {
    if (function_exists('ebs_RANK')) return ebs_RANK((string)$rank, $country, $job, $skill);
    return ' (Rank:'.ebs_h((string)$rank).')';
}
function ebs_legacy_battle_summary(int $count, int $hits, int $damage): string {
    $dmgStyl='style="font-size:21px;color:#9acd32;"';
    $chaStyl='style="font-size:12px;color:#dc143c;"';
    if ($hits <= 0) return '<font color=#6a5acd>빗나감</font>';
    return '<b '.$dmgStyl.'>'.$count.'</b> <b '.$chaStyl.'>회 공격</b> <b '.$dmgStyl.'>'.$hits.'</b> <b '.$chaStyl.'>회 명중</b> <b '.$dmgStyl.'>'.$damage.'</b><b '.$chaStyl.'> 피해</b>';
}
function ebs_legacy_pick_drop(array $table, int $rateIndex=8): string {
    if (!$table) return '';
    $keys = array_keys($table);
    if (!$keys) return '';
    $id = (string)$keys[mt_rand(0, count($keys)-1)];
    $row = $table[$id] ?? [];
    $rate = isset($row[$rateIndex]) && is_numeric($row[$rateIndex]) ? (int)$row[$rateIndex] : 0;
    return ($rate >= mt_rand(0, 99)) ? $id : '';
}

function ebs_battle_rand255_gt(int $threshold): bool {
    return mt_rand(0, 254) > $threshold;
}
function ebs_battle_rand_int(float|int $max): int {
    $n = (int)floor((float)$max);
    if ($n <= 0) return 0;
    return mt_rand(0, $n - 1);
}
function ebs_battle_effect_has(array $row, string $code): bool {
    return strpos((string)($row[7] ?? ''), $code) !== false;
}
function ebs_battle_add_status_damage(array &$player, int $idx, string $label, array &$messages): void {
    $cur = (int)ebs_player_raw_get($player, $idx, '0');
    $cur--;
    ebs_player_raw_set($player, $idx, (string)$cur);
    $stMap = [19=>0,20=>1,21=>2,22=>3];
    if (isset($stMap[$idx])) {
        if (!isset($player['st']) || !is_array($player['st'])) $player['st'] = [6,6,6,6];
        $player['st'][$stMap[$idx]] = $cur;
    }
    if (strpos($label, '다운') !== false) {
        $messages[] = '<font color=#dc143c>'.ebs_h($label).'</font><br>';
    } else {
        $messages[] = '<font color=#8000ff>'.ebs_h($label).' 파손</font><br>';
    }
}
function ebs_battle_apply_special_effects(
    array &$me,
    array &$vs,
    array $plW,
    array $vsW,
    array $plB,
    array $vsB,
    int $result,
    int &$plHpAfter,
    int &$vsHpAfter,
    int &$plEnAfter,
    int &$vsEnAfter,
    int $plMaxHp,
    int $vsMaxHp,
    int $plMaxEn,
    int $vsMaxEn,
    int &$plExp,
    int &$vsExp,
    int &$plMoneyTotal,
    int &$vsMoneyTotal
): array {
    $messages = [];
    $statusNames = ebs_arr('STATUS_NAME');
    $statusNames = array_replace(['공격','방어','속도','명중','HP','EN'], $statusNames);

    // 패배 시 기체 파괴에 따른 능력치 저하. 원본 BATTLE2의 DOWN 이벤트를 보존한다.
    if ($result === 1) {
        $event = mt_rand(0, 69);
        if ($event === 12 && (int)ebs_player_raw_get($me,19,'0') >= 1) ebs_battle_add_status_damage($me, 19, '기체 파괴 '.$statusNames[0].'가 조금 다운.', $messages);
        if ($event === 13 && (int)ebs_player_raw_get($me,20,'0') >= 1) ebs_battle_add_status_damage($me, 20, '기체 파괴 '.$statusNames[1].'가 조금 다운.', $messages);
        if ($event === 14 && (int)ebs_player_raw_get($me,21,'0') >= 1) ebs_battle_add_status_damage($me, 21, '기체 파괴 '.$statusNames[2].'가 조금 다운.', $messages);
        if ($event === 15 && (int)ebs_player_raw_get($me,22,'0') >= 1) ebs_battle_add_status_damage($me, 22, '기체 파괴 '.$statusNames[3].'가 조금 다운.', $messages);
        if ($event === 20 && $plMaxHp >= 5000) {
            $plMaxHp = (int)($plMaxHp * 0.995);
            $me['max_hp'] = $plMaxHp;
            ebs_player_raw_set($me, 16, (string)$plMaxHp);
            $messages[] = '<font color=#dc143c>기체 파괴 '.$statusNames[4].'가 조금 다운. </font><br>';
        }
        if ($event === 40 && $plMaxEn >= 100) {
            $plMaxEn = (int)($plMaxEn * 0.995);
            $me['max_en'] = $plMaxEn;
            ebs_player_raw_set($me, 18, (string)$plMaxEn);
            $messages[] = '<font color=#dc143c>기체 파괴 '.$statusNames[5].'가 조금 다운. </font><br>';
        }
    }

    // 상대기체 파손 / 전투불능.
    if (ebs_battle_effect_has($plW, '1')) {
        if (ebs_battle_rand255_gt(1)) ebs_battle_add_status_damage($vs, 19, '적기 공격계통을', $messages);
        if (ebs_battle_rand255_gt(1)) ebs_battle_add_status_damage($vs, 20, '적기 방어계통을', $messages);
        if (ebs_battle_rand255_gt(1)) ebs_battle_add_status_damage($vs, 21, '적기 회피계통을', $messages);
        if (ebs_battle_rand255_gt(1)) ebs_battle_add_status_damage($vs, 22, '적기 명중계통을', $messages);
    }
    if (ebs_battle_effect_has($vsW, '1')) {
        if (ebs_battle_rand255_gt(200)) ebs_battle_add_status_damage($me, 19, '적기 공격계통을', $messages);
        if (ebs_battle_rand255_gt(200)) ebs_battle_add_status_damage($me, 20, '적기 방어계통을', $messages);
        if (ebs_battle_rand255_gt(200)) ebs_battle_add_status_damage($me, 21, '적기 회피계통을', $messages);
        if (ebs_battle_rand255_gt(200)) ebs_battle_add_status_damage($me, 22, '적기 명중계통을', $messages);
    }
    if (ebs_battle_effect_has($plW, '2') && ebs_battle_rand255_gt(240)) {
        $vs['repair'] = '1';
        ebs_player_raw_set($vs, 25, '1');
        $messages[] = '<font color=#ff0080>'.ebs_h((string)($vs['msname'] ?? $vs['name'] ?? '')).'은/는 전투불능</font><br>';
    }
    if (ebs_battle_effect_has($vsW, '2') && ebs_battle_rand255_gt(240)) {
        $me['repair'] = '1';
        ebs_player_raw_set($me, 25, '1');
        $messages[] = '<font color=#ff0080>'.ebs_h((string)($me['msname'] ?? $me['name'] ?? '')).'은/는 전투불능</font><br>';
    }

    // 경험치 드레인.
    if (ebs_battle_effect_has($plW, 'b') && ebs_battle_rand255_gt(230)) {
        $loss = $plExp > 1 ? ebs_battle_rand_int($plExp * 0.05) : 1;
        if ($loss > 1000) $loss = 1000;
        $plExp = max(0, $plExp - $loss);
        if (($vsExp + $loss) >= (((int)($vs['level'] ?? ebs_player_raw_get($vs,29,'1')) + 1) * 200 - 1)) $loss = 0;
        $vsExp += $loss;
        $messages[] = '<font color=#c22c2c>'.$loss.'의 경험치를 잃어버렸다</font><br>';
    } elseif (ebs_battle_effect_has($plW, 'b') && ebs_battle_rand255_gt(180)) {
        $gain = $vsExp > 100 ? ebs_battle_rand_int($vsMoneyTotal * 0.05) : 1;
        if ($gain > 1000) $gain = 1000;
        $vsExp = max(0, $vsExp - $gain);
        $plExp += $gain;
        $messages[] = '<font color=#80ff00>'.$gain.'의 경험치를 더 얻었다!!</font><br>';
    }
    if (ebs_battle_effect_has($vsW, 'b') && ebs_battle_rand255_gt(230)) {
        $gain = $vsExp > 100 ? ebs_battle_rand_int($vsMoneyTotal * 0.05) : 1;
        if ($gain > 1000) $gain = 1000;
        $vsExp = max(0, $vsExp - $gain);
        $plExp += $gain;
        $messages[] = '<font color=#80ff00>'.$gain.'의 경험치를 더 얻었다</font><br>';
    } elseif (ebs_battle_effect_has($vsW, 'b') && ebs_battle_rand255_gt(180)) {
        $loss = $plExp > 100 ? ebs_battle_rand_int($plMoneyTotal * 0.05) : 1;
        if ($loss > 1000) $loss = 1000;
        $plExp = max(0, $plExp - $loss);
        if (($vsExp + $loss) >= (((int)($vs['level'] ?? ebs_player_raw_get($vs,29,'1')) + 1) * 200 - 1)) $loss = 0;
        $vsExp += $loss;
        $messages[] = '<font color=#c22c2c>'.$loss.'의 경험치를 잃어버렸다</font><br>';
    }

    // HP 드레인.
    if (ebs_battle_effect_has($plW, '5') && ebs_battle_rand255_gt(200)) {
        $messages[] = '<font color=#80ff00>적의 HP를 흡수하였다!</font><br>';
        $drain = ($plMaxHp > $vsHpAfter) ? ebs_battle_rand_int($vsHpAfter * 0.3) : 0;
        $vsHpAfter -= $drain;
        $plHpAfter += $drain;
    }
    if (ebs_battle_effect_has($vsW, '5') && ebs_battle_rand255_gt(200)) {
        $messages[] = '<font color=#c22c2c>적에게 HP를 흡수당했다!</font><br>';
        $drain = ($vsMaxHp > $plHpAfter) ? ebs_battle_rand_int($plHpAfter * 0.3) : ebs_battle_rand_int($vsHpAfter * 0.3);
        $plHpAfter -= $drain;
        $vsHpAfter += $drain;
    }

    // EN 드레인.
    if (ebs_battle_effect_has($plW, '9') && ebs_battle_rand255_gt(200)) {
        $messages[] = '<font color=#80ff00>적의 EN을 흡수하였다!</font><br>';
        $drain = ($plMaxEn > $vsEnAfter) ? ebs_battle_rand_int($vsEnAfter * 0.1) : 0;
        $vsEnAfter -= $drain;
        $plEnAfter += $drain;
    }
    if (ebs_battle_effect_has($vsW, '9') && ebs_battle_rand255_gt(200)) {
        $messages[] = '<font color=#c22c2c>적에게 EN을 흡수당했다!</font><br>';
        $drain = ($vsMaxEn > $plEnAfter) ? ebs_battle_rand_int($plEnAfter * 0.3) : ebs_battle_rand_int($vsEnAfter * 0.3);
        $plEnAfter -= $drain;
        $vsEnAfter += $drain;
    }

    // 머니 드레인.
    if (ebs_battle_effect_has($plW, 'a') && ebs_battle_rand255_gt(230)) {
        $loss = $plMoneyTotal > 100 ? ebs_battle_rand_int($plMoneyTotal * 0.01) : 1;
        if ($loss > 1000) $loss = 1000;
        $plMoneyTotal -= $loss;
        $vsMoneyTotal += $loss;
        $messages[] = '<font color=#c22c2c>$'.$loss.'이 어디론가 사라졌다</font><br>';
    } elseif (ebs_battle_effect_has($plW, 'a') && ebs_battle_rand255_gt(180)) {
        $gain = $vsMoneyTotal > 100 ? ebs_battle_rand_int($vsMoneyTotal * 0.01) : 1;
        if ($gain > 1000) $gain = 1000;
        $vsMoneyTotal -= $gain;
        $plMoneyTotal += $gain;
        $messages[] = '<font color=#80ff00>적의 주머니에서 $'.$gain.'을 몰래 가져왔다!</font><br>';
    }
    if (ebs_battle_effect_has($vsW, 'a') && ebs_battle_rand255_gt(230)) {
        $gain = $vsMoneyTotal > 100 ? ebs_battle_rand_int($vsMoneyTotal * 0.01) : 1;
        if ($gain > 1000) $gain = 1000;
        $vsMoneyTotal -= $gain;
        $plMoneyTotal += $gain;
        $messages[] = '<font color=#80ff00>적의 주머니에서 $'.$gain.'이 떨어졌다!</font><br>';
    } elseif (ebs_battle_effect_has($vsW, 'a') && ebs_battle_rand255_gt(180)) {
        $loss = $plMoneyTotal > 100 ? ebs_battle_rand_int($plMoneyTotal * 0.01) : 1;
        if ($loss > 1000) $loss = 1000;
        $plMoneyTotal -= $loss;
        $vsMoneyTotal += $loss;
        $messages[] = '<font color=#c22c2c>$'.$loss.'이 어디론가 사라졌다</font><br>';
    }

    // 보강장비 Emergency Fix Kit.
    if (strpos((string)($plB[7] ?? ''), '6') !== false && $result !== 2) {
        $messages[] = '<font color=#dbdafe>Emergency Fix Kit가 작동하였다!</font><br>';
        $plHpAfter = (int)($plHpAfter + $plMaxHp * 0.5);
        $me['repair'] = '0';
        ebs_player_raw_set($me, 25, '0');
    }
    if (strpos((string)($vsB[7] ?? ''), '6') !== false && $result !== 2) {
        $messages[] = '<font color=#dbfcf7>Emergency Fix Kit가 작동하였다!</font><br>';
        $vsHpAfter = (int)($vsHpAfter + $vsMaxHp * 0.5);
        $vs['repair'] = '0';
        ebs_player_raw_set($vs, 25, '0');
    }

    $plHpAfter = max(0, $plHpAfter);
    $vsHpAfter = max(0, $vsHpAfter);
    $plEnAfter = max(0, $plEnAfter);
    $vsEnAfter = max(0, $vsEnAfter);
    return $messages;
}
function ebs_BATTLE2(): void {
    ebs_header_html();
    ebs_record_post('ebs_sub4.php::BATTLE2');
    ebs_bootstrap_runtime_counts();
    $pname = ebs_param('pname', ebs_cookie_value('pname', ''));
    $pass  = ebs_param('pass', ebs_cookie_value('pass', ''));
    $vsname = ebs_param('vsname');
    $bmode = ebs_param('b_mode', '전투');
    $mode = ebs_battle_normalize_mode(ebs_param('mode', ebs_param('battle_plan', '1')));
    @setcookie('EBMISSON', (string)$mode, time() + ((int)ebs_v('COOKIE_KEEP','1400') * 24 * 60 * 60));

    $battle = ebs_with_file_lock(ebs_file('data/battle_state'), LOCK_EX, static function () use ($pname, $pass, $vsname, $bmode, $mode): array {
        $players = ebs_players_load();
        $myKey = ebs_find_player_key($pname, $players);
        $vsKey = ebs_find_player_key($vsname, $players);
        if ($pname === '' || $myKey === null || !isset($players[$myKey]) || !is_array($players[$myKey])) return ['error'=>'자신의 등록 데이터를 찾을 수 없습니다.'];
        if (!ebs_password_matches($players[$myKey], $pass)) return ['error'=>'패스워드가 틀립니다.'];
        if ($vsname === '' || $vsKey === null || !isset($players[$vsKey]) || !is_array($players[$vsKey])) return ['error'=>'대전상대를 찾을 수 없습니다.'];

        $me = $players[$myKey];
        $vs = $players[$vsKey];
        $pname2 = (string)($me['name'] ?? $myKey);
        $vsname2 = (string)($vs['name'] ?? $vsKey);
        $now = time();
        $dateText = date('n월 j일 (H:i)', $now);
        $getMoney = max(1, (int)ebs_v('GET_MONEY','10'));
        $weaponLvup = max(1, (int)ebs_v('WEAPON_LVUP','100'));
        $maxWeaponLv = max(1, (int)ebs_v('MAX_WEAPONLV','100')) * 100;

        [$plWid, $plWlv, $plW] = ebs_legacy_weapon_parts($me);
        [$vsWid, $vsWlv, $vsW] = ebs_legacy_weapon_parts($vs);
        [$plBg, $plBgt, $plB] = ebs_legacy_bougu_parts($me);
        [$vsBg, $vsBgt, $vsB] = ebs_legacy_bougu_parts($vs);
        if (strpos((string)$plB[7], '8') !== false) $plW[1] = (int)$plW[1] + (int)$vsW[1];
        if (strpos((string)$vsB[7], '8') !== false) $vsW[1] = (int)$vsW[1] + (int)$plW[1];

        $plRank = ebs_player_rank_value($me);
        $vsRank = ebs_player_rank_value($vs);
        $plLevel = ebs_player_level_value($me);
        $vsLevel = ebs_player_level_value($vs);
        $plHpBefore = max(0, (int)ebs_player_raw_get($me, 15, (string)($me['hp'] ?? 4000)));
        $vsHpBefore = max(0, (int)ebs_player_raw_get($vs, 15, (string)($vs['hp'] ?? 4000)));
        $plMaxHp = max(1, (int)ebs_player_raw_get($me, 16, (string)($me['max_hp'] ?? max(1,$plHpBefore))));
        $vsMaxHp = max(1, (int)ebs_player_raw_get($vs, 16, (string)($vs['max_hp'] ?? max(1,$vsHpBefore))));
        $plEnBefore = max(0, (int)ebs_player_raw_get($me, 17, (string)($me['en'] ?? 200)));
        $vsEnBefore = max(0, (int)ebs_player_raw_get($vs, 17, (string)($vs['en'] ?? 200)));
        $plMaxEn = max(1, (int)ebs_player_raw_get($me, 18, (string)($me['max_en'] ?? max(1,$plEnBefore))));
        $vsMaxEn = max(1, (int)ebs_player_raw_get($vs, 18, (string)($vs['max_en'] ?? max(1,$vsEnBefore))));
        if ($plHpBefore <= 0 || ebs_player_raw_get($me,25,(string)($me['repair'] ?? '0')) !== '0') return ['error'=>'Repair 상태입니다. 수리 후 전투할 수 있습니다.'];
        if ($vsHpBefore <= 0 || ebs_player_raw_get($vs,25,(string)($vs['repair'] ?? '0')) !== '0') return ['error'=>'상대가 Repair 상태입니다.'];

        $plAtkPoint = (float)((int)$plW[1] * (($plWlv * 0.0001) + 1));
        $vsAtkPoint = (float)((int)$vsW[1] * (($vsWlv * 0.0001) + 1));
        $plStA=(int)ebs_player_raw_get($me,19,(string)(($me['st'][0] ?? 6))); $plStD=(int)ebs_player_raw_get($me,20,(string)(($me['st'][1] ?? 6))); $plStS=(int)ebs_player_raw_get($me,21,(string)(($me['st'][2] ?? 6))); $plStH=(int)ebs_player_raw_get($me,22,(string)(($me['st'][3] ?? 6)));
        $vsStA=(int)ebs_player_raw_get($vs,19,(string)(($vs['st'][0] ?? 6))); $vsStD=(int)ebs_player_raw_get($vs,20,(string)(($vs['st'][1] ?? 6))); $vsStS=(int)ebs_player_raw_get($vs,21,(string)(($vs['st'][2] ?? 6))); $vsStH=(int)ebs_player_raw_get($vs,22,(string)(($vs['st'][3] ?? 6)));
        $plbs = (strpos((string)$plW[7], '4') !== false) ? (int)($plStD + 7) : 0;
        $vsbs = (strpos((string)$vsW[7], '4') !== false) ? (int)($vsStD + 7) : 0;
        $plDefPoint = (float)(($plStD + $plbs + (int)$plB[1]) * 2 - (int)($vsStA / 3 + (int)$vsB[4]));
        $vsDefPoint = (float)(($vsStD + $vsbs + (int)$vsB[1]) * 2 - (int)($plStA / 3 + (int)$plB[4]));
        $plSpPoint = (float)($plStS - (int)$plB[2]);
        $vsSpPoint = (float)($vsStS - (int)$vsB[2]);
        $plMisPoint = (float)($plStH + (int)$plB[3]);
        $vsMisPoint = (float)($vsStH + (int)$vsB[3]);
        if (strpos((string)$plW[7], '3') !== false) $plSpPoint = (float)(int)($plSpPoint * 1.5);
        if (strpos((string)$vsW[7], '3') !== false) $vsSpPoint = (float)(int)($vsSpPoint * 1.5);
        if ($plMaxHp > 50000) $plSpPoint -= (int)(($plMaxHp - 50000) / 5000);
        if ($vsMaxHp > 50000) $vsSpPoint -= (int)(($vsMaxHp - 50000) / 5000);
        if (strpos((string)$plW[7], 'c') !== false) $plMisPoint *= 1.3;
        if (strpos((string)$vsW[7], 'c') !== false) $vsMisPoint *= 1.3;
        $plCount = max(1, (int)$plW[3]); $vsCount = max(1, (int)$vsW[3]);
        $plEnCost = max(0, (int)$plW[4]); $vsEnCost = max(0, (int)$vsW[4]);
        if ($plEnBefore < $plEnCost) return ['error'=>'EN부족'];
        if ($vsEnBefore < $vsEnCost) { $vsCount = 0; $vsEnCost = 0; }
        $plModeLabel = ebs_legacy_apply_mission($mode, $plAtkPoint, $plDefPoint, $plSpPoint, $plMisPoint, $plCount, $plEnCost);
        $vsMode = mt_rand(1, 8);
        $vsModeLabel = ebs_legacy_apply_mission($vsMode, $vsAtkPoint, $vsDefPoint, $vsSpPoint, $vsMisPoint, $vsCount, $vsEnCost);
        ebs_legacy_apply_chara(ebs_player_raw_get($me,12,(string)($me['chara'] ?? '')), $plAtkPoint, $plDefPoint, $plSpPoint, $plMisPoint);
        ebs_legacy_apply_chara(ebs_player_raw_get($vs,12,(string)($vs['chara'] ?? '')), $vsAtkPoint, $vsDefPoint, $vsSpPoint, $vsMisPoint);

        $plCounter=0; $vsCounter=0; $plHits=0; $vsHits=0; $plDamage=0; $vsDamage=0; $plIcons=[]; $vsIcons=[];
        for ($turn=1; $turn<100; $turn++) {
            if ($vsCounter >= $vsCount && $plCounter >= $plCount) break;
            $initiative = ($plSpPoint + mt_rand(0,29)) >= ($vsSpPoint + mt_rand(0,29));
            if ($vsDamage < $plHpBefore && $plCounter < $plCount && ($initiative || $vsCounter >= $vsCount)) {
                $check = (int)(mt_rand(0,99) + $vsSpPoint / 2 - $plMisPoint / 2);
                $plCounter++;
                if ($check < (float)$plW[2]) { $plIcons[] = true; $plHits++; $plDamage += (int)($plAtkPoint - (int)($vsDefPoint * mt_rand(90,139)) / max(1,$plCount)); }
                else $plIcons[] = false;
                continue;
            }
            if ($plDamage < $vsHpBefore && $vsCounter < $vsCount && (!$initiative || $plCounter >= $plCount)) {
                $check = (int)(mt_rand(0,99) + $plSpPoint / 2 - $vsMisPoint / 2);
                $vsCounter++;
                if ($check < (float)$vsW[2]) { $vsIcons[] = true; $vsHits++; $vsDamage += (int)($vsAtkPoint - (int)($plDefPoint * mt_rand(90,139)) / max(1,$vsCount)); }
                else $vsIcons[] = false;
                continue;
            }
        }
        if ($plDamage < 0) $plDamage = 0;
        if ($vsDamage < 0) $vsDamage = 0;
        $plDamage = min($plDamage, $vsHpBefore);
        $vsDamage = min($vsDamage, $plHpBefore);
        $plHpAfter = max(0, $plHpBefore - $vsDamage);
        $vsHpAfter = max(0, $vsHpBefore - $plDamage);
        $plEnSpend = $plHits > 0 ? $plEnCost : (int)($plEnCost/2);
        $vsEnSpend = $vsHits > 0 ? $vsEnCost : (int)($vsEnCost/2);
        $plEnAfter = max(0, $plEnBefore - $plEnSpend);
        $vsEnAfter = max(0, $vsEnBefore - $vsEnSpend);
        $plHpBattleAfter = $plHpAfter;
        $vsHpBattleAfter = $vsHpAfter;
        $plEnBattleAfter = $plEnAfter;
        $vsEnBattleAfter = $vsEnAfter;
        if ($vsHpAfter === 0 && $plHpAfter > 0) $result = 0;
        elseif ($plHpAfter === 0 && $vsHpAfter > 0) $result = 1;
        else $result = 2;

        if ($result === 0) { $plRankDelta=1.5; $vsRankDelta=-1; $plWeaponGain=mt_rand(4,5); $vsWeaponGain=mt_rand(2,3); $plMoney=mt_rand(200,299)+((100-$plLevel)*$getMoney); $vsMoney=mt_rand(200,299)+((100-$vsLevel)*(int)($getMoney/2)); }
        elseif ($result === 1) { $plRankDelta=-1; $vsRankDelta=1.5; $plWeaponGain=mt_rand(2,6); $vsWeaponGain=mt_rand(8,12); $plMoney=mt_rand(400,599)+((250-$plLevel)*(int)($getMoney/3)); $vsMoney=mt_rand(400,599)+((250-$vsLevel)*$getMoney); }
        else { $plRankDelta=0.5; $vsRankDelta=0.5; $plWeaponGain=mt_rand(4,6); $vsWeaponGain=mt_rand(4,6); $plMoney=mt_rand(400,599); $vsMoney=mt_rand(400,599); }
        if ($plMoney < 10) $plMoney = 10;
        if ($vsMoney < 10) $vsMoney = 10;
        if ((string)ebs_player_raw_get($me,5,(string)($me['kuni'] ?? '')) !== '') $plMoney += (int)($plRank * 4 + 20);
        $luckMsg = '';
        if (strpos((string)$plB[7], '7') !== false) { $plMoney *= 2; $plWeaponGain *= 2; $luckMsg = '<font color=yellow>행운의 여신이 축복을 내렸다!</font><br>'; }
        if ((string)ebs_v('event','0') === '1') { $plMoney *= 2; $plWeaponGain *= 2; }
        $expGain = (int)($plWeaponGain * ($vsRank + 1));
        if ($expGain < 0) $expGain = 0;

        $plRankNew = max(0, min(215, $plRank + $plRankDelta));
        $vsRankNew = max(0, min(215, $vsRank + $vsRankDelta));
        if (ebs_player_raw_get($me,6,(string)($me['job'] ?? '')) === '1') $plRankNew = 220;
        if (ebs_player_raw_get($vs,6,(string)($vs['job'] ?? '')) === '1') $vsRankNew = 220;

        $plExp = max(0, (int)ebs_player_raw_get($me,30,(string)($me['level_exp'] ?? 0)) + $expGain);
        $vsExp = max(0, (int)ebs_player_raw_get($vs,30,(string)($vs['level_exp'] ?? 0)));
        $plMoneyTotal = (int)ebs_player_raw_get($me,8,(string)($me['money'] ?? 0)) + $plMoney;
        $vsMoneyTotal = (int)ebs_player_raw_get($vs,8,(string)($vs['money'] ?? 0)) + $vsMoney;

        $plWin=(int)ebs_player_raw_get($me,41,(string)($me['win'] ?? 0)); $plLose=(int)ebs_player_raw_get($me,42,(string)($me['lose'] ?? 0));
        $vsWin=(int)ebs_player_raw_get($vs,41,(string)($vs['win'] ?? 0)); $vsLose=(int)ebs_player_raw_get($vs,42,(string)($vs['lose'] ?? 0));
        if ($result === 0) { $plWin++; $vsLose++; $vs['repair']='1'; }
        if ($result === 1) { $plLose++; $vsWin++; $me['repair']='1'; }
        if ($result === 2) { /* 원본은 무승부일 때 양측 출격 가능 상태를 유지한다. */ }

        $specialMessages = ebs_battle_apply_special_effects($me, $vs, $plW, $vsW, $plB, $vsB, $result, $plHpAfter, $vsHpAfter, $plEnAfter, $vsEnAfter, $plMaxHp, $vsMaxHp, $plMaxEn, $vsMaxEn, $plExp, $vsExp, $plMoneyTotal, $vsMoneyTotal);

        $levelUp = false;
        if (($plLevel + 1) * 500 <= $plExp) { $plExp = 0; $plLevel++; $levelUp = true; }
        $plWlvNew = min($maxWeaponLv, $plWlv + $plWeaponGain);
        $vsWlvNew = min($maxWeaponLv, $vsWlv + $vsWeaponGain);
        $plWeaponLevelUp = ((int)($plWlvNew / $weaponLvup) > (int)($plWlv / $weaponLvup)) && $plWlvNew < $maxWeaponLv;
        $vsWeaponLevelUp = ((int)($vsWlvNew / $weaponLvup) > (int)($vsWlv / $weaponLvup)) && $vsWlvNew < $maxWeaponLv;

        $me['rank']=$plRankNew; $vs['rank']=$vsRankNew;
        $me['level']=$plLevel; $vs['level']=$vsLevel;
        $me['hp']=$plHpAfter; $vs['hp']=$vsHpAfter;
        $me['en']=$plEnAfter; $vs['en']=$vsEnAfter;
        $me['money']=$plMoneyTotal;
        $vs['money']=$vsMoneyTotal;
        $me['level_exp']=$plExp; $me['exp']=$plExp;
        $vs['level_exp']=$vsExp; $vs['exp']=$vsExp;
        $me['weapon']=$plWid.'!'.$plWlvNew; $vs['weapon']=$vsWid.'!'.$vsWlvNew;
        $me['win']=$plWin; $me['lose']=$plLose; $vs['win']=$vsWin; $vs['lose']=$vsLose;
        $me['last_access']=(string)$now;
        $me['online_seen']=(string)$now;
        // 상대는 전투 저장만 갱신하고 접속자로 표시하지 않는다.
        $vs['last_access']=(string)$now;
        $me['recovery_at']=(string)$now; $vs['recovery_at']=(string)$now;
        $me['battle_log']=$dateText.' '.$pname2.'와'.$vsname2.'교전'.($result===0 ? $vsname2.'대파' : ($result===1 ? $pname2.'대파' : ''));
        $vs['battle_log']=$dateText.' '.$pname2.'와'.$vsname2.'교전'.($result===0 ? $vsname2.'대파' : ($result===1 ? $pname2.'대파' : ''));
        ebs_player_raw_set($me,1,(string)$me['battle_log']); ebs_player_raw_set($vs,1,(string)$vs['battle_log']);
        ebs_player_raw_set($me,26,(string)$now); ebs_player_raw_set($vs,26,(string)$now);
        ebs_player_raw_set($me,35,(string)($_SERVER['REMOTE_ADDR'] ?? ''));

        $dropMessages = [];
        if ($result === 0) {
            $weapons = ebs_weapon_table();
            if (ebs_player_raw_get($me,10,(string)($me['weapon2'] ?? '')) === '') { $drop = ebs_legacy_pick_drop($weapons); if ($drop !== '') { $me['weapon2']=$drop; ebs_player_raw_set($me,10,$drop); $dropMessages[]='<font color="#f7e957">무기를 획득</font><br>'; } }
            elseif (ebs_player_raw_get($me,11,(string)($me['weapon3'] ?? '')) === '') { $drop = ebs_legacy_pick_drop($weapons); if ($drop !== '') { $me['weapon3']=$drop; ebs_player_raw_set($me,11,$drop); $dropMessages[]='<font color="#f7e957">무기를 획득</font><br>'; } }
            if (ebs_player_raw_get($me,32,(string)($me['armor'] ?? '')) === '') { $drop = ebs_legacy_pick_drop(ebs_bougu_table(), 6); if ($drop !== '') { $me['armor']=$drop; ebs_player_raw_set($me,32,$drop); $dropMessages[]='<font color="#f7e957">보강장비 획득</font><br>'; } }
        }
        if (!isset($me['event_log']) || !is_array($me['event_log'])) $me['event_log']=[];
        $me['event_log'][]=['type'=>'battle','enemy'=>$vsname2,'result'=>$result===0?'win':($result===1?'lose':'draw'),'mode'=>$mode,'hit'=>$plHits,'attack'=>$plCount,'damage'=>$plDamage,'exp'=>$expGain,'weapon_exp'=>$plWeaponGain,'money'=>$plMoney,'time'=>date('YmdHis',$now)];
        if (count($me['event_log'])>80) $me['event_log']=array_slice($me['event_log'],-80);
        ebs_player_sync_common($me); ebs_player_sync_common($vs);
        $players[$myKey]=$me; $players[$vsKey]=$vs;
        ebs_players_save($players);

        return compact('me','vs','pname2','vsname2','bmode','mode','plModeLabel','vsModeLabel','plWid','vsWid','plW','vsW','plWlv','vsWlv','plWlvNew','vsWlvNew','plHpBefore','vsHpBefore','plHpAfter','vsHpAfter','plHpBattleAfter','vsHpBattleAfter','plMaxHp','vsMaxHp','plEnBefore','vsEnBefore','plEnAfter','vsEnAfter','plEnBattleAfter','vsEnBattleAfter','plMaxEn','vsMaxEn','plEnSpend','vsEnSpend','plCount','vsCount','plHits','vsHits','plDamage','vsDamage','plIcons','vsIcons','result','plRank','vsRank','plRankNew','vsRankNew','plLevel','vsLevel','levelUp','plWeaponGain','vsWeaponGain','plWeaponLevelUp','vsWeaponLevelUp','expGain','plMoney','luckMsg','dropMessages','specialMessages','dateText');
    });
    if (!is_array($battle)) { ebs_error_page('Error', '전투 저장 잠금을 얻지 못했습니다.'); return; }
    if (isset($battle['error'])) { ebs_error_page('Error', (string)$battle['error']); return; }
    extract($battle, EXTR_SKIP);

    $plCountry=(string)($me['kuni'] ?? ebs_v('NONE_NATIONALITY')); if ($plCountry==='') $plCountry=ebs_v('NONE_NATIONALITY');
    $vsCountry=(string)($vs['kuni'] ?? ebs_v('NONE_NATIONALITY')); if ($vsCountry==='') $vsCountry=ebs_v('NONE_NATIONALITY');
    $plCountryColor=(string)($me['country_color'] ?? '#808080');
    $vsCountryColor=(string)($vs['country_color'] ?? '#808080');
    $plRankTag=ebs_legacy_rank_label((float)$plRank, (string)($me['kuni'] ?? ''), (string)($me['job'] ?? ''), (string)($me['skill'] ?? ''));
    $vsRankTag=ebs_legacy_rank_label((float)$vsRank, (string)($vs['kuni'] ?? ''), (string)($vs['job'] ?? ''), (string)($vs['skill'] ?? ''));
    $plWeaponTitle=(string)$plW[0].'(Level.'.(int)($plWlv / max(1,(int)ebs_v('WEAPON_LVUP','100'))).')';
    $vsWeaponTitle=(string)$vsW[0].'(Level.'.(int)($vsWlv / max(1,(int)ebs_v('WEAPON_LVUP','100'))).')';
    $plSummary=ebs_legacy_battle_summary((int)$plCount,(int)$plHits,(int)$plDamage);
    $vsSummary=ebs_legacy_battle_summary((int)$vsCount,(int)$vsHits,(int)$vsDamage);
    $chaStyl='style="font-size:12px;color:#dc143c;"';
    $resultTag='';
    if ((float)$plRankNew !== (float)$plRank) $resultTag .= ebs_h($pname2).' 이/가 계급 '.(((float)$plRankNew > (float)$plRank) ? '상승' : '하락').'<br>';
    if ((float)$vsRankNew !== (float)$vsRank) $resultTag .= ebs_h($vsname2).' 이/가 계급 '.(((float)$vsRankNew > (float)$vsRank) ? '상승' : '하락').'<br>';
    if ($result === 0) $resultTag .= ebs_h((string)($vs['msname'] ?? $vsname2)).'대파<br>';
    elseif ($result === 1) $resultTag .= ebs_h((string)($me['msname'] ?? $pname2)).'대파<br>';
    $resultTag .= (string)$luckMsg;
    $resultTag .= ebs_h($pname2).' (이/가) '.(int)$expGain.' 의 경험치를 습득 / '.(int)$plWeaponGain.' 의 무기경험치를 습득<br>';
    $resultTag .= '$'.(int)$plMoney.'의 골드를 얻었습니다<br>';
    if ($levelUp) $resultTag .= '<font color=#f7e957>'.ebs_h($pname2).' (이/가) 레벨이 올랐습니다</font><br>';
    if ($plWeaponLevelUp) $resultTag .= '<font color=#f7e957>'.ebs_h($pname2).'의 '.ebs_h((string)$plW[0]).' 이/가 레벨업</font><br>';
    foreach ($dropMessages as $m) $resultTag .= $m;
    if (isset($specialMessages) && is_array($specialMessages)) foreach ($specialMessages as $m) $resultTag .= $m;

    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>ENDLESS BATTLE</title></head>';
    echo '<body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="margin:0px;" oncontextmenu="return false;">';
    echo '<div align=center>';
    echo '<table border=0 bgcolor=#000000 width=80% cellspacing=0 cellpadding=0>';
    echo '<tr><td align=center width=50% bgcolor="'.ebs_h($plCountryColor).'" style="color:#000000;font-size:25pt;"><b>'.ebs_h($plCountry).'</b></td><td align=center width=50% bgcolor="'.ebs_h($vsCountryColor).'" style="color:#000000;font-size:25pt;"><b>'.ebs_h($vsCountry).'</b></td></tr>';
    echo '<tr><td align=center width=50%><font color="'.ebs_h((string)($me['color'] ?? '#ffffff')).'" style="font-size:18pt;">'.ebs_h((string)($me['msname'] ?? $pname2)).'</font><br><div style="font-size:15px;">「'.ebs_h($pname2).$plRankTag.'機」</div></td><td align=center width=50%><font color="'.ebs_h((string)($vs['color'] ?? '#ffffff')).'" style="font-size:18pt;">'.ebs_h((string)($vs['msname'] ?? $vsname2)).'</font><br><div style="font-size:15px;">「'.ebs_h($vsname2).$vsRankTag.'機」</div></td></tr>';
    echo '<tr><td align=center width=50% height=100 valign=bottom><div align=center><marquee behavior=slide scrolldelay=10 scrollamount=10 loop=1 direction=right><img src="'.ebs_h(ebs_v('IMG_FOLDER2')).'/'.ebs_h(ebs_normalize_icon((string)($me['icon'] ?? '1'))).'.gif"></marquee></div><div style="font-size:15px;">【'.ebs_h($plModeLabel).'】<br><font color="'.ebs_h((string)($me['color'] ?? '#ffffff')).'">'.ebs_h((string)($me['comment'] ?? '')).'</font></div><table border=0 cellspacing=0 cellpadding=1><tr><td style="font-size:15px;"><b>HP</b>&nbsp;</td><td>'.ebs_battle_bar_img((int)$plHpBefore,(int)$plHpBattleAfter,(int)$plMaxHp,'hp').'</td><td width=50 align=right style="font-size:14px;"><span id=cplhp>'.(int)$plHpBefore.'</span></td><td style="font-size:14px;">/<b>'.(int)$plMaxHp.'</b></td></tr><tr><td style="font-size:15px;"><b>EN</b>&nbsp;</td><td>'.ebs_battle_bar_img((int)$plEnBefore,(int)$plEnBattleAfter,(int)$plMaxEn,'en').'</td><td width=50 align=right style="font-size:14px;"><span id=cplen>'.(int)$plEnBefore.'</span></td><td style="font-size:14px;">/<b>'.(int)$plMaxEn.'</b></td></tr></table></td>';
    echo '<td align=center width=50% height=100 valign=bottom><div align=center><marquee behavior=slide scrolldelay=10 scrollamount=10 loop=1 direction=left><img src="'.ebs_h(ebs_v('IMG_FOLDER2')).'/'.ebs_h(ebs_normalize_icon((string)($vs['icon'] ?? '1'))).'.gif" style="filter:fliph();"></marquee></div><div style="font-size:15px;">【'.ebs_h($vsModeLabel).'】<br><font color="'.ebs_h((string)($vs['color'] ?? '#ffffff')).'">'.ebs_h((string)($vs['comment'] ?? '')).'</font></div><table border=0 cellspacing=0 cellpadding=1><tr><td style="font-size:15px;"><b>HP</b>&nbsp;</td><td>'.ebs_battle_bar_img((int)$vsHpBefore,(int)$vsHpBattleAfter,(int)$vsMaxHp,'hp').'</td><td width=50 align=right style="font-size:14px;"><span id=cvshp>'.(int)$vsHpBefore.'</span></td><td style="font-size:14px;">/<b>'.(int)$vsMaxHp.'</b></td></tr><tr><td style="font-size:15px;"><b>EN</b>&nbsp;</td><td>'.ebs_battle_bar_img((int)$vsEnBefore,(int)$vsEnBattleAfter,(int)$vsMaxEn,'en').'</td><td width=50 align=right style="font-size:14px;"><span id=cvsen>'.(int)$vsEnBefore.'</span></td><td style="font-size:14px;">/<b>'.(int)$vsMaxEn.'</b></td></tr></table></td></tr>';
    echo '<tr><td align=center valign=top width=40%><font color=#778899 style="font-size:16px;"><img src="'.ebs_h(ebs_battle_weapon_image($plW)).'"><b>'.ebs_h($plWeaponTitle).'</b></font><div align=center>'.ebs_legacy_hit_icons((int)$plCount,$plIcons).'<div align=center>'.$plSummary.'<br><b '.$chaStyl.'>EN:-'.(int)$plEnSpend.'</b></div></td><td align=center valign=top width=40%><font color=#778899 style="font-size:16px;"><img src="'.ebs_h(ebs_battle_weapon_image($vsW)).'"><b>'.ebs_h($vsWeaponTitle).'</b></font><div align=center>'.ebs_legacy_hit_icons((int)$vsCount,$vsIcons).'<div align=center>'.$vsSummary.'<br><b '.$chaStyl.'>EN:-'.(int)$vsEnSpend.'</b></div></td></tr></table>';
    echo '<div style="line-height:4pt;">&nbsp;</div><table><tr><td bgcolor=#000000 style="line-height:18px;font-size:14px;">'.$resultTag;
    echo '<script language="JavaScript">timeID=10;timeID2=10;cdplhp=Math.round(('.(int)$plHpBefore.'-'.(int)$plHpBattleAfter.')*0.1);cdvshp=Math.round(('.(int)$vsHpBefore.'-'.(int)$vsHpBattleAfter.')*0.1);cdplen=Math.round(('.(int)$plEnBefore.'-'.(int)$plEnBattleAfter.')*0.1);cdvsen=Math.round(('.(int)$vsEnBefore.'-'.(int)$vsEnBattleAfter.')*0.1);flaga=flagb=flagc=0;flagae=flagbe=flagce=0;setTimeout("HEcount()",2500);setTimeout("EEcount() ",2500);function HEcount(){cplhp.innerText-=cdplhp;cvshp.innerText-=cdvshp;if(eval(cplhp.innerText)<='.(int)$plHpBattleAfter.'){cplhp.innerText="'.(int)$plHpBattleAfter.'";flaga=1;}if(eval(cvshp.innerText)<='.(int)$vsHpBattleAfter.'){cvshp.innerText="'.(int)$vsHpBattleAfter.'";flagb=1;}clearTimeout(timeID);if(!flaga||!flagb){timeID=setTimeout("HEcount()",1);}}function EEcount(){cplen.innerText-=cdplen;cvsen.innerText-=cdvsen;if(eval(cplen.innerText)<='.(int)$plEnBattleAfter.'){cplen.innerText="'.(int)$plEnBattleAfter.'";flagae=1;}if(eval(cvsen.innerText)<='.(int)$vsEnBattleAfter.'){cvsen.innerText="'.(int)$vsEnBattleAfter.'";flagbe=1;}clearTimeout(timeID2);if(!flagae||!flagbe){timeID2=setTimeout("EEcount() ",1);}}</script>';
    if ($result === 2) {
        echo '</td></tr></table><table border=0 bordercolor=#333333 bgcolor="'.ebs_h(ebs_v('BG_STATUS')).'" cellspacing=0><form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method=POST><input type=hidden name="cmd" value="BATTLE_2"><input type=hidden name="pname" value="'.ebs_h($pname2).'"><input type=hidden name="vsname" value="'.ebs_h($vsname2).'"><input type=hidden name="pass" value="'.ebs_h($pass).'"><input type=hidden name="b_mode" value="'.ebs_h($bmode).'"><input type=hidden name="check" value="'.time().'"><tr><td><b '.$chaStyl.'> </b><br>'.ebs_battle_plan_select((string)$mode, ebs_player_level_value($me)).'<input type=submit value="재전투" '.ebs_v('STYLE_B1').'></td></form>';
    } else {
        echo '</td></tr></table><table border=0 bordercolor=#333333 bgcolor="'.ebs_h(ebs_v('BG_STATUS')).'" cellspacing=0><form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method=POST target=Main><input type=hidden name=cmd value=MAIN_FRAME><input type=hidden name=pname value="'.ebs_h($pname2).'"><input type=hidden name=pass value="'.ebs_h($pass).'"><tr><td><b '.$chaStyl.'> </b><br><input type=submit value="귀환" '.ebs_v('STYLE_B1').' onClick="parent.Sub.location.replace(\''.ebs_h(ebs_v('MAIN_SCRIPT')).'?LOGO\');"></td></form>';
    }
    echo '</table></div></body></html>';
}


function ebs_HiddenTAG(): void {
    // 원본 HiddenTAG: 전투 폼의 hidden 값 출력 보조. PHP에서는 현재 입력값을 안전하게 재출력한다.
    $pname = ebs_param('pname', ebs_cookie_value('pname', ''));
    $pass = ebs_param('pass', ebs_cookie_value('pass', ''));
    echo '<input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'">';
}

function ebs_FILTING(): void {
    // 원본 FILTING: 전투 대상 필터 보조. 단독 호출 시 전투 대상 화면으로 돌린다.
    ebs_BATTLE1();
}

$map = [
    'BATTLE1' => 'ebs_BATTLE1',
    'HiddenTAG' => 'ebs_HiddenTAG',
    'FILTING' => 'ebs_FILTING',
    'BATTLE2' => 'ebs_BATTLE2',
    'DOWN' => 'ebs_DOWN',
    'SYUSEI' => 'ebs_SYUSEI',
    '__TOP__' => 'ebs_top_level_output',
];
ebs_dispatch($map, 'ebs_BATTLE1');
?>
