<?php
declare(strict_types=1);
require_once __DIR__ . '/lib_ebs.php';
/**
 * 원본 legacy 파일: d_mainte.php
 * PHP 8.4 지하감옥 관리 페이지.
 */
$cmd = ebs_cmd('TOP');
$public = ['TOP','LOGOUT'];
if (!in_array($cmd, $public, true) && !ebs_admin_ok()) { ebs_admin_login_form(basename(__FILE__), '운영 관리'); return; }
switch ($cmd) {
    case 'LOGOUT':
        ebs_admin_logout();
        break;
    case 'TOP':
        if (ebs_admin_ok()) { ebs_admin_dungeon_screen('d_mainte.php'); }
        else { ebs_admin_login_form('d_mainte.php','지하감옥 관리'); }
        break;
    case 'MAINTE':
    case 'MAINTE2':
        if (ebs_admin_ok()) { ebs_admin_dungeon_screen('d_mainte.php'); }
        else { ebs_admin_login_form('d_mainte.php','지하감옥 관리'); }
        break;
    case 'DUNGEONS':
        ebs_admin_dungeon_screen('d_mainte.php');
        break;
    case 'DUNGEON_EDIT':
        ebs_admin_dungeon_edit_screen('d_mainte.php');
        break;
    case 'BUILD':
        ebs_admin_dungeon_save();
        break;
    case 'SETUMEI':
        ebs_admin_dungeon_help_screen('d_mainte.php');
        break;
    case 'MONSTER_DATA':
        ebs_admin_dungeon_monster_data_screen('d_mainte.php');
        break;
    case 'MONSTER_SAVE':
        ebs_admin_dungeon_monster_save();
        break;
    default:
        ebs_admin_dungeon_screen('d_mainte.php');
        break;
}
?>
