<?php
declare(strict_types=1);
require_once __DIR__ . '/lib_ebs.php';
/**
 * 원본 legacy 파일: member.php
 * 참전자 표시를 PHP 8.4 user/*.json 기준으로 출력한다.
 */
function ebs_MEMBER(): void {
    ebs_header_html();
    ebs_record_post('member.php::MEMBER');
    $players = ebs_players_load();
    $timer = max(1, (int)ebs_param('timer', '60'));
    $now = time();
    $rows = [];
    foreach ($players as $key=>$p) {
        if (!is_array($p)) continue;
        $ts = ebs_player_time_value($p);
        $active = $ts > 0 && ($now - $ts) <= ($timer * 60);
        $rows[] = ['name'=>(string)($p['name'] ?? $key), 'country'=>(string)($p['kuni'] ?? ebs_v('NONE_NATIONALITY')), 'msname'=>(string)($p['msname'] ?? ''), 'icon'=>ebs_normalize_icon((string)($p['icon'] ?? '1'), '1'), 'time'=>$ts, 'active'=>$active];
    }
    usort($rows, static function(array $a, array $b): int { return ((int)$b['time']) <=> ((int)$a['time']); });
    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>ENDLESS BATTLE</title></head><body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="margin:0;font-size:13px;" oncontextmenu="return false;">';
    echo '<table width="100%" height="100%"><tr><td align="center"><table cellspacing="2" cellpadding="3" bgcolor="#909090" style="font-size:16px;" border="1">';
    echo '<tr><td bgcolor="#404040" colspan="6"><center><b>'.ebs_h((string)$timer).' 분 이내의 참전 상황</b></center></td></tr>';
    echo '<tr bgcolor="#404040"><td>No</td><td>파일럿</td><td>소속</td><td>기체</td><td>아이콘</td><td>상태</td></tr>';
    $count = 0;
    foreach ($rows as $row) {
        if (!$row['active']) continue;
        $count++;
        echo '<tr style="color:#000000;background:#f7f7f7;"><td nowrap align="right">'.ebs_h((string)$count).'</td><td nowrap>'.ebs_h((string)$row['name']).'</td><td nowrap>【'.ebs_h((string)($row['country'] ?: ebs_v('NONE_NATIONALITY'))).'】소속</td><td nowrap>'.ebs_h((string)$row['msname']).'기</td><td nowrap align="center"><img src="'.ebs_h(ebs_v('IMG_FOLDER2')).'/'.ebs_h((string)$row['icon']).'.gif" width="32" height="32"></td><td>참전중</td></tr>';
    }
    if ($count === 0) echo '<tr style="color:#000000;background:#f7f7f7;"><td colspan="6" align="center">현재 참전자는 없습니다.</td></tr>';
    echo '<tr><td colspan="6"><form action="member.php" method="POST" target="Sub"><input type="hidden" name="cmd" value="MEMBER"><input type="hidden" name="timer" value="'.ebs_h((string)$timer).'"><input type="submit" value="갱신" '.ebs_v('STYLE_B2').'></form></td></tr>';
    echo '</table><br>참가자 표시 : EDIT BY <a href="http://members.jcom.home.ne.jp/masimaro/">MASIMARO</a></td></tr></table></body></html>';
}
$map = ['MEMBER' => 'ebs_MEMBER'];
ebs_dispatch($map, 'ebs_MEMBER');
?>
