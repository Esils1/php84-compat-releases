<?php
declare(strict_types=1);
require_once __DIR__ . '/lib_ebs.php';
/** 아이템 시스템: user/*.json items와 data/itemsys_market.json 기반. */
function ebs_item_names(): array { return ['hukubiki'=>'제비뽑기권','hojoken'=>'제비뽑기 보조권','repair_hp'=>'HP수리권','repair_en'=>'EN수리권','boost'=>'강화부품']; }
function ebs_item_prices(): array { return ['hukubiki'=>50000,'hojoken'=>10000,'repair_hp'=>30000,'repair_en'=>15000,'boost'=>100000]; }
function ebs_item_start(string $title='아이템'): void { ebs_header_html(); echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>'.ebs_h($title).'</title></head><body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="margin:8px;font-size:13px;"><center><table border="1" cellspacing="0" cellpadding="5" bordercolor="'.ebs_h(ebs_v('TABLE_BORDER')).'" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" style="min-width:700px;font-size:13px;"><tr><td colspan="5" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'" align="center"><b>'.ebs_h($title).'</b></td></tr>'; }
function ebs_item_end(): void { echo '</table></center></body></html>'; }
function ebs_item_hidden(): string { return '<input type="hidden" name="pname" value="'.ebs_h(ebs_param('pname', ebs_cookie_value('pname',''))).'"><input type="hidden" name="pass" value="'.ebs_h(ebs_param('pass', ebs_cookie_value('pass',''))).'">'; }
function ebs_ITEM(): void {
    $p=ebs_current_player(); $items=is_array($p['items']??null)?$p['items']:[]; $names=ebs_item_names(); $prices=ebs_item_prices();
    ebs_item_start('아이템 창고');
    echo '<tr bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'"><td>아이템</td><td>보유</td><td>상점가</td><td>구입</td><td>판매</td></tr>';
    foreach($names as $id=>$name){ echo '<tr><td>'.ebs_h($name).'</td><td align="right">'.number_format((int)($items[$id]??0)).'</td><td align="right">'.number_format((int)($prices[$id]??0)).' G</td><td><form method="post" action="itemsys.php" style="margin:0">'.ebs_item_hidden().'<input type="hidden" name="cmd" value="KOUNYU3"><input type="hidden" name="item" value="'.ebs_h($id).'">수량 <input name="num" value="1" size="3" '.ebs_v('STYLE_L').'> <input type="submit" value="구입" '.ebs_v('STYLE_B1').'></form></td><td><form method="post" action="itemsys.php" style="margin:0">'.ebs_item_hidden().'<input type="hidden" name="cmd" value="ITEM_SELL"><input type="hidden" name="item" value="'.ebs_h($id).'">수량 <input name="num" value="1" size="3" '.ebs_v('STYLE_L').'> <input type="submit" value="판매" '.ebs_v('STYLE_B1').'></form></td></tr>'; }
    echo '<tr><td colspan="5"><a href="itemsys.php?cmd=SELLHIS">거래 기록</a></td></tr>'; ebs_item_end();
}
function ebs_ITEM3(): void { ebs_ITEM(); }
function ebs_KOJIN(): void { ebs_ITEM(); }
function ebs_KOUNYU3(): void {
    $GLOBALS['EBS_DISABLE_AUTO_POST_SAVE'] = true;
    [$key,$me,$players,$err]=ebs_require_player(); if($err!==''||$key===null||!is_array($me)){ ebs_error_page('아이템 오류',$err); return; }
    $item=ebs_param('item',''); $num=max(1,(int)ebs_param('num','1')); $prices=ebs_item_prices(); if(!isset($prices[$item])){ ebs_error_page('아이템 오류','존재하지 않는 아이템입니다.'); return; }
    $cost=$prices[$item]*$num; if((int)($me['money']??0)<$cost){ ebs_error_page('아이템 오류','소지금이 부족합니다.'); return; }
    if(!isset($me['items'])||!is_array($me['items']))$me['items']=[]; $me['money']=(int)$me['money']-$cost; $me['items'][$item]=(int)($me['items'][$item]??0)+$num; ebs_player_sync_common($me); $players[$key]=$me; ebs_players_save($players); ebs_item_log($key,'구입',$item,$num,$cost); ebs_ITEM();
}
function ebs_ITEM_SELL(): void {
    $GLOBALS['EBS_DISABLE_AUTO_POST_SAVE'] = true;
    [$key,$me,$players,$err]=ebs_require_player(); if($err!==''||$key===null||!is_array($me)){ ebs_error_page('아이템 오류',$err); return; }
    $item=ebs_param('item',''); $num=max(1,(int)ebs_param('num','1')); $prices=ebs_item_prices(); if(!isset($prices[$item])){ ebs_error_page('아이템 오류','존재하지 않는 아이템입니다.'); return; }
    if(!isset($me['items'])||!is_array($me['items']))$me['items']=[]; if((int)($me['items'][$item]??0)<$num){ ebs_error_page('아이템 오류','보유 수량이 부족합니다.'); return; }
    $gain=(int)floor($prices[$item]*$num*0.5); $me['items'][$item]=(int)$me['items'][$item]-$num; $me['money']=(int)($me['money']??0)+$gain; ebs_player_sync_common($me); $players[$key]=$me; ebs_players_save($players); ebs_item_log($key,'판매',$item,$num,$gain); ebs_ITEM();
}
function ebs_item_log(string $p,string $type,string $item,int $num,int $money): void { $l=ebs_json_load('itemsys_log'); $l[]=['time'=>date('Y-m-d H:i:s'),'pname'=>$p,'type'=>$type,'item'=>$item,'num'=>$num,'money'=>$money]; if(count($l)>100)$l=array_slice($l,-100); ebs_json_save('itemsys_log',$l); }
function ebs_SELLHIS(): void { ebs_item_start('아이템 거래 기록'); echo '<tr><td>시간</td><td>파일럿</td><td>구분</td><td>아이템</td><td>금액</td></tr>'; foreach(array_reverse(array_slice(ebs_json_load('itemsys_log'),-50)) as $r) echo '<tr><td>'.ebs_h((string)($r['time']??'')).'</td><td>'.ebs_h((string)($r['pname']??'')).'</td><td>'.ebs_h((string)($r['type']??'')).'</td><td>'.ebs_h((string)($r['item']??'')).' x '.ebs_h((string)($r['num']??'')).'</td><td align="right">'.number_format((int)($r['money']??0)).'</td></tr>'; ebs_item_end(); }
function ebs_ITEM_CONVERT(): void { ebs_ITEM(); }
function ebs_set_cookie(): void { ebs_ITEM(); }
function ebs_get_cookie(): void { ebs_ITEM(); }
function ebs_cookie_ch(): void { ebs_ITEM(); }
$map=['ITEM'=>'ebs_ITEM','ITEM3'=>'ebs_ITEM3','ITEM_SELL'=>'ebs_ITEM_SELL','KOJIN'=>'ebs_KOJIN','KOUNYU3'=>'ebs_KOUNYU3','SELLHIS'=>'ebs_SELLHIS','ITEM_CONVERT'=>'ebs_ITEM_CONVERT','set_cookie'=>'ebs_set_cookie','get_cookie'=>'ebs_get_cookie','cookie_ch'=>'ebs_cookie_ch'];
ebs_dispatch($map,'ebs_ITEM');
?>
