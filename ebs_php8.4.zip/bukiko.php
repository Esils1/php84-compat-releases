<?php
declare(strict_types=1);
require_once __DIR__ . '/lib_ebs.php';
/**
 * 원본 legacy 파일: bukiko.php
 * PHP 8.4 파일당 1:1 대응 변환 파일.
 * 원본 주석은 PHP // 주석으로 보존하고, 기존 실행 의존은 제거하고 PHP 8.4 파일 기반으로 동작시킨다.
 * 유지보수 시 원본 sub 이름과 아래 ebs_함수명을 대조한다.
 */
//
// ver 2.1 에서 추가
//
// 기술실패의 수정
// 수정일 2003/9/28
//
// ver 2.0 에서 추가
//
// 매매품의 검색기능을 추가하였습니다.
// 무기의 이동(출/납) 정보를 추가하였습니다.
// 무기 데이터가 2개로 복사되는 점을 수정하였습니다.
//
// 수정일 2002/10/15
//
//
// -------소스 사용규정의 대한 안내--------------------------------
// 이 스크립트는 NET GAME Communications 「http://www.ngcoms.net/」
// 에서 배포하고 있는 ENDLESSBATTLE2 의 추가 스크립트 소스 입니다.
//
// 이 스크립트는 무료로 제작되어 배포되는 것 입니다만 저작권의 명시
// 는 확실히 해주시길 바랍니다.(수정불가능)
//
// 이 스크립트를 사용하시는 분은 제작자가 명시한 이용규정을 꼭
// 지켜주시길 바랍니다.
//
// 1.이 스크립트를 사용하다 발생한 오류나 손해는 사용자에 책임
// 입니다.
//
// 2.이 스크립트를 사용해 개조해서 사용할 수 있습니다. 하지만
// 스크립트 사용시 생기는 경우는 수정자의 책임입니다.
//
// 3.재배포는 자유롭게 할 수 있지만 , 저작권 표시를  삭제하거나 덧붙
// 이지는 말아주세요
//
// SCRIPTNAME	EBS BUKIKO ver 2.0
// HOMEPAGE 		http://melcha.zone.ne.jp/ebs/dl/
// E-MAIL 		melchaa@hotmail.com
// (C)2002 44-net FACTORY
//
//
//
// ---------------ENDLESSBATTLE 스크립트 추가하는 법-----------------
//
// ebs_sub3.php 속에 보시면 <input type=button> 버튼이 있는 곳에
// 밑에 있는 소스를 추가하셔야 사용이 가능하니 꼭 넣어주세요.
//
// <td><input type=button value="무기고" $STYLE_B1 onClick="parent.Sub.location.replace('./파일이름.php')"></td>
//
// 위에 보시면 파일이름을 여러분이 원하는 파일이름으로 해주세요. 이름은 스크립트 파일과 같아야 합니다.
//
//
//
//
// 이 밑에는 스크립트 프로그램의 내용입니다.

function ebs_bukiko_market_load(): array {
    $data = ebs_json_load('bukiko_market');
    return isset($data['rows']) && is_array($data['rows']) ? $data['rows'] : [];
}
function ebs_bukiko_market_save(array $rows): bool {
    return ebs_json_save('bukiko_market', ['rows'=>array_values($rows)]);
}
function ebs_bukiko_weapon_name(string $raw): string {
    [$id, $name, $lv, $exp] = ebs_calc_weapon_label($raw);
    return $name.' Lv.'.$lv.' / exp.'.$exp;
}
function ebs_bukiko_normalize_warehouse(array &$player): void {
    if (!isset($player['warehouse_weapons']) || !is_array($player['warehouse_weapons'])) $player['warehouse_weapons'] = [];
    $player['warehouse_weapons'] = array_values(array_filter(array_map('strval', $player['warehouse_weapons']), static function (string $v): bool { return $v !== ''; }));
    if (count($player['warehouse_weapons']) > 30) $player['warehouse_weapons'] = array_slice($player['warehouse_weapons'], 0, 30);
}
function ebs_bukiko_handle(array &$me, array &$players, string $key): string {
    if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') $GLOBALS['EBS_DISABLE_AUTO_POST_SAVE'] = true;
    ebs_bukiko_normalize_warehouse($me);
    $mode = ebs_param('Cmode', ebs_param('cmd',''));
    $msg = '';
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') return '';

    if ($mode === '보관' || $mode === 'HOKAN') {
        $slot = ebs_param('weapon_slot', 'weapon');
        if (!in_array($slot, ['weapon','weapon2','weapon3'], true)) $slot = 'weapon';
        $current = (string)($me[$slot] ?? '');
        if ($current === '') return '보관할 무기가 없습니다.';
        if (count($me['warehouse_weapons']) >= 30) return '무기고가 가득 찼습니다.';
        $me['warehouse_weapons'][] = $current;
        if ($slot === 'weapon') {
            if ((string)($me['weapon2'] ?? '') !== '') { $me['weapon'] = (string)$me['weapon2']; $me['weapon2'] = ''; }
            elseif ((string)($me['weapon3'] ?? '') !== '') { $me['weapon'] = (string)$me['weapon3']; $me['weapon3'] = ''; }
            else { $me['weapon'] = ebs_default_weapon_id().'!0'; }
        } else {
            $me[$slot] = '';
        }
        $msg = ebs_bukiko_slot_label($slot).' 무기를 무기고에 보관했습니다.';
    } elseif ($mode === '출고' || $mode === 'DASU') {
        $idx = (int)ebs_param('whidx','-1');
        $target = ebs_param('target_slot', 'weapon');
        if (!in_array($target, ['weapon','weapon2','weapon3'], true)) $target = 'weapon';
        if (!isset($me['warehouse_weapons'][$idx])) return '출고할 무기를 선택해 주세요.';
        $old = (string)($me[$target] ?? '');
        if ($old !== '' && count($me['warehouse_weapons']) >= 30) return '교체할 기존 무기를 보관할 공간이 없습니다.';
        $take = (string)$me['warehouse_weapons'][$idx];
        array_splice($me['warehouse_weapons'], $idx, 1);
        if ($old !== '') $me['warehouse_weapons'][] = $old;
        $me[$target] = $take;
        $msg = '무기를 출고하여 '.ebs_bukiko_slot_label($target).'에 넣었습니다.';
    } elseif ($mode === '삭제' || $mode === 'DELETE' || $mode === 'DEL' || $mode === 'SAKUJO') {
        $idx = (int)ebs_param('whidx','-1');
        if (!isset($me['warehouse_weapons'][$idx])) return '삭제할 무기를 선택해 주세요.';
        array_splice($me['warehouse_weapons'], $idx, 1);
        $msg = '창고 무기를 삭제했습니다.';
    } elseif ($mode === '판매등록' || $mode === 'HANBAI') {
        $idx = (int)ebs_param('whidx','-1');
        $price = max(0, (int)ebs_param('price','0'));
        if (!isset($me['warehouse_weapons'][$idx])) return '판매할 무기를 선택해 주세요.';
        if ($price <= 0) return '판매 가격을 입력해 주세요.';
        $weapon = (string)$me['warehouse_weapons'][$idx];
        array_splice($me['warehouse_weapons'], $idx, 1);
        $rows = ebs_bukiko_market_load();
        $rows[] = ['id'=>bin2hex(random_bytes(6)), 'seller'=>(string)($me['name'] ?? $key), 'weapon'=>$weapon, 'price'=>$price, 'time'=>date('Y-m-d H:i:s')];
        if (count($rows) > 200) $rows = array_slice($rows, -200);
        ebs_bukiko_market_save($rows);
        $msg = '무기를 판매장에 등록했습니다.';
    } elseif ($mode === '구입' || $mode === 'BUY') {
        $id = ebs_param('sale_id','');
        $rows = ebs_bukiko_market_load();
        foreach ($rows as $i=>$row) {
            if (!is_array($row) || (string)($row['id'] ?? '') !== $id) continue;
            $price = max(0, (int)($row['price'] ?? 0));
            if ($price > (int)($me['money'] ?? 0)) return '구입 자금이 부족합니다.';
            if (count($me['warehouse_weapons']) >= 30) return '무기고가 가득 찼습니다.';
            $me['money'] = (int)($me['money'] ?? 0) - $price;
            $me['warehouse_weapons'][] = (string)($row['weapon'] ?? '');
            $seller = (string)($row['seller'] ?? '');
            $sellerKey = ebs_find_player_key($seller, $players);
            if ($sellerKey !== null && isset($players[$sellerKey]) && is_array($players[$sellerKey])) {
                $players[$sellerKey]['money'] = (int)($players[$sellerKey]['money'] ?? 0) + $price;
                ebs_player_sync_common($players[$sellerKey]);
            }
            array_splice($rows, $i, 1);
            ebs_bukiko_market_save($rows);
            $msg = '무기를 구입하여 무기고에 보관했습니다.';
            break;
        }
        if ($msg === '') $msg = '판매 정보를 찾을 수 없습니다.';
    }
    ebs_bukiko_normalize_warehouse($me);
    if (!isset($me['event_log']) || !is_array($me['event_log'])) $me['event_log'] = [];
    $me['event_log'][] = ['type'=>'bukiko','mode'=>$mode,'time'=>date('YmdHis')];
    if (count($me['event_log']) > 50) $me['event_log'] = array_slice($me['event_log'], -50);
    ebs_player_sync_common($me);
    $players[$key] = $me;
    ebs_players_save($players);
    return $msg;
}
function ebs_bukiko_slot_label(string $slot): string { return ['weapon'=>'장비중','weapon2'=>'예비1','weapon3'=>'예비2'][$slot] ?? '장비중'; }
function ebs_bukiko_render(string $title='무기고'): void {
    if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && empty($GLOBALS['EBS_BUKIKO_TX'])) {
        $GLOBALS['EBS_BUKIKO_TX'] = true;
        ebs_with_file_lock(ebs_file('data/bukiko_market_state'), LOCK_EX, static function () use ($title): void { ebs_bukiko_render($title); });
        $GLOBALS['EBS_BUKIKO_TX'] = false;
        return;
    }
    ebs_header_html();
    [$key, $me, $players, $err] = ebs_require_player();
    if ($err !== '' || !is_array($me) || $key === null) { ebs_error_page('Error', $err ?: '등록 데이터를 찾을 수 없습니다.'); return; }
    $msg = ebs_bukiko_handle($me, $players, $key);
    ebs_bukiko_normalize_warehouse($me);
    $pname=(string)($me['name'] ?? $key); $pass=ebs_param('pass', ebs_cookie_value('pass',''));
    $money=(int)($me['money'] ?? 0);
    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>ENDLESS BATTLE - '.ebs_h($title).'</title></head>';
    echo '<body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="margin:0;font-size:13px;" oncontextmenu="return false;"><script>try{if(parent&&parent.Main&&parent.Main.location&&window.name=="Sub")parent.Main.location.reload();}catch(e){}</script>';
    echo '<center><table border="1" cellspacing="0" cellpadding="5" bordercolor="'.ebs_h(ebs_v('TABLE_BORDER')).'" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" style="font-size:13px;min-width:760px;">';
    echo '<tr><td colspan="7" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'"><b>'.ebs_h($title).'</b> / 소지금 $'.ebs_h(number_format($money)).'</td></tr>';
    if ($msg !== '') echo '<tr><td colspan="7" align="center"><b>'.ebs_h($msg).'</b></td></tr>';
    echo '<tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'" colspan="7"><b>장비/예비 무기</b></td></tr>';
    foreach (['weapon'=>'장비중','weapon2'=>'예비1','weapon3'=>'예비2'] as $slot=>$label) {
        $raw=(string)($me[$slot] ?? '');
        echo '<tr><td width="90">'.ebs_h($label).'</td><td colspan="5">'.($raw!=='' ? ebs_h(ebs_bukiko_weapon_name($raw)) : '&nbsp;').'</td><td align="center">';
        if ($raw !== '') echo '<form action="bukiko.php" method="POST" target="Sub" style="margin:0;"><input type="hidden" name="cmd" value="HOKAN"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'"><input type="hidden" name="weapon_slot" value="'.ebs_h($slot).'"><input type="hidden" name="Cmode" value="보관"><input type="submit" value="보관" '.ebs_v('STYLE_B1').'></form>';
        echo '</td></tr>';
    }
    echo '<tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'" colspan="7"><b>내 무기고</b></td></tr>';
    echo '<tr><td>No</td><td>무기명</td><td>출고위치</td><td>출고</td><td>판매가</td><td>판매등록</td><td>삭제</td></tr>';
    foreach ($me['warehouse_weapons'] as $i=>$weapon) {
        echo '<tr><td align="center">'.($i+1).'</td><td>'.ebs_h(ebs_bukiko_weapon_name((string)$weapon)).'</td>';
        echo '<form action="bukiko.php" method="POST" target="Sub" style="margin:0;"><td align="center"><select name="target_slot" '.ebs_v('STYLE_L').'><option value="weapon">장비중<option value="weapon2">예비1<option value="weapon3">예비2</select></td><td align="center"><input type="hidden" name="cmd" value="DASU"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'"><input type="hidden" name="whidx" value="'.ebs_h((string)$i).'"><input type="hidden" name="Cmode" value="출고"><input type="submit" value="출고" '.ebs_v('STYLE_B1').'></td></form>';
        echo '<form action="bukiko.php" method="POST" target="Sub" style="margin:0;"><td align="center"><input type="text" name="price" size="8" '.ebs_v('STYLE_L').'></td><td align="center"><input type="hidden" name="cmd" value="HANBAI"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'"><input type="hidden" name="whidx" value="'.ebs_h((string)$i).'"><input type="hidden" name="Cmode" value="판매등록"><input type="submit" value="등록" '.ebs_v('STYLE_B1').'></td></form>';
        echo '<form action="bukiko.php" method="POST" target="Sub" style="margin:0;"><td align="center"><input type="hidden" name="cmd" value="DELETE"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'"><input type="hidden" name="whidx" value="'.ebs_h((string)$i).'"><input type="hidden" name="Cmode" value="삭제"><input type="submit" value="삭제" '.ebs_v('STYLE_B1').' onclick="return confirm(&quot;창고의 이 무기를 삭제합니다. 괜찮습니까?&quot;)"></td></form></tr>';
    }
    if (!$me['warehouse_weapons']) echo '<tr><td colspan="7" align="center">보관중인 무기가 없습니다.</td></tr>';
    echo '<tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'" colspan="7"><b>판매장</b></td></tr>';
    echo '<tr><td>판매자</td><td colspan="3">무기명</td><td colspan="2">가격</td><td>구입</td></tr>';
    $rows = ebs_bukiko_market_load();
    foreach ($rows as $row) {
        if (!is_array($row)) continue;
        echo '<tr><td>'.ebs_h((string)($row['seller'] ?? '')).'</td><td colspan="3">'.ebs_h(ebs_bukiko_weapon_name((string)($row['weapon'] ?? ''))).'</td><td colspan="2" align="right">$'.ebs_h(number_format((int)($row['price'] ?? 0))).'</td>';
        echo '<td align="center"><form action="bukiko.php" method="POST" target="Sub" style="margin:0;"><input type="hidden" name="cmd" value="SOUKO"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'"><input type="hidden" name="sale_id" value="'.ebs_h((string)($row['id'] ?? '')).'"><input type="hidden" name="Cmode" value="구입"><input type="submit" value="구입" '.ebs_v('STYLE_B1').'></form></td></tr>';
    }
    if (!$rows) echo '<tr><td colspan="7" align="center">판매중인 무기가 없습니다.</td></tr>';
    echo '</table></center></body></html>';
}

function ebs_INPORT(): void { ebs_bukiko_render('무기고'); }
function ebs_MAIN(): void { ebs_bukiko_render('무기고'); }
function ebs_SOUKO(): void { ebs_bukiko_render('무기고 판매장'); }
function ebs_HOKAN(): void { ebs_bukiko_render('무기 보관'); }
function ebs_DASU(): void { ebs_bukiko_render('무기 출고'); }
function ebs_HANBAI(): void { ebs_bukiko_render('무기 판매등록'); }
function ebs_BUKI_DELETE(): void { ebs_bukiko_render('무기 삭제'); }
function ebs_ENDHTML(): void { ebs_bukiko_render('무기고'); }
function ebs_JOUHOU(): void { ebs_bukiko_render('무기 정보'); }
function ebs_BUKILOCK(): void { ebs_bukiko_render('무기고'); }
function ebs_BUKIUNLOCK(): void { ebs_bukiko_render('무기고'); }

$map = [
    'INPORT' => 'ebs_INPORT',
    'MAIN' => 'ebs_MAIN',
    'SOUKO' => 'ebs_SOUKO',
    'HOKAN' => 'ebs_HOKAN',
    'DASU' => 'ebs_DASU',
    'HANBAI' => 'ebs_HANBAI',
    'DELETE' => 'ebs_BUKI_DELETE',
    'DEL' => 'ebs_BUKI_DELETE',
    'SAKUJO' => 'ebs_BUKI_DELETE',
    'ENDHTML' => 'ebs_ENDHTML',
    'JOUHOU' => 'ebs_JOUHOU',
    'BUKILOCK' => 'ebs_BUKILOCK',
    'BUKIUNLOCK' => 'ebs_BUKIUNLOCK',
];
ebs_dispatch($map, 'ebs_INPORT');
?>
