<?php
declare(strict_types=1);
require_once __DIR__ . '/lib_ebs.php';

const EBS_MS_HP = 3500;
const EBS_MS_EN = 170;
const EBS_MS_MONEY = 1000000;
const EBS_MS_MAX = 4;

function ebs_ms_store(): array {
    $data = ebs_json_load('msdata');
    return is_array($data) ? $data : [];
}

function ebs_ms_save_store(array $data): bool {
    return ebs_json_save('msdata', $data);
}

function ebs_ms_list_for(string $name): array {
    $store = ebs_ms_store();
    $list = $store[$name] ?? [];
    return is_array($list) ? array_values(array_filter($list, 'is_array')) : [];
}

function ebs_ms_weapon_select(string $selected = ''): string {
    $out = '<select name="wep" '.ebs_v('STYLE_L').'>';
    foreach (ebs_weapon_table() as $key => $row) {
        if (!is_array($row) || strlen((string)$key) !== 1) continue;
        $kind = isset($row[6]) ? (string)$row[6] : '';
        if ($kind === '2' || $kind === '4' || $kind === '6') continue;
        $sel = ((string)$key === $selected) ? ' selected' : '';
        $out .= '<option value="'.ebs_h((string)$key).'"'.$sel.'>'.ebs_h((string)($row[0] ?? $key)).'</option>';
    }
    return $out.'</select>';
}

function ebs_ms_icon_select(string $selected = '0'): string {
    $max = (int)ebs_v('ICON', '985');
    $out = '<select name="msimg" '.ebs_v('STYLE_L').' onChange="selectMsIcon()">';
    for ($i=0; $i <= $max; $i++) {
        $sel = ((string)$i === $selected) ? ' selected' : '';
        $out .= '<option value="'.$i.'"'.$sel.'>아이콘 No.'.$i.'</option>';
    }
    return $out.'</select>';
}

function ebs_ms_weapon_label(string $weapon): string {
    [$id, $lvRaw] = array_pad(explode('!', $weapon, 2), 2, '0');
    $table = ebs_weapon_table();
    $name = isset($table[$id][0]) ? (string)$table[$id][0] : ($id !== '' ? $id : '무장비');
    $lv = (int)floor(((int)$lvRaw) / max(1, (int)ebs_v('WEAPON_LVUP', '100')));
    return $name.'(Lv.'.$lv.')';
}

function ebs_MSEQUIP(): void {
    ebs_header_html();
    [$key, $me, $players, $err] = ebs_require_player();
    if ($err !== '' || $key === null || !is_array($me)) { ebs_error_page('PwdError', $err !== '' ? $err : '패스워드가 잘못되어 있을 우려가 있습니다.'); return; }
    $pname = (string)($me['name'] ?? $key);
    $pass = ebs_param('pass', ebs_cookie_value('pass', ''));
    $list = ebs_ms_list_for($pname);
    $money = ebs_plv_int($me, 8, (int)($me['money'] ?? 0));
    $canBuy = count($list) < EBS_MS_MAX && $money >= EBS_MS_MONEY;
    $buyInput = count($list) >= EBS_MS_MAX ? '더 이상 구입할 수 없습니다.' : ($money < EBS_MS_MONEY ? '<font color="red">자금이 충분하지 않습니다.</font>' : '<input type="submit" name="Cmode1" value="구입" '.ebs_v('STYLE_B1').' onclick="return checkMS();">');
    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>ENDLESS BATTLE</title>';
    echo '<script>function selectMsIcon(){var f=document.Ms;var n=f.msimg.options[f.msimg.selectedIndex].value;document.ms_preview.src="'.ebs_h(ebs_v('IMG_FOLDER2')).'/"+n+".gif";}function checkMS(){return confirm("기체를 새롭게 구입합니다. 좋습니까?");}function checkMSC(){return confirm("다른 기체에 탑승합니다. 좋습니까?");}function checkMSD(){return confirm("이 기체를 파기합니다. 좋습니까?");}</script>';
    echo '</head><body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="margin:0;font-size:13px;" oncontextmenu="return false;">';
    echo '<form action="kitai.php" method="POST" name="Ms"><input type="hidden" name="cmd" value="MSSHOP"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'">';
    echo '<table border="0"><tr><td valign="top"><table bordercolor="'.ebs_h(ebs_v('TABLE_BORDER')).'" border="1" cellspacing="0" style="font-size:10pt;"><tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'"><b>기체구입</b></td></tr>';
    echo '<tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" nowrap><b>설명</b><br>기체를 여기서 큰돈을 지불해 새롭게 구입할 수가 있습니다.<br>여기서 구입한 기체는, 현재의 기체와 교환을 할 수 있습니다.<br>기체의 초기치 : HP : '.EBS_MS_HP.'&nbsp;EN : '.EBS_MS_EN.'<br><br>';
    echo '<table bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" style="font-size:13px;" bordercolor="#a9a9a9" border="1"><tr><td align="center" style="background-color:#333366;"><b>기체구입</b></td><td align="left"><b>비용 : </b></td><td align="right">&nbsp;&nbsp;$'.EBS_MS_MONEY.'</td></tr>';
    echo '<tr><td align="center"><b>기체명</b><div align="right"><input type="text" name="name" size="20" maxlength="14" '.ebs_v('STYLE_L').'></div></td><td align="center" colspan="2"><b>초기장비</b><div align="right">'.ebs_ms_weapon_select().'</div></td></tr>';
    echo '<tr><td align="right"><img src="'.ebs_h(ebs_v('IMG_FOLDER2')).'/0.gif" name="ms_preview"><br>'.ebs_ms_icon_select('0').'</td><td align="center" colspan="2">'.$buyInput.'</td></tr></table>';
    echo '</td></tr></table></td>';
    echo '<td valign="top"><table bordercolor="'.ebs_h(ebs_v('TABLE_BORDER')).'" border="1" cellspacing="0" style="font-size:10pt;"><tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'"><b>기체격납고</b></td></tr><tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'"><br>';
    echo '<table bordercolor="'.ebs_h(ebs_v('TABLE_BORDER')).'" border="1" cellspacing="0" style="font-size:13px;"><tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'" align="center" nowrap><b>기체명</b></td><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'" align="center" nowrap><b>HP</b></td><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'" align="center" nowrap><b>EN</b></td><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'" align="center" nowrap><b>상태</b></td><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'" align="center" nowrap><b>장비무기</b></td><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'" align="center" nowrap><b>아이콘</b></td></tr>';
    $options = '';
    foreach ($list as $i => $ms) {
        $nm = (string)($ms['name'] ?? 'NoName');
        $hp = (int)($ms['hp'] ?? EBS_MS_HP); $mhp = (int)($ms['max_hp'] ?? EBS_MS_HP);
        $en = (int)($ms['en'] ?? EBS_MS_EN); $men = (int)($ms['max_en'] ?? EBS_MS_EN);
        $repair = !empty($ms['repair']) ? '<font color="red">수리중</font>' : '<font color="blue">발진가능</font>';
        $weapon = (string)($ms['weapon'] ?? '0!0');
        $icon = (string)($ms['icon'] ?? '1');
        if (!preg_match('/^[0-9A-Za-z_\-]+$/', $icon)) $icon = '1';
        echo '<tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'" nowrap>'.ebs_h($nm).'</td><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" align="right">'.$hp.' / '.$mhp.'</td><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" align="right">'.$en.' / '.$men.'</td><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" align="center">'.$repair.'</td><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'">'.ebs_h(ebs_ms_weapon_label($weapon)).'</td><td align="center" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'"><img src="'.ebs_h(ebs_v('IMG_FOLDER2')).'/'.ebs_h($icon).'.gif" width="32" height="32"></td></tr>';
        $options .= '<option value="'.$i.'">'.ebs_h($nm).'</option>';
    }
    if (!$list) echo '<tr><td colspan="6" align="center" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'">보유 기체가 없습니다.</td></tr>';
    echo '</table><br><select name="mschanges" '.ebs_v('STYLE_L').'>'.$options.'</select>&nbsp;&nbsp;<input type="submit" name="Cmode2" value="탑승" '.ebs_v('STYLE_B1').' onclick="return checkMSC();">&nbsp;&nbsp;<input type="submit" name="Cmode3" value="파기" '.ebs_v('STYLE_B1').' onclick="return checkMSD();"><br><br>';
    echo '</td></tr></table></td></tr></table></form>';
    echo '<br><div align="center" style="font-size:13px;">기체 환승 스크립트<br>Produce By &copy; ENDLESS</div><br></body></html>';
}

function ebs_MSSHOP(): void {
    $GLOBALS['EBS_DISABLE_AUTO_POST_SAVE'] = true;
    ebs_header_html();
    [$key, $me, $players, $err] = ebs_require_player();
    if ($err !== '' || $key === null || !is_array($me)) { ebs_error_page('PwdError', $err !== '' ? $err : '패스워드가 잘못되어 있을 우려가 있습니다.'); return; }
    $pname = (string)($me['name'] ?? $key);
    $store = ebs_ms_store();
    $list = isset($store[$pname]) && is_array($store[$pname]) ? array_values(array_filter($store[$pname], 'is_array')) : [];
    if (isset($_POST['Cmode1'])) {
        if (count($list) >= EBS_MS_MAX) { ebs_error_page('Error', '더 이상 구입할 수 없습니다.'); return; }
        $money = ebs_plv_int($me, 8, (int)($me['money'] ?? 0));
        if ($money < EBS_MS_MONEY) { ebs_error_page('Error', '자금이 충분하지 않습니다.'); return; }
        $name = trim((string)($_POST['name'] ?? ''));
        if ($name === '') { ebs_error_page('Error', '기체명을 기입해 주세요'); return; }
        if (preg_match('/[:,\r\n]/u', $name)) { ebs_error_page('Error', '그 기체명은 무리입니다.'); return; }
        $weapon = preg_match('/^[0-9A-Za-z_\-]+$/', (string)($_POST['wep'] ?? '0')) ? (string)$_POST['wep'] : '0';
        $icon = preg_match('/^[0-9]+$/', (string)($_POST['msimg'] ?? '0')) ? (string)$_POST['msimg'] : '0';
        $me['money'] = $money - EBS_MS_MONEY;
        ebs_player_raw_set($me, 8, (string)$me['money']);
        $list[] = ['name'=>$name, 'date'=>time(), 'hp'=>EBS_MS_HP, 'max_hp'=>EBS_MS_HP, 'en'=>EBS_MS_EN, 'max_en'=>EBS_MS_EN, 'repair'=>0, 'weapon'=>$weapon.'!0', 'icon'=>$icon, 'st'=>[6,6,6,6], 'level'=>1, 'exp'=>0, 'win'=>0, 'lose'=>0];
    } elseif (isset($_POST['Cmode2'])) {
        $i = (int)($_POST['mschanges'] ?? -1);
        if (!isset($list[$i]) || !is_array($list[$i])) { ebs_error_page('Error', '부정 에러입니다'); return; }
        $current = ['name'=>ebs_plv($me,3,$pname), 'date'=>time(), 'hp'=>ebs_plv_int($me,15,0), 'max_hp'=>ebs_plv_int($me,16,0), 'en'=>ebs_plv_int($me,17,0), 'max_en'=>ebs_plv_int($me,18,0), 'repair'=>ebs_plv_int($me,25,0), 'weapon'=>ebs_plv($me,9,'0!0'), 'icon'=>ebs_plv($me,27,'1'), 'st'=>[ebs_plv_int($me,19,6), ebs_plv_int($me,20,6), ebs_plv_int($me,21,6), ebs_plv_int($me,22,6)], 'level'=>ebs_plv_int($me,29,1), 'exp'=>ebs_plv_int($me,30,0), 'win'=>ebs_plv_int($me,41,0), 'lose'=>ebs_plv_int($me,42,0)];
        $new = $list[$i];
        $me['msname'] = (string)($new['name'] ?? $me['msname'] ?? $pname);
        $me['hp'] = (int)($new['hp'] ?? EBS_MS_HP); $me['max_hp'] = (int)($new['max_hp'] ?? EBS_MS_HP);
        $me['en'] = (int)($new['en'] ?? EBS_MS_EN); $me['max_en'] = (int)($new['max_en'] ?? EBS_MS_EN);
        $me['repair'] = (string)((int)($new['repair'] ?? 0)); $me['weapon'] = (string)($new['weapon'] ?? '0!0'); $me['icon'] = (string)($new['icon'] ?? '1');
        $me['st'] = isset($new['st']) && is_array($new['st']) ? array_values($new['st']) : [6,6,6,6];
        $me['level'] = (int)($new['level'] ?? 1); $me['level_exp'] = (int)($new['exp'] ?? 0);
        ebs_player_raw_set($me, 3, (string)$me['msname']); ebs_player_raw_set($me,15,(string)$me['hp']); ebs_player_raw_set($me,16,(string)$me['max_hp']); ebs_player_raw_set($me,17,(string)$me['en']); ebs_player_raw_set($me,18,(string)$me['max_en']); ebs_player_raw_set($me,25,(string)$me['repair']); ebs_player_raw_set($me,9,(string)$me['weapon']); ebs_player_raw_set($me,27,(string)$me['icon']);
        foreach ([19,20,21,22] as $idx => $rawIdx) ebs_player_raw_set($me, $rawIdx, (string)($me['st'][$idx] ?? 6));
        ebs_player_raw_set($me,29,(string)$me['level']); ebs_player_raw_set($me,30,(string)$me['level_exp']);
        $list[$i] = $current;
    } elseif (isset($_POST['Cmode3'])) {
        $i = (int)($_POST['mschanges'] ?? -1);
        if (isset($list[$i])) array_splice($list, $i, 1);
    }
    $me['last_access'] = (string)time();
    ebs_player_sync_common($me);
    $players[$key] = $me;
    ebs_players_save($players);
    $store[$pname] = $list;
    ebs_ms_save_store($store);
    ebs_MSEQUIP();
}

function ebs_MSREPAIR(): void { ebs_MSEQUIP(); }

$map = [
    'MSEQUIP' => 'ebs_MSEQUIP',
    'MSSHOP' => 'ebs_MSSHOP',
    'MSREPAIR' => 'ebs_MSREPAIR',
];
ebs_dispatch($map, 'ebs_MSEQUIP');
?>
