<?php
declare(strict_types=1);
require_once __DIR__ . '/lib_ebs.php';
/**
 * 원본 legacy 파일: ebs_finance.php
 * PHP 8.4 파일당 1:1 대응 변환 파일.
 * 원본 주석은 PHP // 주석으로 보존하고, 기존 실행 의존은 제거하고 PHP 8.4 파일 기반으로 동작시킨다.
 * 유지보수 시 원본 sub 이름과 아래 ebs_함수명을 대조한다.
 */

function ebs_CUSTOM_HEADER(): void {
    // 직접 접근이나 잘못된 cmd로 들어온 경우도 실제 은행 화면으로 보낸다.
    ebs_FINANCE2();
}

function ebs_FINANCE2(): void {
    ebs_header_html();
    ebs_record_post('ebs_finance.php::FINANCE2');
    [$key, $me, $players, $err] = ebs_require_player();
    if ($err !== '' || !is_array($me) || $key === null) { ebs_error_page('Error', $err ?: '등록 데이터를 찾을 수 없습니다.'); return; }

    $pname = (string)($me['name'] ?? $key);
    $pass = ebs_param('pass', ebs_cookie_value('pass',''));
    $money = max(0, (int)($me['money'] ?? 0));
    $bank = max(0, (int)($me['bank'] ?? 0));
    $msg = '';

    if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && ebs_param('Cmode','') === '수속') {
        $amount = (int)ebs_param('money1', '0');
        $mode = ebs_param('bank', 'yokinn');
        if ($amount <= 0) {
            $msg = '금액이 입력되고 있지 않습니다.';
        } elseif ($mode === 'yokinn') {
            if ($amount > $money) $msg = '자금이 충분하지 않습니다.';
            else { $money -= $amount; $bank += $amount; $msg = '$'.number_format($amount).' 예금 완료'; }
        } elseif ($mode === 'syukkinn') {
            if ($amount > $bank) $msg = '입력한 금액이 예금액을 넘고 있습니다.';
            else { $bank -= $amount; $money += $amount; $msg = '$'.number_format($amount).' 출금 완료'; }
        }
        $me['money'] = $money;
        $me['bank'] = $bank;
        if (!isset($me['event_log']) || !is_array($me['event_log'])) $me['event_log'] = [];
        $me['event_log'][] = ['type'=>'finance','mode'=>$mode,'amount'=>$amount,'time'=>date('YmdHis')];
        if (count($me['event_log']) > 50) $me['event_log'] = array_slice($me['event_log'], -50);
        ebs_player_sync_common($me);
        $players[$key] = $me;
        ebs_players_save($players);
    }

    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>ENDLESS BATTLE - Bank</title></head>';
    echo '<body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="margin:0;font-size:13px;" oncontextmenu="return false;">';
    echo '<script language="JavaScript">function KinCheck(MC){if(MC.value==""||MC.value=="0"){alert("금액이 입력되고 있지 않습니다.");return false;}else if(MC.value.match(/[^0-9]/)){alert("숫자 이외의 문자는 입력할 수 없습니다.");return false;}return true;}</script>';
    echo '<center><form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST" name="Ms" target="Sub">';
    echo '<input type="hidden" name="cmd" value="FINANCE"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'">';
    echo '<table border="1" cellspacing="0" cellpadding="6" bordercolor="'.ebs_h(ebs_v('TABLE_BORDER')).'" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" style="font-size:13px;min-width:360px;">';
    echo '<tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'" colspan="2"><b>예금</b></td></tr>';
    if ($msg !== '') echo '<tr><td colspan="2" align="center"><b>'.ebs_h($msg).'</b></td></tr>';
    echo '<tr><td>소지금</td><td align="right">$'.ebs_h(number_format($money)).'</td></tr>';
    echo '<tr><td>예금 총액</td><td align="right">$'.ebs_h(number_format($bank)).'</td></tr>';
    echo '<tr><td colspan="2" align="center"><label><input type="radio" value="yokinn" name="bank" checked>예금</label>&nbsp;<label><input type="radio" value="syukkinn" name="bank">출금</label></td></tr>';
    echo '<tr><td>수속 금액</td><td><input maxlength="10" size="10" name="money1" '.ebs_v('STYLE_L').'> <input name="Cmode" type="submit" value="수속" '.ebs_v('STYLE_B1').' onClick="return KinCheck(document.Ms.money1);"></td></tr>';
    echo '</table></form><br><span style="font-size:15px;font-weight:bold;">Bank System ver1.04</span></center></body></html>';
}

$map = [
    'CUSTOM_HEADER' => 'ebs_CUSTOM_HEADER',
    'FINANCE2' => 'ebs_FINANCE2',
];
ebs_dispatch($map, 'ebs_CUSTOM_HEADER');
?>
