<?php
declare(strict_types=1);
require_once __DIR__ . '/lib_ebs.php';

function ebs_nextcard_hidden(string $pname='', string $pass=''): string {
    if ($pname === '') $pname = ebs_param('pname', ebs_cookie_value('pname',''));
    if ($pass === '') $pass = ebs_param('pass', ebs_cookie_value('pass',''));
    return '<input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'">';
}

function ebs_nextcard_header(string $title): void {
    ebs_header_html();
    echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>'.ebs_h($title).'</title></head>';
    echo '<body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="margin:8px;font-size:13px;" oncontextmenu="return false;"><center>';
    echo '<table border="1" cellspacing="0" cellpadding="5" bordercolor="'.ebs_h(ebs_v('TABLE_BORDER')).'" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" width="620">';
    echo '<tr><td colspan="4" align="center" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'"><b>'.ebs_h($title).'</b></td></tr>';
}

function ebs_nextcard_footer(string $pname='', string $pass=''): void {
    echo '<tr><td colspan="4" align="center" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'">';
    echo '<form action="nextcard.php" method="POST" style="display:inline" target="Sub"><input type="hidden" name="cmd" value="START_GAME">'.ebs_nextcard_hidden($pname,$pass).'<input type="submit" value="처음으로" '.ebs_v('STYLE_B1').'></form> ';
    echo '<form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST" target="Main" style="display:inline"><input type="hidden" name="cmd" value="MAIN_FRAME">'.ebs_nextcard_hidden($pname,$pass).'<input type="submit" value="메인" '.ebs_v('STYLE_B1').'></form>';
    echo '</td></tr></table></center></body></html>';
}

function ebs_nextcard_rank_value(array $p): int { return (int)($p['nextcard_total_win'] ?? 0); }
function ebs_nextcard_card_name(int $n): string { $names=[1=>'A',11=>'J',12=>'Q',13=>'K']; return $names[$n] ?? (string)$n; }

function ebs_nextcard_load_player(): array {
    $pname = ebs_param('pname', ebs_cookie_value('pname',''));
    $pass = ebs_param('pass', ebs_cookie_value('pass',''));
    [$key, $me, $players, $err] = ebs_require_player($pname, $pass);
    $ok = ($key !== null && is_array($me) && $err === '');
    return [$ok, $me, $err, $players, $key];
}

function ebs_START_GAME(): void {
    [$ok,$me,$err] = ebs_nextcard_load_player();
    $pname = is_array($me) ? (string)($me['name'] ?? ebs_param('pname','')) : ebs_param('pname', ebs_cookie_value('pname',''));
    $pass = ebs_param('pass', ebs_cookie_value('pass',''));
    ebs_nextcard_header('Next Card');
    if (!$ok || !is_array($me)) {
        echo '<tr><td colspan="4" align="center">로그인 정보를 입력하면 넥스트카드를 시작할 수 있습니다.</td></tr>';
    } else {
        echo '<tr><td>파일럿</td><td>'.ebs_h($pname).'</td><td>소지금</td><td align="right">'.number_format((int)($me['money'] ?? 0)).' G</td></tr>';
    }
    echo '<tr><td colspan="4" align="center"><form action="nextcard.php" method="POST" target="Sub"><input type="hidden" name="cmd" value="ON_BET">'.ebs_nextcard_hidden($pname,$pass).'BET <input name="bet" value="100" size="8" '.ebs_v('STYLE_L').'> <input type="submit" value="START" '.ebs_v('STYLE_B1').'></form></td></tr>';
    echo '<tr><td colspan="4" align="center"><form action="nextcard.php" method="POST" style="display:inline" target="Sub"><input type="hidden" name="cmd" value="RANKING"><input type="submit" value="랭킹" '.ebs_v('STYLE_B1').'></form> <form action="nextcard.php" method="POST" style="display:inline" target="Sub"><input type="hidden" name="cmd" value="SETUMEI"><input type="submit" value="설명" '.ebs_v('STYLE_B1').'></form></td></tr>';
    ebs_nextcard_footer($pname,$pass);
}

function ebs_ON_BET(): void {
    [$ok,$me,$err,$players,$key] = ebs_nextcard_load_player();
    if (!$ok || !is_array($me) || $key === null) { ebs_error_page('Next Card', $err ?: '로그인 정보가 없습니다.'); return; }
    $pname=(string)($me['name'] ?? $key); $pass=ebs_param('pass', ebs_cookie_value('pass',''));
    $bet = max(1, (int)ebs_param('bet','100'));
    if ((int)($me['money'] ?? 0) < $bet) { ebs_nextcard_header('Next Card'); echo '<tr><td colspan="4" align="center">소지금이 부족합니다.</td></tr>'; ebs_nextcard_footer($pname,$pass); return; }
    $card = random_int(1,13);
    $me['money'] = (int)($me['money'] ?? 0) - $bet;
    $me['nextcard'] = ['bet'=>$bet,'current'=>$card,'payout'=>$bet * 2,'streak'=>0,'time'=>date('YmdHis')];
    ebs_player_sync_common($me); $players[$key]=$me; ebs_players_save($players);
    ebs_nextcard_game_screen($me, $pname, $pass, '첫 카드가 공개되었습니다. 다음 카드가 높을지 낮을지 선택하세요.');
}

function ebs_nextcard_game_screen(array $me, string $pname, string $pass, string $message=''): void {
    $state = isset($me['nextcard']) && is_array($me['nextcard']) ? $me['nextcard'] : [];
    $card = (int)($state['current'] ?? random_int(1,13));
    $payout = (int)($state['payout'] ?? 0);
    ebs_nextcard_header('Next Card');
    if ($message !== '') echo '<tr><td colspan="4" align="center" bgcolor="#404040">'.ebs_h($message).'</td></tr>';
    echo '<tr><td>파일럿</td><td>'.ebs_h($pname).'</td><td>소지금</td><td align="right">'.number_format((int)($me['money'] ?? 0)).' G</td></tr>';
    echo '<tr><td colspan="4" align="center" style="font-size:42px;background:#ffffff;color:#000000;">'.ebs_h(ebs_nextcard_card_name($card)).'</td></tr>';
    echo '<tr><td colspan="4" align="center">성공 시 지급 예정: <b>'.number_format($payout).' G</b></td></tr>';
    echo '<tr><td colspan="4" align="center"><form action="nextcard.php" method="POST" style="display:inline" target="Sub"><input type="hidden" name="cmd" value="CHANGE">'.ebs_nextcard_hidden($pname,$pass).'<input type="hidden" name="guess" value="HIGH"><input type="submit" value="HIGH" '.ebs_v('STYLE_B1').'></form> ';
    echo '<form action="nextcard.php" method="POST" style="display:inline" target="Sub"><input type="hidden" name="cmd" value="CHANGE">'.ebs_nextcard_hidden($pname,$pass).'<input type="hidden" name="guess" value="LOW"><input type="submit" value="LOW" '.ebs_v('STYLE_B1').'></form> ';
    echo '<form action="nextcard.php" method="POST" style="display:inline" target="Sub"><input type="hidden" name="cmd" value="PAY_OUT">'.ebs_nextcard_hidden($pname,$pass).'<input type="submit" value="정산" '.ebs_v('STYLE_B1').'></form></td></tr>';
    ebs_nextcard_footer($pname,$pass);
}

function ebs_IN_GAME(): void {
    [$ok,$me,$err] = ebs_nextcard_load_player();
    if (!$ok || !is_array($me)) { ebs_START_GAME(); return; }
    ebs_nextcard_game_screen($me, (string)($me['name'] ?? ''), ebs_param('pass', ebs_cookie_value('pass','')));
}

function ebs_CHANGE(): void {
    [$ok,$me,$err,$players,$key] = ebs_nextcard_load_player();
    if (!$ok || !is_array($me) || $key === null) { ebs_error_page('Next Card', $err ?: '로그인 정보가 없습니다.'); return; }
    $pname=(string)($me['name'] ?? $key); $pass=ebs_param('pass', ebs_cookie_value('pass',''));
    $state = isset($me['nextcard']) && is_array($me['nextcard']) ? $me['nextcard'] : [];
    if (!$state) { ebs_START_GAME(); return; }
    $old = (int)($state['current'] ?? 1);
    $new = random_int(1,13);
    $guess = strtoupper(ebs_param('guess','HIGH'));
    $hit = ($guess === 'HIGH' && $new >= $old) || ($guess === 'LOW' && $new <= $old);
    ebs_nextcard_header('Next Card 결과');
    echo '<tr><td colspan="4" align="center" style="font-size:28px;background:#ffffff;color:#000000;">'.ebs_h(ebs_nextcard_card_name($old)).' → '.ebs_h(ebs_nextcard_card_name($new)).'</td></tr>';
    if ($hit) {
        $state['current'] = $new;
        $state['streak'] = (int)($state['streak'] ?? 0) + 1;
        $state['payout'] = max(1, (int)($state['payout'] ?? 0)) * 2;
        $me['nextcard'] = $state;
        ebs_player_sync_common($me); $players[$key]=$me; ebs_players_save($players);
        echo '<tr><td colspan="4" align="center">성공했습니다. 계속 진행하거나 정산할 수 있습니다.</td></tr>';
        echo '<tr><td colspan="4" align="center"><form action="nextcard.php" method="POST" style="display:inline" target="Sub"><input type="hidden" name="cmd" value="IN_GAME">'.ebs_nextcard_hidden($pname,$pass).'<input type="submit" value="계속" '.ebs_v('STYLE_B1').'></form> <form action="nextcard.php" method="POST" style="display:inline" target="Sub"><input type="hidden" name="cmd" value="PAY_OUT">'.ebs_nextcard_hidden($pname,$pass).'<input type="submit" value="정산" '.ebs_v('STYLE_B1').'></form></td></tr>';
    } else {
        unset($me['nextcard']);
        ebs_player_sync_common($me); $players[$key]=$me; ebs_players_save($players);
        echo '<tr><td colspan="4" align="center">실패했습니다. 베팅금은 회수되지 않습니다.</td></tr>';
    }
    ebs_nextcard_footer($pname,$pass);
}

function ebs_PAY_OUT(): void {
    [$ok,$me,$err,$players,$key] = ebs_nextcard_load_player();
    if (!$ok || !is_array($me) || $key === null) { ebs_error_page('Next Card', $err ?: '로그인 정보가 없습니다.'); return; }
    $pname=(string)($me['name'] ?? $key); $pass=ebs_param('pass', ebs_cookie_value('pass',''));
    $state = isset($me['nextcard']) && is_array($me['nextcard']) ? $me['nextcard'] : [];
    $win = max(0, (int)($state['payout'] ?? 0));
    if ($win > 0) {
        $me['money'] = (int)($me['money'] ?? 0) + $win;
        $me['nextcard_total_win'] = (int)($me['nextcard_total_win'] ?? 0) + $win;
        unset($me['nextcard']);
        ebs_player_sync_common($me); $players[$key]=$me; ebs_players_save($players);
    }
    ebs_nextcard_header('Next Card 정산');
    echo '<tr><td colspan="4" align="center">'.number_format($win).' G를 정산했습니다.</td></tr>';
    echo '<tr><td>파일럿</td><td>'.ebs_h($pname).'</td><td>소지금</td><td align="right">'.number_format((int)($me['money'] ?? 0)).' G</td></tr>';
    ebs_nextcard_footer($pname,$pass);
}

function ebs_DOUBLE_UP(): void { ebs_IN_GAME(); }
function ebs_DOUBLE(): void { ebs_CHANGE(); }
function ebs_HANTEI(): void { ebs_CHANGE(); }
function ebs_CARD_TABLE(): void { ebs_IN_GAME(); }
function ebs_TABLE_HTML(): void { ebs_IN_GAME(); }
function ebs_HAITOU(): void { ebs_PAY_OUT(); }
function ebs_FILE_OPEN(): void { ebs_START_GAME(); }
function ebs_LOCKA(): void { ebs_START_GAME(); }
function ebs_UNLOCKA(): void { ebs_START_GAME(); }
function ebs_ER_HTML(): void { ebs_START_GAME(); }
function ebs_HTML_EOF(): void { ebs_START_GAME(); }
function ebs_RANK_CHECK(): void { ebs_RANKING(); }

function ebs_RANKING(): void {
    $players = ebs_players_load();
    uasort($players, static function(array $a, array $b): int { return ebs_nextcard_rank_value($b) <=> ebs_nextcard_rank_value($a); });
    ebs_nextcard_header('Next Card 랭킹');
    echo '<tr bgcolor="#404040"><td>순위</td><td>파일럿</td><td>국가</td><td>누적정산</td></tr>';
    $rank=1;
    foreach ($players as $name=>$p) {
        if (!is_array($p) || ebs_nextcard_rank_value($p) <= 0) continue;
        echo '<tr><td align="right">'.$rank.'</td><td>'.ebs_h((string)($p['name'] ?? $name)).'</td><td>'.ebs_h((string)($p['kuni'] ?? '')).'</td><td align="right">'.number_format(ebs_nextcard_rank_value($p)).' G</td></tr>';
        if (++$rank > 50) break;
    }
    if ($rank === 1) echo '<tr><td colspan="4" align="center">랭킹 기록이 없습니다.</td></tr>';
    ebs_nextcard_footer();
}

function ebs_SETUMEI(): void {
    ebs_nextcard_header('Next Card 설명');
    echo '<tr><td colspan="4" style="line-height:1.7;background:#101010;">카드를 보고 다음 카드가 높을지 낮을지 선택합니다. 맞추면 지급 예정 금액이 2배가 되고, 틀리면 베팅금과 진행 중인 지급 예정 금액을 잃습니다. 같은 숫자는 HIGH/LOW 모두 성공으로 처리합니다.</td></tr>';
    ebs_nextcard_footer();
}

$map = [
    'START_GAME' => 'ebs_START_GAME',
    'IN_GAME' => 'ebs_IN_GAME',
    'ON_BET' => 'ebs_ON_BET',
    'CHANGE' => 'ebs_CHANGE',
    'HANTEI' => 'ebs_HANTEI',
    'CARD_TABLE' => 'ebs_CARD_TABLE',
    'TABLE_HTML' => 'ebs_TABLE_HTML',
    'PAY_OUT' => 'ebs_PAY_OUT',
    'DOUBLE_UP' => 'ebs_DOUBLE_UP',
    'DOUBLE' => 'ebs_DOUBLE',
    'RANKING' => 'ebs_RANKING',
    'SETUMEI' => 'ebs_SETUMEI',
    'RANK_CHECK' => 'ebs_RANK_CHECK',
    'HTML_EOF' => 'ebs_HTML_EOF',
    'ER_HTML' => 'ebs_ER_HTML',
    'HAITOU' => 'ebs_HAITOU',
    'FILE_OPEN' => 'ebs_FILE_OPEN',
    'LOCKA' => 'ebs_LOCKA',
    'UNLOCKA' => 'ebs_UNLOCKA',
];
ebs_dispatch($map, 'ebs_START_GAME');
?>
