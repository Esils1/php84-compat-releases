# EBS PHP 8.4 v86 최적화 및 안정화 보고서

## 기준

- 기준본: ebs_php84_v85_online_menu_fix.zip
- 실행 기준: PHP 8.4 전용
- 저장 기준: 원본 DBM/.db가 아닌 PHP JSON 파일 저장소 유지

## 적용 사항

1. 유저 JSON 로딩 안정화
   - UTF-8 BOM이 섞인 JSON도 배열로 안전하게 읽도록 공통 디코더를 추가했다.
   - config override, user JSON, data JSON, 관리자 백업 복원, 이동데이터 복원에 동일 디코더를 적용했다.

2. 요청 단위 유저 캐시 추가
   - 한 요청 안에서 user/*.json 전체를 반복 로딩하지 않도록 요청 단위 캐시를 적용했다.
   - 저장/삭제/전체복원 시 캐시를 즉시 갱신한다.
   - 전투/관리자/상단 접속자/국가목록처럼 같은 요청에서 유저 목록을 여러 번 읽는 화면의 디스크 I/O를 줄였다.

3. 유저명 변경/복원 안정화
   - 저장 대상 파일명을 player['name'] 기준으로 통일했다.
   - 기존 키와 실제 유저명이 달라지는 복원/정정 상황에서 이전 파일이 잔존하지 않도록 정리한다.
   - 신규등록 데이터 격리 보정은 유지한다.

4. 파일 저장 안정화
   - atomic rename 실패 시 fallback 저장에도 chmod(0664)를 적용했다.
   - 기존 flock 기반 sidecar lock 구조는 유지했다.

## 검증

- PHP 8.4 문법 검사: 전체 PHP 파일 통과
- ebs.php 라우트 86개 GET 검사: 200 또는 정상 302 응답
- Fatal/Parse/Warning/Notice/Deprecated 출력 없음
- 신규등록 격리 테스트: 기존 EB 쿠키가 있는 상태에서 신규 유저 2명 생성 시 각각 독립 user/*.json 파일 생성 확인
- g.php 접속자 표시 테스트: 로그인 쿠키 기준 현재 접속자 표시 확인
- 패키징 정리: .cgi, .lock, .tmp.*, .bak 제외
- img/ 폴더 제외 유지, img1/img2/bukiimg 등 실제 참조 리소스는 유지
