<?php
declare(strict_types=1);
require_once __DIR__ . '/../lib_ebs.php';
ebs_header_html();
$weapons = ebs_weapon_table();
echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Weapon Data</title></head><body bgcolor="#000000" text="#ffffff" style="margin:8px;font-size:13px;"><center><table border="1" cellspacing="0" cellpadding="4" bordercolor="#808080" bgcolor="#202020" style="min-width:760px;font-size:13px;"><tr><td colspan="8" bgcolor="#606060" align="center"><b>무기 데이터</b></td></tr><tr bgcolor="#606060"><td>ID</td><td>명칭</td><td>공격</td><td>명중</td><td>회수</td><td>EN</td><td>가격</td><td>효과</td></tr>';
$i=0; foreach($weapons as $id=>$row){ if($i++>=300) break; echo '<tr><td>'.ebs_h((string)$id).'</td><td>'.ebs_h((string)($row[0]??'')).'</td><td>'.ebs_h((string)($row[1]??'')).'</td><td>'.ebs_h((string)($row[2]??'')).'</td><td>'.ebs_h((string)($row[3]??'')).'</td><td>'.ebs_h((string)($row[4]??'')).'</td><td>'.ebs_h((string)($row[5]??'')).'</td><td>'.ebs_weapon_effects((string)($row[7]??''),(string)($row[6]??'')).'</td></tr>'; }
if($i===0) echo '<tr><td colspan="8" align="center">NoData</td></tr>'; echo '</table></center></body></html>';
?>
