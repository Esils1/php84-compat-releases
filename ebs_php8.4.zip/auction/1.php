<?php
declare(strict_types=1);
require_once __DIR__ . '/../lib_ebs.php';
ebs_header_html();
header('Location: ../auction.php');
?>
