<?php
declare(strict_types=1);
require_once __DIR__ . '/lib_ebs.php';
/** 제비뽑기: user/*.json items/warehouse_weapons와 data/hukubiki_log.json 기반. */
function ebs_huku_start(string $title='제비뽑기'): void { ebs_header_html(); echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>'.ebs_h($title).'</title></head><body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="margin:8px;font-size:13px;"><center><table border="1" cellspacing="0" cellpadding="5" bordercolor="'.ebs_h(ebs_v('TABLE_BORDER')).'" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" style="min-width:620px;font-size:13px;"><tr><td colspan="4" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'" align="center"><b>'.ebs_h($title).'</b></td></tr>'; }
function ebs_huku_end(): void { echo '</table></center></body></html>'; }
function ebs_huku_hidden(): string { return '<input type="hidden" name="pname" value="'.ebs_h(ebs_param('pname', ebs_cookie_value('pname',''))).'"><input type="hidden" name="pass" value="'.ebs_h(ebs_param('pass', ebs_cookie_value('pass',''))).'">'; }
function ebs_COOKIE_IN(): void { ebs_HUKUBIKI(); }
function ebs_SETUMEI(): void { ebs_huku_start('제비뽑기 설명'); echo '<tr><td>제비뽑기권이 있으면 1장 사용하고, 없으면 50,000G를 사용해 무기 또는 보조권을 획득합니다.</td></tr>'; ebs_huku_end(); }
function ebs_HUKUBIKI(): void { ebs_MAIN_HTML(); }
function ebs_INPORT(): void { ebs_MAIN_HTML(); }
function ebs_MAIN_HTML(): void {
    $p = ebs_current_player(); $items = is_array($p['items'] ?? null) ? $p['items'] : [];
    ebs_huku_start('제비뽑기');
    echo '<tr><td colspan="4">보유 제비뽑기권: '.number_format((int)($items['hukubiki']??0)).' / 보조권: '.number_format((int)($items['hojoken']??0)).'</td></tr>';
    echo '<tr><td colspan="4"><form method="post" action="hukubiki.php">'.ebs_huku_hidden().'<input type="hidden" name="cmd" value="IRERU"><input type="submit" value="제비뽑기" '.ebs_v('STYLE_B1').'> <a href="hukubiki.php?cmd=SETUMEI">설명</a></form></td></tr>';
    $log = array_reverse(array_slice(ebs_json_load('hukubiki_log'), -20));
    echo '<tr bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'"><td>시간</td><td>파일럿</td><td>결과</td><td>비고</td></tr>';
    foreach($log as $r) echo '<tr><td>'.ebs_h((string)($r['time']??'')).'</td><td>'.ebs_h((string)($r['pname']??'')).'</td><td>'.ebs_h((string)($r['result']??'')).'</td><td>'.ebs_h((string)($r['note']??'')).'</td></tr>';
    ebs_huku_end();
}
function ebs_IRERU(): void {
    [$key,$me,$players,$err]=ebs_require_player(); if($err!==''||$key===null||!is_array($me)){ ebs_error_page('제비뽑기 오류',$err); return; }
    if(!isset($me['items'])||!is_array($me['items'])) $me['items']=[];
    $cost=50000; $note='';
    if((int)($me['items']['hukubiki']??0)>0){ $me['items']['hukubiki']=(int)$me['items']['hukubiki']-1; $note='제비뽑기권 사용'; }
    elseif((int)($me['money']??0)>=$cost){ $me['money']=(int)$me['money']-$cost; $note='구입비 '.number_format($cost).'G 사용'; }
    else { ebs_error_page('제비뽑기 오류','제비뽑기권 또는 소지금이 부족합니다.'); return; }
    $roll=random_int(1,1000); $result='보조권';
    if($roll<=80){ $me['items']['hukubiki']=(int)($me['items']['hukubiki']??0)+1; $result='제비뽑기권'; }
    elseif($roll<=250){ $me['items']['hojoken']=(int)($me['items']['hojoken']??0)+1; $result='제비뽑기 보조권'; }
    else { $weapons=ebs_weapon_table(); $keys=array_keys($weapons); $wid=$keys ? (string)$keys[array_rand($keys)] : ebs_default_weapon_id(); $weapon=$wid.'!0'; if(!isset($me['warehouse_weapons'])||!is_array($me['warehouse_weapons'])) $me['warehouse_weapons']=[]; $me['warehouse_weapons'][]=$weapon; [, $wname] = ebs_calc_weapon_label($weapon); $result='무기: '.$wname; }
    $players[$key]=$me; ebs_players_save($players); $log=ebs_json_load('hukubiki_log'); $log[]=['time'=>date('Y-m-d H:i:s'),'pname'=>$key,'result'=>$result,'note'=>$note]; if(count($log)>100)$log=array_slice($log,-100); ebs_json_save('hukubiki_log',$log); ebs_MAIN_HTML();
}
function ebs_END_HTML(): void { ebs_MAIN_HTML(); }
function ebs_hukubiki_2(): void { ebs_IRERU(); }
$map=['COOKIE_IN'=>'ebs_COOKIE_IN','SETUMEI'=>'ebs_SETUMEI','HUKUBIKI'=>'ebs_HUKUBIKI','INPORT'=>'ebs_INPORT','MAIN_HTML'=>'ebs_MAIN_HTML','END_HTML'=>'ebs_END_HTML','IRERU'=>'ebs_IRERU','hukubiki'=>'ebs_hukubiki_2'];
ebs_dispatch($map,'ebs_COOKIE_IN');
?>
