<?php
declare(strict_types=1);
/**
 * EBS PHP 8.4 공통 런타임.
 *
 * 원본 PHP 8.4 파일 기반으로 동작시키기 위한 공통 함수 모음이다.
 * - 유저/국가/로그 데이터는 JSON 파일만 읽고 쓴다.
 * - 출력은 UTF-8 기준이다.
 * - 외부 실행 함수는 사용하지 않는다.
 * - 원본 IE 전용 강제 차단은 제거했다.
 */
if (function_exists('mb_internal_encoding')) { mb_internal_encoding('UTF-8'); }
if (session_status() === PHP_SESSION_NONE && !headers_sent()) { @session_start(); }
$GLOBALS['EBS_VARS'] = [
    'ADMIN' => 'Albert',
    'BANNER_DISPLAY' => '1',
    'BG_BUTTON' => '#000000',
    'BG_LIST' => '#000000',
    'BG_MAIN' => '#000000',
    'BG_STATUS' => '#000000',
    'BG_TOP' => '#000000',
    'COMMENT_1' => 'EBS 교육방송 Open<br>PvP를 전제로 한 게임입니다. PK당했다고 <font color=red>욕설/비방<font color=#111111>을 하지 맙시다.',
    'COMMENT_2' => '',
    'COMMENT_3' => '',
    'CONFIG_DISPLAY' => '1',
    'COOKIE_KEEP' => '1400',
    'COPYRIGHT_ICON' => '',
    'COUNTRY_MAX' => '10',
    'CUSTOM_NAME' => '개조',
    'C_MAX_MEMBER' => '40',
    'DIRECT_LINK' => '1',
    'ENTRY_MAX' => '1500',
    'EN_REPAIR' => '1',
    'EN_REPAIR2' => '0.5',
    'FC_BUTTON' => '#ededed',
    'FC_LIST' => '#ededed',
    'FONT_COLOR' => '#ffffff',
    'GET_MONEY' => '10',
    'HISTORY2_PAGE' => '1',
    'HISTORY3_PAGE' => '2',
    'HISTORY_MAX' => '9999',
    'HISTORY_PAGE' => '10',
    'HOVER' => '#dcdcdc',
    'HP_REPAIR' => '30',
    'HP_REPAIR2' => '0.5',
    'HP_REPAIR_Y' => '20',
    'ICON' => '985',
    'IMG_FOLDER1' => './img1',
    'IMG_FOLDER2' => './img2',
    'LINK' => '#707070',
    'LOG_FOLDER' => 'log',
    'MAIN_SCRIPT' => './ebs.php',
    'SCRIPTNM' => './ebs.php',
    'MAKE_COUNTRY' => '5000000',
    'MAKE_TEAM' => '50000',
    'MASTER_PWD' => '1064',
    'MAX_EN' => '200000',
    'MAX_HP' => '5000000',
    'MAX_WEAPONLV' => '100',
    'NAIRAN_MODE' => '1',
    'NONE_NATIONALITY' => '방랑자',
    'NT_END' => '1',
    'NT_START' => '1',
    'OWNER_EMAIL' => '',
    'OWNER_NAME' => 'Albert',
    'POOHLOVE' => '70',
    'SATELLITE_FLAG' => '0',
    'SPECIAL_ICON' => '0',
    'ST_limit' => '0.5',
    'ST_resetpay' => '0',
    'STperLEVEL' => '1',
    'S_ICON_NUMBER' => '514',
    'TABLE_BORDER' => '#808080',
    'TABLE_COLOR1' => '#202020',
    'TABLE_COLOR2' => '#606060',
    'THIS_DIR' => './',
    'UPDATA_MAX' => '9999',
    'UPPER_FRAME' => '380',
    'WEAPON_LVUP' => '100',
    'WEAPON_RANKUP' => '50',
    'YMICON' => '1008',
    'YOUR_BBS' => './board.php',
    'YOUR_HOME' => './',
    'YOUSAI_HP' => '600000',
    'BgColor' => 'bgcolor="#202020"',
    'CL_VALUES' => '#333333',
    'ENTRYS' => '0',
    'VER' => '',
    'DATE' => '',
    'STYLE_B1' => 'style="height:24px; background:#000000;color:#ededed; font-size:15px;"',
    'STYLE_B2' => 'style="height:22px; background:#000000;color:#ededed; font-size:13px;"',
    'STYLE_L' => 'style="height:21px; background:#000000;color:#ededed; font-size:15px;"',
    'adminad' => ' 운영자 : DarkWind // 다양한 이벤트 진행중 // 도우미 추가 ',
    'buimg' => './bukiimg',
    'event' => '0',
    'eventco' => ' - ',
    'hea' => '200000',
    'kk_time' => '0.2',
    'tip' => ' 렙업하면 [ 특별 - > 스텟찍기 ] 로 가서 스텟 분배하면 댄다 냥!. '
];
if (is_file(__DIR__ . '/config.php')) {
    $GLOBALS['EBS_CONFIG_LOADED'] = true;
    require_once __DIR__ . '/config.php';
}
// 관리자 화면에서 수정한 운영 설정은 소스 config.php를 직접 훼손하지 않고
// data/config_override.json으로 보관한 뒤 런타임에서 config.php 위에 덮어쓴다.
// 따라서 폴더 위치를 바꿔 업로드해도 상대 경로 기준으로 동작한다.
$__ebs_config_override_file = __DIR__ . '/data/config_override.json';
if (is_file($__ebs_config_override_file)) {
    $__ebs_config_override_raw = file_get_contents($__ebs_config_override_file);
    $__ebs_config_override = is_string($__ebs_config_override_raw) ? ebs_json_decode_array($__ebs_config_override_raw) : [];
    if (is_array($__ebs_config_override)) {
        foreach ($__ebs_config_override as $__k => $__v) {
            if (is_string($__k) && is_scalar($__v)) $GLOBALS['EBS_VARS'][$__k] = (string)$__v;
        }
    }
}
// 절대 URL이 남아 있으면 현재 설치 폴더 기준 상대 경로로 강제 보정한다.
foreach (['YOUR_HOME'=>'./','MAIN_SCRIPT'=>'./ebs.php','SCRIPTNM'=>'./ebs.php','YOUR_BBS'=>'./board.php','IMG_FOLDER1'=>'./img1','IMG_FOLDER2'=>'./img2','buimg'=>'./bukiimg'] as $__k=>$__default) {
    $__val = (string)($GLOBALS['EBS_VARS'][$__k] ?? '');
    if ($__val === '' || preg_match('/^https?:\/\//i', $__val)) $GLOBALS['EBS_VARS'][$__k] = $__default;
}
function ebs_header_html(): void { if (!headers_sent()) header('Content-Type: text/html; charset=UTF-8'); }
function ebs_h(mixed $v): string { return htmlspecialchars((string)$v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function ebs_color(string $v, string $default = '#ffffff'): string {
    $v = trim($v);
    if ($v === '') return $default;
    if (preg_match('/^#[0-9a-fA-F]{6}$/', $v)) return $v;
    if (preg_match('/^[0-9a-fA-F]{6}$/', $v)) return '#'.$v;
    return $default;
}
function ebs_arr(string $name): array {
    $a = $GLOBALS['EBS_ARRAYS'][$name] ?? [];
    return is_array($a) ? $a : [];
}
function ebs_v(string $name, mixed $default=''): string {
    if (array_key_exists($name, $GLOBALS['EBS_VARS'])) {
        $v = (string)$GLOBALS['EBS_VARS'][$name];
        if ($v !== '') return $v;
    }
    if (isset($_POST[$name]) && is_scalar($_POST[$name])) return (string)$_POST[$name];
    if (isset($_GET[$name]) && is_scalar($_GET[$name])) return (string)$_GET[$name];
    $fallbacks = [
        'FORM' => '',
            'CONDITIONAL' => '',
        'STATUS_NAME' => '',
        'AT' => '0', 'DE' => '0', 'MT' => '0', 'HI' => '0', 'SP' => '0',
        'ATST' => '0', 'DEST' => '0', 'MTST' => '0',
        'total' => '0', 'sanka' => '0', 'totalC' => '0', 'sankaC' => '0',
        '_' => '1', 'ad_comment' => '', 'EX' => '',
    ];
    if (array_key_exists($name, $fallbacks)) return (string)$fallbacks[$name];
    return (string)$default;
}
/** mbstring 확장이 없어도 등록명 길이 검사를 수행한다. */
function ebs_strlen(string $s): int { return function_exists('mb_strlen') ? mb_strlen($s, 'UTF-8') : strlen($s); }

function ebs_param(string $name, string $default=''): string {
    $v = $_POST[$name] ?? $_GET[$name] ?? null;
    if ($v === null && isset($_SERVER['REQUEST_URI']) && is_string($_SERVER['REQUEST_URI'])) {
        $uri = (string)$_SERVER['REQUEST_URI'];
        $q = parse_url($uri, PHP_URL_QUERY);
        if (is_string($q) && $q !== '') {
            $tmp = [];
            parse_str($q, $tmp);
            if (array_key_exists($name, $tmp)) $v = $tmp[$name];
        }
        // 잘못 생성된 /method=POST?cmd=... 같은 경로도 query 부분은 정상 인식한다.
    }
    if ($v === null) $v = $default;
    return is_scalar($v) ? trim((string)$v) : $default;
}
function ebs_clean_login_value(string $v): string {
    $v = html_entity_decode(trim($v), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    if ($v === '' || preg_match('/[\"<>\s\x00-\x1F]/u', $v)) return '';
    return preg_match('/^[0-9A-Za-z_\-가-힣ぁ-んァ-ン一-龥]{1,40}$/u', $v) ? $v : '';
}

/**
 * 신규등록명 서버측 정규화.
 * 브라우저에 이전 EB 쿠키/자동완성 값이 남아 있으면 old"new" 형태로 POST 되는 경우가 있어
 * 그대로 저장하면 user/*.json의 name과 쿠키가 동시에 깨진다. 원본에서 허용 가능한 이름 문자만 인정하고,
 * old"new"/old&quot;new&quot; 꼴은 마지막 따옴표 뒤의 신규명만 사용한다.
 */
function ebs_clean_registration_name(string $v): string {
    $v = html_entity_decode(trim($v), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    $v = str_replace(["\r", "\n", "\t"], '', $v);
    if ($v === '') return '';
    if (preg_match('/[\"\']\s*([0-9A-Za-z_\-가-힣ぁ-んァ-ン一-龥]{1,40})\s*[\"\']?\s*$/u', $v, $m)) {
        return $m[1];
    }
    return preg_match('/^[0-9A-Za-z_\-가-힣ぁ-んァ-ン一-龥]{1,40}$/u', $v) ? $v : '';
}
function ebs_clean_registration_password(string $v): string {
    $v = html_entity_decode(trim($v), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    if ($v === '' || preg_match('/[\"<>\s\x00-\x1F]/u', $v)) return '';
    return preg_match('/^[0-9A-Za-z_\-가-힣ぁ-んァ-ン一-龥]{1,40}$/u', $v) ? $v : '';
}
function ebs_cmd(string $default='TOP'): string {
    if (isset($GLOBALS['EBS_FORCE_CMD']) && is_string($GLOBALS['EBS_FORCE_CMD']) && $GLOBALS['EBS_FORCE_CMD'] !== '') return $GLOBALS['EBS_FORCE_CMD'];
    foreach ($_GET as $k=>$v) { if (($v === '' || $v === '1') && preg_match('/^[A-Za-z0-9_]+$/', (string)$k)) return (string)$k; }
    $cmd = ebs_param('SUB', '');
    if ($cmd === '') $cmd = ebs_param('cmd', '');
    if ($cmd === '' && isset($_SERVER['REQUEST_URI']) && is_string($_SERVER['REQUEST_URI'])) {
        $q = parse_url((string)$_SERVER['REQUEST_URI'], PHP_URL_QUERY);
        if (is_string($q) && $q !== '') {
            $tmp = [];
            parse_str($q, $tmp);
            if (isset($tmp['cmd']) && is_scalar($tmp['cmd'])) $cmd = trim((string)$tmp['cmd']);
        }
    }
    if ($cmd === '') $cmd = $default;
    return preg_match('/^[A-Za-z0-9_]+$/', $cmd) ? $cmd : $default;
}
function ebs_file(string $rel): string { return __DIR__.'/'.ltrim($rel,'/'); }

/** JSON 저장소 안정화: UTF-8 BOM/공백을 제거하고 배열만 허용한다. */
function ebs_json_decode_array(string $raw): array {
    if ($raw === '') return [];
    $raw = preg_replace('/^\xEF\xBB\xBF/', '', $raw) ?? $raw;
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}
function ebs_players_cache_clear(): void { unset($GLOBALS['EBS_PLAYERS_CACHE']); }
function ebs_players_cache_set(array $players): void { $GLOBALS['EBS_PLAYERS_CACHE'] = $players; }
function ebs_players_cache_get(): ?array {
    return isset($GLOBALS['EBS_PLAYERS_CACHE']) && is_array($GLOBALS['EBS_PLAYERS_CACHE']) ? $GLOBALS['EBS_PLAYERS_CACHE'] : null;
}
function ebs_player_storage_hash(array $player): string {
    $copy = $player;
    ksort($copy);
    $json = json_encode($copy, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
    return hash('sha256', is_string($json) ? $json : serialize($copy));
}
function ebs_players_base_hashes_set(array $hashes): void { $GLOBALS['EBS_PLAYERS_BASE_HASHES'] = $hashes; }
function ebs_players_base_hashes_get(): array { return isset($GLOBALS['EBS_PLAYERS_BASE_HASHES']) && is_array($GLOBALS['EBS_PLAYERS_BASE_HASHES']) ? $GLOBALS['EBS_PLAYERS_BASE_HASHES'] : []; }
function ebs_players_base_hash_set(string $name, array $player): void {
    if (!isset($GLOBALS['EBS_PLAYERS_BASE_HASHES']) || !is_array($GLOBALS['EBS_PLAYERS_BASE_HASHES'])) $GLOBALS['EBS_PLAYERS_BASE_HASHES'] = [];
    $GLOBALS['EBS_PLAYERS_BASE_HASHES'][$name] = ebs_player_storage_hash($player);
}

/**
 * 파일 저장 기준 잠금 처리.
 * - user/*.json.lock, user/.players_state.lock 같은 sidecar lock은 더 이상 생성하지 않는다.
 * - 기본 lock 위치는 시스템 임시 폴더이다. 따라서 user/ 또는 data/에 잠금 파일이 누적되지 않는다.
 * - 과거 배포본이 만든 sidecar lock 및 data/.locks 잔존 lock은 현재 사용 중이 아니고 잠금 가능할 때만 정리한다.
 */
function ebs_lock_root_dir(): string {
    $tmpBase = rtrim(sys_get_temp_dir(), '/\\');
    $tmpLockDir = $tmpBase.'/ebs_locks_'.substr(sha1(__DIR__), 0, 16);
    if (!is_dir($tmpLockDir)) @mkdir($tmpLockDir, 0775, true);
    if (is_dir($tmpLockDir) && is_writable($tmpLockDir)) return $tmpLockDir;

    $fallback = __DIR__.'/data/.locks';
    if (!is_dir($fallback)) @mkdir($fallback, 0775, true);
    return $fallback;
}
function ebs_try_remove_lock_file(string $file, int $minAgeSeconds=0): bool {
    if (!is_file($file)) return false;
    $mtime = (int)(@filemtime($file) ?: 0);
    if ($minAgeSeconds > 0 && $mtime > 0 && (time() - $mtime) < $minAgeSeconds) return false;
    $fp = @fopen($file, 'c+');
    if ($fp === false) return false;
    $ok = false;
    if (@flock($fp, LOCK_EX | LOCK_NB)) {
        @flock($fp, LOCK_UN);
        $ok = true;
    }
    @fclose($fp);
    return $ok ? @unlink($file) : false;
}
function ebs_cleanup_lock_files(int $internalMinAgeSeconds=600): int {
    $removed = 0;
    $userDir = __DIR__.'/user';
    if (is_dir($userDir)) {
        foreach (glob($userDir.'/*.json.lock') ?: [] as $lock) {
            if (ebs_try_remove_lock_file($lock, 0)) $removed++;
        }
        $legacyStateLock = $userDir.'/.players_state.lock';
        if (ebs_try_remove_lock_file($legacyStateLock, 0)) $removed++;
    }

    foreach ([__DIR__.'/data/.locks', ebs_lock_root_dir()] as $dir) {
        if (!is_dir($dir)) continue;
        foreach (glob($dir.'/*.lock') ?: [] as $lock) {
            if (ebs_try_remove_lock_file($lock, $internalMinAgeSeconds)) $removed++;
        }
        if ($dir === __DIR__.'/data/.locks') {
            $left = glob($dir.'/*.lock') ?: [];
            if (!$left) @rmdir($dir);
        }
    }
    return $removed;
}
function ebs_lock_path_for(string $absPath): string {
    $rel = str_replace(__DIR__, '', $absPath);
    return ebs_lock_root_dir().'/'.sha1($rel !== '' ? $rel : $absPath).'.lock';
}
function ebs_with_file_lock(string $absPath, int $mode, callable $callback): mixed {
    static $cleanupDone = false;
    if (!$cleanupDone) {
        $cleanupDone = true;
        ebs_cleanup_lock_files(600);
    }

    $dir = dirname($absPath);
    if (!is_dir($dir) && !mkdir($dir, 0775, true) && !is_dir($dir)) return null;
    $lockPath = ebs_lock_path_for($absPath);
    $lockDir = dirname($lockPath);
    if (!is_dir($lockDir) && !mkdir($lockDir, 0775, true) && !is_dir($lockDir)) return null;
    $lock = @fopen($lockPath, 'c');
    if ($lock === false) return null;
    try {
        if (!flock($lock, $mode)) return null;
        return $callback();
    } finally {
        @flock($lock, LOCK_UN);
        @fclose($lock);
    }
}

function ebs_read(string $rel): string {
    $p = ebs_file($rel);
    if (!is_file($p)) return '';
    $data = ebs_with_file_lock($p, LOCK_SH, static function () use ($p): string {
        $d = file_get_contents($p);
        return $d === false ? '' : $d;
    });
    return is_string($data) ? $data : '';
}

function ebs_write(string $rel, string $data): bool {
    $p = ebs_file($rel);
    $ok = ebs_with_file_lock($p, LOCK_EX, static function () use ($p, $data): bool {
        $d = dirname($p);
        if (!is_dir($d) && !mkdir($d, 0775, true) && !is_dir($d)) return false;
        try { $suffix = bin2hex(random_bytes(4)); } catch (Throwable) { $suffix = str_replace('.', '', uniqid('', true)); }
        $tmp = $p.'.tmp.'.getmypid().'.'.$suffix;
        $bytes = file_put_contents($tmp, $data, LOCK_EX);
        if ($bytes === false) { @unlink($tmp); return false; }
        @chmod($tmp, 0664);
        if (!@rename($tmp, $p)) {
            @unlink($tmp);
            $fallbackOk = file_put_contents($p, $data, LOCK_EX) !== false;
            if ($fallbackOk) @chmod($p, 0664);
            return $fallbackOk;
        }
        return true;
    });
    return $ok === true;
}

function ebs_json_load(string $name): array {
    $raw = ebs_read('data/'.$name.'.json');
    if ($raw === '') return [];
    return ebs_json_decode_array($raw);
}
function ebs_json_save(string $name, array $data): bool { return ebs_write('data/'.$name.'.json', json_encode($data, JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT)); }

/** 유저 관련 로그는 txt 파일을 생성하지 않고 기존 JSON 로그 저장소에 누적한다. */
function ebs_user_event_log(string $type, array $payload = []): void {
    // 추가 로그 파일을 만들지 않는다. 필요한 상태 변경은 user/*.json/countrydata.json에만 반영한다.
}
function ebs_record_post(string $scope): void {
    // 추가 검사/로그 파일을 만들지 않는다.
}
function ebs_dispatch(array $map, string $default): void { $cmd=ebs_cmd($default); if(isset($map[$cmd]) && function_exists($map[$cmd])) { $map[$cmd](); return; } if(function_exists($default)) { $default(); return; } ebs_header_html(); echo '<html><body></body></html>'; }




/**
 * CLI 검사용 QUERY_STRING 파서.
 * 실제 웹 서버에서는 PHP가 $_GET을 채우지만, php-cli lint/실행 비교에서는 비어 있으므로
 * 원본 legacy 비교 작업에서 ebs.php?LOGIN 같은 쿼리 라우팅을 동일하게 재현한다.
 */
function ebs_import_cli_query_string(): void {
    if (PHP_SAPI !== 'cli') return;
    if (!empty($_GET)) return;
    $qs = getenv('QUERY_STRING');
    if (!is_string($qs) || $qs === '') return;
    if (str_contains($qs, '=')) {
        parse_str($qs, $_GET);
        return;
    }
    if (preg_match('/^[A-Za-z0-9_]+$/', $qs)) {
        $_GET[$qs] = '';
    }
}
ebs_import_cli_query_string();


/** img2 폴더의 실제 아이콘 파일 목록을 숫자 순서로 반환한다. */
function ebs_existing_icon_ids(): array {
    static $ids = null;
    if (is_array($ids)) return $ids;
    $ids = [];
    $dir = ebs_file(trim(ebs_v('IMG_FOLDER2', './img2'), './'));
    if (!is_dir($dir)) $dir = ebs_file('img2');
    foreach (glob($dir.'/*.gif') ?: [] as $file) {
        $base = pathinfo($file, PATHINFO_FILENAME);
        if (preg_match('/^[0-9A-Za-z_\-]+$/', $base)) $ids[] = $base;
    }
    usort($ids, static function (string $a, string $b): int {
        $an = ctype_digit($a); $bn = ctype_digit($b);
        if ($an && $bn) return (int)$a <=> (int)$b;
        if ($an !== $bn) return $an ? -1 : 1;
        return strcmp($a, $b);
    });
    return $ids;
}
function ebs_icon_exists(string $icon): bool {
    if ($icon === '' || !preg_match('/^[0-9A-Za-z_\-]+$/', $icon)) return false;
    $dirRel = trim(ebs_v('IMG_FOLDER2', './img2'), './');
    return is_file(ebs_file($dirRel.'/'.$icon.'.gif')) || is_file(ebs_file('img2/'.$icon.'.gif'));
}
function ebs_normalize_icon(string $icon, string $fallback='1'): string {
    $icon = trim($icon);
    if (ebs_icon_exists($icon)) return $icon;
    if (ebs_icon_exists($fallback)) return $fallback;
    $ids = ebs_existing_icon_ids();
    return $ids[0] ?? $fallback;
}


/** 배경색 대비에 맞는 글자색을 고른다. 국가색/버튼색이 너무 밝거나 어두워도 글자가 보이도록 한다. */
function ebs_hex_to_rgb(string $color): array {
    $color = trim($color);
    if ($color !== '' && $color[0] !== '#') $color = '#'.$color;
    if (!preg_match('/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/', $color, $m)) return [128,128,128];
    $hex = $m[1];
    if (strlen($hex) === 3) $hex = $hex[0].$hex[0].$hex[1].$hex[1].$hex[2].$hex[2];
    return [hexdec(substr($hex,0,2)), hexdec(substr($hex,2,2)), hexdec(substr($hex,4,2))];
}
function ebs_contrast_text_color(string $background): string {
    [$r,$g,$b] = ebs_hex_to_rgb($background);
    $luma = ($r * 299 + $g * 587 + $b * 114) / 1000;
    return $luma >= 145 ? '#000000' : '#ffffff';
}
function ebs_visible_player_color(string $color, string $background='#202020'): string {
    $color = trim($color);
    if ($color !== '' && $color[0] !== '#') $color = '#'.$color;
    if (!preg_match('/^#[0-9a-fA-F]{3,6}$/', $color)) return '#ededed';
    [$r,$g,$b] = ebs_hex_to_rgb($color);
    [$br,$bg,$bb] = ebs_hex_to_rgb($background);
    $dist = abs($r-$br) + abs($g-$bg) + abs($b-$bb);
    if ($dist < 96) return '#ededed';
    return $color;
}
function ebs_country_icon(string $icon): string { return ebs_normalize_icon($icon, '1000'); }
function ebs_country_button_style(string $color): string {
    if ($color !== '' && $color[0] !== '#') $color = '#'.$color;
    if (!preg_match('/^#[0-9a-fA-F]{3,6}$/', $color)) $color = '#606060';
    return 'background:'.$color.';color:'.ebs_contrast_text_color($color).';border:1px solid #999999;min-width:54px;height:22px;font-size:13px;';
}
function ebs_event_type_label(string $type): string {
    $map = [
        'battle'=>'전투', 'npc_battle'=>'NPC전투', 'dungeon_battle'=>'던전전투', 'dungeonss_battle'=>'랜덤던전전투',
        'dungeon'=>'지하감옥', 'dungeonss'=>'랜덤던전', 'newentry'=>'신규등록', 'delete'=>'등록삭제', 'import'=>'데이터복원',
        'finance'=>'금융', 'bukiko'=>'무기고', 'personal_weapon'=>'개인무기', 'numbers'=>'넘버즈', 'unit'=>'부대',
        'post'=>'화면이동', 'auction'=>'경매', 'warehouse'=>'창고', 'event'=>'기록'
    ];
    return $map[$type] ?? $type;
}
function ebs_event_result_label(string $result): string {
    $map = ['win'=>'승리', 'lose'=>'패배', 'draw'=>'무승부', 'lost'=>'패배', 'success'=>'성공', 'fail'=>'실패'];
    return $map[$result] ?? $result;
}
function ebs_format_event_history_text(array $player, string $fallbackName, array $ev): string {
    $name = (string)($player['name'] ?? $fallbackName);
    $type = (string)($ev['type'] ?? 'event');
    if ($type === 'newentry') {
        $created = ebs_clean_login_value((string)($ev['pname'] ?? $name));
        if ($created === '') $created = $name;
        return $created.' '.ebs_event_type_label($type);
    }
    $txt = $name.' '.ebs_event_type_label($type);
    if (isset($ev['enemy'])) $txt .= ' 대 '.(string)$ev['enemy'];
    if (isset($ev['to'])) $txt .= ' → '.(string)$ev['to'];
    if (isset($ev['from'])) $txt .= ' ← '.(string)$ev['from'];
    if (isset($ev['amount'])) $txt .= ' $'.number_format((int)$ev['amount']);
    if (isset($ev['result'])) $txt .= ' '.ebs_event_result_label((string)$ev['result']);
    if (isset($ev['floor'])) $txt .= ' '.(int)$ev['floor'].'층';
    if (isset($ev['money'])) $txt .= ' 획득금 $'.number_format((int)$ev['money']);
    if (isset($ev['exp'])) $txt .= ' 경험치 +'.number_format((int)$ev['exp']);
    return $txt;
}

function ebs_weapon_table(): array {
    static $cache = null;
    if (is_array($cache)) return $cache;
    $json = ebs_json_load('weapons');
    if ($json) { $cache = $json; return $cache; }
    $cache = [];
    $raw = ebs_read('log/_buki.data');
    if ($raw === '') return $cache;
    if (function_exists('mb_check_encoding') && function_exists('mb_convert_encoding') && !mb_check_encoding($raw, 'UTF-8')) {
        $raw = mb_convert_encoding($raw, 'UTF-8', 'CP949,EUC-KR,Shift_JIS,EUC-JP');
    } elseif (function_exists('iconv') && !preg_match('//u', $raw)) {
        $converted = @iconv('CP949', 'UTF-8//IGNORE', $raw);
        if (is_string($converted) && $converted !== '') { $raw = $converted; }
    }
    if (preg_match_all('/^\s*"([^"]+)"\s*=>\s*"([^"]*)"/m', $raw, $m, PREG_SET_ORDER)) {
        foreach ($m as $row) {
            $cache[$row[1]] = str_getcsv($row[2], ',', '"', '\\');
        }
    }
    // 원본 _buki.data 기재 순서를 그대로 유지한다.
    return $cache;
}

function ebs_default_weapon_id(): string {
    $weapons = ebs_weapon_table();
    if (isset($weapons['c'])) return 'c';
    if (isset($weapons['0'])) return '0';
    $keys = array_keys($weapons);
    return $keys ? (string)$keys[0] : '0';
}

/** 원본 CGI의 레벨 경험치 표시에 맞춘 다음 레벨 필요 경험치. 예: Lv1=1000, Lv101=51000. */
function ebs_level_threshold(int $level): int {
    return max(1000, ($level + 1) * 500);
}

/** 경험치 누적 후 필요한 만큼 레벨업한다. 경험치는 다음 레벨 기준에서 차감되어 남는다. */
function ebs_apply_levelup(array &$player): array {
    $level = max(1, (int)($player['level'] ?? ebs_player_raw_get($player, 0, '1')));
    $exp = max(0, (int)($player['level_exp'] ?? ($player['exp'] ?? ebs_player_raw_get($player, 30, '0'))));
    $up = 0;
    while ($exp >= ebs_level_threshold($level)) {
        $exp -= ebs_level_threshold($level);
        $level++;
        $up++;
        if ($up > 1000) break;
    }
    $player['level'] = $level;
    $player['level_exp'] = $exp;
    $player['exp'] = $exp;
    if (!isset($player['rank'])) $player['rank'] = ebs_player_raw_get($player, 0, '0');
    ebs_player_raw_set($player, 0, (string)($player['rank'] ?? ebs_player_raw_get($player, 0, '0')));
    ebs_player_raw_set($player, 29, (string)$level);
    ebs_player_raw_set($player, 30, (string)$exp);
    return [$level, $exp, $up];
}

function ebs_weapon_exists(string $weapon): bool {
    $id = explode('!', $weapon, 2)[0];
    $weapons = ebs_weapon_table();
    return isset($weapons[$id]);
}

/** 원본 STATUS_CONVERT 일부 재현: 무기 공격/명중 랭크 표시. */
function ebs_status_rank(float|int|string $value): string {
    $v = (float)$value;
    $idx = (int)floor($v / 5);
    if ($idx < 0) $idx = 0;
    if ($idx > 20) $idx = 20;
    $colors = ['#5000CC','#8000ff','#a000e5','#bf00cc','#df00a6','#ff0080','#f7e957','#f7e957','#f7e957','#ff0080','#ff0080','#ff0080','#ff0080','#ff0080','#ff0080','#ff0080','#ff0080','#ff0080','#ff0080','#ff0080','#ff0080'];
    $ranks = ['F','E','D','C','B','A','S','SS','SSS','ACE','NT','NT1','NT2','NT3','NT4','NT5','NT6','NT7','NT8','NT9','NT10'];
    return '<b style="color:'.$colors[$idx].';">'.$ranks[$idx].'</b>';
}

/** 원본 특수효과 코드 문자열을 표시명으로 변환한다. */
function ebs_weapon_effects(string $code, string $limit): string {
    $out = [];
    if ($code === '' || $code === '0') $out[] = 'none';
    $map = ['1'=>'상대기체파손','2'=>'상대기체대파','4'=>'방어력업','3'=>'스피드업','c'=>'명중력업','5'=>'HP 드레인','6'=>'에너지 회복','7'=>'행운','8'=>'데미지 반사','9'=>'EN 드레인','a'=>'머니 드레인','b'=>'경험치 드레인'];
    foreach ($map as $k=>$v) if (str_contains($code, (string)$k)) $out[] = $v;
    if (str_contains($limit, 'a')) $out[] = '<font color=yellow>레벨 제한 : 500</font>';
    if (str_contains($limit, 'b')) $out[] = '<font color=yellow>레벨 제한 : 1000</font>';
    return implode('<br>', $out).'<br>';
}


/** 원본 상태창/관리창에서 사용하던 성격명. */
function ebs_chara_names(): array {
    return ['0'=>'드셈','1'=>'소극','2'=>'보통','3'=>'격정','4'=>'냉정','5'=>'냉혹'];
}
function ebs_chara_label(string $value): string {
    $names = ebs_chara_names();
    return $names[$value] ?? ($value !== '' ? $value : '드셈');
}
function ebs_player_contrib_value(array $player): int {
    $v = $player['contrib'] ?? $player['contribution'] ?? ebs_player_raw_get($player, 43, '0');
    return is_numeric($v) ? (int)$v : 0;
}
function ebs_player_job_value(array $player): int {
    $v = $player['job'] ?? ebs_player_raw_get($player, 6, '0');
    if (is_numeric($v)) return (int)$v;
    $classes = ebs_arr('CLASS_NAME');
    if (!$classes) $classes = ['거지','천민','농민','중민','부르주아','기사','성주','남작','백작','후작','공작','국왕'];
    $idx = array_search((string)$v, array_map('strval', $classes), true);
    return $idx === false ? 0 : ((int)$idx * 10);
}
function ebs_player_class_index_from_value($value): int {
    $classes = ebs_arr('CLASS_NAME');
    if (!$classes) $classes = ['거지','천민','농민','중민','부르주아','기사','성주','남작','백작','후작','공작','국왕'];
    if (is_numeric($value)) return max(0, min(count($classes) - 1, (int)floor(((int)$value) / 10)));
    $idx = array_search((string)$value, array_map('strval', $classes), true);
    return $idx === false ? 0 : (int)$idx;
}
function ebs_player_class_label(array $player): string {
    $classes = ebs_arr('CLASS_NAME');
    if (!$classes) $classes = ['거지','천민','농민','중민','부르주아','기사','성주','남작','백작','후작','공작','국왕'];
    $idx = ebs_player_class_index_from_value($player['job'] ?? ebs_player_raw_get($player, 6, '0'));
    return (string)$classes[$idx];
}
function ebs_player_rank_label(array $player): string {
    $rank = ebs_player_rank_value($player);
    return ebs_status_rank($rank).'('.ebs_h(rtrim(rtrim(sprintf('%.4F', $rank), '0'), '.')).')';
}

/**
 * 원본 CGI 던전/메인 상단에 있던 파일럿 상세 패널을 PHP 화면에서도 재사용한다.
 * 표시만 보강하며 전투/저장 로직은 변경하지 않는다.
 */
function ebs_render_legacy_player_panel(array $p, string $pname, string $pass='', string $context=''): void {
    $msname = ebs_plv($p, 3, $pname);
    $hp=ebs_plv_int($p,15,4000); $mhp=max(1,ebs_plv_int($p,16,4000));
    $en=ebs_plv_int($p,17,200); $men=max(1,ebs_plv_int($p,18,200));
    $level=ebs_plv_int($p,29,ebs_plv_int($p,0,1)); $exp=ebs_plv_int($p,30,0); $need=ebs_level_threshold($level); $money=ebs_plv_int($p,8,0);
    $st = [ebs_plv_int($p,19,0), ebs_plv_int($p,20,0), ebs_plv_int($p,21,0), ebs_plv_int($p,22,0)];
    $weapon=ebs_plv($p,9,''); [$weaponId,$weaponLvRaw] = array_pad(explode('!', $weapon, 2), 2, '0'); $weaponRow = ebs_weapon_table()[$weaponId] ?? ebs_weapon_table()[$weapon] ?? [];
    $weaponName = (string)($weaponRow[0] ?? ($weapon !== '' ? $weapon : '무장비'));
    $weaponLv = (int)floor(((int)$weaponLvRaw)/(int)max(1,(int)ebs_v('WEAPON_LVUP','100')));
    $weaponExp = ((int)$weaponLvRaw)%(int)max(1,(int)ebs_v('WEAPON_LVUP','100'));
    [$w2id,$w2name,$w2lv,$w2exp] = ebs_calc_weapon_label((string)($p['weapon2'] ?? ''));
    [$w3id,$w3name,$w3lv,$w3exp] = ebs_calc_weapon_label((string)($p['weapon3'] ?? ''));
    $armorRaw = (string)($p['armor'] ?? ebs_player_raw_get($p,32,'')); [$armorId,$armorDur]=array_pad(explode('!', $armorRaw, 2), 2, '');
    $armorTable = ebs_bougu_table(); $armorRow = ($armorId !== '' && isset($armorTable[$armorId])) ? $armorTable[$armorId] : [];
    $armorName = $armorRow ? (string)($armorRow[0] ?? $armorId) : '';
    $armorSpec = $armorRow ? (string)($armorRow[9] ?? ($armorRow[8] ?? '')) : '';
    $icon=ebs_normalize_icon(ebs_plv($p,27,'1'), '1'); $color=ebs_color(ebs_plv($p,13,'#ffffff'));
    $chara = (string)($p['chara'] ?? ebs_player_raw_get($p,12,'0'));
    $comment = (string)($p['comment'] ?? ebs_player_raw_get($p,7,''));
    $contrib = ebs_player_contrib_value($p);
    $job = ebs_player_job_value($p);
    $classLabel = ebs_player_class_label($p);
    $kuni = (string)($p['kuni'] ?? ebs_player_raw_get($p,5,''));
    $hpw=max(0,min(100,(int)floor($hp/$mhp*100))); $enw=max(0,min(100,(int)floor($en/$men*100)));
    echo '<table width="100%" cellspacing="1" cellpadding="3" bgcolor="'.ebs_h(ebs_v('TABLE_BORDER')).'" style="font-size:13px;color:'.ebs_h(ebs_v('FONT_COLOR')).';table-layout:fixed;">';
    echo '<tr bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'"><td colspan="4"><b style="font-size:16px;color:'.ebs_h($color).'">'.ebs_h($pname).'</b> <span>('.ebs_h($msname).')</span> <span style="float:right">국가: '.ebs_h($kuni !== '' ? $kuni : ebs_v('NONE_NATIONALITY','방랑자')).' / 성격: '.ebs_h(ebs_chara_label($chara)).' / 계급: '.ebs_player_rank_label($p).' / 작위: '.ebs_h($classLabel).' / 공헌도: '.number_format($contrib).'</span></td></tr>';
    echo '<tr bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'">';
    echo '<td width="120" align="center" valign="top"><img src="'.ebs_h(ebs_v('IMG_FOLDER2')).'/'.ebs_h($icon).'.gif"><br>'.ebs_h($msname).'<br>숙련('.ebs_h(ebs_plv($p,24,'0')).')<br>작위('.ebs_h($classLabel).')<br>공헌('.number_format($contrib).')<br>성격('.ebs_h(ebs_chara_label($chara)).')<br><a href="'.ebs_h(ebs_v('MAIN_SCRIPT')).'?STATUSUP&amp;pname='.rawurlencode($pname).'&amp;pass='.rawurlencode($pass).'" target="Sub">발전가능</a></td>';
    echo '<td width="220" valign="top"><table width="100%" cellspacing="1" cellpadding="2" style="font-size:13px;color:'.ebs_h(ebs_v('FONT_COLOR')).';">';
    foreach ([['공격',0],['방어',1],['명중',3],['속도',2],['행운',4]] as $row) { $val = $row[1]===4 ? 10 : ($st[$row[1]] ?? 0); $bar=min(120,max(10,(int)$val*3)); echo '<tr><td width="48">'.$row[0].'</td><td>'.ebs_status_rank($val).'('.ebs_h((string)$val).') <span style="display:inline-block;width:'.$bar.'px;background:#004010;border-left:3px solid red;height:16px;vertical-align:middle;"></span></td></tr>'; }
    if ($comment !== '') echo '<tr><td colspan="2">코멘트: '.ebs_h($comment).'</td></tr>';
    echo '</table></td>';
    echo '<td width="190" valign="top"><b>HP</b> <span style="float:right">'.$hp.'/'.$mhp.'</span><br><div style="width:170px;background:#303030"><div style="width:'.$hpw.'%;background:#00a0ff;height:5px"></div></div>';
    echo '<b>EN</b> <span style="float:right">'.$en.'/'.$men.'</span><br><div style="width:170px;background:#303030"><div style="width:'.$enw.'%;background:#00a0ff;height:5px"></div></div>';
    echo 'Level <b>'.$level.'</b><br>EXP <b>'.$exp.'/'.$need.'</b><br>Gold <b>'.number_format($money).'</b><br>금괴 <b>'.ebs_h(ebs_plv($p,72,'0')).'개</b><br>전적 <b>'.ebs_h((string)(ebs_plv_int($p,41,0)+ebs_plv_int($p,42,0))).'전 '.ebs_h(ebs_plv($p,41,'0')).'승 '.ebs_h(ebs_plv($p,42,'0')).'패</b><br>계급값 <b>'.ebs_player_rank_label($p).'</b><br>직위값 <b>'.number_format($job).'</b></td>';
    echo '<td valign="top" style="line-height:1.55;padding-left:6px;">';
    echo '<span style="background:#606060;padding:2px 5px">장비</span> [<img src="'.ebs_h(ebs_v('buimg')).'/'.ebs_h((string)($weaponRow[9] ?? '00')).'.png" width="16" height="16" onerror="this.src=\''.ebs_h(ebs_v('buimg')).'/00.gif\'">] <b>'.ebs_h($weaponName).'</b> Lv.'.ebs_h((string)$weaponLv).'/exp.'.ebs_h((string)$weaponExp).'<br>';
    echo '<span style="background:#606060;padding:2px 5px">성능</span> 공격：'.ebs_h((string)($weaponRow[1] ?? '0')).' 명중：'.ebs_h((string)($weaponRow[2] ?? '0')).' EN：'.ebs_h((string)($weaponRow[4] ?? '0')).' 효과：'.ebs_h((string)($weaponRow[7] ?? ($weaponRow[5] ?? '없음'))).'<br>';
    echo '<span style="background:#606060;padding:2px 5px">예비</span> '.($w2id !== '' ? ebs_h($w2name.' Lv.'.$w2lv.'/exp.'.($w2exp % max(1,(int)ebs_v('WEAPON_LVUP','100')))) : '').'<br>';
    echo '<span style="background:#606060;padding:2px 5px">예비</span> '.($w3id !== '' ? ebs_h($w3name.' Lv.'.$w3lv.'/exp.'.($w3exp % max(1,(int)ebs_v('WEAPON_LVUP','100')))) : '').'<br>';
    echo '<span style="background:#606060;padding:2px 5px">보강장비</span> '.($armorName !== '' ? ebs_h($armorName) : '').'<br>';
    if ($armorName !== '') echo '<span style="background:#606060;padding:2px 5px">성능</span> '.ebs_h($armorSpec).' 내구:'.ebs_h($armorDur).'<br>';
    echo '<span style="background:#606060;padding:2px 5px">LASTBATTLE</span> '.ebs_h((string)($p['battle_log'] ?? '')).'</td>';
    echo '</tr></table>';
}

/**
 * 원본 legacy의 배경 변수는 색상값이면 bgcolor 속성, 파일명이면 background 속성으로 사용했다.
 * PHP 변환본에서는 body 태그에 그대로 색상값만 출력되면 흰 화면이 되므로 여기서 속성 문자열로 보정한다.
 */
function ebs_bg_attr(string $name): string {
    $v = ebs_v($name);
    if ($v === '') return '';
    if (str_contains($v, '=') || str_starts_with(trim($v), 'bgcolor') || str_starts_with(trim($v), 'background')) return $v;
    return str_contains($v, '.') ? 'background="'.ebs_h($v).'"' : 'bgcolor="'.ebs_h($v).'"';
}

/** 원본 EB 쿠키(pname:...,pass:...)를 PHP 배열로 해석한다. */
function ebs_cookie_value(string $key, string $default=''): string {
    $raw = $_COOKIE['EB'] ?? '';
    if (!is_string($raw) || $raw === '') return $default;
    $pairs = [];
    // PHP 변환판 표준: pname:NAME,pass:PASS
    foreach (explode(',', $raw) as $pair) {
        [$k, $v] = array_pad(explode(':', $pair, 2), 2, '');
        $k = trim($k); $v = trim($v);
        if ($k !== '') $pairs[$k] = $v;
    }
    // 일부 원본/이전 변환 쿠키는 &quot; 또는 따옴표가 섞인 깨진 문자열로 남는다.
    // 그런 값은 로그인 입력칸에 그대로 보이면 안 되므로 안전한 문자만 허용한다.
    $val = $pairs[$key] ?? $default;
    $val = html_entity_decode((string)$val, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    if ($val === '') return $default;
    $clean = ebs_clean_login_value($val);
    return $clean !== '' ? $clean : $default;
}

/**
 * EB 로그인 쿠키를 현재 설치 경로와 루트 경로에 동시에 쓴다.
 * 이전 변환본/서버 설정에서 /ebs, /ebs/ 같은 더 구체적인 path 쿠키가 남아 있으면
 * 브라우저가 그 쿠키를 우선 전송하여 신규 등록 후에도 이전 캐릭터로 로그인되는 문제가 생긴다.
 * 따라서 로그인/신규등록/복원/삭제 시 가능한 경로를 모두 같은 값으로 동기화한다.
 */
function ebs_cookie_path_candidates(): array {
    $paths = ['/'];
    $script = isset($_SERVER['SCRIPT_NAME']) && is_string($_SERVER['SCRIPT_NAME']) ? str_replace('\\', '/', $_SERVER['SCRIPT_NAME']) : '';
    $dir = trim(str_replace('\\', '/', dirname($script)), '/');
    if ($dir !== '' && $dir !== '.') {
        $paths[] = '/'.$dir;
        $paths[] = '/'.$dir.'/';
    }
    $phpSelf = isset($_SERVER['PHP_SELF']) && is_string($_SERVER['PHP_SELF']) ? str_replace('\\', '/', $_SERVER['PHP_SELF']) : '';
    $selfDir = trim(str_replace('\\', '/', dirname($phpSelf)), '/');
    if ($selfDir !== '' && $selfDir !== '.') {
        $paths[] = '/'.$selfDir;
        $paths[] = '/'.$selfDir.'/';
    }
    return array_values(array_unique($paths));
}
function ebs_set_cookie_all_paths(string $name, string $value, int $expires): void {
    if (headers_sent()) return;
    foreach (ebs_cookie_path_candidates() as $path) {
        setcookie($name, $value, $expires, $path);
    }
}
function ebs_set_login_cookie(string $pname, string $pass): void {
    $cookie = 'pname:'.$pname.',pass:'.$pass;
    $expires = time() + ((int)ebs_v('COOKIE_KEEP','1400')) * 86400;
    ebs_set_cookie_all_paths('EB', $cookie, $expires);
    $_COOKIE['EB'] = $cookie;
}
function ebs_clear_login_cookie(): void {
    ebs_set_cookie_all_paths('EB', '', time() - 3600);
    unset($_COOKIE['EB']);
}

/** 플레이어 이름 조회: 인코딩/대소문자 차이와 name 필드 기준을 같이 확인한다. */
function ebs_find_player_key(string $name, array $players): ?string {
    if ($name === '') return null;
    if (isset($players[$name]) && is_array($players[$name])) return $name;
    foreach ($players as $k => $p) {
        if (!is_array($p)) continue;
        if ((string)$k === $name || (string)($p['name'] ?? '') === $name) return (string)$k;
    }
    return null;
}

/** 로그인/POST에서 전달된 패스워드를 원본처럼 비어 있으면 통과, 저장값이 있으면 비교한다. */

function ebs_plv(array $player, int $idx, mixed $default=''): string {
    $raw = $player['raw_values'] ?? null;
    if (is_array($raw) && array_key_exists($idx, $raw)) return (string)$raw[$idx];
    $map = [0=>'rank',2=>'pass',3=>'msname',4=>'type',5=>'kuni',7=>'comment',8=>'money',9=>'weapon',10=>'weapon2',11=>'weapon3',12=>'chara',13=>'color',14=>'weapon_exp',15=>'hp',16=>'max_hp',17=>'en',18=>'max_en',19=>'attack',20=>'defense',21=>'speed',22=>'hit',24=>'skill',27=>'icon',29=>'level',30=>'level_exp',41=>'win',42=>'lose',43=>'contrib',72=>'goldbar',73=>'exp_free',75=>'total_free'];
    if (isset($map[$idx]) && array_key_exists($map[$idx], $player)) return (string)$player[$map[$idx]];
    return (string)$default;
}
function ebs_plv_int(array $player, int $idx, int $default=0): int {
    $v = ebs_plv($player, $idx, (string)$default);
    return is_numeric($v) ? (int)$v : $default;
}

function ebs_player_rank_value(array $player): float {
    $v = $player['rank'] ?? ebs_player_raw_get($player, 0, '0');
    return is_numeric($v) ? (float)$v : 0.0;
}
function ebs_player_level_value(array $player): int {
    $v = ebs_player_raw_get($player, 29, '');
    if ($v !== '' && is_numeric($v)) return max(1, (int)$v);
    return max(1, (int)($player['level'] ?? 1));
}

function ebs_password_matches(array $player, string $pass): bool {
    $stored = (string)($player['pass'] ?? '');
    if ($stored === '') return true;
    if ($pass === '') return false;
    if (hash_equals($stored, $pass)) return true;
    $crypt = crypt($pass, 'eb');
    return is_string($crypt) && hash_equals($stored, $crypt);
}

/** 로그인명 기준으로 개별 user/*.json 저장소에서 플레이어를 찾는다. */
function ebs_require_player(string $pname = '', string $pass = ''): array {
    ebs_bootstrap_players_from_backup();
    $pname = ebs_clean_login_value($pname !== '' ? $pname : ebs_param('pname', ebs_cookie_value('pname', '')));
    $pass = ebs_clean_login_value($pass !== '' ? $pass : ebs_param('pass', ebs_cookie_value('pass', '')));
    $players = ebs_players_load();
    $key = ebs_find_player_key($pname, $players);
    if ($key === null || !isset($players[$key]) || !is_array($players[$key])) return [null, null, $players, '등록 데이터를 찾을 수 없습니다.'];
    if (!ebs_password_matches($players[$key], $pass)) return [$key, null, $players, '패스워드가 틀립니다.'];
    return [$key, $players[$key], $players, ''];
}

/** 원본 file/텍스트 플레이어 저장소를 PHP JSON 저장 방식으로 대체한다. */
/**
 * 원본 legacy의 file 유저 저장소를 PHP 파일 저장 방식으로 대체한다.
 * - 한 파일(user/*.json)에 모든 캐릭터를 넣지 않는다.
 * - user/{safe-id}.json 파일 하나가 캐릭터 한 명의 저장 파일이다.
 * - 원본 file 값의 공백 필드 순서를 유지하기 위해 raw_values 배열을 함께 보존한다.
 * - 출력/조회용으로만 전체 유저를 메모리에 모아 원본 해시처럼 사용한다.
 */
function ebs_user_dir(): string { return ebs_file('user'); }
function ebs_user_safe_name(string $name): string {
    $name = trim($name);
    if ($name === '') return '';
    $safe = preg_replace('/[^0-9A-Za-z가-힣ぁ-んァ-ン一-龥_\-]/u', '_', $name);
    $safe = trim((string)$safe, '._- ');
    if ($safe === '') $safe = 'user_'.substr(hash('sha256', $name), 0, 16);
    return $safe;
}
function ebs_user_file(string $name): string { return ebs_user_dir().'/'.ebs_user_safe_name($name).'.json'; }

function ebs_repair_atomic_write(string $absPath, string $data): bool {
    $dir = dirname($absPath);
    if (!is_dir($dir) && !mkdir($dir, 0775, true) && !is_dir($dir)) return false;
    try { $suffix = bin2hex(random_bytes(4)); } catch (Throwable) { $suffix = str_replace('.', '', uniqid('', true)); }
    $tmp = $absPath.'.tmp.repair.'.getmypid().'.'.$suffix;
    if (file_put_contents($tmp, $data, LOCK_EX) === false) { @unlink($tmp); return false; }
    @chmod($tmp, 0664);
    if (!@rename($tmp, $absPath)) { @unlink($tmp); return false; }
    return true;
}
function ebs_repair_quarantine_file(string $file, string $reason): bool {
    if (!is_file($file)) return true;
    $dir = __DIR__.'/data/repair_quarantine';
    if (!is_dir($dir) && !mkdir($dir, 0775, true) && !is_dir($dir)) return false;
    $target = $dir.'/'.date('YmdHis').'_'.preg_replace('/[^0-9A-Za-z._#U가-힣ぁ-んァ-ン一-龥-]/u', '_', basename($file));
    $ok = @rename($file, $target);
    if ($ok) @file_put_contents($target.'.reason.txt', $reason, LOCK_EX);
    return $ok;
}
function ebs_repair_weapon_slot_value(string $value, bool $mainSlot): array {
    $original = $value;
    $value = html_entity_decode(trim($value), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    $value = str_replace(["\r", "\n", "\t"], '', $value);
    if ($value === '') return ['', $original !== ''];
    $parts = explode('!', $value, 2);
    $id = trim((string)$parts[0]);
    $exp = isset($parts[1]) ? trim((string)$parts[1]) : '0';
    if (!preg_match('/^[0-9A-Za-z_\-]+$/', $id) || !ebs_weapon_exists($id)) {
        if ($mainSlot) {
            $fixed = ebs_default_weapon_id().'!0';
            return [$fixed, $fixed !== $original];
        }
        return ['', $original !== ''];
    }
    if ($exp === '' || !preg_match('/^-?\d+$/', $exp)) $exp = '0';
    $exp = (string)max(0, (int)$exp);
    $fixed = $id.'!'.$exp;
    return [$fixed, $fixed !== $original];
}
function ebs_repair_player_record(array &$player): array {
    $changes = [];
    $name = (string)($player['name'] ?? '');
    $cleanName = ebs_clean_login_value($name);
    if ($cleanName === '') $cleanName = ebs_clean_registration_name($name);
    if ($cleanName !== '' && $cleanName !== $name) { $player['name'] = $cleanName; $changes[] = '이름 정규화'; }

    foreach (['weapon'=>true, 'weapon2'=>false, 'weapon3'=>false] as $field=>$mainSlot) {
        [$fixed, $changed] = ebs_repair_weapon_slot_value((string)($player[$field] ?? ''), $mainSlot);
        if ($changed) { $player[$field] = $fixed; $changes[] = $field.' 무기값 수리'; }
    }
    if (isset($player['warehouse_weapons'])) {
        if (!is_array($player['warehouse_weapons'])) { $player['warehouse_weapons'] = []; $changes[] = '창고 무기 배열 수리'; }
        else {
            $fixedList = [];
            foreach ($player['warehouse_weapons'] as $w) {
                [$fixed, ] = ebs_repair_weapon_slot_value((string)$w, false);
                if ($fixed !== '') $fixedList[] = $fixed;
            }
            if ($fixedList !== $player['warehouse_weapons']) { $player['warehouse_weapons'] = $fixedList; $changes[] = '창고 무기 오류값 제거'; }
        }
    }

    $level = max(1, (int)($player['level'] ?? ebs_player_raw_get($player, 29, '1')));
    if (!isset($player['level']) || (int)$player['level'] !== $level) { $player['level'] = $level; $changes[] = '레벨값 수리'; }
    foreach (['money','level_exp','custom','skill','win','lose','contrib'] as $field) {
        if (array_key_exists($field, $player)) {
            $fixed = max(0, (int)$player[$field]);
            if ((string)$player[$field] !== (string)$fixed) { $player[$field] = $fixed; $changes[] = $field.' 숫자값 수리'; }
        }
    }
    $maxHp = max(1, (int)($player['max_hp'] ?? ebs_player_raw_get($player, 16, '4000')));
    $maxEn = max(1, (int)($player['max_en'] ?? ebs_player_raw_get($player, 18, '200')));
    $hp = min($maxHp, max(0, (int)($player['hp'] ?? ebs_player_raw_get($player, 15, (string)$maxHp))));
    $en = min($maxEn, max(0, (int)($player['en'] ?? ebs_player_raw_get($player, 17, (string)$maxEn))));
    foreach (['max_hp'=>$maxHp, 'max_en'=>$maxEn, 'hp'=>$hp, 'en'=>$en] as $field=>$fixed) {
        if (!isset($player[$field]) || (int)$player[$field] !== $fixed) { $player[$field] = $fixed; $changes[] = $field.' 범위값 수리'; }
    }
    if (!isset($player['st']) || !is_array($player['st']) || count($player['st']) < 4) {
        $player['st'] = [
            max(0, (int)ebs_player_raw_get($player, 19, '6')),
            max(0, (int)ebs_player_raw_get($player, 20, '6')),
            max(0, (int)ebs_player_raw_get($player, 21, '6')),
            max(0, (int)ebs_player_raw_get($player, 22, '6')),
        ];
        $changes[] = '스탯 배열 수리';
    } else {
        $st = [];
        for ($i=0; $i<4; $i++) $st[$i] = max(0, (int)($player['st'][$i] ?? 6));
        if ($st !== array_values($player['st'])) { $player['st'] = $st; $changes[] = '스탯 숫자값 수리'; }
    }
    ebs_player_sync_common($player);
    return array_values(array_unique($changes));
}
function ebs_user_storage_repair(bool $apply=false, bool $runtime=false): array {
    static $runtimeDone = false;
    if ($runtime && $runtimeDone) return ['scanned'=>0,'players'=>0,'fixed'=>0,'duplicates'=>0,'renamed'=>0,'invalid_json'=>0,'invalid_name'=>0,'locks_removed'=>0,'quarantined'=>0,'messages'=>[]];
    if ($runtime) $runtimeDone = true;
    $summary = ['scanned'=>0,'players'=>0,'fixed'=>0,'duplicates'=>0,'renamed'=>0,'invalid_json'=>0,'invalid_name'=>0,'locks_removed'=>0,'quarantined'=>0,'messages'=>[]];
    $result = ebs_with_file_lock(ebs_file('user/.players_state'), LOCK_EX, static function () use ($apply, $summary): array {
        $summary = $summary;
        $dir = ebs_user_dir();
        if (!is_dir($dir)) return $summary;
        $groups = [];
        foreach (glob($dir.'/*.json') ?: [] as $file) {
            $summary['scanned']++;
            $base = pathinfo($file, PATHINFO_FILENAME);
            $raw = file_get_contents($file);
            $json = is_string($raw) ? ebs_json_decode_array($raw) : [];
            if (!$json) {
                $summary['invalid_json']++;
                if ($apply && ebs_repair_quarantine_file($file, 'invalid json')) $summary['quarantined']++;
                continue;
            }
            ebs_player_normalize_legacy_fields($json);
            $name = (string)($json['name'] ?? '');
            if ($name === '') $name = ebs_decode_backup_name($base);
            $cleanName = ebs_clean_login_value($name);
            if ($cleanName === '') $cleanName = ebs_clean_registration_name($name);
            if ($cleanName === '') {
                $summary['invalid_name']++;
                if ($apply && ebs_repair_quarantine_file($file, 'invalid player name')) $summary['quarantined']++;
                continue;
            }
            $changed = false;
            $changeList = [];
            if ((string)($json['name'] ?? '') !== $cleanName) { $json['name'] = $cleanName; $changed = true; $changeList[] = 'name'; }
            $recordChanges = ebs_repair_player_record($json);
            if ($recordChanges) { $changed = true; $changeList = array_merge($changeList, $recordChanges); }
            $canonicalSafe = ebs_user_safe_name($cleanName);
            $groups[$cleanName][] = [
                'file'=>$file,
                'base'=>$base,
                'safe'=>$canonicalSafe,
                'canonical'=>($base === $canonicalSafe),
                'mtime'=>(int)(@filemtime($file) ?: 0),
                'data'=>$json,
                'changed'=>$changed,
                'changes'=>$changeList,
            ];
        }
        foreach ($groups as $name=>$rows) {
            $summary['players']++;
            usort($rows, static function (array $a, array $b): int {
                if ($a['canonical'] !== $b['canonical']) return $a['canonical'] ? -1 : 1;
                return $b['mtime'] <=> $a['mtime'];
            });
            $chosen = $rows[0];
            $target = $dir.'/'.$chosen['safe'].'.json';
            $hasDuplicate = count($rows) > 1;
            if ($hasDuplicate) $summary['duplicates'] += count($rows) - 1;
            if (!$chosen['canonical']) $summary['renamed']++;
            if ($chosen['changed'] || !$chosen['canonical'] || $hasDuplicate || !is_file($target)) $summary['fixed']++;
            if ($apply) {
                if ($chosen['changed'] || !$chosen['canonical'] || !is_file($target)) {
                    $encoded = json_encode($chosen['data'], JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT);
                    if (is_string($encoded)) ebs_repair_atomic_write($target, $encoded);
                }
                foreach ($rows as $row) {
                    if ($row['file'] !== $target && is_file($row['file'])) @unlink($row['file']);
                    $oldLock = $row['file'].'.lock';
                    if (is_file($oldLock) && @unlink($oldLock)) $summary['locks_removed']++;
                }
            }
            if ($chosen['changed'] || !$chosen['canonical'] || $hasDuplicate) {
                $summary['messages'][] = $name.' : '.implode(', ', array_unique(array_merge($chosen['changes'], (!$chosen['canonical'] ? ['파일명 정규화'] : []), ($hasDuplicate ? ['중복 파일 제거'] : []))));
            }
        }
        if ($apply) {
            foreach (glob($dir.'/*.json.lock') ?: [] as $lock) { if (@unlink($lock)) $summary['locks_removed']++; }
            foreach (glob($dir.'/*.tmp.*') ?: [] as $tmp) { @unlink($tmp); }
            $legacyStateLock = $dir.'/.players_state.lock';
            if (is_file($legacyStateLock) && @unlink($legacyStateLock)) $summary['locks_removed']++;
            $summary['locks_removed'] += ebs_cleanup_lock_files(0);
        }
        return $summary;
    });
    if (is_array($result)) {
        if ($apply) { ebs_players_cache_clear(); ebs_players_base_hashes_set([]); }
        return $result;
    }
    return $summary;
}

/** 기존 배포본에서 old"new" 형태로 저장된 잘못된 신규등록 파일을 1회 복구한다. */
function ebs_repair_corrupted_registration_files(): void {
    static $done = false;
    if ($done) return;
    $done = true;
    $dir = ebs_user_dir();
    if (!is_dir($dir)) return;
    foreach (glob($dir.'/*.json') ?: [] as $file) {
        $safe = pathinfo($file, PATHINFO_FILENAME);
        $json = ebs_json_decode_array(ebs_read('user/'.$safe.'.json'));
        if (!$json) continue;
        $oldName = (string)($json['name'] ?? $safe);
        if ($oldName === '') continue;
        if (strpos($oldName, '"') === false && strpos($oldName, "'") === false && strpos($oldName, '&quot;') === false) continue;
        $fixed = ebs_clean_registration_name($oldName);
        if ($fixed === '' || $fixed === $oldName) continue;
        $target = ebs_user_file($fixed);
        if (is_file($target)) continue;
        $json['name'] = $fixed;
        if (isset($json['event_log']) && is_array($json['event_log'])) {
            foreach ($json['event_log'] as &$ev) {
                if (is_array($ev) && (string)($ev['type'] ?? '') === 'newentry') $ev['pname'] = $fixed;
            }
            unset($ev);
        }
        if (isset($json['raw_values']) && is_array($json['raw_values'])) {
            // 원본 raw에는 파일럿명이 별도 필드로 없으므로 기체명 등은 유지한다.
        }
        ebs_player_sync_common($json);
        $encoded = json_encode($json, JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT);
        if (is_string($encoded) && ebs_write('user/'.ebs_user_safe_name($fixed).'.json', $encoded)) {
            @unlink($file);
        }
    }
}
function ebs_player_load_one(string $name): array {
    $safe = ebs_user_safe_name($name);
    if ($safe === '') return [];
    $rel = 'user/'.$safe.'.json';
    if (!is_file(ebs_file($rel))) return [];
    $json = ebs_json_decode_array(ebs_read($rel));
    if (!$json) return [];
    ebs_player_normalize_legacy_fields($json);
    return $json;
}
function ebs_player_save_one(string $name, array $player): bool {
    $player['name'] = (string)($player['name'] ?? $name);
    $storageName = (string)$player['name'];
    $safe = ebs_user_safe_name($storageName);
    if ($safe === '') return false;
    $dir = ebs_user_dir();
    if (!is_dir($dir) && !mkdir($dir, 0775, true) && !is_dir($dir)) return false;
    ebs_player_sync_common($player);
    $json = json_encode($player, JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT);
    if (!is_string($json)) return false;
    $rel = 'user/'.$safe.'.json';
    if (!ebs_write($rel, $json)) return false;
    $check = ebs_json_decode_array(ebs_read($rel));
    $ok = $check && (string)($check['name'] ?? '') === $storageName;
    if ($ok && $storageName !== $name) {
        $oldFile = ebs_user_file($name);
        $newFile = ebs_user_file($storageName);
        if ($oldFile !== $newFile && is_file($oldFile)) @unlink($oldFile);
    }
    if ($ok && is_array(ebs_players_cache_get())) {
        $cache = ebs_players_cache_get();
        foreach ($cache as $ck => $cv) {
            if (is_array($cv) && ((string)$ck === (string)$name || (string)$ck === $storageName || (string)($cv['name'] ?? '') === $storageName)) unset($cache[$ck]);
        }
        $cache[$storageName] = $player;
        ksort($cache, SORT_NATURAL);
        ebs_players_cache_set($cache);
    }
    return $ok;
}
function ebs_player_delete_one(string $name): bool {
    $file = ebs_user_file($name);
    $ok = !is_file($file) || unlink($file);
    if ($ok && is_array(ebs_players_cache_get())) {
        $cache = ebs_players_cache_get();
        foreach ($cache as $ck => $cv) {
            if ((string)$ck === $name || (is_array($cv) && (string)($cv['name'] ?? '') === $name)) unset($cache[$ck]);
        }
        ebs_players_cache_set($cache);
    }
    return $ok;
}
function ebs_players_load(): array {
    $cached = ebs_players_cache_get();
    if (is_array($cached)) return $cached;
    ebs_bootstrap_players_from_backup();
    ebs_repair_corrupted_registration_files();
    ebs_user_storage_repair(true, true);
    $dir = ebs_user_dir();
    $players = [];
    $baseHashes = [];
    if (!is_dir($dir)) return $players;
    foreach (glob($dir.'/*.json') ?: [] as $file) {
        $safe = pathinfo($file, PATHINFO_FILENAME);
        $json = ebs_json_decode_array(ebs_read('user/'.$safe.'.json'));
        if (!$json) continue;
        ebs_player_normalize_legacy_fields($json);
        if (ebs_apply_player_recovery($json)) {
            $saveName = (string)($json['name'] ?? $safe);
            if ($saveName !== '') ebs_player_save_one($saveName, $json);
        }
        $name = (string)($json['name'] ?? $safe);
        if ($name !== '') {
            $players[$name] = $json;
            $baseHashes[$name] = ebs_player_storage_hash($json);
        }
    }
    ksort($players, SORT_NATURAL);
    ebs_players_cache_set($players);
    ebs_players_base_hashes_set($baseHashes);
    return $players;
}
function ebs_players_save(array $players): bool {
    // 여러 요청이 동시에 열린 상태에서 오래된 전체 players 배열을 다시 저장하면
    // 장비/창고/아이템 변경이 이전 값으로 되돌아갈 수 있다.
    // 최초 로드 시점의 해시와 비교해 실제 변경된 캐릭터 파일만 저장한다.
    $baseHashes = ebs_players_base_hashes_get();
    $result = ebs_with_file_lock(ebs_file('user/.players_state'), LOCK_EX, static function () use ($players, $baseHashes): bool {
        $ok = true;
        foreach ($players as $key => $player) {
            if (!is_array($player)) continue;
            $name = (string)($player['name'] ?? $key);
            if ($name === '') continue;
            $candidate = $player;
            ebs_player_sync_common($candidate);
            $newHash = ebs_player_storage_hash($candidate);
            $baseHash = $baseHashes[$key] ?? ($baseHashes[$name] ?? null);
            if ($baseHash !== null && hash_equals((string)$baseHash, $newHash)) continue;
            $saved = ebs_player_save_one($name, $candidate);
            if ($saved) ebs_players_base_hash_set($name, $candidate);
            $ok = $saved && $ok;
        }
        return $ok;
    });
    if ($result === true) ebs_players_cache_clear();
    return $result === true;
}

/** 관리자 백업 복원처럼 전체 DBM 키셋을 갈아끼우는 경우에만 사용한다.
 * 원본 dbmopen 해시의 전체 교체와 동일하게, 백업에 없는 user/*.json 잔존 파일을 제거한다.
 */
function ebs_players_replace_all(array $players): bool {
    $result = ebs_with_file_lock(ebs_file('user/.players_state'), LOCK_EX, static function () use ($players): bool {
        $dir = ebs_user_dir();
        if (!is_dir($dir) && !mkdir($dir, 0775, true) && !is_dir($dir)) return false;
        foreach (glob($dir.'/*.json') ?: [] as $file) {
            @unlink($file);
        }
        $ok = true;
        foreach ($players as $key => $player) {
            if (!is_array($player)) continue;
            $name = (string)($player['name'] ?? $key);
            if ($name === '') continue;
            $ok = ebs_player_save_one($name, $player) && $ok;
        }
        return $ok;
    });
    if ($result === true) {
        ksort($players, SORT_NATURAL);
        ebs_players_cache_set($players);
    }
    return $result === true;
}

function ebs_satellite_allowed(): bool { return ebs_v('SATELLITE_FLAG','0') === '1'; }
function ebs_satellite_guard(): bool {
    if (ebs_satellite_allowed()) return true;
    ebs_error_page('Data 이동 불가', '관리자 설정에서 데이터 이동 허가(SATELLITE_FLAG)가 0으로 되어 있어 DataImport/DataExport를 실행할 수 없습니다.');
    return false;
}
function ebs_player_exists(string $name): bool { $name = ebs_clean_registration_name($name); if ($name === '') return false; $p=ebs_players_load(); return ebs_find_player_key($name, $p) !== null; }
function ebs_add_player(array $form): bool {
    $name = ebs_clean_registration_name((string)($form['pname'] ?? ''));
    if ($name === '') return false;
    $players = ebs_players_load();
    if (ebs_find_player_key($name, $players) !== null) return false;
    $now = date('YmdHis');
    $plainPass = ebs_clean_registration_password((string)($form['pass'] ?? ''));
    if ($plainPass === '') return false;
    $cryptPass = crypt($plainPass, 'eb');
    $msname = trim((string)($form['msname'] ?? $name));
    $msname = str_replace(["\r", "\n", "\t", '"', "'", '<', '>'], '', $msname);
    if ($msname === '') $msname = $name;
    $type = (string)($form['type'] ?? '0');
    $kuni = (string)($form['kuni'] ?? '');
    $weapon = (string)($form['w'] ?? ebs_default_weapon_id());
    if (!ebs_weapon_exists($weapon)) $weapon = ebs_default_weapon_id();
    $chara = (string)($form['chara'] ?? '0');
    $color = (string)($form['cl'] ?? '#FFFFFF');
    $icon = (string)($form['msImg'] ?? ($form['imgSelect'] ?? '1'));
    // 원본 file 문자열의 인덱스 구조를 PHP에서도 보존한다.
    $raw = [
        '1', $now, $cryptPass, $msname, $type, $kuni, '0', 'noComment', '0', $weapon.'!0', '', '',
        $chara, $color, '0', '4000', '4000', '200', '200', '6', '6', '6', '6', '0', '0', '0', $now, $icon, '', '1', '0'
    ];
    $players[$name] = [
        'name' => $name,
        'level' => 1,
        'date' => $now,
        'pass' => $cryptPass,
        'msname' => $msname,
        'type' => $type,
        'kuni' => $kuni,
        'job' => '0',
        'comment' => 'noComment',
        'money' => 0,
        'weapon' => $weapon.'!0',
        'weapon2' => '',
        'weapon3' => '',
        'chara' => $chara,
        'color' => $color,
        'weapon_exp' => '0',
        'hp' => 4000,
        'max_hp' => 4000,
        'en' => 200,
        'max_en' => 200,
        'st' => [6,6,6,6],
        'custom' => 0,
        'skill' => 0,
        'repair' => '0',
        'last_access' => $now,
        'recovery_at' => $now,
        'icon' => $icon,
        'level_exp' => 0,
        'remote' => ($_SERVER['REMOTE_HOST'] ?? '').'!'.($_SERVER['REMOTE_ADDR'] ?? '').'!'.($_SERVER['REMOTE_USER'] ?? ''),
        'raw_values' => $raw,
        'raw_original_shape' => implode(' ', $raw),
        'event_log' => [['type'=>'newentry','pname'=>$name,'time'=>$now]],
    ];
    return ebs_player_save_one($name, $players[$name]);
}


/** 원본 backupdata를 PHP 로그인/상태 화면에서 참조할 수 있도록 user 폴더 개별 플레이어 JSON 기본값을 생성한다. */
function ebs_decode_backup_name(string $name): string {
    $base = preg_replace('/\.txt$/i', '', $name) ?? $name;
    return preg_replace_callback('/#U([0-9a-fA-F]{4})/', static function (array $m): string { return html_entity_decode('&#x'.$m[1].';', ENT_NOQUOTES, 'UTF-8'); }, $base) ?? $base;
}
function ebs_bootstrap_players_from_backup(): void {
    $userDir = ebs_user_dir();
    if (is_dir($userDir) && glob($userDir.'/*.json')) return;
    $backup = ebs_json_load('backupdata');
    if (!$backup) return;
    $players = [];
    foreach ($backup as $file => $raw) {
        $name = ebs_decode_backup_name((string)$file);
        $rawStr = is_scalar($raw) ? (string)$raw : '';
        $parts = preg_split('/\s/u', trim($rawStr));
        if (!is_array($parts)) $parts = []; // 원본 공백 분리 방식처럼 연속 공백의 빈 필드도 보존한다.
        $players[$name] = [
            'name' => $name,
            'rank' => isset($parts[0]) && is_numeric($parts[0]) ? (float)$parts[0] : 0,
            'level' => isset($parts[29]) && is_numeric($parts[29]) ? (int)$parts[29] : (isset($parts[0]) && is_numeric($parts[0]) ? (int)$parts[0] : 1),
            'battle_log' => (string)($parts[1] ?? ''),
            'pass' => (string)($parts[2] ?? ''),
            'msname' => (string)($parts[3] ?? $name),
            'type' => (string)($parts[4] ?? ''),
            'kuni' => (string)($parts[5] ?? ''),
            'job' => (string)($parts[6] ?? ''),
            'comment' => (string)($parts[7] ?? 'noComment'),
            'money' => isset($parts[8]) && is_numeric($parts[8]) ? (int)$parts[8] : 0,
            'weapon' => (string)($parts[9] ?? ''),
            'weapon2' => (string)($parts[10] ?? ''),
            'weapon3' => (string)($parts[11] ?? ''),
            'chara' => (string)($parts[12] ?? ''),
            'color' => (string)($parts[13] ?? '#ffffff'),
            'weapon_exp' => (string)($parts[14] ?? '0'),
            'hp' => isset($parts[15]) && is_numeric($parts[15]) ? (int)$parts[15] : 4000,
            'max_hp' => isset($parts[16]) && is_numeric($parts[16]) ? (int)$parts[16] : 4000,
            'en' => isset($parts[17]) && is_numeric($parts[17]) ? (int)$parts[17] : 200,
            'max_en' => isset($parts[18]) && is_numeric($parts[18]) ? (int)$parts[18] : 200,
            'st' => [
                isset($parts[19]) && is_numeric($parts[19]) ? (int)$parts[19] : 6,
                isset($parts[20]) && is_numeric($parts[20]) ? (int)$parts[20] : 6,
                isset($parts[21]) && is_numeric($parts[21]) ? (int)$parts[21] : 6,
                isset($parts[22]) && is_numeric($parts[22]) ? (int)$parts[22] : 6,
            ],
            'custom' => isset($parts[23]) && is_numeric($parts[23]) ? (int)$parts[23] : 0,
            'skill' => isset($parts[24]) && is_numeric($parts[24]) ? (int)$parts[24] : 0,
            'repair' => (string)($parts[25] ?? '0'),
            'last_access' => (string)($parts[26] ?? ''),
            'recovery_at' => (string)($parts[26] ?? ($parts[1] ?? '')),
            'icon' => (string)($parts[27] ?? '1'),
            'level_exp' => isset($parts[30]) && is_numeric($parts[30]) ? (int)$parts[30] : 0,
            'raw_values' => array_values($parts),
            'raw_original_shape' => $rawStr,
        ];
    }
    ebs_players_save($players);
}


/** 원본 raw_values 인덱스와 PHP 필드 값을 함께 갱신한다. */
function ebs_player_raw_get(array $player, int $idx, string $default = ''): string {
    if (isset($player['raw_values']) && is_array($player['raw_values']) && array_key_exists($idx, $player['raw_values'])) {
        return (string)$player['raw_values'][$idx];
    }
    return $default;
}
function ebs_player_raw_set(array &$player, int $idx, string $value): void {
    if (!isset($player['raw_values']) || !is_array($player['raw_values'])) $player['raw_values'] = [];
    while (count($player['raw_values']) <= $idx) $player['raw_values'][] = '';
    $player['raw_values'][$idx] = $value;
    $player['raw_original_shape'] = implode(' ', array_map('strval', $player['raw_values']));
}
function ebs_player_normalize_legacy_fields(array &$player): void {
    $rawRank = ebs_player_raw_get($player, 0, '');
    $rawLevel = ebs_player_raw_get($player, 29, '');
    if ($rawRank !== '' && is_numeric($rawRank)) $player['rank'] = (float)$rawRank;
    if ($rawLevel !== '' && is_numeric($rawLevel)) $player['level'] = max(1, (int)$rawLevel);
    // 잘못된 진급 처리로 [0] 계급 자리에 백작/후작/공작 같은 작위명이 들어간 유저는
    // [6] 직위/작위값으로 복구하고 전투 계급은 숫자값만 유지한다.
    if ($rawRank !== '' && !is_numeric($rawRank)) {
        $classIdx = ebs_player_class_index_from_value($rawRank);
        if ($classIdx > 0 && (ebs_player_raw_get($player, 6, '') === '' || ebs_player_raw_get($player, 6, '0') === '0')) {
            $player['job'] = (string)($classIdx * 10);
            ebs_player_raw_set($player, 6, (string)($classIdx * 10));
        }
        if (!isset($player['rank']) || !is_numeric($player['rank'])) $player['rank'] = 0.0;
        ebs_player_raw_set($player, 0, (string)$player['rank']);
    }
    if (!isset($player['contrib']) && isset($player['contribution'])) $player['contrib'] = $player['contribution'];

    // 원본 DBM 배열의 주요 인덱스가 raw_values에만 남아 있는 경우에도
    // PHP 필드와 동기화한다. 특수/국가/부대 조건식은 이 값에 의존한다.
    $rawToField = [
        2=>'pass', 3=>'msname', 4=>'type', 5=>'kuni', 6=>'job', 7=>'comment',
        8=>'money', 9=>'weapon', 10=>'weapon2', 11=>'weapon3', 12=>'chara',
        13=>'color', 14=>'weapon_exp', 15=>'hp', 16=>'max_hp', 17=>'en',
        18=>'max_en', 23=>'custom', 24=>'skill', 25=>'repair', 26=>'last_access',
        27=>'icon', 28=>'unit', 30=>'level_exp', 32=>'armor', 41=>'win',
        42=>'lose', 43=>'contrib'
    ];
    foreach ($rawToField as $idx => $field) {
        $raw = ebs_player_raw_get($player, $idx, '');
        if ($raw === '') continue;
        if (!array_key_exists($field, $player) || $player[$field] === '' || $player[$field] === null) {
            if (in_array($field, ['money','hp','max_hp','en','max_en','custom','skill','level_exp','win','lose','contrib'], true) && is_numeric($raw)) {
                $player[$field] = (int)$raw;
            } else {
                $player[$field] = $raw;
            }
        }
    }
    if (!isset($player['st']) || !is_array($player['st'])) {
        $player['st'] = [
            (int)ebs_player_raw_get($player, 19, '6'),
            (int)ebs_player_raw_get($player, 20, '6'),
            (int)ebs_player_raw_get($player, 21, '6'),
            (int)ebs_player_raw_get($player, 22, '6'),
        ];
    }
}

/** 관리자 raw_values 직접 수정값을 PHP 필드에 강제로 반영한다.
 * 일반 로딩에서는 기존 PHP 필드를 보존하지만, 관리자 수정 저장에서는 raw 인덱스가 원본이므로
 * [8] 돈, [43] 공헌도 같은 값이 기존 필드에 덮여 되돌아가지 않도록 별도로 적용한다.
 */
function ebs_player_apply_admin_raw_values(array &$player): void {
    $map = [
        0=>'rank', 2=>'pass', 3=>'msname', 4=>'type', 5=>'kuni', 6=>'job', 7=>'comment',
        8=>'money', 9=>'weapon', 10=>'weapon2', 11=>'weapon3', 12=>'chara', 13=>'color',
        14=>'weapon_exp', 15=>'hp', 16=>'max_hp', 17=>'en', 18=>'max_en', 23=>'custom',
        24=>'skill', 25=>'repair', 26=>'last_access', 27=>'icon', 28=>'unit', 29=>'level',
        30=>'level_exp', 32=>'armor', 41=>'win', 42=>'lose', 43=>'contrib', 72=>'goldbar',
        73=>'exp_free', 75=>'total_free'
    ];
    foreach ($map as $idx=>$field) {
        if (!isset($player['raw_values']) || !is_array($player['raw_values']) || !array_key_exists($idx, $player['raw_values'])) continue;
        $raw = (string)$player['raw_values'][$idx];
        if ($field === 'rank') {
            $player[$field] = is_numeric($raw) ? (float)$raw : 0;
        } elseif ($field === 'level') {
            $player[$field] = is_numeric($raw) ? max(1, (int)$raw) : 1;
        } elseif (in_array($field, ['money','hp','max_hp','en','max_en','custom','skill','level_exp','win','lose','contrib','goldbar','exp_free','total_free'], true)) {
            $player[$field] = is_numeric($raw) ? (int)$raw : 0;
        } else {
            $player[$field] = $raw;
        }
    }
    $player['contribution'] = isset($player['contrib']) ? $player['contrib'] : ($player['contribution'] ?? 0);
    $player['st'] = [
        (int)ebs_player_raw_get($player, 19, '6'),
        (int)ebs_player_raw_get($player, 20, '6'),
        (int)ebs_player_raw_get($player, 21, '6'),
        (int)ebs_player_raw_get($player, 22, '6'),
    ];
    if (isset($player['job']) && !is_numeric($player['job'])) $player['job'] = (string)(ebs_player_class_index_from_value((string)$player['job']) * 10);
}

function ebs_player_sync_common(array &$player): void {
    // 원본 player 배열은 [0]=계급/랭크, [29]=레벨이다. 둘을 분리해서 저장한다.
    $rawRank = ebs_player_raw_get($player, 0, '0');
    $rawLevel = ebs_player_raw_get($player, 29, '1');
    if (!array_key_exists('rank', $player)) $player['rank'] = is_numeric($rawRank) ? (float)$rawRank : 0;
    if (!array_key_exists('level', $player)) $player['level'] = is_numeric($rawLevel) ? max(1, (int)$rawLevel) : 1;
    $map = [0=>'rank',2=>'pass',3=>'msname',4=>'type',5=>'kuni',6=>'job',7=>'comment',8=>'money',9=>'weapon',10=>'weapon2',11=>'weapon3',12=>'chara',13=>'color',15=>'hp',16=>'max_hp',17=>'en',18=>'max_en',23=>'custom',24=>'skill',25=>'repair',26=>'last_access',27=>'icon',29=>'level',30=>'level_exp',32=>'armor',41=>'win',42=>'lose',43=>'contrib'];
    if (isset($player['exp']) && !isset($player['level_exp'])) $player['level_exp'] = $player['exp'];
    if (isset($player['contribution']) && !isset($player['contrib'])) $player['contrib'] = $player['contribution'];
    if (isset($player['contrib'])) $player['contribution'] = $player['contrib'];
    if (isset($player['job']) && !is_numeric($player['job'])) $player['job'] = (string)(ebs_player_class_index_from_value($player['job']) * 10);
    if (isset($player['rank']) && !is_numeric($player['rank'])) {
        $classIdx = ebs_player_class_index_from_value($player['rank']);
        if ($classIdx > 0 && (empty($player['job']) || (string)$player['job'] === '0')) $player['job'] = (string)($classIdx * 10);
        $player['rank'] = 0;
    }
    foreach ($map as $idx=>$key) {
        if (array_key_exists($key, $player)) ebs_player_raw_set($player, $idx, (string)$player[$key]);
    }
    if (isset($player['st']) && is_array($player['st'])) {
        foreach ([19,20,21,22] as $i=>$idx) ebs_player_raw_set($player, $idx, (string)($player['st'][$i] ?? '6'));
    }
}

/** 원본 REPAIR: 마지막 전투/회복 기준 시각부터 HP/EN을 서버 저장값으로 회복한다. */
function ebs_parse_legacy_time_value(string $raw): int {
    $raw = trim($raw);
    if ($raw === '') return 0;
    if (strpos($raw, '!') !== false) $raw = (string)explode('!', $raw, 2)[0];
    $raw = trim($raw);
    if ($raw === '') return 0;
    if (preg_match('/^\d{14}$/', $raw)) {
        $ts = strtotime(substr($raw,0,4).'-'.substr($raw,4,2).'-'.substr($raw,6,2).' '.substr($raw,8,2).':'.substr($raw,10,2).':'.substr($raw,12,2));
        return $ts === false ? 0 : (int)$ts;
    }
    if (preg_match('/^\d{10}$/', $raw)) return (int)$raw;
    $ts = strtotime($raw);
    return $ts === false ? 0 : (int)$ts;
}
function ebs_player_recovery_base_time(array $player): int {
    foreach (['recovery_at','battle_recovery_at'] as $key) {
        if (isset($player[$key]) && is_scalar($player[$key])) {
            $ts = ebs_parse_legacy_time_value((string)$player[$key]);
            if ($ts > 0) return $ts;
        }
    }
    $rawBattle = ebs_player_raw_get($player, 1, '');
    foreach ([$rawBattle, (string)($player['battle_log'] ?? ''), (string)($player['last_access'] ?? ''), (string)($player['date'] ?? '')] as $raw) {
        $ts = ebs_parse_legacy_time_value($raw);
        if ($ts > 0) return $ts;
    }
    return 0;
}
function ebs_apply_player_recovery(array &$player, int $now = 0): bool {
    if ($now <= 0) $now = time();
    $base = ebs_player_recovery_base_time($player);
    if ($base <= 0 || $base > $now) {
        if (!isset($player['recovery_at'])) {
            $player['recovery_at'] = (string)$now;
            ebs_player_sync_common($player);
            return true;
        }
        return false;
    }
    $elapsed = $now - $base;
    $hp = max(0, (int)($player['hp'] ?? ebs_player_raw_get($player, 15, '0')));
    $maxHp = max(1, (int)($player['max_hp'] ?? ebs_player_raw_get($player, 16, '4000')));
    $en = max(0, (int)($player['en'] ?? ebs_player_raw_get($player, 17, '0')));
    $maxEn = max(1, (int)($player['max_en'] ?? ebs_player_raw_get($player, 18, '200')));
    $repair = (string)($player['repair'] ?? ebs_player_raw_get($player, 25, '0'));
    $needsBaseline = !isset($player['recovery_at']);
    if ($elapsed <= 0 && !$needsBaseline) return false;

    $changed = false;
    if ($elapsed > 0 && $hp < $maxHp) {
        $hpRate = (float)ebs_v('HP_REPAIR', '30') + ($maxHp * (float)ebs_v('HP_REPAIR2', '0.5') * 0.01);
        $hpGain = (int)floor($elapsed * max(0.0, $hpRate));
        if ($hpGain > 0) {
            $hp = min($maxHp, $hp + $hpGain);
            $player['hp'] = $hp;
            ebs_player_raw_set($player, 15, (string)$hp);
            $changed = true;
        }
    }
    if ($elapsed > 0 && $en < $maxEn) {
        $enRate = (float)ebs_v('EN_REPAIR', '1') + ($maxEn * (float)ebs_v('EN_REPAIR2', '0.5') * 0.01);
        $enGain = (int)floor($elapsed * max(0.0, $enRate));
        if ($enGain > 0) {
            $en = min($maxEn, $en + $enGain);
            $player['en'] = $en;
            ebs_player_raw_set($player, 17, (string)$en);
            $changed = true;
        }
    }
    if ($hp >= $maxHp && $repair === '1') {
        $player['repair'] = '0';
        ebs_player_raw_set($player, 25, '0');
        $changed = true;
    }
    if ($changed || $needsBaseline || ($hp < $maxHp) || ($en < $maxEn) || (string)($player['repair'] ?? '0') === '1') {
        $player['recovery_at'] = (string)$now;
        ebs_player_sync_common($player);
        return true;
    }
    return false;
}

function ebs_current_player_ref(): array {
    [$key, $me, $players, $err] = ebs_require_player();
    return [$key, $me, $players, $err];
}
function ebs_mutate_current_player(callable $fn): array {
    [$key, $me, $players, $err] = ebs_require_player();
    if ($err !== '' || $key === null || !is_array($me)) return [false, null, $err ?: '등록 데이터를 찾을 수 없습니다.'];
    $fn($me, $players, $key);
    ebs_player_sync_common($me);
    $players[$key] = $me;
    ebs_players_save($players);
    return [true, $me, ''];
}
function ebs_render_sub_result(string $title, string $message, string $target='Sub'): void {
    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>ENDLESS BATTLE</title></head><body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="margin:0;font-size:13px;">';
    echo '<center><table border="1" cellspacing="0" cellpadding="6" bordercolor="'.ebs_h(ebs_v('TABLE_BORDER')).'" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'">';
    echo '<tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'" align="center"><b>'.ebs_h($title).'</b></td></tr><tr><td align="center">'.$message.'</td></tr></table></center></body></html>';
}
function ebs_calc_weapon_label(string $raw): array {
    [$id,$exp] = array_pad(explode('!', $raw, 2), 2, '0');
    $table = ebs_weapon_table();
    $row = $table[$id] ?? [];
    $name = (string)($row[0] ?? ($id !== '' ? $id : '없음'));
    $lv = intdiv(max(0,(int)$exp), max(1,(int)ebs_v('WEAPON_LVUP','100')));
    return [$id, $name, $lv, (int)$exp, $row];
}
function ebs_bougu_table(): array {
    $data = ebs_json_load('bougu');
    if ($data) return is_array($data) ? $data : [];
    $raw = ebs_read('log/_bougu.data');
    if ($raw === '') return [];
    if (function_exists('mb_check_encoding') && function_exists('mb_convert_encoding') && !mb_check_encoding($raw, 'UTF-8')) {
        $raw = mb_convert_encoding($raw, 'UTF-8', 'CP949,EUC-KR,Shift_JIS,EUC-JP');
    } elseif (function_exists('iconv') && !preg_match('//u', $raw)) {
        $converted = @iconv('CP949', 'UTF-8//IGNORE', $raw);
        if (is_string($converted) && $converted !== '') $raw = $converted;
    }
    $data = [];
    if (preg_match_all('/^\s*"([^"]+)"\s*=>\s*"([^"]*)"/m', $raw, $m, PREG_SET_ORDER)) {
        foreach ($m as $row) {
            $data[$row[1]] = str_getcsv($row[2], ',', '"', '\\');
        }
    }
    // 원본 _bougu.data 기재 순서를 그대로 유지한다.
    return $data;
}
function ebs_country_save_records(array $records): bool { return ebs_json_save('countrydata', $records); }

function ebs_current_player(): array {
    ebs_bootstrap_players_from_backup();
    $name = ebs_clean_login_value(ebs_param('pname', ebs_cookie_value('pname', '')));
    $players = ebs_players_load();
    $key = ebs_find_player_key($name, $players);
    if ($key !== null && isset($players[$key]) && is_array($players[$key])) return $players[$key];
    if ($name !== '') return [];
    return [];
}
function ebs_player_time_value(array $p): int {
    // 최근 접속자 표시는 전투/관리 저장 시각과 분리한다.
    // 기존 last_access/raw[26]은 전투 결과 저장, 회복 기준, 관리 조회에 같이 쓰여
    // 상대를 공격하기만 해도 접속자로 표시되는 문제가 있었다.
    $raw = (string)($p['online_seen'] ?? '');
    $raw = trim($raw);
    if ($raw === '') return 0;
    if (preg_match('/^\d{14}$/', $raw)) {
        $ts = strtotime(substr($raw,0,4).'-'.substr($raw,4,2).'-'.substr($raw,6,2).' '.substr($raw,8,2).':'.substr($raw,10,2).':'.substr($raw,12,2));
        return $ts === false ? 0 : (int)$ts;
    }
    if (preg_match('/^\d{10}$/', $raw)) return (int)$raw;
    $ts = strtotime($raw);
    return $ts === false ? 0 : (int)$ts;
}

function ebs_online_players(array $players = null, int $seconds = 900): array {
    if ($players === null) $players = ebs_players_load();
    $now = time();
    $rows = [];
    foreach ($players as $key=>$p) {
        if (!is_array($p)) continue;
        $ts = ebs_player_time_value($p);
        if ($ts <= 0 || $ts <= $now - $seconds) continue;
        $name = (string)($p['name'] ?? $key);
        if ($name === '') continue;
        $rows[] = [
            'name' => $name,
            'msname' => (string)($p['msname'] ?? ''),
            'country' => (string)($p['kuni'] ?? ebs_v('NONE_NATIONALITY')),
            'time' => $ts,
        ];
    }
    usort($rows, static function(array $a, array $b): int { return ((int)$b['time']) <=> ((int)$a['time']); });
    return $rows;
}

function ebs_online_names_text(array $players = null, int $seconds = 900): string {
    $rows = ebs_online_players($players, $seconds);
    if (!$rows) return '현재 접속자 없음';
    $names = [];
    foreach ($rows as $row) {
        $name = (string)$row['name'];
        $ms = (string)($row['msname'] ?? '');
        $names[] = $ms !== '' && $ms !== $name ? $name.'('.$ms.')' : $name;
    }
    return implode(' 　‡　 ', $names);
}

function ebs_touch_player_activity(array &$p): void {
    $now = time();
    // 화면을 실제로 열고 있는 본인만 접속자로 집계하기 위한 별도 시각.
    // last_access/raw[26]은 원본 호환 저장값이므로 온라인 판정에 사용하지 않는다.
    $p['online_seen'] = (string)$now;
    $p['last_action_time'] = date('Y-m-d H:i:s', $now);
    if (isset($_SERVER['REMOTE_ADDR']) || isset($_SERVER['REMOTE_HOST']) || isset($_SERVER['REMOTE_USER'])) {
        $p['remote'] = (string)($_SERVER['REMOTE_HOST'] ?? '').'!'.(string)($_SERVER['REMOTE_ADDR'] ?? '').'!'.(string)($_SERVER['REMOTE_USER'] ?? '');
    }
}

function ebs_touch_current_cookie_player_online(): bool {
    // 상단 Menu(g.php)는 Main 프레임보다 먼저 로드될 수 있다.
    // 그래서 로그인 완료 후에도 상단이 기존 집계값(현재 접속자 없음)을 계속 보이는 문제가 있었다.
    // Menu 프레임이 직접 EB 쿠키를 검증하고 현재 사용자만 online_seen을 갱신한다.
    ebs_bootstrap_players_from_backup();
    $pname = ebs_clean_login_value(ebs_cookie_value('pname', ''));
    $pass  = ebs_clean_login_value(ebs_cookie_value('pass', ''));
    if ($pname === '' || $pass === '') return false;
    $players = ebs_players_load();
    $key = ebs_find_player_key($pname, $players);
    if ($key === null || !isset($players[$key]) || !is_array($players[$key])) return false;
    $p = $players[$key];
    if (!ebs_password_matches($p, $pass)) return false;
    ebs_apply_player_recovery($p);
    ebs_apply_levelup($p);
    ebs_touch_player_activity($p);
    ebs_player_sync_common($p);
    $saveName = (string)($p['name'] ?? $key);
    if ($saveName === '') return false;
    return ebs_player_save_one($saveName, $p);
}

function ebs_bootstrap_runtime_counts(): void {
    ebs_bootstrap_players_from_backup();
    $players = ebs_players_load();
    $playerCount = count($players);
    $GLOBALS['EBS_VARS']['ENTRYS'] = (string)$playerCount;
    $GLOBALS['EBS_VARS']['total'] = (string)$playerCount;
    $GLOBALS['EBS_VARS']['sanka'] = (string)$playerCount;
    $countries = ebs_json_load('countrydata');
    $countryCount = is_array($countries) ? count($countries) : 0;
    $GLOBALS['EBS_VARS']['totalC'] = (string)$countryCount;
    $GLOBALS['EBS_VARS']['sankaC'] = (string)$countryCount;
    $GLOBALS['EBS_VARS']['ONLINE_COUNT'] = (string)count(ebs_online_players($players, 900));
    $GLOBALS['EBS_VARS']['ONLINE_NAMES'] = ebs_online_names_text($players, 900);
    $p = ebs_current_player();
    if ($p) {
        $GLOBALS['EBS_VARS']['CURRENT_PNAME'] = (string)($p['name'] ?? '');
        $GLOBALS['EBS_VARS']['CURRENT_MSNAME'] = (string)($p['msname'] ?? ($p['name'] ?? ''));
        $GLOBALS['EBS_VARS']['CURRENT_ICON'] = (string)($p['icon'] ?? '1');
        $GLOBALS['EBS_VARS']['CURRENT_LEVEL'] = (string)($p['level'] ?? '1');
    }
}

/** 파일명 안의 #Uxxxx 표기와 원본 CP949 데이터명을 PHP 출력용 UTF-8 이름으로 복원한다. */
function ebs_decode_data_name(string $name): string {
    $base = preg_replace('/\.txt$/i', '', $name) ?? $name;
    $base = preg_replace_callback('/#U([0-9a-fA-F]{4})/', static function (array $m): string { return html_entity_decode('&#x'.$m[1].';', ENT_NOQUOTES, 'UTF-8'); }, $base) ?? $base;
    return $base;
}

function ebs_utf8_codepoint(string $char): int {
    $bytes = array_values(unpack('C*', $char));
    $b0 = $bytes[0] ?? 0;
    if ($b0 < 0x80) return $b0;
    if (($b0 & 0xE0) === 0xC0) return (($b0 & 0x1F) << 6) | (($bytes[1] ?? 0) & 0x3F);
    if (($b0 & 0xF0) === 0xE0) return (($b0 & 0x0F) << 12) | ((($bytes[1] ?? 0) & 0x3F) << 6) | (($bytes[2] ?? 0) & 0x3F);
    if (($b0 & 0xF8) === 0xF0) return (($b0 & 0x07) << 18) | ((($bytes[1] ?? 0) & 0x3F) << 12) | ((($bytes[2] ?? 0) & 0x3F) << 6) | (($bytes[3] ?? 0) & 0x3F);
    return 0;
}
function ebs_encode_data_name(string $name): string {
    $name = trim($name);
    if ($name === '') return '';
    $chars = preg_split('//u', $name, -1, PREG_SPLIT_NO_EMPTY);
    if (!is_array($chars)) $chars = str_split($name);
    $out = '';
    foreach ($chars as $ch) {
        if (preg_match('/^[A-Za-z0-9_.-]$/', $ch)) $out .= $ch;
        else $out .= sprintf('#U%04x', ebs_utf8_codepoint($ch));
    }
    return $out . '.txt';
}

/** 원본 country DBM 행은 split(/\s/) 기준의 빈 필드를 포함한다.
 *  0 색상, 1 국비, 2~4 부대명, 5 작전명, 6 주공, 7 작전종료,
 *  8~10 부대별 목표, 11 요새 HP, 12 요새 능력, 13 문장, 14 최대국민수.
 */
function ebs_country_raw_parts(string $value): array {
    $parts = preg_split('/\s/u', trim($value));
    if (!is_array($parts)) $parts = [];
    while (count($parts) < 15) $parts[] = '';
    return array_values($parts);
}
function ebs_country_raw_string(array $parts): string {
    while (count($parts) < 15) $parts[] = '';
    return rtrim(implode(' ', array_map('strval', $parts)));
}
function ebs_country_find_raw_key(string $country, array $raw): ?string {
    foreach ($raw as $file=>$value) {
        if (ebs_decode_data_name((string)$file) === $country) return (string)$file;
    }
    return null;
}

/** countrydata 원본 file 대체 배열을 색상/국비/국명 중심으로 해석한다. */
function ebs_country_records(): array {
    $raw = ebs_json_load('countrydata');
    $rows = [];
    foreach ($raw as $file => $value) {
        $name = ebs_decode_data_name((string)$file);
        if ($name === '') continue;
        $value = is_scalar($value) ? trim((string)$value) : '';
        $parts = ebs_country_raw_parts($value);
        $color = $parts[0] ?? '#808080';
        if (!preg_match('/^#[0-9a-fA-F]{3,6}$/', $color)) $color = '#808080';
        $fortress = (string)($parts[11] ?? '');
        $stats = (string)($parts[12] ?? '');
        $icon = preg_match('/^\d{1,6}$/', (string)($parts[13] ?? '')) ? (string)$parts[13] : '1000';
        $maxMember = preg_match('/^\d{1,4}$/', (string)($parts[14] ?? '')) ? (string)$parts[14] : ebs_v('C_MAX_MEMBER','40');
        $rows[$name] = [
            'name' => $name,
            'color' => $color,
            'money' => $parts[1] ?? '0',
            'units' => array_values(array_filter([(string)($parts[2] ?? ''), (string)($parts[3] ?? ''), (string)($parts[4] ?? '')], static fn(string $v): bool => $v !== '')),
            'mission_name' => (string)($parts[5] ?? ''),
            'mission_main' => (string)($parts[6] ?? ''),
            'mission_end' => (string)($parts[7] ?? ''),
            'mission_units' => [(string)($parts[8] ?? ''), (string)($parts[9] ?? ''), (string)($parts[10] ?? '')],
            'raw' => $value,
            'fortress' => $fortress,
            'stats' => $stats,
            'max_member' => $maxMember,
            'icon' => $icon,
        ];
    }
    ksort($rows, SORT_NATURAL | SORT_FLAG_CASE);
    return $rows;
}

/** 원본 C_LIST 계열: 국가 선택 버튼 목록 출력. */
function ebs_render_country_buttons(string $target='Sub'): void {
    echo '<form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST" target="'.ebs_h($target).'" onSubmit="">' . "\n";
    echo '<input type="hidden" name="cmd" value="CO_LIST">' . "\n";
    echo '<b style="font-size:13px;">어느 국가의 정보를 보시겠습니까?</b><br>' . "\n";
    foreach (ebs_country_records() as $c) {
        echo '<input type="submit" name="CNTRY" value="'.ebs_h($c['name']).'" style="'.ebs_h(ebs_country_button_style((string)$c['color'])).'">' . "\n";
    }
    echo '<input type="submit" name="CNTRY" value="'.ebs_h(ebs_v('NONE_NATIONALITY')).'" style="'.ebs_h(ebs_country_button_style('#606060')).'"></form>' . "\n";
}

/** 원본 CNTRY_LIST의 기본 국가 정보 표. */
function ebs_render_country_detail(): void {
    $selected = ebs_param('CNTRY', ebs_v('NONE_NATIONALITY'));
    $countries = ebs_country_records();
    $c = $countries[$selected] ?? ['name'=>$selected, 'color'=>'#808080', 'money'=>'0', 'max_member'=>ebs_v('C_MAX_MEMBER','40'), 'icon'=>'1000'];
    echo '<table border="8" cellspacing="0" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" style="font-size:15px;background:'.ebs_h(ebs_v('TABLE_COLOR1')).';color:'.ebs_h(ebs_v('FONT_COLOR')).';border:8px outset '.ebs_h($c['color']).';">';
    $countryTextColor = ebs_contrast_text_color((string)$c['color']);
    $countryIcon = ebs_country_icon((string)$c['icon']);
    echo '<tr><td colspan="10" bgcolor="'.ebs_h($c['color']).'" style="color:'.ebs_h($countryTextColor).';font-size:30px;">';
    echo '<img src="'.ebs_h(ebs_v('IMG_FOLDER2')).'/'.ebs_h($countryIcon).'.gif" width="40" height="40">&nbsp;&nbsp;'.ebs_h((string)$c['name']);
    echo '<span style="font-size:15px;">&nbsp;&nbsp;&nbsp;국비&nbsp;<b>$'.ebs_h((string)$c['money']).'</b>&nbsp;&nbsp;최대국민수&nbsp;<b>'.ebs_h((string)$c['max_member']).'</b></span></td></tr>';
    echo '<tr bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'"><td>Name</td><td>Rank</td><td>&nbsp;</td><td>공격</td><td>방어</td><td>속도</td><td>명중</td><td>숙련도</td><td>Weapon</td><td>참전상황</td></tr>';
    $players = ebs_players_load();
    $printed = 0;
    foreach ($players as $name => $p) {
        if (!is_array($p)) continue;
        $pkuni = (string)($p['kuni'] ?? '');
        if ($selected !== ebs_v('NONE_NATIONALITY') && $pkuni !== $selected) continue;
        if ($selected === ebs_v('NONE_NATIONALITY') && $pkuni !== '') continue;
        $printed++;
        echo '<tr bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'"><td nowrap style="color:'.ebs_h(ebs_visible_player_color((string)($p['color'] ?? '#ededed'), ebs_v('TABLE_COLOR1'))).';">'.ebs_h((string)($p['name'] ?? $name)).'</td>';
        echo '<td>'.ebs_h((string)($p['level'] ?? '1')).'</td><td><img src="'.ebs_h(ebs_v('IMG_FOLDER2')).'/'.ebs_h(ebs_normalize_icon((string)($p['icon'] ?? '1'))).'.gif" width="32" height="32"></td>';
        echo '<td align="center">'.ebs_h((string)($p['st'][0] ?? '0')).'</td><td align="center">'.ebs_h((string)($p['st'][1] ?? '0')).'</td><td align="center">'.ebs_h((string)($p['st'][2] ?? '0')).'</td><td align="center">'.ebs_h((string)($p['st'][3] ?? '0')).'</td>';
        echo '<td align="center">0</td><td><b>'.ebs_h((string)($p['weapon'] ?? '')).'</b></td><td>휴식중</td></tr>';
    }
    if ($printed === 0) echo '<tr bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'"><td colspan="10" align="center">NoPlayer</td></tr>';
    echo '</table><br><br><br><br>';
}


/** 개인 무기/무기 데이터 관리. 원본 mainte.php의 WEAPON/ALLWEAPONS 관리 화면 대응. */
function ebs_admin_weapon_screen(string $script='maintenance.php'): void {
    $pass = ebs_h(ebs_admin_pass_value());
    $weapons = ebs_weapon_table();
    ebs_admin_header('무기 데이터 관리');
    echo '<form method="post" action="'.ebs_h($script).'"><input type="hidden" name="cmd" value="WEAPON_SAVE"><input type="hidden" name="pass" value="'.$pass.'">';
    echo '<table class="tbl"><tr><th>Key</th><th>무기명</th><th>공격</th><th>명중</th><th>회수</th><th>EN</th><th>가격</th><th>제한</th><th>특수</th><th>예비</th><th>이미지</th><th>삭제</th></tr>';
    $i = 0;
    foreach ($weapons as $key=>$row) {
        if ($i++ >= 300) break;
        echo '<tr><td><input class="inp" name="key[]" value="'.ebs_h((string)$key).'" size="8"></td>';
        for ($c=0; $c<10; $c++) echo '<td><input class="inp" name="col'.$c.'[]" value="'.ebs_h((string)($row[$c] ?? '')).'" size="'.($c===0?18:8).'"></td>';
        echo '<td align="center"><input type="checkbox" name="del['.$i.']" value="1"></td></tr>';
    }
    for ($n=0; $n<3; $n++) {
        echo '<tr><td><input class="inp" name="key[]" value="" size="8"></td>';
        for ($c=0; $c<10; $c++) echo '<td><input class="inp" name="col'.$c.'[]" value="" size="'.($c===0?18:8).'"></td>';
        echo '<td></td></tr>';
    }
    echo '</table><p><button class="btn" type="submit">무기 데이터 저장</button></p></form><p>';
    ebs_admin_nav_form($script, 'MAINTE2', '관리 메뉴');
    echo '</p>';
    ebs_admin_footer();
}

/** 무기 데이터 저장. PHP 변환본에서는 원본 log/_buki.data 대신 data/weapons.json에 저장한다. */
function ebs_admin_weapon_save(): void {
    $keys = $_POST['key'] ?? [];
    if (!is_array($keys)) { ebs_error_page('Error','무기 데이터가 올바르지 않습니다.'); return; }
    $rows = [];
    foreach ($keys as $idx=>$key) {
        if (!is_scalar($key)) continue;
        $k = trim((string)$key);
        if ($k === '' || isset($_POST['del'][$idx])) continue;
        $row = [];
        for ($c=0; $c<10; $c++) {
            $arr = $_POST['col'.$c] ?? [];
            $row[] = is_array($arr) && isset($arr[$idx]) && is_scalar($arr[$idx]) ? trim((string)$arr[$idx]) : '';
        }
        if (($row[0] ?? '') === '') continue;
        $rows[$k] = $row;
    }
    ebs_json_save('weapons', $rows);
    ebs_admin_audit('WEAPON_SAVE', '무기 데이터 '.count($rows).'건 저장');
    ebs_admin_weapon_screen(ebs_admin_script_name());
}


function ebs_config_override_file(): string { return __DIR__ . '/data/config_override.json'; }
function ebs_config_overrides_load(): array {
    $raw = is_file(ebs_config_override_file()) ? file_get_contents(ebs_config_override_file()) : '';
    return is_string($raw) && $raw !== '' ? ebs_json_decode_array($raw) : [];
}
function ebs_config_overrides_save(array $rows): bool {
    $clean=[];
    foreach ($rows as $k=>$v) {
        if (!is_string($k) || !preg_match('/^[A-Za-z0-9_]+$/', $k)) continue;
        if (is_scalar($v)) $clean[$k]=(string)$v;
    }
    return ebs_write('data/config_override.json', json_encode($clean, JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT));
}
function ebs_admin_config_label_map(): array {
    return [
        'OWNER_NAME'=>['관리인 이름','화면에 표시할 운영자 이름'],
        'OWNER_EMAIL'=>['관리인 이메일','관리자 연락처. 공백이면 표시하지 않음'],
        'ADMIN'=>['운영자 아이디','관리자 계정 식별명'],
        'MASTER_PWD'=>['관리자 비밀번호','관리 페이지 진입 패스워드'],
        'ICON'=>['아이콘 수','0.gif부터 사용할 일반 아이콘의 마지막 번호'],
        'YMICON'=>['문장 아이콘 수','1000.gif부터 사용할 문장 아이콘의 마지막 번호'],
        'LOG_FOLDER'=>['로그 폴더','로그/원본 데이터 폴더명'],
        'IMG_FOLDER1'=>['메뉴 이미지 폴더','상단/전투 메뉴 이미지 경로'],
        'IMG_FOLDER2'=>['캐릭터 이미지 폴더','캐릭터 아이콘 이미지 경로'],
        'YOUR_HOME'=>['홈 경로','종료/홈 이동 경로. 상대경로 권장'],
        'YOUR_BBS'=>['게시판 경로','게시판 파일 또는 주소'],
        'buimg'=>['무기 이미지 폴더','무기 아이콘 이미지 경로'],
        'THIS_DIR'=>['설치 디렉터리','현재 PHP 설치 폴더. 보통 .'],
        'COOKIE_KEEP'=>['쿠키 보존일수','로그인 쿠키 보존 및 삭제 방치 기간'],
        'HP_REPAIR2'=>['HP 회복률','초당 HP 회복률. 최대 HP 기준 %'],
        'EN_REPAIR2'=>['EN 회복률','초당 EN 회복률. 최대 EN 기준 %'],
        'HP_REPAIR_Y'=>['요새 HP 회복','요새의 초당 HP 회복량'],
        'HP_REPAIR'=>['HP 회복','초당 HP 회복량'],
        'EN_REPAIR'=>['EN 회복','초당 EN 회복량'],
        'HISTORY_MAX'=>['히스토리 최대 표시','전체 히스토리 보존/표시 건수'],
        'UPDATA_MAX'=>['업데이트 최대 표시','업데이트 목록 표시 건수'],
        'HISTORY_PAGE'=>['역사 페이지 건수','역사 1페이지 표시 건수'],
        'HISTORY2_PAGE'=>['역사2 페이지 건수','역사2 1페이지 표시 건수'],
        'HISTORY3_PAGE'=>['역사3 페이지 건수','역사3 1페이지 표시 건수'],
        'COUNTRY_MAX'=>['최대 국가 수','생성 가능한 최대 국가 수'],
        'ENTRY_MAX'=>['최대 등록 인원','가입 가능한 최대 참가자 수'],
        'MAKE_COUNTRY'=>['건국비','국가 생성에 필요한 비용'],
        'MAKE_TEAM'=>['부대 결성비','부대 생성에 필요한 비용'],
        'YOUSAI_HP'=>['초기 요새 HP','건국 시 요새 초기 HP'],
        'WEAPON_RANKUP'=>['무기 랭크업 레벨','무기 랭크 상승 기준 레벨'],
        'WEAPON_LVUP'=>['무기 레벨업 경험치','무기 레벨 상승에 필요한 경험치'],
        'MAX_WEAPONLV'=>['무기 최고 레벨','무기 레벨 상한'],
        'GET_MONEY'=>['전투 수입 배율','전투 후 획득 골드 계산값'],
        'MAX_HP'=>['HP 상한','플레이어 HP 최대값'],
        'MAX_EN'=>['EN 상한','플레이어 EN 최대값'],
        'hea'=>['회복 관련 보정값','기존 hea 설정값'],
        'SATELLITE_FLAG'=>['데이터 이동 허가','DataImport/DataExport 허가. 1=허가, 0=불가'],
        'POOHLOVE'=>['푸 축복 레벨','푸의 축복을 받을 수 있는 레벨'],
        'event'=>['이벤트 실행','이벤트 실행 여부'],
        'eventco'=>['이벤트 문구','상태창에 표시할 이벤트 코멘트'],
        'adminad'=>['추가사항','상단/상태창 추가사항 공지'],
        'tip'=>['도우미 문구','상태창 도움말 문구'],
        'STperLEVEL'=>['레벨당 보너스 스탯','레벨업 시 지급되는 스탯'],
        'ST_limit'=>['스탯 제한','총 스탯 중 한 항목에 배분 가능한 비율'],
        'ST_resetpay'=>['스탯 초기화 비용','스탯 초기화 시 스탯 1당 비용'],
        'DIRECT_LINK'=>['직접 링크 금지','1=금지, 0=허가'],
        'UPPER_FRAME'=>['상단 프레임 높이','상단 프레임 크기 설정'],
        'BANNER_DISPLAY'=>['배너 표시 설정','1=비표시, 0=표시'],
        'CONFIG_DISPLAY'=>['사이트 데이터 공개','TOP 하부 프레임에 등록 수 등 공개. 1=공개, 0=비공개'],
        'SPECIAL_ICON'=>['특수 아이콘 사용','조건부 특수 아이콘 사용 여부'],
        'S_ICON_NUMBER'=>['특수 아이콘 마지막 번호','특수 아이콘 파일 마지막 번호'],
        'NAIRAN_MODE'=>['내란 허가','내란 커맨드. 1=허가, 0=불허'],
        'NT_START'=>['각성 시작 조건','각성 발동 조건'],
        'NT_END'=>['각성 종료 조건','각성 종료 조건'],
        'COMMENT_1'=>['공지사항','메인/로그인 화면 공지사항'],
        'COMMENT_2'=>['공지사항2','하단 추가 표시 문구'],
        'COMMENT_3'=>['공지사항3','예비 공지 문구'],
        'COPYRIGHT_ICON'=>['아이콘 저작권','배포 이미지 사용 시 저작권 표시'],
        'LINK'=>['링크 색상','기본 링크 색상'],
        'HOVER'=>['링크 마우스 색상','마우스 오버 링크 색상'],
        'BG_TOP'=>['TOP 배경색','TOP/로그인 화면 배경색'],
        'BG_MAIN'=>['메인 배경색','일반 화면 배경색'],
        'BG_STATUS'=>['상태창 배경색','스테이터스 표시부 배경색'],
        'FONT_COLOR'=>['글자 색상','기본 글자 색상'],
        'TABLE_COLOR1'=>['테이블 배경색','테이블 본문 색상'],
        'TABLE_COLOR2'=>['테이블 강조색','테이블 헤더/강조 색상'],
        'TABLE_BORDER'=>['테이블 경계선','테이블 보더 색상'],
        'BG_BUTTON'=>['버튼 배경색','폼 버튼 배경색'],
        'FC_BUTTON'=>['버튼 글자색','폼 버튼 글자색'],
        'BG_LIST'=>['입력창 배경색','풀다운/텍스트 입력창 배경색'],
        'FC_LIST'=>['입력창 글자색','풀다운/텍스트 입력창 글자색'],
        'CUSTOM_NAME'=>['개조 명칭','개조 메뉴 표시명'],
        'NONE_NATIONALITY'=>['무소속 명칭','국가가 없는 참가자 표시명'],
        'kk_time'=>['참가자 명단 갱신','참가자 명단 갱신 주기. 분 단위'],
        'C_MAX_MEMBER'=>['국가 최대 인원','한 나라당 최고 인원 수'],
        'MAIN_SCRIPT'=>['메인 PHP 파일','메인 라우터 파일. 보통 ./ebs.php'],
        'SCRIPTNM'=>['스크립트명','원본 SCRIPTNM 대응. 보통 ./ebs.php'],
        'STYLE_B1'=>['큰 버튼 스타일','버튼 CSS 스타일'],
        'STYLE_B2'=>['작은 버튼 스타일','작은 버튼 CSS 스타일'],
        'STYLE_L'=>['입력창 스타일','입력창 CSS 스타일'],
        'VER'=>['버전','표시 버전'],
        'DATE'=>['현재 날짜값','원본 DATE 대응. PHP에서는 런타임 사용'],
        'CL_VALUES'=>['국가 색상값','현재 국가 색상 캐시'],
        'ENTRYS'=>['현재 등록 인원','자동 계산값. user/*.json 기준'],
        'total'=>['참전자 수','자동 계산값'],
        'sanka'=>['참가자 수','자동 계산값'],
        'totalC'=>['국가 수','자동 계산값'],
        'sankaC'=>['참가국 수','자동 계산값'],
        'BgColor'=>['배경색 별칭','원본 호환 배경색 값'],
    ];
}

function ebs_admin_config_group_for(string $key): string {
    if (in_array($key, ['OWNER_NAME','OWNER_EMAIL','ADMIN','MASTER_PWD','VER','DATE'], true)) return '관리자/기본 표시';
    if (in_array($key, ['COMMENT_1','COMMENT_2','COMMENT_3','adminad','tip','event','eventco','COPYRIGHT_ICON'], true)) return '공지/이벤트 문구';
    if (in_array($key, ['COOKIE_KEEP','COUNTRY_MAX','ENTRY_MAX','MAKE_COUNTRY','MAKE_TEAM','C_MAX_MEMBER','YOUSAI_HP','MAX_HP','MAX_EN','GET_MONEY','hea','POOHLOVE','STperLEVEL','ST_limit','ST_resetpay'], true)) return '게임 수치';
    if (in_array($key, ['HP_REPAIR','EN_REPAIR','HP_REPAIR2','EN_REPAIR2','HP_REPAIR_Y','WEAPON_RANKUP','WEAPON_LVUP','MAX_WEAPONLV','NAIRAN_MODE','NT_START','NT_END'], true)) return '회복/전투/무기';
    if (in_array($key, ['YOUR_HOME','YOUR_BBS','THIS_DIR','MAIN_SCRIPT','SCRIPTNM','IMG_FOLDER1','IMG_FOLDER2','buimg','LOG_FOLDER'], true)) return '파일/경로';
    if (in_array($key, ['UPPER_FRAME','BANNER_DISPLAY','CONFIG_DISPLAY','DIRECT_LINK','SPECIAL_ICON','S_ICON_NUMBER','SATELLITE_FLAG','kk_time'], true)) return '화면/허가 설정';
    if (in_array($key, ['BG_TOP','BG_MAIN','BG_STATUS','FONT_COLOR','LINK','HOVER','TABLE_COLOR1','TABLE_COLOR2','TABLE_BORDER','BG_BUTTON','FC_BUTTON','BG_LIST','FC_LIST','BgColor'], true)) return '색상';
    if (in_array($key, ['STYLE_B1','STYLE_B2','STYLE_L'], true)) return 'HTML 스타일';
    if (in_array($key, ['ENTRYS','total','sanka','totalC','sankaC','CL_VALUES'], true)) return '자동 계산값';
    return '기타 설정';
}

function ebs_admin_config_readonly_keys(): array {
    return ['ENTRYS'=>true,'total'=>true,'sanka'=>true,'totalC'=>true,'sankaC'=>true,'CL_VALUES'=>true,'DATE'=>true];
}

function ebs_admin_config_keys(): array {
    ebs_bootstrap_runtime_counts();
    $groups = [];
    foreach ($GLOBALS['EBS_VARS'] as $key=>$value) {
        if (!is_string($key) || !is_scalar($value)) continue;
        if (!preg_match('/^[A-Za-z0-9_]+$/', $key)) continue;
        $group = ebs_admin_config_group_for($key);
        if (!isset($groups[$group])) $groups[$group] = [];
        $groups[$group][] = $key;
    }
    foreach ($groups as $group=>$keys) {
        $keys = array_values(array_unique($keys));
        sort($keys, SORT_STRING);
        $groups[$group] = $keys;
    }
    $order = ['관리자/기본 표시','공지/이벤트 문구','게임 수치','회복/전투/무기','파일/경로','화면/허가 설정','색상','HTML 스타일','자동 계산값','기타 설정'];
    $ordered = [];
    foreach ($order as $group) if (isset($groups[$group])) $ordered[$group] = $groups[$group];
    foreach ($groups as $group=>$keys) if (!isset($ordered[$group])) $ordered[$group] = $keys;
    return $ordered;
}

function ebs_admin_config_screen(string $script='maintenance.php', string $message=''): void {
    $pass = ebs_h(ebs_admin_pass_value());
    $over = ebs_config_overrides_load();
    $labels = ebs_admin_config_label_map();
    $readonly = ebs_admin_config_readonly_keys();
    ebs_admin_header('config.php 전체 운영 설정 관리');
    if ($message !== '') echo '<p class="ok">'.ebs_h($message).'</p>';
    echo '<p>config.php의 스칼라 설정 전체를 표시합니다. 영문 키는 코드 호환을 위해 유지하고, 한글명/설명으로 의미를 확인할 수 있게 했습니다. 관리자 수정값은 data/config_override.json에 저장되어 우선 적용됩니다.</p>';
    echo '<form method="post" action="'.ebs_h($script).'"><input type="hidden" name="cmd" value="CONFIG_SAVE"><input type="hidden" name="pass" value="'.$pass.'">';
    foreach (ebs_admin_config_keys() as $group=>$keys) {
        echo '<div class="head" style="margin-top:10px">'.ebs_h($group).'</div><table class="tbl"><tr><th style="width:150px">영문 키</th><th style="width:160px">한글명</th><th>현재값</th><th style="width:260px">설명</th><th style="width:70px">초기값</th></tr>';
        foreach ($keys as $key) {
            $val = ebs_v($key,'');
            $label = $labels[$key][0] ?? $key;
            $desc = $labels[$key][1] ?? '원본 config.php 호환 설정값';
            $isLong = in_array($key, ['COMMENT_1','COMMENT_2','COMMENT_3','adminad','tip','eventco','STYLE_B1','STYLE_B2','STYLE_L'], true) || strlen($val) > 90;
            $mark = array_key_exists($key, $over) ? ' <span class="ok">override</span>' : '';
            $ro = isset($readonly[$key]);
            echo '<tr><td><b>'.ebs_h($key).'</b>'.$mark.'</td><td>'.ebs_h($label).'</td><td>';
            if ($isLong) echo '<textarea class="inp" name="cfg['.ebs_h($key).']" rows="3" style="width:98%;height:70px"'.($ro?' readonly':'').'>'.ebs_h($val).'</textarea>';
            else echo '<input class="inp" name="cfg['.ebs_h($key).']" value="'.ebs_h($val).'" style="width:98%"'.($ro?' readonly':'').'>';
            if ($key === 'SATELLITE_FLAG') echo '<div style="font-size:11px;color:#ffdd66">DataImport/DataExport 허가: 1=허가, 0=불가</div>';
            if ($ro) echo '<div style="font-size:11px;color:#aaa">자동 계산값이므로 저장 대상에서 제외됩니다.</div>';
            echo '</td><td>'.ebs_h($desc).'</td><td align="center">'.($ro ? '-' : '<input type="checkbox" name="clear['.ebs_h($key).']" value="1">').'</td></tr>';
        }
        echo '</table>';
    }
    echo '<p><button class="btn" type="submit">config 설정 저장</button></p></form><p>';
    ebs_admin_nav_form($script,'MAINTE2','관리 메뉴');
    echo '</p>';
    ebs_admin_footer();
}

function ebs_admin_config_save(): void {
    $script = ebs_admin_script_name();
    $allowed=[];
    foreach (ebs_admin_config_keys() as $keys) foreach ($keys as $k) $allowed[$k]=true;
    foreach (ebs_admin_config_readonly_keys() as $k=>$v) unset($allowed[$k]);
    $override = ebs_config_overrides_load();
    $cfg = $_POST['cfg'] ?? [];
    if (is_array($cfg)) {
        foreach ($cfg as $key=>$val) {
            if (!is_string($key) || !isset($allowed[$key]) || !is_scalar($val)) continue;
            $v = (string)$val;
            if (isset($_POST['clear'][$key])) { unset($override[$key]); continue; }
            if (in_array($key, ['YOUR_HOME'], true)) $v = './';
            if (in_array($key, ['MAIN_SCRIPT','SCRIPTNM'], true)) $v = './ebs.php';
            if (in_array($key, ['YOUR_BBS'], true) && preg_match('/^https?:\/\//i', $v)) $v = './board.php';
            if (in_array($key, ['IMG_FOLDER1','IMG_FOLDER2','buimg'], true) && preg_match('/^https?:\/\//i', $v)) {
                $v = ['IMG_FOLDER1'=>'./img1','IMG_FOLDER2'=>'./img2','buimg'=>'./bukiimg'][$key];
            }
            if ($key === 'SATELLITE_FLAG') $v = $v === '1' ? '1' : '0';
            $override[$key]=$v;
            $GLOBALS['EBS_VARS'][$key]=$v;
        }
    }
    ebs_config_overrides_save($override);
    ebs_admin_audit('CONFIG_SAVE', '운영 설정 저장');
    ebs_admin_config_screen($script, '저장했습니다.');
}


function ebs_admin_public_text_rows(string $store): array {
    $rows = ebs_json_load($store);
    return is_array($rows) ? $rows : [];
}

function ebs_admin_public_text_screen(string $script, string $store, string $cmd, string $title, string $label, string $message=''): void {
    $pass = ebs_h(ebs_admin_pass_value());
    $rows = ebs_admin_public_text_rows($store);
    ebs_admin_header($title);
    if ($message !== '') echo '<p class="ok">'.ebs_h($message).'</p>';
    echo '<form method="post" action="'.ebs_h($script).'" style="margin:0"><input type="hidden" name="cmd" value="'.ebs_h($cmd).'_SAVE"><input type="hidden" name="mode" value="save"><input type="hidden" name="pass" value="'.$pass.'">';
    echo '<table class="tbl"><tr><th colspan="3">'.ebs_h($label).' 작성</th></tr>';
    echo '<tr><td width="120">내용</td><td><textarea class="inp" name="text" rows="4" style="width:98%;height:78px"></textarea></td><td width="80" align="center"><button class="btn" type="submit">추가</button></td></tr></table></form>';
    echo '<table class="tbl" style="margin-top:8px"><tr><th width="150">시간</th><th>내용</th><th width="70">삭제</th></tr>';
    $printed = 0;
    foreach (array_reverse($rows, true) as $idx=>$row) {
        if (is_array($row)) {
            $time = (string)($row['time'] ?? $idx);
            $text = (string)($row['text'] ?? $row['body'] ?? '');
        } elseif (is_scalar($row)) {
            $time = (string)$idx;
            $text = (string)$row;
        } else continue;
        if ($text === '') continue;
        $printed++;
        echo '<tr><td>'.ebs_h($time).'</td><td style="white-space:pre-wrap">'.ebs_h($text).'</td><td align="center"><form method="post" action="'.ebs_h($script).'" style="margin:0"><input type="hidden" name="cmd" value="'.ebs_h($cmd).'_SAVE"><input type="hidden" name="mode" value="delete"><input type="hidden" name="idx" value="'.ebs_h((string)$idx).'"><input type="hidden" name="pass" value="'.$pass.'"><button class="btn" type="submit">삭제</button></form></td></tr>';
    }
    if ($printed === 0) echo '<tr><td colspan="3" align="center">작성된 내용이 없습니다.</td></tr>';
    echo '</table><p>';
    ebs_admin_nav_form($script, 'MAINTE2', '관리 메뉴');
    echo '</p>';
    ebs_admin_footer();
}

function ebs_admin_public_text_save(string $script, string $store, string $cmd, string $title, string $label): void {
    $rows = ebs_admin_public_text_rows($store);
    $mode = ebs_param('mode','');
    if ($mode === 'save') {
        $text = trim(ebs_param('text',''));
        if ($text !== '') {
            $rows[] = ['time'=>date('YmdHis'), 'text'=>$text];
            if (count($rows) > 300) $rows = array_slice($rows, -300);
            ebs_json_save($store, $rows);
            ebs_admin_audit(strtoupper($store).'_SAVE', $label.' 작성');
        }
    } elseif ($mode === 'delete') {
        $idx = ebs_param('idx','');
        $deleted = false;
        if ($idx !== '' && isset($rows[$idx])) {
            unset($rows[$idx]);
            $deleted = true;
        } elseif ($idx !== '' && isset($rows[(int)$idx])) {
            unset($rows[(int)$idx]);
            $deleted = true;
        }
        if ($deleted) {
            $rows = array_values($rows);
            ebs_json_save($store, $rows);
            ebs_admin_audit(strtoupper($store).'_DELETE', $label.' 삭제');
        }
    }
    ebs_admin_public_text_screen($script, $store, $cmd, $title, $label, '저장했습니다.');
}

function ebs_admin_history_public_screen(string $script='maintenance.php', string $message=''): void {
    ebs_admin_public_text_screen($script, 'history_data', 'HISTORY_EDIT', '역사 편찬', '역사', $message);
}
function ebs_admin_history_public_save(string $script='maintenance.php'): void {
    ebs_admin_public_text_save($script, 'history_data', 'HISTORY_EDIT', '역사 편찬', '역사');
}
function ebs_admin_update_public_screen(string $script='maintenance.php', string $message=''): void {
    ebs_admin_public_text_screen($script, 'updata', 'UPDATE_EDIT', '업데이트 작성', '업데이트', $message);
}
function ebs_admin_update_public_save(string $script='maintenance.php'): void {
    ebs_admin_public_text_save($script, 'updata', 'UPDATE_EDIT', '업데이트 작성', '업데이트');
}

function ebs_admin_notice_screen(string $script='maintenance.php', string $message=''): void {
    $pass = ebs_h(ebs_admin_pass_value());
    ebs_admin_header('공지사항 / 추가사항 관리');
    if ($message !== '') echo '<p class="ok">'.ebs_h($message).'</p>';
    echo '<form method="post" action="'.ebs_h($script).'"><input type="hidden" name="cmd" value="NOTICE_SAVE"><input type="hidden" name="pass" value="'.$pass.'">';
    echo '<table class="tbl"><tr><th>항목</th><th>내용</th><th>처리</th></tr>';
    foreach (['COMMENT_1'=>'공지사항','adminad'=>'추가사항','COMMENT_2'=>'공지사항2','COMMENT_3'=>'공지사항3'] as $key=>$label) {
        echo '<tr><td>'.ebs_h($label).'<br><span style="color:#aaa">'.ebs_h($key).'</span></td><td><textarea class="inp" name="cfg['.ebs_h($key).']" rows="4" style="width:98%;height:82px">'.ebs_h(ebs_v($key,'')).'</textarea></td>';
        echo '<td align="center"><label><input type="checkbox" name="clear['.ebs_h($key).']" value="1"> 삭제</label></td></tr>';
    }
    echo '</table><p><button class="btn" type="submit">공지/추가사항 저장</button></p></form><p>';
    ebs_admin_nav_form($script,'MAINTE2','관리 메뉴');
    echo '</p>';
    ebs_admin_footer();
}
function ebs_admin_notice_save(): void {
    $script = ebs_admin_script_name();
    $override = ebs_config_overrides_load();
    $cfg = $_POST['cfg'] ?? [];
    foreach (['COMMENT_1','adminad','COMMENT_2','COMMENT_3'] as $key) {
        $val = is_array($cfg) && isset($cfg[$key]) && is_scalar($cfg[$key]) ? (string)$cfg[$key] : ebs_v($key,'');
        if (isset($_POST['clear'][$key])) $val = '';
        $override[$key] = $val;
        $GLOBALS['EBS_VARS'][$key] = $val;
    }
    ebs_config_overrides_save($override);
    ebs_admin_audit('NOTICE_SAVE', '공지사항/추가사항 저장');
    ebs_admin_notice_screen($script, '저장했습니다. 상단 공지 프레임은 새로고침 후 반영됩니다.');
}
function ebs_admin_bougu_screen(string $script='maintenance.php', string $message=''): void {
    $pass = ebs_h(ebs_admin_pass_value());
    $rows = ebs_bougu_table();
    ebs_admin_header('보강장비 데이터 관리');
    if ($message !== '') echo '<p class="ok">'.ebs_h($message).'</p>';
    echo '<form method="post" action="'.ebs_h($script).'"><input type="hidden" name="cmd" value="BOUGU_SAVE"><input type="hidden" name="pass" value="'.$pass.'">';
    echo '<table class="tbl"><tr><th>Key</th><th>명칭</th><th>방어</th><th>무게</th><th>명중</th><th>공격</th><th>가격</th><th>입수</th><th>특수</th><th>상품</th><th>효과 설명</th><th>내구</th><th>삭제</th></tr>';
    $i=0;
    foreach ($rows as $key=>$row) {
        if (!is_array($row)) continue;
        echo '<tr><td><input class="inp" name="key[]" value="'.ebs_h((string)$key).'" size="4"></td>';
        for ($c=0;$c<11;$c++) echo '<td><input class="inp" name="col'.$c.'[]" value="'.ebs_h((string)($row[$c] ?? '')).'" size="'.($c===9?24:8).'"></td>';
        echo '<td align="center"><input type="checkbox" name="del['.$i.']" value="1"></td></tr>';
        $i++;
    }
    for ($n=0;$n<3;$n++) {
        echo '<tr><td><input class="inp" name="key[]" value="" size="4"></td>';
        for ($c=0;$c<11;$c++) echo '<td><input class="inp" name="col'.$c.'[]" value="" size="'.($c===9?24:8).'"></td>';
        echo '<td></td></tr>';
    }
    echo '</table><p><button class="btn" type="submit">보강장비 데이터 저장</button></p></form><p>';
    ebs_admin_nav_form($script,'MAINTE2','관리 메뉴');
    echo '</p>';
    ebs_admin_footer();
}
function ebs_admin_bougu_save(): void {
    $keys = $_POST['key'] ?? [];
    if (!is_array($keys)) { ebs_error_page('Error','보강장비 데이터가 올바르지 않습니다.'); return; }
    $rows=[];
    foreach ($keys as $idx=>$key) {
        if (!is_scalar($key)) continue;
        $k = trim((string)$key);
        if ($k === '' || isset($_POST['del'][$idx])) continue;
        $row=[];
        for ($c=0;$c<11;$c++) {
            $arr = $_POST['col'.$c] ?? [];
            $row[] = is_array($arr) && isset($arr[$idx]) && is_scalar($arr[$idx]) ? trim((string)$arr[$idx]) : '';
        }
        if (($row[0] ?? '') === '') continue;
        $rows[$k]=$row;
    }
    ksort($rows, SORT_STRING);
    ebs_json_save('bougu', $rows);
    ebs_admin_audit('BOUGU_SAVE', '보강장비 데이터 '.count($rows).'건 저장');
    ebs_admin_bougu_screen(ebs_admin_script_name(), '저장했습니다.');
}

/** 원본 legacy의 ERROR 출력 대체. */
function ebs_error_page(string $title, string $message=''): void {
    ebs_header_html();
    echo '<!DOCTYPE HTML PUBLIC -//IETF//DTD HTML//EN><html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>ENDLESS BATTLE</title></head>';
    echo '<body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="margin:0px 0px 0px 0px;" oncontextmenu="return false;">';
    echo '<table width="100%" height="100%"><tr><td align="center"><table bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" style="border:1px solid '.ebs_h(ebs_v('TABLE_BORDER')).';font-size:15px;">';
    echo '<tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'"><b>'.ebs_h($title).'</b></td></tr><tr><td>'.ebs_h($message !== '' ? $message : $title).'</td></tr>';
    echo '</table></td></tr></table></body></html>';
}



function ebs_admin_logout(): void {
    if (session_status() === PHP_SESSION_ACTIVE) {
        $_SESSION['EBS_ADMIN_OK'] = false;
        unset($_SESSION['EBS_ADMIN_OK'], $_SESSION['EBS_ADMIN_PASS']);
    }
    if (!headers_sent()) setcookie('EBS_ADMIN_PASS', '', time() - 3600, '/');
    ebs_admin_header('관리자 로그아웃');
    echo '<p class="ok">관리자 세션을 종료했습니다.</p>';
    echo '<p><a class="btn" style="display:inline-block;padding:4px 10px;text-decoration:none" href="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" target="_top">ebs.php로 나가기</a></p>';
    ebs_admin_footer();
}

/** 관리자 비밀번호 확인. 원본 MASTER_PWD를 그대로 사용한다. */
function ebs_admin_ok(): bool {
    $master = (string)ebs_v('MASTER_PWD');
    if (isset($_SESSION['EBS_ADMIN_OK']) && $_SESSION['EBS_ADMIN_OK'] === true) return true;
    $pass = ebs_param('pass', '');
    if ($pass === '' && isset($_SESSION['EBS_ADMIN_PASS']) && is_string($_SESSION['EBS_ADMIN_PASS'])) $pass = trim($_SESSION['EBS_ADMIN_PASS']);
    if ($pass === '' && isset($_COOKIE['EBS_ADMIN_PASS']) && is_string($_COOKIE['EBS_ADMIN_PASS'])) $pass = trim($_COOKIE['EBS_ADMIN_PASS']);
    $ok = $pass !== '' && hash_equals($master, $pass);
    if ($ok) {
        $_SESSION['EBS_ADMIN_OK'] = true;
        $_SESSION['EBS_ADMIN_PASS'] = $pass;
        if (!headers_sent()) setcookie('EBS_ADMIN_PASS', $pass, time() + 86400, '/');
    }
    return $ok;
}

/** 관리자 화면 공통 헤더. 본 게임과 같은 검정 계열 스타일을 유지한다. */

/** 현재 실행 중인 관리자 PHP 파일명. 관리자 처리 후 원래 화면으로 되돌리기 위해 사용한다. */
function ebs_admin_script_name(string $default='maintenance.php'): string {
    $self = $_SERVER['SCRIPT_NAME'] ?? '';
    $base = is_string($self) && $self !== '' ? basename($self) : '';
    if ($base !== '' && preg_match('/^[A-Za-z0-9_\-]+\.php$/', $base)) return $base;
    return $default;
}

function ebs_admin_audit(string $type, string $body=''): void {
    $rows = ebs_json_load('admin_history');
    if (!is_array($rows)) $rows = [];
    $rows[] = [
        'time' => date('Y-m-d H:i:s'),
        'type' => $type,
        'name' => 'admin',
        'body' => $body,
        'script' => ebs_admin_script_name(),
    ];
    if (count($rows) > 500) $rows = array_slice($rows, -500);
    ebs_json_save('admin_history', $rows);
}

/** 관리자 패스워드 전달값. 원본 legacy는 각 폼에 pass를 계속 넘기므로 PHP에서도 같은 흐름을 유지한다. */
function ebs_admin_pass_value(): string {
    $pass = ebs_param('pass', '');
    if ($pass === '' && isset($_SESSION['EBS_ADMIN_PASS']) && is_string($_SESSION['EBS_ADMIN_PASS'])) $pass = trim($_SESSION['EBS_ADMIN_PASS']);
    if ($pass === '' && isset($_COOKIE['EBS_ADMIN_PASS']) && is_string($_COOKIE['EBS_ADMIN_PASS'])) $pass = trim($_COOKIE['EBS_ADMIN_PASS']);
    return $pass;
}

function ebs_admin_pass_query(): string {
    return rawurlencode(ebs_admin_pass_value());
}
function ebs_admin_nav_form(string $script, string $cmd, string $label): void {
    $pass = ebs_h(ebs_admin_pass_value());
    echo '<form method="post" action="'.ebs_h($script).'" style="display:inline;margin:0 4px 0 0"><input type="hidden" name="pass" value="'.$pass.'"><button class="btn" name="cmd" value="'.ebs_h($cmd).'">'.ebs_h($label).'</button></form>';
}

function ebs_admin_header(string $title): void {
    ebs_header_html();
    echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>'.ebs_h($title).'</title>';
    echo '<style>body{font-family:Arial,"Malgun Gothic",sans-serif;background:#000;color:#ededed;margin:0}a{color:#9aa9ff}.wrap{padding:18px}.box{background:#101010;border:1px solid #808080;margin:10px auto;padding:10px;max-width:1120px}.head{background:#606060;color:#fff;border-bottom:1px solid #808080;font-weight:bold;padding:6px}.tbl{border-collapse:collapse;width:100%;font-size:13px;color:#ededed}.tbl th,.tbl td{border:1px solid #808080;padding:4px;background:#202020}.tbl th{background:#606060;color:#fff}.btn{height:24px;background:#000;color:#ededed;border:1px solid #808080}.inp{height:21px;background:#000;color:#ededed;border:1px inset #808080}.warn{color:#ff6666;font-weight:bold}.ok{color:#66ff66;font-weight:bold}.menu button,.menu input{margin:2px}</style>';
    echo '</head><body><div class="wrap"><div class="box"><div class="head">'.ebs_h($title).'</div>';
    echo '<div style="text-align:right;margin:6px 0 10px 0"><a class="btn" style="display:inline-block;padding:4px 10px;text-decoration:none" href="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" target="_top">ebs.php로 나가기</a> <form method="post" action="'.ebs_h(ebs_admin_script_name()).'" style="display:inline;margin:0 0 0 6px"><button class="btn" name="cmd" value="LOGOUT">관리자 로그아웃</button></form></div>';
}
function ebs_admin_footer(): void { echo '</div></div></body></html>'; }

/** 관리자 로그인 폼. 원본 editadmin.php / maintenance.php의 첫 화면 대응. */
function ebs_admin_login_form(string $script, string $title='Maintenance Mode'): void {
    ebs_admin_header($title);
    $loginCmd = (basename($script) === 'mainte.php' || basename($script) === 'maintenance.php' || basename($script) === 'editadmin.php') ? 'MAINTE2' : 'MAINTE2';
    echo '<form action="'.ebs_h($script).'" method="post"><input type="hidden" name="cmd" value="'.ebs_h($loginCmd).'">';
    echo '<table class="tbl" style="max-width:420px;margin:30px auto"><tr><th colspan="2">'.ebs_h($title).'</th></tr>';
    echo '<tr><td>PASS</td><td><input class="inp" type="password" name="pass"> <input class="btn" type="submit" value="Login"></td></tr></table></form>';
    echo '<div style="text-align:center"><a href="'.ebs_h(ebs_v('MAIN_SCRIPT')).'">게임으로 돌아가기</a></div>';
    ebs_admin_footer();
}

/** 관리자 메인 메뉴. 원본 관리자 링크를 PHP 파일/명령으로 연결한다. */
function ebs_admin_player_select_options(array $players, string $selected=''): string {
    $out = '<option value=""></option>';
    foreach ($players as $key=>$p) {
        if (!is_array($p)) continue;
        $name = (string)($p['name'] ?? $key);
        $out .= '<option value="'.ebs_h($name).'"'.($name===$selected ? ' selected' : '').'>'.ebs_h($name).'</option>';
    }
    return $out;
}
function ebs_admin_menu_row(string $script, string $label, string $desc, string $cmd, string $extraHtml='', string $button='결정'): void {
    $pass = ebs_h(ebs_admin_pass_value());
    echo '<tr><td width="140" align="center" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'">'.ebs_h($label).'</td><td>'.ebs_h($desc).$extraHtml.'</td><td width="44" align="center"><form method="post" action="'.ebs_h($script).'" style="margin:0"><input type="hidden" name="pass" value="'.$pass.'"><button class="btn" name="cmd" value="'.ebs_h($cmd).'">'.ebs_h($button).'</button></form></td></tr>';
}
function ebs_admin_menu(string $script='editadmin.php'): void {
    ebs_bootstrap_players_from_backup();
    $players = ebs_players_load();
    $countries = ebs_country_records();
    $pass = ebs_h(ebs_admin_pass_value());
    $scriptH = ebs_h($script);
    ebs_admin_header('데이터 메인터넌스');
    echo '<table class="tbl" style="max-width:920px;margin:0 auto">';
    echo '<tr><th colspan="3">데이터 메인터넌스 <span style="float:right"><form method="post" action="'.$scriptH.'" style="display:inline;margin:0"><input type="hidden" name="pass" value="'.$pass.'"><button class="btn" name="cmd" value="MAINTE2">갱신</button></form></span></th></tr>';
    echo '<tr><td colspan="3" align="center">'.number_format(count($players)).'건 정보를 읽었습니다.</td></tr>';
    echo '<tr><th colspan="3">사람데이터관리</th></tr>';
    echo '<tr><td align="center" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'">사람정보</td><td>';
    echo '<form method="post" action="'.$scriptH.'" style="margin:0"><input type="hidden" name="pass" value="'.$pass.'"><select class="inp" name="plname">'.ebs_admin_player_select_options($players).'</select> 플레이어명 직접 입력 : <input class="inp" name="plname2" size="18"> ';
    echo '<select class="inp" name="admin_action"><option value="PLAYER_EDIT">플레이어 데이터수정</option><option value="USER_REPAIR">플레이어 데이터 점검/수리</option><option value="DEL">플레이어 삭제</option></select></td><td align="center"><button class="btn" name="cmd" value="ADMIN_ACTION">결정</button></form></td></tr>';
    echo '<tr><td align="center" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'">전부등록</td><td>플레이어를 전부 수정할 수 있습니다.</td><td align="center"><form method="post" action="'.$scriptH.'" style="margin:0"><input type="hidden" name="pass" value="'.$pass.'"><button class="btn" name="cmd" value="MASTER">결정</button></form></td></tr>';
    echo '<tr><td align="center" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'">사람데이터 백업</td><td>사용 데이터 백업을 작성합니다. <select class="inp"><option>플레이어데이터</option></select></td><td align="center"><form method="post" action="'.$scriptH.'" style="margin:0"><input type="hidden" name="pass" value="'.$pass.'"><button class="btn" name="cmd" value="BACKUP_RUN">결정</button></form></td></tr>';
    echo '<tr><td align="center" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'">사람데이터 복구</td><td>백업을 이용해서 데이터를 복구합니다. <select class="inp"><option>플레이어데이터</option></select></td><td align="center"><form method="post" action="'.$scriptH.'" style="margin:0"><input type="hidden" name="pass" value="'.$pass.'"><button class="btn" name="cmd" value="DATAUP">결정</button></form></td></tr>';
    echo '<tr><td align="center" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'">사람데이터 하나씩 복구</td><td>백업을 이용해서 사람을 하나씩 복구합니다. <select class="inp"><option>플레이어데이터</option></select></td><td align="center"><form method="post" action="'.$scriptH.'" style="margin:0"><input type="hidden" name="pass" value="'.$pass.'"><button class="btn" name="cmd" value="DATAUP">결정</button></form></td></tr>';
    echo '<tr><td align="center" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'">사람삭제</td><td><form method="post" action="'.$scriptH.'" style="margin:0"><input type="hidden" name="pass" value="'.$pass.'"><select class="inp" name="plname">'.ebs_admin_player_select_options($players).'</select> 플레이어명 직접 입력 : <input class="inp" name="plname2" size="18"></td><td align="center"><button class="btn" name="cmd" value="DEL">결정</button></form></td></tr>';
    echo '<tr><th colspan="3">나라 데이터 관리</th></tr>';
    echo '<tr><td align="center" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'">나라정보</td><td><form method="post" action="'.$scriptH.'" style="margin:0"><input type="hidden" name="pass" value="'.$pass.'"><select class="inp" name="country"><option value=""></option>';
    foreach ($countries as $name=>$c) echo '<option value="'.ebs_h((string)$name).'">'.ebs_h((string)$name).'</option>';
    echo '</select> 나라명 직접입력 : <input class="inp" name="country2" size="18"></td><td align="center"><button class="btn" name="cmd" value="COUNTRY_EDIT">결정</button></form></td></tr>';
    echo '<tr><td align="center" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'">신규군국</td><td>나라를 건국할 수 있습니다.</td><td align="center"><form method="post" action="'.$scriptH.'" style="margin:0"><input type="hidden" name="pass" value="'.$pass.'"><button class="btn" name="cmd" value="COUNTRY">결정</button></form></td></tr>';
    echo '<tr><td align="center" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'">나라 백업</td><td>나라를 백업합니다.</td><td align="center"><form method="post" action="'.$scriptH.'" style="margin:0"><input type="hidden" name="pass" value="'.$pass.'"><button class="btn" name="cmd" value="BACKUP_RUN">결정</button></form></td></tr>';
    echo '<tr><td align="center" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'">나라 복구</td><td>나라를 복구합니다.</td><td align="center"><form method="post" action="'.$scriptH.'" style="margin:0"><input type="hidden" name="pass" value="'.$pass.'"><button class="btn" name="cmd" value="DATAUP">결정</button></form></td></tr>';
    echo '<tr><td align="center" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'">나라 하나씩 복구</td><td>나라를 하나씩 복구합니다.</td><td align="center"><form method="post" action="'.$scriptH.'" style="margin:0"><input type="hidden" name="pass" value="'.$pass.'"><button class="btn" name="cmd" value="DATAUP">결정</button></form></td></tr>';
    echo '<tr><td align="center" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'">나라 삭제</td><td><form method="post" action="'.$scriptH.'" style="margin:0"><input type="hidden" name="pass" value="'.$pass.'"><select class="inp" name="country"><option value=""></option>';
    foreach ($countries as $name=>$c) echo '<option value="'.ebs_h((string)$name).'">'.ebs_h((string)$name).'</option>';
    echo '</select> 나라명 직접 입력 : <input class="inp" name="country2" size="18"></td><td align="center"><button class="btn" name="cmd" value="COUNTRY_DELETE" onclick="return confirm(\'선택한 국가를 삭제합니다. 계속합니까?\')">결정</button></form></td></tr>';
    echo '<tr><th colspan="3">그 외의 정보</th></tr>';
    echo '<tr><td align="center" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'">무기소재정보</td><td><form method="post" action="mainte.php" style="margin:0"><input type="hidden" name="pass" value="'.$pass.'"><select class="inp"><option>전체 무기</option></select> 무기ID 직접입력 : <input class="inp" name="weapon_id" size="18"></td><td align="center"><button class="btn" name="cmd" value="WEAPON">결정</button></form></td></tr>';
    echo '<tr><td align="center" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'">암호변경</td><td>패스워드 암호화된 것을 알려줍니다.(플레이어 삭제용)</td><td align="center"><form method="post" action="'.$scriptH.'" style="margin:0"><input type="hidden" name="pass" value="'.$pass.'"><button class="btn" name="cmd" value="COOKIES">결정</button></form></td></tr>';
    echo '<tr><td align="center" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'">로그인 한사람의 IP보기</td><td>로그인한 사람의 IP를 표시합니다. <select class="inp"><option>IP순서</option></select></td><td align="center"><form method="post" action="'.$scriptH.'" style="margin:0"><input type="hidden" name="pass" value="'.$pass.'"><button class="btn" name="cmd" value="MAINTE_LOG">결정</button></form></td></tr>';
    echo '<tr><td align="center" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'">역사 조작</td><td><select class="inp"><option>--역사작성의 경우는 이대로--</option></select></td><td align="center"><form method="post" action="'.$scriptH.'" style="margin:0"><input type="hidden" name="pass" value="'.$pass.'"><button class="btn" name="cmd" value="HISTORY_EDIT">결정</button></form></td></tr>';
    echo '<tr><td align="center" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'">업데이트 작성</td><td><select class="inp"><option>--업데이트 작성의 경우는 이대로--</option></select></td><td align="center"><form method="post" action="'.$scriptH.'" style="margin:0"><input type="hidden" name="pass" value="'.$pass.'"><button class="btn" name="cmd" value="UPDATE_EDIT">결정</button></form></td></tr>';
    echo '<tr><td align="center" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'">접속해석</td><td>이 스크립트를 접속 IP를 열람합니다.</td><td align="center"><form method="post" action="'.$scriptH.'" style="margin:0"><input type="hidden" name="pass" value="'.$pass.'"><button class="btn" name="cmd" value="MAINTE_LOG">결정</button></form></td></tr>';
    echo '<tr><td align="center" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'">데이터 재구축</td><td>플레이어 데이터의 중복/깨짐/락 파일을 검사하고 자동수리합니다.</td><td align="center"><form method="post" action="'.$scriptH.'" style="margin:0"><input type="hidden" name="pass" value="'.$pass.'"><button class="btn" name="cmd" value="USER_REPAIR">결정</button></form></td></tr>';
    echo '</table>';
    echo '<p style="text-align:center">';
    ebs_admin_nav_form('mainte.php', 'WEAPON', '무기 관리창');
    ebs_admin_nav_form('mainte.php', 'BOUGU_DATA', '보강장비 관리창');
    ebs_admin_nav_form('d_mainte.php', 'MAINTE', '지하감옥 관리창');
    ebs_admin_nav_form('d_config.php', 'TOP', '던전 설정 관리');
    ebs_admin_nav_form('maintenance.php', 'CONFIG_EDIT', '운영 설정 관리');
    ebs_admin_nav_form('maintenance.php', 'NOTICE', '공지/이벤트 설정');
    ebs_admin_nav_form('maintenance.php', 'HISTORY_EDIT', '역사 편찬');
    ebs_admin_nav_form('maintenance.php', 'UPDATE_EDIT', '업데이트 작성');
    ebs_admin_nav_form('maintenance.php', 'USER_REPAIR', '유저 데이터 점검/수리');
    echo '</p><div style="text-align:center;font-size:12px">메인터넌스 스크립트</div>';
    ebs_admin_footer();
}

/** 참가자 목록/수정 폼. 원본 MASTER/SYUSEI/TYOUSEI 계열 대응. */
function ebs_admin_players(string $script='editadmin.php'): void {
    ebs_bootstrap_players_from_backup();
    $players = ebs_players_load();
    $pass = ebs_h(ebs_admin_pass_value());
    ebs_admin_header('플레이어 데이터 일람');
    echo '<form method="post" action="'.ebs_h($script).'" style="margin:0"><input type="hidden" name="pass" value="'.$pass.'">';
    echo '<table class="tbl"><tr><th colspan="12">플레이어 데이터 선택</th></tr>';
    echo '<tr><td colspan="12">선택 : <select class="inp" name="plname">'.ebs_admin_player_select_options($players).'</select> 직접입력 : <input class="inp" name="plname2" size="18"> <button class="btn" name="cmd" value="PLAYER_EDIT">데이터수정</button> <button class="btn" name="cmd" value="DEL">삭제</button></td></tr>';
    echo '<tr><th>선택</th><th>파일럿</th><th>기체명</th><th>계급</th><th>작위</th><th>성격</th><th>공헌</th><th>Level</th><th>HP</th><th>EN</th><th>Gold</th><th>무기</th></tr>';
    foreach ($players as $key=>$p) {
        if (!is_array($p)) continue;
        $name=(string)($p['name'] ?? $key);
        echo '<tr><td><input type="radio" name="plname" value="'.ebs_h($name).'"></td><td>'.ebs_h($name).'</td><td>'.ebs_h((string)($p['msname'] ?? '')).'</td><td>'.ebs_player_rank_label($p).'</td><td>'.ebs_h(ebs_player_class_label($p)).'</td><td>'.ebs_h(ebs_chara_label((string)($p['chara'] ?? ebs_player_raw_get($p,12,'0')))).'</td><td align="right">'.number_format(ebs_player_contrib_value($p)).'</td><td align="right">'.ebs_h((string)($p['level'] ?? '1')).'</td><td>'.ebs_h((string)($p['hp'] ?? '0')).'/'.ebs_h((string)($p['max_hp'] ?? '0')).'</td><td>'.ebs_h((string)($p['en'] ?? '0')).'/'.ebs_h((string)($p['max_en'] ?? '0')).'</td><td align="right">'.ebs_h(number_format((int)($p['money'] ?? ($p['gold'] ?? '0')))).'</td><td>'.ebs_h((string)($p['weapon'] ?? '')).'</td></tr>';
    }
    echo '</table></form>';
    echo '<p>'; ebs_admin_nav_form($script, 'MAINTE2', '관리 메뉴'); echo '</p>';
    ebs_admin_footer();
}
function ebs_admin_player_raw_labels(): array {
    return [0=>'계급',1=>'전투력',2=>'패스워드',3=>'기체명',4=>'기체타입',5=>'국가명',6=>'직위/작위값',7=>'발언',8=>'돈',9=>'장비중 무기',10=>'예비1',11=>'예비2',12=>'성격',13=>'문자색',14=>'무기경험치',15=>'HP',16=>'최대HP',17=>'EN',18=>'최대EN',19=>'공격',20=>'방어',21=>'속도',22=>'명중',23=>'기체특수',24=>'숙련도',25=>'수리상태',26=>'액세스시간',27=>'아이콘번호',28=>'소속부대',29=>'레벨',30=>'경험치',31=>'예비',32=>'보강장비',33=>'보강예비',34=>'전투대사',35=>'킬수',36=>'요새격추',37=>'랜덤값',38=>'기체색',39=>'승리대사',40=>'패배대사',41=>'승',42=>'패',43=>'공헌도',72=>'금괴',73=>'경험치프리',75=>'전체프리'];
}
function ebs_admin_player_edit_screen(string $script='editadmin.php', string $name='', string $message=''): void {
    ebs_bootstrap_players_from_backup();
    $players = ebs_players_load();
    if ($name === '') $name = ebs_param('plname2', '') !== '' ? ebs_param('plname2', '') : ebs_param('plname', '');
    $key = ebs_find_player_key($name, $players);
    if ($key === null || !isset($players[$key]) || !is_array($players[$key])) { ebs_admin_players($script); return; }
    $p = $players[$key];
    ebs_player_normalize_legacy_fields($p);
    $raw = isset($p['raw_values']) && is_array($p['raw_values']) ? array_values($p['raw_values']) : [];
    for ($i=0; $i<=80; $i++) if (!array_key_exists($i, $raw)) $raw[$i]='';
    $labels = ebs_admin_player_raw_labels();
    $pass = ebs_h(ebs_admin_pass_value());
    ebs_admin_header('플레이어 데이터 변경 화면');
    echo '<form method="post" action="'.ebs_h($script).'" style="margin:0"><input type="hidden" name="pass" value="'.$pass.'"><input type="hidden" name="cmd" value="TYOUSEI"><input type="hidden" name="plname" value="'.ebs_h((string)($p['name'] ?? $key)).'">';
    echo '<table class="tbl" style="max-width:860px;margin:0 auto"><tr><th colspan="3">플레이어 데이터 변경 화면</th></tr>';
    if ($message !== '') echo '<tr><td colspan="3" align="center" class="ok">'.ebs_h($message).'</td></tr>';
    echo '<tr><td>플레이어명</td><td>'.ebs_h((string)($p['name'] ?? $key)).'</td><td><input class="inp" name="new_name" value="'.ebs_h((string)($p['name'] ?? $key)).'" size="24"></td></tr>';
    echo '<tr><td colspan="3">계급 '.ebs_player_rank_label($p).' / 작위 '.ebs_h(ebs_player_class_label($p)).' / 성격 '.ebs_h(ebs_chara_label((string)($p['chara'] ?? ebs_player_raw_get($p,12,'0')))).' / 공헌도 '.number_format(ebs_player_contrib_value($p)).'</td></tr>';
    foreach ($raw as $i=>$v) {
        if ($i > 80 && $v === '') continue;
        $label = $labels[$i] ?? '';
        echo '<tr><td width="74">['.(int)$i.'] '.ebs_h($label).'</td><td style="max-width:280px;overflow:hidden;white-space:nowrap">'.ebs_h((string)$v).'</td><td><input class="inp" name="raw['.(int)$i.']" value="'.ebs_h((string)$v).'" style="width:96%"></td></tr>';
    }
    echo '<tr><td colspan="3" align="center"><button class="btn" type="submit">변경</button></td></tr></table></form>';
    echo '<p style="text-align:center">'; ebs_admin_nav_form($script, 'MASTER', '플레이어 일람'); ebs_admin_nav_form($script, 'MAINTE2', '관리 메뉴'); echo '</p>';
    ebs_admin_footer();
}

/** 참가자 수정/삭제 처리. */
function ebs_admin_update_player(): void {
    $players = ebs_players_load();
    $name = ebs_param('plname2', '') !== '' ? ebs_param('plname2', '') : ebs_param('plname');
    $key = ebs_find_player_key($name, $players);
    if ($key === null) { ebs_error_page('Error', '지정한 참가자 데이터를 찾을 수 없습니다.'); return; }
    $changed = false;
    if (isset($_POST['raw']) && is_array($_POST['raw'])) {
        $raw = [];
        foreach ($_POST['raw'] as $idx=>$val) {
            $idx = (int)$idx;
            if ($idx < 0) continue;
            while (count($raw) <= $idx) $raw[] = '';
            $raw[$idx] = is_scalar($val) ? (string)$val : '';
        }
        $players[$key]['raw_values'] = $raw;
        $players[$key]['raw_original_shape'] = implode(' ', array_map('strval', $raw));
        ebs_player_apply_admin_raw_values($players[$key]);
        ebs_player_normalize_legacy_fields($players[$key]);
        ebs_player_sync_common($players[$key]);
        $newName = ebs_clean_registration_name(ebs_param('new_name', (string)($players[$key]['name'] ?? $key)));
        if ($newName !== '' && $newName !== (string)($players[$key]['name'] ?? $key)) {
            $oldName = (string)($players[$key]['name'] ?? $key);
            $players[$key]['name'] = $newName;
            ebs_player_delete_one($oldName);
            $newKey = $newName;
            $players[$newKey] = $players[$key];
            if ($newKey !== $key) unset($players[$key]);
            $key = $newKey;
        }
        $changed = true;
    } else {
        foreach (['level','hp','en','money','max_hp','max_en','kuni','weapon','msname','contrib','job','chara'] as $field) {
            $v = ebs_param($field, '');
            if ($v !== '') { $players[$key][$field] = is_numeric($v) ? (int)$v : $v; $changed = true; }
        }
        if ($changed) ebs_player_sync_common($players[$key]);
    }
    if (!$changed) { ebs_admin_player_edit_screen(ebs_admin_script_name(), (string)($players[$key]['name'] ?? $key)); return; }
    $players[$key]['last_admin_update'] = date('Y-m-d H:i:s');
    ebs_players_save($players);
    ebs_admin_audit('PLAYER_SAVE', '참가자 데이터 수정: '.(string)($players[$key]['name'] ?? $key));
    ebs_admin_player_edit_screen(ebs_admin_script_name(), (string)($players[$key]['name'] ?? $key), '플레이어 정보를 변경했습니다.');
}
function ebs_admin_delete_player(): void {
    $players = ebs_players_load();
    $name = ebs_param('plname2', '') !== '' ? ebs_param('plname2', '') : ebs_param('plname');
    $key = ebs_find_player_key($name, $players);
    if ($key !== null) {
        ebs_player_delete_one((string)($players[$key]['name'] ?? $key));
        unset($players[$key]);
        ebs_admin_audit('PLAYER_DELETE', '참가자 삭제: '.$name);
    }
    ebs_admin_players(ebs_admin_script_name());
}
/** 국가 데이터 조정. 원본 COUNTRY/HENSYU/KAIZAN 계열 대응. */
function ebs_admin_country_param_name(): string {
    $name = ebs_param('country2', '');
    if ($name === '') $name = ebs_param('country', '');
    return trim($name);
}
function ebs_admin_country_field_labels(): array {
    return [
        0=>'국가색', 1=>'국비', 2=>'부대명1', 3=>'부대명2', 4=>'부대명3',
        5=>'작전명', 6=>'주공', 7=>'작전 종료시각', 8=>'부대1 목표', 9=>'부대2 목표', 10=>'부대3 목표',
        11=>'요새 HP/최대HP/시각', 12=>'요새 능력 AT/DE/SP/명칭', 13=>'문장', 14=>'최대국민수'
    ];
}
function ebs_admin_country_detail_rows(string $name, array $parts): string {
    $labels = ebs_admin_country_field_labels();
    $html = '<table class="tbl" style="max-width:760px;margin:8px auto"><tr><th colspan="3">국가 상세 수정 - '.ebs_h($name).'</th></tr>';
    $html .= '<tr><td>국가명</td><td>'.ebs_h($name).'</td><td><input class="inp" name="new_country" value="'.ebs_h($name).'" style="width:96%"></td></tr>';
    for ($i=0; $i<=14; $i++) {
        $v = (string)($parts[$i] ?? '');
        $html .= '<tr><td width="150">['.$i.'] '.ebs_h($labels[$i] ?? '').'</td><td style="max-width:250px;overflow:hidden;white-space:nowrap">'.ebs_h($v).'</td><td><input class="inp" name="parts['.$i.']" value="'.ebs_h($v).'" style="width:96%"></td></tr>';
    }
    $html .= '<tr><td colspan="3" align="center"><button class="btn" type="submit">국가 데이터 변경</button></td></tr></table>';
    return $html;
}
function ebs_admin_countries(string $script='editadmin.php', string $message=''): void {
    $raw = ebs_json_load('countrydata');
    $countries = ebs_country_records();
    $selected = ebs_admin_country_param_name();
    $selectedKey = $selected !== '' ? ebs_country_find_raw_key($selected, $raw) : null;
    $pass = ebs_h(ebs_admin_pass_value());
    ebs_admin_header('국가 데이터 조정');
    if ($message !== '') echo '<p class="ok" style="text-align:center">'.ebs_h($message).'</p>';

    echo '<form method="post" action="'.ebs_h($script).'" style="margin:0"><input type="hidden" name="pass" value="'.$pass.'">';
    echo '<table class="tbl"><tr><th>선택</th><th>국가명</th><th>색</th><th>국비</th><th>부대</th><th>작전</th><th>요새</th><th>문장</th><th>최대국민수</th></tr>';
    foreach ($countries as $name=>$c) {
        $checked = ((string)$name === $selected) ? ' checked' : '';
        $units = implode(' / ', $c['units']);
        echo '<tr><td align="center"><input type="radio" name="country" value="'.ebs_h((string)$name).'"'.$checked.'></td><td>'.ebs_h((string)$name).'</td>';
        echo '<td>'.ebs_h((string)$c['color']).'</td><td align="right">'.ebs_h(number_format((int)$c['money'])).'</td><td>'.ebs_h($units).'</td><td>'.ebs_h((string)$c['mission_name']).'</td>';
        echo '<td>'.ebs_h((string)$c['fortress']).'</td><td>'.ebs_h((string)$c['icon']).'</td><td>'.ebs_h((string)$c['max_member']).'</td></tr>';
    }
    if (!$countries) echo '<tr><td colspan="9" align="center">등록된 국가 데이터가 없습니다.</td></tr>';
    echo '</table>';
    echo '<p style="text-align:center">나라명 직접 입력 : <input class="inp" name="country2" size="18"> ';
    echo '<button class="btn" name="cmd" value="COUNTRY_EDIT">선택/입력 국가 수정</button> ';
    echo '<button class="btn" name="cmd" value="COUNTRY_DELETE" onclick="return confirm(\'선택한 국가를 삭제합니다. 계속합니까?\')">선택/입력 국가 삭제</button></p>';
    echo '</form>';

    if ($selectedKey !== null && isset($raw[$selectedKey])) {
        $parts = ebs_country_raw_parts((string)$raw[$selectedKey]);
        echo '<form method="post" action="'.ebs_h($script).'" style="margin:0"><input type="hidden" name="pass" value="'.$pass.'"><input type="hidden" name="cmd" value="KAIZAN"><input type="hidden" name="country" value="'.ebs_h($selected).'">';
        echo ebs_admin_country_detail_rows($selected, $parts);
        echo '</form>';
    }

    echo '<form method="post" action="'.ebs_h($script).'" style="margin:0">';
    echo '<input type="hidden" name="pass" value="'.$pass.'"><input type="hidden" name="cmd" value="COUNTRY_CREATE">';
    echo '<table class="tbl" style="max-width:760px;margin:8px auto"><tr><th colspan="4">신규 국가 작성</th></tr>';
    echo '<tr><td>국가명</td><td><input class="inp" name="new_country" size="20"></td><td>국가색</td><td><input class="inp" name="parts[0]" value="#808080" size="10"></td></tr>';
    echo '<tr><td>국비</td><td><input class="inp" name="parts[1]" value="0" size="12"></td><td>문장</td><td><input class="inp" name="parts[13]" value="1000" size="8"></td></tr>';
    echo '<tr><td>최대국민수</td><td><input class="inp" name="parts[14]" value="'.ebs_h(ebs_v('C_MAX_MEMBER','40')).'" size="8"></td><td colspan="2" align="center"><button class="btn" type="submit">신규 국가 작성</button></td></tr>';
    echo '</table></form>';

    echo '<p style="text-align:center">';
    ebs_admin_nav_form($script, 'MAINTE2', '관리 메뉴');
    echo '</p>';
    ebs_admin_footer();
}
function ebs_admin_update_country(): void {
    $name = ebs_admin_country_param_name();
    $raw = ebs_json_load('countrydata');
    if ($name === '') { ebs_admin_countries(ebs_admin_script_name(), '수정할 국가를 선택하거나 직접 입력하십시오.'); return; }
    $target = ebs_country_find_raw_key($name, $raw);
    if ($target === null) { ebs_error_page('Error', '지정한 국가 데이터를 찾을 수 없습니다.'); return; }
    $parts = ebs_country_raw_parts((string)$raw[$target]);
    if (isset($_POST['parts']) && is_array($_POST['parts'])) {
        foreach ($_POST['parts'] as $idx=>$val) {
            $idx = (int)$idx;
            if ($idx < 0 || $idx > 14) continue;
            while (count($parts) <= $idx) $parts[] = '';
            $parts[$idx] = is_scalar($val) ? trim((string)$val) : '';
        }
    } else {
        $hash = md5($name);
        if (($color=ebs_param('color_'.$hash, '')) !== '') $parts[0] = $color;
        if (($m=ebs_param('money')) !== '') $parts[1] = preg_replace('/[^0-9]/', '', $m) ?: '0';
        if (($icon=ebs_param('icon')) !== '') $parts[13] = ebs_normalize_icon($icon, '1000');
        if (($mm=ebs_param('max_member')) !== '') $parts[14] = (string)max(1, (int)$mm);
    }
    $parts[0] = preg_match('/^#[0-9a-fA-F]{3,6}$/', (string)$parts[0]) ? (string)$parts[0] : '#808080';
    $parts[1] = preg_replace('/[^0-9]/', '', (string)$parts[1]) ?: '0';
    $parts[13] = ebs_normalize_icon((string)($parts[13] ?? '1000'), '1000');
    $parts[14] = (string)max(1, (int)($parts[14] ?? ebs_v('C_MAX_MEMBER','40')));
    $newName = trim(ebs_param('new_country', $name));
    if ($newName === '') $newName = $name;
    $newKey = $newName === $name ? $target : ebs_encode_data_name($newName);
    if ($newKey === '') $newKey = $target;
    if ($newKey !== $target && isset($raw[$newKey])) { ebs_error_page('Error', '동명의 국가 데이터가 이미 존재합니다.'); return; }
    unset($raw[$target]);
    $raw[$newKey] = ebs_country_raw_string($parts);
    ebs_json_save('countrydata', $raw);
    if ($newName !== $name) {
        $players = ebs_players_load();
        foreach ($players as $pkey=>$p) {
            if (!is_array($p)) continue;
            if ((string)($p['kuni'] ?? ebs_player_raw_get($p, 5, '')) === $name) {
                $players[$pkey]['kuni'] = $newName;
                ebs_player_raw_set($players[$pkey], 5, $newName);
                ebs_player_sync_common($players[$pkey]);
            }
        }
        ebs_players_save($players);
    }
    ebs_admin_audit('COUNTRY_SAVE', '국가 데이터 수정: '.$name);
    $_POST['country'] = $newName;
    $_POST['country2'] = '';
    ebs_admin_countries(ebs_admin_script_name(), '국가 데이터를 변경했습니다.');
}
function ebs_admin_create_country(): void {
    $name = trim(ebs_param('new_country', ''));
    if ($name === '') { ebs_admin_countries(ebs_admin_script_name(), '신규 국가명을 입력하십시오.'); return; }
    $raw = ebs_json_load('countrydata');
    if (ebs_country_find_raw_key($name, $raw) !== null) { ebs_error_page('Error', '동명의 국가 데이터가 이미 존재합니다.'); return; }
    $parts = array_fill(0, 15, '');
    if (isset($_POST['parts']) && is_array($_POST['parts'])) {
        foreach ($_POST['parts'] as $idx=>$val) {
            $idx = (int)$idx;
            if ($idx < 0 || $idx > 14) continue;
            $parts[$idx] = is_scalar($val) ? trim((string)$val) : '';
        }
    }
    $parts[0] = preg_match('/^#[0-9a-fA-F]{3,6}$/', (string)($parts[0] ?? '')) ? (string)$parts[0] : '#808080';
    $parts[1] = preg_replace('/[^0-9]/', '', (string)($parts[1] ?? '0')) ?: '0';
    $parts[11] = (string)($parts[11] ?? '600000!600000!'.time());
    $parts[12] = (string)($parts[12] ?? '1!1!1!'.$name);
    $parts[13] = ebs_normalize_icon((string)($parts[13] ?? '1000'), '1000');
    $parts[14] = (string)max(1, (int)($parts[14] ?? ebs_v('C_MAX_MEMBER','40')));
    $key = ebs_encode_data_name($name);
    if ($key === '') { ebs_admin_countries(ebs_admin_script_name(), '국가명을 저장할 수 없습니다.'); return; }
    $raw[$key] = ebs_country_raw_string($parts);
    ebs_json_save('countrydata', $raw);
    ebs_admin_audit('COUNTRY_CREATE', '국가 생성: '.$name);
    $_POST['country'] = $name;
    $_POST['country2'] = '';
    ebs_admin_countries(ebs_admin_script_name(), '신규 국가를 작성했습니다.');
}
function ebs_admin_delete_country(): void {
    $name = ebs_admin_country_param_name();
    $raw = ebs_json_load('countrydata');
    if ($name === '') { ebs_admin_countries(ebs_admin_script_name(), '삭제할 국가를 선택하거나 직접 입력하십시오.'); return; }
    $target = ebs_country_find_raw_key($name, $raw);
    if ($target === null) { ebs_error_page('Error', '지정한 국가 데이터를 찾을 수 없습니다.'); return; }
    unset($raw[$target]);
    ebs_json_save('countrydata', $raw);
    $players = ebs_players_load();
    foreach ($players as $pkey=>$p) {
        if (!is_array($p)) continue;
        if ((string)($p['kuni'] ?? ebs_player_raw_get($p, 5, '')) === $name) {
            $players[$pkey]['kuni'] = '';
            $players[$pkey]['job'] = '0';
            if (isset($players[$pkey]['unit'])) $players[$pkey]['unit'] = '';
            ebs_player_raw_set($players[$pkey], 5, '');
            ebs_player_raw_set($players[$pkey], 6, '0');
            ebs_player_raw_set($players[$pkey], 28, '');
            ebs_player_sync_common($players[$pkey]);
        }
    }
    ebs_players_save($players);
    ebs_admin_audit('COUNTRY_DELETE', '국가 삭제: '.$name);
    ebs_admin_countries(ebs_admin_script_name(), '국가 데이터를 삭제했습니다.');
}

/** 관리자 로그 화면. */
function ebs_admin_log_screen(string $script='maintenance.php'): void {
    $pass = ebs_h(ebs_admin_pass_value());
    ebs_admin_header('관리 로그');
    echo '<p>';
    ebs_admin_nav_form($script, 'MAINTE2', '관리 메뉴');
    echo '</p>';
    $logs = [];
    $adminHistory = ebs_json_load('admin_history');
    if (is_array($adminHistory)) {
        foreach ($adminHistory as $row) {
            if (is_array($row)) $logs[] = ['time'=>(string)($row['time'] ?? ''), 'type'=>'관리', 'name'=>(string)($row['name'] ?? ''), 'body'=>(string)($row['body'] ?? json_encode($row, JSON_UNESCAPED_UNICODE))];
        }
    }
    foreach (ebs_players_load() as $key=>$p) {
        if (!is_array($p) || empty($p['event_log']) || !is_array($p['event_log'])) continue;
        foreach ($p['event_log'] as $row) {
            if (!is_array($row)) continue;
            $logs[] = ['time'=>(string)($row['time'] ?? ''), 'type'=>(string)($row['type'] ?? 'event'), 'name'=>(string)($p['name'] ?? $key), 'body'=>(string)($row['message'] ?? $row['scope'] ?? $row['body'] ?? '')];
        }
    }
    usort($logs, static function($a,$b){ return strcmp((string)($b['time'] ?? ''), (string)($a['time'] ?? '')); });
    echo '<table class="tbl"><tr><th>일시</th><th>구분</th><th>대상</th><th>내용</th></tr>';
    foreach (array_slice($logs,0,200) as $row) {
        echo '<tr><td>'.ebs_h((string)$row['time']).'</td><td>'.ebs_h((string)$row['type']).'</td><td>'.ebs_h((string)$row['name']).'</td><td>'.ebs_h((string)$row['body']).'</td></tr>';
    }
    if (!$logs) echo '<tr><td colspan="4" align="center">관리 로그가 없습니다.</td></tr>';
    echo '</table>';
    ebs_admin_footer();
}

/** 백업/복원/로그 관리. */
function ebs_admin_user_repair_screen(string $script='editadmin.php', string $message=''): void {
    $pass = ebs_h(ebs_admin_pass_value());
    $summary = ebs_user_storage_repair(false, false);
    ebs_admin_header('유저 데이터 점검/수리');
    if ($message !== '') echo '<p style="color:#ffff66">'.ebs_h($message).'</p>';
    echo '<table class="tbl"><tr><th>항목</th><th>건수</th></tr>';
    $labels = ['scanned'=>'검사한 JSON 파일', 'players'=>'실제 유저 수', 'fixed'=>'수리 필요 유저', 'duplicates'=>'중복/잔존 파일', 'renamed'=>'파일명 정규화 필요', 'invalid_json'=>'깨진 JSON 파일', 'invalid_name'=>'이름 오류 파일', 'locks_removed'=>'삭제 가능한 기존 lock', 'quarantined'=>'격리 파일'];
    foreach ($labels as $key=>$label) echo '<tr><td>'.ebs_h($label).'</td><td>'.number_format((int)($summary[$key] ?? 0)).'</td></tr>';
    echo '</table>';
    echo '<p>점검 대상: user/*.json 파일명, 중복 캐릭터 파일, 잘못된 무기/예비무기/창고무기, HP/EN/레벨/경험치/금액 범위값, 기존 sidecar .lock 파일.</p>';
    echo '<form method="post" action="'.ebs_h($script).'" style="margin:10px 0"><input type="hidden" name="pass" value="'.$pass.'"><button class="btn" name="cmd" value="USER_REPAIR_RUN">자동수리 실행</button></form>';
    if (!empty($summary['messages']) && is_array($summary['messages'])) {
        echo '<table class="tbl"><tr><th>수리 예정 내역</th></tr>';
        foreach (array_slice($summary['messages'], 0, 200) as $msg) echo '<tr><td>'.ebs_h((string)$msg).'</td></tr>';
        if (count($summary['messages']) > 200) echo '<tr><td>... '.number_format(count($summary['messages'])-200).'건 추가</td></tr>';
        echo '</table>';
    }
    echo '<p>'; ebs_admin_nav_form($script, 'MAINTE2', '관리 메뉴'); echo '</p>';
    ebs_admin_footer();
}
function ebs_admin_user_repair_run(): void {
    $script = ebs_admin_script_name();
    $summary = ebs_user_storage_repair(true, false);
    ebs_admin_audit('USER_REPAIR', '유저 데이터 수리: fixed='.(int)($summary['fixed'] ?? 0).', duplicates='.(int)($summary['duplicates'] ?? 0).', locks='.(int)($summary['locks_removed'] ?? 0));
    ebs_admin_user_repair_screen($script, '자동수리를 완료했습니다. 수리 '.number_format((int)($summary['fixed'] ?? 0)).'건 / 중복 제거 '.number_format((int)($summary['duplicates'] ?? 0)).'건 / lock 정리 '.number_format((int)($summary['locks_removed'] ?? 0)).'건');
}

function ebs_admin_backup_screen(string $script='editadmin.php'): void {
    $pass = ebs_h(ebs_admin_pass_value());
    ebs_admin_header('데이터 백업/복원');
    echo '<form method="post" action="'.ebs_h($script).'"><input type="hidden" name="pass" value="'.$pass.'"><button class="btn" name="cmd" value="BACKUP_RUN">전체 데이터 백업 생성</button> <button class="btn" name="cmd" value="DATAUP_RUN" onclick="return confirm(\'최근 백업으로 복원합니다. 현재 데이터가 덮어써질 수 있습니다.\')">최근 백업 복원</button></form>';
    $files = glob(ebs_file('data/admin_backup_*.json')) ?: [];
    rsort($files);
    echo '<table class="tbl"><tr><th>백업파일</th><th>크기</th><th>생성시각</th></tr>';
    foreach (array_slice($files,0,20) as $f) echo '<tr><td>'.ebs_h(basename($f)).'</td><td>'.number_format((int)filesize($f)).'</td><td>'.date('Y-m-d H:i:s', (int)filemtime($f)).'</td></tr>';
    if (!$files) echo '<tr><td colspan="3" align="center">백업 파일이 없습니다.</td></tr>';
    echo '</table><p>백업 대상: user/*.json, data/*.json, 관리자 config_override, 보드, 보강장비, 무기, 국가 데이터. .lock/.tmp 파일은 제외됩니다.</p><p>'; ebs_admin_nav_form($script, 'MAINTE2', '관리 메뉴'); echo '</p>';
    ebs_admin_footer();
}
function ebs_admin_backup_collect_data(): array {
    $data = [];
    $dir = ebs_file('data');
    foreach ((glob($dir.'/*.json') ?: []) as $f) {
        $base = basename($f);
        if (str_starts_with($base, 'admin_backup_')) continue;
        $raw = file_get_contents($f);
        $data[$base] = is_string($raw) ? $raw : '';
    }
    ksort($data, SORT_STRING);
    return $data;
}
function ebs_admin_backup_run(): void {
    $payload = [
        'created_at'=>date('c'),
        'players'=>ebs_players_load(),
        'data_json'=>ebs_admin_backup_collect_data(),
    ];
    $stamp = date('Ymd_His');
    ebs_write('data/admin_backup_'.$stamp.'.json', json_encode($payload, JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT));
    ebs_admin_audit('BACKUP_RUN', '전체 데이터 백업 생성: admin_backup_'.$stamp.'.json');
    ebs_admin_backup_screen(ebs_admin_script_name());
}
function ebs_admin_restore_run(): void {
    $files = glob(ebs_file('data/admin_backup_*.json')) ?: [];
    rsort($files);
    if ($files) {
        $j = ebs_json_decode_array((string)file_get_contents($files[0]));
        if ($j) {
            if (isset($j['players']) && is_array($j['players'])) ebs_players_replace_all($j['players']);
            if (isset($j['data_json']) && is_array($j['data_json'])) {
                foreach ($j['data_json'] as $base=>$raw) {
                    if (!is_string($base) || !preg_match('/^[A-Za-z0-9_\-]+\.json$/', $base) || str_starts_with($base, 'admin_backup_')) continue;
                    if (is_string($raw)) ebs_write('data/'.$base, $raw);
                }
            } else {
                if (isset($j['countrydata']) && is_array($j['countrydata'])) ebs_json_save('countrydata', $j['countrydata']);
                if (isset($j['weapons']) && is_array($j['weapons'])) ebs_json_save('weapons', $j['weapons']);
            }
            ebs_admin_audit('DATAUP_RUN', '최근 백업 복원: '.basename($files[0]));
        }
    }
    ebs_admin_backup_screen(ebs_admin_script_name());
}

function ebs_admin_cookies_screen(string $script='editadmin.php'): void {
    $pass=ebs_h(ebs_admin_pass_value());
    ebs_admin_header('쿠키/삭제기한 확인');
    echo '<table class="tbl"><tr><th>항목</th><th>값</th></tr><tr><td>COOKIE_KEEP</td><td>'.ebs_h(ebs_v('COOKIE_KEEP')).'</td></tr><tr><td>ENTRY_MAX</td><td>'.ebs_h(ebs_v('ENTRY_MAX')).'</td></tr><tr><td>현재 등록수</td><td>'.count(ebs_players_load()).'</td></tr></table>';
    echo '<p>'; ebs_admin_nav_form($script, 'MAINTE2', '관리 메뉴'); echo '</p>';
    ebs_admin_footer();
}

/** 던전 맵 데이터. 원본 d_mainte.cgi의 층별 10x10 맵 편집 구조를 PHP 파일 기반 저장으로 대응한다. */
function ebs_dungeon_config_file(): string { return 'data/dungeon_config.json'; }
function ebs_dungeon_config_defaults(): array {
    return [
        'dungeon'=>['move_rate'=>28,'stay_rate'=>45,'trap_rate'=>65],
        'dungeonss'=>['move_rate'=>28,'stay_rate'=>45,'trap_rate'=>65]
    ];
}
function ebs_dungeon_config_load(): array {
    $defaults = ebs_dungeon_config_defaults();
    $raw = ebs_read(ebs_dungeon_config_file());
    $j = $raw !== '' ? ebs_json_decode_array($raw) : [];
    if (!is_array($j)) $j = [];
    foreach ($defaults as $key=>$vals) {
        if (!isset($j[$key]) || !is_array($j[$key])) $j[$key] = [];
        foreach ($vals as $name=>$default) {
            $v = isset($j[$key][$name]) ? (int)$j[$key][$name] : (int)$default;
            $j[$key][$name] = max(0, min(100, $v));
        }
    }
    return $j;
}
function ebs_dungeon_config_save(array $cfg): bool {
    $defaults = ebs_dungeon_config_defaults();
    $out = [];
    foreach ($defaults as $key=>$vals) {
        $out[$key] = [];
        foreach ($vals as $name=>$default) {
            $v = isset($cfg[$key]) && is_array($cfg[$key]) && isset($cfg[$key][$name]) ? (int)$cfg[$key][$name] : (int)$default;
            $out[$key][$name] = max(0, min(100, $v));
        }
    }
    return ebs_write(ebs_dungeon_config_file(), json_encode($out, JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT));
}
function ebs_dungeon_encounter_rate(string $key, string $move, string $tile): int {
    $cfg = ebs_dungeon_config_load();
    $row = isset($cfg[$key]) && is_array($cfg[$key]) ? $cfg[$key] : [];
    $tile = strtolower(substr($tile, 0, 1));
    if ($tile === 'a') return max(0, min(100, (int)($row['trap_rate'] ?? 65)));
    if ($move === 'stay') return max(0, min(100, (int)($row['stay_rate'] ?? 45)));
    return max(0, min(100, (int)($row['move_rate'] ?? 28)));
}

function ebs_dungeon_map_file(): string { return 'data/dungeon_maps.json'; }
function ebs_dungeon_map_empty_floor(int $floor=1, int $maxFloor=10): array {
    $rows = [];
    for ($y=0; $y<10; $y++) {
        $row = [];
        for ($x=0; $x<10; $x++) $row[] = '5';
        $rows[] = $row;
    }
    $rows[0][0] = ($floor > 1) ? '6' : '8';
    if ($floor < $maxFloor) $rows[9][9] = '7';
    return $rows;
}
function ebs_dungeon_map_normalize_floor($rows, int $floor=1, int $maxFloor=10): array {
    $allowed = array_fill_keys(str_split('0123456789abAB'), true);
    $out = [];
    for ($y=0; $y<10; $y++) {
        $line = [];
        for ($x=0; $x<10; $x++) {
            $v = '5';
            if (is_array($rows) && isset($rows[$y])) {
                if (is_array($rows[$y]) && array_key_exists($x, $rows[$y])) $v = (string)$rows[$y][$x];
                elseif (is_string($rows[$y]) && isset($rows[$y][$x])) $v = $rows[$y][$x];
            }
            $v = substr(trim($v), 0, 1);
            if ($v === '' || !isset($allowed[$v])) $v = '5';
            $line[] = strtolower($v);
        }
        $out[] = $line;
    }
    return $out;
}
function ebs_dungeon_map_load(string $key='dungeon', int $maxFloor=10): array {
    $raw = ebs_read(ebs_dungeon_map_file());
    $j = $raw !== '' ? ebs_json_decode_array($raw) : [];
    if (!is_array($j)) $j = [];
    $src = isset($j[$key]) && is_array($j[$key]) ? $j[$key] : [];
    $maps = [];
    for ($f=1; $f<=max(1,$maxFloor); $f++) {
        $floorKey = (string)$f;
        $maps[$f] = isset($src[$floorKey]) ? ebs_dungeon_map_normalize_floor($src[$floorKey], $f, $maxFloor) : ebs_dungeon_map_empty_floor($f, $maxFloor);
    }
    return $maps;
}
function ebs_dungeon_map_save_all(string $key, array $maps): bool {
    $raw = ebs_read(ebs_dungeon_map_file());
    $j = $raw !== '' ? ebs_json_decode_array($raw) : [];
    if (!is_array($j)) $j = [];
    $pack = [];
    foreach ($maps as $floor=>$rows) {
        $norm = ebs_dungeon_map_normalize_floor($rows, (int)$floor, max(10, count($maps)));
        $pack[(string)(int)$floor] = $norm;
    }
    $j[$key] = $pack;
    return ebs_write(ebs_dungeon_map_file(), json_encode($j, JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT));
}
function ebs_dungeon_map_save_floor(string $key, int $floor, array $rows, int $maxFloor=10): bool {
    $maps = ebs_dungeon_map_load($key, $maxFloor);
    $maps[$floor] = ebs_dungeon_map_normalize_floor($rows, $floor, $maxFloor);
    return ebs_dungeon_map_save_all($key, $maps);
}
function ebs_dungeon_floor_map(array $maps, int $floor): array {
    return isset($maps[$floor]) && is_array($maps[$floor]) ? ebs_dungeon_map_normalize_floor($maps[$floor], $floor, count($maps)) : ebs_dungeon_map_empty_floor($floor, count($maps));
}
function ebs_dungeon_find_start(array $map): array {
    for ($y=0; $y<10; $y++) for ($x=0; $x<10; $x++) if (($map[$y][$x] ?? '') === '8') return [$x,$y];
    for ($y=0; $y<10; $y++) for ($x=0; $x<10; $x++) if (($map[$y][$x] ?? '') !== '') return [$x,$y];
    return [0,0];
}
function ebs_dungeon_tile_allows(string $tile, string $dir): bool {
    $tile = strtolower(substr($tile, 0, 1));
    if ($tile === '1') return $dir === 'up' || $dir === 'down';
    if ($tile === '2' && $dir === 'right') return false;
    if ($tile === '3' && $dir === 'down') return false;
    if ($tile === '4' && $dir === 'left') return false;
    return true;
}
function ebs_dungeon_tile_name(string $tile): string {
    $map = [
        '0'=>'통로', '1'=>'상하통로', '2'=>'오른쪽벽', '3'=>'아래벽', '4'=>'왼쪽벽', '5'=>'사방통로',
        '6'=>'오름계단', '7'=>'내리막계단', '8'=>'시작지점', '9'=>'보상', 'a'=>'트랩', 'b'=>'보스'
    ];
    $k = strtolower(substr($tile, 0, 1));
    return $map[$k] ?? $k;
}
function ebs_admin_dungeon_kind(): string {
    $kind = ebs_param('dungeon_kind', ebs_param('map_key', 'dungeon'));
    return $kind === 'dungeonss' ? 'dungeonss' : 'dungeon';
}
function ebs_admin_dungeon_kind_label(string $kind): string {
    return $kind === 'dungeonss' ? '어둠의 미궁' : '지하감옥';
}
function ebs_admin_dungeon_kind_select(string $selected='dungeon', string $name='dungeon_kind'): string {
    $selected = $selected === 'dungeonss' ? 'dungeonss' : 'dungeon';
    $out = '<select class="inp" name="'.ebs_h($name).'">';
    foreach (['dungeon'=>'지하감옥', 'dungeonss'=>'어둠의 미궁'] as $key=>$label) {
        $out .= '<option value="'.ebs_h($key).'"'.($key===$selected?' selected':'').'>'.ebs_h($label).'</option>';
    }
    return $out.'</select>';
}
function ebs_admin_dungeon_floor_select(int $selected=1, string $name='floor'): string {
    $out = '<select class="inp" name="'.ebs_h($name).'">';
    for ($i=1; $i<=10; $i++) $out .= '<option value="'.$i.'"'.($i===$selected?' selected':'').'>'.$i.'층</option>';
    return $out.'</select>';
}
function ebs_admin_dungeon_screen(string $script='d_mainte.php', string $message=''): void {
    $pass=ebs_h(ebs_admin_pass_value());
    $floor=max(1,min(10,(int)ebs_param('floor','1')));
    $kind=ebs_admin_dungeon_kind();
    ebs_admin_header('지하 감옥 메인터넌스');
    if ($message !== '') echo '<p class="ok">'.ebs_h($message).'</p>';
    echo '<table class="tbl" style="max-width:460px;margin:120px auto 0 auto">';
    echo '<tr><th colspan="3">지하 감옥 메인터넌스 <span style="float:right"><form method="post" action="'.ebs_h($script).'" style="display:inline;margin:0"><input type="hidden" name="pass" value="'.$pass.'"><button class="btn" name="cmd" value="MAINTE">갱신</button></form></span></th></tr>';
    echo '<tr><td width="90" align="center">맵 구성</td><td><form method="post" action="'.ebs_h($script).'" style="margin:0"><input type="hidden" name="pass" value="'.$pass.'">'.ebs_admin_dungeon_kind_select($kind).' '.ebs_admin_dungeon_floor_select($floor).' <span style="font-size:12px">1맵을 작성 혹은 변경합니다.</span></td><td width="48"><button class="btn" name="cmd" value="DUNGEON_EDIT">결정</button></form></td></tr>';
    echo '</table>';
    echo '<p style="text-align:center">';
    ebs_admin_nav_form($script, 'SETUMEI', '설명');
    ebs_admin_nav_form($script, 'MONSTER_DATA', '몬스터 데이터 편집');
    ebs_admin_nav_form('d_config.php', 'TOP', '던전 설정 관리');
    ebs_admin_nav_form('maintenance.php', 'CONFIG_EDIT', '운영 설정 관리');
    ebs_admin_nav_form('maintenance.php', 'MAINTE2', '관리창 돌아가기');
    echo '</p><div style="text-align:center;font-size:12px">지하 감옥 스크립트</div>';
    ebs_admin_footer();
}
function ebs_admin_dungeon_edit_screen(string $script='d_mainte.php', string $message=''): void {
    $pass=ebs_h(ebs_admin_pass_value());
    $floor=max(1,min(10,(int)ebs_param('floor','1')));
    $kind=ebs_admin_dungeon_kind();
    $label=ebs_admin_dungeon_kind_label($kind);
    $maps=ebs_dungeon_map_load($kind, 10);
    $map=ebs_dungeon_floor_map($maps, $floor);
    ebs_admin_header($label.' 편집의 설명');
    if ($message !== '') echo '<p class="ok">'.ebs_h($message).'</p>';
    echo '<table class="tbl" style="max-width:980px;margin:0 auto 8px auto"><tr><th colspan="2">'.ebs_h($label).' 편집의 설명</th></tr><tr><td colspan="2">';
    echo '<a href="#">설명</a>을 보십시오<br>편집의 수치<br>1=상하 통행 2=오른쪽 벽 3=아래 벽 4=왼쪽 벽 5=사방 통행 가능 6=오름 계단 7=내리막 계단 8=스타트 지정 9=보상 a=트랩 b=보스';
    echo '</td></tr></table>';
    echo '<form method="post" action="'.ebs_h($script).'"><input type="hidden" name="pass" value="'.$pass.'"><input type="hidden" name="cmd" value="BUILD"><input type="hidden" name="floor" value="'.$floor.'"><input type="hidden" name="dungeon_kind" value="'.ebs_h($kind).'">';
    echo '<table style="border-collapse:separate;border-spacing:4px;margin-left:40px"><tr><td valign="top">';
    echo '<table class="tbl" style="width:auto"><tr><th colspan="10">'.ebs_h($label).$floor.'층 구성</th></tr>';
    for ($y=0; $y<10; $y++) {
        echo '<tr>';
        for ($x=0; $x<10; $x++) {
            $v=(string)($map[$y][$x] ?? '5');
            $mark = ($v==='8') ? 'S' : (($v==='6') ? '↑' : (($v==='7') ? '↓' : (($v==='a') ? 'T' : (($v==='b') ? 'B' : '&nbsp;'))));
            echo '<td title="'.ebs_h($v.' '.ebs_dungeon_tile_name($v)).'" style="width:20px;height:20px;text-align:center;padding:0;background:#303030">'.$mark.'</td>';
        }
        echo '</tr>';
    }
    echo '</table>';
    echo '</td><td valign="top">';
    echo '<table class="tbl" style="width:auto"><tr><th colspan="10">'.ebs_h($label).$floor.'층 편집</th></tr>';
    for ($y=0; $y<10; $y++) {
        echo '<tr>';
        for ($x=0; $x<10; $x++) {
            $v=ebs_h((string)($map[$y][$x] ?? '5'));
            echo '<td style="padding:1px"><input class="inp" name="cell['.$y.']['.$x.']" value="'.$v.'" maxlength="1" style="width:24px;height:18px;text-align:center;padding:0"></td>';
        }
        echo '</tr>';
    }
    echo '<tr><td colspan="10" align="center"><button class="btn" type="submit">편집</button></td></tr></table>';
    echo '</td></tr></table></form>';
    echo '<p style="margin-left:40px">귀환 '; 
    echo '<form method="post" action="'.ebs_h($script).'" style="display:inline"><input type="hidden" name="pass" value="'.$pass.'">'.ebs_admin_dungeon_kind_select($kind).' '.ebs_admin_dungeon_floor_select($floor).' <button class="btn" name="cmd" value="DUNGEON_EDIT">결정</button></form> ';
    ebs_admin_nav_form($script, 'MAINTE', '메뉴');
    ebs_admin_nav_form('d_config.php', 'TOP', '던전 설정 관리');
    ebs_admin_nav_form('maintenance.php', 'MAINTE2', '관리창 돌아가기');
    echo '</p><div style="text-align:center;font-size:12px">지하 감옥 스크립트</div>';
    ebs_admin_footer();
}
function ebs_admin_dungeon_save(): void {
    $floor=max(1,min(10,(int)ebs_param('floor','1')));
    $kind=ebs_admin_dungeon_kind();
    $rows=[];
    $cell = $_POST['cell'] ?? [];
    for ($y=0; $y<10; $y++) {
        $rows[$y]=[];
        for ($x=0; $x<10; $x++) $rows[$y][$x] = is_array($cell) && isset($cell[$y]) && is_array($cell[$y]) && isset($cell[$y][$x]) ? (string)$cell[$y][$x] : '5';
    }
    ebs_dungeon_map_save_floor($kind, $floor, $rows, 10);
    ebs_admin_audit('DUNGEON_MAP_SAVE', ebs_admin_dungeon_kind_label($kind).' '.$floor.'층 맵 저장');
    ebs_admin_dungeon_edit_screen(ebs_admin_script_name('d_mainte.php'), $floor.'층 맵을 저장했습니다.');
}
function ebs_admin_dungeon_help_screen(string $script='d_mainte.php'): void {
    ebs_admin_header('지하감옥 편집의 설명');
    echo '<table class="tbl" style="max-width:820px;margin:20px auto"><tr><th>지하감옥 편집의 설명</th></tr><tr><td>';
    echo '각 칸에는 한 글자 맵 코드를 입력합니다.<br>';
    echo '0=일반 통로, 1=상하 통행, 2=오른쪽 벽, 3=아래 벽, 4=왼쪽 벽, 5=사방 통행 가능, 6=오름 계단, 7=내리막 계단, 8=스타트 지정, 9=보상, a=트랩, b=보스<br>';
    echo '저장된 맵은 dungeons.php 탐사 화면에서 즉시 사용됩니다. 몬스터 목록은 별도의 몬스터 데이터 편집에서 수정합니다.';
    echo '</td></tr></table><p style="text-align:center">';
    ebs_admin_nav_form($script, 'MAINTE', '메뉴');
    echo '</p>';
    ebs_admin_footer();
}
function ebs_admin_dungeon_monster_file(string $kind): string {
    return $kind === 'dungeonss' ? 'log/_dungeonss.data' : 'log/_dungeon.data';
}
function ebs_admin_dungeon_monster_data_screen(string $script='d_mainte.php', string $message=''): void {
    $pass=ebs_h(ebs_admin_pass_value());
    $kind=ebs_admin_dungeon_kind();
    $label=ebs_admin_dungeon_kind_label($kind);
    $file=ebs_admin_dungeon_monster_file($kind);
    $data = ebs_read($file);
    ebs_admin_header($label.' 몬스터 데이터 편집');
    if ($message !== '') echo '<p class="ok">'.ebs_h($message).'</p>';
    echo '<form method="post" action="'.ebs_h($script).'"><input type="hidden" name="pass" value="'.$pass.'"><input type="hidden" name="cmd" value="MONSTER_DATA"><p>'.ebs_admin_dungeon_kind_select($kind).' <button class="btn">선택</button></p></form>';
    echo '<form method="post" action="'.ebs_h($script).'"><input type="hidden" name="pass" value="'.$pass.'"><input type="hidden" name="cmd" value="MONSTER_SAVE"><input type="hidden" name="dungeon_kind" value="'.ebs_h($kind).'">';
    echo '<p>전투 몬스터 데이터는 실제 런타임에서 사용하는 <b>'.ebs_h($file).'</b>를 수정합니다.</p><textarea name="dungeon_data" style="width:100%;height:360px;background:#000;color:#ededed">'.ebs_h($data).'</textarea><br><button class="btn">저장</button></form>';
    echo '<p>'; ebs_admin_nav_form($script, 'MAINTE', '던전관리 메뉴'); ebs_admin_nav_form('d_config.php', 'TOP', '던전 설정 관리'); ebs_admin_nav_form('maintenance.php', 'MAINTE2', '관리창 돌아가기'); echo '</p>';
    ebs_admin_footer();
}
function ebs_admin_dungeon_monster_save(): void {
    $kind=ebs_admin_dungeon_kind();
    $file=ebs_admin_dungeon_monster_file($kind);
    ebs_write($file, (string)($_POST['dungeon_data'] ?? ''));
    ebs_admin_audit('DUNGEON_MONSTER_SAVE', ebs_admin_dungeon_kind_label($kind).' 몬스터 데이터 저장');
    ebs_admin_dungeon_monster_data_screen(ebs_admin_script_name('d_mainte.php'), '몬스터 데이터를 저장했습니다.');
}

/**
 * PHP 변환 출력 후처리.
 *
 * 원본 legacy는 헤더(Set-Cookie 등)와 본문을 분리해서 출력했지만, 자동 변환 과정에서
 * 이 함수는 게임 로직을 바꾸지 않고 화면 출력 오류만 보정한다.
 */

/**
 * 원본 legacy의 file 갱신성 POST 처리 공통 대체.
 *
 * 아직 개별 수식까지 분리되지 않은 함수라도 POST를 무시하지 않고
 * user/*.json에 요청값과 처리 범위를 저장한다.
 * 이후 개별 함수 이식 시 이 저장 구조를 기준으로 원본 file 필드 대응을 확장한다.
 */
function ebs_apply_gameplay_post_to_player(array &$player, string $scope): void {
    // 원본 legacy의 file 갱신을 PHP 8.4 user/*.json 개별 파일 저장으로 대체한다.
    // 각 처리 함수에서 아직 세부 수식이 완전히 분리되지 않은 경우에도
    // 게임플레이 POST 값은 무시하지 않고 플레이어 상태에 반영한다.
    $cmd = ebs_param('cmd', $scope);
    $cmode = ebs_param('Cmode', ebs_param('custom', ''));
    $player['last_action'] = $scope;
    $player['last_cmd'] = $cmd;
    $player['last_cmode'] = $cmode;
    $player['last_action_time'] = date('Y-m-d H:i:s');

    if ($scope === 'AUTO_POST_SAVE') {
        // 자동 종료 저장은 개별 처리 함수의 비용/소유권 검증을 우회하면 안 된다.
        // 따라서 수치/장비/국가 필드는 반영하지 않고 최근 행동 시각만 동기화한다.
        ebs_player_sync_common($player);
        return;
    }

    $intMap = [
        'money' => 'money', 'gold' => 'money', 'MONEY' => 'money',
        'hp' => 'hp', 'HP' => 'hp', 'max_hp' => 'max_hp', 'mhp' => 'max_hp',
        'en' => 'en', 'EN' => 'en', 'max_en' => 'max_en', 'men' => 'max_en',
        'level' => 'level', 'lv' => 'level', 'exp' => 'level_exp', 'level_exp' => 'level_exp',
        'win' => 'win', 'lose' => 'lose', 'contrib' => 'contrib',
    ];
    foreach ($intMap as $postKey => $field) {
        if (isset($_POST[$postKey]) && is_scalar($_POST[$postKey]) && is_numeric((string)$_POST[$postKey])) {
            $player[$field] = (int)$_POST[$postKey];
        }
    }

    $strMap = [
        'msname' => 'msname', 'MsName' => 'msname', 'name2' => 'msname',
        'com' => 'comment', 'comment' => 'comment',
        'kuni' => 'kuni', 'country' => 'kuni', 'boumeiC' => 'kuni',
        'icon' => 'icon', 'msImg' => 'icon', 'imgSelect' => 'icon',
        'chara' => 'chara', 'cl' => 'color', 'MsColor' => 'color',
        'w' => 'weapon', 'weapon' => 'weapon', 'wname' => 'weapon',
        'armor' => 'armor',
    ];
    foreach ($strMap as $postKey => $field) {
        if (isset($_POST[$postKey]) && is_scalar($_POST[$postKey])) {
            $val = trim((string)$_POST[$postKey]);
            if ($val !== '') $player[$field] = $val;
        }
    }

    switch ($cmode) {
        case '망명':
            $to = ebs_param('boumeiC', '');
            if ($to !== '') { $player['kuni'] = $to; $player['job'] = '0'; }
            break;
        case '성격변경':
            $player['chara'] = ebs_param('chara', (string)($player['chara'] ?? '0'));
            break;
        case '변경':
            $player['comment'] = function_exists('mb_substr') ? mb_substr(ebs_param('com',''), 0, 80, 'UTF-8') : substr(ebs_param('com',''), 0, 80);
            break;
        case 'HP업':
        case 'EN업':
            // HP/EN 개조는 비용 검증이 필요한 처리이므로 ebs_CUSTOMING2()에서만 반영한다.
            // 자동 POST 저장에서 처리하면 자금 부족 상태에서도 수치가 증가할 수 있다.
            break;
        case '스탯리셋':
            $player['st'] = [6,6,6,6];
            break;
    }

    if ($cmd === 'BATTLE_2' || stripos($scope, 'BATTLE') !== false) {
        $player['battle_count'] = (int)($player['battle_count'] ?? 0) + 1;
        $player['level_exp'] = (int)($player['level_exp'] ?? ($player['exp'] ?? 0)) + 1;
        $player['exp'] = $player['level_exp'];
        ebs_apply_levelup($player);
    }

    // 단순 화면 이동/조회 POST는 역사에 기록하지 않는다.
    // 실제 전투/거래/개조 등 의미 있는 사건은 각 처리 함수가 event_log를 직접 남긴다.
    foreach ($_POST as $k => $v) {
        if (is_scalar($v) && preg_match('/^[A-Za-z0-9_]{1,40}$/', (string)$k)) {
            $player['form_'.$k] = trim((string)$v);
        }
    }
    ebs_player_sync_common($player);
}

function ebs_apply_generic_post(string $scope): void {
    ebs_header_html();
    ebs_record_post($scope);
    $pname = ebs_clean_login_value(ebs_param('pname', ebs_cookie_value('pname', '')));
    $pass = ebs_param('pass', ebs_cookie_value('pass', ''));
    $message = '처리할 세부 동작이 없습니다.';
    if ($pname !== '') {
        [$key, $me, $players, $err] = ebs_require_player($pname, $pass);
        if ($err !== '' || $key === null || !is_array($me)) {
            $message = $err !== '' ? $err : '로그인 정보가 올바르지 않습니다.';
        } else {
            // 호환용 fallback은 비용/소유권 검증을 우회하지 않도록 게임 수치와 장비값을 변경하지 않는다.
            // 실제 저장이 필요한 기능은 개별 처리 함수에서만 반영한다.
            $me['last_action'] = $scope;
            $me['last_action_time'] = date('Y-m-d H:i:s');
            ebs_player_sync_common($me);
            ebs_player_save_one((string)($me['name'] ?? $key), $me);
            $message = '상태 확인 완료';
        }
    }
    echo '<html><body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'"><table width="100%" height="100%"><tr><td align="center">';
    echo ebs_h($scope).' : '.ebs_h($message).'<br><form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST" target="Main" style="display:inline"><input type="hidden" name="cmd" value="MAIN_FRAME"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'"><input type="submit" value="메인" '.ebs_v('STYLE_B1').'></form>';
    echo '</td></tr></table></body></html>';
}

function ebs_autosave_post_state(): void {
    if (PHP_SAPI === 'cli') return;
    if (!empty($GLOBALS['EBS_DISABLE_AUTO_POST_SAVE'])) return;
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') return;
    if (empty($_POST)) return;
    $cmd = ebs_cmd('');
    $rawCmd = strtoupper(ebs_param('cmd', ebs_param('SUB', '')));
    $readOnly = ['HIS','HISA','UPD','TR','WEAPON','LIST','MY_LIST','C_LIST','CO_LIST','ICON','LOGO','MAIN_FRAME','GAME_FRAME','CITY','TRADE','SPS','LOTO','SPC','KAMO2','BATTLE_1','HISTORY','HISALL2','UPDATA2','WEAPON_LIST','MY_LIST2','C_LIST2','CNTRY_LIST','ICON_LIST','LOGO2','STATUS','FRAME2','CITY2','TRADE2','SPS2','LOTO2','SPECIAL'];
    if (in_array($cmd, $readOnly, true) || in_array($rawCmd, $readOnly, true)) return;
    $pname = ebs_clean_login_value(ebs_param('pname', ebs_cookie_value('pname', '')));
    if ($pname === '') return;
    $players = ebs_players_load();
    $key = ebs_find_player_key($pname, $players);
    if ($key === null || !isset($players[$key]) || !is_array($players[$key])) return;
    ebs_apply_gameplay_post_to_player($players[$key], 'AUTO_POST_SAVE');
    ebs_player_save_one((string)($players[$key]['name'] ?? $key), $players[$key]);
}
register_shutdown_function('ebs_autosave_post_state');


function ebs_output_cleanup(string $html): string {
    // legacy 헤더 문자열이 본문에 보이는 문제 제거.
    $html = preg_replace('/(?:^|\R)\s*(?:Content-type|Content-Type|Set-Cookie)\s*:[^\r\n]*(?:\r?\n)?/i', '', $html) ?? $html;


    // legacy 헤더가 한 줄 중간 또는 태그 사이에 끼어든 경우까지 제거한다.
    $html = preg_replace('/\bSet-Cookie\s*:\s*EB=[^<\r\n]*/i', '', $html) ?? $html;
    $html = preg_replace('/\bContent-type\s*:\s*text\/html[^<\r\n]*/i', '', $html) ?? $html;


    $pname = ebs_cookie_value('pname', ebs_param('pname', ''));
    $pass  = ebs_cookie_value('pass', ebs_param('pass', ''));

    $html = preg_replace('/ebs_v\(\s*[\'\"]FORM[\'\"]\s*\)\s*\.\s*\{\\?[\'\"]pname\\?[\'\"]\}/i', ebs_h($pname), $html) ?? $html;
    $html = preg_replace('/ebs_v\(\s*[\'\"]FORM[\'\"]\s*\)\s*\.\s*\{\\?[\'\"]pass\\?[\'\"]\}/i', ebs_h($pass), $html) ?? $html;
    $html = preg_replace('/FORM\s*\{\\?[\'\"]pname\\?[\'\"]\}/i', ebs_h($pname), $html) ?? $html;
    $html = preg_replace('/FORM\s*\{\\?[\'\"]pass\\?[\'\"]\}/i', ebs_h($pass), $html) ?? $html;
    $repl = [
        "{pname}" => ebs_h($pname),
        "{pass}" => ebs_h($pass),
        '{pname}' => ebs_h($pname),
        '{pass}' => ebs_h($pass),
        'COOKIE{\'pname\"]' => ebs_h($pname),
        'COOKIE{\'pass\"]' => ebs_h($pass),
        'FORM{pass}' => ebs_h($pass),
        "\\{'pname'\\}" => ebs_h($pname),
        "\\{'pass'\\}" => ebs_h($pass),
    ];
    $html = strtr($html, $repl);

    $html = preg_replace_callback('~\{(.)([A-Za-z0-9_]+)\1\}~', static function (array $m): string {
        if ($m[1] !== chr(39) && $m[1] !== chr(34)) return $m[0];
        $key = $m[2];
        if (strtolower($key) === 'pass') return ebs_h(ebs_cookie_value('pass', ebs_param('pass', '')));
        if (strtolower($key) === 'pname') return ebs_h(ebs_cookie_value('pname', ebs_param('pname', '')));
        return ebs_h(ebs_param($key, ''));
    }, $html) ?? $html;
    $html = preg_replace_callback('~(?:FORM|COOKIE)\{(.)([A-Za-z0-9_]+)\1\}~i', static function (array $m): string {
        if ($m[1] !== chr(39) && $m[1] !== chr(34)) return $m[0];
        $key = $m[2];
        if (strtolower($key) === 'pass') return ebs_h(ebs_cookie_value('pass', ebs_param('pass', '')));
        if (strtolower($key) === 'pname') return ebs_h(ebs_cookie_value('pname', ebs_param('pname', '')));
        return ebs_h(ebs_param($key, ''));
    }, $html) ?? $html;
    $html = preg_replace_callback('~\{\\?["\']([A-Za-z0-9_]+)\\?["\']\}~', static function (array $m): string {
        $key = $m[1];
        if (strtolower($key) === 'pass') return ebs_h(ebs_cookie_value('pass', ebs_param('pass', '')));
        if (strtolower($key) === 'pname') return ebs_h(ebs_cookie_value('pname', ebs_param('pname', '')));
        return ebs_h(ebs_param($key, ''));
    }, $html) ?? $html;

    // 남은 FORM["임의키"] / COOKIE["임의키"] 표기는 동일 키의 PHP 입력값/쿠키값으로 대체한다.
    $html = preg_replace_callback('~(?:FORM|COOKIE)\s*\{\\?["\']([A-Za-z0-9_]+)\\?["\']\}~i', static function (array $m): string {
        $key = $m[1];
        if (strtolower($key) === 'pass') return ebs_h(ebs_cookie_value('pass', ebs_param('pass', '')));
        if (strtolower($key) === 'pname') return ebs_h(ebs_cookie_value('pname', ebs_param('pname', '')));
        return ebs_h(ebs_param($key, ''));
    }, $html) ?? $html;
    $html = preg_replace_callback('~ebs_v\(\s*["\']FORM["\']\s*\)\s*\.\s*\{\\?["\']([A-Za-z0-9_]+)\\?["\']\}~i', static function (array $m): string {
        return ebs_h(ebs_param($m[1], ''));
    }, $html) ?? $html;

    $html = preg_replace('/\b(?:foreach|elsif|unless|last|next)\b[^<;]*;?/i', '', $html) ?? $html;
    $html = preg_replace('/\$[A-Za-z_][A-Za-z0-9_]*(?:->)?/i', '', $html) ?? $html;



    // FORM 해시가 분리 변환되어 pass 필드에 파일럿명이 들어가는 경우를 방지한다.
    // replacement에 '$1'.숫자값을 직접 붙이면 PHP 정규식이 $1123처럼 해석해 '23>'만 남길 수 있으므로 callback으로 처리한다.
    $html = preg_replace_callback('/(<input\s+[^>]*name=["\']?pass["\']?[^>]*value=)([^\s>"\']*)/i', static function (array $m) use ($pass): string {
        return $m[1] . ebs_h($pass);
    }, $html) ?? $html;
    $html = preg_replace_callback('/(<input\s+[^>]*name=["\']?pname["\']?[^>]*value=)([^\s>"\']*)/i', static function (array $m) use ($pname): string {
        return $m[1] . ebs_h($pname);
    }, $html) ?? $html;

    // 이전 정규식 보정으로 value=test"test"처럼 중복된 hidden/input 값이 생기는 경우를 정리한다.
    $html = preg_replace('/value=([^\s"\'>]+)"\1"/i', 'value="$1"', $html) ?? $html;
    $html = preg_replace('/value=([^\s"\'>]+)\'\1\'/i', 'value="$1"', $html) ?? $html;
    $html = preg_replace('/(<input\s+[^>]*name=["\']?(?:pname|pass)["\']?[^>]*value=)([^"\'\s>]+)(?=[\s>])/i', '$1"$2"', $html) ?? $html;

    // 빈 이미지/수치 값으로 깨지는 대표 출력 보정.
    $html = str_replace(['/ .gif', '/.gif'], ['/1.gif', '/1.gif'], $html);
    $html = preg_replace('/(src=["\']?\.\/img2\/)\.gif/i', '${1}1.gif', $html) ?? $html;
    $html = preg_replace('/(src=["\']?\.\/bukiimg\/)\.png/i', '${1}1.png', $html) ?? $html;
    $html = preg_replace('/width=("|\')?%/i', 'width=${1}0%', $html) ?? $html;
    $html = preg_replace('/width=\s*%/i', 'width=0%', $html) ?? $html;

    $html = preg_replace('/\bmy\s+=\s*;?/i', '', $html) ?? $html;
    $html = preg_replace('/\bmy\s+[A-Za-z_][A-Za-z0-9_]*\s*=\s*;?/i', '', $html) ?? $html;

    // 원본 legacy와 화면색 일치를 위해 검정 배경/흰 글자 계열은 임의로 밝게 바꾸지 않는다.


    // HTML/JavaScript 영역에 섞인 구형 채팅 인증 블록 제거.
    $html = preg_replace('/<script\s+language=["\']TEXT\/JavaScript["\']>.*?use\s+[A-Za-z0-9_:]+.*?(?=<script\s+language=["\']JavaScript["\']>)/is', '', $html) ?? $html;
    $html = preg_replace('/use\s+[A-Za-z0-9_:]+.*?print\s+\\?\'\s*<embed.*?;\s*/is', '', $html) ?? $html;

    // 원본 legacy 색상을 유지한다. 검정 배경/흰 글자 계열을 임의 변환하지 않는다.

    // legacy 헤더 제거 후 남는 빈 괄호/헤더 잔재를 정리한다.
    $html = preg_replace('/^\s*\(\)\s*$/m', '', $html) ?? $html;
    $html = preg_replace('/Set-Cookie\s*:\s*EB=[^\r\n<]*(?:\r?\n\s*\(\)\s*)?/i', '', $html) ?? $html;

    // 자동 변환으로 비어버린 JavaScript 수식은 브라우저 오류를 막기 위해 0으로 보정한다.
    $html = preg_replace('/<\s*\)/', '< 0)', $html) ?? $html;
    $html = preg_replace('/<\s*\{/', '< 0{', $html) ?? $html;
    $html = preg_replace('/=\s*;/', '= 0;', $html) ?? $html;
    $html = str_replace(')/*100', ')/1*100', $html);
    $html = str_replace('width=0%"', 'width="0%"', $html);


    // 카피라이트 블록이 body 상단에 먼저 출력된 경우 하단으로 이동한다.
    $copyMovePattern = '/(<body\b[^>]*>\s*)(?:<span[^>]*>\s*)?<br>\s*<br>\s*The ENDLESS BATTLE Program Satellite.*?한글화 by adonas<\/a>(?:<\/span>)?/is';
    if (preg_match($copyMovePattern, $html, $cm)) {
        $copyBlock = preg_replace('/^<body\b[^>]*>\s*/is', '', $cm[0]) ?? '';
        $html = preg_replace($copyMovePattern, '$1', $html, 1) ?? $html;
        if ($copyBlock !== '' && stripos($html, 'The ENDLESS BATTLE Program Satellite') === false) {
            $html = preg_replace('/<\/body>/i', '<div align="center" style="font-size:15px;font-weight:bold;color:#555555;margin-top:30px;">'.$copyBlock.'</div></body>', $html, 1) ?? ($html.$copyBlock);
        }
    }

    // 같은 카피라이트 블록이 연속 또는 근접해서 두 번 출력되는 경우 첫 번째만 남긴다.
    $copyrightPattern = '/(The ENDLESS BATTLE Program Satellite\s*<br>\s*Produce By.*?한글화 by adonas<\/a><\/span>)(\s*\1)+/is';
    $html = preg_replace($copyrightPattern, '$1', $html) ?? $html;

    // 좁은 프레임/모바일 에뮬레이터에서 고정 min-width 테이블이 화면을 밀어내지 않도록 제한한다.
    $html = preg_replace_callback('/min-width\s*:\s*(\d+)px\s*;?/i', static function (array $m): string {
        $w = max(1, (int)$m[1]);
        return 'min-width:min('.$w.'px,100%);max-width:100%;';
    }, $html) ?? $html;
    $html = preg_replace_callback('/<body\b([^>]*)>/i', static function (array $m): string {
        $attrs = $m[1];
        if (preg_match('/\sstyle=("|\')(.*?)\1/i', $attrs, $sm)) {
            $quote = $sm[1];
            $style = rtrim($sm[2]);
            $style = rtrim($style, ';') . ';background:#000000;color:#ffffff;';
            $attrs = preg_replace('/\sstyle=("|\').*?\1/i', ' style=' . $quote . $style . $quote, $attrs, 1) ?? $attrs;
        } else {
            $attrs .= ' style="background:#000000;color:#ffffff;"';
        }
        return '<body' . $attrs . '>';
    }, $html, 1) ?? $html;

    // 출력에 남을 수 있는 기존 실행 링크는 동일 위치의 PHP 파일 링크로만 치환한다.
    $html = preg_replace_callback('/(?<![A-Za-z0-9_\-])([A-Za-z0-9_\-\/]+)\.cgi\b/i', static function (array $m): string {
        $candidate = $m[1] . '.php';
        $local = __DIR__ . '/' . ltrim($candidate, '/');
        return is_file($local) ? $candidate : $m[0];
    }, $html) ?? $html;

    // 빈 색상 속성은 원본 기본값(FONT_COLOR/BG_MAIN)에 맞춰 보정한다.
    $html = preg_replace('/background:\s*(;|")/i', 'background:'.ebs_h(ebs_v('BG_MAIN')).'$1', $html) ?? $html;
    $html = preg_replace('/color:\s*(;|")/i', 'color:'.ebs_h(ebs_v('FONT_COLOR')).'$1', $html) ?? $html;
    $html = preg_replace('/<span style="color:;/', '<span style="color:'.ebs_h(ebs_v('FONT_COLOR')).';', $html) ?? $html;


    // 빈 자바스크립트/오타 속성 보정.
    $html = preg_replace('/onClick\s*=\s*(>|\s)/i', 'onClick="return false;"$1', $html) ?? $html;
    $html = str_ireplace(' acrion=', ' action=', $html);
    // 중복 메타 charset 정리.
    $html = preg_replace('/<meta\s+http-equiv="Content-Type"\s+content="text\/html;?"\s*>\s*<meta\s+http-equiv="Content-Type"\s+content="text\/html"\s+charset="UTF-8"\s*>/i', '<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">', $html) ?? $html;
    return $html;
}



/** legacy CP949/EUC-KR 텍스트 데이터의 표시용 UTF-8 변환. */
function ebs_legacy_text_to_utf8(string $s): string {
    if ($s === '') return '';
    if (function_exists('mb_check_encoding') && mb_check_encoding($s, 'UTF-8')) return $s;
    if (!function_exists('mb_check_encoding') && preg_match('//u', $s)) return $s;
    foreach (['CP949','EUC-KR','UHC'] as $enc) {
        if (function_exists('mb_convert_encoding')) {
            $v = @mb_convert_encoding($s, 'UTF-8', $enc);
            if (is_string($v) && $v !== '') return $v;
        }
        if (function_exists('iconv')) {
            $v = @iconv($enc, 'UTF-8//IGNORE', $s);
            if (is_string($v) && $v !== '') return $v;
        }
    }
    return preg_replace('/[^\x09\x0A\x0D\x20-\x7E]/', '?', $s) ?? $s;
}

/** 원본 %MON_LISTn 데이터 파일을 PHP 배열로 읽는다. */
function ebs_legacy_monsters(string $rel): array {
    $raw = ebs_read($rel);
    if ($raw === '' && $rel !== ltrim($rel, '/')) $raw = ebs_read(ltrim($rel, '/'));
    if ($raw === '') return [];
    $rows = [];
    if (preg_match_all('/%MON_LIST(\d+)\s*=\s*\((.*?)\);/s', $raw, $blocks, PREG_SET_ORDER)) {
        foreach ($blocks as $block) {
            $floor = (int)$block[1];
            if (!preg_match_all('/"([^"]+)"\s*=>\s*"([^"]*)"/s', $block[2], $items, PREG_SET_ORDER)) continue;
            foreach ($items as $item) {
                $id = (string)$item[1];
                $cols = str_getcsv((string)$item[2], ',', '"', '\\');
                $rows[] = [
                    'floor' => $floor,
                    'id' => $id,
                    'name' => ebs_legacy_text_to_utf8((string)($cols[0] ?? ('MON-'.$id))),
                    'area' => ebs_legacy_text_to_utf8((string)($cols[1] ?? ($floor.'층'))),
                    'weapon' => (string)($cols[2] ?? 'a!0'),
                    'hp' => max(1, (int)($cols[3] ?? 1000)),
                    'max_hp' => max(1, (int)($cols[4] ?? ($cols[3] ?? 1000))),
                    'at' => max(1, (int)($cols[5] ?? 10)),
                    'de' => max(1, (int)($cols[6] ?? 10)),
                    'sp' => max(1, (int)($cols[7] ?? 10)),
                    'hit' => max(1, (int)($cols[8] ?? 10)),
                    'icon' => preg_replace('/[^0-9A-Za-z_\-]/', '', (string)($cols[9] ?? '1')) ?: '1',
                    'exp' => max(1, (int)($cols[10] ?? 10)),
                    'money' => max(0, (int)($cols[11] ?? 0)),
                    'wexp' => max(0, (int)($cols[12] ?? 0)),
                ];
            }
        }
    }
    return $rows;
}
function ebs_monsters_by_floor(string $rel, int $floor): array {
    $all = ebs_legacy_monsters($rel);
    $rows = array_values(array_filter($all, static function (array $m) use ($floor): bool { return (int)$m['floor'] === $floor; }));
    if (!$rows) $rows = $all;
    return $rows;
}
function ebs_pick_monster(string $rel, int $floor, string $id=''): array {
    $rows = ebs_monsters_by_floor($rel, $floor);
    if (!$rows) return [];
    if ($id !== '') foreach ($rows as $m) if ((string)$m['id'] === $id) return $m;
    return $rows[array_rand($rows)];
}

/** NPC/던전/요새/제압전용 전투 보조 함수. 메인 PVP와 이름을 분리해 재선언 충돌을 피한다. */
function ebs_npc_weapon_parts_from_raw(string $raw): array {
    [$id, $exp] = array_pad(explode('!', $raw, 2), 2, '0');
    if ($id === '') $id = ebs_default_weapon_id();
    $table = ebs_weapon_table();
    $row = $table[$id] ?? ($table[ebs_default_weapon_id()] ?? []);
    $defaults = ['없음',1000,70,1,0,0,0,'0','0','01'];
    for ($i=0; $i<count($defaults); $i++) if (!array_key_exists($i, $row) || $row[$i] === '') $row[$i] = $defaults[$i];
    return [$id, max(0, (int)$exp), array_values($row)];
}
function ebs_npc_bougu_parts(array $player): array {
    [$id, $dur] = array_pad(explode('!', ebs_player_raw_get($player, 32, (string)($player['armor'] ?? '')), 2), 2, '0');
    $table = ebs_bougu_table();
    $row = ($id !== '' && isset($table[$id])) ? $table[$id] : [];
    $defaults = ['',0,0,0,0,0,0,'0','7','',0];
    for ($i=0; $i<count($defaults); $i++) if (!array_key_exists($i, $row) || $row[$i] === '') $row[$i] = $defaults[$i];
    return [$id, max(0, (int)$dur), array_values($row)];
}
function ebs_npc_has_effect(array $row, string $code): bool {
    return strpos((string)($row[7] ?? ''), $code) !== false;
}
function ebs_npc_rand255_gt(int $threshold): bool { return mt_rand(0, 254) > $threshold; }
function ebs_npc_rand_int(float|int $max): int {
    $n = (int)floor((float)$max);
    return $n <= 0 ? 0 : mt_rand(0, $n - 1);
}
function ebs_npc_apply_mission(int $mode, float &$atk, float &$def, float &$sp, float &$hit, int &$count, int &$en): string {
    $names = [1=>'통상공격',2=>'돌격',3=>'방어',4=>'치고 빠지기',5=>'저격',6=>'필사',7=>'배수의 진',8=>'일제사격'];
    if ($mode === 2) { $atk *= 1.3; $def *= 0.7; }
    elseif ($mode === 3) { $atk *= 0.8; $def *= 2; }
    elseif ($mode === 4) { $atk *= 0.7; $sp *= 2; }
    elseif ($mode === 5) { $def *= 0.8; $hit += 20; }
    elseif ($mode === 6) { $atk *= 2; $def /= 5; }
    elseif ($mode === 7) { $atk *= 0.9; $sp *= 3; $hit += 10; }
    elseif ($mode === 8) { $hit -= 35; $count *= 2; $en *= 2; }
    $count = max(1, $count);
    $en = max(0, $en);
    return $names[$mode] ?? $names[1];
}
function ebs_npc_apply_chara(string $chara, float &$atk, float &$def, float &$sp, float &$hit): void {
    if ($chara === '1') { $atk *= 1.2; $def -= 2; }
    elseif ($chara === '2') { $atk *= 1.2; }
    elseif ($chara === '3') { $atk *= 0.9; $sp += 3; }
    elseif ($chara === '4') { $hit += 5; }
    elseif ($chara === '5') { $atk *= 1.3; $hit += 10; $def -= 4; }
    elseif ($chara === '6') { $atk *= 1.5; $def *= 1.5; $sp *= 1.7; $hit *= 1.7; }
}
function ebs_npc_effect_icons(int $count, array $hits): string {
    $base = ebs_h(ebs_v('IMG_FOLDER1', './img1'));
    $out = '';
    for ($i=0; $i<$count; $i++) {
        $out .= '<img src="'.$base.'/'.(!empty($hits[$i]) ? 'hit.gif' : 'miss.gif').'" border="0">';
        if (($i + 1) % 10 === 0) $out .= "<br>\n";
    }
    return $out === '' ? '&nbsp;' : $out;
}
function ebs_npc_hp_bar(int $before, int $after, int $max, int $width=150): string {
    $max = max(1, $max);
    $before = max(0, min($max, $before));
    $after = max(0, min($max, $after));
    $remain = (int)floor($after / $max * $width);
    $damage = (int)floor(max(0, $before - $after) / $max * $width);
    $recover = (int)floor(max(0, $after - $before) / $max * $width);
    $base = ebs_h(ebs_v('IMG_FOLDER1', './img1'));
    $out = '';
    if ($remain > 0) $out .= '<img src="'.$base.'/hp.gif" hspace="0" height="7" width="'.$remain.'">';
    if ($damage > 0) $out .= '<img src="'.$base.'/dmg.gif" hspace="0" height="7" width="'.$damage.'">';
    if ($recover > 0) $out .= '<img src="'.$base.'/zen.gif" hspace="0" height="7" width="'.$recover.'">';
    return $out !== '' ? $out : '<img src="'.$base.'/dmg.gif" hspace="0" height="7" width="1">';
}
function ebs_npc_battle_summary(int $count, int $hits, int $damage): string {
    $dmgStyl='style="font-size:21px;color:#9acd32;"';
    $chaStyl='style="font-size:12px;color:#dc143c;"';
    if ($hits <= 0) return '<font color="#6a5acd">빗나감</font>';
    return '<b '.$dmgStyl.'>'.$count.'</b> <b '.$chaStyl.'>회 공격</b> <b '.$dmgStyl.'>'.$hits.'</b> <b '.$chaStyl.'>회 명중</b> <b '.$dmgStyl.'>'.$damage.'</b><b '.$chaStyl.'> 피해</b>';
}
function ebs_npc_add_status_damage(array &$player, int $idx, string $label, array &$messages): void {
    $cur = (int)ebs_player_raw_get($player, $idx, '0');
    if ($cur <= 0) return;
    $cur--;
    ebs_player_raw_set($player, $idx, (string)$cur);
    $map = [19=>0,20=>1,21=>2,22=>3];
    if (isset($map[$idx])) {
        if (!isset($player['st']) || !is_array($player['st'])) $player['st'] = [6,6,6,6];
        $player['st'][$map[$idx]] = $cur;
    }
    $messages[] = '<font color="#8000ff">'.ebs_h($label).'</font><br>';
}
function ebs_npc_apply_special_effects(array &$me, array $plW, array $enemyW, array $plB, int $result, int &$myHpAfter, int &$enemyHpAfter, int &$myEnAfter, int &$enemyEnAfter, int $myMaxHp, int $enemyMaxHp, int $myMaxEn, int $enemyMaxEn, int &$gainExp, int &$gainMoney): array {
    $messages = [];
    $statusNames = array_replace(['공격','방어','속도','명중','HP','EN'], ebs_arr('STATUS_NAME'));

    // 패배 시 원본 DOWN 계열: 일정 확률로 능력치/상한 저하.
    if ($result === 1) {
        $event = mt_rand(0, 69);
        if ($event === 12) ebs_npc_add_status_damage($me, 19, '기체 파괴 '.$statusNames[0].'가 조금 다운.', $messages);
        if ($event === 13) ebs_npc_add_status_damage($me, 20, '기체 파괴 '.$statusNames[1].'가 조금 다운.', $messages);
        if ($event === 14) ebs_npc_add_status_damage($me, 21, '기체 파괴 '.$statusNames[2].'가 조금 다운.', $messages);
        if ($event === 15) ebs_npc_add_status_damage($me, 22, '기체 파괴 '.$statusNames[3].'가 조금 다운.', $messages);
        if ($event === 20 && $myMaxHp >= 5000) {
            $new = max(1, (int)floor($myMaxHp * 0.995));
            $me['max_hp'] = $new;
            ebs_player_raw_set($me, 16, (string)$new);
            $messages[] = '<font color="#dc143c">기체 파괴 '.$statusNames[4].'가 조금 다운.</font><br>';
        }
        if ($event === 40 && $myMaxEn >= 100) {
            $new = max(1, (int)floor($myMaxEn * 0.995));
            $me['max_en'] = $new;
            ebs_player_raw_set($me, 18, (string)$new);
            $messages[] = '<font color="#dc143c">기체 파괴 '.$statusNames[5].'가 조금 다운.</font><br>';
        }
    }

    // 플레이어 무기 특수효과: NPC HP/EN/보상에 직접 반영한다.
    if (ebs_npc_has_effect($plW, '1') && ebs_npc_rand255_gt(200)) {
        $enemyHpAfter = max(0, $enemyHpAfter - max(1, (int)floor($enemyMaxHp * 0.03)));
        $messages[] = '<font color="#8000ff">적기 내부 계통을 파손시켰다.</font><br>';
    }
    if (ebs_npc_has_effect($plW, '2') && ebs_npc_rand255_gt(240)) {
        $enemyHpAfter = 0;
        $messages[] = '<font color="#ff0080">상대기체를 전투불능으로 만들었다.</font><br>';
    }
    if (ebs_npc_has_effect($plW, '5') && ebs_npc_rand255_gt(200)) {
        $drain = ebs_npc_rand_int(max(1, $enemyHpAfter * 0.3));
        $enemyHpAfter = max(0, $enemyHpAfter - $drain);
        $myHpAfter = min($myMaxHp, $myHpAfter + $drain);
        $messages[] = '<font color="#80ff00">적의 HP를 흡수하였다!</font><br>';
    }
    if (ebs_npc_has_effect($plW, '9') && ebs_npc_rand255_gt(200)) {
        $drain = ebs_npc_rand_int(max(1, $enemyEnAfter * 0.1));
        $enemyEnAfter = max(0, $enemyEnAfter - $drain);
        $myEnAfter = min($myMaxEn, $myEnAfter + $drain);
        $messages[] = '<font color="#80ff00">적의 EN을 흡수하였다!</font><br>';
    }
    if (ebs_npc_has_effect($plW, 'a') && ebs_npc_rand255_gt(180)) {
        $bonus = min(1000, max(1, ebs_npc_rand_int(max(1, $gainMoney * 0.2))));
        $gainMoney += $bonus;
        $messages[] = '<font color="#80ff00">적의 주머니에서 $'.$bonus.'을 몰래 가져왔다!</font><br>';
    }
    if (ebs_npc_has_effect($plW, 'b') && ebs_npc_rand255_gt(180)) {
        $bonus = min(1000, max(1, ebs_npc_rand_int(max(1, $gainExp * 0.2))));
        $gainExp += $bonus;
        $messages[] = '<font color="#80ff00">'.$bonus.'의 경험치를 더 얻었다!</font><br>';
    }

    // NPC 무기 특수효과. 몬스터/요새/제압군 데이터의 weapon ID에 효과가 있을 경우만 적용된다.
    if (ebs_npc_has_effect($enemyW, '1')) {
        if (ebs_npc_rand255_gt(230)) ebs_npc_add_status_damage($me, 19, '적기 공격계통 파손', $messages);
        if (ebs_npc_rand255_gt(230)) ebs_npc_add_status_damage($me, 20, '적기 방어계통 파손', $messages);
        if (ebs_npc_rand255_gt(230)) ebs_npc_add_status_damage($me, 21, '적기 회피계통 파손', $messages);
        if (ebs_npc_rand255_gt(230)) ebs_npc_add_status_damage($me, 22, '적기 명중계통 파손', $messages);
    }
    if (ebs_npc_has_effect($enemyW, '2') && ebs_npc_rand255_gt(240)) {
        $me['repair'] = '1';
        ebs_player_raw_set($me, 25, '1');
        $messages[] = '<font color="#ff0080">기체가 전투불능 상태가 되었다.</font><br>';
    }
    if (ebs_npc_has_effect($enemyW, '5') && ebs_npc_rand255_gt(200)) {
        $drain = ebs_npc_rand_int(max(1, $myHpAfter * 0.3));
        $myHpAfter = max(0, $myHpAfter - $drain);
        $enemyHpAfter = min($enemyMaxHp, $enemyHpAfter + $drain);
        $messages[] = '<font color="#c22c2c">적에게 HP를 흡수당했다!</font><br>';
    }
    if (ebs_npc_has_effect($enemyW, '9') && ebs_npc_rand255_gt(200)) {
        $drain = ebs_npc_rand_int(max(1, $myEnAfter * 0.3));
        $myEnAfter = max(0, $myEnAfter - $drain);
        $enemyEnAfter = min($enemyMaxEn, $enemyEnAfter + $drain);
        $messages[] = '<font color="#c22c2c">적에게 EN을 흡수당했다!</font><br>';
    }
    if (ebs_npc_has_effect($enemyW, 'a') && ebs_npc_rand255_gt(180)) {
        $loss = min(1000, max(1, ebs_npc_rand_int(max(1, (int)($me['money'] ?? 0) * 0.01))));
        $me['money'] = max(0, (int)($me['money'] ?? 0) - $loss);
        $messages[] = '<font color="#c22c2c">$'.$loss.'이 어디론가 사라졌다.</font><br>';
    }
    if (ebs_npc_has_effect($enemyW, 'b') && ebs_npc_rand255_gt(180)) {
        $loss = min(1000, max(1, ebs_npc_rand_int(max(1, (int)($me['level_exp'] ?? 0) * 0.05))));
        $me['level_exp'] = max(0, (int)($me['level_exp'] ?? 0) - $loss);
        $me['exp'] = $me['level_exp'];
        ebs_player_raw_set($me, 30, (string)$me['level_exp']);
        $messages[] = '<font color="#c22c2c">'.$loss.'의 경험치를 잃어버렸다.</font><br>';
    }

    // 보강장비 Emergency Fix Kit. 패배 또는 대파 직전에 회복한다.
    if (strpos((string)($plB[7] ?? ''), '6') !== false && $myHpAfter <= 0) {
        $myHpAfter = max(1, (int)floor($myMaxHp * 0.5));
        $me['repair'] = '0';
        ebs_player_raw_set($me, 25, '0');
        $messages[] = '<font color="#dbdafe">Emergency Fix Kit가 작동하였다!</font><br>';
    }

    $myHpAfter = max(0, min($myMaxHp, $myHpAfter));
    $enemyHpAfter = max(0, min($enemyMaxHp, $enemyHpAfter));
    $myEnAfter = max(0, min($myMaxEn, $myEnAfter));
    $enemyEnAfter = max(0, min($enemyMaxEn, $enemyEnAfter));
    return $messages;
}
function ebs_npc_add_weapon_exp_to_player(array &$player, int $gain): array {
    $gain = max(0, $gain);
    $raw = ebs_player_raw_get($player, 9, (string)($player['weapon'] ?? ''));
    [$id, $exp] = array_pad(explode('!', $raw, 2), 2, '0');
    if ($id === '') return [false, ''];
    $oldLevel = intdiv(max(0, (int)$exp), max(1, (int)ebs_v('WEAPON_LVUP','100')));
    $maxExp = max(1, (int)ebs_v('MAX_WEAPONLV','100')) * max(1, (int)ebs_v('WEAPON_LVUP','100'));
    $newExp = min($maxExp, max(0, (int)$exp + $gain));
    $newLevel = intdiv($newExp, max(1, (int)ebs_v('WEAPON_LVUP','100')));
    $player['weapon'] = $id.'!'.$newExp;
    ebs_player_raw_set($player, 9, $player['weapon']);
    return [$newLevel > $oldLevel, $id];
}

/** 파일 기반 저장용 NPC 전투 처리. 원본 던전/요새/제압의 전투 루프와 특수효과를 PHP 저장 방식에 맞춰 통합한다. */
function ebs_run_npc_battle(string $title, array $enemy, string $logType='npc_battle'): void {
    ebs_header_html();
    [$key, $me, $players, $err] = ebs_require_player();
    if ($err !== '' || $key === null || !is_array($me)) { ebs_error_page('Error', $err ?: '로그인 정보가 없습니다.'); return; }
    if ((string)($me['repair'] ?? ebs_player_raw_get($me, 25, '0')) === '1') { ebs_error_page('수리중', '수리중입니다.'); return; }

    $pname = (string)($me['name'] ?? $key);
    $pass = ebs_param('pass', ebs_cookie_value('pass', ''));
    $mode = max(1, min(8, (int)ebs_param('mode', '1')));
    $enemyMode = mt_rand(1, 8);

    [$plWid, $plWexp, $plW] = ebs_npc_weapon_parts_from_raw(ebs_player_raw_get($me, 9, (string)($me['weapon'] ?? '')));
    [$enWid, $enWexp, $enW] = ebs_npc_weapon_parts_from_raw((string)($enemy['weapon'] ?? ebs_default_weapon_id().'!0'));
    [$plBid, $plBdur, $plB] = ebs_npc_bougu_parts($me);

    $plWlv = intdiv($plWexp, max(1, (int)ebs_v('WEAPON_LVUP','100')));
    $enWlv = intdiv($enWexp, max(1, (int)ebs_v('WEAPON_LVUP','100')));
    $plWeaponName = (string)($plW[0] ?? $plWid).' (Level.'.$plWlv.')';
    $enWeaponName = (string)($enW[0] ?? $enWid).' (Level.'.$enWlv.')';

    $myLv = max(1, (int)($me['level'] ?? ebs_player_raw_get($me,29,'1')));
    $st = isset($me['st']) && is_array($me['st']) ? $me['st'] : [
        (int)ebs_player_raw_get($me,19,'6'), (int)ebs_player_raw_get($me,20,'6'),
        (int)ebs_player_raw_get($me,21,'6'), (int)ebs_player_raw_get($me,22,'6')
    ];
    $myHpBefore = max(0, (int)($me['hp'] ?? ebs_player_raw_get($me,15,'0')));
    $myMaxHp = max(1, (int)($me['max_hp'] ?? ebs_player_raw_get($me,16,(string)$myHpBefore)));
    if ($myHpBefore <= 0) $myHpBefore = $myMaxHp;
    $myEnBefore = max(0, (int)($me['en'] ?? ebs_player_raw_get($me,17,'0')));
    $myMaxEn = max(1, (int)($me['max_en'] ?? ebs_player_raw_get($me,18,(string)$myEnBefore)));

    $enemyHpBefore = max(1, (int)ebs_param('hp', (string)($enemy['hp'] ?? 1000)));
    $enemyMaxHp = max($enemyHpBefore, (int)($enemy['max_hp'] ?? $enemyHpBefore));
    $enemyEnBefore = max(0, (int)($enemy['en'] ?? (int)($enW[4] ?? 0) * max(1, (int)($enW[3] ?? 1))));
    $enemyMaxEn = max(1, (int)($enemy['max_en'] ?? max(1, $enemyEnBefore)));

    $plAtk = max(1.0, (float)($plW[1] ?? 1000) * (($plWexp * 0.0001) + 1));
    $plDef = ((float)($st[1] ?? 6) + (float)($plB[1] ?? 0)) * 2 - ((float)($enemy['at'] ?? 10) / 3);
    $plSp = (float)($st[2] ?? 6) + (float)($plB[2] ?? 0);
    $plHit = (float)($st[3] ?? 6) + (float)($plB[3] ?? 0) + (float)($plW[2] ?? 70);
    $plCount = max(1, (int)($plW[3] ?? 1));
    $plEnSpend = max(0, (int)($plW[4] ?? 0));

    $enAtk = max(1.0, (float)($enW[1] ?? 1000) * (($enWexp * 0.0001) + 1));
    $enDef = ((float)($enemy['de'] ?? 10)) * 2 - ((float)($st[0] ?? 6) / 3);
    $enSp = (float)($enemy['sp'] ?? 10);
    $enHit = (float)($enemy['hit'] ?? 10) + (float)($enW[2] ?? 70);
    $enCount = max(1, (int)($enW[3] ?? 1));
    $enEnSpend = max(0, (int)($enW[4] ?? 0));

    $plModeLabel = ebs_npc_apply_mission($mode, $plAtk, $plDef, $plSp, $plHit, $plCount, $plEnSpend);
    $enModeLabel = ebs_npc_apply_mission($enemyMode, $enAtk, $enDef, $enSp, $enHit, $enCount, $enEnSpend);
    ebs_npc_apply_chara((string)($me['chara'] ?? ebs_player_raw_get($me,12,'0')), $plAtk, $plDef, $plSp, $plHit);
    if (ebs_npc_has_effect($plW, '4')) $plDef *= 1.2;
    if (ebs_npc_has_effect($plW, '3')) $plSp *= 1.2;
    if (ebs_npc_has_effect($plW, 'c')) $plHit += 20;
    if (ebs_npc_has_effect($enW, '4')) $enDef *= 1.2;
    if (ebs_npc_has_effect($enW, '3')) $enSp *= 1.2;
    if (ebs_npc_has_effect($enW, 'c')) $enHit += 20;

    if ($myEnBefore < $plEnSpend) {
        ebs_error_page('noEnergy', 'EN이 충분하지 않습니다.');
        return;
    }

    $plUsed = $enUsed = $plHits = $enHits = 0;
    $plDamage = $enDamage = 0;
    $plHitSeq = $enHitSeq = [];
    for ($turn=1; $turn<100; $turn++) {
        if (($plUsed >= $plCount && $enUsed >= $enCount) || $turn > ($plCount + $enCount)) break;
        $initiative = ($plSp + mt_rand(0, 29)) >= ($enSp + mt_rand(0, 29));
        if ($plDamage < $enemyHpBefore && $plUsed < $plCount && ($initiative || $enUsed >= $enCount)) {
            $check = (int)floor(mt_rand(0, 99) + $enSp / 2 - (($st[3] ?? 6) + (float)($plB[3] ?? 0)) / 2);
            $plUsed++;
            if ($check < $plHit) {
                $plHitSeq[] = true; $plHits++;
                $plDamage += max(0, (int)floor($plAtk - ($enDef * mt_rand(90, 139) / max(1, $plCount))));
            } else $plHitSeq[] = false;
            continue;
        }
        if ($enDamage < $myHpBefore && $enUsed < $enCount && (!$initiative || $plUsed >= $plCount)) {
            $check = (int)floor(mt_rand(0, 99) + $plSp / 2 - (float)($enemy['hit'] ?? 10) / 2);
            $enUsed++;
            if ($check < $enHit) {
                $enHitSeq[] = true; $enHits++;
                $enDamage += max(0, (int)floor($enAtk - ($plDef * mt_rand(90, 139) / max(1, $enCount))));
            } else $enHitSeq[] = false;
            continue;
        }
    }
    $plDamage = max(0, $plDamage);
    $enDamage = max(0, $enDamage);
    $enemyHpAfter = max(0, $enemyHpBefore - min($enemyHpBefore, $plDamage));
    $myHpAfter = max(0, $myHpBefore - min($myHpBefore, $enDamage));
    $myEnAfter = max(0, $myEnBefore - ($plHits > 0 ? $plEnSpend : 0));
    $enemyEnAfter = max(0, $enemyEnBefore - ($enHits > 0 ? $enEnSpend : 0));

    $result = 2; // 0=승리, 1=패배, 2=무승부
    if ($enemyHpAfter <= 0 && $myHpAfter > 0) $result = 0;
    elseif ($myHpAfter <= 0 && $enemyHpAfter > 0) $result = 1;

    $baseExp = max(1, (int)($enemy['exp'] ?? 10));
    $baseMoney = max(0, (int)($enemy['money'] ?? 0));
    $gainWexp = max(0, (int)($enemy['wexp'] ?? 0));
    $gainExp = $result === 0 ? $baseExp : max(1, (int)floor($baseExp / 4));
    $gainMoney = $result === 0 ? $baseMoney : 0;
    if ($result === 1 && mt_rand(0, 254) > 240) {
        $lost = (int)floor((int)($me['money'] ?? 0) * 2 / 3);
        $me['money'] = max(0, (int)($me['money'] ?? 0) - $lost);
    }

    $specialMessages = ebs_npc_apply_special_effects($me, $plW, $enW, $plB, $result, $myHpAfter, $enemyHpAfter, $myEnAfter, $enemyEnAfter, $myMaxHp, $enemyMaxHp, $myMaxEn, $enemyMaxEn, $gainExp, $gainMoney);
    if ($enemyHpAfter <= 0 && $myHpAfter > 0) $result = 0;
    elseif ($myHpAfter <= 0 && $enemyHpAfter > 0) $result = 1;
    else $result = 2;

    $oldLevel = $myLv;
    $me['hp'] = $myHpAfter;
    $me['en'] = $myEnAfter;
    if ($result === 1) {
        $me['hp'] = 0;
        $me['repair'] = '1';
        ebs_player_raw_set($me, 25, '1');
    }
    $me['level_exp'] = max(0, (int)($me['level_exp'] ?? ($me['exp'] ?? 0)) + $gainExp);
    $me['exp'] = $me['level_exp'];
    $me['money'] = max(0, (int)($me['money'] ?? 0) + $gainMoney);
    // 원본 dungeonss/mission/wars CGI는 NPC 전투 결과와 무관하게 전투에 사용한 주무기의
    // 누적 경험치(PL_WLV)를 갱신한다. 기존 변환본은 승리 때만 저장해서
    // 화면에는 무기경험치 획득이 출력되는데 실제 장비 exp가 변하지 않는 케이스가 있었다.
    [$weaponLevelUp, $weaponId] = $gainWexp > 0 ? ebs_npc_add_weapon_exp_to_player($me, $gainWexp) : [false, ''];
    [$newLevel, $newExp, $levelUps] = ebs_apply_levelup($me);

    if (!isset($me['event_log']) || !is_array($me['event_log'])) $me['event_log'] = [];
    $resultLabel = $result === 0 ? 'win' : ($result === 1 ? 'lose' : 'draw');
    $me['event_log'][] = ['type'=>$logType,'enemy'=>(string)($enemy['name'] ?? 'MONSTER'),'result'=>$resultLabel,'exp'=>$gainExp,'weapon_exp'=>$gainWexp,'money'=>$gainMoney,'floor'=>(int)($enemy['floor'] ?? 0),'time'=>date('YmdHis')];
    if (count($me['event_log']) > 80) $me['event_log'] = array_slice($me['event_log'], -80);
    $me['battle_log'] = date('YmdHis').'!'.(string)($enemy['name'] ?? 'MONSTER').'와 교전';
    $me['recovery_at'] = (string)time();
    ebs_player_sync_common($me);
    $players[$key] = $me;
    ebs_players_save($players);

    $enemyName = (string)($enemy['name'] ?? 'MONSTER');
    $enemyIcon = preg_replace('/[^0-9A-Za-z_\-]/', '', (string)($enemy['icon'] ?? '1')) ?: '1';
    $myIcon = preg_replace('/[^0-9A-Za-z_\-]/', '', (string)($me['icon'] ?? '1')) ?: '1';
    $plIcons = ebs_npc_effect_icons($plCount, $plHitSeq);
    $enIcons = ebs_npc_effect_icons($enCount, $enHitSeq);
    $plSummary = ebs_npc_battle_summary($plCount, $plHits, $plDamage);
    $enSummary = ebs_npc_battle_summary($enCount, $enHits, $enDamage);
    $plBar = ebs_npc_hp_bar($myHpBefore, (int)$me['hp'], $myMaxHp);
    $enBar = ebs_npc_hp_bar($enemyHpBefore, $enemyHpAfter, $enemyMaxHp);
    $resultText = $result === 0 ? $enemyName.'를(을) 쓰러뜨렸다.' : ($result === 1 ? (string)($me['msname'] ?? $pname).' 대파' : '결판이 나지 않았습니다.');

    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>'.ebs_h($title).'</title></head>';
    echo '<body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="margin:0;font-size:13px;" oncontextmenu="return false;">';
    echo '<center><table border="0" width="100%" cellspacing="0" cellpadding="0" bgcolor="#000000">';
    echo '<tr><td align="center" width="100%" colspan="2" bgcolor="#ff3300" style="color:#000000;font-size:30px;font-family:굴림;height:35px;"><b>'.ebs_h($title).'</b></td></tr>';
    echo '<tr><td align="center" width="50%"><font color="'.ebs_h((string)($me['color'] ?? '#ffffff')).'" style="font-size:18pt;">'.ebs_h((string)($me['msname'] ?? $pname)).'</font><br><div style="font-size:15px;">('.ebs_h($pname).')</div></td>';
    echo '<td align="center" width="50%"><font color="#ffcc66" style="font-size:18pt;">'.ebs_h($enemyName).'</font><br><div style="font-size:15px;">('.ebs_h((string)($enemy['area'] ?? '전장')).')</div></td></tr>';
    echo '<tr><td align="center" width="50%" height="100" valign="bottom"><img src="'.ebs_h(ebs_v('IMG_FOLDER2')).'/'.ebs_h($myIcon).'.gif"><div style="font-size:15px;">【'.ebs_h($plModeLabel).'】</div><table><tr><td><b>HP</b></td><td>'.$plBar.'</td><td width="50" align="right"><span id="cplhp">'.$myHpBefore.'</span></td><td>/<b>'.$myMaxHp.'</b></td></tr></table></td>';
    echo '<td align="center" width="50%" height="100" valign="bottom"><img src="'.ebs_h(ebs_v('IMG_FOLDER2')).'/'.ebs_h($enemyIcon).'.gif" style="filter:fliph();"><div style="font-size:15px;">【'.ebs_h($enModeLabel).'】</div><table><tr><td><b>HP</b></td><td>'.$enBar.'</td><td width="50" align="right"><span id="cvshp">'.$enemyHpBefore.'</span></td><td>/<b>'.$enemyMaxHp.'</b></td></tr></table></td></tr>';
    echo '<tr><td align="center" valign="top" width="50%"><font color="#778899" style="font-size:16px;"><b>'.ebs_h($plWeaponName).'</b></font><div>'.$plIcons.'<div>'.$plSummary.'<br><b style="font-size:12px;color:#dc143c;">EN:-'.$plEnSpend.'</b></div></div></td>';
    echo '<td align="center" valign="top" width="50%"><font color="#778899" style="font-size:16px;"><b>'.ebs_h($enWeaponName).'</b></font><div>'.$enIcons.'<div>'.$enSummary.'<br><b style="font-size:12px;color:#dc143c;">EN:-'.$enEnSpend.'</b></div></div></td></tr>';
    echo '</table><div style="line-height:4pt;">&nbsp;</div><table border="1" bordercolor="#333333" bgcolor="#000000" cellspacing="0" cellpadding="5"><tr><td bgcolor="#000000" style="line-height:18px;font-size:14px;">';
    echo ebs_h($resultText).'<br>';
    foreach ($specialMessages as $m) echo $m;
    $isDungeonBattle = (strpos($logType, 'dungeon') === 0);
    if ($result === 0) {
        echo ebs_h($pname).'는 '.$gainExp.'의 경험치, '.$gainMoney.'의 돈, '.$gainWexp.'의 무기경험치를 획득<br>';
        if ($levelUps > 0) echo '<font color="#f7e957">'.ebs_h($pname).' (이/가) 레벨이 올랐습니다.</font><br>';
        if ($weaponLevelUp) echo '<font color="#f7e957">'.ebs_h($pname).'의 무기가 레벨업했습니다.</font><br>';
    } elseif ($result === 1) {
        echo '몬스터에게 졌습니다.<br>';
    } else {
        echo $isDungeonBattle ? '탐험 화면으로 돌아가 계속 진행합니다.<br>' : '재전투가 가능합니다.<br>';
    }
    echo '</td></tr></table>';
    echo '<script>timeID=10;cdplhp=Math.round(('.$myHpBefore.'-'.(int)$me['hp'].')*0.1);cdvshp=Math.round(('.$enemyHpBefore.'-'.$enemyHpAfter.')*0.1);flaga=flagb=0;setTimeout("HEcount()",1200);function HEcount(){var a=document.getElementById("cplhp"),b=document.getElementById("cvshp");if(!a||!b)return;a.innerText=parseInt(a.innerText)-cdplhp;b.innerText=parseInt(b.innerText)-cdvshp;if(parseInt(a.innerText)<='.(int)$me['hp'].'){a.innerText="'.(int)$me['hp'].'";flaga=1;}if(parseInt(b.innerText)<='.$enemyHpAfter.'){b.innerText="'.$enemyHpAfter.'";flagb=1;}clearTimeout(timeID);if(!flaga||!flagb){timeID=setTimeout("HEcount()",1);}}</script>';

    $returnFile = (strpos($logType, 'dungeonss') === 0) ? 'dungeonss.php' : ((strpos($logType, 'dungeon') === 0) ? 'dungeons.php' : '');
    echo '<table border="1" bordercolor="#333333" bgcolor="#000000" cellspacing="0"><tr><td><b style="font-size:12px;color:#dc143c;">&nbsp;</b><br>';
    if ($returnFile !== '') {
        echo '<form action="'.ebs_h($returnFile).'" method="POST" target="Sub" style="display:inline;"><input type="hidden" name="cmd" value="DUNGEON"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'"><input type="submit" value="탐험 계속" '.ebs_v('STYLE_B1').'></form>';
    } else {
        echo '<form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST" target="Main" style="display:inline;"><input type="hidden" name="cmd" value="MAIN_FRAME"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'"><input type="submit" value="귀환" '.ebs_v('STYLE_B1').'></form>';
    }
    echo '</td></tr></table></center></body></html>';
}

ebs_bootstrap_runtime_counts();

if (empty($GLOBALS['EBS_OUTPUT_CLEANUP_STARTED'])) {
    $GLOBALS['EBS_OUTPUT_CLEANUP_STARTED'] = true;
    ob_start('ebs_output_cleanup');
}


/**
 * 원본 부가 legacy에서 아직 직접 HTML 변환이 끝나지 않은 단독 처리 화면용 공통 출력.
 * 단순 함수명만 노출하지 않고, PHP 파일 기반 저장소와 연결되는 유지보수 가능한 화면을 출력한다.
 */
function ebs_feature_screen(string $title, string $message = ''): void {
    ebs_header_html();
    ebs_bootstrap_runtime_counts();
    $safeTitle = ebs_h($title);
    $msg = $message !== '' ? $message : '이 화면은 원본 처리부에 대응하는 PHP 8.4 화면입니다.';
    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>ENDLESS BATTLE - '.$safeTitle.'</title></head>';
    echo '<body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="margin:0;padding:8px;font-size:13px;" oncontextmenu="return false;">';
    echo '<center><table border="0" cellspacing="1" cellpadding="6" style="background:'.ebs_h(ebs_v('TABLE_BORDER')).';color:'.ebs_h(ebs_v('FONT_COLOR')).';font-size:13px;min-width:420px;">';
    echo '<tr><td align="center" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'" style="font-size:18px;font-weight:bold;">'.$safeTitle.'</td></tr>';
    echo '<tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" style="line-height:1.6;">'.ebs_h($msg).'</td></tr>';
    echo '<tr><td align="center" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'">';
    echo '<form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST" target="Main" style="display:inline;"><input type="hidden" name="cmd" value="MAIN_FRAME"><input type="submit" value="메인" '.ebs_v('STYLE_B1').'></form> ';
    echo '<form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST" target="Sub" style="display:inline;"><input type="hidden" name="cmd" value="GAME_FRAME"><input type="submit" value="게임화면" '.ebs_v('STYLE_B1').'></form>';
    echo '</td></tr></table></center></body></html>';
}

/** 부가 기능의 POST 처리 후 표준 완료 화면. */
function ebs_post_done_screen(string $scope): void {
    ebs_apply_generic_post($scope);
}
