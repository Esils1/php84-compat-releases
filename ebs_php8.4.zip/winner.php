<?php
declare(strict_types=1);
require_once __DIR__ . '/lib_ebs.php';
/** 우승자/전적 요약 화면. */
ebs_header_html();
$players = ebs_players_load();
usort($players, static function(array $a,array $b): int { return ((int)($b['win']??0)+ ebs_player_contrib_value($b)) <=> ((int)($a['win']??0)+ ebs_player_contrib_value($a)); });
echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>WINNER</title></head><body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="margin:8px;font-size:13px;"><center><table border="1" cellspacing="0" cellpadding="5" bordercolor="'.ebs_h(ebs_v('TABLE_BORDER')).'" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" style="min-width:700px;font-size:13px;"><tr><td colspan="7" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'" align="center"><b>WINNER LIST</b></td></tr><tr bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'"><td>순위</td><td>파일럿</td><td>기체</td><td>국가</td><td>승</td><td>패</td><td>공헌</td></tr>';
$i=0; foreach($players as $p){ if(++$i>50) break; echo '<tr><td align="right">'.$i.'</td><td>'.ebs_h((string)($p['name']??'')).'</td><td>'.ebs_h((string)($p['msname']??'')).'</td><td>'.ebs_h((string)($p['kuni']??'')).'</td><td align="right">'.number_format((int)($p['win']??0)).'</td><td align="right">'.number_format((int)($p['lose']??0)).'</td><td align="right">'.number_format(ebs_player_contrib_value($p)).'</td></tr>'; }
if($i===0) echo '<tr><td colspan="7" align="center">NoData</td></tr>'; echo '</table></center></body></html>';
?>
