<?php
declare(strict_types=1);
require_once __DIR__ . '/lib_ebs.php';
/**
 * 원본 legacy 파일: ebs_sub1.php
 * PHP 8.4 파일당 1:1 대응 변환 파일.
 * 원본 주석은 PHP // 주석으로 보존하고, 기존 실행 의존은 제거하고 PHP 8.4 파일 기반으로 동작시킨다.
 * 유지보수 시 원본 sub 이름과 아래 ebs_함수명을 대조한다.
 */
// 아래는 라이센스표시이므로 절대로 삭제수정하지 마세요 추가는 가능

function ebs_HEADER(): void {
    ebs_header_html();
    ebs_record_post('ebs_sub1.php::HEADER');
    // PHP 8.4: 원본 legacy의 상단 HTML 헤더만 출력한다. 카피라이트는 FOOTER에서만 하단 출력한다.
    echo '<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML//EN">
<html><head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>ENDLESS BATTLE</title></head>
<body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="margin:0px 0px 0px 0px;" oncontextmenu="return false;">';
}

function ebs_FOOTER(): void {
    ebs_header_html();
    ebs_record_post('ebs_sub1.php::FOOTER');
    // PHP 8.4: 라이선스/한글화 표시는 원본 의도대로 하단에만 출력한다.
    echo '<div align="center" style="font-size:15px;font-weight:bold;color:#555555;margin-top:30px;">';
    echo 'The ENDLESS BATTLE Program Satellite '.ebs_h(ebs_v('VER')).'<br>Produce By ';
    echo '<a href="http://www.ngcoms.net/" style="font-size:15px;color:#555555;"><font face="Verdana">&copy NET GAME Communications</font></a> All Right Reserved.<br>';
    echo '<a href="http://adonas.com/" style="font-size:15px;color:#555555;">한글화 by adonas</a>';
    echo '</div>';
}

function ebs_FILE_INPORT(): void {
    ebs_header_html();
    ebs_record_post('ebs_sub1.php::FILE_INPORT');
    $players = ebs_players_load();
    $countries = ebs_json_load('countrydata');
    ebs_render_sub_result('파일 저장소 읽기', '플레이어 '.number_format(count($players)).'명 / 국가 '.number_format(count($countries)).'건을 PHP 파일 저장소에서 읽었습니다.');
}

function ebs_FILE_CONVERT(): void {
    ebs_header_html();
    ebs_record_post('ebs_sub1.php::FILE_CONVERT');
    $players = ebs_players_load();
    $fixed = 0;
    foreach ($players as $key=>$p) {
        if (!is_array($p)) continue;
        $before = json_encode($p, JSON_UNESCAPED_UNICODE);
        ebs_player_sync_common($p);
        if (json_encode($p, JSON_UNESCAPED_UNICODE) !== $before) { ebs_player_save_one((string)($p['name'] ?? $key), $p); $fixed++; }
    }
    ebs_render_sub_result('파일 저장소 보정', '플레이어 raw 필드 동기화 '.number_format($fixed).'건을 처리했습니다.');
}

function ebs_REPAIR(): void {
    ebs_header_html();
    ebs_record_post('ebs_sub1.php::REPAIR');
    [$key, $me, $players, $err] = ebs_require_player();
    if ($err !== '' || $key === null || !is_array($me)) { ebs_render_sub_result('수리 상태', ebs_h($err ?: '로그인 정보가 없습니다.')); return; }
    $msg = 'HP '.number_format((int)($me['hp'] ?? 0)).' / '.number_format((int)($me['max_hp'] ?? 0)).' , EN '.number_format((int)($me['en'] ?? 0)).' / '.number_format((int)($me['max_en'] ?? 0)).' 입니다. 수리는 도시 메뉴의 RR 처리에서 수행됩니다.';
    ebs_render_sub_result('수리 상태', $msg);
}

function ebs_RANK(): void {
    ebs_header_html();
    ebs_record_post('ebs_sub1.php::RANK');
    $players = ebs_players_load();
    uasort($players, static function(array $a, array $b): int { return ((int)($b['level'] ?? 1)) <=> ((int)($a['level'] ?? 1)); });
    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>RANK</title></head><body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="font-size:13px;"><center><table border="1" cellspacing="0" cellpadding="4" bordercolor="'.ebs_h(ebs_v('TABLE_BORDER')).'" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'"><tr bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'"><td>순위</td><td>파일럿</td><td>레벨</td><td>승/패</td></tr>';
    $r=1; foreach ($players as $name=>$p) { if (!is_array($p)) continue; echo '<tr><td align="right">'.$r.'</td><td>'.ebs_h((string)($p['name'] ?? $name)).'</td><td align="right">'.number_format((int)($p['level'] ?? 1)).'</td><td>'.number_format((int)($p['win'] ?? 0)).'/'.number_format((int)($p['lose'] ?? 0)).'</td></tr>'; if (++$r>50) break; }
    echo '</table></center></body></html>';
}

function ebs_STATUS_CONVERT(): void {
    ebs_header_html();
    ebs_record_post('ebs_sub1.php::STATUS_CONVERT');
    [$key, $me, $players, $err] = ebs_require_player();
    if ($err !== '' || $key === null || !is_array($me)) { ebs_render_sub_result('상태 변환', ebs_h($err ?: '로그인 정보가 없습니다.')); return; }
    ebs_player_sync_common($me);
    ebs_player_save_one((string)($me['name'] ?? $key), $me);
    ebs_render_sub_result('상태 변환', '현재 플레이어의 표시용/raw 상태 필드를 PHP 저장 방식에 맞춰 동기화했습니다.');
}

function ebs_DATE_DECORD(): void {
    ebs_header_html();
    ebs_record_post('ebs_sub1.php::DATE_DECORD');
    ebs_render_sub_result('날짜 변환', '현재 서버시각: '.date('Y-m-d H:i:s').' / 원본형식: '.date('YmdHis'));
}

function ebs_ERROR(): void {
    ebs_header_html();
    ebs_record_post('ebs_sub1.php::ERROR');
    // 원본 연결 함수: FOOTER, HEADER
    echo '<script language="JavaScript">
alert(\''.ebs_v('_').'\\
'.ebs_v('_').'\\
'.ebs_v('_').'\')\\;

</script>';
}

function ebs_LOCK(): void {
    ebs_header_html();
    ebs_record_post('ebs_sub1.php::LOCK');
    ebs_render_sub_result('잠금 상태', '파일 저장은 ebs_read/ebs_write 공통 함수에서 공유잠금/배타잠금으로 처리됩니다.');
}

function ebs_UNLOCK(): void {
    ebs_header_html();
    ebs_record_post('ebs_sub1.php::UNLOCK');
    ebs_render_sub_result('잠금 해제', '요청 단위 잠금은 파일 입출력 종료 시 자동 해제됩니다.');
}

function ebs_JScfm(): void {
    ebs_header_html();
    ebs_record_post('ebs_sub1.php::JScfm');
    echo '	<script language="JavaScript">
	<!--
	function '.ebs_v('fct').' (){
		if (confirm(\''.ebs_v('msg').'\') == true){return true;}else{return false}
	}
	//-->
	</script>';
}

$map = [
    'HEADER' => 'ebs_HEADER',
    'FOOTER' => 'ebs_FOOTER',
    'FILE_INPORT' => 'ebs_FILE_INPORT',
    'FILE_CONVERT' => 'ebs_FILE_CONVERT',
    'REPAIR' => 'ebs_REPAIR',
    'RANK' => 'ebs_RANK',
    'STATUS_CONVERT' => 'ebs_STATUS_CONVERT',
    'DATE_DECORD' => 'ebs_DATE_DECORD',
    'ERROR' => 'ebs_ERROR',
    'LOCK' => 'ebs_LOCK',
    'UNLOCK' => 'ebs_UNLOCK',
    'JScfm' => 'ebs_JScfm',
];
if (empty($GLOBALS['EBS_SUPPRESS_SUB1_DISPATCH'])) { ebs_dispatch($map, 'ebs_HEADER'); }
?>
