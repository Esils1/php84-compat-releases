<?php
declare(strict_types=1);
require_once __DIR__ . '/lib_ebs.php';
/**
 * 원본 legacy 파일: mainte.php
 *
 * 개인 무기 보조 관리 스크립트의 PHP 8.4 대응 파일이다.
 * 원본의 이전 파일 저장 설명은 제거하고, PHP 변환본은 data/weapons.json과 user/*.json만 사용한다.
 * 외부 실행 함수와 별도 서버형 저장소는 사용하지 않는다.
 */
$cmd = ebs_cmd('TOP');
$public = ['TOP','LOGOUT'];
if ($cmd === 'MAINTE' && ebs_admin_ok()) { $cmd = 'MAINTE2'; }
if (!in_array($cmd, $public, true) && !ebs_admin_ok()) { ebs_admin_login_form('mainte.php', '개인 무기 메인트넌스'); return; }
switch ($cmd) {
    case 'ADMIN_ACTION':
        $action = ebs_param('admin_action', 'PLAYER_EDIT');
        if ($action === 'USER_REPAIR') { ebs_admin_user_repair_screen('mainte.php'); break; }
        if ($action === 'DEL') { ebs_admin_delete_player(); break; }
        ebs_admin_player_edit_screen('mainte.php'); break;
    case 'PLAYER_EDIT':
        ebs_admin_player_edit_screen('mainte.php'); break;
    case 'LOGOUT': ebs_admin_logout(); break;
    case 'TOP':
        if (ebs_admin_ok()) { ebs_admin_menu('mainte.php'); } else { ebs_admin_login_form('mainte.php', '개인 무기 메인트넌스'); }
        break;
    case 'MAINTE':
    case 'MAINTE2':
        if (ebs_admin_ok()) { ebs_admin_menu('mainte.php'); } else { ebs_admin_login_form('mainte.php', '개인 무기 메인트넌스'); }
        break;
    case 'ALLWEAPONS':
    case 'WEAPON':
        ebs_admin_weapon_screen('mainte.php');
        break;
    case 'WEAPON_SAVE':
    case 'CHANGE':
        ebs_admin_weapon_save();
        break;
    case 'BOUGU_DATA':
    case 'ARMOR':
        ebs_admin_bougu_screen('mainte.php');
        break;
    case 'BOUGU_SAVE':
        ebs_admin_bougu_save();
        break;
    case 'NOTICE':
        ebs_admin_notice_screen('mainte.php');
        break;
    case 'NOTICE_SAVE':
        ebs_admin_notice_save();
        break;
    case 'CONFIG_EDIT':
        ebs_admin_config_screen('mainte.php');
        break;
    case 'CONFIG_SAVE':
        ebs_admin_config_save();
        break;
    case 'COUNTRY':
    case 'COUNTRY_EDIT':
        ebs_admin_countries('mainte.php');
        break;
    case 'COUNTRY_CREATE':
        ebs_admin_create_country();
        break;
    case 'COUNTRY_DELETE':
        ebs_admin_delete_country();
        break;
    case 'KAIZAN':
        ebs_admin_update_country();
        break;
    case 'PLAYER':
        ebs_admin_players('mainte.php');
        break;
    case 'SYUSEI':
    case 'SYUSEI2':
        ebs_admin_player_edit_screen('mainte.php');
        break;
    case 'PLCHANGE':
        ebs_admin_update_player();
        break;
    case 'DELETE':
    case 'DELETE2':
        ebs_admin_delete_player();
        break;
    case 'BACKUP':
        ebs_admin_backup_screen('mainte.php');
        break;
    case 'HISTORY_EDIT':
    case 'HISTORY_EDIT2':
    case 'HISMAKE':
    case 'HISMAKES': ebs_admin_history_public_screen('mainte.php'); break;
    case 'HISTORY_EDIT_SAVE':
    case 'HISMAKES_SAVE': ebs_admin_history_public_save('mainte.php'); break;
    case 'UPDATE_EDIT':
    case 'UPDATE_EDIT2':
    case 'UPDATA':
    case 'UPDMAKE':
    case 'UPDMAKES': ebs_admin_update_public_screen('mainte.php'); break;
    case 'UPDATE_EDIT_SAVE':
    case 'UPDMAKES_SAVE': ebs_admin_update_public_save('mainte.php'); break;
    case 'USER_REPAIR':
        ebs_admin_user_repair_screen('mainte.php');
        break;
    case 'USER_REPAIR_RUN':
        ebs_admin_user_repair_run();
        break;
    case 'MAINTE_LOG':
        ebs_admin_log_screen('mainte.php');
        break;
    case 'HUKUGEN':
        ebs_admin_restore_run();
        break;
    default:
        ebs_admin_menu('mainte.php');
        break;
}
?>
