<?php
declare(strict_types=1);
require_once __DIR__ . '/lib_ebs.php';
/**
 * 원본 legacy 파일: ebs_sub3.php
 * PHP 8.4 파일당 1:1 대응 변환 파일.
 * 원본 주석은 PHP // 주석으로 보존하고, 기존 실행 의존은 제거하고 PHP 8.4 파일 기반으로 동작시킨다.
 * 유지보수 시 원본 sub 이름과 아래 ebs_함수명을 대조한다.
 */
// ＝＝＝＝＝＝＝＝＝＝중복 IP 체크
// @OK_HOST=('999.999.999.999','888.888.888.888');
// &file_INPORT(P);
// }
// ＝＝＝＝＝＝＝＝＝＝重複IPチェック終わり
// ------------------자동 회복하는 HP바 (%회복)-------------------
// -----------------------여기까지---------------------------
// --------------자동으로 회복하는 EN 바(%회복)-------------
// ------------------------여기까지-----------------
// -------------------------경험치 바로 표시 ---------------
// --------------------여기까지---------------------
// 채팅방 option 주고 싶으면 아래 코맨트 제거 (예로 글씨 크게, 대화방 세로형)
// PHP 채팅/닉네임 연동 보정 시작 ###################
// $usernickz= 유저 별명/닉네임 변수; 없으면 그냥 my $usernickz = $userz; 해보세요.
// PHP 채팅/닉네임 연동 보정 끝 ###################
// -------------------------- 여기까지 -----------------------
// ===============================
// 참전자 표시
// ===============================
// ===============================
// 참전자 표시 끝
// ===============================

function ebs_FRAME(): void {
    ebs_header_html();
    ebs_record_post('ebs_sub3.php::FRAME');
    $upperFrame = max(300, min(460, (int)ebs_v('UPPER_FRAME', '380')));
    echo '<html><head>
		<title>ENDLESS BATTLE</title></head>
			<frameset rows="58,*" border="0" frameborder="0" framespacing="0">
		<frame name="Menu" src="g.php" scrolling="no" noresize>
<frameset rows="'.$upperFrame.',*">
		<frame name="Main" src="'.ebs_v('MAIN_SCRIPT').'?LOGIN">
		<frame name="Sub" src="'.ebs_v('MAIN_SCRIPT').'?LOG0">
						</frameset>

						</frameset>
		</html>';
}

function ebs_STATUS(): void {
    ebs_header_html();
    ebs_record_post('ebs_sub3.php::STATUS');
    ebs_bootstrap_runtime_counts();
    $pname = ebs_clean_login_value(ebs_param('pname', ebs_cookie_value('pname', '')));
    $pass  = ebs_clean_login_value(ebs_param('pass', ebs_cookie_value('pass', '')));
    $players = ebs_players_load();
    $key = ebs_find_player_key($pname, $players);
    if ($key !== null && isset($players[$key]) && is_array($players[$key])) {
        $p = $players[$key];
        if (!ebs_password_matches($p, $pass)) { ebs_error_page('Error', '패스워드가 틀립니다.'); return; }
        $pname = (string)($p['name'] ?? $key);
        ebs_apply_player_recovery($p);
        ebs_apply_levelup($p);
        ebs_touch_player_activity($p);
        ebs_player_sync_common($p);
        $players[$key] = $p;
        ebs_players_save($players);
        if ($pname !== '') ebs_set_login_cookie($pname, $pass);
    } else {
        $p = [];
    }
    if (!$p) { ebs_error_page('Error', '자신의 등록 데이터를 찾을 수 없습니다.'); return; }

    $msname = ebs_plv($p, 3, $pname);
    $hp=ebs_plv_int($p,15,4000); $mhp=max(1,ebs_plv_int($p,16,4000));
    $en=ebs_plv_int($p,17,200); $men=max(1,ebs_plv_int($p,18,200));
    $level=ebs_plv_int($p,29,ebs_plv_int($p,0,1)); $exp=ebs_plv_int($p,30,0); $need=ebs_level_threshold($level); $money=ebs_plv_int($p,8,0);
    $st = [ebs_plv_int($p,19,0), ebs_plv_int($p,20,0), ebs_plv_int($p,21,0), ebs_plv_int($p,22,0)];
    $hpw=max(0,min(100,(int)floor($hp/$mhp*100))); $enw=max(0,min(100,(int)floor($en/$men*100)));
    $weapon=ebs_plv($p,9,''); [$weaponId,$weaponLvRaw] = array_pad(explode('!', $weapon, 2), 2, '0'); $weaponRow = ebs_weapon_table()[$weaponId] ?? ebs_weapon_table()[$weapon] ?? [];
    $weaponName = (string)($weaponRow[0] ?? ($weapon !== '' ? $weapon : '무장비'));
    $weaponLv = (int)floor(((int)$weaponLvRaw)/(int)max(1,(int)ebs_v('WEAPON_LVUP','100')));
    $weaponExp = ((int)$weaponLvRaw)%(int)max(1,(int)ebs_v('WEAPON_LVUP','100'));
    [$w2id,$w2name,$w2lv,$w2exp] = ebs_calc_weapon_label((string)($p['weapon2'] ?? ''));
    [$w3id,$w3name,$w3lv,$w3exp] = ebs_calc_weapon_label((string)($p['weapon3'] ?? ''));
    $armorRaw = (string)($p['armor'] ?? ebs_player_raw_get($p,32,'')); [$armorId,$armorDur]=array_pad(explode('!', $armorRaw, 2), 2, '');
    $armorTable = ebs_bougu_table(); $armorRow = ($armorId !== '' && isset($armorTable[$armorId])) ? $armorTable[$armorId] : [];
    $armorName = $armorRow ? (string)($armorRow[0] ?? $armorId) : '';
    $armorSpec = $armorRow ? (string)($armorRow[9] ?? ($armorRow[8] ?? '')) : '';
    $icon=ebs_normalize_icon(ebs_plv($p,27,'1'), '1'); $color=ebs_color(ebs_plv($p,13,'#ffffff'));
    $countries = ebs_country_records();
    $onlineRows = ebs_online_players($players, 900);
    $active = count($onlineRows);
    $onlineNames = ebs_online_names_text($players, 900);
    $rankLabel = ebs_player_rank_label($p);
    $classLabel = ebs_player_class_label($p);
    $charaLabel = ebs_chara_label((string)($p['chara'] ?? ebs_player_raw_get($p,12,'0')));
    $contrib = ebs_player_contrib_value($p);
    $jobValue = ebs_player_job_value($p);

    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>ENDLESS BATTLE</title></head>';
    echo '<body '.ebs_bg_attr('BG_STATUS').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" link="'.ebs_h(ebs_v('LINK')).'" style="margin:0;font-size:13px;" oncontextmenu="return false;">';
    echo "<script>try{if(parent&&parent.frames&&parent.frames['Menu']){parent.frames['Menu'].location.replace('g.php?online='+(new Date()).getTime());}}catch(e){}</script>";
    echo '<form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST" name="FM" target="Sub" style="margin:0">';
    echo '<input type="hidden" name="cmd" value=""><input type="hidden" name="b_mode" value=""><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'">';
    echo '<script>function Move(){document.FM.submit();}</script>';
    echo '<script>var EBS_HP='.(int)$hp.',EBS_MHP='.(int)$mhp.',EBS_EN='.(int)$en.',EBS_MEN='.(int)$men.',EBS_HPR='.(float)((float)ebs_v('HP_REPAIR','30') + ((int)$mhp * (float)ebs_v('HP_REPAIR2','0.5') * 0.01)).',EBS_ENR='.(float)((float)ebs_v('EN_REPAIR','1') + ((int)$men * (float)ebs_v('EN_REPAIR2','0.5') * 0.01)).';function EBSRepairTick(){if(EBS_HP<EBS_MHP){EBS_HP=Math.min(EBS_MHP,EBS_HP+EBS_HPR);var hp=Math.round(EBS_HP);var h=document.getElementById("j_hp");var b=document.getElementById("hpb");if(h)h.innerHTML=hp;if(b)b.style.width=Math.max(0,Math.min(100,Math.floor(hp/EBS_MHP*100)))+"%";}if(EBS_EN<EBS_MEN){EBS_EN=Math.min(EBS_MEN,EBS_EN+EBS_ENR);var en=Math.round(EBS_EN);var e=document.getElementById("j_en");var eb=document.getElementById("epb");if(e)e.innerHTML=en;if(eb)eb.style.width=Math.max(0,Math.min(100,Math.floor(en/EBS_MEN*100)))+"%";}}setInterval(EBSRepairTick,1000);</script>';

    echo '<table width="100%" cellspacing="0" cellpadding="2" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" style="font-size:13px;color:'.ebs_h(ebs_v('FONT_COLOR')).';table-layout:fixed;">';
    echo '<tr><td colspan="4" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'"><b style="font-size:18px;color:'.ebs_h($color).'">'.ebs_h($pname).'</b> <span>('.ebs_h($msname).')</span><span style="float:right;">계급 '.$rankLabel.' / 작위 '.ebs_h($classLabel).' / 성격 '.ebs_h($charaLabel).' / 공헌도 '.number_format($contrib).' / 참전자 '.count($players).'명 / 국가 '.count($countries).'개 / 현재접속 '.$active.'명</span></td></tr>';
    echo '<tr>';
    echo '<td width="118" valign="top" align="center"><img src="'.ebs_h(ebs_v('IMG_FOLDER2')).'/'.ebs_h($icon).'.gif"><br>'.ebs_h($msname).'<br>계급 '.$rankLabel.'<br>작위('.ebs_h($classLabel).')<br>성격('.ebs_h($charaLabel).')<br>공헌도('.number_format($contrib).')<br>숙련('.ebs_h(ebs_plv($p,24,'0')).')<br>경험치 프리('.ebs_h(ebs_plv($p,73,'0')).')<br>전체 프리('.ebs_h(ebs_plv($p,75,'0')).')<br><a href="'.ebs_h(ebs_v('MAIN_SCRIPT')).'?STATUSUP&amp;pname='.rawurlencode($pname).'&amp;pass='.rawurlencode($pass).'" target="Sub">발전가능</a></td>';
    echo '<td width="205" valign="top"><table width="100%" cellspacing="1" cellpadding="2" style="font-size:13px;color:'.ebs_h(ebs_v('FONT_COLOR')).';">';
    foreach ([['공격',0],['방어',1],['명중',3],['속도',2],['행운',4]] as $row) { $val = $row[1]===4 ? 10 : ($st[$row[1]] ?? 0); echo '<tr><td width="48">'.$row[0].'</td><td>'.ebs_status_rank($val).'('.ebs_h((string)$val).') <span style="display:inline-block;width:105px;background:#004010;border-left:3px solid red;height:18px;vertical-align:middle;"></span></td></tr>'; }
    echo '<tr><td colspan="2" align="center"><font color="#f7e957">이벤트 [ '.ebs_h(ebs_v('eventco','-')).' ] 가 진행중입니다.</font></td></tr>';
    echo '<tr><td colspan="2">도우미 : 네꼬 [ '.ebs_h(ebs_v('tip')).' ]</td></tr>';
    echo '</table></td>';
    echo '<td width="190" valign="top"><b>HP</b> <span style="float:right"><span id="j_hp">'.$hp.'</span>/'.$mhp.'</span><br><div style="width:170px;background:#303030"><div id="hpb" style="width:'.$hpw.'%;background:#00a0ff;height:5px"></div></div>';
    echo '<b>EN</b> <span style="float:right"><span id="j_en">'.$en.'</span>/'.$men.'</span><br><div style="width:170px;background:#303030"><div id="epb" style="width:'.$enw.'%;background:#00a0ff;height:5px"></div></div>';
    echo 'Level <b>'.$level.'</b><br>EXP <b>'.$exp.'/'.$need.'</b><br>Gold <b>'.number_format($money).'</b><br>금괴 <b>'.ebs_h(ebs_plv($p,72,'0')).'개</b><br>전적 <b>'.ebs_h((string)(ebs_plv_int($p,41,0)+ebs_plv_int($p,42,0))).' 전 '.ebs_h(ebs_plv($p,41,'0')).'승 '.ebs_h(ebs_plv($p,42,'0')).'패</b><br>계급 <b>'.$rankLabel.'</b><br>작위 <b>'.ebs_h($classLabel).'</b>('.number_format($jobValue).')<br>공헌도 <b>'.number_format($contrib).'</b><br>성격 <b>'.ebs_h($charaLabel).'</b></td>';
    echo '<td valign="top" style="line-height:1.55;border-left:1px solid '.ebs_h(ebs_v('TABLE_BORDER')).';padding-left:8px;">';
    echo '<span style="background:#606060;padding:2px 5px">장비</span> [<img src="'.ebs_h(ebs_v('buimg')).'/'.ebs_h((string)($weaponRow[9] ?? '00')).'.png" width="16" height="16" onerror="this.src=\''.ebs_h(ebs_v('buimg')).'/00.gif\'">] <b>'.ebs_h($weaponName).'</b> Lv.'.ebs_h((string)$weaponLv).'/exp.'.ebs_h((string)$weaponExp).'<br>';
    echo '<span style="background:#606060;padding:2px 5px">성능</span> 공격：'.ebs_h((string)($weaponRow[1] ?? '0')).' 명중：'.ebs_h((string)($weaponRow[2] ?? '0')).' EN：'.ebs_h((string)($weaponRow[4] ?? '0')).' 효과：'.ebs_h((string)($weaponRow[7] ?? ($weaponRow[5] ?? '없음'))).'<br>';
    echo '<span style="background:#606060;padding:2px 5px">예비</span> '.($w2id !== '' ? ebs_h($w2name.' Lv.'.$w2lv.'/exp.'.($w2exp % max(1,(int)ebs_v('WEAPON_LVUP','100')))) : '').'<br>';
    echo '<span style="background:#606060;padding:2px 5px">예비</span> '.($w3id !== '' ? ebs_h($w3name.' Lv.'.$w3lv.'/exp.'.($w3exp % max(1,(int)ebs_v('WEAPON_LVUP','100')))) : '').'<br>';
    echo '<span style="background:#606060;padding:2px 5px">보강장비</span> '.($armorName !== '' ? ebs_h($armorName) : '').'<br>';
    if ($armorName !== '') echo '<span style="background:#606060;padding:2px 5px">성능</span> '.ebs_h($armorSpec).' 내구:'.ebs_h($armorDur).'<br>';
    echo '<span style="background:#606060;padding:2px 5px">성격/계급</span> '.ebs_h($charaLabel).' / '.$rankLabel.' / '.ebs_h($classLabel).' / 공헌 '.number_format($contrib).'<br>';
    echo '<span style="background:#606060;padding:2px 5px">LASTBATTLE</span> '.ebs_h((string)($p['battle_log'] ?? '')).'</td>';
    echo '</tr>';
    echo '<tr><td colspan="4" align="center">';
    $button = static function(string $label, string $cmd = '', string $url = '', string $mode = ''): void {
        if ($url !== '') {
            echo '<input type="button" value="'.ebs_h($label).'" '.ebs_v('STYLE_B1').' onClick="parent.Sub.location.replace(\''.ebs_h($url).'\')"> ';
        } else {
            echo '<input type="submit" value="'.ebs_h($label).'" '.ebs_v('STYLE_B1').' onClick="document.FM.target=\'Sub\';document.FM.cmd.value=\''.ebs_h($cmd).'\';document.FM.b_mode.value=\''.ebs_h($mode).'\';Move()"> ';
        }
    };
    echo '<table cellpadding="0" cellspacing="0" border="0" align="center"><tr><td>&nbsp;</td><td>';
    $button('전투','BATTLE_1','','전투'); echo '</td><td>';
    $button('망명','BATTLE_1','','망명'); echo '</td>';
    if (ebs_v('NAIRAN_MODE') !== '') { echo '<td>'; $button('내란','BATTLE_1','','내란'); echo '</td>'; }
    echo '<td>&nbsp;</td><td>&nbsp;</td><td>'; $button('장비','EQUIPMENT'); echo '</td><td>';
    $button('보강','BOUGU'); echo '</td><td>'; $button(ebs_v('CUSTOM_NAME','개조'),'CUSTOMING'); echo '</td><td>&nbsp;</td><td>';
    $button('자국','', ebs_v('MAIN_SCRIPT').'?MY_LIST'); echo '</td><td>'; $button('정보','', ebs_v('MAIN_SCRIPT').'?C_LIST'); echo '</td><td>';
    $button('역사','HIS'); echo '</td><td>'; $button('도시','CITY'); echo '</td><td>&nbsp;</td><td>'; $button('특별','SPS');
    echo '</td></tr><tr><td>&nbsp;</td><td>';
    echo '<input type="submit" value="갱신" '.ebs_v('STYLE_B1').' onClick="document.FM.target=\'Main\';document.FM.cmd.value=\'MAIN_FRAME\';Move()"> ';
    echo '</td><td>'; $button('던전','', './dungeon.php?pname='.rawurlencode($pname).'&pass='.rawurlencode($pass)); echo '</td><td>'; $button('채팅','CHAT'); echo '</td><td>&nbsp;</td><td>&nbsp;</td><td>';
    $button('거래','TRADE'); echo '</td><td>'; $button('세력','', 'ballance.php'); echo '</td><td>'; $button('발언','COM'); echo '</td><td>&nbsp;</td><td>';
    $button('랭킹','', 'ranking.php'); echo '</td><td>'; $button('특수','SPC'); echo '</td><td>'; $button('업뎃','UPD'); echo '</td><td>'; $button('도박','LOTO'); echo '</td><td>&nbsp;</td><td>';
    $button('보드','', './board.php?pname='.rawurlencode($pname).'&pass='.rawurlencode($pass)); echo '</td><td>'; $button('편지','', './kaigisitu.php'); echo '</td><td colspan="2">&nbsp;</td></tr></table>';
    echo '</td></tr></table></form></body></html>';
}


function ebs_BORDER(): void {
    ebs_header_html();
    ebs_record_post('ebs_sub3.php::BORDER');
    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>ENDLESS BATTLE</title></head><body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="margin:0;font-size:13px;">';
    ebs_render_country_buttons('Sub');
    ebs_render_country_detail();
    echo '</body></html>';
}

function ebs_userKey(): void {
    ebs_header_html();
    ebs_record_post('ebs_sub3.php::userKey');
    [$key, $me, $players, $err] = ebs_require_player();
    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>ENDLESS BATTLE</title></head><body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="margin:0;font-size:13px;">';
    echo '<center><table border="1" cellspacing="0" cellpadding="6" bordercolor="'.ebs_h(ebs_v('TABLE_BORDER')).'" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'">';
    echo '<tr><td bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'" align="center"><b>파일럿 키 확인</b></td></tr>';
    if ($err !== '' || $key === null || !is_array($me)) echo '<tr><td>'.ebs_h($err ?: '로그인 정보가 없습니다.').'</td></tr>';
    else echo '<tr><td>파일럿 '.ebs_h((string)($me['name'] ?? $key)).' / 기체 '.ebs_h((string)($me['msname'] ?? '')).' / 저장키 '.ebs_h((string)$key).'</td></tr>';
    echo '</table></center></body></html>';
}

function ebs_CNTRY_LIST(): void {
    ebs_header_html();
    ebs_record_post('ebs_sub3.php::CNTRY_LIST');
    // 원본 CNTRY_LIST: 국가 버튼 출력 후 선택 국가의 국민/국비/부대 정보를 표시한다.
    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>ENDLESS BATTLE</title></head><body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" link="'.ebs_h(ebs_v('LINK')).'" style="margin:0;font-size:13px;" oncontextmenu="return false;"><center>';
    ebs_render_country_buttons('Sub');
    ebs_render_country_detail();
    echo '</center></body></html>';
}

function ebs_FRAME2(): void {
    // 원본 GAME_FRAME 경로: 프레임 재구성 요청은 TOP 프레임 출력과 동일하게 처리한다.
    ebs_FRAME();
}

function ebs_MY_LIST(): void {
    // 원본 MY_LIST: 자국/참가자 목록. PHP 파일 저장소의 플레이어 목록을 표로 출력한다.
    ebs_header_html();
    $players = ebs_players_load();
    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>ENDLESS BATTLE</title></head><body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="font-size:13px;margin:0;">';
    echo '<center><table bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" cellpadding="3" cellspacing="1"><tr><td colspan="5" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'" align="center"><b>참가자 목록</b></td></tr>';
    echo '<tr><td>Name</td><td>Lv</td><td>국가</td><td>MS</td><td>Gold</td></tr>';
    foreach ($players as $name=>$p) { if (!is_array($p)) continue; echo '<tr><td>'.ebs_h((string)($p['name'] ?? $name)).'</td><td align="right">'.ebs_h((string)($p['level'] ?? 1)).'</td><td>'.ebs_h((string)($p['kuni'] ?? '')).'</td><td>'.ebs_h((string)($p['msname'] ?? '')).'</td><td align="right">'.ebs_h((string)($p['money'] ?? 0)).'</td></tr>'; }
    echo '</table></center></body></html>';
}

function ebs_CUSTOMIZE(): void {
    // 원본 CUSTOMIZE: 망명/내란 보조, 코멘트, 부대, 국가 관련 Cmode를 file 대신 user/*.json에 반영한다.
    ebs_header_html();
    [$key, $me, $players, $err] = ebs_require_player();
    if ($err !== '' || !is_array($me) || $key === null) { ebs_error_page('Error', $err ?: '자신의 등록 데이터를 찾을 수 없습니다.'); return; }
    $pname=(string)($me['name'] ?? $key); $pass=ebs_param('pass', ebs_cookie_value('pass','')); $cmode=ebs_param('Cmode','');
    if ($cmode !== '') {
        $msg='처리가 반영되었습니다.';
        switch ($cmode) {
            case '망명':
                $to=ebs_param('boumeiC','');
                if ($to !== '') { $me['kuni']=$to; $me['job']='0'; $me['unit']=''; $me['unit_rank']='0'; ebs_player_raw_set($me,5,$to); ebs_player_raw_set($me,6,'0'); ebs_player_raw_set($me,28,''); $msg='망명 처리가 완료되었습니다.'; }
                break;
            case '변경':
                $me['comment']=function_exists('mb_substr') ? mb_substr(ebs_param('com',''),0,80,'UTF-8') : substr(ebs_param('com',''),0,80); ebs_player_raw_set($me,7,(string)$me['comment']); $msg='코멘트를 변경했습니다.'; break;
            case '성격변경':
                $me['chara']=ebs_param('chara',(string)($me['chara'] ?? '0')); ebs_player_raw_set($me,12,(string)$me['chara']); $me['money']=max(0,(int)($me['money'] ?? 0)-20000); $msg='성격을 변경했습니다.'; break;
            case '대사':
                $me['battle_comment']=function_exists('mb_substr') ? mb_substr(ebs_param('bacom',''),0,80,'UTF-8') : substr(ebs_param('bacom',''),0,80); ebs_player_raw_set($me,34,(string)$me['battle_comment']); $msg='대사를 변경했습니다.'; break;
            case '입대':
                $me['unit']=ebs_param('inunit',''); ebs_player_raw_set($me,28,(string)$me['unit']); $msg='입대 처리했습니다.'; break;
            case '제대':
                $me['unit']=''; $me['job']='0'; ebs_player_raw_set($me,28,''); ebs_player_raw_set($me,6,'0'); $msg='제대 처리했습니다.'; break;
            case '100만골드기부':
                if ((int)($me['money'] ?? 0) >= 1000000) { $me['money']=(int)$me['money']-1000000; $me['contrib']=(int)($me['contrib'] ?? 0)+1; ebs_player_raw_set($me,43,(string)$me['contrib']); $msg='국비 기부가 완료되었습니다.'; } else $msg='골드가 부족합니다.';
                break;
            case '백작진급': case '후작진급': case '공작진급':
                $cost=['백작진급'=>1,'후작진급'=>5,'공작진급'=>10][$cmode]; $add=['백작진급'=>10,'후작진급'=>10,'공작진급'=>10][$cmode];
                if ((int)($me['contrib'] ?? 0) >= $cost) { $me['job']=(string)((int)($me['job'] ?? 0)+$add); $me['contrib']=(int)$me['contrib']-$cost; ebs_player_raw_set($me,6,(string)$me['job']); ebs_player_raw_set($me,43,(string)$me['contrib']); $msg='진급 처리했습니다.'; } else $msg='공헌도가 부족합니다.';
                break;
            case '스탯리셋':
                $me['st']=[6,6,6,6]; ebs_player_raw_set($me,19,'6'); ebs_player_raw_set($me,20,'6'); ebs_player_raw_set($me,21,'6'); ebs_player_raw_set($me,22,'6'); $msg='스탯을 초기화했습니다.'; break;
        }
        ebs_player_sync_common($me); $players[$key]=$me; ebs_players_save($players); ebs_render_sub_result('CUSTOM', ebs_h($msg)); return;
    }
    echo '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>ENDLESS BATTLE</title></head><body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="font-size:13px;margin:0;">';
    echo '<center><table bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" cellpadding="4" cellspacing="1"><tr><td colspan="2" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'" align="center"><b>개조 / 정비</b></td></tr>';
    foreach (["STATUSUP"=>"능력치 상승", "EQUIPMENT"=>"장비 변경", "BOUGU"=>"보강", "ST_RESET"=>"스테이터스 리셋", "CUSTOMING"=>"기체 개조/성격", "COMMENT"=>"코멘트 변경", "MAKE_T"=>"부대"] as $cmd=>$label) {
        echo '<tr><td>'.ebs_h($label).'</td><td><form action="'.ebs_h(ebs_v('MAIN_SCRIPT')).'" method="POST" target="Sub"><input type="hidden" name="cmd" value="'.ebs_h($cmd).'"><input type="hidden" name="pname" value="'.ebs_h($pname).'"><input type="hidden" name="pass" value="'.ebs_h($pass).'"><input type="submit" value="실행" '.ebs_v('STYLE_B1').'></form></td></tr>';
    }
    echo '</table></center></body></html>';
}

$map = [
    'FRAME' => 'ebs_FRAME',
    'FRAME2' => 'ebs_FRAME2',
    'STATUS' => 'ebs_STATUS',
    'MY_LIST' => 'ebs_MY_LIST',
    'BORDER' => 'ebs_BORDER',
    'userKey' => 'ebs_userKey',
    'CNTRY_LIST' => 'ebs_CNTRY_LIST',
    'TR' => 'ebs_TR',
    'CUSTOMIZE' => 'ebs_CUSTOMIZE',
    '__TOP__' => 'ebs_top_level_output',
];
ebs_dispatch($map, 'ebs_FRAME');
?>
