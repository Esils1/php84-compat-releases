<?php
declare(strict_types=1);
require_once __DIR__ . '/lib_ebs.php';

/** 용병소: user/*.json과 data/youhei_market.json 기반 PHP 8.4 변환 화면. */
function ebs_youhei_header(string $title='용병소'): void {
    ebs_header_html();
    echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>'.ebs_h($title).'</title></head>';
    echo '<body '.ebs_bg_attr('BG_MAIN').' text="'.ebs_h(ebs_v('FONT_COLOR')).'" style="margin:8px;font-size:13px;">';
    echo '<center><table border="1" cellspacing="0" cellpadding="5" bordercolor="'.ebs_h(ebs_v('TABLE_BORDER')).'" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR1')).'" style="min-width:760px;font-size:13px;">';
    echo '<tr><td colspan="8" bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'" align="center"><b>'.ebs_h($title).'</b></td></tr>';
}
function ebs_youhei_footer(): void {
    echo '<tr><td colspan="8" align="center"><a href="youhei.php?cmd=IRIGUTI">용병소</a> | <a href="youhei.php?cmd=SETUMEI">설명</a> | <a href="ebs.php" target="_top">메인</a></td></tr>';
    echo '</table></center></body></html>';
}
function ebs_youhei_hidden(): string {
    return '<input type="hidden" name="pname" value="'.ebs_h(ebs_param('pname', ebs_cookie_value('pname',''))).'"><input type="hidden" name="pass" value="'.ebs_h(ebs_param('pass', ebs_cookie_value('pass',''))).'">';
}
function ebs_youhei_market(): array {
    $market = ebs_json_load('youhei_market');
    return is_array($market) ? $market : [];
}
function ebs_youhei_save_market(array $market): void {
    ksort($market, SORT_NATURAL);
    ebs_json_save('youhei_market', $market);
}
function ebs_youhei_normalize_market(array $market, array $players): array {
    $changed = false;
    foreach ($market as $name => $row) {
        if (!is_array($row) || ebs_find_player_key((string)$name, $players) === null) {
            unset($market[$name]);
            $changed = true;
        }
    }
    if ($changed) ebs_youhei_save_market($market);
    return $market;
}

function ebs_GETCOOK(): void { ebs_IRIGUTI(); }

function ebs_IRIGUTI(): void {
    ebs_bootstrap_players_from_backup();
    $players = ebs_players_load();
    $market = ebs_youhei_normalize_market(ebs_youhei_market(), $players);
    ebs_youhei_header('용병소');
    echo '<tr bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'"><td>상태</td><td>아이콘</td><td>파일럿</td><td>소속</td><td>Lv</td><td>고용비</td><td>메시지</td><td>처리</td></tr>';
    if (!$market) echo '<tr><td colspan="8" align="center">현재 등록된 용병이 없습니다.</td></tr>';
    foreach ($market as $name => $row) {
        if (!is_array($row)) continue;
        $pkey = ebs_find_player_key((string)$name, $players);
        $p = $pkey !== null ? ($players[$pkey] ?? []) : [];
        if (!is_array($p)) $p = [];
        $icon = ebs_normalize_icon((string)($p['icon'] ?? ($row['icon'] ?? '1')));
        $status = (string)($row['status'] ?? 'open');
        $price = max(0, (int)($row['price'] ?? 0));
        echo '<tr><td>'.($status === 'hired' ? '고용중' : '대기').'</td><td align="center"><img src="'.ebs_h(ebs_v('IMG_FOLDER2')).'/'.ebs_h($icon).'.gif" width="32" height="32"></td>';
        echo '<td>'.ebs_h((string)($p['msname'] ?? $name)).'<br><small>'.ebs_h((string)$name).'</small></td><td>'.ebs_h((string)($p['kuni'] ?? '')).'</td><td align="right">'.ebs_h((string)($p['level'] ?? '1')).'</td><td align="right">$'.ebs_h(number_format($price)).'</td><td>'.ebs_h((string)($row['comment'] ?? '')).'</td>';
        echo '<td>';
        if ($status === 'open') {
            echo '<form method="post" action="youhei.php" style="margin:0;" target="Sub">'.ebs_youhei_hidden().'<input type="hidden" name="cmd" value="NYUSATU"><input type="hidden" name="target" value="'.ebs_h((string)$name).'"><input type="submit" value="고용" '.ebs_v('STYLE_B1').'></form>';
        } else {
            echo ebs_h((string)($row['employer'] ?? ''));
        }
        echo '</td></tr>';
    }
    echo '<tr><td colspan="8"><form method="post" action="youhei.php" target="Sub">'.ebs_youhei_hidden().'<input type="hidden" name="cmd" value="IN_MEMBER">고용비 <input name="price" value="50000" size="8"> 메시지 <input name="comment" size="40" maxlength="120"> <input type="submit" value="용병 등록/갱신" '.ebs_v('STYLE_B1').'></form></td></tr>';
    echo '<tr><td colspan="8"><form method="post" action="youhei.php" target="Sub">'.ebs_youhei_hidden().'<input type="hidden" name="cmd" value="RAKUSATU"><input type="submit" value="내 용병 등록 취소" '.ebs_v('STYLE_B1').'></form></td></tr>';
    ebs_youhei_footer();
}

function ebs_SETUMEI(): void {
    ebs_youhei_header('용병소 설명');
    echo '<tr><td colspan="8" style="line-height:1.7;">용병 등록자는 자신의 고용비와 메시지를 등록할 수 있습니다. 고용자는 표시된 고용비를 지불하고 대상 캐릭터를 고용 기록에 남깁니다. 데이터는 <b>data/youhei_market.json</b>에 저장되며 유저 데이터는 기존 <b>user/*.json</b> 구조를 유지합니다.</td></tr>';
    ebs_youhei_footer();
}

function ebs_IN_MEMBER(): void {
    [$key,$me,$players,$err] = ebs_require_player();
    if ($err !== '' || $key === null || !is_array($me)) { ebs_error_page('용병 등록 오류', $err); return; }
    $price = max(0, (int)preg_replace('/\D+/', '', ebs_param('price','0')));
    if ($price < 1) $price = 1;
    $comment = trim(ebs_param('comment',''));
    if ($comment === '') $comment = '고용 가능합니다.';
    $market = ebs_youhei_market();
    $market[$key] = [
        'name' => $key,
        'msname' => (string)($me['msname'] ?? $key),
        'kuni' => (string)($me['kuni'] ?? ''),
        'level' => (int)($me['level'] ?? 1),
        'icon' => ebs_normalize_icon((string)($me['icon'] ?? '1')),
        'price' => $price,
        'comment' => $comment,
        'status' => 'open',
        'updated_at' => date('c'),
    ];
    ebs_youhei_save_market($market);
    ebs_youhei_header('용병 등록 완료');
    echo '<tr><td colspan="8" align="center">용병 등록이 완료되었습니다. 고용비: $'.ebs_h(number_format($price)).'</td></tr>';
    ebs_youhei_footer();
}

function ebs_NYUSATU(): void {
    [$key,$me,$players,$err] = ebs_require_player();
    if ($err !== '' || $key === null || !is_array($me)) { ebs_error_page('용병 고용 오류', $err); return; }
    $target = trim(ebs_param('target',''));
    if ($target === '' || $target === $key) { ebs_error_page('용병 고용 오류', '고용 대상을 확인할 수 없습니다.'); return; }
    $market = ebs_youhei_market();
    if (!isset($market[$target]) || !is_array($market[$target])) { ebs_error_page('용병 고용 오류', '등록된 용병이 아닙니다.'); return; }
    $price = max(0, (int)($market[$target]['price'] ?? 0));
    $money = (int)($me['money'] ?? 0);
    if ($money < $price) { ebs_error_page('용병 고용 오류', '소지금이 부족합니다.'); return; }
    $sellerKey = ebs_find_player_key($target, $players);
    if ($sellerKey === null || !isset($players[$sellerKey]) || !is_array($players[$sellerKey])) { unset($market[$target]); ebs_youhei_save_market($market); ebs_error_page('용병 고용 오류', '대상 캐릭터가 존재하지 않습니다.'); return; }
    $me['money'] = $money - $price;
    $players[$sellerKey]['money'] = (int)($players[$sellerKey]['money'] ?? 0) + $price;
    $me['mercenary'] = ['name'=>$target, 'price'=>$price, 'hired_at'=>date('c')];
    $market[$target]['status'] = 'hired';
    $market[$target]['employer'] = $key;
    $market[$target]['hired_at'] = date('c');
    ebs_player_sync_common($me);
    ebs_player_sync_common($players[$sellerKey]);
    $players[$key] = $me;
    ebs_players_save($players);
    ebs_youhei_save_market($market);
    ebs_youhei_header('용병 고용 완료');
    echo '<tr><td colspan="8" align="center">'.ebs_h($target).' 고용이 완료되었습니다. 지불액: $'.ebs_h(number_format($price)).'</td></tr>';
    ebs_youhei_footer();
}

function ebs_RAKUSATU(): void {
    [$key,$me,$players,$err] = ebs_require_player();
    if ($err !== '' || $key === null || !is_array($me)) { ebs_error_page('용병 취소 오류', $err); return; }
    $market = ebs_youhei_market();
    unset($market[$key]);
    ebs_youhei_save_market($market);
    ebs_youhei_header('용병 등록 취소');
    echo '<tr><td colspan="8" align="center">내 용병 등록을 취소했습니다.</td></tr>';
    ebs_youhei_footer();
}

function ebs_MAINTE(): void { ebs_IRIGUTI(); }
function ebs_REKISI(): void {
    $market = ebs_youhei_market();
    ebs_youhei_header('용병 기록');
    echo '<tr bgcolor="'.ebs_h(ebs_v('TABLE_COLOR2')).'"><td>용병</td><td colspan="2">고용자</td><td colspan="2">고용비</td><td colspan="3">시각</td></tr>';
    foreach ($market as $name=>$row) {
        if (!is_array($row) || (string)($row['status'] ?? '') !== 'hired') continue;
        echo '<tr><td>'.ebs_h((string)$name).'</td><td colspan="2">'.ebs_h((string)($row['employer'] ?? '')).'</td><td colspan="2" align="right">$'.ebs_h(number_format((int)($row['price'] ?? 0))).'</td><td colspan="3">'.ebs_h((string)($row['hired_at'] ?? '')).'</td></tr>';
    }
    ebs_youhei_footer();
}
function ebs_foot(): void { ebs_youhei_footer(); }
function ebs_top_level_output(): void { ebs_IRIGUTI(); }

$map = [
    'GETCOOK'=>'ebs_GETCOOK', 'IRIGUTI'=>'ebs_IRIGUTI', 'SETUMEI'=>'ebs_SETUMEI',
    'REKISI'=>'ebs_REKISI', 'IN_MEMBER'=>'ebs_IN_MEMBER', 'MAINTE'=>'ebs_MAINTE',
    'NYUSATU'=>'ebs_NYUSATU', 'RAKUSATU'=>'ebs_RAKUSATU', 'foot'=>'ebs_foot', '__TOP__'=>'ebs_top_level_output',
];
ebs_dispatch($map, 'ebs_IRIGUTI');
?>
