<?php
/*******************************************************************

  모형정원 제도 2 for PHP

  
  $Id: hako-html.php, v 1.12 2004/08/10 22:00:41 Watson Exp $

*******************************************************************/

if(GZIP == true) {
  // gzip 압축 전송용
  require_once "HTTP/Compress.php";
  $http = new HTTP_Compress;
}

//--------------------------------------------------------------------
#[\AllowDynamicProperties]
class HTML {

  //---------------------------------------------------
  // HTML 헤더 출력
  //---------------------------------------------------
  static function header($data = "") {
    global $init;
    global $PRODUCT_VERSION;

    // 압축 전송
    if(GZIP == true) {
      global $http;
      $http->start();
    }
    header("X-Product-Version: {$PRODUCT_VERSION}");
    header("Content-Type: text/html; charset=UTF-8");
    $css = (empty($data['defaultSkin'])) ? $init->cssList[0] : $data['defaultSkin'];
    print <<<END
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html lang="ko">
<head>
<base href="{$init->imgDir}/">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<link rel="stylesheet" type="text/css" href="{$init->cssDir}/{$css}">
<title>{$init->title}</title>
<script type="text/javascript" src="{$init->baseDir}/hako.js"></script>
</head>
<body>

<div id="LinkHeader">
<a href="http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html">모형정원 제도 스크립트 배포원</a> 
<a href="http://scrlab.g-7.ne.jp/">[PHP]</a>  
<a href="http://AFresh.ub.to" target="_blank"><font color=blue>[한글화 배포처]</font></a> 
[<a href="{$GLOBALS['THIS_FILE']}?mode=conf">섬 등록·설정 변경</a> ]
</div>
<hr>

END;
  }
  //---------------------------------------------------
  // HTML footer 출력
  //---------------------------------------------------
  static function footer() {
    global $init;

    print <<<END
<hr>
<div id="LinkFoot">
관리자:{$init->adminName}(<a href="mailto:{$init->adminEmail}">{$init->adminEmail}</a> )<br>
게시판:(<a href="{$init->urlBbs}">{$init->urlBbs}</a> )<br>
메인 페이지:(<a href="{$init->urlTopPage}">{$init->urlTopPage}</a> )
</div>
</body>
</html>

END;

    if(GZIP == true) {
      global $http;
      $http->output();
    }
  }
  //---------------------------------------------------
  // 최종 업데이트 시각 + 다음 턴 업데이트 시각 출력
  //---------------------------------------------------
  function lastModified($hako) {
    global $init;
    $timeString = date("Y년 m월 d일 H시", $hako->islandLastTime);
    print <<<END
<h2 class="lastModified">최종 업데이트 시간 : $timeString
<span style="font-weight: normal;">
(다음 턴까지 남은 시간
<script type="text/javascript"> <!--
 var nextTime = $hako->islandLastTime + $init->unitTime;
 remainTime(nextTime);
//-->
</script>
</span>
</h2>

END;
   }
}
//--------------------------------------------------------------------
#[\AllowDynamicProperties]
class HtmlTop extends HTML {
  //---------------------------------------------------
  // 메인 페이지
  //---------------------------------------------------
  function main($hako, $data) {
    global $init;

    // 최종 업데이트 시각 + 다음 턴 업데이트 시각 출력
    $this->lastModified($hako);
    if(empty($data['defaultDevelopeMode']) || $data['defaultDevelopeMode'] == "cgi") {
      $radio = "checked"; $radio2 = "";
    } else {
      $radio = ""; $radio2 = "checked";
    }

    print "<h1>{$init->title}</h1>\n";
    if(DEBUG == true) {
      print <<<END
<form accept-charset="UTF-8" action="{$GLOBALS['THIS_FILE']}" method="post">
<input type="hidden" name="mode" value="debugTurn">
<input type="submit" value="턴 진행">
</form>

END;
  }
    print <<<END
<h2 class='Turn'>턴 $hako->islandTurn</h2>
<hr>
<div id="MyIsland">
<h2>내 섬으로</h2>
<form accept-charset="UTF-8" action="{$GLOBALS['THIS_FILE']}" method="post">
내 섬 이름은?<br>
<select name="ISLANDID">
$hako->islandList
</select>
<br>
비밀번호를 입력하세요.<br>
<input type="password" name="PASSWORD" value="{$data['defaultPassword']}" size="32" maxlength="32"><br>
<input type="hidden" name="mode" value="owner">
<input type="radio" name="DEVELOPEMODE" value="cgi" id="cgi" $radio><label for="cgi">통상 모드</label>
<input type="radio" name="DEVELOPEMODE" value="java" id="java" $radio2><label for="java">자바스크립트 모드</label><BR>
<input type="submit" value="개발 화면으로 이동">
</form>
</div>
<hr>

<div ID="IslandView">
<h2>제도 현황</h2>
<p>
섬 이름을 클릭하면 <strong>방문</strong>할 수 있습니다.
</p>
<table border="1">
<tr>
<th {$init->bgTitleCell}>{$init->tagTH_}순위{$init->_tagTH}</th>
<th {$init->bgTitleCell}>{$init->tagTH_}섬{$init->_tagTH}</th>
<th {$init->bgTitleCell}>{$init->tagTH_}인구{$init->_tagTH}</th>
<th {$init->bgTitleCell}>{$init->tagTH_}면적{$init->_tagTH}</th>
<th {$init->bgTitleCell}>{$init->tagTH_}자금{$init->_tagTH}</th>
<th {$init->bgTitleCell}>{$init->tagTH_}식량{$init->_tagTH}</th>
<th {$init->bgTitleCell}>{$init->tagTH_}농장 규모{$init->_tagTH}</th>
<th {$init->bgTitleCell}>{$init->tagTH_}공장 규모{$init->_tagTH}</th>
<th {$init->bgTitleCell}>{$init->tagTH_}채굴장 규모{$init->_tagTH}</th>
</tr>

END;
    for($i = 0; $i < $hako->islandNumber; $i++) {
      $island = $hako->islands[$i];
      $j = $i + 1;
      $id    = $island['id'];
      $pop   = $island['pop'] . $init->unitPop;
      $area  = $island['area'] . $init->unitArea;
      $money = Util::aboutMoney($island['money']);
      $food  = $island['food'] . $init->unitFood;
      $farm  = ($island['farm'] <= 0) ? "보유하지 않음" : $island['farm'] * 10 . $init->unitPop;
      $factory  = ($island['factory'] <= 0) ? "보유하지 않음" : $island['factory'] * 10 . $init->unitPop;
      $mountain = ($island['mountain'] <= 0) ? "보유하지 않음" : $island['mountain'] * 10 . $init->unitPop;
      $comment  = $island['comment'];
      $comment_turn = $island['comment_turn'];
      $monster = '';
      if($island['monster'] > 0) {
        $monster = "<strong class=\"monster\">[괴수 {$island['monster']}마리]</strong>";
      }
      
      $name = "";
      if($island['absent']  == 0) {
        $name = "{$init->tagName_}{$island['name']}섬{$init->_tagName}";
      } else {
        $name = "{$init->tagName2_}{$island['name']}섬({$island['absent']}){$init->_tagName2}";
      }
      if(!empty($island['owner'])) {
        $owner = $island['owner'];
      } else {
        $owner = "?";
      }
      
      $prize = $island['prize'];
      $prize = $hako->getPrizeList($prize);

      if($init->commentNew > 0 && ($comment_turn + $init->commentNew) > $hako->islandTurn) {
        $comment .= " <span class=\"new\">New</span>";
      }
      
      print "<tr>\n";
      print "<th {$init->bgNumberCell} rowspan=\"2\">{$init->tagNumber_}$j{$init->_tagNumber}</th>\n";
      print "<td {$init->bgNameCell} rowspan=\"2\"><a href=\"{$GLOBALS['THIS_FILE']}?Sight={$id}\">{$name}</a>  {$monster}<br>\n{$prize}</td>\n";

      print "<td {$init->bgInfoCell}>$pop</td>\n";
      print "<td {$init->bgInfoCell}>$area</td>\n";
      print "<td {$init->bgInfoCell}>$money</td>\n";
      print "<td {$init->bgInfoCell}>$food</td>\n";
      print "<td {$init->bgInfoCell}>$farm</td>\n";
      print "<td {$init->bgInfoCell}>$factory</td>\n";
      print "<td {$init->bgInfoCell}>$mountain</td>\n";
      print "</tr>\n";
      print "<tr>\n";
      print "<td {$init->bgCommentCell} colspan=\"7\">{$init->tagTH_}{$owner}:{$init->_tagTH}$comment</td>\n";
      print "</tr>\n";
    }
    print "</table>\n</div>\n";
    print "<hr>\n";
    $this->logPrintTop();
    $this->historyPrint();
  }
  //---------------------------------------------------
  // 섬의 등록과 설정
  //---------------------------------------------------
  function regist(&$hako) {
    global $init;
    $this->newDiscovery($hako->islandNumber);
    $this->changeIslandInfo($hako->islandList);
    $this->changeOwnerName($hako->islandList);
    $this->setStyleSheet();
  }
  //---------------------------------------------------
  // 새로운 섬을 찾는다
  //---------------------------------------------------
  function newDiscovery($number) {
    global $init;

    print "<div id=\"NewIsland\">\n";
    print "<h2>새 섬 찾기</h2>\n";
    if($number < $init->maxIsland) {
      print <<<END
<form accept-charset="UTF-8" action="{$GLOBALS['THIS_FILE']}" method="post">
섬 이름<br>
<input type="text" name="ISLANDNAME" size="32" maxlength="32">섬<br>
소유자 이름은?(생략 가능)<br>
<input type="text" name="OWNERNAME" size="32" maxlength="32"><br>
비밀번호는?<br>
<input type="password" name="PASSWORD" size="32" maxlength="32"><br>
만약을 위해 비밀번호를 다시 입력하세요<br>
<input type="password" name="PASSWORD2" size="32" maxlength="32"><br>
<input type="hidden" name="mode" value="new">
<input type="submit" value="찾기">
</form>
END;
    } else {
      print "섬 수가 최대치입니다. 현재 등록할 수 없습니다.\n";
    }
    print "</div>\n";
    print "<hr>\n";
  }
  //---------------------------------------------------
  // 섬 이름과 비밀번호 변경
  //---------------------------------------------------
  function changeIslandInfo($islandList = "") {
    global $init;
    print <<<END
<div id="ChangeInfo">
<h2>섬 이름과 비밀번호 변경</h2>
<p>
(주의) 이름 변경에는 500억원이 필요합니다.
</p>
<form accept-charset="UTF-8" action="{$GLOBALS['THIS_FILE']}" method="post">
어느 섬입니까?<br>
<select NAME="ISLANDID">
$islandList
</select>
<br>
어떤 이름으로 바꾸겠습니까?(변경할 경우만)<br>
<input type="text" name="ISLANDNAME" size="32" maxlength="32">섬<br>
비밀번호는?(필수)<br>
<input type="password" name="OLDPASS" size="32" maxlength="32"><br>
새 비밀번호는?(변경할 경우)<br>
<input type="password" name="PASSWORD" size="32" maxlength="32"><br>
만약을 위해 비밀번호를 다시 입력하세요(변경할 경우)<br>
<input type="password" name="PASSWORD2" size="32" maxlength="32"><br>
<input type="hidden" name="mode" value="change">
<input type="submit" value="변경">
</form>
</div>
<hr>

END;
  }
  //---------------------------------------------------
  // 소유자 변경
  //---------------------------------------------------
  function changeOwnerName($islandList = "") {
    global $init;
    print <<<END
<div id="ChangeOwnerName">
<h2>소유자 변경</h2>
<form accept-charset="UTF-8" action="{$GLOBALS['THIS_FILE']}" method="post">
어느 섬입니까?<br>
<select name="ISLANDID">
{$islandList}
</select>
<br>
새 소유자는?<br>
<input type="text" name="OWNERNAME" size="32" maxlength="32"><br>
비밀번호는?<br>
<input type="password" name="OLDPASS" size="32" maxlength="32"><br>
<input type="hidden" name="mode" value="ChangeOwnerName">
<input type="submit" value="변경">
</form>
</div>
END;
  }
  //---------------------------------------------------
  // 스타일 시트의 설정
  //---------------------------------------------------
  function setStyleSheet() {
    global $init;
    $styleSheet;
    for($i = 0; $i < count($init->cssList); $i++) {
      $styleSheet .= "<option value=\"{$init->cssList[$i]}\">{$init->cssList[$i]}</option>\n";
    }
    print <<<END
<div id="HakoSkin">
<h2>스타일 시트의 설정</h2>
<form accept-charset="UTF-8" action="{$GLOBALS['THIS_FILE']}" method="post">
<select name="SKIN">
$styleSheet
</select>
<input type="hidden" name="mode" value="skin">
<input type="submit" value="설정">
</form>
</div>
<hr>

END;
  }
  //---------------------------------------------------
  // 최근의 사건
  //---------------------------------------------------
  function logPrintTop() {
    global $init;
    print "<div id=\"RecentlyLog\">\n";
    print "<h2>최근의 사건</h2>\n";
    for($i = 0; $i < $init->logTopTurn; $i++) {
      LogIO::logFilePrint($i, 0, 0);
    }
    print "</div>\n";
  }
  //---------------------------------------------------
  // 발견의 기록
  //---------------------------------------------------
  function historyPrint() {
    print "<div id=\"HistoryLog\">\n";
    print "<h2>발견의 기록</h2>";
    LogIO::historyPrint();
    print "</div>\n";
  }
}
//------------------------------------------------------------------
#[\AllowDynamicProperties]
class HtmlMap extends HTML {
  //---------------------------------------------------
  // 개발 화면
  //---------------------------------------------------
  function owner($hako, $data) {
    global $init;
    $id     = $data['ISLANDID'];
    $number = $hako->idToNumber[$id];
    $island = $hako->islands[$number];

    // 비밀번호 체크
    if(!Util::checkPassword($island['password'], $data['PASSWORD'])){
      HakoError::wrongPassword();
      return;
    }
    $this->tempOwer($hako, $data, $number);
    
    if($init->useBbs) {
      print "<div id=\"localBBS\">\n";
      $this->lbbsHead($island);
      $this->lbbsInputOW($island, $data);
      $this->lbbsContents($island);
      print "</div>\n";
    }
    $this->islandRecent($island, 1);
  }

  //---------------------------------------------------
  // 관광 화면
  //---------------------------------------------------
  function visitor($hako, $data) {
    global $init;
    $id     = $data['ISLANDID'];
    $number = $hako->idToNumber[$id];
    $island = $hako->islands[$number];
    print <<<END
<div align="center">
{$init->tagBig_}{$init->tagName_}「{$island['name']}섬」{$init->_tagName}에 도착하였습니다.{$init->_tagBig}<br>
{$GLOBALS['BACK_TO_TOP']}<br>
</div>

END;

    $this->islandInfo($island, $number, 0);
    $this->islandMap($hako, $island, 0);

    if($init->useBbs) {
      print "<div id=\"localBBS\">\n";
      $this->lbbsHead($island);
      $this->lbbsInput($island, $data);
      $this->lbbsContents($island);
      print "</div>\n";
    }
    $this->islandRecent($island, 0);
  }
  //---------------------------------------------------
  // 섬의 정보
  //---------------------------------------------------
  function islandInfo($island, $number = 0, $mode = 0) {
    global $init;
    $rank = $number + 1;
    $pop   = $island['pop'] . $init->unitPop;
    $area  = $island['area'] . $init->unitArea;
    $money = ($mode == 0) ? Util::aboutMoney($island['money']) : "{$island['money']}{$init->unitMoney}";
    $food  = $island['food'] . $init->unitFood;
    $farm  = ($island['farm'] <= 0) ? "보유하지 않음" : $island['farm'] * 10 . $init->unitPop;
    $factory  = ($island['factory'] <= 0) ? "보유하지 않음" : $island['factory'] * 10 . $init->unitPop;
    $mountain = ($island['mountain'] <= 0) ? "보유하지 않음" : $island['mountain'] * 10 . $init->unitPop;
    $comment  = $island['comment'];

    print <<<END
<div id="islandInfo">
<table border="1">
<tr>
<th {$init->bgTitleCell}>{$init->tagTH_}순위{$init->_tagTH}</th>
<th {$init->bgTitleCell}>{$init->tagTH_}인구{$init->_tagTH}</th>
<th {$init->bgTitleCell}>{$init->tagTH_}면적{$init->_tagTH}</th>
<th {$init->bgTitleCell}>{$init->tagTH_}자금{$init->_tagTH}</th>
<th {$init->bgTitleCell}>{$init->tagTH_}식량{$init->_tagTH}</th>
<th {$init->bgTitleCell}>{$init->tagTH_}농장 규모{$init->_tagTH}</th>
<th {$init->bgTitleCell}>{$init->tagTH_}공장 규모{$init->_tagTH}</th>
<th {$init->bgTitleCell}>{$init->tagTH_}채굴장 규모{$init->_tagTH}</th>
</tr>
<tr>
<th {$init->bgNumberCell}>{$init->tagNumber_}$rank{$init->_tagNumber}</th>
<td {$init->bgInfoCell}>$pop</td>
<td {$init->bgInfoCell}>$area</td>
<td {$init->bgInfoCell}>$money</td>
<td {$init->bgInfoCell}>$food</td>
<td {$init->bgInfoCell}>$farm</td>
<td {$init->bgInfoCell}>$factory</td>
<td {$init->bgInfoCell}>$mountain</td>
</tr>
<tr>
<td colspan="8" {$init->bgCommentCell}>$comment</td>
</tr>
</table>
</div>

END;
  }
  //---------------------------------------------------
  // 지형 출력
  // $mode = 1 -- 미사일 기지등도 표시
  //---------------------------------------------------
  function islandMap($hako, $island, $mode = 0) {
    global $init;
    $land      = $island['land'];
    $landValue = $island['landValue'];
    $command   = $island['command'];
    if($mode == 1) {
      for($i = 0; $i < $init->commandMax; $i++) {
        $j = $i + 1;
        $com = $command[$i];
        if($com['kind'] < 20) {
          $comStr[$com['x']][$com['y']] .=
            "[{$j}]{$init->comName[$com['kind']]} ";
        }
      }
    }

    print "<div id=\"islandMap\" align=\"center\"><table border=\"1\"><tr><td>\n";
    print "<img src=\"xbar.gif\" width=\"400\" height=\"16\" alt=\"\"><br>\n";
    for($y = 0; $y < $init->islandSize; $y++) {
      if($y % 2 == 0) { print "<img src=\"space{$y}.gif\" width=\"16\" height=\"32\" alt=\"{$y}\">"; }

      for($x = 0; $x < $init->islandSize; $x++) {
        $hako->landString($land[$x][$y], $landValue[$x][$y], $x, $y, $mode, $comStr[$x][$y] ?? '');
      }
      
      if($y % 2 == 1) { print "<img src=\"space{$y}.gif\" width=\"16\" height=\"32\" alt=\"{$y}\">"; }

      print "<br>";
    }
    print "<div id=\"NaviView\">&shy;</div>";
    print "</td></tr></table></div>\n";
  }
  //---------------------------------------------------
  // 방문자 통신
  //---------------------------------------------------
  function lbbsHead($island) {
    global $init;
    print <<<END
<hr>
<h2>{$init->tagName_}{$island['name']}섬의 {$init->_tagName}방문자 통신</h2>

END;
  }
  //---------------------------------------------------
  // 방문자 통신 입력 부분
  //---------------------------------------------------
  function lbbsInput($island, $data) {
    global $init;
    print <<<END
<div align="center">
<table border="1">
<tr>
<th>이름</th>
<th>내용</th>
<th>작업</th>
</tr>
<tr>
<form accept-charset="UTF-8" action="{$GLOBALS['THIS_FILE']}" method="post">
<td><input type="text" size="32" maxlength="32" name="LBBSNAME" value="{$data['defaultName']}"></td>
<td><input type="text" size="80" name="LBBSMESSAGE"></td>
<td>
<input type="hidden" name="mode" value="lbbs">
<input type="hidden" name="lbbsMode" value="0">
<input type="hidden" name="ISLANDID" value="{$island['id']}">
<input type="hidden" name="DEVELOPEMODE" value="{$data['DEVELOPEMODE']}">
<input type="submit" value="기록한다">
</td>
</form>
</tr>
</table>
</div>

END;
  }
  //---------------------------------------------------
  // 방문자 통신 입력 부분 소유자용
  //---------------------------------------------------
  function lbbsInputOW($island, $data) {
    global $init;
    print <<<END
<div align="center">
<table border="1">
<tr>
<th>이름</th>
<th colspan="2">내용</th>
</tr>
<tr>
<form accept-charset="UTF-8" action="{$GLOBALS['THIS_FILE']}" method="post">
<td><input type="text" size="32" maxlength="32" name="LBBSNAME" VALUE="{$data['defaultName']}"></TD>
<td colspan="2"><input type="text" size="80" name="LBBSMESSAGE"></td>
</tr>
<tr>
<th colspan="2">작업</th>
</tr>
<tr>
<td align="right">
<input type="hidden" name="mode" value="lbbs">
<input type="hidden" name="lbbsMode" value="1">
<input type="hidden" name="PASSWORD" value="{$data['defaultPassword']}">
<input type="hidden" name="ISLANDID" value="{$island['id']}">
<input type="hidden" name="DEVELOPEMODE" value="{$data['DEVELOPEMODE']}">
<input type="submit" value="기록한다">
</td>
</form>
<td align="right">
<form accept-charset="UTF-8" action="{$GLOBALS['THIS_FILE']}" method="post">
번호
<select name="NUMBER">

END;
    
    // 글 번호
    for($i = 0; $i < $init->lbbsMax; $i++) {
      $j = $i + 1;
      print "<option value=\"{$i}\">{$j}</option>\n";
    }
    print <<<END
</select>
<input type="hidden" name="mode" value="lbbs">
<input type="hidden" name="lbbsMode" value="2">
<input type="hidden" name="PASSWORD" value="{$data['defaultPassword']}">
<input type="hidden" name="ISLANDID" value="{$island['id']}">
<input type="hidden" name="DEVELOPEMODE" value="{$data['DEVELOPEMODE']}">
<input type="submit" value="삭제">
</form>
</td>
</tr>
</table>
</div>

END;
  }
  //---------------------------------------------------
  // 방문자 통신 작성된 내용을 출력
  //---------------------------------------------------
  function lbbsContents($island) {
    global $init;
    $lbbs = $island['lbbs'];
    print <<<END
<div align="center">
<table border="1">
<tr>
<th style="width:3em;">번호</th>
<th>작성 내용</th>
</tr>

END;
    for($i = 0; $i < $init->lbbsMax; $i++) {
      $j = $i + 1;
      $line = $lbbs[$i];
      list($mode, $turn, $message) = explode(">", $line);
      print "<tr><th>{$init->tagNumber_}{$j}{$init->_tagNumber}</th>";
      if($mode == 0) {
        // 방문자
        print "<td>{$init->tagLbbsSS_}{$turn} &gt; {$message}{$init->_tagLbbsSS}</td></tr>\n";
      } else {
        // 섬 소유자
        print "<td>{$init->tagLbbsOW_}{$turn} &gt; {$message}{$init->_tagLbbsOW}</td></tr>\n";
      }
      
    }
    print "</table></div>\n";
  }
  //---------------------------------------------------
  // 섬의 최근 상황
  //---------------------------------------------------
  function islandRecent($island, $mode = 0) {
    global $init;
    print "<hr>\n";
    print "<div id=\"RecentlyLog\">\n";
    print "<h2>{$init->tagName_}{$island['name']}섬 {$init->_tagName}의 최근 상황</h2>\n";
    for($i = 0; $i < $init->logMax; $i++) {
      LogIO::logFilePrint($i, $island['id'], $mode);
    }
    print "</div>\n";
  }
  //---------------------------------------------------
  // 개발 화면
  //---------------------------------------------------
  function tempOwer($hako, $data, $number = 0) {
    global $init;
    $island = $hako->islands[$number];

    $width  = $init->islandSize * 32 + 50;
    $height = $init->islandSize * 32 + 100;
    $defaultTarget = ($init->targetIsland == 1) ? $island['id'] : $hako->defaultTarget;
    print <<<END
<script type="text/javascript">
<!--
var w;
var p = $defaultTarget;
function ps(x, y) {
  document.InputPlan.POINTX.options[x].selected = true;
  document.InputPlan.POINTY.options[y].selected = true;
  return true;
}

function ns(x) {
  document.InputPlan.NUMBER.options[x].selected = true;
  return true;
}

function settarget(part){
  p = part.options[part.selectedIndex].value;
}
function targetopen() {
  w = window.open("{$GLOBALS['THIS_FILE']}?target=" + p, "","width={$width},height={$height},scrollbars=1,resizable=1,toolbar=1,menubar=1,location=1,directories=0,status=1");
}


//-->
</script>
<div align="center">
{$init->tagBig_}{$init->tagName_}{$island['name']}섬{$init->_tagName}개발 계획{$init->_tagBig}<br>
{$GLOBALS['BACK_TO_TOP']}<br>
</div>

END;
    $this->islandInfo($island, $number, 1);
    print <<<END
<div align="center">
<table border="1">
<tr>
<td {$init->bgInputCell}>
<div align="center">
<form accept-charset="UTF-8" action="{$GLOBALS['THIS_FILE']}" method="post" name="InputPlan">
<input type="hidden" name="mode" value="command">
<input type="hidden" name="ISLANDID" value="{$island['id']}">
<input type="hidden" name="PASSWORD" value="{$data['defaultPassword']}">
<input type="submit" value="계획 송신">
<hr>
<strong>계획 번호</strong>
<select name="NUMBER">

END;
    // 계획 번호
    for($i = 0; $i < $init->commandMax; $i++) {
      $j = $i + 1;
      print "<option value=\"{$i}\">{$j}</option>";
    }
    print <<<END
</select><br>
<hr>
<strong>개발 계획</strong><br>
<select name="COMMAND">

END;
    // 계획
    for($i = 0; $i < $init->commandTotal; $i++) {
      $kind = $init->comList[$i];
      $cost = $init->comCost[$kind];
      if($cost == 0) {
        $cost = '무료';
      } elseif($cost < 0) {
        $cost  = - $cost;
        $cost .= $init->unitFood;
      } else {
        $cost .= $init->unitMoney;
      }
      if($kind == $data['defaultKind']) {
        $s = 'selected';
      } else {
        $s = '';
      }
      print "<option value=\"{$kind}\" {$s}>{$init->comName[$kind]}({$cost})</option>\n";
    }
    print <<<END
</select>
<hr>
<strong>좌표(</strong>
<select name="POINTX">

END;
    for($i = 0; $i < $init->islandSize; $i++) {
      if($i == $data['defaultX']) {
        print "<option value=\"{$i}\" selected>{$i}</option>\n";
      } else {
        print "<option value=\"{$i}\">{$i}</option>\n";
      }
    }
    print "</select>, <select name=\"POINTY\">";
    for($i = 0; $i < $init->islandSize; $i++) {
      if($i == $data['defaultY']) {
        print "<option value=\"{$i}\" selected>{$i}</option>\n";
      } else {
        print "<option value=\"{$i}\">{$i}</option>\n";
      }
    }
    print <<<END
</select><strong>)</strong>
<hr>
<strong>수량</strong>
<select name="AMOUNT">

END;
     for($i = 0; $i < 100; $i++)
       print "<option value=\"{$i}\">{$i}</option>\n";

     print <<<END
</select>
<hr>
<strong>목표 섬</strong><br>
<select name="TARGETID" onchange="settarget(this);">
$hako->targetList
</select>
<input type="button" value="목표 보기" onClick="javascript: targetopen();" onkeypress="javascript: targetopen();">
<hr>
<strong>작업</strong><br>
<input type="radio" name="COMMANDMODE" id="insert" value="insert" checked><label for="insert">삽입</label>
<input type="radio" name="COMMANDMODE" id="write" value="write"><label for="write">덮어쓰기</label><BR>
<input type="radio" name="COMMANDMODE" id="delete" value="delete"><label for="delete">삭제</label>
<hr>
<input type="hidden" name="DEVELOPEMODE" value="cgi">
<input type="submit" value="계획 송신">
</form>
</div>
</td>
<td {$init->bgMapCell}>

END;
    $this->islandMap($hako, $island, 1);    // 섬의 지도, 소유자 모드
    print <<<END
</td>
<td {$init->bgCommandCell}>
END;
    $command = $island['command'];
    for($i = 0; $i < $init->commandMax; $i++) {
      $this->tempCommand($i, $command[$i], $hako);
    }
    print <<<END
</td>
</tr>
</table>
</div>
<hr>
<div id='CommentBox'>
<h2>댓글 업데이트</h2>
<form accept-charset="UTF-8" action="{$GLOBALS['THIS_FILE']}" method="post">
<input type="text" name="MESSAGE" size="80" value="{$island['comment']}"><br>
<input type="hidden" name="PASSWORD" value="{$data['defaultPassword']}">
<input type="hidden" name="mode" value="comment">
<input type="hidden" name="ISLANDID" value="{$island['id']}">
<input type="hidden" name="DEVELOPEMODE" value="cgi">
<input type="submit" value="댓글 업데이트">
</form>
</div>

END;

  }
  //---------------------------------------------------
  // 입력이 끝난 계획 표시
  //---------------------------------------------------
  function tempCommand($number, $command, $hako) {
    global $init;

    $kind   = $command['kind'];
    $target = $command['target'];
    $x      = $command['x'];
    $y      = $command['y'];
    $arg    = $command['arg'];

    $comName = "{$init->tagComName_}{$init->comName[$kind]}{$init->_tagComName}";
    $point   = "{$init->tagName_}({$x},{$y}){$init->_tagName}";
    $target  = $hako->idToName[$target] ?? '';
    if(empty($target)) {
      $target = "무인도";
    }
    $target = "{$init->tagName_}{$target}섬{$init->_tagName}";
    $value = $arg * $init->comCost[$kind];
    if($value == 0) {
      $value = $init->comCost[$kind];
    }
    if($value < 0) {
      $value = -$value;
      $value = "{$value}{$init->unitFood}";
    } else {
      $value = "{$value}{$init->unitMoney}";
    }
    $value = "{$init->tagName_}{$value}{$init->_tagName}";

    $j = sprintf("%02d:", $number + 1);

    print "<a href=\"javascript:void(0);\" onclick=\"ns({$number})\" onkeypress=\"ns({$number})\">{$init->tagNumber_}{$j}{$init->_tagNumber}";

    switch($kind) {
    case $init->comDoNothing:
    case $init->comGiveup:
    case $init->comPropaganda:
      $str = "{$comName}";
      break;
    case $init->comMissileNM:
    case $init->comMissilePP:
    case $init->comMissileST:
    case $init->comMissileLD:
      // 미사일계
      $n = ($arg == 0) ? '무제한' : "{$arg}발";
      $str = "{$target}{$point}에{$comName}({$init->tagName_}{$n}{$init->_tagName})";
      break;
    case $init->comSendMonster:
      // 괴수 파견
      $str = "{$target}에 {$comName}";
      break;
    case $init->comSell:
      // 식량 수출
      $str ="{$comName}{$value}";
      break;
    case $init->comMoney:
    case $init->comFood:
      // 원조
      $str = "{$target}에 {$comName}{$value}";
      break;
    case $init->comDestroy:
      // 굴착
      if($arg != 0) {
        $str = "{$point}로 {$comName}(예산{$value})";
      } else {
        $str = "{$point}로 {$comName}";
      }
      break;
    case $init->comFarm:
    case $init->comFactory:
    case $init->comMountain:
      // 반복 횟수 포함
      if($arg == 0) {
        $str = "{$point}로 {$comName}";
      } else {
        $str = "{$point}로 {$comName}({$arg}회)";
      }      
      break;
    default:
      // 좌표 첨부
      $str = "{$point}로 {$comName}";
    }

    print "{$str}</a> <br>";
  }
  //---------------------------------------------------
  // 새롭게 발견한 섬
  //---------------------------------------------------
  function newIslandHead($name) {
    global $init;
    print <<<END
<div align="center">
{$init->tagBig_}섬을 발견했습니다!{$init->_tagBig}<br>
{$init->tagBig_}{$init->tagName_}「{$name}섬」을 {$init->_tagName}이라고 이름 붙입니다.{$init->_tagBig}<br>
{$GLOBALS['BACK_TO_TOP']}<br>
</div>
END;
  }
  //---------------------------------------------------
  // 목표 보기 모드
  //---------------------------------------------------
  function print대상($hako, $data) {
    global $init;
    // ID에서 섬 번호 취득
    $id     = $data['ISLANDID'];
    $number = $hako->idToNumber[$id];
    // 해당 섬이 없는 경우
    if($number < 0 || $number > $hako->islandNumber) {
      HakoError::problem();
      return;
    }
    $island = $hako->islands[$number];

print <<<END
<script type="text/javascript">
<!--
function ps(x, y) {
  window.opener.document.InputPlan.POINTX.options[x].selected = true;
  window.opener.document.InputPlan.POINTY.options[y].selected = true;
  return true;
}
//-->
</script>

<div align="center">
{$init->tagBig_}{$init->tagName_}{$island['name']}섬{$init->_tagName}{$init->_tagBig}<br>
</div>

END;

    //섬의 지도
    $this->islandMap($hako, $island, 2);

  }
}
//------------------------------------------------------------------
#[\AllowDynamicProperties]
class HtmlJS extends HtmlMap {
  static function header($data = "") {
    global $init;
    global $PRODUCT_VERSION;

    // 압축 전송
    if(GZIP == true) {
      global $http;
      $http->start();
    }
    header("X-Product-Version: {$PRODUCT_VERSION}");
    header("Content-Type: text/html; charset=UTF-8");
    $css = (empty($data['defaultSkin'])) ? $init->cssList[0] : $data['defaultSkin'];
    print <<<END
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html lang="ko">
<head>
<base href="{$init->imgDir}/">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<link rel="stylesheet" type="text/css" href="{$init->cssDir}/{$css}">
<title>{$init->title}</title>
<script type="text/javascript" src="{$init->baseDir}/hako.js"></script>
</head>
<body onload="init()">
<div id="LinkHeader">
<a href="http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html">모형정원 제도 스크립트 배포원</a> 
<a href="http://scrlab.g-7.ne.jp/">[PHP]</a>  
<a href="http://AFresh.ub.to" target="_blank"><font color=red>[한글화 배포처]</font></a> 

[<a href="{$GLOBALS['THIS_FILE']}?mode=conf">섬 등록·설정 변경</a> ]
</div>
<hr>

END;
  }
  //---------------------------------------------------
  // 개발 화면
  //---------------------------------------------------
  function tempOwer($hako, $data, $number = 0) {
    global $init;
    $island = $hako->islands[$number];

    $width  = $init->islandSize * 32 + 50;
    $height = $init->islandSize * 32 + 100;

    // 계획 세트
    $set_com = "";
    $com_max = "";
    for($i = 0; $i < $init->commandMax; $i++) {
      // 각 요소의 꺼내
      $command  = $island['command'][$i];
      $s_kind   = $command['kind'];
      $s_target = $command['target'];
      $s_x      = $command['x'];
      $s_y      = $command['y'];
      $s_arg    = $command['arg'];

      // 계획 등록
      if($i == $init->commandMax - 1){
        $set_com .= "[$s_kind, $s_x, $s_y, $s_arg, $s_target]\n";
        $com_max .= "0";
      } else {
        $set_com .= "[$s_kind, $s_x, $s_y, $s_arg, $s_target], \n";
        $com_max .= "0,";
      }
    }

    //계획 리스트 세트
    $l_kind;
    $set_listcom = "";
    $click_com = "";
    $click_com2 = "";
    $All_listCom = 0;
    $com_count = count($init->commandDivido);
    for($m = 0; $m < $com_count; $m++) {
      list($aa, $dd, $ff) = explode(",", $init->commandDivido[$m]);
      $set_listcom .= "[ ";
      for($i = 0; $i < $init->commandTotal; $i++) {
        $l_kind = $init->comList[$i];
        $l_cost = $init->comCost[$l_kind];
        if($l_cost == 0) {
          $l_cost = '무료';
        } elseif($l_cost < 0) {
          $l_cost = - $l_cost; $l_cost .= $init->unitFood;
        } else {
          $l_cost .= $init->unitMoney;
        }
        if($l_kind > $dd-1 && $l_kind < $ff+1) {
          $set_listcom .= "[$l_kind, '{$init->comName[$l_kind]}', '{$l_cost}'], \n";
          if($m == 0){
            $click_com .= "<a href='javascript:void(0);' onclick='cominput(InputPlan, 6, {$l_kind})' onkeypress='cominput(InputPlan, 6, {$l_kind})' style='text-decoration:none'>{$init->comName[$l_kind]}({$l_cost})<\\/a><br>\n";
          } elseif($m == 1) {
            $click_com2 .= "<a href='javascript:void(0);' onclick='cominput(InputPlan, 6, {$l_kind})' onkeypress='cominput(InputPlan, 6, {$l_kind})' style='text-decoration:none'>{$init->comName[$l_kind]}({$l_cost})<\\/a><br>\n";
          }
          $All_listCom++;
        }
        if($l_kind < $ff+1) { continue; }
      }
      $bai = strlen($set_listcom);
      $set_listcom = substr($set_listcom, 0, $bai - 2);
      $set_listcom .= " ], \n";
    }
    $bai = strlen($set_listcom);
    $set_listcom = substr($set_listcom, 0, $bai - 2);
    if(empty($data['defaultKind'])) {
      $default_Kind = 1;
    } else {
      $default_Kind = $data['defaultKind'];
    }

    // 섬리스트 세트
    $set_island = "";
    for($i = 0; $i < $hako->islandNumber; $i++) {
      $l_name = $hako->islands[$i]['name'];
      $l_name = preg_replace("/'/", "\'", $l_name);
      $l_id = $hako->islands[$i]['id'];
      if($i == $hako->islandNumber - 1){
        $set_island .= "[$l_id, '$l_name']\n";
      }else{
        $set_island .= "[$l_id, '$l_name'], \n";
      }
    }
    $defaultTarget = ($init->targetIsland == 1) ? $island['id'] : $hako->defaultTarget;

    print <<<END
<div align="center">
{$init->tagBig_}{$init->tagName_}{$island['name']}섬{$init->_tagName}개발 계획{$init->_tagBig}<BR>
{$GLOBALS['BACK_TO_TOP']}<br>
</div>
<script type="text/javascript">
<!--
var w;
var p = $defaultTarget;

// JAVA 스크립트 개발 화면 배포원
// -암모형정원 제도( http://appoh.execweb.cx/hakoniwa/ )
// Programmed by Jynichi Sakai(―)
// ↑ 삭제하지 마세요.
var str;
g = [$com_max];
k1 = [$com_max];
k2 = [$com_max];
tmpcom1 = [ [0,0,0,0,0] ];
tmpcom2 = [ [0,0,0,0,0] ];
command = [
$set_com];

comlist = [
$set_listcom
];

islname = [
$set_island];


function init() {
  for(i = 0; i < command.length ;i++) {
    for(s = 0; s < $com_count ;s++) {
      var comlist2 = comlist[s];
      for(j = 0; j < comlist2.length ; j++) {
        if(command[i][0] == comlist2[j][0]) {
          g[i] = comlist2[j][1];
        }
      }
    }
  }
  SelectList('');
  outp();
  str = plchg();
  str = '<font color="blue">■ 송신이 끝남 ■<\\/font><br>' + str;
  disp(str, "");

}

function cominput(theForm, x, k) {
  a = theForm.NUMBER.options[theForm.NUMBER.selectedIndex].value;
  b = theForm.COMMAND.options[theForm.COMMAND.selectedIndex].value;
  c = theForm.POINTX.options[theForm.POINTX.selectedIndex].value;
  d = theForm.POINTY.options[theForm.POINTY.selectedIndex].value;
  e = theForm.AMOUNT.options[theForm.AMOUNT.selectedIndex].value;
  f = theForm.TARGETID.options[theForm.TARGETID.selectedIndex].value;
  //  if(x == 6){ b = k; menuclose(); }
  if (x == 1 || x == 6){
    for(i = $init->commandMax - 1; i > a; i--) {
      command[i] = command[i-1];
      g[i] = g[i-1];
    }
  } else if(x == 3) {
    for(i = Math.floor(a); i < ($init->commandMax - 1); i++) {
      command[i] = command[i + 1];
      g[i] = g[i+1];
    }
    command[$init->commandMax - 1] = [41, 0, 0, 0, 0];
    g[$init->commandMax - 1] = '자금 융통';
    str = plchg();
    str = '<font color="red"><strong>■ 미송신 ■<\\/strong><\\/font><br>' + str;
    disp(str,"white");
    outp();
    return true;
  } else if(x == 4) {
    i = Math.floor(a);
    if (i == 0){ return true; }
    i = Math.floor(a);
    tmpcom1[i] = command[i];tmpcom2[i] = command[i - 1];
    command[i] = tmpcom2[i];command[i-1] = tmpcom1[i];
    k1[i] = g[i];k2[i] = g[i - 1];
    g[i] = k2[i];g[i-1] = k1[i];
    ns(--i);
    str = plchg();
    str = '<font color="red"><strong>■ 미송신 ■<\\/strong><\\/font><br>' + str;
    disp(str,"white");
    outp();
    return true;
  } else if(x == 5) {
    i = Math.floor(a);
    if (i == $init->commandMax - 1){ return true; }
    tmpcom1[i] = command[i];tmpcom2[i] = command[i + 1];
    command[i] = tmpcom2[i];command[i + 1] = tmpcom1[i];
    k1[i] = g[i];k2[i] = g[i + 1];
    g[i] = k2[i];g[i + 1] = k1[i];
    ns(++i);
    str = plchg();
    str = '<font color="red"><strong>■ 미송신 ■<\\/strong><\\/font><br>' + str;
    disp(str,"white");
    outp();
    return true;
  }

  for(s = 0; s < $com_count; s++) {
    var comlist2 = comlist[s];
    for(i = 0; i < comlist2.length; i++){
      if(comlist2[i][0] == b){
        g[a] = comlist2[i][1];
        break;
      }
    }
  }
  command[a] = [b, c, d, e, f];
  ns(++a);
  str = plchg();
  str = '<font color="red"><b>■ 미송신 ■<\\/b><\\/font><br>' + str;
  disp(str, "white");
  outp();
  return true;
}
function plchg() {
  strn1 = "";
  for(i = 0; i < $init->commandMax; i++) {
    c = command[i];

    kind = '{$init->tagComName_}' + g[i] + '{$init->_tagComName}';
    x = c[1];
    y = c[2];
    tgt = c[4];
    point = '{$init->tagName_}' + "(" + x + "," + y + ")" + '{$init->_tagName}';
    for(j = 0; j < islname.length ; j++) {
      if(tgt == islname[j][0]){
        tgt = '{$init->tagName_}' + islname[j][1] + "도" + '{$init->_tagName}';
      }
    }
    if(c[0] == $init->comDoNothing || c[0] == $init->comGiveup){ // 자금 융통, 섬의 포기
      strn2 = kind;
    }else if(c[0] == $init->comMissileNM || // 미사일 관련
             c[0] == $init->comMissilePP ||
             c[0] == $init->comMissileST ||
             c[0] == $init->comMissileLD){
      if(c[3] == 0) {
        arg = "(무제한)";
      } else {
        arg = "(" + c[3] + "발)";
      }
      strn2 = tgt + point + "에" + kind + arg;
    } else if(c[0] == $init->comSendMonster) { // 괴수 파견
      strn2 = tgt + "에" + kind;
    } else if(c[0] == $init->comSell) { // 식량 수출
      if(c[3] == 0){ c[3] = 1; }
      arg = c[3] * 100;
      arg = "(" + arg + "{$init->unitFood})";
      strn2 = kind + arg;
    } else if(c[0] == $init->comPropaganda) { // 인구 유치 활동
      strn2 = kind;
    } else if(c[0] == $init->comMoney) { // 자금 원조
      if(c[3] == 0){ c[3] = 1; }
      arg = c[3] * {$init->comCost[$init->comMoney]};
      arg = "(" + arg + "{$init->unitMoney})";
      strn2 = tgt + "에" + kind + arg;
    } else if(c[0] == $init->comFood) { // 식량 원조
      if(c[3] == 0){ c[3] = 1; }
      arg = c[3] * 100;
      arg = "(" + arg + "{$init->unitFood})";
      strn2 = tgt + "에" + kind + arg;
    } else if(c[0] == $init->comDestroy) { // 굴착
      if(c[3] == 0){
        strn2 = point + "로" + kind;
      } else {
        arg = c[3] * {$init->comCost[$init->comDestroy]};
        arg = "(예\산" + arg + "{$init->unitMoney})";
        strn2 = point + "로" + kind + arg;
      }
    } else if(c[0] == $init->comFarm || // 농장, 공장, 채굴장 정비
              c[0] == $init->comFactory ||
              c[0] == $init->comMountain) {
      if(c[3] != 0){
        arg = "(" + c[3] + "회)";
        strn2 = point + "로" + kind + arg;
      }else{
        strn2 = point + "로" + kind;
      }
    }else{
      strn2 = point + "로" + kind;
    }
    tmpnum = '';
    if(i < 9){ tmpnum = '0'; }
    strn1 +=
      '<a style="text-decoration:none;color:000000" HREF="javascript:void(0);" onclick="ns(' + i + ')" onkeypress="ns(' + i + ')"><nobr>' +
        tmpnum + (i + 1) + ':' +
          strn2 + '<\\/nobr><\\/a><br>\\n';
  }
  return strn1;
}

function disp(str, bgclr) {
  if(str==null)  str = "";

  if(document.getElementById){
    document.getElementById("LINKMSG1").innerHTML = str;
    if(bgclr != "")
      document.getElementById("plan").bgColor = bgclr;
  } else if(document.all){
    el = document.all("LINKMSG1");
    el.innerHTML = str;
    if(bgclr != "")
      document.all.plan.bgColor = bgclr;
  } else if(document.layers) {
    lay = document.layers["PARENT_LINKMSG"].document.layers["LINKMSG1"];
    lay.document.open();
    lay.document.write("<font style='font-size:11pt'>"+str+"<\\/font>");
    lay.document.close();
    if(bgclr != "")
      document.layers["PARENT_LINKMSG"].bgColor = bgclr;
  }
}

function outp() {
  comary = "";

  for(k = 0; k < command.length; k++){
    comary = comary + command[k][0]
      + " " + command[k][1]
        + " " + command[k][2]
          + " " + command[k][3]
            + " " + command[k][4]
              + " " ;
  }
  document.InputPlan.COMARY.value = comary;
}

function ps(x, y) {
  document.InputPlan.POINTX.options[x].selected = true;
  document.InputPlan.POINTY.options[y].selected = true;
  return true;
}


function ns(x) {
  if (x == $init->commandMax){ return true; }
  document.InputPlan.NUMBER.options[x].selected = true;
  return true;
}

function set_com(x, y, land) {
  com_str = land + " ";
  for(i = 0; i < $init->commandMax; i++) {
    c = command[i];
    x2 = c[1];
    y2 = c[2];
    if(x == x2 && y == y2 && c[0] < 30){
      com_str += "[" + (i + 1) +"]" ;
      kind = g[i];
      if(c[0] == $init->comDestroy){
        if(c[3] == 0){
          com_str += kind;
        } else {
          arg = c[3] * 200;
          arg = "(예\산" + arg + "{$init->unitMoney})";
          com_str += kind + arg;
        }
      } else if(c[0] == $init->comFarm ||
                c[0] == $init->comFactory ||
                c[0] == $init->comMountain) {
        if(c[3] != 0){
          arg = "(" + c[3] + "회)";
          com_str += kind + arg;
        } else {
          com_str += kind;
        }
      } else {
        com_str += kind;
      }
      com_str += " ";
    }
  }
  document.InputPlan.COMSTATUS.value= com_str;
}


function SelectList(theForm) {
  var u, selected_ok;
  if(!theForm) { s = '' }
  else { s = theForm.menu.options[theForm.menu.selectedIndex].value; }
  if(s == ''){
    u = 0; selected_ok = 0;
    document.InputPlan.COMMAND.options.length = $All_listCom;
    for (i=0; i<comlist.length; i++) {
      var command = comlist[i];
      for (a=0; a<command.length; a++) {
        comName = command[a][1] + "(" + command[a][2] + ")";
        document.InputPlan.COMMAND.options[u].value = command[a][0];
        document.InputPlan.COMMAND.options[u].text = comName;
        if(command[a][0] == $default_Kind){
          document.InputPlan.COMMAND.options[u].selected = true;
          selected_ok = 1;
        }
        u++;
      }
    }
    if(selected_ok == 0)
      document.InputPlan.COMMAND.selectedIndex = 0;
  } else {
    var command = comlist[s];
    document.InputPlan.COMMAND.options.length = command.length;
    for (i=0; i<command.length; i++) {
      comName = command[i][1] + "(" + command[i][2] + ")";
      document.InputPlan.COMMAND.options[i].value = command[i][0];
      document.InputPlan.COMMAND.options[i].text = comName;
      if(command[i][0] == $default_Kind){
        document.InputPlan.COMMAND.options[i].selected = true;
        selected_ok = 1;
      }
    }
    if(selected_ok == 0)
      document.InputPlan.COMMAND.selectedIndex = 0;
  }
}


function settarget(part){
  p = part.options[part.selectedIndex].value;
}
function targetopen() {
  w = window.open("{$GLOBALS['THIS_FILE']}?target=" + p, "","width={$width},height={$height},scrollbars=1,resizable=1,toolbar=1,menubar=1,location=1,directories=0,status=1");
}

    //-->
</script>
END;

    $this->islandInfo($island, $number, 1);

    print <<<END
<div align="center">
<table border="1">
<tr valign="top">
<td $init->bgInputCell>
<form accept-charset="UTF-8" action="{$GLOBALS['THIS_FILE']}" method="post" name="InputPlan">
<input type="hidden" name="mode" value="command">
<input type="hidden" name="COMARY" value="comary">
<input type="hidden" name="DEVELOPEMODE" value="java">
<div align="center">
<br>
<b>계획 입력</b><br>
<b>
<a href="javascript:void(0);" onclick="cominput(InputPlan,1)" onkeypress="cominput(InputPlan,1)">삽입</a> 
 <a href="javascript:void(0);" onclick="cominput(InputPlan,2)" onkeypress="cominput(InputPlan,2)">덮어쓰기</a> 
 <a href="javascript:void(0);" onclick="cominput(InputPlan,3)" onkeypress="cominput(InputPlan,3)">삭제</a> 
</b>
<hr>
<b>계획 번호</b>
<select name="NUMBER">
END;

    // 계획 번호
    for($i = 0; $i < $init->commandMax; $i++) {
      $j = $i + 1;
      print "<option value=\"$i\">$j</option>\n";
    }

    if (($HmenuOpen ?? '') == 'on') {
      $open = "CHECKED";
    }else{
      $open = "";
    }

    print <<<END
</select>
<hr>
<b>개발 계획</b>
<br>
<select name="menu" onchange="SelectList(InputPlan)">
<option value="">전종류</option>

END;

    for($i = 0; $i < $com_count; $i++) {
      list($aa, $tmp) = explode(",", $init->commandDivido[$i], 2);
      print "<option value=\"$i\">{$aa}</option>\n";
    }
    print <<<END
</select><br>
<select name="COMMAND">
<option>          </option>
<option>          </option>
<option>          </option>
<option>          </option>
<option>          </option>
<option>          </option>
<option>          </option>
<option>          </option>
<option>          </option>
<option>          </option>
</select>
<hr>
<b>좌표(</b>
<select name="POINTX">

END;

    for($i = 0; $i < $init->islandSize; $i++) {
      if($i == $data['defaultX']) {
        print "<option value=\"$i\" selected>$i</option>\n";
      } else {
        print "<option value=\"$i\">$i</option>\n";
      }
    }

    print "</select>, <select name=\"POINTY\">\n";

    for($i = 0; $i < $init->islandSize; $i++) {
      if($i == $data['defaultY']) {
        print "<option value=\"$i\" selected>$i</option>\n";
      } else {
        print "<option value=\"$i\">$i</option>\n";
      }
    }

    print <<<END
</select><b> )</b>
<hr>
<b>수량</b><select name="AMOUNT">

END;

    // 수량
    for($i = 0; $i < 100; $i++) {
      print "<option value=\"$i\">$i</option>\n";
    }

    print <<<END
</select>
<hr>
<b>목표 섬</b><br>
<select name="TARGETID" onchange="settarget(this);">
$hako->targetList
</select>
<input type="button" value="목표 보기" onClick="javascript: targetopen();" onkeypress="javascript: targetopen();">
<hr>
<b>계획 이동</b>:
<a href="javascript:void(0);" onclick="cominput(InputPlan,4)" onkeypress="cominput(InputPlan,4)" style="text-decoration:none"> ▲ </a> ··
<a href="javascript:void(0);" onclick="cominput(InputPlan,5)" onkeypress="cominput(InputPlan,5)" style="text-decoration:none"> ▼ </a> 
<hr>
<input type="hidden" name="ISLANDID" value="{$island['id']}">
<input type="hidden" name="PASSWORD" value="{$data['defaultPassword']}">
<input type="submit" value="계획 송신">
<br>마지막에<font color="red">계획 송신 버튼</font>을<br>누르는 것을 잊지 마세요.
</div>
</form>
</td>
<td $init->bgMapCell><div align="center">

END;

    $this->islandMap($hako, $island, 1);    // 섬의 지도, 소유자 모드

    $comment = $hako->islands[$number]['comment'];

    print <<<END
</div>
</td>
<td $init->bgCommandCell id="plan">
<ilayer name="PARENT_LINKMSG" width="100%" height="100%">
<layer name="LINKMSG1" width="200"></layer>
<span id="LINKMSG1"></span>
</ilayer>
<br>
</td>
</tr>
</table>
</div>
<hr>
<div id='CommentBox'>
<h2>댓글 업데이트</h2>
<form accept-charset="UTF-8" action="{$GLOBALS['THIS_FILE']}" method="post">
<input type="text" name="MESSAGE" size="80" value="{$island['comment']}"><br>
<input type="hidden" name="PASSWORD" value="{$data['defaultPassword']}">
<input type="hidden" name="mode" value="comment">
<input type="hidden" name="DEVELOPEMODE" value="java">
<input type="hidden" name="ISLANDID" value="{$island['id']}">
<input type="submit" value="댓글 업데이트">
</FORM>
</DIV>
END;

  }
}



#[\AllowDynamicProperties]
class HtmlSetted extends HTML {
  static function setSkin() {
    global $init;
    print "{$init->tagBig_}스타일 시트를 설정했습니다.{$init->_tagBig}{$GLOBALS['BACK_TO_TOP']}\n";
  }
  static function comment() {
    global $init;
    print "{$init->tagBig_}댓글을 업데이트했습니다.{$init->_tagBig}<hr>";
  }
  static function change() {
    global $init;
    print "{$init->tagBig_}변경 완료했습니다{$init->_tagBig}{$GLOBALS['BACK_TO_TOP']}\n";
  }
  static function lbbsDelete() {
    global $init;
    print "{$init->tagBig_}작성 내용을 삭제했습니다{$init->_tagBig}<hr>";
  }
  static function lbbsAdd() {
    global $init;
    print "{$init->tagBig_}기록을 실행했습니다{$init->_tagBig}<hr>";
  }
  // 계획 삭제
  static function commandDelete() {
    global $init;
    print "{$init->tagBig_}계획를 삭제했습니다{$init->_tagBig}<hr>\n";
  }

  // 계획 등록
  static function commandAdd() {
    global $init;
    print "{$init->tagBig_}계획를 등록했습니다{$init->_tagBig}<hr>\n";
  }
}
#[\AllowDynamicProperties]
class HakoError {
  static function wrongPassword() {
    global $init;
    print "{$init->tagBig_}비밀번호가 다릅니다.{$init->_tagBig}{$GLOBALS['BACK_TO_TOP']}\n";
    HTML::footer();
    exit;
  }
  // hakojima.dat가 없다
  static function noDataFile() {
    global $init;
    print "{$init->tagBig_}데이터 파일이 열리지 않습니다.{$init->_tagBig}{$GLOBALS['BACK_TO_TOP']}\n";
    HTML::footer();
    exit;
  }
  static function newIslandFull() {
    global $init;
    print "{$init->tagBig_}죄송합니다, 더이상 섬이 없어서 등록할 수 없습니다!{$init->_tagBig}{$GLOBALS['BACK_TO_TOP']}\n";
    HTML::footer();
    exit;
  }
  static function newIslandNoName() {
    global $init;
    print "{$init->tagBig_}섬에 붙일 이름이 필요합니다.{$init->_tagBig}{$GLOBALS['BACK_TO_TOP']}\n";
    HTML::footer();
    exit;
  }
  static function newIslandBadName() {
    global $init;
    print "{$init->tagBig_}특수문자나 「무인도」 같은 이름은 사용할 수 없습니다.{$init->_tagBig}{$GLOBALS['BACK_TO_TOP']}\n";
    HTML::footer();
    exit;
  }
  static function newIslandAlready() {
    global $init;
    print "{$init->tagBig_}그 섬이라면 이미 발견 되었습니다.{$init->_tagBig}{$GLOBALS['BACK_TO_TOP']}\n";
    HTML::footer();
    exit;
  }
  static function newIslandNoPassword() {
    global $init;
    print "{$init->tagBig_}비밀번호가 필요합니다.{$init->_tagBig}{$GLOBALS['BACK_TO_TOP']}\n";
    HTML::footer();
    exit;
  }
  static function changeNoMoney() {
    global $init;
    print "{$init->tagBig_}자금이 부족하여 변경할 수 없습니다{$init->_tagBig}{$GLOBALS['BACK_TO_TOP']}\n";
    HTML::footer();
    exit;
  }
  static function changeNothing() {
    global $init;
    print "{$init->tagBig_}이름, 비밀번호 모두 공백입니다{$init->_tagBig}{$GLOBALS['BACK_TO_TOP']}\n";
    HTML::footer();
    exit;
  }
  static function problem() {
    global $init;
    print "{$init->tagBig_}문제 발생, 우선 돌아와 주세요.{$init->_tagBig}{$GLOBALS['BACK_TO_TOP']}\n";
    HTML::footer();
    exit;
  }
  static function lbbsNoMessage() {
    global $init;
    print "{$init->tagBig_}이름 또는 내용의 란이 공백입니다.{$init->_tagBig}{$GLOBALS['BACK_TO_TOP']}\n";
    HTML::footer();
    exit;
  }
  static function lockFail() {
    global $init;
    print "{$init->tagBig_}동시 액세스 에러입니다.<BR>브라우저의 「돌아온다」버튼을 눌러,<BR>당분간 기다리고 나서 재차 시험해 주세요.{$init->_tagBig}{$GLOBALS['BACK_TO_TOP']}\n";
    HTML::footer();
    exit;
  }
}
?>
