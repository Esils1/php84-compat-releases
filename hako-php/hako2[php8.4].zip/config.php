<?php
/*******************************************************************

  모형정원 제도 2 for PHP

  - 초기 설정용 파일 -
  
  $Id: config.php, v 1.7 2003/09/29 11:54:19 Watson Exp $

*******************************************************************/
define("GZIP", false);	// true: GZIP 압축 전송을 사용  false: 사용하지 않는다
define("DEBUG", false);	// true: 디버그 false: 통상

#[\AllowDynamicProperties]
class Init {
  //----------------------------------------
  // 각종 설정치
  //----------------------------------------
  // 프로그램 디렉토리
  var $baseDir		= "https://esils2.mycafe24.com/af";

  // 이미지를 두는 디렉토리
  var $imgDir		= "https://esils2.mycafe24.com/af/hako_image";

  // CSS 파일 디렉토리
  var $cssDir		= "https://esils2.mycafe24.com/af/css";

  // CSS 리스트
  var $cssList		= array('SkyBlue.css', 'Autumn.css');
  
  //비밀번호의 암호화 true: 암호화, false: 암호화하지 않는다
  var $cryptOn		= true; 
  // 관리자 비밀번호
  var $masterPassword	= "1064";
  var $specialPassword	= "1004";
  
  // 데이터 디렉토리 이름
  var $dirName		= "data";

  // 게임 제목
  var $title		= "모형정원 제도 2";

  var $adminName	= "AFresh";
  var $adminEmail	= "amen6114@naver.com";
  var $urlBbs		= "http://zrogadis.hanb.net/bbs/zboard.php?id=sang";
  var $urlTopPage	= "http://AFresh.ub.to/";

  // 디렉토리 생성 시의 퍼미션
  var $dirMode		= 0755;
  
  // 1 턴이 몇 초인지
  var $unitTime		= 3600; // 6시간

  // 섬의 최대 수
  var $maxIsland	= 20;

  // 자금 표시 모드
  var $moneyMode	= true; // true: 100의 위로 반올림, false: 그대로
  // 메인 페이지에 표시하는 로그의 턴 수
  var $logTopTurn	= 1;
  // 로그 파일 보관 턴 수
  var $logMax		= 8;

  // 백업을 몇 턴마다 백업할지
  var $backupTurn	= 12;
  // 백업을 몇 회분을 남길지
  var $backupTimes	= 4;

  // 발견 로그 보관 행 수
  var $historyMax	= 10;

  // 포기 계획 자동 입력 턴 수
  var $giveupTurn	= 28;

  // 계획 입력 한계 수
  var $commandMax	= 20;

  // 내부 게시판 사용 여부(false:사용 안 함, true:사용함)
  var $useBbs		= true;
  // 내부 게시판 행 수
  var $lbbsMax		= 5;
  var $commentNew	= 0;

  // 섬의 크기
  var $islandSize	= 12;

  // 초기 자금
  var $initialMoney	= 100;
  // 초기 식량
  var $initialFood	= 100;

  // 자금 최대치
  var $maxMoney		= 9999;
  // 식량 최대치
  var $maxFood		= 9999;

  // 인구의 단위
  var $unitPop		= "00명";
  // 식량의 단위
  var $unitFood		= "00톤";
  // 면적의 단위
  var $unitArea		= "00만평";
  // 나무의 수의 단위
  var $unitTree		= "00개";
  // 돈의 단위
  var $unitMoney	= "억원";

  // 나무 단위당 판매가
  var $treeValue	= 5;

  // 이름 변경의 비용
  var $costChangeName	= 500;

  // 인구 1단위당 식량 소비량
  var $eatenFood	= 0.2;

  // 유전의 수입
  var $oilMoney		= 1000;
  // 유전의 고갈 확률
  var $oilRatio		= 40;


  // 미사일 기지
  // 경험치의 최대치
  var $maxExpPoint	= 200; // 단, 최대여도 255까지

  // 레벨의 최대치
  var $maxBaseLevel	= 5; // 미사일 기지
  var $maxSBaseLevel	= 3; // 해저 기지

  // 경험치가 몇 점마다 레벨업할지
  var $baseLevelUp	= array(20, 60, 120, 200); // 미사일 기지
  var $sBaseLevelUp	= array(50, 200);          // 해저 기지

  // 괴수에게 밟혔을 때 자폭한다면 1, 하지 않으면 0
  var $dBaseAuto = 1;

  // 1이면 목표 섬 또는 소유 섬이 선택된 목록 생성, 0이면 순위 1위 섬 선택
  // 미사일의 오발사가 많은 경우 등에 사용하면 좋을지도 모른다
  var $targetIsland = 1;
  
  var $disEarthquake = 5;  // 지진
  var $disTsunami    = 15; // 해일
  var $disTyphoon    = 20; // 태풍
  var $disMeteo      = 15; // 운석
  var $disHugeMeteo  = 5;  // 거대 운석
  var $disEruption   = 10; // 분화
  var $disFire       = 10; // 화재
  var $disMaizo      = 10; // 매장 자금

  // 지반침하
  var $disFallBorder = 90; // 안전 한계의 면적(Hex수)
  var $disFalldown   = 30; // 그 면적을 넘었을 경우의 확률

  // 괴수
  var $disMonsBorder1 = 1000; // 인구 기준 1(괴수 레벨 1)
  var $disMonsBorder2 = 2500; // 인구 기준 2(괴수 레벨 2)
  var $disMonsBorder3 = 4000; // 인구 기준 3(괴수 레벨 3)
  var $disMonster     = 3;    // 단위 면적당 출현율(0.01%단위)

  var $monsterLevel1  = 2; // 산지라까지    
  var $monsterLevel2  = 5; // 이노라 고우스트까지
  var $monsterLevel3  = 7; // 킹 이노라까지(전부)

  var $monsterNumber	= 8; // 괴수의 종류
  // 괴수의 이름
  var $monsterName	= array (
    '메카 이노라 ',
    '이노라 ',
    '산지라',
    '레드 이노라 ',
    '다크 이노라 ',
    '이노라 고우스트',
    '고래',
    '킹 이노라 '
    );
  // 괴수의 이미지
  var $monsterImage	= array (
    'monster7.gif',
    'monster0.gif',
    'monster5.gif',
    'monster1.gif',
    'monster2.gif',
    'monster8.gif',
    'monster6.gif',
    'monster3.gif',
    );
  // 이미지 파일 2(경화 상태)
  var $monsterImage2	= array ('', '', 'monster4.gif', '', '', '', 'monster4.gif', '');

  // 최저 체력, 체력의 폭, 특수 능력, 경험치, 시체의 가격
  var $monsterBHP	= array( 2,   1,   1,    3,   2,   1,    4,    5,   3,   2,   3,    5,    6);
  var $monsterDHP	= array( 0,   2,   2,    2,   2,   0,    2,    2,   1,   2,   2,    2,    3);
  var $monsterSpecial	= array( 0,   0,   3,    6,   1,   2,    4,    7,   5,   1,   2,    9,   10);
  var $monsterExp	= array( 5,   5,   7,   12,  15,  10,   20,   30,  20,  15,  20,   50,  100);
  var $monsterValue	= array( 0, 400, 500, 1000, 800, 300, 1500, 2000, 500, 600, 800, 3000, 3500);

  // 턴상을 몇 턴마다 수여할지
  var $turnPrizeUnit	= 100;

  // 상 이름
  var $prizeName	= array (
    '턴상',
    '번영상',
    '초번영상',
    '궁극 번영상',
    '평화상',
    '초평화상',
    '궁극 평화상',
    '재난상',
    '초재난상',
    '궁극 재난상',
    );

  // 기념비
  var $monumentNumber	= 1;
  var $monumentName	= array (
    '모노리스',
    );
  // 이미지 파일
  var $monumentImage = array (
    'monument0.gif',
    );

  /********************
      외관 관계
   ********************/
  // 큰 문자
  var $tagBig_ = '<span class="big">';
  var $_tagBig = '</span>';
  // 섬의 이름 등
  var $tagName_ = '<span class="islName">';
  var $_tagName = '</span>';
  // 얇아진 섬의 이름
  var $tagName2_ = '<span class="islName2">';
  var $_tagName2 = '</span>';
  // 순위의 번호 등
  var $tagNumber_ = '<span class="number">';
  var $_tagNumber = '</span>';
  // 순위표 제목
  var $tagTH_ = '<span class="head">';
  var $_tagTH = '</span>';
  // 개발 계획의 이름
  var $tagComName_ = '<span class="command">';
  var $_tagComName = '</span>';
  // 재해
  var $tagDisaster_ = '<span class="disaster">';
  var $_tagDisaster = '</span>';
  // 내부 게시판, 방문자가 쓴 문자
  var $tagLbbsSS_ = '<span class="lbbsSS">';
  var $_tagLbbsSS = '</span>';
  // 내부 게시판, 섬 소유자가 쓴 문자
  var $tagLbbsOW_ = '<span class="lbbsOW">';
  var $_tagLbbsOW = '</span>';
  // 순위표, 셀의 속성
  var $bgTitleCell   = 'class="TitleCell"';   // 순위표 제목
  var $bgNumberCell  = 'class="NumberCell"';  // 순위표 순위
  var $bgNameCell    = 'class="NameCell"';    // 순위표 섬 이름
  var $bgInfoCell    = 'class="InfoCell"';    // 순위표 섬 정보
  var $bgCommentCell = 'class="CommentCell"'; // 순위표 댓글란
  var $bgInputCell   = 'class="InputCell"';   // 개발 계획 폼
  var $bgMapCell     = 'class="MapCell"';     // 개발 계획 지도
  var $bgCommandCell = 'class="CommandCell"'; // 개발 계획 입력이 끝난 계획

  /********************
      지형 번호
   ********************/

  var $landSea		=  0; // 바다
  var $landWaste	=  1; // 황무지
  var $landPlains	=  2; // 평지
  var $landTown		=  3; // 마을계
  var $landForest	=  4; // 숲
  var $landFarm		=  5; // 농장
  var $landFactory	=  6; // 공장
  var $landBase		=  7; // 미사일 기지
  var $landDefence	=  8; // 방어 시설
  var $landMountain	=  9; // 산
  var $landMonster	= 10; // 괴수
  var $landSbase	= 11; // 해저 기지
  var $landOil		= 12; // 해저 유전
  var $landMonument	= 13; // 기념비
  var $landHaribote	= 14; // 위장 방어 시설
  /********************
       계획
   ********************/
  // 계획 분할
  // 이 계획 분할만은, 자동 입력계의 계획은 설정하지 마세요.
  var $commandDivido = 
	array(
	'개발, 0,10',  // 계획 번호 00~10
	'건설, 11,30', // 계획 번호 11~30
	'공격, 31,40', // 계획 번호 31~40
	'운영, 41,60'  // 계획 번호 41~60
	);
  // 주의: 공백이 들어가지 않도록
  // ○→	'개발, 0,10',  # 계획 번호 00~10
  // ×→	'개발, 0  , 10  ',  # 계획 번호 00~10

  var $commandTotal	= 28; // 계획의 종류
  // 순서
  var $comList;
  // 개간계
  var $comPrepare	= 01; // 개간
  var $comPrepare2	= 02; // 땅 고르기
  var $comReclaim	= 03; // 매립
  var $comDestroy	= 04; // 굴착
  var $comSellTree	= 05; // 벌채

  // 건설 계열
  var $comPlant		= 11; // 조림
  var $comFarm		= 12; // 농장 정비
  var $comFactory	= 13; // 공장 건설
  var $comMountain	= 14; // 채굴장 정비
  var $comBase		= 15; // 미사일 기지 건설
  var $comDbase		= 16; // 방어 시설 건설
  var $comSbase		= 17; // 해저 기지 건설
  var $comMonument	= 18; // 기념비 건설
  var $comHaribote	= 19; // 위장 방어 시설 설치

  // 발사계
  var $comMissileNM	= 31; // 미사일 발사
  var $comMissilePP	= 32; // PP미사일 발사
  var $comMissileST	= 33; // ST미사일 발사
  var $comMissileLD	= 34; // 육지 파괴탄 발사
  var $comSendMonster	= 35; // 괴수 파견

  // 운영계
  var $comDoNothing	= 41; // 자금 융통
  var $comSell		= 42; // 식량 수출
  var $comMoney		= 43; // 자금 원조
  var $comFood		= 44; // 식량 원조
  var $comPropaganda	= 45; // 인구 유치 활동
  var $comGiveup	= 46; // 섬의 포기

  // 자동 입력계
  var $comAutoPrepare	= 61; // 모두 개간
  var $comAutoPrepare2	= 62; // 모두 땅 고르기
  var $comAutoDelete	= 63; // 전체 계획 삭제

  var $comName;
  var $comCost;

  // 섬의 좌표수
  var $pointNumber;

  // 주위 2 헥스의 좌표
  var $ax = array(0, 1, 1, 1, 0,-1, 0, 1, 2, 2, 2, 1, 0,-1,-1,-2,-1,-1, 0);
  var $ay = array(0,-1, 0, 1, 1, 0,-1,-2,-1, 0, 1, 2, 2, 2, 1, 0,-1,-2,-2);

  // 댓글 등에 백슬래시가 자동 추가되는 경우 처리
  var $stripslashes;

  function setVariable() {
    $this->pointNumber = $this->islandSize * $this->islandSize;

    $this->comList	= array(
      $this->comPrepare,
      $this->comSell,
      $this->comPrepare2,
      $this->comReclaim,
      $this->comDestroy,
      $this->comSellTree,
      $this->comPlant,
      $this->comFarm,
      $this->comFactory,
      $this->comMountain,
      $this->comBase,
      $this->comDbase,
      $this->comSbase,
      $this->comMonument,
      $this->comHaribote,
      $this->comMissileNM,
      $this->comMissilePP,
      $this->comMissileST,
      $this->comMissileLD,
      $this->comSendMonster,
      $this->comDoNothing,
      $this->comMoney,
      $this->comFood,
      $this->comPropaganda,
      $this->comGiveup,
      $this->comAutoPrepare,
      $this->comAutoPrepare2,
      $this->comAutoDelete,
      );
    // 계획의 이름과 가격
    $this->comName[$this->comPrepare]      = '개간';
    $this->comCost[$this->comPrepare]      = 5;
    $this->comName[$this->comPrepare2]     = '땅 고르기';
    $this->comCost[$this->comPrepare2]     = 100;
    $this->comName[$this->comReclaim]      = '매립';
    $this->comCost[$this->comReclaim]      = 150;
    $this->comName[$this->comDestroy]      = '굴착';
    $this->comCost[$this->comDestroy]      = 200;
    $this->comName[$this->comSellTree]     = '벌채';
    $this->comCost[$this->comSellTree]     = 0;
    $this->comName[$this->comPlant]        = '조림';
    $this->comCost[$this->comPlant]        = 50;
    $this->comName[$this->comFarm]         = '농장 정비';
    $this->comCost[$this->comFarm]         = 20;
    $this->comName[$this->comFactory]      = '공장 건설';
    $this->comCost[$this->comFactory]      = 100;
    $this->comName[$this->comMountain]     = '채굴장 정비';
    $this->comCost[$this->comMountain]     = 300;
    $this->comName[$this->comBase]         = '미사일 기지 건설';
    $this->comCost[$this->comBase]         = 300;
    $this->comName[$this->comDbase]        = '방어 시설 건설';
    $this->comCost[$this->comDbase]        = 800;
    $this->comName[$this->comSbase]        = '해저 기지 건설';
    $this->comCost[$this->comSbase]        = 8000;
    $this->comName[$this->comMonument]     = '기념비 건설';
    $this->comCost[$this->comMonument]     = 9999;
    $this->comName[$this->comHaribote]     = '위장 방어 시설 설치';
    $this->comCost[$this->comHaribote]     = 1;
    $this->comName[$this->comMissileNM]    = '미사일 발사';
    $this->comCost[$this->comMissileNM]    = 20;
    $this->comName[$this->comMissilePP]    = 'PP미사일 발사';
    $this->comCost[$this->comMissilePP]    = 50;
    $this->comName[$this->comMissileST]    = 'ST미사일 발사';
    $this->comCost[$this->comMissileST]    = 50;
    $this->comName[$this->comMissileLD]    = '육지 파괴탄 발사';
    $this->comCost[$this->comMissileLD]    = 100;
    $this->comName[$this->comSendMonster]  = '괴수 파견';
    $this->comCost[$this->comSendMonster]  = 3000;
    $this->comName[$this->comDoNothing]    = '자금 융통';
    $this->comCost[$this->comDoNothing]    = 0;
    $this->comName[$this->comSell]         = '식량 수출';
    $this->comCost[$this->comSell]         = -100;
    $this->comName[$this->comMoney]        = '자금 원조';
    $this->comCost[$this->comMoney]        = 100;
    $this->comName[$this->comFood]         = '식량 원조';
    $this->comCost[$this->comFood]         = -100;
    $this->comName[$this->comPropaganda]   = '인구 유치 활동';
    $this->comCost[$this->comPropaganda]   = 1000;
    $this->comName[$this->comGiveup]       = '섬의 포기';
    $this->comCost[$this->comGiveup]       = 0;
    $this->comName[$this->comAutoPrepare]  = '개간 자동 입력';
    $this->comCost[$this->comAutoPrepare]  = 0;
    $this->comName[$this->comAutoPrepare2] = '땅 고르기 자동 입력';
    $this->comCost[$this->comAutoPrepare2] = 0;
    $this->comName[$this->comAutoDelete]   = '전체 계획 취소';
    $this->comCost[$this->comAutoDelete]   = 0;

  }
  function __construct() {
    $this->setVariable();
    mt_srand(time());
    // 서버 시간을 JST 기준으로 맞출 때 사용
    // 필요하면 다음 줄의 주석을 해제한다.
    // putenv("TZ=JST-9");

    // 백슬래시가 자동 추가되는 경우 처리
    $this->stripslashes = false;
  }
}
?>