<?php
/*******************************************************************

  모형정원 제도 2 for PHP

  
  $Id: hako-turn.php,v 1.12 2004/12/14 12:25:38 Watson Exp $

*******************************************************************/

require 'hako-log.php';

#[\AllowDynamicProperties]
class Make {
  //---------------------------------------------------
  // 섬의 신규 작성 모드
  //---------------------------------------------------
  function newIsland($hako,$data){
    global $init;
    $log = new Log;
    if($hako->islandNumber >= $init->maxIsland){
      HakoError::newIslandFull();
      return;
    }
    if(empty($data['ISLANDNAME'])){
      HakoError::newIslandNoName();
      return;
    }
    // 이름이 정당화 체크
    if(preg_match("/[,?()<>$]/", $data['ISLANDNAME'])|| strcmp($data['ISLANDNAME'],"무인도")== 0){
      HakoError::newIslandBadName();
      return;
    }
    // 이름의 중복 체크
    if(Util::nameToNumber($hako,$data['ISLANDNAME'])!= -1){
      HakoError::newIslandAlready();
      return;
    }
    // 비밀번호의 존재 판정
    if(empty($data['PASSWORD'])){
      HakoError::newIslandNoPassword();
      return;
    }
    if(strcmp($data['PASSWORD'],$data['PASSWORD2'])!= 0){
      HakoError::wrongPassword();
      return;
    }
    // 새로운 섬의 번호를 결정한다
    $newNumber = $hako->islandNumber;
    $hako->islandNumber++;
    $island = $this->makeNewIsland();

    // 각종의 값을 설정
    $island['name']  = htmlspecialchars($data['ISLANDNAME']);
    $island['owner'] = htmlspecialchars($data['OWNERNAME']);
    $island['id']    = $hako->islandNextID;
    $hako->islandNextID++;
    $island['absent'] = $init->giveupTurn - 3;
    $island['comment'] = '(미등록)';
    $island['comment_turn'] = $hako->islandTurn;
    $island['password'] = Util::encode($data['PASSWORD']);

    Turn::estimate($island);
    $hako->islands[$newNumber] = $island;
    $hako->writeIslandsFile($island['id']);

    $log->discover($island['name']);

    $htmlMap = new HtmlMap;
    $htmlMap->newIslandHead($island['name']);
    $htmlMap->islandInfo($island,$newNumber);
    $htmlMap->islandMap($hako,$island,1,$data);
    
  }
  //---------------------------------------------------
  // 새로운 섬을 작성한다
  //---------------------------------------------------
  function makeNewIsland(){
    global $init;
    $command = array();
    // 초기 계획 생성
    for($i = 0; $i < $init->commandMax; $i++){
      $command[$i] = array(
        'kind'   => $init->comDoNothing,
        'target' => 0,
        'x'      => 0,
        'y'      => 0,
        'arg'    => 0,
        );
    }
    $lbbs = array();
    // 초기 게시판 생성
    for($i = 0; $i < $init->lbbsMax; $i++){
      $lbbs[$i] = "0>>";
    }
    $land = array();
    $landValue = array();
    // 기본형을 작성
    for($y = 0; $y < $init->islandSize; $y++){
      for($x = 0; $x < $init->islandSize; $x++){
        $land[$x][$y]      = $init->landSea;
        $landValue[$x][$y] = 0;
      }
    }
    
    // 4*4에 황무지를 배치
    $center = intdiv($init->islandSize, 2) - 1;
    for($y = $center -1; $y < $center + 3; $y++){
      for($x = $center - 1; $x < $center + 3; $x++){
        $land[$x][$y] = $init->landWaste;
      }
    }
    // 8*8범위내에 육지를 증식
    for($i = 0; $i < 120; $i++){
      $x = Util::random(8)+ $center - 3;
      $y = Util::random(8)+ $center - 3;
      if(Turn::countAround($land,$x,$y,$init->landSea,7)!= 7){
        // 주위에 육지가 있는 경우,얕은 여울로 한다
        // 얕은 여울은 황무지로 한다
        // 황무지는 평지로 한다
        if($land[$x][$y] == $init->landWaste){
          $land[$x][$y] = $init->landPlains;
          $landValue[$x][$y] = 0;
        } else {
          if($landValue[$x][$y] == 1){
            $land[$x][$y] = $init->landWaste;
            $landValue[$x][$y] = 0;
          } else {
            $landValue[$x][$y] = 1;
          }
        }
      }
    }
    // 숲을 만든다
    $count = 0;
    while($count < 4){
      // 랜덤 좌표
      $x = Util::random(4)+ $center - 1;
      $y = Util::random(4)+ $center - 1;

      // 그곳이 이미 숲이 아니면,숲을 만든다
      if($land[$x][$y] != $init->landForest){
        $land[$x][$y] = $init->landForest;
        $landValue[$x][$y] = 5; // 처음은 500개
        $count++;
      }
    }
    $count = 0;
    while($count < 2){
      // 랜덤 좌표
      $x = Util::random(4)+ $center - 1;
      $y = Util::random(4)+ $center - 1;

      // 그곳이 숲이나 마을이 아니면,마을을 만든다
      if(($land[$x][$y] != $init->landTown)&&
        ($land[$x][$y] != $init->landForest)){
        $land[$x][$y] = $init->landTown;
        $landValue[$x][$y] = 5; // 처음은 500명
        $count++;
      }
    }

    // 산을 만든다
    $count = 0;
    while($count < 1){
      // 랜덤 좌표
      $x = Util::random(4)+ $center - 1;
      $y = Util::random(4)+ $center - 1;

      // 그곳이 숲이나 마을이 아니면,마을을 만든다
      if(($land[$x][$y] != $init->landTown)&&
        ($land[$x][$y] != $init->landForest)){
        $land[$x][$y] = $init->landMountain;
        $landValue[$x][$y] = 0; // 처음은 채굴장 없음
        $count++;
      }
    }

    // 기지를 만든다
    $count = 0;
    while($count < 1){
      // 랜덤 좌표
      $x = Util::random(4)+ $center - 1;
      $y = Util::random(4)+ $center - 1;

      // 그곳이 숲이나 마을이나 산이 아니면,기지
      if(($land[$x][$y] != $init->landTown)&&
        ($land[$x][$y] != $init->landForest)&&
        ($land[$x][$y] != $init->landMountain)){
        $land[$x][$y] = $init->landBase;
        $landValue[$x][$y] = 0;
        $count++;
      }
    }

    return array(
      'money'	  => $init->initialMoney,
      'food'	  => $init->initialFood,
      'land'	  => $land,
      'landValue' => $landValue,
      'command'	  => $command,
      'lbbs'	  => $lbbs,
      'prize'	  => '0,0,',
      );    
  }
  //---------------------------------------------------
  // 댓글 업데이트
  //---------------------------------------------------
  function commentMain($hako,$data){
    $id  = $data['ISLANDID'];
    $num = $hako->idToNumber[$id];
    $island = $hako->islands[$num];
    $name = $island['name'];

    // 비밀번호
    if(!Util::checkPassword($island['password'],$data['PASSWORD'])){
      // password 실수
      HakoError::wrongPassword();
      return;
    }
    // 메시지를 업데이트
    $island['comment'] = htmlspecialchars($data['MESSAGE']);
    $island['comment_turn'] = $hako->islandTurn;
    $hako->islands[$num] = $island;

    // 데이터의 서두
    $hako->writeIslandsFile();

    // 댓글 업데이트 메시지
    HtmlSetted::Comment();

    
    // owner mode에
    if($data['DEVELOPEMODE'] == "cgi"){
      $html = new HtmlMap;
    } else {
      $html = new HtmlJS;
    }
    $html->owner($hako,$data);
  }
  //---------------------------------------------------
  // 내부 게시판 모드
  //---------------------------------------------------
  function localBbsMain($hako,$data){
    $id  = $data['ISLANDID'];
    $num = $hako->idToNumber[$id];
    $island = $hako->islands[$num];
    $name = $island['name'];

    // 해당 섬이 없는 경우
    if(empty($data['ISLANDID'])){
      HakoError::problem();
      return;
    }

    // 삭제 모드가 아니고 이름이나 메시지가 없는 경우
    if($data['lbbsMode'] != 2){
      if(empty($data['LBBSNAME'])||(empty($data['LBBSMESSAGE']))){
        HakoError::lbbsNoMessage();
        return;
      }
    }

    // 방문자 모드가 아닐 때는 비밀번호 체크
    if($data['lbbsMode'] != 0){
      if(!Util::checkPassword($island['password'],$data['PASSWORD'])){
        // password 실수
        HakoError::wrongPassword();
        return;
      }
    }

    $lbbs = $island['lbbs'];

    // 모드로 분기
    if($data['lbbsMode'] == 2){
      // 삭제 모드
      // 메시지를 앞에 두고 비켜 놓는다
      Util::slideBackLbbsMessage($lbbs,$data['NUMBER']);
      HtmlSetted::lbbsDelete();
    } else {
      // 기장 모드
      Util::slideLbbsMessage($lbbs);

      // 메시지 작성
      if($data['lbbsMode'] == 0){
        $message = '0';
      } else {
        $message = '1';
      }
      $bbs_name = "{$hako->islandTurn}：" . htmlspecialchars($data['LBBSNAME']);
      $bbs_message = htmlspecialchars($data['LBBSMESSAGE']);
      $lbbs[0] = "{$message}>{$bbs_name}>{$bbs_message}";

      HtmlSetted::lbbsAdd();
    }
    $island['lbbs'] = $lbbs;
    $hako->islands[$num] = $island;

    // 데이터 서두
    $hako->writeIslandsFile($id);

    if($data['DEVELOPEMODE'] == "cgi"){
      $html = new HtmlMap;
    } else {
      $html = new HtmlJS;
    }
    // 원래의 모드에
    if($data['lbbsMode'] == 0){
      $html->visitor($hako,$data);
    } else {
      $html->owner($hako,$data);
    }
  }
  //---------------------------------------------------
  // 정보 변경 모드
  //---------------------------------------------------
  function changeMain($hako,$data){
    global $init;
    $log = new Log;
    
    $id  = $data['ISLANDID'];
    $num = $hako->idToNumber[$id];
    $island = $hako->islands[$num];
    $name = $island['name'];

    // 비밀번호 체크
    if(strcmp($data['OLDPASS'],$init->specialPassword)== 0){
      // 특수 비밀번호
      $island['money'] = $init->maxMoney;
      $island['food']  = $init->maxFood;
    } elseif(!Util::checkPassword($island['password'],$data['OLDPASS'])){
      // password 실수
      HakoError::wrongPassword();
      return;
    }

    // 확인용 비밀번호
    if(strcmp($data['PASSWORD'],$data['PASSWORD2'])!= 0){
      // password 실수
      HakoError::wrongPassword();
      return;
    }

    if(!empty($data['ISLANDNAME'])){
      // 이름 변경의 경우
      // 이름이 정당한가 체크
      if(preg_match("/[,?()<>$]/", $data['ISLANDNAME'])|| strcmp($data['ISLANDNAME'],"무인도")== 0){
        HakoError::newIslandBadName();
        return;
      }

      // 이름의 중복 체크
      if(Util::nameToNumber($hako,$data['ISLANDNAME'])!= -1){
        HakoError::newIslandAlready();
        return;
      }

      if($island['money'] < $init->costChangeName){
        // 돈이 부족하다
        HakoError::changeNoMoney();
        return;
      }

      // 대금
      if(strcmp($data['OLDPASS'],$init->specialPassword)!= 0){
        $island['money'] -= $init->costChangeName;
      }

      // 이름을 변경
      $log->changeName($island['name'],$data['ISLANDNAME']);
      $island['name'] = $data['ISLANDNAME'];
      $flag = 1;
    }

    // password 변경의 경우
    if(!empty($data['PASSWORD'])){
      // 비밀번호를 변경
      $island['password'] = Util::encode($data['PASSWORD']);
      $flag = 1;
    }

    if(($flag == 0)&&(strcmp($data['PASSWORD'],$data['PASSWORD2'])!= 0)){
      // 어느쪽이나 변경되어 있지 않다
      HakoError::changeNothing();
      return;
    }

    $hako->islands[$num] = $island;
    // 데이터 서두
    $hako->writeIslandsFile($id);

    // 변경 성공
    HtmlSetted::change();
  }
  //---------------------------------------------------
  // 소유자명 변경 모드
  //---------------------------------------------------
  function changeOwnerName($hako,$data){
    global $init;

    $id  = $data['ISLANDID'];
    $num = $hako->idToNumber[$id];
    $island = $hako->islands[$num];

    // 비밀번호 체크
    if(strcmp($data['OLDPASS'],$init->specialPassword)== 0){
      // 특수 비밀번호
      $island['money'] = $init->maxMoney;
      $island['food']  = $init->maxFood;
    } elseif(!Util::checkPassword($island['password'],$data['OLDPASS'])){
      // password 실수
      HakoError::wrongPassword();
      return;
    }
    $island['owner'] = htmlspecialchars($data['OWNERNAME']);
    $hako->islands[$num] = $island;
    // 데이터 서두
    $hako->writeIslandsFile($id);

    // 변경 성공
    HtmlSetted::change();
  }
  //---------------------------------------------------
  // 계획 모드
  //---------------------------------------------------
  function commandMain($hako,$data){
    global $init;
    $id  = $data['ISLANDID'];
    $num = $hako->idToNumber[$id];
    $island = $hako->islands[$num];
    $name = $island['name'];

    // 비밀번호
    if(!Util::checkPassword($island['password'],$data['PASSWORD'])){
      // password 실수
      HakoError::wrongPassword();
      return;
    }

    // 모드로 분기
    $command = $island['command'];

    if(strcmp($data['COMMANDMODE'],'delete')== 0){
      Util::slideFront($command,$data['NUMBER']);
      HtmlSetted::commandDelete();
    } elseif(($data['COMMAND'] == $init->comAutoPrepare)||
            ($data['COMMAND'] == $init->comAutoPrepare2)){
      // 풀정지,풀 땅 고르는 일
      // 좌표 배열을 만든다
      $r = Util::makeRandomPointArray();
      $rpx = $r[0];
      $rpy = $r[1];
      $land = $island['land'];
      // 계획의 종류 결정
      $kind = $init->comPrepare;
      if($data['COMMAND'] == $init->comAutoPrepare2){
        $kind = $init->comPrepare2;
      }

      $i = $data['NUMBER'];
      $j = 0;
      while(($j < $init->pointNumber)&&($i < $init->commandMax)){
        $x = $rpx[$j];
        $y = $rpy[$j];
        if($land[$x][$y] == $init->landWaste){
          Util::slideBack($command,$data['NUMBER']);
          $command[$data['NUMBER']] = array(
            'kind'	=> $kind,
            'target'	=> 0,
            'x'		=> $x,
            'y'		=> $y,
            'arg'	=> 0,
            );
          $i++;
        }
        $j++;
      }
      HtmlSetted::commandAdd();
    } elseif($data['COMMAND'] == $init->comAutoDelete){
      // 전 지워
      for($i = 0; $i < $init->commandMax; $i++){
        Util::slideFront($command,0);
      }
      HtmlSetted::commandDelete();
    } else {
      if(strcmp($data['COMMANDMODE'],'insert')== 0){
        Util::slideBack($command,$data['NUMBER']);
      }
      HtmlSetted::commandAdd();
      // 계획를 등록
      $command[$data['NUMBER']] = array(
        'kind'   => $data['COMMAND'],
        'target' => $data['TARGETID'],
        'x'      => $data['POINTX'],
        'y'      => $data['POINTY'],
        'arg'    => $data['AMOUNT'],
        );
    }

    // 데이터의 서두
    $island['command'] = $command;
    $hako->islands[$num] = $island;
    $hako->writeIslandsFile($island['id']);

    // owner mode에
    $html = new HtmlMap;
    $html->owner($hako,$data);
  }
}
#[\AllowDynamicProperties]
class MakeJS extends Make {
  //---------------------------------------------------
  // 계획 모드
  //---------------------------------------------------
  function commandMain($hako,$data){
    global $init;
    $id  = $data['ISLANDID'];
    $num = $hako->idToNumber[$id];
    $island = $hako->islands[$num];
    $name = $island['name'];

    // 비밀번호
    if(!Util::checkPassword($island['password'],$data['PASSWORD'])){
      // password 실수
      HakoError::wrongPassword();
      return;
    }
    // 모드로 분기
    $command = $island['command'];
    $comary = explode(" ", $data['COMARY']);
    
    for($i = 0; $i < $init->commandMax; $i++){
      $pos = $i * 5;
      $kind   = $comary[$pos];
      $x      = $comary[$pos + 1];
      $y      = $comary[$pos + 2];
      $arg    = $comary[$pos + 3];
      $target = $comary[$pos + 4];
      // 계획 등록
      if($kind == 0){
        $kind = $init->comDoNothing;
      }
      $command[$i] = array(
        'kind'   => $kind,
        'x'      => $x,
        'y'      => $y,
        'arg'    => $arg,
        'target' => $target
        );
    }
    HtmlSetted::commandAdd();

    // 데이터의 서두
    $island['command'] = $command;
    $hako->islands[$num] = $island;
    $hako->writeIslandsFile($island['id']);

    // owner mode에
    $html = new HtmlJS;
    $html->owner($hako,$data);
  }
  
}
//--------------------------------------------------------------------
#[\AllowDynamicProperties]
class Turn {
  var $log;
  var $rpx;
  var $rpy;
  //---------------------------------------------------
  // 턴 진행 모드
  //---------------------------------------------------
  function turnMain(&$hako,$data){
    global $init;
    $this->log = new Log;
    
    // 최종 업데이트 시간을 업데이트
    $hako->islandLastTime += $init->unitTime;
    // 로그 파일을 뒤로 비켜 놓는다
    $this->log->slideBackLogFile();

    // 턴 번호
    $hako->islandTurn++;
    $GLOBALS['ISLAND_TURN'] = $hako->islandTurn;
    if($hako->islandNumber == 0){
      // 섬이 없으면 턴 수를 저장한 이후의 처리는 생략한다
      // 파일에 써내
      $hako->writeIslandsFile();
      return;
    }

    // 좌표 배열을 만든다
    $randomPoint = Util::makeRandomPointArray();
    $this->rpx = $randomPoint[0];
    $this->rpy = $randomPoint[1];
    // 차례 결정
    $order = Util::randomArray($hako->islandNumber);

    // 수입·소비
    for($i = 0; $i < $hako->islandNumber; $i++){
      $this->estimate($hako->islands[$order[$i]]);
      $this->income($hako->islands[$order[$i]]);

      // 인구를 메모 한다
      $hako->islands[$order[$i]]['oldPop'] = $hako->islands[$order[$i]]['pop'];
    }
    // 계획 처리
    for($i = 0; $i < $hako->islandNumber; $i++){
      // 반환값 1이 될 때까지 반복
      while($this->doCommand($hako,$hako->islands[$order[$i]])== 0);
    }
    // 성장 및 단헥스 재해
    for($i = 0; $i < $hako->islandNumber; $i++){
      $this->doEachHex($hako,$hako->islands[$order[$i]]);
    }
    // 섬전체 처리
    $remainNumber = $hako->islandNumber;
    for($i = 0; $i < $hako->islandNumber; $i++){
      $island = $hako->islands[$order[$i]];
      $this->doIslandProcess($hako,$island);

      // 사멸 판정
      if($island['dead'] == 1){
        $island['pop'] = 0;
        $remainNumber--;
      } elseif($island['pop'] == 0){
        $island['dead'] = 1;
        $remainNumber--;
        // 사멸 메시지
        $tmpid = $island['id'];
        $this->log->dead($tmpid,$island['name']);
        if(is_file("{$init->dirName}/island.{$tmpid}")){
          unlink("{$init->dirName}/island.{$tmpid}");
        }
      }
      $hako->islands[$order[$i]] = $island;
    }
    // 인구순서에 소트
    $this->islandSort($hako);
    // 턴상 대상 턴이라면,그 처리
    if(($hako->islandTurn % $init->turnPrizeUnit)== 0){
      $island = $hako->islands[0];
      $this->log->prize($island['id'],$island['name'],"{$hako->islandTurn}{$init->prizeName[0]}");
      $hako->islands[0]['prize'] .= "{$hako->islandTurn},";
    }
    // 도수컷
    $hako->islandNumber = $remainNumber;

    // 백업 턴이면,쓰기 전에 rename
    if(($hako->islandTurn % $init->backupTurn)== 0){
      $hako->backUp();
    }
    // 파일에 써내
    $hako->writeIslandsFile(-1);

    // 로그 서두
    $this->log->flush();

    // 기록 로그 조정
    $this->log->historyTrim();

  }
  //---------------------------------------------------
  // 코만드페이즈
  //---------------------------------------------------
  function doCommand(&$hako,&$island){
    global $init;

    $comArray = &$island['command'];
    $command  = $comArray[0];
    Util::slideFront($comArray,0);
    $island['command'] = $comArray;
    
    $kind   = $command['kind'];
    $target = $command['target'];
    $x      = $command['x'];
    $y      = $command['y'];
    $arg    = $command['arg'];

    $name = $island['name'];
    $id   = $island['id'];
    $land = $island['land'];
    $landValue = &$island['landValue'];
    $landKind = &$land[$x][$y];
    $lv   = $landValue[$x][$y];
    $cost = $init->comCost[$kind];
    $comName = $init->comName[$kind];
    $point = "({$x},{$y})";
    $landName = $this->landName($landKind,$lv);

    $prize = &$island['prize'];

    if($kind == $init->comDoNothing){
      //$this->log->doNothing($id,$name,$comName);
      $island['money'] += 10;
      $island['absent']++;
      // 자동 포기
      if($island['absent'] >= $init->giveupTurn){
        $comArray[0] = array(
          'kind'   => $init->comGiveup,
          'target' => 0,
          'x'      => 0,
          'y'      => 0,
          'arg'    => 0
          );
        $island['command'] = $comArray;
      }
      return 1;
    }
    $island['command'] = $comArray;
    $island['absent']  = 0;
    // 비용 체크
    if($cost > 0){
      // 돈의 경우
      if($island['money'] < $cost){
        $this->log->noMoney($id,$name,$comName);
        return 0;
      }
    } elseif($cost < 0){
      // 식량의 경우
      if($island['food'] <(-$cost)){
        $this->log->noFood($id,$name,$comName);
        return 0;
      }
    }

    $returnMode = 1;
    switch($kind){
    case $init->comPrepare:
    case $init->comPrepare2:
      // 정지,땅 고르는 일
      if(($landKind == $init->landSea)||
        ($landKind == $init->landSbase)||
        ($landKind == $init->landOil)||
        ($landKind == $init->landMountain)||
        ($landKind == $init->landMonster)){
        // 바다,해저 기지,유전,산,괴수는 중지할 수 없다
        $this->log->landFail($id,$name,$comName,$landName,$point);

        $returnMode = 0;
        break;
      }
      // 목표 지점를 평지로 한다
      $land[$x][$y] = $init->landPlains;
      $landValue[$x][$y] = 0;
      $this->log->landSuc($id,$name,'정지',$point);

      // 금을 공제한다
      $island['money'] -= $cost;

      if($kind == $init->comPrepare2){
        // 땅 고르는 일
        $island['prepare2']++;

        // 턴 소비하지 않고
        $returnMode = 0;
      } else {
        // 정지라면,매장 자금의 가능성이 있음
        if(Util::random(1000)< $init->disMaizo){
          $v = 100 + Util::random(901);
          $island['money'] += $v;
          $this->log->maizo($id,$name,$comName,$v);
        }
        $returnMode = 1;
      }
      break;
    case $init->comReclaim:
      // 매립
      if(($landKind != $init->landSea)&&
        ($landKind != $init->landOil)&&
        ($landKind != $init->landSbase)){
        // 바다,해저 기지,유전 밖에 매립하고 할 수 없다
        $this->log->landFail($id,$name,$comName,$landName,$point);

        $returnMode = 0;
        break;
      }

      // 주위에 육지가 있을까 체크
      $seaCount =
        Turn::countAround($land,$x,$y,$init->landSea,7)+
          Turn::countAround($land,$x,$y,$init->landOil,7)+
            Turn::countAround($land,$x,$y,$init->landSbase,7);

      if($seaCount == 7){
        // 전부해이니까 매립 불능
        $this->log->noLandAround($id,$name,$comName,$point);

        $returnMode = 0;
        break;
      }

      if(($landKind == $init->landSea)&&($lv == 1)){
        // 얕은 여울의 경우
        // 목표 지점를 황무지로 한다
        $land[$x][$y] = $init->landWaste;
        $landValue[$x][$y] = 0;
        $this->log->landSuc($id,$name,$comName,$point);
        $island['area']++;

        if($seaCount <= 4){
          // 주위의 바다가 3 헥스 이내이므로,얕은 여울로 한다

          for($i = 1; $i < 7; $i++){
            $sx = $x + $init->ax[$i];
            $sy = $y + $init->ay[$i];

            // 행에 의한 위치 조정
            if((($sy % 2)== 0)&&(($y % 2)== 1)){
              $sx--;
            }

            if(($sx < 0)||($sx >= $init->islandSize)||
              ($sy < 0)||($sy >= $init->islandSize)){
            } else {
              // 범위내의 경우
              if($land[$sx][$sy] == $init->landSea){
                $landValue[$sx][$sy] = 1;
              }
            }
          }
        }
      } else {
        // 바다라면,목표 지점를 얕은 여울로 한다
        $land[$x][$y] = $init->landSea;
        $landValue[$x][$y] = 1;
        $this->log->landSuc($id,$name,$comName,$point);
      }

      // 금을 공제한다
      $island['money'] -= $cost;
      $returnMode =  1;
      break;

    case $init->comDestroy:
      // 굴착
      if(($landKind == $init->landSbase)||
        ($landKind == $init->landOil)||
        ($landKind == $init->landMonster)){
        // 해저 기지,유전,괴수는 굴착할 수 없다
        $this->log->landFail($id,$name,$comName,$landName,$point);

        $returnMode = 0;
        break;
      }

      if(($landKind == $init->landSea)&&($lv == 0)){
        // 바다라면,유전 찾기
        // 투자액 결정
        if($arg == 0){ $arg = 1; }

        $value = min($arg *($cost),$island['money']);
        $str = "{$value}{$init->unitMoney}";
        $p = round($value / $cost);
        $island['money'] -= $value;

        // 발견될까 판정
        if($p > Util::random(100)){
          // 유전 발견된다
          $this->log->oilFound($id,$name,$point,$comName,$str);
          $land[$x][$y] = $init->landOil;
          $landValue[$x][$y] = 0;
        } else {
          // 헛됨 공격해에 끝난다
          $this->log->oilFail($id,$name,$point,$comName,$str);
        }
        $returnMode = 1;
        break;
      }

      // 목표 지점를 바다로 한다.산이라면 황무지에.얕은 여울이라면 바다에.
      if($landKind == $init->landMountain){
        $land[$x][$y] = $init->landWaste;
        $landValue[$x][$y] = 0;
      } elseif($landKind == $init->landSea){
        $landValue[$x][$y] = 0;
      } else {
        $land[$x][$y] = $init->landSea;
        $landValue[$x][$y] = 1;
        $island['area']--;
      }
      $this->log->landSuc($id,$name,$comName,$point);

      // 금을 공제한다
      $island['money'] -= $cost;

      $returnMode = 1;
      break;

    case $init->comSellTree:
      // 벌채
      if($landKind != $init->landForest){
        // 숲 이외는 벌채할 수 없다
        $this->log->landFail($id,$name,$comName,$landName,$point);

        $returnMode = 0;
        break;
      }

      // 목표 지점를 평지로 한다
      $land[$x][$y] = $init->landPlains;
      $landValue[$x][$y] = 0;
      $this->log->landSuc($id,$name,$comName,$point);

      // 매각금을 얻는다
      $island['money'] += $init->treeValue * $lv;

      $returnMode = 1;
      break;
    case $init->comPlant:
    case $init->comFarm:
    case $init->comFactory:
    case $init->comBase:
    case $init->comMonument:
    case $init->comHaribote:
    case $init->comDbase:
      // 지상 건설계
      if(!
        (($landKind == $init->landPlains)||
         ($landKind == $init->landTown)  ||
         (($landKind == $init->landMonument)&&($kind == $init->comMonument))||
         (($landKind == $init->landFarm)    &&($kind == $init->comFarm))    ||
         (($landKind == $init->landFactory) &&($kind == $init->comFactory)) ||
         (($landKind == $init->landDefence) &&($kind == $init->comDbase)))){
        // 부적당한 지형
        $this->log->landFail($id,$name,$comName,$landName,$point);

        $returnMode = 0;
        break;
      }

      // 종류로 분기
      switch($kind){
      case $init->comPlant:
        // 목표 지점를 숲으로 한다.
        $land[$x][$y] = $init->landForest;
        $landValue[$x][$y] = 1; // 나무는 최저 단위
        $this->log->PBSuc($id,$name,$comName,$point);
        break;

      case $init->comBase:
        // 목표 지점를 미사일 기지로 한다.
        $land[$x][$y] = $init->landBase;
        $landValue[$x][$y] = 0; // 경험치 0
        $this->log->PBSuc($id,$name,$comName,$point);
        break;

      case $init->comHaribote:
        // 목표 지점를 위장 방어 시설로 한다
        $land[$x][$y] = $init->landHaribote;
        $landValue[$x][$y] = 0;
        $this->log->hariSuc($id,$name,$comName,$init->comName[$init->comDbase],$point);
        break;

      case $init->comFarm:
        // 농장
        if($landKind == $init->landFarm){
          // 이미 농장의 경우
          $landValue[$x][$y] += 2; // 규모 + 2000명
          if($landValue[$x][$y] > 50){
            $landValue[$x][$y] = 50; // 최대 50000명
          }
        } else {
          // 목표 지점를 농장에
          $land[$x][$y] = $init->landFarm;
          $landValue[$x][$y] = 10; // 규모 = 10000명
        }
        $this->log->landSuc($id,$name,$comName,$point);
        break;

      case $init->comFactory:
        // 공장
        if($landKind == $init->landFactory){
          // 이미 공장의 경우
          $landValue[$x][$y] += 10; // 규모 + 10000명
          if($landValue[$x][$y] > 100){
            $landValue[$x][$y] = 100; // 최대 100000명
          }
        } else {
          // 목표 지점를 공장에
          $land[$x][$y] = $init->landFactory;
          $landValue[$x][$y] = 30; // 규모 = 10000명
        }
        $this->log->landSuc($id,$name,$comName,$point);
        break;
        
      case $init->comDbase:
        // 방어 시설
        if($landKind == $init->landDefence){
          // 이미 방어 시설의 경우
          $landValue[$x][$y] = 1; // 자폭 장치 세트
          $this->log->bombSet($id,$name,$landName,$point);
        } else {
          // 목표 지점를 방어 시설에
          $land[$x][$y] = $init->landDefence;
          $landValue[$x][$y] = 0;
          $this->log->landSuc($id,$name,$comName,$point);
        }
        break;
        
      case $init->comMonument:
        // 기념비
        if($landKind == $init->landMonument){
          // 이미 기념비의 경우
          // 대상 취득
          $tn = $hako->idToNumber[$target];
          if($tn != 0 && empty($tn)){
            // 대상이 이미 없다
            // 별도 메시지 없이 중지

            $returnMode = 0;
            break;
          }

          $hako->islands[$tn]['bigmissile']++;

          // 그 자리소는 황무지에
          $land[$x][$y] = $init->landWaste;
          $landValue[$x][$y] = 0;
          $this->log->monFly($id,$name,$landName,$point);
        } else {
          // 목표 지점를 기념비에
          $land[$x][$y] = $init->landMonument;
          if($arg >= $init->monumentNumber){
            $arg = 0;
          }
          $landValue[$x][$y] = $arg;
          $this->log->landSuc($id,$name,$comName,$point);
        }
        break;
      }

      // 금을 공제한다
      $island['money'] -= $cost;

      // 반복 횟수 포함라면,계획를 되돌린다
      if(($kind == $init->comFarm)||
        ($kind == $init->comFactory)){
        if($arg > 1){
          $arg--;
          Util::slideBack($comArray,0);
          $comArray[0] = array(
            'kind'   => $kind,
            'target' => $target,
            'x'      => $x,
            'y'      => $y,
            'arg'    => $arg
            );
        }
      }

      $returnMode = 1;
      break;
      // 여기까지 지상 건설계
    case $init->comMountain:
      // 채굴장
      if($landKind != $init->landMountain){
        // 산 이외에는 만들 수 없다
        $this->log->landFail($id,$name,$comName,$landName,$point);

        $returnMode = 0;
        break;
      }

      $landValue[$x][$y] += 5; // 규모 + 5000명
      if($landValue[$x][$y] > 200){
        $landValue[$x][$y] = 200; // 최대 200000명
      }
      $this->log->landSuc($id,$name,$comName,$point);

      // 금을 공제한다
      $island['money'] -= $cost;
      if($arg > 1){
        $arg--;
        Util::slideBack($comArray,0);
        $comArray[0] = array(
          'kind'   => $kind,
          'target' => $target,
          'x'      => $x,
          'y'      => $y,
          'arg'    => $arg,
          );
      }
      $returnMode = 1;
      break;

    case $init->comSbase:
      // 해저 기지
      if(($landKind != $init->landSea)||($lv != 0)){
        // 바다 이외에는 만들 수 없다
        $this->log->landFail($id,$name,$comName,$landName,$point);
        $returnMode = 0;
        break;
      }

      $land[$x][$y] = $init->landSbase;
      $landValue[$x][$y] = 0; // 경험치 0
      $this->log->landSuc($id,$name,$comName,'(?,?)');

      // 금을 공제한다
      $island['money'] -= $cost;
      $returnMode = 1;
      break;

    case $init->comMissileNM:
    case $init->comMissilePP:
    case $init->comMissileST:
    case $init->comMissileLD:
      // 미사일계
      // 대상 취득
      $tn = $hako->idToNumber[$target];
      if($tn != 0 && empty($tn)){
        // 대상이 이미 없다
        $this->log->msNo대상($id,$name,$comName);

        $returnMode = 0;
        break;
      }

      $flag = 0;
      if($arg == 0){
        // 0의 경우는 공격할 수 있을 뿐
        $arg = 10000;
      }

      // 사전 준비
      $tIsland = &$hako->islands[$tn];
      $tName   = &$tIsland['name'];
      $tLand   = &$tIsland['land'];
      $tLandValue = &$tIsland['landValue'];
      // 난민의 수
      $boat = 0;

      // 오차
      if($kind == $init->comMissilePP){
        $err = 7;
      } else {
        $err = 19;
      }

      $bx = $by = 0;
      // 금이 바닥날까 지정수 기에 충분할까 기지 전부가 공격할 때까지 루프
      while(($arg > 0)&&
           ($island['money'] >= $cost)){
        // 기지를 찾아낼 때까지 루프
        while($count < $init->pointNumber){
          $bx = $this->rpx[$count];
          $by = $this->rpy[$count];
          if(($land[$bx][$by] == $init->landBase)||
            ($land[$bx][$by] == $init->landSbase)){
            break;
          }
          $count++;
        }
        if($count >= $init->pointNumber){
          // 발견되지 않았으면 거기까지
          break;
        }
        // 최저1개(살)기지가 있었으므로,flag를 세운다
        $flag = 1;
        // 기지의 레벨을 산출
        $level = Util::expToLevel($land[$bx][$by],$landValue[$bx][$by]);
        // 기지내에서 루프
        while(($level > 0)&&
             ($arg > 0)&&
             ($island['money'] > $cost)){
          // 공격했던 것이 확정이므로,각 치를 소모시킨다
          $level--;
          $arg--;
          $island['money'] -= $cost;

          // 착탄점산출
          $r = Util::random($err);
          $tx = $x + $init->ax[$r];
          $ty = $y + $init->ay[$r];
          if((($ty % 2)== 0)&&(($y % 2)== 1)){
            $tx--;
          }

          // 착탄점범위내외 체크
          if(($tx < 0)||($tx >= $init->islandSize)||
            ($ty < 0)||($ty >= $init->islandSize)){
            // 범위 밖
            if($kind == $init->comMissileST){
              // 스텔스
              $this->log->msOutS($id,$target,$name,$tName,$comName,$point);
            } else {
              // 통상계
              $this->log->msOut($id,$target,$name,$tName,$comName,$point);
            }
            break;
          }

          // 착탄점의 지형등 산출
          $tL  = $tLand[$tx][$ty];
          $tLv = $tLandValue[$tx][$ty];
          $tLname = $this->landName($tL,$tLv);
          $tPoint = "({$tx},{$ty})";

          // 방어 시설 판정
          $defence = 0;
          if($defenceHex[$id][$tx][$ty] == 1){
            $defence = 1;
          } elseif($defenceHex[$id][$tx][$ty] == -1){
            $defence = 0;
          } else {
            if($tL == $init->landDefence){
              // 방어 시설에 명중
              // 플래그를 클리어
              for($i = 0; $i < 19; $i++){
                $sx = $tx + $init->ax[$i];
                $sy = $ty + $init->ay[$i];

                // 행에 의한 위치 조정
                if((($sy % 2)== 0)&&(($ty % 2)== 1)){
                  $sx--;
                }

                if(($sx < 0)||($sx >= $init->islandSize)||
                  ($sy < 0)||($sy >= $init->islandSize)){
                  // 범위 밖의 경우 아무것도 하지 않는다
                } else {
                  // 범위내의 경우
                  $defenceHex[$id][$sx][$sy] = 0;
                }
              }
            } elseif(Turn::countAround($tLand,$tx,$ty,$init->landDefence,19)){
              $defenceHex[$id][$tx][$ty] = 1;
              $defence = 1;
            } else {
              $defenceHex[$id][$tx][$ty] = -1;
              $defence = 0;
            }
          }

          if($defence == 1){
            // 공중 폭파
            if($kind == $init->comMissileST){
              // 스텔스
              $this->log->msCaughtS($id,$target,$name,$tName,$comName,$point,$tPoint);
            } else {
              // 통상계
              $this->log->msCaught($id,$target,$name,$tName,$comName,$point,$tPoint);
            }
            break;
          }

          // 「효과 없음」hex를 최초로 판정
          if((($tL == $init->landSea)&&($tLv == 0))|| // 깊은 바다
            ((($tL == $init->landSea)||    // 바다 또는···
              ($tL == $init->landSbase)||  // 해저 기지 또는···
              ($tL == $init->landMountain))// 산에서···
              &&($kind != $init->comMissileLD))){ // 륙파탄 이외
            // 해저 기지의 경우,바다의 가장
            if($tL == $init->landSbase){
              $tL = $init->landSea;
            }
            $tLname = $this->landName($tL,$tLv);

            // 무효화
            if($kind == $init->comMissileST){
              // 스텔스
              $this->log->msNoDamageS($id,$target,$name,$tName,$comName,$tLname,$point,$tPoint);
            } else {
              // 통상계
              $this->log->msNoDamage($id,$target,$name,$tName,$comName,$tLname,$point,$tPoint);
            }
            continue;
          }

          // 총알의 종류로 분기
          if($kind == $init->comMissileLD){
            // 육지 파괴탄
            switch($tL){
            case $init->landMountain:
              // 산(황무지가 된다)
              $this->log->msLDMountain($id,$target,$name,$tName,$comName,$tLname,$point,$tPoint);
              // 황무지가 된다
              $tLand[$tx][$ty] = $init->landWaste;
              $tLandValue[$tx][$ty] = 0;
              continue 2;

            case $init->landSbase:
              // 해저 기지
              $this->log->msLDSbase($id,$target,$name,$tName,$comName,$tLname,$point,$tPoint);
              break;
              
            case $init->landMonster:
              // 괴수
              $this->log->msLDMonster($id,$target,$name,$tName,$comName,$tLname,$point,$tPoint);
              break;
              
            case $init->landSea:
              // 얕은 여울
              $this->log->msLDSea1($id,$target,$name,$tName,$comName,$tLname,$point,$tPoint);
              break;
              
            default:
              // 그 밖
              $this->log->msLDLand($id,$target,$name,$tName,$comName,$tLname,$point,$tPoint);
            }

            // 경험치
            if($tL == $init->landTown){
              if(($land[$bx][$by] == $init->landBase)||
                ($land[$bx][$by] == $init->landSbase)){
                // 아직 기지의 경우만
                $landValue[$bx][$by] += round($tLv / 20);
                if($landValue[$bx][$by] > $init->maxExpPoint){
                  $landValue[$bx][$by] = $init->maxExpPoint;
                }
              }
            }

            // 얕은 여울이 된다
            $tLand[$tx][$ty] = $init->landSea;
            $tIsland['area']--;
            $tLandValue[$tx][$ty] = 1;

            // 그렇지만 유전,얕은 여울,해저 기지라면 바다
            if(($tL == $init->landOil)||
              ($tL == $init->landSea)||
              ($tL == $init->landSbase)){
              $tLandValue[$tx][$ty] = 0;
            }
          } else {
            // 그 밖 미사일
            if($tL == $init->landWaste){
              // 황무지(피해 없음)
              if($kind == $init->comMissileST){
                // 스텔스
                $this->log->msWasteS($id,$target,$name,$tName,$comName,$tLname,$point,$tPoint);
              } else {
                // 통상
                $this->log->msWaste($id,$target,$name,$tName,$comName,$tLname,$point,$tPoint);
              }
            } elseif($tL == $init->landMonster){
              // 괴수
              $monsSpec = Util::monsterSpec($tLv);
              $special = $init->monsterSpecial[$monsSpec['kind']];

              // 경화 상태?
              if((($special == 3)&&(($hako->islandTurn % 2)== 1))||
                (($special == 4)&&(($hako->islandTurn % 2)== 0))){
                // 경화 상태
                if($kind == $init->comMissileST){
                  // 스텔스
                  $this->log->msMonNoDamageS($id,$target,$name,$tName,$comName,$tLname,$point,$tPoint);
                } else {
                  // 통상탄
                  $this->log->msMonNoDamage($id,$target,$name,$tName,$comName,$tLname,$point,$tPoint);
                }
                continue;
              } else {
                // 경화 상태이 아니다
                if($monsSpec['hp'] == 1){
                  // 괴수 쏘아 죽였다
                  if(($land[$bx][$by] == $init->landBase)||
                    ($land[$bx][$by] == $init->landSbase)){
                    // 경험치
                    $landValue[$bx][$by] += $init->monsterExp[$monsSpec['kind']];
                    if($landValue[$bx][$by] > $init->maxExpPoint){
                      $landValue[$bx][$by] = $init->maxExpPoint;
                    }
                  }

                  if($kind == $init->comMissileST){
                    // 스텔스
                    $this->log->msMonKillS($id,$target,$name,$tName,$comName,$tLname,$point,$tPoint);
                  } else {
                    // 통상
                    $this->log->msMonKill($id,$target,$name,$tName,$comName,$tLname,$point,$tPoint);
                  }

                  // 수입
                  $value = $init->monsterValue[$monsSpec['kind']];
                  if($value > 0){
                    $tIsland['money'] += $value;
                    $this->log->msMonMoney($target,$tLname,$value);
                  }

                  // 상관계
//                  $prize = $island['prize'];
                  list($flags,$monsters,$turns)= explode(",", $prize, 3);
                  $v = 1 << $monsSpec['kind'];
                  $monsters |= $v;

                  $prize = "{$flags},{$monsters},{$turns}";
//                  $island['prize'] = "{$flags},{$monsters},{$turns}";
                } else {
                  // 괴수 살아 있다
                  if($kind == $init->comMissileST){
                    // 스텔스
                    $this->log->msMonsterS($id,$target,$name,$tName,$comName,$tLname,$point,$tPoint);
                  } else {
                    // 통상
                    $this->log->msMonster($id,$target,$name,$tName,$comName,$tLname,$point,$tPoint);
                  }
                  // HP가  1줄어든다
                  $tLandValue[$tx][$ty]--;
                  continue;
                }

              }
            } else {
              // 통상 지형
              if($kind == $init->comMissileST){
                // 스텔스
                $this->log->msNormalS($id,$target,$name,$tName,$comName,$tLname,$point,$tPoint);
              } else {
                // 통상
                $this->log->msNormal($id,$target,$name,$tName,$comName,$tLname,$point,$tPoint);
              }
            }
            // 경험치
            if($tL == $init->landTown){
              if(($land[$bx][$by] == $init->landBase)||
                ($land[$bx][$by] == $init->landSbase)){
                $landValue[$bx][$by] += round($tLv / 20);
                $boat += $tLv; // 통상 미사일이므로 난민에게 플러스
                if($landValue[$bx][$by] > $init->maxExpPoint){
                  $landValue[$bx][$by] = $init->maxExpPoint;
                }
              }
            }

            // 황무지가 된다
            $tLand[$tx][$ty] = $init->landWaste;
            $tLandValue[$tx][$ty] = 1; // 착탄점
            // 그렇지만 유전이라면 바다
            if($tL == $init->landOil){
              $tLand[$tx][$ty] = $init->landSea;
              $tLandValue[$tx][$ty] = 0;
            }
          }
        }

        // 카운트증가나 해 둔다
        $count++;
      }


      if($flag == 0){
        // 기지가 1개나 없었던 경우
        $this->log->msNoBase($id,$name,$comName);

        $returnMode = 0;
        break;
      }
      
      $tIsland['land'] = $tLand;
      $tIsland['landValue'] = $tLandValue;
      unset($hako->islands[$tn]);
      $hako->islands[$tn] = $tIsland;
      
      
      // 난민 판정
      $boat = round($boat / 2);
      if(($boat > 0)&&($id != $target)&&($kind != $init->comMissileST)){
        // 난민 표착
        $achive = 0; // 도달 난민
        for($i = 0;($i < $init->pointNumber && $boat > 0); $i++){
          $bx = $this->rpx[$i];
          $by = $this->rpy[$i];
          if($land[$bx][$by] == $init->landTown){
            // 마을의 경우
            $lv = $landValue[$bx][$by];
            if($boat > 50){
              $lv += 50;
              $boat -= 50;
              $achive += 50;
            } else {
              $lv += $boat;
              $achive += $boat;
              $boat = 0;
            }
            if($lv > 200){
              $boat +=($lv - 200);
              $achive -=($lv - 200);
              $lv = 200;
            }
            $landValue[$bx][$by] = $lv;
          } elseif($land[$bx][$by] == $init->landPlains){
            // 평지의 경우
            $land[$bx][$by] = $init->landTown;;
            if($boat > 10){
              $landValue[$bx][$by] = 5;
              $boat -= 10;
              $achive += 10;
            } elseif($boat > 5){
              $landValue[$bx][$by] = $boat - 5;
              $achive += $boat;
              $boat = 0;
            }
          }
          if($boat <= 0){
            break;
          }
        }
        if($achive > 0){
          // 조금이라도 도착했을 경우,로그를 출력한다
          $this->log->msBoatPeople($id,$name,$achive);

          // 난민의 수가 일정 수 이상이라면,평화상 수상 가능성 있음
          if($achive >= 200){
            $prize = $island['prize'];
            list($flags,$monsters,$turns)= explode(",", $prize, 3);

            if((!($flags & 8))&&  $achive >= 200){
              $flags |= 8;
              $this->log->prize($id,$name,$init->prizeName[4]);
            } elseif((!($flags & 16))&&  $achive > 500){
              $flags |= 16;
              $this->log->prize($id,$name,$init->prizeName[5]);
            } elseif((!($flags & 32))&&  $achive > 800){
              $flags |= 32;
              $this->log->prize($id,$name,$init->prizeName[6]);
            }
            $island['prize'] = "{$flags},{$monsters},{$turns}";
          }
        }
      }
      
      $returnMode = 1;
      break;

    case $init->comSendMonster:
      // 괴수 파견
      // 대상 취득
      $tn = $hako->idToNumber[$target];
      $tIsland = $hako->islands[$tn];
      $tName = $tIsland['name'];
      
      if($tn != 0 && empty($tn)){
        // 대상이 이미 없다
        $this->log->msNo대상($id,$name,$comName);

        $returnMode = 0;
        break;
      }

      // 메시지
      $this->log->monsSend($id,$target,$name,$tName);
      $tIsland['monstersend']++;
      $hako->islands[$tn] = $tIsland;

      $island['money'] -= $cost;
      $returnMode = 1;
      break;
    case $init->comSell:
      // 수출량 결정
      if($arg == 0){ $arg = 1; }
      $value = min($arg *(-$cost),$island['food']);

      // 수출 로그
      $this->log->sell($id,$name,$comName,$value);
      $island['food'] -=  $value;
      $island['money'] +=($value / 10);

      $returnMode = 0;
      break;
      
    case $init->comFood:
    case $init->comMoney:
      // 원조계
      // 대상 취득
      $tn = $hako->idToNumber[$target];
      $tIsland = &$hako->islands[$tn];
      $tName = $tIsland['name'];

      // 원조량 결정
      if($arg == 0){ $arg = 1; }

      if($cost < 0){
        $value = min($arg *(-$cost),$island['food']);
        $str = "{$value}{$init->unitFood}";
      } else {
        $value = min($arg *($cost),$island['money']);
        $str = "{$value}{$init->unitMoney}";
      }

      // 원조 로그
      $this->log->aid($id,$target,$name,$tName,$comName,$str);

      if($cost < 0){
        $island['food'] -= $value;
        $tIsland['food'] += $value;
      } else {
        $island['money'] -= $value;
        $tIsland['money'] += $value;
      }
      $hako->islands[$tn] = $tIsland;

      $returnMode = 0;
      break;
      
    case $init->comPropaganda:
      // 인구 유치 활동
      $this->log->propaganda($id,$name,$comName);
      $island['propaganda'] = 1;
      $island['money'] -= $cost;

      $returnMode = 1;
      break;

    case $init->comGiveup:
      // 포기
      $this->log->giveup($id,$name);
      $island['dead'] = 1;
      unlink("{$init->dirName}/island.{$id}");

      $returnMode = 1;
      break;
    }

    // 변경된 가능성이 있는 변수를 써 되돌린다
//    $hako->islands[$hako->idToNumber[$id]] = $island;

    // 사후 처리
    unset($island['prize']);
    unset($island['land']);
    unset($island['landValue']);
    unset($island['command']);
    $island['prize'] = $prize;
    $island['land'] = $land;
    $island['landValue'] = $landValue;
    $island['command'] = $comArray;

    return $returnMode;
  }
  //---------------------------------------------------
  // 성장 및 단헥스 재해
  //---------------------------------------------------
  function doEachHex($hako,&$island){
    global $init;
    // 도출치
    $name = $island['name'];
    $id = $island['id'];
    $land = $island['land'];
    $landValue = $island['landValue'];

    // 증가하는 인구의 씨치
    $addpop  = 10;  // 마을,마을
    $addpop2 = 0; // 도시
    if($island['food'] < 0){
      // 식량 부족
      $addpop = -30;
    } elseif($island['propaganda'] == 1){
      // 인구 유치 활동중
      $addpop = 30;
      $addpop2 = 3;
    }
    $monsterMove = array();
    // 루프
    for($i = 0; $i < $init->pointNumber; $i++){
      $x = $this->rpx[$i];
      $y = $this->rpy[$i];
      $landKind = $land[$x][$y];
      $lv = $landValue[$x][$y];

      switch($landKind){
      case $init->landTown:
        // 마을계
        if($addpop < 0){
          // 부족
          $lv -=(Util::random(-$addpop)+ 1);
          if($lv <= 0){
            // 평지에 되돌린다
            $land[$x][$y] = $init->landPlains;
            $landValue[$x][$y] = 0;
            break;
          }
        } else {
          // 성장
          if($lv < 100){
            $lv += Util::random($addpop)+ 1;
            if($lv > 100){
              $lv = 100;
            }
          } else {
            // 도시가 되면 성장 늦다
            if($addpop2 > 0){
              $lv += Util::random($addpop2)+ 1;
            }
          }
        }
        if($lv > 200){
          $lv = 200;
        }
        $landValue[$x][$y] = $lv;
        break;
        
      case $init->landPlains:
        // 평지
        if(Util::random(5)== 0){
          // 주위에 농장,마을이 있으면,이곳도 마을이 된다
          if($this->countGrow($land,$landValue,$x,$y)){
            $land[$x][$y] = $init->landTown;
            $landValue[$x][$y] = 1;
          }
        }
        break;
        
      case $init->landForest:
        // 삼
        if($lv < 200){
          // 나무를 늘린다
          $landValue[$x][$y]++;
        }
        break;
        
      case $init->landDefence:
        if($lv == 1){
          // 방어 시설 자폭
          $lName = $this->landName($landKind,$lv);
          $this->log->bombFire($id,$name,$lName,"($x,$y)");

          // 광역 피해 루틴
          $this->wideDamage($id,$name,$land,$landValue,$x,$y);
        }
        break;
        
      case $init->landOil:
        // 해저 유전
        $lName = $this->landName($landKind,$lv);
        $value = $init->oilMoney;
        $island['money'] += $value;
        $str = "{$value}{$init->unitMoney}";

        // 수입 로그
        $this->log->oilMoney($id,$name,$lName,"($x,$y)",$str);

        // 고갈 판정
        if(Util::random(1000)< $init->oilRatio){
          // 고갈
          $this->log->oilEnd($id,$name,$lName,"($x,$y)");
          $land[$x][$y] = $init->landSea;
          $landValue[$x][$y] = 0;
        }
        break;
        
      case $init->landMonster:

        // 괴수
        if($monsterMove[$x][$y] == 2){
          // 이미 움직인 후
          break;
        }

        // 각 요소의 꺼내
        $monsSpec = Util::monsterSpec($landValue[$x][$y]);
        $special  = $init->monsterSpecial[$monsSpec['kind']];
        $mName    = $monsSpec['name'];
        // 경화 상태
        if((($special == 3)&&(($hako->islandTurn % 2)== 1))||
          (($special == 4)&&(($hako->islandTurn % 2)== 0))){
          // 경화 상태
          break;
        }

        // 움직일 방향을 결정
        for($j = 0; $j < 3; $j++){
          $d = Util::random(6)+ 1;
          $sx = $x + $init->ax[$d];
          $sy = $y + $init->ay[$d];

          // 행에 의한 위치 조정
          if((($sy % 2)== 0)&&(($y % 2)== 1)){
            $sx--;
          }

          // 범위 밖 판정
          if(($sx < 0)||($sx >= $init->islandSize)||
            ($sy < 0)||($sy >= $init->islandSize)){
            continue;
          }
          // 바다,해 기,유전,괴수,산,기념비 이외
          if(($land[$sx][$sy] != $init->landSea)&&
            ($land[$sx][$sy] != $init->landSbase)&&
            ($land[$sx][$sy] != $init->landOil)&&
            ($land[$sx][$sy] != $init->landMountain)&&
            ($land[$sx][$sy] != $init->landMonument)&&
            ($land[$sx][$sy] != $init->landMonster)){
            break;
          }
        }

        if($j == 3){
          // 움직이지 않았다
          break;
        }

        // 이동한 위치의 지형에 의해 메시지
        $l = $land[$sx][$sy];
        $lv = $landValue[$sx][$sy];
        $lName = $this->landName($l,$lv);
        $point = "({$sx},{$sy})";

        // 이동
        $land[$sx][$sy] = $land[$x][$y];
        $landValue[$sx][$sy] = $landValue[$x][$y];

        // 아래 있던 위치를 황무지에
        $land[$x][$y] = $init->landWaste;
        $landValue[$x][$y] = 0;
      
        // 이동이 끝난 플래그
        if($init->monsterSpecial[$monsSpec['kind']] == 2){
          // 이동이 끝난 플래그는 세우지 않다
        } elseif($init->monsterSpecial[$monsSpec['kind']] == 1){
          // 빠른 괴수
          $monsterMove[$sx][$sy] = $monsterMove[$x][$y] + 1;
        } else {
          // 보통 괴수
          $monsterMove[$sx][$sy] = 2;
        }
        if(($l == $init->landDefence)&&($init->dBaseAuto == 1)){
          // 방어 시설을 밟았다
          $this->log->monsMoveDefence($id,$name,$lName,$point,$mName);

          // 광역 피해 루틴
          $this->wideDamage($id,$name,$land,$landValue,$sx,$sy);
        } else {
          // 행선지가 황무지가 된다
          $this->log->monsMove($id,$name,$lName,$point,$mName);
        }
        break;
      }
      // 이미 $init->landTown가 case문으로 사용되고 있으므로 switch를 별도로 준비
      switch($landKind){
      case $init->landTown:
      case $init->landHaribote:
      case $init->landFactory:
        // 화재 판정
        if($landKind == $init->landTown &&($lv <= 30))
          break;
        
        if(Util::random(1000)< $init->disFire){
          // 주위의 숲과 기념비를 센다
          if((Turn::countAround($land,$x,$y,$init->landForest,7)+
              Turn::countAround($land,$x,$y,$init->landMonument,7))== 0){
            // 없었던 경우,화재로 괴멸
            $l = $land[$x][$y];
            $lv = $landValue[$x][$y];
            $point = "({$x},{$y})";
            $lName = $this->landName($l,$lv);
            $this->log->fire($id,$name,$lName,$point);
            $land[$x][$y] = $init->landWaste;
            $landValue[$x][$y] = 0;
          }
        }
        break;
      }
    }
    // 변경된 가능성이 있는 변수를 써 되돌린다
    $island['land'] = $land;
    $island['landValue'] = $landValue;
  }

  //---------------------------------------------------
  // 섬전체
  //---------------------------------------------------
  function doIslandProcess($hako,&$island){
    global $init;
    
    // 도출치
    $name = $island['name'];
    $id = $island['id'];
    $land = $island['land'];
    $landValue = $island['landValue'];

    // 지진 판정
    if(Util::random(1000)<(($island['prepare2'] + 1)* $init->disEarthquake)){
      // 지진 발생
      $this->log->earthquake($id,$name);

      for($i = 0; $i < $init->pointNumber; $i++){
        $x = $this->rpx[$i];
        $y = $this->rpy[$i];
        $landKind = $land[$x][$y];
        $lv = $landValue[$x][$y];

        if((($landKind == $init->landTown)&&($lv >= 100))||
          ($landKind == $init->landHaribote)||
          ($landKind == $init->landFactory)){
          // 1/4그리고 괴멸
          if(Util::random(4)== 0){
            $this->log->eQDamage($id,$name,$this->landName($landKind,$lv),"({$x},{$y})");
            $land[$x][$y] = $init->landWaste;
            $landValue[$x][$y] = 0;
          }
        }
      }
    }

    // 식량 부족
    if($island['food'] <= 0){
      // 부족 메시지
      $this->log->starve($id,$name);
      $island['food'] = 0;

      for($i = 0; $i < $init->pointNumber; $i++){
        $x = $this->rpx[$i];
        $y = $this->rpy[$i];
        $landKind = $land[$x][$y];
        $lv = $landValue[$x][$y];

        if(($landKind == $init->landFarm)||
          ($landKind == $init->landFactory)||
          ($landKind == $init->landBase)||
          ($landKind == $init->landDefence)){
          // 1/4그리고 괴멸
          if(Util::random(4)== 0){
            $this->log->svDamage($id,$name,$this->landName($landKind,$lv),"({$x},{$y})");
            $land[$x][$y] = $init->landWaste;
            $landValue[$x][$y] = 0;
          }
        }
      }
    }

    // 해일 판정
    if(Util::random(1000)< $init->disTsunami){
      // 해일 발생
      $this->log->tsunami($id,$name);

      for($i = 0; $i < $init->pointNumber; $i++){
        $x = $this->rpx[$i];
        $y = $this->rpy[$i];
        $landKind = $land[$x][$y];
        $lv = $landValue[$x][$y];

        if(($landKind == $init->landTown)||
          ($landKind == $init->landFarm)||
          ($landKind == $init->landFactory)||
          ($landKind == $init->landBase)||
          ($landKind == $init->landDefence)||
          ($landKind == $init->landHaribote)){
          // 1d12 <=(주위의 바다 - 1)로 붕괴
          if(Util::random(12)<
            (Turn::countAround($land,$x,$y,$init->landOil,7)+
              Turn::countAround($land,$x,$y,$init->landSbase,7)+
              Turn::countAround($land,$x,$y,$init->landSea,7)- 1)){
            $this->log->tsunamiDamage($id,$name,$this->landName($landKind,$lv),"({$x},{$y})");
            $land[$x][$y] = $init->landWaste;
            $landValue[$x][$y] = 0;
          }
        }

      }
    }

    // 괴수 판정
    $r = Util::random(10000);
    $pop = $island['pop'];
    do{
      if((($r <($init->disMonster * $island['area']))&&
         ($pop >= $init->disMonsBorder1))||
        ($island['monstersend'] > 0)){
        // 괴수 출현
        // 종류를 결정한다
        if($island['monstersend'] > 0){
          // 인조
          $kind = 0;
          $island['monstersend']--;
        } elseif($pop >= $init->disMonsBorder3){
          // level3까지
          $kind = Util::random($init->monsterLevel3)+ 1;
        } elseif($pop >= $init->disMonsBorder2){
          // level2까지
          $kind = Util::random($init->monsterLevel2)+ 1;
        } else {
          // level1만
          $kind = Util::random($init->monsterLevel1)+ 1;
        }

        // lv의 값을 결정한다
        $lv = $kind * 10
          + $init->monsterBHP[$kind] + Util::random($init->monsterDHP[$kind]);

        // 어디에 나타날까 결정한다
        for($i = 0; $i < $init->pointNumber; $i++){
          $bx = $this->rpx[$i];
          $by = $this->rpy[$i];
          if($land[$bx][$by] == $init->landTown){

            // 지형명
            $lName = $this->landName($init->landTown,$landValue[$bx][$by]);

            // 그 헥스를 괴수에게
            $land[$bx][$by] = $init->landMonster;
            $landValue[$bx][$by] = $lv;

            // 괴수 정보
            $monsSpec = Util::monsterSpec($lv);
            $mName    = $monsSpec['name'];

            // 메시지
            $this->log->monsCome($id,$name,$mName,"({$bx},{$by})",$lName);
            break;
          }
        }
      }
    } while($island['monstersend'] > 0);

    // 지반침하 판정
    if(($island['area'] > $init->disFallBorder)&&
      (Util::random(1000)< $init->disFalldown)){
      // 지반침하 발생
      $this->log->falldown($id,$name);

      for($i = 0; $i < $init->pointNumber; $i++){
        $x = $this->rpx[$i];
        $y = $this->rpy[$i];
        $landKind = $land[$x][$y];
        $lv = $landValue[$x][$y];

        if(($landKind != $init->landSea)&&
          ($landKind != $init->landSbase)&&
          ($landKind != $init->landOil)&&
          ($landKind != $init->landMountain)){

          // 주위에 바다가 있으면,값을―1에
          if(Turn::countAround($land,$x,$y,$init->landSea,7)+
             Turn::countAround($land,$x,$y,$init->landSbase,7)){
            $this->log->falldownLand($id,$name,$this->landName($landKind,$lv),"({$x},{$y})");
            $land[$x][$y] = -1;
            $landValue[$x][$y] = 0;
          }
        }
      }

      for($i = 0; $i < $init->pointNumber; $i++){
        $x = $this->rpx[$i];
        $y = $this->rpy[$i];
        $landKind = $land[$x][$y];

        if($landKind == -1){
          // -1(이)가 되어 있는 곳을 얕은 여울에
          $land[$x][$y] = $init->landSea;
          $landValue[$x][$y] = 1;
        } elseif($landKind == $init->landSea){
          // 얕은 여울은 바다에
          $landValue[$x][$y] = 0;
        }

      }
    }

    // 태풍 판정
    if(Util::random(1000)< $init->disTyphoon){
      // 태풍 발생
      $this->log->typhoon($id,$name);

      for($i = 0; $i < $init->pointNumber; $i++){
        $x = $this->rpx[$i];
        $y = $this->rpy[$i];
        $landKind = $land[$x][$y];
        $lv = $landValue[$x][$y];

        if(($landKind == $init->landFarm)||
          ($landKind == $init->landHaribote)){

          // 1d12 <=(6 - 주위의 숲)로 붕괴
          if(Util::random(12)<
            (6
              - Turn::countAround($land,$x,$y,$init->landForest,7)
              - Turn::countAround($land,$x,$y,$init->landMonument,7))){
            $this->log->typhoonDamage($id,$name,$this->landName($landKind,$lv),"({$x},{$y})");
            $land[$x][$y] = $init->landPlains;
            $landValue[$x][$y] = 0;
          }
        }
      }
    }

    // 거대 운석 판정
    if(Util::random(1000)< $init->disHugeMeteo){

      // 낙하
      $x = Util::random($init->islandSize);
      $y = Util::random($init->islandSize);
      $landKind = $land[$x][$y];
      $lv = $landValue[$x][$y];
      $point = "({$x},{$y})";

      // 메시지
      $this->log->hugeMeteo($id,$name,$point);

      // 광역 피해 루틴
      $this->wideDamage($id,$name,$land,$landValue,$x,$y);
    }

    // 거대 미사일 판정
    while($island['bigmissile'] > 0){
      $island['bigmissile']--;

      // 낙하
      $x = Util::random($init->islandSize);
      $y = Util::random($init->islandSize);
      $landKind = $land[$x][$y];
      $lv = $landValue[$x][$y];
      $point = "({$x},{$y})";

      // 메시지
      $this->log->monDamage($id,$name,$point);

      // 광역 피해 루틴
      $this->wideDamage($id,$name,$land,$landValue,$x,$y);
    }

    // 운석 판정
    if(Util::random(1000)< $init->disMeteo){
      $first = 1;
      while((Util::random(2)== 0)||($first == 1)){
        $first = 0;

        // 낙하
        $x = Util::random($init->islandSize);
        $y = Util::random($init->islandSize);
        $landKind = $land[$x][$y];
        $lv = $landValue[$x][$y];
        $point = "({$x},{$y})";

        if(($landKind == $init->landSea)&&($lv == 0)){
          // 바다 포체
          $this->log->meteoSea($id,$name,$this->landName($landKind,$lv),$point);
        } elseif($landKind == $init->landMountain){
          // 산파괴
          $this->log->meteoMountain($id,$name,$this->landName($landKind,$lv),$point);
          $land[$x][$y] = $init->landWaste;
          $landValue[$x][$y] = 0;
          continue;
        } elseif($landKind == $init->landSbase){
          $this->log->meteoSbase($id,$name,$this->landName($landKind,$lv),$point);
        } elseif($landKind == $init->landMonster){
          $this->log->meteoMonster($id,$name,$this->landName($landKind,$lv),$point);
        } elseif($landKind == $init->landSea){
          // 얕은 여울
          $this->log->meteoSea1($id,$name,$this->landName($landKind,$lv),$point);
        } else {
          $this->log->meteoNormal($id,$name,$this->landName($landKind,$lv),$point);
        }
        $land[$x][$y] = $init->landSea;
        $landValue[$x][$y] = 0;
      }
    }

    // 분화 판정
    if(Util::random(1000)< $init->disEruption){
      $x = Util::random($init->islandSize);
      $y = Util::random($init->islandSize);
      $landKind = $land[$x][$y];
      $lv = $landValue[$x][$y];
      $point = "({$x},{$y})";
      $this->log->eruption($id,$name,$this->landName($landKind,$lv),$point);
      $land[$x][$y] = $init->landMountain;
      $landValue[$x][$y] = 0;

      for($i = 1; $i < 7; $i++){
        $sx = $x + $init->ax[$i];
        $sy = $y + $init->ay[$i];

        // 행에 의한 위치 조정
        if((($sy % 2)== 0)&&(($y % 2)== 1)){
          $sx--;
        }

        $landKind = $land[$sx][$sy];
        $lv = $landValue[$sx][$sy];
        $point = "({$sx},{$sy})";

        if(($sx < 0)||($sx >= $init->islandSize)||
          ($sy < 0)||($sy >= $init->islandSize)){
        } else {
          // 범위내의 경우
          $landKind = $land[$sx][$sy];
          $lv = $landValue[$sx][$sy];
          $point = "({$sx},{$sy})";
          if(($landKind == $init->landSea)||
            ($landKind == $init->landOil)||
            ($landKind == $init->landSbase)){
            // 바다의 경우
            if($lv == 1){
              // 얕은 여울
              $this->log->eruptionSea1($id,$name,$this->landName($landKind,$lv),$point);
            } else {
              $this->log->eruptionSea($id,$name,$this->landName($landKind,$lv),$point);
              $land[$sx][$sy] = $init->landSea;
              $landValue[$sx][$sy] = 1;
              continue;
            }
          } elseif(($landKind == $init->landMountain)||
                 ($landKind == $init->landMonster)||
                 ($landKind == $init->landWaste)){
            continue;
          } else {
            // 그 이외의 경우
            $this->log->eruptionNormal($id,$name,$this->landName($landKind,$lv),$point);
          }
          $land[$sx][$sy] = $init->landWaste;
          $landValue[$sx][$sy] = 0;
        }
      }
    }
    // 변경된 가능성이 있는 변수를 써 되돌린다
    $island['land'] = $land;
    $island['landValue'] = $landValue;

    // 식량이 넘치고 있으면 현금화
    if($island['food'] > $init->maxFood){
      $island['money'] += round(($island['food'] - $init->maxFood)/ 10);
      $island['food'] = $init->maxFood;
    }

    // 돈이 넘치고 있으면 잘라서 버림
    if($island['money'] > $init->maxMoney){
      $island['money'] = $init->maxMoney;
    }

    // 각종의 값을 계산
    Turn::estimate($island);

    // 번영,재난상
    $pop = $island['pop'];
    $damage = $island['oldPop'] - $pop;
    $prize = $island['prize'];
    list($flags,$monsters,$turns)= explode(",", $prize, 3);


    // 번영상
    if((!($flags & 1))&&  $pop >= 3000){
      $flags |= 1;
      $this->log->prize($id,$name,$init->prizeName[1]);
    } elseif((!($flags & 2))&&  $pop >= 5000){
      $flags |= 2;
      $this->log->prize($id,$name,$init->prizeName[2]);
    } elseif((!($flags & 4))&&  $pop >= 10000){
      $flags |= 4;
      $this->log->prize($id,$name,$init->prizeName[3]);
    }

    // 재난상
    if((!($flags & 64))&&  $damage >= 500){
      $flags |= 64;
      $this->log->prize($id,$name,$init->prizeName[7]);
    } elseif((!($flags & 128))&&  $damage >= 1000){
      $flags |= 128;
      $this->log->prize($id,$name,$init->prizeName[8]);
    } elseif((!($flags & 256))&&  $damage >= 2000){
      $flags |= 256;
      $this->log->prize($id,$name,$init->prizeName[9]);
    }

    $island['prize'] = "{$flags},{$monsters},{$turns}";

  }

  //---------------------------------------------------
  // 주위의 마을,농장이 있을까 판정
  //---------------------------------------------------
  function countGrow($land,$landValue,$x,$y){
    global $init;

    for($i = 1; $i < 7; $i++){
      $sx = $x + $init->ax[$i];
      $sy = $y + $init->ay[$i];

      // 행에 의한 위치 조정
      if((($sy % 2)== 0)&&(($y % 2)== 1)){
        $sx--;
      }

      if(($sx < 0)||($sx >= $init->islandSize)||
        ($sy < 0)||($sy >= $init->islandSize)){
      } else {
        // 범위내의 경우
        if(($land[$sx][$sy] == $init->landTown)||
          ($land[$sx][$sy] == $init->landFarm)){
          if($landValue[$sx][$sy] != 1){
            return true;
          }
        }
      }
    }
    return false;
  }
  //---------------------------------------------------
  // 광역 피해 루틴
  //---------------------------------------------------
  function wideDamage($id,$name,$land,$landValue,$x,$y){
    global $init;

    for($i = 0; $i < 19; $i++){
      $sx = $x + $init->ax[$i];
      $sy = $y + $init->ay[$i];

      // 행에 의한 위치 조정
      if((($sy % 2)== 0)&&(($y % 2)== 1)){
        $sx--;
      }

      $landKind = $land[$sx][$sy];
      $lv = $landValue[$sx][$sy];
      $landName = $this->landName($landKind,$lv);
      $point = "({$sx},{$sy})";

      // 범위 밖 판정
      if(($sx < 0)||($sx >= $init->islandSize)||
        ($sy < 0)||($sy >= $init->islandSize)){
        continue;
      }

      // 범위에 의한 분기
      if($i < 7){
        // 중심,및 1 헥스
        if($landKind == $init->landSea){
          $landValue[$sx][$sy] = 0;
          continue;
        } elseif(($landKind == $init->landSbase)||
                ($landKind == $init->landOil)){
          $this->log->wideDamageSea2($id,$name,$landName,$point);
          $land[$sx][$sy] = $init->landSea;
          $landValue[$sx][$sy] = 0;
        } else {
          if($landKind == $init->landMonster){
            $this->log->wideDamageMonsterSea($id,$name,$landName,$point);
          } else {
            $this->log->wideDamageSea($id,$name,$landName,$point);
          }
          $land[$sx][$sy] = $init->landSea;
          if($i == 0){
            // 해
            $landValue[$sx][$sy] = 0;
          } else {
            // 얕은 여울
            $landValue[$sx][$sy] = 1;
          }
        }
      } else {
        // 2 헥스
        if(($landKind == $init->landSea)||
          ($landKind == $init->landOil)||
          ($landKind == $init->landWaste)||
          ($landKind == $init->landMountain)||
          ($landKind == $init->landSbase)){
          continue;
        } elseif($landKind == $init->landMonster){
          $this->log->wideDamageMonster($id,$name,$landName,$point);
          $land[$sx][$sy] = $init->landWaste;
          $landValue[$sx][$sy] = 0;
        } else {
          $this->log->wideDamageWaste($id,$name,$landName,$point);
          $land[$sx][$sy] = $init->landWaste;
          $landValue[$sx][$sy] = 0;
        }
      }
    }
  }

  //---------------------------------------------------
  // 인구순서로 소트
  //---------------------------------------------------
  function islandSort(&$hako){
    global $init;
    usort($hako->islands,'popComp');
  }
  //---------------------------------------------------
  // 수입,소비 페이즈
  //---------------------------------------------------
  function income(&$island){
    global $init;
    
    $pop = $island['pop'];
    $farm = $island['farm'] * 10;
    $factory = $island['factory'];
    $mountain =$island['mountain'];

    // 수입
    if($pop > $farm){
      // 농업만은 손이 남는 경우
      $island['food'] += $farm; // 농장 풀 가동
      $island['money'] +=
        min(round(($pop - $farm)/ 10),
              $factory + $mountain);
    } else {
      // 농업만으로 손 한 잔의 경우
      $island['food'] += $pop; // 전원 들일
    }

    // 식량 소비
    $island['food'] = round($island['food'] - $pop * $init->eatenFood);
  }
  //---------------------------------------------------
  // 인구 그 밖의 값을 산출
  //---------------------------------------------------
  static function estimate(&$island){
    // estimate(&$island)와 같이 사용
    
    global $init;
    $land = $island['land'];
    $landValue = $island['landValue'];

    $area       = 0;
    $pop        = 0;
    $farm       = 0;
    $factory    = 0;
    $mountain   = 0;
    $monster    = 0;
    // 센다
    for($y = 0; $y < $init->islandSize; $y++){
      for($x = 0; $x < $init->islandSize; $x++){
        $kind = $land[$x][$y];
        $value = $landValue[$x][$y];
        if(($kind != $init->landSea)&&
          ($kind != $init->landSbase)&&
          ($kind != $init->landOil)){
          $area++;
          switch($kind){
          case $init->landTown:
            // 정
            $pop += $value;
            break;
          case $init->landFarm:
            // 농장
            $farm += $value;
            break;
          case $init->landFactory:
            // 공장
            $factory += $value;
            break;
          case $init->landMountain:
            // 산
            $mountain += $value;
            break;
          case $init->landMonster:
            // 괴수
            $monster++;
            break;
          }
        }
      }
    }
    // 대입
    $island['pop']      = $pop;
    $island['area']     = $area;
    $island['farm']     = $farm;
    $island['factory']  = $factory;
    $island['mountain'] = $mountain;
    $island['monster'] = $monster;
  }
  //---------------------------------------------------
  // 범위내의 지형을 센다
  //---------------------------------------------------
  static function countAround($land,$x,$y,$kind,$range){
    global $init;
    // 범위내의 지형을 센다
    $count = 0;
    for($i = 0; $i < $range; $i++){
      $sx = $x + $init->ax[$i];
      $sy = $y + $init->ay[$i];

      // 행에 의한 위치 조정
      if((($sy % 2)== 0)&&(($y % 2)== 1)){
        $sx--;
      }

      if(($sx < 0)||($sx >= $init->islandSize)||
        ($sy < 0)||($sy >= $init->islandSize)){
        // 범위 밖의 경우
        if($kind == $init->landSea){
          // 바다라면 가산
          $count++;
        }
      } else {
        // 범위내의 경우
        if($land[$sx][$sy] == $kind){
          $count++;
        }
      }
    }
    return $count;
  }
  //---------------------------------------------------
  // 지형의 부르는 법
  //---------------------------------------------------
  function landName($land,$lv){
    global $init;
    switch($land){
    case $init->landSea:
      if($lv == 1){
        return '얕은 여울';
      } else {
        return '바다';
      }
      break;
    case $init->landWaste:
      return '황무지';
    case $init->landPlains:
      return '평지';
    case $init->landTown:
      if($lv < 30){
        return '마을';
      } elseif($lv < 100){
        return '마을';
      } else {
        return '도시';
      }
    case $init->landForest:
      return '숲';
    case $init->landFarm:
      return '농장';
    case $init->landFactory:
      return '공장';
    case $init->landBase:
      return '미사일 기지';
    case $init->landDefence:
      return '방어 시설';
    case $init->landMountain:
      return '산';
    case $init->landMonster:
      $monsSpec = Util::monsterSpec($lv);
      return $monsSpec['name'];
    case $init->landSbase:
      return '해저 기지';
    case $init->landOil:
      return '해저 유전';
    case $init->landMonument:
      return $init->monumentName[$lv];
    case $init->landHaribote:
      return '위장 방어 시설';

    }
  }
}
// 인구를 비교
function popComp($x,$y){
  if($x['pop'] == $y['pop'])return 0;
  return($x['pop'] > $y['pop'])? -1 : 1;
}


?>
