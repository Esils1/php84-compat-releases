<?php
/*******************************************************************

  모형정원 제도 2 for PHP

  
  $Id: hako-mente-safemode.php, v 1.5 2004/09/23 05:29:26 Watson Exp $

*******************************************************************/

require 'config.php';
require 'hako-html.php';
define("READ_LINE", 1024);
$init = new Init;
$THIS_FILE = $init->baseDir . "/hako-mente-safemode.php";

class HtmlMente extends HTML {

  function enter() {
    global $init;
    print <<<END
<h1>모형정원 제도 2 maintenance tool</h1>
<form accept-charset="UTF-8" action="{$GLOBALS['THIS_FILE']}" method="post">
<strong>비밀번호：</strong>
<input type="password" size="32" maxlength="32" name="PASSWORD">
<input type="hidden" name="mode" value="enter">
<input type="submit" value="메인트넌스">
</form>

END;
  
  }
  function main($data) {
    global $init;
    print "<h1>모형정원 제도 2 maintenance tool</h1>\n";

	// 데이터 저장용 디렉토리의 존재 체크
	if(!is_dir("{$init->dirName}")) {
		print "{$init->tagBig_}데이터 저장용의 디렉토리가 존재하지 않습니다{$init->_tagBig}";
		HTML::footer();
		exit;
	}
	// 데이터 저장용 디렉토리의 퍼미션 체크
	if(!is_writeable("{$init->dirName}") || !is_readable("{$init->dirName}")) {
		print "{$init->tagBig_}데이터 저장용의 디렉토리의 권한 설정이 올바르지 않습니다. 권한을 0777 등의 값으로 설정해 주세요.{$init->_tagBig}";
		HTML::footer();
		exit;
	}


    if(is_file("{$init->dirName}/hakojima.dat")) {
      $this->dataPrint($data);
    } else {
      print "<hr>\n";
      print "<form accept-charset=\"UTF-8\" action=\"{$GLOBALS['THIS_FILE']}\" method=\"post\">\n";
      print "<input type=\"hidden\" name=\"PASSWORD\" value=\"{$data['PASSWORD']}\">\n";
      print "<input type=\"hidden\" name=\"mode\" value=\"NEW\">\n";
      print "<input type=\"submit\" value=\"새로운 데이터를 만든다\">\n";
      print "</form>\n";
    }

    // 백업 데이터
    $dir = opendir("./");
    while($dn = readdir($dir)) {
      if(preg_match("/{$init->dirName}\.bak/", $dn)) {
        $this->dataPrint($data, 1);
        break;
      }
    }
    closedir($dir);


  }
  // 표시 모드
  function dataPrint($data, $suf = "") {
    global $init;

    print "<HR>";
    if(strcmp($suf, "") == 0) {
      $fp = fopen("{$init->dirName}/hakojima.dat", "r");
      print "<h1>현역 데이터</h1>\n";
    } else {
      $fp = fopen("{$init->dirName}.bak/hakojima.dat", "r");
      print "<h1>백업</h1>\n";
    }

    $lastTurn = chop(fgets($fp, READ_LINE));
    $lastTime = chop(fgets($fp, READ_LINE));
    fclose($fp);
    $timeString = timeToString($lastTime);

    print <<<END
<strong>턴 $lastTurn</strong><br>
<strong>최종 업데이트 시간</strong>:$timeString<br>
<strong>최종 업데이트 시간(초수의 표\시)</strong>:1970연 1월 1일부터 $lastTime 초<br>

END;

    if(strcmp($suf, "") == 0) {
      $time = localtime($lastTime, TRUE);
      $time['tm_year'] += 1900;
      $time['tm_mon']++;

      print <<<END
<h2>최종 업데이트 시간의 변경</h2>
<form accept-charset="UTF-8" action="{$GLOBALS['THIS_FILE']}" method="post">
<input type="hidden" name="PASSWORD" value="{$data['PASSWORD']}">
<input type="hidden" name="mode" value="NTIME">
<input type="hidden" name="NUMBER" value="{$suf}">
<input type="text" size="4" name="YEAR" value="{$time['tm_year']}">년
<input type="text" size="2" name="MON" value="{$time['tm_mon']}">월
<input type="text" size="2" name="DATE" value="{$time['tm_mday']}">일
<input type="text" size="2" name="HOUR" value="{$time['tm_hour']}">시
<input type="text" size="2" name="MIN" value="{$time['tm_min']}">분
<input type="text" size="2" name="NSEC" value="{$time['tm_sec']}">초
<input type="submit" value="변경">
</form>
<form accept-charset="UTF-8" action="{$GLOBALS['THIS_FILE']}" method="post">
<input type="hidden" name="PASSWORD" value="{$data['PASSWORD']}">
<input type="hidden" name="mode" value="STIME">
<input type="hidden" name="NUMBER" value="{$suf}">
1970년 1월 1일부터<input type="text" size="32" name="SSEC" value="$lastTime">초
<input type="submit" value="초지정으로 변경">
</form>

END;
    } else {
      print <<<END
<form accept-charset="UTF-8" action="{$GLOBALS['THIS_FILE']}" method="post">
<input type="hidden" name="PASSWORD" value="{$data['PASSWORD']}">
<input type="hidden" name="mode" value="CURRENT">
<input type="submit" value="이 데이터를 현역에게">
</form>

END;

    }
  }
}

function timeToString($t) {
  $time = localtime($t, TRUE);
  $time['tm_year'] += 1900;
  $time['tm_mon']++;

  return "{$time['tm_year']}해 {$time['tm_mon']}달 {$time['tm_mday']}날 {$time['tm_hour']}때 {$time['tm_min']}분 {$time['tm_sec']}초";
}

class Main {
  var $mode;
  var $dataSet = array();
  function execute() {
    $html = new HtmlMente;

    $this->parseInputData();

    $html->header();
    switch($this->mode) {
    case "NEW":
      if($this->passCheck())
        $this->newMode();

      $html->main($this->dataSet);
      break;

    case "CURRENT":
      if($this->passCheck())
        $this->currentMode();
      
      $html->main($this->dataSet);
      break;

    case "DELETE":
      if($this->passCheck())
        $this->delMode();

      $html->main($this->dataSet);
      break;
    case "NTIME":
      if($this->passCheck())
        $this->timeMode();

      $html->main($this->dataSet);
      break;

    case "STIME":
      if($this->passCheck())
        $this->stimeMode($this->dataSet['SSEC']);

      $html->main($this->dataSet);
      break;

    case "enter":
     if($this->passCheck())
       $html->main($this->dataSet);
      break;
    default:
      $html->enter();
      break;
    }
    $html->footer();
  }
  //----------------------------------------
  function parseInputData() {
    $this->mode = $_POST['mode'];    
    if(!empty($_POST)) {
      while(list($name, $value) = each($_POST)) {
//        $value = Util::sjis_convert($value);
        // 반각 가나가 있으면 전각으로 변환해 돌려준다
//        $value = i18n_ja_jp_hantozen($value,"KHV");
        $value = str_replace(",", "", $value);

        $this->dataSet["{$name}"] = $value;
      }
    }
  }
  function newMode() {
    global $init;
//    mkdir($init->dirName, $init->dirMode);

    // 현재의 시간을 취득
    $now = time();
    $now = $now - ($now % ($init->unitTime));

    $fileName = "{$init->dirName}/hakojima.dat";
    touch($fileName);
    $fp = fopen($fileName, "w");
    fputs($fp, "1\n");
    fputs($fp, "{$now}\n");
    fputs($fp, "0\n");
    fputs($fp, "1\n");
    fclose($fp);
  }
  function delMode() {
    global $init;
    if(empty($this->dataSet['NUMBER'])) {
      $dirName = "data";
    } else {
      $dirName = "data.bak{$this->dataSet['NUMBER']}";
    }
    $this->rmTree($dirName);
  }
  function timeMode() {
    $year = $this->dataSet['YEAR'];
    $day  = $this->dataSet['DATE'];
    $mon  = $this->dataSet['MON'];
    $hour = $this->dataSet['HOUR'];
    $min  = $this->dataSet['MIN'];
    $sec  = $this->dataSet['NSEC'];
    $ctSec = mktime($hour, $min, $sec, $mon, $day, $year);
    $this->stimeMode($ctSec);
  }
  function stimeMode($sec) {
    global $init;
    
    $fileName = "{$init->dirName}/hakojima.dat";
    $fp = fopen($fileName, "r+");
    $buffer = array();
    while($line = fgets($fp, READ_LINE)) {
      array_push($buffer, $line);
    }
    $buffer[1] = "{$sec}\n";
    fseek($fp, 0);
    while($line = array_shift($buffer)) {
      fputs($fp, $line);
    }
    fclose($fp);
    
  }
  function currentMode() {
    global $init;
//    $this->rmTree("{$init->dirName}");
//    mkdir("{$init->dirName}", $init->dirMode);

    $dir = opendir("{$init->dirName}.bak/");
    while($fileName = readdir($dir)) {
      if(!(strcmp($fileName, ".") == 0 || strcmp($fileName, "..") == 0))
        copy("{$init->dirName}.bak/{$fileName}", "{$init->dirName}/{$fileName}");
    } 
    closedir($dir);
  }
  //----------------------------------------
  function rmTree($dirName) {
    if(is_dir("{$dirName}")) {
      $dir = opendir("{$dirName}/");
      while($fileName = readdir($dir)) {
        if(!(strcmp($fileName, ".") == 0 || strcmp($fileName, "..") == 0))
          unlink("{$dirName}/{$fileName}");
      }
      closedir($dir);
//      rmdir($dirName);
    }
  }
  function passCheck() {
    global $init;
    if(strcmp($this->dataSet['PASSWORD'], $init->masterPassword) == 0) {
      return 1;
    } else {
      print "<h2>비밀번호가 다릅니다.</h2>\n";
      return 0;
    }
  }
}

$start = new Main();
$start->execute();

?>