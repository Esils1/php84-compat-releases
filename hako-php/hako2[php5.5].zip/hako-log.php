<?php
/*******************************************************************

  모형정원 제도 2 for PHP

  
  $Id: hako-log.php, v 1.2 2004/08/10 22:00:03 Watson Exp $

*******************************************************************/

class Log extends LogIO {

  function discover($name) {
    global $init;
    $this->history("{$init->tagName_}{$name}섬 {$init->_tagName}가 발견되었습니다.");
  }
  function changeName($name1, $name2) {
    global $init;
    $this->history("{$init->tagName_}{$name1}섬 {$init->_tagName}, 이름을 {$init->tagName_}{$name2}섬 {$init->_tagName}로 변경했습니다.");
  }
  // 수상
  function prize($id, $name, $pName) {
    global $init;
    $this->out("{$init->tagName_}{$name}섬 {$init->_tagName}가 <strong>$pName</strong>를 수상했습니다.", $id);
    $this->history("{$init->tagName_}{$name}섬 {$init->_tagName},<strong>$pName</strong>를 수상");
  }
  // 사멸
  function dead($id, $name) {
    global $init;
    $this->out("{$init->tagName_}{$name}섬 {$init->_tagName}로부터,<strong>무인도</strong>가 되었습니다.", $id);
    $this->history("{$init->tagName_}{$name}섬 {$init->_tagName}, <strong>무인도</strong>가 된다.");
  }
  function doNothing($id, $name, $comName) {
    //global $init;
    //$this->out("{$init->tagName_}{$name}섬 {$init->_tagName}로{$init->tagComName_}{$comName}{$init->_tagComName}를 실행했습니다.", $id);
  }
  // 자금 부족하다
  function noMoney($id, $name, $comName) {
    global $init;
    $this->out("{$init->tagName_}{$name}섬 {$init->_tagName}로 예정되어 있던{$init->tagComName_}{$comName}{$init->_tagComName}는, 자금이 부족하여 중지되었습니다.", $id);
  }
  // 식량 부족하다
  function noFood($id, $name, $comName) {
    global $init;
    $this->out("{$init->tagName_}{$name}섬 {$init->_tagName}로 예정되어 있던{$init->tagComName_}{$comName}{$init->_tagComName}는, 비축 식량이 부족하여 중지되었습니다.", $id);
  }
  // 대상 지형의 종류에 의한 실패
  function landFail($id, $name, $comName, $kind, $point) {
    global $init;
    $this->out("{$init->tagName_}{$name}섬 {$init->_tagName}로 예정되어 있던{$init->tagComName_}{$comName}{$init->_tagComName}는, 예정지의{$init->tagName_}{$point}{$init->_tagName}가<strong>{$kind}</strong>였기 때문에 중지되었습니다.", $id);
  }
  // 성공
  function landSuc($id, $name, $comName, $point) {
    global $init;
    $this->out("{$init->tagName_}{$name}섬 {$point}{$init->_tagName}로{$init->tagComName_}{$comName}{$init->_tagComName}를 실행했습니다.", $id);
  }
  // 매장 자금
  function maizo($id, $name, $comName, $value) {
    global $init;
    $this->out("{$init->tagName_}{$name}섬 {$init->_tagName}에서의{$init->tagComName_}{$comName}{$init->_tagComName}중 <strong>{$value}{$init->unitMoney}의 매장 자금</strong>이 발견되었습니다.", $id);
  }
  function noLandAround($id, $name, $comName, $point) {
    global $init;
    $this->out("{$init->tagName_}{$name}섬 {$init->_tagName}로 예정되어 있던{$init->tagComName_}{$comName}{$init->_tagComName}는, 예정지의{$init->tagName_}{$point}{$init->_tagName}의 주변에 육지가 없었기 때문에 중지되었습니다.", $id);
  }
  // 유전 발견
  function oilFound($id, $name, $point, $comName, $str) {
    global $init;
    $this->out("{$init->tagName_}{$name}섬 {$point}{$init->_tagName}로<strong>{$str}</strong>의 예산을 투입해{$init->tagComName_}{$comName}{$init->_tagComName}를 실행하여 <strong>유전을 발견했습니다</strong>.", $id);
  }
  // 유전 발견 하지 못하고
  function oilFail($id, $name, $point, $comName, $str) {
    global $init;
    $this->out("{$init->tagName_}{$name}섬 {$point}{$init->_tagName}로<strong>{$str}</strong>의 예산을 투입해{$init->tagComName_}{$comName}{$init->_tagComName}를 했습니단, 유전은 발견되지 않았습니다.", $id);
  }
  // 방어 시설, 자폭 세트
  function bombSet($id, $name, $lName, $point) {
    global $init;
    $this->out("{$init->tagName_}{$name}섬 {$point}{$init->_tagName}의<strong>{$lName}</strong>의<strong>자폭 장치가 설치</strong>되었습니다.", $id);
  }
  // 방어 시설, 자폭 작동
  function bombFire($id, $name, $lName, $point) {
    global $init;
    $this->out("{$init->tagName_}{$name}섬 {$point}{$init->_tagName}의<strong>{$lName}</strong>,{$init->tagDisaster_}자폭 장치 작동!{$init->_tagDisaster}", $id);
  }
  // 조림 or미사일 기지
  function PBSuc($id, $name, $comName, $point) {
    global $init;
    $this->secret("{$init->tagName_}{$name}섬 {$point}{$init->_tagName}로 {$init->tagComName_}{$comName}{$init->_tagComName}를 실행했습니다.", $id);
    $this->out("어쩐지 {$init->tagName_}{$name}섬 {$init->_tagName}의 <strong>숲</strong>이 늘어난 것 같습니다.", $id);
  }
  // 위장 시설
  function hariSuc($id, $name, $comName, $comName2, $point) {
    global $init;
    $this->secret("{$init->tagName_}{$name}섬 {$point}{$init->_tagName}로{$init->tagComName_}{$comName}{$init->_tagComName}를 실행했습니다.", $id);
    $this->landSuc($id, $name, $comName2, $point);
  }
  // 기념비, 발사
  function monFly($id, $name, $lName, $point) {
    global $init;
    $this->out("{$init->tagName_}{$name}섬 {$point}{$init->_tagName}의<strong>{$lName}</strong>가<strong>굉음과 함께 날아올랐습니다</strong>.", $id);
  }
  // 미사일을 발사하려 했다(or 괴수를 파견하려 했다)가 대상이 없다
  function msNoTarget($id, $name, $comName) {
    global $init;
    $this->out("{$init->tagName_}{$name}섬 {$init->_tagName}로 예정되어 있던{$init->tagComName_}{$comName}{$init->_tagComName}는, 목표 섬에 대상 섬에 사람이 보이지 않아 중지되었습니다.", $id);
  }
  // 스텔스 미사일 발사했지만 범위 밖
  function msOutS($id, $tId, $name, $tName, $comName, $point) {
    global $init;
    $this->secret("{$init->tagName_}{$name}섬 {$init->_tagName}가{$init->tagName_}{$tName}섬 $point{$init->_tagName}지점을 향해{$init->tagComName_}{$comName}{$init->_tagComName}를 실시했습니단,<strong>영역 밖의 바다</strong>에 떨어진 것 같습니다.", $id, $tId);
    $this->late("<strong>누군가</strong>가{$init->tagName_}{$tName}섬 {$point}{$init->_tagName}을 향해{$init->tagComName_}{$comName}{$init->_tagComName}를 실시했습니단,<strong>영역 밖의 바다</strong>에 떨어진 것 같습니다.", $tId);
  }
  // 미사일 발사했지만 범위 밖
  function msOut($id, $tId, $name, $tName, $comName, $point) {
    global $init;
    $this->out("{$init->tagName_}{$name}섬 {$init->_tagName}가{$init->tagName_}{$tName}섬 {$point}{$init->_tagName}지점을 향해{$init->tagComName_}{$comName}{$init->_tagComName}를 실시했습니단,<strong>영역 밖의 바다</strong>에 떨어진 것 같습니다.", $id, $tId);
  }
  // 스텔스 미사일 발사했지만 방어 시설에서 포착
  function msCaughtS($id, $tId, $name, $tName, $comName, $point, $tPoint) {
    global $init;
    $this->secret("{$init->tagName_}{$name}섬 {$init->_tagName}가{$init->tagName_}{$tName}섬 {$point}{$init->_tagName}지점을 향해{$init->tagComName_}{$comName}{$init->_tagComName}를 실시했습니단,{$init->tagName_}{$tPoint}{$init->_tagName}지점 상공에서 방어막에 포착되어<strong>공중 폭발</strong>했습니다.", $id, $tId);
    $this->late("<strong>누군가</strong>가{$init->tagName_}{$tName}섬 {$point}{$init->_tagName}을 향해{$init->tagComName_}{$comName}{$init->_tagComName}를 실시했습니단,{$init->tagName_}{$tPoint}{$init->_tagName}지점 상공에서 방어막에 포착되어<strong>공중 폭발</strong>했습니다.", $tId);
  }
  // 미사일 발사했지만 방어 시설에서 포착
  function msCaught($id, $tId, $name, $tName, $comName, $point, $tPoint) {
    global $init;
    $this->out("{$init->tagName_}{$name}섬 {$init->_tagName}가{$init->tagName_}{$tName}섬 {$point}{$init->_tagName}지점을 향해{$init->tagComName_}{$comName}{$init->_tagComName}를 실시했습니단,{$init->tagName_}{$tPoint}{$init->_tagName}지점 상공에서 방어막에 포착되어<strong>공중 폭발</strong>했습니다.", $id, $tId);
  }
  // 스텔스 미사일 발사했지만 효과 없음
  function msNoDamageS($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) {
    global $init;
    $this->secret("{$init->tagName_}{$name}섬 {$init->_tagName}가{$init->tagName_}{$tName}섬 {$point}{$init->_tagName}지점을 향해{$init->tagComName_}{$comName}{$init->_tagComName}를 실시했습니단,{$init->tagName_}{$tPoint}{$init->_tagName}의<strong>{$tLname}</strong>에 떨어졌으므로 피해가 없었습니다.", $id, $tId);
    $this->late("<strong>누군가</strong>가{$init->tagName_}{$tName}섬 {$point}{$init->_tagName}지점을 향해{$init->tagComName_}{$comName}{$init->_tagComName}를 실시했습니단,{$init->tagName_}{$tPoint}{$init->_tagName}의<strong>{$tLname}</strong>에 떨어졌으므로 피해가 없었습니다.", $tId);
  }  
  // 미사일 발사했지만 효과 없음
  function msNoDamage($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) {
    global $init;
    $this->out("{$init->tagName_}{$name}섬 {$init->_tagName}가{$init->tagName_}{$tName}섬 {$point}{$init->_tagName}지점을 향해{$init->tagComName_}{$comName}{$init->_tagComName}를 실시했습니단,{$init->tagName_}{$tPoint}{$init->_tagName}의<strong>{$tLname}</strong>에 떨어졌으므로 피해가 없었습니다.", $id, $tId);
  }
  // 육지 파괴탄, 산에 명중
  function msLDMountain($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) {
    global $init;
    $this->out("{$init->tagName_}{$name}섬 {$init->_tagName}가{$init->tagName_}{$tName}섬 {$point}{$init->_tagName}지점을 향해{$init->tagComName_}{$comName}{$init->_tagComName}를 실행해,{$init->tagName_}{$tPoint}{$init->_tagName}의<strong>{$tLname}</strong>에 명중.<strong>{$tLname}</strong>는 날아가, 황무지화했습니다.", $id, $tId);
  }
  // 육지 파괴탄, 해저 기지에 명중
  function msLDSbase($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) {
    global $init;
    $this->out("{$init->tagName_}{$name}섬 {$init->_tagName}가{$init->tagName_}{$tName}섬 {$point}{$init->_tagName}지점을 향해{$init->tagComName_}{$comName}{$init->_tagComName}를 실행해,{$init->tagName_}{$tPoint}{$init->_tagName}에 착탄 후 폭발, 해당 지점에 있던<strong>{$tLname}</strong>는 흔적도 없이 날아갔습니다.", $id, $tId);
  }
  // 육지 파괴탄, 괴수에게 명중
  function msLDMonster($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) {
    global $init;
    $this->out("{$init->tagName_}{$name}섬 {$init->_tagName}가{$init->tagName_}{$tName}섬 {$point}{$init->_tagName}지점을 향해{$init->tagComName_}{$comName}{$init->_tagComName}를 실행해,{$init->tagName_}{$tPoint}{$init->_tagName}에 착탄 해 폭발.육지는 <strong>괴수{$tLname}</strong>와도 수몰 했습니다.", $id, $tId);
  }
  // 육지 파괴탄, 얕은 여울에 명중
  function msLDSea1($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) {
    global $init;
    $this->out("{$init->tagName_}{$name}섬 {$init->_tagName}가{$init->tagName_}{$tName}섬 {$point}{$init->_tagName}지점을 향해{$init->tagComName_}{$comName}{$init->_tagComName}를 실행해,{$init->tagName_}{$tPoint}{$init->_tagName}의<strong>{$tLname}</strong>에 착탄.해저가 뒤흔들렸습니다.", $id, $tId);
  }
  // 육지 파괴탄, 그 밖의 지형에 명중
  function msLDLand($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) {
    global $init;
    $this->out("{$init->tagName_}{$name}섬 {$init->_tagName}가{$init->tagName_}{$tName}섬 {$point}{$init->_tagName}지점을 향해{$init->tagComName_}{$comName}{$init->_tagComName}를 실행해,{$init->tagName_}{$tPoint}{$init->_tagName}의<strong>{$tLname}</strong>에 착탄.육지는 수몰 했습니다.", $id, $tId);
  }
  // 스텔스 미사일, 황무지에 착탄
  function msWasteS($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) {
    global $init;
    $this->secret("{$init->tagName_}{$name}섬 {$init->_tagName}가{$init->tagName_}{$tName}섬 {$point}{$init->_tagName}지점을 향해{$init->tagComName_}{$comName}{$init->_tagComName}를 실시했습니단,{$init->tagName_}{$tPoint}{$init->_tagName}의<strong>{$tLname}</strong>에 떨어졌습니다.", $id, $tId);
    $this->late("<strong>누군가</strong>가{$init->tagName_}{$tName}섬 {$point}{$init->_tagName}지점을 향해{$init->tagComName_}{$comName}{$init->_tagComName}를 실시했습니단,{$init->tagName_}{$tPoint}{$init->_tagName}의<strong>{$tLname}</strong>에 떨어졌습니다.", $tId);
  }
  // 통상 미사일, 황무지에 착탄
  function msWaste($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) {
    global $init;
    $this->out("{$init->tagName_}{$name}섬 {$init->_tagName}가{$init->tagName_}{$tName}섬 {$point}{$init->_tagName}지점을 향해{$init->tagComName_}{$comName}{$init->_tagComName}를 실시했습니단,{$init->tagName_}{$tPoint}{$init->_tagName}의<strong>{$tLname}</strong>에 떨어졌습니다.", $id, $tId);
  }
  // 스텔스 미사일, 괴수에게 명중, 경화 상태로 피해 없음
  function msMonNoDamageS($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) {
    global $init;
    $this->secret("{$init->tagName_}{$name}섬 {$init->_tagName}가{$init->tagName_}{$tName}섬 {$point}{$init->_tagName}지점을 향해{$init->tagComName_}{$comName}{$init->_tagComName}를 실행해,{$init->tagName_}{$tPoint}{$init->_tagName}의<strong>괴수{$tLname}</strong>에 명중, 그러나 경화 상태였기 때문에 효과가 없었습니다.", $id, $tId);
    $this->out("<strong>누군가</strong>가{$init->tagName_}{$tName}섬 {$point}{$init->_tagName}지점을 향해{$init->tagComName_}{$comName}{$init->_tagComName}를 실행해,{$init->tagName_}{$tPoint}{$init->_tagName}의<strong>괴수{$tLname}</strong>에 명중, 그러나 경화 상태였기 때문에 효과가 없었습니다.", $tId);
  }
  // 통상 미사일, 괴수에게 명중, 경화 상태로 피해 없음
  function msMonNoDamage($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) {
    global $init;
    $this->out("{$init->tagName_}{$name}섬 {$init->_tagName}가{$init->tagName_}{$tName}섬 {$point}{$init->_tagName}지점을 향해{$init->tagComName_}{$comName}{$init->_tagComName}를 실행해,{$init->tagName_}{$tPoint}{$init->_tagName}의<strong>괴수{$tLname}</strong>에 명중, 그러나 경화 상태였기 때문에 효과가 없었습니다.", $id, $tId);
  }
  // 스텔스 미사일, 괴수에게 명중, 살상
  function msMonKillS($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) {
    global $init;
    $this->secret("{$init->tagName_}{$name}섬 {$init->_tagName}가{$init->tagName_}{$tName}섬 {$point}{$init->_tagName}지점을 향해{$init->tagComName_}{$comName}{$init->_tagComName}를 실행해,{$init->tagName_}{$tPoint}{$init->_tagName}의<strong>괴수{$tLname}</strong>에 명중.<strong>괴수{$tLname}</strong>는 소멸했습니다.", $id, $tId);
    $this->late("<strong>누군가</strong>가{$init->tagName_}{$tName}섬 {$point}{$init->_tagName}지점을 향해{$init->tagComName_}{$comName}{$init->_tagComName}를 실행해,{$init->tagName_}{$tPoint}{$init->_tagName}의<strong>괴수{$tLname}</strong>에 명중.<strong>괴수{$tLname}</strong>는 소멸했습니다.", $tId);
  }
  // 통상 미사일, 괴수에게 명중, 살상
  function msMonKill($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) {
    global $init;
    $this->out("{$init->tagName_}{$name}섬 {$init->_tagName}가{$init->tagName_}{$tName}섬 {$point}{$init->_tagName}지점을 향해{$init->tagComName_}{$comName}{$init->_tagComName}를 실행해,{$init->tagName_}{$tPoint}{$init->_tagName}의<strong>괴수{$tLname}</strong>에 명중.<strong>괴수{$tLname}</strong>는 소멸했습니다.", $id, $tId);
  }
  // 괴수의 시체
  function msMonMoney($tId, $mName, $value) {
    global $init;
    $this->out("<strong>괴수{$mName}</strong>의 잔해에는,<strong>{$value}{$init->unitMoney}</strong>의 값이 붙었습니다.", $tId);
  }
  // 스텔스 미사일, 괴수에게 명중, 데미지
  function msMonsterS($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) {
    global $init;
    $this->secret("{$init->tagName_}{$name}섬 {$init->_tagName}가{$init->tagName_}{$tName}섬 {$point}{$init->_tagName}지점을 향해{$init->tagComName_}{$comName}{$init->_tagComName}를 실행해,{$init->tagName_}{$tPoint}{$init->_tagName}의<strong>괴수{$tLname}</strong>에 명중.<strong>괴수{$tLname}</strong>는 괴로운 듯하게 사납게 울부짖었습니다.", $id, $tId);
    $this->late("<strong>누군가</strong>가{$init->tagName_}{$tName}섬 {$point}{$init->_tagName}지점을 향해{$init->tagComName_}{$comName}{$init->_tagComName}를 실행해,{$init->tagName_}{$tPoint}{$init->_tagName}의<strong>괴수{$tLname}</strong>에 명중.<strong>괴수{$tLname}</strong>는 괴로운 듯하게 사납게 울부짖었습니다.", $tId);
  }
  // 통상 미사일, 괴수에게 명중, 데미지
  function msMonster($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) {
    global $init;
    $this->out("{$init->tagName_}{$name}섬 {$init->_tagName}가{$init->tagName_}{$tName}섬 {$point}{$init->_tagName}지점을 향해{$init->tagComName_}{$comName}{$init->_tagComName}를 실행해,{$init->tagName_}{$tPoint}{$init->_tagName}의<strong>괴수{$tLname}</strong>에 명중.<strong>괴수{$tLname}</strong>는 괴로운 듯하게 사납게 울부짖었습니다.", $id, $tId);
  }
  // 스텔스 미사일 통상 지형에 명중
  function msNormalS($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) {
    global $init;
    $this->secret("{$init->tagName_}{$name}섬 {$init->_tagName}가{$init->tagName_}{$tName}섬 {$point}{$init->_tagName}지점을 향해{$init->tagComName_}{$comName}{$init->_tagComName}를 실행해,{$init->tagName_}{$tPoint}{$init->_tagName}의<strong>{$tLname}</strong>에 명중, 일대가 괴멸했습니다.", $id, $tId);
    $this->late("<strong>누군가</strong>가{$init->tagName_}{$tName}섬 {$point}{$init->_tagName}지점을 향해{$init->tagComName_}{$comName}{$init->_tagComName}를 실행해,{$init->tagName_}{$tPoint}{$init->_tagName}의<strong>{$tLname}</strong>에 명중, 일대가 괴멸했습니다.", $tId);
  }
  // 통상 미사일 통상 지형에 명중
  function msNormal($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) {
    global $init;
    $this->out("{$init->tagName_}{$name}섬 {$init->_tagName}가{$init->tagName_}{$tName}섬 {$point}{$init->_tagName}지점을 향해{$init->tagComName_}{$comName}{$init->_tagComName}를 실행해,{$init->tagName_}{$tPoint}{$init->_tagName}의<strong>{$tLname}</strong>에 명중, 일대가 괴멸했습니다.", $id, $tId);
  }
  // 미사일을 발사하려 했지만 기지가 없다
  function msNoBase($id, $name, $comName) {
    global $init;
    $this->out("{$init->tagName_}{$name}섬 {$init->_tagName}로 예정되어 있던{$init->tagComName_}{$comName}{$init->_tagComName}는,<strong>미사일 설비를 보유하고 있지 않기</strong>때문에 실행할 수 없었습니다.", $id);
  }
  // 미사일 난민 도착
  function msBoatPeople($id, $name, $achive) {
    global $init;
    $this->out("{$init->tagName_}{$name}섬 {$init->_tagName}에 어디선가<strong>{$achive}{$init->unitPop}것 난민</strong>이 표착했습니다.{$init->tagName_}{$name}섬 {$init->_tagName}는 기꺼이 받아들인 것 같습니다.", $id);
  }
  // 괴수 파견
  function monsSend($id, $tId, $name, $tName) {
    global $init;
    $this->out("{$init->tagName_}{$name}섬 {$init->_tagName}가<strong>인조 괴수</strong>를 건조.{$init->tagName_}{$tName}섬 {$init->_tagName}에 보냈습니다.", $id, $tId);
  }
  // 수출
  function sell($id, $name, $comName, $value) {
    global $init;
    $this->out("{$init->tagName_}{$name}섬 {$init->_tagName}가<strong>{$value}{$init->unitFood}</strong>의{$init->tagComName_}{$comName}{$init->_tagComName}를 실행했습니다.", $id);
  }
  // 원조
  function aid($id, $tId, $name, $tName, $comName, $str) {
    global $init;
    $this->out("{$init->tagName_}{$name}섬 {$init->_tagName}가{$init->tagName_}{$tName}섬 {$init->_tagName}에<strong>{$str}</strong>의{$init->tagComName_}{$comName}{$init->_tagComName}를 실행했습니다.", $id, $tId);
  }
  // 인구 유치 활동
  function propaganda($id, $name, $comName) {
    global $init;
    $this->out("{$init->tagName_}{$name}섬 {$init->_tagName}로{$init->tagComName_}{$comName}{$init->_tagComName}를 실행했습니다.", $id);
  }
  // 포기
  function giveup($id, $name) {
    global $init;
    $this->out("{$init->tagName_}{$name}섬 {$init->_tagName}는 포기되어<strong>무인도</strong>가 되었습니다.", $id);
    $this->history("{$init->tagName_}{$name}섬 {$init->_tagName}, 포기되고<strong>무인도</strong>가 된다.");
  }
  // 유전으로부터의 수입
  function oilMoney($id, $name, $lName, $point, $str) {
    global $init;
    $this->out("{$init->tagName_}{$name}섬 {$point}{$init->_tagName}의<strong>{$lName}</strong>로부터,<strong>{$str}</strong>의 수익이 올랐습니다.", $id);
  }
  // 유전 고갈
  function oilEnd($id, $name, $lName, $point) {
    global $init;
    $this->out("{$init->tagName_}{$name}섬 {$point}{$init->_tagName}의 <strong>{$lName}</strong>는 고갈된 것 같습니다.", $id);
  }
  // 괴수, 방어 시설을 밟는다
  function monsMoveDefence($id, $name, $lName, $point, $mName) {
    global $init;
    $this->out("<strong>괴수{$mName}</strong>가{$init->tagName_}{$name}섬 {$point}{$init->_tagName}의<strong>{$lName}</strong>에 도달,<strong>{$lName}의 자폭 장치가 작동!</strong>", $id);
  }
  // 괴수 이동
  function monsMove($id, $name, $lName, $point, $mName) {
    global $init;
    $this->out("{$init->tagName_}{$name}섬 {$point}{$init->_tagName}의<strong>{$lName}</strong>가<strong>괴수{$mName}</strong>에게 밟혀 폐허가 되었습니다.", $id);
  }
  // 화재
  function fire($id, $name, $lName, $point) {
    global $init;
    $this->out("{$init->tagName_}{$name}섬 {$point}{$init->_tagName}의<strong>{$lName}</strong>가{$init->tagDisaster_}화재{$init->_tagDisaster}에 의해 괴멸했습니다.", $id);
  }
  // 광역 피해, 바다로 변경
  function wideDamageSea2($id, $name, $lName, $point) {
    global $init;
    $this->out("{$init->tagName_}{$name}섬 {$point}{$init->_tagName}의<strong>{$lName}</strong>는 흔적도 없이 사라졌습니다.", $id);
  }
  // 광역 피해, 괴수 수몰
  function wideDamageMonsterSea($id, $name, $lName, $point) {
    global $init;
    $this->out("{$init->tagName_}{$name}섬 {$point}{$init->_tagName}의 육지는 <strong>괴수{$lName}</strong>와 수몰 했습니다.", $id);
  }
  // 광역 피해, 수몰
  function wideDamageSea($id, $name, $lName, $point) {
    global $init;
    $this->out("{$init->tagName_}{$name}섬 {$point}{$init->_tagName}의<strong>{$lName}</strong>는<strong>수몰</strong>했습니다.", $id);
  }
  // 광역 피해, 괴수
  function wideDamageMonster($id, $name, $lName, $point) {
    global $init;
    $this->out("{$init->tagName_}{$name}섬 {$point}{$init->_tagName}의<strong>괴수{$lName}</strong>는 날아갔습니다.", $id);
  }
  // 광역 피해, 황무지
  function wideDamageWaste($id, $name, $lName, $point) {
    global $init;
    $this->out("{$init->tagName_}{$name}섬 {$point}{$init->_tagName}의<strong>{$lName}</strong>는 순식간에 <strong>황무지</strong>가 되었습니다.", $id);
  }
  // 지진 발생
  function earthquake($id, $name) {
    global $init;
    $this->out("{$init->tagName_}{$name}섬 {$init->_tagName}로 대규모{$init->tagDisaster_}지진{$init->_tagDisaster}가 발생!", $id);
  }
  // 지진피해
  function eQDamage($id, $name, $lName, $point) {
    global $init;
    $this->out("{$init->tagName_}{$name}섬 {$point}{$init->_tagName}의<strong>{$lName}</strong>는{$init->tagDisaster_}지진{$init->_tagDisaster}에 의해 괴멸했습니다.", $id);
  }
  // 기아
  function starve($id, $name) {
    global $init;
    $this->out("{$init->tagName_}{$name}섬 {$init->_tagName}의{$init->tagDisaster_}식량이 부족{$init->_tagDisaster}하고 있습니다!", $id);
  }
  // 식량 부족 피해
  function svDamage($id, $name, $lName, $point) {
    global $init;
    $this->out("{$init->tagName_}{$name}섬 {$point}{$init->_tagName}의<strong>{$lName}</strong>에<strong>식량을 요구하며 주민이 쇄도</strong>.<strong>{$lName}</strong>는 괴멸했습니다.", $id);
  }
  // 해일 발생
  function tsunami($id, $name) {
    global $init;
    $this->out("{$init->tagName_}{$name}섬 {$init->_tagName}부근에서{$init->tagDisaster_}해일{$init->_tagDisaster}발생!", $id);
  }
  // 해일 피해
  function tsunamiDamage($id, $name, $lName, $point) {
    global $init;
    $this->out("{$init->tagName_}{$name}섬 {$point}{$init->_tagName}의<strong>{$lName}</strong>는{$init->tagDisaster_}해일{$init->_tagDisaster}에 의해 붕괴했습니다.", $id);
  }
  // 괴수현
  function monsCome($id, $name, $mName, $point, $lName) {
    global $init;
    $this->out("{$init->tagName_}{$name}섬 {$init->_tagName}에<strong>괴수{$mName}</strong>출현!{$init->tagName_}{$point}{$init->_tagName}의<strong>{$lName}</strong>가 짓밟혔습니다.", $id);
  }
  // 지반침하 발생
  function falldown($id, $name) {
    global $init;
    $this->out("{$init->tagName_}{$name}섬 {$init->_tagName}로{$init->tagDisaster_}지반침하{$init->_tagDisaster}가 발생했습니다!", $id);
  }
  // 지반침하 피해
  function falldownLand($id, $name, $lName, $point) {
    global $init;
    $this->out("{$init->tagName_}{$name}섬 {$point}{$init->_tagName}의<strong>{$lName}</strong>는 바다 속에 가라앉았습니다.", $id);
  }
  // 태풍 발생
  function typhoon($id, $name) {
    global $init;
    $this->out("{$init->tagName_}{$name}섬 {$init->_tagName}에{$init->tagDisaster_}태풍{$init->_tagDisaster}상륙!", $id);
  }

  // 태풍 피해
  function typhoonDamage($id, $name, $lName, $point) {
    global $init;
    $this->out("{$init->tagName_}{$name}섬 {$point}{$init->_tagName}의<strong>{$lName}</strong>는{$init->tagDisaster_}태풍{$init->_tagDisaster}으로 날아갔습니다.", $id);
  }
  // 운석, 그 밖
  function hugeMeteo($id, $name, $point) {
    global $init;
    $this->out("{$init->tagName_}{$name}섬 {$point}{$init->_tagName}지점에{$init->tagDisaster_}거대 운석{$init->_tagDisaster}가 낙하!", $id);
  }
  // 기념비, 낙하
  function monDamage($id, $name, $point) {
    global $init;
    $this->out("<strong>정체불명의 물체</strong>이{$init->tagName_}{$name}섬 {$point}{$init->_tagName}지점에 낙하했습니다!", $id);
  }
  // 운석, 바다
  function meteoSea($id, $name, $lName, $point) {
    global $init;
    $this->out("{$init->tagName_}{$name}섬 {$point}{$init->_tagName}의<strong>{$lName}</strong>에{$init->tagDisaster_}운석{$init->_tagDisaster}가 낙하했습니다.", $id);
  }
  // 운석, 산
  function meteoMountain($id, $name, $lName, $point) {
    global $init;
    $this->out("{$init->tagName_}{$name}섬 {$point}{$init->_tagName}의<strong>{$lName}</strong>에{$init->tagDisaster_}운석{$init->_tagDisaster}가 낙하,<strong>{$lName}</strong>는 날아갔습니다.", $id);
  }
  // 운석, 해저 기지
  function meteoSbase($id, $name, $lName, $point) {
    global $init;
    $this->out("{$init->tagName_}{$name}섬 {$point}{$init->_tagName}의<strong>{$lName}</strong>에{$init->tagDisaster_}운석{$init->_tagDisaster}가 낙하,<strong>{$lName}</strong>는 붕괴했습니다.", $id);
  }
  // 운석, 괴수
  function meteoMonster($id, $name, $lName, $point) {
    global $init;
    $this->out("<strong>괴수{$lName}</strong>가 있던{$init->tagName_}{$name}섬 {$point}{$init->_tagName}지점에{$init->tagDisaster_}운석{$init->_tagDisaster}가 낙하, 육지는 <strong>괴수{$lName}</strong>와 수몰 했습니다.", $id);
  }
  // 운석, 얕은 여울
  function meteoSea1($id, $name, $lName, $point) {
    global $init;
    $this->out("{$init->tagName_}{$name}섬 {$point}{$init->_tagName}지점에{$init->tagDisaster_}운석{$init->_tagDisaster}가 낙하, 해저가 뒤흔들렸습니다.", $id);
  }
  // 운석, 그 밖
  function meteoNormal($id, $name, $lName, $point) {
    global $init;
    $this->out("{$init->tagName_}{$name}섬 {$point}{$init->_tagName}지점의<strong>{$lName}</strong>에{$init->tagDisaster_}운석{$init->_tagDisaster}가 낙하, 일대가 수몰 했습니다.", $id);
  }
  // 분화
  function eruption($id, $name, $lName, $point) {
    global $init;
    $this->out("{$init->tagName_}{$name}섬 {$point}{$init->_tagName}지점에서{$init->tagDisaster_}화산이 분화{$init->_tagDisaster},<strong>산</strong>이 생겼습니다.", $id);
  }
  // 분화, 얕은 여울
  function eruptionSea1($id, $name, $lName, $point) {
    global $init;
    $this->out("{$init->tagName_}{$name}섬 {$point}{$init->_tagName}지점의<strong>{$lName}</strong>는,{$init->tagDisaster_}분화{$init->_tagDisaster}의 영향으로 육지가 되었습니다.", $id);
  }
  // 분화, 바다 또는 해저 기지
  function eruptionSea($id, $name, $lName, $point) {
    global $init;
    $this->out("{$init->tagName_}{$name}섬 {$point}{$init->_tagName}지점의<strong>{$lName}</strong>는,{$init->tagDisaster_}분화{$init->_tagDisaster}의 영향으로 해저가 융기, 얕은 여울이 되었습니다.", $id);
  }
  // 분화, 그 밖
  function eruptionNormal($id, $name, $lName, $point) {
    global $init;
    $this->out("{$init->tagName_}{$name}섬 {$point}{$init->_tagName}지점의<strong>{$lName}</strong>는,{$init->tagDisaster_}분화{$init->_tagDisaster}의 영향으로 괴멸했습니다.", $id);
  }
}

?>