<?php
/*******************************************************************

  하코니와 제도 2 for PHP

  
  $Id: hako-main.php,v 1.20 2004/12/14 12:24:56 Watson Exp $

*******************************************************************/

require 'config.php';
require 'hako-html.php';
require 'hako-turn.php';
$init = new Init;

define("READ_LINE", 1024);
$THIS_FILE =  $init->baseDir . "/hako-main.php";
$BACK_TO_TOP = "<A HREF=\"{$THIS_FILE}?\">{$init->tagBig_}처음 페이지로{$init->_tagBig}</A>";
$ISLAND_TURN; // 턴 수

$PRODUCT_VERSION = '20040328';

//--------------------------------------------------------------------
class Hako extends HakoIO {
  var $islandList;	// 섬 리스트
  var $targetList;	// 대상 섬 리스트
  var $defaultTarget;	// 목표 보충용 대상
  
  function readIslands(&$cgi) {
    global $init;
    
    $m = $this->readIslandsFile($cgi);
    $this->islandList = $this->getIslandList($cgi->dataSet['defaultID']);
    if($init->targetIsland == 1) {
      // 목표 섬으로 소유 섬이 선택된 리스트
      $this->targetList = $this->islandList;
    } else {
      // 순위가 TOP인 섬이 선택된 상태의 리스트
      $this->targetList = $this->getIslandList($cgi->dataSet['defaultTarget']);
    }
    return $m;
  }

  //---------------------------------------------------
  // 섬 리스트 생성
  //---------------------------------------------------
  function getIslandList($select = 0) {
    $list = "";
    for($i = 0; $i < $this->islandNumber; $i++) {
      $name = $this->islands[$i]['name'];
      $id   = $this->islands[$i]['id'];

      // 공격 목표를 미리 내 섬으로 설정
      if(empty($this->defaultTarget)) {$this->defaultTarget = $id;}

      if($id == $select) {
        $s = "selected";
      } else {
        $s = "";
      }
      $list .= "<option value=\"$id\" $s>{$name}섬</option>\n";
    }
    return $list;
  }
  //---------------------------------------------------
  // 수상 관련 리스트 생성
  //---------------------------------------------------
  function getPrizeList($prize) {
    global $init;
    list($flags, $monsters, $turns) = split(",", $prize, 3);

    $turns = split(",", $turns);
    $prizeList = "";
    // 턴상
    $max = -1;
    $nameList = "";
    if($turns[0] != "") {
      for($k = 0; $k < count($turns) - 1; $k++) {
        $nameList .= "[{$turns[$k]}] ";
        $max = $k;
      }
    }
    if($max != -1) {
      $prizeList .= "<img src=\"prize0.gif\" alt=\"$nameList\" width=\"16\" height=\"16\"> ";
    }
    // 상
    $f = 1;
    for($k = 1; $k < count($init->prizeName); $k++) {
      if($flags & $f) {
        $prizeList .= "<img src=\"prize{$k}.gif\" alt=\"{$init->prizeName[$k]}\" width=\"16\" height=\"16\"> ";
      }
      $f = $f << 1;
    }
    // 쓰러뜨린 괴수 리스트
    $f = 1;
    $max = -1;
    $nameList = "";
    for($k = 0; $k < $init->monsterNumber; $k++) {
      if($monsters & $f) {
        $nameList .= "[{$init->monsterName[$k]}] ";
        $max = $k;
      }
      $f = $f << 1;
    }
    if($max != -1) {
      $prizeList .= "<img src=\"{$init->monsterImage[$max]}\" alt=\"{$nameList}\" width=\"16\" height=\"16\"> ";
    }
    return $prizeList;
  }
  //------------------------------------------------------------------

  //---------------------------------------------------
  // 지형 관련 데이터 생성
  //---------------------------------------------------
  function landString($l, $lv, $x, $y, $mode, $comStr) {
    global $init;
    $point = "({$x},{$y})";
    $naviExp = "''";

    if($x < $init->islandSize / 2)
      $naviPos = 0;
    else
      $naviPos = 1;

    switch($l) {
    case $init->landSea:
      switch($lv) {
      case 1:
        // 얕은 여울
        $image = 'land14.gif';
        $naviTitle = '얕은 여울';
        break;
      default:
        // 바다
        $image = 'land0.gif';
        $naviTitle = '바다';
      }
      break;
    case $init->landWaste:
      // 황무지
      if($lv == 1) {
        $image = 'land13.gif'; // 착탄점
      } else {
        $image = 'land1.gif';
      }
      $naviTitle = '황무지';
      break;
    case $init->landPlains:
      // 평지
      $image = 'land2.gif';
      $naviTitle = '평지';
      break;
    case $init->landForest:
      // 숲
      if($mode == 1) {
        $image = 'land6.gif';
        $naviText= "{$lv}{$init->unitTree}";
      } else {
        // 방문자일 경우 나무 수를 숨김
        $image = 'land6.gif';
      }
      $naviTitle = '숲';
      break;
    case $init->landTown:
      // 마을
      $p; $n;
      if($lv < 30) {
        $p = 3;
        $naviTitle = '작은 마을';
      } else if($lv < 100) {
        $p = 4;
        $naviTitle = '마을';
      } else {
        $p = 5;
        $naviTitle = '도시';
      }
      $image = "land{$p}.gif";
      $naviText = "{$lv}{$init->unitPop}";
      break;
    case $init->landFarm:
      // 농장
      $image = 'land7.gif';
      $naviTitle = '농장';
      $naviText = "{$lv}0{$init->unitPop}규모";
      break;
    case $init->landFactory:
      // 공장
      $image = 'land8.gif';
      $naviTitle = '공장';
      $naviText = "{$lv}0{$init->unitPop}규모";
      break;
    case $init->landBase:
      if($mode == 0 || $mode == 2) {
        // 방문자일 경우 숲으로 보이게 함
        $image = 'land6.gif';
        $naviTitle = '숲';
      } else {
        // 미사일 기지
        $level = Util::expToLevel($l, $lv);
        $image = 'land9.gif';
        $naviTitle = '미사일 기지';
        $naviText = "레벨 {$level} / 경험치 {$lv}";
      }
      break;
    case $init->landSbase:
      // 해저 기지
      if($mode == 0 || $mode == 2) {
        // 방문자일 경우 바다로 보이게 함
        $image = 'land0.gif';
        $naviTitle = '바다';
      } else {
        $level = Util::expToLevel($l, $lv);
        $image = 'land12.gif';
        $naviTitle = '해저 기지';
        $naviText = "레벨 {$level} / 경험치 {$lv}";
      }
      break;
    case $init->landDefence:
      // 해저 기지
      $image = 'land10.gif';
      $naviTitle = '해저 기지';
      break;
    case $init->landHaribote:
      // 위장 방위기지
      $image = 'land10.gif';
      if($mode == 0 || $mode == 2) {
        // 방문자일 경우 해저 기지로 보이게 함
        $naviTitle = '해저 기지';
      } else {
        $naviTitle = '위장 방위기지';
      }
      break;
    case $init->landOil:
      // 해저 유전
      $image = 'land16.gif';
      $naviTitle = '해저 유전';
      break;
    case $init->landMountain:
      // 산
      if($lv > 0) {
        $image = 'land15.gif';
        $naviTitle = '채굴장';
        $naviText = "{$lv}0{$init->unitPop}규모";
      } else {
        $image = 'land11.gif';
        $naviTitle = '산';
      }
      break;
    case $init->landMonument:
      // 기념비
      $image = $init->monumentImage[$lv];
      $naviTitle = '기념비';
      $naviText = $init->monumentName[$lv];
      break;
    case $init->landMonster:
      // 괴수
      $monsSpec = Util::monsterSpec($lv);
      $special = $init->monsterSpecial[$monsSpec['kind']];
      $image = $init->monsterImage[$monsSpec['kind']];
      $naviTitle = '괴수';

      // 경화 중
      if((($special == 3) && (($this->islandTurn % 2) == 1)) ||
         (($special == 4) && (($this->islandTurn % 2) == 0))) {
        // 경화 중
        $image = $init->monsterImage2[$monsSpec['kind']];
      }
      $naviText = "괴수{$monsSpec['name']}(체력{$monsSpec['hp']})";
    }

    if($mode == 1 || $mode == 2) {
      print "<a href=\"javascript: void(0);\" onclick=\"ps($x,$y)\" onkeypress=\"ps($x,$y)\">";
      $naviText = "{$comStr}\\n{$naviText}";
    }
    print "<img src=\"{$image}\" width=\"32\" height=\"32\" alt=\"{$point} {$naviTitle} {$comStr}\" onMouseOver=\"Navi({$naviPos},'{$image}', '{$naviTitle}', '{$point}', '{$naviText}', {$naviExp});\" onMouseOut=\"NaviClose(); return false\">";

    // 좌표 설정 닫기
    if($mode == 1 || $mode == 2)
      print "</a>";
  }
}
//--------------------------------------------------------------------
class HakoIO {
  var $islandTurn;	// 턴 수
  var $islandLastTime;	// 최종 업데이트 시각
  var $islandNumber;	// 섬 총수
  var $islandNextID;	// 다음에 할당할 섬 ID
  var $islands;		// 전체 섬 정보를 저장
  var $idToNumber;
  var $idToName;

  //---------------------------------------------------
  // 전체 섬 데이터 읽기
  // 'mode'가 바뀔 수 있으므로 $cgi를 참조로 받음
  //---------------------------------------------------
  function readIslandsFile(&$cgi) {
    global $init;
    $num = $cgi->dataSet['ISLANDID'];

    $fileName = "{$init->dirName}/hakojima.dat";
    if(!is_file($fileName)) {
      return false;
    }
    $fp = fopen($fileName, "r");
    Util::lockr($fp);
    $this->islandTurn     = chop(fgets($fp, READ_LINE));
    $this->islandLastTime = chop(fgets($fp, READ_LINE));
    $this->islandNumber   = chop(fgets($fp, READ_LINE));
    $this->islandNextID   = chop(fgets($fp, READ_LINE));

    $GLOBALS['ISLAND_TURN'] = $this->islandTurn;
      
    // 턴 처리 판정
    $now = time();
    if((DEBUG && (strcmp($cgi->dataSet['mode'], 'debugTurn') == 0)) ||
       (($now - $this->islandLastTime) >= $init->unitTime)) {
      $cgi->mode = $data['mode'] = 'turn';
      $num = -1;
    }
    for($i = 0; $i < $this->islandNumber; $i++) {
      $this->islands[$i] = $this->readIsland($fp, $num);
      $this->idToNumber[$this->islands[$i]['id']] = $i;
    }
    Util::unlock($fp);
    fclose($fp);
    return true;
  }
  //---------------------------------------------------
  // 섬 하나 읽기
  //---------------------------------------------------
  function readIsland($fp, $num) {
    global $init;
    $name     = chop(fgets($fp, READ_LINE));
    list($name, $owner, $monster) = split(",", $name);
    $name = Util::toUtf8($name);
    $owner = Util::toUtf8($owner);
    $id       = chop(fgets($fp, READ_LINE));
    $prize    = chop(fgets($fp, READ_LINE));
    $absent   = chop(fgets($fp, READ_LINE));
    $comment  = chop(fgets($fp, READ_LINE));
    list($comment, $comment_turn) = split(",", $comment);
    $comment = Util::toUtf8($comment);
    $password = chop(fgets($fp, READ_LINE));
    $money    = chop(fgets($fp, READ_LINE));
    $food     = chop(fgets($fp, READ_LINE));
    $pop      = chop(fgets($fp, READ_LINE));
    $area     = chop(fgets($fp, READ_LINE));
    $farm     = chop(fgets($fp, READ_LINE));
    $factory  = chop(fgets($fp, READ_LINE));
    $mountain = chop(fgets($fp, READ_LINE));

    $this->idToName[$id] = $name;
    
    if(($num == -1) || ($num == $id)) {
      $fp_i = fopen("{$init->dirName}/island.{$id}", "r");
      Util::lockr($fp_i);

      // 지형
      $offset = 4; // 한 쌍의 데이터가 몇 글자인지
      for($y = 0; $y < $init->islandSize; $y++) {
        $line = chop(fgets($fp_i, READ_LINE));
        for($x = 0; $x < $init->islandSize; $x++) {
          $l = substr($line, $x * $offset    , 2);
          $v = substr($line, $x * $offset + 2, 2);
          $land[$x][$y]      = hexdec($l);
          $landValue[$x][$y] = hexdec($v);
        }
      }
      
      // 계획
      for($i = 0; $i < $init->commandMax; $i++) {
        $line = chop(fgets($fp_i, READ_LINE));
        list($kind, $target, $x, $y, $arg) = split(",", $line);
        $command[$i] = array (
          'kind'   => $kind,
          'target' => $target,
          'x'      => $x,
          'y'      => $y,
          'arg'    => $arg,
          );
      }
      // 내부 게시판
      for($i = 0; $i < $init->lbbsMax; $i++) {
        $line = chop(fgets($fp_i, READ_LINE));
        $lbbs[$i] = Util::toUtf8($line);
      }
      Util::unlock($fp_i);
      fclose($fp_i);
    }
    return array(
      'name'     => $name,
      'owner'    => $owner,
      'id'       => $id,
      'prize'    => $prize,
      'absent'   => $absent,
      'comment'  => $comment,
      'comment_turn' => $comment_turn,
      'password' => $password,
      'money'    => $money,
      'food'     => $food,
      'pop'      => $pop,
      'area'     => $area,
      'farm'     => $farm,
      'factory'  => $factory,
      'mountain' => $mountain,
      'monster'  => $monster,
      'land'     => $land,
      'landValue'=> $landValue,
      'command'  => $command,
      'lbbs'     => $lbbs,
      );
  }
  //---------------------------------------------------
  // 전체 섬 데이터 쓰기
  //---------------------------------------------------
  function writeIslandsFile($num = 0) {
    global $init;
    $fileName = "{$init->dirName}/hakojima.dat";

    if(!is_file($fileName))
      touch($fileName);

    $fp = fopen($fileName, "w");
    Util::lockw($fp);
    fputs($fp, $this->islandTurn . "\n");
    fputs($fp, $this->islandLastTime . "\n");
    fputs($fp, $this->islandNumber . "\n");
    fputs($fp, $this->islandNextID . "\n");
    for($i = 0; $i < $this->islandNumber; $i++) {
      $this->writeIsland($fp, $num, $this->islands[$i]);
    }
    Util::unlock($fp);
    fclose($fp);
//    chmod($fileName, 0666);
  }
  //---------------------------------------------------
  // 섬 하나 쓰기
  //---------------------------------------------------
  function writeIsland($fp, $num, $island) {
    global $init;
    fputs($fp, $island['name'] . "," . $island['owner'] . "," . $island['monster'] . "\n");
    fputs($fp, $island['id'] . "\n");
    fputs($fp, $island['prize'] . "\n");
    fputs($fp, $island['absent'] . "\n");
    fputs($fp, $island['comment'] . "," . $island['comment_turn'] . "\n");
    fputs($fp, $island['password'] . "\n");
    fputs($fp, $island['money'] . "\n");
    fputs($fp, $island['food'] . "\n");
    fputs($fp, $island['pop'] . "\n");
    fputs($fp, $island['area'] . "\n");
    fputs($fp, $island['farm'] . "\n");
    fputs($fp, $island['factory'] . "\n");
    fputs($fp, $island['mountain'] . "\n");
    // 지형
    if(($num <= -1) || ($num == $island['id'])) {
      $fileName = "{$init->dirName}/island.{$island['id']}";

      if(!is_file($fileName))
        touch($fileName);

      $fp_i = fopen($fileName, "w");
      Util::lockw($fp_i);
      $land = $island['land'];
      $landValue = $island['landValue'];
  
      for($y = 0; $y < $init->islandSize; $y++) {
        for($x = 0; $x < $init->islandSize; $x++) {
          $l = sprintf("%02x%02x", $land[$x][$y], $landValue[$x][$y]);
          fputs($fp_i, $l);
        }
        fputs($fp_i, "\n");
      }

      // 계획
      $command = $island['command'];
      for($i = 0; $i < $init->commandMax; $i++) {
        $com = sprintf("%d,%d,%d,%d,%d\n",
                     $command[$i]['kind'],
                     $command[$i]['target'],
                     $command[$i]['x'],
                     $command[$i]['y'],
                     $command[$i]['arg']
                );
        fputs($fp_i, $com);
      }

      // 내부 게시판
      $lbbs = $island['lbbs'];
      for($i = 0; $i < $init->lbbsMax; $i++) {
        fputs($fp_i, $lbbs[$i] . "\n");
      }
      Util::unlock($fp_i);
      fclose($fp_i);
//      chmod($fileName, 0666);
    }
  }
  //---------------------------------------------------
  // 데이터 백업
  //---------------------------------------------------
  function backUp() {
    global $init;

    if($init->backupTimes <= 0)
      return;
    
    $tmp = $init->backupTimes - 1;
    $this->rmTree("{$init->dirName}.bak{$tmp}");
    for($i = ($init->backupTimes - 1); $i > 0; $i--) {
      $j = $i - 1;
      if(is_dir("{$init->dirName}.bak{$j}"))
        rename("{$init->dirName}.bak{$j}", "{$init->dirName}.bak{$i}");
    }
    if(is_dir("{$init->dirName}"))
      rename("{$init->dirName}", "{$init->dirName}.bak0");

    mkdir("{$init->dirName}", $init->dirMode);

    // 로그 파일만 복원
    for($i = 0; $i <= $init->logMax; $i++) {
      if(is_file("{$init->dirName}.bak0/hakojima.log{$i}"))
        rename("{$init->dirName}.bak0/hakojima.log{$i}", "{$init->dirName}/hakojima.log{$i}");
    }
    if(is_file("{$init->dirName}.bak0/hakojima.his"))
      rename("{$init->dirName}.bak0/hakojima.his", "{$init->dirName}/hakojima.his");
  }
  //---------------------------------------------------
  // 불필요한 디렉터리와 파일 삭제
  //---------------------------------------------------
  function rmTree($dirName) {
    if(is_dir("{$dirName}")) {
      $dir = opendir("{$dirName}/");
      while($fileName = readdir($dir)) {
        if(!(strcmp($fileName, ".") == 0 || strcmp($fileName, "..") == 0))
          unlink("{$dirName}/{$fileName}");
      }
      closedir($dir);
      rmdir($dirName);
    }
  }
}
//--------------------------------------------------------------------
class LogIO {
  var $logPool = array();
  var $secretLogPool = array();
  var $lateLogPool = array();
  
  //---------------------------------------------------
  // 로그 파일을 뒤로 밀기
  //---------------------------------------------------
  function slideBackLogFile() {
    global $init;
    for($i = $init->logMax - 1; $i >= 0; $i--) {
      $j = $i + 1;
      $s = "{$init->dirName}/hakojima.log{$i}";
      $d = "{$init->dirName}/hakojima.log{$j}";
      if(is_file($s)) {
        if(is_file($d))
           unlink($d);
        rename($s, $d);
      }
    }
  }
  //---------------------------------------------------
  // 최근 사건 출력
  //---------------------------------------------------
  function logFilePrint($num = 0, $id = 0, $mode = 0) {
    global $init;
    $fileName = $init->dirName . "/hakojima.log" . $num;
    if(!is_file($fileName)) {
      return;
    }
    $fp = fopen($fileName, "r");
    Util::lockr($fp);

    while($line = chop(fgets($fp, READ_LINE))) {
      list($m, $turn, $id1, $id2, $message) = split(",", $line, 5);
      if($m == 1) {
        if(($mode == 0) || ($id1 != $id)) {
          continue;
        }
        $m = "<strong>(비밀)</strong>";
      } else {
        $m = "";
      }
      if($id != 0) {
        if(($id != $id1) && ($id != $id2)) {
          continue;
        }
      }
      print "{$init->tagNumber_}턴{$turn}{$m}{$init->_tagNumber}:{$message}<br>\n";
    }
    Util::unlock($fp);
    fclose($fp);
  }
  //---------------------------------------------------
  // 발견 기록 출력
  //---------------------------------------------------
  function historyPrint() {
    global $init;
    $fileName = $init->dirName . "/hakojima.his";
    if(!is_file($fileName)) {
      return;
    }
    $fp = fopen($fileName, "r");
    Util::lockr($fp);

    $history = array();
    $k = 0;
    while($line = chop(fgets($fp, READ_LINE))) {
      array_push($history, $line);
      $k++;
    }
    for($i = 0; $i < $k; $i++) {
      list($turn, $his) = split(",", array_pop($history), 2);
      print "{$init->tagNumber_}턴{$turn}{$init->_tagNumber}:$his<br>\n";
    }
  }
  //---------------------------------------------------
  // 발견 기록 저장
  //---------------------------------------------------
  function history($str) {
    global $init;
    $fileName = "{$init->dirName}/hakojima.his";

    if(!is_file($fileName))
      touch($fileName);

    $fp = fopen($fileName, "a");
    Util::lockw($fp);
    fputs($fp, "{$GLOBALS['ISLAND_TURN']},{$str}\n");
    Util::unlock($fp);
    fclose($fp);
//    chmod($fileName, 0666);
    
  }
  //---------------------------------------------------
  // 발견 기록 로그 조정
  //---------------------------------------------------
  function historyTrim() {
    global $init;
    $fileName = "{$init->dirName}/hakojima.his";
    if(is_file($fileName)) {
      $fp = fopen($fileName, "r");
      Util::lockr($fp);

      $line = array();
      while($l = chop(fgets($fp, READ_LINE))) {
        array_push($line, $l);
        $count++;
      }
      Util::unlock($fp);
      fclose($fp);
      if($count > $init->historyMax) {

        if(!is_file($fileName))
          touch($fileName);

        $fp = fopen($fileName, "w");
        Util::lockw($fp);
        for($i = ($count - $init->historyMax); $i < $count; $i++) {
          fputs($fp, "{$line[$i]}\n");
        }
        Util::unlock($fp);
        fclose($fp);
//        chmod($fileName, 0666);
      }
    }
  }
  //---------------------------------------------------
  // 로그
  //---------------------------------------------------
  function out($str, $id = "", $tid = "") {
    array_push($this->logPool, "0,{$GLOBALS['ISLAND_TURN']},{$id},{$tid},{$str}");
  }
  //---------------------------------------------------
  // 비밀 로그
  //---------------------------------------------------
  function secret($str, $id = "", $tid = "") {
    array_push($this->secretLogPool,"1,{$GLOBALS['ISLAND_TURN']},{$id},{$tid},{$str}");
  }
  //---------------------------------------------------
  // 지연 로그
  //---------------------------------------------------
  function late($str, $id = "", $tid = "") {
    array_push($this->lateLogPool,"0,{$GLOBALS['ISLAND_TURN']},{$id},{$tid},{$str}");
  }
  //---------------------------------------------------
  // 로그 쓰기
  //---------------------------------------------------
  function flush() {
    global $init;
    $fileName = "{$init->dirName}/hakojima.log0";

    if(!is_file($fileName))
      touch($fileName);

    $fp = fopen($fileName, "w");
    Util::lockw($fp);

    // 전부 역순으로 써넣기
    if(!empty($this->secretLogPool)) {
      for($i = count($this->secretLogPool) - 1; $i >= 0; $i--) {
        fputs($fp, "{$this->secretLogPool[$i]}\n");
      }
    }
    if(!empty($this->lateLogPool)) {
      for($i = count($this->lateLogPool) - 1; $i >= 0; $i--) {
        fputs($fp, "{$this->lateLogPool[$i]}\n");
      }
    }
    if(!empty($this->logPool)) {
      for($i = count($this->logPool) - 1; $i >= 0; $i--) {
        fputs($fp, "{$this->logPool[$i]}\n");
      }
    }
    Util::unlock($fp);
    fclose($fp);
//    chmod($fileName, 0666);
  }    
}

//--------------------------------------------------------------------
class Util {
  //---------------------------------------------------
  // 자금 표시
  //---------------------------------------------------
  function aboutMoney($money = 0) {
    global $init;
    if($init->moneyMode) {
      if($money < 500) {
        return "약 500{$init->unitMoney}미만";
      } else {
        return "약 " . round($money / 1000) . "000" . $init->unitMoney;
      }
    } else {
      return $money . $init->unitMoney;
    }
  }
  //---------------------------------------------------
  // 경험치에서 기지 레벨을 산출
  //---------------------------------------------------
  function expToLevel($kind, $exp) {
    global $init;
    if($kind == $init->landBase) {
      // 미사일 기지
      for($i = $init->maxBaseLevel; $i > 1; $i--) {
        if($exp >= $init->baseLevelUp[$i - 2]) {
          return $i;
        }
      }
      return 1;
    } else {
      // 해저 기지
      for($i = $init->maxSBaseLevel; $i > 1; $i--) {
        if($exp >= $init->sBaseLevelUp[$i - 2]) {
          return $i;
        }
      }
      return 1;
    }
  }
  //---------------------------------------------------
  // 괴수의 종류, 이름, 체력을 산출
  //---------------------------------------------------
  function monsterSpec($lv) {
    global $init;
    // 종류
    $kind = (int)($lv / 10);
    // 이름
    $name = $init->monsterName[$kind];
    // 체력
    $hp = $lv - ($kind * 10);
    return array ( 'kind' => $kind, 'name' => $name, 'hp' => $hp );
  }
  //---------------------------------------------------
  // 섬 이름에서 번호를 산출
  //---------------------------------------------------
  function  nameToNumber($hako, $name) {
    // 전체 섬에서 찾기
    for($i = 0; $i < $hako->islandNumber; $i++) {
      if(strcmp($name, "{$hako->islands[$i]['name']}") == 0) {
        return $i;
      }
    }
    // 찾지 못한 경우
    return -1;
  }
  //---------------------------------------------------
  // 비밀번호 체크
  //---------------------------------------------------
  function checkPassword($p1 = "", $p2 = "") {
    global $init;

    // null 체크
    if(empty($p2))
      return false;

    // 마스터 비밀번호 체크
    if(strcmp($init->masterPassword, $p2) == 0)
      return true;

    if(strcmp($p1, Util::encode($p2)) == 0)
      return true;
    
    return false;
  }
  //---------------------------------------------------
  // 비밀번호 인코딩
  //---------------------------------------------------
  function encode($s) {
    global $init;
    if($init->cryptOn) {
      return crypt($s, 'h2');
    } else {
      return $s;
    }
  }
  //---------------------------------------------------
  // 0부터 num - 1까지 난수 생성
  //---------------------------------------------------
  function random($num = 0) {
    if($num <= 1) return 0;
    return mt_rand(0, $num - 1);
  }
  //---------------------------------------------------
  // 내부 게시판 메시지를 하나 앞으로 이동
  //---------------------------------------------------
  function slideBackLbbsMessage(&$lbbs, $num) {
    global $init;
    array_splice($lbbs, $num, 1);
    $lbbs[$init->lbbsMax - 1] = '0>>';
  }
  //---------------------------------------------------
  // 내부 게시판 메시지를 하나 뒤로 이동
  //---------------------------------------------------
  function slideLbbsMessage(&$lbbs) {
    array_pop($lbbs);
    array_unshift($lbbs, $lbbs[0]);
  }
  //---------------------------------------------------
  // 무작위 좌표 생성
  //---------------------------------------------------
  function makeRandomPointArray() {
    global $init;
    $rx = $ry = array();
    for($i = 0; $i < $init->islandSize; $i++)
      for($j = 0; $j < $init->islandSize; $j++)
        $rx[$i * $init->islandSize + $j] = $j;

    for($i = 0; $i < $init->islandSize; $i++)
      for($j = 0; $j < $init->islandSize; $j++)
        $ry[$j * $init->islandSize + $i] = $j;
    

    for($i = $init->pointNumber; --$i;) {
      $j = Util::random($i + 1);
      if($i != $j) {
        $tmp = $rx[$i];
        $rx[$i] = $rx[$j];
        $rx[$j] = $tmp;
          
        $tmp = $ry[$i];
        $ry[$i] = $ry[$j];
        $ry[$j] = $tmp;
      }
    }
    return array($rx, $ry);
  }
  //---------------------------------------------------
  // 무작위 섬 순서 생성
  //---------------------------------------------------
  function randomArray($n = 1) {
    // 초기값
    for($i = 0; $i < $n; $i++) {
      $list[$i] = $i;
    }

    // 섞기
    for($i = 0; $i < $n; $i++) {
      $j = Util::random($n - 1);
      if($i != $j) {
        $tmp = $list[$i];
        $list[$i] = $list[$j];
        $list[$j] = $tmp;
      }
    }
    return $list;
  }
  //---------------------------------------------------
  // 계획를 앞으로 이동
  //---------------------------------------------------
  function slideFront(&$command, $number = 0) {
    global $init;
    // 각각 이동
    array_splice($command, $number, 1);

    // 마지막에 자금 확보 계획 추가
    $command[$init->commandMax - 1] = array (
      'kind'   => $init->comDoNothing,
      'target' => 0,
      'x'      => 0,
      'y'      => 0,
      'arg'    => 0
      );
  }
  //---------------------------------------------------
  // 계획를 뒤로 이동
  //---------------------------------------------------
  function slideBack(&$command, $number = 0) {
    global $init;
    // 각각 이동
    if($number == count($command) - 1)
      return;

    for($i = $init->commandMax - 1; $i >= $number; $i--) {
      $command[$i] = $command[$i - 1];
    }
  }


  //---------------------------------------------------
  // 문자열을 UTF-8 출력용으로 정리한다
  //---------------------------------------------------
  function isUtf8($str) {
    return ($str === '' || preg_match('//u', $str));
  }
  function toUtf8($str) {
    if($str === '' || Util::isUtf8($str)) {
      return $str;
    }
    if(function_exists('iconv')) {
      $conv = @iconv('CP949', 'UTF-8//IGNORE', $str);
      if($conv !== false && $conv !== '') return $conv;
      $conv = @iconv('EUC-KR', 'UTF-8//IGNORE', $str);
      if($conv !== false && $conv !== '') return $conv;
      $conv = @iconv('SJIS-win', 'UTF-8//IGNORE', $str);
      if($conv !== false && $conv !== '') return $conv;
      $conv = @iconv('Shift_JIS', 'UTF-8//IGNORE', $str);
      if($conv !== false && $conv !== '') return $conv;
    }
    return $str;
  }
  function substrUtf8($str, $start = 0, $length = 0) {
    $str = Util::toUtf8($str);
    if($length == 0) return '';
    if(function_exists('mb_substr')) {
      return mb_substr($str, $start, $length, 'UTF-8');
    }
    $chars = preg_split('//u', $str, -1, PREG_SPLIT_NO_EMPTY);
    if($chars === false) {
      return substr($str, $start, $length);
    }
    return implode('', array_slice($chars, $start, $length));
  }
  //---------------------------------------------------
  // 파일 잠금 처리(쓰기 시)
  //---------------------------------------------------
  function lockw($fp) {
    set_file_buffer($fp, 0);
    if(!flock($fp, LOCK_EX)) {
      fclose($fp);
      Error::lockFail();
    }
    rewind($fp);
  }
  //---------------------------------------------------
  // 파일 잠금 처리(읽기 시)
  //---------------------------------------------------
  function lockr($fp) {
    set_file_buffer($fp, 0);
    if(!flock($fp, LOCK_SH)) {
      fclose($fp);
      Error::lockFail();
    }
    rewind($fp);
  }
  //---------------------------------------------------
  // 파일 잠금 해제
  //---------------------------------------------------
  function unlock($fp) {
    flock($fp, LOCK_UN);
  }
}
class Cgi {
  var $mode = "";
  var $dataSet = array();
  //---------------------------------------------------
  // POST, GET 데이터 취득
  //---------------------------------------------------
  function parseInputData() {
    global $init;

    $this->mode = $_POST['mode'];
    if(!empty($_POST)) {
      while(list($name, $value) = each($_POST)) {
//        $value = Util::sjis_convert($value);
        // 반각 가나가 있으면 전각으로 변환하여 반환
//        $value = i18n_ja_jp_hantozen($value,"KHV");
        $value = Util::toUtf8($value);
        $value = str_replace(",", "", $value);
        if($init->stripslashes == true) {
          $this->dataSet["{$name}"] = stripslashes($value);
        } else {
          $this->dataSet["{$name}"] = $value;
        }
      }
    }
    if(!empty($_GET['Sight'])) {
      $this->mode = "print";
      $this->dataSet['ISLANDID'] = $_GET['Sight'];
    }
    if(!empty($_GET['target'])) {
      $this->mode = "targetView";
      $this->dataSet['ISLANDID'] = $_GET['target'];
    }
    if($_GET['mode'] == "conf") {
      $this->mode = "conf";
    }
    if($this->mode == "turn") {
      // 이 단계에서 mode에 turn이 설정되는 것은 부정 접근인 경우뿐이므로 초기화
      $this->mode = '';
    }
    $this->dataSet["ISLANDNAME"] = Util::substrUtf8($this->dataSet["ISLANDNAME"], 0, 16);
    $this->dataSet["MESSAGE"] = Util::substrUtf8($this->dataSet["MESSAGE"], 0, 60);
    $this->dataSet["LBBSMESSAGE"] = Util::substrUtf8($this->dataSet["LBBSMESSAGE"], 0, 60);
  }
  function lastModified() {
    global $init;

    // Last Modified 헤더 출력
/*
    if($this->mode == "Sight") {
      $fileName = "{$init->dirName}/island.{$this->dataSet['ISLANDID']}";
    } else {
      $fileName = "{$init->dirName}/hakojima.dat";
    }
*/
    $fileName = "{$init->dirName}/hakojima.dat";
    $time_stamp = filemtime($fileName);
    $time = gmdate("D, d M Y G:i:s", $time_stamp);
    header ("Last-Modified: $time GMT");
    $this->modifiedSinces($time_stamp);
  }
  function modifiedSinces($time) {
    $modsince = $_SERVER['HTTP_IF_MODIFIED_SINCE'];

    $ms = gmdate("D, d M Y G:i:s", $time) . " GMT";
    if($modsince == $ms)
      // RFC 822
      header ("HTTP/1.1 304 Not Modified\n");

    $ms = gmdate("l, d-M-y G:i:s", $time) . " GMT";
    if($modsince == $ms)
      // RFC 850
      header ("HTTP/1.1 304 Not Modified\n");

    $ms = gmdate("D M j G:i:s Y", $time);
    if($modsince == $ms)
      // ANSI C's asctime() format
      header ("HTTP/1.1 304 Not Modified\n");
  }
  //---------------------------------------------------
  // COOKIE 취득
  //---------------------------------------------------
  function getCookies() {
    if(!empty($_COOKIE)) {
      while(list($name, $value) = each($_COOKIE)) {
        $value = Util::toUtf8($value);
        switch($name) {
        case "OWNISLANDID":
          $this->dataSet['defaultID'] = $value;
          break;
        case "OWNISLANDPASSWORD":
          $this->dataSet['defaultPassword'] = $value;
          break;
        case "TARGETISLANDID":
          $this->dataSet['defaultTarget'] = $value;
          break;
        case "LBBSNAME":
          $this->dataSet['defaultName'] = $value;
          break;
        case "POINTX":
          $this->dataSet['defaultX'] = $value;
          break;
        case "POINTY":
          $this->dataSet['defaultY'] = $value;
          break;
        case "COMMAND":
          $this->dataSet['defaultKind'] = $value;
          break;
        case "DEVELOPEMODE":
          $this->dataSet['defaultDevelopeMode'] = $value;
          break;
        case "SKIN":
          $this->dataSet['defaultSkin'] = $value;
          break;
        }
      }
    }
  }
  //---------------------------------------------------
  // COOKIE 생성
  //---------------------------------------------------
  function setCookies() {
    $time = time() + 30 * 86400; // 현재 + 30일 유효

    // Cookie 설정 및 POST로 입력된 데이터로 Cookie에서 취득한 데이터 업데이트
    if($this->dataSet['ISLANDID'] && $this->mode == "owner") {
      setcookie("OWNISLANDID",$this->dataSet['ISLANDID'], $time);
      $this->dataSet['defaultID'] = $this->dataSet['ISLANDID'];
    }
    if($this->dataSet['PASSWORD']) {
      setcookie("OWNISLANDPASSWORD",$this->dataSet['PASSWORD'], $time);
      $this->dataSet['defaultPassword'] = $this->dataSet['PASSWORD'];
    }
    if($this->dataSet['TARGETID']) {
      setcookie("TARGETISLANDID",$this->dataSet['TARGETID'], $time);
      $this->dataSet['defaultTarget'] = $this->dataSet['TARGETID'];
    }
    if($this->dataSet['LBBSNAME']) {
      setcookie("LBBSNAME",$this->dataSet['LBBSNAME'], $time);
      $this->dataSet['defaultName'] = $this->dataSet['LBBSNAME'];
    }
    if($this->dataSet['POINTX']) {
      setcookie("POINTX",$this->dataSet['POINTX'], $time);
      $this->dataSet['defaultX'] = $this->dataSet['POINTX'];
    }
    if($this->dataSet['POINTY']) {
      setcookie("POINTY",$this->dataSet['POINTY'], $time);
      $this->dataSet['defaultY'] = $this->dataSet['POINTY'];
    }
    if($this->dataSet['COMMAND']) {
      setcookie("COMMAND",$this->dataSet['COMMAND'], $time);
      $this->dataSet['defaultKind'] = $this->dataSet['COMMAND'];
    }
    if($this->dataSet['DEVELOPEMODE']) {
      setcookie("DEVELOPEMODE",$this->dataSet['DEVELOPEMODE'], $time);
      $this->dataSet['defaultDevelopeMode'] = $this->dataSet['DEVELOPEMODE'];
    }
    if($this->dataSet['SKIN']) {
      setcookie("SKIN",$this->dataSet['SKIN'], $time);
      $this->dataSet['defaultSkin'] = $this->dataSet['SKIN'];
    }
  }
}


//--------------------------------------------------------------------
class Main {

  function execute() {
    $hako = new Hako;
    $cgi = new Cgi;
    
    $cgi->parseInputData();
    $cgi->getCookies();
    if(!$hako->readIslands($cgi)) {
      HTML::header($cgi->dataSet);
      Error::noDataFile();
      HTML::footer();
      exit();
    }
    $cgi->setCookies();
    $cgi->lastModified();

    if($cgi->dataSet['DEVELOPEMODE'] == "java") {
      $html = new HtmlJS;
      $com = new MakeJS;
    } else {
      $html = new HtmlMap;
      $com = new Make;
    }
    switch($cgi->mode) {
    case "turn":
      $turn = new Turn;
      $html = new HtmlTop;
      $html->header($cgi->dataSet);
      $turn->turnMain($hako, $cgi->dataSet); 
      $html->main($hako, $cgi->dataSet); // 턴 처리 후 메인 페이지 열기
      $html->footer();
      break;
    case "owner":
      $html->header($cgi->dataSet);
      $html->owner($hako, $cgi->dataSet);
      $html->footer();
      break;
    case "command":
      $html->header($cgi->dataSet);
      $com->commandMain($hako, $cgi->dataSet);
      $html->footer();
      break;
      
    case "new":
      $html->header($cgi->dataSet);
      $com->newIsland($hako, $cgi->dataSet);
      $html->footer();
      break;
    case "comment":
      $html->header($cgi->dataSet);
      $com->commentMain($hako, $cgi->dataSet);
      $html->footer();
      break;
      
    case "print":
      $html->header($cgi->dataSet);
      $html->visitor($hako, $cgi->dataSet);
      $html->footer();
      break;
    case "targetView":
      $html->header($cgi->dataSet);
      $html->printTarget($hako, $cgi->dataSet);
      $html->footer();
      break;
    case "change":
      $html->header($cgi->dataSet);
      $com->changeMain($hako, $cgi->dataSet);
      $html->footer();
      break;
    case "ChangeOwnerName":
      $html->header($cgi->dataSet);
      $com->changeOwnerName($hako, $cgi->dataSet);
      $html->footer();
      break;
    case "lbbs":
      $lbbs = new Make;
      $html->header($cgi->dataSet);
      $lbbs->localBbsMain($hako, $cgi->dataSet);
      $html->footer();
      break;
      
    case "skin":
      $html = new HtmlSetted;
      $html->header($cgi->dataSet);
      $html->setSkin();
      $html->footer();
      break;
    case "conf":
      $html = new HtmlTop;
      $html->header($cgi->dataSet);
      $html->regist($hako);
      $html->footer();
      break;
      
    default: 
      $html = new HtmlTop;
      $html->header($cgi->dataSet);
      $html->main($hako, $cgi->dataSet);
      $html->footer();
    }
    exit();
  }
}
$start = new Main;
$start->execute();
?>