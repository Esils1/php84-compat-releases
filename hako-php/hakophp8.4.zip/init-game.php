<?php
if (!isset($versionInfo)) { $versionInfo = isset($GLOBALS['versionInfo']) ? $GLOBALS['versionInfo'] : ''; }
if (!isset($HwarFlg)) { $HwarFlg = 0; }
if (!isset($_hako_fh)) { $_hako_fh = array(); }
if (!function_exists('hako_open')) {
  function hako_open($name, $spec) {
    global $_hako_fh;
    $mode = 'r';
    $path = $spec;
    if (substr($path, 0, 2) === '>>') { $mode = 'a'; $path = substr($path, 2); }
    elseif (substr($path, 0, 1) === '>') { $mode = 'w'; $path = substr($path, 1); }
    elseif (substr($path, 0, 1) === '<') { $mode = 'r'; $path = substr($path, 1); }
    $_hako_fh[$name] = @fopen($path, $mode);
    return $_hako_fh[$name];
  }
  function hako_close($name) {
    global $_hako_fh;
    if (isset($_hako_fh[$name]) && $_hako_fh[$name]) { fclose($_hako_fh[$name]); }
  }
  function hako_getline($name) {
    global $_hako_fh;
    if (!isset($_hako_fh[$name]) || !$_hako_fh[$name]) { return false; }
    return fgets($_hako_fh[$name]);
  }
  function hako_write($name, $data) {
    global $_hako_fh;
    if (!isset($_hako_fh[$name]) || !$_hako_fh[$name]) { return false; }
    return fwrite($_hako_fh[$name], $data);
  }
  function hako_cmp($a, $b) {
    if ($a == $b) { return 0; }
    return ($a < $b) ? -1 : 1;
  }
  function hako_reorder($array, $idx) {
    $out = array();
    foreach ($idx as $i) { if (isset($array[$i])) { $out[] = $array[$i]; } }
    return $out;
  }
  function hako_pick($array, $keys) {
    $out = array();
    foreach ($keys as $key) { $out[] = isset($array[$key]) ? $array[$key] : null; }
    return (count($keys) == 1) ? $out[0] : $out;
  }
  function hako_idx($array, $idx) {
    return isset($array[$idx]) ? $array[$idx] : null;
  }
}
//----------------------------------------------------------------------
// 모형정원 제도 ver2. 30
// 게임 설정 모듈
// 사용 조건, 사용 방법등은, qhako-readme.txt 파일을 참조
//----------------------------------------------------------------------
// 구상의 모형정원  (ver5. 53)
//----------------------------------------------------------------------

//----------------------------------------------------------------------
// 각종 설정치
// (이 이후의 부분의 각 설정치를, 적절한 값으로 변경해 주세요)
//----------------------------------------------------------------------
//----------------------------------------
// 게임의 진행이나 파일 등
//----------------------------------------
// 탑 페이지에 표시하는 로그의 턴수
$HtopLogTurn = 10;

// 로그 파일 보관 유지 턴수
$HlogMax = 10;

// 백업을 무엇 턴 걸러서 취할까
$HbackupTurn = 10;

// 백업을 몇회분 남길까
$HbackupTimes = 5;

// 발견 로그 보관 유지행수
$HhistoryMax = 10;

// 날씨 로그 보관 유지행수(행수의 지정 밖에 할 수 없습니다)
$HWeatherMax = 40;

// 방폐 커멘드 자동 입력 턴수
$HgiveupTurn = 9999;

// write open 의 retry 회수
$HretryCount = 1500;

//----------------------------------------
// 부정행위 방지 관계
//----------------------------------------

// 호스트 나토리 이득 모드(호스트명은 현재 사용하고 있습니다)
//  --> 0 : $ENV{'REMOTE_HOST'} 으로 취득할 수 있는 경우
//  --> 1 : gethostbyaddr 로 취득할 수 있는 경우
$get_remotehost = 1;

// COOKIE에 의한 ID체크를 할까? (0:하지 않는,1:한다)
// 「한다」로 하면, 동일 PC로 복수의 도을 관리할 때, COOKIE를 삭제하지 않으면 다른 도의 개발 화면 에 들어갈 수 없게 됩니다.
// 간이 중복 대책인 이유입니다만, 도 마다 브라우저를 바꾸는 것으로 곧바로나인 체해지고 있습니다(/_<. )
$checkID = 0;

//COOKIE에 의한 「이미지의 로컬 설정」도 체크해? (0:하지 않는,1:한다)
$checkImg = 0;

// COOKIE 체크(위의 2개의 설정)를 면제하는 도의 ID
// 예：@freepass = (2, 7, 12);
$freepass = array();
// 액세스 로그를 취할까? (0:취하지 않는,1:개발 화면에 들어갈 때와 자원 거래시,2:탑 페이지)
$HtopAxes = 1;
// 1으로 했을 경우, 이하를 설정
// 로그 파일명
$HaxesLogfile = './axes.php';
// 최대 기록 건수
$HaxesMax = 100;

// 타인으로부터 자금을 안보이게 할까
// 0 안보인다
// 1 보인다
// 2 100의 위로 컷
$HhideMoneyMode = 2;

// 패스워드의 암호화(0이라면 암호화하지 않는, 1이라고 암호화한다)
$cryptOn = 1;

//----------------------------------------
// 관광자 통신(로컬 게시판)
//----------------------------------------

// 사용할지 어떨지(0:사용하지 않는,1:사용한다)
$HuseLbbs = 1;

// IP표시
// 1 때는 로컬 게시판, 도작성 때 등에 IP를 표시한다. 마스터, 도주, 관광자도 차별 없게 표시
$Hlipdisp = 0;

// 로컬 게시판의 패스워드 인증
// 다른 도의 사용자가 기입할 때 패스워드 확인의 유무(0:무,1:유)
$HlbbsAuth = 1;

// 로컬 게시판을 패스워드 인증하는 경우의 설정
// 익명 발언(관광객 선택)을 허가할까(0:금지,1:허가)
$HlbbsAnon = 0;

// 로컬 게시판을 패스워드 인증하는 경우의 설정
// 발언에 발언자의 이름을 표시할까(0:표시하지 않는,1:표시한다)
$HlbbsSpeaker = 1;

// 정지 로그를 1개화할까? (0:하지 않는 1:좌표 있어 2:좌표 없음)
$HlogOmit2 = 1;

//----------------------------------------
// 자금, 식량등의 설정치와 단위
//----------------------------------------
// 최대 자금
$MaxMoney = 99999;

// 최대 식량 비축
$MaxFood = 99999;

// 최대 자원(원유, 광석, 병기) 비축
$MaxSigen = 9999;

// 돈의 단위
$HunitMoney = '억엔';

// 식량의 단위
$HunitFood = '00톤';

// 광석의 단위
$HunitOre = '톤';

// 원유의 단위
$HunitOil = '만 배럴';

// 병기의 단위
$HunitWeapon = '만 톤';

// 인구의 단위
$HunitPop = '00명';

// 넓이의 단위
$HunitArea = '00만평';

// 나무의 수의 단위
$HunitTree = '00개';

// 나무의 단위 당의 판매가
$HtreeValue = 5;

// 이름 변경의 설정
$HcostChangeName = 500;

// 인구 1단위 당의 식량 소비료
$HeatenFood = 0.2;

// 우주 공장, 우주 농장은, 우주인구의 몇배의 규모분이 가동할까?
$HspaceEfficiency = 5; # 5배

// 우주 공장, 우주 농장의 가동하고 있는 천명 규모 근처의 지상 수입(억)
$HspaceIncome = 5;

//----------------------------------------
// 외관 관계
//----------------------------------------

// <BODY>태그의 옵션
$htmlBody = 'BGCOLOR="#EEFFFF"';
// 배경 이미지을 지정하는경우. 이미지은 모형정원의 이미지 폴더에 넣어주세요. 로컬 지정하고있는경우엔 이미지 배포해주세요.
//$htmlBody = 'BGCOLOR="#EEFFFF" BACKGROUND="kabe.gif"';

$htmlBgColor = 'BGCOLOR="#EEFFFF"';

// 게임의 타이틀 문자 자유롭게 변경해 상관하지 않습니다.
$Htitle = '구상의 모형정원';
$Htitle2 = $versionInfo;

// 태그
// 타이틀 문자?
$HtagTitle_ = '<span class="title">';
$HtagTitle2_= '<span class="title2">';
$H_tagTitle = '</span>';

// 큰 문자
$HtagBig_ = '<span class="big">';
$H_tagBig = '</span>';

// 도의 이름 등
$HtagName_ = '<span class="islName">';
$H_tagName = '</span>';

// 얇아진 도의 이름
$HtagName2_ = '<span class="islName2">';
$H_tagName2 = '</span>';

// 순위의 번호 등
$HtagNumber_ = '<span class="number">';
$H_tagNumber = '</span>';

// 순위표의 보고
$HtagTH_ = '<span class="head">';
$H_tagTH = '</span>';

// 개발 계획의 이름
$HtagComName_ = '<span class="command">';
$H_tagComName = '</span>';

// 재해
$HtagDisaster_ = '<span class="disaster">';
$H_tagDisaster = '</span>';

// 로컬 게시판, 관광자가 쓴 문자
$HtagLbbsSS_ = '<span class="lbbsSS">';
$H_tagLbbsSS = '</span>';

// 로컬 게시판, 도주가 쓴 문자
$HtagLbbsOW_ = '<span class="lbbsOW">';
$H_tagLbbsOW = '</span>';

// 통상의 문자색
$HnormalColor_ = '<span class="normal">';
$H_normalColor = '</span>';

// 순위표, 셀의 속성
$HbgTitleCell	= 'class=TitleCell';	# 순위표견 방편
$HbgSubTCell	= 'class=SubTCell';		# 순위표 서브표제
$HbgNumberCell	= 'class=NumberCell';	# 순위표 순위
$HbgNameCell	= 'class=NameCell';		# 순위표 도의 이름
$HbgInfoCell	= 'class=InfoCell';		# 순위표 도의 정보
$HbgCommentCell	= 'class=CommentCell';	# 순위표 코멘트란?
$HbgInputCell	= 'class=InputCell';	# 개발 계획 폼
$HbgMapCell		= 'class=MapCell';		# 개발 계획 지도
$HbgCommandCell	= 'class=CommandCell';	# 개발 계획 입력이 끝난 계획
$HbgLbbsCell	= 'class=LbbsCell';		# 관광자 통신 표시란

//----------------------------------------
// 기지의 경험치
//----------------------------------------

// 경험치의 최대치
$HmaxExpPoint = 250;

// 레벨의 최대치
$maxBaseLevel = 6;  # 미사일 기지
$maxSBaseLevel = 4; # 해저 기지

// 경험치가 몇으로 레벨업인가
$baseLevelUp = array(20, 60, 120, 200, 250);# 미사일 기지
$sBaseLevelUp = array(50, 200, 250);# 해저 기지

if($HwarFlg){
	$maxBaseLevel  = 9;
	$maxSBaseLevel = 6;
	$baseLevelUp  = array(10, 30, 50, 70, 100, 150, 200, 250);
	$sBaseLevelUp = array(20, 60, 120, 200, 250);
}

// 방위 시설의 자폭 해저 방위 시설도 포함된다
// 괴수에게 밟혔을 때 자폭한다면 1, 하지 않으면 0
$HdBaseAuto = 1;

//----------------------------------------
// 재해
//----------------------------------------
// 재해 반감기를 도입할까?　한다 2(TOP에 반감중으로 표시) 한다 1 하지않는다 0
// 백의 위가 짝수때, 재해율이 약반감합니다.
$Hdishangen = 0;

// 통상 재해 발생율(확률은 0.1%단위)
$HdisEarthquake = 5;  # 지진
$HdisTsunami    = 15; # 해일
$HdisTyphoon    = 20; # 태풍
$HdisMeteo      = 15; # 운석
$HdisHugeMeteo  = 4;  # 거대 운석
$HdisEruption   = 10; # 분화
$HdisFire       = 10; # 화재
$HdisMaizo      = 10; # 매장금
$HdisAkasio     = 30; # 적조
$HdisVGHarvest  = 10; # 대풍작
$HdisGHarvest   = 50; # 풍작
$HdisBHarvest   = 40; # 흉작
$HdisAEruption  = 4;  # 재분화

$HdisPirate     = 20; # 해적선
$HdisTreasureS  = 1;  # 보물선

$HdisTinka      = 9; # 온천에 의한 지반침하(0.01%단위)

// 해저계(깊은 바다의 건축물 모두) 한계치(%), 더 이상 증가하면 시 이노라가 나옵니다.
$HdisKLimit = 50;

// 인구 1만명 당의 발생율
$HdisPollution    = 1;  # 공해(0.01%단위)
$HmaxdisPollution = 24; # 공해 최대(0.1%단위)
$HdisCrime        = 10; # 범죄(0.01%단위)(인구 이외의 요소도 있습니다)

// 지반침하
$HdisFallBorder = 90; # 안전 한계의 넓이(Hex수)
$HdisFalldown   = 30; # 그 넓이를 넘었을 경우의 확률

// 우주 공장 1개 마다 거대 운석이 발생하는 확률(0.0001%단위)
$HdisSHugeMeteo = 25; # ×개발 면적

// 기후
$WeatherName = array('맑음','갬','흐림','안개','비','폭우');
$WeatherIcon = array('weather/kaisei.gif','weather/hare.gif','weather/kumori.gif','weather/noumu.gif','weather/ame.gif','weather/ooame.gif');
// 코멘트의 라벨 이미지 (4미사용. 추가에는 hako-main.php의 개조가 필요) by ShibaAni
$HlabelName = array('괴수 출현시에 미사일 원호를 거부한다<>괴수 출현시에 미사일 원호를 허가한다','괴수 배틀로의 원정 수입을 거부 ','자금원조 해줍니다','자금원조 해주세요','예비 1');
$HlabelImage = array('label00_2.gif<>label00_1.gif','label01.gif','label02.gif','label03.gif','label04.gif');
// 괴수
$HdisMonsBorder1 = 1000; # 인구 기준 1(괴수 레벨 1)
$HdisMonsBorder2 = 2500; # 인구 기준 2(괴수 레벨 2)
$HdisMonsBorder3 = 4000; # 인구 기준 3(괴수 레벨 3)
$HdisMonsBorder4 = 6000; # 인구 기준 4(괴수 레벨 4)
$HdisMonsBorder5 = 8000; # 인구 기준 5(괴수 레벨 5)
$HdisMonster     = 2.6;  # 단위면적 근처의 출현율(0.01%단위)

// 단위면적 근처의 매립 이노라 , 갯바람배의 출현치(적을 정도 확률이 높은, 서바이벌 모드, $HdisMonster=0의 경우는 값에 관계없이 출현하지 않는다)
$HdisMonsterU    = 20000;

// 우주에서의 괴수의 출현치(적을 정도 확률이 높은, $HdisMonster=0의 경우는 값에 관계없이 출현하지 않는다)
// 개발 면적 ÷ $HdisSpaceMonster × 100 = 출현율(%)　(매턴 이 확률로 마을계의 수만큼 판정)
$HdisSpaceMonster1 = 30000; # 괴수 있음
$HdisSpaceMonster2 = 10000; # 괴수 없음

// 해역에서의 괴수의 출현치(적을 정도 확률이 높은, $HdisMonster=0의 경우는 값에 관계없이 출현하지 않는다)
// 1 ÷ $HdisSeaMonster × 100 = 출현율(%)　(매턴 이 확률로 바다의 수만큼 판정)
$HdisSeaMonster = 8000;

// 종류
$HmonsterNumber  = 36; 

// 각 기준에 대해 나오는 괴수수와 종류
$HmonsterL1Num = 2;
$HmonsterL2Num = 5;
$HmonsterL3Num = 7;
$HmonsterL4Num = 11;
$HmonsterL5Num = 12;
$HmonsterL1 = array(1,2);
$HmonsterL2 = array(1,2,3,4,5);
$HmonsterL3 = array(1,2,3,4,5,6,7);
$HmonsterL4 = array(1,3,4,5,6,7,8, 9,10,24,26);
$HmonsterL5 = array(3,4,5,6,7,8,9,10,19,24,26,27);
// 우주 괴수
$HmonsterS = array(32,33,34,35);
// 최저 체력, 체력의 폭, 특수 능력, 망친 후의 지형, 경험치, 시체의 가격
                   // 0  1  2  3  4  5  6  7  8  9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 35
$HmonsterBHP     = array( 2, 1, 1, 3, 2, 1, 4, 5, 2, 3, 6, 2, 2, 1, 2, 2, 2, 2, 5, 8, 5, 3, 2, 2, 2, 1, 3, 6, 2, 2, 5, 1, 2, 4, 2, 6);
$HmonsterDHP     = array( 3, 2, 2, 2, 2, 0, 2, 2, 2, 2, 3, 3, 3, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3, 2, 2, 3, 3, 4, 2, 2, 0, 3, 2, 2, 2, 3);
$HmonsterSpecial = array( 2, 0, 3, 0, 1, 2, 4, 0, 2, 0, 1, 5, 5, 6, 7, 2, 0, 0, 8, 0, 7, 7, 8, 0, 0, 5, 2, 0, 0, 0, 9, 5, 0, 1, 2, 0);
$HmonsterDestroy = array( 1, 1, 1, 1, 1, 1, 1, 1, 1, 0,15, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0);
$HmonsterExp     = array(10, 5,7,12,15,10,20,30,100,35,50,10,20,15,40,15,15,20,80,70,60,40,12,20,90,10,30,10,10,10,60,10,15,20,25,40);
                   // 0    1    2    3    4    5    6    7    8    9
$HmonsterValue   = array(  0, 400, 500,1000, 800, 300,1500,2000,1000,2000,
                   3000, 100,3000,1000,2000,1000,1200,1500,6000,4000,
                   3500,2000, 200,4000, 300, 100,2000, 500,1000,1000,
                   5000,9999,2000,3000,3500,5000);

// 특수 능력의 내용은,
// 0 특별히 이루어
// 1 발이 빠르다 (최대 2보 걷는다)
// 2 켤레가 매우 빠르다(최대 몇보 걸을까 불명)
// 3 홀수 턴은 방어
// 4 짝수 턴은 방어
// 5 항상 방어이지만 25%로 맞는다
// 6 명령 처리보다 먼저 이동(0-1보)
// 7 명령 처리보다 먼저 이동(최대 몇보 걸을까 불명)
// 8 주위 1에 헥스에 안개를 낸다
// 9 회복한다(매턴 MAX)

// 이름(도중에 변경하면 랭킹이 이상해집니다)
$HmonsterName = 
    array(
     '메카 이노라',     # 0(인조)
     '이노라',         # 1
     '산지라',       # 2
     '레드 이노라',   # 3
     '다크 이노라',   # 4
     '이노라 고스트', # 5
     '쿠지라',         # 6
     '킹 이노라',   # 7
     '메탈 이노라',   # 8
     '바다 이노라',     # 9
     '데빌 이노라',   # 10
     '메카지라',       # 11(인조)
 '엔시트 이노라', # 12(지질 조사)
     '이다텐',       # 13(오염)
     '래빗 이노라', # 14(오염)
     '지바쿠 레이',     # 15(고스트가 변화)
     '매립 이노라', # 16(바다에 랜덤)
     '타임보칸',   # 17(미사일수)
     '반격 이노라',     # 18(미사일수)
     '아슈라',       # 19(미사일수)
     '스페이스 이노라', # 20(미사일수)
     '바다 고스트',   # 21(미사일수)
    '그라테네스 이노라',# 22(인조)
     '카네곤',       # 23
     '리치 이노라',   # 24
     '해저 메카 이노라', # 25
     '미채 이노라',     # 26
     '분열 이노라',     # 27
     '테루테루 이노라', # 28
     '테루테루 이노라(역)',   # 29
     '회복 이노라',     # 30
    '골드 고스트',# 31
     '초록 우주 괴수',   # 32
     '노랑 우주 괴수',   # 33
     '빨강 우주 괴수',   # 34
     '파랑 우주 괴수'    # 35
);

// 괴수 배틀용?
$HmonsterSP      = array( 7, 4, 1, 7, 7, 3, 2, 7, 6, 0,10, 6, 6, 5, 5, 5, 0, 8, 7, 0, 9, 5, 0, 8, 0, 6, 5, 5, 0, 0,11, 8, 0, 7, 7, 9);# 특수
                   // 0  1  2  3  4  5  6  7  8  9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 35
$HmonsterSTR     = array(10, 7, 7,10, 7, 2, 8,12, 4, 7,13, 3,11, 5, 7, 3, 8,12,15, 9, 9, 9, 7, 5,10,10, 7, 7, 7, 9,11,11, 7, 9,11,11);# 공격
$HmonsterDEF     = array( 2, 3, 5, 2, 2, 0, 5, 3, 7, 3, 1, 5, 5, 0, 0, 0, 3, 5, 0, 3, 3, 1, 3, 2, 3, 5, 1, 1, 3, 3, 3, 5, 3, 3, 3, 3);# 방어
$HmonsterAGI     = array( 6, 5, 2, 3, 9,14, 4, 5,11, 5, 5, 1, 2,15,17,19, 6,11, 5, 9,15,20, 5,10,10, 7,15,20, 5, 6, 9,15, 5, 6, 6,14);# 회피
$HmonsterSKL     = array( 2, 7, 6, 5, 9, 9, 7, 4, 7, 7,10, 1, 5,10,13,13, 8,12,12, 9,10,16, 7,10,10, 7,12,10, 7, 7, 9,12, 7, 7, 8,12);# 명중
       // 합계(참고)  20 22 20 20 27 25 24 24 29 22 29 10 23 30 37 35 25 40 32 30 37 46 22 27 33 29 35 38 22 25 32 43 22 25 28 40

// 괴수 배틀 진화용
$HmonsterGRP     = array( 0, 0, 1, 3, 2, 2, 1, 3, 1, 4, 3, 1, 1, 2, 2, 2, 4, 5, 3, 4, 4, 2, 5, 5, 5, 5, 4, 5, 3, 3, 4, 1, 6, 6, 6, 6);# 그룹
$HmonsterCLS     = array( 0, 0, 1, 3, 1, 2, 2, 4, 4, 1, 5, 3, 5, 3, 4, 2, 2, 6, 6, 3, 6, 5, 1, 5, 2, 3, 4, 4, 1, 2, 5, 6, 1, 2, 3, 4);# 계급
$HmonsterSEI     = array( 0, 1, 4, 2, 4, 5, 4, 2, 4, 4, 4, 2, 1, 5, 5, 5, 4, 3, 3, 0, 5, 3, 4, 5, 4, 4, 5, 5, 2, 2, 4, 1, 2, 4, 3, 5);# 성장

// 성장
// 0 보통
// 1 성장률이 높다
// 2 성장률이 낮다
// 3 공격의 성장이 좋다
// 4 수비가 오른다
// 5 회피, 명중의 성장이 좋다

// 이미지 파일
$HmonsterImage =
    array(
     'monster7.gif',
     'monster0.gif',
     'monster5.gif', # 2
     'monster1.gif',
     'monster2.gif',
     'monster8.gif',
     'monster6.gif', # 6
     'monster3.gif',
     'monster9.gif',
     'monster10.gif',
     'monster11.gif', # 10
     'monster12.gif',
     'monster13.gif',
     'monster14.gif',
     'monster15.gif', # 14
     'monster16.gif',
     'monster17.gif',
     'monster18.gif',
     'monster19.gif', # 18
     'monster20.gif',
     'monster21.gif',
     'monster22.gif',
     'monster23.gif', # 22
     'monster24.gif',
     'monster25.gif',
     'monster26.gif',
     'land1.gif',     # 황무지
     'monster27.gif',
     'monster28.gif',
     'monster29.gif',
     'monster30.gif', # 30
     'monster31.gif',
     'cmonster1.gif',
     'cmonster2.gif',
     'cmonster3.gif', # 34
     'cmonster4.gif'
     );

// 이미지 파일 그 2(방어중)
$HmonsterImage2 =
  array('','','monster4.gif','','','','monster4.gif','','','','','','','','','','','','','','','','','','','','','','','','','','','','','');
 // 0  1         2       3  4  5        6        7  8  9  10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 35

//----------------------------------------
// 유전
//----------------------------------------
// 유전의 수입(양)
$HoilMoney = 400;

// 유전의 고갈 확률
$HoilRatio = 40;

//----------------------------------------
// 기념비
//----------------------------------------
// 몇종류 있을까
$HmonumentNumber = 19;

// 통상 미사일을 효과없이 하는 경우 1
$HmonumentMissile = 1;

// 로켓 개시 위치
$HmonumentRocket = 11;

// 이름
$HmonumentName = 
    array(
     '모노리스',   #0
     '평화 기념비',
     '싸움의 비',
     '염가 기념비',
     '예비 기념비',
     '예비 기념비', #5
     '예비 기념비',
     '예비 기념비',
     '재해의 비',
     '순금의 비',
     '괴수 기념비', #10
     '로켓 기념비',
     '로켓대(LV1)',
     '로켓대(LV2)',
     '로켓대(LV3)',
     '로켓대(LV4)', #15
     '로켓대(LV5)',
     '로켓대(LV6)',
     '로켓대(LV7)'
    );

// 이미지 파일
$HmonumentImage = 
    array(
     'monument0.gif',
     'monument0.gif',
     'monument0.gif',
     'monument0.gif',
     'monument0.gif',
     'monument0.gif',
     'monument0.gif',
     'monument0.gif',
     'monumentP.gif',
     'monumentG.gif',
     'monumentM.gif',
     'monument3.gif',
     'monument4.gif',
     'monument4.gif',
     'monument4.gif',
     'monument4.gif',
     'monument4.gif',
     'monument4.gif',
     'monument4.gif'
     );

//----------------------------------------
// 해저 기념비
//----------------------------------------
// 몇종류 있을까
$HsmonumentNumber = 2;

// 이름
$HsmonumentName = 
    array(
     '해저 기념비',
     '해저 기념비'
    );

// 이미지 파일
$HsmonumentImage = 
    array(
     'smonument0.gif',
     'smonument1.gif'
     );

//----------------------------------------
// 상관계
//----------------------------------------
// 턴배를 무엇 턴 마다 낼까
$HturnPrizeUnit = 100;

// 상의 이름
$Hprize = array('턴배','번영상','초번영상','궁극 번영상','평화상',
			'초평화상','궁극 평화상','재난상','초재난상','궁극 재난상',
			'우주상','구상 이노라 상');

// 부문상을 무엇 턴 마다 낼까
$HturnPrizeVarious = 20;

// 부문상의 가산 순위점
$HturnPrizePoint = 50;

// 부문상의 수
$HturnPrizeNumber = 14;

// 상의 이름
$HprizeV = array('','농업왕','공업왕','상업왕','수산 왕',
			'삼림왕','미사일왕','위장 방위 시설왕','괴수왕','석유왕',
			'재해왕','선박왕','기념비왕','우주왕','원예왕');


//----------------------------------------------------------------------
//기호에 의해 설정하는 부분은 이상
//----------------------------------------------------------------------
// 이 이후의 스크립트는, 변경되는 것을 상정하고 있었습니다만,
// 만져도 괜찮습니다.
// 커멘드의 이름, 가격 등은 알기 쉽다고 생각합니다.
//----------------------------------------------------------------------

//----------------------------------------
// 배계
//----------------------------------------
//              적수이탐거룩한 보물어어어룡류부객풍

$HshipHP    = array( 3, 2, 4, 2, 3, 3, 1, 1, 1, 2, 3, 4, 1, 2, 2, 6);# HP
$HshipKAI   = array( 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0);# 회복?
$HshipSP    = array( 1, 0, 1, 1, 0, 1, 2, 2, 0, 0, 0, 2, 0, 0, 0, 1);# 속력(괴수와 같다)
$HshipMATK  = array( 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0);# 대 괴공격력
$HshipSATK  = array( 1, 0, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);# 대  함상 공격격력
$HshipEX    = array(10, 5,12, 4,40,35,20,30, 2, 4, 6,60,10,10, 5, 5);# 경험치
$HshipMoney = array( 0,50,50,100,0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);# 유지비
$HshipFood  = array( 0, 0, 0,100,0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);# 유지 식량
$HshipMoneyE= array( 0,50,50,100,0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);# 유지비 원정
$HshipFoodE = array( 0, 0, 0,100,0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);# 유지 식량 원정

$HshipSell =array(2000, 800,1500, 600,4000,
			 2000,1000,9999, 300, 700,
			 1200,1000,2000,2000,1200,1000);

// 지령
$Hshiporder = array('특수','이동','방어','후퇴','공격');
// 이름
$HshipName = array('해적선','바다짐승 소탕정','이지스 함','해저 탐사배', '예비',
			'예비','유령선','보물선','소형 어선','중형 어선',
			'대형 어선','익룡','빙산','부부바위','호화 여객선',
			'바람배');

// 이미지 파일
$HshipImage = array( 'ship01.gif','ship02.gif','ship03.gif','ship04.gif','ship05.gif',
				'ship06.gif','land0.gif','ship08.gif','ship09.gif','ship10.gif',
				'ship11.gif','ship12.gif','ship13.gif','ship14.gif','ship15.gif',
				'ship16');

// 바다계 지형인가 어떤가 체크한다(-1대책으로 최후는 0으로 하는 것)
// 1이상해계, 2배, 3 방파제
//           0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9
$HseaChk = array(1,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0, # 19
			0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0, # 39
			0,0,0,0,0,0,0,0,0,3,3,0,0,0,0,0,0,0,0,0, # 59
			0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0, # 79
			0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0, # 99
			0,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2, #119
			2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,0);#139

//----------------------------------------
// 지하계
//----------------------------------------

$Hunderground = array('지하 공간','지하 출구','지하 사다리','지하','지하 도시',
				'지하 농장','지하 공장','지하 미사일 기지','지하 합성석유 공장');

$HugImage = array('ug.gif','ug_dokan.gif','ug_hasigo.gif','ug_road.gif','ug_tosi.gif',
			'ug_farm.gif','ug_fact.gif','ug_kiti.gif','ug_oil.gif');

$HugSpace  = 0;
$HugDokan  = 1;
$HugHasigo = 2;
$HugRoad   = 3;
$HugTosi   = 4;
$HugFarm   = 5;
$HugFact   = 6;
$HugKiti   = 7;
$HugOil    = 8;

//----------------------------------------
//  후지산
//----------------------------------------
$HfujiImage = array('fuji/fuji1.gif','fuji/fuji2.gif','fuji/fuji3.gif');
//----------------------------------------
//  우주 위성
//----------------------------------------
$HsEisei      = array('기상 위성','관측 위성','요격 위성','군사위성','방위 위성');
$HsEiseiImage = array('cosmo20.gif','cosmo21.gif','cosmo22.gif','cosmo23.gif','cosmo24.gif');
//----------------------------------------
// 주위 4 헥스의 좌표 0-60
//----------------------------------------

$ax = array(0, 1, 1, 1, 0,-1, 0, 1, 2, 2, 2, 1, 0,-1,-1,-2,-1,-1, 0,
		2, 2, 3, 3, 3, 2, 2, 1, 0,-1,-2,-2,-3,-2,-2,-1, 0, 1,
		2,3,3,4,4,4,3,3,2,1,0,-1,-2,-2,-3,-3,-4,-3,-3,-2,-2,-1,0,1);
$ay = array(0,-1, 0, 1, 1, 0,-1,-2,-1, 0, 1, 2, 2, 2, 1, 0,-1,-2,-2,
		-3,-2,-1, 0, 1, 2, 3, 3, 3, 3, 2, 1, 0,-1,-2,-3,-3,-3,
		-4,-3,-2,-1,0,1,2,3,4,4,4,4,4,3,2,1,0,-1,-2,-3,-4,-4,-4,-4);

//----------------------------------------------------------------------
// 각종 정수
//----------------------------------------------------------------------
// 지형 번호
$HlandSea      = 0;  # 해
$HlandWaste    = 1;  # 황무지
$HlandPlains   = 2;  # 평지
$HlandTown     = 3;  # 마을계
$HlandForest   = 4;  # 숲
$HlandFarm     = 5;  # 농장
$HlandFactory  = 6;  # 공장?
$HlandBase     = 7;  # 미사일 기지
$HlandDefence  = 8;  # 방위 시설
$HlandMountain = 9;  # 산
$HlandMonster  = 10; # 괴수?
$HlandSbase    = 11; # 해저 기지?
$HlandOil      = 12; # 해저 유전?
$HlandMonument = 13; # 기념비?
$HlandHaribote = 14; # 위장 방위 시설?
$HlandOsen     = 15; # 오염?
$HlandSlum     = 16; # 슬럼가?
$HlandTower    = 17; # 상업 빌딩?
$HlandSeisei   = 18; # 정제장
$HlandBank     = 19; # 은행?
$HlandStadium  = 20; # 스타디움?
$HlandAmusement = 21; # 유원지
$HlandCasino    = 22; # 카지노?
$HlandPark      = 23; # 공원
$HlandSchool    = 24; # 학교
$HlandDome      = 25; # 돔?
$HlandAirport   = 26; # 공항
$HlandFire      = 27; # 소방서?
$HlandWarp      = 28; # 전이 장치?
$HlandZoo       = 29; # 동물원
$HlandBigcity   = 30; # 대도시
$HlandExpo      = 31; # 박람회?
$HlandMegacity  = 32; # 거대 도시
$HlandMegatower = 33; # 거대 빌딩?
$HlandMegaFact  = 34; # 거대 공장?
$HlandDeathtrap = 35; # 데스트랩?
$HlandWindmill  = 36; # 풍차
$HlandMyhome    = 37; # 마이 홈?
$HlandWarpR     = 38; # 전이 저장장치
$HlandPort      = 39; # 항구
$HlandPolice    = 40; # 경찰서?
$HlandKInora    = 41; # 구상 이노라
$HlandTrump     = 42; # 트럼프
$HlandFlower    = 43; # 꽃
$HlandDokan     = 44; # 입구?
$HlandFuji      = 45; # 후지산
$HlandTcity     = 46; # 상업 도시?
$HlandMegaFarm  = 47; # 거대 농장?
$HlandHugecity  = 48; # 초거대 도시?
$HlandBreakwater= 49; # 방파제
$HlandSMonument = 50; # 해저 기념비?
$HlandHospital  = 51; # 병원

// 해역용
$HlandOcean     = 71; # 무인도(변경하는 경우 hako-mente.php도)
$HlandOPlayer   = 72; # 플레이어도
$HlandOmonster  = 73; #  monster(미사용)

// 바다계
$HlandPirate    = 101; # 해적선

$HlandMonsShip  = 102; # 바다짐승 소탕정
$HlandAegisShip = 103; # 이지스 함
$HlandProbeShip = 104; # 해저 탐사배

$HlandGhostShip = 107; # 유령선?
$HlandTreasureS = 108; # 보물선?
$HlandFishSShip = 109; # 소형 어선?
$HlandFishMShip = 110; # 중형 어선?
$HlandFishLShip = 111; # 대형 어선?
$HlandWingDragon= 112; # 익룡?
$HlandIceFloe   = 113; # 빙산
$HlandCoupleRock= 114; # 부부바위
$HlandTitanic   = 115; # 호화 여객선?
$HlandBalloonS  = 116; # 갯바람배

// 우주용?
$HlandEarth = 201; # 지구?
$HlandSunit = 202; # 우주 유닛?
$HlandSCity = 203; # 우주 도시?

$HlandSFarm    = 205; # 우주 농장?
$HlandSFactory = 206; # 우주 공장?
$HlandSpaceBase= 207; # 우주 미사일 기지?
$HlandSDefence = 208; # 우주 방위 시설?

$HlandSAEisei  = 210; # 우주 위성

// 커멘드
// 미사일과 함께 할 수 있는 것은0-19,90-
$HcommandDivido = 
	array(
	'개발,0,17',
	'건설,18,49',
	'미사일,50,65',
	'공격,66,89',
	'운영,90,109',
	'괴수,110,119',
	'우주,120,139',
	'해역,140,149'
	);
// 주의：스페이스는 들어갈 수  없게
// ○→	'개발, 0,10',  # 계획 번호 00~10
// ×→	'개발, 0  , 10  ',  # 계획 번호 00~10

// 계획 번호의 설정
// 정지계 9
$HcomPrepare  = 1; # 개간?
$HcomPrepare2 = 2; # 땅 고르기?
$HcomReclaim  = 3; # 매립
$HcomReclaim2 = 4; # 고속 매립?
$HcomDestroy  = 5; # 굴착?
$HcomSellTree = 6; # 벌채
$HcomSearch   = 7; # 지질 조사?
$HcomPioneer  = 8; # 이주
$HcomDestroy2 = 9; # 고속 굴착?

// 만드는 계 29
$HcomPlant    = 11; # 식림?
$HcomFarm     = 12; # 농장 건설?
$HcomFactory  = 13; # 공장 건설?
$HcomMountain = 14; # 채굴장 건설?
$HcomBank     = 15; # 은행
$HcomPresent  = 16; # 선물 건설

$HcomShipbuild	= 18; # 조선?
$HcomSMonument	= 20; # 해저 기념비 건설
$HcomBase		= 21; # 미사일 기지 건설
$HcomDbase		= 22; # 방위 시설 건설
$HcomSbase		= 23; # 해저 기지 건설?
$HcomMonument	= 24; # 기념비 건설

$HcomHaribote	= 25; # 위장 방위시설 설치?
$HcomScity		= 26; # 해저 도시 건설?
$HcomSFarm		= 27; # 해저 농장 건설?
$HcomTower		= 28; # 상업 빌딩 건설?
$HcomFire		= 29; # 소방서 건설
$HcomWarp		= 30; # 전이 장치 건설?
$HcomWindmill	= 31; # 풍차 설치
$HcomMyhome		= 32; # 마이 홈 설치 ?
$HcomDeathtrap	= 33; # 데스트랩 설치?
$HcomPort		= 34; # 항구 건설
$HcomPolice		= 35; # 경찰서 건설?
$HcomTrump		= 36; # 트럼프 설치?
$HcomFlower		= 37; # 꽃을 심는다?
$HcomBreakwater	= 38; # 방파제를 건설?
$HcomHospital	= 39; # 병원 건설

$HcomDokan		= 45; # 입구(지하) 건설?
$HcomUg			= 46; # 지하 건설?

// 공격계 24
$HcomMissileNM	= 50; # 미사일 발사
$HcomMissilePP	= 51; # PP미사일 발사
$HcomMissileSPP	= 52; # SPP미사일 발사?
$HcomMissileDM	= 53; # 확산 미사일 발사
$HcomMissileST	= 54; # ST미사일 발사?
$HcomMissileLD	= 55; # 지형 파괴 미사일 발사?
$HcomMissilePLD	= 56; # 파괴 PP미사일 발사
$HcomMissileRM	= 57; # 매립 미사일 발사
$HcomMissileSRM	= 58; # S매립 미사일 발사?
$HcomBioMissile	= 59; # 바이오 미사일 발사
$HcomMissileNCM	= 60; # 핵 미사일 발사?
$HcomMissileMGM	= 61; # 괴수 유도미사일 발사?
$HcomMissileGM	= 62; # 유도 미사일 발사?
$HcomMissileRNG	= 63; # 링 미사일 발사?


$Hcomcolony			= 69; # 콜로니 오토시?
$HcomSendMonster	= 70; # 괴수 파견?
$HcomManipulate		= 71; # 괴수 조작
$HcomSTManipulate	= 72; # ST괴수 조작
$HcomSpy			= 73; # 공작원
$HcomTeisatu		= 74; # 정찰
$HcomDummy			= 75; # 더미 명령
$HcomSSendMonster	= 76; # S괴수 파견?
$HcomShip			= 80; # 배지령 변경?
$HcomShipM			= 81; # 배전체 조작?

// 운영계 15
$HcomShipSell	= 92; # 배 매각
$HcomSell		= 93; # 식량 매각?
$HcomMoney		= 94; # 자금 원조?
$HcomFood		= 95; # 식량 원조?
$HcomPropaganda	= 96; # 유치 활동
$HcomDoNothing	= 97; # 자금 융통
$HcomPresentAid	= 98; # 선물 양도?
$HcomEmigration	= 99; # 이민
$HcomGiveup		= 100; # 도의 방폐
$HcomOreSell	= 101; # 광석 매각(원조)
$HcomOilSell	= 102; # 원유 매각(원조)
$HcomWeponSell	= 103; # 병기 매각(원조)
$HcomOreBuy		= 104; # 광석 구입
$HcomOilBuy		= 105; # 원유 구입?
$HcomWeponBuy	= 106; # 병기 구입?

// 괴수 배틀계 8 (모두 턴은 걸리지 않습니다)
$HcomMonsEgg	= 110; # 괴수 알 구입
$HcomMonsEsa	= 111; # 괴수에게 먹이 주기
$HcomMonsEnsei	= 112; # 괴수 원정
$HcomMonsTettai	= 113; # 괴수 후퇴
$HcomMonsEsaAid	= 114; # 괴수먹이 양도
$HcomMonsAid	= 115; # 괴수 양도?
$HcomMonsSell	= 116; # 괴수 매각?
$HcomMonsExer	= 117; # 괴수 모의 훈련?

// 우주 개발계?
$HcomSUnit		= 120; # 우주 유닛 건설?
$HcomSFood		= 121; # 우주 식량 발사?
$HcomSPioneer	= 122; # 우주 이주?
$HcomSBuild		= 123; # 우주 건설계
$HcomSpaceFarm	= 124; # 우주 농장 건설?
$HcomSFactory	= 125; # 우주 공장 건설?
$HcomSOccupy	= 126; # 우주 점령
$HcomSMissileGM	= 127; # 우주 유도 미사일 발사?
$HcomSpaceBase	= 128; # 우주 미사일 기지 건설?
$HcomSDestroy	= 129; # 우주 유닛 파괴?
$HcomSMissileMGM= 130; # 우주 괴수 유도?
$HcomSMissilePP	= 131; # 우주 PP미사일 발사?
$HcomSMissile	= 132; # 우주 미사일 발사?
$HcomSDbase		= 133; # 우주 방위 시설 건설?
$HcomSEisei		= 134; # 우주 위성 건설?

$HcomOMissileNM		= 140; # 해역 미사일?
$HcomOMissilePP		= 141; # 해역 PP미사일
$HcomOMissileSPP	= 142; # 해역 SPP미사일

// 자동 입력계, 방폐 4
$HcomAutoPrepare	= 184; # 전체 개간
$HcomAutoPrepare2	= 185; # 전체 땅 고르기?
$HcomAutoSellTree	= 186; # 전체 벌채?
$HcomAutoDelete		= 188; # 전체 커맨드 제거

// 특수 명령($HcommandTotal에는 포함하지 않는 것)
$HcomSpecialSPP	= 200;

// 계획의 이름과 가격
$HcomName[$HcomPrepare]  = '개간';
$HcomCost[$HcomPrepare]  = 5;
$HcomName[$HcomPrepare2] = '땅 고르기';
$HcomCost[$HcomPrepare2] = 100;
$HcomName[$HcomReclaim]  = '매립';
$HcomCost[$HcomReclaim]  = 150;
$HcomName[$HcomReclaim2] = '고속 매립';
$HcomCost[$HcomReclaim2] = 800;
$HcomName[$HcomDestroy]  = '굴착';
$HcomCost[$HcomDestroy]  = 200;
$HcomName[$HcomDestroy2]  = '고속 굴착';
$HcomCost[$HcomDestroy2]  = 800;
$HcomName[$HcomSearch]   = '지질 조사';
$HcomCost[$HcomSearch]   = 1000;
$HcomName[$HcomSellTree] = '벌채';
$HcomCost[$HcomSellTree] = 0;
$HcomName[$HcomPlant]    = '식림';
$HcomCost[$HcomPlant]    = 50;
$HcomName[$HcomBank]     = '은행 투자';
$HcomCost[$HcomBank]     = 1000;
$HcomName[$HcomPioneer]  = '이주';
$HcomCost[$HcomPioneer]  = -500;
$HcomName[$HcomFarm]     = '농장 건설';
$HcomCost[$HcomFarm]     = 20;
$HcomName[$HcomFactory]  = '공장 건설';
$HcomCost[$HcomFactory]  = 100;
$HcomName[$HcomMountain] = '채굴장 건설';
$HcomCost[$HcomMountain] = 300;
$HcomName[$HcomPresent]  = '선물 건설';
$HcomCost[$HcomPresent]  = 0;
$HcomName[$HcomPresentAid] = '선물 양도';
$HcomCost[$HcomPresentAid] = 0;
$HcomName[$HcomBase]     = '미사일 기지 건설';
$HcomCost[$HcomBase]     = 300;
$HcomName[$HcomDbase]    = '방위 시설 건설';
$HcomCost[$HcomDbase]    = 500;
$HcomName[$HcomSbase]    = '[해저] 기지 건설';
$HcomCost[$HcomSbase]    = 8000;
$HcomName[$HcomMonument] = '기념비 건설';
$HcomCost[$HcomMonument] = 9999;
$HcomName[$HcomSMonument] = '[해저] 기념비 건설';
$HcomCost[$HcomSMonument] = 19999;
$HcomName[$HcomHaribote] = '위장 방위시설 설피';
$HcomCost[$HcomHaribote] = 100;
$HcomName[$HcomScity]    = '[해저] 도시 건설';
$HcomCost[$HcomScity]    = 1000;
$HcomName[$HcomSFarm]    = '[해저] 농장 건설';
$HcomCost[$HcomSFarm]    = 600;
$HcomName[$HcomTower]    = '상업 빌딩 건설';
$HcomCost[$HcomTower]    = 400;
$HcomName[$HcomFire]     = '소방서 건설';
$HcomCost[$HcomFire]     = 600;
$HcomName[$HcomWindmill] = '풍차 설치';
$HcomCost[$HcomWindmill] = 3000;
$HcomName[$HcomMyhome]   = '마이 홈 설치';
$HcomCost[$HcomMyhome]   = 500;
$HcomName[$HcomPort]     = '항구 건설';
$HcomCost[$HcomPort]     = 800;
$HcomName[$HcomPolice]   = '경찰서 건설';
$HcomCost[$HcomPolice]   = 1000;
$HcomName[$HcomHospital] = '병원 건설';
$HcomCost[$HcomHospital] = 1000;
$HcomName[$HcomTrump]    = '트럼프 설치';
$HcomCost[$HcomTrump]    = 1500;
$HcomName[$HcomFlower]   = '꽃을 심는다';
$HcomCost[$HcomFlower]   = 100;
$HcomName[$HcomBreakwater]= '방파제 건설';
$HcomCost[$HcomBreakwater]= 300;
$HcomName[$HcomDokan]	= '입구(지하)건설';
$HcomCost[$HcomDokan]	= 1000;
$HcomName[$HcomUg]		= '[지하]건설';
$HcomCost[$HcomUg]		= 800;
$HcomName[$HcomShipbuild]  = '조선';
$HcomCost[$HcomShipbuild]  = 500;
$HcomName[$HcomManipulate] = '[괴수] 조작';
$HcomCost[$HcomManipulate] = 700;
$HcomName[$HcomSTManipulate] = 'ST괴수 조작';
$HcomCost[$HcomSTManipulate] = 1500;
$HcomName[$HcomSpy]          = '공작원 파견';
$HcomCost[$HcomSpy]          = 3800;
$HcomName[$HcomTeisatu]      = '정찰';
$HcomCost[$HcomTeisatu]      = 300;
$HcomName[$HcomWarp]         = '전이 장치 건설';
$HcomCost[$HcomWarp]         = 1800;
$HcomName[$HcomDeathtrap]    = '데스트랩 설치';
$HcomCost[$HcomDeathtrap]    = 350;
$HcomName[$Hcomcolony]       = '콜로니 오토시';
$HcomCost[$Hcomcolony]       = ($HwarFlg) ? 26000 : 34000;
$HcomName[$HcomBioMissile]   = '바이오 미사일 발사';
$HcomCost[$HcomBioMissile]   = 170;
$HcomName[$HcomMissileNM]    = '미사일 발사';
$HcomCost[$HcomMissileNM]    = 20;
$HcomName[$HcomMissilePP]    = 'PP 미사일 발사';
$HcomCost[$HcomMissilePP]    = 40;
$HcomName[$HcomMissileSPP]   = 'SPP 미사일 발사';
$HcomCost[$HcomMissileSPP]   = 50;
$HcomName[$HcomMissileRNG]   = '링 미사일 발사';
$HcomCost[$HcomMissileRNG]   = 60;
$HcomName[$HcomMissileST]    = 'ST 미사일 발사';
$HcomCost[$HcomMissileST]    = 150;
$HcomName[$HcomMissileLD]    = '지형 파괴 미사일 발사';
$HcomCost[$HcomMissileLD]    = 180;
$HcomName[$HcomSendMonster]  = '괴수 파견';
$HcomCost[$HcomSendMonster]  = 3000;
$HcomName[$HcomSSendMonster] = 'S괴수 파견';
$HcomCost[$HcomSSendMonster] = 6000;
$HcomName[$HcomMissileRM]    = '매립 미사일 발사';
$HcomCost[$HcomMissileRM]    = 100;
$HcomName[$HcomMissileSRM]   = 'S매립 미사일 발사';
$HcomCost[$HcomMissileSRM]   = ($HwarFlg) ? 800 : 3000;
$HcomName[$HcomMissileGM]    = '유도 미사일 발사';
$HcomCost[$HcomMissileGM]    = 1000;
$HcomName[$HcomMissileMGM]   = '괴수 유도 미사일 발사';
$HcomCost[$HcomMissileMGM]   = 1000;
$HcomName[$HcomMissileDM]    = '확산 미사일 발사';
$HcomCost[$HcomMissileDM]    = 30;
$HcomName[$HcomMissileNCM]   = '핵 미사일 발사';
$HcomCost[$HcomMissileNCM]   = ($HwarFlg) ? 6000 : 9800;
$HcomName[$HcomMissilePLD]   = '파괴 PP미사일 발사';
$HcomCost[$HcomMissilePLD]   = 200;
$HcomName[$HcomDummy]        = '더미 명령';
$HcomCost[$HcomDummy]        = 10;
$HcomName[$HcomShip]         = '배지령 변경';
$HcomCost[$HcomShip]         = 100;
$HcomName[$HcomShipM]        = '배전체 이동';
$HcomCost[$HcomShipM]        = 300;
$HcomName[$HcomDoNothing]    = '자금 융통';
$HcomCost[$HcomDoNothing]    = 0;
$HcomName[$HcomShipSell]     = '배 매각';
$HcomCost[$HcomShipSell]     = 0;
$HcomName[$HcomSell]         = '식량 매각';
$HcomCost[$HcomSell]         = -100;
$HcomName[$HcomOreSell]      = '광석 매각·원조';
$HcomCost[$HcomOreSell]      = 0;
$HcomName[$HcomOilSell]      = '원유 매각·원조';
$HcomCost[$HcomOilSell]      = 0;
$HcomName[$HcomWeponSell]    = '병기 매각·원조';
$HcomCost[$HcomWeponSell]    = 0;
$HcomName[$HcomOreBuy]       = '광석 구입';
$HcomCost[$HcomOreBuy]       = 2;
$HcomName[$HcomOilBuy]       = '원유 구입';
$HcomCost[$HcomOilBuy]       = 5;
$HcomName[$HcomWeponBuy]     = '병기 구입';
$HcomCost[$HcomWeponBuy]     = 24;
$HcomName[$HcomMoney]        = '자금 원조';
$HcomCost[$HcomMoney]        = 100;
$HcomName[$HcomFood]         = '식량 원조';
$HcomCost[$HcomFood]         = -100;
$HcomName[$HcomEmigration]   = '이민';
$HcomCost[$HcomEmigration]   = -100;
$HcomName[$HcomPropaganda]   = '유치 활동';
$HcomCost[$HcomPropaganda]   = 1000;
$HcomName[$HcomMonsEgg]      = '[괴수] 알 구입';
$HcomCost[$HcomMonsEgg]      = 3000;
$HcomName[$HcomMonsEsa]      = '[괴수] 먹이주기';
$HcomCost[$HcomMonsEsa]      = 500;
$HcomName[$HcomMonsEnsei]    = '[괴수] 원정';
$HcomCost[$HcomMonsEnsei]    = 500;
$HcomName[$HcomMonsTettai]   = '[괴수] 후퇴';
$HcomCost[$HcomMonsTettai]   = 0;
$HcomName[$HcomMonsEsaAid]   = '[괴수] 먹이 양도';
$HcomCost[$HcomMonsEsaAid]   = 0;
$HcomName[$HcomMonsAid]      = '[괴수] 양도';
$HcomCost[$HcomMonsAid]      = 0;
$HcomName[$HcomMonsSell]     = '[괴수] 매각';
$HcomCost[$HcomMonsSell]     = 0;
$HcomName[$HcomMonsExer]     = '[괴수] 모의 훈련';
$HcomCost[$HcomMonsExer]     = 500;

$HcomName[$HcomSUnit]		= '[우주] 유닛 건설';
$HcomCost[$HcomSUnit]		= 400;
$HcomName[$HcomSFood]		= '[우주] 식량 발사';
$HcomCost[$HcomSFood]		= 1000;
$HcomName[$HcomSPioneer]	= '[우주] 이주';
$HcomCost[$HcomSPioneer]	= 1000;
$HcomName[$HcomSBuild]		= '[우주] 건설계';
$HcomCost[$HcomSBuild]		= 1000;
$HcomName[$HcomSMissileGM]	= '[우주] 유도 미사일 발사';
$HcomCost[$HcomSMissileGM]	= 200;
$HcomName[$HcomSMissilePP]	= '[우주] PP미사일 발사';
$HcomCost[$HcomSMissilePP]	= 200;
$HcomName[$HcomSMissile]	= '[우주] 미사일 발사';
$HcomCost[$HcomSMissile]	= 300;
$HcomName[$HcomSMissileMGM]	= '[우주] 괴수 유도미사일 발사';
$HcomCost[$HcomSMissileMGM]	= 1400;
$HcomName[$HcomSOccupy]		= '[우주] 점령 ';
$HcomCost[$HcomSOccupy]		= 1000;
$HcomName[$HcomSpaceFarm]	= '[우주] 농장 건설';
$HcomCost[$HcomSpaceFarm]	= 500;
$HcomName[$HcomSFactory]	= '[우주] 공장 건설';
$HcomCost[$HcomSFactory]	= 1000;
$HcomName[$HcomSpaceBase]	= '[우주] 미사일 기지 건설';
$HcomCost[$HcomSpaceBase]	= 1000;
$HcomName[$HcomSDbase]		= '[우주] 방위 시설 건설';
$HcomCost[$HcomSDbase]		= 1000;
$HcomName[$HcomSEisei]		= '[우주] 위성 건설';
$HcomCost[$HcomSEisei]		= 2000;
$HcomName[$HcomSDestroy]	= '[우주] 유닛 파괴';
$HcomCost[$HcomSDestroy]	= 200;

$HcomName[$HcomOMissileNM]	= '[해역] 미사일';
$HcomCost[$HcomOMissileNM]	= 40;
$HcomName[$HcomOMissilePP]	= '[해역] PP미사일';
$HcomCost[$HcomOMissilePP]	= 50;
$HcomName[$HcomOMissileSPP]	= '[해역] SPP 미사일';
$HcomCost[$HcomOMissileSPP]	= 60;

$HcomName[$HcomGiveup]		= '도의 방폐';
$HcomCost[$HcomGiveup]		= 0;
$HcomName[$HcomAutoPrepare]	= '개간 자동 입력';
$HcomCost[$HcomAutoPrepare]	= 0;
$HcomName[$HcomAutoPrepare2]= '땅 고르기 자동 입력';
$HcomCost[$HcomAutoPrepare2]= 0;
$HcomName[$HcomAutoSellTree]= '벌채 자동 입력';
$HcomCost[$HcomAutoSellTree]= 0;
$HcomName[$HcomAutoDelete]	= '모든 계획을 취소';
$HcomCost[$HcomAutoDelete]	= 0;

1;