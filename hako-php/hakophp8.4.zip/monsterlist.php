<?php
if (!isset($_hako_fh)) { $_hako_fh = array(); }

if (!isset($GLOBALS['_hako_req_start'])) { $GLOBALS['_hako_req_start'] = microtime(true); }
if (!isset($GLOBALS['_hako_req_ru_start'])) { $GLOBALS['_hako_req_ru_start'] = function_exists('getrusage') ? getrusage() : null; }
if (!function_exists('hako_cpu_times')) {
function hako_cpu_times() {
    $startRu = isset($GLOBALS['_hako_req_ru_start']) ? $GLOBALS['_hako_req_ru_start'] : null;
    if (function_exists('getrusage') && is_array($startRu)) {
        $r = getrusage();
        $u0 = (isset($startRu['ru_utime.tv_sec']) ? $startRu['ru_utime.tv_sec'] : 0) + (isset($startRu['ru_utime.tv_usec']) ? $startRu['ru_utime.tv_usec'] : 0) / 1000000;
        $s0 = (isset($startRu['ru_stime.tv_sec']) ? $startRu['ru_stime.tv_sec'] : 0) + (isset($startRu['ru_stime.tv_usec']) ? $startRu['ru_stime.tv_usec'] : 0) / 1000000;
        $u1 = (isset($r['ru_utime.tv_sec']) ? $r['ru_utime.tv_sec'] : 0) + (isset($r['ru_utime.tv_usec']) ? $r['ru_utime.tv_usec'] : 0) / 1000000;
        $s1 = (isset($r['ru_stime.tv_sec']) ? $r['ru_stime.tv_sec'] : 0) + (isset($r['ru_stime.tv_usec']) ? $r['ru_stime.tv_usec'] : 0) / 1000000;
        $uti = max(0, $u1 - $u0);
        $sti = max(0, $s1 - $s0);
        return array(round($uti + $sti, 4), round($uti, 4), round($sti, 4));
    }
    $start = isset($GLOBALS['_hako_req_start']) ? $GLOBALS['_hako_req_start'] : (isset($_SERVER['REQUEST_TIME_FLOAT']) ? $_SERVER['REQUEST_TIME_FLOAT'] : microtime(true));
    $elapsed = microtime(true) - $start;
    if ($elapsed < 0) { $elapsed = 0; }
    return array(round($elapsed, 4), round($elapsed, 4), 0);
}
}
if (!function_exists('hako_open')) {
  function hako_open($name, $spec) {
    global $_hako_fh;
    $mode = 'r';
    $path = $spec;
    if (substr($path, 0, 2) === '>>') { $mode = 'a'; $path = substr($path, 2); }
    elseif (substr($path, 0, 1) === '>') { $mode = 'w'; $path = substr($path, 1); }
    elseif (substr($path, 0, 1) === '<') { $mode = 'r'; $path = substr($path, 1); }
    $_hako_fh[$name] = @fopen($path, $mode);
    return $_hako_fh[$name];
  }
  function hako_close($name) {
    global $_hako_fh;
    if (isset($_hako_fh[$name]) && $_hako_fh[$name]) { fclose($_hako_fh[$name]); }
  }
  function hako_getline($name) {
    global $_hako_fh;
    if (!isset($_hako_fh[$name]) || !$_hako_fh[$name]) { return false; }
    return fgets($_hako_fh[$name]);
  }
  function hako_write($name, $data) {
    global $_hako_fh;
    if (!isset($_hako_fh[$name]) || !$_hako_fh[$name]) { return false; }
    return fwrite($_hako_fh[$name], $data);
  }
  function hako_cmp($a, $b) {
    if ($a == $b) { return 0; }
    return ($a < $b) ? -1 : 1;
  }
  function hako_reorder($array, $idx) {
    $out = array();
    foreach ($idx as $i) { if (isset($array[$i])) { $out[] = $array[$i]; } }
    return $out;
  }
  function hako_pick($array, $keys) {
    $out = array();
    foreach ($keys as $key) { $out[] = isset($array[$key]) ? $array[$key] : null; }
    return (count($keys) == 1) ? $out[0] : $out;
  }
  function hako_idx($array, $idx) {
    return isset($array[$idx]) ? $array[$idx] : null;
  }
}
// #!/usr/bin/perl

//---------------------------------------------------------------------
//
//	구상의 모형정원 괴수 배틀용 일람표시
//
//	작성일 : 2001/09/16 V0. 101
//	작성자 : 라스티아
//
//	수정일 이력
//	2001/12/23 V0. 11 V3. 60에서의 괴수 추가에 대응했다.
//	2001/12/31 V0. 20 공통 설정부를 config.cgi로부터 수중에 넣도록(듯이) 했다.
//	2002/01/13 V0. 21 version4 대응.
//	2002/02/03 V0. 30 CSS를 별파일로부터 읽어들이도록(듯이) 했다.
//	2002/03/31 V0. 31 부하 경감과 전투 상대 표시.
//	2002/11/02 V0. 40 스타일 시트 근처를 개량, 괴수 추가
//	2003/09/24 V0. 50 구상의 모형정원 5 대응.
//---------------------------------------------------------------------
//	당스크립트는 이하를 바탕으로 작성했습니다
//
//	괴수 격퇴 포인트＋획득 상금 랭킹표시
//	작성자 : Watson
//---------------------------------------------------------------------

//---------------------------------------------------------------------
//	초기설정
//---------------------------------------------------------------------
// hako-init.php를 require
require_once "./hako-init.php";

// 화면의 「돌아온다」링크처(URL) $HbaseDir는 config.cgi로 지정..
$bye = "$HbaseDir/hako-main.php";

// 괴수의 능력을 원괴수 능력을 포함해 표시할 때는 1자능력만은 0
$Monshyouzi = 0;

//----------------------------
//HTML에 관한 설정
//----------------------------
// 브라우저의 타이틀 바의 명칭?
$title = '모형정원 제도 괴수 리스트';

// 화면의 색이나 배경의 설정(HTML)
$body = '<body>';

// 모두의 메세지(HTML 서식) 괴수 격퇴 랭킹용
$headKill = <<<EOF
<h2 class=head2>괴수 배틀 괴수 일람표</h2>
EOF;

$HbgTitleCell = 'class=TitleCell';
$HbgInfoCell = 'class=InfoCell';

//여기까지-------------------------------------------------------------

// 괴수명
$HmonsterName = 
    array(
     '메카 이노라',     # 0(인조)
     '이노라',         # 1
     '산지라',       # 2
     '레드 이노라',   # 3
     '다크 이노라',   # 4
     '이노라 고스트', # 5
     '쿠지라',         # 6
     '킹 이노라',   # 7
     '메탈 이노라',   # 8
     '바다 이노라',     # 9
     '데빌 이노라',   # 10
     '메카지라',       # 11(인조)
 '엔시트 이노라', # 12(지질 조사)
     '이다텐',       # 13(오염)
     '래빗 이노라', # 14(오염)
     '지바쿠 레이',     # 15(고스트가 변화)
     '매립 이노라', # 16(바다에 랜덤)
     '타임보칸',   # 17(미사일수)
     '반격 이노라',     # 18(미사일수)
     '아슈라',       # 19(미사일수)
     '스페이스 이노라', # 20(미사일수)
     '바다 고스트',   # 21(미사일수)
    '그라테네스 이노라',# 22(인조)
     '카네곤',       # 23
     '리치 이노라',   # 24
     '해저 메카 이노라', # 25
     '미채 이노라',     # 26
     '분열 이노라',     # 27
     '테루테루 이노라', # 28
     '테루테루 이노라(역)',   # 29
     '회복 이노라',     # 30
    '골드 고스트',# 31
     '초록 우주 괴수',   # 32
     '노랑 우주 괴수',   # 33
     '빨강 우주 괴수',   # 34
     '파랑 우주 괴수'    # 35
);

// 이미지 파일
$HmonsterImage =
    array(
     'monster7.gif',
     'monster0.gif',
     'monster5.gif', # 2
     'monster1.gif',
     'monster2.gif',
     'monster8.gif',
     'monster6.gif', # 6
     'monster3.gif',
     'monster9.gif',
     'monster10.gif',
     'monster11.gif', # 10
     'monster12.gif',
     'monster13.gif',
     'monster14.gif',
     'monster15.gif', # 14
     'monster16.gif',
     'monster17.gif',
     'monster18.gif',
     'monster19.gif', # 18
     'monster20.gif',
     'monster21.gif',
     'monster22.gif',
     'monster23.gif', # 22
     'monster24.gif',
     'monster25.gif',
     'monster26.gif',
     'land1.gif',     # 황무지
     'monster27.gif',
     'monster28.gif',
     'monster29.gif',
     'monster30.gif', # 30
     'monster31.gif',
     'cmonster1.gif',
     'cmonster2.gif',
     'cmonster3.gif', # 34
     'cmonster4.gif'
     );

// 괴수 배틀용
$HmonsterSP      = array( 7, 4, 1, 7, 7, 3, 2, 7, 6, 0,10, 6, 6, 5, 5, 5, 0, 8, 7, 0, 9, 5, 0, 8, 0, 6, 5, 5, 0, 0,11, 8, 0, 7, 7, 9);# 팅쇱
                   // 0  1  2  3  4  5  6  7  8  9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 35
$HmonsterSTR     = array(10, 7, 7,10, 7, 2, 8,12, 4, 7,13, 3,11, 5, 7, 3, 8,12,15, 9, 9, 9, 7, 5,10,10, 7, 7, 7, 9,11,11, 7, 9,11,11);# 뭉룐
$HmonsterDEF     = array( 2, 3, 5, 2, 2, 0, 5, 3, 7, 3, 1, 5, 5, 0, 0, 0, 3, 5, 0, 3, 3, 1, 3, 2, 3, 5, 1, 1, 3, 3, 3, 5, 3, 3, 3, 3);# 漑멩
$HmonsterAGI     = array( 6, 5, 2, 3, 9,14, 4, 5,11, 5, 5, 1, 2,15,17,19, 6,11, 5, 9,15,20, 5,10,10, 7,15,20, 5, 6, 9,15, 5, 6, 6,14);# 뀨흰
$HmonsterSKL     = array( 2, 7, 6, 5, 9, 9, 7, 4, 7, 7,10, 1, 5,10,13,13, 8,12,12, 9,10,16, 7,10,10, 7,12,10, 7, 7, 9,12, 7, 7, 8,12);# 結충
       // 합계(참고)  20 22 20 20 27 25 24 24 29 22 29 10 23 30 37 35 25 40 32 30 37 46 22 27 33 29 35 38 22 25 32 43 22 25 28 40

htmlHeader();

if(!(readIslandsFile())){
	htmlError();
} else {
	out($headKill);
	out("<TABLE BORDER=0 CELLPADDING=1 CELLSPACING=1 WIDTH=100% bgcolor=\"steelblue\">");
	for($i = 0; $i < $HislandNumber; $i++) {
		monsterlist($i);
	}
	out("</TABLE>");

}
htmlFooter();
//종료
exit(0);

//써브루틴---------------------------------------------------------
//---------------------------------------------------------------------
//	함수명 : readIslandsFile
//	기능 : 도 전체의 데이터를 읽어들인다
//	인수 : 없음
//	반환값 : 0 - 파일 오픈에 실패
//	         1 - 성공
//---------------------------------------------------------------------
function readIslandsFile() {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $HbaseDir, $HbgInfoCell, $HbgTitleCell, $HcssFile, $headKill, $helpDir, $HidToNumber, $HislandNumber, $Hislands, $HislandTurn, $HmonsterAGI, $HmonsterDEF, $HmonsterImage, $HmonsterImage2, $HmonsterName, $HmonsterSKL, $HmonsterSP, $HmonsterSpecial, $HmonsterSTR, $imageDir, $lockMode, $toppage, $versionInfo;

  // 데이터 파일을 연다
  if(!hako_open('IN', "{$HdirName}/hakojima.dat")) {
	rename("{$HdirName}/hakojima.tmp", "{$HdirName}/hakojima.dat");
	if(!hako_open('IN', "{$HdirName}/hakojima.dat")) {
	  return 0;
	}
  }
  
  // 각 파라미터의 읽어들여
  $HislandTurn	= intval(hako_getline('IN'));	# 턴수
  
  hako_getline('IN');	#  최종 갱신 시간(사용하지 않는 값이므로 읽어 날린다)
  
  $HislandNumber	= intval(hako_getline('IN'));	# 도의 총수
  hako_getline('IN');	# 다음에 할당하는 ID(사용하지 않는 값이므로 읽어 날린다)
  
  // 도의 읽어들여
  $i = null; $id = null;
  for($i = 0; $i < $HislandNumber; $i++) {
	$Hislands[$i] = readIsland($i);
	$HidToNumber[$Hislands[$i]['id']] = $i;
  }
  
  // 파일을 닫는다
  hako_close('IN');
  
  return 1;
}

//---------------------------------------------------------------------
//   함수명 : readIsland
//	기능 : 각 도에 할당할 수 있고 있는 ID를 취득
//	인수 : 0 .. $HislandNumber
//	반환값 : 도의 ID
//---------------------------------------------------------------------
function readIsland($num) {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $HbaseDir, $HbgInfoCell, $HbgTitleCell, $HcssFile, $headKill, $helpDir, $HidToNumber, $HislandNumber, $Hislands, $HislandTurn, $HmonsterAGI, $HmonsterDEF, $HmonsterImage, $HmonsterImage2, $HmonsterName, $HmonsterSKL, $HmonsterSP, $HmonsterSpecial, $HmonsterSTR, $imageDir, $lockMode, $toppage, $versionInfo;

	$id = null; $name = null;
	$name = hako_getline('IN');
	preg_match('/(.*),(.*)/', $name, $_m);# 도의 이름
	$name = $_m[1];
	$id = intval(hako_getline('IN'));# ID번호

	// 파일 포인터를 진행시킬 뿐(만큼)이므로 name, ID 이외는 값을 격납하지 않는다
	hako_getline('IN');
	hako_getline('IN');
	hako_getline('IN');
	hako_getline('IN');
	hako_getline('IN');
	hako_getline('IN');
	hako_getline('IN');
	hako_getline('IN');	# 10
	hako_getline('IN');
	hako_getline('IN');
	hako_getline('IN');
	hako_getline('IN');
	hako_getline('IN');
	hako_getline('IN');
	hako_getline('IN');
	hako_getline('IN');
	hako_getline('IN');
	hako_getline('IN');	# 20
	hako_getline('IN');
	hako_getline('IN');
	hako_getline('IN');
	hako_getline('IN');
	hako_getline('IN');
	hako_getline('IN');
	hako_getline('IN');
	hako_getline('IN');	# 28
	hako_getline('IN');
	hako_getline('IN');
	hako_getline('IN');
	hako_getline('IN');
	hako_getline('IN');	# 33
	
	//괴수 배틀용
	$mons1    = hako_getline('IN'); # 자신의 괴수
	$monsurl  = hako_getline('IN'); # 괴수 URL
	$monsurl = rtrim($monsurl);
	$monster = preg_split("/,/", $mons1);

  return array(
	'name' => $name,
	'id' => $id,
	'monsurl' => $monsurl,
	'monster' => $monster
  );
}
//---------------------------------------------------------------------
//	함수명 : out
//	기능 : 문자 코드를 shift jis로 표준 출력에 아웃풋
//	인수 : 없음
//	반환값 : 없음
//---------------------------------------------------------------------
function out() {
  $_args = func_get_args();
  extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $HbaseDir, $HbgInfoCell, $HbgTitleCell, $HcssFile, $headKill, $helpDir, $HidToNumber, $HislandNumber, $Hislands, $HislandTurn, $HmonsterAGI, $HmonsterDEF, $HmonsterImage, $HmonsterImage2, $HmonsterName, $HmonsterSKL, $HmonsterSP, $HmonsterSpecial, $HmonsterSTR, $imageDir, $lockMode, $toppage, $versionInfo;
	print $_args[0];
}
//---------------------------------------------------------------------
//	함수명 : htmlHeader
//	기능 : HTML의 헤더 부분을 출력
//	인수 : 없음
//	반환값 : 없음
//---------------------------------------------------------------------
function htmlHeader() {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $HbaseDir, $HbgInfoCell, $HbgTitleCell, $HcssFile, $headKill, $helpDir, $HidToNumber, $HislandNumber, $Hislands, $HislandTurn, $HmonsterAGI, $HmonsterDEF, $HmonsterImage, $HmonsterImage2, $HmonsterName, $HmonsterSKL, $HmonsterSP, $HmonsterSpecial, $HmonsterSTR, $imageDir, $lockMode, $toppage, $versionInfo;
	if (!headers_sent()) { header('Content-Type: text/html; charset=UTF-8'); }
		print '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">' . "\n\n";
	$skinName = "";
	$cookie = isset($_SERVER['HTTP_COOKIE']) ? $_SERVER['HTTP_COOKIE'] : '';
	if (preg_match('/(?:^|;\s*)[^;=]*SKIN=\(([^\)]*)\)/', $cookie, $_m)) {
		$skinName = $_m[1];
	} elseif (preg_match('/(?:^|;\s*)[^;=]*SKIN=([^;]*)/', $cookie, $_m)) {
		$skinName = trim($_m[1]);
	}
	$skinName = ($skinName != '') ? "$skinName" : "$HcssFile";
	out(<<<END
<html>
<head>
<title>
$title
</title>
<base href="$imageDir/">
<link rel="stylesheet" type="text/css" href="$skinName">
</head>
<DIV ID='BodySpecial'><DIV ID='LinkHead'></DIV><DIV ID='LinkTop'>
$body
<a href="$bye">[돌아온다]</a></DIV>
END
);
}
//---------------------------------------------------------------------
//	함수명 : htmlFooter
//	기능 : HTML의 footer 부분을 출력
//	인수 : 없음
//	반환값 : 없음
//---------------------------------------------------------------------
function htmlFooter() {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $HbaseDir, $HbgInfoCell, $HbgTitleCell, $HcssFile, $headKill, $helpDir, $HidToNumber, $HislandNumber, $Hislands, $HislandTurn, $HmonsterAGI, $HmonsterDEF, $HmonsterImage, $HmonsterImage2, $HmonsterName, $HmonsterSKL, $HmonsterSP, $HmonsterSpecial, $HmonsterSTR, $imageDir, $lockMode, $toppage, $versionInfo;
	list($cpu, $uti, $sti) = hako_cpu_times();
	out(<<<END
<p>
도의 이름을 클릭하면, 관광 할 수가 있습니다.  <br>
표시되고 있는 괴수의 능력치는 괴수 개인의 능력입니다. 실제의 전투에는 원괴수의 능력이 더해집니다.  <br>
전투는 랜덤인 수치가 꽤 들어가기 때문에 능력대로 승패가 정해지는 것은 아닙니다.<br>
</p>
<DIV align="right"><SMALL>CPU($cpu) : user($uti) system($sti)</SMALL></DIV>
</body></html>
END
);
}
//---------------------------------------------------------------------
//	함수명 : htmlError
//	기능 : HTML의 에러 메세지의 출력
//	인수 : 없음
//	반환값 : 없음
//---------------------------------------------------------------------
function htmlError() {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $HbaseDir, $HbgInfoCell, $HbgTitleCell, $HcssFile, $headKill, $helpDir, $HidToNumber, $HislandNumber, $Hislands, $HislandTurn, $HmonsterAGI, $HmonsterDEF, $HmonsterImage, $HmonsterImage2, $HmonsterName, $HmonsterSKL, $HmonsterSP, $HmonsterSpecial, $HmonsterSTR, $imageDir, $lockMode, $toppage, $versionInfo;
	out("<h2 class=head2>에러가 발생했던</h2>\n");
}
//---------------------------------------------------------------------
//	함수명 : monsterlist
//	기능 : 괴수 배틀 괴수 일람표 작성
//	인수 : 없음
//	반환값 : 없음
//---------------------------------------------------------------------
function monsterlist() {
  $_args = func_get_args();
  extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $HbaseDir, $HbgInfoCell, $HbgTitleCell, $HcssFile, $headKill, $helpDir, $HidToNumber, $HislandNumber, $Hislands, $HislandTurn, $HmonsterAGI, $HmonsterDEF, $HmonsterImage, $HmonsterImage2, $HmonsterName, $HmonsterSKL, $HmonsterSP, $HmonsterSpecial, $HmonsterSTR, $imageDir, $lockMode, $toppage, $versionInfo;
	$island = $Hislands[$_args[0]];

	list($id,$name,$monster) = array($island['id'],$island['name'],$island['monster']);
	list($MBsId,$MBmId) = array($monster[3],$monster[4]);
	$tn = $HidToNumber[$monster[2]];
	$tMonster = null; $tIsland = null; $tName = null; $tMBsId = null; $tMBmId = null;
	if($tn == '') {
	} else {
		// 대전 상대가 있을 때
		$tIsland = $Hislands[$tn];
		$tName = $tIsland['name'];
		$tMonster = $tIsland['monster'];
		list($tMBsId, $tMBmId) = array($tMonster[3],$tMonster[4]);
	}
	$MBidName = null;
	if($monster[0] == 0) {
		return;
	} else {
		$monsIsland = $Hislands[$HidToNumber[$monster[0]]];
		$MBidName = $monsIsland['name'];
		
		if($monster[2] == 0) {
			$MBidName = "자신의 섬";
		} else {
			$MBidName = "$MBidName$AfterName 으로<br>{$tMonster[1]}으로 <b>전투중</b>";;
		}
	}

	// 괴수 이미지 처리
	$image = $HmonsterImage[$MBmId];
	$special = $HmonsterSpecial[$MBmId];
	// 방어중?
	if((($special == 3) && (($HislandTurn % 2) == 1)) ||
		(($special == 4) && (($HislandTurn % 2) == 0))) {
		$image = $HmonsterImage2[$MBmId];
	}
	if (substr($island['monsurl'],0,7) == 'http://') { $image = $island['monsurl']; }
	
	$image2 = $HmonsterImage[$tMBmId];
	$special = $HmonsterSpecial[$tMBmId];
	// 방어중?
	if((($special == 3) && (($HislandTurn % 2) == 1)) ||
		(($special == 4) && (($HislandTurn % 2) == 0))) {
		$image2 = $HmonsterImage2[$tMBmId];
	}
	if (substr($tIsland['monsurl'],0,7) == 'http://') { $image2 = $tIsland['monsurl']; }
	
	$seityou = $monster[7] + $monster[8] + $monster[9] + $monster[10];
	$tseityou = $tMonster[7] + $tMonster[8] + $tMonster[9] + $tMonster[10];

	$mSTR = $HmonsterSTR[$MBmId] + $monster[7];
	$mDEF = $HmonsterDEF[$MBmId] + $monster[8];
	$mAGI = $HmonsterAGI[$MBmId] + $monster[9];
	$mSKL = $HmonsterSKL[$MBmId] + $monster[10];

	$MBmId = ($MBmId == 0) ? "　" : $HmonsterName[$MBmId];
	$MBsId = ($MBsId == 0) ? "무" : $HmonsterName[$MBsId];
	$tMBmId = ($tMBmId == 0) ? "　" : $HmonsterName[$tMBmId];
	$tMBsId = ($tMBsId == 0) ? "무" : $HmonsterName[$tMBsId];
	
	if($seityou < 12) {
		$seityou = "유년";
	} elseif($seityou < 25) {
		$seityou = "장년";
	} else {
		$seityou = "노년";
	}
	if($tseityou < 12) {
		$tseityou = "유년";
	} elseif($tseityou < 25) {
		$tseityou = "장년";
	} else {
		$tseityou = "노년";
	}

	out(<<<END

<tr>
<td $HbgTitleCell align=center>이름</td>
<td $HbgTitleCell align=center>괴수명</td>
<td $HbgTitleCell align=center>외관</td>
<td $HbgTitleCell align=center>원괴수</td>
<td $HbgTitleCell align=center>승수</td>
<td $HbgTitleCell align=center>음수</td>
<td $HbgTitleCell align=center>성장</td>
<td $HbgTitleCell align=center>HP</td>
<td $HbgTitleCell align=center>공격</td>
<td $HbgTitleCell align=center>수비</td>
<td $HbgTitleCell align=center>회피</td>
<td $HbgTitleCell align=center>명중</td>
<td $HbgTitleCell align=center>상황</td>
<td $HbgTitleCell align=center>이</td>
</tr>
<tr>
<td $HbgInfoCell>
<A HREF="{$HbaseDir}/hako-main.php?Sight={$id}" TARGET=_blank>
$name$AfterName
</A></td>
<td $HbgInfoCell>$monster[1]</td>
<td $HbgInfoCell><IMG SRC=\"$image\" width=32 height=32 BORDER=0></td>
<td $HbgInfoCell>$MBmId</td>
<td $HbgInfoCell align=center>$monster[12]</td>
<td $HbgInfoCell align=center>$monster[13]</td>
<td $HbgInfoCell>$seityou</td>
<td $HbgInfoCell align=center>$monster[5]/$monster[6]</td>

END
);
	if($Monshyouzi) { # 괴수의 능력을 원 괴수 능력을 포함해 표시
	out(<<<END
<td $HbgInfoCell align=center>$mSTR($monster[7])</td>
<td $HbgInfoCell align=center>$mDEF($monster[8])</td>
<td $HbgInfoCell align=center>$mAGI($monster[9])</td>
<td $HbgInfoCell align=center>$mSKL($monster[10])</td>
END
);
	} else { # 괴수의 능력을 자신의 능력만 표시
	out(<<<END
<td $HbgInfoCell align=center>$monster[7]</td>
<td $HbgInfoCell align=center>$monster[8]</td>
<td $HbgInfoCell align=center>$monster[9]</td>
<td $HbgInfoCell align=center>$monster[10]</td>
END
);
	}
	out(<<<END

<td $HbgInfoCell>$MBidName</td>
<td $HbgInfoCell>$MBsId</td>

</tr>

END
);
}
