<?php
if (!isset($_hako_fh)) { $_hako_fh = array(); }

if (!isset($GLOBALS['_hako_req_start'])) { $GLOBALS['_hako_req_start'] = microtime(true); }
if (!isset($GLOBALS['_hako_req_ru_start'])) { $GLOBALS['_hako_req_ru_start'] = function_exists('getrusage') ? getrusage() : null; }
if (!function_exists('hako_cpu_times')) {
function hako_cpu_times() {
    $startRu = isset($GLOBALS['_hako_req_ru_start']) ? $GLOBALS['_hako_req_ru_start'] : null;
    if (function_exists('getrusage') && is_array($startRu)) {
        $r = getrusage();
        $u0 = (isset($startRu['ru_utime.tv_sec']) ? $startRu['ru_utime.tv_sec'] : 0) + (isset($startRu['ru_utime.tv_usec']) ? $startRu['ru_utime.tv_usec'] : 0) / 1000000;
        $s0 = (isset($startRu['ru_stime.tv_sec']) ? $startRu['ru_stime.tv_sec'] : 0) + (isset($startRu['ru_stime.tv_usec']) ? $startRu['ru_stime.tv_usec'] : 0) / 1000000;
        $u1 = (isset($r['ru_utime.tv_sec']) ? $r['ru_utime.tv_sec'] : 0) + (isset($r['ru_utime.tv_usec']) ? $r['ru_utime.tv_usec'] : 0) / 1000000;
        $s1 = (isset($r['ru_stime.tv_sec']) ? $r['ru_stime.tv_sec'] : 0) + (isset($r['ru_stime.tv_usec']) ? $r['ru_stime.tv_usec'] : 0) / 1000000;
        $uti = max(0, $u1 - $u0);
        $sti = max(0, $s1 - $s0);
        return array(round($uti + $sti, 4), round($uti, 4), round($sti, 4));
    }
    $start = isset($GLOBALS['_hako_req_start']) ? $GLOBALS['_hako_req_start'] : (isset($_SERVER['REQUEST_TIME_FLOAT']) ? $_SERVER['REQUEST_TIME_FLOAT'] : microtime(true));
    $elapsed = microtime(true) - $start;
    if ($elapsed < 0) { $elapsed = 0; }
    return array(round($elapsed, 4), round($elapsed, 4), 0);
}
}
if (!function_exists('hako_open')) {
  function hako_open($name, $spec) {
    global $_hako_fh;
    $mode = 'r';
    $path = $spec;
    if (substr($path, 0, 2) === '>>') { $mode = 'a'; $path = substr($path, 2); }
    elseif (substr($path, 0, 1) === '>') { $mode = 'w'; $path = substr($path, 1); }
    elseif (substr($path, 0, 1) === '<') { $mode = 'r'; $path = substr($path, 1); }
    $_hako_fh[$name] = @fopen($path, $mode);
    return $_hako_fh[$name];
  }
  function hako_close($name) {
    global $_hako_fh;
    if (isset($_hako_fh[$name]) && $_hako_fh[$name]) { fclose($_hako_fh[$name]); }
  }
  function hako_getline($name) {
    global $_hako_fh;
    if (!isset($_hako_fh[$name]) || !$_hako_fh[$name]) { return false; }
    return fgets($_hako_fh[$name]);
  }
  function hako_write($name, $data) {
    global $_hako_fh;
    if (!isset($_hako_fh[$name]) || !$_hako_fh[$name]) { return false; }
    return fwrite($_hako_fh[$name], $data);
  }
  function hako_cmp($a, $b) {
    if ($a == $b) { return 0; }
    return ($a < $b) ? -1 : 1;
  }
  function hako_reorder($array, $idx) {
    $out = array();
    foreach ($idx as $i) { if (isset($array[$i])) { $out[] = $array[$i]; } }
    return $out;
  }
  function hako_pick($array, $keys) {
    $out = array();
    foreach ($keys as $key) { $out[] = isset($array[$key]) ? $array[$key] : null; }
    return (count($keys) == 1) ? $out[0] : $out;
  }
  function hako_idx($array, $idx) {
    return isset($array[$idx]) ? $array[$idx] : null;
  }
}
if (!function_exists('printval')) { function printval($s) { echo $s; } }
if (!function_exists('history_log_path')) {
  function history_log_path($file) {
    global $HlogdirName, $HdirName;
    $p = $HlogdirName . '/' . $file;
    if (file_exists($p)) { return $p; }
    $alt = $HdirName . '/' . $file;
    if (file_exists($alt)) { return $alt; }
    $alt2 = './' . $file;
    if (file_exists($alt2)) { return $alt2; }
    return $p;
  }
}
function hako_history_log_file_candidates($fileNumber) {
    global $HlogdirName, $HdirName;
    $dirs = array($HlogdirName, $HdirName, '.', './logdata', './data', '../logdata', '../data');
    $out = array();
    foreach ($dirs as $d) {
        if ($d === null || $d === '') { continue; }
        $out[] = rtrim($d, '/').'/hakojima.log'.intval($fileNumber);
    }
    return array_values(array_unique($out));
}
if (!function_exists('history_weather_icon')) {
  function history_weather_icon($kind) {
    global $WeatherIcon;
    $kind = intval($kind);
    if (is_array($WeatherIcon) && isset($WeatherIcon[$kind])) { return $WeatherIcon[$kind]; }
    if (is_array($WeatherIcon) && isset($WeatherIcon[1])) { return $WeatherIcon[1]; }
    return 'land0.gif';
  }
}
if (!function_exists('history_weather_name')) {
  function history_weather_name($kind) {
    global $WeatherName;
    $kind = intval($kind);
    if (is_array($WeatherName) && isset($WeatherName[$kind])) { return $WeatherName[$kind]; }
    return '';
  }
}
$defaultID = 0;
$Graph = 0;
// #!/usr/bin/perl

//---------------------------------------------------------------------
//	최근의 사건과 최근의 날씨의 이력을 표시
//
//	작성일 : 2001/11/25 V0. 10
//	작성자 : 라스티아1
//
//	수정 내용
//	2001/12/31 V0. 20 공통 설정부를 별파일로부터 수중에 넣도록(듯이) 했다.
//	2002/04/20 V0. 30 대표의 턴수를 표시하는 형식으로 변경. 부하 표시를 붙였다.
//	2002/08/15 V0. 40 통계 파일 표시 기능 추가.
//	2002/09/18 V0. 41 1도근처의 통계를 추가.
//	2002/10/29 V0. 50 스타일 시트 근처와 날씨 파일 표시를 개량
//	2003/05/05 V0. 60 구상의 모형정원 5 사양에 수정.
//	2003/09/15 V0. 70 날씨 이미지 일람표시, 도 마다의 이력등을 수중에 넣어. neo_otacky씨 고마워요♪
//	2003/10/26 V0. 80 턴 차이 명령을 표시, 진영의 이력 표시, 일부 처리를 별파일 로 분리
//---------------------------------------------------------------------
//---------------------------------------------------------------------
//	초기설정
//---------------------------------------------------------------------
require_once "./hako-init.php";
require_once "./hako-io.php";
require_once "./init-game.php";

//----------------------------
//	HTML에 관한 설정
//----------------------------
// 브라우저의 타이틀 바의 명칭
$title = '최근의 사건과 날씨';

// 화면의 색이나 배경의 설정(HTML)
$body = '<body>';

// 화면의 「돌아온다」링크처(URL)
$bye = $HthisFile;

// 최근의 날씨의 색속성
$headNameCellcolor	= 'class=headNameCellcolor';# 최근의 날씨의 헤더 부분의 셀색
$pointCellcolor		= 'class=pointCellcolor';	# 최근의 날씨의 날씨 부분의 셀색
$nameCellcolor		= 'class=nameCellcolor';	# 최근의 날씨의 이름의 표시부 분의 셀색

$tomorrowColor		= 'class=TomorrowColor';	# 최근의 날씨의 내일 이후의 문자색
$todayColor			= 'class=TodayColor';		# 최근의 날씨의 오늘의 문자색
$yesterdayColor		= 'class=YesterdayColor';	# 최근의 날씨의 어제 이전의 문자색

//메인 루틴-------------------------------------------------------

cookieInput();
cgiInput();
if (file_exists($HpasswordFile)) {
	// 패스워드 파일이 있다
	hako_open('PIN', "<$HpasswordFile") or die("file open failed");
	$HmasterPassword = rtrim(hako_getline('PIN'));# master password를 읽어들인다
	$HspecialPassword = rtrim(hako_getline('PIN'));# 특수 패스워드를 읽어들인다
	hako_close('PIN');
}
if(!(readIslandsFile())){
	tempHeader();
	htmlError();
} else {
	$HislandList = getIslandList($HcurrentID);
	tempHeader();
	printval("<DIV ID='RecentlyLog'>\n");
	$HcurrentNumber = (isset($HidToNumber[$HcurrentID]) ? $HidToNumber[$HcurrentID] : null);
	$island = ($HcurrentNumber !== null && isset($Hislands[$HcurrentNumber])) ? $Hislands[$HcurrentNumber] : array('name'=>'');
	$name = isset($island['name']) ? $island['name'] : '';
	$HcurrentName = ($name !== '') ? "$name$AfterName" : '';
	if($HMode == 100) {
		// 날씨
		logTenki();
	} elseif($HMode == 200) {
		// 통계
		logStatistical();
	} elseif($HMode == 300) {
		// 턴 차이 명령
		tempCommandLate();
	} elseif($HMode == 400) {
		// 진영 이력
		tempAlly();
//	} elsif(preg_match('/([0-9]*)/', $HMode)) {
	} else {
		// 최근의 사건
		logDekigoto();
		if($HMode == 99){
			if($HcurrentID == 0) {
				logFilePrintAll();
			} else {
				tempIslandHeader($HcurrentID, $HcurrentName);
				// 패스워드
				if(checkPassword((isset($island['password']) ? $island['password'] : $island), $HinputPassword) && ($HcurrentID == $defaultID)) {
					logPrintLocal(1);
				} else {
					// password 다르다
					logPrintLocal(0);
				}
			}
		} else {
			if($HcurrentID == 0) {
				logFilePrint($HMode, $HcurrentID, 0);
			} else {
				tempIslandHeader($HcurrentID, $HcurrentName);
				// 패스워드
				if(checkPassword((isset($island['password']) ? $island['password'] : $island), $HinputPassword) && ($HcurrentID == $defaultID)) {
					logFilePrint($HMode, $HcurrentID, 1);
				} else {
					// password 실수
					logFilePrint($HMode, $HcurrentID, 0);
				}
			}
		}
		printval("<hr>\n");
//	} else {
//		# 날씨
//		logTenki();
	}
	printval("</DIV>\n");
}
tempFooter();
//종료
exit(0);

//써브루틴---------------------------------------------------------
//---------------------------------------------------------------------
//       함수명 : htmlError
//       기능 : HTML의 에러 메세지의 출력
//       인수 : 없음
//       반환값 : 없음
//---------------------------------------------------------------------
function htmlError() {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $Hallyflg, $Hallygroup, $Hallymark, $HbgNameCell, $HbgNumberCell, $HbgTitleCell, $HcomL, $HcomLateCt, $HcomName, $HcssFile, $HcurrentID, $HcurrentName, $HcurrentNumber, $HdefaultPassword, $headNameCellcolor, $helpDir, $HidToNumber, $HinputPassword, $HislandList, $HislandNumber, $Hislands, $HislandTurn, $HmasterPassword, $HMode, $hp, $HpasswordFile, $HskinName, $HspecialPassword, $HthisFile, $HtopLogTurn, $HturnPrizeVarious, $imageDir, $lockMode, $toppage, $versionInfo, $defaultID, $Graph, $allyturn;
	printval("<h2>에러가 발생했습니다.</h2>\n");
}
//---------------------------------------------------------------------
//       함수명 : readIslandsFile
//       기능 : 도 전체의 데이터를 읽어들인다
//       인수 : 없음
//       반환값 : 0 - 파일 오픈에 실패
//               1 - 성공
//---------------------------------------------------------------------
function readIslandsFile() {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $Hallyflg, $Hallygroup, $Hallymark, $HbgNameCell, $HbgNumberCell, $HbgTitleCell, $HcomL, $HcomLateCt, $HcomName, $HcssFile, $HcurrentID, $HcurrentName, $HcurrentNumber, $HdefaultPassword, $headNameCellcolor, $helpDir, $HidToNumber, $HinputPassword, $HislandList, $HislandNumber, $Hislands, $HislandTurn, $HmasterPassword, $HMode, $hp, $HpasswordFile, $HskinName, $HspecialPassword, $HthisFile, $HtopLogTurn, $HturnPrizeVarious, $imageDir, $lockMode, $toppage, $versionInfo, $defaultID, $Graph, $allyturn;
	// 데이터 파일을 연다
	if(!hako_open('IN', "{$HdirName}/hakojima.dat")) {
		rename("{$HdirName}/hakojima.tmp", "{$HdirName}/hakojima.dat");
		if (!hako_open('IN', "{$HdirName}/hakojima.dat")) { return 0; }
	}
	// 각 파라미터의 읽어들여
	$HislandTurn  = intval(hako_getline('IN'));    # 턴수
	hako_getline('IN'); # 최종 갱신 시간(사용하지 않는 값이므로 읽어 날린다)
	$HislandNumber        = intval(hako_getline('IN'));    # 도의 총수
	hako_getline('IN'); # 다음에 할당하는 ID(사용하지 않는 값이므로 읽어 날린다)
	// 도의 읽어들여
	$i = null; $id = null;
	for($i = 0; $i < $HislandNumber; $i++) {
		$Hislands[$i] = readIsland($i);
		$HidToNumber[$Hislands[$i]['id']] = $i;
	}
	// 파일을 닫는다
	hako_close('IN');
	readCommandLate();
	return 1;
}
//---------------------------------------------------------------------
//       함수명 : readIsland
//       기능 : 각 도에 할당할 수 있고 있는 ID를 취득
//       인수 : 0 .. $HislandNumber
//       반환값 : 도의 ID
//---------------------------------------------------------------------
function readIsland($num) {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $Hallyflg, $Hallygroup, $Hallymark, $HbgNameCell, $HbgNumberCell, $HbgTitleCell, $HcomL, $HcomLateCt, $HcomName, $HcssFile, $HcurrentID, $HcurrentName, $HcurrentNumber, $HdefaultPassword, $headNameCellcolor, $helpDir, $HidToNumber, $HinputPassword, $HislandList, $HislandNumber, $Hislands, $HislandTurn, $HmasterPassword, $HMode, $hp, $HpasswordFile, $HskinName, $HspecialPassword, $HthisFile, $HtopLogTurn, $HturnPrizeVarious, $imageDir, $lockMode, $toppage, $versionInfo, $defaultID, $Graph, $allyturn;
	$id = null; $name = null; $wline = null; $weather = null; $pastweather = null;
	$name = hako_getline('IN');
	preg_match('/(.*),(.*)/', $name, $_m);# 도의 이름
	$name = $_m[1];
	$id = intval(hako_getline('IN'));# ID번호
	// 파일 포인터를 진행시킬 뿐(만큼)이므로 name, ID 이외는 값을 격납하지 않는다
	for($i = 2; $i < 12; $i++) {
		hako_getline('IN');
	}
	$wline = hako_getline('IN');  # 기후
	for($i = 13; $i < 35; $i++) {
		hako_getline('IN');
	}
	$parts = explode(',', trim($wline));
	$weather = intval(array_shift($parts));
	$pastw = array();
	for($w = 0; $w < 11; $w++) {
		$pastw[$w] = isset($parts[$w]) ? intval($parts[$w]) : 0;
	}
	return array(
		'name' => $name,
		'id' => $id,
		'weather' => $weather,
		'pastweather' => $pastw,
	);
}
//--------------------------------------------------------------------
//	POST or GET로 입력된 데이터 취득
//--------------------------------------------------------------------
function cgiInput() {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $Hallyflg, $Hallygroup, $Hallymark, $HbgNameCell, $HbgNumberCell, $HbgTitleCell, $HcomL, $HcomLateCt, $HcomName, $HcssFile, $HcurrentID, $HcurrentName, $HcurrentNumber, $HdefaultPassword, $headNameCellcolor, $helpDir, $HidToNumber, $HinputPassword, $HislandList, $HislandNumber, $Hislands, $HislandTurn, $HmasterPassword, $HMode, $hp, $HpasswordFile, $HskinName, $HspecialPassword, $HthisFile, $HtopLogTurn, $HturnPrizeVarious, $imageDir, $lockMode, $toppage, $versionInfo, $defaultID, $Graph, $allyturn;
	$line = null; $getLine = null;
	// 입력을 받아 일본어 코드를 EUC에
	$line = file_get_contents('php://input');
	if($line === false) { $line = ''; }
	$line = strtr($line, '+', ' ');
//	$line =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
	$line = preg_replace_callback('/%([a-fA-F0-9]{2})/', function($m) { return chr(hexdec($m[1])); }, $line);
//	$line = jcode::euc($line);
//	jcode::convert($line, 'euc');
	$line = preg_replace('/[\x00-\x1f\,]/', '', $line, -1);

	// GET의 녀석도 받는다
	$getLine = isset($_SERVER['QUERY_STRING']) ? $_SERVER['QUERY_STRING'] : '';

	if (preg_match('/tenki=([0-9]*)/', $getLine, $_m)) {
		$HMode = 100;
	} elseif (preg_match('/statistical=([0-9]*)/', $getLine, $_m)) {
		$HMode = 200;
		$Graph = $_m[1];
	} elseif (preg_match('/commandlate=([0-9]*)/', $getLine, $_m)) {
		$HMode = 300;
	} elseif (preg_match('/ally=([0-9]*)/', $getLine, $_m)) {
		$HMode = 400;
		$allyturn = $_m[1];
	} elseif (preg_match('/saikin=([0-9]*)/', $getLine, $_m)) {
		$HMode = $_m[1];
	} else {
		$HMode = 0;
	}
	if (preg_match('/ID=([0-9]*)/', $line, $_m)) {
		$HcurrentID = $_m[1];
	}
	if (preg_match('/PASSWORD=([^\&]*)/', $line, $_m)) {
		$HinputPassword = $_m[1];
	}
	if (preg_match('/ID=([0-9]*)/', $getLine, $_m)) {
		$HcurrentID = $_m[1];
	}
	if (preg_match('/PASSWORD=([^\&]*)/', $getLine, $_m)) {
		$HinputPassword = $_m[1];
	}
	if (preg_match('/Event=([0-9]*)/', $getLine, $_m)) {
		$HMode = $_m[1];
	}
	if ($HMode == 99 && !preg_match('/(?:^|&)ID=([0-9]*)/', $getLine) && !preg_match('/(?:^|&)ID=([0-9]*)/', $line)) {
		$HcurrentID = 0;
	}
}
//cookie 입력
function cookieInput() {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $Hallyflg, $Hallygroup, $Hallymark, $HbgNameCell, $HbgNumberCell, $HbgTitleCell, $HcomL, $HcomLateCt, $HcomName, $HcssFile, $HcurrentID, $HcurrentName, $HcurrentNumber, $HdefaultPassword, $headNameCellcolor, $helpDir, $HidToNumber, $HinputPassword, $HislandList, $HislandNumber, $Hislands, $HislandTurn, $HmasterPassword, $HMode, $hp, $HpasswordFile, $HskinName, $HspecialPassword, $HthisFile, $HtopLogTurn, $HturnPrizeVarious, $imageDir, $lockMode, $toppage, $versionInfo, $defaultID, $Graph, $allyturn;
	$cookie = null;
	$cookie = isset($_SERVER['HTTP_COOKIE']) ? $_SERVER['HTTP_COOKIE'] : '';

	$base = preg_quote($HthisFile, '/');
	if (preg_match('/(?:'.$base.')?OWNISLANDID=\(([^\)]*)\)/', $cookie, $_m)) {
		$defaultID = $_m[1];
	}
	if (preg_match('/(?:'.$base.')?OWNISLANDPASSWORD=\(([^\)]*)\)/', $cookie, $_m)) {
		$HdefaultPassword = $_m[1];
	}
	if (preg_match('/(?:'.$base.')?SKIN=\(([^\)]*)\)/', $cookie, $_m)) {
		$HskinName = $_m[1];
	}

}

//---------------------------------------------------------------------
//	HTML의 헤더와 footer 부분을 출력?
//---------------------------------------------------------------------
// 헤더
function tempHeader() {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $Hallyflg, $Hallygroup, $Hallymark, $HbgNameCell, $HbgNumberCell, $HbgTitleCell, $HcomL, $HcomLateCt, $HcomName, $HcssFile, $HcurrentID, $HcurrentName, $HcurrentNumber, $HdefaultPassword, $headNameCellcolor, $helpDir, $HidToNumber, $HinputPassword, $HislandList, $HislandNumber, $Hislands, $HislandTurn, $HmasterPassword, $HMode, $hp, $HpasswordFile, $HskinName, $HspecialPassword, $HthisFile, $HtopLogTurn, $HturnPrizeVarious, $imageDir, $lockMode, $toppage, $versionInfo, $defaultID, $Graph, $allyturn;
//	print qq{Content-type: text/html; charset=Shift_JIS\n\n};
	if (!headers_sent()) { header('Content-Type: text/html; charset=UTF-8'); }
		print '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">' . "\n\n";
	if (is_array($HskinName)) { $HskinName = ''; }
	$HskinName = (is_string($HskinName) && $HskinName != '') ? "$imageDir/$HskinName" : "$imageDir/$HcssFile";
	print(<<<END
<html lang="ja">
<!--???-->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<TITLE>
$title
</TITLE>
<link rel="stylesheet" type="text/css" href="$HskinName">
</HEAD>
$body
<DIV ID='BodySpecial'><DIV ID='LinkHead'></DIV><DIV ID='LinkTop'>
<FORM name="recentForm" action="{$HbaseDir}/history.php" method="POST" style="margin  : 2px 0px;">
<A HREF="$bye">[돌아온다]</A>　
<B>[최근의 사건]</B>　<A HREF="history.php?saikin=99">[ALL]</A>
END
);
	$i = null; $turn = null;
	for($i = 0;$i < $HtopLogTurn;$i++) {
		$turn = $HislandTurn - $i;
		if (!($turn > 0)) { return; }
		printval("<A HREF='history.php?saikin={$i}'>");
		if($i == 0) {
			printval("[턴{$turn}(현재)]");
		} else {
			printval("[{$turn}]");
		}
		printval("</A>\n");
	}
	$tmp = "";
	if($Hallyflg){
		$tmp = "<A HREF=\"history.php?ally=0\">[진영의 이력]</A>";
	}
	print(<<<END
<SELECT NAME="ID">$HislandList</SELECT>
<INPUT type=hidden name=PASSWORD value=$HinputPassword>
<INPUT type="submit" value="(을)를 본다">
</FORM><HR>
<A HREF="history.php?tenki=0">[최근의 날씨]</A>
<A HREF="history.php?commandlate=0">[턴 차이 명령]</A>
$tmp
<A HREF="history.php?statistical=0">[통계 ALL]</A>
<A HREF="history.php?statistical=30">[통계 1도근처]</A>
<HR></DIV>
END
);
}
// ΦΓ?
function tempFooter() {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $Hallyflg, $Hallygroup, $Hallymark, $HbgNameCell, $HbgNumberCell, $HbgTitleCell, $HcomL, $HcomLateCt, $HcomName, $HcssFile, $HcurrentID, $HcurrentName, $HcurrentNumber, $HdefaultPassword, $headNameCellcolor, $helpDir, $HidToNumber, $HinputPassword, $HislandList, $HislandNumber, $Hislands, $HislandTurn, $HmasterPassword, $HMode, $hp, $HpasswordFile, $HskinName, $HspecialPassword, $HthisFile, $HtopLogTurn, $HturnPrizeVarious, $imageDir, $lockMode, $toppage, $versionInfo, $defaultID, $Graph, $allyturn;
	list($cpu, $uti, $sti) = hako_cpu_times();
	print(<<<END
<DIV align="right"><SMALL>CPU($cpu) : user($uti) system($sti)</SMALL></DIV>
<P></DIV></BODY></HTML>
END
);
}
//---------------------------------------------------------------------
//	날씨 파일 표시
//---------------------------------------------------------------------
function logTenki() {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $Hallyflg, $Hallygroup, $Hallymark, $HbgNameCell, $HbgNumberCell, $HbgTitleCell, $HcomL, $HcomLateCt, $HcomName, $HcssFile, $HcurrentID, $HcurrentName, $HcurrentNumber, $HdefaultPassword, $headNameCellcolor, $helpDir, $HidToNumber, $HinputPassword, $HislandList, $HislandNumber, $Hislands, $HislandTurn, $HmasterPassword, $HMode, $hp, $HpasswordFile, $HskinName, $HspecialPassword, $HthisFile, $HtopLogTurn, $HturnPrizeVarious, $imageDir, $lockMode, $toppage, $versionInfo, $defaultID, $Graph, $allyturn;
	$i = null; $j = null; $name = null; $turn = null;
	print(<<<END
<H1>최근의 날씨</H1>
<TABLE BORDER=0 CELLPADDING=1 CELLSPACING=0 WIDTH=100% BGCOLOR="#000000"><TR><TD>
<TABLE BORDER=0 CELLPADDING=1 CELLSPACING=1 WIDTH=100%>
<TR><TD $headNameCellcolor rowspan=2 NOWRAP>도의 이름</TD>
<TD $headNameCellcolor colspan=3 NOWRAP><span $tomorrowColor>예보</span></TD>
END
);
for($i = 0; $i < 11; $i++) {
	$turn = $HislandTurn - $i;
	if ($turn < 1) { continue; }
	printval("<TD $headNameCellcolor rowspan=2 NOWRAP>");
	if($i == 0) {
		printval("<nobr><span $todayColor>턴{$turn}<br>(현재)</nobr>");
	} else {
		printval("{$turn}");
	}
	printval("</TD>");
}
printval("</TR><TR>");
$turn = $HislandTurn + 3;
printval("<TD $headNameCellcolor NOWRAP>$turn<br><small>(모레)</small></TD>");
$turn--;
printval("<TD $headNameCellcolor NOWRAP>$turn<br><small>(내일)</small></TD>");
$turn--;
printval("<TD $headNameCellcolor NOWRAP>$turn<br><small>(오늘)</small></TD></TR>");
for($i = 0; $i < $HislandNumber; $i++) {
	$no = $HidToNumber[$Hislands[$i]['id']];
	$name = $Hislands[$i]['name'];
	list($wkind, $wname, $whp, $wkind2, $wkind3) = weatherinfo($Hislands[$i]['weather']);
	$pastweather = isset($Hislands[$i]['pastweather']) && is_array($Hislands[$i]['pastweather']) ? $Hislands[$i]['pastweather'] : array();
	$wicon3 = history_weather_icon($wkind3); $wicon2 = history_weather_icon($wkind2); $wicon0 = history_weather_icon($wkind);
	$wname3 = history_weather_name($wkind3); $wname2 = history_weather_name($wkind2); $wname0 = history_weather_name($wkind);
	print(<<<END
<TR>
<TD $nameCellcolor NOWRAP><nobr>{$name}{$AfterName}</TD>
<TD $pointCellcolor NOWRAP><img src ="{$imageDir}/{$wicon3}"><br><span $tomorrowColor>{$wname3}</span></TD>
<TD $pointCellcolor NOWRAP><img src ="{$imageDir}/{$wicon2}"><br><span $tomorrowColor>{$wname2}</span></TD>
<TD $pointCellcolor NOWRAP><img src ="{$imageDir}/{$wicon0}"><br><span $tomorrowColor>{$wname0}</span></TD>
END
);
	for($j = 0; $j < 11; $j++) {
		$turn = $HislandTurn - $j;
		if ($turn < 1) { continue; }
		$pw = isset($pastweather[$j]) ? $pastweather[$j] : $wkind;
		printval("<TD BGCOLOR=#ffffff NOWRAP><img src ='" . $imageDir . "/" . history_weather_icon($pw) . "'><br>");
		if($j){
			printval("<span $yesterdayColor>");
		}else{
			printval("<span $todayColor>");
		}
		printval(history_weather_name($pw) . "</span></TD>");
	}
	printval("</TR>\n");
}
printval("</TABLE></TD></TR></TABLE><br>\n");
}
//---------------------------------------------------------------------
//	기후의 정보
//---------------------------------------------------------------------
function weatherinfo($lv) {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $Hallyflg, $Hallygroup, $Hallymark, $HbgNameCell, $HbgNumberCell, $HbgTitleCell, $HcomL, $HcomLateCt, $HcomName, $HcssFile, $HcurrentID, $HcurrentName, $HcurrentNumber, $HdefaultPassword, $headNameCellcolor, $helpDir, $HidToNumber, $HinputPassword, $HislandList, $HislandNumber, $Hislands, $HislandTurn, $HmasterPassword, $HMode, $hp, $HpasswordFile, $HskinName, $HspecialPassword, $HthisFile, $HtopLogTurn, $HturnPrizeVarious, $imageDir, $lockMode, $toppage, $versionInfo, $defaultID, $Graph, $allyturn;

	if ($lv > 5559) { $lv = 1114; }

	// 모레의 날씨
	$kind3 = intval($lv / 1000);
	if ($kind3 >= 6) { $kind3 = 1; }

	$lv2 = $lv - ($kind3 * 1000);

	// 내일의 날씨
	$kind2 = intval($lv2 / 100);
	if ($kind2 >= 6) { $kind2 = 1; }

	$lv3 = $lv2 - ($kind2 * 100);

	// 날씨
	$kind = intval($lv3 / 10);
	if ($kind >= 6) { $kind = 1; }

	$name = (isset($WeatherName[$kind]) ? $WeatherName[$kind] : '');# 이름
	$hp = $lv3 - ($kind * 10);#지반 상태
	return array($kind, $name, $hp, $kind2, $kind3);
}
//---------------------------------------------------------------------
//	통계 파일 표시?
//---------------------------------------------------------------------
function logStatistical() {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $Hallyflg, $Hallygroup, $Hallymark, $HbgNameCell, $HbgNumberCell, $HbgTitleCell, $HcomL, $HcomLateCt, $HcomName, $HcssFile, $HcurrentID, $HcurrentName, $HcurrentNumber, $HdefaultPassword, $headNameCellcolor, $helpDir, $HidToNumber, $HinputPassword, $HislandList, $HislandNumber, $Hislands, $HislandTurn, $HmasterPassword, $HMode, $hp, $HpasswordFile, $HskinName, $HspecialPassword, $HthisFile, $HtopLogTurn, $HturnPrizeVarious, $imageDir, $lockMode, $toppage, $versionInfo, $defaultID, $Graph, $allyturn;
	$line = array(); $l = null;
	if(hako_open('HIN', history_log_path('statistical.log'))){
		while (($l = hako_getline('HIN')) !== false) {
			$l = rtrim($l);
			array_push($line, $l);
		}
		hako_close('HIN');
	}else{
		printval("아직 데이터가 없습니다.\n");
		return;
	}
	$gimage = "$imageDir/graph.gif";
	$oneisland = ($Graph >= 30) ? "(1도근처)" : "";
	print(<<<END
<H1>구상의 모형정원 통계{$oneisland}</H1>
<TABLE border=1><TR><TH $HbgTitleCell>턴</TH><TH $HbgTitleCell>총 인구</TH><TH $HbgTitleCell>총 자금</TH><TH $HbgTitleCell>총 면적</TH><TH $HbgTitleCell>총 예금</TH><TH $HbgTitleCell>총 미사일 발사수</TH><TH $HbgTitleCell>총 농장</TH><TH $HbgTitleCell>총 상업</TH><TH $HbgTitleCell>총 공업</TH><TH $HbgTitleCell>총 양식</TH><TH $HbgTitleCell>총 삼림</TH><TH $HbgTitleCell>도의 수</TH></TR>
END
);
	$tdata = array(); $title = null; $ld = null;
	foreach ($line as $l) {
		$ld = preg_split("/,/", $l);
		if($Graph >= 30){
			// 1도근처
			if(intval($ld[11]) < 1){
				$ld[1] = '';
				$ld[2] = '';
				$ld[3] = '';
				$ld[4] = '';
				$ld[5] = '';
				$ld[6] = '';
				$ld[7] = '';
				$ld[8] = '';
				$ld[9] = '';
				$ld[10] = '';
			}else{
				$ld[1] = intval($ld[1] / $ld[11]);
				$ld[2] = intval($ld[2] / $ld[11]);
				$ld[3] = intval($ld[3] / $ld[11]);
				$ld[4] = intval($ld[4] / $ld[11]);
				$ld[5] = intval($ld[5] / $ld[11]);
				$ld[6] = intval($ld[6] / $ld[11]);
				$ld[7] = intval($ld[7] / $ld[11]);
				$ld[8] = intval($ld[8] / $ld[11]);
				$ld[9] = intval($ld[9] / $ld[11]);
				$ld[10] = intval($ld[10] / $ld[11]);
			}
			$title = "의 추이의 그래프(1도근처)";
		}else{
			$title = "의 추이의 그래프";
		}
		if($Graph == 1){
			$title = "총 인구{$title}";
			array_push($tdata, intval($ld[1]/100));
		}elseif($Graph == 2){
			$title = "총 자금{$title}";
			array_push($tdata, intval($ld[2]/1000));
		}elseif($Graph == 3){
			$title = "총 면적{$title}";
			array_push($tdata, $ld[3]);
		}elseif($Graph == 4){
			$title = "총 예금{$title}";
			array_push($tdata, $ld[4]);
		}elseif($Graph == 5){
			$title = "총 미사일 발사수{$title}";
			array_push($tdata, intval($ld[5]/10));
		}elseif($Graph == 6){
			$title = "총 농장{$title}";
			array_push($tdata, intval($ld[6]/10));
		}elseif($Graph == 7){
			$title = "총 상업{$title}";
			array_push($tdata, intval($ld[7]/10));
		}elseif($Graph == 8){
			$title = "총 공업{$title}";
			array_push($tdata, intval($ld[8]/10));
		}elseif($Graph == 9){
			$title = "총 양식{$title}";
			array_push($tdata, intval($ld[9]/10));
		}elseif($Graph == 10){
			$title = "총 삼림{$title}";
			array_push($tdata, intval($ld[10]/10));
		}elseif($Graph == 31){
			$title = "총 인구{$title}";
			array_push($tdata, intval($ld[1]/5));
		}elseif($Graph == 32){
			$title = "총 자금{$title}";
			array_push($tdata, intval($ld[2]/50));
		}elseif($Graph == 33){
			$title = "총 면적{$title}";
			array_push($tdata, intval($ld[3]*10));
		}elseif($Graph == 34){
			$title = "총 예금{$title}";
			array_push($tdata, intval($ld[4]*10));
		}elseif($Graph == 35){
			$title = "총 미사일 발사수{$title}";
			array_push($tdata, intval($ld[5]));
		}elseif($Graph == 36){
			$title = "총 농장{$title}";
			array_push($tdata, intval($ld[6]));
		}elseif($Graph == 37){
			$title = "총 상업{$title}";
			array_push($tdata, intval($ld[7]));
		}elseif($Graph == 38){
			$title = "총 공업{$title}";
			array_push($tdata, intval($ld[8]));
		}elseif($Graph == 39){
			$title = "총 양식{$title}";
			array_push($tdata, intval($ld[9]));
		}elseif($Graph == 40){
			$title = "총 삼림{$title}";
			array_push($tdata, intval($ld[10]));
		}

		$allPop = ($ld[1] == '') ? "　" : "{$ld[1]}백명";
		$allMoney = ($ld[2] == '') ? "　" : "{$ld[2]}억엔";
		$allArea = ($ld[3] == '') ? "　" : "{$ld[3]}백만평";
		$allBank = ($ld[4] == '') ? "　" : "{$ld[4]}천억";
		$allMissileA = ($ld[5] == '') ? "　" : "{$ld[5]}발";
		$allFarm		= ($ld[6] == '') ? "　" : "{$ld[6]}천 규모";
		$allTower	= ($ld[7] == '') ? "　" : "{$ld[7]}천 규모";
		$allIndustry = ($ld[8] == '') ? "　" : "{$ld[8]}천 규모";
		$allYousyoku= ($ld[9] == '') ? "　" : "{$ld[9]}백 마리";
		$allForest  = ($ld[10] == '') ? "　" : "{$ld[10]}백개";
		$islandNumber = ($ld[11] == '') ? "　" : "{$ld[11]}$AfterName";
	print(<<<END
<TR>
<TD>{$HtagNumber_}$ld[0]{$H_tagNumber}</TD>
<TD align=right>$allPop</TD>
<TD align=right>$allMoney</TD>
<TD align=right>$allArea</TD>
<TD align=right>$allBank</TD>
<TD align=right>$allMissileA</TD>
<TD align=right>$allFarm</TD>
<TD align=right>$allTower</TD>
<TD align=right>$allIndustry</TD>
<TD align=right>$allYousyoku</TD>
<TD align=right>$allForest</TD>
<TD align=right>$islandNumber</TD></TR>
END
);
	}
	print(<<<END
</TABLE><a name="graph"></a><HR>
막대 그래프 표시[도 전체]
<A HREF="history.php?statistical=1#graph">[총 인구]</A>
<A HREF="history.php?statistical=2#graph">[총 자금]</A>
<A HREF="history.php?statistical=3#graph">[총 면적]</A>
<A HREF="history.php?statistical=4#graph">[총 예금]</A>
<A HREF="history.php?statistical=5#graph">[총 미사일 발사수]</A>
<A HREF="history.php?statistical=6#graph">[총 농장]</A>
<A HREF="history.php?statistical=7#graph">[총 상업]</A>
<A HREF="history.php?statistical=8#graph">[총 공업]</A>
<A HREF="history.php?statistical=9#graph">[총 양식]</A>
<A HREF="history.php?statistical=10#graph">[총 삼림]</A><HR>
막대 그래프 표시[1도]
<A HREF="history.php?statistical=31#graph">[총 인구]</A>
<A HREF="history.php?statistical=32#graph">[총 자금]</A>
<A HREF="history.php?statistical=33#graph">[총 면적]</A>
<A HREF="history.php?statistical=34#graph">[총 예금]</A>
<A HREF="history.php?statistical=35#graph">[총 미사일 발사수]</A>
<A HREF="history.php?statistical=36#graph">[총 농장]</A>
<A HREF="history.php?statistical=37#graph">[총 상업]</A>
<A HREF="history.php?statistical=38#graph">[총 공업]</A>
<A HREF="history.php?statistical=39#graph">[총 양식]</A>
<A HREF="history.php?statistical=40#graph">[총 삼림]</A><HR>
END
);
	if(($Graph != 0) && ($Graph != 30)) {
		printval("<h2>$title</h2>\n");
		printval("<TABLE><TR>\n");
		$d = null; $w = null;
		foreach ($tdata as $d) {
			$w = intval($d / 10);
			printval("<td valign=bottom align=center><br><img src=\"{$gimage}\" width=10 height=$w></td>\n");
		}
		printval("</TABLE><BR><BR>\n");
	}
}
//---------------------------------------------------------------------
//도	의 근황의 링크
//---------------------------------------------------------------------
// 헤더
function tempIslandHeader($id, $name) {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $Hallyflg, $Hallygroup, $Hallymark, $HbgNameCell, $HbgNumberCell, $HbgTitleCell, $HcomL, $HcomLateCt, $HcomName, $HcssFile, $HcurrentID, $HcurrentName, $HcurrentNumber, $HdefaultPassword, $headNameCellcolor, $helpDir, $HidToNumber, $HinputPassword, $HislandList, $HislandNumber, $Hislands, $HislandTurn, $HmasterPassword, $HMode, $hp, $HpasswordFile, $HskinName, $HspecialPassword, $HthisFile, $HtopLogTurn, $HturnPrizeVarious, $imageDir, $lockMode, $toppage, $versionInfo, $defaultID, $Graph, $allyturn;
	if(checkPassword((isset($Hislands[$HidToNumber[$id]]['password']) ? $Hislands[$HidToNumber[$id]]['password'] : $Hislands[$HidToNumber[$id]]), $HinputPassword) && ($HcurrentID == $defaultID)) {
		printval("<HR><span class=lbbsOW><B>[{$name} 의  근황]</B></span>");
	} else {
		printval("<HR><B>[{$name} 의  근황]</B>　");
	}
	if($HinputPassword == '') {
		printval("<A HREF='history.php?ID={$id}&Event=99'>[ALL]</A>");
	} else {
		printval("<A HREF='history.php?ID={$id}&PASSWORD={$HinputPassword}&Event=99'>[ALL]</A> ");
	}
	$i = null; $turn = null;
	for($i = 0;$i < $HtopLogTurn;$i++) {
		$turn = $HislandTurn - $i;
		if (!($turn > 0)) { return; }
		if($HinputPassword == '') {
			printval("<A HREF='history.php?ID={$id}&Event={$i}'>");
		} else {
			printval("<A HREF='history.php?ID={$id}&PASSWORD={$HinputPassword}&Event={$i}'>");
		}
		if($i == 0) {
			printval("[턴{$turn} (현재)]");
		} else {
			printval("[{$turn}]");
		}
		printval("</A>\n");
	}
	printval("<br>\n");
}
//---------------------------------------------------------------------
//  턴 차이 명령
//---------------------------------------------------------------------
function tempCommandLate() {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $Hallyflg, $Hallygroup, $Hallymark, $HbgNameCell, $HbgNumberCell, $HbgTitleCell, $HcomL, $HcomLateCt, $HcomName, $HcssFile, $HcurrentID, $HcurrentName, $HcurrentNumber, $HdefaultPassword, $headNameCellcolor, $helpDir, $HidToNumber, $HinputPassword, $HislandList, $HislandNumber, $Hislands, $HislandTurn, $HmasterPassword, $HMode, $hp, $HpasswordFile, $HskinName, $HspecialPassword, $HthisFile, $HtopLogTurn, $HturnPrizeVarious, $imageDir, $lockMode, $toppage, $versionInfo, $defaultID, $Graph, $allyturn;
	$i = null; $turn = null; $turn2 = null; $id = null; $kind = null; $target = null; $x = null; $y = null; $arg = null; $x2 = null; $y2 = null; $name = null; $tName = null;
	printval("<H1>턴 차이 명령 일람 {$HislandTurn}턴</H1>");
	if($HcomLateCt <= 0){
		printval("현재, 턴 차이 명령은 없습니다.");
		return;
	}
	printval("<TABLE border=1><TR><TH $HbgTitleCell>공격 턴</TH><TH {$HbgTitleCell}등록 턴</TH><TH $HbgTitleCell>실행{$AfterName}</TH><TH $HbgTitleCell>명령</TH><TH $HbgTitleCell>목표{$AfterName}</TH><TH $HbgTitleCell>좌표X</TH><TH $HbgTitleCell>좌표Y</TH><TH $HbgTitleCell>수량</TH><TH $HbgTitleCell>좌표2X</TH><TH $HbgTitleCell>좌표2Y</TH></TR>");
	for($i = (count($HcomL) - 1); $i >= 0; $i--){
		$turn	= $HcomL[$i]['turn'];
		$turn2	= $HcomL[$i]['turn2'];
		$id		= $HcomL[$i]['id'];
		$kind	= $HcomL[$i]['kind'];
		$target	= $HcomL[$i]['target'];
		$x		= $HcomL[$i]['x'];
		$y		= $HcomL[$i]['y'];
		$arg	= $HcomL[$i]['arg'];
		$x2		= $HcomL[$i]['x2'];
		$y2		= $HcomL[$i]['y2'];
		$tn = null; $tIsland = null;
		$tn = $HidToNumber[$id];
		if($tn != ''){
			$tIsland = $Hislands[$tn];
			$name = $tIsland['name'] . $AfterName;
		}else{
			$name = "　";
		}
		$tn = $HidToNumber[$target];
		if($tn != ''){
			$tIsland = $Hislands[$tn];
			$tName = $tIsland['name'] . $AfterName;
		}else{
			$tName = "　";
		}
		printval("<TR><TD>$turn</TD><TD>$turn2</TD><TD>$name</TD><TD>{$HcomName[$kind]}</TD><TD>$tName</TD><TD>$x</TD><TD>$y</TD><TD>$arg</TD><TD>$x2</TD><TD>$y2</TD></TR>");
	}
	printval("</TABLE>\n");
	printval("※　{$AfterName}명이 표시되지 않은 명령은, 방폐등을 위해서 실행되지 않습니다.<BR><BR>\n");
}
//---------------------------------------------------------------------
// 진영 이력
//---------------------------------------------------------------------
function tempAlly() {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $Hallyflg, $Hallygroup, $Hallymark, $HbgNameCell, $HbgNumberCell, $HbgTitleCell, $HcomL, $HcomLateCt, $HcomName, $HcssFile, $HcurrentID, $HcurrentName, $HcurrentNumber, $HdefaultPassword, $headNameCellcolor, $helpDir, $HidToNumber, $HinputPassword, $HislandList, $HislandNumber, $Hislands, $HislandTurn, $HmasterPassword, $HMode, $hp, $HpasswordFile, $HskinName, $HspecialPassword, $HthisFile, $HtopLogTurn, $HturnPrizeVarious, $imageDir, $lockMode, $toppage, $versionInfo, $defaultID, $Graph, $allyturn;
	$logturn = null; $i = null;
	if ($allyturn == 0) { $allyturn = 'log'; }
	printval("<H1>진영의 이력</H1>");
	if (!(($Hallyflg) && (hako_open('LIN', "{$HlogdirName}/ally.$allyturn")))) {
		printval("진영의 과거 데이터가, 없습니다.");
		return;
	}
	print(<<<END
<TABLE BORDER><TR>
<TH $HbgTitleCell>{$HtagTH_}턴{$H_tagTH}</TH>
<TH $HbgTitleCell colspan=100>{$HtagTH_}점유율{$H_tagTH}</TH>
</TR>
END
);
	$turn = null; $line = null; $ally = null; $apop = null;
	$allyCount = null; $allyPop = null; $allyArea = null; $allyGnp = null; $allyPow = null; $amark = null;
	$turn = 0;
	while (($line = hako_getline('LIN')) !== false) {
		// 턴, 진영 ID, 도수, 총인구, 계승자, 총경제력, 전군사력
		$ally = preg_split("/,/", $line);
		$ally[7] = rtrim($ally[7]);
		$apop = intval($ally[7]);
		if($turn != $ally[0]){
			if ($turn != 0) { printval("</TR>"); }
			$turn = $ally[0];
			printval("<TR><TD $HbgNumberCell>{$HtagNumber_}$turn{$H_tagNumber}</TD>");
			$apop++;
		}
		if($ally[1] == 0){
			printval("<TD $HbgNameCell colspan=$apop>" . $Hallygroup[$ally[1]] . "　(" . $ally[7] . "%)</TD>");
		}else{
			printval("<TD $HbgNameCell colspan=$apop>" . $Hallymark[$ally[1]] . $HtagTH_ . $Hallygroup[$ally[1]] . $H_tagTH . "　 (" . $ally[7] . "%)</TD>");
		}
	}
	hako_close('LIN');
	printval("</TR></TABLE>");
	printval("※　점유율은, 인구로 부터 산출됩니다.<br><br>");
	printval("과거의 데이터 <A HREF=\"history.php?ally=0\">[최신]</a> ");
	$logturn = $HislandTurn - $HturnPrizeVarious - ($HislandTurn % $HturnPrizeVarious);
	for($i = 0;$i < 5;$i++){
		if ($logturn <= 0) { return; }
		printval("<A HREF=\"history.php?ally=$logturn\">[$logturn]</a> ");
		$logturn -= $HturnPrizeVarious;
	}
}
//---------------------------------------------------------------------
// 로그 파일 타이틀
//---------------------------------------------------------------------
function logDekigoto() {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $Hallyflg, $Hallygroup, $Hallymark, $HbgNameCell, $HbgNumberCell, $HbgTitleCell, $HcomL, $HcomLateCt, $HcomName, $HcssFile, $HcurrentID, $HcurrentName, $HcurrentNumber, $HdefaultPassword, $headNameCellcolor, $helpDir, $HidToNumber, $HinputPassword, $HislandList, $HislandNumber, $Hislands, $HislandTurn, $HmasterPassword, $HMode, $hp, $HpasswordFile, $HskinName, $HspecialPassword, $HthisFile, $HtopLogTurn, $HturnPrizeVarious, $imageDir, $lockMode, $toppage, $versionInfo, $defaultID, $Graph, $allyturn;
	print(<<<END
<H1>최근의 사건</H1>
END
);
}
//---------------------------------------------------------------------
//	로그 파일 모두 표시
//---------------------------------------------------------------------
function logFilePrintAll() {
    global $HtopLogTurn;
    $max = intval($HtopLogTurn);
    if ($max <= 0) { $max = 10; }
    for ($i = 0; $i < $max; $i++) {
        logFilePrint($i, 0, 0);
    }
}
//---------------------------------------------------------------------
// 개별 로그 표시
//---------------------------------------------------------------------
function logPrintLocal($mode) {
    global $HtopLogTurn, $HcurrentID;
    $max = intval($HtopLogTurn);
    if ($max <= 0) { $max = 10; }
    for ($i = 0; $i < $max; $i++) {
        logFilePrint($i, $HcurrentID, $mode);
    }
}
//---------------------------------------------------------------------
//	파일 번호 지정으로 로그 표시
//---------------------------------------------------------------------
function logFilePrint($fileNumber, $id, $mode) {
    global $HtagNumber_, $H_tagNumber;
    $paths = function_exists('hako_history_log_file_candidates') ? hako_history_log_file_candidates($fileNumber) : array(history_log_path('hakojima.log'.$fileNumber));
    $fp = false;
    foreach ($paths as $path) {
        if ($path !== '' && file_exists($path) && is_readable($path)) { $fp = @fopen($path, 'r'); break; }
    }
    if (!$fp) { return; }
    $set_turn = 0;
    while (($line = fgets($fp)) !== false) {
        $line = rtrim($line, "\r\n");
        if ($line === '') { continue; }
        if (!preg_match('/^([0-9]*),([0-9]*),([0-9]*),([0-9]*),(.*)$/', $line, $mm)) {
            if ($set_turn == 0) {
                printval("<NOBR><B>=====[<span class=number><FONT SIZE=4> 로그 </FONT></span>]================================================</B><NOBR><BR>\n");
                $set_turn = 1;
            }
            printval("<NOBR>　".$line."</NOBR><BR>\n");
            continue;
        }
        $mflag = $mm[1]; $turn = $mm[2]; $id1 = $mm[3]; $id2 = $mm[4]; $message = $mm[5];
        if ($mflag == 1) {
            if (($mode == 0) || ($id1 != $id)) { continue; }
            $mflag = "{$HtagNumber_}<B>(기밀)</B>{$H_tagNumber}:";
        } else {
            $mflag = '';
        }
        if ($id != 0) {
            if (($id != $id1) && ($id != $id2)) { continue; }
        }
        if ($set_turn == 0) {
            printval("<NOBR><B>=====[<span class=number><FONT SIZE=4> 턴$turn </FONT></span>]================================================</B><NOBR><BR>\n");
            $set_turn = 1;
        }
        printval("<NOBR>　{$mflag}{$message}</NOBR><BR>\n");
    }
    fclose($fp);
}
