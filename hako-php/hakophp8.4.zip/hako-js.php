<?php
if (!isset($_hako_fh)) { $_hako_fh = array(); }
if (!function_exists('hako_out')) { function hako_out($s) { echo $s; } }
if (!function_exists('out')) { function out($s) { echo $s; } }
if (!function_exists('htmlEscape')) { function htmlEscape($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); } }
if (!function_exists('hako_open')) {
  function hako_open($name, $spec) { global $_hako_fh;
$mode='r'; $path=$spec; if (substr($path,0,2)==='>>') { $mode='a'; $path=substr($path,2); } elseif (substr($path,0,1)==='>') { $mode='w'; $path=substr($path,1); } elseif (substr($path,0,1)==='<') { $mode='r'; $path=substr($path,1); } $_hako_fh[$name]=@fopen($path,$mode); return $_hako_fh[$name]; }
  function hako_close($name) { global $_hako_fh;
if (isset($_hako_fh[$name]) && is_resource($_hako_fh[$name])) fclose($_hako_fh[$name]); }
  function hako_getline($name) { global $_hako_fh;
if (!isset($_hako_fh[$name]) || !$_hako_fh[$name]) return false; return fgets($_hako_fh[$name]); }
  function hako_write($name,$data) { global $_hako_fh;
if (!isset($_hako_fh[$name]) || !$_hako_fh[$name]) return false; return fwrite($_hako_fh[$name],$data); }
}
?>
<?php
// Function-unit retranslation from hako-js.php.

if (!function_exists('tempOwnerJava')) {
function tempOwnerJava() {
extract($GLOBALS, EXTR_SKIP);
$escapedDefaultPassword = htmlEscape(isset($GLOBALS['HdefaultPassword']) ? $GLOBALS['HdefaultPassword'] : '');
  echo <<<HEDOC_tempOwnerJava_0
<SCRIPT Language="JavaScript">
<!--
// JAVA 스크립트 개발 화면 배포원
// -암모형정원 제도( http://appoh.execweb.cx/hakoniwa/ )
// Programmed by Jynichi Sakai(―)
// ↑ 삭제하지 마세요.
var xmlhttp;
var str;
g = [$com_max];
k1 = [$com_max];
k2 = [$com_max];
tmpcom1 = [ [0,0,0,0,0,0,0] ];
tmpcom2 = [ [0,0,0,0,0,0,0] ];
command = [$set_com];
comlist = [$set_listcom];
islname = {$set_island};
function init(){
	for(i = 0; i < command.length ;i++) {
		for(s = 0; s < $com_count ;s++) {
			var comlist2 = comlist[s];
			for(j = 0; j < comlist2.length ; j++) {
				if(command[i][0] == comlist2[j][0]) {
					g[i] = comlist2[j][1];
				}
			}
		}
	}
	outp();
	str = plchg();
	str = "<TABLE border=0><TR><TD class='commandjs1'><B>◎◎◎◎ 송신이 끝난 상태 ◎◎◎◎</B><br><br>"+str+"<br><B>◎◎◎◎ 송신이 끝난 상태 ◎◎◎◎</B></TD></TR></TABLE>";
	disp(str, "#ccffcc");
	xmlhttp = new_http();
	if(document.layers) {
		document.captureEvents(Event.MOUSEMOVE | Event.MOUSEUP);
	}
	document.onmouseup   = Mup;
	document.onmousemove = Mmove;
	document.onkeydown = Kdown;
	document.ch_numForm.AMOUNT.options.length = 69;
	for(i=0;i<document.ch_numForm.AMOUNT.options.length;i++){
		document.ch_numForm.AMOUNT.options[i].value = i;
		document.ch_numForm.AMOUNT.options[i].text  = i;
		if(i>=50){
			document.ch_numForm.AMOUNT.options[i].value = (i-49) * 50;
			document.ch_numForm.AMOUNT.options[i].text  = (i-49) * 50;
		}
	}
	document.myForm.CommandJavaButton$Hislands[$HcurrentNumber]->{'id'}.disabled = true;
	ns(0);
}

function cominput(theForm, x, k, pp, z) {
	a = theForm.NUMBER.options[theForm.NUMBER.selectedIndex].value;
	b = theForm.COMMAND.options[theForm.COMMAND.selectedIndex].value;
	c = theForm.POINTX.options[theForm.POINTX.selectedIndex].value;
	d = theForm.POINTY.options[theForm.POINTY.selectedIndex].value;
	e = theForm.AMOUNT.options[theForm.AMOUNT.selectedIndex].value;
	f = theForm.TARGETID.options[theForm.TARGETID.selectedIndex].value;
	cc = theForm.POINTTX.options[theForm.POINTTX.selectedIndex].value;
	dd = theForm.POINTTY.options[theForm.POINTTY.selectedIndex].value;
	var newNs = a;
	if(x == 8){x = 6;e = 22}
	if(x == 1 || x == 2 || x == 6){
		if(x == 6){
			b = k;
			if(pp != 0) {e = pp;}
		}
		if(x != 2) {
			for(i = $HcommandMax - 1; i > a; i--) {
				command[i] = command[i-1];
				g[i] = g[i-1];
			}
		}
		for(s = 0; s < $com_count ;s++) {
			var comlist2 = comlist[s];
			for(i = 0; i < comlist2.length; i++){
				if(comlist2[i][0] == b){
					g[a] = comlist2[i][1];
					break;
				}
			}
		}
		command[a] = [b,c,d,e,f,cc,dd];
		newNs++;
		menuclose();
	}else if(x == 3){
		var num = (k) ? k-1 : a;
		for(i = Math.floor(num); i < ($HcommandMax - 1); i++) {
			command[i] = command[i + 1];
			g[i] = g[i+1];
		}
		command[$HcommandMax-1] = [97,0,0,0,0,0,0];
		g[$HcommandMax-1] = '자금 융통';
	}else if(x == 4){
		i = Math.floor(a)
		if (i == 0){ return true; }
		i = Math.floor(a)
		tmpcom1[i] = command[i];tmpcom2[i] = command[i - 1];
		command[i] = tmpcom2[i];command[i-1] = tmpcom1[i];
		k1[i] = g[i];k2[i] = g[i - 1];
		g[i] = k2[i];g[i-1] = k1[i];
		newNs = i-1;
	}else if(x == 5){
		i = Math.floor(a)
		if (i == $HcommandMax-1){ return true; }
		tmpcom1[i] = command[i];tmpcom2[i] = command[i + 1];
		command[i] = tmpcom2[i];command[i+1] = tmpcom1[i];
		k1[i] = g[i];k2[i] = g[i + 1];
		g[i] = k2[i];g[i+1] = k1[i];
		newNs = i+1;
	}else if(x == 7){
		// 이동
		var ctmp = command[k];
		var gtmp = g[k];
		if(z > k) {
			// 위에서 밑으로
			for(i = k; i < z-1; i++) {
				command[i] = command[i+1];
				g[i] = g[i+1];
			}
		} else {
			// 아래에서 위에
			for(i = k; i > z; i--) {
				command[i] = command[i-1];
				g[i] = g[i-1];
			}
		}
		command[i] = ctmp;
		g[i] = gtmp;
	}else if(x == 9){
		command[a][3] = k;
	}

	str = plchg();
	str = "<TABLE border=0><TR><TD class='commandjs2'><B>◎◎◎◎◎미송신◎◎◎◎◎</B><br><br>"+str+"<br><B>◎◎◎◎◎미송신◎◎◎◎◎</B></TD></TR></TABLE>";
	disp(str, "white");
	outp();
	theForm.CommandJavaButton$Hislands[$HcurrentNumber]->{'id'}.disabled = false;
	ns(newNs);
	return true;
}

function plchg(){
	strn1 = "";
	for(i = 0; i < $HcommandMax; i++)	{
		c = command[i];
		kind = '$HtagComName_' + g[i] + '$H_tagComName';
		x = c[1];
		y = c[2];
		tgt = c[4];
		xx = c[5];
		yy = c[6];
		point = '{$HtagName_}(' + x + ',' + y + '){$H_tagName}';
		point2 = '{$HtagName_}(' + xx + ',' + yy + '){$H_tagName}';
		if(tgt == ''){
			tgt = '$HtagName_' + '무인' + '{$AfterName}{$H_tagName}';
		}else{
			tgt = '$HtagName_' + islname[tgt] + '{$AfterName}{$H_tagName}';
		}
		if(c[0] == $HcomDoNothing || c[0] == $HcomGiveup || c[0] == $HcomSMissileMGM){ // 자금융통, 도의 방폐
			strn2 = kind;
		}else if(c[0] == $HcomMissileNM || // 미사일 관련
			c[0] == $HcomMissilePP ||
			c[0] == $HcomBioMissile ||
			c[0] == $HcomMissileSPP ||
			c[0] == $HcomMissileST ||
			c[0] == $HcomMissileRM ||
			c[0] == $HcomMissileSRM ||
			c[0] == $HcomMissileGM ||
			c[0] == $HcomMissilePLD ||
			c[0] == $HcomMissileNCM ||
			c[0] == $HcomMissileDM ||
			c[0] == $HcomSMissileGM ||
			c[0] == $HcomSMissilePP ||
			c[0] == $HcomSMissile ||
			c[0] == $HcomOMissileNM ||
			c[0] == $HcomOMissilePP ||
			c[0] == $HcomOMissileSPP ||
			c[0] == $HcomMissileRNG ||
			c[0] == $HcomMissileLD) {
			if(c[0] == $HcomSMissileGM || c[0] == $HcomSMissilePP || c[0] == $HcomSMissile) {
				tgt = '$HtagName_' + "$SpaceName" + '{$H_tagName}';
			}else if(c[0] == $HcomOMissileNM || c[0] == $HcomOMissilePP || c[0] == $HcomOMissileSPP) {
				tgt = '$HtagName_' + "$OceanName" + '{$H_tagName}';
			}
			if(c[0] == $HcomMissileGM) { c[3] = 1; }
			if(c[3] == 0){
				arg = '({$HtagName_}무제한{$H_tagName})';
			} else {
				arg = '($HtagName_' + c[3] + '발{$H_tagName})';
			}
			strn2 = tgt + point + " 에 " + kind + arg;
		}else if(c[0] == $HcomMissileMGM) {
			strn2 = tgt + " 에 " + kind;
		}else if(c[0] == $Hcomcolony) {
			if(c[3] == 1 || c[3] == 2){
				strn2 = "슈퍼 쉴드(shield) 시스템 발동!" + '(' + c[3] + ')';
			}else{
				strn2 = tgt + " 에" + kind;
			}
		}else if(c[0] == $HcomTeisatu || c[0] == $HcomSpy) { // 공작원, 정찰
			strn2 = tgt + point + " 에 " + kind;
		}else if(c[0] == $HcomSendMonster){ // 괴수 파견
			if(c[3] == 1){
				strn2 = tgt + '{$HtagName_}에 메카지라 파견{$H_tagName}';
			} else if(c[3] == 2){
				strn2 = tgt + '{$HtagName_}에 그라테네스 이노라 파견{$H_tagName}';
			} else if(c[3] == 3){
				strn2 = tgt + '{$HtagName_}에 해저 메카 이노라 파견{$H_tagName}';
			} else {
				strn2 = tgt + '{$HtagName_}에 메카 이노라 파견{$H_tagName}';
			}
		}else if(c[0] == $HcomSSendMonster) {
			strn2 = tgt + '에' + kind + '{$HtagName_}(' + c[3] + '){$H_tagName}';
		}else if(c[0] == $HcomSell){ // 식량 매각
			if(c[3] == 0){ c[3] = 1; }
			arg = c[3] * 100;
			arg = '$HtagName_' + arg + '$HunitFood{$H_tagName}';
			strn2 = kind + arg;
		}else if(c[0] == $HcomOreSell || c[0] == $HcomOilSell || c[0] == $HcomWeponSell){ // 매각
			if(c[3] == 0){ c[3] = 1; }
			arg = '$HtagName_(' + c[3] + '){$H_tagName}';
			strn2 = tgt + " 에 " + kind + arg;
		}else if(c[0] == $HcomOreBuy || c[0] == $HcomOilBuy || c[0] == $HcomWeponBuy){ // 구입
			if(c[3] == 0){ c[3] = 1; }
			arg = '$HtagName_(' + c[3] + '){$H_tagName}';
			strn2 = kind + arg;
		}else if(c[0] == $HcomWarp){ // 전이 장치
			if(c[3] == 0) {
				strn2 = point + "으로 " + kind + "(" + tgt + ")";
			} else {
				if(c[3] == 1) {
					direction = "오른쪽 위";
				} else if(c[3] == 2) {
					direction = "오른쪽";
				} else if(c[3] == 3) {
					direction = "오른쪽 아래";
				} else if(c[3] == 4) {
					direction = "왼쪽 아래";
				} else if(c[3] == 5) {
					direction = "왼쪽";
				} else {
					c[3] = 6;
					direction= "왼쪽 위";
				}
				kind = '$HtagComName_' + "전이 지정 장치 건설" + '$H_tagComName';
				strn2 = point + "으로 " + kind + '({$HtagName_}' + direction + '{$H_tagName})';
			}
		}else if(c[0] == $HcomPropaganda){ // 유치 활동
			if(c[3] == 0){
				strn2 = kind;
			} else {
				strn2 = kind + '($HtagName_' + c[3] + '회{$H_tagName})';
			}
		}else if(c[0] == $HcomMoney){ // 자금원조

			if(c[3] == 0){ c[3] = 1; }
			arg = c[3] * $HcomCost[$HcomMoney];
			arg = '($HtagName_' + arg + '$HunitMoney{$H_tagName})';
			strn2 = tgt + " 에 " + kind + arg;
		}else if(c[0] == $HcomFood){ // 식량 원조

			if(c[3] == 0){ c[3] = 1; }
			arg = c[3] * 100;
			arg = '($HtagName_' + arg + '$HunitFood{$H_tagName})';
			strn2 = tgt + " 에 " + kind + arg;
		}else if(c[0] == $HcomEmigration){ // 이민
			strn2 = point + "사람을" + tgt + " 에 " + kind;
		}else if(c[0] == $HcomDestroy){ // 굴착

			if(c[3] == 0){
				strn2 = point + "으로 " + kind;
			} else {
				arg = c[3] * $HcomCost[$HcomDestroy];
				arg = '(예산$HtagName_' + arg + '$HunitMoney{$H_tagName})';
				strn2 = point + "으로 " + kind + arg;
			}
		}else if(c[0] == $HcomSearch || c[0] == $HcomBank){ // 지질 조사, 은행 투자

			arg = c[3] * $HcomCost[$HcomSearch];
			if(arg == 0) {
				arg = $HcomCost[$HcomSearch]
			}
			arg = '(예산$HtagName_' + arg + '$HunitMoney{$H_tagName})';
			strn2 = point + "으로 " + kind + arg;
		}else if(c[0] == $HcomDummy){ // 더미
			if(c[3] == 1) {
				strn2 = point + '{$HtagName_}로 더미 채굴장{$H_tagName}';
			} else if(c[3] == 2) {
				strn2 = point + '{$HtagName_}로 더미 매립{$H_tagName}';
			} else {
				strn2 = point + '{$HtagName_}로 더미 농장{$H_tagName}';
			}
		}else if(c[0] == $HcomManipulate || c[0] == $HcomSTManipulate || c[0] == $HcomShipM){
			// 괴수 조작, ST괴수 조작, 배조작
			if(c[3] <= 1) {
				c[3] = 1;
				direction = "오른쪽 위";
			} else if(c[3] == 2) {
				direction = "오른쪽";
			} else if(c[3] == 3) {
				direction = "오른쪽 아래";
			} else if(c[3] == 4) {
				direction = "왼쪽 아래";
			} else if(c[3] == 5) {
				direction = "왼쪽";
			} else {
				c[3] = 6;
				direction= "왼쪽 위";
			}
			if(c[0] == $HcomMonsEnsei){
				strn2 = kind + '({$HtagName_}' + direction + '{$H_tagName})';
			}else{
				strn2 = tgt + " 에 " + kind + '({$HtagName_}' + direction + '{$H_tagName})';
			}
		}else if(c[0] == $HcomMonument){ // 기념비
			if(c[3] == 0) {
				strn2 = point + "으로 " + kind + '({$HtagName_}모노리스{$H_tagName})' + tgt;
			} else if(c[3] == 1) {
				strn2 = point + "으로 " + kind + '({$HtagName_}평화 기념비{$H_tagName})' + tgt;
			} else if(c[3] == 2) {
				strn2 = point + "으로 " + kind + '({$HtagName_}싸움의 비{$H_tagName})' + tgt;
			} else if(c[3] == 3) {
				strn2 = point + "으로 " + kind + '({$HtagName_}염가 기념비{$H_tagName})' + tgt;
			} else {
				strn2 = point + "으로 " + kind;
			}
		}else if(c[0] == $HcomSMonument){ // 해저 기념비
			if(c[3] == 0) {
				strn2 = point + "으로 " + kind + '({$HtagName_}해저 기념비{$H_tagName})' + tgt;
			} else if(c[3] == 1) {
				strn2 = point + "으로 " + kind + '({$HtagName_}해저 기념비(파랑){$H_tagName})' + tgt;
			} else {
				strn2 = point + "으로 " + kind;
			}
		}else if(c[0] == $HcomDbase){
			if(c[3] == 1) {
				strn2 = point + "으로 " + kind + '({$HtagName_}ST{$H_tagName})';
			} else if(c[3] == 2) {
				strn2 = point + "으로 " + kind + '({$HtagName_}안개{$H_tagName})';
			} else {
				strn2 = point + "으로 " + kind;
			}
		}else if(c[0] == $HcomFarm || // 여러 차례 있을 계획
			c[0] == $HcomFactory ||
			c[0] == $HcomSFarm ||
			c[0] == $HcomTower ||
			c[0] == $HcomPort ||
			c[0] == $HcomBase ||
			c[0] == $HcomMountain) {
			if(c[3] != 0){
				arg = '($HtagName_' + c[3] + '회{$H_tagName})';
				strn2 = point + "으로 " + kind + arg;
			}else{
				strn2 = point + "으로 " + kind;
			}
		}else if(c[0] == $HcomPresent || c[0] == $HcomPresentAid){ // 선물, 선물 양도
			if(c[3] <= 0) {
				c[3] = 0;
				pres = "공원";
			} else if(c[3] == 1) {
				pres = "스타디움";
			} else if(c[3] == 2) {
				pres = "돔";
			} else if(c[3] == 3) {
				pres = "카지노";
			} else if(c[3] == 4) {
				pres = "유원지";
			} else if(c[3] == 5) {
				pres = "학교";
			} else if(c[3] == 6) {
				pres = "공항";
			} else if(c[3] == 7) {
				pres = "대도시";
			} else if(c[3] == 8) {
				pres = "동물원";
			} else if(c[3] == 9) {
				pres= "박람회";
			} else if(c[3] == 10) {
				pres= "괴수 기념비";
			} else {
				c[3] = 11;
				pres= "재해의 비";
			}
			if(c[0] == $HcomPresent) {
				strn2 = point + "으로 " + kind + '({$HtagName_}' + pres + '{$H_tagName})';
			} else {
				strn2 = tgt + " 에 " + kind + '({$HtagName_}' + pres + '{$H_tagName})';
			}
		// 괴수 배틀

		} else if(c[0] == $HcomMonsEgg ||
			c[0] == $HcomMonsEsa ||
			c[0] == $HcomMonsTettai ||
			c[0] == $HcomMonsExer ||
			c[0] == $HcomMonsSell) {
			strn2 = kind;
		} else if(c[0] == $HcomMonsEnsei ||
			c[0] == $HcomMonsEsaAid ||
			c[0] == $HcomMonsAid) {
			strn2 = tgt + " 에 " + kind;
		// 지하계
		} else if(c[0] == $HcomUg){
			if(c[3] == 0) {
				strn2 = point + "의 지하" + point2 + "으로 "+ kind + '({$HtagName_}지하 도시 건설{$H_tagName})';
			} else if(c[3] == 1) {
				strn2 = point + "의 지하" + point2 + "으로 "+ kind + '({$HtagName_}지하 농장 건설{$H_tagName})';
			} else if(c[3] == 2) {
				strn2 = point + "의 지하" + point2 + "으로 "+ kind + '({$HtagName_}지하 공장 건설{$H_tagName})';
			} else if(c[3] == 3) {
				strn2 = point + "의 지하" + point2 + "으로 "+ kind + '({$HtagName_}지하 미사일 기지 건설{$H_tagName})';
			} else if(c[3] == 4) {
				strn2 = point + "의 지하" + point2 + "으로 "+ kind + '({$HtagName_}지하 합성석유 공장 건설{$H_tagName})';
			} else {
				strn2 = point + "의 지하" + point2 + "으로 "+ kind;
			}
		} else if(c[0] == $HcomShip) {
			// 배지령 변경
			if(c[3] <= 0) {
				c[3] = 0;
				pres = "특수";
			} else if(c[3] == 1) {
				pres = "이동";
			} else if(c[3] == 2) {
				pres = "방어";
			} else if(c[3] == 3) {
				pres = "후퇴";
			} else if(c[3] >= 4) {
				pres = "공격";
				c[3] = 4;
			}
			strn2 = tgt + point + " 에 " + kind + '({$HtagName_}' + pres + '{$H_tagName})';
		} else if(c[0] == $HcomShipbuild) {
			// 조선
			strn2 = point + "으로 " + kind + '({$HtagName_}' + c[3] + '{$H_tagName})';
		} else if(c[0] == $HcomSBuild) {
			// 우주 건설계
			strn2 = "향후 확장 예정 명령(아무것도 일어나지 않습니다)";
		} else if(c[0] == $HcomSUnit || c[0] == $HcomSpaceFarm || c[0] == $HcomSFactory || c[0] == $HcomSpaceBase) {
			tgt = '$HtagName_' + "$SpaceName" + '{$H_tagName}';
			if(c[3] != 0){
				arg = '($HtagName_' + c[3] + '회{$H_tagName})';
				strn2 = tgt + point + "으로 " + kind + arg;
			}else{
				strn2 = tgt + point + "으로 " + kind;
			}
		} else if(c[0] == $HcomSPioneer || c[0] == $HcomSOccupy || c[0] == $HcomSDestroy || c[0] == $HcomSDbase) {
			tgt = '$HtagName_' + "$SpaceName" + '{$H_tagName}';
			strn2 = tgt + point + "으로 " + kind;
		} else if(c[0] == $HcomSEisei){
			if(c[3] <= 0) {
				c[3] = 0;
				pres = "$HsEisei[0]";
			} else if(c[3] == 1) {
				pres = "$HsEisei[1]";
			} else if(c[3] == 2) {
				pres = "$HsEisei[2]";
			} else if(c[3] == 3) {
				pres = "$HsEisei[3]";
			} else if(c[3] >= 4) {
				pres = "$HsEisei[4]";
				c[3] = 4;
			}
			tgt = '$HtagName_' + "$SpaceName" + '{$H_tagName}';
			strn2 = tgt + point + " 에 " + kind + '({$HtagName_}' + pres + '{$H_tagName})';
		} else if(c[0] == $HcomSFood) {
			// 우주 식량 발사
			if(c[3] == 0){ c[3] = 1; }
			arg = c[3] * 100;
			arg = '($HtagName_' + arg + '$HunitFood{$H_tagName})';
			strn2 = kind + arg;
		} else if(c[0] == $HcomPrepare2 && c[3] == 22) {
			strn2 = '$HtagComName_' + "황무지 모두 땅 고르기" + '{$H_tagComName}';
		}else{
			strn2 = point + "으로 " + kind;
		}
		tmpnum = '';
		if(i < 9){ tmpnum = '0'; }
		strn1 += 
			'<div id="com_'+i+'" '+
			'onmouseover="mc_over('+i+');return false;" '+
			'><A STYLE="text-decoration:none;color:000000" HREF="JavaScript:void(0);" onClick="ns(' + i + ')" '+
			'onmousedown="return comListMove('+i+');" '+
			'ondblclick="chNum('+c[3]+');return false;" '+
			'><NOBR>' + tmpnum + (i + 1) + ':' + strn2 + '</NOBR></A></div>';
	}
	return strn1;
}

function disp(str,bgclr){
	if(str==null)  str = "";

	if(document.getElementById || document.all){
		LayWrite('LINKMSG1', str);
	} else if(document.layers) {
		lay = document.layers["PARENT_LINKMSG"].document.layers["LINKMSG1"];
		lay.document.open();
		lay.document.write("<font style='font-size:11pt'>"+str+"</font>");
		lay.document.close(); 
	}
}

function outp(){
	comary = "";
	for(k = 0; k < command.length; k++){
	comary = comary + command[k][0]
	+" "+command[k][1]
	+" "+command[k][2]
	+" "+command[k][3]
	+" "+command[k][4]
	+" "+command[k][5]
	+" "+command[k][6]
	+" ";
	}
	document.myForm.COMARY.value = comary;
}

function ps(x, y) {
	if(document.myForm.xy1.checked){
		document.myForm.POINTX.options[x].selected = true;
		document.myForm.POINTY.options[y].selected = true;
		document.allForm.POINTX.value = x;
		document.allForm.POINTY.value = y;
	}
	if(document.myForm.xy2.checked){
		document.myForm.POINTTX.options[x].selected = true;
		document.myForm.POINTTY.options[y].selected = true;
		document.allForm.POINTTX.value = x;
		document.allForm.POINTTY.value = y;
	}
	if(!(document.myForm.MENUOPEN.checked)) {
		if(document.myForm.MENUOPEN2.checked) {
			moveLAYER("menu2",mx+10,my-50);
		} else {
			moveLAYER("menu",mx+10,my-50);
		}
	}
	return true;
}

function SelectPOINT(){
	if(document.myForm.xy1.checked){
		document.allForm.POINTX.value = document.myForm.POINTX.options[document.myForm.POINTX.selectedIndex].value;
		document.allForm.POINTY.value = document.myForm.POINTY.options[document.myForm.POINTY.selectedIndex].value;
	}
	if(document.myForm.xy2.checked){
		document.allForm.POINTTX.value = document.myForm.POINTTX.options[document.myForm.POINTTX.selectedIndex].value;
		document.allForm.POINTTY.value = document.myForm.POINTTY.options[document.myForm.POINTTY.selectedIndex].value;
	}
	document.allForm.submit();
}

function ns(x) {
	if (x == $HcommandMax){ return true; }
	document.myForm.NUMBER.options[x].selected = true;
	document.allForm.NUMBER.value = x;
	selCommand(x);
	return true;
}
function openCUSTOM(){
	document.customform.submit();
}
function openCAMP(){
	document.campform.submit();
}
function openBBS(){
	document.bbsform.submit();
}
function openCHAT(){
	document.chatform.submit();
}
function set_com(x, y, land) {
	com_str = land + "\\n";
	for(i = 0; i < $HcommandMax; i++){
		c = command[i];
		x2 = c[1];
		y2 = c[2];
		if(x == x2 && y == y2 && c[0] < 50){
			com_str += "[" + (i + 1) +"]" ;
			kind = g[i];
			if(c[0] == $HcomDestroy){
				if(c[3] == 0){
					com_str += kind;
				} else {
					arg = c[3] * 200;
					arg = "(예산" + arg + "$HunitMoney)";
					com_str += kind + arg;
				}
			}else if(c[0] == $HcomFarm ||
				c[0] == $HcomFactory ||
				c[0] == $HcomMountain) {
				if(c[3] != 0){
					arg = "(" + c[3] + "회)";
					com_str += kind + arg;
				}else{
					com_str += kind;
				}
			}else{
				com_str += kind;
			}
			com_str += " ";
		}
	}
	document.myForm.COMSTATUS.value= com_str;
}

function not_com() {
//	document.myForm.COMSTATUS.value="";
}

function jump(theForm, j_mode) {
	var sIndex = theForm.TARGETID.selectedIndex;
	var url = theForm.TARGETID.options[sIndex].value;
	if (url != "" ) window.open("$HthisFile?IslandMap=" +url+"&JAVAMODE="+j_mode, "", "menubar=yes,toolbar=no,location=no,directories=no,status=yes,scrollbars=yes,resizable=yes,width=570,height=600");
}
function jumps(j_mode,str) {
	window.open("$HthisFile?IslandMap=" + str + "&JAVAMODE="+j_mode, "", "menubar=yes,toolbar=no,location=no,directories=no,status=yes,scrollbars=yes,resizable=yes,width=570,height=600");
}
function jumpu(theForm, j_mode) {
	var sIndex = theForm.TARGETID.selectedIndex;
	var url = parseInt(theForm.TARGETID.options[sIndex].value) + 1000;
	if (url != "" ) window.open("$HthisFile?IslandMap=" +url+"&JAVAMODE="+j_mode, "", "menubar=yes,toolbar=no,location=no,directories=no,status=yes,scrollbars=yes,resizable=yes,width=570,height=600");
}
function SelectList(theForm){
	var u, selected_ok;
	if(!theForm){s = ''}
	else { s = theForm.menu.options[theForm.menu.selectedIndex].value; }
	if(s == ''){
		u = 0; selected_ok = 0;
		document.myForm.COMMAND.options.length = $All_listCom;
		for (i=0; i<comlist.length; i++) {
			var command = comlist[i];
			for (a=0; a<command.length; a++) {
				comName = command[a][1] + "(" + command[a][2] + ")";
				document.myForm.COMMAND.options[u].value = command[a][0];
				document.myForm.COMMAND.options[u].text = comName;
				if(command[a][0] == $default_Kind){
					document.myForm.COMMAND.options[u].selected = true;
					selected_ok = 1;
				}
				u++;
			}
		}
		if(selected_ok == 0)
		document.myForm.COMMAND.selectedIndex = 0;
	} else {
		var command = comlist[s];
		document.myForm.COMMAND.options.length = command.length;
		for (i=0; i<command.length; i++) {
			comName = command[i][1] + "(" + command[i][2] + ")";
			document.myForm.COMMAND.options[i].value = command[i][0];
			document.myForm.COMMAND.options[i].text = comName;
			if(command[i][0] == $default_Kind){
				document.myForm.COMMAND.options[i].selected = true;
				selected_ok = 1;
			}
		}
		if(selected_ok == 0)
		document.myForm.COMMAND.selectedIndex = 0;
	}
}

function moveLAYER(layName,x,y){
	if(document.getElementById){		//NN6,IE5
		el = document.getElementById(layName);
		el.style.left = x;
		el.style.top  = y;
	} else if(document.layers){				//NN4
		msgLay.moveTo(x,y);
	} else if(document.all){				//IE4
		msgLay = document.all(layName).style;
		msgLay.pixelLeft = x;
		msgLay.pixelTop = y;
	}
}

function menuclose(){
	moveLAYER("menu",-500,-500);
	moveLAYER("menu2",-500,-500);
}

function Mmove(e){
	if(document.all){
		mx = event.x + document.body.scrollLeft;
		my = event.y + document.body.scrollTop;
	}else if(document.layers){
		mx = e.pageX;
		my = e.pageY;
	}else if(document.getElementById){
		mx = e.pageX;
		my = e.pageY;
	}
	return moveLay.move();
}

function Kdown(e){
	var c, el;
	if(document.all){
		if (event.altKey || event.ctrlKey || event.shiftKey) return;
		c = event.keyCode;
		el = new String(event.srcElement.tagName);
		el = el.toUpperCase();
		if (el == "INPUT") return;
//	}else if(document.layers){// NN4 KEYDOWN이벤트는Win98계로 글자가 깨지므로 코멘트화
//		if (e.modifiers != 0) return;
//		c = e.which;
//		if ((c >= 97) && (c <= 122)) c -= 32; // 영소문자를 영대 문자로 한다

//		el = new String(e.target);
//		el = el.toUpperCase();
//		if (el.indexOf("<INPUT") >= 0) return;
	}else if(document.getElementById){
		if (e.altKey || e.ctrlKey || e.shiftKey) return;
		c = e.which;
		el = new String(e.target.tagName);
		el = el.toUpperCase();
		if (el == "INPUT") return;
	}
	c = String.fromCharCode(c);
//	window.status = c; //확인용

	// 밀린 키에 응해 계획 번호를 설정한다

	switch (c) {
	case 'Z': c =  2; break; // 땅고르기
	case 'S': c = 11; break; // 식림?
	case 'U': c =  3; break; // 매립?
	case 'K': c =  5; break; // 굴착?

	case 'N': c = 12; break; // 농장 정비

	case 'P': c = 16; break; // 선물 건설
	case 'B': c = 21; break; // 미사일 기지 건설
	case 'D': c = 22; break; // 방위 시설 건설
	case 'M': c = 51; break; // PP미사일 발사
	case 'Y': c = 61; break; // 괴수 유도탄 발사
	case 'A': c = 96; break; // 유치 활동
	case '-': c = 97; break; //INS 자금융통

	case '.': cominput(myForm,3); return; //DEL 삭제

	case'\b': //BS 1개 전삭제

		var no = document.myForm.NUMBER.selectedIndex;
		if(no > 0) document.myForm.NUMBER.selectedIndex = no - 1;
		cominput(myForm,3);
		return;
	case '0':case'`': document.myForm.AMOUNT.selectedIndex = 0; return;
	case '1':case'a': document.myForm.AMOUNT.selectedIndex = 1; return;
	case '2':case'b': document.myForm.AMOUNT.selectedIndex = 2; return;
	case '3':case'c': document.myForm.AMOUNT.selectedIndex = 3; return;
	case '4':case'd': document.myForm.AMOUNT.selectedIndex = 4; return;
	case '5':case'e': document.myForm.AMOUNT.selectedIndex = 5; return;
	case '6':case'f': document.myForm.AMOUNT.selectedIndex = 6; return;
	case '7':case'g': document.myForm.AMOUNT.selectedIndex = 7; return;
	case '8':case'h': document.myForm.AMOUNT.selectedIndex = 8; return;
	case '9':case'i': document.myForm.AMOUNT.selectedIndex = 9; return;
	default:
	// IE 에서는 리로드를 위한 F5 까지 주우므로, 여기에 처리를 넣어선 안 된다
	return;
	}
	StatusMsg(c);
	cominput(document.myForm, 6, c, 0);
}

function StatusMsg(x) {
msg = new Array(64);
HEDOC_tempOwnerJava_0;
  echo <<<HEDOC_tempOwnerJava_1
	window.status = msg[x];
}

function myisland(theForm,myid) {
	for(i = 0; i < theForm.TARGETID.length ;i++) {
		if(theForm.TARGETID.options[i].value == myid) {
			theForm.TARGETID.selectedIndex = i;
			return;
		}
	}
}
function LayWrite(layName, str) {
	if(document.getElementById){
		document.getElementById(layName).innerHTML = str;
	} else if(document.all){
		document.all(layName).innerHTML = str;
	} else if(document.layers){
		lay = document.layers[layName];
		lay.document.open();
		lay.document.write(str);
		lay.document.close(); 
	}
}

var oldNum=0;
function selCommand(num) {
	document.getElementById('com_'+oldNum).style.backgroundColor = '';
	document.getElementById('com_'+num).style.backgroundColor = '#FFFFAA';
	oldNum = num;
}

// 커멘드 드러그＆드롭용 추가 스크립트
var moveLay = new MoveFalse();

var newLnum = -2;
var Mcommand = false;

function Mup() {
	moveLay.up();
	moveLay = new MoveFalse();
}

function setBorder(num, color) {
	if(document.getElementById) {
		if(color.length == 4) document.getElementById('com_'+num).style.borderTop = ' 1px solid '+color;
		else document.getElementById('com_'+num).style.border = '0px';
	}
}

function mc_out() {
	if(Mcommand && newLnum >= 0) {
		setBorder(newLnum, '');
		newLnum = -1;
	}
}

function mc_over(num) {
	if(Mcommand) {
		if(newLnum >= 0) setBorder(newLnum, '');
		newLnum = num;
		setBorder(newLnum, '#116');    // blue
	}
}

function comListMove(num) { moveLay = new MoveComList(num); return (document.layers) ? true : false; }

function MoveFalse() {
	this.move = function() { }
	this.up   = function() { }
}

function MoveComList(num) {
	var setLnum  = num;
	Mcommand = true;

	LayWrite('mc_div', '<NOBR><strong>'+(num+1)+': '+g[num]+'</strong></NOBR>');

	this.move = function() {
		moveLAYER('mc_div',mx+10,my-30);
		return false;
	}

	this.up   = function() {
		if(newLnum >= 0) {
			var com = command[setLnum];
			cominput(document.myForm,7,setLnum,0,newLnum);
		}
		else if(newLnum == -1) cominput(document.myForm,3,setLnum+1);

		mc_out();
		newLnum = -2;
		Mcommand = false;
		moveLAYER("mc_div",-50,-50);
	}
}

// 화면 천이 없음에서의 커멘드 송신용 추가 스크립트

function new_http() {
	if(document.getElementById) {
		try{
		   return new ActiveXObject("Msxml2.XMLHTTP");
		} catch (e){
			try {
				return new ActiveXObject("Microsoft.XMLHTTP");
			} catch (E){
				if(typeof XMLHttpRequest != 'undefined') return new XMLHttpRequest;
			}
		}
	}
}

function send_command(form) {
	if (!xmlhttp) return true;

	form.CommandJavaButton$Hislands[$HcurrentNumber]->{'id'}.disabled = true;

	var progress  = document.getElementById('progress');
	progress.innerHTML = '<blink>Sending...</blink>';

	if (xmlhttp.readyState == 1 || xmlhttp.readyState == 2 || xmlhttp.readyState == 3) return; 

	xmlhttp.open("POST", "$HthisFile", true);
	if(!window.opera) xmlhttp.setRequestHeader("referer", "$HthisFile");

	xmlhttp.onreadystatechange = function() {
		if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
			var result = xmlhttp.responseText;
			if(result.indexOf('OK') == 0 || result.indexOf('OK') == 2048) {
				str = plchg($HcommandMax);
				str = "<TABLE border=0><TR><TD class='commandjs1'><B>◎◎◎◎ 송신이 끝난 상태 ◎◎◎◎</B><br><br>"+str+"<br><B>◎◎◎◎ 송신이 끝난 상태 ◎◎◎◎</B></TD></TR></TABLE>";
				disp(str, 1);
				selCommand(document.myForm.NUMBER.selectedIndex);
			} else {
				alert("송신에 실패해습니다.");
				form.CommandJavaButton$Hislands[$HcurrentNumber]->{'id'}.disabled = false;
			}
			progress.innerHTML = '';
		}
	}

	var post;
	post += 'async=true&';
	post += 'CommandJavaButton$island->{'id'}=true&';
	post += 'COMMAND='+form.COMMAND.value+'&';
	post += 'TARGETID='+form.TARGETID.value+'&';
	post += 'JAVAMODE=java&';
	post += 'COMARY='+form.COMARY.value+'&';
	post += 'PASSWORD='+form.PASSWORD.value+'&';

	xmlhttp.send(post);
	return false;
}
function showElement(layName) {
	var element = document.getElementById(layName).style;
	element.display = "block";
	element.visibility ='visible';
}

function hideElement(layName) {
	var element = document.getElementById(layName).style;
	element.display = "none";
}

function chNum(num) {
	document.ch_numForm.AMOUNT.options.length = 69;
	for(i=0;i<document.ch_numForm.AMOUNT.options.length;i++){
		if(document.ch_numForm.AMOUNT.options[i].value == num){
			document.ch_numForm.AMOUNT.selectedIndex = i;
			document.ch_numForm.AMOUNT.options[i].selected = true;
			moveLAYER('ch_num', mx-10, my-60);
			showElement('ch_num');
			break;
		}
	}
}

function chNumDo() {
	var num = document.ch_numForm.AMOUNT.options[document.ch_numForm.AMOUNT.selectedIndex].value;
	cominput(document.myForm,9,num);
	hideElement('ch_num');
}
//-->
</SCRIPT>
<span id="menu2" style="position:absolute; top:-500;left:-500;">
<table border=0 class="PopupCell"><tr><td nowrap>
$click_com3
<hr>
<a href="Javascript:void(0);" onClick="menuclose()" class='M'>메뉴를 닫는다</A>
</td></tr></table></span>
<!-- 수량 변경 폼 -->
<div id="ch_num" style="position:absolute;visibility:hidden;display:none">
<form name="ch_numForm">
<TABLE BORDER=1 BGCOLOR="#e0ffff" CELLSPACING=1>
<TR><TD VALIGN=TOP NOWRAP>
<A HREF="JavaScript:void(0)" onClick="hideElement('ch_num');" STYlE="text-decoration:none"><B>×</B></A><BR>
<select name="AMOUNT" size=13 onchange="chNumDo()">
</select>
</TD>
</TR>
</TABLE>
</form>
</div>
<!-- 커멘드 폼 -->
<span ID="mc_div" style="background-color:white;position:absolute;top:-50;left:-50;height:22px;">&nbsp;</span>
<span ID="menu" style="position:absolute; top:-500;left:-500;">
<table border=0 class="PopupCell"><tr><td nowrap>
$click_com
<TD NOWRAP>
$click_com2
<TR>
<TD NOWRAP COLSPAN=2>
<a href="Javascript:void(0);" onClick="menuclose()" class='M'>메뉴를 닫는다</A>
</td></tr></table></span>

HEDOC_tempOwnerJava_1;
  echo <<<HEDOC_tempOwnerJava_2
<CENTER>
<TABLE BORDER>
<TR valign=top>
<TD $HbgInputCell width=25%>
<CENTER>
<FORM name="myForm" action="$HthisFile" method=POST onsubmit="return send_command(this);">
<BR>
<P>
<B>계획 번호</B><SELECT NAME=NUMBER onchange="selCommand(this.selectedIndex)">
HEDOC_tempOwnerJava_2;
  echo <<<HEDOC_tempOwnerJava_3
</SELECT><BR>
<HR>
<B>개발 계획</B>
<INPUT TYPE="checkbox" NAME="MENUOPEN" $open>비표시
<INPUT TYPE="checkbox" NAME="MENUOPEN2" $open>프리젠테이션<br>
<SELECT NAME=menu onchange="SelectList(myForm)">
<OPTION VALUE=>전종류

HEDOC_tempOwnerJava_3;
  echo <<<HEDOC_tempOwnerJava_4
</SELECT><br>
<SELECT NAME=COMMAND onChange=StatusMsg(this.options[this.selectedIndex].value) onClick=StatusMsg(this.options[this.selectedIndex].value)>
<option>　　　　　　　　　　</option>
<option>　　　　　　　　　　</option>
<option>　　　　　　　　　　</option>
<option>　　　　　　　　　　</option>
<option>　　　　　　　　　　</option>
<option>　　　　　　　　　　</option>
<option>　　　　　　　　　　</option>
<option>　　　　　　　　　　</option>
<option>　　　　　　　　　　</option>
<option>　　　　　　　　　　</option>
</SELECT>
<HR>
<B>커멘드 입력</B><BR><B>
<A HREF=JavaScript:void(0); onClick="cominput(myForm,1)">삽입</A>
　<A HREF=JavaScript:void(0); onClick="cominput(myForm,2)">덧쓰기</A>
　<A HREF=JavaScript:void(0); onClick="cominput(myForm,3)">삭제</A>
</B><HR>
<B>좌표 1(</B><SELECT NAME=POINTX>
HEDOC_tempOwnerJava_4;
  echo <<<HEDOC_tempOwnerJava_5
</SELECT>
<HR>
<B>목표의 {$AfterName}</B>
[<B><A HREF=JavaScript:void(0); onClick="jump(myForm, '$HjavaMode')"> 표시</A></B>
][<B><A HREF=JavaScript:void(0); onClick="myisland(myForm,'$myislandID')">자신 선택</A></B>]
<br>[<B><A HREF=JavaScript:void(0); onClick="jumps('$HjavaMode','999')"> 우주 </A></B>
][<B><A HREF=JavaScript:void(0); onClick="jumps('$HjavaMode','888')"> 해역 </A></B>
][<B><A HREF=JavaScript:void(0); onClick="jumpu(myForm, '$HjavaMode')"> 지하 </A></B>]
<BR>

<SELECT NAME=TARGETID>
$HtargetList<BR>
</SELECT>
<HR>
<B>커멘드 이동</B>:
<BIG>
<A HREF=JavaScript:void(0); onClick="cominput(myForm,4)" STYlE="text-decoration:none"> ▲ </A>I
<A HREF=JavaScript:void(0); onClick="cominput(myForm,5)" STYlE="text-decoration:none"> ▼ </A>
</BIG>
<HR>
<INPUT TYPE="hidden" NAME="COMARY" value="comary">
<INPUT TYPE="hidden" NAME="JAVAMODE" value="$HjavaMode">
<INPUT TYPE=submit VALUE="계획 송신" NAME=CommandJavaButton$Hislands[$HcurrentNumber]->{'id'}>
<span id="progress"></span>
<br><font size=2>마지막에<font color=red>계획 송신 버튼</font>계획 송신 버튼</font><font size=2>을<br>누르세요.</font>
<HR>
<B>패스워드</B></BR>
<INPUT TYPE=password NAME=PASSWORD VALUE="$escapedDefaultPassword">
<HR>
</CENTER>
 
<table border=1 width="100%" height=""> 
<tr><td align=center>키 입력 간이 설명(NN4 불가) </td><tr>
</table> 
<table border=1 width="100%" height="">
<tr><td> 숫자=수량</td>
<td>BS=1개 이전삭제</td></tr>
<tr><td>DEL=삭제</td>
<td>Z=땅 고르기</td></tr>
<tr><td>S=식림</td>
<td>U=매립</td></tr>
<tr><td>K=굴착</td>
<td>N=농장 정비</td></tr>
<tr><td>B=미사일 기지</td>
<td>D=방위 시설</td></tr>
<tr><td>M=PP미사일 발사</td>
<td>Y=괴수 유도 미사일</td></tr>
</table> 

</TD>
<TD $HbgMapCell><center>
<TEXTAREA NAME="COMSTATUS" cols="48" rows="2"></TEXTAREA>
</center>
HEDOC_tempOwnerJava_5;
  echo <<<HEDOC_tempOwnerJava_6
</FORM>
</TD>
<TD $HbgCommandCell id="plan" onmouseout="mc_out();return false;">
<FORM name="allForm" action="$HthisFile" method=POST>
<INPUT TYPE="hidden" NAME=PASSWORD VALUE="$escapedDefaultPassword">
<INPUT TYPE="hidden" NAME=NUMBER VALUE="allno">
<INPUT TYPE="hidden" NAME=POINTY VALUE="allpointy">
<INPUT TYPE="hidden" NAME=POINTX VALUE="allpointx">
<INPUT TYPE="hidden" NAME=POINTTY VALUE="allpointty">
<INPUT TYPE="hidden" NAME=POINTTX VALUE="allpointtx">
<br><INPUT TYPE="hidden" NAME=JAVAMODE value="$HjavaMode">
<DIV ID='AutoCommand'><B>자동 계 계획</B><br>
<SELECT NAME=COMMAND>
HEDOC_tempOwnerJava_6;
  echo <<<HEDOC_tempOwnerJava_7
</SELECT><br>
<INPUT TYPE="hidden" NAME="CommandButton$Hislands[$HcurrentNumber]->{'id'}">
<INPUT TYPE="button" onClick="SelectPOINT()" VALUE="자동계 계획 송신"></DIV><HR>
<ilayer name="PARENT_LINKMSG" width="100%" height="100%">
   <layer name="LINKMSG1" width="200"></layer>
   <span id="LINKMSG1"></span>

</ilayer>
<BR>
</FORM>
</TD></TR></TABLE></CENTER>

<script>
SelectList('');
init();
</script>
HEDOC_tempOwnerJava_7;
  echo <<<HEDOC_tempOwnerJava_8
msg[$k] = \"$Msg\
HEDOC_tempOwnerJava_8;
  echo <<<HEDOC_tempOwnerJava_9
<OPTION VALUE=$i>$j\n
HEDOC_tempOwnerJava_9;
  echo <<<HEDOC_tempOwnerJava_10
<OPTION VALUE=$i>$aa\n
HEDOC_tempOwnerJava_10;
  echo <<<HEDOC_tempOwnerJava_11
<OPTION VALUE=$i SELECTED>$i\n
HEDOC_tempOwnerJava_11;
  echo <<<HEDOC_tempOwnerJava_12
<OPTION VALUE=$i>$i\n
HEDOC_tempOwnerJava_12;
  echo <<<HEDOC_tempOwnerJava_13
</SELECT>, <SELECT NAME=POINTY>
HEDOC_tempOwnerJava_13;
  echo <<<HEDOC_tempOwnerJava_14
<OPTION VALUE=$i SELECTED>$i\n
HEDOC_tempOwnerJava_14;
  echo <<<HEDOC_tempOwnerJava_15
<OPTION VALUE=$i>$i\n
HEDOC_tempOwnerJava_15;
  echo <<<HEDOC_tempOwnerJava_16
</SELECT><B>)</B><INPUT TYPE=\"checkbox\" NAME=\"xy1\" CHECKED><br><B>좌표 2(</B><SELECT NAME=POINTTX>
HEDOC_tempOwnerJava_16;
  echo <<<HEDOC_tempOwnerJava_17
<OPTION VALUE=$i SELECTED>$i\n
HEDOC_tempOwnerJava_17;
  echo <<<HEDOC_tempOwnerJava_18
<OPTION VALUE=$i>$i\n
HEDOC_tempOwnerJava_18;
  echo <<<HEDOC_tempOwnerJava_19
</SELECT>, <SELECT NAME=POINTTY>
HEDOC_tempOwnerJava_19;
  echo <<<HEDOC_tempOwnerJava_20
<OPTION VALUE=$i SELECTED>$i\n
HEDOC_tempOwnerJava_20;
  echo <<<HEDOC_tempOwnerJava_21
<OPTION VALUE=$i>$i\n
HEDOC_tempOwnerJava_21;
  echo <<<HEDOC_tempOwnerJava_22
</SELECT><B>)</B><INPUT TYPE=\"checkbox\" NAME=\"xy2\"><HR><B>수량</B><SELECT NAME=AMOUNT>
HEDOC_tempOwnerJava_22;
  echo <<<HEDOC_tempOwnerJava_23
<OPTION VALUE=$i>$i\n
HEDOC_tempOwnerJava_23;
  echo <<<HEDOC_tempOwnerJava_24
<OPTION VALUE=$i>$i\n
HEDOC_tempOwnerJava_24;
  echo <<<HEDOC_tempOwnerJava_25
<OPTION VALUE=$kind $s>$HcomName[$kind]($cost)\n
HEDOC_tempOwnerJava_25;
}
}

if (!function_exists('commandJavaMain')) {
function commandJavaMain() {
	if (function_exists('hako_command_java_main_impl')) { return hako_command_java_main_impl(); }
	echo "OK";
}
}

if (!function_exists('islandMapJava')) {
function islandMapJava() {
	$args = func_get_args();
	$mode = isset($args[0]) ? $args[0] : 0;
	if (function_exists('hako_print_island_java_impl')) {
		return hako_print_island_java_impl($mode);
	}
	if (function_exists('islandMap')) {
		return islandMap(1, isset($GLOBALS['HcurrentID']) ? $GLOBALS['HcurrentID'] : 0);
	}
}
}

if (!function_exists('printIslandJava')) {
function printIslandJava() {
	$args = func_get_args();
	$mode = isset($args[0]) ? $args[0] : 0;
	if (function_exists('hako_print_island_java_impl')) {
		return hako_print_island_java_impl($mode);
	}
	return null;
}
}
?>
