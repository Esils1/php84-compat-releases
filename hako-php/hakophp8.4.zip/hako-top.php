<?php
if (!isset($_hako_fh)) { $_hako_fh = array(); }
if (!function_exists('hako_open')) {
  function hako_open($name, $spec) {
    global $_hako_fh;
    $mode = 'r';
    $path = $spec;
    if (substr($path, 0, 2) === '>>') { $mode = 'a'; $path = substr($path, 2); }
    elseif (substr($path, 0, 1) === '>') { $mode = 'w'; $path = substr($path, 1); }
    elseif (substr($path, 0, 1) === '<') { $mode = 'r'; $path = substr($path, 1); }
    $_hako_fh[$name] = @fopen($path, $mode);
    return $_hako_fh[$name];
  }
  function hako_close($name) {
    global $_hako_fh;
    if (isset($_hako_fh[$name]) && $_hako_fh[$name]) { fclose($_hako_fh[$name]); }
  }
  function hako_getline($name) {
    global $_hako_fh;
    if (!isset($_hako_fh[$name]) || !$_hako_fh[$name]) { return false; }
    return fgets($_hako_fh[$name]);
  }
  function hako_write($name, $data) {
    global $_hako_fh;
    if (!isset($_hako_fh[$name]) || !$_hako_fh[$name]) { return false; }
    return fwrite($_hako_fh[$name], $data);
  }
  function hako_cmp($a, $b) {
    if ($a == $b) { return 0; }
    return ($a < $b) ? -1 : 1;
  }
  function hako_reorder($array, $idx) {
    $out = array();
    foreach ($idx as $i) { if (isset($array[$i])) { $out[] = $array[$i]; } }
    return $out;
  }
  function hako_pick($array, $keys) {
    $out = array();
    foreach ($keys as $key) { $out[] = isset($array[$key]) ? $array[$key] : null; }
    return (count($keys) == 1) ? $out[0] : $out;
  }
  function hako_idx($array, $idx) {
    return isset($array[$idx]) ? $array[$idx] : null;
  }
}
//----------------------------------------------------------------------
// 모형정원 제도 ver2. 30
// 탑 모듈(ver1. 00)
// 사용 조건, 사용 방법등은, hako-readme.txt 파일을 참조
//
// 모형정원 제도의 페이지: http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html
//----------------------------------------------------------------------
// 구상의 모형정원  (ver5. 52c)
//----------------------------------------------------------------------

//----------------------------------------------------------------------
// 탑 페이지 모드
//----------------------------------------------------------------------
// 메인

function topPageMain() {
  $_args = array_pad(func_get_args(), 1, 0);
  extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $HadminMode, $Halistmode, $Hallyflg, $Hallygroup, $Hallymark, $hangen, $HbaseDir, $HbattleNumber, $HbgCommentCell, $HbgInfoCell, $HbgNameCell, $HbgNumberCell, $HbgTitleCell, $HcostChangeName, $HcssFile, $Hdebug, $HdefaultPassword, $Hdishangen, $HdisUN, $helpDir, $HfightMem, $HflexTime, $HflexTimeSet, $HhideMoneyMode, $HidToName, $Himfflag, $HimgLine, $HislandChangeTurn, $HislandFightMode, $HislandLastTime, $HislandList, $HislandNumber, $Hislands, $HislandTurn, $HislandTurnCount, $HjavaModeSet, $HlabelImage, $HlabelName, $HlastTurn, $HlastTurnS, $Hlocalimage, $Hlocalimagehtml, $HlocalImg, $HmaxIsland, $hmode, $HmonsterName, $HmonsterNumber, $Hmonthname, $Hmyship, $hogo, $hour, $hour2, $HrepeatTurn, $Hskinflag, $HskinList, $HskinName, $HskinNameList, $Hspace, $HspecialPassword, $HthisFile, $Htitle, $Htitle2, $HtmTime1, $HtmTime2, $HtmTime3, $HtopAxes, $Htournament, $HturnPrizeNumber, $HturnPrizeVarious, $HunitArea, $HunitFood, $HunitMoney, $HunitPop, $HunitTime, $HunitWeapon, $HwarFlg, $imageDir, $lockMode, $toppage, $versionInfo;
	if ($HtopAxes == 2) { axeslog(); }
	unlock();		# 개방

	// 자동 턴 처리 전에 이미 화면을 출력한 경우에는 중복 출력하지 않는다.
	if(!empty($GLOBALS['HautoTurnPreprinted'])) { return; }

	if(file_exists("./mente_lock")){
		mente_mode(0);
	}else{
		tempTopPage($_args[0]);	# 템플릿 출력
	}
}

// 탑 페이지
function tempTopPage($mode) {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $HadminMode, $Halistmode, $Hallyflg, $Hallygroup, $Hallymark, $hangen, $HbaseDir, $HbattleNumber, $HbgCommentCell, $HbgInfoCell, $HbgNameCell, $HbgNumberCell, $HbgTitleCell, $HcostChangeName, $HcssFile, $Hdebug, $HdefaultPassword, $Hdishangen, $HdisUN, $helpDir, $HfightMem, $HflexTime, $HflexTimeSet, $HhideMoneyMode, $HidToName, $Himfflag, $HimgLine, $HislandChangeTurn, $HislandFightMode, $HislandLastTime, $HislandList, $HislandNumber, $Hislands, $HislandTurn, $HislandTurnCount, $HjavaModeSet, $HlabelImage, $HlabelName, $HlastTurn, $HlastTurnS, $Hlocalimage, $Hlocalimagehtml, $HlocalImg, $HmaxIsland, $hmode, $HmonsterName, $HmonsterNumber, $Hmonthname, $Hmyship, $hogo, $hour, $hour2, $HrepeatTurn, $Hskinflag, $HskinList, $HskinName, $HskinNameList, $Hspace, $HspecialPassword, $HthisFile, $Htitle, $Htitle2, $HtmTime1, $HtmTime2, $HtmTime3, $HtopAxes, $Htournament, $HturnPrizeNumber, $HturnPrizeVarious, $HunitArea, $HunitFood, $HunitMoney, $HunitPop, $HunitTime, $HunitWeapon, $HwarFlg, $imageDir, $lockMode, $toppage, $versionInfo;
	// flexTime 처리
	if($Htournament){
		// 간이 토너먼트
		$HflexTimeSet = 1;
		if($HislandFightMode == 1){
			// 예선
			$HflexTime = $HtmTime1;
		}elseif($HislandFightMode == 2){
			// 개발
			$HflexTime = $HtmTime2;
			$HmaxIsland = 0;
		}elseif($HislandFightMode == 3){
			// 전투
			$HflexTime = $HtmTime3;
			$HmaxIsland = 0;
		}elseif($HislandFightMode == 9){
			// 종료
			$HlastTurn = $HislandTurn;
		}
		if ($HflexTimeSet) { $HunitTime = 3600 * $HflexTime[$HislandTurnCount % ((count($HflexTime) - 1) + 1)]; }
	}else{
		if ($HflexTimeSet) { $HunitTime = 3600 * $HflexTime[$HislandTurn % ((count($HflexTime) - 1) + 1)]; }
	}
	if($mode != 2){
	out(<<<END
{$HtagTitle_}$Htitle{$HtagTitle2_}$Htitle2{$H_tagTitle}{$H_tagTitle}
END
);
//${HthisFile}?Sight=${id}" class=\"M\" TARGET=_blank>
	// 디버그 모드라면 「턴을 진행시킨다」버튼

	if($Hdebug == 1) {
		out(<<<END
<FORM action="$HthisFile" method="POST">
<INPUT TYPE="submit" VALUE="턴을 진행시킨다" NAME="TurnButton">
</FORM>
END
);
	}
	// 다음번 갱신 시간표시
	$now = time();
	// 다음번 갱신까지의 시간을 계산한다
	$aaa = $HislandLastTime + $HunitTime;
	$sec = null; $min = null; $hour = null; $day = null; $sss = null;
	$sec = $aaa - $now;
	if($sec < 0) {
		$aaa += $HunitTime;
		if(-$sec < $HunitTime) {
			$sec += $HunitTime;
		} else {
			$sec = 0;
		}
	}
	$min  = intval($sec  / 60); $sec  %= 60;
	$hour = intval($min  / 60); $min  %= 60;
	$day  = intval($hour / 24); $hour %= 24;
	if($day){
		$sss = "{$day}일과{$hour}시간{$min}분{$sec}초";
	}else{
		$sss = "{$hour}시간{$min}분{$sec}초";
	}
	
	list($min2, $hour2, $date2, $mon2) = hako_pick(localtime($aaa), array(1,2,3,4));
	$mon2++;
	$bbb = "{$mon2}월{$date2}일{$hour2}시{$min2}분";
	
	$bb1 = "";
	if($HflexTimeSet) {
		list($i,$nnn,$ftime,$ct,$rt) = array(0,0,0,0,0);
		$ct = (count($HflexTime) - 1) + 1;
		if($Htournament){
			$rt = ($HislandTurnCount % ($ct));
		}else{
			$rt = ($HislandTurn % ($ct));
		}
		$bb1 = "갱신 빈도{$ct}회/일(　";
		$bb2;
		for($i = $rt;$i <= (count($HflexTime) - 1);$i++){
			$ftime += hako_idx($HflexTime, $i % ((count($HflexTime) - 1) + 1));
			$nnn = $HislandLastTime + 3600 * $ftime;
			list($min2, $hour2) = hako_pick(localtime($nnn), array(1,2));
			if($rt == $i){
				$bb2 .= "<b>{$hour2}시{$min2}분</b>";
			}else{
				$bb2 .= "{$hour2}시{$min2}분";
			}
		}
		for($i = 0;$i < $rt;$i++){
			$ftime += hako_idx($HflexTime, $i % ((count($HflexTime) - 1) + 1));
			$nnn = $HislandLastTime + 3600 * $ftime;
			list($min2, $hour2) = hako_pick(localtime($nnn), array(1,2));
			$bb1 .= "{$hour2}시{$min2}분";
		}
		$bb1 .= "{$bb2})";
	}
	
	if ($HjavaModeSet == 'cgi') {
		$radio = "CHECKED";	$radio2 = "";
	}else{
		$radio = ""; $radio2 = "CHECKED";
	}

	// 턴 수의 표시
	$HlastTurnS = null;
	if($HlastTurn == 0) {
		$HlastTurnS = "";
	} elseif($HislandTurn < $HlastTurn) {
		$HlastTurnS = "X{$HlastTurn}";
	} else {
		$HlastTurnS = "(게임은 종료했습니다)";
		$bbb = "갱신 없음";
	}

	$sinkiStr = '';
	if($HislandNumber < $HmaxIsland + $HbattleNumber) {
		$sinkiStr = "[<A HREF=\"{$HthisFile}?settei=0\" class=\"M\">신규 참가, 설정 변경</A>]<br>";
	} else {
		// 최대수

		$sinkiStr = "[<A HREF=\"{$HthisFile}?settei=0\" class=\"M\">신규 참가, 설정 변경</A>(만배)]<br>";
	}

	// 폼

	$monthname = hako_idx($Hmonthname, ($HislandTurn % 12) + 1);
	
	$fightmode = "";
	if($Htournament){
		// 간이 토너먼트
		$tst1 = null; $tst2 = null;
		$flog = "[<A href=\"$HthisFile?FightLog=0\" class=\"M\" TARGET=_blank>대전의 기록</A>]";
		if($HislandFightMode == 1){
			// 예선
			if($HislandNumber > $HfightMem){
				$tst2 = $HislandNumber - $HfightMem;
				$tst2 = "$tst2{$AfterName}침몰해";
			}
			$tst1 = "　예선 종료후 {$tst2}개발 기간으로 이행합니다.";
			$fightmode = "<font color=blue>예선 기간중</font>　[$HislandTurn×{$HislandChangeTurn}턴]　($HislandNumber$AfterName×$HfightMem{$AfterName})$tst1";
		}elseif($HislandFightMode == 2){
			// 개발
			$tst1 = $HislandChangeTurn + 1;
			$fightmode = "<font color=blue>예선 기간중</font>　[$HislandTurn×{$HislandChangeTurn}턴]　({$tst1}턴 부터 공격 개시)";
		}elseif($HislandFightMode == 3){
			// 전투
			$fightmode = "<font color=red>예선 기간중</font>　[$HislandTurn×{$HislandChangeTurn}턴]";
		}elseif($HislandFightMode == 9){
			//  종료
			$fightmode = "토너먼트는 종료했습니다.";
		}
		$fightmode = "<DIV ID='fightmode'><b>$fightmode $flog</b></DIV><br><br>";
	}
	$escapedDefaultPassword = htmlEscape($HdefaultPassword);
	out(<<<END
<DIV ID='Turn'>
<H1>턴: $HislandTurn{$HlastTurnS}　($monthname)</H1>
</DIV>
$fightmode
<DIV ID='nexttime'>
<font size=4>다음번의 갱신 시간：$bbb </FONT><font size=3>(나머지 $sss)</FONT>
<br>$bb1
</DIV>

<span class='attention'>


</span>

<HR><TABLE><TR><TD style="border-width:0px;">
<DIV ID='myIsland'>
<H1>자신의{$AfterName}에</H1>
<SCRIPT language="JavaScript">
<!--
function develope(){
	if(document.Island.DEVELOPEMODE[1].checked){
		document.Island.SIGHTMODE.value = "on";
	}
	document.Island.target = "";
}
function newdevelope(){
	if(document.Island.DEVELOPEMODE[1].checked){
		document.Island.SIGHTMODE.value = "on";
	}
//	newWindow = window.open("", "newWindow");
	document.Island.target = "newWindow";
	document.Island.submit();
}
//-->
</SCRIPT>
<FORM name="Island" action="$HthisFile" method="POST">
로그인하는{$AfterName} 의  이름은?<BR>
<SELECT NAME="ISLANDID">
<OPTION VALUE="0">-{$AfterName}를 선택해 주세요-
$HislandList
</SELECT><BR>
당신의{$AfterName} 의  이름은?<BR>
<SELECT NAME="PISLANDID">
$HislandList
</SELECT><BR>
패스워드입력 <BR>
<INPUT TYPE="hidden" NAME="OwnerButton">
<INPUT TYPE="password" NAME="PASSWORD" VALUE="$escapedDefaultPassword" SIZE=32 MAXLENGTH=32><BR>
<INPUT TYPE="radio" NAME=JAVAMODE VALUE=cgi $radio>구모드
<INPUT TYPE="radio" NAME=JAVAMODE VALUE=java $radio2>Java 스크립트 모드<BR>
<INPUT TYPE="radio" NAME=DEVELOPEMODE VALUE=DEVELOPE CHECKED>개발 모드
<INPUT TYPE="radio" NAME=DEVELOPEMODE VALUE=SIGHT>관광 모드<BR>
<INPUT TYPE="hidden" NAME="SIGHTMODE" VALUE=off>
<INPUT TYPE="submit" VALUE="현재 창" onClick="develope()">　
<INPUT TYPE="button" VALUE="새 창 " onClick="newdevelope()">
</FORM></DIV></TD>
<TD WIDTH=40 style="border-width:0px;" >　</TD>
<TD VALIGN="top" style="border-width:0px;" >
<H1>설정 변경이나 각종 정보를 표시</H1>
$sinkiStr<br>
[<A HREF="{$HbaseDir}/history.php?saikin=99" class=\"M\" TARGET=_self>과거의 사건의 로그</A>]
[<A HREF="{$HbaseDir}/history.php?tenki=0" class=\"M\" TARGET=_self>과거의 날씨</A>]
[<A HREF="{$HbaseDir}/history.php?statistical=0" class=\"M\" TARGET=_self>통계</A>]<br>
<br>
[<A href="{$HbaseDir}/profile.php" class=\"M\" TARGET=_self>프로파일({$AfterName}주의 정보)</A>]
[<A href="$HthisFile?Exchange=0" class=\"M\" TARGET=_self>자원 거래소</A>]<br>
<br>
[<A href="{$HbaseDir}/ranking.php" class=\"M\" TARGET=_self>퇴치한 괴수 수등의 랭킹</A>]
[<A href="$HthisFile?SUCCESSIVE=0" class=\"M\" TARGET=_self>역대 최다 인구의 랭킹표시</A>]<br>
<br>
[<A href="{$HbaseDir}/setup.html" class=\"M\" TARGET=_self>설정 일람</A>]
<br>
END
);

	$setupFile = "./setup.html";
	$sftime = file_exists($setupFile) ? ((time() - filemtime($setupFile)) / 86400) : 0;
	$Files = array('hako-main.php', 'hako-init.php', 'init-game.php', 'hako-make.php');
	$sfFlag = 1;
	foreach ($Files as $_) {
		if(file_exists("./$_") && ($sftime >= (((time() - filemtime("./$_")) / 86400)))){
			$sfFlag = 0;
break;
		}
	}
//	if((-e "setup.html") && $sfFlag) {
//		out("[<A href=\"setup.html\" class=\"M\" TARGET=_blank>설정 일람</A>] ");
//	} else {
//		out("[<A href=\"setup.html/SetupV=0\" class=\"M\" TARGET=_blank>설정 일람</A>] ");
//	}
	out("</TD></TR></TABLE>");
	}else{
		// 설정 모드
		out("{$Htitle}신규 참가, 설정 변경<A HREF=\"{$HthisFile}\" class=\"M\">통상의 일람 화면으로 돌아간다</A>");
	}
	$mStr1 = ($HhideMoneyMode != 0) ? "<TH $HbgTitleCell>{$HtagTH_}자금 {$H_tagTH}</TH>" : '';
	if($mode == 1) {
		// 간이 표시 모드
		return;
	} elseif($mode == 2) {
		// 설정 모드
	} else {
		$solarwind = ($Hspace['solarwind'] <= $HislandTurn) ? "(<b>태양풍 발생중</b>)" : "";
		$hangen = "";
		$hmode = "";
		if($Hdishangen == 2) {
			// 재해 반감기를 표시한다.
			if((intval($HislandTurn / 100) % 2) == 0){
				// 확률 반감
				$hangen = "재해율 반감중";
			}
		}
		if($mode == 3){
			// 상세 모드
			$hmode = "[<A href=\"$HthisFile\" class=\"M\">간이 일람</A>]";
		}else{
			$hmode = "[<A href=\"$HthisFile?list=0\" class=\"M\">상세 일람</A>]";
		}
		$warstr = "";
		if($HwarFlg){
			$warstr = "<TH $HbgTitleCell>{$HtagTH_}획득 경험치{$H_tagTH}</TH>";
		}
		// 진영표를 표시?
		campInfoList();
		$vsith = "";
		if($Htournament){
			$vsith = "<TH $HbgTitleCell>{$HtagTH_}대전 상대{$H_tagTH}</TH>";
		}
		out(<<<END
<HR><DIV ID='islandView'>
<H1>모든 {$AfterName}의 상황{$hangen}</H1>
<P>{$AfterName} 의 이름을 클릭하면,<B>관광</B>할 수가 있습니다$hmode
[<A href="{$HbaseDir}/monsterlist.php" class=\"M\">괴수 배틀 소지 괴수 일람</A>]
</P>
[<A href="$HthisFile?Ocean=0" class="M">제도 주변의 해역</A>]
[<A href="$HthisFile?space=0" class="M">우주에</A>{$solarwind}]
<TABLE BORDER>
<TR>
<TH $HbgTitleCell>{$HtagTH_}순위{$H_tagTH}</TH>
<TH $HbgTitleCell COLSPAN=2>{$HtagTH_}{$AfterName}{$H_tagTH}</TH>
$vsith
<TH $HbgTitleCell>{$HtagTH_}좌표{$H_tagTH}</TH>
<TH $HbgTitleCell>{$HtagTH_}날씨{$H_tagTH}</TH>
<TH $HbgTitleCell>{$HtagTH_}인구{$H_tagTH}</TH>
<TH $HbgTitleCell>{$HtagTH_}면적{$H_tagTH}</TH>
$mStr1
<TH $HbgTitleCell>{$HtagTH_}식량{$H_tagTH}</TH>
$warstr
<TH $HbgTitleCell>{$HtagTH_}의사 표시{$H_tagTH}</TH>
END
);
		if($mode == 3){
			// 상세
	out(<<<END
<TH $HbgTitleCell>{$HtagTH_}농장 규모{$H_tagTH}</TH>
<TH $HbgTitleCell>{$HtagTH_}공업 규모{$H_tagTH}</TH>
<TH $HbgTitleCell>{$HtagTH_}상업 규모{$H_tagTH}</TH>
<TH $HbgTitleCell>{$HtagTH_}채굴장 규모{$H_tagTH}</TH>
<TH $HbgTitleCell>{$HtagTH_}부문상{$H_tagTH}</TH>
<TH $HbgTitleCell>{$HtagTH_}선물{$H_tagTH}</TH>
<TH $HbgTitleCell>{$HtagTH_}승P{$H_tagTH}</TH>
<TH $HbgTitleCell>{$HtagTH_}부P{$H_tagTH}</TH>
<TH $HbgTitleCell>{$HtagTH_}자점유수{$H_tagTH}</TH></TR>
END
);
		}else{
			out("</TR>\n");
		}
	}
	
	if(($mode == 0) || ($mode == 3)) {
		// 통상, 상세 모드

	$island = null; $j = null; $food = null; $farm = null; $factory = null; $tower = null; $mountain = null; $ally = null; $amark = null; $name = null; $id = null; $prize = null; $vprize = null; $present = null; $ii = null; $monsfound = null;
	$bcount = 0;
	for($ii = 0; $ii < $HislandNumber; $ii++) {

	$island = $Hislands[$ii];

	$id = $island['id'];
	
	if($id > 90) {
		$bcount++;
	}else{
		// 통상의 도 때
	
//	mylist($wkind, $wname, $whp, $wkind2, $wkind3) = weatherinfo($island['weather']);
//	my($wname2) = $WeatherName[$wkind2];
//	my($wname3) = $WeatherName[$wkind3];
	
	$j = $ii + 1 - $bcount;
	$farm = $island['farm'];
	$factory = $island['factory'] + $island['port'];
	$tower = $island['tower'];
	$mountain = $island['mountain'];
	$farm = ($farm == 0) ? "보유 안함" : "{$farm}0$HunitPop";
	$factory = ($factory == 0) ? "보유 안함" : "{$factory}0$HunitPop";
	$tower = ($tower == 0) ? "보유 안함" : "{$tower}0$HunitPop";
	$mountain = ($mountain == 0) ? "보유 안함" : "{$mountain}0$HunitPop";
	$turnsu = $island['turnsu'];
	$zyuni = $island['zyuni'];

	$prize = $island['prize'];
	$flags = null; $monsters = null; $turns = null;
	preg_match('/([0-9]*),([0-9]*),(.*)/', $prize, $_m);
	$flags = $_m[1];
	$monsters= $_m[2];
	$turns = $_m[3];
	$prize = '';

	if($Hallyflg){
		// 각 세력의 통계
		$ally = $island['ally'];
		$amark = "<b>{$Hallymark[$ally]}</b> ";
	}else{
		$amark = "";
	}
	// 보호국에는 보호를 표시
	$hogo = '○';
	if(($turnsu + $island['evil'] < $HdisUN) || ($island['evil'] == 0)){
		$hogo = '×';
	} elseif(($island['evil'] < $HdisUN) && (!$HwarFlg)) {
		$hogo = '△';
	}

	// 괴수가 있는 경우는 표시
	if($island['monsfound'] > 0){
		$monsfound = "<b>(괴수{$island['monsfound']})</b>";
	}else{
		$monsfound = "";
	}

	// 날씨
	list($wkind, $wname, $whp, $wkind2, $wkind3) = weatherinfo($island['weather']);
	$tenki = "<img src =\"{$imageDir}/{$WeatherIcon[$wkind]}\">";

	if($island['absent']  == 0) {
		$name = "{$HtagName_}{$island['name']}{$AfterName}{$H_tagName}";
	} else {
		$name = "{$HtagName2_}{$island['name']}{$AfterName}({$island['absent']}){$H_tagName2}";
	}
	if (!empty($island['predelete'])) { $name = "<span class='attention'>【관리인 보관】</span><BR>" . $name; }
	
	// 턴배의 표시
	$kazu = 0;
	$mTurnList = '';
	while (preg_match('/([0-9]*),/', $turns, $_m)) { $turns = preg_replace('/([0-9]*),/', '', $turns, 1);
		$kazu++;
		$mTurnList .= "[{$_m[1]}{$Hprize[0]}] ";
	}
	if($kazu >= 5) {
		$prize .= "<IMG SRC=\"prize00.gif\" ALT=\"$mTurnList\" WIDTH=16 HEIGHT=16> ";
	} elseif($kazu >= 3) {
		$prize .= "<IMG SRC=\"prize.gif\" ALT=\"$mTurnList\" WIDTH=16 HEIGHT=16> ";
	} elseif($kazu != 0) {
		$prize .= "<IMG SRC=\"prize0.gif\" ALT=\"$mTurnList\" WIDTH=16 HEIGHT=16> ";
	}

	// 이름에 상의 문자를 추가
	$f = 1;
	$i = null;
	for($i = 1; $i < 11; $i++) {
		if ($flags & $f) { $prize .= "<IMG SRC=\"prize{$i}.gif\" ALT=\"{$Hprize[$i]}\" WIDTH=16 HEIGHT=16> "; }
		$f *= 2;
	}
	if ($flags & 2048) { $prize .= "<IMG SRC=\"prize11.gif\" ALT=\"{$Hprize[11]}\" WIDTH=16 HEIGHT=16> "; }
	
	// 쓰러트린 괴수 리스트
	$f = 1;
	$max = -1;
	$mNameList = '';
//	for($i = 0; $i < 32; $i++) {
//		if($monsters & $f) {
//			$mNameList .= "[{$HmonsterName[$i]}] ";
//			$max = $i;
//		}
//		$f *= 2;
//	}
	for($i = $HmonsterNumber-1; $i >= 0; $i--) {
		$f = pow(2, $i);
		if($monsters >= $f){
			$monsters -= $f;
			$mNameList .= "[{$HmonsterName[$i]}] ";
			if ($max == -1) { $max = $i; }
		}
	}
	if ($max != -1) { $prize .= "<IMG SRC=\"{$HmonsterImage[$max]}\" ALT=\"$mNameList\" WIDTH=16 HEIGHT=16> "; }

	$cspan = null; $comment = null; $popspace = null;
	if($mode == 3){
		// 상세 모드
		$popspace = $island['popspace'];
		$popspace = ($popspace > 0) ? "({$popspace}{$HunitPop})" : "";
		$comment = $island['comment'];
		$cspan = 16;
		// 선물을 표시
		$present = '';
		$pre  = $island['present'];
		if ($pre[0] > 0) { $present .= "<IMG SRC=\"land30.gif\" ALT=\"{$pre[0]}\" WIDTH=16 HEIGHT=16> "; }
		if ($pre[1] > 0) { $present .= "<IMG SRC=\"land27.gif\" ALT=\"{$pre[1]}\" WIDTH=16 HEIGHT=16> "; }
		if ($pre[2] > 0) { $present .= "<IMG SRC=\"land32.gif\" ALT=\"{$pre[2]}\" WIDTH=16 HEIGHT=16> "; }
		if ($pre[3] > 0) { $present .= "<IMG SRC=\"land29.gif\" ALT=\"{$pre[3]}\" WIDTH=16 HEIGHT=16> "; }
		if ($pre[4] > 0) { $present .= "<IMG SRC=\"land28.gif\" ALT=\"{$pre[4]}\" WIDTH=16 HEIGHT=16> "; }
		if ($pre[5] > 0) { $present .= "<IMG SRC=\"land31.gif\" ALT=\"{$pre[5]}\" WIDTH=16 HEIGHT=16> "; }
		if ($pre[6] > 0) { $present .= "<IMG SRC=\"land33.gif\" ALT=\"{$pre[6]}\" WIDTH=16 HEIGHT=16> "; }
		if ($pre[7] > 0) { $present .= "<IMG SRC=\"land39.gif\" ALT=\"{$pre[7]}\" WIDTH=16 HEIGHT=16> "; }
		if ($pre[8] > 0) { $present .= "<IMG SRC=\"land38.gif\" ALT=\"{$pre[8]}\" WIDTH=16 HEIGHT=16> "; }
		if ($pre[9] > 0) { $present .= "<IMG SRC=\"land40.gif\" ALT=\"{$pre[9]}\" WIDTH=16 HEIGHT=16> "; }
		if ($pre[10] > 0) { $present .= "<IMG SRC=\"monumentM.gif\" ALT=\"{$pre[10]}\" WIDTH=16 HEIGHT=16> "; }
		if ($pre[11] > 0) { $present .= "<IMG SRC=\"monumentP.gif\" ALT=\"{$pre[11]}\" WIDTH=16 HEIGHT=16> "; }
		if ($present == '') { $present = '　'; }

		// 각 상을 표시
		$f = 1;
		$vprize = '';
		$flags = $island['status'];
		for($i = 1; $i < $HturnPrizeNumber + 1; $i++) {
			if ($flags & $f) { $vprize .= "<IMG SRC=\"Vprize{$i}.gif\" ALT=\"{$HprizeV[$i]}\" WIDTH=16 HEIGHT=16> "; }
			$f *= 2;
		}
		if ($vprize == '') { $vprize = '　'; }
	}else{
		$comment = cutColumn($island['comment'], 70);
		$cspan = 7;
	}
	
	// 코멘트 라벨
	$label0 = null; $label1 = null; $label2 = null; $label3 = null; $label4 = null;
	list($label0_1n,$label0_2n) = preg_split("/<>/", $HlabelName[0]);
	list($label0_1i,$label0_2i) = preg_split("/<>/", $HlabelImage[0]);
	if($island['commentLabel0']){
		$label0 = " <IMG SRC=\"$imageDir/$label0_1i\" ALT=\"$label0_1n\">" ;
	}else{
		$label0 = " <IMG SRC=\"$imageDir/$label0_2i\" ALT=\"$label0_2n\">";
	}
	if ($island['commentLabel1']) { $label1 = " <IMG SRC=\"$imageDir/{$HlabelImage[1]}\" ALT=\"{$HlabelName[1]}\">"; }
	if ($island['commentLabel2']) { $label2 = " <IMG SRC=\"$imageDir/{$HlabelImage[2]}\" ALT=\"{$HlabelName[2]}\">"; }
	if ($island['commentLabel3']) { $label3 = " <IMG SRC=\"$imageDir/{$HlabelImage[3]}\" ALT=\"{$HlabelName[3]}\">"; }
	if ($island['commentLabel4']) { $label4 = " <IMG SRC=\"$imageDir/{$HlabelImage[4]}\" ALT=\"{$HlabelName[4]}\">"; }
	
	if($HwarFlg){
		// 전쟁 모드
		$warstr = "<TD $HbgInfoCell>" . $island['allex'] . "</TD>";
		$cspan++;
	}
	// 간이 토너먼트
	$vsitd = "";
	if($Htournament){
		$tName = "";
		if($HislandFightMode == 9){
			$tName = "　- 종료 -";
		}elseif($island['fight_id'] == -1){
			$tName = "　- 부전승 -";
		}else{
			$tName = $HidToName[$island['fight_id']];
			$tName = ($tName == '') ? "　- 미정 -" : "$tName$AfterName";
		}
		$vsitd = "<TD $HbgNameCell>$tName</TD>";
		$cspan++;
	}
	$mStr1 = '';
	if($HhideMoneyMode == 1) {
		$mStr1 = "<TD $HbgInfoCell>{$island['money']}$HunitMoney</TD>";
	} elseif($HhideMoneyMode == 2) {
		$mTmp = aboutMoney($island['money']);
		$mStr1 = "<TD $HbgInfoCell>$mTmp</TD>";
	}

	$oStr = ''; # 사용자명 표시를 위해 추가
	if($island['ownername'] == ''){
		$oStr = "<TD $HbgCommentCell COLSPAN=$cspan>$amark{$HtagTH_}코멘트 : {$H_tagTH}{$comment}</TD>";
	} else {
		$oStr = "<TD $HbgCommentCell COLSPAN=$cspan>$amark<A HREF=\"$HbaseDir/profile.php?profile={$id}\" class=\"M\" TARGET=_blank>{$island['ownername']}</A> : {$comment}</TD>";
	}
	out(<<<END
<TR>
<TD $HbgNumberCell ROWSPAN=2>{$HtagNumber_}$j{$H_tagNumber}($zyuni)</TD>
<TD $HbgNameCell ROWSPAN=2>
<A HREF="{$HthisFile}?Sight={$id}" class=\"M\" TARGET=_blank>
$name$monsfound
</A><BR>
$prize
</TD>
<TD $HbgInfoCell>$hogo</TD>
$vsitd
<TD $HbgInfoCell>{$island['x']},{$island['y']}</TD>
<TD $HbgInfoCell>$tenki</TD>
<TD $HbgInfoCell>{$island['pop']}$HunitPop$popspace</TD>
<TD $HbgInfoCell>{$island['area']}$HunitArea</TD>
$mStr1
<TD $HbgInfoCell>{$island['food']}$HunitFood</TD>
$warstr
<TD $HbgInfoCell>$label0$label1$label2$label3$label4</TD>
END
);
	if($mode == 3){
		out(<<<END
<TD $HbgInfoCell>$farm</TD>
<TD $HbgInfoCell>$factory</TD>
<TD $HbgInfoCell>$tower</TD>
<TD $HbgInfoCell>$mountain</TD>
<TD $HbgInfoCell>$vprize</TD>
<TD $HbgInfoCell>$present</TD>
<TD $HbgInfoCell>{$island['winP']}</TD>
<TD $HbgInfoCell>{$island['loseP']}</TD>
<TD $HbgInfoCell>{$island['possess']}</TD></TR>
END
);
	}else{
		out("</TR>\n");
	}
	out(<<<END
<TR>
<TD $HbgInfoCell>$turnsu</TD>
$oStr
</TR>
END
);
	}
	}
	out(<<<END
</TABLE></DIV>
END
);
	$bHeader = 1;
	for($ii = 0; $ii < $HislandNumber; $ii++) {
		$island = $Hislands[$ii];
		$id = $island['id'];
		if($id > 90) {
			// Battle Field
			if($island['ownername'] == ''){
				$oStr = "<TD $HbgNameCell>{$island['comment']}</TD>";
			} else {
				$oStr = "<TD $HbgNameCell><A HREF=\"$HbaseDir/profile.php?profile={$id}\" class=\"M\" TARGET=_blank>{$island['ownername']}</A> : {$island['comment']}</TD>";
			}
			if($bHeader){
				$bHeader = 0;
	out(<<<END
<DIV ID='islandViewBf'>
<H1>Battle Field의 상황</H1>
<TABLE BORDER>
<TR>
<TH $HbgTitleCell>{$HtagTH_}순위{$H_tagTH}</TH>
<TH $HbgTitleCell>{$HtagTH_}ID{$H_tagTH}</TH>
<TH $HbgTitleCell>{$HtagTH_}{$AfterName}{$H_tagTH}</TH>
<TH $HbgTitleCell>{$HtagTH_}좌표{$H_tagTH}</TH>
<TH $HbgTitleCell>{$HtagTH_}코멘트{$H_tagTH}</TH>
</TR>
END
);
			}
	out(<<<END
<TR>
<TD $HbgNumberCell align=center><span class="star">∪</span></TD>
<TD $HbgInfoCell>{$island['id']}</TD>
<TD $HbgNameCell>
<A HREF="{$HthisFile}?Sight={$id}" class=\"M\" TARGET=_blank>{$HtagName_}{$island['name']}{$AfterName}{$H_tagName}</A><BR></TD>
<TD $HbgInfoCell>{$island['x']},{$island['y']}</TD>
$oStr
</TR>
END
);
			}
		}
		if($bHeader){
			out("<HR>");
		}else{
			out("</TABLE></DIV><HR>");
		}
	} else {
		// 일반 설정 변경 화면의 진영 선택입니다.
		// 요청 기준: 진영모드 ON/OFF와 관계없이 항상 표시합니다.
		// 기본값은 "변경 안함"으로 두어, 이름/패스워드만 변경할 때 기존 진영이 임의로 바뀌지 않게 합니다.
		$changeAllyOptions = "<OPTION VALUE=\"-1\" SELECTED>변경 안함
";
		$changeAllyGroups = (is_array($Hallygroup) && count($Hallygroup) > 0) ? $Hallygroup : array('무소속','동맹군','연합군','제국군');
		foreach($changeAllyGroups as $changeAllyId => $changeAllyName){
			$changeAllyMark = (is_array($Hallymark) && isset($Hallymark[$changeAllyId]) && $Hallymark[$changeAllyId] !== '') ? '('.$Hallymark[$changeAllyId].')' : '';
			$changeAllyOptions .= '<OPTION VALUE="'.intval($changeAllyId).'">'.htmlspecialchars((string)$changeAllyName, ENT_QUOTES, 'UTF-8').$changeAllyMark."
";
		}
		// v29: 화면 출력 누락 재발 방지를 위해 진영 선택 HTML을 폼 본문에 직접 삽입합니다.
		// 이 옵션 목록은 진영모드 ON/OFF와 관계없이 항상 출력됩니다.
		$tournamentMons = "";
		if($Htournament == 2){
			$tournamentMons = "수호 괴수(괴수 배틀)는?<BR><SELECT NAME=TOURNAMENTMONS>\n";
			for($i = 1; $i < $HmonsterNumber; $i++) {
				$tournamentMons .= "<OPTION VALUE=$i>{$HmonsterName[$i]}\n";
			}
			$tournamentMons .= "</SELECT><BR>\n";
		}
		out(<<<END
<HR>
<TABLE><TR><TD style="border-width:0px;" >
<DIV ID='changeInfo'>
<H1>{$AfterName}의이름이나 패스워드를 변경시</H1>
<P>(주의) 이름의 변경에는$HcostChangeName{$HunitMoney}이 들어갑니다.</P>
<FORM action="$HthisFile" method="POST">
<!-- campselect-always-v29 -->
진영 선택(변경하는 경우만)<BR>
<SELECT NAME="CHANGEALLY">
$changeAllyOptions</SELECT><BR>
어느 {$AfterName}입니까?<BR>
<SELECT NAME="ISLANDID">
$HislandList
</SELECT>
<BR>
이름 변경(변경하는 경우만)<BR>
<INPUT TYPE="text" NAME="ISLANDNAME" SIZE=32 MAXLENGTH=32>$AfterName<BR>
사용자 이름 변경 (변경하는 경우만)<BR>
<INPUT TYPE="text" NAME="OWNERNAME" SIZE=32 MAXLENGTH=32><BR>
패스워드 (필수)<BR>
<INPUT TYPE="password" NAME="OLDPASS" SIZE=32 MAXLENGTH=32><BR>
새로운 패스워드는? (변경할 패스워드명)<BR>
<INPUT TYPE="password" NAME="PASSWORD" SIZE=32 MAXLENGTH=32><BR>
패스워드 확인(변경할 패스워드명 확인)<BR>
<INPUT TYPE="password" NAME="PASSWORD2" SIZE=32 MAXLENGTH=32><BR>
<INPUT TYPE="submit" VALUE="변경한다" NAME="ChangeInfoButton">
</FORM></DIV></TD>
<TD WIDTH=40 style="border-width:0px;" >　</TD>
<TD VALIGN="top" style="border-width:0px;" >
<DIV ID='newIsland'>
<H1>새로운 $AfterName 를(을) 찾는다</H1>
END
);
		if($HislandNumber < $HmaxIsland + $HbattleNumber) {
			if((!$HadminMode) || (checkPassword($HspecialPassword, $HdefaultPassword))){
				out(<<<END
<FORM action="$HthisFile" method="POST">
섬이름<BR>
<INPUT TYPE="text" NAME="ISLANDNAME" SIZE=32 MAXLENGTH=32>$AfterName<BR>
사용자명(생략가능)<br>
<INPUT TYPE="text" NAME="OWNERNAME" SIZE=32 MAXLENGTH=32><BR>
$tournamentMons
패스워드 <BR>
<INPUT TYPE="password" NAME="PASSWORD" SIZE=32 MAXLENGTH=32><BR>
패스워드 확인<BR>
<INPUT TYPE="password" NAME="PASSWORD2" SIZE=32 MAXLENGTH=32><BR>
<INPUT TYPE="submit" VALUE="찾으러 간다" NAME="NewIslandButton">
</FORM>
END
);
			}else{
				// 관리 모드
				out(<<<END
        본 모형정원제도에서는 부적절한 {$AfterName} 이름등의 사전 체크를 실시하고 있습니다.<BR>
        참가 희망은, 관리자에게  「{$AfterName} 명」과「패스워드」를<BR>
       기입해 메일로 보내주세요<BR>
END
);
			}
		}else{
			out(<<<END
        $AfterName 의 수가 꽉찼습니다. 더이상 등록할수없습니다.
END
);
		}
		
		// CGI 원본의 MYSHIP 쿠키 동작을 PHP 전역값까지 포함해 재현한다.
		// 방금 변경한 값도 즉시 화면에 반영되도록 cgiInput()에서 설정한 $Hmyship을 우선한다.
		$radio = "";
		$radio2 = "";
		$myshipNow = (isset($Hmyship) && $Hmyship !== '') ? $Hmyship : null;
		if ($myshipNow === null) {
			$cookie = isset($_SERVER['HTTP_COOKIE']) ? $_SERVER['HTTP_COOKIE'] : '';
			if (preg_match('/MYSHIP=\(([^\)]*)\)/', $cookie, $_m)) {
				$myshipNow = $_m[1];
			}
		}
		if ($myshipNow !== null) {
			if($myshipNow) {
				$radio = ""; $radio2 = "CHECKED";
			}else{
				$radio = "CHECKED";	$radio2 = "";
			}
		}
		out(<<<END
</DIV>
</TD></TR></TABLE>
<HR>
<FORM action="$HthisFile" method="POST">
<H1>자신의 도 혹은 섬에 배의 이미지를 주위에 구별하기 편하게 할건지 안할건지의 설정 </H1>
<INPUT TYPE="radio" NAME=RMYSHIP VALUE=0 $radio>투과 시킨다

<INPUT TYPE="radio" NAME=RMYSHIP VALUE=1 $radio2>투과 시키지 않는다
<INPUT TYPE="submit" VALUE="변경한다" NAME="MyShipImgMode">
</FORM>
END
);
	$Hskinflag = null;
	$HskinNow = (isset($HskinName) && is_string($HskinName)) ? $HskinName : '';
	if($HskinNow == '' || $HskinNow == "$HcssFile"){
		$Hskinflag = '<span class=attention>미설정</span>';
	} else {
		$Hskinflag = $HskinNow;
	}
	$select_list = "<OPTION value='del'" . (($HskinNow == '' || $HskinNow == "$HcssFile") ? " selected" : "") . ">미설정\n";
	$skinCount = is_array($HskinList) ? count($HskinList) : 0;
	for ($_ = 0; $_ < $skinCount; $_++) {
		$skinLabel = (isset($HskinNameList) && is_array($HskinNameList) && isset($HskinNameList[$_])) ? $HskinNameList[$_] : $HskinList[$_];
		$selected = ($HskinList[$_] == $HskinNow) ? " selected" : "";
		if ($HskinList[$_] == $HskinNow) { $Hskinflag = $skinLabel; }
		$select_list .= "<OPTION value='{$HskinList[$_]}'{$selected}>{$skinLabel}\n";
	}
	out(<<<END
<hr><div id='hakoSkin'>
<h1>스타일 시트의 설정</h1>
현재의 설정<b>[</b> {$Hskinflag} <b>]</b>
<form action=$HthisFile method=POST>
<SELECT NAME="SKIN">$select_list</SELECT>
<INPUT TYPE="submit" VALUE="설정" name=SKINSET>
</form>
</div>
END
);
		if($Hlocalimage) {
			$setsumei = ($Hlocalimagehtml != '') ? "<p>자세하게는<a href=\"{$Hlocalimagehtml}\"target=\"_blank\">설명의 페이지</a>를 봐 주세요. </p>" : "";
			$dlimg = ($HlocalImg != '') ? "이미지은<B><a href=\"$HlocalImg\">여기</a></B>로부터 다운로드해 주세요.<br>" : "";
			$HimgLineNow = isset($HimgLine) ? trim($HimgLine) : '';
			$Himfflag = hako_imgline_is_unset($HimgLineNow, $imageDir) ? '<FONT COLOR=RED>미설정</FONT>' : $HimgLine;
			out(<<<END
<HR>
<TABLE><TR><TD style="border-width:0px;" >
<H1>이미지의 로컬 설정</H1>
$dlimg
참조의 버튼을 클릭해 PC의 로컬 디스크의 모형정원 이미지 보존 폴더의 land0.gif를 선택해 주세요. <BR>
지정의 폴더까지의 루트가 모두영숫자만의 폴더명을 추천 합니다. <BR>
반각 가나는 사용 불가능합니다. 반각 스페이스는%20에 자동 변환됩니다. <BR>
또, 공백을 설정하면 지정이 해제됩니다. <BR><BR>
$setsumei
현재의 설정<B>[</b> {$Himfflag} <B>]</B>
<form action=$HthisFile method=POST>
<INPUT TYPE=file NAME="IMGLINE" SIZE="80">
<INPUT TYPE="submit" VALUE="설정" name=IMGSET>
</form>

<form action=$HthisFile method=POST>
직접 지정(Mac 유저용)<BR>
예(WIN) D:\\image\\hakogif<BR>
<INPUT TYPE=text NAME="IMGLINEMAC" SIZE="80">
<INPUT TYPE="submit" VALUE="설정" name=IMGSET><BR>
Mac를 손대었던 적이 없기 때문에 잘 모릅니다<BR>
</form>

</TD></TR></TABLE>
END
);

			return;
		} else {
			return;
		}
	}
	out(<<<END
<DIV ID='RecentlyLog'>
<H1>최근의 사건</H1>
[<A HREF="{$HbaseDir}/history.php?saikin=99" class=\"M\" TARGET=_self>과거{$HtopLogTurn}턴의 로그를 표시합니다</A>]<BR><BR>
</DIV>
END
);
	for($i=0; $i < $HrepeatTurn; $i++){
		logFilePrint($i, 0, 0);
	}
	out(<<<END
<DIV ID='RecentlyLog'>
<H1>발견의 기록</H1>
END
);
	historyPrint();
	out("</DIV>");
}

// 진영표를 표시
function campInfoList() {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $HadminMode, $Halistmode, $Hallyflg, $Hallygroup, $Hallymark, $hangen, $HbaseDir, $HbattleNumber, $HbgCommentCell, $HbgInfoCell, $HbgNameCell, $HbgNumberCell, $HbgTitleCell, $HcostChangeName, $HcssFile, $Hdebug, $HdefaultPassword, $Hdishangen, $HdisUN, $helpDir, $HfightMem, $HflexTime, $HflexTimeSet, $HhideMoneyMode, $HidToName, $Himfflag, $HimgLine, $HislandChangeTurn, $HislandFightMode, $HislandLastTime, $HislandList, $HislandNumber, $Hislands, $HislandTurn, $HislandTurnCount, $HjavaModeSet, $HlabelImage, $HlabelName, $HlastTurn, $HlastTurnS, $Hlocalimage, $Hlocalimagehtml, $HlocalImg, $HmaxIsland, $hmode, $HmonsterName, $HmonsterNumber, $Hmonthname, $Hmyship, $hogo, $hour, $hour2, $HrepeatTurn, $Hskinflag, $HskinList, $HskinName, $HskinNameList, $Hspace, $HspecialPassword, $HthisFile, $Htitle, $Htitle2, $HtmTime1, $HtmTime2, $HtmTime3, $HtopAxes, $Htournament, $HturnPrizeNumber, $HturnPrizeVarious, $HunitArea, $HunitFood, $HunitMoney, $HunitPop, $HunitTime, $HunitWeapon, $HwarFlg, $imageDir, $lockMode, $toppage, $versionInfo;
	if(($Hallyflg) && (hako_open('LIN', "{$HlogdirName}/ally.log"))){
	out(<<<END
<HR><DIV ID='campInfo'>
<H1>각 진영의 상황</H1>
<TABLE BORDER>
<TR>
<TH $HbgTitleCell>{$HtagTH_}순위{$H_tagTH}</TH>
<TH $HbgTitleCell>{$HtagTH_}그룹{$H_tagTH}</TH>
<TH $HbgTitleCell>{$HtagTH_}{$AfterName}수{$H_tagTH}</TH>
<TH $HbgTitleCell>{$HtagTH_}총인구{$H_tagTH}</TH>
<TH $HbgTitleCell>{$HtagTH_}점유율{$H_tagTH}</TH>
<TH $HbgTitleCell>{$HtagTH_}총 평수{$H_tagTH}</TH>
<TH $HbgTitleCell>{$HtagTH_}총경제력{$H_tagTH}</TH>
<TH $HbgTitleCell>{$HtagTH_}전군사력{$H_tagTH}</TH>
</TR>
END
);
	$i = null; $line = null; $ally = null; $apop = null; $up = null;
	$i = 1;
	while (($line = hako_getline('LIN')) !== false) {
		// 턴, 진영 ID, 도수, 총인구, 총 평수, 총경제력, 전군사력
		$ally = preg_split("/,/", $line);
		if($ally[0] != $HislandTurn){
			$apop[$ally[1]] = $ally[3];
continue;
		}
		out("<TR><TD $HbgNumberCell align=center><a href=\"$HthisFile?alist={$ally[1]}\" class=\"M\">{$HtagNumber_}$i{$H_tagNumber}</a></TD>");
		if($ally[1] == 0){
			out("<TD $HbgNameCell>" . $Hallygroup[$ally[1]] . "</TD>");
		}else{
			out("<TD $HbgNameCell>" . $Hallymark[$ally[1]] . $HtagTH_ . $Hallygroup[$ally[1]] . $H_tagTH . "</TD>");
		}
		out("<TD $HbgInfoCell>{$ally[2]}</TD>");
		if(($HislandTurn % $HturnPrizeVarious) == 0){
			$up = "";
		}else{
			$allyPrevPop = isset($apop[$ally[1]]) ? $apop[$ally[1]] : $ally[3];
			if($allyPrevPop > $ally[3] + 100){
				$up = "↓";
			}elseif($allyPrevPop < $ally[3] - 100){
				$up = "↑";
			}else{
				$up = "→";
			}
		}
		out("<TD $HbgInfoCell>{$ally[3]}{$HunitPop} <B>$up</B></TD>");
		out("<TD $HbgInfoCell>{$ally[7]}%</TD>");
		out("<TD $HbgInfoCell>{$ally[4]}{$HunitArea}</TD>");
		out("<TD $HbgInfoCell>{$ally[5]}{$HunitMoney}</TD>");
		out("<TD $HbgInfoCell>{$ally[6]}P</TD></TR>");
		$i++;
	}
	hako_close('LIN');
	out("</TABLE>");
	out("[<A HREF=\"{$HbaseDir}/history.php?ally=0\" class=\"M\" TARGET=_self>과거의 데이터</a>]</DIV>");
	}
}
function topPageAlist() {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $HadminMode, $Halistmode, $Hallyflg, $Hallygroup, $Hallymark, $hangen, $HbaseDir, $HbattleNumber, $HbgCommentCell, $HbgInfoCell, $HbgNameCell, $HbgNumberCell, $HbgTitleCell, $HcostChangeName, $HcssFile, $Hdebug, $HdefaultPassword, $Hdishangen, $HdisUN, $helpDir, $HfightMem, $HflexTime, $HflexTimeSet, $HhideMoneyMode, $HidToName, $Himfflag, $HimgLine, $HislandChangeTurn, $HislandFightMode, $HislandLastTime, $HislandList, $HislandNumber, $Hislands, $HislandTurn, $HislandTurnCount, $HjavaModeSet, $HlabelImage, $HlabelName, $HlastTurn, $HlastTurnS, $Hlocalimage, $Hlocalimagehtml, $HlocalImg, $HmaxIsland, $hmode, $HmonsterName, $HmonsterNumber, $Hmonthname, $Hmyship, $hogo, $hour, $hour2, $HrepeatTurn, $Hskinflag, $HskinList, $HskinName, $HskinNameList, $Hspace, $HspecialPassword, $HthisFile, $Htitle, $Htitle2, $HtmTime1, $HtmTime2, $HtmTime3, $HtopAxes, $Htournament, $HturnPrizeNumber, $HturnPrizeVarious, $HunitArea, $HunitFood, $HunitMoney, $HunitPop, $HunitTime, $HunitWeapon, $HwarFlg, $imageDir, $lockMode, $toppage, $versionInfo;
	out(<<<END
{$HtagTitle_}$Htitle{$HtagTitle2_}$Htitle2{$H_tagTitle}{$H_tagTitle}
<br><br>
은폐 기능이기도 한다···. (<A HREF="{$HthisFile}" class="M"> 돌아간다</A>)<br>
<h2>{$Hallygroup[$Halistmode]}　{$Hallymark[$Halistmode]}　소속 일람</h2>
<SCRIPT LANGUAGE="JavaScript">
<!--
function textcopy(mapdata){
	window.clipboardData.setData("text",mapdata);
}
function searchID(url){
	if(document.getElementById){
		return document.getElementById(url);
	} else if(document.all){
		return document.all(url);
	} else if(document.layers){
		return document.layers[url];
	}
}
//-->
</SCRIPT>
<INPUT TYPE="button" VALUE="클립보드에 카피" onClick="textcopy(searchID('ALIST').value)">
엑셀이라든지에 붙여 사용해 주세요.<br>
<textarea NAME="ALIST" cols="100" rows="10">
END
);

	$i = null; $island = null; $id = null; $name = null; $pop = null; $money = null; $food = null; $weapon = null;
	out("섬이름\t인구\t자금\t식량\t병기량\n");
	for($i = 0; $i < $HislandNumber; $i++){
		$island = $Hislands[$i];
		$tAlly = $island['ally'];
		if($Halistmode == $tAlly){
			$id = $island['id'];
			$name = $island['name'];
			$pop = $island['pop'] . $HunitPop;
			if($HhideMoneyMode == 1) {
				$money = $island['money'] . $HunitMoney;
			} elseif($HhideMoneyMode == 2) {
				$money = aboutMoney($island['money']);
			} else {
				$money = '기밀';
			}
			$food = $island['food'] . $HunitFood;
			$weapon = $island['weapon'] . $HunitWeapon;
			out("$name$AfterName\t$pop\t$money\t$food\t$weapon\n");
		}
	}
	out("</textarea>");
	// 진영표를 표시
	campInfoList();
}

// 기록 파일 표시
function historyPrint() {
	global $HlogdirName, $HdirName, $HtagNumber_, $H_tagNumber;
	$paths = array();
	foreach (array($HlogdirName, $HdirName, '.', './logdata', './data') as $d) {
		if ($d === null || $d === '') { continue; }
		$paths[] = rtrim($d, '/') . '/hakojima.his';
	}
	$paths = array_values(array_unique($paths));
	$fp = false;
	foreach ($paths as $path) {
		if (file_exists($path) && is_readable($path)) { $fp = @fopen($path, 'r'); break; }
	}
	if (!$fp) { return; }
	$line = array();
	while (($l = fgets($fp)) !== false) {
		$l = rtrim($l, "\r\n");
		if ($l !== '') { $line[] = $l; }
	}
	fclose($fp);
	$line = array_reverse($line);
	foreach ($line as $l) {
		if (preg_match('/^([0-9]*),(.*)$/', $l, $m)) {
			out("{$HtagNumber_}턴" . $m[1] . "{$H_tagNumber}: " . $m[2] . "<BR>\n");
		}
	}
}

1;
