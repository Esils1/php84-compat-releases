<?php
$__proto = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https://' : 'http://';
$__base = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\');
$__root = $__proto . $_SERVER['HTTP_HOST'] . $__base;
?>
<?php
// ----------------------------------------------------------------------
// 모형정원 제도 ver2. 30
// 초기설정용 스크립트(ver1. 07)
// PHP 5.5 변환판 - CGI 원본과 동일한 동작 유지
// jcode 미사용 (UTF-8 환경 전제)
// ----------------------------------------------------------------------

if (!function_exists('out')) { function out($s = '') { echo $s; } }
if (!function_exists('random')) { function random($n) { return ($n > 0) ? mt_rand(0, $n - 1) : 0; } }

// 타임존 설정
date_default_timezone_set('Asia/Seoul');

// ----------------------------------------------------------------------
// 패스워드 파일명
// ----------------------------------------------------------------------
$HpasswordFile = 'passwd.php';

// 데이터 디렉토리
$HdirName      = 'data';
$HtempdirName  = 'temp';
$HlogdirName   = 'logdata';
$HprofileDir   = 'profile';

// 기본 URL (마지막 슬래시 없음)
$HbaseDir = $__root;
$HthisFile = $__root . "/hako-main.php";
$HmenteFile = $__root . "/hako-mente.php";

// 이미지 디렉토리
$imageDir = $__root . "/image";

// 진영 게시판·채팅
$baseDir         = 'https://esil.shop/hakophp8.4/';
$efileDir        = "{$HbaseDir}";
$HefileDir       = '.';

// 도움말
$helpDir = $__root . "/help";

// 관리자
$adminName = 'esils';
$email     = 'loverofwind@naver.com';

// 게시판
$bbs  = 'https://esils.com/xe/hakobbs/';
$bbs2 = 'https://esils.com/xe/hakobbs/';

// 홈페이지
$toppage = 'https://esil.shop/hakophp8.4/hako/';

// 로컬 이미지
$Hlocalimage     = 1;
$Hlocalimagehtml = "";
$HlocalImg       = "";

// 로컬 이미지 설정값이 실제 로컬 경로가 아니라 기본 이미지 경로인지 판정한다.
// 빈 값, 현재 서버의 기본 imageDir, 이전 설치본에서 남은 /image 또는 /Bdata/image 쿠키값은 모두 "미설정"으로 본다.
if (!function_exists('hako_imgline_is_unset')) {
function hako_imgline_is_unset($imgLine, $defaultImageDir) {
    $v = trim(str_replace(array('\\"', '"'), '', (string)$imgLine));
    $base = trim(str_replace(array('\\"', '"'), '', (string)$defaultImageDir));
    if ($v === '') { return true; }

    $vn = rtrim($v, '/');
    $bn = rtrim($base, '/');
    if ($bn !== '' && $vn === $bn) { return true; }

    // 파일 선택 방식으로 저장된 정상 로컬 경로는 file:/// 로 시작한다.
    // 반대로 http/https 의 /image, /Bdata/image 는 로컬 설정이 아니라 기본 이미지 폴더 값으로 취급한다.
    if (preg_match('/^https?:\/\//i', $vn)) {
        $path = parse_url($vn, PHP_URL_PATH);
        if ($path !== false && $path !== null) {
            $path = strtolower(rtrim($path, '/'));
            if (preg_match('#/(bdata/)?image$#', $path)) { return true; }
        }
    }
    return false;
}
}


// 락 방식 (2 = flock 추천)
$lockMode = 2;

// 디렉토리 퍼미션
$HdirMode = 0755;

// 1턴 = 몇 초 (3600 = 1시간)
$HunitTime = 3600;

// 턴 갱신 간격 세분화 설정
$HflexTimeSet = 0;
$HflexTime    = array(6, 6, 6, 6);

// 간이 토너먼트 모드
$Htournament = 0;
$HfightMem   = 16;
$HyosenTurn  = 48;
$HtmTime1    = array(4, 0, 4, 0, 4, 0, 4, 0, 4, 0, 4, 0);
$HdevelopeTurn = 8;
$HtmTime2    = array(4, 0, 4, 0, 4, 0, 4, 0, 4, 0, 4, 0);
$HfightTurn  = 6;
$HtmTime3    = array(8, 0, 8, 0, 8, 0);
$HfinalTurn  = 12;
$HinterTime  = 3600 * 20;
$HinterTime2 = 3600 * 2;
$HconsolationMatch = 1;

// 종료 턴 (0 = 자동 종료 없음)
$HlastTurn = 0;

// 전쟁 모드
$HwarFlg = 0;

// 점유율 패배 판정 (0 = 없음)
$Hpossess = 0;

// 자원 구입 명령 금지 (1 = 금지)
$Hbuycommand = 0;

// 간이 서바이벌 모드
$HsurvFlg      = 0;
$Hsurvivalturn = 6;
$Hsstartturn   = 100;

// 1회 갱신으로 진행할 턴수
$HrepeatTurn = 1;

// 도의 최대수
$HmaxIsland = 20;

// 로컬 게시판 행수
$HlbbsMax = 10;

// 커멘드 입력 한계수 (도중 변경 불가)
$HcommandMax = 30;

// 도의 크기 - 짝수만 (도중 변경 불가)
$HislandSize       = 15;
$HislandSizeImage  = 'xbar15.gif';
$HspaceSizeImage   = 'sxbar15.gif';
$HoceanSizeImage   = 'xbar15.gif';

// 해역 크기 (도중 변경 불가)
$HoceanSize = 15;

// 지하 기지 최대수 (도중 변경 불가)
$HugMax = 5;

// 대도시 식량 소비 (0 = 3배 소비, 1 = 통상)
$HbigcityFood = 0;

// 대도시 괴수 출현 (1 = 출현)
$HbigCityMFlg = 1;

// 괴수 배틀 최대 HP
$HmonsBtlMaxHp = 40;

// 괴수 배틀 능력치 합계 최대치
$HmonsBtlMaxPa = 30;

// 원조계 인구 제한 (0 = 제한 없음, 단위: 백)
$Haidpop = 1000;

// 도 발견 후 공격계 제한 턴수
$Hatkturn = 30;

// 유엔 보호 기간
$HdisUN = 30;

// 관리자 전용 모드 (1 = 관리자만 도 작성 가능)
$HadminMode = 0;

// 섬 이름 뒤에 붙는 글자
$AfterName  = '도';
$SpaceName  = '우주';
$OceanName  = '해역';

// 월 이름
$Hmonthname = array('','1월','2월','3월','4월','5월','6월','7월','8월','9월','10월','11월','12월');

// 부하 계측 (1 = 계측)
$Hperformance = 1;

// 관광자 통신용 마스터 패스워드
$HbbsmasterPassword = 'bbsPass';

// 직개발 모드 패스워드
$Hurlownermode = '1111';

// 진영(동맹) 기능
$Hallyflg   = 1;
// 진영모드 원래 설정값을 보존합니다.
// 설정 변경 화면의 진영 선택은 항상 표시하지만, 다른 처리부에서 원래 설정값이 필요할 수 있으므로 보존합니다.
$HallyConfigFlg = $Hallyflg;
$Hallygroup = array("무소속","동맹군","연합군","제국군");
$Hallymark  = array("","＋","Й","Ψ");
$Hallybbs   = 1;
$HallyDisp  = 1;

// 진영 게시판 연동
$Hcampbbs     = 1;
$HcampbbsPath = "{$baseDir}wforum.php";
$campPass     = array("camp1","camp2","camp3","camp4");

// 진영 회의실 연동
$Hcampchat     = 1;
$HcampchatPath = "{$baseDir}chat.php";

// 직접 액세스 금지
$Hlinkcheck = 0;
$HokURL     = array('http://esils.com/');
$HjumpURL   = 'http://esils.com/';

// CSS
$HcssFile      = 'skin/style.css';
$HskinNameList = array('구상표준','구상표준(빨강계)','Hakoniwa R.A. 바람');
$HskinList     = array('skin/khako.css','skin/khako2.css','skin/ra.css');
$HskinName     = '';

// 승리 시 획득 자원
$HwinMoney  = 99999;
$HwinFood   = 99999;
$HwinWeapon = 9999;

// 턴 차이 명령 발동 턴수
$HcomcolonyTurn       = 2;
$HcomSSendMonsterTurn = 2;
$HcomSendMonsterTurn  = 1;

// 초기 자금·식량
$HinitialMoney = 100;
$HinitialFood  = 100;

// 초기 면적 (0 = 랜덤, 설정 범위 35-80)
$HinitialArea = 0;

// 초기 미사일 기지 수
$HinitialBase   = 1;
$HinitialBaseEx = 0;

// 최초부터 우주상 수상 (1 = 예)
$HspacePrize = 0;

// 디버그 모드 (0 = 사용 안함, 1 = 사용)
$Hdebug = 0;
