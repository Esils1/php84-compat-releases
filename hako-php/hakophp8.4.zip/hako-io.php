<?php
// ----------------------------------------------------------------------
// 모형정원 제도 ver2. 30
// 입출력용 스크립트 (ver1. 00)
// PHP 5.5 변환판 - CGI 원본과 동일한 동작 유지
// jcode 미사용 (UTF-8 환경 전제)
// ----------------------------------------------------------------------

if (!function_exists('out')) { function out($s = '') { echo $s; } }
if (!function_exists('random')) { function random($n) { return ($n > 0) ? mt_rand(0, $n - 1) : 0; } }

// ======================================================================
// 턴 차이 명령
// ======================================================================

// 턴 차이 명령 읽기
function readCommandLate() {
    global $HdirName, $HcomL, $HcomLateCt;

    // PHP 8.x: command.dat 파일이 없어도 count($HcomL)가 fatal이 되지 않도록 빈 배열로 초기화한다.
    $HcomL = array();
    $HcomLateCt = 0;
    $filepath = "{$HdirName}/command.dat";

    if (!file_exists($filepath)) {
        return;
    }

    $lines = file($filepath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    if ($lines === false) {
        return;
    }

    foreach ($lines as $line) {
        $parts = explode(',', $line);
        if (count($parts) < 10) continue;

        $obj = array(
            'turn'   => (int)$parts[0],
            'turn2'  => (int)$parts[1],
            'id'     => (int)$parts[2],
            'kind'   => (int)$parts[3],
            'target' => (int)$parts[4],
            'x'      => (int)$parts[5],
            'y'      => (int)$parts[6],
            'arg'    => (int)$parts[7],
            'x2'     => (int)$parts[8],
            'y2'     => (int)$parts[9],
        );
        $HcomL[$HcomLateCt] = $obj;
        $HcomLateCt++;
    }
}

// 턴 차이 명령 추가
function addCommandLate($turn, $turn2, $id, $kind, $target, $x, $y, $arg, $x2, $y2) {
    global $HcomL, $HcomLateCt;

    if (!isset($HcomL) || !is_array($HcomL)) { $HcomL = array(); }
    if (!isset($HcomLateCt)) { $HcomLateCt = count($HcomL); }

    $obj = array(
        'turn'   => $turn + $turn2,
        'turn2'  => $turn2,
        'id'     => $id,
        'kind'   => $kind,
        'target' => $target,
        'x'      => $x,
        'y'      => $y,
        'arg'    => $arg,
        'x2'     => $x2,
        'y2'     => $y2,
    );
    $HcomL[$HcomLateCt] = $obj;
    $HcomLateCt++;
}

// ======================================================================
// 도 데이터 풀다운 메뉴용
// ======================================================================

// 초기화
function tempInitialize() {
    global $defaultID, $HislandList, $HtargetList;

    $HislandList  = getIslandList($defaultID);
    $HtargetList  = getIslandList($defaultID);
}

// 도 리스트 SELECT 옵션 생성
function getIslandList($select) {
    global $HislandNumber, $Hislands, $Hallyflg, $Hallymark, $AfterName, $HbattleNumber;

    $list  = '';
    $list2 = '';
    $HbattleNumber = 0;

    for ($i = 0; $i < $HislandNumber; $i++) {
        $name = $Hislands[$i]['name'];
        $id   = $Hislands[$i]['id'];

        if ($Hallyflg) {
            $ally_idx = (int)$Hislands[$i]['ally'];
            $ally = $Hallymark[$ally_idx] . " ";
        } else {
            $ally = "";
        }

        $s = ($id == $select) ? 'SELECTED' : '';

        if ($id <= 90) {
            $list  .= "<OPTION VALUE=\"{$id}\" {$s}>{$ally}{$name}{$AfterName}\n";
        } else {
            $HbattleNumber++;
            $list2 .= "<OPTION VALUE=\"{$id}\" {$s}>(BF){$name}{$AfterName}\n";
        }
    }

    return $list . $list2;
}

// ======================================================================
// 패스워드 체크
// ======================================================================

// 패스워드 인코드 (crypt 사용)
function encode($plain) {
    global $cryptOn;
    if ($cryptOn == 1) {
        return crypt($plain, 'h2');
    }
    return $plain;
}

// 마스터 패스워드 체크
function checkMasterPassword($pass) {
    global $HmasterPassword;
    return (crypt($pass, 'ma') === $HmasterPassword);
}

// 특수 패스워드 체크
function checkSpecialPassword($pass) {
    global $HspecialPassword;
    return (crypt($pass, 'sp') === $HspecialPassword);
}

// 일반 패스워드 체크
// 반환값: 0 = 불일치, 1 = 본래 패스, 2 = 마스터 패스
function checkPassword($p1, $p2) {
    if ($p2 === '') return 0;
    if (checkMasterPassword($p2)) return 2;
    if ($p1 === encode($p2)) return 1;
    return 0;
}

// 패스워드 체크 (로컬 게시판용)
// 반환값: 0 = 불일치, 1 = 본래 패스, 2 = 로컬BBS 마스터, 3 = 마스터 패스
function checkPasslocalbbs($p1, $p2) {
    global $HbbsmasterPassword;

    if ($p2 === '') return 0;
    if (checkMasterPassword($p2)) return 3;
    if ($HbbsmasterPassword === $p2) return 2;
    if ($p1 === encode($p2)) return 1;
    return 0;
}

// 패스워드 오류 메시지 출력
function tempWrongPassword() {
    global $HtagBig_, $H_tagBig, $HtempBack;
    out("{$HtagBig_}패스워드가 틀렸습니다.{$H_tagBig}{$HtempBack}");
}

// 일반 오류 메시지 출력
function tempWrong($msg) {
    global $HtagBig_, $H_tagBig, $HtempBack;
    out("{$HtagBig_}{$msg}{$H_tagBig}{$HtempBack}");
}

// ======================================================================
// IP 주소 취득
// ======================================================================

// 원본: 전역변수 $host, $addr 를 직접 수정 (반환값 없음)
function get_host($force = false) {
    global $Hlipdisp, $get_remotehost, $host, $addr;

    $host = '';
    $addr = '';

    if ($Hlipdisp || $force) {
        $addr = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '';
        $host = isset($_SERVER['REMOTE_HOST']) ? $_SERVER['REMOTE_HOST'] : '';

        if ($get_remotehost) {
            if ($host === '' || $host === $addr) {
                $resolved = gethostbyaddr($addr);
                $host = ($resolved !== false) ? $resolved : $addr;
            }
        }

        if ($host === '') $host = $addr;

        $addr = "({$addr})";
    }
}

// ======================================================================
// 액세스 로그 기록
// ======================================================================

function axeslog() {
    global $HaxesLogfile, $HaxesMax, $HtopAxes, $defaultID, $HcurrentID;

    $agent   = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';
    $addr    = isset($_SERVER['REMOTE_ADDR'])     ? $_SERVER['REMOTE_ADDR']     : '';
    $host    = isset($_SERVER['REMOTE_HOST'])     ? $_SERVER['REMOTE_HOST']     : '';
    $referer = (!isset($HtopAxes) || $HtopAxes != 1)
               ? (isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : '')
               : '';

    if ($host === $addr || $host === '') {
        $resolved = gethostbyaddr($addr);
        $host = ($resolved !== false) ? $resolved : $addr;
    }

    $date = date('Y/m/d(D) H:i:s');
    // 요일을 한국어로 변환
    $dayMap = array('Sun'=>'일','Mon'=>'월','Tue'=>'화','Wed'=>'수','Thu'=>'목','Fri'=>'금','Sat'=>'토');
    $engDay = date('D');
    $korDay = isset($dayMap[$engDay]) ? $dayMap[$engDay] : $engDay;
    $date   = date("Y/m/d({$korDay}) H:i:s");

    // 기존 로그 읽기
    $lines = array();
    if (file_exists($HaxesLogfile)) {
        $lines = file($HaxesLogfile, FILE_IGNORE_NEW_LINES);
        if ($lines === false) $lines = array();
    }

    // 최대 건수 유지
    while (count($lines) >= $HaxesMax) {
        array_pop($lines);
    }

    // ID 결정
    if (isset($HtopAxes) && $HtopAxes == 1) {
        $id = ($defaultID == $HcurrentID) ? $defaultID : "{$defaultID}=>{$HcurrentID}";
    } else {
        $id = $defaultID;
    }

    // 새 로그 앞에 추가
    array_unshift($lines, "[{$date}] - {$referer} - {$host} - {$addr} - {$agent} - {$id}");

    // 쓰기
    $fp = fopen($HaxesLogfile, 'w');
    if ($fp === false) {
        tempProblem();
        return;
    }
    flock($fp, LOCK_EX);
    foreach ($lines as $line) {
        fwrite($fp, $line . "\n");
    }
    flock($fp, LOCK_UN);
    fclose($fp);
}

// ======================================================================
// 출력 함수
// ======================================================================

// 표준 출력 (UTF-8) - hako-io.php가 단독 include될 때를 위한 정의
if (!function_exists('out')) {
    function out($s = '') {
        echo $s;
    }
}

// 디버그 로그
function HdebugOut($msg) {
    global $HislandTurn;
    $fp = fopen('debug.log', 'a');
    if ($fp) {
        fwrite($fp, "{$HislandTurn},{$msg}\n");
        fclose($fp);
    }
}

// HTML 이스케이프
function htmlEscape($s) {
    $s = (string)($s ?? '');
    $s = str_replace('&', '&amp;', $s);
    $s = str_replace('<', '&lt;', $s);
    $s = str_replace('>', '&gt;', $s);
    $s = str_replace('"', '&quot;', $s);
    $s = str_replace("'", '&#39;', $s);
    $s = str_replace(' ', '&nbsp;', $s);
    return $s;
}
