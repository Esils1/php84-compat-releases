<?php
// ----------------------------------------------------------------------
// 모형정원 제도 ver2. 30
// 액세스 해석 스크립트 ver1. 01
// PHP 5.5 변환판 - CGI 원본과 동일한 동작 유지
// jcode 미사용 (UTF-8 환경 전제)
//
// 원작: 장 고양이  http://www.midnightroam.org/
// ----------------------------------------------------------------------

if (!function_exists('out')) { function out($s = '') { echo $s; } }
if (!function_exists('random')) { function random($n) { return ($n > 0) ? mt_rand(0, $n - 1) : 0; } }

include_once "./hako-init.php";

// ======================================================================
// 초기 설정
// ======================================================================

$title         = 'Log analyzer CGI';
$logfile       = './axes.php';

$axeslog_no    = 100;   // 액세스 로그 표시 건수
$referer_hide  = 0;     // 도메인 비표시 (1=비표시, 0=표시)
$referer_sweep = 1;     // 리퍼러를 넘겨주지 않음 (2=JS, 1=CGI, 0=없음)
$delaytime     = 0;     // 리프레시 지연 시간

$script    = './analyzer.php';
$separator = ' - ';

$copyright = '<DIV align=right>[ <A href="http://www.midnightroam.org/">Log analyzer CGI</A> ]' . "\n</DIV>";

$CATEGORY = array(
    'date'    => '일별',
    'hour'    => '시간대',
    'referer' => '도이름',
    'host'    => '호스트명',
    'addr'    => 'IP주소',
    'agent'   => '브라우저명',
    'id'      => 'ID',
    'a'       => '액세스·로그',
);

// ======================================================================
// 패스워드 파일 읽기
// ======================================================================

$HmasterPassword = '';
if (file_exists($HpasswordFile)) {
    $lines = file($HpasswordFile, FILE_IGNORE_NEW_LINES);
    if ($lines !== false && isset($lines[0])) {
        $HmasterPassword = trim($lines[0]);
    }
}

// ======================================================================
// 리퍼러 스위퍼용 JavaScript (필요 시)
// ======================================================================

$rs = '';
if (!$referer_hide && $referer_sweep == 2) {
    $rs = <<<JSEOF
<script Language="JavaScript">
<!--
function link(url){
    app = navigator.appName.charAt(0);
    if(app == 'M') {
        w = window.open('','','');
        w.document.write("<html><head>");
        w.document.write("<meta HTTP-EQUIV='refresh' CONTENT='{$delaytime}; URL="+ url +"'></head>");
        w.document.write("<body></body></html>");
        w.location.reload();
    } else {
        document.write("<html><head>");
        document.write("<meta HTTP-EQUIV='refresh' CONTENT='{$delaytime}; URL="+ url +"'></head>");
        document.write("<body></body></html>");
    }
}
//-->
</script>
JSEOF;
}

// ======================================================================
// 라우팅
// ======================================================================

// URL 파라미터로 리퍼러 스위퍼 동작
$url = isset($_GET['url']) ? $_GET['url'] : '';

if ($url !== '') {
    // 리퍼러를 넘기지 않고 리다이렉트
    header("Content-Type: text/html; charset=UTF-8");
    echo <<<HTML
<html>
<head>
<title>Referrer-Sweeper</title>
<meta HTTP-EQUIV="refresh" CONTENT="{$delaytime}; URL={$url}">
{$rs}
</head>
<body>
<h1>
액세스중...  잠깐 기다려 주세요...
<hr>
<center>
<a href="{$url}">{$url}</a>
</center>
</h1>
</body>
</html>
HTML;
    exit;
}

// POST 처리
$FORM = form_decode();

if (!passCheck($FORM)) {
    $referer_hide = 1;
}

if (isset($FORM['mode']) && $FORM['mode'] === 'analyze') {
    analyze($FORM['category'], $FORM);
} else {
    htmlOutput('', $FORM);
}

// ======================================================================
// 폼 디코드
// ======================================================================

function form_decode() {
    $FORM = array();

    $requestMethod = isset($_SERVER['REQUEST_METHOD']) ? strtoupper((string)$_SERVER['REQUEST_METHOD']) : 'GET';
    if ($requestMethod === 'POST') {
        // PHP는 $_POST로 자동 디코드됨
        foreach ($_POST as $name => $value) {
            $value = htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
            $value = str_replace("\r\n", "\n", $value);
            $FORM[$name] = $value;
        }
        // 부정 입력 배제
        if (isset($FORM['select_date'])) {
            $FORM['select_date'] = preg_replace('/["@\/`\\\\]/', '', $FORM['select_date']);
        }
    }

    return $FORM;
}

// ======================================================================
// 해석 처리
// ======================================================================

function analyze($category, $FORM) {
    global $logfile, $separator, $CATEGORY, $axeslog_no, $referer_hide, $referer_sweep, $script;

    if (!file_exists($logfile)) {
        htmlOutput('<DIV align=center>로그 파일이 없습니다.</DIV>', $FORM);
        return;
    }

    // 원본: while(<LOG>) { last if(!$_) } → 빈 줄 만나면 중단
    $fp = fopen($logfile, 'r');
    if ($fp === false) {
        htmlOutput('<DIV align=center>로그 파일을 읽을 수 없습니다.</DIV>', $FORM);
        return;
    }

    $DATA = array();
    $all  = 0;
    $item_log = '';  // 'a' 카테고리 전용 누적 HTML

    while (($line = fgets($fp)) !== false) {
        // 원본과 동일: 빈 줄이면 중단
        $line = rtrim($line, "\r\n");
        if ($line === '') break;

        $parts = explode($separator, $line);

        switch ($category) {
            case 'date':
                $tmp  = isset($parts[0]) ? $parts[0] : '';
                $item = substr($tmp, 1, 14);
                break;

            case 'hour':
                $tmp  = isset($parts[0]) ? $parts[0] : '';
                $item = substr($tmp, 16, 2) . '시';
                $item = preg_replace('/^0/', '&nbsp;', $item);
                break;

            case 'referer':
                if ($referer_hide) {
                    htmlOutput('<DIV align=center>도이름은 현재 비표시 설정이 되어 있습니다.</DIV>', $FORM);
                    return;
                }
                $item = isset($parts[1]) ? $parts[1] : '';
                $item = refererLink($item, $referer_sweep, $script);
                break;

            case 'host':
                $item = isset($parts[2]) ? $parts[2] : '';
                // 일본 도메인 마스킹 (원본 로직 유지)
                if (preg_match('/^.+\.(.+)\.(ac|ne|go|gr|co|or|ad)\.jp$/i', $item, $m)) {
                    $item = "*.{$m[1]}.{$m[2]}.jp";
                } elseif (preg_match('/^YahooBB(\d+)\.bbtec\.net$/i', $item)) {
                    $item = "YahooBB***.bbtec.net";
                }
                break;

            case 'addr':
                $item = isset($parts[3]) ? $parts[3] : '';
                break;

            case 'agent':
                $item = isset($parts[4]) ? $parts[4] : '';
                break;

            case 'id':
                $item = isset($parts[5]) ? rtrim($parts[5], "\r\n") : '';
                break;

            case 'a':
                $tmp   = isset($parts[0]) ? $parts[0] : '';
                $idtmp = isset($parts[5]) ? rtrim($parts[5], "\r\n") : '';
                $host  = isset($parts[2]) ? $parts[2] : '';
                $addr  = isset($parts[3]) ? $parts[3] : '';
                $agent = isset($parts[4]) ? $parts[4] : '';
                $ref   = isset($parts[1]) ? $parts[1] : '';

                $item_log .= '<TR><TD><nobr>' . substr($tmp, 1, 23) . '</nobr></TD>';
                $item_log .= '<TD align=right><nobr>' . $idtmp . '</nobr></TD>';
                $item_log .= '<TD><nobr>' . $host . '</nobr></TD>';
                $item_log .= '<TD><nobr>' . $addr . '</nobr></TD>';
                $item_log .= '<TD><nobr>' . $agent . '</nobr></TD>';
                if (!$referer_hide) {
                    $ref = refererLink($ref, $referer_sweep, $script);
                    $item_log .= '<TD><nobr>' . $ref . '</nobr></TD>';
                }
                $item_log .= '</TR>';
                $all++;
                if ($all >= $axeslog_no) {
                    break 2;  // switch + while 동시 탈출
                }
                continue 2;  // switch 건너뛰고 while 다음 반복

            default:
                $item = '';
        }

        $item = rtrim($item, "\r\n");
        if ($item === '') $item = 'none';

        if (!isset($DATA[$item])) $DATA[$item] = 0;
        $DATA[$item]++;
        $all++;
    }
    fclose($fp);

    // ---- 결과 HTML 생성 ----
    if ($category !== 'a') {
        arsort($DATA);

        $result  = "<DIV align=center>\n<TABLE border=0 cellPadding=2 cellSpacing=5>\n";
        $result .= "<TR><TD align=center>{$CATEGORY[$category]}</TD><TD align=center>회수</TD><TD align=center>비율</TD></TR>\n";

        foreach ($DATA as $key => $count) {
            $per     = sprintf("%.1f", ($all > 0) ? ($count / $all) * 100 : 0);
            $result .= "<TR><TD>{$key}</TD><TD align=center>{$count}</TD><TD align=center>( {$per}% )</TD></TR>\n";
        }

        $result .= "<TR><TD colSpan=3><HR color=#FFFFFF size=1 noShade></TD></TR>\n";
        $result .= "<TR><TD><BR></TD><TD align=center>{$all}</TD><TD align=center><BR></TD></TR>\n";
        $result .= "</TABLE>\n</DIV>";
    } else {
        $result  = "<TABLE border=1 cellpadding=1 cellspacing=0><TBODY>\n";
        $result .= "<TR>";
        $result .= "<TH>Date</TH>";
        $result .= "<TH>ID</TH>";
        $result .= "<TH>Host</TH>";
        $result .= "<TH>Ip</TH>";
        $result .= "<TH>Agent</TH>";
        if (!$referer_hide) {
            $result .= "<TH>Referer</TH>";
        }
        $result .= "</TR>\n";
        $result .= $item_log;
        $result .= "</TBODY></TABLE>";
    }

    htmlOutput($result, $FORM);
}

// ======================================================================
// 리퍼러 링크 변환
// ======================================================================

function refererLink($item, $referer_sweep, $script) {
    $pattern = '/((?:^|[^="])(https?:[\w.\~\-\/\?\&\+\=\:\@\%\;\#]+))/';

    if ($referer_sweep == 1) {
        $item = preg_replace_callback(
            '/(^|[^="])(https?:[\w.\~\-\/\?\&\+\=\:\@\%\;\#]+)/',
            function($m) use ($script) {
                return $m[1] . '<A href="' . $script . '?' . $m[2] . '" target="_blank">' . $m[2] . '</A>';
            },
            $item
        );
    } elseif ($referer_sweep == 2) {
        $item = preg_replace_callback(
            '/(^|[^="])(https?:[\w.\~\-\/\?\&\+\=\:\@\%\;\#]+)/',
            function($m) {
                return $m[1] . '<A href="javascript:link(\'' . $m[2] . '\');">' . $m[2] . '</A>';
            },
            $item
        );
    } else {
        $item = preg_replace_callback(
            '/(^|[^="])(https?:[\w.\~\-\/\?\&\+\=\:\@\%\;\#]+)/',
            function($m) {
                return $m[1] . '<A href="' . $m[2] . '" target="_blank">' . $m[2] . '</A>';
            },
            $item
        );
    }

    return $item;
}

// ======================================================================
// 패스워드 관련
// ======================================================================

function passCheck($FORM) {
    global $HtagBig_, $H_tagBig;
    $pass = isset($FORM['password']) ? $FORM['password'] : '';
    if (checkMasterPassword($pass)) {
        return true;
    }
    // 원본: 패스워드 틀리면 에러 메시지 출력 후 0 반환
    if ($pass !== '') {
        out("{$HtagBig_}패스워드가 다릅니다{$H_tagBig}");
    }
    return false;
}

function checkMasterPassword($pass) {
    global $HmasterPassword;
    if ($HmasterPassword === '') return false;
    return (crypt($pass, 'ma') === $HmasterPassword);
}

// ======================================================================
// HTML 출력
// ======================================================================

function htmlOutput($result, $FORM) {
    global $title, $script, $CATEGORY, $rs, $copyright, $referer_hide, $referer_sweep;

    $i = 0;
    $option_list = '';
    $isPass = passCheck($FORM);
    $password_val = htmlspecialchars(isset($FORM['password']) ? $FORM['password'] : '', ENT_QUOTES, 'UTF-8');

    ksort($CATEGORY);
    foreach ($CATEGORY as $key => $label) {
        // 패스워드 없으면 비공개 항목 숨김
        if (!$isPass && ($key === 'a' || $key === 'addr' || $key === 'id')) {
            continue;
        }
        if ($i === 0) {
            $option_list .= "<OPTION value=\"{$key}\" selected>{$label}\n";
            $i++;
        } else {
            $option_list .= "<OPTION value=\"{$key}\">{$label}\n";
        }
    }

    header("Content-Type: text/html; charset=UTF-8");
    echo <<<HTML
<HTML>
<HEAD>
<TITLE>{$title}</TITLE>
<META http-equiv="Content-Style-Type" content="text/css">
<META http-equiv="Content-Type" content="text/html;charset=UTF-8">
<STYLE type="text/css">
<!--
A               { text-decoration:none }
A:link          { color: #FF0000 }
A:visited       { color: #FFFF00 }
A:hover         { text-decoration:underline; color: #00FF00 }
BODY,TD         { font-size:12px; }
BODY            {
                scrollbar-Track-Color: #000000;
                scrollbar-Face-Color: #000000;
                scrollbar-Shadow-Color: #778899;
                scrollbar-DarkShadow-Color: #333333;
                scrollbar-Highlight-Color: #FFFFFF;
                scrollbar-3dLight-Color: #606060;
                scrollbar-Arrow-Color: #FFFFFF;
                }
INPUT,SELECT,TEXTAREA {
                color: #778899;
                border-color: #333333;
                background: #000000;
                }
-->
</STYLE>
HTML;

    if (!$referer_hide && $referer_sweep == 2) {
        echo $rs;
    }

    echo <<<HTML
</HEAD>
<BODY bgColor=#000000 text=#CCCCCC>
{$title}
<HR size=1 color=#FFFFFF width=100% noShade>
<BR>
<BR>
<FORM action="{$script}" method="POST">
<B>master password：</B><INPUT type="password" size="16" maxlength="32" name="password" value="{$password_val}">
<BR>
<INPUT type="hidden" name="mode" value="analyze">
<SELECT name="category">
{$option_list}
</SELECT>
<INPUT type="submit" value="집계">
</FORM>
<BR>
<BR>
<BR>
<BR>
{$result}
<BR>
{$copyright}
</BODY>
</HTML>
HTML;

    exit;
}
