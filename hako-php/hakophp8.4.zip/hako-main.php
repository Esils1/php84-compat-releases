<?php
if (!isset($_hako_fh)) { $_hako_fh = array(); }

if (!isset($GLOBALS['_hako_req_start'])) { $GLOBALS['_hako_req_start'] = microtime(true); }
if (!isset($GLOBALS['_hako_req_ru_start'])) { $GLOBALS['_hako_req_ru_start'] = function_exists('getrusage') ? getrusage() : null; }
if (!function_exists('hako_cpu_times')) {
function hako_cpu_times() {
    $startRu = isset($GLOBALS['_hako_req_ru_start']) ? $GLOBALS['_hako_req_ru_start'] : null;
    if (function_exists('getrusage') && is_array($startRu)) {
        $r = getrusage();
        $u0 = (isset($startRu['ru_utime.tv_sec']) ? $startRu['ru_utime.tv_sec'] : 0) + (isset($startRu['ru_utime.tv_usec']) ? $startRu['ru_utime.tv_usec'] : 0) / 1000000;
        $s0 = (isset($startRu['ru_stime.tv_sec']) ? $startRu['ru_stime.tv_sec'] : 0) + (isset($startRu['ru_stime.tv_usec']) ? $startRu['ru_stime.tv_usec'] : 0) / 1000000;
        $u1 = (isset($r['ru_utime.tv_sec']) ? $r['ru_utime.tv_sec'] : 0) + (isset($r['ru_utime.tv_usec']) ? $r['ru_utime.tv_usec'] : 0) / 1000000;
        $s1 = (isset($r['ru_stime.tv_sec']) ? $r['ru_stime.tv_sec'] : 0) + (isset($r['ru_stime.tv_usec']) ? $r['ru_stime.tv_usec'] : 0) / 1000000;
        $uti = max(0, $u1 - $u0);
        $sti = max(0, $s1 - $s0);
        return array(round($uti + $sti, 4), round($uti, 4), round($sti, 4));
    }
    $start = isset($GLOBALS['_hako_req_start']) ? $GLOBALS['_hako_req_start'] : (isset($_SERVER['REQUEST_TIME_FLOAT']) ? $_SERVER['REQUEST_TIME_FLOAT'] : microtime(true));
    $elapsed = microtime(true) - $start;
    if ($elapsed < 0) { $elapsed = 0; }
    return array(round($elapsed, 4), round($elapsed, 4), 0);
}
}
if (!function_exists('hako_open')) {
  function hako_open($name, $spec) {
    global $_hako_fh;
    $mode = 'r';
    $path = $spec;
    if (substr($path, 0, 2) === '>>') { $mode = 'a'; $path = substr($path, 2); }
    elseif (substr($path, 0, 1) === '>') { $mode = 'w'; $path = substr($path, 1); }
    elseif (substr($path, 0, 1) === '<') { $mode = 'r'; $path = substr($path, 1); }
    $_hako_fh[$name] = @fopen($path, $mode);
    return $_hako_fh[$name];
  }
  function hako_close($name) {
    global $_hako_fh;
    if (isset($_hako_fh[$name]) && is_resource($_hako_fh[$name])) { fclose($_hako_fh[$name]); }
  }
  function hako_getline($name) {
    global $_hako_fh;
    if (!isset($_hako_fh[$name]) || !$_hako_fh[$name]) { return false; }
    return fgets($_hako_fh[$name]);
  }
  function hako_write($name, $data) {
    global $_hako_fh;
    if (!isset($_hako_fh[$name]) || !$_hako_fh[$name]) { return false; }
    return fwrite($_hako_fh[$name], $data);
  }
  function hako_cmp($a, $b) {
    if ($a == $b) { return 0; }
    return ($a < $b) ? -1 : 1;
  }
  function hako_reorder($array, $idx) {
    $out = array();
    foreach ($idx as $i) { if (isset($array[$i])) { $out[] = $array[$i]; } }
    return $out;
  }
  function hako_pick($array, $keys) {
    $out = array();
    foreach ($keys as $key) { $out[] = isset($array[$key]) ? $array[$key] : null; }
    return (count($keys) == 1) ? $out[0] : $out;
  }
  function hako_idx($array, $idx) {
    return isset($array[$idx]) ? $array[$idx] : null;
  }
}
// #!/usr/bin/perl
// ↑(은)는 서버에 맞추어 변경해 주세요.
// perl5용입니다.
//----------------------------------------------------------------------
// 모형정원 제도 ver2. 30
// 메인 스크립트(ver1. 02)
// 사용 조건, 사용 방법등은, hako-readme.txt 파일을 참조
// 모형정원 제도의 페이지: http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html
//----------------------------------------------------------------------
// 구상의 모형정원 「모두 걷는 모형정원 진화론」
$versionInfo = "php8.4호한 v1";
//----------------------------------------------------------------------
// Perl BEGIN error handlers omitted for PHP runtime.
//----------------------------------------------------------------------
//  환경 설정 부분은"hako-init.php"및"init-game.php"에 있습니다.
//----------------------------------------------------------------------
require_once "./hako-init.php";

if (!function_exists('hako_fix_bad_quoted_url')) {
function hako_fix_bad_quoted_url($u) {
    $u = str_replace(array('\\"','%5C%22','%22','"'), '', $u);
    return $u;
}
}
if (isset($GLOBALS['HthisFile'])) { $GLOBALS['HthisFile'] = hako_fix_bad_quoted_url($GLOBALS['HthisFile']); }
if (isset($GLOBALS['HbaseDir'])) { $GLOBALS['HbaseDir'] = hako_fix_bad_quoted_url($GLOBALS['HbaseDir']); }

require_once "./hako-io.php";
require_once "./init-game.php";

// 이상종료(ABEND) 기준 시간
// (락 후몇초로, 강제 해제할까)
$unlockTime = 60;

//----------------------------------------------------------------------
// 변수
//----------------------------------------------------------------------

// COOKIE
//my($defaultID);   # 도의 이름
$defaultID;     # 도의 이름
$defaultTarget; # 타겟의 이름


// 도의 좌표수
$HpointNumber = $HislandSize * $HislandSize;

// 해역의 좌표수
$HpointOcean = $HoceanSize * $HoceanSize;

//----------------------------------------------------------------------
// 메인
//----------------------------------------------------------------------

get_host(0);

// 「돌아온다」링크
$HtempBack = "<A HREF=\"$HthisFile\">{$HtagBig_}돌아가기{$H_tagBig}</A>";
$Body = "<BODY $htmlBody>";

//  락을 걸친다
if(!hakolock()) {
	// 락 실패
	// 헤더 출력
	tempHeader();

	// 락 실패 메세지
	tempLockFail();

	// footer 출력
	tempFooter();

	// 종료
	exit(0);
}

// 난수의 초기화
mt_srand(time() ^ getmypid());

// COOKIE 읽어들여
cookieInput();

// CGI 읽어들여
cgiInput();

if (file_exists($HpasswordFile)) {
	// 패스워드 파일이 있다
	hako_open('PIN', "<$HpasswordFile") or die("file open failed");
	$HmasterPassword = rtrim(hako_getline('PIN'));# master password를 읽어들인다
	$HspecialPassword = rtrim(hako_getline('PIN'));# 특수 패스워드를 읽어들인다
	hako_close('PIN');
} else {
	unlock();
	tempHeader();
	tempNoPasswordFile();
	tempFooter();
	exit(0);
}
// 직접 링크 금지
if($Hlinkcheck){
if (!(($HmainMode == 'print') || ($HmainMode == 'owner') || ($HmainMode == 'landmap'))) {
	$referer = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : '';
	$linkOk = false;

	foreach (array_merge((array)$HokURL, array($HthisFile)) as $_) {
		if ($_ === null || $_ === '') { continue; }
		if (preg_match('/^' . preg_quote($_, '/') . '/', $referer)) {
			$linkOk = true;
			break;
		}
	}

	if (!$linkOk) {
		// 에러
		header("Location: " . $HjumpURL);
		exit;
	}
}
}
// 관리자모드
if((file_exists("./mente_lock")) && !checkMasterPassword($HdefaultPassword)) {
	cookieOutput();
	unlock();
	mente_mode(1);
}
// 도데이터의 읽어들여
if(readIslandsFile($HcurrentID) == 0) {
	unlock();
	tempHeader();
	tempNoDataFile();
	tempFooter();
	exit(0);
}

// 템플릿을 초기화
tempInitialize();

// COOKIE에 의한 ID체크
if($HmainMode == 'owner') {
	// 액세스·로그
	if ($HtopAxes == 1) { axeslog(); }
	
	if (empty($_SERVER['HTTP_COOKIE'])) {
		cookieOutput(); # COOKIE가 삭제되었는지 어떠했는지 기입 체크
		if (!empty($_SERVER['HTTP_COOKIE'])) { exit(0); }
		// 쿠키를 유효하게 하고 있지 않다
		unlock();
		tempHeader();
		tempWrong("쿠키를 유효하게 해주세요.");
		tempFooter();
		exit(0);
	}
	if($checkID || $checkImg) {
		// id로부터 도을 취득
		$pcheck = checkPassword($Hislands[$HidToNumber[$HcurrentID]]['password'],$HinputPassword);
		$free = 0;
		foreach ($freepass as $_) {
			if (($_ == $defaultID) || ($_ == $HcurrentID)) { $free += 1; }
		}
		$icheck = !($checkID && ($HcurrentID != $defaultID) && $defaultID);
		$lcheck = !($checkImg && hako_imgline_is_unset($HimgLine, $imageDir));
		// 패스워드
		if(($pcheck != 2) && ($free != 2) && (!$icheck || !$lcheck)) {
			// 1개의 도을 초심자용으로 해방할 때 등은 ($free ! = 2)의 부분을 ! $free 로 변경해 주세요.
			unlock();
			tempHeader();
			if(!$icheck) {
				tempWrong("자신의 섬 외에는 넣지 않습니다"); # ID차이?
			} else {
				tempWrong("「이미지의 로컬 설정」을 해 주세요."); # 로컬 설정하고 있지 않다
			}
			tempFooter();
			exit(0);
		}
	}
}

// COOKIE 출력
cookieOutput();

if($HmainMode == 'owner' && $HjavaMode == 'java' ||
	$HmainMode == 'monsedit' && $HjavaMode == 'java' || # 괴수 편집
	$HmainMode == 'commandJava' || # 커멘드 입력 모드
	$HmainMode == 'command2' || # 커멘드 입력 모드(ver1. 1보다 추가·자동계용)
	$HmainMode == 'comment' && $HjavaMode == 'java' || # 코멘트 입력 모드?
	$HmainMode == 'lbbs' && $HjavaMode == 'java') { # 코멘트 입력 모드
	
	require('hako-js.php');
	require('hako-map.php');
	
	// 헤더 출력
	tempHeader(1);
	if($HmainMode == 'commandJava') {
		// 개발 모드
		commandJavaMain();
	} elseif($HmainMode == 'monsedit') {
		// 괴수 설정
		monsMain();
	} elseif($HmainMode == 'command2') {
		// 개발 모드 2(자동계 커멘드용(ver1. 1보다 추가·자동계용))
		commandMain();
	} elseif($HmainMode == 'comment') {
		// 코멘트 입력 모드
//		if($Hrsswrite){require('hako-rss.cgi');rssMain();}
		commentMain();
	} elseif($HmainMode == 'lbbs') {
		// 로컬 게시판 모드
//		if($Hrsswrite){require('hako-rss.cgi');rssMain();}
		localBbsMain();
	}else{
	    ownerMain();
	}
	// footer 출력
	tempFooter();
	// 종료
	exit(0);
}elseif($HmainMode == 'landmap'){
	require('hako-js.php');
	require('hako-map.php');
	if($HcurrentID == 999){
		// 우주
		$Body = "<BODY BGCOLOR=\"BLACK\" TEXT=\"WHITE\" LINK=\"#AAAAFF\" ALINK=\"GREEN\" VLINK=\"#AAAAFF\" BACKGROUND=\"star.gif\" BGPROPERTIES=FIXED>";
		$HskinName = 'space.css';
		tempHeader();
		printIslandJava(3);
	}elseif($HcurrentID == 888){
		// 해역
		$Body = "<BODY BGCOLOR=\"BULE\" TEXT=\"WHITE\" LINK=\"#AAAAFF\" ALINK=\"GREEN\" VLINK=\"#AAAAFF\" BACKGROUND=\"land0.gif\" BGPROPERTIES=FIXED>";
		$HskinName = 'ocean.css';
		tempHeader();
		printIslandJava(4);
	}elseif($Hugmode){
		// 지하
		tempHeader();
		printIslandJava(10);
	}else{
		tempHeader();
		printIslandJava(0);
	}
	// footer 출력
	tempFooter();
	// 종료
	exit(0);
}elseif($HmainMode == 'space'){
	$Body = "<BODY BGCOLOR=\"BLACK\" TEXT=\"WHITE\" LINK=\"#AAAAFF\" ALINK=\"GREEN\" VLINK=\"#AAAAFF\" BACKGROUND=\"star.gif\" BGPROPERTIES=FIXED>";
	$HskinName = 'space.css';
	tempHeader();
	require('hako-map.php');
	spaceMap();
	tempFooter();
	exit(0);
}elseif($HmainMode == 'ocean'){
	$Body = "<BODY BGCOLOR=\"BULE\" TEXT=\"WHITE\" LINK=\"#AAAAFF\" ALINK=\"GREEN\" VLINK=\"#AAAAFF\" BACKGROUND=\"land0.gif\" BGPROPERTIES=FIXED>";
	$HskinName = 'ocean.css';
	tempHeader();
	require('hako-map.php');
	oceanMap();
	tempFooter();
	exit(0);
}elseif(($HmainMode == 'new') || ($HmainMode == 'bfield')) {
//	HdebugOut("모드 :$HmainMode");
}else{
	// 헤더 출력
	tempHeader();
}

if($HmainMode == 'turn') {
	// 턴 진행
	require('hako-turn.php');
	require('hako-top.php');
	require('exchange.php');
	turnMain();
} elseif($HmainMode == 'new') {
	// 도의 신규 작성
	require('hako-make.php');
	require('hako-map.php');
	newIslandMain(0);
} elseif($HmainMode == 'rekidai') {
	// 역대 인구 기록 neo_otacky씨가 작성
	require('hako-make.php');
	rekidaiPopMain();
} elseif($HmainMode == 'print') {
	// 관광 모드
	require('hako-map.php');
	printIslandMain();
} elseif($HmainMode == 'owner') {
	// 개발 모드
	require('hako-map.php');
	ownerMain();
} elseif($HmainMode == 'command') {
	// 커멘드 입력 모드?
	require('hako-map.php');
	commandMain();
} elseif($HmainMode == 'comment') {
	// 코멘트 입력 모드
//	if($Hrsswrite){require('hako-rss.cgi');rssMain();}
	require('hako-map.php');
	commentMain();
} elseif($HmainMode == 'clbbs') {
	// 코멘트·관광자 통신·근황
	$HmainMode = 'owner';
	require('hako-map.php');
	clbbsMain();
} elseif($HmainMode == 'custom') {
	// 커스터마이즈
	$HmainMode = 'owner';
	require('hako-map.php');
	customMain();
} elseif($HmainMode == 'custom2') {
	// 커스터마이즈 2
	$HmainMode = 'owner';
	require('hako-map.php');
	customMain(1);
} elseif($HmainMode == 'lbbs') {
	// 로컬 게시판 모드
//	if($Hrsswrite){require('hako-rss.cgi');rssMain();}
	require('hako-map.php');
	localBbsMain();
} elseif($HmainMode == 'monsedit') {
	// 괴수 설정
	require('hako-map.php');
	monsMain();
} elseif($HmainMode == 'change') {
	// 정보 변경 모드
	require('hako-make.php');
	changeMain();
} elseif($HmainMode == 'FightIsland') {
	// 간이 토너먼트 패자 도표시
	require('hako-js.php');
	require('hako-map.php');
	fight_map();
} elseif($HmainMode == 'FightView') {
	// 간이 토너먼트 LOG 모드
	require('hako-js.php');
	require('hako-map.php');
	FightViewMain();
} elseif($HmainMode == 'camp') {
	// 진영 모드
	require('hako-map.php');
	require('hako-camp.php');
	campMain();
} elseif($HmainMode == 'exchange') {
	// 자원 거래 모드
	if(($HexchangeMode != 'show') && ($HtopAxes == 1)){
		// 액세스·로그?
		axeslog();
	}
	require('exchange.php');
	mainExchange();
} elseif($HmainMode == 'kani') {
	// 간이 탑 페이지 표시 모드?
	require('hako-top.php');
	topPageMain(1);
} elseif($HmainMode == 'alist') {
	// 간이 탑 페이지 표시 모드
	require('hako-top.php');
	topPageAlist();
} elseif($HmainMode == 'settei') { # 로컬 이미지 지정
	// 설정 탑 페이지 표시 모드
	require('hako-top.php');
	topPageMain(2);

} elseif($HmainMode == 'list') {
	// 상세 리스트
	require('hako-top.php');
	topPageMain(3);
} elseif($HmainMode == 'bfield') {
	// BattleField 작성 모드
	require('hako-make.php');
	require('hako-map.php');
	bfieldMain();
} elseif($HmainMode == 'present') {
	// 관리인에 의한 선물 모드
	require('hako-make.php');
	presentMain();
} elseif($HmainMode == 'punish') {
	// 관리인에 의한 제재 모드
	require('hako-make.php');
	punishMain();
} elseif($HmainMode == 'lchange') {
	// 관리인에 의한 지형 변경 모드
	require('hako-map.php');
	require('hako-make.php');
	lchangeMain();
} elseif($HmainMode == 'predelete') {
	// 관리인에 의한 보관 모드
	require('hako-make.php');
	preDeleteMain();
} elseif($HmainMode == 'ichange') {
	// 관리인에 의한 각종도데이터 변경 모드
	require('hako-make.php');
	ichangeMain();
} elseif($HmainMode == 'setupv') {
	// 초기설정 확인 모드
	require('hako-make.php');
	setupValue();
} else {
	//  그 외의 경우는 탑 페이지 모드?
	require('hako-top.php');
	topPageMain(0);
}

// footer 출력
tempFooter();

// 종료
exit(0);

// 커멘드를 앞에 두고 비켜 놓는다
function slideFront(&$command, $number) {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $Halistmode, $Hallyflg, $Hasync, $HbaseDir, $HbfieldMode, $HcomDoNothing, $HcomL, $HcommandArg, $HcommandComary, $HcommandKind, $HcommandMax, $HcommandMode, $HcommandPlanNumber, $HcommandTarget, $HcommandTX, $HcommandTY, $HcommandX, $HcommandY, $HcommentLabel0, $HcommentLabel1, $HcommentLabel2, $HcommentLabel3, $HcommentLabel4, $HcssFile, $HcurrentID, $HcurrentName, $HcurrentOwnerName, $Hcustom, $Hdebug, $HdebugMode, $HdefaultKind, $HdefaultName, $HdefaultPassword, $HdefaultTX, $HdefaultTY, $HdefaultX, $HdefaultY, $HdirMode, $helpDir, $HerrorNum, $HexchangeBidID, $HexchangeBuy, $HexchangeBuyCost, $HexchangeCon, $HexchangeDelID, $HexchangeMode, $HexchangeSell, $HexchangeSellCost, $HflexTime, $HflexTimeSet, $HforeignerID, $Hically, $Hicevil, $Hicfood, $HichangeMode, $Hicmoney, $Hicspace, $Hicweapon, $HidToName, $HidToNumber, $HimageDir, $HimgLine, $HinputPassword, $HinputPassword2, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNextID, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HjavaMode, $HjavaModeSet, $HjumpURL, $HlandBase, $HlandDokan, $HlandEarth, $HlandOcean, $HlandOPlayer, $HlandSea, $HlandSpaceBase, $HlastTurn, $HlbbsMax, $HlbbsMessage, $HlbbsMode, $HlbbsMode2, $HlbbsName, $HlbbsType, $HlchangeKIND, $HlchangeMode, $HlchangeVALUE, $Hlinkcheck, $HlistID, $HmainMode, $HmasterPassword, $Hmessage, $Hmonsname, $HmonsterName, $Hmonsurl, $Hmyship, $HmyshipFlg, $Hocean, $HoceanSize, $HokURL, $HoldPassword, $HomeImage, $hour, $hp, $HpasswordFile, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $HpreDeleteID, $HpreDeleteMode, $HpresentFood, $HpresentLog, $HpresentMode, $HpresentMoney, $HprintID, $Hprofile, $HprofileDir, $HpunishID, $HpunishMode, $HretryCount, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $Hrsswrite, $HseaChk, $HskinName, $Hspace, $HspaceID, $Hspacemap, $HspecialPassword, $HtempBack, $HthisFile, $Htitle, $htmlBgColor, $htmlBody, $HtmTime1, $HtmTime2, $HtmTime3, $HtopAxes, $Htournament, $HtournamentmonsId, $hturn, $HugMax, $Hugmode, $HunitTime, $Hurlownermode, $imageDir, $lockMode, $toppage, $versionInfo;

	// 각각 비켜 놓는다
	array_splice($command, $number, 1);

//	HdebugOut("마지막에 자금융통" . (count($command) - 1));
	// 마지막에 자금융통
	$command[(count($command) - 1) + 1] = array(
	'kind' => $HcomDoNothing,
	'target' => 0,
	'x' => 0,
	'y' => 0,
	'arg' => 0,
	'tx' => 0,
	'ty' => 0,
	'flg' => 0 # 일시적인 영역
	);
}

// 커멘드를 뒤에 늦춘다
function slideBack(&$command, $number, $kind = 0, $target = 0, $x = 0, $y = 0, $arg = 0, $tx = 0, $ty = 0, $flg = 0) {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $Halistmode, $Hallyflg, $Hasync, $HbaseDir, $HbfieldMode, $HcomDoNothing, $HcomL, $HcommandArg, $HcommandComary, $HcommandKind, $HcommandMax, $HcommandMode, $HcommandPlanNumber, $HcommandTarget, $HcommandTX, $HcommandTY, $HcommandX, $HcommandY, $HcommentLabel0, $HcommentLabel1, $HcommentLabel2, $HcommentLabel3, $HcommentLabel4, $HcssFile, $HcurrentID, $HcurrentName, $HcurrentOwnerName, $Hcustom, $Hdebug, $HdebugMode, $HdefaultKind, $HdefaultName, $HdefaultPassword, $HdefaultTX, $HdefaultTY, $HdefaultX, $HdefaultY, $HdirMode, $helpDir, $HerrorNum, $HexchangeBidID, $HexchangeBuy, $HexchangeBuyCost, $HexchangeCon, $HexchangeDelID, $HexchangeMode, $HexchangeSell, $HexchangeSellCost, $HflexTime, $HflexTimeSet, $HforeignerID, $Hically, $Hicevil, $Hicfood, $HichangeMode, $Hicmoney, $Hicspace, $Hicweapon, $HidToName, $HidToNumber, $HimageDir, $HimgLine, $HinputPassword, $HinputPassword2, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNextID, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HjavaMode, $HjavaModeSet, $HjumpURL, $HlandBase, $HlandDokan, $HlandEarth, $HlandOcean, $HlandOPlayer, $HlandSea, $HlandSpaceBase, $HlastTurn, $HlbbsMax, $HlbbsMessage, $HlbbsMode, $HlbbsMode2, $HlbbsName, $HlbbsType, $HlchangeKIND, $HlchangeMode, $HlchangeVALUE, $Hlinkcheck, $HlistID, $HmainMode, $HmasterPassword, $Hmessage, $Hmonsname, $HmonsterName, $Hmonsurl, $Hmyship, $HmyshipFlg, $Hocean, $HoceanSize, $HokURL, $HoldPassword, $HomeImage, $hour, $hp, $HpasswordFile, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $HpreDeleteID, $HpreDeleteMode, $HpresentFood, $HpresentLog, $HpresentMode, $HpresentMoney, $HprintID, $Hprofile, $HprofileDir, $HpunishID, $HpunishMode, $HretryCount, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $Hrsswrite, $HseaChk, $HskinName, $Hspace, $HspaceID, $Hspacemap, $HspecialPassword, $HtempBack, $HthisFile, $Htitle, $htmlBgColor, $htmlBody, $HtmTime1, $HtmTime2, $HtmTime3, $HtopAxes, $Htournament, $HtournamentmonsId, $hturn, $HugMax, $Hugmode, $HunitTime, $Hurlownermode, $imageDir, $lockMode, $toppage, $versionInfo;
	if ($tx == '') { $tx = 0; }
	if ($ty == '') { $ty = 0; }
	// 각각 비켜 놓는다
	if ($number == (count($command) - 1)) { return; }
//	array_pop($command);
	array_splice($command, $number, 0, array($command[$number]));
	if (count($command) > $HcommandMax) { array_pop($command); }
	if($kind > 0){
		$command[$number] = array(
		'kind' => $kind,
		'target' => $target,
		'x' => $x,
		'y' => $y,
		'arg' => $arg,
		'tx' => $tx,
		'ty' => $ty,
		'flg' => $flg # 일시적인 영역
		);
	}
}

//----------------------------------------------------------------------
// 도데이터 입출력
//----------------------------------------------------------------------

// 도 전체 데이터 읽어들여
function readIslandsFile($num) {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $Halistmode, $Hallyflg, $Hasync, $HbaseDir, $HbfieldMode, $HcomDoNothing, $HcomL, $HcommandArg, $HcommandComary, $HcommandKind, $HcommandMax, $HcommandMode, $HcommandPlanNumber, $HcommandTarget, $HcommandTX, $HcommandTY, $HcommandX, $HcommandY, $HcommentLabel0, $HcommentLabel1, $HcommentLabel2, $HcommentLabel3, $HcommentLabel4, $HcssFile, $HcurrentID, $HcurrentName, $HcurrentOwnerName, $Hcustom, $Hdebug, $HdebugMode, $HdefaultKind, $HdefaultName, $HdefaultPassword, $HdefaultTX, $HdefaultTY, $HdefaultX, $HdefaultY, $HdirMode, $helpDir, $HerrorNum, $HexchangeBidID, $HexchangeBuy, $HexchangeBuyCost, $HexchangeCon, $HexchangeDelID, $HexchangeMode, $HexchangeSell, $HexchangeSellCost, $HflexTime, $HflexTimeSet, $HforeignerID, $Hically, $Hicevil, $Hicfood, $HichangeMode, $Hicmoney, $Hicspace, $Hicweapon, $HidToName, $HidToNumber, $HimageDir, $HimgLine, $HinputPassword, $HinputPassword2, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNextID, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HjavaMode, $HjavaModeSet, $HjumpURL, $HlandBase, $HlandDokan, $HlandEarth, $HlandOcean, $HlandOPlayer, $HlandSea, $HlandSpaceBase, $HlastTurn, $HlbbsMax, $HlbbsMessage, $HlbbsMode, $HlbbsMode2, $HlbbsName, $HlbbsType, $HlchangeKIND, $HlchangeMode, $HlchangeVALUE, $Hlinkcheck, $HlistID, $HmainMode, $HmasterPassword, $Hmessage, $Hmonsname, $HmonsterName, $Hmonsurl, $Hmyship, $HmyshipFlg, $Hocean, $HoceanSize, $HokURL, $HoldPassword, $HomeImage, $hour, $hp, $HpasswordFile, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $HpreDeleteID, $HpreDeleteMode, $HpresentFood, $HpresentLog, $HpresentMode, $HpresentMoney, $HprintID, $Hprofile, $HprofileDir, $HpunishID, $HpunishMode, $HretryCount, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $Hrsswrite, $HseaChk, $HskinName, $Hspace, $HspaceID, $Hspacemap, $HspecialPassword, $HtempBack, $HthisFile, $Htitle, $htmlBgColor, $htmlBody, $HtmTime1, $HtmTime2, $HtmTime3, $HtopAxes, $Htournament, $HtournamentmonsId, $hturn, $HugMax, $Hugmode, $HunitTime, $Hurlownermode, $imageDir, $lockMode, $toppage, $versionInfo;
					// -1(이)라면 전지형을 읽는다
					// 번호라면 그 도의 지형만은 읽어들인다

	// 데이터 파일을 연다
	if (!hako_open('IN', "{$HdirName}/hakojima.dat")) { return 0; }
	
	// 각 파라미터의 읽어들여
	$HislandTurn     = intval(hako_getline('IN')); # 턴수
	if ($HislandTurn == 0) { return 0; }
	$HislandLastTime = intval(hako_getline('IN')); # 최종 갱신 시간
	if ($HislandLastTime <= 0) { $HislandLastTime = time() - $HunitTime - 1; }
	$HislandNumber   = intval(hako_getline('IN')); # 도의 총수
	// 다음에 할당하는 ID와 관리인 보관 도ID
	$tmp = hako_getline('IN');
	$tmp = rtrim($tmp);
	$preDelete = preg_split("/,/", $tmp);
	$HislandNextID = isset($preDelete[0]) ? $preDelete[0] : 1;
	$HpreDeleteID = array_slice($preDelete, 1);
	if($Htournament){
		// 간이 토너먼트?
		$HflexTimeSet = 1;
		$Hallyflg = 0;
		$Hpossess = 0;
		// 데이터 파일을 연다
		if (!hako_open('TIN', "{$HdirName}/tournament.dat")) { return 0; }
		$HislandFightMode	= intval(hako_getline('TIN'));  # 현재의 전투 모드
		$HislandChangeTurn	= intval(hako_getline('TIN'));  # 변환 턴
		$HislandFightCount	= intval(hako_getline('TIN'));  # 몇회전목인가
		$HislandTurnCount	= intval(hako_getline('TIN'));  # 턴 갱신수
		hako_getline('TIN');
		hako_getline('TIN');
		hako_getline('TIN');
		hako_getline('TIN');
		if($HislandFightMode == 1){
			// 예선
			$HflexTime = $HtmTime1;
		}elseif($HislandFightMode == 2){
			// 개발
			$HflexTime = $HtmTime2;
		}elseif($HislandFightMode == 3){
			// 전투
			$HflexTime = $HtmTime3;
		}
		// flexTime 처리
		if ($HflexTimeSet) { $HunitTime = 3600 * $HflexTime[$HislandTurnCount % ((count($HflexTime) - 1) + 1)]; }
	}else{
		//  flexTime 처리
		if ($HflexTimeSet) { $HunitTime = 3600 * $HflexTime[$HislandTurn % ((count($HflexTime) - 1) + 1)]; }
	}

	// 턴 처리 판정
	$now = time();
	$__autoTurnByTime = (($now - $HislandLastTime) >= $HunitTime);
	if(((($Hdebug == 1) && ($HmainMode == 'Hdebugturn')) ||
		$__autoTurnByTime) &&
		(($HlastTurn == 0)||($HislandTurn < $HlastTurn))) { # 종료 턴
		// 시간 경과로 자동 턴 처리에 들어간 경우, 먼저 현재 화면을 출력할 수 있도록 표시한다.
		if($__autoTurnByTime && ($HmainMode != 'Hdebugturn')) { $GLOBALS['HautoTurnMode'] = 1; }
		$HmainMode = 'turn';
		$num = -1; # 도 전체 읽어들인다
	}

	// 도의 읽어들여
	$i = null;
	for($i = 0; $i < $HislandNumber; $i++) {
		$Hislands[$i] = readIsland($num);
		$HidToNumber[$Hislands[$i]['id']] = $i;
		foreach ($HpreDeleteID as $_) {
			if($Hislands[$i]['id'] == $_) {
				$Hislands[$i]['predelete'] = 1;
			}
		}
		if ($Hislands[$i]['fight_id'] == -1) { $Hislands[$i]['predelete'] = 1; }
	}
	readsubmap(0);#우주 맵 독입
	readsubmap(1);#해역 맵 독입
	readCommandLate(); #턴 차이 명령 데이터 독입
	// 파일을 닫는다
	hako_close('IN');
	if ($Htournament) { hako_close('TIN'); }
	return 1;
}
// 서브 맵 하나 읽어들여
function readsubmap($num) {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $Halistmode, $Hallyflg, $Hasync, $HbaseDir, $HbfieldMode, $HcomDoNothing, $HcomL, $HcommandArg, $HcommandComary, $HcommandKind, $HcommandMax, $HcommandMode, $HcommandPlanNumber, $HcommandTarget, $HcommandTX, $HcommandTY, $HcommandX, $HcommandY, $HcommentLabel0, $HcommentLabel1, $HcommentLabel2, $HcommentLabel3, $HcommentLabel4, $HcssFile, $HcurrentID, $HcurrentName, $HcurrentOwnerName, $Hcustom, $Hdebug, $HdebugMode, $HdefaultKind, $HdefaultName, $HdefaultPassword, $HdefaultTX, $HdefaultTY, $HdefaultX, $HdefaultY, $HdirMode, $helpDir, $HerrorNum, $HexchangeBidID, $HexchangeBuy, $HexchangeBuyCost, $HexchangeCon, $HexchangeDelID, $HexchangeMode, $HexchangeSell, $HexchangeSellCost, $HflexTime, $HflexTimeSet, $HforeignerID, $Hically, $Hicevil, $Hicfood, $HichangeMode, $Hicmoney, $Hicspace, $Hicweapon, $HidToName, $HidToNumber, $HimageDir, $HimgLine, $HinputPassword, $HinputPassword2, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNextID, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HjavaMode, $HjavaModeSet, $HjumpURL, $HlandBase, $HlandDokan, $HlandEarth, $HlandOcean, $HlandOPlayer, $HlandSea, $HlandSpaceBase, $HlastTurn, $HlbbsMax, $HlbbsMessage, $HlbbsMode, $HlbbsMode2, $HlbbsName, $HlbbsType, $HlchangeKIND, $HlchangeMode, $HlchangeVALUE, $Hlinkcheck, $HlistID, $HmainMode, $HmasterPassword, $Hmessage, $Hmonsname, $HmonsterName, $Hmonsurl, $Hmyship, $HmyshipFlg, $Hocean, $HoceanSize, $HokURL, $HoldPassword, $HomeImage, $hour, $hp, $HpasswordFile, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $HpreDeleteID, $HpreDeleteMode, $HpresentFood, $HpresentLog, $HpresentMode, $HpresentMoney, $HprintID, $Hprofile, $HprofileDir, $HpunishID, $HpunishMode, $HretryCount, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $Hrsswrite, $HseaChk, $HskinName, $Hspace, $HspaceID, $Hspacemap, $HspecialPassword, $HtempBack, $HthisFile, $Htitle, $htmlBgColor, $htmlBody, $HtmTime1, $HtmTime2, $HtmTime3, $HtopAxes, $Htournament, $HtournamentmonsId, $hturn, $HugMax, $Hugmode, $HunitTime, $Hurlownermode, $imageDir, $lockMode, $toppage, $versionInfo;
	// 우주, 해역 맵 읽어들여
	if(hako_open('IN', "{$HdirName}/submap.$num")){
		// 지형
		$land = null; $landValue = null; $land2 = null; $landValue2 = null; $nation = null; $line = null; $lbbs = null;
		$x = null; $y = null; $i = null;
		if($num == 0){
			// 우주
			$Hspacemap = 1;
			for($y = 0; $y < $HislandSize; $y++) {
				$line = hako_getline('IN');
				for($x = 0; $x < $HislandSize; $x++) {
					if (preg_match('/^(..)(....)(..)(....)(..)/', $line, $_m)) {
						$line = substr($line, 14);
						$land[$x][$y] = hexdec($_m[1]);
						$landValue[$x][$y] = hexdec($_m[2]);
						$land2[$x][$y] = hexdec($_m[3]);
						$landValue2[$x][$y] = hexdec($_m[4]);
						$nation[$x][$y] = hexdec($_m[5]);
					}
				}
			}
		}else{
			// 해역
			for($y = 0; $y < $HoceanSize; $y++) {
				$line = hako_getline('IN');
				for($x = 0; $x < $HoceanSize; $x++) {
					if (preg_match('/^(..)(....)(..)(....)(..)/', $line, $_m)) {
						$line = substr($line, 14);
						$land[$x][$y] = hexdec($_m[1]);
						$landValue[$x][$y] = hexdec($_m[2]);
						$land2[$x][$y] = hexdec($_m[3]);
						$landValue2[$x][$y] = hexdec($_m[4]);
						$nation[$x][$y] = hexdec($_m[5]);
					}
				}
			}
		}
		$spaces = hako_getline('IN');# 우주 자산 상위 5위
		$spaces = rtrim($spaces);
		$solarwind= intval(hako_getline('IN')); # 태양풍 턴
		$area	= intval(hako_getline('IN')); # 개발 면적
		$pop		= intval(hako_getline('IN')); # 우주인구
		$farm	= intval(hako_getline('IN')); # 우주 농장
		$factory	= intval(hako_getline('IN')); # 우주 공장
		$food	= hako_getline('IN'); # 우주 식량
		$foods	= array_pad(preg_split("/,/", $food), 3, 0);
//		HdebugOut("{$foods[0]},{$foods[1]},{$foods[2]}");
		hako_getline('IN');# 확장용
		hako_getline('IN');# 확장용
		hako_getline('IN');# 확장용
		hako_getline('IN');# 확장용
		hako_getline('IN');# 확장용
		// 로컬 게시판
		for($i = 0; $i < $HlbbsMax; $i++) {
			$line = hako_getline('IN');
			$line = rtrim($line);
			$lbbs[$i] = $line;
		}
		if($num == 0){
			//우주
			$Hspace = array(
			 'land' => $land,
			 'landValue' => $landValue,
			 'land2' => $land2,
			 'landValue2' => $landValue2,
			 'nation' => $nation,
			 'solarwind' => $solarwind,
			 'space' => $spaces,
			 'area' => $area,
			 'pop' => $pop,
			 'farm' => $farm,
			 'factory' => $factory,
			 'food' => intval($foods[0]),
			 'foodP' => intval($foods[1]),
			 'foodC' => intval($foods[2]),
			 'lbbs' => $lbbs
			);
		}else{
			//해역
			$Hocean = array(
			 'land' => $land,
			 'landValue' => $landValue,
			 'land2' => $land2,
			 'landValue2' => $landValue2,
			 'nation' => $nation,
			 'solarwind' => $solarwind,
			 'space' => $spaces,
			 'area' => $area,
			 'pop' => $pop,
			 'farm' => $farm,
			 'factory' => $factory,
			 'food' => intval($foods[0]),
			 'foodP' => intval($foods[1]),
			 'foodC' => intval($foods[2]),
			 'lbbs' => $lbbs
			);
		}
		hako_close('IN');
	} else {
		// PHP 8.x: 초기 데이터에서 submap.0이 아직 없거나 손상된 경우에도 턴 처리가 중단되지 않도록 기본 서브맵을 구성한다.
		$size = ($num == 0) ? $HislandSize : $HoceanSize;
		$land = array(); $landValue = array(); $land2 = array(); $landValue2 = array(); $nation = array(); $lbbs = array();
		for($y = 0; $y < $size; $y++) {
			for($x = 0; $x < $size; $x++) {
				$land[$x][$y] = $HlandSea;
				$landValue[$x][$y] = 0;
				$land2[$x][$y] = 0;
				$landValue2[$x][$y] = 0;
				$nation[$x][$y] = 0;
			}
		}
		if($num == 0) { $land[intval($HislandSize / 2 - 1)][intval($HislandSize / 2 - 1)] = $HlandEarth; $Hspacemap = 0; }
		for($i = 0; $i < $HlbbsMax; $i++) { $lbbs[$i] = "0<<0>>"; }
		$tmpMap = array(
			'land' => $land, 'landValue' => $landValue, 'land2' => $land2, 'landValue2' => $landValue2, 'nation' => $nation,
			'solarwind' => 0, 'space' => '0', 'area' => 0, 'pop' => 0, 'farm' => 0, 'factory' => 0,
			'food' => 0, 'foodP' => 0, 'foodC' => 0, 'lbbs' => $lbbs
		);
		if($num == 0) { $Hspace = $tmpMap; } else { $Hocean = $tmpMap; }
	}
}

// 도하나 읽어들여
function readIsland($num) {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $Halistmode, $Hallyflg, $Hasync, $HbaseDir, $HbfieldMode, $HcomDoNothing, $HcomL, $HcommandArg, $HcommandComary, $HcommandKind, $HcommandMax, $HcommandMode, $HcommandPlanNumber, $HcommandTarget, $HcommandTX, $HcommandTY, $HcommandX, $HcommandY, $HcommentLabel0, $HcommentLabel1, $HcommentLabel2, $HcommentLabel3, $HcommentLabel4, $HcssFile, $HcurrentID, $HcurrentName, $HcurrentOwnerName, $Hcustom, $Hdebug, $HdebugMode, $HdefaultKind, $HdefaultName, $HdefaultPassword, $HdefaultTX, $HdefaultTY, $HdefaultX, $HdefaultY, $HdirMode, $helpDir, $HerrorNum, $HexchangeBidID, $HexchangeBuy, $HexchangeBuyCost, $HexchangeCon, $HexchangeDelID, $HexchangeMode, $HexchangeSell, $HexchangeSellCost, $HflexTime, $HflexTimeSet, $HforeignerID, $Hically, $Hicevil, $Hicfood, $HichangeMode, $Hicmoney, $Hicspace, $Hicweapon, $HidToName, $HidToNumber, $HimageDir, $HimgLine, $HinputPassword, $HinputPassword2, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNextID, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HjavaMode, $HjavaModeSet, $HjumpURL, $HlandBase, $HlandDokan, $HlandEarth, $HlandOcean, $HlandOPlayer, $HlandSea, $HlandSpaceBase, $HlastTurn, $HlbbsMax, $HlbbsMessage, $HlbbsMode, $HlbbsMode2, $HlbbsName, $HlbbsType, $HlchangeKIND, $HlchangeMode, $HlchangeVALUE, $Hlinkcheck, $HlistID, $HmainMode, $HmasterPassword, $Hmessage, $Hmonsname, $HmonsterName, $Hmonsurl, $Hmyship, $HmyshipFlg, $Hocean, $HoceanSize, $HokURL, $HoldPassword, $HomeImage, $hour, $hp, $HpasswordFile, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $HpreDeleteID, $HpreDeleteMode, $HpresentFood, $HpresentLog, $HpresentMode, $HpresentMoney, $HprintID, $Hprofile, $HprofileDir, $HpunishID, $HpunishMode, $HretryCount, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $Hrsswrite, $HseaChk, $HskinName, $Hspace, $HspaceID, $Hspacemap, $HspecialPassword, $HtempBack, $HthisFile, $Htitle, $htmlBgColor, $htmlBody, $HtmTime1, $HtmTime2, $HtmTime3, $HtopAxes, $Htournament, $HtournamentmonsId, $hturn, $HugMax, $Hugmode, $HunitTime, $Hurlownermode, $imageDir, $lockMode, $toppage, $versionInfo;
	$name = null; $id = null; $ownername = null; $prize = null; $absent = null; $comment = null; $password = null; $money = null; $food = null; $pop = null; $area = null; $farm = null; $weather = null; $factory = null; $port = null; $mountain = null; $tower = null; $yousyoku = null; $turnsu = null; $ally = null; $MissileK = null; $MissileA = null; $present = null; $allex = null; $status = null; $evil = null; $order = null; $mons1 = null; $monsurl = null; $score = null; $xy = null; $ore = null; $weapon = null; $oil = null; $oilfield = null; $monsfound = null; $cmdTurn = null; $cmdIp = null; $cmdId = null; $cmdtime = null;
	$name = hako_getline('IN'); # 도의 이름
	$name = rtrim($name);
	if (preg_match('/^(.*),(.*)$/', $name, $_m)) {
		$name = $_m[1];
		$score = intval($_m[2]);
	} else {
		$score = 0;
	}
	$id = intval(hako_getline('IN'));       # ID번호
	$ownername= hako_getline('IN');      # 사용자명
	$ownername = rtrim($ownername);
	$prize = hako_getline('IN');         # 수상
	$prize = rtrim($prize);
	$absent = intval(hako_getline('IN'));   # 연속 자금융통수
	$comment = hako_getline('IN');       # 코멘트
	$comment = rtrim($comment);
	$comments = preg_split("/<>/", $comment);
	$password = hako_getline('IN');      # 암호화 패스워드
	$password = rtrim($password);
	$money = intval(hako_getline('IN'));    # 자금
	$food = intval(hako_getline('IN'));     # 식량
	$pop = hako_getline('IN'); # 인구
	$pops = preg_split("/,/", $pop);
	$area = intval(hako_getline('IN'));     # 넓이
	$farm = intval(hako_getline('IN'));     # 농장
	$weather = hako_getline('IN');  # 기후
	$neww = null; $pastw = null;
	$w = 0;
	if (preg_match('/^([0-9]*),(.*)$/', $weather, $_m)) {
		$neww = intval($_m[1]);
		$weather = $_m[2];
	}
	for($w = 0; $w < 10; $w++) {
		if (preg_match('/^([0-9]*),(.*)$/', $weather, $_m)) {
			$pastw[$w] = intval($_m[1]);
			$weather = $_m[2];
		} else {
			$pastw[$w] = 0;
		}
	}
	if (preg_match('/^([0-9]*)$/', trim($weather), $_m)) {
		$pastw[$w] = intval($_m[1]);
	} else {
		$pastw[$w] = 0;
	}
	$factory = intval(hako_getline('IN'));  # 공장
	$port     = intval(hako_getline('IN')); # 항구
	$mountain = intval(hako_getline('IN')); # 채굴장
	$tower    = intval(hako_getline('IN')); # 상업지
	$yousyoku = intval(hako_getline('IN')); # 양식장
	$turnsu   = hako_getline('IN'); # 이월을 제외한 그 도의 턴수, 순위점, 개시 턴
	$hturn = preg_split("/,/", $turnsu);
	$winp  = hako_getline('IN'); # 승리, 패배 포인트, 승리 수
	$win   = preg_split("/,/", $winp);
	$MissileK = hako_getline('IN'); # 미사일 발사 가능수, 발사 미사일 총수
	$ally     = intval(hako_getline('IN')); # 소속 ID
	$present  = hako_getline('IN');      # 선물
	$allex    = intval(hako_getline('IN')); # 경험 획득수
	$status   = intval(hako_getline('IN')); # 부문상
	$evil     = intval(hako_getline('IN')); # 
	$monsfound= intval(hako_getline('IN')); # 현재 출현하고 있는 괴수의 수
	$order    = intval(hako_getline('IN')); # 명령
	$xy       = hako_getline('IN'); # 좌표
	$ore      = intval(hako_getline('IN')); # 광석
	$weapon   = intval(hako_getline('IN')); # 병기
	$oil      = intval(hako_getline('IN')); # 원유
	$oilfield = intval(hako_getline('IN')); # 유전 생산량
	$Missile = preg_split("/,/", $MissileK);
	$coordinate = preg_split("/,/", $xy);
	
	$prese = array_pad(array_map('intval', preg_split('/,/', trim($present))), 14, 0);
	// 괴수 배틀용
	$mons1    = hako_getline('IN'); # 자신의 괴수
	$monsurl  = hako_getline('IN'); # 괴수 URL
	$monsurl = rtrim($monsurl);
	$monster = preg_split("/,/", $mons1);

	// HidToName 테이블에 보존
	$HidToName[$id] = $name;

	// 지형
	$land = null; $landValue = null; $land2 = null; $landValue2 = null; $nation = null; $line = null; $command = null; $lbbs = null;
	$ugL = null; $ugV = null; $ugX = null; $ugY = null;# 지하
	if(($num == -1) || ($num == $id)) {
		if (!hako_open('IIN', "{$HdirName}/island.$id")) { exit(0); }
		$x = null; $y = null; $i = null;
		for($y = 0; $y < $HislandSize; $y++) {
			$line = hako_getline('IIN');
			for($x = 0; $x < $HislandSize; $x++) {
				if (preg_match('/^(..)(....)(..)(....)(..)/', $line, $_m)) {
					$line = substr($line, 14);
					$land[$x][$y] = hexdec($_m[1]);
					$landValue[$x][$y] = hexdec($_m[2]);
					$land2[$x][$y] = hexdec($_m[3]);
					$landValue2[$x][$y] = hexdec($_m[4]);
					$nation[$x][$y] = hexdec($_m[5]);
				}
			}
		}
		// 지하
		for($i = 0; $i < $HugMax; $i++) {
			$line = hako_getline('IIN');
			for($x = 0; $x < 9; $x++) {
				if (preg_match('/^(.)(..)/', $line, $_m)) {
					$line = substr($line, 3);
					$ugL[$i][$x] = hexdec($_m[1]);
					$ugV[$i][$x] = hexdec($_m[2]);
				}
			}
			preg_match('/^,([0-9]*),([0-9]*)/', trim($line), $_m);
			$ugX[$i] = isset($_m[1]) ? $_m[1] : '';
			$ugY[$i] = isset($_m[2]) ? $_m[2] : '';
		}
		$cmdTurn	= intval(hako_getline('IIN')); # 턴
		$cmdIp		= hako_getline('IIN');# IP
		$cmdIp = rtrim($cmdIp);
		$cmdId		= intval(hako_getline('IIN'));# 쿠키 ID
		$cmdtime	= intval(hako_getline('IIN'));# 입력 시간
		hako_getline('IIN');# 확장용
		// 커멘드?
		for($i = 0; $i < $HcommandMax; $i++) {
			$line = hako_getline('IIN');
			$cmds = array_pad(array_map('intval', preg_split('/,/', trim($line))), 7, 0);
			$command[$i] = array(
			'kind' => $cmds[0],
			'target' => $cmds[1],
			'x' => $cmds[2],
			'y' => $cmds[3],
			'arg' => $cmds[4],
			'tx' => $cmds[5],
			'ty' => $cmds[6]
			);
		}

		// 로컬 게시판
		for($i = 0; $i < $HlbbsMax; $i++) {
			$line = hako_getline('IIN');
			$line = rtrim($line);
			$lbbs[$i] = $line;
		}

		hako_close('IIN');
	}

	$fight_id = null;
	if($Htournament){
		// 간이 토너먼트
		$fight_id = intval(hako_getline('TIN'));	# 대전 상대 ID
		hako_getline('TIN');
		hako_getline('TIN');
		hako_getline('TIN');
		hako_getline('TIN');
	}

	// 도형으로 해 돌려준다
	return array(
	 'name' => $name,
	 'ownername' => $ownername, # 사용자명 표시를 위해 추가
	 'id' => $id,
	 'score' => $score,
	 'prize' => $prize,
	 'absent' => $absent,
	 'comment' => $comments[0],
	 'commentLabel0' => $comments[1],
	 'commentLabel1' => $comments[2],
	 'commentLabel2' => $comments[3],
	 'commentLabel3' => $comments[4],
	 'commentLabel4' => $comments[5],
	 'password' => $password,
	 'money' => $money,
	 'food' => $food,
	 'pop' => intval($pops[0]),
	 'popspace' => intval($pops[1]),
	 'spa' => intval($pops[2]),
	 'area' => $area,
	 'farm' => $farm,
	 'weather' => $neww,
	 'pastweather' => $pastw,
	 'factory' => $factory,
	 'port' => $port,
	 'mountain' => $mountain,
	 'tower' => $tower,
	 'yousyoku' => $yousyoku,
	 'turnsu' => intval($hturn[0]),
	 'zyuni' => intval($hturn[1]),
	 'winP' => intval($win[0]),
	 'loseP' => intval($win[1]),
	 'winS' => intval($win[2]),
	 'possess' => intval($win[3]),
	 'ally' => $ally,
	 'MissileK' => intval($Missile[0]),
	 'MissileA' => intval($Missile[1]),
	 'present' => $prese,
	 'allex' => $allex,
	 'status' => $status,
	 'evil' => $evil,
	 'kaisi' => intval($hturn[2]),
	 'order' => $order,
	 'x' => intval($coordinate[0]),
	 'y' => intval($coordinate[1]),
	 'ore' => $ore,
	 'weapon' => $weapon,
	 'oil' => $oil,
	 'oilfield' => $oilfield,
	 'land' => $land,
	 'landValue' => $landValue,
	 'land2' => $land2,
	 'landValue2' => $landValue2,
	 'nation' => $nation,
	 'ugL' => $ugL,
	 'ugV' => $ugV,
	 'ugX' => $ugX,
	 'ugY' => $ugY,
	 'fight_id' => $fight_id,
	 'command' => $command,
	 'lbbs' => $lbbs,
	 'monsurl' => $monsurl,
	 'monster' => $monster,
	 'monsfound' => $monsfound,
	 'cmdTurn' => $cmdTurn,
	 'cmdIp' => $cmdIp,
	 'cmdId' => $cmdId,
	 'cmdtime' => $cmdtime,
		 'achive' => 0,
		 'eis0' => 0,
		 'eis1' => 0,
		 'eis2' => 0,
		 'event' => 0,
		 'event2' => 0,
		 'propaganda' => 0,
		 'Kouzui' => 0,
		 'Hideri' => 0,
		 'Crime' => 0,
		 'towerD' => 0,
		 'Pollution' => 0,
		 'gold' => 0,
		 'Rain' => 0,
		 'SSSystem' => 0,
		 'prepare2' => 0,
		 'tunami' => 0,
		 'monstersend' => 0,
		 'monstersend1' => 0,
		 'monstersend2' => 0,
		 'monstersend3' => 0,
		 'TeruteruMons' => 0,
		 'monsEnsei' => 0,
		 'piratesend' => 0,
		 'ghost' => 0,
		 'wingdragon' => 0,
		 'icefloe' => 0,
		 'couplerock' => 0,
		 'bigmissile' => 0,
		 'colony' => 0,
		 'Meteo' => 0,
		 'AEruption' => 0,
		 'GoldMonument' => 0,
		 'esa' => 0,
	);
}

// 도 전체 데이터 기입
function writeIslandsFile($num, $mode) {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $Halistmode, $Hallyflg, $Hasync, $HbaseDir, $HbfieldMode, $HcomDoNothing, $HcomL, $HcommandArg, $HcommandComary, $HcommandKind, $HcommandMax, $HcommandMode, $HcommandPlanNumber, $HcommandTarget, $HcommandTX, $HcommandTY, $HcommandX, $HcommandY, $HcommentLabel0, $HcommentLabel1, $HcommentLabel2, $HcommentLabel3, $HcommentLabel4, $HcssFile, $HcurrentID, $HcurrentName, $HcurrentOwnerName, $Hcustom, $Hdebug, $HdebugMode, $HdefaultKind, $HdefaultName, $HdefaultPassword, $HdefaultTX, $HdefaultTY, $HdefaultX, $HdefaultY, $HdirMode, $helpDir, $HerrorNum, $HexchangeBidID, $HexchangeBuy, $HexchangeBuyCost, $HexchangeCon, $HexchangeDelID, $HexchangeMode, $HexchangeSell, $HexchangeSellCost, $HflexTime, $HflexTimeSet, $HforeignerID, $Hically, $Hicevil, $Hicfood, $HichangeMode, $Hicmoney, $Hicspace, $Hicweapon, $HidToName, $HidToNumber, $HimageDir, $HimgLine, $HinputPassword, $HinputPassword2, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNextID, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HjavaMode, $HjavaModeSet, $HjumpURL, $HlandBase, $HlandDokan, $HlandEarth, $HlandOcean, $HlandOPlayer, $HlandSea, $HlandSpaceBase, $HlastTurn, $HlbbsMax, $HlbbsMessage, $HlbbsMode, $HlbbsMode2, $HlbbsName, $HlbbsType, $HlchangeKIND, $HlchangeMode, $HlchangeVALUE, $Hlinkcheck, $HlistID, $HmainMode, $HmasterPassword, $Hmessage, $Hmonsname, $HmonsterName, $Hmonsurl, $Hmyship, $HmyshipFlg, $Hocean, $HoceanSize, $HokURL, $HoldPassword, $HomeImage, $hour, $hp, $HpasswordFile, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $HpreDeleteID, $HpreDeleteMode, $HpresentFood, $HpresentLog, $HpresentMode, $HpresentMoney, $HprintID, $Hprofile, $HprofileDir, $HpunishID, $HpunishMode, $HretryCount, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $Hrsswrite, $HseaChk, $HskinName, $Hspace, $HspaceID, $Hspacemap, $HspecialPassword, $HtempBack, $HthisFile, $Htitle, $htmlBgColor, $htmlBody, $HtmTime1, $HtmTime2, $HtmTime3, $HtopAxes, $Htournament, $HtournamentmonsId, $hturn, $HugMax, $Hugmode, $HunitTime, $Hurlownermode, $imageDir, $lockMode, $toppage, $versionInfo;

	if (!(file_exists("{$HtempdirName}"))) { mkdir($HtempdirName, $HdirMode); }
	if(file_exists("deldata")) { rmtree("deldata"); }

	if(($mode == 0)||($mode == 1)) {
		// 파일을 연다
		$retry = $HretryCount;
		while(!hako_open('OUT', ">{$HtempdirName}/hakojima.tmp")) {
			$retry--;
			if($retry <= 0) {
				$HerrorNum = '100';
				return 0;
			}
			// 0.2 초 sleep
			usleep(200000);
		}

		//  각 파라미터 기입
		hako_write('OUT', "$HislandTurn\n");
		hako_write('OUT', "$HislandLastTime\n");
		hako_write('OUT', "$HislandNumber\n");
		hako_write('OUT', "$HislandNextID," . implode(', ', $HpreDeleteID) . "\n");
		
		if($Htournament){
			// 파일을 연다
			$retry = $HretryCount;
			while(!hako_open('TOUT', ">{$HtempdirName}/tournament.tmp")) {
				$retry--;
				if($retry <= 0) {
					$HerrorNum = '100';
					return 0;
				}
				// 0.2 초 sleep
				usleep(200000);
			}
			hako_write('TOUT', "$HislandFightMode\n");
			hako_write('TOUT', "$HislandChangeTurn\n");
			hako_write('TOUT', "$HislandFightCount\n");
			hako_write('TOUT', "$HislandTurnCount\n");
			hako_write('TOUT', "\n");
			hako_write('TOUT', "\n");
			hako_write('TOUT', "\n");
			hako_write('TOUT', "\n");
			
		}
	}
	// 도의 글
	$i = null;
	$flag = 1;
	for($i = 0; $i < $HislandNumber; $i++) {
		if(!writeIsland($Hislands[$i], $num, 0)) {
			$flag = 0;
break;
		}
	}

	// 우주 맵의 글
	if($flag) {
		// PHP 8.x: 최초 섬 생성 시 submap.0이 아직 없으면 전체 배열을 먼저 만든다.
		if (!isset($Hspace) || !is_array($Hspace)) { $Hspace = array(); }
		if (!isset($Hspace['land']) || !is_array($Hspace['land'])) {
			$Hspace['land'] = array();
			$Hspace['landValue'] = array();
			$Hspace['land2'] = array();
			$Hspace['landValue2'] = array();
			$Hspace['nation'] = array();
			for($sy = 0; $sy < $HislandSize; $sy++) {
				for($sx = 0; $sx < $HislandSize; $sx++) {
					$Hspace['land'][$sx][$sy] = $HlandSea;
					$Hspace['landValue'][$sx][$sy] = 0;
					$Hspace['land2'][$sx][$sy] = 0;
					$Hspace['landValue2'][$sx][$sy] = 0;
					$Hspace['nation'][$sx][$sy] = 0;
				}
			}
		}
		$Hspace['space'] = isset($Hspace['space']) ? $Hspace['space'] : '0';
		$Hspace['solarwind'] = isset($Hspace['solarwind']) ? $Hspace['solarwind'] : 0;
		$Hspace['area'] = isset($Hspace['area']) ? $Hspace['area'] : 0;
		$Hspace['pop'] = isset($Hspace['pop']) ? $Hspace['pop'] : 0;
		$Hspace['farm'] = isset($Hspace['farm']) ? $Hspace['farm'] : 0;
		$Hspace['factory'] = isset($Hspace['factory']) ? $Hspace['factory'] : 0;
		$Hspace['food'] = isset($Hspace['food']) ? $Hspace['food'] : 0;
		$Hspace['foodP'] = isset($Hspace['foodP']) ? $Hspace['foodP'] : 0;
		$Hspace['foodC'] = isset($Hspace['foodC']) ? $Hspace['foodC'] : 0;
		$c = intval($HislandSize / 2 - 1);
//       HdebugOut("우주 맵의 작성 $num 모드 $mode 초기화 $Hspacemap 지구 $c");	
		$Hspace['land'][$c][$c] = $HlandEarth;
		if($Hspacemap != 1){
			// 우주 맵 초기화
			$Hspace['solarwind'] = $HislandTurn + random(30) + 30;
			// 초기 게시판을 작성
			$lbbs = null;
			for($i = 0; $i < $HlbbsMax; $i++) {
				$lbbs[$i] = "0<<0>>";
			}
			$Hspace['lbbs'] = $lbbs;
		}
		if (!isset($Hspace['lbbs']) || !is_array($Hspace['lbbs'])) {
			$lbbs = array();
			for($i = 0; $i < $HlbbsMax; $i++) { $lbbs[$i] = "0<<0>>"; }
			$Hspace['lbbs'] = $lbbs;
		}
		if (!writeIsland($Hspace, 0, 3)) { $flag = 0; }
	}

	// 해역 맵의 글
	if($flag) {
		if (!writeIsland($Hocean, 0, 4)) { $flag = 0; }
	}

	// 턴 차이 명령 데이터 기입
	if(!is_array($HcomL)) { $HcomL = array(); }
	hako_open('COUT', ">{$HtempdirName}/command.tmp");
	for($i = (count($HcomL) - 1); $i >= 0; $i--){
		if ($HcomL[$i]['turn'] <= $HislandTurn) { continue; }
		hako_write('COUT', sprintf("%d,%d,%d,%d,%d,%d,%d,%d,%d,%d\n",
			$HcomL[$i]['turn'],
			$HcomL[$i]['turn2'],
			$HcomL[$i]['id'],
			$HcomL[$i]['kind'],
			$HcomL[$i]['target'],
			$HcomL[$i]['x'],
			$HcomL[$i]['y'],
			$HcomL[$i]['arg'],
			$HcomL[$i]['x2'],
			$HcomL[$i]['y2']
		));
	}
	hako_close('COUT');

	// 파일을 닫는다
	if(($mode == 0)||($mode == 1)){
		hako_close('OUT');
		if ($Htournament) { hako_close('TOUT'); }
	}

	if(!$flag) {
		if(file_exists("{$HtempdirName}/hakojima.tmp")) { unlink("{$HtempdirName}/hakojima.tmp"); }
		$HerrorNum = '200';
		return 0;
	}
	
	
	if($Htournament){
		rename("{$HdirName}/fight.log","{$HtempdirName}/fight.tmp");
	}

	// 본래의 이름으로 한다
	if($num <= -1) {
		if(!((file_exists("{$HtempdirName}/hakojima.tmp") && filesize("{$HtempdirName}/hakojima.tmp") > 0))) { $HerrorNum = '111'; return 0; }
		if(!rename("{$HtempdirName}/hakojima.tmp", "{$HtempdirName}/hakojima.dat")) { $HerrorNum = '121'; return 0; }
		for($i = 0; $i < $HislandNumber; $i++) {
			if(!((file_exists("{$HtempdirName}/islandtmp." . $Hislands[$i]['id']) && filesize("{$HtempdirName}/islandtmp." . $Hislands[$i]['id']) > 0))) { $HerrorNum = '211'; return 0; }
			if(!rename("{$HtempdirName}/islandtmp." . $Hislands[$i]['id'], "{$HtempdirName}/island." . $Hislands[$i]['id'])) {
				$HerrorNum = '221';
				return 0;
			}
		}
		if(!((file_exists("{$HtempdirName}/submaptmp.0") && filesize("{$HtempdirName}/submaptmp.0") > 0))) { $HerrorNum = '511'; return 0; }
		if(!rename("{$HtempdirName}/submaptmp.0", "{$HtempdirName}/submap.0")) { $HerrorNum = '521'; return 0; }
		if(!((file_exists("{$HtempdirName}/submaptmp.1") && filesize("{$HtempdirName}/submaptmp.1") > 0))) { $HerrorNum = '611'; return 0; }
		if(!rename("{$HtempdirName}/submaptmp.1", "{$HtempdirName}/submap.1")) { $HerrorNum = '621'; return 0; }
		if((file_exists("{$HtempdirName}/command.tmp") && filesize("{$HtempdirName}/command.tmp") > 0)) {
			if(!rename("{$HtempdirName}/command.tmp", "{$HtempdirName}/command.dat")) { $HerrorNum = '721'; return 0; }
		}
		if($Htournament){
			if((file_exists("{$HtempdirName}/tournament.tmp") && filesize("{$HtempdirName}/tournament.tmp") > 0)) {
				if(!rename("{$HtempdirName}/tournament.tmp", "{$HtempdirName}/tournament.dat")) { $HerrorNum = '821'; return 0; }
			}
			if((file_exists("{$HtempdirName}/fight.tmp") && filesize("{$HtempdirName}/fight.tmp") > 0)) {
				if(!rename("{$HtempdirName}/fight.tmp", "{$HtempdirName}/fight.log")) { $HerrorNum = '921'; return 0; }
			}
		}
//		if($Hrsswrite){
//			rename("${HdirName}/rss.dat", "${HtempdirName}/rss.dat");
//		}
		
		if(!rename("{$HdirName}", "deldata")) { $HerrorNum = '321'; return 0; }
		if(!rename("{$HtempdirName}", "{$HdirName}")) {
			rename("deldata", "{$HdirName}");
			$HerrorNum = '421';
			return 0;
		}
		rmtree("deldata");
		return 1;
	}

	if(($mode == 0)||($mode == 1)) {
		if(!((file_exists("{$HtempdirName}/hakojima.tmp") && filesize("{$HtempdirName}/hakojima.tmp") > 0))) { $HerrorNum = '112'; return 0; }
		if(!rename("{$HtempdirName}/hakojima.tmp", "{$HdirName}/hakojima.dat")) { $HerrorNum = '122'; return 0; }
	}

	if(($mode == 0)||($mode == 2)) {
		for($i = 0; $i < $HislandNumber; $i++) {
			if (file_exists("{$HtempdirName}/islandtmp." . $Hislands[$i]['id'])) {
				if(!((file_exists("{$HtempdirName}/islandtmp." . $Hislands[$i]['id']) && filesize("{$HtempdirName}/islandtmp." . $Hislands[$i]['id']) > 0))) { $HerrorNum = '212'; return 0; }
				if(!rename("{$HtempdirName}/islandtmp." . $Hislands[$i]['id'], "{$HdirName}/island." . $Hislands[$i]['id'])) {
					$HerrorNum = '222';
					return 0;
				}
			}
		}
	}
	
	if(($mode == 0)||($mode == 3)) {
		if(!((file_exists("{$HtempdirName}/submaptmp.0") && filesize("{$HtempdirName}/submaptmp.0") > 0))) { $HerrorNum = '512'; return 0; }
		if(!rename("{$HtempdirName}/submaptmp.0", "{$HdirName}/submap.0")) { $HerrorNum = '522'; return 0; }
	}
	if(($mode == 0)||($mode == 4)) {
		if(!((file_exists("{$HtempdirName}/submaptmp.1") && filesize("{$HtempdirName}/submaptmp.1") > 0))) { $HerrorNum = '612'; return 0; }
		if(!rename("{$HtempdirName}/submaptmp.1", "{$HdirName}/submap.1")) { $HerrorNum = '622'; return 0; }
	}
	if(($mode == 0)||($mode == 4)) {
		if((file_exists("{$HtempdirName}/command.tmp") && filesize("{$HtempdirName}/command.tmp") > 0)) {
			if(!rename("{$HtempdirName}/command.tmp", "{$HdirName}/command.dat")) { $HerrorNum = '722'; return 0; }
		}
	}
	if($Htournament){
		if((file_exists("{$HtempdirName}/tournament.tmp") && filesize("{$HtempdirName}/tournament.tmp") > 0)) {
			if(!rename("{$HtempdirName}/tournament.tmp", "{$HdirName}/tournament.dat")) { $HerrorNum = '822'; return 0; }
		}
		if((file_exists("{$HtempdirName}/fight.tmp") && filesize("{$HtempdirName}/fight.tmp") > 0)) {
			if(!rename("{$HtempdirName}/fight.tmp", "{$HdirName}/fight.log")) { $HerrorNum = '922'; return 0; }
		}
	}
//	if(($mode == 0) && ($Hrsswrite)){
//		if(!((file_exists("${HtempdirName}/rss.tmp") && filesize("${HtempdirName}/rss.tmp") > 0))) { $HerrorNum = '612'; return 0; }
//		if(!rename("${HtempdirName}/rss.tmp", "${HdirName}/rss.dat")) { $HerrorNum = '622'; return 0; }
//	}
	
	return 1;

}

// 도하나 기입
function writeIsland($island, $num, $mode) {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $Halistmode, $Hallyflg, $Hasync, $HbaseDir, $HbfieldMode, $HcomDoNothing, $HcomL, $HcommandArg, $HcommandComary, $HcommandKind, $HcommandMax, $HcommandMode, $HcommandPlanNumber, $HcommandTarget, $HcommandTX, $HcommandTY, $HcommandX, $HcommandY, $HcommentLabel0, $HcommentLabel1, $HcommentLabel2, $HcommentLabel3, $HcommentLabel4, $HcssFile, $HcurrentID, $HcurrentName, $HcurrentOwnerName, $Hcustom, $Hdebug, $HdebugMode, $HdefaultKind, $HdefaultName, $HdefaultPassword, $HdefaultTX, $HdefaultTY, $HdefaultX, $HdefaultY, $HdirMode, $helpDir, $HerrorNum, $HexchangeBidID, $HexchangeBuy, $HexchangeBuyCost, $HexchangeCon, $HexchangeDelID, $HexchangeMode, $HexchangeSell, $HexchangeSellCost, $HflexTime, $HflexTimeSet, $HforeignerID, $Hically, $Hicevil, $Hicfood, $HichangeMode, $Hicmoney, $Hicspace, $Hicweapon, $HidToName, $HidToNumber, $HimageDir, $HimgLine, $HinputPassword, $HinputPassword2, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNextID, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HjavaMode, $HjavaModeSet, $HjumpURL, $HlandBase, $HlandDokan, $HlandEarth, $HlandOcean, $HlandOPlayer, $HlandSea, $HlandSpaceBase, $HlastTurn, $HlbbsMax, $HlbbsMessage, $HlbbsMode, $HlbbsMode2, $HlbbsName, $HlbbsType, $HlchangeKIND, $HlchangeMode, $HlchangeVALUE, $Hlinkcheck, $HlistID, $HmainMode, $HmasterPassword, $Hmessage, $Hmonsname, $HmonsterName, $Hmonsurl, $Hmyship, $HmyshipFlg, $Hocean, $HoceanSize, $HokURL, $HoldPassword, $HomeImage, $hour, $hp, $HpasswordFile, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $HpreDeleteID, $HpreDeleteMode, $HpresentFood, $HpresentLog, $HpresentMode, $HpresentMoney, $HprintID, $Hprofile, $HprofileDir, $HpunishID, $HpunishMode, $HretryCount, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $Hrsswrite, $HseaChk, $HskinName, $Hspace, $HspaceID, $Hspacemap, $HspecialPassword, $HtempBack, $HthisFile, $Htitle, $htmlBgColor, $htmlBody, $HtmTime1, $HtmTime2, $HtmTime3, $HtopAxes, $Htournament, $HtournamentmonsId, $hturn, $HugMax, $Hugmode, $HunitTime, $Hurlownermode, $imageDir, $lockMode, $toppage, $versionInfo;
	if($mode == 0){
	$score = null;
	$score = intval($island['score']);
	hako_write('OUT', $island['name'] . "," . $score . "\n");
	hako_write('OUT', $island['id'] . "\n");
	hako_write('OUT', $island['ownername'] . "\n");
	hako_write('OUT', $island['prize'] . "\n");
	hako_write('OUT', $island['absent'] . "\n");
	$comments = $island['comment'] . '<>' . $island['commentLabel0'] . '<>' . $island['commentLabel1'] . '<>' . $island['commentLabel2'] . '<>' . $island['commentLabel3'] . '<>' . $island['commentLabel4'];
	hako_write('OUT', $comments . "\n");
	hako_write('OUT', $island['password'] . "\n");
	hako_write('OUT', $island['money'] . "\n");
	hako_write('OUT', $island['food'] . "\n");
	hako_write('OUT', $island['pop'] . "," . $island['popspace'] . "," . $island['spa'] . "\n");
	hako_write('OUT', ($island['area'] ?? 0) . "\n");
	hako_write('OUT', ($island['farm'] ?? 0) . "\n");
	$pastweather = $island['pastweather'];
	hako_write('OUT', sprintf("%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d\n",
		$island['weather'],
		$pastweather[0],
		$pastweather[1],
		$pastweather[2],
		$pastweather[3],
		$pastweather[4],
		$pastweather[5],
		$pastweather[6],
		$pastweather[7],
		$pastweather[8],
		$pastweather[9],
		$pastweather[10]
	));
	hako_write('OUT', ($island['factory'] ?? 0) . "\n");
	hako_write('OUT', $island['port'] . "\n");
	hako_write('OUT', $island['mountain'] . "\n");
	hako_write('OUT', $island['tower'] . "\n");
	hako_write('OUT', $island['yousyoku'] . "\n");
	hako_write('OUT', $island['turnsu'] . "," . $island['zyuni'] . "," . $island['kaisi'] . "\n");
	hako_write('OUT', $island['winP'] . "," . $island['loseP'] . "," . $island['winS'] . "," . $island['possess'] . "\n");
	hako_write('OUT', $island['MissileK'] . "," . $island['MissileA'] . "\n");
	hako_write('OUT', $island['ally'] . "\n");
	$present = $island['present'];
	hako_write('OUT', sprintf("%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d\n", 
		$present[0],
		$present[1],
		$present[2],
		$present[3],
		$present[4],
		$present[5],
		$present[6],
		$present[7],
		$present[8],
		$present[9],
		$present[10],
		$present[11],
		$present[12],
		$present[13]
	));
	
	hako_write('OUT', $island['allex'] . "\n");
	hako_write('OUT', $island['status'] . "\n");
	hako_write('OUT', $island['evil'] . "\n");
	hako_write('OUT', $island['monsfound'] . "\n");
	hako_write('OUT', $island['order'] . "\n");
	hako_write('OUT', $island['x'] . "," . $island['y'] . "\n");
	
	hako_write('OUT', $island['ore'] . "\n");
	hako_write('OUT', $island['weapon'] . "\n");
	hako_write('OUT', $island['oil'] . "\n");
	hako_write('OUT', $island['oilfield'] . "\n");
	
	// 괴수 배틀용
	$monster = $island['monster'];
	hako_write('OUT', sprintf("%d,%s,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d\n", 
		$monster[0],
		$monster[1],
		$monster[2],
		$monster[3],
		$monster[4],
		$monster[5],
		$monster[6],
		$monster[7],
		$monster[8],
		$monster[9],
		$monster[10],
		$monster[11],
		$monster[12],
		$monster[13]
	));
	hako_write('OUT', $island['monsurl'] . "\n");

	
	if($Htournament){
		// 간이 토너먼트
		hako_write('TOUT', $island['fight_id'] . "\n");
		hako_write('TOUT', "\n");
		hako_write('TOUT', "\n");
		hako_write('TOUT', "\n");
		hako_write('TOUT', "\n");
	}
	}
	
	// 지형
	if(($num <= -1) || ($mode == 3) || ($mode == 4) || ($num == $island['id'])) {
		$retry = $HretryCount;
		if($mode == 3){
			// 우주 맵
			while(!hako_open('IOUT', ">{$HtempdirName}/submaptmp.0")) {
				$retry--;
				if ($retry <= 0) { return 0; }
				//  0.2 초 sleep
				usleep(200000);
			}
		}elseif($mode == 4){
			while(!hako_open('IOUT', ">{$HtempdirName}/submaptmp.1")) {
				$retry--;
				if ($retry <= 0) { return 0; }
				//  0.2 초 sleep
				usleep(200000);
			}
		}else{
			while(!hako_open('IOUT', ">{$HtempdirName}/islandtmp." . $island['id'])) {
				$retry--;
				if ($retry <= 0) { return 0; }
				//  0.2 초 sleep
				usleep(200000);
			}
		}
		$land = null; $landValue = null; $land2 = null; $landValue2 = null; $nation = null;
		$land		= isset($island['land']) && is_array($island['land']) ? $island['land'] : array();
		$landValue	= isset($island['landValue']) && is_array($island['landValue']) ? $island['landValue'] : array();
		$land2		= isset($island['land2']) && is_array($island['land2']) ? $island['land2'] : array();
		$landValue2	= isset($island['landValue2']) && is_array($island['landValue2']) ? $island['landValue2'] : array();
		$nation		= isset($island['nation']) && is_array($island['nation']) ? $island['nation'] : array();
		
		// 지하
		$ugL = isset($island['ugL']) && is_array($island['ugL']) ? $island['ugL'] : array();
		$ugV = isset($island['ugV']) && is_array($island['ugV']) ? $island['ugV'] : array();
		$ugX = isset($island['ugX']) && is_array($island['ugX']) ? $island['ugX'] : array();
		$ugY = isset($island['ugY']) && is_array($island['ugY']) ? $island['ugY'] : array();
		$x = null; $y = null;
		if($mode == 3){
			// 우주 맵
			for($y = 0; $y < $HislandSize; $y++) {
				for($x = 0; $x < $HislandSize; $x++) {
					hako_write('IOUT', sprintf("%02x%04x%02x%04x%02x", $land[$x][$y] ?? $HlandSea, $landValue[$x][$y] ?? 0, $land2[$x][$y] ?? 0, $landValue2[$x][$y] ?? 0, $nation[$x][$y] ?? 0));
				}
				hako_write('IOUT', "\n");
			}
			hako_write('IOUT', ($island['space'] ?? '0') . "\n");
			hako_write('IOUT', ($island['solarwind'] ?? 0) . "\n");
			hako_write('IOUT', $island['area'] . "\n");
			hako_write('IOUT', ($island['pop'] ?? 0) . "\n");
			hako_write('IOUT', $island['farm'] . "\n");
			hako_write('IOUT', $island['factory'] . "\n");
			hako_write('IOUT', ($island['food'] ?? 0) . "," . ($island['foodP'] ?? 0) . "," . ($island['foodC'] ?? 0) . "\n");
			
			hako_write('IOUT', "0\n");
			hako_write('IOUT', "0\n");
			hako_write('IOUT', "0\n");
			hako_write('IOUT', "0\n");
			hako_write('IOUT', "0\n");
		}elseif($mode == 4){
			// 해역 맵
			for($y = 0; $y < $HoceanSize; $y++) {
				for($x = 0; $x < $HoceanSize; $x++) {
					hako_write('IOUT', sprintf("%02x%04x%02x%04x%02x", $land[$x][$y] ?? $HlandSea, $landValue[$x][$y] ?? 0, $land2[$x][$y] ?? 0, $landValue2[$x][$y] ?? 0, $nation[$x][$y] ?? 0));
				}
				hako_write('IOUT', "\n");
			}
			hako_write('IOUT', "0\n");
			hako_write('IOUT', "0\n");
			hako_write('IOUT', "0\n");
			hako_write('IOUT', "0\n");
			hako_write('IOUT', "0\n");
			hako_write('IOUT', "0\n");
			hako_write('IOUT', "0\n");
			
			hako_write('IOUT', "0\n");
			hako_write('IOUT', "0\n");
			hako_write('IOUT', "0\n");
			hako_write('IOUT', "0\n");
			hako_write('IOUT', "0\n");
		}else{
			// 통상 맵
			for($y = 0; $y < $HislandSize; $y++) {
				for($x = 0; $x < $HislandSize; $x++) {
					hako_write('IOUT', sprintf("%02x%04x%02x%04x%02x", $land[$x][$y] ?? $HlandSea, $landValue[$x][$y] ?? 0, $land2[$x][$y] ?? 0, $landValue2[$x][$y] ?? 0, $nation[$x][$y] ?? 0));
				}
				hako_write('IOUT', "\n");
			}
			// 지하
			$i = null;
			for($i = 0; $i < $HugMax; $i++) {
				// 체크
				$ux = isset($ugX[$i]) ? $ugX[$i] : "";
				$uy = isset($ugY[$i]) ? $ugY[$i] : "";
				$hasDokan = false;
				if($ux !== "" && $uy !== "") {
					$hasDokan = ((isset($land[$ux][$uy]) && $land[$ux][$uy] == $HlandDokan) ||
						(isset($land2[$ux][$uy]) && $land2[$ux][$uy] == $HlandDokan));
				}
				if(!$hasDokan){
					// 출구가 없기 때문에 클리어 한다
					$ugX[$i] = "";
					$ugY[$i] = "";
				}else{
					$ugX[$i] = $ux;
					$ugY[$i] = $uy;
				}
				for($x = 0; $x < 9; $x++) {
					$ul = isset($ugL[$i][$x]) ? $ugL[$i][$x] : 0;
					$uv = isset($ugV[$i][$x]) ? $ugV[$i][$x] : 0;
					hako_write('IOUT', sprintf("%01x%02x", $ul, $uv));
				}
				hako_write('IOUT', "," . $ugX[$i] . "," . $ugY[$i] . "\n");
			}
			//커멘드
			hako_write('IOUT', $island['cmdTurn'] . "\n");
			hako_write('IOUT', $island['cmdIp'] . "\n");
			hako_write('IOUT', $island['cmdId'] . "\n");
			hako_write('IOUT', $island['cmdtime'] . "\n");
			hako_write('IOUT', "\n");
			$command = null; $i = null;
			$command = isset($island['command']) && is_array($island['command']) ? $island['command'] : array();
			for($i = 0; $i < $HcommandMax; $i++) {
				if (!isset($command[$i]) || !is_array($command[$i])) { $command[$i] = array(); }
				$command[$i]['ip'] = rtrim((string)($command[$i]['ip'] ?? ''));
				hako_write('IOUT', sprintf("%d,%d,%d,%d,%d,%d,%d\n", 
					 $command[$i]['kind'] ?? $HcomDoNothing,
					 $command[$i]['target'] ?? 0,
					 $command[$i]['x'] ?? 0,
					 $command[$i]['y'] ?? 0,
					 $command[$i]['arg'] ?? 0,
					 $command[$i]['tx'] ?? 0,
					 $command[$i]['ty'] ?? 0
				));
			}
		}

		// 로컬 게시판
		$lbbs = $island['lbbs'];
		for($i = 0; $i < $HlbbsMax; $i++) {
			hako_write('IOUT', $lbbs[$i] . "\n");
		}

		hako_close('IOUT');
	}
	return 1;
}

// 디렉토리 삭제
function rmtree($dn) {
	if ($dn === '' || !file_exists($dn)) { return 1; }
	if (is_file($dn) || is_link($dn)) { return @unlink($dn); }
	$dh = @opendir($dn);
	if (!$dh) { return 0; }
	while (($fileName = readdir($dh)) !== false) {
		if ($fileName === '.' || $fileName === '..') { continue; }
		$path = $dn . '/' . $fileName;
		if (is_dir($path) && !is_link($path)) { rmtree($path); }
		else { @unlink($path); }
	}
	closedir($dh);
	return @rmdir($dn);
}

//----------------------------------------------------------------------
// 입출력
//----------------------------------------------------------------------

// CGI의 읽어들여
function cgiInput() {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $Halistmode, $Hallyflg, $Hasync, $HbaseDir, $HbfieldMode, $HcomDoNothing, $HcomL, $HcommandArg, $HcommandComary, $HcommandKind, $HcommandMax, $HcommandMode, $HcommandPlanNumber, $HcommandTarget, $HcommandTX, $HcommandTY, $HcommandX, $HcommandY, $HcommentLabel0, $HcommentLabel1, $HcommentLabel2, $HcommentLabel3, $HcommentLabel4, $HcssFile, $HcurrentID, $HcurrentName, $HcurrentOwnerName, $Hcustom, $Hdebug, $HdebugMode, $HdefaultKind, $HdefaultName, $HdefaultPassword, $HdefaultTX, $HdefaultTY, $HdefaultX, $HdefaultY, $HdirMode, $helpDir, $HerrorNum, $HexchangeBidID, $HexchangeBuy, $HexchangeBuyCost, $HexchangeCon, $HexchangeDelID, $HexchangeMode, $HexchangeSell, $HexchangeSellCost, $HflexTime, $HflexTimeSet, $HforeignerID, $Hically, $Hicevil, $Hicfood, $HichangeMode, $Hicmoney, $Hicspace, $Hicweapon, $HidToName, $HidToNumber, $HimageDir, $HimgLine, $HinputPassword, $HinputPassword2, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNextID, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HjavaMode, $HjavaModeSet, $HjumpURL, $HlandBase, $HlandDokan, $HlandEarth, $HlandOcean, $HlandOPlayer, $HlandSea, $HlandSpaceBase, $HlastTurn, $HlbbsMax, $HlbbsMessage, $HlbbsMode, $HlbbsMode2, $HlbbsName, $HlbbsType, $HlchangeKIND, $HlchangeMode, $HlchangeVALUE, $Hlinkcheck, $HlistID, $HmainMode, $HmasterPassword, $Hmessage, $Hmonsname, $HmonsterName, $Hmonsurl, $Hmyship, $HmyshipFlg, $Hocean, $HoceanSize, $HokURL, $HoldPassword, $HomeImage, $hour, $hp, $HpasswordFile, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $HpreDeleteID, $HpreDeleteMode, $HpresentFood, $HpresentLog, $HpresentMode, $HpresentMoney, $HprintID, $Hprofile, $HprofileDir, $HpunishID, $HpunishMode, $HretryCount, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $Hrsswrite, $HseaChk, $HskinName, $Hspace, $HspaceID, $Hspacemap, $HspecialPassword, $HtempBack, $HthisFile, $Htitle, $htmlBgColor, $htmlBody, $HtmTime1, $HtmTime2, $HtmTime3, $HtopAxes, $Htournament, $HtournamentmonsId, $hturn, $HugMax, $Hugmode, $HunitTime, $Hurlownermode, $imageDir, $lockMode, $toppage, $versionInfo;
	global $defaultID, $defaultTarget;
	$line = null; $getLine = null;
	// 입력 수신: PHP 5.x 환경에서는 php://input 이 비어있는 경우가 있어 $_POST 를 우선 사용한다.
	if (!empty($_POST)) {
		$line = http_build_query($_POST);
	} else {
		$line = file_get_contents('php://input');
		if ($line === false) { $line = ''; }
	}
	$line = strtr($line, '+', ' ');
//	$line =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
	$line = preg_replace_callback('/%([a-fA-F0-9]{2})/', function($m) { return chr(hexdec($m[1])); }, $line);
//	$line = jcode::euc($line);
//	jcode::convert($line, 'euc');
	$line = preg_replace('/[\x00-\x1f\,]/', '', $line, -1);
	if ($line !== '' && substr($line, -1) !== '&') { $line .= '&'; }

	// GET의 녀석도 받는다
	$getLine = isset($_SERVER['QUERY_STRING']) ? $_SERVER['QUERY_STRING'] : '';
	$getLine = str_replace(array('%22','\"','"'), '', $getLine);
	if ($getLine !== '' && substr($getLine, -1) !== '&') { $getLine .= '&'; }
//	HdebugOut("POST=$line");
//	HdebugOut("GET =$getLine");

	//  대상의 도
	if (preg_match('/CommandButton([0-9]+)=/', $line, $_m)) {
		// 커멘드 송신 버튼의 경우
		$HcurrentID = $_m[1];
	}

	if (preg_match('/ISLANDNAME=([^\&]*)\&/', $line, $_m)) {
		// 이름 지정의 경우
		$HcurrentName = cutColumn($_m[1], 32);
	}

	if (preg_match('/OWNERNAME=([^\&]*)\&/', $line, $_m)) {
		// 사용자명의 경우
		$HcurrentOwnerName = cutColumn($_m[1], 32);
	}

	if (preg_match('/ISLANDID=([0-9]+)\&/', $line, $_m)) {
		// 그 외의 경우
		$HcurrentID = $_m[1];
	}

	if (preg_match('/LBBSTYPE=([^\&]*)\&/', $line, $_m)) {
		// 게시판의 통신 형식
		$HlbbsType = $_m[1];
	}

	// 패스워드
	if (preg_match('/OLDPASS=([^\&]*)\&/', $line, $_m)) {
		$HoldPassword = $_m[1];
		$HdefaultPassword = $_m[1];
	}
	if (preg_match('/PASSWORD=([^\&]*)\&/', $line, $_m)) {
		$HinputPassword = $_m[1];
		$HdefaultPassword = $_m[1];
	}
	if (preg_match('/PASSWORD2=([^\&]*)\&/', $line, $_m)) {
		$HinputPassword2 = $_m[1];
	}
	// 진영모드 사용 시, 일반 설정 변경 화면에서 선택한 진영값입니다.
	// CHANGEALLY=-1 은 "변경 안함" 이므로 changeMain()에서 기존 값을 유지합니다.
	if (preg_match('/CHANGEALLY=([^\&]*)\&/', $line, $_m)) {
		$HchangeAlly = $_m[1];
		$GLOBALS['HchangeAlly'] = $HchangeAlly;
	}

	// 메세지
	if (preg_match('/MESSAGE=([^\&]*)\&/', $line, $_m)) {
		$Hmessage = cutColumn($_m[1], 120);
	}

	// 코멘트 라벨
	if (preg_match('/COMMENT_LABEL0=([^\&]*)\&/', $line, $_m)) {
		$HcommentLabel0 = $_m[1];
	}
	if (preg_match('/COMMENT_LABEL1=([^\&]*)\&/', $line, $_m)) {
		$HcommentLabel1 = $_m[1];
	}
	if (preg_match('/COMMENT_LABEL2=([^\&]*)\&/', $line, $_m)) {
		$HcommentLabel2 = $_m[1];
	}
	if (preg_match('/COMMENT_LABEL3=([^\&]*)\&/', $line, $_m)) {
		$HcommentLabel3 = $_m[1];
	}
	if (preg_match('/COMMENT_LABEL4=([^\&]*)\&/', $line, $_m)) {
		$HcommentLabel4 = $_m[1];
	}
	
	// 괴수 설정
	if (preg_match('/MONSNAME=([^\&]*)\&/', $line, $_m)) {
		$Hmonsname = cutColumn($_m[1], 32);
	}
	if (preg_match('/MONSURL=([^\&]*)\&/', $line, $_m)) {
		$Hmonsurl = cutColumn($_m[1], 80);
	}
	
	// Jaｖa스크립트 모드
	if (preg_match('/JAVAMODE=(cgi|java)/', $line, $_m)) {
		$HjavaMode = $_m[1];
	}
	if (preg_match('/JAVAMODE=(cgi|java)/', $getLine, $_m)) {
		$HjavaMode = $_m[1];
	}
	// 비동기 통신 플래그
	if (preg_match('/async=true\&/', $line, $_m)) {
		$Hasync = 1;
	}
	if (preg_match('/CommandJavaButton([0-9]+)=/', $line, $_m)) {
		// 커멘드 송신 버튼의 경우(Jaｖa스크립트)
		$HcurrentID = $_m[1];
		$defaultID = $_m[1];
	}

	// 로컬 게시판
	if (preg_match('/LBBSNAME=([^\&]*)\&/', $line, $_m)) {
		$HlbbsName = $_m[1];
		$HdefaultName = $_m[1];
	}
	if (preg_match('/LBBSMESSAGE=([^\&]*)\&/', $line, $_m)) {
		$HlbbsMessage = cutColumn($_m[1], 100);
	}

	// 로컬 이미지 지정
	if (preg_match('/IMGLINEMAC=([^&]*)\&/', $line, $_m)) {
		$flag = $_m[1];
		if($flag == ''){
			$flag = $imageDir;
		} else {
			$flag = preg_replace('/ /', '%20', $flag, -1);
			$flag = 'file:///' . $flag;
		}
		$HimgLine = $flag;
	} elseif (preg_match('/IMGLINE=([^&]*)\&/', $line, $_m)) {
		$flag = substr($_m[1], 0 , -10);
		$flag = strtr($flag, "\\", "/");
		if($flag == ''){
			$flag = $imageDir;
		} else {
			$flag = preg_replace('/ /', '%20', $flag, -1);
			$flag = 'file:///' . $flag;
		}
		$HimgLine = $flag;
	}
	if (hako_imgline_is_unset($HimgLine, $imageDir)) {
		$HimgLine = '';
	}

	// 배계로 투과 이미지을 사용할까
	if (preg_match('/RMYSHIP=([^&]*)\&/', $line, $_m)) {
		$HmyshipFlg = 1;
		$Hmyship = $_m[1];
	}

	// main mode의 취득
	if (preg_match('/TurnButton/', $line, $_m)) {
		if($Hdebug == 1) {
			$HmainMode = 'Hdebugturn';
		}
	} elseif (preg_match('/kani/', $getLine, $_m)) {
		$HmainMode = 'kani';
	} elseif (preg_match('/alist=([0-9]*)/', $getLine, $_m)) {
		$HmainMode = 'alist';
		$Halistmode = $_m[1];
	} elseif (preg_match('/'.preg_quote($Hurlownermode, '/').'=([0-9]*)/', $getLine, $_m)) {
		$HjavaMode = 'java';
		$defaultID = $_m[1];
		$HcurrentID = $_m[1];
		$HmainMode = 'owner';
		if (preg_match('/PASSWORD=([^\&]*)\&/', $getLine, $_m)) {
			$HinputPassword = $_m[1];
			$HdefaultPassword = $_m[1];
		}
	} elseif (preg_match('/settei=([^\&]*)/', $getLine, $_m)) {# 로컬 이미지 지정
		$HmainMode = 'settei';
		$HdefaultPassword = $_m[1];
	} elseif (preg_match('/SIGHTMODE=on/', $line, $_m)) {
		// 인증 관광 모드
		if (preg_match('/PISLANDID=([0-9]+)\&/', $line, $_m)) {
			$HprintID = $_m[1];# 자신의 ID
		}
		$HmainMode = 'print';
	} elseif (preg_match('/OwnerButton/', $line, $_m)) {
		$HmainMode = 'owner';
	} elseif (preg_match('/SUCCESSIVE=([0-9]*)/', $getLine, $_m)) {# neo_otacky씨가 작성
		$HmainMode = 'rekidai';
	} elseif (preg_match('/Sight=([0-9]*)/', $getLine, $_m)) {
		$HmainMode = 'print';
		$HcurrentID = $_m[1];
	} elseif (preg_match('/IslandMap=([0-9]*)/', $getLine, $_m)) {
		$HmainMode = 'landmap';
		if($_m[1] >= 1000){
			// 지하
			$Hugmode = 1;
			$HcurrentID = $_m[1] - 1000;
		}else{
			$HcurrentID = $_m[1];
		}
	} elseif (preg_match('/NewIslandButton/', $line, $_m)) {
		$HmainMode = 'new';
		if (preg_match('/TOURNAMENTMONS=([0-9]*)/', $line, $_m)) {
			$HtournamentmonsId = $_m[1];
		} else {
			$HtournamentmonsId = 0;
		}
	} elseif (preg_match('/LbbsButton(..)([0-9]*)/', $line, $_m)) {
		$HmainMode = 'lbbs';
		if($_m[1] == 'SS') {
			// 관광자
			$HlbbsMode = 0;
		} elseif($_m[1] == 'OW') {
			// 도주
			$HlbbsMode = 1;
		} elseif($_m[1] == 'FO') {
			// 다른 도주
			$HlbbsMode = 3;
			$HforeignerID = $HcurrentID;
		} elseif($_m[1] == 'FD') {
			// 다른 도주삭제
			$HlbbsMode = 4;
			$HforeignerID = $HcurrentID;
		} else {
			// 삭제
			$HlbbsMode = 2;
		}
		$HcurrentID = $_m[2];

		// 삭제일지도 모르기 때문에, 번호를 취득
		if (preg_match('/NUMBER=([^\&]*)\&?/', $line, $_m)) {
			$HcommandPlanNumber = $_m[1];
		} else {
			$HcommandPlanNumber = 0;
		}
		
		if (preg_match('/LBBSLIST=([^\&]*)\&?/', $line, $_m)) {
			$HlbbsMode2 = $_m[1];
		} else {
			$HlbbsMode2 = '';
		}
	} elseif (preg_match('/ChangeInfoButton/', $line, $_m)) {
		$HmainMode = 'change';
	} elseif (preg_match('/MessageButton([0-9]*)/', $line, $_m)) {
		$HmainMode = 'comment';
		$HcurrentID = $_m[1];
	} elseif (preg_match('/CLbbsRButton([0-9]*)/', $line, $_m)) {
		$HmainMode = 'clbbs';
		$HcurrentID = $_m[1];
	} elseif (preg_match('/customButton([0-9]*)/', $line, $_m)) {
		$HmainMode = 'custom';
		$HcurrentID = $_m[1];
	} elseif (preg_match('/customMButton([0-9]*)/', $line, $_m)) {
		$HmainMode = 'custom2';
		$HcurrentID = $_m[1];
		if (preg_match('/custom3=on/', $line, $_m)) { $Hcustom[3] = 1;  }
		if (preg_match('/custom4=on/', $line, $_m)) { $Hcustom[4] = 1;  }
		if (preg_match('/custom5=on/', $line, $_m)) { $Hcustom[5] = 1;  }
		if (preg_match('/custom6=on/', $line, $_m)) { $Hcustom[6] = 1;  }
		if (preg_match('/custom7=on/', $line, $_m)) { $Hcustom[7] = 1;  }
		if (preg_match('/custom8=on/', $line, $_m)) { $Hcustom[8] = 1;  }
		if (preg_match('/custom9=on/', $line, $_m)) { $Hcustom[9] = 1;  }
		if (preg_match('/custom10=on/', $line, $_m)) { $Hcustom[10] = 1;  }
		if (preg_match('/custom11=on/', $line, $_m)) { $Hcustom[11] = 1;  }
	} elseif (preg_match('/MonsButton([0-9]*)/', $line, $_m)) {
		$HmainMode = 'monsedit';
		$HcurrentID = $_m[1];
	} elseif (preg_match('/CommandJavaButton/', $line, $_m)) {
		$HmainMode = 'commandJava';
		preg_match('/COMARY=([^\&]*)\&/', $line, $_m);
		$HcommandComary = $_m[1];
		
		preg_match('/COMMAND=([^\&]*)\&/', $line, $_m);
		$HcommandKind = $_m[1];
		$HdefaultKind = $_m[1];
		preg_match('/AMOUNT=([^\&]*)\&/', $line, $_m);
		$HcommandArg = $_m[1];
		preg_match('/TARGETID=([^\&]*)\&/', $line, $_m);
		$HcommandTarget = $_m[1];
		$defaultTarget = $_m[1];
		preg_match('/POINTX=([^\&]*)\&/', $line, $_m);
		$HcommandX = $_m[1];
		$HdefaultX = $_m[1];
		preg_match('/POINTY=([^\&]*)\&/', $line, $_m);
		$HcommandY = $_m[1];
		$HdefaultY = $_m[1];
		preg_match('/POINTTX=([^\&]*)\&/', $line, $_m);
		$HcommandTX = $_m[1];
		$HdefaultTX = $_m[1];
		preg_match('/POINTTY=([^\&]*)\&/', $line, $_m);
		$HcommandTY = $_m[1];
		$HdefaultTY = $_m[1];
		
	} elseif (preg_match('/CommandButton/', $line, $_m)) {
		if($HjavaMode == 'java'){
			$HmainMode = 'command2';
		}else{
			$HmainMode = 'command';
		}
		// 커멘드 모드의 경우, 커멘드의 취득
		preg_match('/NUMBER=([^\&]*)\&/', $line, $_m);
		
		$HcommandPlanNumber = $_m[1];
		preg_match('/COMMAND=([^\&]*)\&/', $line, $_m);
		$HcommandKind = $_m[1];
		$HdefaultKind = $_m[1];
		preg_match('/AMOUNT=([^\&]*)\&/', $line, $_m);
		$HcommandArg = $_m[1];
		preg_match('/TARGETID=([^\&]*)\&/', $line, $_m);
		$HcommandTarget = $_m[1];
		$defaultTarget = $_m[1];
		preg_match('/POINTX=([^\&]*)\&/', $line, $_m);
		$HcommandX = $_m[1];
		$HdefaultX = $_m[1];
		preg_match('/POINTY=([^\&]*)\&/', $line, $_m);
		$HcommandY = $_m[1];
		$HdefaultY = $_m[1];
		preg_match('/POINTTX=([^\&]*)\&/', $line, $_m);
		$HcommandTX = $_m[1];
		$HdefaultTX = $_m[1];
		preg_match('/POINTTY=([^\&]*)\&/', $line, $_m);
		$HcommandTY = $_m[1];
		$HdefaultTY = $_m[1];

		preg_match('/COMMANDMODE=(write|insert|delete)/', $line, $_m);
		$HcommandMode = $_m[1];
	} elseif (preg_match('/camp([0-9]*)/', $line, $_m)) {
		$HmainMode = 'camp';
		$HcurrentID = $_m[1];
// 자원 거래소
	} elseif (preg_match('/Exchange=([0-9]*)/', $getLine, $_m)) {
		$HmainMode = 'exchange';
		$HexchangeMode = 'show';
	} elseif (preg_match('/ExchangeButton/', $line, $_m)) {
		$HmainMode = 'exchange';
		$HexchangeMode = 'add';

		preg_match('/EXC_SELL=([^\&]*)\&/', $line, $_m);
		$HexchangeSell = $_m[1];
		preg_match('/EXC_SELL1=([^\&]*)\&/', $line, $_m);
		$HexchangeSellCost = $_m[1] * 100;
		preg_match('/EXC_SELL0=([^\&]*)\&/', $line, $_m);
		$HexchangeSellCost += $_m[1];
		preg_match('/EXC_BUY=([^\&]*)\&/', $line, $_m);
		$HexchangeBuy = $_m[1];
		preg_match('/EXC_BUY1=([^\&]*)\&/', $line, $_m);
		$HexchangeBuyCost = $_m[1] * 100;
		preg_match('/EXC_BUY0=([^\&]*)\&/', $line, $_m);
		$HexchangeBuyCost += $_m[1];
	} elseif (preg_match('/ExchangeBidButton/', $line, $_m)) {
		$HmainMode = 'exchange';
		$HexchangeMode = 'bid';
		preg_match('/EXC_SELL1=([^\&]*)\&/', $line, $_m);
		$HexchangeSellCost = $_m[1] * 100;
		preg_match('/EXC_SELL0=([^\&]*)\&/', $line, $_m);
		$HexchangeSellCost += $_m[1];
		preg_match('/EXC_ID=([^\&]*)\&/', $line, $_m);
		$HexchangeBidID = $_m[1];
		$HexchangeCon = 1;
	} elseif (preg_match('/ExchangeBid2Button/', $line, $_m)) {
		$HmainMode = 'exchange';
		$HexchangeMode = 'bid';
		preg_match('/EXC_SELL=([^\&]*)\&/', $line, $_m);
		$HexchangeSellCost = $_m[1];
		preg_match('/EXC_ID=([^\&]*)\&/', $line, $_m);
		$HexchangeBidID = $_m[1];
		$HexchangeCon = 0;
	} elseif (preg_match('/ExchangeDelButton/', $line, $_m)) {
		$HmainMode = 'exchange';
		$HexchangeMode = 'del';

		preg_match('/EXC_ID=([^\&]*)\&/', $line, $_m);
		$HexchangeDelID = $_m[1];

// 상세 표시
	} elseif (preg_match('/list=([0-9]*)/', $getLine, $_m)) {
		$HlistID = $_m[1];
		$HmainMode = 'list';

// 우주 맵 표시
	} elseif (preg_match('/space=([0-9]*)/', $getLine, $_m)) {
		$HspaceID = $_m[1];
		$HmainMode = 'space';

// 해역 맵 표시
	} elseif (preg_match('/Ocean=([0-9]*)/', $getLine, $_m)) {
		$HmainMode = 'ocean';

// BattleField 작성 모드
	} elseif (preg_match('/Bfield=([^\&]*)/', $getLine, $_m)) {
		// 최초의 기동
		$HmainMode = 'bfield';
		$HbfieldMode = 0;
		$HdefaultPassword = $_m[1];
	} elseif (preg_match('/Bfield=([^\&]*)\&/', $line, $_m)) {
		// BattleField 작성 버튼이 밀린 기동
		$HmainMode = 'bfield';
		if (preg_match('/LBFIELD=([0-9]+)\&/', $line, $_m)) {
			$HbfieldMode = $_m[1];
		}else{
			$HbfieldMode = 0;
		}
		$HdefaultPassword = $_m[1];
// 초기설정 확인 모드
	} elseif (preg_match('/SetupV=([^\&]*)/', $getLine, $_m)) {
		$HmainMode = 'setupv';
		$HdefaultPassword = $_m[1];

// 간이 토너먼트
} elseif (preg_match('/LoseMap=([0-9]*)/', $getLine, $_m)) {
	$HmainMode = 'FightIsland';
	$HcurrentID = $_m[1];
} elseif (preg_match('/FightLog/', $getLine, $_m)) {
	$HmainMode = 'FightView';

// 관리인에 의한 선물 모드?
	} elseif (preg_match('/Present/', $getLine, $_m)) {
		// 최초의 기동
		$HmainMode = 'present';
		$HpresentMode = 0;
	} elseif (preg_match('/Present/', $line, $_m)) {
		//  선물 버튼이 밀린 기동?
		$HmainMode = 'present';
		$HpresentMode = 1;
		preg_match('/PRESENTMONEY=([^\&]*)\&/', $line, $_m); $HpresentMoney = isset($_m[1]) ? $_m[1] : null;
		preg_match('/PRESENTFOOD=([^\&]*)\&/', $line, $_m); $HpresentFood = isset($_m[1]) ? $_m[1] : null;
		preg_match('/PRESENTLOG=([^\&]*)\&/', $line, $_m); $HpresentLog = isset($_m[1]) ? $_m[1] : null;

// 관리인에 의한 제재 모드
	} elseif (preg_match('/Punish=([^\&]*)/', $getLine, $_m)) {
		// 최초의 기동
		$HmainMode = 'punish';
		$HpunishMode = 0;
		$HdefaultPassword = $_m[1];
	} elseif (preg_match('/Punish=([^\&]*)\&/', $line, $_m)) {
		// 제재 버튼이 밀린 기동
		$HmainMode = 'punish';
		$HpunishMode = 1;
		$HdefaultPassword = $_m[1];

		preg_match('/POINTX=([^\&]*)\&/', $line, $_m);
		$HcommandX = $_m[1];
		$HdefaultX = $_m[1];
		preg_match('/POINTY=([^\&]*)\&/', $line, $_m);
		$HcommandY = $_m[1];
		$HdefaultY = $_m[1];
		preg_match('/PUNISHID=([^\&]*)\&/', $line, $_m);
		$HpunishID = $_m[1];
// 관리인에 의한 지형 변경 모드
	} elseif (preg_match('/Lchange=([^\&]*)/', $getLine, $_m)) {
		// 최초의 기동
		$HmainMode = 'lchange';
		$HlchangeMode = 0;
		$HdefaultPassword = $_m[1];
	} elseif (preg_match('/LchangeButtonM=([^\&]*)\&/', $line, $_m)) {
		// 맵 변경
		$HmainMode = 'lchange';
		$HlchangeMode = 0;
		preg_match('/Lchange=([^\&]*)\&/', $line, $_m);
		$HdefaultPassword = $_m[1];
	} elseif (preg_match('/Lchange=([^\&]*)\&/', $line, $_m)) {
		// 변경 버튼이 밀린 기동
		$HmainMode = 'lchange';
		$HlchangeMode = 1;
		$HdefaultPassword = $_m[1];

		preg_match('/POINTX=([^\&]*)\&/', $line, $_m);
		$HcommandX = $_m[1];
		$HdefaultX = $_m[1];
		preg_match('/POINTY=([^\&]*)\&/', $line, $_m);
		$HcommandY = $_m[1];
		$HdefaultY = $_m[1];
		preg_match('/LCHANGEKIND=([^\&]*)\&/', $line, $_m);
		$HlchangeKIND = $_m[1];
		preg_match('/LCHANGEVALUE=([^\&]*)\&/', $line, $_m);
		$HlchangeVALUE = $_m[1];
// 관리인에 의한 각종도데이터 변경 모드
	} elseif (preg_match('/Ichange=([^\&]*)/', $getLine, $_m)) {
		// 최초의 기동
		$HmainMode = 'ichange';
		$HichangeMode = 0;
		$HdefaultPassword = $_m[1];
	} elseif (preg_match('/Ichange=([^\&]*)\&/', $line, $_m)) {
		$HmainMode = 'ichange';
		$HichangeMode = 1;
		$HdefaultPassword = $_m[1];
		preg_match('/ICID=([^\&]*)\&/', $line, $_m);
		$HcurrentID = $_m[1];
		preg_match('/ICMONEY=([^\&]*)\&/', $line, $_m);
		$Hicmoney = $_m[1];
		preg_match('/ICFOOD=([^\&]*)\&/', $line, $_m);
		$Hicfood = $_m[1];
		preg_match('/ICWEAPON=([^\&]*)\&/', $line, $_m);
		$Hicweapon = $_m[1];
		preg_match('/ICEVIL=([^\&]*)\&/', $line, $_m);
		$Hicevil = $_m[1];
		if (preg_match('/ICSPACE=on/', $line, $_m)) { $Hicspace = 1;  }
		preg_match('/ICALLY=([^\&]*)\&/', $line, $_m);
		$Hically = $_m[1];
// 관리인에 의한 보관 모드
	} elseif (preg_match('/Pdelete=([^\&]*)/', $getLine, $_m)) {
		// 최초의 기동
		$HmainMode = 'predelete';
		$HpreDeleteMode = 0;
		$HdefaultPassword = $_m[1];
	} elseif (preg_match('/Pdelete=([^\&]*)\&/', $line, $_m)) {
		// 변경 버튼이 밀린 기동
		$HmainMode = 'predelete';
		$HpreDeleteMode = 1;
		$HdefaultPassword = $_m[1];
	} else {
		$HmainMode = 'top';
	}

	if (preg_match('/SKIN=([^\&]*)\&/', $line, $_m)) {
		$flag = $_m[1];
		if(($flag == 'del') || ($flag == '')){
			$flag = $HcssFile;
		}
		$HskinName = $flag;
	}

// 디버그
	if (preg_match('/debug=([0-9]*)/', $getLine, $_m)) {
		$HdebugMode = $_m[1];
	}
}


//cookie 입력
function cookieName($name) {
	return preg_replace('/[^A-Za-z0-9_]/', '_', $name);
}

function hako_cookie_get_value($suffix) {
	global $HthisFile;
	$names = array();
	$names[] = $HthisFile . $suffix;
	$names[] = cookieName($HthisFile . $suffix);
	$names[] = cookieName($HthisFile) . $suffix;
	$names[] = basename($HthisFile) . $suffix;
	$names[] = cookieName(basename($HthisFile) . $suffix);
	$names[] = $suffix;

	foreach ($names as $name) {
		if (isset($_COOKIE[$name])) {
			$v = $_COOKIE[$name];
			if (preg_match('/^\((.*)\)$/', $v, $_m)) { return $_m[1]; }
			return $v;
		}
	}

	$cookie = isset($_SERVER['HTTP_COOKIE']) ? $_SERVER['HTTP_COOKIE'] : '';
	foreach ($names as $name) {
		$quoted = preg_quote($name, '/');
		if (preg_match('/(?:^|;\s*)' . $quoted . '=\(([^\)]*)\)/', $cookie, $_m)) { return $_m[1]; }
		if (preg_match('/(?:^|;\s*)' . $quoted . '=([^;]*)/', $cookie, $_m)) { return trim($_m[1]); }
	}

	// 변환 전 CGI/PHP가 만든 쿠키명까지 허용한다. 경로·확장자 차이가 있어도 끝 이름이 같으면 읽는다.
	if (preg_match('/(?:^|;\s*)[^;=]*' . preg_quote($suffix, '/') . '=\(([^\)]*)\)/', $cookie, $_m)) { return $_m[1]; }
	if (preg_match('/(?:^|;\s*)[^;=]*' . preg_quote($suffix, '/') . '=([^;]*)/', $cookie, $_m)) { return trim($_m[1]); }
	return null;
}

function cookieInput() {
extract($GLOBALS, EXTR_SKIP);
  global $defaultID, $defaultTarget, $HdefaultPassword, $HinputPassword, $HdefaultName, $HdefaultX, $HdefaultY, $HdefaultTX, $HdefaultTY, $HdefaultKind, $HjavaModeSet, $HimgLine, $Hmyship, $HskinName, $HthisFile, $imageDir;

	$v = hako_cookie_get_value('OWNISLANDID'); if ($v !== null && $v !== '') { $defaultID = $v; }
	$v = hako_cookie_get_value('OWNISLANDPASSWORD'); if ($v !== null) { $HdefaultPassword = $v; if ($HinputPassword === '' || $HinputPassword === null) { $HinputPassword = $v; } }
	$v = hako_cookie_get_value('TARGETISLANDID'); if ($v !== null && $v !== '') { $defaultTarget = $v; }
	$v = hako_cookie_get_value('LBBSNAME'); if ($v !== null) { $HdefaultName = $v; }
	$v = hako_cookie_get_value('POINTX'); if ($v !== null && $v !== '') { $HdefaultX = $v; }
	$v = hako_cookie_get_value('POINTY'); if ($v !== null && $v !== '') { $HdefaultY = $v; }
	$v = hako_cookie_get_value('POINTTX'); if ($v !== null && $v !== '') { $HdefaultTX = $v; }
	$v = hako_cookie_get_value('POINTTY'); if ($v !== null && $v !== '') { $HdefaultTY = $v; }
	$v = hako_cookie_get_value('KIND'); if ($v !== null && $v !== '') { $HdefaultKind = $v; }
	$v = hako_cookie_get_value('JAVAMODESET'); if ($v !== null && $v !== '') { $HjavaModeSet = $v; }
	$v = hako_cookie_get_value('IMGLINE'); if ($v !== null && $v !== '') { $HimgLine = $v; }
	if (hako_imgline_is_unset($HimgLine, $imageDir)) { $HimgLine = ''; }
	$v = hako_cookie_get_value('MYSHIP'); if ($v !== null) { $Hmyship = $v; }
	$v = hako_cookie_get_value('SKIN'); if ($v !== null && $v !== '') { $HskinName = $v; }
}

//cookie 출력
function cookieOutput() {
extract($GLOBALS, EXTR_SKIP);
  global $HcurrentID, $HmainMode, $HinputPassword, $HdefaultPassword, $HcommandTarget, $HlbbsName, $HcommandX, $HcommandY, $HcommandTX, $HcommandTY, $HcommandKind, $HjavaMode, $HimgLine, $HmyshipFlg, $Hmyship, $HskinName, $HthisFile, $imageDir;
	$expires = time() + 30 * 86400;
	$path = '/';
	if(($HcurrentID) && ($HmainMode == 'owner')){
		setcookie(cookieName($HthisFile . 'OWNISLANDID'), "($HcurrentID)", $expires, $path);
	}
	$pass = $HinputPassword ? $HinputPassword : $HdefaultPassword;
	if($pass) {
		setcookie(cookieName($HthisFile . 'OWNISLANDPASSWORD'), "($pass)", $expires, $path);
	}
	if($HcommandTarget) {
		setcookie(cookieName($HthisFile . 'TARGETISLANDID'), "($HcommandTarget)", $expires, $path);
	}
	if($HlbbsName) {
		setcookie(cookieName($HthisFile . 'LBBSNAME'), "($HlbbsName)", $expires, $path);
	}
	if($HcommandX !== '' && $HcommandX !== null) {
		setcookie(cookieName($HthisFile . 'POINTX'), "($HcommandX)", $expires, $path);
	}
	if($HcommandY !== '' && $HcommandY !== null) {
		setcookie(cookieName($HthisFile . 'POINTY'), "($HcommandY)", $expires, $path);
	}
	if($HcommandTX !== '' && $HcommandTX !== null) {
		setcookie(cookieName($HthisFile . 'POINTTX'), "($HcommandTX)", $expires, $path);
	}
	if($HcommandTY !== '' && $HcommandTY !== null) {
		setcookie(cookieName($HthisFile . 'POINTTY'), "($HcommandTY)", $expires, $path);
	}
	if($HcommandKind) {
		setcookie(cookieName($HthisFile . 'KIND'), "($HcommandKind)", $expires, $path);
	}
	if($HjavaMode) {
		setcookie(cookieName($HthisFile . 'JAVAMODESET'), "($HjavaMode)", $expires, $path);
	}
	if(!hako_imgline_is_unset($HimgLine, $imageDir)) {
		setcookie(cookieName($HthisFile . 'IMGLINE'), "($HimgLine)", $expires, $path);
	} else {
		setcookie(cookieName($HthisFile . 'IMGLINE'), '', time() - 3600, $path);
	}
	if($HmyshipFlg) {
		setcookie(cookieName($HthisFile . 'MYSHIP'), "($Hmyship)", $expires, $path);
	}
	if((!is_array($HskinName)) && ($HskinName != '')) {
		setcookie(cookieName($HthisFile . 'SKIN'), "($HskinName)", $expires, $path);
	}
}

//----------------------------------------------------------------------
// 유틸리티
//----------------------------------------------------------------------
function hakolock() {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $Halistmode, $Hallyflg, $Hasync, $HbaseDir, $HbfieldMode, $HcomDoNothing, $HcomL, $HcommandArg, $HcommandComary, $HcommandKind, $HcommandMax, $HcommandMode, $HcommandPlanNumber, $HcommandTarget, $HcommandTX, $HcommandTY, $HcommandX, $HcommandY, $HcommentLabel0, $HcommentLabel1, $HcommentLabel2, $HcommentLabel3, $HcommentLabel4, $HcssFile, $HcurrentID, $HcurrentName, $HcurrentOwnerName, $Hcustom, $Hdebug, $HdebugMode, $HdefaultKind, $HdefaultName, $HdefaultPassword, $HdefaultTX, $HdefaultTY, $HdefaultX, $HdefaultY, $HdirMode, $helpDir, $HerrorNum, $HexchangeBidID, $HexchangeBuy, $HexchangeBuyCost, $HexchangeCon, $HexchangeDelID, $HexchangeMode, $HexchangeSell, $HexchangeSellCost, $HflexTime, $HflexTimeSet, $HforeignerID, $Hically, $Hicevil, $Hicfood, $HichangeMode, $Hicmoney, $Hicspace, $Hicweapon, $HidToName, $HidToNumber, $HimageDir, $HimgLine, $HinputPassword, $HinputPassword2, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNextID, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HjavaMode, $HjavaModeSet, $HjumpURL, $HlandBase, $HlandDokan, $HlandEarth, $HlandOcean, $HlandOPlayer, $HlandSea, $HlandSpaceBase, $HlastTurn, $HlbbsMax, $HlbbsMessage, $HlbbsMode, $HlbbsMode2, $HlbbsName, $HlbbsType, $HlchangeKIND, $HlchangeMode, $HlchangeVALUE, $Hlinkcheck, $HlistID, $HmainMode, $HmasterPassword, $Hmessage, $Hmonsname, $HmonsterName, $Hmonsurl, $Hmyship, $HmyshipFlg, $Hocean, $HoceanSize, $HokURL, $HoldPassword, $HomeImage, $hour, $hp, $HpasswordFile, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $HpreDeleteID, $HpreDeleteMode, $HpresentFood, $HpresentLog, $HpresentMode, $HpresentMoney, $HprintID, $Hprofile, $HprofileDir, $HpunishID, $HpunishMode, $HretryCount, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $Hrsswrite, $HseaChk, $HskinName, $Hspace, $HspaceID, $Hspacemap, $HspecialPassword, $HtempBack, $HthisFile, $Htitle, $htmlBgColor, $htmlBody, $HtmTime1, $HtmTime2, $HtmTime3, $HtopAxes, $Htournament, $HtournamentmonsId, $hturn, $HugMax, $Hugmode, $HunitTime, $Hurlownermode, $imageDir, $lockMode, $toppage, $versionInfo;
	if($lockMode == 1) {
		// directory식 락
		return hakolock1();
	} elseif($lockMode == 2) {
		// flock식 락
		return hakolock2();
	} elseif($lockMode == 3) {
		// symlink식 락
		return hakolock3();
	} elseif($lockMode == 4) {
		// 통상 파일식 락
		return hakolock4();
	} else {
		// rename식 락
		if (!($lfh = hakolock5())) { return 0; }
		return 1;
	}
}

function hakolock1() {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $Halistmode, $Hallyflg, $Hasync, $HbaseDir, $HbfieldMode, $HcomDoNothing, $HcomL, $HcommandArg, $HcommandComary, $HcommandKind, $HcommandMax, $HcommandMode, $HcommandPlanNumber, $HcommandTarget, $HcommandTX, $HcommandTY, $HcommandX, $HcommandY, $HcommentLabel0, $HcommentLabel1, $HcommentLabel2, $HcommentLabel3, $HcommentLabel4, $HcssFile, $HcurrentID, $HcurrentName, $HcurrentOwnerName, $Hcustom, $Hdebug, $HdebugMode, $HdefaultKind, $HdefaultName, $HdefaultPassword, $HdefaultTX, $HdefaultTY, $HdefaultX, $HdefaultY, $HdirMode, $helpDir, $HerrorNum, $HexchangeBidID, $HexchangeBuy, $HexchangeBuyCost, $HexchangeCon, $HexchangeDelID, $HexchangeMode, $HexchangeSell, $HexchangeSellCost, $HflexTime, $HflexTimeSet, $HforeignerID, $Hically, $Hicevil, $Hicfood, $HichangeMode, $Hicmoney, $Hicspace, $Hicweapon, $HidToName, $HidToNumber, $HimageDir, $HimgLine, $HinputPassword, $HinputPassword2, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNextID, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HjavaMode, $HjavaModeSet, $HjumpURL, $HlandBase, $HlandDokan, $HlandEarth, $HlandOcean, $HlandOPlayer, $HlandSea, $HlandSpaceBase, $HlastTurn, $HlbbsMax, $HlbbsMessage, $HlbbsMode, $HlbbsMode2, $HlbbsName, $HlbbsType, $HlchangeKIND, $HlchangeMode, $HlchangeVALUE, $Hlinkcheck, $HlistID, $HmainMode, $HmasterPassword, $Hmessage, $Hmonsname, $HmonsterName, $Hmonsurl, $Hmyship, $HmyshipFlg, $Hocean, $HoceanSize, $HokURL, $HoldPassword, $HomeImage, $hour, $hp, $HpasswordFile, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $HpreDeleteID, $HpreDeleteMode, $HpresentFood, $HpresentLog, $HpresentMode, $HpresentMoney, $HprintID, $Hprofile, $HprofileDir, $HpunishID, $HpunishMode, $HretryCount, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $Hrsswrite, $HseaChk, $HskinName, $Hspace, $HspaceID, $Hspacemap, $HspecialPassword, $HtempBack, $HthisFile, $Htitle, $htmlBgColor, $htmlBody, $HtmTime1, $HtmTime2, $HtmTime3, $HtopAxes, $Htournament, $HtournamentmonsId, $hturn, $HugMax, $Hugmode, $HunitTime, $Hurlownermode, $imageDir, $lockMode, $toppage, $versionInfo;
	// 락을 시험한다
	if(mkdir('hakojimalock', $HdirMode)) {
		// 성공
		return 1;
	} else {
		// 실패
		$b = file_exists('hakojimalock') ? intval(@filemtime('hakojimalock')) : 0;
		$lockExpires = is_array($unlockTime) ? 60 : intval($unlockTime);
		if(($b > 0) && ((time() -  $b)> $lockExpires)) {
			// 강제 해제
			unlock();

			// 헤더 출력
			tempHeader();

			// 강제 해제 메세지
			tempUnlock();

			// footer 출력
			tempFooter();

			// 종료
			exit(0);
		}
		return 0;
	}
}

function hakolock2() {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $Halistmode, $Hallyflg, $Hasync, $HbaseDir, $HbfieldMode, $HcomDoNothing, $HcomL, $HcommandArg, $HcommandComary, $HcommandKind, $HcommandMax, $HcommandMode, $HcommandPlanNumber, $HcommandTarget, $HcommandTX, $HcommandTY, $HcommandX, $HcommandY, $HcommentLabel0, $HcommentLabel1, $HcommentLabel2, $HcommentLabel3, $HcommentLabel4, $HcssFile, $HcurrentID, $HcurrentName, $HcurrentOwnerName, $Hcustom, $Hdebug, $HdebugMode, $HdefaultKind, $HdefaultName, $HdefaultPassword, $HdefaultTX, $HdefaultTY, $HdefaultX, $HdefaultY, $HdirMode, $helpDir, $HerrorNum, $HexchangeBidID, $HexchangeBuy, $HexchangeBuyCost, $HexchangeCon, $HexchangeDelID, $HexchangeMode, $HexchangeSell, $HexchangeSellCost, $HflexTime, $HflexTimeSet, $HforeignerID, $Hically, $Hicevil, $Hicfood, $HichangeMode, $Hicmoney, $Hicspace, $Hicweapon, $HidToName, $HidToNumber, $HimageDir, $HimgLine, $HinputPassword, $HinputPassword2, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNextID, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HjavaMode, $HjavaModeSet, $HjumpURL, $HlandBase, $HlandDokan, $HlandEarth, $HlandOcean, $HlandOPlayer, $HlandSea, $HlandSpaceBase, $HlastTurn, $HlbbsMax, $HlbbsMessage, $HlbbsMode, $HlbbsMode2, $HlbbsName, $HlbbsType, $HlchangeKIND, $HlchangeMode, $HlchangeVALUE, $Hlinkcheck, $HlistID, $HmainMode, $HmasterPassword, $Hmessage, $Hmonsname, $HmonsterName, $Hmonsurl, $Hmyship, $HmyshipFlg, $Hocean, $HoceanSize, $HokURL, $HoldPassword, $HomeImage, $hour, $hp, $HpasswordFile, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $HpreDeleteID, $HpreDeleteMode, $HpresentFood, $HpresentLog, $HpresentMode, $HpresentMoney, $HprintID, $Hprofile, $HprofileDir, $HpunishID, $HpunishMode, $HretryCount, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $Hrsswrite, $HseaChk, $HskinName, $Hspace, $HspaceID, $Hspacemap, $HspecialPassword, $HtempBack, $HthisFile, $Htitle, $htmlBgColor, $htmlBody, $HtmTime1, $HtmTime2, $HtmTime3, $HtopAxes, $Htournament, $HtournamentmonsId, $hturn, $HugMax, $Hugmode, $HunitTime, $Hurlownermode, $imageDir, $lockMode, $toppage, $versionInfo;
	hako_open('LOCKID', '>>hakojimalockflock');
	if(flock($GLOBALS['_hako_fh']['LOCKID'], 2)) {
		// 성공
		return 1;
	} else {
		// 실패
		return 0;
	}
}

function hakolock3() {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $Halistmode, $Hallyflg, $Hasync, $HbaseDir, $HbfieldMode, $HcomDoNothing, $HcomL, $HcommandArg, $HcommandComary, $HcommandKind, $HcommandMax, $HcommandMode, $HcommandPlanNumber, $HcommandTarget, $HcommandTX, $HcommandTY, $HcommandX, $HcommandY, $HcommentLabel0, $HcommentLabel1, $HcommentLabel2, $HcommentLabel3, $HcommentLabel4, $HcssFile, $HcurrentID, $HcurrentName, $HcurrentOwnerName, $Hcustom, $Hdebug, $HdebugMode, $HdefaultKind, $HdefaultName, $HdefaultPassword, $HdefaultTX, $HdefaultTY, $HdefaultX, $HdefaultY, $HdirMode, $helpDir, $HerrorNum, $HexchangeBidID, $HexchangeBuy, $HexchangeBuyCost, $HexchangeCon, $HexchangeDelID, $HexchangeMode, $HexchangeSell, $HexchangeSellCost, $HflexTime, $HflexTimeSet, $HforeignerID, $Hically, $Hicevil, $Hicfood, $HichangeMode, $Hicmoney, $Hicspace, $Hicweapon, $HidToName, $HidToNumber, $HimageDir, $HimgLine, $HinputPassword, $HinputPassword2, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNextID, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HjavaMode, $HjavaModeSet, $HjumpURL, $HlandBase, $HlandDokan, $HlandEarth, $HlandOcean, $HlandOPlayer, $HlandSea, $HlandSpaceBase, $HlastTurn, $HlbbsMax, $HlbbsMessage, $HlbbsMode, $HlbbsMode2, $HlbbsName, $HlbbsType, $HlchangeKIND, $HlchangeMode, $HlchangeVALUE, $Hlinkcheck, $HlistID, $HmainMode, $HmasterPassword, $Hmessage, $Hmonsname, $HmonsterName, $Hmonsurl, $Hmyship, $HmyshipFlg, $Hocean, $HoceanSize, $HokURL, $HoldPassword, $HomeImage, $hour, $hp, $HpasswordFile, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $HpreDeleteID, $HpreDeleteMode, $HpresentFood, $HpresentLog, $HpresentMode, $HpresentMoney, $HprintID, $Hprofile, $HprofileDir, $HpunishID, $HpunishMode, $HretryCount, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $Hrsswrite, $HseaChk, $HskinName, $Hspace, $HspaceID, $Hspacemap, $HspecialPassword, $HtempBack, $HthisFile, $Htitle, $htmlBgColor, $htmlBody, $HtmTime1, $HtmTime2, $HtmTime3, $HtopAxes, $Htournament, $HtournamentmonsId, $hturn, $HugMax, $Hugmode, $HunitTime, $Hurlownermode, $imageDir, $lockMode, $toppage, $versionInfo;
	// 락을 시험한다
	if(symlink('hakojimalockdummy', 'hakojimalock')) {
		// 성공
		return 1;
	} else {
		// 실패
		$b = file_exists('hakojimalock') ? intval(@filemtime('hakojimalock')) : 0;
		$lockExpires = is_array($unlockTime) ? 60 : intval($unlockTime);
		if(($b > 0) && ((time() -  $b)> $lockExpires)) {
			// 강제 해제
			unlock();

			// 헤더 출력
			tempHeader();

			// 강제 해제 메세지
			tempUnlock();

			// footer 출력
			tempFooter();

			// 종료
			exit(0);
		}
		return 0;
	}
}

function hakolock4() {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $Halistmode, $Hallyflg, $Hasync, $HbaseDir, $HbfieldMode, $HcomDoNothing, $HcomL, $HcommandArg, $HcommandComary, $HcommandKind, $HcommandMax, $HcommandMode, $HcommandPlanNumber, $HcommandTarget, $HcommandTX, $HcommandTY, $HcommandX, $HcommandY, $HcommentLabel0, $HcommentLabel1, $HcommentLabel2, $HcommentLabel3, $HcommentLabel4, $HcssFile, $HcurrentID, $HcurrentName, $HcurrentOwnerName, $Hcustom, $Hdebug, $HdebugMode, $HdefaultKind, $HdefaultName, $HdefaultPassword, $HdefaultTX, $HdefaultTY, $HdefaultX, $HdefaultY, $HdirMode, $helpDir, $HerrorNum, $HexchangeBidID, $HexchangeBuy, $HexchangeBuyCost, $HexchangeCon, $HexchangeDelID, $HexchangeMode, $HexchangeSell, $HexchangeSellCost, $HflexTime, $HflexTimeSet, $HforeignerID, $Hically, $Hicevil, $Hicfood, $HichangeMode, $Hicmoney, $Hicspace, $Hicweapon, $HidToName, $HidToNumber, $HimageDir, $HimgLine, $HinputPassword, $HinputPassword2, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNextID, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HjavaMode, $HjavaModeSet, $HjumpURL, $HlandBase, $HlandDokan, $HlandEarth, $HlandOcean, $HlandOPlayer, $HlandSea, $HlandSpaceBase, $HlastTurn, $HlbbsMax, $HlbbsMessage, $HlbbsMode, $HlbbsMode2, $HlbbsName, $HlbbsType, $HlchangeKIND, $HlchangeMode, $HlchangeVALUE, $Hlinkcheck, $HlistID, $HmainMode, $HmasterPassword, $Hmessage, $Hmonsname, $HmonsterName, $Hmonsurl, $Hmyship, $HmyshipFlg, $Hocean, $HoceanSize, $HokURL, $HoldPassword, $HomeImage, $hour, $hp, $HpasswordFile, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $HpreDeleteID, $HpreDeleteMode, $HpresentFood, $HpresentLog, $HpresentMode, $HpresentMoney, $HprintID, $Hprofile, $HprofileDir, $HpunishID, $HpunishMode, $HretryCount, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $Hrsswrite, $HseaChk, $HskinName, $Hspace, $HspaceID, $Hspacemap, $HspecialPassword, $HtempBack, $HthisFile, $Htitle, $htmlBgColor, $htmlBody, $HtmTime1, $HtmTime2, $HtmTime3, $HtopAxes, $Htournament, $HtournamentmonsId, $hturn, $HugMax, $Hugmode, $HunitTime, $Hurlownermode, $imageDir, $lockMode, $toppage, $versionInfo;
	// 락을 시험한다
	if(unlink('lockfile')) {
		// 성공
		hako_open('OUT', '>lockfile.lock');
		hako_write('OUT', time());
		hako_close('OUT');
		return 1;
	} else {
		// 락 시간 체크
		if(!hako_open('IN', 'lockfile.lock')) {
			return 0;
		}
		$t = null;
		$t = hako_getline('IN');
		hako_close('IN');
		if(($t != 0) && (($t + $unlockTime) < time())) {
			// 60초 이상 경과하고 있으면, 강제적으로 락을 제외한다
			unlock();

			// 헤더 출력
			tempHeader();

			// 강제 해제 메세지
			tempUnlock();

			// footer 출력
			tempFooter();

			// 종료
			exit(0);
		}
		return 0;
	}
}

// rename식(Perl 메모 http://www.din.or.jp/~ohzaki/perl.htm#File_Lock)
function hakolock5() {
  global $unlockTime;
  $lfh = array('dir' => "./", 'basename' => "lockfile", 'timeout' => $unlockTime, 'trytime' => 3);
  $lfh['path'] = $lfh['dir'] . $lfh['basename'];
  for ($i = 0; $i < $lfh['trytime']; $i++, sleep(1)) {
    if (rename($lfh['path'], $lfh['current'] = $lfh['path'] . time())) { return $lfh; }
  }
  if ($dh = opendir($lfh['dir'])) {
    while (false !== ($_file = readdir($dh))) {
      if (preg_match('/^' . preg_quote($lfh['basename'], '/') . '(\d+)/', $_file, $_m)) {
        if ((time() - $_m[1] > $lfh['timeout']) && rename($lfh['dir'] . $_file, $lfh['current'] = $lfh['path'] . time())) { closedir($dh); return $lfh; }
        break;
      }
    }
    closedir($dh);
  }
  return null;
}

// 락을 제외한다
function unlock() {
	if(!empty($GLOBALS['HlockReleased'])) { return; }
	$GLOBALS['HlockReleased'] = 1;
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $Halistmode, $Hallyflg, $Hasync, $HbaseDir, $HbfieldMode, $HcomDoNothing, $HcomL, $HcommandArg, $HcommandComary, $HcommandKind, $HcommandMax, $HcommandMode, $HcommandPlanNumber, $HcommandTarget, $HcommandTX, $HcommandTY, $HcommandX, $HcommandY, $HcommentLabel0, $HcommentLabel1, $HcommentLabel2, $HcommentLabel3, $HcommentLabel4, $HcssFile, $HcurrentID, $HcurrentName, $HcurrentOwnerName, $Hcustom, $Hdebug, $HdebugMode, $HdefaultKind, $HdefaultName, $HdefaultPassword, $HdefaultTX, $HdefaultTY, $HdefaultX, $HdefaultY, $HdirMode, $helpDir, $HerrorNum, $HexchangeBidID, $HexchangeBuy, $HexchangeBuyCost, $HexchangeCon, $HexchangeDelID, $HexchangeMode, $HexchangeSell, $HexchangeSellCost, $HflexTime, $HflexTimeSet, $HforeignerID, $Hically, $Hicevil, $Hicfood, $HichangeMode, $Hicmoney, $Hicspace, $Hicweapon, $HidToName, $HidToNumber, $HimageDir, $HimgLine, $HinputPassword, $HinputPassword2, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNextID, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HjavaMode, $HjavaModeSet, $HjumpURL, $HlandBase, $HlandDokan, $HlandEarth, $HlandOcean, $HlandOPlayer, $HlandSea, $HlandSpaceBase, $HlastTurn, $HlbbsMax, $HlbbsMessage, $HlbbsMode, $HlbbsMode2, $HlbbsName, $HlbbsType, $HlchangeKIND, $HlchangeMode, $HlchangeVALUE, $Hlinkcheck, $HlistID, $HmainMode, $HmasterPassword, $Hmessage, $Hmonsname, $HmonsterName, $Hmonsurl, $Hmyship, $HmyshipFlg, $Hocean, $HoceanSize, $HokURL, $HoldPassword, $HomeImage, $hour, $hp, $HpasswordFile, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $HpreDeleteID, $HpreDeleteMode, $HpresentFood, $HpresentLog, $HpresentMode, $HpresentMoney, $HprintID, $Hprofile, $HprofileDir, $HpunishID, $HpunishMode, $HretryCount, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $Hrsswrite, $HseaChk, $HskinName, $Hspace, $HspaceID, $Hspacemap, $HspecialPassword, $HtempBack, $HthisFile, $Htitle, $htmlBgColor, $htmlBody, $HtmTime1, $HtmTime2, $HtmTime3, $HtopAxes, $Htournament, $HtournamentmonsId, $hturn, $HugMax, $Hugmode, $HunitTime, $Hurlownermode, $imageDir, $lockMode, $toppage, $versionInfo;
	if($lockMode == 1) {
		// directory식 락
		rmdir('hakojimalock');
	} elseif($lockMode == 2) {
		// flock식 락
		hako_close('LOCKID');
	} elseif($lockMode == 3) {
		// symlink식 락
		unlink('hakojimalock');
	} elseif($lockMode == 4) {
		// 통상 파일식 락
		$i = null;
		$i = rename('lockfile.lock', 'lockfile');
	} else {
		// rename식 락
		rename($lfh['current'], $lfh['path']);
	}
}

// 작은 (분)편을 돌려준다
function hako_min() {
  $_args = func_get_args();
  extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $Halistmode, $Hallyflg, $Hasync, $HbaseDir, $HbfieldMode, $HcomDoNothing, $HcomL, $HcommandArg, $HcommandComary, $HcommandKind, $HcommandMax, $HcommandMode, $HcommandPlanNumber, $HcommandTarget, $HcommandTX, $HcommandTY, $HcommandX, $HcommandY, $HcommentLabel0, $HcommentLabel1, $HcommentLabel2, $HcommentLabel3, $HcommentLabel4, $HcssFile, $HcurrentID, $HcurrentName, $HcurrentOwnerName, $Hcustom, $Hdebug, $HdebugMode, $HdefaultKind, $HdefaultName, $HdefaultPassword, $HdefaultTX, $HdefaultTY, $HdefaultX, $HdefaultY, $HdirMode, $helpDir, $HerrorNum, $HexchangeBidID, $HexchangeBuy, $HexchangeBuyCost, $HexchangeCon, $HexchangeDelID, $HexchangeMode, $HexchangeSell, $HexchangeSellCost, $HflexTime, $HflexTimeSet, $HforeignerID, $Hically, $Hicevil, $Hicfood, $HichangeMode, $Hicmoney, $Hicspace, $Hicweapon, $HidToName, $HidToNumber, $HimageDir, $HimgLine, $HinputPassword, $HinputPassword2, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNextID, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HjavaMode, $HjavaModeSet, $HjumpURL, $HlandBase, $HlandDokan, $HlandEarth, $HlandOcean, $HlandOPlayer, $HlandSea, $HlandSpaceBase, $HlastTurn, $HlbbsMax, $HlbbsMessage, $HlbbsMode, $HlbbsMode2, $HlbbsName, $HlbbsType, $HlchangeKIND, $HlchangeMode, $HlchangeVALUE, $Hlinkcheck, $HlistID, $HmainMode, $HmasterPassword, $Hmessage, $Hmonsname, $HmonsterName, $Hmonsurl, $Hmyship, $HmyshipFlg, $Hocean, $HoceanSize, $HokURL, $HoldPassword, $HomeImage, $hour, $hp, $HpasswordFile, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $HpreDeleteID, $HpreDeleteMode, $HpresentFood, $HpresentLog, $HpresentMode, $HpresentMoney, $HprintID, $Hprofile, $HprofileDir, $HpunishID, $HpunishMode, $HretryCount, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $Hrsswrite, $HseaChk, $HskinName, $Hspace, $HspaceID, $Hspacemap, $HspecialPassword, $HtempBack, $HthisFile, $Htitle, $htmlBgColor, $htmlBody, $HtmTime1, $HtmTime2, $HtmTime3, $HtopAxes, $Htournament, $HtournamentmonsId, $hturn, $HugMax, $Hugmode, $HunitTime, $Hurlownermode, $imageDir, $lockMode, $toppage, $versionInfo;
	return ($_args[0] < $_args[1]) ? $_args[0] : $_args[1];
}

// 1000억 단위 둥근 루틴
function aboutMoney($m) {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $Halistmode, $Hallyflg, $Hasync, $HbaseDir, $HbfieldMode, $HcomDoNothing, $HcomL, $HcommandArg, $HcommandComary, $HcommandKind, $HcommandMax, $HcommandMode, $HcommandPlanNumber, $HcommandTarget, $HcommandTX, $HcommandTY, $HcommandX, $HcommandY, $HcommentLabel0, $HcommentLabel1, $HcommentLabel2, $HcommentLabel3, $HcommentLabel4, $HcssFile, $HcurrentID, $HcurrentName, $HcurrentOwnerName, $Hcustom, $Hdebug, $HdebugMode, $HdefaultKind, $HdefaultName, $HdefaultPassword, $HdefaultTX, $HdefaultTY, $HdefaultX, $HdefaultY, $HdirMode, $helpDir, $HerrorNum, $HexchangeBidID, $HexchangeBuy, $HexchangeBuyCost, $HexchangeCon, $HexchangeDelID, $HexchangeMode, $HexchangeSell, $HexchangeSellCost, $HflexTime, $HflexTimeSet, $HforeignerID, $Hically, $Hicevil, $Hicfood, $HichangeMode, $Hicmoney, $Hicspace, $Hicweapon, $HidToName, $HidToNumber, $HimageDir, $HimgLine, $HinputPassword, $HinputPassword2, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNextID, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HjavaMode, $HjavaModeSet, $HjumpURL, $HlandBase, $HlandDokan, $HlandEarth, $HlandOcean, $HlandOPlayer, $HlandSea, $HlandSpaceBase, $HlastTurn, $HlbbsMax, $HlbbsMessage, $HlbbsMode, $HlbbsMode2, $HlbbsName, $HlbbsType, $HlchangeKIND, $HlchangeMode, $HlchangeVALUE, $Hlinkcheck, $HlistID, $HmainMode, $HmasterPassword, $Hmessage, $Hmonsname, $HmonsterName, $Hmonsurl, $Hmyship, $HmyshipFlg, $Hocean, $HoceanSize, $HokURL, $HoldPassword, $HomeImage, $hour, $hp, $HpasswordFile, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $HpreDeleteID, $HpreDeleteMode, $HpresentFood, $HpresentLog, $HpresentMode, $HpresentMoney, $HprintID, $Hprofile, $HprofileDir, $HpunishID, $HpunishMode, $HretryCount, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $Hrsswrite, $HseaChk, $HskinName, $Hspace, $HspaceID, $Hspacemap, $HspecialPassword, $HtempBack, $HthisFile, $Htitle, $htmlBgColor, $htmlBody, $HtmTime1, $HtmTime2, $HtmTime3, $HtopAxes, $Htournament, $HtournamentmonsId, $hturn, $HugMax, $Hugmode, $HunitTime, $Hurlownermode, $imageDir, $lockMode, $toppage, $versionInfo;
	if($m < 500) {
		return "예상 500{$HunitMoney}미만";
	} else {
		$m = intval(($m + 500) / 1000);
		return "예상 {$m}000{$HunitMoney}";
	}
}

// 잘라 가지런히 하고
function cutColumn($s, $c) {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $Halistmode, $Hallyflg, $Hasync, $HbaseDir, $HbfieldMode, $HcomDoNothing, $HcomL, $HcommandArg, $HcommandComary, $HcommandKind, $HcommandMax, $HcommandMode, $HcommandPlanNumber, $HcommandTarget, $HcommandTX, $HcommandTY, $HcommandX, $HcommandY, $HcommentLabel0, $HcommentLabel1, $HcommentLabel2, $HcommentLabel3, $HcommentLabel4, $HcssFile, $HcurrentID, $HcurrentName, $HcurrentOwnerName, $Hcustom, $Hdebug, $HdebugMode, $HdefaultKind, $HdefaultName, $HdefaultPassword, $HdefaultTX, $HdefaultTY, $HdefaultX, $HdefaultY, $HdirMode, $helpDir, $HerrorNum, $HexchangeBidID, $HexchangeBuy, $HexchangeBuyCost, $HexchangeCon, $HexchangeDelID, $HexchangeMode, $HexchangeSell, $HexchangeSellCost, $HflexTime, $HflexTimeSet, $HforeignerID, $Hically, $Hicevil, $Hicfood, $HichangeMode, $Hicmoney, $Hicspace, $Hicweapon, $HidToName, $HidToNumber, $HimageDir, $HimgLine, $HinputPassword, $HinputPassword2, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNextID, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HjavaMode, $HjavaModeSet, $HjumpURL, $HlandBase, $HlandDokan, $HlandEarth, $HlandOcean, $HlandOPlayer, $HlandSea, $HlandSpaceBase, $HlastTurn, $HlbbsMax, $HlbbsMessage, $HlbbsMode, $HlbbsMode2, $HlbbsName, $HlbbsType, $HlchangeKIND, $HlchangeMode, $HlchangeVALUE, $Hlinkcheck, $HlistID, $HmainMode, $HmasterPassword, $Hmessage, $Hmonsname, $HmonsterName, $Hmonsurl, $Hmyship, $HmyshipFlg, $Hocean, $HoceanSize, $HokURL, $HoldPassword, $HomeImage, $hour, $hp, $HpasswordFile, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $HpreDeleteID, $HpreDeleteMode, $HpresentFood, $HpresentLog, $HpresentMode, $HpresentMoney, $HprintID, $Hprofile, $HprofileDir, $HpunishID, $HpunishMode, $HretryCount, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $Hrsswrite, $HseaChk, $HskinName, $Hspace, $HspaceID, $Hspacemap, $HspecialPassword, $HtempBack, $HthisFile, $Htitle, $htmlBgColor, $htmlBody, $HtmTime1, $HtmTime2, $HtmTime3, $HtopAxes, $Htournament, $HtournamentmonsId, $hturn, $HugMax, $Hugmode, $HunitTime, $Hurlownermode, $imageDir, $lockMode, $toppage, $versionInfo;
	if(strlen($s) <= $c) {
		return $s;
	} else {
		// 합계$c자릿수가 될 때까지 절취
		$ss = '';
		$count = 0;
		while($count < $c) {
			$s = preg_replace('/(^[\x80-\xFF][\x80-\xFF])|(^[\x00-\x7F])/', '', $s, 1);
			if($_m[1]) {
				$ss .= $_m[1];
				$count ++;
			} else {
				$ss .= $_m[2];
			}
			$count ++;
		}
		return $ss;
	}
}

// 도의 이름으로부터 번호를 얻는다(ID가 아니고 번호)
function nameToNumber() {
  $_args = func_get_args();
  extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $Halistmode, $Hallyflg, $Hasync, $HbaseDir, $HbfieldMode, $HcomDoNothing, $HcomL, $HcommandArg, $HcommandComary, $HcommandKind, $HcommandMax, $HcommandMode, $HcommandPlanNumber, $HcommandTarget, $HcommandTX, $HcommandTY, $HcommandX, $HcommandY, $HcommentLabel0, $HcommentLabel1, $HcommentLabel2, $HcommentLabel3, $HcommentLabel4, $HcssFile, $HcurrentID, $HcurrentName, $HcurrentOwnerName, $Hcustom, $Hdebug, $HdebugMode, $HdefaultKind, $HdefaultName, $HdefaultPassword, $HdefaultTX, $HdefaultTY, $HdefaultX, $HdefaultY, $HdirMode, $helpDir, $HerrorNum, $HexchangeBidID, $HexchangeBuy, $HexchangeBuyCost, $HexchangeCon, $HexchangeDelID, $HexchangeMode, $HexchangeSell, $HexchangeSellCost, $HflexTime, $HflexTimeSet, $HforeignerID, $Hically, $Hicevil, $Hicfood, $HichangeMode, $Hicmoney, $Hicspace, $Hicweapon, $HidToName, $HidToNumber, $HimageDir, $HimgLine, $HinputPassword, $HinputPassword2, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNextID, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HjavaMode, $HjavaModeSet, $HjumpURL, $HlandBase, $HlandDokan, $HlandEarth, $HlandOcean, $HlandOPlayer, $HlandSea, $HlandSpaceBase, $HlastTurn, $HlbbsMax, $HlbbsMessage, $HlbbsMode, $HlbbsMode2, $HlbbsName, $HlbbsType, $HlchangeKIND, $HlchangeMode, $HlchangeVALUE, $Hlinkcheck, $HlistID, $HmainMode, $HmasterPassword, $Hmessage, $Hmonsname, $HmonsterName, $Hmonsurl, $Hmyship, $HmyshipFlg, $Hocean, $HoceanSize, $HokURL, $HoldPassword, $HomeImage, $hour, $hp, $HpasswordFile, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $HpreDeleteID, $HpreDeleteMode, $HpresentFood, $HpresentLog, $HpresentMode, $HpresentMoney, $HprintID, $Hprofile, $HprofileDir, $HpunishID, $HpunishMode, $HretryCount, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $Hrsswrite, $HseaChk, $HskinName, $Hspace, $HspaceID, $Hspacemap, $HspecialPassword, $HtempBack, $HthisFile, $Htitle, $htmlBgColor, $htmlBody, $HtmTime1, $HtmTime2, $HtmTime3, $HtopAxes, $Htournament, $HtournamentmonsId, $hturn, $HugMax, $Hugmode, $HunitTime, $Hurlownermode, $imageDir, $lockMode, $toppage, $versionInfo;
	// 도 전체로부터 찾는다
	$i = null;
	for($i = 0; $i < $HislandNumber; $i++) {
		if ($Hislands[$i]['name'] == $_args[0]) { return $i; }
	}
	return -1; # 발견되지 않았던 경우
}

// 괴수의 정보
function monsterSpec() {
  $_args = func_get_args();
  extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $Halistmode, $Hallyflg, $Hasync, $HbaseDir, $HbfieldMode, $HcomDoNothing, $HcomL, $HcommandArg, $HcommandComary, $HcommandKind, $HcommandMax, $HcommandMode, $HcommandPlanNumber, $HcommandTarget, $HcommandTX, $HcommandTY, $HcommandX, $HcommandY, $HcommentLabel0, $HcommentLabel1, $HcommentLabel2, $HcommentLabel3, $HcommentLabel4, $HcssFile, $HcurrentID, $HcurrentName, $HcurrentOwnerName, $Hcustom, $Hdebug, $HdebugMode, $HdefaultKind, $HdefaultName, $HdefaultPassword, $HdefaultTX, $HdefaultTY, $HdefaultX, $HdefaultY, $HdirMode, $helpDir, $HerrorNum, $HexchangeBidID, $HexchangeBuy, $HexchangeBuyCost, $HexchangeCon, $HexchangeDelID, $HexchangeMode, $HexchangeSell, $HexchangeSellCost, $HflexTime, $HflexTimeSet, $HforeignerID, $Hically, $Hicevil, $Hicfood, $HichangeMode, $Hicmoney, $Hicspace, $Hicweapon, $HidToName, $HidToNumber, $HimageDir, $HimgLine, $HinputPassword, $HinputPassword2, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNextID, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HjavaMode, $HjavaModeSet, $HjumpURL, $HlandBase, $HlandDokan, $HlandEarth, $HlandOcean, $HlandOPlayer, $HlandSea, $HlandSpaceBase, $HlastTurn, $HlbbsMax, $HlbbsMessage, $HlbbsMode, $HlbbsMode2, $HlbbsName, $HlbbsType, $HlchangeKIND, $HlchangeMode, $HlchangeVALUE, $Hlinkcheck, $HlistID, $HmainMode, $HmasterPassword, $Hmessage, $Hmonsname, $HmonsterName, $Hmonsurl, $Hmyship, $HmyshipFlg, $Hocean, $HoceanSize, $HokURL, $HoldPassword, $HomeImage, $hour, $hp, $HpasswordFile, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $HpreDeleteID, $HpreDeleteMode, $HpresentFood, $HpresentLog, $HpresentMode, $HpresentMoney, $HprintID, $Hprofile, $HprofileDir, $HpunishID, $HpunishMode, $HretryCount, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $Hrsswrite, $HseaChk, $HskinName, $Hspace, $HspaceID, $Hspacemap, $HspecialPassword, $HtempBack, $HthisFile, $Htitle, $htmlBgColor, $htmlBody, $HtmTime1, $HtmTime2, $HtmTime3, $HtopAxes, $Htournament, $HtournamentmonsId, $hturn, $HugMax, $Hugmode, $HunitTime, $Hurlownermode, $imageDir, $lockMode, $toppage, $versionInfo;
	$kind = intval($_args[0] / 100);
	// 종류, 이름, 체력
	return array($kind, $HmonsterName[$kind], $_args[0] - ($kind * 100));
}

// 거대 괴수의 정보
function bigMonsterSpec() {
  $_args = func_get_args();
  extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $Halistmode, $Hallyflg, $Hasync, $HbaseDir, $HbfieldMode, $HcomDoNothing, $HcomL, $HcommandArg, $HcommandComary, $HcommandKind, $HcommandMax, $HcommandMode, $HcommandPlanNumber, $HcommandTarget, $HcommandTX, $HcommandTY, $HcommandX, $HcommandY, $HcommentLabel0, $HcommentLabel1, $HcommentLabel2, $HcommentLabel3, $HcommentLabel4, $HcssFile, $HcurrentID, $HcurrentName, $HcurrentOwnerName, $Hcustom, $Hdebug, $HdebugMode, $HdefaultKind, $HdefaultName, $HdefaultPassword, $HdefaultTX, $HdefaultTY, $HdefaultX, $HdefaultY, $HdirMode, $helpDir, $HerrorNum, $HexchangeBidID, $HexchangeBuy, $HexchangeBuyCost, $HexchangeCon, $HexchangeDelID, $HexchangeMode, $HexchangeSell, $HexchangeSellCost, $HflexTime, $HflexTimeSet, $HforeignerID, $Hically, $Hicevil, $Hicfood, $HichangeMode, $Hicmoney, $Hicspace, $Hicweapon, $HidToName, $HidToNumber, $HimageDir, $HimgLine, $HinputPassword, $HinputPassword2, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNextID, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HjavaMode, $HjavaModeSet, $HjumpURL, $HlandBase, $HlandDokan, $HlandEarth, $HlandOcean, $HlandOPlayer, $HlandSea, $HlandSpaceBase, $HlastTurn, $HlbbsMax, $HlbbsMessage, $HlbbsMode, $HlbbsMode2, $HlbbsName, $HlbbsType, $HlchangeKIND, $HlchangeMode, $HlchangeVALUE, $Hlinkcheck, $HlistID, $HmainMode, $HmasterPassword, $Hmessage, $Hmonsname, $HmonsterName, $Hmonsurl, $Hmyship, $HmyshipFlg, $Hocean, $HoceanSize, $HokURL, $HoldPassword, $HomeImage, $hour, $hp, $HpasswordFile, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $HpreDeleteID, $HpreDeleteMode, $HpresentFood, $HpresentLog, $HpresentMode, $HpresentMoney, $HprintID, $Hprofile, $HprofileDir, $HpunishID, $HpunishMode, $HretryCount, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $Hrsswrite, $HseaChk, $HskinName, $Hspace, $HspaceID, $Hspacemap, $HspecialPassword, $HtempBack, $HthisFile, $Htitle, $htmlBgColor, $htmlBody, $HtmTime1, $HtmTime2, $HtmTime3, $HtopAxes, $Htournament, $HtournamentmonsId, $hturn, $HugMax, $Hugmode, $HunitTime, $Hurlownermode, $imageDir, $lockMode, $toppage, $versionInfo;
	$limit = intval($_args[0] / 10000);
	$d = $_args[0] - ($limit * 10000);
	$hp = intval($d / 100);
	$d = $d - ($hp * 100);
	$ld = intval($d / 10);
	// 제한 시간, HP, 지형, 위치
	return array($limit, $hp, $ld, $d - ($ld * 10));
}

// 배의 정보
function shipSpec() {
  $_args = func_get_args();
  extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $Halistmode, $Hallyflg, $Hasync, $HbaseDir, $HbfieldMode, $HcomDoNothing, $HcomL, $HcommandArg, $HcommandComary, $HcommandKind, $HcommandMax, $HcommandMode, $HcommandPlanNumber, $HcommandTarget, $HcommandTX, $HcommandTY, $HcommandX, $HcommandY, $HcommentLabel0, $HcommentLabel1, $HcommentLabel2, $HcommentLabel3, $HcommentLabel4, $HcssFile, $HcurrentID, $HcurrentName, $HcurrentOwnerName, $Hcustom, $Hdebug, $HdebugMode, $HdefaultKind, $HdefaultName, $HdefaultPassword, $HdefaultTX, $HdefaultTY, $HdefaultX, $HdefaultY, $HdirMode, $helpDir, $HerrorNum, $HexchangeBidID, $HexchangeBuy, $HexchangeBuyCost, $HexchangeCon, $HexchangeDelID, $HexchangeMode, $HexchangeSell, $HexchangeSellCost, $HflexTime, $HflexTimeSet, $HforeignerID, $Hically, $Hicevil, $Hicfood, $HichangeMode, $Hicmoney, $Hicspace, $Hicweapon, $HidToName, $HidToNumber, $HimageDir, $HimgLine, $HinputPassword, $HinputPassword2, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNextID, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HjavaMode, $HjavaModeSet, $HjumpURL, $HlandBase, $HlandDokan, $HlandEarth, $HlandOcean, $HlandOPlayer, $HlandSea, $HlandSpaceBase, $HlastTurn, $HlbbsMax, $HlbbsMessage, $HlbbsMode, $HlbbsMode2, $HlbbsName, $HlbbsType, $HlchangeKIND, $HlchangeMode, $HlchangeVALUE, $Hlinkcheck, $HlistID, $HmainMode, $HmasterPassword, $Hmessage, $Hmonsname, $HmonsterName, $Hmonsurl, $Hmyship, $HmyshipFlg, $Hocean, $HoceanSize, $HokURL, $HoldPassword, $HomeImage, $hour, $hp, $HpasswordFile, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $HpreDeleteID, $HpreDeleteMode, $HpresentFood, $HpresentLog, $HpresentMode, $HpresentMoney, $HprintID, $Hprofile, $HprofileDir, $HpunishID, $HpunishMode, $HretryCount, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $Hrsswrite, $HseaChk, $HskinName, $Hspace, $HspaceID, $Hspacemap, $HspecialPassword, $HtempBack, $HthisFile, $Htitle, $htmlBgColor, $htmlBody, $HtmTime1, $HtmTime2, $HtmTime3, $HtopAxes, $Htournament, $HtournamentmonsId, $hturn, $HugMax, $Hugmode, $HunitTime, $Hurlownermode, $imageDir, $lockMode, $toppage, $versionInfo;
	$order = intval($_args[0] / 10000);
	$lv2 = $_args[0] - ($order * 10000);
	$hp = intval($lv2 / 1000);
	// 지령, 내구력, ID
	return array($order, $hp, $lv2 - ($hp * 1000));
}

// 기후의 정보
function weatherinfo($lv) {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $Halistmode, $Hallyflg, $Hasync, $HbaseDir, $HbfieldMode, $HcomDoNothing, $HcomL, $HcommandArg, $HcommandComary, $HcommandKind, $HcommandMax, $HcommandMode, $HcommandPlanNumber, $HcommandTarget, $HcommandTX, $HcommandTY, $HcommandX, $HcommandY, $HcommentLabel0, $HcommentLabel1, $HcommentLabel2, $HcommentLabel3, $HcommentLabel4, $HcssFile, $HcurrentID, $HcurrentName, $HcurrentOwnerName, $Hcustom, $Hdebug, $HdebugMode, $HdefaultKind, $HdefaultName, $HdefaultPassword, $HdefaultTX, $HdefaultTY, $HdefaultX, $HdefaultY, $HdirMode, $helpDir, $HerrorNum, $HexchangeBidID, $HexchangeBuy, $HexchangeBuyCost, $HexchangeCon, $HexchangeDelID, $HexchangeMode, $HexchangeSell, $HexchangeSellCost, $HflexTime, $HflexTimeSet, $HforeignerID, $Hically, $Hicevil, $Hicfood, $HichangeMode, $Hicmoney, $Hicspace, $Hicweapon, $HidToName, $HidToNumber, $HimageDir, $HimgLine, $HinputPassword, $HinputPassword2, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNextID, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HjavaMode, $HjavaModeSet, $HjumpURL, $HlandBase, $HlandDokan, $HlandEarth, $HlandOcean, $HlandOPlayer, $HlandSea, $HlandSpaceBase, $HlastTurn, $HlbbsMax, $HlbbsMessage, $HlbbsMode, $HlbbsMode2, $HlbbsName, $HlbbsType, $HlchangeKIND, $HlchangeMode, $HlchangeVALUE, $Hlinkcheck, $HlistID, $HmainMode, $HmasterPassword, $Hmessage, $Hmonsname, $HmonsterName, $Hmonsurl, $Hmyship, $HmyshipFlg, $Hocean, $HoceanSize, $HokURL, $HoldPassword, $HomeImage, $hour, $hp, $HpasswordFile, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $HpreDeleteID, $HpreDeleteMode, $HpresentFood, $HpresentLog, $HpresentMode, $HpresentMoney, $HprintID, $Hprofile, $HprofileDir, $HpunishID, $HpunishMode, $HretryCount, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $Hrsswrite, $HseaChk, $HskinName, $Hspace, $HspaceID, $Hspacemap, $HspecialPassword, $HtempBack, $HthisFile, $Htitle, $htmlBgColor, $htmlBody, $HtmTime1, $HtmTime2, $HtmTime3, $HtopAxes, $Htournament, $HtournamentmonsId, $hturn, $HugMax, $Hugmode, $HunitTime, $Hurlownermode, $imageDir, $lockMode, $toppage, $versionInfo;

	if ($lv > 5559) { $lv = 1114; }

	// 모레의 날씨
	$kind3 = intval($lv / 1000);
	if ($kind3 >= 6) { $kind3 = 1; }

	$lv2 = $lv - ($kind3 * 1000);

	// 내일의 날씨
	$kind2 = intval($lv2 / 100);
	if ($kind2 >= 6) { $kind2 = 1; }

	$lv3 = $lv2 - ($kind2 * 100);

	// 날씨
	$kind = intval($lv3 / 10);
	if ($kind >= 6) { $kind = 1; }

	$name = (isset($WeatherName[$kind]) ? $WeatherName[$kind] : '');# 이름
	$hp = $lv3 - ($kind * 10);# 지반 상태
	return array($kind, $name, $hp, $kind2, $kind3);
}

// 경험지로부터 레벨을 산출
function expToLevel($kind, $exp) {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $Halistmode, $Hallyflg, $Hasync, $HbaseDir, $HbfieldMode, $HcomDoNothing, $HcomL, $HcommandArg, $HcommandComary, $HcommandKind, $HcommandMax, $HcommandMode, $HcommandPlanNumber, $HcommandTarget, $HcommandTX, $HcommandTY, $HcommandX, $HcommandY, $HcommentLabel0, $HcommentLabel1, $HcommentLabel2, $HcommentLabel3, $HcommentLabel4, $HcssFile, $HcurrentID, $HcurrentName, $HcurrentOwnerName, $Hcustom, $Hdebug, $HdebugMode, $HdefaultKind, $HdefaultName, $HdefaultPassword, $HdefaultTX, $HdefaultTY, $HdefaultX, $HdefaultY, $HdirMode, $helpDir, $HerrorNum, $HexchangeBidID, $HexchangeBuy, $HexchangeBuyCost, $HexchangeCon, $HexchangeDelID, $HexchangeMode, $HexchangeSell, $HexchangeSellCost, $HflexTime, $HflexTimeSet, $HforeignerID, $Hically, $Hicevil, $Hicfood, $HichangeMode, $Hicmoney, $Hicspace, $Hicweapon, $HidToName, $HidToNumber, $HimageDir, $HimgLine, $HinputPassword, $HinputPassword2, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNextID, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HjavaMode, $HjavaModeSet, $HjumpURL, $HlandBase, $HlandDokan, $HlandEarth, $HlandOcean, $HlandOPlayer, $HlandSea, $HlandSpaceBase, $HlastTurn, $HlbbsMax, $HlbbsMessage, $HlbbsMode, $HlbbsMode2, $HlbbsName, $HlbbsType, $HlchangeKIND, $HlchangeMode, $HlchangeVALUE, $Hlinkcheck, $HlistID, $HmainMode, $HmasterPassword, $Hmessage, $Hmonsname, $HmonsterName, $Hmonsurl, $Hmyship, $HmyshipFlg, $Hocean, $HoceanSize, $HokURL, $HoldPassword, $HomeImage, $hour, $hp, $HpasswordFile, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $HpreDeleteID, $HpreDeleteMode, $HpresentFood, $HpresentLog, $HpresentMode, $HpresentMoney, $HprintID, $Hprofile, $HprofileDir, $HpunishID, $HpunishMode, $HretryCount, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $Hrsswrite, $HseaChk, $HskinName, $Hspace, $HspaceID, $Hspacemap, $HspecialPassword, $HtempBack, $HthisFile, $Htitle, $htmlBgColor, $htmlBody, $HtmTime1, $HtmTime2, $HtmTime3, $HtopAxes, $Htournament, $HtournamentmonsId, $hturn, $HugMax, $Hugmode, $HunitTime, $Hurlownermode, $imageDir, $lockMode, $toppage, $versionInfo;
	$i = null;
	if(($kind == $HlandBase) || ($kind == $HlandSpaceBase)) {
		// 미사일 기지
		for($i = $maxBaseLevel; $i > 1; $i--) {
			if ($exp >= $baseLevelUp[$i - 2]) { return $i; }
		}
	}elseif($kind == $HlandDokan){
		// 지하 입구
		return $exp % 100;
	}else{
		// 해저 기지 등
		for($i = $maxSBaseLevel; $i > 1; $i--) {
			if ($exp >= $sBaseLevelUp[$i - 2]) { return $i; }
		}
	}
	return 1;
}

// 주위의 바다계 지형의 수를 센다
function seaAround($land, $x, $y, $range, $mode) {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $Halistmode, $Hallyflg, $Hasync, $HbaseDir, $HbfieldMode, $HcomDoNothing, $HcomL, $HcommandArg, $HcommandComary, $HcommandKind, $HcommandMax, $HcommandMode, $HcommandPlanNumber, $HcommandTarget, $HcommandTX, $HcommandTY, $HcommandX, $HcommandY, $HcommentLabel0, $HcommentLabel1, $HcommentLabel2, $HcommentLabel3, $HcommentLabel4, $HcssFile, $HcurrentID, $HcurrentName, $HcurrentOwnerName, $Hcustom, $Hdebug, $HdebugMode, $HdefaultKind, $HdefaultName, $HdefaultPassword, $HdefaultTX, $HdefaultTY, $HdefaultX, $HdefaultY, $HdirMode, $helpDir, $HerrorNum, $HexchangeBidID, $HexchangeBuy, $HexchangeBuyCost, $HexchangeCon, $HexchangeDelID, $HexchangeMode, $HexchangeSell, $HexchangeSellCost, $HflexTime, $HflexTimeSet, $HforeignerID, $Hically, $Hicevil, $Hicfood, $HichangeMode, $Hicmoney, $Hicspace, $Hicweapon, $HidToName, $HidToNumber, $HimageDir, $HimgLine, $HinputPassword, $HinputPassword2, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNextID, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HjavaMode, $HjavaModeSet, $HjumpURL, $HlandBase, $HlandDokan, $HlandEarth, $HlandOcean, $HlandOPlayer, $HlandSea, $HlandSpaceBase, $HlastTurn, $HlbbsMax, $HlbbsMessage, $HlbbsMode, $HlbbsMode2, $HlbbsName, $HlbbsType, $HlchangeKIND, $HlchangeMode, $HlchangeVALUE, $Hlinkcheck, $HlistID, $HmainMode, $HmasterPassword, $Hmessage, $Hmonsname, $HmonsterName, $Hmonsurl, $Hmyship, $HmyshipFlg, $Hocean, $HoceanSize, $HokURL, $HoldPassword, $HomeImage, $hour, $hp, $HpasswordFile, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $HpreDeleteID, $HpreDeleteMode, $HpresentFood, $HpresentLog, $HpresentMode, $HpresentMoney, $HprintID, $Hprofile, $HprofileDir, $HpunishID, $HpunishMode, $HretryCount, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $Hrsswrite, $HseaChk, $HskinName, $Hspace, $HspaceID, $Hspacemap, $HspecialPassword, $HtempBack, $HthisFile, $Htitle, $htmlBgColor, $htmlBody, $HtmTime1, $HtmTime2, $HtmTime3, $HtopAxes, $Htournament, $HtournamentmonsId, $hturn, $HugMax, $Hugmode, $HunitTime, $Hurlownermode, $imageDir, $lockMode, $toppage, $versionInfo;
	$i = null; $count = null; $sx = null; $sy = null;
	$count = 0;
	for($i = 0; $i < $range; $i++) {
		$sx = $x + $ax[$i];
		$sy = $y + $ay[$i];
		
		// 행에 의한 위치 조정
		if (!($sy % 2) && ($y % 2)) { $sx--; }
		
		if(($sx < 0) || ($sx >= $HislandSize) || ($sy < 0) || ($sy >= $HislandSize)) {
			// 범위외의 경우
			$count++;
		} elseif(($HseaChk[$land[$sx][$sy]] == 3) && ($mode)){
			// 방파제는 제외하다
continue;
		} elseif($HseaChk[$land[$sx][$sy]]) {
			// 바다계 지형의 경우
			$count++;
		}
	}
	return $count;
}

// (0,0)(으)로부터(size - 1, size - 1)까지의 숫자가 1회씩 나오도록(듯이)
// (@Hrpx, @Hrpy)(을)를 설정
function makeRandomPointArray() {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $Halistmode, $Hallyflg, $Hasync, $HbaseDir, $HbfieldMode, $HcomDoNothing, $HcomL, $HcommandArg, $HcommandComary, $HcommandKind, $HcommandMax, $HcommandMode, $HcommandPlanNumber, $HcommandTarget, $HcommandTX, $HcommandTY, $HcommandX, $HcommandY, $HcommentLabel0, $HcommentLabel1, $HcommentLabel2, $HcommentLabel3, $HcommentLabel4, $HcssFile, $HcurrentID, $HcurrentName, $HcurrentOwnerName, $Hcustom, $Hdebug, $HdebugMode, $HdefaultKind, $HdefaultName, $HdefaultPassword, $HdefaultTX, $HdefaultTY, $HdefaultX, $HdefaultY, $HdirMode, $helpDir, $HerrorNum, $HexchangeBidID, $HexchangeBuy, $HexchangeBuyCost, $HexchangeCon, $HexchangeDelID, $HexchangeMode, $HexchangeSell, $HexchangeSellCost, $HflexTime, $HflexTimeSet, $HforeignerID, $Hically, $Hicevil, $Hicfood, $HichangeMode, $Hicmoney, $Hicspace, $Hicweapon, $HidToName, $HidToNumber, $HimageDir, $HimgLine, $HinputPassword, $HinputPassword2, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNextID, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HjavaMode, $HjavaModeSet, $HjumpURL, $HlandBase, $HlandDokan, $HlandEarth, $HlandOcean, $HlandOPlayer, $HlandSea, $HlandSpaceBase, $HlastTurn, $HlbbsMax, $HlbbsMessage, $HlbbsMode, $HlbbsMode2, $HlbbsName, $HlbbsType, $HlchangeKIND, $HlchangeMode, $HlchangeVALUE, $Hlinkcheck, $HlistID, $HmainMode, $HmasterPassword, $Hmessage, $Hmonsname, $HmonsterName, $Hmonsurl, $Hmyship, $HmyshipFlg, $Hocean, $HoceanSize, $HokURL, $HoldPassword, $HomeImage, $hour, $hp, $HpasswordFile, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $HpreDeleteID, $HpreDeleteMode, $HpresentFood, $HpresentLog, $HpresentMode, $HpresentMoney, $HprintID, $Hprofile, $HprofileDir, $HpunishID, $HpunishMode, $HretryCount, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $Hrsswrite, $HseaChk, $HskinName, $Hspace, $HspaceID, $Hspacemap, $HspecialPassword, $HtempBack, $HthisFile, $Htitle, $htmlBgColor, $htmlBody, $HtmTime1, $HtmTime2, $HtmTime3, $HtopAxes, $Htournament, $HtournamentmonsId, $hturn, $HugMax, $Hugmode, $HunitTime, $Hurlownermode, $imageDir, $lockMode, $toppage, $versionInfo;
	// 초기치
	$y = null; $i = null; $j = null; $Hrpy = array();
	$Hrpx = array(); for ($_ri = 0; $_ri < $HislandSize; $_ri++) { $Hrpx = array_merge($Hrpx, range(0, $HislandSize-1)); }
	for($y = 0; $y < $HislandSize; $y++) {
		for ($_ri = 0; $_ri < $HislandSize; $_ri++) { array_push($Hrpy, $y); }
	}

	// 상훌
	for ($i = $HpointNumber; --$i; ) {
		$j = mt_rand(0, $i);
		if ($i == $j) { continue; }
		$_tmp = $Hrpx[$i]; $Hrpx[$i] = $Hrpx[$j]; $Hrpx[$j] = $_tmp;
		$_tmp = $Hrpy[$i]; $Hrpy[$i] = $Hrpy[$j]; $Hrpy[$j] = $_tmp;
	}
}
function makeRandomOceanPointArray() {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $Halistmode, $Hallyflg, $Hasync, $HbaseDir, $HbfieldMode, $HcomDoNothing, $HcomL, $HcommandArg, $HcommandComary, $HcommandKind, $HcommandMax, $HcommandMode, $HcommandPlanNumber, $HcommandTarget, $HcommandTX, $HcommandTY, $HcommandX, $HcommandY, $HcommentLabel0, $HcommentLabel1, $HcommentLabel2, $HcommentLabel3, $HcommentLabel4, $HcssFile, $HcurrentID, $HcurrentName, $HcurrentOwnerName, $Hcustom, $Hdebug, $HdebugMode, $HdefaultKind, $HdefaultName, $HdefaultPassword, $HdefaultTX, $HdefaultTY, $HdefaultX, $HdefaultY, $HdirMode, $helpDir, $HerrorNum, $HexchangeBidID, $HexchangeBuy, $HexchangeBuyCost, $HexchangeCon, $HexchangeDelID, $HexchangeMode, $HexchangeSell, $HexchangeSellCost, $HflexTime, $HflexTimeSet, $HforeignerID, $Hically, $Hicevil, $Hicfood, $HichangeMode, $Hicmoney, $Hicspace, $Hicweapon, $HidToName, $HidToNumber, $HimageDir, $HimgLine, $HinputPassword, $HinputPassword2, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNextID, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HjavaMode, $HjavaModeSet, $HjumpURL, $HlandBase, $HlandDokan, $HlandEarth, $HlandOcean, $HlandOPlayer, $HlandSea, $HlandSpaceBase, $HlastTurn, $HlbbsMax, $HlbbsMessage, $HlbbsMode, $HlbbsMode2, $HlbbsName, $HlbbsType, $HlchangeKIND, $HlchangeMode, $HlchangeVALUE, $Hlinkcheck, $HlistID, $HmainMode, $HmasterPassword, $Hmessage, $Hmonsname, $HmonsterName, $Hmonsurl, $Hmyship, $HmyshipFlg, $Hocean, $HoceanSize, $HokURL, $HoldPassword, $HomeImage, $hour, $hp, $HpasswordFile, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $HpreDeleteID, $HpreDeleteMode, $HpresentFood, $HpresentLog, $HpresentMode, $HpresentMoney, $HprintID, $Hprofile, $HprofileDir, $HpunishID, $HpunishMode, $HretryCount, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $Hrsswrite, $HseaChk, $HskinName, $Hspace, $HspaceID, $Hspacemap, $HspecialPassword, $HtempBack, $HthisFile, $Htitle, $htmlBgColor, $htmlBody, $HtmTime1, $HtmTime2, $HtmTime3, $HtopAxes, $Htournament, $HtournamentmonsId, $hturn, $HugMax, $Hugmode, $HunitTime, $Hurlownermode, $imageDir, $lockMode, $toppage, $versionInfo;
	// 초기치
	$y = null; $i = null; $j = null; $HrpyO = array();
	$HrpxO = array(); for ($_ri = 0; $_ri < $HoceanSize; $_ri++) { $HrpxO = array_merge($HrpxO, range(0, $HoceanSize-1)); }
	for($y = 0; $y < $HoceanSize; $y++) {
		for ($_ri = 0; $_ri < $HoceanSize; $_ri++) { array_push($HrpyO, $y); }
	}
	// 상훌
	for ($i = $HpointOcean; --$i; ) {
		$j = mt_rand(0, $i);
		if ($i == $j) { continue; }
		$_tmp = $HrpxO[$i]; $HrpxO[$i] = $HrpxO[$j]; $HrpxO[$j] = $_tmp;
		$_tmp = $HrpyO[$i]; $HrpyO[$i] = $HrpyO[$j]; $HrpyO[$j] = $_tmp;
	}
}

// 0으로부터(n - 1)의 난수
function random() {
  $_args = func_get_args();
  extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $Halistmode, $Hallyflg, $Hasync, $HbaseDir, $HbfieldMode, $HcomDoNothing, $HcomL, $HcommandArg, $HcommandComary, $HcommandKind, $HcommandMax, $HcommandMode, $HcommandPlanNumber, $HcommandTarget, $HcommandTX, $HcommandTY, $HcommandX, $HcommandY, $HcommentLabel0, $HcommentLabel1, $HcommentLabel2, $HcommentLabel3, $HcommentLabel4, $HcssFile, $HcurrentID, $HcurrentName, $HcurrentOwnerName, $Hcustom, $Hdebug, $HdebugMode, $HdefaultKind, $HdefaultName, $HdefaultPassword, $HdefaultTX, $HdefaultTY, $HdefaultX, $HdefaultY, $HdirMode, $helpDir, $HerrorNum, $HexchangeBidID, $HexchangeBuy, $HexchangeBuyCost, $HexchangeCon, $HexchangeDelID, $HexchangeMode, $HexchangeSell, $HexchangeSellCost, $HflexTime, $HflexTimeSet, $HforeignerID, $Hically, $Hicevil, $Hicfood, $HichangeMode, $Hicmoney, $Hicspace, $Hicweapon, $HidToName, $HidToNumber, $HimageDir, $HimgLine, $HinputPassword, $HinputPassword2, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNextID, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HjavaMode, $HjavaModeSet, $HjumpURL, $HlandBase, $HlandDokan, $HlandEarth, $HlandOcean, $HlandOPlayer, $HlandSea, $HlandSpaceBase, $HlastTurn, $HlbbsMax, $HlbbsMessage, $HlbbsMode, $HlbbsMode2, $HlbbsName, $HlbbsType, $HlchangeKIND, $HlchangeMode, $HlchangeVALUE, $Hlinkcheck, $HlistID, $HmainMode, $HmasterPassword, $Hmessage, $Hmonsname, $HmonsterName, $Hmonsurl, $Hmyship, $HmyshipFlg, $Hocean, $HoceanSize, $HokURL, $HoldPassword, $HomeImage, $hour, $hp, $HpasswordFile, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $HpreDeleteID, $HpreDeleteMode, $HpresentFood, $HpresentLog, $HpresentMode, $HpresentMoney, $HprintID, $Hprofile, $HprofileDir, $HpunishID, $HpunishMode, $HretryCount, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $Hrsswrite, $HseaChk, $HskinName, $Hspace, $HspaceID, $Hspacemap, $HspecialPassword, $HtempBack, $HthisFile, $Htitle, $htmlBgColor, $htmlBody, $HtmTime1, $HtmTime2, $HtmTime3, $HtopAxes, $Htournament, $HtournamentmonsId, $hturn, $HugMax, $Hugmode, $HunitTime, $Hurlownermode, $imageDir, $lockMode, $toppage, $versionInfo;
	$limit = isset($_args[0]) ? intval($_args[0]) : 0;
	return ($limit > 0) ? mt_rand(0, $limit - 1) : 0;
}

//해역의 정비
function OceanMente($id) {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $Halistmode, $Hallyflg, $Hasync, $HbaseDir, $HbfieldMode, $HcomDoNothing, $HcomL, $HcommandArg, $HcommandComary, $HcommandKind, $HcommandMax, $HcommandMode, $HcommandPlanNumber, $HcommandTarget, $HcommandTX, $HcommandTY, $HcommandX, $HcommandY, $HcommentLabel0, $HcommentLabel1, $HcommentLabel2, $HcommentLabel3, $HcommentLabel4, $HcssFile, $HcurrentID, $HcurrentName, $HcurrentOwnerName, $Hcustom, $Hdebug, $HdebugMode, $HdefaultKind, $HdefaultName, $HdefaultPassword, $HdefaultTX, $HdefaultTY, $HdefaultX, $HdefaultY, $HdirMode, $helpDir, $HerrorNum, $HexchangeBidID, $HexchangeBuy, $HexchangeBuyCost, $HexchangeCon, $HexchangeDelID, $HexchangeMode, $HexchangeSell, $HexchangeSellCost, $HflexTime, $HflexTimeSet, $HforeignerID, $Hically, $Hicevil, $Hicfood, $HichangeMode, $Hicmoney, $Hicspace, $Hicweapon, $HidToName, $HidToNumber, $HimageDir, $HimgLine, $HinputPassword, $HinputPassword2, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNextID, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HjavaMode, $HjavaModeSet, $HjumpURL, $HlandBase, $HlandDokan, $HlandEarth, $HlandOcean, $HlandOPlayer, $HlandSea, $HlandSpaceBase, $HlastTurn, $HlbbsMax, $HlbbsMessage, $HlbbsMode, $HlbbsMode2, $HlbbsName, $HlbbsType, $HlchangeKIND, $HlchangeMode, $HlchangeVALUE, $Hlinkcheck, $HlistID, $HmainMode, $HmasterPassword, $Hmessage, $Hmonsname, $HmonsterName, $Hmonsurl, $Hmyship, $HmyshipFlg, $Hocean, $HoceanSize, $HokURL, $HoldPassword, $HomeImage, $hour, $hp, $HpasswordFile, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $HpreDeleteID, $HpreDeleteMode, $HpresentFood, $HpresentLog, $HpresentMode, $HpresentMoney, $HprintID, $Hprofile, $HprofileDir, $HpunishID, $HpunishMode, $HretryCount, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $Hrsswrite, $HseaChk, $HskinName, $Hspace, $HspaceID, $Hspacemap, $HspecialPassword, $HtempBack, $HthisFile, $Htitle, $htmlBgColor, $htmlBody, $HtmTime1, $HtmTime2, $HtmTime3, $HtopAxes, $Htournament, $HtournamentmonsId, $hturn, $HugMax, $Hugmode, $HunitTime, $Hurlownermode, $imageDir, $lockMode, $toppage, $versionInfo;
	$x = null; $y = null; $i = null; $j = null;
	for($y = 0; $y < $HoceanSize; $y++) {
		for($x = 0; $x < $HoceanSize; $x++) {
			if($Hocean['nation'][$x][$y] == $id){
				if(($Hocean['land'][$x][$y] == $HlandOPlayer) ||
				   ($Hocean['land'][$x][$y] == $HlandOcean)){
					$Hocean['land'][$x][$y] = $HlandOcean;
				}else{
					$Hocean['land'][$x][$y] = $HlandSea;
				}
				$Hocean['landValue'][$x][$y] = 0;
				$Hocean['land2'][$x][$y] = 0;
				$Hocean['landValue2'][$x][$y] = 0;
				$Hocean['nation'][$x][$y] = 0;
			}
		}
	}
}

//----------------------------------------------------------------------
// 로그 표시
//----------------------------------------------------------------------
// 파일 번호 지정으로 로그 표시
function logFilePrint($fileNumber, $id, $mode) {
	global $HlogdirName, $HdirName, $HtagNumber_, $H_tagNumber;
	$paths = array();
	foreach (array($HlogdirName, $HdirName, '.', './logdata', './data') as $d) {
		if ($d === null || $d === '') { continue; }
		$paths[] = rtrim($d, '/') . '/hakojima.log' . intval($fileNumber);
	}
	$paths = array_values(array_unique($paths));
	$fp = false;
	foreach ($paths as $path) {
		if (file_exists($path) && is_readable($path)) { $fp = @fopen($path, 'r'); break; }
	}
	if (!$fp) { return; }
	$set_turn = 0;
	while (($line = fgets($fp)) !== false) {
		$line = rtrim($line, "\r\n");
		if ($line === '') { continue; }
		if (!preg_match('/^([0-9]*),([0-9]*),([0-9]*),([0-9]*),(.*)$/', $line, $m)) { continue; }
		$secret = $m[1]; $turn = $m[2]; $id1 = $m[3]; $id2 = $m[4]; $message = $m[5];
		$prefix = '';
		if ($secret == 1) {
			if (($mode == 0) || ($id1 != $id)) { continue; }
			$prefix = "{$HtagNumber_}<B> (기밀) </B>{$H_tagNumber}:";
		}
		if ($id != 0) {
			if (($id != $id1) && ($id != $id2)) { continue; }
		}
		if ($set_turn == 0) {
			out("<NOBR><B>=====[<span class=number><FONT SIZE=4> 턴 $turn </FONT></span>]================================================</B><NOBR><BR>\n");
			$set_turn = 1;
		}
		out("<NOBR>{$prefix}{$message}</NOBR><BR>\n");
	}
	fclose($fp);
}

//----------------------------------------------------------------------
// 프로파일로부터 정보 취득
//----------------------------------------------------------------------
//
// 프로파일을 읽어 지정된 도ID의 배경 이미지 URL를 돌려준다
function getBGImageUrl($bgimageid) {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $Halistmode, $Hallyflg, $Hasync, $HbaseDir, $HbfieldMode, $HcomDoNothing, $HcomL, $HcommandArg, $HcommandComary, $HcommandKind, $HcommandMax, $HcommandMode, $HcommandPlanNumber, $HcommandTarget, $HcommandTX, $HcommandTY, $HcommandX, $HcommandY, $HcommentLabel0, $HcommentLabel1, $HcommentLabel2, $HcommentLabel3, $HcommentLabel4, $HcssFile, $HcurrentID, $HcurrentName, $HcurrentOwnerName, $Hcustom, $Hdebug, $HdebugMode, $HdefaultKind, $HdefaultName, $HdefaultPassword, $HdefaultTX, $HdefaultTY, $HdefaultX, $HdefaultY, $HdirMode, $helpDir, $HerrorNum, $HexchangeBidID, $HexchangeBuy, $HexchangeBuyCost, $HexchangeCon, $HexchangeDelID, $HexchangeMode, $HexchangeSell, $HexchangeSellCost, $HflexTime, $HflexTimeSet, $HforeignerID, $Hically, $Hicevil, $Hicfood, $HichangeMode, $Hicmoney, $Hicspace, $Hicweapon, $HidToName, $HidToNumber, $HimageDir, $HimgLine, $HinputPassword, $HinputPassword2, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNextID, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HjavaMode, $HjavaModeSet, $HjumpURL, $HlandBase, $HlandDokan, $HlandEarth, $HlandOcean, $HlandOPlayer, $HlandSea, $HlandSpaceBase, $HlastTurn, $HlbbsMax, $HlbbsMessage, $HlbbsMode, $HlbbsMode2, $HlbbsName, $HlbbsType, $HlchangeKIND, $HlchangeMode, $HlchangeVALUE, $Hlinkcheck, $HlistID, $HmainMode, $HmasterPassword, $Hmessage, $Hmonsname, $HmonsterName, $Hmonsurl, $Hmyship, $HmyshipFlg, $Hocean, $HoceanSize, $HokURL, $HoldPassword, $HomeImage, $hour, $hp, $HpasswordFile, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $HpreDeleteID, $HpreDeleteMode, $HpresentFood, $HpresentLog, $HpresentMode, $HpresentMoney, $HprintID, $Hprofile, $HprofileDir, $HpunishID, $HpunishMode, $HretryCount, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $Hrsswrite, $HseaChk, $HskinName, $Hspace, $HspaceID, $Hspacemap, $HspecialPassword, $HtempBack, $HthisFile, $Htitle, $htmlBgColor, $htmlBody, $HtmTime1, $HtmTime2, $HtmTime3, $HtopAxes, $Htournament, $HtournamentmonsId, $hturn, $HugMax, $Hugmode, $HunitTime, $Hurlownermode, $imageDir, $lockMode, $toppage, $versionInfo;

	// 쿠키로부터 자신의 ID취득
	$bgcookie = null; $myId = null;
//	$bgcookie = jcode::euc($ENV{'HTTP_COOKIE'});
	$bgcookie = isset($_SERVER['HTTP_COOKIE']) ? $_SERVER['HTTP_COOKIE'] : '';
	if (preg_match('/OWNISLANDID=\(([^\)]*)\)/', $bgcookie, $_m)) {
		$myId = $_m[1];
		readProfileMAP($myId);
	}
	if(!is_array($Hprofile)) {
		$Hprofile = array('MyHomeImage' => '', 'BackgroundImage' => '', 'BackgroundUse' => '');
	}
	if(isset($Hprofile['BackgroundUse']) && $Hprofile['BackgroundUse'] == 2) {
		//  배경 이미지을 표시하지 않을 때
		return '';
	}
	if($myId == $bgimageid) {
		// 자신 도의 경우
		return isset($Hprofile['BackgroundImage']) ? $Hprofile['BackgroundImage'] : '';
	}
	
	readProfileMAP($bgimageid);
	return isset($Hprofile['BackgroundImage']) ? $Hprofile['BackgroundImage'] : '';
}

function readProfileMAP($proid) {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $Halistmode, $Hallyflg, $Hasync, $HbaseDir, $HbfieldMode, $HcomDoNothing, $HcomL, $HcommandArg, $HcommandComary, $HcommandKind, $HcommandMax, $HcommandMode, $HcommandPlanNumber, $HcommandTarget, $HcommandTX, $HcommandTY, $HcommandX, $HcommandY, $HcommentLabel0, $HcommentLabel1, $HcommentLabel2, $HcommentLabel3, $HcommentLabel4, $HcssFile, $HcurrentID, $HcurrentName, $HcurrentOwnerName, $Hcustom, $Hdebug, $HdebugMode, $HdefaultKind, $HdefaultName, $HdefaultPassword, $HdefaultTX, $HdefaultTY, $HdefaultX, $HdefaultY, $HdirMode, $helpDir, $HerrorNum, $HexchangeBidID, $HexchangeBuy, $HexchangeBuyCost, $HexchangeCon, $HexchangeDelID, $HexchangeMode, $HexchangeSell, $HexchangeSellCost, $HflexTime, $HflexTimeSet, $HforeignerID, $Hically, $Hicevil, $Hicfood, $HichangeMode, $Hicmoney, $Hicspace, $Hicweapon, $HidToName, $HidToNumber, $HimageDir, $HimgLine, $HinputPassword, $HinputPassword2, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNextID, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HjavaMode, $HjavaModeSet, $HjumpURL, $HlandBase, $HlandDokan, $HlandEarth, $HlandOcean, $HlandOPlayer, $HlandSea, $HlandSpaceBase, $HlastTurn, $HlbbsMax, $HlbbsMessage, $HlbbsMode, $HlbbsMode2, $HlbbsName, $HlbbsType, $HlchangeKIND, $HlchangeMode, $HlchangeVALUE, $Hlinkcheck, $HlistID, $HmainMode, $HmasterPassword, $Hmessage, $Hmonsname, $HmonsterName, $Hmonsurl, $Hmyship, $HmyshipFlg, $Hocean, $HoceanSize, $HokURL, $HoldPassword, $HomeImage, $hour, $hp, $HpasswordFile, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $HpreDeleteID, $HpreDeleteMode, $HpresentFood, $HpresentLog, $HpresentMode, $HpresentMoney, $HprintID, $Hprofile, $HprofileDir, $HpunishID, $HpunishMode, $HretryCount, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $Hrsswrite, $HseaChk, $HskinName, $Hspace, $HspaceID, $Hspacemap, $HspecialPassword, $HtempBack, $HthisFile, $Htitle, $htmlBgColor, $htmlBody, $HtmTime1, $HtmTime2, $HtmTime3, $HtopAxes, $Htournament, $HtournamentmonsId, $hturn, $HugMax, $Hugmode, $HunitTime, $Hurlownermode, $imageDir, $lockMode, $toppage, $versionInfo;
	if(!hako_open('PIN', "$HprofileDir/profile{$proid}.dat")){
		$Hprofile['MyHomeImage'] = '';
		$Hprofile['BackgroundImage'] = '';
		$Hprofile['BackgroundUse'] = '';
		return 0;
	}

	hako_getline('PIN');#lastModify
	hako_getline('PIN');#photo
	hako_getline('PIN');#address
	hako_getline('PIN');#age
	hako_getline('PIN');#sex
	hako_getline('PIN');#job
	hako_getline('PIN');#email
	hako_getline('PIN');#icq
	hako_getline('PIN');#webtitle
	hako_getline('PIN');#webaddr
	hako_getline('PIN');#comment
	hako_getline('PIN');#bestweb1
	hako_getline('PIN');#bestweb2
	hako_getline('PIN');#bestweb3
	
	$HomeImage = null; $BGImage = null; $BGImageUse = null;
	$HomeImage = hako_getline('PIN');
	$BGImage   = hako_getline('PIN');
	$BGImageUse = intval(hako_getline('PIN'));
	
	$HomeImage = rtrim($HomeImage);
	$BGImage = rtrim($BGImage);
	
	$Hprofile['MyHomeImage'] = $HomeImage;
	$Hprofile['BackgroundImage'] = $BGImage;
	$Hprofile['BackgroundUse'] = $BGImageUse;

	hako_close('PIN');
	return 1;
}

//----------------------------------------------------------------------
// 템플릿
//----------------------------------------------------------------------
// 헤더
function tempHeader($js = 0) {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $Halistmode, $Hallyflg, $Hasync, $HbaseDir, $HbfieldMode, $HcomDoNothing, $HcomL, $HcommandArg, $HcommandComary, $HcommandKind, $HcommandMax, $HcommandMode, $HcommandPlanNumber, $HcommandTarget, $HcommandTX, $HcommandTY, $HcommandX, $HcommandY, $HcommentLabel0, $HcommentLabel1, $HcommentLabel2, $HcommentLabel3, $HcommentLabel4, $HcssFile, $HcurrentID, $HcurrentName, $HcurrentOwnerName, $Hcustom, $Hdebug, $HdebugMode, $HdefaultKind, $HdefaultName, $HdefaultPassword, $HdefaultTX, $HdefaultTY, $HdefaultX, $HdefaultY, $HdirMode, $helpDir, $HerrorNum, $HexchangeBidID, $HexchangeBuy, $HexchangeBuyCost, $HexchangeCon, $HexchangeDelID, $HexchangeMode, $HexchangeSell, $HexchangeSellCost, $HflexTime, $HflexTimeSet, $HforeignerID, $Hically, $Hicevil, $Hicfood, $HichangeMode, $Hicmoney, $Hicspace, $Hicweapon, $HidToName, $HidToNumber, $HimageDir, $HimgLine, $HinputPassword, $HinputPassword2, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNextID, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HjavaMode, $HjavaModeSet, $HjumpURL, $HlandBase, $HlandDokan, $HlandEarth, $HlandOcean, $HlandOPlayer, $HlandSea, $HlandSpaceBase, $HlastTurn, $HlbbsMax, $HlbbsMessage, $HlbbsMode, $HlbbsMode2, $HlbbsName, $HlbbsType, $HlchangeKIND, $HlchangeMode, $HlchangeVALUE, $Hlinkcheck, $HlistID, $HmainMode, $HmasterPassword, $Hmessage, $Hmonsname, $HmonsterName, $Hmonsurl, $Hmyship, $HmyshipFlg, $Hocean, $HoceanSize, $HokURL, $HoldPassword, $HomeImage, $hour, $hp, $HpasswordFile, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $HpreDeleteID, $HpreDeleteMode, $HpresentFood, $HpresentLog, $HpresentMode, $HpresentMoney, $HprintID, $Hprofile, $HprofileDir, $HpunishID, $HpunishMode, $HretryCount, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $Hrsswrite, $HseaChk, $HskinName, $Hspace, $HspaceID, $Hspacemap, $HspecialPassword, $HtempBack, $HthisFile, $Htitle, $htmlBgColor, $htmlBody, $HtmTime1, $HtmTime2, $HtmTime3, $HtopAxes, $Htournament, $HtournamentmonsId, $hturn, $HugMax, $Hugmode, $HunitTime, $Hurlownermode, $imageDir, $lockMode, $toppage, $versionInfo;
	// 로컬 이미지 지정
	$baseIMG = ($HimgLine != '') ? $HimgLine : $imageDir;
	$baseSKIN = (is_string($HskinName) && $HskinName != '') ? "$imageDir/$HskinName" : "$imageDir/$HcssFile";
	if (!headers_sent()) { header('Content-Type: text/html; charset=UTF-8'); }
	if ($Hasync) { return; }
	out(<<<END
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html lang="kr">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<TITLE>$Htitle</TITLE>
<BASE HREF="$baseIMG/">
END
);
	if($js == 1){
		// js모드
		$Body = "<BODY>";
		$MyImage = getBGImageUrl($HcurrentID);
		if(substr($MyImage,0,7) == 'http://'){
			if (preg_match('/\.css$/', $MyImage, $_m)) {
				$baseSKIN = $MyImage;
			}else{
				$Body = "<BODY $htmlBgColor BACKGROUND={$MyImage}>";
			}
		}
	}else{
		if(($HmainMode == 'print') || ($HmainMode == 'command') ||
			($HmainMode == 'owner') || ($HmainMode == 'comment') || ($HmainMode == 'lbbs')) {
			// 도의 맵을 호출할 때
			$MyImage = getBGImageUrl($HcurrentID);
			if(substr($MyImage,0,7) == 'http://'){
				if (preg_match('/\.css$/', $MyImage, $_m)) {
					$Body = "<BODY>";
					$baseSKIN = $MyImage;
				}else{
					$Body = "<BODY $htmlBgColor BACKGROUND={$MyImage}>";
				}
			}
		}
	}
	out(<<<END
<link rel="stylesheet" type="text/css" href="$baseSKIN">
</HEAD>
$Body
<DIV ID='BodySpecial'><DIV ID='LinkHead'>
<A HREF="$HbaseDir/history.php?saikin=0" target="_blank"> 최근의 사건</A> /
<A HREF="$HbaseDir/ranking.php" target="_blank"> 랭킹</A> /
<A HREF="$HbaseDir/profile.php" target="_blank"> 프로파일</A> /
<A HREF="$helpDir" target="_blank">도움말</A> /
<A HREF="$bbs" target="_blank">게시판</A> /
<A HREF="$bbs2" target="_blank">게시판2</A> /
<A HREF="$toppage">홈페이지로</A> /
</DIV><HR>
END
);
}
// footer
function tempFooter() {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $Halistmode, $Hallyflg, $Hasync, $HbaseDir, $HbfieldMode, $HcomDoNothing, $HcomL, $HcommandArg, $HcommandComary, $HcommandKind, $HcommandMax, $HcommandMode, $HcommandPlanNumber, $HcommandTarget, $HcommandTX, $HcommandTY, $HcommandX, $HcommandY, $HcommentLabel0, $HcommentLabel1, $HcommentLabel2, $HcommentLabel3, $HcommentLabel4, $HcssFile, $HcurrentID, $HcurrentName, $HcurrentOwnerName, $Hcustom, $Hdebug, $HdebugMode, $HdefaultKind, $HdefaultName, $HdefaultPassword, $HdefaultTX, $HdefaultTY, $HdefaultX, $HdefaultY, $HdirMode, $helpDir, $HerrorNum, $HexchangeBidID, $HexchangeBuy, $HexchangeBuyCost, $HexchangeCon, $HexchangeDelID, $HexchangeMode, $HexchangeSell, $HexchangeSellCost, $HflexTime, $HflexTimeSet, $HforeignerID, $Hically, $Hicevil, $Hicfood, $HichangeMode, $Hicmoney, $Hicspace, $Hicweapon, $HidToName, $HidToNumber, $HimageDir, $HimgLine, $HinputPassword, $HinputPassword2, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNextID, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HjavaMode, $HjavaModeSet, $HjumpURL, $HlandBase, $HlandDokan, $HlandEarth, $HlandOcean, $HlandOPlayer, $HlandSea, $HlandSpaceBase, $HlastTurn, $HlbbsMax, $HlbbsMessage, $HlbbsMode, $HlbbsMode2, $HlbbsName, $HlbbsType, $HlchangeKIND, $HlchangeMode, $HlchangeVALUE, $Hlinkcheck, $HlistID, $HmainMode, $HmasterPassword, $Hmessage, $Hmonsname, $HmonsterName, $Hmonsurl, $Hmyship, $HmyshipFlg, $Hocean, $HoceanSize, $HokURL, $HoldPassword, $HomeImage, $hour, $hp, $HpasswordFile, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $HpreDeleteID, $HpreDeleteMode, $HpresentFood, $HpresentLog, $HpresentMode, $HpresentMoney, $HprintID, $Hprofile, $HprofileDir, $HpunishID, $HpunishMode, $HretryCount, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $Hrsswrite, $HseaChk, $HskinName, $Hspace, $HspaceID, $Hspacemap, $HspecialPassword, $HtempBack, $HthisFile, $Htitle, $htmlBgColor, $htmlBody, $HtmTime1, $HtmTime2, $HtmTime3, $HtopAxes, $Htournament, $HtournamentmonsId, $hturn, $HugMax, $Hugmode, $HunitTime, $Hurlownermode, $imageDir, $lockMode, $toppage, $versionInfo;
	out(<<<END
<HR>

<style type="text/css">
#LinkFoot table {
	border-collapse:collapse;
	background:#eaffff;
}

#LinkFoot td {
	border:1px solid #88aacc;
	padding:3px;
	text-align:center;
	font-size:10px;
}

/* 팝업 */
#copyrightView {
	display:none;
	position:fixed;
	left:50%;
	top:50%;
	width:460px;
	margin-left:-230px;
	margin-top:-120px;
	background:#eaffff;
	border:1px solid #88aacc;
	z-index:9999;
	padding:8px;
	box-shadow:0 0 8px #777;
}

#copyrightView table {
	border-collapse:collapse;
	width:100%;
}

#copyrightView td {
	border:1px solid #88aacc;
	padding:4px;
	text-align:center;
	font-size:12px;
}

#copyrightBg {
	display:none;
	position:fixed;
	left:0;
	top:0;
	width:100%;
	height:100%;
	background:#000;
	opacity:0.25;
	z-index:9998;
}

.closeBtn {
	text-align:right;
}
</style>

<script>
function openCopyright(){
	var box = document.getElementById('copyrightView');
	var imgs = box.getElementsByTagName('img');
	for (var i = 0; i < imgs.length; i++) {
		if (imgs[i].getAttribute('data-src') && imgs[i].getAttribute('data-loaded') != '1') {
			imgs[i].src = imgs[i].getAttribute('data-src');
			imgs[i].setAttribute('data-loaded', '1');
		}
	}
	document.getElementById('copyrightBg').style.display='block';
	box.style.display='block';
}
function closeCopyright(){
	document.getElementById('copyrightBg').style.display='none';
	document.getElementById('copyrightView').style.display='none';
}
</script>

<!-- 항상 보이는 테이블 -->
<div id="LinkFoot">
<table width="400" align="center">
<tr>
	<td colspan="2">
		구상의 모형정원 「모두 걷는 모형정원 진화론」{$versionInfo}
	</td>
</tr>

<tr>
	<td>
		관 리 자 ： $adminName
	</td>
	<td>
		메일주소 ： <a href="mailto:$email">$email</a>
	</td>
</tr>

<tr>
	<td colspan="2">
		copyright .
		<a href="javascript:void(0);" onclick="openCopyright()">바로보기</a>대부분사이트가없어짐
	</td>
</tr>
</table>
</div>

<!-- 배경 -->
<div id="copyrightBg" onclick="closeCopyright()"></div>

<!-- 팝업 (배포소 테이블만) -->
<div id="copyrightView">
	<div class="closeBtn">
		<a href="javascript:void(0);" onclick="closeCopyright()">닫기</a>
	</div>

	<table>
	<tr>
		<td>개조원 및 배포소</td>
		<td>본 가</td>
		<td>이미지 배포원</td>
	</tr>

	<tr>
	<td rowspan="3">
		<a href="http://www8.plala.or.jp/nayupon/" target="_blank">
		<img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///ywAAAAAAQABAAACAUwAOw==" data-src="http://www8.plala.or.jp/nayupon/image/khako.png" width="105" alt="究 想 の 箱 庭 배너"><br>
		究 想 の 箱 庭</a><br>

		<a href="http://esils.com" target="_blank">
		<img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///ywAAAAAAQABAAACAUwAOw==" data-src="https://esils.com/banner/be.png" width="105" alt="esils 배너"><br>
		esils</a>
	</td>

	<td rowspan="3">
		<a href="http://t.pos.to/hako/" target="_blank">
		<img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///ywAAAAAAQABAAACAUwAOw==" data-src="https://esils.com/banner/hako.gif" width="105" alt="箱庭諸島 배너"><br>
		箱庭諸島</a>
	</td>

	<td>
		<a href="http://www.propel.ne.jp/~yysky/" target="_blank">
		<img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///ywAAAAAAQABAAACAUwAOw==" data-src="http://www.propel.ne.jp/~yysky/gallery/banner_1.gif" width="88" alt="이미지 배포원 배너">
		</a><br>

		<a href="http://www5b.biglobe.ne.jp/~k-e-i/i.html" target="_blank">
		<img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///ywAAAAAAQABAAACAUwAOw==" data-src="http://www5b.biglobe.ne.jp/~k-e-i/keilink.gif" width="88" alt="이미지 배포원 배너">
		</a>
	</td>
	</tr>

	<tr>
	<td>
		<a href="http://www.qoonet.com/hakoniwa.html" target="_blank">箱庭QooLand</a><br>
		<a href="http://color.2.pro.tok2.com/" target="_blank">P L U S +</a>
	</td>
	</tr>

	</table>
</div>

END
);
//#### 추가 감독 20020307
	if($Hperformance) {
		list($cpu, $uti, $sti) = hako_cpu_times();

		// 로그 파일 서두(테스트 계측용 평상시는 코멘트로 해 두어 주세요)
//		hako_open('POUT',">>cpu-h.log");
//		hako_write('POUT', "CPU($cpu) : user($uti) system($sti)\n");
//		hako_close('POUT');

		out(<<<END
<DIV align="right">
<SMALL>CPU($cpu) : user($uti) system($sti)</SMALL>
</DIV>
END
);
	}
//####
	out(<<<END
</BODY>
</HTML>
END
);
}

// 락 실패
function tempLockFail() {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $Halistmode, $Hallyflg, $Hasync, $HbaseDir, $HbfieldMode, $HcomDoNothing, $HcomL, $HcommandArg, $HcommandComary, $HcommandKind, $HcommandMax, $HcommandMode, $HcommandPlanNumber, $HcommandTarget, $HcommandTX, $HcommandTY, $HcommandX, $HcommandY, $HcommentLabel0, $HcommentLabel1, $HcommentLabel2, $HcommentLabel3, $HcommentLabel4, $HcssFile, $HcurrentID, $HcurrentName, $HcurrentOwnerName, $Hcustom, $Hdebug, $HdebugMode, $HdefaultKind, $HdefaultName, $HdefaultPassword, $HdefaultTX, $HdefaultTY, $HdefaultX, $HdefaultY, $HdirMode, $helpDir, $HerrorNum, $HexchangeBidID, $HexchangeBuy, $HexchangeBuyCost, $HexchangeCon, $HexchangeDelID, $HexchangeMode, $HexchangeSell, $HexchangeSellCost, $HflexTime, $HflexTimeSet, $HforeignerID, $Hically, $Hicevil, $Hicfood, $HichangeMode, $Hicmoney, $Hicspace, $Hicweapon, $HidToName, $HidToNumber, $HimageDir, $HimgLine, $HinputPassword, $HinputPassword2, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNextID, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HjavaMode, $HjavaModeSet, $HjumpURL, $HlandBase, $HlandDokan, $HlandEarth, $HlandOcean, $HlandOPlayer, $HlandSea, $HlandSpaceBase, $HlastTurn, $HlbbsMax, $HlbbsMessage, $HlbbsMode, $HlbbsMode2, $HlbbsName, $HlbbsType, $HlchangeKIND, $HlchangeMode, $HlchangeVALUE, $Hlinkcheck, $HlistID, $HmainMode, $HmasterPassword, $Hmessage, $Hmonsname, $HmonsterName, $Hmonsurl, $Hmyship, $HmyshipFlg, $Hocean, $HoceanSize, $HokURL, $HoldPassword, $HomeImage, $hour, $hp, $HpasswordFile, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $HpreDeleteID, $HpreDeleteMode, $HpresentFood, $HpresentLog, $HpresentMode, $HpresentMoney, $HprintID, $Hprofile, $HprofileDir, $HpunishID, $HpunishMode, $HretryCount, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $Hrsswrite, $HseaChk, $HskinName, $Hspace, $HspaceID, $Hspacemap, $HspecialPassword, $HtempBack, $HthisFile, $Htitle, $htmlBgColor, $htmlBody, $HtmTime1, $HtmTime2, $HtmTime3, $HtopAxes, $Htournament, $HtournamentmonsId, $hturn, $HugMax, $Hugmode, $HunitTime, $Hurlownermode, $imageDir, $lockMode, $toppage, $versionInfo;
	// 타이틀
	out(<<<END
{$HtagBig_}동시 액세스 에러입니다.<BR>
브라우저의 「돌아온다」버튼을 눌러,<BR>
당분간 기다리고 나서 접속해 주세요.{$H_tagBig}$HtempBack
END
);
}

// 강제 해제
function tempUnlock() {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $Halistmode, $Hallyflg, $Hasync, $HbaseDir, $HbfieldMode, $HcomDoNothing, $HcomL, $HcommandArg, $HcommandComary, $HcommandKind, $HcommandMax, $HcommandMode, $HcommandPlanNumber, $HcommandTarget, $HcommandTX, $HcommandTY, $HcommandX, $HcommandY, $HcommentLabel0, $HcommentLabel1, $HcommentLabel2, $HcommentLabel3, $HcommentLabel4, $HcssFile, $HcurrentID, $HcurrentName, $HcurrentOwnerName, $Hcustom, $Hdebug, $HdebugMode, $HdefaultKind, $HdefaultName, $HdefaultPassword, $HdefaultTX, $HdefaultTY, $HdefaultX, $HdefaultY, $HdirMode, $helpDir, $HerrorNum, $HexchangeBidID, $HexchangeBuy, $HexchangeBuyCost, $HexchangeCon, $HexchangeDelID, $HexchangeMode, $HexchangeSell, $HexchangeSellCost, $HflexTime, $HflexTimeSet, $HforeignerID, $Hically, $Hicevil, $Hicfood, $HichangeMode, $Hicmoney, $Hicspace, $Hicweapon, $HidToName, $HidToNumber, $HimageDir, $HimgLine, $HinputPassword, $HinputPassword2, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNextID, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HjavaMode, $HjavaModeSet, $HjumpURL, $HlandBase, $HlandDokan, $HlandEarth, $HlandOcean, $HlandOPlayer, $HlandSea, $HlandSpaceBase, $HlastTurn, $HlbbsMax, $HlbbsMessage, $HlbbsMode, $HlbbsMode2, $HlbbsName, $HlbbsType, $HlchangeKIND, $HlchangeMode, $HlchangeVALUE, $Hlinkcheck, $HlistID, $HmainMode, $HmasterPassword, $Hmessage, $Hmonsname, $HmonsterName, $Hmonsurl, $Hmyship, $HmyshipFlg, $Hocean, $HoceanSize, $HokURL, $HoldPassword, $HomeImage, $hour, $hp, $HpasswordFile, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $HpreDeleteID, $HpreDeleteMode, $HpresentFood, $HpresentLog, $HpresentMode, $HpresentMoney, $HprintID, $Hprofile, $HprofileDir, $HpunishID, $HpunishMode, $HretryCount, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $Hrsswrite, $HseaChk, $HskinName, $Hspace, $HspaceID, $Hspacemap, $HspecialPassword, $HtempBack, $HthisFile, $Htitle, $htmlBgColor, $htmlBody, $HtmTime1, $HtmTime2, $HtmTime3, $HtopAxes, $Htournament, $HtournamentmonsId, $hturn, $HugMax, $Hugmode, $HunitTime, $Hurlownermode, $imageDir, $lockMode, $toppage, $versionInfo;
	// 타이틀
	out(<<<END
{$HtagBig_}전회의 액세스가 이상종료(ABEND)였던 것 같습니다.<BR>
락을 강제 해제했습니다.{$H_tagBig}$HtempBack

END
);
}

// 패스워드 파일이 없다
function tempNoPasswordFile() {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $Halistmode, $Hallyflg, $Hasync, $HbaseDir, $HbfieldMode, $HcomDoNothing, $HcomL, $HcommandArg, $HcommandComary, $HcommandKind, $HcommandMax, $HcommandMode, $HcommandPlanNumber, $HcommandTarget, $HcommandTX, $HcommandTY, $HcommandX, $HcommandY, $HcommentLabel0, $HcommentLabel1, $HcommentLabel2, $HcommentLabel3, $HcommentLabel4, $HcssFile, $HcurrentID, $HcurrentName, $HcurrentOwnerName, $Hcustom, $Hdebug, $HdebugMode, $HdefaultKind, $HdefaultName, $HdefaultPassword, $HdefaultTX, $HdefaultTY, $HdefaultX, $HdefaultY, $HdirMode, $helpDir, $HerrorNum, $HexchangeBidID, $HexchangeBuy, $HexchangeBuyCost, $HexchangeCon, $HexchangeDelID, $HexchangeMode, $HexchangeSell, $HexchangeSellCost, $HflexTime, $HflexTimeSet, $HforeignerID, $Hically, $Hicevil, $Hicfood, $HichangeMode, $Hicmoney, $Hicspace, $Hicweapon, $HidToName, $HidToNumber, $HimageDir, $HimgLine, $HinputPassword, $HinputPassword2, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNextID, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HjavaMode, $HjavaModeSet, $HjumpURL, $HlandBase, $HlandDokan, $HlandEarth, $HlandOcean, $HlandOPlayer, $HlandSea, $HlandSpaceBase, $HlastTurn, $HlbbsMax, $HlbbsMessage, $HlbbsMode, $HlbbsMode2, $HlbbsName, $HlbbsType, $HlchangeKIND, $HlchangeMode, $HlchangeVALUE, $Hlinkcheck, $HlistID, $HmainMode, $HmasterPassword, $Hmessage, $Hmonsname, $HmonsterName, $Hmonsurl, $Hmyship, $HmyshipFlg, $Hocean, $HoceanSize, $HokURL, $HoldPassword, $HomeImage, $hour, $hp, $HpasswordFile, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $HpreDeleteID, $HpreDeleteMode, $HpresentFood, $HpresentLog, $HpresentMode, $HpresentMoney, $HprintID, $Hprofile, $HprofileDir, $HpunishID, $HpunishMode, $HretryCount, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $Hrsswrite, $HseaChk, $HskinName, $Hspace, $HspaceID, $Hspacemap, $HspecialPassword, $HtempBack, $HthisFile, $Htitle, $htmlBgColor, $htmlBody, $HtmTime1, $HtmTime2, $HtmTime3, $HtopAxes, $Htournament, $HtournamentmonsId, $hturn, $HugMax, $Hugmode, $HunitTime, $Hurlownermode, $imageDir, $lockMode, $toppage, $versionInfo;
	out(<<<END
{$HtagBig_}패스워드 파일이 열리지 않습니다.{$H_tagBig}$HtempBack
END
);
}

//  hakojima.dat하지만 없다
function tempNoDataFile() {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $Halistmode, $Hallyflg, $Hasync, $HbaseDir, $HbfieldMode, $HcomDoNothing, $HcomL, $HcommandArg, $HcommandComary, $HcommandKind, $HcommandMax, $HcommandMode, $HcommandPlanNumber, $HcommandTarget, $HcommandTX, $HcommandTY, $HcommandX, $HcommandY, $HcommentLabel0, $HcommentLabel1, $HcommentLabel2, $HcommentLabel3, $HcommentLabel4, $HcssFile, $HcurrentID, $HcurrentName, $HcurrentOwnerName, $Hcustom, $Hdebug, $HdebugMode, $HdefaultKind, $HdefaultName, $HdefaultPassword, $HdefaultTX, $HdefaultTY, $HdefaultX, $HdefaultY, $HdirMode, $helpDir, $HerrorNum, $HexchangeBidID, $HexchangeBuy, $HexchangeBuyCost, $HexchangeCon, $HexchangeDelID, $HexchangeMode, $HexchangeSell, $HexchangeSellCost, $HflexTime, $HflexTimeSet, $HforeignerID, $Hically, $Hicevil, $Hicfood, $HichangeMode, $Hicmoney, $Hicspace, $Hicweapon, $HidToName, $HidToNumber, $HimageDir, $HimgLine, $HinputPassword, $HinputPassword2, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNextID, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HjavaMode, $HjavaModeSet, $HjumpURL, $HlandBase, $HlandDokan, $HlandEarth, $HlandOcean, $HlandOPlayer, $HlandSea, $HlandSpaceBase, $HlastTurn, $HlbbsMax, $HlbbsMessage, $HlbbsMode, $HlbbsMode2, $HlbbsName, $HlbbsType, $HlchangeKIND, $HlchangeMode, $HlchangeVALUE, $Hlinkcheck, $HlistID, $HmainMode, $HmasterPassword, $Hmessage, $Hmonsname, $HmonsterName, $Hmonsurl, $Hmyship, $HmyshipFlg, $Hocean, $HoceanSize, $HokURL, $HoldPassword, $HomeImage, $hour, $hp, $HpasswordFile, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $HpreDeleteID, $HpreDeleteMode, $HpresentFood, $HpresentLog, $HpresentMode, $HpresentMoney, $HprintID, $Hprofile, $HprofileDir, $HpunishID, $HpunishMode, $HretryCount, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $Hrsswrite, $HseaChk, $HskinName, $Hspace, $HspaceID, $Hspacemap, $HspecialPassword, $HtempBack, $HthisFile, $Htitle, $htmlBgColor, $htmlBody, $HtmTime1, $HtmTime2, $HtmTime3, $HtopAxes, $Htournament, $HtournamentmonsId, $hturn, $HugMax, $Hugmode, $HunitTime, $Hurlownermode, $imageDir, $lockMode, $toppage, $versionInfo;
	out(<<<END
{$HtagBig_}데이터 파일이 열리지 않습니다.{$H_tagBig}$HtempBack
END
);
}

// 무엇인가 문제 발생
function tempProblem() {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $Halistmode, $Hallyflg, $Hasync, $HbaseDir, $HbfieldMode, $HcomDoNothing, $HcomL, $HcommandArg, $HcommandComary, $HcommandKind, $HcommandMax, $HcommandMode, $HcommandPlanNumber, $HcommandTarget, $HcommandTX, $HcommandTY, $HcommandX, $HcommandY, $HcommentLabel0, $HcommentLabel1, $HcommentLabel2, $HcommentLabel3, $HcommentLabel4, $HcssFile, $HcurrentID, $HcurrentName, $HcurrentOwnerName, $Hcustom, $Hdebug, $HdebugMode, $HdefaultKind, $HdefaultName, $HdefaultPassword, $HdefaultTX, $HdefaultTY, $HdefaultX, $HdefaultY, $HdirMode, $helpDir, $HerrorNum, $HexchangeBidID, $HexchangeBuy, $HexchangeBuyCost, $HexchangeCon, $HexchangeDelID, $HexchangeMode, $HexchangeSell, $HexchangeSellCost, $HflexTime, $HflexTimeSet, $HforeignerID, $Hically, $Hicevil, $Hicfood, $HichangeMode, $Hicmoney, $Hicspace, $Hicweapon, $HidToName, $HidToNumber, $HimageDir, $HimgLine, $HinputPassword, $HinputPassword2, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNextID, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HjavaMode, $HjavaModeSet, $HjumpURL, $HlandBase, $HlandDokan, $HlandEarth, $HlandOcean, $HlandOPlayer, $HlandSea, $HlandSpaceBase, $HlastTurn, $HlbbsMax, $HlbbsMessage, $HlbbsMode, $HlbbsMode2, $HlbbsName, $HlbbsType, $HlchangeKIND, $HlchangeMode, $HlchangeVALUE, $Hlinkcheck, $HlistID, $HmainMode, $HmasterPassword, $Hmessage, $Hmonsname, $HmonsterName, $Hmonsurl, $Hmyship, $HmyshipFlg, $Hocean, $HoceanSize, $HokURL, $HoldPassword, $HomeImage, $hour, $hp, $HpasswordFile, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $HpreDeleteID, $HpreDeleteMode, $HpresentFood, $HpresentLog, $HpresentMode, $HpresentMoney, $HprintID, $Hprofile, $HprofileDir, $HpunishID, $HpunishMode, $HretryCount, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $Hrsswrite, $HseaChk, $HskinName, $Hspace, $HspaceID, $Hspacemap, $HspecialPassword, $HtempBack, $HthisFile, $Htitle, $htmlBgColor, $htmlBody, $HtmTime1, $HtmTime2, $HtmTime3, $HtopAxes, $Htournament, $HtournamentmonsId, $hturn, $HugMax, $Hugmode, $HunitTime, $Hurlownermode, $imageDir, $lockMode, $toppage, $versionInfo;
	out(<<<END
{$HtagBig_}문제 발생  돌아가 주세요.{$H_tagBig}$HtempBack
END
);
}

// 기입 실패
function tempFailWrite() {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $Halistmode, $Hallyflg, $Hasync, $HbaseDir, $HbfieldMode, $HcomDoNothing, $HcomL, $HcommandArg, $HcommandComary, $HcommandKind, $HcommandMax, $HcommandMode, $HcommandPlanNumber, $HcommandTarget, $HcommandTX, $HcommandTY, $HcommandX, $HcommandY, $HcommentLabel0, $HcommentLabel1, $HcommentLabel2, $HcommentLabel3, $HcommentLabel4, $HcssFile, $HcurrentID, $HcurrentName, $HcurrentOwnerName, $Hcustom, $Hdebug, $HdebugMode, $HdefaultKind, $HdefaultName, $HdefaultPassword, $HdefaultTX, $HdefaultTY, $HdefaultX, $HdefaultY, $HdirMode, $helpDir, $HerrorNum, $HexchangeBidID, $HexchangeBuy, $HexchangeBuyCost, $HexchangeCon, $HexchangeDelID, $HexchangeMode, $HexchangeSell, $HexchangeSellCost, $HflexTime, $HflexTimeSet, $HforeignerID, $Hically, $Hicevil, $Hicfood, $HichangeMode, $Hicmoney, $Hicspace, $Hicweapon, $HidToName, $HidToNumber, $HimageDir, $HimgLine, $HinputPassword, $HinputPassword2, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNextID, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HjavaMode, $HjavaModeSet, $HjumpURL, $HlandBase, $HlandDokan, $HlandEarth, $HlandOcean, $HlandOPlayer, $HlandSea, $HlandSpaceBase, $HlastTurn, $HlbbsMax, $HlbbsMessage, $HlbbsMode, $HlbbsMode2, $HlbbsName, $HlbbsType, $HlchangeKIND, $HlchangeMode, $HlchangeVALUE, $Hlinkcheck, $HlistID, $HmainMode, $HmasterPassword, $Hmessage, $Hmonsname, $HmonsterName, $Hmonsurl, $Hmyship, $HmyshipFlg, $Hocean, $HoceanSize, $HokURL, $HoldPassword, $HomeImage, $hour, $hp, $HpasswordFile, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $HpreDeleteID, $HpreDeleteMode, $HpresentFood, $HpresentLog, $HpresentMode, $HpresentMoney, $HprintID, $Hprofile, $HprofileDir, $HpunishID, $HpunishMode, $HretryCount, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $Hrsswrite, $HseaChk, $HskinName, $Hspace, $HspaceID, $Hspacemap, $HspecialPassword, $HtempBack, $HthisFile, $Htitle, $htmlBgColor, $htmlBody, $HtmTime1, $HtmTime2, $HtmTime3, $HtopAxes, $Htournament, $HtournamentmonsId, $hturn, $HugMax, $Hugmode, $HunitTime, $Hurlownermode, $imageDir, $lockMode, $toppage, $versionInfo;
	out(<<<END
{$HtagBig_}데이터 파일의 기입에 실패했습니다. (에러 번호{$HerrorNum}){$H_tagBig}$HtempBack
END
);
}

// 메인트넌스중
function mente_mode() {
  $_args = func_get_args();
  extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $Halistmode, $Hallyflg, $Hasync, $HbaseDir, $HbfieldMode, $HcomDoNothing, $HcomL, $HcommandArg, $HcommandComary, $HcommandKind, $HcommandMax, $HcommandMode, $HcommandPlanNumber, $HcommandTarget, $HcommandTX, $HcommandTY, $HcommandX, $HcommandY, $HcommentLabel0, $HcommentLabel1, $HcommentLabel2, $HcommentLabel3, $HcommentLabel4, $HcssFile, $HcurrentID, $HcurrentName, $HcurrentOwnerName, $Hcustom, $Hdebug, $HdebugMode, $HdefaultKind, $HdefaultName, $HdefaultPassword, $HdefaultTX, $HdefaultTY, $HdefaultX, $HdefaultY, $HdirMode, $helpDir, $HerrorNum, $HexchangeBidID, $HexchangeBuy, $HexchangeBuyCost, $HexchangeCon, $HexchangeDelID, $HexchangeMode, $HexchangeSell, $HexchangeSellCost, $HflexTime, $HflexTimeSet, $HforeignerID, $Hically, $Hicevil, $Hicfood, $HichangeMode, $Hicmoney, $Hicspace, $Hicweapon, $HidToName, $HidToNumber, $HimageDir, $HimgLine, $HinputPassword, $HinputPassword2, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNextID, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HjavaMode, $HjavaModeSet, $HjumpURL, $HlandBase, $HlandDokan, $HlandEarth, $HlandOcean, $HlandOPlayer, $HlandSea, $HlandSpaceBase, $HlastTurn, $HlbbsMax, $HlbbsMessage, $HlbbsMode, $HlbbsMode2, $HlbbsName, $HlbbsType, $HlchangeKIND, $HlchangeMode, $HlchangeVALUE, $Hlinkcheck, $HlistID, $HmainMode, $HmasterPassword, $Hmessage, $Hmonsname, $HmonsterName, $Hmonsurl, $Hmyship, $HmyshipFlg, $Hocean, $HoceanSize, $HokURL, $HoldPassword, $HomeImage, $hour, $hp, $HpasswordFile, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $HpreDeleteID, $HpreDeleteMode, $HpresentFood, $HpresentLog, $HpresentMode, $HpresentMoney, $HprintID, $Hprofile, $HprofileDir, $HpunishID, $HpunishMode, $HretryCount, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $Hrsswrite, $HseaChk, $HskinName, $Hspace, $HspaceID, $Hspacemap, $HspecialPassword, $HtempBack, $HthisFile, $Htitle, $htmlBgColor, $htmlBody, $HtmTime1, $HtmTime2, $HtmTime3, $HtopAxes, $Htournament, $HtournamentmonsId, $hturn, $HugMax, $Hugmode, $HunitTime, $Hurlownermode, $imageDir, $lockMode, $toppage, $versionInfo;
	// 헤더 출력
	if ($_args[0]) { tempHeader(); }

	// 메세지
	out("{$HtagBig_}지금 점검중입니다.<BR>잠시 기다려 주세요. {$H_tagBig}");

	// footer 출력
	tempFooter();

	// 종료
	exit(0);
}
