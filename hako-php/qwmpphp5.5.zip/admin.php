<?php



















require_once './init.php';


wf_boot(true);










if (wf_form_value('pass') === '') { wf_admin_enter(); }
elseif ($mode === 'edit' && wf_form_value('no') !== '') { wf_admin_edit(); }
elseif ($mode === 'edit2' && wf_form_value('no') !== '') { wf_admin_edit2(); }
elseif ($mode === 'dele' && wf_form_value('no') !== '') { wf_admin_dele(); }
wf_admin_loglist();







function wf_admin_check() {
    global $pass;
    if (wf_form_value('pass') !== $pass) { wf_error('패스워드가 틀립니다'); }
}









function wf_admin_loglist() {
    global $script, $admin, $pqhako, $in, $page, $p_tree, $no_color;
    wf_admin_check();
    wf_header();
    echo '<form action="' . wf_attr($script) . '">' . "\n";
    echo $pqhako . "\n";
    echo '<input type="submit" value="게시판으로 돌아간다"></form>' . "\n";
    echo '<ul><li>처리를 선택해 송신 버튼을 눌러 주세요.' . "\n";
    echo '<li>트리의 선두 기사를 삭제하면, 트리마다 일괄 삭제됩니다.</ul>' . "\n";
    echo '<form action="' . wf_attr($admin) . '" method="post">' . "\n";
    echo $pqhako . "\n";
    echo '<input type="hidden" name="pass" value="' . wf_attr(wf_form_value('pass')) . '">' . "\n";
    echo '처리 <select name="mode"><option value="edit">수정<option value="dele">삭제</select>' . "\n";
    echo '<input type="submit" value="송신한다"><dl>' . "\n";
    
    list($top, $records) = wf_read_records();
    $i = 0;
    foreach ($records as $r) {
        
        if (intval($r['reno']) == 0) { $i++; }
        if ($i < $page + 1) { continue; }
        if ($i > $page + $p_tree) { continue; }
        
        $sp = intval($r['lx']) ? str_repeat('&nbsp;&nbsp;&nbsp;', intval($r['lx'])) : '';
        $msg = str_replace('<br>', ' ', $r['message']);
        if (function_exists('mb_strimwidth')) { $msg = mb_strimwidth($msg, 0, 60, '..', 'UTF-8'); }
        elseif (strlen($msg) > 60) { $msg = substr($msg, 0, 58) . '..'; }
        echo '<dt>';
        if ((string)$r['no'] === (string)$r['oya']) { echo '<hr>'; }
        echo $sp . '<input type=checkbox name=no value="' . wf_attr($r['no']) . '">[' . $r['no'] . '] <b>' . $r['sub'] . '</b> ';
        echo '- <B>' . $r['name'] . '</B> ' . $r['date'] . ' 【' . $r['host'] . '】' . "\n";
        echo '<dd>' . $sp . '<span style=\'font-size:11px;color:' . wf_attr($no_color) . ';\'>' . $msg . '</span>' . "\n";
    }
    echo '<dt><hr></dl></form>' . "\n";
    $next = $page + $p_tree; $back = $page - $p_tree;
    echo '<table><tr>' . "\n";
    if ($back >= 0) {
        echo '<td><form action="' . wf_attr($admin) . '" method="post">' . "\n";
        echo $pqhako . '<input type="hidden" name="pass" value="' . wf_attr(wf_form_value('pass')) . '">' . "\n";
        echo '<input type="hidden" name="page" value="' . $back . '"><input type="submit" value="전화면"></form></td>' . "\n";
    }
    if ($next < $i) {
        echo '<td><form action="' . wf_attr($admin) . '" method="post">' . "\n";
        echo $pqhako . '<input type="hidden" name="pass" value="' . wf_attr(wf_form_value('pass')) . '">' . "\n";
        echo '<input type="hidden" name="page" value="' . $next . '"><input type="submit" value="다음 화면"></form></td>' . "\n";
    }
    echo '</tr></table></body></html>' . "\n";
    exit;
}








function wf_admin_edit() {
    global $pqhako, $admin;
    wf_admin_check();
    $no_req = wf_form_value('no');
    if (strpos($no_req, "\0") !== false) { wf_error('수정 처리는 1 기사씩입니다'); }
    list($top, $records) = wf_read_records();
    $target = wf_find_record_by_no($records, $no_req);
    if (!$target) { wf_error('기사가 눈에 띄지 않습니다'); }
    $msg = str_replace('<br>', "\n", $target['message']);
    wf_header();
    echo '<form><input type="button" value="전화면에 돌아온다" onclick="history.back()"></form>' . "\n";
    echo '▼변경하고 싶은 부분만 수정해 송신 버튼을 눌러 주세요.' . "\n";
    echo '<form action="' . wf_attr($admin) . '" method="post">' . "\n";
    echo $pqhako . "\n";
    echo '<input type="hidden" name="mode" value="edit2">' . "\n";
    echo '<input type="hidden" name="no" value="' . wf_attr($target['no']) . '">' . "\n";
    echo '<input type="hidden" name="pass" value="' . wf_attr(wf_form_value('pass')) . '">' . "\n";
    echo '<table border="0">' . "\n";
    echo '<tr><td><B>글자</B></td><td><input type="text" name="name" value="' . wf_attr($target['name']) . '" size="28"></td></tr>' . "\n";
    echo '<tr><td><B>E메일</B></td><td><input type="text" name="email" value="' . wf_attr($target['email']) . '" size="28"><select name="smail">' . "\n";
    foreach (array(0=>'표시',1=>'비표시') as $i=>$lab) { echo '<option value="' . $i . '"' . ((string)$target['smail'] === (string)$i ? ' selected' : '') . '>' . $lab . "\n"; }
    echo '</select></td></tr>' . "\n";
    echo '<tr><td><B>타이틀</B></td><td><input type="text" name="sub" value="' . wf_attr($target['sub']) . '" size="38"></td></tr>' . "\n";
    echo '<tr><td colspan="2"><B>내용</B>' . "\n";
    foreach (array('soft'=>'수동 개행','hard'=>'강제 개행','pre'=>'도표 모드') as $wv=>$label) { echo '<input type="radio" name="wrap" value="' . $wv . '"' . ($target['wrap'] === $wv ? ' checked' : '') . '>' . $label . "\n"; }
    echo '<br><textarea name="message" cols="64" rows="10">' . wf_h($msg) . '</textarea></td></tr>' . "\n";
    echo '<tr><td><B>참조처</B></td><td><input type="text" name="url" value="' . wf_attr($target['url']) . '" size="55"></td></tr>' . "\n";
    echo '</table><p><input type="submit" value=" 송신하는 "><input type="reset" value="리셋"></form></body></html>' . "\n";
    exit;
}








function wf_admin_edit2() {
    wf_admin_check();
    list($top, $records) = wf_read_records();
    $no_req = wf_form_value('no');
    foreach ($records as $idx=>$r) {
        if ((string)$r['no'] === (string)$no_req) {
            $records[$idx]['sub'] = wf_sanitize_post_value(wf_form_value('sub'));
            $records[$idx]['email'] = wf_sanitize_post_value(wf_form_value('email'));
            $records[$idx]['url'] = wf_sanitize_post_value(wf_form_value('url'));
            $records[$idx]['name'] = wf_sanitize_post_value(wf_form_value('name'));
            $records[$idx]['message'] = wf_sanitize_message(wf_form_value('message'), wf_form_value('wrap'));
            $records[$idx]['wrap'] = in_array(wf_form_value('wrap'), array('soft','hard','pre')) ? wf_form_value('wrap') : 'soft';
            $records[$idx]['smail'] = wf_form_value('smail','0');
            wf_write_records($top, $records);
            wf_admin_loglist();
        }
    }
    wf_error('기사가 눈에 띄지 않습니다');
}








function wf_admin_dele() {
    wf_admin_check();
    list($top, $records) = wf_read_records();
    $raw = wf_form_value('no');
    
    $targets = explode("\0", $raw);
    $new = array();
    foreach ($records as $r) {
        $flag = false;
        foreach ($targets as $del) {
            
            if ((string)$del === (string)$r['no'] || (string)$del === (string)$r['oya']) { $flag = true; break; }
        }
        if (!$flag) { $new[] = $r; }
    }
    wf_write_records($top, $new);
    wf_admin_loglist();
}







function wf_admin_enter() {
    global $Hallygroup, $admin, $script;
    $select_list = '';
    foreach ($Hallygroup as $i=>$name) { $select_list .= '<OPTION value=' . wf_attr($i) . '>' . wf_h($name) . "\n"; }
    wf_header();
    echo '<div align="center">' . "\n";
    echo '<hr width=400><h4>관리용 페이지에 입실한다.</h4><table>' . "\n";
    echo '<form action="' . wf_attr($admin) . '" method="POST">' . "\n";
    echo '진영 명칭<SELECT NAME="campID">' . "\n" . $select_list . '</SELECT><br>' . "\n";
    echo '진영 패스<INPUT TYPE="text" NAME="campPASS" VALUE=""><br>' . "\n";
    echo '관리 패스<input type=password name=pass size=8><input type=submit value=" 인증 "></form></table>' . "\n";
    echo '<hr width=400><h4>임의의 게시판에 입실한다.</h4><table>' . "\n";
    echo '<FORM action="' . wf_attr($script) . '" method="POST">진영 명칭<SELECT NAME="campID">' . "\n" . $select_list . '</SELECT><br>' . "\n";
    echo '진영 패스<INPUT TYPE="text" NAME="campPASS" VALUE=""><INPUT TYPE="submit" VALUE="실행" NAME="cButton"></FORM></table>' . "\n";
    echo '<hr width=400></div><!-- Web Forum v5.02 --></body></html>' . "\n";
    exit;
}
?>
