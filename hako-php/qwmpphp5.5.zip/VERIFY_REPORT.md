# 수정 보고

## 증상
매립 계획을 여러 좌표에 입력했으나 x=0 또는 y=0 좌표가 포함된 뒤부터 좌표 쿠키가 갱신되지 않아 이전 좌표가 재사용될 수 있었습니다. 그 결과 일부 명령이 같은 좌표로 저장/표시되거나 실제 매립 수가 줄어드는 문제가 발생했습니다.

## 수정
- hako/hako-main.php
  - POINTX/POINTY 쿠키 저장 조건을 truthy 판정에서 isset + 빈 문자열 판정으로 변경
  - 좌표 0도 정상 저장되도록 수정
  - TARGETID도 0/빈값 판정 오류가 나지 않도록 보정
- hako/hako-js.php
  - AJAX 명령 송신 post 문자열 초기화 누락 수정
  - COMARY/PASSWORD URL 인코딩 추가
  - Content-Type 명시

## 유지
- DB 미사용
- CGI/Perl 미사용
- PHP 5.5 호환 문법 유지
- 고정 URL 제거/동적 경로 계산 유지
- 이미지 폴더 포함
- 턴 간격 1800초 유지
