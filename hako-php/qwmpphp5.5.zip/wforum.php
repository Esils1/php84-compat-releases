<?php


















require_once './init.php';
require_once './fold.php';

wf_boot(true);







if ($mode === 'msgview' || $mode === 'msg') { wf_msgview(); }
elseif ($mode === 'allread') { wf_allread(); }
elseif ($mode === 'newsort') { wf_newsort(); }
elseif ($mode === 'find' || $mode === 'search') { wf_find(); }
elseif ($mode === 'note') { wf_note(); }
elseif ($mode === 'past') { wf_past_view(); }
elseif ($mode === 'check') { wf_check(); }
wf_list_view();







function wf_title_block() {
    global $t_img, $title, $t_w, $t_h, $t_point, $t_color;
    if ($t_img) { echo '<img src="' . wf_attr($t_img) . '" alt="' . wf_attr($title) . '" width="' . intval($t_w) . '" height="' . intval($t_h) . '">' . "\n"; }
    else { echo '<b style="font-size:' . wf_attr($t_point) . ';color:' . wf_attr($t_color) . '">' . wf_h($title) . '</b>' . "\n"; }
}







function wf_list_view() {
    global $home, $script, $admin, $gqhako, $in, $page, $new_time, $newmark, $treehead, $pastkey, $ver;
    wf_header();
    echo '<div align="center">' . "\n";
    wf_title_block();
    echo '<hr width="90%">' . "\n";
    echo '[<a href="' . wf_attr($home) . '" target="_top">탑에 돌아온다</a>]' . "\n";
    echo '[<a href="' . wf_attr($script . '?' . $gqhako . 'mode=note') . '">유의 사항</a>]' . "\n";
    echo '[<a href="#msg">신규 글</a>]' . "\n";
    if (!isset($in['list']) || $in['list'] !== 'new') { echo '[<a href="' . wf_attr($script . '?' . $gqhako . 'list=new') . '">신규순 표시</a>]' . "\n"; }
    else { echo '[<a href="' . wf_attr($script . '?' . $gqhako . 'list=tree') . '">트리 표시</a>]' . "\n"; }
    if (!isset($in['list']) || $in['list'] === '') { $in['list'] = 'tree'; }
    echo '[<a href="' . wf_attr($script . '?' . $gqhako . 'mode=newsort&page=' . intval($page)) . '">신착 기사</a>]' . "\n";
    echo '[<a href="' . wf_attr($script . '?' . $gqhako . 'mode=find&page=' . intval($page) . '&list=' . rawurlencode($in['list'])) . '">워드 검색</a>]' . "\n";
    if ($pastkey) { echo '[<a href="' . wf_attr($script . '?' . $gqhako . 'mode=past') . '">과거 로그</a>]' . "\n"; }
    echo '[<a href="' . wf_attr($admin . '?' . $gqhako) . '">관리용</a>]' . "\n";
    echo '<hr width="90%">' . "\n";
    echo '<table><tr><td>' . "\n";
    echo '<li>' . intval($new_time) . ' 시간 이내의 글은 ' . $newmark . ' 로 나타납니다. </li><br>' . "\n";
    if ($in['list'] === 'new') { echo '<li>이하는 신규 글순서의 리스트 표시입니다. </li><br>' . "\n"; }
    else { echo '<li>트리 선두부의 ' . wf_h($treehead) . '를 클릭하면 관련 기사를 일괄 가리킵니다.</li><br>' . "\n"; }
    echo '</td></tr></table></div>' . "\n";
    
    if ($in['list'] === 'new') { wf_list_new_open(); } else { wf_list_tree_open(); }
    wf_move_list();
    wf_msg_form();
    echo '<p><!-- ' . wf_h($ver) . ' -->' . "\n";
    echo '<div align="center" style="font-size:10px; font-family:Verdana,Helvetica,Arial">' . "\n";
    echo '- <a href="http://www.kent-web.com/" target="_top">Web Forum</a> -' . "\n";
    echo '<BR>Edit:<a href=\'http://www8.plala.or.jp/nayupon/\' target=\'_top\'>nayupon</a>' . "\n";
    echo '</div>' . "\n";
    echo '</body></html>' . "\n";
    exit;
}







function wf_list_tree_open($path = null, $past = false) {
    global $mode, $page, $p_tree, $time, $new_time, $newmark, $no_color, $treehead, $script, $gqhako, $in, $wf_list_i;
    list($top, $records) = wf_read_records($path, !$past);
    if ($mode !== 'past' && !$past) { echo '<DL>' . "\n"; }
    echo '<ul>' . "\n";
    $i = 0; $x = 0; $now = time();
    
    foreach ($records as $r) {
        
        $no = $r['no']; $reno = $r['reno']; $lx = intval($r['lx']); $sub = $r['sub']; $name = $r['name']; $dat = $r['date']; $t = intval($r['times']); $pw = $r['ango']; $oya = $r['oya'];
        if (intval($reno) == 0) { $i++; }
        if ($i < $page + 1) { continue; }
        if ($i > $page + $p_tree) { continue; }
        while ($x > $lx) { echo '</ul>' . "\n"; $x--; }
        while ($x < $lx) { echo '<ul>' . "\n"; $x++; }
        if (intval($reno) == 0) { while ($x > 0) { echo '</ul>' . "\n"; $x--; } }
        $newsign = ($now - $t > $new_time * 3600) ? '' : $newmark;
        $sub2 = wf_cut_subject($sub);
        if ($mode === 'past' || $past) {
            echo '<li><a href="' . wf_attr($script . '?' . $gqhako . 'mode=allread&pastlog=' . wf_form_value('pastlog') . '&no=' . $oya . '&page=' . $page . '&act=past#' . $no) . '">' . $sub2 . '</a> - <b>' . $name . '</b> ' . $dat . ' <font color="' . wf_attr($no_color) . '">No.' . $no . '</font> ' . $newsign . "\n";
        } elseif ($pw === 'DEL') {
            if ($lx == 0) {
                echo '<P><DT><a href="' . wf_attr($script . '?' . $gqhako . 'mode=allread&no=' . $no . '&page=' . $page) . '">' . wf_h($treehead) . '</a> - ';
                echo $sub2 . ' - ' . $dat . ' <font color="' . wf_attr($no_color) . '">No.' . $no . '</font>' . "\n";
            } else {
                echo '<li>' . $sub2 . ' - ' . $dat . ' <font color="' . wf_attr($no_color) . '">No.' . $no . '</font>' . "\n";
            }
        } elseif ($lx != 0) {
            echo '<li><a href="' . wf_attr($script . '?' . $gqhako . 'no=' . $no . '&reno=' . $reno . '&oya=' . $oya . '&mode=msgview&page=' . $page) . '">' . $sub2 . '</a> - <b>' . $name . '</b> ' . $dat . ' <font color="' . wf_attr($no_color) . '">No.' . $no . '</font> ' . $newsign . "\n";
        } else {
            echo '<P><DT><a href="' . wf_attr($script . '?' . $gqhako . 'mode=allread&no=' . $no . '&page=' . $page) . '">' . wf_h($treehead) . '</a> - ';
            echo '<a href="' . wf_attr($script . '?' . $gqhako . 'no=' . $no . '&reno=' . $reno . '&oya=' . $oya . '&mode=msgview&page=' . $page) . '">' . $sub2 . '</a> - <b>' . $name . '</b> ' . $dat . ' <font color="' . wf_attr($no_color) . '">No.' . $no . '</font> ' . $newsign . "\n";
        }
    }
    while ($x > 0) { echo '</ul>' . "\n"; $x--; }
    echo '</ul>' . "\n";
    if ($mode !== 'past' && !$past) { echo '</DL>' . "\n"; }
    $wf_list_i = $i;
}







function wf_list_new_open() {
    global $page, $p_tree, $new_time, $newmark, $no_color, $script, $gqhako, $wf_list_i;
    list($top, $records) = wf_read_records();
    usort($records, 'wf_sort_records_time_desc');
    echo '<ul>' . "\n";
    $i = 0; $limit = $p_tree * 3; $now = time();
    foreach ($records as $r) {
        $i++;
        if ($i < $page + 1) { continue; }
        if ($i > $page + $limit) { continue; }
        $newsign = ($now - intval($r['times']) > $new_time * 3600) ? '' : $newmark;
        if ($r['sub'] === '<s>글자 삭제</s>') {
            echo '<li>' . $r['sub'] . ' - ' . $r['date'] . ' <font color="' . wf_attr($no_color) . '">No.' . $r['no'] . '</font> ' . $newsign . "\n";
        } else {
            echo '<li><a href="' . wf_attr($script . '?' . $gqhako . 'no=' . $r['no'] . '&reno=' . $r['reno'] . '&oya=' . $r['oya'] . '&mode=msgview&list=new') . '">' . $r['sub'] . '</a> - <b>' . $r['name'] . '</b> ' . $r['date'] . ' <font color="' . wf_attr($no_color) . '">No.' . $r['no'] . '</font> ' . $newsign . "\n";
        }
    }
    echo '</ul>' . "\n";
    $wf_list_i = $i;
}




function wf_sort_records_time_desc($a, $b) { return intval($b['times']) - intval($a['times']); }







function wf_msgview() {
    global $in, $script, $admin, $gqhako, $page, $pastkey, $sub_color, $no_color, $treehead, $wf_reply_sub, $wf_reply_msg;
    list($top, $records) = wf_read_records();
    $target = null; $thread = array(); $flag = false; $oya_req = wf_form_value('oya'); $no_req = wf_form_value('no');
    foreach ($records as $r) {
        if ((string)$r['oya'] === (string)$oya_req) { $thread[] = $r; }
        elseif ($flag && (string)$r['oya'] !== (string)$oya_req) { break; }
        if ((string)$r['no'] === (string)$no_req) { $flag = true; $target = $r; }
    }
    if (!$target) { wf_error('기사가 눈에 띄지 않습니다'); }
    
    $wf_reply_msg = "\n&gt; " . str_replace('<br>', "\r&gt; ", $target['message']);
    $wf_reply_msg = str_replace('"', '&quot;', $wf_reply_msg);
    $wf_reply_sub = wf_reply_subject($target['sub']);
    wf_header();
    echo '<div align="center">' . "\n";
    wf_title_block();
    echo '<hr width="90%">' . "\n";
    echo '[<a href="' . wf_attr($script . '?' . $gqhako . 'page=' . $page . '&list=' . wf_form_value('list')) . '">기사 리스트</a>]' . "\n";
    echo '[<a href="' . wf_attr($script . '?' . $gqhako . 'mode=newsort') . '">신착 기사</a>]' . "\n";
    echo '[<a href="' . wf_attr($script . '?' . $gqhako . 'mode=find') . '">워드 검색</a>]' . "\n";
    if ($pastkey) { echo '[<a href="' . wf_attr($script . '?' . $gqhako . 'mode=past') . '">과거 로그</a>]' . "\n"; }
    echo '[<a href="' . wf_attr($admin . '?' . $gqhako) . '">관리용</a>]<hr width="90%"></div>' . "\n";
    $v_msg = wf_message_for_view($target['message'], $target['wrap']);
    $date = wf_get_time(intval($target['times']));
    echo '<p><table cellspacing=0>' . "\n";
    echo '<tr><td>타이틀</td><td>: <b><font color="' . wf_attr($sub_color) . '">' . $target['sub'] . '</font></b></td></tr>' . "\n";
    echo '<tr><td>글일</td><td>: ' . $date . '</td></tr>' . "\n";
    echo '<tr><td>글자</td><td>: <b>' . $target['name'] . '</b>';
    if ($target['email'] !== '' && $target['smail'] === '0') { echo '&nbsp; &lt;<a href="mailto:' . wf_attr($target['email']) . '" class=num>' . $target['email'] . '</a>&gt;'; }
    echo '</td></tr>' . "\n";
    if ($target['url'] !== '') {
        $url = preg_match('|^https?://|', $target['url']) ? $target['url'] : 'http://' . $target['url'];
        echo '<tr><td>참조처</td><td>: <a href="' . wf_attr($url) . '" target="_blank">' . $url . '</a></td></tr>' . "\n";
    }
    echo '</table><blockquote>' . $v_msg . '</blockquote><p>' . "\n";
    if (count($thread) > 1) {
        echo "<hr width='95%'><b style='text-indent:18'>- 관련 일람 트리</b>\n";
        echo '(' . wf_h($treehead) . ' 를 클릭하면 트리 전체를 일괄 가리킵니다)<br>' . "\n";
        $x = 0; echo '<ul>' . "\n";
        foreach ($thread as $r) {
            $lx = intval($r['lx']);
            while ($x > $lx) { echo '</ul>' . "\n"; $x--; }
            while ($x < $lx) { echo '<ul>' . "\n"; $x++; }
            $sub = wf_cut_subject($r['sub']);
            if ($lx != 0) { echo '<li><a href="' . wf_attr($script . '?' . $gqhako . 'no=' . $r['no'] . '&reno=' . $r['reno'] . '&oya=' . $r['oya'] . '&mode=msgview&page=' . $page) . '">' . $sub . '</a> - <B>' . $r['name'] . '</B> ' . $r['date'] . ' '; }
            else { echo '<a href="' . wf_attr($script . '?' . $gqhako . 'mode=allread&no=' . $r['no'] . '&page=' . $page) . '">' . wf_h($treehead) . '</a> - <a href="' . wf_attr($script . '?' . $gqhako . 'no=' . $r['no'] . '&reno=' . $r['reno'] . '&oya=' . $r['oya'] . '&mode=msgview&page=' . $page) . '">' . $sub . '</a> - <B>' . $r['name'] . '</B> ' . $r['date']; }
            if ((string)$r['no'] === (string)$no_req) { echo '<font color="' . wf_attr($sub_color) . '"><B>No.' . $r['no'] . '</B></font>' . "\n"; }
            else { echo '<font color="' . wf_attr($no_color) . '">No.' . $r['no'] . '</font>' . "\n"; }
        }
        while ($x > 0) { echo '</ul>' . "\n"; $x--; }
        echo '</ul>' . "\n";
    }
    wf_msg_form();
    echo '</body>' . "\n</html>\n";
    exit;
}







function wf_allread() {
    global $in, $script, $gqhako, $page, $tbl_color, $sub_color;
    wf_header();
    echo '[<a href="' . wf_attr($script . '?' . $gqhako . 'page=' . $page . '&mode=' . wf_form_value('act')) . '">리스트에 돌아온다</a>]<br>' . "\n";
    echo '<table width="100%"><tr><th class="obi">일괄 표시</th></tr></table>' . "\n";
    list($top, $records) = wf_read_records();
    $new = array();
    $no_req = wf_form_value('no');
    echo '<ul>' . "\n"; $x = 0; $flag = false;
    foreach ($records as $r) {
        if ((string)$r['oya'] === (string)$no_req) {
            $flag = true; $new[] = $r; $lx = intval($r['lx']);
            while ($x > $lx) { echo '</ul>' . "\n"; $x--; }
            while ($x < $lx) { echo '<ul>' . "\n"; $x++; }
            $sub = wf_cut_subject($r['sub']);
            if ($r['ango'] === 'DEL') { echo '<li>' . $sub . ' - ' . $r['date'] . ' <font color="#008000">No.' . $r['no'] . '</font>' . "\n"; }
            else { echo '<li><a href="#' . wf_attr($r['no']) . '">' . $sub . '</a> - <B>' . $r['name'] . '</B> ' . $r['date'] . ' <font color="#008000">No.' . $r['no'] . '</font>' . "\n"; }
        } elseif ($flag) { break; }
    }
    while ($x > 0) { echo '</ul>' . "\n"; $x--; }
    echo '</ul><div align=\'center\'>' . "\n";
    foreach ($new as $r) {
        if ($r['ango'] === 'DEL') { continue; }
        $msg = wf_message_for_view($r['message'], $r['wrap']);
        $date = wf_get_time(intval($r['times']));
        echo '<a name="' . wf_attr($r['no']) . '"></a>' . "\n";
        echo '<table border="1" width="95%" cellpadding="5">' . "\n";
        echo '<tr><td bgcolor="' . wf_attr($tbl_color) . '"><table cellspacing="0">';
        echo '<tr><td>타이틀</td><td>: <b style="color:' . wf_attr($sub_color) . '">' . $r['sub'] . '</b></td></tr>' . "\n";
        echo '<tr><td>기사 No</td><td>: <b>' . $r['no'] . '</b></td></tr>' . "\n";
        echo '<tr><td>글일</td><td>: ' . $date . '</td></tr>' . "\n";
        echo '<tr><td>글자</td><td>: <b>' . $r['name'] . '</b> ';
        if ($r['email'] !== '' && $r['smail'] === '0') { echo '&nbsp; &lt;<a href="mailto:' . wf_attr($r['email']) . '" class=num>' . $r['email'] . '</a>&gt;'; }
        echo '</td></tr>' . "\n";
        
        if ($r['url'] !== '') { $url = preg_match('|^https?://|', $r['url']) ? $r['url'] : 'http://' . $r['url']; echo '<tr><td>참조처</td><td>: <a href="' . wf_attr($url) . '" target="_blank">' . $url . '</a></td></tr>' . "\n"; }
        echo '</table><blockquote>' . $msg . '</blockquote>' . "\n";
        echo '<div align=right>' . "\n";
        echo '<form action="' . wf_attr($script) . '#msg" method="post">' . "\n";
        echo wf_hidden_camp() . "\n" . '<input type="hidden" name="mode" value=msgview>' . "\n";
        echo '<input type="hidden" name="reno" value="' . wf_attr($r['reno']) . '">' . "\n";
        echo '<input type="hidden" name="no" value="' . wf_attr($r['no']) . '">' . "\n";
        echo '<input type="hidden" name="oya" value="' . wf_attr($r['oya']) . '">' . "\n";
        echo '<input type="hidden" name="page" value="' . intval($page) . '">' . "\n";
        echo '<input type="submit" value="답장하는"></form></div>' . "\n";
        echo '</td></tr></table><br>' . "\n";
    }
    echo '</div>' . "\n</body>\n</html>\n";
    exit;
}







function wf_newsort() {
    global $script, $gqhako, $page, $sortcnt, $tbl_color, $sub_color;
    wf_header();
    echo '[<a href="' . wf_attr($script . '?' . $gqhako . 'page=' . $page) . '">리스트에 돌아온다</a>]' . "\n";
    echo '<table width="100%"><tr><th class="obi">신착 기사</th></tr></table>' . "\n<br><div align=\"center\">\n";
    list($top, $records) = wf_read_records();
    
    $records = array_values(array_filter($records, function($r) { return $r["ango"] !== "DEL"; }));
    usort($records, 'wf_sort_records_time_desc');
    $i = 0;
    foreach ($records as $r) {
        $i++; if ($i > $sortcnt) { break; }
        $msg = wf_message_for_view($r['message'], $r['wrap']);
        $date = wf_get_time(intval($r['times']));
        echo '<table border="1" width="95%" cellpadding="5">' . "\n";
        echo '<tr><td bgcolor="' . wf_attr($tbl_color) . '">' . "\n";
        echo '<table cellspacing="0"><tr><td>타이틀</td><td>: <font color="' . wf_attr($sub_color) . '"><b>' . $r['sub'] . '</b></font></td></tr>';
        echo '<tr><td>기사 No</td><td>: <b>' . $r['no'] . '</b> &nbsp;&nbsp;[<a href="' . wf_attr($script . '?' . $gqhako . 'mode=allread&no=' . $r['oya']) . '">관련 기사</a>]</td></tr>' . "\n";
        echo '<tr><td>글일</td><td>: ' . $date . '</td></tr>' . "\n";
        echo '<tr><td>글자</td><td>: <b>' . $r['name'] . '</b> ';
        if ($r['email'] !== '' && $r['smail'] === '0') { echo '&nbsp; &lt;<a href="mailto:' . wf_attr($r['email']) . '" class=num>' . $r['email'] . '</a>&gt;'; }
        echo '</td></tr>' . "\n";
        if ($r['url'] !== '') { $url = preg_match('|^https?://|', $r['url']) ? $r['url'] : 'http://' . $r['url']; echo '<tr><td>참조처</td><td>: <a href="' . wf_attr($url) . '" target="_blank">' . $url . '</a></td></tr>' . "\n"; }
        echo '</table><blockquote>' . $msg . '</blockquote>' . "\n";
        echo '<div align="right"><form action="' . wf_attr($script) . '#msg" method="post">' . "\n";
        echo wf_hidden_camp() . "\n" . '<input type="hidden" name="mode" value=msgview>' . "\n";
        echo '<input type="hidden" name="reno" value="' . wf_attr($r['reno']) . '">' . "\n";
        echo '<input type="hidden" name="no" value="' . wf_attr($r['no']) . '">' . "\n";
        echo '<input type="hidden" name="oya" value="' . wf_attr($r['oya']) . '">' . "\n";
        echo '<input type="hidden" name="page" value="' . intval($page) . '">' . "\n";
        echo '<input type="submit" value="답장하는"></div></form>' . "\n";
        echo '</td></tr></table><br>' . "\n";
    }
    echo '</div>' . "\n</body>\n</html>\n";
    exit;
}







function wf_note() {
    global $script, $gqhako, $max, $new_time, $newmark;
    wf_header();
    echo <<<HTML
<table width="100%"><tr>
<th class="obi">유의 사항</th>
</tr></table>
<P>
<b style="text-indent:10">- 글을 올릴때의  주의 사항 -</b>
<P>
<ul>
<li>글을 올리는데 있어서 필수 입력 항목은<b>「이름」 「메일 주소」 「타이틀」 「내용」</b>입니다. 그 외의 항목은 선택 사항이 됩니다.
<li>글을 올릴 시에<B>「패스워드」</B>를 입력해 두면, 그 패스워드를 사용해 자신의 글을 수정·삭제할 수가 있습니다.
<li>메일 주소의 입력시에,<b>「비표시」</b>에 체크를 넣어 두는 것으로, 메일 주소를 비표시로 할 수가 있습니다. (관리자 밖에 모릅니다)
<li>올린 글의 최대 보관 유지 건수는 <b>$max</b>건으로, 그것을 넘으면 오래된 글부터 삭제됩니다.
<li>글 내용에서는,<b>HTML 태그의 사용은 할 수 없습니다. </b>
<li>관리자가 현저하게 불이익이라고 판단하는 기사나 타인을 비방 중상하는 글은 예고 없게 삭제 당할 수 있습니다.
</ul>
<P>
<b style="text-indent:10">- 게시판의 사용법 -</b>
<P>
<ul>
<li>이 게시판은 트리식 게시판입니다. 누군가가 올린 글에 대해, 간단하게 댓글을 적을수 있습니다.
<li>신규의 기사 글는 리스트의 「글 폼」으로부터 송신해 주세요.
<li>기사를 읽으려면 , 리스트에 있는<b>「제목」</b>을 클릭하면 내용이 나타납니다. 또 그 기사에<b>레스</b>를 붙이려면 , 「내용 표시화면」하부의 답신용 글 폼으로부터 송신해 주세요.
<li>글된 글은,$new_time 시간 이내는 리스트에 {$newmark}로 나타납니다.
<li>리스트에서, 트리 선두의 ★ 을 클릭하면 관련 기사도 동시에 일괄 나타납니다.
<li>내용 폼내의 글 서식에는 이하의 3 방법이 있어, 각각 적응하는 라디오 버튼을 선택합니다.
  <DL>
  <DT><b>「수동 개행」</b>
  <DD>폼내의 개행 위치는, 자신으로 적당 개행합니다.
  <DT><b>「강제 개행」</b>
  <DD>폼내의 개행 위치는, 폼 범위의 우단에서 강제적으로 개행 처리합니다.
  <DT><b>「도표 모드」</b>
  <DD>폼내의 개행 위치나 반각 스페이스 위치등을 그대로의 상태로 가리킵니다. 괘선등을 사용해 간이적인 도표 를 기술하는데 편리합니다. (HTML에서&lt;PRE&gt;태그로 둘러싸는 기능)
  </DL>
</ul>
</OL>
<hr>
<P>
<center>
<form>
<input type="button" value="기사 리스트에 돌아온다" onclick="history.back()">
</form>
</center>
</body>
</html>
HTML;
    exit;
}







function wf_find() {
    global $script, $gqhako, $pqhako, $in, $page;
    if (!isset($in['view']) || intval($in['view']) <= 0) { $in['view'] = 10; }
    if (!isset($in['cond']) || $in['cond'] === '') { $in['cond'] = 'AND'; }
    wf_header();
    echo '[<a href="' . wf_attr($script . '?' . $gqhako . 'page=' . $page . '&list=' . wf_form_value('list')) . '">리스트에 돌아온다</a>]' . "\n";
    echo '<table width="100%"><tr><th class="obi">워드 검색</th></tr></table>' . "\n";
    echo '<p><a name="SEARCH"></a><ul>' . "\n";
    echo '<li>검색하고 싶은 키워드를 입력해, 검색 조건을 선택해 「검색」을 눌러 주세요.' . "\n";
    echo '<li>복수의 키워드를 입력할 때는 스페이스에서 단락지어 주세요.' . "\n";
    echo '<form action="' . wf_attr($script) . '" method="get">' . "\n";
    echo $pqhako . "\n";
    echo '<input type="hidden" name="mode" value="find">' . "\n";
    echo '<input type="hidden" name="list" value="' . wf_attr(wf_form_value('list')) . '">' . "\n";
    echo '키워드：<input type="text" name="word" size="35" value="' . wf_attr(wf_form_value('word')) . '">' . "\n";
    echo '조건：<select name="cond">' . "\n";
    foreach (array('AND','OR') as $c) { echo '<option value="' . $c . '"' . ($in['cond'] === $c ? ' selected' : '') . '>' . $c . "\n"; }
    echo '</select> 표시：<select name="view">' . "\n";
    foreach (array(10,15,20,25,30) as $v) { echo '<option value="' . $v . '"' . (intval($in['view']) === $v ? ' selected' : '') . '>' . $v . "건\n"; }
    echo '</select>' . "\n" . '<input type="submit" value=" 검색 "></form>' . "\n</ul>\n";
    if (wf_form_value('word') !== '') { wf_search(); }
    echo '</body>' . "\n</html>\n";
    exit;
}







function wf_search() {
    global $in, $page, $script, $gqhako, $sub_color;
    $words = preg_split('/\s+/u', trim(str_replace('　', ' ', wf_form_value('word'))));
    $view = intval($in['view']); if ($view <= 0) { $view = 10; }
    list($top, $records) = wf_read_records();
    $matches = array();
    foreach ($records as $r) {
        $hay = implode('<>', $r);
        $ok = ($in['cond'] === 'OR') ? false : true;
        foreach ($words as $wd) {
            if ($wd === '') { continue; }
            $hit = (function_exists('mb_stripos') ? mb_stripos($hay, $wd, 0, 'UTF-8') : stripos($hay, $wd)) !== false;
            if ($in['cond'] === 'OR' && $hit) { $ok = true; break; }
            if ($in['cond'] === 'AND' && !$hit) { $ok = false; break; }
        }
        if ($ok) { $matches[] = $r; }
    }
    $i = 0;
    foreach ($matches as $r) {
        $i++;
        if ($i < $page + 1) { continue; }
        if ($i > $page + $view) { continue; }
        $msg = wf_message_for_view($r['message'], $r['wrap']);
        $date = wf_get_time(intval($r['times']));
        echo '<hr><table cellspacing="0">' . "\n";
        echo '<tr><td>타이틀</td><td>: <font color="' . wf_attr($sub_color) . '"><b>' . $r['sub'] . '</b></font></td></tr>' . "\n";
        echo '<tr><td>기사 No</td><td>: <b>' . $r['no'] . '</b> &nbsp;&nbsp;[<a href="' . wf_attr($script . '?' . $gqhako . 'mode=allread&no=' . $r['oya']) . '">관련 기사</a>]</td></tr>' . "\n";
        echo '<tr><td>글일</td><td>: ' . $date . '</td></tr>' . "\n";
        echo '<tr><td>글자</td><td>: <b>' . $r['name'] . '</b> ';
        if ($r['email'] !== '' && $r['smail'] === '0') { echo '&nbsp; &lt;<a href="mailto:' . wf_attr($r['email']) . '" class=num>' . $r['email'] . '</a>&gt;'; }
        echo '</td></tr>' . "\n";
        if ($r['url'] !== '') { $url = preg_match('|^https?://|', $r['url']) ? $r['url'] : 'http://' . $r['url']; echo '<tr><td>참조처</td><td>: <a href="' . wf_attr($url) . '" target="_blank">' . $url . '</a></td></tr>' . "\n"; }
        echo '</table><blockquote>' . $msg . '</blockquote>' . "\n";
    }
    $count = count($matches);
    echo '<hr>검색 결과：<b>' . $count . '</b>건' . "\n";
    $next = $page + $view; $back = $page - $view; $enwd = rawurlencode(wf_form_value('word'));
    if ($back >= 0) { echo '[<a href="' . wf_attr($script . '?' . $gqhako . 'mode=find&page=' . $back . '&word=' . $enwd . '&view=' . $view . '&cond=' . $in['cond']) . '">전의' . $view . '건</a>]' . "\n"; }
    if ($next < $count) { echo '[<a href="' . wf_attr($script . '?' . $gqhako . 'mode=find&page=' . $next . '&word=' . $enwd . '&view=' . $view . '&cond=' . $in['cond']) . '">다음의 ' . $view . '건</a>]' . "\n"; }
    if ($count) { echo '<P><a href="#SEARCH">▲TOP</a>' . "\n"; }
}






function wf_move_list() {
    global $in, $page, $p_tree, $wf_list_i, $script, $gqhako, $mode, $pqhako;
    if (!isset($in['list']) || $in['list'] === '') { $in['list'] = 'tree'; }
    $next = $page + $p_tree; $back = $page - $p_tree; $i = isset($wf_list_i) ? $wf_list_i : 0;
    echo '<p><table><tr>' . "\n";
    if ($back >= 0) {
        echo '<td><form action="' . wf_attr($script) . '" method="get">' . "\n";
        echo $pqhako . "\n";
        if (wf_form_value('pastlog') !== '') { echo '<input type="hidden" name="pastlog" value="' . wf_attr(wf_form_value('pastlog')) . '">' . "\n"; }
        echo '<input type="hidden" name="page" value="' . $back . '">' . "\n";
        if ($mode === 'past') { echo '<input type="hidden" name="mode" value="past">' . "\n"; }
        echo '<input type="hidden" name="list" value="' . wf_attr($in['list']) . '">' . "\n";
        echo '<input type="submit" value="전페이지"></td></form>' . "\n";
    }
    if ($next < $i) {
        echo '<td><form action="' . wf_attr($script) . '" method="get">' . "\n";
        echo $pqhako . "\n";
        if (wf_form_value('pastlog') !== '') { echo '<input type="hidden" name="pastlog" value="' . wf_attr(wf_form_value('pastlog')) . '">' . "\n"; }
        echo '<input type="hidden" name="page" value="' . $next . '">' . "\n";
        if ($mode === 'past') { echo '<input type="hidden" name="mode" value="past">' . "\n"; }
        echo '<input type="hidden" name="list" value="' . wf_attr($in['list']) . '">' . "\n";
        echo '<input type="submit" value="다음 페이지"></td></form>' . "\n";
    }
    echo '<td width="10"></td><td class="num">';
    $x = 1; $y = 0; $z = 0; $tmp = $i;
    while ($tmp > 0) {
        if ($page == $y) { $z++; echo '| <b style="color:red">' . $x . '</b>' . "\n"; }
        else { $z++; echo '| <a href="' . wf_attr($script . '?' . $gqhako . 'page=' . $y . '&list=' . $in['list']) . '">' . $x . '</a>' . "\n"; }
        $x++; $y += $p_tree; $tmp -= $p_tree;
    }
    if ($z) { echo '|'; }
    echo '</td></tr></table><br>' . "\n";
}






function wf_past_view() { wf_error('과거 로그 기능은 현재 설정되어 있지 않습니다'); }






function wf_check() {
    global $logfile, $pastkey, $nofile, $pastdir;
    wf_header();
    echo '<h2>Check Mode</h2><ul>' . "\n";
    echo '<li>로그 패스：' . (file_exists($logfile) ? 'OK' : 'NG → ' . wf_h($logfile)) . "\n";
    if (file_exists($logfile)) { echo '<li>로그 퍼미션：' . (is_readable($logfile) && is_writable($logfile) ? 'OK' : 'NG → ' . wf_h($logfile)) . "\n"; }
    echo '<li>과거 로그：' . ($pastkey ? '설정 있어' : '설정 없음') . "\n";
    echo '</body></html>' . "\n";
    exit;
}
?>
