<?php
















if (!function_exists('wf_pcp_makekey')) {






function wf_pcp_makekey() {
    global $pcp_passwd;
    $code = '';
    for ($i=0; $i<4; $i++) { $code .= mt_rand(0, 9); }
    $plain = $code . time();
    $sig = substr(sha1($plain . '|' . $pcp_passwd), 0, 16);
    $crypt = rtrim(strtr(base64_encode($plain . '|' . $sig), '+/', '-_'), '=');
    return array($plain, rawurlencode($crypt));
}





function wf_registkey_plain($crypt) {
    global $pcp_passwd;
    $crypt = rawurldecode((string)$crypt);
    $pad = strlen($crypt) % 4;
    if ($pad) { $crypt .= str_repeat('=', 4 - $pad); }
    $raw = base64_decode(strtr($crypt, '-_', '+/'));
    if ($raw === false || strpos($raw, '|') === false) { return false; }
    list($plain, $sig) = explode('|', $raw, 2);
    if (substr(sha1($plain . '|' . $pcp_passwd), 0, 16) !== $sig) { return false; }
    return $plain;
}








function wf_registkey_chk($input, $crypt) {
    global $pcp_time;
    $plain = wf_registkey_plain($crypt);
    if ($plain === false || !preg_match('/^(\d{4})(\d+)$/', $plain, $m)) { return -1; }
    if ((string)$input !== (string)$m[1]) { return -1; }
    if (time() - intval($m[2]) > intval($pcp_time) * 60) { return 0; }
    return 1;
}
}
?>
