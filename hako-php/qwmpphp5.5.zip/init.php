<?php





















if (!defined('QHAKO_INIT_LOADED')) {

define('QHAKO_INIT_LOADED', 1);

date_default_timezone_set('Asia/Seoul');







function wf_load_hako_config() {
    static $loaded = false;
    if ($loaded) { return; }
    $loaded = true;
    $paths = array(
        dirname(__FILE__) . '/hako/hako-init.php',
        dirname(__FILE__) . '/hako-init.php',
        dirname(__FILE__) . '/../hako-init.php'
    );
    foreach ($paths as $p) {
        if (is_file($p)) {
            @include_once $p;
            break;
        }
    }
}



$ver = 'Web Forum v5.02';
$home = './hako/hako-main.php';
$title = '진영 게시판';
$c_title = 1;
$t_color = '#004080';
$t_point = '20px';
$t_img = '';
$t_w = 151;
$t_h = 28;

$b_size = '13px';
$b_face = 'MS UI Gothic, Osaka, MS P고딕';

$pass = '0123';
$max = 200;

$bg = '';
$bc = '#EEEEEE';
$te = '#004080';
$li = '#0000FF';
$vl = '#008080';
$al = '#DD0000';

$script = './wforum.php';
$admin = './admin.php';
$regist = './regist.php';
$registkeyphp = './registkey.php';
$foldpl = './fold.php';
$regkeylib = './registkey_lib.php';
$logfile = './data/log.php';

$autolink = 1;
$sub_color = '#dd0000';
$tbl_color = '#FFFFFF';
$new_time = 48;
$newmark = '<font color="#FF3300">new!</font>';
$no_color = '#008000';
$sortcnt = 10;
$p_tree = 10;
$sub_length = 30;

$in_email = 0;
$top_sort = 1;
$bot_res = 1;
$refcol = '#804000';
$backCol = '#004080';
$charCol = '#ffffff';
$postonly = 1;

$mailing = 0;
$mailto = 'xxx@xxx.xxx';
$sendmail = '/usr/lib/sendmail';

$treehead = '▼';
$pastkey = 0;
$nofile = './data/pastno.dat';
$pastdir = './past/';
$max_line = 650;

$gethostbyaddr = 0;
$deny_host = '';
$deny_addr = '';

$no_wd = '';
$jp_wd = 0;
$urlnum = 3;
$maxData = 51200;
$baseUrl = '';
$regCtl = 0;
$wait = 60;

$regist_key = 1;
$pcp_passwd = 'pass0000';
$pcp_time = 30;
$regkey_pt = 10;
$moji_col = '#dd0000';
$back_col = '#EEEEEE';

$Hallygroup = array('무소속','동맹군','연합군','제국군');
$campPass = array('camp1','camp2','camp3','camp4');

$gqhako = '';
$pqhako = '';
$in = array();
$mode = '';
$page = 0;
$headflag = 0;
$post_flag = 0;
$host = '';
$addr = '';
$campID = '';







function wf_apply_hako_globals() {
    global $home, $HthisFile, $Hallygroup, $campPass;
    wf_load_hako_config();
    if (isset($GLOBALS['HthisFile']) && $GLOBALS['HthisFile'] !== '') {
        $home = $GLOBALS['HthisFile'];
    }
    if (isset($GLOBALS['Hallygroup']) && is_array($GLOBALS['Hallygroup'])) {
        $Hallygroup = $GLOBALS['Hallygroup'];
    }
    if (isset($GLOBALS['campPass']) && is_array($GLOBALS['campPass'])) {
        $campPass = $GLOBALS['campPass'];
    }
}







function wf_request_value($v) {
    if (is_array($v)) {
        $out = array();
        foreach ($v as $k => $x) { $out[$k] = wf_request_value($x); }
        return implode("\0", $out);
    }
    $v = str_replace("\0", '', (string)$v);
    return trim($v);
}






function wf_input() {
    $data = array();
    foreach ($_GET as $k => $v) { $data[$k] = wf_request_value($v); }
    foreach ($_POST as $k => $v) { $data[$k] = wf_request_value($v); }
    return $data;
}






function wf_h($s) {
    return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}






function wf_attr($s) {
    return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}






function wf_hidden($name, $value) {
    return '<input type=hidden name=' . wf_attr($name) . ' value=' . wf_attr($value) . '>';
}






function wf_hidden_q($name, $value) {
    return '<input type="hidden" name="' . wf_attr($name) . '" value="' . wf_attr($value) . '">';
}






function wf_query() {
    global $campID, $in;
    $id = ($campID !== '') ? $campID : (isset($in['campID']) ? $in['campID'] : '');
    $pw = isset($in['campPASS']) ? $in['campPASS'] : '';
    if ($id === '') { return ''; }
    return 'campID=' . rawurlencode($id) . '&campPASS=' . rawurlencode($pw) . '&';
}






function wf_hidden_camp() {
    global $campID, $in;
    $id = ($campID !== '') ? $campID : (isset($in['campID']) ? $in['campID'] : '');
    $pw = isset($in['campPASS']) ? $in['campPASS'] : '';
    if ($id === '') { return ''; }
    return '<input type=hidden name=campID value=' . wf_attr($id) . '><input type=hidden name=campPASS value=' . wf_attr($pw) . '>';
}











function wf_boot($requireCamp) {
    global $in, $mode, $page, $post_flag;
    wf_apply_hako_globals();
    $post_flag = (isset($_SERVER['REQUEST_METHOD']) && strtoupper($_SERVER['REQUEST_METHOD']) === 'POST') ? 1 : 0;
    $in = wf_input();
    $mode = isset($in['mode']) ? $in['mode'] : '';
    $page = isset($in['page']) ? intval($in['page']) : 0;
    if ($page < 0) { $page = 0; }
    
    if ($requireCamp) { wf_get_log_name(); }
    wf_axs_check();
}







function wf_get_log_name() {
    global $in, $campPass, $Hallygroup, $gqhako, $pqhako, $logfile, $title, $c_title, $campID;
    $hakoID = isset($in['campID']) ? (string)$in['campID'] : '';
    $hakoPASS = isset($in['campPASS']) ? (string)$in['campPASS'] : '';
    if ($hakoID === '' || !isset($campPass[$hakoID]) || (string)$hakoPASS !== (string)$campPass[$hakoID]) {
        wf_temp_login();
    }
    $campID = $hakoID;
    $gqhako = 'campID=' . rawurlencode($hakoID) . '&campPASS=' . rawurlencode($hakoPASS) . '&';
    $pqhako = '<input type=hidden name=campID value=' . wf_attr($hakoID) . '><input type=hidden name=campPASS value=' . wf_attr($hakoPASS) . '>';
    $dir = './data';
    if (!is_dir($dir)) { @mkdir($dir, 0777, true); }
    $logfile = './data/log_' . preg_replace('/[^0-9A-Za-z_-]/', '', $hakoID) . '.php';
    
    if (!file_exists($logfile) || filesize($logfile) === 0) {
        @file_put_contents($logfile, "0<>" . wf_remote_addr() . "<>" . time() . "<>\n", LOCK_EX);
    }
    if ($c_title && isset($Hallygroup[$hakoID]) && strpos($title, $Hallygroup[$hakoID] . ':') !== 0) {
        $title = $Hallygroup[$hakoID] . ':' . $title;
    }
}






function wf_temp_login() {
    global $script, $Hallygroup;
    wf_header();
    $select_list = '';
    foreach ($Hallygroup as $i => $name) {
        $select_list .= '<OPTION value=' . wf_attr($i) . '>' . wf_h($name) . "\n";
    }
    echo '<div align="center">' . "\n";
    echo '<hr width=400>' . "\n";
    echo '<h3>인증해 주세요.</h3>' . "\n";
    echo '<FORM action="' . wf_attr($script) . '" method="POST">' . "\n";
    echo '<SELECT NAME="campID">' . "\n" . $select_list . '</SELECT>' . "\n";
    echo '<INPUT TYPE="text" NAME="campPASS" VALUE="">' . "\n";
    echo '<INPUT TYPE="submit" VALUE="실행" NAME="cButton">' . "\n";
    echo '</FORM>' . "\n";
    echo '<hr width=400>' . "\n";
    echo '</div></body></html>' . "\n";
    exit;
}







function wf_header($meta = '') {
    global $headflag, $bg, $bc, $te, $li, $vl, $al, $b_size, $b_face, $backCol, $charCol, $title;
    if ($headflag) { return; }
    if (!headers_sent()) { header('Content-Type: text/html; charset=UTF-8'); }
    $bg_attr = ($bg !== '') ? 'background="' . wf_attr($bg) . '"' : '';
    echo "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">\n";
    echo "<html lang=\"ko\">\n<head>\n";
    echo "<META HTTP-EQUIV=\"Content-type\" CONTENT=\"text/html; charset=UTF-8\">\n";
    echo "<META HTTP-EQUIV=\"Content-Style-Type\" content=\"text/css\">\n";
    echo "<STYLE type=\"text/css\">\n<!--\n";
    echo 'body,tr,td,th { font-size:' . $b_size . '; font-family:"' . wf_h($b_face) . '"; }' . "\n";
    echo 'a:hover       { text-decoration:underline; color:' . $al . '; }' . "\n";
    echo ".num          { font-family:Verdana,Helvetica,Arial; }\n";
    echo '.obi          { background-color:' . $backCol . '; color:' . $charCol . '; }' . "\n";
    echo "-->\n</STYLE>\n";
    if ($meta !== '') { echo $meta . "\n"; }
    echo '<title>' . wf_h($title) . "</title></head>\n";
    echo '<body bgcolor="' . wf_attr($bc) . '" text="' . wf_attr($te) . '" link="' . wf_attr($li) . '" vlink="' . wf_attr($vl) . '" alink="' . wf_attr($al) . '" ' . $bg_attr . ">\n";
    $headflag = 1;
}







function wf_error($msg) {
    wf_header();
    echo '<div align="center">' . "\n";
    echo '<hr width="400">' . "\n";
    echo '<h3>ERROR !</h3>' . "\n";
    echo '<font color="#dd0000">' . $msg . '</font>' . "\n";
    echo '<p>' . "\n";
    echo '<hr width="400">' . "\n";
    echo '<p>' . "\n";
    echo '<form>' . "\n";
    echo '<input type="button" value="전화면에 돌아온다" onclick="history.back()">' . "\n";
    echo '</form>' . "\n";
    echo '</div>' . "\n</body>\n</html>\n";
    exit;
}






function wf_remote_addr() {
    return isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '';
}







function wf_axs_check() {
    global $host, $addr, $gethostbyaddr, $deny_addr, $deny_host;
    $host = isset($_SERVER['REMOTE_HOST']) ? $_SERVER['REMOTE_HOST'] : '';
    $addr = wf_remote_addr();
    if ($gethostbyaddr && ($host === '' || $host === $addr) && $addr !== '') { $host = @gethostbyaddr($addr); }
    
    if ($deny_addr !== '') {
        foreach (preg_split('/\s+/', trim($deny_addr)) as $deny) {
            if ($deny === '') { continue; }
            $pat = '/^' . str_replace('\*', '.*', preg_quote($deny, '/')) . '/i';
            if (preg_match($pat, $addr)) { wf_error('액세스가 허가되고 있지 않습니다'); }
        }
    }
    
    if ($deny_host !== '' && $host !== '') {
        foreach (preg_split('/\s+/', trim($deny_host)) as $deny) {
            if ($deny === '') { continue; }
            $pat = '/' . str_replace('\*', '.*', preg_quote($deny, '/')) . '$/i';
            if (preg_match($pat, $host)) { wf_error('액세스가 허가되고 있지 않습니다'); }
        }
    }
}







function wf_get_time($time = 0, $log = '') {
    if (!$time) { $time = time(); }
    if ($log === 'log') { return date('y/m/d-H:i', $time); }
    $week = array('Sun','Mon','Tue','Wed','Thu','Fri','Sat');
    return date('Y/m/d', $time) . '(' . $week[intval(date('w', $time))] . ') ' . date('H:i', $time);
}







function wf_read_records($path = null, $skipTop = true) {
    global $logfile;
    $file = $path ? $path : $logfile;
    
    if (!file_exists($file)) { @file_put_contents($file, "0<>" . wf_remote_addr() . "<>" . time() . "<>\n", LOCK_EX); }
    $lines = @file($file, FILE_IGNORE_NEW_LINES);
    if ($lines === false) { wf_error('Open Error: ' . wf_h($file)); }
    $top = '';
    if ($skipTop && count($lines)) { $top = array_shift($lines); }
    $records = array();
    foreach ($lines as $line) {
        $line = rtrim($line, "\r\n");
        if ($line === '') { continue; }
        $records[] = wf_parse_record($line);
    }
    return array($top, $records);
}







function wf_write_records($top, $records) {
    global $logfile, $max;
    $out = rtrim($top, "\r\n");
    if ($out === '') { $out = '0<>' . wf_remote_addr() . '<>' . time() . '<>'; }
    $out .= "\n";
    $n = 0;
    foreach ($records as $r) {
        if ($n >= $max) { break; }
        $out .= wf_record_line($r) . "\n";
        $n++;
    }
    @file_put_contents($logfile, $out, LOCK_EX);
}







function wf_parse_record($line) {
    $p = explode('<>', $line);
    
    while (count($p) < 17) { $p[] = ''; }
    return array(
        'no'=>$p[0], 'reno'=>$p[1], 'lx'=>$p[2], 'sub'=>$p[3], 'email'=>$p[4],
        'url'=>$p[5], 'name'=>$p[6], 'date'=>$p[7], 'message'=>$p[8], 'times'=>$p[9],
        'host'=>$p[10], 'ango'=>$p[11], 'wrap'=>$p[12], 'oya'=>$p[13], 'smail'=>$p[14],
        'del'=>$p[15], 'tail'=>$p[16]
    );
}







function wf_record_line($r) {
    
    $keys = array('no','reno','lx','sub','email','url','name','date','message','times','host','ango','wrap','oya','smail','del','tail');
    $vals = array();
    foreach ($keys as $k) {
        $v = isset($r[$k]) ? (string)$r[$k] : '';
        $v = str_replace(array("\r", "\n", '<>'), array('', '<br>', ''), $v);
        $vals[] = $v;
    }
    return implode('<>', $vals);
}






function wf_top_count($top) {
    $p = explode('<>', $top);
    return isset($p[0]) ? intval($p[0]) : 0;
}






function wf_make_top($count) {
    return intval($count) . '<>' . wf_remote_addr() . '<>' . time() . '<>';
}






function wf_cut_subject($sub) {
    global $sub_length;
    $sub = (string)$sub;
    if (function_exists('mb_strimwidth')) {
        if (mb_strwidth($sub, 'UTF-8') <= $sub_length) { return $sub; }
        return mb_strimwidth($sub, 0, $sub_length, '..', 'UTF-8');
    }
    if (strlen($sub) <= $sub_length) { return $sub; }
    return substr($sub, 0, max(0, $sub_length - 2)) . '..';
}






function wf_auto_link($msg) {
    return preg_replace('/([^=^"]|^)(https?:\/\/[\w\.\~\-\/\?\&\=\;\#\:\%\+\@]+)/i', '$1<a href="$2" target="_blank">$2</a>', $msg);
}









function wf_message_for_view($msg, $wrap) {
    global $autolink, $refcol;
    
    if ($autolink) { $msg = wf_auto_link($msg); }
    if ($refcol) {
        $msg = preg_replace('/([\>]|^)(&gt;[^<]*)/u', '$1<font color="' . $refcol . '">$2</font>', $msg);
    }
    if ($wrap === 'pre') {
        $msg = str_replace('<br>', "\n", $msg);
        $msg = '<pre>' . $msg . '</pre>';
    }
    return $msg;
}






function wf_get_cookie() {
    if (empty($_COOKIE['webforum'])) { return array('', '', 'http://', '', '', '0'); }
    $parts = explode(',', $_COOKIE['webforum']);
    while (count($parts) < 6) { $parts[] = ''; }
    return $parts;
}






function wf_set_cookie($name, $email, $url, $pwd, $pview, $smail) {
    $val = implode(',', array($name, $email, $url, $pwd, $pview, $smail));
    if (!headers_sent()) { setcookie('webforum', $val, time() + 60*60*24*30); }
}






function wf_form_value($key, $default = '') {
    global $in;
    return isset($in[$key]) ? $in[$key] : $default;
}






function wf_sanitize_post_value($s) {
    $s = str_replace("\0", '', (string)$s);
    $s = str_replace("\t", '', $s);
    return wf_h($s);
}






function wf_sanitize_message($s, $wrap) {
    $s = str_replace("\0", '', (string)$s);
    $s = str_replace("\t", '', $s);
    $s = str_replace(array("\r\n", "\r"), "\n", $s);
    $s = wf_h($s);
    $s = str_replace("\n", '<br>', $s);
    return $s;
}







function wf_check_form() {
    global $in, $postonly, $post_flag, $in_email, $urlnum;
    if ($postonly && !$post_flag) { wf_error('부정한 액세스입니다'); }
    $err = '';
    if (!isset($in['name']) || trim($in['name']) === '') { $err .= '이름 입력을 하세요<br>'; }
    if (!isset($in['message']) || trim(str_replace(array('<br>', "\r", "\n"), '', $in['message'])) === '') { $err .= '내용 입력을 하세요<br>'; }
    if ($in_email && (!isset($in['email']) || !preg_match('/^[\w\.\-]+\@[\w\.\-]+\.[a-zA-Z]{2,5}$/', $in['email']))) { $err .= 'E-Mail의 입력이 부정합니다<br>'; }
    if (!isset($in['sub']) || trim($in['sub']) === '') { $err .= '제목 입력을 하세요<br>'; }
    if (isset($in['url']) && $in['url'] === 'http://') { $in['url'] = ''; }
    if ($urlnum > 0 && isset($in['message'])) {
        if (preg_match_all('/https?:\/\//i', $in['message'], $m) > $urlnum) { $err .= 'URL의 개수가 너무 많습니다<br>'; }
    }
    if ($err !== '') { wf_error($err); }
}







function wf_msg_form($type = '') {
    global $in, $mode, $regist, $pqhako, $page, $regist_key, $regkeylib, $registkeyphp, $sub_color;
    
    list($cname, $cmail, $curl, $cpwd, $cpv, $csmail) = wf_get_cookie();
    if ($curl === '') { $curl = 'http://'; }
    $res_sub = '';
    $res_msg = '';
    $wrap = 'soft';
    
    if ($type === 'edt') {
        $args = func_get_args();
        $cname = isset($args[1]) ? $args[1] : $cname;
        $cmail = isset($args[2]) ? $args[2] : $cmail;
        $curl = isset($args[3]) ? $args[3] : $curl;
        $csmail = isset($args[4]) ? $args[4] : $csmail;
        $res_sub = isset($args[5]) ? $args[5] : '';
        $res_msg = isset($args[6]) ? $args[6] : '';
        $wrap = isset($args[7]) && $args[7] !== '' ? $args[7] : 'soft';
        echo "<form><input type=button value='전화면에 돌아오는' onClick='history.back()'></form>\n";
        echo "<h3>수정 폼</h3>\n";
        echo '<form action="' . wf_attr($regist) . '" method="post">' . "\n";
        echo $pqhako . '<input type=hidden name=mode value="usr_edt">' . "\n";
        echo '<input type=hidden name=action value="edit">' . "\n";
        echo '<input type=hidden name=pwd value="' . wf_attr(wf_form_value('pwd')) . '">' . "\n";
        echo '<input type=hidden name=no value="' . wf_attr(wf_form_value('no')) . '">' . "\n";
    
    } elseif ($mode === 'msgview' || $mode === 'msg') {
        $wrap = 'soft';
        echo '<hr width="95%"><a name="msg"></a>' . "\n";
        echo '<b style="text-indent:18">- 답신 폼</b>' . "\n";
        echo '이 기사에 답장하는 경우는 아래와 같이 폼으로부터 글해 주세요<br>' . "\n";
        echo '<form action="' . wf_attr($regist) . '" method="post">' . "\n";
        echo $pqhako . '<input type="hidden" name="mode" value="form">' . "\n";
        echo '<input type="hidden" name="page" value="' . intval($page) . '">' . "\n";
        echo '<input type="hidden" name="action" value="res_msg">' . "\n";
        echo '<input type="hidden" name="no" value="' . wf_attr(wf_form_value('no')) . '">' . "\n";
        echo '<input type="hidden" name="oya" value="' . wf_attr(wf_form_value('oya')) . '">' . "\n";
        $res_sub = isset($GLOBALS['wf_reply_sub']) ? $GLOBALS['wf_reply_sub'] : '';
        $res_msg = isset($GLOBALS['wf_reply_msg']) ? $GLOBALS['wf_reply_msg'] : '';
    } else {
        $wrap = 'soft';
        echo '<hr width="95%"><p><a name="msg"></a><div align="center">' . "\n";
        echo '<b><big>내용를 부탁합니다··</big></b></a></div>' . "\n";
        echo '<P><form action="' . wf_attr($regist) . '" method="post">' . "\n";
        echo $pqhako . '<input type="hidden" name="mode" value="form">' . "\n";
        echo '<input type="hidden" name="page" value="' . intval($page) . '">' . "\n";
        echo '<input type="hidden" name="no" value="new">' . "\n";
    }
    echo '<blockquote><table border="0" cellspacing="0" cellpadding="1">' . "\n";
    echo '<tr><td><b>이름</b></td><td><input type="text" name="name" size="28" value="' . wf_attr($cname) . '"></td></tr>' . "\n";
    echo '<tr><td><b>E메일</b></td><td><input type="text" name="email" size="28" value="' . wf_attr($cmail) . '"> ' . "\n";
    echo '<select name="smail">' . "\n";
    $sm = array('표시', '비표시');
    if ($csmail === '') { $csmail = 0; }
    foreach (array(0,1) as $i) {
        echo '<option value="' . $i . '"' . ((string)$csmail === (string)$i ? ' selected' : '') . '>' . $sm[$i] . "\n";
    }
    echo '</select></td></tr>' . "\n";
    echo '<tr><td><b>타이틀</b></td><td><input type="text" name="sub" size="38" value="' . wf_attr($res_sub) . '"></td></tr>' . "\n";
    echo '<tr><td colspan="2"><b>내용</b>&nbsp;&nbsp;&nbsp;';
    $w1 = array('수동 개행', '강제 개행', '도표 모드');
    $w2 = array('soft', 'hard', 'pre');
    foreach ($w2 as $idx => $wv) {
        echo '<input type="radio" name="wrap" value="' . $wv . '"' . ($wrap === $wv ? ' checked' : '') . '>' . $w1[$idx] . "\n";
    }
    $checked = ($cpv === 'on') ? 'checked' : '';
    echo '<br><textarea name="message" rows="10" cols="62">' . wf_h(str_replace('<br>', "\n", $res_msg)) . '</textarea>';
    echo '</td></tr><tr><td><b>참조처</b></td><td><input type="text" name="url" size="58" value="' . wf_attr($curl) . '"></td></tr>' . "\n";
    if ($type === 'edt') {
        echo '<tr><td></td><td><input type="submit" value=" 기사를 수정하는 "></td>' . "\n";
        echo '</tr></table></form></blockquote>' . "\n";
        return;
    }
    echo '<tr>' . "\n";
    echo '  <td><b>패스워드</b></td>' . "\n";
    echo '  <td><input type="password" name="pwd" size="8" value="' . wf_attr($cpwd) . '" maxlength=8>' . "\n";
    echo '    (영숫자로 8 문자 이내)</td>' . "\n";
    echo '</tr>' . "\n";
    
    if ($regist_key) {
        require_once dirname(__FILE__) . '/registkey_lib.php';
        list($str_plain, $str_crypt) = wf_pcp_makekey();
        echo '<tr><td><b>인증 키</b></td>';
        echo '<td><input type="text" name="regikey" size="6" style="ime-mode:inactive" value="">' . "\n";
        echo '(인증 키 <img src="' . wf_attr($registkeyphp . '?' . $str_crypt) . '" align="absmiddle" alt="인증 키"> 를 입력해 주세요)</td></tr>' . "\n";
        echo '<input type="hidden" name="str_crypt" value="' . wf_attr($str_crypt) . '">' . "\n";
    }
    echo '<tr>' . "\n";
    echo '  <td></td>' . "\n";
    echo '  <td><input type="submit" value=" 글을 올린다 ">' . "\n";
    echo '     &nbsp; <input type="checkbox" name="pview" value="on" ' . $checked . '>미리보기</td>' . "\n";
    echo '</tr>' . "\n";
    echo '</table>' . "\n";
    echo '</form>' . "\n";
    echo '</blockquote>' . "\n";
    echo '<hr width="95%">' . "\n";
    echo '<div align="center">' . "\n";
    echo '<form action="' . wf_attr($regist) . '" method="post">' . "\n";
    echo $pqhako . "\n";
    echo '<input type="hidden" name="page" value="' . intval($page) . '">' . "\n";
    echo '<font color="' . wf_attr($sub_color) . '">' . "\n";
    echo '- 이하의 폼으로부터 자신의 올린 글을 수정·삭제할 수가 있습니다-</font><br>' . "\n";
    echo '처리 <select name="mode">' . "\n";
    echo '<option value="usr_edt">수정' . "\n";
    echo '<option value="usr_del">삭제' . "\n";
    echo '</select>' . "\n";
    echo '기사 No<input type="text" name="no" size="4" style="ime-mode:inactive">' . "\n";
    echo '패스워드 <input type="password" name="pwd" size="6">' . "\n";
    echo '<input type="submit" value="송신"></form>' . "\n";
    echo '<hr width="95%"></div>' . "\n";
}






function wf_find_record_by_no($records, $no) {
    foreach ($records as $r) { if ((string)$r['no'] === (string)$no) { return $r; } }
    return null;
}







function wf_reply_subject($sub) {
    if (preg_match('/^Re\^(\d+)\:(.*)$/u', $sub, $m)) { return 'Re^' . (intval($m[1]) + 1) . ':' . $m[2]; }
    if (preg_match('/^Re\:(.*)$/u', $sub, $m)) { return 'Re^2:' . $m[1]; }
    return 'Re: ' . $sub;
}






function wf_encrypt($pwd) {
    if ($pwd === '') { return ''; }
    return substr(crypt($pwd, 'wf'), 0, 13);
}






function wf_check_password($pwd, $hash) {
    if ($hash === '') { return false; }
    return (crypt($pwd, $hash) === $hash || $pwd === $hash);
}

}
?>
