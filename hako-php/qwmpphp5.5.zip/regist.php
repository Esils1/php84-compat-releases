<?php




















require_once './init.php';
require_once './fold.php';
require_once './registkey_lib.php';

wf_boot(true);








if ($mode === 'regist') { wf_regist_exec(); }
elseif ($mode === 'form' && wf_form_value('pview') !== 'on') { wf_regist_exec(); }
elseif ($mode === 'form' && wf_form_value('pview') === 'on') { wf_preview(); }
elseif ($mode === 'usr_del') { wf_user_delete(); }
elseif ($mode === 'usr_edt') { wf_user_edit(); }
wf_error('불명한 처리입니다');







function wf_check_regist_key() {
    global $regist_key, $in;
    if (!$regist_key) { return; }
    if (!isset($in['regikey']) || !preg_match('/^\d{4}$/', $in['regikey'])) {
        wf_error('인증 키가 입력 불비합니다. <p>글 폼에 돌아와 다시 읽기 보고 후, 지정의 숫자를 입력해 주세요');
    }
    $chk = wf_registkey_chk($in['regikey'], isset($in['str_crypt']) ? $in['str_crypt'] : '');
    if ($chk == 0) { wf_error('인증 키가 제한 시간을 초과했습니다. <p>글 폼에 돌아와 다시 읽기 보고 후, 지정의 숫자를 재입력해 주세요'); }
    if ($chk == -1) { wf_error('인증 키가 부정합니다. <p>글 폼에 돌아와 다시 읽기 보고 후, 지정의 숫자를 입력해 주세요'); }
}







function wf_prepare_in_for_write() {
    global $in;
    $wrap = isset($in['wrap']) ? $in['wrap'] : 'soft';
    $fields = array('sub','email','url','name','pwd','smail','oya','no','page','action','pview');
    foreach ($fields as $f) { if (isset($in[$f])) { $in[$f] = wf_sanitize_post_value($in[$f]); } }
    if (!isset($in['url']) || $in['url'] === 'http://') { $in['url'] = ''; }
    $in['wrap'] = in_array($wrap, array('soft','hard','pre')) ? $wrap : 'soft';
    $in['message'] = wf_sanitize_message(isset($in['message']) ? $in['message'] : '', $in['wrap']);
}














function wf_regist_exec() {
    global $in, $logfile, $top_sort, $bot_res, $page, $script, $gqhako;
    
    wf_check_form();
    
    wf_check_regist_key();
    wf_prepare_in_for_write();
    
    list($top, $records) = wf_read_records();
    $count = wf_top_count($top);
    $count = ($count % 9999) ? $count + 1 : 1;
    $times = time();
    $date = wf_get_time($times, 'log');
    foreach ($records as $r) {
        if ($in['name'] === $r['name'] && $in['message'] === $r['message']) { wf_error('이중 글는 금지입니다'); }
    }
    wf_set_cookie($in['name'], $in['email'], $in['url'], isset($in['pwd']) ? $in['pwd'] : '', wf_form_value('pview'), wf_form_value('smail'));
    $ango = (isset($in['pwd']) && $in['pwd'] !== '') ? wf_encrypt($in['pwd']) : '';
    $host = isset($_SERVER['REMOTE_HOST']) && $_SERVER['REMOTE_HOST'] !== '' ? $_SERVER['REMOTE_HOST'] : wf_remote_addr();
    if ($in['no'] === 'new' || $in['no'] === '') {
        $newRecord = array('no'=>$count,'reno'=>'no','lx'=>0,'sub'=>$in['sub'],'email'=>$in['email'],'url'=>$in['url'],'name'=>$in['name'],'date'=>$date,'message'=>$in['message'],'times'=>$times,'host'=>$host,'ango'=>$ango,'wrap'=>$in['wrap'],'oya'=>$count,'smail'=>wf_form_value('smail','0'),'del'=>'0','tail'=>'');
        array_unshift($records, $newRecord);
    
    } else {
        $parentNo = $in['no'];
        $oya = isset($in['oya']) && $in['oya'] !== '' ? $in['oya'] : $parentNo;
        $newRecord = null;
        $newRecords = array();
        $tmp = array();
        $flag = 0; $inserted = false; $lx2 = 1;
        
        if ($top_sort) {
            foreach ($records as $r) {
                $lx = intval($r['lx']);
                if ($bot_res && $flag == 1 && $lx2 > $lx && (string)$r['oya'] === (string)$oya) {
                    $newRecords[] = wf_make_reply_record($count, $parentNo, $lx2, $in, $date, $times, $host, $ango, $oya);
                    $inserted = true; $flag = 2;
                }
                if ((string)$r['no'] === (string)$parentNo) {
                    $r['del'] = (string)(intval($r['del']) + 1);
                    $newRecords[] = $r;
                } elseif ((string)$r['oya'] === (string)$oya) {
                    $newRecords[] = $r;
                } else {
                    $tmp[] = $r;
                }
                if ((string)$r['no'] === (string)$parentNo) {
                    $flag = 1; $lx2 = intval($r['lx']) + 1;
                    if (!$bot_res) { $newRecords[] = wf_make_reply_record($count, $parentNo, $lx2, $in, $date, $times, $host, $ango, $oya); $inserted = true; }
                }
            }
            if ($flag == 0) { wf_error('친기사가 눈에 띄지 않습니다'); }
            if ($bot_res && !$inserted) { $newRecords[] = wf_make_reply_record($count, $parentNo, $lx2, $in, $date, $times, $host, $ango, $oya); }
            $records = array_merge($newRecords, $tmp);
        } else {
            foreach ($records as $r) {
                $lx = intval($r['lx']);
                if ($bot_res && $flag == 1 && $lx2 > $lx && ((string)$r['reno'] !== (string)$parentNo || (string)$r['oya'] !== (string)$oya)) {
                    $newRecords[] = wf_make_reply_record($count, $parentNo, $lx2, $in, $date, $times, $host, $ango, $oya);
                    $inserted = true; $flag = 2;
                }
                if ((string)$r['no'] === (string)$parentNo) { $r['del'] = (string)(intval($r['del']) + 1); $newRecords[] = $r; }
                else { $newRecords[] = $r; }
                if ((string)$r['no'] === (string)$parentNo) {
                    $flag = 1; $lx2 = intval($r['lx']) + 1;
                    if (!$bot_res) { $newRecords[] = wf_make_reply_record($count, $parentNo, $lx2, $in, $date, $times, $host, $ango, $oya); $inserted = true; }
                }
            }
            if ($flag == 0) { wf_error('친기사가 눈에 띄지 않습니다'); }
            if ($bot_res && !$inserted) { $newRecords[] = wf_make_reply_record($count, $parentNo, $lx2, $in, $date, $times, $host, $ango, $oya); }
            $records = $newRecords;
        }
    }
    $top = wf_make_top($count);
    wf_write_records($top, $records);
    if (wf_form_value('pview') === 'on') {
        wf_header('<META HTTP-EQUIV="refresh" CONTENT="0; URL=' . wf_attr($script . '?' . $gqhako) . '">');
        echo '<div align="center">정상적으로 수리했던' . "\n";
        echo '<p>점프 하지 않는 경우는<a href="' . wf_attr($script . '?' . $gqhako) . '">여기</a>를 클릭' . "\n";
        echo '</div></body></html>' . "\n";
        exit;
    }
    wf_after();
}







function wf_make_reply_record($count, $parentNo, $lx, $in, $date, $times, $host, $ango, $oya) {
    return array('no'=>$count,'reno'=>$parentNo,'lx'=>$lx,'sub'=>$in['sub'],'email'=>$in['email'],'url'=>$in['url'],'name'=>$in['name'],'date'=>$date,'message'=>$in['message'],'times'=>$times,'host'=>$host,'ango'=>$ango,'wrap'=>$in['wrap'],'oya'=>$oya,'smail'=>wf_form_value('smail','0'),'del'=>'0','tail'=>'');
}







function wf_preview() {
    global $in, $regist, $pqhako, $tbl_color;
    wf_check_form();
    wf_check_regist_key();
    wf_prepare_in_for_write();
    $email = (wf_form_value('smail') == '1') ? '비표시' : $in['email'];
    wf_header();
    echo '<div align="center">' . "\n";
    echo '▼이하의 내용으로 내용를 글합니다. 확인해 주십시오.' . "\n";
    echo '<form action="' . wf_attr($regist) . '" method="post">' . "\n";
    echo $pqhako . "\n";
    foreach (array('mode'=>'regist','pwd'=>wf_form_value('pwd'),'name'=>$in['name'],'email'=>$in['email'],'url'=>$in['url'],'sub'=>$in['sub'],'oya'=>wf_form_value('oya'),'pview'=>wf_form_value('pview'),'smail'=>wf_form_value('smail'),'page'=>wf_form_value('page'),'wrap'=>wf_form_value('wrap'),'message'=>$in['message']) as $k=>$v) {
        echo '<input type="hidden" name="' . wf_attr($k) . '" value="' . wf_attr($v) . '">' . "\n";
    }
    if (isset($in['regikey'])) { echo '<input type="hidden" name="regikey" value="' . wf_attr($in['regikey']) . '">' . "\n"; }
    if (isset($in['str_crypt'])) { echo '<input type="hidden" name="str_crypt" value="' . wf_attr($in['str_crypt']) . '">' . "\n"; }
    if (wf_form_value('action') === 'res_msg') { echo '<input type="hidden" name="no" value="' . wf_attr(wf_form_value('no')) . '">' . "\n" . '<input type="hidden" name="action" value="res_msg">' . "\n"; }
    else { echo '<input type="hidden" name="no" value="new">' . "\n"; }
    echo '<table border="1" cellpadding="5" width="90%"><tr><td bgcolor="' . wf_attr($tbl_color) . '"><table>' . "\n";
    echo '<tr><td><b>타이틀</b></td><td>: <B>' . $in['sub'] . '</B></td></tr>' . "\n";
    echo '<tr><td><b>글자</b></td><td>: <B>' . $in['name'] . '</B></td></tr>' . "\n";
    echo '<tr><td><b>E메일</b></td><td>: ' . $email . '</td></tr>' . "\n";
    echo '<tr><td><b>참조처</b></td><td>: ' . $in['url'] . '</td></tr></table><blockquote>' . "\n";
    echo $in['message'] . "\n";
    echo '</blockquote></td></tr></table><p><table cellpadding="5"><tr>' . "\n";
    echo '<td><input type="submit" value="상기 내용으로 글을 올린다"></form></td>' . "\n";
    echo '<td><form><input type="button" value="전화면에 돌아온다" onclick="history.back()"></form></td>' . "\n";
    echo '</tr></table></div></body></html>' . "\n";
    exit;
}







function wf_after() {
    global $in, $script, $pqhako, $page, $top_sort, $refcol, $tbl_color, $sub_color;
    if ($top_sort) { $page = 0; }
    $msg = $in['message'];
    if ($refcol) { $msg = preg_replace('/([\>]|^)(&gt;[^<]*)/u', '$1<font color="' . $refcol . '">$2</font>', $msg); }
    if (wf_form_value('wrap') === 'pre') { $msg = '<pre>' . str_replace('<br>', "\n", $msg) . '</pre>'; }
    $email = (wf_form_value('smail') == '1') ? '비표시' : $in['email'];
    wf_header();
    echo '<div align="center">' . "\n";
    echo '<b style="color:' . wf_attr($sub_color) . '">이하대로 기사를 수리했습니다.</b>' . "\n<p>\n";
    echo '<table border="1" cellpadding="10" width="90%"><tr><td bgcolor="' . wf_attr($tbl_color) . '"><table>' . "\n";
    echo '<tr><td>타이틀</td><td>: <b style="color:' . wf_attr($sub_color) . '">' . $in['sub'] . '</b></td></tr>' . "\n";
    echo '<tr><td>글자</td><td>: <b>' . $in['name'] . '</b></td></tr>' . "\n";
    echo '<tr><td>E메일</td><td>: ' . $email . '</td></tr>' . "\n";
    echo '<tr><td>참조처</td><td>: ' . $in['url'] . '</td></tr></table><blockquote>' . "\n";
    echo $msg . "\n";
    echo '</blockquote></td></tr></table><p>' . "\n";
    echo '<form action="' . wf_attr($script) . '">' . "\n" . $pqhako . "\n";
    echo '<input type="hidden" name="page" value="' . intval($page) . '">' . "\n";
    echo '<input type="submit" value="리스트에 돌아온다">' . "\n";
    echo '</form></div></body></html>' . "\n";
    exit;
}







function wf_user_delete() {
    global $in;
    wf_check_form_user();
    list($top, $records) = wf_read_records();
    $no = wf_form_value('no');
    $pwd = wf_form_value('pwd');
    $changed = false;
    foreach ($records as $idx => $r) {
        if ((string)$r['no'] === (string)$no) {
            if (!wf_check_password($pwd, $r['ango'])) { wf_error('패스워드가 틀립니다'); }
            $records[$idx]['sub'] = '<s>글자 삭제</s>';
            $records[$idx]['name'] = '';
            $records[$idx]['email'] = '';
            $records[$idx]['url'] = '';
            $records[$idx]['message'] = '삭제되었습니다';
            
            $records[$idx]['ango'] = 'DEL';
            $changed = true;
            break;
        }
    }
    if (!$changed) { wf_error('기사가 눈에 띄지 않습니다'); }
    wf_write_records($top, $records);
    wf_header('<META HTTP-EQUIV="refresh" CONTENT="0; URL=./wforum.php?' . wf_query() . '">');
    echo '<div align="center">삭제했습니다</div></body></html>';
    exit;
}







function wf_user_edit() {
    global $in;
    wf_check_form_user();
    list($top, $records) = wf_read_records();
    $no = wf_form_value('no');
    $pwd = wf_form_value('pwd');
    foreach ($records as $r) {
        if ((string)$r['no'] === (string)$no) {
            if (!wf_check_password($pwd, $r['ango'])) { wf_error('패스워드가 틀립니다'); }
            $msg = str_replace('<br>', "\n", $r['message']);
            wf_header();
            wf_msg_form('edt', $r['name'], $r['email'], $r['url'], $r['smail'], $r['sub'], $msg, $r['wrap']);
            echo '</body></html>';
            exit;
        }
    }
    wf_error('기사가 눈에 띄지 않습니다');
}







function wf_check_form_user() {
    global $postonly, $post_flag;
    if ($postonly && !$post_flag) { wf_error('부정한 액세스입니다'); }
    if (wf_form_value('no') === '' || wf_form_value('pwd') === '') { wf_error('기사 No와 패스워드를 입력해 주세요'); }
}
?>
