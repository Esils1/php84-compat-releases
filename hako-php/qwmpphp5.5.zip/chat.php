<?php



















date_default_timezone_set('Asia/Seoul');
@include_once dirname(__FILE__) . '/hako/hako-init.php';
@include_once dirname(__FILE__) . '/hako-init.php';






$ver = 'PONNY v3.5';
$title = '진영 회의실';
$c_title = 1;
$t_color = '#008040';
$t_size = '16pt';
$b_size = '10pt';
$body = '<body bgcolor="#F1F1F1" text="#000000">';
$max = 25;
$COLORS = array('#0000FF','#DF0000','#008040','#800000','#C100C1','#FF80C0','#FF8040','#000080');
$IROIRO = array('파랑','빨강','연녹색','밤색','보라색','핑크','오렌지','남색');
$retime_list = array(0,30,40,50,60);
$retime_default = 40;
$sikiri = '<hr>';
$in_msg  = '씨, 어서오세요.';
$out_msg = '씨, 안녕히 가세요∼.';
$rep_color = '#808080';
$method = 'POST';
$script = './chat.php';
$home = isset($HthisFile) ? $HthisFile : './hako-main.php';
$Hallygroup = isset($Hallygroup) && is_array($Hallygroup) ? $Hallygroup : array('무소속','동맹군','연합군','제국군');
$campPass = isset($campPass) && is_array($campPass) ? $campPass : array('camp1','camp2','camp3','camp4');
$in = chat_input();
$ownername = isset($in['oNAME']) ? $in['oNAME'] : '';
$gqhako = '';
$pqhako = '';
$logfile = '';
$head_flag = 0;
chat_get_log_name();










if (isset($in['mode']) && $in['mode'] === 'form') { chat_form1(); }
elseif (isset($in['mode']) && $in['mode'] === 'into') { chat_form2(); }
elseif (isset($in['comment']) && $in['comment'] !== '' && isset($in['mode']) && $in['mode'] === 'regist') { chat_regist(''); chat_log_view(); }
elseif (isset($in['mode']) && $in['mode'] === 'byebye') { chat_byebye(); }
elseif (isset($in['mode']) && $in['mode'] === 'top') { chat_top_view(); }
chat_log_view();







function chat_input() {
    $data = array();
    foreach ($_GET as $k=>$v) { $data[$k] = chat_clean($v); }
    foreach ($_POST as $k=>$v) { $data[$k] = chat_clean($v); }
    if (!isset($data['name']) || $data['name'] === '') { $data['name'] = '이름 없는 곤베에'; }
    return $data;
}






function chat_clean($v) {
    if (is_array($v)) { $v = implode('', $v); }
    $v = str_replace(array("\0", "\r", "\n"), '', (string)$v);
    return htmlspecialchars(trim($v), ENT_QUOTES, 'UTF-8');
}





function chat_attr($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }






function chat_get_log_name() {
    global $in, $campPass, $Hallygroup, $gqhako, $pqhako, $logfile, $title, $c_title;
    $hakoID = isset($in['campID']) ? (string)$in['campID'] : '';
    $hakoPASS = isset($in['campPASS']) ? (string)$in['campPASS'] : '';
    if ($hakoID === '' || !isset($campPass[$hakoID]) || (string)$hakoPASS !== (string)$campPass[$hakoID]) { chat_temp_login(); }
    $gqhako = 'campID=' . rawurlencode($hakoID) . '&campPASS=' . rawurlencode($hakoPASS) . '&';
    $pqhako = '<input type=hidden name=campID value=' . chat_attr($hakoID) . '><input type=hidden name=campPASS value=' . chat_attr($hakoPASS) . '>';
    
    $logfile = 'log_' . preg_replace('/[^0-9A-Za-z_-]/', '', $hakoID) . '.php';
    if (!file_exists($logfile)) { @file_put_contents($logfile, '', LOCK_EX); }
    if ($c_title && isset($Hallygroup[$hakoID]) && strpos($title, $Hallygroup[$hakoID] . ':') !== 0) { $title = $Hallygroup[$hakoID] . ':' . $title; }
}






function chat_header($bodyOpen = false) {
    global $head_flag, $b_size, $title, $body;
    $head_flag = 1;
    if (!headers_sent()) { header('Content-Type: text/html; charset=UTF-8'); }
    echo '<html><head>' . "\n";
    echo '<META HTTP-EQUIV="Content-type" CONTENT="text/html; charset=UTF-8">' . "\n";
    echo '<STYLE TYPE="text/css">' . "\n";
    echo '<!-- body,tr,td,th { font-size:' . $b_size . ' } -->' . "\n";
    echo '</STYLE>' . "\n";
    echo '<title>' . chat_attr($title) . '</title>' . "\n";
    if ($bodyOpen) { echo '</head>' . "\n" . $body . "\n"; }
}





function chat_temp_login() {
    global $script, $Hallygroup;
    chat_header(true);
    $select = '';
    foreach ($Hallygroup as $i=>$name) { $select .= '<OPTION value=' . chat_attr($i) . '>' . chat_attr($name) . "\n"; }
    echo '<div align="center"><hr width=400><h3>인증해 주세요.</h3>' . "\n";
    echo '<FORM action="' . chat_attr($script) . '" method="POST"><SELECT NAME="campID">' . "\n" . $select . '</SELECT>' . "\n";
    echo '<INPUT TYPE="hidden" NAME="mode" VALUE="top">' . "\n";
    echo '<INPUT TYPE="text" NAME="campPASS" VALUE=""><INPUT TYPE="submit" VALUE="실행" NAME="cButton"></FORM>' . "\n";
    echo '<hr width=400></div></body></html>' . "\n";
    exit;
}






function chat_form1() {
    global $method, $script, $title, $t_color, $t_size, $ownername, $retime_default, $retime_list, $COLORS, $IROIRO, $pqhako, $home;
    chat_header(true);
    echo '<center>' . "\n";
    echo '<form method="' . chat_attr($method) . '" action="' . chat_attr($script) . '" target="form" name="ponny">' . "\n";
    echo '<input type=hidden name=mode value="into">' . "\n";
    echo '<table border=2 cellspacing=0>' . "\n";
    echo '<tr><th colspan=2><font color="' . chat_attr($t_color) . '" size=5><b style="font-size:' . chat_attr($t_size) . '">' . chat_attr($title) . '</b></font></th></tr>' . "\n";
    echo '<tr><td><b>이름</b> <input type=text name=name size=20 value="' . chat_attr($ownername) . '"></td></tr>' . "\n";
    echo '<tr><td>리로드<select name=retime>' . "\n";
    foreach ($retime_list as $r) { echo '<option value=' . $r . ($retime_default == $r ? ' selected' : '') . '>' . $r . "초\n"; }
    echo '</select> 문자색 <select name=color>' . "\n";
    foreach ($COLORS as $i=>$c) { echo '<option value="' . chat_attr($c) . '">' . chat_attr($IROIRO[$i]) . "\n"; }
    echo '</select></td></tr></table>' . "\n";
    echo '<table cellpadding=0 cellspacing=0><tr>' . "\n";
    echo '<th><input type=submit value="입실하는">' . $pqhako . '</th></form>' . "\n";
    echo '<th><form action="' . chat_attr($home) . '" target="_top"><input type=submit value="돌아오는">' . $pqhako . '</th></form></tr></table>' . "\n";
    echo '<SCRIPT LANGUAGE="JavaScript">' . "\n";
    echo '<!-- self.document.ponny.name.focus(); //-->' . "\n";
    echo '</SCRIPT></body></html>' . "\n";
    exit;
}






function chat_form2() {
    global $in, $method, $script, $pqhako, $retime_list, $COLORS, $IROIRO, $body;
    chat_regist('into');
    $text_width = (isset($_SERVER['HTTP_USER_AGENT']) && stripos($_SERVER['HTTP_USER_AGENT'], 'MSIE') !== false) ? 90 : 50;
    chat_header(false);
    echo '<SCRIPT LANGUAGE="JavaScript">' . "\n";
    echo '<!--' . "\n";
    echo 'function autoclear() { if (self.document.send) { if (self.document.cmode && self.document.cmode.autoclear) { if (self.document.cmode.autoclear.checked) { if (self.document.send.comment) { self.document.send.comment.value = ""; self.document.send.comment.focus(); } } } } }' . "\n";
    echo '// -->' . "\n";
    echo '//-->
</SCRIPT>' . "\n";
    echo '</head>' . "\n" . $body . "\n";
    echo '<form name=send method=' . chat_attr($method) . ' action="' . chat_attr($script) . '" target="log" onSubmit="setTimeout(&quot;autoclear()&quot;,10)">' . "\n";
    echo $pqhako . "\n";
    echo '<input type=hidden name=mode value="regist">' . "\n";
    echo '<input type=hidden name=name value="' . chat_attr($in['name']) . '">' . "\n";
    echo '<b>발언</b>:<input type=text size="' . intval($text_width) . '" name=comment><br>' . "\n";
    echo '리로드<select name=retime>' . "\n";
    foreach ($retime_list as $r) { echo '<option value=' . $r . ((isset($in['retime']) && intval($in['retime']) == $r) ? ' selected' : '') . '>' . $r . "초\n"; }
    echo '</select>  문자색 <select name=color>' . "\n";
    foreach ($COLORS as $i=>$c) { echo '<option value=' . chat_attr($c) . ((isset($in['color']) && $in['color'] === $c) ? ' selected' : '') . '>' . chat_attr($IROIRO[$i]) . "\n"; }
    echo '</select><input type=submit value="발언 및 리로드"><input type=reset value="클리어">' . $pqhako . '</form>' . "\n";
    echo '<form action="' . chat_attr($script) . '" method="' . chat_attr($method) . '" target=form><table><tr><td>' . "\n";
    echo '<input type=submit value="퇴실하는">' . $pqhako . '<input type=hidden name=mode value="byebye"><input type=hidden name=name value="' . chat_attr($in['name']) . '"></td></form>' . "\n";
    echo '<td valign=top><form name="cmode"><input type="checkbox" name="autoclear" checked>발언 자동 소거</td></form></tr></table>' . "\n";
    echo '</body></html>' . "\n";
    exit;
}






function chat_log_view() {
    global $in, $retime_default, $script, $gqhako, $body, $logfile, $sikiri, $ver;
    if (!isset($in['retime']) || $in['retime'] === '') { $in['retime'] = $retime_default; }
    chat_header(false);
    if (intval($in['retime']) != 0) { echo '<META HTTP-EQUIV="refresh" CONTENT="' . intval($in['retime']) . '; URL=' . chat_attr($script . '?' . $gqhako . 'retime=' . intval($in['retime'])) . '">' . "\n"; }
    echo '</head>' . "\n" . $body . "\n";
    echo '<div align=right>리로드 설정' . (intval($in['retime']) == 0 ? '수동' : intval($in['retime']) . '초') . '</div><hr>' . "\n";
    $lines = file_exists($logfile) ? file($logfile, FILE_IGNORE_NEW_LINES) : array();
    foreach ($lines as $line) {
        $p = explode('<>', $line);
        if (count($p) < 4) { continue; }
        echo '<font color="' . chat_attr($p[3]) . '"><b>' . $p[1] . '</b> ＞ ' . $p[2] . '</font> (' . $p[0] . ')' . $sikiri . "\n";
    }
    echo '<center><small><!-- ' . chat_attr($ver) . ' -->' . "\n";
    echo "- <a href='http://www.kent-web.com/' target='_top'>Ponny Chat</a> -\n";
    echo "<BR>Edit:<a href='http://www8.plala.or.jp/nayupon/' target='_top'>lastier</a>\n";
    echo '</small></center>' . "\n</body></html>\n";
    exit;
}






function chat_regist($type) {
    global $in, $logfile, $max, $in_msg, $out_msg, $rep_color;
    $date = date('m/d-H:i:s');
    
    if ($type === 'into') { $comment = '<b>' . $in['name'] . '</b>' . $in_msg; $name = 'MASTER'; $color = $rep_color; }
    elseif ($type === 'bye') { $comment = '<b>' . $in['name'] . '</b>' . $out_msg; $name = 'MASTER'; $color = $rep_color; }
    else { $comment = isset($in['comment']) ? $in['comment'] : ''; $name = isset($in['name']) ? $in['name'] : ''; $color = isset($in['color']) ? $in['color'] : '#0000FF'; }
    $lines = file_exists($logfile) ? file($logfile, FILE_IGNORE_NEW_LINES) : array();
    
    while ($max <= count($lines)) { array_pop($lines); }
    
    array_unshift($lines, $date . '<>' . $name . '<>' . $comment . '<>' . $color . '<>' . (isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '') );
    file_put_contents($logfile, implode("\n", $lines) . "\n", LOCK_EX);
}





function chat_byebye() {
    global $in, $home;
    chat_regist('bye');
    chat_header(true);
    echo '<center><h3>' . chat_attr($in['name']) . '씨, 이용 감사합니다</h3>' . "\n";
    echo '[<a href="' . chat_attr($home) . '" target="_top">탑에 돌아온다</a>]</center>' . "\n";
    echo '</body></html>' . "\n";
    exit;
}






function chat_top_view() {
    global $script, $gqhako, $ownername;
    chat_header(false);
    echo '<frameset rows="135,*">' . "\n";
    echo '<frame name="form" src="./' . chat_attr($script) . '?' . chat_attr($gqhako . 'oNAME=' . rawurlencode($ownername) . '&mode=form ') . '" target="_self">' . "\n";
    echo '<frame name="log" src="./' . chat_attr($script) . '?' . chat_attr($gqhako) . '">' . "\n";
    echo '<noframes><body><h3>프레임 비대응의 브라우저는 이용하실 수 없습니다</h3></body></noframes>' . "\n";
    echo '</frameset></html>' . "\n";
    exit;
}
?>
