<?php

/*
 * hako/hako-top.php
 * ------------------------------------------------------------
 * 탑 페이지/해역 목록/통계 링크/최근 로그 출력 모듈
 *
 * 상세 주석 기준:
 * - 원본 대응: qwmp155.zip 의 hako-top.cgi.
 * - 메인 첫 화면, 해역/섬 목록, 진영 정보, 설정 일람 링크, 신규 등록 링크, 최근 로그와 과거 로그 링크를 출력합니다.
 * - 초기 접속 화면의 보이는 HTML이므로 문구, 링크 순서, 테이블 구조를 임의 변경하지 마십시오.
 * - 섬 정렬과 목록 표시는 인구/자원/진영/전쟁 상태의 시각적 차이를 만들 수 있습니다.
 * - 원본 CGI 주석 라인 확인 수: 56줄. PHP 주석은 실행 결과를 바꾸지 않는 범위에서 복원/보강했습니다.
 *
 * 유지보수 원칙:
 * - 실행 로직, 저장 포맷, 배열 인덱스, 출력 HTML은 원본 CGI 호환성 대상입니다.
 * - 개조가 필요하면 먼저 해당 변수/함수가 어떤 파일 저장값과 연결되는지 확인하십시오.
 * - 이 주석은 유지보수용이며 실행 결과를 바꾸지 않습니다.
 */

chdir(dirname(__FILE__));
require_once dirname(__FILE__) . '/hako-compat.php';
if (function_exists('htmlEscape')) { $HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : ''); } else { $HdefaultPasswordEsc = isset($HdefaultPassword) ? $HdefaultPassword : ''; }














/*
 * 함수: topPageMain()
 * 역할: 탑 페이지 출력 전체를 제어합니다.
 * 원본 대응: hako/hako-top.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function topPageMain() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	
	unlock();
	
	$mode = isset($_args[0]) ? $_args[0] : null;
	tempTopPage($mode);
}


/*
 * 함수: tempTopPage()
 * 역할: 탑 페이지 HTML 본문을 출력합니다.
 * 원본 대응: hako/hako-top.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function tempTopPage() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	unset($mode); $mode = isset($_args[0]) ? $_args[0] : null;
	out($HtagTitle_ . $Htitle . $HtagTitle2_ . $Htitle2 . $H_tagTitle . $H_tagTitle);
	if ($mode == 2) {
		
		tempsetteiPage();
	} elseif (($mode == 9) && ($HislandNumber < $HmaxIsland) && ($HislandNFlg != 1)) {
		
		tempNewIslandPage();
	} else{
	
	if ($Hdebug == 1) {
		out(<<<HAKOHDOC_0
<FORM action="$HthisFile" method="POST">
<INPUT TYPE="submit" VALUE="턴을 진행시킨다" NAME="TurnButton">
</FORM>
HAKOHDOC_0
);
	}

	
	if ($HmainMode != 'turn') {
		$now = $HislandLastTime + $HunitTime - time();
		$hour2 = intval($now/3600);
		$min2 = intval(($now-$hour2*3600)/60);
		$sec2 = ($now-$hour2*3600-$min2*60);
		if (!empty($HautoTurnPending)) {
			$__hako_backlog_text = '';
			if (isset($HautoTurnBacklog) && ($HautoTurnBacklog > 1)) {
				$__hako_backlog_text = " (밀린 턴 " . intval($HautoTurnBacklog) . "턴)";
			}
			$rtStr = "<b>턴 갱신 대기중" . $__hako_backlog_text . "</b> <A HREF=\"" . $HthisFile . "?AutoTurn=1\">1턴 진행</A>";
		} else {
			$rtStr = "다음의 갱신까지<b>나머지{$hour2}시간 {$min2}분 {$sec2}초</b>";
		}
	} else {
		$rtStr = "턴을 갱신했던 \n";
	}

		$now = time();
	
	if ($HflexTimeSet) { $HunitTime = 3600 * $HflexTime[$HTurnCt]; }
	$aaa = $HislandLastTime + $HunitTime;
	$_list_tmp = hako_localtime(time());
	unset($sec); $sec = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
	unset($min); $min = isset($_list_tmp[1]) ? $_list_tmp[1] : null;
	unset($hour); $hour = isset($_list_tmp[2]) ? $_list_tmp[2] : null;
	unset($date); $date = isset($_list_tmp[3]) ? $_list_tmp[3] : null;
	unset($mon); $mon = isset($_list_tmp[4]) ? $_list_tmp[4] : null;
	unset($year); $year = isset($_list_tmp[5]) ? $_list_tmp[5] : null;
	unset($day); $day = isset($_list_tmp[6]) ? $_list_tmp[6] : null;
	unset($yday); $yday = isset($_list_tmp[7]) ? $_list_tmp[7] : null;
	unset($dummy); $dummy = isset($_list_tmp[8]) ? $_list_tmp[8] : null;
	$mon++;
	$sss = "{$mon}월 {$date}일 {$hour}시 {$min}분 {$sec}초";
	$_list_tmp = hako_localtime($aaa);
	unset($sec2); $sec2 = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
	unset($min2); $min2 = isset($_list_tmp[1]) ? $_list_tmp[1] : null;
	unset($hour2); $hour2 = isset($_list_tmp[2]) ? $_list_tmp[2] : null;
	unset($date2); $date2 = isset($_list_tmp[3]) ? $_list_tmp[3] : null;
	unset($mon2); $mon2 = isset($_list_tmp[4]) ? $_list_tmp[4] : null;
	unset($year2); $year2 = isset($_list_tmp[5]) ? $_list_tmp[5] : null;
	unset($day2); $day2 = isset($_list_tmp[6]) ? $_list_tmp[6] : null;
	unset($yday2); $yday2 = isset($_list_tmp[7]) ? $_list_tmp[7] : null;
	unset($dummy2); $dummy2 = isset($_list_tmp[8]) ? $_list_tmp[8] : null;
	$mon2++;
	$bbb = "{$mon2}월{$date2}일{$hour2}시{$min2}분";

	unset($bb1); $bb1 = "";
	if ($HflexTimeSet) {
		$_list_tmp = array(0,0,0);
		unset($i); $i = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
		unset($nnn); $nnn = isset($_list_tmp[1]) ? $_list_tmp[1] : null;
		unset($ftime); $ftime = isset($_list_tmp[2]) ? $_list_tmp[2] : null;
		unset($ct); $ct = hako_last_index($HflexTime) + 1;
		$bb1 = "갱신 빈도　{$ct}회/일(　";
		unset($bb2); $bb2 = null;
		for ($i = $HTurnCt;$i <= hako_last_index($HflexTime);$i++) {
			$ftime += $HflexTime[$i];
			$nnn = $HislandLastTime + 3600 * $ftime;
			$_list_tmp = array_slice(hako_localtime($nnn), 1, 2);
			$min2 = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
			$hour2 = isset($_list_tmp[1]) ? $_list_tmp[1] : null;
			if ($i == $HTurnCt) {
				$bb2 .= "<b>{$hour2}시{$min2}분</b>　";
			} else{
				$bb2 .= "{$hour2}시{$min2}분　";
			}
		}
		for ($i = 0;$i < $HTurnCt;$i++) {
			$ftime += $HflexTime[$i];
			$nnn = $HislandLastTime + 3600 * $ftime;
			$_list_tmp = array_slice(hako_localtime($nnn), 1, 2);
			$min2 = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
			$hour2 = isset($_list_tmp[1]) ? $_list_tmp[1] : null;
			$bb1 .= "{$hour2}시{$min2}분　";
		}
		$bb1 .= "{$bb2})";
	}

	if (($HislandNumber <= 1) && (($HislandNumber >= $HmaxIsland) || ($HislandNFlg == 1))) {
		
		$ltStr = "/$HislandTurn (게임 종료)";
	} elseif ($HlimitTurn <= 0) {
		
		$ltStr = " ($rtStr)";
	} else{
		
		$ltStr = "/$HlimitTurn ";
		if ($HislandTurn < $HlimitTurn) {
			
			$ltStr .= "($rtStr)";
		} else{
			
			$ltStr .= "(게임 종료)";
		}
	}

	$_list_tmp = array("","","");
	unset($mStr1); $mStr1 = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
	unset($mStr2); $mStr2 = isset($_list_tmp[1]) ? $_list_tmp[1] : null;
	unset($mStr3); $mStr3 = isset($_list_tmp[2]) ? $_list_tmp[2] : null;
	if ($HhideMoneyMode != 0) {
		$mStr1 = "<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>{$HtagTH_}자금{$H_tagTH}</NOBR></TH>";
	}
	if ($Hnoarmy) {
		
		$mStr2 = "<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>{$HtagTH_}총병력{$H_tagTH}</NOBR></TH>";
		$mStr3 = "<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>{$HtagTH_}누계 전과{$H_tagTH}</NOBR></TH><TH $HbgTitleCell align=center nowrap=nowrap><NOBR>{$HtagTH_}누계 손해{$H_tagTH}</NOBR></TH>";
	}
	if ($HjavaModeSet == 'java2') {
		$radio = ""; $radio2 = "CHECKED";
	} else{
		$radio = "CHECKED";	$radio2 = "";
	}
	
	out(<<<HAKOHDOC_1
<DIV ID='Turn'>
<H1>턴 $HislandTurn$ltStr</H1>
</DIV>
<DIV ID='nexttime'>
<font size=4>현재의 시간：<b>$sss</b>(다음번의 갱신 시간：$bbb)</FONT>
<br>$bb1<br>
</DIV>
<span class='attention'>
$Hattention

</span>
<HR>
<TABLE BORDER=0 width="100%">
<TR valign="top">
<TD width="30%" class="M">
<DIV ID='myIsland'>
<H1>자신의 나라에</H1>
<SCRIPT language="JavaScript">
<!--
function newdevelope(){
//	newWindow = window.open("", "newWindow");
	document.Island.target = "newWindow";
	document.Island.submit();
}
function develope(){
	document.Island.target = "";
}
var mode = 1;
function swtext(){
	if(mode){
		mode = 0;
		document.getElementById("TopText").innerHTML = document.getElementById('LogRecently').innerHTML;
		document.getElementById("TopTitle").innerHTML = "<u>최근의 사건</u>";
	}else{
		mode = 1;
		document.getElementById("TopText").innerHTML = document.getElementById('LogHistory').innerHTML;
		document.getElementById("TopTitle").innerHTML = "<u>세계의 역사</u>";
	}
}
//-->
</SCRIPT>
<FORM name="Island" action="$HthisFile" method="POST">
당신의 나라의 이름은? <BR>
<SELECT NAME="ISLANDID">
$HislandList
</SELECT><BR>
패스워드를 부탁합니다!<BR>
<INPUT TYPE="hidden" NAME="OwnerButton">
<INPUT TYPE="password" NAME="PASSWORD" VALUE="{$HdefaultPasswordEsc}" SIZE=32 MAXLENGTH=32><BR>
<INPUT TYPE="radio" NAME=JAVAMODE VALUE=java $radio>통상 모드
<INPUT TYPE="radio" NAME=JAVAMODE VALUE=java2 $radio2>신개발 모드(β)<BR>
<INPUT TYPE="hidden" NAME="DUMMY" VALUE="DUMMY">
<INPUT TYPE="submit" VALUE="개발하러 간다" onClick="develope()">　
<INPUT TYPE="button" VALUE="새로운 화면" onClick="newdevelope()">
</FORM>
</DIV>
</TD><TD width="20%" class="M">

HAKOHDOC_1
);
if ($mode == 0) { islandMapTop(); }
	out(<<<HAKOHDOC_2
</TD><TD width="50%" class="M">
<DIV ID='RecentlyLog'>
<H1 id=TopTitle onclick="swtext()"><u>세계의 역사</u></H1>
<DIV id=TopText style="overflow:auto; height:120px;">

HAKOHDOC_2
);

	historyPrint();

	
	unset($graph); $graph = hako_file_age_days("{$HefileDir}/graph.html");
	if ((file_exists("{$HefileDir}/graph.html")) && ($graph < hako_file_age_days("{$HdirName}/pop.0"))) {
		$graph = "{$efileDir}/graph.html";
	} else{
		$graph = "$HbaseDir/hako-graph.php";
	}
	out(<<<HAKOHDOC_3
</DIV></DIV>
</TD></TR></TABLE>
<HR>
<DIV ID='RecentlyLog'>
<FONT SIZE=4><B>[
<A HREF="$HbaseDir/hakolog.html" target="_blank">{$HtagHeader_}최근의 사건{$H_tagHeader}</A>
　/　　
<A HREF="{$HthisFile}?settei=0">{$HtagHeader_}설정의 변경{$H_tagHeader}</A>
　/　　
<A HREF="$HbaseDir/lbbslist.php?id=99">{$HtagHeader_}관광자 통신 일람{$H_tagHeader}</A>
　/　　
<A HREF="$graph">{$HtagHeader_}통계{$H_tagHeader}</A>

HAKOHDOC_3
);
	if ($HeditorN) { out("　/　<A HREF=\"{$HthisFile}?meditor=0\">{$HtagHeader_}맵 에디터{$H_tagHeader}</A>"); }
	out("]</B></FONT></DIV>");

	
	campInfoList();
	out("<HR>");
	if (($HislandNumber < $HmaxIsland) && ($HislandNFlg != 1)) {
	out(<<<HAKOHDOC_4
<DIV ID='newIsland'>
<FORM action="$HthisFile" method="POST">
<INPUT TYPE="submit" VALUE="신규 참가한다" NAME="NewIslandInfo">
</FORM></DIV>

HAKOHDOC_4
);
	}
out(<<<HAKOHDOC_5
<DIV ID='islandView'>
<H1>제국의 상황</H1>
<TABLE BORDER>
<TR>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>{$HtagTH_}순위{$H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>{$HtagTH_}국{$H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>{$HtagTH_}인구{$H_tagTH}</NOBR></TH>
$mStr2
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>{$HtagTH_}면적{$H_tagTH}</NOBR></TH>
$mStr1
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>{$HtagTH_}식량{$H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>{$HtagTH_}농장 규모{$H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>{$HtagTH_}총직장수{$H_tagTH}</NOBR></TH>
$mStr3
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>{$HtagTH_}국력{$H_tagTH}</NOBR></TH>
</TR>

HAKOHDOC_5
);

	unset($island); $island = null;
	unset($j); $j = null;
	unset($food); $food = null;
	unset($farm); $farm = null;
	unset($factory); $factory = null;
	unset($mountain); $mountain = null;
	unset($jobpop); $jobpop = null;
	unset($attackA); $attackA = null;
	unset($damageA); $damageA = null;
	unset($ally); $ally = null;
	unset($amark); $amark = null;
	unset($name); $name = null;
	unset($id); $id = null;
	unset($prize); $prize = null;
	unset($ii); $ii = null;
	unset($sPop); $sPop = null;
	unset($sArea); $sArea = null;
	for ($ii = 0; $ii < $HislandNumber; $ii++) {
	$j = $ii + 1;
	$island =& $Hislands[$ii];

	$id = $island['id'];
	$food = $island['food'];
	$food = ($food <= 400) ? "<span class='attention'>{$island['food']}$HunitFood</span>" : "{$island['food']}$HunitFood";
	$farm = $island['farm'];
	$factory = $island['factory'];
	$mountain = $island['mountain'];
	$jobpop = $farm + $factory + $mountain;
	$attackA = $island['attackA'];
	$damageA = $island['damageA'];
	$farm = ($farm == 0) ? "보유안함" : "{$farm}0$HunitPop";
	$factory = ($factory == 0) ? "보유안함" : "{$factory}0$HunitPop";
	$mountain = ($mountain == 0) ? "보유안함" : "{$mountain}0$HunitPop";
	$jobpop = ($jobpop == 0) ? "보유안함" : "{$jobpop}0$HunitPop";
	$attackA = ($attackA == 0) ? "0명" : "{$attackA}$HunitPop";
	$damageA = ($damageA == 0) ? "0명" : "{$damageA}$HunitPop";

	if ($island['absent']  == 0) {
		$name = "{$HtagName_}{$island['name']}{$H_tagName}";
	} else {
		$name = "{$HtagName2_}{$island['name']}({$island['absent']}){$H_tagName2}";
	}
	if ($island['predelete'] && $HdispAzukari != 1) { $name = "<span class='attention'>【관리인 보관】</span><BR>" . $name; }

	$sPop += $island['pop'];
	$sArea += $island['area'];

	$prize = $island['prize'];
	unset($flags); $flags = null;
	unset($monsters); $monsters = null;
	unset($turns); $turns = null;
	hako_regex('~([0-9]*),([0-9]*),(.*)~', $prize);
	$flags = hako_m(1);
	$monsters= hako_m(2);
	$turns = hako_m(3);
	$prize = '';

	if (($HislandTurn - $island['kaisi'] <= $Hatkturn) && ($island['kaisi'] < 99999)) {
		$at = $Hatkturn - ($HislandTurn - $island['kaisi']) + 1;
		$prize = "외교 명령 제한({$at})";
	}

	if ($Hallyflg) {
		
		$ally = $island['ally'];
		$amark = isset($Hallymark[$ally]) ? "<b>" . $Hallymark[$ally] . "</b> " : "";
	} else{
		$amark = "";
	}
	
	$kazu = 0;
	$mTurnList = '';
	while (hako_shift_str($turns, '~([0-9]*),~')) {
		$kazu++;
		$mTurnList .= "[" . hako_m(1) . $Hprize[0] . "] ";
	}
	if ($kazu != 0) { $prize .= "<A HREF=\"JavaScript:void(0);\" onMouseOver=\"window.status = '$mTurnList'; return true;\" onMouseOut=\"window.status = '';\">"; }
	if ($kazu >= 5) {
		$prize .= "<IMG SRC=\"nu/prize00.gif\" ALT=\"$mTurnList\" WIDTH=16 HEIGHT=16 BORDER=0></A> ";
	} elseif ($kazu >= 3) {
		$prize .= "<IMG SRC=\"nu/prize.gif\" ALT=\"$mTurnList\" WIDTH=16 HEIGHT=16 BORDER=0></A> ";
	} elseif ($kazu != 0) {
		$prize .= "<IMG SRC=\"nu/prize0.gif\" ALT=\"$mTurnList\" WIDTH=16 HEIGHT=16 BORDER=0></A> ";
	}

	
	$f = 1;
	unset($i); $i = null;
	for ($i = 1; $i < 10; $i++) {
		if ($flags & $f) {
			$prize .= <<<HAKOHDOC_6
<A HREF="JavaScript:void(0);" onMouseOver="window.status = '{$Hprize[$i]}'; return true;" onMouseOut="window.status = '';">
<IMG SRC="nu/prize{$i}.gif" ALT="{$Hprize[$i]}" TITLE="{$Hprize[$i]}" WIDTH=16 HEIGHT=16 BORDER=0></A>
HAKOHDOC_6
;
		}
		$f *= 2;
	}

	
	$f = 1;
	$max = -1;
	$mNameList = '';
	for ($i = 0; $i < $HmonsterNumber; $i++) {
		if ($monsters & $f) {
			$mNameList .= "[$HmonsterName[$i]] ";
			$max = $i;
		}
		$f *= 2;
	}
	if ($max != -1) {
		$prize .= <<<HAKOHDOC_7
<A HREF="JavaScript:void(0);" onMouseOver="window.status = '$mNameList'; return true;" onMouseOut="window.status = '';">
<IMG SRC="nu/{$HmonsterImage[$max]}" ALT="$mNameList" TITLE="$mNameList" WIDTH=16 HEIGHT=16 BORDER=0></A>
HAKOHDOC_7
;
	}
	$_list_tmp = array("","","");
	$mStr1 = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
	$mStr2 = isset($_list_tmp[1]) ? $_list_tmp[1] : null;
	$mStr3 = isset($_list_tmp[2]) ? $_list_tmp[2] : null;
	$CellCt = 7;
	if ($HhideMoneyMode == 1) {
		$mStr1 = "<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>{$island['money']}$HunitMoney</NOBR></TD>";
	} elseif ($HhideMoneyMode == 2) {
		$mTmp = aboutMoney($island['money']);
		$mStr1 = "<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$mTmp</NOBR></TD>";
	}
	if ($Hnoarmy) {
		
		unset($mp); $mp = (isset($island['mpower']) && is_array($island['mpower'])) ? $island['mpower'] : array();
		unset($allpop); $allpop = 0;
		for ($_ = 0; $_ <= hako_last_index($Fdivision); $_++) {
			if (isset($mp[$_]) && intval($mp[$_]) > 0) { $allpop += intval($mp[$_]); }
		}
		if ($island['soldier'] > 0) { $allpop += $island['soldier']; }
		if ($allpop > 0) {
		
			$mStr2 = "<TD $HbgInfoCell align=right>$allpop$HunitPop</TD>";
		} else{
			$mStr2 = "<TD $HbgInfoCell align=right>보유안함</TD>";
		}
		$mStr3 = "<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$attackA</NOBR></TD><TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$damageA</NOBR></TD>";
		$CellCt += 3;
	}
	$oStr = '';
	if ($island['ownername'] == '') {
		$oStr = "<TD $HbgCommentCell COLSPAN=$CellCt align=left>{$amark}{$HtagTH_} 코멘트 : {$H_tagTH}{$island['comment']}</TD>";
	} else {
		$oStr = "<TD $HbgCommentCell COLSPAN=$CellCt align=left>$amark<font color=#0000ff>{$island['ownername']} : </font>{$island['comment']}</TD>";
	}
	out(<<<HAKOHDOC_8
<TR>
<TD $HbgNumberCell ROWSPAN=2 align=center>{$HtagNumber_}{$j}{$H_tagNumber}</TD>
<TD $HbgNameCell ROWSPAN=2 align=left>
<NOBR>
<A STYlE="text-decoration:none" HREF="{$HthisFile}?Sight={$id}">
$name
</A>
</NOBR><BR>
$prize
</TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>{$island['pop']}$HunitPop</NOBR></TD>
$mStr2
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>{$island['area']}$HunitArea</NOBR></TD>
$mStr1
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$food</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$farm</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$jobpop</NOBR></TD>
$mStr3
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>{$island['score']}</NOBR></TD>
</TR>
<TR>
$oStr
</TR>

HAKOHDOC_8
);
	}
	out(<<<HAKOHDOC_9
</TABLE>
</DIV>
<DIV ID='islandView'>
<TABLE BORDER>
<TR>
<TD class=TitleCell><span class="head">총인구</span></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$sPop$HunitPop</span></TD>
<TD class=TitleCell><span class="head">총면적</span></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR><NOBR>{$sArea}{$HunitArea}/{$HdisFallBorder}{$HunitArea}</NOBR></span></TD>
</TR>
</TABLE>
</DIV>
<DIV ID='LogHistory' style="display:none;visibility:hidden;">

HAKOHDOC_9
);
	historyPrint();
	out(<<<HAKOHDOC_10
</DIV>

<DIV ID='LogRecently' style="display:none;visibility:hidden;">

HAKOHDOC_10
);
	logFilePrint(0, 0, 0, 2);
	out(<<<HAKOHDOC_11
</DIV>

HAKOHDOC_11
);
	if (!(($HislandNumber < $HmaxIsland) && ($HislandNFlg != 1))) {
		out("신규 등록은 받아들이고 있지 않습니다. ");
	}
	}
}


/*
 * 함수: campInfoList()
 * 역할: 진영 정보 목록을 출력합니다.
 * 원본 대응: hako/hako-top.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function campInfoList() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	if (($Hallyflg) && (hako_open('LIN', "{$HdirName}/ally.log"))) {
	out(<<<HAKOHDOC_12
<HR><DIV ID='campInfo'>
<H1>각 진영의 상황</H1>
<TABLE BORDER>
<TR>
<TH $HbgTitleCell>{$HtagTH_}순위{$H_tagTH}</TH>
<TH $HbgTitleCell>{$HtagTH_}그룹{$H_tagTH}</TH>
<TH $HbgTitleCell>{$HtagTH_}국 수{$H_tagTH}</TH>
<TH $HbgTitleCell>{$HtagTH_}총인구{$H_tagTH}</TH>
<TH $HbgTitleCell>{$HtagTH_}총병력{$H_tagTH}</TH>
<TH $HbgTitleCell>{$HtagTH_}계승자흙{$H_tagTH}</TH>
<TH $HbgTitleCell>{$HtagTH_}영토 점유율{$H_tagTH}</TH>
<TH $HbgTitleCell>{$HtagTH_}총경제력{$H_tagTH}</TH>
</TR>
HAKOHDOC_12
);
	unset($i); $i = null;
	unset($line); $line = null;
	unset($ally); $ally = array();
	unset($apop); $apop = array();
	unset($up); $up = null;
	$i = 1;
	while ($line = hako_getline('LIN')) {
		
		$ally = explode(',', $line);
		if ($ally[0] != $HislandTurn) {
			$apop[$ally[1]] = $ally[3];
			continue;
		}
		out("<TR><TD $HbgNumberCell align=center><a href=\"$HthisFile?alist=$ally[1]\" class=\"M\">{$HtagNumber_}{$i}{$H_tagNumber}</a></TD>");
		if ($ally[1] == 0) {
			out("<TD $HbgNameCell>" . $Hallygroup[$ally[1]] . "</TD>");
		} else{
			out("<TD $HbgNameCell>" . $Hallymark[$ally[1]] . $HtagTH_ . $Hallygroup[$ally[1]] . $H_tagTH . "</TD>");
		}
		out("<TD $HbgInfoCell>$ally[2]</TD>");
		if ((isset($apop[$ally[1]]) ? $apop[$ally[1]] : 0) > $ally[3] + 100) {
			$up = "↓";
		} elseif ((isset($apop[$ally[1]]) ? $apop[$ally[1]] : 0) < $ally[3] - 100) {
			$up = "↑";
		} else{
			$up = "→";
		}
		out("<TD $HbgInfoCell>$ally[3]{$HunitPop} <B>$up</B></TD>");
		out("<TD $HbgInfoCell>$ally[4]{$HunitPop}</TD>");
		out("<TD $HbgInfoCell>$ally[5]{$HunitArea}</TD>");
		out("<TD $HbgInfoCell>$ally[7]%</TD>");
		out("<TD $HbgInfoCell>$ally[6]{$HunitMoney}</TD></TR>");
		$i++;
	}
	hako_close('LIN');
	out("</TABLE>");

	}
}
/*
 * 함수: topPageAlist()
 * 역할: 통계/랭킹/과거 로그 링크 목록을 출력합니다.
 * 원본 대응: hako/hako-top.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function topPageAlist() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	out(<<<HAKOHDOC_13
{$HtagTitle_}{$Htitle}{$HtagTitle2_}{$Htitle2}{$H_tagTitle}{$H_tagTitle}
<br><br>
은폐 기능이기도 한다···. (<A HREF="{$HthisFile}" class="M">통상의 일람 화면으로 돌아간다</A>)<br>
<h2>{$Hallygroup[$Halistmode]}　{$Hallymark[$Halistmode]}　소속 일람</h2>
<SCRIPT LANGUAGE="JavaScript">
<!--
function textcopy(mapdata){
	window.clipboardData.setData("text",mapdata);
}
function searchID(url){
	if(document.getElementById){
		return document.getElementById(url);
	} else if(document.all){
		return document.all(url);
	} else if(document.layers){
		return document.layers[url];
	}
}
//-->
</SCRIPT>
<INPUT TYPE="button" VALUE="클립보드에 카피" onClick="textcopy(searchID('ALIST').value)">
엑셀이라든지에 붙여 사용해 주세요. <br>
<textarea NAME="ALIST" cols="100" rows="10">

HAKOHDOC_13
);

	unset($i); $i = null;
	unset($island); $island = null;
	unset($id); $id = null;
	unset($name); $name = null;
	unset($pop); $pop = null;
	unset($area); $area = null;
	unset($money); $money = null;
	unset($food); $food = null;
	unset($weapon); $weapon = null;
	out("시마나\t인구\t면적\t자금\t식량 \n");
	for ($i = 0; $i < $HislandNumber; $i++) {
		$island =& $Hislands[$i];
		$tAlly = $island['ally'];
		if ($Halistmode == $tAlly) {
			$id = $island['id'];
			$name = $island['name'];
			$pop = $island['pop'] . $HunitPop;
			$area = $island['area'] . $HunitArea;

			if ($HhideMoneyMode == 1) {
				$money = $island['money'] . $HunitMoney;
			} elseif ($HhideMoneyMode == 2) {
				$money = aboutMoney($island['money']);
			} else {
				$money = '기밀';
			}
			$food = $island['food'] . $HunitFood;
			out("$name$AfterName\t$pop\t$area\t$money\t$food\n");
		}
	}
	out("</textarea>");
	
	campInfoList();
}



/*
 * 함수: islandMapTop()
 * 역할: 탑 페이지용 축약 지도/섬 목록을 출력합니다.
 * 원본 대응: hako/hako-top.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function islandMapTop() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	unset($mode); $mode = isset($_args[0]) ? $_args[0] : null;
	require_once 'hako-map.php';
	$set_island = getJsIslandList();
	
	unset($ctbl); $ctbl = array('green2','red3','blue3','yellow2','purple2','white','red2','gray','blue2','purple1','yellow1','blue1','red1','green1','black','white','white','white');
	unset($i); $i = null;
	unset($x); $x = null;
	unset($y); $y = null;
	unset($set_color); $set_color = null;
	unset($l_c); $l_c = null;
	unset($l_id); $l_id = null;
	unset($set_owner); $set_owner = null;
	for ($i = 0; $i < $HislandNumber; $i++) {
		$l_id = $Hislands[$i]['id'];
		$l_c = $ctbl[$HidToNumber[$l_id]];
		if ($i == $HislandNumber-1) {
			$set_color .= "'$l_id':'$l_c'";
		} else{
			$set_color .= "'$l_id':'$l_c',\n";
		}
	}
	
	for ($y = 0; $y < $HislandSize; $y++) {
		$set_owner .= "[";
		for ($x = 0; $x < $HislandSize; $x++) {
			$set_owner .= $HlandOwner[$x][$y] . ",";
		}
		hako_chop($set_owner);
		$set_owner .= "],\n";
	}
	$set_owner = substr($set_owner, 0, -2);
	out(<<<HAKOHDOC_14
<CENTER><TABLE BORDER><TR><TD>
<SCRIPT language="JavaScript">
islname = {
$set_island
};
color = {
$set_color
};
owner = [
$set_owner
];
function px(x){
	if(x > 0) window.open("$HthisFile?color=1&Sight="+x,"_blank","status=yes,scrollbars=yes,resizable=yes,width=800");
}
function msg(x,y,l,img){
	l = '(' + x + ', ' + y + ') ' + l + '[' + islname[owner[y][x]] + ']<BR>';
	for(j = y - 1; j < y + 2; j++){
		yj = (j < 0) ? $HislandSize + j : j;
		if(yj >= $HislandSize) yj = yj - $HislandSize;
		if((yj % 2) == 0) l = l + '<IMG SRC=' + document.getElementById("s"+yj).src + ' width=16 height=32 BORDER=0>';
		for(i = x - 5; i < x + 6; i++){
			xi = (i < 0) ? $HislandSize + i : i;
			if(xi >= $HislandSize) xi = xi - $HislandSize;
			if(xi == x && yj == y){
				l = l + '<IMG SRC="f/white.gif" width=32 height=32 BORDER=0 STYLE="position: absolute;">';
				l = l + '<IMG SRC=' + document.getElementById(xi+"x"+yj).src + ' width=32 height=32 BORDER=0>';
			}else{
				if(owner[yj][xi] > 0) l = l + '<IMG SRC="f/' + color[owner[yj][xi]] + '.gif" width=32 height=32 BORDER=0 STYLE="position: absolute;">';
				l = l + '<IMG SRC=' + document.getElementById(xi+"x"+yj).src + ' width=32 height=32 BORDER=0>';
			}
		}
		if((yj % 2) == 1) l = l + '<IMG SRC=' + document.getElementById("s"+yj).src + ' width=16 height=32 BORDER=0>';
		l = l + '<BR>';
	}
	document.getElementById("TopTitle").innerHTML = "<u>지형의 상세</u>";
	document.getElementById("TopText").innerHTML = l;
}
</SCRIPT>
<IMG SRC="nu/xbar.gif" width=164 height=4><BR>

HAKOHDOC_14
);
	
	unset($ow); $ow = null;
	unset($ows); $ows = null;
	unset($cur); $cur = null;
	unset($id); $id = null;
	unset($point); $point = null;
	$_list_tmp = array(hako_get_env('HTTP_COOKIE'));
	unset($lcookie); $lcookie = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
	if (hako_regex('~OWNISLANDID=\(([^\)]*)\)~', $lcookie)) {
		$id = hako_m(1);
	}
	for ($y = 0; $y < $HislandSize; $y++) {
		out("<NOBR>");
		
		if (($y % 2) == 0) { out("<IMG SRC=\"nu/space{$y}.gif\" width=4 height=8 id=s{$y}>"); }
		
		for ($x = 0; $x < $HislandSize; $x++) {
			
			$ow  = $HlandOwner[$x][$y];
			$ows = "[" . (isset($HidToName[$ow]) ? $HidToName[$ow] : '') . "]";
			$cur = ($id == $ow && $ow != 0) ? 'cu' : 'nu';
			$point = "($x, $y)";
			if ($Hland[$x][$y] == $HlandSbase) {
				
				$ows = "[$HidToName[0]]";
			}
			$ls = landString($Hland[$x][$y], $HlandValue[$x][$y], $ows, $cur, $x, $y, 0, 8);
				out("<A HREF=\"JavaScript:void(0);\" onclick=\"px(" . $ow . ")\" onMouseOver=\"msg(" . $x . ", " . $y . ",'" . $ls[0] . "','" . $ls[1] . "'); return true;\" onMouseOut=\"window.status = '';\">");
				out("<IMG SRC=\"nu/" . $ls[1] . "\" width=8 height=8 BORDER=0 id=" . $x . "x" . $y . "></A>");
		}
		
		if (($y % 2) == 1) { out("<IMG SRC=\"nu/space{$y}.gif\" width=4 height=8 id=s{$y}>"); }
		out("</NOBR><BR>");
	}
	out("</TD></TR></TABLE></CENTER>\n");
}


/*
 * 함수: tempsetteiPage()
 * 역할: 설정 일람 페이지를 출력합니다.
 * 원본 대응: hako/hako-top.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function tempsetteiPage() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	out("<HR>$HtempBack");
	if ($Hlocalimage) {
		unset($setsumei); $setsumei = ($Hlocalimagehtml != '') ? "<p>자세하게는<a href=\"{$Hlocalimagehtml}\"target=\"_blank\">설명의 페이지</a>를 봐 주세요.  </p>" : "";
		unset($dlimg); $dlimg = ($HlocalImg != '') ? "화상은<B><a href=\"$HlocalImg\">여기</a> </B>로부터 다운로드해, 해동 후임뜻의 폴더에 격납해 주세요.<br>" : "";
		unset($Himfflag); $Himfflag = ($HimgLine == '') ? '<FONT COLOR=RED>미설정</FONT>' : $HimgLine;
		out(<<<HAKOHDOC_15
<HR><DIV ID='RecentlyLog'>
<H1>화상의 로컬 설정</H1>
$dlimg
참조의 버튼을 클릭해 PC의 로컬 디스크의 모형정원 화상 보존 폴더의<b>「qhw.css」</b>를 선택해 주세요. <BR>
지정의 폴더까지의 루트가 모두영숫자만의 폴더명을 추천 합니다. <BR>
반각 가나는 사용 불가능합니다. 또, 공백을 설정하면 지정이 해제됩니다.<BR><BR>
$setsumei
현재의 설정<B>[</b> {$Himfflag} <B>]</B>
<form action=$HthisFile method=POST>
<INPUT TYPE=file NAME="IMGLINE" SIZE="80">
<INPUT TYPE="submit" VALUE="설정" name=IMGSET>
</form>
</DIV>
HAKOHDOC_15
);
	}
	unset($Hskinflag); $Hskinflag = null;
	if ($HskinName == '' || $HskinName == "$HcssFile") {
		$Hskinflag = '<span class=attention>미설정</span>';
	} else {
		$Hskinflag = $HskinName;
	}
	unset($select_list); $select_list = "<OPTION value='del' selected>디폴트 \n";
	for ($_ = 0; $_ <= hako_last_index($HskinList); $_++) {
		if ($HskinList[$_] == $HskinName) { $Hskinflag = $HskinNameList[$_]; }
		$select_list .= "<OPTION value='$HskinList[$_]'>$HskinNameList[$_]\n";
	}
	unset($afname_list); $afname_list = "<SELECT NAME=\"AFNAME\">\n";
	for ($_ = 0; $_ <= hako_last_index($Haftername); $_++) {
		$afname_list .= "<OPTION value='$_'>$Haftername[$_]\n";
	}
	$afname_list .= "</SELECT>\n";
	out(<<<HAKOHDOC_16
<hr><div id='hakoSkin'>
<h1>스타일 시트의 설정</h1>
현재의 설정<b>[</b> {$Hskinflag} <b>]</b>
<form action=$HthisFile method=POST>
<SELECT NAME="SKIN">$select_list</SELECT>
<INPUT TYPE="submit" VALUE="설정" name=SKINSET>
</form>
</div>
<HR><DIV ID='changeInfo'>
<H1>나라의 이름과 패스워드의 변경</H1>
<P>
(주의) 이름의 변경에는 {$HcostChangeName}{$HunitMoney}걸립니다. (이름의 뒤로 붙는 녀석은 매회 지정해 주세요)<br>
※　이름의 뒤로 붙는 녀석만의 변경, 오너명이나 패스워드 변경은 무료.
</P>
<FORM action="$HthisFile" method="POST">
어느 나라입니까? <BR>
<SELECT NAME="ISLANDID">
$HislandList
</SELECT>
<BR>
어떤 이름으로 바꿉니까? (변경하는 경우만)<BR>
<INPUT TYPE="text" NAME="ISLANDNAME" SIZE=32 MAXLENGTH=32>$afname_list<BR>
어떤 오너명으로 바꿉니까? (변경하는 경우만)<BR>
<INPUT TYPE="text" NAME="OWNERNAME" SIZE=32 MAXLENGTH=32><BR>
패스워드는? (필수)<BR>
<INPUT TYPE="password" NAME="OLDPASS" SIZE=32 MAXLENGTH=32><BR>
새로운 패스워드는? (변경할 때)<BR>
<INPUT TYPE="password" NAME="PASSWORD" SIZE=32 MAXLENGTH=32><BR>
만약을 위해 패스워드를 다시 한번(변경할 때)<BR>
<INPUT TYPE="password" NAME="PASSWORD2" SIZE=32 MAXLENGTH=32><BR>
<INPUT TYPE="submit" VALUE="변경한다" NAME="ChangeInfoButton">
</FORM>
</DIV>
HAKOHDOC_16
);
}


/*
 * 함수: tempNewIslandPage()
 * 역할: 신규 섬 등록 안내 페이지를 출력합니다.
 * 원본 대응: hako/hako-top.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function tempNewIslandPage() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	unset($afname_list); $afname_list = "<SELECT NAME=\"AFNAME\">\n";
	for ($_ = 0; $_ <= hako_last_index($Haftername); $_++) {
		$afname_list .= "<OPTION value='$_'>$Haftername[$_]\n";
	}
	$afname_list .= "</SELECT>\n";
	out(<<<HAKOHDOC_17
<SCRIPT language="JavaScript">
<!--
function itemmsg(x){
	msg = new Array(16);
HAKOHDOC_17
);
	unset($i); $i = null;
	unset($Msg); $Msg = null;
	for ($i = 0; $i <= hako_last_index($FItemName); $i++) {
		$Msg = $FItemMsg[$i];
		out("msg[$i] = \"$Msg\";\n");
	}
	out(<<<HAKOHDOC_18
	document.getElementById("itemmsg").innerHTML = msg[x];
}
function NIslandButton(){
	var r = true;
	if((document.NIslandB.autoPoint.checked == true) && (document.NIslandB.POINTX.selectedIndex == 0 || document.NIslandB.POINTY.selectedIndex == 0)){
		r = confirm("희망의 좌표가(0, 0)입니다만, 좋습니까? ");
	}else if((document.NIslandB.autoPoint.checked == false) && (document.NIslandB.POINTX.selectedIndex > 0 || document.NIslandB.POINTY.selectedIndex > 0)){
		r = confirm("좌표 지정에 체크되고 있지 않습니다. 작성 좌표가 랜덤이 됩니다만 좋습니까?");
	}
	if(r == true) document.NIslandB.submit();
}
//-->
</SCRIPT>
<DIV ID='newIsland'>
<H1>참가하는 에 해당하는 제주의</H1>

<b>설정 일람·헬프를 자주(잘) 읽는다. </b><br>
　설정에 대해서는 「<A href=\"$HthisFile?SetupV=0\" TARGET=_blank>설정 일람</a>」을, 룰에 대해서는 「<A HREF="$helpDir" target="_blank">헬프</a>」를 참조해 주세요. <BR>
　설정 일람·헬프는, 헤더에도 링크가 있기 때문에, 읽어 둡시다. <br>
　헬프에는, 룰 외에 테크닉등도 수시 덧붙여 씀 해 있기 때문에 참고로 해 주세요. <br>
<br>

<b>·초심자 발언은 하지 않는다. </b><br>
　이 게임은 전쟁계 서바이벌입니다. 자국 이외의 모든 나라를 멸해 전국 통일이 목적이 됩니다. <br>
　초심자는 모습의 공격 대상이 됩니다. 어렵습니다만 초심자인 것에 응석부리지 않고 헬프를 자주(잘) 읽어 노력합시다! <br>
<br>

<b>·우선은 코멘트를 기입한다. </b><br>
　새로운 나라를 찾은 후, 1 시간내에 코멘트를 입력하고 있지 않는 경우, 자동 삭제됩니다. <br>
</DIV>
<hr>
<DIV ID='newIsland'>
<H1>새로운 나라를 작성한다</H1>
<span class=attention>중복 등록 금지입니다. 1명 1국으로 부탁합니다. <BR>
자국의 생존에 관계없이 특정의 나라를 고의로 이기게 하는 행위는 금지합니다. (일방적인 원조·방폐전의 원조등 )</span>
<FORM name="NIslandB" action="$HthisFile" method="POST">
국명을 입력해 주세요. (전각 9 문자, 반각 18 문자까지)<BR>
<INPUT TYPE="text" NAME="ISLANDNAME" SIZE=32 MAXLENGTH=18>$afname_list<BR>
지도자의 이름을 입력해 주세요. (전각 9 문자, 반각 18 문자까지)<BR>
<INPUT TYPE="text" NAME="OWNERNAME" SIZE=32 MAXLENGTH=18><BR>
희망의 좌표 설정한다<INPUT TYPE="checkbox" NAME="autoPoint">( <SELECT NAME=POINTX>
HAKOHDOC_18
);
	unset($i); $i = null;
	for ($i = 0; $i < $HislandSize; $i++) {
		out("<OPTION VALUE=$i>$i\n");
	}
	out(<<<HAKOHDOC_19
</SELECT>, <SELECT NAME=POINTY>
HAKOHDOC_19
);
	for ($i = 0; $i < $HislandSize; $i++) {
		out("<OPTION VALUE=$i>$i\n");
	}
	out(<<<HAKOHDOC_20
</SELECT> )<BR>
※　좌표 지정하는 경우, 체크를 해 희망의 좌표를 선택해 주세요. <BR>
<BR>
갖고 싶은 아이템을 1개선택해 주세요. (아이템은 부대에 아이템 장비 시켜 사용합니다)<BR>
<SELECT NAME=STARTITEM onchange="itemmsg(this.options[this.selectedIndex].value)">
HAKOHDOC_20
);
	for ($i = 0; $i <= hako_last_index($FItemName); $i++) {
		if (($i == 1) && ($FSItemID[$i] == 1)) {
			out("<OPTION VALUE=$i selected>$FItemName[$i]\n");
		} elseif ($FSItemID[$i] == 1) {
			out("<OPTION VALUE=$i>$FItemName[$i]\n");
		}
	}
	out(<<<HAKOHDOC_21
</SELECT>　∵’ <span id="itemmsg">$FItemMsg[1]</span><BR><BR>
패스워드는?<BR>
<INPUT TYPE="password" NAME="PASSWORD" SIZE=32 MAXLENGTH=32><BR>
만약을 위해 패스워드를 다시 한번<BR>
<INPUT TYPE="password" NAME="PASSWORD2" SIZE=32 MAXLENGTH=32><BR>
<INPUT TYPE="hidden" NAME="NewIslandButton">
<INPUT TYPE="button" VALUE="작성한다" onClick="NIslandButton()">
</FORM></DIV>
<HR>$HtempBack
HAKOHDOC_21
);
}


/*
 * 함수: logPrintTop()
 * 역할: 탑 페이지 최근 로그를 출력합니다.
 * 원본 대응: hako/hako-top.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logPrintTop() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	unset($i); $i = null;
	for ($i = 0; $i < $HtopLogTurn; $i++) {
		logFilePrint($i, 0, 0);
	}
}


/*
 * 함수: historyPrint()
 * 역할: 과거 로그/이력 데이터를 출력합니다.
 * 원본 대응: hako/hako-top.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function historyPrint() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	hako_open('HIN', "{$HdirName}/hakojima.his");
	unset($line); $line = array();
	unset($l); $l = null;
	while ($l = hako_getline('HIN')) {
		hako_chomp($l);
		hako_push($line, $l);
	}
	$line = reverse($line);

	foreach ($line as $l) {
		hako_regex('~^([0-9]*),(.*)$~', $l);
		out("<NOBR>{$HtagNumber_}턴 " . hako_m(1) . "{$H_tagNumber}│" . hako_m(2) . "</NOBR><BR>\n");
	}
	hako_close('HIN');
}

?>
