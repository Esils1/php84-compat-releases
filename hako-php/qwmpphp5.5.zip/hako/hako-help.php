<?php

/*
 * hako/hako-help.php
 * ------------------------------------------------------------
 * 설정 일람 출력 모듈
 *
 * 상세 주석 기준:
 * - 원본 대응: qwmp155.zip 의 hako-help.cgi.
 * - 현재 게임 설정값을 HTML로 보여주는 설정 일람 화면을 출력합니다.
 * - 숫자 설정의 의미 설명은 원본 help/설정 화면과 맞춰 유지해야 합니다.
 * - 원본 CGI 주석 라인 확인 수: 10줄. PHP 주석은 실행 결과를 바꾸지 않는 범위에서 복원/보강했습니다.
 *
 * 유지보수 원칙:
 * - 실행 로직, 저장 포맷, 배열 인덱스, 출력 HTML은 원본 CGI 호환성 대상입니다.
 * - 개조가 필요하면 먼저 해당 변수/함수가 어떤 파일 저장값과 연결되는지 확인하십시오.
 * - 이 주석은 유지보수용이며 실행 결과를 바꾸지 않습니다.
 */

chdir(dirname(__FILE__));
require_once dirname(__FILE__) . '/hako-compat.php';









/*
 * 함수: setupValue()
 * 역할: 현재 설정값 목록을 HTML로 출력합니다.
 * 원본 대응: hako/hako-help.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function setupValue() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	unset($mode); $mode = 1;
	unset($admin); $admin = null;

	if (checkPassword($HspecialPassword, $HdefaultPassword)) {
		$admin = 1;
		$mode = 0;
	} elseif (file_exists("qwhelp.html")) {
		out("<meta HTTP-EQUIV=\"refresh\" CONTENT=\"0; URL=setup.html\">");
	}

	unset($src); $src = null;
	unset($i); $i = null;
	unset($j); $j = null;
	unlock();

	unset($sec); $sec = ($HunitTime % 60);
	$sec = ($sec ? "{$sec}초" : '');
	unset($min); $min = ($HunitTime % 3600);
	$min = ($min ? "{$min}분" : '');
	unset($hour); $hour = intval($HunitTime / 3600);
	$hour = ($hour ? "{$hour}시간" : '');
	if (!($HflexTimeSet)) { unset($sttime); $sttime = "1 턴이 몇초인가　<B>{$HunitTime}초 ( $hour$min$sec )</B><BR>"; }

	unset($switchStr); $switchStr = array('OFF', 'ON');
	unset($enaStr); $enaStr = array('할 수 없는', '할 수 있는');
	unset($doStr); $doStr = array('하지 않는', '하는');
	unset($NdoStr); $NdoStr = array('하는', '하지 않는');
	unset($oxStr); $oxStr = array('×', '○', '◎');

	
	$landNameT = 14; 
	$landName[$HlandSea]     = "해";
	$landName[$HlandSbase]   = "해 미";
	$landName[$HlandMonster] = "괴";
	$landName[$HlandMonument]= "비";
	$landName[$HlandMountain]= "산";
	$landName[$HlandWaste]   = "황";
	$landName[$HlandPlains]  = "평";
	$landName[$HlandTown]    = "마을";
	$landName[$HlandForest]  = "숲";
	$landName[$HlandFarm]    = "농";
	$landName[$HlandFactory] = "공";
	$landName[$HlandBase]    = "미";
	$landName[$HlandDefence] = "방";
	$landName[$HlandSupply]  = "참";
	$divisionT = hako_last_index($Fdivision) + 1;

	unset($maxAidMoney); $maxAidMoney = $HmaxAidMoney * $HcomCost[$HcomMoney];
	unset($maxAidFood); $maxAidFood = $HmaxAidFood * -$HcomCost[$HcomFood];

	if ($mode) {
		$src = temphead($Htitle);
		$src .= <<<HAKOHDOC_0
$Body<DIV ID='BodySpecial'>
<DIV ID='LinkHead'>
<A HREF="http://t.pos.to/hako/" target="_blank">모형정원 제도 스크립트 배포원</A> /
<A HREF="$HthisFile">탑 돌아온다</A> /
</DIV>
<HR>
HAKOHDOC_0
;
	}
	$src .= <<<HAKOHDOC_1
<DIV ID='setupValue'>
<H1>모형정원 공통 맵 N　설정 일람</H1>
HAKOHDOC_1
;

	$src .= <<<HAKOHDOC_2
--- 관리인용 설정 확인 데이터 --- <BR><BR>

디버그 모드　<B>$switchStr[$Hdebug]</B><BR>
설치 디렉토리　<B>$HbaseDir</B><BR>
화상 디렉토리　<B>$imageDir</B><BR>
<BR>
로그 파일 보관 유지 턴수　<B>$HlogMax 턴</B><BR>
「최근의 사건」에 표시하는 로그의 턴수　<B>$HtopLogTurn 턴</B><BR>
백업을 무엇 턴 걸러서 취할까　<B>$HbackupTurn 턴</B><BR>
백업을 몇회분 남길까　<B>{$HbackupTimes}회분</B><BR>
발견 로그 보관 유지행수　<B>{$HhistoryMax}행</B><BR>
<BR>
로컬 게시판<BR>
　관광객의 로컬 게시판 익명 발언 기능　<B>$switchStr[$HlbbsAnon]</B><BR>
　발언에 발언자의 이름 표시　<B>$switchStr[$HlbbsSpeaker]</B><BR>
<BR>
--- 참가자용 설정 확인 데이터 --- <BR><BR>
HAKOHDOC_2
;
	if ($HragnarokTurn > 0) {
		$src .= "라그나로크가 방문하는 턴 <B>{$HragnarokTurn}턴</B>";
	} elseif ($Hragnarok == 0 || $HragnarokTurn < 0) {
		$src .= "라그나로크모드는 무효가 되고 있습니다. ";
	} else{
		$src .= "라그나로크모드는 유효가 되고 있습니다. (발생 턴 미정)";
	}
	$src .= <<<HAKOHDOC_3
<PRE>
※라그나로크모드
　전쟁·우호 관계에 관계없이 모든 나라가 전쟁 상태가 되는 기능입니다.

　나머지 3개국이 된 턴에 1위였던 나라가, 발생 턴을 결정할 수 있습니다.
　→　발생 턴은, 6 턴~50 턴 다음에 한 번 결정하면 변경은 할 수 없다.
　→　결정을 보류해 두는 일도 가능하지만, 순위가 떨어져 버리면 새롭고 1위가 된 나라에 결정권이 바뀐다.

　라그나로크가 방문하면 이하와 같이 됩니다.
　·모든 나라가 전쟁 상태가 됩니다.
　·모든 나라에 식료 100만 톤 무상 배포합니다. (발생 턴만)
　·모든 나라의 부상병이 모두 예비병에게 귀환합니다. (발생 턴만)

　※설정 턴의 1 턴전에 모든 전쟁·우호 상태가 파기됩니다.
　※관리인 맡아 하고 있었을 경우는 전쟁 상태가 되지 않습니다.
</PRE>
섬의 크기　<B>{$HislandSize}x{$HislandSize}</B>　커멘드 입력 한계수<B>{$HcommandMax}개</B><BR>$sttime
방폐 커멘드 자동 입력 턴수　<B>$HgiveupTurn 턴</B><BR>
<BR>
지구 모드　<B>$switchStr[$Hroundmode]</B>　ON의 경우 맵의 상하와 좌우가 연결됩니다. <BR>
<BR>
방폐된 국토의 그 후　<B>바다에 $NdoStr[$Hdeadisland]</B><BR>
<BR>
이름 변경의 코스트　<B>$HcostChangeName$HunitMoney</B><BR>
인구 1$HunitPop 근처의 식량 소비료　<B>{$HeatenFood}x1$HunitFood</B><BR>
턴배의 간격　<B>$HturnPrizeUnit 턴</B><BR>
외교 명령의 제한국 발견으로부터<B>{$Hatkturn}턴</B>간, 선전포고·우호 타진(어느 쪽인지에서도 해당하는 경우), 영토 할양, 자금원조, 식료 원조, 예비병 원조, 각종 미사일 발사를 할 수 없습니다. <BR>
강력한 공격의 제한국 발견으로부터<B>{$Hatkturn2}}턴</B>간, 방위 시설의 자폭, 괴수 파견, 육지 파괴 탄발 쏘아 맞히고가 할 수 없습니다. <BR>
방위 시설은, 괴수에게 밟혔을 때 자폭할까?　<B>$doStr[$HdBaseAuto]</B><BR>
안전 한계를 넘었을 때에 매립을 금지로 할까?　<B>$doStr[$HareaBorder]</B><BR>
<BR>
선전포고의 유예 턴　<B>$HdeclareTurn 턴</B><BR>
가격 변경 턴　<B>스타트로부터 $HdiscountTurn 턴까지</B><BR>
<BR>
초기 자금 등
<TABLE><TR>
<TH $HbgTitleCell rowspan=2>{$HtagTH_}초기 자금 / 최대 자금{$H_tagTH}{$H_tagTH}</TH>
<TH $HbgTitleCell rowspan=2>{$HtagTH_}초기 식료 / 최대 식량{$H_tagTH}</TH>
<TH $HbgTitleCell colspan=5>{$HtagTH_}최소단위{$H_tagTH}</TH>
<TH $HbgTitleCell colspan=4>{$HtagTH_}원조 제한{$H_tagTH}</TH>
</TR>
<TR $HbgInfoCell>
<TH $HbgTitleCell>{$HtagTH_}돈{$H_tagTH}</TH>
<TH $HbgTitleCell>{$HtagTH_}식량{$H_tagTH}</TH>
<TH $HbgTitleCell>{$HtagTH_}인구{$H_tagTH}</TH>
<TH $HbgTitleCell>{$HtagTH_}넓이{$H_tagTH}</TH>
<TH $HbgTitleCell>{$HtagTH_}나무의 수{$H_tagTH}</TH>
<TH $HbgTitleCell>{$HtagTH_}자금원조{$H_tagTH}</TH>
<TH $HbgTitleCell>{$HtagTH_}식량 원조{$H_tagTH}</TH>
<TH $HbgTitleCell>{$HtagTH_}예비병 원조{$H_tagTH}</TH>
<TH $HbgTitleCell>{$HtagTH_}영토 할양{$H_tagTH}</TH>
</TR>
<TR $HbgInfoCell>
<TD align='center'>$HinitialMoney$HunitMoney / $MaxMoney$HunitMoney</TD><TD align='center'>$HinitialFood$HunitFood / $MaxFood$HunitFood</TD>
<TD align='right'>1$HunitMoney</TD>
<TD align='right'>1$HunitFood</TD>
<TD align='right'>1$HunitPop</TD>
<TD align='right'>1$HunitArea</TD>
<TD align='right'>1$HunitTree</TD>
<TD align='right'>$maxAidMoney$HunitMoney</TD>
<TD align='right'>$maxAidFood$HunitFood</TD>
<TD align='right'>$HmaxAidSoldier$HunitPop</TD>
<TD align='right'>$HmaxAidArea$HunitArea</TD>
</TR>
</TABLE>
※　원조 제한과는 1 턴으로 할 수 있는 최대의 원조액·할양 할 수 있는 영토입니다. (자금원조와 식료 원조는 자국보다 많은 나라에는 원조할 수 없습니다)
<hr>
군대 모드　<B>$switchStr[$Hnoarmy]</B><BR>
<TABLE><TR>
<TH $HbgTitleCell rowspan=2>{$HtagTH_}병종 명칭{$H_tagTH}</TH>
<TH $HbgTitleCell rowspan=2>{$HtagTH_}점령{$H_tagTH}</TH>
<TH $HbgTitleCell rowspan=2>{$HtagTH_}간접{$H_tagTH}</TH>
<TH $HbgTitleCell rowspan=2>{$HtagTH_}ZOC<BR>유무{$H_tagTH}</TH>
<TH $HbgTitleCell rowspan=2>{$HtagTH_}ZOC<BR>무시{$H_tagTH}</TH>
<TH $HbgTitleCell rowspan=2>{$HtagTH_}색적<BR>범위{$H_tagTH}</TH>
<TH $HbgTitleCell rowspan=2>{$HtagTH_}적적<BR>이동{$H_tagTH}</TH>
<TH $HbgTitleCell rowspan=2>{$HtagTH_}병종<BR>고정{$H_tagTH}</TH>
<TH $HbgTitleCell colspan=$landNameT>{$HtagTH_}이동 가부{$H_tagTH}</TH>
</TR><TR $HbgInfoCell>
HAKOHDOC_3
;
	for ($i = 0; $i <= 50; $i++) {
		if (isset($landName[$i]) && $landName[$i] != '') {
			$src .= "<TH $HbgTitleCell>$landName[$i]</TH>";
		}
	}
	$src .= "</TR>";
	for ($i = 0; $i <= hako_last_index($Fdivision); $i++) {
		$src .= <<<HAKOHDOC_4
<TR $HbgInfoCell>
<TD align='left'>$Fdivision[$i]</TD>
<TD align='center'>{$oxStr[$FoccupyFlg[$i]]}</TD>
<TD align='center'>{$oxStr[$FartilleryFlg[$i]]}</TD>
<TD align='center'>{$oxStr[$FzocFlg[$i]]}</TD>
<TD align='center'>{$oxStr[$FnoZocFlg[$i]]}</TD>
<TD align='center'>$FsearchR[$i]</TD>
<TD align='center'>{$oxStr[$Feemove[$i]]}</TD>
<TD align='center'>{$oxStr[$Fnochange[$i]]}</TD>
HAKOHDOC_4
;
		for ($j = 0; $j <= 50; $j++) {
			if (isset($landName[$j]) && $landName[$j] != '') {
				$src .= "<TD align='center'>" . $oxStr[isset($FmapMove[$i][$j]) ? $FmapMove[$i][$j] : 0] . "</TD>";
			}
		}
	}
	$src .= <<<HAKOHDOC_5
</TABLE>
※　점령··×점령 불가, 0미만 점령,◎점령. (자세하게는 헬프의 지형 저항력을 참조)<BR>
※　간접··○공격시 1에 쿠스 멀어진 부대도 공격, 간접 공격은 반격 되지 않는,◎공격시 1에 쿠스 멀어진 부대도 공격, 거리에 관계없이 반격 되지 않는다<BR>
※　ZOC 유무··부대가 ZOC 유효의 적부대에 접하고 있는 경우, ZOC 유효의 적부대에 접하고 있는 장소에 이동 불가. (자세하게는 헬프 참조)<BR>
※　ZOC 무시··어디에 이동할려고도 ZOC의 영향을 일절 받지 않는다. <BR>
※　이동 가부··×이동 불가, ○1 매스 이동,◎최대 2 매스 이동<BR>
※　적적이동··×자국 이외 영토→자국 이외 영토의 이동을 할 수 없다. ○할 수 있다. <BR>
※　병종 고정··○추가 부대 설치해도 보충만으로 병종의 변경은 되지 않는다. <BR>
<TABLE><TR>
<TH $HbgTitleCell rowspan=2>{$HtagTH_}병종 명칭{$H_tagTH}</TH>
<TH $HbgTitleCell colspan=$divisionT>{$HtagTH_}대  부대 특성{$H_tagTH}</TH>
<TH $HbgTitleCell colspan=$landNameT>{$HtagTH_}지형 효과{$H_tagTH}</TH>
</TR><TR $HbgInfoCell>
HAKOHDOC_5
;
	for ($i = 0; $i <= hako_last_index($Fdivision); $i++) {
		$src .= "<TH $HbgTitleCell>$FdivisionS[$i]</TH>";
	}
	for ($i = 0; $i <= 50; $i++) {
		if (isset($landName[$i]) && $landName[$i] != '') {
			$src .= "<TH $HbgTitleCell>$landName[$i]</TH>";
		}
	}
	$src .= "</TR>";
	for ($i = 0; $i <= hako_last_index($Fdivision); $i++) {
		$src .= "<TR $HbgInfoCell><TD align='left'>$Fdivision[$i]</TD>";
		for ($j = 0; $j <= hako_last_index($Fdivision); $j++) {
			$src .= "<TD align='center'>" . $FunitPt[$i][$j] . "</TD>";
		}
		for ($j = 0; $j <= 50; $j++) {
			if (isset($landName[$j]) && $landName[$j] != '') {
				$src .= "<TD align='center'>" . (isset($FmapPt[$i][$j]) ? $FmapPt[$i][$j] : '') . "</TD>";
			}
		}
		$src .= "</TR>";
	}
	$src .= <<<HAKOHDOC_6
</TABLE>
<PRE><B>공격력의 계산</B>

병력　＋　(0~경험치-1)　÷　10　×　대부대 특성　÷　10　×　지원 효과　×　지형 효과　÷　10
※　소수점 이하는 잘라 버려 결과가 1 이하의 경우는 1이 됩니다.
※　지형 효과의 대상은, 공격 상대측의 지형입니다.
※　지원 효과는, 공격측의 주위 1 헤크스에 들어가는 자국 부대수가 대상이 됩니다만··.
　　이 수의 산출 방법은 랜덤입니다. 0~주위 1 헤크스의 자국 부대수가 됩니다.
　　(100　＋　30　×　대상의 수)　÷　100

반격은, 이하와 같이 됩니다. (병력은, 공격에 의해 감소한 수)
병력　＋　(0~경험치-1)　÷　20　×　대부대 특성　÷　10　×　지형 효과　÷　10

포병은, 지원 효과의 산출 방법이 다릅니다. 또, 반격 되지 않습니다.
※　지원 효과는, 0~주위 2 헤크스의 자국 부대수가 됩니다.
　　(100　＋　15　×　대상의 수)　÷　100
</PRE>
<hr>
미사일에 대해<BR><BR>
※　미사일 기지의 레벨에 의해 성장하는 사정거리와 증가하는 발사수는, 아래와 같은 겉(표)를 참조. <BR>
※　목표가 사정 범위의 미사일 기지가 없는 경우, 명령은 중지됩니다. <BR>
<BR><BR>
경험치에 의한 미사일 기지의 사정과 발사수
<TABLE>
<TR $HbgTitleCell><TH $HbgTitleCell>{$HtagTH_}경험치{$H_tagTH}</TH><TH $HbgTitleCell>{$HtagTH_}0{$H_tagTH}</TH>
HAKOHDOC_6
;
	for ($i = 0;$i <= hako_last_index($baseLevelUp);$i++) {
		$src .= "<TH $HbgTitleCell>{$HtagTH_}$baseLevelUp[$i]{$H_tagTH}</TH>";
	}
	$src .= "</TR><TR $HbgInfoCell><TD><b>사정</b></TD><TD><b>$HmissileRange</b></TD>";
	for ($i = 0;$i < hako_last_index($baseLevelUp) + 1;$i++) {
		$HmissileRange++;
		$src .= "<TD><b>$HmissileRange</b></TD>";
	}
	unset($ct); $ct = 1;
	$src .= "</TR><TR $HbgInfoCell><TD><b>발사수</b></TD><TD><b>$ct</b></TD>";
	for ($i = 0;$i < hako_last_index($baseLevelUp) + 1;$i++) {
		if ($baseLevelUp[$i] >= $baseLevelUp2[$ct-1]) { $ct++; }
		$src .= "<TD><b>$ct</b></TD>";
	}
	$src .= <<<HAKOHDOC_7
</TR></TABLE>
<BR>
경험치에 의한 해저 미사일 기지의 사정과 발사수
<TABLE>
<TR $HbgTitleCell><TH $HbgTitleCell>{$HtagTH_}경험치{$H_tagTH}</TH><TH $HbgTitleCell>{$HtagTH_}0{$H_tagTH}</TH>
HAKOHDOC_7
;
	for ($i = 0;$i <= hako_last_index($sBaseLevelUp);$i++) {
		$src .= "<TH $HbgTitleCell>{$HtagTH_}$sBaseLevelUp[$i]{$H_tagTH}</TH>";
	}
	$src .= "</TR><TR $HbgInfoCell><TD><b>사정</b></TD><TD><b>$HmissileRangeS</b></TD>";
	for ($i = 0;$i < hako_last_index($sBaseLevelUp) + 1;$i++) {
		$HmissileRangeS++;
		$src .= "<TD><b>$HmissileRangeS</b></TD>";
	}
	$ct = 1;
	$src .= "</TR><TR $HbgInfoCell><TD><b>발사수</b></TD><TD><b>$ct</b></TD>";
	for ($i = 0;$i < hako_last_index($sBaseLevelUp) + 1;$i++) {
		if ($sBaseLevelUp[$i] >= $sBaseLevelUp2[$ct-1]) { $ct++; }
		$src .= "<TD><b>$ct</b></TD>";
	}
	$src .= "</TR></TABLE><hr>";

	$HdisEarthquake *= 0.1; 
	$HdisTsunami    *= 0.1; 
	$HdisMeteo      *= 0.1; 
	$HdisMeteo2     *= 0.1; 
	$HdisHugeMeteo  *= 0.1; 
	$HdisHugeMeteo2 *= 0.1; 
	$HdisEruption   *= 0.1; 
	$HdisFire       *= 0.1; 
	$HdisMaizo      *= 0.1; 

	$HdisFalldown   *= 0.1; 
	$HdisMonster    *= 0.01;
	$HdisapearMons  *= 0.1; 
	$src .= <<<HAKOHDOC_8
섬전체의 재해 등
<TABLE>
<TR>
<TH $HbgTitleCell rowspan=2>{$HtagTH_}지진{$H_tagTH}</TH>
<TH $HbgTitleCell rowspan=2>{$HtagTH_}해일{$H_tagTH}</TH>
<TH $HbgTitleCell rowspan=2>{$HtagTH_}분화{$H_tagTH}</TH>
<TH $HbgTitleCell colspan=3>{$HtagTH_}운석{$H_tagTH}</TH>
<TH $HbgTitleCell colspan=3>{$HtagTH_}거대 운석{$H_tagTH}</TH>
</TR>
<TR $HbgInfoCell>
<TH $HbgTitleCell>{$HtagTH_}통상 확률{$H_tagTH}</TH><TH $HbgTitleCell>{$HtagTH_}안전 한계의 넓이{$H_tagTH}</TH><TH $HbgTitleCell>{$HtagTH_}넘었을 경우의 확률{$H_tagTH}</TH>
<TH $HbgTitleCell>{$HtagTH_}통상 확률{$H_tagTH}</TH><TH $HbgTitleCell>{$HtagTH_}안전 한계의 넓이{$H_tagTH}</TH><TH $HbgTitleCell>{$HtagTH_}넘었을 경우의 확률{$H_tagTH}</TH>
</TR>
<TR $HbgInfoCell><TD align='right'>{$HdisEarthquake}%</TD><TD align='right'>{$HdisTsunami}%</TD>
<TD align='right'>{$HdisEruption}%</TD>
<TD align='right'>{$HdisMeteo}%</TD>
<TD align='right'>$HdisFallBorder$HunitArea</TD>
<TD align='right'>{$HdisMeteo2}%</TD>
<TD align='right'>{$HdisHugeMeteo}%</TD>
<TD align='right'>$HdisFallBorder$HunitArea</TD>
<TD align='right'>{$HdisHugeMeteo2}%</TD></TR>
</TABLE>
※　거대 운석·운석은 확률에 관계없이{$HdisNoMeteoTurn}턴까지는, 절대로 발생하지 않습니다. <BR>
※　해일은, 바다(얕은 여울 포함한다)에 지진·분화가 발생했을 경우에 50%의 확률로 발생합니다. <BR>
<BR>
단위면적 근처에서 발생하는 재해 등
<TABLE><TR $HbgInfoCell>
<TH $HbgTitleCell>{$HtagTH_}화재{$H_tagTH}</TH><TH $HbgTitleCell>{$HtagTH_}매장금{$H_tagTH}</TH>
<TH $HbgTitleCell>{$HtagTH_}단위면적 근처<br>의 괴수 출현율{$H_tagTH}</TH><TH $HbgTitleCell>{$HtagTH_}재해 괴수가 데미지 1을 받는 확률{$H_tagTH}</TH>
</TR>
<TR $HbgInfoCell><TD align='right'>{$HdisFire}%</TD><TD align='right'>{$HdisMaizo}%</TD>
<TD align='right'>{$HdisMonster}%</TD><TD align='right'>{$HdisapearMons}%</TD>
</TR>
</TABLE>
※　화재는, 인구 10만명 미만의 나라에서는 발생하지 않습니다. (턴 개시시의 인구) <BR>
　　또 인구가 20만을 넘으면(자) 1만명 마다 0. 1%발생율이 높아집니다.  <BR>
　　겉(표)에 표시되고 있는 확률은, 인구가 10만~20만의 경우의 확률이 됩니다.  <BR>
※　괴수 레벨 1의 괴수는 1회로 소멸합니다. <BR>
<HR>
괴수 출현 면적 기준 1(괴수 레벨 1)　<B>$HdisMonsBorder1$HunitArea</B><BR>
HAKOHDOC_8
;
for ($_ = 1; $_ <= $HmonsterLevel1; $_++) {
	$src .= "$HmonsterName[$_] ";
}
$src .= "<BR><BR>괴수 출현 면적 기준 2(괴수 레벨 2)　<B>$HdisMonsBorder2$HunitArea</B><BR>";
for ($_ = 1; $_ <= $HmonsterLevel2; $_++) {
	$src .= "$HmonsterName[$_] ";
}
$src .= "<BR><BR>괴수 출현 면적 기준 3(괴수 레벨 3)　<B>$HdisMonsBorder3$HunitArea</B><BR>";
for ($_ = 1; $_ <= $HmonsterLevel3; $_++) {
	$src .= "$HmonsterName[$_] ";
}
	$src .= <<<HAKOHDOC_9

<TABLE><TR>
<TH $HbgTitleCell colspan=2 rowspan=2>{$HtagTH_}괴수의 명칭{$H_tagTH}</TH>
<TH $HbgTitleCell colspan=2>{$HtagTH_}체력{$H_tagTH}</TH>
<TH $HbgTitleCell rowspan=2>{$HtagTH_}경험치{$H_tagTH}</TH>
<TH $HbgTitleCell rowspan=2>{$HtagTH_}잔해의 가격{$H_tagTH}</TH>
<TH $HbgTitleCell rowspan=2>{$HtagTH_}기본적인 능력{$H_tagTH}</TH></TR>
<TR><TH $HbgTitleCell>{$HtagTH_}min{$H_tagTH}</TH><TH $HbgTitleCell>{$HtagTH_}max{$H_tagTH}</TH></TR>
HAKOHDOC_9
;

$Monspe = array("특별히 이루어","발이 빠른(최대 2보 걷는다)","다리가 매우 빠른(최대하보 걸을까 불명)","홀수 턴은 경화","짝수 턴은 경화","항상 경화이지만 25%로 맞는다");
	for ($i = 0; $i <= hako_last_index($HmonsterName); $i++) {
		unset($maxHP); $maxHP = $HmonsterBHP[$i] + $HmonsterDHP[$i] - 1;
		if (!$HmonsterDHP[$i]) { $maxHP++; }
		$src .= <<<HAKOHDOC_10
<TR $HbgInfoCell>
<TD align='right'><img src='nu/$HmonsterImage[$i]'></TD>
<TD align='left'>$HmonsterName[$i]</TD>
<TD align='right'>$HmonsterBHP[$i]</TD><TD align='right'>$maxHP</TD>
<TD align='right'>$HmonsterExp[$i]</TD><TD align='right'>$HmonsterValue[$i]$HunitMoney</TD>
<TD align='left'>{$Monspe[$HmonsterSpecial[$i]]}</TD></TR>
HAKOHDOC_10
;
	}
	$src .= <<<HAKOHDOC_11

</TABLE>

HAKOHDOC_11
;

	if ($mode) {
		// UTF-8로 변환된 PHP판에서는 정적 setup.html이 HTTP 헤더 없이 직접 열립니다.
		// 원본 CGI는 euc-kr 출력이었지만, PHP판은 UTF-8 저장이므로 브라우저가 문자셋을 잘못 추정하면 한글이 깨집니다.
		// 동적 관리자용 화면은 PHP 헤더로 문자셋을 보장하므로, 정적 파일 생성시에만 meta charset을 추가합니다.
		if (!hako_regex('~charset\s*=\s*["\']?utf-8~i', $src)) {
			$__setup_src = preg_replace('~(<head[^>]*>)~i', "$1\n<META HTTP-EQUIV=\"Content-Type\" CONTENT=\"text/html; charset=UTF-8\">", $src, 1);
			if ($__setup_src === null || $__setup_src === $src) {
				$src = "<META HTTP-EQUIV=\"Content-Type\" CONTENT=\"text/html; charset=UTF-8\">\n" . $src;
			} else {
				$src = $__setup_src;
			}
		}
		hako_open('OUT', ">{$HefileDir}/setup.html");
		hako_write('OUT', ($src));
		hako_close('OUT');
		@chmod("{$HefileDir}/setup.html", 0666);

		out("<meta HTTP-EQUIV=\"refresh\" CONTENT=\"0; URL={$efileDir}/setup.html\">");
	} else {
		out("$src");
	}
}

?>
