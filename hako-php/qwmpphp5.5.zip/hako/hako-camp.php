<?php

/*
 * hako/hako-camp.php
 * ------------------------------------------------------------
 * 진영 화면/진영 맵/진영별 명령 표시 모듈
 *
 * 상세 주석 기준:
 * - 원본 대응: qwmp155.zip 의 hako-camp.cgi.
 * - 진영 선택/진영 지도/진영별 섬 정보/진영 화면용 명령 읽기를 담당합니다.
 * - 진영 비밀번호, 진영 마크, 소속 표시, 진영게시판 링크는 hako-init.php 설정값과 연결됩니다.
 * - 원본 CGI 주석 라인 확인 수: 33줄. PHP 주석은 실행 결과를 바꾸지 않는 범위에서 복원/보강했습니다.
 *
 * 유지보수 원칙:
 * - 실행 로직, 저장 포맷, 배열 인덱스, 출력 HTML은 원본 CGI 호환성 대상입니다.
 * - 개조가 필요하면 먼저 해당 변수/함수가 어떤 파일 저장값과 연결되는지 확인하십시오.
 * - 이 주석은 유지보수용이며 실행 결과를 바꾸지 않습니다.
 */

chdir(dirname(__FILE__));
require_once dirname(__FILE__) . '/hako-compat.php';














/*
 * 함수: campMain()
 * 역할: 진영 화면 전체를 출력합니다.
 * 원본 대응: hako/hako-camp.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function campMain() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HcurrentNumber = $HidToNumber[$HcurrentID];
	$HcurrentCamp =& $Hislands[$HcurrentNumber];
	

	unlock();

	
	if (!checkPassword($HcurrentCamp['password'],$HinputPassword)) {
		
		tempWrongPassword();
		return;
	}
	$HcurrentCampID = $HcurrentCamp['ally'];

	out(<<<HAKOHDOC_0
<DIV align='center'>
{$HtagBig_}진영 일람표시{$H_tagBig}<BR>
$HtempBack<BR><BR>
</DIV>
<table border=0><tr><td>
HAKOHDOC_0
);
	campMap($HcurrentCampID);
	out("</td><TD>");
	campAllIslandsInfo(); 

	out("</td></tr></table>");
}





/*
 * 함수: campMap()
 * 역할: 진영별 지도 표시를 출력합니다.
 * 원본 대응: hako/hako-camp.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function campMap() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	unset($HcurrentCampID); $HcurrentCampID = isset($_args[0]) ? $_args[0] : null;
	unset($widthsize); $widthsize = $HislandSize * 32 + 16;
	$Hcolormap = 1;
	out(<<<HAKOHDOC_1
<CENTER><TABLE BORDER><TR><TD>
<IMG SRC="nu/xbar.gif" width=$widthsize height=16><BR>
HAKOHDOC_1
);
	
	unset($x); $x = null;
	unset($y); $y = null;
	unset($ow); $ow = null;
	unset($ows); $ows = null;
	unset($cur); $cur = null;
	unset($DivPw); $DivPw = null;
	unset($disp); $disp = null;
	unset($i); $i = null;
	unset($id); $id = null;
	unset($island); $island = null;
	for ($y = 0; $y < $HislandSize; $y++) {
		out("<NOBR>");
		
		if (($y % 2) == 0) { out("<IMG SRC=\"nu/space{$y}.gif\" width=16 height=32>"); }
		
		for ($x = 0; $x < $HislandSize; $x++) {
			$ow  = $HlandOwner[$x][$y];
			$ows = "[" . (isset($HidToName[$ow]) ? $HidToName[$ow] : '') . "]";
			$cur = 'nu';
			if ($Hland[$x][$y] == $HlandSbase) {
				

				$ows = "[$HidToName[0]]";
			}
			$DivPw = 0;
			if ($HlandDivPw[$x][$y] > 0) {
				$disp = 0;
				$sflg = array(1,7,19,37);
				for ($_ = 1; $_ <= 36; $_++) {
					
					$_list_tmp = array($x + $ax[$_],$y + $ay[$_]);
					unset($sx); $sx = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
					unset($sy); $sy = isset($_list_tmp[1]) ? $_list_tmp[1] : null;
					if (!($sy % 2) && ($y % 2)) { $sx--; }
					if ($Hroundmode) {
						$sx = $correct[$sx + 12];
						$sy = $correct[$sy + 12];
					}
					if (($sx < 0) || ($sx >= $HislandSize) || ($sy < 0) || ($sy >= $HislandSize)) { continue; }

					
					for ($i = 0; $i < $HislandNumber; $i++) {
						if (($Hislands[$i]['ally'] == '') || ($Hislands[$i]['ally'] < 1)) { continue; }
						if ($HcurrentCampID == $Hislands[$i]['ally']) {
							$island =& $Hislands[$i];
							$id = $island['id'];
								if ((($_ < $sflg[$FsearchR[$HlandDiv[$sx][$sy]]]) && ($HlandDivNa[$sx][$sy] == $id) && ($HlandDivPw[$sx][$sy] > 0)) ||
									(($_ < 19) && ($HlandOwner[$sx][$sy] == $id) && ($Hland[$sx][$sy] == $HlandSupply)) ||
									(($_ < 19) && ($HlandOwner[$sx][$sy] == $id) && ($Hland[$sx][$sy] == $HlandMountain))) {
								

								$disp = 1;
								break;
							}
						}
					}
					if ($disp) { break; }
				}
				if (($id == $HlandDivNa[$x][$y]) || ($id == $ow) || ($disp)) {
					$ofname = $island['fleet'];
					$HGr  = $island['HGr'];
					$Div  = $island['Div'];
					$DivPw = $island['DivPw'];
					$DivLv = $island['DivLv'];
					$DivEx = $island['DivEx'];
					$DivNa = $island['DivNa'];
					if ($id != $HlandDivNa[$x][$y]) {
						$color = array('red', 'red', 'red', 'red','red', 'red', 'red', 'red');
					} else{
						$color = array('white', 'white', 'white', 'white','white', 'white', 'white', 'white');
					}
				} else{
					$DivPw = 0;
				}
			}
			landString($Hland[$x][$y], $HlandValue[$x][$y], $ows, $cur, $x, $y, 0, 0, "", $ofname, $HGr, $Div, $DivPw, $DivLv, $DivEx, $DivNa, $color, "");
		}
		
		if (($y % 2) == 1) { out("<IMG SRC=\"nu/space{$y}.gif\" width=16 height=32>"); }
		out("</NOBR><BR>");
	}
	out("</TD></TR></TABLE></CENTER>\n");
}


/*
 * 함수: campAllIslandsInfo()
 * 역할: 진영 화면용 전체 섬 정보를 출력합니다.
 * 원본 대응: hako/hako-camp.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function campAllIslandsInfo() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	
	unset($i); $i = null;
	for ($i = 0; $i < $HislandNumber; $i++) {
		$_list_tmp = readCommands($Hislands[$i]['id']);
		$Hislands[$i]['command'] = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
	}

	
	for ($i = 0; $i < $HislandNumber; $i++) {
		if (($Hislands[$i]['ally'] == '') || ($Hislands[$i]['ally'] < 1)) { continue; }
		if ($HcurrentCampID == $Hislands[$i]['ally']) {
			campIslandInfo($Hislands[$i], $i+1);
		}
	}

}


/*
 * 함수: readCommands()
 * 역할: 섬의 명령 데이터를 진영 화면 표시용으로 읽습니다.
 * 원본 대응: hako/hako-camp.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function readCommands() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($command); $command = array();
	unset($line); $line = null;
	unset($i); $i = null;
	if (!hako_open('IIN', "{$HdirName}/island.$id")) {
		@rename("{$HdirName}/islandtmp.$id", "{$HdirName}/island.$id");
		if (!hako_open('IIN', "{$HdirName}/island.$id")) { exit(0); }
	}
	for ($i = 0; $i < $HcommandMax; $i++) {
		$line = hako_getline('IIN');
		hako_regex('~^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$~', $line);
		$command[$i] = array('kind'=>intval(hako_m(1)), 'target'=>intval(hako_m(2)), 'x'=>intval(hako_m(3)), 'y'=>intval(hako_m(4)), 'arg'=>intval(hako_m(5)));
	}
	hako_close('IIN');

	
	return $command;
}

/*
 * 함수: campIslandInfo()
 * 역할: 진영 화면용 개별 섬 정보를 출력합니다.
 * 원본 대응: hako/hako-camp.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function campIslandInfo() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	unset($island); $island = isset($_args[0]) ? $_args[0] : null;
	unset($rank); $rank = isset($_args[1]) ? $_args[1] : null;

	
	$id = $island['id'];
	unset($name); $name = null;
	$money = "{$island['money']}$HunitMoney";
	$food = "{$island['food']}$HunitFood";
	if ($island['absent']  == 0) {
		$name = "{$HtagName_}{$island['name']}{$H_tagName}";
	} else {
		$name = "{$HtagName2_}{$island['name']}({$island['absent']}){$H_tagName2}";
	}

	out(<<<HAKOHDOC_2
<table><tr><th $HbgTitleCell>데이터</th><th $HbgTitleCell>NO</th><th $HbgTitleCell>명령</th><th $HbgTitleCell>목표</th><th $HbgTitleCell>좌표 1</th><th $HbgTitleCell>수량</th>
<tr><td rowspan=30>
<A HREF=\"$HthisFile?Sight={$id}\" class=\"M\" TARGET=_blank>$name</A><br>
{$island['ownername']}<br><br>
자금：{$island['money']}$HunitMoney<br>
식량：{$island['food']}$HunitFood<br>
</td>
HAKOHDOC_2
);
	for ($i = 0; $i < 15; $i++) {
		campCommand($i, $island['command'][$i]);
	}
	out("</table>");
}


/*
 * 함수: campCommand()
 * 역할: 진영 화면에서 입력된 명령 목록을 출력합니다.
 * 원본 대응: hako/hako-camp.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function campCommand() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	unset($number); $number = isset($_args[0]) ? $_args[0] : null;
	unset($command); $command = isset($_args[1]) ? $_args[1] : null;
		$kind = $command['kind'];
		$target = $command['target'];
		$x = $command['x'];
		$y = $command['y'];
		$arg = $command['arg'];
	$name = $HtagComName_ . (isset($HcomName[$kind]) ? $HcomName[$kind] : '') . $H_tagComName;
	$point = "$HtagName_($x,$y)$H_tagName";
	$id = $target;
	$target = isset($HidToName[$target]) ? $HidToName[$target] : '';
	if ($target == '') {
		$target = "-------";
	} else{
		$target = "<A HREF=\"$HthisFile?Sight={$id}\" class=\"M\" TARGET=_blank>$HtagName_[$target]$H_tagName</a>";
	}
	$value = $arg * $HcomCost[$kind];
	if ($value == 0) { $value = $HcomCost[$kind]; }
	if ($value < 0) {
		$value = -$value;
		$value = "$value$HunitFood";
	} else {
		$value = "$value$HunitMoney";
	}
	$value = "$HtagName_$value$H_tagName";
	$j = sprintf("%02d", $number + 1);
	if ($number > 0) { out("<tr>"); }
	out("<td>$HtagNumber_$j$H_tagNumber</td>");
	out("<td>{$name}</td><td>{$target}</td><td>{$point}</td><td>{$arg}</td>");
	out("</tr>");
}

?>
