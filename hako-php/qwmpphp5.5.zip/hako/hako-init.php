<?php

/*
 * hako/hako-init.php
 * ------------------------------------------------------------
 * 환경/URL/잠금/진영/스킨 기본 설정 파일
 *
 * 상세 주석 기준:
 * - 원본 대응: test1155.zip 의 hako-init.cgi.
 * - 서버 경로, URL, 데이터 디렉터리, 로그/백업/턴 시간, 진영 기능, 게시판 경로, 스킨 설정을 정의합니다.
 * - 실서버 업로드 시 수정이 필요한 값은 주로 이 파일의 URL/경로/관리자/게시판 설정입니다.
 * - 게임 로직 파일이 이 값을 전역 변수로 직접 읽으므로 변수명 변경은 금지합니다.
 * - 원본 CGI 주석 라인 확인 수: 99줄. PHP 주석은 실행 결과를 바꾸지 않는 범위에서 복원/보강했습니다.
 *
 * 유지보수 원칙:
 * - 실행 로직, 저장 포맷, 배열 인덱스, 출력 HTML은 원본 CGI 호환성 대상입니다.
 * - 개조가 필요하면 먼저 해당 변수/함수가 어떤 파일 저장값과 연결되는지 확인하십시오.
 * - 이 주석은 유지보수용이며 실행 결과를 바꾸지 않습니다.
 */

chdir(dirname(__FILE__));
require_once dirname(__FILE__) . '/hako-compat.php';


//----------------------------------------------------------------------
// 서버/시간대 기본 설정
//----------------------------------------------------------------------
putenv("TZ=KST-9"); date_default_timezone_set("Asia/Seoul");


//----------------------------------------------------------------------
// 기본 파일명과 공개 URL 설정
// 실서버 업로드 시 주로 수정하는 영역
//----------------------------------------------------------------------
$Hdebug = 0; // 디버그 출력 여부입니다. 실서버에서는 0 유지가 안전합니다.



$HpasswordFile = 'passwd.php'; // 섬/관리자 비밀번호 저장 파일명입니다.



$HdirName = 'data'; // 게임 데이터 디렉터리입니다.


// 현재 설치 위치를 기준으로 공개 URL을 자동 계산합니다.
// 예: /game/qwmpphp5.5/hako/hako-main.php 로 접속하면
//     $HbaseDir=/game/qwmpphp5.5/hako, $imageDir=/game/qwmpphp5.5/image 로 설정됩니다.
if (!function_exists('hako_detect_public_url')) {
	function hako_detect_public_url($dir) {
		$https = false;
		if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== '' && strtolower($_SERVER['HTTPS']) !== 'off') { $https = true; }
		if (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && strtolower($_SERVER['HTTP_X_FORWARDED_PROTO']) === 'https') { $https = true; }
		$scheme = $https ? 'https' : 'http';
		$host = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '';

		$docRoot = isset($_SERVER['DOCUMENT_ROOT']) ? str_replace('\\', '/', realpath($_SERVER['DOCUMENT_ROOT'])) : '';
		$realDir = str_replace('\\', '/', realpath($dir));
		$path = '';

		if ($docRoot !== '' && $realDir !== false && strpos($realDir, $docRoot) === 0) {
			$path = substr($realDir, strlen($docRoot));
		} elseif (isset($_SERVER['SCRIPT_NAME'])) {
			$scriptDir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME']));
			if (basename($scriptDir) === 'hako') {
				$path = $scriptDir;
			} else {
				$path = rtrim($scriptDir, '/') . '/hako';
			}
		} else {
			$path = '.';
		}

		$path = '/' . trim(str_replace('\\', '/', $path), '/');
		if ($path === '/') { $path = ''; }
		return ($host !== '') ? ($scheme . '://' . $host . $path) : $path;
	}
}

$HbaseDir = hako_detect_public_url(dirname(__FILE__));


$imageDir = dirname($HbaseDir) . '/image';






$Hlocalimage = 1; // 로컬 이미지 설정 사용 여부입니다.

$Hlocalimagehtml = "";

$HlocalImg = "";


$HthisFile = "{$HbaseDir}/hako-main.php"; // 메인 PHP 파일 URL입니다.


$HmenteFile = "{$HbaseDir}/hako-mente.php"; // 관리자 PHP 파일 URL입니다.


$helpDir = dirname($HbaseDir) . '/help';


$adminName = 'esils'; // 푸터와 관리자 표시용 이름입니다.


$email = 'loverofwind@naver.com'; // 푸터 표시용 관리자 이메일입니다.


$bbs = dirname($HbaseDir) . '/wforum.php';


$toppage = dirname($HbaseDir) . '/';



$HdirMode = 0755; // 데이터/백업 디렉터리 생성 권한입니다.








//----------------------------------------------------------------------
// 파일 잠금과 턴 진행 시간 설정
//----------------------------------------------------------------------
$lockMode = 2; // 파일 잠금 방식입니다.






$HunitTime = 1800;  // 기본 턴 간격(초)입니다.



$HflexTimeSet = 0; // 상세 턴 시간표 사용 여부입니다.


$HmaxIsland = 20; // 최대 섬 수입니다.


$HlimitTurn = 0;  // 턴 제한값입니다. 0이면 제한 없음입니다.


$HtopLogTurn = 12; // 탑 페이지 최근 로그 표시 수입니다.


$HlogMax = 12; // 보관 로그 파일 수입니다.


$HbackupTurn = 1; // 백업 생성 턴 간격입니다.


$HbackupTimes = 6; // 순환 백업 보관 개수입니다.


$HhistoryMax = 100; // 과거 사건 최대 보관 수입니다.


$HgiveupTurn = 100; // 섬 포기 관련 제한 턴입니다.


$HcommandMax = 50; // 섬별 명령 최대 개수입니다.


$HuseLbbs = 1; // 로컬게시판 사용 여부입니다.


$HlbbsMax = 15; // 로컬게시판 최대 글 수입니다.


$HlbbsAnon = 0; // 로컬게시판 익명 허용 여부입니다.


$HlbbsSpeaker = 1; // 로컬게시판 발언자 표시 방식입니다.


$Hroundmode = 1; // 라운드/시즌 모드 사용 여부입니다.


$Hatkturn = 15; // 공격 제한 기본 턴입니다.
$Hatkturn2 = 30; // 추가 공격 제한 턴입니다.


$Hdeadisland = 0; // 멸망 섬 처리 방식입니다.


$efileDir = "{$HbaseDir}"; // 설정/그래프 출력용 공개 경로입니다.

$HefileDir = '.'; // 설정/그래프 파일 저장 경로입니다.


$HdispAzukari = 0; // 보관/예치 표시 여부입니다.


$Hragnarok = 1; // 라그나로크 이벤트 사용 여부입니다.






//----------------------------------------------------------------------
// 진영/진영게시판/진영채팅 설정
//----------------------------------------------------------------------
$Hallyflg = 1; // 진영 기능 사용 여부입니다.


$Hautoally = 0; // 자동 진영 배정 여부입니다.


$Hallygroup = array("무소속","동맹군","연합군","제국군"); // 진영 이름 배열입니다.
$Hallymark = array("","＋","Й","Ψ"); // 진영 마크 배열입니다.

$HallyDisp = 1; // 진영 표시 여부입니다.



$Hcampbbs = 1; // 진영게시판 사용 여부입니다.


$HcampbbsPath = dirname($HbaseDir) . '/wforum.php';



$Hcampchat = 1; // 진영채팅 사용 여부입니다.


$HcampchatPath = dirname($HbaseDir) . '/chat.php';




$campPass = array("camp1","camp2","camp3","camp4"); // 진영별 비밀번호 배열입니다.







//----------------------------------------------------------------------
// 화면 스킨/CSS 설정
//----------------------------------------------------------------------
$HcssFile = 'qhw.css'; // 기본 CSS 파일명입니다.


$HskinNameList = array('구상표준', '구상표준(빨강계)', 'Hakoniwa R.A. 바람'); // 스킨 선택 표시명 배열입니다.
$HskinList = array('skin/khako.css','skin/khako2.css','skin/ra.css'); // 스킨 CSS 파일 배열입니다.
$HskinName = ''; // 현재 선택된 스킨명입니다.

?>
