<?php

/*
 * hako/lbbslist.php
 * ------------------------------------------------------------
 * 로컬게시판 목록 독립 출력 모듈
 *
 * 상세 주석 기준:
 * - 원본 대응: qwmp155.zip 의 lbbslist.cgi.
 * - 섬별 로컬게시판 데이터를 읽어서 독립 목록 화면으로 출력합니다.
 * - 게시글 저장 포맷은 island.* 내부 lbbs 배열과 연결되며 DB를 사용하지 않습니다.
 * - 원본 CGI 주석 라인 확인 수: 108줄. PHP 주석은 실행 결과를 바꾸지 않는 범위에서 복원/보강했습니다.
 *
 * 유지보수 원칙:
 * - 실행 로직, 저장 포맷, 배열 인덱스, 출력 HTML은 원본 CGI 호환성 대상입니다.
 * - 개조가 필요하면 먼저 해당 변수/함수가 어떤 파일 저장값과 연결되는지 확인하십시오.
 * - 이 주석은 유지보수용이며 실행 결과를 바꾸지 않습니다.
 */

chdir(dirname(__FILE__));
require_once dirname(__FILE__) . '/hako-compat.php';
if (function_exists('htmlEscape')) { $HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : ''); } else { $HdefaultPasswordEsc = isset($HdefaultPassword) ? $HdefaultPassword : ''; }












































$versionInfo = '';
$HcurrentID = '';
$HdefaultPassword = '';
$HdefaultName = '';
$h2 = '<H2>';
require_once './hako-init.php';
require_once './init-game.php';
require_once './hako-io.php';


$bye = "$HbaseDir/hako-main.php";


$kyoutyouturn = 20;





$title = '관광자 통신 일람';


$headKill = <<<HAKOHDOC_0
<h2 class=head2>모형정원 제도 관광자 통신 일람표</h2>
HAKOHDOC_0
;

$HbgTitleCell   = 'class=TitleCell';
$HbgLbbsCell    = 'class=LbbsCell';
$HbgCommentCell = 'class=CommentCell';


$HtagCo_ = '<span class="number">';
$H_tagCo = '</span>';


$HtagLbbsSS_ = '<span class="lbbsSS">';
$H_tagLbbsSS = '</span>';


$HtagLbbsOW_ = '<span class="lbbsOW">';
$H_tagLbbsOW = '</span>';


$HtagNumber_ = '<span class="number">';
$H_tagNumber = '</span>';



requestInput();
tempHeader(0);
out("<A HREF=\"$bye\">[돌아온다]</A></DIV>");

if (!(readIslandsFile())) {
	htmlError();
} else {
	out($headKill);
	out("<CENTER><TABLE BORDER><TR><TD>");
	unset($i); $i = null;
	for ($i = 0; $i < $HislandNumber; $i++) {
		tempLbbsContents($i);
	}
	out("</TR></TD></TABLE></CENTER>");

}
tempFooter();

exit(0);









/*
 * 함수: readIslandsFile()
 * 역할: 전체 섬 데이터와 공통 데이터 파일을 읽어 Hislands/각종 전역 배열로 복원합니다.
 * 원본 대응: hako/lbbslist.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function readIslandsFile() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	
	if (!hako_open('IN', "{$HdirName}/hakojima.dat")) {
		@rename("{$HdirName}/hakojima.tmp", "{$HdirName}/hakojima.dat");
		if (!hako_open('IN', "{$HdirName}/hakojima.dat")) {
			return 0;
		}
	}
	
	$HislandTurn = intval(hako_getline('IN')); 
	hako_getline('IN');
	$HislandNumber = intval(hako_getline('IN')); 
	hako_getline('IN');hako_getline('IN');hako_getline('IN');hako_getline('IN');hako_getline('IN');hako_getline('IN');hako_getline('IN');hako_getline('IN');

	
	unset($i); $i = null;
	for ($i = 0; $i < $HislandSize; $i++) {
		hako_getline('IN');
	}
	
	for ($i = 0; $i < $HislandNumber; $i++) {
		$Hislands[$i] = readIsland();
		$HidToNumber[$Hislands[$i]['id']] = $i;
	}

	
	hako_close('IN');
	return 1;
}







/*
 * 함수: readIsland()
 * 역할: 개별 island.ID 파일을 읽어 한 섬의 상세 데이터, 명령, 로컬게시판, 부대 정보를 복원합니다.
 * 원본 대응: hako/lbbslist.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function readIsland() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	unset($id); $id = null;
	unset($name); $name = null;
	unset($comment); $comment = null;
	unset($i); $i = null;
	unset($line); $line = null;
	unset($lbbs); $lbbs = array();
	unset($password); $password = null;
	unset($afnameId); $afnameId = null;
	$name = hako_getline('IN');
	hako_regex('~(.*),(.*)~', $name);
	$name = hako_m(1);
	$id = intval(hako_getline('IN')); 
	hako_getline('IN'); 
	hako_getline('IN'); 
	hako_getline('IN'); 
	$comment = hako_getline('IN');
	hako_chomp($comment);
	$password = hako_getline('IN');
	hako_chomp($password);
	
	for ($_ = 8; $_ <= 30; $_++) {
		if ($_ == 27) {
			$afnameId = intval(hako_getline('IN'));
		} else{
			hako_getline('IN');
		}
	}
	
	$name .= $Haftername[$afnameId];
	if (!hako_open('IIN', "{$HdirName}/island.$id")) {
		@rename("{$HdirName}/islandtmp.$id", "{$HdirName}/island.$id");
		if (!hako_open('IIN', "{$HdirName}/island.$id")) { exit(0); }
	}
	for ($i = 0; $i < $HcommandMax; $i++) {
		$line = hako_getline('IIN');
	}
	
	for ($i = 0; $i < $HlbbsMax; $i++) {
		$line = hako_getline('IIN');
		hako_chomp($line);
		$lbbs[$i] = $line;
	}
	hako_close('IIN');

		return array('name'=>$name, 'id'=>$id, 'comment'=>$comment, 'password'=>$password, 'lbbs'=>$lbbs);
}




/*
 * 함수: requestInput()
 * 역할: GET/POST 입력값을 원본 CGI의 cgiInput 역할에 맞춰 전역 변수로 정리합니다.
 * 원본 대응: hako/lbbslist.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function requestInput() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	unset($line); $line = null;
	unset($getLine); $getLine = null;

	
	if (file_exists("./mente_lock")) { return; }

	
	$line = file_get_contents("php://input");
	$line = strtr($line, '+', ' ');
	$line = rawurldecode(str_replace("+", " ", $line));
	hako_subst($line, '~[\\,\\r]~', '');

	
	$getLine = hako_get_env('QUERY_STRING');

	if (hako_regex('~id=([^\&]*)~', $getLine)) {
		$HcurrentID = hako_m(1);
	}
	$_list_tmp = array(hako_get_env('HTTP_COOKIE'));
	unset($cookie); $cookie = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
	if ($HcurrentID == 99) {
		
		if (hako_regex(hako_cookie_pattern('OWNISLANDID'), $cookie)) { $HcurrentID = hako_m(1); }
	}
	if (hako_regex(hako_cookie_pattern('SKIN'), $cookie)) { $HskinName = hako_m(1); }
	if (hako_regex(hako_cookie_pattern('OWNISLANDPASSWORD'), $cookie)) { $HdefaultPassword = hako_m(1); }
	if (hako_regex(hako_cookie_pattern('LBBSNAME'), $cookie)) { $HdefaultName = hako_m(1); }
	if (hako_regex('~pass=([^\&]*)~', $getLine)) {
		$HdefaultPassword = hako_m(1);
	}
	$HdecodePassword = crypt($HdefaultPassword, 'ma');
	if (file_exists($HpasswordFile)) {
		
		hako_open('PIN', "<$HpasswordFile");
		$HmasterPassword = hako_getline('PIN'); hako_chomp($HmasterPassword);
		hako_close('PIN');
	}
}






/*
 * 함수: htmlError()
 * 역할: 독립 로컬게시판 오류 화면을 출력합니다.
 * 원본 대응: hako/lbbslist.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function htmlError() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	out("{$h2}에러가 발생했던</H2>\n");
}






/*
 * 함수: tempLbbsContents()
 * 역할: 로컬게시판 목록 HTML을 출력합니다.
 * 원본 대응: hako/lbbslist.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function tempLbbsContents() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	unset($number); $number = isset($_args[0]) ? $_args[0] : null;
	$HislandList = getIslandList($HcurrentID);
	unset($island); $island = null;
	unset($id); $id = null;
	unset($password); $password = null;
	unset($name); $name = null;
	unset($link); $link = null;
	unset($lbbs); $lbbs = null;
	unset($comment); $comment = null;
	unset($line); $line = null;
	$island =& $Hislands[$number];
	$name = $island['name'] . $AfterName;
	$link = "Sight=" . $island['id'];
	$comment = $island['comment'];
	$id = $island['id'];
	$lbbs = $island['lbbs'];
	if ($comment == '') { $comment = "　"; }
	$owner = 0;
	if ($HdecodePassword == $HmasterPassword) {
		
		out("<TR><TD colspan=2>관리인 모드</TD></TR>");
		$owner = 1;
	}
		$password = (isset($HidToNumber[$HcurrentID]) && isset($Hislands[$HidToNumber[$HcurrentID]]['password'])) ? $Hislands[$HidToNumber[$HcurrentID]]['password'] : '';
	if ($password == crypt($HdefaultPassword,'h2')) {
		
		$HspeakerID = $HcurrentID;
	}
	out(<<<HAKOHDOC_1
<TR><TD $HbgTitleCell><a name=$id><b>국명</b></a></TD>
<TD $HbgLbbsCell>
<A HREF="$HthisFile?{$link}" TARGET=_blank>
<b>$name</b></A>
</TD></TR>
<TR><TD $HbgTitleCell><b>코멘트</b></TD>
<TD $HbgLbbsCell>{$HtagCo_}{$comment}{$H_tagCo}
</TD></TR>
HAKOHDOC_1
);
	if ($owner || $HcurrentID) { out(<<<HAKOHDOC_2
<TR>
<TD $HbgTitleCell><b>투고</b></TD>
<TD $HbgTitleCell>
<FORM action="$HthisFile" method="POST">
이름:<INPUT TYPE="text" SIZE=12 MAXLENGTH=32 NAME="LBBSNAME" VALUE="$HdefaultName">
<SELECT NAME="ISLANDID2">$HislandList</SELECT>
내용:<INPUT TYPE="text" SIZE=50 NAME="LBBSMESSAGE">
<INPUT TYPE="hidden" NAME="LBBSLIST" VALUE="lbbslist">
패스:<INPUT TYPE="password" SIZE=4 MAXLENGTH=16 NAME=PASSWORD VALUE="{$HdefaultPasswordEsc}">
<INPUT TYPE="radio" NAME="LBBSTYPE" VALUE="PUBLIC" CHECKED>공개
<INPUT TYPE="radio" NAME="LBBSTYPE" VALUE="SECRET"><span class='lbbsST'>극비</span>
<INPUT TYPE="submit" VALUE="적는다" NAME="LbbsButtonSS$id">
</TD>
</TR>
</FORM>
HAKOHDOC_2
); }
	unset($i); $i = null;
	for ($i = 0; $i < $HlbbsMax; $i++) {
		$line = $lbbs[$i];
		if (hako_regex('~([0-9]*)\<(.*)\<([0-9]*)\>(.*)\>(.*)$~', $line)) {
			$j = $i + 1;
			out("<TR><TD $HbgSubTCell align=center>$HtagNumber_$j$H_tagNumber</TD>");
			unset($speaker); $speaker = null;
			unset($CellColor); $CellColor = null;
			$_list_tmp = array(hako_m(1),hako_m(2),hako_m(3),hako_m(4),hako_m(5));
			unset($bbs1); $bbs1 = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
			unset($bbs2); $bbs2 = isset($_list_tmp[1]) ? $_list_tmp[1] : null;
			unset($bbs3); $bbs3 = isset($_list_tmp[2]) ? $_list_tmp[2] : null;
			unset($bbs4); $bbs4 = isset($_list_tmp[3]) ? $_list_tmp[3] : null;
			unset($bbs5); $bbs5 = isset($_list_tmp[4]) ? $_list_tmp[4] : null;
			hako_regex('~([0-9]*)~', $bbs4);
			if (hako_m(1) >= $HislandTurn - $kyoutyouturn) {
				$CellColor = $HbgCommentCell;
			} else {
				$CellColor = $HbgLbbsCell;
			}
			if ($bbs3 == 0) {
				$_list_tmp = explode(',', $bbs2);
				$sName = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
				unset($sID); $sID = isset($_list_tmp[1]) ? $_list_tmp[1] : null;
				$sNo = $HidToNumber[$sID];
				if ($sName != '') {
					if (isset($sNo)) {
						$speaker = "<span class='lbbsST'><B><SMALL>(<A HREF=\"{$HbaseDir}/hako-main.php?Sight=$sID\" class=\"M\">$sName</A>)</SMALL></B></span>";
					} else {
						$speaker = "<span class='lbbsST'><B><SMALL>($sName)</SMALL></B></span>";
					}
				}
				
				if ($bbs1 == 0) {
					
					out("<TD $CellColor>$HtagLbbsSS_$bbs4 > $bbs5$H_tagLbbsSS $speaker</TD></TR>");
				} else {
					
				
					if (($owner) || (($HspeakerID != '') && ($sID == $HspeakerID))) {
						
						out("<TD $CellColor>$HtagLbbsSS_$bbs4 >(비) $bbs5$H_tagLbbsSS $speaker</TD></TR>");
					} else {
						
						out("<TD $CellColor><CENTER><span class='lbbsST'>- 극비 -</span></CENTER></TD></TR>");
					}
				}
			} else {
				
				if ($bbs2 != '') { $speaker = "<span class='lbbsST'><B><SMALL>$bbs2</SMALL></B></span>"; }
				out("<TD $CellColor>$HtagLbbsOW_$bbs4 > $bbs5$H_tagLbbsOW $speaker</TD></TR>");
			}
		}
	}
	out(<<<HAKOHDOC_3
</TD></TR>
<TR></TR><TR></TR>
HAKOHDOC_3
);
}


?>
