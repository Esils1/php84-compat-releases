<?php

/*
 * hako/hako-turn.php
 * ------------------------------------------------------------
 * 턴 진행/명령 실행/전투/재해/로그 모듈
 *
 * 상세 주석 기준:
 * - 원본 대응: qwmp155.zip 의 hako-turn.cgi. 깨진 원본 주석은 qwhako154.zip 의 일본어 hako-turn.cgi 흐름을 참고했습니다.
 * - 한 턴마다 자원 수입, 명령 실행, 미사일/괴수/전쟁/우호 관계, 자연재해, 로그/통계/백업을 처리합니다.
 * - 원본 CGI의 미정의값 처리가 PHP 에서는 Warning/Fatal 로 드러나므로, 배열 기본값 보정은 원본 동작 보존 범위에서만 허용합니다.
 * - 전쟁/우호/부대/미사일 사거리 관련 배열은 참조 대입과 인덱스 의미가 중요하므로 임의 재정렬하지 마십시오.
 * - 장기 플레이 문제는 대부분 이 파일의 저장 누적, 로그 누적, 턴 반복 흐름에서 발생합니다.
 * - 원본 CGI 주석 라인 확인 수: 713줄. PHP 주석은 실행 결과를 바꾸지 않는 범위에서 복원/보강했습니다.
 *
 * 유지보수 원칙:
 * - 실행 로직, 저장 포맷, 배열 인덱스, 출력 HTML은 원본 CGI 호환성 대상입니다.
 * - 개조가 필요하면 먼저 해당 변수/함수가 어떤 파일 저장값과 연결되는지 확인하십시오.
 * - 이 주석은 유지보수용이며 실행 결과를 바꾸지 않습니다.
 */

chdir(dirname(__FILE__));
require_once dirname(__FILE__) . '/hako-compat.php';















$ForceFlgMove = array();

/*
 * 함수: turnMain()
 * 역할: 한 턴 진행 전체를 제어합니다. 로그 이동, 랜덤 좌표 준비, 외교 관계 정리, 섬별 수입/명령/재해/저장을 순서대로 수행합니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function turnMain() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $HislandLastTime, $HunitTime, $i, $j, $s, $d, $HlogMax, $HdirName, $HislandTurn, $HflexTimeSet, $HTurnCt, $HflexTime, $HislandNumber, $order, $Hislands, $HragnarokTurn, $HtagName_, $H_tagName, $island, $HamityIsland, $tn1, $HidToNumber, $tn2, $HwarIsland, $HthisFile;
    global $wname, $id, $tId, $Harea, $HdoCommand, $HlogOmit2, $cmdcount, $HflagCommand, $HcomTurn, $HfirstFlg, $remainNumber, $HdisFallBorder, $HdisMeteo, $HdisMeteo2, $HdisHugeMeteo, $HdisHugeMeteo2, $x, $y, $HislandSize, $Hland, $HlandMonster, $HlandDivPw, $tn, $HlandDivNa;
    global $ForceFlgMove, $HlandDivEx, $HlandDivItem, $level, $HlandDivLv, $HlandOwner, $HidToName, $sx, $sy, $OwnerCount, $count2, $ax, $ay, $Hroundmode, $correct, $oct, $a, $b, $HlandResist, $FoccupyFlg, $HlandDiv, $HlandValue, $HlandKeep, $HlandSea;
    global $HlandDefence, $tmpid, $Hdeadisland, $HislandNFlg, $HturnPrizeUnit, $Hprize, $tIsland, $FItemName, $idx, $HlimitTurn, $HbackupTurn, $tmp, $HbackupTimes, $HdirMode, $Hallyflg, $ctarea, $allyCount, $allyPop, $allySol, $allyArea, $allyGnp, $ally, $_, $w;
$_args = func_get_args();
	
	hako_prepare_long_turn();

	/*
	 * PHP 5.5 파일 저장 환경 보정:
	 * 턴 처리 중 다른 브라우저/자동 새로고침이 동시에 들어오면 같은 데이터 파일을
	 * 중복 처리하면서 로딩이 길어질 수 있으므로 비차단 lock을 둡니다.
	 * 이미 턴 처리 중이면 현재 화면만 출력하고 빠져나옵니다.
	 */
	$__hako_turn_lock_fp = null;
	if (isset($HdirName) && $HdirName !== '') {
		$__hako_turn_lock_fp = @fopen($HdirName . '/turn.lock', 'c');
		if ($__hako_turn_lock_fp) {
			if (!@flock($__hako_turn_lock_fp, LOCK_EX | LOCK_NB)) {
				@fclose($__hako_turn_lock_fp);
				if (function_exists('topPageMain')) { topPageMain(); }
				return;
			}
			register_shutdown_function(function() { global $__hako_turn_lock_fp; if ($__hako_turn_lock_fp) { @flock($__hako_turn_lock_fp, LOCK_UN); @fclose($__hako_turn_lock_fp); } });
		}
	}

	$HislandLastTime += $HunitTime;

	
	unset($i); $i = null;
	unset($j); $j = null;
	unset($s); $s = null;
	unset($d); $d = null;
	for ($i = ($HlogMax - 1); $i >= 0; $i--) {
		$j = $i + 1;
		$s = "{$HdirName}/hakojima.log$i";
		$d = "{$HdirName}/hakojima.log$j";
		@unlink($d);
		@rename($s, $d);
	}

	
	makeRandomPointArray();

	
	$HislandTurn++;
	if ($HflexTimeSet) {
		if ($HTurnCt >= hako_last_index($HflexTime)) {
			$HTurnCt = 0;
		} else{
			$HTurnCt++;
		}
	}

	
	$_list_tmp = randomArray($HislandNumber);
	unset($order); $order = array_slice($_list_tmp,0);

	for ($i = 0; $i < $HislandNumber; $i++) {
		if (!isset($Hislands[$i]['YU']) || !is_array($Hislands[$i]['YU'])) { $Hislands[$i]['YU'] = array(); }
		foreach (array('warA','warD','warP','warC','propaganda','bigmissile','hohei','heitan','seichi','jigyo','soldier2') as $__k) {
			if (!isset($Hislands[$i][$__k])) { $Hislands[$i][$__k] = 0; }
		}
	}

	
	
	
	
	
	
	
	if (($HragnarokTurn > 0) && ($HragnarokTurn == $HislandTurn)) {
		
		logHistory("{$HtagName_}라그나로크{$H_tagName}가 방문했습니다.");
		for ($i = 0; $i < $HislandNumber; $i++) {
			$island =& $Hislands[$order[$i]];
			$island['food'] += 10000;
			$island['soldier'] += $island['soldierF'];
			$island['soldierF'] = 0;
		}
	} else{
		for ($i=0;$i < hako_last_index($HamityIsland);$i+=4) {
			$tn1 = $HidToNumber[$HamityIsland[$i+1]];
			if (($tn1 === '' || $tn1 === null)) {
				hako_splice($HamityIsland, $i, 4);
				$i-=4;
				continue;
			}
			$tn2 = $HidToNumber[$HamityIsland[$i+2]];
			if ((($tn2 === '' || $tn2 === null)) || (chkWarIsland($HamityIsland[$i+1], $HamityIsland[$i+2]) > 0)) {
				
				hako_splice($HamityIsland, $i, 4);
				$i-=4;
				continue;
			}

			if ($HamityIsland[$i] < $HislandTurn) {
				if ($HamityIsland[$i+3] > 0) { logAmityEnd($HamityIsland[$i+1], $Hislands[$tn1]['name'], $HamityIsland[$i+2], $Hislands[$tn2]['name'], "기한 마감에"); }
				hako_splice($HamityIsland, $i, 4);
				$i-=4;
			} else{
				if ($HislandNumber <= 2) {
					
					logAmityEnd($HamityIsland[$i+1], $Hislands[$tn1]['name'], $HamityIsland[$i+2], $Hislands[$tn2]['name'], "나머지 2개국이기 때문에,");
					hako_splice($HamityIsland, $i, 4);
					$i-=4;
				} else{
					$Hislands[$tn1]['YU'][$HamityIsland[$i+2]] = $HamityIsland[$i+3] + 2;
					$Hislands[$tn2]['YU'][$HamityIsland[$i+1]] = $HamityIsland[$i+3] + 1;
				}
			}
		}
	}

	
	unset($i); $i = null;
	for ($i=0;$i < hako_last_index($HwarIsland);$i+=4) {
		$tn1 = $HidToNumber[$HwarIsland[$i+1]];
		$tn2 = $HidToNumber[$HwarIsland[$i+2]];
		if ((($tn1 === '' || $tn1 === null)) || (($tn2 === '' || $tn2 === null))) { continue; }
		if ($HwarIsland[$i+3] == 1) {
			$Hislands[$tn1]['warD']++;
			$Hislands[$tn1]['warP'] += $Hislands[$tn2]['score'];
			$Hislands[$tn2]['warA']++;
		} else{
			$Hislands[$tn1]['warA']++;
			$Hislands[$tn2]['warD']++;
			$Hislands[$tn2]['warP'] += $Hislands[$tn1]['score'];
		}
		if ($HwarIsland[$i] <= $HislandTurn) {
			
			$Hislands[$tn1]['warC']++;
			$Hislands[$tn2]['warC']++;
		}
		if ($HwarIsland[$i] != $HislandTurn) { continue; }
	
		$wname = $Hislands[$tn1]['name'] . " VS " . $Hislands[$tn2]['name'];
		logOut("{$HtagName_}{$wname}{$H_tagName}전쟁 발발!",$id, $tId);
		logHistory("{$HtagName_}{$wname}{$H_tagName}전쟁 발발!");
	}

	
	$Harea = 0;
	for ($i = 0; $i < $HislandNumber; $i++) {
		if ($Hislands[$order[$i]]['warD'] < 2) { $Hislands[$order[$i]]['warP'] = 0; }
		estimate($Hislands[$order[$i]],1);
		income($Hislands[$order[$i]]);
		$Harea += $Hislands[$order[$i]]['area'];
	}

	
	$HdoCommand = 1;
	$HlogOmit2 = 1;
	for ($i = 0; $i < $HislandNumber; $i++) {
		$island =& $Hislands[$order[$i]];
		if ($island['predelete']) { continue; }
		for ($cmdcount = 0; $cmdcount < $HdoCommand; $cmdcount++) {
		
			$HflagCommand = 0;
			$__hako_command_guard = 0;
			$__hako_command_guard_limit = isset($HcommandMax) ? intval($HcommandMax) + 5 : 105;
			while (!$HflagCommand) {
				$__hako_command_guard++;
				if ($__hako_command_guard > $__hako_command_guard_limit) {
					/* 실패/0턴 명령이 계속 반복되는 경우 화면 흰화면을 막기 위한 최소 안전장치 */
					$HflagCommand = 1;
					break;
				}
				if ($island['custom'] & 4) {
					$HflagCommand += isset($HcomTurn[$island['command'][0]['kind']]) ? $HcomTurn[$island['command'][0]['kind']] : 1;
					doCommand($island);
				} else {
					$HflagCommand += doCommand($island);
				}
			}
		}
		
		if ($HlogOmit2) { logMatome($island, $HlogOmit2, 'seichi'); }
	}

	
	$HfirstFlg = 1; 
	for ($i = 0; $i < $HislandNumber; $i++) {
		if ($Hislands[$order[$i]]['predelete']) { continue; }
		doEachHex($Hislands[$order[$i]]);
		$HfirstFlg = 0;
	}

	
	doEachHex2();

	
	$remainNumber = $HislandNumber;
	
	unset($island); $island = null;
	for ($i = 0; $i < $HislandNumber; $i++) {
		$island =& $Hislands[$order[$i]];
		doIslandProcess($island);
	}

	
	if ($Harea > $HdisFallBorder) {
		$HdisMeteo = $HdisMeteo2;
		$HdisHugeMeteo = $HdisHugeMeteo2;
	}
	
	doIslandProcess2();

	unset($x); $x = null;
	unset($y); $y = null;
	
	for ($y = 0; $y < $HislandSize; $y++) {
		for ($x = 0; $x < $HislandSize; $x++) {
			if ($Hland[$x][$y] == $HlandMonster) {
				
				continue;
			}
			
			if ($HlandDivPw[$x][$y] > 0) {
				$tn = $HidToNumber[$HlandDivNa[$x][$y]];
				if (($tn === '' || $tn === null)) {
				} else{
					unset($island); $island =& $Hislands[$tn];
					if ($ForceFlgMove[$x][$y] == 98 || $ForceFlgMove[$x][$y] == 99) {
						
						if ($ForceFlgMove[$x][$y] == 98) { unset($s); $s = "(초토)"; }
						if ($HlandDivPw[$x][$y] + $island['soldier'] > 0) {
							$HlandDivEx[$x][$y] += 5;
							$island['soldierex'] = $HlandDivEx[$x][$y] = intval((($HlandDivPw[$x][$y] * $HlandDivEx[$x][$y]) + ($island['soldier'] * $island['soldierex'])) / ($HlandDivPw[$x][$y] + $island['soldier']));
						}
						$island['soldier'] += $HlandDivPw[$x][$y];
						if ($HlandDivItem[$x][$y] > 0) {
							
							$island['item'][$HlandDivItem[$x][$y]]++;
						}
						$level = intval($HlandDivLv[$x][$y] / 2);
						$island['item'][7] += $level;
						logLandSuc($HlandDivNa[$x][$y], $HlandOwner[$x][$y], $island['name'], $HidToName[$HlandOwner[$x][$y]], "취소", "($x, $y)");
						
						$HlandDivPw[$x][$y] = 0;
						$ForceFlgMove[$x][$y] = 0;
					} elseif (random(2) == 0) {
						$HlandDivEx[$x][$y]++;
					}
					if ($HlandDivEx[$x][$y] > 100) {
						
						logSoldierLvUp($HlandDivNa[$x][$y], $island['name'], "($x, $y)");
						if ($HlandDivLv[$x][$y] < 15) { $HlandDivLv[$x][$y]++; }
						$HlandDivEx[$x][$y] = $HlandDivEx[$x][$y] - 100;
					}
				}
			}
			unset($i); $i = null;
			unset($sx); $sx = null;
			unset($sy); $sy = null;
			unset($OwnerCount); $OwnerCount = array();
			unset($count2); $count2 = 0;
			for ($i = 1; $i < 7; $i++) {
				$sx = $x + $ax[$i];
				$sy = $y + $ay[$i];
				if (!($sy % 2) && ($y % 2)) { $sx--; }
				if ($Hroundmode) {
					$sx = $correct[$sx + 12];
					$sy = $correct[$sy + 12];
				}
				
				if (($sx < 0) || ($sx >= $HislandSize) || ($sy < 0) || ($sy >= $HislandSize)) { continue; }
				$__owner2 = isset($HlandOwner[$sx][$sy]) ? $HlandOwner[$sx][$sy] : 0;
				if (!isset($OwnerCount[$__owner2])) { $OwnerCount[$__owner2] = 0; }
				$OwnerCount[$__owner2]++;
				$__owner1 = isset($HlandOwner[$x][$y]) ? $HlandOwner[$x][$y] : 0;
				if ($__owner1 != $__owner2) { $count2++; }
			}
			$oct = array_keys($OwnerCount); usort($oct, function($a, $b) use ($OwnerCount) { return hako_cmp($OwnerCount[$b], $OwnerCount[$a]); });
			$__oct0 = isset($oct[0]) ? $oct[0] : 0;
				if (($__oct0 > 0) && ($count2 > 4) && ($HlandOwner[$x][$y] != $__oct0)) {
				if (($HlandDivPw[$x][$y] > 0) && ($HlandDivNa[$x][$y] > 0) && ($HlandDivNa[$x][$y] == $HlandOwner[$x][$y])) {
					
				} else{
					if ($count2 > 5) {
						$HlandResist[$x][$y] -= 3;
					} else{
						$HlandResist[$x][$y] -= 1;
					}
					if ($HlandResist[$x][$y] < 1) {
						$id = $HlandOwner[$x][$y];
						$tId = $oct[0];
						$tn = $HidToNumber[$id];
						$island =& $Hislands[$tn];
						if ((($tn !== '' && $tn !== null)) && ($island['YU'][$tId] > 2)) {
							
							$HlandResist[$x][$y] = 1;
						} elseif (($HlandDivPw[$x][$y] > 0) && ($FoccupyFlg[$HlandDiv[$x][$y]])) {
							
							$HlandResist[$x][$y] = 1;
						} else{
							
							$HlandResist[$x][$y] = 2;
							logLandOccupy($id, $tId, $HidToName[$id], $HidToName[$tId], $x, $y, landName($Hland[$x][$y], $HlandValue[$x][$y]));
							$HlandOwner[$x][$y] = $__oct0;
							$HlandKeep[$x][$y] = 0;
						}
					}
				}
			} else{
				if ($HlandResist[$x][$y] < 10) { $HlandResist[$x][$y]++; }
			}
			if ($HlandResist[$x][$y] < 1) {
				$HlandResist[$x][$y] = 2;
				$id = $HlandOwner[$x][$y];
				logLandGiveup($id, $HidToName[$id], "($x, $y)", landName($Hland[$x][$y], $HlandValue[$x][$y]));
				$HlandOwner[$x][$y] = 0;
				$HlandKeep[$x][$y] = 0;
			}
			if ($Hland[$x][$y] == $HlandSea) {
				if (countAround($x, $y, $HlandSea, 7) == 7) {
					
					$HlandValue[$x][$y] = 0;
					$HlandOwner[$x][$y] = 0;
					$HlandKeep[$x][$y] = 0;
				}
				continue;
			}
		}
	}

	
	for ($y = 0; $y < $HislandSize; $y++) {
		for ($x = 0; $x < $HislandSize; $x++) {
			if ($HlandKeep[$x][$y] < 15) { $HlandKeep[$x][$y]++; }
			if ($Hland[$x][$y] == $HlandDefence && $HlandValue[$x][$y] == 1) {
				$HlandValue[$x][$y] = 2;
			} elseif ($Hland[$x][$y] == $HlandDefence && $HlandValue[$x][$y] == 2) {
				
				logBombFire($HlandOwner[$x][$y], $HidToName[$HlandOwner[$x][$y]], landName($Hland[$x][$y], $HlandValue[$x][$y]), "($x, $y)");
				
				wideDamage($HlandOwner[$x][$y], $HidToName[$HlandOwner[$x][$y]], $x, $y, 1);
			} elseif ($Hland[$x][$y] == $HlandSea) {
				
				$HlandOwner[$x][$y] = 0;
				$HlandResist[$x][$y] = 10;
				continue;
			}
		}
	}

	
	for ($i = 0; $i < $HislandNumber; $i++) {
		$island =& $Hislands[$order[$i]];
		doIslandProcess3($island);
		
		if (!isset($island['dead'])) { $island['dead'] = 0; }
		if ($island['dead'] == 1) {
			unset($HidToNumber[$island['id']]);
			$island['pop'] = 0;
			$island['popsol'] = 0;
			$remainNumber--;
		} elseif ($island['pop'] == 0) {
			unset($HidToNumber[$island['id']]);
			$island['dead'] = 1;
			$island['popsol'] = 0;
			$remainNumber--;
			
			$tmpid = $island['id'];
			logDead($tmpid, $island['name']);
			@unlink("island.$tmpid");
		}
	}

	
	unset($tId); $tId = null;
	for ($y = 0; $y < $HislandSize; $y++) {
		for ($x = 0; $x < $HislandSize; $x++) {
			$tId = $HlandOwner[$x][$y];
			/* PHP 5.5 loose comparison warning: HidToNumber의 첫 섬 인덱스 0은 빈 문자열과 느슨하게 비교하면 true가 됩니다. */
			if (($tId != 0) && (!isset($HidToNumber[$tId]))) {
				$tn = $HidToNumber[$HlandDivNa[$x][$y]];
				if (($tn === '' || $tn === null)) { $HlandDivPw[$x][$y] = 0; }
				if ((!$Hdeadisland) && ($HlandDivPw[$x][$y] < 50)) {
					
					$Hland[$x][$y] = $HlandSea;
					$HlandValue[$x][$y] = 1;
					
					if ($HlandDivPw[$x][$y] > 0) {
						if (($tn !== '' && $tn !== null)) {
							unset($island); $island =& $Hislands[$tn];
							$island['soldier'] += $HlandDivPw[$x][$y];
							if ($HlandDivItem[$x][$y] > 0) { $island['item'][$HlandDivItem[$x][$y]]++; }
							logLandSuc($HlandDivNa[$x][$y], $HlandOwner[$x][$y], $island['name'], $HidToName[$HlandOwner[$x][$y]], "긴급 이탈", "($x, $y)");
						}
						$HlandDivPw[$x][$y] = 0;
					}
				}
				$HlandOwner[$x][$y] = 0;
				continue;
			}
		}
	}

	
	$HislandNFlg = 0;

	
	islandSort();

	
	if (($HislandTurn % $HturnPrizeUnit) == 0) {
		$island =& $Hislands[0];
		logPrize($island['id'], $island['name'], "$HislandTurn{$Hprize[0]}");
		$island['prize'] .= "{$HislandTurn},";

		
		
		unset($tIsland); $tIsland =& $Hislands[$remainNumber - 1];
		$tIsland['item'][1]++;
		$tIsland['item'][2]++;
		logPrizeV($tIsland['id'], $tIsland['name'], "$FItemName[1]으로 $FItemName[2]");
		
		unset($idx); $idx = hako_sort_indices_desc_path($Hislands, array('statistical2',1));
		unset($tIsland); $tIsland =& $Hislands[$idx[0]];
		if ($tIsland['statistical2'][1] > 0) {
			
			$tIsland['item'][1]++;
			logPrizeV($tIsland['id'], $tIsland['name'], $FItemName[1]);
		}
		
		unset($idx); $idx = hako_sort_indices_desc_path($Hislands, array('statistical2',2));
		unset($tIsland); $tIsland =& $Hislands[$idx[0]];
		if ($tIsland['statistical2'][2] > 0) {
			
			$tIsland['item'][2]++;
			logPrizeV($tIsland['id'], $tIsland['name'], $FItemName[2]);
		}
		
		unset($idx); $idx = hako_sort_indices_desc_path($Hislands, array('soldierF'));
		unset($tIsland); $tIsland =& $Hislands[$idx[0]];
		if ($tIsland['soldierF'] > 0) {
			
			$tIsland['item'][3]++;
			logPrizeV($tIsland['id'], $tIsland['name'], $FItemName[3]);
		}
		
		unset($idx); $idx = hako_sort_indices_desc_path($Hislands, array('statistical2',3));
		unset($tIsland); $tIsland =& $Hislands[$idx[0]];
		if ($tIsland['statistical2'][3] > 0) {
			
			$tIsland['item'][4]++;
			logPrizeV($tIsland['id'], $tIsland['name'], $FItemName[4]);
		}
		
		unset($idx); $idx = hako_sort_indices_desc_path($Hislands, array('statistical2',4));
		unset($tIsland); $tIsland =& $Hislands[$idx[0]];
		if ($tIsland['statistical2'][4] > 0) {
			
			$tIsland['item'][5]++;
			logPrizeV($tIsland['id'], $tIsland['name'], $FItemName[5]);
		}
		








		








		
		unset($idx); $idx = hako_sort_indices_desc_path($Hislands, array('statistical2',0));
		unset($tIsland); $tIsland =& $Hislands[$idx[0]];
		if ($tIsland['statistical2'][0] > 0) {
			
			$tIsland['item'][6]++;
			logPrizeV($tIsland['id'], $tIsland['name'], $FItemName[6]);
		}
	}

	
	$HislandNumber = $remainNumber;

	
	if ($HislandNumber == 1) {
		logHistory("게임 종료{$HtagName_}{$Hislands[0]['name']}{$H_tagName}가<B>세계 제패</B>의 위업을 완수한다!");
	} elseif ($HislandTurn == $HlimitTurn) {
		logHistory("게임 종료{$HtagName_}{$Hislands[0]['name']}{$H_tagName}가<B>세계 최대</B>의 위업을 완수한다!");
	}

	
	if (($HislandTurn % $HbackupTurn) == 0) {
		/*
		 * PHP 5.5 공유호스팅 보정:
		 * 원본 CGI는 live data 디렉터리를 data.bak0으로 rename한 뒤 data를 새로 만듭니다.
		 * 이 과정은 일부 웹호스팅에서 턴 처리 중 data 경로가 사라지거나 rename/mkdir 실패로 빈 화면을 만들 수 있습니다.
		 * 백업 목적은 유지하되, live data는 그대로 두고 data.bak0으로 복사합니다.
		 */
		hako_safe_backup_dir($HdirName, $HbackupTimes, $HdirMode);
	}

	
	logPop('pop');
	logPop('sol');
	logPop('area');
	logPop('power',1);

	
	if ($Hallyflg) {
		unset($ctarea); $ctarea = null;
		unset($allyCount); $allyCount = array();
		unset($allyPop); $allyPop = array();
		unset($allySol); $allySol = array();
		unset($allyArea); $allyArea = array();
		unset($allyGnp); $allyGnp = array();
		$ctarea = 0;
		for ($i = 0; $i < $HislandNumber; $i++) {
			$island =& $Hislands[$i];
			$ally = isset($island['ally']) ? $island['ally'] : 0;
			foreach (array('allyCount','allyPop','allySol','allyArea','allyGnp') as $__ak) { if (!isset(${$__ak}[$ally])) { ${$__ak}[$ally] = 0; } }
			$allyCount[$ally]++;
			$allyPop[$ally] += isset($island['pop']) ? intval($island['pop']) : 0;
			$allySol[$ally] += isset($island['sol']) ? intval($island['sol']) : 0;
			$allyArea[$ally] += isset($island['area']) ? intval($island['area']) : 0;
			$ctarea += isset($island['area']) ? intval($island['area']) : 0;
			$allyGnp[$ally] += (isset($island['money']) ? intval($island['money']) : 0) + intval((isset($island['food']) ? intval($island['food']) : 0) / 10);
		}
		$__allyKeys = array_keys($allyPop); usort($__allyKeys, function($a, $b) use ($allyPop) { return hako_cmp($allyPop[$b], $allyPop[$a]); });
			foreach ($__allyKeys as $_) {
			if ($allyPop[$_] > 0) {
				unset($w); $w = intval($allyArea[$_] * 10000 / $ctarea + 0.5) / 100;
				hako_open('AOUT', ">>{$HdirName}/ally.log");
				
				hako_write('AOUT', "$HislandTurn,$_,$allyCount[$_],$allyPop[$_],$allySol[$_],$allyArea[$_],$allyGnp[$_],$w\n");
				hako_close('AOUT');
			}
		}
	}

	
	writeIslandsFile(-1);

	
	logHistoryTrim();

	
	logFlush();

	
	logPrintHtml();

		topPageMain();
}


/*
 * 함수: myrmtree()
 * 역할: 백업/임시 디렉터리 삭제용 재귀 삭제 함수입니다. 없는 디렉터리에서도 화면 경고를 내면 안 됩니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function myrmtree() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $dn, $fileName;
$_args = func_get_args();
	unset($dn); $dn = isset($_args[0]) ? $_args[0] : null;
	if (!is_dir("$dn/")) { return; }
	$__dir_DIN = opendir("$dn/");
	if (!$__dir_DIN) { return; }
	unset($fileName); $fileName = null;
	while (($fileName = readdir($__dir_DIN)) !== false) {
		@unlink("$dn/$fileName");
	}
	if (isset($__dir_DIN) && $__dir_DIN) { closedir($__dir_DIN); }
	rmdir($dn);
}


unset($popsol); $popsol = 0; 
unset($popsolID); $popsolID = null;
/*
 * 함수: income()
 * 역할: 섬별 인구/농장/공장/채굴장/병력 기준 수입과 소비를 계산합니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function income(&$island) {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $HpreDeleteID, $_, $id, $pop, $pop2, $farm, $factory, $mountain, $HislandTurn, $Hnoarmy, $HeatenFood, $popsol, $popsolID, $command, $command2, $HcomPrepare2, $HcomDraft, $i, $sx, $sy, $HpointNumber, $Hrpx, $Hrpy, $HlandOwner;
    global $Hland, $HlandWaste, $HlandTown, $HlandValue;
$_args = func_get_args();
	$island['oldmoney'] = $island['money'];
	$island['oldfood'] = $island['food'];
	$island['oldSoldier'] = $island['sol'];
	$island['oldPop'] = $island['pop'];

	
	foreach ($HpreDeleteID as $_) {
		$island['YU'][$_] = 3;
	}

	$_list_tmp = array($island['id'], $island['pop'], $island['pop'], $island['farm'] * 10, $island['factory'], $island['mountain']);
	unset($id); $id = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
	unset($pop); $pop = isset($_list_tmp[1]) ? $_list_tmp[1] : null;
	unset($pop2); $pop2 = isset($_list_tmp[2]) ? $_list_tmp[2] : null;
	unset($farm); $farm = isset($_list_tmp[3]) ? $_list_tmp[3] : null;
	unset($factory); $factory = isset($_list_tmp[4]) ? $_list_tmp[4] : null;
	unset($mountain); $mountain = isset($_list_tmp[5]) ? $_list_tmp[5] : null;

	if ($HislandTurn <= 2) {
		$island['kaisi'] = 1;
	}

	if ($island['predelete']) {
		
		$island['money'] += 20;
		return;
	}

	if ($island['warP'] > $island['score'] * 2) {
		
		$pop2 += $pop2;
	}

	
	if ($pop2 > $farm) {
		
		$island['food'] += $farm; 
	
		$island['money'] += min(intval(($pop2 - $farm) / 10),$factory + $mountain);
	} else{
		
		$island['food'] += $pop2; 
	}

	
	if ($Hnoarmy) {
		
		$pop += $island['sol'] + $island['soldierF'];
	}
	$island['food'] = intval(($island['food']) - ($pop * $HeatenFood));

	
	if ($popsol < $island['pop'] + $island['sol']) {
		$popsol = $island['pop'] + $island['sol'];
		$popsolID = $id;
	}

	
	$_list_tmp = array($island['command'][0],$island['command'][1]);
	unset($command); $command = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
	unset($command2); $command2 = isset($_list_tmp[1]) ? $_list_tmp[1] : null;
	if (($command['kind'] == $HcomPrepare2 || $command['kind'] == $HcomDraft) && ($command['arg'] == 22)) {
		unset($i); $i = null;
		unset($sx); $sx = null;
		unset($sy); $sy = null;
		slideFront($island['command'], 0); 

		if (($command['kind'] != $command2['kind']) && ($command2['kind'] == $HcomPrepare2 || $command2['kind'] == $HcomDraft) && ($command2['arg'] == 22)) {
			
			slideFront($island['command'], 0);
		}
		for ($i = 0; $i < $HpointNumber; $i++) {
			$sx = $Hrpx[$i];
			$sy = $Hrpy[$i];
			if ($HlandOwner[$sx][$sy] == $id) {
					if (($Hland[$sx][$sy] == $HlandWaste) &&
						(($command['kind'] == $HcomPrepare2) || ($command2['kind'] == $HcomPrepare2))) {
						slideBack($island['command'], 0, $HcomPrepare2, $id, $sx, $sy, 0);
					} elseif (($Hland[$sx][$sy] == $HlandTown) && ($HlandValue[$sx][$sy] >= 70) &&
						(($command['kind'] == $HcomDraft) || ($command2['kind'] == $HcomDraft))) {
						slideBack($island['command'], 0, $HcomDraft, $id, $sx, $sy, 0);
					}
			}
		}
		return 0;
	}
}



/*
 * 함수: doCommand()
 * 역할: 명령 배열의 현재 명령을 판정하고 비용/턴수/대상 지형에 맞춰 실행합니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function doCommand(&$island) {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $comArray, $command, $HcomPrepare2, $HcomDraft, $HflagCommand, $kind, $target, $x, $y, $arg, $HcomArea, $HlandOwner, $Hland, $HlandValue, $id, $name, $landKind, $lv, $tId, $tName, $HidToName, $cost, $HcomCost, $comName;
    global $HcomName, $point, $landName, $HlandBase, $HlandDefence, $HlandForest, $HcomSendMonster, $HcomMissileLD, $HislandTurn, $Hatkturn2, $HcomMoney, $HcomFood, $HcomSoldier, $HcomMissileNM, $HcomMissilePP, $HcomMissileDM, $HcomMissileHM, $HcomMissileBM, $Hatkturn, $HcomDoNothing, $p, $HgiveupTurn, $HcomGiveup, $HcomPrepare;
    global $HlandSea, $HlandSbase, $HlandMountain, $HlandMonster, $HlandDivPw, $HlandDivNa, $HlandPlains, $HlandTown, $HlandWaste, $HlogOmit2, $sno, $seichipnt, $HdisMaizo, $v, $HcomReclaim, $HareaBorder, $Harea, $HdisFallBorder, $HunitArea, $seaCount, $i, $sx, $sy, $ax;
    global $ay, $Hroundmode, $correct, $HislandSize, $HcomDestroy, $fmapmv, $FmapMove, $HlandDiv, $ForceFlgMove, $HmaxAidArea, $tn, $HidToNumber, $tIsland, $Hislands, $HlandKeep, $HlandResist, $HlandDivItem, $HcomInfantry, $HlandSupply, $HlandMonument, $Hfleet, $ofcorps, $Fnochange, $HlandHGr;
    global $a, $b, $HlandDivEx, $HcomWithdraw, $HcomUnitOrder, $ofdirection, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName, $HcomItem, $FItemName, $HlandDivLv, $HcomPlant, $HcomFarm, $HcomFactory, $HcomFarm2, $HcomFactory2, $HcomBase, $HcomMonument, $HcomMountain, $HcomSupply, $HcomDbase, $rtn;
    global $HcomTurn, $HlandFarm, $HlandFactory, $cmdcount, $count, $flg, $HmonumentNumber, $HcomSbase, $flag, $tOrgName, $tx, $ty, $err, $distance, $HmissileRange, $r, $boat, $bx, $by, $HpointNumber, $Hrpx, $Hrpy, $dx, $dy;
    global $rl, $baseLevel, $HmissileRangeS, $level, $tTarget, $tL, $tLv, $tLname, $tPoint, $defence, $HdefenceHex, $pw, $HmaxExpPoint, $mKind, $mName, $mHp, $special, $HmonsterSpecial, $HmonsterExp, $value, $HmonsterValue, $prize, $flags, $monsters;
    global $turns, $achive, $Hprize, $lName, $HmonsterBHP, $HmonsterDHP, $HcomAmity, $HcomDeWar, $HcomCeasefire, $HragnarokTurn, $HamityIsland, $tn1, $tn2, $wname, $HwarIsland, $HdeclareTurn, $HtagDisaster_, $H_tagDisaster, $HcomSell, $HunitFood, $HcomSoldier2, $HunitPop2, $str, $HmaxAidSoldier;
    global $HunitPop, $HmaxAidFood, $HmaxAidMoney, $HunitMoney, $HcomPropaganda;
$_args = func_get_args();

	unset($comArray); $comArray =& $island['command'];
	unset($command); $command = isset($comArray[0]) ? $comArray[0] : array('kind'=>$HcomDoNothing, 'target'=>0, 'x'=>0, 'y'=>0, 'arg'=>0); 
	if (($command['kind'] == $HcomPrepare2 || $command['kind'] == $HcomDraft) && ($command['arg'] == 22)) {
		$HflagCommand = 1;
		return 1;
	}

	slideFront($comArray, 0); 

	
	if ((($command['kind'] >= 31) && ($command['kind'] <= 37)) && ($island['Afmissile'] == 1)) {
		
		return 0;
	}

	
	$_list_tmp = array($command['kind'],$command['target'],$command['x'],$command['y'],$command['arg']);
	unset($kind); $kind = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
	unset($target); $target = isset($_list_tmp[1]) ? $_list_tmp[1] : null;
	unset($x); $x = isset($_list_tmp[2]) ? $_list_tmp[2] : null;
	unset($y); $y = isset($_list_tmp[3]) ? $_list_tmp[3] : null;
	unset($arg); $arg = isset($_list_tmp[4]) ? $_list_tmp[4] : null;

	
	if ($kind < 41 && $HcomArea != $kind) { $target = $HlandOwner[$x][$y]; }

	
	$_list_tmp = array($island['id'],$island['name'],$Hland[$x][$y],$HlandValue[$x][$y]);
	unset($id); $id = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
	unset($name); $name = isset($_list_tmp[1]) ? $_list_tmp[1] : null;
	unset($landKind); $landKind = isset($_list_tmp[2]) ? $_list_tmp[2] : null;
	unset($lv); $lv = isset($_list_tmp[3]) ? $_list_tmp[3] : null;
		unset($tId); $tId = isset($HlandOwner[$x][$y]) ? $HlandOwner[$x][$y] : 0;
		unset($tName); $tName = isset($HidToName[$tId]) ? $HidToName[$tId] : '';
	unset($cost); $cost = isset($HcomCost[$kind]) ? $HcomCost[$kind] : 0;
	unset($comName); $comName = isset($HcomName[$kind]) ? $HcomName[$kind] : '';
	$point = "($x, $y)";
	unset($landName); $landName = null;
	if (($id != $tId) && (($landKind == $HlandBase) || ($landKind == $HlandDefence))) {
		$landName = landName($HlandForest, $lv);
	} else{
		$landName = landName($landKind, $lv);
	}

	if ((($kind == $HcomSendMonster) || ($kind == $HcomMissileLD)) &&
		($HislandTurn - $island['kaisi'] <= $Hatkturn2)) {
		logMiss($id, $name, $comName, "$Hatkturn2 턴의 사이, 금지되고 있는 행위의");
		return 0;
	}
	if ((($kind == $HcomArea) || ($kind == $HcomMoney) || ($kind == $HcomFood) || ($kind == $HcomSoldier) || ($kind == $HcomMissileNM) ||
		($kind == $HcomMissilePP) || ($kind == $HcomMissileDM) || ($kind == $HcomMissileHM) || ($kind == $HcomMissileBM)) &&
		($HislandTurn - $island['kaisi'] <= $Hatkturn)) {
		logMiss($id, $name, $comName, "$Hatkturn 턴의 사이, 금지되고 있는 행위의");
		return 0;
	}
	if ($kind == $HcomDoNothing) {
		
		$island['money'] += 20;
		$island['absent'] ++;
		
		$p = ($island['warC'] > 0) ? 6 : 0;
		if ($island['absent'] + $p >= $HgiveupTurn) {
			$comArray[0] = array('kind'=>$HcomGiveup, 'target'=>0, 'x'=>0, 'y'=>0, 'arg'=>0);
		}
		return 1;
	}

	$island['absent'] = 0;

	
	if ($cost > 0) {
		
		if ($island['money'] < $cost) {
			logNoMoney($id, $name, $comName);
			return 0;
		}
	} elseif ($cost < 0) {
		
		if ($island['food'] < (-$cost)) {
			logNoFood($id, $name, $comName);
			return 0;
		}
	}

	
		if (($kind == $HcomPrepare) ||
			($kind == $HcomPrepare2)) {
			
			if (($landKind == $HlandSea) ||
				($landKind == $HlandSbase) ||
				($landKind == $HlandMountain) ||
				($landKind == $HlandMonster)) {
				
				logLandFail($id, $tId, $name, $tName, $comName, $landName, $point);
				return 0;
			}

		if (countAroundTerritory($x, $y, $id, 7) == 0) {
			
			logLandOwnerFail($id, $tId, $name, $tName, $comName, $point);
			return 0;
		}

		if ((($HlandDivPw[$x][$y] > 0) && ($id != $HlandDivNa[$x][$y])) || ($island['YU'][$tId] > 2)) {
			
			logLandRestrictFail($id, $HlandDivNa[$x][$y], $name, $tName, $comName, $point);
			return 0;
		}

		if ($id == $tId) {
			
			if (($landKind == $HlandPlains) || (($landKind == $HlandTown) && ($lv < 10))) {
				
				logLandFail($id, $tId, $name, $tName, $comName, "평지·1000명 미만의 마을", $point);
				return 0;
			}
		} elseif ($tId == 0) {
			
			if ($kind == $HcomPrepare2) {
				
				if (($landKind == $HlandWaste) && ($HlandDivPw[$x][$y] > 0) && ($id == $HlandDivNa[$x][$y])) {
					
				} else{
					logLandRestrictFail($id, $tId, $name, $tName, $comName, $point);
					return 0;
				}
			}
		} else{
			
			if ($kind == $HcomPrepare2) {
				
				if (($landKind == $HlandWaste) && ($HlandDivPw[$x][$y] > 0) && ($id == $HlandDivNa[$x][$y])) {
					
				} else{
					logLandRestrictFail($id, $tId, $name, $tName, $comName, $point);
					return 0;
				}
			}
			if ($landKind != $HlandWaste) {
				
				logLandRestrictFail($id, $tId, $name, $tName, $comName, $point);
				return 0;
			}
		}

		
		$Hland[$x][$y] = $HlandPlains;
		$HlandValue[$x][$y] = 0;
		$HlandOwner[$x][$y] = $id;

		if (($HlogOmit2) && ($kind == $HcomPrepare2)) {
			unset($sno); $sno = $island['seichi'];
			$island['seichi']++;
			if ($HlogOmit2 == 1) {
				unset($seichipnt); $seichipnt = null;
				$_list_tmp = array($x, $y, '개간');
				$seichipnt['x'] = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
				$seichipnt['y'] = isset($_list_tmp[1]) ? $_list_tmp[1] : null;
				$seichipnt['z'] = isset($_list_tmp[2]) ? $_list_tmp[2] : null;
				$island['seichipnt'][$sno] = $seichipnt;
			}
		} else{
			logLandSuc($id, $tId, $name, $tName, '개간', $point);
		}

		
		$island['money'] -= $cost;

		if ($kind == $HcomPrepare2) {
			
			
			return 0;
		} else{
			
			if (random(1000) < $HdisMaizo) {
				$v = 100 + random(401);
				$island['money'] += $v;
				logMaizo($id, $tId, $name, $tName, $comName, $v);
			}
			return 1;
		}
	} elseif ($kind == $HcomReclaim) {
		
		if (($HareaBorder) && ($Harea > $HdisFallBorder)) {
			
			logMiss($id, $name, $comName, "안전 한계치($HdisFallBorder$HunitArea)를 넘으면 매립 금지되고 있다");
			return 0;
		}
		if (($landKind != $HlandSea) && ($landKind != $HlandSbase)) {
			
			logLandFail($id, $tId, $name, $tName, $comName, $landName, $point);
			return 0;
		}

		if (countAroundTerritory($x, $y, $id, 7) == 0) {
			
			logLandOwnerFail($id, $tId, $name, $tName, $comName, $point);
			return 0;
		}

		if ((($HlandDivPw[$x][$y] > 0) && ($id != $HlandDivNa[$x][$y])) || ($island['YU'][$tId] > 2)) {
			
			logLandRestrictFail($id, $HlandDivNa[$x][$y], $name, $tName, $comName, $point);
			return 0;
		}

		
			$seaCount = countAround($x, $y, $HlandSea, 7) +
				countAround($x, $y, $HlandSbase, 7);

		if ($seaCount == 7) {
			
			logNoLandAround($id, $tId, $name, $tName, $comName, $point);
			return 0;
		}

		if (($landKind == $HlandSea) && ($lv == 1)) {
			

			
			$Hland[$x][$y] = $HlandWaste;
			$HlandValue[$x][$y] = 0;
			$HlandOwner[$x][$y] = $id;
			logLandSuc($id, $tId, $name, $tName, $comName, $point);
			$island['area']++;

			$seaCount = countAround($x, $y, $HlandSea, 7) +
				countAround($x, $y, $HlandSbase, 7);

			if ($seaCount <= 4) {
				
				unset($i); $i = null;
				unset($sx); $sx = null;
				unset($sy); $sy = null;
				for ($i = 1; $i < 7; $i++) {
					$sx = $x + $ax[$i];
					$sy = $y + $ay[$i];
					if (!($sy % 2) && ($y % 2)) { $sx--; }
					if ($Hroundmode) {
						$sx = $correct[$sx + 12];
						$sy = $correct[$sy + 12];
					}
					if (($sx < 0) || ($sx >= $HislandSize) || ($sy < 0) || ($sy >= $HislandSize)) {
					} else{
						
						if ($Hland[$sx][$sy] == $HlandSea) { $HlandValue[$sx][$sy] = 1; }
					}
				}
			}
		} else{
			
			$Hland[$x][$y] = $HlandSea;
			$HlandValue[$x][$y] = 1;
			$HlandOwner[$x][$y] = $id;
			logLandSuc($id, $tId, $name, $tName, $comName, $point);
		}

		
		$island['statistical'][0]++;

		
		$island['money'] -= $cost;
		return 1;
	} elseif ($kind == $HcomDestroy) {
		
		if (countAroundTerritory($x, $y, $id, 7) == 0) {
			
			logLandOwnerFail($id, $tId, $name, $tName, $comName, $point);
			return 0;
		}

		if ((($HlandDivPw[$x][$y] > 0) && ($id != $HlandDivNa[$x][$y])) || ($island['YU'][$tId] > 2)) {
			
			logLandRestrictFail($id, $HlandDivNa[$x][$y], $name, $tName, $comName, $point);
			return 0;
		}

		if (($landKind == $HlandSbase) || ($landKind == $HlandMonster)) {
			
			logLandFail($id, $tId, $name, $tName, $comName, $landName, $point);
			return 0;
		}

		if ($id == $tId) {
			
		} elseif ($tId == 0) {
			
		} else{
			
			if (($landKind != $HlandSea) && ($landKind != $HlandWaste)) {
				
				logLandRestrictFail($id, $tId, $name, $tName, $comName, $point);
				return 0;
			}
		}

		
		if ($landKind == $HlandMountain) {
			$Hland[$x][$y] = $HlandWaste;
			$HlandValue[$x][$y] = 0;
			$HlandOwner[$x][$y] = $id;
		} elseif ($landKind == $HlandSea) {
			$HlandValue[$x][$y] = 0;
			$HlandOwner[$x][$y] = 0;
		} else{
			$Hland[$x][$y] = $HlandSea;
			$HlandValue[$x][$y] = 1;
			$HlandOwner[$x][$y] = $id;
			$island['area']--;
		}
		unset($fmapmv); $fmapmv = $FmapMove[$HlandDiv[$x][$y]][$Hland[$x][$y]];
		if (($HlandDivPw[$x][$y] > 0) && ($FmapMove[$HlandDiv[$x][$y]][$Hland[$x][$y]] == 0)) {
			
			$ForceFlgMove[$x][$y] = 99;
		}
		logLandSuc($id, $tId, $name, $tName, $comName, $point);

		
		$island['money'] -= $cost;
		return 1;
	} elseif ($kind == $HcomArea) {
		
		if ($island['cession'] >= $HmaxAidArea) {
			logMiss($id, $name, $comName, "1 턴으로 할 수 있는 것은, $HmaxAidArea{$HunitArea}까지의");
		} elseif ($id == $tId) {
			
			$tn = $HidToNumber[$target];
			if (($tn === '' || $tn === null)) { return 0; }
			$tIsland =& $Hislands[$tn];
			$tId = $tIsland['id'];
	
			if (($HlandDivPw[$x][$y] > 0) && ($id != $HlandDivNa[$x][$y])) {
				logLandRestrictFail($id, $HlandDivNa[$x][$y], $name, $tName, $comName, $point);
				return 0;
			} elseif ($id == $tId) {
				
				logMiss($id, $name, $comName, "목표가 자국 영토의");
				return 0;
			}
			$tName = $tIsland['name'];
			$HlandOwner[$x][$y] = $tId;
			$HlandKeep[$x][$y] = 0;
			$HlandResist[$x][$y] = 5;
			$island['cession']++;
			logAreaSuc($id, $tId, $name, $tName, $comName, $point);
			if (($HlandDivNa[$x][$y] == $id) && ($arg == 1)) {
				$HlandDivNa[$x][$y] = $tId;
			} elseif (($HlandDivNa[$x][$y] == $id) && ($HlandDivPw[$x][$y] > 0)) {
				$island['soldier'] += $HlandDivPw[$x][$y];
				if ($HlandDivItem[$x][$y] > 0) { $island['item'][$HlandDivItem[$x][$y]]++; }
				logLandSuc($HlandDivNa[$x][$y], $HlandOwner[$x][$y], $island['name'], $HidToName[$HlandOwner[$x][$y]], "긴급 이탈", "($x, $y)");
				$HlandDivPw[$x][$y] = 0;
			}
		} else{
			logLandRestrictFail($id, $tId, $name, $tName, $comName, $point);
			return 0;
		}
		return 0;
	} elseif ($kind == $HcomDraft) {
		
		if ($id != $tId) {
			
			logLandRestrictFail($id, $tId, $name, $tName, $comName, $point);
			return 0;
		} else{
			
			if ($landKind != $HlandTown) {
				logLandFail($id, $tId, $name, $tName, $comName, $landName, $point);
				return 0;
			}
			if (($HlandDivPw[$x][$y] > 0) && ($id != $HlandDivNa[$x][$y])) {
				
				logLandRestrictFail($id, $HlandDivNa[$x][$y], $name, $tName, $comName, $point);
				return 0;
			}
			if ($HlogOmit2) {
				unset($sno); $sno = $island['seichi'];
				$island['seichi']++;
				if ($HlogOmit2 == 1) {
					unset($seichipnt); $seichipnt = null;
					$_list_tmp = array($x, $y, '징병');
					$seichipnt['x'] = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
					$seichipnt['y'] = isset($_list_tmp[1]) ? $_list_tmp[1] : null;
					$seichipnt['z'] = isset($_list_tmp[2]) ? $_list_tmp[2] : null;
					$island['seichipnt'][$sno] = $seichipnt;
				}
			} else{
				logLandSuc($id, $tId, $name, $tName, $comName, $point);
			}
			$island['soldier2'] += intval($lv / 2);

			$HlandValue[$x][$y] = intval($lv / 2) + 1;
		}
		$island['money'] -= $cost;
		return 0;
	} elseif ($kind == $HcomInfantry) {
		
		if ($island['soldier'] < 1) { return 0; }
		if ($id != $tId) {
			
			logLandRestrictFail($id, $tId, $name, $tName, $comName, $point);
			return 0;
		} else{
			
			if (($landKind != $HlandSupply) && ($landKind != $HlandMonument)) {
				logLandFail($id, $tId, $name, $tName, $comName, $landName, $point);
				return 0;
			}
			if (($HlandDivPw[$x][$y] > 0) && ($id != $HlandDivNa[$x][$y])) {
				
				logLandRestrictFail($id, $HlandDivNa[$x][$y], $name, $tName, $comName, $point);
				return 0;
			}
			if ($lv > $Hfleet) { $lv = $Hfleet; }
			if ($lv < 1) { $lv = 1; }
			unset($ofcorps); $ofcorps = $island['corps'];
			if ($Fnochange[$HlandDiv[$x][$y]]) {
				
				$HlandHGr[$x][$y] = $lv; 
			} elseif ($landKind == $HlandMonument) {
				
				if (!($HlandDivPw[$x][$y] > 0)) { return 0; }
			} else{
				$HlandHGr[$x][$y] = $lv; 
				$HlandDiv[$x][$y] = $ofcorps[$lv - 1]; 
			}
			if ($HlandDivPw[$x][$y] > 0) {
				
				if ($arg < 1) { $arg = 0; }
			} else{
				
				if ($arg < 10) { $arg = 10; }
			}
			if ($island['soldier'] < $arg) { $arg = $island['soldier']; }
			if ($HlandDivPw[$x][$y] + $arg > 250) { $arg = 250 - $HlandDivPw[$x][$y]; }
			$island['soldier'] -= $arg;
			if ($HlandDivPw[$x][$y] + $arg > 0) {

				$_list_tmp = array(0,0);
				unset($a); $a = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
				unset($b); $b = isset($_list_tmp[1]) ? $_list_tmp[1] : null;
				if ($HlandDivPw[$x][$y] > 0) {
					
					$a = $HlandDivEx[$x][$y] - $island['soldierex'];
					if ($a > 0) {
						$b = $a / 4;
						$a = 0;
					} else{
						$a = abs($a) / 4;
					}
				}
				$HlandDivEx[$x][$y] = intval((($HlandDivPw[$x][$y] * ($HlandDivEx[$x][$y] + $a)) + ($arg * ($island['soldierex'] + $b))) / ($HlandDivPw[$x][$y] + $arg));
			}
			$HlandDivPw[$x][$y] += $arg;
			$HlandDivNa[$x][$y] = $id;

			if ($HlogOmit2) {
				unset($sno); $sno = $island['seichi'];
				$island['seichi']++;
				if ($HlogOmit2 == 1) {
					unset($seichipnt); $seichipnt = null;
					$_list_tmp = array($x, $y, '설치');
					$seichipnt['x'] = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
					$seichipnt['y'] = isset($_list_tmp[1]) ? $_list_tmp[1] : null;
					$seichipnt['z'] = isset($_list_tmp[2]) ? $_list_tmp[2] : null;
					$island['seichipnt'][$sno] = $seichipnt;
				}
			} else{
				logLandSuc($id, $tId, $name, $tName, $comName, $point);
			}
		}
		$island['money'] -= $cost;
		return 0;
	} elseif ($kind == $HcomWithdraw) {
		
		if (($HlandDivPw[$x][$y] > 0) && ($id == $HlandDivNa[$x][$y])) {
			
			$ForceFlgMove[$x][$y] = 99;
			if ((($id == $tId) && ($arg == 1) && ($HlandDivPw[$x][$y] >= 50)) ||
				(($arg == 1) && ($HlandDivPw[$x][$y] >= 200)) ||
				(($arg == 1) && ($HlandDivPw[$x][$y] >= 150) && (hako_rand(2) == 0))) {
				
				$ForceFlgMove[$x][$y] = 98;
				if ($landKind == $HlandMountain) {
					$HlandValue[$x][$y] = 0;
				} elseif ($landKind == $HlandSbase) {
					$Hland[$x][$y] = $HlandSea;
					$HlandValue[$x][$y] = 0;
				} elseif ($landKind == $HlandSea) {
				} else{
					$Hland[$x][$y] = $HlandWaste;
					$HlandValue[$x][$y] = 0;
				}
			}
		} else{
			logLandRestrictFail($id, $tId, $name, $tName, $comName, $point);
			return 0;
		}
		$island['money'] -= $cost;
		return 0;
	} elseif ($kind == $HcomUnitOrder) {
		
		$arg--;
		if ($arg >= $Hfleet) { $arg = $Hfleet - 1; }
		if ($arg < 0) { $arg = 0; }
		
		if ($x > 6) { $x = 6; }
		if ($x < 0) { $x = 0; }
		unset($ofdirection); $ofdirection = $island['direction'];
		$ofdirection[$arg] = $x;
		$island['direction'] = $ofdirection;
		logSecret("{$HtagName_}{$name}{$H_tagName}가{$HtagComName_}{$comName}{$H_tagComName}를 실시했습니다.",$id,$id);
		return 0;
	} elseif ($kind == $HcomItem) {
		

		
		if (($id == $tId) && ($landKind == $HlandSupply) && (($HlandDivPw[$x][$y] > 0) && ($id == $HlandDivNa[$x][$y]))) {
			
			if ($island['item'][$arg] > 0) {
				$island['item'][$arg]--;
				logLandSuc($id, $tId, $name, $tName, "{$comName}($FItemName[$arg])", $point);
				if ($arg == 7) {
					
					logSoldierLvUp($id, $island['name'], $point);
					if ($HlandDivLv[$x][$y] < 15) { $HlandDivLv[$x][$y]++; }
				} else{
					if ($HlandDivItem[$x][$y] > 0) { $island['item'][$HlandDivItem[$x][$y]]++; }
					$HlandDivItem[$x][$y] = $arg;
				}
				$island['money'] -= $cost;
			} else{
				return 0;
			}
		} else{
			logLandFail($id, $tId, $name, $tName, $comName, $landName, $point);
			return 0;
		}
		return 0;
	} elseif (($kind == $HcomPlant) ||
		($kind == $HcomFarm) ||
		($kind == $HcomFactory) ||
		($kind == $HcomFarm2) ||
		($kind == $HcomFactory2) ||
		($kind == $HcomBase) ||
		($kind == $HcomMonument) ||
		($kind == $HcomMountain) ||
		($kind == $HcomSupply) ||
		($kind == $HcomDbase)) {
	unset($rtn); $rtn = $HcomTurn[$kind];
	$_adjacentCount = countAroundTerritory($x, $y, $id, 7);
	if ($_adjacentCount == 0) {
		// PHP 5.5 변환 후 가장자리/얇은여울 좌표에서 인접 판정이 누락되는 문제 보정
		$_adjacentCount = countAroundTerritory($x, $y, $id, 19);
	}
	if ($_adjacentCount == 0) {
		logLandOwnerFail($id, $tId, $name, $tName, $comName, $point);
		return 0;
	}
	if ((($HlandDivPw[$x][$y] > 0) && ($id != $HlandDivNa[$x][$y])) || ($island['YU'][$tId] > 2)) {
		
		logLandRestrictFail($id, $HlandDivNa[$x][$y], $name, $tName, $comName, $point);
		return 0;
	}
	if ($kind == $HcomMountain) {
		
		if ($landKind != $HlandMountain) {
			
			logLandFail($id, $tId, $name, $tName, $comName, $landName, $point);
			return 0;
		}
		if ($id == $tId) {
			
		} elseif ($tId == 0) {
			
		} else{
			
			if ($HlandValue[$x][$y] != 0) {
				
				logLandRestrictFail($id, $tId, $name, $tName, $comName, $point);
				return 0;
			}
		}
	} else{
		
		if (!
			(($landKind == $HlandPlains) ||
			(($landKind == $HlandTown) && ($id == $tId)) ||
			(($landKind == $HlandFarm) && ($kind == $HcomFarm)) ||
			(($landKind == $HlandFactory) && ($kind == $HcomFactory)) ||
			(($landKind == $HlandFarm) && ($kind == $HcomFarm2) && ($id == $tId)) ||
			(($landKind == $HlandFactory) && ($kind == $HcomFactory2) && ($id == $tId)) ||
			(($landKind == $HlandSupply) && ($kind == $HcomSupply) && ($id == $tId)) ||
			(($landKind == $HlandDefence) && ($kind == $HcomDbase) && ($id == $tId)))) {
			
			if (($id == $tId) || ($tId == 0)) {
				logLandFail($id, $tId, $name, $tName, $comName, $landName, $point);
			} else{
				logLandRestrictFail($id, $tId, $name, $tName, $comName, $point);
			}
			return 0;
		}
	}

	
	if ($kind == $HcomPlant) {
		
		$Hland[$x][$y] = $HlandForest;
		$HlandValue[$x][$y] = 1; 
		logPBSuc($id, $tId, $name, $tName, $comName, $point);
	} elseif ($kind == $HcomBase) {
		
		$Hland[$x][$y] = $HlandBase;
		$HlandValue[$x][$y] = 0; 
		logPBSuc($id, $tId, $name, $tName, $comName, $point);
	} elseif ($kind == $HcomFarm || $kind == $HcomFarm2) {
		
		if ($landKind == $HlandFarm) {
			
			$HlandValue[$x][$y] += 5;
			if ($HlandValue[$x][$y] > 60) { $HlandValue[$x][$y] = 60; }
		} else{
			
			$Hland[$x][$y] = $HlandFarm;
			$HlandValue[$x][$y] = 10;
		}
		logLandSuc($id, $tId, $name, $tName, $comName, $point);
	} elseif ($kind == $HcomFactory || $kind == $HcomFactory2) {
		
		if ($landKind == $HlandFactory) {
			
			$HlandValue[$x][$y] += 15; 
			if ($HlandValue[$x][$y] > 120) { $HlandValue[$x][$y] = 120; }
		} else{
			
			$Hland[$x][$y] = $HlandFactory;
			$HlandValue[$x][$y] = 30; 
		}
		logLandSuc($id, $tId, $name, $tName, $comName, $point);
	} elseif ($kind == $HcomDbase) {
		
		if ($cmdcount == 0) {
			if ($landKind == $HlandDefence) {
				
				if ($HislandTurn - $island['kaisi'] <= $Hatkturn2) {
					logMiss($id, $name, "$comName(자폭)", "$Hatkturn2 턴의 사이, 금지되고 있는 행위의");
					return 0;
				}
				$cost *= 4;
				if ($island['money'] < $cost) {
					logNoMoney($id, $name, $comName);
					return 0;
				}
				
				unset($i); $i = null;
				unset($sx); $sx = null;
				unset($sy); $sy = null;
				unset($count); $count = null;
				unset($flg); $flg = null;
				$count = 0;
				for ($i = 0; $i < 19; $i++) {
					$sx = $x + $ax[$i];
					$sy = $y + $ay[$i];
					if (!($sy % 2) && ($y % 2)) { $sx--; }
					if ($Hroundmode) {
						$sx = $correct[$sx + 12];
						$sy = $correct[$sy + 12];
					}
					if (($sx < 0) || ($sx >= $HislandSize) || ($sy < 0) || ($sy >= $HislandSize)) {
						
					} elseif (($island['YU'][$HlandOwner[$sx][$sy]] > 2) &&
						 ($Hland[$sx][$sy] != $HlandSea) &&
						 (($i >= 7) && ($Hland[$sx][$sy] != $HlandWaste))) {
						 logMiss($id, $name, $comName, "우호국에 피해를 준다");
						 return 0;
					} elseif (($i < 7) && ($HlandOwner[$sx][$sy] != $id) && ($HlandOwner[$sx][$sy] != 0)) {
						$flg = 1;
					}
				}
				$HlandValue[$x][$y] = 1; 
				if ($flg) {
					logBombSet($id, $tId, $name, $tName, $landName, $point);
				} else{
					logBombSet($id, $tId, $name, $tName, $landName, '(?, ?)');
				}
			} else{
				
				$Hland[$x][$y] = $HlandDefence;
				$HlandValue[$x][$y] = 0;
				logPBSuc($id, $tId, $name, $tName, $comName, $point);
			}
		} else{
			logMiss($id, $name, $comName, "최초의 커멘드만 유효의");
			return 0;
		}
	} elseif ($kind == $HcomSupply) {
		
		if ($arg > $Hfleet) { $arg = $Hfleet; }
		if ($arg < 1) { $arg = 1; }
		if ($landKind == $HlandSupply) { $rtn = 0; } 

		
		$Hland[$x][$y] = $HlandSupply;
		$HlandValue[$x][$y] = $arg;
		logPBSuc($id, $tId, $name, $tName, "제{$arg}{$comName}", $point);
	} elseif ($kind == $HcomMonument) {
		
		$Hland[$x][$y] = $HlandMonument;
		if ($arg >= $HmonumentNumber) { $arg = 0; }
		$HlandValue[$x][$y] = $arg;
		logLandSuc($id, $tId, $name, $tName, $comName, $point);
		if (($HlandDivPw[$x][$y] > 0) && ($FmapMove[$HlandDiv[$x][$y]][$Hland[$x][$y]] == 0)) {
			
			$ForceFlgMove[$x][$y] = 99;
		}
	} elseif ($kind == $HcomMountain) {
		
		$HlandValue[$x][$y] += 20;
		if ($HlandValue[$x][$y] > 240) { $HlandValue[$x][$y] = 240; }
		if (hako_rand(250) < $HdisMaizo) { 
			$v = 200 + hako_rand(401);
			$island['money'] += $v;
			logGold($id, $tId, $name, $tName, $comName, $v);
		}
		logLandSuc($id, $tId, $name, $tName, $comName, $point);
	}
	$HlandOwner[$x][$y] = $id;

	
	$island['money'] -= $cost;

	
		if (($kind == $HcomFarm) ||
			($kind == $HcomFactory) ||
			($kind == $HcomFarm2) ||
			($kind == $HcomFactory2) ||
			($kind == $HcomMountain)) {
			if ($arg > 1) {
				$arg--;
				slideBack($comArray, 0, $kind, $target, $x, $y, $arg);
			}
		}
	return $rtn;

	} elseif ($kind == $HcomSbase) {
		
		if (($landKind != $HlandSea) || ($lv == 1)) {
			
			logLandFail($id, $tId, $name, $tName, $comName, $landName, $point);
			return 0;
		}
		$Hland[$x][$y] = $HlandSbase;
		$HlandValue[$x][$y] = 0; 
		$HlandOwner[$x][$y] = $id;
		logLandSuc($id, $tId, $name, $tName, $comName, '(?, ?)');

		
		$island['money'] -= $cost;
		return 1;
		} elseif (($kind == $HcomMissileNM) ||
			($kind == $HcomMissilePP) ||
			($kind == $HcomMissileDM) ||
			($kind == $HcomMissileLD) ||
			($kind == $HcomMissileHM) ||
			($kind == $HcomMissileBM)) {
		
		$flag = 0;
		if ($arg == 0) { $arg = 10000; }

		
		$tOrgName = $HidToName[$target];
		unset($tx); $tx = null;
		unset($ty); $ty = null;
		unset($err); $err = null;
		unset($distance); $distance = null;

		if (($id != $target) && (chkWarIsland($id, $target) != 2)) {
			logNoWar($id, $target, $name, $tOrgName, $comName);
			return 0;
		}

		
		if (($kind == $HcomMissileLD) ||
			($kind == $HcomMissileDM)) {
			$err = 19;
		} elseif ($kind == $HcomMissileHM) {
			$err = 1;
		} else{
			if ($distance >= $HmissileRange) {
				$err = 7;
			} else{
				if ($kind == $HcomMissilePP) {
					$err = 8;
				} else{
					$err = 7;
				}
			}
		}

		
		if ($Hland[$x][$y] != $HlandMonster) {
			unset($i); $i = null;
			unset($r); $r = null;
			$r = ($err == 8) ? 7 : $err;
			for ($i = 1; $i < $r; $i++) {
				$tx = $x + $ax[$i];
				$ty = $y + $ay[$i];
				if (!($ty % 2) && ($y % 2)) { $tx--; }
				if ($Hroundmode) {
					$tx = $correct[$tx + 12];
					$ty = $correct[$ty + 12];
				}
				
				if (($tx < 0) || ($tx >= $HislandSize) || ($ty < 0) || ($ty >= $HislandSize)) { continue; }
				if ($island['YU'][$HlandOwner[$tx][$ty]] > 2) {
					if (($Hland[$tx][$ty] == $HlandMountain) ||
						($Hland[$tx][$ty] == $HlandWaste) ||
						($Hland[$tx][$ty] == $HlandPlains) ||
						($Hland[$tx][$ty] == $HlandSbase) ||
						($HlandKeep[$tx][$ty] < 1)) {
						
					} else{
						
						logMiss($id, $name, $comName, "우호국이 오차의 범위에 포함된다");
						return 0;
					}
				}
			}
		}

		
		$boat = 0;

		
		$_list_tmp = array(0,0,0);
		unset($bx); $bx = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
		unset($by); $by = isset($_list_tmp[1]) ? $_list_tmp[1] : null;
		unset($count); $count = isset($_list_tmp[2]) ? $_list_tmp[2] : null;
		while (($arg > 0) &&
			($island['money'] >= $cost)) {
			
			while ($count < $HpointNumber) {
				$bx = $Hrpx[$count];
				$by = $Hrpy[$count];
			if ($id == $HlandOwner[$bx][$by]) {
				if (($Hland[$bx][$by] == $HlandBase) ||
					($Hland[$bx][$by] == $HlandSbase)) {

					
					$_list_tmp = array(abs($bx - $x), abs($by - $y));
					unset($dx); $dx = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
					unset($dy); $dy = isset($_list_tmp[1]) ? $_list_tmp[1] : null;

					$rl = 0;
					if ($x > $bx) {
						
						$rl = 1;
					} elseif ($x < $bx) {
						
						$rl = -1;
					}
					if ($Hroundmode) {
						if ($dx > intval($HislandSize / 2)) {
							$rl = -$rl;
							$dx = $HislandSize - $dx;
						}
						if ($dy > intval($HislandSize / 2)) { $dy = $HislandSize - $dy; }
					}
					$distance = $dx + $dy;
					$distance -= ($dx >= ($dy / 2)) ? intval($dy / 2) : $dx;

					if (!($by % 2) && ($y % 2)) {
						
						if ($rl == 1) { $distance--; }
					} elseif (!($y % 2) && ($by % 2)) {
						
						if ($rl == -1) { $distance--; }
					}
					
					$baseLevel = expToLevel($Hland[$bx][$by], $HlandValue[$bx][$by]);
					if ($Hland[$bx][$by] == $HlandSbase) {
						$baseLevel += $HmissileRangeS;
					} else{
						$baseLevel += $HmissileRange;
					}
					if ($kind == $HcomMissileBM) { $baseLevel += 5; } 

					if ($baseLevel > $distance) { break; }
				}
			}
			$count++;
		}
		if ($count >= $HpointNumber) { break; }
		
		$flag = 1;
		$_list_tmp = expToLevel2($Hland[$bx][$by], $HlandValue[$bx][$by]); 
		unset($level); $level = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
		
		while (($level > 0) && ($arg > 0) && ($island['money'] > $cost)) {

		
		$level--;
		$arg--;
		$island['money'] -= $cost;

		
		$r = random($err);
		if (($err == 8) && ($r == 7)) { $r = 0; }
		$tx = $x + $ax[$r];
		$ty = $y + $ay[$r];
		if (!($ty % 2) && ($y % 2)) { $tx--; }
		if ($Hroundmode) {
			$tx = $correct[$tx + 12];
			$ty = $correct[$ty + 12];
		}
		
		if (($tx < 0) || ($tx >= $HislandSize) || ($ty < 0) || ($ty >= $HislandSize)) {
			
			logMsOut($id, $target, $name, $tOrgName,$comName, $point);
			continue;
		}

		
		$tTarget = $HlandOwner[$tx][$ty];
		$tIsland =& $Hislands[$HidToNumber[$tTarget]];

		$tName = $HidToName[$tTarget];

		
		$tL = $Hland[$tx][$ty];
		$tLv = $HlandValue[$tx][$ty];
		$tLname = landName($tL, $tLv);
		$tPoint = "($tx, $ty)";

		
		if (($kind == $HcomMissileHM) && ($id != $tTarget)) {
			
			logMsCaught($id, $target, $tTarget, $name, $tOrgName, $tName, $comName, $point, $tPoint);
			continue;
		}

		
		$defence = 0;
		if ($HdefenceHex[$id][$tx][$ty] == 1) {
			$defence = 1;
		} elseif ($HdefenceHex[$id][$tx][$ty] == -1) {
		} else{
			if ($tL == $HlandDefence) {
				

				
				unset($i); $i = null;
				unset($sx); $sx = null;
				unset($sy); $sy = null;
				for ($i = 0; $i < 19; $i++) {
					$sx = $tx + $ax[$i];
					$sy = $ty + $ay[$i];
					if (!($sy % 2) && ($ty % 2)) { $sx--; }
					if ($Hroundmode) {
						$sx = $correct[$sx + 12];
						$sy = $correct[$sy + 12];
					}
					if (($sx < 0) || ($sx >= $HislandSize) || ($sy < 0) || ($sy >= $HislandSize)) { continue; }
					$HdefenceHex[$id][$sx][$sy] = 0;
				}
			} else{
				$HdefenceHex[$id][$tx][$ty] = -1;
				unset($i); $i = null;
				unset($sx); $sx = null;
				unset($sy); $sy = null;
				for ($i = 0; $i < 19; $i++) {
					$sx = $tx + $ax[$i];
					$sy = $ty + $ay[$i];
					if (!($sy % 2) && ($ty % 2)) { $sx--; }
					if ($Hroundmode) {
						$sx = $correct[$sx + 12];
						$sy = $correct[$sy + 12];
					}
					if (($sx < 0) || ($sx >= $HislandSize) || ($sy < 0) || ($sy >= $HislandSize)) { continue; }
					if (($HlandDivPw[$sx][$sy] > 49) && ($HlandOwner[$sx][$sy] != $HlandDivNa[$sx][$sy])) { continue; }
					if (($Hland[$sx][$sy] == $HlandDefence) && ($HlandOwner[$sx][$sy] == $HlandOwner[$tx][$ty])) {
						$HdefenceHex[$id][$tx][$ty] = 1;
						$defence = 1;
						break;
					}
				}
			}
		}

		if ($defence == 1) {
			
			logMsCaught($id, $target, $tTarget, $name, $tOrgName, $tName, $comName, $point, $tPoint);
			continue;
		}

		
		if ($HlandDivPw[$tx][$ty] > 0) {
			if ($kind == $HcomMissileLD) {
				
				logAnnihilation($HlandDivNa[$tx][$ty], $HidToName[$HlandDivNa[$tx][$ty]], $tPoint);
				
				$island['attack'] += $HlandDivPw[$tx][$ty];
				$tIsland['damage'] += $HlandDivPw[$tx][$ty];
				
				$HlandDivPw[$tx][$ty] = 0;
			} else{
				unset($pw); $pw = $HlandDivPw[$tx][$ty];
				if ($kind == $HcomMissileHM) {
					
					$HlandDivPw[$tx][$ty] -= 50;
				} else{
					$HlandDivPw[$tx][$ty] -= random(20) + 30;
				}
				if ($HlandDivPw[$tx][$ty] < 1) {
					logAnnihilation($HlandDivNa[$tx][$ty], $HidToName[$HlandDivNa[$tx][$ty]], $tPoint);
					$HlandDivPw[$tx][$ty] = 0;
				}
				
				$island['attack'] += $pw - $HlandDivPw[$tx][$ty];
				$tIsland['damage'] += $pw - $HlandDivPw[$tx][$ty];
				if ($kind == $HcomMissileHM) {
					
					$island['soldierF'] += $pw - $HlandDivPw[$tx][$ty];
				}
			}
		}

		
		if ((($tL == $HlandSea) && ($tLv == 0)) ||
			((($tL == $HlandSea) ||
			($tL == $HlandSbase) ||
			($tL == $HlandMountain))
			&& ($kind != $HcomMissileLD))) {
			

			if ($tL == $HlandSbase) { $tL = $HlandSea; }
			$tLname = landName($tL, $tLv);
			
			logMsNoDamage($id, $target, $tTarget, $name, $tOrgName, $tName, $comName, $tLname, $point, $tPoint);
			continue;
		}

		
		if ($kind == $HcomMissileLD) {
			
			if ($tL == $HlandMountain) {
				
				logMsLDMountain($id, $target, $tTarget, $name, $tOrgName, $tName, $comName, $tLname, $point, $tPoint);
				
				$Hland[$tx][$ty] = $HlandWaste;
				$HlandValue[$tx][$ty] = 0;
				continue;
			} elseif ($tL == $HlandSbase) {
				
				logMsLDSbase($id, $target, $tTarget, $name, $tOrgName, $tName, $comName, $tLname, $point, $tPoint);
			} elseif ($tL == $HlandMonster) {
				
				logMsLDMonster($id, $target, $tTarget, $name, $tOrgName, $tName, $comName, $tLname, $point, $tPoint);
			} elseif ($tL == $HlandSea) {
				
				logMsLDSea1($id, $target, $tTarget, $name, $tOrgName, $tName, $comName, $tLname, $point, $tPoint);
			} elseif ($tL == $HlandDefence && $tLv == 1) {
				
				logMsLDLand($id, $target, $tTarget, $name, $tOrgName, $tName, $comName, $tLname, $point, $tPoint, "방위 시설을 자폭 장치마다 파괴!");
			} else{
				
				logMsLDLand($id, $target, $tTarget, $name, $tOrgName, $tName, $comName, $tLname, $point, $tPoint);
			}

			
			if (($tL == $HlandTown) ||
			  ($tL == $HlandFarm) || ($tL == $HlandFactory) || ($tL == $HlandBase) || ($tL == $HlandDefence) || ($tL == $HlandSupply)) {
				if (($Hland[$bx][$by] == $HlandBase) || ($Hland[$bx][$by] == $HlandSbase)) {
					
					if (($tL == $HlandFarm) || ($tL == $HlandFactory) || ($tL == $HlandBase) || ($tL == $HlandDefence) || ($tL == $HlandSupply)) {
						$HlandValue[$bx][$by] += 2;
					} else{
						$HlandValue[$bx][$by] += intval($tLv / 20);
					}
					if ($HlandValue[$bx][$by] > $HmaxExpPoint) { $HlandValue[$bx][$by] = $HmaxExpPoint; }
				}
			}

			
			$Hland[$tx][$ty] = $HlandSea;
			$tIsland['area']--;
			$HlandValue[$tx][$ty] = 1;

			
			if (($tL == $HlandSea) || ($tL == $HlandSbase)) {
				$HlandValue[$tx][$ty] = 0;
			}
		} elseif ($kind == $HcomMissileHM) {
			
			if ($tL == $HlandTown) {
				unset($pw); $pw = $HlandValue[$tx][$ty];
				$HlandValue[$tx][$ty] -= 50;
				if ($HlandValue[$tx][$ty] < 1) {
					
					$Hland[$tx][$ty] = $HlandPlains;
					$HlandValue[$tx][$ty] = 0;
				}
				
				$island['soldierF'] += $pw - $HlandValue[$tx][$ty];
				
				if (($Hland[$bx][$by] == $HlandBase) || ($Hland[$bx][$by] == $HlandSbase)) {
					$HlandValue[$bx][$by] += 2;
					if ($HlandValue[$bx][$by] > $HmaxExpPoint) { $HlandValue[$bx][$by] = $HmaxExpPoint; }
				}
			} else{
				
				logMsWaste($id, $target, $tTarget, $name, $tOrgName, $tName, $comName, $tLname, $point, $tPoint);
			}

		} else{
			
			if ($tL == $HlandWaste) {
				
				logMsWaste($id, $target, $tTarget, $name, $tOrgName, $tName, $comName, $tLname, $point, $tPoint);
			} elseif ($tL == $HlandDefence && $tLv == 1) {
				
				logMsNormal($id, $target, $tTarget, $name, $tOrgName, $tName, $comName, $tLname, $point, $tPoint, "자폭 장치마다 파괴해");
			} elseif ($tL == $HlandMonster) {
				
				$mKind = monsterSpec($tLv);
				unset($mName); $mName = isset($_list_tmp[1]) ? $_list_tmp[1] : null;
				unset($mHp); $mHp = isset($_list_tmp[2]) ? $_list_tmp[2] : null;
				$special = $HmonsterSpecial[$mKind];

				
				if ((($special == 3) && (($HislandTurn % 2) == 1)) ||
					(($special == 4) && (($HislandTurn % 2) == 0)) ||
					(($special == 5) && (hako_rand(4) != 0))) {
					
					logMsMonNoDamage($id, $target, $tTarget, $name, $tOrgName, $tName, $comName, $mName, $point, $tPoint);
					continue;
				} else{
					
					if ($mHp == 1) {
						
						if (($Hland[$bx][$by] == $HlandBase) || ($Hland[$bx][$by] == $HlandSbase)) {
							
							$HlandValue[$bx][$by] += $HmonsterExp[$mKind];
							if ($HlandValue[$bx][$by] > $HmaxExpPoint) { $HlandValue[$bx][$by] = $HmaxExpPoint; }
						}
						logMsMonKill($id, $target, $tTarget, $name, $tOrgName, $tName, $comName, $mName, $point, $tPoint);

						
						$value = $HmonsterValue[$mKind];
						if ($value > 0) {
							$island['money'] += $value;
							logMsMonMoney($id, $mName, $value);
						}

						
						$prize = $island['prize'];
						hako_regex('~([0-9]*),([0-9]*),(.*)~', $prize);
						$flags = hako_m(1);
						$monsters = hako_m(2);
						$turns = hako_m(3);
						$v = intval(pow(2, $mKind));
						$monsters |= $v;
						$island['prize'] = "$flags,$monsters,$turns";
					} else{
						
						logMsMonster($id, $target, $tTarget, $name, $tOrgName, $tName, $comName, $mName, $point, $tPoint);
						
						$HlandValue[$tx][$ty]--;
						continue;
					}
				}
			} else{
				
				logMsNormal($id, $target, $tTarget, $name, $tOrgName, $tName, $comName, $tLname, $point, $tPoint);
			}
			
			if (($tL == $HlandTown) ||
			  ($tL == $HlandFarm) || ($tL == $HlandFactory) || ($tL == $HlandBase) || ($tL == $HlandDefence) || ($tL == $HlandSupply)) {
				if (($Hland[$bx][$by] == $HlandBase) || ($Hland[$bx][$by] == $HlandSbase)) {
					
					if (($tL == $HlandFarm) || ($tL == $HlandFactory) || ($tL == $HlandBase) || ($tL == $HlandDefence) || ($tL == $HlandSupply)) {
						$HlandValue[$bx][$by] += 2;
					} else{
						$HlandValue[$bx][$by] += intval($tLv / 20);
						$boat += $tLv; 
					}
					if ($HlandValue[$bx][$by] > $HmaxExpPoint) { $HlandValue[$bx][$by] = $HmaxExpPoint; }
				}
			}
			
			$Hland[$tx][$ty] = $HlandWaste;
			$HlandValue[$tx][$ty] = 1; 
			$HlandResist[$tx][$ty] -= 2;
		}
		}
		
		$count++;
		}

		if ($flag == 0) {
			
			logMsNoBase($id, $name, $comName);
			return 0;
		}

		
		$boat = intval($boat / 2);
		if (($boat > 0) && ($id != $target)) {
			
			$achive = 0; 
			unset($i); $i = null;
			for ($i = 0; ($i < $HpointNumber && $boat > 0); $i++) {
			$bx = $Hrpx[$i];
			$by = $Hrpy[$i];
			if ($HlandOwner[$bx][$by] != $id) { continue; }
			if ($Hland[$bx][$by] == $HlandTown) {
				
				$lv = $HlandValue[$bx][$by];
				if ($boat > 50) {
					$lv += 50;
					$boat -= 50;
					$achive += 50;
				} else{
					$lv += $boat;
					$achive += $boat;
					$boat = 0;
				}
				if ($lv > 200) {
					$boat += ($lv - 200);
					$achive -= ($lv - 200);
					$lv = 200;
				}
				$HlandValue[$bx][$by] = $lv;
			} elseif ($Hland[$bx][$by] == $HlandPlains) {
				

				$Hland[$bx][$by] = $HlandTown;
				if ($boat > 10) {
					$HlandValue[$bx][$by] = 5;
					$boat -= 10;
					$achive += 10;
				} elseif ($boat > 5) {
					$HlandValue[$bx][$by] = $boat - 5;
					$achive += $boat;
					$boat = 0;
				}
			}
			if ($boat <= 0) {
				break;
			}
			}
			if ($achive > 0) {
			
			logMsBoatPeople($id, $name, $achive);

			
			if ($achive >= 200) {
				$prize = $island['prize'];
				hako_regex('~([0-9]*),([0-9]*),(.*)~', $prize);
				$flags = hako_m(1);
				$monsters = hako_m(2);
				$turns = hako_m(3);

				if ((!($flags & 8)) &&  $achive >= 200) {
					$flags |= 8;
					logPrize($id, $name, $Hprize[4]);
				} elseif ((!($flags & 16)) &&  $achive > 500) {
					$flags |= 16;
					logPrize($id, $name, $Hprize[5]);
				} elseif ((!($flags & 32)) &&  $achive > 800) {
					$flags |= 32;
					logPrize($id, $name, $Hprize[6]);
				}
				$island['prize'] = "$flags,$monsters,$turns";
			}
			}
		}
		if ($kind == $HcomMissileHM) {
			$island['Afmissile'] = 1;
			return 0;
		} else{
			return 1;
		}
	if ($kind == $HcomSendMonster) {
		
		
		$tn = $HidToNumber[$target];
		$tIsland =& $Hislands[$tn];
		$tName = $tIsland['name'];

		if (($tn === '' || $tn === null)) {
			
			logMsNoTarget($id, $name, $comName);
			return 0;
		}
		if (($id != $target) && (chkWarIsland($id, $target) != 2)) {
			logNoWar($id, $target, $name, $tName, $comName);
			return 0;
		}
		$lName = landName($Hland[$x][$y], $HlandValue[$x][$y]);
		
		if ($Hland[$x][$y] != $HlandTown) {
			logLandFail($id, $target, $name, $tName, $comName, $landName, $point);
			return 0;
		}
		
		logMonsSend($id, $target, $name, $tName);
		$name = $HidToName[$HlandOwner[$x][$y]];
		
		$Hland[$x][$y] = $HlandMonster;
		$HlandValue[$x][$y] = $HmonsterBHP[0] + random($HmonsterDHP[0]);
		if ($HlandDivPw[$x][$y] > 99 && $HlandValue[$x][$y] > 1) { $HlandValue[$x][$y]--; }
		$HlandOwner[$x][$y] = 0;
		$HlandDivPw[$x][$y] = 0;
		
		$__monster_spec = monsterSpec($HlandValue[$x][$y]);
			logMonsCome($id, $target, $name, isset($__monster_spec[1]) ? $__monster_spec[1] : '', $point, $lName);
			unset($__monster_spec);

	
		$island['money'] -= $cost;
		return 1;
	} elseif (($kind == $HcomAmity) || ($kind == $HcomDeWar) || ($kind == $HcomCeasefire)) {
		if (($HragnarokTurn > 0) && ($HragnarokTurn <= $HislandTurn)) {
			
			return 0;
		}
		if (($kind == $HcomDeWar) && ($island['AfDeWar'] == 1)) {
			
			return 0;
		} elseif ($kind == $HcomDeWar) {
			$island['AfDeWar'] = 1;
		}
		
		$tn = $HidToNumber[$target];
		if (($tn === '' || $tn === null)) {
			
			logMsNoTarget($id, $name, $comName);
			return 0;
		}
		$tIsland =& $Hislands[$tn];
		$tName = $tIsland['name'];
		if ($target == $id) { return 0; }
		if ((($HislandTurn - $tIsland['kaisi']) <= $Hatkturn) ||
			(($HislandTurn - $island['kaisi']) <= $Hatkturn)) {
			logMiss($id, $name, $comName, "$Hatkturn 턴의 사이, 금지되고 있는 행위의");
			return 0;
		}
		if ($kind == $HcomAmity) {
			
			if (chkWarIsland($id, $target) > 0) {
				logMiss($id, $name, $comName, "{$tName}와 전쟁중 또는, 전쟁 준비중의");
				return 0;
			}
			for ($i=0;$i < hako_last_index($HamityIsland);$i+=4) {
				$tn1 = $HidToNumber[$HamityIsland[$i+1]];
				if (($tn1 === '' || $tn1 === null)) { continue; }
				$tn2 = $HidToNumber[$HamityIsland[$i+2]];
				if (($tn2 === '' || $tn2 === null)) { continue; }
				if ((($Hislands[$tn1]['id'] == $id) && ($Hislands[$tn2]['id'] == $target)) ||
					(($Hislands[$tn1]['id'] == $target) && ($Hislands[$tn2]['id'] == $id))) {
					break;
				}
			}
			if ($i < hako_last_index($HamityIsland)) {
				if ($island['YU'][$target] == 1) {
					
					if ($arg == 1002) {
						
						logOut("{$tName}가{$name}에 간 우호 타진은, 거부되었습니다. ",$id, $target);
						hako_splice($HamityIsland, $i, 4);
					} else{
						
						$HamityIsland[$i+3] = 3;
						logAmity($id, $name, $target, $tName);
					}
				} elseif ($island['YU'][$target] == 2) {
					
					logOut("{$name}가{$tName}에 간 우호 타진은, 철회되었습니다. ",$id, $target);
					hako_splice($HamityIsland, $i, 4);
				} elseif ($island['YU'][$target] > 2) {
					logMiss($id, $name, $comName, "{$tName}가 이미 우호국의");
				} else{
					
				}
			} else{
				$arg = $HislandTurn + $arg;
				hako_push($HamityIsland, $arg);
				hako_push($HamityIsland, $id);
				hako_push($HamityIsland, $target);
				hako_push($HamityIsland, 0);
				logSecret("{$tName}에 우호 타진을 했습니다.",$id);
				logSecret("{$name}가 우호 관계를 묶으려고 타진하고 있습니다. (희망하는 경우는,{$name}에 대해서 우호 타진 명령을 던져 주세요)",$target);
			}
			return 0;
		} else{
			
			$wname = $name . " VS " . $tName;
			$name = "{$HtagName_}{$name}{$H_tagName}";
			$tName = "{$HtagName_}{$tName}{$H_tagName}";

			if (chkWarIsland($id, $target)) {
				
				for ($i=0;$i < hako_last_index($HwarIsland);$i+=4) {
					$tn1 = $HidToNumber[$HwarIsland[$i+1]];
					if (($tn1 === '' || $tn1 === null)) { continue; }
					$tn2 = $HidToNumber[$HwarIsland[$i+2]];
					if (($tn2 === '' || $tn2 === null)) { continue; }
					if (($Hislands[$tn1]['id'] == $id) && ($Hislands[$tn2]['id'] == $target)) {
						
						if ($kind == $HcomDeWar) {
							if ($HwarIsland[$i+3] == 1) {
								$HwarIsland[$i+3] = 0;
								logOut("{$name}가{$tName}에 타진하고 있던 정전을 철회해 전쟁 계속을 통고했습니다.",$id, $target);
							}
						} elseif ($HwarIsland[$i+3] == 2) {
							
							if ($HwarIsland[$i] > $HislandTurn) {
								
								logOut("{$name}와{$tName}의 전쟁은 회피되었습니다.",$id, $target);
							} else{
								
								logOut("{$name}와{$tName}의 정전 합의에 의해 전쟁은 종결했습니다. ",$id, $target);
								logHistory("{$HtagName_}{$wname}{$H_tagName}전쟁은 종결했습니다. ");
							}
							hako_splice($HwarIsland, $i, 4);
						} else{
							
							$HwarIsland[$i+3] = 1;
							logOut("{$name}가{$tName}에<b>정전의 의사</b>를 타진했습니다. ",$id, $target);
						}
						return 0;
					} elseif (($Hislands[$tn1]['id'] == $target) && ($Hislands[$tn2]['id'] == $id)) {
						
						if ($kind == $HcomDeWar) {
							if ($HwarIsland[$i+3] == 2) {
								$HwarIsland[$i+3] = 0;
								logOut("{$name}가{$tName}에 타진하고 있던 정전을 철회해 전쟁 계속을 통고했습니다. ",$id, $target);
							}
						} elseif ($HwarIsland[$i+3] == 1) {
							
							if ($HwarIsland[$i] > $HislandTurn) {
								
								logOut("{$name}와{$tName}의 전쟁은 회피되었습니다. ",$id, $target);
							} else{
								
								logOut("{$name}와{$tName}의 정전 합의에 의해 전쟁은 종결했습니다. ",$id, $target);
								logHistory("{$HtagName_}{$wname}{$H_tagName}전쟁은 종결했습니다. ");
							}
							hako_splice($HwarIsland, $i, 4);
						} else{
							
							$HwarIsland[$i+3] = 2;
							logOut("{$name}가{$tName}에<b>정전의 의사</b>를 타진했습니다.",$id, $target);
						}
						return 0;
					}
				}
			} elseif ($kind == $HcomCeasefire) {
				
				return 0;
			} else{
				
				if ($island['YU'][$target] > 2) {
					logMiss($id, $name, $comName, "{$tName}가 우호국의");
					return 0;
				} elseif ($island['warA'] > 0) {
					
					logMiss($id, $name, $comName, "선전포고를 할 수 있는 것은 1개국까지의");
					return 0;
				} elseif ($tIsland['warD'] > 1) {
					
					logMiss($id, $name, $comName, "$tName 구제의");
					return 0;
				}
				$island['warA']++;
				$tIsland['warD']++;
				$arg = $HislandTurn + $HdeclareTurn;
				hako_push($HwarIsland, $arg);
				hako_push($HwarIsland, $id);
				hako_push($HwarIsland, $target);
				hako_push($HwarIsland, 0);
				logOut("{$name}가{$tName}에{$HtagDisaster_}선전포고! {$H_tagDisaster}({$arg}턴에 개전)",$id, $target);
			}
		}
		return 0;
	} elseif ($kind == $HcomSell) {
		
		if ($arg == 0) { $arg = 1; }
		$value = min($arg * (-$cost), $island['food']);

		
		logSell($id, $name, $comName, "$value$HunitFood");
		$island['food'] -=  $value;
		$island['money'] += intval($value / 10);
		return 0;
	} elseif ($kind == $HcomSoldier2) {
		
		if ($island['soldier'] < 100) {
			
		} else{
			if ($arg == 0) { $arg = 1; }
			$arg = min($arg, intval($island['soldier'] / 100));

			
			logSell($id, $name, $comName, "$arg$HunitPop2");
			$island['soldier'] -=  $arg * 100;
			$island['money'] += $arg * $cost;
		}
		return 0;
	} elseif (($kind == $HcomFood) ||
		($kind == $HcomMoney) ||
		($kind == $HcomSoldier)) {
		
		
		$tn = $HidToNumber[$target];
		$tIsland =& $Hislands[$tn];
		$tName = $tIsland['name'];

		
		if ($arg == 0) { $arg = 1; }
		unset($value); $value = null;
		unset($str); $str = null;
		if ($island['aid'] > 0) {
			logMiss($id, $name, $comName, "1 턴내에 여러 차례 실행할 수 없다");
			return 0;
		} else{
			if ($kind == $HcomSoldier) {
				if ($arg > $HmaxAidSoldier) { $arg = $HmaxAidSoldier; }
				$value = min($arg, $island['soldier']);
				$str = "$value$HunitPop";
				if ($tIsland['soldier'] + $value > 0) {
					$tIsland['soldierex'] = intval(($tIsland['soldier'] * $tIsland['soldierex'] + $value * $island['soldierex']) / ($tIsland['soldier'] + $value));
				}
				$island['soldier'] -= $value;
				$tIsland['soldier'] += $value;
			} elseif ($cost < 0) {
				if ($island['food'] < $tIsland['food']) {
					logMiss($id, $name, $comName, "자국보다 많은 나라에는 원조할 수 없다");
					return 0;
				}
				if ($arg > $HmaxAidFood) { $arg = $HmaxAidFood; }
				$value = min($arg * (-$cost), $island['food']);
				$str = "$value$HunitFood";
				$island['food'] -= $value;
				$tIsland['food'] += $value;
			} else{
				if ($island['money'] < $tIsland['money']) {
					logMiss($id, $name, $comName, "자국보다 많은 나라에는 원조할 수 없다");
					return 0;
				}
				if ($arg > $HmaxAidMoney) { $arg = $HmaxAidMoney; }
				$value = min($arg * ($cost), $island['money']);
				$str = "$value$HunitMoney";
				$island['money'] -= $value;
				$tIsland['money'] += $value;
			}
		}
		
		logAid($id, $target, $name, $tName, $comName, $str);
		$island['aid'] = 1;
		return 0;
	} elseif ($kind == $HcomPropaganda) {
		
		logPropaganda($id, $name, $comName);
		$island['propaganda'] = 1;
		$island['money'] -= $cost;
		if ($arg > 1) {
			$arg--;
			slideBack($comArray, 0, $kind, $target, $x, $y, $arg);
		}
		return 1;
	} elseif ($kind == $HcomGiveup) {
		
		if ($island['aid'] + $island['cession'] > 0) {
			logMiss($id, $name, $comName, "원조계와 동시에 실행할 수 없다");
			return 0;
		}
		logGiveup($id, $name);
		$island['dead'] = 1;
		@unlink("island.$id");
		return 1;
	}

	return 1;

}
}


/*
 * 함수: doEachHex()
 * 역할: 각 좌표의 지형별 자연 변화와 주변 영향 처리를 수행합니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function doEachHex(&$island) {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $monsterMove, $id, $name, $pop1, $pop2, $pop3, $x, $y, $i, $HpointNumber, $Hrpx, $Hrpy, $landKind, $Hland, $lv, $HlandValue, $tId, $HlandOwner, $HfirstFlg, $HlandMonument, $HlandTown, $HlandForest, $HlandBase, $HlandDefence;
    global $HlandSupply, $HlandWaste, $HlandPlains, $HlandSbase, $HlandSea, $HlandMonster, $addpop, $addpop2, $addpop3, $HlandDivPw, $HlandDivNa, $r, $sx, $sy, $_, $Hrno6, $ax, $ay, $Hroundmode, $correct, $HislandSize, $HlandFarm, $tIsland, $Hislands;
    global $HidToNumber, $tName, $mKind, $mName, $mHp, $special, $HmonsterSpecial, $HdisapearMons, $HmonsterLevel1, $lName, $HislandTurn, $d, $HlandMountain, $l, $point, $HdBaseAuto, $disFire, $HdisFire, $HlandFactory;
$_args = func_get_args();
	unset($monsterMove); $monsterMove = array();

	
	$_list_tmp = array($island['id'],$island['name']);
	unset($id); $id = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
	unset($name); $name = isset($_list_tmp[1]) ? $_list_tmp[1] : null;

	
	$_list_tmp = array(10,2,0);
	unset($pop1); $pop1 = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
	unset($pop2); $pop2 = isset($_list_tmp[1]) ? $_list_tmp[1] : null;
	unset($pop3); $pop3 = isset($_list_tmp[2]) ? $_list_tmp[2] : null;
	if ($island['warP'] > $island['score']) {
		
		$_list_tmp = array(20,4,0);
		$pop1 = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
		$pop2 = isset($_list_tmp[1]) ? $_list_tmp[1] : null;
		$pop3 = isset($_list_tmp[2]) ? $_list_tmp[2] : null;
	}
	if ($island['food'] < 0) {
		
		$pop1 = -30;
	} elseif ((isset($island['propaganda']) ? $island['propaganda'] : 0) == 1) {
		
		$pop1 = 30;
		$pop2 = 6;
		$pop3 = 3;
	}
	
	unset($x); $x = null;
	unset($y); $y = null;
	unset($i); $i = null;
	for ($i = 0; $i < $HpointNumber; $i++) {
	$x = $Hrpx[$i];
	$y = $Hrpy[$i];
	$landKind = $Hland[$x][$y];
	$lv = $HlandValue[$x][$y];
	$tId = $HlandOwner[$x][$y];
	if ($tId != $id) {
		if (($HfirstFlg) && ($tId == 0)) {
			
			if (($landKind == $HlandMonument) ||
				($landKind == $HlandTown) ||
				($landKind == $HlandForest) ||
				($landKind == $HlandBase) ||
				($landKind == $HlandDefence) ||
				($landKind == $HlandSupply)) {
				
				$Hland[$x][$y] = $HlandWaste;
				$HlandValue[$x][$y] = 0;
			} elseif ($landKind == $HlandWaste) {
				
				if (random(10) == 0) {
					$Hland[$x][$y] = $HlandPlains;
					$HlandValue[$x][$y] = 0;
				}
			} elseif ($landKind == $HlandSbase) {
				$Hland[$x][$y] = $HlandSea;
				$HlandValue[$x][$y] = 0;
			}
			if ($landKind != $HlandMonster) { continue; }
		} else{
			continue;
		}
	}
	if ($landKind == $HlandTown) {
		
		$_list_tmp = array($pop1,$pop2,$pop3);
		unset($addpop); $addpop = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
		unset($addpop2); $addpop2 = isset($_list_tmp[1]) ? $_list_tmp[1] : null;
		unset($addpop3); $addpop3 = isset($_list_tmp[2]) ? $_list_tmp[2] : null;
		if (($HlandDivPw[$x][$y] > 49) && ($id != $HlandDivNa[$x][$y])) {
			
			$addpop = -4;
			$addpop2 = -8;
			$addpop3 = -12;
		}
		if ($addpop < 0) {
			
			$lv -= (random(-$addpop) + 1);
			if ($lv <= 0) {
				
				$Hland[$x][$y] = $HlandPlains;
				$HlandValue[$x][$y] = 0;
				return;
			}
		} else{
			
			if ($lv < 100) {
				$lv += random($addpop) + 1;
				if ($lv > 100) { $lv = 100; }
			} elseif ($lv < 160) {
				$lv += random($addpop2 + 1);
			} else{
				
				if ($addpop3 > 0) {
					$lv += random($addpop3) + 1;
				}
			}
		}
		if ($lv > 200) { $lv = 200; }
		$HlandValue[$x][$y] = $lv;
	} elseif ($landKind == $HlandPlains) {
		
		unset($r); $r = null;
		unset($sx); $sx = null;
		unset($sy); $sy = null;
		unset($tId); $tId = null;
		for ($_ = 1; $_ <= 2; $_++) {
		$r = $Hrno6[$_];
		$sx = $x + $ax[$r];
		$sy = $y + $ay[$r];
		if (!($sy % 2) && ($y % 2)) { $sx--; }
		if ($Hroundmode) {
			$sx = $correct[$sx + 12];
			$sy = $correct[$sy + 12];
		}
		if (($sx < 0) || ($sx >= $HislandSize) || ($sy < 0) || ($sy >= $HislandSize)) {
		} else{
			
			if (($HlandValue[$sx][$sy] != 1) &&
				(($Hland[$sx][$sy] == $HlandTown) || ($Hland[$sx][$sy] == $HlandFarm))) {
				

				$tId = $HlandOwner[$sx][$sy];
				if ($tId == 0) { break; }
				if (($HlandDivPw[$x][$y] > 0) && ($tId != $HlandDivNa[$x][$y])) { break; }
				$tIsland =& $Hislands[$HidToNumber[$tId]];
				if ($tId != $id) {
					
					if (($tIsland['YU'][$id] > 2) || (random(2) == 0)) { break; }
				}
				$tName = $tIsland['name'];
				logLandReclamation($id, $tId, $name, $tName, "($x, $y)", landName($landKind, $lv));
				$Hland[$x][$y] = $HlandTown;
				$HlandValue[$x][$y] = 1;
				$HlandOwner[$x][$y] = $tId;
				break;
			}
		}
		}
	} elseif ($landKind == $HlandWaste) {
		
		if (random(10) == 0) {
			$Hland[$x][$y] = $HlandPlains;
			$HlandValue[$x][$y] = 0;
		}
	} elseif ($landKind == $HlandForest) {
		
		if ($lv < 40) {
			
			$HlandValue[$x][$y]++;
		} elseif ($lv >= 40) {
			$island['money'] += 5 * $lv;
			$HlandValue[$x][$y] = 1;
			logAutoTree($id, $name);
		}
	} elseif ($landKind == $HlandMonster) {
		
		if ($monsterMove[$x][$y] == 2) {
			
			return;
		}

		
		$mKind = monsterSpec($HlandValue[$x][$y]);
		unset($mName); $mName = isset($_list_tmp[1]) ? $_list_tmp[1] : null;
		unset($mHp); $mHp = isset($_list_tmp[2]) ? $_list_tmp[2] : null;
		$special = $HmonsterSpecial[$mKind];


		if ((random(1000) < $HdisapearMons)) {
			
			if (($mKind != 0) && ($mKind <= $HmonsterLevel1)) {
				
				$mHp = 0;
			} else{
				$mHp--;
			}
			$lName = ($tId == 0) ? "중립 지대" : $name;
			if ($mHp > 0) {
				logMonsLost($HlandOwner[$x][$y], $HlandOwner[$x][$y], $lName, $mName, "($x, $y)", "육체가 쇠약해진 것 같습니다. ");
				$HlandValue[$x][$y]--;
			} else{
				logMonsLost($HlandOwner[$x][$y], $HlandOwner[$x][$y], $lName, $mName, "($x, $y)", "안개가운데에 사라졌습니다. ");
				$Hland[$x][$y] = $HlandWaste;
				$HlandValue[$x][$y] = 0;
				return;
			}
		}

		
		if ((($special == 3) && (($HislandTurn % 2) == 1)) ||
		   (($special == 4) && (($HislandTurn % 2) == 0))) {
			
			return;
		}

		
		unset($d); $d = null;
		unset($sx); $sx = null;
		unset($sy); $sy = null;
		unset($i); $i = null;
		for ($i = 0; $i < 6; $i++) {
			$d = random(6) + 1;
			$sx = $x + $ax[$d];
			$sy = $y + $ay[$d];
			if (!($sy % 2) && ($y % 2)) { $sx--; }
			if ($Hroundmode) {
				$sx = $correct[$sx + 12];
				$sy = $correct[$sy + 12];
			}
			
			if (($sx < 0) || ($sx >= $HislandSize) || ($sy < 0) || ($sy >= $HislandSize)) { continue; }
			
			if (($HlandOwner[$sx][$sy] != 0) && ($HlandOwner[$sx][$sy] == $HlandOwner[$x][$y])) { continue; }

			
			if (($Hland[$sx][$sy] != $HlandSea) &&
				($Hland[$sx][$sy] != $HlandSbase) &&
				($Hland[$sx][$sy] != $HlandMountain) &&
				($Hland[$sx][$sy] != $HlandMonument) &&
				($Hland[$sx][$sy] != $HlandMonster)) {
				if ($HlandDivPw[$sx][$sy] > 50) {
					$HlandDivPw[$sx][$sy] -= 50;
					logSoldierDamage($HlandDivNa[$sx][$sy], $sx , $sy, "괴수{$mName}의 공격", 50);
					continue;
				}

				break;
			}
		}

		
		if ($i == 6) { return; }

		
		$l = $Hland[$sx][$sy];
		$lv = $HlandValue[$sx][$sy];
		$tId = $HlandOwner[$sx][$sy];
		$name = ($tId == 0) ? '중립 지대' : $Hislands[$HidToNumber[$tId]]['name'];
		$lName = landName($l, $lv);
		$point = "($sx, $sy)";

		if ($HlandDivPw[$sx][$sy] > 0) {
			logSoldierDamage($HlandDivNa[$sx][$sy], $sx , $sy, "괴수{$mName}의 공격", 0);
		}

		
		$Hland[$sx][$sy] = $Hland[$x][$y];
		$HlandValue[$sx][$sy] = $HlandValue[$x][$y];
		$HlandOwner[$sx][$sy] = $HlandOwner[$x][$y];
		$HlandDivPw[$sx][$sy] = 0;

		
		$Hland[$x][$y] = $HlandWaste;
		$HlandValue[$x][$y] = 0;
		$HlandDivPw[$x][$y] = 0;

		
		if ($HmonsterSpecial[$mKind] == 2) {
			
		} elseif ($HmonsterSpecial[$mKind] == 1) {
			
			$monsterMove[$sx][$sy] = $monsterMove[$x][$y] + 1;
		} else{
			
			$monsterMove[$sx][$sy] = 2;
		}

		if (($l == $HlandDefence) && ($HdBaseAuto == 1)) {
			
			logMonsMoveDefence($tId, $HlandOwner[$x][$y], $name, $lName, $point, $mName);
			
			wideDamage($tId, $name, $sx, $sy);
		} else{
			
			logMonsMove($tId, $HlandOwner[$x][$y], $name, $lName, $point, $mName);
		}
	}
	
	if (($island['oldPop'] >= 1000) && ($island['warP'] < $island['score'] * 1.5)) {
		
		unset($disFire); $disFire = $HdisFire;
		if ($island['oldPop'] > 2000) {
			$disFire += intval(($island['oldPop'] - 2000) / 100);
		}
		if (($HlandDivPw[$x][$y] < 50) &&
			((($landKind == $HlandTown) && ($lv > 50)) ||
			($landKind == $HlandFactory))) {
			if (random(1000) < $disFire) {
				
				if ((countAround($x, $y, $HlandForest, 7) +
					countAround($x, $y, $HlandMonument, 7)) == 0) {
					
					logFire($id, $name, landName($Hland[$x][$y], $HlandValue[$x][$y]), "($x, $y)");
					$Hland[$x][$y] = $HlandWaste;
					$HlandValue[$x][$y] = 0;
					$HlandDivPw[$x][$y] = 0;
				}
			}
		}
	}

}
}


/*
 * 함수: doEachHex2()
 * 역할: 각 좌표의 추가 지형 변화/후처리를 수행합니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function doEachHex2() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $i, $id, $tId, $name, $tName, $x, $y, $landKind, $lv, $hgr, $div, $divpw, $HpointNumber, $Hrpx, $Hrpy, $HlandDivPw, $ForceFlgMove, $Hland, $HlandValue, $HlandOwner, $HlandHGr, $HlandDivNa, $HidToName, $lName;
    global $tn, $HidToNumber, $island, $Hislands, $ofname, $ofdirection, $oforder, $FoccupyFlg, $HlandDiv, $HlandResist, $HlandKeep, $sx, $sy, $flg;
$_args = func_get_args();
	
	unset($i); $i = null;
	unset($id); $id = null;
	unset($tId); $tId = null;
	unset($name); $name = null;
	unset($tName); $tName = null;
	unset($x); $x = null;
	unset($y); $y = null;
	unset($landKind); $landKind = null;
	unset($lv); $lv = null;
	unset($hgr); $hgr = null;
	unset($div); $div = null;
	unset($divpw); $divpw = null;
	for ($i = 0; $i < $HpointNumber; $i++) {
	$x = $Hrpx[$i];
	$y = $Hrpy[$i];
	if (($HlandDivPw[$x][$y] > 0) && ($ForceFlgMove[$x][$y] <= 1)) {
		


		$landKind = $Hland[$x][$y];
		$lv = $HlandValue[$x][$y];
		$tId = $HlandOwner[$x][$y];
		$hgr = $HlandHGr[$x][$y] - 1;		
		$divpw = $HlandDivPw[$x][$y];		
		$id = $HlandDivNa[$x][$y];		

		$name = $HidToName[$id];			
		$tName = $HidToName[$tId];			
		$lName = landName($landKind, $lv);

		$tn = $HidToNumber[$id];
		if (($tn === '' || $tn === null)) {
			
			$HlandDivPw[$x][$y] = 0;
			$ForceFlgMove[$x][$y] = 0;
			continue;
		}
		unset($island); $island =& $Hislands[$tn];
		unset($ofname); $ofname = $island['fleet'];
		unset($ofdirection); $ofdirection = $island['direction'];
		unset($oforder); $oforder = $island['order'];
		if ($island['predelete']) { continue; }
		
		if (($id != $tId) && ($FoccupyFlg[$HlandDiv[$x][$y]])) {
			
			if ($divpw < 50) {
				if ($FoccupyFlg[$HlandDiv[$x][$y]] == 2) {
					$HlandResist[$x][$y] -= 4;
				} else{
					$HlandResist[$x][$y] -= 1;
				}
			} elseif ($divpw < 100) {
				if ($FoccupyFlg[$HlandDiv[$x][$y]] == 2) {
					$HlandResist[$x][$y] -= 5;
				} else{
					$HlandResist[$x][$y] -= 2;
				}
			} elseif ($divpw < 200) {
				if ($FoccupyFlg[$HlandDiv[$x][$y]] == 2) {
					$HlandResist[$x][$y] -= 7;
				} else{
					$HlandResist[$x][$y] -= 4;
				}
			} else{
				if ($FoccupyFlg[$HlandDiv[$x][$y]] == 2) {
					$HlandResist[$x][$y] -= 8;
				} else{
					$HlandResist[$x][$y] -= 5;
				}
			}
			if ($HlandResist[$x][$y] < 1) {
				
				$HlandResist[$x][$y] = 10;
				logLandOccupy($tId, $id, $tName, $name, $x, $y, $lName, 1);
				$HlandOwner[$x][$y] = $id;
				$HlandKeep[$x][$y] = 0;
			}
		} elseif (($id == $tId) && ($FoccupyFlg[$HlandDiv[$x][$y]])) {
			
			if ($HlandResist[$x][$y] < 10) { $HlandResist[$x][$y] += 3; }
		}
		unset($sx); $sx = null;
		unset($sy); $sy = null;
		unset($flg); $flg = null;
		
		if (($oforder[$hgr] == 0) || ($oforder[$hgr] == 3)) {
			
			if (forceMov($island, $x, $y, 0, $ofdirection[$hgr])) {
				
				if ($oforder[$hgr] == 3) {
					
					$_list_tmp = forceMov($island, $x, $y, 2, $ofdirection[$hgr]);
					$sx = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
					$sy = isset($_list_tmp[1]) ? $_list_tmp[1] : null;
					$flg = isset($_list_tmp[2]) ? $_list_tmp[2] : null;
				} else{
					$_list_tmp = forceMov($island, $x, $y, 1, $ofdirection[$hgr]);
					$sx = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
					$sy = isset($_list_tmp[1]) ? $_list_tmp[1] : null;
					$flg = isset($_list_tmp[2]) ? $_list_tmp[2] : null;
				}
				$ForceFlgMove[$sx][$sy] += $flg; 
			}
		} elseif (($oforder[$hgr] == 1) || ($oforder[$hgr] == 2)) {
			
			$_list_tmp = forceMov($island, $x, $y, $oforder[$hgr], $ofdirection[$hgr]);
			$sx = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
			$sy = isset($_list_tmp[1]) ? $_list_tmp[1] : null;
			$flg = isset($_list_tmp[2]) ? $_list_tmp[2] : null;
			$ForceFlgMove[$sx][$sy] += $flg; 
			if ($flg == 10) {
				
				forceMov($island, $x, $y, 0, $ofdirection[$hgr]);
			}
		}
	}
	}
}


/*
 * 함수: forceMov()
 * 역할: 부대 이동을 처리합니다. ForceFlgMove 플래그와 좌표 인덱스가 연결됩니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function forceMov(&$island, $x=null, $y=null, $mode=null, $d=null) {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $name, $ofname, $point, $tId, $ax, $ay, $sx, $sy, $Hroundmode, $correct, $HislandSize, $HlandOwner, $HlandDivPw, $fmapmv, $FmapMove, $HlandDiv, $Hland, $FItemID, $HlandDivItem, $HlandSea, $HlandSbase, $FartilleryFlg, $Feemove;
    global $FnoZocFlg, $ct1, $ct2, $ct3, $ct4, $HtagName_, $H_tagName, $HlandHGr, $Fdivision, $HlandDivLv, $HlandDivEx, $HlandDivNa, $support, $range, $spoint, $_, $Hrno18, $Hrno6, $tName, $HidToName, $tIsland, $Hislands, $HidToNumber, $tOfname;
    global $tPoint, $tOforder, $dp, $aPt, $TaPt, $r, $unitPt, $FunitPt, $FmapPt, $logA, $logB, $ForceFlgMove, $HunitPop, $HtagDisaster_, $H_tagDisaster;
$_args = func_get_args();
	$_list_tmp = array($island['id'],$island['name'],$island['fleet']);
	unset($id); $id = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
	unset($name); $name = isset($_list_tmp[1]) ? $_list_tmp[1] : null;
	unset($ofname); $ofname = isset($_list_tmp[2]) ? $_list_tmp[2] : null;
	$point = "($x, $y)";
	unset($tId); $tId = null;
	if (($mode == 1) || ($mode == 2)) {
		
		$_list_tmp = array($x + $ax[$d],$y + $ay[$d]);
		unset($sx); $sx = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
		unset($sy); $sy = isset($_list_tmp[1]) ? $_list_tmp[1] : null;
		if (!($sy % 2) && ($y % 2)) { $sx--; }
		if ($Hroundmode) {
			$sx = $correct[$sx + 12];
			$sy = $correct[$sy + 12];
		}
		
		if (($sx < 0) || ($sx >= $HislandSize) || ($sy < 0) || ($sy >= $HislandSize)) { return array($x, $y, 1); }
			$tId = $HlandOwner[$sx][$sy];

		
		if (($mode == 2) && ($id != $tId)) {
			return array($x, $y, 2);
		}

		
		if ($HlandDivPw[$sx][$sy] > 0) {
			return array($x, $y, 10);
		}
		
		unset($fmapmv); $fmapmv = $FmapMove[$HlandDiv[$x][$y]][$Hland[$sx][$sy]];
		if ($FItemID[$HlandDivItem[$x][$y]] == 6) {
			
			if (($Hland[$sx][$sy] == $HlandSea) || ($Hland[$sx][$sy] == $HlandSbase)) { $fmapmv = 1; }
		}
		if (($fmapmv <= 0) || ($island['YU'][$tId] > 2)) {
			if ($FartilleryFlg[$HlandDiv[$x][$y]]) {
				
				return array($x, $y, 10);
			} else{
				return array($x, $y, 2);
			}
		}
		
		if (($id != $tId) && (chkWarIsland($id, $tId) != 2)) {
			return array($x, $y, 2);
		}
		
		if ($Feemove[$HlandDiv[$x][$y]] == 0) {
			if (($Hland[$x][$y] != $HlandSea) && ($Hland[$x][$y] != $HlandSbase)) {
				if (($id != $HlandOwner[$x][$y]) && ($id != $tId)) {
					return array($x, $y, 2);
				}
			}
		}
		
		if (($FnoZocFlg[$HlandDiv[$x][$y]] == 0) && ($FItemID[$HlandDivItem[$x][$y]] != 4)) {
			
			$ct1 = countAroundArmy($x, $y, $id, 7);
			unset($ct2); $ct2 = isset($_list_tmp[1]) ? $_list_tmp[1] : null;
			unset($ct3); $ct3 = isset($_list_tmp[2]) ? $_list_tmp[2] : null;
			unset($ct4); $ct4 = isset($_list_tmp[3]) ? $_list_tmp[3] : null;

			if ($ct4 > 0) {
				
				$_list_tmp = countAroundArmy($sx, $sy, $id, 7);
				$ct1 = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
				$ct2 = isset($_list_tmp[1]) ? $_list_tmp[1] : null;
				$ct3 = isset($_list_tmp[2]) ? $_list_tmp[2] : null;
				$ct4 = isset($_list_tmp[3]) ? $_list_tmp[3] : null;
				if ($ct4 > 0) {
					
					logForce($HtagName_ . $name . $point . $H_tagName . $ofname[$HlandHGr[$x][$y]-1] . " " . $Fdivision[$HlandDiv[$x][$y]] . "는, 이동처가 적ZOC 범위내이기 때문에 이동할 수 없다. ", $id, $tId);
					return array($x, $y, 2);
				}
			}
		}

		
			$HlandHGr[$sx][$sy] = $HlandHGr[$x][$y];
			$HlandDiv[$sx][$sy] = $HlandDiv[$x][$y];
			$HlandDivPw[$sx][$sy] = $HlandDivPw[$x][$y];
			$HlandDivLv[$sx][$sy] = $HlandDivLv[$x][$y];
			$HlandDivEx[$sx][$sy] = $HlandDivEx[$x][$y];
			$HlandDivNa[$sx][$sy] = $HlandDivNa[$x][$y];
			$HlandDivItem[$sx][$sy] = $HlandDivItem[$x][$y];
		$HlandDivPw[$x][$y] = 0;
		if ($fmapmv > 1) {
			
			return array($sx, $sy, 1);
		} else{
			return array($sx, $sy, 2);
		}
	} else{
		
		$support = 100;
		$range = 5;
		$spoint = 30;
		if ($FartilleryFlg[$HlandDiv[$x][$y]]) {
			
			$range = 17;
			$spoint = 15;
		}
		for ($_ = 0; $_ <= $range; $_++) {
			$d = ($FartilleryFlg[$HlandDiv[$x][$y]]) ? $Hrno18[$_] : $Hrno6[$_];
			$_list_tmp = array($x + $ax[$d],$y + $ay[$d]);
			unset($sx); $sx = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
			unset($sy); $sy = isset($_list_tmp[1]) ? $_list_tmp[1] : null;
			if (!($sy % 2) && ($y % 2)) { $sx--; }
			if ($Hroundmode) {
				$sx = $correct[$sx + 12];
				$sy = $correct[$sy + 12];
			}
			
			if (($sx < 0) || ($sx >= $HislandSize) || ($sy < 0) || ($sy >= $HislandSize)) { continue; }
			$tId = $HlandDivNa[$sx][$sy];
			if ($tId == $id) { $support += $spoint; } 
			if (($HlandDivPw[$sx][$sy] > 0) && ($tId != $id) && ($island['YU'][$tId] <= 2) && (chkWarIsland($id, $tId) == 2)) {
				
				$tName = $HidToName[$tId];
				$tIsland =& $Hislands[$HidToNumber[$tId]];
				$tOfname = $tIsland['fleet'];
				$tPoint = "($sx, $sy)";

				
				$tOforder = $tIsland['order'];
				unset($dp); $dp = ($tOforder[$HlandHGr[$sx][$sy]-1] == 3) ? 1 : 0;

				
				unset($aPt); $aPt = null;
				unset($TaPt); $TaPt = null;
				unset($r); $r = null;
				unset($unitPt); $unitPt = null;
				
				$r = $HlandDivEx[$x][$y];
				$aPt += (random($r) + $HlandDivPw[$x][$y]) / 10;
				$unitPt = $FunitPt[$HlandDiv[$x][$y]][$HlandDiv[$sx][$sy]] + $HlandDivLv[$x][$y] * 5;
				
				if (($unitPt > 10) && ($FItemID[$HlandDivItem[$sx][$sy]] == 3)) { $unitPt = 10; } 
				$aPt *= $unitPt / 10;

				
				$aPt = intval($aPt * ($support / 100));

				
				$aPt = intval($aPt * (($FmapPt[$HlandDiv[$sx][$sy]][$Hland[$sx][$sy]] - $dp) / 10));

				
				if ($FItemID[$HlandDivItem[$x][$y]] == 1) { $aPt += $aPt; } 
				if ($FItemID[$HlandDivItem[$sx][$sy]] == 2) { $aPt = int($aPt / 2); } 
				if ($aPt < 1) { $aPt = 1; }

				
				if ($HlandDivPw[$sx][$sy] < $aPt) { $aPt = $HlandDivPw[$sx][$sy]; }
				$island['attack'] += $aPt;
				$tIsland['damage'] += $aPt;

				$tIsland['soldierF'] += ($HlandDivPw[$sx][$sy] > $aPt) ? intval($aPt / 2) : intval($HlandDivPw[$sx][$sy] / 2);
				$HlandDivPw[$sx][$sy] -= $aPt;
				$HlandDivEx[$x][$y] += 3;
				unset($logA); $logA = $HtagName_ . $name . $point . $H_tagName . $ofname[$HlandHGr[$x][$y]-1] . " " . $Fdivision[$HlandDiv[$x][$y]];
				unset($logB); $logB = $HtagName_ . $tName . $tPoint . $H_tagName . $tOfname[$HlandHGr[$sx][$sy]-1] . " " . $Fdivision[$HlandDiv[$sx][$sy]];
				if ($HlandDivPw[$sx][$sy] < 1) {
					
					$HlandDivPw[$sx][$sy] = 0;
					$ForceFlgMove[$sx][$sy] = 0;
					if ($HlandDivItem[$sx][$sy] > 0) { $tIsland['item'][$HlandDivItem[$sx][$sy]]++; }
					$HlandDivEx[$x][$y] += 17;
					logForce("{$logA}가{$logB}에 공격해<B>부대를 소멸</B>시켰습니다. ",$id, $tId);
				} else{
					
					if (($FartilleryFlg[$HlandDiv[$x][$y]] == 2) || (($FartilleryFlg[$HlandDiv[$x][$y]]) && ($d > 6))) {
						
						logForce($logA . "가" . $logB . "에 공격해<B>" . $aPt . $HunitPop . "</B>를 사상시켰습니다. ",$id, $tId);
					} else{
						
						if ($ForceFlgMove[$sx][$sy] == 99) {
							
							$TaPt = 1;
						} else{
							$r = $HlandDivEx[$sx][$sy];
							$TaPt += (random($r) + $HlandDivPw[$sx][$sy]) / 20;
							$unitPt = $FunitPt[$HlandDiv[$sx][$sy]][$HlandDiv[$x][$y]] + $HlandDivLv[$sx][$sy] * 5;
							
							if (($unitPt > 10) && ($FItemID[$HlandDivItem[$x][$y]] == 3)) { $unitPt = 10; } 
							$TaPt *= $unitPt / 10;
							$TaPt = intval($TaPt * ($FmapPt[$HlandDiv[$x][$y]][$Hland[$x][$y]] / 10));
							if ($TaPt < 1) { $TaPt = 1; }

							
							if ($FItemID[$HlandDivItem[$sx][$sy]] == 1) { $TaPt += $TaPt; } 
							if ($FItemID[$HlandDivItem[$x][$y]] == 2) { $TaPt = int($TaPt / 2); } 
							if ($TaPt < 1) { $TaPt = 1; }
						}
						
						if ($HlandDivPw[$x][$y] < $TaPt) { $TaPt = $HlandDivPw[$x][$y]; }
						$island['damage'] += $TaPt;
						$tIsland['attack'] += $TaPt;

						$island['soldierF'] += ($HlandDivPw[$x][$y] > $TaPt) ? intval($TaPt / 2) : intval($HlandDivPw[$x][$y] / 2);
						$HlandDivPw[$x][$y] -= $TaPt;
						$HlandDivEx[$sx][$sy] += 2;
						if ($HlandDivPw[$x][$y] < 1) {
							
							$HlandDivPw[$x][$y] = 0;
							$ForceFlgMove[$x][$y] = 0;
							if ($HlandDivItem[$x][$y] > 0) { $island['item'][$HlandDivItem[$x][$y]]++; }
							$HlandDivEx[$sx][$sy] += 15;
							logForce($logA . "가" . $logB . "에 공격해<B>" . $aPt . $HunitPop . "</B>를 사상시켰습니다만, 반격으로<B>부대가 소멸</B>했습니다. ",$id, $tId);
						} else{
							logForce($logA . "가" . $logB . "에 공격해<B>" . $aPt . $HunitPop . "</B>를 사상시켰습니다만, 반격으로" . $HtagDisaster_ . $TaPt . $HunitPop . $H_tagDisaster . "가 사상했습니다. ",$id, $tId);
						}
					}
				}
				return 0;
			}
		}
		return 1;
	}
}


/*
 * 함수: doIslandProcess()
 * 역할: 섬 하나의 턴 처리를 수행합니다. 수입, 명령, 재해, 로그가 여기서 이어집니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function doIslandProcess(&$island) {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $name, $id, $x, $y, $i, $j, $sx, $sy, $landKind, $lv, $tId, $HpointNumber, $Hrpx, $Hrpy, $Hland, $HlandValue, $HlandOwner, $HlandTown, $ax, $ay, $Hroundmode, $correct, $HislandSize, $tName;
    global $HidToName, $HlandDivPw, $HlandFarm, $HlandFactory, $HlandBase, $HlandDefence, $HlandSupply, $HlandWaste, $r, $area, $HdisMonster, $HdisMonsBorder1, $kind, $HdisMonsBorder3, $HmonsterLevel3, $HdisMonsBorder2, $HmonsterLevel2, $HmonsterLevel1, $HmonsterBHP, $HmonsterDHP, $lName, $HlandMonster;
$_args = func_get_args();

	$name = $island['name'];
	$id = $island['id'];

	
	if ($island['food'] <= 0) {
		
		logStarve($id, $name);
		$island['food'] = 0;
		unset($x); $x = null;
		unset($y); $y = null;
		unset($i); $i = null;
		unset($j); $j = null;
		unset($sx); $sx = null;
		unset($sy); $sy = null;
		unset($landKind); $landKind = null;
		unset($lv); $lv = null;
		unset($tId); $tId = null;
		for ($j = 0; $j < $HpointNumber; $j++) {
			$x = $Hrpx[$j];
			$y = $Hrpy[$j];
			$landKind = $Hland[$x][$y];
			$lv = $HlandValue[$x][$y];
			$tId = $HlandOwner[$x][$y];
			if (($landKind != $HlandTown) || ($tId != $id)) { continue; }
			logStarveRiot($id, $name, "($x, $y)", landName($landKind, $lv));
			for ($i = 0; $i < 19; $i++) {
				$sx = $x + $ax[$i];
				$sy = $y + $ay[$i];
				if (!($sy % 2) && ($y % 2)) { $sx--; }
				if ($Hroundmode) {
					$sx = $correct[$sx + 12];
					$sy = $correct[$sy + 12];
				}
				if (($sx < 0) || ($sx >= $HislandSize) || ($sy < 0) || ($sy >= $HislandSize)) {
				} else{
					
					$landKind = $Hland[$sx][$sy];
					$lv = $HlandValue[$sx][$sy];
					$tId = $HlandOwner[$sx][$sy];
					$tName = $HidToName[$tId];
					if ($HlandDivPw[$x][$y] >= 50) {
						
					} elseif (($landKind == $HlandFarm) || ($landKind == $HlandFactory) || ($landKind == $HlandBase) || ($landKind == $HlandDefence) || ($landKind == $HlandSupply)) {
						
						if (random(4) == 0) {
							if (($tId != $id) && ($i > 6)) { continue; }
							logSvDamage($id, $tId, $name, $tName, landName($landKind, $lv), "($sx, $sy)");
							$Hland[$sx][$sy] = $HlandWaste;
							$HlandValue[$sx][$sy] = 0;
							$HlandDivPw[$sx][$sy] = 0;
						}
					}
				}
			}
		}
	}

	
	unset($r); $r = random(10000);
	unset($area); $area = $island['area'];
	do {
	if ((($r < ($HdisMonster * $island['area'])) && ($area >= $HdisMonsBorder1) && ($island['warP'] < $island['score'] * 1.5)) ||
	    (isset($island['monstersend']) && count($island['monstersend']) > 0)) {
		
		$tId = 0;

		
		unset($lv); $lv = null;
		unset($kind); $kind = null;
		if (isset($island['monstersend']) && count($island['monstersend']) > 0) {
			
			$kind = 0;
			$tId = array_pop($island['monstersend']);
		} elseif ($area >= $HdisMonsBorder3) {
			
			$kind = random($HmonsterLevel3) + 1;
		} elseif ($area >= $HdisMonsBorder2) {
			
			$kind = random($HmonsterLevel2) + 1;
		} else{
			
			$kind = random($HmonsterLevel1) + 1;
		}

		
		$lv = $kind * 10 + $HmonsterBHP[$kind] + random($HmonsterDHP[$kind]);

		
		unset($sx); $sx = null;
		unset($sy); $sy = null;
		unset($i); $i = null;
		for ($i = 0; $i < $HpointNumber; $i++) {
			$sx = $Hrpx[$i];
			$sy = $Hrpy[$i];

			if ($Hland[$sx][$sy] == $HlandTown) {
				if ($HlandOwner[$sx][$sy] != $id) { continue; }

				
				$lName = landName($HlandTown, $HlandValue[$sx][$sy]);
				$name = $HidToName[$HlandOwner[$sx][$sy]];

				
				$Hland[$sx][$sy] = $HlandMonster;
				$HlandValue[$sx][$sy] = $lv;
				$HlandOwner[$sx][$sy] = 0;
				$HlandDivPw[$sx][$sy] = 0;

				
				$__monster_spec = monsterSpec($lv);
					logMonsCome($id, $HlandOwner[$sx][$sy], $name, isset($__monster_spec[1]) ? $__monster_spec[1] : '', "($sx, $sy)", $lName);
					unset($__monster_spec);
				break;
			}
		}
	}
	} while(isset($island['monstersend']) && count($island['monstersend']) > 0);

	
	while ((isset($island['bigmissile']) ? $island['bigmissile'] : 0) > 0) {
		$island['bigmissile'] --;

		unset($x); $x = null;
		unset($y); $y = null;
		unset($tId); $tId = null;
		unset($tName); $tName = null;

		
		$x = random($HislandSize);
		$y = random($HislandSize);
		$tId = $HlandOwner[$x][$y];
		$tName = $HidToName[$tId];

		
		logMonDamage($tId, $tName, "($x, $y)");

		
		wideDamage($tId, $tName, $x, $y);
	}
}


/*
 * 함수: doIslandProcess2()
 * 역할: 섬별 턴 처리 2단계입니다. 전역 이벤트와 후처리 흐름에 연결됩니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function doIslandProcess2() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $i, $id, $tId, $name, $tName, $x, $y, $sx, $sy, $landKind, $lv, $HdisEarthquake, $HislandSize, $HlandOwner, $HidToName, $Hislands, $Hland, $HlandSea, $HdisTsunami, $ax, $ay, $Hroundmode, $correct, $HlandValue;
    global $HlandTown, $HlandSupply, $HlandFarm, $HlandFactory, $HlandBase, $HlandDefence, $HlandWaste, $HlandDivPw, $HdisEruption, $HlandMountain, $HpointNumber, $Hrpx, $Hrpy, $HlandSbase, $HdisHugeMeteo, $HdisNoMeteoTurn, $HislandTurn, $HdisMeteo, $first, $point, $lName, $HlandMonster;
$_args = func_get_args();
	unset($i); $i = null;
	unset($id); $id = null;
	unset($tId); $tId = null;
	unset($name); $name = null;
	unset($tName); $tName = null;
	unset($x); $x = null;
	unset($y); $y = null;
	unset($sx); $sx = null;
	unset($sy); $sy = null;
	unset($landKind); $landKind = null;
	unset($lv); $lv = null;
	
	if (random(1000) < $HdisEarthquake) {
		
		$x = random($HislandSize);
		$y = random($HislandSize);
		$id = $HlandOwner[$x][$y];
		$name = $HidToName[$id];
		if ($Hislands[$id]['warP'] < $Hislands[$id]['score'] * 1.5) {
			
			if ($Hland[$x][$y] == $HlandSea) {
				
				$HdisTsunami = 500;
			}
			logEarthquake($id, $name, "($x, $y)");
			for ($i = 0; $i < 19; $i++) {
				$sx = $x + $ax[$i];
				$sy = $y + $ay[$i];
				if (!($sy % 2) && ($y % 2)) { $sx--; }
				if ($Hroundmode) {
					$sx = $correct[$sx + 12];
					$sy = $correct[$sy + 12];
				}
				if (($sx < 0) || ($sx >= $HislandSize) || ($sy < 0) || ($sy >= $HislandSize)) { continue; }
				
				$landKind = $Hland[$sx][$sy];
				$lv = $HlandValue[$sx][$sy];
				$tId = $HlandOwner[$sx][$sy];
				$tName = $HidToName[$tId];

				if (($landKind == $HlandTown) ||
					($landKind == $HlandSupply) ||
					($landKind == $HlandFarm) ||
					($landKind == $HlandFactory) ||
					($landKind == $HlandBase) ||
					($landKind == $HlandDefence)) {
					
					if (random(4) == 0) {
						logDamage($id, $tId, $name, $tName, landName($landKind, $lv), "($sx, $sy)","지진");
						$Hland[$sx][$sy] = $HlandWaste;
						$HlandValue[$sx][$sy] = 0;
						$HlandDivPw[$sx][$sy] = 0;
					}
				}
			}
		}
	}
	
	if (random(1000) < $HdisEruption) {
		$x = random($HislandSize);
		$y = random($HislandSize);
		$id = $HlandOwner[$x][$y];
		$name = $HidToName[$id];
		if ($Hislands[$id]['warP'] < $Hislands[$id]['score'] * 1.5) {
			
			if ($Hland[$x][$y] == $HlandSea) {
				
				$HdisTsunami = 500;
			}
			logEruption($id, $name, landName($Hland[$x][$y], $HlandValue[$x][$y]), "($x, $y)");
			$Hland[$x][$y] = $HlandMountain;
			$HlandValue[$x][$y] = 0;
			$HlandDivPw[$x][$y] = 0;
		}
	}
	
	if (random(1000) < $HdisTsunami) {
		
		if ($HdisTsunami == 500) {
			
		} else{
			for ($i = 0; $i < $HpointNumber; $i++) {
				$x = $Hrpx[$i];
				$y = $Hrpy[$i];
				if ($Hland[$x][$y] == $HlandSea) { break; }
			}
		}
		$id = $HlandOwner[$x][$y];
		if (($i < $HpointNumber) && ($Hislands[$id]['warP'] < $Hislands[$id]['score'] * 1.5)) {
			
			$name = $HidToName[$id];
			logTsunami($id, $name, "($x, $y)");
			for ($i = 0; $i < 19; $i++) {
				$sx = $x + $ax[$i];
				$sy = $y + $ay[$i];
				if (!($sy % 2) && ($y % 2)) { $sx--; }
				if ($Hroundmode) {
					$sx = $correct[$sx + 12];
					$sy = $correct[$sy + 12];
				}
				
				if (($sx < 0) || ($sx >= $HislandSize) || ($sy < 0) || ($sy >= $HislandSize)) { continue; }

				$landKind = $Hland[$sx][$sy];
				$lv = $HlandValue[$sx][$sy];
				$tId = $HlandOwner[$sx][$sy];
				$tName = $HidToName[$tId];

				if (($landKind == $HlandTown) ||
					($landKind == $HlandSupply) ||
					($landKind == $HlandFarm) ||
					($landKind == $HlandFactory) ||
					($landKind == $HlandBase) ||
					($landKind == $HlandDefence)) {
					
					if (random(12) < (
						countAround($sx, $sy, $HlandSbase, 7) +
						countAround($sx, $sy, $HlandSea, 7) - 1)) {
						logDamage($id, $tId, $name, $tName, landName($landKind, $lv), "($sx, $sy)","해일");
						$Hland[$sx][$sy] = $HlandWaste;
						$HlandValue[$sx][$sy] = 0;
						$HlandDivPw[$sx][$sy] = 0;
					}
				}
			}
		}
	}

	
	if ((random(1000) < $HdisHugeMeteo) && ($HdisNoMeteoTurn < $HislandTurn)) {
		$x = random($HislandSize);
		$y = random($HislandSize);
		$id = $HlandOwner[$x][$y];
		if ($Hislands[$id]['warP'] < $Hislands[$id]['score'] * 1.5) {
			
			$name = $HidToName[$id];
			logHugeMeteo($id, $name, "($x, $y)");
			
			wideDamage($id, $name, $x, $y);
		}
	}

	
	if ((random(1000) < $HdisMeteo) && ($HdisNoMeteoTurn < $HislandTurn)) {
		unset($first); $first = 1;
		while ((random(2) == 0) || ($first == 1)) {
			$first = 0;
			
			$x = random($HislandSize);
			$y = random($HislandSize);
			$landKind = $Hland[$x][$y];
			$lv = $HlandValue[$x][$y];
			$id = $HlandOwner[$x][$y];
			$name = $HidToName[$id];
			$point = "($x, $y)";
			$lName = landName($landKind, $lv);
			if ($Hislands[$id]['warP'] < $Hislands[$id]['score'] * 1.5) {
				
				continue;
			}
			
			$HlandDivPw[$x][$y] = 0;
			if (($landKind == $HlandSea) && ($lv == 0)) {
				
				logMeteo($id, $name, landName($landKind, $lv), $point, "했습니다");
			} elseif ($landKind == $HlandMountain) {
				
				logMeteo($id, $name, landName($landKind, $lv), $point, "、<B>$lName</B>는 날아가 버렸습니다");
				$Hland[$x][$y] = $HlandWaste;
				$HlandValue[$x][$y] = 0;
				continue;
			} elseif ($landKind == $HlandSbase) {
				logMeteo($id, $name, landName($landKind, $lv), $point, "、<B>$lName</B>는 붕괴했습니다");
			} elseif ($landKind == $HlandMonster) {
				logMeteo($id, $name, "괴수$lName" , $point, "、육지는<B>$lName</B>와 같이 수몰 했습니다");
			} elseif ($landKind == $HlandSea) {
				
				logMeteo($id, $name, $lName, $point, "、해저가 꾸물거려졌습니다");
			} else{
				logMeteo($id, $name, $lName, $point, "、일대가 수몰 했습니다");
			}
			$Hland[$x][$y] = $HlandSea;
			$HlandValue[$x][$y] = 0;
		}
	}
}


/*
 * 함수: doIslandProcess3()
 * 역할: 섬별 턴 처리 3단계입니다. 최종 저장 전 누적값과 상태를 정리합니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function doIslandProcess3(&$island) {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $name, $id, $po, $mo, $fo, $so, $ak, $da, $f, $MaxFood, $MaxMoney, $FItemName, $HunitPop, $HtagDisaster_, $H_tagDisaster, $HunitMoney, $HunitFood, $Hnoarmy, $pop, $damage, $prize, $flags, $monsters, $turns;
    global $Hprize;
$_args = func_get_args();

	if (($island['soldier'] > 0) && (random(3) == 0)) {
		$island['soldierex']++;
	}

	
	$name = $island['name'];
	$id = $island['id'];
	unset($po); $po = null;
	unset($mo); $mo = null;
	unset($fo); $fo = null;
	unset($so); $so = null;
	unset($ak); $ak = null;
	unset($da); $da = null;
	unset($f); $f = null;
	
	if ($island['soldier2'] > 0) {
		$island['soldierex'] = intval(($island['soldier'] * $island['soldierex']) / ($island['soldier'] + $island['soldier2']));
		$island['soldier'] += $island['soldier2'];
	}

	
	if ($island['soldierF'] < 10) {
		$island['soldier'] += $island['soldierF'];
		$island['soldierF'] = 0;
	} else{
		if ($island['warP'] > $island['score']) {
			
			$f = intval($island['soldierF'] / 8);
		} else{
			$f = intval($island['soldierF'] / 20);
		}
		if ($f > 10) {
			$island['soldier'] += $f;
			$island['soldierF'] -= $f;
		} else{
			$island['soldier'] += 10;
			$island['soldierF'] -= 10;
		}
	}

	$mo = $island['money'] - $island['oldmoney'];
	$fo = $island['food'] - $island['oldfood'];

	
	if ($island['food'] > $MaxFood) {
		$island['money'] += intval(($island['food'] - $MaxFood) / 10);
		$island['food'] = $MaxFood;
	}

	
	if ($island['food'] < 1000) {
		$island['soldierF'] = 0;
	}

	
	if ($island['money'] > $MaxMoney) {
		$island['money'] = $MaxMoney;
	}
	
	if (!isset($island['statistical']) || !is_array($island['statistical'])) { $island['statistical'] = array(); }
	if (!isset($island['statistical'][1])) { $island['statistical'][1] = 0; }
	if (!isset($island['statistical'][2])) { $island['statistical'][2] = 0; }
	if (!isset($island['attack'])) { $island['attack'] = 0; }
	if (!isset($island['damage'])) { $island['damage'] = 0; }
	$island['statistical'][1] = intval($island['statistical'][1]) + intval($island['attack']);
	$island['statistical'][2] = intval($island['statistical'][2]) + intval($island['damage']);

	
	if (!isset($island['attackA'])) { $island['attackA'] = 0; }
		if (intval($island['attackA'] % 2000) + intval($island['attack']) >= 2000) {
		$island['item'][7]++;
		logPrizeV($island['id'], $island['name'], $FItemName[7]);
	}
	$island['attackA'] += $island['attack'];
	$island['damageA'] += $island['damage'];

	
	estimate($island,0);

	
	$po = $island['pop'] - $island['oldPop'];
	if ($po > 0) {
		$po = "{$po}{$HunitPop}";
	} elseif ($po == 0) {
		$po = "증감 없음";
	} else{
		$po = "{$HtagDisaster_}{$po}{$HunitPop}{$H_tagDisaster}";
	}
	if ($mo > 0) {
		$mo = "{$mo}{$HunitMoney}";
	} elseif ($mo == 0) {
		$mo = "증감 없음";
	} else{
		$mo = "{$HtagDisaster_}{$mo}{$HunitMoney}{$H_tagDisaster}";
	}
	if ($fo > 0) {
		$fo = "{$fo}{$HunitFood}";
	} elseif ($fo == 0) {
		$fo = "증감 없음";
	} else{
		$fo = "{$HtagDisaster_}{$fo}{$HunitFood}{$H_tagDisaster}";
	}
	$so = $island['sol'] - $island['oldSoldier'];
	if ($so > 0) {
		$so = "{$so}{$HunitPop}";
	} elseif ($so == 0) {
		$so = "증감 없음";
	} else{
		$so = "{$HtagDisaster_}{$so}{$HunitPop}{$H_tagDisaster}";
	}
	
	if ($island['attack'] > 0) {
		$ak = "{$island['attack']}[$HunitPop]";
	} else{
		$ak = "없음";
	}
	
	if ($island['damage'] > 0) {
		$da = "{$HtagDisaster_}{$island['damage']}[$HunitPop]{$H_tagDisaster}";
	} else{
		$da = "없음";
	}

	if ($Hnoarmy) {
		
		logSecret("인구<B>$po</B> 총병력<B>$so</B> 전과<B>$ak</B> 손해<B>$da</B> 자금<B>$mo</B> 식량<B>$fo</B> ",$id);
	} else{
		logSecret("인구<B>$po</B> 자금<B>$mo</B> 식량<B>$fo</B> ",$id);
	}

	
	$pop = $island['pop'];
	unset($damage); $damage = ($island['oldPop'] + $island['oldSoldier']) - ($pop + $island['sol']);
	$prize = $island['prize'];
	hako_regex('~([0-9]*),([0-9]*),(.*)~', $prize);
	$flags = hako_m(1);
	$monsters = hako_m(2);
	$turns = hako_m(3);

	
	if ((!($flags & 1)) &&  $pop >= 3000) {
		$flags |= 1;
		logPrize($id, $name, $Hprize[1]);
	} elseif ((!($flags & 2)) &&  $pop >= 5000) {
		$flags |= 2;
		logPrize($id, $name, $Hprize[2]);
	} elseif ((!($flags & 4)) &&  $pop >= 10000) {
		$flags |= 4;
		logPrize($id, $name, $Hprize[3]);
	}

	
	if ((!($flags & 64)) &&  $damage >= 500) {
		$flags |= 64;
		logPrize($id, $name, $Hprize[7]);
		$island['food'] += 1000;
	} elseif ((!($flags & 128)) &&  $damage >= 1000) {
		$flags |= 128;
		logPrize($id, $name, $Hprize[8]);
		$island['food'] += 2000;
	} elseif ((!($flags & 256)) &&  $damage >= 2000) {
		$flags |= 256;
		logPrize($id, $name, $Hprize[9]);
		$island['food'] += 3000;
	}

	$island['prize'] = "$flags,$monsters,$turns";
}


/*
 * 함수: islandSort()
 * 역할: 섬 목록을 원본 정렬 기준에 맞춰 정렬합니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function islandSort() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $flag, $i, $tmp, $idx, $Hislands, $Hislands2;
$_args = func_get_args();
	unset($flag); $flag = null;
	unset($i); $i = null;
	unset($tmp); $tmp = null;

	
	unset($idx); $idx = hako_sort_indices_desc_path($Hislands, array('popsol'));

	$Hislands2 = $Hislands;
	$Hislands = hako_permute($Hislands, $idx);
}


/*
 * 함수: wideDamage()
 * 역할: 지진/해일/운석/화산 등 광역 피해를 지정 범위에 적용합니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function wideDamage() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $name, $x, $y, $mode, $sx, $sy, $i, $landKind, $landName, $tId, $point, $ax, $ay, $Hroundmode, $correct, $HislandSize, $Hland, $HlandOwner, $HlandValue, $HidToName, $HlandDivPw, $tn, $HidToNumber;
    global $HlandDivNa, $island, $Hislands, $HlandDivItem, $HlandSea, $HlandSbase, $HlandMonster, $HlandWaste, $HlandMountain;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($name); $name = isset($_args[1]) ? $_args[1] : null;
	unset($x); $x = isset($_args[2]) ? $_args[2] : null;
	unset($y); $y = isset($_args[3]) ? $_args[3] : null;
	unset($mode); $mode = isset($_args[4]) ? $_args[4] : null;
	unset($sx); $sx = null;
	unset($sy); $sy = null;
	unset($i); $i = null;
	unset($landKind); $landKind = null;
	unset($landName); $landName = null;
	unset($tId); $tId = null;
	unset($point); $point = null;

	for ($i = 0; $i < 19; $i++) {
		$sx = $x + $ax[$i];
		$sy = $y + $ay[$i];
		if (!($sy % 2) && ($y % 2)) { $sx--; }
		if ($Hroundmode) {
			$sx = $correct[$sx + 12];
			$sy = $correct[$sy + 12];
		}
		if (($sx < 0) || ($sx >= $HislandSize) || ($sy < 0) || ($sy >= $HislandSize)) { continue; }

		$landKind = $Hland[$sx][$sy];
		$tId = $HlandOwner[$sx][$sy];
		$landName = landName($landKind, $HlandValue[$sx][$sy]);
		$point = "($sx, $sy)";
		$name = $HidToName[$tId];
		$id = $tId;

		if ($mode) {
			
			if ($HlandDivPw[$sx][$sy] > 0) {
				$tn = $HidToNumber[$HlandDivNa[$sx][$sy]];
				if (($tn !== '' && $tn !== null)) {
					unset($island); $island =& $Hislands[$tn];
					$island['soldier'] += $HlandDivPw[$sx][$sy];
					if ($HlandDivItem[$sx][$sy] > 0) { $island['item'][$HlandDivItem[$sx][$sy]]++; }
					logLandSuc($HlandDivNa[$sx][$sy], $HlandOwner[$sx][$sy], $island['name'], $HidToName[$HlandOwner[$sx][$sy]], "긴급 이탈", "($sx, $sy)");
				}
				$HlandDivPw[$sx][$sy] = 0;
			}
		} else{
			$HlandDivPw[$sx][$sy] = 0;
		}

		
		if ($i < 7) {
			
			$HlandOwner[$sx][$sy] = 0;
			if ($landKind == $HlandSea) {
				$HlandValue[$sx][$sy] = 0;
				continue;
			} elseif ($landKind == $HlandSbase) {
				logWideDamageSea2($id, $tId, $name, $landName, $point);
				$Hland[$sx][$sy] = $HlandSea;
				$HlandValue[$sx][$sy] = 0;
			} else{
				if ($landKind == $HlandMonster) {
					logWideDamageMonsterSea($id, $tId, $name, $landName, $point);
				} else{
					logWideDamageSea($id, $tId, $name, $landName, $point);
				}
				$Hland[$sx][$sy] = $HlandSea;
				if ($i == 0) {
					
					$HlandValue[$sx][$sy] = 0;
				} else{
					
					$HlandValue[$sx][$sy] = 1;
				}
			}
		} else{
			
			if (($landKind == $HlandSea) ||
				($landKind == $HlandWaste) ||
				($landKind == $HlandMountain) ||
				($landKind == $HlandSbase)) {
				continue;
			} elseif ($landKind == $HlandMonster) {
				logWideDamageMonster($id, $tId, $name, $landName, $point);
				$Hland[$sx][$sy] = $HlandWaste;
				$HlandValue[$sx][$sy] = 0;
			} else{
				logWideDamageWaste($id, $tId, $name, $landName, $point);
				$Hland[$sx][$sy] = $HlandWaste;
				$HlandValue[$sx][$sy] = 0;
			}
		}
	}
}


/*
 * 함수: logMatome()
 * 역할: 동일 종류 로그를 묶어 요약 출력합니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logMatome() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $island, $flag, $kind, $sno, $m, $i, $sArray, $spnt, $x, $y, $z, $point, $ptn;
$_args = func_get_args();
	unset($island); $island = isset($_args[0]) ? $_args[0] : null;
	unset($flag); $flag = isset($_args[1]) ? $_args[1] : null;
	unset($kind); $kind = isset($_args[2]) ? $_args[2] : null;
	unset($sno); $sno = null;
	unset($m); $m = null;
	unset($i); $i = null;
	unset($sArray); $sArray = null;
	unset($spnt); $spnt = null;
	unset($x); $x = null;
	unset($y); $y = null;
	unset($z); $z = null;
	unset($point); $point = null;
	unset($ptn); $ptn = array("정지","징병","정지, 징병","부대 설치","정지, 부대 설치","징병, 부대 설치","정지, 징병, 부대 설치");
	$sno = $island[$kind];
	$point = "";
	if ($sno > 0) {
		if ($flag == 1) {
			$kind .= 'pnt';
			$sArray = $island[$kind];
			for ($i = 0; $i < $sno; $i++) {
				$spnt = $sArray[$i];
				if ($spnt == "") { break; }
				$_list_tmp = array($spnt['x'], $spnt['y'], $spnt['z']);
				$x = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
				$y = isset($_list_tmp[1]) ? $_list_tmp[1] : null;
				$z = isset($_list_tmp[2]) ? $_list_tmp[2] : null;
				if ($z == '정지') {
					$point .= " 정($x, $y)";
					if (!($m & 1)) { $m |= 1; }
				} elseif ($z == '징병') {
					$point .= " 징병($x, $y)";
					if (!($m & 2)) { $m |= 2; }
				} elseif ($z == '설치') {
					$point .= " 설치($x, $y)";
					if (!($m & 4)) { $m |= 4; }
				} else{
					$point .= "($x, $y)";
				}
				if (!(($i + 1) % 20)) { $point .= "<br>　　　"; }
			}
		}
		if ($i > 1 || $flag != 1) { $point .= "의<B>$sno 개소</B>"; }
	}
	if (!($point == "")) {
		if (($flag == 1) && ($m > 0)) {
			logLandSucMatome($island['id'], $island['name'], $ptn[$m-1], "$point");
		} else{
			logLandSuc($island['id'], $island['id'], $island['name'], $island['name'], $z, "($x, $y)");
		}
	}
}







/*
 * 함수: logOut()
 * 역할: 일반 로그를 현재 턴 로그에 추가합니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logOut() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $msg, $id1, $id2, $id3, $HlogPool, $HislandTurn;
$_args = func_get_args();
	$msg = isset($_args[0]) ? $_args[0] : null;
	$id1 = isset($_args[1]) ? $_args[1] : null;
	$id2 = isset($_args[2]) ? $_args[2] : null;
	$id3 = isset($_args[3]) ? $_args[3] : null;
	hako_push($HlogPool, "0,$HislandTurn,$id1,$id2,$id3,$msg");
}


/*
 * 함수: logOut2()
 * 역할: 관리/비공개 계열 로그를 추가합니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logOut2() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $msg, $id1, $id2, $id3, $HlogPool, $HislandTurn;
$_args = func_get_args();
	$msg = isset($_args[0]) ? $_args[0] : null;
	$id1 = isset($_args[1]) ? $_args[1] : null;
	$id2 = isset($_args[2]) ? $_args[2] : null;
	$id3 = isset($_args[3]) ? $_args[3] : null;
	hako_push($HlogPool, "9,$HislandTurn,$id1,$id2,$id3,$msg");
}


/*
 * 함수: logForce()
 * 역할: 부대 관련 로그를 추가합니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logForce() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $msg, $id1, $id2, $id3, $HforceLogPool, $HislandTurn;
$_args = func_get_args();
	$msg = isset($_args[0]) ? $_args[0] : null;
	$id1 = isset($_args[1]) ? $_args[1] : null;
	$id2 = isset($_args[2]) ? $_args[2] : null;
	$id3 = isset($_args[3]) ? $_args[3] : null;
	hako_push($HforceLogPool, "2,$HislandTurn,$id1,$id2,$id3,$msg");
}


/*
 * 함수: logLate()
 * 역할: 늦게 출력할 로그를 임시 보관합니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logLate() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $msg, $id1, $id2, $id3, $HlateLogPool, $HislandTurn;
$_args = func_get_args();
	$msg = isset($_args[0]) ? $_args[0] : null;
	$id1 = isset($_args[1]) ? $_args[1] : null;
	$id2 = isset($_args[2]) ? $_args[2] : null;
	$id3 = isset($_args[3]) ? $_args[3] : null;
	hako_push($HlateLogPool, "3,$HislandTurn,$id1,$id2,$id3,$msg");
}


/*
 * 함수: logSecret()
 * 역할: 비공개 로그를 기록합니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logSecret() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $msg, $id1, $id2, $id3, $HsecretLogPool, $HislandTurn;
$_args = func_get_args();
	$msg = isset($_args[0]) ? $_args[0] : null;
	$id1 = isset($_args[1]) ? $_args[1] : null;
	$id2 = isset($_args[2]) ? $_args[2] : null;
	$id3 = isset($_args[3]) ? $_args[3] : null;
	hako_push($HsecretLogPool, "1,$HislandTurn,$id1,$id2,$id3,$msg");
}


/*
 * 함수: logHistory()
 * 역할: 과거 사건 로그를 기록합니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logHistory() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $msg, $HhistoryLogPool, $HislandTurn;
$_args = func_get_args();
	$msg = isset($_args[0]) ? $_args[0] : null;
	hako_push($HhistoryLogPool, "$HislandTurn,$msg");
}


/*
 * 함수: logHistoryTrim()
 * 역할: 과거 사건 로그가 최대 개수를 넘지 않게 잘라냅니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logHistoryTrim() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $HdirName, $line, $l, $count, $i, $HhistoryLogPool, $HhistoryMax;
$_args = func_get_args();
	hako_open('HIN', "{$HdirName}/hakojima.his");
	unset($line); $line = array();
	unset($l); $l = null;
	unset($count); $count = null;
	unset($i); $i = null;
	$count = 0;
	while ($l = hako_getline('HIN')) {
		hako_chomp($l);
		hako_push($line, $l);
		$count++;
	}
	hako_close('HIN');
	hako_open('HOUT', ">>{$HdirName}/hakojima.his");
	for ($i = 0;$i <= hako_last_index($HhistoryLogPool);$i++) {
		hako_write('HOUT', "$HhistoryLogPool[$i]\n");
		hako_push($line, $HhistoryLogPool[$i]);
		$count++;
	}
	hako_close('HOUT');
	if ($count > $HhistoryMax) {
		hako_open('HOUT', ">{$HdirName}/hakojima.his");
		for ($i = ($count - $HhistoryMax); $i < $count; $i++) {
			hako_write('HOUT', "$line[$i]\n");
		}
		hako_close('HOUT');
	}
}


/*
 * 함수: logFlush()
 * 역할: 누적된 로그 버퍼를 실제 로그 배열/파일 출력 대상으로 반영합니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logFlush() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $uti, $sti, $cuti, $csti, $cpu, $HdirName, $HislandTurn, $i, $HsecretLogPool, $HlateLogPool, $forceLogPool, $HforceLogPool, $HlogPool;
$_args = func_get_args();
	
	$_list_tmp = hako_cpu_times();
	$uti = isset($_list_tmp[0]) ? $_list_tmp[0] : 0;
	$sti = isset($_list_tmp[1]) ? $_list_tmp[1] : 0;
	$cuti = isset($_list_tmp[2]) ? $_list_tmp[2] : 0;
	$csti = isset($_list_tmp[3]) ? $_list_tmp[3] : 0;
	$uti += $cuti;
	$sti += $csti;
	unset($cpu); $cpu = $uti + $sti;
	




	hako_open('LOUT', ">{$HdirName}/hakojima.log0");
	hako_write('LOUT', "0,$HislandTurn,0,,,<SMALL>부하 계측 CPU($cpu) : user($uti) system($sti)</SMALL>\n");

	
	unset($i); $i = null;
	for ($i = hako_last_index($HsecretLogPool); $i >= 0; $i--) {
		hako_write('LOUT', "$HsecretLogPool[$i]\n");
	}
	for ($i = hako_last_index($HlateLogPool); $i >= 0; $i--) {
		hako_write('LOUT', "$HlateLogPool[$i]\n");
	}
	unset($forceLogPool); $forceLogPool = (isset($HforceLogPool) && is_array($HforceLogPool)) ? $HforceLogPool : array();
	rsort($forceLogPool, SORT_STRING);
	for ($i = hako_last_index($forceLogPool); $i >= 0; $i--) {
		hako_write('LOUT', "$forceLogPool[$i]\n");
	}
	for ($i = hako_last_index($HlogPool); $i >= 0; $i--) {
		hako_write('LOUT', "$HlogPool[$i]\n");
	}
	hako_close('LOUT');
}


/*
 * 함수: logPop()
 * 역할: 인구·병력 등 턴 통계 로그를 기록합니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logPop() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $str, $mode, $p, $HislandTurn, $line, $l, $i, $count, $island, $idx, $islands, $HdirName, $HislandNumber, $Hislands2, $tmp, $tn, $HidToNumber, $s, $m;
$_args = func_get_args();
	unset($str); $str = isset($_args[0]) ? $_args[0] : null;
	unset($mode); $mode = isset($_args[1]) ? $_args[1] : null;
	unset($p); $p = intval($HislandTurn / 300);
	unset($line); $line = array();
	unset($l); $l = null;
	unset($i); $i = null;
	unset($count); $count = null;
	unset($island); $island = null;
	unset($idx); $idx = array();
	unset($islands); $islands = array();
	hako_open('HIN', "{$HdirName}/$str.$p");
	while ($l = hako_getline('HIN')) {
		hako_chomp($l); hako_push($line, $l);
		$count++;
	}
	hako_close('HIN');
	hako_open('HOUT', ">{$HdirName}/$str.$p");
	if ($count < 1) {
		hako_push($line, ",");
		$count = 1;
		for ($i = 0; $i < $HislandNumber; $i++) {
			$island = $Hislands2[$i];
			hako_push($line, "{$island['id']},{$island['name']}");
			$count++;
		}
	}
	$line[0] .= ",$HislandTurn";
	hako_write('HOUT', "$line[0]\n");
	for ($i = 0; $i < $count-1; $i++) {
		unset($tmp); $tmp = explode(',', $line[$i+1]);
		$tn = $HidToNumber[$tmp[0]];
		if (($tn === '' || $tn === null)) {
			$line[$i+1] .= ",0";
		} elseif ($mode == 1) {
			$island = $Hislands2[$tn];
			

			unset($p); $p = $island['pop'] + $island['sol'];
			unset($s); $s = $island['farm'] + $island['factory'] + $island['mountain'];
			unset($m); $m = $island['money'] + $island['pwct'] + (($island['food'] + 1) / 5);
			if ($p < 1 || $s < 1) {
				$p = 0;
			} else{
				$p = intval((($p / 100) + ($s / 250) + ($m / 150)) * ($island['area'] / 3));
			}
			$island['score'] = $p;
			$line[$i+1] .= ",$p";
		} else{
			$island = $Hislands2[$tn];
			$line[$i+1] .= "," . $island[$str];
		}
		hako_write('HOUT', $line[$i+1] . "\n");
	}
	hako_close('HOUT');
}





/*
 * 함수: logNoMoney()
 * 역할: 자금 부족 로그를 출력합니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logNoMoney() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $name, $comName, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($name); $name = isset($_args[1]) ? $_args[1] : null;
	unset($comName); $comName = isset($_args[2]) ? $_args[2] : null;
	logOut("{$HtagName_}{$name}{$H_tagName}로 예정되어 있던{$HtagComName_}{$comName}{$H_tagComName}는, 자금부족이기 때문에 중지되었습니다. ",$id);
}


/*
 * 함수: logNoFood()
 * 역할: 식량 부족 로그를 출력합니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logNoFood() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $name, $comName, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($name); $name = isset($_args[1]) ? $_args[1] : null;
	unset($comName); $comName = isset($_args[2]) ? $_args[2] : null;
	logOut("{$HtagName_}{$name}{$H_tagName}로 예정되어 있던{$HtagComName_}{$comName}{$H_tagComName}는, 비축 식량 부족을 위해 중지되었습니다. ",$id);
}


/*
 * 함수: logMiss()
 * 역할: 명령 실패 로그를 출력합니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logMiss() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $name, $comName, $reason, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
$_args = func_get_args();
	$id = isset($_args[0]) ? $_args[0] : null;
	$name = isset($_args[1]) ? $_args[1] : null;
	$comName = isset($_args[2]) ? $_args[2] : null;
	$reason = isset($_args[3]) ? $_args[3] : null;
	logOut("{$HtagName_}{$name}{$H_tagName}로 예정되어 있던{$HtagComName_}{$comName}{$H_tagComName}는,{$reason}유익 중지되었습니다.",$id);
}


/*
 * 함수: logLandFail()
 * 역할: 대상 지형 부적합 로그를 출력합니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logLandFail() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $tId, $name, $tName, $comName, $kind, $point, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($tId); $tId = isset($_args[1]) ? $_args[1] : null;
	unset($name); $name = isset($_args[2]) ? $_args[2] : null;
	unset($tName); $tName = isset($_args[3]) ? $_args[3] : null;
	unset($comName); $comName = isset($_args[4]) ? $_args[4] : null;
	unset($kind); $kind = isset($_args[5]) ? $_args[5] : null;
	unset($point); $point = isset($_args[6]) ? $_args[6] : null;
	logOut("{$HtagName_}{$name}{$H_tagName}로 예정되어 있던{$HtagComName_}{$comName}{$H_tagComName}는, 예정지의{$HtagName_}{$tName}{$point}{$H_tagName}가<B>실행 불가능한 지형</B>이었기 때문에 중지되었습니다. ",$id,$tId);
}


/*
 * 함수: logLandOwnerFail()
 * 역할: 대상 소유권 부적합 로그를 출력합니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logLandOwnerFail() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $tId, $name, $tName, $comName, $point, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($tId); $tId = isset($_args[1]) ? $_args[1] : null;
	unset($name); $name = isset($_args[2]) ? $_args[2] : null;
	unset($tName); $tName = isset($_args[3]) ? $_args[3] : null;
	unset($comName); $comName = isset($_args[4]) ? $_args[4] : null;
	unset($point); $point = isset($_args[5]) ? $_args[5] : null;
	logOut("{$HtagName_}{$name}{$H_tagName}로 예정되어 있던{$HtagComName_}{$comName}{$H_tagComName}는, 예정지의{$HtagName_}{$tName}{$point}{$H_tagName}가<B>자국의 영토와 인접하고 있지 않는</B>유익 중지되었습니다. ",$id,$tId);
}


/*
 * 함수: logLandRestrictFail()
 * 역할: 대상 제한 조건 실패 로그를 출력합니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logLandRestrictFail() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $tId, $name, $tName, $comName, $point, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($tId); $tId = isset($_args[1]) ? $_args[1] : null;
	unset($name); $name = isset($_args[2]) ? $_args[2] : null;
	unset($tName); $tName = isset($_args[3]) ? $_args[3] : null;
	unset($comName); $comName = isset($_args[4]) ? $_args[4] : null;
	unset($point); $point = isset($_args[5]) ? $_args[5] : null;
	logOut("{$HtagName_}{$name}{$H_tagName}로 예정되어 있던{$HtagComName_}{$comName}{$H_tagComName}는, 예정지의{$HtagName_}{$tName}{$point}{$H_tagName}에서는<B>실행이 제한되고 있는</B>유익 중지되었습니다. ",$id,$tId);
}


/*
 * 함수: logNoLandAround()
 * 역할: 주변 지형 조건 실패 로그를 출력합니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logNoLandAround() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $tId, $name, $tName, $comName, $point, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($tId); $tId = isset($_args[1]) ? $_args[1] : null;
	unset($name); $name = isset($_args[2]) ? $_args[2] : null;
	unset($tName); $tName = isset($_args[3]) ? $_args[3] : null;
	unset($comName); $comName = isset($_args[4]) ? $_args[4] : null;
	unset($point); $point = isset($_args[5]) ? $_args[5] : null;
	logOut("{$HtagName_}{$name}{$H_tagName}로 예정되어 있던{$HtagComName_}{$comName}{$H_tagComName}는, 예정지의{$HtagName_}{$tName}{$point}{$H_tagName}의 주변에 영토가 없었기 때문에 중지되었습니다. ",$id,$tId);
}


/*
 * 함수: logLandOccupy()
 * 역할: 영토 점령 로그를 출력합니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logLandOccupy() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $tId, $name, $tName, $x, $y, $lName, $mode, $str, $HlandOwner, $island, $Hislands, $HidToNumber, $tIsland, $p, $HlandKeep, $Hland, $HlandFarm, $HlandTown, $HlandValue, $HunitFood, $HlandSupply, $HlandBase, $HunitPop;
    global $HlandFactory, $HlandDefence, $HunitMoney, $HlandMountain, $HtagName_, $H_tagName;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($tId); $tId = isset($_args[1]) ? $_args[1] : null;
	unset($name); $name = isset($_args[2]) ? $_args[2] : null;
	unset($tName); $tName = isset($_args[3]) ? $_args[3] : null;
	unset($x); $x = isset($_args[4]) ? $_args[4] : null;
	unset($y); $y = isset($_args[5]) ? $_args[5] : null;
	unset($lName); $lName = isset($_args[6]) ? $_args[6] : null;
	unset($mode); $mode = isset($_args[7]) ? $_args[7] : null;
	unset($str); $str = "";
	if (($mode == 1) && ($HlandOwner[$x][$y] > 0)) {
		
		unset($island); $island =& $Hislands[$HidToNumber[$tId]];
		unset($tIsland); $tIsland =& $Hislands[$HidToNumber[$id]];
		unset($p); $p = 0;
		if ($HlandKeep[$x][$y] < 15) {
			
		} elseif (($Hland[$x][$y] == $HlandFarm) || (($Hland[$x][$y] == $HlandTown) && ($HlandValue[$x][$y] >= 50))) {
			$p = ($tIsland['food'] / 10 > 500) ? 500 : intval($tIsland['food'] / 10);
			if ($p < 10) { $p = 10; }
			$island['food'] += $p;
			$tIsland['food'] -= $p;
			if ($tIsland['food'] < 0) { $tIsland['food'] = 0; }
			$str = "또 동시에 식량을<B>$p$HunitFood</B>약탈했습니다.";
		} elseif (($Hland[$x][$y] == $HlandSupply) || ($Hland[$x][$y] == $HlandBase)) {
			$p = ($tIsland['soldier'] / 10 > 100) ? 100 : intval($tIsland['soldier'] / 10);
			if ($p < 10) { $p = 10; }
			$island['soldier'] += $p;
			$tIsland['soldier'] -= $p;
			if ($tIsland['soldier'] < 0) { $tIsland['soldier'] = 0; }
			$str = "또 동시에 예비병을<B>$p$HunitPop</B>약탈했습니다.";
		} elseif (($Hland[$x][$y] == $HlandFactory) || ($Hland[$x][$y] == $HlandDefence)) {
			$p = ($tIsland['money'] / 10 > 100) ? 100 : intval($tIsland['money'] / 10);
			if ($p < 10) { $p = 10; }
			$island['money'] += $p;
			$tIsland['money'] -= $p;
			if ($tIsland['money'] < 0) { $tIsland['money'] = 0; }
			$str = "또 동시에 자금을<B>$p$HunitMoney</B>약탈했습니다.";
		} elseif (($Hland[$x][$y] == $HlandMountain) && ($HlandValue[$x][$y] >= 1)) {
			$p = ($tIsland['money'] / 10 > 250) ? 250 : intval($tIsland['money'] / 10);
			if ($p < 50) { $p = 50; }
			$island['money'] += $p;
			$tIsland['money'] -= $p;
			if ($tIsland['money'] < 0) { $tIsland['money'] = 0; }
			$str = "또 동시에 자금을<B>$p$HunitMoney</B>약탈했습니다.";
		}
	}
	logOut("{$HtagName_}{$name}({$x}, {$y}){$H_tagName}의<B>$lName</B>는{$HtagName_}{$tName}{$H_tagName}의 점령하가 되었습니다. $str",$id,$tId);
}


/*
 * 함수: logLandReclamation()
 * 역할: 영토/토지 회복 로그를 출력합니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logLandReclamation() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $tId, $name, $tName, $point, $lName, $HtagName_, $H_tagName;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($tId); $tId = isset($_args[1]) ? $_args[1] : null;
	unset($name); $name = isset($_args[2]) ? $_args[2] : null;
	unset($tName); $tName = isset($_args[3]) ? $_args[3] : null;
	unset($point); $point = isset($_args[4]) ? $_args[4] : null;
	unset($lName); $lName = isset($_args[5]) ? $_args[5] : null;
	logOut("{$HtagName_}{$name}{$point}{$H_tagName}의<B>$lName</B>는{$HtagName_}{$tName}{$H_tagName}의 주민에게 개척되었습니다. ",$id,$tId);
}


/*
 * 함수: logLandGiveup()
 * 역할: 영토 포기 로그를 출력합니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logLandGiveup() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $name, $point, $lName, $HtagName_, $H_tagName;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($name); $name = isset($_args[1]) ? $_args[1] : null;
	unset($point); $point = isset($_args[2]) ? $_args[2] : null;
	unset($lName); $lName = isset($_args[3]) ? $_args[3] : null;
	logOut("{$HtagName_}{$name}{$point}{$H_tagName}가<B>$lName</B>의 영유를 방폐했습니다. ",$id);
}


/*
 * 함수: logLandSuc()
 * 역할: 토목/지형 변경 성공 로그를 출력합니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logLandSuc() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $tId, $name, $tName, $comName, $point, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($tId); $tId = isset($_args[1]) ? $_args[1] : null;
	unset($name); $name = isset($_args[2]) ? $_args[2] : null;
	unset($tName); $tName = isset($_args[3]) ? $_args[3] : null;
	unset($comName); $comName = isset($_args[4]) ? $_args[4] : null;
	unset($point); $point = isset($_args[5]) ? $_args[5] : null;
	logOut("{$HtagName_}{$name}{$H_tagName}가{$HtagName_}{$tName}{$point}{$H_tagName}로{$HtagComName_}{$comName}{$H_tagComName}를 실시했습니다. ",$id,$tId);
}


/*
 * 함수: logLandSucMatome()
 * 역할: 지형 변경 성공 로그를 묶어 출력합니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logLandSucMatome() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $name, $comName, $point, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($name); $name = isset($_args[1]) ? $_args[1] : null;
	unset($comName); $comName = isset($_args[2]) ? $_args[2] : null;
	unset($point); $point = isset($_args[3]) ? $_args[3] : null;
	logOut("{$HtagName_}{$name}{$H_tagName}로{$HtagComName_}{$comName}{$H_tagComName}를 했습니다.<br>　　<B>◆</B> $point",$id,$id);
}


/*
 * 함수: logAreaSuc()
 * 역할: 영토 할양 성공 로그를 출력합니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logAreaSuc() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $tId, $name, $tName, $comName, $point, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($tId); $tId = isset($_args[1]) ? $_args[1] : null;
	unset($name); $name = isset($_args[2]) ? $_args[2] : null;
	unset($tName); $tName = isset($_args[3]) ? $_args[3] : null;
	unset($comName); $comName = isset($_args[4]) ? $_args[4] : null;
	unset($point); $point = isset($_args[5]) ? $_args[5] : null;
	logOut("{$HtagName_}{$name}{$H_tagName}가{$HtagName_}{$point}{$H_tagName}를{$HtagName_}{$tName}{$H_tagName}에{$HtagComName_}{$comName}{$H_tagComName}를 실시했습니다. ",$id,$tId);
}


/*
 * 함수: logAutoTree()
 * 역할: 자동 식림 로그를 출력합니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logAutoTree() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $name, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($name); $name = isset($_args[1]) ? $_args[1] : null;
	logOut("{$HtagName_}{$name}{$H_tagName}의<B>숲</B>을{$HtagComName_}벌채{$H_tagComName}, 새롭게{$HtagComName_}식림{$H_tagComName}했습니다. ",$id);
}


/*
 * 함수: logBombSet()
 * 역할: 폭탄/설치 계열 로그를 출력합니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logBombSet() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $tId, $name, $tName, $lName, $point, $HtagName_, $H_tagName;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($tId); $tId = isset($_args[1]) ? $_args[1] : null;
	unset($name); $name = isset($_args[2]) ? $_args[2] : null;
	unset($tName); $tName = isset($_args[3]) ? $_args[3] : null;
	unset($lName); $lName = isset($_args[4]) ? $_args[4] : null;
	unset($point); $point = isset($_args[5]) ? $_args[5] : null;
	logOut2("{$HtagName_}{$name}{$H_tagName}가{$HtagName_}{$tName}{$point}{$H_tagName}로<B>$lName</B>의<B>자폭 장치를 셋팅</B>했습니다.",$id,$tId);
}


/*
 * 함수: logBombFire()
 * 역할: 폭탄/발동 계열 로그를 출력합니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logBombFire() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $name, $lName, $point, $HtagName_, $H_tagName, $HtagDisaster_, $H_tagDisaster;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($name); $name = isset($_args[1]) ? $_args[1] : null;
	unset($lName); $lName = isset($_args[2]) ? $_args[2] : null;
	unset($point); $point = isset($_args[3]) ? $_args[3] : null;
	logOut2("{$HtagName_}{$name}{$point}{$H_tagName}의<B>$lName</B>、{$HtagDisaster_}자폭 장치 작동! {$H_tagDisaster}",$id);
}


/*
 * 함수: logMonDamage()
 * 역할: 괴수 피해 로그를 출력합니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logMonDamage() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $name, $point, $HtagName_, $H_tagName;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($name); $name = isset($_args[1]) ? $_args[1] : null;
	unset($point); $point = isset($_args[2]) ? $_args[2] : null;
	logOut2("<B>무엇인가라고 개도 없는 것</B>이{$HtagName_}{$name}{$point}{$H_tagName}지점에 낙하했습니다! ",$id);
}


/*
 * 함수: logPBSuc()
 * 역할: 피해/방어 성공 로그를 출력합니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logPBSuc() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $tId, $name, $tName, $comName, $point, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($tId); $tId = isset($_args[1]) ? $_args[1] : null;
	unset($name); $name = isset($_args[2]) ? $_args[2] : null;
	unset($tName); $tName = isset($_args[3]) ? $_args[3] : null;
	unset($comName); $comName = isset($_args[4]) ? $_args[4] : null;
	unset($point); $point = isset($_args[5]) ? $_args[5] : null;
	if ($id != $tId) {
		
		logLandSuc($id, $tId, $name, $tName, $comName, $point);
	} else{
		logSecret("{$HtagName_}{$name}{$H_tagName}가{$HtagName_}{$tName}{$point}{$H_tagName}로{$HtagComName_}{$comName}{$H_tagComName}를 실시했습니다.",$id,$tId);
		logOut("마음 탓인지,{$HtagName_}{$name}{$H_tagName}의<B>숲</B>이 증가한 것 같습니다. ",$id,$tId);
	}
}


/*
 * 함수: logMsNoTarget()
 * 역할: 미사일 목표 없음 로그를 출력합니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logMsNoTarget() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $name, $comName, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($name); $name = isset($_args[1]) ? $_args[1] : null;
	unset($comName); $comName = isset($_args[2]) ? $_args[2] : null;
	logOut("{$HtagName_}{$name}{$H_tagName}로 예정되어 있던{$HtagComName_}{$comName}{$H_tagComName}는, 목표의 나라에 사람이 눈에 띄지 않기 때문에 중지되었습니다. ",$id);
}

/*
 * 함수: logNoWar()
 * 역할: 전쟁 상태가 아니라 공격할 수 없을 때의 로그입니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logNoWar() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $tId, $name, $tName, $comName, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($tId); $tId = isset($_args[1]) ? $_args[1] : null;
	unset($name); $name = isset($_args[2]) ? $_args[2] : null;
	unset($tName); $tName = isset($_args[3]) ? $_args[3] : null;
	unset($comName); $comName = isset($_args[4]) ? $_args[4] : null;
	logOut("{$HtagName_}{$name}{$H_tagName}로 예정되어 있던{$HtagComName_}{$comName}{$H_tagComName}는, 목표의{$HtagName_}{$tName}{$H_tagName}와 전쟁중이 아니기 때문에 중지되었습니다. ",$id,$tId);
}


/*
 * 함수: logMsNoBase()
 * 역할: 미사일 기지가 없을 때의 로그입니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logMsNoBase() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $name, $comName, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($name); $name = isset($_args[1]) ? $_args[1] : null;
	unset($comName); $comName = isset($_args[2]) ? $_args[2] : null;
	logOut("{$HtagName_}{$name}{$H_tagName}로 예정되어 있던{$HtagComName_}{$comName}{$H_tagComName}는,<B>사정 범위내의 미사일 설비를 보유하고 있지 않기</B> 때문에 실행할 수 없었습니다. ",$id);
}


/*
 * 함수: logMsOut()
 * 역할: 미사일 사거리 밖 로그입니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logMsOut() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $tId, $name, $tName, $comName, $point, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($tId); $tId = isset($_args[1]) ? $_args[1] : null;
	unset($name); $name = isset($_args[2]) ? $_args[2] : null;
	unset($tName); $tName = isset($_args[3]) ? $_args[3] : null;
	unset($comName); $comName = isset($_args[4]) ? $_args[4] : null;
	unset($point); $point = isset($_args[5]) ? $_args[5] : null;
	logOut("{$HtagName_}{$name}{$H_tagName}가{$HtagName_}{$tName}{$point}{$H_tagName}지점으로 향해{$HtagComName_}{$comName}{$H_tagComName}를 실시했습니다만,<B>영역외의 바다</B>에 떨어진 모양입니다. ",$id, $tId);
}


/*
 * 함수: logMsCaught()
 * 역할: 방위 시설에 요격된 로그입니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logMsCaught() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $tId, $tId2, $name, $tName, $tName2, $comName, $point, $tPoint, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($tId); $tId = isset($_args[1]) ? $_args[1] : null;
	unset($tId2); $tId2 = isset($_args[2]) ? $_args[2] : null;
	unset($name); $name = isset($_args[3]) ? $_args[3] : null;
	unset($tName); $tName = isset($_args[4]) ? $_args[4] : null;
	unset($tName2); $tName2 = isset($_args[5]) ? $_args[5] : null;
	unset($comName); $comName = isset($_args[6]) ? $_args[6] : null;
	unset($point); $point = isset($_args[7]) ? $_args[7] : null;
	unset($tPoint); $tPoint = isset($_args[8]) ? $_args[8] : null;
	logOut("{$HtagName_}{$name}{$H_tagName}가{$HtagName_}{$tName}{$point}{$H_tagName}지점으로 향해{$HtagComName_}{$comName}{$H_tagComName}를 실시했습니다만,{$HtagName_}{$tPoint}{$H_tagName}지점 상공에서 력장에 파악할 수 있어<B>공중 폭발</B>했습니다. ",$id, $tId, $tId2);
}


/*
 * 함수: logMsNoDamage()
 * 역할: 미사일 피해 없음 로그입니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logMsNoDamage() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $tId, $tId2, $name, $tName, $tName2, $comName, $tLname, $point, $tPoint, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($tId); $tId = isset($_args[1]) ? $_args[1] : null;
	unset($tId2); $tId2 = isset($_args[2]) ? $_args[2] : null;
	unset($name); $name = isset($_args[3]) ? $_args[3] : null;
	unset($tName); $tName = isset($_args[4]) ? $_args[4] : null;
	unset($tName2); $tName2 = isset($_args[5]) ? $_args[5] : null;
	unset($comName); $comName = isset($_args[6]) ? $_args[6] : null;
	unset($tLname); $tLname = isset($_args[7]) ? $_args[7] : null;
	unset($point); $point = isset($_args[8]) ? $_args[8] : null;
	unset($tPoint); $tPoint = isset($_args[9]) ? $_args[9] : null;
	logOut("{$HtagName_}{$name}{$H_tagName}가{$HtagName_}{$tName}{$point}{$H_tagName}지점으로 향해{$HtagComName_}{$comName}{$H_tagComName}를 실시했습니다만,{$HtagName_}{$tName2}{$tPoint}{$H_tagName}의<B>$tLname</B>에 떨어졌으므로 피해가 없었습니다. ",$id, $tId, $tId2);
}


/*
 * 함수: logMsLDMountain()
 * 역할: 산에 미사일이 명중한 로그입니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logMsLDMountain() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $tId, $tId2, $name, $tName, $tName2, $comName, $tLname, $point, $tPoint, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($tId); $tId = isset($_args[1]) ? $_args[1] : null;
	unset($tId2); $tId2 = isset($_args[2]) ? $_args[2] : null;
	unset($name); $name = isset($_args[3]) ? $_args[3] : null;
	unset($tName); $tName = isset($_args[4]) ? $_args[4] : null;
	unset($tName2); $tName2 = isset($_args[5]) ? $_args[5] : null;
	unset($comName); $comName = isset($_args[6]) ? $_args[6] : null;
	unset($tLname); $tLname = isset($_args[7]) ? $_args[7] : null;
	unset($point); $point = isset($_args[8]) ? $_args[8] : null;
	unset($tPoint); $tPoint = isset($_args[9]) ? $_args[9] : null;
	logOut("{$HtagName_}{$name}{$H_tagName}가{$HtagName_}{$tName}{$point}{$H_tagName}지점으로 향해{$HtagComName_}{$comName}{$H_tagComName}를 실시해,{$HtagName_}{$tName2}{$tPoint}{$H_tagName}의<B>$tLname</B>에 명중. <B>$tLname</B>>는 날아가 버려, 황무지화했습니다. ",$id, $tId, $tId2);
}


/*
 * 함수: logMsLDSbase()
 * 역할: 해저기지 명중 로그입니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logMsLDSbase() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $tId, $tId2, $name, $tName, $tName2, $comName, $tLname, $point, $tPoint, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($tId); $tId = isset($_args[1]) ? $_args[1] : null;
	unset($tId2); $tId2 = isset($_args[2]) ? $_args[2] : null;
	unset($name); $name = isset($_args[3]) ? $_args[3] : null;
	unset($tName); $tName = isset($_args[4]) ? $_args[4] : null;
	unset($tName2); $tName2 = isset($_args[5]) ? $_args[5] : null;
	unset($comName); $comName = isset($_args[6]) ? $_args[6] : null;
	unset($tLname); $tLname = isset($_args[7]) ? $_args[7] : null;
	unset($point); $point = isset($_args[8]) ? $_args[8] : null;
	unset($tPoint); $tPoint = isset($_args[9]) ? $_args[9] : null;
	logOut("{$HtagName_}{$name}{$H_tagName}가{$HtagName_}{$tName}{$point}{$H_tagName}지점으로 향해{$HtagComName_}{$comName}{$H_tagComName}를 실시해,{$HtagName_}{$tName2}{$tPoint}{$H_tagName}에 착수 후 폭발, 도우지점에 있던<B>$tLname</B>는 흔적도 없게 불어 날았습니다. ",$id, $tId, $tId2);
}


/*
 * 함수: logMsLDMonster()
 * 역할: 괴수 명중 로그입니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logMsLDMonster() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $tId, $tId2, $name, $tName, $tName2, $comName, $tLname, $point, $tPoint, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($tId); $tId = isset($_args[1]) ? $_args[1] : null;
	unset($tId2); $tId2 = isset($_args[2]) ? $_args[2] : null;
	unset($name); $name = isset($_args[3]) ? $_args[3] : null;
	unset($tName); $tName = isset($_args[4]) ? $_args[4] : null;
	unset($tName2); $tName2 = isset($_args[5]) ? $_args[5] : null;
	unset($comName); $comName = isset($_args[6]) ? $_args[6] : null;
	unset($tLname); $tLname = isset($_args[7]) ? $_args[7] : null;
	unset($point); $point = isset($_args[8]) ? $_args[8] : null;
	unset($tPoint); $tPoint = isset($_args[9]) ? $_args[9] : null;
	logOut("{$HtagName_}{$name}{$H_tagName}가{$HtagName_}{$tName}{$point}{$H_tagName}지점으로 향해{$HtagComName_}{$comName}{$H_tagComName}를 실시해,{$HtagName_}{$tName2}{$tPoint}{$H_tagName}에 착탄 해 폭발. 육지는<B>괴수 $tLname</B>와 수몰 했습니다.",$id, $tId, $tId2);
}


/*
 * 함수: logMsLDSea1()
 * 역할: 바다 명중 로그입니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logMsLDSea1() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $tId, $tId2, $name, $tName, $tName2, $comName, $tLname, $point, $tPoint, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($tId); $tId = isset($_args[1]) ? $_args[1] : null;
	unset($tId2); $tId2 = isset($_args[2]) ? $_args[2] : null;
	unset($name); $name = isset($_args[3]) ? $_args[3] : null;
	unset($tName); $tName = isset($_args[4]) ? $_args[4] : null;
	unset($tName2); $tName2 = isset($_args[5]) ? $_args[5] : null;
	unset($comName); $comName = isset($_args[6]) ? $_args[6] : null;
	unset($tLname); $tLname = isset($_args[7]) ? $_args[7] : null;
	unset($point); $point = isset($_args[8]) ? $_args[8] : null;
	unset($tPoint); $tPoint = isset($_args[9]) ? $_args[9] : null;
	logOut("{$HtagName_}{$name}{$H_tagName}가{$HtagName_}{$tName}{$point}{$H_tagName}지점으로 향해{$HtagComName_}{$comName}{$H_tagComName}를 실시해,{$HtagName_}{$tName2}{$tPoint}{$H_tagName}의<B>$tLname</B>에 착탄. 해저가 꾸물거려졌습니다. ",$id, $tId, $tId2);
}


/*
 * 함수: logMsLDLand()
 * 역할: 일반 지형 명중 로그입니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logMsLDLand() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $tId, $tId2, $name, $tName, $tName2, $comName, $tLname, $point, $tPoint, $str, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($tId); $tId = isset($_args[1]) ? $_args[1] : null;
	unset($tId2); $tId2 = isset($_args[2]) ? $_args[2] : null;
	unset($name); $name = isset($_args[3]) ? $_args[3] : null;
	unset($tName); $tName = isset($_args[4]) ? $_args[4] : null;
	unset($tName2); $tName2 = isset($_args[5]) ? $_args[5] : null;
	unset($comName); $comName = isset($_args[6]) ? $_args[6] : null;
	unset($tLname); $tLname = isset($_args[7]) ? $_args[7] : null;
	unset($point); $point = isset($_args[8]) ? $_args[8] : null;
	unset($tPoint); $tPoint = isset($_args[9]) ? $_args[9] : null;
	unset($str); $str = isset($_args[10]) ? $_args[10] : null;
	logOut("{$HtagName_}{$name}{$H_tagName}가{$HtagName_}{$tName}{$point}{$H_tagName}지점으로 향해{$HtagComName_}{$comName}{$H_tagComName}를 실시해,{$HtagName_}{$tName2}{$tPoint}{$H_tagName}의<B>$tLname</B>에 착탄. $str 육지는 수몰 했습니다. ",$id, $tId, $tId2);
}


/*
 * 함수: logMsWaste()
 * 역할: 미사일로 황무지가 된 로그입니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logMsWaste() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $tId, $tId2, $name, $tName, $tName2, $comName, $tLname, $point, $tPoint, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($tId); $tId = isset($_args[1]) ? $_args[1] : null;
	unset($tId2); $tId2 = isset($_args[2]) ? $_args[2] : null;
	unset($name); $name = isset($_args[3]) ? $_args[3] : null;
	unset($tName); $tName = isset($_args[4]) ? $_args[4] : null;
	unset($tName2); $tName2 = isset($_args[5]) ? $_args[5] : null;
	unset($comName); $comName = isset($_args[6]) ? $_args[6] : null;
	unset($tLname); $tLname = isset($_args[7]) ? $_args[7] : null;
	unset($point); $point = isset($_args[8]) ? $_args[8] : null;
	unset($tPoint); $tPoint = isset($_args[9]) ? $_args[9] : null;
	logOut("{$HtagName_}{$name}{$H_tagName}가{$HtagName_}{$tName}{$point}{$H_tagName}지점으로 향해{$HtagComName_}{$comName}{$H_tagComName}를 실시했습니다만,{$HtagName_}{$tName2}{$tPoint}{$H_tagName}의<B>$tLname</B>에 떨어졌습니다. ",$id, $tId, $tId2);
}


/*
 * 함수: logMsMonNoDamage()
 * 역할: 괴수에게 피해가 없을 때의 로그입니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logMsMonNoDamage() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $tId, $tId2, $name, $tName, $tName2, $comName, $tLname, $point, $tPoint, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($tId); $tId = isset($_args[1]) ? $_args[1] : null;
	unset($tId2); $tId2 = isset($_args[2]) ? $_args[2] : null;
	unset($name); $name = isset($_args[3]) ? $_args[3] : null;
	unset($tName); $tName = isset($_args[4]) ? $_args[4] : null;
	unset($tName2); $tName2 = isset($_args[5]) ? $_args[5] : null;
	unset($comName); $comName = isset($_args[6]) ? $_args[6] : null;
	unset($tLname); $tLname = isset($_args[7]) ? $_args[7] : null;
	unset($point); $point = isset($_args[8]) ? $_args[8] : null;
	unset($tPoint); $tPoint = isset($_args[9]) ? $_args[9] : null;
	logOut("{$HtagName_}{$name}{$H_tagName}가{$HtagName_}{$tName}{$point}{$H_tagName}지점으로 향해{$HtagComName_}{$comName}{$H_tagComName}를 실시해,{$HtagName_}{$tName2}{$tPoint}{$H_tagName}의<B>괴수 $tLname</B>에 명중, 그러나 경화 상태였기 때문에 효과가 없었습니다. ",$id, $tId, $tId2);
}


/*
 * 함수: logMsMonKill()
 * 역할: 괴수 퇴치 로그입니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logMsMonKill() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $tId, $tId2, $name, $tName, $tName2, $comName, $tLname, $point, $tPoint, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($tId); $tId = isset($_args[1]) ? $_args[1] : null;
	unset($tId2); $tId2 = isset($_args[2]) ? $_args[2] : null;
	unset($name); $name = isset($_args[3]) ? $_args[3] : null;
	unset($tName); $tName = isset($_args[4]) ? $_args[4] : null;
	unset($tName2); $tName2 = isset($_args[5]) ? $_args[5] : null;
	unset($comName); $comName = isset($_args[6]) ? $_args[6] : null;
	unset($tLname); $tLname = isset($_args[7]) ? $_args[7] : null;
	unset($point); $point = isset($_args[8]) ? $_args[8] : null;
	unset($tPoint); $tPoint = isset($_args[9]) ? $_args[9] : null;
	logOut("{$HtagName_}{$name}{$H_tagName}가{$HtagName_}{$tName}{$point}{$H_tagName}지점으로 향해{$HtagComName_}{$comName}{$H_tagComName}를 실시해,{$HtagName_}{$tName2}{$tPoint}{$H_tagName}의<B>괴수 $tLname</B>에 명중. <B>괴수 $tLname</B>는 힘이 다해 넘어졌습니다. ",$id, $tId, $tId2);
}


/*
 * 함수: logMsMonster()
 * 역할: 괴수 피해/반응 로그입니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logMsMonster() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $tId, $tId2, $name, $tName, $tName2, $comName, $tLname, $point, $tPoint, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($tId); $tId = isset($_args[1]) ? $_args[1] : null;
	unset($tId2); $tId2 = isset($_args[2]) ? $_args[2] : null;
	unset($name); $name = isset($_args[3]) ? $_args[3] : null;
	unset($tName); $tName = isset($_args[4]) ? $_args[4] : null;
	unset($tName2); $tName2 = isset($_args[5]) ? $_args[5] : null;
	unset($comName); $comName = isset($_args[6]) ? $_args[6] : null;
	unset($tLname); $tLname = isset($_args[7]) ? $_args[7] : null;
	unset($point); $point = isset($_args[8]) ? $_args[8] : null;
	unset($tPoint); $tPoint = isset($_args[9]) ? $_args[9] : null;
	logOut("{$HtagName_}{$name}{$H_tagName}가{$HtagName_}{$tName}{$point}{$H_tagName}지점으로 향해{$HtagComName_}{$comName}{$H_tagComName}를 실시해,{$HtagName_}{$tName2}{$tPoint}{$H_tagName}의<B>괴수 $tLname</B>에 명중. <B>괴수 $tLname</B>는 괴로운 듯하게 사납게 울부짖고 했습니다. ",$id, $tId, $tId2);
}


/*
 * 함수: logMsMonMoney()
 * 역할: 괴수 퇴치 보상 로그입니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logMsMonMoney() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $tId, $mName, $value, $HunitMoney;
$_args = func_get_args();
	unset($tId); $tId = isset($_args[0]) ? $_args[0] : null;
	unset($mName); $mName = isset($_args[1]) ? $_args[1] : null;
	unset($value); $value = isset($_args[2]) ? $_args[2] : null;
	logOut("<B>괴수 $mName</B>의 잔해에는,<B>$value$HunitMoney</B>의 값이 붙었습니다. ",$tId);
}


/*
 * 함수: logMsNormal()
 * 역할: 일반 미사일 피해 로그입니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logMsNormal() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $tId, $tId2, $name, $tName, $tName2, $comName, $tLname, $point, $tPoint, $str, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($tId); $tId = isset($_args[1]) ? $_args[1] : null;
	unset($tId2); $tId2 = isset($_args[2]) ? $_args[2] : null;
	unset($name); $name = isset($_args[3]) ? $_args[3] : null;
	unset($tName); $tName = isset($_args[4]) ? $_args[4] : null;
	unset($tName2); $tName2 = isset($_args[5]) ? $_args[5] : null;
	unset($comName); $comName = isset($_args[6]) ? $_args[6] : null;
	unset($tLname); $tLname = isset($_args[7]) ? $_args[7] : null;
	unset($point); $point = isset($_args[8]) ? $_args[8] : null;
	unset($tPoint); $tPoint = isset($_args[9]) ? $_args[9] : null;
	unset($str); $str = isset($_args[10]) ? $_args[10] : null;
	logOut("{$HtagName_}{$name}{$H_tagName}가{$HtagName_}{$tName}{$point}{$H_tagName}지점으로 향해{$HtagComName_}{$comName}{$H_tagComName}를 실시해,{$HtagName_}{$tName2}{$tPoint}{$H_tagName}의<B>$tLname</B>에 명중, $str 일대가 괴멸 했습니다. ",$id, $tId, $tId2);
}


/*
 * 함수: logMsBoatPeople()
 * 역할: 난민 발생 로그입니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logMsBoatPeople() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $name, $achive, $HtagName_, $H_tagName, $HunitPop;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($name); $name = isset($_args[1]) ? $_args[1] : null;
	unset($achive); $achive = isset($_args[2]) ? $_args[2] : null;
	logOut("{$HtagName_}{$name}{$H_tagName}에 어디에서와도 없고<B>$achive[$HunitPop]것 난민</B>이 표착했습니다.{$HtagName_}{$name}{$H_tagName}는 기분 좋게 받아들인 것 같습니다.",$id);
}


/*
 * 함수: logMonsSend()
 * 역할: 괴수 파견 로그입니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logMonsSend() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $tId, $name, $tName, $HtagName_, $H_tagName;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($tId); $tId = isset($_args[1]) ? $_args[1] : null;
	unset($name); $name = isset($_args[2]) ? $_args[2] : null;
	unset($tName); $tName = isset($_args[3]) ? $_args[3] : null;
	logOut("{$HtagName_}{$name}{$H_tagName}가<B>인조 괴수</B>를 건조{$HtagName_}{$tName}{$H_tagName}에 보내 주었습니다. ",$id, $tId);
}


/*
 * 함수: logAmity()
 * 역할: 우호 조약 체결 로그입니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logAmity() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $name, $tId, $tName, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($name); $name = isset($_args[1]) ? $_args[1] : null;
	unset($tId); $tId = isset($_args[2]) ? $_args[2] : null;
	unset($tName); $tName = isset($_args[3]) ? $_args[3] : null;
	logOut("{$HtagName_}{$name}{$H_tagName}와{$HtagName_}{$tName}{$H_tagName}가{$HtagComName_}우호국{$H_tagComName}가 되었습니다. ",$id, $tId);
}

/*
 * 함수: logAmityEnd()
 * 역할: 우호 조약 종료 로그입니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logAmityEnd() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $name, $tId, $tName, $str, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($name); $name = isset($_args[1]) ? $_args[1] : null;
	unset($tId); $tId = isset($_args[2]) ? $_args[2] : null;
	unset($tName); $tName = isset($_args[3]) ? $_args[3] : null;
	unset($str); $str = isset($_args[4]) ? $_args[4] : null;
	logOut("{$HtagName_}{$name}{$H_tagName}와{$HtagName_}{$tName}{$H_tagName}의{$HtagComName_}우호 관계{$H_tagComName}는{$str}실효했습니다. ",$id, $tId);
}


/*
 * 함수: logSell()
 * 역할: 식량 판매 로그입니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logSell() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $name, $comName, $value, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($name); $name = isset($_args[1]) ? $_args[1] : null;
	unset($comName); $comName = isset($_args[2]) ? $_args[2] : null;
	unset($value); $value = isset($_args[3]) ? $_args[3] : null;
	logOut("{$HtagName_}{$name}{$H_tagName}가<B>$value</B>의{$HtagComName_}{$comName}{$H_tagComName}를 실시했습니다. ",$id);
}


/*
 * 함수: logAid()
 * 역할: 지원/원조 로그입니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logAid() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $tId, $name, $tName, $comName, $str, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($tId); $tId = isset($_args[1]) ? $_args[1] : null;
	unset($name); $name = isset($_args[2]) ? $_args[2] : null;
	unset($tName); $tName = isset($_args[3]) ? $_args[3] : null;
	unset($comName); $comName = isset($_args[4]) ? $_args[4] : null;
	unset($str); $str = isset($_args[5]) ? $_args[5] : null;
	logOut("{$HtagName_}{$name}{$H_tagName}가{$HtagName_}{$tName}{$H_tagName}에<B>$str</B>의{$HtagComName_}{$comName}{$H_tagComName}를 실시했습니다. ",$id, $tId);
}


/*
 * 함수: logPropaganda()
 * 역할: 선전포고/선전 활동 로그입니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logPropaganda() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $name, $comName, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($name); $name = isset($_args[1]) ? $_args[1] : null;
	unset($comName); $comName = isset($_args[2]) ? $_args[2] : null;
	logOut("{$HtagName_}{$name}{$H_tagName}로{$HtagComName_}{$comName}{$H_tagComName}를 했습니다. ",$id);
}


/*
 * 함수: logGiveup()
 * 역할: 섬 포기 로그입니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logGiveup() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $name, $HtagName_, $H_tagName;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($name); $name = isset($_args[1]) ? $_args[1] : null;
	logOut("{$HtagName_}{$name}{$H_tagName}는 방폐되어<B>무인국</B>이 되었습니다. ",$id);
	logHistory("{$HtagName_}{$name}{$H_tagName}, 방폐되고<B>무인국</B>이 된다. ");
}


/*
 * 함수: logDead()
 * 역할: 섬 멸망 로그입니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logDead() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $name, $HtagName_, $H_tagName;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($name); $name = isset($_args[1]) ? $_args[1] : null;
	logOut("{$HtagName_}{$name}{$H_tagName}로부터 사람이 없어져,<B>무인국</B>이 되었습니다. ",$id);
	logHistory("{$HtagName_}{$name}{$H_tagName}, 사람이 없어져<B>무인국</B>이 된다. ");
}


/*
 * 함수: logStarve()
 * 역할: 식량 부족/기아 로그입니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logStarve() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $name, $HtagName_, $H_tagName, $HtagDisaster_, $H_tagDisaster;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($name); $name = isset($_args[1]) ? $_args[1] : null;
	logOut("{$HtagName_}{$name}{$H_tagName}의{$HtagDisaster_}식량이 부족{$H_tagDisaster}하고 있습니다!",$id);
}


/*
 * 함수: logStarveRiot()
 * 역할: 기아로 인한 폭동 로그입니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logStarveRiot() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $name, $point, $lName, $HtagName_, $H_tagName;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($name); $name = isset($_args[1]) ? $_args[1] : null;
	unset($point); $point = isset($_args[2]) ? $_args[2] : null;
	unset($lName); $lName = isset($_args[3]) ? $_args[3] : null;
	logOut("{$HtagName_}{$name}{$point}{$H_tagName}의<B>$lName</B>로 폭동이 발생했습니다! ",$id);
}


/*
 * 함수: logMonsCome()
 * 역할: 괴수 출현 로그입니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logMonsCome() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $tId, $name, $mName, $point, $lName, $HtagName_, $H_tagName;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($tId); $tId = isset($_args[1]) ? $_args[1] : null;
	unset($name); $name = isset($_args[2]) ? $_args[2] : null;
	unset($mName); $mName = isset($_args[3]) ? $_args[3] : null;
	unset($point); $point = isset($_args[4]) ? $_args[4] : null;
	unset($lName); $lName = isset($_args[5]) ? $_args[5] : null;
	logOut("{$HtagName_}{$name}{$H_tagName}에<B>괴수 $mName</B>출현!{$HtagName_}{$point}{$H_tagName}의<B>$lName</B>가 밟아 망쳐졌습니다.",$id, $tId);
}


/*
 * 함수: logMonsLost()
 * 역할: 괴수 소멸/행방불명 로그입니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logMonsLost() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $tId, $name, $mName, $point, $str, $HtagName_, $H_tagName;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($tId); $tId = isset($_args[1]) ? $_args[1] : null;
	unset($name); $name = isset($_args[2]) ? $_args[2] : null;
	unset($mName); $mName = isset($_args[3]) ? $_args[3] : null;
	unset($point); $point = isset($_args[4]) ? $_args[4] : null;
	unset($str); $str = isset($_args[5]) ? $_args[5] : null;
	logOut("{$HtagName_}{$name}{$point}{$H_tagName}의<B>괴수$mName</B>는 $str",$id, $tId);
}


/*
 * 함수: logMonsMove()
 * 역할: 괴수 이동 로그입니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logMonsMove() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $tId, $name, $lName, $point, $mName, $HtagName_, $H_tagName;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($tId); $tId = isset($_args[1]) ? $_args[1] : null;
	unset($name); $name = isset($_args[2]) ? $_args[2] : null;
	unset($lName); $lName = isset($_args[3]) ? $_args[3] : null;
	unset($point); $point = isset($_args[4]) ? $_args[4] : null;
	unset($mName); $mName = isset($_args[5]) ? $_args[5] : null;
	logOut("{$HtagName_}{$name}{$point}{$H_tagName}의<B>$lName</B>가<B>괴수 $mName</B>에 밟아 망쳐졌습니다. ",$id, $tId);
}


/*
 * 함수: logMonsMoveDefence()
 * 역할: 괴수가 방위 시설을 밟은 로그입니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logMonsMoveDefence() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $tId, $name, $lName, $point, $mName, $HtagName_, $H_tagName;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($tId); $tId = isset($_args[1]) ? $_args[1] : null;
	unset($name); $name = isset($_args[2]) ? $_args[2] : null;
	unset($lName); $lName = isset($_args[3]) ? $_args[3] : null;
	unset($point); $point = isset($_args[4]) ? $_args[4] : null;
	unset($mName); $mName = isset($_args[5]) ? $_args[5] : null;
	logOut2("<B>괴수 $mName</B>가{$HtagName_}{$name}{$point}{$H_tagName}의<B>$lName</B>에 도달,<B>{$lName}의 자폭 장치가 작동! </B>",$id, $tId);
}


/*
 * 함수: logFire()
 * 역할: 화재 로그입니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logFire() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $name, $lName, $point, $HtagName_, $H_tagName, $HtagDisaster_, $H_tagDisaster;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($name); $name = isset($_args[1]) ? $_args[1] : null;
	unset($lName); $lName = isset($_args[2]) ? $_args[2] : null;
	unset($point); $point = isset($_args[3]) ? $_args[3] : null;
	logOut("{$HtagName_}{$name}{$point}{$H_tagName}의<B>$lName</B>가{$HtagDisaster_}화재{$H_tagDisaster}에 의해 괴멸 했습니다. ",$id);
}


/*
 * 함수: logMaizo()
 * 역할: 매장금 발견 로그입니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logMaizo() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $tId, $name, $tName, $comName, $value, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName, $HunitMoney;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($tId); $tId = isset($_args[1]) ? $_args[1] : null;
	unset($name); $name = isset($_args[2]) ? $_args[2] : null;
	unset($tName); $tName = isset($_args[3]) ? $_args[3] : null;
	unset($comName); $comName = isset($_args[4]) ? $_args[4] : null;
	unset($value); $value = isset($_args[5]) ? $_args[5] : null;
	logOut("{$HtagName_}{$name}{$H_tagName}에 의한{$HtagName_}{$tName}{$H_tagName}에서의{$HtagComName_}{$comName}{$H_tagComName}중에,<B>$value{$HunitMoney}의 매장금</B>이 발견되었습니다. ",$id,$tId);
}

/*
 * 함수: logGold()
 * 역할: 금광 발견 로그입니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logGold() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $tId, $name, $tName, $comName, $value, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName, $HunitMoney;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($tId); $tId = isset($_args[1]) ? $_args[1] : null;
	unset($name); $name = isset($_args[2]) ? $_args[2] : null;
	unset($tName); $tName = isset($_args[3]) ? $_args[3] : null;
	unset($comName); $comName = isset($_args[4]) ? $_args[4] : null;
	unset($value); $value = isset($_args[5]) ? $_args[5] : null;
	logOut("{$HtagName_}{$name}{$H_tagName}에 의한{$HtagName_}{$tName}{$H_tagName}에서의{$HtagComName_}{$comName}{$H_tagComName}중에 금광맥발견,<B>$value$HunitMoney 상당한 금</B>이 채굴되었습니다. ",$id,$tId);
}


/*
 * 함수: logEarthquake()
 * 역할: 지진 로그입니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logEarthquake() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $name, $point, $HtagName_, $H_tagName, $HtagDisaster_, $H_tagDisaster;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($name); $name = isset($_args[1]) ? $_args[1] : null;
	unset($point); $point = isset($_args[2]) ? $_args[2] : null;
	logOut("{$HtagName_}{$name}{$point}{$H_tagName}로 대규모{$HtagDisaster_}지진{$H_tagDisaster}가 발생! ",$id);
}


/*
 * 함수: logSvDamage()
 * 역할: 식량/자원 피해 로그입니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logSvDamage() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $tId, $name, $tName, $lName, $point, $HtagName_, $H_tagName;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($tId); $tId = isset($_args[1]) ? $_args[1] : null;
	unset($name); $name = isset($_args[2]) ? $_args[2] : null;
	unset($tName); $tName = isset($_args[3]) ? $_args[3] : null;
	unset($lName); $lName = isset($_args[4]) ? $_args[4] : null;
	unset($point); $point = isset($_args[5]) ? $_args[5] : null;
	logOut("{$HtagName_}{$tName}{$point}{$H_tagName}의<B>$lName</B>에<B>식량을 요구해{$name}의 주민이 쇄도</B>. <B>$lName</B>는 괴멸 했습니다. ",$id,$tId);
}


/*
 * 함수: logTsunami()
 * 역할: 해일 로그입니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logTsunami() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $name, $point, $HtagName_, $H_tagName, $HtagDisaster_, $H_tagDisaster;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($name); $name = isset($_args[1]) ? $_args[1] : null;
	unset($point); $point = isset($_args[2]) ? $_args[2] : null;
	logOut("{$HtagName_}{$name}{$point}{$H_tagName}로{$HtagDisaster_}해일{$H_tagDisaster}발생! ",$id);
}


/*
 * 함수: logDamage()
 * 역할: 일반 재해 피해 로그입니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logDamage() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $tId, $name, $tName, $lName, $point, $str, $HtagName_, $H_tagName, $HtagDisaster_, $H_tagDisaster;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($tId); $tId = isset($_args[1]) ? $_args[1] : null;
	unset($name); $name = isset($_args[2]) ? $_args[2] : null;
	unset($tName); $tName = isset($_args[3]) ? $_args[3] : null;
	unset($lName); $lName = isset($_args[4]) ? $_args[4] : null;
	unset($point); $point = isset($_args[5]) ? $_args[5] : null;
	unset($str); $str = isset($_args[6]) ? $_args[6] : null;
	logOut("{$HtagName_}{$tName}{$point}{$H_tagName}의<B>$lName</B>는{$HtagName_}{$name}{$H_tagName}로 발생한{$HtagDisaster_}{$str}{$H_tagDisaster}에 의해 괴멸 했습니다. ",$id,$tId);
}


/*
 * 함수: logMeteo()
 * 역할: 운석 로그입니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logMeteo() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $name, $lName, $point, $str, $HtagName_, $H_tagName, $HtagDisaster_, $H_tagDisaster;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($name); $name = isset($_args[1]) ? $_args[1] : null;
	unset($lName); $lName = isset($_args[2]) ? $_args[2] : null;
	unset($point); $point = isset($_args[3]) ? $_args[3] : null;
	unset($str); $str = isset($_args[4]) ? $_args[4] : null;
	logOut("{$HtagName_}{$name}{$point}{$H_tagName}지점의<B>$lName</B>에{$HtagDisaster_}운석{$H_tagDisaster}가 낙하{$str}。",$id);
}


/*
 * 함수: logHugeMeteo()
 * 역할: 거대 운석 로그입니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logHugeMeteo() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $name, $point, $HtagName_, $H_tagName, $HtagDisaster_, $H_tagDisaster;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($name); $name = isset($_args[1]) ? $_args[1] : null;
	unset($point); $point = isset($_args[2]) ? $_args[2] : null;
	logOut2("{$HtagName_}{$name}{$point}{$H_tagName}지점에{$HtagDisaster_}거대 운석{$H_tagDisaster}가 낙하! ",$id);
}


/*
 * 함수: logEruption()
 * 역할: 화산 분화 로그입니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logEruption() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $name, $lName, $point, $HtagName_, $H_tagName, $HtagDisaster_, $H_tagDisaster;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($name); $name = isset($_args[1]) ? $_args[1] : null;
	unset($lName); $lName = isset($_args[2]) ? $_args[2] : null;
	unset($point); $point = isset($_args[3]) ? $_args[3] : null;
	logOut("{$HtagName_}{$name}{$point}{$H_tagName}지점에서{$HtagDisaster_}화산이 분화{$H_tagDisaster},<B>산</B>을 생겼습니다. ",$id);
}


/*
 * 함수: logEruptionNormal()
 * 역할: 화산 분화 후 일반 지형 변화 로그입니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logEruptionNormal() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $tId, $name, $lName, $point, $HtagName_, $H_tagName, $HtagDisaster_, $H_tagDisaster, $str;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($tId); $tId = isset($_args[1]) ? $_args[1] : null;
	unset($name); $name = isset($_args[2]) ? $_args[2] : null;
	unset($lName); $lName = isset($_args[3]) ? $_args[3] : null;
	unset($point); $point = isset($_args[4]) ? $_args[4] : null;
	logOut("{$HtagName_}{$name}{$point}{$H_tagName}지점의<B>$lName</B>는,{$HtagDisaster_}분화{$H_tagDisaster}의 영향으로{$str}。",$id, $tId);
}


/*
 * 함수: logWideDamageSea()
 * 역할: 광역 피해로 바다가 된 로그입니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logWideDamageSea() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $tId, $name, $lName, $point, $HtagName_, $H_tagName;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($tId); $tId = isset($_args[1]) ? $_args[1] : null;
	unset($name); $name = isset($_args[2]) ? $_args[2] : null;
	unset($lName); $lName = isset($_args[3]) ? $_args[3] : null;
	unset($point); $point = isset($_args[4]) ? $_args[4] : null;
	logOut2("{$HtagName_}{$name}{$point}{$H_tagName}의<B>$lName</B>는<B>수몰</B>했습니다. ",$id, $tId);
}


/*
 * 함수: logWideDamageSea2()
 * 역할: 광역 피해로 해저/수몰된 로그입니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logWideDamageSea2() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $tId, $name, $lName, $point, $HtagName_, $H_tagName;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($tId); $tId = isset($_args[1]) ? $_args[1] : null;
	unset($name); $name = isset($_args[2]) ? $_args[2] : null;
	unset($lName); $lName = isset($_args[3]) ? $_args[3] : null;
	unset($point); $point = isset($_args[4]) ? $_args[4] : null;
	logOut2("{$HtagName_}{$name}{$point}{$H_tagName}의<B>$lName</B>는 흔적도 없어졌습니다. ",$id, $tId);
}


/*
 * 함수: logWideDamageMonsterSea()
 * 역할: 광역 피해로 괴수가 바다에 빠진 로그입니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logWideDamageMonsterSea() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $tId, $name, $lName, $point, $HtagName_, $H_tagName;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($tId); $tId = isset($_args[1]) ? $_args[1] : null;
	unset($name); $name = isset($_args[2]) ? $_args[2] : null;
	unset($lName); $lName = isset($_args[3]) ? $_args[3] : null;
	unset($point); $point = isset($_args[4]) ? $_args[4] : null;
	logOut2("{$HtagName_}{$name}{$point}{$H_tagName}의 육지는<B>괴수 $lName</B>와 수몰 했습니다. ",$id, $tId);
}


/*
 * 함수: logWideDamageMonster()
 * 역할: 광역 피해로 괴수가 피해를 입은 로그입니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logWideDamageMonster() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $tId, $name, $lName, $point, $HtagName_, $H_tagName;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($tId); $tId = isset($_args[1]) ? $_args[1] : null;
	unset($name); $name = isset($_args[2]) ? $_args[2] : null;
	unset($lName); $lName = isset($_args[3]) ? $_args[3] : null;
	unset($point); $point = isset($_args[4]) ? $_args[4] : null;
	logOut2("{$HtagName_}{$name}{$point}{$H_tagName}의<B>괴수 $lName</B>는 날아가 버렸습니다. ",$id, $tId);
}


/*
 * 함수: logWideDamageWaste()
 * 역할: 광역 피해로 황무지가 된 로그입니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logWideDamageWaste() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $tId, $name, $lName, $point, $HtagName_, $H_tagName;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($tId); $tId = isset($_args[1]) ? $_args[1] : null;
	unset($name); $name = isset($_args[2]) ? $_args[2] : null;
	unset($lName); $lName = isset($_args[3]) ? $_args[3] : null;
	unset($point); $point = isset($_args[4]) ? $_args[4] : null;
	logOut2("{$HtagName_}{$name}{$point}{$H_tagName}의<B>$lName</B>는 한순간에<B>황무지</B>화했습니다. ",$id, $tId);
}


/*
 * 함수: logPrize()
 * 역할: 수상/상장 로그입니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logPrize() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $name, $pName, $HtagName_, $H_tagName;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($name); $name = isset($_args[1]) ? $_args[1] : null;
	unset($pName); $pName = isset($_args[2]) ? $_args[2] : null;
	logOut("{$HtagName_}{$name}{$H_tagName}가<B>$pName</B>를 수상했습니다. ",$id);
	logHistory("{$HtagName_}{$name}{$H_tagName}、<B>$pName</B>를 수상");
}

/*
 * 함수: logPrizeV()
 * 역할: 상 수여 조건 표시 로그입니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logPrizeV() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $name, $pName, $HtagName_, $H_tagName;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($name); $name = isset($_args[1]) ? $_args[1] : null;
	unset($pName); $pName = isset($_args[2]) ? $_args[2] : null;
	logOut("{$HtagName_}{$name}{$H_tagName}가<B>$pName</B>가 수여되었습니다. ",$id);
}

/*
 * 함수: logAnnihilation()
 * 역할: 완전 멸망/소멸 로그입니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logAnnihilation() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $name, $point, $HtagName_, $H_tagName;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($name); $name = isset($_args[1]) ? $_args[1] : null;
	unset($point); $point = isset($_args[2]) ? $_args[2] : null;
	logOut("{$HtagName_}{$name}{$point}{$H_tagName}의 부대는,<B>전멸</B>했습니다. ",$id);
}


/*
 * 함수: logSoldierLvUp()
 * 역할: 부대 레벨 상승 로그입니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logSoldierLvUp() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $name, $point, $HtagName_, $H_tagName;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($name); $name = isset($_args[1]) ? $_args[1] : null;
	unset($point); $point = isset($_args[2]) ? $_args[2] : null;
	logOut("{$HtagName_}{$name}{$point}{$H_tagName}의 부대는,<B>레벨업</B>했습니다. ",$id);
}


/*
 * 함수: logSoldierDamage()
 * 역할: 부대 피해 로그입니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logSoldierDamage() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $x, $y, $cause, $pt, $tIsland, $Hislands, $HidToNumber, $name, $ofname, $HtagName_, $H_tagName, $HlandHGr, $Fdivision, $HlandDiv, $HtagDisaster_, $HunitPop, $H_tagDisaster;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($x); $x = isset($_args[1]) ? $_args[1] : null;
	unset($y); $y = isset($_args[2]) ? $_args[2] : null;
	unset($cause); $cause = isset($_args[3]) ? $_args[3] : null;
	unset($pt); $pt = isset($_args[4]) ? $_args[4] : null;
	$tIsland =& $Hislands[$HidToNumber[$id]];
	$name = $tIsland['name'];
	$ofname = $tIsland['fleet'];
	if ($pt == 0) {
		logOut($HtagName_ . $name . "($x, $y)" . $H_tagName . $ofname[$HlandHGr[$x][$y]-1] . " " . $Fdivision[$HlandDiv[$x][$y]] . "는," . $cause . "이기 때문에<B>전멸</B>했습니다. ",$id);
	} else{
		logOut($HtagName_ . $name . "($x, $y)" . $H_tagName . $ofname[$HlandHGr[$x][$y]-1] . " " . $Fdivision[$HlandDiv[$x][$y]] . "는," . $cause . "이기 때문에" . $HtagDisaster_ . $pt . $HunitPop . $H_tagDisaster . "가 사상했습니다. ",$id);
	}
}


/*
 * 함수: landName()
 * 역할: 지형 번호와 세부값을 화면 표시용 지형명으로 변환합니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function landName() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $land, $lv, $HlandSea, $HlandWaste, $HlandPlains, $HlandTown, $HlandForest, $HlandFarm, $HlandFactory, $HlandBase, $HlandDefence, $HlandMountain, $HlandMonster, $kind, $name, $hp, $HlandSbase, $HlandMonument, $HmonumentName, $HlandSupply;
$_args = func_get_args();
	unset($land); $land = isset($_args[0]) ? $_args[0] : null;
	unset($lv); $lv = isset($_args[1]) ? $_args[1] : null;
	if ($land == $HlandSea) {
		if ($lv == 1) {
			return '얕은 여울';
		} else{
			return '바다';
		}
	} elseif ($land == $HlandWaste) {
		return '황무지';
	} elseif ($land == $HlandPlains) {
		return '평지';
	} elseif ($land == $HlandTown) {
		if ($lv < 30) {
			return '마을';
		} elseif ($lv < 100) {
			return '마을';
		} else{
			return '도시';
		}
	} elseif ($land == $HlandForest) {
		return '숲';
	} elseif ($land == $HlandFarm) {
		return '농장';
	} elseif ($land == $HlandFactory) {
		return '공장';
	} elseif ($land == $HlandBase) {
		return '미사일 기지';
	} elseif ($land == $HlandDefence) {
		return '방위시설';
	} elseif ($land == $HlandMountain) {
		return '산';
	} elseif ($land == $HlandMonster) {
		$kind = monsterSpec($lv);
		unset($name); $name = isset($_list_tmp[1]) ? $_list_tmp[1] : null;
		unset($hp); $hp = isset($_list_tmp[2]) ? $_list_tmp[2] : null;
		return $name;
	} elseif ($land == $HlandSbase) {
		return '해저 기지';
	} elseif ($land == $HlandMonument) {
		return $HmonumentName[$lv];
	} elseif ($land == $HlandSupply) {
		return '병참기지';
	}
}


/*
 * 함수: estimate()
 * 역할: 섬 전체의 인구/식량/자금/면적/병력 등 평가값을 계산합니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function estimate(&$island, $mode=null) {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $pop, $area, $farm, $factory, $mountain, $supply, $pwct, $itemF, $id, $soldier, $HislandTurn, $HturnPrizeUnit, $i, $FSItemID, $x, $y, $kind, $value, $owner, $mpower, $HislandSize, $Hland, $HlandValue, $HlandOwner;
    global $HlandDivPw, $HlandDivNa, $HlandDiv, $HlandDivItem, $HlandSea, $HlandSbase, $ForceFlgMove, $HlandTown, $HlandSupply, $HlandMonument, $HlandForest, $HlandBase, $HlandDefence, $HlandFarm, $HlandFactory, $HlandMountain;
$_args = func_get_args();
	$_list_tmp = array(0,0,0,0,0, 0,0,0);
	unset($pop); $pop = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
	unset($area); $area = isset($_list_tmp[1]) ? $_list_tmp[1] : null;
	unset($farm); $farm = isset($_list_tmp[2]) ? $_list_tmp[2] : null;
	unset($factory); $factory = isset($_list_tmp[3]) ? $_list_tmp[3] : null;
	unset($mountain); $mountain = isset($_list_tmp[4]) ? $_list_tmp[4] : null;
	unset($supply); $supply = isset($_list_tmp[5]) ? $_list_tmp[5] : null;
	unset($pwct); $pwct = isset($_list_tmp[6]) ? $_list_tmp[6] : null;
	unset($itemF); $itemF = isset($_list_tmp[7]) ? $_list_tmp[7] : null;

	
	$_list_tmp = array($island['id'],$island['soldier']);
	unset($id); $id = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
	unset($soldier); $soldier = isset($_list_tmp[1]) ? $_list_tmp[1] : null;

	
	if (($mode == 0) && (($HislandTurn % $HturnPrizeUnit) == 0)) {
		
		$island['statistical'][3] = $island['statistical'][1] - $island['statistical'][2];
		
		$island['statistical'][4] = $island['statistical'][2] - $island['statistical'][1];
		for ($i = 0; $i < 16; $i++) {
			
			$island['statistical2'][$i] = $island['statistical'][$i];
			$island['statistical'][$i] = 0;
		}
		if ($HislandTurn != $HturnPrizeUnit) {
			
			$itemF = 1;
			for ($i = 0; $i < 16; $i++) {
				if ($FSItemID[$i] != 2) { $island['item'][$i] = 0; }
			}
		}
	}

	
	unset($x); $x = null;
	unset($y); $y = null;
	unset($kind); $kind = null;
	unset($value); $value = null;
	unset($owner); $owner = null;
	unset($mpower); $mpower = array();
	for ($y = 0; $y < $HislandSize; $y++) {
	for ($x = 0; $x < $HislandSize; $x++) {
		$kind = $Hland[$x][$y];
		$value = $HlandValue[$x][$y];
		$owner = $HlandOwner[$x][$y];

		if (($HlandDivPw[$x][$y] > 0) && ($id == $HlandDivNa[$x][$y])) {
			$soldier += $HlandDivPw[$x][$y];
			$mpower[$HlandDiv[$x][$y]] += $HlandDivPw[$x][$y];
			
			if ($itemF) { $HlandDivItem[$x][$y] = 0; }
		}
		if ($owner != $id) { continue; }

		if (($kind != $HlandSea) && ($kind != $HlandSbase)) {
			$area++;
			$__divNa = isset($HlandDivNa[$x][$y]) ? $HlandDivNa[$x][$y] : 0;
				if (($id != $__divNa) && isset($island['YU'][$__divNa]) && ($island['YU'][$__divNa] > 3)) {
				
				$ForceFlgMove[$x][$y] = 99;
			}
			if ($kind == $HlandTown) {
				
				$pop += $value;
			} elseif ($kind == $HlandSupply) {
				
				$supply++;
			} elseif ($kind == $HlandMonument) {
				
				$pwct += 30;
			} elseif ($kind == $HlandForest) {
				
				$pwct += $value * 3 + 20;
			} elseif ($kind == $HlandBase) {
				
				$pwct += expToLevel2($kind, $value) * 80;
			} elseif ($kind == $HlandDefence) {
				
				$pwct += 120;
			} elseif (($mode) && ($HlandDivPw[$x][$y] > 49) && ($id != $HlandDivNa[$x][$y])) {
				
			} elseif ($kind == $HlandFarm) {
				
				$farm += $value;
			} elseif ($kind == $HlandFactory) {
				
				$factory += $value;
			} elseif ($kind == $HlandMountain) {
				
				$mountain += $value;
			}
		} elseif ($kind == $HlandSbase) {
			
			$pwct += expToLevel2($kind, $value) * 100;
		}
	}
	}

	
	$island['pop']      = $pop;
	$island['area']     = $area;
	$island['farm']     = $farm;
	$island['factory']  = $factory;
	$island['mountain'] = $mountain;
	$island['sol']      = $soldier; 
	$island['popsol']   = $pop + $soldier;
	$island['mpower']   = $mpower; 
	$island['pwct']     = $pwct;
	
	if ($soldier > 0) { $island['hohei'] = ((isset($mpower[0]) ? $mpower[0] : 0) * 100) / $soldier; }
	
	if ($area > 0) { $island['heitan'] = ($supply * 100) / $area; }
}



/*
 * 함수: countAround()
 * 역할: 지정 좌표 주변의 특정 지형 개수를 셉니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function countAround() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $x, $y, $kind, $range, $i, $count, $sx, $sy, $ax, $ay, $Hroundmode, $correct, $HislandSize, $HlandSea, $Hland;
$_args = func_get_args();
	unset($x); $x = isset($_args[0]) ? $_args[0] : null;
	unset($y); $y = isset($_args[1]) ? $_args[1] : null;
	unset($kind); $kind = isset($_args[2]) ? $_args[2] : null;
	unset($range); $range = isset($_args[3]) ? $_args[3] : null;
	unset($i); $i = null;
	unset($count); $count = null;
	unset($sx); $sx = null;
	unset($sy); $sy = null;
	$count = 0;
	for ($i = 0; $i < $range; $i++) {
		$sx = $x + $ax[$i];
		$sy = $y + $ay[$i];
		if (!($sy % 2) && ($y % 2)) { $sx--; }
		if ($Hroundmode) {
			$sx = $correct[$sx + 12];
			$sy = $correct[$sy + 12];
		}
		if (($sx < 0) || ($sx >= $HislandSize) || ($sy < 0) || ($sy >= $HislandSize)) {
			
			if ($kind == $HlandSea) { $count++; }
		} else{
			
			if ($Hland[$sx][$sy] == $kind) { $count++; }
		}
	}
	return $count;
}


/*
 * 함수: countAroundTerritory()
 * 역할: 지정 좌표 주변 영토/소유권 상태를 셉니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function countAroundTerritory() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $x, $y, $id, $range, $i, $count, $sx, $sy, $ax, $ay, $Hroundmode, $correct, $HislandSize, $HlandOwner;
$_args = func_get_args();
	unset($x); $x = isset($_args[0]) ? $_args[0] : null;
	unset($y); $y = isset($_args[1]) ? $_args[1] : null;
	unset($id); $id = isset($_args[2]) ? $_args[2] : null;
	unset($range); $range = isset($_args[3]) ? $_args[3] : null;
	unset($i); $i = null;
	unset($count); $count = null;
	unset($sx); $sx = null;
	unset($sy); $sy = null;
	$count = 0;
	for ($i = 0; $i < $range; $i++) {
		$sx = $x + $ax[$i];
		$sy = $y + $ay[$i];
		if (!($sy % 2) && ($y % 2)) { $sx--; }
		if ($Hroundmode) {
			$sx = $correct[$sx + 12];
			$sy = $correct[$sy + 12];
		}
		if (($sx < 0) || ($sx >= $HislandSize) || ($sy < 0) || ($sy >= $HislandSize)) {
			
		} else{
			
			if ($HlandOwner[$sx][$sy] == $id) { $count++; }
		}
	}
	return $count;
}


/*
 * 함수: countAroundArmy()
 * 역할: 지정 좌표 주변 부대 존재/소속 상태를 셉니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function countAroundArmy() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $x, $y, $id, $range, $i, $sx, $sy, $tId, $ct1, $ct2, $ct3, $ct4, $ax, $ay, $Hroundmode, $correct, $HislandSize, $HlandDivNa, $HlandDivPw, $tIsland, $Hislands, $HidToNumber, $FzocFlg, $HlandDiv;
    global $FItemID, $HlandDivItem;
$_args = func_get_args();
	unset($x); $x = isset($_args[0]) ? $_args[0] : null;
	unset($y); $y = isset($_args[1]) ? $_args[1] : null;
	unset($id); $id = isset($_args[2]) ? $_args[2] : null;
	unset($range); $range = isset($_args[3]) ? $_args[3] : null;
	unset($i); $i = null;
	unset($sx); $sx = null;
	unset($sy); $sy = null;
	unset($tId); $tId = null;
	$_list_tmp = array(0,0,0,0);
	unset($ct1); $ct1 = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
	unset($ct2); $ct2 = isset($_list_tmp[1]) ? $_list_tmp[1] : null;
	unset($ct3); $ct3 = isset($_list_tmp[2]) ? $_list_tmp[2] : null;
	unset($ct4); $ct4 = isset($_list_tmp[3]) ? $_list_tmp[3] : null;
	for ($i = 1; $i < $range; $i++) {
		$sx = $x + $ax[$i];
		$sy = $y + $ay[$i];
		if (!($sy % 2) && ($y % 2)) { $sx--; }
		if ($Hroundmode) {
			$sx = $correct[$sx + 12];
			$sy = $correct[$sy + 12];
		}
		if (($sx < 0) || ($sx >= $HislandSize) || ($sy < 0) || ($sy >= $HislandSize)) {
			
		} else{
			
			$tId = $HlandDivNa[$sx][$sy];
			if ($HlandDivPw[$sx][$sy] > 0) {
				$tIsland =& $Hislands[$HidToNumber[$tId]];
				if ($tId == $id) {
					
					$ct1++;
				} elseif ($tIsland['YU'][$id] > 2) {
					
					$ct2++;
				} elseif ($FzocFlg[$HlandDiv[$sx][$sy]]) {
					
					$ct4++;
				} elseif ($FItemID[$HlandDivItem[$sx][$sy]] == 5) {
					
					$ct4++;
				} else{
					
					$ct3++;
				}
			}
		}
	}
	return array($ct1, $ct2, $ct3, $ct4);
}


/*
 * 함수: chkWarIsland()
 * 역할: 두 섬이 전쟁 상태인지 검사합니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function chkWarIsland() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $id, $tId, $HragnarokTurn, $HislandTurn, $i, $HwarIsland, $tn1, $HidToNumber, $tn2, $Hislands;
$_args = func_get_args();
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	unset($tId); $tId = isset($_args[1]) ? $_args[1] : null;
	if (($HragnarokTurn > 0) && ($HragnarokTurn <= $HislandTurn)) {
		
		return 2;
	}
	if (($id == 0) || ($tId == 0)) { return 2; }
	unset($i); $i = null;
	for ($i=0;$i < hako_last_index($HwarIsland);$i+=4) {
		$tn1 = $HidToNumber[$HwarIsland[$i+1]];
		$tn2 = $HidToNumber[$HwarIsland[$i+2]];
		if ((($tn1 === '' || $tn1 === null)) || (($tn2 === '' || $tn2 === null))) {
			hako_splice($HwarIsland, $i, 4);
			$i-=4;
			continue;
		}
		if ((($Hislands[$tn1]['id'] == $id) && ($Hislands[$tn2]['id'] == $tId)) ||
			(($Hislands[$tn1]['id'] == $tId) && ($Hislands[$tn2]['id'] == $id))) {
			if ($HwarIsland[$i] > $HislandTurn) {
				
				return 1;
			} else{
				return 2;
			}
		}
	}
	return 0;
}


/*
 * 함수: randomArray()
 * 역할: 0부터 n-1까지의 값을 중복 없이 섞은 배열을 반환합니다.
 * 원본 대응: hako/hako-turn.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function randomArray() {
        // PHP 5.5 공유호스팅 턴 처리 속도 보정을 위해 이 함수에서 실제 사용하는 전역만 가져옵니다.
    global $n, $list, $i, $j, $tmp;
$_args = func_get_args();
	unset($n); $n = isset($_args[0]) ? $_args[0] : null;
	unset($list); $list = array();
	unset($i); $i = null;

	
	if ($n == 0) { $n = 1; }
	$list = range(0, $n - 1);

	
	for ($i = $n; --$i; ) {
		unset($j); $j = intval(hako_rand($i + 1));
		if ($i == $j) { continue; }
		$tmp = $list[$i];
		$list[$i] = $list[$j];
		$list[$j] = $tmp;
	}

	return $list;
}

?>
