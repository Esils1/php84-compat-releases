<?php

/*
 * hako/hako-io.php
 * ------------------------------------------------------------
 * 공통 입력/비밀번호/출력/접근 로그 모듈
 *
 * 상세 주석 기준:
 * - 원본 대응: qwmp155.zip 의 hako-io.cgi.
 * - 공통 초기화, 섬 목록 생성, 비밀번호 확인, 마스터/특수 비밀번호 확인, HTML 출력, 접근 로그를 담당합니다.
 * - out() 출력은 화면 동일성의 핵심이므로 출력 버퍼 처리나 자동 개행을 임의 변경하지 마십시오.
 * - 암호화 방식은 기존 저장 파일 호환을 위한 것이며 새 보안 로직을 추가하지 않습니다.
 * - 원본 CGI 주석 라인 확인 수: 40줄. PHP 주석은 실행 결과를 바꾸지 않는 범위에서 복원/보강했습니다.
 *
 * 유지보수 원칙:
 * - 실행 로직, 저장 포맷, 배열 인덱스, 출력 HTML은 원본 CGI 호환성 대상입니다.
 * - 개조가 필요하면 먼저 해당 변수/함수가 어떤 파일 저장값과 연결되는지 확인하십시오.
 * - 이 주석은 유지보수용이며 실행 결과를 바꾸지 않습니다.
 */

chdir(dirname(__FILE__));
require_once dirname(__FILE__) . '/hako-compat.php';












/*
 * 함수: tempInitialize()
 * 역할: 공통 초기화 후 섬 목록/쿠키/입력값을 준비합니다.
 * 원본 대응: hako/hako-io.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function tempInitialize() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	
	$HislandList = getIslandList($defaultID);
	$HtargetList = getIslandList($defaultTarget);
	if ($HislandTurn <= $HdiscountTurn) {
		
		$HcomCost[$HcomMissileLD] = 200;
		$HcomCost[$HcomSendMonster]= 5000;
	}
}


/*
 * 함수: getIslandList()
 * 역할: 풀다운 메뉴용 섬 목록을 생성합니다.
 * 원본 대응: hako/hako-io.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function getIslandList() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	unset($select); $select = isset($_args[0]) ? $_args[0] : null;
	unset($list); $list = null;
	unset($name); $name = null;
	unset($id); $id = null;
	unset($s); $s = null;
	unset($i); $i = null;

	
	$list = '';
	for ($i = 0; $i < $HislandNumber; $i++) {
		$name = $Hislands[$i]['name'];
		$id = $Hislands[$i]['id'];
		if ($Hallyflg) {
			$ally = isset($Hislands[$i]['ally']) ? $Hislands[$i]['ally'] : 0;
			$ally = isset($Hallymark[$ally]) ? $Hallymark[$ally] . " " : "";
		} else{
			$ally = "";
		}
		if ($id == $select) {
			$s = 'SELECTED';
		} else {
			$s = '';
		}
		$list .= "<OPTION VALUE=\"$id\" $s>{$ally}{$name}\n";
	}
	return $list;
}


/*
 * 함수: getJsIslandList()
 * 역할: JavaScript용 섬 목록 데이터를 생성합니다.
 * 원본 대응: hako/hako-io.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function getJsIslandList() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	unset($set_island); $set_island = null;
	unset($l_name); $l_name = null;
	unset($l_id); $l_id = null;
	unset($l_ally); $l_ally = null;
	$set_island = "'0':'$HidToName[0]',\n";
	for ($i = 0; $i < $HislandNumber; $i++) {
		$l_name = $Hislands[$i]['name'];
		hako_subst($l_name, '~\'~', '\\\\\'');
		$l_id = $Hislands[$i]['id'];
		if ($Hallyflg) {
			$l_ally = $Hislands[$i]['ally'];
			$l_ally = isset($Hallymark[$l_ally]) ? $Hallymark[$l_ally] . " " : "";
		} else{
			$l_ally = "";
		}
		if ($i == $HislandNumber-1) {
			$set_island .= "'$l_id':'$l_ally$l_name'";
		} else{
			$set_island .= "'$l_id':'$l_ally$l_name',\n";
		}
	}
	return $set_island;
}





/*
 * 함수: checkPassword()
 * 역할: 섬 비밀번호를 확인합니다.
 * 원본 대응: hako/hako-io.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function checkPassword() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	unset($p1); $p1 = isset($_args[0]) ? $_args[0] : null;
	unset($p2); $p2 = isset($_args[1]) ? $_args[1] : null;

	
	if ($p2 == '') { return 0; }

	
	if (checkMasterPassword($p2)) { return 2; }

	
	if ($p1 == encode($p2)) { return 1; }

	return 0;
}


/*
 * 함수: checkMasterPassword()
 * 역할: 관리자 마스터 비밀번호를 확인합니다.
 * 원본 대응: hako/hako-io.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function checkMasterPassword() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	unset($pass); $pass = isset($_args[0]) ? $_args[0] : null;
	return (crypt((string)$pass, 'ma') == $HmasterPassword);
}


/*
 * 함수: checkSpecialPassword()
 * 역할: 특수 비밀번호를 확인합니다.
 * 원본 대응: hako/hako-io.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function checkSpecialPassword() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	unset($pass); $pass = isset($_args[0]) ? $_args[0] : null;
	return (crypt((string)$pass, 'sp') == $HspecialPassword || crypt((string)$pass, 'ma') == $HmasterPassword);
}


/*
 * 함수: encode()
 * 역할: 원본과 호환되는 비밀번호 인코딩을 수행합니다.
 * 원본 대응: hako/hako-io.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function encode() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	unset($pass); $pass = isset($_args[0]) ? $_args[0] : null;
	return ($cryptOn ? crypt((string)$pass, 'h2') : (string)$pass);
}


/*
 * 함수: tempWrongPassword()
 * 역할: 비밀번호 오류 화면을 출력합니다.
 * 원본 대응: hako/hako-io.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function tempWrongPassword() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	Dummyfunction();
	if ($HinputPassword == '') {
		tempWrong("패스워드를 잊고 있지 않습니까? "); 
		if ($HtopAxes && $HtopAxes != 3) { axeslog(2, 'NoPass error!'); }
		return;
	}
	if ($HtopAxes && $HtopAxes != 3) { axeslog(2, 'PASS error!'); }
	out(<<<HAKOHDOC_0
<span class="big">패스워드가 다릅니다.
<A HREF=\"$HthisFile\">탑에 돌아온다</span></A>
HAKOHDOC_0
);
	if ($HpassError) {
		unset($agent); $agent = hako_get_env('HTTP_USER_AGENT');
		unset($addr); $addr = hako_get_env('REMOTE_ADDR');
		unset($host); $host = hako_get_env('REMOTE_HOST');
		if ($gethostbyaddr && (($host == '') || ($host == $addr))) {
			$host = gethostbyaddr($addr) ? gethostbyaddr($addr) : $addr;
		} elseif ($host == '') {
			$host = $addr;
		}
		$_list_tmp = hako_localtime(time());
		unset($sec); $sec = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
		unset($min); $min = isset($_list_tmp[1]) ? $_list_tmp[1] : null;
		unset($hour); $hour = isset($_list_tmp[2]) ? $_list_tmp[2] : null;
		unset($mday); $mday = isset($_list_tmp[3]) ? $_list_tmp[3] : null;
		unset($mon); $mon = isset($_list_tmp[4]) ? $_list_tmp[4] : null;
		unset($year); $year = isset($_list_tmp[5]) ? $_list_tmp[5] : null;
		unset($wday); $wday = isset($_list_tmp[6]) ? $_list_tmp[6] : null;
		unset($yday); $yday = isset($_list_tmp[7]) ? $_list_tmp[7] : null;
		unset($isdst); $isdst = isset($_list_tmp[8]) ? $_list_tmp[8] : null;
		$__days = array('일','월','화','수','목','금','토');
		unset($day); $day = $__days[$wday];
		$year = $year + 1900;
		$mon = $mon + 1;
		unset($date); $date = sprintf("%04d/%02d/%02d(%s) %02d:%02d:%02d", $year,$mon,$mday,$day,$hour,$min,$sec);
		out(<<<HAKOHDOC_1
<HR>
<TABLE><TR><TH><span class="big">【{$HtagDisaster_}! 경고!{$H_tagDisaster}】</span></TH></TR>
<TR><TD>당신의 정보를 기록했습니다.
　$date<BR>　<B>$host - $addr - $agent</B>
</TD></TR>
<TR><TD class='N'>
<BR>　<A HREF='http://www.ipa.go.jp/security/ciadr/law199908.html' target='_blank'><B>부정 액세스 행위의 금지등에 관한 법률</B></A> 이 2001년 2월 13일에 시행되었습니다.
<BR><BR>　이 법률은, 하이테크 범죄의 방지와 고도 정보통신 사회의 건전한 발전을 목적으로 한 것으로, 형법으로 처벌할 수 없는 부분을 대상으로 하는 법률입니다.
<BR><BR>　형법에서는, 어떠한 피해가 나오지 않으면 처벌할 수 없었습니다만, 부정 액세스 금지법에서는
{$HtagDisaster_}부정 액세스를 실시한 시점에서 처벌의 대상이 됩니다. {$H_tagDisaster}
<BR><BR>　실제의 법률을 씹어 분쇄해라고 설명하면(자),
「<A HREF='http://www.ipa.go.jp/security/ciadr/law199908.html#부정 액세스 행위' target='_blank'><B>부정 액세스</B></A> 란,<B>패스워드등으로 보호된 영역에, 권한이 없는 것이 마음대로 액세스 하는 것</B>」으로,
이것에 위반했을 경우, 「{$HtagDisaster_}징역 1년 이하, 또는, 50만엔 이하의 벌금{$H_tagDisaster}」가 부과되게 됩니다.
<BR><BR>　단순한 「패스워드의 입력 미스」이면 좋겠습니다만, 너무 빈번하면,<B>관리자로서 상응하는 조치를 취하지 않을 수 없습니다. </B>
<BR><BR>　{$HtagTH_}반복 패스워드 에러가 발생했을 경우, 무엇인가 특별한 이유가 있으므로 하면, 「게시판」혹은 「메일」에서 연락해 주시도록 부탁 드리겠습니다. {$H_tagTH}
</TD></TR></TABLE>
HAKOHDOC_1
);
	}
}


/*
 * 함수: tempWrong()
 * 역할: 범용 오류 화면을 출력합니다.
 * 원본 대응: hako/hako-io.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function tempWrong() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	Dummyfunction();
	$msg = isset($_args[0]) ? $_args[0] : null;
	out("{$HtagBig_}{$msg}{$H_tagBig}{$HtempBack}");
}


/*
 * 함수: Dummyfunction()
 * 역할: JS 모드 비밀번호 오류 시 브라우저 스크립트 에러를 막기 위한 더미 함수입니다.
 * 원본 대응: hako/hako-io.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function Dummyfunction() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	out(<<<HAKOHDOC_2
<SCRIPT LANGUAGE="JavaScript">
function SelectList(theForm){}
function init() {}
</SCRIPT>
HAKOHDOC_2
);
}




/*
 * 함수: axeslog()
 * 역할: 접근 로그를 파일에 기록합니다.
 * 원본 대응: hako/hako-io.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function axeslog() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	unset($mode); $mode = isset($_args[0]) ? $_args[0] : null;
	unset($wid); $wid = isset($_args[1]) ? $_args[1] : null;
	unset($lines); $lines = array();

	unset($agent); $agent = hako_get_env('HTTP_USER_AGENT');
	unset($addr); $addr = hako_get_env('REMOTE_ADDR');
	unset($host); $host = hako_get_env('REMOTE_HOST');
	if (!($HtopAxes == 1)) { unset($referer); $referer = hako_get_env('HTTP_REFERER'); }
	if (($host == $addr) || ($host == '')) {
		$host = gethostbyaddr($addr) ? gethostbyaddr($addr) : $addr;
	}
	putenv('TZ=KST-9'); date_default_timezone_set('Asia/Seoul');
	$_list_tmp = hako_localtime(time());
	unset($sec); $sec = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
	unset($min); $min = isset($_list_tmp[1]) ? $_list_tmp[1] : null;
	unset($hour); $hour = isset($_list_tmp[2]) ? $_list_tmp[2] : null;
	unset($mday); $mday = isset($_list_tmp[3]) ? $_list_tmp[3] : null;
	unset($mon); $mon = isset($_list_tmp[4]) ? $_list_tmp[4] : null;
	unset($year); $year = isset($_list_tmp[5]) ? $_list_tmp[5] : null;
	unset($wday); $wday = isset($_list_tmp[6]) ? $_list_tmp[6] : null;
	unset($yday); $yday = isset($_list_tmp[7]) ? $_list_tmp[7] : null;
	unset($isdst); $isdst = isset($_list_tmp[8]) ? $_list_tmp[8] : null;
	$__days = array('일','월','화','수','목','금','토');
		unset($day); $day = $__days[$wday];
	$year = $year + 1900;
	$mon = $mon + 1;
	unset($date); $date = sprintf("%04d/%02d/%02d(%s) %02d:%02d:%02d", $year,$mon,$mday,$day,$hour,$min,$sec);

	hako_open('IN', "$HaxesLogfile");
	unset($lines); $lines = hako_read_all_lines('IN');
	hako_close('IN');

	while ($HaxesMax <= count($lines)) { array_pop($lines); }
	unset($id); $id = null;
	if ($mode == 1) {
		
		$id = "NEW=>$wid";
	} else {
		$id = ($defaultID == $HcurrentID) ? "$defaultID $wid" : "$defaultID=>$HcurrentID $wid";
	}
	array_unshift($lines, "[$date] - $referer - $host - $addr - $agent - $id\n");

	if (hako_open('OUT', ">$HaxesLogfile")) {
		foreach ($lines as $line) {
		hako_write('OUT', ($line));
		}
		hako_close('OUT');
	} else {
		tempProblem();
		return;
	}
}






if (!function_exists('out')) {
/*
 * 함수: out()
 * 역할: HTML을 출력합니다. 자동 변형 없이 원본 문자열을 그대로 내보내야 합니다.
 * 원본 대응: hako/hako-io.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function out() {
    $_args = func_get_args();
    echo isset($_args[0]) ? $_args[0] : '';
}
}


/*
 * 함수: HdebugOut()
 * 역할: 디버그 로그를 출력/기록합니다.
 * 원본 대응: hako/hako-io.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function HdebugOut() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	hako_open('DOUT', ">>debug.log");
	$msg = isset($_args[0]) ? $_args[0] : null;
	hako_write('DOUT', "$HislandTurn,$msg\n");
	hako_close('DOUT');
}


/*
 * 함수: htmlEscape()
 * 역할: HTML 특수문자를 원본 호환 방식으로 이스케이프합니다.
 * 원본 대응: hako/hako-io.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function htmlEscape() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	unset($s); $s = isset($_args[0]) ? $_args[0] : null;
	hako_subst($s, '~&~', '&amp;');
	hako_subst($s, '~<~', '&lt;');
	hako_subst($s, '~>~', '&gt;');
	hako_subst($s, '~\\"~', '&quot;');
	hako_subst($s, '~\'~', '&#39;');
	hako_subst($s, '~ ~', '&#32;');
	return $s;
}


?>
