<?php

/*
 * hako/hako-editorN.php
 * ------------------------------------------------------------
 * 맵 에디터 독립 화면 모듈
 *
 * 상세 주석 기준:
 * - 원본 대응: qwmp155.zip 의 hako-editorN.cgi.
 * - 쿠키 기반 로컬 이미지 경로, 지도 데이터 입력/출력, 에디터용 이미지 표시를 담당합니다.
 * - 로컬 이미지 경로의 역슬래시/슬래시 변환은 원본 CGI의 역슬래시를 슬래시로 바꾸는 동작과 맞춰야 합니다.
 * - 원본 CGI 주석 라인 확인 수: 43줄. PHP 주석은 실행 결과를 바꾸지 않는 범위에서 복원/보강했습니다.
 *
 * 유지보수 원칙:
 * - 실행 로직, 저장 포맷, 배열 인덱스, 출력 HTML은 원본 CGI 호환성 대상입니다.
 * - 개조가 필요하면 먼저 해당 변수/함수가 어떤 파일 저장값과 연결되는지 확인하십시오.
 * - 이 주석은 유지보수용이며 실행 결과를 바꾸지 않습니다.
 */

chdir(dirname(__FILE__));
require_once dirname(__FILE__) . '/hako-compat.php';

















require_once './hako-init.php';
require_once './hako-io.php';




$headtitle = '모형정원 공통 맵 N 맵 에디터';


$bye = "$HbaseDir/hako-main.php?meditor=0";




cookieInput();
tempHeader();
requestInput();
hakoEditor();
tempFooter();


exit(0);





/*
 * 함수: cookieInput()
 * 역할: 브라우저 쿠키에서 로컬 이미지/스킨/이전 선택값을 읽습니다.
 * 원본 대응: hako/hako-editorN.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function cookieInput() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	unset($cookie); $cookie = hako_get_env('HTTP_COOKIE');
	unset($hakoFile); $hakoFile = "$HbaseDir/hako-main.php";

	
	if (hako_regex('~' . preg_quote($hakoFile . 'IMGLINE', '~') . '=\(([^\)]*)\)~', $cookie)) {
		$HimgLine = hako_m(1);
	}
}



/*
 * 함수: requestInput()
 * 역할: GET/POST 입력값을 원본 CGI의 cgiInput 역할에 맞춰 전역 변수로 정리합니다.
 * 원본 대응: hako/hako-editorN.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function requestInput() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	unset($line); $line = null;
	unset($getLine); $getLine = null;

	
	$line = file_get_contents("php://input");
	$line = strtr($line, '+', ' ');
	$line = rawurldecode(str_replace("+", " ", $line));
	hako_subst($line, '~[\\x00-\\x1f\\,]~', '');

	
	$getLine = hako_get_env('QUERY_STRING');

	if (hako_regex('~mapeditor=([^&]*)~', $line)) {
		$hakoEditor = hako_m(1);
		hako_subst($hakoEditor, '~@~', ',');
	}
}





/*
 * 함수: tempHeader()
 * 역할: 공통 HTML 헤더를 출력합니다.
 * 원본 대응: hako/hako-editorN.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function tempHeader() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$baseIMG = ($HimgLine != '') ? $HimgLine : $imageDir;
	if (!headers_sent()) { header('Content-Type: text/html; charset=UTF-8'); }
	echo "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n";
	out(<<<HAKOHDOC_0
<html lang="kr">
<head>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
<TITLE>$headtitle</TITLE>
<BASE HREF="$baseIMG/">
HAKOHDOC_0
);
}

/*
 * 함수: tempFooter()
 * 역할: 공통 HTML 푸터와 CPU 표시를 출력합니다.
 * 원본 대응: hako/hako-editorN.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function tempFooter() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$_list_tmp = hako_cpu_times();
	$uti = isset($_list_tmp[0]) ? $_list_tmp[0] : 0;
	$sti = isset($_list_tmp[1]) ? $_list_tmp[1] : 0;
	$cuti = isset($_list_tmp[2]) ? $_list_tmp[2] : 0;
	$csti = isset($_list_tmp[3]) ? $_list_tmp[3] : 0;
	$uti += $cuti;
	$sti += $csti;
	unset($cpu); $cpu = $uti + $sti;
	out(<<<HAKOHDOC_1

[<A HREF="$bye">←돌아온다</A>]

<A HREF="http://www8.plala.or.jp/nayupon/">구상의 모형정원</A>

<!-- 저작권 표시는 지우지 말것 -->
<DIV ALIGN="RIGHT">
<A HREF="http://espion.just-size.jp/">Copyright (C) 2000-2004 Kyosuke Takayama, All rights reserved.</A>
</DIV>
</BODY>
</HTML>

HAKOHDOC_1
);
}




/*
 * 함수: hakoEditor()
 * 역할: 맵 에디터 본체를 출력합니다.
 * 원본 대응: hako/hako-editorN.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function hakoEditor() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	out(<<<HAKOHDOC_2

<SCRIPT language=JavaScript>
<!--



var mapsize = 19;
imgdir = "./"; 
maplst = new Array( 
	["nu/land0.gif", "바다"             , 0, "", 0, 0], 
	["nu/land1.gif", "황무지"           , 1, "", 1, 0], 
	["nu/land2.gif", "평지"           , 1, "", 2, 0], 
	["nu/land3.gif", "촌"             , 1, "", 3, 0], 
	["nu/land4.gif", "정"             , 1, "", 3, 0], 
	["nu/land5.gif", "도시"           , 1, "", 3, 0], 
	["nu/land6.gif", "숲"             , 1, "", 6, 0], 
	["nu/land7.gif", "농장"           , 1, "", 7, 0], 
	["nu/land8.gif", "공장"           , 1, "", 8, 0], 
	["nu/land9.gif", "미사일 기지"   , 1,  6, 9, 0], 
	["nu/land10.gif", "방위 시설"      , 1, "",10, 0], 
	["nu/land11.gif", "산"            , 1, "",11, 0], 
	["nu/land12.gif", "해저기지"      , 0,  0,12, 0], 
	["nu/land13.gif", "황무지(자취)"      , 1, "", 1, 0], 
	["nu/land14.gif", "얕은 여율"          , 0, "", 0, 0], 
	["nu/land15.gif", "채굴장"        , 1, "",11, 0], 
	["nu/monument1.gif", "방벽"       , 1, "",16, 0], 
	["nu/land17.gif", "병참기지"      , 1,  6,17, 0], 
	["nu/monster0.gif", "이노라"        , 1, "",18, 0], 
	["nu/monster5.gif", "산지라"      , 1, "",18, 0], 
	["nu/monster1.gif", "레드 이노라"  , 1, "",18, 0], 
	["nu/monster2.gif", "다크이노라"  , 1, "",18, 0], 
	["nu/monster8.gif", "이노라 고스트", 1, "",18, 0], 
	["nu/monster6.gif", "쿠지라"        , 1, "",18, 0], 
	["nu/monster3.gif", "킹 이노라"  , 1, "",18, 0], 
	["nu/monster7.gif", "메카 이노라"    , 1, "",18, 0], 
	["nu/monster4.gif", "경화중의 괴수"  , 1, "",18, 0], 
	["nu/monster7_2.gif", "경화 메카 이노라", 1, "",18, 0], 
	["e/land30.gif", "숲(?)"          , 1,  6, 6, 0],
	["e/land31.gif", "미사일 기지(?)", 1,  6, 9, 0],
	["e/land32.gif", "방위 시설(?)"    , 1,  6,10, 0],
	["e/land33.gif", "병참 기지(?)"    , 1,  6,17, 0] 
);
ctlst = new Array( 
	["황무지"         , 1],
	["평지"         , 2],
	["마을계"         , 3],
	["숲"           , 6],
	["농장"         , 7],
	["공장"         , 8],
	["미사일 기지" , 9],
	["방위 시설"     ,10],
	["채굴장(산)"   ,11],
	["해저 기지"     ,12],
	["방벽(기념비)" ,16],
	["병참기지"     ,17],
	["괴수"         ,18]
);
numlst = new Array( 
	"nu/space0.gif",
	"nu/space1.gif",
	"nu/space2.gif",
	"nu/space3.gif",
	"nu/space4.gif",
	"nu/space5.gif",
	"nu/space6.gif",
	"nu/space7.gif",
	"nu/space8.gif",
	"nu/space9.gif",
	"nu/space10.gif",
	"nu/space11.gif",
	"nu/space12.gif",
	"nu/space13.gif",
	"nu/space14.gif",
	"nu/space15.gif",
	"nu/space16.gif",
	"nu/space17.gif",
	"nu/space18.gif",
	"nu/space19.gif"
);
var space = "space.gif";
var xbar = "nu/xbar.gif";
mislst = new Array (
	["e/m0.gif", "마크"],
	["e/m1.gif", "주위 1 필드"],
	["e/m2.gif", "주위 2 필드"],
	["e/m3.gif", "주위 3 필드"]
);

var selected = 0;
var guest_mode = 0;
var original_str = "";
var keep_selected;
var bgcolor = '#CCCCFF'; 
function chMap(x,y) {
	if (selected.charAt(0) == "m") {
		markMissileArea(x,y,selected.charAt(1));
	} else {
		chImg(x,y,selected);
		bgChg();
	}
}

function chImg(x,y,z) {
	document.images[x + "x" + y].src = imgdir + maplst[z][0];
	document.images[x + "x" + y].alt = "(" + y + "," + x + ") " + maplst[z][1];
}
function chImg2(x,y,z,c) {
	if(c == 1){
		document.images[x + "x" + y].src = imgdir + maplst[z][0].replace(/^nu/,"cu/");
	}else{
		document.images[x + "x" + y].src = imgdir + maplst[z][0].replace(/^cu/,"nu/");
	}
	document.images[x + "x" + y].alt = "(" + y + "," + x + ") " + maplst[z][1];
}

function getDat(x,y) {
	var img_url = document.images[x + "x" + y].src;
	var img_file = img_url.substr(img_url.lastIndexOf("/", img_url.length) + 1);
	for (var i = 0; i < maplst.length; i++) {
		var img_file2 = maplst[i][0].substr(maplst[i][0].lastIndexOf("/", maplst[i][0].length) + 1);
		if (img_file == img_file2) {
			return i;
		}
	}

	return 0;
}
function getDat2(x,y) {
	var img_url = document.images[x + "x" + y].src;
	var img_file = img_url.substr(img_url.lastIndexOf("/", img_url.length) + 1);
	for (var i = 0; i < maplst.length; i++) {
		var img_file2 = maplst[i][0].substr(maplst[i][0].lastIndexOf("/", maplst[i][0].length) + 1);
		if (img_file == img_file2) {
			if(img_url.match(/\\/cu\\
				return i+100;
			}else{
				return i;
			}
		}
	}
	return 0;
}
function setImg(x) {
	selected = x.toString();
	if (selected.charAt(0) == "m") {
		document.images["selected"].src = imgdir + mislst[selected.charAt(1)][0];
		document.images["selected"].alt = imgdir + mislst[selected.charAt(1)][1];
		document.forms[0].elements[0].value = mislst[selected.charAt(1)][1];
	} else {
		document.images["selected"].src = imgdir + maplst[selected][0];
		document.images["selected"].alt = maplst[selected][1];
		document.forms[0].elements[0].value = maplst[selected][1]
	}
}

function writeCookie() {
	var cookieStr = "editorN=";
	var map_data = "";
	for (var i = 0; i <= mapsize; i++) {
		for (j = 0; j <= mapsize; j++) {
			map_data += getDat2(i,j);
			map_data += ",";
		}
	}

	cookieArray = new Array();
	for (var i = 1; i <= 6; i++) {
		if (document.forms[1].elements["n" + i].value == "") {
			document.forms[1].elements["n" + i].value.replace(/[\\;\\s]/,"")
		}
		if (document.forms[1].elements["r" + i].checked) {
			document.forms[1].elements["c" + i].value = map_data;
		}
		cookieArray[i - 1] = document.forms[1].elements["n" + i].value + "|" + document.forms[1].elements["c" + i].value;
	}
	cookieStr += cookieArray.join("<>");

	cookieStr += "; ";

	present_date = new Date();
	present_year = present_date.getFullYear();
	present_month = present_date.getMonth();
	if (present_month >= 10) {
		present_year++;
		present_month -= 10;
	} else {
		present_month += 2;
	}
	expired_date = new Date(present_year, present_month, 1);
	expired_year = expired_date.getFullYear();
	expired_month = expired_date.getMonth();
	expired_week = expired_date.getDay();
	month = new Array("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec");
	week = new Array("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat");
	expired_month = month[expired_month];
	expired_week = week[expired_week];
	expired = "expires=" + expired_week + ", " + "01-" + expired_month + "-" + expired_year + " 00:00:00 GMT;";

	document.cookie = cookieStr + expired;
	checkCookie();
}

function readCookie() {
	if (document.cookie != "") {
		var cookieStr = "";
		var cookies = document.cookie.split("; ");
		for (var i = 0; i < cookies.length; i++) {
			var str = cookies[i].split("=");
			if (str[0] != "editorN") continue;
			cookieStr = str[1];break;
		}

		cookieArray = new Array();
		cookieArray = cookieStr.split("<>");
		namedata = new Array(2);
		for (var i = 1; i <= 6; i++) {
			if (cookieArray[i - 1].indexOf("|") < 0) {
				document.forms[1].elements["n" + i].value = "무명";
				document.forms[1].elements["c" + i].value = document.cookie;
				for ( ; i <= 6; i++) {
					document.forms[1].elements["n" + i].value = "무명";
				}
				break;
			} else {
				namedata = cookieArray[i - 1].split("|");
				if (namedata[0] == "") {
					document.forms[1].elements["n" + i].value = "무명";
					document.forms[1].elements["c" + i].value = namedata[1];
				} else {
					document.forms[1].elements["n" + i].value = namedata[0];
					document.forms[1].elements["c" + i].value = namedata[1];
				}
			}
		}
	}
	checkCookie();
}

function setCookie() {
	document.all.zikoku.checked = false;
	zikoku();
	var cookie_str = "";
	var cu = 0;
	for (var i = 1; i <= 6; i++) {
		if (document.forms[1].elements["r" + i].checked) {
			if (document.forms[1].elements["c" + i].value == "") {
				window.alert(document.forms[1].elements["n" + i].value + "에 Cookie는 보존되고 있지 않습니다. ");
				return;
			} else {
				cookie_str = document.forms[1].elements["c" + i].value;
			}
			break;
		}
	}
	cookie_array = cookie_str.split(",");
	if (cookie_array.length < (mapsize + 1) * (mapsize + 1)) {
		window.alert(document.forms[1].elements["n" + i].value + "에 보존된 데이터는 망가져 있습니다");
		return;
	}
	for (var i = 0; i <= mapsize; i++) {
		for (j = 0; j <= mapsize; j++) {
			var mapInt = cookie_array[i * (mapsize + 1) + j];
			if (mapInt >= 100) {
				cu = 1;
				mapInt -= 100
			}else{
				cu = 0;
			}
			var mapdata = mapInt.toString();
			if (mapdata == "") {
				if (confirm("(" + j + "," + i +")의 데이터를 읽어들일 수 없습니다\\n계속합니까?")) {
					continue;
				} else {
					return;
				}
			}
			chImg2(i,j,parseInt(mapdata),cu);
		}
	}
    mapInfo();
	checkCookie();
}

function delCookie() {
	for (var i = 1; i <= 6; i++) {
		if (document.forms[1].elements["r" + i].checked) {
			document.forms[1].elements["c" + i].value = "";
			break;
		}
	}
	checkCookie();
}

function checkCookie() {
	var cookie_area = "";
	for (var i = 1; i <= 6; i++) {
		cookie_area = "ca" + i;
		if (document.forms[1].elements["c" + i].value == "") {
			document.all[cookie_area].bgColor = "white";
		} else {
			document.all[cookie_area].bgColor = "forestgreen";
		}
	}
}

function cookie2data() {
	var outStr = ""
	var cookieStr = "";
	for (var i = 1; i <= 6; i++) {
		if (document.forms[1].elements["r" + i].checked) {
			cookieStr = document.forms[1].elements["c" + i].value;
			break;
		}
	}
	if (cookieStr != "") {
		cookieArray = cookieStr.split(",");
		for (var i = 0; i <= mapsize; i++) {
			for (j = 0; j <= mapsize; j++) {
				outStr += cookieArray[i * (mapsize + 1) + j];
				outStr += ",";
			}
			outStr += "\\n";
		}
	} else {
		window.alert(document.forms[1].elements["n" + i].value + "에 보존된 데이터는 없습니다.");
		return;
	}
	outStr = outStr.substr(0, (outStr.length - 2));
	document.forms[1].elements["userdat"].value = outStr;
}

function outpData() {
	var outStr = "";
	for (i = 0; i <= mapsize; i++) {
		for (j = 0; j <= mapsize; j++) {
			outStr += getDat2(i,j);
			outStr += ",";
		}
		outStr += "\\n";
	}
	outStr = outStr.substr(0, (outStr.length - 2));
	document.forms[1].elements["userdat"].value = outStr;
}

function inpData() {
	document.all.zikoku.checked = false;
	zikoku();
	var inStr = document.forms[1].elements["userdat"].value;
	if (inStr != "") {
		inStr.replace(/\\n/,"");
		inArray = inStr.split(",");
		var err_flag = 0;
		err_map = new Array();
		var err_ignore = 0;
		var mapdata = "0";
		var cu = 0;
		for (i = 0; i <= mapsize; i++) {
			for (j = 0; j <= mapsize; j++) {
				if (inArray[i * (mapsize + 1) + j] != null) {
					var mapInt = inArray[i * (mapsize + 1) + j];
					if (mapInt >= 100) {
						cu = 1;
						mapInt -= 100
					}else{
						cu = 0;
					}
					mapdata = mapInt.toString();
				}
				if (mapdata == "" || mapdata != parseInt(mapdata) || mapdata >= maplst.length || mapdata < 0) {
					err_flag = 1;
					err_map[err_map.length] = j + "," + i;
					if (err_ignore == 1 || confirm("입력된 데이터가 망가져 있을 가능성이 있습니다.\\n 계속합니까? ")) {
						if (err_ignore == 1 || confirm("에러를 모두 무시합니까? ")) {
							err_ignore = 1;
						}
						continue;
					} else {
						return;
					}
				}
				chImg2(i,j,parseInt(mapdata),cu);
			}
		}
		if (err_flag == 1) {
			var err_zahyou = "(" + err_map.join(") (") + ")";
			if (confirm(err_zahyou + " 의 맵 데이터의 복원에 실패했습니다. \\n에러 개소를 마크 합니까? ")) {
				markErrMap(err_map.join(","));
			}
		}
	} else {
		return;
	}
    mapInfo();
}

function markErrMap(map_str) {
	map_array = map_str.split(",");
	var x;
	var y;
	for (var i = 0; i < map_array.length; i += 2) {
		x = map_array[i + 1];
		y = map_array[i];
		markMap(x,y,"inv");
	}
}

function markMissileArea(x,y,z) {
	if (parseInt(z) == 0) {
		xArray = new Array(); xArray[0] = 0;
		yArray = new Array(); yArray[0] = 0;
	} else if (parseInt(z) == 1) {
		xArray = new Array(-1, -1, 0, 0, 0, 1, 1);
		yArray = new Array(-1, 0, -1, 0, 1, -1, 0);

	} else if (parseInt(z) == 2) {
		xArray = new Array(-2, -2, -2, -1, -1, -1, -1, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2);
		yArray = new Array(-1, 0, 1, -2, -1, 0, 1, -2, -1, 0, 1, 2, -2, -1, 0, 1, -1, 0, 1);
	} else if (parseInt(z) == 3) {
		xArray = new Array(-3, -3, -3, -3, -2, -2, -2, -2, -2, -1, -1, -1, -1, -1, -1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 3, 3, 3, 3);
		yArray = new Array(-2, -1, 0, 1, -2, -1, 0, 1, 2, -3, -2, -1, 0, 1, 2, -3, -2, -1, 0, 1, 2, 3, -3, -2, -1, 0, 1, 2, -2, -1, 0, 1, 2, -2, -1, 0, 1);
	}

	for (i = 0; i < xArray.length; i++) {
		var targetX = x + xArray[i];
		if (targetX > mapsize || targetX < 0) {
			continue;
		}
		if (x % 2 == 0 && Math.abs(xArray[i]) % 2 == 1) {
			yArray[i]++;
		}
		var targetY = y + yArray[i];
		if (targetY > mapsize || targetY < 0) {
			continue;
		}
                if(document.all.mark.checked == true) {
                    markMap(targetX,targetY,"noinv")
	        } else if(document.all.black.checked == true) {
		    markMap(targetX,targetY,"binv")
                } else {
		    markMap(targetX,targetY,"inv")
                }
	}
}

function markMap(x,y,kind) {
	var target_name = x + "x" + y;
	document.images[target_name].id = kind;
}

function markReset() {
	for (i = 0; i <= mapsize; i++) {
		for (j = 0; j <= mapsize; j++) {
			var target_name = i + "x" + j;
			document.images[target_name].id = "noinv";
		}
	}
}

function guestView() {
	if (guest_mode == 0) {
		original_str = "";
		for (i = 0; i <= mapsize; i++) {
			for (j = 0; j <= mapsize; j++) {
				var present_img = getDat(i,j);
				original_str += present_img;
				original_str += ",";
				if (maplst[present_img][3].toString() != "") {
					chImg(i,j,maplst[present_img][3].toString());
				}
			}
		}
		guest_mode = 1;
		document.forms[1].elements["chView"].value = "개발 화면에 돌아온다";
	} else {
		original_array = new Array();
		original_array = original_str.split(",");
		for (i = 0; i <= mapsize; i++) {
			for (j = 0; j <= mapsize; j++) {
				chImg(i,j,original_array[i * (mapsize + 1) + j].toString());
			}
		}
		guest_mode = 0;
		document.forms[1].elements["chView"].value = "관광자 모드에";
	}
}

function mapPaint() {
    if (selected.charAt(0) == "m") {
	return;
    }
	for (i = 0; i <= mapsize; i++) {
		for (j = 0; j <= mapsize; j++) {
			chImg(i,j,selected);
		}
	}
    bgChg();
}

function decodeMap(){
	var src = document.srcForm.inputText.value;
	src = src.replace(/monument/g,"land16."); 
	src = src.replace(/cu\\/land([0-9][0-9].)/g,"land1\$1");
	src = src.replace(/cu\\/land([0-9].)/g,"land10\$1");
	src = src.replace(/monster0/g,"land18."); 
	src = src.replace(/monster5/g,"land19."); 
	src = src.replace(/monster1/g,"land20."); 
	src = src.replace(/monster2/g,"land21."); 
	src = src.replace(/monster8/g,"land22."); 
	src = src.replace(/monster6/g,"land23."); 
	src = src.replace(/monster3/g,"land24."); 
	src = src.replace(/monster7_2/g,"land27."); 
	src = src.replace(/monster7/g,"land25."); 
	src = src.replace(/monster4/g,"land26."); 
	src = src.match(/land.../gi);
	document.forms[1].elements["userdat"].value = src;
	src = document.forms[1].userdat.value.replace(/[^0-9,]/g,"");
	src = src.replace(/^,+/,"");
	document.forms[1].elements["userdat"].value = src;
}

function mapInfo(){
	var outStr = "";
	var lands = 0;
	for (i = 0; i <= mapsize; i++) {
		for (j = 0; j <= mapsize; j++) {
			outMap = getDat(i,j);
			maplst[maplst[outMap][4]][5]++;
			lands += maplst[outMap][2];
	    }
	}

	document.all.hex.innerHTML = lands + "HEX"; 

	for (g = 1;g < ctlst.length; g++) {
		moremap = '';
		document.all["hinfo" + ctlst[g][1]].innerHTML = maplst[ctlst[g][1]][5] + moremap + "필드";
	}
	for (g = 1;g < maplst.length; g++) {
		maplst[g][5] = 0;
	}
	document.all.info.bgColor = '#eeffff';
}

function bgChg() {

    document.all.info.bgColor = bgcolor;

}

function zikoku() {
	for (var i = 0; i < maplst.length; i++) {
		if(document.all.zikoku.checked == true){
			maplst[i][0] = maplst[i][0].replace(/^nu/,"cu/");
		}else{
			maplst[i][0] = maplst[i][0].replace(/^cu/,"nu/");
		}
	}
}

//-->
</SCRIPT>

<STYLE type=text/css>A:link {
	COLOR: 
}
A:visited {
	COLOR: 
}
A:active {
	COLOR: 
}
A:hover {
	COLOR: 
}
BODY {
	COLOR: navy; FONT-SIZE: 13pt
}
IMG
	FILTER: Invert()
}
IMG
	FILTER: none
}
IMG
	FILTER: Gray()
}
</STYLE>
</HEAD>
<BODY bgColor=
<FONT size=5>모형정원 공통 맵 N(1.4x) 맵 에디터 v0.12
<A href="$HbaseDir/hako-main.php">탑에 돌아온다</A>　
<!--<A href="./map.html">간단한 설명</A>　
<!--<A href="./exp.html">설정 방법법</A>　
</FONT><BR><BR>
<TABLE border=0 cellPadding=0 cellSpacing=5>
<TBODY>
<TR><TD valign=top>
<TABLE border=0 cellPadding=0 cellSpacing=0>
<SCRIPT language=JavaScript>
<!--

document.write("<TR><TD nowrap><IMG src=\\"" + imgdir + xbar + "\\" border=0></TD></TR>");
for (i = 0; i <= mapsize; i++) {
	document.write("<TR><TD nowrap>");
	if (i % 2 == 0) {
		document.write("<IMG src=\\"" + imgdir + numlst[i] + "\\" border=0>");
	}
	for (j = 0; j <= mapsize; j++) {
		document.write("<A href=\\"JavaScript:chMap(" + i + "," + j + ");\\" onMouseOver=\\"JavaScript:window.status=document.images['" + i + "x" + j + "'].alt; return true;\\">");
		document.write("<IMG src=\\"" + imgdir + maplst[0][0] + "\\" name=\\"" + i + "x" + j + "\\" alt=\\"(" + j + "," + i + ") " + maplst[0][1] + "\\" border=0>");
		document.write("</A>");
	}
	if (i % 2 == 1) {
		document.write("<IMG src=\\"" + imgdir + numlst[i] + "\\" border=0>");
	}
	document.write("</TD></TR>");
}

//-->
</SCRIPT>
</TABLE>
</TD>
<TD vAlign=top>
<TABLE border=0 cellPadding=0 cellSpacing=0>
<TBODY>
<TR>
   <TD nowrap><FORM><IMG border=0 name=selected src="./nu/land0.gif">
<INPUT SIZE=14></FORM>
</TD></TR>
<SCRIPT language=JavaScript>
<!--

document.write("<TR><TD nowrap>");
for (i = 0; i <=3 ; i++) {
	document.write("<A href=\\"JavaScript:setImg(\\'m" + i + "');\\" onMouseOver=\\"JavaScript:window.status = '" + mislst[i][1] + "'; return true\\">");
	document.write("<IMG src=\\"" + imgdir + mislst[i][0] + "\\" alt=\\"" + mislst[i][1] + "\\" border=0>");
	document.write("</A>");
}
document.write("</TD></TR>");


//-->
</SCRIPT>
<TR><TD nowrap>
<INPUT TYPE=CHECKBOX NAME=black>흑마크<BR>
<INPUT TYPE=CHECKBOX NAME=mark>마킹 해제<BR>
</TD></TR>
<TR><TD>
<HR width="100%">
</TD></TR>
<TR><TD nowrap>
<INPUT TYPE=CHECKBOX NAME=zikoku onclick=zikoku()>자국 영토
</TD></TR>
<SCRIPT language=JavaScript>
<!--

for (i = 0; i < maplst.length; i++) {
	document.write("<TR><TD nowrap>");
	for (j = 0; j < 3; j++) {
		if (j != 0) {
			i++;
		}
		if (i >= maplst.length) {
			break;
		}
		document.write("<A href=\\"JavaScript:setImg(" + i + ");\\" onMouseOver=\\"JavaScript:window.status = '" + maplst[i][1] + "'; return true\\">");
		document.write("<IMG src=\\"" + imgdir + maplst[i][0] + "\\" alt=\\"" + maplst[i][1] + "\\" border=0>");
		document.write("</A>");
	}
	document.write("</TD></TR>");
}

//-->
</SCRIPT>
</TBODY></TABLE></TD>
<TD rowSpan=4 valign=top>
<TABLE id ="info" bgColor=
<TBODY>
<TR><TD align=center COLSPAN=3>
<INPUT onclick=mapInfo() type=button value=정보 read>
</TD></TR>
<TR><TD NOWRAP>　</TD><TD NOWRAP>면적</TD><TD NOWRAP id="hex">0HEX</TD></TR>
<SCRIPT language=JavaScript>
<!--
    for (g = 0;g < ctlst.length; g++) {
document.write("<TR><TD NOWRAP><IMG src=\\"" + imgdir + maplst[ctlst[g][1]][0] + "\\"></TD><TD NOWRAP>" + ctlst[g][0] + "</TD><TD NOWRAP id=\\"hinfo" + ctlst[g][1] + "\\">0 필드</TD></TR>");
    }
//-->
</SCRIPT>
</TBODY>
</TABLE>
</TD></TR></TBODY></TABLE>
<FORM><INPUT name=chView onclick=JavaScript:guestView() type=button value=관광자 모드에> <INPUT onclick=JavaScript:markReset() type=button value=전마킹을 리셋> <INPUT onclick=JavaScript:mapPaint() type=button value=칠해 부순다> <BR><BR>
<TABLE border=1>
  <TBODY>
  <TR>
    <TD id=ca1><INPUT CHECKED id=r1 name=radio type=radio value=1><INPUT 
      name=n1 size=10><INPUT name=c1 type=hidden></TD>
    <TD id=ca2><INPUT id=r2 name=radio type=radio value=2><INPUT name=n2 
      size=10><INPUT name=c2 type=hidden></TD>
    <TD id=ca3><INPUT id=r3 name=radio type=radio value=3><INPUT name=n3 
      size=10><INPUT name=c3 type=hidden></TD>
    <TD align=middle>Cookie (흰색：미사용)</TD></TR>
  <TR>
    <TD id=ca4><INPUT id=r4 name=radio type=radio value=4><INPUT name=n4 
      size=10><INPUT name=c4 type=hidden></TD>
    <TD id=ca5><INPUT id=r5 name=radio type=radio value=5><INPUT name=n5 
      size=10><INPUT name=c5 type=hidden></TD>
    <TD id=ca6><INPUT id=r6 name=radio type=radio value=6><INPUT name=n6 
      size=10><INPUT name=c6 type=hidden></TD>
    <TD><INPUT onclick=JavaScript:setCookie() type=button value=Read><INPUT onclick=JavaScript:writeCookie() type=button value=Save><INPUT onclick=JavaScript:delCookie() type=button value=Del></TD></TR></TBODY></TABLE><BR><INPUT onclick=JavaScript:outpData() type=button value=↓데이터 서두↓> 
<INPUT onclick=JavaScript:inpData() type=button value=↑데이터 read↑>
<INPUT onclick=JavaScript:cookie2data() type=button value=Cookie서두> <BR>
<TEXTAREA cols=70 name=userdat rows=10>$hakoEditor</TEXTAREA> </FORM>
<FORM name=srcForm>맵 화면 소스：　<INPUT onclick=decodeMap() type=button value=↑데이터 read↑> <BR>
주변 표시가 OFF 상태의 데이터의 HTML 소스가 아니면 안돼! <br><TEXTAREA cols=70 name=inputText rows=10>
모형정원 개발 화면·관광 화면의 HTML 소스를 붙이고 나서 read 버튼을 누르면,
에디터용으로 데이터를 추출합니다.
*HTML 소스의 견해
기본적으로 오른쪽 클릭의 메뉴에 그런 것같은 것은 있습니다
(MAC는 context menu입니다)
HTML 소스는, 아무것도 의식하지 않고 모두 선택해 카피해, 이 부분에 붙여 주세요
이 문장은, 지우지 않아도 문제 없게 동작 합니다
</TEXTAREA>
</FORM>

<SCRIPT LANGUAGE="JavaScript">
<!--
var mdata = document.forms[1].elements["userdat"].value;
if(mdata != "") inpData();
//-->
</SCRIPT>

HAKOHDOC_2
);
}

?>
