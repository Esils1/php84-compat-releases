<?php

/*
 * hako/hako-compat.php
 * ------------------------------------------------------------
 * PHP 5.5 호환 보조 함수 모음
 *
 * 상세 주석 기준:
 * - 원본 CGI에는 없지만 PHP 변환 과정에서 원본 동작을 보존하기 위해 추가된 호환 계층입니다.
 * - 원본 CGI의 미정의값, 배열 splice, 파일 시간, 안전한 flock/getmypid 처리처럼 PHP 5.5 서버에서 차이가 나는 부분을 흡수합니다.
 * - 게임 로직을 새로 구현하는 파일이 아니라 원본 동작을 PHP에서 재현하기 위한 최소 보정층입니다.
 *
 * 유지보수 원칙:
 * - 실행 로직, 저장 포맷, 배열 인덱스, 출력 HTML은 원본 CGI 호환성 대상입니다.
 * - 개조가 필요하면 먼저 해당 변수/함수가 어떤 파일 저장값과 연결되는지 확인하십시오.
 * - 이 주석은 유지보수용이며 실행 결과를 바꾸지 않습니다.
 */

chdir(dirname(__FILE__));

if (!isset($_hako_fh)) { $_hako_fh = array(); }
if (!isset($GLOBALS['_hako_match'])) { $GLOBALS['_hako_match'] = array(); }
if (!isset($GLOBALS['_hako_predeclared'])) {
    $GLOBALS['_hako_predeclared'] = true;
    foreach (array(
        'AfterName', 'All_listCom', 'Body', 'COLORS', 'CellColor', 'CellCt', 'Div', 'DivEx',
        'DivItem', 'DivLv', 'DivNa', 'DivPw', 'FItemID', 'FItemMsg', 'FItemName', 'FSItemID',
        'FartilleryFlg', 'Fdirection', 'Fdivision', 'FdivisionS', 'Feemove', 'Files', 'FmapMove', 'FmapPt',
        'FnoZocFlg', 'Fnochange', 'FoccupyFlg', 'ForceFlgMove', 'Forder', 'FsearchR', 'FunitPt', 'FzocFlg',
        'HGr', 'HGrname', 'HTurnCt', 'H_normalColor', 'H_tagBig', 'H_tagCo', 'H_tagComName', 'H_tagDisaster',
        'H_tagHeader', 'H_tagLbbsOW', 'H_tagLbbsSS', 'H_tagName', 'H_tagName2', 'H_tagNumber', 'H_tagTH', 'H_tagTitle',
        'Haftername', 'Halistmode', 'HallyDisp', 'Hallyflg', 'Hallygroup', 'Hallymark', 'HamityIsland', 'Harea',
        'HareaBorder', 'Hasync', 'Hatkturn', 'Hatkturn2', 'Hattention', 'HautoPoint', 'Hautoally', 'Hawc0',
        'Hawc1', 'Hawc2', 'Hawc3', 'Hawc4', 'HawcM', 'HaxesLogfile', 'HaxesMax', 'HbackupTimes',
        'HbackupTurn', 'HbaseDir', 'HbgCommandCell', 'HbgCommentCell', 'HbgInfoCell', 'HbgInputCell', 'HbgLbbsCell', 'HbgMapCell',
        'HbgNameCell', 'HbgNumberCell', 'HbgSubTCell', 'HbgTitleCell', 'Hcampbbs', 'HcampbbsPath', 'Hcampchat', 'HcampchatPath',
        'Hcolormap', 'HcomAmity', 'HcomArea', 'HcomAutoDelete', 'HcomAutoPrepare', 'HcomAutoPrepare2', 'HcomBase', 'HcomCeasefire',
        'HcomCost', 'HcomDbase', 'HcomDeWar', 'HcomDestroy', 'HcomDoNothing', 'HcomDraft', 'HcomFactory', 'HcomFactory2',
        'HcomFarm', 'HcomFarm2', 'HcomFood', 'HcomGiveup', 'HcomInfantry', 'HcomItem', 'HcomList', 'HcomMissileBM',
        'HcomMissileDM', 'HcomMissileHM', 'HcomMissileLD', 'HcomMissileNM', 'HcomMissilePP', 'HcomMoney', 'HcomMonument', 'HcomMountain',
        'HcomMsg', 'HcomName', 'HcomPlant', 'HcomPrepare', 'HcomPrepare2', 'HcomPresent', 'HcomPropaganda', 'HcomReclaim',
        'HcomSbase', 'HcomSell', 'HcomSendMonster', 'HcomSoldier', 'HcomSoldier2', 'HcomSupply', 'HcomTurn', 'HcomUnitOrder',
        'HcomWithdraw', 'HcommandArg', 'HcommandComary', 'HcommandDivido', 'HcommandKind', 'HcommandMax', 'HcommandMode', 'HcommandPlanNumber',
        'HcommandTarget', 'HcommandTotal', 'HcommandX', 'HcommandY', 'HcostChangeName', 'HcssFile', 'HcurrentAFNameId', 'HcurrentCamp',
        'HcurrentCampID', 'HcurrentID', 'HcurrentName', 'HcurrentNumber', 'HcurrentOwnerName', 'Hcustom', 'HdBaseAuto', 'Hdeadisland',
        'Hdebug', 'HdebugR', 'HdeclareTurn', 'HdecodePassword', 'HdefaultKind', 'HdefaultName', 'HdefaultPassword', 'HdefaultPasswordEsc',
        'HdefaultX', 'HdefaultY', 'HdefenceHex', 'HdirMode', 'HdirName', 'HdisEarthquake', 'HdisEruption', 'HdisFallBorder',
        'HdisFalldown', 'HdisFire', 'HdisHugeMeteo', 'HdisHugeMeteo2', 'HdisMaizo', 'HdisMeteo', 'HdisMeteo2', 'HdisMonsBorder1',
        'HdisMonsBorder2', 'HdisMonsBorder3', 'HdisMonster', 'HdisNoMeteoTurn', 'HdisTsunami', 'HdisapearMons', 'HdiscountTurn', 'HdispAzukari',
        'HdoCommand', 'HeatenFood', 'HeditorN', 'HefileDir', 'HfirstFlg', 'HflagCommand', 'Hfleet', 'HflexTime',
        'HflexTimeSet', 'HforceLogPool', 'HgiveupTurn', 'HhideMoneyMode', 'HhistoryLogPool', 'HhistoryMax', 'Hically', 'Hicfood',
        'HichangeMode', 'Hicmoney', 'Hicsoldier', 'HidToName', 'HidToNumber', 'Himfflag', 'HimgLine', 'HinitialFood',
        'HinitialMoney', 'HinitialSoldier', 'HinputPassword', 'HinputPassword2', 'HislandLastTime', 'HislandList', 'HislandNFlg', 'HislandNextID',
        'HislandNumber', 'HislandSize', 'HislandTurn', 'Hislands', 'Hislands2', 'HjavaMode', 'HjavaModeSet', 'Hland',
        'HlandBase', 'HlandDefence', 'HlandDiv', 'HlandDivEx', 'HlandDivItem', 'HlandDivLv', 'HlandDivNa', 'HlandDivPw',
        'HlandFactory', 'HlandFarm', 'HlandForest', 'HlandHGr', 'HlandKeep', 'HlandMonster', 'HlandMonument', 'HlandMountain',
        'HlandOwner', 'HlandPlains', 'HlandResist', 'HlandSbase', 'HlandSea', 'HlandSupply', 'HlandTown', 'HlandValue',
        'HlandWaste', 'HlateLogPool', 'HlbbsAnon', 'HlbbsMax', 'HlbbsMessage', 'HlbbsMode', 'HlbbsMode2', 'HlbbsName',
        'HlbbsSpeaker', 'HlbbsType', 'HlchangeDIV', 'HlchangeDIVEX', 'HlchangeDIVITEM', 'HlchangeDIVLV', 'HlchangeDIVNA', 'HlchangeDIVPW',
        'HlchangeHGR', 'HlchangeKIND', 'HlchangeMode', 'HlchangeOWNER', 'HlchangeVALUE', 'HlimitTurn', 'HlocalImg', 'Hlocalimage',
        'Hlocalimagehtml', 'HlogMax', 'HlogOmit2', 'HlogPool', 'HmainMode', 'HmapeditorMode', 'HmasterPassword', 'HmaxAidArea',
        'HmaxAidFood', 'HmaxAidMoney', 'HmaxAidSoldier', 'HmaxExpPoint', 'HmaxIsland', 'HmenteFile', 'HmenuOpen', 'Hmessage',
        'HmissileRange', 'HmissileRangeS', 'HmonsterBHP', 'HmonsterDHP', 'HmonsterExp', 'HmonsterImage', 'HmonsterImage2', 'HmonsterLevel1',
        'HmonsterLevel2', 'HmonsterLevel3', 'HmonsterName', 'HmonsterNumber', 'HmonsterSpecial', 'HmonsterValue', 'HmonumentImage', 'HmonumentName',
        'HmonumentNumber', 'Hnoarmy', 'HnormalColor_', 'HoldPassword', 'HpassError', 'HpasswordFile', 'HpointNumber', 'HpreDeleteID',
        'HpreDeleteMode', 'Hprize', 'HrTurn', 'Hragnarok', 'HragnarokTurn', 'Hrno18', 'Hrno6', 'Hroundmode',
        'Hrpx', 'Hrpy', 'HsecretLogPool', 'HskinList', 'HskinName', 'HskinNameList', 'Hskinflag', 'HspeakerID',
        'HspecialPassword', 'HstartItem', 'HtagBig_', 'HtagCo_', 'HtagComName1_', 'HtagComName2_', 'HtagComName_', 'HtagDisaster_',
        'HtagHeader_', 'HtagLbbsOW_', 'HtagLbbsSS_', 'HtagName2_', 'HtagName_', 'HtagNumber_', 'HtagTH_', 'HtagTitle2_',
        'HtagTitle_', 'HtargetList', 'HtempBack', 'HthisFile', 'Htitle', 'Htitle2', 'HtopAxes', 'HtopLogTurn',
        'Htopmode', 'HturnPrizeUnit', 'HunitArea', 'HunitFood', 'HunitFood2', 'HunitMoney', 'HunitPop', 'HunitPop2',
        'HunitTime', 'HunitTree', 'HuseLbbs', 'HwarIsland', 'IROIRO', 'ItemList', 'LbbsButtonD', 'LbbsButtonW',
        'ListIx', 'MaxFood', 'MaxMoney', 'Monspe', 'Msg', 'NdoStr', 'OwnerCount', 'StrTD1',
        'StrTD2', 'StrTH1', 'StrTH2', 'TaPt', '_', '_monsterSpec', 'a', 'aPt',
        'aa', 'aaa', 'absent', 'achive', 'addpop', 'addpop2', 'addpop3', 'addr',
        'admin', 'adminName', 'advice', 'advice2', 'afnameId', 'afname_list', 'agent', 'ak',
        'al', 'alertNoIndex', 'allpop', 'ally', 'allyArea', 'allyCount', 'allyGnp', 'allyPop',
        'allySol', 'alpha', 'alt', 'amark', 'amiName', 'amitywar', 'ango', 'apop',
        'area', 'arg', 'args', 'array', 'at', 'attackA', 'autolink', 'awvalue',
        'ax', 'ay', 'b', 'b_face', 'b_size', 'back', 'backCol', 'back_col',
        'bai', 'base', 'baseIMG', 'baseLevel', 'baseLevelUp', 'baseLevelUp2', 'baseSKIN', 'baseUrl',
        'baseflg', 'bb1', 'bb2', 'bbb', 'bbs', 'bbs1', 'bbs2', 'bbs3',
        'bbs4', 'bbs5', 'bc', 'bg', 'bg_attr', 'boat', 'body', 'bodyOpen',
        'bot_res', 'bx', 'by', 'bye', 'c', 'cName', 'c_title', 'campID',
        'campPass', 'cause', 'changed', 'charCol', 'checked', 'chk', 'click_com', 'click_com2',
        'click_com3', 'click_com4', 'cmail', 'cmdcount', 'cname', 'cnum', 'code', 'col',
        'color', 'com', 'comArray', 'comName', 'comStr', 'com_count', 'com_max', 'command',
        'command2', 'comment', 'commentValue', 'cookie', 'corps', 'correct', 'cost', 'count',
        'count2', 'cpu', 'cpv', 'cpwd', 'crypt', 'cryptOn', 'csmail', 'csti',
        'ct', 'ct1', 'ct2', 'ct3', 'ct4', 'ctDate', 'ctHour', 'ctMin',
        'ctMon', 'ctSec', 'ctYear', 'ctarea', 'ctbl', 'cur', 'curl', 'currentID',
        'custom', 'cuti', 'd', 'da', 'damage', 'damageA', 'dat', 'data',
        'dataVersion', 'date', 'date2', 'day', 'day2', 'dd', 'default', 'defaultID',
        'defaultTarget', 'default_Kind', 'defence', 'del', 'deleteID', 'deleteIslandId', 'deny', 'deny_addr',
        'deny_host', 'dir', 'direc', 'direction', 'disFire', 'disp', 'dist', 'distance',
        'div', 'divisionT', 'divpw', 'dlimg', 'dn', 'doStr', 'dp', 'dummy',
        'dummy2', 'dx', 'dy', 'efileDir', 'email', 'enaStr', 'end', 'env',
        'enwd', 'err', 'exMark', 'exp', 'f', 'factory', 'farm', 'farm2',
        'ff', 'fields', 'file', 'fileName', 'fileNumber', 'first', 'flag', 'flags',
        'fleet', 'flexTime', 'flg', 'fmapmv', 'fnum', 'fo', 'foldpl', 'food',
        'forceLogPool', 'fset', 'ftime', 'fturnH', 'fturnM', 'fturnh', 'fturnm', 'getLine',
        'gethostbyaddr', 'gqhako', 'graph', 'gtitle', 'gzip', 'h2', 'hakoEditor', 'hakoFile',
        'hakoID', 'hakoPASS', 'hash', 'hay', 'haystack', 'head', 'headKill', 'head_flag',
        'headflag', 'headtitle', 'helpDir', 'hgr', 'hit', 'home', 'host', 'hour',
        'hour0', 'hour2', 'hp', 'html1', 'html2', 'html3', 'htmlBody', 'i',
        'id', 'id1', 'id2', 'id3', 'idx', 'ii', 'im', 'image',
        'imageDir', 'imagesize', 'imgLine', 'in', 'in_email', 'in_msg', 'indexName', 'info',
        'input', 'inserted', 'isdst', 'island', 'island2', 'islandList1', 'islandList2', 'islands',
        'item', 'itemF', 'itemMenu', 'j', 'jj', 'jobpop', 'jp_wd', 'js',
        'k', 'kaisi', 'kazu', 'key', 'keyName', 'keys', 'kind', 'kindVal',
        'kyoutyouturn', 'l', 'lName', 'l_ally', 'l_c', 'l_cost', 'l_id', 'l_kind',
        'l_name', 'lab', 'label', 'land', 'landKeep', 'landKind', 'landName', 'landNameT',
        'landOwner', 'landResist', 'landValue', 'lastTime', 'lastTurn', 'lbbs', 'lcland', 'lclandId',
        'lcookie', 'length', 'level', 'li', 'limit', 'line', 'line2', 'line3',
        'line4', 'lines', 'link', 'list', 'list4', 'loaded', 'lockMode', 'log',
        'logA', 'logB', 'logfile', 'ls', 'ltStr', 'lv', 'lx', 'lx2',
        'm', 'mHp', 'mId', 'mIslandList', 'mKind', 'mName', 'mNameList', 'mStr1',
        'mStr2', 'mStr3', 'mTmp', 'mTurnList', 'mailing', 'mailto', 'mainMode', 'mapdata',
        'mark', 'matches', 'max', 'maxAidFood', 'maxAidMoney', 'maxData', 'maxHP', 'max_line',
        'mday', 'message', 'meta', 'method', 'min', 'min0', 'min2', 'mirange',
        'missile', 'mo', 'mode', 'mode2', 'modeValue', 'moji_col', 'mon', 'mon2',
        'money', 'monsterMove', 'monsters', 'mountain', 'mp', 'mpass1', 'mpass2', 'mpower',
        'msg', 'n', 'nKind', 'name', 'name1', 'name2', 'nationalflag', 'naviExp',
        'naviName', 'naviText', 'naviTitle', 'ncolor', 'needle', 'new', 'newID', 'newRecord',
        'newRecords', 'new_time', 'newmark', 'newsign', 'next', 'nnn', 'no', 'no_color',
        'no_req', 'no_wd', 'nofile', 'now', 'ntmp', 'ntmp2', 'num', 'number',
        'oStr', 'oct', 'ofcolor', 'ofcorps', 'ofdirection', 'offset', 'ofname', 'oforder',
        'ok', 'open', 'order', 'ostr', 'out', 'out_msg', 'ov', 'ow',
        'owner', 'ownerID', 'ownername', 'ows', 'oxStr', 'oya', 'oya_req', 'p',
        'p1', 'p2', 'pId', 'pName', 'p_tree', 'pad', 'page', 'pairs',
        'parentNo', 'parts', 'pass', 'passCheck', 'password', 'past', 'pastdir', 'pastkey',
        'pat', 'path', 'paths', 'pattern', 'pcp_passwd', 'pcp_time', 'plain', 'po',
        'point', 'pop', 'pop1', 'pop2', 'pop3', 'popsol', 'popsolID', 'popsolMode',
        'pos', 'pos2', 'post_flag', 'postonly', 'pqhako', 'prize', 'psturn', 'pt',
        'ptn', 'pview', 'pw', 'pwct', 'pwd', 'r', 'radio', 'radio2',
        'range', 'rank', 'raw', 'reason', 'records', 'refcol', 'referer', 'regCtl',
        'regist', 'regist_key', 'registkeyphp', 'regkey_pt', 'regkeylib', 'remainNumber', 'remainTime', 'reno',
        'rep_color', 'replacement', 'requireCamp', 'res_msg', 'res_sub', 'rest', 'retime_default', 'retime_list',
        'rl', 'rt', 'rtStr', 'rtn', 's', 'sArea', 'sArray', 'sBaseLevelUp',
        'sBaseLevelUp2', 'sID', 'sIsland', 'sName', 'sNo', 'sPop', 's_arg', 's_kind',
        's_list', 's_list2', 's_list3', 's_list4', 's_target', 's_x', 's_y', 'salt',
        'score', 'script', 'seaCount', 'sec', 'sec2', 'seichipnt', 'select', 'select_list',
        'sendmail', 'set_DivPw', 'set_DivPwC', 'set_color', 'set_com', 'set_island', 'set_listcom', 'set_map',
        'set_missile', 'set_owner', 'set_resist', 'set_turn', 'setsumei', 'setuplist', 'sfFlag', 'sflg',
        'sftime', 'sig', 'sikiri', 'skipTop', 'sm', 'smail', 'sno', 'so',
        'soldier', 'soldierF', 'sortcnt', 'sp', 'spass1', 'spass2', 'speaker', 'spec',
        'special', 'spnt', 'spoint', 'src', 'ss', 'sss', 'st', 'start',
        'statistical', 'sti', 'str', 'str1', 'str2', 'str3', 'str4', 'str5',
        'str_crypt', 'str_plain', 'sttime', 'sub', 'sub2', 'sub_color', 'sub_length', 'subject',
        'suf', 'supply', 'support', 'switchStr', 'sx', 'sy', 't', 'tAlly',
        'tId', 'tId2', 'tIsland', 'tL', 'tLname', 'tLv', 'tName', 'tName2',
        'tOfname', 'tOforder', 'tOrgName', 'tPoint', 'tTarget', 't_color', 't_h', 't_img',
        't_point', 't_size', 't_w', 'takokuse', 'takokuyu', 'target', 'targets', 'tbl_color',
        'te', 'text_width', 'thread', 'time', 'timeString', 'times', 'title', 'tmp',
        'tmp2', 'tmpid', 'tmpx', 'tmpy', 'tn', 'tn1', 'tn2', 'top',
        'top_sort', 'toppage', 'treehead', 'turn', 'turn2', 'turnCt', 'turns', 'tx',
        'ty', 'type', 'unitPt', 'unlockTime', 'up', 'url', 'urlnum', 'uti',
        'v', 'v_msg', 'va', 'val', 'vals', 'value', 'vb', 'ver',
        'version', 'versionInfo', 'view', 'vl', 'w', 'w1', 'w2', 'wId',
        'wait', 'warC', 'warName', 'warP', 'warS', 'wd', 'wday', 'weapon',
        'week', 'wf_list_i', 'wf_reply_msg', 'wf_reply_sub', 'wid', 'wide', 'width', 'widthsize',
        'wname', 'words', 'wrap', 'wv', 'x', 'xy', 'y', 'yday',
        'yday2', 'year', 'year2', 'z',
    ) as $__hako_pre_var) { if (!array_key_exists($__hako_pre_var, $GLOBALS)) { $GLOBALS[$__hako_pre_var] = null; } }
}
if (!function_exists('hako_get_env')) {
/*
 * 함수: hako_get_env()
 * 역할: 원본 CGI에서 변환된 보조 함수입니다. 전역 변수, 저장 포맷, 출력 문자열을 원본 흐름에 맞춰 유지합니다.
 * 원본 대응: hako/hako-compat.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function hako_get_env($key) {
    if (isset($_SERVER[$key])) { return $_SERVER[$key]; }
    $env = getenv($key);
    if ($env !== false) { return $env; }
    if ($key === 'QUERY_STRING' && isset($_SERVER['QUERY_STRING'])) { return $_SERVER['QUERY_STRING']; }
    if ($key === 'HTTP_COOKIE') {
        $pairs = array();
        foreach ($_COOKIE as $k => $v) { $pairs[] = $k . '=' . $v; }
        return implode('; ', $pairs);
    }
    return '';
}
/*
 * 함수: hako_open()
 * 역할: 원본 CGI에서 변환된 보조 함수입니다. 전역 변수, 저장 포맷, 출력 문자열을 원본 흐름에 맞춰 유지합니다.
 * 원본 대응: hako/hako-compat.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function hako_open($name, $spec) {
    global $_hako_fh;
    $mode = 'r'; $path = $spec;
    if (substr($path,0,2) === '>>') { $mode = 'a'; $path = substr($path,2); }
    elseif (substr($path,0,1) === '>') { $mode = 'w'; $path = substr($path,1); }
    elseif (substr($path,0,1) === '<') { $mode = 'r'; $path = substr($path,1); }
    $dir = dirname($path);
    if (($mode === 'w' || $mode === 'a') && $dir !== '.' && $dir !== '' && !is_dir($dir)) { @mkdir($dir, 0777, true); }
    $_hako_fh[$name] = @fopen($path, $mode);
    return $_hako_fh[$name] ? true : false;
}
/*
 * 함수: hako_close()
 * 역할: 원본 CGI에서 변환된 보조 함수입니다. 전역 변수, 저장 포맷, 출력 문자열을 원본 흐름에 맞춰 유지합니다.
 * 원본 대응: hako/hako-compat.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function hako_close($name) { global $_hako_fh; if (isset($_hako_fh[$name]) && is_resource($_hako_fh[$name])) { @fflush($_hako_fh[$name]); fclose($_hako_fh[$name]); } }
/*
 * 함수: hako_getline()
 * 역할: 원본 CGI에서 변환된 보조 함수입니다. 전역 변수, 저장 포맷, 출력 문자열을 원본 흐름에 맞춰 유지합니다.
 * 원본 대응: hako/hako-compat.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function hako_getline($name) { global $_hako_fh; if (!isset($_hako_fh[$name]) || !is_resource($_hako_fh[$name])) { return false; } return fgets($_hako_fh[$name]); }
/*
 * 함수: hako_read_all_lines()
 * 역할: 원본 CGI에서 변환된 보조 함수입니다. 전역 변수, 저장 포맷, 출력 문자열을 원본 흐름에 맞춰 유지합니다.
 * 원본 대응: hako/hako-compat.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function hako_read_all_lines($name) { global $_hako_fh; if (!isset($_hako_fh[$name]) || !is_resource($_hako_fh[$name])) { return array(); } $r = array(); while (($l = fgets($_hako_fh[$name])) !== false) { $r[] = $l; } return $r; }
/*
 * 함수: hako_write()
 * 역할: 원본 CGI에서 변환된 보조 함수입니다. 전역 변수, 저장 포맷, 출력 문자열을 원본 흐름에 맞춰 유지합니다.
 * 원본 대응: hako/hako-compat.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function hako_write($name, $data) { global $_hako_fh; if (!isset($_hako_fh[$name]) || !is_resource($_hako_fh[$name])) { return false; } if (is_array($data)) { $data = implode('', $data); } return fwrite($_hako_fh[$name], $data); }
/*
 * 함수: hako_chomp()
 * 역할: 원본 CGI에서 변환된 보조 함수입니다. 전역 변수, 저장 포맷, 출력 문자열을 원본 흐름에 맞춰 유지합니다.
 * 원본 대응: hako/hako-compat.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function hako_chomp(&$s) { if (is_array($s)) { foreach($s as &$v) { hako_chomp($v); } return $s; } $s = preg_replace('/(\r\n|\n|\r)$/', '', (string)$s); return $s; }
/*
 * 함수: hako_chop()
 * 역할: 원본 CGI에서 변환된 보조 함수입니다. 전역 변수, 저장 포맷, 출력 문자열을 원본 흐름에 맞춰 유지합니다.
 * 원본 대응: hako/hako-compat.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function hako_chop(&$s) { $s = substr((string)$s, 0, -1); return $s; }
/*
 * 함수: hako_last_index()
 * 역할: 원본 CGI에서 변환된 보조 함수입니다. 전역 변수, 저장 포맷, 출력 문자열을 원본 흐름에 맞춰 유지합니다.
 * 원본 대응: hako/hako-compat.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function hako_last_index($a) { return is_array($a) ? count($a)-1 : -1; }
/*
 * 함수: hako_arr_len()
 * 역할: 원본 CGI에서 변환된 보조 함수입니다. 전역 변수, 저장 포맷, 출력 문자열을 원본 흐름에 맞춰 유지합니다.
 * 원본 대응: hako/hako-compat.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function hako_arr_len($a) { return is_array($a) ? count($a) : 0; }
/*
 * 함수: hako_hex()
 * 역할: 원본 CGI에서 변환된 보조 함수입니다. 전역 변수, 저장 포맷, 출력 문자열을 원본 흐름에 맞춰 유지합니다.
 * 원본 대응: hako/hako-compat.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function hako_hex($s) { return hexdec((string)$s); }
/*
 * 함수: hako_int()
 * 역할: 원본 CGI에서 변환된 보조 함수입니다. 전역 변수, 저장 포맷, 출력 문자열을 원본 흐름에 맞춰 유지합니다.
 * 원본 대응: hako/hako-compat.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function hako_int($v) { return intval($v); }
/*
 * 함수: hako_rand()
 * 역할: 원본 CGI에서 변환된 보조 함수입니다. 전역 변수, 저장 포맷, 출력 문자열을 원본 흐름에 맞춰 유지합니다.
 * 원본 대응: hako/hako-compat.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function hako_rand($max=null) { if ($max === null) { return mt_rand() / mt_getrandmax(); } $max = intval($max); return $max <= 0 ? 0 : mt_rand(0, $max-1); }
/*
 * 함수: hako_time()
 * 역할: 원본 CGI에서 변환된 보조 함수입니다. 전역 변수, 저장 포맷, 출력 문자열을 원본 흐름에 맞춰 유지합니다.
 * 원본 대응: hako/hako-compat.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function hako_time() { return time(); }

/*
 * 함수: hako_safe_pid()
 * 역할: 원본 CGI에서 변환된 보조 함수입니다. 전역 변수, 저장 포맷, 출력 문자열을 원본 흐름에 맞춰 유지합니다.
 * 원본 대응: hako/hako-compat.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function hako_safe_pid() {
    if (function_exists('getmypid')) {
        $p = @getmypid();
        if ($p !== false && $p !== null) { return intval($p); }
    }
    return intval(mt_rand(1, 2147483647));
}

/*
 * 함수: hako_safe_mtime()
 * 역할: 원본 CGI에서 변환된 보조 함수입니다. 전역 변수, 저장 포맷, 출력 문자열을 원본 흐름에 맞춰 유지합니다.
 * 원본 대응: hako/hako-compat.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function hako_safe_mtime($path, $use_lstat=false) {
    $st = $use_lstat ? @lstat($path) : @stat($path);
    if (is_array($st) && isset($st[9])) { return $st[9]; }
    if (file_exists($path)) { return @filemtime($path); }
    return 0;
}

/*
 * 함수: hako_safe_flock()
 * 역할: 원본 CGI에서 변환된 보조 함수입니다. 전역 변수, 저장 포맷, 출력 문자열을 원본 흐름에 맞춰 유지합니다.
 * 원본 대응: hako/hako-compat.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function hako_safe_flock($handle, $operation) {
    if (function_exists('flock')) { return @flock($handle, $operation); }
    return is_resource($handle);
}

/*
 * 함수: hako_gmtime()
 * 역할: 원본 CGI에서 변환된 보조 함수입니다. 전역 변수, 저장 포맷, 출력 문자열을 원본 흐름에 맞춰 유지합니다.
 * 원본 대응: hako/hako-compat.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function hako_gmtime($t=null) { if ($t === null) { $t=time(); } return array(intval(gmdate('s',$t)), intval(gmdate('i',$t)), intval(gmdate('G',$t)), intval(gmdate('j',$t)), intval(gmdate('n',$t))-1, intval(gmdate('Y',$t))-1900, intval(gmdate('w',$t)), intval(gmdate('z',$t)), 0); }
/*
 * 함수: hako_localtime()
 * 역할: 원본 CGI에서 변환된 보조 함수입니다. 전역 변수, 저장 포맷, 출력 문자열을 원본 흐름에 맞춰 유지합니다.
 * 원본 대응: hako/hako-compat.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function hako_localtime($t=null) { if ($t === null) { $t=time(); } return array(intval(date('s',$t)), intval(date('i',$t)), intval(date('G',$t)), intval(date('j',$t)), intval(date('n',$t))-1, intval(date('Y',$t))-1900, intval(date('w',$t)), intval(date('z',$t)), intval(date('I',$t))); }

/*
 * 함수: hako_cookie_pattern()
 * 역할: 원본 CGI에서 변환된 보조 함수입니다. 전역 변수, 저장 포맷, 출력 문자열을 원본 흐름에 맞춰 유지합니다.
 * 원본 대응: hako/hako-compat.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function hako_cookie_pattern($name) {
    $base = isset($GLOBALS['HthisFile']) ? $GLOBALS['HthisFile'] : '';
    return '~' . preg_quote($base . $name, '~') . '=\(([^\)]*)\)~';
}
/*
 * 함수: hako_regex()
 * 역할: 원본 CGI에서 변환된 보조 함수입니다. 전역 변수, 저장 포맷, 출력 문자열을 원본 흐름에 맞춰 유지합니다.
 * 원본 대응: hako/hako-compat.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function hako_regex($pattern, $subject) { $ok = @preg_match($pattern, (string)$subject, $m); $GLOBALS['_hako_match'] = $ok ? $m : array(); return $ok; }
/*
 * 함수: hako_m()
 * 역할: 원본 CGI에서 변환된 보조 함수입니다. 전역 변수, 저장 포맷, 출력 문자열을 원본 흐름에 맞춰 유지합니다.
 * 원본 대응: hako/hako-compat.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function hako_m($i) { return isset($GLOBALS['_hako_match'][$i]) ? $GLOBALS['_hako_match'][$i] : ''; }
/*
 * 함수: hako_subst()
 * 역할: 원본 CGI에서 변환된 보조 함수입니다. 전역 변수, 저장 포맷, 출력 문자열을 원본 흐름에 맞춰 유지합니다.
 * 원본 대응: hako/hako-compat.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function hako_subst(&$s, $pattern, $replacement, $limit=-1) { $subject = (string)$s; $ok = @preg_match($pattern, $subject, $m); $GLOBALS['_hako_match'] = $ok ? $m : array(); $s = preg_replace($pattern, $replacement, $subject, $limit); return $s; }
/*
 * 함수: hako_subst_match()
 * 역할: 원본 CGI에서 변환된 보조 함수입니다. 전역 변수, 저장 포맷, 출력 문자열을 원본 흐름에 맞춰 유지합니다.
 * 원본 대응: hako/hako-compat.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function hako_subst_match(&$s, $pattern, $replacement, $limit=-1) { $subject = (string)$s; $ok = @preg_match($pattern, $subject, $m); $GLOBALS['_hako_match'] = $ok ? $m : array(); $count = 0; $s = preg_replace($pattern, $replacement, $subject, $limit, $count); return $count; }
/*
 * 함수: hako_shift_str()
 * 역할: 원본 CGI에서 변환된 보조 함수입니다. 전역 변수, 저장 포맷, 출력 문자열을 원본 흐름에 맞춰 유지합니다.
 * 원본 대응: hako/hako-compat.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function hako_shift_str(&$s, $pattern) { if (@preg_match($pattern, (string)$s, $m)) { $GLOBALS['_hako_match'] = $m; $s = preg_replace($pattern, '', (string)$s, 1); return true; } $GLOBALS['_hako_match'] = array(); return false; }
/*
 * 함수: hako_defined()
 * 역할: 원본 CGI에서 변환된 보조 함수입니다. 전역 변수, 저장 포맷, 출력 문자열을 원본 흐름에 맞춰 유지합니다.
 * 원본 대응: hako/hako-compat.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function hako_defined($v) { return isset($v); }
/*
 * 함수: hako_html_escape()
 * 역할: 원본 CGI에서 변환된 보조 함수입니다. 전역 변수, 저장 포맷, 출력 문자열을 원본 흐름에 맞춰 유지합니다.
 * 원본 대응: hako/hako-compat.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function hako_html_escape($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
/*
 * 함수: hako_url_decode()
 * 역할: 원본 CGI에서 변환된 보조 함수입니다. 전역 변수, 저장 포맷, 출력 문자열을 원본 흐름에 맞춰 유지합니다.
 * 원본 대응: hako/hako-compat.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function hako_url_decode($s) { return rawurldecode(str_replace('+',' ',(string)$s)); }
/*
 * 함수: hako_rindex()
 * 역할: 원본 CGI에서 변환된 보조 함수입니다. 전역 변수, 저장 포맷, 출력 문자열을 원본 흐름에 맞춰 유지합니다.
 * 원본 대응: hako/hako-compat.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function hako_rindex($haystack,$needle) { $p = strrpos((string)$haystack,(string)$needle); return $p === false ? -1 : $p; }
/*
 * 함수: hako_index()
 * 역할: 원본 CGI에서 변환된 보조 함수입니다. 전역 변수, 저장 포맷, 출력 문자열을 원본 흐름에 맞춰 유지합니다.
 * 원본 대응: hako/hako-compat.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function hako_index($haystack,$needle) { $p = strpos((string)$haystack,(string)$needle); return $p === false ? -1 : $p; }
/*
 * 함수: hako_splice()
 * 역할: 원본 CGI에서 변환된 보조 함수입니다. 전역 변수, 저장 포맷, 출력 문자열을 원본 흐름에 맞춰 유지합니다.
 * 원본 대응: hako/hako-compat.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function hako_splice(&$array, $offset, $length=null, $replacement=array()) { if (!is_array($array)) { $array=array(); } $offset = intval($offset); if ($length === null) { return array_splice($array,$offset); } return array_splice($array,$offset,intval($length),$replacement); }

/*
 * 함수: hako_arg()
 * 역할: 원본 CGI에서 변환된 보조 함수입니다. 전역 변수, 저장 포맷, 출력 문자열을 원본 흐름에 맞춰 유지합니다.
 * 원본 대응: hako/hako-compat.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function hako_arg($args, $idx, $default=null) { return (is_array($args) && isset($args[$idx])) ? $args[$idx] : $default; }
/*
 * 함수: hako_unshift()
 * 역할: 원본 CGI에서 변환된 보조 함수입니다. 전역 변수, 저장 포맷, 출력 문자열을 원본 흐름에 맞춰 유지합니다.
 * 원본 대응: hako/hako-compat.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function hako_unshift(&$array) { if (!is_array($array)) { $array=array(); } $args=func_get_args(); array_shift($args); foreach(array_reverse($args) as $a){ array_unshift($array,$a); } return count($array); }
/*
 * 함수: hako_array_first()
 * 역할: 원본 CGI에서 변환된 보조 함수입니다. 전역 변수, 저장 포맷, 출력 문자열을 원본 흐름에 맞춰 유지합니다.
 * 원본 대응: hako/hako-compat.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function hako_array_first($array, $default=null) { return (is_array($array) && isset($array[0])) ? $array[0] : $default; }
/*
 * 함수: hako_push()
 * 역할: 원본 CGI에서 변환된 보조 함수입니다. 전역 변수, 저장 포맷, 출력 문자열을 원본 흐름에 맞춰 유지합니다.
 * 원본 대응: hako/hako-compat.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function hako_push(&$array) { if (!is_array($array)) { $array=array(); } $args=func_get_args(); array_shift($args); foreach($args as $a){ if(is_array($a)){ foreach($a as $v){ $array[]=$v; } } else { $array[]=$a; } } return count($array); }
/*
 * 함수: hako_pop()
 * 역할: 원본 CGI에서 변환된 보조 함수입니다. 전역 변수, 저장 포맷, 출력 문자열을 원본 흐름에 맞춰 유지합니다.
 * 원본 대응: hako/hako-compat.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function hako_pop(&$array) { if (!is_array($array)) { $array=array(); return null; } return array_pop($array); }
/*
 * 함수: hako_unlink()
 * 역할: 원본 CGI에서 변환된 보조 함수입니다. 전역 변수, 저장 포맷, 출력 문자열을 원본 흐름에 맞춰 유지합니다.
 * 원본 대응: hako/hako-compat.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function hako_unlink($path) { return @unlink($path); }

/*
 * 함수: hako_replace_file()
 * 역할: 임시 파일을 실제 저장 파일로 교체합니다.
 * 유지보수: PHP 5.5 공유호스팅에서 unlink 후 rename 실패가 발생하면 원본 데이터가 사라질 수 있으므로,
 *           먼저 rename을 시도하고 실패할 때만 copy 방식으로 덮어씁니다.
 */
function hako_replace_file($tmp, $dest) {
    $dir = dirname($dest);
    if ($dir !== '.' && $dir !== '' && !is_dir($dir)) { @mkdir($dir, 0777, true); }
    if (!file_exists($tmp)) { return false; }
    if (@rename($tmp, $dest)) { return true; }
    if (@copy($tmp, $dest)) { @unlink($tmp); return true; }
    return false;
}

/*
 * 함수: hako_safe_rmtree()
 * 역할: 백업 디렉터리를 재귀적으로 삭제합니다.
 * 유지보수: 원본 CGI의 myrmtree는 백업 회전용입니다. PHP 서버에서는 빈 폴더가 아닌 경우 rmdir이 실패할 수 있어 재귀 삭제합니다.
 */
function hako_safe_rmtree($path) {
    if ($path === '' || $path === '.' || $path === '..') { return false; }
    if (!file_exists($path)) { return true; }
    if (is_file($path) || is_link($path)) { return @unlink($path); }
    $dh = @opendir($path);
    if (!$dh) { return false; }
    while (($file = readdir($dh)) !== false) {
        if ($file === '.' || $file === '..') { continue; }
        hako_safe_rmtree($path . '/' . $file);
    }
    @closedir($dh);
    return @rmdir($path);
}

/*
 * 함수: hako_safe_copy_tree()
 * 역할: 데이터 디렉터리를 백업 디렉터리로 복사합니다.
 * 유지보수: 라이브 data 디렉터리를 rename하지 않고 백업만 생성하여 턴 처리 중 데이터 경로가 사라지지 않게 합니다.
 */
function hako_safe_copy_tree($src, $dst, $mode=0777) {
    if (!is_dir($src)) { return false; }
    if (!is_dir($dst)) { @mkdir($dst, $mode, true); }
    $dh = @opendir($src);
    if (!$dh) { return false; }
    while (($file = readdir($dh)) !== false) {
        if ($file === '.' || $file === '..') { continue; }
        $s = $src . '/' . $file;
        $d = $dst . '/' . $file;
        if (is_dir($s) && !is_link($s)) {
            hako_safe_copy_tree($s, $d, $mode);
        } else {
            @copy($s, $d);
        }
    }
    @closedir($dh);
    return true;
}

/*
 * 함수: hako_safe_backup_dir()
 * 역할: 턴 백업을 생성합니다.
 * 유지보수: 원본 CGI는 data 디렉터리를 data.bak0으로 rename한 뒤 data를 다시 만들지만,
 *           PHP 5.5 공유호스팅에서는 이 과정에서 화면이 빈 상태로 중단될 수 있습니다.
 *           화면/게임 계산에는 영향을 주지 않는 백업 방식만 copy 기반으로 바꿉니다.
 */
function hako_safe_backup_dir($dir, $times, $mode=0777) {
    $times = intval($times);
    if ($times <= 0) { return true; }
    $last = $times - 1;
    hako_safe_rmtree($dir . '.bak' . $last);
    for ($i = $last; $i > 0; $i--) {
        $from = $dir . '.bak' . ($i - 1);
        $to = $dir . '.bak' . $i;
        if (file_exists($from)) { @rename($from, $to); }
    }
    if (file_exists($dir . '.bak0')) { hako_safe_rmtree($dir . '.bak0'); }
    return hako_safe_copy_tree($dir, $dir . '.bak0', $mode);
}

/*
 * 함수: hako_rename()
 * 역할: 원본 CGI에서 변환된 보조 함수입니다. 전역 변수, 저장 포맷, 출력 문자열을 원본 흐름에 맞춰 유지합니다.
 * 원본 대응: hako/hako-compat.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function hako_rename($a,$b) { return @rename($a,$b); }
/*
 * 함수: hako_copy()
 * 역할: 원본 CGI에서 변환된 보조 함수입니다. 전역 변수, 저장 포맷, 출력 문자열을 원본 흐름에 맞춰 유지합니다.
 * 원본 대응: hako/hako-compat.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function hako_copy($a,$b) { $dir=dirname($b); if ($dir!=='.' && !is_dir($dir)) { @mkdir($dir,0777,true); } return @copy($a,$b); }
/*
 * 함수: hako_file_exists()
 * 역할: 원본 CGI에서 변환된 보조 함수입니다. 전역 변수, 저장 포맷, 출력 문자열을 원본 흐름에 맞춰 유지합니다.
 * 원본 대응: hako/hako-compat.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function hako_file_exists($p) { return file_exists($p); }
/*
 * 함수: hako_file_age_days()
 * 역할: 원본 CGI에서 변환된 보조 함수입니다. 전역 변수, 저장 포맷, 출력 문자열을 원본 흐름에 맞춰 유지합니다.
 * 원본 대응: hako/hako-compat.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function hako_file_age_days($p) { return file_exists($p) ? ((time() - filemtime($p)) / 86400.0) : 0; }
/*
 * 함수: hako_crypt()
 * 역할: 원본 CGI에서 변환된 보조 함수입니다. 전역 변수, 저장 포맷, 출력 문자열을 원본 흐름에 맞춰 유지합니다.
 * 원본 대응: hako/hako-compat.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function hako_crypt($pass,$salt) { return crypt((string)$pass,(string)$salt); }
/*
 * 함수: hako_cpu_times()
 * 역할: 원본 CGI에서 변환된 보조 함수입니다. 전역 변수, 저장 포맷, 출력 문자열을 원본 흐름에 맞춰 유지합니다.
 * 원본 대응: hako/hako-compat.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function hako_cpu_times() {
    if (function_exists('getrusage')) {
        $u = @getrusage();
        if (is_array($u)) {
            $uti  = (isset($u['ru_utime.tv_sec']) ? $u['ru_utime.tv_sec'] : 0) + ((isset($u['ru_utime.tv_usec']) ? $u['ru_utime.tv_usec'] : 0) / 1000000);
            $sti  = (isset($u['ru_stime.tv_sec']) ? $u['ru_stime.tv_sec'] : 0) + ((isset($u['ru_stime.tv_usec']) ? $u['ru_stime.tv_usec'] : 0) / 1000000);
            $cuti = (isset($u['ru_cutime.tv_sec']) ? $u['ru_cutime.tv_sec'] : 0) + ((isset($u['ru_cutime.tv_usec']) ? $u['ru_cutime.tv_usec'] : 0) / 1000000);
            $csti = (isset($u['ru_cstime.tv_sec']) ? $u['ru_cstime.tv_sec'] : 0) + ((isset($u['ru_cstime.tv_usec']) ? $u['ru_cstime.tv_usec'] : 0) / 1000000);
            return array($uti, $sti, $cuti, $csti);
        }
    }
    return array(0,0,0,0);
}

/*
 * 함수: hako_range_list()
 * 역할: 원본 CGI에서 변환된 보조 함수입니다. 전역 변수, 저장 포맷, 출력 문자열을 원본 흐름에 맞춰 유지합니다.
 * 원본 대응: hako/hako-compat.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function hako_range_list($start, $end) { $start = intval($start); $end = intval($end); if ($end < $start) { return array(); } return range($start, $end); }
/*
 * 함수: hako_permute()
 * 역할: 원본 CGI에서 변환된 보조 함수입니다. 전역 변수, 저장 포맷, 출력 문자열을 원본 흐름에 맞춰 유지합니다.
 * 원본 대응: hako/hako-compat.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function hako_permute($array, $idx) { $out = array(); if (!is_array($array) || !is_array($idx)) { return $out; } foreach ($idx as $i) { if (array_key_exists($i, $array)) { $out[] = $array[$i]; } } return $out; }
/*
 * 함수: hako_path_value()
 * 역할: 원본 CGI에서 변환된 보조 함수입니다. 전역 변수, 저장 포맷, 출력 문자열을 원본 흐름에 맞춰 유지합니다.
 * 원본 대응: hako/hako-compat.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function hako_path_value($array, $path) { $v = $array; foreach ($path as $k) { if (is_array($v) && array_key_exists($k, $v)) { $v = $v[$k]; } else { return 0; } } return $v; }
/*
 * 함수: hako_sort_indices_desc_path()
 * 역할: 원본 CGI에서 변환된 보조 함수입니다. 전역 변수, 저장 포맷, 출력 문자열을 원본 흐름에 맞춰 유지합니다.
 * 원본 대응: hako/hako-compat.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function hako_sort_indices_desc_path($array, $path) { $idx = hako_range_list(0, hako_last_index($array)); usort($idx, function($a, $b) use ($array, $path) { $vb = hako_path_value(isset($array[$b]) ? $array[$b] : array(), $path); $va = hako_path_value(isset($array[$a]) ? $array[$a] : array(), $path); if ($vb == $va) { return hako_cmp($a, $b); } return hako_cmp($vb, $va); }); return $idx; }

/*
 * 함수: out()
 * 역할: HTML을 출력합니다. 자동 변형 없이 원본 문자열을 그대로 내보내야 합니다.
 * 원본 대응: hako/hako-compat.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function out($s) { echo $s; }
/*
 * 함수: hako_get()
 * 역할: 원본 CGI에서 변환된 보조 함수입니다. 전역 변수, 저장 포맷, 출력 문자열을 원본 흐름에 맞춰 유지합니다.
 * 원본 대응: hako/hako-compat.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function hako_get($array, $key, $default=null) { return (is_array($array) && isset($array[$key])) ? $array[$key] : $default; }

/*
 * 함수: timelocal()
 * 역할: 원본 CGI에서 변환된 보조 함수입니다. 전역 변수, 저장 포맷, 출력 문자열을 원본 흐름에 맞춰 유지합니다.
 * 원본 대응: hako/hako-compat.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function timelocal($sec, $min, $hour, $mday, $mon, $year) { $year = intval($year); if ($year < 1000) { $year += 1900; } return mktime(intval($hour), intval($min), intval($sec), intval($mon) + 1, intval($mday), $year); }
/*
 * 함수: length()
 * 역할: 원본 CGI에서 변환된 보조 함수입니다. 전역 변수, 저장 포맷, 출력 문자열을 원본 흐름에 맞춰 유지합니다.
 * 원본 대응: hako/hako-compat.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function length($v) { return is_array($v) ? count($v) : strlen((string)$v); }
/*
 * 함수: reverse()
 * 역할: 원본 CGI에서 변환된 보조 함수입니다. 전역 변수, 저장 포맷, 출력 문자열을 원본 흐름에 맞춰 유지합니다.
 * 원본 대응: hako/hako-compat.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function reverse($v) { return is_array($v) ? array_reverse($v) : strrev((string)$v); }
/*
 * 함수: hako_cmp()
 * 역할: 원본 CGI에서 변환된 보조 함수입니다. 전역 변수, 저장 포맷, 출력 문자열을 원본 흐름에 맞춰 유지합니다.
 * 원본 대응: hako/hako-compat.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function hako_cmp($a,$b) { if ($a == $b) return 0; return ($a < $b) ? -1 : 1; }
/*
 * 함수: hako_safe()
 * 역할: 원본 CGI에서 변환된 보조 함수입니다. 전역 변수, 저장 포맷, 출력 문자열을 원본 흐름에 맞춰 유지합니다.
 * 원본 대응: hako/hako-compat.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function hako_safe($a,$k,$default=null) { return (is_array($a) && isset($a[$k])) ? $a[$k] : $default; }
}

/*
 * 함수: hako_prepare_long_turn()
 * 역할: 턴 처리 중 PHP 5.5 공유호스팅의 기본 실행 시간 제한으로 중간 종료되는 것을 줄입니다.
 * 출력/저장 로직은 변경하지 않고, 사용 가능한 서버 함수만 조용히 호출합니다.
 */
function hako_prepare_long_turn() {
    if (function_exists('ignore_user_abort')) { @ignore_user_abort(true); }
    if (function_exists('set_time_limit')) { @set_time_limit(180); }
    if (function_exists('ini_set')) { @ini_set('max_execution_time', '180'); }
}
