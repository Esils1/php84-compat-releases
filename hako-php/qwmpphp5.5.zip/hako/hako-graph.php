<?php

/*
 * hako/hako-graph.php
 * ------------------------------------------------------------
 * 그래프 데이터 출력 모듈
 *
 * 상세 주석 기준:
 * - 원본 대응: qwmp155.zip 의 hako-graph.cgi.
 * - 인구/병력/면적/자원 그래프 데이터를 읽어서 HTML/스크립트로 출력합니다.
 * - 그래프 데이터 파일이 없을 때 원본처럼 조용히 처리해야 하며 PHP Warning을 화면에 노출하면 안 됩니다.
 * - 원본 CGI 주석 라인 확인 수: 36줄. PHP 주석은 실행 결과를 바꾸지 않는 범위에서 복원/보강했습니다.
 *
 * 유지보수 원칙:
 * - 실행 로직, 저장 포맷, 배열 인덱스, 출력 HTML은 원본 CGI 호환성 대상입니다.
 * - 개조가 필요하면 먼저 해당 변수/함수가 어떤 파일 저장값과 연결되는지 확인하십시오.
 * - 이 주석은 유지보수용이며 실행 결과를 바꾸지 않습니다.
 */

chdir(dirname(__FILE__));
require_once dirname(__FILE__) . '/hako-compat.php';






$version = "version0.20";









require_once './hako-init.php';
require_once './hako-io.php';


$color = array('blue','yellow','red','green','black','maroon','purple','lime','fuchsia',
			'olive','navy','teal','aqua','pink','lavender','salmon','Gold','gray');


$bye = "$HbaseDir/hako-main.php";


$gtitle['pop']   = '(백)　<b>인구의 그래프</b>';
$gtitle['sol']   = '(백)　<b>병력의 그래프</b>';
$gtitle['area']  = '(Hex)　<b>영토의 그래프</b>';
$gtitle['power'] = '(P)　<b>국력의 그래프</b>';




$src = "";

$mode = 1;

tempHeader();
readGraphFile("pop");
readGraphFile("sol");
readGraphFile("area");
readGraphFile("power");
tempFooter();


exit(0);





/*
 * 함수: tempHeader()
 * 역할: 공통 HTML 헤더를 출력합니다.
 * 원본 대응: hako/hako-graph.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function tempHeader() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	if (!headers_sent()) { header('Content-Type: text/html; charset=UTF-8'); }
	$src .= <<<HAKOHDOC_1
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html lang="kr">
<head>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
<TITLE>모형정원 공통 맵 N 그래프 표시</TITLE>
<script type="text/javascript" src="$imageDir/includes/excanvas.js"></script>
<script type="text/javascript" src="$imageDir/includes/chart.js"></script>
<script type="text/javascript" src="$imageDir/includes/canvaschartpainter.js"></script>
<link rel="stylesheet" type="text/css" href="$imageDir/includes/canvaschart.css" />
<style type="text/css">
	html, body { border: none; padding: 0px; margin: 0px; }
</style>
</HEAD>
<BODY>
<FORM>
<A HREF="$bye">[돌아온다]</A>　　<B>모형정원 공통 맵 N　각종 그래프 표시</B>[
<INPUT TYPE="button" VALUE="인구" onClick="pop()">
<INPUT TYPE="button" VALUE="병력" onClick="sol()">
<INPUT TYPE="button" VALUE="영토" onClick="area()">
<INPUT TYPE="button" VALUE="국력" onClick="power()">
]
</FORM><hr>
<SPAN ID=GraphTitle></SPAN>
<div id="chart" class="chart" style="width: 1000px; height: 500px;"></div>
<script type="text/javascript">

HAKOHDOC_1
;
}
/*
 * 함수: tempFooter()
 * 역할: 공통 HTML 푸터와 CPU 표시를 출력합니다.
 * 원본 대응: hako/hako-graph.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function tempFooter() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$src .= <<<HAKOHDOC_2
window.onload = function() {
	pop();
};
</script>
<HR>
<DIV align="right"><SMALL><a href="http://www8.plala.or.jp/nayupon/">모형정원 공통 맵 N　각종 그래프 표시 </a></SMALL></DIV>
</BODY></HTML>
HAKOHDOC_2
;
	if ($mode) {
		hako_open('OUT', ">{$HefileDir}/graph.html");
		hako_write('OUT', ($src));
		hako_close('OUT');
		@chmod("{$HefileDir}/graph.html", 0666);

		out("<meta HTTP-EQUIV=\"refresh\" CONTENT=\"0; URL={$efileDir}/graph.html\">");
	} else {
		out("$src");
	}
}



/*
 * 함수: readGraphFile()
 * 역할: 그래프 데이터 파일을 읽어 화면에 출력합니다.
 * 원본 대응: hako/hako-graph.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function readGraphFile() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	unset($file); $file = isset($_args[0]) ? $_args[0] : null;
	unset($line); $line = array();
	unset($line2); $line2 = array();
	unset($line3); $line3 = array();
	unset($line4); $line4 = array();
	unset($tmp2); $tmp2 = null;
	unset($l); $l = null;
	unset($i); $i = null;
	unset($j); $j = null;
	unset($count); $count = null;
	unset($turn); $turn = null;
	unset($turn2); $turn2 = null;
	
	hako_open('HIN', "{$HdirName}/$file.0");
	while ($l = hako_getline('HIN')) {
		hako_chomp($l); hako_push($line, $l);
		$count++;
	}
	hako_close('HIN');
	if (!isset($line[0])) { $line[0] = ''; $count = 1; }
	unset($tmp); $tmp = explode(',', $line[0]);
	hako_splice($tmp, 0, 1);
	
	$src .= <<<HAKOHDOC_3
function $file() {
document.getElementById("GraphTitle").innerHTML = "$gtitle[$file]";
var c = new Chart(document.getElementById('chart'));
c.setDefaultType(CHART_LINE);
HAKOHDOC_3
;
	$turn = hako_last_index($tmp) + 1;
	
	$turn2 = intval($turn / 2);
	$tmp2 = "c.setGridDensity($turn2,10);";
	$src .= "$tmp2\n";

	
	$tmp2 = "c.setHorizontalLabels([";
	
	$i = ($turn % 2 == 0) ? 2 : 3;
	for (; $i <= $turn; $i+=2) {
			$tmp2 .= "'$i',";
	}
	hako_chop($tmp2);
	$tmp2 .= "]);";
	$src .= "$tmp2\n";

	for ($i = 0; $i < $count-1; $i++) {
		unset($tmp); $tmp = explode(',', $line[$i+1]);
		
		if ($turn > 35) {
			if ($tmp[35] == '0') { continue; }
		}
		$tmp2 = "c.add('$tmp[1]','$color[$i]',[";
		
		$j = ($turn % 2 == 0) ? 2 : 3;
		for (; $j <= $turn; $j++) {
			$tmp2 .= "$tmp[$j],";
		}
		hako_chop($tmp2);
		$tmp2 .= "]);";
		$src .= "$tmp2\n";
	}
	$src .= <<<HAKOHDOC_4
c.draw();
}
HAKOHDOC_4
;
}


?>
