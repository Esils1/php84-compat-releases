<?php

/*
 * hako/hako-make.php
 * ------------------------------------------------------------
 * 신규 섬 생성/섬 설정 변경/관리자 편집 모듈
 *
 * 상세 주석 기준:
 * - 원본 대응: qwmp155.zip 의 hako-make.cgi.
 * - 새 섬 생성, 이름/소유자/비밀번호 변경, 섬 삭제, 관리자에 의한 자원/외교/지형 변경, 맵 에디터 연계를 담당합니다.
 * - 섬 생성 위치와 초기 지형은 원본 난수/좌표 규칙을 유지해야 기존 CGI와 같은 게임 흐름이 됩니다.
 * - 관리자 편집은 저장 파일을 직접 바꾸므로 출력 주석과 별개로 배열 키/순서/파일명 변경을 금지합니다.
 * - 맵 에디터 출력은 전각 공백과 HTML 조각까지 CGI 원본과 비교 대상입니다.
 * - 원본 CGI 주석 라인 확인 수: 177줄. PHP 주석은 실행 결과를 바꾸지 않는 범위에서 복원/보강했습니다.
 *
 * 유지보수 원칙:
 * - 실행 로직, 저장 포맷, 배열 인덱스, 출력 HTML은 원본 CGI 호환성 대상입니다.
 * - 개조가 필요하면 먼저 해당 변수/함수가 어떤 파일 저장값과 연결되는지 확인하십시오.
 * - 이 주석은 유지보수용이며 실행 결과를 바꾸지 않습니다.
 */

chdir(dirname(__FILE__));
require_once dirname(__FILE__) . '/hako-compat.php';
if (function_exists('htmlEscape')) { $HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : ''); } else { $HdefaultPasswordEsc = isset($HdefaultPassword) ? $HdefaultPassword : ''; }












/*
 * 함수: newIslandMain()
 * 역할: 신규 섬 생성 화면과 입력 검증 흐름을 처리합니다.
 * 원본 대응: hako/hako-make.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function newIslandMain() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	
	if ($HislandNumber >= $HmaxIsland) {
		unlock();
		tempNewIslandFull();
		return;
	}

	
	if ($HcurrentName == '') {
		unlock();
		tempNewIslandNoName();
		return;
	}

	
	if (hako_regex('~[\\,\?\(\)\<\>\$]|^무인$|^[ 　]+$~', $HcurrentName)) {
		
		unlock();
		tempNewIslandBadName();
		return;
	}

	
	if (nameToNumber($HcurrentName) != -1) {
		
		unlock();
		tempNewIslandAlready();
		return;
	}

	
	if ($HcurrentOwnerName == '') {
		unlock();
		tempNewIslandNoOwner();
		return;
	}

	
	if ($HinputPassword == '') {
		
		unlock();
		tempNewIslandNoPassword();
		return;
	}

	
	if ($HinputPassword2 != $HinputPassword) {
		
		unlock();
		tempWrongPassword();
		return;
	}

	
	unset($pos); $pos = array();
	unset($x); $x = null;
	unset($y); $y = null;
	unset($r); $r = null;
	$r = ($Hroundmode) ? 0 : 2;
	if ($HautoPoint) {
		
		if (countAroundValue($HdefaultX, $HdefaultY, $HlandSea, 0, 19) == 19) {
			hako_push($pos, "$HdefaultX,$HdefaultY");
		}
	} else{
		for ($y = $r; $y < $HislandSize - $r; $y++) {
			for ($x = $r; $x < $HislandSize - $r; $x++) {
				if (countAroundValue($x, $y, $HlandSea, 0, 19) == 19) {
					hako_push($pos, "$x,$y");
				}
			}
		}
	}
	if (hako_last_index($pos) < 0) {
		
		tempNewSeaEmpty();
		if (!$HautoPoint) {
			$HislandNFlg = 1;
			writeIslandsFile(0);
		}
		unlock();
		return;
	}

	
	$HcurrentNumber = $HislandNumber;
	$HislandNumber++;
	$Hislands[$HcurrentNumber] = makeNewIsland();
	$island =& $Hislands[$HcurrentNumber];

	
	$island['name'] = $HcurrentName;
	$island['id'] = $HislandNextID;
	$HislandNextID ++;
	$island['absent'] = $HgiveupTurn - 3;
	$island['comment'] = '(미등록)';
	$island['password'] = encode($HinputPassword);
	$island['ownername'] = htmlEscape($HcurrentOwnerName);
	$island['afnameId'] = $HcurrentAFNameId;

	
		if (!isset($island['item']) || !is_array($island['item'])) { $island['item'] = array(); }
		if ($HstartItem > 0) { if (!isset($island['item'][$HstartItem])) { $island['item'][$HstartItem] = 0; } $island['item'][$HstartItem] = intval($island['item'][$HstartItem]) + 1; }

	if ($HislandTurn <= 1) {
		$now = time();
		$island['kaisi'] = $now + 3600;
	} else{
		$island['kaisi'] = $HislandTurn;
	}

	
	$land = $island['land'];
	$landValue = $island['landValue'];
	$landOwner = $island['landOwner'];

	$HidToNumber[$island['id']] = $HcurrentNumber;
	$HidToName[$island['id']] = $HcurrentName;

	
	$_list_tmp = explode(',', $pos[random(hako_last_index($pos) + 1)]);
	$x = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
	$y = isset($_list_tmp[1]) ? $_list_tmp[1] : null;

	
	if (($Hallyflg) && ($Hautoally)) {
		unset($i); $i = null;
		unset($ally); $ally = array();
		unset($allyCount); $allyCount = array();
		
		$island['ally'] = 1;
		for ($_ = 1; $_ <= $Hautoally; $_++) {
			$allyCount[$_] = 1;
		}
		for ($i = 0; $i < $HislandNumber; $i++) {
			
			$allyCount[$Hislands[$i]['ally']]++;
		}
		$ally = array_keys($allyCount); usort($ally, function($a, $b) use ($allyCount) { return hako_cmp($allyCount[$a], $allyCount[$b]); });
		for ($_ = 0; $_ <= $Hautoally; $_++) {
			if ($ally[$_] > 0) {
				$island['ally'] = $ally[$_];
				break;
			}
		}
	}


	
	makeNewLand($island, $x, $y);
	unset($point); $point = "($x, $y)";

	
	estimateM($HcurrentNumber);

	if ($HtopAxes == 1) { axeslog(1,$island['id']); }

	
	unset($pos2); $pos2 = array();
	$r = ($Hroundmode) ? 0 : 2;
	for ($y = $r; $y < $HislandSize - $r; $y++) {
		for ($x = $r; $x < $HislandSize - $r; $x++) {
			if (countAroundValue($x, $y, $HlandSea, 0, 19) == 19) {
				hako_push($pos2, "$x,$y");
			}
		}
	}
	if (hako_last_index($pos2) < 0) { $HislandNFlg = 1; }

	
	writeIslandsFile($island['id']);
	$__afname = isset($Haftername[$HcurrentAFNameId]) ? $Haftername[$HcurrentAFNameId] : '';
	logDiscover($HcurrentName . $__afname); 

	
	unlock();

	
	tempNewIslandHead($HcurrentName . $__afname, $point); 
	islandInfo(); 
	islandMap(1); 
}


/*
 * 함수: makeNewIsland()
 * 역할: 새 섬 데이터를 생성하고 초기 파일을 작성합니다.
 * 원본 대응: hako/hako-make.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function makeNewIsland() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	


	
	unset($command); $command = array();
	unset($i); $i = null;
	for ($i = 0; $i < $HcommandMax; $i++) {
		$command[$i] = array('kind'=>$HcomDoNothing, 'target'=>0, 'x'=>0, 'y'=>0, 'arg'=>0);
	}

	
	unset($lbbs); $lbbs = array();
	for ($i = 0; $i < $HlbbsMax; $i++) {
		$lbbs[$i] = "0<<0>>";
	}

	
		return array(
			'land'=>$Hland, 'landValue'=>$HlandValue, 'landOwner'=>$HlandOwner, 'command'=>$command, 'lbbs'=>$lbbs,
			'money'=>$HinitialMoney, 'food'=>$HinitialFood, 'soldier'=>$HinitialSoldier, 'soldierex'=>0, 'prize'=>'0,0,',
			'score'=>0, 'pop'=>0, 'area'=>0, 'farm'=>0, 'factory'=>0, 'mountain'=>0, 'item'=>array_fill(0,16,''),
			'fleet'=>array_fill(0,8,''), 'direction'=>array_fill(0,8,''), 'order'=>array_fill(0,8,''), 'corps'=>array_fill(0,8,''), 'color'=>array_fill(0,8,''),
			'mpower'=>array_fill(0,16,''), 'custom'=>0, 'ally'=>0, 'soldierF'=>0, 'soldierFex'=>0, 'statistical'=>array_fill(0,6,''),
			'attackA'=>0, 'damageA'=>0, 'nationalflag'=>0, 'predelete'=>0
		);
}


/*
 * 함수: makeNewLand()
 * 역할: 신규 섬의 초기 지형 배열을 생성합니다.
 * 원본 대응: hako/hako-make.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function makeNewLand(&$island, $x, $y) {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if (($__hako_global_key !== 'GLOBALS') && !in_array($__hako_global_key, array('island', 'x', 'y'), true)) { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	$_list_tmp = array($island['id'],$island['land'],$island['landValue'],$island['landOwner']);
	unset($id); $id = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
	unset($land); $land = isset($_list_tmp[1]) ? $_list_tmp[1] : null;
	unset($landValue); $landValue = isset($_list_tmp[2]) ? $_list_tmp[2] : null;
	unset($landOwner); $landOwner = isset($_list_tmp[3]) ? $_list_tmp[3] : null;
	unset($i); $i = null;
	unset($sx); $sx = null;
	unset($sy); $sy = null;
	unset($count); $count = null;

	
	unset($landKind); $landKind = array();
	foreach (array($HlandDefence,$HlandBase,$HlandForest,$HlandMountain,$HlandFarm,$HlandFarm,$HlandFactory) as $_) {
			unset($r); $r = hako_rand(count($landKind) + 1);
			hako_push($landKind, isset($landKind[$r]) ? $landKind[$r] : null);
		$landKind[$r] = $_;
	}
	for ($i = 0; $i < 7; $i++) {
		$sx = $x + $ax[$i];
		$sy = $y + $ay[$i];
		if (!($sy % 2) && ($y % 2)) { $sx--; } 
		if ($Hroundmode) {
			$sx = $correct[$sx + 12];
			$sy = $correct[$sy + 12];
		}
		if (($sx < 0) || ($sx >= $HislandSize) || ($sy < 0) || ($sy >= $HislandSize)) {
			
		} else {
			
			$land[$sx][$sy] = $landKind[$i];
			if (($landKind[$i] == $HlandForest) || ($landKind[$i] == $HlandTown)) {
				$landValue[$sx][$sy] = 20;
			} elseif ($landKind[$i] == $HlandFarm) {
				$landValue[$sx][$sy] = 10;
			} elseif ($landKind[$i] == $HlandFactory) {
				$landValue[$sx][$sy] = 30;
			} elseif ($landKind[$i] == $HlandMountain) {
				$landValue[$sx][$sy] = 20;
			} else{
				$landValue[$sx][$sy] = 0;
			}
			$landOwner[$sx][$sy] = $id;
		}
	}
	
	for ($i = 7; $i < 37; $i++) {
		$sx = $x + $ax[$i];
		$sy = $y + $ay[$i];
		if (!($sy % 2) && ($y % 2)) { $sx--; } 
		if ($Hroundmode) {
			$sx = $correct[$sx + 12];
			$sy = $correct[$sy + 12];
		}
		if (($sx < 0) || ($sx >= $HislandSize) || ($sy < 0) || ($sy >= $HislandSize)) {
			
		} else {
			
			if ($i < 19) {
				if ($i % 6 == 1) {
					$land[$sx][$sy] = $HlandSupply; 
					$landValue[$sx][$sy] = ($i % 12 == 1) ? 3 : 1;
					$landOwner[$sx][$sy] = $id;
				} elseif ($i % 6 == 5) {
					$land[$sx][$sy] = $HlandSupply; 
					$landValue[$sx][$sy] = ($i % 12 == 5) ? 4 : 2;
					$landOwner[$sx][$sy] = $id;
				} else {
	
					$land[$sx][$sy] = $HlandTown; 
					$landValue[$sx][$sy] = 20;
					$landOwner[$sx][$sy] = $id;
				}
			} elseif ($land[$sx][$sy] == $HlandSea) {
				$land[$sx][$sy] = $HlandSea; 
				$landValue[$sx][$sy] = 1;
			}
		}
	}
	$island['land'] = $land;
	$island['landValue'] = $landValue;
	$island['landOwner'] = $landOwner;
	$Hland = $land;
	$HlandValue = $landValue;
	$HlandOwner = $landOwner;
}





/*
 * 함수: changeMain()
 * 역할: 섬 이름/소유자/비밀번호 변경 화면과 저장을 처리합니다.
 * 원본 대응: hako/hako-make.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function changeMain() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	
	$HcurrentNumber = isset($HidToNumber[$HcurrentID]) ? $HidToNumber[$HcurrentID] : 0;
	$island =& $Hislands[$HcurrentNumber];
	$flag = 0;

	
	if (checkSpecialPassword($HoldPassword)) {
		
		if (hako_regex('~^로그 강제 출력$~', $HcurrentName)) {
			
			logPrintHtml();
			unlock();
			tempChange();
			return;
		} elseif (hako_regex('~^무인$~', $HcurrentName)) {
			
			deleteIsland();
			return;
		} else{
			
			$island['money'] = $MaxMoney;
			$island['food'] = $MaxFood;
		}
	} elseif (!checkPassword($island['password'],$HoldPassword)) {
		
		unlock();
		tempWrongPassword();
		return;
	}

	
	if ($HinputPassword2 != $HinputPassword) {
		
		unlock();
		tempWrongPassword();
		return;
	}

	if ($HcurrentName != '') {
		
		
		if (hako_regex('~[\\,\?\(\)\<\>\$]|^무인$|^[ 　]+$~', $HcurrentName)) {
			
			unlock();
			tempNewIslandBadName();
			return;
		}

		
		if (nameToNumber($HcurrentName) != -1) {
			
			unlock();
			tempNewIslandAlready();
			return;
		}

		if ($island['money'] < $HcostChangeName) {
			
			unlock();
			tempChangeNoMoney();
			return;
		}

		
		if (!checkSpecialPassword($HoldPassword)) {
			$island['money'] -= $HcostChangeName;
		}

		
		$__afname = isset($Haftername[$HcurrentAFNameId]) ? $Haftername[$HcurrentAFNameId] : '';
	logChangeName($island['name'], $HcurrentName . $__afname);
		$island['name'] = $HcurrentName;
		$flag = 1;
	}
	
	unset($r); $r = hako_rindex($island['name'],$Haftername[$island['afnameId']]);
	if ($r > 0) { $island['name'] = substr($island['name'],0,$r); }
	$island['afnameId'] = $HcurrentAFNameId;

	if ($HcurrentOwnerName != '') {
		
		$island['ownername'] = htmlEscape($HcurrentOwnerName);
		$flag = 1;
	}

	
	if ($HinputPassword != '') {
		
		$island['password'] = encode($HinputPassword);
		$flag = 1;
	}

	
	writeIslandsFile($HcurrentID);
	unlock();

	
	tempChange();
}


/*
 * 함수: deleteIsland()
 * 역할: 섬 삭제 처리를 수행합니다. 삭제 로그와 파일 처리가 연결됩니다.
 * 원본 대응: hako/hako-make.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function deleteIsland() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	unset($mode); $mode = isset($_args[0]) ? $_args[0] : null;
	$island =& $Hislands[$HidToNumber[$HcurrentID]];

	
	$island['pop'] = -100;
	$island['dead'] = 1;
	$HislandNFlg = 0;

	
	unset($x); $x = null;
	unset($y); $y = null;
	for ($y = 0; $y < $HislandSize; $y++) {
		for ($x = 0; $x < $HislandSize; $x++) {
			if ($HcurrentID == $HlandOwner[$x][$y]) {
				
				$Hland[$x][$y] = $HlandSea;
				$HlandValue[$x][$y] = 0;
				$HlandOwner[$x][$y] = 0;
				continue;
			}
			if (($Hland[$x][$y] == $HlandSea) && ($HlandValue[$x][$y] == 0)) {
				
				$HlandOwner[$x][$y] = 0;
				continue;
			}
		}
	}

	
	unset($flag); $flag = null;
	unset($i); $i = null;
	unset($tmp); $tmp = null;
	unset($idx); $idx = hako_sort_indices_desc_path($Hislands, array('pop'));
	$Hislands = hako_permute($Hislands, $idx);
	if ($mode == 1) {
		logHistory("{$HtagName_}{$island['name']}{$H_tagName}는, 코멘트 미입력을 위해 삭제했습니다. ");
	} else{
		logHistory("{$HtagName_}{$island['name']}{$H_tagName}에, 돌연<B>천벌이 내리고</B>순식간에<B><FONT COLOR=\"ff0000\">바다에 침몰해</FONT></B>흔적도 없어졌습니다. ");
	}
	
	$HislandNumber--;
	writeIslandsFile($HcurrentID);

	@unlink("{$HdirName}/island.{$HcurrentID}");

	unlock();
	if ($mode != 1) { tempDeleteIsland($island['name']); }
}


/*
 * 함수: estimateM()
 * 역할: 관리/생성 흐름에서 섬 평가값을 계산합니다.
 * 원본 대응: hako/hako-make.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function estimateM() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	$number = isset($_args[0]) ? $_args[0] : null;
	$_list_tmp = array(0, 0, 0, 0, 0, 0);
	unset($pop); $pop = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
	unset($area); $area = isset($_list_tmp[1]) ? $_list_tmp[1] : null;
	unset($farm); $farm = isset($_list_tmp[2]) ? $_list_tmp[2] : null;
	unset($factory); $factory = isset($_list_tmp[3]) ? $_list_tmp[3] : null;
	unset($mountain); $mountain = isset($_list_tmp[4]) ? $_list_tmp[4] : null;

	
	$island =& $Hislands[$number];
	$id = $island['id'];

	
	unset($x); $x = null;
	unset($y); $y = null;
	unset($kind); $kind = null;
	unset($value); $value = null;
	unset($owner); $owner = null;
	for ($y = 0; $y < $HislandSize; $y++) {
	for ($x = 0; $x < $HislandSize; $x++) {
		$kind = $Hland[$x][$y];
		$value = $HlandValue[$x][$y];
		$owner = $HlandOwner[$x][$y];
		$HlandResist[$x][$y] = 10;
		if ($kind == $HlandSea && $value == 0) {
			
			$HlandOwner[$x][$y] = 0;
		}
		if ($owner != $id) { continue; }

		if (($kind != $HlandSea) &&
			($kind != $HlandSbase)) {
			$area++;
			if ($kind == $HlandTown) {
				
				$pop += $value;
			} elseif ($kind == $HlandFarm) {
				
				$farm += $value;
			} elseif ($kind == $HlandFactory) {
				
				$factory += $value;
			} elseif ($kind == $HlandMountain) {
				
				$mountain += $value;
			}
		}
	}
	}

	
	$island['pop']      = $pop;
	$island['area']     = $area;
	$island['farm']     = $farm;
	$island['factory']  = $factory;
	$island['mountain'] = $mountain;
}


/*
 * 함수: countAroundValue()
 * 역할: 주변 지형 값을 기준으로 개수를 계산합니다.
 * 원본 대응: hako/hako-make.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function countAroundValue() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	unset($x); $x = isset($_args[0]) ? $_args[0] : null;
	unset($y); $y = isset($_args[1]) ? $_args[1] : null;
	unset($kind); $kind = isset($_args[2]) ? $_args[2] : null;
	unset($value); $value = isset($_args[3]) ? $_args[3] : null;
	unset($range); $range = isset($_args[4]) ? $_args[4] : null;
	unset($i); $i = null;
	unset($count); $count = null;
	unset($sx); $sx = null;
	unset($sy); $sy = null;
	$count = 0;
	for ($i = 0; $i < $range; $i++) {
		$sx = $x + $ax[$i];
		$sy = $y + $ay[$i];
		
		if (!($sy % 2) && ($y % 2)) { $sx--; }
		if ($Hroundmode) {
			$sx = $correct[$sx + 12];
			$sy = $correct[$sy + 12];
		}
		if (($sx < 0) || ($sx >= $HislandSize) || ($sy < 0) || ($sy >= $HislandSize)) {
			

			if ($kind == $HlandSea) { $count++; }
		} else {
			

			if ($Hland[$sx][$sy] == $kind) { $count++; }
		}
	}
	return $count;
}




/*
 * 함수: preDeleteMain()
 * 역할: 관리자 삭제 보관 화면의 진입부입니다.
 * 원본 대응: hako/hako-make.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function preDeleteMain() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	if (checkPassword($HmasterPassword, $HdefaultPassword)) {
		if ($HpreDeleteMode) { preDeleteMainP(); }
		unlock();
		
		tempPdeleteMain();
	} else {
		
		require_once 'hako-top.php';
		unlock();
		
		tempTopPage();
	}
}

/*
 * 함수: preDeleteMainP()
 * 역할: 관리자 삭제 보관 실행부입니다.
 * 원본 대응: hako/hako-make.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function preDeleteMainP() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	unset($newID); $newID = array();
	unset($flag); $flag = 0;
	foreach ($HpreDeleteID as $_) {
		if (!(isset($HidToNumber[$_]))) {
		} elseif ($_ == $HcurrentID) {
			$flag = 1;
		} else {
			hako_push($newID, $_);
		}
	}
	$HpreDeleteID = $newID;
	if (!$flag) { hako_push($HpreDeleteID, $HcurrentID); }
	writeIslandsFile($HcurrentID);
	unset($name); $name = $Hislands[$HidToNumber[$HcurrentID]]['name'];
	if ($flag) {
		out("{$HtagBig_}{$name}의 관리인 보관 을 헤제했습니다{$H_tagBig}");
	} else {
		out("{$HtagBig_}{$name}를 관리인 보관으로 했습니다.{$H_tagBig}");
	}
}

/*
 * 함수: tempPdeleteMain()
 * 역할: 삭제 보관 화면 템플릿입니다.
 * 원본 대응: hako/hako-make.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function tempPdeleteMain() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	out(<<<HAKOHDOC_0
<CENTER>$HtempBack</CENTER>
<H1>참가국을 관리인 보관으로 한다</H1>

<DL>
<DT>·예 마낀 나라는 일절의 명령 처리를 할 수 없는 대신에 재해도 일어나지 않습니다. (타국으로부터 괴수가 침입하는 것은 있다) </DT>
<DT>·인구나 숲의 갯수도 증가하지 않습니다. 식량은 전혀 소비합니다만, 수입도 없습니다.  </DT>
<DT>·타국은 전부 우호국의 취급이 됩니다. (전쟁중에서 만나도) </DT>
</DL>

<FORM name="pdForm" action="$HthisFile" method="POST">
<INPUT TYPE="hidden" VALUE="{$HdefaultPasswordEsc}" NAME="Pdelete">
<B>관리인 보관으로 하는 나라는?</B><BR>
<SELECT NAME="ISLANDID">
$HislandList
</SELECT>
<BR>
<INPUT TYPE="submit" VALUE="설정·해제" NAME="PdeleteButton"><BR>
</FORM>
<TABLE BORDER><TR><TH>보관 중인 나라</TH></TR>
HAKOHDOC_0
);
	if ($HpreDeleteID[0] == '') {
		out("<TR><TH>관리인에게 보관중인 나라는 없습니다.</TH></TR>");
	} else {
		unset($name); $name = null;
		foreach ($HpreDeleteID as $_) {
		if (!(isset($HidToNumber[$_]))) {
			$name = $Hislands[$HidToNumber[$_]]['name'];
			out("<TR><TD>$name</TD></TR>");
		}
	}
	}
	out("</TABLE>");
}



/*
 * 함수: ichangeMain()
 * 역할: 관리자 섬 정보/외교 관계 변경 화면 진입부입니다.
 * 원본 대응: hako/hako-make.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function ichangeMain() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	unset($mode); $mode = isset($_args[0]) ? $_args[0] : null;
	if (checkPassword($HmasterPassword, $HdefaultPassword)) {
		if ($HichangeMode) { ichangeMainP($mode); }
		unlock();
		tempIchangePage($mode);
	} else {
		
		require_once 'hako-top.php';
		unlock();
		
		tempTopPage();
	}
}

/*
 * 함수: ichangeMainP()
 * 역할: 관리자 섬 정보/외교 관계 변경 실행부입니다.
 * 원본 대응: hako/hako-make.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function ichangeMainP() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	unset($mode); $mode = isset($_args[0]) ? $_args[0] : null;
	if ($mode) {
		unset($i); $i = $Hawc0;
		unset($amitywar); $amitywar = null;
		if ($HawcM) {
			
			$amitywar =& $HwarIsland;
		} else{
			
			$amitywar =& $HamityIsland;
		}
		if ($Hawc4 == 1002) {
			
			hako_splice($amitywar, $i, 4);
		} elseif ($Hawc4 > 999) {
			
			$Hawc4 = ($HawcM) ? 0 : $Hawc4 - 1000;
			hako_push($amitywar,$Hawc1);
			hako_push($amitywar,$Hawc2);
			hako_push($amitywar,$Hawc3);
			hako_push($amitywar,$Hawc4);
		} else{
			$amitywar[$i]   = $Hawc1;
			$amitywar[$i+1] = $Hawc2;
			$amitywar[$i+2] = $Hawc3;
			$amitywar[$i+3] = $Hawc4;
		}
	} else{
		$HcurrentNumber = isset($HidToNumber[$HcurrentID]) ? $HidToNumber[$HcurrentID] : 0;
		$island =& $Hislands[$HcurrentNumber];
		$island['money'] = intval($Hicmoney);
		$island['food'] = intval($Hicfood);
		$island['soldier'] = intval($Hicsoldier);
		$island['ally'] = intval($Hically);
		if ($island['money'] > $MaxMoney) {
			$island['money'] = $MaxMoney;
		}
		if ($island['food'] > $MaxFood) {
			$island['food'] = $MaxFood;
		}
	}
	
	writeIslandsFile($HcurrentID);
	unlock();
}

/*
 * 함수: tempIchangePage()
 * 역할: 섬 정보 변경 화면 템플릿입니다.
 * 원본 대응: hako/hako-make.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function tempIchangePage() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	unset($mode); $mode = isset($_args[0]) ? $_args[0] : null;
	out("<span class='attention'>※　반드시 백업을 해 가 주세요. 데이터를 직접 수정하므로 위험합니다!</span>");
	if ($mode) {
		
		out(<<<HAKOHDOC_1
<br>
통상은, 참가자 자신이 우호 관계를 묶거나 전쟁을 하는 것이어<br>
관리인이 데이터를 강제 변경하는 것은하지 마세요. <br>
<br>현재는,{$HislandTurn}턴입니다. <br>
<b>우호 관계의 리스트</b><br>
HAKOHDOC_1
);
		tempAWchangePage(0,$HamityIsland);
		out("<br><b>전쟁 관계의 리스트</b><br>");
		tempAWchangePage(1,$HwarIsland);
		out(<<<HAKOHDOC_2
※　맨 밑의 항목은, 신규의 추가 항목입니다. <br>
『　1국 마다의 수정 밖에 할 수 없습니다. 데이터의 정합성 체크는 하고 있지 않습니다. 부정한 데이터를 만들지 않게! <br>
『　A≧B와 B≧A의 2살의 우호·전쟁 관계는 구조상 있을 수 없습니다. <br>
※　현재의 턴보다 낡은 우호 기한 턴의 지정도 실시하지 않게. (전쟁의 경우는 OK)<br>
HAKOHDOC_2
);
	} else{
		
		out(<<<HAKOHDOC_3
<TABLE BORDER>
<TR>
<TH $HbgTitleCell>{$HtagTH_}순위{$H_tagTH}</TH>
<TH $HbgTitleCell>{$HtagTH_}국명{$H_tagTH}</TH>
<TH $HbgTitleCell>{$HtagTH_}자금{$H_tagTH}</TH>
<TH $HbgTitleCell>{$HtagTH_}식량{$H_tagTH}</TH>
<TH $HbgTitleCell>{$HtagTH_}예비병{$H_tagTH}</TH>
<TH $HbgTitleCell>{$HtagTH_}소속{$H_tagTH}</TH>
<TH $HbgTitleCell>{$HtagTH_}변경{$H_tagTH}</TH>
</TR>
HAKOHDOC_3
);
	unset($island); $island = null;
	unset($id); $id = null;
	unset($name); $name = null;
	unset($money); $money = null;
	unset($food); $food = null;
	unset($soldier); $soldier = null;
	unset($ally); $ally = null;
	unset($i); $i = null;
	unset($j); $j = null;
	unset($select_list); $select_list = null;
	for ($i = 0; $i < $HislandNumber; $i++) {

		$island =& $Hislands[$i];
		$id = $island['id'];
		$name = $island['name'];
		$money = $island['money'];
		$food = $island['food'];
		$soldier = $island['soldier'];
		$ally = $island['ally'];

		$j = $i + 1;
		$select_list = "";
		for ($_ = 0; $_ <= hako_last_index($Hallygroup); $_++) {
			if ($_ == $ally) {
				$select_list .= "<OPTION value={$_} selected>$Hallygroup[$_]\n";
			} else{
				$select_list .= "<OPTION value={$_}>$Hallygroup[$_]\n";
			}
		}
	out(<<<HAKOHDOC_4
<TR>
<FORM name="IchForm" action="$HthisFile" method="POST">
<INPUT TYPE="hidden" VALUE="{$HdefaultPasswordEsc}" NAME="Ichange">
<INPUT TYPE="hidden" VALUE="$id" NAME="ICID">
<TD $HbgNumberCell>{$HtagNumber_}{$j}{$H_tagNumber}</TD>
<TD $HbgNameCell>{$HtagTH_}{$name}{$H_tagTH}({$id})</TD>
<TD><INPUT TYPE="text" SIZE=5 NAME="ICMONEY" VALUE="$money">$HunitMoney</TD>
<TD><INPUT TYPE="text" SIZE=5 NAME="ICFOOD" VALUE="$food">$HunitFood</TD>
<TD><INPUT TYPE="text" SIZE=4 NAME="ICSOLDIER" VALUE="$soldier">$HunitPop</TD>
<TD><SELECT NAME="ICALLY">$select_list</SELECT><b>$Hallymark[$ally]</b></TD>
<TD><INPUT TYPE="submit" VALUE="변경" NAME="IchangeButton"></TD>
</FORM>
</TR>
HAKOHDOC_4
);
	}
	out(<<<HAKOHDOC_5
</TABLE>
『　1국 마다 수정 밖에 할 수 없습니다.<br>
HAKOHDOC_5
);
	}
}


/*
 * 함수: tempAWchangePage()
 * 역할: 우호/전쟁 관계 변경 화면 템플릿입니다.
 * 원본 대응: hako/hako-make.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function tempAWchangePage() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	unset($mode); $mode = isset($_args[0]) ? $_args[0] : null;
	unset($amitywar); $amitywar = isset($_args[1]) ? $_args[1] : null;
	unset($str1); $str1 = array('우호 기한', '전쟁 개시');
	unset($str2); $str2 = array('까지', '로부터');
	out(<<<HAKOHDOC_6
<TABLE BORDER>
<TR>
<TH $HbgTitleCell>{$HtagTH_}$str1[$mode]턴{$H_tagTH}</TH>
<TH $HbgTitleCell>{$HtagTH_}국명１{$H_tagTH}</TH>
<TH $HbgTitleCell>{$HtagTH_}국명２{$H_tagTH}</TH>
<TH $HbgTitleCell>{$HtagTH_}상태{$H_tagTH}</TH>
<TH $HbgTitleCell>{$HtagTH_}변경{$H_tagTH}</TH>
</TR>
HAKOHDOC_6
);
		for ($i=0;$i < hako_last_index($amitywar);$i+=4) {
			$tn1 = isset($HidToNumber[$amitywar[$i+1]]) ? $HidToNumber[$amitywar[$i+1]] : '';
			if (($tn1 === '' || $tn1 === null)) {
				hako_splice($amitywar, $i, 4);
				continue;
			}
			$tn2 = isset($HidToNumber[$amitywar[$i+2]]) ? $HidToNumber[$amitywar[$i+2]] : '';
			if (($tn2 === '' || $tn2 === null)) {
				hako_splice($amitywar, $i, 4);
				continue;
			}
			unset($islandList1); $islandList1 = getIslandList($amitywar[$i+1]);
			unset($islandList2); $islandList2 = getIslandList($amitywar[$i+2]);
			unset($awvalue); $awvalue = null;
			if ($mode) {
				
				unset($str3); $str3 = array('통상', '1≧2 정전', '2≧1 정전');
				$awvalue = "<SELECT NAME=\"AWVALUE\">";
				for ($_ = 0; $_ <= 2; $_++) {
					if ($_ == $amitywar[$i+3]) {
						$awvalue .= "<OPTION value={$_} selected>$str3[$_]\n";
					} else{
						$awvalue .= "<OPTION value={$_}>$str3[$_]\n";
					}
				}
			} else{
				
				if ($amitywar[$i+3] == 3) {
					$awvalue = "<SELECT NAME=\"AWVALUE\"><OPTION VALUE=\"0\">타진중<OPTION VALUE=\"3\" SELECTED>성립";
				} else{
					$awvalue = "<SELECT NAME=\"AWVALUE\"><OPTION VALUE=\"0\" SELECTED>타진중<OPTION VALUE=\"3\">성립";
				}
			}
			$awvalue .= "<OPTION VALUE=\"1002\">삭제</SELECT>";
		out(<<<HAKOHDOC_7
<TR>
<FORM name="AWchForm1" action="$HthisFile" method="POST">
<INPUT TYPE="hidden" VALUE="{$HdefaultPasswordEsc}" NAME="AWchange">
<INPUT TYPE="hidden" VALUE="$mode" NAME="AWMODE">
<INPUT TYPE="hidden" VALUE="$i" NAME="AWAMITY">
<TD><INPUT TYPE="text" SIZE=3 NAME="AWCTURN" VALUE="$amitywar[$i]">턴 $str2[$mode]</TD>
<TD><SELECT NAME="ISLANDID1">
$islandList1</SELECT></TD>
<TD><SELECT NAME="ISLANDID2">
$islandList2</SELECT></TD>
<TD>$awvalue</TD>
<TD><INPUT TYPE="submit" VALUE="변경" NAME="AWchangeButton"></TD>
</FORM>
</TR>
HAKOHDOC_7
);
		}
		$islandList1 = getIslandList();
		$islandList2 = getIslandList();
		if ($mode) {
			
			$awvalue = "<SELECT NAME=\"AWVALUE\"><OPTION VALUE=\"0\">전쟁 개시</SELECT>";
		} else{
			$awvalue = "<SELECT NAME=\"AWVALUE\"><OPTION VALUE=\"1000\">타진중<OPTION VALUE=\"1003\" SELECTED>성립</SELECT>";
		}
		out(<<<HAKOHDOC_8
<TR>
<FORM name="AWchForm2" action="$HthisFile" method="POST">
<INPUT TYPE="hidden" VALUE="{$HdefaultPasswordEsc}" NAME="AWchange">
<INPUT TYPE="hidden" VALUE="$mode" NAME="AWMODE">
<INPUT TYPE="hidden" VALUE="$i" NAME="AWAMITY">
<TD><INPUT TYPE="text" SIZE=3 NAME="AWCTURN" VALUE="0">턴$str2[$mode]</TD>
<TD><SELECT NAME="ISLANDID1">
$islandList1</SELECT></TD>
<TD><SELECT NAME="ISLANDID2">
$islandList2</SELECT></TD>
<TD>$awvalue</TD>
<TD><INPUT TYPE="submit" VALUE="추가" NAME="AWchangeButton"></TD>
</FORM>
</TR>
</TABLE>
HAKOHDOC_8
);
}



/*
 * 함수: lchangeMain()
 * 역할: 관리자 지형 변경 화면 진입부입니다.
 * 원본 대응: hako/hako-make.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function lchangeMain() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	if (checkPassword($HmasterPassword, $HdefaultPassword)) {
		
		$HcurrentNumber = isset($HidToNumber[$HcurrentID]) ? $HidToNumber[$HcurrentID] : 0;
		$island =& $Hislands[$HcurrentNumber];
		if ($HlchangeMode) {

			
			if (!landCheck($HlchangeKIND, $HlchangeVALUE)) {
				out("{$HtagBig_}지형의 값이 이상한 것 같습니다{$H_tagBig}$HtempBack");
				unlock();
				return;
			}

			$Hland[$HcommandX][$HcommandY] = $HlchangeKIND;
			$HlandValue[$HcommandX][$HcommandY] = $HlchangeVALUE;
			$HlandOwner[$HcommandX][$HcommandY] = $HlchangeOWNER;

			if ($HlchangeHGR != 999) {
				
				if ($HlchangeDIVPW > 250) { $HlchangeDIVPW = 250; }
				if ($HlchangeDIVEX > 200) { $HlchangeDIVEX = 200; }

				$HlandHGr[$HcommandX][$HcommandY] = $HlchangeHGR;
				$HlandDiv[$HcommandX][$HcommandY] = $HlchangeDIV;
				$HlandDivPw[$HcommandX][$HcommandY] = $HlchangeDIVPW;
				$HlandDivEx[$HcommandX][$HcommandY] = $HlchangeDIVEX;
				$HlandDivNa[$HcommandX][$HcommandY] = $HlchangeDIVNA;
				$HlandDivItem[$HcommandX][$HcommandY] = $HlchangeDIVITEM;
			}

			
			writeIslandsFile($HcurrentID);
			unlock();
			
			out("{$HtagBig_}지형을 변경했던{$H_tagBig}<HR>");
		}
		unlock();
		
		tempLchangePage();
	} else {
		
		unlock();
		require_once 'hako-top.php';
		
		tempTopPage();
	}
}


/*
 * 함수: tempLchangePage()
 * 역할: 지형 변경 화면 템플릿입니다.
 * 원본 대응: hako/hako-make.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function tempLchangePage() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	out(<<<HAKOHDOC_9
$HtempBack<hr>
<H1>지형 데이터를 변경한다</H1>
<b>정상적으로 동작하지 않게 될 우려</b>가 있습니다. 운용중의 데이터는 개서는 삼가합시다! <BR>
<b>반드시 모형정원 데이터의 백업을 사전에 실시하는 것! </b>하등의 문제가 발생해도 대응이나 책임은 일절 취할 수 있습니다. <BR>
<TABLE><TR><TD>
HAKOHDOC_9
);
	islandMap(1);
	$HtargetList = getIslandList($HcurrentID);
	out(<<<HAKOHDOC_10
</TD><TD valign=top>
<FORM name="lcForm" action="$HthisFile" method="POST">
<INPUT TYPE="hidden" VALUE="{$HdefaultPasswordEsc}" NAME="Lchange">
<B>지형을 변경하는{$AfterName}</B>(ID=$HcurrentID)<BR>
<SELECT NAME="ISLANDID">
$HtargetList
</SELECT><BR>
<INPUT TYPE="submit" VALUE="맵을 연다" NAME="LchangeButtonM"><BR>
<BR>
<B>좌표는? </B><BR>
<B>(</B><SELECT NAME=POINTX>
HAKOHDOC_10
);
	unset($i); $i = null;
	for ($i = 0; $i < $HislandSize; $i++) {
		if ($i == $HdefaultX) {
			out("<OPTION VALUE=$i SELECTED>$i\n");
		} else {
			out("<OPTION VALUE=$i>$i\n");
		}
	}
	out(<<<HAKOHDOC_11
</SELECT><B>, </B><SELECT NAME=POINTY>
HAKOHDOC_11
);
	for ($i = 0; $i < $HislandSize; $i++) {
		if ($i == $HdefaultY) {
			out("<OPTION VALUE=$i SELECTED>$i\n");
		} else {
			out("<OPTION VALUE=$i>$i\n");
		}
	}
	out("</SELECT><B>)</B><BR><B>지형은?</B><BR><SELECT NAME=\"LCHANGEKIND\">");
	$lcland = array("바다","황무지","평지","마을계","숲","농장","공장","미사일 기지","방위 시설","산","괴수","해저 기지","병참기지","기념비");
		$lclandId = array($HlandSea,$HlandWaste,$HlandPlains,$HlandTown,$HlandForest,$HlandFarm,$HlandFactory,$HlandBase,$HlandDefence,$HlandMountain,
					$HlandMonster,$HlandSbase,$HlandSupply,$HlandMonument);
	for ($i = 0; $i <= hako_last_index($lcland); $i++) {
		if ($lclandId[$i] == $HlchangeKIND) {
			out("<OPTION VALUE=$lclandId[$i] SELECTED>$lcland[$i]\n");
		} else {
			out("<OPTION VALUE=$lclandId[$i]>$lcland[$i]\n");
		}
	}
	if ($HlchangeVALUE == '') { $HlchangeVALUE = 0; }
	if ($HlchangeDIVPW == '') { $HlchangeDIVPW = 0; }
	if ($HlchangeDIVLV == '') { $HlchangeDIVLV = 0; }
	if ($HlchangeDIVEX == '') { $HlchangeDIVEX = 0; }
	out(<<<HAKOHDOC_12
</SELECT><BR>
<B>지형의 값은?</B><BR>
<INPUT TYPE="text" SIZE=4 NAME="LCHANGEVALUE" VALUE="$HlchangeVALUE">(통상0-200)
<BR>
<B>지형의 소속국은?</B><BR>
<SELECT NAME="LCHANGEOWNER">
$HtargetList
</SELECT>
<BR><BR>

<B>부대 정보도 변경해?</B><BR>
<SELECT NAME="LCHANGEHGR">
<OPTION VALUE=999>부대는 변경하지 않는다
HAKOHDOC_12
);
	$HcurrentNumber = isset($HidToNumber[$HcurrentID]) ? $HidToNumber[$HcurrentID] : 0;
	$island =& $Hislands[$HcurrentNumber];
	unset($ofname); $ofname = $island['fleet'];
	for ($_ = 1; $_ <= $Hfleet; $_++) {
		out("<OPTION VALUE=$_>" . $ofname[$_ - 1] . "\n");
	}
	out("</SELECT><BR><B>부대의 병종은?</B><BR><SELECT NAME=\"LCHANGEDIV\">");
	for ($_ = 0; $_ <= hako_last_index($Fdivision); $_++) {
		if ($_ == $HlchangeDIV) {
			out("<OPTION VALUE=$_ SELECTED>$Fdivision[$_]\n");
		} else {
			out("<OPTION VALUE=$_>$Fdivision[$_]\n");
		}
	}
	out("</SELECT>\n");
	out(<<<HAKOHDOC_13
<BR>
<B>부대의 유무(병력)는?</B><BR>
<INPUT TYPE="text" SIZE=3 NAME="LCHANGEDIVPW" VALUE="$HlchangeDIVPW"><BR>
(0은 부대 없음, 최대 250)
<BR>
<B>부대의 레벨은? </B><BR>
<INPUT TYPE="text" SIZE=3 NAME="LCHANGEDIVLV" VALUE="$HlchangeDIVLV">(0-15) 0=Lv1
<BR>
<B>부대의 경험치는? </B><BR>
<INPUT TYPE="text" SIZE=3 NAME="LCHANGEDIVEX" VALUE="$HlchangeDIVEX">(0-99)
<BR>
<B>부대의 소속국은?</B><BR>
<SELECT NAME="LCHANGEDIVNA">
$HtargetList
</SELECT>
<BR>
<B>부대의 아이템은? </B><BR>
<SELECT NAME="LCHANGEDIVITEM">
HAKOHDOC_13
);
	for ($_ = 0; $_ <= hako_last_index($FItemName); $_++) {
		if ($FSItemID[$_] != 2) {
			if ($_ == $HlchangeDIVITEM) {
				out("<OPTION VALUE=$_ SELECTED>$FItemName[$_]\n");
			} else {
				out("<OPTION VALUE=$_>$FItemName[$_]\n");
			}
		}
	}
	out(<<<HAKOHDOC_14
</SELECT>
<BR>
<INPUT TYPE="submit" VALUE="변경한다" NAME="LchangeButton"><BR>
</FORM>
</TD></TR></TABLE>
「지형」에 대해서 「지형의 값」이 적절한지 어떤지를 체크(부실)를 하고 있기 때문에, 주의해 주세요. <BR>
통상은, 부대에 대해서 변경하지 않게 되어 있습니다. 변경할 때는, 「부대 정보도 변경해?々(으)로 군단명을 선택해 주세요. <BR>
그 때에, 병력을 0으로 하면 부대가 사라집니다. <BR>
<SCRIPT Language="JavaScript">
<!--
function ps(x, y) {
	document.lcForm.POINTX.options[x].selected = true;
	document.lcForm.POINTY.options[y].selected = true;
	return true;
}
//-->
</SCRIPT>
HAKOHDOC_14
);
}


/*
 * 함수: landCheck()
 * 역할: 지형 변경값의 허용 여부를 검사합니다.
 * 원본 대응: hako/hako-make.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function landCheck() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	unset($land); $land = isset($_args[0]) ? $_args[0] : null;
	unset($lv); $lv = isset($_args[1]) ? $_args[1] : null;
	if ($lv < 0) { return 0; }
	if ($land == $HlandSea) {
		if ($lv > 1) { $lv = 0; }
	} elseif ($land == $HlandWaste) {
		if ($lv > 1) { $lv = 0; }
	} elseif ($land == $HlandPlains) {
		$lv = 0;
	} elseif ($land == $HlandTown) {
		if (($lv < 1) || ($lv > 200)) { return 0; }
	} elseif ($land == $HlandForest) {
		if (($lv < 1) || ($lv > 200)) { return 0; }
	} elseif ($land == $HlandFarm) {
		if (($lv < 10) || ($lv > 60)) { return 0; }
	} elseif ($land == $HlandFactory) {
		if (($lv < 30) || ($lv > 120)) { return 0; }
	} elseif ($land == $HlandBase) {
		if (($lv < 0) || ($lv > $HmaxExpPoint)) { return 0; }
	} elseif ($land == $HlandDefence) {
		if ($lv > 2) { return 0; }
	} elseif ($land == $HlandMountain) {
		if (($lv < 0) || ($lv > 240)) { return 0; }
	} elseif ($land == $HlandMonster) {
		if ($lv > 3199) { return 0; }
	} elseif ($land == $HlandSbase) {
		if (($lv < 0) || ($lv > $HmaxExpPoint)) { return 0; }
	} elseif ($land == $HlandSupply) {
		if (($lv < 1) || ($lv > $Hfleet)) { $lv = 1; }
	} elseif ($land == $HlandMonument) {
		if ($lv >= $HmonumentNumber) { $lv = 0; }
	} else {
		if ($lv > 200) { return 0; }
	}
	return 1;
}





/*
 * 함수: mapeditorMain()
 * 역할: 맵 에디터 연계 화면 진입부입니다.
 * 원본 대응: hako/hako-make.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function mapeditorMain() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	if (!$HmapeditorMode) {
		
		unlock();
		
		tempMapmaker();
	} else {
		unset($mode); $mode = null;
		unset($mapdata); $mapdata = null;
		$HcurrentNumber = isset($HidToNumber[$HcurrentID]) ? $HidToNumber[$HcurrentID] : 0;
		$island =& $Hislands[$HcurrentNumber];
		
		if (!checkPassword($island['password'], $HoldPassword)) {
			
			if ($HoldPassword != '') {
				
				unlock();
				tempWrongPassword();
				return;
			} else{
				
				unlock();
				tempMapmaker();
				$mapdata = hakoToEditor(0,$island);
				$mode = 0;
			}
		} else{
			
			unlock();
			tempMapmaker();
			$mapdata = hakoToEditor(1,$island);
			$mode = 1;
		}
		out(<<<HAKOHDOC_15
<h2>아래와 같이 맵을 맵 에디터로 설정해 기동한다</h2>
<FORM action="$HeditorN" method="GET">
<INPUT TYPE="submit" VALUE="맵 에디터를 기동" ID="mapeditordata"><BR>
<INPUT TYPE="hidden" VALUE="$mapdata" NAME="mapeditor">
</FORM>
HAKOHDOC_15
);
	tempNavi();
	islandMap($mode);
	out("<center>※　개발 모드의 경우는, 부대도 표시됩니다만 맵 에디터에서는 대응하고 있지 않습니다.</center>");
	}
}


/*
 * 함수: tempMapmaker()
 * 역할: 맵 에디터 출력 HTML 템플릿입니다.
 * 원본 대응: hako/hako-make.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function tempMapmaker() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	unset($mIslandList); $mIslandList = getIslandList($HcurrentID);
	out(<<<HAKOHDOC_16
{$HtempBack}　　{$HtagBig_}{$H_tagBig}
<hr>
맵 에디터는, 주로 장래의 계획을 생각하는 것입니다. 맵을 편집해도 무언가에 사용할 수 있는 것은 아닙니다. <br>
※　방벽(기념비)의 종류에 의한 화상 차이 등 일부의 지형 화상에는 대응하고 있지 않습니다. <br>
※　부대 표시에도 대응하고 있지 않습니다.
<hr>
<h2>맵 에디터용의 맵 데이터를 작성한다</h2>
패스워드가 입력되고 있으면(자) 개발 모드로 데이터를 작성합니다. <br>
패스워드가 하늘때는, 관광 모드로 데이터를 작성합니다.<br><br>
<FORM action="$HthisFile" method="POST">
맵 에디터용 데이터를 작성하는 나라는?<BR>
<SELECT NAME="ISLANDID">$mIslandList</SELECT><BR>
패스워드는? <BR>
<INPUT TYPE="password" NAME="OLDPASS" SIZE=32 MAXLENGTH=32>
<INPUT TYPE="submit" VALUE="맵 에디터용 데이터 작성" NAME="MapEditor"><BR>
</FORM>
HAKOHDOC_16
);
}

/*
 * 함수: hakoToEditor()
 * 역할: 현재 섬 데이터를 에디터 입력 형식으로 변환합니다.
 * 원본 대응: hako/hako-make.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function hakoToEditor() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	unset($mode); $mode = isset($_args[0]) ? $_args[0] : null;
	unset($island); $island = isset($_args[1]) ? $_args[1] : null;
	$name = $island['name'];
	$id = $island['id'];
	$land = $island['land'];
	$landValue = $island['landValue'];
	unset($i); $i = null;
	unset($x); $x = null;
	unset($y); $y = null;
	unset($str); $str = null;

	for ($y = 0; $y < $HislandSize; $y++) {
		for ($x = 0; $x < $HislandSize; $x++) {
			$_list_tmp = array($Hland[$x][$y],$HlandValue[$x][$y],$HlandOwner[$x][$y]);
			unset($l); $l = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
			unset($lv); $lv = isset($_list_tmp[1]) ? $_list_tmp[1] : null;
			unset($ow); $ow = isset($_list_tmp[2]) ? $_list_tmp[2] : null;
			if ($mode == 1 && $id == $ow) {
				
				$ow = 1;
			} else{
				$ow = 0;
			}
			if ($l == $HlandSea) {
				if ($lv > 0) {
					$l = 14;
				} else{
					$l = 0;
				}
			} elseif ($l == $HlandWaste) {
				if ($lv > 0) {
					$l = 13;
				} else{
					$l = 1;
				}
			} elseif ($l == $HlandPlains) {
				$l = 2;
			} elseif ($l == $HlandTown) {
				if ($lv < 30) {
					$l = 3;
				} elseif ($lv < 100) {
					$l = 4;
				} else{
					$l = 5;
				}
			} elseif ($l == $HlandForest) {
				$l = 6;
			} elseif ($l == $HlandFarm) {
				$l = 7;
			} elseif ($l == $HlandFactory) {
				$l = 8;
			} elseif ($l == $HlandBase) {
				if ($ow == 0) {
					$l = 6;
				} else{
					$l = 9;
				}
			} elseif ($l == $HlandDefence) {
				if ($ow == 0) {
					$l = 6;
				} else{
					$l = 10;
				}
			} elseif ($l == $HlandMountain) {
				if ($lv == 0) {
					$l = 11;
				} else{
					$l = 15;
				}
			} elseif ($l == $HlandSbase) {
				if ($ow == 0) {
					$l = 0;
				} else{
					$l = 12;
				}
			} elseif ($l == $HlandSupply) {
				if ($ow == 0) {
					$l = 6;
				} else{
					$l = 17;
				}
			} elseif ($l == $HlandMonument) {
				$l = 16;
			} elseif ($l == $HlandMonster) {
					$_monsterSpec = monsterSpec($lv);
					$mId = isset($_monsterSpec[0]) ? $_monsterSpec[0] : null;
					$special = isset($HmonsterSpecial[$mId]) ? $HmonsterSpecial[$mId] : null;
					if ((($special == 3) && (($HislandTurn % 2) == 1)) ||
						(($special == 4) && (($HislandTurn % 2) == 0))) {
					
					if ($mId == 0) {
						$l = 25;
					} else{
						$l = 26;
					}
				} else{
					if ($mId == 0) {
						$l = 27;
					} else{
						$l = $mId + 17;
					}
				}
			} else{
				$l = 0;
			}
			if ($id == $HlandOwner[$x][$y]) {
				
				$l += 100;
			}
			$str .= "$l\Z";
		}
	
	}
	return $str;
}





/*
 * 함수: logHistory()
 * 역할: 과거 사건 로그를 기록합니다.
 * 원본 대응: hako/hako-make.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logHistory() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	hako_open('HOUT', ">>{$HdirName}/hakojima.his");
	$msg = isset($_args[0]) ? $_args[0] : null;
	hako_write('HOUT', "$HislandTurn,$msg\n");
	hako_close('HOUT');
}


/*
 * 함수: logDiscover()
 * 역할: 새 섬 발견/등록 로그를 기록합니다.
 * 원본 대응: hako/hako-make.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logDiscover() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	unset($name); $name = isset($_args[0]) ? $_args[0] : null;
	logHistory("{$HtagName_}{$name}{$H_tagName}가 발견된다.$addr");
}


/*
 * 함수: logChangeName()
 * 역할: 섬 이름 변경 로그를 기록합니다.
 * 원본 대응: hako/hako-make.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logChangeName() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	unset($name1); $name1 = isset($_args[0]) ? $_args[0] : null;
	unset($name2); $name2 = isset($_args[1]) ? $_args[1] : null;
	logHistory("{$HtagName_}{$name1}{$H_tagName}, 명칭을{$HtagName_}{$name2}{$H_tagName}로 변경한다.$addr");
}


/*
 * 함수: tempDeleteIsland()
 * 역할: 섬 삭제 완료 화면 템플릿입니다.
 * 원본 대응: hako/hako-make.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function tempDeleteIsland() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	unset($name); $name = isset($_args[0]) ? $_args[0] : null;
	out(<<<HAKOHDOC_17
{$HtagBig_}{$name}(을)를 강제 삭제했습니다. {$H_tagBig}$HtempBack
HAKOHDOC_17
);
}


/*
 * 함수: tempNewIslandFull()
 * 역할: 최대 섬 수 초과 안내 화면입니다.
 * 원본 대응: hako/hako-make.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function tempNewIslandFull() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	out(<<<HAKOHDOC_18
{$HtagBig_}죄송합니다, 가득해 등록할 수 없습니다! {$H_tagBig}$HtempBack
HAKOHDOC_18
);
}


/*
 * 함수: tempNewIslandNoName()
 * 역할: 신규 섬 이름 누락 안내 화면입니다.
 * 원본 대응: hako/hako-make.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function tempNewIslandNoName() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	out(<<<HAKOHDOC_19
{$HtagBig_}나라에 붙이는 이름이 필요합니다. {$H_tagBig}$HtempBack
HAKOHDOC_19
);
}


/*
 * 함수: tempNewIslandBadName()
 * 역할: 신규 섬 이름 부정 안내 화면입니다.
 * 원본 대응: hako/hako-make.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function tempNewIslandBadName() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	out(<<<HAKOHDOC_20
{$HtagBig_}',?()<>\"\'\$'라든지 들어가기도 하고, 「무인」이나 공백만의 이상한 이름은 그만둡시다∼{$H_tagBig}$HtempBack
HAKOHDOC_20
);
}


/*
 * 함수: tempNewIslandAlready()
 * 역할: 이미 존재하는 섬 이름 안내 화면입니다.
 * 원본 대응: hako/hako-make.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function tempNewIslandAlready() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	out(<<<HAKOHDOC_21
{$HtagBig_}그 나라라면 벌써 발견되고 있습니다.{$H_tagBig}$HtempBack
HAKOHDOC_21
);
}


/*
 * 함수: tempNewIslandNoOwner()
 * 역할: 소유자명 누락 안내 화면입니다.
 * 원본 대응: hako/hako-make.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function tempNewIslandNoOwner() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	out(<<<HAKOHDOC_22
{$HtagBig_}나라에 붙이는 오너명이 필요합니다.{$H_tagBig}$HtempBack
HAKOHDOC_22
);
}


/*
 * 함수: tempNewSeaEmpty()
 * 역할: 신규 섬 생성 가능한 바다가 없을 때의 화면입니다.
 * 원본 대응: hako/hako-make.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function tempNewSeaEmpty() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	out(<<<HAKOHDOC_23
{$HtagBig_}나라를 만들 수가 있는 바다가 없습니다. {$H_tagBig}$HtempBack
HAKOHDOC_23
);
}


/*
 * 함수: tempNewIslandNoPassword()
 * 역할: 비밀번호 누락 안내 화면입니다.
 * 원본 대응: hako/hako-make.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function tempNewIslandNoPassword() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	out(<<<HAKOHDOC_24
{$HtagBig_}패스워드가 필요합니다.{$H_tagBig}$HtempBack
HAKOHDOC_24
);
}


/*
 * 함수: tempNewIslandHead()
 * 역할: 신규 섬 생성 완료 화면 상단입니다.
 * 원본 대응: hako/hako-make.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function tempNewIslandHead() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	unset($name); $name = isset($_args[0]) ? $_args[0] : null;
	unset($point); $point = isset($_args[1]) ? $_args[1] : null;
	out(<<<HAKOHDOC_25
<SCRIPT Language="JavaScript">
<!--
function ps(x) {
	return true;
}
//-->
</SCRIPT>
<CENTER>
{$HtagBig_}{$point}로 나라를 발견했습니다!{$H_tagBig}<BR>
{$HtagBig_}{$HtagName_}[{$name}]{$H_tagName}라고 명명합니다.{$H_tagBig}<BR>
<BR>
탑 화면으로 돌아간 후, 반드시 자신의 나라에 들어가<b>코멘트를 기입해 주세요. </b><br>
일정기간, 입력이 없는 경우, 발견한 나라가<b>자동으로 삭제됩니다.</b><br>
<BR>
$HtempBack<BR>
</CENTER>
HAKOHDOC_25
);
}


/*
 * 함수: tempChangeNothing()
 * 역할: 변경 내용 없음 안내 화면입니다.
 * 원본 대응: hako/hako-make.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function tempChangeNothing() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	out(<<<HAKOHDOC_26
{$HtagBig_}이름, 패스워드 모두 공난입니다{$H_tagBig}$HtempBack
HAKOHDOC_26
);
}


/*
 * 함수: tempChangeNoMoney()
 * 역할: 변경 비용 부족 안내 화면입니다.
 * 원본 대응: hako/hako-make.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function tempChangeNoMoney() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	out(<<<HAKOHDOC_27
{$HtagBig_}자금부족이기 때문에 변경할 수 없습니다{$H_tagBig}$HtempBack
HAKOHDOC_27
);
}


/*
 * 함수: tempChange()
 * 역할: 섬 정보 변경 완료 화면입니다.
 * 원본 대응: hako/hako-make.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function tempChange() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	out(<<<HAKOHDOC_28
{$HtagBig_}변경 완료했습니다{$H_tagBig}<br>
{$HtempBack}　<A HREF={$HthisFile}?settei=0>{$HtagBig_}설정의 변경{$H_tagBig}</A>
HAKOHDOC_28
);
}


?>
