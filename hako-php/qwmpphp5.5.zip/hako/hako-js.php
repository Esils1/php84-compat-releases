<?php

/*
 * hako/hako-js.php
 * ------------------------------------------------------------
 * JavaScript 명령 입력 화면 출력 모듈
 *
 * 상세 주석 기준:
 * - 원본 대응: qwmp155.zip 의 hako-js.cgi.
 * - Java 명령 모드에서 사용하는 스크립트, 레이어 이동, 명령 선택, 좌표 선택, 메뉴 표시를 출력합니다.
 * - 이 파일의 대부분은 브라우저에 그대로 출력되는 JavaScript 문자열이므로 PHP 코드처럼 정리하면 화면/동작이 달라집니다.
 * - 대괄호 배열, 함수명, 폼 이름, 레이어 ID는 원본 CGI와 동일해야 합니다.
 * - 원본 CGI 주석 라인 확인 수: 58줄. PHP 주석은 실행 결과를 바꾸지 않는 범위에서 복원/보강했습니다.
 *
 * 유지보수 원칙:
 * - 실행 로직, 저장 포맷, 배열 인덱스, 출력 HTML은 원본 CGI 호환성 대상입니다.
 * - 개조가 필요하면 먼저 해당 변수/함수가 어떤 파일 저장값과 연결되는지 확인하십시오.
 * - 이 주석은 유지보수용이며 실행 결과를 바꾸지 않습니다.
 */

chdir(dirname(__FILE__));
require_once dirname(__FILE__) . '/hako-compat.php';
if (!function_exists('random')) { function random($max) { return hako_rand($max); } }
if (function_exists('htmlEscape')) { $HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : ''); } else { $HdefaultPasswordEsc = isset($HdefaultPassword) ? $HdefaultPassword : ''; }










$HcommandTotal = 42; 



$HcommandDivido = array('개발,0,6','건설,7,30','공격,31,40','운영,41,60');





$HcomList = array($HcomPrepare, $HcomSell, $HcomPrepare2, $HcomReclaim, $HcomDestroy,
	$HcomPlant, $HcomFarm, $HcomFarm2, $HcomFactory, $HcomFactory2, $HcomMountain,
	$HcomBase, $HcomDbase, $HcomSbase, $HcomMonument, $HcomArea,
	$HcomSupply, $HcomDraft, $HcomInfantry, $HcomWithdraw, $HcomUnitOrder, $HcomItem, $HcomSoldier, $HcomSoldier2,
	$HcomDeWar, $HcomCeasefire, $HcomMissileNM, $HcomMissilePP, $HcomMissileDM, $HcomMissileHM, $HcomMissileBM,
	$HcomMissileLD, $HcomSendMonster, $HcomDoNothing,
	$HcomMoney, $HcomFood, $HcomPropaganda, $HcomGiveup, $HcomAmity,
	$HcomAutoPrepare, $HcomAutoPrepare2, $HcomAutoDelete);

if (!($Hnoarmy)) {
	
	hako_splice($HcomList, 16, 8);
	$HcommandTotal -= 8;
}


unset($r); $r = random(100);
$advice = isset($HcomMsg[$r]) ? $HcomMsg[$r] : '';
if ($advice == "") {
	$advice2 = array(
		'징병을 입력 후, 수량을 22에 변경하면「7천 이상 모두 징병」이 됩니다. ',
		'땅 고르기를 입력 후, 수량을 22에 변경하면 「황무지 모두 땅 고르기」가 됩니다. ',
		'단축 키의 설명 키보드의 「9」를 입력하면 수량이 「250」이 됩니다. '
	);
	$advice = "※" . $advice2[random(3)];
} else{
	$advice = "※　커멘드 간이 설명 「" . (isset($HcomName[$r]) ? $HcomName[$r] : '') . "」\n$advice";
}




/*
 * 함수: tempOwnerJava()
 * 역할: Java 개발 화면에 필요한 JavaScript 본문을 출력합니다.
 * 원본 대응: hako/hako-js.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function tempOwnerJava() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	if ($HjavaMode == '' && $HjavaModeSet == 'java') { $HjavaMode = 'java'; } 
	$HcurrentNumber = $HidToNumber[$HcurrentID];
	$island =& $Hislands[$HcurrentNumber];
	$id = $island['id'];
	unset($i); $i = null;
	unset($x); $x = null;
	unset($y); $y = null;
	
	$set_com = "";
	$com_max = "";
	for ($i = 0; $i < $HcommandMax; $i++) {
		
		$command = $island['command'][$i];
		$s_kind = $command['kind'];
		$s_target = $command['target'];
		$s_x = $command['x'];
		$s_y = $command['y'];
		$s_arg = $command['arg'];
		
		if ($i == $HcommandMax-1) {
			$set_com .= "[$s_kind,$s_x,$s_y,$s_arg,$s_target]\n";
			$com_max .= "[0,0]";
		} else{
			$set_com .= "[$s_kind,$s_x,$s_y,$s_arg,$s_target],\n";
			$com_max .= "[0,0],";
		}
	}
	
	$keyName[$HcomPrepare2]	= "(Z)";
	$keyName[$HcomPlant]	= "(S)";
	$keyName[$HcomReclaim]	= "(U)";
	$keyName[$HcomDestroy]	= "(K)";
	$keyName[$HcomFarm]		= "(N)";
	$keyName[$HcomFactory]	= "(F)";
	$keyName[$HcomPresent]	= "(P)";

	$keyName[$HcomDbase]	= "(D)";
	$keyName[$HcomArea]		= "(R)";
	$keyName[$HcomDraft]	= "(C)";
	$keyName[$HcomInfantry]	= "(G)";
	$keyName[$HcomWithdraw]	= "(T)";
	$keyName[$HcomSupply]	= "(H)";
	$keyName[$HcomMissilePP]= "(M)";

	
	unset($l_kind); $l_kind = null;
	unset($str); $str = null;
	$set_listcom = "";
	$click_com = "";
	$click_com2 = "";
	$click_com3 = "";
	$click_com4 = "";
	$ItemList = "";
	$ListIx = -1;

	$All_listCom = 0;
	$com_count = count($HcommandDivido);
	for ($m = 0; $m < $com_count; $m++) {
		$_list_tmp = explode(',', $HcommandDivido[$m]);
		$aa = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
		$dd = isset($_list_tmp[1]) ? $_list_tmp[1] : null;
		$ff = isset($_list_tmp[2]) ? $_list_tmp[2] : null;
		$set_listcom .= "[ ";
		for ($i = 0; $i < $HcommandTotal; $i++) {
			$l_kind = $HcomList[$i];
			$l_cost = $HcomCost[$l_kind];
			if ($l_cost == 0) { $l_cost = '무료'; }
			elseif ($l_cost < 0) { $l_cost = -$l_cost; $l_cost .= $HunitFood; }
			else { $l_cost .= $HunitMoney; }
			if ($l_kind > $dd-1 && $l_kind < $ff+1) {
				$set_listcom .= "[$l_kind,'" . (isset($HcomName[$l_kind]) ? $HcomName[$l_kind] : '') . "','$l_cost'," . (isset($HcomTurn[$l_kind]) ? $HcomTurn[$l_kind] : 0) . "],\n";
				if ($l_kind == $HcomItem) {
					
				} else{
					if ($m != $ListIx) {
						$ListIx = $m;
					}

					$str = "<a href='javascript:void(0);' onmouseover='StatusMsg($l_kind);return true;' onClick='cominput(myForm,6,$l_kind,0)' class='M' TITLE='$l_cost'>" . (isset($HcomName[$l_kind]) ? $HcomName[$l_kind] : '') . (isset($keyName[$l_kind]) ? $keyName[$l_kind] : '') . "</a>";
					if ($m == 0) {
						$click_com .= "$str<br>\n";
						if ($l_kind == $HcomPrepare2) {
							$click_com .= "<a href='javascript:void(0);' onmouseover='StatusMsg($l_kind);return true;' onClick='cominput(myForm,8,$l_kind,0)' class='M' TITLE='$l_cost'>황무지 모두 땅고르기</a><br>\n";
						}
					} elseif ($m == 1) {
						if ($l_kind == $HcomFarm || $l_kind == $HcomFactory) {
					
							$click_com2 .= "$str<br>\n";
						} elseif ($l_kind == $HcomDraft) {
							$click_com2 .= "$str <a href='javascript:void(0);' onmouseover='StatusMsg($l_kind);return true;' onClick='cominput(myForm,8,$l_kind,0)' class='M' TITLE='$l_cost'>(총동원)</a><br>\n";
						} else{
							$click_com2 .= "$str<br>\n";
						}
					} elseif ($m == 2) {
						$click_com3 .= "$str<br>\n";
					}
				}
				$All_listCom++;
			}
			if ($l_kind < $ff+1) { continue; }
		}
		$bai = length($set_listcom);
		$set_listcom = substr($set_listcom, 0,$bai-2);
		$set_listcom .= " ],\n";
	}
	$bai = length($set_listcom);
	$set_listcom = substr($set_listcom, 0,$bai-2);
	if ($HdefaultKind == '') { $default_Kind = 1; }
	else { $default_Kind = $HdefaultKind; }

	
	unset($im); $im = isset($island['item']) && is_array($island['item']) ? $island['item'] : array();
		$__item_sum = 0;
		for ($__ii = 1; $__ii < 16; $__ii++) { $__item_sum += intval(isset($im[$__ii]) ? $im[$__ii] : 0); }
	if ($__item_sum == 0) {
		$click_com4 .= "아이템은 없습니다.<br>\n";
		$ItemList .= "<OPTION VALUE=''> 【 아이템은 없습니다. 】";
	} else{
		$ItemList .= "<OPTION VALUE=''> 【 ↓↓ 아이템 장비 ↓↓ 】";
		unset($tmp); $tmp = "<a href='javascript:void(0);' class='M' onClick='cominput(myForm,6,$HcomItem,";
		for ($i = 1; $i < 16; $i++) {
			if (intval(isset($im[$i]) ? $im[$i] : 0) > 0) {
				unset($ov); $ov = $i + 100;
				$ItemList .= "<OPTION VALUE='$ov'>" . (isset($FItemName[$i]) ? $FItemName[$i] : '') . " (" . (isset($im[$i]) ? $im[$i] : 0) . ")";
				$click_com4 .= "$tmp$i)' TITLE='" . (isset($FItemMsg[$i]) ? $FItemMsg[$i] : '') . "'>" . (isset($FItemName[$i]) ? $FItemName[$i] : '') . "</a>(" . (isset($im[$i]) ? $im[$i] : 0) . ")<br>\n";
			}
		}
	}

	
	$set_island = getJsIslandList();

	
	$_list_tmp = array("","","","","","",$id);
	unset($set_owner); $set_owner = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
	unset($set_resist); $set_resist = isset($_list_tmp[1]) ? $_list_tmp[1] : null;
	unset($set_missile); $set_missile = isset($_list_tmp[2]) ? $_list_tmp[2] : null;
	unset($set_DivPw); $set_DivPw = isset($_list_tmp[3]) ? $_list_tmp[3] : null;
	unset($set_DivPwC); $set_DivPwC = isset($_list_tmp[4]) ? $_list_tmp[4] : null;
	unset($set_map); $set_map = isset($_list_tmp[5]) ? $_list_tmp[5] : null;
	unset($ownerID); $ownerID = isset($_list_tmp[6]) ? $_list_tmp[6] : null;
	unset($bx); $bx = null;
	unset($by); $by = null;
	unset($baseflg); $baseflg = array();
	unset($distance); $distance = null;
	unset($base); $base = null;
	unset($nKind); $nKind = null;
	for ($y = 0; $y < $HislandSize; $y++) {
		$set_owner .= "[";
		$set_resist .= "[";
		$set_DivPw .= "[";
		$set_DivPwC .= "[";
		$set_map .= "[";
		for ($x = 0; $x < $HislandSize; $x++) {
			$nKind = $Hland[$x][$y];
			if ($id != $HlandOwner[$x][$y] && $nKind == $HlandSbase) {
				$set_owner .= "0,";
			} else{
				$set_owner .= $HlandOwner[$x][$y] . ",";
			}
			$set_resist .= $HlandResist[$x][$y] . ",";
			if ($id == $HlandOwner[$x][$y]) {
				$set_map .= ($nKind != $HlandSea || !$HlandValue[$x][$y]) ? "$nKind," : '-1,';
			} else{
				if ($nKind == $HlandBase || $nKind == $HlandDefence || $nKind == $HlandSupply) {
					$set_map .= "$HlandForest,";
				} elseif ($nKind == $HlandSbase) {
					$set_map .= "$HlandSea,";
				} else{
					$set_map .= ($nKind != $HlandSea || !$HlandValue[$x][$y]) ? "$nKind," : '-1,';
				}
			}

				if (($id == $HlandOwner[$x][$y]) &&
					(($nKind == $HlandBase) || ($nKind == $HlandSbase))) {
					hako_push($baseflg, $x*$HislandSize+$y);
				}
			if ($HlandDivPw[$x][$y] > 0) {
				$disp = 0;
				$sflg = array(1,7,19,37);
				for ($_ = 1; $_ <= 36; $_++) {
						
						$_list_tmp = array($x + $ax[$_],$y + $ay[$_]);
						unset($sx); $sx = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
						unset($sy); $sy = isset($_list_tmp[1]) ? $_list_tmp[1] : null;
						if (!($sy % 2) && ($y % 2)) { $sx--; }
						if ($Hroundmode) {
							$sx = $correct[$sx + 12];
							$sy = $correct[$sy + 12];
						}
						if (($sx < 0) || ($sx >= $HislandSize) || ($sy < 0) || ($sy >= $HislandSize)) { continue; }
						if ((($_ < $sflg[$FsearchR[$HlandDiv[$sx][$sy]]]) && ($HlandDivNa[$sx][$sy] == $id) && ($HlandDivPw[$sx][$sy] > 0)) ||
							(($_ < 19) && ($HlandOwner[$sx][$sy] == $id) && ($Hland[$sx][$sy] == $HlandSupply)) ||
							(($_ < 19) && ($HlandOwner[$sx][$sy] == $id) && ($Hland[$sx][$sy] == $HlandMountain))) {
							$disp = 1;
							break;
						}
					}
				if (($id == $HlandDivNa[$x][$y]) || ($id == $HlandOwner[$x][$y]) || ($disp) || ($Hdebug == 2)) {
					unset($col); $col = 'enemy';
					if ($id == $HlandDivNa[$x][$y]) { $col = $island['color'][$island['HGr'][$x][$y] - 1]; }
					$set_DivPw .= $HlandDivPw[$x][$y] . ",";
					$set_DivPwC .= "'$col',";
				} else{
					$set_DivPw .= "0,";
					$set_DivPwC .= "'0',";
				}
			} else{
				$set_DivPw .= "0,";
				$set_DivPwC .= "'',";
			}
		}
		hako_chop($set_owner);
		hako_chop($set_resist);
		hako_chop($set_DivPw);
		hako_chop($set_DivPwC);
		hako_chop($set_map);
		$set_owner .= "],\n";
		$set_resist .= "],\n";
		$set_DivPw .= "],\n";
		$set_DivPwC .= "],\n";
		$set_map .= "],\n";
	}
	$set_owner = substr($set_owner, 0, -2);
	$set_resist = substr($set_resist, 0, -2);
	$set_DivPw = substr($set_DivPw, 0, -2);
	$set_DivPwC = substr($set_DivPwC, 0, -2);
	$set_map = substr($set_map, 0, -2);

	
	for ($y = 0; $y < $HislandSize; $y++) {
		$set_missile .= "[";
		for ($x = 0; $x < $HislandSize; $x++) {
			$base = 0;
			
			foreach ($baseflg as $_) {
				$bx = intval($_ / $HislandSize);
				$by = $_ % $HislandSize;
				
				$_list_tmp = array(abs($bx - $x), abs($by - $y));
				unset($dx); $dx = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
				unset($dy); $dy = isset($_list_tmp[1]) ? $_list_tmp[1] : null;
				$rl = 0;
				if ($x > $bx) {
					
					$rl = 1;
				} elseif ($x < $bx) {
					
					$rl = -1;
				}
				if ($Hroundmode) {
					if ($dx > intval($HislandSize / 2)) {
						$rl = -$rl;
						$dx = $HislandSize - $dx;
					}
					if ($dy > intval($HislandSize / 2)) { $dy = $HislandSize - $dy; }
				}
				$distance = $dx + $dy;
				$distance -= ($dx >= ($dy / 2)) ? intval($dy / 2) : $dx;

				if (!($by % 2) && ($y % 2)) {
					
					if ($rl == 1) { $distance--; }
				} elseif (!($y % 2) && ($by % 2)) {
					
					if ($rl == -1) { $distance--; }
				}
				
				$baseLevel = expToLevel($Hland[$bx][$by], $HlandValue[$bx][$by]);
				if ($Hland[$bx][$by] == $HlandSbase) {
					$baseLevel += $HmissileRangeS;
				} else{
					$baseLevel += $HmissileRange;
				}

				$_list_tmp = expToLevel2($Hland[$bx][$by], $HlandValue[$bx][$by]); 
				unset($level); $level = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
				if ($baseLevel > $distance) { $base += $level; }
			}
			$set_missile .= "$base,";
		}
		hako_chop($set_missile);
		$set_missile .= "],\n";
	}
	$set_missile = substr($set_missile, 0, -2);

	
	unset($wide); $wide = 1;
	if ($island['custom'] & 1) {
		$wide = 0;
	}
	out(<<<HAKOHDOC_0
<CENTER>
{$HtagBig_}{$HtagName_}{$HcurrentName}{$H_tagName}개발 계획{$H_tagBig}<BR><BR>

<FORM name="campform" action="$HthisFile" method="POST" target=_blank>
<INPUT TYPE=HIDDEN NAME=PASSWORD VALUE="{$HdefaultPasswordEsc}">
<INPUT TYPE=HIDDEN NAME=camp{$Hislands[$HcurrentNumber]['id']}">
</FORM>
<FORM name="bbsform" action="$HcampbbsPath" method="POST" target=_blank>
<INPUT TYPE=HIDDEN NAME=PASSWORD VALUE="{$HdefaultPasswordEsc}">
<INPUT TYPE=HIDDEN NAME=campPASS VALUE="{$campPass[$Hislands[$HcurrentNumber]['ally']]}">
<INPUT TYPE=HIDDEN NAME=campID   VALUE="{$Hislands[$HcurrentNumber]['ally']}">
</FORM>
<FORM name="chatform" action="$HcampchatPath" method="POST" target=_blank>
<INPUT TYPE=HIDDEN NAME=mode VALUE="top">
<INPUT TYPE=HIDDEN NAME=oNAME VALUE="{$Hislands[$HcurrentNumber]['ownername']}">
<INPUT TYPE=HIDDEN NAME=PASSWORD VALUE="{$HdefaultPasswordEsc}">
<INPUT TYPE=HIDDEN NAME=campPASS VALUE="{$campPass[$Hislands[$HcurrentNumber]['ally']]}">
<INPUT TYPE=HIDDEN NAME=campID   VALUE="{$Hislands[$HcurrentNumber]['ally']}">
</FORM>
<FORM name="MapEditor" action="$HthisFile" method="POST" target=_blank>
<INPUT TYPE=HIDDEN NAME=ISLANDID VALUE="$HcurrentID">
<INPUT TYPE=HIDDEN NAME=OLDPASS VALUE="{$HdefaultPasswordEsc}">
<INPUT TYPE=HIDDEN NAME=MapEditor">
</FORM>

[<A HREF="$HthisFile">탑에 돌아온다</A>]　
HAKOHDOC_0
	);
	if ($HeditorN) { out("[<A HREF=\"JavaScript:void(0);\" onClick=\"openMEditor();return false;\">맵 에디터</A>]　"); }
	if ($Hallyflg && $HallyDisp) {
		out("[<A HREF=\"JavaScript:void(0);\" onClick=\"openCAMP();return false;\">진영 화면에</A>]　");
		if ($Hcampbbs) { out("[<A HREF=\"JavaScript:void(0);\" onClick=\"openBBS();return false;\">진영 게시판에</A>]　"); }
		if ($Hcampchat) { out("[<A HREF=\"JavaScript:void(0);\" onClick=\"openCHAT();return false;\">진영 회의실에</A>]"); }
	}
	// 원본 CGI의 $#FItemName은 아이템명 배열의 마지막 인덱스입니다.
	// PHP heredoc 안에서 $# 형태를 그대로 쓰면 변수 확장이 깨져 JavaScript 문법 오류가 나므로 숫자로 출력합니다.
	$FItemNameMax = hako_last_index($FItemName);
	out(<<<HAKOHDOC_1
</CENTER>
<SCRIPT Language="JavaScript">
<!--




var xmlhttp;
var str;
g = [$com_max];
k1 = [$com_max];
k2 = [$com_max];
tmpcom1 = [ [0,0,0,0,0] ];
tmpcom2 = [ [0,0,0,0,0] ];
command = [
$set_com];

comlist = [
$set_listcom
];

islname = {
$set_island
};

ownerID = $ownerID;
owner = [
$set_owner
];

resist = [
$set_resist
];

missile = [
$set_missile
];


soldier = {$island['soldier']};
DivPw = [
$set_DivPw
];

DivPwC = [
$set_DivPwC
];

mapdata = [
$set_map
];

mapcommand = [
"$HcomReclaim,$HcomDestroy,$HcomSbase,$HcomWithdraw",
"$HcomReclaim,$HcomDestroy,$HcomWithdraw",
"$HcomMissileNM,$HcomMissilePP,$HcomMissileDM,$HcomMissileLD,$HcomMissileBM,$HcomWithdraw",
"$HcomPrepare,$HcomPrepare2,$HcomDestroy,$HcomInfantry,$HcomWithdraw",
"$HcomMountain,$HcomDestroy,$HcomWithdraw",
"$HcomPrepare,$HcomPrepare2,$HcomDestroy,$HcomSupply,$HcomWithdraw",
"$HcomSupply,$HcomPlant,$HcomFarm,$HcomFarm2,$HcomFactory,$HcomFactory2,$HcomBase,$HcomDbase,$HcomMonument,$HcomDestroy,$HcomWithdraw",
"$HcomDraft,$HcomSupply,$HcomPlant,$HcomFarm,$HcomFarm2,$HcomFactory,$HcomFactory2,$HcomBase,$HcomDbase,$HcomMonument,$HcomDestroy,$HcomWithdraw",
"$HcomPrepare,$HcomPrepare2,$HcomDestroy,$HcomWithdraw",
"$HcomFarm,$HcomFarm2,$HcomPrepare,$HcomPrepare2,$HcomDestroy,$HcomWithdraw",
"$HcomFactory,$HcomFactory2,$HcomPrepare,$HcomPrepare2,$HcomDestroy,$HcomWithdraw",
"$HcomPrepare,$HcomPrepare2,$HcomDestroy,$HcomWithdraw",
"$HcomPrepare,$HcomPrepare2,$HcomDestroy,$HcomDbase,$HcomWithdraw",
"$HcomInfantry,$HcomSupply,$HcomPrepare,$HcomPrepare2,$HcomDestroy,$HcomWithdraw,$HcomItem"
]

mapcommand2 = [
"$HcomReclaim,$HcomDestroy,$HcomSbase,$HcomWithdraw",
"$HcomReclaim,$HcomDestroy,$HcomWithdraw",
"$HcomMissileNM,$HcomMissilePP,$HcomMissileDM,$HcomMissileLD,$HcomMissileBM,$HcomWithdraw",
"$HcomMissileNM,$HcomMissilePP,$HcomMissileDM,$HcomMissileLD,$HcomMissileBM,$HcomWithdraw",
"$HcomMissileNM,$HcomMissilePP,$HcomMissileDM,$HcomMissileLD,$HcomMissileBM,$HcomMountain,$HcomWithdraw",
"$HcomMissileNM,$HcomMissilePP,$HcomMissileDM,$HcomMissileLD,$HcomMissileBM,$HcomWithdraw,$HcomPrepare",
"$HcomMissileNM,$HcomMissilePP,$HcomMissileDM,$HcomMissileLD,$HcomMissileBM,$HcomSupply,$HcomBase,$HcomDbase,$HcomMonument,$HcomWithdraw",
"$HcomMissileNM,$HcomMissilePP,$HcomMissileDM,$HcomMissileLD,$HcomMissileBM,$HcomWithdraw",
"$HcomMissileNM,$HcomMissilePP,$HcomMissileDM,$HcomMissileLD,$HcomMissileBM,$HcomWithdraw",
"$HcomMissileNM,$HcomMissilePP,$HcomMissileDM,$HcomMissileLD,$HcomMissileBM,$HcomFarm,$HcomWithdraw",
"$HcomMissileNM,$HcomMissilePP,$HcomMissileDM,$HcomMissileLD,$HcomMissileBM,$HcomFactory,$HcomWithdraw",
"$HcomMissileNM,$HcomMissilePP,$HcomMissileDM,$HcomMissileLD,$HcomMissileBM,$HcomWithdraw",
"$HcomMissileNM,$HcomMissilePP,$HcomMissileDM,$HcomMissileLD,$HcomMissileBM,$HcomWithdraw",
"$HcomMissileNM,$HcomMissilePP,$HcomMissileDM,$HcomMissileLD,$HcomMissileBM,$HcomWithdraw",
]

bgclr = 0;
function init(){
	for(i = 0; i < command.length ;i++) {
		for(s = 0; s < $com_count ;s++) {
		var comlist2 = comlist[s];
		for(j = 0; j < comlist2.length ; j++) {
			if(command[i][0] == comlist2[j][0]) {
				g[i] = [comlist2[j][1], comlist2[j][3]];
			}
		}
		}
	}
	outp();
	str = plchg($HcommandMax);
	str = "<TABLE border=0><TR><TD class='commandjs1'><B>－－－－ 송신이 끝난 상태 －－－－</B><br><br>"+str+"<br><B>－－－－ 송신이 끝난 상태 －－－－</B></TD></TR></TABLE>";
	disp(str, 1);
	xmlhttp = new_http();
	if(document.layers) {
		document.captureEvents(Event.MOUSEMOVE | Event.MOUSEUP);
	}
	document.onmouseup   = Mup;
	document.onmousemove = Mmove;
	document.onkeydown = Kdown;
	document.ch_numForm.AMOUNT.options.length = 71;
	for(i=0;i<document.ch_numForm.AMOUNT.options.length;i++){
		document.ch_numForm.AMOUNT.options[i].value = i;
		document.ch_numForm.AMOUNT.options[i].text  = i;
		if(i>=50){
			document.ch_numForm.AMOUNT.options[i].value = (i-45) * 10;
			document.ch_numForm.AMOUNT.options[i].text  = (i-45) * 10;
		}
	}
	document.myForm.CommandJavaButton{$Hislands[$HcurrentNumber]['id']}.disabled = true;
	ns(0);

}
function init2(){
	str = plchg(document.myForm.CMDMAX.value);
	if(bgclr == 1){
		str = "<TABLE border=0><TR><TD class='commandjs1'><B>－－－－ 송신이 끝난 상태 －－－－</B><br><br>"+str+"<br><B>－－－－ 송신이 끝난 상태 －－－－</B></TD></TR></TABLE>";
		disp(str, 1);
	}else{
		str = "<TABLE border=0><TR><TD class='commandjs2'><B>－－－－－미송신-----</B><br><br>"+str+"<br><B>－－－－－미송신-----</B></TD></TR></TABLE>";
		disp(str, 2);
	}
	ns(0);
}

function cominput(theForm, x, k, pp, z) {
	a = theForm.NUMBER.options[theForm.NUMBER.selectedIndex].value;
	b = theForm.COMMAND.options[theForm.COMMAND.selectedIndex].value;
	c = theForm.POINTX.options[theForm.POINTX.selectedIndex].value;
	d = theForm.POINTY.options[theForm.POINTY.selectedIndex].value;
	e = theForm.AMOUNT.options[theForm.AMOUNT.selectedIndex].value;
	f = theForm.TARGETID.options[theForm.TARGETID.selectedIndex].value;
	var newNs = a;
	if(x == 8){x = 6;e = 22}
	if(x == 1 || x == 2 || x == 6){
		if(x == 6){
			b = k;
			if(pp != 0) {e = pp;}
		}
		if(30 < b && b < 41) f = owner[d][c];
		if(x != 2) {
			for(i = $HcommandMax - 1; i > a; i--) {
				command[i] = command[i-1];
				g[i] = g[i-1];
			}
		}
		for(s = 0; s < $com_count ;s++) {
			var comlist2 = comlist[s];
			for(i = 0; i < comlist2.length; i++){
				if(comlist2[i][0] == b){
					g[a] = [comlist2[i][1], comlist2[i][3]];
					break;
				}
			}
		}
		command[a] = [b,c,d,e,f];
		newNs++;
		menuclose();
	}else if(x == 3){
		var num = (k) ? k-1 : a;
		for(i = Math.floor(num); i < ($HcommandMax - 1); i++) {
			command[i] = command[i + 1];
			g[i] = g[i+1];
		}
		command[$HcommandMax-1] = [41,0,0,0,0];
		g[$HcommandMax-1] = ['자금융통', '1'];
	}else if(x == 4){
		i = Math.floor(a)
		if (i == 0){ return true; }
		i = Math.floor(a)
		tmpcom1[i] = command[i];tmpcom2[i] = command[i - 1];
		command[i] = tmpcom2[i];command[i-1] = tmpcom1[i];
		k1[i] = g[i];k2[i] = g[i - 1];
		g[i] = k2[i];g[i-1] = k1[i];
		newNs = i-1;
	}else if(x == 5){
		i = Math.floor(a)
		if (i == $HcommandMax-1){ return true; }
		tmpcom1[i] = command[i];tmpcom2[i] = command[i + 1];
		command[i] = tmpcom2[i];command[i+1] = tmpcom1[i];
		k1[i] = g[i];k2[i] = g[i + 1];
		g[i] = k2[i];g[i+1] = k1[i];
		newNs = i+1;
	}else if(x == 7){
		
		var ctmp = command[k];
		var gtmp = g[k];
		if(z > k) {
			
			for(i = k; i < z-1; i++) {
				command[i] = command[i+1];
				g[i] = g[i+1];
			}
		} else {
			
			for(i = k; i > z; i--) {
				command[i] = command[i-1];
				g[i] = g[i-1];
			}
		}
		command[i] = ctmp;
		g[i] = gtmp;
	}else if(x == 9){
		command[a][3] = k;
	}

	str = plchg($HcommandMax);
	str = "<TABLE border=0><TR><TD class='commandjs2'><B>－－－－－미송신-----</B><br><br>"+str+"<br><B>－－－－－미송신-----</B></TD></TR></TABLE>";
	disp(str, 2);
	outp();
	theForm.CommandJavaButton{$Hislands[$HcurrentNumber]['id']}.disabled = false;
	ns(newNs);
	return true;
}

function plchg(cmdmax){
	strn1 = "";
	strturn = "";
	turn = $HislandTurn + 1;
	cflag = 1;
	trunCt = 0;
	ct    = 0;
	for(i = 0; i < document.myForm.CMDMAX.value; i++){
		commandturn = g[i][1];
		c = command[i];
		if(i+1 < document.myForm.CMDMAX.value) c2 = command[i+1];
		x = c[1];
		y = c[2];
		if((c[0] == $HcomSupply) && (mapdata[y][x] == $HlandSupply)) {
			commandturn = 0;
		}else if((c2[0] == $HcomPrepare2 || c2[0] == $HcomDraft) && (c2[3] == 22)) {
			commandturn = 1;
		}
		if(c[0] == $HcomPrepare2 && c[3] == 22) {
			g[i][0] = '황무지 모두 땅 고르기';
		}else if(c[0] == $HcomDraft && c[3] == 22) {
			g[i][0] = '7천 이상 모두 징병';
		}
		if(commandturn == 0) {
			kind = '$HtagComName2_' + g[i][0] + '$H_tagComName';
		} else {
			kind = '$HtagComName1_' + g[i][0] + '$H_tagComName';
		}
		carg = c[3];
		tgt = c[4];
		tgt = '$HtagName_' + islname[tgt] + '{$H_tagName}';
		if(carg == 0) { carg = 1; }
		if( (c[0] == $HcomFarm) ||
			(c[0] == $HcomFactory) ||
			(c[0] == $HcomFarm2) ||
			(c[0] == $HcomFactory2) ||
			(c[0] == $HcomMountain) ||
			(c[0] == $HcomPropaganda)
			) {
			trunCt += commandturn * carg;
		} else {
			trunCt += commandturn;
		}
		if(cflag <= trunCt) {
			point = '{$HtagName_}(' + x + ',' + y + '){$H_tagName}';
			strturn = '$HtagComName1_' + turn + '$H_tagComName';
			turn += Math.floor(trunCt/cflag);
			trunCt %= cflag;
		} else {
			point = '{$HtagComName2_}(' + x + ',' + y + '){$H_tagComName}';
			strturn = '$HtagComName2_' + turn + '$H_tagComName';
		}

		if(c[0] == $HcomDoNothing || c[0] == $HcomGiveup){ 
			strn2 = kind;
		}else if(c[0] == $HcomInfantry){
			if(0 < c[3] && c[3] < 10){ c[3] = 10; }
			if(DivPw[y][x] > 0 && DivPwC[y][x] != 'enemy' && (250 - DivPw[y][x] < c[3])) c[3] = 250 - DivPw[y][x];
			ct += parseInt(c[3]);
			if(ct > soldier){
				strn2 = point + '로' + kind + '(' + c[3] + ' {$HtagDisaster_}계' + ct + '{$H_tagDisaster})';
			}else{
				strn2 = point + "" + kind + "(" + c[3] + " 계" + ct + ")";
			}
		}else if(c[0] == $HcomDeWar || c[0] == $HcomCeasefire) { 
			strn2 = tgt + '에' + kind;
		}else if(c[0] == $HcomAmity) { 
			if(c[3] == 1003){
				strn2 = tgt + '에' + kind + '({$HtagName_}우호 수락{$H_tagName})';
			}else if(c[3] == 1002){
				strn2 = tgt + '에' + kind + '({$HtagName_}우호 거부{$H_tagName})';
			}else{
				if(c[3] < 10){ c[3] = 10;}
				if(c[3] > 50){ c[3] = 50;}
				strn2 = tgt + '에' + kind + '($HtagName_' + c[3] + '턴{$H_tagName})';
			}
		}else if(c[0] == $HcomMissileNM || 
			c[0] == $HcomMissilePP || 
			c[0] == $HcomMissileDM || 
			c[0] == $HcomMissileLD || 
			c[0] == $HcomMissileHM || 
			c[0] == $HcomMissileBM){
			if(c[0] == $HcomMissileHM) {c[3] = 1;}
			if(c[3] == 0){
				arg = '({$HtagName_}무제한{$H_tagName})';
			} else {
				arg = '($HtagName_' + c[3] + '발{$H_tagName})';
			}
			strn2 = tgt + point + "" + kind + arg;
		}else if(c[0] == $HcomSendMonster){
			strn2 = tgt + point + "" + kind;
		}else if(c[0] == $HcomArea){
			if(c[3] == 1){
				strn2 = tgt + "" + kind + point + "(부대도 양도)";
			}else{
				strn2 = tgt + "" + kind + point;
			}
		}else if(c[0] == $HcomSell){ 
			if(c[3] == 0){ c[3] = 1; }
			arg = c[3];
			strn2 = kind + '$HtagName_' + arg + '{$HunitFood2}{$H_tagName}(' + arg + '0{$HunitMoney}상당)';
		}else if(c[0] == $HcomPropaganda){ 
			if(c[3] == 0){
				strn2 = kind;
			} else {
				strn2 = kind + '($HtagName_' + c[3] + '회{$H_tagName})';
			}
		}else if(c[0] == $HcomMoney){ 
			if(c[3] == 0){ c[3] = 1; }
			arg = c[3] * $HcomCost[$HcomMoney];
			arg = '($HtagName_' + arg + '{$HunitMoney}{$H_tagName})';
			strn2 = tgt + "" + kind + arg;
		}else if(c[0] == $HcomFood){ 
			if(c[3] == 0){ c[3] = 1; }
			arg = c[3];
			arg = '($HtagName_' + arg + '{$HunitFood2}{$H_tagName})';
			strn2 = tgt + "" + kind + arg;
		}else if(c[0] == $HcomSoldier){ 
			if(c[3] == 0){ c[3] = 1; }
			arg = '($HtagName_' + c[3] + '{$HunitPop}{$H_tagName})';
			strn2 = tgt + "" + kind + arg;
		}else if(c[0] == $HcomSoldier2){ 
			if(c[3] == 0){ c[3] = 1; }
			arg = c[3];
			arg2 = arg * $HcomCost[$HcomSoldier2];
			strn2 = kind + '$HtagName_' + arg + '{$HunitPop2}{$H_tagName}(' + arg2 + '{$HunitMoney}상당)';
		}else if(c[0] == $HcomMonument){ 
			if(c[3] == 0) {
				strn2 = point + "" + kind + '({$HtagName_}방벽{$H_tagName})';
			} else if(c[3] == 1) {
				strn2 = point + "" + kind + '({$HtagName_}모노리스{$H_tagName})';
			} else if(c[3] == 2) {
				strn2 = point + "" + kind + '({$HtagName_}평화 기념비{$H_tagName})';
			} else if(c[3] == 3) {
				strn2 = point + "" + kind + '({$HtagName_}싸움의 비{$H_tagName})';
			} else {
				strn2 = point + "" + kind;
			}
		}else if(c[0] == $HcomFarm || 
			c[0] == $HcomFactory ||
			c[0] == $HcomFarm2 ||
			c[0] == $HcomFactory2 ||
			c[0] == $HcomMountain) {
			if(c[3] != 0){
				arg = '($HtagName_' + c[3] + '회{$H_tagName})';
				strn2 = point + "" + kind + arg;
			}else{
				strn2 = point + "" + kind;
			}
		}else if(c[0] == $HcomSupply){
			strn2 = point + "" + kind + "(" + c[3] + ")";
		}else if(c[0] == $HcomUnitOrder){
			strn2 = kind + "(" + c[3] + "군→" + c[1] + ")";
		}else if(c[0] == $HcomItem){
			if(c[3] == 0){ c[3] = 1; }
			if(c[3] > $FItemNameMax){ c[3] = $FItemNameMax; }
			tmp = '';
			if(c[3] == 1) {
				tmp = '$FItemName[1]';
HAKOHDOC_1
);
		for ($i = 2; $i <= hako_last_index($FItemName); $i++) {
	out(<<<HAKOHDOC_2
			} else if(c[3] == $i) {
				tmp = '$FItemName[$i]';
HAKOHDOC_2
);
		}
	out(<<<HAKOHDOC_3
			}
			strn2 = point + "" + kind + '($HtagName_' + tmp + '{$H_tagName})';
		}else if(c[0] == $HcomWithdraw && c[3] == 1){
			strn2 = point + "" + kind + "(초토)";
		}else if((c[0] == $HcomPrepare2 || c[0] == $HcomDraft) && (c[3] == 22)) {
			strn2 = kind;
		}else{
			strn2 = point + "" + kind;
		}
		tmpnum = '';
		if(i < 9){ tmpnum = '0'; }
		strn1 += 
			'<div id="com_'+i+'"'+
			'onmouseover="mc_over('+i+');return false;" '+
			'><A STYLE="text-decoration:none;color:000000" HREF="JavaScript:void(0);" onClick="ns(' + i + ')" '+
			'onmousedown="return comListMove('+i+');" '+
			'ondblclick="chNum('+c[3]+');return false;" '+
			'><NOBR>' + tmpnum + (i + 1) + '<FONT SIZE=-1>$HnormalColor_(' + strturn + ')│'
			 + strn2 + '$H_normalColor</FONT></NOBR></A></div>\\n';
	}
	return strn1;
}
function disp(str,bg){
	if(str==null)  str = "";
	bgclr = bg;
	if(document.getElementById || document.all){
		LayWrite('LINKMSG1', str);
	} else if(document.layers) {
		lay = document.layers["PARENT_LINKMSG"].document.layers["LINKMSG1"];
		lay.document.open();
		lay.document.write("<font style='font-size:11pt'>"+str+"</font>");
		lay.document.close(); 
	}
}

function outp(){
	comary = "";
	for(k = 0; k < command.length; k++){
	comary = comary + command[k][0]
	+" "+command[k][1]
	+" "+command[k][2]
	+" "+command[k][3]
	+" "+command[k][4]
	+" ";
	}
	document.myForm.COMARY.value = comary;
}

function ps(x, y, id) {
	document.myForm.POINTX.options[x].selected = true;
	document.myForm.POINTY.options[y].selected = true;
	document.allForm.POINTX.value = x;
	document.allForm.POINTY.value = y;
	if(document.mark_form.mark.checked) {
		set_mark(x, y);
	}else if(!(document.myForm.MENUOPEN.checked)) {
		NaviClose();
		if(document.myForm.MENUOPEN2.checked) {
			moveLAYER("menu2",mx+10,my-50);
		} else {
HAKOHDOC_3
);
	if ($HjavaMode != 'java') { out("			menuinit(x,y,-2);\n"); }
	out(<<<HAKOHDOC_4
			moveLAYER("menu",mx+10,my-50);
		}
	}
	return true;
}

function SelectPOINT(){
	document.allForm.POINTX.value = document.myForm.POINTX.options[document.myForm.POINTX.selectedIndex].value;
	document.allForm.POINTY.value = document.myForm.POINTY.options[document.myForm.POINTY.selectedIndex].value;
	document.allForm.submit();
}

function ns(x) {
	if (x == $HcommandMax){ return true; }
	document.myForm.NUMBER.options[x].selected = true;
	document.allForm.NUMBER.value = x;
	selCommand(x);
	return true;
}

function set_com(x, y, land, img, name, title, text, exp) {
	com_str = land + "\\n";
	for(i = 0; i < $HcommandMax; i++){
		c = command[i];
		x2 = c[1];
		y2 = c[2];
		if(x == x2 && y == y2 && c[0] < 30){
			com_str += "[" + (i + 1) +"]" ;
			kind = g[i][0];
			if(c[0] == $HcomFarm || c[0] == $HcomFactory || c[0] == $HcomFarm2 || c[0] == $HcomFactory2 || c[0] == $HcomMountain) {
				if(c[3] != 0){
					arg = "「" + c[3] + "회」";
					com_str += kind + arg;
				}else{
					com_str += kind;
				}
			}else{
				com_str += kind;
			}
			com_str += " ";
		}
	}
	window.status = com_str;
	document.mapForm.COMSTATUS1.value= com_str;
	document.mapForm.COMSTATUS2.value= com_str;
	Navi(x, y, img, name, title, text, exp);
	document.mapForm.COMSTATUS1.scrollTop = 1;
	if(document.mapForm.COMSTATUS1.scrollTop > 0){
		document.mapForm.COMSTATUS1.setAttribute('rows','3');
		document.mapForm.COMSTATUS2.setAttribute('rows','3');
	}
}

function SelectList(theForm){
	var u, selected_ok;
	if(!theForm){s = ''}
	else { s = theForm.menuchoice.options[theForm.menuchoice.selectedIndex].value; }
	if(s == ''){
		u = 0; selected_ok = 0;
		document.myForm.COMMAND.options.length = $All_listCom;
		for (i=0; i<comlist.length; i++) {
			var command = comlist[i];
			for (a=0; a<command.length; a++) {
				comName = command[a][1] + "(" + command[a][2] + ")";
				document.myForm.COMMAND.options[u].value = command[a][0];
				document.myForm.COMMAND.options[u].text = comName;
				if(command[a][0] == $default_Kind){
					document.myForm.COMMAND.options[u].selected = true;
					selected_ok = 1;
				}
				u++;
			}
		}
		if(selected_ok == 0)
		document.myForm.COMMAND.selectedIndex = 0;
	} else {
		var command = comlist[s];
		document.myForm.COMMAND.options.length = command.length;
		for (i=0; i<command.length; i++) {
			comName = command[i][1] + "(" + command[i][2] + ")";
			document.myForm.COMMAND.options[i].value = command[i][0];
			document.myForm.COMMAND.options[i].text = comName;
			if(command[i][0] == $default_Kind){
				document.myForm.COMMAND.options[i].selected = true;
				selected_ok = 1;
			}
		}
		if(selected_ok == 0)
		document.myForm.COMMAND.selectedIndex = 0;
	}
}
function StatusMsg(x) {
msg = new Array(64);
HAKOHDOC_4
);
	unset($i); $i = null;
	unset($k); $k = null;
	for ($i = 0; $i < $HcommandTotal; $i++) {
		$k = $HcomList[$i];
		$Msg = isset($HcomMsg[$k]) ? $HcomMsg[$k] : '';
		out("msg[$k] = \"$Msg\";\n");
	}
	out(<<<HAKOHDOC_5
	window.status = msg[x];
	document.mapForm.COMSTATUS1.value= msg[x];
	document.mapForm.COMSTATUS2.value= msg[x];
}

function moveLAYER(layName,x,y){
	if(document.getElementById){		
		el = document.getElementById(layName);
		el.style.left = x;
		el.style.top  = y;
	} else if(document.layers){				
		msgLay.moveTo(x,y);
	} else if(document.all){				
		msgLay = document.all(layName).style;
		msgLay.pixelLeft = x;
		msgLay.pixelTop = y;
	}
}

var mapx = 0;
var mapy = 0;
function menuinit(x,y,z){
	var ItemList = "$ItemList";
	if(z < -1){
		mapx = x;mapy = y;
		land = mapdata[y][x];
		ow = owner[y][x];
		for(i = 0; i < document.myForm.NUMBER.selectedIndex;i++) {
			if((x == command[i][1] && y == command[i][2]) && (command[i][0] == $HcomSupply)){
				land = $HlandSupply;
			}else if(land == -1 && (x == command[i][1] && y == command[i][2]) && command[i][0] == $HcomReclaim){
				land = $HlandWaste;ow = $id
			}else if(land >= $HlandWaste || land == $HlandMonument){
				if((x == command[i][1] && y == command[i][2]) && (command[i][0] == $HcomPrepare || command[i][0] == $HcomPrepare2)){
					land = $HlandPlains;
				}
			}
		}
		if(land < 0) land = 0;
	}
	
	var ct = 0;
	var menulist = "";
	if(z < 0){
		if($id == ow) {
			com_array = mapcommand[land].split(",");
		}else{
			com_array = mapcommand2[land].split(",");
		}
		for(i = 0; i < com_array.length ; i++) {
			for(s = 0; s < 4 ;s++) {
			var comlist2 = comlist[s];
			for(j = 0; j < comlist2.length ; j++) {
				if(com_array[i] == comlist2[j][0]){
					if(comlist2[j][0] == $HcomWithdraw && (DivPw[mapy][mapx] == 0 || DivPwC[mapy][mapx] == 'enemy')){
						continue;
					}else if(comlist2[j][0] == $HcomItem){
						menulist += ItemList;
					}else{
						menulist += "<OPTION VALUE='" + comlist2[j][0] + "'>" + comlist2[j][1] + "(" + comlist2[j][2] + ")";
					}
					ct++;
				}
			}
			}
		}
	}else{
		var comlist2 = comlist[z];
		for(j = 0; j < comlist2.length ; j++) {
			if(comlist2[j][0] == $HcomItem){
				menulist += ItemList;
			}else{
				menulist += "<OPTION VALUE='" + comlist2[j][0] + "'>" + comlist2[j][1] + "(" + comlist2[j][2] + ")";
			}
			ct++;
		}
	}
	menulist = '<SELECT size="' + ct + '"NAME="command_list" onChange="select_command(com_list, myForm)">' + menulist + "</SELECT>";
	LayWrite('popupmenu', menulist);
	z++;if(z < 0) z = 0;
	for(i = 0; i < 5 ; i++) {
		if(i == z){
			document.getElementById('PMENU'+i).style.backgroundColor = '#FFAAAA';
		}else{
			document.getElementById('PMENU'+i).style.backgroundColor = '';
		}
	}
}

function menuclose(){
	moveLAYER("menu",-500,-500);
	moveLAYER("menu2",-500,-500);
	moveLAYER("TakokuYU",-500,-500);
	moveLAYER("TakokuSE",-500,-500);
}

function Mmove(e){
	if(document.all){
		mx = event.x + document.body.scrollLeft;
		my = event.y + document.body.scrollTop;
	}else if(document.layers){
		mx = e.pageX;
		my = e.pageY;
	}else if(document.getElementById){
		mx = e.pageX;
		my = e.pageY;
	}
	return moveLay.move();
}
function Kdown(e){
	var c, el;
	if(document.all){
		if (event.altKey || event.ctrlKey || event.shiftKey) return;
		c = event.keyCode;
		el = new String(event.srcElement.tagName);
		el = el.toUpperCase();
		if (el == "INPUT") return;
	}else if(document.getElementById){
		if (e.altKey || e.ctrlKey || e.shiftKey) return;
		c = e.which;
		el = new String(e.target.tagName);
		el = el.toUpperCase();
		if (el == "INPUT") return;
	}
	c = String.fromCharCode(c);
	window.status = c; 

	
	switch (c) {
	case 'Z': c = $HcomPrepare2; break; 
	case 'S': c = $HcomPlant; break; 
	case 'U': c = $HcomReclaim; break; 
	case 'K': c = $HcomDestroy; break; 
	case 'N': c = $HcomFarm; break; 
	case 'F': c = $HcomFactory; break; 
	case 'B': c = $HcomBase; break; 
	case 'D': c = $HcomDbase; break; 
	case 'R': c = $HcomArea; break; 
	case 'C': c = $HcomDraft; break; 
	case 'G': c = $HcomInfantry; break; 
	case 'T': c = $HcomWithdraw; break; 
	case 'H': c = $HcomSupply; break; 
	case 'M': c = $HcomMissilePP; break; 
	case 'A': c = $HcomPropaganda; break; 
	case '-': c = $HcomDoNothing; break; 
	case '.': cominput(myForm,3); return; 
	case'\b': 
		var no = document.myForm.NUMBER.selectedIndex;
		if(no > 0) document.myForm.NUMBER.selectedIndex = no - 1;
		cominput(myForm,3);
		return;
	case '0':case'`': document.myForm.AMOUNT.selectedIndex = 0; return;
	case '1':case'a': document.myForm.AMOUNT.selectedIndex = 1; return;
	case '2':case'b': document.myForm.AMOUNT.selectedIndex = 2; return;
	case '3':case'c': document.myForm.AMOUNT.selectedIndex = 3; return;
	case '4':case'd': document.myForm.AMOUNT.selectedIndex = 4; return;
	case '5':case'e': document.myForm.AMOUNT.selectedIndex = 5; return;
	case '6':case'f': document.myForm.AMOUNT.selectedIndex = 6; return;
	case '7':case'g': document.myForm.AMOUNT.selectedIndex = 7; return;
	case '8':case'h': document.myForm.AMOUNT.selectedIndex = 8; return;
	case '9':case'i': document.myForm.AMOUNT.selectedIndex = 70; return;
	default:
	
	return;
	}
	cominput(document.myForm, 6, c, 0);
}

function openCAMP(){
	document.campform.submit();
}
function openBBS(){
	document.bbsform.submit();
}
function openCHAT(){
	document.chatform.submit();
}
function openMEditor(){
	document.MapEditor.submit();
}

function LayWrite(layName, str) {
	if(document.getElementById){
		document.getElementById(layName).innerHTML = str;
	} else if(document.all){
		document.all(layName).innerHTML = str;
	} else if(document.layers){
		lay = document.layers[layName];
		lay.document.open();
		lay.document.write(str);
		lay.document.close(); 
	}
}

var oldNum=0;
function selCommand(num) {
	document.getElementById('com_'+oldNum).style.backgroundColor = '';
	document.getElementById('com_'+num).style.backgroundColor = '#FFFFAA';
	oldNum = num;
}


var moveLay = new MoveFalse();

var newLnum = -2;
var Mcommand = false;

function Mup() {
	moveLay.up();
	moveLay = new MoveFalse();
}

function setBorder(num, color) {
	if(document.getElementById) {
		if(color.length == 4) document.getElementById('com_'+num).style.borderTop = ' 1px solid '+color;
		else document.getElementById('com_'+num).style.border = '0px';
	}
}

function mc_out() {
	if(Mcommand && newLnum >= 0) {
		setBorder(newLnum, '');
		newLnum = -1;
	}
}

function mc_over(num) {
	if(Mcommand) {
		if(newLnum >= 0) setBorder(newLnum, '');
		newLnum = num;
		setBorder(newLnum, '#116');    
	}
}

function comListMove(num) { moveLay = new MoveComList(num); return (document.layers) ? true : false; }

function MoveFalse() {
	this.move = function() { }
	this.up   = function() { }
}

function MoveComList(num) {
	var setLnum  = num;
	Mcommand = true;

	LayWrite('mc_div', '<NOBR><strong>'+(num+1)+': '+g[num][0]+'</strong></NOBR>');

	this.move = function() {
		moveLAYER('mc_div',mx+10,my-30);
		return false;
	}

	this.up   = function() {
		if(newLnum >= 0) {
			var com = command[setLnum];
			cominput(document.myForm,7,setLnum,0,newLnum);
		}
		else if(newLnum == -1) cominput(document.myForm,3,setLnum+1);

		mc_out();
		newLnum = -2;
		Mcommand = false;
		moveLAYER("mc_div",-50,-50);
	}
}


function new_http() {
	if(document.getElementById) {
		try{
		   return new ActiveXObject("Msxml2.XMLHTTP");
		} catch (e){
			try {
				return new ActiveXObject("Microsoft.XMLHTTP");
			} catch (E){
				if(typeof XMLHttpRequest != 'undefined') return new XMLHttpRequest;
			}
		}
	}
}

function send_command(form) {
	if (!xmlhttp) return true;

	form.CommandJavaButton{$Hislands[$HcurrentNumber]['id']}.disabled = true;

	var progress  = document.getElementById('progress');
	progress.innerHTML = '<blink>Sending...</blink>';

	if (xmlhttp.readyState == 1 || xmlhttp.readyState == 2 || xmlhttp.readyState == 3) return; 

	xmlhttp.open("POST", "$HthisFile", true);
	if(!window.opera) xmlhttp.setRequestHeader("referer", "$HthisFile");

	xmlhttp.onreadystatechange = function() {
		if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
			var result = xmlhttp.responseText;
			if(result.indexOf('AjaxOK') >= 0) {
				str = plchg($HcommandMax);
				str = "<TABLE border=0><TR><TD class='commandjs1'><B>－－－－ 송신이 끝난 상태 －－－－</B><br><br>"+str+"<br><B>－－－－ 송신이 끝난 상태 －－－－</B></TD></TR></TABLE>";
				disp(str, 1);
				selCommand(document.myForm.NUMBER.selectedIndex);
			} else {
				alert("송신에 실패했습니다. ");
				form.CommandJavaButton{$Hislands[$HcurrentNumber]['id']}.disabled = false;
			}
			progress.innerHTML = '';
		}
	}

	var post = '';
	post += 'async=true&';
	post += 'CommandJavaButton{$island['id']}=true&';
	post += 'COMARY='+encodeURIComponent(form.COMARY.value)+'&';
	post += 'PASSWORD='+encodeURIComponent(form.PASSWORD.value)+'&';
	if (xmlhttp.setRequestHeader) xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

	xmlhttp.send(post);
	return false;
}

function showElement(layName) {
	var element = document.getElementById(layName).style;
	element.display = "block";
	element.visibility ='visible';
}

function hideElement(layName) {
	var element = document.getElementById(layName).style;
	element.display = "none";
}

function chNum(num) {
	for(i=0;i<document.ch_numForm.AMOUNT.options.length;i++){
		if(document.ch_numForm.AMOUNT.options[i].value == num){
			document.ch_numForm.AMOUNT.selectedIndex = i;
			document.ch_numForm.AMOUNT.options[i].selected = true;
			break;
		}
	}
	moveLAYER('ch_num', mx-10, my-60);
	showElement('ch_num');
}

function chNumDo(num) {
	if(num == 0) num = document.ch_numForm.AMOUNT.options[document.ch_numForm.AMOUNT.selectedIndex].value;
	cominput(document.myForm,9,num);
	hideElement('ch_num');
}

function chForceMenu() {
	document.getElementById("CHFORCE1").innerHTML = "설정 변경미송신　　→→";
	document.getElementById("CHFORCE2").innerHTML = "←←　설정 변경미송신";
}

var mArray = new Array();

var lastX = 0;
var lastY = 0;
var lastN = 19;
var lastF = 0;

function set_mark(x, y) {
	if(!document.mark_form.mark.checked) return false;
	if(!document.getElementById) {
		alert("Warning: Your Browser could not support marking system.");
		return false;
	}

	var num  = document.mark_form.number_mark.value;
	var kind = document.mark_form.kind_mark.value;

	if(kind == '') {
		do_mark(lastX, lastY, lastN, '-');

		if(lastF == 1 && lastX == x && lastY == y) {
			lastX = 0;
			lastY = 0;
			lastN = 19;
			lastF = 0;
			return;
		}
		lastX = x;
		lastY = y;
		lastN = num;
		lastF = 1;
		kind = 'yellow';
	}
	do_mark(x, y, num, kind);
}

function do_mark(x, y, num, kind) {
	var xArray = new Array(0,1,1,1,0,-1,0,1,2,2,2,1,0,-1,-1,-2,-1,-1,0,2,2,3,3,3,2,2,1,0,-1,-2,-2,-3,-2,-2,-1,0,1,2,3,3,4,4,4,3,3,2,1,0,-1,-2,-2,-3,-3,-4,-3,-3,-2,-2,-1,0,1);
	var yArray = new Array(0,-1,0,1,1,0,-1,-2,-1,0,1,2,2,2,1,0,-1,-2,-2,-3,-2,-1,0,1,2,3,3,3,3,2,1,0,-1,-2,-3,-3,-3,-4,-3,-2,-1,0,1,2,3,4,4,4,4,4,3,2,1,0,-1,-2,-3,-4,-4,-4,-4);
	var cArray = new Array(8,9,10,11,12,13,14,15,16,17,18,19,0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,0,1,2,3,4,5,6,7,8,9,10,11);

	for (i = 0; i < num; i++) {
		var targetX = x + xArray[i];
		var targetY = y + yArray[i];

		if(((targetY % 2) == 0) && ((y % 2) == 1)) {
			targetX = targetX - 1;
		}
		if($Hroundmode){
			targetX = cArray[targetX + 12];
			targetY = cArray[targetY + 12];
		}
		if(!(targetX < 0 || targetX >= $HislandSize || targetY < 0 || targetY >= $HislandSize)) {
			if(kind == '-') {
				unset_highlight(targetX, targetY);
			} else {
				set_highlight(targetX, targetY, kind);
			}
		}
	}
}

function do_mark_id(id, color) {
	for (x=0;x<$HislandSize;x++) {
		for (y=0;y<$HislandSize;y++) {
			if(id == owner[y][x]) {
				set_highlight(x, y, color);
			}else{
				unset_highlight(x, y);
			}
		}
	}
}

function set_highlight(x, y, color) {
	if(document.getElementById) {
		document.getElementById(x+"a"+y+"i").width  = "30";
		document.getElementById(x+"a"+y+"i").height = "30";
		document.getElementById(x+"a"+y+"i").border = "1";
		document.getElementById(x+"a"+y+"i").style.borderColor = color;
		if(($wide == 1) && ((x == 0 || x == $HislandSize - 1) || (y == 0 || y == $HislandSize - 1))){
			document.getElementById(x+"b"+y+"i").width  = "30";
			document.getElementById(x+"b"+y+"i").height = "30";
			document.getElementById(x+"b"+y+"i").border = "1";
			document.getElementById(x+"b"+y+"i").style.borderColor = color;
		}
		if(($wide == 1) && ((x == 0 || x == $HislandSize - 1) && (y == 0 || y == $HislandSize - 1))){
			document.getElementById(x+"c"+y+"i").width  = "30";
			document.getElementById(x+"c"+y+"i").height = "30";
			document.getElementById(x+"c"+y+"i").border = "1";
			document.getElementById(x+"c"+y+"i").style.borderColor = color;
			document.getElementById(x+"d"+y+"i").width  = "30";
			document.getElementById(x+"d"+y+"i").height = "30";
			document.getElementById(x+"d"+y+"i").border = "1";
			document.getElementById(x+"d"+y+"i").style.borderColor = color;
		}
		mArray[x+"x"+y] = 1;
	}
}

function unset_highlight(x, y) {
	if(document.getElementById) {
		document.getElementById(x+"a"+y+"i").width  = "32";
		document.getElementById(x+"a"+y+"i").height = "32";
		document.getElementById(x+"a"+y+"i").border = "0";
		if(($wide == 1) && ((x == 0 || x == $HislandSize - 1) || (y == 0 || y == $HislandSize - 1))){
			document.getElementById(x+"b"+y+"i").width  = "32";
			document.getElementById(x+"b"+y+"i").height = "32";
			document.getElementById(x+"b"+y+"i").border = "0";
		}
		if(($wide == 1) && ((x == 0 || x == $HislandSize - 1) && (y == 0 || y == $HislandSize - 1))){
			document.getElementById(x+"c"+y+"i").width  = "32";
			document.getElementById(x+"c"+y+"i").height = "32";
			document.getElementById(x+"c"+y+"i").border = "0";
			document.getElementById(x+"d"+y+"i").width  = "32";
			document.getElementById(x+"d"+y+"i").height = "32";
			document.getElementById(x+"d"+y+"i").border = "0";
		}
		mArray[x+"x"+y] = 0;
	}
}
function set_mark_ms() {
	if(!document.getElementById) {
		alert("Warning: Your Browser could not support marking system.");
		return false;
	}
	if(document.mapForm.MSMARK[0].checked){
		do_mark_ms(1);
	}else if(document.mapForm.MSMARK[1].checked){
		do_mark_ms(2);
	}else if(document.mapForm.MSMARK[2].checked){
		do_mark_ms(3);
	}
}
function do_mark_ms(m) {
	for (x=0;x<$HislandSize;x++) {
		for (y=0;y<$HislandSize;y++) {
			if(m == 1) {
				if(DivPw[y][x] > 0){
					sc = DivPwC[y][x];
					if(sc == 'enemy') sc = 'red';
					set_highlight2(x, y, DivPw[y][x], sc);
				}else{
					unset_highlight2(x, y);
				}
			}else if(missile[y][x] > 0 && m == 2) {
				set_highlight2(x, y, missile[y][x], 'aqua');
			}else if(resist[y][x] < 10 && m == 3) {
				set_highlight2(x, y, resist[y][x], 'aqua');
			}else if(m == 4) {
				if(document.mapForm.IDMARK.checked && owner[y][x] > 0 && owner[y][x] != ownerID){
					ctbl = ['white','lime','red','aqua','yellow','fuchsia','white','maroon','gray','blue','green','purple','olive','navy','black','teal','silver','white','white'];
					set_highlight(x, y, ctbl[owner[y][x]]);
				}else{
					unset_highlight(x, y);
				}
			}else{
				unset_highlight2(x, y);
			}
		}
	}
}
function set_highlight2(x, y, z, c) {
	if(document.getElementById) {
		document.getElementById(x+"a"+y).style.color = c;
		document.getElementById(x+"a"+y).innerHTML = z;
		if(($wide == 1) && ((x == 0 || x == $HislandSize - 1) || (y == 0 || y == $HislandSize - 1))){
			document.getElementById(x+"b"+y).style.color = c;
			document.getElementById(x+"b"+y).innerHTML = z;
		}
		if(($wide == 1) && ((x == 0 || x == $HislandSize - 1) && (y == 0 || y == $HislandSize - 1))){
			document.getElementById(x+"c"+y).style.color = c;
			document.getElementById(x+"d"+y).style.color = c;
			document.getElementById(x+"c"+y).innerHTML = z;
			document.getElementById(x+"d"+y).innerHTML = z;
		}
	}
}
function unset_highlight2(x, y) {
	if(document.getElementById) {
		document.getElementById(x+"a"+y).innerHTML = "";
		if(($wide == 1) && ((x == 0 || x == $HislandSize - 1) || (y == 0 || y == $HislandSize - 1))){
			document.getElementById(x+"b"+y).style.color = c;
			document.getElementById(x+"b"+y).innerHTML = "";
		}
		if(($wide == 1) && ((x == 0 || x == $HislandSize - 1) && (y == 0 || y == $HislandSize - 1))){
			document.getElementById(x+"c"+y).innerHTML = "";
			document.getElementById(x+"d"+y).innerHTML = "";
		}
	}
}
function mark_menu(){
	if(!document.mark_form.mark.checked){
		unset_all_highlight();
	}else{
		menuclose();
	}
}

function unset_all_highlight() {
	for (f=0;f<$HislandSize;f++) {
		for (i=0;i<$HislandSize;i++) {
			if(mArray[i+"x"+f] == 1) {
				unset_highlight(i, f);
			}
		}
	}
}

function swTakoku(){
	var id = document.myForm.TARGETID.options[document.myForm.TARGETID.selectedIndex].value;
	if(id > 0){
		document.getElementById("TakokuText").innerHTML = document.getElementById("Takoku"+id).innerHTML;
	}else{
		document.getElementById("TakokuText").innerHTML = "";
	}
}
function TakokuYuSe(ID){
	moveLAYER(ID,mx+10,my-150);
}
function handicap(){
	document.mapForm.COMSTATUS1.value= "2개국 이상으로부터 공격받고 있어, 상대의 국력의 총화가 자국의 국력을 넘는 경우에 핸디캡이 랭크에 응해 받을 수 있습니다.";
}
function select_command(set_form, form_name) {
	var Sel = set_form.command_list.options[set_form.command_list.selectedIndex].value;
	if(Sel == ""){
		return;
	}else if(Sel > 100){
		Sel = Sel - 100;
		cominput(form_name, 6, $HcomItem, Sel);
	}else{
		cominput(form_name, 6, Sel, 0);
	}
	document.com_list.command_list.selectedIndex = -1;
}

//-->
</SCRIPT>
HAKOHDOC_5
);
	islandInfo();
	out(<<<HAKOHDOC_6
<CENTER>
<TABLE BORDER>
<TR valign=top>
<TD $HbgInputCell width=30% onmouseout="mc_out();return false;">
<br>
<CENTER>
<FORM name="myForm" action="$HthisFile" method=POST onsubmit="return send_command(this);">
<B>계획 번호</B><SELECT NAME=NUMBER onchange="selCommand(this.selectedIndex)">
HAKOHDOC_6
);
	
	unset($j); $j = null;
	unset($i); $i = null;
	unset($itemMenu); $itemMenu = null;
	for ($i = 0; $i < $HcommandMax; $i++) {
		$j = $i + 1;
		out("<OPTION VALUE=$i>$j\n");
	}
	if ($HmenuOpen == 'on') {
		$open = "CHECKED";
	} else{
		$open = "";
	}
	if ($HjavaMode == 'java') {
		$itemMenu = "<INPUT TYPE=\"checkbox\" NAME=\"MENUOPEN2\" $open onClick=\"menuclose()\">아이템<br>";
	} else{
		$itemMenu = "<INPUT TYPE=\"hidden\" NAME=\"MENUOPEN2\"><br>";
	}
	out(<<<HAKOHDOC_7
</SELECT><BR>
<HR>
<B>개발 계획</B>
<INPUT TYPE="checkbox" NAME="MENUOPEN" $open onClick="menuclose()">비표시
$itemMenu
<SELECT NAME=menuchoice onchange="SelectList(myForm)">
<OPTION VALUE=>전종류
HAKOHDOC_7
);
	for ($i = 0; $i < $com_count; $i++) {
		$_list_tmp = explode(',', $HcommandDivido[$i]);
		$aa = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
		out("<OPTION VALUE=$i>$aa\n");
	}
	out(<<<HAKOHDOC_8
</SELECT>
<SELECT NAME=COMMAND onChange="StatusMsg(this.options[this.selectedIndex].value)" onClick="StatusMsg(this.options[this.selectedIndex].value)">
<option>　　　　　　　　　　</option>
<option>　　　　　　　　　　</option>
<option>　　　　　　　　　　</option>
<option>　　　　　　　　　　</option>
<option>　　　　　　　　　　</option>
<option>　　　　　　　　　　</option>
<option>　　　　　　　　　　</option>
<option>　　　　　　　　　　</option>
<option>　　　　　　　　　　</option>
<option>　　　　　　　　　　</option>
</SELECT>
<HR>
커멘드 입력<B>
<A HREF=JavaScript:void(0); onClick="cominput(myForm,1)">삽입</A>
　<A HREF=JavaScript:void(0); onClick="cominput(myForm,2)">덧쓰기</A>
　<A HREF=JavaScript:void(0); onClick="cominput(myForm,3)">삭제</A>
</B>
<HR>
<B>좌표(</B>
<SELECT NAME=POINTX>
HAKOHDOC_8
);
	for ($i = 0; $i < $HislandSize; $i++) {
		if ($i == $HdefaultX) {
			out("<OPTION VALUE=$i SELECTED>$i\n");
		} else {
			out("<OPTION VALUE=$i>$i\n");
		}
	}
	out(<<<HAKOHDOC_9
</SELECT>, <SELECT NAME=POINTY>
HAKOHDOC_9
);
	for ($i = 0; $i < $HislandSize; $i++) {
		if ($i == $HdefaultY) {
			out("<OPTION VALUE=$i SELECTED>$i\n");
		} else {
			out("<OPTION VALUE=$i>$i\n");
		}
	}
	out(<<<HAKOHDOC_10
</SELECT><B>)</B>
<B>수량</B><SELECT NAME=AMOUNT>
HAKOHDOC_10
);
	
	for ($i = 0; $i < 50; $i++) {
		out("<OPTION VALUE=$i>$i\n");
	}
	for ($i = 50; $i < 251; $i+=10) {
		out("<OPTION VALUE=$i>$i\n");
	}
	out(<<<HAKOHDOC_11
</SELECT>
<HR>
<B>목표의 나라</B>：
<SELECT NAME=TARGETID onchange="swTakoku()">
$HtargetList<BR>
</SELECT>
<HR>
<INPUT TYPE="hidden" NAME="COMARY" value="comary">
<INPUT TYPE=submit VALUE="계획 송신" NAME=CommandJavaButton{$Hislands[$HcurrentNumber]['id']}>
<INPUT TYPE=password NAME=PASSWORD VALUE="{$HdefaultPasswordEsc}" SIZE=8>
<INPUT TYPE="hidden" NAME="DUMMY" VALUE="DUMMY">
<span id="progress"></span>
</CENTER>
<HR>
<SPAN $HbgCommandCell>
<CENTER>
<B>커멘드 이동</B>：
<BIG>
<A HREF=JavaScript:void(0); onClick="cominput(myForm,4)" STYlE="text-decoration:none"> ▲ </A> ··
<A HREF=JavaScript:void(0); onClick="cominput(myForm,5)" STYlE="text-decoration:none"> ▼ </A>
</BIG>
</CENTER>
<ilayer name="PARENT_LINKMSG" width="100%" height="100%">
   <layer name="LINKMSG1" width="200"></layer>
   <span id="LINKMSG1"></span>
</ilayer>
<BR>
커멘드 표시수：
<SELECT NAME=CMDMAX onClick="init2()" onChange="init2()">
HAKOHDOC_11
);
	if ($HcommandMax < 22) {
		out("<OPTION VALUE=$HcommandMax>MAX\n");
	} else{
		out("<OPTION VALUE=20>20<OPTION VALUE=$HcommandMax>MAX\n");
	}
	out(<<<HAKOHDOC_12
</SELECT>

</SPAN>
</FORM>
</TD>
<TD $HbgMapCell>
<FORM name="mapForm">
<INPUT TYPE="radio" NAME="MSMARK" onClick="set_mark_ms()" checked>부대 표시
<INPUT TYPE="radio" NAME="MSMARK" onClick="set_mark_ms()">미사일 착탄 수의 표시
<INPUT TYPE="radio" NAME="MSMARK" onClick="set_mark_ms()">지형 저항력 표시
<INPUT TYPE="checkbox" NAME="IDMARK" onClick="do_mark_ms(4)">국별 분류
<center><TEXTAREA NAME='COMSTATUS1' cols='90' rows='2'>$advice</TEXTAREA></center>
HAKOHDOC_12
);
	islandMap(2,1); 
	unset($comment); $comment = $Hislands[$HcurrentNumber]['comment'];
	out(<<<HAKOHDOC_13
<center><TEXTAREA NAME='COMSTATUS2' cols='90' rows='2'></TEXTAREA></center>
</FORM>

<TABLE BORDER=0>
<TR><TD>
<FORM name="allForm" action="$HthisFile" method=POST>
<INPUT TYPE="hidden" NAME=PASSWORD VALUE="{$HdefaultPasswordEsc}">
<INPUT TYPE="hidden" NAME=NUMBER VALUE="allno">
<INPUT TYPE="hidden" NAME=POINTY VALUE="0">
<INPUT TYPE="hidden" NAME=POINTX VALUE="0">
<DIV ID='AutoCommand'><B>자동계</B>
<SELECT NAME=COMMAND>
HAKOHDOC_13
);
	
	unset($kind); $kind = null;
	unset($cost); $cost = null;
	unset($s); $s = null;
	$m = count($HcommandDivido);
	$_list_tmp = explode(',', $HcommandDivido[$m-1]);
	$aa = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
	unset($dd); $dd = isset($_list_tmp[1]) ? $_list_tmp[1] : null;
	unset($ff); $ff = isset($_list_tmp[2]) ? $_list_tmp[2] : null;
	for ($i = 0; $i < $HcommandTotal; $i++) {
	$kind = $HcomList[$i];
	$cost = $HcomCost[$kind];
	if ($kind > $ff) {
		if ($cost == 0) {
			$cost = '무료';
		}
		if ($kind == $HdefaultKind) {
			$s = 'SELECTED';
		} else {
			$s = '';
		}
		out("<OPTION VALUE=$kind $s>" . (isset($HcomName[$kind]) ? $HcomName[$kind] : '') . "($cost)\n");
		}
	}
	out(<<<HAKOHDOC_14
</SELECT>
<INPUT TYPE="hidden" NAME="CommandButton{$Hislands[$HcurrentNumber]['id']}">
<INPUT TYPE="button" onClick="SelectPOINT()" VALUE="자동계 송신">
</DIV>
</FORM>
</TD><TD>
HAKOHDOC_14
);
	$ostr = "주변 표시 OFF에";
	if ($island['custom'] & 1) {
		$ostr = "주변 표시 ON에";
	}
	out(<<<HAKOHDOC_15
<FORM name="FormCustom" action="$HthisFile" method=POST>
<INPUT TYPE=hidden NAME=PASSWORD VALUE="{$HdefaultPasswordEsc}">
<INPUT TYPE=submit VALUE="$ostr" NAME=customMButton{$Hislands[$HcurrentNumber]['id']}">
<INPUT TYPE=hidden NAME=custom0">
</FORM>
</TD>
HAKOHDOC_15
);
	$ostr = "미 착탄 수의 표시에";
	if ($island['custom'] & 2) {
		$ostr = "부대 표시에";
	}
	out(<<<HAKOHDOC_16
<TD>
<FORM name="FormCustom" action="$HthisFile" method=POST>
<INPUT TYPE=hidden NAME=PASSWORD VALUE="{$HdefaultPasswordEsc}">
<INPUT TYPE=submit VALUE="$ostr" NAME=customMButton{$Hislands[$HcurrentNumber]['id']}">
<INPUT TYPE=hidden NAME=custom1">
</FORM>
</TD>
</TR></TABLE>

</TD></TR></TABLE>
<!-- 수량 변경 폼 -->
<div id="ch_num" style="position:absolute;visibility:hidden;display:none">
<form name="ch_numForm">
<TABLE BORDER=1 BGCOLOR="#e0ffff" CELLSPACING=1>
<TR><TD VALIGN=TOP NOWRAP>
<A HREF="JavaScript:void(0)" onClick="hideElement('ch_num');" STYlE="text-decoration:none"><B>×</B></A>
<A HREF="JavaScript:void(0)" onClick="chNumDo(250);" STYlE="text-decoration:none"><B>Max</B></A>
<BR>
<select name="AMOUNT" size=13 onchange="chNumDo(0)">
</select>
</TD></TR>
</TABLE></form></div>
HAKOHDOC_16
);
	if ($HjavaMode == 'java') {
		out(<<<HAKOHDOC_17
<!--  커멘드 폼 -->
<DIV ID="mc_div" style="background-color:white;position:absolute;top:-50;left:-50;height:22px;">&nbsp;</DIV>
<DIV ID="menu" style="position:absolute; top:-500;left:-500;">
<table border=0 class="PopupCell">
<tr><td NOWRAP COLSPAN=2><a href="Javascript:void(0);" onClick="menuclose()" class='M'>메뉴를 닫는다</A></td></tr>
<tr><td nowrap>$click_com<hr>$click_com3</td><td NOWRAP>$click_com2</td></tr>
</table></DIV>
HAKOHDOC_17
);
	} else{
		out(<<<HAKOHDOC_18
<!-- 수량 변경 폼 -->
<DIV ID="mc_div" style="background-color:white;position:absolute;top:-50;left:-50;height:22px;">&nbsp;</DIV>
<DIV ID="menu" style="position:absolute; top:-500;left:-500;">
<FORM NAME="com_list">
<TABLE BORDER=1 class="PopupCell">
<TR><TD VALIGN=TOP NOWRAP>
[<A HREF="JavaScript:void(0)" onClick="menuclose()" STYlE="text-decoration:none"><B>×</B></A>]
<A HREF='JavaScript:void(0)' onClick='menuinit(0,0,-1)' ID=PMENU0 STYlE='text-decoration:none'>우선</A> 
<A HREF='JavaScript:void(0)' onClick='menuinit(0,0,0)' ID=PMENU1 STYlE='text-decoration:none'>개</A> 
<A HREF='JavaScript:void(0)' onClick='menuinit(0,0,1)' ID=PMENU2 STYlE='text-decoration:none'>건</A> 
<A HREF='JavaScript:void(0)' onClick='menuinit(0,0,2)' ID=PMENU3 STYlE='text-decoration:none'>공</A> 
<A HREF='JavaScript:void(0)' onClick='menuinit(0,0,3)' ID=PMENU4 STYlE='text-decoration:none'>타</A>
<BR>
<span id="popupmenu">
<SELECT size="18" NAME="command_list" onChange="select_command(com_list, myForm)">
</SELECT>
</span>
</TD></TR>
<TR><TD ALIGN=CENTER>
<a href="Javascript:void(0);" onClick="menuclose()" STYlE="text-decoration:none">메뉴를 닫는다</A>
</TD></TR></TABLE></FORM></DIV>
HAKOHDOC_18
);
	}
	out(<<<HAKOHDOC_19

<DIV ID="menu2" style="position:absolute; top:-500;left:-500;">
<table border=0 class="PopupCell">
<tr><td NOWRAP><a href="Javascript:void(0);" onClick="menuclose()" class='M'>메뉴를 닫는다</A></td></tr>
<tr><td NOWRAP>$click_com4</td></tr>
</table></DIV>

<FORM NAME="mark_form">
[마킹<INPUT TYPE=CHECKBOX NAME="mark" onClick="mark_menu()">
종류
<SELECT NAME="kind_mark">
<OPTION VALUE="">표준
<OPTION VALUE="yellow">Yellow
<OPTION VALUE="red">Red
<OPTION VALUE="blue">Blue
<OPTION VALUE="purple">Purple
<OPTION VALUE="gray">Gray
<OPTION VALUE="-">None
</SELECT>
범위
<SELECT NAME="number_mark">
<OPTION VALUE="1">0HEX
<OPTION VALUE="7">1HEX
<OPTION VALUE="19" SELECTED>2HEX
<OPTION VALUE="37">3HEX
<OPTION VALUE="61">4HEX
</SELECT>]
　[<INPUT TYPE="BUTTON" VALUE="마킹 해제" onClick="unset_all_highlight();">]
</FORM>
HAKOHDOC_19
);
	$ostr = '<FONT COLOR="#0000FF">하는</FONT>(표준)';
	if ($island['custom'] & 4) { $ostr = '<FONT COLOR="#FF0000">하지 않는</FONT>'; }
	out(<<<HAKOHDOC_20
<FORM action="$HthisFile" method="POST">
<INPUT TYPE=hidden NAME=PASSWORD VALUE="{$HdefaultPasswordEsc}">
[<b>커멘드 실행 설정</b>　턴 소비하는 커멘드를 실행할 수 없어도, 예정 턴을 앞당겨 실행<B>$ostr</B>
<INPUT TYPE=submit VALUE="변경" NAME=customMButton{$Hislands[$HcurrentNumber]['id']}">]
<INPUT TYPE=hidden NAME=custom2">
</FORM>
</CENTER>
HAKOHDOC_20
);
}




/*
 * 함수: commandJavaMain()
 * 역할: Java 명령 입력 화면 전체를 출력합니다.
 * 원본 대응: hako/hako-js.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function commandJavaMain() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	
	$HcurrentNumber = $HidToNumber[$HcurrentID];
	$island =& $Hislands[$HcurrentNumber];
	$HcurrentName = $island['name'];

	
	if (!checkPassword($island['password'],$HinputPassword)) {
		
		unlock();
		tempWrongPassword();
		return;
	}

	
	$command = $island['command'];
	for ($i = 0; $i < $HcommandMax; $i++) {
		
		/* Perl/CGI 원본의 s///는 1회 치환입니다.
		 * PHP preg_replace 기본 전역 치환으로 처리하면 COMARY 전체 명령열이 한 번에 삭제되어
		 * 첫 명령만 저장되고 나머지는 자금 융통/기본값으로 바뀝니다.
		 * Java 입력 명령은 반드시 1개씩 파싱/제거해야 합니다. */
		hako_subst($HcommandComary, '~([0-9]+) ([0-9]+) ([0-9]+) ([0-9]+) ([0-9]+) ~', '', 1);
		$kindVal = intval(hako_m(1));
		$command[$i] = array(
			'kind' => ($kindVal == 0 ? $HcomDoNothing : $kindVal),
			'x' => intval(hako_m(2)),
			'y' => intval(hako_m(3)),
			'arg' => intval(hako_m(4)),
			'target' => intval(hako_m(5))
		);
	}

	
	$island['command'] = $command;
	$Hislands[$HcurrentNumber] = $island;
	if (isset($island['land']) && is_array($island['land'])) { $Hland = $island['land']; }
	if (isset($island['landValue']) && is_array($island['landValue'])) { $HlandValue = $island['landValue']; }
	if (isset($island['landOwner']) && is_array($island['landOwner'])) { $HlandOwner = $island['landOwner']; }
	writeIslandsFile($HcurrentID);
	if ($Hasync) {
		unlock();
		out("AjaxOK");
	} else {
		tempCommandAdd();
		
		ownerMain();
	}
}

?>
