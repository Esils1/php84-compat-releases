<?php

/*
 * hako/hako-map.php
 * ------------------------------------------------------------
 * 섬 화면/개발 화면/명령 화면/로컬게시판 출력 모듈
 *
 * 상세 주석 기준:
 * - 원본 대응: qwmp155.zip 의 hako-map.cgi.
 * - 관광 화면, 소유자 개발 화면, 일반 명령 입력, Java 명령 입력 보조 화면, 코멘트, 커스텀, 부대편성, 로컬게시판을 출력합니다.
 * - HTML 테이블 구조와 JavaScript 호출 인자는 CGI 원본과 화면 동일성에 직접 영향을 줍니다.
 * - 지형 표시 함수는 지도 좌표, 이미지 파일명, 지형 이름, 부대/괴수/소유권 표시를 함께 처리합니다.
 * - 로컬게시판은 DB가 아니라 island.* 내부 lbbs 배열과 파일 저장 포맷을 사용합니다.
 * - 원본 CGI 주석 라인 확인 수: 228줄. PHP 주석은 실행 결과를 바꾸지 않는 범위에서 복원/보강했습니다.
 *
 * 유지보수 원칙:
 * - 실행 로직, 저장 포맷, 배열 인덱스, 출력 HTML은 원본 CGI 호환성 대상입니다.
 * - 개조가 필요하면 먼저 해당 변수/함수가 어떤 파일 저장값과 연결되는지 확인하십시오.
 * - 이 주석은 유지보수용이며 실행 결과를 바꾸지 않습니다.
 */

chdir(dirname(__FILE__));
require_once dirname(__FILE__) . '/hako-compat.php';
if (function_exists('htmlEscape')) { $HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : ''); } else { $HdefaultPasswordEsc = isset($HdefaultPassword) ? $HdefaultPassword : ''; }














/*
 * 함수: printIslandMain()
 * 역할: 관광 모드의 섬 화면을 출력합니다.
 * 원본 대응: hako/hako-map.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function printIslandMain() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	
	unlock();

	
	$HcurrentNumber = isset($HidToNumber[$HcurrentID]) ? $HidToNumber[$HcurrentID] : null;

	
	if ((string)$HcurrentNumber === '') {
		tempProblem();
		return;
	}

	
	$HcurrentName = $Hislands[$HcurrentNumber]['name'];

	
	tempPrintIslandHead(); 
	islandInfo();	
	islandMap(0,1);	
	islandJamp();	

	
	if ($HuseLbbs) { tempLbbsInput(0); }

	
	tempRecent(0);
}





/*
 * 함수: ownerMain()
 * 역할: 소유자 개발 모드 화면을 출력합니다. 비밀번호와 쿠키 흐름이 연결됩니다.
 * 원본 대응: hako/hako-map.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function ownerMain() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	
	unlock();

	
	$HmainMode = 'owner';

	
	$HcurrentNumber = isset($HidToNumber[$HcurrentID]) ? $HidToNumber[$HcurrentID] : null;
	$island =& $Hislands[$HcurrentNumber];
	$HcurrentName = $island['name'];

	
	if (!checkPassword($island['password'],$HinputPassword)) {
		


		tempWrongPassword();
		return;
	}
	
	tempNavi();
	tempOwnerJava(); 

	if ($Hnoarmy) { tempForceInput($island); } 

	tempCommentInput($island['comment']);

	
	if ($HuseLbbs) { tempLbbsInput(1); }

	
	tempRecent(1);
}





/*
 * 함수: commandMain()
 * 역할: 일반 명령 입력/수정 화면을 출력합니다.
 * 원본 대응: hako/hako-map.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function commandMain() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	
	$HcurrentNumber = isset($HidToNumber[$HcurrentID]) ? $HidToNumber[$HcurrentID] : null;
	$island =& $Hislands[$HcurrentNumber];
	$HcurrentName = $island['name'];

	
	if (!checkPassword($island['password'],$HinputPassword)) {
		
		unlock();
		tempWrongPassword();
		return;
	}

	
	$command = (isset($island['command']) && is_array($island['command'])) ? $island['command'] : array();

	if ($HcommandMode == 'delete') {
		slideFront($command, $HcommandPlanNumber);
		tempCommandDelete();
	} elseif (($HcommandKind == $HcomAutoPrepare) ||
			($HcommandKind == $HcomAutoPrepare2)) {
		
		
		makeRandomPointArray();

		
		$kind = $HcomPrepare;
		if ($HcommandKind == $HcomAutoPrepare2) { $kind = $HcomPrepare2; }

		$i = 0;
		$j = 0;
		while (($j < $HpointNumber) && ($i < $HcommandMax)) {
			$x = $Hrpx[$j];
			$y = $Hrpy[$j];
			if ($HlandOwner[$x][$y] != $HcurrentID) {
				$j++;
				continue;
			}
			$lv = $HlandValue[$x][$y];
			if ($Hland[$x][$y] == $HlandWaste) {
				slideBack($command, $HcommandPlanNumber, $kind, 0, $x, $y, 0);
				$i++;
			}
			$j++;
		}
		tempCommandAdd();
	} elseif ($HcommandKind == $HcomAutoDelete) {
		
		unset($i); $i = null;
		for ($i = 0; $i < $HcommandMax; $i++) {
			slideFront($command, $HcommandPlanNumber);
		}
		tempCommandDelete();
	} else {
		if ($HcommandMode == 'insert') { slideBack($command, $HcommandPlanNumber, 0); }
		tempCommandAdd();
		
		$command[$HcommandPlanNumber] = array('kind'=>$HcommandKind, 'target'=>$HcommandTarget, 'x'=>$HcommandX, 'y'=>$HcommandY, 'arg'=>$HcommandArg);
	}

	$island['command'] = $command;
	$Hislands[$HcurrentNumber] = $island;
	writeIslandsFile($HcurrentID);

	
	ownerMain();

}





/*
 * 함수: customMain()
 * 역할: 섬별 커스텀 설정 화면을 출력합니다.
 * 원본 대응: hako/hako-map.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function customMain() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	
	$HcurrentNumber = isset($HidToNumber[$HcurrentID]) ? $HidToNumber[$HcurrentID] : null;
	$island =& $Hislands[$HcurrentNumber];
	$HcurrentName = $island['name'];

	
	if (!checkPassword($island['password'],$HinputPassword)) {
		
		unlock();
		tempWrongPassword();
		return;
	}

	
	unset($i); $i = null;
	for ($i = 0; $i < 3; $i++) {
		if (!empty($Hcustom[$i])) {
			$island['custom'] ^= intval(pow(2, $i));
		}
	}

	$Hislands[$HcurrentNumber] = $island;
	writeIslandsFile($HcurrentID);

	out("{$HtagBig_}설정을 갱신했던{$H_tagBig}<HR>");

	
	ownerMain();
}





/*
 * 함수: commentMain()
 * 역할: 섬 코멘트 입력 화면과 저장 흐름을 처리합니다.
 * 원본 대응: hako/hako-map.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function commentMain() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	
	$HcurrentNumber = isset($HidToNumber[$HcurrentID]) ? $HidToNumber[$HcurrentID] : null;
	$island =& $Hislands[$HcurrentNumber];
	$HcurrentName = $island['name'];

	
	if (!checkPassword($island['password'],$HinputPassword)) {
		
		unlock();
		tempWrongPassword();
		return;
	}

	
	$island['comment'] = htmlEscape($Hmessage);

	$Hislands[$HcurrentNumber] = $island;
	writeIslandsFile($HcurrentID);

	out("{$HtagBig_}코멘트를 갱신했던{$H_tagBig}<HR>");

	
	ownerMain();
}





/*
 * 함수: ragnarokMain()
 * 역할: 라그나로크 이벤트 입력 화면을 처리합니다.
 * 원본 대응: hako/hako-map.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function ragnarokMain() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	
	$HcurrentNumber = isset($HidToNumber[$HcurrentID]) ? $HidToNumber[$HcurrentID] : null;
	$island =& $Hislands[$HcurrentNumber];
	$HcurrentName = $island['name'];

	
	if (!checkPassword($island['password'],$HinputPassword)) {
		
		unlock();
		tempWrongPassword();
		return;
	}

	$HragnarokTurn = $HrTurn;

	
	writeIslandsFile($HcurrentID);

	unset($r); $r = "";
	if ($HragnarokTurn > 0) {
		$r = "라그나로크의 방문은$HragnarokTurn 턴입니다.";
	} else{
		$r = "라그나로크는 발생하지 않는다. ";
	}
	out("{$HtagBig_}{$r}{$H_tagBig}<HR>");
	logHistory("$r");

	
	ownerMain();
}




/*
 * 함수: forceMain()
 * 역할: 부대 편성/명령 화면을 출력합니다.
 * 원본 대응: hako/hako-map.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function forceMain() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	
	$HcurrentNumber = isset($HidToNumber[$HcurrentID]) ? $HidToNumber[$HcurrentID] : null;
	$island =& $Hislands[$HcurrentNumber];
	$HcurrentName = $island['name'];

	
	if (!checkPassword($island['password'],$HinputPassword)) {
		
		unlock();
		tempWrongPassword();
		return;
	}

	
	for ($_ = 0; $_ <= 3; $_++) {
		if (hako_regex('~[,\?\(\)\<\>\"\'\$]~', $ofname[$_])) {
			
			unlock();
			tempBadName();
			return;
		}
	}

	$island['fleet'] = $ofname;
	$island['color'] = $ofcolor;
	$island['direction'] = $ofdirection;
	$island['order'] = $oforder;
	$island['corps'] = $ofcorps;

	$Hislands[$HcurrentNumber] = $island;
	writeIslandsFile($HcurrentID);

	out("{$HtagBig_}군정보를 갱신했던{$H_tagBig}<HR>");

	
	ownerMain();
}





/*
 * 함수: localBbsMain()
 * 역할: 섬 로컬게시판 화면과 글쓰기/삭제 흐름을 처리합니다.
 * 원본 대응: hako/hako-map.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function localBbsMain() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	
	$HcurrentNumber = isset($HidToNumber[$HcurrentID]) ? $HidToNumber[$HcurrentID] : null;
	$island =& $Hislands[$HcurrentNumber];
	$speaker = "0<";

	
	if ((string)$HcurrentNumber === '') {
		unlock();
		tempProblem();
		return;
	}

	
	if ($HlbbsMode < 2 || $HlbbsMode == 5) {
		if (($HlbbsName == '') || ($HlbbsMessage == '')) {
			unlock();
			tempLbbsNoMessage();
			return;
		}
	}
	unset($lbbs); $lbbs = (isset($island['lbbs']) && is_array($island['lbbs'])) ? $island['lbbs'] : array();
	
	if ($HlbbsMode % 2 == 1) {
		if (!checkPassword($island['password'],$HinputPassword)) {
			
			unlock();
			tempWrongPassword();
			return;
		}
	} elseif ($HlbbsMode == 0) {
		
		unset($sIsland); $sIsland = null;
		if ($HlbbsType != 'ANON') {
			
			$sIsland = LbbsPassChk($HspeakerID);
			if ($sIsland == 0) { return; }
		}
		
		if ($HlbbsType != 'ANON') {
			
			if ($passCheck == 2) {
				$speaker = "관리인,0";
			} else{
				$speaker = $sIsland['name'] . "," . $sIsland['id'];
			}
		} else {
			
			$speaker = hako_get_env('REMOTE_HOST');
			if ($speaker == '') { $speaker = hako_get_env('REMOTE_ADDR'); }
		}
		if ($HlbbsType != 'SECRET') {
			
			$speaker = "0<$speaker";
		} else {
			
			$speaker = "1<$speaker";
		}
	} elseif ($HlbbsMode == 2 || $HlbbsMode == 4) {
		
		unset($sIsland); $sIsland = LbbsPassChk($HspeakerID);
		if ($sIsland == 0) { return; }
		if ($HlbbsMode == 2) {
			
			hako_regex('~[0-9]*\<.*,([0-9]*)\<[0-9]*\>.*\>.*$~', $lbbs[$HcommandPlanNumber]);
			unset($wId); $wId = hako_m(1);
			if ($wId != $HspeakerID) {
				
				unlock();
				tempWrong("당신의 발언이 아닙니다!");
				return;
			}
		}
	}

	
	if ($HlbbsMode == 4) {
		printIslandMain();
		return;
	} elseif ($HlbbsMode == 2 || $HlbbsMode == 3 || $HlbbsMode == 7) {
		
		
		slideBackLbbsMessage($lbbs, $HcommandPlanNumber);
		tempLbbsDelete();
	} else {
		
		
		slideLbbsMessage($lbbs);

		
		unset($message); $message = null;
		if ($HlbbsMode == 0) {
			$message = '0';
		} else {
			$message = '1';
		}
		$HlbbsName = "$HislandTurn │ " . htmlEscape($HlbbsName);
		$HlbbsMessage = htmlEscape($HlbbsMessage);
		$lbbs[0] = "$speaker<$message>$HlbbsName>$HlbbsMessage";
		tempLbbsAdd();
	}

	$island['lbbs'] = $lbbs;
	$Hislands[$HcurrentNumber] = $island;
	writeIslandsFile($HcurrentID);

	if ($HlbbsMode2 == 'lbbslist') {
		
		$HlbbsMode2 = 0;
		out("<meta HTTP-EQUIV=\"refresh\" CONTENT=\"0; URL=$HbaseDir/lbbslist.php?pass=$HdefaultPassword&id=$HspeakerID\#$HcurrentID\">");
		return;
	}
	
	if ($HlbbsMode % 2 == 0) {
		printIslandMain();
	} else {
		ownerMain();
	}
}


/*
 * 함수: LbbsPassChk()
 * 역할: 로컬게시판 삭제/관리 비밀번호를 확인합니다.
 * 원본 대응: hako/hako-map.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function LbbsPassChk() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	
	$id = isset($_args[0]) ? $_args[0] : null;
	$number = isset($HidToNumber[$id]) ? $HidToNumber[$id] : '';

	
	if ((string)$number === '' || !isset($Hislands[$number])) {
		unlock();
		tempProblem();
		return 0;
	}

	
	$sIsland =& $Hislands[$number];
	$passCheck = checkPassword($sIsland['password'],$HinputPassword);
	if ($passCheck == 0) {
		unlock();
		tempWrongPassword();
		return 0;
	}
	return $sIsland;
}


/*
 * 함수: slideLbbsMessage()
 * 역할: 로컬게시판 글을 뒤로 밀어 새 글 삽입 공간을 만듭니다.
 * 원본 대응: hako/hako-map.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function slideLbbsMessage(&$lbbs) {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	if (!is_array($lbbs)) { $lbbs = array(); }
	for ($__i = 0; $__i < $HlbbsMax; $__i++) { if (!isset($lbbs[$__i])) { $lbbs[$__i] = '0<<0>>'; } }
	array_pop($lbbs);
	array_unshift($lbbs, isset($lbbs[0]) ? $lbbs[0] : '0<<0>>');
}


/*
 * 함수: slideBackLbbsMessage()
 * 역할: 로컬게시판 글 삭제 후 뒤 글을 앞으로 당깁니다.
 * 원본 대응: hako/hako-map.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function slideBackLbbsMessage(&$lbbs, $number) {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	if (!is_array($lbbs)) { $lbbs = array(); }
	for ($__i = 0; $__i < $HlbbsMax; $__i++) { if (!isset($lbbs[$__i])) { $lbbs[$__i] = '0<<0>>'; } }
	hako_splice($lbbs, $number, 1);
	$lbbs[$HlbbsMax - 1] = '0<<0>>';
}






/*
 * 함수: islandInfo()
 * 역할: 섬의 기본 정보, 자원, 외교, 진영, 통계 표시를 출력합니다.
 * 원본 대응: hako/hako-map.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function islandInfo() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	$island =& $Hislands[$HcurrentNumber];
	
	$rank = $HcurrentNumber + 1;
	$CellCt = 7;
	$farm = $island['farm'];
	$factory = $island['factory'];
	$mountain = $island['mountain'];
	$jobpop = $farm + $factory + $mountain;
	$farm = ($farm == 0) ? "보유 안함" : "{$farm}0$HunitPop";
	$factory = ($factory == 0) ? "보유 안함" : "{$factory}0$HunitPop";
	$mountain = ($mountain == 0) ? "보유 안함" : "{$mountain}0$HunitPop";
	$jobpop = ($jobpop == 0) ? "보유 안함" : "{$jobpop}0$HunitPop";

	$_list_tmp = array('','','','');
	unset($StrTH1); $StrTH1 = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
	unset($StrTD1); $StrTD1 = isset($_list_tmp[1]) ? $_list_tmp[1] : null;
	unset($StrTH2); $StrTH2 = isset($_list_tmp[2]) ? $_list_tmp[2] : null;
	unset($StrTD2); $StrTD2 = isset($_list_tmp[3]) ? $_list_tmp[3] : null;
	if (($HhideMoneyMode == 1) || ($HmainMode == 'owner')) {
		
		if ($Hnoarmy) {
			
			unset($mp); $mp = (isset($island['mpower']) && is_array($island['mpower'])) ? $island['mpower'] : array();
			unset($allpop); $allpop = 0;
			for ($_ = 0; $_ <= hako_last_index($Fdivision); $_++) {
				if (isset($mp[$_]) && $mp[$_] > 0) {
					$allpop += $mp[$_];
				}
			}
			if ($allpop > 0) {
				$CellCt++;
				$StrTH1 .= "<TH $HbgTitleCell nowrap=nowrap><NOBR>{$HtagTH_}배치 병력{$H_tagTH}</NOBR></TH>";
				$StrTD1 .= "<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$allpop$HunitPop</NOBR></TD>";
			}
			if ($island['soldier'] > 0) {
				$CellCt++;
				$StrTH1 .= "<TH $HbgTitleCell nowrap=nowrap><NOBR>{$HtagTH_}예비병(EX){$H_tagTH}</NOBR></TH>";
				$StrTD1 .= "<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>{$island['soldier']}[$HunitPop]({$island['soldierex']})</NOBR></TD>";
				$allpop += $island['soldier'];
			}
			if ($island['soldierF'] > 0) {
				$CellCt++;
				$StrTH1 .= "<TH $HbgTitleCell nowrap=nowrap><NOBR>{$HtagTH_}부상병{$H_tagTH}</NOBR></TH>";
				$StrTD1 .= "<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>{$island['soldierF']}[$HunitPop]</NOBR></TD>";
				$allpop += $island['soldierF'];
			}
			if ($allpop > 0) {
				$CellCt++;
				$allpop += $island['pop'];
				$allpop = intval($allpop * $HeatenFood);
				$StrTH1 .= "<TH $HbgTitleCell nowrap=nowrap><NOBR>{$HtagTH_}식량 소비{$H_tagTH}</NOBR></TH>";
				$StrTD1 .= "<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$allpop$HunitFood</NOBR></TD>";
			}
		}
		$CellCt++;
		$StrTH2 = "<TH $HbgTitleCell nowrap=nowrap><NOBR>{$HtagTH_}자금{$H_tagTH}</NOBR></TH>";
		$StrTD2 = "<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>{$island['money']}$HunitMoney</NOBR></TD>";
	} elseif ($HhideMoneyMode == 2) {
		
		$CellCt++;
		$mTmp = aboutMoney($island['money']);
		$StrTH2 = "<TH $HbgTitleCell nowrap=nowrap><NOBR>{$HtagTH_}자금{$H_tagTH}</NOBR></TH>";
		$StrTD2 = "<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$mTmp</NOBR></TD>";
	}

	unset($remainTime); $remainTime = null;
	unset($rtStr); $rtStr = null;
	$remainTime = $HunitTime - time() + $HislandLastTime;
	$rtStr = "다음의 갱신 시간까지";
	$rtStr .= intval($remainTime / 3600) . "시간";
	$rtStr .= intval(($remainTime % 3600) / 60) . "분";
	$rtStr .= $remainTime % 60 . "초";

	out("<CENTER>{$HtagHeader_}턴{$HislandTurn}{$H_tagHeader}($rtStr)<BR>");
	if (($HislandTurn > 50) && ($HislandNumber <= 3) && ($rank == 1) && ($HragnarokTurn == 0) && ($Hragnarok > 0)) {
		
		unset($rt); $rt = $HislandTurn;
	out(<<<HAKOHDOC_0
<SCRIPT LANGUAGE="JavaScript">
<!--
function RagnarokButton(){
	var r = confirm("결정 버튼을 클릭하면 두 번 다시 변경할 수 없습니다만, 좋습니까?");
	if(r == true) document.RAGNAROKFORM.submit();
}
//-->
</SCRIPT>
<FORM name="RAGNAROKFORM" action="$HthisFile" method="POST">
<INPUT TYPE="hidden" VALUE="{$HdefaultPasswordEsc}" NAME="PASSWORD">
<INPUT TYPE="hidden" VALUE="{$Hislands[$HcurrentNumber]['id']}" NAME="RagnarokID">
<A href=\"{$efileDir}/setup.html\" TARGET=_blank>라그나로크</a>가 방문하는 턴을 설정할 수 있습니다.
HAKOHDOC_0
);
		out("<SELECT NAME=RagnarokTurn>");
		out("<OPTION VALUE=-1>발생시키지 않는\n");
		for ($i = $HislandTurn + 6; $i < $HislandTurn + 50; $i++) {
			out("<OPTION VALUE=$i>{$ii}턴에 발생\n");
		}
		out("</SELECT>");
		out("<INPUT TYPE=button VALUE='결정' onClick='RagnarokButton()'></FORM>");
	}
	out(<<<HAKOHDOC_1
<TABLE BORDER>
<TR>
<TH $HbgTitleCell nowrap=nowrap><NOBR>{$HtagTH_}순위{$H_tagTH}</NOBR></TH>
<TH $HbgTitleCell nowrap=nowrap><NOBR>{$HtagTH_}인구{$H_tagTH}</NOBR></TH>
$StrTH1
$StrTH2
<TH $HbgTitleCell nowrap=nowrap><NOBR>{$HtagTH_}식량{$H_tagTH}</NOBR></TH>
<TH $HbgTitleCell nowrap=nowrap><NOBR>{$HtagTH_}면적{$H_tagTH}</NOBR></TH>
<TH $HbgTitleCell nowrap=nowrap><NOBR>{$HtagTH_}총직장수{$H_tagTH}</NOBR></TH>
<TH $HbgTitleCell nowrap=nowrap><NOBR>{$HtagTH_}농장 규모{$H_tagTH}</NOBR></TH>
<TH $HbgTitleCell nowrap=nowrap><NOBR>{$HtagTH_}공장 규모{$H_tagTH}</NOBR></TH>
<TH $HbgTitleCell nowrap=nowrap><NOBR>{$HtagTH_}채굴장 규모{$H_tagTH}</NOBR></TH>
</TR>
<TR>
<TD $HbgNumberCell align=middle nowrap=nowrap><NOBR>{$HtagNumber_}{$rank}{$H_tagNumber}</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>{$island['pop']}$HunitPop</NOBR></TD>
$StrTD1
$StrTD2
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>{$island['food']}$HunitFood</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>{$island['area']}$HunitArea</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>{$jobpop}</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>{$farm}</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>{$factory}</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>{$mountain}</NOBR></TD>
</TR>
<TR>

HAKOHDOC_1
);
	if ($HmainMode == 'owner') {
		out("<TH $HbgTitleCell><SPAN onMouseOver=\"TakokuYuSe('TakokuYU'); return true;\" onMouseOut=\"menuclose();\">{$HtagTH_}우호국{$H_tagTH}</SPAN></TH><TD colspan=$CellCt class='C'>");
	} else{
		out("<TH $HbgTitleCell>{$HtagTH_}우호국{$H_tagTH}</TH><TD colspan=$CellCt class='C'>");
	}
	unset($amiName); $amiName = null;
	unset($takokuyu); $takokuyu = null;
	for ($i=0;$i < hako_last_index($HamityIsland);$i+=4) {
		unset($id1); $id1 = null;
		unset($id2); $id2 = null;
		unset($name1); $name1 = null;
		unset($name2); $name2 = null;
		unset($str); $str = null;
		$tn1 = isset($HidToNumber[$HamityIsland[$i+1]]) ? $HidToNumber[$HamityIsland[$i+1]] : '';
		if (($tn1 === '' || $tn1 === null)) { continue; }
		$tn2 = isset($HidToNumber[$HamityIsland[$i+2]]) ? $HidToNumber[$HamityIsland[$i+2]] : '';
		if (($tn2 === '' || $tn2 === null)) { continue; }
		$id1 = $Hislands[$tn1]['id'];
		$id2 = $Hislands[$tn2]['id'];
		$name1 = $Hislands[$tn1]['name'];
		$name2 = $Hislands[$tn2]['name'];
		if ($HmainMode == 'owner') { $str = "($HamityIsland[$i])"; }
		if ($island['id'] == $id1) {
			if ($HamityIsland[$i+3] == 0) {
				if ($HmainMode != 'owner') { continue; }
				$str .= "우호 타진중";
			}
			$amiName .= "<A STYlE=\"text-decoration:none\" href=\"{$HthisFile}?Sight={$id2}\" target=\"_blank\">{$name2}</A>$str ";
		} elseif ($island['id'] == $id2) {

			if ($HamityIsland[$i+3] == 0) {
				if ($HmainMode != 'owner') { continue; }
	$amiName .= <<<HAKOHDOC_2
<FORM name="KAHIFORM" action="$HthisFile" method="POST">
<A STYlE="text-decoration:none" href="{$HthisFile}?Sight={$id1}" target="_blank">{$name1}</A>$str
<INPUT TYPE="hidden" VALUE="0" NAME="NUMBER">
<INPUT TYPE="hidden" VALUE="$HcomAmity" NAME="COMMAND">
<INPUT TYPE="hidden" VALUE="$id1" NAME="TARGETID">
<INPUT TYPE="hidden" VALUE="insert" NAME=COMMANDMODE>
<INPUT TYPE="hidden" VALUE="{$HdefaultPasswordEsc}" NAME="PASSWORD">
우호 타진을 받고 있습니다<SELECT NAME=AMOUNT><OPTION VALUE=1003>수락<OPTION VALUE=1002>거부</SELECT>
<INPUT TYPE="submit" VALUE="커멘드의 1번째에 삽입" NAME="CommandButton{$Hislands[$HcurrentNumber]['id']}"></FORM>
HAKOHDOC_2
;
			} else{
				$amiName .= "<A STYlE=\"text-decoration:none\" href=\"{$HthisFile}?Sight={$id1}\" target=\"_blank\">{$name1}</A>$str ";
			}
		} elseif ($HamityIsland[$i+3] == 3) {
			$takokuyu .= "·{$name1} 와 {$name2}<BR>";
		}
	}
	if (!(isset($amiName))) { out("　"); }
	out($amiName);
	if (!(isset($takokuyu))) { $takokuyu = "존재하지 않는"; }
	out("\n<DIV ID='TakokuYU' style='position:absolute; top:-500;left:-500;background-color: #EEFFFF;border:outset #CCCCFF 1px;'><H3>타국 우호국 정보</H3>$takokuyu</DIV>");
	out("</TD></TR><TR>");
	$CellCt--;
	if ($HmainMode == 'owner') {
		out("<TH $HbgTitleCell><SPAN onMouseOver=\"TakokuYuSe('TakokuSE'); return true;\" onMouseOut=\"menuclose();\">{$HtagTH_}교전국{$H_tagTH}</SPAN></TH><TD colspan=$CellCt class='C'>");
	} else{
		out("<TH $HbgTitleCell>{$HtagTH_}교전국{$H_tagTH}</TH><TD colspan=$CellCt class='C'>");
	}
	unset($warName); $warName = null;
	unset($takokuse); $takokuse = null;
	unset($warP); $warP = null;
	unset($warC); $warC = null;
	$warS = "　";
	if (($HragnarokTurn > 0) && ($HragnarokTurn <= $HislandTurn + 10)) {
		$warName = "모두($HragnarokTurn)";
	}
	for ($i=0;$i < hako_last_index($HwarIsland);$i+=4) {
		unset($id1); $id1 = null;
		unset($id2); $id2 = null;
		unset($name1); $name1 = null;
		unset($name2); $name2 = null;
		$tn1 = isset($HidToNumber[$HwarIsland[$i+1]]) ? $HidToNumber[$HwarIsland[$i+1]] : '';
		if (($tn1 === '' || $tn1 === null)) { continue; }
		$tn2 = isset($HidToNumber[$HwarIsland[$i+2]]) ? $HidToNumber[$HwarIsland[$i+2]] : '';
		if (($tn2 === '' || $tn2 === null)) { continue; }
		$id1 = $Hislands[$tn1]['id'];
		$id2 = $Hislands[$tn2]['id'];
		$name1 = $Hislands[$tn1]['name'];
		$name2 = $Hislands[$tn2]['name'];
		unset($s); $s = '공';
		if ($island['id'] == $id1) {
			if ($HwarIsland[$i+3] == 1) {
				$s = '공→방';
				$warC++;
				$warP += $Hislands[$tn2]['score'];
			}
			$warName .= "<A STYlE=\"text-decoration:none\" href=\"{$HthisFile}?Sight={$id2}\" target=\"_blank\">{$name2}</A>($HwarIsland[$i]$s) ";
		} elseif ($island['id'] == $id2) {
			if ($HwarIsland[$i+3] == 1) {
				$s = '방→공';
			} else{
				$s = '방';
				$warC++;
				$warP += $Hislands[$tn1]['score'];
			}
			$warName .= "<A STYlE=\"text-decoration:none\" href=\"{$HthisFile}?Sight={$id1}\" target=\"_blank\">{$name1}</A>($HwarIsland[$i]$s) ";
		} else{
			if ($HwarIsland[$i+3] == 1) {
				$takokuse .= "·{$name1}(정) ← {$name2}(공)<BR>";
			} elseif ($HwarIsland[$i+3] == 2) {
				$takokuse .= "·{$name1}(공) → {$name2}(정)<BR>";
			} else{
				$takokuse .= "·{$name1}(공) → {$name2}(방)<BR>";
			}
		}
	}
	if ($island['score'] > 0) {
		$warS = sprintf("%.2f",$warP / $island['score']);
		if ($warC < 2) { $warP = 0; }
		if ($warP > $island['score'] * 2) {
			$warS = "핸디캡 A($warS)";
		} elseif ($warP >= $island['score'] * 1.5) {
			$warS = "핸디캡 B($warS)";
		} elseif ($warP > $island['score']) {
			$warS = "핸디캡 C($warS)";
		} else{
			$warS = "봐주기 없기($warS)";
		}
	}
	if (!(isset($warName))) { $warName = "　"; }
	out($warName);
	if (!(isset($takokuse))) { $takokuse = "존재하지 않는"; }
	out("\n<DIV ID='TakokuSE' style='position:absolute; top:-500;left:-500;background-color: #EEFFFF;border:outset #CCCCFF 1px;'><H3>타국 교전국 정보</H3>$takokuse</DIV>");
	out(<<<HAKOHDOC_3
</TD><SPAN onMouseOver="handicap(); return true;"><TD $HbgInfoCell align=right nowrap=nowrap>$warS
</TD></SPAN></TR>
</TABLE>

HAKOHDOC_3
);
	if ((($HislandTurn - $island['kaisi']) <= $Hatkturn) && ($island['kaisi'] < 99999)) {
		$at = $Hatkturn - ($HislandTurn - $island['kaisi']);
		if ($at == 1) {
			out("나라 발견해 얼마 되지 않기 때문에 외교 명령의 제한이 걸려 있습니다. 나머지<B>{$at}턴</B>. (다음의 턴 갱신에서는 할 수 없습니다)<BR>");
		} elseif ($at == 0) {
			out("선전포고나 우호 타진등의 외교 명령을 실행할 수 있게 되었습니다!");
		} else{
			out("나라 발견해 얼마 되지 않기 때문에 외교 명령의 제한이 걸려 있습니다. 나머지<B>{$at}턴</B>。<BR>");
		}
	}
	for ($i = 0; $i < $HislandNumber; $i++) {
		unset($island2); $island2 = null;
		unset($id2); $id2 = null;
		unset($name); $name = null;
		unset($pop); $pop = null;
		unset($area); $area = null;
		unset($money); $money = null;
		unset($food); $food = null;
		unset($weapon); $weapon = null;
		$island2 = $Hislands[$i];
		$id2 = $island2['id'];
		out("<DIV ID='Takoku{$id2}' style='display:none;visibility:hidden;'><TABLE BORDER>\n");
		out("<TH $HbgTitleCell nowrap=nowrap>{$HtagTH_}타국 정보{$H_tagTH}</TH><TD $HbgInfoCell align=right nowrap=nowrap>{$island2['name']}</TD>\n");
		out("<TH $HbgTitleCell nowrap=nowrap>{$HtagTH_}인구{$H_tagTH}</TH><TD $HbgInfoCell align=right nowrap=nowrap>{$island2['pop']}$HunitPop</TD>\n");
		if ($Hnoarmy) {
			
			$mp = (isset($island2['mpower']) && is_array($island2['mpower'])) ? $island2['mpower'] : array();
			unset($allpop); $allpop = 0;
			for ($_ = 0; $_ <= hako_last_index($Fdivision); $_++) {
				if (isset($mp[$_]) && $mp[$_] > 0) { $allpop += $mp[$_]; }
			}
			if ($island2['soldier'] > 0) { $allpop += $island2['soldier']; }
			$allpop = ($allpop > 0) ? "$allpop$HunitPop" : "보유 안함";
			out("<TH $HbgTitleCell nowrap=nowrap>{$HtagTH_}총병력{$H_tagTH}</TH><TD $HbgInfoCell align=right nowrap=nowrap>$allpop</TD>\n");
		}
		out("<TH $HbgTitleCell nowrap=nowrap>{$HtagTH_}면적{$H_tagTH}</TH><TD $HbgInfoCell align=right nowrap=nowrap>{$island2['area']}$HunitArea</TD>\n");
		unset($mStr1); $mStr1 = ($HhideMoneyMode == 1) ? "{$island2['money']}$HunitMoney" : aboutMoney($island2['money']);
		out("<TH $HbgTitleCell nowrap=nowrap>{$HtagTH_}자금{$H_tagTH}</TH><TD $HbgInfoCell align=right nowrap=nowrap>$mStr1</TD>\n");
		out("<TH $HbgTitleCell nowrap=nowrap>{$HtagTH_}식량{$H_tagTH}</TH><TD $HbgInfoCell align=right nowrap=nowrap>{$island2['food']}$HunitFood</TD>\n");
		unset($farm2); $farm2 = ($island2['farm'] == 0) ? "보유 안함" : "{$island2['farm']}0$HunitPop";
		out("<TH $HbgTitleCell nowrap=nowrap>{$HtagTH_}농장 규모{$H_tagTH}</TH><TD $HbgInfoCell align=right nowrap=nowrap>$farm2</TD>\n");
		out("</TR></TABLE></DIV>\n");
	}
	out("<DIV id=TakokuText></DIV></CENTER>");
}



/*
 * 함수: islandMap()
 * 역할: 섬 지도 전체를 HTML 테이블/이미지로 출력합니다.
 * 원본 대응: hako/hako-map.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function islandMap() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	unset($js); $js = isset($_args[0]) ? $_args[0] : null;
	unset($wide); $wide = isset($_args[1]) ? $_args[1] : null;
	unset($island); $island = null;
	tempNavi();
	$island =& $Hislands[$HcurrentNumber];

	
	$a = array('b','b','c','c','b','b','d','d','c','c','d','d');
	$c = 0;

	out("<CENTER><TABLE BORDER><TR><TD>");
	if ($js == 0) { out('<SCRIPT language="JavaScript">function ps(x, y, id){}</SCRIPT>'); }

	
	$command = (isset($island['command']) && is_array($island['command'])) ? $island['command'] : array();
	unset($com); $com = null;
	unset($comStr); $comStr = array();
	unset($i); $i = null;
	if ($HmainMode == 'owner') {
		for ($i = 0; $i < $HcommandMax; $i++) {
			$j = $i + 1;
			$com = $command[$i];
			$__kind = isset($com['kind']) ? intval($com['kind']) : 0;
			if ($__kind < 24) {
					if (!isset($comStr[$com['x']][$com['y']])) { $comStr[$com['x']][$com['y']] = ''; }
				$comStr[$com['x']][$com['y']] .= " [{$j}]" . (isset($HcomName[$__kind]) ? $HcomName[$__kind] : '');
			}
		}
	}

	if (!($Hroundmode) || ($Hcolormap) || ($island['custom'] & 1)) { $wide = 0; } 
	if ($island['custom'] & 2) {
		
		$mirange = 1;
		SearchBase($island['id']);
	}

	unset($x); $x = null;
	unset($y); $y = null;
	unset($xy); $xy = array();
	unset($alpha); $alpha = null;
	unset($ay); $ay = null;
	
	unset($widthsize); $widthsize = $HislandSize * 32 + 16;
	if ($wide) {
		$widthsize += 64;
		out("<IMG SRC=\"nu/xbarw.gif\" width=$widthsize height=16><BR>");
		$xy = array(19,0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,0);
	} else{
		out("<IMG SRC=\"nu/xbar.gif\" width=$widthsize height=16><BR>");
		$xy = array(0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19);
	}
	
	foreach ($xy as $y) {
		if (($wide) && ($ay == 0 || $ay == hako_last_index($xy))) {
			$alpha = " STYLE=\"filter: Alpha(opacity=40)\"";
		} else{
			$alpha = "";
		}
		$ay++;
		out("<NOBR>");
		
		if (($y % 2) == 0) { out("<IMG SRC=\"nu/space{$y}.gif\" width=16 height=32>"); }
		
		if ($wide) {
			for ($x = $HislandSize - 1; $x < $HislandSize; $x++) {
					mapString($island, $x, $y, $js, (isset($comStr[$x][$y]) ? $comStr[$x][$y] : ''), " STYLE=\"filter: Alpha(opacity=40)\"");
			}
		}
		for ($x = 0; $x < $HislandSize; $x++) {
			mapString($island, $x, $y, $js, (isset($comStr[$x][$y]) ? $comStr[$x][$y] : ''), $alpha);
		}
		if ($wide) {
			for ($x = 0; $x < 1; $x++) {
					mapString($island, $x, $y, $js, (isset($comStr[$x][$y]) ? $comStr[$x][$y] : ''), " STYLE=\"filter: Alpha(opacity=40)\"");
			}
		}
		
		if (($y % 2) == 1) { out("<IMG SRC=\"nu/space{$y}.gif\" width=16 height=32>"); }
		out("</NOBR><BR>");
	}
	out("<div id='NaviView'></div></TD></TR></TABLE></CENTER>\n");
}


/*
 * 함수: SearchBase()
 * 역할: 미사일/부대 관련 기지 탐색을 수행합니다.
 * 원본 대응: hako/hako-map.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function SearchBase() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	unset($id); $id = isset($_args[0]) ? $_args[0] : null;
	
	unset($x); $x = null;
	unset($y); $y = null;
	unset($bx); $bx = null;
	unset($by); $by = null;
	unset($i); $i = null;
	unset($baseflg); $baseflg = array();
	unset($distance); $distance = null;

	for ($i = 0; $i < $HpointNumber; $i++) {
		$x = intval($i / $HislandSize);
		$y = $i % $HislandSize;
		if (($id == $HlandOwner[$x][$y]) &&
			(($Hland[$x][$y] == $HlandBase) ||
			($Hland[$x][$y] == $HlandSbase))) {
			hako_push($baseflg, $i);
		}
	}
	if (hako_last_index($baseflg) < 0) { return; }
	
	for ($y = 0; $y < $HislandSize; $y++) {
		for ($x = 0; $x < $HislandSize; $x++) {
			foreach ($baseflg as $_) {
				$bx = intval($_ / $HislandSize);
				$by = $_ % $HislandSize;
				
				$_list_tmp = array(abs($bx - $x), abs($by - $y));
				unset($dx); $dx = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
				unset($dy); $dy = isset($_list_tmp[1]) ? $_list_tmp[1] : null;
				$rl = 0;
				if ($x > $bx) {
					
					$rl = 1;
				} elseif ($x < $bx) {
					
					$rl = -1;
				}
				if ($Hroundmode) {
					if ($dx > intval($HislandSize / 2)) {
						$rl = -$rl;
						$dx = $HislandSize - $dx;
					}
					if ($dy > intval($HislandSize / 2)) { $dy = $HislandSize - $dy; }
				}
				$distance = $dx + $dy;
				$distance -= ($dx >= ($dy / 2)) ? intval($dy / 2) : $dx;

				if (!($by % 2) && ($y % 2)) {
					
					if ($rl == 1) { $distance--; }
				} elseif (!($y % 2) && ($by % 2)) {
					
					if ($rl == -1) { $distance--; }
				}
				
				$baseLevel = expToLevel($Hland[$bx][$by], $HlandValue[$bx][$by]);
				if ($Hland[$bx][$by] == $HlandSbase) {
					$baseLevel += $HmissileRangeS;
				} else{
					$baseLevel += $HmissileRange;
				}

				$_list_tmp = expToLevel2($Hland[$bx][$by], $HlandValue[$bx][$by]); 
				unset($level); $level = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
				if ($baseLevel > $distance) { $base[$x][$y] += $level; }
			}
		}
	}
}



/*
 * 함수: mapString()
 * 역할: 지도 한 칸의 이미지/링크/툴팁 문자열을 생성합니다.
 * 원본 대응: hako/hako-map.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function mapString($island, $x, $y, $js, $comStr, $alpha) {
	// 지도 1칸마다 호출되는 고빈도 함수입니다.
	// 전체 $GLOBALS 순회는 PHP 5.5 공유호스팅에서 지도를 매우 느리게 만들므로, 실제로 필요한 전역값만 명시합니다.
	global $Hland, $HlandValue, $HlandOwner, $HidToName, $HlandSbase, $Hdebug, $HlandDivNa;
	global $HlandDivPw, $Hroundmode, $ax, $ay, $correct, $HislandSize, $HlandDiv, $FsearchR;
	global $HlandSupply, $HlandMountain, $mirange, $base;
	unset($l); $l = null;
	unset($lv); $lv = null;
	unset($id); $id = null;
	unset($ow); $ow = null;
	unset($ows); $ows = null;
	unset($color); $color = null;
	unset($mode); $mode = null;
	unset($cur); $cur = null;
	unset($HGr); $HGr = null;
	unset($Div); $Div = null;
	unset($DivPw); $DivPw = null;
	unset($DivEx); $DivEx = null;
	unset($DivNa); $DivNa = null;
	unset($disp); $disp = null;
	unset($missile); $missile = null;
	unset($ofname); $ofname = null;
	unset($ofcorps); $ofcorps = null;
	unset($DivItem); $DivItem = null;
	unset($DivLv); $DivLv = null;
	$l = $Hland[$x][$y];
	$lv = $HlandValue[$x][$y];
	$id = $island['id'];
	$ow  = $HlandOwner[$x][$y];
	$ows = "[" . (isset($HidToName[$ow]) ? $HidToName[$ow] : '') . "]";
		$color = (isset($island['color']) && is_array($island['color'])) ? $island['color'] : array();
	if ($js == 0) {
		
		$mode = 0;
		if ($id == $ow) {
			
			if ($l == $HlandSbase) {
				
				$cur = 'nu';
				$ows = "[$HidToName[0]]";
			} else {
				$cur = 'cu';
			}
		} else {
			
			if ($l == $HlandSbase) {
				
				$ows = "[$HidToName[0]]";
			}
			$cur = 'nu';
		}
		if ($Hdebug == 2) {
			$ofname = $island['fleet'];
			$ofcorps = $island['corps'];
			$HGr  = $island['HGr'];
			$Div  = $island['Div'];
			$DivPw = $island['DivPw'];
			$DivEx = $island['DivEx'];
			$DivNa = $island['DivNa'];
			$DivItem = $island['DivItem'];
			if ($id != $HlandDivNa[$x][$y]) {
				$color = array('red', 'red', 'red', 'red','red', 'red', 'red', 'red');
			}
		}
	} else {
		
		if ($id == $ow) {
			
			$mode = 1;
			$cur = 'cu';
			$ofname = $island['fleet'];
			$ofcorps = $island['corps'];
		} else{
			
			$mode = 0;
			if ($l == $HlandSbase) {
				
				$ows = "[$HidToName[0]]";
			}
			$cur = 'nu';
		}
		$DivPw = 0;
		if ($mirange) {
			if ($base[$x][$y]) { $missile = $base[$x][$y]; }
		}
		if ($HlandDivPw[$x][$y] > 0) {
			$disp = 0;
			$sflg = array(1,7,19,37);
			for ($_ = 1; $_ <= 36; $_++) {
				
				$_list_tmp = array($x + $ax[$_],$y + $ay[$_]);
				unset($sx); $sx = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
				unset($sy); $sy = isset($_list_tmp[1]) ? $_list_tmp[1] : null;
				if (!($sy % 2) && ($y % 2)) { $sx--; }
				if ($Hroundmode) {
					$sx = $correct[$sx + 12];
					$sy = $correct[$sy + 12];
				}
				if (($sx < 0) || ($sx >= $HislandSize) || ($sy < 0) || ($sy >= $HislandSize)) { continue; }
					if ((($_ < $sflg[$FsearchR[$HlandDiv[$sx][$sy]]]) && ($HlandDivNa[$sx][$sy] == $id) && ($HlandDivPw[$sx][$sy] > 0)) ||
						(($_ < 19) && ($HlandOwner[$sx][$sy] == $id) && ($Hland[$sx][$sy] == $HlandSupply)) ||
						(($_ < 19) && ($HlandOwner[$sx][$sy] == $id) && ($Hland[$sx][$sy] == $HlandMountain))) {
					
					$disp = 1;
					break;
				}
			}
			if (($id == $HlandDivNa[$x][$y]) || ($id == $ow) || ($disp) || ($Hdebug == 2)) {
				$HGr  = $island['HGr'];
				$Div  = $island['Div'];
				$DivPw = $island['DivPw'];
				$DivLv = $island['DivLv'];
				$DivEx = $island['DivEx'];
				$DivNa = $island['DivNa'];
				$DivItem = $island['DivItem'];
				if ($id != $HlandDivNa[$x][$y]) {
					$color = array('red', 'red', 'red', 'red','red', 'red', 'red', 'red');
				}
			} else{
				$DivPw = 0;
			}
		}
	}
	landString($l, $lv, $ows, $cur, $x, $y, $mode, $js, $comStr, $ofname, $HGr, $Div, $DivPw, $DivLv, $DivEx, $DivNa, $color, $alpha, $missile, $id, $ofcorps, $DivItem);
}
/*
 * 함수: landString()
 * 역할: 지형 한 칸의 표시 문자열을 생성합니다.
 * 원본 대응: hako/hako-map.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function landString($l, $lv, $ow, $cur, $x, $y, $mode, $js, $comStr = null, $ofname = null, $HGr = null, $Div = null, $DivPw = null, $DivLv = null, $DivEx = null, $DivNa = null, $color = null, $alpha = null, $missile = null, $pId = null, $ofcorps = null, $DivItem = null) {
	// 지도 1칸의 지형명/이미지/마우스 설명을 만드는 고빈도 함수입니다.
	// 원본 출력은 유지하되 전체 전역변수 순회를 제거해 PHP 5.5 서버에서 지도 출력 지연을 줄입니다.
	global $HidToName, $HidToNumber, $Hislands, $Fdirection, $Fdivision, $FItemName;
	global $HlandSea, $HlandWaste, $HlandPlains, $HlandForest, $HlandTown, $HlandFarm, $HlandFactory;
	global $HlandBase, $HlandSbase, $HlandDefence, $HlandSupply, $HlandMountain, $HlandMonument, $HlandMonster;
	global $HunitTree, $HunitPop, $HmissileRange, $HmissileRangeS, $HmonumentImage, $HmonumentName;
	global $HmonsterSpecial, $HmonsterImage, $HmonsterImage2, $HislandTurn, $HdebugR, $HlandResist;
	global $HlandOwner, $HmainMode, $Hcolormap, $a, $c;
	$point = "($x, $y)";
	unset($image); $image = null;
	unset($alt); $alt = null;
	unset($soldier); $soldier = null;
	$imagesize = ($js > 7) ? $js : 32;
	unset($naviTitle); $naviTitle = null;
	unset($naviText); $naviText = null;
	unset($s); $s = '';

	if (is_array($DivPw) && isset($DivPw[$x]) && is_array($DivPw[$x]) && isset($DivPw[$x][$y]) && $DivPw[$x][$y] > 0) {
		$HGrname = isset($HidToName[$DivNa[$x][$y]]) ? $HidToName[$DivNa[$x][$y]] : '';
		$tn = isset($HidToNumber[$DivNa[$x][$y]]) ? $HidToNumber[$DivNa[$x][$y]] : '';
		if (($tn !== '' && $tn !== null)) {
			$tIsland =& $Hislands[$tn];
			$tOfname = $tIsland['fleet'];
			$direction = "";
			if ($pId > 0 && $pId == $DivNa[$x][$y]) {
				$direction = "(" . $Fdirection[$tIsland['direction'][$HGr[$x][$y] - 1]] . ")";
			}
			$level = $DivLv[$x][$y] + 1;
			$soldier = "【$HGrname " . $tOfname[$HGr[$x][$y] - 1] . $direction . " " . $Fdivision[$Div[$x][$y]] . " " . $DivPw[$x][$y] . "{$HunitPop} Lv{$level}(" . $DivEx[$x][$y] . ")" . $FItemName[$DivItem[$x][$y]] . "】";
		} else{
			$soldier = "【패잔병】";
		}
	}
	$_list_tmp = array($ow, $soldier);
	unset($naviName); $naviName = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
	unset($naviExp); $naviExp = isset($_list_tmp[1]) ? $_list_tmp[1] : null;
	if ($l == $HlandSea) {
		if ($lv == 1) {
			
			$image = 'land14.gif';
			$alt = '바다(얕은 여울)';
		} else {
			
			$image = 'land0.gif';
			$alt = '바다';
		}
		$naviTitle = $alt;
	} elseif ($l == $HlandWaste) {
		
		if ($lv == 1) {
			$image = 'land13.gif'; 
			$alt = '황무지';
		} else {
			$image = 'land1.gif';
			$alt = '황무지';
		}
		$naviTitle = $alt;
	} elseif ($l == $HlandPlains) {
		
		$image = 'land2.gif';
		$alt = '평지';
		$naviTitle = $alt;
	} elseif ($l == $HlandForest) {
		
		if ($mode == 0) {
			
			$image = 'land6.gif';
			$alt = '숲';
		} else {
			$image = 'land6.gif';
			$alt = "숲({$lv}$HunitTree)";
			$naviText = "{$lv}$HunitTree";
		}
		$naviTitle = '숲';
	} elseif ($l == $HlandTown) {
		
		unset($p); $p = null;
		if ($lv < 30) {
			$p = 3;
			$naviTitle = '마을';
		} elseif ($lv < 100) {
			$p = 4;
			$naviTitle = '마을';
		} else {
			$p = 5;
			$naviTitle = '도시';
		}
		$image = "land{$p}.gif";
		$alt = "$naviTitle({$lv}$HunitPop)";
		$naviText = "{$lv}$HunitPop";
	} elseif ($l == $HlandFarm) {
		
		$image = 'land7.gif';
		$alt = "농장({$lv}0{$HunitPop}규모)";
		$naviTitle = '농장';
		$naviText = "{$lv}0{$HunitPop}규모";
	} elseif ($l == $HlandFactory) {
		
		$image = 'land8.gif';
		$alt = "공장({$lv}0{$HunitPop}규모)";
		$naviTitle = '공장';
		$naviText = "{$lv}0{$HunitPop}규모";
	} elseif ($l == $HlandBase) {
		
		if ($mode == 0) {
			
			$image = 'land6.gif';
			$alt = '숲';
			$naviTitle = $alt;
		} else {
			$level = expToLevel($l, $lv) + $HmissileRange - 1;
			$image = 'land9.gif';
			$alt = "미사일 기지 (사정 {$level}/경험치 $lv)";
			$naviTitle = '미사일 기지';
			$naviText = "사정 {$level}/경험치 $lv";
		}
	} elseif ($l == $HlandSbase) {
		
		if ($mode == 0) {
			
			$image = 'land0.gif';
			$alt = '바다';
			$naviTitle = $alt;
		} else {
			$level = expToLevel($l, $lv) + $HmissileRangeS - 1;
			$image = 'land12.gif';
			$alt = "해저 기지 (사정 {$level}/경험치 $lv)";
			$naviTitle = '해저 기지';
			$naviText = "사정 {$level}/경험치 $lv";
		}
	} elseif ($l == $HlandDefence) {
		
		if ($mode == 0) {
			
			$image = 'land6.gif';
			$alt = '숲';
		} else {
			$image = 'land10.gif';
			$alt = '방위 시설';
		}
		$naviTitle = $alt;
	} elseif ($l == $HlandSupply) {
		
		if ($mode == 0) {
			
			$image = 'land6.gif';
			$alt = '숲';
				$naviTitle = $alt;
		} else {
			$image = "land17_{$lv}.gif";
			$__supply_idx = intval($lv) - 1;
			$__supply_name = isset($ofname[$__supply_idx]) ? $ofname[$__supply_idx] : '';
			$__supply_corps = isset($ofcorps[$__supply_idx]) ? $ofcorps[$__supply_idx] : '';
			$__supply_div = isset($Fdivision[$__supply_corps]) ? $Fdivision[$__supply_corps] : '';
			$alt = "병참기지(" . $__supply_name . " " . $__supply_div . ")";
			$naviTitle = '병참기지';
			$naviText = $__supply_name . " " . $__supply_div;
		}
	} elseif ($l == $HlandMountain) {
		
		$naviTitle = '산';
		if ($lv > 0) {
			$image = 'land15.gif';
			$alt = "산(채굴장{$lv}0{$HunitPop}규모)";
			$naviText = "채굴장{$lv}0{$HunitPop}규모";
		} else {
			$image = 'land11.gif';
			$alt = '산';
		}
	} elseif ($l == $HlandMonument) {
		
		$image = $HmonumentImage[$lv];
		$alt = $HmonumentName[$lv];
		$naviTitle = $alt;
	} elseif ($l == $HlandMonster) {
		
		$kind = monsterSpec($lv);
		unset($name); $name = isset($_list_tmp[1]) ? $_list_tmp[1] : null;
		unset($hp); $hp = isset($_list_tmp[2]) ? $_list_tmp[2] : null;
		$special = $HmonsterSpecial[$kind];
		$image = $HmonsterImage[$kind];

		
			if ((($special == 3) && (($HislandTurn % 2) == 1)) ||
				(($special == 4) && (($HislandTurn % 2) == 0))) {
			
			$image = $HmonsterImage2[$kind];
		}
		$alt = "괴수$name(체력{$hp})";
		$naviTitle = $name;
		$naviText = "체력{$hp}";
	}
	$_list_tmp = array("","",'aqua');
	unset($ntmp); $ntmp = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
	unset($ntmp2); $ntmp2 = isset($_list_tmp[1]) ? $_list_tmp[1] : null;
	unset($ncolor); $ncolor = isset($_list_tmp[2]) ? $_list_tmp[2] : null;
	if ($HdebugR) {
		$ntmp2 = strval($HlandResist[$x][$y]);
	} elseif ($missile > 0) {
		$ntmp2 = $missile;
	} elseif (is_array($DivPw) && isset($DivPw[$x]) && is_array($DivPw[$x]) && isset($DivPw[$x][$y]) && $DivPw[$x][$y] > 0) {
		$ntmp2 = $DivPw[$x][$y];
		$ncolor = $color[$HGr[$x][$y] - 1];
	}
	$id = $HlandOwner[$x][$y];
	if ($js == 2) {
		
		unset($s); $s = "";
		if ($alpha == '') {
			
			$s = "a";
		} else{
			
			if (($x == 0 || $x == $HislandSize - 1) && ($y == 0 || $y == $HislandSize - 1)) {
				$s = $a[$c];
				$c++;
			} else{
				$s = "b";
			}
		}
		$alpha .= " ID='{$x}{$s}{$y}i'";
		$ntmp = "<span ID='{$x}{$s}{$y}' style=\"position:absolute;text-decoration:none;color:$ncolor;font-weight:bold;font-size:12pt;\">$ntmp2</span>";

		out("<A HREF=\"JavaScript:void(0);\" onclick=\"ps($x,$y,$id)\" ");
		if ($HmainMode != 'landmap') {
			out("onMouseOver=\"set_com($x, $y, '$point $alt $ow $soldier','$cur/$image', '$naviName', '$naviTitle', '$naviText', '$naviExp'); return true;\" onMouseOut=\"NaviClose();window.status = '';return true;\">");
		} elseif ($HmainMode == 'landmap') {
			
			out("onMouseOver=\"window.status = '$point $alt $ow $soldier $comStr'; return true;\" onMouseOut=\"window.status = '';\">");
		}
	
		out("$ntmp<IMG SRC=\"$cur/$image\" width=$imagesize height=$imagesize BORDER=0$alpha></A>");
	} elseif ($imagesize < 16) {
		
	
	
		return array($alt, $image);
	} else{
		
		out("<A HREF=\"JavaScript:void(0);\" onclick=\"ps($x,$y,$id)\" ");

	
		out("onMouseOver=\"Navi($x, $y,'$cur/$image', '$naviName', '$naviTitle', '$naviText', '$naviExp');window.status = '$point $alt $ow $soldier $comStr'; return true;\" onMouseOut=\"NaviClose();window.status = '';return true;\">");
		if (($Hcolormap > 0) && ($id > 0) && ($l != $HlandSbase)) {
			
			unset($ctbl); $ctbl = array('green2','red3','blue3','yellow2','purple2','white','red2','gray','blue2','purple1','yellow1','blue1','red1','green1','black','white','white','white');
			out("<IMG SRC=\"f/" . $ctbl[$HidToNumber[$id]] . ".gif\" width=$imagesize height=$imagesize BORDER=0 STYLE=\"position: absolute;\">");
		}
		$ntmp = "<span ID='{$x}{$s}{$y}' style=\"position:absolute;text-decoration:none;color:$ncolor;font-weight:bold;font-size:12pt;\">$ntmp2</span>";
		out("$ntmp<IMG SRC=\"$cur/$image\" ALT=\"$point $alt $ow $comStr\" TITLE=\"$point $alt $ow $comStr\" width=$imagesize height=$imagesize BORDER=0$alpha>");
		out("</A>");
	}

} 






/*
 * 함수: tempPrintIslandHead()
 * 역할: 섬 화면 공통 제목/상단 HTML을 출력합니다.
 * 원본 대응: hako/hako-map.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function tempPrintIslandHead() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	out(<<<HAKOHDOC_4
<CENTER>
{$HtagBig_}{$HtagName_}[{$HcurrentName}]{$H_tagName}라고 명명합니다.!{$H_tagBig}<BR>
{$HtempBack}　

HAKOHDOC_4
);
	if ($HeditorN) { out("<A HREF=\"{$HthisFile}?meditor=$HcurrentID\">맵 에디터</A><BR>"); }
	out("</CENTER>");
}

/*
 * 함수: tempNavi()
 * 역할: 섬 화면 상단 내비게이션 링크를 출력합니다.
 * 원본 대응: hako/hako-map.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function tempNavi() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	unset($mode); $mode = isset($_args[0]) ? $_args[0] : null;
	out(<<<HAKOHDOC_5
<SCRIPT Language="JavaScript">
<!--
function Navi(x, y, img, name, title, text, exp) {
	StyElm = document.getElementById("NaviView");
	StyElm.style.visibility = "visible";
	if(x - 2 > $HislandSize / 2) {
		StyElm.style.marginLeft = (x - 12) * 32; // 보짝
	} else {
		StyElm.style.marginLeft = (x + 4) * 32; // 괜짝
	}
	StyElm.style.marginTop = (y - $HislandSize - 1.5) * 32;
	StyElm.innerHTML = "<table><tr><td class='M'><img class='NaviImg' height='48' width='48' src=" + img + "><\\/td><td class='M'><div class='NaviTitle'>" + name + "<\\/div><div class='NaviTitle'>" + title + " (" + x + "," + y + ")<\\/div><div class='NaviText'>" + text + "<\\/div>";
	if(exp) {
		StyElm.innerHTML += "<div class='NaviText'>" + exp + "<\\/div>";
	}
	StyElm.innerHTML += "<\\/td><\\/tr><\\/table>";
}
function NaviClose() {
	StyElm = document.getElementById("NaviView");
	StyElm.style.visibility = "hidden";
}
//-->
</SCRIPT>

HAKOHDOC_5
);
}


/*
 * 함수: tempForceInput()
 * 역할: 부대 편성 입력 폼을 출력합니다.
 * 원본 대응: hako/hako-map.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function tempForceInput() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	unset($island); $island = isset($_args[0]) ? $_args[0] : null;
	unset($ofname); $ofname = $island['fleet'];
	unset($ofcolor); $ofcolor = $island['color'];
	unset($ofdirection); $ofdirection = $island['direction'];
	unset($oforder); $oforder = $island['order'];
	unset($ofcorps); $ofcorps = $island['corps'];
	out(<<<HAKOHDOC_6
<DIV ID='localBBS'>
<HR>
{$HtagBig_}군정보{$H_tagBig}<BR>
<FORM name="ForceForm" action="$HthisFile" method="POST">
<INPUT TYPE="hidden" VALUE="{$HdefaultPasswordEsc}" NAME="PASSWORD">
<TABLE BORDER><TR>
<TH $HbgTitleCell>No</TH>
<TH $HbgTitleCell>명칭</TH>
<TH $HbgTitleCell>진격 방향</TH>
<TH $HbgTitleCell>명령 지침</TH>
<TH $HbgTitleCell>편제 병종</TH>
<TH $HbgTitleCell>표시색</TH>
</TR>
HAKOHDOC_6
);
	for ($_ = 0; $_ <= $Hfleet - 1; $_++) {
		unset($no); $no = $_ + 1;
		$_list_tmp = array(0,0);
		unset($i); $i = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
		unset($c); $c = isset($_list_tmp[1]) ? $_list_tmp[1] : null;
		unset($s_list); $s_list = "";
		for ($i = 0; $i <= 6; $i++) {
			if ($i == $ofdirection[$_]) {
				$s_list .= "<OPTION value=$i selected>$Fdirection[$i]\n";
			} else{
				$s_list .= "<OPTION value=$i>$Fdirection[$i]\n";
			}
		}
		unset($s_list2); $s_list2 = "";
		for ($i = 0; $i <= 3; $i++) {
			if ($i == $oforder[$_]) {
				$s_list2 .= "<OPTION value=$i selected>$Forder[$i]\n";
			} else{
				$s_list2 .= "<OPTION value=$i>$Forder[$i]\n";
			}
		}
		unset($s_list3); $s_list3 = "";
		for ($i = 0; $i <= hako_last_index($Fdivision); $i++) {
			if ($i == $ofcorps[$_]) {
				$s_list3 .= "<OPTION value=$i selected>$Fdivision[$i]\n";
			} else{
				$s_list3 .= "<OPTION value=$i>$Fdivision[$i]\n";
			}
		}
		unset($s_list4); $s_list4 = "";
		$cName = array('black','gray','silver','white','maroon','red','purple','fuchsia','green','lime',
					'olive','yellow','navy','blue','teal','aqua','pink','lavender','salmon','Gold');
		$list4 = array('black','gray','silver','white','maroon','red','purple','fuchsia','green','lime',
		'olive','yellow','navy','blue','teal','aqua','#FFC0CB','#E6E6FA','#FA8072','#FFD700');
		for ($c = 0; $c <= 19; $c++) {
			if ($list4[$c] == $ofcolor[$_]) {
				$s_list4 .= "<OPTION value=$list4[$c] style=\"background-color:$list4[$c]\" selected>$cName[$c]\n";
			} else{
				$s_list4 .= "<OPTION value=$list4[$c] style=\"background-color:$list4[$c]\">$cName[$c]\n";
			}
		}
		out(<<<HAKOHDOC_7
<TR>
<TD $HbgInfoCell>$no</TD>
<TD $HbgInfoCell><INPUT TYPE="text" SIZE=20 MAXLENGTH=20 NAME="ForceName{$_}" VALUE="$ofname[$_]" onchange="chForceMenu()"></TD>
<TD $HbgInfoCell><SELECT NAME="ForceDir{$_}" onchange="chForceMenu()">$s_list</SELECT></TD>
<TD $HbgInfoCell><SELECT NAME="ForceOrder{$_}" onchange="chForceMenu()">$s_list2</SELECT></TD>
<TD $HbgInfoCell><SELECT NAME="ForceCorps{$_}" onchange="chForceMenu()">$s_list3</SELECT></TD>
<TD $HbgInfoCell><SELECT NAME="ForceColor{$_}" onchange="chForceMenu()">$s_list4</SELECT></TD>
</TR>
HAKOHDOC_7
);
	}
	out(<<<HAKOHDOC_8
</TABLE>
<span class='attention' id="CHFORCE1"></span>
<INPUT TYPE="submit" VALUE="설정 변경" NAME=ForceButton{$Hislands[$HcurrentNumber]['id']}>
<span class='attention' id="CHFORCE2"></span>
</FORM></DIV>
HAKOHDOC_8
);
}


/*
 * 함수: tempCommentInput()
 * 역할: 코멘트 입력 폼을 출력합니다.
 * 원본 대응: hako/hako-map.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function tempCommentInput() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	$commentValue = isset($_args[0]) ? htmlEscape($_args[0]) : null;
	out(<<<HAKOHDOC_9
<DIV ID='CommentBox'>
<HR>
{$HtagBig_}코멘트 갱신{$H_tagBig}<BR>
<FORM action="$HthisFile" method="POST">
코멘트 <INPUT TYPE=text NAME=MESSAGE SIZE=80 VALUE="{$commentValue}"><INPUT TYPE="password" VALUE="{$HdefaultPasswordEsc}" NAME="PASSWORD" SIZE=4>
<INPUT TYPE=submit VALUE="코멘트 갱신" NAME=MessageButton{$Hislands[$HcurrentNumber]['id']}>
</FORM>
</DIV>
HAKOHDOC_9
);
}


/*
 * 함수: tempLbbsInput()
 * 역할: 로컬게시판 입력 폼을 출력합니다.
 * 원본 대응: hako/hako-map.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function tempLbbsInput() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	unset($str1); $str1 = null;
	unset($str2); $str2 = null;
	unset($str3); $str3 = null;
	unset($str4); $str4 = null;
	unset($str5); $str5 = null;
	unset($LbbsButtonW); $LbbsButtonW = null;
	unset($LbbsButtonD); $LbbsButtonD = null;
	out("\n<DIV ID='localBBS'>");
	$mode = isset($_args[0]) ? $_args[0] : null;
	if ($mode == 0) {
		
		$str1 = "<TH $HbgTitleCell>통신 방법</TH>";
		$str2 = <<<HAKOHDOC_10
<TD $HbgInfoCell>
<INPUT TYPE="radio" NAME="LBBSTYPE" VALUE="PUBLIC" CHECKED>공개
<INPUT TYPE="radio" NAME="LBBSTYPE" VALUE="SECRET"><FONT COLOR="red">극비</FONT></TD>

HAKOHDOC_10
;
		$str3 = "<TH $HbgTitleCell>국명</TH><TH $HbgTitleCell COLSPAN=2>동작</TH>";
		$str4 = "<TD $HbgNameCell><SELECT NAME=\"ISLANDID2\">$HislandList</SELECT>";
		if ($HlbbsAnon) { $str4 .= "<INPUT TYPE=\"radio\" NAME=\"LBBSTYPE\" VALUE=\"ANON\">관광자"; }
		$str4 .= "</TD>";
		$str5 = "<INPUT TYPE=\"submit\" VALUE=\"극비 확인\" NAME=\"LbbsButtonCK$HcurrentID\">";
		$LbbsButtonW = "LbbsButtonSS";
		$LbbsButtonD = "LbbsButtonDS";
	} else{
		$str3 = "<TH $HbgTitleCell COLSPAN=2>동작</TH>";
		$LbbsButtonW = "LbbsButtonOW";
		$LbbsButtonD = "LbbsButtonDL";
	}
	out(<<<HAKOHDOC_11
<HR>{$HtagBig_}{$HtagName_}{$HcurrentName}{$H_tagName}관광자 통신{$H_tagBig}<BR>
<CENTER>
<FORM action="$HthisFile" method="POST">
<TABLE BORDER><TR>
<TH $HbgTitleCell>이름</TH>
<TH $HbgTitleCell COLSPAN=2>내용</TH>
$str1
</TR><TR>
<TD $HbgInfoCell><INPUT TYPE="text" SIZE=32 MAXLENGTH=32 NAME="LBBSNAME" VALUE="$HdefaultName"></TD>
<TD $HbgInfoCell COLSPAN=2><INPUT TYPE="text" SIZE=120 NAME="LBBSMESSAGE"></TD>
$str2
</TR><TR>
<TH $HbgTitleCell>패스워드</TH>
$str3
</TR><TR>
<TD $HbgInfoCell><INPUT TYPE=password SIZE=32 MAXLENGTH=32 NAME=PASSWORD VALUE="{$HdefaultPasswordEsc}"></TD>
$str4
<TD $HbgInfoCell align=right>
<INPUT TYPE="submit" VALUE="기장한다" NAME="$LbbsButtonW$HcurrentID">
$str5
</TD>
<TD $HbgInfoCell align=right>번호<SELECT NAME=NUMBER>

HAKOHDOC_11
);
	
	unset($j); $j = null;
	unset($i); $i = null;
	for ($i = 0; $i < $HlbbsMax; $i++) {
		$j = $i + 1;
		out("<OPTION VALUE=$i>$j\n");
	}
	out(<<<HAKOHDOC_12
</SELECT>
<INPUT TYPE="submit" VALUE="삭제" NAME="$LbbsButtonD$HcurrentID">
</TD></TR></TABLE></FORM></CENTER>

<CENTER><TABLE BORDER><TR>
<TH $HbgTitleCell>번호</TH><TH $HbgTitleCell>기장 내용</TH></TR>

HAKOHDOC_12
);
	unset($i); $i = null;
	unset($line); $line = null;
	$lbbs = $Hislands[$HcurrentNumber]['lbbs'];
	for ($i = 0; $i < $HlbbsMax; $i++) {
	$line = $lbbs[$i];
	if (hako_regex('~([0-9]*)\<(.*)\<([0-9]*)\>(.*)\>(.*)$~', $line)) {
		$j = $i + 1;
		out("<TR><TD $HbgSubTCell>$HtagNumber_$j$H_tagNumber</TD>");
		unset($speaker); $speaker = null;
		if (hako_m(3) == 0) {
			$_list_tmp = explode(',', hako_m(2));
			$sName = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
			unset($sID); $sID = isset($_list_tmp[1]) ? $_list_tmp[1] : null;
			unset($sNo); $sNo = ((string)$sID !== '' && isset($HidToNumber[$sID])) ? $HidToNumber[$sID] : null;
			if ($HlbbsSpeaker && ($sName != '')) {
				if (isset($sNo)) {
					$speaker = "<FONT COLOR=gray><B><SMALL>(<A HREF=\"$HthisFile?Sight=$sID\" class=\"M\">$sName</A>)</SMALL></B></FONT>";
				} else {
					$speaker = "<FONT COLOR=gray><B><SMALL>($sName)</SMALL></B></FONT>";
				}
			}
			
			if (hako_m(1) == 0) {
				
				out("<TD $HbgLbbsCell>" . $HtagLbbsSS_ . hako_m(4) . " > " . hako_m(5) . $H_tagLbbsSS . " $speaker</TD></TR>");
			} else {
				
			
				if (($HmainMode != 'owner') &&(($HspeakerID == '') || ($sID != $HspeakerID))) {
					
					out("<TD $HbgLbbsCell><CENTER><FONT COLOR=gray>- 극비 -</FONT></CENTER></TD></TR>");
				} else {
					
					out("<TD $HbgLbbsCell>" . $HtagLbbsSS_ . hako_m(4) . " >(비) " . hako_m(5) . $H_tagLbbsSS . " $speaker</TD></TR>");
				}
			}
		} else {
			
			if ($HlbbsSpeaker && (hako_m(2) != '')) { $speaker = "<FONT COLOR=gray><B><SMALL>" . hako_m(2) . "</SMALL></B></FONT>"; }
			out("<TD $HbgLbbsCell>" . $HtagLbbsOW_ . hako_m(4) . " > " . hako_m(5) . $H_tagLbbsOW . " $speaker</TD></TR>");
		}
	}
	}
	out(<<<HAKOHDOC_13
</TD></TR></TABLE></CENTER></DIV>

HAKOHDOC_13
);
}


/*
 * 함수: tempLbbsNoMessage()
 * 역할: 로컬게시판 글이 없을 때의 화면 조각입니다.
 * 원본 대응: hako/hako-map.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function tempLbbsNoMessage() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	out(<<<HAKOHDOC_14
{$HtagBig_}이름 또는 내용의 란이 공난입니다.{$H_tagBig}$HtempBack
HAKOHDOC_14
);
}


/*
 * 함수: tempLbbsDelete()
 * 역할: 로컬게시판 삭제 결과 화면 조각입니다.
 * 원본 대응: hako/hako-map.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function tempLbbsDelete() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	out(<<<HAKOHDOC_15
{$HtagBig_}기장 내용을 삭제했습니다{$H_tagBig}<HR>
HAKOHDOC_15
);
}


/*
 * 함수: tempLbbsAdd()
 * 역할: 로컬게시판 글 등록 결과 화면 조각입니다.
 * 원본 대응: hako/hako-map.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function tempLbbsAdd() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	out(<<<HAKOHDOC_16
{$HtagBig_}기장을 실시했습니다{$H_tagBig}<HR>
HAKOHDOC_16
);
}


/*
 * 함수: tempCommandDelete()
 * 역할: 명령 삭제 결과 화면 조각입니다.
 * 원본 대응: hako/hako-map.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function tempCommandDelete() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	out(<<<HAKOHDOC_17
{$HtagBig_}커멘드를 삭제했습니다{$H_tagBig}<HR>
HAKOHDOC_17
);
}


/*
 * 함수: tempCommandAdd()
 * 역할: 명령 추가/삽입 결과 화면 조각입니다.
 * 원본 대응: hako/hako-map.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function tempCommandAdd() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	out(<<<HAKOHDOC_18
{$HtagBig_}커멘드를 등록했습니다{$H_tagBig}<HR>
HAKOHDOC_18
);
}


/*
 * 함수: tempRecent()
 * 역할: 최근 사건 표시 영역을 출력합니다.
 * 원본 대응: hako/hako-map.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function tempRecent() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	unset($mode); $mode = isset($_args[0]) ? $_args[0] : null;
	out(<<<HAKOHDOC_19
<HR>{$HtagBig_}{$HtagName_}{$HcurrentName}{$H_tagName}의 근황{$H_tagBig}<BR>

HAKOHDOC_19
);
	logPrintLocal($mode);
}

/*
 * 함수: logPrintLocal()
 * 역할: 섬별 로컬 로그를 출력합니다.
 * 원본 대응: hako/hako-map.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logPrintLocal() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	unset($mode); $mode = isset($_args[0]) ? $_args[0] : null;
	unset($i); $i = null;
	for ($i = 0; $i < $HlogMax; $i++) {
		logFilePrint($i, $HcurrentID, $mode);
	}
}


/*
 * 함수: islandJamp()
 * 역할: 섬 이동/선택 링크를 출력합니다.
 * 원본 대응: hako/hako-map.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function islandJamp() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$HdefaultPasswordEsc = htmlEscape(isset($HdefaultPassword) ? $HdefaultPassword : '');
	$HtargetList = getIslandList($HcurrentID);
	out(<<<HAKOHDOC_20
<CENTER>
<SCRIPT LANGUAGE="JavaScript">
function jump(theForm) {
  var sIndex = theForm.urlsel.selectedIndex;
  var url = theForm.urlsel.options[sIndex].value;
  if (url != "" ) location.href = "$HthisFile?Sight=" +url;
}
</SCRIPT>
<TABLE align=center border=0>
<TR><TD>
<FORM name="urlForm">
<SELECT NAME="urlsel">
$HtargetList<BR>
</SELECT>
</TD>
<TD><input type="button" value=" GO " onClick="jump(this.form)"></TD>
</TR></TABLE>
</form>
</CENTER>
HAKOHDOC_20
);
}

?>
