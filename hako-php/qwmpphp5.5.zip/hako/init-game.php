<?php

/*
 * hako/init-game.php
 * ------------------------------------------------------------
 * 게임 규칙/좌표/HTML 공통 조각 설정 파일
 *
 * 상세 주석 기준:
 * - 원본 대응: qwmp155.zip 의 init-game.cgi.
 * - 맵 크기, 좌표 보정 배열, 기본 안내문, HTML 헤더/푸터, 그래프/로그/색상 관련 설정을 정의합니다.
 * - 좌표 배열 ax/ay/correct 는 육각형 지도 탐색과 미사일/재해 범위 계산에 사용되므로 값 변경을 금지합니다.
 * - 원본 CGI 주석 라인 확인 수: 124줄. PHP 주석은 실행 결과를 바꾸지 않는 범위에서 복원/보강했습니다.
 *
 * 유지보수 원칙:
 * - 실행 로직, 저장 포맷, 배열 인덱스, 출력 HTML은 원본 CGI 호환성 대상입니다.
 * - 개조가 필요하면 먼저 해당 변수/함수가 어떤 파일 저장값과 연결되는지 확인하십시오.
 * - 이 주석은 유지보수용이며 실행 결과를 바꾸지 않습니다.
 */

chdir(dirname(__FILE__));
require_once dirname(__FILE__) . '/hako-compat.php';
$Hasync = 0; // 비동기/출력 생략 플래그입니다.
$HimgLine = ''; // BASE HREF에 사용할 이미지 기준 경로 보조값입니다.













//----------------------------------------------------------------------
// 게임 안내문과 기본 출력 설정
//----------------------------------------------------------------------
$Hattention = <<<HAKOHDOC_0
이 모형정원은 전쟁 서바이벌계입니다. 무단으로 공격·침략되어도 화내지 않고 즐겁게 합시다.<br>


HAKOHDOC_0
;




//----------------------------------------------------------------------
// 육각형 지도 좌표 보정 배열
// 미사일 사거리, 재해 범위, 주변 판정에서 사용
//----------------------------------------------------------------------
$ax = array(0,1,1,1,0,-1,0,1,2,2,2,1,0,-1,-1,-2,-1,-1,0,2,2,3,3,3,2,2,1,0,-1,-2,-2,-3,-2,-2,-1,0,1,2,3,3,4,4,4,3,3,2,1,0,-1,-2,-2,-3,-3,-4,-3,-3,-2,-2,-1,0,1,3,3,4,4,5,5,5,4,4,3,3,2,1,0,-1,-2,-3,-3,-4,-4,-5,-4,-4,-3,-3,-2,-1,0,1,2,3,4,4,5,5,6,6,6,5,5,4,4,3,2,1,0,-1,-2,-3,-3,-4,-4,-5,-5,-6,-5,-5,-4,-4,-3,-3,-2,-1,0,1,2,4,4,5,5,6,6,7,7,7,6,6,5,5,4,4,3,2,1,0,-1,-2,-3,-4,-4,-5,-5,-6,-6,-7,-6,-6,-5,-5,-4,-4,-3,-2,-1,0,1,2,3,4,5,5,6,6,7,7,8,8,8,7,7,6,6,5,5,4,3,2,1,0,-1,-2,-3,-4,-4,-5,-5,-6,-6,-7,-7,-8,-7,-7,-6,-6,-5,-5,-4,-4,-3,-2,-1,0,1,2,3,5,5,6,6,7,7,8,8,9,9,9,8,8,7,7,6,6,5,5,4,3,2,1,0,-1,-2,-3,-4,-5,-5,-6,-6,-7,-7,-8,-8,-9,-8,-8,-7,-7,-6,-6,-5,-5,-4,-3,-2,-1,0,1,2,3,4,5,6,6,7,7,8,8,9,9,10,10,10,9,9,8,8,7,7,6,6,5,4,3,2,1,0,-1,-2,-3,-4,-5,-5,-6,-6,-7,-7,-8,-8,-9,-9,-10,-9,-9,-8,-8,-7,-7,-6,-6,-5,-5,-4,-3,-2,-1,0,1,2,3,4,6,6,7,7,8,8,9,9,10,10,11,11,11,10,10,9,9,8,8,7,7,6,6,5,4,3,2,1,0,-1,-2,-3,-4,-5,-6,-6,-7,-7,-8,-8,-9,-9,-10,-10,-11,-10,-10,-9,-9,-8,-8,-7,-7,-6,-6,-5,-4,-3,-2,-1,0,1,2,3,4,5,7,7,8,8,9,9,10,10,11,11,12,12,11,11,10,10,9,9,8,8,7,7,-6,-7,-7,-8,-8,-9,-9,-10,-10,-11,-11,-11,-11,-10,-10,-9,-9,-8,-8,-7,-7,-6); // 육각형 지도 주변 탐색용 x 좌표 보정 배열입니다. 미사일/재해/주변 판정에 사용됩니다.
$ay = array(0,-1,0,1,1,0,-1,-2,-1,0,1,2,2,2,1,0,-1,-2,-2,-3,-2,-1,0,1,2,3,3,3,3,2,1,0,-1,-2,-3,-3,-3,-4,-3,-2,-1,0,1,2,3,4,4,4,4,4,3,2,1,0,-1,-2,-3,-4,-4,-4,-4,-5,-4,-3,-2,-1,0,1,2,3,4,5,5,5,5,5,5,4,3,2,1,0,-1,-2,-3,-4,-5,-5,-5,-5,-5,-6,-5,-4,-3,-2,-1,0,1,2,3,4,5,6,6,6,6,6,6,6,5,4,3,2,1,0,-1,-2,-3,-4,-5,-6,-6,-6,-6,-6,-6,-7,-6,-5,-4,-3,-2,-1,0,1,2,3,4,5,6,7,7,7,7,7,7,7,7,6,5,4,3,2,1,0,-1,-2,-3,-4,-5,-6,-7,-7,-7,-7,-7,-7,-7,-8,-7,-6,-5,-4,-3,-2,-1,0,1,2,3,4,5,6,7,8,8,8,8,8,8,8,8,8,7,6,5,4,3,2,1,0,-1,-2,-3,-4,-5,-6,-7,-8,-8,-8,-8,-8,-8,-8,-8,-9,-8,-7,-6,-5,-4,-3,-2,-1,0,1,2,3,4,5,6,7,8,9,9,9,9,9,9,9,9,9,9,8,7,6,5,4,3,2,1,0,-1,-2,-3,-4,-5,-6,-7,-8,-9,-9,-9,-9,-9,-9,-9,-9,-9,-10,-9,-8,-7,-6,-5,-4,-3,-2,-1,0,1,2,3,4,5,6,7,8,9,10,10,10,10,10,10,10,10,10,10,10,9,8,7,6,5,4,3,2,1,0,-1,-2,-3,-4,-5,-6,-7,-8,-9,-10,-10,-10,-10,-10,-10,-10,-10,-10,-10,-11,-10,-9,-8,-7,-6,-5,-4,-3,-2,-1,0,1,2,3,4,5,6,7,8,9,10,11,11,11,11,11,11,11,11,11,11,11,11,10,9,8,7,6,5,4,3,2,1,0,-1,-2,-3,-4,-5,-6,-7,-8,-9,-10,-11,-11,-11,-11,-11,-11,-11,-11,-11,-11,-11,-11,-10,-9,-8,-7,-6,-5,-4,-3,-2,-1,1,2,3,4,5,6,7,8,9,10,11,11,10,9,8,7,6,5,4,3,2,1,-1,-2,-3,-4,-5,-6,-7,-8,-9,-10,-11); // 육각형 지도 주변 탐색용 y 좌표 보정 배열입니다.



//----------------------------------------------------------------------
// 지도 크기와 좌표 보정값
//----------------------------------------------------------------------
$HislandSize = 20; // 지도 한 변의 크기입니다.



$correct = array(8,9,10,11,12,13,14,15,16,17,18,19,0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,0,1,2,3,4,5,6,7,8,9,10,11); // 지도 좌표 보정 배열입니다. 화면 출력과 주변 탐색에 사용됩니다.




/*
 * 함수: tempHeader()
 * 역할: 공통 HTML 헤더를 출력합니다.
 * 원본 대응: hako/init-game.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
//----------------------------------------------------------------------
// 공통 HTML 헤더/푸터 출력
//----------------------------------------------------------------------
function tempHeader() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	unset($js); $js = isset($_args[0]) ? $_args[0] : null;
	if ($js == 1) {
		
		$Body = "<BODY $htmlBody onload=\"SelectList('');init()\">";
	} else{
		$Body = "<BODY $htmlBody>";
	}
	unset($sftime); $sftime = hako_file_age_days("{$HefileDir}/setup.html");
	unset($Files); $Files = array('hako-main.php', 'hako-init.php', 'init-game.php', 'init-army.php', 'hako-help.php');
	unset($sfFlag); $sfFlag = 1;
	unset($setuplist); $setuplist = null;
	foreach ($Files as $_) {
		if ($sftime >= (hako_file_age_days("./$_"))) {
			$sfFlag = 0;
			break;
		}
	}
	if ((file_exists("{$HefileDir}/setup.html")) && $sfFlag) {
	
	$setuplist = "<A href=\"{$efileDir}/setup.html\" TARGET=_blank>설정 일람</A> /";
	} else {
		$setuplist = "<A href=\"$HthisFile?SetupV=0\" TARGET=_blank>설정 일람</A> /";
	}
	if (!headers_sent()) { header('Content-Type: text/html; charset=UTF-8'); }
	if ($Hasync) { return; }
	unset($headtitle); $headtitle = temphead($Htitle,$HimgLine);
	out(<<<HAKOHDOC_3
$headtitle
$Body
<DIV ID='BodySpecial'><DIV ID='LinkHead'>
<A HREF="https://esils.com/xe/hakobbs/" target="_blank">모형정원 공용게시판</A> /
<A HREF="$bbs" target="_blank">게시판</A> /
<A HREF="$HbaseDir/hakolog.html" target="_blank">최근의 사건</A> /
$setuplist
<A HREF="$helpDir" target="_blank">도움말</A> /
<A HREF="$toppage">Top</A> /
</DIV><HR>
HAKOHDOC_3
);
out("\n");
}


/*
 * 함수: temphead()
 * 역할: HTML head 태그와 CSS 기준 경로를 생성합니다.
 * 원본 대응: hako/init-game.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function temphead() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	unset($headtitle); $headtitle = isset($_args[0]) ? $_args[0] : null;
	unset($imgLine); $imgLine = isset($_args[1]) ? $_args[1] : null;
	$baseIMG = ($imgLine != '') ? $imgLine : $imageDir;
	$baseSKIN = (is_string($HskinName) && $HskinName != '') ? "$imageDir/$HskinName" : "$imageDir/$HcssFile";
	return <<<HAKOHDOC_4
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html lang="kr">
<!--???-->
<head>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
<TITLE>$headtitle</TITLE>
<BASE HREF="$baseIMG/">
<link rel="stylesheet" type="text/css" href="$baseSKIN">
</HEAD>

HAKOHDOC_4
;
}


/*
 * 함수: tempFooter()
 * 역할: 공통 HTML 푸터와 CPU 표시를 출력합니다.
 * 원본 대응: hako/init-game.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function tempFooter() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$_list_tmp = hako_cpu_times();
	$uti = isset($_list_tmp[0]) ? $_list_tmp[0] : 0;
	$sti = isset($_list_tmp[1]) ? $_list_tmp[1] : 0;
	$cuti = isset($_list_tmp[2]) ? $_list_tmp[2] : 0;
	$csti = isset($_list_tmp[3]) ? $_list_tmp[3] : 0;
	$uti += $cuti;
	$sti += $csti;
	unset($cpu); $cpu = $uti + $sti;

	$cpu = sprintf('%5.2f', $cpu);
	$uti = sprintf('%5.2f', $uti);
	$sti = sprintf('%5.2f', $sti);

	out(<<<HAKOHDOC_5
<HR>
<DIV ID='LinkFoot'>
타이틀：<A HREF="http://www8.plala.or.jp/nayupon/">모형정원 공통 맵 N　</A>{$versionInfo}<BR>
관리자：$adminName(<A HREF="mailto:$email">$email</A>)<BR>
배포실：(<A HREF="https://esils.com">배포실</A>)<BR>
</DIV>
<DIV align="right"><SMALL>CPU($cpu) : user($uti) system($sti)</SMALL></DIV>
</BODY></HTML>
HAKOHDOC_5
);
out("\n");
}






$HtopAxes = 1; // 탑 페이지 접근 로그 사용 여부입니다.


$HaxesLogfile = './axes.log'; // 접근 로그 파일명입니다.

$HaxesMax = 500;


$HpassError = 0;





$HhideMoneyMode = 2;





$HinitialMoney = 2000;


$HinitialFood = 1500;


$HinitialSoldier = 200;


$MaxMoney = 15000;


$MaxFood = 30000;


$HunitMoney = '억엔';


$HunitFood  = '00톤';
$HunitFood2 = '만 톤'; 


$HunitPop  = '00명';
$HunitPop2 = '만 명'; 


$HunitArea = 'Hex';


$HunitTree = '00개';


$HcostChangeName = 9999;


$HeatenFood = 0.2;


$HmaxAidMoney = 10;


$HmaxAidFood = 10;


$HmaxAidSoldier = 200;


$HmaxAidArea = 1;





$HmissileRange  = 5;
$HmissileRangeS = 12;


$HmaxExpPoint = 200; 


$baseLevelUp = array(1,4,8,12,20,30,40,50,70,100,140,200);
$sBaseLevelUp = array(1,4,8,12,20,30,40,50,70,100,200);


$baseLevelUp2 = array(50,200);
$sBaseLevelUp2 = array(20,50,100,200);




$HdBaseAuto = 1;





$HdisEarthquake = 10; 
$HdisTsunami    = 0;  
$HdisMeteo      = 10; 
$HdisEruption   = 30; 
$HdisFire       = 10; 
$HdisMaizo      = 10; 


$HdisNoMeteoTurn= 100;
$HdisHugeMeteo  = 0;  
$HdisFallBorder = 330;
$HdisHugeMeteo2 = 0;  
$HdisMeteo2     = 40; 

$HareaBorder = 0;


$HdisMonsBorder1 = 50;   
$HdisMonsBorder2 = 90;   
$HdisMonsBorder3 = 100;  
$HdisMonster     = 2.6;  
$HdisapearMons   = 250;  


$HmonsterNumber  = 8;


$HmonsterLevel1  = 2; 
$HmonsterLevel2  = 5; 
$HmonsterLevel3  = 7; 


$HmonsterName = array('메카 이노라', '이노라', '산지라', '레드 이노라', '다크 이노라', '이노라 고스트', '쿠지라', '킹 이노라');


$HmonsterBHP = array(4, 1, 1, 2, 1, 1, 4, 4);
$HmonsterDHP = array(0, 0, 0, 2, 2, 0, 2, 2);
$HmonsterSpecial = array(3, 0, 3, 0, 1, 2, 4, 0);
$HmonsterExp = array(5, 5, 7,12,15,10,20,30);
$HmonsterValue = array(10, 400, 500, 1000, 800, 300, 1500, 2000);










$HmonsterImage = array('monster7.gif', 'monster0.gif', 'monster5.gif', 'monster1.gif', 'monster2.gif', 'monster8.gif', 'monster6.gif', 'monster3.gif');


$HmonsterImage2 = array('monster7_2.gif', '', 'monster4.gif', '', '', '', 'monster4.gif', '');





$HmonumentNumber = 4;


$HmonumentName = array('방벽', '모노리스', '평화 기념비', '싸움의 비');


$HmonumentImage = array('monument1.gif', 'monument0.gif', 'monument0.gif', 'monument0.gif');





$HturnPrizeUnit = 25;


$Hprize[0] = '턴배';
$Hprize[1] = '번영상';
$Hprize[2] = '초번영상';
$Hprize[3] = '궁극 번영상';
$Hprize[4] = '평화상';
$Hprize[5] = '초평화상';
$Hprize[6] = '궁극 평화상';
$Hprize[7] = '재난상';
$Hprize[8] = '초재난상';
$Hprize[9] = '궁극 재난상';





$Haftername = array("나라","","왕국","제국","공화국","연방","황국","합중국","아침","공국","동맹");







$htmlBody = '';


$Htitle = '모형정원 공통 맵 N';
if (!isset($versionInfo)) { $versionInfo = ''; }
$Htitle2 = "$versionInfo";



$HtagTitle_ = '<span class="title">';
$HtagTitle2_= '<span class="title2">';
$H_tagTitle = '</span>';


$HtagBig_ = '<span class="big">';
$H_tagBig = '</span>';
$HtempBack = "<A HREF=\"$HthisFile\">탑에 돌아오는</A>";


$HtagName_ = '<span class="islName">';
$H_tagName = '</span>';


$HtagName2_ = '<span class="islName2">';
$H_tagName2 = '</span>';


$HtagNumber_ = '<span class="number">';
$H_tagNumber = '</span>';


$HtagTH_ = '<span class="head">';
$H_tagTH = '</span>';


$HtagComName_ = '<span class="command">';
$H_tagComName = '</span>';


$HtagComName1_ = '<span class="command1">';

$HtagComName2_ = '<span class="command2">';


$HtagDisaster_ = '<span class="disaster">';
$H_tagDisaster = '</span>';


$HtagLbbsSS_ = '<span class="lbbsSS">';
$H_tagLbbsSS = '</span>';


$HtagLbbsOW_ = '<span class="lbbsOW">';
$H_tagLbbsOW = '</span>';


$HnormalColor_ = '<span class="normal">';
$H_normalColor = '</span>';


$HbgTitleCell	= 'class=TitleCell';	
$HbgSubTCell	= 'class=SubTCell';		
$HbgNumberCell	= 'class=NumberCell';	
$HbgNameCell	= 'class=NameCell';		
$HbgInfoCell	= 'class=InfoCell';		
$HbgCommentCell	= 'class=CommentCell';	
$HbgInputCell	= 'class=InputCell';	
$HbgMapCell		= 'class=MapCell';		
$HbgCommandCell	= 'class=CommandCell';	
$HbgLbbsCell	= 'class=LbbsCell';		

?>
