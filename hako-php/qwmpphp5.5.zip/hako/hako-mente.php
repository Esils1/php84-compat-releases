<?php

/*
 * hako/hako-mente.php
 * ------------------------------------------------------------
 * 관리자/메인터넌스/데이터 초기화/턴 시간 조정 모듈
 *
 * 상세 주석 기준:
 * - 원본 대응: qwmp155.zip 의 hako-mente.cgi.
 * - 관리자 SETUP, 새 데이터 생성, 데이터 삭제/보관, 설정 변경, 시간 변경, 메인터넌스 모드, 통계 파일 생성을 담당합니다.
 * - 실제 서버에서 500 에러가 나기 쉬운 파일/디렉터리 조작이 많으므로 PHP 5.5 공유호스팅 함수 제한을 고려해야 합니다.
 * - access 계열 파일은 자동 생성 대상이며 원본 누락으로 판단하지 않습니다.
 * - 원본 CGI 주석 라인 확인 수: 47줄. PHP 주석은 실행 결과를 바꾸지 않는 범위에서 복원/보강했습니다.
 *
 * 유지보수 원칙:
 * - 실행 로직, 저장 포맷, 배열 인덱스, 출력 HTML은 원본 CGI 호환성 대상입니다.
 * - 개조가 필요하면 먼저 해당 변수/함수가 어떤 파일 저장값과 연결되는지 확인하십시오.
 * - 이 주석은 유지보수용이며 실행 결과를 바꾸지 않습니다.
 */

chdir(dirname(__FILE__));
require_once dirname(__FILE__) . '/hako-compat.php';


















require_once './hako-init.php';
require_once './hako-io.php';
require_once './init-game.php';


$alertNoIndex = 0;
$indexName = 'index.html';

unset($title); $title = '모형정원 공통 맵 N　maintenance tool';










unset($mainMode); $mainMode = null;
unset($mpass1); $mpass1 = null;
unset($mpass2); $mpass2 = null;
unset($spass1); $spass1 = null;
unset($spass2); $spass2 = null;
unset($deleteID); $deleteID = null;
unset($currentID); $currentID = null;
unset($ctYear); $ctYear = null;
unset($ctMon); $ctMon = null;
unset($ctDate); $ctDate = null;
unset($ctHour); $ctHour = null;
unset($ctMin); $ctMin = null;
unset($ctSec); $ctSec = null;

if (!headers_sent()) { header('Content-Type: text/html; charset=UTF-8'); }
echo <<<HAKOHDOC_0
<HTML>
<HEAD><META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
<TITLE>모형정원 공통 맵 N　maintenance tool</TITLE>
<link rel="stylesheet" type="text/css" href="$imageDir/qhw.css">
</HEAD>
<BODY>
HAKOHDOC_0
;

requestInput();

if ($alertNoIndex) {
	unset($flag); $flag = 0;
	if (!(file_exists($indexName))) {
		echo "{$HbaseDir}에{$indexName}가 없습니다!";
		$flag = 1;
	}
	if ($flag) { echo "<HR>\n"; }
}

if (file_exists($HpasswordFile)) {
	
	hako_open('PIN', "<$HpasswordFile");
	$HmasterPassword = hako_getline('PIN'); hako_chomp($HmasterPassword);
	hako_close('PIN');
}

if ($mainMode == 'delete') {
	if (passCheck()) { deleteMode(); }
} elseif ($mainMode == 'current') {
	if (passCheck()) { currentMode(); }
} elseif ($mainMode == 'time') {
	if (passCheck()) { timeMode(); }
} elseif ($mainMode == 'stime') {
	if (passCheck()) { stimeMode(); }
} elseif ($mainMode == 'new') {
	if (passCheck()) { newMode(); }
} elseif ($mainMode == 'setup' || $mainMode == 'changepw') {
	if (!$modeValue || passCheck()) { setupMode($modeValue); }
} elseif ($mainMode == 'mente') {
	if (passCheck()) { menteMode(); }
} elseif ($mainMode == 'unmente') {
	if (passCheck()) { unmenteMode(); }
} elseif ($mainMode == 'popsol') {
	if (passCheck()) { $popsolMode = 1; }
}

if (($mainMode == 'ktime') || ($mainMode == 'fsettime')) {
	if (passCheck()) { fTimeSetMode(); }
} elseif (($mainMode == 'admin') && (passCheck())) {
	adminMode();
} elseif ((($mainMode == 'mente') || ($mainMode == 'unmente') || ($mainMode == 'popsol')) && (passCheck())) {
	adminMode();
} else{
	mainMode();
}
echo <<<HAKOHDOC_1
</FORM></BODY></HTML>
HAKOHDOC_1
;

/*
 * 함수: myrmtree()
 * 역할: 백업/임시 디렉터리 삭제용 재귀 삭제 함수입니다. 없는 디렉터리에서도 화면 경고를 내면 안 됩니다.
 * 원본 대응: hako/hako-mente.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function myrmtree() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	unset($dn); $dn = isset($_args[0]) ? $_args[0] : null;
	if (!is_dir("$dn/")) { return; }
	$__dir_DIN = opendir("$dn/");
	if (!$__dir_DIN) { return; }
	unset($fileName); $fileName = null;
	while (($fileName = readdir($__dir_DIN)) !== false) {
		if (($fileName == '.') || ($fileName == '..')) { continue; }
		@unlink("$dn/$fileName");
	}
	if (isset($__dir_DIN) && $__dir_DIN) { closedir($__dir_DIN); }
	@rmdir($dn);
}

/*
 * 함수: currentMode()
 * 역할: 현재 데이터 상태를 관리자 화면에 표시합니다.
 * 원본 대응: hako/hako-mente.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function currentMode() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	myrmtree("{$HdirName}");
	mkdir("{$HdirName}", $HdirMode);
	$__bakDir = "{$HdirName}.bak$currentID";
	if (!is_dir("$__bakDir/")) { return; }
	$__dir_DIN = opendir("$__bakDir/");
	if (!$__dir_DIN) { return; }
	unset($fileName); $fileName = null;
	while (($fileName = readdir($__dir_DIN)) !== false) {
		if (($fileName == '.') || ($fileName == '..')) { continue; }
		fileCopy("$__bakDir/$fileName", "{$HdirName}/$fileName");
	}
	if (isset($__dir_DIN) && $__dir_DIN) { closedir($__dir_DIN); }
}

/*
 * 함수: deleteMode()
 * 역할: 관리자 데이터 삭제/보관 흐름을 처리합니다.
 * 원본 대응: hako/hako-mente.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function deleteMode() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	if ($deleteID == '') {
		myrmtree("{$HdirName}");
	} else {
		myrmtree("{$HdirName}.bak$deleteID");
	}
	unlink("hakojimalockflock");
}

/*
 * 함수: newMode()
 * 역할: 관리자 새 데이터 생성 흐름을 처리합니다.
 * 원본 대응: hako/hako-mente.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function newMode() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
		if (!is_dir($HdirName)) { mkdir($HdirName, $HdirMode); }

	
	$now = time();
	$now -= $now % $HunitTime;

	hako_open('OUT', ">$HdirName/hakojima.dat");
	hako_write('OUT', "1\n");
	hako_write('OUT', "$now\n");
	hako_write('OUT', "0\n");
	hako_write('OUT', "1\n");
	hako_write('OUT', "11\n");
	hako_write('OUT', "0\n");
	hako_write('OUT', "\n");
	hako_write('OUT', "\n");
	hako_write('OUT', "1\n");
	hako_write('OUT', "7,12,2.5,2.5\n");

	
	hako_close('OUT');
}

/*
 * 함수: setupMode()
 * 역할: 설정 일람 파일 생성/갱신 흐름을 처리합니다.
 * 원본 대응: hako/hako-mente.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function setupMode() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	if (!($mpass1 && $mpass2) || ($mpass1 != $mpass2)) {
		echo "master password가 입력되어 있지 않은가 잘못되어 있습니다. ";
		return;
	}
	if (!($spass1 && $spass2) || ($spass1 != $spass2)) {
		echo "특수 패스워드가 입력되어 있지 않은가 잘못되어 있습니다. ";
		return;
	}

	if (file_exists($HpasswordFile)) {
		if (!$modeValue) {
			
			echo "벌써 패스워드가 설정되어 있습니다. ";
			return;
		} else {
			@unlink("$HpasswordFile");
		}
	}

	$HinputPassword = $mpass1;
	$mpass1 = crypt($mpass1, 'ma');
	$spass1 = crypt($spass1, 'sp');

	hako_open('OUT', ">$HpasswordFile");
	hako_write('OUT', <<<HAKOHDOC_2
$mpass1
$spass1
HAKOHDOC_2
);
	hako_close('OUT');
	$modeValue = (!$modeValue) ? '설정' : '변경';
	echo "패스워드를{$modeValue}했습니다.";
}

/*
 * 함수: timeMode()
 * 역할: 턴 시간 변경 화면과 저장을 처리합니다.
 * 원본 대응: hako/hako-mente.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function timeMode() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$ctMon--;
	$ctYear -= 1900;
	$ctSec = timelocal($ctSec, $ctMin, $ctHour, $ctDate, $ctMon, $ctYear);
	stimeMode();
}

/*
 * 함수: stimeMode()
 * 역할: 상세 턴 시간 변경 화면과 저장을 처리합니다.
 * 원본 대응: hako/hako-mente.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function stimeMode() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$t = $ctSec;
	hako_open('IN', "{$HdirName}/hakojima.dat");
	unset($lines); $lines = hako_read_all_lines('IN');
	hako_close('IN');

	$lines[1] = "$t\n";

	hako_open('OUT', ">{$HdirName}/hakojima.dat");
	hako_write('OUT', $lines);
	hako_close('OUT');
}

/*
 * 함수: mainMode()
 * 역할: 관리자 메인 화면을 출력합니다.
 * 원본 대응: hako/hako-mente.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function mainMode() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	echo <<<HAKOHDOC_3
<STYLE type="text/css">
<!--
A { text-decoration:none; }
A:HOVER { text-decoration:underline; }
H1, H3, H5 { display:inline; }
H5 { color: green; }
-->
</STYLE>
<FORM action="$HmenteFile" method="POST">
<H1>$title</H1>　 [<a href="$HthisFile">게임 화면에</a>]
<HR>
HAKOHDOC_3
;
	if (!(file_exists($HpasswordFile))) {
		
		echo <<<HAKOHDOC_4
<H2>master password와 특수 패스워드를 매듭지어 주세요. </H2>
<P>※입력 미스를 막기 위해서(때문에), 각각 2회씩 입력해 주세요. </P>
<B>master password：</B><BR>
(1) <INPUT type="password" name="MPASS1" value="$mpass1">&nbsp;&nbsp;(2) <INPUT type="password" name="MPASS2" value="$mpass2"><BR>
<BR>
<B>특수 패스워드：</B><BR>
(1) <INPUT type="password" name="SPASS1" value="$spass1">&nbsp;&nbsp;(2) <INPUT type="password" name="SPASS2" value="$spass2"><BR>
<BR>
<INPUT type="submit" value="패스워드를 설정한다" name="SETUP">
<BR>
<BR><B>※master password</B>
<BR>　　이 패스워드는, 모든 나라의 패스워드를 대용할 수 있습니다.
<BR>　　예를 들면, 「다른 나라의 패스워드 변경」등도 할 수 있습니다.
<BR>
<BR><B>※특수 패스워드</B>
<BR>　　이 패스워드로 「이름 변경」을 실시하면, 그 나라의 자금, 식량이 최대치가 됩니다.
<BR>　　(실제로 이름을 바꿀 필요는 없습니다. )
HAKOHDOC_4
;
		return;
	}
	if ($HinputPassword == '') { $HinputPassword = $HdefaultPassword; }
	echo <<<HAKOHDOC_5
<B>master password：</B><INPUT TYPE=password SIZE=32 MAXLENGTH=32 NAME=PASSWORD VALUE="$HinputPassword">
<INPUT type="submit" value="관리실에 들어온다" name="ADMIN">
HAKOHDOC_5
;
	$__dir_DIN = opendir("./");

	
	if (is_dir("{$HdirName}")) {
		dataPrint("");
	} else {
		echo <<<HAKOHDOC_6
<HR><INPUT TYPE="submit" VALUE="새로운 데이터를 만든다" NAME="NEW">
HAKOHDOC_6
;
	}
	
	unset($dn); $dn = null;
	while (($dn = readdir($__dir_DIN)) !== false) {
		if (hako_regex('~^{$HdirName}.bak(.*)~', $dn)) {
			dataPrint(hako_m(1));
		}
	}
	if (isset($__dir_DIN) && $__dir_DIN) { closedir($__dir_DIN); }
}

/*
 * 함수: adminMode()
 * 역할: 관리인실 화면을 출력합니다.
 * 원본 대응: hako/hako-mente.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function adminMode() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	echo <<<HAKOHDOC_7
<STYLE type="text/css">
<!--
A { text-decoration:none; }
A:HOVER { text-decoration:underline; }
H1, H3, H5 { display:inline; }
H5 { color: green; }



-->
</STYLE>
<script type="text/javascript">
<!--
function display(id) {
  if(document.getElementById){
    var obj = document.getElementById(id);
    if (obj.style.display == 'block'){
      obj.style.display='none';
    } else {
      obj.style.display='block';
    }
  }
}
-->
//-->
</SCRIPT>
<FORM action="$HmenteFile" method="POST">
[<A href="$HmenteFile">돌아온다</A>]
<H1>모형정원 공통 맵 N 관리인실</H1>　 [<a href="$HthisFile">게임 화면에</a>]
<HR>
<INPUT type=hidden name=PASSWORD value="{$HinputPassword}">
<INPUT type=hidden name=ADMIN>
<H3><span class='disaster'>※이하의 작업은, 갱신 직전에 실시하면 매우 위험합니다!</span></H3>
HAKOHDOC_7
;
	if (file_exists("./mente_lock")) {
		echo "#";
	} else {
		echo "#";
	}
	unset($exMark); $exMark = '▼';
	echo "<blockquote><h5>$exMark</h5>를 클릭하면 간단한 설명이 표시됩니다.";
	echo <<<HAKOHDOC_8
</FORM>
<a href="javascript: display('mentemd');"><h5>$exMark</h5></a>　
<H3><a href="javascript: display('mentemd');">관리모드에 대해</a></H3>
<DIV id='mentemd'>
<UL>
<LI>관리 모드는, 게임 동작을 세우는 기능입니다.
<LI>모형정원 데이터를 직접 수정하고 싶은 경우 등에 참가자가 데이터를 액세스 하는 것을 막습니다.
</UL></DIV><BR><BR>
HAKOHDOC_8
;

	echo <<<HAKOHDOC_9
<FORM name="CHANGEPW" action="{$HmenteFile}" method=POST>
<a href="javascript: display('changpw');"><h5>$exMark</h5></a>　
<H3><a href="javascript: display('changpw');">master password·특수 패스워드의 변경</a></H3>
<DIV id='changpw'>
<INPUT type=hidden name=PASSWORD value="{$HinputPassword}">
<P>※새로운 패스워드는, 입력 미스를 막기 위해서(때문에), 각각 2회씩 입력해 주세요. </P>
<B>새로운 master password：</B><BR>
(1) <INPUT type="password" name="MPASS1" value="$mpass1">&nbsp;&nbsp;(2) <INPUT type="password" name="MPASS2" value="$mpass2"><BR>
<BR>
<B>새로운 특수 패스워드：</B><BR>
(1) <INPUT type="password" name="SPASS1" value="$spass1">&nbsp;&nbsp;(2) <INPUT type="password" name="SPASS2" value="$spass2"><BR>
<BR>
　　　<INPUT type="submit" value="패스워드를 설정한다" name="CHANGEPW">
</FORM>
</DIV><BR><BR>
HAKOHDOC_9
;

	echo <<<HAKOHDOC_10
<a href="javascript: display('setupvalue');"><h5>$exMark</h5></a>　
<H3><A HREF="{$HthisFile}?SetupV={$HinputPassword}" target="_blank">설정 일람(관리자용) 표시</A>(<A HREF="{$HthisFile}?SetupV=0" target="_blank">설정 일람을 고쳐 쓴다</A>)</H3>
<DIV id='setupvalue'>
<UL>
<LI>관리자용과 탑 페이지의 링크와의 차이는, 플레이어에 공개하지 않는 설정도 열람할 수 있는 것 정도입니다.
<LI>설정을 변경했을 때 등은, html를 고쳐 써 두면 좋을 것입니다.
</UL></DIV><BR><BR>
HAKOHDOC_10
;

	echo <<<HAKOHDOC_11
<a href="javascript: display('predelete');"><h5>$exMark</h5></a>　
<H3><A HREF="{$HthisFile}?Pdelete={$HinputPassword}" target="_blank">참가국을 관리인 보관으로 한다</A></H3>
<DIV id='predelete'>
<UL>
<LI>예 빌리고된 나라는 일절의 명령 처리를 할 수 없는 대신에 재해도 일어나지 않습니다. (타국으로부터 괴수가 침입하는 것은 있다) 
<LI>인구나 숲의 갯수도 증가하지 않습니다. 식량은 전혀 소비합니다만, 수입도 없습니다.  
<LI>타국은 전부 우호국의 취급이 됩니다. (전쟁중에서 만나도) 
</UL></DIV><BR><BR>
HAKOHDOC_11
;

	echo <<<HAKOHDOC_12
<a href="javascript: display('delisland');"><h5>$exMark</h5></a>　
<H3><a href="javascript: display('delisland');">참가국을 강제 삭제한다</A></H3>
<DIV id='delisland'>
<UL>
<LI><A HREF="$HbaseDir/hako-main.php?settei={$HinputPassword}" target="_blank">「나라의 이름과 패스워드의 변경」</a>의 입력 폼으로, 해당의 나라의 이름을 「무인」국으로 해 주세요.
<LI>그 때, 패스워드란에는 「특수 패스워드」를 입력해 주세요. (새로운 패스와 패스 확인란은 없음)
</UL></DIV><BR><BR>
HAKOHDOC_12
;

	echo <<<HAKOHDOC_13
<a href="javascript: display('datachange');"><h5>$exMark</h5></a>　
<H3><A HREF="$HbaseDir/hako-main.php?Ichange={$HinputPassword}" target="_blank">각종국 데이터를 강제 변경한다</A></H3>
<DIV id='datachange'>
<UL>
<LI>debug용입니다. 참가자의 동의를 얻지 않는 사용은 추천 하지 않습니다.
<LI>진영을 변경하는 목적 이외의 사용은 추천 하지 않습니다.
</UL></DIV><BR><BR>
HAKOHDOC_13
;

	echo <<<HAKOHDOC_14
<a href="javascript: display('mapchange');"><h5>$exMark</h5></a>　
<H3><A HREF="$HbaseDir/hako-main.php?Lchange={$HinputPassword}" target="_blank">지형 데이터를 변경한다</A></H3>
<DIV id='mapchange'>
<UL>
<LI>debug용입니다. <B>통상 운용중의 데이터는 고쳐 쓰지 말아 주세요. </B>
<LI>털기의 피해나, 서버 트러블, 스크립트의 버그등으로, 지형 데이터가 본의가 아닌 상태가 되어 버렸을 경우 등 긴급시에도 사용할 수도 있습니다만
<LI>「지형」과「지형의 값」에 대한 지식이 없으면 사용은 어려울지도 모릅니다. 예를 들어 「바다」에서 값을 1으로 하면(자) 「얕은 여울」이 되거나 도시의 인구의 표시상의 수치와 데이터상의 수치의 차이(10000명이 100으로 기록되어 있거나 하므로)나, 농장이나 공장의 발전 규모로 취할 수 있는 수치가 정해져 있는 것 등(hako-make.php의 sub landCheck로 간이 체크를 하도록(듯이) 하고 있습니다).
<LI>또, 인구, 농장 규모등의 수치 데이터에의 반영은 턴 갱신 처리를 하고 나서가 되므로, 주의해 주세요.
</UL></DIV><BR><BR>
HAKOHDOC_14
;

	echo <<<HAKOHDOC_15
<a href="javascript: display('dewarsetup');"><h5>$exMark</h5></a>　
<H3><A HREF="$HbaseDir/hako-main.php?AWchange={$HinputPassword}" target="_blank">우호·전쟁 데이터를 강제 변경한다</A></H3>
<DIV id='dewarsetup'>
<UL>
<LI>debug용입니다. 참가자의 동의를 얻지 않는 사용은 추천 하지 않습니다.
</UL></DIV><BR><BR>
HAKOHDOC_15
;

	echo <<<HAKOHDOC_16
<a href="javascript: display('popsol');"><h5>$exMark</h5></a>　
<H3><a href="javascript: display('popsol');">인구·총병력 추이 일람 데이터</a></H3>
<DIV id='popsol'>
<FORM action="$HmenteFile" method="POST">
<INPUT type=hidden name=PASSWORD value="{$HinputPassword}">
<INPUT type=hidden name=ADMIN>
파일
<SELECT NAME="PSTURN">
<OPTION VALUE="0" SELECTED>0
<OPTION VALUE="1">1
<OPTION VALUE="2">2
<OPTION VALUE="3">3
<OPTION VALUE="4">4
</SELECT>
<INPUT TYPE="submit" VALUE="인구·총병력 추이 일람 데이터" NAME="POPSOL">
</FORM>
</DIV><BR><BR>
HAKOHDOC_16
;
	if ($popsolMode) { popsolMode($psturn); }
}


/*
 * 함수: dataPrint()
 * 역할: 관리자 데이터 표시 모드 출력입니다.
 * 원본 대응: hako/hako-mente.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function dataPrint() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	unset($suf); $suf = isset($_args[0]) ? $_args[0] : null;

	echo "<HR>";
	if ($suf == "") {
		hako_open('IN', "{$HdirName}/hakojima.dat");
		echo "<H1>현역 데이터</H1>";
	} else {
		hako_open('IN', "{$HdirName}.bak$suf/hakojima.dat");
		echo "<H1>백업 $suf</H1>";
	}

	unset($lastTurn); $lastTurn = null;
	$lastTurn = hako_getline('IN');
	unset($lastTime); $lastTime = null;
	$lastTime = hako_getline('IN');

	$timeString = timeToString($lastTime);

	echo <<<HAKOHDOC_17
	　<H3>[턴 $lastTurn]</H3><BR>
	<B>최종 갱신 시간</B>:$timeString<BR>
	<B>최종 갱신 시간(초수의 표시)</B>:1970연 1월 1일부터 {$lastTime}초<BR>
	<INPUT TYPE="submit" VALUE="이 데이터를 삭제" NAME="DELETE$suf">
HAKOHDOC_17
;

	if ($suf == "") {
	$_list_tmp = hako_localtime($lastTime);
	unset($sec); $sec = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
	unset($min); $min = isset($_list_tmp[1]) ? $_list_tmp[1] : null;
	unset($hour); $hour = isset($_list_tmp[2]) ? $_list_tmp[2] : null;
	unset($date); $date = isset($_list_tmp[3]) ? $_list_tmp[3] : null;
	unset($mon); $mon = isset($_list_tmp[4]) ? $_list_tmp[4] : null;
	unset($year); $year = isset($_list_tmp[5]) ? $_list_tmp[5] : null;
	unset($day); $day = isset($_list_tmp[6]) ? $_list_tmp[6] : null;
	unset($yday); $yday = isset($_list_tmp[7]) ? $_list_tmp[7] : null;
	unset($dummy); $dummy = isset($_list_tmp[8]) ? $_list_tmp[8] : null;
	$mon++;
	$year += 1900;

	echo <<<HAKOHDOC_18
<H2>최종 갱신 시간의 변경</H2>
<INPUT TYPE="text" SIZE=4 NAME="YEAR" VALUE="$year">년
<INPUT TYPE="text" SIZE=2 NAME="MON" VALUE="$mon">월
<INPUT TYPE="text" SIZE=2 NAME="DATE" VALUE="$date">일
<INPUT TYPE="text" SIZE=2 NAME="HOUR" VALUE="$hour">시
<INPUT TYPE="text" SIZE=2 NAME="MIN" VALUE="$min">분
<INPUT TYPE="text" SIZE=2 NAME="NSEC" VALUE="$sec">초
<INPUT TYPE="submit" VALUE="변경" NAME="NTIME"><BR>
1970년 1월 1일부터<INPUT TYPE="text" SIZE=32 NAME="SSEC" VALUE="$lastTime">초
<INPUT TYPE="submit" VALUE="초지정으로 변경" NAME="STIME">
<br>
<INPUT TYPE="submit" VALUE="갱신 시간을 상세 설정한다" NAME="KTIMESET">
HAKOHDOC_18
;
	} else {
	echo <<<HAKOHDOC_19
	<INPUT TYPE="submit" VALUE="이 데이터를 현역에게" NAME="CURRENT$suf">
HAKOHDOC_19
;
	}
}

/*
 * 함수: timeToString()
 * 역할: 시간 값을 화면 표시 문자열로 변환합니다.
 * 원본 대응: hako/hako-mente.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function timeToString() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$_list_tmp = hako_localtime(isset($_args[0]) ? $_args[0] : time());
	unset($sec); $sec = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
	unset($min); $min = isset($_list_tmp[1]) ? $_list_tmp[1] : null;
	unset($hour); $hour = isset($_list_tmp[2]) ? $_list_tmp[2] : null;
	unset($date); $date = isset($_list_tmp[3]) ? $_list_tmp[3] : null;
	unset($mon); $mon = isset($_list_tmp[4]) ? $_list_tmp[4] : null;
	unset($year); $year = isset($_list_tmp[5]) ? $_list_tmp[5] : null;
	unset($day); $day = isset($_list_tmp[6]) ? $_list_tmp[6] : null;
	unset($yday); $yday = isset($_list_tmp[7]) ? $_list_tmp[7] : null;
	unset($dummy); $dummy = isset($_list_tmp[8]) ? $_list_tmp[8] : null;
	$mon++;
	$year += 1900;

	return "{$year}년 {$mon}월 {$date}일 {$hour}시 {$min}분 {$sec}초";
}


/*
 * 함수: requestInput()
 * 역할: GET/POST 입력값을 원본 CGI의 cgiInput 역할에 맞춰 전역 변수로 정리합니다.
 * 원본 대응: hako/hako-mente.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function requestInput() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	unset($line); $line = null;

	
	$line = file_get_contents("php://input");
	$line = strtr($line, '+', ' ');
	$line = rawurldecode(str_replace("+", " ", $line));

	
	$getLine = hako_get_env('QUERY_STRING');




	if (hako_regex('~DELETE([0-9]*)~', $line)) {
		$mainMode = 'delete';
		$deleteID = hako_m(1);
	} elseif (hako_regex('~CURRENT([0-9]*)~', $line)) {
		$mainMode = 'current';
		$currentID = hako_m(1);
	} elseif (hako_regex('~NEW~', $line)) {
		$mainMode = 'new';
	} elseif (hako_regex('~UNMENTE~', $line)) {
		$mainMode = 'unmente';
	} elseif (hako_regex('~MENTE~', $line)) {
		$mainMode = 'mente';
	} elseif (hako_regex('~POPSOL~', $line)) {
		$mainMode = 'popsol';
		if (hako_regex('~PSTURN=([0-9]*)~', $line)) { $psturn = hako_m(1); }
	} elseif (hako_regex('~ADMIN~', $line)) {
		$mainMode = 'admin';
	} elseif (hako_regex('~ADMIN=([^\&]*)~', $getLine)) {
		$mainMode = 'admin';
		$HinputPassword = hako_m(1);
	} elseif (hako_regex('~SETUP~', $line) || hako_regex('~CHANGEPW~', $line)) {
		$mainMode = 'setup';
		$modeValue = hako_regex('~CHANGEPW~', $line) ? 1 : 0;
		if (hako_regex('~MPASS1=([^\&]*)\&~', $line)) { $mpass1 = hako_m(1); }
		if (hako_regex('~MPASS2=([^\&]*)\&~', $line)) { $mpass2 = hako_m(1); }
		if (hako_regex('~SPASS1=([^\&]*)\&~', $line)) { $spass1 = hako_m(1); }
		if (hako_regex('~SPASS2=([^\&]*)\&~', $line)) { $spass2 = hako_m(1); }
	} elseif (hako_regex('~NTIME~', $line)) {
		$mainMode = 'time';
		if (hako_regex('~YEAR=([0-9]*)~', $line)) { $ctYear = hako_m(1); }
		if (hako_regex('~MON=([0-9]*)~', $line)) { $ctMon = hako_m(1); }
		if (hako_regex('~DATE=([0-9]*)~', $line)) { $ctDate = hako_m(1); }
		if (hako_regex('~HOUR=([0-9]*)~', $line)) { $ctHour = hako_m(1); }
		if (hako_regex('~MIN=([0-9]*)~', $line)) { $ctMin = hako_m(1); }
		if (hako_regex('~NSEC=([0-9]*)~', $line)) { $ctSec = hako_m(1); }
	} elseif (hako_regex('~STIME~', $line)) {
		$mainMode = 'stime';
		if (hako_regex('~SSEC=([0-9]*)~', $line)) { $ctSec = hako_m(1); }
	} elseif (hako_regex('~KTIMESET~', $line)) {
		$mainMode = 'ktime';
	} elseif (hako_regex('~FSETTIME~', $line)) {
		unset($i); $i = null;
		unset($fturnh); $fturnh = null;
		unset($fturnm); $fturnm = null;
		unset($tmp); $tmp = null;
		unset($tmp2); $tmp2 = null;
		unset($ct); $ct = null;
		unset($hour0); $hour0 = null;
		unset($min0); $min0 = null;
		unset($flexTime); $flexTime = array();
		$tmp = -1;
		for ($i = 0; $i < 31; $i++) {
			if (hako_regex('~FTURNH$i=([^\&]*)\&~', $line)) { $fturnh = hako_m(1); }
			if (hako_regex('~FTURNM$i=([^\&]*)\&~', $line)) { $fturnm = hako_m(1) / 100; }
			if ($fturnh >= 0) {
				$flexTime[$i] = $fturnh + $fturnm;
				if ($flexTime[$i] < $tmp) { break; }
				if ($i > 0) {
					$tmp2 = $flexTime[$i] - $tmp;
					$tmp = $flexTime[$i];
					$flexTime[$i] = $tmp2;
					$ct += $flexTime[$i];
				} else{
					$tmp = $flexTime[$i];
					$hour0 = $tmp;
				}
			} else{
				break;
			}
		}
		
		if (hako_regex('~FTURNC=([0-9]*)~', $line)) { unset($turnCt); $turnCt = hako_m(1); }
		if ($turnCt > hako_last_index($flexTime)) {
			$turnCt = hako_last_index($flexTime);
		}
		
		$flexTime[0] = 24 - $ct;
		$mainMode = 'fsettime';
		$hour0 -= $flexTime[0];
		for ($i = 0;$i < $turnCt;$i++) {
			$hour0 += $flexTime[$i];
		}
		if ($hour0 < 0) { $hour0 += 24; }
		$min0 = ($hour0 - intval($hour0)) * 60;

		echo "설정했습니다. <br>반드시,<a href=$HmenteFile>[멘테 화면 TOP]</a> 로<b>최종 갱신 시간을 지나지 않은가 확인 바랍니다.</b><br>";

		hako_open('IN', "{$HdirName}/hakojima.dat");
		unset($lines); $lines = hako_read_all_lines('IN');
		hako_close('IN');

		$_list_tmp = hako_localtime(isset($lines[1]) ? $lines[1] : time());
		unset($sec); $sec = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
		unset($min); $min = isset($_list_tmp[1]) ? $_list_tmp[1] : null;
		unset($hour); $hour = isset($_list_tmp[2]) ? $_list_tmp[2] : null;
		unset($date); $date = isset($_list_tmp[3]) ? $_list_tmp[3] : null;
		unset($mon); $mon = isset($_list_tmp[4]) ? $_list_tmp[4] : null;
		unset($year); $year = isset($_list_tmp[5]) ? $_list_tmp[5] : null;
		unset($day); $day = isset($_list_tmp[6]) ? $_list_tmp[6] : null;
		unset($yday); $yday = isset($_list_tmp[7]) ? $_list_tmp[7] : null;
		unset($dummy); $dummy = isset($_list_tmp[8]) ? $_list_tmp[8] : null;
		$_list_tmp = array(0, $min0, $hour0);
		$sec = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
		$min = isset($_list_tmp[1]) ? $_list_tmp[1] : null;
		$hour = isset($_list_tmp[2]) ? $_list_tmp[2] : null;
		$ctSec = timelocal($sec, $min, $hour, $date, $mon, $year);

		$lines[1] = "$ctSec\n";
		$lines[8] = "$turnCt\n";
		$lines[9] = join(',', $flexTime) . "\n";

		hako_open('OUT', ">{$HdirName}/hakojima.dat");
		hako_write('OUT', $lines);
		hako_close('OUT');
	}
	if (hako_regex('~PASSWORD=([^\&]*)\&~', $line)) { $HinputPassword = hako_m(1); }
}


/*
 * 함수: fileCopy()
 * 역할: 데이터/백업 파일 복사를 수행합니다.
 * 원본 대응: hako/hako-mente.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function fileCopy() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	unset($src); $src = isset($_args[0]) ? $_args[0] : null;
	unset($dist); $dist = isset($_args[1]) ? $_args[1] : null;
	hako_open('IN', $src);
	hako_open('OUT', ">$dist");
	while (($line = hako_getline('IN')) !== false) {
		hako_write('OUT', $line);
	}
	hako_close('IN');
	hako_close('OUT');
}


/*
 * 함수: passCheck()
 * 역할: 관리자 비밀번호를 확인합니다.
 * 원본 대응: hako/hako-mente.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function passCheck() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	if (checkMasterPassword($HinputPassword)) {
		return 1;
	} else {
		tempWrongPassword(); 
		echo "</BODY></HTML>";
		exit(0);
	}
}


/*
 * 함수: menteMode()
 * 역할: 메인터넌스 모드를 설정합니다.
 * 원본 대응: hako/hako-mente.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function menteMode() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
    mkdir("./mente_lock", $HdirMode);
}


/*
 * 함수: unmenteMode()
 * 역할: 메인터넌스 모드를 해제합니다.
 * 원본 대응: hako/hako-mente.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function unmenteMode() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	rmdir("./mente_lock");
}


/*
 * 함수: popsolMode()
 * 역할: 인구/총병력 통계 파일을 생성합니다.
 * 원본 대응: hako/hako-mente.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function popsolMode() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	unset($p); $p = isset($_args[0]) ? $_args[0] : null;
	echo <<<HAKOHDOC_20
인구·총병력 추이등의 일람 데이터 엑셀이라든지에 붙여 사용해 주세요.<br>
<SCRIPT LANGUAGE="JavaScript">
<!--
function textcopy(mapdata){
	window.clipboardData.setData("text",mapdata);
}
function searchID(url){
	if(document.getElementById){
		return document.getElementById(url);
	} else if(document.all){
		return document.all(url);
	} else if(document.layers){
		return document.layers[url];
	}
}
//-->
</SCRIPT>
<INPUT TYPE="button" VALUE="인구를 클립보드에 카피" onClick="textcopy(searchID('POPLIST').value)"><br>
<textarea NAME="POPLIST" cols="100" rows="2">

HAKOHDOC_20
;
	unset($line); $line = array();
	unset($line2); $line2 = array();
	unset($line3); $line3 = array();
	unset($line4); $line4 = array();
	unset($l); $l = null;
	unset($i); $i = null;
	unset($count); $count = null;
	unset($island); $island = null;
	unset($idx); $idx = array();
	unset($islands); $islands = array();
	hako_open('HIN', "{$HdirName}/pop.$p");
	while ($l = hako_getline('HIN')) {
		hako_chomp($l); hako_push($line, $l);
		$count++;
	}
	hako_close('HIN');
	unset($tmp); $tmp = explode(',', $line[0]);
	hako_splice($tmp, 0, 1);
	echo "\t" . join("\t",$tmp) . "\n";
	for ($i = 0; $i < $count-1; $i++) {
		unset($tmp); $tmp = explode(',', $line[$i+1]);
		echo join("\t",$tmp) . "\n";
	}
	echo <<<HAKOHDOC_21
</textarea><br>
<INPUT TYPE="button" VALUE="병력을 클립보드에 카피" onClick="textcopy(searchID('SOLLIST').value)"><br>
<textarea NAME="SOLLIST" cols="100" rows="2">

HAKOHDOC_21
;
	$count = 0;
	hako_open('HIN', "{$HdirName}/sol.$p");
	while ($l = hako_getline('HIN')) {
		hako_chomp($l); hako_push($line2, $l);
		$count++;
	}
	hako_close('HIN');
	unset($tmp); $tmp = explode(',', $line2[0]);
	hako_splice($tmp, 0, 1);
	echo "\t" . join("\t",$tmp) . "\n";
	for ($i = 0; $i < $count-1; $i++) {
		unset($tmp); $tmp = explode(',', $line2[$i+1]);
		echo join("\t",$tmp) . "\n";
	}
	echo <<<HAKOHDOC_22
</textarea><br>
<INPUT TYPE="button" VALUE="영토를 클립보드에 카피" onClick="textcopy(searchID('AREALIST').value)"><br>
<textarea NAME="AREALIST" cols="100" rows="2">

HAKOHDOC_22
;
	$count = 0;
	hako_open('HIN', "{$HdirName}/area.$p");
	while ($l = hako_getline('HIN')) {
		hako_chomp($l); hako_push($line3, $l);
		$count++;
	}
	hako_close('HIN');
	unset($tmp); $tmp = explode(',', $line3[0]);
	hako_splice($tmp, 0, 1);
	echo "\t" . join("\t",$tmp) . "\n";
	for ($i = 0; $i < $count-1; $i++) {
		unset($tmp); $tmp = explode(',', $line3[$i+1]);
		echo join("\t",$tmp) . "\n";
	}
	echo <<<HAKOHDOC_23
</textarea><br>
<INPUT TYPE="button" VALUE="전력 데이터를 클립보드에 카피" onClick="textcopy(searchID('POWERLIST').value)"><br>
<textarea NAME="POWERLIST" cols="100" rows="2">

HAKOHDOC_23
;
	$count = 0;
	hako_open('HIN', "{$HdirName}/power.$p");
	while ($l = hako_getline('HIN')) {
		hako_chomp($l); hako_push($line4, $l);
		$count++;
	}
	hako_close('HIN');
	unset($tmp); $tmp = explode(',', $line4[0]);
	hako_splice($tmp, 0, 1);
	echo "\t" . join("\t",$tmp) . "\n";
	for ($i = 0; $i < $count-1; $i++) {
		unset($tmp); $tmp = explode(',', $line4[$i+1]);
		echo join("\t",$tmp) . "\n";
	}
	echo "</textarea>";
}

/*
 * 함수: fTimeSetMode()
 * 역할: 상세 턴 시간 설정을 처리합니다.
 * 원본 대응: hako/hako-mente.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function fTimeSetMode() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	unset($mode); $mode = isset($_args[0]) ? $_args[0] : null;
	
	if ($HunitTime < 1) { $HunitTime = 1; }
	unset($i,$j); $i = null; $j = null;

	unset($fturnH); $fturnH = array();
	unset($fturnM); $fturnM = array();
	unset($fset); $fset = null;
	unset($turnCt); $turnCt = null;
	unset($j); $j = null;

	for ($j = 0; $j < 31; $j++) {
		$fturnH[$j] = "<SELECT NAME=FTURNH$j><OPTION VALUE=-1>-";
		for ($i = 4; $i < 28; $i++) {
			$fturnH[$j] .= "<OPTION VALUE=$i>$i";
		}
		$fturnH[$j] .= "</SELECT>";
		$fturnM[$j] = "<SELECT NAME=FTURNM$j><OPTION VALUE=0>0<OPTION VALUE=25>15<OPTION VALUE=50>30<OPTION VALUE=75>45</SELECT>";
		$jj = $j + 1;
		$turnCt .= "<OPTION VALUE=$j>$jj";
	}
	echo <<<HAKOHDOC_24
<FORM action="$HmenteFile" method="POST">
<H1>모형정원 공통 맵 N　갱신 시간 상세 설정</H1>
<hr>
HAKOHDOC_24
;
	if ($HflexTimeSet) {
	echo <<<HAKOHDOC_25
갱신하는 시간을 모두 지정해 주세요. 복수 턴을 갱신하고 싶은 경우는, 같은 시간을 지정해 주세요. <br>
반드시 작은 순서로 지정 바랍니다. (시간 지정에 모순이 맞았을 경우, 그 이후 무시됩니다)<br>
１‥$fturnH[0]샤$fturnM[0]분　11‥$fturnH[10]샤$fturnM[10]분　21‥$fturnH[20]샤$fturnM[20]분<br>
２‥$fturnH[1]샤$fturnM[1]분　12‥$fturnH[11]샤$fturnM[11]분　22‥$fturnH[21]샤$fturnM[21]분<br>
３‥$fturnH[2]샤$fturnM[2]분　13‥$fturnH[12]샤$fturnM[12]분　23‥$fturnH[22]샤$fturnM[22]분<br>
４‥$fturnH[3]샤$fturnM[3]분　14‥$fturnH[13]샤$fturnM[13]분　24‥$fturnH[23]샤$fturnM[23]분<br>
５‥$fturnH[4]샤$fturnM[4]분　15‥$fturnH[14]샤$fturnM[14]분　25‥$fturnH[24]샤$fturnM[24]분<br>
６‥$fturnH[5]샤$fturnM[5]분　16‥$fturnH[15]샤$fturnM[15]분　26‥$fturnH[25]샤$fturnM[25]분<br>
７‥$fturnH[6]샤$fturnM[6]분　17‥$fturnH[16]샤$fturnM[16]분　27‥$fturnH[26]샤$fturnM[26]분<br>
８‥$fturnH[7]샤$fturnM[7]분　18‥$fturnH[17]샤$fturnM[17]분　28‥$fturnH[27]샤$fturnM[27]분<br>
９‥$fturnH[8]샤$fturnM[8]분　19‥$fturnH[18]샤$fturnM[18]분　29‥$fturnH[28]샤$fturnM[28]분<br>
10‥$fturnH[9]샤$fturnM[9]분　20‥$fturnH[19]샤$fturnM[19]분　30‥$fturnH[29]샤$fturnM[29]분<br>
<hr>
최초의 갱신 시간　<SELECT NAME=FTURNC>$turnCt</SELECT>번째
<hr>
<B>master password:</B><INPUT TYPE=password SIZE=32 MAXLENGTH=32 NAME=PASSWORD VALUE="$HinputPassword">
<INPUT TYPE="submit" VALUE="상세 지정을 설정한다" NAME="FSETTIME">
HAKOHDOC_25
;
	} else{
	echo <<<HAKOHDOC_26
현재의 설정은, 통상 지정이 되어 있습니다. <br>
상세 설정을 실시하려면 , 「hako-init.php」의 「HflexTimeSet」를 「1」으로 해 주세요. <br>
HAKOHDOC_26
;
}
	echo <<<HAKOHDOC_27
<hr>
<a href="$HmenteFile">[멘테 화면 TOP에]</a><br>
<a href="$HthisFile">[게임 화면에]</a><br>
HAKOHDOC_27
;
}



?>
