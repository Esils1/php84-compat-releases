<?php

/*
 * hako/hako-main.php
 * ------------------------------------------------------------
 * 공통 메인/상수/입출력/잠금 모듈
 *
 * 상세 주석 기준:
 * - 원본 대응: qwmp155.zip 의 hako-main.cgi.
 * - 지형번호, 명령번호, 명령 비용/턴수, 저장 파일 입출력, 쿠키, 파일 잠금, 공통 오류 화면을 담당합니다.
 * - 이 파일의 상수값과 배열 인덱스는 저장 파일 island.*, hakojima.dat, 명령 배열 command 와 직접 연결됩니다.
 * - 화면 출력 문자열뿐 아니라 공백/줄바꿈/링크 파라미터도 CGI 원본과 비교 대상입니다.
 * - PHP 5.5 호환을 위해 DB와 CGI 실행 의존 기능을 사용하지 않습니다.
 * - 원본 CGI 주석 라인 확인 수: 292줄. PHP 주석은 실행 결과를 바꾸지 않는 범위에서 복원/보강했습니다.
 *
 * 유지보수 원칙:
 * - 실행 로직, 저장 포맷, 배열 인덱스, 출력 HTML은 원본 CGI 호환성 대상입니다.
 * - 개조가 필요하면 먼저 해당 변수/함수가 어떤 파일 저장값과 연결되는지 확인하십시오.
 * - 이 주석은 유지보수용이며 실행 결과를 바꾸지 않습니다.
 */

chdir(dirname(__FILE__));
require_once dirname(__FILE__) . '/hako-compat.php';

// CGI 원본은 화면을 순차 출력하므로 강제 출력 버퍼를 사용하지 않습니다.
// PHP 5.5 공유호스팅에서 턴 처리 중 타임아웃이 발생하면 버퍼 때문에 빈 화면처럼 보일 수 있어 제거합니다.
















//----------------------------------------------------------------------
// 버전 정보와 공통 설정
//----------------------------------------------------------------------
$versionInfo = "version1.54"; // 배포/표시용 버전 문자열입니다.





require_once './hako-init.php';
require_once './init-game.php';
require_once './init-army.php';
require_once './hako-io.php';



$unlockTime = 120; // 락 후 이 시간이 지나면 이상 종료로 보고 강제 해제 후보가 됩니다.


$cryptOn = 1; // 비밀번호 암호화 사용 여부입니다. 기존 passwd.php 호환을 위해 임의 변경하지 마십시오.





//----------------------------------------------------------------------
// 지형 번호
// 저장 파일에는 숫자로 기록되므로 값 변경 금지
//----------------------------------------------------------------------
$HlandSea      = 0; // 지형 번호: 바다
$HlandSbase    = 1; // 지형 번호: 해저 기지
$HlandMonster  = 2; // 지형 번호: 괴수
$HlandMonument = 3; // 지형 번호: 기념비
$HlandMountain = 4; // 지형 번호: 산
$HlandWaste    = 5; // 지형 번호: 황무지
$HlandPlains   = 6; // 지형 번호: 평지
$HlandTown     = 7; // 지형 번호: 마을계
$HlandForest   = 8; // 지형 번호: 숲
$HlandFarm     = 9; // 지형 번호: 농장
$HlandFactory  = 10; // 지형 번호: 공장
$HlandBase     = 11; // 지형 번호: 미사일 기지
$HlandDefence  = 12; // 지형 번호: 방위 시설
$HlandSupply   = 13; // 지형 번호: 병참 기지




//----------------------------------------------------------------------
// 명령 번호
// 명령 배열 command 의 kind 값과 직접 연결됨
//----------------------------------------------------------------------
$HcomPrepare  = 1; // 명령 번호: 개간
$HcomPrepare2 = 2; // 명령 번호: 땅 고르기
$HcomReclaim  = 3; // 명령 번호: 매립
$HcomDestroy  = 4; // 명령 번호: 굴착


$HcomFarm2    = 7; // 명령 번호: 고속 농장
$HcomFactory2 = 8; // 명령 번호: 고속 공장
$HcomPlant    = 11; // 명령 번호: 식림
$HcomFarm     = 12; // 명령 번호: 농장 정비
$HcomFactory  = 13; // 명령 번호: 공장 건설
$HcomMountain = 14; // 명령 번호: 채굴장 건설
$HcomBase     = 15; // 명령 번호: 미사일 기지 건설
$HcomDbase    = 16; // 명령 번호: 방위 시설 건설
$HcomSbase    = 17; // 명령 번호: 해저 기지 건설
$HcomMonument = 18; // 명령 번호: 기념비 건설
$HcomArea     = 20; // 명령 번호: 영토 할양
$HcomSupply   = 21; // 명령 번호: 병참 기지 건설
$HcomDraft    = 22; // 명령 번호: 징병
$HcomInfantry = 23; // 명령 번호: 부대 설치
$HcomWithdraw = 24; // 명령 번호: 부대 철퇴
$HcomItem     = 25; // 명령 번호: 아이템 장비


$HcomMissileNM   = 31; // 명령 번호: 미사일 발사
$HcomMissilePP   = 32; // 명령 번호: PP 미사일 발사
$HcomMissileDM   = 33; // 명령 번호: ST/방어 계열 미사일 발사
$HcomMissileLD   = 34; // 명령 번호: 육지파괴 미사일 발사
$HcomSendMonster = 35; // 명령 번호: 괴수 파견
$HcomMissileHM   = 36; // 명령 번호: 핵/고위력 계열 미사일 발사
$HcomMissileBM   = 37; // 명령 번호: 광역/특수 미사일 발사


$HcomDoNothing  = 41; // 명령 번호: 대기/아무것도 하지 않음
$HcomSell       = 42; // 명령 번호: 식량 판매
$HcomMoney      = 43; // 명령 번호: 자금 원조
$HcomFood       = 44; // 명령 번호: 식량 원조
$HcomPropaganda = 45; // 명령 번호: 선전/외교 행동
$HcomGiveup     = 46; // 명령 번호: 섬 포기
$HcomAmity      = 47; // 명령 번호: 우호 조약
$HcomUnitOrder  = 48; // 명령 번호: 부대 명령
$HcomDeWar      = 49; // 명령 번호: 선전포고/전쟁 관련
$HcomSoldier    = 50; // 명령 번호: 병력 관련
$HcomCeasefire  = 51; // 명령 번호: 정전/전쟁 해제
$HcomSoldier2   = 52; // 명령 번호: 추가 병력 관련


$HcomAutoPrepare   = 61; // 자동 명령 번호: 자동 개간
$HcomAutoPrepare2  = 62; // 자동 명령 번호: 자동 땅 고르기
$HcomAutoDelete    = 68; // 자동 명령 번호: 자동 삭제/정리



//----------------------------------------------------------------------
// 명령 이름/비용/소요 턴 설정
// 화면 표시와 턴 처리 비용 판정에 동시에 사용됨
//----------------------------------------------------------------------
$HcomName[$HcomPrepare]  = '개간';
$HcomCost[$HcomPrepare]  = 5;
$HcomTurn[$HcomPrepare]  = 1;
$HcomName[$HcomPrepare2] = '땅 고르기';
$HcomCost[$HcomPrepare2] = 50;
$HcomTurn[$HcomPrepare2] = 0;
$HcomName[$HcomReclaim]  = '매립';
$HcomCost[$HcomReclaim]  = 90;
$HcomTurn[$HcomReclaim]  = 1;
$HcomName[$HcomDestroy]  = '굴착';
$HcomCost[$HcomDestroy]  = 90;
$HcomTurn[$HcomDestroy]  = 1;
$HcomName[$HcomPlant]    = '식림';
$HcomCost[$HcomPlant]    = 30;
$HcomTurn[$HcomPlant]    = 1;
$HcomName[$HcomFarm]     = '농장 건설';
$HcomCost[$HcomFarm]     = 20;
$HcomTurn[$HcomFarm]     = 1;
$HcomName[$HcomFactory]  = '공장 건설';
$HcomCost[$HcomFactory]  = 60;
$HcomTurn[$HcomFactory]  = 1;
$HcomName[$HcomFarm2]    = '고속 농장';
$HcomCost[$HcomFarm2]    = 180;
$HcomTurn[$HcomFarm2]    = 0;
$HcomName[$HcomFactory2] = '고속 공장';
$HcomCost[$HcomFactory2] = 180;
$HcomTurn[$HcomFactory2] = 0;
$HcomName[$HcomMountain] = '채굴장 정비';
$HcomCost[$HcomMountain] = 120;
$HcomTurn[$HcomMountain] = 1;
$HcomName[$HcomBase]     = '미사일 기지 건설';
$HcomCost[$HcomBase]     = 100;
$HcomTurn[$HcomBase]     = 1;
$HcomName[$HcomDbase]    = '방위 시설 건설';
$HcomCost[$HcomDbase]    = 150;
$HcomTurn[$HcomDbase]    = 1;
$HcomName[$HcomSbase]    = '해저 기지 건설';
$HcomCost[$HcomSbase]    = 500;
$HcomTurn[$HcomSbase]    = 1;
$HcomName[$HcomMonument] = '방벽 건설';
$HcomCost[$HcomMonument] = 40;
$HcomTurn[$HcomMonument] = 1;
$HcomName[$HcomArea]     = '영토 할양';
$HcomCost[$HcomArea]     = 0;
$HcomTurn[$HcomArea]     = 0;
$HcomName[$HcomSupply]   = '병참 기지 건설';
$HcomCost[$HcomSupply]   = 10;
$HcomTurn[$HcomSupply]   = 1;
$HcomName[$HcomDraft]    = '징병';
$HcomCost[$HcomDraft]    = 10;
$HcomTurn[$HcomDraft]    = 0;
$HcomName[$HcomInfantry] = '부대 설치';
$HcomCost[$HcomInfantry] = 5;
$HcomTurn[$HcomInfantry] = 0;
$HcomName[$HcomWithdraw] = '부대 취소';
$HcomCost[$HcomWithdraw] = 10;
$HcomTurn[$HcomWithdraw] = 0;
$HcomName[$HcomItem]     = '아이템 장비';
$HcomCost[$HcomItem]     = 30;
$HcomTurn[$HcomItem]     = 0;
$HcomName[$HcomUnitOrder]= '부대 방향 변경';
$HcomCost[$HcomUnitOrder]= 0;
$HcomTurn[$HcomUnitOrder]= 0;
$HcomName[$HcomSoldier]  = '예비병 원조';
$HcomCost[$HcomSoldier]  = 0;
$HcomTurn[$HcomSoldier]  = 0;
$HcomName[$HcomSoldier2] = '용병 수출';
$HcomCost[$HcomSoldier2] = 60;
$HcomTurn[$HcomSoldier2] = 0;
$HcomName[$HcomMissileNM]= '미사일 발사';
$HcomCost[$HcomMissileNM]= 25;
$HcomTurn[$HcomMissileNM]= 1;
$HcomName[$HcomMissilePP]= 'PP미사일 발사';
$HcomCost[$HcomMissilePP]= 30;
$HcomTurn[$HcomMissilePP]= 1;
$HcomName[$HcomMissileDM]= '확산 미사일 발사';
$HcomCost[$HcomMissileDM]= 25;
$HcomTurn[$HcomMissileDM]= 1;
$HcomName[$HcomMissileLD]= '육지 파괴탄 발사';
$HcomCost[$HcomMissileLD]= 100;
$HcomTurn[$HcomMissileLD]= 1;
$HcomName[$HcomMissileHM]= '대인 미사일 발사';
$HcomCost[$HcomMissileHM]= 70;
$HcomTurn[$HcomMissileHM]= 0;
$HcomName[$HcomMissileBM]= '탄도 미사일 발사';
$HcomCost[$HcomMissileBM]= 100;
$HcomTurn[$HcomMissileBM]= 1;
$HcomName[$HcomSendMonster]= '괴수 파견';
$HcomCost[$HcomSendMonster]= 2500;
$HcomTurn[$HcomSendMonster]= 1;
$HcomName[$HcomDoNothing]  = '자금 유통';
$HcomCost[$HcomDoNothing]  = 0;
$HcomTurn[$HcomDoNothing]  = 1;
$HcomName[$HcomSell]       = '식량 수출';
$HcomCost[$HcomSell]       = -100;
$HcomTurn[$HcomSell]       = 0;
$HcomName[$HcomMoney]      = '자금 원조';
$HcomCost[$HcomMoney]      = 10;
$HcomTurn[$HcomMoney]      = 0;
$HcomName[$HcomFood]       = '식량 원조';
$HcomCost[$HcomFood]       = -100;
$HcomTurn[$HcomFood]       = 0;
$HcomName[$HcomPropaganda] = '유치 활동';
$HcomCost[$HcomPropaganda] = 500;
$HcomTurn[$HcomPropaganda] = 1;
$HcomName[$HcomGiveup]     = '나라의 방폐';
$HcomCost[$HcomGiveup]     = 0;
$HcomTurn[$HcomGiveup]     = 1;
$HcomName[$HcomAmity]      = '우호 타진';
$HcomCost[$HcomAmity]      = 0;
$HcomTurn[$HcomAmity]      = 0;
$HcomName[$HcomDeWar]      = '선전 포고';
$HcomCost[$HcomDeWar]      = 0;
$HcomTurn[$HcomDeWar]      = 0;
$HcomName[$HcomCeasefire]  = '정전 타진';
$HcomCost[$HcomCeasefire]  = 0;
$HcomTurn[$HcomCeasefire]  = 0;
$HcomName[$HcomAutoPrepare]  = '개간 자동 입력';
$HcomCost[$HcomAutoPrepare]  = 0;
$HcomTurn[$HcomAutoPrepare]  = 0;
$HcomName[$HcomAutoPrepare2] = '땅 고르기 자동 입력';
$HcomCost[$HcomAutoPrepare2] = 0;
$HcomTurn[$HcomAutoPrepare2] = 0;
$HcomName[$HcomAutoDelete]   = '모든 계획을 취소';
$HcomCost[$HcomAutoDelete]   = 0;
$HcomTurn[$HcomAutoDelete]   = 0;

$HcomMsg[$HcomPrepare]     = '황무지를 평지로 합니다.';
$HcomMsg[$HcomPrepare2]    = '턴 소비 없는 개간 입니다. 그만큼 비쌉니다.';
$HcomMsg[$HcomReclaim]     = '매립해서 바다를 얕은 여울로 얕은 여울을 황무지로 바꿉니다.';
$HcomMsg[$HcomDestroy]     = '산을 황무지로 황무지를 얕은 여울로 얕은 여울은 바다로 바꿉니다.';
$HcomMsg[$HcomPlant]       = '평지를 숲으로 바꿉니다.';
$HcomMsg[$HcomFarm]        = '농장을 건설 합니다. 추가 건설을 할 수 있습니다.';
$HcomMsg[$HcomFactory]     = '공장을 건설 합니다. 추가 건설을 할 수 있습니다.';
$HcomMsg[$HcomFarm2]       = '턴 소비없는 농장을 건설합니다. 추가 건설을 할 수 있습니다.';
$HcomMsg[$HcomFactory2]    = '턴 소비없는 공장을 건설합니다. 추가 건설을 할 수 있습니다.';
$HcomMsg[$HcomMountain]    = '산에 채굴장을 건설 합니다. 추가 건설을 할 수 있습니다.';
$HcomMsg[$HcomBase]        = '미사일 건설에 필요합니다.';
$HcomMsg[$HcomDbase]       = '방위 시설을 건설합니다. (추가 건설(자폭) 비는, 3배입니다)';
$HcomMsg[$HcomSbase]       = '자국과는 관계없이 모든 바다에 건설 가능(얕은 여울은 불가)입니다.';
$HcomMsg[$HcomMonument]    = '방벽·기념비를 건설합니다';
$HcomMsg[$HcomArea]        = '수량 1일경우 부대마다 양도 합니다. 턴소비 없음.';
$HcomMsg[$HcomSupply]      = '신규는 턴 소비 있음(변경은 턴 소비 없음)';
$HcomMsg[$HcomDraft]       = '마을계의 인구를 반징병해 예비병으로 짜넣습니다. 턴 소비 없음';
$HcomMsg[$HcomInfantry]    = '예비병을 병참기지등에 설치합니다. 턴 소비 없음';
$HcomMsg[$HcomWithdraw]    = '부대를 취소합니다. 일정수이상의 경우 수량 1으로 초토(황무지화)가 가능. 턴 소비 없음(취소는 턴 처리의 최후)';
$HcomMsg[$HcomUnitOrder]   = '턴 소비 없음/수량으로 군단/X좌표로 방향을 지정(0 대기, 1 우상, 2 오른쪽, 3 우하, 4 좌하, 5왼쪽, 6 좌상)';
$HcomMsg[$HcomItem]        = '턴 소비 없음/수량으로 아이템의 종류를 지정/이미 아이템이 없으면 사용할 수 없는';
$HcomMsg[$HcomSoldier]     = '턴 소비 없음/예비병 원조합니다';
$HcomMsg[$HcomSoldier2]    = '턴 소비 없음/예비병 매각합니다';
$HcomMsg[$HcomMissileNM]   = '오차 1/목표는 좌표로 지정';
$HcomMsg[$HcomMissilePP]   = '오차 1(중심 명중율 2배)/목표는 좌표로 지정';
$HcomMsg[$HcomMissileDM]   = '오차 2/목표는 좌표로 지정';
$HcomMsg[$HcomMissileLD]   = '오차 2/목표는 좌표로 지정/육지를 얕은 여울로 합니다. ';
$HcomMsg[$HcomMissileHM]   = '오차 0/목표는 좌표로 지정/1발고정/자국만 착탄/마을계·병사만 피해/그 외 지형에는 무해';
$HcomMsg[$HcomMissileBM]   = '오차 1/목표는 좌표로 지정/사정이＋5 필드';
$HcomMsg[$HcomSendMonster] = '목표는 좌표로 지정';
$HcomMsg[$HcomDoNothing]   = '자금융통(소액의 자금을 입수할 수 있습니다.';
$HcomMsg[$HcomSell]        = '식량 수출합니다. 턴 소비 없음.';
$HcomMsg[$HcomMoney]       = '자금원조 합니다. 턴 소비 없음';
$HcomMsg[$HcomFood]        = '식량 원조합니다. 턴 소비 없음';
$HcomMsg[$HcomPropaganda]  = '유치 활동을 실시해, 인구를 늘립니다. ';
$HcomMsg[$HcomGiveup]      = '나라의 방폐(게임을 도중에 그만둡니다)';
$HcomMsg[$HcomAmity]       = '턴 소비 없음';
$HcomMsg[$HcomDeWar]       = '턴 소비 없음';
$HcomMsg[$HcomCeasefire]   = '턴 소비 없음';






$defaultID = isset($defaultID) ? $defaultID : null;
$defaultTarget = isset($defaultTarget) ? $defaultTarget : null;
$HskipAutoTurn = 0; // 턴 처리 직후 리다이렉트 표시 화면에서 자동 턴 재진입을 1회 막습니다.
$HautoTurnPending = 0; // 자동 턴 시각이 지났지만 화면 출력을 우선할 때 표시용 플래그입니다.
$HmanualTurnRequest = 0; // 사용자가 명시적으로 1턴 진행을 요청한 경우에만 턴 처리합니다.
$HautoTurnBacklog = 0; // 2턴 이상 밀렸을 때 화면 표시용 밀린 턴 수입니다.


$HpointNumber = $HislandSize * $HislandSize;




$Body = "<BODY $htmlBody>";



if (!hakolock()) {
	
	
	tempHeader(0);

	
	tempLockFail();

	
	tempFooter();

	
	exit(0);
}


srand(time() ^ hako_safe_pid());


cookieInput();


requestInput();

if (file_exists($HpasswordFile)) {
	
	hako_open('PIN', "<$HpasswordFile");
	$HmasterPassword = hako_getline('PIN'); hako_chomp($HmasterPassword);
	$HspecialPassword = hako_getline('PIN'); hako_chomp($HspecialPassword);
	hako_close('PIN');
} else {
	unlock();
	tempHeader();
	tempNoHpasswordFile();
	tempFooter();
	exit(0);
}


if ((file_exists("./mente_lock")) && ($HdefaultPassword != $HmasterPassword)) {
	cookieOutput();
	unlock();
	mente_mode(1);
}


if (readIslandsFile($HcurrentID) == 0) {
	unlock();
	tempHeader(0);
	tempNoDataFile();
	tempFooter();
	exit(0);
}


tempInitialize();


cookieOutput();



if ($deleteIslandId) {
	$HcurrentID = $deleteIslandId;
	require_once 'hako-make.php';
	deleteIsland(1);
}

if ($HmainMode == 'owner' ||
		$HmainMode == 'commandJava' ||
		$HmainMode == 'command2' ||
		$HmainMode == 'comment' ||
		$HmainMode == 'ragnarok' ||
		$HmainMode == 'custom' ||
		$HmainMode == 'force' ||
		($HmainMode == 'lbbs' && $HlbbsMode % 2 == 1)) {
	require_once 'hako-js.php';
	require_once 'hako-map.php';
	if ($HtopAxes == 1) { axeslog(); }
	tempHeader(1);
	if ($HmainMode == 'commandJava') {
		commandJavaMain();
	} elseif ($HmainMode == 'command2') {
		commandMain();
	} elseif ($HmainMode == 'comment') {
		commentMain();
	} elseif ($HmainMode == 'ragnarok') {
		require_once 'hako-make.php';
		ragnarokMain();
	} elseif ($HmainMode == 'custom') {
		customMain();
	} elseif ($HmainMode == 'force') {
		forceMain();
	} elseif ($HmainMode == 'lbbs') {
		localBbsMain();
	} else {
		ownerMain();
	}
	tempFooter();
	exit(0);
} else {
	tempHeader(0);
	if ($HmainMode == 'turn') {
		// 원본 CGI와 동일하게 헤더 출력 후 같은 요청에서 턴 처리와 topPageMain() 출력을 수행합니다.
		// 리다이렉트 방식은 헤더/출력 순서를 바꾸므로 사용하지 않습니다.
		hako_prepare_long_turn();
		require_once 'hako-turn.php';
		require_once 'hako-top.php';
		turnMain();
	} elseif ($HmainMode == 'new') {
		require_once 'hako-make.php';
		require_once 'hako-map.php';
		newIslandMain();
	} elseif ($HmainMode == 'print') {
		require_once 'hako-map.php';
		printIslandMain();
	} elseif ($HmainMode == 'lbbs') {
		require_once 'hako-map.php';
		require_once 'hako-js.php';
		localBbsMain();
	} elseif ($HmainMode == 'change') {
		require_once 'hako-make.php';
		changeMain();
	} elseif ($HmainMode == 'alist') {
		require_once 'hako-top.php';
		topPageAlist();
	} elseif ($HmainMode == 'settei') {
		require_once 'hako-top.php';
		topPageMain(2);
	} elseif ($HmainMode == 'camp') {
		require_once 'hako-map.php';
		require_once 'hako-camp.php';
		campMain();
	} elseif ($HmainMode == 'predelete') {
		require_once 'hako-make.php';
		preDeleteMain();
	} elseif ($HmainMode == 'ichange') {
		require_once 'hako-make.php';
		ichangeMain(0);
	} elseif ($HmainMode == 'awchange') {
		require_once 'hako-make.php';
		ichangeMain(1);
	} elseif ($HmainMode == 'lchange') {
		require_once 'hako-map.php';
		require_once 'hako-make.php';
		lchangeMain();
	} elseif ($HmainMode == 'setupv') {
		require_once 'hako-help.php';
		setupValue();
	} elseif ($HmainMode == 'meditor') {
		require_once 'hako-make.php';
		require_once 'hako-map.php';
		mapeditorMain();
	} else {
		require_once 'hako-top.php';
		topPageMain($Htopmode);
	}
	tempFooter();
	exit(0);
}


/*
 * 함수: slideFront()
 * 역할: 명령 배열에서 지정 위치의 명령을 한 칸 앞쪽으로 이동합니다. 원본의 계획 순서 변경 동작을 유지합니다.
 * 원본 대응: hako/hako-main.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function slideFront(&$command, $number) {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if (!in_array($__hako_global_key, array('GLOBALS','command','number'), true)) { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	unset($i); $i = null;

	
	hako_splice($command, $number, 1);

	

	$command[] = array('kind'=>$HcomDoNothing, 'target'=>0, 'x'=>0, 'y'=>0, 'arg'=>0);
}


/*
 * 함수: slideBack()
 * 역할: 명령 배열에서 지정 위치의 명령을 한 칸 뒤쪽으로 이동합니다. 삭제가 아니라 순서 조정입니다.
 * 원본 대응: hako/hako-main.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function slideBack(&$command, $number, $kind=0, $target=0, $x=0, $y=0, $arg=0) {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if (!in_array($__hako_global_key, array('GLOBALS','command','number','kind','target','x','y','arg'), true)) { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();

	
		if ($number == hako_last_index($command)) { return; }
		$__hako_dup_command = isset($command[$number]) ? $command[$number] : array('kind'=>$HcomDoNothing, 'target'=>0, 'x'=>0, 'y'=>0, 'arg'=>0);
			hako_splice($command, $number, 0, array($__hako_dup_command));
		if ($kind > 0) {
			$command[$number] = array('kind'=>$kind, 'target'=>$target, 'x'=>$x, 'y'=>$y, 'arg'=>$arg);
	}
}






/*
 * 함수: readIslandsFile()
 * 역할: 전체 섬 데이터와 공통 데이터 파일을 읽어 Hislands/각종 전역 배열로 복원합니다.
 * 원본 대응: hako/hako-main.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function readIslandsFile() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	unset($num); $num = isset($_args[0]) ? $_args[0] : null;
					

					

	
	if (!hako_open('IN', "{$HdirName}/hakojima.dat")) {
		@rename("{$HdirName}/hakojima.tmp", "{$HdirName}/hakojima.dat");
		if (!hako_open('IN', "{$HdirName}/hakojima.dat")) {
			return 0;
		}
	}

	
$HislandTurn = intval(trim(hako_getline('IN')));

	if ($HislandTurn == 0) { return 0; }
	if (($HislandTurn <= 1) && ($HmaxIsland == 0)) { $HmaxIsland = 99; }
$HislandLastTime = intval(trim(hako_getline('IN')));
	if ($HislandLastTime == 0) { return 0; }
$HislandNumber = intval(trim(hako_getline('IN')));

	
	unset($tmp); $tmp = hako_getline('IN');hako_chomp($tmp);
	$_list_tmp = explode(',', $tmp);
	$HislandNextID = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
	array_shift($_list_tmp);
	$HpreDeleteID = array_values(array_filter($_list_tmp, 'strlen'));
$dataVersion = intval(trim(hako_getline('IN')));
$HislandNFlg = intval(trim(hako_getline('IN')));
	$tmp = hako_getline('IN');

	hako_chomp($tmp);
	$HwarIsland = ($tmp === '') ? array() : explode(',', $tmp);
	$tmp = hako_getline('IN');

	hako_chomp($tmp);
	$HamityIsland = ($tmp === '') ? array() : explode(',', $tmp);
	$HTurnCt = intval(hako_getline('IN'));
	$tmp = hako_getline('IN');
	hako_chomp($tmp);
	$HflexTime = ($tmp === '') ? array() : explode(',', $tmp);

	if ($dataVersion >= 14) {
$HragnarokTurn = intval(trim(hako_getline('IN')));
	}

	
	if ($HflexTimeSet) { $HunitTime = 3600 * $HflexTime[$HTurnCt]; }

	

	$now = time();
		$__hako_turn_elapsed = $now - $HislandLastTime;
		$__hako_turn_backlog = 0;
		if (($HunitTime > 0) && ($__hako_turn_elapsed >= $HunitTime)) {
			$__hako_turn_backlog = intval(floor($__hako_turn_elapsed / $HunitTime));
		}
		$__hako_turn_due = (($__hako_turn_backlog >= 1) &&
			 (($HlimitTurn <= 0) || ($HislandTurn < $HlimitTurn)) &&
			 !(($HislandNumber <= 1) && (($HislandNumber >= $HmaxIsland) || ($HislandNFlg == 1))));

		if ((empty($HskipAutoTurn)) &&
			((($Hdebug == 1) && ($HmainMode == 'Hdebugturn')) ||
			($__hako_turn_due && (!empty($HmanualTurnRequest) || ($__hako_turn_backlog == 1))))) {
			/*
				 * PHP 5.5 파일 저장 환경 보정:
				 * 1턴만 밀린 정상 갱신 시점에서는 원본 CGI처럼 한 요청에서 1턴을 자동 처리합니다.
				 * 2턴 이상 밀렸으면 일반 접속에서는 화면을 먼저 출력하고 수동 1턴 진행 링크를 표시합니다.
				 * 링크를 누르면 한 요청에서 1턴만 처리하며 HislandLastTime은 현재 시간으로 보정하지 않습니다.
				 */
			$HmainMode = 'turn';
			$num = -1;
		} elseif ($__hako_turn_due) {
			$HautoTurnPending = 1;
			$HautoTurnBacklog = $__hako_turn_backlog;
		}

	
	unset($land); $land = array();
	unset($landValue); $landValue = array();
	unset($landOwner); $landOwner = array();
	unset($landResist); $landResist = array();
	unset($landKeep); $landKeep = array();
	unset($HGr); $HGr = array();
	unset($Div); $Div = array();
	unset($DivPw); $DivPw = array();
	unset($DivEx); $DivEx = array();
	unset($DivLv); $DivLv = array();
	unset($DivNa); $DivNa = array();
	unset($DivItem); $DivItem = array();
	unset($line); $line = null;
	unset($x); $x = null;
	unset($y); $y = null;
	for ($y = 0; $y < $HislandSize; $y++) {
		$line = hako_getline('IN');
		for ($x = 0; $x < $HislandSize; $x++) {
			if ($dataVersion >= 13) {
				hako_subst($line, '~^(..)(...)(...)(.)(.)(.)(.)(..)(..)(.)(...)(.)~', '');
				$land[$x][$y] = hexdec(hako_m(1));
				$landValue[$x][$y] = hexdec(hako_m(2));
				$landOwner[$x][$y] = hexdec(hako_m(3));
$landResist[$x][$y] = hexdec(hako_m(4));
$landKeep[$x][$y] = hexdec(hako_m(5));
$HGr[$x][$y] = hexdec(hako_m(6));
$Div[$x][$y] = hexdec(hako_m(7));
$DivPw[$x][$y] = hexdec(hako_m(8));
$DivEx[$x][$y] = hexdec(hako_m(9));
$DivLv[$x][$y] = hexdec(hako_m(10));
$DivNa[$x][$y] = hexdec(hako_m(11));
$DivItem[$x][$y] = hexdec(hako_m(12));
			} else{
				hako_subst($line, '~^(..)(...)(...)(.)(.)(.)(.)(..)(..)(...)(.)~', '');
				$land[$x][$y] = hexdec(hako_m(1));
				$landValue[$x][$y] = hexdec(hako_m(2));
				$landOwner[$x][$y] = hexdec(hako_m(3));
$landResist[$x][$y] = hexdec(hako_m(4));
$landKeep[$x][$y] = hexdec(hako_m(5));
$HGr[$x][$y] = hexdec(hako_m(6));
$Div[$x][$y] = hexdec(hako_m(7));
$DivPw[$x][$y] = hexdec(hako_m(8));
$DivEx[$x][$y] = hexdec(hako_m(9));
$DivNa[$x][$y] = hexdec(hako_m(10));
$DivItem[$x][$y] = hexdec(hako_m(11));
			}
		}
	}
	$Hland = $land;
	$HlandValue = $landValue;
	$HlandOwner = $landOwner;
	$HlandResist = $landResist;
	$HlandKeep = $landKeep;
	$HlandHGr = $HGr;
	$HlandDiv = $Div;
	$HlandDivPw = $DivPw;
	$HlandDivEx = $DivEx;
	$HlandDivLv = $DivLv;
	$HlandDivNa = $DivNa;
	$HlandDivItem = $DivItem;

	
	unset($i); $i = null;
	for ($i = 0; $i < $HislandNumber; $i++) {
		$Hislands[$i] = readIsland($num);
		$HidToNumber[$Hislands[$i]['id']] = $i;
		foreach ($HpreDeleteID as $_) {
			if ($Hislands[$i]['id'] == $_) {
				$Hislands[$i]['predelete'] = 1;
			}
		}
	}
	$HidToName[0] = '중립 지역';

	
	hako_close('IN');

	return 1;
}


/*
 * 함수: readIsland()
 * 역할: 개별 island.ID 파일을 읽어 한 섬의 상세 데이터, 명령, 로컬게시판, 부대 정보를 복원합니다.
 * 원본 대응: hako/hako-main.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function readIsland() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	unset($num); $num = isset($_args[0]) ? $_args[0] : null;
	$name = $id = $ownername = $prize = $absent = $comment = $password = $money = $food = null;
	$pop = $area = $farm = $factory = $mountain = $kaisi = $score = $custom = $ally = $tmp = null;
	$soldierF = array();
	$attackA = array();
	$afnameId = $nationalflag = null;
	$name = hako_getline('IN');
	hako_chomp($name);
	if (hako_subst_match($name, '/,(.*)$/', '', 1)) {
		$score = intval(hako_m(1));
	} else {
		$score = 0;
	}
$id = intval(trim(hako_getline('IN')));

	$ownername = hako_getline('IN');
	hako_chomp($ownername);
	$prize = hako_getline('IN');
	hako_chomp($prize);
$absent = intval(trim(hako_getline('IN')));

	$comment = hako_getline('IN');
	hako_chomp($comment);
	$password = hako_getline('IN');
	hako_chomp($password);
$money = intval(trim(hako_getline('IN')));
$food = intval(trim(hako_getline('IN')));	$pop = intval(trim(hako_getline('IN')));      
$area = intval(trim(hako_getline('IN')));
$farm = intval(trim(hako_getline('IN')));
$factory = intval(trim(hako_getline('IN')));
$mountain = intval(trim(hako_getline('IN')));

	$tmp = hako_getline('IN'); hako_chomp($tmp);
	unset($item); $item = explode(',', $tmp);
$kaisi = intval(trim(hako_getline('IN')));

	$tmp = hako_getline('IN'); hako_chomp($tmp);
	unset($soldier); $soldier = explode(',', $tmp);

	
	$tmp = hako_getline('IN'); hako_chomp($tmp);
	unset($fleet); $fleet = explode(',', $tmp);
	$tmp = hako_getline('IN'); hako_chomp($tmp);
	unset($direction); $direction = explode(',', $tmp);
	$tmp = hako_getline('IN'); hako_chomp($tmp);
	unset($order); $order = explode(',', $tmp);
	$tmp = hako_getline('IN'); hako_chomp($tmp);
	unset($corps); $corps = explode(',', $tmp);
	$tmp = hako_getline('IN'); hako_chomp($tmp);
	unset($color); $color = explode(',', $tmp);
	$tmp = hako_getline('IN'); hako_chomp($tmp);
	unset($mpower); $mpower = explode(',', $tmp);
$custom = intval(trim(hako_getline('IN')));
$ally = intval(trim(hako_getline('IN')));

	$tmp = hako_getline('IN'); hako_chomp($tmp);
	$soldierF = explode(',', $tmp);
	$afnameId = intval(hako_getline('IN'));

	$tmp = hako_getline('IN'); hako_chomp($tmp);
	unset($statistical); $statistical = explode(',', $tmp);

	$tmp = hako_getline('IN'); hako_chomp($tmp);
	$attackA = explode(',', $tmp);
$nationalflag = intval(trim(hako_getline('IN')));

	foreach (array('item', 'mpower') as $__hako_key) {
		if (!isset($$__hako_key) || !is_array($$__hako_key)) { $$__hako_key = array(); }
		for ($__hako_i = 0; $__hako_i < 16; $__hako_i++) {
			if (!isset(${$__hako_key}[$__hako_i])) { ${$__hako_key}[$__hako_i] = ''; }
		}
	}
	foreach (array('fleet', 'direction', 'order', 'corps', 'color') as $__hako_key) {
		if (!isset($$__hako_key) || !is_array($$__hako_key)) { $$__hako_key = array(); }
		for ($__hako_i = 0; $__hako_i < 8; $__hako_i++) {
			if (!isset(${$__hako_key}[$__hako_i])) { ${$__hako_key}[$__hako_i] = ''; }
		}
	}
	if (!isset($statistical) || !is_array($statistical)) { $statistical = array(); }
	for ($__hako_i = 0; $__hako_i < 6; $__hako_i++) {
		if (!isset($statistical[$__hako_i])) { $statistical[$__hako_i] = ''; }
	}

	$name .= $Haftername[$afnameId];

	

	$now = time();
	if (($now > $kaisi) && ($HislandTurn <= 1)) {
		if ($comment == '(미입력)') {
			

			$deleteIslandId = $id;
		}
	}

	
	$HidToName[$id] = $name;
	
	unset($line); $line = null;
	unset($command); $command = array();
	unset($lbbs); $lbbs = array();
	if (($num == -1) || ($num == $id)) {
	if (!hako_open('IIN', "{$HdirName}/island.$id")) {
		@rename("{$HdirName}/islandtmp.$id", "{$HdirName}/island.$id");
		if (!hako_open('IIN', "{$HdirName}/island.$id")) { exit(0); }
	}

	
	unset($i); $i = null;
	for ($i = 0; $i < $HcommandMax; $i++) {
		$line = hako_getline('IIN');
		hako_regex('~^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$~', $line);
		$command[$i] = array(
			'kind' => intval(hako_m(1)),
			'target' => intval(hako_m(2)),
			'x' => intval(hako_m(3)),
			'y' => intval(hako_m(4)),
			'arg' => intval(hako_m(5))
		);
	}

	
	for ($i = 0; $i < $HlbbsMax; $i++) {
		$line = hako_getline('IIN');
		hako_chomp($line);
		$lbbs[$i] = $line;
	}

	hako_close('IIN');
	}

	
	return array(
		'name' => $name,
		'ownername' => $ownername,
		'id' => $id,
		'score' => $score,
		'prize' => $prize,
		'absent' => $absent,
		'comment' => $comment,
		'password' => $password,
		'money' => $money,
		'food' => $food,
		'pop' => $pop,
		'area' => $area,
		'farm' => $farm,
		'factory' => $factory,
		'mountain' => $mountain,
		'item' => $item,
		'kaisi' => $kaisi,
		'afnameId' => $afnameId,
		'nationalflag' => $nationalflag,
			'predelete' => 0,
		'soldier' => intval(isset($soldier[0]) ? $soldier[0] : 0),
		'soldierex' => intval(isset($soldier[1]) ? $soldier[1] : 0),
		'soldierF' => intval(isset($soldierF[0]) ? $soldierF[0] : 0),
		'soldierFex' => intval(isset($soldierF[1]) ? $soldierF[1] : 0),
		'fleet' => $fleet,
		'direction' => $direction,
		'order' => $order,
		'corps' => $corps,
		'color' => $color,
		'mpower' => $mpower,
		'custom' => $custom,
		'statistical' => $statistical,
		'attackA' => intval(isset($attackA[0]) ? $attackA[0] : 0),
		'damageA' => intval(isset($attackA[1]) ? $attackA[1] : 0),
		'ally' => $ally,
		'land' => $Hland,
		'landValue' => $HlandValue,
		'HGr' => $HlandHGr,
		'Div' => $HlandDiv,
		'DivPw' => $HlandDivPw,
		'DivEx' => $HlandDivEx,
		'DivLv' => $HlandDivLv,
		'DivNa' => $HlandDivNa,
		'DivItem' => $HlandDivItem,
		'landOwner' => $HlandOwner,
		'command' => $command,
		'lbbs' => $lbbs
	);
}


/*
 * 함수: writeIslandsFile()
 * 역할: 전체 섬 목록과 공통 데이터를 저장합니다. 빈 값 비교가 원본과 달라지면 island.* 파일이 잘못 덮일 수 있습니다.
 * 원본 대응: hako/hako-main.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function writeIslandsFile() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	unset($num); $num = isset($_args[0]) ? $_args[0] : null;
	unset($x); $x = null;
	unset($y); $y = null;
	unset($i); $i = null;

	
	hako_open('OUT', ">{$HdirName}/hakojima.tmp");

	
		if (!is_array($HpreDeleteID)) { $HpreDeleteID = (strlen((string)$HpreDeleteID) ? array($HpreDeleteID) : array()); }
		if (!is_array($HwarIsland)) { $HwarIsland = (strlen((string)$HwarIsland) ? array($HwarIsland) : array()); }
		if (!is_array($HamityIsland)) { $HamityIsland = (strlen((string)$HamityIsland) ? array($HamityIsland) : array()); }
		if (!is_array($HflexTime)) { $HflexTime = (strlen((string)$HflexTime) ? array($HflexTime) : array()); }

	hako_write('OUT', "$HislandTurn\n");
	hako_write('OUT', "$HislandLastTime\n");
	hako_write('OUT', "$HislandNumber\n");
	hako_write('OUT', "$HislandNextID," . join(',', $HpreDeleteID) . "\n");
	hako_write('OUT', "14\n");
	hako_write('OUT', "$HislandNFlg\n");
	if (($HragnarokTurn > 0) && ($HragnarokTurn <= $HislandTurn + 1)) {
		
		hako_write('OUT', "\n");
		hako_write('OUT', "\n");
	} else{
		hako_write('OUT', join(',', $HwarIsland) . "\n");
		hako_write('OUT', join(',', $HamityIsland) . "\n");
	}
	hako_write('OUT', "$HTurnCt\n");
	hako_write('OUT', join(',', $HflexTime) . "\n");
	hako_write('OUT', "$HragnarokTurn\n");

	
	for ($y = 0; $y < $HislandSize; $y++) {
		for ($x = 0; $x < $HislandSize; $x++) {
			
			if ($HlandDivPw[$x][$y] == 0) {
				$_list_tmp = array(0,0,0,0,0,0,0);
				$HlandHGr[$x][$y] = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
				$HlandDiv[$x][$y] = isset($_list_tmp[1]) ? $_list_tmp[1] : null;
				$HlandDivPw[$x][$y] = isset($_list_tmp[2]) ? $_list_tmp[2] : null;
				$HlandDivEx[$x][$y] = isset($_list_tmp[3]) ? $_list_tmp[3] : null;
				$HlandDivLv[$x][$y] = isset($_list_tmp[4]) ? $_list_tmp[4] : null;
				$HlandDivNa[$x][$y] = isset($_list_tmp[5]) ? $_list_tmp[5] : null;
				$HlandDivItem[$x][$y] = isset($_list_tmp[6]) ? $_list_tmp[6] : null;
			}
			if ($HlandResist[$x][$y] > 10) { $HlandResist[$x][$y] = 10; }
			if ($HlandDivPw[$x][$y] > 250) { $HlandDivPw[$x][$y] = 250; }
			if ($HlandDivEx[$x][$y] > 255) { $HlandDivEx[$x][$y] = 255; }

			hako_write('OUT', sprintf("%02x%03x%03x%01x%01x%01x%01x%02x%02x%01x%03x%01x", $Hland[$x][$y], $HlandValue[$x][$y], $HlandOwner[$x][$y], $HlandResist[$x][$y], $HlandKeep[$x][$y], $HlandHGr[$x][$y], $HlandDiv[$x][$y], $HlandDivPw[$x][$y], $HlandDivEx[$x][$y], $HlandDivLv[$x][$y], $HlandDivNa[$x][$y], $HlandDivItem[$x][$y]));
		}
		hako_write('OUT', "\n");
	}

	
	for ($i = 0; $i < $HislandNumber; $i++) {
		writeIsland($Hislands[$i], $num);
	}

	

	hako_close('OUT');

	

	hako_replace_file("{$HdirName}/hakojima.tmp", "{$HdirName}/hakojima.dat");
}


/*
 * 함수: writeIsland()
 * 역할: 한 섬의 상세 데이터를 island.ID 파일로 저장합니다. 저장 순서와 구분자는 기존 데이터 호환에 필요합니다.
 * 원본 대응: hako/hako-main.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function writeIsland() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	unset($island); $island = isset($_args[0]) ? $_args[0] : null;
	unset($num); $num = isset($_args[1]) ? $_args[1] : null;

	unset($score); $score = null;
	unset($command); $command = null;
	unset($lbbs); $lbbs = null;
	unset($i); $i = null;
		$island += array(
			'score'=>0, 'prize'=>'0,0,', 'absent'=>0, 'comment'=>'', 'password'=>'',
			'money'=>0, 'food'=>0, 'pop'=>0, 'area'=>0, 'farm'=>0, 'factory'=>0, 'mountain'=>0,
			'item'=>array(), 'kaisi'=>0, 'soldier'=>0, 'soldierex'=>0, 'fleet'=>array(), 'direction'=>array(),
			'order'=>array(), 'corps'=>array(), 'color'=>array(), 'mpower'=>array(), 'custom'=>0, 'ally'=>0,
			'soldierF'=>0, 'soldierFex'=>0, 'afnameId'=>0, 'statistical'=>array(), 'attackA'=>0, 'damageA'=>0, 'nationalflag'=>0, 'predelete'=>0
		);
		foreach (array('item','mpower') as $__k) { for ($__i=0; $__i<16; $__i++) { if (!isset($island[$__k][$__i])) { $island[$__k][$__i] = ''; } } }
		foreach (array('fleet','direction','order','corps','color') as $__k) { for ($__i=0; $__i<8; $__i++) { if (!isset($island[$__k][$__i])) { $island[$__k][$__i] = ''; } } }
		for ($__i=0; $__i<6; $__i++) { if (!isset($island['statistical'][$__i])) { $island['statistical'][$__i] = ''; } }
		if (!isset($island['command']) || !is_array($island['command'])) { $island['command'] = array(); }
		for ($__i=0; $__i<$HcommandMax; $__i++) { if (!isset($island['command'][$__i]) || !is_array($island['command'][$__i])) { $island['command'][$__i] = array('kind'=>$HcomDoNothing, 'target'=>0, 'x'=>0, 'y'=>0, 'arg'=>0); } }
		if (!isset($island['lbbs']) || !is_array($island['lbbs'])) { $island['lbbs'] = array(); }
		for ($__i=0; $__i<$HlbbsMax; $__i++) { if (!isset($island['lbbs'][$__i])) { $island['lbbs'][$__i] = ''; } }
	$score = intval($island['score']);
	$__afid = ($island['afnameId'] === '' || $island['afnameId'] === null) ? 0 : intval($island['afnameId']);
	$__aftername = isset($Haftername[$__afid]) ? $Haftername[$__afid] : '';
	$island['afnameId'] = $__afid;

	unset($r); $r = hako_rindex($island['name'],$__aftername);
	if ($r > 0) { $island['name'] = substr($island['name'],0,$r); }

	hako_write('OUT', $island['name'] . ",$score\n");
	
	$island['name'] .= $__aftername;
	hako_write('OUT', $island['id'] . "\n");
	hako_write('OUT', $island['ownername'] . "\n");
	hako_write('OUT', $island['prize'] . "\n");
	hako_write('OUT', $island['absent'] . "\n");
	hako_write('OUT', $island['comment'] . "\n");
	hako_write('OUT', $island['password'] . "\n");
	hako_write('OUT', $island['money'] . "\n");
	hako_write('OUT', $island['food'] . "\n");
	hako_write('OUT', $island['pop'] . "\n");
	hako_write('OUT', $island['area'] . "\n");
	hako_write('OUT', $island['farm'] . "\n");
	hako_write('OUT', $island['factory'] . "\n");
	hako_write('OUT', $island['mountain'] . "\n");

	unset($im); $im = $island['item'];
	hako_write('OUT', "$im[0],$im[1],$im[2],$im[3],$im[4],$im[5],$im[6],$im[7],$im[8],$im[9],$im[10],$im[11],$im[12],$im[13],$im[14],$im[15]\n");

	hako_write('OUT', $island['kaisi'] . "\n");
	if ($island['soldier'] < 0) { $island['soldier'] = 0; }
	if ($island['soldierex'] > 90) { $island['soldierex'] = 90; }
	hako_write('OUT', $island['soldier'] . "," . $island['soldierex'] . "\n");
	unset($fleet); $fleet = $island['fleet'];
	unset($direc); $direc = $island['direction'];
	unset($order); $order = $island['order'];
	unset($corps); $corps = $island['corps'];
	unset($fnum); $fnum = array(' 제1군', ' 제2군', ' 제3군', ' 제4군', ' 제5군', ' 제6군', ' 제7군', ' 제8군');
	for ($_ = 0; $_ <= 7; $_++) {
		if ($fleet[$_] == '') { $fleet[$_] = $fnum[$_]; }
	}
	unset($color); $color = $island['color'];
	unset($cnum); $cnum = array('white','yellow','lime','aqua','fuchsia','#FFD700','teal','#FA8072');
	for ($_ = 0; $_ <= 7; $_++) {
		if ($color[$_] == '') { $color[$_] = $cnum[$_]; }
	}
	hako_write('OUT', "$fleet[0],$fleet[1],$fleet[2],$fleet[3],$fleet[4],$fleet[5],$fleet[6],$fleet[7]\n");
	hako_write('OUT', "$direc[0],$direc[1],$direc[2],$direc[3],$direc[4],$direc[5],$direc[6],$direc[7]\n");
	hako_write('OUT', "$order[0],$order[1],$order[2],$order[3],$order[4],$order[5],$order[6],$order[7]\n");
	hako_write('OUT', "$corps[0],$corps[1],$corps[2],$corps[3],$corps[4],$corps[5],$corps[6],$corps[7]\n");
	hako_write('OUT', "$color[0],$color[1],$color[2],$color[3],$color[4],$color[5],$color[6],$color[7]\n");
	unset($mp); $mp = $island['mpower'];
	hako_write('OUT', "$mp[0],$mp[1],$mp[2],$mp[3],$mp[4],$mp[5],$mp[6],$mp[7],$mp[8],$mp[9],$mp[10],$mp[11],$mp[12],$mp[13],$mp[14],$mp[15]\n");
	hako_write('OUT', $island['custom'] . "\n");
	hako_write('OUT', $island['ally'] . "\n");

	hako_write('OUT', $island['soldierF'] . "," . $island['soldierFex'] . "\n");
	hako_write('OUT', $island['afnameId'] . "\n");

	unset($st); $st = $island['statistical'];
	hako_write('OUT', "$st[0],$st[1],$st[2],$st[3],$st[4],$st[5]\n");

	hako_write('OUT', $island['attackA'] . "," . $island['damageA'] . "\n");
	hako_write('OUT', $island['nationalflag'] . "\n");

	
	if (($num <= -1) || ($num == $island['id'])) {
	hako_open('IOUT', ">{$HdirName}/islandtmp.{$island['id']}");

	
	$command = $island['command'];
	for ($i = 0; $i < $HcommandMax; $i++) {
			hako_write('IOUT', sprintf("%d,%d,%d,%d,%d\n",
				$command[$i]['kind'],
				$command[$i]['target'],
				$command[$i]['x'],
				$command[$i]['y'],
				$command[$i]['arg']));
	}

	
	$lbbs = $island['lbbs'];
	for ($i = 0; $i < $HlbbsMax; $i++) {
		hako_write('IOUT', $lbbs[$i] . "\n");
	}

	hako_close('IOUT');
	hako_replace_file("{$HdirName}/islandtmp.{$island['id']}", "{$HdirName}/island.{$island['id']}");
	}
}






/*
 * 함수: requestInput()
 * 역할: GET/POST 입력값을 원본 CGI의 cgiInput 역할에 맞춰 전역 변수로 정리합니다.
 * 원본 대응: hako/hako-main.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function requestInput() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	unset($line); $line = null;
	unset($getLine); $getLine = null;

	
	$line = file_get_contents("php://input");
	$line = strtr($line, '+', ' ');
	$line = rawurldecode(str_replace("+", " ", $line));
	hako_subst($line, '~[\\x00-\\x1f\\,]~', '');

	
	$getLine = hako_get_env('QUERY_STRING');




	
	if (hako_regex('~mode=([0-9]*)~', $getLine)) {
		$Htopmode = hako_m(1);
	}
	
	if (hako_regex('~CommandButton([0-9]+)=~', $line)) {
		
		$HcurrentID = hako_m(1);
		$defaultID = hako_m(1);
	}
	if (hako_regex('~ISLANDNAME=([^\&]*)\&~', $line)) {
		
		$HcurrentName = cutColumn(hako_m(1), 18);
	
	}
	if (hako_regex('~AFNAME=([0-9]+)\&~', $line)) {
		
		$HcurrentAFNameId = hako_m(1);
	}
	if (hako_regex('~OWNERNAME=([^\&]*)\&~', $line)) {
		
		$HcurrentOwnerName = cutColumn(hako_m(1), 18);
	}
	if (hako_regex('~ISLANDID=([0-9]+)\&~', $line)) {
		
		$HcurrentID = hako_m(1);
	}
	if (hako_regex('~ISLANDID2=([0-9]+)\&~', $line)) {
		
		$HspeakerID = hako_m(1);
	}
	if (hako_regex('~LBBSTYPE=([^\&]*)\&~', $line)) {
		
		$HlbbsType = hako_m(1);
	}
	
	if (hako_regex('~OLDPASS=([^\&]*)\&~', $line)) {
		$HoldPassword = hako_m(1);
		$HdefaultPassword = hako_m(1);
	}
	if (hako_regex('~PASSWORD=([^\&]*)\&~', $line)) {
		$HinputPassword = hako_m(1);
		$HdefaultPassword = hako_m(1);
	}
	if (hako_regex('~PASSWORD2=([^\&]*)\&~', $line)) {
		$HinputPassword2 = hako_m(1);
	}
	
	if (hako_regex('~MESSAGE=([^\&]*)\&~', $line)) {
		$Hmessage = cutColumn(hako_m(1), 100);
	}
	
	if (hako_regex('~JAVAMODE=([^\&]*)\&~', $line)) {
		$HjavaMode = hako_m(1);
	}
	
	if (hako_regex('~async=true\&~', $line)) {
		$Hasync = 1;
	}
	if (hako_regex('~CommandJavaButton([0-9]+)=~', $line)) {
		
		$HcurrentID = hako_m(1);
		$defaultID = hako_m(1);
	}
	
	if (hako_regex('~LBBSNAME=([^\&]*)\&~', $line)) {
		$HlbbsName = hako_m(1);
		$HdefaultName = hako_m(1);
	}
	if (hako_regex('~LBBSMESSAGE=([^\&]*)\&~', $line)) {
		$HlbbsMessage = cutColumn(hako_m(1), 122);
	}
	
	if (hako_regex('~IMGLINEMAC=([^&]*)\&~', $line)) {
		$flag = hako_m(1);
		if ($flag == '') {
			$flag = $imageDir;
		} else {
			hako_subst($flag, '~ ~', '%20');
			$flag = 'file:///' . $flag;
		}
		$HimgLine = $flag;
	} elseif (hako_regex('~IMGLINE=([^&]*)\&~', $line)) {
		$flag = substr(hako_m(1), 0 , -8);
		$flag = strtr($flag, '\\', '/');
		if ($flag == '') {
			$flag = $imageDir;
		} else {
			hako_subst($flag, '~ ~', '%20');
			$flag = 'file:///' . $flag;
		}
		$HimgLine = $flag;
	}
	
	if (hako_regex('~color=([0-9]*)~', $getLine)) {
		$Hcolormap = hako_m(1);
	}
	
	if (hako_regex('~AutoTurn=1~', $getLine)) {
		$HmanualTurnRequest = 1;
	}

	if (hako_regex('~TurnButton~', $line)) {
		if ($Hdebug == 1) {
			$HmainMode = 'Hdebugturn';
		}
	} elseif (hako_regex('~alist=([0-9]*)~', $getLine)) {
		$HmainMode = 'alist';
		$Halistmode = hako_m(1);
	} elseif (hako_regex('~OwnerButton~', $line)) {
		$HmainMode = 'owner';
	} elseif (hako_regex('~Sight=([0-9]*)~', $getLine)) {
		$HmainMode = 'print';
		$HcurrentID = hako_m(1);
	} elseif (hako_regex('~NewIslandInfo~', $line)) {
		$HmainMode = 'top';
		$Htopmode = 9;
	} elseif (hako_regex('~NewIslandButton~', $line)) {
		$HmainMode = 'new';
		if (hako_regex('~autoPoint=on~', $line)) { $HautoPoint = 1; }
		hako_regex('~POINTX=([^\&]*)\&~', $line);
		$HdefaultX = hako_m(1);
		hako_regex('~POINTY=([^\&]*)\&~', $line);
		$HdefaultY = hako_m(1);
		hako_regex('~STARTITEM=([^\&]*)\&~', $line);
		$HstartItem = hako_m(1);
	} elseif (hako_regex('~LbbsButton(..)([0-9]*)~', $line)) {
		$HmainMode = 'lbbs';
		if (hako_m(1) == 'OW') {
			
			$HlbbsMode = 1;
		} elseif (hako_m(1) == 'DL') {
			
			$HlbbsMode = 3;
		} elseif (hako_m(1) == 'DS') {
			
			$HlbbsMode = 2;
		} elseif (hako_m(1) == 'CK') {
			
			$HlbbsMode = 4;
	
	
	
	
	
	
		} else {
			
			$HlbbsMode = 0;
		}
		$HcurrentID = hako_m(2);

		
		hako_regex('~NUMBER=([^\&]*)\&~', $line);
		$HcommandPlanNumber = hako_m(1);
		hako_regex('~LBBSLIST=([^\&]*)\&~', $line);
		$HlbbsMode2 = hako_m(1);
	} elseif (hako_regex('~settei=([^\&]*)~', $getLine)) {
		$HmainMode = 'settei';
		$HdefaultPassword = hako_m(1);
	} elseif (hako_regex('~ChangeInfoButton~', $line)) {
		$HmainMode = 'change';
	} elseif (hako_regex('~MessageButton([0-9]*)~', $line)) {
		$HmainMode = 'comment';
		$HcurrentID = hako_m(1);
	} elseif (hako_regex('~CommandJavaButton~', $line)) {
		$HmainMode = 'commandJava';
		hako_regex('~COMARY=([^\&]*)\&~', $line);
		$HcommandComary = hako_m(1);
		hako_regex('~COMMAND=([^\&]*)\&~', $line);
		$HdefaultKind = hako_m(1);
		hako_regex('~POINTX=([^\&]*)\&~', $line);
		$HdefaultX = hako_m(1);
		hako_regex('~POINTY=([^\&]*)\&~', $line);
		$HdefaultY = hako_m(1);
	} elseif (hako_regex('~CommandButton~', $line)) {
		$HmainMode = 'command2';
		
		hako_regex('~NUMBER=([^\&]*)\&~', $line);
		$HcommandPlanNumber = hako_m(1);
		hako_regex('~COMMAND=([^\&]*)\&~', $line);
		$HcommandKind = hako_m(1);
		$HdefaultKind = hako_m(1);
		hako_regex('~AMOUNT=([^\&]*)\&~', $line);
		$HcommandArg = hako_m(1);
		hako_regex('~TARGETID=([^\&]*)\&~', $line);
		$HcommandTarget = hako_m(1);
		$defaultTarget = hako_m(1);
		hako_regex('~POINTX=([^\&]*)\&~', $line);
		$HcommandX = hako_m(1);
		$HdefaultX = hako_m(1);
		hako_regex('~POINTY=([^\&]*)\&~', $line);
		$HcommandY = hako_m(1);
		$HdefaultY = hako_m(1);
		hako_regex('~COMMANDMODE=(write|insert|delete)~', $line);
		$HcommandMode = hako_m(1);
	} elseif (hako_regex('~ForceButton([0-9]*)~', $line)) {
		$HmainMode = 'force';
		$HcurrentID = hako_m(1);
		for ($_ = 0; $_ <= 7; $_++) {
			hako_regex('~ForceName' . $_ . '=([^\&]*)\&~', $line);
			$ofname[$_] = hako_m(1);
			hako_regex('~ForceDir' . $_ . '=([^\&]*)\&~', $line);
			$ofdirection[$_] = hako_m(1);
			hako_regex('~ForceOrder' . $_ . '=([^\&]*)\&~', $line);
			$oforder[$_] = hako_m(1);
			hako_regex('~ForceCorps' . $_ . '=([^\&]*)\&~', $line);
			$ofcorps[$_] = hako_m(1);
			hako_regex('~ForceColor' . $_ . '=([^\&]*)\&~', $line);
			$ofcolor[$_] = hako_m(1);
		}
	} elseif (hako_regex('~camp([0-9]*)~', $line)) {
		$HmainMode = 'camp';
		$HcurrentID = hako_m(1);

	} elseif (hako_regex('~customMButton([0-9]*)~', $line)) {
		$HmainMode = 'custom';
		$HcurrentID = hako_m(1);
		if (hako_regex('~custom0~', $line)) { $Hcustom[0] = 1; }
		if (hako_regex('~custom1~', $line)) { $Hcustom[1] = 1; }
		if (hako_regex('~custom2~', $line)) { $Hcustom[2] = 1; }

	} elseif (hako_regex('~SetupV=([^\&]*)~', $getLine)) {
		$HmainMode = 'setupv';
		$HdefaultPassword = hako_m(1);

	} elseif (hako_regex('~Ichange=([^\&]*)~', $getLine)) {
		
		$HmainMode = 'ichange';
		$HichangeMode = 0;
		$HdefaultPassword = hako_m(1);
	} elseif (hako_regex('~Ichange=([^\&]*)\&~', $line)) {
		$HmainMode = 'ichange';
		$HichangeMode = 1;
		$HdefaultPassword = hako_m(1);
		hako_regex('~ICID=([^\&]*)\&~', $line);
		$HcurrentID = hako_m(1);
		hako_regex('~ICMONEY=([^\&]*)\&~', $line);
		$Hicmoney = hako_m(1);
		hako_regex('~ICFOOD=([^\&]*)\&~', $line);
		$Hicfood = hako_m(1);
		hako_regex('~ICSOLDIER=([^\&]*)\&~', $line);
		$Hicsoldier = hako_m(1);
		hako_regex('~ICALLY=([^\&]*)\&~', $line);
		$Hically = hako_m(1);

	} elseif (hako_regex('~AWchange=([^\&]*)~', $getLine)) {
		
		$HmainMode = 'awchange';
		$HichangeMode = 0;
		$HdefaultPassword = hako_m(1);
	} elseif (hako_regex('~AWchange=([^\&]*)\&~', $line)) {
		$HmainMode = 'awchange';
		$HichangeMode = 1;
		$HdefaultPassword = hako_m(1);
		if (hako_regex('~AWMODE=([0-9]*)~', $line)) { $HawcM = hako_m(1); }
		if (hako_regex('~AWAMITY=([0-9]*)~', $line)) { $Hawc0 = hako_m(1); }
		if (hako_regex('~AWCTURN=([0-9]*)~', $line)) { $Hawc1 = hako_m(1); }
		if (hako_regex('~ISLANDID1=([0-9]*)~', $line)) { $Hawc2 = hako_m(1); }
		if (hako_regex('~ISLANDID2=([0-9]*)~', $line)) { $Hawc3 = hako_m(1); }
		if (hako_regex('~AWVALUE=([0-9]*)~', $line)) { $Hawc4 = hako_m(1); }

	} elseif (hako_regex('~Lchange=([^\&]*)~', $getLine)) {
		
		$HmainMode = 'lchange';
		$HlchangeMode = 0;
		$HdefaultPassword = hako_m(1);
	} elseif (hako_regex('~LchangeButtonM=([^\&]*)\&~', $line)) {
		
		$HmainMode = 'lchange';
		$HlchangeMode = 0;
		hako_regex('~Lchange=([^\&]*)\&~', $line);
		$HdefaultPassword = hako_m(1);
	} elseif (hako_regex('~Lchange=([^\&]*)\&~', $line)) {
		
		$HmainMode = 'lchange';
		$HlchangeMode = 1;
		$HdefaultPassword = hako_m(1);

		hako_regex('~POINTX=([^\&]*)\&~', $line);
		$HcommandX = hako_m(1);
		$HdefaultX = hako_m(1);
		hako_regex('~POINTY=([^\&]*)\&~', $line);
		$HcommandY = hako_m(1);
		$HdefaultY = hako_m(1);
		hako_regex('~LCHANGEKIND=([^\&]*)\&~', $line);
		$HlchangeKIND = hako_m(1);
		hako_regex('~LCHANGEVALUE=([^\&]*)\&~', $line);
		$HlchangeVALUE = hako_m(1);
		hako_regex('~LCHANGEOWNER=([^\&]*)\&~', $line);
		$HlchangeOWNER = hako_m(1);

		hako_regex('~LCHANGEHGR=([^\&]*)\&~', $line);
		$HlchangeHGR = hako_m(1);
		hako_regex('~LCHANGEDIV=([^\&]*)\&~', $line);
		$HlchangeDIV = hako_m(1);
		hako_regex('~LCHANGEDIVPW=([^\&]*)\&~', $line);
		$HlchangeDIVPW = hako_m(1);
		hako_regex('~LCHANGEDIVEX=([^\&]*)\&~', $line);
		$HlchangeDIVEX = hako_m(1);
		hako_regex('~LCHANGEDIVLV=([^\&]*)\&~', $line);
		$HlchangeDIVLV = hako_m(1);
		hako_regex('~LCHANGEDIVNA=([^\&]*)\&~', $line);
		$HlchangeDIVNA = hako_m(1);
		hako_regex('~LCHANGEDIVITEM=([^\&]*)\&~', $line);
		$HlchangeDIVITEM = hako_m(1);


	} elseif (hako_regex('~meditor=([0-9]*)~', $getLine)) {
		$HcurrentID = hako_m(1);
		$HmapeditorMode = ($HcurrentID > 0) ? 1 : 0;
		$HmainMode = 'meditor';
	} elseif (hako_regex('~MapEditor~', $line)) {
		$HmainMode = 'meditor';
		$HmapeditorMode = 1;


	} elseif (hako_regex('~RagnarokTurn=([^\&]*)~', $line)) {
		$HrTurn = hako_m(1);
		if (hako_regex('~RagnarokID=([^\&]*)~', $line)) {
			$HmainMode = 'ragnarok';
			$HcurrentID = hako_m(1);
		}

	} elseif (hako_regex('~Pdelete=([^\&]*)~', $getLine)) {
		
		$HmainMode = 'predelete';
		$HpreDeleteMode = 0;
		$HdefaultPassword = hako_m(1);
	} elseif (hako_regex('~Pdelete=([^\&]*)\&~', $line)) {
		
		$HmainMode = 'predelete';
		$HpreDeleteMode = 1;
		$HdefaultPassword = hako_m(1);
	} else {
		$HmainMode = 'top';
	}
	if (hako_regex('~SKIN=([^\&]*)\&~', $line)) {
		$flag = hako_m(1);
		if (($flag == 'del') || ($flag == '')) {
			$flag = $HcssFile;
		}
		$HskinName = $flag;
	}
}



/*
 * 함수: cookieInput()
 * 역할: 브라우저 쿠키에서 로컬 이미지/스킨/이전 선택값을 읽습니다.
 * 원본 대응: hako/hako-main.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function cookieInput() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	unset($cookie); $cookie = null;
	$cookie = (hako_get_env('HTTP_COOKIE'));
	if (hako_regex(hako_cookie_pattern('OWNISLANDID'), $cookie)) {
		$defaultID = hako_m(1);
	}
	if (hako_regex(hako_cookie_pattern('OWNISLANDPASSWORD'), $cookie)) {
		$HdefaultPassword = hako_m(1);
	}
	if (hako_regex(hako_cookie_pattern('TARGETISLANDID'), $cookie)) {
		$defaultTarget = hako_m(1);
	}
	if (hako_regex(hako_cookie_pattern('LBBSNAME'), $cookie)) {
		$HdefaultName = hako_m(1);
	}
	if (hako_regex(hako_cookie_pattern('POINTX'), $cookie)) {
		$HdefaultX = hako_m(1);
	}
	if (hako_regex(hako_cookie_pattern('POINTY'), $cookie)) {
		$HdefaultY = hako_m(1);
	}
	if (hako_regex(hako_cookie_pattern('KIND'), $cookie)) {
		$HdefaultKind = hako_m(1);
	}
	
	if (hako_regex(hako_cookie_pattern('IMGLINE'), $cookie)) {
		$HimgLine = hako_m(1);
	}
	
	if (hako_regex(hako_cookie_pattern('SKIN'), $cookie)) {
		$HskinName = hako_m(1);
	}
	if (hako_regex(hako_cookie_pattern('JAVAMODESET'), $cookie)) {
		$HjavaModeSet = hako_m(1);
	}
}


/*
 * 함수: cookieOutput()
 * 역할: 원본 CGI와 같은 이름의 쿠키를 출력합니다. 헤더 출력 시점에 주의해야 합니다.
 * 원본 대응: hako/hako-main.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function cookieOutput() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
    unset($info); $info = null;

    $_list_tmp = hako_gmtime(time() + 30 * 86400);
    $sec = $_list_tmp[0];
    $min = $_list_tmp[1];
    $hour = $_list_tmp[2];
    $date = $_list_tmp[3];
    $mon = $_list_tmp[4];
    $year = $_list_tmp[5];
    $day = $_list_tmp[6];

    $year += 1900;
    if ($date < 10) { $date = "0$date"; }
    if ($hour < 10) { $hour = "0$hour"; }
    if ($min < 10) { $min  = "0$min"; }
    if ($sec < 10) { $sec  = "0$sec"; }

    $__hako_cookie_days = array("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday");
    $__hako_cookie_months = array("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec");
    $day = isset($__hako_cookie_days[$day]) ? $__hako_cookie_days[$day] : $__hako_cookie_days[0];
    $mon = isset($__hako_cookie_months[$mon]) ? $__hako_cookie_months[$mon] : $__hako_cookie_months[0];
    unset($__hako_cookie_days, $__hako_cookie_months);

    $info = "; expires=$day, $date-$mon-$year $hour:$min:$sec GMT";

    $headers = array();
    if (($HcurrentID) && ($HmainMode == 'owner')) {
        $headers[] = "Set-Cookie: {$HthisFile}OWNISLANDID=($HcurrentID) $info";
    }
    if ($HinputPassword) {
        $headers[] = "Set-Cookie: {$HthisFile}OWNISLANDPASSWORD=($HinputPassword) $info";
    }
    if (isset($HcommandTarget) && $HcommandTarget !== '') {
        $headers[] = "Set-Cookie: {$HthisFile}TARGETISLANDID=($HcommandTarget) $info";
    }
    if ($HlbbsName) {
        $headers[] = "Set-Cookie: {$HthisFile}LBBSNAME=($HlbbsName) $info";
    }
    if (isset($HcommandX) && $HcommandX !== '') {
        $headers[] = "Set-Cookie: {$HthisFile}POINTX=($HcommandX) $info";
    }
    if (isset($HcommandY) && $HcommandY !== '') {
        $headers[] = "Set-Cookie: {$HthisFile}POINTY=($HcommandY) $info";
    }
    if ($HcommandKind) {
        $headers[] = "Set-Cookie: {$HthisFile}KIND=($HcommandKind) $info";
    }
    if ($HimgLine) {
        $headers[] = "Set-Cookie: {$HthisFile}IMGLINE=($HimgLine) $info";
    }
    if ($HskinName) {
        $headers[] = "Set-Cookie: {$HthisFile}SKIN=($HskinName) $info";
    }
    if ($HjavaMode) {
        $headers[] = "Set-Cookie: {$HthisFile}JAVAMODESET=($HjavaMode) $info";
    }
    if (!headers_sent()) {
        foreach ($headers as $__hako_cookie_header) { header($__hako_cookie_header, false); }
    }
}



/*
 * 함수: hakolock()
 * 역할: 턴 처리와 저장 중 동시 접근을 막기 위한 파일 잠금 진입점입니다.
 * 원본 대응: hako/hako-main.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function hakolock() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	if ($lockMode == 1) {
		
		return hakolock1();
	} elseif ($lockMode == 2) {
		
		return hakolock2();
	} elseif ($lockMode == 3) {
		
		return hakolock3();
	} else {
		
		return hakolock4();
	}
}

/*
 * 함수: hakolock1()
 * 역할: 1차 잠금 방식입니다. 원본의 symlink/파일 잠금 흐름을 PHP 파일 잠금으로 재현합니다.
 * 원본 대응: hako/hako-main.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function hakolock1() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	
	if (mkdir('hakojimalock', $HdirMode)) {
		
		return 1;
	} else {
		
		$b = hako_safe_mtime('hakojimalock');
		if (($b > 0) && ((time() -  $b)> $unlockTime)) {
			

			unlock();

			
			tempHeader(0);

			
			tempUnlock();

			
			tempFooter();

			
			exit(0);
		}
		return 0;
	}
}

/*
 * 함수: hakolock2()
 * 역할: 잠금 대기/재시도 흐름의 보조 단계입니다.
 * 원본 대응: hako/hako-main.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function hakolock2() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	global $_hako_fh;
	hako_open('LOCKID', '>>hakojimalockflock');
	if (isset($_hako_fh['LOCKID']) && is_resource($_hako_fh['LOCKID']) && hako_safe_flock($_hako_fh['LOCKID'], LOCK_EX)) {
		

		return 1;
	} else {
		
		return 0;
	}
}

/*
 * 함수: hakolock3()
 * 역할: 잠금 실패 시 강제 해제 가능 여부를 판단하는 보조 단계입니다.
 * 원본 대응: hako/hako-main.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function hakolock3() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	
	if (symlink('hakojimalockdummy', 'hakojimalock')) {
		

		return 1;
	} else {
		
		$b = hako_safe_mtime('hakojimalock', true);
		if (($b > 0) && ((time() -  $b)> $unlockTime)) {
			

			unlock();

			
			tempHeader(0);

			
			tempUnlock();

			
			tempFooter();

			
			exit(0);
		}
		return 0;
	}
}

/*
 * 함수: hakolock4()
 * 역할: 잠금 복구/재시도 보조 단계입니다.
 * 원본 대응: hako/hako-main.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function hakolock4() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	
	if (unlink('key-free')) {
		
		hako_open('OUT', '>key-locked');
		hako_write('OUT', time());
		hako_close('OUT');
		return 1;
	} else {
		
		if (!hako_open('IN', 'key-locked')) {
			return 0;
		}

		unset($t); $t = null;
		$t = hako_getline('IN');
		hako_close('IN');
		if (($t != 0) && (($t + $unlockTime) < time())) {
			
			unlock();

			
			tempHeader(0);

			
			tempUnlock();

			
			tempFooter();

			
			exit(0);
		}
		return 0;
	}
}


/*
 * 함수: unlock()
 * 역할: 턴 처리나 저장 완료 후 잠금 파일/핸들을 해제합니다.
 * 원본 대응: hako/hako-main.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function unlock() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	if ($lockMode == 1) {
		
		rmdir('hakojimalock');
	} elseif ($lockMode == 2) {
		
		hako_close('LOCKID');
	} elseif ($lockMode == 3) {
		
		@unlink('hakojimalock');
	} else {
		
		unset($i); $i = rename('key-locked', 'key-free');
	}
}




/*
 * 함수: aboutMoney()
 * 역할: 금액을 1000억 단위 표기처럼 화면용 문자열로 둥글게 처리합니다.
 * 원본 대응: hako/hako-main.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function aboutMoney() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	unset($m); $m = isset($_args[0]) ? $_args[0] : null;
	if ($m < 500) {
		return "추정500{$HunitMoney}미만";
	} else {
		$m = intval(($m + 500) / 1000);
		return "추정{$m}000{$HunitMoney}";
	}
}


/*
 * 함수: cutColumn()
 * 역할: 문자열을 지정 자리수로 잘라 표 출력 폭을 맞춥니다.
 * 원본 대응: hako/hako-main.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function cutColumn() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	unset($s); $s = isset($_args[0]) ? $_args[0] : null;
	unset($c); $c = isset($_args[1]) ? $_args[1] : null;
	if (length($s) <= $c) {
		return $s;
	} else {
		

		$ss = '';
		$count = 0;
		while ($count < $c) {
			hako_subst($s, '~(^[\\x80-\\xFF][\\x80-\\xFF])|(^[\\x00-\\x7F])~', '');
			if (hako_m(1)) {
				$ss .= hako_m(1);
				$count ++;
			} else {
				$ss .= hako_m(2);
			}
			$count ++;
		}
		return $ss;
	}
}


/*
 * 함수: nameToNumber()
 * 역할: 섬 이름으로 내부 배열 번호를 찾습니다. ID가 아니라 현재 Hislands 배열 인덱스를 반환합니다.
 * 원본 대응: hako/hako-main.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function nameToNumber() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	unset($name); $name = isset($_args[0]) ? $_args[0] : null;

	
	unset($i); $i = null;
	for ($i = 0; $i < $HislandNumber; $i++) {
		if (hako_index($Hislands[$i]['name'],$name) != -1) {
			return $i;
		}
	}
	

	return -1;
}


/*
 * 함수: monsterSpec()
 * 역할: 괴수 종류/체력/표시 정보를 조회합니다.
 * 원본 대응: hako/hako-main.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function monsterSpec() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	unset($lv); $lv = isset($_args[0]) ? $_args[0] : null;

	

	$kind = intval($lv / 10);

	
	$name = $HmonsterName[$kind];

	
	$hp = $lv - ($kind * 10);

	return array($kind, $name, $hp);
}


/*
 * 함수: expToLevel()
 * 역할: 경험치 기준으로 미사일 사거리 레벨을 계산합니다.
 * 원본 대응: hako/hako-main.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function expToLevel() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	unset($kind); $kind = isset($_args[0]) ? $_args[0] : null;
	unset($exp); $exp = isset($_args[1]) ? $_args[1] : null;
	unset($i); $i = null;
	if ($kind == $HlandBase) {
		
		for ($i = hako_last_index($baseLevelUp) + 2; $i > 1; $i--) {
			if ($exp >= $baseLevelUp[$i-2]) { return $i; }
		}
		return 1;
	} else {
		
		for ($i = hako_last_index($sBaseLevelUp) + 2; $i > 1; $i--) {
			if ($exp >= $sBaseLevelUp[$i-2]) { return $i; }
		}
		return 1;
	}
}


/*
 * 함수: expToLevel2()
 * 역할: 경험치 기준으로 발사 수/부대 계열 레벨을 계산합니다.
 * 원본 대응: hako/hako-main.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function expToLevel2() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	unset($kind); $kind = isset($_args[0]) ? $_args[0] : null;
	unset($exp); $exp = isset($_args[1]) ? $_args[1] : null;
	unset($i); $i = null;
	if ($kind == $HlandBase) {
		
		for ($i = hako_last_index($baseLevelUp2) + 2; $i > 1; $i--) {
			if ($exp >= $baseLevelUp2[$i-2]) { return $i; }
		}
		return 1;
	} else {
		
		for ($i = hako_last_index($sBaseLevelUp2) + 2; $i > 1; $i--) {
			if ($exp >= $sBaseLevelUp2[$i-2]) { return $i; }
		}
		return 1;
	}
}



/*
 * 함수: makeRandomPointArray()
 * 역할: 지도 전체 좌표와 6방향/18방향 탐색 순서를 난수 순서로 준비합니다.
 * 원본 대응: hako/hako-main.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function makeRandomPointArray() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	
	unset($i); $i = null;
	unset($y); $y = null;
	$Hrpx = array();
	$Hrpy = array();
	$Hrno6 = array();
	$Hrno18 = array();
	for ($__rep = 0; $__rep < $HislandSize; $__rep++) {
		for ($__x = 0; $__x < $HislandSize; $__x++) { $Hrpx[] = $__x; }
	}
	for ($y = 0; $y < $HislandSize; $y++) {
		for ($__x = 0; $__x < $HislandSize; $__x++) { $Hrpy[] = $y; }
	}
	

	for ($i = $HpointNumber; --$i; ) {
		$j = intval(hako_rand($i + 1));
		if ($i == $j) { continue; }
		$tmpx = $Hrpx[$i]; $Hrpx[$i] = $Hrpx[$j]; $Hrpx[$j] = $tmpx;
		$tmpy = $Hrpy[$i]; $Hrpy[$i] = $Hrpy[$j]; $Hrpy[$j] = $tmpy;
	}
	for ($_ = 1; $_ <= 6; $_++) {
		unset($r); $r = hako_rand(hako_arr_len($Hrno6) + 1);
		hako_push($Hrno6, isset($Hrno6[$r]) ? $Hrno6[$r] : null);
		$Hrno6[$r] = $_;
	}
	for ($_ = 1; $_ <= 18; $_++) {
		unset($r); $r = hako_rand(hako_arr_len($Hrno18) + 1);
		hako_push($Hrno18, isset($Hrno18[$r]) ? $Hrno18[$r] : null);
		$Hrno18[$r] = $_;
	}
}


/*
 * 함수: random()
 * 역할: 0부터 n-1까지의 원본 호환 난수를 반환합니다.
 * 원본 대응: hako/hako-main.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function random() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$max = isset($_args[0]) ? intval($_args[0]) : 0;
	return hako_rand($max);
}





/*
 * 함수: logFilePrint()
 * 역할: 지정된 과거 로그 파일을 화면에 출력합니다.
 * 원본 대응: hako/hako-main.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logFilePrint() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	unset($fileNumber); $fileNumber = isset($_args[0]) ? $_args[0] : null;
	unset($id); $id = isset($_args[1]) ? $_args[1] : null;
	unset($mode); $mode = isset($_args[2]) ? $_args[2] : null;
	unset($mode2); $mode2 = isset($_args[3]) ? $_args[3] : null;
	hako_open('LIN', "{$HdirName}/hakojima.log{$fileNumber}");
	unset($line); $line = null;
	unset($m); $m = null;
	unset($turn); $turn = null;
	unset($id1); $id1 = null;
	unset($id2); $id2 = null;
	unset($id3); $id3 = null;
	unset($message); $message = null;
	$set_turn = 0;
	while ($line = hako_getline('LIN')) {
		hako_regex('~^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),(.*)$~', $line);
		$_list_tmp = array(hako_m(1), hako_m(2), hako_m(3), hako_m(4), hako_m(5), hako_m(6));
		$m = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
		$turn = isset($_list_tmp[1]) ? $_list_tmp[1] : null;
		$id1 = isset($_list_tmp[2]) ? $_list_tmp[2] : null;
		$id2 = isset($_list_tmp[3]) ? $_list_tmp[3] : null;
		$id3 = isset($_list_tmp[4]) ? $_list_tmp[4] : null;
		$message = isset($_list_tmp[5]) ? $_list_tmp[5] : null;
		
		if ($m == 1) {
			if (($mode == 0) || ($id1 != $id)) { continue; }
			$m = "{$HtagNumber_}<B>(기밀)</B>{$H_tagNumber}：";
		} elseif ($m == 2) {
			
			if ($mode2 == 2) { continue; }
			$m = '';
		} else{				if ($m == 9) { $id = 0; } 
			$m = '';
		}

		
		if ($id != 0) {
			if (($id != $id1) && ($id != $id2) && ($id != $id3)) { continue; }
		}
		
		if ($set_turn == 0) {
			out("<NOBR><B>=====[<span class=number><FONT SIZE=4> 턴 $turn </FONT></span>]================================================</B><NOBR><BR>\n");
			$set_turn++;
		}
		out("<NOBR>{$m}{$message}</NOBR><BR>\n");
	}
	hako_close('LIN');
}




/*
 * 함수: logPrintHtml()
 * 역할: 최근 로그 HTML 파일을 생성합니다.
 * 원본 대응: hako/hako-main.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function logPrintHtml() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	$_list_tmp = hako_localtime(time());
	unset($sec); $sec = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
	unset($min); $min = isset($_list_tmp[1]) ? $_list_tmp[1] : null;
	unset($hour); $hour = isset($_list_tmp[2]) ? $_list_tmp[2] : null;
	unset($date); $date = isset($_list_tmp[3]) ? $_list_tmp[3] : null;
	unset($mon); $mon = isset($_list_tmp[4]) ? $_list_tmp[4] : null;
	unset($year); $year = isset($_list_tmp[5]) ? $_list_tmp[5] : null;
	unset($day); $day = isset($_list_tmp[6]) ? $_list_tmp[6] : null;
	unset($yday); $yday = isset($_list_tmp[7]) ? $_list_tmp[7] : null;
	unset($dummy); $dummy = isset($_list_tmp[8]) ? $_list_tmp[8] : null;
	$mon++;
	$sss = "{$mon}월{$date}일 {$hour}시 {$min}분 {$sec}초";

	$html1  = temphead("최근의 사건");
	$html1 .= <<<HAKOHDOC_0
<BODY $htmlBody><DIV ID='BodySpecial'>
<DIV ID='RecentlyLog'>
<H1>최근의 사건</H1>
<FORM>
최신 갱신일：$sss::
<INPUT TYPE="button" VALUE="다시 읽기 보고" onClick="location.reload()">
</FORM>
<hr>
HAKOHDOC_0
;

$html3= <<<HAKOHDOC_1
</DIV><HR></DIV></BODY></HTML>
HAKOHDOC_1
;
	unset($i); $i = null;
	$mark = array('★', '', '■', '', '', '', '', '', '', '●');
	for ($i = 0; $i < $HtopLogTurn; $i++) {
		$id =0;
		$mode = 0;
		$set_turn = 0;
		hako_open('LIN', "{$HdirName}/hakojima.log$i");
		unset($line); $line = null;
		unset($m); $m = null;
		unset($turn); $turn = null;
		unset($id1); $id1 = null;
		unset($id2); $id2 = null;
		unset($id3); $id3 = null;
		unset($message); $message = null;
		while ($line = hako_getline('LIN')) {
			hako_regex('~^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),(.*)$~', $line);
			$_list_tmp = array(hako_m(1), hako_m(2), hako_m(3), hako_m(4), hako_m(5), hako_m(6));
			$m = isset($_list_tmp[0]) ? $_list_tmp[0] : null;
			$turn = isset($_list_tmp[1]) ? $_list_tmp[1] : null;
			$id1 = isset($_list_tmp[2]) ? $_list_tmp[2] : null;
			$id2 = isset($_list_tmp[3]) ? $_list_tmp[3] : null;
			$id3 = isset($_list_tmp[4]) ? $_list_tmp[4] : null;
			$message = isset($_list_tmp[5]) ? $_list_tmp[5] : null;

			
			if ($m == 1) {
				if (!$mode || ($id1 != $id)) { continue; }
			}

			
			if ($id != 0) {
				if (($id != $id1) && ($id != $id2) && ($id != $id3)) { continue; }
			}

			
			if ($set_turn == 0) {
				$html2 .= "<NOBR><B>=====[<span class=number><FONT SIZE=4> 턴 $turn </FONT></span>]================================================</B><NOBR><BR>\n";
				$set_turn++;
			}
			$html2 .= "<NOBR>{$HtagNumber_}$mark[$m]:{$H_tagNumber}$message</NOBR><BR>\n";
		}
		hako_close('LIN');
	}
	hako_open('HTML', ">hakolog.html");
	hako_write('HTML', $html1);
	hako_write('HTML', $html2);
	hako_write('HTML', $html3);
	hako_close('HTML');
	@chmod("hakolog.html", 0666);
}






/*
 * 함수: tempLockFail()
 * 역할: 파일 잠금 실패 안내 화면을 출력합니다.
 * 원본 대응: hako/hako-main.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function tempLockFail() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	

	out(<<<HAKOHDOC_2
{$HtagBig_}동시 엑세스 에러 입니다.<BR>
브라우저의 「돌아온다」버튼을 눌러,<BR>
당분간 기다리고 나서 재차 시험해 주세요. {$H_tagBig}$HtempBack
HAKOHDOC_2
);
}


/*
 * 함수: tempUnlock()
 * 역할: 잠금 강제 해제 안내 화면을 출력합니다.
 * 원본 대응: hako/hako-main.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function tempUnlock() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	

	out(<<<HAKOHDOC_3
{$HtagBig_}전회의 액세스가 이상종료(ABEND)였던 것 같습니다. <BR>
락을 강제 해제했습니다. {$H_tagBig}$HtempBack
HAKOHDOC_3
);
}


/*
 * 함수: tempNoHpasswordFile()
 * 역할: 패스워드 파일이 없을 때의 원본 오류 화면입니다.
 * 원본 대응: hako/hako-main.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function tempNoHpasswordFile() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	out("{$HtagBig_}패스워드 파일이 열리지 않습니다. {$H_tagBig}{$HtempBack}\n");
}


/*
 * 함수: tempNoDataFile()
 * 역할: 메인 데이터 파일이 없을 때의 원본 오류 화면입니다.
 * 원본 대응: hako/hako-main.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function tempNoDataFile() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	out("{$HtagBig_}데이터 파일이 열리지 않습니다.{$H_tagBig}{$HtempBack}\n");
}


/*
 * 함수: tempBadName()
 * 역할: 섬 이름/입력값이 부정할 때의 오류 화면입니다.
 * 원본 대응: hako/hako-main.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function tempBadName() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	Dummyfunction();
	out(<<<HAKOHDOC_6
{$HtagBig_}',?()<>\"\'\$'등의 문자는, 사용할 수 없습니다.{$H_tagBig}$HtempBack
HAKOHDOC_6
);
}


/*
 * 함수: tempProblem()
 * 역할: 기타 문제 발생 시 공통 오류 화면입니다.
 * 원본 대응: hako/hako-main.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function tempProblem() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	out("{$HtagBig_}문제 발생 우선 돌아와 주세요.{$H_tagBig}{$HtempBack}\n");
}


/*
 * 함수: mente_mode()
 * 역할: 메인터넌스 중 접근했을 때 안내 화면을 출력합니다.
 * 원본 대응: hako/hako-main.cgi 의 같은 이름 또는 같은 역할의 처리 블록.
 * 유지보수: 인자 순서, 전역 변수 참조, 저장 배열 인덱스, echo/out 출력 문자열을 임의 변경하지 마십시오.
 * PHP 5.5 주의: 원본 CGI의 미정의값/빈 문자열 판정과 PHP isset/empty 판정 차이가 화면 경고나 저장 누락으로 이어질 수 있습니다.
 */
function mente_mode() {
    foreach ($GLOBALS as $__hako_global_key => $__hako_global_val) { if ($__hako_global_key !== 'GLOBALS') { ${$__hako_global_key} =& $GLOBALS[$__hako_global_key]; } } unset($__hako_global_val);
    $_args = func_get_args();
	
	$mode = isset($_args[0]) ? $_args[0] : null;
	if ($mode) { tempHeader(); }

	
	out("{$HtagBig_}지금 점검중입니다.<br> 잠시 기다려 주세요{$H_tagBig}");

	out("<BR><BR><BR>※　점검중 모드는, 관리인이 hako-mente.php의 관리인실에서(설정｜해제) 가능합니다. ");

	
	tempFooter();

	
	exit(0);
}





?>
