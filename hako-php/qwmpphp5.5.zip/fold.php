<?php
























function fold($str, $width) {
    if (function_exists('mb_strimwidth')) {
        $head = mb_strimwidth($str, 0, $width, '', 'UTF-8');
        $rest = mb_substr($str, mb_strlen($head, 'UTF-8'), null, 'UTF-8');
        return array($head, $rest);
    }
    return array(substr($str, 0, $width), substr($str, $width));
}
?>
