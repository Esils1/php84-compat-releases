<?php
















require_once './init.php';
require_once './registkey_lib.php';
wf_apply_hako_globals();


$crypt = isset($_SERVER['QUERY_STRING']) ? $_SERVER['QUERY_STRING'] : '';


$plain = wf_registkey_plain($crypt);
$code = '0000';
if ($plain !== false && preg_match('/^(\d{4})/', $plain, $m)) { $code = $m[1]; }
if (!headers_sent()) { header('Content-Type: image/svg+xml; charset=UTF-8'); }


echo '<?xml version="1.0" encoding="UTF-8"?>';
echo '<svg xmlns="http://www.w3.org/2000/svg" width="58" height="22" viewBox="0 0 58 22">';
echo '<rect width="58" height="22" fill="#EEEEEE"/>';
echo '<text x="6" y="16" font-family="Arial, sans-serif" font-size="16" font-weight="bold" fill="#dd0000">' . wf_h($code) . '</text>';
echo '</svg>';
?>
