<?php
if (!isset($_hako_fh)) { $_hako_fh = array(); }

if (!isset($GLOBALS['_hako_req_start'])) { $GLOBALS['_hako_req_start'] = microtime(true); }
if (!isset($GLOBALS['_hako_req_ru_start'])) { $GLOBALS['_hako_req_ru_start'] = function_exists('getrusage') ? getrusage() : null; }
if (!function_exists('hako_cpu_times')) {
function hako_cpu_times() {
    $startRu = isset($GLOBALS['_hako_req_ru_start']) ? $GLOBALS['_hako_req_ru_start'] : null;
    if (function_exists('getrusage') && is_array($startRu)) {
        $r = getrusage();
        $u0 = (isset($startRu['ru_utime.tv_sec']) ? $startRu['ru_utime.tv_sec'] : 0) + (isset($startRu['ru_utime.tv_usec']) ? $startRu['ru_utime.tv_usec'] : 0) / 1000000;
        $s0 = (isset($startRu['ru_stime.tv_sec']) ? $startRu['ru_stime.tv_sec'] : 0) + (isset($startRu['ru_stime.tv_usec']) ? $startRu['ru_stime.tv_usec'] : 0) / 1000000;
        $u1 = (isset($r['ru_utime.tv_sec']) ? $r['ru_utime.tv_sec'] : 0) + (isset($r['ru_utime.tv_usec']) ? $r['ru_utime.tv_usec'] : 0) / 1000000;
        $s1 = (isset($r['ru_stime.tv_sec']) ? $r['ru_stime.tv_sec'] : 0) + (isset($r['ru_stime.tv_usec']) ? $r['ru_stime.tv_usec'] : 0) / 1000000;
        $uti = max(0, $u1 - $u0);
        $sti = max(0, $s1 - $s0);
        return array(round($uti + $sti, 4), round($uti, 4), round($sti, 4));
    }
    $start = isset($GLOBALS['_hako_req_start']) ? $GLOBALS['_hako_req_start'] : (isset($_SERVER['REQUEST_TIME_FLOAT']) ? $_SERVER['REQUEST_TIME_FLOAT'] : microtime(true));
    $elapsed = microtime(true) - $start;
    if ($elapsed < 0) { $elapsed = 0; }
    return array(round($elapsed, 4), round($elapsed, 4), 0);
}
}
if (!function_exists('hako_open')) {
  function hako_open($name, $spec) {
    global $_hako_fh;
    $mode = 'r';
    $path = $spec;
    if (substr($path, 0, 2) === '>>') { $mode = 'a'; $path = substr($path, 2); }
    elseif (substr($path, 0, 1) === '>') { $mode = 'w'; $path = substr($path, 1); }
    elseif (substr($path, 0, 1) === '<') { $mode = 'r'; $path = substr($path, 1); }
    if (($mode === 'w' || $mode === 'a') && ($dir = dirname($path)) && $dir !== '.' && !is_dir($dir)) { @mkdir($dir, 0777, true); }
    $_hako_fh[$name] = @fopen($path, $mode);
    return $_hako_fh[$name];
  }
  function hako_close($name) {
    global $_hako_fh;
    if (isset($_hako_fh[$name]) && is_resource($_hako_fh[$name])) { fclose($_hako_fh[$name]); }
  }
  function hako_getline($name) {
    global $_hako_fh;
    if (!isset($_hako_fh[$name]) || !$_hako_fh[$name]) { return false; }
    return fgets($_hako_fh[$name]);
  }
  function hako_write($name, $data) {
    global $_hako_fh;
    if (!isset($_hako_fh[$name]) || !$_hako_fh[$name]) { return false; }
    return fwrite($_hako_fh[$name], $data);
  }
  function hako_cmp($a, $b) {
    if ($a == $b) { return 0; }
    return ($a < $b) ? -1 : 1;
  }
  function hako_reorder($array, $idx) {
    $out = array();
    foreach ($idx as $i) { if (isset($array[$i])) { $out[] = $array[$i]; } }
    return $out;
  }
  function hako_pick($array, $keys) {
    $out = array();
    foreach ($keys as $key) { $out[] = isset($array[$key]) ? $array[$key] : null; }
    return $out;
  }
  function hako_idx($array, $idx) {
    return isset($array[$idx]) ? $array[$idx] : null;
  }
}
//----------------------------------------------------------------------
// 모형정원 제도 ver2. 30
// 턴 진행 모듈(ver1. 02)
// 사용 조건, 사용 방법등은, hako-readme.txt 파일을 참조
// 모형정원 제도의 페이지: http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html
//----------------------------------------------------------------------
// 구상의 모형정원(ver5. 54d)
//----------------------------------------------------------------------

//----------------------------------------------------------------------
// 턴 진행 모드
//----------------------------------------------------------------------
// 메인
function turnMain() {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $H_tagName2, $Haidpop, $Hallyflg, $Hallygroup, $haribote, $Hatkturn, $HbackupTimes, $HbackupTurn, $HbgInfoCell, $HbgTitleCell, $HbigcityFood, $HbigCityMFlg, $HcomBank, $HcomBase, $HcomBioMissile, $HcomBreakwater, $Hcomcolony, $HcomcolonyTurn, $HcomCost, $HcomDbase, $HcomDeathtrap, $HcomDestroy, $HcomDestroy2, $HcomDokan, $HcomDoNothing, $HcomDummy, $HcomEmigration, $HcomFactory, $HcomFarm, $HcomFire, $HcomFlower, $HcomFood, $HcomGiveup, $HcomHaribote, $HcomHospital, $HcomL, $HcommandMax, $HcomManipulate, $HcomMissileDM, $HcomMissileGM, $HcomMissileLD, $HcomMissileMGM, $HcomMissileNCM, $HcomMissileNM, $HcomMissilePLD, $HcomMissilePP, $HcomMissileRM, $HcomMissileRNG, $HcomMissileSPP, $HcomMissileSRM, $HcomMissileST, $HcomMoney, $HcomMonsAid, $HcomMonsEgg, $HcomMonsEnsei, $HcomMonsEsa, $HcomMonsEsaAid, $HcomMonsExer, $HcomMonsSell, $HcomMonsTettai, $HcomMonument, $HcomMountain, $HcomMyhome, $HcomName, $HcomOilBuy, $HcomOilSell, $HcomOMissileMGM, $HcomOMissileNM, $HcomOMissilePP, $HcomOMissileSPP, $HcomOreBuy, $HcomOreSell, $HcomPioneer, $HcomPlant, $HcomPolice, $HcomPort, $HcomPrepare, $HcomPrepare2, $HcomPresent, $HcomPresentAid, $HcomPropaganda, $HcomReclaim, $HcomReclaim2, $HcomSbase, $HcomSBuild, $HcomScity, $HcomSDbase, $HcomSDestroy, $HcomSearch, $HcomSEisei, $HcomSell, $HcomSellTree, $HcomSendMonster, $HcomSendMonsterTurn, $HcomSFactory, $HcomSFarm, $HcomSFood, $HcomShip, $HcomShipbuild, $HcomShipM, $HcomShipSell, $HcomSMissile, $HcomSMissileGM, $HcomSMissileMGM, $HcomSMissilePP, $HcomSMonument, $HcomSOccupy, $HcomSpaceBase, $HcomSpaceFarm, $HcomSpecialSPP, $HcomSPioneer, $HcomSpy, $HcomSSendMonster, $HcomSSendMonsterTurn, $HcomSTManipulate, $HcomSUnit, $HcomTeisatu, $HcomTower, $HcomTrump, $HcomUg, $HcomWarp, $HcomWeponBuy, $HcomWeponSell, $HcomWindmill, $HconsolationMatch, $HcurrentNumber, $HdBaseAuto, $HdefenceHex, $HdefenceSpace, $HdevelopeTurn, $HdirMode, $HdirName, $HdisAEruption, $HdisAkasio, $HdisBHarvest, $HdisCrime, $HdisEarthquake, $HdisEruption, $HdisFallBorder, $HdisFalldown, $HdisFire, $HdisGHarvest, $Hdishangen, $HdisHugeMeteo, $HdisKLimit, $HdisMaizo, $HdisMeteo, $HdisMonsBorder1, $HdisMonsBorder2, $HdisMonsBorder3, $HdisMonsBorder4, $HdisMonsBorder5, $HdisMonster, $HdisMonsterU, $HdisPirate, $HdisPollution, $HdisSeaMonster, $HdisSHugeMeteo, $HdisSpaceMonster1, $HdisSpaceMonster2, $HdisTinka, $HdisTreasureS, $HdisTsunami, $HdisTyphoon, $HdisUN, $HdisVGHarvest, $HearthAttack, $HeatenFood, $helpDir, $HfightMem, $HfightTurn, $HfinalTurn, $HgiveupTurn, $HhistoryMax, $HidToName, $HidToNumber, $HidToNumberR, $HinterTime, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HlandAegisShip, $HlandAirport, $HlandAmusement, $HlandBalloonS, $HlandBank, $HlandBase, $HlandBigcity, $HlandBreakwater, $HlandCasino, $HlandCoupleRock, $HlandDeathtrap, $HlandDefence, $HlandDokan, $HlandDome, $HlandEarth, $HlandExpo, $HlandFactory, $HlandFarm, $HlandFire, $HlandFishLShip, $HlandFishMShip, $HlandFishSShip, $HlandFlower, $HlandForest, $HlandFuji, $HlandGhostShip, $HlandHaribote, $HlandHospital, $HlandHugecity, $HlandIceFloe, $HlandKInora, $HlandMegacity, $HlandMegaFact, $HlandMegaFarm, $HlandMegatower, $HlandMonsShip, $HlandMonster, $HlandMonument, $HlandMountain, $HlandMyhome, $HlandOcean, $HlandOil, $HlandOPlayer, $HlandOsen, $HlandPark, $HlandPirate, $HlandPlains, $HlandPolice, $HlandPort, $HlandProbeShip, $HlandSAEisei, $HlandSbase, $HlandSchool, $HlandSCity, $HlandSDefence, $HlandSea, $HlandSeisei, $HlandSFactory, $HlandSFarm, $HlandSlum, $HlandSMonument, $HlandSpaceBase, $HlandStadium, $HlandSunit, $HlandTcity, $HlandTitanic, $HlandTower, $HlandTown, $HlandTreasureS, $HlandTrump, $HlandWarp, $HlandWarpR, $HlandWaste, $HlandWindmill, $HlandWingDragon, $HlandZoo, $HlateLogPool, $HlogMax, $HlogOmit2, $HlogPool, $HmaxdisPollution, $HmaxExpPoint, $HmaxIsland, $HmonsBtlMaxHp, $HmonsBtlMaxPa, $HmonsterAGI, $HmonsterBHP, $HmonsterCLS, $HmonsterDEF, $HmonsterDestroy, $HmonsterDHP, $HmonsterExp, $HmonsterGRP, $HmonsterL1, $HmonsterL1Num, $HmonsterL2, $HmonsterL2Num, $HmonsterL3, $HmonsterL3Num, $HmonsterL4, $HmonsterL4Num, $HmonsterL5, $HmonsterL5Num, $HmonsterName, $HmonsterNumber, $HmonsterS, $HmonsterSEI, $HmonsterSKL, $HmonsterSP, $HmonsterSpecial, $HmonsterSTR, $HmonsterValue, $Hmonth, $HmonumentMissile, $HmonumentName, $HmonumentRocket, $Hocean, $HoceanSize, $HoilMoney, $HoilRatio, $hp, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $Hprize, $HprizeV, $HpunishInfo, $HrepeatTurn, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $HseaChk, $HsecretLogPool, $HsEisei, $HshipEX, $HshipFood, $HshipHP, $HshipKAI, $HshipMATK, $HshipMoney, $HshipName, $Hshiporder, $HshipSATK, $HshipSell, $HshipSP, $HsmonumentName, $HsmonumentNumber, $Hsolarwind, $Hspace, $HspaceEfficiency, $HspaceIncome, $Hsstartturn, $HStotalPoint, $HsurvFlg, $Hsurvivalturn, $HtagName2_, $HthisFile, $HtotalBumon, $HtotalMoney, $HtotalPoint, $Htournament, $HtreeValue, $HturnPrizeNumber, $HturnPrizePoint, $HturnPrizeUnit, $HturnPrizeVarious, $HugDokan, $HugFact, $HugFarm, $HugHasigo, $HugKiti, $HugMax, $HugOil, $HugRoad, $HugSpace, $HugTosi, $human, $HunitFood, $HunitMoney, $HunitOil, $HunitOre, $HunitPop, $HunitTime, $HunitWeapon, $HwarFlg, $HWeatherMax, $Hwflg, $HwinFood, $HwinIsland, $HwinMoney, $HwinWeapon, $imageDir, $lockMode, $toppage, $versionInfo;
	$i = null; $j = null;
	if (!isset($HlogPool) || !is_array($HlogPool)) { $HlogPool = array(); }
	if (!isset($HlateLogPool) || !is_array($HlateLogPool)) { $HlateLogPool = array(); }
	if (!isset($HsecretLogPool) || !is_array($HsecretLogPool)) { $HsecretLogPool = array(); }
	// 최종 갱신 시간을 갱신
	if($HrepeatTurn > 0){
		if($HislandTurn % $HrepeatTurn == ($HrepeatTurn-1)){
			$HislandLastTime += $HunitTime;
		}
	}else{
		$HislandLastTime += $HunitTime;
	}

	// 좌표 배열을 만든다
	makeRandomPointArray();
	makeRandomOceanPointArray();

	// 턴 번호
	$HislandTurn++;
	
	// 계절 처리
	$Hmonth = ($HislandTurn % 12) + 1;

	// 차례 결정
	$order = randomArray($HislandNumber);

	// 자원 거래의 패널티 처리
	penaltyExchange();

	$HmonsterSpecial[19] = random(7) + 2; # ´램也繞侊걋?2≠8)

	if($Hdishangen){
		// 재해 반감기를 도입한다.
		if((intval($HislandTurn / 100) % 2) == 0){
			// 확률 반감, 모두는 아니다.
			$HdisEarthquake /= 2;
			$HdisTsunami /= 2;
			$HdisTyphoon /= 2;
			$HdisMeteo  /= 2;
			$HdisHugeMeteo /= 2;
			$HdisEruption /= 2;
			$HdisFire /= 2;
			$HdisAkasio  /= 2;
			$HdisAEruption /= 2;
			$HdisPirate  /= 2;
			$HdisPollution /= 2;
			$HdisMonster /= 2;
		}
	}

	// 계절에 의한 변동
	if(($Hmonth < 4) || (11 < $Hmonth)){
		$HdisAkasio = 0;
		$HdisTyphoon = 0;
	}

	// 참가도에의 제재 내용을 읽어들인다
	readPunishData();

	// 수입, 소비 페이즈
	for($i = 0; $i < $HislandNumber; $i++){
		estimateS($order[$i]);
		$Hislands[$order[$i]]['oldmoney'] = $Hislands[$order[$i]]['money'];
		$Hislands[$order[$i]]['oldfood'] = $Hislands[$order[$i]]['food'];
		// 턴 개시 앞 사람구를 메모한다
		$Hislands[$order[$i]]['oldPop'] = $Hislands[$order[$i]]['pop'];
		if ($Hislands[$order[$i]]['predelete']) { continue; }
		$island =& $Hislands[$order[$i]];
		income($order[$i], $island);
		unset($island);
	}
	spaceEstimate(0);# 우주 처리

	doCommandLate(); # 턴 차이 명령

	// 커멘드 처리
	for($i = 0; $i < $HislandNumber; $i++){
		$island =& $Hislands[$order[$i]];
		if ($island['predelete']) { continue; }
		// 반환값 1이 될 때까지 반복
		$Hwflg = 10;# 기후에 의한 반환의 최대수(안전책)
		while(!doCommand($island)){};
		// 정지 로그(정리해 로그 출력)
		if ($HlogOmit2) { logMatome($island, $HlogOmit2, 'seichi'); }
	}
	unset($island);

	// Battle Field용구상 이노라 플래그
	if($HislandTurn > 250){
		if (($HislandTurn % $HturnPrizeUnit) == 0) { $kinoraFlg = 1; }
	}

	$HearthAttack = 0; # 지구 공격이 되었는지
	spaceHex();# 우주 성장 처리
	oceanHex();# 해역 성장 처리
	// 성장 및 단헥스 재해
	for($i = 0; $i < $HislandNumber; $i++){
		if ($Hislands[$order[$i]]['predelete']) { continue; }
		$island =& $Hislands[$order[$i]];
		doEachHex($island);
		unset($island);
	}
	
	// 도전체 처리
	$remainNumber = $HislandNumber;
	unset($island);
	$island = null;
	// 괴수 배틀 턴배용 변수 초기화
	$MonsBattleTurn = 2; # 최악이어도 3승 이상
	$MonsBattleTurnID = 0;

	global $allPop, $allMoney, $allArea, $allBank, $allMissileA, $allFarm, $allTower, $allIndustry, $allYousyoku, $allForest;
	list($allPop,$allMoney,$allArea,$allBank,$allMissileA,$allFarm,$allTower,$allIndustry,$allYousyoku,$allForest) = array(0,0,0,0,0,0,0,0,0,0);
	for($i = 0; $i < $HislandNumber; $i++){
		$island =& $Hislands[$order[$i]];
		if ($island['predelete']) { continue; }
		doIslandProcess($order[$i], $island);
		// 사멸 판정
		if($island['dead'] == 1){
			$island['pop'] = -100;
			$remainNumber--;
			OceanMente($island['id']);
		}elseif(($island['pop'] == 0) && ($island['id'] <= 90)) {
			$island['dead'] = 1;
			$island['pop'] = -100;
			$remainNumber--;
			OceanMente($island['id']);
			// 사멸 메세지
			$tmpid = $island['id'];
			logDead($tmpid, $island['name']);
		}
	}
	unset($island);
	// 자원 거래의 턴 처리 준비
	turnExchangeBegin();
	// 상인이 거래를 해?
	if (mt_rand(0, 99) < 100) { # 10%
		merchantInviteExchange();
	}
	// 자원 거래의 턴 처리
	turnExchange();

	for($i = 0; $i < $HislandNumber; $i++){
		$island =& $Hislands[$order[$i]];
		doIslandProcess2($island);
		unset($island);
	}
	
	spaceEstimate(1);# 우주 처리

	// 인구 처리·수지
	for($i = 0; $i < $HislandNumber; $i++){
		$island =& $Hislands[$order[$i]];
		$island['pop'] += $island['popspace'];
		if($island['pop'] < 1){
			$island['rank'] = -100;
		}else{
			$island['rank'] = $island['allex'];
		}
	}
	unset($island);
	
	// 통계
	$allBank2;
	if($allBank > 0){
		$allBank2 = ", 총예금 ${allBank}000${HunitMoney}";
	}else{
		$allBank2 = "";
	}
	array_push($HlogPool, "0,$HislandTurn,0,,모형정원 제도 통계：총인구 ${allPop}${HunitPop}, 총면적 ${allArea}${HunitArea}, 총자금 $allMoney${HunitMoney}${allBank2}");

	if(($HislandTurn % $HturnPrizeVarious) == 0){
		// 부문상

		// 부문상의 턴에 통계의 로그를 취한다
		hako_open('POUT',">>${HlogdirName}/statistical.log");
		hako_write('POUT', "$HislandTurn,$allPop,$allMoney,$allArea,$allBank,$allMissileA,$allFarm,$allTower,$allIndustry,$allYousyoku,$allForest,$HislandNumber\n");
		hako_close('POUT');

		// 농업왕
		$idx = range(0, count($Hislands) - 1);
		usort($idx, function($a, $b) { global $Hislands, $rekidai, $HtotalPoint, $HtotalMoney, $HtotalBumon, $HStotalPoint, $DATA, $LandCount, $LandCount2, $allyPop; $c = hako_cmp($Hislands[$b]['farm'], $Hislands[$a]['farm']); return ($c != 0) ? $c : hako_cmp($a, $b); });
		$tIsland =& $Hislands[$idx[0]];
		if($tIsland['farm'] > 0){
			$tIsland['status'] |= 1;
			$tIsland['zyuni'] += $HturnPrizePoint;
			logPrizeV($tIsland['id'], $tIsland['name'], $HprizeV[1]);
			if ($HsurvFlg) { $tIsland['money'] += 2000; }
		}
		// 공업왕
		usort($idx, function($a, $b) { global $Hislands, $rekidai, $HtotalPoint, $HtotalMoney, $HtotalBumon, $HStotalPoint, $DATA, $LandCount, $LandCount2, $allyPop; $c = hako_cmp($Hislands[$b]['industry'], $Hislands[$a]['industry']); return ($c != 0) ? $c : hako_cmp($a, $b); });
		$tIsland =& $Hislands[$idx[0]];
		if($tIsland['industry'] > 0){
			$tIsland['status'] |= 2;
			$tIsland['zyuni'] += $HturnPrizePoint;
			logPrizeV($tIsland['id'], $tIsland['name'], $HprizeV[2]);
			if ($HsurvFlg) { $tIsland['money'] += 2000; }
		}
		// 상업왕
		usort($idx, function($a, $b) { global $Hislands, $rekidai, $HtotalPoint, $HtotalMoney, $HtotalBumon, $HStotalPoint, $DATA, $LandCount, $LandCount2, $allyPop; $c = hako_cmp($Hislands[$b]['tower'], $Hislands[$a]['tower']); return ($c != 0) ? $c : hako_cmp($a, $b); });
		$tIsland =& $Hislands[$idx[0]];
		if($tIsland['tower'] > 0){
			$tIsland['status'] |= 4;
			$tIsland['zyuni'] += $HturnPrizePoint;
			logPrizeV($tIsland['id'], $tIsland['name'], $HprizeV[3]);
			if ($HsurvFlg) { $tIsland['money'] += 2000; }
		}
		// 수산왕
		usort($idx, function($a, $b) { global $Hislands, $rekidai, $HtotalPoint, $HtotalMoney, $HtotalBumon, $HStotalPoint, $DATA, $LandCount, $LandCount2, $allyPop; $c = hako_cmp($Hislands[$b]['yousyoku'], $Hislands[$a]['yousyoku']); return ($c != 0) ? $c : hako_cmp($a, $b); });
		$tIsland =& $Hislands[$idx[0]];
		if($tIsland['yousyoku'] > 0){
			$tIsland['status'] |= 8;
			$tIsland['zyuni'] += $HturnPrizePoint;
			logPrizeV($tIsland['id'], $tIsland['name'], $HprizeV[4]);
			if ($HsurvFlg) { $tIsland['money'] += 2000; }
		}
		// 삼림왕
		usort($idx, function($a, $b) { global $Hislands, $rekidai, $HtotalPoint, $HtotalMoney, $HtotalBumon, $HStotalPoint, $DATA, $LandCount, $LandCount2, $allyPop; $c = hako_cmp($Hislands[$b]['forestV'], $Hislands[$a]['forestV']); return ($c != 0) ? $c : hako_cmp($a, $b); });
		$tIsland =& $Hislands[$idx[0]];
		if($tIsland['forestV'] > 0){
			$tIsland['status'] |= 16;
			$tIsland['zyuni'] += $HturnPrizePoint;
			logPrizeV($tIsland['id'], $tIsland['name'], $HprizeV[5]);
			if ($HsurvFlg) { $tIsland['money'] += 2000; }
		}
		// 미사일왕
		// 삼림왕
		usort($idx, function($a, $b) { global $Hislands, $rekidai, $HtotalPoint, $HtotalMoney, $HtotalBumon, $HStotalPoint, $DATA, $LandCount, $LandCount2, $allyPop; $c = hako_cmp($Hislands[$b]['MissileK'], $Hislands[$a]['MissileK']); return ($c != 0) ? $c : hako_cmp($a, $b); });
		$tIsland =& $Hislands[$idx[0]];
		if($tIsland['MissileK'] > 0){
			$tIsland['status'] |= 32;
			$tIsland['zyuni'] += $HturnPrizePoint;
			logPrizeV($tIsland['id'], $tIsland['name'], $HprizeV[6]);
			if ($HsurvFlg) { $tIsland['money'] += 2000; }
		}
		// 위장 방위 시설왕
		usort($idx, function($a, $b) { global $Hislands, $rekidai, $HtotalPoint, $HtotalMoney, $HtotalBumon, $HStotalPoint, $DATA, $LandCount, $LandCount2, $allyPop; $c = hako_cmp($Hislands[$b]['haribote'], $Hislands[$a]['haribote']); return ($c != 0) ? $c : hako_cmp($a, $b); });
		$tIsland =& $Hislands[$idx[0]];
		if($tIsland['haribote'] > 0){
			$tIsland['status'] |= 64;
			$tIsland['zyuni'] += $HturnPrizePoint;
			logPrizeV($tIsland['id'], $tIsland['name'], $HprizeV[7]);
			if ($HsurvFlg) { $tIsland['money'] += 2000; }
		}
		// 괴수왕
		usort($idx, function($a, $b) { global $Hislands, $rekidai, $HtotalPoint, $HtotalMoney, $HtotalBumon, $HStotalPoint, $DATA, $LandCount, $LandCount2, $allyPop; $c = hako_cmp($Hislands[$b]['mons'], $Hislands[$a]['mons']); return ($c != 0) ? $c : hako_cmp($a, $b); });
		$tIsland =& $Hislands[$idx[0]];
		if($tIsland['mons'] > 0){
			$tIsland['status'] |= 128;
			$tIsland['zyuni'] += $HturnPrizePoint;
			logPrizeV($tIsland['id'], $tIsland['name'], $HprizeV[8]);
			if ($HsurvFlg) { $tIsland['money'] += 2000; }
		}
		// 석유왕
		usort($idx, function($a, $b) { global $Hislands, $rekidai, $HtotalPoint, $HtotalMoney, $HtotalBumon, $HStotalPoint, $DATA, $LandCount, $LandCount2, $allyPop; $c = hako_cmp($Hislands[$b]['oilfield'], $Hislands[$a]['oilfield']); return ($c != 0) ? $c : hako_cmp($a, $b); });
		$tIsland =& $Hislands[$idx[0]];
		if($tIsland['oilfield'] > 0){
			$tIsland['status'] |= 256;
			$tIsland['zyuni'] += $HturnPrizePoint;
			logPrizeV($tIsland['id'], $tIsland['name'], $HprizeV[9]);
			if ($HsurvFlg) { $tIsland['money'] += 2000; }
		}
		// 재해왕
		usort($idx, function($a, $b) { global $Hislands, $rekidai, $HtotalPoint, $HtotalMoney, $HtotalBumon, $HStotalPoint, $DATA, $LandCount, $LandCount2, $allyPop; $c = hako_cmp($Hislands[$b]['score2'], $Hislands[$a]['score2']); return ($c != 0) ? $c : hako_cmp($a, $b); });
		$tIsland =& $Hislands[$idx[0]];
		if($tIsland['score2'] > 0){
			$tIsland['status'] |= 512;
			$tIsland['zyuni'] += $HturnPrizePoint;
			logPrizeV($tIsland['id'], $tIsland['name'], $HprizeV[10]);
			if ($HsurvFlg) { $tIsland['money'] += 2000; }
			if($tIsland['score2'] > 3000){
				// 누계 30만명을 넘는 감소
				logEvent($tIsland['id'], $tIsland['name'],"가 재해왕을 획득, 많은 희생자의 죽음을 애도해 재해의 비가 주어졌습니다.");
				$tIsland['present'][11]++;
			}
		}
		// 선박왕
		usort($idx, function($a, $b) { global $Hislands, $rekidai, $HtotalPoint, $HtotalMoney, $HtotalBumon, $HStotalPoint, $DATA, $LandCount, $LandCount2, $allyPop; $c = hako_cmp($Hislands[$b]['ship'], $Hislands[$a]['ship']); return ($c != 0) ? $c : hako_cmp($a, $b); });
		$tIsland =& $Hislands[$idx[0]];
		if($tIsland['ship'] > 0){
			$tIsland['status'] |= 1024;
			$tIsland['zyuni'] += $HturnPrizePoint;
			logPrizeV($tIsland['id'], $tIsland['name'], $HprizeV[11]);
			if ($HsurvFlg) { $tIsland['money'] += 2000; }
		}
		// 기념비왕
		usort($idx, function($a, $b) { global $Hislands, $rekidai, $HtotalPoint, $HtotalMoney, $HtotalBumon, $HStotalPoint, $DATA, $LandCount, $LandCount2, $allyPop; $c = hako_cmp($Hislands[$b]['monument'], $Hislands[$a]['monument']); return ($c != 0) ? $c : hako_cmp($a, $b); });
		$tIsland =& $Hislands[$idx[0]];
		if($tIsland['monument'] > 0){
			$tIsland['status'] |= 2048;
			$tIsland['zyuni'] += $HturnPrizePoint;
			logPrizeV($tIsland['id'], $tIsland['name'], $HprizeV[12]);
			if ($HsurvFlg) { $tIsland['money'] += 2000; }
		}
		// 원예왕
		usort($idx, function($a, $b) { global $Hislands, $rekidai, $HtotalPoint, $HtotalMoney, $HtotalBumon, $HStotalPoint, $DATA, $LandCount, $LandCount2, $allyPop; $c = hako_cmp($Hislands[$b]['flower'], $Hislands[$a]['flower']); return ($c != 0) ? $c : hako_cmp($a, $b); });
		$tIsland =& $Hislands[$idx[0]];
		if($tIsland['flower'] > 0){
			$tIsland['status'] |= 8192;
			$tIsland['zyuni'] += $HturnPrizePoint;
			logPrizeV($tIsland['id'], $tIsland['name'], $HprizeV[14]);
			if ($HsurvFlg) { $tIsland['money'] += 2000; }
		}
	}

	// 턴배 대상 턴이라면, 괴수배 처리
	if((($HislandTurn % $HturnPrizeUnit) == 0) && ($MonsBattleTurnID != 0)){
		$island =& $Hislands[$HidToNumber[$MonsBattleTurnID]];
		$island['present'][10]++; # 괴수 기념비를 1개 늘린다
		logPrize($island['id'], $island['name'],"괴수배");
		logEvent($island['id'], $island['name'],"가 괴수배를 획득, 괴수 기념비를 선물 했습니다.");
	}

	// 전투 기간에의 이행등
	$tournamentflg = 0;
	if($Htournament){
		// 간이 토너먼트
		$HislandTurnCount++;
		if($HislandFightMode == 1){
			// 예선
			if($HislandTurn == $HislandChangeTurn){
				// 개발 턴에 이행
				$tournamentflg = 1;
				$HislandFightMode = 2;
				$HislandTurnCount = 0;
				$HislandChangeTurn = $HislandTurn + $HdevelopeTurn;
			}
		}elseif($HislandFightMode == 2){
			// 개발
			if($HislandTurn == $HislandChangeTurn){
				// 전투 턴에 이행
				$tournamentflg = 2;# 대전 상대 결정 처리는 인구 소트 다음에
				$HislandFightMode = 3;
				$HislandFightCount++;
				$HislandTurnCount = 0;
				if($remainNumber > 2){
					// 결승전 이외는, 시간을 비운다
					$HislandLastTime += $HinterTime;
					$HislandChangeTurn = $HislandTurn + $HfightTurn;
				}else{
					// 결승전
					$HislandChangeTurn = $HislandTurn + $HfinalTurn;
				}
			}
		}elseif($HislandFightMode == 3){
			// 전투
			if($HislandTurn == $HislandChangeTurn){
				// 승패 결착 개발 턴에 이행
				$tournamentflg = 3;
				if($remainNumber <= 2){
					// 종료
					$HislandFightMode = 9;
				}else{
					$HislandTurnCount = 0;
					$HislandFightMode = 2;
				}
				$HislandChangeTurn = $HislandTurn + $HdevelopeTurn;
				$HwinIsland = 0; # 승리한 도의 수
				$consolationPop = 0; # 패자 부활 대상 도 사람구
				$consolationID = 0; # 패자 부활 대상도ID
				for($i = 0; $i < $HislandNumber; $i++){
					$island =& $Hislands[$i];
					$HcurrentNumber = $HidToNumber[$island['fight_id']];
					$tIsland =& $Hislands[$HcurrentNumber];
					// 전투후의 승패
					$reward = $island['waste'];
					if(($HcurrentNumber != '' and $island['pop'] >= $tIsland['pop']) or ($island['fight_id'] == -1)) {
						// 승리
						$tPop = 0;
						$HwinIsland++;
						if($island['fight_id'] > 0){
							logWin($island['id'], $island['name'], "승리", $reward);
							$tPop = $tIsland['pop'];
							$tIsland['fight_id'] = 0;
							if($consolationPop <= $tPop){
								$consolationPop = $tPop;
								$consolationID = $tIsland['id'];
							}
							$tIsland['lose'] = 1;
							logOut("${HtagName_}{$tIsland[name]}${AfterName}${H_tagName},<B>패퇴</B>.",$tIsland['id']);
						}else{
							// 부전승
							logWin($island['id'], $island['name'], "부전승");
						}
						array_push($fight_log_flag, "{$island[name]},{$tIsland[name]},$reward,0,{$island[pop]},0,$tPop,0,{$island[fight_id]}");
						$island['fight_id'] = 0;
					}elseif(($HcurrentNumber == '') && ($island['fight_id'] > 0)){
						$HwinIsland++;
						logWin($island['id'], $island['name'], "승리", $reward);
						array_push($fight_log_flag, "{$island[name]},,$reward,0,{$island[pop]},0,0,0,-2");
						$island['fight_id'] = 0;
					}
					$island['reward'] = 0;
				}
				// 패퇴한 도의 제거
				$consolationName = "";
				if($HislandFightMode != 9){
					// 종료시 이외
					for($i = 0; $i < $HislandNumber; $i++){
						$island =& $Hislands[$i];
						if($island['lose']){
							if(($consolationID == $island['id']) && (($HwinIsland % 2) != 0) && ($HconsolationMatch)){
								// 패자 부활 대상도에서 다음번 홀수의 경우로 패자 부활 모드
								$consolationName = "${HtagName_}{$island[name]}${AfterName}${H_tagName},<B>패자 부활!</B>";
								logOut($consolationName,$island['id']);
							}else{
								logHistory("${HtagName_}{$island[name]}${AfterName}${H_tagName},<B>패배로 침몰</B>.");
								$island['pop'] = 0;
								$remainNumber--;
								OceanMente($island['id']);
							}
						}
					}
				}
			}
		}
	}

//------------------------------------------------

	// 인구순서에 소트
	// 인구가 같은 때는 직전의 턴의 차례인 채
	$idx = range(0, count($Hislands) - 1);
	usort($idx, function($a, $b) { global $Hislands, $rekidai, $HtotalPoint, $HtotalMoney, $HtotalBumon, $HStotalPoint, $DATA, $LandCount, $LandCount2, $allyPop; $c = hako_cmp($Hislands[$b]['pop'], $Hislands[$a]['pop']); return ($c != 0) ? $c : hako_cmp($a, $b); });
	$Hislands = hako_reorder($Hislands, $idx);

	islandReki();

	// 턴배 대상 턴이라면, 그 처리
	if(($HislandTurn % $HturnPrizeUnit) == 0){
		$island =& $Hislands[0];
		logPrize($island['id'], $island['name'], "$HislandTurn${Hprize[0]}");
		$island['prize'] .= "${HislandTurn},";
	}
	if($Htournament){
		// 간이 토너먼트
		if($tournamentflg == 1){
			// 예선 빠짐을 침몰시킨다
			while($remainNumber > $HfightMem){
				$remainNumber--;
				array_unshift($yosen_log, "{$Hislands[$remainNumber]}['pop'],{$Hislands[$remainNumber]}['name']");
				logLoseOut($Hislands[$remainNumber]['id'], $Hislands[$remainNumber]['name']);
				OceanMente($Hislands[$remainNumber]['id']);
			}
		}elseif($tournamentflg == 2){
			// 대전 상대 결정 처리
			$l = null; $r = null;
			$r = $remainNumber - 1;
			for($l = 0; $l <= $r; $l++, $r--){
				if($Hislands[$r]['id'] == $Hislands[$l]['id']){
					// 부전승
					$Hislands[$r]['fight_id'] = -1;
				}else{
					$Hislands[$l]['fight_id'] = $Hislands[$r]['id'];
					$Hislands[$r]['fight_id'] = $Hislands[$l]['id'];
				}
			}
		}
	}else{
		// 정한 턴 간격으로 최하정도의 도을 강제 삭제
		if($HsurvFlg){
			if(($HislandTurn > $Hsstartturn) && ((($HislandTurn - $Hsstartturn) % $Hsurvivalturn) == 0)){
				if($remainNumber > 1){
					$remainNumber--;
					logDead2($Hislands[$remainNumber]['id'], $Hislands[$remainNumber]['name']);
					OceanMente($Hislands[$remainNumber]['id']);
				}
			}
		}
	}

	// 도수컷
	$HislandNumber = $remainNumber;

	// 진영 각 세력의 통계 이력
	if($Hallyflg){
		$ctpop = null; $allyCount = null; $allyPop = null; $allyArea = null; $allyGnp = null; $allyPow = null;
		$ctpop = 0;
		for($i = 0; $i < $HislandNumber; $i++){
			$island =& $Hislands[$i];
			if ($island['id'] > 90) { continue; }
			$ally = $island['ally'];
			$allyCount[$ally]++;
			$allyPop[$ally] += $island['pop'];
			$ctpop += $island['pop'];
			$allyArea[$ally] += $island['area'];
			$allyGnp[$ally] += $island['money'] + intval(($island['food'] / 10) + ($island['ore'] * 1.2) + ($island['oil'] * 2.6) + ($island['weapon'] * 7));
			$allyPow[$ally] += $island['MissileK'] * 200 + $island['weapon'];
			$prize = $island['prize'];
			preg_match('/([0-9]*),([0-9]*),(.*)/', $prize, $_m);
			if ($_m[1] & 512) { $allyPow[$ally] += 3000; }
		}
		if(($HislandTurn % $HturnPrizeVarious) == 0){
			$aturn = $HislandTurn - $HturnPrizeVarious;
			rename("${HlogdirName}/ally.log", "${HlogdirName}/ally.$aturn");
		}
		$__keys = array_keys($allyPop); usort($__keys, function($a, $b) { global $Hislands, $rekidai, $HtotalPoint, $HtotalMoney, $HtotalBumon, $HStotalPoint, $DATA, $LandCount, $LandCount2, $allyPop;  return hako_cmp($allyPop[$b], $allyPop[$a]); }); foreach ($__keys as $_) {
			if($allyPop[$_] > 0){

				$w = intval($allyPop[$_] * 10000 / $ctpop + 0.5) / 100;
				hako_open('AOUT',">>${HlogdirName}/ally.log");
				// 턴, 진영 ID, 도수, 총인구, 계승자흙, 총경제력, 전군사력, 점유율
				hako_write('AOUT', "$HislandTurn,$_,{$allyCount[$_]},{$allyPop[$_]},{$allyArea[$_]},{$allyGnp[$_]},{$allyPow[$_]},$w\n");
				hako_close('AOUT');
			}
		}
	}
	// 백업 턴이면, 쓰기 전에 rename
	if(($HislandTurn % $HbackupTurn) == 0){
		$tmp = $HbackupTimes - 1;
		rmtree("${HdirName}.bak$tmp");
		for($i = ($HbackupTimes - 1); $i > 0; $i--){
			$j = $i - 1;
			rename("${HdirName}.bak$j", "${HdirName}.bak$i");
		}
		rename("${HdirName}", "${HdirName}.bak0");
		mkdir("${HdirName}", $HdirMode);
		rename("${HdirName}.bak0/fight.log","${HdirName}/fight.log");
	}

	// 자원 거래의 턴 처리 뒤처리
	turnExchangeEnd();

	if($Htournament){
		// 간이 토너먼트
		if($tournamentflg == 3){
			fihgt_log();
		}elseif($tournamentflg == 1){
			log_yosen();
		}
	}

	// 파일에 써내
	if(!writeIslandsFile(-1, 0)){
		if(($HislandTurn % $HbackupTurn) == 0){
			rmdir("${HdirName}");
			rename("${HdirName}.bak0", "${HdirName}");
		}
		unlock();
		tempFailWrite();
		return;
	}

	// 로그 파일을 뒤로 비켜 놓는다
	for($i = ($HlogMax - 1); $i >= 0; $i--){
		$j = $i + 1;
		if (file_exists("${HlogdirName}/hakojima.log$j")) { unlink("${HlogdirName}/hakojima.log$j"); }
		if (file_exists("${HlogdirName}/hakojima.log$i")) { rename("${HlogdirName}/hakojima.log$i", "${HlogdirName}/hakojima.log$j"); }
	}

//#### 추가 감독 20020307
	if($Hperformance){
		list($cpu, $uti, $sti) = hako_cpu_times();

		// 로그 파일 서두(테스트 계측용 평상시는 코멘트로 해 두어 주세요)
//		hako_open('POUT',">>cpu-t.log");
//		hako_write('POUT', "CPU($cpu) : user($uti) system($sti)\n");
//		hako_close('POUT');

		array_push($HlogPool, "0,$HislandTurn,0,,<SMALL>부하 계측 : CPU($cpu) : user($uti) system($sti)</SMALL>");
	}
//####

	// 로그 서두
	logFlush();

	// 기록 로그 조정
	logHistoryTrim("hakojima.his", $HhistoryMax);
	logHistoryTrim("weather.his", $HWeatherMax);

	// 탑에
	topPageMain();
}

// 참가도에의 제재 내용을 읽어들인다
function readPunishData() {
global $HdirName, $HpunishInfo;
	if(hako_open('Fpunish', "<${HdirName}/punish.dat")){

		$island = null;
		while (($_ = hako_getline('Fpunish')) !== false) {
			$_ = preg_split('/,/', rtrim($_));
			$obj = null;
			$obj['turn'] = array_shift($_);
			$obj['id'] = array_shift($_);
			$obj['punish'] = array_shift($_);
			$obj['x'] = array_shift($_);
			$obj['y'] = array_shift($_);
			$HpunishInfo[$obj['id']] = $obj;
		}
		hako_close('Fpunish');
	}

	// 제재 데이터를 삭제한다
	if (file_exists("${HdirName}/punish.dat")) { unlink("${HdirName}/punish.dat"); }
}

//  수입, 소비 페이즈
function income($number, &$island) {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $H_tagName2, $Haidpop, $Hallyflg, $Hallygroup, $haribote, $Hatkturn, $HbackupTimes, $HbackupTurn, $HbgInfoCell, $HbgTitleCell, $HbigcityFood, $HbigCityMFlg, $HcomBank, $HcomBase, $HcomBioMissile, $HcomBreakwater, $Hcomcolony, $HcomcolonyTurn, $HcomCost, $HcomDbase, $HcomDeathtrap, $HcomDestroy, $HcomDestroy2, $HcomDokan, $HcomDoNothing, $HcomDummy, $HcomEmigration, $HcomFactory, $HcomFarm, $HcomFire, $HcomFlower, $HcomFood, $HcomGiveup, $HcomHaribote, $HcomHospital, $HcomL, $HcommandMax, $HcomManipulate, $HcomMissileDM, $HcomMissileGM, $HcomMissileLD, $HcomMissileMGM, $HcomMissileNCM, $HcomMissileNM, $HcomMissilePLD, $HcomMissilePP, $HcomMissileRM, $HcomMissileRNG, $HcomMissileSPP, $HcomMissileSRM, $HcomMissileST, $HcomMoney, $HcomMonsAid, $HcomMonsEgg, $HcomMonsEnsei, $HcomMonsEsa, $HcomMonsEsaAid, $HcomMonsExer, $HcomMonsSell, $HcomMonsTettai, $HcomMonument, $HcomMountain, $HcomMyhome, $HcomName, $HcomOilBuy, $HcomOilSell, $HcomOMissileMGM, $HcomOMissileNM, $HcomOMissilePP, $HcomOMissileSPP, $HcomOreBuy, $HcomOreSell, $HcomPioneer, $HcomPlant, $HcomPolice, $HcomPort, $HcomPrepare, $HcomPrepare2, $HcomPresent, $HcomPresentAid, $HcomPropaganda, $HcomReclaim, $HcomReclaim2, $HcomSbase, $HcomSBuild, $HcomScity, $HcomSDbase, $HcomSDestroy, $HcomSearch, $HcomSEisei, $HcomSell, $HcomSellTree, $HcomSendMonster, $HcomSendMonsterTurn, $HcomSFactory, $HcomSFarm, $HcomSFood, $HcomShip, $HcomShipbuild, $HcomShipM, $HcomShipSell, $HcomSMissile, $HcomSMissileGM, $HcomSMissileMGM, $HcomSMissilePP, $HcomSMonument, $HcomSOccupy, $HcomSpaceBase, $HcomSpaceFarm, $HcomSpecialSPP, $HcomSPioneer, $HcomSpy, $HcomSSendMonster, $HcomSSendMonsterTurn, $HcomSTManipulate, $HcomSUnit, $HcomTeisatu, $HcomTower, $HcomTrump, $HcomUg, $HcomWarp, $HcomWeponBuy, $HcomWeponSell, $HcomWindmill, $HconsolationMatch, $HcurrentNumber, $HdBaseAuto, $HdefenceHex, $HdefenceSpace, $HdevelopeTurn, $HdirMode, $HdirName, $HdisAEruption, $HdisAkasio, $HdisBHarvest, $HdisCrime, $HdisEarthquake, $HdisEruption, $HdisFallBorder, $HdisFalldown, $HdisFire, $HdisGHarvest, $Hdishangen, $HdisHugeMeteo, $HdisKLimit, $HdisMaizo, $HdisMeteo, $HdisMonsBorder1, $HdisMonsBorder2, $HdisMonsBorder3, $HdisMonsBorder4, $HdisMonsBorder5, $HdisMonster, $HdisMonsterU, $HdisPirate, $HdisPollution, $HdisSeaMonster, $HdisSHugeMeteo, $HdisSpaceMonster1, $HdisSpaceMonster2, $HdisTinka, $HdisTreasureS, $HdisTsunami, $HdisTyphoon, $HdisUN, $HdisVGHarvest, $HearthAttack, $HeatenFood, $helpDir, $HfightMem, $HfightTurn, $HfinalTurn, $HgiveupTurn, $HhistoryMax, $HidToName, $HidToNumber, $HidToNumberR, $HinterTime, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HlandAegisShip, $HlandAirport, $HlandAmusement, $HlandBalloonS, $HlandBank, $HlandBase, $HlandBigcity, $HlandBreakwater, $HlandCasino, $HlandCoupleRock, $HlandDeathtrap, $HlandDefence, $HlandDokan, $HlandDome, $HlandEarth, $HlandExpo, $HlandFactory, $HlandFarm, $HlandFire, $HlandFishLShip, $HlandFishMShip, $HlandFishSShip, $HlandFlower, $HlandForest, $HlandFuji, $HlandGhostShip, $HlandHaribote, $HlandHospital, $HlandHugecity, $HlandIceFloe, $HlandKInora, $HlandMegacity, $HlandMegaFact, $HlandMegaFarm, $HlandMegatower, $HlandMonsShip, $HlandMonster, $HlandMonument, $HlandMountain, $HlandMyhome, $HlandOcean, $HlandOil, $HlandOPlayer, $HlandOsen, $HlandPark, $HlandPirate, $HlandPlains, $HlandPolice, $HlandPort, $HlandProbeShip, $HlandSAEisei, $HlandSbase, $HlandSchool, $HlandSCity, $HlandSDefence, $HlandSea, $HlandSeisei, $HlandSFactory, $HlandSFarm, $HlandSlum, $HlandSMonument, $HlandSpaceBase, $HlandStadium, $HlandSunit, $HlandTcity, $HlandTitanic, $HlandTower, $HlandTown, $HlandTreasureS, $HlandTrump, $HlandWarp, $HlandWarpR, $HlandWaste, $HlandWindmill, $HlandWingDragon, $HlandZoo, $HlateLogPool, $HlogMax, $HlogOmit2, $HlogPool, $HmaxdisPollution, $HmaxExpPoint, $HmaxIsland, $HmonsBtlMaxHp, $HmonsBtlMaxPa, $HmonsterAGI, $HmonsterBHP, $HmonsterCLS, $HmonsterDEF, $HmonsterDestroy, $HmonsterDHP, $HmonsterExp, $HmonsterGRP, $HmonsterL1, $HmonsterL1Num, $HmonsterL2, $HmonsterL2Num, $HmonsterL3, $HmonsterL3Num, $HmonsterL4, $HmonsterL4Num, $HmonsterL5, $HmonsterL5Num, $HmonsterName, $HmonsterNumber, $HmonsterS, $HmonsterSEI, $HmonsterSKL, $HmonsterSP, $HmonsterSpecial, $HmonsterSTR, $HmonsterValue, $Hmonth, $HmonumentMissile, $HmonumentName, $HmonumentRocket, $Hocean, $HoceanSize, $HoilMoney, $HoilRatio, $hp, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $Hprize, $HprizeV, $HpunishInfo, $HrepeatTurn, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $HseaChk, $HsecretLogPool, $HsEisei, $HshipEX, $HshipFood, $HshipHP, $HshipKAI, $HshipMATK, $HshipMoney, $HshipName, $Hshiporder, $HshipSATK, $HshipSell, $HshipSP, $HsmonumentName, $HsmonumentNumber, $Hsolarwind, $Hspace, $HspaceEfficiency, $HspaceIncome, $Hsstartturn, $HStotalPoint, $HsurvFlg, $Hsurvivalturn, $HtagName2_, $HthisFile, $HtotalBumon, $HtotalMoney, $HtotalPoint, $Htournament, $HtreeValue, $HturnPrizeNumber, $HturnPrizePoint, $HturnPrizeUnit, $HturnPrizeVarious, $HugDokan, $HugFact, $HugFarm, $HugHasigo, $HugKiti, $HugMax, $HugOil, $HugRoad, $HugSpace, $HugTosi, $human, $HunitFood, $HunitMoney, $HunitOil, $HunitOre, $HunitPop, $HunitTime, $HunitWeapon, $HwarFlg, $HWeatherMax, $Hwflg, $HwinFood, $HwinIsland, $HwinMoney, $HwinWeapon, $imageDir, $lockMode, $toppage, $versionInfo;

	list($name, $id, $land, $landValue, $p, $r) = array($island['name'], $island['id'], $island['land'], $island['landValue'], 1, random(1000));
	if($island['id'] > 90){
		// Battle Field 때
	}else{
		list($pop, $farm, $factory, $oilfactory, $port, $tower, $mountain) = 
		array(
		 $island['pop'],
		($island['farm'] * 10) + $island['yousyoku'],
		 $island['factory'],
		intval($island['oilfactory'] / 3),
		 $island['port'],
		 $island['tower'],
		 $island['mountain']
		 );
		$pop -= $island['slum']; #슬럼가의 사람의 노동은 수입이 되지 않는다..

		list($wkind, $wname, $whp, $wkind2, $wkind3) = weatherinfo($island['weather']);
		if(($r < $HdisVGHarvest) && ($whp > 1) && ($whp < 8)){
			logEvent2($id, $name, '대풍작','입니다');
			$p = 4;
		}elseif(($r < $HdisGHarvest + $HdisVGHarvest) && ($whp > 1) && ($whp < 8)){
			logEvent2($id, $name, '풍작','입니다');
			$p = 2;
		}elseif($r < $HdisBHarvest + $HdisGHarvest + $HdisVGHarvest){
			logEvent2($id, $name, '흉작','입니다');
			$p = 0;
		}
		
		$island['turnsu']++; #도고유의 턴수

//w		if($HwarFlg){
//w			# 전쟁계
//w			$island['evil'] = 10;
//w		}elsif($island['MissileK'] == 0){ # 미사일 비 보유도

		if($island['MissileK'] == 0){ # 미사일 비 보유도
			$island['evil'] -= 2; # 0때는 턴수에 관계없이 보호국이 된다
			if ($island['evil'] < 0) { $island['evil'] = 0; }
		}elseif($island['evil'] < 10){
			$island['evil'] = 10;
		}
		if($island['evil'] > 10000){
			$island['evil'] -= 1000;
			$island['gold'] = 1; # 황금기
		}elseif($island['evil'] > 300){
			$island['evil'] = 300;
		}
		
		// 보호국에서 순위점이 40이상의 도은 지진의 확률이 0. 5%UP 한다
		if (($island['evil'] == 0) && ($island['zyuni'] >= 40)) { $island['prepare2']++; }
		
		// 수입
		if($number < 5){
			// 상위에 보너스
			if ($HislandTurn > 100) { $island['money'] += 100 - $number * 20; }
		}
		
		// 상위에 점수를 가산.
		if ($number < 10) { $island['zyuni'] += 10 - $number; }
		
		// 턴배 대상 턴이라면, 점수를 리셋트 한다.
		if (($HislandTurn % $HturnPrizeUnit) == 0) { $island['zyuni'] = 0; }
		
		// 인구 10만 미만때는 상업 빌딩은 의미가 없다
		if ($pop < 1000) { $tower = 0; }
		
		if($factory < $port){
			// 공장보다 항구가 많을 때
			$factory += $factory;
		}else{
			$factory += $port; # 항의 값을 공장의 값에 더한다
		}
		if($island['order'] & 32){
			// 채굴장은 자금을 생산한다
			$tower += $mountain;
			$mountain = 0;
		}
		if($island['order'] & 128){
			// 공장은 자금을 생산한다
			$tower += $factory;
			$factory = 0;
		}
		if($pop > $farm){
			$island['food'] += $farm * $p; # 농장 풀 가동
			$pop -= $farm;
			if($pop > $mountain * 10){
				// 광석
				$island['ore'] += $mountain;
				$pop -= $mountain * 10;
				if(($pop > $oilfactory * 30) && ($island['ore'] > $oilfactory)){
					// 합성석유
					$island['ore'] -= $oilfactory;
					$island['oil'] += $oilfactory;
					$pop -= $oilfactory * 30;
				}
				if($pop > $factory * 10){
					// 병기
					if ($island['ore'] < $factory) { $factory = $island['ore']; }
					if ($island['oil'] < $factory) { $factory = $island['oil']; }
					$island['ore'] -= $factory;
					$island['oil'] -= $factory;
					$island['weapon'] += $factory;
					// 자금
					$island['money'] += min(intval(($pop - $factory) / 10), $tower);
				}else{
					$island['money'] += intval($pop / 10);
				}
			}else{
				$island['ore'] += intval($pop / 10);
			}
		}else{
			$island['food'] += $pop * $p; # 전원 들일
		}
		// 식량 소비
		$island['food'] = intval(($island['food']) - ($island['pop'] * $HeatenFood));
	}
	// 괴수처 이동
	if($island['smons'] > 0){
		$x = null; $y = null;
		for($p = 0; $p < $HpointNumber; $p++){
			$x = $Hrpx[$p];
			$y = $Hrpy[$p];
			if($land[$x][$y] == $HlandMonster){
				list($mKind, $mName, $mHp) = monsterSpec($landValue[$x][$y]);
				$special = $HmonsterSpecial[$mKind];
				if(($special == 6) || ($special == 7)){
					monmove($island, $x, $y, 0);
					if ($special == 6) { break; }
				}
			}
		}
	}
	// 황무지~땅 고르는 일 공격(땅 고르는 일의 수치 지정 22)
	$comArray = null; $command = null; $cNo = null; $i = null; $sx = null; $sy = null;
	for($cNo = 0; $cNo < $HcommandMax; $cNo++) {
		$comArray =& $island['command'];
		$command = $comArray[$cNo];
		if ($command['kind'] == $HcomSpecialSPP) { continue; }
		if(($command['kind'] == $HcomPrepare2) && ($command['arg'] == 22)){
			slideFront($island['command'], $cNo); # 이후를 채운다
			for($i = 0; $i < $HpointNumber; $i++){
				$sx = $Hrpx[$i];
				$sy = $Hrpy[$i];
				if (($land[$sx][$sy] == $HlandWaste) && ($landValue[$sx][$sy] <= 1)) { slideBack($island['command'], $cNo, $HcomPrepare2, $id, $sx, $sy, 0); }
			}
		}
break;
	}
//	for($cNo = 0; $cNo < $HcommandMax; $cNo++){
//		$comArray = $island['command'];
//		$command = $comArray[$cNo];
//		HdebugOut($id . "=" . $command['kind']);
//	}
} # income


// 코만드페이즈
function doCommand(&$island) {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $H_tagName2, $Haidpop, $Hallyflg, $Hallygroup, $haribote, $Hatkturn, $HbackupTimes, $HbackupTurn, $HbgInfoCell, $HbgTitleCell, $HbigcityFood, $HbigCityMFlg, $HcomBank, $HcomBase, $HcomBioMissile, $HcomBreakwater, $Hcomcolony, $HcomcolonyTurn, $HcomCost, $HcomDbase, $HcomDeathtrap, $HcomDestroy, $HcomDestroy2, $HcomDokan, $HcomDoNothing, $HcomDummy, $HcomEmigration, $HcomFactory, $HcomFarm, $HcomFire, $HcomFlower, $HcomFood, $HcomGiveup, $HcomHaribote, $HcomHospital, $HcomL, $HcommandMax, $HcomManipulate, $HcomMissileDM, $HcomMissileGM, $HcomMissileLD, $HcomMissileMGM, $HcomMissileNCM, $HcomMissileNM, $HcomMissilePLD, $HcomMissilePP, $HcomMissileRM, $HcomMissileRNG, $HcomMissileSPP, $HcomMissileSRM, $HcomMissileST, $HcomMoney, $HcomMonsAid, $HcomMonsEgg, $HcomMonsEnsei, $HcomMonsEsa, $HcomMonsEsaAid, $HcomMonsExer, $HcomMonsSell, $HcomMonsTettai, $HcomMonument, $HcomMountain, $HcomMyhome, $HcomName, $HcomOilBuy, $HcomOilSell, $HcomOMissileMGM, $HcomOMissileNM, $HcomOMissilePP, $HcomOMissileSPP, $HcomOreBuy, $HcomOreSell, $HcomPioneer, $HcomPlant, $HcomPolice, $HcomPort, $HcomPrepare, $HcomPrepare2, $HcomPresent, $HcomPresentAid, $HcomPropaganda, $HcomReclaim, $HcomReclaim2, $HcomSbase, $HcomSBuild, $HcomScity, $HcomSDbase, $HcomSDestroy, $HcomSearch, $HcomSEisei, $HcomSell, $HcomSellTree, $HcomSendMonster, $HcomSendMonsterTurn, $HcomSFactory, $HcomSFarm, $HcomSFood, $HcomShip, $HcomShipbuild, $HcomShipM, $HcomShipSell, $HcomSMissile, $HcomSMissileGM, $HcomSMissileMGM, $HcomSMissilePP, $HcomSMonument, $HcomSOccupy, $HcomSpaceBase, $HcomSpaceFarm, $HcomSpecialSPP, $HcomSPioneer, $HcomSpy, $HcomSSendMonster, $HcomSSendMonsterTurn, $HcomSTManipulate, $HcomSUnit, $HcomTeisatu, $HcomTower, $HcomTrump, $HcomUg, $HcomWarp, $HcomWeponBuy, $HcomWeponSell, $HcomWindmill, $HconsolationMatch, $HcurrentNumber, $HdBaseAuto, $HdefenceHex, $HdefenceSpace, $HdevelopeTurn, $HdirMode, $HdirName, $HdisAEruption, $HdisAkasio, $HdisBHarvest, $HdisCrime, $HdisEarthquake, $HdisEruption, $HdisFallBorder, $HdisFalldown, $HdisFire, $HdisGHarvest, $Hdishangen, $HdisHugeMeteo, $HdisKLimit, $HdisMaizo, $HdisMeteo, $HdisMonsBorder1, $HdisMonsBorder2, $HdisMonsBorder3, $HdisMonsBorder4, $HdisMonsBorder5, $HdisMonster, $HdisMonsterU, $HdisPirate, $HdisPollution, $HdisSeaMonster, $HdisSHugeMeteo, $HdisSpaceMonster1, $HdisSpaceMonster2, $HdisTinka, $HdisTreasureS, $HdisTsunami, $HdisTyphoon, $HdisUN, $HdisVGHarvest, $HearthAttack, $HeatenFood, $helpDir, $HfightMem, $HfightTurn, $HfinalTurn, $HgiveupTurn, $HhistoryMax, $HidToName, $HidToNumber, $HidToNumberR, $HinterTime, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HlandAegisShip, $HlandAirport, $HlandAmusement, $HlandBalloonS, $HlandBank, $HlandBase, $HlandBigcity, $HlandBreakwater, $HlandCasino, $HlandCoupleRock, $HlandDeathtrap, $HlandDefence, $HlandDokan, $HlandDome, $HlandEarth, $HlandExpo, $HlandFactory, $HlandFarm, $HlandFire, $HlandFishLShip, $HlandFishMShip, $HlandFishSShip, $HlandFlower, $HlandForest, $HlandFuji, $HlandGhostShip, $HlandHaribote, $HlandHospital, $HlandHugecity, $HlandIceFloe, $HlandKInora, $HlandMegacity, $HlandMegaFact, $HlandMegaFarm, $HlandMegatower, $HlandMonsShip, $HlandMonster, $HlandMonument, $HlandMountain, $HlandMyhome, $HlandOcean, $HlandOil, $HlandOPlayer, $HlandOsen, $HlandPark, $HlandPirate, $HlandPlains, $HlandPolice, $HlandPort, $HlandProbeShip, $HlandSAEisei, $HlandSbase, $HlandSchool, $HlandSCity, $HlandSDefence, $HlandSea, $HlandSeisei, $HlandSFactory, $HlandSFarm, $HlandSlum, $HlandSMonument, $HlandSpaceBase, $HlandStadium, $HlandSunit, $HlandTcity, $HlandTitanic, $HlandTower, $HlandTown, $HlandTreasureS, $HlandTrump, $HlandWarp, $HlandWarpR, $HlandWaste, $HlandWindmill, $HlandWingDragon, $HlandZoo, $HlateLogPool, $HlogMax, $HlogOmit2, $HlogPool, $HmaxdisPollution, $HmaxExpPoint, $HmaxIsland, $HmonsBtlMaxHp, $HmonsBtlMaxPa, $HmonsterAGI, $HmonsterBHP, $HmonsterCLS, $HmonsterDEF, $HmonsterDestroy, $HmonsterDHP, $HmonsterExp, $HmonsterGRP, $HmonsterL1, $HmonsterL1Num, $HmonsterL2, $HmonsterL2Num, $HmonsterL3, $HmonsterL3Num, $HmonsterL4, $HmonsterL4Num, $HmonsterL5, $HmonsterL5Num, $HmonsterName, $HmonsterNumber, $HmonsterS, $HmonsterSEI, $HmonsterSKL, $HmonsterSP, $HmonsterSpecial, $HmonsterSTR, $HmonsterValue, $Hmonth, $HmonumentMissile, $HmonumentName, $HmonumentRocket, $Hocean, $HoceanSize, $HoilMoney, $HoilRatio, $hp, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $Hprize, $HprizeV, $HpunishInfo, $HrepeatTurn, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $HseaChk, $HsecretLogPool, $HsEisei, $HshipEX, $HshipFood, $HshipHP, $HshipKAI, $HshipMATK, $HshipMoney, $HshipName, $Hshiporder, $HshipSATK, $HshipSell, $HshipSP, $HsmonumentName, $HsmonumentNumber, $Hsolarwind, $Hspace, $HspaceEfficiency, $HspaceIncome, $Hsstartturn, $HStotalPoint, $HsurvFlg, $Hsurvivalturn, $HtagName2_, $HthisFile, $HtotalBumon, $HtotalMoney, $HtotalPoint, $Htournament, $HtreeValue, $HturnPrizeNumber, $HturnPrizePoint, $HturnPrizeUnit, $HturnPrizeVarious, $HugDokan, $HugFact, $HugFarm, $HugHasigo, $HugKiti, $HugMax, $HugOil, $HugRoad, $HugSpace, $HugTosi, $human, $HunitFood, $HunitMoney, $HunitOil, $HunitOre, $HunitPop, $HunitTime, $HunitWeapon, $HwarFlg, $HWeatherMax, $Hwflg, $HwinFood, $HwinIsland, $HwinMoney, $HwinWeapon, $imageDir, $lockMode, $toppage, $versionInfo;

	// 커멘드 꺼내(기후등으로 중지된 명령은 공회전)
	$comArray = null; $command = null; $cNo = null;
	for($cNo = 0; $cNo < $HcommandMax; $cNo++) {
		$comArray =& $island['command'];
		$command = $comArray[$cNo];
		if ($command['flg'] <= 0) { break; }
	}

	if($Htournament){
		// 간이 토너먼트?
		$tName = $HidToName[$island['fight_id']];
		if($tName == ''){
			// 없음
			$command['target'] = $island['id'];
		}elseif($command['target'] != $island['id']){
			$command['target'] = $island['fight_id'];
		}
	}

	// 각 요소의 꺼내
	$name = $island['name']; $id = $island['id']; $land =& $island['land']; $landValue =& $island['landValue'];
	list($kind, $target, $x, $y, $arg, $x2, $y2) = array(
	 $command['kind'],
	 $command['target'],
	 $command['x'],
	 $command['y'],
	 $command['arg'],
	 $command['tx'],
	 $command['ty']
	 );

	if($Htournament == 2){
		// 간이 토너먼트 괴수 첨부
		if($HislandFightMode == 3){
			// 원정?
			$tn = $HidToNumber[$island['fight_id']];
			if($tn != ''){
				// $id,$name,$tId,$sId,$mId,$hp,$mhp,$str,$def,$agi,$skl,$winh,$win,$lose
				$tIsland =& $Hislands[$tn];
				if( $tIsland['monster'][0] == $island['fight_id'] ||
					$tIsland['monster'][2] == 0){
					// 상대가 있을 때는, 마음대로 원정 한다.
					logMonsENSEI($id, $name, $island['fight_id'], $tIsland['name'], "원정한다");
					$island['monster'][0] = $island['fight_id'];
					$island['monster'][2] = $island['fight_id'];
					$tIsland['monster'][2] = $id;
				}
			}
		}else{
			// 후퇴?
		}
		if( $kind == $HcomMonsEgg ||
			$kind == $HcomMonsEnsei ||
			$kind == $HcomMonsTettai ||
			$kind == $HcomMonsEsaAid ||
			$kind == $HcomMonsAid ||
			$kind == $HcomMonsSell){
			// 상기의 명령은 할 수 없다
			return 0;
		}
	}
	
	// 이미 미사일을 쏘았을 때
	if(((($kind >= 18) && ($kind <= 24)) ||
		(($kind >= 26) && ($kind <= 27)) ||
		(($kind >= 45) && ($kind <= 109)) ||
		($kind >= 140)) && ($island['Afmissile'] >= 1)){
		return 1;
	}

	// 이민은 1 턴에 1회까지.
	if (($kind == $HcomEmigration) && ($island['AfEmigra'] == 1)) { return 1; }

	if(($kind != $HcomSpecialSPP) && # 바다짐승 소탕정에 의한 SPP는 아니고
		($island['order'] & 16) && # 강제 괴수 유도탄 설정
		($island['monsmgmflg'] == 1)){ # 괴수가 있다(있었어? )
		//  강제 괴수 유도탄
		$island['monsmgmflg'] = 0;
		list($kind, $target, $x, $y, $arg, $x2, $y2) = array($HcomMissileMGM,$island['id'],0,0,1,0,0);
	}else{
		if (($command['kind'] == $HcomPrepare2) && ($command['arg'] == 22)) { return 1; }
		slideFront($comArray, $cNo); # 이후를 채운다
	}

	// 특수 명령
	$kind2;
	if($kind == $HcomSpecialSPP){
		// 바다짐승 소탕정에 의한 SPP
		if(($island['turnsu'] + $island['evil'] < $HdisUN) || ($island['evil'] == 0) || ($island['monsship'] < 1)){
			// 유엔 보호, 바다짐승 소탕정이 존재하지 않는 경우는 컷
			return 0;
		}
		$kind = $HcomMissileSPP;
		$kind2 = $HcomSpecialSPP;
	}

	if(($kind == $HcomOMissilePP) ||
		($kind == $HcomOMissileSPP) ||
		($kind == $HcomOMissileNM)){
		// 해역계
		if ($x >= $HoceanSize) { $x = $HoceanSize - 1; }
		if ($y >= $HoceanSize) { $y = $HoceanSize - 1; }
		if ($x2 >= $HoceanSize) { $x2 = $HoceanSize - 1; }
		if ($y2 >= $HoceanSize) { $y2 = $HoceanSize - 1; }
	}else{
		if ($x >= $HislandSize) { $x = $HislandSize - 1; }
		if ($y >= $HislandSize) { $y = $HislandSize - 1; }
		if ($x2 >= $HislandSize) { $x2 = $HislandSize - 1; }
		if ($y2 >= $HislandSize) { $y2 = $HislandSize - 1; }
	}

	// 도출치
	list($landKind, $lv, $cost, $comName, $point) = array($land[$x][$y], $landValue[$x][$y],$HcomCost[$kind], $HcomName[$kind],"($x, $y)");
	$landName = landName($landKind, $lv);

	if (($id != $target) &&
		((($kind >= 50) && ($kind <= 90)) || ($kind >= 140) || ($kind == $HcomWarp)) &&
		($HislandTurn - $island['kaisi'] <= $Hatkturn)){
		logMiss($id, $name, $comName, "${Hatkturn}턴의 사이, 공격계 커멘드는 자신의섬 외에 금지되고 있다");
		return 0;
	}

	if ( ($kind <= 19) ||
		(($kind >= 21) && ($kind <= 23)) ||
		(($kind >= 25) && ($kind <= 46)) ||
		($kind == 75) || ($kind == 100) || ($kind == 113) ||
		(($kind >= 92) && ($kind <= 97)) ||
		(($kind >= 104) && ($kind <= 111)) ||
		(($kind >= 116) && ($kind <= 142))){
		// 타겟이 관계없는 명령 때
	}else{
		if($HdefenceHex[$target] == 1){
			logOut("${HtagName_}$name$AfterName${H_tagName} 의 ${HtagComName_}$comName${H_tagComName} 는 , 목표가 슈퍼 쉴드(shield) 시스템이 발동중이기 때문에 실패했습니다.",$id,$target);
			return 1;
		}
		if($target > 90){
			// Battle Field 때
			if(($kind < 50) ||
			($kind == $HcomMissileNM) ||
			($kind == $HcomMissilePP) ||
			($kind == $HcomSendMonster) ||
			($kind == $HcomEmigration)){
				// 허가된 명령
			}else{
				logMiss($id, $name, $comName, "타겟이 Battle Field의");
				return 0;
			}
		}
	}

	if($kind == $HcomDoNothing){
		// 자금융통
		$island['turnsu']--;
	//	logDoNothing($id, $name, $comName);
		$island['money'] += 10;
		$island['absent']++;
		// 자동 방폐
		if($island['absent'] >= $HgiveupTurn){
			$comArray[0] = array(
			'kind' => $HcomGiveup,
			'target' => 0,
			'x' => 0,
			'y' => 0,
			'arg' => 0,
			'tx' => 0,
			'ty' => 0
			);
		}
		return 1;
	}

	$island['absent'] = 0;

	// 코스트 체크
	if($cost > 0){
		// 돈의 경우
		if($island['money'] < $cost){
			logMiss($id, $name, $comName, "자금부족");
			return 0;
		}
	}elseif($cost < 0){
		// 식량의 경우
		if($island['food'] < (-$cost)){
			logMiss($id, $name, $comName, "비축 식량 부족");
			return 0;
		}
	}

	// 커멘드로 분기
	if(($kind == $HcomPrepare) || ($kind == $HcomPrepare2)){
		// 정지, 땅 고르는 일
		if(($landKind == $HlandSea) || 
			(($landKind == $HlandOil) && ($lv == 0)) ||
			($landKind == $HlandOsen) ||
			($landKind == $HlandMountain) ||
			($landKind == $HlandMonster) ||
			($landKind == $HlandKInora) ||
			($landKind == $HlandBreakwater) ||
			($HseaChk[$landKind] == 2)){
			// 바다, 유전, 산, 괴수, 오염 토양, 배계는 정지 할 수 없다
			logLandFail($id, $name, $comName, $landName, $point, $landKind, $lv);
			return 0;
		}
		if(($landKind == $HlandOil) || ($landKind == $HlandSbase) || ($landKind == $HlandSMonument)){
			$land[$x][$y] = $HlandSea;
		}else{
			$land[$x][$y] = $HlandPlains;  # 목적의 장소를 평지로 한다
		}
		$landValue[$x][$y] = 0;

		if($HlogOmit2){
			$sno = $island['seichi'];
			$island['seichi']++;
			if($HlogOmit2 == 1){
				$seichipnt;
				list($seichipnt['x'], $seichipnt['y'], $seichipnt['z']) = array($x, $y, '개간');
				$island['seichipnt'][$sno] = $seichipnt;
			}
		}else{
			logLandSuc($id, $name, '개간', $point);
		}

		// 금을 공제한다
		$island['money'] -= $cost;

		if($kind == $HcomPrepare2){
			// 땅 고르는 일
			$island['prepare2']++;
			return 0;
		}else{
			// 정지라면, 매장금의 가능성 있어
			if(random(1000) < $HdisMaizo){
				$v = 100 + random(901);
				$island['money'] += $v;
				logMaizo($id, $name, $comName, $v);
			}
			return 1;
		}
	}elseif(($kind == $HcomReclaim) || ($kind == $HcomReclaim2)){
		// 매립해 고속 매립

		// 주위에 육지가 있을까 체크
		$seaCount = seaAround($land, $x, $y, 7);

		if(($landKind == $HlandPlains) && ($seaCount == 0) && ($kind == $HcomReclaim) &&
				(countAround($land, $x, $y, $HlandMountain, 7) > 1) &&
				(chkAround($land, $x, $y, $HlandFuji, 7) == 0)){
			// 평지에서 주위 1에 쿠스에 산이 2개 이상으로, 주위에 바다계, 후지산이 없는 지형에 매립(고속은 안돼)로, 후지산이 생긴다!
			$land[$x][$y] = $HlandFuji;
			$landValue[$x][$y] = 0;
			fujiAround($land, $landValue, $x, $y, 0);
			$island['money'] -= $cost;
			logOut("${HtagName_}${name}${AfterName}$point${H_tagName}ㅗ${HtagComName_}후지산 조성 ${H_tagComName}을 했습니다. 갑자기 주위의 지반이 융기 해 후지산이 되었습니다.",$id);
			return 1;
		}

		if($HseaChk[$landKind] == 0 || $HseaChk[$landKind] == 2){
			// 바다, 해저 기지, 유전, 방파제 밖에 매립 할 수 없다
			logLandFail($id, $name, $comName, $landName, $point, $landKind, $lv);
			return 0;
		}

		if($seaCount == 7){
			// 전부해이니까 매립 불능
			logNoLandAround($id, $name, $comName, "육지",$point);
			return 0;
		}

		if(($landKind == $HlandSea) && ($lv >= 1) ||
		   ($landKind == $HlandBreakwater) && ($lv >= 1) ){
			// 얕은 여울이나 방파제의 경우
			// 목적의 장소를 황무지로 한다
			$land[$x][$y] = $HlandWaste;
			$landValue[$x][$y] = 0;
			$island['area']++;

			if($seaCount <= 4){
				// 주위의 바다가 3 헥스 이내이므로, 얕은 여울로 한다
				$i = null; $sx = null; $sy = null;
				for($i = 1; $i < 7; $i++){
					$sx = $x + $ax[$i];
					$sy = $y + $ay[$i];
					if (!($sy % 2) && ($y % 2)) { $sx--; }
					if(($sx < 0) || ($sx >= $HislandSize) || ($sy < 0) || ($sy >= $HislandSize)){
					}else{
						// 범위내의 경우
						if ($land[$sx][$sy] == $HlandSea) { $landValue[$sx][$sy] = 1; }
					}
				}
			}
		}else{
			// 바다라면, 목적의 장소를 얕은 여울로 한다
			$land[$x][$y] = $HlandSea;
			$landValue[$x][$y] = 1;
		}
		if($HlogOmit2){
			$sno = $island['seichi'];
			$island['seichi']++;
			if($HlogOmit2 == 1){
				$seichipnt;
				list($seichipnt['x'], $seichipnt['y'], $seichipnt['z']) = array($x, $y, '매립');
				$island['seichipnt'][$sno] = $seichipnt;
			}
		}else{
			logLandSuc($id, $name, $comName, $point);
		}
		// 금을 공제한다
		$island['money'] -= $cost;
		if($kind == $HcomReclaim2){
			// 고속
			$island['prepare2'] += 4;
			// 턴 소비하지 않고
			return 0;
		}else{
			return 1;
		}
	}elseif(($kind == $HcomDestroy) || ($kind == $HcomDestroy2)){
		// 굴착
		if(($landKind == $HlandSbase) ||
			($landKind == $HlandOil) ||
			($landKind == $HlandMonster) ||
			($landKind == $HlandKInora) ||
			($HseaChk[$landKind] == 2)){
			// 해저 기지, 유전, 괴수, 배계는 굴착할 수 없다
			logLandFail($id, $name, $comName, $landName, $point, $landKind, $lv);
			return 0;
		}

		if($kind == $HcomDestroy){
			if((($landKind == $HlandSea) && ($lv == 0)) ||
					(($landKind == $HlandPlains) && ($arg != 0)) ||
					(($landKind == $HlandTown) && ($arg != 0)) ||
					(($landKind == $HlandWaste) && ($lv <= 1) && ($arg != 0))){
				// 바다라면, 유전 찾기 평지, 마을, 황무지에서 회수가 있을 때는 온천을 판다
				// 투자액 결정
				if ($arg == 0) { $arg = 1; }
				$value = null; $str = null; $p = null;
				$value = min($arg * ($cost), $island['money']);
				$str = "$value$HunitMoney";
				$p = intval($value / $cost);
				if ($p > 50) { $p = 50; }
				$island['money'] -= $p * $cost;
				if($landKind == $HlandSea){
					// 발견될까 판정
					if($p > random(100)){
						// 유전 발견된다
						logChosa($id, $name, $point, $comName, $str, ",<B>유전</B>을 파서 기대");
						$land[$x][$y] = $HlandOil;
						$landValue[$x][$y] = 0;
						$island['oilfield']++;
					}else{
						// 헛됨 공격해에 끝난다
						logChosa($id, $name, $point, $comName, $str, "했지만, 유전은 발견되지 않아");
					}
				}elseif($p + (countAround($land, $x, $y, $HlandMountain, 7) * 10) > random(100)){
					// 온천 발견된다
					logChosa($id, $name, $point, $comName, $str, ",<B>온천</B>을 파서 기대");
					$land[$x][$y] = $HlandWaste;
					$landValue[$x][$y] = 20 + random($p + 41);
				}else{
					// 헛됨 공격해에 끝난다
					logChosa($id, $name, $point, $comName, $str, "했지만, 온천은 발견되지 않고 황무지가 되었다.");
					$land[$x][$y] = $HlandWaste;
					$landValue[$x][$y] = 1;
				}
				return 1;
			}
		}

		// 목적의 장소를 바다로 한다. 산이라면 황무지에. 얕은 여울이라면 바다에.
		if($landKind == $HlandMountain){
			$land[$x][$y] = $HlandWaste;
			$landValue[$x][$y] = 0;
		}elseif(($landKind == $HlandSea) || ($landKind == $HlandBreakwater) || ($landKind == $HlandSMonument)){
			$land[$x][$y] = $HlandSea;
			$landValue[$x][$y] = 0;
		}else{
			$land[$x][$y] = $HlandSea;
			$landValue[$x][$y] = 1;
			$island['area']--;
		}
		if($HlogOmit2){
			$sno = $island['seichi'];
			$island['seichi']++;
			if($HlogOmit2 == 1){
				$seichipnt;
				list($seichipnt['x'], $seichipnt['y'], $seichipnt['z']) = array($x, $y, '굴착');
				$island['seichipnt'][$sno] = $seichipnt;
			}
		}else{
			logLandSuc($id, $name, $comName, $point);
		}
		// 금을 공제한다
		$island['money'] -= $cost;
		if($kind == $HcomDestroy2){
			// 고속
			$island['prepare2'] += 4;
			return 0;
		}else{
			return 1;
		}
	}elseif($kind == $HcomSellTree){
		// 벌채
		if($landKind == $HlandForest){
			// 숲때는 평지로 한다
			$land[$x][$y] = $HlandPlains;
			$landValue[$x][$y] = 0;
		}elseif(($landKind == $HlandSea) && ($lv >= 10)){
			// 양식장때는 얕은 여울로 한다
			$land[$x][$y] = $HlandSea;
			$landValue[$x][$y] = 1;
			$comName = '물고기 매각';
		}else{
			// 벌채할 수 없을 때
			logLandFail($id, $name, $comName, $landName, $point, $landKind, $lv);
			return 0;
		}
		logLandSuc($id, $name, $comName, $point);
		// 매각금을 얻는다
		$island['money'] += $HtreeValue * $lv;
		return 0;
	}elseif(($kind == $HcomPlant) ||
		($kind == $HcomFarm) ||
		($kind == $HcomFactory) ||
		($kind == $HcomTower) ||
		($kind == $HcomFire) ||
		($kind == $HcomWindmill) ||
		($kind == $HcomMyhome) ||
		($kind == $HcomPort) ||
		($kind == $HcomPolice) ||
		($kind == $HcomHospital) ||
		($kind == $HcomFlower) ||
		($kind == $HcomTrump) ||
		($kind == $HcomBase) ||
		($kind == $HcomMonument) ||
		($kind == $HcomHaribote) ||
		($kind == $HcomBank) ||
		($kind == $HcomWarp) ||
		($kind == $HcomDeathtrap) ||
		($kind == $HcomDokan) ||
		($kind == $HcomDbase)){

	// 지상 건설계
	if(($landKind == $HlandForest) && ($kind != $HcomPlant)){
		// 숲은 사전 처리로 자동 벌채
		$island['money'] += $HtreeValue * $lv;
		logLandSuc($id, $name, "자동 벌채", $point);
		$land[$x][$y] = $HlandPlains;
		$landValue[$x][$y] = 0;
		list($landKind,$lv) = array($land[$x][$y],$landValue[$x][$y]);
	}
	if(!
		(($landKind == $HlandPlains) ||
		($landKind == $HlandTown) ||
		(($landKind == $HlandSea) && ($lv == 0) && ($kind == $HcomFire)) ||
		(($landKind == $HlandSea) && ($lv == 0) && ($kind == $HcomDbase)) ||
		(($landKind == $HlandSea) && ($lv == 1) && ($kind == $HcomPlant)) ||
		(($landKind == $HlandMonument) && ($kind == $HcomMonument)) ||
		(($landKind == $HlandBank) && ($kind == $HcomBank)) ||
		(($landKind == $HlandBase) && ($kind == $HcomBase)) ||
		(($landKind == $HlandBase) && ($kind == $HcomMonument)) ||
		(($landKind == $HlandMyhome) && ($kind == $HcomMyhome)) ||
		(($landKind == $HlandDeathtrap) && ($kind == $HcomDeathtrap)) ||
		(($landKind == $HlandSea) && ($lv == 0) && ($kind == $HcomDeathtrap)) ||
		(($landKind == $HlandFarm) && ($kind == $HcomFarm)) ||
		(($landKind == $HlandFactory) && ($kind == $HcomFactory)) ||
		(($landKind == $HlandTower) && ($kind == $HcomTower)) ||
		(($landKind == $HlandPort) && ($kind == $HcomPort)) ||
		(($landKind == $HlandDokan) && ($kind == $HcomDokan)) ||
		(($landKind == $HlandDefence) && ($kind == $HcomDbase)))){
		// 부적당한 지형
		logLandFail($id, $name, $comName, $landName, $point, $landKind, $lv);
		return 0;
	}

	// 종류로 분기
	if($kind == $HcomPlant){
		// 얕은 여울을 양식장으로 한다
		if(($landKind == $HlandSea) && ($lv == 1)){
			$landValue[$x][$y] = 10; # 어는 1000마리로부터
			logLandSuc($id, $name, '양식장 정비', $point);
		}else{
			// 목적의 장소를 숲으로 한다.
			$land[$x][$y] = $HlandForest;
			$landValue[$x][$y] = 1; # 나무는 최저 단위
			logPBSuc($id, $name, $comName, $point);
		}
	}elseif($kind == $HcomFarm){
		// 농장
		if($landKind == $HlandFarm){
			// 이미 농장일 경우
			$landValue[$x][$y] += 5; # 규모 + 5000명
			if ($landValue[$x][$y] > 50) { $landValue[$x][$y] = 50; }
		}else{
			// 목적의 장소를 농장에
			$land[$x][$y] = $HlandFarm;
			$landValue[$x][$y] = 10; # 규모 = 10000와
		}
		logLandSuc($id, $name, $comName, $point);
	}elseif($kind == $HcomFactory){
		// 공장
		if($landKind == $HlandFactory){
			// 이미 공장일 경우
			$landValue[$x][$y] += 10; # 규모 + 10000명
			if ($landValue[$x][$y] > 100) { $landValue[$x][$y] = 100; }
		}else{
			// 목적의 장소를 공장에
			$land[$x][$y] = $HlandFactory;
			$landValue[$x][$y] = 30;
		}
		logLandSuc($id, $name, $comName, $point);
	}elseif($kind == $HcomTower){
		// 상업 빌딩
		if($landKind == $HlandTower){
			$landValue[$x][$y] += 10;
			if ($landValue[$x][$y] > 200) { $landValue[$x][$y] = 200; }
		}else{
			$land[$x][$y] = $HlandTower;
			$landValue[$x][$y] = 30;
		}
		logLandSuc($id, $name, $comName, $point);
	}elseif($kind == $HcomPort){
		//  항
		if(seaAround($land, $x, $y, 7) == 0){
			// 주위에 바다계가 없는 경우 건설 불가
			logNoLandAround($id, $name, $comName, "바다", $point);
			return 0;
		}
		if($landKind == $HlandPort){
			$landValue[$x][$y] += 20;
			if ($landValue[$x][$y] > 200) { $landValue[$x][$y] = 200; }
		}else{
			$land[$x][$y] = $HlandPort;
			$landValue[$x][$y] = 40;
		}
		logLandSuc($id, $name, $comName, $point);
	}elseif($kind == $HcomBase){
		// 목적의 장소를 미사일 기지로 한다.
		if($landKind == $HlandBase){
			if($landValue[$x][$y] < 15){
				$landValue[$x][$y] += 5;
			}elseif($landValue[$x][$y] < 20){
				$landValue[$x][$y] = 20;
			}elseif($landValue[$x][$y] < $HmaxExpPoint){
				$landValue[$x][$y]++;
			}elseif($landValue[$x][$y] > $HmaxExpPoint){
				$landValue[$x][$y] = $HmaxExpPoint;
			}
		}else{
			$land[$x][$y] = $HlandBase;
			$landValue[$x][$y] = 0;
		}
		logPBSuc($id, $name, $comName, $point);
	}elseif($kind == $HcomHaribote){
		// 목적의 장소를 위장 방위 시설로 한다
		$island['Afmissile'] = 1;
		$land[$x][$y] = $HlandHaribote;
		$landValue[$x][$y] = 0;
		logHariSuc($id, $name, $comName, $HcomName[$HcomDbase], $point);
		return 0;
	}elseif($kind == $HcomDokan){
		// 입구(지하) 건설
		$ugL =& $island['ugL'];
		$ugV =& $island['ugV'];
		$ugX =& $island['ugX'];
		$ugY =& $island['ugY'];
		$i = null;
		$arg = $HugMax;
		for($i = 0; $i < $HugMax; $i++) {
			if(($ugX[$i] == $x) && ($ugY[$i] == $y)){
				// 이미 지하가 있다
				return 0;
			}elseif(($land[$ugX[$i]][$ugY[$i]] != $HlandDokan) && ($land2[$ugX[$i]][$ugY[$i]] != $HlandDokan)){
				$arg = $i;
			}
		}
		if($arg == $HugMax){
			return 0;
		}
		$land[$x][$y] = $HlandDokan;
		$landValue[$x][$y] = 0;
		$ugX[$arg] = $x;
		$ugY[$arg] = $y;
		$ugL[$arg][0] = $HugSpace;
		$ugL[$arg][1] = $HugDokan;
		$ugL[$arg][2] = $HugSpace;
		$ugL[$arg][3] = $HugRoad;
		$ugL[$arg][4] = $HugHasigo;
		$ugL[$arg][5] = $HugRoad;
		$ugL[$arg][6] = $HugRoad;
		$ugL[$arg][7] = $HugHasigo;
		$ugL[$arg][8] = $HugRoad;
		for($i = 0; $i < 9; $i++){
			$ugV[$arg][$i] = 0;
		}
		logPBSuc($id, $name, $comName, $point);
	}elseif($kind == $HcomBank){
		// 은행
		if ($arg == 0) { $arg = 1; }
		$value = min($arg * $cost, $island['money']);
		$p = intval($value / $cost);
		$cost = $p * $cost;
		if($landKind == $HlandBank){
			$landValue[$x][$y] += $p;
		}else{
			$land[$x][$y] = $HlandBank;
			$landValue[$x][$y] = $p;
		}
		if ($landValue[$x][$y] > 200) { $landValue[$x][$y] = 200; }
		logLandSuc($id, $name, $comName, '(?, ?)');
	}elseif($kind == $HcomWarp){
		if($arg == 0){
			// 목적의 장소를 전이 장치로 한다
			$tn = $HidToNumber[$target];
			if ($tn == '') { return 0; }
			$land[$x][$y] = $HlandWarp;
			$landValue[$x][$y] = $target;
		}else{
			$land[$x][$y] = $HlandWarpR;
			$landValue[$x][$y] = $arg;
			$comName = '전이 지정 장치 건설';
		}
		logLandSuc($id, $name, $comName, $point);
	}elseif($kind == $HcomDbase){
		// 방위 시설
		$island['defence'] = 1; # 플래그 ON
		if($landKind == $HlandDefence){
			// 벌써 방위 시설의 경우
			$landValue[$x][$y] = 1; # 자폭 장치 세트
			logBombSet($id, $name, $landName, $point);
		}elseif($landKind == $HlandSea){
			$land[$x][$y] = $HlandOil;
			$landValue[$x][$y] = 5;
			logLandSuc($id, $name, $comName, $point);
		}else{
			// 목적의 장소를 방위 시설에
			$land[$x][$y] = $HlandDefence;
			if($arg == 1){
				$landValue[$x][$y] = 10;
				logPBSuc($id, $name, $comName, $point);
			}elseif($arg == 2){
				$landValue[$x][$y] = 20;
				logPBSuc($id, $name, $comName, $point);
			}else{
				$landValue[$x][$y] = 0;
				logLandSuc($id, $name, $comName, $point);
			}
		}
	}elseif($kind == $HcomFire){
		// 소방서, 해저 소방서
		if($landKind == $HlandSea){
			$land[$x][$y] = $HlandOil;
			$landValue[$x][$y] = 7;
			logLandSuc($id, $name, "해저 소방서 건설", $point);
		}else{
			$land[$x][$y] = $HlandFire;
			$landValue[$x][$y] = 0;
			$cost = intval($cost / 2);
			logLandSuc($id, $name, $comName, $point);
		}
	}elseif($kind == $HcomMonument){
		// 기념비
		if(($landKind == $HlandMonument) && ($lv <= $HmonumentRocket) && ($lv != 3)){
			// 벌써 기념비의 경우 로켓대, 염가 기념비는 제외하다
			// 타겟 취득
			$tn = $HidToNumber[$target];
			if ($tn == '') { return 0; }
			$tIsland =& $Hislands[$tn];
			if(($tIsland['turnsu'] + $tIsland['evil'] < $HdisUN) || ($tIsland['evil'] == 0)){
				// 상대가 도상국이기 때문에 중지.
				logUNMiss($id, $target, $name, $tIsland['name'], $comName);
				return 0;
			}
			$island['evil'] += 60;

			// 그 자리소는 황무지에
			$land[$x][$y] = $HlandWaste;
			$landValue[$x][$y] = 0;
			logMonFly($id, $name, $landName, $point);
			if(($x2 == 0) && ($y2 == 0)){
				$x = random($HislandSize);
				$y = random($HislandSize);
			}else{
				$r = random(61);
				$x = $x2 + $ax[$r];
				$y = $y2 + $ay[$r];
				if (!($y % 2) && ($y2 % 2)) { $x--; }
			}
			$tId = $tIsland['id']; $tName = $tIsland['name']; $tLand =& $tIsland['land']; $tLandValue =& $tIsland['landValue'];
			logMonDamage($tId, $tName, "($x, $y)");
			wideDamage($tId, $tName, $tLand, $tLandValue, $x, $y, 0);
		}elseif(($landKind == $HlandMonument) && ($lv > $HmonumentRocket)){
			// 로켓 발사
			list($wkind, $wname, $whp, $wkind2, $wkind3) = weatherinfo($island['weather']);
			if($wkind > 1){
				logMiss($id, $name,"로켓 발사","기후 이상");
				if(($island['order'] & 512) && ($Hwflg > 0)){ # 자신 없어서 회수제감
					slideBack($comArray, $cNo, $kind, $target, $x, $y, $arg, $x2, $y2, $Hwflg); # 플래그 첨부로 명령 되돌린다
					$Hwflg--;
				}
				return 0;
			}
			if($lv - $HmonumentRocket > random(10)){
				logRocketS($id, $name);
				$landValue[$x][$y] = $HmonumentRocket;
				$prize = $island['prize'];
				preg_match('/([0-9]*),([0-9]*),(.*)/', $prize, $_m);
				list($flags,$monsters,$turns) = array($_m[1],$_m[2],$_m[3]);
				if(!($flags & 512)){
					$flags |= 512;
					$island['money'] += 64999;
					// 우주상 수상의 로그는 턴 처리의 마지막 편으로 출력 이유는 도중에 출력하면 턴 처리에 실패했을 때 다중에 나오기 때문에?
					$island['space'] = 1;
				}else{
					$island['money'] += 54999;
				}
				$island['prize'] = "$flags,$monsters,$turns";
			}else{
				if ($landValue[$x][$y] < $HmonumentRocket + 7) { $landValue[$x][$y]++; }
				logRocketF($id, $name);
			}
		}elseif($landKind == $HlandBase){
			// 미사일 기지때, 로켓대 건설
			$land[$x][$y] = $HlandMonument;
			$landValue[$x][$y] = $HmonumentRocket + 1;
			logLandSuc($id, $name,"로켓대 건설", $point);
		}else{
			// 목적의 장소를 기념비에
			$land[$x][$y] = $HlandMonument;
			if($arg == 3){
				// 염가 기념비
				$cost = 2500;
			}elseif($arg > 3){
				$arg = 0;
			}
			$landValue[$x][$y] = $arg;
			logLandSuc($id, $name, $comName, $point);
		}
	}elseif($kind == $HcomFlower){
		// 꽃을 심는다
		$land[$x][$y] = $HlandFlower;
		$landValue[$x][$y] = random(13) + 1;
		logLandSuc($id, $name, $comName, $point);
	}elseif($kind == $HcomTrump){
		// 트럼프 설치
		$land[$x][$y] = $HlandTrump;
		$landValue[$x][$y] = 0;
		logLandSuc($id, $name, $comName, $point);
	}elseif($kind == $HcomPolice){
		// 경찰서
		$land[$x][$y] = $HlandPolice;
		$landValue[$x][$y] = 0;
		logLandSuc($id, $name, $comName, $point);
	}elseif($kind == $HcomHospital){
		// 병원
		$land[$x][$y] = $HlandHospital;
		$landValue[$x][$y] = 0;
		logLandSuc($id, $name, $comName, $point);
	}elseif($kind == $HcomWindmill){
		// 풍차
		$land[$x][$y] = $HlandWindmill;
		$landValue[$x][$y] = 0;
		logLandSuc($id, $name, $comName, $point);
	}elseif($kind == $HcomDeathtrap){
		// 데스트랩 
		if($landKind == $HlandSea){
			$land[$x][$y] = $HlandOil;
			$landValue[$x][$y] = 6;
			$comName = "해저 데스트랩  건설";
		}elseif($landKind == $HlandDeathtrap){
			// 벌써 데스트랩 의 경우
			$landValue[$x][$y]++;
			if ($landValue[$x][$y] > 2) { $landValue[$x][$y] = 3; }
		}else{
			$land[$x][$y] = $HlandDeathtrap;
			$landValue[$x][$y] = 1;
		}
		logLandSuc($id, $name, $comName, $point);
	}elseif($kind == $HcomMyhome){
		// 마이 홈
		if($landKind == $HlandMyhome){
			$landValue[$x][$y] += 3;
			if ($landValue[$x][$y] > 12) { $landValue[$x][$y] = 12; }
		}elseif($island['myhome'] == 1){
			// 벌써 있는 아무것도 말하지 않고 중지
			return 0;
		}else{
			$land[$x][$y] = $HlandMyhome;



			$landValue[$x][$y] = 0;
		}
		logLandSuc($id, $name, $comName, $point);
	}

	// 금을 공제한다
	$island['money'] -= $cost;

	// 회수 첨부라면, 커멘드를 되돌린다
	if(($kind == $HcomFarm) ||
			($kind == $HcomTower) ||
			($kind == $HcomBase) ||
			($kind == $HcomPort) ||
			($kind == $HcomFactory)){
		if($arg > 1){
			$arg--;
			slideBack($comArray, $cNo, $kind, $target, $x, $y, $arg);
		}
	}

	return 1;
//w	if(($HwarFlg) && ($island['dcount'] < 3)){
//w		# 전쟁계는 연속 개발이 가능
//w		$island['dcount']++;
//w		return 0;
//w	}else{
//w		return 1;
//w	}

	}elseif($kind == $HcomMountain){
		// 채굴장
		if($landKind != $HlandMountain){
			// 산 이외에는 만들 수 없다
			logLandFail($id, $name, $comName, $landName, $point, $landKind, $lv);
			return 0;
		}
		$landValue[$x][$y] += 10; # 규모 + 10000명
		if($landValue[$x][$y] > 200){ # 최대 200000명
			$landValue[$x][$y] = 200;
			logMiss($id, $name, $comName, "이미 최대 규모의");
			return 0;
		}
		if(random(250) < $HdisMaizo){ # 금광맥발견의 확률 있어
			$v = 200 + random(1001);
			$island['money'] += $v;
			logGold($id, $name, $comName, $v);
		}
		logLandSuc($id, $name, $comName, $point);
		// 금을 공제한다
		$island['money'] -= $cost;
		if($arg > 1){
			$arg--;
			slideBack($comArray, $cNo, $kind, $target, $x, $y, $arg);
		}
		return 1;
	}elseif(($kind == $HcomSFarm) || ($kind == $HcomPropaganda)){
		// 해저 농장, 유치 활동
		if($kind == $HcomPropaganda){ # 유치 활동
			logPropaganda($id, $name, $comName);
			$island['propaganda'] = 1;
		}else{ # 해저 농장
			if(($landKind == $HlandOil) && ($lv >= 10) && ($lv <= 30)){
				// 벌써 해저 농장의 경우
				$landValue[$x][$y] += 5;
				if ($landValue[$x][$y] > 30) { $landValue[$x][$y] = 30; }
			}elseif(($landKind != $HlandSea) || ($lv != 0)){
				// 바다 이외에는 만들 수 없다
				logLandFail($id, $name, $comName, $landName, $point, $landKind, $lv);
				return 0;
			}else{
				// 목적의 장소를 해저 농장에
				$land[$x][$y] = $HlandOil;
				$landValue[$x][$y] = 10;
			}
			logLandSuc($id, $name, $comName, $point);
		}
		// 금을 공제한다?
		$island['money'] -= $cost;
		if($arg > 1){
			$arg--;
			slideBack($comArray, $cNo, $kind, $target, $x, $y, $arg);
		}
		return 1;
	}elseif(($kind == $HcomSbase) || ($kind == $HcomScity)){
		// 해저 기지, 해저 도시
		if(($landKind != $HlandSea) || ($lv != 0)){
			// 바다 이외에는 만들 수 없다
			logLandFail($id, $name, $comName, $landName, $point, $landKind, $lv);
			return 0;
		}
		if($kind == $HcomSbase){
			$land[$x][$y] = $HlandSbase;
			$landValue[$x][$y] = 0; # 경험치 0
			logLandSuc($id, $name, $comName, '(?, ?)');
		}else{
			list($wkind, $wname, $whp, $wkind2, $wkind3) = weatherinfo($island['weather']);
			if($wkind > 2){
				logMiss($id, $name,$comName,"기후 이상");
				if(($island['order'] & 512) && ($Hwflg > 0)){ # 자신 없어서 회수제감
					slideBack($comArray, $cNo, $kind, $target, $x, $y, $arg, $x2, $y2, $Hwflg); # 플래그 첨부로 명령 되돌린다
					$Hwflg--;
				}
				return 0;
			}
			$land[$x][$y] = $HlandOil;
			$landValue[$x][$y] = 35;
			logLandSuc($id, $name, $comName, $point);
		}
		// 금을 공제한다
		$island['money'] -= $cost;
		return 1;
	}elseif($kind == $HcomSMonument){
		// 해저 기념비
		if($landKind == $HlandSMonument){
			// 벌써 해저 기념비의 경우
			// 타겟 취득
			$tn = $HidToNumber[$target];
			if ($tn == '') { return 0; }
			$tIsland =& $Hislands[$tn];
			if(($tIsland['turnsu'] + $tIsland['evil'] < $HdisUN) || ($tIsland['evil'] == 0)){
				// 상대가 도상국이기 때문에 중지.
				logUNMiss($id, $target, $name, $tIsland['name'], $comName);
				return 0;
			}
			$island['evil'] += 70;
			// 그 자리소는 바다에
			$land[$x][$y] = $HlandSea;
			$landValue[$x][$y] = 0;
			logMonFly($id, $name, $landName, $point);
			if(($x2 == 0) && ($y2 == 0)){
				$x = random($HislandSize);
				$y = random($HislandSize);
			}else{
				$r = random(19);
				$x = $x2 + $ax[$r];
				$y = $y2 + $ay[$r];
				if (!($y % 2) && ($y2 % 2)) { $x--; }
			}
			$tId = $tIsland['id']; $tName = $tIsland['name']; $tLand =& $tIsland['land']; $tLandValue =& $tIsland['landValue'];
			logMonDamage($tId, $tName, "($x, $y)");
			wideDamage($tId, $tName, $tLand, $tLandValue, $x, $y, 0);
		}elseif(($landKind != $HlandSea) || ($lv != 0)){
			// 바다 이외에는 만들 수 없다
			logLandFail($id, $name, $comName, $landName, $point, $landKind, $lv);
			return 0;
		}else{
			// 목적의 장소를 기념비에
			$land[$x][$y] = $HlandSMonument;
			if ($arg >= $HsmonumentNumber) { $arg = 0; }
			$landValue[$x][$y] = $arg;
			logLandSuc($id, $name, $comName, $point);
		}
		$island['money'] -= $cost;
		return 1;
	}elseif($kind == $HcomBreakwater){
		// 방파제
		if(($landKind != $HlandSea) || ($lv != 1)){
			// 얕은 여울 이외에는 만들 수 없다
			logLandFail($id, $name, $comName, $landName, $point, $landKind, $lv);
			return 0;
		}
		$land[$x][$y] = $HlandBreakwater;
		$landValue[$x][$y] = 1;
		logLandSuc($id, $name, $comName, $point);
		$island['money'] -= $cost;
		return 1;
	}elseif($kind == $HcomShipbuild){
		// 조선
		// 주위 2 매스에 항구가 있을까 체크
		if (!chkAround($land, $x, $y, $HlandPort, 19)) { return 0; }
		
		// 얕은 여울인가, 추가 가능의 자선이나 체크
		if(($landKind == $HlandSea) && ($lv > 0)){
			// 짚젖
			$land[$x][$y] = $HlandFishSShip;
			$landValue[$x][$y] = 21000 + $id; # 초기 지령은 방어
			$island['land2'][$x][$y] = $HlandSea;
			$island['landValue2'][$x][$y] = 1;
			$comName = "어선 조선";
		}elseif(($landKind == $HlandFishSShip) || ($landKind == $HlandFishMShip)){
			// 소형, 중형 어선
			list($order, $hp, $sId) = shipSpec($lv);
			if ($sId != $id) { return 0; }
			if($landKind == $HlandFishMShip){
				if($arg == 1){
					// 호화 여객선
					$land[$x][$y] = $HlandTitanic;
					$comName = "호화 여객선 조선";
				}elseif($arg == 2){
					// 이지스 함
					$land[$x][$y] = $HlandAegisShip;
					$comName = "이지스 함 조선";
				}else{
					$land[$x][$y] = $HlandFishLShip;
					$comName = "어선 추가 조선";
				}
			}else{
				// 소형
				if($arg == 1){
					// 해저 탐사배
					$land[$x][$y] = $HlandProbeShip;
					$comName = "해저 탐사배 조선";
				}elseif($arg == 2){
					// 바다짐승 소탕정
					$land[$x][$y] = $HlandMonsShip;
					$comName = "바다짐승 소탕정 조선";
				}else{
					$land[$x][$y] = $HlandFishMShip;
					$comName = "어선 추가 조선";
				}
			}
		}else{
			return 0;
		}
		logLandSuc($id, $name, $comName, $point);
		$island['money'] -= $cost;
		return 1;
	}elseif(($kind == $HcomPresent) || ($kind == $HcomPresentAid)){
		// 선물, 선물 양도
		$tn = null; unset($tIsland); $tIsland = null; $tName = null;
		if($kind == $HcomPresent){
			if(!(($landKind == $HlandPlains) || ($landKind == $HlandTown))){
				// 부적당한 지형
				logLandFail($id, $name, $comName, $landName, $point, $landKind, $lv);
				return 0;
			}
		}else{
			$tn = $HidToNumber[$target];
			if ($tn == '') { return 0; }
			$tIsland =& $Hislands[$tn];
			$tName = $tIsland['name'];
		}
		if($kind == $HcomPresent){
			$landValue[$x][$y] = 0;
			if(($arg <= 0) && ($island['present'][0] > 0)){
				$island['present'][0]--;
				$land[$x][$y] = $HlandPark;
			}elseif(($arg == 1) && ($island['present'][1] > 0)){
				$island['present'][1]--;
				$land[$x][$y] = $HlandStadium;
			}elseif(($arg == 2) && ($island['present'][2] > 0)){
				$island['present'][2]--;
				$land[$x][$y] = $HlandDome;
			}elseif(($arg == 3) && ($island['present'][3] > 0)){
				$island['present'][3]--;
				$land[$x][$y] = $HlandCasino;
			}elseif(($arg == 4) && ($island['present'][4] > 0)){
				$island['present'][4]--;
				$land[$x][$y] = $HlandAmusement;
			}elseif(($arg == 5) && ($island['present'][5] > 0)){
				$island['present'][5]--;
				$land[$x][$y] = $HlandSchool;
			}elseif(($arg == 6) && ($island['present'][6] > 0)){
				$island['present'][6]--;
				$land[$x][$y] = $HlandAirport;
			}elseif(($arg == 7) && ($island['present'][7] > 0)){
				$island['present'][7]--;
				$land[$x][$y] = $HlandBigcity;
			}elseif(($arg == 8) && ($island['present'][8] > 0)){
				$island['present'][8]--;
				$land[$x][$y] = $HlandZoo;
			}elseif(($arg == 9) && ($island['present'][9] > 0)){
				$island['present'][9]--;
				$land[$x][$y] = $HlandExpo;
			}elseif(($arg == 10) && ($island['present'][10] > 0)){
				$island['present'][10]--;
				$land[$x][$y] = $HlandMonument;
				$landValue[$x][$y] = 10;
			}elseif(($arg >= 11) && ($island['present'][11] > 0)){
				$island['present'][11]--;
				$land[$x][$y] = $HlandMonument;
				$landValue[$x][$y] = 8;
			}else{
				// 있을 수 없지만 우선 황무지에 해 둔다
				$land[$x][$y] = $HlandWaste;
				logNoPresent($id, $name, $comName, $point);
				return 0;
			}
			logLandSuc($id, $name, $comName, $point);
		//	$island['money'] -= $cost;
		}else{
			if(($arg <= 0) && ($island['present'][0] > 0)){
				$island['present'][0]--;
				$tIsland['present'][0]++;
			}elseif(($arg == 1) && ($island['present'][1] > 0)){
				$island['present'][1]--;
				$tIsland['present'][1]++;
			}elseif(($arg == 2) && ($island['present'][2] > 0)){
				$island['present'][2]--;
				$tIsland['present'][2]++;
			}elseif(($arg == 3) && ($island['present'][3] > 0)){
				$island['present'][3]--;
				$tIsland['present'][3]++;
			}elseif(($arg == 4) && ($island['present'][4] > 0)){
				$island['present'][4]--;
				$tIsland['present'][4]++;
			}elseif(($arg == 5) && ($island['present'][5] > 0)){
				$island['present'][5]--;
				$tIsland['present'][5]++;
			}elseif(($arg == 6) && ($island['present'][6] > 0)){
				$island['present'][6]--;
				$tIsland['present'][6]++;
			}elseif(($arg == 7) && ($island['present'][7] > 0)){
				$island['present'][7]--;
				$tIsland['present'][7]++;
			}elseif(($arg == 8) && ($island['present'][8] > 0)){
				$island['present'][8]--;
				$tIsland['present'][8]++;
			}elseif(($arg == 9) && ($island['present'][9] > 0)){
				$island['present'][9]--;
				$tIsland['present'][9]++;
			}elseif(($arg == 10) && ($island['present'][10] > 0)){
				$island['present'][10]--;
				$tIsland['present'][10]++;
			}elseif(($arg >= 11) && ($island['present'][11] > 0)){
				$island['present'][11]--;
				$tIsland['present'][11]++;
			}else{
				logNoPresent($id, $name, $comName, $point);
				return 0;
			}
			logPresent($id, $target, $name, $tName);
			return 0;
		}
		return 1;
	}elseif(($kind == $HcomSpy) || ($kind == $HcomTeisatu)){
		// 공작원 파견, 정찰
		$tn = $HidToNumber[$target];
		if ($tn == '') { return 0; }
		$tIsland =& $Hislands[$tn];
		if(($tIsland['turnsu'] + $tIsland['evil'] < $HdisUN) || ($tIsland['evil'] == 0)){
			// 상대가 도상국이기 때문에 중지.
			logUNMiss($id, $target, $name, $tIsland['name'], $comName);
			return 0;
		}
		$island['evil'] += 30;
		$tName = $tIsland['name'];
		$tLand =& $tIsland['land'];
		$tLandValue =& $tIsland['landValue'];
		$tLand2 =& $tIsland['land2'];
		$tLandValue2 =& $tIsland['landValue2'];
		
		$tx = null; $ty = null; $i = null;
		if($kind == $HcomSpy){
			$island['money'] -= $cost;
			if(random(5) == 0){ # 실패
				logSpyF($id, $target, $name, $tName, $comName);
				return 1;
			}
			foreach (range(0, 36) as $_) {
				$tx = $x + $ax[$_];
				$ty = $y + $ay[$_];
				if (!($ty % 2) && ($y % 2)) { $tx--; }
				if (($tx < 0) || ($tx >= $HislandSize) || ($ty < 0) || ($ty >= $HislandSize)) { continue; }
				if($tLand[$tx][$ty] == $HlandPolice){
//					HdebugOut("목표 주위 3 헤크스에 경찰서는 실패");
					logSpyF($id, $target, $name, $tName, $comName);
					return 1;
				}elseif(($tLand[$tx][$ty] == $HlandAegisShip) && ($HseaChk[$tLand[$x][$y]])){
					list($order, $hp, $sId) = shipSpec($tLandValue[$tx][$ty]);
					if($sId == $target){
//						HdebugOut("목표가 바다계로 주위 3 헤크스에 이지스 함은 실패");
						logSpyF($id, $target, $name, $tName, $comName);
						return 1;
					}
				}
			}
//			HdebugOut("공작원 2차 체크 성공!");
			if($arg == 0){
				// 지진 발생시킨다
				if(($HseaChk[$tLand[$x][$y]]) && (random(2) == 0)){
					// 바다의 경우는 50%로 실패
					logSpyF($id, $target, $name, $tName, $comName);
					return 1;
				}
				$comName = "공작원 파견：지진";
				addCommandLate(3,$HislandTurn,$id,$kind,$target,$x,$y,$arg,$x2,$y2);# 턴 차이 명령
			}elseif($arg == 1){
				// 알루미늄 박 살포
				$comName = "공작원 파견：알루미늄 박 살포($x,$y)";
				addCommandLate(1,$HislandTurn,$id,$kind,$target,$x,$y,$arg,$x2,$y2);# 턴 차이 명령
			}else{
				// 식량 구워 토벌해
				$comName = "공작원 파견：식량 파괴";
				$tIsland['food'] -= intval($tIsland['food'] * 0.2);
				logLate("${HtagName_}${tName}${AfterName}${H_tagName} 의  식량의 일부가 누군가에 의해 태워졌습니다.",$target);
			}
			logSecret("${HtagName_}${name}${AfterName}${H_tagName} 가${HtagName_}${tName}${AfterName}${H_tagName}에${HtagComName_}$comName${H_tagComName}를 실시해 훌륭히 성공했습니다.",$id);
			return 1;
		}else{
		//	$arg = 1 if($arg < 1);
		//	$arg = 37 if($arg > 36); #  최대 37 매스
			$arg = 37;
		}
		// 선택한 수량만 조사한다
		for($i = 0; $i < $arg; $i++){
		//	if(random(25) == 0){ # 성함
		//		logSpyF($id, $target, $name, $tName, $comName);
		//		break;
		//	}
			$tx = $x + $ax[$i];
			$ty = $y + $ay[$i];
			if (!($ty % 2) && ($y % 2)) { $tx--; }
			if (($tx < 0) || ($tx >= $HislandSize) || ($ty < 0) || ($ty >= $HislandSize)) { continue; }

			// 지형등 산출
			$tL = $tLand[$tx][$ty];
			$tLv = $tLandValue[$tx][$ty];
			$tLname = landName($tL, $tLv);
			$tPoint = "($tx, $ty)";
			if(($tL == $HlandBase) || ($tL == $HlandSbase)){ # 미 기지, 해저미 기지때
				logBeseFind($id, $tName, $tPoint, $tLv, $tLname);
			}elseif(($tL == $HlandForest) || ($tL == $HlandDefence)){
				logLandTruth($id, $tName, $tPoint, $tLname, '진짜');
			}elseif(($tL == $HlandHaribote) && ($tLv == 0)){
				logLandTruth($id, $tName, $tPoint, '방위 시설', $tLname);
			}elseif(($tL == $HlandHaribote) && ($tLv > 0)){
				logLandTruth($id, $tName, $tPoint, '방위 시설', '위장 방위 시설 이노라');
			}elseif($tL == $HlandBank){
				logLandTruth($id, $tName, $tPoint, '숲', $tLname);
			}elseif($tL == $HlandGhostShip){
				logLandTruth($id, $tName, $tPoint, '바다', $tLname); # 유령배
			}elseif($tL == $HlandPirate){
				logLandTruth($id, $tName, $tPoint, '해적선', $tLname); # 해적선
			}
		}
		$island['money'] -= $cost;
		return 1;
	}elseif($kind == $HcomPioneer){
		// 이주
		if($landKind != $HlandPlains){
			// 평지 이외에서는 할 수 없다.
			logLandFail($id, $name, $comName, $landName, $point, $landKind, $lv);
			return 0;
		}
		$land[$x][$y] = $HlandTown;
		$landValue[$x][$y] = 1;
		logLandSuc($id, $name, $comName, $point);
		// 식량을 공제한다
		$island['food'] += $cost;
		return 1;
	}elseif($kind == $HcomDummy){
		// 더미 명령
		if($arg == 1){
			$comName = '채굴장 정비';
		}elseif($arg == 2){
			$comName = '매립';
		}else{
			$comName = '농장 정비';
		}
		if(($arg == 2) && ($HlogOmit2)){
			$sno = $island['seichi'];
			$island['seichi']++;
			if($HlogOmit2 == 1){
				$seichipnt;
				list($seichipnt['x'], $seichipnt['y'], $seichipnt['z']) = array($x, $y, '매립');
				$island['seichipnt'][$sno] = $seichipnt;
			}
		}else{
			logLandSuc($id, $name, $comName, $point);
		}
		logDummy($id, $name, $comName, $point);
		$island['money'] -= $cost;
		return 0;
	}elseif($kind == $HcomUg){
		// 지하 건설
		$ugL =& $island['ugL'];
		$ugV =& $island['ugV'];
		$ugX =& $island['ugX'];
		$ugY =& $island['ugY'];
		$i = null;
		for($i = 0; $i < $HugMax; $i++) {
			if (($land[$x][$y] == $HlandDokan) && (($x == $ugX[$i]) && ($y == $ugY[$i]))) { break; }
		}
		if($i >= $HugMax){
			return 0;
		}
		$v = ($x2 + $y2 * 3);
		if(($ugL[$i][$v] == $HugSpace) ||
			($ugL[$i][$v] == $HugDokan) ||
			($ugL[$i][$v] == $HugHasigo)){
			return 0;
		}
		if(($arg == 4) && ($island['money'] < 2400)){
			// 합성석유
			return 0;
		}
		if (($ugL[$i][$v] == $HugKiti) && ($landValue[$x][$y] > 0)) { $landValue[$x][$y]--; }
		if($arg <= 0){
			$ugL[$i][$v] = $HugTosi;
			$ugV[$i][$v] = 1;
			$comName = "지하 도시 건설";
		}elseif($arg == 1){
			$ugL[$i][$v] = $HugFarm;
			$ugV[$i][$v] = 10;
			$comName = "지하 농장 건설";
		}elseif($arg == 2){
			$ugL[$i][$v] = $HugFact;
			$ugV[$i][$v] = 30;
			$comName = "지하 공장 건설";
		}elseif($arg == 3){
			$ugL[$i][$v] = $HugKiti;
			$ugV[$i][$v] = 0;
			$comName = "지하 미사일 기지";
			$landValue[$x][$y]++;
		}else{
			$ugL[$i][$v] = $HugOil;
			$ugV[$i][$v] = 30;
			$cost *= 3;
			$comName = "지하 합성석유 공장 건설";
		}
		$island['money'] -= $cost;
		logPBSuc($id, $name, $comName, "($x, $y)의($x2, $y2)");
		return 1;
	}elseif($kind == $Hcomcolony){
		//콜로니 오토시
		if($arg == 1){
			logEvent($id, $name,"가,<B>슈퍼 쉴드(shield) 시스템</B>을 발동! ");
			$island['SSSystem'] = 1;
			$island['Crime'] = 1;
			$island['money'] -= $cost;
			return 1;
		}elseif($arg == 2){
			$island['money'] -= $cost;
			addCommandLate(1,$HislandTurn,$id,$kind,$target,$x,$y,$arg,$x2,$y2);# 턴 차이 명령
			return 1;
		}
		$tn = $HidToNumber[$target];
		if ($tn == '') { return 0; }
		$prize = $island['prize'];
		preg_match('/([0-9]*),([0-9]*),(.*)/', $prize, $_m);
		list($flags,$monsters,$turns) = array($_m[1],$_m[2],$_m[3]);
		if(!($flags & 512)){
			// 기술 부족에보다 중지
			logMiss($id, $name, $comName,"기술 부족");
			return 0;
		}
		$tIsland =& $Hislands[$tn];
		$tName = $tIsland['name'];
		if(($tIsland['turnsu'] + $tIsland['evil'] < $HdisUN) || ($tIsland['evil'] == 0)){
			// 상대가 도상국이기 때문에 중지.
			logUNMiss($id, $target, $name, $tName, $comName);
			return 0;
		}
//	극악이므로 코멘트···. 아한 번은 사용하고 싶다..
//		if($arg == 49){
//			$HpunishInfo{$target}->{punish} = 10;
//			$HpunishInfo{$target}->{x} = $x;
//			$HpunishInfo{$target}->{y} = $y;
//			logEventT($id, $target, $name,"가<B>구상 이노라을 소환해</B>${HtagName_}${tName}${AfterName}${H_tagName}를 향해 출격 시켰습니다.");
//			return 1;
//		}elsif($arg == 48){
//			my($i);
//			my($tAlly) = $tIsland['ally'];
//			logEvent($id, $name,"가,<B>다탄두핵미사일</B>을{$Hallygroup[$tAlly]}진영으로 향해 발사한 모양!");
//			for($i = 0; $i < $HislandNumber; $i++){
//				$tIsland =& $Hislands[$i];
//				my($ttAlly) = $tIsland['ally'];
//				if($tAlly == $ttAlly){
//					$target = $tIsland['id'];
//					$tName = $tIsland['name'];
//					logOut("다탄두핵미사일은,${HtagName_}${tName}${AfterName}($x,$y)${H_tagName}에 명중해 주위에도 피해가 나왔습니다.",$id, $target);
//					wideDamage($target, $tName, $tIsland['land'], $tIsland['landValue'], $x, $y, 1);
//				}
//			}
//			return 1;
//		}elsif($arg == 47){
//			my($i);
//			my($tAlly) = $tIsland['ally'];
//			logEvent($id, $name,"가,<B>구상 이노라을 소환해</B>$Hallygroup[$tAll진영으로 향해 출격 시켰습니다.");
//			for($i = 0; $i < $HislandNumber; $i++){
//				$tIsland =& $Hislands[$i];
//				my($ttAlly) = $tIsland['ally'];
//				if($tAlly == $ttAlly){
//					$target = $tIsland['id'];
//					$tName = $tIsland['name'];
//					$HpunishInfo{$target}->{punish} = 10;
//					$HpunishInfo{$target}->{x} = $x;
//					$HpunishInfo{$target}->{y} = $y;
//				}
//			}
//			return 1;
//		}
		if($island['weapon'] < 200){logMiss($id, $name,$comName,"콜로니 강하에 필요한 병기 부족");return 0;}
		list($wkind, $wname, $whp, $wkind2, $wkind3) = weatherinfo($tIsland['weather']);
		if($wkind > 1 && $island['eis3'] != 1){
			logMiss($id, $name,$comName,"표적이 기후 이상");
			if(($island['order'] & 512) && ($Hwflg > 0)){ # 자신 없어서 회수제감
				slideBack($comArray, $cNo, $kind, $target, $x, $y, $arg, $x2, $y2, $Hwflg); # 플래그 첨부로 명령 되돌린다
				$Hwflg--;
			}
			return 0;
		}
		$arg = 0;
		$island['weapon'] -= 200;
		$island['evil'] += 200;
		logEventT($id, $target, $name,"가<B>우주 인공 기지</B>를 ${HtagName_}${tName}${AfterName}${H_tagName}를 향해 강하시켰습니다.");
		// 금을 공제한다
		$island['money'] -= $cost;
		
		addCommandLate($HcomcolonyTurn,$HislandTurn,$id,$kind,$target,$x,$y,$arg,$x2,$y2);#턴 차이 명령
//CL		$tIsland['colony']++;
//CL		$tIsland['tunami'] = 2;
		return 1;
	}elseif(($kind == $HcomMissileNM) ||
		($kind == $HcomMissilePP) ||
		($kind == $HcomMissileSPP) ||
		($kind == $HcomMissileST) ||
		($kind == $HcomMissileLD) ||
		($kind == $HcomMissileRM) ||
		($kind == $HcomMissileSRM) ||
		($kind == $HcomMissileGM) ||
		($kind == $HcomMissileMGM) ||
		($kind == $HcomBioMissile) ||
		($kind == $HcomMissilePLD) ||
		($kind == $HcomMissileNCM) ||
		($kind == $HcomMissileRNG) ||
		($kind == $HcomMissileDM)){
		//  미사일계

		// 타겟 취득
		$tn = $HidToNumber[$target];
		if($tn == ''){
			// 타겟이 벌써 없다
			logMsNoTarget($id, $name, $comName);

			return 0;
		}
		// 공격할 수 있는 수를 산출
		if(($kind == $HcomMissileGM) || ($kind == $HcomMissileMGM)){
			$arg = 1;
		}elseif($arg == 0){
			// 0의 경우는 공격할 수 있을 뿐
			$arg = 10000;
		}

		// 사전 준비
		$tIsland =& $Hislands[$tn];
		$tName = $tIsland['name']; $tLand =& $tIsland['land']; $tLandValue =& $tIsland['landValue']; $flag = 0; $boat = 0;
		$tx = null; $ty = null; $err = null;
//		if($kind != $HcomMissileRM){ # 매립탄 이외
			if ($id != $target) { $island['evil'] += 30; }
			if(($tIsland['turnsu'] + $tIsland['evil'] < $HdisUN) || ($tIsland['evil'] == 0)){
				// 상대가 도상국이기 때문에 중지.
				logUNMiss($id, $target, $name, $tName, $comName);
				return 0;
			}
//		}
		$we = 1;# 병기
		// 파괴 미사일
		$DestMissile = 0;
		if(($kind == $HcomMissileLD) || ($kind == $HcomMissilePLD) || ($kind == $HcomMissileNCM)){
			$DestMissile = 1;
			$we = 10;
		}
		// 오차
		if(($kind == $HcomMissileGM) ||
		   ($kind == $HcomMissileMGM)){
			$err = 1;
			$we = 0;
		}elseif(($kind == $HcomMissilePP) ||
				($kind == $HcomBioMissile) ||
				($kind == $HcomMissilePLD) ||
				($kind == $HcomMissileRM)){
			$err = 7;
		}elseif($kind == $HcomMissileSPP){
			$err = 8;
		}elseif($kind == $HcomMissileDM){
			$err = 37;
		}elseif($kind == $HcomMissileRNG){
			$err = 18;
		}elseif($kind == $HcomMissileNCM){
			$err = 61;
			$we = 30;
		}else{
			$err = 19;
		}

		if($id != $target){
			if($island['weapon'] < $we) {logMiss($id, $name,$comName,"미사일 발사에 필요한 병기 부족");return 0;}
			$island['weapon'] -= $we;
		}

		list($renzoku, $rouryoku) = array(0,0);
		if(($kind == $HcomMissilePP) || ($kind == $HcomMissileNM)){
			$command = $comArray[$cNo]; # 다음의 명령을 조사한다
			// 연속으로 공격할 수 있는 대상의 명령 때
			if(($command['kind'] == $HcomMissilePP) ||
				($command['kind'] == $HcomMissileNM)){
				$renzoku = 1;
			}
		}

		if($kind == $HcomMissileNCM){ # 핵미사일
			if(($tIsland['MissileK'] < 30) && ($id != $target) && (!$HwarFlg)){
				logOut("${HtagName_}${name}${AfterName}${H_tagName} 가 ${HtagName_}${tName}${AfterName}$point${H_tagName}를 실시하려고 했습니다만, 격렬한 반핵 운동을 위해 중지되었습니다.",$id);
				return 0;
			}
			$rouryoku = 9;
		}
	
	// 전쟁 모드에서는 돈의 대신에 병기를 소비
	$mcost = 'money';
	if(($HwarFlg) && ($id != $target) && ($cost < 500)){
		$mcost = 'weapon';
		$cost = intval($cost / 10);
	}
	// 로그를 정리한다
	list($msCt,$mslogCtM,$mslogCtW,$mslogCtD) = array(0,0,0,0);
	// 금이 바닥날까 지정수 기에 충분할까 기지 전부가 공격할 때까지 루프, 연속때는 계속한다.
	list($bx, $by, $count, $level) = array(0,0,0,0);
	while((($arg > 0) && ($island['money'] >= $cost)) ||
			 (($renzoku == 1) && ($island[$mcost] >= $cost))){
		
		// 기지를 찾아낼 때까지 루프
		if($kind2 == $HcomSpecialSPP){
			// 바다짐승 소탕정에 의한 SPP
			if($island['monsship'] < 1){
				if ($flag == 0) { return 0; }
break;
			}elseif($island['monsship'] < 5){
				$level = $island['monsship'];
				$island['monsship'] = 0;
			}else{
				$level = 5;
				$island['monsship'] -= 5;
			}
		}else{
			while($count < $HpointNumber){
				$bx = $Hrpx[$count];
				$by = $Hrpy[$count];
				if ((($land[$bx][$by] == $HlandDefence) && ($landValue[$bx][$by] == 3)) ||
					($land[$bx][$by] == $HlandBase) || ($land[$bx][$by] == $HlandSbase) || ($land[$bx][$by] == $HlandDokan)) { break; }
				$count++;
			}
			if ($count >= $HpointNumber) { break; }
			$level = expToLevel($land[$bx][$by], $landValue[$bx][$by]); #  기지의 레벨을 산출
		}
	
		// 최저1개 기지가 있었으므로, flag를 세운다
		$flag = 1;

		// 기지내에서 루프
		while(($level > 0) && ($island[$mcost] > $cost)){
			
			if (($arg <= 0) && ($renzoku == 0)) { break; }
		// 공격했던 것이 확정이므로, 각 치를 소모시킨다
		$level--;
		if($rouryoku > 0){$rouryoku--;continue;} # 노력 소비

		if(($arg <= 0) && ($renzoku == 1)){ # 연속때

			slideFront($comArray, $cNo); # 이후를 채운다

			// 미사일 발사수등의 로그
			$island['MissileA'] += $msCt;
			logMissile($id, $target, $name, $tName, $comName, $point, $msCt, $msCt - $mslogCtM - $mslogCtW - $mslogCtD, $mslogCtM, $mslogCtW, $mslogCtD);
			list($msCt,$mslogCtM,$mslogCtW,$mslogCtD) = array(0,0,0,0);
			// 다음의 목표를 입력
			$kind = $command['kind'];
			$target = $command['target'];

			// 타겟 취득?
			$tn = $HidToNumber[$target];
			if($tn == ''){logMsNoTarget($id, $name, $comName);return 1;}
			$tIsland =& $Hislands[$tn];
			
			$tName = $tIsland['name'];
			$tLand =& $tIsland['land'];
			$tLandValue =& $tIsland['landValue'];

			$x = $command['x'];
			$y = $command['y'];

			$arg = $command['arg'];
			if ($arg == 0) { $arg = 10000; }

			if($HsurvFlg){
				// 서바이벌에서는 제한 없음
			}else{
				if (($id != $target) && ($arg > 5)) { $arg = 5; }
			}
			$err = ($kind == $HcomMissilePP) ? 7 : 19;

			$cost = $HcomCost[$kind];
			$comName = $HcomName[$kind];
			$point = "($x, $y)";

			// 전쟁 모드에서는 돈의 대신에 병기를 소비
			$mcost = 'money';
			if(($HwarFlg) && ($id != $target) && ($cost < 500)){
				$mcost = 'weapon';
				$cost = intval($cost / 10);
			}

			// 명령을 진행하게 한다
			$command = $comArray[$cNo]; # 최초의 것을 꺼내

			if ($id != $target) { $island['evil'] += 30; }
			if(($tIsland['turnsu'] + $tIsland['evil'] < $HdisUN) || ($tIsland['evil'] == 0)){
				// 상대가 도상국이기 때문에 중지.
				logUNMiss($id, $target, $name, $tName, $comName);
				return 1;
			}

			// 연속으로 공격할 수 있는 대상의 명령 때
			if(($command['kind'] == $HcomMissilePP) || ($command['kind'] == $HcomMissileNM)){
				$renzoku = 1;
			}else{
				$renzoku = 0;
			}
			if($HsurvFlg){
				// 서바이벌에서는 노력 1?
			}else{
				$rouryoku = 2;
			}
continue;
		}

		$msCt++; # 발사수를 계산

		$arg--;
		$island[$mcost] -= $cost;

		if($kind == $HcomMissileNCM){ # 핵미사일때
			$ncm = 1; # 미사일을 쏘았다
			$rouryoku = 9; # 노력
		}

		if($kind == $HcomMissileMGM){ # 괴수 유도탄때
			$Mcount = null;
			for($Mcount = 0; $Mcount < $HpointNumber; $Mcount++){
				$x = $Hrpx[$Mcount];
				$y = $Hrpy[$Mcount];
				if($tLand[$x][$y] == $HlandMonster){
					$special = $HmonsterSpecial[hako_pick(monsterSpec($tLandValue[$x][$y]), array(0))];
					if((($special == 3) && (($HislandTurn % 2) == 1)) ||
					   (($special == 4) && (($HislandTurn % 2) == 0))){
//								(($special == 4) && (($HislandTurn % 2) == 0)) ||
//								($special == 5)){
					}else{
break;
					}
				}
			}
			if($Mcount >= $HpointNumber){
				logMiss($id, $name, $comName, "적당한 괴수가 없었다");
				$island[$mcost] += $cost;
				return 0;
			}
		}

		// 착탄점산출
		$r = random($err);
		if (($kind == $HcomMissileSPP) && ($r == 7)) { $r = 0; }
		if ($kind == $HcomMissileRNG) { $r += 19; }
		$tx = $x + $ax[$r];
		$ty = $y + $ay[$r];
		if (!($ty % 2) && ($y % 2)) { $tx--; }
		
		list($wkind, $wname, $whp, $wkind2, $wkind3) = weatherinfo($island['weather']);
		list($twkind, $twname, $twhp, $twkind2, $twkind3) = weatherinfo($tIsland['weather']);

		if($kind != $HcomMissileMGM){ # 괴수 유도탄은 빗나가게 하지 않는다
			// 기후 체크
			if(($id != $target) && ($kind != $HcomMissileRM) && # 자신 도과 매립 미사일은 기후에 좌우되지 않는다.
					($island['eis3'] != 1) && # 군사위성이 없다
					((($wkind >= 2) && (random(6) == 0)) || (($twkind >= 2) && (random(6) == 0)))  ){
				$mslogCtW++;
continue;
			}
			
			// 이지스 함 체크
			if(($id != $target) && ($tIsland['aegis'] > 0)){
				$tIsland['aegis']--;
				if((random(3) == 0) && ($tIsland['money'] > 100)){
//					HdebugOut("이지스 함으로 막았다");
					$tIsland['money'] -= 100;
					$mslogCtD++;
continue;
				}
			}
			
			// 방위 위성 체크
			if(($id != $target) && ($tIsland['eis4']) && (random(2) == 0)){
//				HdebugOut("방위 위성으로 막았다");
				$tIsland['eis4']++;
				$mslogCtD++;
continue;
			}
			
			// 착탄점범위내외 체크
			if(($tx < 0) || ($tx >= $HislandSize) || ($ty < 0) || ($ty >= $HislandSize)){
				$mslogCtM++;
continue;
			}
		}
		
		// 착탄점의 지형등 산출
		list($tL, $tLv) = array($tLand[$tx][$ty], $tLandValue[$tx][$ty]);
		list($tLname, $tPoint) = array(landName($tL, $tLv), "($tx, $ty)");
		if($tIsland['defence'] > 0){
			// 방위 시설이 있는 경우 방위 시설 판정
			$defence = 0;
			if($HdefenceHex[$target][$tx][$ty] == 1){
				$defence = 1;
			}elseif(($tL == $HlandDefence) || (($tL == $HlandOil) && ($tLv == 5))){
				// 방위 시설에 명중
//				HdebugOut("방위 시설에 명중:list($tx,$ty) = ${tLv}");
				if($tLv == 2){
					$tLandValue[$tx][$ty] = 0;
					$defence = 1;
					logDefenceD($id, $target, $tName, landName($HlandDefence, 0), "($tx, $ty)");
				}elseif($tLv == 3){
					$tLandValue[$tx][$ty] = 2;
					$defence = 1;
					logDefenceD($id, $target, $tName, landName($HlandDefence, 2), "($tx, $ty)");
				}elseif($tLv == 11){
					$tLandValue[$tx][$ty] = 10;
					$defence = 1;
					logDefenceD($id, $target, $tName, landName($HlandDefence, 10), "(?, ?)");
				}elseif($tLv == 21){
					$tLandValue[$tx][$ty] = 20;
					$defence = 1;
					logDefenceD($id, $target, $tName, landName($HlandDefence, 20), "($tx, $ty)");
				}else{
					// 플래그를 클리어
					$i = null; $count = null; $sx = null; $sy = null;
					for($i = 0; $i < 19; $i++){
						$sx = $tx + $ax[$i];
						$sy = $ty + $ay[$i];
						if (!($sy % 2) && ($ty % 2)) { $sx--; }
						if(($sx < 0) || ($sx >= $HislandSize) || ($sy < 0) || ($sy >= $HislandSize)){
							// 범위외의 경우 아무것도 하지 않는다
						}else{
							// 범위내의 경우
							if ($HdefenceHex[$target][$sx][$sy] != -1) { $HdefenceHex[$target][$sx][$sy] = 0; }
						}
					}
				}
			}elseif($HdefenceHex[$target][$tx][$ty] == -1){
				$defence = 0;
			}elseif(chkAround($tLand, $tx, $ty, $HlandDefence, 19)){
				$HdefenceHex[$target][$tx][$ty] = 1;
				$defence = 1;
			}elseif(chkAroundEX($tLand, $tLandValue, $tx, $ty, $HlandOil, 5, 19)){
				$HdefenceHex[$target][$tx][$ty] = 1;
				$defence = 1;
			}else{
				$HdefenceHex[$target][$tx][$ty] = -1;
				$defence = 0;
			}
			
			if(($defence == 1) && ($kind != $HcomMissileMGM)){
				// 공중 폭파
				$mslogCtD++;
				if($kind == $HcomMissileST){ # 스텔스
					if (random(25) == 0) { logMsCaughtH($target, $name, $comName); }
				}
				if(random(25) == 0){
					// S방위 시설에 진화한다.
					$i = null; $sx = null; $sy = null;
					for($i = 1; $i < 19; $i++){
						$sx = $tx + $ax[$i];
						$sy = $ty + $ay[$i];
						if (!($sy % 2) && ($ty % 2)) { $sx--; }
						if(($sx < 0) || ($sx >= $HislandSize) || ($sy < 0) || ($sy >= $HislandSize)){
							// 범위외의 경우 아무것도 하지 않는다
						}elseif(($tLand[$sx][$sy] == $HlandDefence) && ($tLandValue[$sx][$sy] == 0)){
							logDefenceS($id, $target, $tName, landName($HlandDefence, 0), "($sx, $sy)");
							$tLandValue[$sx][$sy] = 2;
break;
						}elseif(($tLand[$sx][$sy] == $HlandDefence) && ($tLandValue[$sx][$sy] == 2)){
							logDefenceS($id, $target, $tName, landName($HlandDefence, 2), "($sx, $sy)");
							$tLandValue[$sx][$sy] = 3;
break;
						}elseif(($tLand[$sx][$sy] == $HlandDefence) && ($tLandValue[$sx][$sy] == 10)){
							logDefenceS($id, $target, $tName, landName($HlandDefence, 10), "(?, ?)");
							$tLandValue[$sx][$sy] = 11;
break;
						}elseif(($tLand[$sx][$sy] == $HlandDefence) && ($tLandValue[$sx][$sy] == 20)){
							logDefenceS($id, $target, $tName, landName($HlandDefence, 20), "($sx, $sy)");
							$tLandValue[$sx][$sy] = 21;
break;
						}
					}
				}
continue;
			}
		}

		// 전송 장치에 떨어졌을 경우
		if($tL == $HlandWarp){
			logOut("--- ${HtagName_}$tPoint${H_tagName} 의 <B>${tLname}</B>에 착탄. <B>시공의 틈에 빨려 들어갔습니다!</B>",$id,$target);
	//		$tLand[$tx][$ty] = $HlandWaste;
	//		$tLandValue[$tx][$ty] = 0;
			$st = warp($id, $name, 0, 0, $comName, $tLv, 11);
continue;
		}

		// 매립탄
		if($kind == $HcomMissileRM){
			if(($tIsland['area'] < $HdisFallBorder) && (($tL == $HlandSea) && ($tLv <= 1))){
				if(($tL == $HlandSea) && ($tLv == 0)){
					$tLand[$tx][$ty] = $HlandSea;
					$tLandValue[$tx][$ty] = 1;
					logMsNormal($id, $target, $tLname, $tPoint, "융기 해");
				}else{
					$tLand[$tx][$ty] = $HlandWaste;
					$tLandValue[$tx][$ty] = 1;
					$tIsland['area']++;
					logMsNormal($id, $target, $tLname, $tPoint, "융기 해");
				}
			}else{
				$mslogCtD++;
			}
continue;
		}

		// 전쟁용 매립탄
		if($kind == $HcomMissileSRM){
			if(($tL == $HlandSea) && ($tLv > 0)){
				// 얕은 여울 관계때
				$tLand[$tx][$ty] = $HlandWaste;
				$tLandValue[$tx][$ty] = 1;
				$tIsland['area']++;
			}elseif($HseaChk[$tL]){
				// 해관계때
				$tLand[$tx][$ty] = $HlandSea;
				$tLandValue[$tx][$ty] = 1;
			}else{
				$tLand[$tx][$ty] = $HlandWaste;
				$tLandValue[$tx][$ty] = 1;
			}
			logMsNormal($id, $target, $tLname, $tPoint, "융기 해");
continue;
		}

		// 핵미사일
		if($kind == $HcomMissileNCM){
			logOut("핵은,${HtagName_}${tName}${AfterName}$tPoint${H_tagName} 의 <B>$tLname</B>에 명중해 주위에도 피해가 나왔습니다.",$id, $target);
			wideDamage($target, $tName, $tLand, $tLandValue, $tx, $ty, 1);
			$tIsland['trump'][15] = 1;#트럼프 이벤트 캔슬
continue;
		}

		// 「효과 없음」hex를 최초로 판정
		if((($tL == $HlandSea) && ($tLv == 0)) || # 깊은 바다
			(((($tL == $HlandSea) && ($tLv <= 1)) || (($tL == $HlandOsen) && ($kind != $HcomBioMissile)) ||
				(($HmonumentMissile == 1) && ($tL == $HlandMonument)) ||   # (기념비 설정 밤)
				($tL == $HlandSMonument) ||   # 해저 기념비 또는···
				($tL == $HlandSbase) ||   # 해저 기지 또는···
				($tL == $HlandMountain)) #  산에서···
				&& ($DestMissile == 0))){ # 파괴 미사일 이외
			$mslogCtM++;# 무효화
continue;
		}

		// 총알의 종류로 분기
		if($DestMissile == 1){
			// 파괴 미사일계

			if($tL == $HlandMountain){
				// 산(황무지가 된다)
				logMsLD($id, $target, $tPoint, "의<B>$tLname</B>에 명중해 황무지화 되었습니다");
				$tLand[$tx][$ty] = $HlandWaste;
				$tLandValue[$tx][$ty] = 0;
continue;


			}elseif($tL == $HlandSbase){
				// 해저 기지
				logMsLD($id, $target, $tPoint, "에 착수 후 폭발해<B>$tLname</B>는 흔적도없이 사라졌습니다.");
			}elseif($tL == $HlandMonster){
				// 괴수
				logMsLD($id, $target, $tPoint, "에 착탄 후 폭발해<B>괴수$tLname</B>와 함께 수몰했습니다.");
			}elseif($tL == $HlandSea || $tL == $HlandBreakwater){
				// 얕은 여울, 방파제
				logMsLD($id, $target, $tPoint, "의<B>$tLname</B>에 착탄. 해저가 변화 했습니다");
			}elseif($tL == $HlandKInora){
				// 구상 이노라
				$mslogCtD++; # 공중 폭파
continue;
			}else{
				// 그 외
				logMsLD($id, $target, $tPoint, "의<B>$tLname</B>에 착탄. 육지가 수몰했습니다");
			}
			// 경험치
			if($tL == $HlandTown){
				if(($land[$bx][$by] == $HlandBase) || ($land[$bx][$by] == $HlandSbase)){
					// 아직 기지의 경우만
					$landValue[$bx][$by] += intval($tLv / 20);
					$island['allex'] += intval($tLv / 20); # 경험치총획득 건수
					if ($landValue[$bx][$by] > $HmaxExpPoint) { $landValue[$bx][$by] = $HmaxExpPoint; }
				}
			}

			// 얕은 여울이 된다
			$tLand[$tx][$ty] = $HlandSea;
			$tIsland['area']--;
			$tLandValue[$tx][$ty] = 1;
			if ($id != $target) { $tIsland['nation'][$tx][$ty] = $id; }

			// 그렇지만 바다계 지형이라면 바다
			if ($HseaChk[$tL]) { $tLandValue[$tx][$ty] = 0; }
			
			if ($tL == $HlandTrump) { $tIsland['trump'][$tLv] = 0; }
		}else{
			// 그 외 미사일
			if(($tL == $HlandWaste) && ($tLv <= 1)){
				//  황무지
				if($kind == $HcomBioMissile){
					logBioMs($id, $target, $tLname, $tPoint);
				}else{
					//  피해 없음
					$mslogCtM++;# 무효 미사일에 카운트
				}
			}elseif($tL == $HlandHugecity){
				// 초거대도시는 미사일이 효과가 없다
				$mslogCtM++;# 무효 미사일에 카운트
continue;
			}elseif($tL == $HlandMonster){
				// 괴수
				list($mKind, $mName, $mHp) = monsterSpec($tLv);
				$special = $HmonsterSpecial[$mKind];
				//  반격 이노라 (ST 이외)
				if(($mKind == 18) && (random(2) == 0) && ($kind != $HcomMissileST)){
					if(random(20) == 0){
						logMonsCounter($id, $target, $mName, $tPoint,"거대 운석을 소환했습니다.");
						$island['bigmissile']++;
					}else{
						logMonsCounter($id, $target, $mName, $tPoint,"운석을 소환할려고 합니다");
						$island['Meteo'] += 10;
					}
continue;
				}
				// 방어중?
				if((($special == 3) && (($HislandTurn % 2) == 1)) ||
				   (($special == 4) && (($HislandTurn % 2) == 0)) ||
				   (($special == 5) && (random(4) != 0))){
					// 방어중
					if($kind == $HcomMissileST){
						// 스텔스
						logMsMonNoDamageS($id, $target, $name, $tName, $comName, $mName, $point, $tPoint);
					}else{
						// 통상탄
						logMsMonNoDamage($id, $target, $mName, $tPoint);
					}
continue;
				}else{
					// 방어중이 아니다
					if($mHp == 1){

						// 이노라 고스트가 지바쿠 레이에
						if(($mKind == 5) && (random(5) == 0)){
							logMonsRei($id, $target, $mName, $tPoint);
							$tLandValue[$tx][$ty] = 1500 + $HmonsterBHP[15] + random($HmonsterDHP[15]);
continue;
						}

						// 괴수 쏘아 죽였을 때의 경험치
						if(($land[$bx][$by] == $HlandBase) || ($land[$bx][$by] == $HlandSbase)){
							$landValue[$bx][$by] += $HmonsterExp[$mKind];
							$island['allex'] += $HmonsterExp[$mKind]; # 경험치총획득 건수
							if ($landValue[$bx][$by] > $HmaxExpPoint) { $landValue[$bx][$by] = $HmaxExpPoint; }
						}

						// 괴수먹이 취득 플래그를 세운다

						$island['esa'] = $mKind;
						$tIsland['esa'] = $mKind;

						// 괴수의 상관계
						monstersPrize($mKind,$island);

						// 골드 고스트가 순금의 비가 된다
						if($mKind == 31){
							logMonsGold($id, $target, $name, $tName, $comName, $mName, $point, $tPoint);
							$tLand[$tx][$ty] = $HlandMonument;
							$tLandValue[$tx][$ty] = 9;
						}elseif($kind == $HcomMissileST){
							// 스텔스
							logMsMonKillS($id, $target, $name, $tName, $comName, $mName, $point, $tPoint);
						}else{
							// 통상
							logMsMonKill($id, $target, $name, $tName, $mName, $tPoint);
						}

						// 수입
						$value = $HmonsterValue[$mKind];
						if($value > 0) {
							if($target <= 90) {
								$tIsland['money'] += $value;
								logMsMonMoney($target, $mName, $value);
							} else {
								$island['money'] += $value;
								logMsMonMoney($id, $mName, $value);
							}
						}
						if ($mKind == 31) { continue; }
					}else{
						// 괴수 살아 있다
						if($kind == $HcomMissileST){
							// 스텔스
							logMsMonsterS($id, $target, $name, $tName, $comName, $mName, $point, $tPoint);
						}else{
							// 통상
							logMsMonster($id, $target, $mName, $tPoint);
						}
						// HP가  1줄어든다
						$tLandValue[$tx][$ty]--;
						if(($kind == $HcomBioMissile) && (($mKind == 6) || ($mKind == 7) || ($mKind == 8))){
							if(random(4) == 0){ # 오염에 의한 특수 변이
								if(random(2) == 0){
									$tLandValue[$tx][$ty] = 1300 + $HmonsterBHP[13] + random($HmonsterDHP[13]);
								}else{
									$tLandValue[$tx][$ty] = 1400 + $HmonsterBHP[14] + random($HmonsterDHP[14]);
								}
								list($afmKind, $afmName, $afmHp) = monsterSpec($tLandValue[$tx][$ty]);
								logMonsC($target, $name, $point, $mName, $afmName);
							}
						}
continue;
					}
				}
			}elseif(($tL == $HlandTown) || ($tL == $HlandTower) || ($tL == $HlandFactory) || ($tL == $HlandPort) || ($tL == $HlandFarm) || ($tL == $HlandBase)){
				// 마을, 농장, 공장, 상업 빌딩, 항구, 미사일 기지
				$result = " 피해가 감소";
				list($break,$Ept) = array(0,2);
				if($tL == $HlandFarm){ # 농장
					$tLandValue[$tx][$ty] -= 5;
					if ($kind == $HcomMissileGM) { $tLandValue[$tx][$ty] -= 5; }
					if($tLandValue[$tx][$ty] < 10){
						$result = " 괴멸";
						$break = 1;
						$Ept = 4;
					}
				}elseif($tL == $HlandBase){
					$tLandValue[$tx][$ty] -= 50;
					if ($kind == $HcomMissileGM) { $tLandValue[$tx][$ty] -= 50; }
					if($tLandValue[$tx][$ty] < 0){
						$result = " 괴멸";
						$break = 1;
						$Ept = 4;
					}
				}elseif($tL == $HlandPort){
					$tLandValue[$tx][$ty] -= 40;
					if ($kind == $HcomMissileGM) { $tLandValue[$tx][$ty] -= 40; }
					if($tLandValue[$tx][$ty] < 40){
						$result = " 괴멸";
						$break = 1;
						$Ept = 4;
					}
				}elseif($tL == $HlandTown){
					$p = 100;
					if ($tIsland['Hospital'] == 1) { $p = 80; }
					$tLandValue[$tx][$ty] -= $p;
					if ($kind == $HcomMissileGM) { $tLandValue[$tx][$ty] -= $p; }
					if($tLandValue[$tx][$ty] < 1){
						$result = "괴멸";
						$break = 1;
						$Ept = 0;
					}else{
						$Ept = 5;
						$boat += $p;
					}
				}else{
					$tLandValue[$tx][$ty] -= 10;
					if ($kind == $HcomMissileGM) { $tLandValue[$tx][$ty] -= 10; }
					if($tLandValue[$tx][$ty] < 30){
						$result = "괴멸";
						$break = 1;
						$Ept = 4;
					}
				}
				if($kind == $HcomMissileST){ # 스텔스
					logMsNormalS($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint, $result);
				}elseif(($kind == $HcomBioMissile) && ($break == 1)){ # 바이오
					logBioMs($id, $target, $tLname, $tPoint);
				}else{ # 통상
					logMsNormal($id, $target, $tLname, $tPoint, $result);
				}
				// 경험치
				if(($land[$bx][$by] == $HlandBase) || ($land[$bx][$by] == $HlandSbase)){
					$landValue[$bx][$by] += $Ept;
					$island['allex'] += $Ept; # 경험치총획득 건수
					if ($landValue[$bx][$by] > $HmaxExpPoint) { $landValue[$bx][$by] = $HmaxExpPoint; }
				}
				if ($break == 0) { continue; }
			}elseif(($tL == $HlandMegacity) || ($tL == $HlandMegaFarm) || ($tL == $HlandMegaFact) || ($tL == $HlandMegatower)){
				// 거대 지형 때
				$tL2 = null; $tLname2 = null;
				if($tL == $HlandMegaFact){
					$tL2 = $HlandFactory;
					$tLand[$tx][$ty] = $tL2;
					$tLandValue[$tx][$ty] = 90;
					$tLname2 = landName($tL2, 90);
				}elseif($tL == $HlandMegaFarm){
					$tL2 = $HlandFarm;
					$tLand[$tx][$ty] = $tL2;
					$tLandValue[$tx][$ty] = 50;
					$tLname2 = landName($tL2, 50);
				}else{
					if($tL == $HlandMegacity){
						$tL2 = $HlandTown;
						$boat += 300; # 통상 미사일이므로 난민에게 플러스
					}elseif($tL == $HlandMegatower){
						$tL2 = $HlandTower;
					}
					$tLand[$tx][$ty] = $tL2;
					$tLandValue[$tx][$ty] = 190;
					$tLname2 = landName($tL2, 190);
				}
				$result = "피해가 감소 ${tLname2}에 돌아왔습니다.";
				
				if($kind == $HcomMissileST){ # 스텔스
					logMsNormalS($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint, $result);
				}else{ # 통상
					logMsNormal($id, $target, $tLname, $tPoint, $result);
				}
				// 거대 지형 때의 경험치
				if(($land[$bx][$by] == $HlandBase) || ($land[$bx][$by] == $HlandSbase)){
					$landValue[$bx][$by] += 10;
					$island['allex'] += 10; # 경험치총획득 건수
					if ($landValue[$bx][$by] > $HmaxExpPoint) { $landValue[$bx][$by] = $HmaxExpPoint; }
				}
continue;
			}elseif(($tL > 100) && ($tL < 120)){
				// 배계의 경우
				list($order, $hp, $sId) = shipSpec($tLv);
				if(($hp <= 1) || ($tL == $HlandBalloonS)){
					// 배침몰(갯바람배는 일격으로 갈라진다)
					if($tL == $HlandPirate){
						if(random(5) == 0){
							// 해적선이 있던 도에 유령 출범현
							$tIsland['ghost'] = $target;
						}elseif(($sId == 0) && ($kind != $HcomMissileST)){
							// 해적선 귀속시킨다
							logMsShip($id, $target, $tLname, $tPoint, $tL, "투항했습니다.");
							$tLandValue[$tx][$ty] = 21000 + $id;
continue;
						}
					}elseif($tL == $HlandTreasureS){
						// 보물선
						$island['money'] += 5000;
						$tIsland['money'] += 5000;
						//랭킹용 로그 파일 서두
						hako_open('MOUT',">>${HlogdirName}/money.log");
						hako_write('MOUT', "$HislandTurn,$id,보물선,5000\n");
						hako_write('MOUT', "$HislandTurn,$target,보물선,5000\n");
						hako_close('MOUT');
					}elseif($tL == $HlandBalloonS){
						// 갯바람배
						if($kind == $HcomMissileST){
							logMsShipS($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint, "갈라졌습니다.");
						}else{
							$tLand2 =& $tIsland['land2'];
							$tLandValue2 =& $tIsland['landValue2'];
							
							$p = random(100);
							if($p < 20){ # 자금
								$r = random(10000);
								$tIsland['money'] += $r;
								logOut("--- ${HtagName_}($tx, $ty)${H_tagName} 의  바람배가 갈라지고 왜인지 보관중인 $r${HunitMoney}가 뿌려졌습니다.",$id,$target);
								//랭킹용 로그 파일 서두
								hako_open('MOUT',">>${HlogdirName}/money.log");
								hako_write('MOUT', "$HislandTurn,$id,갯바람배,$r\n");
								hako_close('MOUT');
							}elseif($p < 30){ # 식량
								$tIsland['food'] += 10000;
								logOut("--- ${HtagName_}($tx, $ty)${H_tagName} 의  바람배가 갈라지고 왜인지 보관중인 식량이 뿌려졌습니다..",$id,$target);
							}elseif($p < 45){ # 꽃
								$tLand[$tx][$ty] = $HlandFlower;
								$tLandValue[$tx][$ty] = random(13) + 1;
								$tLand2[$tx][$ty] = $HlandSea;
								$tLandValue2[$tx][$ty] = 0;
								$mName = landName($HlandFlower, $tLandValue[$tx][$ty]);
								logOut("--- ${HtagName_}($tx, $ty)${H_tagName} 의  바람배가 갈라지고 동시에 안으로부터 대량의<B>$mName</B>이 뿌려졌습니다!",$id,$target);
							}elseif($p < 60){ # 운석
								$tIsland['Meteo'] += 10;
								logOut("--- ${HtagName_}($tx, $ty)${H_tagName} 의  바람배가 갈라졌습니다",$id,$target);
							}elseif($p < 68){ # 거대 운석
								$tIsland['bigmissile']++;
								logOut("--- ${HtagName_}($tx, $ty)${H_tagName} 의  바람배가 분열하여 갑작스럽게 출현한 이공간으로부터<b>거대 운석</b>이 나타났습니다.",$id,$target);
							}elseif($p < 88){ # 지진
								$tIsland['prepare2'] += 10;
								logOut("--- ${HtagName_}($tx, $ty)${H_tagName} 의  바람배가 갈라졌습니다",$id,$target);
							}elseif($p < 98){ # 시고스트
								$tLand[$tx][$ty] = $HlandMonster;
								$tLandValue[$tx][$ty] = 2105;
								$tLand2[$tx][$ty] = $HlandSea;
								$tLandValue2[$tx][$ty] = 0;
								$mName = hako_pick(monsterSpec(2105), array(1));
								logOut("--- ${HtagName_}($tx, $ty)${H_tagName} 의  바람배가 갈라졌다고 보임과 동시에 이공간이 열려 안으로부터<B> 괴수 $mName</B>가 출현했습니다!",$id,$target);
							}else{ # 골드 고스트
								$tLand[$tx][$ty] = $HlandMonster;
								$tLandValue[$tx][$ty] = 3100 + $HmonsterBHP[31] + random($HmonsterDHP[31]);
								$tLand2[$tx][$ty] = $HlandSea;
								$tLandValue2[$tx][$ty] = 0;
								$mName = hako_pick(monsterSpec(3100), array(1));
								logOut("--- ${HtagName_}($tx, $ty)${H_tagName} 의  바람배가 갈라졌다고 보임과 동시에 이공간이 열려 안으로부터<B> 괴수 $mName</B>가 출현했습니다!",$id,$target);
							}
							
							//랭킹용 로그 파일 서두
							$rL = $tL - $HlandPirate;
							hako_open('ROUT',">>${HlogdirName}/ship.log");
							hako_write('ROUT', "$HislandTurn,$id,99,$rL\n");
							hako_close('ROUT');
						}
					}
					// 배 가라앉혔을 때의 경험치
					if(($land[$bx][$by] == $HlandBase) || ($land[$bx][$by] == $HlandSbase)){
						$landValue[$bx][$by] += $HshipEX[$tL - $HlandPirate];
						$island['allex'] += $HshipEX[$tL - $HlandPirate]; # 경험치총획득 건수
						if ($landValue[$bx][$by] > $HmaxExpPoint) { $landValue[$bx][$by] = $HmaxExpPoint; }
					}
					
					if($tL == $HlandBalloonS){
						if ($tLand[$tx][$ty] != $HlandBalloonS) { continue; }
					}elseif($kind == $HcomMissileST){
						// 스텔스
						logMsShipS($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint, "침몰했습니다.");
					}else{
						// 통상
						logMsShip($id, $target, $tLname, $tPoint, $tL, "침몰했습니다.");
					}
					
				}else{
					// 배데미지
					if($kind == $HcomMissileST){
						// 스텔스
						logMsShipS($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint, "데미지를 받았습니다.");
					}else{
						// 통상
						logMsShipD($id, $target, $tLname, $tPoint, $tL, "데미지를 받았습니다.");
					}
					// HP가  1줄어든다
					$tLandValue[$tx][$ty] -= 1000;
continue;
				}
			}elseif($tL == $HlandKInora){
				// 구상 이노라
				list($limit, $hp, $ld, $d) = bigMonsterSpec($tLv);
				if($kind == $HcomMissileST){
					$mslogCtD++; # 공중 폭파
continue;
				}
				if ($hp < 100) { $tLandValue[$tx][$ty] += 100; }
				if($d == 0){
					// 중심
					logOut("--- ${HtagName_}$tPoint${H_tagName} 의 <B>괴수$tLname</B>에 명중했습니다만, 효과가 없을 뿐만 아니라 회복하고 있는 것 같습니다",$id, $target);
				}else{
					// 경험치
					if(($land[$bx][$by] == $HlandBase) || ($land[$bx][$by] == $HlandSbase)){
						$landValue[$bx][$by] += 2;
						$island['allex'] += 2;
						if ($landValue[$bx][$by] > $HmaxExpPoint) { $landValue[$bx][$by] = $HmaxExpPoint; }
					}
					// 라스트 데미지 보존
					$lastDamage = $id;
					logOut("--- ${HtagName_}$tPoint${H_tagName} 의 <B>괴수$tLname</B>에 명중해,<B>괴수$tLname</B>는 데미지를 받았습니다.",$id, $target);
				}
continue;
			}elseif(($tL == $HlandTrump) && ($tLv == 0)){
				// 트럼프
				$tNumber = random(14) + 1;
				$tLandValue[$tx][$ty] = $tNumber;
				$tLname2 = landName($tL, $tNumber);
				if($kind == $HcomMissileST){ #스텔스
					logMsNormalS($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint,"째구<b>${tLname2}</b>가 되어");
				}else{ # 통상
					logMsNormal($id, $target, $tLname, $tPoint,"째구<b>${tLname2}</b>가 되어");
				}
				if($tIsland['trump'][15] != 1){
					// 핵미사일이 총격당하지 않을 때
					$i = null;
					for($i = 1; $i < 14; $i++){
						if ($tIsland['trump'][$i] != 1) { continue; }
						if($i == $tNumber){
							// 같은 번호
							$str = "";
							$r = 0;
							if($i < 6){
								$r = 10000;
								$str = "상금을${r}${HunitMoney}획득";
							}elseif($i < 10){
								$r = 5000;
								$str = "상금을${r}${HunitMoney}획득";
								$island['event2'] = 1;
							}elseif($i < 13){
								$r = 4000;
								$str = "상금을${r}${HunitMoney}와 선물 세트를 획득";
								$island['present'][4]++;
								$island['present'][5]++;
								$island['present'][8]++;
							}
							if($r == 0){
								$island['present'][7]++; # 대도시
								$str = "왜인지 대도시가 건설 예정으로 되어";
							}else{
								$island['money'] += $r;
								hako_open('MOUT',">>${HlogdirName}/money.log");
								hako_write('MOUT', "$HislandTurn,$id,트럼프,$r\n");
								hako_close('MOUT');
							}
							logOut("${HtagName_}$name${AfterName}${H_tagName} 는 , 당긴 카드가 갖추어져 ${str}했다.",$id, $target);
							$tLand[$tx][$ty] = $HlandWaste;
							$tLandValue[$tx][$ty] = 1;
break;
						}
					}
				}
				if($tLandValue[$tx][$ty] == 14){
					// 공격한 도에 그라테네스 출현
					logOut("조커가<B>괴수</B>를 ${HtagName_}${name}${AfterName}${H_tagName}에 소환하고 있다.",$id, $target);
					$island['monstersend2']++;
				}else{
					$tIsland['trump'][$tNumber] = 1;
				}
continue;
			}else{
				// 통상 지형
				if($kind == $HcomMissileST){ # 스텔스
					logMsNormalS($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint,"괴멸 해");
				}elseif($kind == $HcomBioMissile){ #바이오
					logBioMs($id, $target, $tLname, $tPoint);
				}else{ # 통상
					logMsNormal($id, $target, $tLname, $tPoint,"괴멸");
				}
				if ($tL == $HlandTrump) { $tIsland['trump'][$tLv] = 0; }
			}
			// 경험치
			if((($tL == $HlandTown) || ($tL == $HlandSlum)) ||
				(($tL == $HlandOil) && ($tLv >= 35))){
				if(($land[$bx][$by] == $HlandBase) || ($land[$bx][$by] == $HlandSbase)){
					$landValue[$bx][$by] += intval($tLv / 20);
					$island['allex'] += intval($tLv / 20); # 경험치총획득 건수
					if ($landValue[$bx][$by] > $HmaxExpPoint) { $landValue[$bx][$by] = $HmaxExpPoint; }
					// 해저 이외 때는 통상 미사일이므로 난민에게 플러스
					if ($tL != $HlandOil) { $boat += $tLv; }
				}
			}elseif(($tL == $HlandOil) && ($tLv >= 10) && ($tLv <= 30)){
				if(($land[$bx][$by] == $HlandBase) || ($land[$bx][$by] == $HlandSbase)){
					$landValue[$bx][$by] += intval($tLv / 5);
					$island['allex'] += intval($tLv / 5); # 경험치총획득 건수
					if ($landValue[$bx][$by] > $HmaxExpPoint) { $landValue[$bx][$by] = $HmaxExpPoint; }
				}
			}

			if($kind != $HcomMissileST){
				// ST미사일 이외
				if($tL == $HlandBank){
					// 은행을 파괴했을 때
					$island['money'] += $tLv * 500;
					logMsBank($id, $name, $tLv * 500);
				}
				// ST미사일 이외로 점유
				if (($tLand[$tx][$ty] != $HlandWaste) && ($id != $target)) { $tIsland['nation'][$tx][$ty] = $id; }
			}
			
			if(($tL == $HlandOil) || (($tL > 100) && ($tL < 120))){
				// 유전, 배계라면 바다
				$tLand[$tx][$ty] = $HlandSea;
				$tLandValue[$tx][$ty] = 0;
			}elseif( (($tL == $HlandSea) && ($tLv >= 10)) || 
					(($tL == $HlandBreakwater) && ($tLv >= 1))){
				// 양식장, 방파제라면 얕은 여울
				$tLand[$tx][$ty] = $HlandSea;
				$tLandValue[$tx][$ty] = 1;
			}elseif($kind == $HcomBioMissile){
				// 바이오 미사일때는 오염
				if(($tL == $HlandOsen) && ($tLv < 10)){
					$tLandValue[$tx][$ty]++;
				}elseif($tL != $HlandOsen){
					$tLand[$tx][$ty] = $HlandOsen;
					$tLandValue[$tx][$ty] = 1;
				}
			}else{
				 // 그 외는 황무지가 된다
				 $tLand[$tx][$ty] = $HlandWaste;
				 $tLandValue[$tx][$ty] = 1; #  착탄점
			}
		} 
		}

		// 카운트증가나 해 둔다
		$count++;
	}

	if($flag == 0){
		// 기지가 1개나 없었던 경우
		logMsMiss($id, $name, $comName);
		return 0;
	}

	$island['MissileA'] += $msCt; # 발사수를 계산
	// 미사일 발사수등의 로그
	if($kind == $HcomMissileST){ # 스텔스
		logMissileS($id, $target, $name, $tName, $comName, $point, $msCt, $msCt - $mslogCtM - $mslogCtW - $mslogCtD, $mslogCtM, $mslogCtW,$mslogCtD);
	}else{
		logMissile($id, $target, $name, $tName, $comName, $point, $msCt, $msCt - $mslogCtM - $mslogCtW - $mslogCtD, $mslogCtM, $mslogCtW, $mslogCtD);
	}

	// 난민 판정
	$boat = ($HwarFlg) ? $boat : intval($boat / 2);
//	HdebugOut("난민 debug１=${id}=>${target} 명령=${kind} 수=${boat}");
	if(($boat > 0) && ($id != $target) && ($kind != $HcomMissileST)){
		$achive = refugees($boat,$island);
//		HdebugOut("난민 debug２=${achive}");
		if($achive > 0){
			// 조금이라도 도착했을 경우, 로그를 토한다
			logMsBoatPeople($id, $name, $achive);
			$island['achive'] = ($HwarFlg) ? 0 : $achive; # 난민수보존
			// 난민의 수가 일정수이상이라면, 평이미지의 가능성 있어
			if($achive >= 200){
				$prize = $island['prize'];
				preg_match('/([0-9]*),([0-9]*),(.*)/', $prize, $_m);
				list($flags,$monsters,$turns) = array($_m[1],$_m[2],$_m[3]);
				if((!($flags & 8)) &&  $achive >= 200){
					$flags |= 8;
					logPrize($id, $name, $Hprize[4]);
				}elseif((!($flags & 16)) &&  $achive > 500){

					$flags |= 16;
					logPrize($id, $name, $Hprize[5]);
				}elseif((!($flags & 32)) &&  $achive > 800){
					$flags |= 32;
					logPrize($id, $name, $Hprize[6]);
				}
				$island['prize'] = "$flags,$monsters,$turns";
			}
		}else{
			logOut("${HtagName_}${name}${AfterName}${H_tagName}에  난민이 표착했습니다만 ${HtagName_}${name}${AfterName}${H_tagName} 는  수락을 거절한 것 같습니다. ",$id);
		}
	}
	
	if($kind2 == $HcomSpecialSPP){
		// 바다짐승 소탕정에 의한 SPP
		return 0;
	}elseif(($kind == $HcomMissileST) || ($kind == $HcomMissileNCM)){
		// 스텔스, 핵의 경우는 종료
		if(($kind == $HcomMissileNCM) && ($ncm == 0)){ # 미사일 기지 부족해 핵을 공격할 수 없었다
			logOut("${HtagName_}${name}${AfterName}${H_tagName} 가 ${HtagName_}${tName}${AfterName}$point${H_tagName}지점으로 향해 ${HtagComName_}${comName}${H_tagComName}를 실시하려고 했습니다만, 미사일 기지의 부족으로 중단 되었습니다.",$id);
			return 0;
		}
		return 1;
	}else{
		$island['Afmissile'] = 2;
		return 0;
	}

	}elseif(($kind == $HcomSendMonster) || ($kind == $HcomSSendMonster)){
		// 괴수 파견
		// 타겟 취득
		$tn = $HidToNumber[$target];
		$tIsland =& $Hislands[$tn];
		$tName = $tIsland['name'];

		if($tn == ''){
			// 타겟이 벌써 없다
			logMsNoTarget($id, $name, $comName);
			return 0;
		}
		if(($tIsland['turnsu'] + $tIsland['evil'] < $HdisUN) || ($tIsland['evil'] == 0)){
			// 상대가 도상국이기 때문에 중지.
			logUNMiss($id, $target, $name, $tName, $comName);
			return 0;
		}
		$we = 100;
		if($kind == $HcomSSendMonster){
			if(($HsurvFlg) && ($HislandTurn > $Hsstartturn)){
				// 서바이벌의 경우는 제한 없음
			}elseif(($arg > 30) || ((12 <= $arg) && ($arg <= 17)) || ($arg == 23) || ($arg == 24)){
				logMiss($id, $name,$comName,"괴수 건조를 할수없는 괴수");
				return 0;
			}
			$we = 200;
		}
		if(($kind == $HcomSSendMonster) || ($arg == 2)){
			if($island['weapon'] < $we){logMiss($id, $name,$comName,"괴수 건조에 필요한 병기 부족");return 0;}
			$island['weapon'] -= $we;
		}
		if ($id != $target) { $island['evil'] += 40; }
		// 메세지
		logMonsSend($id, $target, $name, $tName);
		$island['money'] -= $cost;
		if($kind == $HcomSSendMonster){
			addCommandLate($HcomSSendMonsterTurn,$HislandTurn,$id,$kind,$target,$x,$y,$arg,$x2,$y2);# 턴 차이 명령
		}else{
			addCommandLate($HcomSendMonsterTurn,$HislandTurn,$id,$kind,$target,$x,$y,$arg,$x2,$y2);#  턴 차이 명령
		}
//CL		if($arg == 1){
//CL			$tIsland['monstersend1']++;
//CL		}elsif($arg == 2){
//CL			$tIsland['monstersend2']++;
//CL		}elsif($arg == 3){
//CL			$tIsland['monstersend3']++;
//CL		}else{
//CL			$tIsland['monstersend']++;
//CL		}
		return 1;
	}elseif(($kind == $HcomManipulate) || ($kind == $HcomSTManipulate) || ($kind == $HcomShipM)){
		// 괴수 조작, ST괴수 조작, 배조작
		$tn = $HidToNumber[$target];
		if ($tn == '') { return 0; }
		$tIsland =& $Hislands[$tn];
		$tName = $tIsland['name'];
		if($arg < 1){
			$arg = 1;
		}elseif($arg >= 7){
			$arg = 6;
		}
		if($kind == $HcomShipM){
			if($id == $target){
				// 자도의 경우
				$tIsland['shipMoveM'] = $arg;
				$tIsland['shipMoveMt'] = $target;
				$tIsland['shipMoveMid'] = $id;
			}else{
				$tIsland['shipMoveT'] = $arg;
				$tIsland['shipMoveTt'] = $target;
				$tIsland['shipMoveTid'] = $id;
			}
			logManipulateS($id, $target, $name, $tName, $comName);
		}else{
			$tIsland['manipulate'] = $arg;
			if($kind == $HcomManipulate){
				logManipulate($id, $target, $name, $tName, $comName);
			}else{
				logManipulateS($id, $target, $name, $tName, $comName);
			}
		}
		$island['money'] -= $cost;
		return 1;
	}elseif($kind == $HcomShip){
		// 배지령 변경
		$tn = $HidToNumber[$target];
		if ($tn == '') { return 0; }
		
		$tIsland =& $Hislands[$tn];
		$tName = $tIsland['name'];
		$tLand =& $tIsland['land'];
		$tLandValue =& $tIsland['landValue'];
		$tL = $tLand[$x][$y];
		$tLv = $tLandValue[$x][$y];
		
		if ($HseaChk[$tL] != 2) { return 0; }
		list($order, $hp, $sId) = shipSpec($tLv);
		if ($sId != $id) { return 0; }
		if($arg < 0){
			$arg = 0;
		}elseif($arg >= 4){
			$arg = 4;
		}
		if ($order == $arg) { return 0; }
		logShipOrderC($id, $tName, landName($tL, $tLv), "($x, $y)", $Hshiporder[$arg]);
		$tLandValue[$x][$y] = $arg * 10000 + $hp * 1000 + $sId;
		$island['money'] -= $cost;
		return 0;
	}elseif($kind == $HcomShipSell){
		// 배매각
		if ($HseaChk[$landKind] != 2) { return 0; }
		list($order, $hp, $sId) = shipSpec($lv);
		if ($sId != $id) { return 0; }
		$island['money'] += $HshipSell[$landKind - $HlandPirate];
		$land[$x][$y] = $land2[$x][$y];
		$landValue[$x][$y] = $landValue2[$x][$y];
		$land2[$x][$y] = $HlandSea;
		$landValue2[$x][$y] = 0;
		logEventP($id, $name,"($x, $y)", "의 배가 매각되었습니다.");
		return 0;
	}elseif($kind == $HcomEmigration){
		// 이민
		$tn = $HidToNumber[$target];
		if ($tn == '') { return 0; }
		$tIsland =& $Hislands[$tn];
		$tName = $tIsland['name'];
		if(($landKind == $HlandTown) || ($landKind == $HlandSlum)){
			$boat = $landValue[$x][$y];
			$boat = intval($boat / 2);
			$achive = refugees($boat, $tIsland);
			if ($achive > 0) { logRefugees($id, $target, $name, $tName, $achive); }
			$land[$x][$y] = $HlandPlains;
			$landValue[$x][$y] = 0;
			$island['money'] -= $cost;
			$island['AfEmigra'] = 1;
			return 0;
		}else{
			logLandFail($id, $name, $comName, $landName, $point, $landKind, $lv);
			return 0;
		}
	}elseif($kind == $HcomSell){
		// 수출량 결정
		if ($arg == 0) { $arg = 1; }
		$value = min($arg * (-$cost), $island['food']);

		// 수출 로그
		logSell($id, $name, $comName, "$value$HunitFood");
		$island['food'] -=  $value;
		$island['money'] += intval($value / 10);
		return 0;
	}elseif(($kind == $HcomOreSell) || ($kind == $HcomOilSell) || ($kind == $HcomWeponSell)) {
		// 매각량 결정
		if ($arg == 0) { $arg = 1; }
		$value = null;
		if($id != $target){
			// 원조의 경우
			if ($island['pop'] < $Haidpop) { return 0; }
			$tn = $HidToNumber[$target];
			if ($tn == '') { return 0; }
			$tIsland =& $Hislands[$tn];
			$tName = $tIsland['name'];

			// 원조량 결정
			if($kind == $HcomOreSell){
				$value = min($arg, $island['ore']);
				$island['ore'] -= $value;
				$tIsland['ore'] += $value;
				$value = "$value$HunitOre";
			}elseif($kind == $HcomOilSell){
				$value = min($arg, $island['oil']);
				$island['oil'] -= $value;
				$tIsland['oil'] += $value;
				$value = "$value$HunitOil";
			}elseif($kind == $HcomWeponSell){
				$value = min($arg, $island['weapon']);
				$island['weapon'] -= $value;
				$tIsland['weapon'] += $value;
				$value = "$value$HunitWeapon";
			}
			// 원조 로그
			logAid($id, $target, $name, "$tName$AfterName", $comName, $value);
			return 0;
		}else{
			if($kind == $HcomOreSell){
				$value = min($arg, $island['ore']);
				$island['ore'] -= $value;
				$island['money'] += ($value * 1);
				$value = "$value$HunitOre";
			}elseif($kind == $HcomOilSell){
				$value = min($arg, $island['oil']);
				$island['oil'] -= $value;
				$island['money'] += ($value * 2);
				$value = "$value$HunitOil";
			}elseif($kind == $HcomWeponSell){
				$value = min($arg, $island['weapon']);
				$island['weapon'] -= $value;
				$island['money'] += ($value * 6);
				$value = "$value$HunitWeapon";
			}
		}

		// 매각 로그
		logSell($id, $name, $comName, $value);
		return 0;
	}elseif(($kind == $HcomOreBuy) || ($kind == $HcomOilBuy) || ($kind == $HcomWeponBuy)) {
		// 구입량 결정
		if ($arg == 0) { $arg = 1; }
		if($kind == $HcomOreBuy){
			if($island['money'] > $arg * 2){
				$island['ore'] += $arg;
				$island['money'] -= ($arg * 2);
			}else{
				logMiss($id, $name, $comName,"자금부족");
				return 0;
			}
		}elseif($kind == $HcomOilBuy){
			if($island['money'] > $arg * 5){
				$island['oil'] += $arg;
				$island['money'] -= ($arg * 5);
			}else{
				logMiss($id, $name, $comName,"자금부족");
				return 0;
			}
		}elseif($kind == $HcomWeponBuy){
			if($island['money'] > $arg * 24){
				$island['weapon'] += $arg;
				$island['money'] -= ($arg * 24);
			}else{
				logMiss($id, $name, $comName,"자금부족");
				return 0;
			}
		}
		logSell($id, $name, $comName, $arg);
		return 1;
	}elseif(($kind == $HcomFood) || ($kind == $HcomMoney)){
		// 원조계
		if($island['pop'] < $Haidpop){
//			HdebugOut("인구가 규정수에 못 미친 경우는, 원조 명령은 할 수 없습니다.")
			return 0;
		}
		
		// 타겟 취득
		$tn = $HidToNumber[$target];
		$tIsland =& $Hislands[$tn];
		$tName = $tIsland['name'];

		// 원조량 결정
		if ($arg == 0) { $arg = 1; }
		$value = null; $str = null;
		if($cost < 0){
			$value = min($arg * (-$cost), $island['food']);
			$str = "$value$HunitFood";
		}else{
			$value = min($arg * ($cost), $island['money']);
			$str = "$value$HunitMoney";
		}

		// 원조 로그
		logAid($id, $target, $name, "$tName$AfterName", $comName, $str);

		if($cost < 0){
			$island['food'] -= $value;
			$tIsland['food'] += $value;
		}else{
			$island['money'] -= $value;
			$tIsland['money'] += $value;
		}
		return 0;
	}elseif($kind == $HcomSearch){
		// 지질 조사
		if(($landKind == $HlandPlains) || ($landKind == $HlandTown) ||
			(($landKind == $HlandWaste) && ($lv <= 1))){
			// 투자액 결정
			if ($arg == 0) { $arg = 1; }
			if ($arg > 10) { $arg = 10; }
			$value = null; $str = null; $p = null; $q = null;
			$value = min($arg * ($cost), $island['money']);
			$str = "$value$HunitMoney";
			$p = intval($value / $cost);
			if ($p > 10) { $p = 10; }
			$island['money'] -= $p * $cost;
			$q = random(1000);
			$island['prepare2'] += $p;
			if($q < 3 * $p){ # 금광
				$land[$x][$y] = $HlandSeisei;
				$landValue[$x][$y] = 30;
				logChosa($id, $name, $point, $comName, $str, ",금광맥이 발견");
			}elseif($q < 17 * $p){ # 동광
				$land[$x][$y] = $HlandSeisei;
				$landValue[$x][$y] = 10;
				logChosa($id, $name, $point, $comName, $str, ",동광맥이 발견");
			}elseif($q < 50 * $p){ # 탄광
				$land[$x][$y] = $HlandSeisei;
				$landValue[$x][$y] = 5;
				logChosa($id, $name, $point, $comName, $str, ",탄광맥이 발견");
			}elseif($q < 60 * $p){ # 온천
				$land[$x][$y] = $HlandWaste;
				$landValue[$x][$y] = 20 + random(51);
				logChosa($id, $name, $point, $comName, $str, ",온천이 발견");
			}elseif($q < 86 * $p){ # 지하수
				$land[$x][$y] = $HlandSea;
				$landValue[$x][$y] = 1;
				logChosa($id, $name, $point, $comName, $str, ", 대량의 지하수가 분출해 얕은 여울이 되어");
			}elseif($q < 90 * $p){ #  괴수
				$land[$x][$y] = $HlandMonster;
				$landValue[$x][$y] = 1200 + $HmonsterBHP[12] + random($HmonsterDHP[12]);
				logChosa($id, $name, $point, $comName, $str, ",태고의 괴수가 발견");
			}else{ # 실패
				$land[$x][$y] = $HlandWaste;
				$landValue[$x][$y] = 0;
				logChosa($id, $name, $point, $comName, $str, "했지만 아무것도 발견되지 않고 황무지 화 되어");
			}
			return 1;
		}else{
			logLandFail($id, $name, $comName, $landName, $point, $landKind, $lv);
			return 0;
		}
	}elseif($kind == $HcomGiveup){
		// 방폐
		$island['giveup'] = 1;
		$island['dead'] = 1;
		return 1;
	}elseif (($kind == $HcomSUnit) ||
			($kind == $HcomSMissileGM) ||
			($kind == $HcomSMissilePP) ||
			($kind == $HcomSMissile) ||
			($kind == $HcomSMissileMGM) ||
			($kind == $HcomSBuild) ||
			($kind == $HcomSpaceFarm) ||
			($kind == $HcomSFactory) ||
			($kind == $HcomSpaceBase) ||
			($kind == $HcomSDbase) ||
			($kind == $HcomSEisei) ||
			($kind == $HcomSPioneer) ||
			($kind == $HcomSOccupy) ||
			($kind == $HcomSDestroy) ||
			($kind == $HcomSFood)){
		// 우주계
		$prize = $island['prize'];
		preg_match('/([0-9]*),([0-9]*),(.*)/', $prize, $_m);
		if(!($_m[1] & 512)){
			// 기술 부족에보다 중지
			logMiss($id, $name, $comName,"기술 부족");
			return 0;
		}elseif($Hsolarwind == 1){
			logMiss($id, $name, $comName,"우주풍이 불어");
			return 0;
		}
		$land =& $Hspace['land']; $landValue =& $Hspace['landValue']; $dis =& $Hspace['landValue2']; $nation =& $Hspace['nation'];
		$l = $land[$x][$y];
		$tLname = landName($l, $landValue[$x][$y]);
		
		if($kind == $HcomSFood){
			// 우주 식량 발사 수량 1=1만 톤
			if ($arg <= 0) { $arg = 1; }
			$arg *= 100;
			$value = min($arg, $island['food']);
			$island['comsfood'] = $value;

			$island['food'] -= $value;
			$Hspace['food'] += $value;
			logAid($id, 999, $name, $SpaceName, $comName, "$value$HunitFood");
		}elseif(($kind == $HcomSMissileGM) ||
				($kind == $HcomSMissilePP) ||
				($kind == $HcomSMissile) ||
				($kind == $HcomSMissileMGM)){
			// 우주 미사일 발사
			$bx = null; $by = null; $tx = null; $ty = null; $err = null;
			list($count, $flag) = array(0,0);
			if($kind == $HcomSMissileMGM){
				$arg = 1;
			}else{
				if ($arg <= 0) { $arg = 10000; }
			}
			
			// 오차
			if($kind == $HcomSMissile){
				$err = 19;
			}elseif($kind == $HcomSMissilePP){
				$err = 7;
			}else{
				$err = 1;
			}
			// 전쟁 모드에서는 돈의 대신에 병기를 소비
			$mcost = 'money';
			if(($HwarFlg) && ($cost < 500)){
				$mcost = 'weapon';
				$cost = intval($cost / 10);
			}
			list($msCt,$mslogCtM,$mslogCtW,$mslogCtD) = array(0,0,0,0);
			while(($arg > 0) && ($island[$mcost] >= $cost)){
				//  기지를 찾아낼 때까지 루프
				while($count < $HpointNumber){
					$bx = $Hrpx[$count];
					$by = $Hrpy[$count];
					if (($land[$bx][$by] == $HlandSpaceBase) && ($nation[$bx][$by] == $id)) { break; }
					$count++;
				}
				if ($count >= $HpointNumber) { break; }
				// 최저1개 기지가 있었으므로, flag를 세운다
				$flag = 1;
				
				// 기지의 레벨을 산출
				$level = expToLevel($land[$bx][$by], $landValue[$bx][$by]);
				// 기지내에서 루프
				while(($level > 0) && ($island[$mcost] > $cost)){
					if ($arg <= 0) { break; }
					$level--;
					$arg--;
					$msCt++; # 발사수를 계산
					if($kind == $HcomSMissileMGM){ # 수 유도탄때
						$Mcount = null;
						for($Mcount = 0; $Mcount < $HpointNumber; $Mcount++){
							$x = $Hrpx[$Mcount];
							$y = $Hrpy[$Mcount];
							if($land[$x][$y] == $HlandMonster){
								$special = $HmonsterSpecial[hako_pick(monsterSpec($landValue[$x][$y]), array(0))];
								if((($special == 3) && (($HislandTurn % 2) == 1)) ||
								   (($special == 4) && (($HislandTurn % 2) == 0))){
			//								(($special == 4) && (($HislandTurn % 2) == 0)) ||
			//								($special == 5)){
								}else{
break;
								}
							}
						}
						if($Mcount >= $HpointNumber){
							logMiss($id, $name, $comName, "적당한 괴수가 없었다");
							return 0;
						}
						$HdefenceSpace[$id][$x][$y] = 1;
					}elseif(random(2) == 0){
						// 50%로 제외한다
						$mslogCtW++;
continue;
					}
					$island[$mcost] -= $cost;
					
					// 착탄점산출
					$r = random($err);
					$tx = $x + $ax[$r];
					$ty = $y + $ay[$r];
					if (!($ty % 2) && ($y % 2)) { $tx--; }
					
					// 착탄점범위내외 체크
					if(($tx < 0) || ($tx >= $HislandSize) || ($ty < 0) || ($ty >= $HislandSize)){
						$mslogCtM++;
continue;
					}
					
					// 착탄점의 지형등 산출
					list($tL, $tLv, $tId) = array($land[$tx][$ty], $landValue[$tx][$ty], $nation[$tx][$ty]);
					list($tLname, $tPoint) = array(landName($tL, $tLv), "($tx, $ty)");
					// 소유 이름를 부가
					if($tId > 0){
						$tn = $HidToNumber[$tId];
						$tIsland =& $Hislands[$tn];
						$tName = $tIsland['name'];
						if ($tName != '') { $tLname .= "(${tName}${AfterName})"; }
					}
					
					// 방위 시설 판정
					if($HdefenceSpace[$id][$tx][$ty] != 1){
						$i = null; $sx = null; $sy = null;
						if($tL == $HlandSDefence){
							$HdefenceSpace[$id][$tx][$ty] = 1;
						}else{
							for($i = 1; $i < 19; $i++){
								$sx = $x + $ax[$i];
								$sy = $y + $ay[$i];
								if (!($sy % 2) && ($y % 2)) { $sx--; }
								if(($sx < 0) || ($sx >= $HislandSize) || ($sy < 0) || ($sy >= $HislandSize)){
								}elseif($land[$sx][$sy] == $HlandSDefence){
									if(($tId == $nation[$sx][$sy]) ||
										($tId == 0) || ($nation[$sx][$sy] == 0)){
break;
									}
								}
							}
							if($i < 19){
								// 요격
								$mslogCtD++;
continue;
							}else{
								HdebugOut("SA　$id　$tx　$ty");
								$HdefenceSpace[$id][$tx][$ty] = 1;
							}
						}
					}
					
					if($tL == $HlandSunit){
						if($tLv < 10){
							// 파괴
							logMsSpace($id, $tPoint, $tLname, "티끌이 되어", 999);
							$land[$tx][$ty] = $HlandSea;
							$landValue[$tx][$ty] = 0;
							$dis[$tx][$ty] = 0;
						}else{
							logMsSpace($id, $tPoint, $tLname, "파괴되고", 999);
							$landValue[$tx][$ty] = 20;
						}
						$nation[$tx][$ty] = 0;
					}elseif (($tL == $HlandSCity) ||
							($tL == $HlandSFarm) ||
							($tL == $HlandSFactory) ||
							($tL == $HlandSDefence) ||
							($tL == $HlandSAEisei) ||
							($tL == $HlandSpaceBase)){
						list($a,$b,$e) = array(10,10,0);
						if($tL == $HlandSCity){
							$a = random(40) + 10;
						}elseif($tL == $HlandSFarm){
							$a = 5;
						}elseif($tL == $HlandSFactory){
							$a = 10;
							$b = 30;
						}elseif($tL == $HlandSAEisei){
							$a = 40;
							$b = 10;
							$e = intval($landValue[$tx][$ty] / 1000);
							$landValue[$tx][$ty] -= $e * 1000;
						}
						$landValue[$tx][$ty] -= $a;
						if($landValue[$tx][$ty] < $b){
							logMsSpace($id, $tPoint, $tLname, "파괴되고", 999);
							$land[$tx][$ty] = $HlandSunit;
							$landValue[$tx][$ty] = 10;
							$dis[$tx][$ty] = 0;
							$nation[$tx][$ty] = 0;
						}else{
							logMsSpace($id, $tPoint, $tLname, "피해가 감소", 999);
							$dis[$tx][$ty] += 8;
							if(random(5) == 0){
								$nation[$tx][$ty] = 0;
							}
							if ($tL == $HlandSAEisei) { $landValue[$tx][$ty] += $e * 1000; }
						}
						// 경험치
						if($land[$bx][$by] == $HlandSpaceBase){
							$dis[$bx][$by] -= 6;
							$landValue[$bx][$by] += 2;
							$island['allex'] += 2;
							if ($landValue[$bx][$by] > $HmaxExpPoint) { $landValue[$bx][$by] = $HmaxExpPoint; }
						}
					}elseif($tL == $HlandMonster){
						// 괴수
						list($mKind, $mName, $mHp) = monsterSpec($tLv);
						$special = $HmonsterSpecial[$mKind];
						if($mHp <= 1){
							
							logMsMonKillSpace($id, $name, $tPoint, $mName, 999);
							
							// 괴수 쏘아 죽였을 때의 경험치
							if($land[$bx][$by] == $HlandSpaceBase){
								$dis[$bx][$by] -= 6;
								$landValue[$bx][$by] += $HmonsterExp[$mKind];
								$island['allex'] += $HmonsterExp[$mKind]; # 경험치총획득 건수
								if ($landValue[$bx][$by] > $HmaxExpPoint) { $landValue[$bx][$by] = $HmaxExpPoint; }
							}

							$island['displus'] = 200;

							// 괴수먹이 취득 플래그를 세운다
							$island['esa'] = $mKind;

							// 괴수를 지운다
							$land[$tx][$ty] = $HlandSea;
							$landValue[$tx][$ty] = 0;
							$nation[$tx][$ty] = 0;

							// 괴수의 상관계
							monstersPrize($mKind,$island);

							// 수입
							$value = $HmonsterValue[$mKind];
							if($value > 0) {
								$island['money'] += $value;
								logMsMonMoney($id, $mName, $value);
							}
						}else{
							// 괴수 살아 있다
							logMsMonSpace($id, $tPoint, $mName, 999);
							// HP가  1줄어든다
							$landValue[$tx][$ty]--;
continue;
						}
					}elseif($tL == $HlandEarth){
						// 지구
						$mslogCtM++;
						$nation[$tx][$ty] = 0;
					}else{
						$mslogCtM++;
						$land[$tx][$ty] = $HlandSea;
						$landValue[$tx][$ty] = 0;
						$nation[$tx][$ty] = 0;
					}
				}
				$count++;
			}
			if($flag == 0){
				logMsMiss($id, $name, $comName);
				return 0;
			}
			logMissileSpace($id, $name, $comName, $point, $msCt, $msCt - $mslogCtM - $mslogCtW - $mslogCtD, $mslogCtM, $mslogCtW, $mslogCtD, $SpaceName, 999);
			return 1;
		}elseif($kind == $HcomSOccupy){
			// 우주 점령
			if (($nation[$x][$y] != $id) && (
				($l == $HlandSunit) ||
				($l == $HlandSCity) ||
				($l == $HlandSFarm) ||
				($l == $HlandSFactory) ||
				($l == $HlandSpaceBase) ||
				($l == $HlandSAEisei) ||
				($l == $HlandSDefence))){
			}else{
				// 점령 불가
				logMissS($id, $name, $comName, $point,"점령할 수 없는 지형의");
				return 0;
			}
			$count = 1;
			if($nation[$x][$y] > 0){
				$i = null; $sx = null; $sy = null;
				for($i = 1; $i < 7; $i++){
					$sx = $x + $ax[$i];
					$sy = $y + $ay[$i];
					if (!($sy % 2) && ($y % 2)) { $sx--; }
					if(($sx < 0) || ($sx >= $HislandSize) || ($sy < 0) || ($sy >= $HislandSize)){
					}elseif (($nation[$sx][$sy] > 0) &&
							($nation[$sx][$sy] == $nation[$x][$y])){
						if($land[$sx][$sy] == $HlandSCity){
							logMissS($id, $name, $comName, $point,"점령 조건을 채우지 않는다");
							return 0;
						}else{
							$count++;
						}
					}
				}
				if ($count > 5) { $count = 5; }
			}
			if(random($count) == 0){
				$dis[$x][$y] -= 20;
				logLandSucS($id, $name, $comName, $point);
				$nation[$x][$y] = $id;
			}else{
				$dis[$x][$y] += 20;
				logMissS2($id, $name, $comName, $point,"저항 세력의");
			}
		}else{
			if(($nation[$x][$y] != 0) && ($nation[$x][$y] != $id)){
				logMissS($id, $name, $comName, $point,"소유 이외의");
				return 0;
			}
			if($kind == $HcomSUnit){
				// 우주 유니트 건설
				if(($l != $HlandEarth) && ($l != $HlandMonster)){
					if($l != $HlandSunit){
						$land[$x][$y] = $HlandSunit;
						$landValue[$x][$y] = 0;
					}elseif($landValue[$x][$y] == 0){
						$landValue[$x][$y] = 1;
					}else{
						$landValue[$x][$y] = 10;
					}
				}else{
					logMissS($id, $name, $comName, $point,"건설할 수 없는 지형의");
					return 0;
				}
			}elseif($kind == $HcomSPioneer){
				// 우주 이주
				if(($l == $HlandSunit) && ($landValue[$x][$y] == 10)){
					$land[$x][$y] = $HlandSCity;
					$landValue[$x][$y] = 1;
				}elseif($l == $HlandSCity){
					$landValue[$x][$y] += 30;
				}else{
					logMissS($id, $name, $comName, $point,"건설할 수 없는 지형의");
					return 0;
				}
			}elseif($kind == $HcomSDestroy){
				// 우주 유니트 파괴
				if($l != $HlandEarth){
					$land[$x][$y] = $HlandSea;
					$landValue[$x][$y] = 0;
				}else{
					logMissS($id, $name, $comName, $point,"건설할 수 없는 지형의");
					return 0;
				}
				$island['money'] -= $cost;
				logLandSucS($id, $name, $comName, $point);
				if($nation[$x][$y] == $id) {
					// 자도의 경우는 턴 소비 없음
					$nation[$x][$y] = 0;
					return 0;
				}else{
					return 1;
				}
			}elseif($kind == $HcomSpaceFarm){
				// 우주 농장 건설
				if($l == $HlandSFarm){
					$landValue[$x][$y] += 5; # 규모 + 5000
					if ($landValue[$x][$y] > 50) { $landValue[$x][$y] = 50; }
				}elseif((($l == $HlandSunit) && ($landValue[$x][$y] == 10)) || ($l == $HlandSCity)){
					$land[$x][$y] = $HlandSFarm;
					$landValue[$x][$y] = 10; # 규모 10000
				}else{
					logMissS($id, $name, $comName, $point,"건설할 수 없는 지형의");
					return 0;
				}
			}elseif($kind == $HcomSFactory){
				// 우주 공장 건설
				if($l == $HlandSFactory){
					$landValue[$x][$y] += 10; # 규모 + 10000
					if ($landValue[$x][$y] > 100) { $landValue[$x][$y] = 100; }
				}elseif((($l == $HlandSunit) && ($landValue[$x][$y] == 10)) || ($l == $HlandSCity)){
					$land[$x][$y] = $HlandSFactory;
					$landValue[$x][$y] = 30; # 규모 30000
				}else{
					logMissS($id, $name, $comName, $point,"건설할 수 없는 지형의");
					return 0;
				}
			}elseif($kind == $HcomSEisei){
				// 우주 위성 건설
				if ($arg < 0) { $arg = 0; }
				if ($arg > 5) { $arg = 5; }
				if($island['sfactory'] > 0){
					if($l == $HlandSAEisei){
						// 추가 건설
						$arg = intval($landValue[$x][$y] / 1000);
						$landValue[$x][$y] += 75;
						if ($landValue[$x][$y] % 1000 > 200) { $landValue[$x][$y] = $arg * 1000 + 200; }
					}elseif((($l == $HlandSunit) && ($landValue[$x][$y] == 10)) || ($l == $HlandSCity)){
						// 신규 건설
						$land[$x][$y] = $HlandSAEisei;
						$landValue[$x][$y] = $arg * 1000 + 100;
					}else{
						logMissS($id, $name, $comName, $point,"건설할 수 없는 지형의");
						return 0;
					}
					$comName .= "(" . $HsEisei[$arg] . ")";
				}else{
					logMissS($id, $name, $comName, $point,"자재 부족");
					return 0;
				}
			}elseif($kind == $HcomSpaceBase){
				// 우주 미사일 기지 건설
				if($island['sfactory'] > 0){
					if($l == $HlandSpaceBase){
						$landValue[$x][$y] += 4;
						if ($landValue[$x][$y] > $HmaxExpPoint) { $landValue[$x][$y] = $HmaxExpPoint; }
					}elseif((($l == $HlandSunit) && ($landValue[$x][$y] == 10)) || ($l == $HlandSCity)){
						// 우주 미사일 기지
						$land[$x][$y] = $HlandSpaceBase;
						$landValue[$x][$y] = 0;
					}else{
						logMissS($id, $name, $comName, $point,"건설할 수 없는 지형의");
						return 0;
					}
				}else{
					logMissS($id, $name, $comName, $point,"자재 부족");
					return 0;
				}
			}elseif($kind == $HcomSDbase){
				// 우주 방위 시설
				if((($l == $HlandSunit) && ($landValue[$x][$y] == 10)) || ($l == $HlandSCity)){
					$land[$x][$y] = $HlandSDefence;
					$landValue[$x][$y] = 0;
				}else{
					logMissS($id, $name, $comName, $point,"건설할 수 없는 지형의");
					return 0;
				}
			}elseif($kind == $HcomSBuild){
				// 우주 건설계
			//	if($arg <= 0){
			//	}else{
			//	}
				return 0;
			}
			$dis[$x][$y] -= 30;
			logLandSucS($id, $name, $comName, $point);
			$nation[$x][$y] = $id;
//			HdebugOut("소유 변경:list($x,$y) = ${id}");
		}
		$island['money'] -= $cost;
		// 회수 첨부라면, 커멘드를 되돌린다
		if(($kind == $HcomSUnit) ||
			($kind == $HcomSpaceFarm) ||
			($kind == $HcomSFactory) ||
			($kind == $HcomSpaceBase)){
			if($arg > 1){
				$arg--;
				slideBack($comArray, $cNo, $kind, $target, $x, $y, $arg);
			}
		}
		return 1;
		
	}elseif(($kind == $HcomOMissilePP) ||
			($kind == $HcomOMissileSPP) ||
			($kind == $HcomOMissileNM)){




			// 해역 미사일 발사
			
			$bx = null; $by = null; $tx = null; $ty = null; $err = null;
			list($count, $flag) = array(0,0);
		//	if($kind == $HcomOMissileMGM){
		//		$arg = 1;
		//	}else{
				if ($arg <= 0) { $arg = 10000; }
		//	}
			
			// 오차
			if($kind == $HcomOMissileNM){
				$err = 19;
			}elseif($kind == $HcomOMissileSPP){
				$err = 8;
			}elseif($kind == $HcomOMissilePP){
				$err = 7;
			}else{

				$err = 1;
			}
			// 전쟁 모드에서는 돈의 대신에 병기를 소비
			$mcost = 'money';
			if(($HwarFlg) && ($cost < 500)){
				$mcost = 'weapon';
				$cost = intval($cost / 10);
			}
			list($msCt,$mslogCtM,$mslogCtW,$mslogCtD) = array(0,0,0,0);
			while(($arg > 0) && ($island[$mcost] >= $cost)){
				// 기지를 찾아낼 때까지 루프
				while($count < $HpointNumber){
					$bx = $Hrpx[$count];
					$by = $Hrpy[$count];
					if ((($land[$bx][$by] == $HlandDefence) && ($landValue[$bx][$by] == 3)) ||
						($land[$bx][$by] == $HlandBase) || ($land[$bx][$by] == $HlandSbase) || ($land[$bx][$by] == $HlandDokan)) { break; }
					$count++;
				}
				if ($count >= $HpointNumber) { break; }
				
				// 최저1개 기지가 있었으므로, flag를 세운다
				$flag = 1;
				// 기지의 레벨을 산출
				$level = expToLevel($land[$bx][$by], $landValue[$bx][$by]);
				// 기지내에서 루프
				while(($level > 0) && ($island[$mcost] > $cost)){
					if ($arg <= 0) { break; }
					$level--;
					$arg--;
					$msCt++; # 발사수를 계산
					$island[$mcost] -= $cost;
					
					// 착탄점산출
					$r = random($err);
					if (($kind == $HcomOMissileSPP) && ($r == 7)) { $r = 0; }
					$tx = $x + $ax[$r];
					$ty = $y + $ay[$r];
					if (!($ty % 2) && ($y % 2)) { $tx--; }
					
					//  착탄점범위내외 체크
					if(($tx < 0) || ($tx >= $HoceanSize) || ($ty < 0) || ($ty >= $HoceanSize)){
						$mslogCtM++;
continue;
					}
					// 착탄점의 지형등 산출
					$tLand =& $Hocean['land']; $tLandValue =& $Hocean['landValue']; $tLandValue2 =& $Hocean['landValue2']; $tNation =& $Hocean['nation'];
					list($tL, $tLv, $tLv2, $tId) = array($tLand[$tx][$ty], $tLandValue[$tx][$ty], $tLandValue2[$tx][$ty], $tNation[$tx][$ty]);
					list($tLname, $tPoint) = array(landName($tL, $tLv), "($tx, $ty)");
					unset($tIsland); $tIsland = null; $tName = null;
					// 소유 이름를 부가
					if($tId > 0){
						$tn = $HidToNumber[$tId];
						$tIsland =& $Hislands[$tn];
						$tName = $tIsland['name'];
						if ($tName != '') { $tLname .= "(${tName}${AfterName})"; }
					}
					if($tL == $HlandOPlayer){
						if(($tIsland['turnsu'] + $tIsland['evil'] < $HdisUN) || ($tIsland['evil'] == 0)){
							// 상대가 도상국
							$mslogCtD++; # 공중 폭파
						}elseif($tLv2 <= 0){
							logMsOPlayer($id, $tPoint, $tLname, 888);
							if(random(100) == 0){
								$tIsland['bigmissile']++;
							}else{
								$tIsland['Meteo'] += 5;
							}
						}else{
							$tLandValue2[$tx][$ty]--;
							$mslogCtD++; #  공중 폭파
						}
					}elseif($tL == $HlandOcean){
						$mslogCtD++; #  공중 폭파
					}elseif($tL == $HlandMonster){
						// 괴수
						list($mKind, $mName, $mHp) = monsterSpec($tLv);
						$special = $HmonsterSpecial[$mKind];
						
						if($mHp <= 1){
							logMsMonKillSpace($id, $name, $tPoint, $mName, 888);
							// 괴수 쏘아 죽였을 때의 경험치
							if(($land[$bx][$by] == $HlandBase) || ($land[$bx][$by] == $HlandSbase)){
								$landValue[$bx][$by] += $HmonsterExp[$mKind];
								$island['allex'] += $HmonsterExp[$mKind]; # 경험치총획득 건수
								if ($landValue[$bx][$by] > $HmaxExpPoint) { $landValue[$bx][$by] = $HmaxExpPoint; }
							}
							$island['displus'] = 200;

							// 괴수먹이 취득 플래그를 세운다
							$island['esa'] = $mKind;

							// 괴수를 지운다
							$tLand[$tx][$ty] = $HlandSea;
							$tLandValue[$tx][$ty] = 0;
							$tNation[$tx][$ty] = 0;

							// 괴수의 상관계
							monstersPrize($mKind,$island);

							// 수입
							$value = $HmonsterValue[$mKind];
							if($value > 0) {
								$value *= 2;
								$island['money'] += $value;
								logMsMonMoney($id, $mName, $value);
							}
						}else{
							// 괴수 살아 있다
							logMsMonSpace($id, $tPoint, $mName, 888);
							// HP가  1줄어든다
							$tLandValue[$tx][$ty]--;
continue;
						}
					}else{
						$mslogCtM++;
						$tLand[$tx][$ty] = $HlandSea;
						$tLandValue[$tx][$ty] = 0;
						$tNation[$tx][$ty] = 0;
					}
				}
				$count++;
			}
			if($flag == 0){
				logMsMiss($id, $name, $comName);
				return 0;
			}
			logMissileSpace($id, $name, $comName, $point, $msCt, $msCt - $mslogCtM - $mslogCtW - $mslogCtD, $mslogCtM, $mslogCtW, $mslogCtD, $OceanName, 888);
			return 1;
	}elseif(($kind == $HcomMonsEgg) || ($kind == $HcomMonsEsa) ||
			($kind == $HcomMonsEnsei) || ($kind == $HcomMonsTettai) ||
			($kind == $HcomMonsEsaAid) || ($kind == $HcomMonsAid) ||
			($kind == $HcomMonsSell) || ($kind == $HcomMonsExer)){
	// 괴수 배틀
		$monster =& $island['monster'];
		list($MBid, $MBname, $MBtId, $MBsId, $MBmId, $MBhp, $MBmhp, $MBstr, $MBdef, $MBagi, $MBskl, $MBwinh, $MBwin, $MBlose) = 
		array(
			$monster[0],
			$monster[1],
			$monster[2],
			$monster[3],
			$monster[4],
			$monster[5],
			$monster[6],
			$monster[7],
			$monster[8],
			$monster[9],
			$monster[10],
			$monster[11],
			$monster[12],
			$monster[13]
		 );
		 
		$mtn = $HidToNumber[$MBtId];
		if($MBid == 0){
			// 자신의 괴수가 없다
		}elseif($id != $MBid){
			// 원정중
			if($mtn == ''){
				$MBid = $id; # 상대가 없어졌으므로 괴수를 자신 도에 되돌린다.
				$MBhp = $MBmhp;
				$MBtId = 0;
			}
		}elseif($mtn == ''){
			$MBid = $id; # 상대가 없기 때문에 괴수를 자신 도에 되돌린다.
			$MBhp = $MBmhp;
			$MBtId = 0;
		}
		
		if($kind == $HcomMonsTettai){
			// 괴수 후퇴
			// 타겟을 자동 지정한다
			$target = $MBtId;
		}
		
		$tn = $HidToNumber[$target];
		if ($tn == '') { return 0; }
		$tIsland =& $Hislands[$tn];
		$tName = $tIsland['name'];
		$tMonster =& $tIsland['monster'];
		list($tMBid, $tMBname, $tMBtId, $tMBsId, $tMBmId, $tMBhp, $tMBmhp, $tMBstr, $tMBdef, $tMBagi, $tMBskl, $tMBwinh, $tMBwin, $tMBlose) = 
		array(
			$tMonster[0],
			$tMonster[1],
			$tMonster[2],
			$tMonster[3],
			$tMonster[4],
			$tMonster[5],
			$tMonster[6],
			$tMonster[7],
			$tMonster[8],
			$tMonster[9],
			$tMonster[10],
			$tMonster[11],
			$tMonster[12],
			$tMonster[13]
		 );
		
		if($kind == $HcomMonsEsaAid){
			// 괴수먹이 양도
			if(($MBsId == 0) || ($tMBsId != 0)){
				// 먹이가 없는 또는, 상대에게 먹이가 있으므로 중지
				logMonsCancel($id, $name, $comName,"먹이가 없는 또는, 타겟에 먹이가 있다");
				return 0;
			}
			$tMBsId = $MBsId;
			logMonsEsaAid($id, $name, $target, $tName, $HmonsterName[$MBsId]);
			$MBsId = 0;
		}else{
			if($MBid == 0){
				// 괴수가 없다
				if($kind == $HcomMonsEgg){
					// 괴수 에그 구입
					logMonsEGG($id, $name, $comName);
					$MBid = $id;
					$MBname = "이노라 (이름 미설정)";
					$MBtId = 0;
					$MBsId = $MBsId;
					$MBmId = 1; # 이노라
					$MBhp = 18 + random(8);
					$MBmhp = $MBhp;
					$MBstr = random(2);
					$MBdef = random(2);
					$MBagi = random(2);
					$MBskl = random(2);
					$MBwinh = 0;
					$MBwin = 0;
					$MBlose = 0;
					$island['money'] -= $cost;
				}else{
					logMonsCancel($id, $name, $comName,"괴수가 없다");
					return 0;
				}
			}else{
				// 괴수가 있다
				
				if($kind != $HcomMonsTettai){
					// 괴수 후퇴 이외
					if(($id != $MBid) || ($MBtId != 0)){
						// 자신의 괴수가 자신 도에 없다
						logMonsCancel($id, $name, $comName,"전투중의");
						return 0;
					}
				}
				
				
				if($kind == $HcomMonsEsa){
					// 괴수에게 먹이를 먹인다
					if($MBsId == 0){
						// 먹이가 없기 때문에 중지
						logMonsCancel($id, $name, $comName,"먹이가 없다");
						return 0;
					}elseif($MBsId == 1){
						//먹이가 이노라
						$MBmId = 1; # 이노라
						logMonsEvo($id, $name, $MBname, $HmonsterName[$MBmId], $comName);
					}else{
						
						$MonGRP = $HmonsterGRP[$MBmId];
						$MonCLS = $HmonsterCLS[$MBmId];
						$EsaMonGRP = $HmonsterGRP[$MBsId];
						$EsaMonCLS = $HmonsterCLS[$MBsId];
						
						if($MonGRP == $EsaMonGRP){
							// 먹이와 같은 그룹의 경우
							if($MonCLS > $EsaMonCLS){
								// 먹이보다 계급이 낮기 때문에 먹이의 괴수에게 진화
								$MBmId = $MBsId;
								logMonsEvo($id, $name, $MBname, $HmonsterName[$MBmId], $comName);
							}else{
								// 계급이 1오른다
								$MonSea = MonSeaCls($MBmId ,1);
								if($MonSea == 0){
									// 실패
									logMonsEvoF($id, $name, $MBname, $comName);
								}else{
									$MBmId = $MonSea;
									logMonsEvo($id, $name, $MBname, $HmonsterName[$MonSea], $comName);
								}
							}
						}else{
							if($MonCLS < $EsaMonCLS){
								// 먹이 쪽의 계급이 1이상 높은 경우
								$MonSea = MonSeaCls($MBsId ,3);
								if($MonSea == 0){
									// 실패
									logMonsEvoF($id, $name, $MBname, $comName);
								}else{
									$MBmId = $MonSea;
									logMonsEvo($id, $name, $MBname, $HmonsterName[$MonSea], $comName);
								}
							}else{
								$MonSea = null;
								if($HmonsterCLS[$MBmId] == 1){
									$MonSea = MonSeaCls($MBsId ,3);
								}else{
									$MonSea = MonSeaCls($MBmId ,2);
								}
								if($MonSea == 0){
									// 실패
									logMonsEvoF($id, $name, $MBname, $comName);
								}else{
									$MBmId = $MonSea;
									logMonsEvo($id, $name, $MBname, $HmonsterName[$MonSea], $comName);
								}
							}
						}
					}
					$MBsId = 0;
					$island['money'] -= $cost;
				}elseif($kind == $HcomMonsEnsei){
					// 괴수 원정
					if($tMBid != $target){
						// 상대에게 괴수가 없는, 원정중 때 무조건으로 중지
						logMonsCancel($id, $name, $comName,"타겟에  괴수가 없거나, 원정중입니다");
						return 0;
					}
					if($tMBtId != 0){
						// 상대가 전투중 때 무조건으로 중지
						logMonsCancel($id, $name, $comName,"타겟이 전투중입니다");
						return 0;
					}
					if($tMBid == $id){
						// 자신 도
						logMonsCancel($id, $name, $comName,"자신 섬입니다");
						return 0;
					}
					logMonsENSEI($id, $name, $target, $tName, $comName);
					$MBid = $target;
					$MBtId = $target;
					$tMBtId = $id;
					$island['money'] -= $cost;
				}elseif($kind == $HcomMonsTettai){
					// 괴수 후퇴
					if($MBid == $id){
						// 자신 도
						if($MBtId == 0){
							// 상대가 없을 때라고 하고 무조건으로 중지
							logMonsCancel($id, $name, $comName,"전투중이 아닙니다");
							return 0;
						}
						$tMBid = $tMBtId;
					}else{
						// 원정중
						$MBid = $MBtId;
						$tMBid = $tMBtId;
					}
					logMonsEND($id, $name, $MBname, $tMBid, "싸움으로부터 도망쳤습니다.");
					logMonsEND($tMBid, $tName, $tMBname, $id, "싸워 승리했습니다.");
					$MBtId = 0;
					$tMBtId = 0;
					$MBhp = $MBmhp;
					$tMBhp = $tMBmhp;
					$tMBwinh++; # 괴수배용
					$tMBwin++;
					$MBlose++;
				}elseif($kind == $HcomMonsAid){
					// 괴수 양도
					if(($tMBid != 0) || ($tMBtId != 0)){
						// 상대에게 이미 괴수가 있을 때 무조건으로 중지
						logMonsCancel($id, $name, $comName,"타겟에  이미 괴수가 있습니다");
						return 0;
					}
					logMonsAid($id, $name,$target, $tName);
					$tMBid = $target;
					$tMBname = $MBname;
					$tMBtId = 0;
			//		$tMBsId = 0;
					$tMBmId = $MBmId;
					$tMBhp = $MBhp;
					$tMBmhp = $MBmhp;
					$tMBstr = $MBstr;
					$tMBdef = $MBdef;
					$tMBagi = $MBagi;
					$tMBskl = $MBskl;
					$tMBwinh = $MBwinh;
					$tMBwin = $MBwin;
					$tMBlose = $MBlose;
					
					$MBid = 0;
					$MBname = "";
					$MBtId = 0;
			//		$MBsId = 0;
					$MBmId = 0;
					$MBhp = 0;
					$MBmhp = 0;
					$MBstr = 0;
					$MBdef = 0;
					$MBagi = 0;
					$MBskl = 0;
					$MBwinh = 0;
					$MBwin = 0;
					$MBlose = 0;
				}elseif($kind == $HcomMonsSell){
					// 괴수 매각
					logMonsSell($id, $name, $comName);
					$island['money'] += ($MBwin + 1) * 1000;
					$MBid = 0;
					$MBname = "";
					$MBtId = 0;
			//		$MBsId = 0;
					$MBmId = 0;
					$MBhp = 0;
					$MBmhp = 0;
					$MBstr = 0;
					$MBdef = 0;
					$MBagi = 0;
					$MBskl = 0;
					$MBwinh = 0;
					$MBwin = 0;
					$MBlose = 0;
				}elseif($kind == $HcomMonsExer){
					// 괴수 모의 훈련
					if($MBsId == 0){
						// 먹이가 없기 때문에 중지
						logMonsCancel($id, $name, $comName,"먹이가 없습니다.");
						return 0;
					}
					logMonsExer($id, $name, $comName);
					$island['money'] -= $cost;
					$er = random(10);
					if($er < 3){
						$MBstr++;
					}elseif ($er < 4){
						$MBdef++;
					}elseif ($er < 7){
						$MBagi++;
					}else{
						$MBskl++;
					}
					$MBsId = 0;
				}
			}
		}
		
		$wmonster = array($MBid,$MBname,$MBtId,$MBsId,$MBmId,$MBhp,$MBmhp,$MBstr,$MBdef,$MBagi,$MBskl,$MBwinh,$MBwin,$MBlose);
		$island['monster'] = $wmonster;

		if($id != $target){
			$wtMonster = array($tMBid,$tMBname,$tMBtId,$tMBsId,$tMBmId,$tMBhp,$tMBmhp,$tMBstr,$tMBdef,$tMBagi,$tMBskl,$tMBwinh,$tMBwin,$tMBlose);
			$tIsland['monster'] = $wtMonster;
		}
		
		if(($kind == $HcomMonsEgg) || ($kind == $HcomMonsEsa) || ($kind == $HcomMonsExer)){
			return 1;
		}
		return 0;
	}
	return 1;
} # doCommand()

// 괴수 배틀용
// 1개 계급이 위의 괴수를 요구한다
function MonSeaCls($monid, $pattern) {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $H_tagName2, $Haidpop, $Hallyflg, $Hallygroup, $haribote, $Hatkturn, $HbackupTimes, $HbackupTurn, $HbgInfoCell, $HbgTitleCell, $HbigcityFood, $HbigCityMFlg, $HcomBank, $HcomBase, $HcomBioMissile, $HcomBreakwater, $Hcomcolony, $HcomcolonyTurn, $HcomCost, $HcomDbase, $HcomDeathtrap, $HcomDestroy, $HcomDestroy2, $HcomDokan, $HcomDoNothing, $HcomDummy, $HcomEmigration, $HcomFactory, $HcomFarm, $HcomFire, $HcomFlower, $HcomFood, $HcomGiveup, $HcomHaribote, $HcomHospital, $HcomL, $HcommandMax, $HcomManipulate, $HcomMissileDM, $HcomMissileGM, $HcomMissileLD, $HcomMissileMGM, $HcomMissileNCM, $HcomMissileNM, $HcomMissilePLD, $HcomMissilePP, $HcomMissileRM, $HcomMissileRNG, $HcomMissileSPP, $HcomMissileSRM, $HcomMissileST, $HcomMoney, $HcomMonsAid, $HcomMonsEgg, $HcomMonsEnsei, $HcomMonsEsa, $HcomMonsEsaAid, $HcomMonsExer, $HcomMonsSell, $HcomMonsTettai, $HcomMonument, $HcomMountain, $HcomMyhome, $HcomName, $HcomOilBuy, $HcomOilSell, $HcomOMissileMGM, $HcomOMissileNM, $HcomOMissilePP, $HcomOMissileSPP, $HcomOreBuy, $HcomOreSell, $HcomPioneer, $HcomPlant, $HcomPolice, $HcomPort, $HcomPrepare, $HcomPrepare2, $HcomPresent, $HcomPresentAid, $HcomPropaganda, $HcomReclaim, $HcomReclaim2, $HcomSbase, $HcomSBuild, $HcomScity, $HcomSDbase, $HcomSDestroy, $HcomSearch, $HcomSEisei, $HcomSell, $HcomSellTree, $HcomSendMonster, $HcomSendMonsterTurn, $HcomSFactory, $HcomSFarm, $HcomSFood, $HcomShip, $HcomShipbuild, $HcomShipM, $HcomShipSell, $HcomSMissile, $HcomSMissileGM, $HcomSMissileMGM, $HcomSMissilePP, $HcomSMonument, $HcomSOccupy, $HcomSpaceBase, $HcomSpaceFarm, $HcomSpecialSPP, $HcomSPioneer, $HcomSpy, $HcomSSendMonster, $HcomSSendMonsterTurn, $HcomSTManipulate, $HcomSUnit, $HcomTeisatu, $HcomTower, $HcomTrump, $HcomUg, $HcomWarp, $HcomWeponBuy, $HcomWeponSell, $HcomWindmill, $HconsolationMatch, $HcurrentNumber, $HdBaseAuto, $HdefenceHex, $HdefenceSpace, $HdevelopeTurn, $HdirMode, $HdirName, $HdisAEruption, $HdisAkasio, $HdisBHarvest, $HdisCrime, $HdisEarthquake, $HdisEruption, $HdisFallBorder, $HdisFalldown, $HdisFire, $HdisGHarvest, $Hdishangen, $HdisHugeMeteo, $HdisKLimit, $HdisMaizo, $HdisMeteo, $HdisMonsBorder1, $HdisMonsBorder2, $HdisMonsBorder3, $HdisMonsBorder4, $HdisMonsBorder5, $HdisMonster, $HdisMonsterU, $HdisPirate, $HdisPollution, $HdisSeaMonster, $HdisSHugeMeteo, $HdisSpaceMonster1, $HdisSpaceMonster2, $HdisTinka, $HdisTreasureS, $HdisTsunami, $HdisTyphoon, $HdisUN, $HdisVGHarvest, $HearthAttack, $HeatenFood, $helpDir, $HfightMem, $HfightTurn, $HfinalTurn, $HgiveupTurn, $HhistoryMax, $HidToName, $HidToNumber, $HidToNumberR, $HinterTime, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HlandAegisShip, $HlandAirport, $HlandAmusement, $HlandBalloonS, $HlandBank, $HlandBase, $HlandBigcity, $HlandBreakwater, $HlandCasino, $HlandCoupleRock, $HlandDeathtrap, $HlandDefence, $HlandDokan, $HlandDome, $HlandEarth, $HlandExpo, $HlandFactory, $HlandFarm, $HlandFire, $HlandFishLShip, $HlandFishMShip, $HlandFishSShip, $HlandFlower, $HlandForest, $HlandFuji, $HlandGhostShip, $HlandHaribote, $HlandHospital, $HlandHugecity, $HlandIceFloe, $HlandKInora, $HlandMegacity, $HlandMegaFact, $HlandMegaFarm, $HlandMegatower, $HlandMonsShip, $HlandMonster, $HlandMonument, $HlandMountain, $HlandMyhome, $HlandOcean, $HlandOil, $HlandOPlayer, $HlandOsen, $HlandPark, $HlandPirate, $HlandPlains, $HlandPolice, $HlandPort, $HlandProbeShip, $HlandSAEisei, $HlandSbase, $HlandSchool, $HlandSCity, $HlandSDefence, $HlandSea, $HlandSeisei, $HlandSFactory, $HlandSFarm, $HlandSlum, $HlandSMonument, $HlandSpaceBase, $HlandStadium, $HlandSunit, $HlandTcity, $HlandTitanic, $HlandTower, $HlandTown, $HlandTreasureS, $HlandTrump, $HlandWarp, $HlandWarpR, $HlandWaste, $HlandWindmill, $HlandWingDragon, $HlandZoo, $HlateLogPool, $HlogMax, $HlogOmit2, $HlogPool, $HmaxdisPollution, $HmaxExpPoint, $HmaxIsland, $HmonsBtlMaxHp, $HmonsBtlMaxPa, $HmonsterAGI, $HmonsterBHP, $HmonsterCLS, $HmonsterDEF, $HmonsterDestroy, $HmonsterDHP, $HmonsterExp, $HmonsterGRP, $HmonsterL1, $HmonsterL1Num, $HmonsterL2, $HmonsterL2Num, $HmonsterL3, $HmonsterL3Num, $HmonsterL4, $HmonsterL4Num, $HmonsterL5, $HmonsterL5Num, $HmonsterName, $HmonsterNumber, $HmonsterS, $HmonsterSEI, $HmonsterSKL, $HmonsterSP, $HmonsterSpecial, $HmonsterSTR, $HmonsterValue, $Hmonth, $HmonumentMissile, $HmonumentName, $HmonumentRocket, $Hocean, $HoceanSize, $HoilMoney, $HoilRatio, $hp, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $Hprize, $HprizeV, $HpunishInfo, $HrepeatTurn, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $HseaChk, $HsecretLogPool, $HsEisei, $HshipEX, $HshipFood, $HshipHP, $HshipKAI, $HshipMATK, $HshipMoney, $HshipName, $Hshiporder, $HshipSATK, $HshipSell, $HshipSP, $HsmonumentName, $HsmonumentNumber, $Hsolarwind, $Hspace, $HspaceEfficiency, $HspaceIncome, $Hsstartturn, $HStotalPoint, $HsurvFlg, $Hsurvivalturn, $HtagName2_, $HthisFile, $HtotalBumon, $HtotalMoney, $HtotalPoint, $Htournament, $HtreeValue, $HturnPrizeNumber, $HturnPrizePoint, $HturnPrizeUnit, $HturnPrizeVarious, $HugDokan, $HugFact, $HugFarm, $HugHasigo, $HugKiti, $HugMax, $HugOil, $HugRoad, $HugSpace, $HugTosi, $human, $HunitFood, $HunitMoney, $HunitOil, $HunitOre, $HunitPop, $HunitTime, $HunitWeapon, $HwarFlg, $HWeatherMax, $Hwflg, $HwinFood, $HwinIsland, $HwinMoney, $HwinWeapon, $imageDir, $lockMode, $toppage, $versionInfo;
	$MonsGRP = null; $MonsCLS = null;
	$MonsGRP = $HmonsterGRP[$monid];
	if($pattern == 1){
		// $monid와 같은 그룹의 계급이 1높은 괴수를 찾는다
		$MonsCLS = $HmonsterCLS[$monid] + 1;
	}elseif($pattern == 2){
		// $monid와 같은 그룹의 계급이 1낮은 괴수를 찾는다
		$MonsCLS = $HmonsterCLS[$monid] - 1;
		if($MonsCLS < 1){
			$MonsCLS = 1;
		}
	}else{
		// $monid와 같은 그룹의 계급이 1의 괴수를 찾는다
		$MonsCLS = 1;
	}
	$i = null; $sx = null; $sy = null;
	for($i = 1; $i < $HmonsterNumber; $i++){
		if($MonsGRP == $HmonsterGRP[$i]){
			if($MonsCLS == $HmonsterCLS[$i]){
				return $i;
			}
		}
	}
	return 0;
}

// 괴수의 상관계의 계산
function monstersPrize($mKind, &$island) {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $H_tagName2, $Haidpop, $Hallyflg, $Hallygroup, $haribote, $Hatkturn, $HbackupTimes, $HbackupTurn, $HbgInfoCell, $HbgTitleCell, $HbigcityFood, $HbigCityMFlg, $HcomBank, $HcomBase, $HcomBioMissile, $HcomBreakwater, $Hcomcolony, $HcomcolonyTurn, $HcomCost, $HcomDbase, $HcomDeathtrap, $HcomDestroy, $HcomDestroy2, $HcomDokan, $HcomDoNothing, $HcomDummy, $HcomEmigration, $HcomFactory, $HcomFarm, $HcomFire, $HcomFlower, $HcomFood, $HcomGiveup, $HcomHaribote, $HcomHospital, $HcomL, $HcommandMax, $HcomManipulate, $HcomMissileDM, $HcomMissileGM, $HcomMissileLD, $HcomMissileMGM, $HcomMissileNCM, $HcomMissileNM, $HcomMissilePLD, $HcomMissilePP, $HcomMissileRM, $HcomMissileRNG, $HcomMissileSPP, $HcomMissileSRM, $HcomMissileST, $HcomMoney, $HcomMonsAid, $HcomMonsEgg, $HcomMonsEnsei, $HcomMonsEsa, $HcomMonsEsaAid, $HcomMonsExer, $HcomMonsSell, $HcomMonsTettai, $HcomMonument, $HcomMountain, $HcomMyhome, $HcomName, $HcomOilBuy, $HcomOilSell, $HcomOMissileMGM, $HcomOMissileNM, $HcomOMissilePP, $HcomOMissileSPP, $HcomOreBuy, $HcomOreSell, $HcomPioneer, $HcomPlant, $HcomPolice, $HcomPort, $HcomPrepare, $HcomPrepare2, $HcomPresent, $HcomPresentAid, $HcomPropaganda, $HcomReclaim, $HcomReclaim2, $HcomSbase, $HcomSBuild, $HcomScity, $HcomSDbase, $HcomSDestroy, $HcomSearch, $HcomSEisei, $HcomSell, $HcomSellTree, $HcomSendMonster, $HcomSendMonsterTurn, $HcomSFactory, $HcomSFarm, $HcomSFood, $HcomShip, $HcomShipbuild, $HcomShipM, $HcomShipSell, $HcomSMissile, $HcomSMissileGM, $HcomSMissileMGM, $HcomSMissilePP, $HcomSMonument, $HcomSOccupy, $HcomSpaceBase, $HcomSpaceFarm, $HcomSpecialSPP, $HcomSPioneer, $HcomSpy, $HcomSSendMonster, $HcomSSendMonsterTurn, $HcomSTManipulate, $HcomSUnit, $HcomTeisatu, $HcomTower, $HcomTrump, $HcomUg, $HcomWarp, $HcomWeponBuy, $HcomWeponSell, $HcomWindmill, $HconsolationMatch, $HcurrentNumber, $HdBaseAuto, $HdefenceHex, $HdefenceSpace, $HdevelopeTurn, $HdirMode, $HdirName, $HdisAEruption, $HdisAkasio, $HdisBHarvest, $HdisCrime, $HdisEarthquake, $HdisEruption, $HdisFallBorder, $HdisFalldown, $HdisFire, $HdisGHarvest, $Hdishangen, $HdisHugeMeteo, $HdisKLimit, $HdisMaizo, $HdisMeteo, $HdisMonsBorder1, $HdisMonsBorder2, $HdisMonsBorder3, $HdisMonsBorder4, $HdisMonsBorder5, $HdisMonster, $HdisMonsterU, $HdisPirate, $HdisPollution, $HdisSeaMonster, $HdisSHugeMeteo, $HdisSpaceMonster1, $HdisSpaceMonster2, $HdisTinka, $HdisTreasureS, $HdisTsunami, $HdisTyphoon, $HdisUN, $HdisVGHarvest, $HearthAttack, $HeatenFood, $helpDir, $HfightMem, $HfightTurn, $HfinalTurn, $HgiveupTurn, $HhistoryMax, $HidToName, $HidToNumber, $HidToNumberR, $HinterTime, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HlandAegisShip, $HlandAirport, $HlandAmusement, $HlandBalloonS, $HlandBank, $HlandBase, $HlandBigcity, $HlandBreakwater, $HlandCasino, $HlandCoupleRock, $HlandDeathtrap, $HlandDefence, $HlandDokan, $HlandDome, $HlandEarth, $HlandExpo, $HlandFactory, $HlandFarm, $HlandFire, $HlandFishLShip, $HlandFishMShip, $HlandFishSShip, $HlandFlower, $HlandForest, $HlandFuji, $HlandGhostShip, $HlandHaribote, $HlandHospital, $HlandHugecity, $HlandIceFloe, $HlandKInora, $HlandMegacity, $HlandMegaFact, $HlandMegaFarm, $HlandMegatower, $HlandMonsShip, $HlandMonster, $HlandMonument, $HlandMountain, $HlandMyhome, $HlandOcean, $HlandOil, $HlandOPlayer, $HlandOsen, $HlandPark, $HlandPirate, $HlandPlains, $HlandPolice, $HlandPort, $HlandProbeShip, $HlandSAEisei, $HlandSbase, $HlandSchool, $HlandSCity, $HlandSDefence, $HlandSea, $HlandSeisei, $HlandSFactory, $HlandSFarm, $HlandSlum, $HlandSMonument, $HlandSpaceBase, $HlandStadium, $HlandSunit, $HlandTcity, $HlandTitanic, $HlandTower, $HlandTown, $HlandTreasureS, $HlandTrump, $HlandWarp, $HlandWarpR, $HlandWaste, $HlandWindmill, $HlandWingDragon, $HlandZoo, $HlateLogPool, $HlogMax, $HlogOmit2, $HlogPool, $HmaxdisPollution, $HmaxExpPoint, $HmaxIsland, $HmonsBtlMaxHp, $HmonsBtlMaxPa, $HmonsterAGI, $HmonsterBHP, $HmonsterCLS, $HmonsterDEF, $HmonsterDestroy, $HmonsterDHP, $HmonsterExp, $HmonsterGRP, $HmonsterL1, $HmonsterL1Num, $HmonsterL2, $HmonsterL2Num, $HmonsterL3, $HmonsterL3Num, $HmonsterL4, $HmonsterL4Num, $HmonsterL5, $HmonsterL5Num, $HmonsterName, $HmonsterNumber, $HmonsterS, $HmonsterSEI, $HmonsterSKL, $HmonsterSP, $HmonsterSpecial, $HmonsterSTR, $HmonsterValue, $Hmonth, $HmonumentMissile, $HmonumentName, $HmonumentRocket, $Hocean, $HoceanSize, $HoilMoney, $HoilRatio, $hp, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $Hprize, $HprizeV, $HpunishInfo, $HrepeatTurn, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $HseaChk, $HsecretLogPool, $HsEisei, $HshipEX, $HshipFood, $HshipHP, $HshipKAI, $HshipMATK, $HshipMoney, $HshipName, $Hshiporder, $HshipSATK, $HshipSell, $HshipSP, $HsmonumentName, $HsmonumentNumber, $Hsolarwind, $Hspace, $HspaceEfficiency, $HspaceIncome, $Hsstartturn, $HStotalPoint, $HsurvFlg, $Hsurvivalturn, $HtagName2_, $HthisFile, $HtotalBumon, $HtotalMoney, $HtotalPoint, $Htournament, $HtreeValue, $HturnPrizeNumber, $HturnPrizePoint, $HturnPrizeUnit, $HturnPrizeVarious, $HugDokan, $HugFact, $HugFarm, $HugHasigo, $HugKiti, $HugMax, $HugOil, $HugRoad, $HugSpace, $HugTosi, $human, $HunitFood, $HunitMoney, $HunitOil, $HunitOre, $HunitPop, $HunitTime, $HunitWeapon, $HwarFlg, $HWeatherMax, $Hwflg, $HwinFood, $HwinIsland, $HwinMoney, $HwinWeapon, $imageDir, $lockMode, $toppage, $versionInfo;
	$prize = $island['prize'];
	preg_match('/([0-9]*),([0-9]*),(.*)/', $prize, $_m);
	list($flags,$monsters,$turns) = array($_m[1],$_m[2],$_m[3]);
	$i = null; $f = null;
	$monsters2 = $monsters;
	for($i = $HmonsterNumber-1; $i >= 0; $i--){
		$f = pow(2, $i);
		if($monsters2 >= $f){
			$monsters2 -= $f;
		}elseif($i == $mKind){
			$monsters += $f;
break;
		}
	}
	$island['prize'] = "$flags,$monsters,$turns";
}

//CL 턴 차이 명령
function doCommandLate() {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $H_tagName2, $Haidpop, $Hallyflg, $Hallygroup, $haribote, $Hatkturn, $HbackupTimes, $HbackupTurn, $HbgInfoCell, $HbgTitleCell, $HbigcityFood, $HbigCityMFlg, $HcomBank, $HcomBase, $HcomBioMissile, $HcomBreakwater, $Hcomcolony, $HcomcolonyTurn, $HcomCost, $HcomDbase, $HcomDeathtrap, $HcomDestroy, $HcomDestroy2, $HcomDokan, $HcomDoNothing, $HcomDummy, $HcomEmigration, $HcomFactory, $HcomFarm, $HcomFire, $HcomFlower, $HcomFood, $HcomGiveup, $HcomHaribote, $HcomHospital, $HcomL, $HcommandMax, $HcomManipulate, $HcomMissileDM, $HcomMissileGM, $HcomMissileLD, $HcomMissileMGM, $HcomMissileNCM, $HcomMissileNM, $HcomMissilePLD, $HcomMissilePP, $HcomMissileRM, $HcomMissileRNG, $HcomMissileSPP, $HcomMissileSRM, $HcomMissileST, $HcomMoney, $HcomMonsAid, $HcomMonsEgg, $HcomMonsEnsei, $HcomMonsEsa, $HcomMonsEsaAid, $HcomMonsExer, $HcomMonsSell, $HcomMonsTettai, $HcomMonument, $HcomMountain, $HcomMyhome, $HcomName, $HcomOilBuy, $HcomOilSell, $HcomOMissileMGM, $HcomOMissileNM, $HcomOMissilePP, $HcomOMissileSPP, $HcomOreBuy, $HcomOreSell, $HcomPioneer, $HcomPlant, $HcomPolice, $HcomPort, $HcomPrepare, $HcomPrepare2, $HcomPresent, $HcomPresentAid, $HcomPropaganda, $HcomReclaim, $HcomReclaim2, $HcomSbase, $HcomSBuild, $HcomScity, $HcomSDbase, $HcomSDestroy, $HcomSearch, $HcomSEisei, $HcomSell, $HcomSellTree, $HcomSendMonster, $HcomSendMonsterTurn, $HcomSFactory, $HcomSFarm, $HcomSFood, $HcomShip, $HcomShipbuild, $HcomShipM, $HcomShipSell, $HcomSMissile, $HcomSMissileGM, $HcomSMissileMGM, $HcomSMissilePP, $HcomSMonument, $HcomSOccupy, $HcomSpaceBase, $HcomSpaceFarm, $HcomSpecialSPP, $HcomSPioneer, $HcomSpy, $HcomSSendMonster, $HcomSSendMonsterTurn, $HcomSTManipulate, $HcomSUnit, $HcomTeisatu, $HcomTower, $HcomTrump, $HcomUg, $HcomWarp, $HcomWeponBuy, $HcomWeponSell, $HcomWindmill, $HconsolationMatch, $HcurrentNumber, $HdBaseAuto, $HdefenceHex, $HdefenceSpace, $HdevelopeTurn, $HdirMode, $HdirName, $HdisAEruption, $HdisAkasio, $HdisBHarvest, $HdisCrime, $HdisEarthquake, $HdisEruption, $HdisFallBorder, $HdisFalldown, $HdisFire, $HdisGHarvest, $Hdishangen, $HdisHugeMeteo, $HdisKLimit, $HdisMaizo, $HdisMeteo, $HdisMonsBorder1, $HdisMonsBorder2, $HdisMonsBorder3, $HdisMonsBorder4, $HdisMonsBorder5, $HdisMonster, $HdisMonsterU, $HdisPirate, $HdisPollution, $HdisSeaMonster, $HdisSHugeMeteo, $HdisSpaceMonster1, $HdisSpaceMonster2, $HdisTinka, $HdisTreasureS, $HdisTsunami, $HdisTyphoon, $HdisUN, $HdisVGHarvest, $HearthAttack, $HeatenFood, $helpDir, $HfightMem, $HfightTurn, $HfinalTurn, $HgiveupTurn, $HhistoryMax, $HidToName, $HidToNumber, $HidToNumberR, $HinterTime, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HlandAegisShip, $HlandAirport, $HlandAmusement, $HlandBalloonS, $HlandBank, $HlandBase, $HlandBigcity, $HlandBreakwater, $HlandCasino, $HlandCoupleRock, $HlandDeathtrap, $HlandDefence, $HlandDokan, $HlandDome, $HlandEarth, $HlandExpo, $HlandFactory, $HlandFarm, $HlandFire, $HlandFishLShip, $HlandFishMShip, $HlandFishSShip, $HlandFlower, $HlandForest, $HlandFuji, $HlandGhostShip, $HlandHaribote, $HlandHospital, $HlandHugecity, $HlandIceFloe, $HlandKInora, $HlandMegacity, $HlandMegaFact, $HlandMegaFarm, $HlandMegatower, $HlandMonsShip, $HlandMonster, $HlandMonument, $HlandMountain, $HlandMyhome, $HlandOcean, $HlandOil, $HlandOPlayer, $HlandOsen, $HlandPark, $HlandPirate, $HlandPlains, $HlandPolice, $HlandPort, $HlandProbeShip, $HlandSAEisei, $HlandSbase, $HlandSchool, $HlandSCity, $HlandSDefence, $HlandSea, $HlandSeisei, $HlandSFactory, $HlandSFarm, $HlandSlum, $HlandSMonument, $HlandSpaceBase, $HlandStadium, $HlandSunit, $HlandTcity, $HlandTitanic, $HlandTower, $HlandTown, $HlandTreasureS, $HlandTrump, $HlandWarp, $HlandWarpR, $HlandWaste, $HlandWindmill, $HlandWingDragon, $HlandZoo, $HlateLogPool, $HlogMax, $HlogOmit2, $HlogPool, $HmaxdisPollution, $HmaxExpPoint, $HmaxIsland, $HmonsBtlMaxHp, $HmonsBtlMaxPa, $HmonsterAGI, $HmonsterBHP, $HmonsterCLS, $HmonsterDEF, $HmonsterDestroy, $HmonsterDHP, $HmonsterExp, $HmonsterGRP, $HmonsterL1, $HmonsterL1Num, $HmonsterL2, $HmonsterL2Num, $HmonsterL3, $HmonsterL3Num, $HmonsterL4, $HmonsterL4Num, $HmonsterL5, $HmonsterL5Num, $HmonsterName, $HmonsterNumber, $HmonsterS, $HmonsterSEI, $HmonsterSKL, $HmonsterSP, $HmonsterSpecial, $HmonsterSTR, $HmonsterValue, $Hmonth, $HmonumentMissile, $HmonumentName, $HmonumentRocket, $Hocean, $HoceanSize, $HoilMoney, $HoilRatio, $hp, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $Hprize, $HprizeV, $HpunishInfo, $HrepeatTurn, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $HseaChk, $HsecretLogPool, $HsEisei, $HshipEX, $HshipFood, $HshipHP, $HshipKAI, $HshipMATK, $HshipMoney, $HshipName, $Hshiporder, $HshipSATK, $HshipSell, $HshipSP, $HsmonumentName, $HsmonumentNumber, $Hsolarwind, $Hspace, $HspaceEfficiency, $HspaceIncome, $Hsstartturn, $HStotalPoint, $HsurvFlg, $Hsurvivalturn, $HtagName2_, $HthisFile, $HtotalBumon, $HtotalMoney, $HtotalPoint, $Htournament, $HtreeValue, $HturnPrizeNumber, $HturnPrizePoint, $HturnPrizeUnit, $HturnPrizeVarious, $HugDokan, $HugFact, $HugFarm, $HugHasigo, $HugKiti, $HugMax, $HugOil, $HugRoad, $HugSpace, $HugTosi, $human, $HunitFood, $HunitMoney, $HunitOil, $HunitOre, $HunitPop, $HunitTime, $HunitWeapon, $HwarFlg, $HWeatherMax, $Hwflg, $HwinFood, $HwinIsland, $HwinMoney, $HwinWeapon, $imageDir, $lockMode, $toppage, $versionInfo;
	$i = null; $id = null; $kind = null; $target = null; $x = null; $y = null; $arg = null; $x2 = null; $y2 = null;
	for($i = (count($HcomL) - 1); $i >= 0; $i--){
		if($HcomL[$i]['turn'] == $HislandTurn){
			// 실행한다··.
			$id		= $HcomL[$i]['id'];
			$kind	= $HcomL[$i]['kind'];
			$target	= $HcomL[$i]['target'];
			$x		= $HcomL[$i]['x'];
			$y		= $HcomL[$i]['y'];
			$arg	= $HcomL[$i]['arg'];
			$tn = $HidToNumber[$id];
			if ($tn == '') { continue; }
			$tn = $HidToNumber[$target];
			if ($tn == '') { continue; }
			$tIsland =& $Hislands[$tn];
			$tName = $tIsland['name'];
			$island =& $Hislands[$HidToNumber[$id]];
			$name = $island['name'];
			if($kind == $HcomSendMonster){
				if($arg == 1){
					$tIsland['monstersend1']++;
				}elseif($arg == 2){
					$tIsland['monstersend2']++;
				}elseif($arg == 3){
					$tIsland['monstersend3']++;
				}else{
					$tIsland['monstersend']++;
				}
				logEvent($id, $name,"가, 보낸 괴수가 ${HtagName_}${tName}${AfterName}${H_tagName}에 도착한 모양!");
			}elseif($kind == $HcomSSendMonster){
				if ($arg >= $HmonsterNumber) { $arg = $HmonsterNumber - 1; }
				$tIsland['monsEnsei'] = $arg;
				logEvent($id, $name,"가, 보낸 괴수가 ${HtagName_}${tName}${AfterName}${H_tagName}에 도착한 모양!");
			}elseif($kind == $HcomSpy){
				if($arg == 0){
					// 공작원 파견：지진
					$HpunishInfo[$target]['punish'] = 1;
					$HpunishInfo[$target]['x'] = $x;
					$HpunishInfo[$target]['y'] = $y;
				}else{
					logEventP($target, $tName,"($x, $y)","  그리고  대량의 알루미늄 박이 춤추고 있는 모양! 2 헤크스로 미사일 방위 불가.");
					$j = null; $sx = null; $sy = null;
					for($j = 0; $j < 19; $j++){
						$sx = $x + $ax[$j];
						$sy = $y + $ay[$j];
						if (!($sy % 2) && ($y % 2)) { $sx--; }
						if (($sx < 0) || ($sx >= $HislandSize) || ($sy < 0) || ($sy >= $HislandSize)) { continue; }

						$HdefenceHex[$target][$sx][$sy] = -1;
					}
				}
			}elseif($kind == $Hcomcolony){
				// 콜로니 오토시
				if($arg == 2){
					logEvent($id, $name,"가,<B>슈퍼 쉴드(shield) 시스템 2</B>를 발동!");
					$island['SSSystem'] = 1;
					$HdefenceHex[$id] = 1;
					$island['Crime'] = 1;
					$island['money'] -= $cost;
				}else{
					$tIsland['colony']++;
					$tIsland['tunami'] = 2;
					logEvent($id, $name,"가, 강하시킨<B>우주 인공 기지</B>가 결국 ${HtagName_}${tName}${AfterName}${H_tagName}에 추락했습니다.");
				}
			}
		}
	}
}

// 성장 및 단헥스 재해
function doEachHex(&$island) {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $H_tagName2, $Haidpop, $Hallyflg, $Hallygroup, $haribote, $Hatkturn, $HbackupTimes, $HbackupTurn, $HbgInfoCell, $HbgTitleCell, $HbigcityFood, $HbigCityMFlg, $HcomBank, $HcomBase, $HcomBioMissile, $HcomBreakwater, $Hcomcolony, $HcomcolonyTurn, $HcomCost, $HcomDbase, $HcomDeathtrap, $HcomDestroy, $HcomDestroy2, $HcomDokan, $HcomDoNothing, $HcomDummy, $HcomEmigration, $HcomFactory, $HcomFarm, $HcomFire, $HcomFlower, $HcomFood, $HcomGiveup, $HcomHaribote, $HcomHospital, $HcomL, $HcommandMax, $HcomManipulate, $HcomMissileDM, $HcomMissileGM, $HcomMissileLD, $HcomMissileMGM, $HcomMissileNCM, $HcomMissileNM, $HcomMissilePLD, $HcomMissilePP, $HcomMissileRM, $HcomMissileRNG, $HcomMissileSPP, $HcomMissileSRM, $HcomMissileST, $HcomMoney, $HcomMonsAid, $HcomMonsEgg, $HcomMonsEnsei, $HcomMonsEsa, $HcomMonsEsaAid, $HcomMonsExer, $HcomMonsSell, $HcomMonsTettai, $HcomMonument, $HcomMountain, $HcomMyhome, $HcomName, $HcomOilBuy, $HcomOilSell, $HcomOMissileMGM, $HcomOMissileNM, $HcomOMissilePP, $HcomOMissileSPP, $HcomOreBuy, $HcomOreSell, $HcomPioneer, $HcomPlant, $HcomPolice, $HcomPort, $HcomPrepare, $HcomPrepare2, $HcomPresent, $HcomPresentAid, $HcomPropaganda, $HcomReclaim, $HcomReclaim2, $HcomSbase, $HcomSBuild, $HcomScity, $HcomSDbase, $HcomSDestroy, $HcomSearch, $HcomSEisei, $HcomSell, $HcomSellTree, $HcomSendMonster, $HcomSendMonsterTurn, $HcomSFactory, $HcomSFarm, $HcomSFood, $HcomShip, $HcomShipbuild, $HcomShipM, $HcomShipSell, $HcomSMissile, $HcomSMissileGM, $HcomSMissileMGM, $HcomSMissilePP, $HcomSMonument, $HcomSOccupy, $HcomSpaceBase, $HcomSpaceFarm, $HcomSpecialSPP, $HcomSPioneer, $HcomSpy, $HcomSSendMonster, $HcomSSendMonsterTurn, $HcomSTManipulate, $HcomSUnit, $HcomTeisatu, $HcomTower, $HcomTrump, $HcomUg, $HcomWarp, $HcomWeponBuy, $HcomWeponSell, $HcomWindmill, $HconsolationMatch, $HcurrentNumber, $HdBaseAuto, $HdefenceHex, $HdefenceSpace, $HdevelopeTurn, $HdirMode, $HdirName, $HdisAEruption, $HdisAkasio, $HdisBHarvest, $HdisCrime, $HdisEarthquake, $HdisEruption, $HdisFallBorder, $HdisFalldown, $HdisFire, $HdisGHarvest, $Hdishangen, $HdisHugeMeteo, $HdisKLimit, $HdisMaizo, $HdisMeteo, $HdisMonsBorder1, $HdisMonsBorder2, $HdisMonsBorder3, $HdisMonsBorder4, $HdisMonsBorder5, $HdisMonster, $HdisMonsterU, $HdisPirate, $HdisPollution, $HdisSeaMonster, $HdisSHugeMeteo, $HdisSpaceMonster1, $HdisSpaceMonster2, $HdisTinka, $HdisTreasureS, $HdisTsunami, $HdisTyphoon, $HdisUN, $HdisVGHarvest, $HearthAttack, $HeatenFood, $helpDir, $HfightMem, $HfightTurn, $HfinalTurn, $HgiveupTurn, $HhistoryMax, $HidToName, $HidToNumber, $HidToNumberR, $HinterTime, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HlandAegisShip, $HlandAirport, $HlandAmusement, $HlandBalloonS, $HlandBank, $HlandBase, $HlandBigcity, $HlandBreakwater, $HlandCasino, $HlandCoupleRock, $HlandDeathtrap, $HlandDefence, $HlandDokan, $HlandDome, $HlandEarth, $HlandExpo, $HlandFactory, $HlandFarm, $HlandFire, $HlandFishLShip, $HlandFishMShip, $HlandFishSShip, $HlandFlower, $HlandForest, $HlandFuji, $HlandGhostShip, $HlandHaribote, $HlandHospital, $HlandHugecity, $HlandIceFloe, $HlandKInora, $HlandMegacity, $HlandMegaFact, $HlandMegaFarm, $HlandMegatower, $HlandMonsShip, $HlandMonster, $HlandMonument, $HlandMountain, $HlandMyhome, $HlandOcean, $HlandOil, $HlandOPlayer, $HlandOsen, $HlandPark, $HlandPirate, $HlandPlains, $HlandPolice, $HlandPort, $HlandProbeShip, $HlandSAEisei, $HlandSbase, $HlandSchool, $HlandSCity, $HlandSDefence, $HlandSea, $HlandSeisei, $HlandSFactory, $HlandSFarm, $HlandSlum, $HlandSMonument, $HlandSpaceBase, $HlandStadium, $HlandSunit, $HlandTcity, $HlandTitanic, $HlandTower, $HlandTown, $HlandTreasureS, $HlandTrump, $HlandWarp, $HlandWarpR, $HlandWaste, $HlandWindmill, $HlandWingDragon, $HlandZoo, $HlateLogPool, $HlogMax, $HlogOmit2, $HlogPool, $HmaxdisPollution, $HmaxExpPoint, $HmaxIsland, $HmonsBtlMaxHp, $HmonsBtlMaxPa, $HmonsterAGI, $HmonsterBHP, $HmonsterCLS, $HmonsterDEF, $HmonsterDestroy, $HmonsterDHP, $HmonsterExp, $HmonsterGRP, $HmonsterL1, $HmonsterL1Num, $HmonsterL2, $HmonsterL2Num, $HmonsterL3, $HmonsterL3Num, $HmonsterL4, $HmonsterL4Num, $HmonsterL5, $HmonsterL5Num, $HmonsterName, $HmonsterNumber, $HmonsterS, $HmonsterSEI, $HmonsterSKL, $HmonsterSP, $HmonsterSpecial, $HmonsterSTR, $HmonsterValue, $Hmonth, $HmonumentMissile, $HmonumentName, $HmonumentRocket, $Hocean, $HoceanSize, $HoilMoney, $HoilRatio, $hp, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $Hprize, $HprizeV, $HpunishInfo, $HrepeatTurn, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $HseaChk, $HsecretLogPool, $HsEisei, $HshipEX, $HshipFood, $HshipHP, $HshipKAI, $HshipMATK, $HshipMoney, $HshipName, $Hshiporder, $HshipSATK, $HshipSell, $HshipSP, $HsmonumentName, $HsmonumentNumber, $Hsolarwind, $Hspace, $HspaceEfficiency, $HspaceIncome, $Hsstartturn, $HStotalPoint, $HsurvFlg, $Hsurvivalturn, $HtagName2_, $HthisFile, $HtotalBumon, $HtotalMoney, $HtotalPoint, $Htournament, $HtreeValue, $HturnPrizeNumber, $HturnPrizePoint, $HturnPrizeUnit, $HturnPrizeVarious, $HugDokan, $HugFact, $HugFarm, $HugHasigo, $HugKiti, $HugMax, $HugOil, $HugRoad, $HugSpace, $HugTosi, $human, $HunitFood, $HunitMoney, $HunitOil, $HunitOre, $HunitPop, $HunitTime, $HunitWeapon, $HwarFlg, $HWeatherMax, $Hwflg, $HwinFood, $HwinIsland, $HwinMoney, $HwinWeapon, $imageDir, $lockMode, $toppage, $versionInfo;
	$name = $island['name']; $id = $island['id']; $land =& $island['land']; $landValue =& $island['landValue']; $land2 =& $island['land2']; $landValue2 =& $island['landValue2'];
	// 날씨 변경
	$island['weather2'] = $island['weather'];
	list($wkind, $wname, $whp, $wkind2, $wkind3) = weatherinfo($island['weather']);
	// 숲이 촉촉할 때
	if((random(4) == 0) && (($wkind == 3) || ($wkind == 4)) && ($whp < 8) && ($id <= 90)){
		$island['Rain'] = 1;
		logEvent($id, $name,"에 <B>비가 와서</B> 숲이 증가 했습니다");
	}
	// 날씨 과거 데이터 조정
	$pastweather = $island['pastweather'];
	$pastw = null;
	$w = null; $pw = null;
	array_push($pastw, $wkind);
	for($w = 0; $w < 10; $w++) {
		$pw = $pastweather[$w];
		array_push($pastw, $pw);
	}
	$island['pastweather'] = $pastw;
//	logWeather("${HtagName_}${name}${AfterName}${H_tagName} 의  날씨는<B>$wname</B>입니다.");
	$wkind  = (random(10) < 9) ? $wkind2 : random(6);
	$wkind2 = (random(10) < 7) ? $wkind3 : random(6);
	$wkind3 = (random(12) == 0) ? 1 : random(6);

	if($id > 90){
		// Battle Field 때
		$island['weather'] = $wkind3 * 1000 + $wkind2 * 100 + $wkind * 10 + random(10);
		$x = null; $y = null; $i = null;
		for($i = 0; $i < $HpointNumber; $i++){
			$x = $Hrpx[$i];
			$y = $Hrpy[$i];
			list($landKind,$lv) = array($land[$x][$y],$landValue[$x][$y]);
			if($landKind == $HlandTown){
				if((random(500) == 0) || 
				($island['monstersend'] + $island['monstersend1'] + $island['monstersend2'] + $island['monstersend3'])){
					$kind = $HmonsterL3[random($HmonsterL3Num)];
					// 인조
					if($island['monstersend'] > 0){
						$kind = 0;
						$island['monstersend']--;
					}elseif($island['monstersend1'] > 0){
						$kind = 11;
						$island['monstersend1']--;
					}elseif($island['monstersend2'] > 0){
						$kind = 22;
						$island['monstersend2']--;
					}elseif($island['monstersend3'] > 0){
						$kind = 25;
						$island['monstersend3']--;
					}
					$lv2 = $kind * 100 + $HmonsterBHP[$kind] + random($HmonsterDHP[$kind]);
					logMonsCome($id, $name, hako_pick(monsterSpec($lv2), array(1)), "($x, $y)", landName($landKind, $lv));
					$land[$x][$y] = $HlandMonster;
					$landValue[$x][$y] = $lv2;
				}else{
					$landValue[$x][$y] += random(20);
					if ($landValue[$x][$y] > 200) { $landValue[$x][$y] = 200; }
				}
			}elseif($landKind == $HlandSlum){
				if (random(2) == 0) { $land[$x][$y] = $HlandTown; }
			}elseif($landKind == $HlandPlains){
				if(random(5) == 0){
					$land[$x][$y] = $HlandTown;
					$landValue[$x][$y] = 1;
				}
			}elseif($landKind == $HlandWaste){
				if(random(2) == 0){
					$land[$x][$y] = $HlandPlains;
					$landValue[$x][$y] = 0;
				}
			}elseif(($landKind == $HlandSea) && ($kinoraFlg == 1)){
				if (chkAround($land, $x, $y, $HlandKInora, 7)) { continue; }
				// 구상 이노라
				$kinoraFlg = 0;
				$land[$x][$y] = $HlandKInora;
				$landValue[$x][$y] = 50000 + (random(60) * 100) + 4000;
				logMonsCome($id, $name, landName($HlandKInora, 0), "($x, $y)", landName($landKind, $lv));
				kinoraMake($land, $landValue, $x, $y);
			}elseif($landKind == $HlandKInora){
				// 구상 이노라
				kinoraMove($island, $x, $y);
			}
		}
		return;
	}

	// 도출치
	$monsterMove = null; $shipMove = null;
	// 실업자와 난민의 수로 슬럼가의 발생 확률을 결정한다.
	list($unemployment) = $island['pop'] - 
		(($island['farm'] + $island['factory'] + $island['port'] + $island['mountain'] + $island['tower']) * 13) + $island['achive'] * 30;
	if ($unemployment < 0) { $unemployment = 0; }
	$p = ($island['food'] < 0) ? 20000 : 100000;
	$oilFlag = $island['oilfield'];

	// 숲의 비율에 의한 보수력의 조정
	list($wp,$fp) = array(2,$island['forest']);
	if ($island['eis0']) { $fp += 5; }
	if($fp >= 10){
		if (random(2) == 0) { $wp = 1; }
	}elseif($fp == 4){
		$wp = 3;
	}elseif($fp < 2){
		$wp = 5;
	}elseif($fp < 4){
		$wp = 4;
	}
	$whp += $island['tenki']; #테루테루 이노라에 의한 증가

	if($wkind == 5){ # 큰 비
		if ($whp < 4) { $whp++; }
		$whp += $wp;
	}elseif($wkind == 4){ # 비
		if ($whp < 4) { $whp++; }
		$whp += intval($wp / 2);
	}elseif($wkind == 0){ # 쾌청
		if ($whp > 5) { $whp--; }
		$whp -= $wp;
	}elseif($wkind == 1){ # 맑음
		if ($whp > 6) { $whp--; }
		$whp -= intval($wp / 2);
	}else{
		if($whp > 6){
			$whp--;
		}elseif($whp < 3){
			$whp++;
		}
	}
	// 숲이 20%이상이라면 특별히 습도를 증가한다
	if($fp >= 20){
		if($whp > 6){
			$whp--;
		}elseif($whp < 3){
			$whp++;
		}
	}

	if($whp > 9){
		$island['Kouzui'] = 1;
		$island['food'] -= intval($island['food'] * 0.1);
		$whp = 8;
		logEvent2($id, $name, '홍수가 발생!','섬의 인구가 줄어들었습니다.');
		if (($island['pop'] >= $HdisMonsBorder1) && (random(12) == 0)) { $island['TeruteruMons'] = 1; }
	}elseif($whp < 0){
		$island['Hideri'] = 1;
		$whp = 1;
		logEvent2($id, $name, '가뭄이 발생!','여러가지 피해가 나왔습니다.');
		if (($island['pop'] >= $HdisMonsBorder1) && (random(12) == 0)) { $island['TeruteruMons'] = 2; }
	}
	$island['weather'] = $wkind3 * 1000 + $wkind2 * 100 + $wkind * 10 + $whp;

	$Pol = $HdisPollution * $island['pop'] * 0.001;
	if ($Pol > $HmaxdisPollution) { $Pol = $HmaxdisPollution; }

	if((random(1000) < $Pol) && ($island['pop'] >= 3000) &&
								 ($island['propaganda'] != 1 )){
		// 공해 발생 인구 30만 미만, 유치 활동중때는 발생하지 않는다
		$island['Pollution'] = 1;
		logEvent2($id, $name, '공해','가 발생하고 있습니다');
	}
	if((random($p) < ($HdisCrime * ($island['pop'] + $island['slum'] * 4 + $unemployment) * 0.1)) && ($island['Police'] == 0)){
		// 범죄 발생
		$island['Crime'] = 1;
		logEvent2($id, $name, '범죄가 발생','하고 있습니다');
	}
	if(random(100) < 5 + $island['event']){
		$island['event'] = 1;
		$eve = random(100);
		if($eve < 10){
			$island['wingdragon'] = 1;
			$eve = " 에 익룡이 출현! 관광객이 모였습니다.";
		}elseif($eve < 30){
			$island['icefloe'] = 1;
			$eve = " 에 빙산이 출현! 관광객이 모였습니다.";
		}elseif($eve < 50){
			$island['couplerock'] = 1;
			$eve = " 에 부부바위가 출현! 관광객이 모였습니다.";
		}elseif($eve < 52){
			$eve = "에 대륙으로부터 이민 표착! 인구가 증가했습니다.";
		}elseif($eve < 63){
			$island['present'][0]++;
			$eve = "로, 왜인지 공원이 유치되어 관광객이 모였습니다.";
		}elseif($eve < 69){
			$island['present'][1]++;
			$eve = "로, 대륙의 종합건설업자로부터 스타디움 건설 자금이 기부되어 관광객이 모였습니다.";
		}elseif($eve < 72){
			$island['present'][2]++;
			$eve = "로, 돔 건설 예산안이 의회에서 가결되어 관광객이 모였습니다.";
		}elseif($eve < 76){
			$island['present'][3]++;
			$eve = "로, 대륙의 자산가가 카지노 건설을 결정, 관광객이 모였습니다.";
		}elseif($eve < 80){
			$island['present'][4]++;
			$eve = "로, 섬의 재벌이 유원지 건설을 결정, 관광객이 모였습니다.";
		}elseif($eve < 89){
			$island['present'][5]++;
			$eve = "로, 주민이 학교의 건설을 간절히 원해서 건설이 결정, 대륙으로부터 많은 이민자가 왔습니다";
		}elseif($eve < 94){
			$island['present'][6]++;
			$eve = "로, 공항 건설의 예산이 짜여지고 건설하는 것이 결정, 대륙으로부터 많은 이민자가 왔습니다";
		}elseif($eve < 96){
			$island['present'][7]++;
			$eve = "로, 대도시를 건설한다고 하는 소문이 퍼져 대륙으로부터 많은 이민자가 왔습니다.";
		}else{
			$island['present'][8]++;
			$eve = "로, 동물 좋아하는 실업가가 동물원 건설을 결정, 관광객이 모였습니다.";
		}
		logOut("${HtagName_}${name}${AfterName}${H_tagName}${eve}",$id);
	}else{
		$island['event'] = 0;
	}
	
	// 증가하는 인구의 씨치촌정, 도시, 대도시
	list($pop1,$pop2,$pop3) = array(10,0,0);
	if($island['food'] < 0){
 		$pop1 = -30; # 식량부족
 		$pop2 = -10;
 		$pop3 = -10;
	}elseif($island['propaganda'] == 1){
		$pop1 = 30; # 유치 활동중
		$pop2 = 4;
		$pop3 = 4;
	}
	if($island['Kouzui'] == 1){ # 홍수
		$pop1 -= random(30) + 5;
		$pop2 -= random(15) + 4;
		$pop3 -= random(10) + 4;
	}
	if($island['Hideri'] == 1){ # 가뭄
		$pop1 -= random(20) + 5;
		$pop2 -= 5;
		$pop3 -= 5;
	}
	if($island['Crime'] == 1){ # 범죄 다발시
		$pop1 -= random(10) + 5;
		$pop2 -= 4;
		$pop3 -= 5;
	}
	if($island['towerD'] > 0){ # 상업 과잉시
		$pop1 -= 3;
		$pop2--;
		$pop3 -= 2;

	}
	if($island['event'] == 1){ # 인구 증 이벤트
		$pop1 += 30;
		$pop2 += 5;
		$pop3 += 5;
	}
	if($island['event2'] == 1){ # 인구 증 이벤트 2
		$pop1 += 50;
		$pop2 += 15;
		$pop3 += 10;
	}
	if($island['treasure'] > 0){ # 보물선
		$pop1 += 5;
		$pop2 += 2;
		$pop3++;
		$island['displus'] = 70;
	}
	if($island['gold'] > 0){ # 황금기
		$pop1 += 20;
		$pop2 += 6;
		$pop3 += 4;
		$island['displus'] = 150;
	}
	
	// 루프
	$x = null; $y = null; $i = null; $osen = null;
	for($i = 0; $i < $HpointNumber; $i++){
		$x = $Hrpx[$i];
		$y = $Hrpy[$i];
		list($landKind,$lv) = array($land[$x][$y],$landValue[$x][$y]);
	if(($landKind == $HlandTown) || ($landKind == $HlandSlum) ||
		($landKind == $HlandMegacity) || ($landKind == $HlandMegaFarm) || ($landKind == $HlandMegaFact) || ($landKind == $HlandMegatower) ||
		(($landKind == $HlandOil) && ($lv >= 35))){
		// 마을계, 해저 도시, 슬럼가, 합체 지형
		if((($landKind == $HlandTown) && ($lv < 130)) && (random($p) < $unemployment + $island['towerD'])){
			// 슬럼가에 변화하는 확률이 있다
			logslum($id, $name,landName($landKind, $lv), "($x, $y)");
			$land[$x][$y] = $HlandSlum;
continue;
		}elseif(($landKind == $HlandSlum) && ($unemployment == 0) && (random(3) == 0)){
			//난민도 가미해 일자리가 남아 있을 때는 33.3%의 확률로 슬럼가가 마을이 된다.
			$land[$x][$y] = $HlandTown;
continue;
		}elseif(($island['Pollution'] == 1) && ($landKind == $HlandTown) && ($island['Hospital'] != 1)){
			// 병원이 없는 경우, 공해 발생중 31%로 연쇄
			if (random(100) > 30) { $island['Pollution'] = 0; }
			logOsen($id, $name, landName($landKind, $lv), "($x, $y)");
			$land[$x][$y] = $HlandOsen;
			if(chkAround($land, $x, $y, $HlandForest, 7)){
				$landValue[$x][$y] = 1;
			}else{
				$landValue[$x][$y] = random(3) + 1;
			}
continue;
		}
		
		// 주위의 지형으로 인구의 증가하는 방법을 조절한다
		list($addpop,$addpop2,$addpop3) = array($pop1,$pop2,$pop3);
		$count = 0; 
		$j = null; $sx = null; $sy = null;
		for($j = 0; $j < 7; $j++){
			$sx = $x + $ax[$j];
			$sy = $y + $ay[$j];
			if (!($sy % 2) && ($y % 2)) { $sx--; }
			if(($sx < 0) || ($sx >= $HislandSize) || ($sy < 0) || ($sy >= $HislandSize)){
			}elseif(($land[$sx][$sy] == $HlandMonument) ||
				($land[$sx][$sy] == $HlandSMonument) ||
				($land[$sx][$sy] == $HlandForest) ||
				(($land[$sx][$sy] == $HlandWaste) && ($landValue[$sx][$sy] >= 10))){
				// 기념비, 해저 기념비, 숲, 온천
				$addpop += 2;
				$addpop2++;
			}elseif($land[$sx][$sy] == $HlandSchool){
				// 학교
				$addpop += 2;
				$addpop2 += 2;
				$count = -1;
			}elseif($land[$sx][$sy] == $HlandSlum){
				if ($count == 0) { $count = 1; }
			}elseif($land[$sx][$sy] == $HlandOsen){
				$addpop -= 15;
			}
		}
		if($count){
			// 주위에 학교가 없게 슬럼가가 있을 때
			$addpop  -= 3;
			$addpop2 -= 3;
			$addpop3 -= 3;
		}

		if($landKind == $HlandOil){
			if($lv >= 35){
				// 해저 도시
				$island['money']--;
				$island['food'] -= intval($lv * $HeatenFood);
				if($island['money'] < 0){
					$addpop -= 20;
					$island['money'] = 0;
				}
				if($island['food'] < 0){
					$addpop -= 20;
					$island['food'] = 0;
				}
			}elseif ($lv >= 10){
				// 해저 농장
				$island['money'] -= intval($lv / 5);
				if($island['money'] < 0){
					$land[$x][$y] = $HlandSea;
					$landValue[$x][$y] = 0;
				}
			}
		}
		
		if(($landKind == $HlandMegacity) || ($landKind == $HlandMegaFarm) || ($landKind == $HlandMegaFact) || ($landKind == $HlandMegatower)){
			// 거대 지형의 경우
			list($r1,$r2,$r3) = array(3,-3,0);
			if ($island['Hospital'] == 1) { list($r1,$r2,$r3) = array(0,-4,1); }
			if ($landKind != $HlandMegacity) { list($r1,$r2,$r3) = array(-1,-7,2); }
			
			if((random(5) > $r3) && (($addpop < $r1) || ($addpop2 < $r2) || ($addpop3 < $r2))){
				// 원래대로 돌아간다
				$lName = landName($landKind, $lv);
				$lName2 = null;
				if($landKind == $HlandMegaFact){
					$landKind = $HlandFactory;
					$land[$x][$y] = $landKind;
					$lName2 = landName($landKind, 90);
					$landValue[$x][$y] = 90;
				}elseif($landKind == $HlandMegaFarm){
					$landKind = $HlandFarm;
					$land[$x][$y] = $landKind;
					$lName2 = landName($landKind, 50);
					$landValue[$x][$y] = 50;
				}else{
					if($landKind == $HlandMegacity){
						$landKind = $HlandTown;
					}elseif($landKind == $HlandMegatower){
						$landKind = $HlandTower;
					}
					$land[$x][$y] = $landKind;
					$lName2 = landName($landKind, 190);
					$landValue[$x][$y] = 190;
				}
				logEventP($id, $name,"($x, $y)", "의 ${lName}가 ${lName2}에 돌아가 버렸습니다.");
			}
		}else{
			if($addpop < 0){
				// 부족
				$lv -= (random(-$addpop) + 1);
				if(($landKind == $HlandOil) && ($lv < 35)){
					$land[$x][$y] = $HlandSea;
					$landValue[$x][$y] = 0;
continue;
				}elseif((($landKind == $HlandTown) && ($lv <= 0)) ||
						(($landKind == $HlandSlum) && ($lv <= 0))){
					// 평지에 되돌린다
					$land[$x][$y] = $HlandPlains;
					$landValue[$x][$y] = 0;
continue;
				}
			}else{
				// 성장
				if($lv < 100){
					$lv += random($addpop) + 1;
					if ($lv > 100) { $lv = 100; }
				}elseif($lv < 130){
					//  도시가 되면 성장 늦다
					if($addpop2 > 0){
						$lv += random($addpop2 + 1);
						if ($lv > 130) { $lv = 130; }
					}
				}else{
					// 대도시가 되면 성장이 한층 더 늦다
					if ($addpop3 > 0) { $lv += random($addpop3); }
				}
			}
//			if($lv > 200){
//				$lv = 200;
//			}
			$landValue[$x][$y] = $lv;
		}
	}elseif(($landKind == $HlandSea) && ($lv >= 10)){
		// 양식장
//		$island['food'] += intval($lv / 2);
		if(($island['Hideri']  == 1) || ($island['Kouzui']  == 1)){
			$landValue[$x][$y] -= 5;
			if ($landValue[$x][$y] < 10) { $landValue[$x][$y] = 1; }
		}elseif($lv < 200){
			// 물고기를 늘린다
			$landValue[$x][$y]++;
		}else{
			$landValue[$x][$y] = 200;
		}
	}elseif(($landKind > 100) && ($landKind < 120)){
		// 배계의 경우
		
		if(($landKind == $HlandPirate) || ($landKind == $HlandGhostShip)){
			// 해적, 유령배는 유엔의 토벌 대상.
			if(($island['turnsu'] + $island['evil'] < $HdisUN) || ($island['evil'] == 0)){
				logUNShip($id, $name, landName($landKind, 0), "($x, $y)");
				$land[$x][$y] = $land2[$x][$y];
				$landValue[$x][$y] = $landValue2[$x][$y];
				$land2[$x][$y] = $HlandSea;
				$landValue2[$x][$y] = 0;
continue;
			}
		}
		
		list($order, $hp, $sId) = shipSpec($lv);
		
		if($sId > 0){
			$sn = $HidToNumber[$sId];
			if($sn == ''){
				// 배보유도이 존재하지 않는은 조난한다.
				$land[$x][$y] = $land2[$x][$y];
				$landValue[$x][$y] = $landValue2[$x][$y];
				$land2[$x][$y] = $HlandSea;
				$landValue2[$x][$y] = 0;
				logShipWreck($id, $name, landName($landKind, 0), "($x, $y)");
continue;
			}
		}
		
		if($shipMove[$x][$y] == 2){
			// 벌써 움직인 후
continue;
		}elseif($shipMove[$x][$y] == 0){
			// 회복하는 배의 경우는 회복한다
			if($HshipHP[$landKind - $HlandPirate] > $hp){
				$landValue[$x][$y] += $HshipKAI[$landKind - $HlandPirate] * 1000;
				$hp += $HshipKAI[$landKind - $HlandPirate];
			}
		}

		// 수입
		if(($landKind == $HlandFishSShip) ||
			($landKind == $HlandFishMShip) ||
			($landKind == $HlandFishLShip) ||
			($landKind == $HlandTitanic)){
			$sIsland = $Hislands[$HidToNumber[$sId]];
			if($landKind == $HlandFishSShip){
				$sIsland['food'] += 30;
			}elseif($landKind == $HlandTitanic){
				$sIsland['money'] += 5;
			}else{
				$sIsland['food'] += 50;
			}
		}

		// 지출 우선 자도에 있는 녀석만
		if(($sId == $id) && ($shipMove[$x][$y] == 0)){
//			HdebugOut("배계 지출:" . $island['name'] . $landKind . ":자금:" . $HshipMoney[$landKind - $HlandPirate] . ":식량:" . $HshipFood[$landKind - $HlandPirate]);
			$island['money'] -= $HshipMoney[$landKind - $HlandPirate];
			$island['food'] -= $HshipFood[$landKind - $HlandPirate];
		}

		$sx = null; $sy = null;
		if($order == 2){
			// 지령이 방어의 경우
			// 1회갚는다
			if ($HshipHP[$landKind - $HlandPirate] > $hp) { $landValue[$x][$y] += 1000; }
continue;
		}else{
			// 이동과 행동
			list($sx, $sy) = shipAction($island, $x, $y);
		}

		// 이동이 끝난 플래그
		if($sx == 100){
			// 사라졌다
		}elseif($HshipSP[$landKind - $HlandPirate] == 2){
			// 매우 빠른 배
			$shipMove[$sx][$sy] = 1;
		}elseif($HshipSP[$landKind - $HlandPirate] == 1){
			// 빠른 배
			$shipMove[$sx][$sy] = $shipMove[$x][$y] + 1;
		}else{
			// 보통 배
			$shipMove[$sx][$sy] = 2;
		}
	}elseif($landKind == $HlandForest){
		// 숲
		if($lv < 200){
			// 나무를 늘린다
			if($island['Rain'] == 1){
				$lv += 5;
			}elseif($island['Hideri'] == 1){
				$lv -= 5;
				if ($lv < 1) { $lv = 1; }
			}else{
				$lv++;
			}
			$landValue[$x][$y] = $lv;
		}elseif($lv >= 200){
			$island['money'] += $HtreeValue * $lv;
			$landValue[$x][$y] = 1;
			logAutoTree($id, $name);
		}
	}elseif($landKind == $HlandMonument){
		// 기념비
		if(($island['pop'] >= 10000) && ($island['evil'] > 0) && ($island['tower'] > 450) && (random(4) == 0)){
	//	if($island['pop'] >= 100){
			$i = null; $sx = null; $sy = null;
			for($i = 1; $i < 7; $i++){
				$sx = $x + $ax[$i];
				$sy = $y + $ay[$i];
				if (!($sy % 2) && ($y % 2)) { $sx--; }
				if (($sx < 0) || ($sx >= $HislandSize) || ($sy < 0) || ($sy >= $HislandSize)) { break; }
				if( ($land[$sx][$sy] == $HlandMegacity) ||
						($land[$sx][$sy] == $HlandMegatower) ||
						($land[$sx][$sy] == $HlandMegaFact) ||
						($land[$sx][$sy] == $HlandMegaFarm)){
				}else{
					break;
				}
			}
			if($i >= 7){
				// 발전
				$lName = landName($landKind, $lv);
				logEventP($id, $name,"($x, $y)", "의 ${lName}를 핵심으로서 주위가 초거대도시로 발전했습니다.");
				$land[$x][$y] = $HlandHugecity;
				for($i = 1; $i < 7; $i++){
					$sx = $x + $ax[$i];
					$sy = $y + $ay[$i];
					if (!($sy % 2) && ($y % 2)) { $sx--; }
					if (($sx < 0) || ($sx >= $HislandSize) || ($sy < 0) || ($sy >= $HislandSize)) { break; }
					if($land[$sx][$sy] == $HlandMegaFact){
						$landValue[$sx][$sy] = 60;
					}elseif($land[$sx][$sy] == $HlandMegatower){
						$landValue[$sx][$sy] = 70;
					}elseif($land[$sx][$sy] == $HlandMegaFarm){
						$landValue[$sx][$sy] = 80;
					}else{
						$landValue[$sx][$sy] = 50;
					}
					$land[$sx][$sy] = $HlandHugecity;
				}
			}
		}
		if(random(10000) == 0){
			// 1만 분의 1의 확률로 골드 고스트가 된다
			$land[$x][$y] = $HlandMonster;
			$landValue[$x][$y] = 3100 + $HmonsterBHP[31] + random($HmonsterDHP[31]);
			logMonsCome($id, $name, hako_pick(monsterSpec($landValue[$x][$y]), array(1)), "($x, $y)", landName($landKind, $lv));
		}elseif($lv == 9){ # 순금의 비
			$island['money'] += 300;
			$island['GoldMonument']++;
		}
	}elseif($landKind == $HlandOsen){
		// 오염 토양
		if ($lv > 10) { $landValue[$x][$y] = 10; }
		if(random(3) == 0){
			$landValue[$x][$y]--;
			if($landValue[$x][$y] <= 0){
				$land[$x][$y] = $HlandWaste;
				$landValue[$x][$y] = 0;
			}
		}
	}elseif($landKind == $HlandDefence){
		if($lv == 1){
			// 방위 시설 자폭
			logBombFire($id, $name, landName($landKind, $lv), "($x, $y)");
			// 광역 피해 루틴
			wideDamage($id, $name, $land, $landValue, $x, $y, 0);
		}elseif(($lv == 20) || ($lv == 21)){
			// 안개 첨부 방위 시설
			if($island['money'] < 50){
				logBombFire($id, $name, landName($landKind, $lv), "($x, $y)");
				wideDamage($id, $name, $land, $landValue, $x, $y, 0);
			}else{
				$island['money'] -= 50;
			}
		}
	}elseif($landKind == $HlandPort){
		// 항
		if((seaAround($land, $x, $y, 7) == 0) && (random(3) == 0)){
			// 주위에 바다계가 없는 경우33%로 폐쇄
			logClosedPort($id, $name, landName($landKind, $lv), "($x, $y)");
			$land[$x][$y] = $HlandWaste;
			$landValue[$x][$y] = 0;
		}
	}elseif($landKind == $HlandBank){
		// 은행
		if(($lv >= 30) && (random(1000) == 0)){
			logEventP($id, $name,"(?, ?)", "의 은행이 도산할 것 같게 되었습니다만, 공적자금 투입에 의해 규모는 반이 되었습니다만 도산을 면했습니다. ");
			logSecret("도산할 것 같게 된 것은${HtagName_}($x, $y)${H_tagName}지점의 은행입니다.",$id);
			$landValue[$x][$y] = intval($lv / 2);
		}elseif(($lv < 30) && (random(1000) == 0)){
			logEventP($id, $name,"($x, $y)", "의 은행이 도산해 황무지가 되었습니다.");
			$land[$x][$y] = $HlandWaste;
			$landValue[$x][$y] = 0;
		}else{
			$island['money'] += $lv * (random(3) + 1);
		}
	}elseif(($landKind == $HlandOil) && (($lv == 6) || ($lv == 7))){
		// 해저 소방서, 해저 데스트랩 의 유지비
		if($island['money'] < 5){
			$land[$x][$y] = $HlandSea;
			$landValue[$x][$y] = 0;
		}else{
			$island['money'] -= 5;
		}
	}elseif($landKind == $HlandFire){ # 소방서의 유지비
		if($island['money'] < 3){
			$land[$x][$y] = $HlandWaste;
			$landValue[$x][$y] = 0;
		}else{
			$island['money'] -= 3;
			if (random(100) < 1) { $landValue[$x][$y] = 10; }
		}
	}elseif(($landKind == $HlandOil) && ($lv == 0)){
		// 해저 유전
		// 고갈 판정
		if(random(1000) < $HoilRatio){
			// 고갈
			logOilEnd($id, $name, landName($landKind, $lv), "($x, $y)");
			$land[$x][$y] = $HlandSea;
			$landValue[$x][$y] = 0;
		}
		// 모든 유전의 고갈 판정을 실시했는지 어떠했는지
		$oilFlag--;
		if ($oilFlag > 0) { continue; }
		if($island['order'] & 2048){
			// 유전은 자금을 생산한다
			$value = $island['oilfield'] * $HoilMoney * 2;
			$island['money'] += $value;
			// 수입 로그
			logOilMoney($id, $name, landName($landKind, $lv), "($x, $y)", $value);
		}else{
			$value = $island['oilfield'] * $HoilMoney;
			$island['oil'] += $value;
			// 수입 로그
			$lName = landName($landKind, $lv);
			logOut("${HtagName_}${name}${AfterName}${H_tagName} 의 <B>$lName</B>로부터,<B>$value$HunitOil</B>의 수익이 올랐습니다.",$id);
		}
	}elseif(($landKind == $HlandWaste) && ($lv >= 10)){
		// 온천
		$value = $lv * (random(23) + 1);
		$island['money'] += $value;

		// 수입 로그
		logOilMoney($id, $name, landName($landKind, $lv), "($x, $y)", $value);

		// 고갈 판정
		if(random(10) < 6){
			$landValue[$x][$y] -= random(21);
			if($landValue[$x][$y] < 10){
				// 고갈
				logOilEnd($id, $name, landName($landKind, $lv), "($x, $y)");
				$land[$x][$y] = $HlandWaste;
				$landValue[$x][$y] = 1;
			}
		}else{
			$landValue[$x][$y] += random(21);
			if ($landValue[$x][$y] > 200) { $landValue[$x][$y] = 200; }
		}
	}elseif($landKind == $HlandPlains){
		// 평지
		if(random(5) == 0){
			// 주위에 농장, 마을이 있으면, 여기도 마을이 된다
			if(countGrow($land, $landValue, $x, $y)){
				$land[$x][$y] = $HlandTown;
				$landValue[$x][$y] = 1;
			}
		}
	}elseif(($landKind == $HlandExpo) || ($landKind == $HlandStadium) || ($landKind == $HlandDome) ||
			($landKind == $HlandAmusement) || ($landKind == $HlandAirport) || ($landKind == $HlandZoo)){
		// 박람회, 스타디움, 돔, 유원지, 공항, 동물원
		$island['money'] += 40;
	}elseif($landKind == $HlandCasino){
		// 카지노
		$island['money'] += random(150) - 50;
	}elseif($landKind == $HlandBigcity){
		// 대도시
		if (!$HbigcityFood) { $island['food'] -= 400; }

//	}elsif(($landKind == $HlandPark) || ($landKind == $HlandSchool)){
//		#  공원, 학교
//		$island['money'] += 10;
	}elseif(($landKind == $HlandWindmill) || ($landKind == $HlandPolice) || ($landKind == $HlandHospital)){
		// 풍차, 경찰서, 병원 유지비
		if($island['money'] < 5){
			$land[$x][$y] = $HlandWaste;
			$landValue[$x][$y] = 0;
		}else{
			$island['money'] -= 5;
		}
	}elseif(($landKind == $HlandTower) && ($lv >= 200)){
		//  MAX 상업 빌딩
//		HdebugOut($island['name'] . "：상업의 규모：" . $island['tower'] . ":인구증파라 3 : ${pop3}:");
		if(($island['pop'] >= 8000) && ($island['tower'] > 450) && ($pop3 > 2) && (random(5) == 0)){
			$lName = landName($HlandTower, 200);
			$lName2 = landName($HlandTcity, 200);
			logOut("${HtagName_}${name}${AfterName}($x, $y)${H_tagName} 의 <B>$lName</B>가,<B>$lName2</B>로 발전했습니다.",$id);
			$land[$x][$y] = $HlandTcity;
			$landValue[$x][$y] = 200;
		}
	}elseif($landKind == $HlandTcity){
		// 상업도시
//		HdebugOut($island['name'] . "：상업도시:인구증파라 3：${pop3}:");
		if(($island['pop'] < 7000) || (($pop3 < -3) && (random(5) == 0))){
			$lName = landName($HlandTcity, 200);
			$lName2 = landName($HlandTower, 200);
			logOut("${HtagName_}${name}${AfterName}($x, $y)${H_tagName} 의 <B>$lName</B>가,<B>$lName2</B>에 레벨 다운했습니다.",$id);
			$land[$x][$y] = $HlandTower;
			$landValue[$x][$y] = 200;
		}
	}elseif($landKind == $HlandSeisei){
		// 정제장
		$value = $lv * 100;
		$island['money'] += $value;

		// 수입 로그
		logOilMoney($id, $name, landName($landKind, $lv), "($x, $y)", $value);

		// 고갈 판정
		if(random(1000) < $HoilRatio){
			logOilEnd($id, $name, landName($landKind, $lv), "($x, $y)");
			$land[$x][$y] = $HlandWaste;
			$landValue[$x][$y] = 0;
		}
	}elseif($landKind == $HlandMonster){
		// 괴수
		// 각 요소의 꺼내
		list($mKind, $mName, $mHp) = monsterSpec($landValue[$x][$y]);
		$special = $HmonsterSpecial[$mKind];
		
		if(($island['turnsu'] + $island['evil'] < $HdisUN) || ($island['evil'] == 0)){
			logUNMons($id, $name, $mName, "($x, $y)");
			$land[$x][$y] = $HlandWaste;
			$landValue[$x][$y] = 0;
continue;
		}
		if($monsterMove[$x][$y] == 2){
			// 벌써 움직인 후
continue;
		}
		// 방어중?
		if((($special == 3) && (($HislandTurn % 2) == 1)) ||
				(($special == 4) && (($HislandTurn % 2) == 0)) ||
				($special == 5) || 
				(($island['manipulate'] == 0) && (($special == 6) || ($special == 7)) ) ){
			continue;  # 방어중
		}

		if($special == 9){
			// 전회복한다
			$landValue[$x][$y] = $mKind * 100 + $HmonsterBHP[$mKind];
			logMonster($id, $name, "($x, $y)", $mName, "는, 정신을 집중하여 순식간에 상처가 회복했습니다.");
		}
		
		// 이동한다
		list($sx, $sy) = monmove($island, $x, $y, 0);

		// 이동이 끝난 플래그
		if($HmonsterSpecial[$mKind] == 2){
			// 이동이 끝난 플래그는 세우지 않다
		}elseif($HmonsterSpecial[$mKind] == 1){
			// 빠른 괴수
			$monsterMove[$sx][$sy] = $monsterMove[$x][$y] + 1;
		}else{
			// 보통 괴수
			$monsterMove[$sx][$sy] = 2;
		}
	}elseif($landKind == $HlandKInora){
		// 구상 이노라
		if(($island['turnsu'] + $island['evil'] < $HdisUN) || ($island['evil'] == 0)){
			logUNMons($id, $name, $mName, "($x, $y)");
			$land[$x][$y] = $HlandWaste;
			$landValue[$x][$y] = 0;
continue;
		}
		kinoraMove($island, $x, $y);
	}elseif($land[$x][$y] > 51){
		// 있을 수 없는 지형때는 우선 황무지로 해 둔다
		$land[$x][$y] = $HlandWaste;
		$landValue[$x][$y] = 0;
	}
	if($Htournament){
		// 간이 토너먼트
		if($HislandFightMode == 3){
			// 전투중
		}else{
			// 그 이외
			if($landKind == $HlandWarp){
				// 전이 장치는 우선 꽃으로 한다.
				logEventP($id, $name,"($x, $y)", "의 전이 장치는, 전투 기간이 아니기 때문에 해체되고 꽃이 심어졌습니다. ");
				$land[$x][$y] = $HlandFlower;
				$landValue[$x][$y] = random(13) + 1;
			}
		}
	}
	if(($land[$x][$y] > 100) || ($landKind == $HlandKInora)){
		// 배계, 구상 이노라 때
	}elseif(($land[$x][$y] == $HlandMonster) || ($land[$x][$y] == $HlandHaribote)){
		if($landValue[$x][$y] > 4000){
			// 있을 수 없는 값이므로 우선 황무지로 해 둔다
			$land[$x][$y] = $HlandWaste;
			$landValue[$x][$y] = 0;
		}
	}elseif(($land[$x][$y] == $HlandBase) || ($land[$x][$y] == $HlandSbase)){
		if($landValue[$x][$y] > 250){
			// 250이상은 있을 수 없기 때문에 우선 250으로 해 둔다
			$landValue[$x][$y] = 250;
		}
	}elseif(($landValue[$x][$y] > 200) && ($land[$x][$y] != $HlandWarp)){
		// 200이상은 있을 수 없기 때문에 우선 200으로 해 두는 전이 장치 이외
//		HdebugOut("지형 데이터치 부정 때문에 우선 200으로 합니다.:LAND=" . {$land[$x]}[$y] . ":LV=" . $landValue[$x][$y]);
		$landValue[$x][$y] = 200;
	}
	// 거대 지형 변화
	list($landKind,$lv) = array($land[$x][$y],$landValue[$x][$y]);
	if((($landKind == $HlandTown) && ($lv >= 201)) ||
		(($landKind == $HlandFarm) && ($lv >= 50)) ||
		(($landKind == $HlandFactory) && ($lv >= 90)) ||
		(($landKind == $HlandTower) && ($lv >= 180))){
		// 200의 도시, 농장, 공장, 상업 빌딩 때
		$i = null; $j = null; $r = null; $sx = null; $sy = null;
		for($i = 1; $i < 7; $i++){
			$sx = $x + $ax[$i];
			$sy = $y + $ay[$i];
			if (!($sy % 2) && ($y % 2)) { $sx--; }
			if(($sx < 0) || ($sx >= $HislandSize) || ($sy < 0) || ($sy >= $HislandSize)){
				// 범위외의 경우 아무것도 하지 않는다
			}elseif((($land[$sx][$sy] == $landKind) && ($landValue[$sx][$sy] >= 200)) ||
					(($landKind == $HlandFarm) && ($land[$sx][$sy] == $HlandFarm) && ($landValue[$sx][$sy] >= 50)) ||
					(($landKind == $HlandFactory) && ($land[$sx][$sy] == $HlandFactory) && ($landValue[$sx][$sy] >= 100))){
				// 범위내의 경우로 합체 가능 지형이 있었을 때
				
				// 의미 불명한 계산을 해 복잡하게 한다
				$r = 30;
				if ($island['propaganda'] == 1) { $r -= 20; }
				if ($island['evil'] == 0) { $r += 170; }
				if ($island['event'] == 1) { $r -= 15; }
				if($island['Crime'] + $island['Pollution'] + $island['Kouzui'] + $island['Hideri'] >= 1){
					// 범죄, 공해, 홍수, 가뭄
					$r += 1000;
				}
				if($island['zyuni'] > 700){ # 순위점
					$r -= 10;
				}elseif($island['zyuni'] > 500){
					$r -= 7;
				}elseif($island['zyuni'] > 300){
					$r -= 5;
				}elseif($island['zyuni'] > 100){
					$r -= 3;
				}
				// 부문상수를 계산
				$k = null; $f = null; $flags = null; $kazu = null;
				$f = 1;
				$kazu = 0;
				$flags = $island['status'];
				for($k = 0; $k < $HturnPrizeNumber; $k++){
					if ($flags & $f) { $kazu++; }
					$f *= 2;
				}
				$r -= $kazu * 8;
				if ($r < 2) { $r = 2; }
				if(random($r) == 0){
					// 합체처의 지형의 방향을 요구한다
					if ($i < 4){
						$j = $i + 3;
					}else{
						$j = $i - 3;
					}
					$lName = landName($landKind, $lv);
					$lName2 = null;
					if($landKind == $HlandTown){
						// 도시 때
						$lName2 = landName($HlandMegacity, 0);
						$land[$x][$y] = $HlandMegacity;
						$land[$sx][$sy] = $HlandMegacity;
					}elseif($landKind == $HlandFarm){
						// 농장 때
						$lName2 = landName($HlandMegaFarm, 0);
						$land[$x][$y] = $HlandMegaFarm;
						$land[$sx][$sy] = $HlandMegaFarm;
					}elseif($landKind == $HlandFactory){
						// 공장 때
						$lName2 = landName($HlandMegaFact, 0);
						$land[$x][$y] = $HlandMegaFact;
						$land[$sx][$sy] = $HlandMegaFact;
					}elseif($landKind == $HlandTower){
						// 상업 빌딩 때
						$lName2 = landName($HlandMegatower, 0);
						$land[$x][$y] = $HlandMegatower;
						$land[$sx][$sy] = $HlandMegatower;
					}
					logEventP($id, $name,"($x, $y)", "라고 ${HtagName_}($sx, $sy)${H_tagName}의 ${lName} 가${lName2} 으로 발전했습니다.");
					$landValue[$x][$y] = $i;
					$landValue[$sx][$sy] = $j;
break;
				}
			}
		}
	}
	list($landKind,$lv) = array($land[$x][$y],$landValue[$x][$y]);
	// 오염 확산
	if(random(5) == 0){
		// 평지, 황무지, 온천, 농장, 오염때
		if(($landKind == $HlandWaste) ||
			($landKind == $HlandPlains) ||
			($landKind == $HlandFarm) ||
			($landKind == $HlandOsen)){
			if(chkAround($land, $x, $y, $HlandOsen, 7)){
				if(($landKind == $HlandOsen) && ($lv < 10)){
					$landValue[$x][$y]++;
				}elseif($landKind != $HlandOsen){
					if(($landKind == $HlandFarm) || (($landKind == $HlandWaste) && ($lv >= 10))){
						logOsen($id, $name, landName($landKind, $lv), "($x, $y)");
					}
					$land[$x][$y] = $HlandOsen;
					$landValue[$x][$y] = 1;
				}
			}
		}
	}
	list($landKind,$lv) = array($land[$x][$y],$landValue[$x][$y]);
	// 정제장에 의한 오염
	// 바다계, 괴수, 산, 오염, 기념비 이외
	if(($HseaChk[$land[$x][$y]] == 0) &&
		($land[$x][$y] != $HlandMountain) &&
		($land[$x][$y] != $HlandMonument) &&
		($land[$x][$y] != $HlandOsen) &&
		($land[$x][$y] != $HlandMyhome) &&
		($land[$x][$y] != $HlandFuji) &&
		($land[$x][$y] != $HlandKInora) &&
		($land[$x][$y] != $HlandMonster)){
		if(random(100) == 0){
			if(chkAround($land, $x, $y, $HlandSeisei, 7)){
				$land[$x][$y] = $HlandOsen;
				$landValue[$x][$y] = random(3) + 1;
				logOsen($id, $name, landName($landKind, $lv), "($x, $y)");
			}
		}
	}
	list($landKind,$lv) = array($land[$x][$y],$landValue[$x][$y]);
	// 비에 의한 숲증식
	if(($island['Rain'] == 1) && (random(2) == 0) && ($landKind == $HlandPlains)){
		if(chkAround($land, $x, $y, $HlandForest, 7)){
			 $land[$x][$y] = $HlandForest;
			 $landValue[$x][$y] = 1;

		}
	}
	list($landKind,$lv) = array($land[$x][$y],$landValue[$x][$y]);
	// 온천에 의한 지반침하 판정
	if(($HseaChk[$land[$x][$y]] == 0) &&
			($land[$x][$y] != $HlandMountain) &&
			($land[$x][$y] != $HlandMonument) &&
			($land[$x][$y] != $HlandMyhome) &&
			($land[$x][$y] != $HlandFuji) &&
			($land[$x][$y] != $HlandKInora) &&
			($land[$x][$y] != $HlandMonster)){
		if(random(10000) < countAroundEX($land, $landValue, $x, $y, $HlandWaste, 10, 19) * $HdisTinka){
			logFalldownLandO($id, $name, landName($landKind, $lv), "($x, $y)");
			$land[$x][$y] = $HlandSea;
			$landValue[$x][$y] = 1;
		}
	}
	list($landKind,$lv) = array($land[$x][$y],$landValue[$x][$y]);
	// 재분화 판정
	if(($landKind == $HlandMountain) && ($lv >= 1)){
		if(random(1000) < countAroundEX($land, $landValue, $x, $y, $HlandWaste, 10, 7) * $HdisAEruption){
			$island['AEruption'] = 1;
			$island['AEruptionX'] = $x;
			$island['AEruptionY'] = $y;
		}
	}
	list($landKind,$lv) = array($land[$x][$y],$landValue[$x][$y]);
	// 해저계 과잉 시 이노라 판정
	if(($island['kaitei'] > $HdisKLimit) && (($landKind == $HlandOil) || ($landKind == $HlandSbase) || ($landKind == $HlandSMonument))){
		$ks = $island['kaitei'] - $HdisKLimit;
		if($ks > 30){$ks = 30;}
		if(random(1000) < $ks){
			$land[$x][$y] = $HlandMonster;
			$landValue[$x][$y] = 905;
			logMonsCome($id, $name, hako_pick(monsterSpec(905), array(1)), "($x, $y)", landName($landKind, $lv));
		}
	}
	list($landKind,$lv) = array($land[$x][$y],$landValue[$x][$y]);
	// 매립 이노라 , 갯바람배판정
	if((($landKind == $HlandSea) && ($lv <= 1)) && ($island['pop'] >= $HdisMonsBorder1)){ # 바다, 얕은 여울, 인구 규정치 1이상
		$r = random($HdisMonsterU);
		if($r == 0){
			if(($HsurvFlg) && ($HdisMonster == 0)){
				// 서바이벌, 괴수 발생율 0의 경우는 출현하지 않는다
			}else{
				$land[$x][$y] = $HlandMonster;
				$landValue[$x][$y] = 1600 + $HmonsterBHP[16] + random($HmonsterDHP[16]);
				logMonsCome($id, $name, hako_pick(monsterSpec(1605), array(1)), "($x, $y)", landName($landKind, $lv));
			}
		}elseif($r < 5){
			$land[$x][$y] = $HlandBalloonS;
			$landValue[$x][$y] = 10000 + (random(6) + 1) * 1000;
			logShipCome($id, $name, landName($HlandBalloonS, 0), "($x, $y)");
		}
	}
	list($landKind,$lv) = array($land[$x][$y],$landValue[$x][$y]);
	// 화재 판정
	if((($landKind == $HlandTown) && ($lv > 30)) ||
			($landKind == $HlandMegacity) ||
			(($landKind == $HlandSlum) && ($lv > 30)) ||
			(($landKind == $HlandOil) && ($lv >= 5)) ||
			($landKind == $HlandHaribote) ||
			($landKind == $HlandFire) ||
			($landKind == $HlandPolice) ||
			($landKind == $HlandHospital) ||
			($landKind == $HlandFactory)){

		$wf = 1000;
		if(($HpunishInfo[$id]['punish'] == 11) &&
			($HpunishInfo[$id]['x'] == $x) &&
			($HpunishInfo[$id]['y'] == $y)){
			$wf = 1;
		}else{
			if($landKind == $HlandOil){
				$wf = 1000;
			}elseif(($whp < 2) && ($wkind < 3)){
				$wf = 500;
			}elseif($wkind > 3){ # 비때
				$wf = ($whp > 7) ? 4000 : 2000;
			}
		}
		if(random($wf) < $HdisFire){
			// 주위의 숲과 기념비를 세는 공원, 풍차도
			$s = chkAround($land, $x, $y, $HlandSMonument, 7);
			if(((chkAround($land, $x, $y, $HlandForest, 7) +
				chkAround($land, $x, $y, $HlandMonument, 7) +
				chkAround($land, $x, $y, $HlandFlower, 7) +
				chkAround($land, $x, $y, $HlandWindmill, 7) +
				chkAround($land, $x, $y, $HlandPark, 7) + $s) == 0) || # 주위에 화재를 막는 지형이 없는 경우
				(($landKind == $HlandOil) && ($s == 0)) || #  해저계로 주위에 해저 기념비가 없는 경우
				(($landKind == $HlandOil) && ($lv == 7)) || # 해저 소방서의 경우
				($landKind == $HlandFire)){ # 소방서의 경우
				$fire1 = chkAround($land, $x, $y, $HlandFire, 19);					# 소방서
				$fire2 = chkAroundEX($land, $landValue, $x, $y, $HlandFire, 10, 37);	# S소방서
				$fire3 = chkAroundEX($land, $landValue, $x, $y, $HlandOil, 7, 19);	# 해저 소방서
				
				if(($fire1 + $fire2) &&
					($landKind != $HlandFire) && ($landKind != $HlandOil)){ # 육지의 화재를 막을 수 있을 때
					if($island['money'] > 50){
						$island['money'] -= 50;
						logFireD($id, $name, landName($landKind, $lv), "($x, $y)");
					}else{
						$land[$x][$y] = $HlandWaste;
						$landValue[$x][$y] = 0;
						logFire($id, $name, landName($landKind, $lv), "($x, $y)");
					}
				}elseif(($fire2 + $fire3) &&
					   ($lv != 7) && ($landKind == $HlandOil)){ # 바다의 화재를 막을 수 있을 때
					if($island['money'] > 100){
						$island['money'] -= 100;
						logFireD($id, $name, landName($landKind, $lv), "($x, $y)");
					}else{
						$land[$x][$y] = $HlandSea;
						$landValue[$x][$y] = 0;
						logFire($id, $name, landName($landKind, $lv), "($x, $y)");
					}
				}elseif($landKind == $HlandOil){
					if($island['order'] & 1024){
						if($lv == 5){
							slideBack($island['command'], 0, $HcomDbase, $id, $x, $y, 0);
						}elseif($lv == 7){
							slideBack($island['command'], 0, $HcomFire, $id, $x, $y, 0);
						}
					}
					$land[$x][$y] = $HlandSea;
					$landValue[$x][$y] = 0;
					logFire($id, $name, landName($landKind, $lv), "($x, $y)");
				}else{
					if(($island['order'] & 1024) && ($landKind == $HlandFire)){
						slideBack($island['command'], 0, $HcomFire, $id, $x, $y, 0);
						slideBack($island['command'], 0, $HcomPrepare2, $id, $x, $y, 0);
					}
					$land[$x][$y] = $HlandWaste;
					$landValue[$x][$y] = 0;
					logFire($id, $name, landName($landKind, $lv), "($x, $y)");
				}
			}
		}
	}
	
	}
} # doEachHex

// 도전체
function doIslandProcess($number, &$island) {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $H_tagName2, $Haidpop, $Hallyflg, $Hallygroup, $haribote, $Hatkturn, $HbackupTimes, $HbackupTurn, $HbgInfoCell, $HbgTitleCell, $HbigcityFood, $HbigCityMFlg, $HcomBank, $HcomBase, $HcomBioMissile, $HcomBreakwater, $Hcomcolony, $HcomcolonyTurn, $HcomCost, $HcomDbase, $HcomDeathtrap, $HcomDestroy, $HcomDestroy2, $HcomDokan, $HcomDoNothing, $HcomDummy, $HcomEmigration, $HcomFactory, $HcomFarm, $HcomFire, $HcomFlower, $HcomFood, $HcomGiveup, $HcomHaribote, $HcomHospital, $HcomL, $HcommandMax, $HcomManipulate, $HcomMissileDM, $HcomMissileGM, $HcomMissileLD, $HcomMissileMGM, $HcomMissileNCM, $HcomMissileNM, $HcomMissilePLD, $HcomMissilePP, $HcomMissileRM, $HcomMissileRNG, $HcomMissileSPP, $HcomMissileSRM, $HcomMissileST, $HcomMoney, $HcomMonsAid, $HcomMonsEgg, $HcomMonsEnsei, $HcomMonsEsa, $HcomMonsEsaAid, $HcomMonsExer, $HcomMonsSell, $HcomMonsTettai, $HcomMonument, $HcomMountain, $HcomMyhome, $HcomName, $HcomOilBuy, $HcomOilSell, $HcomOMissileMGM, $HcomOMissileNM, $HcomOMissilePP, $HcomOMissileSPP, $HcomOreBuy, $HcomOreSell, $HcomPioneer, $HcomPlant, $HcomPolice, $HcomPort, $HcomPrepare, $HcomPrepare2, $HcomPresent, $HcomPresentAid, $HcomPropaganda, $HcomReclaim, $HcomReclaim2, $HcomSbase, $HcomSBuild, $HcomScity, $HcomSDbase, $HcomSDestroy, $HcomSearch, $HcomSEisei, $HcomSell, $HcomSellTree, $HcomSendMonster, $HcomSendMonsterTurn, $HcomSFactory, $HcomSFarm, $HcomSFood, $HcomShip, $HcomShipbuild, $HcomShipM, $HcomShipSell, $HcomSMissile, $HcomSMissileGM, $HcomSMissileMGM, $HcomSMissilePP, $HcomSMonument, $HcomSOccupy, $HcomSpaceBase, $HcomSpaceFarm, $HcomSpecialSPP, $HcomSPioneer, $HcomSpy, $HcomSSendMonster, $HcomSSendMonsterTurn, $HcomSTManipulate, $HcomSUnit, $HcomTeisatu, $HcomTower, $HcomTrump, $HcomUg, $HcomWarp, $HcomWeponBuy, $HcomWeponSell, $HcomWindmill, $HconsolationMatch, $HcurrentNumber, $HdBaseAuto, $HdefenceHex, $HdefenceSpace, $HdevelopeTurn, $HdirMode, $HdirName, $HdisAEruption, $HdisAkasio, $HdisBHarvest, $HdisCrime, $HdisEarthquake, $HdisEruption, $HdisFallBorder, $HdisFalldown, $HdisFire, $HdisGHarvest, $Hdishangen, $HdisHugeMeteo, $HdisKLimit, $HdisMaizo, $HdisMeteo, $HdisMonsBorder1, $HdisMonsBorder2, $HdisMonsBorder3, $HdisMonsBorder4, $HdisMonsBorder5, $HdisMonster, $HdisMonsterU, $HdisPirate, $HdisPollution, $HdisSeaMonster, $HdisSHugeMeteo, $HdisSpaceMonster1, $HdisSpaceMonster2, $HdisTinka, $HdisTreasureS, $HdisTsunami, $HdisTyphoon, $HdisUN, $HdisVGHarvest, $HearthAttack, $HeatenFood, $helpDir, $HfightMem, $HfightTurn, $HfinalTurn, $HgiveupTurn, $HhistoryMax, $HidToName, $HidToNumber, $HidToNumberR, $HinterTime, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HlandAegisShip, $HlandAirport, $HlandAmusement, $HlandBalloonS, $HlandBank, $HlandBase, $HlandBigcity, $HlandBreakwater, $HlandCasino, $HlandCoupleRock, $HlandDeathtrap, $HlandDefence, $HlandDokan, $HlandDome, $HlandEarth, $HlandExpo, $HlandFactory, $HlandFarm, $HlandFire, $HlandFishLShip, $HlandFishMShip, $HlandFishSShip, $HlandFlower, $HlandForest, $HlandFuji, $HlandGhostShip, $HlandHaribote, $HlandHospital, $HlandHugecity, $HlandIceFloe, $HlandKInora, $HlandMegacity, $HlandMegaFact, $HlandMegaFarm, $HlandMegatower, $HlandMonsShip, $HlandMonster, $HlandMonument, $HlandMountain, $HlandMyhome, $HlandOcean, $HlandOil, $HlandOPlayer, $HlandOsen, $HlandPark, $HlandPirate, $HlandPlains, $HlandPolice, $HlandPort, $HlandProbeShip, $HlandSAEisei, $HlandSbase, $HlandSchool, $HlandSCity, $HlandSDefence, $HlandSea, $HlandSeisei, $HlandSFactory, $HlandSFarm, $HlandSlum, $HlandSMonument, $HlandSpaceBase, $HlandStadium, $HlandSunit, $HlandTcity, $HlandTitanic, $HlandTower, $HlandTown, $HlandTreasureS, $HlandTrump, $HlandWarp, $HlandWarpR, $HlandWaste, $HlandWindmill, $HlandWingDragon, $HlandZoo, $HlateLogPool, $HlogMax, $HlogOmit2, $HlogPool, $HmaxdisPollution, $HmaxExpPoint, $HmaxIsland, $HmonsBtlMaxHp, $HmonsBtlMaxPa, $HmonsterAGI, $HmonsterBHP, $HmonsterCLS, $HmonsterDEF, $HmonsterDestroy, $HmonsterDHP, $HmonsterExp, $HmonsterGRP, $HmonsterL1, $HmonsterL1Num, $HmonsterL2, $HmonsterL2Num, $HmonsterL3, $HmonsterL3Num, $HmonsterL4, $HmonsterL4Num, $HmonsterL5, $HmonsterL5Num, $HmonsterName, $HmonsterNumber, $HmonsterS, $HmonsterSEI, $HmonsterSKL, $HmonsterSP, $HmonsterSpecial, $HmonsterSTR, $HmonsterValue, $Hmonth, $HmonumentMissile, $HmonumentName, $HmonumentRocket, $Hocean, $HoceanSize, $HoilMoney, $HoilRatio, $hp, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $Hprize, $HprizeV, $HpunishInfo, $HrepeatTurn, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $HseaChk, $HsecretLogPool, $HsEisei, $HshipEX, $HshipFood, $HshipHP, $HshipKAI, $HshipMATK, $HshipMoney, $HshipName, $Hshiporder, $HshipSATK, $HshipSell, $HshipSP, $HsmonumentName, $HsmonumentNumber, $Hsolarwind, $Hspace, $HspaceEfficiency, $HspaceIncome, $Hsstartturn, $HStotalPoint, $HsurvFlg, $Hsurvivalturn, $HtagName2_, $HthisFile, $HtotalBumon, $HtotalMoney, $HtotalPoint, $Htournament, $HtreeValue, $HturnPrizeNumber, $HturnPrizePoint, $HturnPrizeUnit, $HturnPrizeVarious, $HugDokan, $HugFact, $HugFarm, $HugHasigo, $HugKiti, $HugMax, $HugOil, $HugRoad, $HugSpace, $HugTosi, $human, $HunitFood, $HunitMoney, $HunitOil, $HunitOre, $HunitPop, $HunitTime, $HunitWeapon, $HwarFlg, $HWeatherMax, $Hwflg, $HwinFood, $HwinIsland, $HwinMoney, $HwinWeapon, $imageDir, $lockMode, $toppage, $versionInfo;

	// 도출치
	$name = $island['name']; $id = $island['id']; $land =& $island['land']; $landValue =& $island['landValue']; $land2 =& $island['land2']; $landValue2 =& $island['landValue2'];
	if($island['SSSystem']){
	//	logEvent($id, $name,"는,<B>슈퍼 쉴드(shield) 시스템</B>을 발동중!");
	}else{

	// 구상 이노라 판정(제재만)
	if($HpunishInfo[$id]['punish'] == 10){
		$x = null; $y = null;
		$x = $HpunishInfo[$id]['x'];
		$y = $HpunishInfo[$id]['y'];
		$landKind = $land[$x][$y];
		$lv = $landValue[$x][$y];
		logMonsCome($id, $name, landName($HlandKInora, 0), "($x, $y)", landName($landKind,$lv));
		$land[$x][$y] = $HlandKInora;
		$landValue[$x][$y] = 50000 + (random(60) * 100) + 4000;
		kinoraMake($land, $landValue, $x, $y);
	}
	
	if($id > 90){
		// Battle Field 때
		$island['tenki'] = 0;
		$island['area'] = 0;
		$island['forest'] = 0;

		$island['pop']  = -$island['id'];
		$island['farm'] = 0;
		$island['port'] = 0;
		$island['factory']  = 0;
		$island['tower']    = 0;
		$island['mountain'] = 0;
		$island['yousyoku'] = 0;
		$island['kaitei'] = 0;
		$island['MissileK'] = 0;

		$island['oilfield']  = 0;
		$island['mons'] = 0;
		$island['forestV']  = 0;
		$island['haribote'] = 0;
		$island['industry'] = 0;
		$island['monument'] = 0;

		$island['evil'] = 200;
		$island['zyuni'] = 0;
		$island['status'] = 0;
		$island['score'] = 0;
		$island['absent'] = 0;
		$island['turnsu'] = 1000;
		
		$island['ship'] = 0;
		$island['flower'] = 0;
		return;
	}
//	HdebugOut($island['name'] . "$AfterName 위성:" . $island['eis0'] . ":" . $island['eis1'] . ":" . $island['eis2']);
	$disTyphoon		= ($island['eis0']) ? intval($HdisTyphoon / 2) : $HdisTyphoon;
	$disAkasio		= ($island['eis0']) ? intval($HdisAkasio / 2) : $HdisAkasio;
	$disEarthquake	= ($island['eis1']) ? intval($HdisEarthquake / 2) : $HdisEarthquake;
	$disTsunami		= ($island['eis1']) ? intval($HdisTsunami / 2) : $HdisTsunami;
	$disEruption		= ($island['eis1']) ? intval($HdisEruption / 2) : $HdisEruption;
	$disMeteo		= ($island['eis2']) ? intval($HdisMeteo / 2) : $HdisMeteo;
	$disHugeMeteo	= ($island['eis2']) ? intval($HdisHugeMeteo / 2) : $HdisHugeMeteo;

	// 지진 판정
	if(($HpunishInfo[$id]['punish'] == 1) ||
		(random(1000) < (($island['prepare2'] + 1) * $disEarthquake))){
		// 지진 발생
		$x = null; $y = null; $sx = null; $sy = null; $i = null;
		if($HpunishInfo[$id]['punish'] == 1){
			$x = $HpunishInfo[$id]['x'];
			$y = $HpunishInfo[$id]['y'];
		}else{
			$x = random($HislandSize);
			$y = random($HislandSize);
		}
		if(chkAround($land, $x, $y, $HlandAmusement, $x)){
			// 발생하지 않는다!
		}else{
			logEarthquake($id, $name, "($x, $y)");
			// 진원이 바다라면 해일 발생
			if ($HseaChk[$land[$x][$y]]) { $island['tunami'] = 1; }
			// 주위 4 헥스에 피해
			for($i = 0; $i < 61; $i++){
				$sx = $x + $ax[$i];
				$sy = $y + $ay[$i];
				if (!($sy % 2) && ($y % 2)) { $sx--; }
				$landKind = $land[$sx][$sy];
				$lv = $landValue[$sx][$sy];
				$landName = landName($landKind, $lv);
				$point = "($sx, $sy)";
				if (($sx < 0) || ($sx >= $HislandSize) || ($sy < 0) || ($sy >= $HislandSize)) { continue; }
				$d = 0;
				if((($landKind == $HlandTown) && ($lv >= 50)) ||
					(($landKind == $HlandSlum) && ($lv >= 30)) ||
					($landKind == $HlandHaribote) || ($landKind == $HlandFactory)){
				// 5천 이상의 마을, 3천 이상의 slum, 위장 방위 시설, 공장
					if($i == 0){
						$d = 200;
					}elseif($i < 7){
						$d = (random(5) + 3) * 10;
					}elseif($i < 19){
						$d = (random(4) + 1) * 10;
					}elseif($i < 37){
						$d = random(3) * 10;
					}else{
						$d = random(2) * 10;
					}
					if(($landKind == $HlandTown) || ($landKind == $HlandSlum)){$d = $d * 3;}
					if($d >= 150){
						logEQDestroy($id, $name, $landName, $point);
						$landKind = $HlandWaste;
						$lv = 0;
					}elseif($d != 0){
						if(($lv <= $d) || ($landKind == $HlandHaribote) ||
							(($landKind == $HlandFactory) && ($lv < $d + 30))){
							logEQDestroy($id, $name, $landName, $point);
							$landKind = $HlandWaste;
							$lv = 0;
						}else{
							$lv -= $d;
							logEQDamage($id, $name, $landName, $point);
						}
					}
					$land[$sx][$sy] = $landKind;
					$landValue[$sx][$sy] = $lv;
				}
			}
		}
	}

	// 식량 부족
	if($island['food'] <= 0){
		// 부족 메세지
		logStarve($id, $name);
		$island['food'] = 0;
		$x = null; $y = null; $landKind = null; $lv = null; $i = null; $lName = null;
		for($i = 0; $i < $HpointNumber; $i++){
			$x = $Hrpx[$i];
			$y = $Hrpy[$i];
			$landKind = $land[$x][$y];
			$lName = landName($landKind, $landValue[$x][$y]);
			if(($landKind == $HlandFarm) ||
				($landKind == $HlandFactory) ||
				($landKind == $HlandBase) ||
				($landKind == $HlandBigcity) ||
				($landKind == $HlandHugecity) ||
				($landKind == $HlandDefence)){
				// 1/4 그리고  괴멸
				if(random(4) == 0){
					if($kind == $HlandHugecity){
						// 초거대도시
						$lName2 = landName($HlandMonument, $landValue[$x][$y]);
						logEventP($id, $island['name'],"($x, $y)", "의<B> $lName</B>에<식량를 요구해 주민이 쇄도</B>. <B>$lName</B>는<B>$lName2</B>에 돌아가 버렸습니다.");
						$land[$x][$y] = $HlandMonument;
					}else{
						logSvDamage($id, $name, $lName,"($x, $y)");
						$land[$x][$y] = $HlandWaste;
						$landValue[$x][$y] = 0;
					}
				}
			}
		}
	}

	// 해일 판정
	if(($HpunishInfo[$id]['punish'] == 2) ||
		((random(1000) < $disTsunami) || ($island['tunami'] >= 1))){
		// 해일 발생
		$x = null; $y = null; $landKind = null; $lv = null; $i = null; $p = null; $q = null;
		if($island['tunami'] == 1){ # 해저 지진에 의한 큰 해일
			logEvent($id, $name,"의 지진은, 진원이 바다였기 때문에 ${HtagDisaster_}큰 해일 ${H_tagDisaster}발생!");
			$p = 10;
			$q = 25;
		}else{ # 통상의 해일, 콜로니 오토시의 해일
			logEvent($id, $name,"부근에서 ${HtagDisaster_}해일 ${H_tagDisaster}발생!");
			$p = 12;
			$q = 30;
		}
		for($i = 0; $i < $HpointNumber; $i++){
			$x = $Hrpx[$i];
			$y = $Hrpy[$i];
			$landKind = $land[$x][$y];
			$lv = $landValue[$x][$y];

			if(($landKind == $HlandTown) ||
				($landKind == $HlandSlum) ||
				($landKind == $HlandFarm) ||
				($landKind == $HlandFactory) ||
				($landKind == $HlandBase) ||
				($landKind == $HlandDefence) ||
				($landKind == $HlandPort) ||
				($landKind == $HlandHaribote)){
				if(random($p) < (seaAround($land, $x, $y, 7, 1) - 1)){
					if(($landKind == $HlandTown) && ($lv >= 60) && (random(2) == 0)){
						logTsunamiDamage($id, $name, landName($landKind, $lv),"($x, $y)","피해가 감소");
						$landValue[$x][$y] -= random(40) + 20;
					}elseif(($landKind == $HlandBase) && ($lv > 0) && (random(3) < 2)){
						logTsunamiDamage($id, $name, landName($landKind, $lv),"($x, $y)","피해가 감소");
						$landValue[$x][$y] = random($lv) + 1;
					}elseif(($landKind == $HlandFarm) && ($lv > 10) && (random(3) < 2)){
						logTsunamiDamage($id, $name, landName($landKind, $lv),"($x, $y)","피해가 감소");
						$landValue[$x][$y] = 10;
					}elseif(($landKind == $HlandFactory) && ($lv > 30) && (random(3) < 2)){
						logTsunamiDamage($id, $name, landName($landKind, $lv),"($x, $y)","피해가 감소");
						$landValue[$x][$y] = 30;
					}elseif(($landKind == $HlandPort) && ($lv > 40) && (random(3) < 2)){
						logTsunamiDamage($id, $name, landName($landKind, $lv),"($x, $y)","피해가 감소");
						$landValue[$x][$y] = 40;
					}else{
						logTsunamiDamage($id, $name, landName($landKind, $lv),"($x, $y)","붕괴 ");
						$land[$x][$y] = $HlandWaste;
						$landValue[$x][$y] = 0;
					}
				}
			}elseif(($landKind == $HlandSea) && ($lv >= 10)){
				if(random($q) < (seaAround($land, $x, $y, 7, 1) - 1)){
					logTsunamiDamage($id, $name, landName($landKind, $lv),"($x, $y)", "붕괴 ");
					$land[$x][$y] = $HlandSea;
					$landValue[$x][$y] = 1;
				}
			}
		}
	}

	// 괴수 판정
	$r = random(10000);
	if ($island['towerD']) { $r -= 100; }
	$pop = $island['pop'];
	if ($HpunishInfo[$id]['punish'] == 3) { $r = 0; }
	do{
	if((($r < ($HdisMonster * $island['area'])) && ($pop >= $HdisMonsBorder1)) ||
		($island['monstersend'] + $island['monstersend1'] + $island['monstersend2'] + $island['monstersend3'] + $island['TeruteruMons'] + $island['monsEnsei'] > 0)){
		// 괴수 출현
		// 종류를 결정한다
		$lv = null; $kind = null; $human = null;
		$human = 0;
		if($island['monsEnsei'] > 0){
			// S괴수 파견?
			$kind = $island['monsEnsei'];
			$human = 1;
			$island['monsEnsei'] = 0;
		}elseif($island['monstersend'] > 0){
			// 인조
			$kind = 0;
			$human = 1;
			$island['monstersend']--;
		}elseif($island['monstersend1'] > 0){
			// 인조
			$kind = 11;
			$human = 1;
			$island['monstersend1']--;
		}elseif($island['monstersend2'] > 0){
			// 인조
			$kind = 22;
			$human = 1;
			$island['monstersend2']--;
		}elseif($island['monstersend3'] > 0){
			// 인조
			$kind = 25;
			$human = 1;
			$island['monstersend3']--;
		}elseif($island['TeruteruMons'] > 0){
			// 테루테루 이노라 (28),# 반대 비치는 비친다(29)
			$kind = ($island['TeruteruMons'] == 1) ? 28 : 29;
			$island['TeruteruMons'] = 0;
		}elseif($pop >= $HdisMonsBorder5){
			// level5까지
			$kind = $HmonsterL5[random($HmonsterL5Num)];
		}elseif($pop >= $HdisMonsBorder4){
			// level4까지
			$kind = $HmonsterL4[random($HmonsterL4Num)];
		}elseif($pop >= $HdisMonsBorder3){
			// level3까지
			$kind = $HmonsterL3[random($HmonsterL3Num)];
		}elseif($pop >= $HdisMonsBorder2){
			// level2까지
			$kind = $HmonsterL2[random($HmonsterL2Num)];
		}else{
			//  level1만
			$kind = $HmonsterL1[random($HmonsterL1Num)];
		}

		// lv의 값을 결정한다
		$lv = $kind * 100 + $HmonsterBHP[$kind] + random($HmonsterDHP[$kind]);

		// 어디에 나타날까 결정한다
		$bx = null; $by = null; $i = null;
		for($i = 0; $i < $HpointNumber; $i++){
			$bx = $Hrpx[$i];
			$by = $Hrpy[$i];
			if($kind == 25){
				// 해저 메카 이노라

				if(($land[$bx][$by] == $HlandOil) && ($landValue[$bx][$by] >= 35)){
					logMonsCome($id, $name, hako_pick(monsterSpec($lv), array(1)), "($bx, $by)", landName($land[$bx][$by], $landValue[$bx][$by]));
					$land[$bx][$by] = $HlandMonster;
					$landValue[$bx][$by] = $lv;
break;
				}
			}elseif(($land[$bx][$by] == $HlandTown) || ($land[$bx][$by] == $HlandSlum) ||
				(($land[$bx][$by] == $HlandBigcity) && ($HbigCityMFlg)) || ($land[$bx][$by] == $HlandWindmill)){
				// 그 헥스를 괴수에게
				if($human != 1){
					if(chkAround($land, $bx, $by, $HlandZoo, 19)){
						$i += $HislandSize * 3;
						$human = 1;
continue;
					}
				}
				logMonsCome($id, $name, hako_pick(monsterSpec($lv), array(1)), "($bx, $by)", landName($land[$bx][$by], $landValue[$bx][$by]));
				$land[$bx][$by] = $HlandMonster;
				$landValue[$bx][$by] = $lv;
break;
			}
		}
		if(($i >= $HpointNumber) && (($island['kaiteipop'] == 1) || ($HearthAttack > 0))){
			// 해저의 인구가 육상보다 많을 때에 출현하는 지형이 없을 때(지구 공격시도)는, 숲이나 미사일 기지에 나온다.
			for($i = 0; $i < $HpointNumber; $i++){
				$bx = $Hrpx[$i];
				$by = $Hrpy[$i];
				if(($land[$bx][$by] == $HlandBase) || ($land[$bx][$by] == $HlandForest)){
					// 그 헥스를 괴수에게
					logMonsCome($id, $name, hako_pick(monsterSpec($lv), array(1)), "($bx, $by)", landName($land[$bx][$by], $landValue[$bx][$by]));

					$land[$bx][$by] = $HlandMonster;
					$landValue[$bx][$by] = $lv;
break;

				}
			}
		}
	}
	} while($island['monstersend'] + $island['monstersend1'] + $island['monstersend2'] + $island['monstersend3'] > 0);

	// 미사일수에 의한 괴수 판정(r=0-9999)
	if(($r > 9969) && ($island['MissileK'] >= 30) && ($HdisMonster > 0)){
		$lv = null; $kind = null;
		if($r > 9994){
			$kind = 17; # 타임보칸
		}elseif($r > 9989){ 
			$kind = 18; # 반격
		}elseif($r > 9984){ 
			$kind = 20; # 스페이스
		}elseif($r > 9979){ 
			$kind = 21; # 시고스트
		}elseif($r > 9974){ 
			$kind = 30; # 회복 이노라
		}else{ 
			$kind = 23; # 카네곤
		}
		$lv = $kind * 100 + $HmonsterBHP[$kind] + random($HmonsterDHP[$kind]);
		list($mKind, $mName, $mHp) = monsterSpec($lv);

		// 어디에 나타날까 결정한다
		$bx = null; $by = null; $i = null;
		for($i = 0; $i < $HpointNumber; $i++){
			$bx = $Hrpx[$i];
			$by = $Hrpy[$i];
			if($kind == 21){
				// 시고스트
				if(($land[$bx][$by] == $HlandOil) && ($landValue[$bx][$by] >= 35)){
					logMonsCome($id, $name, $mName, "($bx, $by)", landName($land[$bx][$by], $landValue[$bx][$by]));
					$land[$bx][$by] = $HlandMonster;
					$landValue[$bx][$by] = $lv;
					$r = 100;
break;
				}
			}elseif(($land[$bx][$by] == $HlandTown) || ($land[$bx][$by] == $HlandSlum) || ($land[$bx][$by] == $HlandWindmill)){
				logMonsCome($id, $name, $mName, "($bx, $by)", landName($land[$bx][$by], $landValue[$bx][$by]));
				$land[$bx][$by] = $HlandMonster;
				$landValue[$bx][$by] = $lv;
				$r = 100;
break;
			}
		}
	}

	// 지반침하 판정
	if((($HpunishInfo[$id]['punish'] == 4) || (random(1000) < $HdisFalldown)) && ($island['area'] > $HdisFallBorder)){
		// 지반침하 발생
		logFalldown($id, $name);
		$x = null; $y = null; $landKind = null; $lv = null; $i = null;
		for($i = 0; $i < $HpointNumber; $i++){
			$x = $Hrpx[$i];
			$y = $Hrpy[$i];
			$landKind = $land[$x][$y];
			$lv = $landValue[$x][$y];
			if(($HseaChk[$landKind] == 0) &&
				($landKind != $HlandMountain)){
				// 주위에 바다가 있으면, 값을―1에
				if(seaAround($land, $x, $y, 7)){
					logFalldownLand($id, $name, landName($landKind, $lv), "($x, $y)");
					$land[$x][$y] = -1;
					$landValue[$x][$y] = 0;
				}
			}
		}
		for($i = 0; $i < $HpointNumber; $i++){
			$x = $Hrpx[$i];
			$y = $Hrpy[$i];
			$landKind = $land[$x][$y];
			if($landKind == -1){
				// -1(이)가 되어 있는 곳을 얕은 여울에
				$land[$x][$y] = $HlandSea;
				$landValue[$x][$y] = 1;
			}elseif(($landKind == $HlandSea) || ($landKind == $HlandBreakwater)){
				// 얕은 여울, 방파제는 바다에
				$land[$x][$y] = $HlandSea;
				$landValue[$x][$y] = 0;
			}
		}
	}

	// 태풍 판정
	if(($HpunishInfo[$id]['punish'] == 5) || (random(1000) < $disTyphoon)){
		// 태풍 판정
		logTyphoon($id, $name);
		$island['weather'] = 59;
		$x = null; $y = null; $landKind = null; $i = null;
		for($i = 0; $i < $HpointNumber; $i++){
			$x = $Hrpx[$i];
			$y = $Hrpy[$i];
			$landKind = $land[$x][$y];
			if(($landKind == $HlandFarm) || ($landKind == $HlandHaribote) || ($landKind == $HlandWindmill) || ($landKind == $HlandBreakwater)){
				// 1d12 <= (6 - 주위의 숲)로 붕괴
				$j = null; $tx = null; $ty = null;
				$count = 6;
				for($j = 0; $j < 7; $j++){
					$tx = $x + $ax[$j];
					$ty = $y + $ay[$j];
					if (!($ty % 2) && ($y % 2)) { $tx--; }
					if(($tx < 0) || ($tx >= $HislandSize) || ($ty < 0) || ($ty >= $HislandSize)){
					}elseif(($land[$tx][$ty] == $HlandMonument) || ($land[$tx][$ty] == $HlandSMonument) || ($land[$tx][$ty] == $HlandForest) || ($land[$tx][$ty] == $HlandFlower) ||
							($land[$tx][$ty] == $HlandWindmill) || ($land[$tx][$ty] == $HlandPark)){
						$count--;
					}
				}
				if(random(12) < $count){
					// S소방서가 있으면 태풍의 확률 반감
					if ((chkAroundEX($land, $landValue, $x, $y, $HlandFire, 10, 37)) && (random(2) == 0)) { continue; }
					$lv = $landValue[$x][$y];
					if($landKind == $HlandBreakwater){
						if (!(random(10) == 0)) { continue; }
						logTyphoonDamage($id, $name, landName($landKind, $lv),"($x, $y)","파괴 되었습니다.");
						$land[$x][$y] = $HlandSea;
						$landValue[$x][$y] = 1;
					}elseif(($landKind == $HlandFarm) && ($lv > 21)){
						logTyphoonDamage($id, $name, landName($landKind, $lv),"($x, $y)","피해를 받지 않았습니다");
						$landValue[$x][$y] = $lv - 10;
					}elseif(($landKind == $HlandFarm) && ($lv > 13)){
						logTyphoonDamage($id, $name, landName($landKind, $lv),"($x, $y)","피해를 받지 않았습니다.");
						$landValue[$x][$y] = 10;
					}else{
						logTyphoonDamage($id, $name, landName($landKind, $lv),"($x, $y)","날아가 버렸습니다.");
						$land[$x][$y] = $HlandPlains;
						$landValue[$x][$y] = 0;
					}
				}
			}elseif(($landKind == $HlandFishSShip) || ($landKind == $HlandFishMShip)){
				// 소형, 중형 어선
				if(random(10) == 0){
					logTyphoonDamage($id, $name, landName($landKind, $lv),"($x, $y)","난파해");
					if(random(20) == 0){
						//  유령배
						$land[$x][$y] = $HlandGhostShip;
						$landValue[$x][$y] = $HshipHP[$HlandGhostShip - $HlandPirate] * 1000;
					}else{
						$land[$x][$y] = $land2[$x][$y];
						$landValue[$x][$y] = $landValue2[$x][$y];
						$land2[$x][$y] = $HlandSea;
						$landValue2[$x][$y] = 0;
					}
				}
			}
		}
	}

	// 적조 판정
	if((random(1000) < $disAkasio + intval($island['yousyoku'] / 200)) && ($disAkasio != 0)){
		if($island['yousyoku'] > 0){
		// 적조 발생
		logEvent($id, $name,"에 ${HtagDisaster_}적조 ${H_tagDisaster}발생!");
		$x = null; $y = null; $landKind = null; $lv = null; $i = null; $p = null;
		for($i = 0; $i < $HpointNumber; $i++){
			$x = $Hrpx[$i];
			$y = $Hrpy[$i];
			$landKind = $land[$x][$y];
			if(($landKind == $HlandSea) && ($landValue[$x][$y] >= 10)){
				// 1d10 <= (주위 2 매스의 공장 또는 마을계)로 붕괴
				$p = countAround($land, $x, $y, $HlandFactory, 19) + countAround($land, $x, $y, $HlandTown, 19);
				$p = ($p * 10) + intval($island['yousyoku'] / 300);
				if (random(100) < $p){
					logAkasioDamage($id, $name, landName($landKind, 10),"($x, $y)");
					$land[$x][$y] = $HlandSea;
					$landValue[$x][$y] = 1;
				}
			}
		}
		}
	}
	
	
	$pirate = 1000;
	if($island['treasure'] > 0){
		// 보물선 존재시, 해적선 출현 확률이 2배가 된다
		$pirate = 500;
	}else{
		// 보물선이 존재하지 않을 때 보물선 출현 판정, 여객선이 있는 만큼으로 싸진다.
		if(random(1000) < $HdisTreasureS + $island['titanic'] * 0.4){
			list($x, $y) = shipAppear($land, random(4));

			// 지형 보존
			$land2[$x][$y] = $land[$x][$y];
			$landValue2[$x][$y] = $landValue[$x][$y];
			$land[$x][$y] = $HlandTreasureS;
			$landValue[$x][$y] = 10000 + $HshipHP[$HlandTreasureS - $HlandPirate] * 1000;

			logShipCome($id, $name, landName($HlandTreasureS, 0), "($x, $y)");
		}
	}
	// 해적선, 유령배, 익룡 출현 판정 어선이 10척이상이라면으로 싸진다.
	$fishship = $island['fishShip'];
	if ($fishship < 10) { $fishship = 0; }
	$ship  = random($pirate);
	do{
	if(($ship < $HdisPirate + $fishship * 0.1) || 
		($island['piratesend'] + $island['ghost'] + $island['wingdragon'] + 
			$island['icefloe'] + $island['couplerock'] > 0)){
		list($x, $y) = shipAppear($land, random(4));
		
		// 지형 보존
		$land2[$x][$y] = $land[$x][$y];
		$landValue2[$x][$y] = $landValue[$x][$y];
		
		$newship = null; $point = null;
		if($island['wingdragon'] > 0){
			// 익룡
			$newship = $HlandWingDragon;
			$landValue[$x][$y] = 10000 + $HshipHP[$newship - $HlandPirate] * 1000;
			$island['wingdragon'] = 0;
			$point = "($x, $y)";
		}elseif($island['icefloe'] > 0){
			// 유빙
			$newship = $HlandIceFloe;
			$landValue[$x][$y] = 10000 + $HshipHP[$newship - $HlandPirate] * 1000;
			$island['icefloe'] = 0;
			$point = "($x, $y)";
		}elseif($island['couplerock'] > 0){
			// 부부바위
			$newship = $HlandCoupleRock;
			$landValue[$x][$y] = 10000 + $HshipHP[$newship - $HlandPirate] * 1000;
			$island['couplerock'] = 0;
			$point = "($x, $y)";
		}elseif($island['ghost'] > 0){
			// 유령배
			$newship = $HlandGhostShip;
			$landValue[$x][$y] = $HshipHP[$newship - $HlandPirate] * 1000;
			$island['ghost'] = 0;
			$point = "(?, ?)";
		}else{
			// 해적선
			$newship = $HlandPirate;
			$landValue[$x][$y] = $HshipHP[$newship - $HlandPirate] * 1000 + $island['piratesend'];
			$island['piratesend'] = 0;
			$point = "($x, $y)";
		}
		$land[$x][$y] = $newship;
		logShipCome($id, $name, landName($newship, 0), $point);
	}
	} while($island['piratesend'] + $island['ghost'] + $island['wingdragon'] + $island['icefloe'] + $island['couplerock'] > 0);
	// 거대 운석 판정
	if(($HpunishInfo[$id]['punish'] == 6) || (random(1000) < $disHugeMeteo)){
		$x = null; $y = null;
		if($HpunishInfo[$id]['punish'] == 6){
			$x = $HpunishInfo[$id]['x'];
			$y = $HpunishInfo[$id]['y'];
		}else{
			$x = random($HislandSize);
			$y = random($HislandSize);
		}
		// S, SS방위 시설
		if(($land[$x][$y] != $HlandDefence) && 
			(chkAroundEX($land, $landValue, $x, $y, $HlandDefence, 2, 19) + chkAroundEX($land, $landValue, $x, $y, $HlandDefence, 3, 19))){
			// S, SS방위 시설에서 막는다(두상 이외)
			logMeteoD($id, $name, landName($land[$x][$y], $landValue[$x][$y]), "($x, $y)", '거대 운석');
		}else{
			logHugeMeteo($id, $name, "($x, $y)");
			wideDamage($id, $name, $land, $landValue, $x, $y, 0);
		}
	}

	// 거대 미사일 판정
	while($island['bigmissile'] > 0){
		$island['bigmissile']--;
		$x = random($HislandSize);
		$y = random($HislandSize);
		logMonDamage($id, $name, "($x, $y)");
		// 광역 피해 루틴
		wideDamage($id, $name, $land, $landValue, $x, $y, 0);
	}
	// 콜로니 오토시 판정
	while($island['colony'] > 0){
		$island['colony']--;
		$x = random($HislandSize);
		$y = random($HislandSize);
		logMonDamage($id, $name, "($x, $y)");
		// 광역 피해 루틴
		SuperDamage($id, $name, $land, $landValue, $x, $y);
	}

	// 운석 판정
	if(($HpunishInfo[$id]['punish'] == 7) ||
		(random(1000) < (($island['Meteo'] + 1) * $disMeteo))){
		$x = null; $y = null; $landKind = null; $lv = null; $point = null; $first = null;
		$first = 1;
		while((random(2) == 0) || ($first == 1)){
			$first = 0;
			
			// 낙하
			$x = random($HislandSize);
			$y = random($HislandSize);
			$landKind = $land[$x][$y];
			$lv = $landValue[$x][$y];
			$point = "($x, $y)";
			//  S, SS방위 시설
			if(($landKind != $HlandDefence) && 
				(chkAroundEX($land, $landValue, $x, $y, $HlandDefence, 2, 19) + chkAroundEX($land, $landValue, $x, $y, $HlandDefence, 3, 19))){
				//  S, SS방위 시설에서 막는다(두상 이외)
				logMeteoD($id, $name, landName($landKind, $lv), $point, '운석');
continue;
			}
			// 이지스 함 체크
			if($island['aegis'] > 4){
				$island['aegis'] -= 5;
//				HdebugOut("이지스 함 요격 준비:" . $island['money']);
				if((random(3) == 0) && ($island['money'] > 500)){
					$island['money'] -= 500;
					logMeteoD($id, $name, landName($landKind, $lv), $point, '운석');
continue;
				}
			}
			
			if(($landKind == $HlandSea) && ($lv == 0)){
				// 바다 포체
				logMeteoSea($id, $name, landName($landKind, $lv), $point);
			}elseif($landKind == $HlandMountain){
				// 산파괴
				logMeteoMountain($id, $name, landName($landKind, $lv), $point);
				$land[$x][$y] = $HlandWaste;
				$landValue[$x][$y] = 0;
continue;
			}elseif($landKind == $HlandSbase){
				logMeteoSbase($id, $name, landName($landKind, $lv), $point);
			}elseif($landKind == $HlandMonster){
				logMeteoMonster($id, $name, landName($landKind, $lv), $point);
			}elseif(($landKind == $HlandSea) || ($landKind == $HlandBreakwater)){
				// 얕은 여울, 방파제
				logMeteoSea1($id, $name, landName($landKind, $lv), $point);
			}elseif($landKind == $HlandWarp){
				// 전이
				logWarpMeteo($id, $name, landName($landKind, $lv), $point);
	//			$land[$x][$y] = $HlandWaste;
	//			$landValue[$x][$y] = 0;
				$st = warp($id, $name, 0, 0, "운석", $lv, 12);
continue;
			}else{
				logMeteoNormal($id, $name, landName($landKind, $lv), $point);
			}
			$land[$x][$y] = $HlandSea;
			$landValue[$x][$y] = 0;
		}
	}

	// 분화 판정
	if(($HpunishInfo[$id]['punish'] == 8) ||
		((random(1000) < $disEruption) || ($island['AEruption'] != 0))){
		$x = null; $y = null; $sx = null; $sy = null; $landKind = null; $lv = null;
		$i = 1;
		if($island['AEruption'] == 0){
			if($HpunishInfo[$id]['punish'] == 8){
				$x = $HpunishInfo[$id]['x'];
				$y = $HpunishInfo[$id]['y'];
			}else{
				$x = random($HislandSize);
				$y = random($HislandSize);
			}
			if(chkAround($land, $x, $y, $HlandSchool, 7)){
				$i = 10;
			}
			logEruption($id, $name, landName($land[$x][$y], $landValue[$x][$y]),"($x, $y)", "분화");
		}else{
			$x = $island['AEruptionX'];
			$y = $island['AEruptionY'];
			logEruption($id, $name, landName($land[$x][$y], $landValue[$x][$y]), "($x, $y)", "재분화");
		}
		$land[$x][$y] = $HlandMountain;
		$landValue[$x][$y] = 0;
		for( ; $i < 7; $i++){
			$sx = $x + $ax[$i];
			$sy = $y + $ay[$i];
			if (!($sy % 2) && ($y % 2)) { $sx--; }
			$landKind = $land[$sx][$sy];
			$lv = $landValue[$sx][$sy];
			if (($sx < 0) || ($sx >= $HislandSize) || ($sy < 0) || ($sy >= $HislandSize)){
			}else{
				// 범위내의 경우
				$landKind = $land[$sx][$sy];
				$lv = $landValue[$sx][$sy];
				if($HseaChk[$landKind]){
					// 바다의 경우
					if((($landKind == $HlandSea) && ($lv >= 1)) || ($landKind == $HlandBreakwater)){
						// 얕은 여울, 방파제
						logEruptionSea1($id, $name, landName($landKind, $lv), "($sx, $sy)");
					}else{
						logEruptionSea($id, $name, landName($landKind, $lv), "($sx, $sy)");
						$land[$sx][$sy] = $HlandSea;
						$landValue[$sx][$sy] = 1;
continue;
					}
				}elseif(($landKind == $HlandMountain) || ($landKind == $HlandMonster) ||
						(($landKind == $HlandWaste) && ($lv == 1))){
continue;
				}else{
					// 그 이외의 경우
					logEruptionNormal($id, $name, landName($landKind, $lv), "($sx, $sy)");
				}
				$land[$sx][$sy] = $HlandWaste;
				$landValue[$sx][$sy] = 0;
			}
		}
	}

	}#SSSystem

	// 괴수 배틀

	
	// 각 요소의 꺼내
	$monster =& $island['monster'];
	list($MBid, $MBname, $MBtId, $MBsId, $MBmId, $MBhp, $MBmhp, $MBstr, $MBdef, $MBagi, $MBskl, $MBwinh, $MBwin, $MBlose) = 
	array(
		$monster[0],
		$monster[1],
		$monster[2],
		$monster[3],
		$monster[4],
		$monster[5],
		$monster[6],
		$monster[7],
		$monster[8],
		$monster[9],
		$monster[10],
		$monster[11],
		$monster[12],
		$monster[13]
	 );
	
	$tn = $HidToNumber[$MBtId];
	$tMonster = null;
	unset($tIsland);
	$tIsland = null;
	$tName = null;
	$tMBid = null; $tMBname = null; $tMBtId = null; $tMBsId = null; $tMBmId = null; $tMBhp = null; $tMBmhp = null; $tMBstr = null; $tMBdef = null; $tMBagi = null; $tMBskl = null; $tMBwinh = null; $tMBwin = null; $tMBlose = null;
	if($island['esa'] > 0){
		// 괴수먹이 취득 플래그가 서 있다

		$MBsId = $island['esa'];
		logMonsESA($id, $name, $HmonsterName[$MBsId]);
	}
	
	if($MBid == 0){
		// 자신의 괴수가 없다
	}elseif($id != $MBid){
		// 원정중

		if($tn == ''){
			$MBid = $id; # 상대가 없어졌으므로 괴수를 자신 도에 되돌린다.
			$MBhp = $MBmhp;
			$MBtId = 0;
		}
	}elseif($tn == ''){
		$MBid = $id; # 상대가 없기 때문에 괴수를 자신 도에 되돌린다
		$MBhp = $MBmhp;
		$MBtId = 0;
	}else{
		// 대전 상대가 있을 때
		$tIsland =& $Hislands[$tn];
		$tName = $tIsland['name'];
		$tMonster =& $tIsland['monster'];
		list($tMBid, $tMBname, $tMBtId, $tMBsId, $tMBmId, $tMBhp, $tMBmhp, $tMBstr, $tMBdef, $tMBagi, $tMBskl, $tMBwinh, $tMBwin, $tMBlose) =
		array(
			$tMonster[0],
			$tMonster[1],
			$tMonster[2],
			$tMonster[3],
			$tMonster[4],
			$tMonster[5],
			$tMonster[6],
			$tMonster[7],
			$tMonster[8],
			$tMonster[9],
			$tMonster[10],
			$tMonster[11],
			$tMonster[12],
			$tMonster[13]
		 );
		
		// 전투 루틴

		$mId = null; $tmId = null;# monster ID
		if($MBmId == 19){ # 아슈라때
			$mId = random(25);
		}else{
			$mId = $MBmId;
		}
		if($tMBmId == 19){ # 아슈라때
			$tmId = random(25);
		}else{
			$tmId = $tMBmId;
		}
		
		$speed = null; $mei = null; $kai = null; $damage = null; $sp = null; $spskl = null;
		$tspeed = null; $tmei = null; $tkai = null; $tdamage = null; $tsp = null; $tspskl = null;
		$speed = $HmonsterAGI[$mId] + $MBagi + random(30);
		$mei = $HmonsterSKL[$mId] + $MBskl + random(30);
		$kai = $HmonsterAGI[$mId] + $MBagi + random(15);
		$damage = ($HmonsterSTR[$mId] + $MBstr + random(12)) - ($HmonsterDEF[$tmId] + $tMBdef + random(5));
		if ($damage < 0) { $damage = 0; }
		$sp = $HmonsterSP[$mId];
		$spskl = $MBagi + $MBskl;
		
		// 특수 능력이 발동할까
		$ran100 = random(100);
		if($spskl + 20 > $ran100){
			$spskl = 3;
		}elseif($spskl + 25 > $ran100){
			$spskl = 2;
		}elseif($spskl + 40 > $ran100){
			$spskl = 1;
		}else{
			$spskl = 0;
		}
		
		$tspeed = $HmonsterAGI[$tmId] + $tMBagi + random(30);
		$tmei = $HmonsterSKL[$tmId] + $tMBskl + random(30);
		$tkai = $HmonsterAGI[$tmId] + $tMBagi + random(15);
		$tdamage = ($HmonsterSTR[$tmId] + $tMBstr + random(12)) - ($HmonsterDEF[$mId] + $MBdef + random(5));
		if ($tdamage < 0) { $tdamage = 0; }
		$tsp = $HmonsterSP[$tmId];
		$tspskl = $tMBagi + $tMBskl;
		
		// 특수 능력이 발동할까
		$ran100 = random(100);
		if($tspskl + 20 > $ran100){
			$tspskl = 3;
		}elseif($tspskl + 25 > $ran100){
			$tspskl = 2;
		}elseif($tspskl + 40 > $ran100){
			$tspskl = 1;
		}else{
			$tspskl = 0;
		}
		
		if(($sp == 10) || ($tsp == 10)){
			 // 한쪽에서도 상대의 특수 능력 무효기술 가지고 있는 경우.
			$sp = 0;
			$tsp = 0;
		}
		
		list($first, $end) = array(1, 3);
		if($speed == $tspeed){
			//  양자 움직이지 않았다.
			logMonsNOATTACK($MBtId, $tName, $tMBname, $id, $name, $MBname);
			$first = 3;
		}elseif($speed > $tspeed){
			// 자신의 괴수 선제 공격

			$first = 0;
			$end = 2;
		}else{
			// 상대의 선제 공격

		}
		$special = $HmonsterSpecial[$mId];
		$special2 = $HmonsterSpecial[$tmId];
		
		$BattleEnd = 0;
		
		while ($first < $end){
			if($first == 1){
				// 상대의 공격

				if((($tsp == 1) && (($HislandTurn % 2) == 0)) ||
					(($tsp == 2) && (($HislandTurn % 2) == 1))){
					// 방어중에서 공격하지 않는다
					$first++;
continue;
				}
				if($tmei > $kai){
					// 상대의 공격이 맞았다
					if(($sp == 5) && ($spskl >= 2)){
						//  특수 능력으로 피했다
						logMonsATTACK($MBtId, $tName, $tMBname, $id, $name, $MBname, "통상 공격, 그러나 회피 했습니다.");
					}elseif(($sp == 6) && ($spskl >= 1)){
						// 특수 능력으로 방어했다
						logMonsATTACK($MBtId, $tName, $tMBname, $id, $name, $MBname, "통상 공격, 그러나 피해를 받지 않았습니다.");
					}elseif(((($sp == 1) && (($HislandTurn % 2) == 0)) ||
							(($sp == 2) && (($HislandTurn % 2) == 1))) &&
							(($tsp != 1) && ($tsp != 2))){
						//방어중에서 데미지를 창고 함정 있고, 다만 산지라와 쿠지라는 제외하다
						logMonsATTACK($MBtId, $tName, $tMBname, $id, $name, $MBname, "통상 공격, 그러나 피해를 받지 않았습니다.");
					}elseif(($tsp == 8) && ($tMBhp <= 10)){
						// 자폭 공격

						if(random(2) == 0){
							$tdamage = 100;
							$MBhp = $MBhp - $tdamage;
							logMonsATTACK($MBtId, $tName, $tMBname, $id, $name, $MBname, "자폭 공격,${tdamage} 의  피해를 주었습니다.");
						}else{
							logMonsATTACK($MBtId, $tName, $tMBname, $id, $name, $MBname, "자폭 공격,그러나 회피했습니다.");
							logMonsEND($MBtId, $tName, $tMBname, $MBtId, "자멸했습니다.");
							logMonsEND($id, $name, $MBname, $MBtId, "싸워 승리했습니다.");
							
							$BattleEnd = 1;
break;
						}
					}elseif(($tsp == 7) && ($tspskl >= 2)){
						// 필살 공격

						$tdamage = $tdamage * 2;
						$MBhp = $MBhp - $tdamage;
						logMonsATTACK($MBtId, $tName, $tMBname, $id, $name, $MBname, "필살의 일격,${tdamage} 의  피해를 주었습니다.");
					}elseif(($tsp == 9) && ($tspskl >= 3)){
						// 운석 오토시
						$tdamage = $tdamage * 3;
						$MBhp = $MBhp - $tdamage;
						logMonsATTACK($MBtId, $tName, $tMBname, $id, $name, $MBname, "필살의 운석 오토시 발동,${tdamage} 의  피해를 주었습니다.");
					}else{
						// 통상 공격

						$MBhp = $MBhp - $tdamage;
						logMonsATTACK($MBtId, $tName, $tMBname, $id, $name, $MBname, "통상 공격,${tdamage} 의  피해를 주었습니다.");
					}
					if($MBhp < 1){
						// 져 버렸다.
						logMonsEND($MBtId, $tName, $tMBname, $id, "싸워 승리했습니다.");
						
						$BattleEnd = 2;
break;
					}
				}else{
					// 상대의 공격을 피했다
					logMonsATTACK($MBtId, $tName, $tMBname, $id, $name, $MBname, "통상 공격, 그러나 회피했습니다.");
				}
			}else{
				// 자신의 공격

				if((($sp == 1) && (($HislandTurn % 2) == 0)) ||
					(($sp == 2) && (($HislandTurn % 2) == 1))){
					// 방어중에서 공격하지 않는다
					$first++;
continue;
				}
				if($mei > $tkai){
					// 자신의 공격이 맞았다
					if(($tsp == 5) && ($tspskl >= 2)){
						// 특수 능력으로 피했다
						logMonsATTACK($id, $name, $MBname, $MBtId, $tName, $tMBname, "통상 공격, 그러나 회피했습니다.");
					}elseif(($tsp == 6) && ($tspskl >= 1)){
						// 특수 능력으로 방어했다
						logMonsATTACK($id, $name, $MBname, $MBtId, $tName, $tMBname, "통상 공격, 그러나 피해를 받지 않았습니다.");
					}elseif(((($tsp == 1) && (($HislandTurn % 2) == 0)) ||
							(($tsp == 2) && (($HislandTurn % 2) == 1))) &&
							(($sp != 1) && ($sp != 2))){
						// 방어중에서 데미지를 창고 함정 있고, 다만 산지라와 쿠지라는 제외하다
						logMonsATTACK($id, $name, $MBname, $MBtId, $tName, $tMBname, "통상 공격, 그러나 피해를 받지 않았습니다.");
					}elseif(($sp == 8) && ($MBhp <= 10)){
						// 자폭 공격

						if(random(2) == 0){
							$damage = 100;
							$tMBhp = $tMBhp - $damage;
							logMonsATTACK($id, $name, $MBname, $MBtId, $tName, $tMBname, "자폭 공격,${damage} 의  피해를 주었습니다.");
						}else{
							logMonsATTACK($id, $name, $MBname, $MBtId, $tName, $tMBname, "자폭 공격, 그러나 회피했습니다.");
							logMonsEND($id, $name, $MBname, $MBtId, "자멸했습니다.");
							logMonsEND($id, $tName, $tMBname, $MBtId, "싸워 승리했습니다. ");
							
							$BattleEnd = 2;
break;
						}
					}elseif(($sp == 7) && ($spskl >= 2)){
						// 필살 공격

						$damage = $damage * 2;
						$tMBhp = $tMBhp - $damage;
						logMonsATTACK($id, $name, $MBname, $MBtId, $tName, $tMBname, "필살의 일격,${damage} 의  피해를 주었습니다. ");
					}elseif(($sp == 9) && ($spskl >= 3)){
						// 운석 오토시
						$damage = $damage * 3;
						$tMBhp = $tMBhp - $damage;
						logMonsATTACK($id, $name, $MBname, $MBtId, $tName, $tMBname, "필살의 운석 오토시 발동,${damage} 의  피해를 주었습니다.");
					}else{
						// 통상 공격

						$tMBhp = $tMBhp - $damage;
						logMonsATTACK($id, $name, $MBname, $MBtId, $tName, $tMBname, "통상 공격,${damage} 의  피해를 주었습니다..");
					}
					if($tMBhp < 1){
						// 져 버렸다.
						logMonsEND($id, $name, $MBname, $MBtId, "싸워 승리했습니다.");
						
						$BattleEnd = 1;
break;
					}
				}else{
					// 자신의 공격이야 차졌다
					logMonsATTACK($id, $name, $MBname, $MBtId, $tName, $tMBname, "통상 공격, 그러나 회피했습니다.");
				}
			}
			$first++;
		}
		
		if($BattleEnd > 0){
			// 전투 종료시는 전투후의 처리
			$up = array(3,3,0,3,3);
			$tup = array(3,3,0,3,3);
			if($BattleEnd == 1){
				if(($tsp == 3) && (random(3) == 0)){
					// 졌을 때에 33%로 지바쿠 레이에 진화
					$tMBmId = 15;
					logMonsEND($MBtId, $tName, $tMBname, $id, "죽지 못하고 지바쿠 레이가 되어 전생 했습니다.");
				}
				$up = MonsterSei(1,$up); #성장률 가산
				
				$MBwinh++; # 괴수배용
				$MBwin++;
				$tMBlose++;
				if($Htournament == 2){
					$achive = refugees(500,$island);
					if($achive > 0){
						logMsBoatPeople($id, $name, $achive);
					}
				}
			}else{
				if(($sp == 3) && (random(3) == 0)){
					// 졌을 때에 33%로 지바쿠 레이에 진화
					$MBmId = 15;
					logMonsEND($id, $name, $MBname, $MBtId, "죽지 못하고 지바쿠 레이가 되어 전생 했습니다.");
				}
				$tup = MonsterSei(1,$tup); #성장률 가산
				
				$tMBwinh++; # 괴수배용
				$tMBwin++;
				$MBlose++;
				if($Htournament == 2){
					$achive = refugees(500,$tIsland);
					if($achive > 0){
						logMsBoatPeople($MBtId, $tName, $achive);
					}
				}
			}
			
			$up = MonsterSei($HmonsterSEI[$mId],$up); # 성장률 가산
			$tup = MonsterSei($HmonsterSEI[$tmId],$tup); # 성장률 가산
			
			$MBmhp = $MBmhp + random($up[0] - 1);
			if ($MBmhp > $HmonsBtlMaxHp) { $MBmhp = $HmonsBtlMaxHp; }
			if (($MBstr + $MBdef + $MBagi + $MBskl) < $HmonsBtlMaxPa){
				if (random($up[1]) > 1) { $MBstr++; }
				if (random($up[2]) > 0) { $MBdef++; }
				if (random($up[3]) > 1) { $MBagi++; }
				if (random($up[4]) > 1) { $MBskl++; }
			}
			
			$tMBmhp = $tMBmhp + random($tup[0] - 1);
			if ($tMBmhp > $HmonsBtlMaxHp) { $tMBmhp = $HmonsBtlMaxHp; }
			if (($tMBstr + $tMBdef + $tMBagi + $tMBskl) < $HmonsBtlMaxPa){
				if (random($tup[1]) > 1) { $tMBstr++; }
				if (random($tup[2]) > 0) { $tMBdef++; }
				if (random($tup[3]) > 1) { $tMBagi++; }
				if (random($tup[4]) > 1) { $tMBskl++; }
			}
			
			$MBhp = $MBmhp;
			$tMBhp = $tMBmhp;
			$MBid = $id;
			$tMBid = $MBtId;
			$MBtId = 0;
			$tMBtId = 0;
		}else{
			// 계속중

			$point = 5;
			if($sp == 11){
				// 회복

				$MBhp = $MBhp + $point;
				if($MBhp > $MBmhp){
					$point -= $MBhp - $MBmhp;
					$MBhp = $MBmhp;
				}
				logMonsRrcovery($id, $name, $MBname, $MBtId, $point);
			}elseif($tsp == 11){
				// 회복

				$tMBhp = $tMBhp + $point;
				if($tMBhp > $tMBmhp){
					$point -= $tMBhp - $tMBmhp;
					$tMBhp = $tMBmhp;
				}
				logMonsRrcovery($MBtId, $tName, $tMBname, $id, $point);
			}
		}
	}
	
	// 턴배 대상 턴이라면, 그 처리
	if(($HislandTurn % $HturnPrizeUnit) == 0){
		if($MonsBattleTurn < $MBwinh){
			$MonsBattleTurn = $MBwinh;
			$MonsBattleTurnID = $id;
		}
		$MBwinh = 0;
	}
	// 각 요소 격납
	$wmonster = array($MBid,$MBname,$MBtId,$MBsId,$MBmId,$MBhp,$MBmhp,$MBstr,$MBdef,$MBagi,$MBskl,$MBwinh,$MBwin,$MBlose);
	$island['monster'] = $wmonster;
	if($id != $target){
		$wtMonster = array($tMBid,$tMBname,$tMBtId,$tMBsId,$tMBmId,$tMBhp,$tMBmhp,$tMBstr,$tMBdef,$tMBagi,$tMBskl,$tMBwinh,$tMBwin,$tMBlose);
		$tIsland['monster'] = $wtMonster;
	}

	if($island['GoldMonument'] > 0){
		logGoldMonu($id, $name, $HmonumentName[9], intval($island['GoldMonument']) * 300);
	}

	// 각종의 값을 계산
	estimateE($number);

} # doIslandProcess


// 기밀 로그에 수지를 표시
function doIslandProcess2(&$island) {
global $HdisFallBorder, $HdisKLimit, $HislandTurn, $Hprize, $HsecretLogPool, $HturnPrizeVarious, $HunitFood, $HunitMoney, $HunitPop, $MaxFood, $MaxMoney, $MaxSigen, $MiH, $id,
       $iken, $iken2, $iken3, $kaiteiw, $moriw, $name, $HtagDisaster_, $H_tagDisaster;
	if($island['id'] > 90){
		// Battle Field 때
		return;
	}
	list($name, $id, $moriw, $kaiteiw, $MiH) = array($island['name'], $island['id'],$island['forest'], $island['kaitei'], $island['MissileK']);
	$po = null; $mo = null; $fo = null;
	$po = $island['pop'] - $island['oldPop'];
	$mo = $island['money'] - $island['oldmoney'];
	$fo = $island['food'] - $island['oldfood'];
	
	// 광석이 넘치고 있으면 환금
	if($island['ore'] > $MaxSigen){
		$island['money'] += ($island['ore'] - $MaxSigen);
		$island['ore'] = $MaxSigen;
	}
	// 원유가 넘치고 있으면 환금
	if($island['oil'] > $MaxSigen){
		$island['money'] += ($island['oil'] - $MaxSigen) * 2;
		$island['oil'] = $MaxSigen;
	}
	// 병기가 넘치고 있으면 환금
	if($island['weapon'] > $MaxSigen){
		$island['money'] += ($island['weapon'] - $MaxSigen) * 6;
		$island['weapon'] = $MaxSigen;
	}

	// 식량가 넘치고 있으면 환금
	if($island['food'] > $MaxFood){
		$island['money'] += intval(($island['food'] - $MaxFood) / 10);
		$island['food'] = $MaxFood;
	}

	// 돈이 넘치고 있으면 잘라서 버림
	if($island['money'] > $MaxMoney){
		$island['money'] = $MaxMoney;
	}elseif($island['money'] < 0){
		$island['money'] = 0;
	}

	list($iken,$iken2,$iken3) = array("","","(해저계${kaiteiw}%숲${moriw}%)");
	if(($island['forest'] < 5) && (random(5) == 0)){
		$iken = "자연 보호 단체가 삼림 보호를 요구하고 있습니다.";
	}elseif(($island['forest'] < 4) && (random(3) == 0)){
		$iken = "자연 보호 단체가 식림 하라고 항의 데모를 실시하고 있습니다.";
	}elseif($island['kaitei'] > $HdisKLimit){
		$iken = "해저계의 건축물이 너무 많습니다. 바다 이노라 가 나올지도 모릅니다.";
	}
	if($island['area'] > $HdisFallBorder){
		$iken2 = "육지 면적이 한계치를 넘고 있습니다.";
	}elseif($island['towerD'] > 1000){
		$iken2 = "상업지가 너무 많습니다.";
	}elseif($island['towerD'] > 0){
		$iken2 = "주민이 상업 빌딩을 요구하고 있습니다.";
	}elseif(($island['kaiteipop'] == 1) && ($island['area'] > 0)){
		$iken2 = "해저 인구과잉입니다. 숲이나 미사일 기지에 괴수가 나올지도 모릅니다.";
	}
	if ($island['area'] == 0) { $moriw = 0; }

	if($po > 0){
		$po = "${po}${HunitPop}";
	}elseif($po == 0){
		$po = "증가 없음";
	}else{
		// 마이너스
		$island['score'] += -$po;
		$po = "${HtagDisaster_}${po}${HunitPop}${H_tagDisaster}";
	}
	if($mo > 0){
		$mo = "${mo}${HunitMoney}";
	}elseif($mo == 0){
		$mo = "증가 없음";
	}else{
		$mo = "${HtagDisaster_}${mo}${HunitMoney}${H_tagDisaster}";
	}
	if($fo > 0){
		$fo = "${fo}${HunitFood}";
	}elseif($fo == 0){
		$fo = "증가 없음";
	}else{
		$fo = "${HtagDisaster_}${fo}${HunitFood}${H_tagDisaster}";
	}
	$wname = hako_pick(weatherinfo($island['weather2']), array(1));
	// 수지의 기밀 로그
	array_push($HsecretLogPool, "1,$HislandTurn,$id,,인구<B>$po</B>,자금<B>$mo</B>,식량<B>$fo</B>, 처리한 날씨는<B>$wname</B>.${HtagDisaster_}${iken}${iken2}${H_tagDisaster}$iken3");

	// 부문상 대상 턴이라면 초기화한다.
	if(($HislandTurn % $HturnPrizeVarious) == 0){
		$island['status'] = 0;
		$island['score2'] = $island['score'];
		$island['score'] = 0;
	}

	// 번영, 재난상
	$pop = $island['pop'];
	$damage = $island['oldPop'] - $pop;
	$prize = $island['prize'];
	preg_match('/([0-9]*),([0-9]*),(.*)/', $prize, $_m);
	list($flags,$monsters,$turns) = array($_m[1],$_m[2],$_m[3]);
	// 번영상
	if((!($flags & 1)) &&  $pop >= 3000){
		$flags |= 1;
		logPrize($id, $name, $Hprize[1]);
		$island['present'][9]++; # 박람회를 1개 늘린다
		logEvent($id, $name," 그리고  30만명 달성 기념의 박람회가 개최되는 것이 결정했습니다.");
	}elseif((!($flags & 2)) &&  $pop >= 5000){
		$flags |= 2;
		logPrize($id, $name, $Hprize[2]);
		$island['present'][9]++; # 박람회를 1개 늘린다
		logEvent($id, $name," 그리고  50만명 달성 기념의 박람회가 개최되는 것이 결정했습니다.");
	}elseif((!($flags & 4)) &&  $pop >= 10000){
		$flags |= 4;
		logPrize($id, $name, $Hprize[3]);
		$island['present'][9]++; # 박람회를 1개 늘린다
		logEvent($id, $name," 그리고  100만명 달성 기념의 박람회가 개최되는 것이 결정했습니다.");
	}elseif((!($flags & 1024)) &&  $pop >= 15000){
		$flags |= 1024;
		$island['present'][9]++; # 박람회를 1개 늘린다
		logEvent($id, $name," 그리고  150만명 달성 기념의 박람회가 개최되는 것이 결정했습니다.");
	}

	// 재난상
	if((!($flags & 64)) &&  $damage >= 500){
		$flags |= 64;
		logPrize($id, $name, $Hprize[7]);
	}elseif((!($flags & 128)) &&  $damage >= 1000){
		$flags |= 128;
		logPrize($id, $name, $Hprize[8]);
	}elseif((!($flags & 256)) &&  $damage >= 2000){
		$flags |= 256;
		logPrize($id, $name, $Hprize[9]);
	}
	// 우주상의 로그
	if ($island['space'] == 1) { logPrize($id, $name, $Hprize[10]); }
	
	// 방폐의 로그
	if ($island['giveup'] == 1) { logGiveup($id, $name); }
	
	$island['prize'] = "$flags,$monsters,$turns";
} # doIslandProcess2

// 주위의 마을, 농장이 있을까 판정
function countGrow($land, $landValue, $x, $y) {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $H_tagName2, $Haidpop, $Hallyflg, $Hallygroup, $haribote, $Hatkturn, $HbackupTimes, $HbackupTurn, $HbgInfoCell, $HbgTitleCell, $HbigcityFood, $HbigCityMFlg, $HcomBank, $HcomBase, $HcomBioMissile, $HcomBreakwater, $Hcomcolony, $HcomcolonyTurn, $HcomCost, $HcomDbase, $HcomDeathtrap, $HcomDestroy, $HcomDestroy2, $HcomDokan, $HcomDoNothing, $HcomDummy, $HcomEmigration, $HcomFactory, $HcomFarm, $HcomFire, $HcomFlower, $HcomFood, $HcomGiveup, $HcomHaribote, $HcomHospital, $HcomL, $HcommandMax, $HcomManipulate, $HcomMissileDM, $HcomMissileGM, $HcomMissileLD, $HcomMissileMGM, $HcomMissileNCM, $HcomMissileNM, $HcomMissilePLD, $HcomMissilePP, $HcomMissileRM, $HcomMissileRNG, $HcomMissileSPP, $HcomMissileSRM, $HcomMissileST, $HcomMoney, $HcomMonsAid, $HcomMonsEgg, $HcomMonsEnsei, $HcomMonsEsa, $HcomMonsEsaAid, $HcomMonsExer, $HcomMonsSell, $HcomMonsTettai, $HcomMonument, $HcomMountain, $HcomMyhome, $HcomName, $HcomOilBuy, $HcomOilSell, $HcomOMissileMGM, $HcomOMissileNM, $HcomOMissilePP, $HcomOMissileSPP, $HcomOreBuy, $HcomOreSell, $HcomPioneer, $HcomPlant, $HcomPolice, $HcomPort, $HcomPrepare, $HcomPrepare2, $HcomPresent, $HcomPresentAid, $HcomPropaganda, $HcomReclaim, $HcomReclaim2, $HcomSbase, $HcomSBuild, $HcomScity, $HcomSDbase, $HcomSDestroy, $HcomSearch, $HcomSEisei, $HcomSell, $HcomSellTree, $HcomSendMonster, $HcomSendMonsterTurn, $HcomSFactory, $HcomSFarm, $HcomSFood, $HcomShip, $HcomShipbuild, $HcomShipM, $HcomShipSell, $HcomSMissile, $HcomSMissileGM, $HcomSMissileMGM, $HcomSMissilePP, $HcomSMonument, $HcomSOccupy, $HcomSpaceBase, $HcomSpaceFarm, $HcomSpecialSPP, $HcomSPioneer, $HcomSpy, $HcomSSendMonster, $HcomSSendMonsterTurn, $HcomSTManipulate, $HcomSUnit, $HcomTeisatu, $HcomTower, $HcomTrump, $HcomUg, $HcomWarp, $HcomWeponBuy, $HcomWeponSell, $HcomWindmill, $HconsolationMatch, $HcurrentNumber, $HdBaseAuto, $HdefenceHex, $HdefenceSpace, $HdevelopeTurn, $HdirMode, $HdirName, $HdisAEruption, $HdisAkasio, $HdisBHarvest, $HdisCrime, $HdisEarthquake, $HdisEruption, $HdisFallBorder, $HdisFalldown, $HdisFire, $HdisGHarvest, $Hdishangen, $HdisHugeMeteo, $HdisKLimit, $HdisMaizo, $HdisMeteo, $HdisMonsBorder1, $HdisMonsBorder2, $HdisMonsBorder3, $HdisMonsBorder4, $HdisMonsBorder5, $HdisMonster, $HdisMonsterU, $HdisPirate, $HdisPollution, $HdisSeaMonster, $HdisSHugeMeteo, $HdisSpaceMonster1, $HdisSpaceMonster2, $HdisTinka, $HdisTreasureS, $HdisTsunami, $HdisTyphoon, $HdisUN, $HdisVGHarvest, $HearthAttack, $HeatenFood, $helpDir, $HfightMem, $HfightTurn, $HfinalTurn, $HgiveupTurn, $HhistoryMax, $HidToName, $HidToNumber, $HidToNumberR, $HinterTime, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HlandAegisShip, $HlandAirport, $HlandAmusement, $HlandBalloonS, $HlandBank, $HlandBase, $HlandBigcity, $HlandBreakwater, $HlandCasino, $HlandCoupleRock, $HlandDeathtrap, $HlandDefence, $HlandDokan, $HlandDome, $HlandEarth, $HlandExpo, $HlandFactory, $HlandFarm, $HlandFire, $HlandFishLShip, $HlandFishMShip, $HlandFishSShip, $HlandFlower, $HlandForest, $HlandFuji, $HlandGhostShip, $HlandHaribote, $HlandHospital, $HlandHugecity, $HlandIceFloe, $HlandKInora, $HlandMegacity, $HlandMegaFact, $HlandMegaFarm, $HlandMegatower, $HlandMonsShip, $HlandMonster, $HlandMonument, $HlandMountain, $HlandMyhome, $HlandOcean, $HlandOil, $HlandOPlayer, $HlandOsen, $HlandPark, $HlandPirate, $HlandPlains, $HlandPolice, $HlandPort, $HlandProbeShip, $HlandSAEisei, $HlandSbase, $HlandSchool, $HlandSCity, $HlandSDefence, $HlandSea, $HlandSeisei, $HlandSFactory, $HlandSFarm, $HlandSlum, $HlandSMonument, $HlandSpaceBase, $HlandStadium, $HlandSunit, $HlandTcity, $HlandTitanic, $HlandTower, $HlandTown, $HlandTreasureS, $HlandTrump, $HlandWarp, $HlandWarpR, $HlandWaste, $HlandWindmill, $HlandWingDragon, $HlandZoo, $HlateLogPool, $HlogMax, $HlogOmit2, $HlogPool, $HmaxdisPollution, $HmaxExpPoint, $HmaxIsland, $HmonsBtlMaxHp, $HmonsBtlMaxPa, $HmonsterAGI, $HmonsterBHP, $HmonsterCLS, $HmonsterDEF, $HmonsterDestroy, $HmonsterDHP, $HmonsterExp, $HmonsterGRP, $HmonsterL1, $HmonsterL1Num, $HmonsterL2, $HmonsterL2Num, $HmonsterL3, $HmonsterL3Num, $HmonsterL4, $HmonsterL4Num, $HmonsterL5, $HmonsterL5Num, $HmonsterName, $HmonsterNumber, $HmonsterS, $HmonsterSEI, $HmonsterSKL, $HmonsterSP, $HmonsterSpecial, $HmonsterSTR, $HmonsterValue, $Hmonth, $HmonumentMissile, $HmonumentName, $HmonumentRocket, $Hocean, $HoceanSize, $HoilMoney, $HoilRatio, $hp, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $Hprize, $HprizeV, $HpunishInfo, $HrepeatTurn, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $HseaChk, $HsecretLogPool, $HsEisei, $HshipEX, $HshipFood, $HshipHP, $HshipKAI, $HshipMATK, $HshipMoney, $HshipName, $Hshiporder, $HshipSATK, $HshipSell, $HshipSP, $HsmonumentName, $HsmonumentNumber, $Hsolarwind, $Hspace, $HspaceEfficiency, $HspaceIncome, $Hsstartturn, $HStotalPoint, $HsurvFlg, $Hsurvivalturn, $HtagName2_, $HthisFile, $HtotalBumon, $HtotalMoney, $HtotalPoint, $Htournament, $HtreeValue, $HturnPrizeNumber, $HturnPrizePoint, $HturnPrizeUnit, $HturnPrizeVarious, $HugDokan, $HugFact, $HugFarm, $HugHasigo, $HugKiti, $HugMax, $HugOil, $HugRoad, $HugSpace, $HugTosi, $human, $HunitFood, $HunitMoney, $HunitOil, $HunitOre, $HunitPop, $HunitTime, $HunitWeapon, $HwarFlg, $HWeatherMax, $Hwflg, $HwinFood, $HwinIsland, $HwinMoney, $HwinWeapon, $imageDir, $lockMode, $toppage, $versionInfo;
	$i = null; $sx = null; $sy = null;
	for($i = 1; $i < 7; $i++){
		$sx = $x + $ax[$i];
		$sy = $y + $ay[$i];
		if (!($sy % 2) && ($y % 2)) { $sx--; }
		if(($sx < 0) || ($sx >= $HislandSize) || ($sy < 0) || ($sy >= $HislandSize)){
		}elseif(($land[$sx][$sy] == $HlandTown) ||
				($land[$sx][$sy] == $HlandFarm) ||
				($land[$sx][$sy] == $HlandSFarm) ||
				($land[$sx][$sy] == $HlandMegaFarm) ||
				($land[$sx][$sy] == $HlandMegacity) ||
				($land[$sx][$sy] == $HlandHugecity)){
			if ($landValue[$sx][$sy] != 1) { return 1; }
		}
	}
	return 0;
}

// 구상 이노라 이동, 또는 소거.
function kinoraMove(&$island, $x, $y) {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $H_tagName2, $Haidpop, $Hallyflg, $Hallygroup, $haribote, $Hatkturn, $HbackupTimes, $HbackupTurn, $HbgInfoCell, $HbgTitleCell, $HbigcityFood, $HbigCityMFlg, $HcomBank, $HcomBase, $HcomBioMissile, $HcomBreakwater, $Hcomcolony, $HcomcolonyTurn, $HcomCost, $HcomDbase, $HcomDeathtrap, $HcomDestroy, $HcomDestroy2, $HcomDokan, $HcomDoNothing, $HcomDummy, $HcomEmigration, $HcomFactory, $HcomFarm, $HcomFire, $HcomFlower, $HcomFood, $HcomGiveup, $HcomHaribote, $HcomHospital, $HcomL, $HcommandMax, $HcomManipulate, $HcomMissileDM, $HcomMissileGM, $HcomMissileLD, $HcomMissileMGM, $HcomMissileNCM, $HcomMissileNM, $HcomMissilePLD, $HcomMissilePP, $HcomMissileRM, $HcomMissileRNG, $HcomMissileSPP, $HcomMissileSRM, $HcomMissileST, $HcomMoney, $HcomMonsAid, $HcomMonsEgg, $HcomMonsEnsei, $HcomMonsEsa, $HcomMonsEsaAid, $HcomMonsExer, $HcomMonsSell, $HcomMonsTettai, $HcomMonument, $HcomMountain, $HcomMyhome, $HcomName, $HcomOilBuy, $HcomOilSell, $HcomOMissileMGM, $HcomOMissileNM, $HcomOMissilePP, $HcomOMissileSPP, $HcomOreBuy, $HcomOreSell, $HcomPioneer, $HcomPlant, $HcomPolice, $HcomPort, $HcomPrepare, $HcomPrepare2, $HcomPresent, $HcomPresentAid, $HcomPropaganda, $HcomReclaim, $HcomReclaim2, $HcomSbase, $HcomSBuild, $HcomScity, $HcomSDbase, $HcomSDestroy, $HcomSearch, $HcomSEisei, $HcomSell, $HcomSellTree, $HcomSendMonster, $HcomSendMonsterTurn, $HcomSFactory, $HcomSFarm, $HcomSFood, $HcomShip, $HcomShipbuild, $HcomShipM, $HcomShipSell, $HcomSMissile, $HcomSMissileGM, $HcomSMissileMGM, $HcomSMissilePP, $HcomSMonument, $HcomSOccupy, $HcomSpaceBase, $HcomSpaceFarm, $HcomSpecialSPP, $HcomSPioneer, $HcomSpy, $HcomSSendMonster, $HcomSSendMonsterTurn, $HcomSTManipulate, $HcomSUnit, $HcomTeisatu, $HcomTower, $HcomTrump, $HcomUg, $HcomWarp, $HcomWeponBuy, $HcomWeponSell, $HcomWindmill, $HconsolationMatch, $HcurrentNumber, $HdBaseAuto, $HdefenceHex, $HdefenceSpace, $HdevelopeTurn, $HdirMode, $HdirName, $HdisAEruption, $HdisAkasio, $HdisBHarvest, $HdisCrime, $HdisEarthquake, $HdisEruption, $HdisFallBorder, $HdisFalldown, $HdisFire, $HdisGHarvest, $Hdishangen, $HdisHugeMeteo, $HdisKLimit, $HdisMaizo, $HdisMeteo, $HdisMonsBorder1, $HdisMonsBorder2, $HdisMonsBorder3, $HdisMonsBorder4, $HdisMonsBorder5, $HdisMonster, $HdisMonsterU, $HdisPirate, $HdisPollution, $HdisSeaMonster, $HdisSHugeMeteo, $HdisSpaceMonster1, $HdisSpaceMonster2, $HdisTinka, $HdisTreasureS, $HdisTsunami, $HdisTyphoon, $HdisUN, $HdisVGHarvest, $HearthAttack, $HeatenFood, $helpDir, $HfightMem, $HfightTurn, $HfinalTurn, $HgiveupTurn, $HhistoryMax, $HidToName, $HidToNumber, $HidToNumberR, $HinterTime, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HlandAegisShip, $HlandAirport, $HlandAmusement, $HlandBalloonS, $HlandBank, $HlandBase, $HlandBigcity, $HlandBreakwater, $HlandCasino, $HlandCoupleRock, $HlandDeathtrap, $HlandDefence, $HlandDokan, $HlandDome, $HlandEarth, $HlandExpo, $HlandFactory, $HlandFarm, $HlandFire, $HlandFishLShip, $HlandFishMShip, $HlandFishSShip, $HlandFlower, $HlandForest, $HlandFuji, $HlandGhostShip, $HlandHaribote, $HlandHospital, $HlandHugecity, $HlandIceFloe, $HlandKInora, $HlandMegacity, $HlandMegaFact, $HlandMegaFarm, $HlandMegatower, $HlandMonsShip, $HlandMonster, $HlandMonument, $HlandMountain, $HlandMyhome, $HlandOcean, $HlandOil, $HlandOPlayer, $HlandOsen, $HlandPark, $HlandPirate, $HlandPlains, $HlandPolice, $HlandPort, $HlandProbeShip, $HlandSAEisei, $HlandSbase, $HlandSchool, $HlandSCity, $HlandSDefence, $HlandSea, $HlandSeisei, $HlandSFactory, $HlandSFarm, $HlandSlum, $HlandSMonument, $HlandSpaceBase, $HlandStadium, $HlandSunit, $HlandTcity, $HlandTitanic, $HlandTower, $HlandTown, $HlandTreasureS, $HlandTrump, $HlandWarp, $HlandWarpR, $HlandWaste, $HlandWindmill, $HlandWingDragon, $HlandZoo, $HlateLogPool, $HlogMax, $HlogOmit2, $HlogPool, $HmaxdisPollution, $HmaxExpPoint, $HmaxIsland, $HmonsBtlMaxHp, $HmonsBtlMaxPa, $HmonsterAGI, $HmonsterBHP, $HmonsterCLS, $HmonsterDEF, $HmonsterDestroy, $HmonsterDHP, $HmonsterExp, $HmonsterGRP, $HmonsterL1, $HmonsterL1Num, $HmonsterL2, $HmonsterL2Num, $HmonsterL3, $HmonsterL3Num, $HmonsterL4, $HmonsterL4Num, $HmonsterL5, $HmonsterL5Num, $HmonsterName, $HmonsterNumber, $HmonsterS, $HmonsterSEI, $HmonsterSKL, $HmonsterSP, $HmonsterSpecial, $HmonsterSTR, $HmonsterValue, $Hmonth, $HmonumentMissile, $HmonumentName, $HmonumentRocket, $Hocean, $HoceanSize, $HoilMoney, $HoilRatio, $hp, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $Hprize, $HprizeV, $HpunishInfo, $HrepeatTurn, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $HseaChk, $HsecretLogPool, $HsEisei, $HshipEX, $HshipFood, $HshipHP, $HshipKAI, $HshipMATK, $HshipMoney, $HshipName, $Hshiporder, $HshipSATK, $HshipSell, $HshipSP, $HsmonumentName, $HsmonumentNumber, $Hsolarwind, $Hspace, $HspaceEfficiency, $HspaceIncome, $Hsstartturn, $HStotalPoint, $HsurvFlg, $Hsurvivalturn, $HtagName2_, $HthisFile, $HtotalBumon, $HtotalMoney, $HtotalPoint, $Htournament, $HtreeValue, $HturnPrizeNumber, $HturnPrizePoint, $HturnPrizeUnit, $HturnPrizeVarious, $HugDokan, $HugFact, $HugFarm, $HugHasigo, $HugKiti, $HugMax, $HugOil, $HugRoad, $HugSpace, $HugTosi, $human, $HunitFood, $HunitMoney, $HunitOil, $HunitOre, $HunitPop, $HunitTime, $HunitWeapon, $HwarFlg, $HWeatherMax, $Hwflg, $HwinFood, $HwinIsland, $HwinMoney, $HwinWeapon, $imageDir, $lockMode, $toppage, $versionInfo;
	$land =& $island['land']; $landValue =& $island['landValue'];
	$i = null; $sx = null; $sy = null;
	for($i = 1; $i < 7; $i++){
		$sx = $x + $ax[$i];
		$sy = $y + $ay[$i];
		if (!($sy % 2) && ($y % 2)) { $sx--; }
		if(($sx < 0) || ($sx >= $HislandSize) || ($sy < 0) || ($sy >= $HislandSize)){
		}elseif($land[$sx][$sy] == $HlandKInora){
			if (hako_pick(bigMonsterSpec($landValue[$sx][$sy]), array(3)) == 0) { break; }
		}
	}
	list($ld, $d) = hako_pick(bigMonsterSpec($landValue[$x][$y]), array(2,3));
	if(($d == 0) && ($landValue[$x][$y] > 0)){
		// 이동
	//	HdebugOut("구상 이노라 1($x,$y):" . $island['name'] . "도:" . $landValue[$x][$y]);
		if ($monsterMove[$x][$y] == 2) { return; }
		list($sx, $sy) = monmove($island, $x, $y, 0);
		$monsterMove[$sx][$sy] = 2;
	}elseif(($i > 6) || ($landValue[$x][$y] == 0)){
		// 사라진다

		if($ld == 0){
			$land[$x][$y] = $HlandSea;
			$landValue[$x][$y] = 0;
		}elseif($ld == 1){
			$land[$x][$y] = $HlandSea;
			$landValue[$x][$y] = 1;
		}else{
			$land[$x][$y] = $HlandWaste;
			$landValue[$x][$y] = 0;

		}
	}
}
// 구상 이노라 작성
function kinoraMake(&$land, &$landValue, $x, $y) {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $H_tagName2, $Haidpop, $Hallyflg, $Hallygroup, $haribote, $Hatkturn, $HbackupTimes, $HbackupTurn, $HbgInfoCell, $HbgTitleCell, $HbigcityFood, $HbigCityMFlg, $HcomBank, $HcomBase, $HcomBioMissile, $HcomBreakwater, $Hcomcolony, $HcomcolonyTurn, $HcomCost, $HcomDbase, $HcomDeathtrap, $HcomDestroy, $HcomDestroy2, $HcomDokan, $HcomDoNothing, $HcomDummy, $HcomEmigration, $HcomFactory, $HcomFarm, $HcomFire, $HcomFlower, $HcomFood, $HcomGiveup, $HcomHaribote, $HcomHospital, $HcomL, $HcommandMax, $HcomManipulate, $HcomMissileDM, $HcomMissileGM, $HcomMissileLD, $HcomMissileMGM, $HcomMissileNCM, $HcomMissileNM, $HcomMissilePLD, $HcomMissilePP, $HcomMissileRM, $HcomMissileRNG, $HcomMissileSPP, $HcomMissileSRM, $HcomMissileST, $HcomMoney, $HcomMonsAid, $HcomMonsEgg, $HcomMonsEnsei, $HcomMonsEsa, $HcomMonsEsaAid, $HcomMonsExer, $HcomMonsSell, $HcomMonsTettai, $HcomMonument, $HcomMountain, $HcomMyhome, $HcomName, $HcomOilBuy, $HcomOilSell, $HcomOMissileMGM, $HcomOMissileNM, $HcomOMissilePP, $HcomOMissileSPP, $HcomOreBuy, $HcomOreSell, $HcomPioneer, $HcomPlant, $HcomPolice, $HcomPort, $HcomPrepare, $HcomPrepare2, $HcomPresent, $HcomPresentAid, $HcomPropaganda, $HcomReclaim, $HcomReclaim2, $HcomSbase, $HcomSBuild, $HcomScity, $HcomSDbase, $HcomSDestroy, $HcomSearch, $HcomSEisei, $HcomSell, $HcomSellTree, $HcomSendMonster, $HcomSendMonsterTurn, $HcomSFactory, $HcomSFarm, $HcomSFood, $HcomShip, $HcomShipbuild, $HcomShipM, $HcomShipSell, $HcomSMissile, $HcomSMissileGM, $HcomSMissileMGM, $HcomSMissilePP, $HcomSMonument, $HcomSOccupy, $HcomSpaceBase, $HcomSpaceFarm, $HcomSpecialSPP, $HcomSPioneer, $HcomSpy, $HcomSSendMonster, $HcomSSendMonsterTurn, $HcomSTManipulate, $HcomSUnit, $HcomTeisatu, $HcomTower, $HcomTrump, $HcomUg, $HcomWarp, $HcomWeponBuy, $HcomWeponSell, $HcomWindmill, $HconsolationMatch, $HcurrentNumber, $HdBaseAuto, $HdefenceHex, $HdefenceSpace, $HdevelopeTurn, $HdirMode, $HdirName, $HdisAEruption, $HdisAkasio, $HdisBHarvest, $HdisCrime, $HdisEarthquake, $HdisEruption, $HdisFallBorder, $HdisFalldown, $HdisFire, $HdisGHarvest, $Hdishangen, $HdisHugeMeteo, $HdisKLimit, $HdisMaizo, $HdisMeteo, $HdisMonsBorder1, $HdisMonsBorder2, $HdisMonsBorder3, $HdisMonsBorder4, $HdisMonsBorder5, $HdisMonster, $HdisMonsterU, $HdisPirate, $HdisPollution, $HdisSeaMonster, $HdisSHugeMeteo, $HdisSpaceMonster1, $HdisSpaceMonster2, $HdisTinka, $HdisTreasureS, $HdisTsunami, $HdisTyphoon, $HdisUN, $HdisVGHarvest, $HearthAttack, $HeatenFood, $helpDir, $HfightMem, $HfightTurn, $HfinalTurn, $HgiveupTurn, $HhistoryMax, $HidToName, $HidToNumber, $HidToNumberR, $HinterTime, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HlandAegisShip, $HlandAirport, $HlandAmusement, $HlandBalloonS, $HlandBank, $HlandBase, $HlandBigcity, $HlandBreakwater, $HlandCasino, $HlandCoupleRock, $HlandDeathtrap, $HlandDefence, $HlandDokan, $HlandDome, $HlandEarth, $HlandExpo, $HlandFactory, $HlandFarm, $HlandFire, $HlandFishLShip, $HlandFishMShip, $HlandFishSShip, $HlandFlower, $HlandForest, $HlandFuji, $HlandGhostShip, $HlandHaribote, $HlandHospital, $HlandHugecity, $HlandIceFloe, $HlandKInora, $HlandMegacity, $HlandMegaFact, $HlandMegaFarm, $HlandMegatower, $HlandMonsShip, $HlandMonster, $HlandMonument, $HlandMountain, $HlandMyhome, $HlandOcean, $HlandOil, $HlandOPlayer, $HlandOsen, $HlandPark, $HlandPirate, $HlandPlains, $HlandPolice, $HlandPort, $HlandProbeShip, $HlandSAEisei, $HlandSbase, $HlandSchool, $HlandSCity, $HlandSDefence, $HlandSea, $HlandSeisei, $HlandSFactory, $HlandSFarm, $HlandSlum, $HlandSMonument, $HlandSpaceBase, $HlandStadium, $HlandSunit, $HlandTcity, $HlandTitanic, $HlandTower, $HlandTown, $HlandTreasureS, $HlandTrump, $HlandWarp, $HlandWarpR, $HlandWaste, $HlandWindmill, $HlandWingDragon, $HlandZoo, $HlateLogPool, $HlogMax, $HlogOmit2, $HlogPool, $HmaxdisPollution, $HmaxExpPoint, $HmaxIsland, $HmonsBtlMaxHp, $HmonsBtlMaxPa, $HmonsterAGI, $HmonsterBHP, $HmonsterCLS, $HmonsterDEF, $HmonsterDestroy, $HmonsterDHP, $HmonsterExp, $HmonsterGRP, $HmonsterL1, $HmonsterL1Num, $HmonsterL2, $HmonsterL2Num, $HmonsterL3, $HmonsterL3Num, $HmonsterL4, $HmonsterL4Num, $HmonsterL5, $HmonsterL5Num, $HmonsterName, $HmonsterNumber, $HmonsterS, $HmonsterSEI, $HmonsterSKL, $HmonsterSP, $HmonsterSpecial, $HmonsterSTR, $HmonsterValue, $Hmonth, $HmonumentMissile, $HmonumentName, $HmonumentRocket, $Hocean, $HoceanSize, $HoilMoney, $HoilRatio, $hp, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $Hprize, $HprizeV, $HpunishInfo, $HrepeatTurn, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $HseaChk, $HsecretLogPool, $HsEisei, $HshipEX, $HshipFood, $HshipHP, $HshipKAI, $HshipMATK, $HshipMoney, $HshipName, $Hshiporder, $HshipSATK, $HshipSell, $HshipSP, $HsmonumentName, $HsmonumentNumber, $Hsolarwind, $Hspace, $HspaceEfficiency, $HspaceIncome, $Hsstartturn, $HStotalPoint, $HsurvFlg, $Hsurvivalturn, $HtagName2_, $HthisFile, $HtotalBumon, $HtotalMoney, $HtotalPoint, $Htournament, $HtreeValue, $HturnPrizeNumber, $HturnPrizePoint, $HturnPrizeUnit, $HturnPrizeVarious, $HugDokan, $HugFact, $HugFarm, $HugHasigo, $HugKiti, $HugMax, $HugOil, $HugRoad, $HugSpace, $HugTosi, $human, $HunitFood, $HunitMoney, $HunitOil, $HunitOre, $HunitPop, $HunitTime, $HunitWeapon, $HwarFlg, $HWeatherMax, $Hwflg, $HwinFood, $HwinIsland, $HwinMoney, $HwinWeapon, $imageDir, $lockMode, $toppage, $versionInfo;
	$i = null; $sx = null; $sy = null;
	for($i = 1; $i < 7; $i++){
		$sx = $x + $ax[$i];
		$sy = $y + $ay[$i];
		if (!($sy % 2) && ($y % 2)) { $sx--; }
		if(($sx < 0) || ($sx >= $HislandSize) || ($sy < 0) || ($sy >= $HislandSize)){
		}else{
			if($land[$sx][$sy] == $HlandKInora){
				list($ld, $d) = hako_pick(bigMonsterSpec($landValue[$x][$y]), array(2,3));
				$landValue[$sx][$sy] = $ld * 10 + $d;
			}elseif($HseaChk[$land[$sx][$sy]]){
				if(($land[$sx][$sy] == $HlandSea) && ($landValue[$sx][$sy] > 0)){
					$landValue[$sx][$sy] = $i + 10;
				}else{
					$landValue[$sx][$sy] = $i;
				}
			}else{
				$landValue[$sx][$sy] = $i + 20;
			}
			$land[$sx][$sy] = $HlandKInora;
		}
	}
}
// 구상 이노라 소거
function kinoraDel(&$land, &$landValue, $x, $y) {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $H_tagName2, $Haidpop, $Hallyflg, $Hallygroup, $haribote, $Hatkturn, $HbackupTimes, $HbackupTurn, $HbgInfoCell, $HbgTitleCell, $HbigcityFood, $HbigCityMFlg, $HcomBank, $HcomBase, $HcomBioMissile, $HcomBreakwater, $Hcomcolony, $HcomcolonyTurn, $HcomCost, $HcomDbase, $HcomDeathtrap, $HcomDestroy, $HcomDestroy2, $HcomDokan, $HcomDoNothing, $HcomDummy, $HcomEmigration, $HcomFactory, $HcomFarm, $HcomFire, $HcomFlower, $HcomFood, $HcomGiveup, $HcomHaribote, $HcomHospital, $HcomL, $HcommandMax, $HcomManipulate, $HcomMissileDM, $HcomMissileGM, $HcomMissileLD, $HcomMissileMGM, $HcomMissileNCM, $HcomMissileNM, $HcomMissilePLD, $HcomMissilePP, $HcomMissileRM, $HcomMissileRNG, $HcomMissileSPP, $HcomMissileSRM, $HcomMissileST, $HcomMoney, $HcomMonsAid, $HcomMonsEgg, $HcomMonsEnsei, $HcomMonsEsa, $HcomMonsEsaAid, $HcomMonsExer, $HcomMonsSell, $HcomMonsTettai, $HcomMonument, $HcomMountain, $HcomMyhome, $HcomName, $HcomOilBuy, $HcomOilSell, $HcomOMissileMGM, $HcomOMissileNM, $HcomOMissilePP, $HcomOMissileSPP, $HcomOreBuy, $HcomOreSell, $HcomPioneer, $HcomPlant, $HcomPolice, $HcomPort, $HcomPrepare, $HcomPrepare2, $HcomPresent, $HcomPresentAid, $HcomPropaganda, $HcomReclaim, $HcomReclaim2, $HcomSbase, $HcomSBuild, $HcomScity, $HcomSDbase, $HcomSDestroy, $HcomSearch, $HcomSEisei, $HcomSell, $HcomSellTree, $HcomSendMonster, $HcomSendMonsterTurn, $HcomSFactory, $HcomSFarm, $HcomSFood, $HcomShip, $HcomShipbuild, $HcomShipM, $HcomShipSell, $HcomSMissile, $HcomSMissileGM, $HcomSMissileMGM, $HcomSMissilePP, $HcomSMonument, $HcomSOccupy, $HcomSpaceBase, $HcomSpaceFarm, $HcomSpecialSPP, $HcomSPioneer, $HcomSpy, $HcomSSendMonster, $HcomSSendMonsterTurn, $HcomSTManipulate, $HcomSUnit, $HcomTeisatu, $HcomTower, $HcomTrump, $HcomUg, $HcomWarp, $HcomWeponBuy, $HcomWeponSell, $HcomWindmill, $HconsolationMatch, $HcurrentNumber, $HdBaseAuto, $HdefenceHex, $HdefenceSpace, $HdevelopeTurn, $HdirMode, $HdirName, $HdisAEruption, $HdisAkasio, $HdisBHarvest, $HdisCrime, $HdisEarthquake, $HdisEruption, $HdisFallBorder, $HdisFalldown, $HdisFire, $HdisGHarvest, $Hdishangen, $HdisHugeMeteo, $HdisKLimit, $HdisMaizo, $HdisMeteo, $HdisMonsBorder1, $HdisMonsBorder2, $HdisMonsBorder3, $HdisMonsBorder4, $HdisMonsBorder5, $HdisMonster, $HdisMonsterU, $HdisPirate, $HdisPollution, $HdisSeaMonster, $HdisSHugeMeteo, $HdisSpaceMonster1, $HdisSpaceMonster2, $HdisTinka, $HdisTreasureS, $HdisTsunami, $HdisTyphoon, $HdisUN, $HdisVGHarvest, $HearthAttack, $HeatenFood, $helpDir, $HfightMem, $HfightTurn, $HfinalTurn, $HgiveupTurn, $HhistoryMax, $HidToName, $HidToNumber, $HidToNumberR, $HinterTime, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HlandAegisShip, $HlandAirport, $HlandAmusement, $HlandBalloonS, $HlandBank, $HlandBase, $HlandBigcity, $HlandBreakwater, $HlandCasino, $HlandCoupleRock, $HlandDeathtrap, $HlandDefence, $HlandDokan, $HlandDome, $HlandEarth, $HlandExpo, $HlandFactory, $HlandFarm, $HlandFire, $HlandFishLShip, $HlandFishMShip, $HlandFishSShip, $HlandFlower, $HlandForest, $HlandFuji, $HlandGhostShip, $HlandHaribote, $HlandHospital, $HlandHugecity, $HlandIceFloe, $HlandKInora, $HlandMegacity, $HlandMegaFact, $HlandMegaFarm, $HlandMegatower, $HlandMonsShip, $HlandMonster, $HlandMonument, $HlandMountain, $HlandMyhome, $HlandOcean, $HlandOil, $HlandOPlayer, $HlandOsen, $HlandPark, $HlandPirate, $HlandPlains, $HlandPolice, $HlandPort, $HlandProbeShip, $HlandSAEisei, $HlandSbase, $HlandSchool, $HlandSCity, $HlandSDefence, $HlandSea, $HlandSeisei, $HlandSFactory, $HlandSFarm, $HlandSlum, $HlandSMonument, $HlandSpaceBase, $HlandStadium, $HlandSunit, $HlandTcity, $HlandTitanic, $HlandTower, $HlandTown, $HlandTreasureS, $HlandTrump, $HlandWarp, $HlandWarpR, $HlandWaste, $HlandWindmill, $HlandWingDragon, $HlandZoo, $HlateLogPool, $HlogMax, $HlogOmit2, $HlogPool, $HmaxdisPollution, $HmaxExpPoint, $HmaxIsland, $HmonsBtlMaxHp, $HmonsBtlMaxPa, $HmonsterAGI, $HmonsterBHP, $HmonsterCLS, $HmonsterDEF, $HmonsterDestroy, $HmonsterDHP, $HmonsterExp, $HmonsterGRP, $HmonsterL1, $HmonsterL1Num, $HmonsterL2, $HmonsterL2Num, $HmonsterL3, $HmonsterL3Num, $HmonsterL4, $HmonsterL4Num, $HmonsterL5, $HmonsterL5Num, $HmonsterName, $HmonsterNumber, $HmonsterS, $HmonsterSEI, $HmonsterSKL, $HmonsterSP, $HmonsterSpecial, $HmonsterSTR, $HmonsterValue, $Hmonth, $HmonumentMissile, $HmonumentName, $HmonumentRocket, $Hocean, $HoceanSize, $HoilMoney, $HoilRatio, $hp, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $Hprize, $HprizeV, $HpunishInfo, $HrepeatTurn, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $HseaChk, $HsecretLogPool, $HsEisei, $HshipEX, $HshipFood, $HshipHP, $HshipKAI, $HshipMATK, $HshipMoney, $HshipName, $Hshiporder, $HshipSATK, $HshipSell, $HshipSP, $HsmonumentName, $HsmonumentNumber, $Hsolarwind, $Hspace, $HspaceEfficiency, $HspaceIncome, $Hsstartturn, $HStotalPoint, $HsurvFlg, $Hsurvivalturn, $HtagName2_, $HthisFile, $HtotalBumon, $HtotalMoney, $HtotalPoint, $Htournament, $HtreeValue, $HturnPrizeNumber, $HturnPrizePoint, $HturnPrizeUnit, $HturnPrizeVarious, $HugDokan, $HugFact, $HugFarm, $HugHasigo, $HugKiti, $HugMax, $HugOil, $HugRoad, $HugSpace, $HugTosi, $human, $HunitFood, $HunitMoney, $HunitOil, $HunitOre, $HunitPop, $HunitTime, $HunitWeapon, $HwarFlg, $HWeatherMax, $Hwflg, $HwinFood, $HwinIsland, $HwinMoney, $HwinWeapon, $imageDir, $lockMode, $toppage, $versionInfo;
	$i = null; $sx = null; $sy = null;
	for($i = 0; $i < 7; $i++){
		$sx = $x + $ax[$i];
		$sy = $y + $ay[$i];
		if (!($sy % 2) && ($y % 2)) { $sx--; }
		if(($sx < 0) || ($sx >= $HislandSize) || ($sy < 0) || ($sy >= $HislandSize)){
		}else{
			$ld = hako_pick(bigMonsterSpec($landValue[$sx][$sy]), array(2));
			if($ld == 0){
				$land[$sx][$sy] = $HlandSea;
				$landValue[$sx][$sy] = 0;
			}elseif($ld == 1){
				$land[$sx][$sy] = $HlandSea;
				$landValue[$sx][$sy] = 1;
			}else{
				$land[$sx][$sy] = $HlandWaste;
				$landValue[$sx][$sy] = 0;
			}
		}
	}
}

// 다용되는 countAround계 처리를 기능별로 분별해 부하 경감
// 범위내의 지형을 체크한다
function chkAround($land, $x, $y, $kind, $range) {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $H_tagName2, $Haidpop, $Hallyflg, $Hallygroup, $haribote, $Hatkturn, $HbackupTimes, $HbackupTurn, $HbgInfoCell, $HbgTitleCell, $HbigcityFood, $HbigCityMFlg, $HcomBank, $HcomBase, $HcomBioMissile, $HcomBreakwater, $Hcomcolony, $HcomcolonyTurn, $HcomCost, $HcomDbase, $HcomDeathtrap, $HcomDestroy, $HcomDestroy2, $HcomDokan, $HcomDoNothing, $HcomDummy, $HcomEmigration, $HcomFactory, $HcomFarm, $HcomFire, $HcomFlower, $HcomFood, $HcomGiveup, $HcomHaribote, $HcomHospital, $HcomL, $HcommandMax, $HcomManipulate, $HcomMissileDM, $HcomMissileGM, $HcomMissileLD, $HcomMissileMGM, $HcomMissileNCM, $HcomMissileNM, $HcomMissilePLD, $HcomMissilePP, $HcomMissileRM, $HcomMissileRNG, $HcomMissileSPP, $HcomMissileSRM, $HcomMissileST, $HcomMoney, $HcomMonsAid, $HcomMonsEgg, $HcomMonsEnsei, $HcomMonsEsa, $HcomMonsEsaAid, $HcomMonsExer, $HcomMonsSell, $HcomMonsTettai, $HcomMonument, $HcomMountain, $HcomMyhome, $HcomName, $HcomOilBuy, $HcomOilSell, $HcomOMissileMGM, $HcomOMissileNM, $HcomOMissilePP, $HcomOMissileSPP, $HcomOreBuy, $HcomOreSell, $HcomPioneer, $HcomPlant, $HcomPolice, $HcomPort, $HcomPrepare, $HcomPrepare2, $HcomPresent, $HcomPresentAid, $HcomPropaganda, $HcomReclaim, $HcomReclaim2, $HcomSbase, $HcomSBuild, $HcomScity, $HcomSDbase, $HcomSDestroy, $HcomSearch, $HcomSEisei, $HcomSell, $HcomSellTree, $HcomSendMonster, $HcomSendMonsterTurn, $HcomSFactory, $HcomSFarm, $HcomSFood, $HcomShip, $HcomShipbuild, $HcomShipM, $HcomShipSell, $HcomSMissile, $HcomSMissileGM, $HcomSMissileMGM, $HcomSMissilePP, $HcomSMonument, $HcomSOccupy, $HcomSpaceBase, $HcomSpaceFarm, $HcomSpecialSPP, $HcomSPioneer, $HcomSpy, $HcomSSendMonster, $HcomSSendMonsterTurn, $HcomSTManipulate, $HcomSUnit, $HcomTeisatu, $HcomTower, $HcomTrump, $HcomUg, $HcomWarp, $HcomWeponBuy, $HcomWeponSell, $HcomWindmill, $HconsolationMatch, $HcurrentNumber, $HdBaseAuto, $HdefenceHex, $HdefenceSpace, $HdevelopeTurn, $HdirMode, $HdirName, $HdisAEruption, $HdisAkasio, $HdisBHarvest, $HdisCrime, $HdisEarthquake, $HdisEruption, $HdisFallBorder, $HdisFalldown, $HdisFire, $HdisGHarvest, $Hdishangen, $HdisHugeMeteo, $HdisKLimit, $HdisMaizo, $HdisMeteo, $HdisMonsBorder1, $HdisMonsBorder2, $HdisMonsBorder3, $HdisMonsBorder4, $HdisMonsBorder5, $HdisMonster, $HdisMonsterU, $HdisPirate, $HdisPollution, $HdisSeaMonster, $HdisSHugeMeteo, $HdisSpaceMonster1, $HdisSpaceMonster2, $HdisTinka, $HdisTreasureS, $HdisTsunami, $HdisTyphoon, $HdisUN, $HdisVGHarvest, $HearthAttack, $HeatenFood, $helpDir, $HfightMem, $HfightTurn, $HfinalTurn, $HgiveupTurn, $HhistoryMax, $HidToName, $HidToNumber, $HidToNumberR, $HinterTime, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HlandAegisShip, $HlandAirport, $HlandAmusement, $HlandBalloonS, $HlandBank, $HlandBase, $HlandBigcity, $HlandBreakwater, $HlandCasino, $HlandCoupleRock, $HlandDeathtrap, $HlandDefence, $HlandDokan, $HlandDome, $HlandEarth, $HlandExpo, $HlandFactory, $HlandFarm, $HlandFire, $HlandFishLShip, $HlandFishMShip, $HlandFishSShip, $HlandFlower, $HlandForest, $HlandFuji, $HlandGhostShip, $HlandHaribote, $HlandHospital, $HlandHugecity, $HlandIceFloe, $HlandKInora, $HlandMegacity, $HlandMegaFact, $HlandMegaFarm, $HlandMegatower, $HlandMonsShip, $HlandMonster, $HlandMonument, $HlandMountain, $HlandMyhome, $HlandOcean, $HlandOil, $HlandOPlayer, $HlandOsen, $HlandPark, $HlandPirate, $HlandPlains, $HlandPolice, $HlandPort, $HlandProbeShip, $HlandSAEisei, $HlandSbase, $HlandSchool, $HlandSCity, $HlandSDefence, $HlandSea, $HlandSeisei, $HlandSFactory, $HlandSFarm, $HlandSlum, $HlandSMonument, $HlandSpaceBase, $HlandStadium, $HlandSunit, $HlandTcity, $HlandTitanic, $HlandTower, $HlandTown, $HlandTreasureS, $HlandTrump, $HlandWarp, $HlandWarpR, $HlandWaste, $HlandWindmill, $HlandWingDragon, $HlandZoo, $HlateLogPool, $HlogMax, $HlogOmit2, $HlogPool, $HmaxdisPollution, $HmaxExpPoint, $HmaxIsland, $HmonsBtlMaxHp, $HmonsBtlMaxPa, $HmonsterAGI, $HmonsterBHP, $HmonsterCLS, $HmonsterDEF, $HmonsterDestroy, $HmonsterDHP, $HmonsterExp, $HmonsterGRP, $HmonsterL1, $HmonsterL1Num, $HmonsterL2, $HmonsterL2Num, $HmonsterL3, $HmonsterL3Num, $HmonsterL4, $HmonsterL4Num, $HmonsterL5, $HmonsterL5Num, $HmonsterName, $HmonsterNumber, $HmonsterS, $HmonsterSEI, $HmonsterSKL, $HmonsterSP, $HmonsterSpecial, $HmonsterSTR, $HmonsterValue, $Hmonth, $HmonumentMissile, $HmonumentName, $HmonumentRocket, $Hocean, $HoceanSize, $HoilMoney, $HoilRatio, $hp, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $Hprize, $HprizeV, $HpunishInfo, $HrepeatTurn, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $HseaChk, $HsecretLogPool, $HsEisei, $HshipEX, $HshipFood, $HshipHP, $HshipKAI, $HshipMATK, $HshipMoney, $HshipName, $Hshiporder, $HshipSATK, $HshipSell, $HshipSP, $HsmonumentName, $HsmonumentNumber, $Hsolarwind, $Hspace, $HspaceEfficiency, $HspaceIncome, $Hsstartturn, $HStotalPoint, $HsurvFlg, $Hsurvivalturn, $HtagName2_, $HthisFile, $HtotalBumon, $HtotalMoney, $HtotalPoint, $Htournament, $HtreeValue, $HturnPrizeNumber, $HturnPrizePoint, $HturnPrizeUnit, $HturnPrizeVarious, $HugDokan, $HugFact, $HugFarm, $HugHasigo, $HugKiti, $HugMax, $HugOil, $HugRoad, $HugSpace, $HugTosi, $human, $HunitFood, $HunitMoney, $HunitOil, $HunitOre, $HunitPop, $HunitTime, $HunitWeapon, $HwarFlg, $HWeatherMax, $Hwflg, $HwinFood, $HwinIsland, $HwinMoney, $HwinWeapon, $imageDir, $lockMode, $toppage, $versionInfo;
	$i = null; $sx = null; $sy = null;
	for($i = 0; $i < $range; $i++){
		$sx = $x + $ax[$i];
		$sy = $y + $ay[$i];
		if (!($sy % 2) && ($y % 2)) { $sx--; }
		if(($sx < 0) || ($sx >= $HislandSize) || ($sy < 0) || ($sy >= $HislandSize)){
			//  범위외의 경우해라면 1
			if ($kind == $HlandSea) { return 1; }
		}elseif($land[$sx][$sy] == $kind){
			return 1;
		}
	}
	return 0;
}
// 범위내의 지형을 체크하는 $lv==0때는 chkAround를 사용하도록(듯이)
function chkAroundEX($land, $landValue, $x, $y, $kind, $lv, $range) {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $H_tagName2, $Haidpop, $Hallyflg, $Hallygroup, $haribote, $Hatkturn, $HbackupTimes, $HbackupTurn, $HbgInfoCell, $HbgTitleCell, $HbigcityFood, $HbigCityMFlg, $HcomBank, $HcomBase, $HcomBioMissile, $HcomBreakwater, $Hcomcolony, $HcomcolonyTurn, $HcomCost, $HcomDbase, $HcomDeathtrap, $HcomDestroy, $HcomDestroy2, $HcomDokan, $HcomDoNothing, $HcomDummy, $HcomEmigration, $HcomFactory, $HcomFarm, $HcomFire, $HcomFlower, $HcomFood, $HcomGiveup, $HcomHaribote, $HcomHospital, $HcomL, $HcommandMax, $HcomManipulate, $HcomMissileDM, $HcomMissileGM, $HcomMissileLD, $HcomMissileMGM, $HcomMissileNCM, $HcomMissileNM, $HcomMissilePLD, $HcomMissilePP, $HcomMissileRM, $HcomMissileRNG, $HcomMissileSPP, $HcomMissileSRM, $HcomMissileST, $HcomMoney, $HcomMonsAid, $HcomMonsEgg, $HcomMonsEnsei, $HcomMonsEsa, $HcomMonsEsaAid, $HcomMonsExer, $HcomMonsSell, $HcomMonsTettai, $HcomMonument, $HcomMountain, $HcomMyhome, $HcomName, $HcomOilBuy, $HcomOilSell, $HcomOMissileMGM, $HcomOMissileNM, $HcomOMissilePP, $HcomOMissileSPP, $HcomOreBuy, $HcomOreSell, $HcomPioneer, $HcomPlant, $HcomPolice, $HcomPort, $HcomPrepare, $HcomPrepare2, $HcomPresent, $HcomPresentAid, $HcomPropaganda, $HcomReclaim, $HcomReclaim2, $HcomSbase, $HcomSBuild, $HcomScity, $HcomSDbase, $HcomSDestroy, $HcomSearch, $HcomSEisei, $HcomSell, $HcomSellTree, $HcomSendMonster, $HcomSendMonsterTurn, $HcomSFactory, $HcomSFarm, $HcomSFood, $HcomShip, $HcomShipbuild, $HcomShipM, $HcomShipSell, $HcomSMissile, $HcomSMissileGM, $HcomSMissileMGM, $HcomSMissilePP, $HcomSMonument, $HcomSOccupy, $HcomSpaceBase, $HcomSpaceFarm, $HcomSpecialSPP, $HcomSPioneer, $HcomSpy, $HcomSSendMonster, $HcomSSendMonsterTurn, $HcomSTManipulate, $HcomSUnit, $HcomTeisatu, $HcomTower, $HcomTrump, $HcomUg, $HcomWarp, $HcomWeponBuy, $HcomWeponSell, $HcomWindmill, $HconsolationMatch, $HcurrentNumber, $HdBaseAuto, $HdefenceHex, $HdefenceSpace, $HdevelopeTurn, $HdirMode, $HdirName, $HdisAEruption, $HdisAkasio, $HdisBHarvest, $HdisCrime, $HdisEarthquake, $HdisEruption, $HdisFallBorder, $HdisFalldown, $HdisFire, $HdisGHarvest, $Hdishangen, $HdisHugeMeteo, $HdisKLimit, $HdisMaizo, $HdisMeteo, $HdisMonsBorder1, $HdisMonsBorder2, $HdisMonsBorder3, $HdisMonsBorder4, $HdisMonsBorder5, $HdisMonster, $HdisMonsterU, $HdisPirate, $HdisPollution, $HdisSeaMonster, $HdisSHugeMeteo, $HdisSpaceMonster1, $HdisSpaceMonster2, $HdisTinka, $HdisTreasureS, $HdisTsunami, $HdisTyphoon, $HdisUN, $HdisVGHarvest, $HearthAttack, $HeatenFood, $helpDir, $HfightMem, $HfightTurn, $HfinalTurn, $HgiveupTurn, $HhistoryMax, $HidToName, $HidToNumber, $HidToNumberR, $HinterTime, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HlandAegisShip, $HlandAirport, $HlandAmusement, $HlandBalloonS, $HlandBank, $HlandBase, $HlandBigcity, $HlandBreakwater, $HlandCasino, $HlandCoupleRock, $HlandDeathtrap, $HlandDefence, $HlandDokan, $HlandDome, $HlandEarth, $HlandExpo, $HlandFactory, $HlandFarm, $HlandFire, $HlandFishLShip, $HlandFishMShip, $HlandFishSShip, $HlandFlower, $HlandForest, $HlandFuji, $HlandGhostShip, $HlandHaribote, $HlandHospital, $HlandHugecity, $HlandIceFloe, $HlandKInora, $HlandMegacity, $HlandMegaFact, $HlandMegaFarm, $HlandMegatower, $HlandMonsShip, $HlandMonster, $HlandMonument, $HlandMountain, $HlandMyhome, $HlandOcean, $HlandOil, $HlandOPlayer, $HlandOsen, $HlandPark, $HlandPirate, $HlandPlains, $HlandPolice, $HlandPort, $HlandProbeShip, $HlandSAEisei, $HlandSbase, $HlandSchool, $HlandSCity, $HlandSDefence, $HlandSea, $HlandSeisei, $HlandSFactory, $HlandSFarm, $HlandSlum, $HlandSMonument, $HlandSpaceBase, $HlandStadium, $HlandSunit, $HlandTcity, $HlandTitanic, $HlandTower, $HlandTown, $HlandTreasureS, $HlandTrump, $HlandWarp, $HlandWarpR, $HlandWaste, $HlandWindmill, $HlandWingDragon, $HlandZoo, $HlateLogPool, $HlogMax, $HlogOmit2, $HlogPool, $HmaxdisPollution, $HmaxExpPoint, $HmaxIsland, $HmonsBtlMaxHp, $HmonsBtlMaxPa, $HmonsterAGI, $HmonsterBHP, $HmonsterCLS, $HmonsterDEF, $HmonsterDestroy, $HmonsterDHP, $HmonsterExp, $HmonsterGRP, $HmonsterL1, $HmonsterL1Num, $HmonsterL2, $HmonsterL2Num, $HmonsterL3, $HmonsterL3Num, $HmonsterL4, $HmonsterL4Num, $HmonsterL5, $HmonsterL5Num, $HmonsterName, $HmonsterNumber, $HmonsterS, $HmonsterSEI, $HmonsterSKL, $HmonsterSP, $HmonsterSpecial, $HmonsterSTR, $HmonsterValue, $Hmonth, $HmonumentMissile, $HmonumentName, $HmonumentRocket, $Hocean, $HoceanSize, $HoilMoney, $HoilRatio, $hp, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $Hprize, $HprizeV, $HpunishInfo, $HrepeatTurn, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $HseaChk, $HsecretLogPool, $HsEisei, $HshipEX, $HshipFood, $HshipHP, $HshipKAI, $HshipMATK, $HshipMoney, $HshipName, $Hshiporder, $HshipSATK, $HshipSell, $HshipSP, $HsmonumentName, $HsmonumentNumber, $Hsolarwind, $Hspace, $HspaceEfficiency, $HspaceIncome, $Hsstartturn, $HStotalPoint, $HsurvFlg, $Hsurvivalturn, $HtagName2_, $HthisFile, $HtotalBumon, $HtotalMoney, $HtotalPoint, $Htournament, $HtreeValue, $HturnPrizeNumber, $HturnPrizePoint, $HturnPrizeUnit, $HturnPrizeVarious, $HugDokan, $HugFact, $HugFarm, $HugHasigo, $HugKiti, $HugMax, $HugOil, $HugRoad, $HugSpace, $HugTosi, $human, $HunitFood, $HunitMoney, $HunitOil, $HunitOre, $HunitPop, $HunitTime, $HunitWeapon, $HwarFlg, $HWeatherMax, $Hwflg, $HwinFood, $HwinIsland, $HwinMoney, $HwinWeapon, $imageDir, $lockMode, $toppage, $versionInfo;
	$i = null; $sx = null; $sy = null;
	for($i = 0; $i < $range; $i++){
		$sx = $x + $ax[$i];
		$sy = $y + $ay[$i];
		if (!($sy % 2) && ($y % 2)) { $sx--; }
		if(($sx < 0) || ($sx >= $HislandSize) || ($sy < 0) || ($sy >= $HislandSize)){
			// 범위외의 경우해라면 가산
			if ($kind == $HlandSea) { return 1; }
		}elseif($lv < 10){
			if (($land[$sx][$sy] == $kind) && ($landValue[$sx][$sy] == $lv)) { return 1; }
		}elseif(($land[$sx][$sy] == $kind) && ($landValue[$sx][$sy] >= $lv)){
			return 1;
		}
	}
	return 0;
}

//  범위내의 지형을 센다

function countAround($land, $x, $y, $kind, $range) {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $H_tagName2, $Haidpop, $Hallyflg, $Hallygroup, $haribote, $Hatkturn, $HbackupTimes, $HbackupTurn, $HbgInfoCell, $HbgTitleCell, $HbigcityFood, $HbigCityMFlg, $HcomBank, $HcomBase, $HcomBioMissile, $HcomBreakwater, $Hcomcolony, $HcomcolonyTurn, $HcomCost, $HcomDbase, $HcomDeathtrap, $HcomDestroy, $HcomDestroy2, $HcomDokan, $HcomDoNothing, $HcomDummy, $HcomEmigration, $HcomFactory, $HcomFarm, $HcomFire, $HcomFlower, $HcomFood, $HcomGiveup, $HcomHaribote, $HcomHospital, $HcomL, $HcommandMax, $HcomManipulate, $HcomMissileDM, $HcomMissileGM, $HcomMissileLD, $HcomMissileMGM, $HcomMissileNCM, $HcomMissileNM, $HcomMissilePLD, $HcomMissilePP, $HcomMissileRM, $HcomMissileRNG, $HcomMissileSPP, $HcomMissileSRM, $HcomMissileST, $HcomMoney, $HcomMonsAid, $HcomMonsEgg, $HcomMonsEnsei, $HcomMonsEsa, $HcomMonsEsaAid, $HcomMonsExer, $HcomMonsSell, $HcomMonsTettai, $HcomMonument, $HcomMountain, $HcomMyhome, $HcomName, $HcomOilBuy, $HcomOilSell, $HcomOMissileMGM, $HcomOMissileNM, $HcomOMissilePP, $HcomOMissileSPP, $HcomOreBuy, $HcomOreSell, $HcomPioneer, $HcomPlant, $HcomPolice, $HcomPort, $HcomPrepare, $HcomPrepare2, $HcomPresent, $HcomPresentAid, $HcomPropaganda, $HcomReclaim, $HcomReclaim2, $HcomSbase, $HcomSBuild, $HcomScity, $HcomSDbase, $HcomSDestroy, $HcomSearch, $HcomSEisei, $HcomSell, $HcomSellTree, $HcomSendMonster, $HcomSendMonsterTurn, $HcomSFactory, $HcomSFarm, $HcomSFood, $HcomShip, $HcomShipbuild, $HcomShipM, $HcomShipSell, $HcomSMissile, $HcomSMissileGM, $HcomSMissileMGM, $HcomSMissilePP, $HcomSMonument, $HcomSOccupy, $HcomSpaceBase, $HcomSpaceFarm, $HcomSpecialSPP, $HcomSPioneer, $HcomSpy, $HcomSSendMonster, $HcomSSendMonsterTurn, $HcomSTManipulate, $HcomSUnit, $HcomTeisatu, $HcomTower, $HcomTrump, $HcomUg, $HcomWarp, $HcomWeponBuy, $HcomWeponSell, $HcomWindmill, $HconsolationMatch, $HcurrentNumber, $HdBaseAuto, $HdefenceHex, $HdefenceSpace, $HdevelopeTurn, $HdirMode, $HdirName, $HdisAEruption, $HdisAkasio, $HdisBHarvest, $HdisCrime, $HdisEarthquake, $HdisEruption, $HdisFallBorder, $HdisFalldown, $HdisFire, $HdisGHarvest, $Hdishangen, $HdisHugeMeteo, $HdisKLimit, $HdisMaizo, $HdisMeteo, $HdisMonsBorder1, $HdisMonsBorder2, $HdisMonsBorder3, $HdisMonsBorder4, $HdisMonsBorder5, $HdisMonster, $HdisMonsterU, $HdisPirate, $HdisPollution, $HdisSeaMonster, $HdisSHugeMeteo, $HdisSpaceMonster1, $HdisSpaceMonster2, $HdisTinka, $HdisTreasureS, $HdisTsunami, $HdisTyphoon, $HdisUN, $HdisVGHarvest, $HearthAttack, $HeatenFood, $helpDir, $HfightMem, $HfightTurn, $HfinalTurn, $HgiveupTurn, $HhistoryMax, $HidToName, $HidToNumber, $HidToNumberR, $HinterTime, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HlandAegisShip, $HlandAirport, $HlandAmusement, $HlandBalloonS, $HlandBank, $HlandBase, $HlandBigcity, $HlandBreakwater, $HlandCasino, $HlandCoupleRock, $HlandDeathtrap, $HlandDefence, $HlandDokan, $HlandDome, $HlandEarth, $HlandExpo, $HlandFactory, $HlandFarm, $HlandFire, $HlandFishLShip, $HlandFishMShip, $HlandFishSShip, $HlandFlower, $HlandForest, $HlandFuji, $HlandGhostShip, $HlandHaribote, $HlandHospital, $HlandHugecity, $HlandIceFloe, $HlandKInora, $HlandMegacity, $HlandMegaFact, $HlandMegaFarm, $HlandMegatower, $HlandMonsShip, $HlandMonster, $HlandMonument, $HlandMountain, $HlandMyhome, $HlandOcean, $HlandOil, $HlandOPlayer, $HlandOsen, $HlandPark, $HlandPirate, $HlandPlains, $HlandPolice, $HlandPort, $HlandProbeShip, $HlandSAEisei, $HlandSbase, $HlandSchool, $HlandSCity, $HlandSDefence, $HlandSea, $HlandSeisei, $HlandSFactory, $HlandSFarm, $HlandSlum, $HlandSMonument, $HlandSpaceBase, $HlandStadium, $HlandSunit, $HlandTcity, $HlandTitanic, $HlandTower, $HlandTown, $HlandTreasureS, $HlandTrump, $HlandWarp, $HlandWarpR, $HlandWaste, $HlandWindmill, $HlandWingDragon, $HlandZoo, $HlateLogPool, $HlogMax, $HlogOmit2, $HlogPool, $HmaxdisPollution, $HmaxExpPoint, $HmaxIsland, $HmonsBtlMaxHp, $HmonsBtlMaxPa, $HmonsterAGI, $HmonsterBHP, $HmonsterCLS, $HmonsterDEF, $HmonsterDestroy, $HmonsterDHP, $HmonsterExp, $HmonsterGRP, $HmonsterL1, $HmonsterL1Num, $HmonsterL2, $HmonsterL2Num, $HmonsterL3, $HmonsterL3Num, $HmonsterL4, $HmonsterL4Num, $HmonsterL5, $HmonsterL5Num, $HmonsterName, $HmonsterNumber, $HmonsterS, $HmonsterSEI, $HmonsterSKL, $HmonsterSP, $HmonsterSpecial, $HmonsterSTR, $HmonsterValue, $Hmonth, $HmonumentMissile, $HmonumentName, $HmonumentRocket, $Hocean, $HoceanSize, $HoilMoney, $HoilRatio, $hp, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $Hprize, $HprizeV, $HpunishInfo, $HrepeatTurn, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $HseaChk, $HsecretLogPool, $HsEisei, $HshipEX, $HshipFood, $HshipHP, $HshipKAI, $HshipMATK, $HshipMoney, $HshipName, $Hshiporder, $HshipSATK, $HshipSell, $HshipSP, $HsmonumentName, $HsmonumentNumber, $Hsolarwind, $Hspace, $HspaceEfficiency, $HspaceIncome, $Hsstartturn, $HStotalPoint, $HsurvFlg, $Hsurvivalturn, $HtagName2_, $HthisFile, $HtotalBumon, $HtotalMoney, $HtotalPoint, $Htournament, $HtreeValue, $HturnPrizeNumber, $HturnPrizePoint, $HturnPrizeUnit, $HturnPrizeVarious, $HugDokan, $HugFact, $HugFarm, $HugHasigo, $HugKiti, $HugMax, $HugOil, $HugRoad, $HugSpace, $HugTosi, $human, $HunitFood, $HunitMoney, $HunitOil, $HunitOre, $HunitPop, $HunitTime, $HunitWeapon, $HwarFlg, $HWeatherMax, $Hwflg, $HwinFood, $HwinIsland, $HwinMoney, $HwinWeapon, $imageDir, $lockMode, $toppage, $versionInfo;
	$i = null; $sx = null; $sy = null;
	$count = 0;
	for($i = 0; $i < $range; $i++){
		$sx = $x + $ax[$i];
		$sy = $y + $ay[$i];
		if (!($sy % 2) && ($y % 2)) { $sx--; }
		if(($sx < 0) || ($sx >= $HislandSize) || ($sy < 0) || ($sy >= $HislandSize)){
			// 범위외의 경우해라면 가산
			if ($kind == $HlandSea) { $count++; }
		}elseif($land[$sx][$sy] == $kind){
			$count++;
		}
	}
	return $count;
}

// 범위내의 지형을 세는 확장판 $lv==0때는 countAround를 사용하도록(듯이)
function countAroundEX($land, $landValue, $x, $y, $kind, $lv, $range) {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $H_tagName2, $Haidpop, $Hallyflg, $Hallygroup, $haribote, $Hatkturn, $HbackupTimes, $HbackupTurn, $HbgInfoCell, $HbgTitleCell, $HbigcityFood, $HbigCityMFlg, $HcomBank, $HcomBase, $HcomBioMissile, $HcomBreakwater, $Hcomcolony, $HcomcolonyTurn, $HcomCost, $HcomDbase, $HcomDeathtrap, $HcomDestroy, $HcomDestroy2, $HcomDokan, $HcomDoNothing, $HcomDummy, $HcomEmigration, $HcomFactory, $HcomFarm, $HcomFire, $HcomFlower, $HcomFood, $HcomGiveup, $HcomHaribote, $HcomHospital, $HcomL, $HcommandMax, $HcomManipulate, $HcomMissileDM, $HcomMissileGM, $HcomMissileLD, $HcomMissileMGM, $HcomMissileNCM, $HcomMissileNM, $HcomMissilePLD, $HcomMissilePP, $HcomMissileRM, $HcomMissileRNG, $HcomMissileSPP, $HcomMissileSRM, $HcomMissileST, $HcomMoney, $HcomMonsAid, $HcomMonsEgg, $HcomMonsEnsei, $HcomMonsEsa, $HcomMonsEsaAid, $HcomMonsExer, $HcomMonsSell, $HcomMonsTettai, $HcomMonument, $HcomMountain, $HcomMyhome, $HcomName, $HcomOilBuy, $HcomOilSell, $HcomOMissileMGM, $HcomOMissileNM, $HcomOMissilePP, $HcomOMissileSPP, $HcomOreBuy, $HcomOreSell, $HcomPioneer, $HcomPlant, $HcomPolice, $HcomPort, $HcomPrepare, $HcomPrepare2, $HcomPresent, $HcomPresentAid, $HcomPropaganda, $HcomReclaim, $HcomReclaim2, $HcomSbase, $HcomSBuild, $HcomScity, $HcomSDbase, $HcomSDestroy, $HcomSearch, $HcomSEisei, $HcomSell, $HcomSellTree, $HcomSendMonster, $HcomSendMonsterTurn, $HcomSFactory, $HcomSFarm, $HcomSFood, $HcomShip, $HcomShipbuild, $HcomShipM, $HcomShipSell, $HcomSMissile, $HcomSMissileGM, $HcomSMissileMGM, $HcomSMissilePP, $HcomSMonument, $HcomSOccupy, $HcomSpaceBase, $HcomSpaceFarm, $HcomSpecialSPP, $HcomSPioneer, $HcomSpy, $HcomSSendMonster, $HcomSSendMonsterTurn, $HcomSTManipulate, $HcomSUnit, $HcomTeisatu, $HcomTower, $HcomTrump, $HcomUg, $HcomWarp, $HcomWeponBuy, $HcomWeponSell, $HcomWindmill, $HconsolationMatch, $HcurrentNumber, $HdBaseAuto, $HdefenceHex, $HdefenceSpace, $HdevelopeTurn, $HdirMode, $HdirName, $HdisAEruption, $HdisAkasio, $HdisBHarvest, $HdisCrime, $HdisEarthquake, $HdisEruption, $HdisFallBorder, $HdisFalldown, $HdisFire, $HdisGHarvest, $Hdishangen, $HdisHugeMeteo, $HdisKLimit, $HdisMaizo, $HdisMeteo, $HdisMonsBorder1, $HdisMonsBorder2, $HdisMonsBorder3, $HdisMonsBorder4, $HdisMonsBorder5, $HdisMonster, $HdisMonsterU, $HdisPirate, $HdisPollution, $HdisSeaMonster, $HdisSHugeMeteo, $HdisSpaceMonster1, $HdisSpaceMonster2, $HdisTinka, $HdisTreasureS, $HdisTsunami, $HdisTyphoon, $HdisUN, $HdisVGHarvest, $HearthAttack, $HeatenFood, $helpDir, $HfightMem, $HfightTurn, $HfinalTurn, $HgiveupTurn, $HhistoryMax, $HidToName, $HidToNumber, $HidToNumberR, $HinterTime, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HlandAegisShip, $HlandAirport, $HlandAmusement, $HlandBalloonS, $HlandBank, $HlandBase, $HlandBigcity, $HlandBreakwater, $HlandCasino, $HlandCoupleRock, $HlandDeathtrap, $HlandDefence, $HlandDokan, $HlandDome, $HlandEarth, $HlandExpo, $HlandFactory, $HlandFarm, $HlandFire, $HlandFishLShip, $HlandFishMShip, $HlandFishSShip, $HlandFlower, $HlandForest, $HlandFuji, $HlandGhostShip, $HlandHaribote, $HlandHospital, $HlandHugecity, $HlandIceFloe, $HlandKInora, $HlandMegacity, $HlandMegaFact, $HlandMegaFarm, $HlandMegatower, $HlandMonsShip, $HlandMonster, $HlandMonument, $HlandMountain, $HlandMyhome, $HlandOcean, $HlandOil, $HlandOPlayer, $HlandOsen, $HlandPark, $HlandPirate, $HlandPlains, $HlandPolice, $HlandPort, $HlandProbeShip, $HlandSAEisei, $HlandSbase, $HlandSchool, $HlandSCity, $HlandSDefence, $HlandSea, $HlandSeisei, $HlandSFactory, $HlandSFarm, $HlandSlum, $HlandSMonument, $HlandSpaceBase, $HlandStadium, $HlandSunit, $HlandTcity, $HlandTitanic, $HlandTower, $HlandTown, $HlandTreasureS, $HlandTrump, $HlandWarp, $HlandWarpR, $HlandWaste, $HlandWindmill, $HlandWingDragon, $HlandZoo, $HlateLogPool, $HlogMax, $HlogOmit2, $HlogPool, $HmaxdisPollution, $HmaxExpPoint, $HmaxIsland, $HmonsBtlMaxHp, $HmonsBtlMaxPa, $HmonsterAGI, $HmonsterBHP, $HmonsterCLS, $HmonsterDEF, $HmonsterDestroy, $HmonsterDHP, $HmonsterExp, $HmonsterGRP, $HmonsterL1, $HmonsterL1Num, $HmonsterL2, $HmonsterL2Num, $HmonsterL3, $HmonsterL3Num, $HmonsterL4, $HmonsterL4Num, $HmonsterL5, $HmonsterL5Num, $HmonsterName, $HmonsterNumber, $HmonsterS, $HmonsterSEI, $HmonsterSKL, $HmonsterSP, $HmonsterSpecial, $HmonsterSTR, $HmonsterValue, $Hmonth, $HmonumentMissile, $HmonumentName, $HmonumentRocket, $Hocean, $HoceanSize, $HoilMoney, $HoilRatio, $hp, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $Hprize, $HprizeV, $HpunishInfo, $HrepeatTurn, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $HseaChk, $HsecretLogPool, $HsEisei, $HshipEX, $HshipFood, $HshipHP, $HshipKAI, $HshipMATK, $HshipMoney, $HshipName, $Hshiporder, $HshipSATK, $HshipSell, $HshipSP, $HsmonumentName, $HsmonumentNumber, $Hsolarwind, $Hspace, $HspaceEfficiency, $HspaceIncome, $Hsstartturn, $HStotalPoint, $HsurvFlg, $Hsurvivalturn, $HtagName2_, $HthisFile, $HtotalBumon, $HtotalMoney, $HtotalPoint, $Htournament, $HtreeValue, $HturnPrizeNumber, $HturnPrizePoint, $HturnPrizeUnit, $HturnPrizeVarious, $HugDokan, $HugFact, $HugFarm, $HugHasigo, $HugKiti, $HugMax, $HugOil, $HugRoad, $HugSpace, $HugTosi, $human, $HunitFood, $HunitMoney, $HunitOil, $HunitOre, $HunitPop, $HunitTime, $HunitWeapon, $HwarFlg, $HWeatherMax, $Hwflg, $HwinFood, $HwinIsland, $HwinMoney, $HwinWeapon, $imageDir, $lockMode, $toppage, $versionInfo;
	$i = null; $sx = null; $sy = null;
	$count = 0;
	for($i = 0; $i < $range; $i++){
		$sx = $x + $ax[$i];
		$sy = $y + $ay[$i];
		if (!($sy % 2) && ($y % 2)) { $sx--; }
		if(($sx < 0) || ($sx >= $HislandSize) || ($sy < 0) || ($sy >= $HislandSize)){
			// 범위외의 경우해라면 가산
			if ($kind == $HlandSea) { $count++; }
		}elseif($lv < 10){
			if (($land[$sx][$sy] == $kind) && ($landValue[$sx][$sy] == $lv)) { $count++; }
		}elseif(($land[$sx][$sy] == $kind) && ($landValue[$sx][$sy] >= $lv)){
			$count++;
		}
	}
	return $count;
}

// 괴수 배틀 성장률 계산용
function MonsterSei($type, $sup) {
	if($type == 1){ #모두 높다
		$sup[0]++;
		$sup[1]++;
		$sup[3]++;
		$sup[4]++;
	}elseif($type == 2){ #낮다
		$sup[0]--;
		$sup[1]--;
		$sup[3]--;
		$sup[4]--;
	}elseif($type == 3){ #공격 높다
		$sup[1]++;
	}elseif($type == 4){ #수비 높다
		$sup[2] = 2;
	}elseif($type == 5){ #회명 높다
		$sup[3]++;
		$sup[4]++;
	}
	return $sup;
}

//  배계 출현 위치
function shipAppear($land, $direction) {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $H_tagName2, $Haidpop, $Hallyflg, $Hallygroup, $haribote, $Hatkturn, $HbackupTimes, $HbackupTurn, $HbgInfoCell, $HbgTitleCell, $HbigcityFood, $HbigCityMFlg, $HcomBank, $HcomBase, $HcomBioMissile, $HcomBreakwater, $Hcomcolony, $HcomcolonyTurn, $HcomCost, $HcomDbase, $HcomDeathtrap, $HcomDestroy, $HcomDestroy2, $HcomDokan, $HcomDoNothing, $HcomDummy, $HcomEmigration, $HcomFactory, $HcomFarm, $HcomFire, $HcomFlower, $HcomFood, $HcomGiveup, $HcomHaribote, $HcomHospital, $HcomL, $HcommandMax, $HcomManipulate, $HcomMissileDM, $HcomMissileGM, $HcomMissileLD, $HcomMissileMGM, $HcomMissileNCM, $HcomMissileNM, $HcomMissilePLD, $HcomMissilePP, $HcomMissileRM, $HcomMissileRNG, $HcomMissileSPP, $HcomMissileSRM, $HcomMissileST, $HcomMoney, $HcomMonsAid, $HcomMonsEgg, $HcomMonsEnsei, $HcomMonsEsa, $HcomMonsEsaAid, $HcomMonsExer, $HcomMonsSell, $HcomMonsTettai, $HcomMonument, $HcomMountain, $HcomMyhome, $HcomName, $HcomOilBuy, $HcomOilSell, $HcomOMissileMGM, $HcomOMissileNM, $HcomOMissilePP, $HcomOMissileSPP, $HcomOreBuy, $HcomOreSell, $HcomPioneer, $HcomPlant, $HcomPolice, $HcomPort, $HcomPrepare, $HcomPrepare2, $HcomPresent, $HcomPresentAid, $HcomPropaganda, $HcomReclaim, $HcomReclaim2, $HcomSbase, $HcomSBuild, $HcomScity, $HcomSDbase, $HcomSDestroy, $HcomSearch, $HcomSEisei, $HcomSell, $HcomSellTree, $HcomSendMonster, $HcomSendMonsterTurn, $HcomSFactory, $HcomSFarm, $HcomSFood, $HcomShip, $HcomShipbuild, $HcomShipM, $HcomShipSell, $HcomSMissile, $HcomSMissileGM, $HcomSMissileMGM, $HcomSMissilePP, $HcomSMonument, $HcomSOccupy, $HcomSpaceBase, $HcomSpaceFarm, $HcomSpecialSPP, $HcomSPioneer, $HcomSpy, $HcomSSendMonster, $HcomSSendMonsterTurn, $HcomSTManipulate, $HcomSUnit, $HcomTeisatu, $HcomTower, $HcomTrump, $HcomUg, $HcomWarp, $HcomWeponBuy, $HcomWeponSell, $HcomWindmill, $HconsolationMatch, $HcurrentNumber, $HdBaseAuto, $HdefenceHex, $HdefenceSpace, $HdevelopeTurn, $HdirMode, $HdirName, $HdisAEruption, $HdisAkasio, $HdisBHarvest, $HdisCrime, $HdisEarthquake, $HdisEruption, $HdisFallBorder, $HdisFalldown, $HdisFire, $HdisGHarvest, $Hdishangen, $HdisHugeMeteo, $HdisKLimit, $HdisMaizo, $HdisMeteo, $HdisMonsBorder1, $HdisMonsBorder2, $HdisMonsBorder3, $HdisMonsBorder4, $HdisMonsBorder5, $HdisMonster, $HdisMonsterU, $HdisPirate, $HdisPollution, $HdisSeaMonster, $HdisSHugeMeteo, $HdisSpaceMonster1, $HdisSpaceMonster2, $HdisTinka, $HdisTreasureS, $HdisTsunami, $HdisTyphoon, $HdisUN, $HdisVGHarvest, $HearthAttack, $HeatenFood, $helpDir, $HfightMem, $HfightTurn, $HfinalTurn, $HgiveupTurn, $HhistoryMax, $HidToName, $HidToNumber, $HidToNumberR, $HinterTime, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HlandAegisShip, $HlandAirport, $HlandAmusement, $HlandBalloonS, $HlandBank, $HlandBase, $HlandBigcity, $HlandBreakwater, $HlandCasino, $HlandCoupleRock, $HlandDeathtrap, $HlandDefence, $HlandDokan, $HlandDome, $HlandEarth, $HlandExpo, $HlandFactory, $HlandFarm, $HlandFire, $HlandFishLShip, $HlandFishMShip, $HlandFishSShip, $HlandFlower, $HlandForest, $HlandFuji, $HlandGhostShip, $HlandHaribote, $HlandHospital, $HlandHugecity, $HlandIceFloe, $HlandKInora, $HlandMegacity, $HlandMegaFact, $HlandMegaFarm, $HlandMegatower, $HlandMonsShip, $HlandMonster, $HlandMonument, $HlandMountain, $HlandMyhome, $HlandOcean, $HlandOil, $HlandOPlayer, $HlandOsen, $HlandPark, $HlandPirate, $HlandPlains, $HlandPolice, $HlandPort, $HlandProbeShip, $HlandSAEisei, $HlandSbase, $HlandSchool, $HlandSCity, $HlandSDefence, $HlandSea, $HlandSeisei, $HlandSFactory, $HlandSFarm, $HlandSlum, $HlandSMonument, $HlandSpaceBase, $HlandStadium, $HlandSunit, $HlandTcity, $HlandTitanic, $HlandTower, $HlandTown, $HlandTreasureS, $HlandTrump, $HlandWarp, $HlandWarpR, $HlandWaste, $HlandWindmill, $HlandWingDragon, $HlandZoo, $HlateLogPool, $HlogMax, $HlogOmit2, $HlogPool, $HmaxdisPollution, $HmaxExpPoint, $HmaxIsland, $HmonsBtlMaxHp, $HmonsBtlMaxPa, $HmonsterAGI, $HmonsterBHP, $HmonsterCLS, $HmonsterDEF, $HmonsterDestroy, $HmonsterDHP, $HmonsterExp, $HmonsterGRP, $HmonsterL1, $HmonsterL1Num, $HmonsterL2, $HmonsterL2Num, $HmonsterL3, $HmonsterL3Num, $HmonsterL4, $HmonsterL4Num, $HmonsterL5, $HmonsterL5Num, $HmonsterName, $HmonsterNumber, $HmonsterS, $HmonsterSEI, $HmonsterSKL, $HmonsterSP, $HmonsterSpecial, $HmonsterSTR, $HmonsterValue, $Hmonth, $HmonumentMissile, $HmonumentName, $HmonumentRocket, $Hocean, $HoceanSize, $HoilMoney, $HoilRatio, $hp, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $Hprize, $HprizeV, $HpunishInfo, $HrepeatTurn, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $HseaChk, $HsecretLogPool, $HsEisei, $HshipEX, $HshipFood, $HshipHP, $HshipKAI, $HshipMATK, $HshipMoney, $HshipName, $Hshiporder, $HshipSATK, $HshipSell, $HshipSP, $HsmonumentName, $HsmonumentNumber, $Hsolarwind, $Hspace, $HspaceEfficiency, $HspaceIncome, $Hsstartturn, $HStotalPoint, $HsurvFlg, $Hsurvivalturn, $HtagName2_, $HthisFile, $HtotalBumon, $HtotalMoney, $HtotalPoint, $Htournament, $HtreeValue, $HturnPrizeNumber, $HturnPrizePoint, $HturnPrizeUnit, $HturnPrizeVarious, $HugDokan, $HugFact, $HugFarm, $HugHasigo, $HugKiti, $HugMax, $HugOil, $HugRoad, $HugSpace, $HugTosi, $human, $HunitFood, $HunitMoney, $HunitOil, $HunitOre, $HunitPop, $HunitTime, $HunitWeapon, $HwarFlg, $HWeatherMax, $Hwflg, $HwinFood, $HwinIsland, $HwinMoney, $HwinWeapon, $imageDir, $lockMode, $toppage, $versionInfo;
	$sx = null; $sy = null; $size = null; $i = null;
	$size = $HislandSize - 1;
	
	if($direction == 0){
		// 우상→우하
		$sx = $size;
		$sy = $size;
		for($i = 0;$i < $HislandSize;$i++){
			if($HseaChk[$land[$sx][$i]] == 1){
				// 바다계 지형의 경우, 배계는 제외하다
				$sy = $i;
break;
			}
		}
	}elseif($direction == 1){
		// 우하→좌하
		$sx = $size;
		$sy = $size;
		for($i = $size;$i >= 0;$i--){
			if($HseaChk[$land[$i][$sy]] == 1){
				// 바다계 지형의 경우, 배계는 제외하다
				$sx = $i;
break;
			}
		}
	}elseif($direction == 2){
		// 좌하→좌상

		$sx = 0;
		$sy = $size;
		for($i = $size;$i >= 0;$i--){
			if($HseaChk[$land[$sx][$i]] == 1){
				// 바다계 지형의 경우, 배계는 제외하다
				$sy = $i;
break;
			}
		}
	}else{
		// 좌상→우상

		$sx = $size;
		$sy = 0;
		for($i = 0;$i < $HislandSize;$i++){
			if($HseaChk[$land[$i][$sy]] == 1){
				// 바다계 지형의 경우, 배계는 제외하다
				$sx = $i;
break;
			}
		}
	}
	return array($sx, $sy);
}

// 후퇴 처리( 꽤 강행인 모아 두고 흉내내지 않게)
function shipEvacuation($sx, $sy) {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $H_tagName2, $Haidpop, $Hallyflg, $Hallygroup, $haribote, $Hatkturn, $HbackupTimes, $HbackupTurn, $HbgInfoCell, $HbgTitleCell, $HbigcityFood, $HbigCityMFlg, $HcomBank, $HcomBase, $HcomBioMissile, $HcomBreakwater, $Hcomcolony, $HcomcolonyTurn, $HcomCost, $HcomDbase, $HcomDeathtrap, $HcomDestroy, $HcomDestroy2, $HcomDokan, $HcomDoNothing, $HcomDummy, $HcomEmigration, $HcomFactory, $HcomFarm, $HcomFire, $HcomFlower, $HcomFood, $HcomGiveup, $HcomHaribote, $HcomHospital, $HcomL, $HcommandMax, $HcomManipulate, $HcomMissileDM, $HcomMissileGM, $HcomMissileLD, $HcomMissileMGM, $HcomMissileNCM, $HcomMissileNM, $HcomMissilePLD, $HcomMissilePP, $HcomMissileRM, $HcomMissileRNG, $HcomMissileSPP, $HcomMissileSRM, $HcomMissileST, $HcomMoney, $HcomMonsAid, $HcomMonsEgg, $HcomMonsEnsei, $HcomMonsEsa, $HcomMonsEsaAid, $HcomMonsExer, $HcomMonsSell, $HcomMonsTettai, $HcomMonument, $HcomMountain, $HcomMyhome, $HcomName, $HcomOilBuy, $HcomOilSell, $HcomOMissileMGM, $HcomOMissileNM, $HcomOMissilePP, $HcomOMissileSPP, $HcomOreBuy, $HcomOreSell, $HcomPioneer, $HcomPlant, $HcomPolice, $HcomPort, $HcomPrepare, $HcomPrepare2, $HcomPresent, $HcomPresentAid, $HcomPropaganda, $HcomReclaim, $HcomReclaim2, $HcomSbase, $HcomSBuild, $HcomScity, $HcomSDbase, $HcomSDestroy, $HcomSearch, $HcomSEisei, $HcomSell, $HcomSellTree, $HcomSendMonster, $HcomSendMonsterTurn, $HcomSFactory, $HcomSFarm, $HcomSFood, $HcomShip, $HcomShipbuild, $HcomShipM, $HcomShipSell, $HcomSMissile, $HcomSMissileGM, $HcomSMissileMGM, $HcomSMissilePP, $HcomSMonument, $HcomSOccupy, $HcomSpaceBase, $HcomSpaceFarm, $HcomSpecialSPP, $HcomSPioneer, $HcomSpy, $HcomSSendMonster, $HcomSSendMonsterTurn, $HcomSTManipulate, $HcomSUnit, $HcomTeisatu, $HcomTower, $HcomTrump, $HcomUg, $HcomWarp, $HcomWeponBuy, $HcomWeponSell, $HcomWindmill, $HconsolationMatch, $HcurrentNumber, $HdBaseAuto, $HdefenceHex, $HdefenceSpace, $HdevelopeTurn, $HdirMode, $HdirName, $HdisAEruption, $HdisAkasio, $HdisBHarvest, $HdisCrime, $HdisEarthquake, $HdisEruption, $HdisFallBorder, $HdisFalldown, $HdisFire, $HdisGHarvest, $Hdishangen, $HdisHugeMeteo, $HdisKLimit, $HdisMaizo, $HdisMeteo, $HdisMonsBorder1, $HdisMonsBorder2, $HdisMonsBorder3, $HdisMonsBorder4, $HdisMonsBorder5, $HdisMonster, $HdisMonsterU, $HdisPirate, $HdisPollution, $HdisSeaMonster, $HdisSHugeMeteo, $HdisSpaceMonster1, $HdisSpaceMonster2, $HdisTinka, $HdisTreasureS, $HdisTsunami, $HdisTyphoon, $HdisUN, $HdisVGHarvest, $HearthAttack, $HeatenFood, $helpDir, $HfightMem, $HfightTurn, $HfinalTurn, $HgiveupTurn, $HhistoryMax, $HidToName, $HidToNumber, $HidToNumberR, $HinterTime, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HlandAegisShip, $HlandAirport, $HlandAmusement, $HlandBalloonS, $HlandBank, $HlandBase, $HlandBigcity, $HlandBreakwater, $HlandCasino, $HlandCoupleRock, $HlandDeathtrap, $HlandDefence, $HlandDokan, $HlandDome, $HlandEarth, $HlandExpo, $HlandFactory, $HlandFarm, $HlandFire, $HlandFishLShip, $HlandFishMShip, $HlandFishSShip, $HlandFlower, $HlandForest, $HlandFuji, $HlandGhostShip, $HlandHaribote, $HlandHospital, $HlandHugecity, $HlandIceFloe, $HlandKInora, $HlandMegacity, $HlandMegaFact, $HlandMegaFarm, $HlandMegatower, $HlandMonsShip, $HlandMonster, $HlandMonument, $HlandMountain, $HlandMyhome, $HlandOcean, $HlandOil, $HlandOPlayer, $HlandOsen, $HlandPark, $HlandPirate, $HlandPlains, $HlandPolice, $HlandPort, $HlandProbeShip, $HlandSAEisei, $HlandSbase, $HlandSchool, $HlandSCity, $HlandSDefence, $HlandSea, $HlandSeisei, $HlandSFactory, $HlandSFarm, $HlandSlum, $HlandSMonument, $HlandSpaceBase, $HlandStadium, $HlandSunit, $HlandTcity, $HlandTitanic, $HlandTower, $HlandTown, $HlandTreasureS, $HlandTrump, $HlandWarp, $HlandWarpR, $HlandWaste, $HlandWindmill, $HlandWingDragon, $HlandZoo, $HlateLogPool, $HlogMax, $HlogOmit2, $HlogPool, $HmaxdisPollution, $HmaxExpPoint, $HmaxIsland, $HmonsBtlMaxHp, $HmonsBtlMaxPa, $HmonsterAGI, $HmonsterBHP, $HmonsterCLS, $HmonsterDEF, $HmonsterDestroy, $HmonsterDHP, $HmonsterExp, $HmonsterGRP, $HmonsterL1, $HmonsterL1Num, $HmonsterL2, $HmonsterL2Num, $HmonsterL3, $HmonsterL3Num, $HmonsterL4, $HmonsterL4Num, $HmonsterL5, $HmonsterL5Num, $HmonsterName, $HmonsterNumber, $HmonsterS, $HmonsterSEI, $HmonsterSKL, $HmonsterSP, $HmonsterSpecial, $HmonsterSTR, $HmonsterValue, $Hmonth, $HmonumentMissile, $HmonumentName, $HmonumentRocket, $Hocean, $HoceanSize, $HoilMoney, $HoilRatio, $hp, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $Hprize, $HprizeV, $HpunishInfo, $HrepeatTurn, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $HseaChk, $HsecretLogPool, $HsEisei, $HshipEX, $HshipFood, $HshipHP, $HshipKAI, $HshipMATK, $HshipMoney, $HshipName, $Hshiporder, $HshipSATK, $HshipSell, $HshipSP, $HsmonumentName, $HsmonumentNumber, $Hsolarwind, $Hspace, $HspaceEfficiency, $HspaceIncome, $Hsstartturn, $HStotalPoint, $HsurvFlg, $Hsurvivalturn, $HtagName2_, $HthisFile, $HtotalBumon, $HtotalMoney, $HtotalPoint, $Htournament, $HtreeValue, $HturnPrizeNumber, $HturnPrizePoint, $HturnPrizeUnit, $HturnPrizeVarious, $HugDokan, $HugFact, $HugFarm, $HugHasigo, $HugKiti, $HugMax, $HugOil, $HugRoad, $HugSpace, $HugTosi, $human, $HunitFood, $HunitMoney, $HunitOil, $HunitOre, $HunitPop, $HunitTime, $HunitWeapon, $HwarFlg, $HWeatherMax, $Hwflg, $HwinFood, $HwinIsland, $HwinMoney, $HwinWeapon, $imageDir, $lockMode, $toppage, $versionInfo;
	
	$center = $HislandSize / 2 - 1;
	$direction = null;
	if(($sx <= $center) && ($sy <= $center)){
		// 좌상

		if($sx >= $sy){
			array_push($direction, 1);
			array_push($direction, 6);
			if($sx == $sy){
				array_push($direction, 5);
				if (($sy % 2) == 1) { array_push($direction, 4); }
			}
		}else{
			array_push($direction, 5);
			if(($sy % 2) == 1){
				array_push($direction, 4);
				array_push($direction, 6);
			}
		}
	}elseif(($sx > $center) && ($sy <= $center)){
		// 우상

		$sx = $HislandSize - $sx - 1;
		if($sx >= $sy){
			array_push($direction, 1);
			array_push($direction, 6);
			if($sx == $sy){
				array_push($direction, 2);
				if (($sy % 2) == 0) { array_push($direction, 3); }
			}
		}else{
			array_push($direction, 2);
			if(($sy % 2) == 0){
				array_push($direction, 1);
				array_push($direction, 3);
			}
		}
	}elseif(($sx <= $center) && ($sy > $center)){
		// 좌하
		$sy = $HislandSize - $sy - 1;
		if($sx >= $sy){

			array_push($direction, 3);
			array_push($direction, 4);
			if($sx == $sy){
				array_push($direction, 5);
				if (($sy % 2) == 0) { array_push($direction, 6); }
			}
		}else{
			array_push($direction, 5);
			if(($sy % 2) == 0){
				array_push($direction, 4);
				array_push($direction, 6);
			}
		}
	}else{
		// 우하
		$sx = $HislandSize - $sx - 1;
		$sy = $HislandSize - $sy - 1;
		if($sx >= $sy){
			array_push($direction, 3);
			array_push($direction, 4);
			if($sx == $sy){
				array_push($direction, 2);
				if (($sy % 2) == 1) { array_push($direction, 1); }
			}
		}else{
			array_push($direction, 2);
			if(($sy % 2) == 1){
				array_push($direction, 1);
				array_push($direction, 3);
			}
		}
	}
	
	// 상훌

	$new = array();
	foreach ($direction as $_) {
		$r = mt_rand(0, count($new));
		array_push($new, $new[$r]);
		$new[$r] = $_;
	}
	
	return $new;
}

// 광역 피해 루틴(로그를 정리할 예정)
function wideDamage($id, $name, &$land, &$landValue, $x, $y, $z) {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $H_tagName2, $Haidpop, $Hallyflg, $Hallygroup, $haribote, $Hatkturn, $HbackupTimes, $HbackupTurn, $HbgInfoCell, $HbgTitleCell, $HbigcityFood, $HbigCityMFlg, $HcomBank, $HcomBase, $HcomBioMissile, $HcomBreakwater, $Hcomcolony, $HcomcolonyTurn, $HcomCost, $HcomDbase, $HcomDeathtrap, $HcomDestroy, $HcomDestroy2, $HcomDokan, $HcomDoNothing, $HcomDummy, $HcomEmigration, $HcomFactory, $HcomFarm, $HcomFire, $HcomFlower, $HcomFood, $HcomGiveup, $HcomHaribote, $HcomHospital, $HcomL, $HcommandMax, $HcomManipulate, $HcomMissileDM, $HcomMissileGM, $HcomMissileLD, $HcomMissileMGM, $HcomMissileNCM, $HcomMissileNM, $HcomMissilePLD, $HcomMissilePP, $HcomMissileRM, $HcomMissileRNG, $HcomMissileSPP, $HcomMissileSRM, $HcomMissileST, $HcomMoney, $HcomMonsAid, $HcomMonsEgg, $HcomMonsEnsei, $HcomMonsEsa, $HcomMonsEsaAid, $HcomMonsExer, $HcomMonsSell, $HcomMonsTettai, $HcomMonument, $HcomMountain, $HcomMyhome, $HcomName, $HcomOilBuy, $HcomOilSell, $HcomOMissileMGM, $HcomOMissileNM, $HcomOMissilePP, $HcomOMissileSPP, $HcomOreBuy, $HcomOreSell, $HcomPioneer, $HcomPlant, $HcomPolice, $HcomPort, $HcomPrepare, $HcomPrepare2, $HcomPresent, $HcomPresentAid, $HcomPropaganda, $HcomReclaim, $HcomReclaim2, $HcomSbase, $HcomSBuild, $HcomScity, $HcomSDbase, $HcomSDestroy, $HcomSearch, $HcomSEisei, $HcomSell, $HcomSellTree, $HcomSendMonster, $HcomSendMonsterTurn, $HcomSFactory, $HcomSFarm, $HcomSFood, $HcomShip, $HcomShipbuild, $HcomShipM, $HcomShipSell, $HcomSMissile, $HcomSMissileGM, $HcomSMissileMGM, $HcomSMissilePP, $HcomSMonument, $HcomSOccupy, $HcomSpaceBase, $HcomSpaceFarm, $HcomSpecialSPP, $HcomSPioneer, $HcomSpy, $HcomSSendMonster, $HcomSSendMonsterTurn, $HcomSTManipulate, $HcomSUnit, $HcomTeisatu, $HcomTower, $HcomTrump, $HcomUg, $HcomWarp, $HcomWeponBuy, $HcomWeponSell, $HcomWindmill, $HconsolationMatch, $HcurrentNumber, $HdBaseAuto, $HdefenceHex, $HdefenceSpace, $HdevelopeTurn, $HdirMode, $HdirName, $HdisAEruption, $HdisAkasio, $HdisBHarvest, $HdisCrime, $HdisEarthquake, $HdisEruption, $HdisFallBorder, $HdisFalldown, $HdisFire, $HdisGHarvest, $Hdishangen, $HdisHugeMeteo, $HdisKLimit, $HdisMaizo, $HdisMeteo, $HdisMonsBorder1, $HdisMonsBorder2, $HdisMonsBorder3, $HdisMonsBorder4, $HdisMonsBorder5, $HdisMonster, $HdisMonsterU, $HdisPirate, $HdisPollution, $HdisSeaMonster, $HdisSHugeMeteo, $HdisSpaceMonster1, $HdisSpaceMonster2, $HdisTinka, $HdisTreasureS, $HdisTsunami, $HdisTyphoon, $HdisUN, $HdisVGHarvest, $HearthAttack, $HeatenFood, $helpDir, $HfightMem, $HfightTurn, $HfinalTurn, $HgiveupTurn, $HhistoryMax, $HidToName, $HidToNumber, $HidToNumberR, $HinterTime, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HlandAegisShip, $HlandAirport, $HlandAmusement, $HlandBalloonS, $HlandBank, $HlandBase, $HlandBigcity, $HlandBreakwater, $HlandCasino, $HlandCoupleRock, $HlandDeathtrap, $HlandDefence, $HlandDokan, $HlandDome, $HlandEarth, $HlandExpo, $HlandFactory, $HlandFarm, $HlandFire, $HlandFishLShip, $HlandFishMShip, $HlandFishSShip, $HlandFlower, $HlandForest, $HlandFuji, $HlandGhostShip, $HlandHaribote, $HlandHospital, $HlandHugecity, $HlandIceFloe, $HlandKInora, $HlandMegacity, $HlandMegaFact, $HlandMegaFarm, $HlandMegatower, $HlandMonsShip, $HlandMonster, $HlandMonument, $HlandMountain, $HlandMyhome, $HlandOcean, $HlandOil, $HlandOPlayer, $HlandOsen, $HlandPark, $HlandPirate, $HlandPlains, $HlandPolice, $HlandPort, $HlandProbeShip, $HlandSAEisei, $HlandSbase, $HlandSchool, $HlandSCity, $HlandSDefence, $HlandSea, $HlandSeisei, $HlandSFactory, $HlandSFarm, $HlandSlum, $HlandSMonument, $HlandSpaceBase, $HlandStadium, $HlandSunit, $HlandTcity, $HlandTitanic, $HlandTower, $HlandTown, $HlandTreasureS, $HlandTrump, $HlandWarp, $HlandWarpR, $HlandWaste, $HlandWindmill, $HlandWingDragon, $HlandZoo, $HlateLogPool, $HlogMax, $HlogOmit2, $HlogPool, $HmaxdisPollution, $HmaxExpPoint, $HmaxIsland, $HmonsBtlMaxHp, $HmonsBtlMaxPa, $HmonsterAGI, $HmonsterBHP, $HmonsterCLS, $HmonsterDEF, $HmonsterDestroy, $HmonsterDHP, $HmonsterExp, $HmonsterGRP, $HmonsterL1, $HmonsterL1Num, $HmonsterL2, $HmonsterL2Num, $HmonsterL3, $HmonsterL3Num, $HmonsterL4, $HmonsterL4Num, $HmonsterL5, $HmonsterL5Num, $HmonsterName, $HmonsterNumber, $HmonsterS, $HmonsterSEI, $HmonsterSKL, $HmonsterSP, $HmonsterSpecial, $HmonsterSTR, $HmonsterValue, $Hmonth, $HmonumentMissile, $HmonumentName, $HmonumentRocket, $Hocean, $HoceanSize, $HoilMoney, $HoilRatio, $hp, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $Hprize, $HprizeV, $HpunishInfo, $HrepeatTurn, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $HseaChk, $HsecretLogPool, $HsEisei, $HshipEX, $HshipFood, $HshipHP, $HshipKAI, $HshipMATK, $HshipMoney, $HshipName, $Hshiporder, $HshipSATK, $HshipSell, $HshipSP, $HsmonumentName, $HsmonumentNumber, $Hsolarwind, $Hspace, $HspaceEfficiency, $HspaceIncome, $Hsstartturn, $HStotalPoint, $HsurvFlg, $Hsurvivalturn, $HtagName2_, $HthisFile, $HtotalBumon, $HtotalMoney, $HtotalPoint, $Htournament, $HtreeValue, $HturnPrizeNumber, $HturnPrizePoint, $HturnPrizeUnit, $HturnPrizeVarious, $HugDokan, $HugFact, $HugFarm, $HugHasigo, $HugKiti, $HugMax, $HugOil, $HugRoad, $HugSpace, $HugTosi, $human, $HunitFood, $HunitMoney, $HunitOil, $HunitOre, $HunitPop, $HunitTime, $HunitWeapon, $HwarFlg, $HWeatherMax, $Hwflg, $HwinFood, $HwinIsland, $HwinMoney, $HwinWeapon, $imageDir, $lockMode, $toppage, $versionInfo;
	$sx = null; $sy = null; $i = null; $landKind = null; $lv = null;
	for($i = 0; $i < 19; $i++){
		$sx = $x + $ax[$i];
		$sy = $y + $ay[$i];
		if (!($sy % 2) && ($y % 2)) { $sx--; }
		if (($sx < 0) || ($sx >= $HislandSize) || ($sy < 0) || ($sy >= $HislandSize)) { continue; }

		$landKind = $land[$sx][$sy];
		$lv = $landValue[$sx][$sy];

		// 범위에 의한 분기

		if($i < 7){
			// 중심, 및 1 헥스
			if(($landKind == $HlandSea) && ($lv == 0)){
				// 해
				$landValue[$sx][$sy] = 0;
			}elseif($HseaChk[$landKind]){
				// 바다계
				logWideDamageSea2($id, $name, landName($landKind, $lv), "($sx, $sy)");
				$land[$sx][$sy] = $HlandSea;
				$landValue[$sx][$sy] = 0;
			}else{
				if($landKind == $HlandMonster){
					logWideDamageMonsterSea($id, $name, landName($landKind, $lv), "($sx, $sy)");
				}else{
					logWideDamageSea($id, $name, landName($landKind, $lv), "($sx, $sy)");
				}
				$land[$sx][$sy] = $HlandSea;
				// 중심은 바다, 외는 얕은 여울
				$landValue[$sx][$sy] = ($i == 0) ? 0 : 1;
			}
continue;
		}else{
			//  2 헥스
			if(($HseaChk[$landKind]) ||
				($landKind == $HlandWaste) ||
				($landKind == $HlandMountain)){
continue;
			}elseif($landKind == $HlandMonster){
				logWideDamageMonster($id, $name, landName($landKind, $lv), "($sx, $sy)");
			}else{
				logWideDamageWaste($id, $name, landName($landKind, $lv), "($sx, $sy)");
			}
			$land[$sx][$sy] = $HlandWaste;
			$landValue[$sx][$sy] = 0;
		}
		if(($z == 1) && ($land[$sx][$sy] == $HlandWaste)){
			logWideDamageOsen($id, $name, "황무지", "($sx, $sy)");
			$land[$sx][$sy] = $HlandOsen;
			$landValue[$sx][$sy] = 1;
		}
	}
}
// 초광역 피해 루틴(로그를 정리할 예정)
function SuperDamage($id, $name, &$land, &$landValue, $x, $y) {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $H_tagName2, $Haidpop, $Hallyflg, $Hallygroup, $haribote, $Hatkturn, $HbackupTimes, $HbackupTurn, $HbgInfoCell, $HbgTitleCell, $HbigcityFood, $HbigCityMFlg, $HcomBank, $HcomBase, $HcomBioMissile, $HcomBreakwater, $Hcomcolony, $HcomcolonyTurn, $HcomCost, $HcomDbase, $HcomDeathtrap, $HcomDestroy, $HcomDestroy2, $HcomDokan, $HcomDoNothing, $HcomDummy, $HcomEmigration, $HcomFactory, $HcomFarm, $HcomFire, $HcomFlower, $HcomFood, $HcomGiveup, $HcomHaribote, $HcomHospital, $HcomL, $HcommandMax, $HcomManipulate, $HcomMissileDM, $HcomMissileGM, $HcomMissileLD, $HcomMissileMGM, $HcomMissileNCM, $HcomMissileNM, $HcomMissilePLD, $HcomMissilePP, $HcomMissileRM, $HcomMissileRNG, $HcomMissileSPP, $HcomMissileSRM, $HcomMissileST, $HcomMoney, $HcomMonsAid, $HcomMonsEgg, $HcomMonsEnsei, $HcomMonsEsa, $HcomMonsEsaAid, $HcomMonsExer, $HcomMonsSell, $HcomMonsTettai, $HcomMonument, $HcomMountain, $HcomMyhome, $HcomName, $HcomOilBuy, $HcomOilSell, $HcomOMissileMGM, $HcomOMissileNM, $HcomOMissilePP, $HcomOMissileSPP, $HcomOreBuy, $HcomOreSell, $HcomPioneer, $HcomPlant, $HcomPolice, $HcomPort, $HcomPrepare, $HcomPrepare2, $HcomPresent, $HcomPresentAid, $HcomPropaganda, $HcomReclaim, $HcomReclaim2, $HcomSbase, $HcomSBuild, $HcomScity, $HcomSDbase, $HcomSDestroy, $HcomSearch, $HcomSEisei, $HcomSell, $HcomSellTree, $HcomSendMonster, $HcomSendMonsterTurn, $HcomSFactory, $HcomSFarm, $HcomSFood, $HcomShip, $HcomShipbuild, $HcomShipM, $HcomShipSell, $HcomSMissile, $HcomSMissileGM, $HcomSMissileMGM, $HcomSMissilePP, $HcomSMonument, $HcomSOccupy, $HcomSpaceBase, $HcomSpaceFarm, $HcomSpecialSPP, $HcomSPioneer, $HcomSpy, $HcomSSendMonster, $HcomSSendMonsterTurn, $HcomSTManipulate, $HcomSUnit, $HcomTeisatu, $HcomTower, $HcomTrump, $HcomUg, $HcomWarp, $HcomWeponBuy, $HcomWeponSell, $HcomWindmill, $HconsolationMatch, $HcurrentNumber, $HdBaseAuto, $HdefenceHex, $HdefenceSpace, $HdevelopeTurn, $HdirMode, $HdirName, $HdisAEruption, $HdisAkasio, $HdisBHarvest, $HdisCrime, $HdisEarthquake, $HdisEruption, $HdisFallBorder, $HdisFalldown, $HdisFire, $HdisGHarvest, $Hdishangen, $HdisHugeMeteo, $HdisKLimit, $HdisMaizo, $HdisMeteo, $HdisMonsBorder1, $HdisMonsBorder2, $HdisMonsBorder3, $HdisMonsBorder4, $HdisMonsBorder5, $HdisMonster, $HdisMonsterU, $HdisPirate, $HdisPollution, $HdisSeaMonster, $HdisSHugeMeteo, $HdisSpaceMonster1, $HdisSpaceMonster2, $HdisTinka, $HdisTreasureS, $HdisTsunami, $HdisTyphoon, $HdisUN, $HdisVGHarvest, $HearthAttack, $HeatenFood, $helpDir, $HfightMem, $HfightTurn, $HfinalTurn, $HgiveupTurn, $HhistoryMax, $HidToName, $HidToNumber, $HidToNumberR, $HinterTime, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HlandAegisShip, $HlandAirport, $HlandAmusement, $HlandBalloonS, $HlandBank, $HlandBase, $HlandBigcity, $HlandBreakwater, $HlandCasino, $HlandCoupleRock, $HlandDeathtrap, $HlandDefence, $HlandDokan, $HlandDome, $HlandEarth, $HlandExpo, $HlandFactory, $HlandFarm, $HlandFire, $HlandFishLShip, $HlandFishMShip, $HlandFishSShip, $HlandFlower, $HlandForest, $HlandFuji, $HlandGhostShip, $HlandHaribote, $HlandHospital, $HlandHugecity, $HlandIceFloe, $HlandKInora, $HlandMegacity, $HlandMegaFact, $HlandMegaFarm, $HlandMegatower, $HlandMonsShip, $HlandMonster, $HlandMonument, $HlandMountain, $HlandMyhome, $HlandOcean, $HlandOil, $HlandOPlayer, $HlandOsen, $HlandPark, $HlandPirate, $HlandPlains, $HlandPolice, $HlandPort, $HlandProbeShip, $HlandSAEisei, $HlandSbase, $HlandSchool, $HlandSCity, $HlandSDefence, $HlandSea, $HlandSeisei, $HlandSFactory, $HlandSFarm, $HlandSlum, $HlandSMonument, $HlandSpaceBase, $HlandStadium, $HlandSunit, $HlandTcity, $HlandTitanic, $HlandTower, $HlandTown, $HlandTreasureS, $HlandTrump, $HlandWarp, $HlandWarpR, $HlandWaste, $HlandWindmill, $HlandWingDragon, $HlandZoo, $HlateLogPool, $HlogMax, $HlogOmit2, $HlogPool, $HmaxdisPollution, $HmaxExpPoint, $HmaxIsland, $HmonsBtlMaxHp, $HmonsBtlMaxPa, $HmonsterAGI, $HmonsterBHP, $HmonsterCLS, $HmonsterDEF, $HmonsterDestroy, $HmonsterDHP, $HmonsterExp, $HmonsterGRP, $HmonsterL1, $HmonsterL1Num, $HmonsterL2, $HmonsterL2Num, $HmonsterL3, $HmonsterL3Num, $HmonsterL4, $HmonsterL4Num, $HmonsterL5, $HmonsterL5Num, $HmonsterName, $HmonsterNumber, $HmonsterS, $HmonsterSEI, $HmonsterSKL, $HmonsterSP, $HmonsterSpecial, $HmonsterSTR, $HmonsterValue, $Hmonth, $HmonumentMissile, $HmonumentName, $HmonumentRocket, $Hocean, $HoceanSize, $HoilMoney, $HoilRatio, $hp, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $Hprize, $HprizeV, $HpunishInfo, $HrepeatTurn, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $HseaChk, $HsecretLogPool, $HsEisei, $HshipEX, $HshipFood, $HshipHP, $HshipKAI, $HshipMATK, $HshipMoney, $HshipName, $Hshiporder, $HshipSATK, $HshipSell, $HshipSP, $HsmonumentName, $HsmonumentNumber, $Hsolarwind, $Hspace, $HspaceEfficiency, $HspaceIncome, $Hsstartturn, $HStotalPoint, $HsurvFlg, $Hsurvivalturn, $HtagName2_, $HthisFile, $HtotalBumon, $HtotalMoney, $HtotalPoint, $Htournament, $HtreeValue, $HturnPrizeNumber, $HturnPrizePoint, $HturnPrizeUnit, $HturnPrizeVarious, $HugDokan, $HugFact, $HugFarm, $HugHasigo, $HugKiti, $HugMax, $HugOil, $HugRoad, $HugSpace, $HugTosi, $human, $HunitFood, $HunitMoney, $HunitOil, $HunitOre, $HunitPop, $HunitTime, $HunitWeapon, $HwarFlg, $HWeatherMax, $Hwflg, $HwinFood, $HwinIsland, $HwinMoney, $HwinWeapon, $imageDir, $lockMode, $toppage, $versionInfo;
	$sx = null; $sy = null; $i = null; $landKind = null; $lv = null;
	for($i = 0; $i < 37; $i++){
		$sx = $x + $ax[$i];
		$sy = $y + $ay[$i];

		if (!($sy % 2) && ($y % 2)) { $sx--; }
		if (($sx < 0) || ($sx >= $HislandSize) || ($sy < 0) || ($sy >= $HislandSize)) { continue; }

		$landKind = $land[$sx][$sy];
		$lv = $landValue[$sx][$sy];

		// 범위에 의한 분기

		if($i == 0){
			logWideDamageSea2($id, $name, landName($landKind, $lv), "($sx, $sy)");
			$land[$sx][$sy] = $HlandMountain;
			$landValue[$sx][$sy] = 0;
		}elseif($i < 7){
			// 1 헥스
			logWideDamageSea2($id, $name, landName($landKind, $lv), "($sx, $sy)");
			if($landKind == $HlandMountain){
				$land[$sx][$sy] = $HlandWaste;
				$landValue[$sx][$sy] = 1;
			}else{
				$land[$sx][$sy] = $HlandSea;
				$landValue[$sx][$sy] = 0;
			}
		}elseif($i < 19){
			// 2 헥스
			if((($landKind == $HlandSea) && ($lv == 0)) ||
				($landKind == $HlandMountain)){
continue;
			}else{
				logWideDamageSea2($id, $name, landName($landKind, $lv), "($sx, $sy)");
				$land[$sx][$sy] = $HlandSea;
				$landValue[$sx][$sy] = 1;
			}
		}else{
			// 3 헥스
			if(($HseaChk[$landKind]) ||
				($landKind == $HlandWaste) ||
				($landKind == $HlandMountain)){
continue;
			}elseif($landKind == $HlandMonster){
				logWideDamageMonster($id, $name, landName($landKind, $lv), "($sx, $sy)");
			}else{
				logWideDamageWaste($id, $name, landName($landKind, $lv), "($sx, $sy)");
			}
			$land[$sx][$sy] = $HlandWaste;
			$landValue[$sx][$sy] = 0;
		}
	}
}
// 광역 피해 우주 루틴
function wideDamageSpace($id, &$land, &$landValue, &$dis, &$nation, $x, $y, $z, $mode) {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $H_tagName2, $Haidpop, $Hallyflg, $Hallygroup, $haribote, $Hatkturn, $HbackupTimes, $HbackupTurn, $HbgInfoCell, $HbgTitleCell, $HbigcityFood, $HbigCityMFlg, $HcomBank, $HcomBase, $HcomBioMissile, $HcomBreakwater, $Hcomcolony, $HcomcolonyTurn, $HcomCost, $HcomDbase, $HcomDeathtrap, $HcomDestroy, $HcomDestroy2, $HcomDokan, $HcomDoNothing, $HcomDummy, $HcomEmigration, $HcomFactory, $HcomFarm, $HcomFire, $HcomFlower, $HcomFood, $HcomGiveup, $HcomHaribote, $HcomHospital, $HcomL, $HcommandMax, $HcomManipulate, $HcomMissileDM, $HcomMissileGM, $HcomMissileLD, $HcomMissileMGM, $HcomMissileNCM, $HcomMissileNM, $HcomMissilePLD, $HcomMissilePP, $HcomMissileRM, $HcomMissileRNG, $HcomMissileSPP, $HcomMissileSRM, $HcomMissileST, $HcomMoney, $HcomMonsAid, $HcomMonsEgg, $HcomMonsEnsei, $HcomMonsEsa, $HcomMonsEsaAid, $HcomMonsExer, $HcomMonsSell, $HcomMonsTettai, $HcomMonument, $HcomMountain, $HcomMyhome, $HcomName, $HcomOilBuy, $HcomOilSell, $HcomOMissileMGM, $HcomOMissileNM, $HcomOMissilePP, $HcomOMissileSPP, $HcomOreBuy, $HcomOreSell, $HcomPioneer, $HcomPlant, $HcomPolice, $HcomPort, $HcomPrepare, $HcomPrepare2, $HcomPresent, $HcomPresentAid, $HcomPropaganda, $HcomReclaim, $HcomReclaim2, $HcomSbase, $HcomSBuild, $HcomScity, $HcomSDbase, $HcomSDestroy, $HcomSearch, $HcomSEisei, $HcomSell, $HcomSellTree, $HcomSendMonster, $HcomSendMonsterTurn, $HcomSFactory, $HcomSFarm, $HcomSFood, $HcomShip, $HcomShipbuild, $HcomShipM, $HcomShipSell, $HcomSMissile, $HcomSMissileGM, $HcomSMissileMGM, $HcomSMissilePP, $HcomSMonument, $HcomSOccupy, $HcomSpaceBase, $HcomSpaceFarm, $HcomSpecialSPP, $HcomSPioneer, $HcomSpy, $HcomSSendMonster, $HcomSSendMonsterTurn, $HcomSTManipulate, $HcomSUnit, $HcomTeisatu, $HcomTower, $HcomTrump, $HcomUg, $HcomWarp, $HcomWeponBuy, $HcomWeponSell, $HcomWindmill, $HconsolationMatch, $HcurrentNumber, $HdBaseAuto, $HdefenceHex, $HdefenceSpace, $HdevelopeTurn, $HdirMode, $HdirName, $HdisAEruption, $HdisAkasio, $HdisBHarvest, $HdisCrime, $HdisEarthquake, $HdisEruption, $HdisFallBorder, $HdisFalldown, $HdisFire, $HdisGHarvest, $Hdishangen, $HdisHugeMeteo, $HdisKLimit, $HdisMaizo, $HdisMeteo, $HdisMonsBorder1, $HdisMonsBorder2, $HdisMonsBorder3, $HdisMonsBorder4, $HdisMonsBorder5, $HdisMonster, $HdisMonsterU, $HdisPirate, $HdisPollution, $HdisSeaMonster, $HdisSHugeMeteo, $HdisSpaceMonster1, $HdisSpaceMonster2, $HdisTinka, $HdisTreasureS, $HdisTsunami, $HdisTyphoon, $HdisUN, $HdisVGHarvest, $HearthAttack, $HeatenFood, $helpDir, $HfightMem, $HfightTurn, $HfinalTurn, $HgiveupTurn, $HhistoryMax, $HidToName, $HidToNumber, $HidToNumberR, $HinterTime, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HlandAegisShip, $HlandAirport, $HlandAmusement, $HlandBalloonS, $HlandBank, $HlandBase, $HlandBigcity, $HlandBreakwater, $HlandCasino, $HlandCoupleRock, $HlandDeathtrap, $HlandDefence, $HlandDokan, $HlandDome, $HlandEarth, $HlandExpo, $HlandFactory, $HlandFarm, $HlandFire, $HlandFishLShip, $HlandFishMShip, $HlandFishSShip, $HlandFlower, $HlandForest, $HlandFuji, $HlandGhostShip, $HlandHaribote, $HlandHospital, $HlandHugecity, $HlandIceFloe, $HlandKInora, $HlandMegacity, $HlandMegaFact, $HlandMegaFarm, $HlandMegatower, $HlandMonsShip, $HlandMonster, $HlandMonument, $HlandMountain, $HlandMyhome, $HlandOcean, $HlandOil, $HlandOPlayer, $HlandOsen, $HlandPark, $HlandPirate, $HlandPlains, $HlandPolice, $HlandPort, $HlandProbeShip, $HlandSAEisei, $HlandSbase, $HlandSchool, $HlandSCity, $HlandSDefence, $HlandSea, $HlandSeisei, $HlandSFactory, $HlandSFarm, $HlandSlum, $HlandSMonument, $HlandSpaceBase, $HlandStadium, $HlandSunit, $HlandTcity, $HlandTitanic, $HlandTower, $HlandTown, $HlandTreasureS, $HlandTrump, $HlandWarp, $HlandWarpR, $HlandWaste, $HlandWindmill, $HlandWingDragon, $HlandZoo, $HlateLogPool, $HlogMax, $HlogOmit2, $HlogPool, $HmaxdisPollution, $HmaxExpPoint, $HmaxIsland, $HmonsBtlMaxHp, $HmonsBtlMaxPa, $HmonsterAGI, $HmonsterBHP, $HmonsterCLS, $HmonsterDEF, $HmonsterDestroy, $HmonsterDHP, $HmonsterExp, $HmonsterGRP, $HmonsterL1, $HmonsterL1Num, $HmonsterL2, $HmonsterL2Num, $HmonsterL3, $HmonsterL3Num, $HmonsterL4, $HmonsterL4Num, $HmonsterL5, $HmonsterL5Num, $HmonsterName, $HmonsterNumber, $HmonsterS, $HmonsterSEI, $HmonsterSKL, $HmonsterSP, $HmonsterSpecial, $HmonsterSTR, $HmonsterValue, $Hmonth, $HmonumentMissile, $HmonumentName, $HmonumentRocket, $Hocean, $HoceanSize, $HoilMoney, $HoilRatio, $hp, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $Hprize, $HprizeV, $HpunishInfo, $HrepeatTurn, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $HseaChk, $HsecretLogPool, $HsEisei, $HshipEX, $HshipFood, $HshipHP, $HshipKAI, $HshipMATK, $HshipMoney, $HshipName, $Hshiporder, $HshipSATK, $HshipSell, $HshipSP, $HsmonumentName, $HsmonumentNumber, $Hsolarwind, $Hspace, $HspaceEfficiency, $HspaceIncome, $Hsstartturn, $HStotalPoint, $HsurvFlg, $Hsurvivalturn, $HtagName2_, $HthisFile, $HtotalBumon, $HtotalMoney, $HtotalPoint, $Htournament, $HtreeValue, $HturnPrizeNumber, $HturnPrizePoint, $HturnPrizeUnit, $HturnPrizeVarious, $HugDokan, $HugFact, $HugFarm, $HugHasigo, $HugKiti, $HugMax, $HugOil, $HugRoad, $HugSpace, $HugTosi, $human, $HunitFood, $HunitMoney, $HunitOil, $HunitOre, $HunitPop, $HunitTime, $HunitWeapon, $HwarFlg, $HWeatherMax, $Hwflg, $HwinFood, $HwinIsland, $HwinMoney, $HwinWeapon, $imageDir, $lockMode, $toppage, $versionInfo;
	$sx = null; $sy = null; $i = null; $landKind = null; $lv = null;
	for($i = 0; $i < $z; $i++){
		$sx = $x + $ax[$i];
		$sy = $y + $ay[$i];
		if (!($sy % 2) && ($y % 2)) { $sx--; }
		if (($sx < 0) || ($sx >= $HislandSize) || ($sy < 0) || ($sy >= $HislandSize) || ($land[$sx][$sy] == $HlandEarth) || ($land[$sx][$sy] == $HlandSea)) { continue; }

		$landKind = $land[$sx][$sy];
		$lv = $landValue[$sx][$sy];
		if(($mode == 0) || ($i == 0)){

			// 소멸
			logWideDamageSpace(landName($landKind, $lv), "($sx, $sy)","허무");
			$land[$sx][$sy] = $HlandSea;
			$landValue[$sx][$sy] = 0;
		}else{
			// 파괴
			if(($landKind == $HlandSunit) && ($lv == 20)){
			}else{
				logWideDamageSpace(landName($landKind, $lv), "($sx, $sy)","가루들");
			}
			$land[$sx][$sy] = $HlandSunit;
			$landValue[$sx][$sy] = 20;
		}
		$dis[$sx][$sy] = 0;
		$nation[$sx][$sy] = 0;
	}
}
// 로그를 정리한다
function logMatome($island, $flag, $kind) {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $H_tagName2, $Haidpop, $Hallyflg, $Hallygroup, $haribote, $Hatkturn, $HbackupTimes, $HbackupTurn, $HbgInfoCell, $HbgTitleCell, $HbigcityFood, $HbigCityMFlg, $HcomBank, $HcomBase, $HcomBioMissile, $HcomBreakwater, $Hcomcolony, $HcomcolonyTurn, $HcomCost, $HcomDbase, $HcomDeathtrap, $HcomDestroy, $HcomDestroy2, $HcomDokan, $HcomDoNothing, $HcomDummy, $HcomEmigration, $HcomFactory, $HcomFarm, $HcomFire, $HcomFlower, $HcomFood, $HcomGiveup, $HcomHaribote, $HcomHospital, $HcomL, $HcommandMax, $HcomManipulate, $HcomMissileDM, $HcomMissileGM, $HcomMissileLD, $HcomMissileMGM, $HcomMissileNCM, $HcomMissileNM, $HcomMissilePLD, $HcomMissilePP, $HcomMissileRM, $HcomMissileRNG, $HcomMissileSPP, $HcomMissileSRM, $HcomMissileST, $HcomMoney, $HcomMonsAid, $HcomMonsEgg, $HcomMonsEnsei, $HcomMonsEsa, $HcomMonsEsaAid, $HcomMonsExer, $HcomMonsSell, $HcomMonsTettai, $HcomMonument, $HcomMountain, $HcomMyhome, $HcomName, $HcomOilBuy, $HcomOilSell, $HcomOMissileMGM, $HcomOMissileNM, $HcomOMissilePP, $HcomOMissileSPP, $HcomOreBuy, $HcomOreSell, $HcomPioneer, $HcomPlant, $HcomPolice, $HcomPort, $HcomPrepare, $HcomPrepare2, $HcomPresent, $HcomPresentAid, $HcomPropaganda, $HcomReclaim, $HcomReclaim2, $HcomSbase, $HcomSBuild, $HcomScity, $HcomSDbase, $HcomSDestroy, $HcomSearch, $HcomSEisei, $HcomSell, $HcomSellTree, $HcomSendMonster, $HcomSendMonsterTurn, $HcomSFactory, $HcomSFarm, $HcomSFood, $HcomShip, $HcomShipbuild, $HcomShipM, $HcomShipSell, $HcomSMissile, $HcomSMissileGM, $HcomSMissileMGM, $HcomSMissilePP, $HcomSMonument, $HcomSOccupy, $HcomSpaceBase, $HcomSpaceFarm, $HcomSpecialSPP, $HcomSPioneer, $HcomSpy, $HcomSSendMonster, $HcomSSendMonsterTurn, $HcomSTManipulate, $HcomSUnit, $HcomTeisatu, $HcomTower, $HcomTrump, $HcomUg, $HcomWarp, $HcomWeponBuy, $HcomWeponSell, $HcomWindmill, $HconsolationMatch, $HcurrentNumber, $HdBaseAuto, $HdefenceHex, $HdefenceSpace, $HdevelopeTurn, $HdirMode, $HdirName, $HdisAEruption, $HdisAkasio, $HdisBHarvest, $HdisCrime, $HdisEarthquake, $HdisEruption, $HdisFallBorder, $HdisFalldown, $HdisFire, $HdisGHarvest, $Hdishangen, $HdisHugeMeteo, $HdisKLimit, $HdisMaizo, $HdisMeteo, $HdisMonsBorder1, $HdisMonsBorder2, $HdisMonsBorder3, $HdisMonsBorder4, $HdisMonsBorder5, $HdisMonster, $HdisMonsterU, $HdisPirate, $HdisPollution, $HdisSeaMonster, $HdisSHugeMeteo, $HdisSpaceMonster1, $HdisSpaceMonster2, $HdisTinka, $HdisTreasureS, $HdisTsunami, $HdisTyphoon, $HdisUN, $HdisVGHarvest, $HearthAttack, $HeatenFood, $helpDir, $HfightMem, $HfightTurn, $HfinalTurn, $HgiveupTurn, $HhistoryMax, $HidToName, $HidToNumber, $HidToNumberR, $HinterTime, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HlandAegisShip, $HlandAirport, $HlandAmusement, $HlandBalloonS, $HlandBank, $HlandBase, $HlandBigcity, $HlandBreakwater, $HlandCasino, $HlandCoupleRock, $HlandDeathtrap, $HlandDefence, $HlandDokan, $HlandDome, $HlandEarth, $HlandExpo, $HlandFactory, $HlandFarm, $HlandFire, $HlandFishLShip, $HlandFishMShip, $HlandFishSShip, $HlandFlower, $HlandForest, $HlandFuji, $HlandGhostShip, $HlandHaribote, $HlandHospital, $HlandHugecity, $HlandIceFloe, $HlandKInora, $HlandMegacity, $HlandMegaFact, $HlandMegaFarm, $HlandMegatower, $HlandMonsShip, $HlandMonster, $HlandMonument, $HlandMountain, $HlandMyhome, $HlandOcean, $HlandOil, $HlandOPlayer, $HlandOsen, $HlandPark, $HlandPirate, $HlandPlains, $HlandPolice, $HlandPort, $HlandProbeShip, $HlandSAEisei, $HlandSbase, $HlandSchool, $HlandSCity, $HlandSDefence, $HlandSea, $HlandSeisei, $HlandSFactory, $HlandSFarm, $HlandSlum, $HlandSMonument, $HlandSpaceBase, $HlandStadium, $HlandSunit, $HlandTcity, $HlandTitanic, $HlandTower, $HlandTown, $HlandTreasureS, $HlandTrump, $HlandWarp, $HlandWarpR, $HlandWaste, $HlandWindmill, $HlandWingDragon, $HlandZoo, $HlateLogPool, $HlogMax, $HlogOmit2, $HlogPool, $HmaxdisPollution, $HmaxExpPoint, $HmaxIsland, $HmonsBtlMaxHp, $HmonsBtlMaxPa, $HmonsterAGI, $HmonsterBHP, $HmonsterCLS, $HmonsterDEF, $HmonsterDestroy, $HmonsterDHP, $HmonsterExp, $HmonsterGRP, $HmonsterL1, $HmonsterL1Num, $HmonsterL2, $HmonsterL2Num, $HmonsterL3, $HmonsterL3Num, $HmonsterL4, $HmonsterL4Num, $HmonsterL5, $HmonsterL5Num, $HmonsterName, $HmonsterNumber, $HmonsterS, $HmonsterSEI, $HmonsterSKL, $HmonsterSP, $HmonsterSpecial, $HmonsterSTR, $HmonsterValue, $Hmonth, $HmonumentMissile, $HmonumentName, $HmonumentRocket, $Hocean, $HoceanSize, $HoilMoney, $HoilRatio, $hp, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $Hprize, $HprizeV, $HpunishInfo, $HrepeatTurn, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $HseaChk, $HsecretLogPool, $HsEisei, $HshipEX, $HshipFood, $HshipHP, $HshipKAI, $HshipMATK, $HshipMoney, $HshipName, $Hshiporder, $HshipSATK, $HshipSell, $HshipSP, $HsmonumentName, $HsmonumentNumber, $Hsolarwind, $Hspace, $HspaceEfficiency, $HspaceIncome, $Hsstartturn, $HStotalPoint, $HsurvFlg, $Hsurvivalturn, $HtagName2_, $HthisFile, $HtotalBumon, $HtotalMoney, $HtotalPoint, $Htournament, $HtreeValue, $HturnPrizeNumber, $HturnPrizePoint, $HturnPrizeUnit, $HturnPrizeVarious, $HugDokan, $HugFact, $HugFarm, $HugHasigo, $HugKiti, $HugMax, $HugOil, $HugRoad, $HugSpace, $HugTosi, $human, $HunitFood, $HunitMoney, $HunitOil, $HunitOre, $HunitPop, $HunitTime, $HunitWeapon, $HwarFlg, $HWeatherMax, $Hwflg, $HwinFood, $HwinIsland, $HwinMoney, $HwinWeapon, $imageDir, $lockMode, $toppage, $versionInfo;
	$sno = null; $m = null; $i = null; $sArray = null; $spnt = null; $x = null; $y = null; $z = null; $point = null;
	$ptn = array("개간","매립","개간, 매립","굴착","개간, 굴착","매립, 굴착","개간, 매립, 굴착");
	$sno = $island[$kind];
	$point = "";
	if($sno > 0) {
		if($flag == 1) {
			$kind .= 'pnt';

			$sArray = $island[$kind];
			for($i = 0; $i < $sno; $i++) {
				$spnt = $sArray[$i];
				if ($spnt == "") { break; }
				list($x, $y, $z) = array($spnt['x'], $spnt['y'], $spnt['z']);
				if($z == '개간'){
					$point .= " 개간($x, $y)";
					if (!($m & 1)) { $m |= 1; }
				}elseif($z == '매립'){
					$point .= " 매립($x, $y)";
					if (!($m & 2)) { $m |= 2; }
				}elseif($z == '굴착'){
					$point .= " 굴착($x, $y)";
					if (!($m & 4)) { $m |= 4; }
				}else{
					$point .= "($x, $y)";
				}
				if (!(($i+1)%20)) { $point .= "<br>　　　"; }
			}
		}
		if ($i > 1 || $flag != 1) { $point .= "의<B>${sno}개소</B>"; }
	}
	if (!($point == "")) {
		if(($flag == 1) && ($m > 0)) {
			logLandSucMatome($island['id'], $island['name'], $ptn[$m-1], "$point");
		} else {
			logLandSuc($island['id'], $island['name'], $z, "($x, $y)");
		}
	}
}

// 로그에의 출력
// 제1 인수:메세지
// 제2 인수:당사자
// 제3 인수:상대

// 통상 로그
function logOut() {
  $_args = func_get_args();
global $HislandTurn, $HlogPool;
	array_push($HlogPool, "0,$HislandTurn,{$_args[1]},{$_args[2]},{$_args[0]}");
}

// 지연 로그
function logLate() {
  $_args = func_get_args();
global $HislandTurn, $HlateLogPool;
	array_push($HlateLogPool, "0,$HislandTurn,{$_args[1]},{$_args[2]},{$_args[0]}");
}

// 기밀 로그
function logSecret() {
  $_args = func_get_args();
global $HislandTurn, $HsecretLogPool;
	array_push($HsecretLogPool, "1,$HislandTurn,{$_args[1]},{$_args[2]},{$_args[0]}");
}

// 날씨 로그
function logWeather() {
  $_args = func_get_args();
global $HislandTurn, $HlogdirName;
	hako_open('HOUT', ">>${HlogdirName}/weather.his");
	hako_write('HOUT', "$HislandTurn,{$_args[0]}\n");
	hako_close('HOUT');
}

// 기록 로그
function logHistory() {
  $_args = func_get_args();
global $HislandTurn, $HlogdirName;
	hako_open('HOUT', ">>${HlogdirName}/hakojima.his");
	hako_write('HOUT', "$HislandTurn,{$_args[0]}\n");
	hako_close('HOUT');
}

// 기록 로그 조정
function logHistoryTrim($logname, $Maxlog) {
global $HlogdirName;
	hako_open('HIN', "${HlogdirName}/${logname}");
	$line = null; $l = null;
	$count = 0;
	while (($l = hako_getline('HIN')) !== false) {
		$l = rtrim($l);
		array_push($line, $l);
		$count++;
	}
	hako_close('HIN');

	if($count > $Maxlog){
		hako_open('HOUT', ">${HlogdirName}/${logname}");
		$i = null;
		for($i = ($count - $Maxlog); $i < $count; $i++){
			hako_write('HOUT', "{$line[$i]}\n");
		}
		hako_close('HOUT');
	}
}

// 로그 서두
function logFlush() {
global $HlateLogPool, $HlogPool, $HsecretLogPool, $HlogdirName;
	if (!isset($HlogPool) || !is_array($HlogPool)) { $HlogPool = array(); }
	if (!isset($HlateLogPool) || !is_array($HlateLogPool)) { $HlateLogPool = array(); }
	if (!isset($HsecretLogPool) || !is_array($HsecretLogPool)) { $HsecretLogPool = array(); }
	hako_open('LOUT', ">${HlogdirName}/hakojima.log0");

	// 전부역순서로 해 써낸다
	$i = null;
	for($i = (count($HsecretLogPool) - 1); $i >= 0; $i--){
		hako_write('LOUT', $HsecretLogPool[$i]);
		hako_write('LOUT', "\n");
	}
	for($i = (count($HlateLogPool) - 1); $i >= 0; $i--){
		hako_write('LOUT', $HlateLogPool[$i]);
		hako_write('LOUT', "\n");
	}
	for($i = (count($HlogPool) - 1); $i >= 0; $i--){
		hako_write('LOUT', $HlogPool[$i]);
		hako_write('LOUT', "\n");
	}
	hako_close('LOUT');
}

//----------------------------------------------------------------------
// 로그 템플릿
//----------------------------------------------------------------------

// 더미 명령
function logDummy($id, $name, $comName, $point) {
global $AfterName, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
	logSecret("${HtagName_}${name}${AfterName}$point${H_tagName} 의 ${HtagComName_}${comName}${H_tagComName} 는  더미 명령입니다.",$id);
}

// 커멘드 실패
function logMiss() {
  $_args = func_get_args();
global $AfterName, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
	logOut("${HtagName_}{$_args[1]}$AfterName${H_tagName} 으로 예정되어 있던${HtagComName_}{$_args[2]}${H_tagComName} 는 ,{$_args[3]}으로 중단되었습니다. ",$_args[0]);
}

// 커멘드 실패(우주)
function logMissS() {
  $_args = func_get_args();
global $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
	logOut("${HtagName_}${SpaceName}{$_args[3]}${H_tagName} 으로 예정되어 있던${HtagComName_}{$_args[2]}${H_tagComName} 는 ,{$_args[4]} 중단되었습니다.",$_args[0]);
}
// 커멘드 실패 2(우주)
function logMissS2() {
  $_args = func_get_args();
global $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
	logOut("${HtagName_}${SpaceName}{$_args[3]}${H_tagName} 으로 예정되어 있던${HtagComName_}{$_args[2]}${H_tagComName} 는 ,{$_args[4]} 실패했습니다.",$_args[0], 999);
}

// 대상 지형의 종류에 의한 실패
function logLandFail($id, $name, $comName, $landName, $point, $landKind, $lv) {
global $AfterName, $HlandGhostShip, $HlandMonster, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
	if($landKind == $HlandGhostShip){
		// 유령배는 바다에 위장
		$landName = '바다';
	}elseif($landKind == $HlandMonster) {
		// 미채 이노라
		if(hako_pick(monsterSpec($lv), array(0)) == 26){
			$landName = '황무지';
		}
	}
	logOut("${HtagName_}$name${AfterName}${H_tagName} 으로 예정되어 있던${HtagComName_}$comName${H_tagComName} 는 , 예정지의${HtagName_}$point${H_tagName} 가<B>$landName</B>이기 때문에 중단되었습니다.",$id);
}

// 주위에 바다나 육지가 없어서 매립 실패
function logNoLandAround() {
  $_args = func_get_args();
global $AfterName, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
	logOut("${HtagName_}{$_args[1]}${AfterName}${H_tagName} 으로 예정되어 있던${HtagComName_}{$_args[2]}${H_tagComName} 는 , 예정지의${HtagName_}{$_args[4]}${H_tagName} 의  주변에{$_args[3]}이 없었기 때문에 중단되었습니다.",$_args[0]);
}

// 항구 폐쇄
function logClosedPort($id, $name, $lName, $point) {
global $AfterName, $HtagName_, $H_tagName;
	logOut("${HtagName_}${name}${AfterName}$point${H_tagName} 의 <B>$lName</B>는 폐쇄한 것 같습니다.",$id);
}

// 정지계 성공
function logLandSuc($id, $name, $comName, $point) {
global $AfterName, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
	logOut("${HtagName_}${name}${AfterName}$point${H_tagName} 으로 ${HtagComName_}${comName}${H_tagComName} 을 했습니다.",$id);
}

// 정지계 로그 통계
function logLandSucMatome($id, $name, $comName, $point) {
global $AfterName, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
	logOut("${HtagName_}${name}${AfterName}${H_tagName} 으로 ${HtagComName_}${comName}${H_tagComName}을 했습니다.<br>　　<B>⇒</B> $point",$id);
}

// 정지계(우주) 성공
function logLandSucS($id, $name, $comName, $point) {
global $AfterName, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
	logOut("${HtagName_}${SpaceName}${point}${H_tagName} 으로 ${HtagName_}$name$AfterName${H_tagName}에 의한${HtagComName_}${comName}${H_tagComName}을 했습니다.",$id,999);
}

// 선물 실패
function logNoPresent($id, $name, $comName, $point) {
global $AfterName, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
	logOut("${HtagName_}${name}${AfterName}$point${H_tagName} 으로 ${HtagComName_}${comName}${H_tagComName} 는  해당의 선물이 없기 때문에, 중단되었습니다",$id);
}
// 선물 원조
function logPresent($id, $tId, $name, $tName) {
global $AfterName, $HtagName_, $H_tagName;
	logOut("${HtagName_}${name}${AfterName}${H_tagName} 가 선물을${HtagName_}${tName}${AfterName}${H_tagName}에 양도했습니다.",$id, $tId);
}

// 숲의 자동 벌채
function logAutoTree($id, $name) {
global $AfterName, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
	logOut("${HtagName_}${name}${AfterName}${H_tagName} 의 <B>숲</B>을${HtagComName_}벌채${H_tagComName}, 새롭게${HtagComName_}식림${H_tagComName}했습니다.",$id);
}

// 조사계 로그
function logChosa() {
  $_args = func_get_args();
global $AfterName, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
	logOut("${HtagName_}{$_args[1]}${AfterName}{$_args[2]}${H_tagName} 으로<B>{$_args[4]}</B>의 예산을 쏟아 넣은${HtagComName_}{$_args[3]}${H_tagComName}를 하고{$_args[5]}",$_args[0]);
}

// 유전으로부터의 수입
function logOilMoney($id, $name, $lName, $point, $value) {
global $AfterName, $HislandTurn, $HunitMoney, $HtagName_, $H_tagName, $HlogdirName;
	logOut("${HtagName_}${name}${AfterName}$point${H_tagName} 의 <B>$lName</B>로부터,<B>$value$HunitMoney</B>의 수익이 올랐습니다.",$id);
	//랭킹용 로그 파일 서두
	hako_open('MOUT',">>${HlogdirName}/money.log");
	hako_write('MOUT', "$HislandTurn,$id,온천,$value\n");
	hako_close('MOUT');
}

// 유전 고갈
function logOilEnd($id, $name, $lName, $point) {
global $AfterName, $HtagName_, $H_tagName;
	logOut("${HtagName_}${name}${AfterName}$point${H_tagName} 의 <B>$lName</B>는 고갈한 것 같습니다.",$id);
}

// 방위 시설, 자폭 세트
function logBombSet($id, $name, $lName, $point) {
global $AfterName, $HtagName_, $H_tagName;
	logOut("${HtagName_}${name}${AfterName}$point${H_tagName} 의 <B>$lName</B>의<B>자폭 장치가 가동</B>되었습니다.",$id);
}

// 방위 시설, 자폭 작동
function logBombFire($id, $name, $lName, $point) {
global $AfterName, $HtagName_, $H_tagName, $HtagDisaster_, $H_tagDisaster;
	logOut("${HtagName_}${name}${AfterName}$point${H_tagName} 의 <B>$lName</B>,${HtagDisaster_}자폭 장치 작동!${H_tagDisaster}",$id);
}

// 기념비, 발사
function logMonFly($id, $name, $lName, $point) {
global $AfterName, $HtagName_, $H_tagName;
	logOut("${HtagName_}${name}${AfterName}$point${H_tagName} 의 <B>$lName</B>가<B>굉음과 함께 날아올랐습니다</B>.",$id);
}

// 기념비, 낙하
function logMonDamage($id, $name, $point) {
global $AfterName, $HtagName_, $H_tagName;
	logOut("<B>무엇인지 알수없는 것</B>이${HtagName_}${name}${AfterName}$point${H_tagName}지점에 낙하했습니다!",$id);
}

// 식림 or미사일 기지
function logPBSuc($id, $name, $comName, $point) {
global $AfterName, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
	logSecret("${HtagName_}${name}${AfterName}$point${H_tagName} 으로 ${HtagComName_}${comName}${H_tagComName}을 했습니다.",$id);
	logOut("마음 탓인지${HtagName_}${name}${AfterName}${H_tagName} 의 <B>숲</B>이 증가한 것 같습니다.",$id);
}

// 위장 방위 시설
function logHariSuc($id, $name, $comName, $comName2, $point) {
global $AfterName, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
	logSecret("${HtagName_}${name}${AfterName}$point${H_tagName} 으로 ${HtagComName_}${comName}${H_tagComName}을 했습니다.",$id);
	logLandSuc($id, $name, $comName2, $point);
}

// 로켓 발사 실패
function logRocketF($id, $name) {
global $AfterName, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
	logOut("${HtagName_}${name}${AfterName}${H_tagName}가${HtagComName_} 로켓${H_tagComName}를 발사했습니다만,<B>실패</B>했습니다.",$id);
}

// 로켓 발사 성공

function logRocketS($id, $name) {
global $AfterName, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
	logOut("${HtagName_}${name}${AfterName}${H_tagName}가${HtagComName_} 로켓${H_tagComName}를 발사해 <B>성공</B>했습니다.",$id);
}

// 모략 실패
function logSpyF($id, $tId, $name, $tName, $comName) {
global $AfterName, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
	logLate("${HtagName_}${name}${AfterName}${H_tagName} 가${HtagName_}${tName}${AfterName}${H_tagName}에${HtagComName_}$comName${H_tagComName}을 했습니다만, 실패해서 잡혔습니다.",$id, $tId);
}
// 기지 발견
function logBeseFind($id, $tName, $tPoint, $tLv, $tLname) {
global $AfterName, $HtagName_, $H_tagName;
	logSecret("${HtagName_}${tName}${AfterName}$tPoint${H_tagName}지점에서 경험치<B>$tLv</B>의<B>$tLname</B>발견!",$id);
}

// 방위 시설 판별
function logLandTruth($id, $tName, $tPoint, $tLname, $truth) {
global $AfterName, $HtagName_, $H_tagName;
	logSecret("${HtagName_}${tName}${AfterName}$tPoint${H_tagName}>지점의<B>$tLname</B>는 아무래도<B>$truth</B>와 같습니다.",$id);
}
// 운석 전이 장치에 떨어진다
function logWarpMeteo($id, $name, $lName, $point) {
global $AfterName, $HtagName_, $H_tagName;
	logOut("<B>운석</B>이${HtagName_}${name}${AfterName}$point${H_tagName} 의 <B>$lName</B>에 낙하,<B>시공의 틈에 빨려 사라졌습니다!</B>",$id);
}

// 괴수, 유엔에 토벌 된다.
function logUNMons($id, $name, $mName, $point) {
global $AfterName, $HtagName_, $H_tagName;
	logOut("${HtagName_}${name}${AfterName}$point${H_tagName}의 <B>괴수 $mName</B>는 국제 연합군에 의해 토벌 되고 황무지가 되었습니다.",$id);
}

// 괴수, 전이 장치를 밟는다
function logWarpMons($id, $name, $lName, $point, $mName) {
global $AfterName, $HtagName_, $H_tagName;
	logOut("<B>$mName</B>가${HtagName_}${name}${AfterName}$point${H_tagName} 의 <B>${lName}</B>에 도달,<B>시공의 틈에 빨려 사라졌습니다!</B>",$id);
}
// 괴수, 전이 실패
function logWarpMonsMiss($id, $name, $point, $mName) {
global $AfterName, $HtagName_, $H_tagName;
	logOut("전송 했음이 분명한<B>$mName</B>가${HtagName_}${name}${AfterName}$point${H_tagName}에<B>다시 되돌아왔습니다!</B>",$id);
}
//  괴수, 운석, 미사일 전이
function logMWarp($id, $tId, $Name, $tName, $point, $lName) {
global $AfterName, $HtagName_, $H_tagName;
	logOut("${HtagName_}${tName}${AfterName}$point${H_tagName}지점의 공간이 비뚤어져, 돌연<B> {lName}</B>가 출현했습니다. 아무래도${HtagName_}${Name}${AfterName}${H_tagName}산과 같습니다.",$id, $tId);
}
// 미사일 쏘려고 했다(or 괴수 파견하려고 했다)가 타겟이 없다
function logMsNoTarget($id, $name, $comName) {
global $AfterName, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
	logOut("${HtagName_}${name}${AfterName}${H_tagName} 으로 예정되${HtagComName_}${comName}${H_tagComName} 는 , 목표의 ${AfterName}에 사람이 눈에 띄지 않기 때문에 중단되었습니다.",$id);
}
// 미사일 쏘려고 했다(or 괴수 파견하려고 했다)이 유엔에 멈추어졌다
function logUNMiss($id, $tId, $name, $tName, $comName) {
global $AfterName, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
	logOut("${HtagName_}${name}${AfterName}${H_tagName} 으로 예정되어 있던${HtagComName_}${comName}${H_tagComName} 는 , 목표의 ${HtagName_}${tName}${AfterName}${H_tagName} 이 유엔 보호 기간 으로 중단되었습니다.",$id, $tId);
}

// 방위 시설 진화
function logDefenceS($id, $tId, $tName, $tLname, $tPoint) {
global $HtagName_, $H_tagName;
	logOut("--- ${HtagName_}$tPoint${H_tagName} 의 <B>${tLname}</B>는S${tLname} 으로 발전했습니다.",$id, $tId);
}
//  방위 시설 다운

function logDefenceD($id, $tId, $tName, $tLname, $tPoint) {
global $HtagName_, $H_tagName;
	logOut("--- ${HtagName_}$tPoint${H_tagName} 의 <B>S${tLname}</B>는${tLname}에 레벨 다운했습니다.",$id, $tId);
}
// 미사일 발사수 등 표시
function logMissile() {
  $_args = func_get_args();
global $AfterName, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
	logOut("${HtagName_}{$_args[2]}${AfterName}${H_tagName} 가${HtagName_}{$_args[3]}${AfterName}{$_args[5]}${H_tagName}지점으로 향해<b>{$_args[6]}발</b>의${HtagComName_}{$_args[4]}${H_tagComName}를 실시했습니다.(명중{$_args[7]},무해{$_args[8]},기후{$_args[9]},방위{$_args[10]})",$_args[0], $_args[1]);
}
function logMissileS() {
  $_args = func_get_args();
global $AfterName, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
	logSecret("${HtagName_}{$_args[2]}${AfterName}${H_tagName} 가${HtagName_}{$_args[3]}${AfterName}{$_args[5]}${H_tagName}지점으로 향해<b>{$_args[6]}발</b>의${HtagComName_}{$_args[4]}${H_tagComName}를 실시했습니다.(명중{$_args[7]},무해{$_args[8]},기후{$_args[9]},방위{$_args[10]})",$_args[0], $_args[1]);
	logLate("<B>누군가</B>가${HtagName_}{$_args[3]}${AfterName}{$_args[5]}${H_tagName}지점으로 향해<b>{$_args[6]}발</b>의${HtagComName_}{$_args[4]}${H_tagComName}를 실시했습니다.(명중{$_args[7]},무해{$_args[8]},기후{$_args[9]},방위{$_args[10]})", $_args[1]);
}

// 통상 미사일 통상 지형에 명중
function logMsNormal() {
  $_args = func_get_args();
global $HtagName_, $H_tagName;
	logOut("--- ${HtagName_}{$_args[3]}${H_tagName} 의 <B>{$_args[2]}</B>에 명중, 일대가 {$_args[4]}했다.",$_args[0],$_args[1]);
}

// 스텔스 미사일 통상 지형에 명중
function logMsNormalS($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint, $result) {
global $AfterName, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
	logSecret("--- ${HtagName_}$tPoint${H_tagName} 의 <B>$tLname</에 명중, 일대가 ${result}했다.",$id, $tId);
	logLate("<B>누군가</B>가${HtagName_}${tName}${AfterName}$point${H_tagName}지점으로 향해${HtagComName_}${comName}${H_tagComName}를 실시해,${HtagName_}$tPoint${H_tagName} 의 <B>$tLname</B>에 명중, 일대가 ${result}했다.",$tId);
}

// 스텔스 미사일 방위 시설에서 판명
function logMsCaughtH($tId, $name, $comName) {
global $AfterName, $HtagComName_, $H_tagComName, $HtagName_, $H_tagName;
	logSecret("막은${HtagComName_}${comName}${H_tagComName}를 공격한 도은,${HtagName_}${name}${AfterName}${H_tagName}와 같습니다.",$tId);
}

// 바이오 미사일
function logBioMs() {
  $_args = func_get_args();
global $HtagName_, $H_tagName;
	logOut("--- ${HtagName_}{$_args[3]}${H_tagName} 의 <B>{$_args[2]}</B>에 떨어져 일대가 <B>오염</B>했습니다. ",$_args[0],$_args[1]);
}

// 육지 파괴탄 명중
function logMsLD() {
  $_args = func_get_args();
global $HtagName_, $H_tagName;
	logOut("--- ${HtagName_}{$_args[2]}${H_tagName}{$_args[3]}했다.",$_args[0],$_args[1]);
}
// 통상 미사일, 괴수에게 명중, 방어중에서 무상
function logMsMonNoDamage() {
  $_args = func_get_args();
global $HtagName_, $H_tagName;
	logOut("--- ${HtagName_}{$_args[3]}${H_tagName} 의 <B>괴수{$_args[2]}</B>에 명중, 그러나 방어 상태였기 때문에 효과가 없었습니다.",$_args[0],$_args[1]);
}

// 스텔스 미사일, 괴수에게 명중, 방어중에서 무상
function logMsMonNoDamageS($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) {
global $AfterName, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
	logSecret("${HtagName_}${name}${AfterName}${H_tagName} 가${HtagName_}${tName}${AfterName}$point${H_tagName}지점으로 향해${HtagComName_}${comName}${H_tagComName}를 실시해,${HtagName_}$tPoint${H_tagName} 의 <B>괴수$tLname</B>에 명중, 그러나 방어 상태였기 때문에 효과가 없었습니다. ",$id, $tId);
	logLate("<B>누군가</B>가${HtagName_}${tName}${AfterName}$point${H_tagName}지점으로 향해${HtagComName_}${comName}${H_tagComName}를 실시해,${HtagName_}$tPoint${H_tagName} 의 <B>괴수$tLname</B>에 명중, 그러나 방어 상태였기 때문에 효과가 없었습니다.",$tId);
}

// 통상 미사일, 괴수에게 명중, 살상
function logMsMonKill($id, $tId, $name, $tName, $tLname, $tPoint) {
global $HislandTurn, $HtagName_, $H_tagName, $HlogdirName;
	logOut("--- ${HtagName_}$tPoint${H_tagName} 의 <B>괴수$tLname</B>에 명중.<B>괴수$tLname</B>는 힘이 다해 넘어졌습니다.",$id, $tId);

	// 랭킹용 로그 파일 서두
	hako_open('ROUT',">>${HlogdirName}/ranking.log");
	hako_write('ROUT', "$HislandTurn,$id,$tId,$tLname\n");
	hako_close('ROUT');
}

// 스텔스 미사일, 괴수에게 명중, 살상
function logMsMonKillS($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) {
global $AfterName, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
	logSecret("${HtagName_}${name}${AfterName}${H_tagName} 가${HtagName_}${tName}${AfterName}$point${H_tagName}지점으로 향해${HtagComName_}${comName}${H_tagComName}를 실시해,${HtagName_}$tPoint${H_tagName} 의 <B>괴수$tLname</B>에 명중. <B>괴수 $tLname</B>는 힘이 다해 넘어졌습니다.",$id, $tId);
	logLate("<B>누군가</B>가${HtagName_}${tName}${AfterName}$point${H_tagName}지점으로 향해${HtagComName_}${comName}${H_tagComName}를 실시해,${HtagName_}$tPoint${H_tagName} 의 <B>괴수$tLname</B에 명중. <B>괴수$tLname</B>는 힘이 다해 넘어졌습니다.", $tId);
}

// 통상 미사일, 괴수에게 명중, 데미지
function logMsMonster() {
  $_args = func_get_args();
global $HtagName_, $H_tagName;
	logOut("--- ${HtagName_}{$_args[3]}${H_tagName} 의 <B>괴수{$_args[2]}</B>에 명중. <B>괴수{$_args[2]}</B는 괴로운 듯 사납게 울부짖고 했습니다.",$_args[0],$_args[1]);
}

// 스텔스 미사일, 괴수에게 명중, 데미지?
function logMsMonsterS($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) {
global $AfterName, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
	logSecret("${HtagName_}${name}${AfterName}${H_tagName} 가${HtagName_}${tName}${AfterName}$point${H_tagName}지점으로 향해${HtagComName_}${comName}${H_tagComName}를 실시해,${HtagName_}$tPoint${H_tagName} 의 <B>괴수$tLname</B>에 명중.<B>괴수$tLname</B>는 괴로운 듯 사납게 울부짖고 했습니다.",$id, $tId);
	logLate("<B>누군가</B>가${HtagName_}${tName}${AfterName}$point${H_tagName}지점으로 향해${HtagComName_}${comName}${H_tagComName}를 실시해,${HtagName_}$tPoint${H_tagName} 의 <B>괴수$tLname</B>에 명중. <B>괴수$tLname</B>는 괴로운 듯 사납게 울부짖고 했습니다.",$tId);
}

// 미사일 지형에 명중(우주, 해역)
function logMsSpace() {
  $_args = func_get_args();
global $HtagName_, $H_tagName;
	logOut("--- ${HtagName_}{$_args[1]}${H_tagName} 의 <B>{$_args[2]}</B>에 명중, 일대가 {$_args[3]}했다. ",$_args[0],$_args[4]);
}
// 미사일 지형에 명중(해역)
function logMsOPlayer() {
  $_args = func_get_args();
global $HtagName_, $H_tagName;
	logOut("--- ${HtagName_}{$_args[1]}${H_tagName} 의 <B>{$_args[2]}</B>부근에 낙하, 파편이 쏟아진 모양. ",$_args[0],$_args[3]);
}
// 미사일 괴수에게 명중(우주, 해역)
function logMsMonSpace() {
  $_args = func_get_args();
global $HtagName_, $H_tagName;
	logOut("--- ${HtagName_}{$_args[1]}${H_tagName} 의 <B>괴수{$_args[2]}</B>에 명중,<B>괴수{$_args[2]}</B>는 괴로운 듯 사납게 울부짖고 했습니다 ",$_args[0],$_args[3]);
}
// 미사일, 괴수에게 명중, 살상(우주, 해역)
function logMsMonKillSpace() {
  $_args = func_get_args();
global $HislandTurn, $HtagName_, $H_tagName, $HlogdirName;
	logOut("--- ${HtagName_}{$_args[2]}${H_tagName} 의 <B>괴수{$_args[3]}</B>에 명중,<B>괴수{$_args[3]}</B은 힘이 다해 넘어졌습니다.",$_args[0],$_args[4]);

	// 랭킹용 로그 파일 서두
	hako_open('ROUT',">>${HlogdirName}/ranking.log");
	hako_write('ROUT', "$HislandTurn,{$_args[0]},{$_args[4]},{$_args[3]}\n");
	hako_close('ROUT');
}
// 미사일 발사수 등 표시(우주, 해역
function logMissileSpace() {
  $_args = func_get_args();
global $AfterName, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
	logOut("${HtagName_}{$_args[1]}${AfterName}${H_tagName} 가${HtagName_}{$_args[9]}{$_args[3]}${H_tagName}지점으로 향해<b>{$_args[4]}발</b>의${HtagComName_}{$_args[2]}${H_tagComName}를 실시했습니다. (명중{$_args[5]}, 무해{$_args[6]}, 실패{$_args[7]}, 방위{$_args[8]})",$_args[0],$_args[10]);
}
// 괴수의 시체
function logMsMonMoney($tId, $mName, $value) {
global $HislandTurn, $HunitMoney, $HlogdirName;
	logOut("<B>괴수$mName</B>의 잔해에는,<B>$value$HunitMoney</B>의 값이 붙었습니다.",$tId);
	
	// 랭킹용 로그 파일 서두
	hako_open('MOUT',">>${HlogdirName}/money.log");
	hako_write('MOUT', "$HislandTurn,$tId,괴수 격파,$value\n");
	hako_close('MOUT');
}

// 미사일 명령 중지
function logMsMiss() {
  $_args = func_get_args();
global $AfterName, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
	logOut("${HtagName_}{$_args[1]}$AfterName${H_tagName} 으로 예정되어 있던${HtagComName_}{$_args[2]}${H_tagComName} 는 , 미사일 설비를 보유하고 있지 않거나, 혹은 그것들을 가동할 수 없는 상황이기 때문에 중단되었습니다. ",$_args[0]);
}

// 괴수, 성불할 수 없다
function logMonsRei() {
  $_args = func_get_args();
global $HtagName_, $H_tagName;
	logOut("--- ${HtagName_}{$_args[3]}${H_tagName} 의 <B>괴수{$_args[2]}</B>에 명중,<B>괴수{$_args[2]}</B>는 힘이 다했습니다만, 성불하지 못하고<B>지바쿠 레이</B>가 되었습니다.",$_args[0],$_args[1]);
}

// 괴수, 순금의 비
function logMonsGold($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) {
global $AfterName, $HislandTurn, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName, $HlogdirName;
	logOut("${HtagName_}${name}${AfterName}${H_tagName} 가${HtagName_}${tName}${AfterName}$point${H_tagName}지점으로 향해${HtagComName_}${comName}${H_tagComName}를 실시해,${HtagName_}$tPoint${H_tagName} 의 <B>괴수$tLname</B>에 명중. <B>괴수$tLname</B>는 힘이 다했습니다. 그 때의 잔해로<B>순금의 비</B>가 만들어졌습니다.",$id, $tId);

	//랭킹용 로그 파일 서두
	hako_open('ROUT',">>${HlogdirName}/ranking.log");
	hako_write('ROUT', "$HislandTurn,$id,$tId,$tLname\n");
	hako_close('ROUT');
}

// 괴수, 반격
function logMonsCounter() {
  $_args = func_get_args();
global $HtagName_, $H_tagName;
	logOut("--- ${HtagName_}{$_args[3]}${H_tagName} 의 <B>괴수{$_args[2]}</B>에 명중. 그러나 효과가 없을 뿐만 아니라 보복에 우주로부터{$_args[4]}",$_args[0],$_args[1]);
}

// 미사일 난민 도착
function logMsBoatPeople($id, $name, $achive) {
global $AfterName, $HunitPop, $HtagName_, $H_tagName;
	logOut("${HtagName_}${name}${AfterName}${H_tagName}에 어디에서 왔는지 <B>$achive${HunitPop}의 난민</B>이 표착했습니다${HtagName_}${name}${AfterName}${H_tagName} 는  기분 좋게 받아들인 것 같습니다.",$id);
}

// 은행 명중
function logMsBank($id, $name, $bank) {
global $AfterName, $HunitMoney, $HtagName_, $H_tagName;
	logOut("${HtagName_}${name}${AfterName}${H_tagName}에 어디에서 왔는지<B>$bank${HunitMoney}의 돈</B>이 표착했습니다.${HtagName_}${name}${AfterName}${H_tagName} 는  기분 좋게 받은 것 같습니다.",$id);
}

//--------괴수 배틀-------------
// 중지 전반
function logMonsCancel($id, $name, $comName, $Result) {
global $AfterName, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
	logOut("${HtagName_}${name}${AfterName}${H_tagName} 의 ${HtagComName_}${comName}${H_tagComName} 는 ,${Result}으로 중단되었습니다.",$id);
}

// 괴수 에그
function logMonsEGG($id, $name, $comName) {
global $AfterName, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
	logOut("${HtagName_}${name}${AfterName}${H_tagName} 으로 ${HtagComName_}${comName}${H_tagComName}를 실시해 괴수 이노라가 탄생했습니다.",$id);
}
// 괴수 매각
function logMonsSell($id, $name, $comName) {
global $AfterName, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
	logOut("${HtagName_}${name}${AfterName}${H_tagName} 으로 ${HtagComName_}${comName}${H_tagComName}를 실시해, 괴수는 없어졌습니다.",$id);
}
// 괴수 모의 훈련
function logMonsExer($id, $name, $comName) {
global $AfterName, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
	logOut("${HtagName_}${name}${AfterName}${H_tagName} 으로 먹이를 사용한${HtagComName_}${comName}${H_tagComName}를 실시해, 먹이가 없어졌습니다.",$id);
}
// 괴수 원정
function logMonsENSEI($id, $name, $tId, $tName, $comName) {
global $AfterName, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
	logOut("${HtagName_}${name}${AfterName}${H_tagName} 으로 ${HtagComName_}${comName}${H_tagComName}를 실시해${HtagName_}${tName}${AfterName}${H_tagName}에 출격 했습니다.",$id, $tId);
}
// 먹이 획득
function logMonsESA($id, $name, $mName) {
global $AfterName, $HtagName_, $H_tagName;
	logOut("${HtagName_}${name}${AfterName}${H_tagName} 는 ,<B>괴수$mName</b>를 먹이로서 획득 했습니다.",$id);
}
// 먹이 양도
function logMonsEsaAid($id, $name, $tId, $tName, $mName) {
global $AfterName, $HtagName_, $H_tagName;
	logOut("${HtagName_}${name}${AfterName}${H_tagName} 는 ,${HtagName_}${tName}${AfterName}${H_tagName}에<B>괴수$mName</B>를 먹이로서 양도했습니다.",$id, $tId);
}
// 괴수 양도
function logMonsAid($id, $name, $tId, $tName) {
global $AfterName, $HtagName_, $H_tagName;
	logOut("${HtagName_}${name}${AfterName}${H_tagName} 는 ,${HtagName_}${tName}${AfterName}${H_tagName}에 괴수를 양도했습니다.",$id, $tId);
}
// 괴수 진화
function logMonsEvo($id, $name, $mName, $mNameE, $comName) {
global $AfterName, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
	logOut("${HtagName_}${name}${AfterName}${H_tagName} 으로 ${HtagComName_}${comName}${H_tagComName}를 실시해<B>괴수$mName</B>의 원괴수가<B>괴수$mNameE</B>에 돌연변이했습니다.",$id);
}
// 괴수 진화 실패
function logMonsEvoF($id, $name, $mName, $comName) {
global $AfterName, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
	logOut("${HtagName_}${name}${AfterName}${H_tagName} 으로 ${HtagComName_}${comName}${H_tagComName}를 실시했습니다만, 아무것도 변화가 없었습니다.",$id);
}
// 괴수 공격
function logMonsATTACK($id, $name, $mName, $tId, $tName, $tmName, $Result) {
global $AfterName, $HtagName_, $H_tagName;
	logOut("${HtagName_}${name}${AfterName}${H_tagName} 의 <B>괴수$mName</B>가${HtagName_}${tName}${AfterName}${H_tagName} 의 <B>괴수$tmName</B>에<B>${Result}</B>",$id, $tId);
}
// 양자는 사이를 잡았다
function logMonsNOATTACK($id, $name, $mName, $tId, $tName, $tmName) {
global $AfterName, $HtagName_, $H_tagName;
	logOut("${HtagName_}${name}${AfterName}${H_tagName} 의 <B>괴수$mName</B>의${HtagName_}${tName}${AfterName}${H_tagName} 의 <B>괴수$tmName</B>는, 양자 사이를 잡아 움직이지 않았습니다.",$id, $tId);
}

// 괴수 회복
function logMonsRrcovery($id, $name, $mName, $tId, $P) {
global $AfterName, $HtagName_, $H_tagName;
	if($P > 0){
		logOut("${HtagName_}${name}${AfterName}${H_tagName} 의 <B>괴수$mName</B>는, 정신을 집중해<B>${P}</B>포인트 자가 회복했습니다.",$id, $tId);
	}
}

// 괴수 배틀 종료
function logMonsEND($id, $name, $mName, $tId, $Result) {
global $AfterName, $HtagName_, $H_tagName;
	logOut("${HtagName_}${name}${AfterName}${H_tagName} 의 <B>괴수$mName</B>는,<B>${Result}</B>",$id, $tId);
}
//-----------배계 로그---------------
// 보유도이 존재하지 않기 때문에 조난
function logShipWreck($id, $name, $tLname, $point) {
global $AfterName, $HtagName_, $H_tagName;
	logOut("${HtagName_}${name}${AfterName}$point${H_tagName}지점의<B>$tLname</B>는, 보유 섬이 존재하지 않기 때문에 조난했습니다.",$id);
}
// 해적, 유엔에 토벌 된다.
function logUNShip($id, $name, $mName, $point) {
global $AfterName, $HtagName_, $H_tagName;
	logOut("${HtagName_}${name}${AfterName}$point${H_tagName}지점의<B>$mName</B>는, 국제 연합군에 의해 토벌 되었습니다.",$id);
}
// 통상 미사일, 배에 명중, 데미지, 침몰
function logMsShip($id, $tId, $tLname, $tPoint, $tL, $result) {
global $HislandTurn, $HlandPirate, $HtagName_, $H_tagName, $HlogdirName;
	logOut("--- ${HtagName_}$tPoint${H_tagName} 의 <B>$tLname</B>에 명중.<B>$tLname</B>는 $result",$id, $tId);

	//랭킹용 로그 파일 서두
	$tL -= $HlandPirate;
	hako_open('ROUT',">>${HlogdirName}/ship.log");
	hako_write('ROUT', "$HislandTurn,$id,99,$tL\n");
	hako_close('ROUT');
}
// 통상 미사일, 배에 명중, 데미지
function logMsShipD($id, $tId, $tLname, $tPoint, $tL, $result) {
global $HtagName_, $H_tagName;
	logOut("--- ${HtagName_}$tPoint${H_tagName} 의 <B>$tLname</B>에 명중.<B>$tLname</B>은 $result",$id, $tId);
}
// 스텔스 미사일, 배에 명중, 데미지, 침몰
function logMsShipS($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint, $result) {
global $AfterName, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
	logSecret("${HtagName_}${name}${AfterName}${H_tagName} 가${HtagName_}${tName}${AfterName}$point${H_tagName}지점으로 향해${HtagComName_}${comName}${H_tagComName}를 실시해,${HtagName_}$tPoint${H_tagName} 의 <B>$tLname</B>에 명중<B>$tLname</B>는 $result",$id, $tId);
	logLate("<B>누군가</B>가${HtagName_}${tName}${AfterName}$point${H_tagName}지점으로 향해${HtagComName_}${comName}${H_tagComName}를 실시해,${HtagName_}$tPoint${H_tagName} 의 <B>$tLname</B>에 명중.<B>$tLname</B>는 $result",$tId);
}

// 배 움직인다
function logShipMove($id, $name, $lName, $point, $mName) {
global $AfterName, $HtagName_, $H_tagName;
	logOut("${HtagName_}${name}${AfterName}$point${H_tagName} 의 <B>$lName</B>부근에<B>$mName</B>가 이동했습니다.",$id);
}
// 배약탈
function logShipPlunder($id, $tId, $name, $lName, $point, $mName) {
global $AfterName, $HtagName_, $H_tagName;
	logOut("${HtagName_}${name}${AfterName}$point${H_tagName} 의 <B>$lName</B>부근에<B>$mName</B>가 이동했습니다. 그 때에 약탈을 실시해<B>$lName</B>는 파괴되었습니다.",$id, $tId);
}
// 배지령 변경
function logShipOrderC($id, $name, $lName, $point, $result) {
global $AfterName, $HtagName_, $H_tagName;
	logSecret("${HtagName_}${name}${AfterName}$point${H_tagName} 의 <B>$lName</B>의 지령을<B>$result</B>로 변경했습니다.",$id);
}

// 선현
function logShipCome($id, $name, $mName, $point) {
global $AfterName, $HtagName_, $H_tagName;
	logOut("${HtagName_}${name}${AfterName}${point}${H_tagName}에 <B>$mName</B> 출현!",$id);
}
// 후뉴우환
function logShipComeIs($id, $name, $mName, $point) {
global $AfterName, $HtagName_, $H_tagName;
	logOut("${HtagName_}${name}${AfterName}${point}${H_tagName}에<B>$mName</B>가, 돌아왔습니다!",$id);
}

// 배 사라진다
function logShipDis($id, $name, $mName, $point, $result) {
global $AfterName, $HtagName_, $H_tagName;
	logOut("${HtagName_}${name}${AfterName}${point}${H_tagName} 의 <B>$mName</B>${result}졌다.",$id);
}
// 배데스트랩 을 밟는다
function logShipMoveDeathtrap($id, $name, $lName, $point, $mName) {
global $AfterName, $HtagName_, $H_tagName;
	logOut("<B>$mName</B>가${HtagName_}${name}${AfterName}$point${H_tagName} 의 <B>$lName</B>에 도달,<B>${lName}</B>가 작동해<B>$mName</B>는 격침했습니다!",$id);
}

//-----------여기까지---------------

// 자금융통
function logDoNothing($id, $name, $comName) {
global $AfterName, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
	logOut("${HtagName_}${name}${AfterName}${H_tagName} 으로 ${HtagComName_}${comName}${H_tagComName}을 했습니다.",$id);
}

//  매각
function logSell($id, $name, $comName, $value) {
global $AfterName, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
	logOut("${HtagName_}${name}${AfterName}${H_tagName} 가<B>$value</B>의${HtagComName_}${comName}${H_tagComName}를 실시했습니다",$id);
}

// 원조
function logAid($id, $tId, $name, $tName, $comName, $str) {
global $AfterName, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
	logOut("${HtagName_}${name}${AfterName}${H_tagName} 가${HtagName_}${tName}${H_tagName}에<B>$str</B>의${HtagComName_}${comName}${H_tagComName}를 실시했습니다.",$id, $tId);
}

// 이민 도착
function logRefugees($id, $tId, $name, $tName, $achive) {
global $AfterName, $HunitPop, $HtagName_, $H_tagName;
	logOut("${HtagName_}${name}${AfterName}${H_tagName} 가${HtagName_}${tName}${AfterName}${H_tagName}에<B>$achive${HunitPop}것 이민</B>을 보내 주었습니다.",$id, $tId);
}

// 유치 활동
function logPropaganda($id, $name, $comName) {
global $AfterName, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
	logOut("${HtagName_}${name}${AfterName}${H_tagName} 으로 ${HtagComName_}${comName}${H_tagComName}을 했습니다.",$id);
}

// 방폐
function logGiveup($id, $name) {
global $AfterName, $HtagName_, $H_tagName;
	logOut("${HtagName_}${name}${AfterName}${H_tagName} 는  방폐되어<B>무인${AfterName}</B>가 되었습니다. ",$id);
	logHistory("${HtagName_}${name}${AfterName}${H_tagName},방폐되고<B>무인${AfterName}</B>가 된다.");
}

// 사멸
function logDead($id, $name) {
global $AfterName, $HtagName_, $H_tagName;
	logOut("${HtagName_}${name}${AfterName}${H_tagName} 으로부터 사람이 없어져,<B>무인${AfterName}</B>가 되었습니다.",$id);
	logHistory("${HtagName_}${name}${AfterName}${H_tagName},사람이 없어져<B>무인${AfterName}</B>가 된다.");
}

// 사멸 2
function logDead2($id, $name) {
global $AfterName, $HtagName_, $H_tagName;
	logOut("${HtagName_}${name}${AfterName}${H_tagName} 는 , 특별 룰에 의해,<B>침몰 ${AfterName}</B>했습니다.",$id);
	logHistory("${HtagName_}${name}${AfterName}${H_tagName}, 특별 룰에 의해<B>침몰 ${AfterName}</B>가 된다.");
}

// 기아
function logStarve($id, $name) {
global $AfterName, $HtagName_, $H_tagName, $HtagDisaster_, $H_tagDisaster;
	logOut("${HtagName_}${name}${AfterName}${H_tagName} 의 ${HtagDisaster_}식량이 부족${H_tagDisaster}하고 있습니다!",$id);
}

//---------괴수 관계의 로그---------

// 괴수현
function logMonsCome($id, $name, $mName, $point, $lName) {
global $AfterName, $HtagName_, $H_tagName;
	logOut("${HtagName_}${name}${AfterName}${H_tagName} 에<B>괴수 $mName</B> 출현!${HtagName_}$point${H_tagName} 의 <B>$lName</B>를 밟아 망쳤습니다.",$id);
}
// 괴수현(우주)
function logMonsComeSpace($mName, $point, $lName) {
global $HtagName_, $H_tagName;
	logOut("${HtagName_}${SpaceName}${H_tagName} 에<B> 괴수 $mName</B> 출현! ${HtagName_}$point${H_tagName} 의 <B>$lName</B>가 흔적도 없이 파괴되었습니다.",999);
}

// 괴수현(해역)
function logMonsComeOcean($mName, $point, $lName) {
global $HtagName_, $H_tagName;
	logOut("${HtagName_}${OceanName}${H_tagName} 에<B> 괴수 $mName</B> 출현! ${HtagName_}$point${H_tagName} 의 <B>$lName</B>가 흔적도 없이 파괴되었습니다.",888);
}
// 괴수 도에 공격(해역)
function logMonsMoveOcean($tId, $lName, $point, $mName) {
global $HtagName_, $H_tagName;
	logOut("<B> 괴수 $mName</B> 가 ${HtagName_}${OceanName}$point${H_tagName} 의 <B> $lName</B>에 공격 했습니다.",888,$tId);
}

// 괴수 움직인다(우주, 해역)
function logMonsMoveSpace() {
  $_args = func_get_args();
global $HtagName_, $H_tagName;
	logOut("${HtagName_}{$_args[2]}{$_args[0]}${H_tagName} 의 <B>{$_args[3]}</B> 이<B> 괴수 {$_args[1]}</B>에 흔적도 없이 파괴되었습니다.",$_args[4]);
}
// 괴수 움직이는 2(우주, 해역)
function logMonsMoveSpace2() {
  $_args = func_get_args();
global $HtagName_, $H_tagName;
	logOut("${HtagName_}{$_args[2]}{$_args[0]}${H_tagName} 에<B> 괴수 {$_args[1]}</B>가 이동했습니다.",$_args[3]);
}
// 괴수, 방위 시설을 밟는다(우주)
function logMonsMoveDefenceS($lName, $point, $mName) {
global $HtagName_, $H_tagName;
	logOut("<B>괴수 $mName</B>가 ${HtagName_}${SpaceName}$point${H_tagName} 의 <B>$lName</B>에 도달,<B>${lName} 의  자폭 장치가 작동!</B>",999);
}
// 괴수 지구에 특공(우주)
function logMonsMoveEarth($lName, $point, $mName) {
global $HtagName_, $H_tagName;
	logOut("<B>괴수 $mName</B>가 ${HtagName_}${SpaceName}$point${H_tagName} 의 <B>$lName</B>의 인력의 영향으로 지구로 낙하하여 사라졌습니다",999);
}


// 괴수 움직인다
function logMonsMove($id, $name, $lName, $point, $mName) {
global $AfterName, $HtagName_, $H_tagName;
	logOut("${HtagName_}${name}${AfterName}$point${H_tagName} 의 <B> $lName</B>가<B> 괴수$mName</B>에 밟아 망쳤습니다",$id);
}

// 괴수금 떨어뜨린다
function logMonsMoney($id, $name, $lName, $point, $mName, $result) {
global $AfterName, $HtagName_, $H_tagName;
	logOut("${HtagName_}${name}${AfterName}$point${H_tagName} 의 <B>$lName</B>가<B> 괴수$mName</B>에 밟아 망쳤습니다만,<B>$result</B>를 떨어뜨렸습니다.",$id);
}

// 괴수 정리한 로그
function logMonster($id, $name, $point, $mName, $result) {
global $AfterName, $HtagName_, $H_tagName;
	logOut("${HtagName_}${name}${AfterName}$point${H_tagName} 의 <B>괴수 $mName</B>${result}",$id);
}

// 괴수 파견
function logMonsSend($id, $tId, $name, $tName) {
global $AfterName, $HtagName_, $H_tagName;
	logOut("${HtagName_}${name}${AfterName}${H_tagName} 가<B> 인조 괴수</B>를 건조.${HtagName_}${tName}${AfterName}${H_tagName}에 보내 주었습니다.",$id, $tId);
}

// 괴수 돌연변이
function logMonsC($id, $name, $point, $mName, $afmName) {
global $AfterName, $HtagName_, $H_tagName;
	logOut("${HtagName_}${name}${AfterName}$point${H_tagName} 의 <B>괴수$mName</B>가 오염의 영향으로<B>괴수 $afmName</B에 돌연변이했습니다.",$id);
}

// 괴수, 방위 시설을 밟는다
function logMonsMoveDefence($id, $name, $lName, $point, $mName) {
global $AfterName, $HtagName_, $H_tagName;
	logOut("<B>괴수$mName</B>가${HtagName_}${name}${AfterName}$point${H_tagName} 의 <B>$lName</B>에 도달,<B>${lName} 의  자폭 장치가 작동!</B>",$id);
}
// 괴수, 데스트랩 을 밟는다
function logMonsMoveDeathtrap($id, $name, $lName, $point, $mName, $result) {
global $AfterName, $HtagName_, $H_tagName;
	logOut("<B>괴수$mName</B>가${HtagName_}${name}${AfterName}$point${H_tagName} 의 <B>$lName</B>에 도달,<B>${lName}</B>가 작동해<B>괴수$mName</B>는 ${result}했다!",$id);
}
// 괴수, 데스트랩 을 밟는 효과 없음
function logMonsMoveDeathtrapM($id, $name, $lName, $point, $mName) {
global $AfterName, $HtagName_, $H_tagName;
	logOut("<B>괴수$mName</B>가${HtagName_}${name}${AfterName}$point${H_tagName} 의 <B>$lName</B>에 도달,<B>${lName}</B>가 작동했습니다만<B>괴수$mName</B>는 아무런 피해가 없고 밟아 망쳤습니다!",$id);
}
// 괴수, 자폭
function logMonsZIBAKU($id, $name, $lName, $point, $mName) {
global $AfterName, $HtagName_, $H_tagName;
	logOut("<B>괴수$mName</B>가${HtagName_}${name}${AfterName}$point${H_tagName} 의 <B>$lName</B>에 이동했을 때, 돌연 부풀어서 단번에<B>폭발했습니다!</B>",$id);
}
// 괴수, 식량를 먹는다
function logMonsEAT($id, $name, $lName, $point, $mName) {
global $AfterName, $HtagName_, $H_tagName;
	logOut("<B>괴수$mName</B>가${HtagName_}${name}${AfterName}$point${H_tagName} 의 <B>$lName</B>에 이동했을 때, 무서울 만큼의 흡인력으로 도의 비축 식량의 5%를 들이 마셔 먹어 버렸습니다.",$id);
}

//괴수 조종한다
function logManipulate($id, $tId, $name, $tName, $comName) {
global $AfterName, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
	logOut("${HtagName_}${name}${AfterName}${H_tagName} 가${HtagName_}${tName}${AfterName}${H_tagName} 으로 ${HtagComName_}${comName}${H_tagComName}를 실시했습니다.",$id, $tId);
}

// 괴수 조종하는 스텔스
function logManipulateS($id, $tId, $name, $tName, $comName) {
global $AfterName, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName;
	logSecret("${HtagName_}${name}${AfterName}${H_tagName} 가${HtagName_}${tName}${AfterName}${H_tagName} 으로 ${HtagComName_}${comName}${H_tagComName}를 실시했습니다.",$id, $tId);
	logLate("<B>누군가</B>가${HtagName_}${tName}${AfterName}${H_tagName} 으로 ${HtagComName_}${comName}${H_tagComName}를 실시하고 있는 것 같습니다.",$tId);
}
//-----------여기까지---------------

// 화재
function logFire($id, $name, $lName, $point) {
global $AfterName, $HtagName_, $H_tagName, $HtagDisaster_, $H_tagDisaster;
	logOut("${HtagName_}${name}${AfterName}$point${H_tagName} 의 <B>$lName</B>가${HtagDisaster_}화재${H_tagDisaster}에 의해 괴멸 했습니다.",$id);
}
// 화재를 미리 막는다
function logFireD($id, $name, $lName, $point) {
global $AfterName, $HtagName_, $H_tagName;
	logOut("${HtagName_}${name}${AfterName}$point${H_tagName} 의 <B>$lName</B>로 발화했습니다만, 소방대원의 활약에 의해 화재는 미리 막았습니다.",$id);
}

// 오염
function logOsen($id, $name, $lName, $point) {
global $AfterName, $HtagName_, $H_tagName, $HtagDisaster_, $H_tagDisaster;
	logOut("${HtagName_}${name}${AfterName}$point${H_tagName} 의 <B>$lName</B>가${HtagDisaster_}오염${H_tagDisaster}되고 괴멸 했습니다.",$id);
}

// 슬럼가
function logslum($id, $name, $lName, $point) {
global $AfterName, $HtagName_, $H_tagName, $HtagDisaster_, $H_tagDisaster;
	logOut("${HtagName_}${name}${AfterName}$point${H_tagName} 의 <B>$lName</B>가 빈곤해서 ${HtagDisaster_}슬럼가${H_tagDisaster}로 변화했습니다.",$id);
}

// 매장금

function logMaizo($id, $name, $comName, $value) {
global $AfterName, $HislandTurn, $HunitMoney, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName, $HlogdirName;
	logOut("${HtagName_}${name}${AfterName}${H_tagName}에서의${HtagComName_}$comName${H_tagComName}중에,<B>$value${HunitMoney}의 매장금</B>이 발견되었습니다.",$id);
	// 랭킹용 로그 파일 서두
	hako_open('MOUT',">>${HlogdirName}/money.log");
	hako_write('MOUT', "$HislandTurn,$id,매장금,$value\n");
	hako_close('MOUT');
}

// 금광맥
function logGold($id, $name, $comName, $value) {
global $AfterName, $HislandTurn, $HunitMoney, $HtagName_, $H_tagName, $HtagComName_, $H_tagComName, $HlogdirName;
	logOut("${HtagName_}${name}${AfterName}${H_tagName}에서의${HtagComName_}$comName${H_tagComName}중에 금광맥 발견,<B>$value${HunitMoney}상당한 금</B>이 채굴되었습니다.",$id);
	// 랭킹용 로그 파일 서두
	hako_open('MOUT',">>${HlogdirName}/money.log");
	hako_write('MOUT', "$HislandTurn,$id,매장금,$value\n");
	hako_close('MOUT');
}

// 순금의 비

function logGoldMonu($id, $name, $lName, $arg) {
global $AfterName, $HtagName_, $H_tagName;
	logOut("${HtagName_}${name}${AfterName}${H_tagName} 의 <B>$lName</B>로부터,<B>${arg}</B>억</B>의 금을 획득했습니다",$id);
}

// 지진 발생
function logEarthquake($id, $name, $point) {
global $AfterName, $HtagName_, $H_tagName, $HtagDisaster_, $H_tagDisaster;
	logOut("${HtagName_}${name}${AfterName}${H_tagName} 으로 대규모${HtagDisaster_}지진 ${H_tagDisaster}가 발생! 진원은${HtagName_}$point${H_tagName}부근인 모양.",$id);
}

// 지진 피해
function logEQDamage($id, $name, $lName, $point) {
global $AfterName, $HtagName_, $H_tagName, $HtagDisaster_, $H_tagDisaster;
	logOut("${HtagName_}${name}${AfterName}$point${H_tagName} 의 <B>$lName</B>는 ${HtagDisaster_}지진${H_tagDisaster}에 의해 피해를 받았습니다.",$id);
}

// 지진 괴멸
function logEQDestroy($id, $name, $lName, $point) {
global $HtagName_, $H_tagName, $HtagDisaster_, $H_tagDisaster;
    logOut("${HtagName_}${name}톨$point${H_tagName}의 <B>$lName</B>는 ${HtagDisaster_}지진${H_tagDisaster}에 의해 괴멸 했습니다.",$id);
}

// 식량 부족 피해
function logSvDamage($id, $name, $lName, $point) {
global $AfterName, $HtagName_, $H_tagName;
	logOut("${HtagName_}${name}${AfterName}$point${H_tagName}의 <B>$lName</B>에<B>식량를 요구해 주민이 쇄도</B>.<B>$lName</B는 괴멸 했습니다.",$id);
}

// 해일 붕괴
function logTsunamiDamage($id, $name, $lName, $point, $result) {
global $AfterName, $HtagName_, $H_tagName, $HtagDisaster_, $H_tagDisaster;
	logOut("${HtagName_}${name}${AfterName}$point${H_tagName}의 <B>$lName</B>는 ${HtagDisaster_}해일${H_tagDisaster}에 의해 ${result}했다.",$id);
}

// 태풍 발생
function logTyphoon($id, $name) {
global $AfterName, $HtagName_, $H_tagName, $HtagDisaster_, $H_tagDisaster;
	logOut("${HtagName_}${name}${AfterName}${H_tagName}에${HtagDisaster_}태풍${H_tagDisaster}상륙!",$id);
}

// 태풍 피해
function logTyphoonDamage($id, $name, $lName, $point, $result) {
global $AfterName, $HtagName_, $H_tagName, $HtagDisaster_, $H_tagDisaster;
	logOut("${HtagName_}${name}${AfterName}$point${H_tagName}의 <B>$lName</B> 은 ${HtagDisaster_}태풍${H_tagDisaster} 으로 ${result}",$id);
}

// 적조 피해
function logAkasioDamage($id, $name, $lName, $point) {
global $AfterName, $HtagName_, $H_tagName, $HtagDisaster_, $H_tagDisaster;
	logOut("${HtagName_}${name}${AfterName}$point${H_tagName} 의 <B>$lName</B>는 ${HtagDisaster_}적조${H_tagDisaster} 으로 전멸 했습니다.",$id);
}

// 여러가지 이벤트
function logEvent() {
  $_args = func_get_args();
global $AfterName, $HtagName_, $H_tagName;
	logOut("${HtagName_}{$_args[1]}${AfterName}${H_tagName}{$_args[2]}",$_args[0]);
}
// 여러가지 이벤트
function logEventT() {
  $_args = func_get_args();
global $AfterName, $HtagName_, $H_tagName;
	logOut("${HtagName_}{$_args[2]}${AfterName}${H_tagName}{$_args[3]}",$_args[0],$_args[1]);
}

// 여러가지 이벤트
function logEventP() {
  $_args = func_get_args();
global $AfterName, $HtagName_, $H_tagName;
	logOut("${HtagName_}{$_args[1]}${AfterName}{$_args[2]}${H_tagName}{$_args[3]}",$_args[0]);
}

// 여러가지 이벤트 2
function logEvent2($id, $name, $result, $result2) {
global $AfterName, $HtagName_, $H_tagName, $HtagDisaster_, $H_tagDisaster;
	logOut("${HtagName_}${name}${AfterName}${H_tagName} 으로 ${HtagDisaster_}${result}${H_tagDisaster}${result2}.",$id);
}

// 우주 재해 이벤트(우주)
function logSpaceDisEvent() {
  $_args = func_get_args();
global $HtagName_, $H_tagName;
	logOut("${HtagName_}${SpaceName}{$_args[1]}${H_tagName}의 <B>{$_args[2]}</B>{$_args[3]}",$_args[0],999);
}
// 우주 이벤트(우주)
function logSpaceEvent() {
  $_args = func_get_args();
global $HtagName_, $H_tagName;
	logOut("${HtagName_}${SpaceName}${H_tagName}{$_args[0]}",999);
}

// 운석, 막는다
function logMeteoD($id, $name, $lName, $point, $kind) {
global $AfterName, $HtagName_, $H_tagName, $HtagDisaster_, $H_tagDisaster;
	logOut("${HtagName_}${name}${AfterName}$point${H_tagName} 의 <B>$lName</B>에${HtagDisaster_}${kind}${H_tagDisaster} 가 낙하했습니다만, 안보이는 힘에 의해 공중 폭발했습니다.",$id);
}

// 운석, 바다
function logMeteoSea($id, $name, $lName, $point) {
global $AfterName, $HtagName_, $H_tagName, $HtagDisaster_, $H_tagDisaster;
	logOut("${HtagName_}${name}${AfterName}$point${H_tagName} 의 <B>$lName</B>에${HtagDisaster_}운석${H_tagDisaster} 가 낙하했습니다.",$id);
}

// 운석, 산
function logMeteoMountain($id, $name, $lName, $point) {
global $AfterName, $HtagName_, $H_tagName, $HtagDisaster_, $H_tagDisaster;
	logOut("${HtagName_}${name}${AfterName}$point${H_tagName} 의 <B>$lName</B>에${HtagDisaster_}운석${H_tagDisaster} 가 낙하,<B>$lName</B>는 날아가 버렸습니다.",$id);
}

// 운석, 해저 기지
function logMeteoSbase($id, $name, $lName, $point) {
global $AfterName, $HtagName_, $H_tagName, $HtagDisaster_, $H_tagDisaster;
	logOut("${HtagName_}${name}${AfterName}$point${H_tagName} 의 <B>$lName</B>에${HtagDisaster_}운석${H_tagDisaster} 가 낙하,<B>$lName</B>는 붕괴했습니다. ",$id);
}

// 운석, 괴수
function logMeteoMonster($id, $name, $lName, $point) {
global $AfterName, $HtagName_, $H_tagName, $HtagDisaster_, $H_tagDisaster;
	logOut("<B>괴수$lName</B>가 있던${HtagName_}${name}${AfterName}$point${H_tagName}지점에${HtagDisaster_}운석${H_tagDisaster} 가 낙하, 육지는<B>괴수$lName</B>와 수몰 했습니다.",$id);
}

// 운석, 얕은 여울
function logMeteoSea1($id, $name, $lName, $point) {
global $AfterName, $HtagName_, $H_tagName, $HtagDisaster_, $H_tagDisaster;
	logOut("${HtagName_}${name}${AfterName}$point${H_tagName}지점에${HtagDisaster_}운석${H_tagDisaster} 가 낙하, 해저가 꾸물거려졌습니다.",$id);
}

// 운석, 그 외
function logMeteoNormal($id, $name, $lName, $point) {
global $AfterName, $HtagName_, $H_tagName, $HtagDisaster_, $H_tagDisaster;
	logOut("${HtagName_}${name}${AfterName}$point${H_tagName}지점의<B>$lName</B>에${HtagDisaster_}운석${H_tagDisaster} 가 낙하, 일대가 수몰 했습니다.",$id);
}

// 운석, 그 외
function logHugeMeteo($id, $name, $point) {
global $AfterName, $HtagName_, $H_tagName, $HtagDisaster_, $H_tagDisaster;
	logOut("${HtagName_}${name}${AfterName}$point${H_tagName}지점에${HtagDisaster_}거대 운석${H_tagDisaster} 가 낙하!",$id);
}

// 분화
function logEruption($id, $name, $lName, $point, $erup) {
global $AfterName, $HtagName_, $H_tagName, $HtagDisaster_, $H_tagDisaster;
	logOut("${HtagName_}${name}${AfterName}$point${H_tagName}지점에서${HtagDisaster_}화산이$erup${H_tagDisaster},<B>$lName</b>가 <B>산</B>이 되었습니다.",$id);
}

// 분화, 얕은 여울
function logEruptionSea1($id, $name, $lName, $point) {
global $AfterName, $HtagName_, $H_tagName, $HtagDisaster_, $H_tagDisaster;
	logOut("${HtagName_}${name}${AfterName}$point${H_tagName}지점의<B>$lName</B>는,${HtagDisaster_}분화${H_tagDisaster} 의  영향으로 육지가 되었습니다.",$id);
}

// 분화, 바다 or해기
function logEruptionSea($id, $name, $lName, $point) {
global $AfterName, $HtagName_, $H_tagName, $HtagDisaster_, $H_tagDisaster;
	logOut("${HtagName_}${name}${AfterName}$point${H_tagName}지점의<B>$lName</B>는,${HtagDisaster_}분화${H_tagDisaster} 의  영향으로 해저가 융기, 얕은 여울이 되었습니다.",$id);
}

// 분화, 그 외
function logEruptionNormal($id, $name, $lName, $point) {
global $AfterName, $HtagName_, $H_tagName, $HtagDisaster_, $H_tagDisaster;
	logOut("${HtagName_}${name}${AfterName}$point${H_tagName}지점의<B>$lName</B>는,${HtagDisaster_}분화${H_tagDisaster} 의  영향으로 괴멸 했습니다.",$id);
}

// 지반침하 발생
function logFalldown($id, $name) {
global $AfterName, $HtagName_, $H_tagName, $HtagDisaster_, $H_tagDisaster;
	logOut("${HtagName_}${name}${AfterName}${H_tagName} 으로 ${HtagDisaster_}지반침하${H_tagDisaster} 가 발생했습니다!",$id);
}

// 지반침하 피해
function logFalldownLand($id, $name, $lName, $point) {
global $AfterName, $HtagName_, $H_tagName;
	logOut("${HtagName_}${name}${AfterName}$point${H_tagName} 의 <B>$lName</B>는 바다 속에 가라앉았습니다.",$id);
}

// 지반침하 피해 온천

function logFalldownLandO($id, $name, $lName, $point) {
global $AfterName, $HtagName_, $H_tagName;
	logOut("${HtagName_}${name}${AfterName}$point${H_tagName} 의 <B>$lName</B>는 바다 속에 가라앉았습니다.",$id);
}

// 광역 피해, 수몰
function logWideDamageSea($id, $name, $lName, $point) {
global $AfterName, $HtagName_, $H_tagName;
	logOut("${HtagName_}${name}${AfterName}$point${H_tagName} 의 <B>$lName</B>는<B>수몰</B>했습니다.",$id);
}

// 광역 피해, 바다의 건설
function logWideDamageSea2($id, $name, $lName, $point) {
global $AfterName, $HtagName_, $H_tagName;
	logOut("${HtagName_}${name}${AfterName}$point${H_tagName} 의 <B>$lName</B>는 흔적도 없어졌습니다.",$id);
}

// 광역 피해, 괴수 수몰
function logWideDamageMonsterSea($id, $name, $lName, $point) {
global $AfterName, $HtagName_, $H_tagName;
	logOut("${HtagName_}${name}${AfterName}$point${H_tagName} 의  육지는<B>괴수$lName</B>와도 수몰 했습니다.",$id);
}

// 광역 피해, 괴수
function logWideDamageMonster($id, $name, $lName, $point) {
global $AfterName, $HtagName_, $H_tagName;
	logOut("${HtagName_}${name}${AfterName}$point${H_tagName} 의 <B>괴수$lName</B>는 날아가 버렸습니다.",$id);
}

// 광역 피해, 황무지
function logWideDamageWaste($id, $name, $lName, $point) {
global $AfterName, $HtagName_, $H_tagName;
	logOut("${HtagName_}${name}${AfterName}$point${H_tagName} 의 <B>$lName</B>는 한순간에<B>황무지</B>화했습니다.",$id);
}
// 광역 피해, 오염
function logWideDamageOsen($id, $name, $lName, $point) {
global $AfterName, $HtagName_, $H_tagName;
	logOut("${HtagName_}${name}${AfterName}$point${H_tagName} 의 <B>$lName</B>는 방사능으로<B>오염</B>했습니다.",$id);
}
// 광역 피해(우주)
function logWideDamageSpace() {
  $_args = func_get_args();
global $HtagName_, $H_tagName;
	logOut("${HtagName_}${SpaceName}{$_args[1]}${H_tagName} 의 <B>{$_args[0]}</B>은 한순간에<B>{$_args[2]}</B>가 되었습니다.",999);
}
// 수상
function logPrize($id, $name, $pName) {
global $AfterName, $HtagName_, $H_tagName;
	logOut("${HtagName_}${name}${AfterName}${H_tagName} 가<B>$pName</B>을 수상했습니다.",$id);
	logHistory("${HtagName_}${name}${AfterName}${H_tagName},<B>$pName</B>을 수상");
}
// 부문상 수상
function logPrizeV($id, $name, $pName) {
global $AfterName, $HislandTurn, $HtagName_, $H_tagName, $HlogdirName;
	logOut("${HtagName_}${name}${AfterName}${H_tagName} 가<B>$pName</B>을 수상했습니다.",$id);
	
	//랭킹용 로그 파일 서두
	hako_open('MOUT',">>${HlogdirName}/bumon.log");
	hako_write('MOUT', "$HislandTurn,$id,$pName,$name\n");
	hako_close('MOUT');
}

// 지형의 부르는 법
function landName($land, $lv) {
global $AfterName, $HidToName, $HlandAirport, $HlandAmusement, $HlandBank, $HlandBase, $HlandBigcity, $HlandBreakwater, $HlandCasino, $HlandDeathtrap, $HlandDefence, $HlandDokan,
       $HlandDome, $HlandEarth, $HlandExpo, $HlandFactory, $HlandFarm, $HlandFire, $HlandFlower, $HlandForest, $HlandFuji, $HlandHaribote, $HlandHospital, $HlandHugecity,
       $HlandKInora, $HlandMegacity, $HlandMegaFact, $HlandMegaFarm, $HlandMegatower, $HlandMonster, $HlandMonument, $HlandMountain, $HlandMyhome, $HlandOil, $HlandOsen,
       $HlandPark, $HlandPirate, $HlandPlains, $HlandPolice, $HlandPort, $HlandSAEisei, $HlandSbase, $HlandSchool, $HlandSCity, $HlandSDefence, $HlandSea, $HlandSeisei,
       $HlandSFactory, $HlandSFarm, $HlandSlum, $HlandSMonument, $HlandSpaceBase, $HlandStadium, $HlandSunit, $HlandTcity, $HlandTower, $HlandTown, $HlandTrump, $HlandWarp,
       $HlandWarpR, $HlandWaste, $HlandWindmill, $HlandZoo, $HmonumentName, $HseaChk, $HsEisei, $HshipName, $HsmonumentName;
	if($land == $HlandSea){
		if($lv >= 10){
			return '양식장';
		}elseif($lv == 1){
			return '얇은 여울';
		}else{
			return '바다';
		}
	}elseif($land == $HlandWaste){
		return ($lv >= 10) ? '온천' : '황무지';
	}elseif($land == $HlandPlains){
		return '평지';
	}elseif($land == $HlandTown){
		if($lv < 30){
			return '마을';
		}elseif($lv < 100){
			return '마을';
		}else{
			return '도시';
		}
	}elseif($land == $HlandSlum){
		return '슬럼가';
	}elseif($land == $HlandForest){
		return '숲';
	}elseif($land == $HlandFarm){
		return '농장';
	}elseif($land == $HlandFactory){
		return '공장';
	}elseif($land == $HlandTower){
		return '상업 빌딩';
	}elseif($land == $HlandBase){
		return '미사일 기지';
	}elseif($land == $HlandDefence){
		if($lv == 2){
			return 'S방위 시설';
		}elseif($lv == 3){
			return 'SS방위 시설';
		}elseif($lv == 10){
			return 'ST방위 시설';
		}elseif($lv == 11){
			return 'SST 방위 시설';
		}elseif($lv == 20){
			return '안개 첨부 방위 시설';
		}elseif($lv == 21){
			return 'S안개 첨부 방위 시설';
		}else{
			return '방위 시설';
		}
	}elseif($land == $HlandMountain){
		return '산';
	}elseif($land == $HlandMonster){
		return hako_pick(monsterSpec($lv), array(1));
	}elseif($land == $HlandSbase){
		return '해저 기지';
	}elseif($land == $HlandOil){
		if($lv == 5){
			return '해저 방위 시설';
		}elseif($lv == 6){
			return '해저 데스트랩 ';
		}elseif($lv == 7){
			return '해저 소방서';
		}elseif($lv >= 35){
			return '해저 도시';
		}elseif($lv >= 10){
			return '해저 농장';
		}else{
			return '해저 유전';
		}
	}elseif($land == $HlandDeathtrap){
		return '데스트랩 ';
	}elseif($land == $HlandWindmill){
		return '풍차';
	}elseif($land == $HlandMyhome){
		return '마이 홈';
	}elseif($land == $HlandPort){
		return '항구';
	}elseif($land == $HlandPolice){
		return '경찰서';
	}elseif($land == $HlandHospital){
		return '병원';
	}elseif($land == $HlandFlower){
		if($lv == 13){
			return '선인장';
		}else{
			return '꽃';
		}
	}elseif($land == $HlandDokan){
		return '입구';
	}elseif($land == $HlandTrump){
		if(($lv < 1) || ($lv > 14)){
			return "트럼프 뒤";
		}else{
			if($lv == 14){
				return "트럼프 조커";
			}else{
				return "트럼프${lv}";
			}
		}
	}elseif($land == $HlandSeisei){
		if($lv == 10){
			return '동 정제장';
		}elseif($lv == 30){
			return '금 정제장';
		}else{
			return '석탄 정제장';
		}
	}elseif($land == $HlandMegacity){
		if($lv == 1){
			return '거대 도시◎남서';
		}elseif($lv == 2){
			return '거대 도시◎서쪽';
		}elseif($lv == 3){
			return '거대 도시◎북서';
		}elseif($lv == 4){
			return '거대 도시◎북동';
		}elseif($lv == 5){
			return '거대 도시◎동쪽';
		}elseif($lv == 6){
			return '거대 도시◎남동';
		}else{
			return '거대 도시';
		}
	}elseif($land == $HlandMegatower){
		if($lv == 1){
			return '거대 빌딩◎남서';
		}elseif($lv == 2){
			return '거대 빌딩◎서쪽';
		}elseif($lv == 3){
			return '거대 빌딩◎북서';
		}elseif($lv == 4){
			return '거대 빌딩◎북동';
		}elseif($lv == 5){
			return '거대 빌딩◎동쪽';
		}elseif($lv == 6){
			return '거대 빌딩◎남동';
		}else{
			return '거대 빌딩';
		}
	}elseif($land == $HlandMegaFact){
		if($lv == 1){
			return '거대 공장◎남서';
		}elseif($lv == 2){
			return '거대 공장◎서쪽';
		}elseif($lv == 3){
			return '거대 공장◎북서';
		}elseif($lv == 4){
			return '거대 공장◎북동';
		}elseif($lv == 5){
			return '거대 공장◎동쪽';
		}elseif($lv == 6){
			return '거대 공장◎남동';
		}else{
			return '거대 공장';
		}
	}elseif($land == $HlandMegaFarm){
		if($lv == 1){
			return '거대 농장◎남서';
		}elseif($lv == 2){
			return '거대 농장◎서쪽';
		}elseif($lv == 3){
			return '거대 농장◎북서';
		}elseif($lv == 4){
			return '거대 농장◎북동';
		}elseif($lv == 5){
			return '거대 농장◎동쪽';
		}elseif($lv == 6){
			return '거대 농장◎남동';
		}else{
			return '거대 농장';
		}
	}elseif($land == $HlandHugecity){
		if($lv < 50){
			return '초 거대 도시(중심)';
		}elseif($lv < 60){
			return '초 거대 도시 (도시)';
		}elseif($lv < 70){
			return '초 거대 도시(공장)';
		}elseif($lv < 80){
			return '초 거대 도시(상업)';
		}else{
			return '초 거대 도시(농장)';
		}
	}elseif($land == $HlandFuji){
		return '후지산';
	}elseif($land == $HlandTcity){
		return '상업 도시';
	}elseif($land == $HlandMonument){
		return $HmonumentName[$lv];
	}elseif($land == $HlandSMonument){
		return $HsmonumentName[$lv];
	}elseif($land == $HlandHaribote){
		return ($lv == 0) ? '위장 방위 시설' : hako_pick(monsterSpec($lv), array(1));
	}elseif($land == $HlandOsen){
		return '오염 토양';
	}elseif($land == $HlandBank){
		return '은행';
	}elseif($land == $HlandStadium){
		return '스타디움';
	}elseif($land == $HlandAmusement){
		return '유원지';
	}elseif($land == $HlandCasino){
		return '카지노';
	}elseif($land == $HlandPark){
		return '공원';
	}elseif($land == $HlandSchool){
		return '학교';
	}elseif($land == $HlandDome){
		return '돔';
	}elseif($land == $HlandAirport){
		return '공항';
	}elseif($land == $HlandZoo){
		return '동물원';
	}elseif($land == $HlandBigcity){
		return '대도시';
	}elseif($land == $HlandExpo){
		return '박람회';
	}elseif($land == $HlandWarp){
		return '전이 장치';
	}elseif($land == $HlandWarpR){
		return '전이 지정 장치';
	}elseif($land == $HlandBreakwater){
		return '방파제';
	}elseif($HseaChk[$land] == 2){
		// 배계
		$sId = hako_pick(shipSpec($lv), array(2));
		if($sId > 0){
			return $HshipName[$land - $HlandPirate] . "({$HidToName[$sId]}${AfterName}소속)";
		}else{
			return $HshipName[$land - $HlandPirate];
		}
	}elseif($land == $HlandFire){
		return ($lv >= 10) ? 'S소방서' : '소방서';
	}elseif($land == $HlandKInora){
		return '구상 이노라';
	}elseif($land == $HlandEarth){
		return '지구';
	}elseif($land == $HlandSunit){
		if($lv == 20){
			return '우주 파괴 유니트';
		}elseif($lv == 1){
			return '우주 건설중 유니트';
		}elseif($lv == 10){
			return '우주 유니트';
		}else{
			return '우주 기초 유니트';
		}
	}elseif($land == $HlandSCity){
		if($lv < 30){
			return '우주 마을';
		}elseif($lv < 100){
			return '우주 마을';
		}else{
			return '우주 도시';
		}
	}elseif($land == $HlandSFarm){
		return '우주 농장';
	}elseif($land == $HlandSFactory){
		return '우주 공장';
	}elseif($land == $HlandSAEisei){
		return $HsEisei[intval($lv / 1000)]; # 우주 위성
	}elseif($land == $HlandSpaceBase){
		return '우주 미사일 기지';
	}elseif($land == $HlandSDefence){
		return '우주 방위 시설';
	}
}
// 우주의 계산
function spaceEstimate($mode) {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $H_tagName2, $Haidpop, $Hallyflg, $Hallygroup, $haribote, $Hatkturn, $HbackupTimes, $HbackupTurn, $HbgInfoCell, $HbgTitleCell, $HbigcityFood, $HbigCityMFlg, $HcomBank, $HcomBase, $HcomBioMissile, $HcomBreakwater, $Hcomcolony, $HcomcolonyTurn, $HcomCost, $HcomDbase, $HcomDeathtrap, $HcomDestroy, $HcomDestroy2, $HcomDokan, $HcomDoNothing, $HcomDummy, $HcomEmigration, $HcomFactory, $HcomFarm, $HcomFire, $HcomFlower, $HcomFood, $HcomGiveup, $HcomHaribote, $HcomHospital, $HcomL, $HcommandMax, $HcomManipulate, $HcomMissileDM, $HcomMissileGM, $HcomMissileLD, $HcomMissileMGM, $HcomMissileNCM, $HcomMissileNM, $HcomMissilePLD, $HcomMissilePP, $HcomMissileRM, $HcomMissileRNG, $HcomMissileSPP, $HcomMissileSRM, $HcomMissileST, $HcomMoney, $HcomMonsAid, $HcomMonsEgg, $HcomMonsEnsei, $HcomMonsEsa, $HcomMonsEsaAid, $HcomMonsExer, $HcomMonsSell, $HcomMonsTettai, $HcomMonument, $HcomMountain, $HcomMyhome, $HcomName, $HcomOilBuy, $HcomOilSell, $HcomOMissileMGM, $HcomOMissileNM, $HcomOMissilePP, $HcomOMissileSPP, $HcomOreBuy, $HcomOreSell, $HcomPioneer, $HcomPlant, $HcomPolice, $HcomPort, $HcomPrepare, $HcomPrepare2, $HcomPresent, $HcomPresentAid, $HcomPropaganda, $HcomReclaim, $HcomReclaim2, $HcomSbase, $HcomSBuild, $HcomScity, $HcomSDbase, $HcomSDestroy, $HcomSearch, $HcomSEisei, $HcomSell, $HcomSellTree, $HcomSendMonster, $HcomSendMonsterTurn, $HcomSFactory, $HcomSFarm, $HcomSFood, $HcomShip, $HcomShipbuild, $HcomShipM, $HcomShipSell, $HcomSMissile, $HcomSMissileGM, $HcomSMissileMGM, $HcomSMissilePP, $HcomSMonument, $HcomSOccupy, $HcomSpaceBase, $HcomSpaceFarm, $HcomSpecialSPP, $HcomSPioneer, $HcomSpy, $HcomSSendMonster, $HcomSSendMonsterTurn, $HcomSTManipulate, $HcomSUnit, $HcomTeisatu, $HcomTower, $HcomTrump, $HcomUg, $HcomWarp, $HcomWeponBuy, $HcomWeponSell, $HcomWindmill, $HconsolationMatch, $HcurrentNumber, $HdBaseAuto, $HdefenceHex, $HdefenceSpace, $HdevelopeTurn, $HdirMode, $HdirName, $HdisAEruption, $HdisAkasio, $HdisBHarvest, $HdisCrime, $HdisEarthquake, $HdisEruption, $HdisFallBorder, $HdisFalldown, $HdisFire, $HdisGHarvest, $Hdishangen, $HdisHugeMeteo, $HdisKLimit, $HdisMaizo, $HdisMeteo, $HdisMonsBorder1, $HdisMonsBorder2, $HdisMonsBorder3, $HdisMonsBorder4, $HdisMonsBorder5, $HdisMonster, $HdisMonsterU, $HdisPirate, $HdisPollution, $HdisSeaMonster, $HdisSHugeMeteo, $HdisSpaceMonster1, $HdisSpaceMonster2, $HdisTinka, $HdisTreasureS, $HdisTsunami, $HdisTyphoon, $HdisUN, $HdisVGHarvest, $HearthAttack, $HeatenFood, $helpDir, $HfightMem, $HfightTurn, $HfinalTurn, $HgiveupTurn, $HhistoryMax, $HidToName, $HidToNumber, $HidToNumberR, $HinterTime, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HlandAegisShip, $HlandAirport, $HlandAmusement, $HlandBalloonS, $HlandBank, $HlandBase, $HlandBigcity, $HlandBreakwater, $HlandCasino, $HlandCoupleRock, $HlandDeathtrap, $HlandDefence, $HlandDokan, $HlandDome, $HlandEarth, $HlandExpo, $HlandFactory, $HlandFarm, $HlandFire, $HlandFishLShip, $HlandFishMShip, $HlandFishSShip, $HlandFlower, $HlandForest, $HlandFuji, $HlandGhostShip, $HlandHaribote, $HlandHospital, $HlandHugecity, $HlandIceFloe, $HlandKInora, $HlandMegacity, $HlandMegaFact, $HlandMegaFarm, $HlandMegatower, $HlandMonsShip, $HlandMonster, $HlandMonument, $HlandMountain, $HlandMyhome, $HlandOcean, $HlandOil, $HlandOPlayer, $HlandOsen, $HlandPark, $HlandPirate, $HlandPlains, $HlandPolice, $HlandPort, $HlandProbeShip, $HlandSAEisei, $HlandSbase, $HlandSchool, $HlandSCity, $HlandSDefence, $HlandSea, $HlandSeisei, $HlandSFactory, $HlandSFarm, $HlandSlum, $HlandSMonument, $HlandSpaceBase, $HlandStadium, $HlandSunit, $HlandTcity, $HlandTitanic, $HlandTower, $HlandTown, $HlandTreasureS, $HlandTrump, $HlandWarp, $HlandWarpR, $HlandWaste, $HlandWindmill, $HlandWingDragon, $HlandZoo, $HlateLogPool, $HlogMax, $HlogOmit2, $HlogPool, $HmaxdisPollution, $HmaxExpPoint, $HmaxIsland, $HmonsBtlMaxHp, $HmonsBtlMaxPa, $HmonsterAGI, $HmonsterBHP, $HmonsterCLS, $HmonsterDEF, $HmonsterDestroy, $HmonsterDHP, $HmonsterExp, $HmonsterGRP, $HmonsterL1, $HmonsterL1Num, $HmonsterL2, $HmonsterL2Num, $HmonsterL3, $HmonsterL3Num, $HmonsterL4, $HmonsterL4Num, $HmonsterL5, $HmonsterL5Num, $HmonsterName, $HmonsterNumber, $HmonsterS, $HmonsterSEI, $HmonsterSKL, $HmonsterSP, $HmonsterSpecial, $HmonsterSTR, $HmonsterValue, $Hmonth, $HmonumentMissile, $HmonumentName, $HmonumentRocket, $Hocean, $HoceanSize, $HoilMoney, $HoilRatio, $hp, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $Hprize, $HprizeV, $HpunishInfo, $HrepeatTurn, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $HseaChk, $HsecretLogPool, $HsEisei, $HshipEX, $HshipFood, $HshipHP, $HshipKAI, $HshipMATK, $HshipMoney, $HshipName, $Hshiporder, $HshipSATK, $HshipSell, $HshipSP, $HsmonumentName, $HsmonumentNumber, $Hsolarwind, $Hspace, $HspaceEfficiency, $HspaceIncome, $Hsstartturn, $HStotalPoint, $HsurvFlg, $Hsurvivalturn, $HtagName2_, $HthisFile, $HtotalBumon, $HtotalMoney, $HtotalPoint, $Htournament, $HtreeValue, $HturnPrizeNumber, $HturnPrizePoint, $HturnPrizeUnit, $HturnPrizeVarious, $HugDokan, $HugFact, $HugFarm, $HugHasigo, $HugKiti, $HugMax, $HugOil, $HugRoad, $HugSpace, $HugTosi, $human, $HunitFood, $HunitMoney, $HunitOil, $HunitOre, $HunitPop, $HunitTime, $HunitWeapon, $HwarFlg, $HWeatherMax, $Hwflg, $HwinFood, $HwinIsland, $HwinMoney, $HwinWeapon, $imageDir, $lockMode, $toppage, $versionInfo;
	$land =& $Hspace['land']; $landValue =& $Hspace['landValue']; $dis =& $Hspace['landValue2']; $nation =& $Hspace['nation'];
	list($pop, $area, $farm, $factory) = array(0,0,0,0);
	$x = null; $y = null; $kind = null; $value = null; $id = null;
	if($mode == 0){
		// 태양풍
		$Hsolarwind = 0;
		if($Hspace['solarwind'] < 10){
			$Hspace['solarwind'] = $HislandTurn + random(30) + 30;
		}elseif($Hspace['solarwind'] < $HislandTurn - 8){
//			HdebugOut("태양풍 8 턴 경과:" . $Hspace['solarwind']);
			if(random(5) == 0){
				// 태양풍 종료
				logSpaceEvent("로 태양풍이 사라졌습니다.");
				$Hspace['solarwind'] = $HislandTurn + random(30) + 30;
			}else{
				$Hsolarwind = 1;
			}
		}elseif($Hspace['solarwind'] <= $HislandTurn){
//			HdebugOut("태양풍 발생중:" . $Hspace['solarwind']);
			$Hsolarwind = 1;
//			logSpaceEvent("로 태양풍이 격렬하게 불어 거칠어지고 있습니다. 사라질 때까지 일절의 우주 개발을 할 수 없습니다.");
		}
	}
	for($y = 0; $y < $HislandSize; $y++){
		for($x = 0; $x < $HislandSize; $x++){
			$kind = $land[$x][$y];
			$value = $landValue[$x][$y];
			$id = $nation[$x][$y];
			if(($kind == $HlandSea) || ($kind == $HlandEarth)){
				$nation[$x][$y] = 0;
				$dis[$x][$y] = 0;
			}else{
				$area++;
			}
			$tn = $HidToNumber[$id];
			if ($tn == '') { $nation[$x][$y] = 0; }
			$island =& $Hislands[$tn];
			
			if(($mode == 1) && ($Hsolarwind == 0)){
				//  후 처리
				$di = 0;
				$tName = $island['name'];
				if($tn != ''){
					$spop = intval($island['spop']);
					if($island['pop'] < $spop * 3){
						$di = 7;
					}elseif($island['pop'] < $spop * 4){
						$di = 3;
					}elseif($island['pop'] < $spop * 5){
						$di = 1;
					}elseif($spop < 1){
						$di = 3;
					}
					if($island['sfarm'] != 1){
						$di += 4;
					}
					if($island['comsfood']){
						$di -= 6;
					}
					$damage = $island['oldPop'] - ($island['pop'] + $island['displus']);
					if($damage >= 3000){
						$di += 24;
					}elseif($damage >= 1000){
						$di += 18;
					}elseif($damage >= 400){
						$di += 12;
					}elseif($damage >= 200){
						$di += 8;
					}elseif($damage >= 70){
						$di += 4;
					}elseif($damage >= 30){
						$di += 2;
					}elseif($damage > -50){
						$di -= 3;
					}elseif($damage > -100){
						$di -= 6;
					}elseif($damage > -200){
						$di -= 10;
					}else{
						$di -= 15;
					}
					if($id == $island['id']){
						$dis[$x][$y] += $di;
					}
				}
//				HdebugOut("인구 지상 우주 비교 (${di})(" . $island['oldPop'] . ")(" . $island['pop'] . ")(" . $island['spop'] . ")${tName}${AfterName}") if($tn ne '');
			}
			
			if(($island['dead'] == 1) || ($island['pop'] <= 0)){
				// 방폐했을 때, 종주도이 멸망했을 때
				$tn = "";
				$nation[$x][$y] = 0;
				$dis[$x][$y] -= 30;
				if ($dis[$x][$y] < 0) { $dis[$x][$y] = 0; }
			}
			
			if($kind == $HlandSCity){
				if ($value > 200) { $value = 200; }
				$pop += $value;
				if($tn != ''){
					// 우주의 인구도 수치만 도 사람구에 더하는, 노동력이라든지가 되지 않는다)
					if($mode == 1){
						// 종료 처리
//						HdebugOut("종료 처리 인구 계산");
						$island['popspace'] += $value;
					}else{
						// 개시 처리
//						HdebugOut("개시 처리 인구 계산");
						$island['spop'] += $value;
						$island['spop2'] += $value * $HspaceEfficiency;
					}
					$island['spa'] += $value + 20;
				}else{
					$nation[$x][$y] = 0;
				}
			}elseif($kind == $HlandSunit){
				if($mode == 0){
					// 마음대로 건설이 진행된다
					if($landValue[$x][$y] == 0){
						$landValue[$x][$y] = 1;
					}elseif($landValue[$x][$y] == 20){
					}else{
						$landValue[$x][$y] = 10;
					}
				}
				if ($tn != '') { $island['spa'] += 20; }
			}elseif($kind == $HlandSFarm){
				$farm += $value;
				if($tn != ''){
					$island['sfarm'] = 1;
					$island['spa'] += $value * 5;
				}else{
					$nation[$x][$y] = 0;
				}
			}elseif($kind == $HlandSFactory){
				$factory += $value;
				if($tn != ''){
					$island['sfactory'] = 1;
					$island['spa'] += $value * 5;
				}else{
					$nation[$x][$y] = 0;
				}
			}elseif(($kind == $HlandSAEisei) && ($Hsolarwind == 0)){
				// 우주 위성
				if($tn != ''){
					$island['spa'] += ($value % 1000) * 2;
					$nkind = 'eis' . intval($value / 1000);
					$island[$nkind] = 1;
				}else{
					$nation[$x][$y] = 0;
				}
			}elseif($kind == $HlandSpaceBase){
				if ($tn != '') { $island['spa'] += 150; }
			}elseif($kind == $HlandSDefence){
				if ($tn != '') { $island['spa'] += 120; }
			}elseif($kind == $HlandMonster){
				$island['spacemonster']++;
			}
			
			// 이상치에 정상적인 값을 대입
			if($land[$x][$y] == $HlandMonster){
				if($landValue[$x][$y] > 4000){
					$land[$x][$y] = $HlandSunit;
					$landValue[$x][$y] = 10;
					$dis[$x][$y] = 0;
					$nation[$x][$y] = 0;
				}
			}elseif($landValue[$x][$y] > 500 && $land[$x][$y] != $HlandSAEisei){
				$land[$x][$y] = $HlandSunit;
				$landValue[$x][$y] = 10;
				$dis[$x][$y] = 0;
				$nation[$x][$y] = 0;
			}
			if($dis[$x][$y] < 0){
				$dis[$x][$y] = 0;
			}elseif($dis[$x][$y] > 200){
				$dis[$x][$y] = 200;
			}
		}
	}
	$Hspace['area']	= $area;
	$Hspace['pop']	= $pop;
	$Hspace['farm']	= $farm;
	$Hspace['factory']= $factory;
	
	if($mode == 0){
		// 초기 처리
		// 생산과 소비
		$Hspace['foodP'] = $farm * 10;
		$Hspace['foodC'] = intval($pop * $HeatenFood);
		$Hspace['food'] += $Hspace['foodP'];
		// 식량 소비
		$Hspace['food'] -= $Hspace['foodC'];
	}else{
		// 식량가 흘러넘치고 있으면 컷 한다
		if($Hspace['food'] > $MaxFood){
			$Hspace['food'] = $MaxFood;
		}
		$idx = range(0, count($Hislands) - 1);
		usort($idx, function($a, $b) { global $Hislands, $rekidai, $HtotalPoint, $HtotalMoney, $HtotalBumon, $HStotalPoint, $DATA, $LandCount, $LandCount2, $allyPop; $c = hako_cmp($Hislands[$b]['spa'], $Hislands[$a]['spa']); return ($c != 0) ? $c : hako_cmp($a, $b); });
		$tIsland =& $Hislands[$idx[0]];
		if($tIsland['spa'] > 0){
			if(($HislandTurn % $HturnPrizeVarious) == 0){
				// 부문상 우주왕
				$tIsland['status'] |= 4096;
				$tIsland['zyuni'] += $HturnPrizePoint;
				logPrizeV($tIsland['id'], $tIsland['name'], $HprizeV[13]);
			}
			$space = null; $i = null;
			for($i = 0;$i <= (count($Hislands) - 1);$i++){
				array_push($space, $Hislands[$idx[$i]]['id']);
				array_push($space, $Hislands[$idx[$i]]['spa']);
			}
//			HdebugOut("{$space[0]},{$space[1]},{$space[2]},{$space[3]},{$space[4]},{$space[5]},{$space[6]},{$space[7]},{$space[8]},{$space[9]}");
			$Hspace['space'] = "{$space[0]},{$space[1]},{$space[2]},{$space[3]},{$space[4]},{$space[5]},{$space[6]},{$space[7]},{$space[8]},{$space[9]}";
		}else{
			$Hspace['space'] = 0;
		}
	}
}

// 우주 성장 및 단헥스 재해
function spaceHex() {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $H_tagName2, $Haidpop, $Hallyflg, $Hallygroup, $haribote, $Hatkturn, $HbackupTimes, $HbackupTurn, $HbgInfoCell, $HbgTitleCell, $HbigcityFood, $HbigCityMFlg, $HcomBank, $HcomBase, $HcomBioMissile, $HcomBreakwater, $Hcomcolony, $HcomcolonyTurn, $HcomCost, $HcomDbase, $HcomDeathtrap, $HcomDestroy, $HcomDestroy2, $HcomDokan, $HcomDoNothing, $HcomDummy, $HcomEmigration, $HcomFactory, $HcomFarm, $HcomFire, $HcomFlower, $HcomFood, $HcomGiveup, $HcomHaribote, $HcomHospital, $HcomL, $HcommandMax, $HcomManipulate, $HcomMissileDM, $HcomMissileGM, $HcomMissileLD, $HcomMissileMGM, $HcomMissileNCM, $HcomMissileNM, $HcomMissilePLD, $HcomMissilePP, $HcomMissileRM, $HcomMissileRNG, $HcomMissileSPP, $HcomMissileSRM, $HcomMissileST, $HcomMoney, $HcomMonsAid, $HcomMonsEgg, $HcomMonsEnsei, $HcomMonsEsa, $HcomMonsEsaAid, $HcomMonsExer, $HcomMonsSell, $HcomMonsTettai, $HcomMonument, $HcomMountain, $HcomMyhome, $HcomName, $HcomOilBuy, $HcomOilSell, $HcomOMissileMGM, $HcomOMissileNM, $HcomOMissilePP, $HcomOMissileSPP, $HcomOreBuy, $HcomOreSell, $HcomPioneer, $HcomPlant, $HcomPolice, $HcomPort, $HcomPrepare, $HcomPrepare2, $HcomPresent, $HcomPresentAid, $HcomPropaganda, $HcomReclaim, $HcomReclaim2, $HcomSbase, $HcomSBuild, $HcomScity, $HcomSDbase, $HcomSDestroy, $HcomSearch, $HcomSEisei, $HcomSell, $HcomSellTree, $HcomSendMonster, $HcomSendMonsterTurn, $HcomSFactory, $HcomSFarm, $HcomSFood, $HcomShip, $HcomShipbuild, $HcomShipM, $HcomShipSell, $HcomSMissile, $HcomSMissileGM, $HcomSMissileMGM, $HcomSMissilePP, $HcomSMonument, $HcomSOccupy, $HcomSpaceBase, $HcomSpaceFarm, $HcomSpecialSPP, $HcomSPioneer, $HcomSpy, $HcomSSendMonster, $HcomSSendMonsterTurn, $HcomSTManipulate, $HcomSUnit, $HcomTeisatu, $HcomTower, $HcomTrump, $HcomUg, $HcomWarp, $HcomWeponBuy, $HcomWeponSell, $HcomWindmill, $HconsolationMatch, $HcurrentNumber, $HdBaseAuto, $HdefenceHex, $HdefenceSpace, $HdevelopeTurn, $HdirMode, $HdirName, $HdisAEruption, $HdisAkasio, $HdisBHarvest, $HdisCrime, $HdisEarthquake, $HdisEruption, $HdisFallBorder, $HdisFalldown, $HdisFire, $HdisGHarvest, $Hdishangen, $HdisHugeMeteo, $HdisKLimit, $HdisMaizo, $HdisMeteo, $HdisMonsBorder1, $HdisMonsBorder2, $HdisMonsBorder3, $HdisMonsBorder4, $HdisMonsBorder5, $HdisMonster, $HdisMonsterU, $HdisPirate, $HdisPollution, $HdisSeaMonster, $HdisSHugeMeteo, $HdisSpaceMonster1, $HdisSpaceMonster2, $HdisTinka, $HdisTreasureS, $HdisTsunami, $HdisTyphoon, $HdisUN, $HdisVGHarvest, $HearthAttack, $HeatenFood, $helpDir, $HfightMem, $HfightTurn, $HfinalTurn, $HgiveupTurn, $HhistoryMax, $HidToName, $HidToNumber, $HidToNumberR, $HinterTime, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HlandAegisShip, $HlandAirport, $HlandAmusement, $HlandBalloonS, $HlandBank, $HlandBase, $HlandBigcity, $HlandBreakwater, $HlandCasino, $HlandCoupleRock, $HlandDeathtrap, $HlandDefence, $HlandDokan, $HlandDome, $HlandEarth, $HlandExpo, $HlandFactory, $HlandFarm, $HlandFire, $HlandFishLShip, $HlandFishMShip, $HlandFishSShip, $HlandFlower, $HlandForest, $HlandFuji, $HlandGhostShip, $HlandHaribote, $HlandHospital, $HlandHugecity, $HlandIceFloe, $HlandKInora, $HlandMegacity, $HlandMegaFact, $HlandMegaFarm, $HlandMegatower, $HlandMonsShip, $HlandMonster, $HlandMonument, $HlandMountain, $HlandMyhome, $HlandOcean, $HlandOil, $HlandOPlayer, $HlandOsen, $HlandPark, $HlandPirate, $HlandPlains, $HlandPolice, $HlandPort, $HlandProbeShip, $HlandSAEisei, $HlandSbase, $HlandSchool, $HlandSCity, $HlandSDefence, $HlandSea, $HlandSeisei, $HlandSFactory, $HlandSFarm, $HlandSlum, $HlandSMonument, $HlandSpaceBase, $HlandStadium, $HlandSunit, $HlandTcity, $HlandTitanic, $HlandTower, $HlandTown, $HlandTreasureS, $HlandTrump, $HlandWarp, $HlandWarpR, $HlandWaste, $HlandWindmill, $HlandWingDragon, $HlandZoo, $HlateLogPool, $HlogMax, $HlogOmit2, $HlogPool, $HmaxdisPollution, $HmaxExpPoint, $HmaxIsland, $HmonsBtlMaxHp, $HmonsBtlMaxPa, $HmonsterAGI, $HmonsterBHP, $HmonsterCLS, $HmonsterDEF, $HmonsterDestroy, $HmonsterDHP, $HmonsterExp, $HmonsterGRP, $HmonsterL1, $HmonsterL1Num, $HmonsterL2, $HmonsterL2Num, $HmonsterL3, $HmonsterL3Num, $HmonsterL4, $HmonsterL4Num, $HmonsterL5, $HmonsterL5Num, $HmonsterName, $HmonsterNumber, $HmonsterS, $HmonsterSEI, $HmonsterSKL, $HmonsterSP, $HmonsterSpecial, $HmonsterSTR, $HmonsterValue, $Hmonth, $HmonumentMissile, $HmonumentName, $HmonumentRocket, $Hocean, $HoceanSize, $HoilMoney, $HoilRatio, $hp, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $Hprize, $HprizeV, $HpunishInfo, $HrepeatTurn, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $HseaChk, $HsecretLogPool, $HsEisei, $HshipEX, $HshipFood, $HshipHP, $HshipKAI, $HshipMATK, $HshipMoney, $HshipName, $Hshiporder, $HshipSATK, $HshipSell, $HshipSP, $HsmonumentName, $HsmonumentNumber, $Hsolarwind, $Hspace, $HspaceEfficiency, $HspaceIncome, $Hsstartturn, $HStotalPoint, $HsurvFlg, $Hsurvivalturn, $HtagName2_, $HthisFile, $HtotalBumon, $HtotalMoney, $HtotalPoint, $Htournament, $HtreeValue, $HturnPrizeNumber, $HturnPrizePoint, $HturnPrizeUnit, $HturnPrizeVarious, $HugDokan, $HugFact, $HugFarm, $HugHasigo, $HugKiti, $HugMax, $HugOil, $HugRoad, $HugSpace, $HugTosi, $human, $HunitFood, $HunitMoney, $HunitOil, $HunitOre, $HunitPop, $HunitTime, $HunitWeapon, $HwarFlg, $HWeatherMax, $Hwflg, $HwinFood, $HwinIsland, $HwinMoney, $HwinWeapon, $imageDir, $lockMode, $toppage, $versionInfo;
	$land =& $Hspace['land']; $landValue =& $Hspace['landValue']; $dis =& $Hspace['landValue2']; $nation =& $Hspace['nation'];
	list($pop1,$pop2,$pop3,$di) = array(18,9,3,0);
//	if($Hspace['food'] < 0){
//		# 식량 부족
//		$pop1 -= 24;
//		$pop2 -= 22;
//		$pop3 -= 20;
// 		$Hspace['food'] = 0;
//	}
	$x = null; $y = null; $i = null; $spaceMove = null;
	$p = ($island['spacemonster'] > 0) ? $HdisSpaceMonster1 : $HdisSpaceMonster2;
	for($i = 0; $i < $HpointNumber; $i++){
		$x = $Hrpx[$i];
		$y = $Hrpy[$i];
		list($kind,$lv,$id) = array($land[$x][$y],$landValue[$x][$y],$nation[$x][$y]);
		$tn = $HidToNumber[$id];
		$island =& $Hislands[$tn];
		
		// 수입
		if(($id > 0) && (($kind == $HlandSFarm) || ($kind == $HlandSFactory))){
			if($island['spop2'] > $lv){
				$island['money'] += $lv * $HspaceIncome;
				$island['spop2'] -= $lv;
			}else{
				$island['money'] += $island['spop2'] * $HspaceIncome;
				$island['spop2'] = 0;
			}
		}
		// 성장
		if($kind == $HlandSCity){
			if((random($p) < $Hspace['area']) && ($Hsolarwind == 0) && ($HdisMonster > 0)){
				// 괴수 처리
				$lv = null; $kind = null;
				if($Hspace['area'] < 80){
					$kind = $HmonsterS[0];
				}else{
					$kind = $HmonsterS[random((count($HmonsterS) - 1) + 1)];
				}
				$lv = $kind * 100 + $HmonsterBHP[$kind] + random($HmonsterDHP[$kind]);
				
				logMonsComeSpace(hako_pick(monsterSpec($lv), array(1)), "($x, $y)", landName($land[$x][$y], $landValue[$x][$y]));
				$land[$x][$y] = $HlandMonster;
				$landValue[$x][$y] = $lv;
			}else{
				if($lv < 100){
					$lv += random($pop1);
				}elseif($lv < 150){
					$lv += random($pop2);
				}else{
					$lv += random($pop3);
				}
				if($lv > 200){
					$landValue[$x][$y] = 200;
				}elseif($lv <= 0){
					$land[$x][$y] = $HlandSunit;
					$landValue[$x][$y] = 10;
				}else{
					$landValue[$x][$y] = $lv;

				}
			}
		}elseif($kind == $HlandSAEisei){
			// 우주 위성
			if($lv % 1000 > 0){
				$e = intval($lv / 1000);
				if($e == 4 && $island['eis4'] > 1){
					if($lv % 1000 < $island['eis4']){
						$landValue[$x][$y] = 4000;
					}else{
						$landValue[$x][$y] -= $island['eis4'];# 에너지 소비
					}
					$island['eis4'] = 1;
				}else{
					$landValue[$x][$y]--;# 에너지 소비
				}
				$island['money'] -= ($e + 1) * 50;
				if($island['money'] < 0){
					$island['money'] = 0;
					$landValue[$x][$y] = 0;
				}
			}else{
				logSpaceDisEvent($id, "($x, $y)", landName($land[$x][$y], $landValue[$x][$y]), "가, 연료 부족으로 지구를 향해 강하했습니다.");
				$land[$x][$y] = $HlandSea;
				$landValue[$x][$y] = 0;
				$dis[$x][$y] = 0;
				$nation[$x][$y] = 0;
				// 지상 운석 낙하율 업은 하지 않는다.?
			//	$HdisMeteo += 80; #  도 전체+8%
			}
		}elseif(($kind == $HlandMonster) && ($Hsolarwind == 0)){
			//  괴수
			// 각 요소의 꺼내
			list($mKind, $mName, $mHp) = monsterSpec($landValue[$x][$y]);
			$special = $HmonsterSpecial[$mKind];
			
			if ($spaceMove[$x][$y] >= 2) { continue; }
			
			// 이동한다
			list($sx, $sy) = monmove($Hspace, $x, $y, 3);

			// 이동이 끝난 플래그
			if($HmonsterSpecial[$mKind] == 2){
				// 이동이 끝난 플래그는 세우지 않다
			}elseif($HmonsterSpecial[$mKind] == 1){
				// 빠른 괴수
				$spaceMove[$sx][$sy] = $spaceMove[$x][$y] + 1;
			}else{
				// 보통 괴수
				$spaceMove[$sx][$sy] = 2;
			}
		}elseif(($kind == $HlandSFactory) && ($dis[$x][$y] > 30)){
			if((random(1000000) < $HdisSHugeMeteo * $Hspace['area']) && ($Hsolarwind == 0)){
				// 거대 운석
				logSpaceDisEvent($id, "($x, $y)", landName($kind,$lv), "부근에서 시공간이 열려  돌연 거대한 운석이 출현했습니다!");
				wideDamageSpace($id, $land, $landValue, $dis, $nation, $x, $y, 7, 1);
			}
		}elseif(($kind == $HlandSunit) && ($lv == 10)){
			if(random(10) == 0){
				//  주위에 농장 있으면, 여기도 마을이 된다
				if(countGrow($land, $landValue, $x, $y)){
					$land[$x][$y] = $HlandSCity;
					$landValue[$x][$y] = 1;
					$dis[$x][$y] = 10;
				}
			}
		}
		
		// 불만도 변동
		if($kind == $HlandSunit){
			$dis[$x][$y] = 20;
		}elseif($id > 0){
			
		}else{
			$dis[$x][$y] -= 4;
		}
		if(($dis[$x][$y] > 30) && ($id > 0)){
			// 불만을 가지는 사람에 따라 다른 봉기 이벤트?
			$p = null;
			if($dis[$x][$y] < 45){
				$p = 1;
			}elseif($dis[$x][$y] < 60){
				$p = 3;
			}elseif($dis[$x][$y] < 100){
				$p = 8;
			}else{
				$p = 20;
			}
			if(random(100) < $p){
				logSpaceDisEvent($id, "($x, $y)", landName($land[$x][$y], $landValue[$x][$y]), "가, 일제히 봉기 하고 독립했습니다.");
				$dis[$x][$y] -= 25;
				$nation[$x][$y] = 0;
				
				// 주위의 불만도를 올린다
				$j = null; $sx = null; $sy = null;
				for($j = 1; $j < 7; $j++){
					$sx = $x + $ax[$j];
					$sy = $y + $ay[$j];
					if (!($sy % 2) && ($y % 2)) { $sx--; }
					if(($sx < 0) || ($sx >= $HislandSize) || ($sy < 0) || ($sy >= $HislandSize)){
					}elseif($nation[$sx][$sy] == $id){
//						HdebugOut("주위의 불만도 같은 소속:" . $nation[$sx][$sy]);
						$dis[$sx][$sy] += 10;
					}elseif($nation[$sx][$sy] > 0){
//						HdebugOut("주위의 불만도 다른 소속:" . $nation[$sx][$sy]);
						$dis[$sx][$sy] -= 5;
					}
				}
			}
		}
	}
}

// 해역 성장 및 단헥스 재해
function oceanHex() {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $H_tagName2, $Haidpop, $Hallyflg, $Hallygroup, $haribote, $Hatkturn, $HbackupTimes, $HbackupTurn, $HbgInfoCell, $HbgTitleCell, $HbigcityFood, $HbigCityMFlg, $HcomBank, $HcomBase, $HcomBioMissile, $HcomBreakwater, $Hcomcolony, $HcomcolonyTurn, $HcomCost, $HcomDbase, $HcomDeathtrap, $HcomDestroy, $HcomDestroy2, $HcomDokan, $HcomDoNothing, $HcomDummy, $HcomEmigration, $HcomFactory, $HcomFarm, $HcomFire, $HcomFlower, $HcomFood, $HcomGiveup, $HcomHaribote, $HcomHospital, $HcomL, $HcommandMax, $HcomManipulate, $HcomMissileDM, $HcomMissileGM, $HcomMissileLD, $HcomMissileMGM, $HcomMissileNCM, $HcomMissileNM, $HcomMissilePLD, $HcomMissilePP, $HcomMissileRM, $HcomMissileRNG, $HcomMissileSPP, $HcomMissileSRM, $HcomMissileST, $HcomMoney, $HcomMonsAid, $HcomMonsEgg, $HcomMonsEnsei, $HcomMonsEsa, $HcomMonsEsaAid, $HcomMonsExer, $HcomMonsSell, $HcomMonsTettai, $HcomMonument, $HcomMountain, $HcomMyhome, $HcomName, $HcomOilBuy, $HcomOilSell, $HcomOMissileMGM, $HcomOMissileNM, $HcomOMissilePP, $HcomOMissileSPP, $HcomOreBuy, $HcomOreSell, $HcomPioneer, $HcomPlant, $HcomPolice, $HcomPort, $HcomPrepare, $HcomPrepare2, $HcomPresent, $HcomPresentAid, $HcomPropaganda, $HcomReclaim, $HcomReclaim2, $HcomSbase, $HcomSBuild, $HcomScity, $HcomSDbase, $HcomSDestroy, $HcomSearch, $HcomSEisei, $HcomSell, $HcomSellTree, $HcomSendMonster, $HcomSendMonsterTurn, $HcomSFactory, $HcomSFarm, $HcomSFood, $HcomShip, $HcomShipbuild, $HcomShipM, $HcomShipSell, $HcomSMissile, $HcomSMissileGM, $HcomSMissileMGM, $HcomSMissilePP, $HcomSMonument, $HcomSOccupy, $HcomSpaceBase, $HcomSpaceFarm, $HcomSpecialSPP, $HcomSPioneer, $HcomSpy, $HcomSSendMonster, $HcomSSendMonsterTurn, $HcomSTManipulate, $HcomSUnit, $HcomTeisatu, $HcomTower, $HcomTrump, $HcomUg, $HcomWarp, $HcomWeponBuy, $HcomWeponSell, $HcomWindmill, $HconsolationMatch, $HcurrentNumber, $HdBaseAuto, $HdefenceHex, $HdefenceSpace, $HdevelopeTurn, $HdirMode, $HdirName, $HdisAEruption, $HdisAkasio, $HdisBHarvest, $HdisCrime, $HdisEarthquake, $HdisEruption, $HdisFallBorder, $HdisFalldown, $HdisFire, $HdisGHarvest, $Hdishangen, $HdisHugeMeteo, $HdisKLimit, $HdisMaizo, $HdisMeteo, $HdisMonsBorder1, $HdisMonsBorder2, $HdisMonsBorder3, $HdisMonsBorder4, $HdisMonsBorder5, $HdisMonster, $HdisMonsterU, $HdisPirate, $HdisPollution, $HdisSeaMonster, $HdisSHugeMeteo, $HdisSpaceMonster1, $HdisSpaceMonster2, $HdisTinka, $HdisTreasureS, $HdisTsunami, $HdisTyphoon, $HdisUN, $HdisVGHarvest, $HearthAttack, $HeatenFood, $helpDir, $HfightMem, $HfightTurn, $HfinalTurn, $HgiveupTurn, $HhistoryMax, $HidToName, $HidToNumber, $HidToNumberR, $HinterTime, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HlandAegisShip, $HlandAirport, $HlandAmusement, $HlandBalloonS, $HlandBank, $HlandBase, $HlandBigcity, $HlandBreakwater, $HlandCasino, $HlandCoupleRock, $HlandDeathtrap, $HlandDefence, $HlandDokan, $HlandDome, $HlandEarth, $HlandExpo, $HlandFactory, $HlandFarm, $HlandFire, $HlandFishLShip, $HlandFishMShip, $HlandFishSShip, $HlandFlower, $HlandForest, $HlandFuji, $HlandGhostShip, $HlandHaribote, $HlandHospital, $HlandHugecity, $HlandIceFloe, $HlandKInora, $HlandMegacity, $HlandMegaFact, $HlandMegaFarm, $HlandMegatower, $HlandMonsShip, $HlandMonster, $HlandMonument, $HlandMountain, $HlandMyhome, $HlandOcean, $HlandOil, $HlandOPlayer, $HlandOsen, $HlandPark, $HlandPirate, $HlandPlains, $HlandPolice, $HlandPort, $HlandProbeShip, $HlandSAEisei, $HlandSbase, $HlandSchool, $HlandSCity, $HlandSDefence, $HlandSea, $HlandSeisei, $HlandSFactory, $HlandSFarm, $HlandSlum, $HlandSMonument, $HlandSpaceBase, $HlandStadium, $HlandSunit, $HlandTcity, $HlandTitanic, $HlandTower, $HlandTown, $HlandTreasureS, $HlandTrump, $HlandWarp, $HlandWarpR, $HlandWaste, $HlandWindmill, $HlandWingDragon, $HlandZoo, $HlateLogPool, $HlogMax, $HlogOmit2, $HlogPool, $HmaxdisPollution, $HmaxExpPoint, $HmaxIsland, $HmonsBtlMaxHp, $HmonsBtlMaxPa, $HmonsterAGI, $HmonsterBHP, $HmonsterCLS, $HmonsterDEF, $HmonsterDestroy, $HmonsterDHP, $HmonsterExp, $HmonsterGRP, $HmonsterL1, $HmonsterL1Num, $HmonsterL2, $HmonsterL2Num, $HmonsterL3, $HmonsterL3Num, $HmonsterL4, $HmonsterL4Num, $HmonsterL5, $HmonsterL5Num, $HmonsterName, $HmonsterNumber, $HmonsterS, $HmonsterSEI, $HmonsterSKL, $HmonsterSP, $HmonsterSpecial, $HmonsterSTR, $HmonsterValue, $Hmonth, $HmonumentMissile, $HmonumentName, $HmonumentRocket, $Hocean, $HoceanSize, $HoilMoney, $HoilRatio, $hp, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $Hprize, $HprizeV, $HpunishInfo, $HrepeatTurn, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $HseaChk, $HsecretLogPool, $HsEisei, $HshipEX, $HshipFood, $HshipHP, $HshipKAI, $HshipMATK, $HshipMoney, $HshipName, $Hshiporder, $HshipSATK, $HshipSell, $HshipSP, $HsmonumentName, $HsmonumentNumber, $Hsolarwind, $Hspace, $HspaceEfficiency, $HspaceIncome, $Hsstartturn, $HStotalPoint, $HsurvFlg, $Hsurvivalturn, $HtagName2_, $HthisFile, $HtotalBumon, $HtotalMoney, $HtotalPoint, $Htournament, $HtreeValue, $HturnPrizeNumber, $HturnPrizePoint, $HturnPrizeUnit, $HturnPrizeVarious, $HugDokan, $HugFact, $HugFarm, $HugHasigo, $HugKiti, $HugMax, $HugOil, $HugRoad, $HugSpace, $HugTosi, $human, $HunitFood, $HunitMoney, $HunitOil, $HunitOre, $HunitPop, $HunitTime, $HunitWeapon, $HwarFlg, $HWeatherMax, $Hwflg, $HwinFood, $HwinIsland, $HwinMoney, $HwinWeapon, $imageDir, $lockMode, $toppage, $versionInfo;
	$wHislandSize = $HislandSize;
	$HislandSize = $HoceanSize;
	$land =& $Hocean['land']; $landValue =& $Hocean['landValue']; $dis =& $Hocean['landValue2']; $nation =& $Hocean['nation'];
	$x = null; $y = null; $i = null; $oceanMove = null;
	for($i = 0; $i < $HpointOcean; $i++){
		$x = $HrpxO[$i];
		$y = $HrpyO[$i];
		list($kind,$lv,$id) = array($land[$x][$y],$landValue[$x][$y],$nation[$x][$y]);
		$tn = $HidToNumber[$id];
		$island =& $Hislands[$tn];
		if($kind == $HlandSea){
			if((random($HdisSeaMonster) == 0) && ($HdisMonster > 0)){
				// 괴수 처리
				$lv = null; $kind = null;
				$kind = (random(2)) ? 9 : 21;
				$lv = $kind * 100 + ($HmonsterBHP[$kind] + random($HmonsterDHP[$kind])) * 3;
				logMonsComeOcean(hako_pick(monsterSpec($lv), array(1)), "($x, $y)", landName($land[$x][$y], $landValue[$x][$y]));
				$land[$x][$y] = $HlandMonster;
				$landValue[$x][$y] = $lv;
			}
		}elseif($kind == $HlandMonster){
			// 괴수
			// 각 요소의 꺼내
			list($mKind, $mName, $mHp) = monsterSpec($landValue[$x][$y]);
			$special = $HmonsterSpecial[$mKind];
			if ($oceanMove[$x][$y] >= 2) { continue; }

			// 이동한다
			list($sx, $sy) = monmove($Hocean, $x, $y, 4);

			// 이동이 끝난 플래그
			if($HmonsterSpecial[$mKind] == 2){
				// 이동이 끝난 플래그는 세우지 않다
			}elseif($HmonsterSpecial[$mKind] == 1){
				// 빠른 괴수
				$oceanMove[$sx][$sy] = $oceanMove[$x][$y] + 1;
			}else{
				// 보통 괴수
				$oceanMove[$sx][$sy] = 2;
			}
		}
	}
	$HislandSize = $wHislandSize;
}


// 인구 그 외의 값을 산출(부하 경감을 위해 나누기라고 다만이지만 그다지 의미가 없었다)
function estimateS() {
  $_args = func_get_args();
  extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $H_tagName2, $Haidpop, $Hallyflg, $Hallygroup, $haribote, $Hatkturn, $HbackupTimes, $HbackupTurn, $HbgInfoCell, $HbgTitleCell, $HbigcityFood, $HbigCityMFlg, $HcomBank, $HcomBase, $HcomBioMissile, $HcomBreakwater, $Hcomcolony, $HcomcolonyTurn, $HcomCost, $HcomDbase, $HcomDeathtrap, $HcomDestroy, $HcomDestroy2, $HcomDokan, $HcomDoNothing, $HcomDummy, $HcomEmigration, $HcomFactory, $HcomFarm, $HcomFire, $HcomFlower, $HcomFood, $HcomGiveup, $HcomHaribote, $HcomHospital, $HcomL, $HcommandMax, $HcomManipulate, $HcomMissileDM, $HcomMissileGM, $HcomMissileLD, $HcomMissileMGM, $HcomMissileNCM, $HcomMissileNM, $HcomMissilePLD, $HcomMissilePP, $HcomMissileRM, $HcomMissileRNG, $HcomMissileSPP, $HcomMissileSRM, $HcomMissileST, $HcomMoney, $HcomMonsAid, $HcomMonsEgg, $HcomMonsEnsei, $HcomMonsEsa, $HcomMonsEsaAid, $HcomMonsExer, $HcomMonsSell, $HcomMonsTettai, $HcomMonument, $HcomMountain, $HcomMyhome, $HcomName, $HcomOilBuy, $HcomOilSell, $HcomOMissileMGM, $HcomOMissileNM, $HcomOMissilePP, $HcomOMissileSPP, $HcomOreBuy, $HcomOreSell, $HcomPioneer, $HcomPlant, $HcomPolice, $HcomPort, $HcomPrepare, $HcomPrepare2, $HcomPresent, $HcomPresentAid, $HcomPropaganda, $HcomReclaim, $HcomReclaim2, $HcomSbase, $HcomSBuild, $HcomScity, $HcomSDbase, $HcomSDestroy, $HcomSearch, $HcomSEisei, $HcomSell, $HcomSellTree, $HcomSendMonster, $HcomSendMonsterTurn, $HcomSFactory, $HcomSFarm, $HcomSFood, $HcomShip, $HcomShipbuild, $HcomShipM, $HcomShipSell, $HcomSMissile, $HcomSMissileGM, $HcomSMissileMGM, $HcomSMissilePP, $HcomSMonument, $HcomSOccupy, $HcomSpaceBase, $HcomSpaceFarm, $HcomSpecialSPP, $HcomSPioneer, $HcomSpy, $HcomSSendMonster, $HcomSSendMonsterTurn, $HcomSTManipulate, $HcomSUnit, $HcomTeisatu, $HcomTower, $HcomTrump, $HcomUg, $HcomWarp, $HcomWeponBuy, $HcomWeponSell, $HcomWindmill, $HconsolationMatch, $HcurrentNumber, $HdBaseAuto, $HdefenceHex, $HdefenceSpace, $HdevelopeTurn, $HdirMode, $HdirName, $HdisAEruption, $HdisAkasio, $HdisBHarvest, $HdisCrime, $HdisEarthquake, $HdisEruption, $HdisFallBorder, $HdisFalldown, $HdisFire, $HdisGHarvest, $Hdishangen, $HdisHugeMeteo, $HdisKLimit, $HdisMaizo, $HdisMeteo, $HdisMonsBorder1, $HdisMonsBorder2, $HdisMonsBorder3, $HdisMonsBorder4, $HdisMonsBorder5, $HdisMonster, $HdisMonsterU, $HdisPirate, $HdisPollution, $HdisSeaMonster, $HdisSHugeMeteo, $HdisSpaceMonster1, $HdisSpaceMonster2, $HdisTinka, $HdisTreasureS, $HdisTsunami, $HdisTyphoon, $HdisUN, $HdisVGHarvest, $HearthAttack, $HeatenFood, $helpDir, $HfightMem, $HfightTurn, $HfinalTurn, $HgiveupTurn, $HhistoryMax, $HidToName, $HidToNumber, $HidToNumberR, $HinterTime, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HlandAegisShip, $HlandAirport, $HlandAmusement, $HlandBalloonS, $HlandBank, $HlandBase, $HlandBigcity, $HlandBreakwater, $HlandCasino, $HlandCoupleRock, $HlandDeathtrap, $HlandDefence, $HlandDokan, $HlandDome, $HlandEarth, $HlandExpo, $HlandFactory, $HlandFarm, $HlandFire, $HlandFishLShip, $HlandFishMShip, $HlandFishSShip, $HlandFlower, $HlandForest, $HlandFuji, $HlandGhostShip, $HlandHaribote, $HlandHospital, $HlandHugecity, $HlandIceFloe, $HlandKInora, $HlandMegacity, $HlandMegaFact, $HlandMegaFarm, $HlandMegatower, $HlandMonsShip, $HlandMonster, $HlandMonument, $HlandMountain, $HlandMyhome, $HlandOcean, $HlandOil, $HlandOPlayer, $HlandOsen, $HlandPark, $HlandPirate, $HlandPlains, $HlandPolice, $HlandPort, $HlandProbeShip, $HlandSAEisei, $HlandSbase, $HlandSchool, $HlandSCity, $HlandSDefence, $HlandSea, $HlandSeisei, $HlandSFactory, $HlandSFarm, $HlandSlum, $HlandSMonument, $HlandSpaceBase, $HlandStadium, $HlandSunit, $HlandTcity, $HlandTitanic, $HlandTower, $HlandTown, $HlandTreasureS, $HlandTrump, $HlandWarp, $HlandWarpR, $HlandWaste, $HlandWindmill, $HlandWingDragon, $HlandZoo, $HlateLogPool, $HlogMax, $HlogOmit2, $HlogPool, $HmaxdisPollution, $HmaxExpPoint, $HmaxIsland, $HmonsBtlMaxHp, $HmonsBtlMaxPa, $HmonsterAGI, $HmonsterBHP, $HmonsterCLS, $HmonsterDEF, $HmonsterDestroy, $HmonsterDHP, $HmonsterExp, $HmonsterGRP, $HmonsterL1, $HmonsterL1Num, $HmonsterL2, $HmonsterL2Num, $HmonsterL3, $HmonsterL3Num, $HmonsterL4, $HmonsterL4Num, $HmonsterL5, $HmonsterL5Num, $HmonsterName, $HmonsterNumber, $HmonsterS, $HmonsterSEI, $HmonsterSKL, $HmonsterSP, $HmonsterSpecial, $HmonsterSTR, $HmonsterValue, $Hmonth, $HmonumentMissile, $HmonumentName, $HmonumentRocket, $Hocean, $HoceanSize, $HoilMoney, $HoilRatio, $hp, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $Hprize, $HprizeV, $HpunishInfo, $HrepeatTurn, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $HseaChk, $HsecretLogPool, $HsEisei, $HshipEX, $HshipFood, $HshipHP, $HshipKAI, $HshipMATK, $HshipMoney, $HshipName, $Hshiporder, $HshipSATK, $HshipSell, $HshipSP, $HsmonumentName, $HsmonumentNumber, $Hsolarwind, $Hspace, $HspaceEfficiency, $HspaceIncome, $Hsstartturn, $HStotalPoint, $HsurvFlg, $Hsurvivalturn, $HtagName2_, $HthisFile, $HtotalBumon, $HtotalMoney, $HtotalPoint, $Htournament, $HtreeValue, $HturnPrizeNumber, $HturnPrizePoint, $HturnPrizeUnit, $HturnPrizeVarious, $HugDokan, $HugFact, $HugFarm, $HugHasigo, $HugKiti, $HugMax, $HugOil, $HugRoad, $HugSpace, $HugTosi, $human, $HunitFood, $HunitMoney, $HunitOil, $HunitOre, $HunitPop, $HunitTime, $HunitWeapon, $HwarFlg, $HWeatherMax, $Hwflg, $HwinFood, $HwinIsland, $HwinMoney, $HwinWeapon, $imageDir, $lockMode, $toppage, $versionInfo;
	list($pop,$popsea, $area, $factory, $tower, $slum, $forest, $kaitei, $MissileK, $oil,
	 $myhome, $port, $tenki, $treasure, $fishShip, $titanic,$monsship,$aegis,$oilfactory) = array(0,0,0,0,0, 0,0,0,0,0, 0,0,0,0,0, 0,0,0,0);
	// 지형을 취득
	$island =& $Hislands[$_args[0]];
	$land =& $island['land']; $landValue =& $island['landValue']; $id = $island['id'];
	// 잠정 처리
	if($island['kaisi'] == 0){
		$zanteisturn = $HislandTurn - $island['turnsu'] * 3;
		if ($zanteisturn < 1) { $zanteisturn = 1; }
		$island['kaisi'] = $zanteisturn;
	}
	// 센다

	$x = null; $y = null; $kind = null; $value = null; $i = null;
	for($y = 0; $y < $HislandSize; $y++){
		for($x = 0; $x < $HislandSize; $x++){
			$kind = $land[$x][$y];
			$value = $landValue[$x][$y];
			if ($HseaChk[$kind] == 0) { $area++; }
			
			if(($kind == $HlandSbase) || ($kind == $HlandOil) || ($kind == $HlandSMonument)){
				$kaitei++;
			}elseif($HseaChk[$kind] == 2){
				// 배계
				list($order, $hp, $sId) = shipSpec($value);
				if($HpunishInfo[$id]['punish'] == 9){
					// 배강제 생환 처리
					if($sId > 0){
						shipComeBack($sId,$kind,$value);
						$land2 =& $island['land2']; $landValue2 =& $island['landValue2'];
						$land[$x][$y] = $land2[$x][$y];
						$landValue[$x][$y] = $landValue2[$x][$y];
						$land2[$x][$y] = $HlandSea;
						$landValue2[$x][$y] = 0;
					}
				}elseif($kind == $HlandTreasureS){
					$treasure++; # 보물선
				}elseif (($kind == $HlandFishSShip) ||
						($kind == $HlandFishMShip) ||
						($kind == $HlandFishLShip) ||
						($kind == $HlandTitanic)){
					$fishShip++; # 어선, 여객선등

					if ($kind == $HlandTitanic) { $titanic++; }
				}elseif (($kind == $HlandMonsShip ) ||
						($kind == $HlandAegisShip) ||
						($kind == $HlandProbeShip)){
					$fishShip++;
					if(($kind == $HlandMonsShip) && ($order == 0) && ($sId == $id)){
						// 바다짐승 소탕정

//						HdebugOut("지령$order배ID$sId도ID$id");
						$monsship += 5;
					}elseif(($kind == $HlandAegisShip) && ($order == 0) && ($sId == $id)){
						// 이지스 함
						$aegis += 5;
					}
				}elseif(($kind == $HlandPirate) && ($sId != $id)){
					// 해적선
					slideBack($island['command'], 0, $HcomSpecialSPP, $id, $x, $y, 5);
				}
continue;
			}
			
			if($kind == $HlandTown){
				// 정
				if ($value > 200) { $value = 200; }
				$pop += $value;
			}elseif(($kind == $HlandOil) && ($value >= 35)){
				// 해저 도시
				$popsea += $value;
			}elseif(($kind == $HlandOil) && ($value == 0)){
				// 유전
				$oil++;
			}elseif(($kind == $HlandForest) || ($kind == $HlandMonument) || ($kind == $HlandSMonument) || ($kind == $HlandFlower) || ($kind == $HlandPark)){
				// 숲, 기념비계, 공원, 꽃
				$forest++;
			}elseif($kind == $HlandTower){
				// 상업 빌딩
				$tower += $value;
			}elseif (($kind == $HlandAirport) || ($kind == $HlandExpo)){
				// 공항, 박람회
				$tower += 50;
			}elseif($kind == $HlandPort){
				// 항구
				$port += $value;
			}elseif($kind == $HlandFactory){
				// 공장
				$factory += $value;
			}elseif($kind == $HlandMegacity){
				// 거대 도시
				if(megaAround($land, $landValue, $x, $y, $kind, $value)){
					$pop += 300;
				}else{
					$land[$x][$y] = $HlandTown;
					$landValue[$x][$y] = 190;
					$pop += 190;
				}
			}elseif($kind == $HlandHugecity){
				// 초 거대 도시
				if($value < 60){
					$pop += 400;
				}elseif($value < 70){
					$factory += 200;
				}elseif($value < 80){
					$tower += 300;
				}
			}elseif($kind == $HlandMonster){
				// 괴수
				$island['monsmgmflg'] = 1;
				$mKind = hako_pick(monsterSpec($value), array(0));
				if($mKind == 28){
					// 테루테루 이노라
					$tenki--;
				}elseif($mKind == 29){
					// 반대 비치는 비친다
					$tenki++;
				}elseif(($HmonsterSpecial[$mKind] == 6) || ($HmonsterSpecial[$mKind] == 7)){
					// 먼저 이동하는 괴수가 있다
					$island['smons'] = 1;
				}
				if($HmonsterDestroy[$mKind] == $HlandSea){
					// 바다짐승
					slideBack($island['command'], 0, $HcomSpecialSPP, $id, $x, $y, 5);
				}
			}elseif($kind == $HlandSlum){
				// 슬럼가
				if($value < 130){
					$slum += $value;
				}else{ # 보통 도시로 돌아간다
					$land[$x][$y] = $HlandTown;
					$pop += $value;
				}
			}elseif($kind == $HlandTcity){
				// 상업도시
				$tower += 200;
				$pop += 300;
			}elseif($kind == $HlandMegatower){
				// 거대 빌딩
				if(megaAround($land, $landValue, $x, $y, $kind, $value)){
					$tower += 300;
				}else{
					$land[$x][$y] = $HlandTower;
					$landValue[$x][$y] = 190;
					$tower += 190;
				}
			}elseif($kind == $HlandMegaFact){
				// 거대 공장
				if(megaAround($land, $landValue, $x, $y, $kind, $value)){
					$factory += 200;
				}else{
					$land[$x][$y] = $HlandFactory;
					$landValue[$x][$y] = 90;
					$factory += 90;
				}
			}elseif($kind == $HlandBigcity){
				// 대 도시
				$pop += 1000;
			}elseif(($kind == $HlandDefence) || (($kind == $HlandOil) && ($value == 5))){
				// 방위 시설
				$island['defence'] = 1;
			}elseif($kind == $HlandMyhome){
				// 마이 홈
				$island['myhome'] = 1;
			}elseif($kind == $HlandPolice){
				// 경찰서
				$island['Police'] = 1;
			}elseif($kind == $HlandHospital){
				// 병원
				$island['Hospital'] = 1;
			}elseif($kind == $HlandFuji){
				// 후지산
				$island['event'] += 2;
			}elseif($kind == $HlandTrump){
				// 트럼프
				$island['trump'][$value] = 1;
			}
		}
	}
	// 지하
	$ugL =& $island['ugL'];
	$ugV =& $island['ugV'];
	$ugX =& $island['ugX'];
	$ugY =& $island['ugY'];
	for($i = 0; $i < $HugMax; $i++) {
		if ($land[$ugX[$i]][$ugY[$i]] != $HlandDokan) { continue; }
		for($x = 0; $x < 9; $x++) {
			if($ugL[$i][$x] == $HugTosi){
				$pop += $ugV[$i][$x];
			}elseif($ugL[$i][$x] == $HugFarm){
				// 아무것도 하지 않는다
			}elseif($ugL[$i][$x] == $HugFact){
				$factory += $ugV[$i][$x];
			}elseif($ugL[$i][$x] == $HugKiti){
				// 아무것도 하지 않는다
			}elseif($ugL[$i][$x] == $HugOil){
				$oilfactory += $ugV[$i][$x];
			}
		}
	}
	
	$pop += $slum;
	if ($pop < $popsea) { $island['kaiteipop'] = 1; }
	$pop += $popsea;
	
	if((($factory + $port + $oilfactory) * 2 < $tower) && ($pop >= 2000)){
		$island['towerD'] = 1001 + $tower - $factory - $port;
	}elseif(($tower == 0) && ($pop >= 2000)){
		$island['towerD'] = 1000;
	}
	// 대입
	$island['pop']  = $pop;
	$island['slum'] = $slum;
	$island['port'] = $port;
	$island['factory']  = $factory;
	$island['tower']    = $tower;
	$island['tenki'] = $tenki;
	$island['treasure'] = $treasure;
	$island['fishShip'] = $fishShip;
	$island['titanic'] = $titanic;
	$island['oilfield']  = $oil;
	$island['kaitei'] = intval($kaitei * 100 / ($HpointNumber + 1 - $area));
	$island['forest'] = ($area == 0) ? 7 : intval($forest * 100 / $area);# 육지가 없을 때
	$island['monsship'] = $monsship;
	$island['aegis'] = $aegis;
	
	$island['oilfactory'] = $oilfactory;

	$island['ship'] = 0;# 초기화
	
	// 우주 자산을 초기화
	$island['spa'] = 0;
	$island['popspace'] = 0;
}

function estimateE() {
  $_args = func_get_args();
  extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $H_tagName2, $Haidpop, $Hallyflg, $Hallygroup, $haribote, $Hatkturn, $HbackupTimes, $HbackupTurn, $HbgInfoCell, $HbgTitleCell, $HbigcityFood, $HbigCityMFlg, $HcomBank, $HcomBase, $HcomBioMissile, $HcomBreakwater, $Hcomcolony, $HcomcolonyTurn, $HcomCost, $HcomDbase, $HcomDeathtrap, $HcomDestroy, $HcomDestroy2, $HcomDokan, $HcomDoNothing, $HcomDummy, $HcomEmigration, $HcomFactory, $HcomFarm, $HcomFire, $HcomFlower, $HcomFood, $HcomGiveup, $HcomHaribote, $HcomHospital, $HcomL, $HcommandMax, $HcomManipulate, $HcomMissileDM, $HcomMissileGM, $HcomMissileLD, $HcomMissileMGM, $HcomMissileNCM, $HcomMissileNM, $HcomMissilePLD, $HcomMissilePP, $HcomMissileRM, $HcomMissileRNG, $HcomMissileSPP, $HcomMissileSRM, $HcomMissileST, $HcomMoney, $HcomMonsAid, $HcomMonsEgg, $HcomMonsEnsei, $HcomMonsEsa, $HcomMonsEsaAid, $HcomMonsExer, $HcomMonsSell, $HcomMonsTettai, $HcomMonument, $HcomMountain, $HcomMyhome, $HcomName, $HcomOilBuy, $HcomOilSell, $HcomOMissileMGM, $HcomOMissileNM, $HcomOMissilePP, $HcomOMissileSPP, $HcomOreBuy, $HcomOreSell, $HcomPioneer, $HcomPlant, $HcomPolice, $HcomPort, $HcomPrepare, $HcomPrepare2, $HcomPresent, $HcomPresentAid, $HcomPropaganda, $HcomReclaim, $HcomReclaim2, $HcomSbase, $HcomSBuild, $HcomScity, $HcomSDbase, $HcomSDestroy, $HcomSearch, $HcomSEisei, $HcomSell, $HcomSellTree, $HcomSendMonster, $HcomSendMonsterTurn, $HcomSFactory, $HcomSFarm, $HcomSFood, $HcomShip, $HcomShipbuild, $HcomShipM, $HcomShipSell, $HcomSMissile, $HcomSMissileGM, $HcomSMissileMGM, $HcomSMissilePP, $HcomSMonument, $HcomSOccupy, $HcomSpaceBase, $HcomSpaceFarm, $HcomSpecialSPP, $HcomSPioneer, $HcomSpy, $HcomSSendMonster, $HcomSSendMonsterTurn, $HcomSTManipulate, $HcomSUnit, $HcomTeisatu, $HcomTower, $HcomTrump, $HcomUg, $HcomWarp, $HcomWeponBuy, $HcomWeponSell, $HcomWindmill, $HconsolationMatch, $HcurrentNumber, $HdBaseAuto, $HdefenceHex, $HdefenceSpace, $HdevelopeTurn, $HdirMode, $HdirName, $HdisAEruption, $HdisAkasio, $HdisBHarvest, $HdisCrime, $HdisEarthquake, $HdisEruption, $HdisFallBorder, $HdisFalldown, $HdisFire, $HdisGHarvest, $Hdishangen, $HdisHugeMeteo, $HdisKLimit, $HdisMaizo, $HdisMeteo, $HdisMonsBorder1, $HdisMonsBorder2, $HdisMonsBorder3, $HdisMonsBorder4, $HdisMonsBorder5, $HdisMonster, $HdisMonsterU, $HdisPirate, $HdisPollution, $HdisSeaMonster, $HdisSHugeMeteo, $HdisSpaceMonster1, $HdisSpaceMonster2, $HdisTinka, $HdisTreasureS, $HdisTsunami, $HdisTyphoon, $HdisUN, $HdisVGHarvest, $HearthAttack, $HeatenFood, $helpDir, $HfightMem, $HfightTurn, $HfinalTurn, $HgiveupTurn, $HhistoryMax, $HidToName, $HidToNumber, $HidToNumberR, $HinterTime, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HlandAegisShip, $HlandAirport, $HlandAmusement, $HlandBalloonS, $HlandBank, $HlandBase, $HlandBigcity, $HlandBreakwater, $HlandCasino, $HlandCoupleRock, $HlandDeathtrap, $HlandDefence, $HlandDokan, $HlandDome, $HlandEarth, $HlandExpo, $HlandFactory, $HlandFarm, $HlandFire, $HlandFishLShip, $HlandFishMShip, $HlandFishSShip, $HlandFlower, $HlandForest, $HlandFuji, $HlandGhostShip, $HlandHaribote, $HlandHospital, $HlandHugecity, $HlandIceFloe, $HlandKInora, $HlandMegacity, $HlandMegaFact, $HlandMegaFarm, $HlandMegatower, $HlandMonsShip, $HlandMonster, $HlandMonument, $HlandMountain, $HlandMyhome, $HlandOcean, $HlandOil, $HlandOPlayer, $HlandOsen, $HlandPark, $HlandPirate, $HlandPlains, $HlandPolice, $HlandPort, $HlandProbeShip, $HlandSAEisei, $HlandSbase, $HlandSchool, $HlandSCity, $HlandSDefence, $HlandSea, $HlandSeisei, $HlandSFactory, $HlandSFarm, $HlandSlum, $HlandSMonument, $HlandSpaceBase, $HlandStadium, $HlandSunit, $HlandTcity, $HlandTitanic, $HlandTower, $HlandTown, $HlandTreasureS, $HlandTrump, $HlandWarp, $HlandWarpR, $HlandWaste, $HlandWindmill, $HlandWingDragon, $HlandZoo, $HlateLogPool, $HlogMax, $HlogOmit2, $HlogPool, $HmaxdisPollution, $HmaxExpPoint, $HmaxIsland, $HmonsBtlMaxHp, $HmonsBtlMaxPa, $HmonsterAGI, $HmonsterBHP, $HmonsterCLS, $HmonsterDEF, $HmonsterDestroy, $HmonsterDHP, $HmonsterExp, $HmonsterGRP, $HmonsterL1, $HmonsterL1Num, $HmonsterL2, $HmonsterL2Num, $HmonsterL3, $HmonsterL3Num, $HmonsterL4, $HmonsterL4Num, $HmonsterL5, $HmonsterL5Num, $HmonsterName, $HmonsterNumber, $HmonsterS, $HmonsterSEI, $HmonsterSKL, $HmonsterSP, $HmonsterSpecial, $HmonsterSTR, $HmonsterValue, $Hmonth, $HmonumentMissile, $HmonumentName, $HmonumentRocket, $Hocean, $HoceanSize, $HoilMoney, $HoilRatio, $hp, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $Hprize, $HprizeV, $HpunishInfo, $HrepeatTurn, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $HseaChk, $HsecretLogPool, $HsEisei, $HshipEX, $HshipFood, $HshipHP, $HshipKAI, $HshipMATK, $HshipMoney, $HshipName, $Hshiporder, $HshipSATK, $HshipSell, $HshipSP, $HsmonumentName, $HsmonumentNumber, $Hsolarwind, $Hspace, $HspaceEfficiency, $HspaceIncome, $Hsstartturn, $HStotalPoint, $HsurvFlg, $Hsurvivalturn, $HtagName2_, $HthisFile, $HtotalBumon, $HtotalMoney, $HtotalPoint, $Htournament, $HtreeValue, $HturnPrizeNumber, $HturnPrizePoint, $HturnPrizeUnit, $HturnPrizeVarious, $HugDokan, $HugFact, $HugFarm, $HugHasigo, $HugKiti, $HugMax, $HugOil, $HugRoad, $HugSpace, $HugTosi, $human, $HunitFood, $HunitMoney, $HunitOil, $HunitOre, $HunitPop, $HunitTime, $HunitWeapon, $HwarFlg, $HWeatherMax, $Hwflg, $HwinFood, $HwinIsland, $HwinMoney, $HwinWeapon, $imageDir, $lockMode, $toppage, $versionInfo;
	global $allPop, $allMoney, $allArea, $allBank, $allMissileA, $allFarm, $allTower, $allIndustry, $allYousyoku, $allForest;
	list($pop,$popsea, $area, $farm, $factory,
	 $tower, $mountain, $yousyoku, $forest, $forestV,
	 $flower, $kaitei, $MissileK, $mons, $haribote,
	 $oil, $myhome, $port, $tenki, $monument) = array(0,0,0,0,0, 0,0,0,0,0, 0,0,0,0,0, 0,0,0,0,0, 0);
	// 지형을 취득
	$island =& $Hislands[$_args[0]];
	$land =& $island['land']; $landValue =& $island['landValue']; $land2 =& $island['land2']; $landValue2 =& $island['landValue2']; $nation =& $island['nation']; $id = $island['id'];
	$LandCount = null;
	// 센다
	$x = null; $y = null; $kind = null; $value = null; $i = null;
	for($y = 0; $y < $HislandSize; $y++){
		for($x = 0; $x < $HislandSize; $x++){
			$kind = $land[$x][$y];
			$value = $landValue[$x][$y];
			$LandCount[$nation[$x][$y]]++;
			if(($HislandTurn % $HturnPrizeUnit) == 0){
				if($nation[$x][$y] > 0){
					$tIsland =& $Hislands[$HidToNumber[$nation[$x][$y]]];
					$tIsland['winP']++;
					if ($nation[$x][$y] != $island['id']) { $island['loseP']++; }
				}
				$nation[$x][$y] = 0; # 턴배때에 클리어
			}
			if($HseaChk[$kind] == 0){
				// 바다계가 아닐 때
				$area++;
			}elseif($kind == $HlandSea){
				//  바다때
				if(($land2[$x][$y] != $HlandSea) || ($landValue2[$x][$y] != 0)){
					// 후에 숨어 있는 지형이 바다가 아닐 때
					$land[$x][$y] = $land2[$x][$y];
					$landValue[$x][$y] = $landValue2[$x][$y];
					$land2[$x][$y] = $HlandSea;
					$landValue2[$x][$y] = 0;
				}
			}elseif(($kind == $HlandSbase) || ($kind == $HlandOil) || ($kind == $HlandSMonument)){
				$kaitei++;
			}elseif($HseaChk[$kind] == 2){
				// 배계
				$sId = hako_pick(shipSpec($value), array(2));
				if($sId > 0){
					$sIsland = $Hislands[$HidToNumber[$sId]];
					$sIsland['ship']++;
				}
continue;
			}
			if($kind == $HlandTown){
				// 정
				if ($value > 200) { $value = 200; }
				$pop += $value;
			}elseif(($kind == $HlandSea) && ($value >= 10)){
				// 양식장
				$yousyoku += $value;
			}elseif(($kind == $HlandOil) && ($value >= 35)){
				// 해저 도시
				$popsea += $value;
			}elseif(($kind == $HlandOil) && ($value == 0)){
				// 유전
				$oil++;
			}elseif($kind == $HlandForest){
				// 숲
			//	$forest++;
				$forestV += $value;
			}elseif($kind == $HlandFlower){
				// 꽃
				$flower++;
			}elseif($kind == $HlandMonument || $kind == $HlandSMonument){
				// 기념비계
				$monument++;
			}elseif(($kind == $HlandFarm) || ($kind == $HlandMegaFarm) || (($kind == $HlandOil) && ($value >= 10))){
				// 농장 , 거대 농장 ,  해저 농장
				$p = 0;
				if($kind == $HlandMegaFarm){
					if(megaAround($land, $landValue, $x, $y, $kind, $value)){
						$p = 60;
					}else{
						$land[$x][$y] = $HlandFarm;
						$landValue[$x][$y] = 50;
						$p = 50;
					}
				}else{
					$p = $value;
				}
				if($kind == $HlandFarm || $kind == $HlandMegaFarm){
					if(chkAround($land, $x, $y, $HlandWindmill, 19)){
						// 육지의 농장 때 주위 2헥스에 풍차가 있으면 2배의 규모에
						$farm += $p * 2;
					}else{
						$farm += $p;
					}
				}else{
					$farm += $p;
				}
			}elseif((($kind == $HlandDefence) && ($value == 3)) ||
				($kind == $HlandBase) || ($kind == $HlandSbase) || ($kind == $HlandDokan)){
				// 미사일 발사수
				if ($kind == $HlandDokan) { $landValue[$x][$y] = intval($value / 100); }
				$MissileK += expToLevel($kind, $value);
			}elseif($kind == $HlandTower){
				// 상업 빌딩
				$tower += $value;
			}elseif(($kind == $HlandAirport) || ($kind == $HlandExpo)){
				// 공항, 박람회
				$tower += 50;
			}elseif($kind == $HlandMountain){
				// 산
				$mountain += $value;
			}elseif($kind == $HlandPort){
				// 항구
				$port += $value;
			}elseif($kind == $HlandFactory){
				// 공장
				$factory += $value;
			}elseif($kind == $HlandMegacity){
				// 거대 도시
				if(megaAround($land, $landValue, $x, $y, $kind, $value)){
					$pop += 300;
				}else{
					$land[$x][$y] = $HlandTown;
					$landValue[$x][$y] = 190;
					$pop += 190;
				}
			}elseif($kind == $HlandHugecity){
				// 초 거대 도시
				$lName = landName($kind, $value);
				$lName2 = null;
				if($value < 50) {
					// 중앙
					if(countAround($land, $x, $y, $HlandHugecity, 7) < 7){
						// 주위 1 헥스가 1개에서도 초거대 지형이 아닌 경우, 붕괴
						$land[$x][$y] = $HlandMonument;
						$lName2 = landName($HlandMonument, $value);
					}else{
						$pop += 400;
					}
				}else{
					//  주위 1 헥스에 초거대도시(중심)가 있을지 어떨지 체크해, 존재하지 않는 경우는 붕괴
					$sx = null; $sy = null;
					$destroy = 1;
					for($i = 1; $i < 7; $i++){
						$sx = $x + $ax[$i];
						$sy = $y + $ay[$i];
						if (!($sy % 2) && ($y % 2)) { $sx--; }
						if(($sx < 0) || ($sx >= $HislandSize) || ($sy < 0) || ($sy >= $HislandSize)){
						}elseif(($land[$sx][$sy] == $HlandHugecity) && ($landValue[$sx][$sy] < 50)){
							$destroy = 0;
						}
					}
					if($value < 60) {
						if($destroy){
							$land[$x][$y] = $HlandTown;
							$landValue[$x][$y] = 200;
							$lName2 = landName($HlandTown, 200);
							$pop += 200;
						}else{
							$pop += 400;
						}
					}elseif($value < 70) {
						if($destroy){
							$land[$x][$y] = $HlandFactory;
							$landValue[$x][$y] = 100;
							$lName2 = landName($HlandFactory, 100);
							$factory += 100;
						}else{
							$factory += 200;
						}
					}elseif($value < 80) {
						if($destroy){
							$land[$x][$y] = $HlandTower;
							$landValue[$x][$y] = 200;
							$lName2 = landName($HlandTower, 200);
							$tower += 200;
						}else{
							$tower += 300;
						}
					}else{
						if($destroy){
							$land[$x][$y] = $HlandFarm;
							$landValue[$x][$y] = 50;
							$lName2 = landName($HlandFarm, 50);
							$farm += 50;
						}else{
							if(chkAround($land, $x, $y, $HlandWindmill, 19)){
								// 육지의 농장 때 주위 2헥스에 풍차가 있으면 2배의 규모에
								$farm += 60 * 2;
							}else{
								$farm += 60;
							}
						}
					}
				}
				if($land[$x][$y] != $HlandHugecity){
					logEventP($id, $island['name'],"($x, $y)", "의${lName} 는 ,${lName2}에 돌아가 버렸습니다.");
				}
			}elseif($kind == $HlandHaribote){
				// 위장 방위 시설
				$haribote++;
			}elseif($kind == $HlandMonster){
				// 괴수
				$mons++;
			}elseif($kind == $HlandSlum){
				// 슬럼가
				$pop += $value;
				if ($value >= 130) { $land[$x][$y] = $HlandTown; }
			}elseif($kind == $HlandTcity){
				// 상업 도시
				$tower += 200;
				$pop += 300;
			}elseif($kind == $HlandMegatower){
				// 거대 빌딩
				if(megaAround($land, $landValue, $x, $y, $kind, $value)){
					$tower += 300;
				}else{
					$land[$x][$y] = $HlandTower;
					$landValue[$x][$y] = 190;
					$tower += 190;
				}
			}elseif($kind == $HlandMegaFact){
				// 거대 공장
				if(megaAround($land, $landValue, $x, $y, $kind, $value)){
					$factory += 200;
				}else{
					$land[$x][$y] = $HlandFactory;
					$landValue[$x][$y] = 90;
					$factory += 90;
				}
			}elseif($kind == $HlandBigcity){
				// 대 도시
				$pop += 1000;
			}elseif($kind == $HlandBank){
				// 은행
				$allBank += $value;
			}elseif($kind == $HlandFuji){
				// 후지산
				fujiAround($land, $landValue, $x, $y, $value);
			}
		}
	}
	// 지하
	$ugL =& $island['ugL'];
	$ugV =& $island['ugV'];
	$ugX =& $island['ugX'];
	$ugY =& $island['ugY'];
	for($i = 0; $i < $HugMax; $i++) {
		if ($land[$ugX[$i]][$ugY[$i]] != $HlandDokan) { continue; }
		for($x = 0; $x < 9; $x++) {
			if($ugL[$i][$x] == $HugTosi){
				if($island['food'] <= 0){
					// 식량부족
					$ugV[$i][$x] -= random(20);
				}else{
					$ugV[$i][$x] += random(10);
				}
				if($ugV[$i][$x] > 0){
					if ($ugV[$i][$x] > 100) { $ugV[$i][$x] = 100; }
					$pop += $ugV[$i][$x];
				}else{
					// 식량부족으로 붕괴
					$ugL[$i][$x] = $HugRoad;
					$ugV[$i][$x] = 0;
				}
			}elseif($ugL[$i][$x] == $HugFarm){
				$farm += $ugV[$i][$x];
			}elseif($ugL[$i][$x] == $HugFact){
				$factory += $ugV[$i][$x];
			}elseif($ugL[$i][$x] == $HugKiti){
				$landValue[$ugX[$i]][$ugY[$i]]++;
			}elseif($ugL[$i][$x] == $HugOil){
				$factory += $ugV[$i][$x];
			}
		}
	}
	if ($pop < $popsea) { $island['kaiteipop'] = 1; }
	$pop += $popsea;
	if((($factory + $port) * 2 < $tower) && ($pop >= 2000)){
		$island['towerD'] = 1001 + $tower - $factory - $port;
	}elseif(($tower == 0) && ($pop >= 2000)){
		$island['towerD'] = 1000;
	}

	// 점유율
//	HdebugOut($island['id'] . "자도점유=" . $LandCount{0});
	if($LandCount[0] < $Hpossess){
		// 항복!
		unset($tIsland); $tIsland = null; $tName = null; $name = null;
		$i = 0;
		$__keys = array_keys($LandCount); usort($__keys, function($a, $b) { global $Hislands, $rekidai, $HtotalPoint, $HtotalMoney, $HtotalBumon, $HStotalPoint, $DATA, $LandCount, $LandCount2, $allyPop;  return hako_cmp($LandCount[$b], $LandCount[$a]); }); foreach ($__keys as $_) {
			$w = intval($LandCount[$_] * 10000 / $HpointNumber + 0.5) / 100;
			if(($_ != 0) && ($w > 1)){
				// 승리도
				$tn = $HidToNumber[$_];
				if ($tn == '') { continue; }
				$tIsland =& $Hislands[$tn];
				$tName = $tIsland['name'] . $AfterName;
				$name = $island['name'];
				$tIsland['winP'] += intval($w);
				$island['loseP'] += intval($w);
				if($i == 0){
					$tIsland['winP'] += intval($w * 2);
					if ($tIsland['evil'] > 0) { $tIsland['evil'] = 20000; }
					$tIsland['money']  += $HwinMoney;
					$tIsland['food']   += $HwinFood;
					$tIsland['weapon'] += $HwinWeapon;
					if ($tIsland['money'] > $MaxMoney) { $tIsland['money'] = $MaxMoney; }
					if ($tIsland['food'] > $MaxFood) { $tIsland['food'] = $MaxFood; }
					if ($tIsland['weapon'] > $MaxSigen) { $tIsland['weapon'] = $MaxSigen; }
					$island['loseP'] += intval($w * 2);
					logEventT($id, $_, $name,"가,${HtagName_}${tName}${H_tagName}(${w}%))에<b>지고</b>했다.");
					// 방위 시설(지상), 미사일 시설, 지하 폐기
					for($y = 0; $y < $HislandSize; $y++){
						for($x = 0; $x < $HislandSize; $x++){
							$kind = $land[$x][$y];
							$value = $landValue[$x][$y];
							$nation[$x][$y] = 0;
							if(($kind == $HlandDefence) || ($kind == $HlandBase) || ($kind == $HlandDokan)){
								$land[$x][$y] = $HlandFlower;
								$landValue[$x][$y] = random(13) + 1;
							}elseif($kind == $HlandSbase){
								$land[$x][$y] = $HlandSea;
								$landValue[$x][$y] = 0;
								$land2[$x][$y] = $HlandSea;
								$landValue2[$x][$y] = 0;
							}
						}
					}
					logEvent($id, $name,"는, 무장 방폐해<b>유엔 보호화</b>가 되었습니다.");
					$island['evil'] = 0;
					$MissileK = 0;
				}
				$i++;
			}
		}
	}

	// 대입
	$island['possess'] = $LandCount[0];
	$island['tenki'] = $tenki;
	$island['area'] = $area;
	$island['pop']  = $pop;
	$island['farm'] = $farm;
	$island['port'] = $port;
	$island['factory']  = $factory;
	$island['tower']    = $tower;
	$island['mountain'] = $mountain;
	$island['yousyoku'] = $yousyoku;
	$island['kaitei'] = intval($kaitei * 100 / ($HpointNumber + 1 - $area));
	$island['MissileK'] = $MissileK;
	$island['oilfield']  = $oil;
	$island['monsfound'] = $mons;

	// 부문상용
	$island['mons'] = $mons;
	$island['forestV']  = $forestV;
	$island['haribote'] = $haribote;
	$island['industry'] = $factory + $port + $mountain;
	$island['monument'] = $monument;
	$island['flower'] = $flower;
	
	$allPop += $pop;
	$allArea += $area;
	$allMoney += $island['money'];
	$allMissileA += $island['MissileA']; #미사일 발사 총수
	$allFarm += $farm;
	$allTower += $tower;
	$allIndustry += $island['industry'];
	$allYousyoku += $yousyoku;
	$allForest += $forestV;
}

// 거대 지형의 주변
function megaAround($land, $landValue, $x, $y, $kind, $lv) {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $H_tagName2, $Haidpop, $Hallyflg, $Hallygroup, $haribote, $Hatkturn, $HbackupTimes, $HbackupTurn, $HbgInfoCell, $HbgTitleCell, $HbigcityFood, $HbigCityMFlg, $HcomBank, $HcomBase, $HcomBioMissile, $HcomBreakwater, $Hcomcolony, $HcomcolonyTurn, $HcomCost, $HcomDbase, $HcomDeathtrap, $HcomDestroy, $HcomDestroy2, $HcomDokan, $HcomDoNothing, $HcomDummy, $HcomEmigration, $HcomFactory, $HcomFarm, $HcomFire, $HcomFlower, $HcomFood, $HcomGiveup, $HcomHaribote, $HcomHospital, $HcomL, $HcommandMax, $HcomManipulate, $HcomMissileDM, $HcomMissileGM, $HcomMissileLD, $HcomMissileMGM, $HcomMissileNCM, $HcomMissileNM, $HcomMissilePLD, $HcomMissilePP, $HcomMissileRM, $HcomMissileRNG, $HcomMissileSPP, $HcomMissileSRM, $HcomMissileST, $HcomMoney, $HcomMonsAid, $HcomMonsEgg, $HcomMonsEnsei, $HcomMonsEsa, $HcomMonsEsaAid, $HcomMonsExer, $HcomMonsSell, $HcomMonsTettai, $HcomMonument, $HcomMountain, $HcomMyhome, $HcomName, $HcomOilBuy, $HcomOilSell, $HcomOMissileMGM, $HcomOMissileNM, $HcomOMissilePP, $HcomOMissileSPP, $HcomOreBuy, $HcomOreSell, $HcomPioneer, $HcomPlant, $HcomPolice, $HcomPort, $HcomPrepare, $HcomPrepare2, $HcomPresent, $HcomPresentAid, $HcomPropaganda, $HcomReclaim, $HcomReclaim2, $HcomSbase, $HcomSBuild, $HcomScity, $HcomSDbase, $HcomSDestroy, $HcomSearch, $HcomSEisei, $HcomSell, $HcomSellTree, $HcomSendMonster, $HcomSendMonsterTurn, $HcomSFactory, $HcomSFarm, $HcomSFood, $HcomShip, $HcomShipbuild, $HcomShipM, $HcomShipSell, $HcomSMissile, $HcomSMissileGM, $HcomSMissileMGM, $HcomSMissilePP, $HcomSMonument, $HcomSOccupy, $HcomSpaceBase, $HcomSpaceFarm, $HcomSpecialSPP, $HcomSPioneer, $HcomSpy, $HcomSSendMonster, $HcomSSendMonsterTurn, $HcomSTManipulate, $HcomSUnit, $HcomTeisatu, $HcomTower, $HcomTrump, $HcomUg, $HcomWarp, $HcomWeponBuy, $HcomWeponSell, $HcomWindmill, $HconsolationMatch, $HcurrentNumber, $HdBaseAuto, $HdefenceHex, $HdefenceSpace, $HdevelopeTurn, $HdirMode, $HdirName, $HdisAEruption, $HdisAkasio, $HdisBHarvest, $HdisCrime, $HdisEarthquake, $HdisEruption, $HdisFallBorder, $HdisFalldown, $HdisFire, $HdisGHarvest, $Hdishangen, $HdisHugeMeteo, $HdisKLimit, $HdisMaizo, $HdisMeteo, $HdisMonsBorder1, $HdisMonsBorder2, $HdisMonsBorder3, $HdisMonsBorder4, $HdisMonsBorder5, $HdisMonster, $HdisMonsterU, $HdisPirate, $HdisPollution, $HdisSeaMonster, $HdisSHugeMeteo, $HdisSpaceMonster1, $HdisSpaceMonster2, $HdisTinka, $HdisTreasureS, $HdisTsunami, $HdisTyphoon, $HdisUN, $HdisVGHarvest, $HearthAttack, $HeatenFood, $helpDir, $HfightMem, $HfightTurn, $HfinalTurn, $HgiveupTurn, $HhistoryMax, $HidToName, $HidToNumber, $HidToNumberR, $HinterTime, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HlandAegisShip, $HlandAirport, $HlandAmusement, $HlandBalloonS, $HlandBank, $HlandBase, $HlandBigcity, $HlandBreakwater, $HlandCasino, $HlandCoupleRock, $HlandDeathtrap, $HlandDefence, $HlandDokan, $HlandDome, $HlandEarth, $HlandExpo, $HlandFactory, $HlandFarm, $HlandFire, $HlandFishLShip, $HlandFishMShip, $HlandFishSShip, $HlandFlower, $HlandForest, $HlandFuji, $HlandGhostShip, $HlandHaribote, $HlandHospital, $HlandHugecity, $HlandIceFloe, $HlandKInora, $HlandMegacity, $HlandMegaFact, $HlandMegaFarm, $HlandMegatower, $HlandMonsShip, $HlandMonster, $HlandMonument, $HlandMountain, $HlandMyhome, $HlandOcean, $HlandOil, $HlandOPlayer, $HlandOsen, $HlandPark, $HlandPirate, $HlandPlains, $HlandPolice, $HlandPort, $HlandProbeShip, $HlandSAEisei, $HlandSbase, $HlandSchool, $HlandSCity, $HlandSDefence, $HlandSea, $HlandSeisei, $HlandSFactory, $HlandSFarm, $HlandSlum, $HlandSMonument, $HlandSpaceBase, $HlandStadium, $HlandSunit, $HlandTcity, $HlandTitanic, $HlandTower, $HlandTown, $HlandTreasureS, $HlandTrump, $HlandWarp, $HlandWarpR, $HlandWaste, $HlandWindmill, $HlandWingDragon, $HlandZoo, $HlateLogPool, $HlogMax, $HlogOmit2, $HlogPool, $HmaxdisPollution, $HmaxExpPoint, $HmaxIsland, $HmonsBtlMaxHp, $HmonsBtlMaxPa, $HmonsterAGI, $HmonsterBHP, $HmonsterCLS, $HmonsterDEF, $HmonsterDestroy, $HmonsterDHP, $HmonsterExp, $HmonsterGRP, $HmonsterL1, $HmonsterL1Num, $HmonsterL2, $HmonsterL2Num, $HmonsterL3, $HmonsterL3Num, $HmonsterL4, $HmonsterL4Num, $HmonsterL5, $HmonsterL5Num, $HmonsterName, $HmonsterNumber, $HmonsterS, $HmonsterSEI, $HmonsterSKL, $HmonsterSP, $HmonsterSpecial, $HmonsterSTR, $HmonsterValue, $Hmonth, $HmonumentMissile, $HmonumentName, $HmonumentRocket, $Hocean, $HoceanSize, $HoilMoney, $HoilRatio, $hp, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $Hprize, $HprizeV, $HpunishInfo, $HrepeatTurn, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $HseaChk, $HsecretLogPool, $HsEisei, $HshipEX, $HshipFood, $HshipHP, $HshipKAI, $HshipMATK, $HshipMoney, $HshipName, $Hshiporder, $HshipSATK, $HshipSell, $HshipSP, $HsmonumentName, $HsmonumentNumber, $Hsolarwind, $Hspace, $HspaceEfficiency, $HspaceIncome, $Hsstartturn, $HStotalPoint, $HsurvFlg, $Hsurvivalturn, $HtagName2_, $HthisFile, $HtotalBumon, $HtotalMoney, $HtotalPoint, $Htournament, $HtreeValue, $HturnPrizeNumber, $HturnPrizePoint, $HturnPrizeUnit, $HturnPrizeVarious, $HugDokan, $HugFact, $HugFarm, $HugHasigo, $HugKiti, $HugMax, $HugOil, $HugRoad, $HugSpace, $HugTosi, $human, $HunitFood, $HunitMoney, $HunitOil, $HunitOre, $HunitPop, $HunitTime, $HunitWeapon, $HwarFlg, $HWeatherMax, $Hwflg, $HwinFood, $HwinIsland, $HwinMoney, $HwinWeapon, $imageDir, $lockMode, $toppage, $versionInfo;
	// 거대 지형이 향하고 있는 분을 조사한다($ax와 합해 있다)
	$sx = $x + $ax[$lv];
	$sy = $y + $ay[$lv];
	if (!($sy % 2) && ($y % 2)) { $sx--; }
	if(($sx < 0) || ($sx >= $HislandSize) || ($sy < 0) || ($sy >= $HislandSize)){
		// 범위외의 경우
	}else{
		// 범위내의 경우
		if ($lv < 4){
			$lv += 3;
		}else{
			$lv -= 3;
		}
		// 대응한 거대 지형이 있었을 때
		if (($land[$sx][$sy] == $kind) && ($landValue[$sx][$sy] == $lv)) { return 1; }
	}
	return 0;
}

// 후지산의 주변
function fujiAround($land, $landValue, $x, $y, $lv) {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $H_tagName2, $Haidpop, $Hallyflg, $Hallygroup, $haribote, $Hatkturn, $HbackupTimes, $HbackupTurn, $HbgInfoCell, $HbgTitleCell, $HbigcityFood, $HbigCityMFlg, $HcomBank, $HcomBase, $HcomBioMissile, $HcomBreakwater, $Hcomcolony, $HcomcolonyTurn, $HcomCost, $HcomDbase, $HcomDeathtrap, $HcomDestroy, $HcomDestroy2, $HcomDokan, $HcomDoNothing, $HcomDummy, $HcomEmigration, $HcomFactory, $HcomFarm, $HcomFire, $HcomFlower, $HcomFood, $HcomGiveup, $HcomHaribote, $HcomHospital, $HcomL, $HcommandMax, $HcomManipulate, $HcomMissileDM, $HcomMissileGM, $HcomMissileLD, $HcomMissileMGM, $HcomMissileNCM, $HcomMissileNM, $HcomMissilePLD, $HcomMissilePP, $HcomMissileRM, $HcomMissileRNG, $HcomMissileSPP, $HcomMissileSRM, $HcomMissileST, $HcomMoney, $HcomMonsAid, $HcomMonsEgg, $HcomMonsEnsei, $HcomMonsEsa, $HcomMonsEsaAid, $HcomMonsExer, $HcomMonsSell, $HcomMonsTettai, $HcomMonument, $HcomMountain, $HcomMyhome, $HcomName, $HcomOilBuy, $HcomOilSell, $HcomOMissileMGM, $HcomOMissileNM, $HcomOMissilePP, $HcomOMissileSPP, $HcomOreBuy, $HcomOreSell, $HcomPioneer, $HcomPlant, $HcomPolice, $HcomPort, $HcomPrepare, $HcomPrepare2, $HcomPresent, $HcomPresentAid, $HcomPropaganda, $HcomReclaim, $HcomReclaim2, $HcomSbase, $HcomSBuild, $HcomScity, $HcomSDbase, $HcomSDestroy, $HcomSearch, $HcomSEisei, $HcomSell, $HcomSellTree, $HcomSendMonster, $HcomSendMonsterTurn, $HcomSFactory, $HcomSFarm, $HcomSFood, $HcomShip, $HcomShipbuild, $HcomShipM, $HcomShipSell, $HcomSMissile, $HcomSMissileGM, $HcomSMissileMGM, $HcomSMissilePP, $HcomSMonument, $HcomSOccupy, $HcomSpaceBase, $HcomSpaceFarm, $HcomSpecialSPP, $HcomSPioneer, $HcomSpy, $HcomSSendMonster, $HcomSSendMonsterTurn, $HcomSTManipulate, $HcomSUnit, $HcomTeisatu, $HcomTower, $HcomTrump, $HcomUg, $HcomWarp, $HcomWeponBuy, $HcomWeponSell, $HcomWindmill, $HconsolationMatch, $HcurrentNumber, $HdBaseAuto, $HdefenceHex, $HdefenceSpace, $HdevelopeTurn, $HdirMode, $HdirName, $HdisAEruption, $HdisAkasio, $HdisBHarvest, $HdisCrime, $HdisEarthquake, $HdisEruption, $HdisFallBorder, $HdisFalldown, $HdisFire, $HdisGHarvest, $Hdishangen, $HdisHugeMeteo, $HdisKLimit, $HdisMaizo, $HdisMeteo, $HdisMonsBorder1, $HdisMonsBorder2, $HdisMonsBorder3, $HdisMonsBorder4, $HdisMonsBorder5, $HdisMonster, $HdisMonsterU, $HdisPirate, $HdisPollution, $HdisSeaMonster, $HdisSHugeMeteo, $HdisSpaceMonster1, $HdisSpaceMonster2, $HdisTinka, $HdisTreasureS, $HdisTsunami, $HdisTyphoon, $HdisUN, $HdisVGHarvest, $HearthAttack, $HeatenFood, $helpDir, $HfightMem, $HfightTurn, $HfinalTurn, $HgiveupTurn, $HhistoryMax, $HidToName, $HidToNumber, $HidToNumberR, $HinterTime, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HlandAegisShip, $HlandAirport, $HlandAmusement, $HlandBalloonS, $HlandBank, $HlandBase, $HlandBigcity, $HlandBreakwater, $HlandCasino, $HlandCoupleRock, $HlandDeathtrap, $HlandDefence, $HlandDokan, $HlandDome, $HlandEarth, $HlandExpo, $HlandFactory, $HlandFarm, $HlandFire, $HlandFishLShip, $HlandFishMShip, $HlandFishSShip, $HlandFlower, $HlandForest, $HlandFuji, $HlandGhostShip, $HlandHaribote, $HlandHospital, $HlandHugecity, $HlandIceFloe, $HlandKInora, $HlandMegacity, $HlandMegaFact, $HlandMegaFarm, $HlandMegatower, $HlandMonsShip, $HlandMonster, $HlandMonument, $HlandMountain, $HlandMyhome, $HlandOcean, $HlandOil, $HlandOPlayer, $HlandOsen, $HlandPark, $HlandPirate, $HlandPlains, $HlandPolice, $HlandPort, $HlandProbeShip, $HlandSAEisei, $HlandSbase, $HlandSchool, $HlandSCity, $HlandSDefence, $HlandSea, $HlandSeisei, $HlandSFactory, $HlandSFarm, $HlandSlum, $HlandSMonument, $HlandSpaceBase, $HlandStadium, $HlandSunit, $HlandTcity, $HlandTitanic, $HlandTower, $HlandTown, $HlandTreasureS, $HlandTrump, $HlandWarp, $HlandWarpR, $HlandWaste, $HlandWindmill, $HlandWingDragon, $HlandZoo, $HlateLogPool, $HlogMax, $HlogOmit2, $HlogPool, $HmaxdisPollution, $HmaxExpPoint, $HmaxIsland, $HmonsBtlMaxHp, $HmonsBtlMaxPa, $HmonsterAGI, $HmonsterBHP, $HmonsterCLS, $HmonsterDEF, $HmonsterDestroy, $HmonsterDHP, $HmonsterExp, $HmonsterGRP, $HmonsterL1, $HmonsterL1Num, $HmonsterL2, $HmonsterL2Num, $HmonsterL3, $HmonsterL3Num, $HmonsterL4, $HmonsterL4Num, $HmonsterL5, $HmonsterL5Num, $HmonsterName, $HmonsterNumber, $HmonsterS, $HmonsterSEI, $HmonsterSKL, $HmonsterSP, $HmonsterSpecial, $HmonsterSTR, $HmonsterValue, $Hmonth, $HmonumentMissile, $HmonumentName, $HmonumentRocket, $Hocean, $HoceanSize, $HoilMoney, $HoilRatio, $hp, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $Hprize, $HprizeV, $HpunishInfo, $HrepeatTurn, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $HseaChk, $HsecretLogPool, $HsEisei, $HshipEX, $HshipFood, $HshipHP, $HshipKAI, $HshipMATK, $HshipMoney, $HshipName, $Hshiporder, $HshipSATK, $HshipSell, $HshipSP, $HsmonumentName, $HsmonumentNumber, $Hsolarwind, $Hspace, $HspaceEfficiency, $HspaceIncome, $Hsstartturn, $HStotalPoint, $HsurvFlg, $Hsurvivalturn, $HtagName2_, $HthisFile, $HtotalBumon, $HtotalMoney, $HtotalPoint, $Htournament, $HtreeValue, $HturnPrizeNumber, $HturnPrizePoint, $HturnPrizeUnit, $HturnPrizeVarious, $HugDokan, $HugFact, $HugFarm, $HugHasigo, $HugKiti, $HugMax, $HugOil, $HugRoad, $HugSpace, $HugTosi, $human, $HunitFood, $HunitMoney, $HunitOil, $HunitOre, $HunitPop, $HunitTime, $HunitWeapon, $HwarFlg, $HWeatherMax, $Hwflg, $HwinFood, $HwinIsland, $HwinMoney, $HwinWeapon, $imageDir, $lockMode, $toppage, $versionInfo;
	$i = null; $sx = null; $sy = null;
	if($lv == 0){
		for($i = 3; $i < 5; $i++){
			$sx = $x + $ax[$i];
			$sy = $y + $ay[$i];
			if (!($sy % 2) && ($y % 2)) { $sx--; }
			if(($sx < 0) || ($sx >= $HislandSize) || ($sy < 0) || ($sy >= $HislandSize)){
			}else{
				$land[$sx][$sy] = $HlandFuji;
				$landValue[$sx][$sy] = $i - 2;
			}
		}
	}elseif($lv == 1){
		$sx = $x + $ax[6];
		$sy = $y + $ay[6];
		if (!($sy % 2) && ($y % 2)) { $sx--; }
		if($land[$sx][$sy] != $HlandFuji){
			$land[$x][$y] = $HlandWaste;
			$landValue[$x][$y] = 1;
		}
	}elseif($lv == 2){
		$sx = $x + $ax[1];
		$sy = $y + $ay[1];
		if (!($sy % 2) && ($y % 2)) { $sx--; }
		if($land[$sx][$sy] != $HlandFuji){
			$land[$x][$y] = $HlandWaste;
			$landValue[$x][$y] = 1;
		}
	}
	return;
}

function kinoraDamage(&$land, &$landValue, $x, $y, $lv) {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $H_tagName2, $Haidpop, $Hallyflg, $Hallygroup, $haribote, $Hatkturn, $HbackupTimes, $HbackupTurn, $HbgInfoCell, $HbgTitleCell, $HbigcityFood, $HbigCityMFlg, $HcomBank, $HcomBase, $HcomBioMissile, $HcomBreakwater, $Hcomcolony, $HcomcolonyTurn, $HcomCost, $HcomDbase, $HcomDeathtrap, $HcomDestroy, $HcomDestroy2, $HcomDokan, $HcomDoNothing, $HcomDummy, $HcomEmigration, $HcomFactory, $HcomFarm, $HcomFire, $HcomFlower, $HcomFood, $HcomGiveup, $HcomHaribote, $HcomHospital, $HcomL, $HcommandMax, $HcomManipulate, $HcomMissileDM, $HcomMissileGM, $HcomMissileLD, $HcomMissileMGM, $HcomMissileNCM, $HcomMissileNM, $HcomMissilePLD, $HcomMissilePP, $HcomMissileRM, $HcomMissileRNG, $HcomMissileSPP, $HcomMissileSRM, $HcomMissileST, $HcomMoney, $HcomMonsAid, $HcomMonsEgg, $HcomMonsEnsei, $HcomMonsEsa, $HcomMonsEsaAid, $HcomMonsExer, $HcomMonsSell, $HcomMonsTettai, $HcomMonument, $HcomMountain, $HcomMyhome, $HcomName, $HcomOilBuy, $HcomOilSell, $HcomOMissileMGM, $HcomOMissileNM, $HcomOMissilePP, $HcomOMissileSPP, $HcomOreBuy, $HcomOreSell, $HcomPioneer, $HcomPlant, $HcomPolice, $HcomPort, $HcomPrepare, $HcomPrepare2, $HcomPresent, $HcomPresentAid, $HcomPropaganda, $HcomReclaim, $HcomReclaim2, $HcomSbase, $HcomSBuild, $HcomScity, $HcomSDbase, $HcomSDestroy, $HcomSearch, $HcomSEisei, $HcomSell, $HcomSellTree, $HcomSendMonster, $HcomSendMonsterTurn, $HcomSFactory, $HcomSFarm, $HcomSFood, $HcomShip, $HcomShipbuild, $HcomShipM, $HcomShipSell, $HcomSMissile, $HcomSMissileGM, $HcomSMissileMGM, $HcomSMissilePP, $HcomSMonument, $HcomSOccupy, $HcomSpaceBase, $HcomSpaceFarm, $HcomSpecialSPP, $HcomSPioneer, $HcomSpy, $HcomSSendMonster, $HcomSSendMonsterTurn, $HcomSTManipulate, $HcomSUnit, $HcomTeisatu, $HcomTower, $HcomTrump, $HcomUg, $HcomWarp, $HcomWeponBuy, $HcomWeponSell, $HcomWindmill, $HconsolationMatch, $HcurrentNumber, $HdBaseAuto, $HdefenceHex, $HdefenceSpace, $HdevelopeTurn, $HdirMode, $HdirName, $HdisAEruption, $HdisAkasio, $HdisBHarvest, $HdisCrime, $HdisEarthquake, $HdisEruption, $HdisFallBorder, $HdisFalldown, $HdisFire, $HdisGHarvest, $Hdishangen, $HdisHugeMeteo, $HdisKLimit, $HdisMaizo, $HdisMeteo, $HdisMonsBorder1, $HdisMonsBorder2, $HdisMonsBorder3, $HdisMonsBorder4, $HdisMonsBorder5, $HdisMonster, $HdisMonsterU, $HdisPirate, $HdisPollution, $HdisSeaMonster, $HdisSHugeMeteo, $HdisSpaceMonster1, $HdisSpaceMonster2, $HdisTinka, $HdisTreasureS, $HdisTsunami, $HdisTyphoon, $HdisUN, $HdisVGHarvest, $HearthAttack, $HeatenFood, $helpDir, $HfightMem, $HfightTurn, $HfinalTurn, $HgiveupTurn, $HhistoryMax, $HidToName, $HidToNumber, $HidToNumberR, $HinterTime, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HlandAegisShip, $HlandAirport, $HlandAmusement, $HlandBalloonS, $HlandBank, $HlandBase, $HlandBigcity, $HlandBreakwater, $HlandCasino, $HlandCoupleRock, $HlandDeathtrap, $HlandDefence, $HlandDokan, $HlandDome, $HlandEarth, $HlandExpo, $HlandFactory, $HlandFarm, $HlandFire, $HlandFishLShip, $HlandFishMShip, $HlandFishSShip, $HlandFlower, $HlandForest, $HlandFuji, $HlandGhostShip, $HlandHaribote, $HlandHospital, $HlandHugecity, $HlandIceFloe, $HlandKInora, $HlandMegacity, $HlandMegaFact, $HlandMegaFarm, $HlandMegatower, $HlandMonsShip, $HlandMonster, $HlandMonument, $HlandMountain, $HlandMyhome, $HlandOcean, $HlandOil, $HlandOPlayer, $HlandOsen, $HlandPark, $HlandPirate, $HlandPlains, $HlandPolice, $HlandPort, $HlandProbeShip, $HlandSAEisei, $HlandSbase, $HlandSchool, $HlandSCity, $HlandSDefence, $HlandSea, $HlandSeisei, $HlandSFactory, $HlandSFarm, $HlandSlum, $HlandSMonument, $HlandSpaceBase, $HlandStadium, $HlandSunit, $HlandTcity, $HlandTitanic, $HlandTower, $HlandTown, $HlandTreasureS, $HlandTrump, $HlandWarp, $HlandWarpR, $HlandWaste, $HlandWindmill, $HlandWingDragon, $HlandZoo, $HlateLogPool, $HlogMax, $HlogOmit2, $HlogPool, $HmaxdisPollution, $HmaxExpPoint, $HmaxIsland, $HmonsBtlMaxHp, $HmonsBtlMaxPa, $HmonsterAGI, $HmonsterBHP, $HmonsterCLS, $HmonsterDEF, $HmonsterDestroy, $HmonsterDHP, $HmonsterExp, $HmonsterGRP, $HmonsterL1, $HmonsterL1Num, $HmonsterL2, $HmonsterL2Num, $HmonsterL3, $HmonsterL3Num, $HmonsterL4, $HmonsterL4Num, $HmonsterL5, $HmonsterL5Num, $HmonsterName, $HmonsterNumber, $HmonsterS, $HmonsterSEI, $HmonsterSKL, $HmonsterSP, $HmonsterSpecial, $HmonsterSTR, $HmonsterValue, $Hmonth, $HmonumentMissile, $HmonumentName, $HmonumentRocket, $Hocean, $HoceanSize, $HoilMoney, $HoilRatio, $hp, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $Hprize, $HprizeV, $HpunishInfo, $HrepeatTurn, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $HseaChk, $HsecretLogPool, $HsEisei, $HshipEX, $HshipFood, $HshipHP, $HshipKAI, $HshipMATK, $HshipMoney, $HshipName, $Hshiporder, $HshipSATK, $HshipSell, $HshipSP, $HsmonumentName, $HsmonumentNumber, $Hsolarwind, $Hspace, $HspaceEfficiency, $HspaceIncome, $Hsstartturn, $HStotalPoint, $HsurvFlg, $Hsurvivalturn, $HtagName2_, $HthisFile, $HtotalBumon, $HtotalMoney, $HtotalPoint, $Htournament, $HtreeValue, $HturnPrizeNumber, $HturnPrizePoint, $HturnPrizeUnit, $HturnPrizeVarious, $HugDokan, $HugFact, $HugFarm, $HugHasigo, $HugKiti, $HugMax, $HugOil, $HugRoad, $HugSpace, $HugTosi, $human, $HunitFood, $HunitMoney, $HunitOil, $HunitOre, $HunitPop, $HunitTime, $HunitWeapon, $HwarFlg, $HWeatherMax, $Hwflg, $HwinFood, $HwinIsland, $HwinMoney, $HwinWeapon, $imageDir, $lockMode, $toppage, $versionInfo;
	if ($lv < 4){
		$lv += 3;
	}else{
		$lv -= 3;
	}
	$sx = $x + $ax[$lv];
	$sy = $y + $ay[$lv];
	if (!($sy % 2) && ($y % 2)) { $sx--; }
	if(($sx < 0) || ($sx >= $HislandSize) || ($sy < 0) || ($sy >= $HislandSize)){
	}elseif($land[$sx][$sy] == $HlandKInora){
		$landValue[$sx][$sy] -= 100;
	}
	return;
}

// 유입한 사람을 각 마을에 배분한다.
function refugees($boat, &$tIsland) {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $H_tagName2, $Haidpop, $Hallyflg, $Hallygroup, $haribote, $Hatkturn, $HbackupTimes, $HbackupTurn, $HbgInfoCell, $HbgTitleCell, $HbigcityFood, $HbigCityMFlg, $HcomBank, $HcomBase, $HcomBioMissile, $HcomBreakwater, $Hcomcolony, $HcomcolonyTurn, $HcomCost, $HcomDbase, $HcomDeathtrap, $HcomDestroy, $HcomDestroy2, $HcomDokan, $HcomDoNothing, $HcomDummy, $HcomEmigration, $HcomFactory, $HcomFarm, $HcomFire, $HcomFlower, $HcomFood, $HcomGiveup, $HcomHaribote, $HcomHospital, $HcomL, $HcommandMax, $HcomManipulate, $HcomMissileDM, $HcomMissileGM, $HcomMissileLD, $HcomMissileMGM, $HcomMissileNCM, $HcomMissileNM, $HcomMissilePLD, $HcomMissilePP, $HcomMissileRM, $HcomMissileRNG, $HcomMissileSPP, $HcomMissileSRM, $HcomMissileST, $HcomMoney, $HcomMonsAid, $HcomMonsEgg, $HcomMonsEnsei, $HcomMonsEsa, $HcomMonsEsaAid, $HcomMonsExer, $HcomMonsSell, $HcomMonsTettai, $HcomMonument, $HcomMountain, $HcomMyhome, $HcomName, $HcomOilBuy, $HcomOilSell, $HcomOMissileMGM, $HcomOMissileNM, $HcomOMissilePP, $HcomOMissileSPP, $HcomOreBuy, $HcomOreSell, $HcomPioneer, $HcomPlant, $HcomPolice, $HcomPort, $HcomPrepare, $HcomPrepare2, $HcomPresent, $HcomPresentAid, $HcomPropaganda, $HcomReclaim, $HcomReclaim2, $HcomSbase, $HcomSBuild, $HcomScity, $HcomSDbase, $HcomSDestroy, $HcomSearch, $HcomSEisei, $HcomSell, $HcomSellTree, $HcomSendMonster, $HcomSendMonsterTurn, $HcomSFactory, $HcomSFarm, $HcomSFood, $HcomShip, $HcomShipbuild, $HcomShipM, $HcomShipSell, $HcomSMissile, $HcomSMissileGM, $HcomSMissileMGM, $HcomSMissilePP, $HcomSMonument, $HcomSOccupy, $HcomSpaceBase, $HcomSpaceFarm, $HcomSpecialSPP, $HcomSPioneer, $HcomSpy, $HcomSSendMonster, $HcomSSendMonsterTurn, $HcomSTManipulate, $HcomSUnit, $HcomTeisatu, $HcomTower, $HcomTrump, $HcomUg, $HcomWarp, $HcomWeponBuy, $HcomWeponSell, $HcomWindmill, $HconsolationMatch, $HcurrentNumber, $HdBaseAuto, $HdefenceHex, $HdefenceSpace, $HdevelopeTurn, $HdirMode, $HdirName, $HdisAEruption, $HdisAkasio, $HdisBHarvest, $HdisCrime, $HdisEarthquake, $HdisEruption, $HdisFallBorder, $HdisFalldown, $HdisFire, $HdisGHarvest, $Hdishangen, $HdisHugeMeteo, $HdisKLimit, $HdisMaizo, $HdisMeteo, $HdisMonsBorder1, $HdisMonsBorder2, $HdisMonsBorder3, $HdisMonsBorder4, $HdisMonsBorder5, $HdisMonster, $HdisMonsterU, $HdisPirate, $HdisPollution, $HdisSeaMonster, $HdisSHugeMeteo, $HdisSpaceMonster1, $HdisSpaceMonster2, $HdisTinka, $HdisTreasureS, $HdisTsunami, $HdisTyphoon, $HdisUN, $HdisVGHarvest, $HearthAttack, $HeatenFood, $helpDir, $HfightMem, $HfightTurn, $HfinalTurn, $HgiveupTurn, $HhistoryMax, $HidToName, $HidToNumber, $HidToNumberR, $HinterTime, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HlandAegisShip, $HlandAirport, $HlandAmusement, $HlandBalloonS, $HlandBank, $HlandBase, $HlandBigcity, $HlandBreakwater, $HlandCasino, $HlandCoupleRock, $HlandDeathtrap, $HlandDefence, $HlandDokan, $HlandDome, $HlandEarth, $HlandExpo, $HlandFactory, $HlandFarm, $HlandFire, $HlandFishLShip, $HlandFishMShip, $HlandFishSShip, $HlandFlower, $HlandForest, $HlandFuji, $HlandGhostShip, $HlandHaribote, $HlandHospital, $HlandHugecity, $HlandIceFloe, $HlandKInora, $HlandMegacity, $HlandMegaFact, $HlandMegaFarm, $HlandMegatower, $HlandMonsShip, $HlandMonster, $HlandMonument, $HlandMountain, $HlandMyhome, $HlandOcean, $HlandOil, $HlandOPlayer, $HlandOsen, $HlandPark, $HlandPirate, $HlandPlains, $HlandPolice, $HlandPort, $HlandProbeShip, $HlandSAEisei, $HlandSbase, $HlandSchool, $HlandSCity, $HlandSDefence, $HlandSea, $HlandSeisei, $HlandSFactory, $HlandSFarm, $HlandSlum, $HlandSMonument, $HlandSpaceBase, $HlandStadium, $HlandSunit, $HlandTcity, $HlandTitanic, $HlandTower, $HlandTown, $HlandTreasureS, $HlandTrump, $HlandWarp, $HlandWarpR, $HlandWaste, $HlandWindmill, $HlandWingDragon, $HlandZoo, $HlateLogPool, $HlogMax, $HlogOmit2, $HlogPool, $HmaxdisPollution, $HmaxExpPoint, $HmaxIsland, $HmonsBtlMaxHp, $HmonsBtlMaxPa, $HmonsterAGI, $HmonsterBHP, $HmonsterCLS, $HmonsterDEF, $HmonsterDestroy, $HmonsterDHP, $HmonsterExp, $HmonsterGRP, $HmonsterL1, $HmonsterL1Num, $HmonsterL2, $HmonsterL2Num, $HmonsterL3, $HmonsterL3Num, $HmonsterL4, $HmonsterL4Num, $HmonsterL5, $HmonsterL5Num, $HmonsterName, $HmonsterNumber, $HmonsterS, $HmonsterSEI, $HmonsterSKL, $HmonsterSP, $HmonsterSpecial, $HmonsterSTR, $HmonsterValue, $Hmonth, $HmonumentMissile, $HmonumentName, $HmonumentRocket, $Hocean, $HoceanSize, $HoilMoney, $HoilRatio, $hp, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $Hprize, $HprizeV, $HpunishInfo, $HrepeatTurn, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $HseaChk, $HsecretLogPool, $HsEisei, $HshipEX, $HshipFood, $HshipHP, $HshipKAI, $HshipMATK, $HshipMoney, $HshipName, $Hshiporder, $HshipSATK, $HshipSell, $HshipSP, $HsmonumentName, $HsmonumentNumber, $Hsolarwind, $Hspace, $HspaceEfficiency, $HspaceIncome, $Hsstartturn, $HStotalPoint, $HsurvFlg, $Hsurvivalturn, $HtagName2_, $HthisFile, $HtotalBumon, $HtotalMoney, $HtotalPoint, $Htournament, $HtreeValue, $HturnPrizeNumber, $HturnPrizePoint, $HturnPrizeUnit, $HturnPrizeVarious, $HugDokan, $HugFact, $HugFarm, $HugHasigo, $HugKiti, $HugMax, $HugOil, $HugRoad, $HugSpace, $HugTosi, $human, $HunitFood, $HunitMoney, $HunitOil, $HunitOre, $HunitPop, $HunitTime, $HunitWeapon, $HwarFlg, $HWeatherMax, $Hwflg, $HwinFood, $HwinIsland, $HwinMoney, $HwinWeapon, $imageDir, $lockMode, $toppage, $versionInfo;
	$bx = null; $by = null; $i = null;
	$achive = 0; $tLand =& $tIsland['land']; $tLandValue =& $tIsland['landValue'];
	for($i = 0; ($i < $HpointNumber && $boat > 0); $i++){
		$bx = $Hrpx[$i];
		$by = $Hrpy[$i];
		if(($tLand[$bx][$by] == $HlandTown) || ($tLand[$bx][$by] == $HlandSlum)){
			// 마을, 슬럼가의 경우
			$lv = $tLandValue[$bx][$by];
			if($boat > 50){
				$lv += 50;
				$boat -= 50;
				$achive += 50;
			}else{
				$lv += $boat;
				$achive += $boat;
				$boat = 0;
			}
			if($lv > 200){
				$boat += ($lv - 200);
				$achive -= ($lv - 200);
				$lv = 200;
			}
			$tLandValue[$bx][$by] = $lv;
		}elseif($tLand[$bx][$by] == $HlandPlains){
			// 평지의 경우
			$tLand[$bx][$by] = $HlandTown;
			if($boat > 10){
				$tLandValue[$bx][$by] = 5;
				$boat -= 10;
				$achive += 5;
			}elseif($boat > 5){
				$tLandValue[$bx][$by] = $boat - 5;
				$achive += $boat - 5;
				$boat = 0;
			}
		}
		if ($boat <= 0) { break; }
	}
	return $achive;
}

// 괴수 이동
function monmove(&$island, $x, $y, $mode) {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $H_tagName2, $Haidpop, $Hallyflg, $Hallygroup, $haribote, $Hatkturn, $HbackupTimes, $HbackupTurn, $HbgInfoCell, $HbgTitleCell, $HbigcityFood, $HbigCityMFlg, $HcomBank, $HcomBase, $HcomBioMissile, $HcomBreakwater, $Hcomcolony, $HcomcolonyTurn, $HcomCost, $HcomDbase, $HcomDeathtrap, $HcomDestroy, $HcomDestroy2, $HcomDokan, $HcomDoNothing, $HcomDummy, $HcomEmigration, $HcomFactory, $HcomFarm, $HcomFire, $HcomFlower, $HcomFood, $HcomGiveup, $HcomHaribote, $HcomHospital, $HcomL, $HcommandMax, $HcomManipulate, $HcomMissileDM, $HcomMissileGM, $HcomMissileLD, $HcomMissileMGM, $HcomMissileNCM, $HcomMissileNM, $HcomMissilePLD, $HcomMissilePP, $HcomMissileRM, $HcomMissileRNG, $HcomMissileSPP, $HcomMissileSRM, $HcomMissileST, $HcomMoney, $HcomMonsAid, $HcomMonsEgg, $HcomMonsEnsei, $HcomMonsEsa, $HcomMonsEsaAid, $HcomMonsExer, $HcomMonsSell, $HcomMonsTettai, $HcomMonument, $HcomMountain, $HcomMyhome, $HcomName, $HcomOilBuy, $HcomOilSell, $HcomOMissileMGM, $HcomOMissileNM, $HcomOMissilePP, $HcomOMissileSPP, $HcomOreBuy, $HcomOreSell, $HcomPioneer, $HcomPlant, $HcomPolice, $HcomPort, $HcomPrepare, $HcomPrepare2, $HcomPresent, $HcomPresentAid, $HcomPropaganda, $HcomReclaim, $HcomReclaim2, $HcomSbase, $HcomSBuild, $HcomScity, $HcomSDbase, $HcomSDestroy, $HcomSearch, $HcomSEisei, $HcomSell, $HcomSellTree, $HcomSendMonster, $HcomSendMonsterTurn, $HcomSFactory, $HcomSFarm, $HcomSFood, $HcomShip, $HcomShipbuild, $HcomShipM, $HcomShipSell, $HcomSMissile, $HcomSMissileGM, $HcomSMissileMGM, $HcomSMissilePP, $HcomSMonument, $HcomSOccupy, $HcomSpaceBase, $HcomSpaceFarm, $HcomSpecialSPP, $HcomSPioneer, $HcomSpy, $HcomSSendMonster, $HcomSSendMonsterTurn, $HcomSTManipulate, $HcomSUnit, $HcomTeisatu, $HcomTower, $HcomTrump, $HcomUg, $HcomWarp, $HcomWeponBuy, $HcomWeponSell, $HcomWindmill, $HconsolationMatch, $HcurrentNumber, $HdBaseAuto, $HdefenceHex, $HdefenceSpace, $HdevelopeTurn, $HdirMode, $HdirName, $HdisAEruption, $HdisAkasio, $HdisBHarvest, $HdisCrime, $HdisEarthquake, $HdisEruption, $HdisFallBorder, $HdisFalldown, $HdisFire, $HdisGHarvest, $Hdishangen, $HdisHugeMeteo, $HdisKLimit, $HdisMaizo, $HdisMeteo, $HdisMonsBorder1, $HdisMonsBorder2, $HdisMonsBorder3, $HdisMonsBorder4, $HdisMonsBorder5, $HdisMonster, $HdisMonsterU, $HdisPirate, $HdisPollution, $HdisSeaMonster, $HdisSHugeMeteo, $HdisSpaceMonster1, $HdisSpaceMonster2, $HdisTinka, $HdisTreasureS, $HdisTsunami, $HdisTyphoon, $HdisUN, $HdisVGHarvest, $HearthAttack, $HeatenFood, $helpDir, $HfightMem, $HfightTurn, $HfinalTurn, $HgiveupTurn, $HhistoryMax, $HidToName, $HidToNumber, $HidToNumberR, $HinterTime, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HlandAegisShip, $HlandAirport, $HlandAmusement, $HlandBalloonS, $HlandBank, $HlandBase, $HlandBigcity, $HlandBreakwater, $HlandCasino, $HlandCoupleRock, $HlandDeathtrap, $HlandDefence, $HlandDokan, $HlandDome, $HlandEarth, $HlandExpo, $HlandFactory, $HlandFarm, $HlandFire, $HlandFishLShip, $HlandFishMShip, $HlandFishSShip, $HlandFlower, $HlandForest, $HlandFuji, $HlandGhostShip, $HlandHaribote, $HlandHospital, $HlandHugecity, $HlandIceFloe, $HlandKInora, $HlandMegacity, $HlandMegaFact, $HlandMegaFarm, $HlandMegatower, $HlandMonsShip, $HlandMonster, $HlandMonument, $HlandMountain, $HlandMyhome, $HlandOcean, $HlandOil, $HlandOPlayer, $HlandOsen, $HlandPark, $HlandPirate, $HlandPlains, $HlandPolice, $HlandPort, $HlandProbeShip, $HlandSAEisei, $HlandSbase, $HlandSchool, $HlandSCity, $HlandSDefence, $HlandSea, $HlandSeisei, $HlandSFactory, $HlandSFarm, $HlandSlum, $HlandSMonument, $HlandSpaceBase, $HlandStadium, $HlandSunit, $HlandTcity, $HlandTitanic, $HlandTower, $HlandTown, $HlandTreasureS, $HlandTrump, $HlandWarp, $HlandWarpR, $HlandWaste, $HlandWindmill, $HlandWingDragon, $HlandZoo, $HlateLogPool, $HlogMax, $HlogOmit2, $HlogPool, $HmaxdisPollution, $HmaxExpPoint, $HmaxIsland, $HmonsBtlMaxHp, $HmonsBtlMaxPa, $HmonsterAGI, $HmonsterBHP, $HmonsterCLS, $HmonsterDEF, $HmonsterDestroy, $HmonsterDHP, $HmonsterExp, $HmonsterGRP, $HmonsterL1, $HmonsterL1Num, $HmonsterL2, $HmonsterL2Num, $HmonsterL3, $HmonsterL3Num, $HmonsterL4, $HmonsterL4Num, $HmonsterL5, $HmonsterL5Num, $HmonsterName, $HmonsterNumber, $HmonsterS, $HmonsterSEI, $HmonsterSKL, $HmonsterSP, $HmonsterSpecial, $HmonsterSTR, $HmonsterValue, $Hmonth, $HmonumentMissile, $HmonumentName, $HmonumentRocket, $Hocean, $HoceanSize, $HoilMoney, $HoilRatio, $hp, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $Hprize, $HprizeV, $HpunishInfo, $HrepeatTurn, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $HseaChk, $HsecretLogPool, $HsEisei, $HshipEX, $HshipFood, $HshipHP, $HshipKAI, $HshipMATK, $HshipMoney, $HshipName, $Hshiporder, $HshipSATK, $HshipSell, $HshipSP, $HsmonumentName, $HsmonumentNumber, $Hsolarwind, $Hspace, $HspaceEfficiency, $HspaceIncome, $Hsstartturn, $HStotalPoint, $HsurvFlg, $Hsurvivalturn, $HtagName2_, $HthisFile, $HtotalBumon, $HtotalMoney, $HtotalPoint, $Htournament, $HtreeValue, $HturnPrizeNumber, $HturnPrizePoint, $HturnPrizeUnit, $HturnPrizeVarious, $HugDokan, $HugFact, $HugFarm, $HugHasigo, $HugKiti, $HugMax, $HugOil, $HugRoad, $HugSpace, $HugTosi, $human, $HunitFood, $HunitMoney, $HunitOil, $HunitOre, $HunitPop, $HunitTime, $HunitWeapon, $HwarFlg, $HWeatherMax, $Hwflg, $HwinFood, $HwinIsland, $HwinMoney, $HwinWeapon, $imageDir, $lockMode, $toppage, $versionInfo;
	
	// 도출치
	$name = $island['name']; $id = $island['id']; $land =& $island['land']; $landValue =& $island['landValue']; $land2 =& $island['land2']; $landValue2 =& $island['landValue2']; $nation =& $island['nation'];
	$i = null; $d = null; $sx = null; $sy = null;
	if($land[$x][$y] == $HlandKInora){
		// 구상 이노라

		$kname = landName($HlandKInora, 0);
		
		// 데미지 계산 처리
		$hp = hako_pick(bigMonsterSpec($landValue[$x][$y]), array(1));
		$damage;
		for($i = 1; $i < 7; $i++){
			$sx = $x + $ax[$i];
			$sy = $y + $ay[$i];
			if (!($sy % 2) && ($y % 2)) { $sx--; }
			if(($sx < 0) || ($sx >= $HislandSize) || ($sy < 0) || ($sy >= $HislandSize)){
			}elseif($land[$sx][$sy] == $HlandKInora){
				if ($landValue[$sx][$sy] > 100) { $damage += intval($landValue[$sx][$sy] / 100); }
			}
		}
		if($damage >= $hp){
			// 넘어뜨렸다
			$tn = $HidToNumber[$lastDamage];
			if($tn == ''){
				// 쓰러트린 도이 없는 경우는 죽지 않는다
				if ($hp > 1) { $landValue[$x][$y] -= ($hp - 1) * 100; }
			}else{
				$tIsland =& $Hislands[$tn];
				$tName = $tIsland['name'];
				
				logOut("${HtagName_}${name}${AfterName}($x, $y)${H_tagName} 의 <B>괴수$kname</B>는 힘이 다해 넘어졌습니다. ",$lastDamage, $id);

				hako_open('ROUT',">>${HlogdirName}/ranking.log");
				hako_write('ROUT', "$HislandTurn,$lastDamage,$id,$kname\n");
				hako_close('ROUT');
				
				$lastDamage = 0;
				$tIsland['money'] += 20000;
				$prize = $tIsland['prize'];
				preg_match('/([0-9]*),([0-9]*),(.*)/', $prize, $_m);
				list($flags,$monsters,$turns) = array($_m[1],$_m[2],$_m[3]);
				if(!($flags & 2048)){
					$flags |= 2048;
					logPrize($lastDamage, $tName, $Hprize[11]);
				}
				$tIsland['prize'] = "$flags,$monsters,$turns";
				$tIsland['evil'] = 20000; # 황금기
				kinoraDel($land, $landValue, $x, $y);
				return array($x, $y);
			}
		}else{
			// 데미지
			$landValue[$x][$y] -= $damage * 100;
		}
		$sx = random($HislandSize);
		$sy = random($HislandSize);
		$lv = $landValue[$x][$y];
		kinoraDel($land, $landValue, $x, $y);
		if(($i > 6) && (chkAround($land, $sx, $sy, $HlandKInora, 7) == 0)){
			// 점프 한다
			if($lv < 10000){
				// 다른 도에 난다
				$INumber = randomArray($HislandNumber);
				$tIsland =& $Hislands[$INumber[random($HislandNumber)]];
				$tId = $tIsland['id']; $tName = $tIsland['name']; $tLand =& $tIsland['land']; $tLandValue =& $tIsland['landValue'];
				if(($tIsland['turnsu'] + $tIsland['evil'] < $HdisUN) || ($tIsland['evil'] == 0)){
					// 상대가 도상국이기 때문에 이동하지 않는다
				}else{
					logEventP($id, $name,"($x, $y)", "의<B>괴수$kname</B>는,${HtagName_}$tName$AfterName${H_tagName}에 날아올랐습니다.");
					logMonsCome($tId, $tName, $kname, "($sx, $sy)", landName($tLand[$sx][$sy], $tLandValue[$sx][$sy]));
					$tLand[$sx][$sy] = $HlandKInora;
					$tLandValue[$sx][$sy] = $lv + 50000;
					kinoraMake($tLand, $tLandValue, $sx, $sy);
					return array($sx, $sy);
				}
			}elseif(random(2) == 0){

				$lv -= 10000;
			}
			$land[$sx][$sy] = $HlandKInora;
			$landValue[$sx][$sy] = $lv;
			logEventP($id, $name,"($sx, $sy)", "에<B>괴수 $kname</B>가 점프 해 주위 1헥스를 짓밟을 수 있었습니다.");
		}else{
			$sx = $x;
			$sy = $y;
			$land[$sx][$sy] = $HlandKInora;
			$landValue[$sx][$sy] = $lv;
		}
		kinoraMake($land, $landValue, $sx, $sy);
		return array($sx, $sy);
	}
	
	list($mKind, $mName, $mHp) = monsterSpec($landValue[$x][$y]);
	$special = $HmonsterSpecial[$mKind];
	
	if($mode == 3){
		if((random(4) != 0) &&

			(($mKind == 32) || ($mKind == 33) || ($mKind == 35))){
			// 우주 어딘지 모르게 중심에
			$c = $HislandSize / 2 - 1;
			if(random(3) == 0){
				if($x == $c){
				}elseif($x - $c > 0){
					// 왼쪽으로
					$island['manipulate'] = 5;
				}else{
					// 오른쪽으로
					$island['manipulate'] = 2;
				}
			}else{
				if($y == $c){
				}elseif($y - $c > 0){
					// 위에
					$island['manipulate'] = (random(2) == 0) ? 1 : 6;
				}else{
					// 아래에
					$island['manipulate'] = (random(2) == 0) ? 3 : 4;
				}
			}
		}else{
			$island['manipulate'] = 0;
		}
	}
	// 움직일 방향을 결정
	for($i = 0; $i < 3; $i++){
		if($island['manipulate'] == 0){
			$d = random(6) + 1;
		}else{ # 조종되고 있을 때
			$d = $island['manipulate'];
		}
		$sx = $x + $ax[$d];
		$sy = $y + $ay[$d];

		if (!($sy % 2) && ($y % 2)) { $sx--; }
		if (($sx < 0) || ($sx >= $HislandSize) || ($sy < 0) || ($sy >= $HislandSize)) { continue; }
		
		if((($land[$sx][$sy] == $HlandDefence) && ($landValue[$sx][$sy] == 3)) ||
			($land[$sx][$sy] == $HlandMountain) || ($land[$sx][$sy] == $HlandKInora) ||
			($land[$sx][$sy] == $HlandMyhome) || ($land[$sx][$sy] == $HlandOcean) ||
			($land[$sx][$sy] == $HlandFuji) || ($land[$sx][$sy] == $HlandMonument) ||
			($land[$sx][$sy] == $HlandSMonument) || ($land[$sx][$sy] == $HlandMonster)){
continue;
		}
		if(($mKind == 9) || ($mKind == 21) || ($mode == 3)){
			// 시 이노라 , 시고스트, 우주
break;
		}elseif($mKind == 16){
			// 매립 이노라
			if (($HseaChk[$land[$sx][$sy]] == 1) || ($land[$sx][$sy] == $HlandWarp)) { break; }
		}else{
			// 육지라면 이동
			if (($HseaChk[$land[$sx][$sy]] == 0)) { break; }
		}
	}
	if ($i == 3) { return array($x, $y); }

	// 움직인 앞의 지형에 의해 메세지
	$l = $land[$sx][$sy];
	$lv = $landValue[$sx][$sy];
	$lName = landName($l, $lv);
	$point = "($sx, $sy)";

	if($l == $HlandEarth){
		// 지구에 도달
		$HearthAttack++;
		$HdisMonster *= 2;
	}elseif($l == $HlandOPlayer){
		// 해역 괴수도에 특공
		$tIsland =& $Hislands[$HidToNumber[$nation[$sx][$sy]]];
		$tId = $tIsland['id']; $tName = $tIsland['name']; $tLand =& $tIsland['land']; $tLandValue =& $tIsland['landValue'];
		logMonsMoveOcean($tId, "$tName$AfterName", $point, $mName);
		list($bx, $by) = shipAppear($tLand, random(4));
		$tLand[$bx][$by] = $HlandMonster;
		$tLandValue[$bx][$by] = $landValue[$x][$y];
	}else{
		// 이동
		$land[$sx][$sy] = $land[$x][$y];
		$landValue[$sx][$sy] = $landValue[$x][$y];
	}

	// 아래 있던 위치를 괴수에 의해 변경
	if($mKind == 10){
		// 데빌 이노라
		$land[$x][$y] = $HlandOsen;
		$landValue[$x][$y] = $mHp;
	}elseif($mKind == 27)  {
		// 분열 이노라
		if(random(2) == 0){
			
			$nhp = intval($mHp / 2);
			
			if($nhp > 0){
				// 분열
				logMonster($id, $name, "($x, $y)", $mName, "가 분열했습니다. ");
				$landValue[$x][$y] = 2700 + $nhp;
				$landValue[$sx][$sy] -= $nhp;
			}else{
				// 소멸 로그 없음
				$land[$sx][$sy] = $HmonsterDestroy[$mKind];
				$landValue[$sx][$sy] = 0;
				
				$land[$x][$y] = $HmonsterDestroy[$mKind];
				$landValue[$x][$y] = 0;
			}
		}else{
			$land[$x][$y] = $HmonsterDestroy[$mKind];
			$landValue[$x][$y] = 0;
		}
	}else{
		$land[$x][$y] = $HmonsterDestroy[$mKind];
		$landValue[$x][$y] = 0;
	}
	// 뒤의 지형도 소거
	$land2[$x][$y] = $HlandSea;
	$landValue2[$x][$y] = 0;

	if($mode == 3){
		// 우주
		$land2[$sx][$sy] = $HlandSea;
		$landValue2[$sx][$sy] = 0;
		$nation[$sx][$sy] = 0;
		
		$nation[$x][$y] = 0;
		

		if($l == $HlandSDefence){
			// 방위 시설
			logMonsMoveDefenceS($lName, $point, $mName);
			wideDamageSpace($id, $land, $landValue, $dis, $nation, $sx, $sy, 7, 0);
		}elseif($l == $HlandEarth){
			logMonsMoveEarth($lName, $point, $mName);
		}elseif($l == $HlandSea){
			logMonsMoveSpace2($point, $mName, $SpaceName, 999);
		}else{
			logMonsMoveSpace($point, $mName, $SpaceName, $lName, 999);
		}
		return array($sx, $sy);
	}elseif($mode == 4){
		// 해역
		$land2[$sx][$sy] = $HlandSea;
		$landValue2[$sx][$sy] = 0;
		if($l == $HlandSea){
			logMonsMoveSpace2($point, $mName, $OceanName, 888);
		}elseif($l == $HlandOPlayer){
		}else{
			logMonsMoveSpace($point, $mName, $OceanName, $lName,  888);
		}
		return array($sx, $sy);
	}

	// 스페이스 이노라
	if ($mKind == 20) { $island['Meteo'] += 20; }
	
	// 스페이스 이노라
	if ($mKind == 20) { $island['Meteo'] += 20; }
	
	if ((($l == $HlandDefence) || (($l == $HlandOil) && ($lv == 5))) && ($HdBaseAuto == 1)){
		// 방위 시설을 밟았다
		logMonsMoveDefence($id, $name, $lName, $point, $mName);
		// 광역 피해 루틴?
		wideDamage($id, $name, $land, $landValue, $sx, $sy, 0);
	}elseif(($l == $HlandDeathtrap) || (($l == $HlandOil) && ($lv == 6))){
		// 데스트랩 을 밟았다
		if($l == $HlandOil){
			// 해저
			logMonsMoveDeathtrap($id, $name, $lName, $point, $mName, "흔적도 없이 사라져");
			$land[$sx][$sy] =  $HlandSea;
			$landValue[$sx][$sy] = 0;
		}else{
			if($lv >= 3){
				logMonsMoveDeathtrap($id, $name, $lName, $point, $mName, "흔적도 없이 사라져");
				$land[$sx][$sy] =  $HlandWaste;
				$landValue[$sx][$sy] = 1;
			}elseif($lv == 2){
				if($mKind == 18){
					// 반격 이노라
					logMonsMoveDeathtrapM($id, $name, $lName, $point, $mName);
				}elseif($mHp > 3){
					logMonsMoveDeathtrap($id, $name, $lName, $point, $mName, "데미지가 감소");
					$landValue[$sx][$sy] -= 3;
				}else{
					logMonsMoveDeathtrap($id, $name, $lName, $point, $mName, "흔적도 없이 사라져");
					$land[$sx][$sy] =  $HlandWaste;
					$landValue[$sx][$sy] = 1;
				}
			}else{
				if(($mKind == 17) || ($mKind == 18) || ($mKind == 19) || ($mKind == 20)){
					// 미사일로 발생하는 괴수
					logMonsMoveDeathtrapM($id, $name, $lName, $point, $mName);
				}elseif($mHp > 3){
					logMonsMoveDeathtrap($id, $name, $lName, $point, $mName, "데미지가 감소");
					$landValue[$sx][$sy] -= 2;
				}elseif($mHp > 1){
					logMonsMoveDeathtrap($id, $name, $lName, $point, $mName, "데미지가 감소");
					$landValue[$sx][$sy]--;
				}else{
					logMonsMoveDeathtrap($id, $name, $lName, $point, $mName, "흔적도 없이 사라져");
					$land[$sx][$sy] =  $HlandWaste;
					$landValue[$sx][$sy] = 1;
				}
			}
		}
	}elseif($l == $HlandWarp){ # 전이 장치
		logWarpMons($id, $name, $lName, $point, "괴수${mName}");
		if (warp($id, $name, $land[$sx][$sy], $landValue[$sx][$sy], "괴수${mName}", $lv, 0) == 0){
			$land[$sx][$sy] =  $HlandWarp;
			$landValue[$sx][$sy] = $lv;
		}else{
			logWarpMonsMiss($id, $name, $point, "괴수${mName}");
		}
	}elseif(($mKind == 17) && (random(5) == 0)){ # 카미카제 괴수 타임보칸
		logMonsZIBAKU($id, $name, $lName, $point, $mName);
		wideDamage($id, $name, $land, $landValue, $sx, $sy, 0);
	}elseif($mKind == 23){
		// 카네곤
		if(random(25) == 0){
			logMonsZIBAKU($id, $name, $lName, $point, $mName);
			wideDamage($id, $name, $land, $landValue, $sx, $sy, 0);
		}else{
			$island['money'] += 1000;
			logMonsMoney($id, $name, $lName, $point, $mName, "1000${HunitMoney}");
		}
	}elseif($mKind == 24){
		// 리치 이노라
		if($mHp <= 1){
			if(random(4) == 0){
				// 소멸한다
				logMonsMove($id, $name, $lName, $point, $mName);
				logMonster($id, $name, $point, $mName, "는 자연 소멸한 것 같습니다.");
				$land[$sx][$sy] =  $HlandWaste;
				$landValue[$sx][$sy] = 0;
			}else{
				$island['money'] += 2000;
				logMonsMoney($id, $name, $lName, $point, $mName, "2000${HunitMoney}");
			}
		}else{
			$island['money'] += 500;
			logMonsMoney($id, $name, $lName, $point, $mName, "500${HunitMoney}");
			if(random(4) == 0){
				// 데미지를 받는다
				$landValue[$sx][$sy]--;
				logMonster($id, $name, $point, $mName,"는 약해진 것 같습니다. ");
			}
		}
	}elseif($mKind == 22){
		// 그라테네스 이노라
		logMonsMove($id, $name, $lName, $point, $mName);
		logMonsEAT($id, $name, $lName, $point, $mName);
		$eatfood = intval($island['food'] * 0.05);
		if ($eatfood < 1000) { $eatfood = 1000; }
		$island['food'] -= $eatfood;
	}elseif($mKind == 26){
		// 미채 이노라
		// 행선지가 황무지가 된다
		logMonsMove($id, $name, $lName, "(?, ?)", $mName);
	}else{
		// 행선지가 황무지가 된다
		logMonsMove($id, $name, $lName, $point, $mName);
	}

	if(($l == $HlandOsen) && (($mKind == 6) || ($mKind == 7) || ($mKind == 8))){
		if(random(4) == 0){ # 오염에 의한 특수 변이
			if(random(2) == 0){
				$landValue[$sx][$sy] = 1300 + $HmonsterBHP[13] + random($HmonsterDHP[13]);
			}else{
				$landValue[$sx][$sy] = 1400 + $HmonsterBHP[14] + random($HmonsterDHP[14]);
			}
			logMonsC($id, $name, $point, $mName, hako_pick(monsterSpec($landValue[$sx][$sy]), array(1)));
		}
	}
	return array($sx, $sy);
}

// 배계 이동 행동
function shipAction(&$island, $x, $y) {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $H_tagName2, $Haidpop, $Hallyflg, $Hallygroup, $haribote, $Hatkturn, $HbackupTimes, $HbackupTurn, $HbgInfoCell, $HbgTitleCell, $HbigcityFood, $HbigCityMFlg, $HcomBank, $HcomBase, $HcomBioMissile, $HcomBreakwater, $Hcomcolony, $HcomcolonyTurn, $HcomCost, $HcomDbase, $HcomDeathtrap, $HcomDestroy, $HcomDestroy2, $HcomDokan, $HcomDoNothing, $HcomDummy, $HcomEmigration, $HcomFactory, $HcomFarm, $HcomFire, $HcomFlower, $HcomFood, $HcomGiveup, $HcomHaribote, $HcomHospital, $HcomL, $HcommandMax, $HcomManipulate, $HcomMissileDM, $HcomMissileGM, $HcomMissileLD, $HcomMissileMGM, $HcomMissileNCM, $HcomMissileNM, $HcomMissilePLD, $HcomMissilePP, $HcomMissileRM, $HcomMissileRNG, $HcomMissileSPP, $HcomMissileSRM, $HcomMissileST, $HcomMoney, $HcomMonsAid, $HcomMonsEgg, $HcomMonsEnsei, $HcomMonsEsa, $HcomMonsEsaAid, $HcomMonsExer, $HcomMonsSell, $HcomMonsTettai, $HcomMonument, $HcomMountain, $HcomMyhome, $HcomName, $HcomOilBuy, $HcomOilSell, $HcomOMissileMGM, $HcomOMissileNM, $HcomOMissilePP, $HcomOMissileSPP, $HcomOreBuy, $HcomOreSell, $HcomPioneer, $HcomPlant, $HcomPolice, $HcomPort, $HcomPrepare, $HcomPrepare2, $HcomPresent, $HcomPresentAid, $HcomPropaganda, $HcomReclaim, $HcomReclaim2, $HcomSbase, $HcomSBuild, $HcomScity, $HcomSDbase, $HcomSDestroy, $HcomSearch, $HcomSEisei, $HcomSell, $HcomSellTree, $HcomSendMonster, $HcomSendMonsterTurn, $HcomSFactory, $HcomSFarm, $HcomSFood, $HcomShip, $HcomShipbuild, $HcomShipM, $HcomShipSell, $HcomSMissile, $HcomSMissileGM, $HcomSMissileMGM, $HcomSMissilePP, $HcomSMonument, $HcomSOccupy, $HcomSpaceBase, $HcomSpaceFarm, $HcomSpecialSPP, $HcomSPioneer, $HcomSpy, $HcomSSendMonster, $HcomSSendMonsterTurn, $HcomSTManipulate, $HcomSUnit, $HcomTeisatu, $HcomTower, $HcomTrump, $HcomUg, $HcomWarp, $HcomWeponBuy, $HcomWeponSell, $HcomWindmill, $HconsolationMatch, $HcurrentNumber, $HdBaseAuto, $HdefenceHex, $HdefenceSpace, $HdevelopeTurn, $HdirMode, $HdirName, $HdisAEruption, $HdisAkasio, $HdisBHarvest, $HdisCrime, $HdisEarthquake, $HdisEruption, $HdisFallBorder, $HdisFalldown, $HdisFire, $HdisGHarvest, $Hdishangen, $HdisHugeMeteo, $HdisKLimit, $HdisMaizo, $HdisMeteo, $HdisMonsBorder1, $HdisMonsBorder2, $HdisMonsBorder3, $HdisMonsBorder4, $HdisMonsBorder5, $HdisMonster, $HdisMonsterU, $HdisPirate, $HdisPollution, $HdisSeaMonster, $HdisSHugeMeteo, $HdisSpaceMonster1, $HdisSpaceMonster2, $HdisTinka, $HdisTreasureS, $HdisTsunami, $HdisTyphoon, $HdisUN, $HdisVGHarvest, $HearthAttack, $HeatenFood, $helpDir, $HfightMem, $HfightTurn, $HfinalTurn, $HgiveupTurn, $HhistoryMax, $HidToName, $HidToNumber, $HidToNumberR, $HinterTime, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HlandAegisShip, $HlandAirport, $HlandAmusement, $HlandBalloonS, $HlandBank, $HlandBase, $HlandBigcity, $HlandBreakwater, $HlandCasino, $HlandCoupleRock, $HlandDeathtrap, $HlandDefence, $HlandDokan, $HlandDome, $HlandEarth, $HlandExpo, $HlandFactory, $HlandFarm, $HlandFire, $HlandFishLShip, $HlandFishMShip, $HlandFishSShip, $HlandFlower, $HlandForest, $HlandFuji, $HlandGhostShip, $HlandHaribote, $HlandHospital, $HlandHugecity, $HlandIceFloe, $HlandKInora, $HlandMegacity, $HlandMegaFact, $HlandMegaFarm, $HlandMegatower, $HlandMonsShip, $HlandMonster, $HlandMonument, $HlandMountain, $HlandMyhome, $HlandOcean, $HlandOil, $HlandOPlayer, $HlandOsen, $HlandPark, $HlandPirate, $HlandPlains, $HlandPolice, $HlandPort, $HlandProbeShip, $HlandSAEisei, $HlandSbase, $HlandSchool, $HlandSCity, $HlandSDefence, $HlandSea, $HlandSeisei, $HlandSFactory, $HlandSFarm, $HlandSlum, $HlandSMonument, $HlandSpaceBase, $HlandStadium, $HlandSunit, $HlandTcity, $HlandTitanic, $HlandTower, $HlandTown, $HlandTreasureS, $HlandTrump, $HlandWarp, $HlandWarpR, $HlandWaste, $HlandWindmill, $HlandWingDragon, $HlandZoo, $HlateLogPool, $HlogMax, $HlogOmit2, $HlogPool, $HmaxdisPollution, $HmaxExpPoint, $HmaxIsland, $HmonsBtlMaxHp, $HmonsBtlMaxPa, $HmonsterAGI, $HmonsterBHP, $HmonsterCLS, $HmonsterDEF, $HmonsterDestroy, $HmonsterDHP, $HmonsterExp, $HmonsterGRP, $HmonsterL1, $HmonsterL1Num, $HmonsterL2, $HmonsterL2Num, $HmonsterL3, $HmonsterL3Num, $HmonsterL4, $HmonsterL4Num, $HmonsterL5, $HmonsterL5Num, $HmonsterName, $HmonsterNumber, $HmonsterS, $HmonsterSEI, $HmonsterSKL, $HmonsterSP, $HmonsterSpecial, $HmonsterSTR, $HmonsterValue, $Hmonth, $HmonumentMissile, $HmonumentName, $HmonumentRocket, $Hocean, $HoceanSize, $HoilMoney, $HoilRatio, $hp, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $Hprize, $HprizeV, $HpunishInfo, $HrepeatTurn, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $HseaChk, $HsecretLogPool, $HsEisei, $HshipEX, $HshipFood, $HshipHP, $HshipKAI, $HshipMATK, $HshipMoney, $HshipName, $Hshiporder, $HshipSATK, $HshipSell, $HshipSP, $HsmonumentName, $HsmonumentNumber, $Hsolarwind, $Hspace, $HspaceEfficiency, $HspaceIncome, $Hsstartturn, $HStotalPoint, $HsurvFlg, $Hsurvivalturn, $HtagName2_, $HthisFile, $HtotalBumon, $HtotalMoney, $HtotalPoint, $Htournament, $HtreeValue, $HturnPrizeNumber, $HturnPrizePoint, $HturnPrizeUnit, $HturnPrizeVarious, $HugDokan, $HugFact, $HugFarm, $HugHasigo, $HugKiti, $HugMax, $HugOil, $HugRoad, $HugSpace, $HugTosi, $human, $HunitFood, $HunitMoney, $HunitOil, $HunitOre, $HunitPop, $HunitTime, $HunitWeapon, $HwarFlg, $HWeatherMax, $Hwflg, $HwinFood, $HwinIsland, $HwinMoney, $HwinWeapon, $imageDir, $lockMode, $toppage, $versionInfo;
	
	$name = $island['name']; $id = $island['id']; $land =& $island['land']; $landValue =& $island['landValue']; $land2 =& $island['land2']; $landValue2 =& $island['landValue2'];
	list($lx,$lvx) = array($land[$x][$y],$landValue[$x][$y]);
	$sName = landName($lx, $lvx);
	list($order, $hp, $sId) = shipSpec($lvx);
	$INumber = randomArray($HislandNumber);
	$tIsland =& $Hislands[$INumber[random($HislandNumber)]];
	$tId = $tIsland['id'];
	
	// 이동전의 행동
	$i = null; $d = null; $sx = null; $sy = null; $j = null;
	if($order == 4){
		// 공격
		$Katk = $HshipMATK[$lx - $HlandPirate];
		$Satk = $HshipSATK[$lx - $HlandPirate];
		if ($Katk + $Satk < 1) { return array($x, $y); }
		for($j = 1; $j < 7; $j++){
			$sx = $x + $ax[$j];
			$sy = $y + $ay[$j];
			if (!($sy % 2) && ($y % 2)) { $sx--; }
			if (($sx < 0) || ($sx >= $HislandSize) || ($sy < 0) || ($sy >= $HislandSize)) { continue; }
			
			if(($land[$sx][$sy] == $HlandMonster) && ($Katk > 0)){
				// 괴수 발견 공격한다
				list($mKind, $mName, $mHp) = monsterSpec($landValue[$sx][$sy]);
				$special = $HmonsterSpecial[$mKind];
				// 방어중?
				if((($special == 3) && (($HislandTurn % 2) == 1)) ||
				   (($special == 4) && (($HislandTurn % 2) == 0)) ||
				   (($special == 5) && (random(4) != 0))){
					// 방어중
continue;
				}else{
					$mHp - $Katk;
					if($mHp > 0){
						// 괴수 살아 있다
						logMonster($id, $name, "($sx, $sy)", $mName, "는, 알수없는 데미지를 받았습니다.");
						$landValue[$sx][$sy] -= $Katk;
					}else{
						// 넘어뜨렸다
						logMonster($id, $name, "($sx, $sy)", $mName, "는, 알수없는 공격에 의해 소멸한 것 같습니다.");
						$land[$sx][$sy] = $HmonsterDestroy[$mKind];
						$landValue[$sx][$sy] = 0;
					}
break;
				}
			}elseif(($HseaChk[$land[$sx][$sy]] == 2) && ($Satk > 0)){
				// 향후 삭제 예정?
				
//				
//				mylist($torder, $thp, $tsId) = shipSpec($landValue[$sx][$sy]);
//				
//				HdebugOut("대선공격? Satk=${Satk} torder=${torder} thp=${thp} tsId=${tsId}");
//				
//				if(($tsId > 0) && ($id != $tsId)){
//					# 다른 도의 소속배(무소속 제외하다)의 경우
//					
//					HdebugOut("다른 도의 소속배(무소속 제외하다)의 경우");
//					
//					my($p);
//					if($torder == 2){
//						# 방어중
//						$p = 3;
//					}elsif($torder == 1){
//						$p = 1;
//					}
//					if(random(5 - $p) == 0){
//						HdebugOut("회피");
//						
//					}else{
//						
//						$thp - $Satk;
//						if($thp > 0){
//							HdebugOut("살아 있다");
//							logShipDis($id, $name, landName($land[$sx][$sy], 0), "($sx, $sy)","는, 어디에선가의 공격에 의해 데미지를 흡수");
//							$landValue[$sx][$sy] -= $Satk;
//						}else{
//							# 넘어뜨렸다
//							HdebugOut("침몰");
//							logShipDis($id, $name, landName($land[$sx][$sy], 0), "($sx, $sy)","는, 어디에선가의 공격에 의해 침몰해");
//							$land[$sx][$sy] = $HlandSea;
//							$landValue[$sx][$sy] = 0;
//						}
//					}
//				}
continue;
			}
		}
	}
	if($lx == $HlandPirate){
		 // 해적선
		for($j = 1; $j < 7; $j++){
			$sx = $x + $ax[$j];
			$sy = $y + $ay[$j];
			if (!($sy % 2) && ($y % 2)) { $sx--; }
			if (($sx < 0) || ($sx >= $HislandSize) || ($sy < 0) || ($sy >= $HislandSize)) { continue; }
			if(($land[$sx][$sy] == $HlandFishSShip) || ($land[$sx][$sy] == $HlandFishMShip) ||
					($land[$sx][$sy] == $HlandFishLShip) || ($land[$sx][$sy] == $HlandTitanic)){
				// 주위에 민간배가 있었을 경우.
				if ($sId == hako_pick(shipSpec($landValue[$sx][$sy]), array(2))) { continue; }
				if($sId > 0){
					// 위장 해적선
					$kIsland = $Hislands[$HidToNumber[$sId]];
					$tname = $kIsland['name'];
					logShipDis($id, $name, landName($land[$sx][$sy], 0), "($sx, $sy)","가 해적 내습에 의해 ${HtagName_}${tname}${AfterName}${H_tagName}에 납치되고");
					$landValue[$sx][$sy] = 21000 + $sId;
				}else{
					logShipDis($id, $name, landName($land[$sx][$sy], 0), "($sx, $sy)","가 해적 내습에 의해 침몰해");
					if(random(20) == 0){
						// 유령배
						$land[$sx][$sy] = $HlandGhostShip;
						$landValue[$sx][$sy] = $HshipHP[$HlandGhostShip - $HlandPirate] * 1000;
					}else{
						$land[$sx][$sy] = $HlandSea;
						$landValue[$sx][$sy] = 0;
					}
				}
break;
			}
		}
	}elseif(($lx == $HlandIceFloe) && ($island['titanic'] > 0)){
		// 호화 여객선은 유빙에서도 침몰 (웃음)
		for($j = 1; $j < 7; $j++){
			$sx = $x + $ax[$j];
			$sy = $y + $ay[$j];
			if (!($sy % 2) && ($y % 2)) { $sx--; }
			if (($sx < 0) || ($sx >= $HislandSize) || ($sy < 0) || ($sy >= $HislandSize)) { continue; }
			if($land[$sx][$sy] == $HlandTitanic){
				if ($sId == hako_pick(shipSpec($landValue[$sx][$sy]), array(2))) { continue; }
				logShipDis($id, $name, landName($land[$sx][$sy], 0), "($sx, $sy)","가 빙산과 충돌해 침몰해");
				$land[$sx][$sy] = $HlandSea;
				$landValue[$sx][$sy] = 0;
break;
			}
		}
	}
	
	if($order == 0){
		if((($lx == $HlandFishSShip) || ($lx == $HlandFishMShip) || ($lx == $HlandFishLShip)) && ($id == $sId)){
			// 어선의 지령이 특수의 경우는 나포
			for($j = 1; $j < 7; $j++){
				$sx = $x + $ax[$j];
				$sy = $y + $ay[$j];
				if (!($sy % 2) && ($y % 2)) { $sx--; }
				if (($sx < 0) || ($sx >= $HislandSize) || ($sy < 0) || ($sy >= $HislandSize)) { continue; }
				if(($land[$sx][$sy] == $HlandIceFloe) || ($land[$sx][$sy] == $HlandCoupleRock)){
					if ($sId == hako_pick(shipSpec($landValue[$sx][$sy]), array(2))) { continue; }
					logShipDis($id, $name, landName($land[$sx][$sy], 0), "($sx, $sy)","를 나포해");
					$landValue[$sx][$sy] = 21000 + $id;
break;
				}
			}
		}
	}
	
	// 이동 처리
	if($order == 3){
		// 후퇴
		if(($x == 0) || ($x == $HislandSize) || ($y == 0) || ($y == $HislandSize)){
			// 후퇴 성공
			$land[$x][$y] = $land2[$x][$y];
			$landValue[$x][$y] = $landValue2[$x][$y];
			$land2[$x][$y] = $HlandSea;
			$landValue2[$x][$y] = 0;
			logShipDis($id, $name, landName($lx, 0), "($x, $y)","도의 영해로부터 멀어져 사라");
			shipComeBack($sId,$lx,$lvx); # 생환 처리
			return array(100, 100);
		}else{
			$i = 3;
			$direction = shipEvacuation($x, $y);
			foreach ($direction as $d) {
				$sx = $x + $ax[$d];
				$sy = $y + $ay[$d];
				if (!($sy % 2) && ($y % 2)) { $sx--; }
				if($HseaChk[$land[$sx][$sy]] == 1){
					// 바다계 지형의 경우, 배계는 제외하다
					$i = 0;
break;
				}
			}
		}
	}else{
		for($i = 0; $i < 3; $i++){
			
			// 배조작 판정
			if(($island['shipMoveMid'] == $sId) && ($island['shipMoveMt'] == $id)){
				$d = $island['shipMoveM'];
			}elseif(($island['shipMoveTid'] == $sId) && ($island['shipMoveTt'] == $id)){
				$d = $island['shipMoveT'];
			}else{
				$d = random(6) + 1;
			}
			
			$sx = $x + $ax[$d];
			$sy = $y + $ay[$d];
			if (!($sy % 2) && ($y % 2)) { $sx--; }
			// 범위외 판정
			if(($sx < 0) || ($sx >= $HislandSize) || ($sy < 0) || ($sy >= $HislandSize)){
				if((($lx == $HlandPirate) && ($id != $tId)) || 
							($lx == $HlandWingDragon) ||
							 ($lx == $HlandIceFloe) ||
							 ($lx == $HlandBalloonS) ||
							 ($lx == $HlandCoupleRock)){
					$land[$x][$y] = $land2[$x][$y];
					$landValue[$x][$y] = $landValue2[$x][$y];
					$land2[$x][$y] = $HlandSea;
					$landValue2[$x][$y] = 0;
					// 해적의 경우로 다른 도의 경우 랜덤으로 선택된 도에 이동
					if ($lx == $HlandPirate) { $tIsland['piratesend'] = $sId; }
					logShipDis($id, $name, landName($lx, 0), "($x, $y)","이 도의 영해로부터 멀어져 사라");
					return array(100, 100);
				}
continue;
			}
			// 바다계 지형, 전이 장치의 경우, 배계는 제외하다
			if (($HseaChk[$land[$sx][$sy]] == 1) || ($land[$sx][$sy] == $HlandWarp)) { break; }
		}
	}

	// 움직이지 않았다
	if ($i == 3) { return array($x, $y); }

	// 움직인 앞의 지형에 의해 메세지
	$l = $land[$sx][$sy];
	$lv = $landValue[$sx][$sy];
	$point = "($sx, $sy)";

	if(($l == $HlandDeathtrap) || (($l == $HlandOil) && ($lv == 6))){
		// 데스트랩 을 밟았다?
		logShipMoveDeathtrap($id, $name, landName($l, $lv), $point, $sName);
		$land[$sx][$sy] =  $HlandSea;
		$landValue[$sx][$sy] = 0;
		
		// 이동처의 지형을 복원
		$land[$x][$y] = $land2[$x][$y];
		$landValue[$x][$y] = $landValue2[$x][$y];
		$land2[$x][$y] = $HlandSea;
		$landValue2[$x][$y] = 0;
		return array(100, 100);
	}elseif($l == $HlandWarp){
		// 전이 장치
		logWarpMons($id, $name, landName($l, $lv), $point, $sName);
		if (warp($id, $name, $lx, $lvx, $sName, $lv, 1) == 0){
			$land[$sx][$sy] =  $HlandWarp;
			$landValue[$sx][$sy] = $lv;

		}else{
			logWarpMonsMiss($id, $name, $point, landName($l, $lv));
		}
		// 이동처의 지형을 복원
		$land[$x][$y] = $land2[$x][$y];
		$landValue[$x][$y] = $landValue2[$x][$y];
		$land2[$x][$y] = $HlandSea;
		$landValue2[$x][$y] = 0;
		return array(100, 100);
	}
	if($order == 0){
		// 지령이 특수의 경우
		if((($lx == $HlandPirate) || ($lx == $HlandGhostShip)) && ($id != $sId)){
			// 해적선, 유령배는 약탈
			if((($l == $HlandOil) && ($lv >= 10)) ||
				(($l == $HlandSea) && ($lv >= 10))){
				// 해저 도시, 해저 농장, 양식장
				if($sId > 0){
					$sIsland = $Hislands[$HidToNumber[$sId]];
					if (($l == $HlandOil) && ($lv < 35)){
						// 해저 농장
						$sIsland['money'] += $lv * 80;
						$sIsland['food'] += $lv * 80;
					}else{
						$sIsland['money'] += $lv * 20;
						$sIsland['food'] += $lv * 20;
					}
				}
				logShipPlunder($id, $sId, $name, landName($l, $lv), $point, $sName);
				$order = 100;
				
				// 양식장 때 1
				$lv = ($l == $HlandSea) ? 1 : 0;
				$l = $HlandSea;
			}
		}elseif($lx == $HlandProbeShip){
			//  해저 탐사배
			$p = random(100);
			if($p < 3){
				if($land2[$x][$y] != $HlandOil){
					$land2[$x][$y] = $HlandOil;
					$landValue2[$x][$y] = 0;
					logOut("${HtagName_}${name}${AfterName}($x, $y)${H_tagName} 으로<B>유전</B>이 발견된 것 같습니다.",$id);
				}
			}elseif($p == 81){
				// 시 이노라
				$land2[$x][$y] = $HlandMonster;
				$landValue2[$x][$y] = 905;
				logMonsCome($id, $name, hako_pick(monsterSpec(905), array(1)), "($x, $y)", landName($HlandSea, 0));
			}elseif($p == 82){
				// 시고스트
				$land2[$x][$y] = $HlandMonster;
				$landValue2[$x][$y] = 2105;
				logMonsCome($id, $name, hako_pick(monsterSpec(2105), array(1)), "($x, $y)", landName($HlandSea, 0));
			}elseif($p == 83){
				// 분화(제재 논리를 이용)
				$HpunishInfo[$id]['punish'] = 8;
				$HpunishInfo[$id]['x'] = $x;
				$HpunishInfo[$id]['y'] = $y;
			}
		}
	}
	
	// 행선지의 지형을 보존해 이동
	$land2[$sx][$sy] = $l;
	$landValue2[$sx][$sy] = $lv;

	$land[$sx][$sy] = $land[$x][$y];
	$landValue[$sx][$sy] = $landValue[$x][$y];

	// 아래 있던 지형을 복원
	$land[$x][$y] = $land2[$x][$y];
	$landValue[$x][$y] = $landValue2[$x][$y];
	$land2[$x][$y] = $HlandSea;
	$landValue2[$x][$y] = 0;

// 시끄럽기 때문에 표시하지 않는다
//	if($order < 100){
//		# 이동 로그
//		logShipMove($id, $name, landName($l, $lv), $point, $sName);
//	}

	return array($sx, $sy);
}

// 후뉴우환처리
function shipComeBack($sId, $kind, $lv) {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $H_tagName2, $Haidpop, $Hallyflg, $Hallygroup, $haribote, $Hatkturn, $HbackupTimes, $HbackupTurn, $HbgInfoCell, $HbgTitleCell, $HbigcityFood, $HbigCityMFlg, $HcomBank, $HcomBase, $HcomBioMissile, $HcomBreakwater, $Hcomcolony, $HcomcolonyTurn, $HcomCost, $HcomDbase, $HcomDeathtrap, $HcomDestroy, $HcomDestroy2, $HcomDokan, $HcomDoNothing, $HcomDummy, $HcomEmigration, $HcomFactory, $HcomFarm, $HcomFire, $HcomFlower, $HcomFood, $HcomGiveup, $HcomHaribote, $HcomHospital, $HcomL, $HcommandMax, $HcomManipulate, $HcomMissileDM, $HcomMissileGM, $HcomMissileLD, $HcomMissileMGM, $HcomMissileNCM, $HcomMissileNM, $HcomMissilePLD, $HcomMissilePP, $HcomMissileRM, $HcomMissileRNG, $HcomMissileSPP, $HcomMissileSRM, $HcomMissileST, $HcomMoney, $HcomMonsAid, $HcomMonsEgg, $HcomMonsEnsei, $HcomMonsEsa, $HcomMonsEsaAid, $HcomMonsExer, $HcomMonsSell, $HcomMonsTettai, $HcomMonument, $HcomMountain, $HcomMyhome, $HcomName, $HcomOilBuy, $HcomOilSell, $HcomOMissileMGM, $HcomOMissileNM, $HcomOMissilePP, $HcomOMissileSPP, $HcomOreBuy, $HcomOreSell, $HcomPioneer, $HcomPlant, $HcomPolice, $HcomPort, $HcomPrepare, $HcomPrepare2, $HcomPresent, $HcomPresentAid, $HcomPropaganda, $HcomReclaim, $HcomReclaim2, $HcomSbase, $HcomSBuild, $HcomScity, $HcomSDbase, $HcomSDestroy, $HcomSearch, $HcomSEisei, $HcomSell, $HcomSellTree, $HcomSendMonster, $HcomSendMonsterTurn, $HcomSFactory, $HcomSFarm, $HcomSFood, $HcomShip, $HcomShipbuild, $HcomShipM, $HcomShipSell, $HcomSMissile, $HcomSMissileGM, $HcomSMissileMGM, $HcomSMissilePP, $HcomSMonument, $HcomSOccupy, $HcomSpaceBase, $HcomSpaceFarm, $HcomSpecialSPP, $HcomSPioneer, $HcomSpy, $HcomSSendMonster, $HcomSSendMonsterTurn, $HcomSTManipulate, $HcomSUnit, $HcomTeisatu, $HcomTower, $HcomTrump, $HcomUg, $HcomWarp, $HcomWeponBuy, $HcomWeponSell, $HcomWindmill, $HconsolationMatch, $HcurrentNumber, $HdBaseAuto, $HdefenceHex, $HdefenceSpace, $HdevelopeTurn, $HdirMode, $HdirName, $HdisAEruption, $HdisAkasio, $HdisBHarvest, $HdisCrime, $HdisEarthquake, $HdisEruption, $HdisFallBorder, $HdisFalldown, $HdisFire, $HdisGHarvest, $Hdishangen, $HdisHugeMeteo, $HdisKLimit, $HdisMaizo, $HdisMeteo, $HdisMonsBorder1, $HdisMonsBorder2, $HdisMonsBorder3, $HdisMonsBorder4, $HdisMonsBorder5, $HdisMonster, $HdisMonsterU, $HdisPirate, $HdisPollution, $HdisSeaMonster, $HdisSHugeMeteo, $HdisSpaceMonster1, $HdisSpaceMonster2, $HdisTinka, $HdisTreasureS, $HdisTsunami, $HdisTyphoon, $HdisUN, $HdisVGHarvest, $HearthAttack, $HeatenFood, $helpDir, $HfightMem, $HfightTurn, $HfinalTurn, $HgiveupTurn, $HhistoryMax, $HidToName, $HidToNumber, $HidToNumberR, $HinterTime, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HlandAegisShip, $HlandAirport, $HlandAmusement, $HlandBalloonS, $HlandBank, $HlandBase, $HlandBigcity, $HlandBreakwater, $HlandCasino, $HlandCoupleRock, $HlandDeathtrap, $HlandDefence, $HlandDokan, $HlandDome, $HlandEarth, $HlandExpo, $HlandFactory, $HlandFarm, $HlandFire, $HlandFishLShip, $HlandFishMShip, $HlandFishSShip, $HlandFlower, $HlandForest, $HlandFuji, $HlandGhostShip, $HlandHaribote, $HlandHospital, $HlandHugecity, $HlandIceFloe, $HlandKInora, $HlandMegacity, $HlandMegaFact, $HlandMegaFarm, $HlandMegatower, $HlandMonsShip, $HlandMonster, $HlandMonument, $HlandMountain, $HlandMyhome, $HlandOcean, $HlandOil, $HlandOPlayer, $HlandOsen, $HlandPark, $HlandPirate, $HlandPlains, $HlandPolice, $HlandPort, $HlandProbeShip, $HlandSAEisei, $HlandSbase, $HlandSchool, $HlandSCity, $HlandSDefence, $HlandSea, $HlandSeisei, $HlandSFactory, $HlandSFarm, $HlandSlum, $HlandSMonument, $HlandSpaceBase, $HlandStadium, $HlandSunit, $HlandTcity, $HlandTitanic, $HlandTower, $HlandTown, $HlandTreasureS, $HlandTrump, $HlandWarp, $HlandWarpR, $HlandWaste, $HlandWindmill, $HlandWingDragon, $HlandZoo, $HlateLogPool, $HlogMax, $HlogOmit2, $HlogPool, $HmaxdisPollution, $HmaxExpPoint, $HmaxIsland, $HmonsBtlMaxHp, $HmonsBtlMaxPa, $HmonsterAGI, $HmonsterBHP, $HmonsterCLS, $HmonsterDEF, $HmonsterDestroy, $HmonsterDHP, $HmonsterExp, $HmonsterGRP, $HmonsterL1, $HmonsterL1Num, $HmonsterL2, $HmonsterL2Num, $HmonsterL3, $HmonsterL3Num, $HmonsterL4, $HmonsterL4Num, $HmonsterL5, $HmonsterL5Num, $HmonsterName, $HmonsterNumber, $HmonsterS, $HmonsterSEI, $HmonsterSKL, $HmonsterSP, $HmonsterSpecial, $HmonsterSTR, $HmonsterValue, $Hmonth, $HmonumentMissile, $HmonumentName, $HmonumentRocket, $Hocean, $HoceanSize, $HoilMoney, $HoilRatio, $hp, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $Hprize, $HprizeV, $HpunishInfo, $HrepeatTurn, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $HseaChk, $HsecretLogPool, $HsEisei, $HshipEX, $HshipFood, $HshipHP, $HshipKAI, $HshipMATK, $HshipMoney, $HshipName, $Hshiporder, $HshipSATK, $HshipSell, $HshipSP, $HsmonumentName, $HsmonumentNumber, $Hsolarwind, $Hspace, $HspaceEfficiency, $HspaceIncome, $Hsstartturn, $HStotalPoint, $HsurvFlg, $Hsurvivalturn, $HtagName2_, $HthisFile, $HtotalBumon, $HtotalMoney, $HtotalPoint, $Htournament, $HtreeValue, $HturnPrizeNumber, $HturnPrizePoint, $HturnPrizeUnit, $HturnPrizeVarious, $HugDokan, $HugFact, $HugFarm, $HugHasigo, $HugKiti, $HugMax, $HugOil, $HugRoad, $HugSpace, $HugTosi, $human, $HunitFood, $HunitMoney, $HunitOil, $HunitOre, $HunitPop, $HunitTime, $HunitWeapon, $HwarFlg, $HWeatherMax, $Hwflg, $HwinFood, $HwinIsland, $HwinMoney, $HwinWeapon, $imageDir, $lockMode, $toppage, $versionInfo;
	$island =& $Hislands[$HidToNumber[$sId]];
	$land =& $island['land']; $landValue =& $island['landValue'];
	list($sx, $sy) = shipAppear($land, random(4));
	$island['land2'][$sx][$sy] = $land[$sx][$sy];
	$island['landValue2'][$sx][$sy] = $landValue[$sx][$sy];
	$land[$sx][$sy] = $kind;
	$lv2 = $lv - (intval($lv / 10000) * 10000);
	$landValue[$sx][$sy] = $lv2 + 20000;
	logShipComeIs($island['id'], $island['name'], landName($kind, 0), "($sx, $sy)");
}

// 전이
// 도의 ID  이름 전송 해 온 지형치 전송물명 타겟 ID  전송물의 종류
function warp($id, $name, $land, $landValue, $mName, $tid, $z) {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $H_tagName2, $Haidpop, $Hallyflg, $Hallygroup, $haribote, $Hatkturn, $HbackupTimes, $HbackupTurn, $HbgInfoCell, $HbgTitleCell, $HbigcityFood, $HbigCityMFlg, $HcomBank, $HcomBase, $HcomBioMissile, $HcomBreakwater, $Hcomcolony, $HcomcolonyTurn, $HcomCost, $HcomDbase, $HcomDeathtrap, $HcomDestroy, $HcomDestroy2, $HcomDokan, $HcomDoNothing, $HcomDummy, $HcomEmigration, $HcomFactory, $HcomFarm, $HcomFire, $HcomFlower, $HcomFood, $HcomGiveup, $HcomHaribote, $HcomHospital, $HcomL, $HcommandMax, $HcomManipulate, $HcomMissileDM, $HcomMissileGM, $HcomMissileLD, $HcomMissileMGM, $HcomMissileNCM, $HcomMissileNM, $HcomMissilePLD, $HcomMissilePP, $HcomMissileRM, $HcomMissileRNG, $HcomMissileSPP, $HcomMissileSRM, $HcomMissileST, $HcomMoney, $HcomMonsAid, $HcomMonsEgg, $HcomMonsEnsei, $HcomMonsEsa, $HcomMonsEsaAid, $HcomMonsExer, $HcomMonsSell, $HcomMonsTettai, $HcomMonument, $HcomMountain, $HcomMyhome, $HcomName, $HcomOilBuy, $HcomOilSell, $HcomOMissileMGM, $HcomOMissileNM, $HcomOMissilePP, $HcomOMissileSPP, $HcomOreBuy, $HcomOreSell, $HcomPioneer, $HcomPlant, $HcomPolice, $HcomPort, $HcomPrepare, $HcomPrepare2, $HcomPresent, $HcomPresentAid, $HcomPropaganda, $HcomReclaim, $HcomReclaim2, $HcomSbase, $HcomSBuild, $HcomScity, $HcomSDbase, $HcomSDestroy, $HcomSearch, $HcomSEisei, $HcomSell, $HcomSellTree, $HcomSendMonster, $HcomSendMonsterTurn, $HcomSFactory, $HcomSFarm, $HcomSFood, $HcomShip, $HcomShipbuild, $HcomShipM, $HcomShipSell, $HcomSMissile, $HcomSMissileGM, $HcomSMissileMGM, $HcomSMissilePP, $HcomSMonument, $HcomSOccupy, $HcomSpaceBase, $HcomSpaceFarm, $HcomSpecialSPP, $HcomSPioneer, $HcomSpy, $HcomSSendMonster, $HcomSSendMonsterTurn, $HcomSTManipulate, $HcomSUnit, $HcomTeisatu, $HcomTower, $HcomTrump, $HcomUg, $HcomWarp, $HcomWeponBuy, $HcomWeponSell, $HcomWindmill, $HconsolationMatch, $HcurrentNumber, $HdBaseAuto, $HdefenceHex, $HdefenceSpace, $HdevelopeTurn, $HdirMode, $HdirName, $HdisAEruption, $HdisAkasio, $HdisBHarvest, $HdisCrime, $HdisEarthquake, $HdisEruption, $HdisFallBorder, $HdisFalldown, $HdisFire, $HdisGHarvest, $Hdishangen, $HdisHugeMeteo, $HdisKLimit, $HdisMaizo, $HdisMeteo, $HdisMonsBorder1, $HdisMonsBorder2, $HdisMonsBorder3, $HdisMonsBorder4, $HdisMonsBorder5, $HdisMonster, $HdisMonsterU, $HdisPirate, $HdisPollution, $HdisSeaMonster, $HdisSHugeMeteo, $HdisSpaceMonster1, $HdisSpaceMonster2, $HdisTinka, $HdisTreasureS, $HdisTsunami, $HdisTyphoon, $HdisUN, $HdisVGHarvest, $HearthAttack, $HeatenFood, $helpDir, $HfightMem, $HfightTurn, $HfinalTurn, $HgiveupTurn, $HhistoryMax, $HidToName, $HidToNumber, $HidToNumberR, $HinterTime, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HlandAegisShip, $HlandAirport, $HlandAmusement, $HlandBalloonS, $HlandBank, $HlandBase, $HlandBigcity, $HlandBreakwater, $HlandCasino, $HlandCoupleRock, $HlandDeathtrap, $HlandDefence, $HlandDokan, $HlandDome, $HlandEarth, $HlandExpo, $HlandFactory, $HlandFarm, $HlandFire, $HlandFishLShip, $HlandFishMShip, $HlandFishSShip, $HlandFlower, $HlandForest, $HlandFuji, $HlandGhostShip, $HlandHaribote, $HlandHospital, $HlandHugecity, $HlandIceFloe, $HlandKInora, $HlandMegacity, $HlandMegaFact, $HlandMegaFarm, $HlandMegatower, $HlandMonsShip, $HlandMonster, $HlandMonument, $HlandMountain, $HlandMyhome, $HlandOcean, $HlandOil, $HlandOPlayer, $HlandOsen, $HlandPark, $HlandPirate, $HlandPlains, $HlandPolice, $HlandPort, $HlandProbeShip, $HlandSAEisei, $HlandSbase, $HlandSchool, $HlandSCity, $HlandSDefence, $HlandSea, $HlandSeisei, $HlandSFactory, $HlandSFarm, $HlandSlum, $HlandSMonument, $HlandSpaceBase, $HlandStadium, $HlandSunit, $HlandTcity, $HlandTitanic, $HlandTower, $HlandTown, $HlandTreasureS, $HlandTrump, $HlandWarp, $HlandWarpR, $HlandWaste, $HlandWindmill, $HlandWingDragon, $HlandZoo, $HlateLogPool, $HlogMax, $HlogOmit2, $HlogPool, $HmaxdisPollution, $HmaxExpPoint, $HmaxIsland, $HmonsBtlMaxHp, $HmonsBtlMaxPa, $HmonsterAGI, $HmonsterBHP, $HmonsterCLS, $HmonsterDEF, $HmonsterDestroy, $HmonsterDHP, $HmonsterExp, $HmonsterGRP, $HmonsterL1, $HmonsterL1Num, $HmonsterL2, $HmonsterL2Num, $HmonsterL3, $HmonsterL3Num, $HmonsterL4, $HmonsterL4Num, $HmonsterL5, $HmonsterL5Num, $HmonsterName, $HmonsterNumber, $HmonsterS, $HmonsterSEI, $HmonsterSKL, $HmonsterSP, $HmonsterSpecial, $HmonsterSTR, $HmonsterValue, $Hmonth, $HmonumentMissile, $HmonumentName, $HmonumentRocket, $Hocean, $HoceanSize, $HoilMoney, $HoilRatio, $hp, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $Hprize, $HprizeV, $HpunishInfo, $HrepeatTurn, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $HseaChk, $HsecretLogPool, $HsEisei, $HshipEX, $HshipFood, $HshipHP, $HshipKAI, $HshipMATK, $HshipMoney, $HshipName, $Hshiporder, $HshipSATK, $HshipSell, $HshipSP, $HsmonumentName, $HsmonumentNumber, $Hsolarwind, $Hspace, $HspaceEfficiency, $HspaceIncome, $Hsstartturn, $HStotalPoint, $HsurvFlg, $Hsurvivalturn, $HtagName2_, $HthisFile, $HtotalBumon, $HtotalMoney, $HtotalPoint, $Htournament, $HtreeValue, $HturnPrizeNumber, $HturnPrizePoint, $HturnPrizeUnit, $HturnPrizeVarious, $HugDokan, $HugFact, $HugFarm, $HugHasigo, $HugKiti, $HugMax, $HugOil, $HugRoad, $HugSpace, $HugTosi, $human, $HunitFood, $HunitMoney, $HunitOil, $HunitOre, $HunitPop, $HunitTime, $HunitWeapon, $HwarFlg, $HWeatherMax, $Hwflg, $HwinFood, $HwinIsland, $HwinMoney, $HwinWeapon, $imageDir, $lockMode, $toppage, $versionInfo;
	// 타겟 취득
	$tn = $HidToNumber[$tid];
	if ($tn == '') { return 0; }
	$tIsland =& $Hislands[$tn];
	// 상대가 도상국이기 때문에 중지
	if (($tIsland['turnsu'] + $tIsland['evil'] < $HdisUN) || ($tIsland['evil'] == 0)) { return 0; }
	
	$tName = $tIsland['name']; $tLand =& $tIsland['land']; $tLandValue =& $tIsland['landValue'];
	// 워프 먼저 전이 장치가 있을까 서치
	$count = null; $x = null; $y = null; $tx = null; $ty = null; $i = null; $j = null;
	for($count = 0; $count < $HpointNumber; $count++){
		$x = $Hrpx[$count];
		$y = $Hrpy[$count];
		if(($tLand[$x][$y] == $HlandWarp) || ($tLand[$x][$y] == $HlandWarpR)){
			// 전이 장치 발견했으므로 주위의 장애물을 서치
			
			// 전이처 장치의 경우는 방향을 지정할 수 있다
			$j = ($tLand[$x][$y] == $HlandWarpR) ? $tLandValue[$x][$y] : 1;
			
			for($i = $j; $i < 61; $i++){
				$tx = $x + $ax[$i];
				$ty = $y + $ay[$i];
				if (!($ty % 2) && ($y % 2)) { $tx--; }
				// 범위내외 체크
				if (($tx < 0) || ($tx >= $HislandSize) || ($ty < 0) || ($ty >= $HislandSize)) { continue; }
				if ($z > 10){ # 괴수, 배계 이외
					$x = $tx;
					$y = $ty;
break;
				}elseif($i > 6){ # 주위에 전송 할 수 없을 때는 전송 실패
					return 1;
				}
				if($z == 1){
					// 배계는 바다계 지형, 배계는 제외하다
					if($HseaChk[$tLand[$tx][$ty]] == 1){
						$x = $tx;
						$y = $ty;
break;
					}
				}else{
					// 바다계, 괴수, 산, 기념비 이외
					if(($HseaChk[$tLand[$tx][$ty]] == 0) &&
						($tLand[$tx][$ty] != $HlandMountain) &&
						($tLand[$tx][$ty] != $HlandMonument) &&
						($tLand[$tx][$ty] != $HlandFuji) &&
						($tLand[$tx][$ty] != $HlandMyhome) &&
						($tLand[$tx][$ty] != $HlandKInora) &&
						($tLand[$tx][$ty] != $HlandMonster)){
						$x = $tx;
						$y = $ty;
break;
					}
				}
			}
break;
		}
	}
	// 전이 장치가 없었던 경우의 워프처는 랜덤
	if($count >= $HpointNumber){
		$x = random($HislandSize);
		$y = random($HislandSize);
	}
	if($z < 10){ # 괴수, 배계
		logMWarp($id, $tid, $name, $tName, "($x, $y)", $mName);
		$tLand[$x][$y] = $land;
		$tLandValue[$x][$y] = $landValue;
	}elseif($z == 11){ # 미사일
		logMWarp($id, $tid, $name, $tName, "($x, $y)", "미사일");
		$tLand[$x][$y] = $HlandSea;
		$tLandValue[$x][$y] = 0;
	}elseif($z == 12){ # 운석
		logMWarp($id, $tid, $name, $tName, "($x, $y)", $mName);
		$tLand[$x][$y] = $HlandSea;
		$tLandValue[$x][$y] = 0;
	}
	return 0;
}
// 0으로부터(n - 1)까지의 숫자가 1회씩 나오는 수열을 만든다
function randomArray($n) {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $H_tagName2, $Haidpop, $Hallyflg, $Hallygroup, $haribote, $Hatkturn, $HbackupTimes, $HbackupTurn, $HbgInfoCell, $HbgTitleCell, $HbigcityFood, $HbigCityMFlg, $HcomBank, $HcomBase, $HcomBioMissile, $HcomBreakwater, $Hcomcolony, $HcomcolonyTurn, $HcomCost, $HcomDbase, $HcomDeathtrap, $HcomDestroy, $HcomDestroy2, $HcomDokan, $HcomDoNothing, $HcomDummy, $HcomEmigration, $HcomFactory, $HcomFarm, $HcomFire, $HcomFlower, $HcomFood, $HcomGiveup, $HcomHaribote, $HcomHospital, $HcomL, $HcommandMax, $HcomManipulate, $HcomMissileDM, $HcomMissileGM, $HcomMissileLD, $HcomMissileMGM, $HcomMissileNCM, $HcomMissileNM, $HcomMissilePLD, $HcomMissilePP, $HcomMissileRM, $HcomMissileRNG, $HcomMissileSPP, $HcomMissileSRM, $HcomMissileST, $HcomMoney, $HcomMonsAid, $HcomMonsEgg, $HcomMonsEnsei, $HcomMonsEsa, $HcomMonsEsaAid, $HcomMonsExer, $HcomMonsSell, $HcomMonsTettai, $HcomMonument, $HcomMountain, $HcomMyhome, $HcomName, $HcomOilBuy, $HcomOilSell, $HcomOMissileMGM, $HcomOMissileNM, $HcomOMissilePP, $HcomOMissileSPP, $HcomOreBuy, $HcomOreSell, $HcomPioneer, $HcomPlant, $HcomPolice, $HcomPort, $HcomPrepare, $HcomPrepare2, $HcomPresent, $HcomPresentAid, $HcomPropaganda, $HcomReclaim, $HcomReclaim2, $HcomSbase, $HcomSBuild, $HcomScity, $HcomSDbase, $HcomSDestroy, $HcomSearch, $HcomSEisei, $HcomSell, $HcomSellTree, $HcomSendMonster, $HcomSendMonsterTurn, $HcomSFactory, $HcomSFarm, $HcomSFood, $HcomShip, $HcomShipbuild, $HcomShipM, $HcomShipSell, $HcomSMissile, $HcomSMissileGM, $HcomSMissileMGM, $HcomSMissilePP, $HcomSMonument, $HcomSOccupy, $HcomSpaceBase, $HcomSpaceFarm, $HcomSpecialSPP, $HcomSPioneer, $HcomSpy, $HcomSSendMonster, $HcomSSendMonsterTurn, $HcomSTManipulate, $HcomSUnit, $HcomTeisatu, $HcomTower, $HcomTrump, $HcomUg, $HcomWarp, $HcomWeponBuy, $HcomWeponSell, $HcomWindmill, $HconsolationMatch, $HcurrentNumber, $HdBaseAuto, $HdefenceHex, $HdefenceSpace, $HdevelopeTurn, $HdirMode, $HdirName, $HdisAEruption, $HdisAkasio, $HdisBHarvest, $HdisCrime, $HdisEarthquake, $HdisEruption, $HdisFallBorder, $HdisFalldown, $HdisFire, $HdisGHarvest, $Hdishangen, $HdisHugeMeteo, $HdisKLimit, $HdisMaizo, $HdisMeteo, $HdisMonsBorder1, $HdisMonsBorder2, $HdisMonsBorder3, $HdisMonsBorder4, $HdisMonsBorder5, $HdisMonster, $HdisMonsterU, $HdisPirate, $HdisPollution, $HdisSeaMonster, $HdisSHugeMeteo, $HdisSpaceMonster1, $HdisSpaceMonster2, $HdisTinka, $HdisTreasureS, $HdisTsunami, $HdisTyphoon, $HdisUN, $HdisVGHarvest, $HearthAttack, $HeatenFood, $helpDir, $HfightMem, $HfightTurn, $HfinalTurn, $HgiveupTurn, $HhistoryMax, $HidToName, $HidToNumber, $HidToNumberR, $HinterTime, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HlandAegisShip, $HlandAirport, $HlandAmusement, $HlandBalloonS, $HlandBank, $HlandBase, $HlandBigcity, $HlandBreakwater, $HlandCasino, $HlandCoupleRock, $HlandDeathtrap, $HlandDefence, $HlandDokan, $HlandDome, $HlandEarth, $HlandExpo, $HlandFactory, $HlandFarm, $HlandFire, $HlandFishLShip, $HlandFishMShip, $HlandFishSShip, $HlandFlower, $HlandForest, $HlandFuji, $HlandGhostShip, $HlandHaribote, $HlandHospital, $HlandHugecity, $HlandIceFloe, $HlandKInora, $HlandMegacity, $HlandMegaFact, $HlandMegaFarm, $HlandMegatower, $HlandMonsShip, $HlandMonster, $HlandMonument, $HlandMountain, $HlandMyhome, $HlandOcean, $HlandOil, $HlandOPlayer, $HlandOsen, $HlandPark, $HlandPirate, $HlandPlains, $HlandPolice, $HlandPort, $HlandProbeShip, $HlandSAEisei, $HlandSbase, $HlandSchool, $HlandSCity, $HlandSDefence, $HlandSea, $HlandSeisei, $HlandSFactory, $HlandSFarm, $HlandSlum, $HlandSMonument, $HlandSpaceBase, $HlandStadium, $HlandSunit, $HlandTcity, $HlandTitanic, $HlandTower, $HlandTown, $HlandTreasureS, $HlandTrump, $HlandWarp, $HlandWarpR, $HlandWaste, $HlandWindmill, $HlandWingDragon, $HlandZoo, $HlateLogPool, $HlogMax, $HlogOmit2, $HlogPool, $HmaxdisPollution, $HmaxExpPoint, $HmaxIsland, $HmonsBtlMaxHp, $HmonsBtlMaxPa, $HmonsterAGI, $HmonsterBHP, $HmonsterCLS, $HmonsterDEF, $HmonsterDestroy, $HmonsterDHP, $HmonsterExp, $HmonsterGRP, $HmonsterL1, $HmonsterL1Num, $HmonsterL2, $HmonsterL2Num, $HmonsterL3, $HmonsterL3Num, $HmonsterL4, $HmonsterL4Num, $HmonsterL5, $HmonsterL5Num, $HmonsterName, $HmonsterNumber, $HmonsterS, $HmonsterSEI, $HmonsterSKL, $HmonsterSP, $HmonsterSpecial, $HmonsterSTR, $HmonsterValue, $Hmonth, $HmonumentMissile, $HmonumentName, $HmonumentRocket, $Hocean, $HoceanSize, $HoilMoney, $HoilRatio, $hp, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $Hprize, $HprizeV, $HpunishInfo, $HrepeatTurn, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $HseaChk, $HsecretLogPool, $HsEisei, $HshipEX, $HshipFood, $HshipHP, $HshipKAI, $HshipMATK, $HshipMoney, $HshipName, $Hshiporder, $HshipSATK, $HshipSell, $HshipSP, $HsmonumentName, $HsmonumentNumber, $Hsolarwind, $Hspace, $HspaceEfficiency, $HspaceIncome, $Hsstartturn, $HStotalPoint, $HsurvFlg, $Hsurvivalturn, $HtagName2_, $HthisFile, $HtotalBumon, $HtotalMoney, $HtotalPoint, $Htournament, $HtreeValue, $HturnPrizeNumber, $HturnPrizePoint, $HturnPrizeUnit, $HturnPrizeVarious, $HugDokan, $HugFact, $HugFarm, $HugHasigo, $HugKiti, $HugMax, $HugOil, $HugRoad, $HugSpace, $HugTosi, $human, $HunitFood, $HunitMoney, $HunitOil, $HunitOre, $HunitPop, $HunitTime, $HunitWeapon, $HwarFlg, $HWeatherMax, $Hwflg, $HwinFood, $HwinIsland, $HwinMoney, $HwinWeapon, $imageDir, $lockMode, $toppage, $versionInfo;
	$list = null; $i = null;
	// 초기치
	if ($n == 0) { $n = 1; }
	$list = range(0, $n-1);
	// 상훌
	for ($i = $n; --$i; ){
		$j = mt_rand(0, $i);
		if ($i == $j) { continue; }
		$tmp = $list[$i];
		$list[$i] = $list[$j];
		$list[$j] = $tmp;
	}

	return $list;
}

// neo_otacky씨가 작성
function islandReki() {
global $HidToNumber, $HidToNumberR, $HislandNumber, $Hislands, $HislandTurn, $HmaxIsland, $HStotalPoint, $HtotalBumon, $HtotalMoney, $HtotalPoint, $HlogdirName;
	$line = null; $i = null; $id = null; $pop = null; $turn = null; $name = null; $n = null; $island = null; $rekidai = null; $reki = null;
	$j = 0;

	if(!hako_open('RIN', "<${HlogdirName}/rekidai.dat")){
		rename("${HlogdirName}/rekidai.tmp", "${HlogdirName}/rekidai.dat");
		if(!hako_open('RIN', "${HlogdirName}/rekidai.dat")){
			hako_open('ROUT', ">${HlogdirName}/rekidai.tmp");
			for($i = 0; $i < $HislandNumber; $i++){# 현존 하는 도 모든 것을 기록
				$island =& $Hislands[$i];
				$id = $island['id'];
				$name = $island['name'];
				$pop = $island['pop'];
				hako_write('ROUT', "$id,$pop,$HislandTurn,$name\n");
			}
			hako_close('ROUT');
			rename("${HlogdirName}/rekidai.tmp", "${HlogdirName}/rekidai.dat");
			return;
		}
	}

	while (($line = hako_getline('RIN')) !== false) {
		preg_match('/^([0-9]*),([0-9]*),([0-9]*),(.*)null', $line, $_m);
		list($id, $pop, $turn, $name) = array($_m[1], $_m[2], $_m[3], $_m[4]);
		if(isset($HidToNumber[$id])) {
			$HidToNumberR[$id] = $j;
			$rekidai[$j]['id'] = $id;
		}
		$rekidai[$j]['pop']=$pop;
		$rekidai[$j]['turn']=$turn;
		$rekidai[$j]['name']=$name;
		$j++;
	}
	hako_close('RIN');

	for($i = 0; $i < $HislandNumber; $i++){
		$island =& $Hislands[$i];
		$id = $island['id'];
		$name = $island['name'];
		$pop = $island['pop'];
		$n = $HidToNumberR[$id];
		if(isset($n)){
			if($pop > $rekidai[$n]['pop']){
				$rekidai[$n]['pop'] = $pop;
				$rekidai[$n]['turn'] = $HislandTurn;
				$rekidai[$n]['name'] = $name;
			}
		}else{
			$rekidai[$j]['id']=$id;
			$rekidai[$j]['pop']=$pop;
			$rekidai[$j]['turn']=$HislandTurn;
			$rekidai[$j]['name']=$name;
			$j++;
		}
	}

	// 인구가 같은 때는 직전의 턴의 차례인 채
	$idx = range(0, count($rekidai) - 1);
	usort($idx, function($a, $b) { global $Hislands, $rekidai, $HtotalPoint, $HtotalMoney, $HtotalBumon, $HStotalPoint, $DATA, $LandCount, $LandCount2, $allyPop; $c = hako_cmp($rekidai[$b]['pop'], $rekidai[$a]['pop']); return ($c != 0) ? $c : hako_cmp($a, $b); });
	$rekidai = hako_reorder($rekidai, $idx);

	hako_open('ROUT', ">${HlogdirName}/rekidai.tmp");
	$recordNo = ($HmaxIsland < 15) ? 15 : $HmaxIsland;
	for($i = 0; $i < $recordNo; $i++) { # 최대로 도의 최대수와 같다기록. 최악이어 15도.
		$reki = $rekidai[$i];
		$n = $i + 1;
		if(isset($reki['pop'])) {
			list($id, $pop, $turn, $name) = array($reki['id'], $reki['pop'], $reki['turn'], $reki['name']);
			hako_write('ROUT', "$id,$pop,$turn,$name\n");
		}
	}
	hako_close('ROUT');
	unlink("${HlogdirName}/rekidai.dat");
	rename("${HlogdirName}/rekidai.tmp", "${HlogdirName}/rekidai.dat");
}

//------------------------------------------------
// 간이 토너먼트
// 대전의 기록 로그
function fihgt_log() {
global $AfterName, $H_tagName2, $HbgInfoCell, $HbgTitleCell, $HdirName, $HislandFightCount, $HislandFightMode, $HtagName2_, $HunitPop, $HtagTH_, $H_tagTH, $HtagName_, $H_tagName;
	hako_open('FOUT', "${HdirName}/fight.log");
	$f = null; $offset = null;
	while (($f = hako_getline('FOUT')) !== false) {
		$f = rtrim($f);
		array_push($offset, "$f\n");
	}
	hako_close('FOUT');
	$fight;
	// 회전 갖가지 대입
	$fTurn = $HislandFightCount;
	// 결승전의 경우 99로 한다
	if ($HislandFightMode == 9) { $fTurn = 99; }

	hako_open('DOUT', ">$HdirName/fight.log.bak");
	hako_write('DOUT', "<${fTurn}>\n");
	hako_write('DOUT', "<TABLE BORDER>\n");
	hako_write('DOUT', "<tr><TH colspan=3></th><th $HbgTitleCell colspan=1>${HtagTH_}승자${H_tagTH}</th><TH colspan=1></th>\n");
	hako_write('DOUT', "<TH $HbgTitleCell colspan=1>${HtagTH_}패자${H_tagTH}</th></tr>\n");
	hako_write('DOUT', "<TR>\n");
	hako_write('DOUT', "<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}승자${H_tagTH}</NOBR></TH>\n");
	hako_write('DOUT', "<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}패자${H_tagTH}</NOBR></TH>\n");
//	hako_write('DOUT', "<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}빗맞음 수${H_tagTH}</NOBR></TH>\n");
	hako_write('DOUT', "<TH $HbgTitleCell width=15 nowrap=nowrap>　</TH>\n");
//	hako_write('DOUT', "<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}보수금${H_tagTH}</NOBR></TH>\n");
	hako_write('DOUT', "<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}인구${H_tagTH}</NOBR></TH>\n");
//	hako_write('DOUT', "<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}파괴 미사일 수${H_tagTH}</NOBR></TH>\n");
//	hako_write('DOUT', "<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}파괴 방어 시설 수${H_tagTH}</NOBR></TH>\n");
	hako_write('DOUT', "<TH $HbgTitleCell width=15 nowrap=nowrap>　</TH>\n");
	hako_write('DOUT', "<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}인구${H_tagTH}</NOBR></TH>\n");
//	hako_write('DOUT', "<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}파괴 미사일 수${H_tagTH}</NOBR></TH>\n");
//	hako_write('DOUT', "<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}파괴 방어 시설 수${H_tagTH}</NOBR></TH>\n");
	hako_write('DOUT', "</tr>\n");

	foreach ($fight_log_flag as $fight) {
		list($name,$tName,$reward,$log,$pop,$tLog,$tPop,$fly,$id) = preg_split('/,/', $fight);
		$logD	= intval($log / 1000)."기";
		$logM	= ($log - $logD * 1000)."기";
		$tLogD	= intval($tLog / 1000)."덧";
		$tLogM	= ($tLog - $tLogD * 1000)."기";
//		$tName	= "<A STYlE=\"text-decoration:none\" HREF=\"".$HthisFile."?LoseMap=".$id."\">".
//					$HtagName2_.$tName."${AfterName}".$H_tagName2."</A>";
		$tName	= "${HtagName2_}$tName$AfterName${H_tagName2}";
		$tPop	.= ${HunitPop};
		if($id == -1) {
			$tName = "${HtagName2_}부전승${H_tagName2}";
			$tPop  = "◎";
			$tLogM = "◎";
			$tLogD = "◎";
		}elseif($id == -2) {
			$tName = "${HtagName2_}침몰${H_tagName2}";
			$tPop  = "◎";
			$tLogM = "◎";
			$tLogD = "◎";
		}
		hako_write('DOUT', "<TR><TD $HbgInfoCell align=right><NOBR>${HtagName_}${name}${AfterName}${H_tagName}</nobr></td>");
		hako_write('DOUT', "<TD $HbgInfoCell align=center><NOBR>${tName}</nobr></td>\n");
//		hako_write('DOUT', "<TH $HbgInfoCell><NOBR>${fly}발</nobr></TH>\n");
		hako_write('DOUT', "<TD $HbgInfoCell><NOBR>　</nobr></td>\n");
//		hako_write('DOUT', "<TH $HbgInfoCell><NOBR>${reward}${HunitMoney}</nobr></TH>\n");
		hako_write('DOUT', "<TH $HbgInfoCell><NOBR>${pop}${HunitPop}</nobr></TH>\n");
//		hako_write('DOUT', "<TH $HbgInfoCell><NOBR>${logM}</nobr></TH>\n");
//		hako_write('DOUT', "<TH $HbgInfoCell><NOBR>${logD}</nobr></TH>\n");
		hako_write('DOUT', "<TD $HbgInfoCell><NOBR>　</nobr></td>\n");
		hako_write('DOUT', "<TH $HbgInfoCell><NOBR>${tPop}</nobr></TH>\n");
//		hako_write('DOUT', "<TH $HbgInfoCell><NOBR>${tLogM}</nobr></TH>\n");
//		hako_write('DOUT', "<TH $HbgInfoCell><NOBR>${tLogD}</nobr></TH>\n");
		hako_write('DOUT', "</tr>\n");
	}
	hako_write('DOUT', "</TABLE>$consolationName\n");
	hako_write('DOUT', $offset);
	hako_close('DOUT');
	rename("${HdirName}/fight.log.bak","${HdirName}/fight.log");
}

// 예선 빠짐 로그
function log_yosen() {
global $AfterName, $HbgInfoCell, $HbgTitleCell, $HdirName, $HunitPop, $yosen, $HtagTH_, $H_tagTH, $HtagName_, $H_tagName;
	$yosen;
	hako_open('DOUT', ">${HdirName}/fight.log");
	hako_write('DOUT', "<0>\n");
	hako_write('DOUT', "<TABLE BORDER>\n");
	hako_write('DOUT', "<TR>\n");
	hako_write('DOUT', "<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}${AfterName}${H_tagTH}</NOBR></TH>\n");
	hako_write('DOUT', "<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}인구${H_tagTH}</NOBR></TH></tr>");
	foreach ($yosen_log as $yosen) {
		list($pop,$name) = preg_split('/,/', $yosen);
		hako_write('DOUT', "<TR><TD $HbgInfoCell align=right><NOBR>${HtagName_}${name}${AfterName}${H_tagName}</nobr></td>");
		hako_write('DOUT', "<TD $HbgInfoCell align=center><NOBR><B>${pop}$HunitPop</b></nobr></td></tr>\n");
	}
	hako_write('DOUT', "</TABLE>\n");
	hako_close('DOUT');
}

// 승리 로그
function logWin($id, $name, $str, $money) {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $H_tagName2, $Haidpop, $Hallyflg, $Hallygroup, $haribote, $Hatkturn, $HbackupTimes, $HbackupTurn, $HbgInfoCell, $HbgTitleCell, $HbigcityFood, $HbigCityMFlg, $HcomBank, $HcomBase, $HcomBioMissile, $HcomBreakwater, $Hcomcolony, $HcomcolonyTurn, $HcomCost, $HcomDbase, $HcomDeathtrap, $HcomDestroy, $HcomDestroy2, $HcomDokan, $HcomDoNothing, $HcomDummy, $HcomEmigration, $HcomFactory, $HcomFarm, $HcomFire, $HcomFlower, $HcomFood, $HcomGiveup, $HcomHaribote, $HcomHospital, $HcomL, $HcommandMax, $HcomManipulate, $HcomMissileDM, $HcomMissileGM, $HcomMissileLD, $HcomMissileMGM, $HcomMissileNCM, $HcomMissileNM, $HcomMissilePLD, $HcomMissilePP, $HcomMissileRM, $HcomMissileRNG, $HcomMissileSPP, $HcomMissileSRM, $HcomMissileST, $HcomMoney, $HcomMonsAid, $HcomMonsEgg, $HcomMonsEnsei, $HcomMonsEsa, $HcomMonsEsaAid, $HcomMonsExer, $HcomMonsSell, $HcomMonsTettai, $HcomMonument, $HcomMountain, $HcomMyhome, $HcomName, $HcomOilBuy, $HcomOilSell, $HcomOMissileMGM, $HcomOMissileNM, $HcomOMissilePP, $HcomOMissileSPP, $HcomOreBuy, $HcomOreSell, $HcomPioneer, $HcomPlant, $HcomPolice, $HcomPort, $HcomPrepare, $HcomPrepare2, $HcomPresent, $HcomPresentAid, $HcomPropaganda, $HcomReclaim, $HcomReclaim2, $HcomSbase, $HcomSBuild, $HcomScity, $HcomSDbase, $HcomSDestroy, $HcomSearch, $HcomSEisei, $HcomSell, $HcomSellTree, $HcomSendMonster, $HcomSendMonsterTurn, $HcomSFactory, $HcomSFarm, $HcomSFood, $HcomShip, $HcomShipbuild, $HcomShipM, $HcomShipSell, $HcomSMissile, $HcomSMissileGM, $HcomSMissileMGM, $HcomSMissilePP, $HcomSMonument, $HcomSOccupy, $HcomSpaceBase, $HcomSpaceFarm, $HcomSpecialSPP, $HcomSPioneer, $HcomSpy, $HcomSSendMonster, $HcomSSendMonsterTurn, $HcomSTManipulate, $HcomSUnit, $HcomTeisatu, $HcomTower, $HcomTrump, $HcomUg, $HcomWarp, $HcomWeponBuy, $HcomWeponSell, $HcomWindmill, $HconsolationMatch, $HcurrentNumber, $HdBaseAuto, $HdefenceHex, $HdefenceSpace, $HdevelopeTurn, $HdirMode, $HdirName, $HdisAEruption, $HdisAkasio, $HdisBHarvest, $HdisCrime, $HdisEarthquake, $HdisEruption, $HdisFallBorder, $HdisFalldown, $HdisFire, $HdisGHarvest, $Hdishangen, $HdisHugeMeteo, $HdisKLimit, $HdisMaizo, $HdisMeteo, $HdisMonsBorder1, $HdisMonsBorder2, $HdisMonsBorder3, $HdisMonsBorder4, $HdisMonsBorder5, $HdisMonster, $HdisMonsterU, $HdisPirate, $HdisPollution, $HdisSeaMonster, $HdisSHugeMeteo, $HdisSpaceMonster1, $HdisSpaceMonster2, $HdisTinka, $HdisTreasureS, $HdisTsunami, $HdisTyphoon, $HdisUN, $HdisVGHarvest, $HearthAttack, $HeatenFood, $helpDir, $HfightMem, $HfightTurn, $HfinalTurn, $HgiveupTurn, $HhistoryMax, $HidToName, $HidToNumber, $HidToNumberR, $HinterTime, $HislandChangeTurn, $HislandFightCount, $HislandFightMode, $HislandLastTime, $HislandNumber, $Hislands, $HislandSize, $HislandTurn, $HislandTurnCount, $HlandAegisShip, $HlandAirport, $HlandAmusement, $HlandBalloonS, $HlandBank, $HlandBase, $HlandBigcity, $HlandBreakwater, $HlandCasino, $HlandCoupleRock, $HlandDeathtrap, $HlandDefence, $HlandDokan, $HlandDome, $HlandEarth, $HlandExpo, $HlandFactory, $HlandFarm, $HlandFire, $HlandFishLShip, $HlandFishMShip, $HlandFishSShip, $HlandFlower, $HlandForest, $HlandFuji, $HlandGhostShip, $HlandHaribote, $HlandHospital, $HlandHugecity, $HlandIceFloe, $HlandKInora, $HlandMegacity, $HlandMegaFact, $HlandMegaFarm, $HlandMegatower, $HlandMonsShip, $HlandMonster, $HlandMonument, $HlandMountain, $HlandMyhome, $HlandOcean, $HlandOil, $HlandOPlayer, $HlandOsen, $HlandPark, $HlandPirate, $HlandPlains, $HlandPolice, $HlandPort, $HlandProbeShip, $HlandSAEisei, $HlandSbase, $HlandSchool, $HlandSCity, $HlandSDefence, $HlandSea, $HlandSeisei, $HlandSFactory, $HlandSFarm, $HlandSlum, $HlandSMonument, $HlandSpaceBase, $HlandStadium, $HlandSunit, $HlandTcity, $HlandTitanic, $HlandTower, $HlandTown, $HlandTreasureS, $HlandTrump, $HlandWarp, $HlandWarpR, $HlandWaste, $HlandWindmill, $HlandWingDragon, $HlandZoo, $HlateLogPool, $HlogMax, $HlogOmit2, $HlogPool, $HmaxdisPollution, $HmaxExpPoint, $HmaxIsland, $HmonsBtlMaxHp, $HmonsBtlMaxPa, $HmonsterAGI, $HmonsterBHP, $HmonsterCLS, $HmonsterDEF, $HmonsterDestroy, $HmonsterDHP, $HmonsterExp, $HmonsterGRP, $HmonsterL1, $HmonsterL1Num, $HmonsterL2, $HmonsterL2Num, $HmonsterL3, $HmonsterL3Num, $HmonsterL4, $HmonsterL4Num, $HmonsterL5, $HmonsterL5Num, $HmonsterName, $HmonsterNumber, $HmonsterS, $HmonsterSEI, $HmonsterSKL, $HmonsterSP, $HmonsterSpecial, $HmonsterSTR, $HmonsterValue, $Hmonth, $HmonumentMissile, $HmonumentName, $HmonumentRocket, $Hocean, $HoceanSize, $HoilMoney, $HoilRatio, $hp, $Hperformance, $HpointNumber, $HpointOcean, $Hpossess, $Hprize, $HprizeV, $HpunishInfo, $HrepeatTurn, $Hrpx, $HrpxO, $Hrpy, $HrpyO, $HseaChk, $HsecretLogPool, $HsEisei, $HshipEX, $HshipFood, $HshipHP, $HshipKAI, $HshipMATK, $HshipMoney, $HshipName, $Hshiporder, $HshipSATK, $HshipSell, $HshipSP, $HsmonumentName, $HsmonumentNumber, $Hsolarwind, $Hspace, $HspaceEfficiency, $HspaceIncome, $Hsstartturn, $HStotalPoint, $HsurvFlg, $Hsurvivalturn, $HtagName2_, $HthisFile, $HtotalBumon, $HtotalMoney, $HtotalPoint, $Htournament, $HtreeValue, $HturnPrizeNumber, $HturnPrizePoint, $HturnPrizeUnit, $HturnPrizeVarious, $HugDokan, $HugFact, $HugFarm, $HugHasigo, $HugKiti, $HugMax, $HugOil, $HugRoad, $HugSpace, $HugTosi, $human, $HunitFood, $HunitMoney, $HunitOil, $HunitOre, $HunitPop, $HunitTime, $HunitWeapon, $HwarFlg, $HWeatherMax, $Hwflg, $HwinFood, $HwinIsland, $HwinMoney, $HwinWeapon, $imageDir, $lockMode, $toppage, $versionInfo;
	$fTurn = $HislandFightCount + 1;
	if($HislandNumber <= 4) {
		$fTurn = '결승전';
	} elseif($HislandNumber <= 8) { 
		$fTurn = '준결승';
	} else {
		$fTurn .= '회전';
	}
	if($HislandNumber == 2) {
		logOut("${HtagName_}${name}${AfterName}${H_tagName}${str}해,<B>우승!</B>",$id);
		logHistory("${HtagName_}${name}${AfterName}${H_tagName},<B>우승!</B>");
	} elseif($money == 0) {
		logOut("${HtagName_}${name}${AfterName}${H_tagName}${str}해,<B>${fTurn}진출!</B>",$id);
	} else {
		logOut("${HtagName_}${name}${AfterName}${H_tagName}${str}해,<B>${fTurn}진출!　$money$HunitMoney</B>의 보수금이 지불되었습니다.",$id);
	}
}

// 예선 빠짐
function logLoseOut($id, $name) {
global $AfterName, $HtagName_, $H_tagName;
	logOut("${HtagName_}${name}${AfterName}${H_tagName},<B>예선 빠짐</B>.",$id);
	logHistory("${HtagName_}${name}${AfterName}${H_tagName},<B>예선 빠짐으로 침몰</B>.");
}
//------------------------------------------------

1;
