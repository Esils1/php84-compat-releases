<?php
// ----------------------------------------------------------------------
// 모형정원 제도 ver2. 20
// 진영 화면 모듈
// PHP 5.5 변환판 - CGI 원본과 동일한 동작 유지
// jcode 미사용 (UTF-8 환경 전제)
// ----------------------------------------------------------------------

if (!function_exists('out')) { function out($s = '') { echo $s; } }
if (!function_exists('random')) { function random($n) { return ($n > 0) ? mt_rand(0, $n - 1) : 0; } }

// ======================================================================
// 진영 화면 - 메인
// ======================================================================

function campMain() {
    global $HcurrentNumber, $HidToNumber, $HcurrentID, $Hislands, $HcurrentCampID, $HinputPassword;

    $HcurrentNumber = $HidToNumber[$HcurrentID];
    $HcurrentCamp   = $Hislands[$HcurrentNumber];

    // 락 해제
    unlock();

    // 패스워드 체크
    if (!checkPassword($HcurrentCamp['password'], $HinputPassword)) {
        tempWrongPassword();
        return;
    }

    $HcurrentCampID = $HcurrentCamp['ally'];

    tempPrintCampHead();   // 작전 본부 헤더
    campAllIslandsInfo();  // 진영에 속하는 섬 정보
}

// ======================================================================
// 템플릿
// ======================================================================

// 진영 작전 본부 헤더 출력
function tempPrintCampHead() {
    global $HtagBig_, $H_tagBig, $HtempBack;

    out(<<<END
<DIV align='center'>
{$HtagBig_}진영 일람표시{$H_tagBig}<BR>
{$HtempBack}<BR><BR>
</DIV>
※　대부분의 내정은, 목표가 다른 섬에서 만나도 자신의 섬에 대해서 실행됩니다.<BR>
END
    );
}

// 진영에 속하는 전체 섬 정보 출력
function campAllIslandsInfo() {
    global $HislandNumber, $Hislands, $HcurrentCampID;

    // 각 섬의 커맨드·지형 데이터 읽기
    for ($i = 0; $i < $HislandNumber; $i++) {
        list($Hislands[$i]['command'],
             $Hislands[$i]['land'],
             $Hislands[$i]['landValue']) = readCommands($Hislands[$i]['id']);
    }

    // 진영이 일치하는 섬만 표시
    for ($i = 0; $i < $HislandNumber; $i++) {
        $ally = $Hislands[$i]['ally'];
        if ($ally === '' || (int)$ally < 1) continue;
        if ($HcurrentCampID != $ally) continue;
        if ($Hislands[$i]['id'] > 90) continue;  // 배틀필드 섬 제외

        campIslandInfo($Hislands[$i], $i + 1);
    }
}

// 섬 데이터 파일에서 커맨드·지형 읽기 (진영 화면용)
function readCommands($id) {
    global $HdirName, $HislandSize, $HugMax, $HcommandMax;

    $filepath = "{$HdirName}/island.{$id}";

    // 파일 없으면 임시 파일로 복구 시도
    if (!file_exists($filepath)) {
        $tmppath = "{$HdirName}/islandtmp.{$id}";
        if (file_exists($tmppath)) {
            rename($tmppath, $filepath);
        } else {
            return array(array(), array(), array());
        }
    }

    $fp = fopen($filepath, 'r');
    if ($fp === false) {
        return array(array(), array(), array());
    }

    $land      = array();
    $landValue = array();
    $command   = array();

    // 지형 데이터 읽기
    for ($y = 0; $y < $HislandSize; $y++) {
        $line = fgets($fp);
        if ($line === false) break;
        $line = rtrim($line, "\r\n");
        for ($x = 0; $x < $HislandSize; $x++) {
            // 각 셀: land(2) + landValue(4) + 패딩(2) + 패딩(4) + 패딩(2) = 14바이트
            // 원본 Perl: s/^(..)(....)(..)(....)(..)//
            // land 2자리hex, landValue 4자리hex
            $land[$x][$y]      = hexdec(substr($line, 0, 2));
            $landValue[$x][$y] = hexdec(substr($line, 2, 4));
            $line = substr($line, 14);
        }
    }

    // 지하 기지 데이터 스킵 ($HugMax 줄)
    for ($i = 0; $i < $HugMax; $i++) {
        fgets($fp);
    }

    // 고정 헤더 5줄 스킵
    fgets($fp); // 식량 등
    fgets($fp);
    fgets($fp);
    fgets($fp);
    fgets($fp);

    // 커맨드 데이터 읽기
    for ($i = 0; $i < $HcommandMax; $i++) {
        $line = fgets($fp);
        if ($line === false) break;
        $line = rtrim($line, "\r\n");
        // 형식: kind,target,x,y,arg,tx,ty
        $parts = explode(',', $line);
        $command[$i] = array(
            'kind'   => isset($parts[0]) ? (int)$parts[0] : 0,
            'target' => isset($parts[1]) ? (int)$parts[1] : 0,
            'x'      => isset($parts[2]) ? (int)$parts[2] : 0,
            'y'      => isset($parts[3]) ? (int)$parts[3] : 0,
            'arg'    => isset($parts[4]) ? (int)$parts[4] : 0,
            'tx'     => isset($parts[5]) ? (int)$parts[5] : 0,
            'ty'     => isset($parts[6]) ? (int)$parts[6] : 0,
        );
    }

    fclose($fp);

    return array($command, $land, $landValue);
}

// 개별 섬 정보 테이블 출력
function campIslandInfo($island, $rank) {
    global $HthisFile, $HtagName_, $H_tagName, $HtagName2_, $H_tagName2, $AfterName, $HunitMoney, $HunitFood, $HunitOre, $HunitOil, $HunitWeapon, $HbgTitleCell;

    $id      = $island['id'];
    $absent  = (int)$island['absent'];

    if ($absent == 0) {
        $name = "{$HtagName_}{$island['name']}{$AfterName}{$H_tagName}";
    } else {
        $name = "{$HtagName2_}{$island['name']}{$AfterName}({$absent}){$H_tagName2}";
    }

    out(<<<END
<table><tr>
<th {$HbgTitleCell}>데이터</th>
<th {$HbgTitleCell}>NO</th>
<th {$HbgTitleCell}>명령</th>
<th {$HbgTitleCell}>목표</th>
<th {$HbgTitleCell}>좌표１</th>
<th {$HbgTitleCell}>수량</th>
<th {$HbgTitleCell}>좌표２</th>
</tr>
<tr><td rowspan=30>
<A HREF="{$HthisFile}?Sight={$id}" class="M" TARGET=_blank>{$name}</A><br>
{$island['ownername']}<br><br>
자금：{$island['money']}{$HunitMoney}<br>
식량：{$island['food']}{$HunitFood}<br>
광석：{$island['ore']}{$HunitOre}<br>
원유：{$island['oil']}{$HunitOil}<br>
병기：{$island['weapon']}{$HunitWeapon}<br>
미사일 발사수：{$island['MissileK']}<br>
</td>
END
    );

    for ($i = 0; $i < 15; $i++) {
        campCommand($i, $island['command'][$i]);
    }

    out("</table>\n");
}

// 커맨드 1행 출력
function campCommand($number, $command) {
    global $HthisFile, $HtagComName_, $H_tagComName, $HcomName, $HtagName_, $H_tagName, $HtagNumber_, $H_tagNumber, $HidToName, $AfterName, $HcomCost, $HunitMoney, $HunitFood;

    $kind   = isset($command['kind'])   ? (int)$command['kind']   : 0;
    $target = isset($command['target']) ? (int)$command['target'] : 0;
    $x      = isset($command['x'])      ? (int)$command['x']      : 0;
    $y      = isset($command['y'])      ? (int)$command['y']      : 0;
    $arg    = isset($command['arg'])    ? (int)$command['arg']    : 0;
    $tx     = isset($command['tx'])     ? (int)$command['tx']     : 0;
    $ty     = isset($command['ty'])     ? (int)$command['ty']     : 0;

    $cmdName  = "{$HtagComName_}{$HcomName[$kind]}{$H_tagComName}";
    $point    = "{$HtagName_}({$x},{$y}){$H_tagName}";
    $point2   = "{$HtagName_}({$tx},{$ty}){$H_tagName}";

    $id          = $target;
    $targetName  = isset($HidToName[$target]) ? $HidToName[$target] : '';

    if ($targetName === '') {
        $targetDisp = "-------";
    } else {
        $targetDisp = "<A HREF=\"{$HthisFile}?Sight={$id}\" class=\"M\" TARGET=_blank>"
                    . "{$HtagName_}{$targetName}{$AfterName}{$H_tagName}</a>";
    }

    $value = $arg * $HcomCost[$kind];
    if ($value == 0) $value = $HcomCost[$kind];

    if ($value < 0) {
        $value = abs($value);
        $valueDisp = "{$HtagName_}{$value}{$HunitFood}{$H_tagName}";
    } else {
        $valueDisp = "{$HtagName_}{$value}{$HunitMoney}{$H_tagName}";
    }

    $j = sprintf("%02d", $number + 1);

    if ($number > 0) {
        out("<tr>");
    }
    out("<td>{$HtagNumber_}{$j}{$H_tagNumber}</td>");
    out("<td>{$cmdName}</td><td>{$targetDisp}</td><td>{$point}</td><td>{$arg}</td><td>{$valueDisp}</td><td>{$point2}</td>");
    out("</tr>\n");
}
