<?php
if (!isset($_hako_fh)) { $_hako_fh = array(); }
if (!function_exists('hako_open')) {
  function hako_open($name, $spec) {
    global $_hako_fh;
    $mode = 'r';
    $path = $spec;
    if (substr($path, 0, 2) === '>>') { $mode = 'a'; $path = substr($path, 2); }
    elseif (substr($path, 0, 1) === '>') { $mode = 'w'; $path = substr($path, 1); }
    elseif (substr($path, 0, 1) === '<') { $mode = 'r'; $path = substr($path, 1); }
    $_hako_fh[$name] = @fopen($path, $mode);
    return $_hako_fh[$name];
  }
  function hako_close($name) {
    global $_hako_fh;
    if (isset($_hako_fh[$name]) && is_resource($_hako_fh[$name])) { fclose($_hako_fh[$name]); }
  }
  function hako_getline($name) {
    global $_hako_fh;
    if (!isset($_hako_fh[$name]) || !$_hako_fh[$name]) { return false; }
    return fgets($_hako_fh[$name]);
  }
  function hako_write($name, $data) {
    global $_hako_fh;
    if (!isset($_hako_fh[$name]) || !$_hako_fh[$name]) { return false; }
    return fwrite($_hako_fh[$name], $data);
  }
  function hako_cmp($a, $b) {
    if ($a == $b) { return 0; }
    return ($a < $b) ? -1 : 1;
  }
  function hako_reorder($array, $idx) {
    $out = array();
    foreach ($idx as $i) { if (isset($array[$i])) { $out[] = $array[$i]; } }
    return $out;
  }
  function hako_pick($array, $keys) {
    $out = array();
    foreach ($keys as $key) { $out[] = isset($array[$key]) ? $array[$key] : null; }
    return $out;
  }
  function hako_idx($array, $idx) {
    return isset($array[$idx]) ? $array[$idx] : null;
  }
}
//
//
// ?자???별㉤?
// ?자????001/03/17
// 버젼?.5
// ?력????001/01/17 초판 ?성
// ??????001/01/17 버그 ?정??인?의 ???// ??????001/01/19 ?위가 ?의 ?에???재??? ?는 버그??정
// ??????001/03/17 ?끼리의 거래??동 처리?는 기능??추?
//
// ??????003/06/22 구상??모형?원 5?으?커스?마?즈
// ??????003/09/20 거래 ?모 ?인 기능??추?
// ??????004/02/13 0?로 ?누??경우가 ?는 문제??정.
// ??????004/07/10 ?재가 병기 부족해 ?패가 ?는 문제??정.
// ??????005/01/24 갱신 ?간???장 ? 개발 ?면?로부??참조?는 거래 ?황 2??성
// ??????005/02/06 ?터?이?? 개량·?재 처리??ON, OFF ?정 추?(ShibaAni)
// ??????006/04/15 ?재??시?? ?는 ?정??경우, ?재 ?이?? 만들지 ?게 ?정

// ?모형?원 ?계???원 거래?? 개설?니??
//
//

// 불성립의 거래가 ?동 ?기???까지???수
$HexchangeDelTurns = 12;

// 거래 ?목
$HexchangeName = array('자금', '식량', '광석', '원유', '병기');
// 거래 ?목??$island->{} ???름( ?괴???치?고?????원 ?외??거래?서??''?지??
$HexchangeVars = array('money', 'food', 'ore', 'oil', 'weapon');
// 거래 ?목??수량 배율
$HexchangeRate = array(10, 10, 10, 10, 10);
// 거래 ?목???위
$HexchangeUnit = array($HunitMoney, $HunitFood, $HunitOre, $HunitOil, $HunitWeapon);
// ?끼리의 거래??동 처리?까?
// ??동 처리?? ?으?// ??·?끼리의 거래를 삭제립?에 ?레?어가 개발 계획?로???시?니??
// ??·?원??부족이 ?어??모형?원 ?원 거래 ?원?는 칸치 ?? ?습?다.
// ??·?인과의 거래를 삭제립 ?점?서 ?해집니??
// ??동 처리?면(??
// ??·?끼리의 거래를 삭제립 ?점?서 ?해집니??
// ??·?인과의 거래를 삭제립 ?점?서 ?해집니??
$HexchangeAutoMode = 1; # 0:수동,1:자동

// ?원??부족이 ?으?모형?원 ?원 거래 ?원?에 ?해 ?재??시?다.
$HpenaltyExchangeSwitch = 1; # 0:실시하지 않는,1:실시한다

// ?인???름
$HexchangeMerchantName = array('농업 조합', '광석 조합', '원유 조합', '무기 조합');
// ??인??출현 ?률( ??인마다 0%~100%)
// ·?인??출현?는 것? ?해??태? ?느 ?인??출현?는지 ?정?는 ?률?니??// ·?률100%???인???으??아무도 출현?? ?는?」것???습?다
$HexchangeMerchantPercent = array(80, 60, 50, 40);
// 모형?원 ?원 거래 ?원?의 ?재 ?단
$HexchangePenaltyAttack = 3; # 0:미사일,1:인조 괴수,2:기념비,3:랜덤

// 거래 ?이?의 ?일
$HexchangeFile = "$HlogdirName/exchange.dat";

// 거래 데이터
$HexchangeID = 1;
$HexchangeData = array();
function readExchange() {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $HbgInfoCell, $HbgNumberCell, $HbgTitleCell, $HcomMissileNM, $HcurrentID, $HcurrentName, $HcurrentNumber, $HdefaultPassword, $helpDir, $HexchangeAutoMode, $HexchangeBidID, $HexchangeBuy, $HexchangeBuyCost, $HexchangeCon, $HexchangeData, $HexchangeDelID, $HexchangeDelTurns, $HexchangeFile, $HexchangeID, $HexchangeMerchantName, $HexchangeMerchantPercent, $HexchangeMode, $HexchangeName, $HexchangePenaltyAttack, $HexchangeRate, $HexchangeSell, $HexchangeSellCost, $HexchangeUnit, $HexchangeVars, $HidToNumber, $HinputPassword, $HislandList, $Hislands, $HislandSize, $HislandTurn, $HlandBase, $HlandSea, $HlogdirName, $HmaxExpPoint, $HpenaltyExchangeSwitch, $HtempBack, $HthisFile, $htmltmp, $HunitFood, $HunitMoney, $HunitOil, $HunitOre, $HunitWeapon, $imageDir, $lockMode, $toppage, $versionInfo;

	if (hako_open('Fexchange', "<$HexchangeFile")) {
		$bac = (null);


		$HexchangeID = rtrim(hako_getline('Fexchange'));
		$HexchangeData = array();
		while (($_ = hako_getline('Fexchange')) !== false) {
			$_ = preg_split('/,/', rtrim($_));
			$exchange = null;
			$exchange['id']        = array_shift($_); 			$exchange['iid']       = array_shift($_); 			$exchange['turn']      = array_shift($_); 			$exchange['sell']      = array_shift($_); 			$exchange['sell_cost'] = array_shift($_); 			$exchange['buy']       = array_shift($_); 			$exchange['buy_cost']  = array_shift($_); 			$exchange['bid']       = array_shift($_); 			$exchange['bid_cost']  = array_shift($_); 			$exchange['rtime']     = array_shift($_);
			array_push($HexchangeData, $exchange);
		}

		hako_close('Fexchange');

$bac = null;
		return 1;
	}
	return null;
}

// 거래 ?이?? 기입?다
function writeExchange() {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $HbgInfoCell, $HbgNumberCell, $HbgTitleCell, $HcomMissileNM, $HcurrentID, $HcurrentName, $HcurrentNumber, $HdefaultPassword, $helpDir, $HexchangeAutoMode, $HexchangeBidID, $HexchangeBuy, $HexchangeBuyCost, $HexchangeCon, $HexchangeData, $HexchangeDelID, $HexchangeDelTurns, $HexchangeFile, $HexchangeID, $HexchangeMerchantName, $HexchangeMerchantPercent, $HexchangeMode, $HexchangeName, $HexchangePenaltyAttack, $HexchangeRate, $HexchangeSell, $HexchangeSellCost, $HexchangeUnit, $HexchangeVars, $HidToNumber, $HinputPassword, $HislandList, $Hislands, $HislandSize, $HislandTurn, $HlandBase, $HlandSea, $HlogdirName, $HmaxExpPoint, $HpenaltyExchangeSwitch, $HtempBack, $HthisFile, $htmltmp, $HunitFood, $HunitMoney, $HunitOil, $HunitOre, $HunitWeapon, $imageDir, $lockMode, $toppage, $versionInfo;

	if (hako_open('Fexchange', ">$HexchangeFile")) {
		$bac = array(null, null, null);
		hako_write('Fexchange', $HexchangeID . "\n");
		$exchange = null;
		foreach ($HexchangeData as $exchange) {
			if (!isset($exchange)) { continue; }
			hako_write('Fexchange', implode(',', array($exchange['id'], $exchange['iid'], $exchange['turn'], $exchange['sell'], $exchange['sell_cost'], $exchange['buy'], $exchange['buy_cost'], $exchange['bid'], $exchange['bid_cost'], $exchange['rtime'])) . "\n");
	}
	hako_close('Fexchange');


		return 1;
	}
	return null;
}


// 거래 ?황
function infoExchange() {
	global $HbgInfoCell, $HbgNumberCell, $HbgTitleCell, $HtagTH_, $H_tagTH, $HtagNumber_, $H_tagNumber, $HtagName_, $H_tagName, $HexchangeData, $HexchangeRate, $HexchangeUnit,
	       $HexchangeName, $HexchangeMerchantName, $HidToNumber, $Hislands;

	out(<<<END
<table border>
  <tr>
    <th $HbgTitleCell nowrap>${HtagTH_}거래 번호${H_tagTH}</th>
    <th $HbgTitleCell nowrap>${HtagTH_}제공 자원${H_tagTH}</th>
    <th $HbgTitleCell nowrap>${HtagTH_}수량${H_tagTH}</th>
    <th $HbgTitleCell nowrap>${HtagTH_}희망 자원${H_tagTH}</th>
    <th $HbgTitleCell nowrap>${HtagTH_}수량${H_tagTH}</th>
    <th $HbgTitleCell nowrap>${HtagTH_}등록 턴${H_tagTH}</th>
    <th $HbgTitleCell nowrap>${HtagTH_}모집 ID${H_tagTH}</th>
    <th $HbgTitleCell nowrap>${HtagTH_}응모 수량${H_tagTH}</th>
    <th $HbgTitleCell nowrap>${HtagTH_}응모 ID${H_tagTH}</th>
  </tr>
END
	);

	foreach ($HexchangeData as $exchange) {
		if (!isset($exchange)) { continue; }
		$id = $exchange['id'];
		$iid = $exchange['iid'];
		if ($iid == -99999) { continue; }

		if ($iid >= 0) {
			if (!isset($HidToNumber[$iid]) || !isset($Hislands[$HidToNumber[$iid]])) { continue; }
			$island = $Hislands[$HidToNumber[$iid]];
			$name = $island['name'] . '도';
		} else {
			$name = isset($HexchangeMerchantName[-$iid - 1]) ? $HexchangeMerchantName[-$iid - 1] : '';
		}

		$turn = $exchange['turn'];
		$sell = $exchange['sell'];
		$sell_cost = $exchange['sell_cost'] * $HexchangeRate[$sell];
		$buy = $exchange['buy'];
		$buy_cost = $exchange['buy_cost'] * $HexchangeRate[$buy];

		$bid = $exchange['bid'];
		if ($bid >= 0) {
			if (!isset($HidToNumber[$bid]) || !isset($Hislands[$HidToNumber[$bid]])) { continue; }
			$island = $Hislands[$HidToNumber[$bid]];
			$bid = $island['name'] . '도';
		} elseif ($bid != -99999) {
			$bid = isset($HexchangeMerchantName[-$bid - 1]) ? $HexchangeMerchantName[-$bid - 1] : '';
		} else {
			$bid = '&nbsp;';
		}
		$bid_cost = (isset($exchange['bid_cost']) ? $exchange['bid_cost'] : 0) * $HexchangeRate[$buy];

		out(<<<END
  <tr>
    <th $HbgNumberCell nowrap align="right">${HtagNumber_}$id${H_tagNumber}</th>
    <td $HbgInfoCell nowrap align="center">{$HexchangeName[$sell]}</td>
    <td $HbgInfoCell nowrap align="right">$sell_cost{$HexchangeUnit[$sell]}</td>
    <td $HbgInfoCell nowrap align="center">{$HexchangeName[$buy]}</td>
    <td $HbgInfoCell nowrap align="right">$buy_cost{$HexchangeUnit[$buy]}</td>
    <td $HbgInfoCell nowrap align="right">$turn 턴</td>
    <td $HbgInfoCell nowrap>${HtagName_}$name${H_tagName}</td>
    <td $HbgInfoCell nowrap align="right">$bid_cost{$HexchangeUnit[$buy]}</td>
    <td $HbgInfoCell nowrap>${HtagName_}$bid${H_tagName}</td>
  </tr>
END
		);
	}

	out(<<<END
</table>
END
	);
}
function infoExchange2($cmdtime) {
	global $HbgInfoCell, $HbgNumberCell, $HbgTitleCell, $HtagTH_, $H_tagTH, $HtagNumber_, $H_tagNumber, $HtagName_, $H_tagName, $HexchangeData, $HexchangeRate, $HexchangeUnit,
	       $HexchangeName, $HexchangeMerchantName, $HidToNumber, $Hislands;

	$htmltmp = <<<END
<hr><DIV ID='islandInfo'>갱신된 거래 정보<table border>
  <tr>
    <th $HbgTitleCell nowrap>${HtagTH_}거래 번호${H_tagTH}</th>
    <th $HbgTitleCell nowrap>${HtagTH_}제공 자원${H_tagTH}</th>
    <th $HbgTitleCell nowrap>${HtagTH_}수량${H_tagTH}</th>
    <th $HbgTitleCell nowrap>${HtagTH_}희망 자원${H_tagTH}</th>
    <th $HbgTitleCell nowrap>${HtagTH_}수량${H_tagTH}</th>
    <th $HbgTitleCell nowrap>${HtagTH_}응모 수량${H_tagTH}</th>
    <th $HbgTitleCell nowrap>${HtagTH_}응모 ID${H_tagTH}</th>
  </tr>
END;

	foreach ($HexchangeData as $exchange) {
		if (!isset($exchange)) { continue; }
		$id = $exchange['id'];
		$iid = $exchange['iid'];
		if ($iid == -99999 || $cmdtime > $exchange['rtime']) { continue; }

		$sell = $exchange['sell'];
		$sell_cost = $exchange['sell_cost'] * $HexchangeRate[$sell];
		$buy = $exchange['buy'];
		$buy_cost = $exchange['buy_cost'] * $HexchangeRate[$buy];
		$bid = $exchange['bid'];
		if ($bid >= 0) {
			if (!isset($HidToNumber[$bid]) || !isset($Hislands[$HidToNumber[$bid]])) { continue; }
			$island = $Hislands[$HidToNumber[$bid]];
			$bid = $island['name'] . '도';
		} elseif ($bid != -99999) {
			$bid = isset($HexchangeMerchantName[-$bid - 1]) ? $HexchangeMerchantName[-$bid - 1] : '';
		} else {
			$bid = '&nbsp;';
		}
		$bid_cost = (isset($exchange['bid_cost']) ? $exchange['bid_cost'] : 0) * $HexchangeRate[$buy];

		out(<<<END
$htmltmp
  <tr>
    <th $HbgNumberCell nowrap align="right">${HtagNumber_}$id${H_tagNumber}</th>
    <td $HbgInfoCell nowrap align="center">{$HexchangeName[$sell]}</td>
    <td $HbgInfoCell nowrap align="right">$sell_cost{$HexchangeUnit[$sell]}</td>
    <td $HbgInfoCell nowrap align="center">{$HexchangeName[$buy]}</td>
    <td $HbgInfoCell nowrap align="right">$buy_cost{$HexchangeUnit[$buy]}</td>
    <td $HbgInfoCell nowrap align="right">$bid_cost{$HexchangeUnit[$buy]}</td>
    <td $HbgInfoCell nowrap>${HtagName_}$bid${H_tagName}</td>
  </tr>
END
		);
		$htmltmp = "";
	}
	if ($htmltmp == "") { out("</table></DIV><hr>"); }
}
function formExchange() {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $HbgInfoCell, $HbgNumberCell, $HbgTitleCell, $HcomMissileNM, $HcurrentID, $HcurrentName, $HcurrentNumber, $HdefaultPassword, $helpDir, $HexchangeAutoMode, $HexchangeBidID, $HexchangeBuy, $HexchangeBuyCost, $HexchangeCon, $HexchangeData, $HexchangeDelID, $HexchangeDelTurns, $HexchangeFile, $HexchangeID, $HexchangeMerchantName, $HexchangeMerchantPercent, $HexchangeMode, $HexchangeName, $HexchangePenaltyAttack, $HexchangeRate, $HexchangeSell, $HexchangeSellCost, $HexchangeUnit, $HexchangeVars, $HidToNumber, $HinputPassword, $HislandList, $Hislands, $HislandSize, $HislandTurn, $HlandBase, $HlandSea, $HlogdirName, $HmaxExpPoint, $HpenaltyExchangeSwitch, $HtempBack, $HthisFile, $htmltmp, $HunitFood, $HunitMoney, $HunitOil, $HunitOre, $HunitWeapon, $imageDir, $lockMode, $toppage, $versionInfo;
	$escapedDefaultPassword = htmlspecialchars($HdefaultPassword, ENT_QUOTES);

	$resource = ''; $number0 = ''; $number00 = ''; $idEx = ''; $ids = '';
	$i = null;
	for ($i = 0; $i <= (count($HexchangeName) - 1); $i++) {
		$resource .= "<option value=\"$i\">{$HexchangeName[$i]} ({$HexchangeRate[$i]}{$HexchangeUnit[$i]})";
	}

	for ($i = 0; $i < 100; $i++) {
		$number0  .= "<option value=\"$i\">$i";
		$number00 .= "<option value=\"$i\">" . sprintf('%02d', $i);
	}

	$exchange = null;
	foreach ($HexchangeData as $exchangeKey => $exchange) {
		if (!isset($exchange) || !is_array($exchange)) { continue; }
		if (isset($exchange['iid']) && $exchange['iid'] == -99999) { continue; }
		$i = (isset($exchange['id']) && $exchange['id'] !== '') ? $exchange['id'] : $exchangeKey;
		$j = isset($exchange['buy']) ? intval($exchange['buy']) : 0;
		$tradeNo = htmlspecialchars($i, ENT_QUOTES, 'UTF-8');
		$rate = isset($HexchangeRate[$j]) ? $HexchangeRate[$j] : '';
		$unit = isset($HexchangeUnit[$j]) ? $HexchangeUnit[$j] : '';
		$idEx .= "<form action=\"$HthisFile\" method=\"POST\">
						  <tr>
							  <td><input type=\"submit\" value=\"{$tradeNo}응모\" name=\"ExchangeBidButton\"><input type=\"hidden\" name=\"EXC_ID\" value=\"$tradeNo\"></td>
						    <td><select name=\"EXC_SELL1\">$number0</select><select name=\"EXC_SELL0\">$number00</select>　×　$rate$unit</td>
								<td><select name=\"ISLANDID\">$HislandList</select></td>
						    <td><input type=\"password\" name=\"PASSWORD\" value=\"$escapedDefaultPassword\" size=\"32\" maxlength=\"32\"></td>
						  </tr>
							<input type=\"hidden\" name=\"dummy\">
						 </form>";
						 
		$ids .= "<option value=\"$tradeNo\">$tradeNo";
	}

	out(<<<END
<table border>
  <tr>
    <th nowrap>응모 거래</th>
    <th nowrap>수량</th>
		<th nowrap>ID</th>
    <th nowrap>패스워드</th>
  </tr>
	$idEx
</table>
<br>
<form action="$HthisFile" method="POST">
<table border>
  <tr>
    <th nowrap>모집 거래</th>
    <th nowrap>제공 자원</th>
    <th nowrap>희망 자원</th>
    <th nowrap>ID</th>
    <th nowrap>패스워드</th>
  </tr>
  <tr>
		<td><input type="submit" value="거래를 등록" name="ExchangeButton"></td>
    <td><select name="EXC_SELL">$resource</select>　×　<select name="EXC_SELL1">$number0</select><select name="EXC_SELL0">$number00</select></td>
    <td><select name="EXC_BUY">$resource</select>　×　<select name="EXC_BUY1">$number0</select><select name="EXC_BUY0">$number00</select></td>
    <td><select name="ISLANDID">$HislandList</select></td>
    <td><input type="password" name="PASSWORD" value="$escapedDefaultPassword" size="32" maxlength="32"></td>
  </tr>
</table>
<input type="hidden" name="dummy">
</form>
<br>
<form action="$HthisFile" method="POST">
<table border>
  <tr>
    <th nowrap>삭제 거래</th>
    <th nowrap>거래 번호</th>
    <th nowrap>ID</th>
    <th nowrap>패스워드</th>
  </tr>
  <tr>
		<td><input type="submit" value="거래를 삭제" name="ExchangeDelButton"></td>
    <td><select name="EXC_ID">$ids</select></td>
    <td><select name="ISLANDID">$HislandList</select></td>
    <td><input type="password" name="PASSWORD" value="$escapedDefaultPassword" size="32" maxlength="32"></td>
  </tr>
</table>
<input type="hidden" name="dummy">
</form>
END
);
}

// 거래 페이지
function htmlExchange() {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $HbgInfoCell, $HbgNumberCell, $HbgTitleCell, $HcomMissileNM, $HcurrentID, $HcurrentName, $HcurrentNumber, $HdefaultPassword, $helpDir, $HexchangeAutoMode, $HexchangeBidID, $HexchangeBuy, $HexchangeBuyCost, $HexchangeCon, $HexchangeData, $HexchangeDelID, $HexchangeDelTurns, $HexchangeFile, $HexchangeID, $HexchangeMerchantName, $HexchangeMerchantPercent, $HexchangeMode, $HexchangeName, $HexchangePenaltyAttack, $HexchangeRate, $HexchangeSell, $HexchangeSellCost, $HexchangeUnit, $HexchangeVars, $HidToNumber, $HinputPassword, $HislandList, $Hislands, $HislandSize, $HislandTurn, $HlandBase, $HlandSea, $HlogdirName, $HmaxExpPoint, $HpenaltyExchangeSwitch, $HtempBack, $HthisFile, $htmltmp, $HunitFood, $HunitMoney, $HunitOil, $HunitOre, $HunitWeapon, $imageDir, $lockMode, $toppage, $versionInfo;


	readExchange();

	// 개방
	unlock();

	out(<<<END
$HtempBack
<h1>구상의 모형정원 자원 거래소</h1>
<b>여기에서는 각 도이 소유하고 있는 자원을 다른 자원으로 교환하는 중개를 실시 하고 있습니다.  </b><br>
·거래는 옥션 형식입니다. 높은 가격을 제시한 섬하고 거래가 턴 갱신되면 성립합니다. <br>
·거래가 성립하지 않는 채 $HexchangeDelTurns 턴이 경과하면 등록이 말소됩니다.<br>
END
);
	if ($HexchangeAutoMode) {
		out("·섬끼리의 거래는 성립 시점에서 행해집니다.<br>");
	}else{
		out("·<font color=\"red\">거래가 성립하면 책임을 가져서 거래를 실행해 주세요. 자동에서는 실행되지 않습니다. </font><br>");
	}
	out("·도 외에 모집하고 있는 거래는 턴 갱신시에 자동 결제됩니다.<br>");
	if ($HpenaltyExchangeSwitch) { out("·<font color=\"red\">부족이 있으면 제재를 합니다.</font><br>"); }
	infoExchange();
	out("<br>");
	formExchange();
}

// 패널티 처리
function penaltyExchange() {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $HbgInfoCell, $HbgNumberCell, $HbgTitleCell, $HcomMissileNM, $HcurrentID, $HcurrentName, $HcurrentNumber, $HdefaultPassword, $helpDir, $HexchangeAutoMode, $HexchangeBidID, $HexchangeBuy, $HexchangeBuyCost, $HexchangeCon, $HexchangeData, $HexchangeDelID, $HexchangeDelTurns, $HexchangeFile, $HexchangeID, $HexchangeMerchantName, $HexchangeMerchantPercent, $HexchangeMode, $HexchangeName, $HexchangePenaltyAttack, $HexchangeRate, $HexchangeSell, $HexchangeSellCost, $HexchangeUnit, $HexchangeVars, $HidToNumber, $HinputPassword, $HislandList, $Hislands, $HislandSize, $HislandTurn, $HlandBase, $HlandSea, $HlogdirName, $HmaxExpPoint, $HpenaltyExchangeSwitch, $HtempBack, $HthisFile, $htmltmp, $HunitFood, $HunitMoney, $HunitOil, $HunitOre, $HunitWeapon, $imageDir, $lockMode, $toppage, $versionInfo;


	readExchange();
	if (!($HpenaltyExchangeSwitch)) { return; }

	// 패널티 데이터가 있을까 조사한다
	$exchange = null; $iid = null; $tn = null; $island = null;
	foreach ($HexchangeData as $exchange) {
		if (!isset($exchange)) { continue; }
		$iid = $exchange['iid'];
		if ($iid != -99999) { continue; }

		$tn = $HidToNumber[$exchange['bid']];
		if (isset($tn)) {
			// ?이 존재?다
			$island =& $Hislands[$tn];

			// ?재 ?행
			$penalty = $exchange['bid_cost'];
			if ($HexchangePenaltyAttack == 3) { $HexchangePenaltyAttack = random(3); }
			if ($HexchangePenaltyAttack == 0) {
				// 미사??				if ($penalty > 16) { $penalty = 16; }

				$comIsland = makeComIsland("exchange");
				$target = $exchange['bid'];
				$n = $penalty;
				$i = null;
				for ($i = 0; $i < $n; $i++) {
					doMissileFireRandom($comIsland, $target, $HcomMissileNM, 5); # ?상 미사?을 5발단?로 발사
					doCommand($comIsland);
				}
			} elseif ($HexchangePenaltyAttack == 1) {
				// ?조 괴수
				if ($penalty > 16) { $penalty = 16; }

				$island['monstersend'] += $penalty;
			} else {
				// 기념?				if ($penalty > 8) { $penalty = 8; }

				$island['bigmissile'] += $penalty;
			}
		}

		$exchange = null;
	}
}

function turnExchangeBegin() {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $HbgInfoCell, $HbgNumberCell, $HbgTitleCell, $HcomMissileNM, $HcurrentID, $HcurrentName, $HcurrentNumber, $HdefaultPassword, $helpDir, $HexchangeAutoMode, $HexchangeBidID, $HexchangeBuy, $HexchangeBuyCost, $HexchangeCon, $HexchangeData, $HexchangeDelID, $HexchangeDelTurns, $HexchangeFile, $HexchangeID, $HexchangeMerchantName, $HexchangeMerchantPercent, $HexchangeMode, $HexchangeName, $HexchangePenaltyAttack, $HexchangeRate, $HexchangeSell, $HexchangeSellCost, $HexchangeUnit, $HexchangeVars, $HidToNumber, $HinputPassword, $HislandList, $Hislands, $HislandSize, $HislandTurn, $HlandBase, $HlandSea, $HlogdirName, $HmaxExpPoint, $HpenaltyExchangeSwitch, $HtempBack, $HthisFile, $htmltmp, $HunitFood, $HunitMoney, $HunitOil, $HunitOre, $HunitWeapon, $imageDir, $lockMode, $toppage, $versionInfo;


}

// 거래를 삭제?처리
function turnExchange() {
	global $HexchangeData, $HexchangeRate, $HexchangeUnit, $HexchangeName, $HexchangeMerchantName, $HexchangeVars, $HidToNumber, $Hislands, $HislandTurn, $HexchangeDelTurns,
	       $HexchangeAutoMode, $HexchangeID, $HcurrentID, $HpenaltyExchangeSwitch;

	foreach ($HexchangeData as $exIdx => &$exchange) {
		if (!isset($exchange)) { continue; }
		$iid = $exchange['iid'];
		$dead = false;
		$bdead = false;
		$name = '';
		$bname = '';

		if ($iid == -99999) {
			$iid = $exchange['bid'];
			if (!isset($HidToNumber[$iid]) || !isset($Hislands[$HidToNumber[$iid]])) {
				unset($HexchangeData[$exIdx]);
				continue;
			}
			$island =& $Hislands[$HidToNumber[$iid]];
			if (!empty($island['dead'])) { unset($HexchangeData[$exIdx]); }
			unset($island);
			continue;
		}

		if ($iid >= 0) {
			if (!isset($HidToNumber[$iid]) || !isset($Hislands[$HidToNumber[$iid]])) {
				unset($HexchangeData[$exIdx]);
				continue;
			}
			$island =& $Hislands[$HidToNumber[$iid]];
			$name = $island['name'];
			$dead = !empty($island['dead']);
		}

		$bid = $exchange['bid'];
		if ($bid >= 0) {
			if (!isset($HidToNumber[$bid]) || !isset($Hislands[$HidToNumber[$bid]])) {
				$bdead = true;
				$bname = '';
			} else {
				$bisland =& $Hislands[$HidToNumber[$bid]];
				$bname = $bisland['name'];
				$bdead = !empty($bisland['dead']);
			}
		}

		if ($dead) {
			$logBid = ($bid < 0) ? null : $bid;
			logExcDead1($logBid, $name, $exchange['id']);
			unset($HexchangeData[$exIdx]);
			if (isset($island)) { unset($island); }
			if (isset($bisland)) { unset($bisland); }
			continue;
		}

		if ($bdead && ($iid < 0)) {
			logExcDead1(null, $bname, $exchange['id']);
			unset($HexchangeData[$exIdx]);
			if (isset($bisland)) { unset($bisland); }
			continue;
		}
		if ($bdead) {
			logExcDead2($iid, $bname, $exchange['id']);
			$exchange['bid'] = -99999;
			$exchange['bid_cost'] = 0;
			$bid = -99999;
		}

		if ($bid < 0) {
			if ($HislandTurn - $exchange['turn'] >= $HexchangeDelTurns) {
				$logIid = ($iid < 0) ? null : $iid;
				logExcLimit($logIid, $exchange['id']);
				unset($HexchangeData[$exIdx]);
			} elseif ($iid < 0) {
				if ($HislandTurn - $exchange['turn'] >= 1) { unset($HexchangeData[$exIdx]); }
			}
			if (isset($island)) { unset($island); }
			if (isset($bisland)) { unset($bisland); }
			continue;
		}

		$sell = $exchange['sell'];
		$sell_cost = $exchange['sell_cost'] * $HexchangeRate[$sell];
		$buy = $exchange['buy'];
		$buy_cost = $exchange['buy_cost'] * $HexchangeRate[$buy];
		$bid_cost = (isset($exchange['bid_cost']) ? $exchange['bid_cost'] : 0) * $HexchangeRate[$buy];
		$penalty = 0;
		$bpenalty = 0;

		if ($iid >= 0) {
			$var = isset($HexchangeVars[$sell]) ? $HexchangeVars[$sell] : null;
			if (isset($var) && $var !== '') {
				$sell_value = isset($island[$var]) ? $island[$var] : 0;
				if ($sell_value < $sell_cost) {
					if ($sell_value < 1) { $sell_value = 1; }
					$penalty += intval($sell_cost / $sell_value);
				}
			}
		}

		if ($bid >= 0) {
			$var = isset($HexchangeVars[$buy]) ? $HexchangeVars[$buy] : null;
			if (isset($var) && $var !== '') {
				$buy_value = isset($bisland[$var]) ? $bisland[$var] : 0;
				if ($buy_value < $bid_cost) {
					if ($buy_value < 1) { $buy_value = 1; }
					$bpenalty += intval($bid_cost / $buy_value);
				}
			}
		}

		if ($iid >= 0) {
			$name .= '도';
			$bname .= '도';
		} else {
			$name = isset($HexchangeMerchantName[-$iid - 1]) ? $HexchangeMerchantName[-$iid - 1] : '';
			$bname .= '도';
		}

		if (!$penalty && !$bpenalty) {
			if ($iid >= 0) {
				if ($HexchangeAutoMode) {
					$var = isset($HexchangeVars[$sell]) ? $HexchangeVars[$sell] : null;
					if (isset($var) && $var !== '') {
						$island[$var] -= $sell_cost;
						$bisland[$var] += $sell_cost;
					}
					$var = isset($HexchangeVars[$buy]) ? $HexchangeVars[$buy] : null;
					if (isset($var) && $var !== '') {
						$island[$var] += $bid_cost;
						$bisland[$var] -= $bid_cost;
					}
				}
			} else {
				$var = isset($HexchangeVars[$sell]) ? $HexchangeVars[$sell] : null;
				if (isset($var) && $var !== '') { $bisland[$var] += $sell_cost; }
				$var = isset($HexchangeVars[$buy]) ? $HexchangeVars[$buy] : null;
				if (isset($var) && $var !== '') { $bisland[$var] -= $bid_cost; }
			}

			$sellText = $HexchangeName[$sell] . $sell_cost . $HexchangeUnit[$sell];
			$buyText = $HexchangeName[$buy] . $bid_cost . $HexchangeUnit[$buy];
			logExcSuccess($bid, $name, (($iid >= 0) ? $iid : null), $bname, $exchange['id'], $sellText, $buyText, (($iid < 0) ? 1 : $HexchangeAutoMode));
		} else {
			$sellText = $HexchangeName[$sell] . $sell_cost . $HexchangeUnit[$sell];
			$buyText = $HexchangeName[$buy] . $bid_cost . $HexchangeUnit[$buy];
			logExcSuccess($bid, $name, (($iid >= 0) ? $iid : null), $bname, $exchange['id'], $sellText, $buyText, (($iid < 0) ? 1 : $HexchangeAutoMode));

			if ($penalty && $HexchangeAutoMode) {
				if ($HpenaltyExchangeSwitch) {
					$newExchange = array('id' => $HexchangeID++, 'iid' => -99999, 'turn' => $HcurrentID, 'bid' => $iid, 'bid_cost' => $penalty, 'sell' => 0, 'sell_cost' => 0, 'buy' => 0, 'buy_cost' => 0, 'rtime' => time());
					$HexchangeData[] = $newExchange;
				}
				logExcPenalty($iid, $bid, $name, $exchange['id'], $sellText, $penalty);
			}

			if ($bpenalty) {
				if ($iid >= 0) {
					if ($HexchangeAutoMode) {
						if ($HpenaltyExchangeSwitch) {
							$newExchange = array('id' => $HexchangeID++, 'iid' => -99999, 'turn' => $HcurrentID, 'bid' => $bid, 'bid_cost' => $bpenalty, 'sell' => 0, 'sell_cost' => 0, 'buy' => 0, 'buy_cost' => 0, 'rtime' => time());
							$HexchangeData[] = $newExchange;
						}
						logExcPenalty($bid, $iid, $bname, $exchange['id'], $buyText, $bpenalty);
					}
				} else {
					if ($HpenaltyExchangeSwitch) {
						$newExchange = array('id' => $HexchangeID++, 'iid' => -99999, 'turn' => $HcurrentID, 'bid' => $bid, 'bid_cost' => $bpenalty, 'sell' => 0, 'sell_cost' => 0, 'buy' => 0, 'buy_cost' => 0, 'rtime' => time());
						$HexchangeData[] = $newExchange;
					}
					logExcPenalty($bid, null, $bname, $exchange['id'], $buyText, $bpenalty);
				}
			}
		}

		unset($HexchangeData[$exIdx]);
		if (isset($island)) { unset($island); }
		if (isset($bisland)) { unset($bisland); }
	}
	unset($exchange);
}
function turnExchangeEnd() {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $HbgInfoCell, $HbgNumberCell, $HbgTitleCell, $HcomMissileNM, $HcurrentID, $HcurrentName, $HcurrentNumber, $HdefaultPassword, $helpDir, $HexchangeAutoMode, $HexchangeBidID, $HexchangeBuy, $HexchangeBuyCost, $HexchangeCon, $HexchangeData, $HexchangeDelID, $HexchangeDelTurns, $HexchangeFile, $HexchangeID, $HexchangeMerchantName, $HexchangeMerchantPercent, $HexchangeMode, $HexchangeName, $HexchangePenaltyAttack, $HexchangeRate, $HexchangeSell, $HexchangeSellCost, $HexchangeUnit, $HexchangeVars, $HidToNumber, $HinputPassword, $HislandList, $Hislands, $HislandSize, $HislandTurn, $HlandBase, $HlandSea, $HlogdirName, $HmaxExpPoint, $HpenaltyExchangeSwitch, $HtempBack, $HthisFile, $htmltmp, $HunitFood, $HunitMoney, $HunitOil, $HunitOre, $HunitWeapon, $imageDir, $lockMode, $toppage, $versionInfo;


	writeExchange();
}

// 거래 ?록·??
function mainExchange() {
	global $HexchangeMode, $HcurrentNumber, $HidToNumber, $HcurrentID, $Hislands, $HcurrentName, $HinputPassword, $HexchangeSell, $HexchangeBuy, $HexchangeSellCost, $HexchangeBuyCost,
	       $HexchangeID, $HislandTurn, $HexchangeData, $HexchangeBidID, $HexchangeCon, $HexchangeDelID;

	if ($HexchangeMode == 'show') {
		htmlExchange();
		return;
	}

	$HcurrentNumber = $HidToNumber[$HcurrentID];
	$island = $Hislands[$HcurrentNumber];
	$HcurrentName = $island['name'];

	if (!checkPassword($island['password'], $HinputPassword)) {
		unlock();
		tempWrongPassword();
		return;
	}

	readExchange();

	if ($HexchangeMode == 'add') {
		if (($HexchangeSell == $HexchangeBuy) || ($HexchangeSellCost == 0) || ($HexchangeBuyCost == 0)) {
			tempExcAddMiss();
		} else {
			$exchange = array();
			$exchange['id'] = $HexchangeID++;
			$exchange['iid'] = $HcurrentID;
			$exchange['turn'] = $HislandTurn;
			$exchange['sell'] = $HexchangeSell;
			$exchange['sell_cost'] = $HexchangeSellCost;
			$exchange['buy'] = $HexchangeBuy;
			$exchange['buy_cost'] = $HexchangeBuyCost;
			$exchange['bid'] = -99999;
			$exchange['bid_cost'] = 0;
			$exchange['rtime'] = time();
			$HexchangeData[] = $exchange;
			tempExcAddSuccess();
		}
	} elseif ($HexchangeMode == 'bid') {
		foreach ($HexchangeData as $exIdx => &$exchange) {
			if (!isset($exchange)) { continue; }
			if ($exchange['id'] == $HexchangeBidID) {
				if ($exchange['iid'] == $HcurrentID) {
					tempExcBidMiss();
				} else {
					if ($exchange['buy_cost'] > $HexchangeSellCost) {
						tempExcBidLimit();
					} elseif ((isset($exchange['bid_cost']) ? $exchange['bid_cost'] : 0) >= $HexchangeSellCost) {
						tempExcBidLow();
					} elseif ($HexchangeCon) {
						tempExcBidSuccess();
					} else {
						tempExcBidSuccess2();
						$exchange['bid'] = $HcurrentID;
						$exchange['bid_cost'] = $HexchangeSellCost;
						$exchange['rtime'] = time();
					}
				}
				break;
			}
		}
		unset($exchange);
	} elseif ($HexchangeMode == 'del') {
		foreach ($HexchangeData as $exIdx => $exchange) {
			if (!isset($exchange)) { continue; }
			if ($exchange['id'] == $HexchangeDelID) {
				if ($exchange['iid'] == $HcurrentID) {
					unset($HexchangeData[$exIdx]);
					tempExcDelSuccess();
				} else {
					tempExcDelMiss();
				}
				break;
			}
		}
	}

	writeExchange();
	htmlExchange();
}
function merchantInviteExchange() {
	global $HexchangeMerchantName, $HexchangeMerchantPercent, $HexchangeID, $HislandTurn, $HexchangeData;

	for ($i = 0; $i <= (count($HexchangeMerchantName) - 1); $i++) {
		if (mt_rand(0, 99) >= $HexchangeMerchantPercent[$i]) { continue; }

		$sell = 0;
		$sell_cost = 0;
		$buy = 0;
		$buy_cost = 0;
		if ($i == 0) {
			$sell = 1;
			$sell_cost = random(8) + 3;
			$buy = 0;
			$buy_cost = intval($sell_cost * (20 - random(9)) / 10);
			$sell_cost *= 10;
		} elseif ($i == 1) {
			$sell = 2;
			$sell_cost = random(91) + 10;
			$buy = 0;
			$buy_cost = intval($sell_cost * (19 - random(9)) / 10);
		} elseif ($i == 2) {
			$sell = 3;
			$sell_cost = random(91) + 10;
			$buy = 0;
			$buy_cost = intval($sell_cost * (48 - random(23)) / 10);
		} elseif ($i == 3) {
			$sell = 4;
			$sell_cost = random(36) + 5;
			$buy = 0;
			$buy_cost = $sell_cost * (22 - random(12));
		}

		$exchange = array();
		$exchange['id'] = $HexchangeID++;
		$exchange['iid'] = -$i - 1;
		$exchange['turn'] = $HislandTurn;
		$exchange['sell'] = $sell;
		$exchange['sell_cost'] = $sell_cost;
		$exchange['buy'] = $buy;
		$exchange['buy_cost'] = $buy_cost;
		$exchange['bid'] = -99999;
		$exchange['bid_cost'] = 0;
		$exchange['rtime'] = time();
		$HexchangeData[] = $exchange;
	}
}
function makeComIsland($name) {
	global $HislandSize, $HlandSea, $HlandBase, $HmaxExpPoint;

	$id = 255;
	require_once "./hako-make.php";
	$island = makeNewIsland();

	$island['name'] = $name;
	$island['id'] = $id;
	$island['money'] = 0x7fffffff;
	$island['food'] = 0x7fffffff;
	$island['weapon'] = 0x7fffffff;

	$land =& $island['land'];
	$landValue =& $island['landValue'];
	$n = 0;
	for ($y = 0; $y < $HislandSize; $y++) {
		for ($x = 0; $x < $HislandSize; $x++) {
			if ($land[$x][$y] != $HlandSea) { continue; }
			$land[$x][$y] = $HlandBase;
			$landValue[$x][$y] = $HmaxExpPoint;
			if (++$n >= 20) { break 2; }
		}
	}
	unset($land);
	unset($landValue);

	return $island;
}
function doMissileFireRandom(&$island, $target, $kind, $n) {
	global $HislandSize;

	$x = intval(random($HislandSize - 2) + 1);
	$y = intval(random($HislandSize - 2) + 1);
	slideBack($island['command'], 0, $kind, $target, $x, $y, $n);
}
function tempExcAddSuccess() {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $HbgInfoCell, $HbgNumberCell, $HbgTitleCell, $HcomMissileNM, $HcurrentID, $HcurrentName, $HcurrentNumber, $HdefaultPassword, $helpDir, $HexchangeAutoMode, $HexchangeBidID, $HexchangeBuy, $HexchangeBuyCost, $HexchangeCon, $HexchangeData, $HexchangeDelID, $HexchangeDelTurns, $HexchangeFile, $HexchangeID, $HexchangeMerchantName, $HexchangeMerchantPercent, $HexchangeMode, $HexchangeName, $HexchangePenaltyAttack, $HexchangeRate, $HexchangeSell, $HexchangeSellCost, $HexchangeUnit, $HexchangeVars, $HidToNumber, $HinputPassword, $HislandList, $Hislands, $HislandSize, $HislandTurn, $HlandBase, $HlandSea, $HlogdirName, $HmaxExpPoint, $HpenaltyExchangeSwitch, $HtempBack, $HthisFile, $htmltmp, $HunitFood, $HunitMoney, $HunitOil, $HunitOre, $HunitWeapon, $imageDir, $lockMode, $toppage, $versionInfo;
	out(<<<END
${HtagBig_}지정의 거래를 등록했습니다.${H_tagBig}
END
);
}

// 거래 추가 ?패
function tempExcAddMiss() {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $HbgInfoCell, $HbgNumberCell, $HbgTitleCell, $HcomMissileNM, $HcurrentID, $HcurrentName, $HcurrentNumber, $HdefaultPassword, $helpDir, $HexchangeAutoMode, $HexchangeBidID, $HexchangeBuy, $HexchangeBuyCost, $HexchangeCon, $HexchangeData, $HexchangeDelID, $HexchangeDelTurns, $HexchangeFile, $HexchangeID, $HexchangeMerchantName, $HexchangeMerchantPercent, $HexchangeMode, $HexchangeName, $HexchangePenaltyAttack, $HexchangeRate, $HexchangeSell, $HexchangeSellCost, $HexchangeUnit, $HexchangeVars, $HidToNumber, $HinputPassword, $HislandList, $Hislands, $HislandSize, $HislandTurn, $HlandBase, $HlandSea, $HlogdirName, $HmaxExpPoint, $HpenaltyExchangeSwitch, $HtempBack, $HthisFile, $htmltmp, $HunitFood, $HunitMoney, $HunitOil, $HunitOre, $HunitWeapon, $imageDir, $lockMode, $toppage, $versionInfo;
	out(<<<END
${HtagBig_}지정의 거래는 무효인 내용입니다.${H_tagBig}
END
);
}
// 거래 응모 ?인
function tempExcBidSuccess() {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $HbgInfoCell, $HbgNumberCell, $HbgTitleCell, $HcomMissileNM, $HcurrentID, $HcurrentName, $HcurrentNumber, $HdefaultPassword, $helpDir, $HexchangeAutoMode, $HexchangeBidID, $HexchangeBuy, $HexchangeBuyCost, $HexchangeCon, $HexchangeData, $HexchangeDelID, $HexchangeDelTurns, $HexchangeFile, $HexchangeID, $HexchangeMerchantName, $HexchangeMerchantPercent, $HexchangeMode, $HexchangeName, $HexchangePenaltyAttack, $HexchangeRate, $HexchangeSell, $HexchangeSellCost, $HexchangeUnit, $HexchangeVars, $HidToNumber, $HinputPassword, $HislandList, $Hislands, $HislandSize, $HislandTurn, $HlandBase, $HlandSea, $HlogdirName, $HmaxExpPoint, $HpenaltyExchangeSwitch, $HtempBack, $HthisFile, $htmltmp, $HunitFood, $HunitMoney, $HunitOil, $HunitOre, $HunitWeapon, $imageDir, $lockMode, $toppage, $versionInfo;
	$buy = null; $bid_cost = null;
	foreach ($HexchangeData as $exchange) {
		if (!isset($exchange)) { continue; }
		if($exchange['id'] == $HexchangeBidID){
			$HexchangeBuy = $exchange['buy'];
			$bid_cost = $HexchangeSellCost * $HexchangeRate[$HexchangeBuy];
			$bid_cost = $HexchangeName[$HexchangeBuy] . $bid_cost . $HexchangeUnit[$HexchangeBuy];
		}
	}
	$escapedDefaultPassword = htmlspecialchars($HdefaultPassword, ENT_QUOTES);
	out(<<<END
${HtagBig_}지정 거래의 응모를 확정합니까? ${H_tagBig}
<form action="$HthisFile" method="POST">
<table border>
  <tr>
    <th nowrap rowspan="2"><input type="submit" value="거래를 확정" name="ExchangeBid2Button"></th>
    <th nowrap>거래 번호</th>
    <th nowrap>수량</th>
  </tr>
  <tr>
    <td>$HexchangeBidID</td>
    <td>$bid_cost</td>
  </tr>
</table>
<input type="hidden" name="ISLANDID" value="$HcurrentID">
<input type="hidden" name="PASSWORD" value="$escapedDefaultPassword">
<input type="hidden" name="EXC_ID" value="$HexchangeBidID">
<input type="hidden" name="EXC_SELL" value="$HexchangeSellCost">
<input type="hidden" name="dummy">
</form>
END
);
}

// 거래 응모 ?정
function tempExcBidSuccess2() {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $HbgInfoCell, $HbgNumberCell, $HbgTitleCell, $HcomMissileNM, $HcurrentID, $HcurrentName, $HcurrentNumber, $HdefaultPassword, $helpDir, $HexchangeAutoMode, $HexchangeBidID, $HexchangeBuy, $HexchangeBuyCost, $HexchangeCon, $HexchangeData, $HexchangeDelID, $HexchangeDelTurns, $HexchangeFile, $HexchangeID, $HexchangeMerchantName, $HexchangeMerchantPercent, $HexchangeMode, $HexchangeName, $HexchangePenaltyAttack, $HexchangeRate, $HexchangeSell, $HexchangeSellCost, $HexchangeUnit, $HexchangeVars, $HidToNumber, $HinputPassword, $HislandList, $Hislands, $HislandSize, $HislandTurn, $HlandBase, $HlandSea, $HlogdirName, $HmaxExpPoint, $HpenaltyExchangeSwitch, $HtempBack, $HthisFile, $htmltmp, $HunitFood, $HunitMoney, $HunitOil, $HunitOre, $HunitWeapon, $imageDir, $lockMode, $toppage, $versionInfo;
	out(<<<END
${HtagBig_}지정의 거래에 응모했습니다.${H_tagBig}
END
);
}

// 거래 응모 각하
function tempExcBidLimit() {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $HbgInfoCell, $HbgNumberCell, $HbgTitleCell, $HcomMissileNM, $HcurrentID, $HcurrentName, $HcurrentNumber, $HdefaultPassword, $helpDir, $HexchangeAutoMode, $HexchangeBidID, $HexchangeBuy, $HexchangeBuyCost, $HexchangeCon, $HexchangeData, $HexchangeDelID, $HexchangeDelTurns, $HexchangeFile, $HexchangeID, $HexchangeMerchantName, $HexchangeMerchantPercent, $HexchangeMode, $HexchangeName, $HexchangePenaltyAttack, $HexchangeRate, $HexchangeSell, $HexchangeSellCost, $HexchangeUnit, $HexchangeVars, $HidToNumber, $HinputPassword, $HislandList, $Hislands, $HislandSize, $HislandTurn, $HlandBase, $HlandSea, $HlogdirName, $HmaxExpPoint, $HpenaltyExchangeSwitch, $HtempBack, $HthisFile, $htmltmp, $HunitFood, $HunitMoney, $HunitOil, $HunitOre, $HunitWeapon, $imageDir, $lockMode, $toppage, $versionInfo;
	out(<<<END
${HtagBig_}응모 수량이 모집 조건에 이르고 있지 않습니다.${H_tagBig}
END
);
}

// 거래 응모 경매 ?배
function tempExcBidLow() {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $HbgInfoCell, $HbgNumberCell, $HbgTitleCell, $HcomMissileNM, $HcurrentID, $HcurrentName, $HcurrentNumber, $HdefaultPassword, $helpDir, $HexchangeAutoMode, $HexchangeBidID, $HexchangeBuy, $HexchangeBuyCost, $HexchangeCon, $HexchangeData, $HexchangeDelID, $HexchangeDelTurns, $HexchangeFile, $HexchangeID, $HexchangeMerchantName, $HexchangeMerchantPercent, $HexchangeMode, $HexchangeName, $HexchangePenaltyAttack, $HexchangeRate, $HexchangeSell, $HexchangeSellCost, $HexchangeUnit, $HexchangeVars, $HidToNumber, $HinputPassword, $HislandList, $Hislands, $HislandSize, $HislandTurn, $HlandBase, $HlandSea, $HlogdirName, $HmaxExpPoint, $HpenaltyExchangeSwitch, $HtempBack, $HthisFile, $htmltmp, $HunitFood, $HunitMoney, $HunitOil, $HunitOre, $HunitWeapon, $imageDir, $lockMode, $toppage, $versionInfo;
	out(<<<END
${HtagBig_}다른섬이 더욱 좋은 조건으로 응모하고 있습니다.${H_tagBig}
END
);
}

// 거래 응모 ?패
function tempExcBidMiss() {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $HbgInfoCell, $HbgNumberCell, $HbgTitleCell, $HcomMissileNM, $HcurrentID, $HcurrentName, $HcurrentNumber, $HdefaultPassword, $helpDir, $HexchangeAutoMode, $HexchangeBidID, $HexchangeBuy, $HexchangeBuyCost, $HexchangeCon, $HexchangeData, $HexchangeDelID, $HexchangeDelTurns, $HexchangeFile, $HexchangeID, $HexchangeMerchantName, $HexchangeMerchantPercent, $HexchangeMode, $HexchangeName, $HexchangePenaltyAttack, $HexchangeRate, $HexchangeSell, $HexchangeSellCost, $HexchangeUnit, $HexchangeVars, $HidToNumber, $HinputPassword, $HislandList, $Hislands, $HislandSize, $HislandTurn, $HlandBase, $HlandSea, $HlogdirName, $HmaxExpPoint, $HpenaltyExchangeSwitch, $HtempBack, $HthisFile, $htmltmp, $HunitFood, $HunitMoney, $HunitOil, $HunitOre, $HunitWeapon, $imageDir, $lockMode, $toppage, $versionInfo;
	out(<<<END
${HtagBig_}이것은 자신의도에 의뢰한 거래입니다.${H_tagBig}
END
);
}

// 거래 삭제 ?공
function tempExcDelSuccess() {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $HbgInfoCell, $HbgNumberCell, $HbgTitleCell, $HcomMissileNM, $HcurrentID, $HcurrentName, $HcurrentNumber, $HdefaultPassword, $helpDir, $HexchangeAutoMode, $HexchangeBidID, $HexchangeBuy, $HexchangeBuyCost, $HexchangeCon, $HexchangeData, $HexchangeDelID, $HexchangeDelTurns, $HexchangeFile, $HexchangeID, $HexchangeMerchantName, $HexchangeMerchantPercent, $HexchangeMode, $HexchangeName, $HexchangePenaltyAttack, $HexchangeRate, $HexchangeSell, $HexchangeSellCost, $HexchangeUnit, $HexchangeVars, $HidToNumber, $HinputPassword, $HislandList, $Hislands, $HislandSize, $HislandTurn, $HlandBase, $HlandSea, $HlogdirName, $HmaxExpPoint, $HpenaltyExchangeSwitch, $HtempBack, $HthisFile, $htmltmp, $HunitFood, $HunitMoney, $HunitOil, $HunitOre, $HunitWeapon, $imageDir, $lockMode, $toppage, $versionInfo;
	out(<<<END
${HtagBig_}지정의 거래를 삭제했습니다.${H_tagBig}
END
);
}

// 거래 삭제 ?패
function tempExcDelMiss() {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $HbgInfoCell, $HbgNumberCell, $HbgTitleCell, $HcomMissileNM, $HcurrentID, $HcurrentName, $HcurrentNumber, $HdefaultPassword, $helpDir, $HexchangeAutoMode, $HexchangeBidID, $HexchangeBuy, $HexchangeBuyCost, $HexchangeCon, $HexchangeData, $HexchangeDelID, $HexchangeDelTurns, $HexchangeFile, $HexchangeID, $HexchangeMerchantName, $HexchangeMerchantPercent, $HexchangeMode, $HexchangeName, $HexchangePenaltyAttack, $HexchangeRate, $HexchangeSell, $HexchangeSellCost, $HexchangeUnit, $HexchangeVars, $HidToNumber, $HinputPassword, $HislandList, $Hislands, $HislandSize, $HislandTurn, $HlandBase, $HlandSea, $HlogdirName, $HmaxExpPoint, $HpenaltyExchangeSwitch, $HtempBack, $HthisFile, $htmltmp, $HunitFood, $HunitMoney, $HunitOil, $HunitOre, $HunitWeapon, $imageDir, $lockMode, $toppage, $versionInfo;
	out(<<<END
${HtagBig_}이것은 다른섬에 의뢰한 거래입니다.${H_tagBig}
END
);
}

function logExcDead1($id, $name, $no) {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $HbgInfoCell, $HbgNumberCell, $HbgTitleCell, $HcomMissileNM, $HcurrentID, $HcurrentName, $HcurrentNumber, $HdefaultPassword, $helpDir, $HexchangeAutoMode, $HexchangeBidID, $HexchangeBuy, $HexchangeBuyCost, $HexchangeCon, $HexchangeData, $HexchangeDelID, $HexchangeDelTurns, $HexchangeFile, $HexchangeID, $HexchangeMerchantName, $HexchangeMerchantPercent, $HexchangeMode, $HexchangeName, $HexchangePenaltyAttack, $HexchangeRate, $HexchangeSell, $HexchangeSellCost, $HexchangeUnit, $HexchangeVars, $HidToNumber, $HinputPassword, $HislandList, $Hislands, $HislandSize, $HislandTurn, $HlandBase, $HlandSea, $HlogdirName, $HmaxExpPoint, $HpenaltyExchangeSwitch, $HtempBack, $HthisFile, $htmltmp, $HunitFood, $HunitMoney, $HunitOil, $HunitOre, $HunitWeapon, $imageDir, $lockMode, $toppage, $versionInfo;
	logOut("거래 번호 ${no} 는 ${HtagName_}${name}도 ${H_tagName}이<B>무인도</B>가 되었기 때문에 무효가 되었습니다.",$id);
}

function logExcDead2($id, $name, $no) {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $HbgInfoCell, $HbgNumberCell, $HbgTitleCell, $HcomMissileNM, $HcurrentID, $HcurrentName, $HcurrentNumber, $HdefaultPassword, $helpDir, $HexchangeAutoMode, $HexchangeBidID, $HexchangeBuy, $HexchangeBuyCost, $HexchangeCon, $HexchangeData, $HexchangeDelID, $HexchangeDelTurns, $HexchangeFile, $HexchangeID, $HexchangeMerchantName, $HexchangeMerchantPercent, $HexchangeMode, $HexchangeName, $HexchangePenaltyAttack, $HexchangeRate, $HexchangeSell, $HexchangeSellCost, $HexchangeUnit, $HexchangeVars, $HidToNumber, $HinputPassword, $HislandList, $Hislands, $HislandSize, $HislandTurn, $HlandBase, $HlandSea, $HlogdirName, $HmaxExpPoint, $HpenaltyExchangeSwitch, $HtempBack, $HthisFile, $htmltmp, $HunitFood, $HunitMoney, $HunitOil, $HunitOre, $HunitWeapon, $imageDir, $lockMode, $toppage, $versionInfo;
	logOut("거래 번호 ${no} 는 ${HtagName_}${name}도 ${H_tagName} 가<B>무인도</B>가 되었기 때문에 모집이 계속 되었습니다.",$id);
}

// 규정 ?수경과
function logExcLimit($id, $no) {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $HbgInfoCell, $HbgNumberCell, $HbgTitleCell, $HcomMissileNM, $HcurrentID, $HcurrentName, $HcurrentNumber, $HdefaultPassword, $helpDir, $HexchangeAutoMode, $HexchangeBidID, $HexchangeBuy, $HexchangeBuyCost, $HexchangeCon, $HexchangeData, $HexchangeDelID, $HexchangeDelTurns, $HexchangeFile, $HexchangeID, $HexchangeMerchantName, $HexchangeMerchantPercent, $HexchangeMode, $HexchangeName, $HexchangePenaltyAttack, $HexchangeRate, $HexchangeSell, $HexchangeSellCost, $HexchangeUnit, $HexchangeVars, $HidToNumber, $HinputPassword, $HislandList, $Hislands, $HislandSize, $HislandTurn, $HlandBase, $HlandSea, $HlogdirName, $HmaxExpPoint, $HpenaltyExchangeSwitch, $HtempBack, $HthisFile, $htmltmp, $HunitFood, $HunitMoney, $HunitOil, $HunitOre, $HunitWeapon, $imageDir, $lockMode, $toppage, $versionInfo;
	logOut("거래 번호 ${no} 는 응모가 없었기 때문에 무효가 되었습니다.",$id);
}

// 거래 ?립
function logExcSuccess($id, $name, $bid, $bname, $no, $sell, $buy, $auto) {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $HbgInfoCell, $HbgNumberCell, $HbgTitleCell, $HcomMissileNM, $HcurrentID, $HcurrentName, $HcurrentNumber, $HdefaultPassword, $helpDir, $HexchangeAutoMode, $HexchangeBidID, $HexchangeBuy, $HexchangeBuyCost, $HexchangeCon, $HexchangeData, $HexchangeDelID, $HexchangeDelTurns, $HexchangeFile, $HexchangeID, $HexchangeMerchantName, $HexchangeMerchantPercent, $HexchangeMode, $HexchangeName, $HexchangePenaltyAttack, $HexchangeRate, $HexchangeSell, $HexchangeSellCost, $HexchangeUnit, $HexchangeVars, $HidToNumber, $HinputPassword, $HislandList, $Hislands, $HislandSize, $HislandTurn, $HlandBase, $HlandSea, $HlogdirName, $HmaxExpPoint, $HpenaltyExchangeSwitch, $HtempBack, $HthisFile, $htmltmp, $HunitFood, $HunitMoney, $HunitOil, $HunitOre, $HunitWeapon, $imageDir, $lockMode, $toppage, $versionInfo;
	$auto = ($auto ? '(자동 거래)' : '(수동 거래)');
	logOut("거래 번호 ${no} 는 ${HtagName_}${name}${H_tagName} 가<B>${sell}</B>,${HtagName_}${bname}${H_tagName} 가<B>${buy}</B>를 교환하는 것으로 성립했습니다.<B>${auto}</B>",$id, $bid);
}

// ?널??발생
function logExcPenalty($id, $bid, $bname, $no, $buy, $penalty) {
extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $HbgInfoCell, $HbgNumberCell, $HbgTitleCell, $HcomMissileNM, $HcurrentID, $HcurrentName, $HcurrentNumber, $HdefaultPassword, $helpDir, $HexchangeAutoMode, $HexchangeBidID, $HexchangeBuy, $HexchangeBuyCost, $HexchangeCon, $HexchangeData, $HexchangeDelID, $HexchangeDelTurns, $HexchangeFile, $HexchangeID, $HexchangeMerchantName, $HexchangeMerchantPercent, $HexchangeMode, $HexchangeName, $HexchangePenaltyAttack, $HexchangeRate, $HexchangeSell, $HexchangeSellCost, $HexchangeUnit, $HexchangeVars, $HidToNumber, $HinputPassword, $HislandList, $Hislands, $HislandSize, $HislandTurn, $HlandBase, $HlandSea, $HlogdirName, $HmaxExpPoint, $HpenaltyExchangeSwitch, $HtempBack, $HthisFile, $htmltmp, $HunitFood, $HunitMoney, $HunitOil, $HunitOre, $HunitWeapon, $imageDir, $lockMode, $toppage, $versionInfo;
	if($HpenaltyExchangeSwitch){
		logOut("거래 번호 ${no} 는${HtagName_}${bname}${H_tagName}에<B>${buy}</B>의 비축이 없는 것이 판명! 모형정원 자원 거래 위원회에서는<B>제재 발동($penalty)</B>을 결정했습니다.",$id, $bid);
	}else{
		logOut("거래 번호 ${no} 는${HtagName_}${bname}${H_tagName}에<B>${buy}</B>의 비축이 없는 것이 판명! 거래는 행해지지 않았습니다.",$id, $bid);
	}
}


1;
