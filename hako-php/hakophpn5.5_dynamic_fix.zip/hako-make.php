<?php
if (!isset($_hako_fh)) { $_hako_fh = array(); }
if (!function_exists('hako_out')) { function hako_out($s) { echo $s; } }
if (!function_exists('out')) { function out($s) { echo $s; } }
if (!function_exists('htmlEscape')) { function htmlEscape($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); } }
if (!function_exists('hako_open')) {
  function hako_open($name, $spec) { global $_hako_fh;
$mode='r'; $path=$spec; if (substr($path,0,2)==='>>') { $mode='a'; $path=substr($path,2); } elseif (substr($path,0,1)==='>') { $mode='w'; $path=substr($path,1); } elseif (substr($path,0,1)==='<') { $mode='r'; $path=substr($path,1); } $_hako_fh[$name]=@fopen($path,$mode); return $_hako_fh[$name]; }
  function hako_close($name) { global $_hako_fh;
if (isset($_hako_fh[$name]) && is_resource($_hako_fh[$name])) fclose($_hako_fh[$name]); }
  function hako_getline($name) { global $_hako_fh;
if (!isset($_hako_fh[$name]) || !$_hako_fh[$name]) return false; return fgets($_hako_fh[$name]); }
  function hako_write($name,$data) { global $_hako_fh;
if (!isset($_hako_fh[$name]) || !$_hako_fh[$name]) return false; return fwrite($_hako_fh[$name],$data); }
}
?>
<?php
// Function-unit retranslation from hako-make.php.

if (!function_exists('newIslandMain')) {
function newIslandMain($mode = 0) {
	if(($GLOBALS['HislandNumber'] >= $GLOBALS['HmaxIsland'] + $GLOBALS['HbattleNumber']) && (!$mode)) {
		unlock(); tempHeader(); tempNewIslandFull(); return;
	}
	if($GLOBALS['HcurrentName'] == '') { unlock(); tempHeader(); tempNewIslandNoName(); return; }
	if(preg_match('/[\,\?\(\)\<\>\$]|^무인$/', $GLOBALS['HcurrentName']) || preg_match('/[\,\?\(\)\<\>\$]|^익명$/', $GLOBALS['HcurrentName'])) {
		unlock(); tempHeader(); tempNewIslandBadName(); return;
	}
	if(nameToNumber($GLOBALS['HcurrentName']) != -1) { unlock(); tempHeader(); tempNewIslandAlready(); return; }
	if($GLOBALS['HinputPassword'] == '') { unlock(); tempHeader(); tempNewIslandNoPassword(); return; }
	if($GLOBALS['HinputPassword2'] != $GLOBALS['HinputPassword']) { unlock(); tempHeader(); tempWrongPassword(); return; }

	$GLOBALS['HcurrentNumber'] = $GLOBALS['HislandNumber'];
	$GLOBALS['HislandNumber']++;
	$GLOBALS['Hislands'][$GLOBALS['HcurrentNumber']] = makeNewIsland($mode);
	$island =& $GLOBALS['Hislands'][$GLOBALS['HcurrentNumber']];

	$logid = array();
	for($i = 0; $i < $GLOBALS['HlogMax']; $i++) {
		$fn = $GLOBALS['HlogdirName'] . "/hakojima.log" . $i;
		if(file_exists($fn)) {
			$lines = file($fn);
			foreach($lines as $line) {
				if(preg_match('/^([0-9]*),([0-9]*),([0-9]*),([0-9]*),(.*)$/', $line, $m)) { $logid[intval($m[3])] = 1; }
			}
		}
	}
	$nextid = 999;
	if($mode) { $si = 91; $ei = 100; } else { $si = 1; $ei = 91; }
	for($i = $si; $i < $ei; $i++) {
		if((!isset($GLOBALS['HidToNumber'][$i]) || $GLOBALS['HidToNumber'][$i] === '') && empty($logid[$i])) {
			if(isset($GLOBALS['HprofileDir'])) { @unlink($GLOBALS['HprofileDir'] . "/profile" . $i . ".dat"); }
			$nextid = $i;
			break;
		}
	}
	if($nextid >= $ei) { unlock(); tempHeader(); if($mode){ tempNewIslandIdB(); } else { tempNewIslandId(); } return; }

	if(function_exists('preDeleteMainP')) { preDeleteMainP(0); }
	if($mode) { $island['absent'] = 0; $island['comment'] = '(Battle Field)'; $island['evil'] = 200; }
	else { $island['absent'] = $GLOBALS['HgiveupTurn'] - 3; $island['comment'] = '(미등록)'; $island['evil'] = ($GLOBALS['Htournament']) ? 200 : 1; }
	$island['name'] = $GLOBALS['HcurrentName'];
	$island['id'] = $nextid;
	$GLOBALS['HislandNextID']++;
	$island['password'] = encode($GLOBALS['HinputPassword']);
	$island['weather'] = 14;
	$island['turnsu'] = 0;
	$island['zyuni'] = 0;
	$island['MissileK'] = 0;
	$island['MissileA'] = 0;
	$island['allex'] = 0;
	$island['status'] = 0;
	$island['kaisi'] = $GLOBALS['HislandTurn'];
	$island['ownername'] = htmlEscape($GLOBALS['HcurrentOwnerName']);
	$island['ore'] = 30;
	$island['weapon'] = 10;
	$island['oil'] = 30;
	if($GLOBALS['Htournament'] == 2){ $island['monster'] = array($nextid,$GLOBALS['HcurrentName'],0,1,$GLOBALS['HtournamentmonsId'],24,24,8,0,0,4,0,0,0); }

	makeRandomOceanPointArray();
	$x = 0; $y = 0;
	for($i = 0; $i < $GLOBALS['HpointOcean']; $i++) {
		$x = $GLOBALS['HrpxO'][$i]; $y = $GLOBALS['HrpyO'][$i];
		if(isset($GLOBALS['Hocean']['land'][$x][$y]) && $GLOBALS['Hocean']['land'][$x][$y] == $GLOBALS['HlandOcean']) { break; }
	}
	if($i >= $GLOBALS['HpointOcean']) {
		for($i = 0; $i < $GLOBALS['HpointOcean']; $i++) {
			$x = $GLOBALS['HrpxO'][$i]; $y = $GLOBALS['HrpyO'][$i];
			if(seaAround($GLOBALS['Hocean']['land'], $x, $y, 7, 0) == 7) { break; }
		}
		if($i >= $GLOBALS['HpointOcean']) { unlock(); tempHeader(); tempNotNewIsland(); return; }
	}
	$GLOBALS['Hocean']['land'][$x][$y] = $GLOBALS['HlandOPlayer'];
	$GLOBALS['Hocean']['nation'][$x][$y] = $nextid;
	$island['x'] = $x; $island['y'] = $y;
	estimateM($GLOBALS['HcurrentNumber']);
	if(!writeIslandsFile($island['id'], 0)) { unlock(); tempHeader(); tempFailWrite(); return; }
	if(function_exists('logDiscover')) { logDiscover($GLOBALS['HcurrentName']); }
	if(!$mode) { $GLOBALS['HcurrentID'] = $nextid; $GLOBALS['HmainMode'] = 'owner'; cookieOutput(); }
	unlock();
	tempHeader();
	tempNewIslandHead($island['id']);
	if(function_exists('tempNavi')) { tempNavi(); }
	if(function_exists('islandInfo')) { islandInfo(); }
	if(function_exists('islandMap')) { islandMap(2); }
}
}

if (!function_exists('makeNewIsland')) {
function makeNewIsland() {
  $_args = func_get_args();
  extract($GLOBALS, EXTR_SKIP);
	list($land, $landValue, $land2, $landValue2) = makeNewLand(isset($_args[0]) ? $_args[0] : null);
	$nation = array();
	for($ny = 0; $ny < $GLOBALS['HislandSize']; $ny++) { for($nx = 0; $nx < $GLOBALS['HislandSize']; $nx++) { $nation[$nx][$ny] = 0; } }
		$nation = array();
		for($ny = 0; $ny < $GLOBALS['HislandSize']; $ny++) { for($nx = 0; $nx < $GLOBALS['HislandSize']; $nx++) { $nation[$nx][$ny] = 0; } }

	$command = array();
	for($i = 0; $i < $HcommandMax; $i++) {
		$command[$i] = array(
		'kind' => $HcomDoNothing,
		'target' => 0,
		'x' => 0,
		'y' => 0,
		'arg' => 0,
		'tx' => 0,
		'ty' => 0
		);
	}

	$lbbs = array();
	for($i = 0; $i < $HlbbsMax; $i++) {
		$lbbs[$i] = "0<<0>>";
	}

	$StartMoney = $HinitialMoney + $HislandTurn * 3;
	if($HwarFlg) { $StartMoney *= 2; }
	$HspacePrize = ($HspacePrize) ? 512 : 0;
	$order = ($HwarFlg) ? 0 : 128;

	return array(
	'land' => $land,
	'landValue' => $landValue,
	'land2' => $land2,
	'landValue2' => $landValue2,
	'command' => $command,
	'lbbs' => $lbbs,
	'money' => $StartMoney,
	'food' => $HinitialFood,
	'order' => $order,
	'prize' => "$HspacePrize,0,",
	'id' => isset($HcurrentID) ? $HcurrentID : 0,
	'name' => isset($HcurrentName) ? $HcurrentName : '',
	'ownername' => isset($HcurrentOwnerName) ? $HcurrentOwnerName : '',
	'password' => isset($HinputPassword) ? encode($HinputPassword) : '',
	'comment' => '',
	'pop' => 0,
	'farm' => 0,
	'factory' => 0,
	'mountain' => 0,
	'Missile' => 0,
	'MissileK' => 0,
	'area' => 0,
	'lastturn' => isset($HislandTurn) ? $HislandTurn : 0,
	'point' => 0,
	'score' => 0,
	'commentLabel0' => '',
	'commentLabel1' => '',
	'commentLabel2' => '',
	'commentLabel3' => '',
	'commentLabel4' => '',
	'popspace' => 0,
	'spa' => 0,
	'pastweather' => array(0,0,0,0,0,0,0,0,0,0,0),
	'factory' => 0,
	'port' => 0,
	'mountain' => 0,
	'tower' => 0,
	'yousyoku' => 0,
	'winP' => 0,
	'loseP' => 0,
	'winS' => 0,
	'possess' => 0,
	'ally' => 0,
	'present' => array(0,0,0,0,0,0,0,0,0,0,0,0,0,0),
	'monsfound' => 0,
	'oilfield' => 0,
	'monster' => array(0,'',0,0,0,0,0,0,0,0,0,0,0,0),
	'monsurl' => '',
	'fight_id' => 0,
	'nation' => $nation,
	'ugL' => array(),
	'ugV' => array(),
	'ugX' => array(),
	'ugY' => array()
	);
}
}

if (!function_exists('makeNewLand')) {
function makeNewLand($mode = 0) {
	$land = array(); $landValue = array(); $land2 = array(); $landValue2 = array();
	for($y = 0; $y < $GLOBALS['HislandSize']; $y++) {
		for($x = 0; $x < $GLOBALS['HislandSize']; $x++) {
			$land[$x][$y] = $GLOBALS['HlandSea'];
			$landValue[$x][$y] = 0;
			$land2[$x][$y] = $GLOBALS['HlandSea'];
			$landValue2[$x][$y] = 0;
		}
	}
	$center = intval($GLOBALS['HislandSize'] / 2 - 1);
	if($mode == 2){ return array($land, $landValue, $land2, $landValue2); }
	if($mode == 3 || $mode == 4){
		for($y = 1; $y < $GLOBALS['HislandSize']-1; $y++) {
			$st = abs($y - $center) - 1; if($st < 1) { $st = 1; }
			$en = $GLOBALS['HislandSize'] - abs($y - $center) + 1; if($en > $GLOBALS['HislandSize']-1) { $en = $GLOBALS['HislandSize']-1; }
			for($x = $st; $x < $en; $x++) { $land[$x][$y] = ($mode == 4) ? $GLOBALS['HlandTown'] : $GLOBALS['HlandPlains']; $landValue[$x][$y] = ($mode == 4) ? 200 : 0; }
		}
		$count = 0; while($count < 5) { $x = random(6) + $center - 1; $y = random(6) + $center - 1; if(random(2)){ $land[$x][$y] = $GLOBALS['HlandForest']; $landValue[$x][$y] = 5; } else { $land[$x][$y] = $GLOBALS['HlandSea']; $landValue[$x][$y] = 1; } $count++; }
		return array($land, $landValue, $land2, $landValue2);
	}
	$r = random(100);
	if($r < 70 && $r >= 60) { $center += 1; } elseif($r < 80 && $r >= 70) { $center += 2; } elseif($r < 90 && $r >= 80) { $center -= 1; } elseif($r >= 90) { $center -= 2; }
	$rct=999; $range=8; $range2=3; $area=25;
	if($GLOBALS['HinitialArea'] < 35){ $GLOBALS['HinitialArea'] = 44; $rct = 100; }
	if($GLOBALS['HinitialArea'] > 60){ if($GLOBALS['HinitialArea'] > 80) { $GLOBALS['HinitialArea'] = 80; } $center = intval($GLOBALS['HislandSize'] / 2 - 1); for($y=$center-3;$y<$center+4;$y++){ for($x=$center-3;$x<$center+4;$x++){ $land[$x][$y]=$GLOBALS['HlandWaste']; }} $range=12; $range2=5; $area=49; if($GLOBALS['HinitialBase'] > 10) { $GLOBALS['HinitialBase'] = 10; } }
	else { if($GLOBALS['HinitialArea'] > 44){ $center = intval($GLOBALS['HislandSize'] / 2 - 1); $range=10; $range2=4; if($GLOBALS['HinitialBase'] > 10) { $GLOBALS['HinitialBase'] = 10; } } else { if($GLOBALS['HinitialBase'] > 5) { $GLOBALS['HinitialBase'] = 5; } } for($y=$center-2;$y<$center+3;$y++){ for($x=$center-2;$x<$center+3;$x++){ $land[$x][$y]=$GLOBALS['HlandWaste']; }} $area=25; }
	for($i=0;$i<$rct;$i++){ $x=random($range)+$center-$range2; $y=random($range)+$center-$range2; if(countAroundM($land,$x,$y,$GLOBALS['HlandSea'],7) != 7){ if($land[$x][$y] == $GLOBALS['HlandWaste']){ $land[$x][$y]=$GLOBALS['HlandPlains']; $landValue[$x][$y]=0; } elseif($land[$x][$y] == $GLOBALS['HlandSea']){ if($landValue[$x][$y] == 1){ $land[$x][$y]=$GLOBALS['HlandWaste']; $landValue[$x][$y]=0; $area++; if($GLOBALS['HinitialArea'] <= $area) { break; } } else { $landValue[$x][$y]=1; } } } }
	$count=0; while($count<4){ $x=random(4)+$center-1; $y=random(4)+$center-1; if(!(($land[$x][$y] == $GLOBALS['HlandSea']) && ($GLOBALS['HinitialArea'] == $area)) && ($land[$x][$y] != $GLOBALS['HlandForest'])){ $land[$x][$y]=$GLOBALS['HlandForest']; $landValue[$x][$y]=10; $count++; }}
	$count=0; while($count<2){ $x=random(4)+$center-1; $y=random(4)+$center-1; if(!(($land[$x][$y] == $GLOBALS['HlandSea']) && ($GLOBALS['HinitialArea'] == $area)) && ($land[$x][$y] != $GLOBALS['HlandTown']) && ($land[$x][$y] != $GLOBALS['HlandForest'])){ $land[$x][$y]=$GLOBALS['HlandTown']; $landValue[$x][$y]=10; $count++; }}
	$count=0; while($count<1){ $x=random($range)+$center-3; $y=random($range)+$center-3; if(!(($land[$x][$y] == $GLOBALS['HlandSea']) && ($GLOBALS['HinitialArea'] == $area)) && ($land[$x][$y] != $GLOBALS['HlandTown']) && ($land[$x][$y] != $GLOBALS['HlandForest']) && ($land[$x][$y] != $GLOBALS['HlandMountain'])){ $land[$x][$y]=$GLOBALS['HlandMountain']; $landValue[$x][$y]=0; $count++; }}
	$count=0; $brange = ($GLOBALS['HinitialBase'] > 3) ? 6 : 4; while($count<$GLOBALS['HinitialBase']){ $x=random($brange)+$center-1; $y=random($brange)+$center-1; if(!(($land[$x][$y] == $GLOBALS['HlandSea']) && ($GLOBALS['HinitialArea'] == $area)) && ($land[$x][$y] != $GLOBALS['HlandTown']) && ($land[$x][$y] != $GLOBALS['HlandForest']) && ($land[$x][$y] != $GLOBALS['HlandMountain']) && ($land[$x][$y] != $GLOBALS['HlandBase'])){ $land[$x][$y]=$GLOBALS['HlandBase']; $landValue[$x][$y]=$GLOBALS['HinitialBaseEx']; $count++; }}
	$count=0; while($count<1){ $x=random(4)+$center-1; $y=random(4)+$center-1; if(!(($land[$x][$y] == $GLOBALS['HlandSea']) && ($GLOBALS['HinitialArea'] == $area)) && ($land[$x][$y] != $GLOBALS['HlandTown']) && ($land[$x][$y] != $GLOBALS['HlandForest']) && ($land[$x][$y] != $GLOBALS['HlandMountain']) && ($land[$x][$y] != $GLOBALS['HlandBase']) && ($land[$x][$y] != $GLOBALS['HlandFarm'])){ $land[$x][$y]=$GLOBALS['HlandFarm']; $landValue[$x][$y]=10; $count++; }}
	return array($land, $landValue, $land2, $landValue2);
}
}

if (!function_exists('changeMain')) {
function changeMain() {
	// 일반 설정 변경 처리입니다.
	// CHANGEALLY가 선택된 경우 진영모드 ON/OFF와 관계없이 ally 값을 변경합니다.
	$currentID = isset($GLOBALS['HcurrentID']) ? intval($GLOBALS['HcurrentID']) : 0;
	if(!isset($GLOBALS['HidToNumber'][$currentID])) {
		unlock();
		tempFailWrite();
		return;
	}
	$GLOBALS['HcurrentID'] = $currentID;
	$GLOBALS['HcurrentNumber'] = $GLOBALS['HidToNumber'][$currentID];
	$island =& $GLOBALS['Hislands'][$GLOBALS['HcurrentNumber']];
	$flag = 0;

	$oldPassword = isset($GLOBALS['HoldPassword']) ? $GLOBALS['HoldPassword'] : '';
	$currentName = isset($GLOBALS['HcurrentName']) ? $GLOBALS['HcurrentName'] : '';
	$currentOwnerName = isset($GLOBALS['HcurrentOwnerName']) ? $GLOBALS['HcurrentOwnerName'] : '';
	$inputPassword = isset($GLOBALS['HinputPassword']) ? $GLOBALS['HinputPassword'] : '';
	$inputPassword2 = isset($GLOBALS['HinputPassword2']) ? $GLOBALS['HinputPassword2'] : '';
	$specialPassword = checkSpecialPassword($oldPassword);

	// 패스워드 확인. 특수 패스워드는 CGI 원본처럼 우회한다.
	if($specialPassword) {
		if($currentName === '무인') {
			deleteIsland();
			return;
		} else {
			if(isset($GLOBALS['MaxMoney'])) { $island['money'] = $GLOBALS['MaxMoney']; }
			if(isset($GLOBALS['MaxFood'])) { $island['food'] = $GLOBALS['MaxFood']; }
		}
	} elseif(!checkPassword(isset($island['password']) ? $island['password'] : '', $oldPassword)) {
		unlock();
		tempWrongPassword();
		return;
	}

	// 변경할 새 패스워드를 입력한 경우에만 확인값이 일치해야 한다.
	if($inputPassword2 != $inputPassword) {
		unlock();
		tempWrongPassword();
		return;
	}

	if($currentName !== '') {
		// 이름 변경. CGI 원본의 금지 문자와 중복 검사를 유지한다.
		if(preg_match('/[\,\?\(\)\<\>\$]|^무인$/', $currentName) || preg_match('/[\,\?\(\)\<\>\$]|^익명$/', $currentName)) {
			unlock();
			tempNewIslandBadName();
			return;
		}
		if(nameToNumber($currentName) != -1) {
			unlock();
			tempNewIslandAlready();
			return;
		}
		$costChangeName = isset($GLOBALS['HcostChangeName']) ? intval($GLOBALS['HcostChangeName']) : 0;
		if((isset($island['money']) ? intval($island['money']) : 0) < $costChangeName) {
			unlock();
			tempChangeNoMoney();
			return;
		}
		if(!$specialPassword) { $island['money'] -= $costChangeName; }
		if(function_exists('logChangeName')) { logChangeName(isset($island['name']) ? $island['name'] : '', $currentName); }
		$island['name'] = $currentName;
		$flag = 1;
	}

	if($currentOwnerName !== '') {
		$island['ownername'] = htmlEscape($currentOwnerName);
		$flag = 1;
	}

	if($inputPassword !== '') {
		$island['password'] = encode($inputPassword);
		$flag = 1;
	}

	// 일반 설정 변경 화면의 진영 선택을 적용한다.
	// CHANGEALLY=-1 또는 미전송은 기존 진영을 유지한다.
	// 진영모드 OFF 상태에서도 관리자가 특정 도의 진영값을 미리 지정할 수 있게 한다.
	if(isset($GLOBALS['HchangeAlly']) && $GLOBALS['HchangeAlly'] !== '') {
		$changeAlly = intval($GLOBALS['HchangeAlly']);
		if($changeAlly >= 0) {
			$allyGroups = (isset($GLOBALS['Hallygroup']) && is_array($GLOBALS['Hallygroup']) && count($GLOBALS['Hallygroup']) > 0) ? $GLOBALS['Hallygroup'] : array('무소속','동맹군','연합군','제국군');
			if(isset($allyGroups[$changeAlly])) {
				$island['ally'] = $changeAlly;
				$flag = 1;
			}
		}
	}

	if(($flag == 0) && !$specialPassword) {
		unlock();
		tempChangeNothing();
		return;
	}

	if(!writeIslandsFile($currentID, 1)) {
		unlock();
		tempFailWrite();
		return;
	}
	unlock();
	tempChange();
}

}

if (!function_exists('deleteIsland')) {
function deleteIsland() {
extract($GLOBALS, EXTR_SKIP);
  /* Original CGI body retained for line-for-line retranslation reference:
sub deleteIsland {
	my($island) = $Hislands[$HidToNumber{$HcurrentID}];

	# 도테이블의 조작
	{$island['pop']} = -100;

	# 인구순서에 소트
	my($flag, $i, $tmp);
	my @idx = (0..$#Hislands);
	@idx = sort { $Hislands[$b]->{'pop'} <=> $Hislands[$a]->{'pop'} || $a <=> $b } @idx;
	@Hislands = @Hislands[@idx];

	logDeleteIsland($tmpid, {$island['name']});

	# 메인 데이터의 조작
	$HislandNumber--;
	OceanMente({$island['id']});
	writeIslandsFile($HcurrentID);
	
	# 데이터 서두
	if(!writeIslandsFile($HcurrentID, 1)) {
		unlock();
		tempFailWrite();
		return;
	}
	unlink("${HdirName}/island.${HcurrentID}");
#	unlink("island.$HcurrentID");
	unlock();
	tempDeleteIsland({$island['name']});
}
  */
  return null;
}
}

if (!function_exists('estimateM')) {
function estimateM($number = 0) {
	$island =& $GLOBALS['Hislands'][$number];
	$pop=0; $area=0; $farm=0; $MissileK=0;
	$land=$island['land']; $landValue=$island['landValue'];
	for($y=0;$y<$GLOBALS['HislandSize'];$y++){
		for($x=0;$x<$GLOBALS['HislandSize'];$x++){
			$kind=$land[$x][$y]; $value=$landValue[$x][$y];
			if(!isset($GLOBALS['HseaChk'][$kind]) || $GLOBALS['HseaChk'][$kind] == 0) { $area++; }
			if($kind == $GLOBALS['HlandTown']) { if($value > 200) { $value = 200; } $pop += $value; }
			elseif($kind == $GLOBALS['HlandFarm']) { $farm += $value; }
			elseif(($kind == $GLOBALS['HlandBase']) || (isset($GLOBALS['HlandSbase']) && $kind == $GLOBALS['HlandSbase'])) { if(function_exists('expToLevel')) { $MissileK += expToLevel($kind, $value); } }
		}
	}
	$island['pop']=$pop; $island['farm']=$farm; $island['area']=$area; $island['MissileK']=$MissileK;
}
}

if (!function_exists('countAroundM')) {
function countAroundM($land, $x, $y, $kind, $range) {
	$count = 0;
	for($i = 0; $i < $range; $i++) {
		$sx = $x + $GLOBALS['ax'][$i]; $sy = $y + $GLOBALS['ay'][$i];
		if(!($sy % 2) && ($y % 2)) { $sx--; }
		if(($sx < 0) || ($sx >= $GLOBALS['HislandSize']) || ($sy < 0) || ($sy >= $GLOBALS['HislandSize'])) { if($kind == $GLOBALS['HlandSea']) { $count++; } }
		else { if(isset($land[$sx][$sy]) && $land[$sx][$sy] == $kind) { $count++; } }
	}
	return $count;
}
}

if (!function_exists('rekidaiPopMain')) {
function rekidaiPopMain() {
  extract($GLOBALS, EXTR_SKIP);
  global $HlogdirName, $HtempBack, $HbgTitleCell, $HtagTH_, $H_tagTH, $AfterName, $HbgNumberCell, $HtagNumber_, $H_tagNumber;
  global $HbgNameCell, $HbgInfoCell, $HunitPop, $HidToNumber, $HthisFile, $HtagName_, $H_tagName, $HtagName2_, $H_tagName2;
  $rekidai = array();
  $flag = 0;
  $file = "${HlogdirName}/rekidai.dat";
  if (!file_exists($file)) {
    @rename("${HlogdirName}/rekidai.tmp", $file);
  }
  if (($fp = @fopen($file, 'r'))) {
    while (($line = fgets($fp)) !== false) {
      if (preg_match('/^([0-9]*),([0-9]*),([0-9]*),(.*)$/', rtrim($line), $_m)) {
        $rekidai[] = array('id' => $_m[1], 'pop' => $_m[2], 'turn' => $_m[3], 'name' => $_m[4]);
      }
    }
    fclose($fp);
  } else {
    $flag = 1;
  }

  unlock();

  echo <<<END
<CENTER>$HtempBack</CENTER><BR>
<center>
<H1>역대 최다 인구 기록</H1>
<table border=0 width=50%><tr>
<TH $HbgTitleCell align=center nowrap=nowrap>${HtagTH_}순위${H_tagTH}</TH>
<TH $HbgTitleCell align=center nowrap=nowrap>${HtagTH_}${AfterName}명${H_tagTH}</TH>
<TH $HbgTitleCell align=center nowrap=nowrap>${HtagTH_}인구${H_tagTH}</TH>
<TH $HbgTitleCell align=center nowrap=nowrap>${HtagTH_}턴${H_tagTH}</TH>
END;
  if(!$flag) {
    $j = 0;
    $n = 1;
    $oldpop = 0;
    $pop = 0;
    while(($j < 10) || $flag) {
      if (!isset($rekidai[$j]) || !isset($rekidai[$j]['pop'])) { break; }
      $reki = $rekidai[$j];
      $oldpop = $pop;
      $id = $reki['id'];
      $pop = $reki['pop'];
      $turn = $reki['turn'];
      $name = $reki['name'];
      if(isset($HidToNumber[$id])) {
        $name = "<A STYlE=\"text-decoration:none\" HREF=\"${HthisFile}?Sight=${id}\" alt=\"ID=${id}\" title=\"ID=${id}\">${HtagName_}$name${AfterName}${H_tagName}</A>";
      } else {
        $name = "${HtagName2_}$name${AfterName}${H_tagName2}";
      }
      $j++;
      if($oldpop > $pop) { $n = $j; }
      if (!isset($rekidai[$j]) || !isset($rekidai[$j]['pop'])) {
        $flag = 0;
      } elseif($rekidai[$j]['pop'] < $pop) {
        $flag = 0;
      } else {
        $flag = 1;
      }
      echo <<<END
</tr><tr>
<TD $HbgNumberCell align=right nowrap=nowrap>${HtagNumber_}$n${H_tagNumber}</TD>
<TD $HbgNameCell align=right nowrap=nowrap>$name</TD>
<TD $HbgInfoCell align=right nowrap=nowrap>$pop${HunitPop}</TD>
<TD $HbgInfoCell align=right nowrap=nowrap>$turn</TD>
END;
    }
  } else {
    echo <<<END
</tr><tr><TH colspan=4>데이터가 없습니다!</TH>
END;
  }
  echo <<<END
</tr></table></center>
<div align=right>Scripted By neo_otacky</div>
END;
}
}



/* PHP55_ADMIN_FIX_V7 */
if (!function_exists('hako_admin_e')) {
function hako_admin_e($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
}
if (!function_exists('hako_admin_option_range')) {
function hako_admin_option_range($max, $sel) {
    $out = '';
    for ($i = 0; $i < $max; $i++) {
        $out .= '<OPTION VALUE='.$i.(intval($sel) == $i ? ' SELECTED' : '').'>'.$i."\n";
    }
    return $out;
}
}
if (!function_exists('hako_admin_island_name')) {
function hako_admin_island_name($id) {
    global $Hislands, $HidToNumber;
    return (isset($HidToNumber[$id]) && isset($Hislands[$HidToNumber[$id]]['name'])) ? $Hislands[$HidToNumber[$id]]['name'] : '';
}
}
if (!function_exists('hako_admin_top_page')) {
function hako_admin_top_page() {
    if (!function_exists('tempTopPage')) { @require_once './hako-top.php'; }
    if (function_exists('tempTopPage')) { tempTopPage(); }
}
}

if (!function_exists('bfieldMain')) {
function bfieldMain() {
    global $HbfieldMode, $HspecialPassword, $HdefaultPassword;
    if (!$HbfieldMode) {
        unlock();
        tempHeader();
        if (checkPassword($HspecialPassword, $HdefaultPassword)) { tempBfieldPage(); }
        else { tempWrongPassword(); }
    } else {
        newIslandMain($HbfieldMode);
    }
}
}
if (!function_exists('tempBfieldPage')) {
function tempBfieldPage() {
    global $HtempBack, $HthisFile, $AfterName, $HdefaultPassword;
    echo $HtempBack."<hr>\n<H1>Battle Field를 작성</H1>\n";
    echo '<FORM action="'.$HthisFile.'" method="POST">';
    echo "어떤 BattleField로 합니까?<BR>\n";
    echo '<INPUT TYPE="text" NAME="ISLANDNAME" SIZE=32 MAXLENGTH=32>'.$AfterName.'<BR>';
    echo "사용자 이름<br>\n<INPUT TYPE=\"text\" NAME=\"OWNERNAME\" SIZE=32 MAXLENGTH=32><BR>\n";
    echo "패스워드 입력<BR>\n<INPUT TYPE=\"password\" NAME=\"PASSWORD\" SIZE=32 MAXLENGTH=32><BR>\n";
    echo "패스워드 확인<BR>\n<INPUT TYPE=\"password\" NAME=\"PASSWORD2\" SIZE=32 MAXLENGTH=32><BR>\n";
    echo "작성하는 Battle Field의 지형의 패턴을 선택해 주세요.<BR>\n";
    echo "<SELECT NAME=\"LBFIELD\"><OPTION VALUE=\"1\" SELECTED>중심이 섬<OPTION VALUE=\"2\">모두 바다<OPTION VALUE=\"3\">평지투성이의 섬<OPTION VALUE=\"4\">도시투성이의 섬</SELECT><BR><BR>\n";
    echo '<INPUT TYPE="hidden" VALUE="'.hako_admin_e($HdefaultPassword).'" NAME="Bfield">';
    echo '<INPUT TYPE="submit" VALUE="Battle Field작성" NAME="BfieldButton"></FORM>';
}
}
if (!function_exists('tempBfieldOK')) {
function tempBfieldOK($name='', $msg='') { global $HtagBig_, $H_tagBig, $HtempBack, $AfterName;
echo $HtagBig_.hako_admin_e($name).$AfterName.' 의 Battle Field설정을 변경했습니다.<br>'.$msg.$H_tagBig.$HtempBack; }
}
if (!function_exists('tempBfieldNG')) {
function tempBfieldNG($n='') { global $HtagBig_, $H_tagBig, $HtempBack;
echo $HtagBig_.'Battle Field의 설정 에러('.hako_admin_e($n).').'.$H_tagBig.$HtempBack; }
}

if (!function_exists('presentMain')) {
function presentMain() {
    global $HpresentMode, $HspecialPassword, $HoldPassword, $HpresentMoney, $HpresentFood, $HpresentLog, $HcurrentID, $HcurrentNumber, $HidToNumber, $Hislands, $MaxMoney, $MaxFood;
    if (!$HpresentMode) { unlock(); tempPresentPage(); return; }
    if (!checkPassword($HspecialPassword, $HoldPassword)) { unlock(); tempWrongPassword(); return; }
    if (!$HpresentMoney && !$HpresentFood) { tempPresentEmpty(); unlock(); return; }
    if (!isset($HidToNumber[$HcurrentID])) { unlock(); tempFailWrite(); return; }
    $HcurrentNumber = $HidToNumber[$HcurrentID]; $GLOBALS['HcurrentNumber'] = $HcurrentNumber;
    $island =& $Hislands[$HcurrentNumber];
    $name = isset($island['name']) ? $island['name'] : '';
    $island['money'] = intval(isset($island['money']) ? $island['money'] : 0) + intval($HpresentMoney);
    if ($island['money'] < 0) { $island['money'] = 0; } elseif ($island['money'] > $MaxMoney) { $island['money'] = $MaxMoney; }
    $island['food'] = intval(isset($island['food']) ? $island['food'] : 0) + intval($HpresentFood);
    if ($island['food'] < 0) { $island['food'] = 0; } elseif ($island['food'] > $MaxFood) { $island['food'] = $MaxFood; }
    if (function_exists('logPresent')) { logPresent($HcurrentID, $name, $HpresentLog); }
    if (!writeIslandsFile($HcurrentID, 1)) { unlock(); tempFailWrite(); return; }
    unlock(); tempPresentOK($name);
}
}
if (!function_exists('tempPresentOK')) {
function tempPresentOK($name='') { global $HtagBig_, $H_tagBig, $HtempBack, $AfterName;
echo $HtagBig_.hako_admin_e($name).$AfterName.'에 선물을 주었습니다'.$H_tagBig.$HtempBack; }
}
if (!function_exists('tempPresentEmpty')) {
function tempPresentEmpty() { global $HtagBig_, $H_tagBig, $HtempBack;
echo $HtagBig_.'선물의 내용이 이상한 것 같습니다'.$H_tagBig.$HtempBack; }
}

if (!function_exists('punishMain')) {
function punishMain() {
    global $HspecialPassword, $HdefaultPassword, $HpunishMode, $HdirName, $HislandTurn, $HcurrentID, $HpunishID, $HcommandX, $HcommandY;
    if (!checkPassword($HspecialPassword, $HdefaultPassword)) { unlock(); hako_admin_top_page(); return; }
    if ($HpunishMode) {
        $punish = array(); $file = $HdirName.'/punish.dat';
        if (($fp = @fopen($file, 'r'))) {
            while (($line = fgets($fp)) !== false) {
                $a = explode(',', rtrim($line));
                if (count($a) < 5) { continue; }
                $punish[$a[1]] = array('turn'=>$a[0], 'id'=>$a[1], 'punish'=>$a[2], 'x'=>$a[3], 'y'=>$a[4]);
            }
            fclose($fp);
        }
        $punish[$HcurrentID] = array('turn'=>$HislandTurn, 'id'=>$HcurrentID, 'punish'=>$HpunishID, 'x'=>$HcommandX, 'y'=>$HcommandY);
        if (($fp = @fopen($file, 'w'))) {
            foreach ($punish as $obj) {
                if (intval($obj['punish']) == 0) { continue; }
                fwrite($fp, $obj['turn'].','.$obj['id'].','.$obj['punish'].','.$obj['x'].','.$obj['y']."\n");
            }
            fclose($fp);
        }
    }
    unlock(); tempPunishPage();
}
}
if (!function_exists('tempPunishPage')) {
function tempPunishPage() {
    global $HtempBack, $AfterName, $HthisFile, $HdefaultPassword, $HislandList, $HislandSize, $HdefaultX, $HdefaultY, $HdirName, $HbgTitleCell, $HbgInfoCell;
    $punishName = array('없음','지진(좌표 지정)','해일','괴수(인구 조건 만족시에만)','지반침하(면적 조건 만족시에만)','태풍','거대 운석(좌표 지정)','운석','분화(좌표 지정)','선박을 강제 퇴장','구상 이노라 강림(좌표 지정)','화재(좌표 지정)');
    echo $HtempBack."<hr><H1>참가${AfterName}에 제재를 더한다</H1>\n";
    echo "제재는 지정한 자연재해를 반드시 발생시킵니다.<BR>선박을 강제 퇴장은 선택한${AfterName}에 있는 무소속 이외의 배를 모두 귀환시키는 처리입니다.<BR><BR>\n";
    echo '<FORM name="lcForm" action="'.$HthisFile.'" method="POST"><INPUT TYPE="hidden" VALUE="'.hako_admin_e($HdefaultPassword).'" NAME="Punish">';
    echo '<B>제재를 더하는'.$AfterName.' 는 ?</B><BR><SELECT NAME="ISLANDID">'.$HislandList.'</SELECT> <INPUT TYPE="button" VALUE="맵을 연다" onclick="printIsland();"><BR><BR>';
    echo '<B>좌표는?</B><BR><B>(</B><SELECT NAME=POINTX>'.hako_admin_option_range($HislandSize,$HdefaultX).'</SELECT><B>, </B><SELECT NAME=POINTY>'.hako_admin_option_range($HislandSize,$HdefaultY).'</SELECT><B>)</B><BR><BR>';
    echo '<B>제재의 내용은?</B><BR><SELECT NAME="PUNISHID">';
    foreach ($punishName as $i=>$n) { echo '<OPTION VALUE="'.$i.'">'.$n."\n"; }
    echo '</SELECT><BR><BR><INPUT TYPE="submit" VALUE="제재를 더한다" NAME="PunishButton"><BR></FORM>';
    echo '<SCRIPT Language="JavaScript"><!--\nfunction printIsland() { var iid; with (document.forms[0].elements[1]) { iid = options[selectedIndex].value; } window.open("'.$HthisFile.'?Sight=" + iid, "punish", "toolbar=0,location=0,directories=0,menubar=0,status=1,scrollbars=1,resizable=1,width=450,height=630"); }\n//--></SCRIPT>';
    $file = $HdirName.'/punish.dat';
    if (($fp = @fopen($file, 'r'))) {
        echo "<HR><TABLE BORDER><TR><TH $HbgTitleCell>${AfterName}명</TH><TH $HbgTitleCell>제재 내용</TH><TH $HbgTitleCell>좌표</TH></TR>";
        while (($line = fgets($fp)) !== false) {
            $a = explode(',', rtrim($line)); if (count($a) < 5) { continue; }
            $name = hako_admin_island_name($a[1]); $pn = isset($punishName[$a[2]]) ? $punishName[$a[2]] : '';
            echo "<TR><TD $HbgInfoCell>".hako_admin_e($name)."${AfterName}</TD><TD $HbgInfoCell>".hako_admin_e($pn)."</TD><TD $HbgInfoCell>(".intval($a[3]).", ".intval($a[4]).")</TD></TR>";
        }
        echo '</TABLE>'; fclose($fp);
    }
}
}

if (!function_exists('lchangeMain')) {
function lchangeMain() {
    global $HspecialPassword, $HdefaultPassword, $HcurrentID, $HcurrentNumber, $HidToNumber, $Hislands, $HlchangeMode, $HlchangeKIND, $HlchangeVALUE, $HcommandX, $HcommandY,
           $HlandSea;
    if (!checkPassword($HspecialPassword, $HdefaultPassword)) { unlock(); hako_admin_top_page(); return; }
    if (isset($HidToNumber[$HcurrentID])) { $HcurrentNumber = $HidToNumber[$HcurrentID]; $GLOBALS['HcurrentNumber'] = $HcurrentNumber; }
    if ($HlchangeMode && isset($Hislands[$HcurrentNumber])) {
        if (!landCheck($HlchangeKIND, $HlchangeVALUE)) { tempBadValue(); unlock(); return; }
        $island =& $Hislands[$HcurrentNumber];
        $x = intval($HcommandX); $y = intval($HcommandY);
        $island['land'][$x][$y] = intval($HlchangeKIND);
        $island['landValue'][$x][$y] = intval($HlchangeVALUE);
        $island['land2'][$x][$y] = $HlandSea;
        $island['landValue2'][$x][$y] = 0;
        if (!writeIslandsFile($HcurrentID, 2)) { unlock(); tempFailWrite(); return; }
        tempLchangeOK($island['name']);
    }
    unlock(); tempLchangePage();
}
}
if (!function_exists('tempLchangePage')) {
function tempLchangePage() {
    global $HtempBack, $AfterName, $HcurrentID, $HislandSize, $HdefaultX, $HdefaultY, $HdefaultPassword, $HthisFile, $HlchangeKIND, $HlchangeVALUE;
    echo $HtempBack."<hr><H1>참가${AfterName} 의  지형 데이터를 변경한다</H1>\n";
    echo "기본적으로,<b>정상적으로 동작하지 않게 될 우려</b>가 있기 때문에<B>${AfterName} 의 데이터를 고쳐 쓰지 말아 주세요. </B><BR>\n";
    echo "<TABLE><TR><TD>";
    if ($HcurrentID != 0 && function_exists('islandMap')) { islandMap(1); } else { echo "지도 표시하기 위해서는,<br>한 번 ${AfterName}를 선택해 맵을 열어 주세요."; }
    $HtargetList = function_exists('getIslandList') ? getIslandList($HcurrentID) : '';
    echo "</TD><TD valign=top><FORM name=\"lcForm\" action=\"$HthisFile\" method=\"POST\">";
    echo '<INPUT TYPE="hidden" VALUE="'.hako_admin_e($HdefaultPassword).'" NAME="Lchange">';
    echo "<B>지형을 변경하는${AfterName}</B>(ID=$HcurrentID)<BR><SELECT NAME=\"ISLANDID\">$HtargetList</SELECT><BR><INPUT TYPE=\"submit\" VALUE=\"맵을 연다\" NAME=\"LchangeButtonM\"><BR><BR><BR>";
    echo '<B>좌표는?</B><BR><B>(</B><SELECT NAME=POINTX>'.hako_admin_option_range($HislandSize,$HdefaultX).'</SELECT><B>, </B><SELECT NAME=POINTY>'.hako_admin_option_range($HislandSize,$HdefaultY).'</SELECT><B>)</B><BR><BR>';
    $names = array('바다','황무지','평지','마을계','숲','농장','공장','미사일 기지','방위 시설','산','괴수','해저 기지','해저 유전','기념비','해저 기념비','위장 방위 시설','오염','슬럼가','상업 빌딩','정제장','은행','스타디움','유원지','카지노','공원','학교','돔','공항','소방서','전이 장치','동물원','대도시','박람회','거대 도시','거대 빌딩','거대 공장','거대 농장','상업 도시','초거대 도시','데스트랩','풍차','마이 홈','전이 지정 장치','항구','방파제','경찰서','병원','트럼프','꽃','입구','후지산','해적선','바다짐승 소탕정','이지스 함','해저 탐사선','유령선','보물선','소형 어선','중형 어선','대형 어선','익룡','빙산','부부바위','호화 여객선','바람배');
    $vars = array('HlandSea','HlandWaste','HlandPlains','HlandTown','HlandForest','HlandFarm','HlandFactory','HlandBase','HlandDefence','HlandMountain','HlandMonster','HlandSbase','HlandOil','HlandMonument','HlandSMonument','HlandHaribote','HlandOsen','HlandSlum','HlandTower','HlandSeisei','HlandBank','HlandStadium','HlandAmusement','HlandCasino','HlandPark','HlandSchool','HlandDome','HlandAirport','HlandFire','HlandWarp','HlandZoo','HlandBigcity','HlandExpo','HlandMegacity','HlandMegatower','HlandMegaFact','HlandMegaFarm','HlandTcity','HlandHugecity','HlandDeathtrap','HlandWindmill','HlandMyhome','HlandWarpR','HlandPort','HlandBreakwater','HlandPolice','HlandHospital','HlandTrump','HlandFlower','HlandDokan','HlandFuji','HlandPirate','HlandMonsShip','HlandAegisShip','HlandProbeShip','HlandGhostShip','HlandTreasureS','HlandFishSShip','HlandFishMShip','HlandFishLShip','HlandWingDragon','HlandIceFloe','HlandCoupleRock','HlandTitanic','HlandBalloonS');
    echo '<B>지형은?</B><BR><SELECT NAME="LCHANGEKIND">';
    foreach ($names as $i=>$nm) { $v = isset($GLOBALS[$vars[$i]]) ? $GLOBALS[$vars[$i]] : $i; echo '<OPTION VALUE='.$v.(intval($v)==intval($HlchangeKIND)?' SELECTED':'').'>'.$nm."\n"; }
    if ($HlchangeVALUE === '') { $HlchangeVALUE = 0; }
    echo '</SELECT><BR><BR><B>지형의 값은?</B><BR><INPUT TYPE="text" SIZE=6 NAME="LCHANGEVALUE" VALUE="'.hako_admin_e($HlchangeVALUE).'"><BR>(통상0-200)<BR>(미사일 기지0-250)<BR>(괴수1-3199)<BR>(배계0-59999)<BR><BR><INPUT TYPE="submit" VALUE="변경한다" NAME="LchangeButton"><BR></FORM></TD></TR></TABLE>';
    echo '<SCRIPT Language="JavaScript"><!--\nfunction ps(x, y) { document.lcForm.POINTX.options[x].selected = true; document.lcForm.POINTY.options[y].selected = true; return true; }\n//--></SCRIPT>';
}
}
if (!function_exists('tempLchangeOK')) {
function tempLchangeOK($name='') { global $HtagBig_, $H_tagBig, $AfterName;
echo $HtagBig_.hako_admin_e($name).$AfterName.' 의 지형을 변경했습니다'.$H_tagBig.'<HR>'; }
}
if (!function_exists('tempBadValue')) {
function tempBadValue() { global $HtagBig_, $H_tagBig, $HtempBack;
echo $HtagBig_.'지형의 값이 이상한 것 같습니다'.$H_tagBig.$HtempBack; }
}
if (!function_exists('landCheck')) {
function landCheck($land, $lv) {
    global $HlandSea, $HlandWaste, $HlandPlains, $HlandTown, $HlandForest, $HlandFarm, $HlandFactory, $HlandBase, $HlandDefence, $HlandMountain, $HlandMonster, $HlandSbase,
           $HlandOil, $HlandMonument, $HlandHaribote, $HlandOsen, $HlandSlum, $HlandTower, $HlandSeisei, $HlandBank, $HlandTrump, $HlandPirate, $HmaxExpPoint;
    $land = intval($land); $lv = intval($lv);
    if ($lv < 0) { return 0; }
    if ($land == $HlandSea || $land == $HlandWaste || $land == $HlandDefence || $land == $HlandMountain || $land == $HlandOil || $land == $HlandMonument || $land == $HlandSlum || $land == $HlandTower) { return ($lv <= 200) ? 1 : 0; }
    if ($land == $HlandPlains) { return ($lv == 0) ? 1 : 0; }
    if ($land == $HlandTown || $land == $HlandForest) { return (($lv >= 1) && ($lv <= 200)) ? 1 : 0; }
    if ($land == $HlandFarm) { return (($lv >= 10) && ($lv <= 50)) ? 1 : 0; }
    if ($land == $HlandFactory) { return (($lv >= 30) && ($lv <= 100)) ? 1 : 0; }
    if ($land == $HlandBase || $land == $HlandSbase) { return (($lv >= 0) && ($lv <= $HmaxExpPoint)) ? 1 : 0; }
    if ($land == $HlandMonster || $land == $HlandHaribote) { return ($lv <= 3199) ? 1 : 0; }
    if ($land == $HlandOsen) { return ($lv <= 9) ? 1 : 0; }
    if ($land == $HlandSeisei) { return ($lv <= 30) ? 1 : 0; }
    if ($land == $HlandBank) { return ($lv <= 100) ? 1 : 0; }
    if ($land == $HlandTrump) { return ($lv <= 14) ? 1 : 0; }
    if ($land >= $HlandPirate) { return ($lv <= 59999) ? 1 : 0; }
    return ($lv <= 200) ? 1 : 0;
}
}

if (!function_exists('preDeleteMain')) {
function preDeleteMain() {
    global $HspecialPassword, $HdefaultPassword, $HpreDeleteMode;
    if (!checkPassword($HspecialPassword, $HdefaultPassword)) { unlock(); hako_admin_top_page(); return; }
    if ($HpreDeleteMode) { preDeleteMainP(1); }
    unlock(); tempPdeleteMain();
}
}
if (!function_exists('preDeleteMainP')) {
function preDeleteMainP($mode = 0) {
    global $HpreDeleteID, $HcurrentID, $HidToNumber;
    if (!is_array($HpreDeleteID)) { $HpreDeleteID = array(); }
    $newID = array(); $flag = 0;
    foreach ($HpreDeleteID as $id) {
        if (!isset($HidToNumber[$id])) { continue; }
        if ($id == $HcurrentID) { $flag = 1; } else { $newID[] = $id; }
    }
    if (($HcurrentID > 90) && (!$flag)) { if ($mode) { tempPreDelete2(hako_admin_island_name($HcurrentID)); } }
    else {
        $HpreDeleteID = $newID;
        if (!$flag) { $HpreDeleteID[] = $HcurrentID; }
        $GLOBALS['HpreDeleteID'] = $HpreDeleteID;
        if ($mode) {
            writeIslandsFile($HcurrentID);
            $name = hako_admin_island_name($HcurrentID);
            if ($flag) { tempPreDeleteEnd($name); } else { tempPreDelete($name); }
        }
    }
}
}
if (!function_exists('tempPdeleteMain')) {
function tempPdeleteMain() {
    global $HtempBack, $AfterName, $HthisFile, $HdefaultPassword, $HislandList, $HpreDeleteID, $HidToNumber;
    echo '<CENTER>'.$HtempBack.'</CENTER><H1>참가'.$AfterName.'를 관리인이 보관하는 걸로 지정 한다</H1>';
    echo '<DL><DT>·보관하는 '.$AfterName.' 는 , 턴 처리(수입 처리·커멘드 처리·성장·재해등 )되지 않게 됩니다.</DT><DT>·Battle Field는, 보관 설정으로 할 수 없습니다. </DT></DL>';
    echo '<FORM name="pdForm" action="'.$HthisFile.'" method="POST"><INPUT TYPE="hidden" VALUE="'.hako_admin_e($HdefaultPassword).'" NAME="Pdelete"><B>관리인이 보관하는 '.$AfterName.' 는 ?</B><BR><SELECT NAME="ISLANDID">'.$HislandList.'</SELECT><BR><INPUT TYPE="submit" VALUE="설정·해제" NAME="PdeleteButton"><BR></FORM>';
    echo '<TABLE BORDER><TR><TH>보관 안의'.$AfterName.'</TH></TR>';
    if (!is_array($HpreDeleteID) || count($HpreDeleteID) == 0 || $HpreDeleteID[0] === '') { echo '<TR><TH>관리인 보관하는 '.$AfterName.' 는 없습니다!</TH></TR>'; }
    else { foreach ($HpreDeleteID as $id) { if (!isset($HidToNumber[$id])) { continue; } echo '<TR><TD>'.hako_admin_e(hako_admin_island_name($id)).$AfterName.'</TD></TR>'; } }
    echo '</TABLE>';
}
}
if (!function_exists('tempPreDelete')) { function tempPreDelete($name='') { global $HtagBig_, $H_tagBig, $AfterName;
echo $HtagBig_.hako_admin_e($name).$AfterName.'(을)를 관리인이 보관으로 했습니다'.$H_tagBig.'<HR>'; } }
if (!function_exists('tempPreDelete2')) { function tempPreDelete2($name='') { global $HtagBig_, $H_tagBig, $AfterName;
echo $HtagBig_.hako_admin_e($name).$AfterName.'(은)는 관리인이 보관 할 수 없습니다'.$H_tagBig.'<HR>'; } }
if (!function_exists('tempPreDeleteEnd')) { function tempPreDeleteEnd($name='') { global $HtagBig_, $H_tagBig, $AfterName;
echo $HtagBig_.hako_admin_e($name).$AfterName.' 의 관리인이 보관 해제했습니다'.$H_tagBig.'<HR>'; } }

if (!function_exists('ichangeMain')) {
function ichangeMain() {
    global $HspecialPassword, $HdefaultPassword, $HichangeMode;
    if (!checkPassword($HspecialPassword, $HdefaultPassword)) { unlock(); hako_admin_top_page(); return; }
    if ($HichangeMode) { ichangeMainP(); }
    unlock(); tempIchangePage();
}
}
if (!function_exists('ichangeMainP')) {
function ichangeMainP() {
    global $HcurrentID, $HcurrentNumber, $HidToNumber, $Hislands, $Hicmoney, $Hicfood, $Hically, $Hicweapon, $Hicevil, $Hicspace, $MaxMoney, $MaxFood, $MaxSigen;
    if (!isset($HidToNumber[$HcurrentID])) { return; }
    $HcurrentNumber = $HidToNumber[$HcurrentID]; $GLOBALS['HcurrentNumber'] = $HcurrentNumber;
    $island =& $Hislands[$HcurrentNumber];
    $island['money'] = intval($Hicmoney); $island['food'] = intval($Hicfood); $island['ally'] = intval($Hically); $island['weapon'] = intval($Hicweapon); $island['evil'] = intval($Hicevil);
    if ($Hicspace == 1) {
        $prize = isset($island['prize']) ? $island['prize'] : '0,0,';
        if (preg_match('/([0-9]*),([0-9]*),(.*)/', $prize, $m)) { $flags = intval($m[1]); $monsters = $m[2]; $turns = $m[3]; $flags |= 512; $island['prize'] = $flags.','.$monsters.','.$turns; }
    }
    if ($island['money'] > $MaxMoney) { $island['money'] = $MaxMoney; }
    if ($island['food'] > $MaxFood) { $island['food'] = $MaxFood; }
    if ($island['weapon'] > $MaxSigen) { $island['weapon'] = $MaxSigen; }
    if (!writeIslandsFile($HcurrentID, 1)) { unlock(); tempFailWrite(); return; }
}
}
if (!function_exists('tempIchangePage')) {
function tempIchangePage() {
    global $AfterName, $HthisFile, $HdefaultPassword, $HislandNumber, $Hislands, $Hallygroup, $Hallymark, $HunitMoney, $HunitFood, $HunitWeapon, $HbgTitleCell, $HbgNumberCell,
           $HbgNameCell, $HtagTH_, $H_tagTH, $HtagNumber_, $H_tagNumber;
    echo "<span class='attention'>※ 반드시 백업을 해 주세요. 데이터를 직접 수정하므로 위험합니다!</span>";
    echo "<TABLE BORDER><TR><TH $HbgTitleCell>${HtagTH_}순위${H_tagTH}</TH><TH $HbgTitleCell>${HtagTH_}${AfterName}${H_tagTH}</TH><TH $HbgTitleCell>${HtagTH_}자금${H_tagTH}</TH><TH $HbgTitleCell>${HtagTH_}식량${H_tagTH}</TH><TH $HbgTitleCell>${HtagTH_}병기${H_tagTH}</TH><TH $HbgTitleCell>${HtagTH_}유엔등${H_tagTH}</TH><TH $HbgTitleCell>${HtagTH_}우주상${H_tagTH}</TH><TH $HbgTitleCell>${HtagTH_}소속${H_tagTH}</TH><TH $HbgTitleCell>${HtagTH_}변경${H_tagTH}</TH></TR>";
    for ($i=0; $i<$HislandNumber; $i++) {
        if (!isset($Hislands[$i])) { continue; }
        $island = $Hislands[$i]; $id = $island['id']; if ($id > 90) { continue; } $j = $i + 1; $name = $island['name']; $zyuni = isset($island['zyuni']) ? $island['zyuni'] : '';
        $money = isset($island['money']) ? $island['money'] : 0; $food = isset($island['food']) ? $island['food'] : 0; $weapon = isset($island['weapon']) ? $island['weapon'] : 0; $evil = isset($island['evil']) ? $island['evil'] : 0; $ally = isset($island['ally']) ? $island['ally'] : 0;
        $space = (isset($island['prize']) && preg_match('/^([0-9]+)/', $island['prize'], $m) && (intval($m[1]) & 512)) ? 'CHECKED' : '';
        $select_list = ''; $groups = (is_array($Hallygroup) && count($Hallygroup) > 0) ? $Hallygroup : array('무소속','동맹군','연합군','제국군'); foreach ($groups as $a => $groupName) { $select_list .= '<OPTION VALUE='.$a.(intval($ally)==intval($a)?' SELECTED':'').'>'.hako_admin_e($groupName)."\n"; }
        $allymark = (is_array($Hallymark) && isset($Hallymark[$ally])) ? $Hallymark[$ally] : '';
        echo "<TR><FORM name=\"IchForm\" action=\"$HthisFile\" method=\"POST\"><INPUT TYPE=\"hidden\" VALUE=\"".hako_admin_e($HdefaultPassword)."\" NAME=\"Ichange\"><INPUT TYPE=\"hidden\" VALUE=\"$id\" NAME=\"ICID\"><TD $HbgNumberCell>${HtagNumber_}$j${H_tagNumber}($zyuni)</TD><TD $HbgNameCell>${HtagTH_}".hako_admin_e($name)."${AfterName}${H_tagTH}($id)</TD><TD><INPUT TYPE=\"text\" SIZE=5 NAME=\"ICMONEY\" VALUE=\"$money\">$HunitMoney</TD><TD><INPUT TYPE=\"text\" SIZE=5 NAME=\"ICFOOD\" VALUE=\"$food\">$HunitFood</TD><TD><INPUT TYPE=\"text\" SIZE=4 NAME=\"ICWEAPON\" VALUE=\"$weapon\">$HunitWeapon</TD><TD><INPUT TYPE=\"text\" SIZE=5 NAME=\"ICEVIL\" VALUE=\"$evil\"></TD><TD><INPUT TYPE=\"checkbox\" NAME=\"ICSPACE\" $space></TD><TD><SELECT NAME=\"ICALLY\">$select_list</SELECT><b>$allymark</b></TD><TD><INPUT TYPE=\"submit\" VALUE=\"변경\" NAME=\"IchangeButton\"></TD></FORM></TR>";
    }
    echo '</TABLE>1'.$AfterName.' 밖에 수정 밖에 할 수 없습니다<br>유엔등은, 미사일 기지가 없는'.$AfterName.'의 값을 0으로 하면, 유엔 보호화가 됩니다. <br>또, 10000이상으로 하면 황금기가 됩니다. <br>우주상은, 주기 밖에 할 수 없습니다.<br>';
}
}

if (!function_exists('setupValue')) {
function setupValue() {
    global $HspecialPassword, $HdefaultPassword, $efileDir, $HefileDir, $HbaseDir, $HtempBack, $Hdebug, $imageDir, $HlogMax, $HtopLogTurn, $HbackupTurn, $HbackupTimes,
           $HhistoryMax, $HWeatherMax, $Hlipdisp, $HlbbsAuth, $HlbbsAnon, $HlbbsSpeaker, $Hurlownermode, $Htournament, $HwarFlg, $Hpossess, $HsurvFlg, $Hallyflg, $Hallybbs,
           $adminName, $email, $bbs, $toppage, $helpDir, $AfterName, $HmaxIsland, $HislandSize, $HcommandMax, $HunitTime, $HinitialMoney, $HinitialFood, $MaxMoney, $MaxFood,
           $HunitMoney, $HunitFood, $HunitPop, $HunitArea, $HunitTree, $HcostChangeName, $HeatenFood, $HbigcityFood, $Haidpop, $Hatkturn, $HspaceEfficiency, $HspaceIncome,
           $HdBaseAuto, $HmaxExpPoint, $HwinMoney, $HwinFood, $HwinWeapon, $HunitWeapon, $HcomcolonyTurn, $HcomSSendMonsterTurn, $HcomSendMonsterTurn, $HbgInfoCell, $HtagTH_,
           $H_tagTH, $HdisEarthquake, $HdisTsunami, $HdisTyphoon, $HdisMeteo, $HdisHugeMeteo, $HdisEruption, $HdisAkasio, $HdisVGHarvest, $HdisGHarvest, $HdisBHarvest, $HdisPirate,
           $HdisTreasureS, $HdisFallBorder, $HdisFalldown, $HdisFire, $HdisMaizo, $HdisTinka, $HdisAEruption, $HdisPollution, $HmaxdisPollution, $HdisCrime, $HdisSHugeMeteo,
           $HdisMonster, $HdisMonsterU, $HdisSpaceMonster1, $HdisSpaceMonster2, $HdisSeaMonster;

    $admin = (function_exists('checkPassword') && checkPassword($HspecialPassword, $HdefaultPassword)) ? 1 : 0;
    unlock();

    $setupPath = (isset($HefileDir) && $HefileDir !== '') ? rtrim($HefileDir, '/').'/setup.html' : 'setup.html';
    $setupUrl  = (isset($efileDir) && $efileDir !== '') ? rtrim($efileDir, '/').'/setup.html' : 'setup.html';
    // CGI 원본은 setup.html 이 이미 있어도 참가자용 설정 파일을 다시 생성한 뒤 이동한다.

    $switchStr = array('OFF','ON');
    $switchStrT = array('OFF','ON','ON(괴수 첨부)');
    $enaStr = array('하지못한다.','할수있다.');
    $doStr = array('못한다','한다');

    $turntime = '';
    if (!empty($HunitTime)) {
        $sec = $HunitTime % 60; $min = intval(($HunitTime % 3600) / 60); $hour = intval($HunitTime / 3600);
        $turntime = '<BR>1 턴이 몇초인가 <B>'.$HunitTime.'초 ( '.($hour?$hour.'시간':'').($min?$min.'분':'').($sec?$sec.'초':'').' )</B><BR>';
    }
    $bigcity = !empty($HbigcityFood) ? '통상의 마을과 같은 소비량' : '3배의 소비량';
    $aidpop = (intval($Haidpop) <= 0) ? '제한 없음' : $Haidpop.$HunitPop;

    $src = '';
    if (!$admin) {
        $css = isset($GLOBALS['HcssFile']) ? $GLOBALS['HcssFile'] : 'skin/style.css';
        $src .= '<HTML><META http-equiv="Content-Type" content="text/html;charset=UTF-8"><HEAD><TITLE>'.htmlspecialchars(isset($GLOBALS['Htitle'])?$GLOBALS['Htitle']:'',ENT_QUOTES,'UTF-8').'</TITLE><BASE HREF="'.$imageDir.'/"><link rel="stylesheet" type="text/css" href="'.$css.'"></HEAD>'.(isset($GLOBALS['Body'])?$GLOBALS['Body']:'<body>').'<DIV ID="BodySpecial"><DIV ID="LinkHead"><A HREF="http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html">모형정원 제도 스크립트 배포원</A></DIV><HR>';
    }
    $src .= '<CENTER>'.$HtempBack.'</CENTER><DIV ID="setupValue"><H1>구상의 모형정원 설정 일람</H1>';

    if ($admin) {
        $src .= '--- 관리인용 설정 확인 데이터 --- <BR><BR>';
        $src .= '※ 설정을 변경했을 경우는, 반드시 이하의 링크를 열어 참가자용의 재생성을 실시해 주세요.<BR>';
        $src .= '<A HREF="'.$HbaseDir.'/hako-main.php?SetupV=0" target="_blank">참가자용의 재생성</A><BR><BR>';
        $src .= '디버그 모드<B>'.(isset($switchStr[$Hdebug])?$switchStr[$Hdebug]:$Hdebug).'</B><BR>';
        $src .= '설치 디렉토리<B>'.$HbaseDir.'</B><BR>이미지 디렉토리<B>'.$imageDir.'</B><BR><BR>';
        $src .= '로그 파일 보관 유지 턴수<B>'.$HlogMax.'턴</B><BR>「최근의 사건」에 표시하는 로그의 턴수<B>'.$HtopLogTurn.'턴</B><BR>';
        $src .= '백업을 무엇 턴 걸러서 취할까<B>'.$HbackupTurn.'턴</B><BR>백업을 몇회분 남길까<B>'.$HbackupTimes.'회분</B><BR>';
        $src .= '발견 로그 보관 유지행수<B>'.$HhistoryMax.'행</B><BR>날씨 로그 보관 유지행수<B>'.$HWeatherMax.'행</B><BR><BR>';
        $src .= 'IP표시<B>'.(isset($switchStr[$Hlipdisp])?$switchStr[$Hlipdisp]:$Hlipdisp).'</B><BR><BR>';
        $src .= '로컬 게시판의 패스워드 인증<B>'.(isset($switchStr[$HlbbsAuth])?$switchStr[$HlbbsAuth]:$HlbbsAuth).'</B><BR>';
        $src .= '　관광객의 로컬 게시판 익명 발언 기능<B>'.(isset($switchStr[$HlbbsAnon])?$switchStr[$HlbbsAnon]:$HlbbsAnon).'</B><BR>';
        $src .= '　발언에 발언자의 이름 표시<B>'.(isset($switchStr[$HlbbsSpeaker])?$switchStr[$HlbbsSpeaker]:$HlbbsSpeaker).'</B><BR><BR>';
        $src .= '직개발 모드 때의 패스워드<B>'.$Hurlownermode.'</B><BR>　　→　(　hako-main.php?PASSWORD=****&amp;'.$Hurlownermode.'=ID<BR><BR>';
        $src .= '--- 참가자용 설정 확인 데이터 --- <BR><BR>';
    }

    $src .= '간이 토너먼트 모드<B>'.(isset($switchStrT[$Htournament])?$switchStrT[$Htournament]:$Htournament).'</B><BR>';
    $src .= '전쟁 모드<B>'.(isset($switchStr[$HwarFlg])?$switchStr[$HwarFlg]:$HwarFlg).'</B><BR>';
    $src .= '　패배가 되는 자신의 섬 점유수<B>'.$Hpossess.'미만</B>(0의 경우는, 패배가 되지 않습니다)<BR>';
    $src .= '간이 서바이벌 모드<B>'.(isset($switchStr[$HsurvFlg])?$switchStr[$HsurvFlg]:$HsurvFlg).'</B><BR>';
    $src .= '간이 진영 나누기 모드<B>'.(isset($switchStr[$Hallyflg])?$switchStr[$Hallyflg]:$Hallyflg).'</B><BR>';
    $src .= '　각 진영내의 극비 통신을 인증 관광 모드로 참조할 수 있을까?<B>'.(isset($enaStr[$Hallybbs])?$enaStr[$Hallybbs]:$Hallybbs).'</B><BR><BR>';
    $src .= '관리자명<B>'.$adminName.'</B><BR>관리자의 메일 주소<B><a href="mailto:'.$email.'">'.$email.'</a></B><BR>';
    $src .= '게시판 주소<B><a href="'.$bbs.'">'.$bbs.'</a></B><BR>홈 페이지의 주소<B><a href="'.$toppage.'">'.$toppage.'</a></B><BR>도움말의 주소<B><a href="'.$helpDir.'">'.$helpDir.'</a></B><BR><BR>';
    $src .= $AfterName.'의 최대수<B>'.$HmaxIsland.'</B><BR>'.$AfterName.'의 크기<B>'.$HislandSize.'x'.$HislandSize.'</B><BR>커멘드 입력 한계수<B>'.$HcommandMax.'</B><BR>'.$turntime.'<BR>';
    $src .= '<TABLE><TR '.$HbgInfoCell.'><TH rowspan=2>'.$HtagTH_.'초기 자금 / 최대 자금 '.$H_tagTH.'</TH><TH rowspan=2>'.$HtagTH_.'초기 식량 / 최대 식량 '.$H_tagTH.'</TH><TH colspan=5>'.$HtagTH_.'최소단위 '.$H_tagTH.'</TH></TR>';
    $src .= '<TR '.$HbgInfoCell.'><TH>'.$HtagTH_.'돈 '.$H_tagTH.'</TH><TH>'.$HtagTH_.'식량 '.$H_tagTH.'</TH><TH>'.$HtagTH_.'인구 '.$H_tagTH.'</TH><TH>'.$HtagTH_.'넓이'.$H_tagTH.'</TH><TH>'.$HtagTH_.'나무의 수'.$H_tagTH.'</TH></TR>';
    $src .= '<TR '.$HbgInfoCell.'><TD align="center">'.$HinitialMoney.$HunitMoney.' / '.$MaxMoney.$HunitMoney.'</TD><TD align="center">'.$HinitialFood.$HunitFood.' / '.$MaxFood.$HunitFood.'</TD><TD align="right">1'.$HunitMoney.'</TD><TD align="right">1'.$HunitFood.'</TD><TD align="right">1'.$HunitPop.'</TD><TD align="right">1'.$HunitArea.'</TD><TD align="right">1'.$HunitTree.'</TD></TR></TABLE><BR>';
    $src .= '이름 변경의 설정<B>'.$HcostChangeName.$HunitMoney.'</B><BR>인구1'.$HunitPop.'근처의 식량 소비료<B>'.$HeatenFood.'x1'.$HunitFood.'</B><BR>대도시의 식량 소비량<B>'.$bigcity.'</B><BR>원조계를 불가로 하는 인구<B>'.$aidpop.'</B><BR>섬 발견으로부터 타도에 공격계 명령을 제한을 더하는 턴수<B>'.$Hatkturn.'턴</B><BR><BR>';
    $src .= '우주 공장, 우주 농장은, 우주 인구의 몇배의 규모분이 가동할까? <B>'.$HspaceEfficiency.'배</B><BR>우주 공장, 우주 농장의 가동하고 있는 천명 규모 근처의 지상 수입 <B>'.$HspaceIncome.'억</B><BR><BR>';
    $src .= '방위 시설은, 괴수에게 밟혔을 때 자폭할까?<B>'.(isset($doStr[$HdBaseAuto])?$doStr[$HdBaseAuto]:$HdBaseAuto).'</B><BR>기지의 경험치의 최대치<B>'.$HmaxExpPoint.'</B><BR><BR>';
    $src .= '점유율에 의한 승패 기능으로 승리한 도을 받을 수 있는 양.<BR>자금<B>'.$HwinMoney.$HunitMoney.'</B><BR>식량<B>'.$HwinFood.$HunitFood.'</B><BR>병기<B>'.$HwinWeapon.$HunitWeapon.'</B><BR><BR>';
    $src .= '턴 차이 명령으로, 명령 실행으로부터 실제로 발동하는 턴수<BR>콜로니 오토시：<B>'.$HcomcolonyTurn.'</B>턴<BR>S괴수 파견：<B>'.$HcomSSendMonsterTurn.'</B>턴<BR>괴수 파견：<B>'.$HcomSendMonsterTurn.'</B>턴<BR><BR>';
    $de = array('지진'=>$HdisEarthquake*0.1,'해일'=>$HdisTsunami*0.1,'태풍'=>$HdisTyphoon*0.1,'운석'=>$HdisMeteo*0.1,'거대 운석'=>$HdisHugeMeteo*0.1,'분화'=>$HdisEruption*0.1,'적조'=>$HdisAkasio*0.1,'대풍작'=>$HdisVGHarvest*0.1,'풍작'=>$HdisGHarvest*0.1,'흉작'=>$HdisBHarvest*0.1,'해적선'=>$HdisPirate*0.1,'보물선'=>$HdisTreasureS*0.1);
    $src .= '도전체의 재해 등<TABLE><TR '.$HbgInfoCell.'>';
    foreach ($de as $k=>$v) { $src .= '<TH>'.$HtagTH_.$k.$H_tagTH.'</TH>'; }
    $src .= '<TH>'.$HtagTH_.'지반침하 안전 한계'.$H_tagTH.'</TH><TH>'.$HtagTH_.'지반침하 확률'.$H_tagTH.'</TH></TR><TR '.$HbgInfoCell.'>';
    foreach ($de as $v) { $src .= '<TD align="right">'.$v.'%</TD>'; }
    $src .= '<TD align="right">'.$HdisFallBorder.$HunitArea.'('.$HdisFallBorder.'Hex)</TD><TD align="right">'.($HdisFalldown*0.1).'%</TD></TR></TABLE><BR>';
    $src .= '단위면적 근처에서 발생하는 재해 등<TABLE><TR '.$HbgInfoCell.'><TH>화재</TH><TH>매장금</TH><TH>온천 국지 지반침하</TH><TH>재분화</TH></TR><TR '.$HbgInfoCell.'><TD align="right">'.($HdisFire*0.1).'%</TD><TD align="right">'.($HdisMaizo*0.1).'%</TD><TD align="right">'.($HdisTinka*0.01).'%</TD><TD align="right">'.($HdisAEruption*0.1).'%</TD></TR></TABLE><BR>';
    $src .= '그 외의 재해<BR>공해 <B>'.($HdisPollution*0.01).'%</B>　(인구 1만명 당의 발생율)<BR>공해 최대 확률 <B>'.($HmaxdisPollution*0.1).'%</B><BR>범죄 <B>'.($HdisCrime*0.01).'%</B><BR>우주 공장 1개 건설시 거대 운석이 발생하는 확률 <B>'.($HdisSHugeMeteo*0.0001).'%</B>×개발 면적<BR><BR>';
    $src .= '단위면적 근처의 괴수 출현율 <B>'.($HdisMonster*0.01).'%</B><BR>단위면적 근처의 매립 이노라, 갯바람배의 출현치<B>'.$HdisMonsterU.'</B><BR>우주에서의 괴수의 출현치 <B>'.$HdisSpaceMonster1.'개발 면적</B> <B>'.$HdisSpaceMonster2.'×개발 면적</B><BR>해역에서의 괴수의 출현치<B>'.$HdisSeaMonster.'</B><BR>';
    // CGI 원본 setupValue의 괴수 출현 기준 및 괴수 일람표 출력부
    $g = $GLOBALS;
    $monsterName = (isset($g['HmonsterName']) && is_array($g['HmonsterName'])) ? $g['HmonsterName'] : array();
    $monsterImage = (isset($g['HmonsterImage']) && is_array($g['HmonsterImage'])) ? $g['HmonsterImage'] : array();
    $monsterBHP = (isset($g['HmonsterBHP']) && is_array($g['HmonsterBHP'])) ? $g['HmonsterBHP'] : array();
    $monsterDHP = (isset($g['HmonsterDHP']) && is_array($g['HmonsterDHP'])) ? $g['HmonsterDHP'] : array();
    $monsterExp = (isset($g['HmonsterExp']) && is_array($g['HmonsterExp'])) ? $g['HmonsterExp'] : array();
    $monsterValue = (isset($g['HmonsterValue']) && is_array($g['HmonsterValue'])) ? $g['HmonsterValue'] : array();
    $monsterSpecial = (isset($g['HmonsterSpecial']) && is_array($g['HmonsterSpecial'])) ? $g['HmonsterSpecial'] : array();
    $levels = array(
        array('괴수 출현 인구 기준 1(괴수 레벨 1)', isset($g['HdisMonsBorder1']) ? $g['HdisMonsBorder1'] : 0, isset($g['HmonsterL1']) ? $g['HmonsterL1'] : array()),
        array('괴수 출현 인구 기준 2(괴수 레벨 2)', isset($g['HdisMonsBorder2']) ? $g['HdisMonsBorder2'] : 0, isset($g['HmonsterL2']) ? $g['HmonsterL2'] : array()),
        array('괴수 출현 인구 기준 3(괴수 레벨 3)', isset($g['HdisMonsBorder3']) ? $g['HdisMonsBorder3'] : 0, isset($g['HmonsterL3']) ? $g['HmonsterL3'] : array()),
        array('괴수 출현 인구 기준 4(괴수 레벨 4)', isset($g['HdisMonsBorder4']) ? $g['HdisMonsBorder4'] : 0, isset($g['HmonsterL4']) ? $g['HmonsterL4'] : array()),
        array('괴수 출현 인구 기준 5(괴수 레벨 5)', isset($g['HdisMonsBorder5']) ? $g['HdisMonsBorder5'] : 0, isset($g['HmonsterL5']) ? $g['HmonsterL5'] : array())
    );
    foreach ($levels as $lv) {
        $src .= '<BR>'.$lv[0].'<B>'.$lv[1].$HunitPop.'</B><BR>';
        $arr = is_array($lv[2]) ? $lv[2] : array();
        foreach ($arr as $mi) {
            if (isset($monsterName[$mi])) { $src .= $monsterName[$mi].' '; }
        }
        $src .= '<BR>';
    }
    $src .= '<BR><TABLE><TR '.$HbgInfoCell.'><TH colspan=2 rowspan=2>'.$HtagTH_.'괴수의 명칭'.$H_tagTH.'</TH><TH colspan=2>'.$HtagTH_.'체력'.$H_tagTH.'</TH><TH rowspan=2>'.$HtagTH_.'경험치'.$H_tagTH.'</TH><TH rowspan=2>'.$HtagTH_.'잔해의 가격'.$H_tagTH.'</TH><TH rowspan=2>'.$HtagTH_.'기본적인 능력'.$H_tagTH.'</TH></TR>';
    $src .= '<TR '.$HbgInfoCell.'><TH>'.$HtagTH_.'min'.$H_tagTH.'</TH><TH>'.$HtagTH_.'max'.$H_tagTH.'</TH></TR>';
    $Monspe = array('알수 없음','발이 빠른(최대 2보 걷는다)','다리가 매우 빠른(최대몇보 걸을까 불명)','홀수 턴은 방어','짝수 턴은 방어','항상 방어이지만 25%로 맞는다','명령 처리보다 먼저 이동(0-1보)','명령 처리보다 먼저 이동(최대몇보 걸을까 불명)','주위 1에 헥스에 안개를 내는','회복한다(매턴 MAX)');
    for ($i = 0; $i < count($monsterName); $i++) {
        $img = isset($monsterImage[$i]) ? $monsterImage[$i] : 'monster'.$i.'.gif';
        $bhp = isset($monsterBHP[$i]) ? intval($monsterBHP[$i]) : 0;
        $dhp = isset($monsterDHP[$i]) ? intval($monsterDHP[$i]) : 0;
        $maxHP = $bhp + $dhp - 1;
        if (!$dhp) { $maxHP++; }
        $exp = isset($monsterExp[$i]) ? $monsterExp[$i] : 0;
        $val = isset($monsterValue[$i]) ? $monsterValue[$i] : 0;
        $sp = isset($monsterSpecial[$i]) ? intval($monsterSpecial[$i]) : 0;
        $spText = isset($Monspe[$sp]) ? $Monspe[$sp] : $Monspe[0];
        $src .= '<TR '.$HbgInfoCell.'><TD align="right"><img src="'.$img.'"></TD><TH>'.$monsterName[$i].'</TH><TD align="right">'.$bhp.'</TD><TD align="right">'.$maxHP.'</TD><TD align="right">'.$exp.'</TD><TD align="right">'.$val.$HunitMoney.'</TD><TD align="right">'.$spText.'</TD></TR>';
    }
    $src .= '</TABLE><BR>';
    $src .= '</DIV>';

    if ($admin) {
        echo $src;
    } else {
        @file_put_contents($setupPath, $src);
        @chmod($setupPath, 0666);
        echo '<meta HTTP-EQUIV="refresh" CONTENT="0; URL='.$setupUrl.'">';
    }
}
}

if (!function_exists('timeToString')) {
function timeToString($t) { $a = localtime(intval($t), true); return ($a['tm_mon'] + 1).'월 '.$a['tm_mday'].'일 '.$a['tm_hour'].'시 '.$a['tm_min'].'분'; }
}
if (!function_exists('logHistory')) {
function logHistory($msg) { global $HlogdirName, $HislandTurn;
if (!is_dir($HlogdirName)) { @mkdir($HlogdirName, 0777, true); } if (($fp = @fopen($HlogdirName.'/hakojima.his', 'a'))) { fwrite($fp, $HislandTurn.','.$msg."\n"); fclose($fp); } }
}
if (!function_exists('logDiscover')) { function logDiscover($name) { global $HtagName_, $H_tagName, $AfterName, $addr;
logHistory($HtagName_.$name.$AfterName.' '.$H_tagName.'가 발견된다.'.$addr); } }
if (!function_exists('logChangeName')) { function logChangeName($name1, $name2) { global $HtagName_, $H_tagName, $AfterName, $addr;
logHistory($HtagName_.$name1.$AfterName.$H_tagName.'、명칭을'.$HtagName_.$name2.$AfterName.$H_tagName.' 으로 변경한다.'.$addr); } }
if (!function_exists('logDeleteIsland')) { function logDeleteIsland($id, $name) { global $HtagName_, $H_tagName, $AfterName;
logHistory($HtagName_.$name.$AfterName.' '.$H_tagName.'에, 돌연<B>천벌이 내리고</B>순식간에<B><FONT COLOR="ff0000">바다에 침몰해</FONT></B>흔적도 없어졌습니다.'); } }

if (!function_exists('bfieldMain')) {
function bfieldMain() {
/* Original CGI body retained for line-for-line retranslation reference:
sub bfieldMain {
	if (!$HbfieldMode) {
		unlock();
		tempHeader();
		# 패스워드 체크
		if(checkPassword($HspecialPassword, $HdefaultPassword)) {
			# 특수 패스워드
			tempBfieldPage();
		} else {
			# password 실수
			tempWrongPassword();
		}
	} else {
		#  BattleField 작성
		newIslandMain($HbfieldMode);
	}
}
  */
  return null;
}
}

if (!function_exists('tempBfieldPage')) {
function tempBfieldPage() {
extract($GLOBALS, EXTR_SKIP);
  echo <<<HEDOC_tempBfieldPage_0
$HtempBack<hr>
<H1>Battle Field를 작성</H1>
<FORM action="$HthisFile" method="POST">
어떤 BattleField로 합니까?<BR>
<INPUT TYPE="text" NAME="ISLANDNAME" SIZE=32 MAXLENGTH=32>$AfterName<BR>
사용자 이름<br>
<INPUT TYPE="text" NAME="OWNERNAME" SIZE=32 MAXLENGTH=32><BR>
패스워드 입력<BR>
<INPUT TYPE="password" NAME="PASSWORD" SIZE=32 MAXLENGTH=32><BR>
패스워드 확인<BR>
<INPUT TYPE="password" NAME="PASSWORD2" SIZE=32 MAXLENGTH=32><BR>
작성하는 Battle Field의 지형의 패턴을 선택해 주세요.<BR>
<SELECT NAME="LBFIELD">
<OPTION VALUE="1" SELECTED>중심이 섬
<OPTION VALUE="2">모두 바다
<OPTION VALUE="3">평지투성이의 섬
<OPTION VALUE="4">도시투성이의 섬
</SELECT><BR><BR>
	<META http-equiv="Content-Style-Type" content="text/css">
<META http-equiv="Content-Type" content="text/html;charset=UTF-8">
<INPUT TYPE="hidden" VALUE="{${htmlEscape($GLOBALS['HdefaultPassword'])}}" NAME="Bfield">
<INPUT TYPE="submit" VALUE="Battle Field작성" NAME="BfieldButton">
</FORM>
HEDOC_tempBfieldPage_0;
}
}

if (!function_exists('tempBfieldOK')) {
function tempBfieldOK() {
extract($GLOBALS, EXTR_SKIP);
  echo <<<HEDOC_tempBfieldOK_0
${HtagBig_}$_[0]${AfterName} 의 Battle Field설정을 변경했습니다.<br>$_[1]${H_tagBig}$HtempBack
HEDOC_tempBfieldOK_0;
}
}

if (!function_exists('tempBfieldNG')) {
function tempBfieldNG() {
extract($GLOBALS, EXTR_SKIP);
  echo <<<HEDOC_tempBfieldNG_0
${HtagBig_}Battle Field의 설정 에러($_[0]).${H_tagBig}$HtempBack
HEDOC_tempBfieldNG_0;
}
}

if (!function_exists('presentMain')) {
function presentMain() {
extract($GLOBALS, EXTR_SKIP);
  /* Original CGI body retained for line-for-line retranslation reference:
sub presentMain {
	if (!$HpresentMode) {
		# 개방
		unlock();

		# 템플릿 출력
		tempPresentPage();
	} else {
		# 패스워드 체크
		if(checkPassword($HspecialPassword, $HoldPassword)) {
			# 특수 패스워드

			if(!$HpresentMoney && !$HpresentFood) {
				# 돈도 식량도 없다
				tempPresentEmpty();
				unlock();
				return;
			}

			# id(으)로부터 도을 취득
			$HcurrentNumber = $HidToNumber{$HcurrentID};
			my($island) = $Hislands[$HcurrentNumber];
			my($name)   = {$island['name']};

			{$island['money']} += $HpresentMoney;
			if({$island['money']} < 0){
				{$island['money']} = 0;
			}elsif({$island['money']} > $MaxMoney){
				{$island['money']} = $MaxMoney;
			}
			{$island['food']} += $HpresentFood;
			if({$island['food']} < 0){
				{$island['food']} = 0;
			}elsif({$island['food']} > $MaxFood){
				{$island['food']} = $MaxFood;
			}
			logPresent($HcurrentID, $name, $HpresentLog);

			# 데이터 서두
			if(!writeIslandsFile($HcurrentID, 1)) {
				unlock();
				tempFailWrite();
				return;
			}
			unlock();
			# 변경 성공
			tempPresentOK($name);
		} else {
			#  password 실수
			unlock();
			tempWrongPassword();
			return;
		}
	}
}
  */
  return null;
}
}

if (!function_exists('tempPresentPage')) {
function tempPresentPage() {
extract($GLOBALS, EXTR_SKIP);
  echo <<<HEDOC_tempPresentPage_0
$HtempBack<hr>
<H1>참가${AfterName}에 선물을 준다</H1>
<UL>
<LI>「발견의 기록」에 로그가 남는 이벤트로서 원조를 실시할 수가 있습니다.
<LI>표시된 폼에 필요한 값이나 메세지를 입력해, 패스워드에 「특수 패스워드」를 넣어 「선물을 준다」버튼을 누르면 선물 할 수 있습니다.
<LI>로그에는 HTML 태그도 사용할 수 있습니다만, 잘못한 로그를 삭제를 할 수 없기 때문에, 신중하게 입력해 주세요. 미리 브라우저로 표시 테스트를 실시해 두는 편이 좋을 것입니다. 「발견의 기록」에 이상한 로그가 남으면, 조금 부끄럽습니다.
<LI>자금이나 식량의 보유량이 제한치를 넘는 것이나 마이너스는 되지 않게 잘라 버리고 있습니다. 버그 대책이므로 양해 바랍니다.
</UL><BR>
<FORM action="$HthisFile" method="POST">
<B>선물을 받는${AfterName} 는 ?</B><BR>
<SELECT NAME="ISLANDID">
$HislandList
</SELECT><BR><BR>
<B>선물의 내용은? (마이너스치도 가능)</B><BR>
<INPUT TYPE="text" NAME="PRESENTMONEY" VALUE="0" SIZE=16 MAXLENGTH=16>$HunitMoney<BR>
<INPUT TYPE="text" NAME="PRESENTFOOD"  VALUE="0" SIZE=16 MAXLENGTH=16>$HunitFood<BR>
<BR>
<B>로그 메세지는? (생략 가능. 선두에${AfterName}명이 삽입됩니다)</B><BR>
00${AfterName}<INPUT TYPE="text" NAME="PRESENTLOG"  VALUE="" SIZE=128 MAXLENGTH=256><BR>
<BR>
<B>패스워드는?</B><BR>
<INPUT TYPE="password" NAME="OLDPASS" SIZE=32 MAXLENGTH=32><BR>
<INPUT TYPE="submit" VALUE="선물을 준다" NAME="PresentButton"><BR>
</FORM>
HEDOC_tempPresentPage_0;
}
}

if (!function_exists('tempPresentOK')) {
function tempPresentOK() {
extract($GLOBALS, EXTR_SKIP);
  echo <<<HEDOC_tempPresentOK_0
${HtagBig_}$_[0]${AfterName}에 선물을 주었습니다${H_tagBig}$HtempBack
HEDOC_tempPresentOK_0;
}
}

if (!function_exists('tempPresentEmpty')) {
function tempPresentEmpty() {
extract($GLOBALS, EXTR_SKIP);
  echo <<<HEDOC_tempPresentEmpty_0
${HtagBig_}선물의 내용이 이상한 것 같습니다${H_tagBig}$HtempBack
HEDOC_tempPresentEmpty_0;
}
}

if (!function_exists('punishMain')) {
function punishMain() {
extract($GLOBALS, EXTR_SKIP);
  /* Original CGI body retained for line-for-line retranslation reference:
sub punishMain {
	if(checkPassword($HspecialPassword, $HdefaultPassword)) {
		# 특수 패스워드
		if ($HpunishMode) {
			my(%punish);
			if (open(Fpunish, "<${HdirName}/punish.dat")) {
				local(@_);
				while (<Fpunish>) {
					chomp;
					@_ = split(',');
					my($obj);
					{$obj['turn']} = shift;
					{$obj['id']} = shift;
					{$obj['punish']} = shift;
					{$obj['x']} = shift;
					{$obj['y']} = shift;
					$punish{{$obj['id']}} = $obj;
				}
				close(Fpunish);
			}

			if (open(Fpunish, ">${HdirName}/punish.dat")) {
				{
					my($obj);
					{$obj['turn']} = $HislandTurn;
					{$obj['id']} = $HcurrentID;
					{$obj['punish']} = $HpunishID;
					{$obj['x']} = $HcommandX;
					{$obj['y']} = $HcommandY;
					$punish{{$obj['id']}} = $obj;
				}

				my($key, $obj);
				while (($key, $obj) = each %punish) {
					next if ({$obj['punish']} == 0);
					print Fpunish
						{$obj['turn']} . ','.
						{$obj['id']} . ','.
						{$obj['punish']} . ','.
						{$obj['x']} . ','.
						{$obj['y']} . "\n";
				}
				close(Fpunish);
			}
		}

		unlock();

		# 템플릿 출력
		tempPunishPage();

	} else {
		# 패스워드가 일치하지 않으면 탑 페이지로
		unlock();

		# 템플릿 출력
		tempTopPage();
	}
}
  */
  return null;
}
}

if (!function_exists('tempPunishPage')) {
function tempPunishPage() {
extract($GLOBALS, EXTR_SKIP);
  echo <<<HEDOC_tempPunishPage_0
$HtempBack<hr>
<H1>참가${AfterName}에 제재를 더한다</H1>
제재는 지정한 자연재해를 반드시 발생시킵니다. 예를 들면 「${AfterName}에 지반침하」라고 하는 지시를 내리면 다음의 턴으로 지반침하 합니다.
<br>이 개조는, 「털기라고 할 정도는 아니지만 모형정원의 분위기를 악화시키는 것 같은 행위를 하는 플레이어」나,
<br>「관리인이 결정한 룰을 위반하고 있어 개선의 전망이 없는 플레이어」 등에 자연재해를 발생 시킵니다.
<br>「실로 좋은 위치에 거대 운석」이든지 「운 나쁘고 지반침하」등이 일어나면, 너무 비비지 못하고 문제${AfterName} 는  약체화 합니다.
<br>「룰에 위반했다」라고 생각하기 전에, 「그 룰은 누구나가 읽을 수 있는 장소에 써 있을까?」를 확인합시다.
<br>제재를 더하는 것은 용이한 일입니다만, 정말로 관리인으로서의 입장에서 실시하고 있을까 생각합시다.
<br>제재를 더하지 않으면 안 될 정도 피해가 큰가 생각합시다. 다른${AfterName}에 폐를 끼치고 있다고 해도 단순한 게임인 것입니다
<br><FONT COLOR="red">제재의 존재는 극비로 합시다. </FONT>제재가 밝혀지면 다른 플레이어와의 신뢰 관계도 무너집니다.
<br><br>구상의 모형정원 개조자는, 이 기능을 추천 하고 있지 않습니다.
<br>문제가 있는 참가자와는 게시판등에서 대화로 해결해야 합니다. 경우에 따라서는 강제적으로 그만두게 받는 것도
<br>어쩔 수 없다고는 생각하고 있습니다만, 이런 내용으로 문제가 있는 참가자를 약체화 시키기는 어떨까라고 생각하고 있습니다.
<br>모든 참가자는 비록 부정한 일을 실시하고 있었다고 해도 게임에서는 공평해야 하다고 생각하고 있습니다.
<br>
<br>선박을 강제 퇴장는, 선택한${AfterName}에 있는 무소속 이외의 배를 모두 귀환시키는 처리입니다.
<br>구상 이노라 강림은, 선택한${AfterName}에 구상 이노라을 출현시킵니다.
<br>화재는, 불타는 지형을 선택했을 경우만 실행됩니다.
</DL>

<FORM name="lcForm" action="$HthisFile" method="POST">
<INPUT TYPE="hidden" VALUE="{${htmlEscape($GLOBALS['HdefaultPassword'])}}" NAME="Punish">
<B>제재를 더하는${AfterName} 는 ?</B><BR>
<SELECT NAME="ISLANDID">
$HislandList
</SELECT>
<INPUT TYPE="button" VALUE="맵을 연다" onclick="printIsland();">
<BR><BR>
<B>좌표는? (좌표 지정할 수 있는 제재에서만 유효)</B><BR>
<B>(</B><SELECT NAME=POINTX>
HEDOC_tempPunishPage_0;
  echo <<<HEDOC_tempPunishPage_1
</SELECT><B>, </B><SELECT NAME=POINTY>
HEDOC_tempPunishPage_1;
  echo <<<HEDOC_tempPunishPage_2
</SELECT><B>)</B><BR>
<BR>
<B>제재의 내용은?</B><BR>
<SELECT NAME="PUNISHID">
<OPTION VALUE="0">$punishName[0]
<OPTION VALUE="1">$punishName[1]
<OPTION VALUE="2">$punishName[2]
<OPTION VALUE="3">$punishName[3]
<OPTION VALUE="4">$punishName[4]
<OPTION VALUE="5">$punishName[5]
<OPTION VALUE="6">$punishName[6]
<OPTION VALUE="7">$punishName[7]
<OPTION VALUE="8">$punishName[8]
<OPTION VALUE="9">$punishName[9]
<OPTION VALUE="10">$punishName[10]
<OPTION VALUE="11">$punishName[11]
</SELECT><BR>
<BR>
<INPUT TYPE="submit" VALUE="제재를 더한다" NAME="PunishButton"><BR>
</FORM>
<SCRIPT Language="JavaScript">
<!--
function printIsland() {
	var iid;
	with (document.forms[0].elements[1]) {
		iid = options[selectedIndex].value;
	}
	window.open("$HthisFile?Sight=" + iid, "punish", "toolbar=0,location=0,directories=0,menubar=0,status=1,scrollbars=1,resizable=1,width=450,height=630");
}
//-->
</SCRIPT>
HEDOC_tempPunishPage_2;
  echo <<<HEDOC_tempPunishPage_3
<OPTION VALUE=$i SELECTED>$i\n
HEDOC_tempPunishPage_3;
  echo <<<HEDOC_tempPunishPage_4
<OPTION VALUE=$i>$i\n
HEDOC_tempPunishPage_4;
  echo <<<HEDOC_tempPunishPage_5
<OPTION VALUE=$i SELECTED>$i\n
HEDOC_tempPunishPage_5;
  echo <<<HEDOC_tempPunishPage_6
<OPTION VALUE=$i>$i\n
HEDOC_tempPunishPage_6;
  echo <<<HEDOC_tempPunishPage_7
<HR><TABLE BORDER><TR><TH $HbgTitleCell>${AfterName}명</TH><TH $HbgTitleCell>제재 내용</TH><TH $HbgTitleCell>좌표</TH></TR>
HEDOC_tempPunishPage_7;
  echo <<<HEDOC_tempPunishPage_8
<TR><TD $HbgInfoCell>{$island['name']}${AfterName}</TD><TD $HbgInfoCell>{$punishName[$obj['punish']]}</TD><TD $HbgInfoCell>({$obj['x']}, {$obj['y']})</TD></TR>
HEDOC_tempPunishPage_8;
  echo <<<HEDOC_tempPunishPage_9
</TABLE>
HEDOC_tempPunishPage_9;
}
}

if (!function_exists('lchangeMain')) {
function lchangeMain() {
extract($GLOBALS, EXTR_SKIP);
  /* Original CGI body retained for line-for-line retranslation reference:
sub lchangeMain {
	# 특수 패스워드
	if(checkPassword($HspecialPassword, $HdefaultPassword)) {
		
		# id로부터 도을 취득
		$HcurrentNumber = $HidToNumber{$HcurrentID};
		my($island) = $Hislands[$HcurrentNumber];
		if ($HlchangeMode) {

			# 지형의 값의 정합성을 체크
			if(!landCheck($HlchangeKIND, $HlchangeVALUE)) {
				tempBadValue();
				unlock();
				return;
			}

			{$island['land']}->[$HcommandX][$HcommandY] = $HlchangeKIND;
			{$island['landValue']}->[$HcommandX][$HcommandY] = $HlchangeVALUE;
			{$island['land2']}->[$HcommandX][$HcommandY] = $HlandSea;
			{$island['landValue2']}->[$HcommandX][$HcommandY] = 0;

			# 데이터 서두
			if(!writeIslandsFile($HcurrentID, 2)) {
				unlock();
				tempFailWrite();
				return;
			}
			unlock();
			# 변경 성공
			tempLchangeOK({$island['name']});
		}
		unlock();
		# 템플릿 출력
		tempLchangePage();
	} else {
		# 패스워드가 일치하지 않으면 탑 페이지로
		unlock();
		require('hako-top.php');
		# 템플릿 출력
		tempTopPage();
	}
}
  */
  return null;
}
}

if (!function_exists('tempLchangePage')) {
function tempLchangePage() {
extract($GLOBALS, EXTR_SKIP);
  echo <<<HEDOC_tempLchangePage_0
$HtempBack<hr>
<H1>참가${AfterName} 의  지형 데이터를 변경한다</H1>
기본적으로,<b>정상적으로 동작하지 않게 될 우려</b>가 있기 때문에<B>${AfterName} 의  데이터를 고쳐 쓰지 말아 주세요. </B><BR>
<b>반드시 고쳐 쓰기 전에 모형정원 데이터의 백업을 실시해 주세요. </b><BR>
버그등으로 지형이 이상해졌을 경우에게만 응급 처치로서 지형을 변경해 주세요. <BR>
지식이 없는 경우는 바다의 0이나 1(얕은 여울), 평지의 0, 황무지의 0의 어떤 것인가만을 사용해 주세요. <BR>
잘못해 변경을 했을 경우에 하등의 문제가 발생해도 일절의 책임은 취할 수 있습니다. <BR>
「지형」에 대해서 「지형의 값」이 적절한지 어떤지를 체크(부실)를 하고 있기 때문에, 주의해 주세요. <BR>
<TABLE><TR><TD>
HEDOC_tempLchangePage_0;
  echo <<<HEDOC_tempLchangePage_1
</TD><TD valign=top>
<FORM name="lcForm" action="$HthisFile" method="POST">
<INPUT TYPE="hidden" VALUE="{${htmlEscape($GLOBALS['HdefaultPassword'])}}" NAME="Lchange">
<B>지형을 변경하는${AfterName}</B>(ID=$HcurrentID)<BR>
<SELECT NAME="ISLANDID">
$HtargetList
</SELECT><BR>
<INPUT TYPE="submit" VALUE="맵을 연다" NAME="LchangeButtonM"><BR>
<BR><BR>
<B>좌표는?</B><BR>
<B>(</B><SELECT NAME=POINTX>
HEDOC_tempLchangePage_1;
  echo <<<HEDOC_tempLchangePage_2
</SELECT><B>, </B><SELECT NAME=POINTY>
HEDOC_tempLchangePage_2;
  echo <<<HEDOC_tempLchangePage_3
</SELECT><BR><BR>
<B>지형의 값은?</B><BR>
<INPUT TYPE="text" SIZE=6 NAME="LCHANGEVALUE" VALUE="$HlchangeVALUE"><BR>
(통상0-200)<BR>
(미사일 기지0-250)<BR>
(괴수1-3199)<BR>
(배계0-59999)<BR>
<BR>
<INPUT TYPE="submit" VALUE="변경한다" NAME="LchangeButton"><BR>
</FORM>
</TD></TR></TABLE>
<SCRIPT Language="JavaScript">
<!--
function ps(x, y) {
	document.lcForm.POINTX.options[x].selected = true;
	document.lcForm.POINTY.options[y].selected = true;
	return true;
}
//-->
</SCRIPT>
HEDOC_tempLchangePage_3;
  echo <<<HEDOC_tempLchangePage_4
지도 표시하기 위해서는,<br>한 번 ${AfterName}를 선택해 맵을 열어 주세요.
HEDOC_tempLchangePage_4;
  echo <<<HEDOC_tempLchangePage_5
<OPTION VALUE=$i SELECTED>$i\n
HEDOC_tempLchangePage_5;
  echo <<<HEDOC_tempLchangePage_6
<OPTION VALUE=$i>$i\n
HEDOC_tempLchangePage_6;
  echo <<<HEDOC_tempLchangePage_7
<OPTION VALUE=$i SELECTED>$i\n
HEDOC_tempLchangePage_7;
  echo <<<HEDOC_tempLchangePage_8
<OPTION VALUE=$i>$i\n
HEDOC_tempLchangePage_8;
  echo <<<HEDOC_tempLchangePage_9
</SELECT><B>)</B><BR><BR><B>지형은?</B><BR><SELECT NAME=\"LCHANGEKIND\">
HEDOC_tempLchangePage_9;
  echo <<<HEDOC_tempLchangePage_10
<OPTION VALUE=$lclandId[$i] SELECTED>$lcland[$i]\n
HEDOC_tempLchangePage_10;
  echo <<<HEDOC_tempLchangePage_11
<OPTION VALUE=$lclandId[$i]>$lcland[$i]\n
HEDOC_tempLchangePage_11;
}
}

if (!function_exists('tempLchangeOK')) {
function tempLchangeOK() {
extract($GLOBALS, EXTR_SKIP);
  echo <<<HEDOC_tempLchangeOK_0
${HtagBig_}$_[0]${AfterName} 의  지형을 변경했습니다${H_tagBig}<HR>
HEDOC_tempLchangeOK_0;
}
}

if (!function_exists('tempBadValue')) {
function tempBadValue() {
extract($GLOBALS, EXTR_SKIP);
  echo <<<HEDOC_tempBadValue_0
${HtagBig_}지형의 값이 이상한 것 같습니다${H_tagBig}$HtempBack
HEDOC_tempBadValue_0;
}
}

if (!function_exists('landCheck')) {
function landCheck() {
  $_args = func_get_args();
  extract($GLOBALS, EXTR_SKIP);
  $land = isset($_args[0]) ? $_args[0] : null;
  $lv = isset($_args[1]) ? $_args[1] : null;
  /* Original CGI body retained for line-for-line retranslation reference:
sub landCheck {
	my($land, $lv) = @_;
	return 0 if($lv < 0);
	if($land == $HlandSea) {
		return 0 if($lv > 200);
	} elsif($land == $HlandWaste) {
		return 0 if($lv > 200);
	} elsif($land == $HlandPlains) {
		return 0 if($lv != 0);
	} elsif($land == $HlandTown) {
		return 0 if(($lv < 1) || ($lv > 200));
	} elsif($land == $HlandForest) {
		return 0 if(($lv < 1) || ($lv > 200));
	} elsif($land == $HlandFarm) {
		return 0 if(($lv < 10) || ($lv > 50));
	} elsif($land == $HlandFactory) {
		return 0 if(($lv < 30) || ($lv > 100));
#		return if(($lv - 30) % 10 != 0);
	} elsif($land == $HlandBase) {
		return 0 if(($lv < 0) || ($lv > $HmaxExpPoint));
	} elsif($land == $HlandDefence) {
		return 0 if($lv > 200);
	} elsif($land == $HlandMountain) {
		return 0 if(($lv < 0) || ($lv > 200));
#		return if($lv % 5 != 0);
	} elsif($land == $HlandMonster) {
		return 0 if($lv > 3199);
	} elsif($land == $HlandSbase) {
		return 0 if(($lv < 0) || ($lv > $HmaxExpPoint));
	} elsif($land == $HlandOil) {
		return 0 if($lv > 200);
	} elsif($land == $HlandMonument) {
		return 0 if($lv > 200);
	} elsif($land == $HlandHaribote) {
		return 0 if($lv > 3199);
	} elsif($land == $HlandOsen) {
		return 0 if($lv > 9);
	} elsif($land == $HlandSlum) {
		return 0 if($lv > 200);
	} elsif($land == $HlandTower) {
		return 0 if(($lv < 0) || ($lv > 200));
#		return if($lv % 10 != 0);
	} elsif($land == $HlandSeisei) {
		return 0 if($lv > 30);
	} elsif($land == $HlandBank) {
		return 0 if($lv > 100);
	} elsif($land == $HlandSeisei) {
		return 0 if($lv > 30);
	} elsif($land == $HlandTrump) {
		return 0 if($lv > 14);
	} elsif($land >= $HlandPirate) {
		return 0 if($lv > 59999);
	} else {
		return 0 if($lv > 200);
	}
	return 1;
}
  */
  return 0;
}
}

if (!function_exists('preDeleteMain')) {
function preDeleteMain() {
extract($GLOBALS, EXTR_SKIP);
  /* Original CGI body retained for line-for-line retranslation reference:
sub preDeleteMain {
	if(checkPassword($HspecialPassword, $HdefaultPassword)) {
		# 특수 패스워드?
		preDeleteMainP(1) if($HpreDeleteMode);
		unlock();
		# 템플릿 출력
		tempPdeleteMain();
	} else {
		# 패스워드가 일치하지 않으면 탑 페이지로
		require('hako-top.php');
		unlock();
		# 템플릿 출력
		tempTopPage();
	}
}
  */
  return null;
}
}

if (!function_exists('preDeleteMainP')) {
function preDeleteMainP() {
  $_args = func_get_args();
  extract($GLOBALS, EXTR_SKIP);
  $mode = isset($_args[0]) ? $_args[0] : null;
  /* Original CGI body retained for line-for-line retranslation reference:
sub preDeleteMainP {
	my($mode) = @_;
#	HdebugOut("preDeleteMainP　$mode");
	my @newID = ();
	my $flag = 0;
	foreach (@HpreDeleteID) {
		if(!(defined $HidToNumber{$_})) {
		} elsif($_ == $HcurrentID) {
			$flag = 1;
		} else {
			push(@newID, $_);
		}
	}
	if(($HcurrentID > 90) && (!$flag)){
		# Battle Field로 추가 모드 때는 무효
		tempPreDelete2($Hislands[$HidToNumber{$HcurrentID}]->{'name'}) if($mode);
	}else{
		@HpreDeleteID = @newID;
		push(@HpreDeleteID, $HcurrentID) if(!$flag);
		# 데이터 서두
		if($mode){
			writeIslandsFile($HcurrentID);
			if($flag) {
				tempPreDeleteEnd($Hislands[$HidToNumber{$HcurrentID}]->{'name'});
			} else {
				tempPreDelete($Hislands[$HidToNumber{$HcurrentID}]->{'name'});
			}
		}
	}
}
  */
  return null;
}
}

if (!function_exists('tempPdeleteMain')) {
function tempPdeleteMain() {
extract($GLOBALS, EXTR_SKIP);
  echo <<<HEDOC_tempPdeleteMain_0
<CENTER>$HtempBack</CENTER>
<H1>참가${AfterName}를 관리인이 보관하는 걸로  지정 한다</H1>

<DL>
<DT>·보관하는 ${AfterName} 는 , 턴 처리(수입 처리·커멘드 처리·성장·재해등 )되지 않게 됩니다.</DT>
<DT>·상관계는 처리되고, 다른 ${AfterName} 으로부터의 공격은 모두 받아들여 버립니다. </DT>
<DT>·Battle Field는, 보관 설정으로 할 수 없습니다. </DT>
<!--
<DT>·보관 ${AfterName} 가 「방폐」혹은 「강제 삭제」되었을 경우, 처리의 형편상
보관의 ID데이터가 다음의 보관 처리를 실시할 때까지 그대로 남습니다만, 이용자(관리인)는 고려할 필요는 없습니다.</DT>
-->
</DT>

</DL>

<FORM name="pdForm" action="$HthisFile" method="POST">
<INPUT TYPE="hidden" VALUE="{${htmlEscape($GLOBALS['HdefaultPassword'])}}" NAME="Pdelete">
<B>관리인이 보관하는 ${AfterName} 는 ?</B><BR>
<SELECT NAME="ISLANDID">
$HislandList
</SELECT>
<BR>
<INPUT TYPE="submit" VALUE="설정·해제" NAME="PdeleteButton"><BR>
</FORM>
<TABLE BORDER><TR><TH>보관 안의${AfterName}</TH></TR>
HEDOC_tempPdeleteMain_0;
  echo <<<HEDOC_tempPdeleteMain_1
<TR><TH>관리인 보관하는 ${AfterName} 는  없습니다!</TH></TR>
HEDOC_tempPdeleteMain_1;
  echo <<<HEDOC_tempPdeleteMain_2
<TR><TD>$name${AfterName}</TD></TR>
HEDOC_tempPdeleteMain_2;
  echo <<<HEDOC_tempPdeleteMain_3
</TABLE>
HEDOC_tempPdeleteMain_3;
}
}

if (!function_exists('tempPreDelete')) {
function tempPreDelete() {
extract($GLOBALS, EXTR_SKIP);
  echo <<<HEDOC_tempPreDelete_0
${HtagBig_}$_[0]${AfterName}(을)를 관리인이 보관으로 했습니다${H_tagBig}
<HR>
HEDOC_tempPreDelete_0;
}
}

if (!function_exists('tempPreDelete2')) {
function tempPreDelete2() {
extract($GLOBALS, EXTR_SKIP);
  echo <<<HEDOC_tempPreDelete2_0
${HtagBig_}$_[0]${AfterName}(은)는 관리인이 보관 할 수 없습니다${H_tagBig}
<HR>
HEDOC_tempPreDelete2_0;
}
}

if (!function_exists('tempPreDeleteEnd')) {
function tempPreDeleteEnd() {
  $_args = func_get_args();
  extract($GLOBALS, EXTR_SKIP);
  $name = isset($_args[0]) ? $_args[0] : null;
  echo <<<HEDOC_tempPreDeleteEnd_0
${HtagBig_}$_[0]${AfterName} 의 관리인이 보관 해제했습니다${H_tagBig}
<HR>
HEDOC_tempPreDeleteEnd_0;
}
}

if (!function_exists('ichangeMain')) {
function ichangeMain() {
extract($GLOBALS, EXTR_SKIP);
  /* Original CGI body retained for line-for-line retranslation reference:
sub ichangeMain {
	if(checkPassword($HspecialPassword, $HdefaultPassword)) {
		# 특수 패스워드
		ichangeMainP() if($HichangeMode);
		unlock();
		# 템플릿 출력
		tempIchangePage();
	} else {
		# 패스워드가 일치하지 않으면 탑 페이지로
		require('hako-top.php');
		unlock();
		# 템플릿 출력
		tempTopPage();
	}
}
  */
  return null;
}
}

if (!function_exists('ichangeMainP')) {
function ichangeMainP() {
extract($GLOBALS, EXTR_SKIP);
  /* Original CGI body retained for line-for-line retranslation reference:
sub ichangeMainP {
	$HcurrentNumber = $HidToNumber{$HcurrentID};
	my($island) = $Hislands[$HcurrentNumber];
	{$island['money']} = int($Hicmoney);
	{$island['food']} = int($Hicfood);
	{$island['ally']} = int($Hically);
	{$island['weapon']} = int($Hicweapon);
	{$island['evil']} = int($Hicevil);
	if($Hicspace == 1){
		my($prize) = {$island['prize']};
		$prize =~ /([0-9]*),([0-9]*),(.*)/;
		my($flags,$monsters,$turns) = ($1,$2,$3);
		$flags |= 512 if(!($flags & 512));
		{$island['prize']} = "$flags,$monsters,$turns";
	}
	if({$island['money']} > $MaxMoney){
		{$island['money']} = $MaxMoney;
	}
	if({$island['food']} > $MaxFood){
		{$island['food']} = $MaxFood;
	}
	if({$island['weapon']} > $MaxSigen){
		{$island['weapon']} = $MaxSigen;
	}
	# 데이터 서두
	if(!writeIslandsFile($HcurrentID, 1)) {
		unlock();
		tempFailWrite();
		return;
	}
}
  */
  return null;
}
}

if (!function_exists('tempIchangePage')) {
function tempIchangePage() {
  $_args = func_get_args();
  extract($GLOBALS, EXTR_SKIP);
  $mode = isset($_args[0]) ? $_args[0] : null;
  echo <<<HEDOC_tempIchangePage_0
<span class='attention'>※　반드시 백업을 해  주세요. 데이터를 직접 수정하므로 위험합니다!</span>
<TABLE BORDER>
<TR>
<TH $HbgTitleCell>${HtagTH_}순위${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}${AfterName}${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}자금${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}식량${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}병기${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}유엔등${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}우주상${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}소속${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}변경${H_tagTH}</TH>
</TR>
HEDOC_tempIchangePage_0;
  echo <<<HEDOC_tempIchangePage_1
<TR>
<FORM name="IchForm" action="$HthisFile" method="POST">
<INPUT TYPE="hidden" VALUE="{${htmlEscape($GLOBALS['HdefaultPassword'])}}" NAME="Ichange">
<INPUT TYPE="hidden" VALUE="$id" NAME="ICID">
<TD $HbgNumberCell>${HtagNumber_}$j${H_tagNumber}($zyuni)</TD>
<TD $HbgNameCell>${HtagTH_}${name}${AfterName}${H_tagTH}(${id})</TD>
<TD><INPUT TYPE="text" SIZE=5 NAME="ICMONEY" VALUE="$money">$HunitMoney</TD>
<TD><INPUT TYPE="text" SIZE=5 NAME="ICFOOD" VALUE="$food">$HunitFood</TD>
<TD><INPUT TYPE="text" SIZE=4 NAME="ICWEAPON" VALUE="$weapon">$HunitWeapon</TD>
<TD><INPUT TYPE="text" SIZE=5 NAME="ICEVIL" VALUE="$evil"></TD>
<TD><INPUT TYPE="checkbox"    NAME="ICSPACE" $space></TD>
<TD><SELECT NAME="ICALLY">$select_list</SELECT><b>$Hallymark[$ally]</b></TD>
<TD><INPUT TYPE="submit" VALUE="변경" NAME="IchangeButton"></TD>
</FORM>
</TR>
HEDOC_tempIchangePage_1;
  echo <<<HEDOC_tempIchangePage_2
</TABLE>
1${AfterName} 밖에  수정 밖에 할 수 없습니다<br>
유엔등은, 미사일 기지가 없는${AfterName}의  값을 0으로 하면, 유엔 보호화가 됩니다. <br>
또, 10000이상으로 하면 황금기가 됩니다. <br>
우주상은, 주기 밖에  할 수 없습니다.<br>
HEDOC_tempIchangePage_2;
}
}

if (!function_exists('getUserAgent')) {
function getUserAgent() {
extract($GLOBALS, EXTR_SKIP);
  /* Original CGI body retained for line-for-line retranslation reference:
sub getUserAgent {
	$agent2 = $agent = $ENV{'HTTP_USER_AGENT'};
	if ($agent =~ /AOL/) { $agent = 'AOL'; }
	elsif ($agent =~ /Opera/i) {
		if($agent =~ /7./){
			$agent = 'Opera7';
		}elsif($agent =~ /6./){
			$agent = 'Opera6';
		}else{
			$agent = 'Opera';
		}
	}elsif ($agent =~ /MSIE 3/i) { $agent = 'Internet Explorer 3'; }
	elsif ($agent =~ /MSIE 4/i) { $agent = 'Internet Explorer 4'; }
	elsif ($agent =~ /MSIE 5/i) { $agent = 'Internet Explorer 5'; }
	elsif ($agent =~ /MSIE 6/i) { $agent = 'Internet Explorer 6'; }
	elsif ($agent =~ /MSIE 7/i) { $agent = 'Internet Explorer 7'; }
	elsif ($agent =~ /Mozilla\/2/i) { $agent = 'Netscape 2'; }
	elsif ($agent =~ /Mozilla\/3/i) { $agent = 'Netscape 3'; }
	elsif ($agent =~ /Mozilla\/4/i) { $agent = 'Netscape 4'; }
	elsif ($agent =~ /Netscape ?6/i) { $agent = 'Netscape 6'; }
	elsif ($agent =~ /Netscape\/7/i) { $agent = 'Netscape 7'; }
	elsif ($agent =~ /Mozilla\/5/i) { $agent = 'Mozilla'; }
	elsif ($agent =~ /Lynx/i) { $agent = 'Lynx'; }

	if ($agent2 =~ /Wind?o?w?s? ?95/i) { $os = 'Win95'; }
	elsif ($agent2 =~ /Wind?o?w?s? ?9x/i) { $os = 'WinMe'; }
	elsif ($agent2 =~ /Wind?o?w?s? ?98/i) { $os = 'Win98'; }
	elsif ($agent2 =~ /Wind?o?w?s? ?NT ?5.2/i) { $os = 'Win2003'; }
	elsif ($agent2 =~ /Wind?o?w?s? ?NT ?5.1/i) { $os = 'WinXP'; }
	elsif ($agent2 =~ /Wind?o?w?s? ?NT ?5.0/i) { $os = 'Win2000'; }
	elsif ($agent2 =~ /Wind?o?w?s? ?NT/i) { $os = 'WinNT'; }
	elsif ($agent2 =~ /Wind?o?w?s? ?CE/i) { $os = 'WinCE'; }
	elsif ($agent2 =~ /Mac/i) { $os = 'Mac'; }
	elsif ($agent2 =~ /X/ || $agent2 =~ /Sun/i || $agent2 =~ /Linux/i || $agent2 =~ /HP-UX/i || $agent2 =~ /BSD/i) { $os = 'UNIX'; }
	return ($agent,$os);
}
  */
  return null;
}
}

if (!function_exists('setupValue')) {
function setupValue() {
extract($GLOBALS, EXTR_SKIP);
  echo <<<HEDOC_setupValue_0
<meta HTTP-EQUIV=\"refresh\" CONTENT=\"0; URL=setup.html\">
HEDOC_setupValue_0;
  echo <<<HEDOC_setupValue_1
<meta HTTP-EQUIV=\"refresh\" CONTENT=\"0; URL=${efileDir}/setup.html\">
HEDOC_setupValue_1;
}
}

if (!function_exists('timeToString')) {
function timeToString() {
extract($GLOBALS, EXTR_SKIP);
  /* Original CGI body retained for line-for-line retranslation reference:
sub timeToString {
	my($sec, $min, $hour, $date, $mon, $year, $day, $yday, $dummy) =
	localtime($_[0]);
	$mon++;
	$year += 1900;
	return "${mon}월 ${date}일 ${hour}시 ${min}분";
}
  */
  return null;
}
}

if (!function_exists('logHistory')) {
function logHistory() {
extract($GLOBALS, EXTR_SKIP);
  /* Original CGI body retained for line-for-line retranslation reference:
sub logHistory {
	open(HOUT, ">>${HlogdirName}/hakojima.his");
	print HOUT "$HislandTurn,$_[0]\n";
	close(HOUT);
}
  */
  return null;
}
}

if (!function_exists('logDiscover')) {
function logDiscover() {
  $_args = func_get_args();
  extract($GLOBALS, EXTR_SKIP);
  $name = isset($_args[0]) ? $_args[0] : null;
  /* Original CGI body retained for line-for-line retranslation reference:
sub logDiscover {
	my($name) = @_;
	logHistory("${HtagName_}${name}${AfterName} ${H_tagName}가 발견된다.$addr");
}
  */
  return null;
}
}

if (!function_exists('logChangeName')) {
function logChangeName() {
  $_args = func_get_args();
  extract($GLOBALS, EXTR_SKIP);
  $name1 = isset($_args[0]) ? $_args[0] : null;
  $name2 = isset($_args[1]) ? $_args[1] : null;
  /* Original CGI body retained for line-for-line retranslation reference:
sub logChangeName {
	my($name1, $name2) = @_;
	logHistory("${HtagName_}${name1}${AfterName}${H_tagName}、명칭을${HtagName_}${name2}${AfterName}${H_tagName} 으로 변경한다.$addr");
}
  */
  return null;
}
}

if (!function_exists('logDeleteIsland')) {
function logDeleteIsland() {
  $_args = func_get_args();
  extract($GLOBALS, EXTR_SKIP);
  $id = isset($_args[0]) ? $_args[0] : null;
  $name = isset($_args[1]) ? $_args[1] : null;
  /* Original CGI body retained for line-for-line retranslation reference:
sub logDeleteIsland {
	my($id, $name) = @_;
#	logHistory("${HtagName_}${name}도${H_tagName}、<B>관리인 권한에 의해</B><B><FONT COLOR=\"ff0000\">퇴장</FONT></B>이 된다.");
	logHistory("${HtagName_}${name}${AfterName} ${H_tagName}에, 돌연<B>천벌이 내리고</B>순식간에<B><FONT COLOR=\"ff0000\">바다에 침몰해</FONT></B>흔적도 없어졌습니다.");
}
  */
  return null;
}
}

if (!function_exists('tempDeleteIsland')) {
function tempDeleteIsland() {
  $_args = func_get_args();
  extract($GLOBALS, EXTR_SKIP);
  $name = isset($_args[0]) ? $_args[0] : null;
  echo <<<HEDOC_tempDeleteIsland_0
${HtagBig_}${name}${AfterName}(을)를 강제 삭제했습니다.${H_tagBig}$HtempBack
HEDOC_tempDeleteIsland_0;
}
}

if (!function_exists('tempNewIslandFull')) {
function tempNewIslandFull() {
extract($GLOBALS, EXTR_SKIP);
  echo <<<HEDOC_tempNewIslandFull_0
${HtagBig_}죄송합니다,${AfterName}이 가득해 등록할 수 없습니다!${H_tagBig}$HtempBack
HEDOC_tempNewIslandFull_0;
}
}

if (!function_exists('tempNewIslandNoName')) {
function tempNewIslandNoName() {
extract($GLOBALS, EXTR_SKIP);
  echo <<<HEDOC_tempNewIslandNoName_0
${HtagBig_}${AfterName}에 붙이는 이름이 필요합니다.${H_tagBig}$HtempBack
HEDOC_tempNewIslandNoName_0;
}
}

if (!function_exists('tempNewIslandBadName')) {
function tempNewIslandBadName() {
extract($GLOBALS, EXTR_SKIP);
  echo <<<HEDOC_tempNewIslandBadName_0
${HtagBig_}',?()<>\"\'\$'라든지 들어가기도 하고, 「무인${AfterName}」든지 말한 이상한 이름은 그만둡시다∼<BR>
또, 구상독자 사양에 의해 「익명${AfterName}」는 사용 불가가 되어 있습니다.${H_tagBig}$HtempBack
HEDOC_tempNewIslandBadName_0;
}
}

if (!function_exists('tempNewIslandAlready')) {
function tempNewIslandAlready() {
extract($GLOBALS, EXTR_SKIP);
  echo <<<HEDOC_tempNewIslandAlready_0
${HtagBig_}그${AfterName}은(는) 이미 발견되어 있습니다.${H_tagBig}$HtempBack
HEDOC_tempNewIslandAlready_0;
}
}

if (!function_exists('tempNewIslandId')) {
function tempNewIslandId() {
extract($GLOBALS, EXTR_SKIP);
  echo <<<HEDOC_tempNewIslandId_0
${HtagBig_}「구상의 모형정원」의 사양에 의해 더 이상의 신규 참가는 할 수 없습니다.${H_tagBig}$HtempBack
HEDOC_tempNewIslandId_0;
}
}

if (!function_exists('tempNewIslandIdB')) {
function tempNewIslandIdB() {
extract($GLOBALS, EXTR_SKIP);
  echo <<<HEDOC_tempNewIslandIdB_0
${HtagBig_}「구상의 모형정원」의 사양에 의해 더 이상의Battle Field는 작성할 수 없습니다.${H_tagBig}$HtempBack
HEDOC_tempNewIslandIdB_0;
}
}

if (!function_exists('tempNotNewIsland')) {
function tempNotNewIsland() {
extract($GLOBALS, EXTR_SKIP);
  echo <<<HEDOC_tempNotNewIsland_0
${HtagBig_}해역에 빈 곳이 없기 때문에, 더 이상의 작성은 할 수 없습니다.${H_tagBig}$HtempBack
HEDOC_tempNotNewIsland_0;
}
}

if (!function_exists('tempNewIslandNoPassword')) {
function tempNewIslandNoPassword() {
extract($GLOBALS, EXTR_SKIP);
  echo <<<HEDOC_tempNewIslandNoPassword_0
${HtagBig_}패스워드가 필요합니다.${H_tagBig}$HtempBack
HEDOC_tempNewIslandNoPassword_0;
}
}

if (!function_exists('tempNewIslandHead')) {
function tempNewIslandHead() {
  $_args = func_get_args();
  extract($GLOBALS, EXTR_SKIP);
  $profileId = isset($_args[0]) ? $_args[0] : '';
  echo <<<HEDOC_tempNewIslandHead_0
<CENTER>
${HtagBig_}${AfterName}를 발견했습니다!${H_tagBig}<BR>
${HtagBig_}${HtagName_}「${HcurrentName}${AfterName}」${H_tagName}라고 명명합니다.${H_tagBig}<BR>
${HtagBig_}추가적인 <a href="${HbaseDir}/profile.php?profile=${profileId}&mode=edit">프로필 등록</a>을 부탁 드립니다.(임의/선택사항)${H_tagBig}　$HtempBack<BR>
</CENTER>
HEDOC_tempNewIslandHead_0;
}
}

if (!function_exists('tempChangeNothing')) {
function tempChangeNothing() {
extract($GLOBALS, EXTR_SKIP);
  echo <<<HEDOC_tempChangeNothing_0
${HtagBig_}이름 혹은 패스워드가 비어 있습니다${H_tagBig}$HtempBack
HEDOC_tempChangeNothing_0;
}
}

if (!function_exists('tempChangeNoMoney')) {
function tempChangeNoMoney() {
extract($GLOBALS, EXTR_SKIP);
  echo <<<HEDOC_tempChangeNoMoney_0
${HtagBig_}자금부족으로 변경할 수 없습니다${H_tagBig}$HtempBack
HEDOC_tempChangeNoMoney_0;
}
}

if (!function_exists('tempChange')) {
function tempChange() {
extract($GLOBALS, EXTR_SKIP);
  echo <<<HEDOC_tempChange_0
${HtagBig_}변경 완료했습니다${H_tagBig}$HtempBack
HEDOC_tempChange_0;
}
}

if (!function_exists('logPresent')) {
function logPresent() {
  $_args = func_get_args();
  extract($GLOBALS, EXTR_SKIP);
  $id = isset($_args[0]) ? $_args[0] : null;
  $name = isset($_args[1]) ? $_args[1] : null;
  $log = isset($_args[2]) ? $_args[2] : null;
  /* Original CGI body retained for line-for-line retranslation reference:
sub logPresent {
	my($id, $name, $log) = @_;
	logHistory("${HtagName_}${name}${AfterName}${H_tagName}$log") if ($log ne '');
}
  */
  return null;
}
}
?>
