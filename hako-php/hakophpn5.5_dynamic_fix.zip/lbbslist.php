<?php
if (!isset($_hako_fh)) { $_hako_fh = array(); }

if (!isset($GLOBALS['_hako_req_start'])) { $GLOBALS['_hako_req_start'] = microtime(true); }
if (!isset($GLOBALS['_hako_req_ru_start'])) { $GLOBALS['_hako_req_ru_start'] = function_exists('getrusage') ? getrusage() : null; }
if (!function_exists('hako_cpu_times')) {
function hako_cpu_times() {
    $startRu = isset($GLOBALS['_hako_req_ru_start']) ? $GLOBALS['_hako_req_ru_start'] : null;
    if (function_exists('getrusage') && is_array($startRu)) {
        $r = getrusage();
        $u0 = (isset($startRu['ru_utime.tv_sec']) ? $startRu['ru_utime.tv_sec'] : 0) + (isset($startRu['ru_utime.tv_usec']) ? $startRu['ru_utime.tv_usec'] : 0) / 1000000;
        $s0 = (isset($startRu['ru_stime.tv_sec']) ? $startRu['ru_stime.tv_sec'] : 0) + (isset($startRu['ru_stime.tv_usec']) ? $startRu['ru_stime.tv_usec'] : 0) / 1000000;
        $u1 = (isset($r['ru_utime.tv_sec']) ? $r['ru_utime.tv_sec'] : 0) + (isset($r['ru_utime.tv_usec']) ? $r['ru_utime.tv_usec'] : 0) / 1000000;
        $s1 = (isset($r['ru_stime.tv_sec']) ? $r['ru_stime.tv_sec'] : 0) + (isset($r['ru_stime.tv_usec']) ? $r['ru_stime.tv_usec'] : 0) / 1000000;
        $uti = max(0, $u1 - $u0);
        $sti = max(0, $s1 - $s0);
        return array(round($uti + $sti, 4), round($uti, 4), round($sti, 4));
    }
    $start = isset($GLOBALS['_hako_req_start']) ? $GLOBALS['_hako_req_start'] : (isset($_SERVER['REQUEST_TIME_FLOAT']) ? $_SERVER['REQUEST_TIME_FLOAT'] : microtime(true));
    $elapsed = microtime(true) - $start;
    if ($elapsed < 0) { $elapsed = 0; }
    return array(round($elapsed, 4), round($elapsed, 4), 0);
}
}
if (!function_exists('hako_open')) {
  function hako_open($name, $spec) { global $_hako_fh;
$mode='r'; $path=$spec; if (substr($path,0,2)==='>>') { $mode='a'; $path=substr($path,2); } elseif (substr($path,0,1)==='>') { $mode='w'; $path=substr($path,1); } elseif (substr($path,0,1)==='<') { $mode='r'; $path=substr($path,1); } $_hako_fh[$name]=@fopen($path,$mode); return $_hako_fh[$name]; }
  function hako_close($name) { global $_hako_fh;
if (isset($_hako_fh[$name]) && is_resource($_hako_fh[$name])) fclose($_hako_fh[$name]); }
  function hako_getline($name) { global $_hako_fh;
if (!isset($_hako_fh[$name]) || !$_hako_fh[$name]) return false; return fgets($_hako_fh[$name]); }
  function hako_write($name,$data) { global $_hako_fh;
if (!isset($_hako_fh[$name]) || !$_hako_fh[$name]) return false; return fwrite($_hako_fh[$name],$data); }
}
?>
<?php
// Function-unit retranslation from lbbslist.php.
require_once './hako-init.php';
require_once './hako-io.php';
$bye = "$HbaseDir/hako-main.php";
$kyoutyouturn = 30;
$viewOrder = 1;
$title = '관광자 통신 일람';
$headKill = '<h2 class=head2>모형정원 제도 관광자 통신 일람표</h2>';
$HbgTitleCell   = 'class=TitleCell';
$HbgSubTCell    = 'class=SubTCell';
$HbgLbbsCell    = 'class=LbbsCell';
$HbgCommentCell = 'class=TitleCell';
$HtagCo_ = '<span class="head">';
$H_tagCo = '</span>';
$HtagLbbsSS_ = '<span class="lbbsSS">';
$H_tagLbbsSS = '</span>';
$HtagLbbsOW_ = '<span class="lbbsOW">';
$H_tagLbbsOW = '</span>';
$HtagNumber_ = '<span class="number">';
$H_tagNumber = '</span>';

if (!function_exists('readIslandsFile')) {
function readIslandsFile() {
extract($GLOBALS, EXTR_SKIP);
  /* Original CGI body retained for line-for-line retranslation reference:
sub readIslandsFile {
	# 데이터 파일을 연다?
	if(!open(IN, "${HdirName}/hakojima.dat")) {
		rename("${HdirName}/hakojima.tmp", "${HdirName}/hakojima.dat");
		return 0 if(!open(IN, "${HdirName}/hakojima.dat"));
	}
	# 각 파라미터의 읽어들여?
	$HislandTurn	= int(<IN>);	# 턴수
	<IN>;	# 최종 갱신 시간(사용하지 않는 값이므로 읽어 날린다)
	$HislandNumber	= int(<IN>);	# 도의 총수
	<IN>;	# 다음에 할당하는 ID(사용하지 않는 값이므로 읽어 날린다)

	# 도의 읽어들여
	my($i, $id);
	for($i = 0; $i < $HislandNumber; $i++) {
		$Hislands[$i] = &readIsland();
		$HidToNumber{$Hislands[$i]->{'id'}} = $i;
	}
	# 파일을 닫는다
	close(IN);
	readsubmap(0);#우주 맵 독입
	readsubmap(1);#해역 맵 독입
	return 1;
}
  */
  return 0;
}
}

if (!function_exists('readIsland')) {
function readIsland() {
extract($GLOBALS, EXTR_SKIP);
  /* Original CGI body retained for line-for-line retranslation reference:
sub readIsland {
	my($id, $name, $comment, @comments,$order, $i, $line, @lbbs);
	$name = <IN>;
	$name =~ /(.*),(.*)/;	# 도의 이름
	$name = $1;
	$id = int(<IN>); # ID번호
		<IN>;  # 사용자명
		<IN>;  # 수상
		<IN>;  # 연속 자금융통수
	$comment = <IN>;       # 코멘트?
	chomp($comment);
	my @comments = split(/<>/, $comment);
	# 파일 포인터를 진행시킬 뿐이므로 name, ID 이외는 값을 격납하지 않는다
	for($i = 6; $i < 27; $i++) {
		<IN>;
	}
	$order = <IN>;# 명령
	for($i = 28; $i < 35; $i++) {
		<IN>;
	}
	if(!open(IIN, "${HdirName}/island.$id")) {
		rename("${HdirName}/islandtmp.$id", "${HdirName}/island.$id");
		exit(0) if(!open(IIN, "${HdirName}/island.$id"));
	}
	for($i = 0; $i < $HislandSize; $i++) {
		$line = <IIN>;
	}
	for($i = 0; $i < $HugMax; $i++) {
		$line = <IIN>;
	}
	<IIN>;
	<IIN>;
	<IIN>;
	<IIN>;
	<IIN>;
	for($i = 0; $i < $HcommandMax; $i++) {
		$line = <IIN>;
	}

	#  로컬 게시판
	for($i = 0; $i < $HlbbsMax; $i++) {
		$line = <IIN>;
		chomp($line);
		$lbbs[$i] = $line;
	}

	close(IIN);

	return {
	'name' => $name,
	'id' => $id,
	'comment' => $comments[0],
	'order' => $order,
	'lbbs' => \@lbbs
	};
}
  */
  return array();
}
}

if (!function_exists('readsubmap')) {
function readsubmap() {
  $_args = func_get_args();
  extract($GLOBALS, EXTR_SKIP);
  $num = isset($_args[0]) ? $_args[0] : null;
  /* Original CGI body retained for line-for-line retranslation reference:
sub readsubmap {
	my($num) = @_;
	# 우주, 해역 맵 읽어들여?
	if(open(IIN, "${HdirName}/submap.$num")){
		my($i, $line, @lbbs);
		if($num == 0){
			#우주
			for($i = 0; $i < $HislandSize; $i++) {
				$line = <IIN>;
			}
		}else{
			#해역
			for($i = 0; $i < $HoceanSize; $i++) {
				$line = <IIN>;
			}
		}
		<IIN>;
		<IIN>;
		<IIN>;
		<IIN>;
		<IIN>;
		<IIN>;
		<IIN>;
		<IIN>;
		<IIN>;
		<IIN>;
		<IIN>;
		<IIN>;
		# 로컬 게시판?
		for($i = 0; $i < $HlbbsMax; $i++) {
			$line = <IIN>;
			chomp($line);
			$lbbs[$i] = $line;
		}
		if($num == 0){
			#우주
			$Hspace = {'lbbs' => \@lbbs};
		}else{
			#해역
			$Hocean = {'lbbs' => \@lbbs};
		}
		close(IIN);
	}
}
  */
  return array();
}
}

if (!function_exists('out')) {
function out() {
extract($GLOBALS, EXTR_SKIP);
  /* Original CGI body retained for line-for-line retranslation reference:
sub out {
  print STDOUT ($_[0]);
}
  */
  return null;
}
}

if (!function_exists('cgiInput')) {
function cgiInput() {
extract($GLOBALS, EXTR_SKIP);
  /* Original CGI body retained for line-for-line retranslation reference:
sub cgiInput {
	my($line, $getLine);

	# 입력을 받아 일본어 코드를 EUC에
	$line = <>;
	$line =~ tr/+/ /;
	$line =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
	$line = ($line);
	$line =~ s/[\,\r]//g;

	# GET의 녀석도 받는다
	$getLine = $ENV{'QUERY_STRING'};

	if($getLine =~ /pass=([^\&]*)/) {
		# 최초의 기동
		$HdefaultPassword = $1;
		$HdecodePassword = crypt($HdefaultPassword, 'ma')
	}
	if($getLine =~ /id=([^\&]*)/) {
		$HcurrentID = $1;
	}
	if (-e $HpasswordFile) {
		# 패스워드 파일이 있다
		open(PIN, "<$HpasswordFile") || die $!;
		chomp($HmasterPassword = <PIN>); #  master password를 읽어들인다
		close(PIN);
	}
}
  */
  return null;
}
}

if (!function_exists('htmlHeader')) {
function htmlHeader() {
extract($GLOBALS, EXTR_SKIP);
  echo <<<HEDOC_htmlHeader_0
<HTML><HEAD><TITLE>$title</TITLE>
<BASE HREF="$imageDir/">
<link rel="stylesheet" type="text/css" href="$skinName">
</HEAD>
<DIV ID='BodySpecial'><DIV ID='LinkHead'></DIV><DIV ID='LinkTop'>
<BODY>
<A HREF="$bye">[돌아온다]</A></DIV>
HEDOC_htmlHeader_0;
}
}

if (!function_exists('htmlFooter')) {
function htmlFooter() {
extract($GLOBALS, EXTR_SKIP);
  echo <<<HEDOC_htmlFooter_0
<P>${AfterName} 의  이름을 클릭하면, 관광할 수가 있습니다.$orderTxt</P>
<DIV align="right">
<SMALL>CPU($cpu) : user($uti) system($sti)</SMALL>
</DIV></DIV></BODY></HTML>
HEDOC_htmlFooter_0;
}
}

if (!function_exists('htmlError')) {
function htmlError() {
extract($GLOBALS, EXTR_SKIP);
  echo <<<HEDOC_htmlError_0
${h2} 에러가 발생했습니다.</H2>\n
HEDOC_htmlError_0;
}
}

if (!function_exists('tempLbbsContents')) {
function tempLbbsContents() {
  $_args = func_get_args();
  extract($GLOBALS, EXTR_SKIP);
  $number = isset($_args[0]) ? $_args[0] : null;
  $mode = isset($_args[1]) ? $_args[1] : null;
  echo <<<HEDOC_tempLbbsContents_0
<TR><TD $HbgTitleCell><a name=$id><b>섬이름</b></a></TD>
<TD $HbgTitleCell>
<A HREF="$HthisFile?${link}" TARGET=_blank>
<b>$name</b></A>$order
</TD></TR>
<TR><TD $HbgTitleCell><b>코멘트</b></TD>
<TD $HbgTitleCell>${HtagCo_}$comment${H_tagCo}
</TD></TR>
HEDOC_tempLbbsContents_0;
  echo <<<HEDOC_tempLbbsContents_1
</TD></TR>
HEDOC_tempLbbsContents_1;
  echo <<<HEDOC_tempLbbsContents_2
<TR><TD $HbgSubTCell align=center>$HtagNumber_$j$H_tagNumber</TD>
HEDOC_tempLbbsContents_2;
  echo <<<HEDOC_tempLbbsContents_3
<TD $CellColor>$HtagLbbsSS_$bbs4 > $bbs5$H_tagLbbsSS $speaker</TD></TR>
HEDOC_tempLbbsContents_3;
  echo <<<HEDOC_tempLbbsContents_4
<TD $CellColor>$HtagLbbsSS_$bbs4 >(비) $bbs5$H_tagLbbsSS $speaker</TD></TR>
HEDOC_tempLbbsContents_4;
  echo <<<HEDOC_tempLbbsContents_5
<TD $CellColor><CENTER><span class='lbbsST'>- 비밀 -</span></CENTER></TD></TR>
HEDOC_tempLbbsContents_5;
  echo <<<HEDOC_tempLbbsContents_6
<TD $CellColor>$HtagLbbsOW_$bbs4 > $bbs5$H_tagLbbsOW $speaker</TD></TR>
HEDOC_tempLbbsContents_6;
  echo <<<HEDOC_tempLbbsContents_7
<TR></TR><TR></TR>
HEDOC_tempLbbsContents_7;
}
}
?>
