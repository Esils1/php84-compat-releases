<?php
include_once './hako-init.php';
if (!isset($versionInfo)) { $versionInfo = ''; }
include_once './init-game.php';

$GLOBALS['HexchangeFile'] = 'exchange.dat';
$GLOBALS['mainMode'] = '';
$GLOBALS['inputPass'] = '';
$GLOBALS['deleteID'] = '';
$GLOBALS['currentID'] = '';
$GLOBALS['ctYear'] = '';
$GLOBALS['ctMon'] = '';
$GLOBALS['ctDate'] = '';
$GLOBALS['ctHour'] = '';
$GLOBALS['ctMin'] = '';
$GLOBALS['ctSec'] = '';
$GLOBALS['mpass1'] = '';
$GLOBALS['mpass2'] = '';
$GLOBALS['spass1'] = '';
$GLOBALS['spass2'] = '';
$GLOBALS['dpass1'] = '';
$GLOBALS['dpass2'] = '';
$GLOBALS['dellcheck'] = '';

if (!headers_sent()) {
	header('Content-type: text/html');
}

echo <<<END
<HTML><HEAD><TITLE>모형정원 관리자 툴</TITLE></HEAD><BODY>
<META http-equiv="Content-Style-Type" content="text/css">
<META http-equiv="Content-Type" content="text/html;charset=UTF-8">
END;

cgiInput();

if (file_exists($GLOBALS['HpasswordFile'])) {
	$__pin = fopen($GLOBALS['HpasswordFile'], 'r');
	if ($__pin) {
		$GLOBALS['HmasterPassword'] = rtrim(fgets($__pin));
		fclose($__pin);
	}
}

if($GLOBALS['mainMode'] == 'delete') {
	if(passCheck()) { deleteMode(); }
} elseif($GLOBALS['mainMode'] == 'current') {
	if(passCheck()) { currentMode(); }
} elseif($GLOBALS['mainMode'] == 'time') {
	if(passCheck()) { timeMode(); }
} elseif($GLOBALS['mainMode'] == 'stime') {
	if(passCheck()) { stimeMode(); }
} elseif($GLOBALS['mainMode'] == 'new') {
	if(passCheck()) { newMode(); }
} elseif($GLOBALS['mainMode'] == 'change') {
	if(passCheck()) {
		if(changeMode()) {
			echo <<<END
<FONT SIZE=7>로그 데이터 이행에 성공했습니다.</FONT>
END;
		} else {
	echo <<<END
<FONT SIZE=7>로그 데이터 이행에 실패했습니다. </FONT>
END;
		}
	}
} elseif($GLOBALS['mainMode'] == 'setup') {
	setupMode();
} elseif($GLOBALS['mainMode'] == 'mente') {
	if(passCheck()) { menteMode(); }
} elseif($GLOBALS['mainMode'] == 'unmente') {
	if(passCheck()) { unmenteMode(); }
}
if(($GLOBALS['mainMode'] == 'admin') && (passCheck())) {
	adminMode();
} else {
	mainMode();
}

echo <<<END
</FORM></BODY></HTML>
END;

function myrmtree($dn) {
	if (!is_dir($dn)) { return; }
	$dh = opendir($dn . '/');
	if ($dh) {
		while(($fileName = readdir($dh)) !== false) {
			if($fileName == '.' || $fileName == '..') { continue; }
			$path = $dn . '/' . $fileName;
			if(is_dir($path)) { myrmtree($path); } else { unlink($path); }
		}
		closedir($dh);
	}
	rmdir($dn);
}

function currentMode() {
	myrmtree($GLOBALS['HdirName']);
	mkdir($GLOBALS['HdirName'], $GLOBALS['HdirMode']);
	if(!(file_exists($GLOBALS['HlogdirName']))) { mkdir($GLOBALS['HlogdirName'], $GLOBALS['HdirMode']); }

	$dh = opendir($GLOBALS['HdirName'] . '.bak' . $GLOBALS['currentID'] . '/');
	if ($dh) {
		while(($fileName = readdir($dh)) !== false) {
			if($fileName == '.' || $fileName == '..') { continue; }
			fileCopy($GLOBALS['HdirName'] . '.bak' . $GLOBALS['currentID'] . '/' . $fileName, $GLOBALS['HdirName'] . '/' . $fileName);
		}
		closedir($dh);
	}
}

function deleteMode() {
	if($GLOBALS['deleteID'] == '') {
		myrmtree($GLOBALS['HdirName']);
		if(file_exists($GLOBALS['HlogdirName'])) { myrmtree($GLOBALS['HlogdirName']); }
		if(file_exists($GLOBALS['HtempdirName'])) { myrmtree($GLOBALS['HtempdirName']); }
		if(file_exists($GLOBALS['HprofileDir'])) { myrmtree($GLOBALS['HprofileDir']); }
		if(file_exists('deldata')) { myrmtree('deldata'); }
	} else {
		myrmtree($GLOBALS['HdirName'] . '.bak' . $GLOBALS['deleteID']);
	}
	if(file_exists('hakojimalockflock')) { unlink('hakojimalockflock'); }
}

function newMode() {
	if(!file_exists($GLOBALS['HdirName'])) { mkdir($GLOBALS['HdirName'], $GLOBALS['HdirMode']); }
	if(!file_exists($GLOBALS['HlogdirName'])) { mkdir($GLOBALS['HlogdirName'], $GLOBALS['HdirMode']); }
	if(!file_exists($GLOBALS['HprofileDir'])) { mkdir($GLOBALS['HprofileDir'], $GLOBALS['HdirMode']); }
	if(file_exists($GLOBALS['HexchangeFile'])) { unlink($GLOBALS['HexchangeFile']); }

	date_default_timezone_set('Asia/Seoul');
	$now = time();
	$now = $now - ($now % ($GLOBALS['HunitTime']));

	$OUT = fopen($GLOBALS['HdirName'] . '/hakojima.dat', 'w');
	if($GLOBALS['Htournament']){
		echoFile($OUT, "2\n");
	}else{
		echoFile($OUT, "1\n");
	}
	echoFile($OUT, $now . "\n");
	echoFile($OUT, "0\n");
	echoFile($OUT, "1\n");
	fclose($OUT);
	if($GLOBALS['Htournament']){
		$OUT = fopen($GLOBALS['HdirName'] . '/tournament.dat', 'w');
		echoFile($OUT, "1\n");
		echoFile($OUT, $GLOBALS['HyosenTurn'] . "\n");
		echoFile($OUT, "0\n");
		echoFile($OUT, "0\n");
		fclose($OUT);
	}

	$maxOcean = $GLOBALS['HoceanSize'] * $GLOBALS['HoceanSize'];
	$field = array();

	for ($i = 0; $i < $maxOcean; $i++) {
		$field[] = $GLOBALS['HlandSea'];
	}

	$tm = 0;
	for ($i = 0; $i < $GLOBALS['HmaxIsland']; $i++) {
		do {
		$x = intval(mt_rand() / mt_getrandmax() * ($GLOBALS['HoceanSize'] - 2)) + 1;
		$y = intval(mt_rand() / mt_getrandmax() * ($GLOBALS['HoceanSize'] - 2)) + 1;
		if (++$tm > $maxOcean) {
			echo <<<END
<H1>에러 발생</H1>
<B>섬의 배치에 실패했습니다. </B><BR><BR>
해역 사이즈에 비례해서 섬이 너무 많습니다. <BR>
재차 시도해 주세요, 몇회 라도 실패하는 경우는,<BR>
해역을 넓히는지, 도을 줄여 주세요. <BR>
END;
			exit(0);
		}
		} while (($field[$y * $GLOBALS['HoceanSize'] + $x] != $GLOBALS['HlandSea']) || (countAroundSea($field, $x, $y) < 6));

		$field[$y * $GLOBALS['HoceanSize'] + $x] = 71;
	}

	$IOUT = fopen($GLOBALS['HdirName'] . '/submap.1', 'w');
	for ($i = 0; $i < $maxOcean; $i++) {
		$GLOBALS['HcurrentField'] = $field[$i];
		$GLOBALS['HcurrentX'] = $i % $GLOBALS['HoceanSize'];
		$GLOBALS['HcurrentY'] = intval($i / $GLOBALS['HoceanSize']);
		fprintf($IOUT, "%02x%04x%02x%04x%02x", $GLOBALS['HcurrentField'], 0, 0, 0, 0);
		if($GLOBALS['HcurrentX'] == $GLOBALS['HoceanSize']-1) { echoFile($IOUT, "\n"); }
	}
	for($i = 0; $i < 12; $i++) { echoFile($IOUT, "0\n"); }
	for($i = 0; $i < $GLOBALS['HlbbsMax']; $i++) {
		echoFile($IOUT, "0<<0>>\n");
	}
	fclose($IOUT);
	echo <<<END
<H1><A href="hako-main.php?Ocean=0" target="_blank">해역을 확인한다</A></H1>
치우친 배치가 되어 있는 경우는, 데이터를 삭제하고 나서 다시 만들어 주세요.<BR>
<HR>
END;
if($GLOBALS['Htournament']){
	echo "<H1>간이 토너먼트 기능은, 최초부터 2턴부터 되어 있습니다.</H1>";
	echo "턴 갱신의 형편상, 2턴 부터 시작해 주세요. <HR>";
}
}

function setupMode() {
	if(!($GLOBALS['mpass1'] && $GLOBALS['mpass2']) || ($GLOBALS['mpass1'] != $GLOBALS['mpass2'])) {
		echo $GLOBALS['HtagBig_'] . 'master password가 입력 되어 있지 않거나 잘못 입력 하셧습니다' . $GLOBALS['H_tagBig'];
		return;
	}
	if(!($GLOBALS['spass1'] && $GLOBALS['spass2']) || ($GLOBALS['spass1'] != $GLOBALS['spass2'])) {
		echo $GLOBALS['HtagBig_'] . '특수 패스워드가 입력 되어 있지 않거나 잘못 입력 하셧습니다' . $GLOBALS['H_tagBig'];
		return;
	}
	if(file_exists($GLOBALS['HpasswordFile'])) {
		echo $GLOBALS['HtagBig_'] . '패스워드가 설정되어 있습니다' . $GLOBALS['H_tagBig'];
		return;
	}

	$GLOBALS['mpass1'] = crypt($GLOBALS['mpass1'], 'ma');
	$GLOBALS['spass1'] = crypt($GLOBALS['spass1'], 'sp');

	$OUT = fopen($GLOBALS['HpasswordFile'], 'w');
	if (!$OUT) { return; }
	echoFile($OUT, $GLOBALS['mpass1'] . "\n");
	echoFile($OUT, $GLOBALS['spass1'] . "\n");
	fclose($OUT);
	echo $GLOBALS['HtagBig_'] . '패스워드를 설정했습니다' . $GLOBALS['H_tagBig'];
}

function timeMode() {
	$GLOBALS['ctMon']--;
	$ctYear = $GLOBALS['ctYear'];
	$ctYear -= 1900;
	$GLOBALS['ctSec'] = mktime($GLOBALS['ctHour'], $GLOBALS['ctMin'], $GLOBALS['ctSec'], $GLOBALS['ctMon'] + 1, $GLOBALS['ctDate'], $ctYear + 1900);
	stimeMode();
}

function stimeMode() {
	$t = $GLOBALS['ctSec'];
	$lines = file($GLOBALS['HdirName'] . '/hakojima.dat');
	$lines[1] = $t . "\n";
	$OUT = fopen($GLOBALS['HdirName'] . '/hakojima.dat', 'w');
	foreach($lines as $line) { echoFile($OUT, $line); }
	fclose($OUT);
}

function changeMode() {
	if(!file_exists($GLOBALS['HlogdirName'])) { mkdir($GLOBALS['HlogdirName'], $GLOBALS['HdirMode']); }

	$dh = opendir('./' . $GLOBALS['HdirName']);
	if ($dh) {
		while(($dn = readdir($dh)) !== false) {
			if(preg_match('/^hakojima\.log(.*)/', $dn, $m)) {
		    if(!rename($GLOBALS['HdirName'] . '/hakojima.log' . $m[1], $GLOBALS['HlogdirName'] . '/hakojima.log' . $m[1])) { return 0; }
			}
		}
		closedir($dh);
	}

	if (file_exists($GLOBALS['HdirName'] . '/hakojima.his')) {
		if(!rename($GLOBALS['HdirName'] . '/hakojima.his', $GLOBALS['HlogdirName'] . '/hakojima.his')) { return 0; }
	}

	if (file_exists($GLOBALS['HdirName'] . '/weather.his')) {
		if(!rename($GLOBALS['HdirName'] . '/weather.his', $GLOBALS['HlogdirName'] . '/weather.his')) { return 0; }
	}

    return 1;
}

function mainMode() {
	echo <<<END
<FORM action="{$GLOBALS['HmenteFile']}" method="POST">
<h1>구상의 모형정원 5 maintenance tool</h1>
END;
	if (!file_exists($GLOBALS['HpasswordFile'])) {
		echo <<<END
<h2>각 패스워드를 기입해 주세요 </h2>
<p>※입력 실수를 막기 위해서, 확인 패스워드를 입력해주세요 <br>
수정하는 경우나 잊어버렸으면 생성된 파일(passwd.php)을 FTP등으로 지우시고 설정 하심 됩니다(마스터 패스워드 유출 조심)</p>
<b>master password：</b><br>
(1) <INPUT type="password" name="MPASS1" value="{$GLOBALS['mpass1']}">&nbsp;&nbsp;(2) <INPUT type="password" name="MPASS2" value="{$GLOBALS['mpass2']}"><br><br>
<b>특수 패스워드：</b><br>
(1) <INPUT type="password" name="SPASS1" value="{$GLOBALS['spass1']}">&nbsp;&nbsp;(2) <INPUT type="password" name="SPASS2" value="{$GLOBALS['spass2']}"><br><br>
<INPUT type="submit" value="등록한다" name="SETUP">
<p>※마스터 패스워드로는 「다른 섬의 패스워드 변경」등 ,모든 섬의 패스워드를 대신 할 수 있습니다. <br>
※특수 패스워드는 이 패스워드로 「이름 변경」을 실시하면, 그 섬의 자금, 식량이 최대치가 됩니다. (실제로 이름을 바꿀 필요는 없습니다.)<br>
END;

		return;
	}
	echo <<<END
<B>master password：</B><INPUT TYPE=password SIZE=32 MAXLENGTH=32 NAME=PASSWORD VALUE="{$GLOBALS['inputPass']}">
<INPUT type="submit" value="관리페이지로 들어간다" name="ADMIN">
END;
	$dh = opendir('./');

	if((file_exists($GLOBALS['HdirName'] . '/hakojima.his'))||(file_exists($GLOBALS['HdirName'] . '/hakojima.log0'))){
		echo <<<END
<HR><INPUT TYPE="submit" VALUE="로그 데이터를 이행" NAME="CHANGE">
END;
	}

	if(is_dir($GLOBALS['HdirName'])) {
		dataPrint('');
	} else {
		echo <<<END
<HR><INPUT TYPE="submit" VALUE="새로운 데이터를 만든다" NAME="NEW">
END;
	}

	if ($dh) {
		while(($dn = readdir($dh)) !== false){
			if(preg_match('/^' . preg_quote($GLOBALS['HdirName'], '/') . '\.bak(.*)/', $dn, $m)) { dataPrint($m[1]); }
		}
		closedir($dh);
	}
}

function adminMode() {
	$tmp = '';
	if($GLOBALS['HadminMode']) { $tmp = '<A HREF="' . $GLOBALS['HthisFile'] . '?settei=' . $GLOBALS['inputPass'] . '" target="_blank"><H2>' . $GLOBALS['AfterName'] . '를 작성하는</H2></A>'; }
	echo <<<END
<H1>구상의 모형정원 5 관리인실</H1>
<H3><FONT COLOR="red">※이하의 작업은, 턴 갱신 전후에 실시하는 것은 매우 위험하기 때문에 실시하지 마세요</FONT></H3>
<FORM action="{$GLOBALS['HmenteFile']}" method="POST">
<INPUT type=hidden name=PASSWORD value="{$GLOBALS['inputPass']}">
<INPUT type=hidden name=ADMIN value=1>
END;
	if(file_exists('./mente_lock')) {
		echo "<INPUT TYPE=\"submit\" VALUE=\"메인트넌스 모드 해제\" NAME=\"UNMENTE\">\n";
	} else {
		echo "<INPUT TYPE=\"submit\" VALUE=\"메인트넌스 모드\" NAME=\"MENTE\">\n";
	}
	echo <<<END
</FORM>
$tmp
<A HREF="{$GLOBALS['HbaseDir']}/hako-main.php?Present=" target="_blank"><H2>참가{$GLOBALS['AfterName']}에게 선물을 준다</H2></A>
<A HREF="{$GLOBALS['HbaseDir']}/hako-main.php?Pdelete={$GLOBALS['inputPass']}" target="_blank"><H2>참가{$GLOBALS['AfterName']}을 관리인 으로 한다</H2></A>
<A HREF="{$GLOBALS['HbaseDir']}/hako-main.php?Punish={$GLOBALS['inputPass']}" target="_blank"><H2>참가{$GLOBALS['AfterName']}에게 제재를 더한다</H2></A>
<A HREF="{$GLOBALS['HbaseDir']}/hako-main.php?Lchange={$GLOBALS['inputPass']}" target="_blank"><H2>참가{$GLOBALS['AfterName']} 의  지형 데이터를 변경한다</H2></A>
<UL>
<LI>털기의 피해나, 서버 트러블, 스크립트의 버그등으로, 지형 데이터가 본의가 아닌 상태가 되어 버린{$GLOBALS['AfterName']}을 구제합니다.
<LI>인구, 농장 규모등의 수치 데이터의 반영은 턴 갱신 처리를 하고 나서가 되므로, 주의해 주세요.?
</UL>
<A HREF="{$GLOBALS['HbaseDir']}/hako-main.php?Ichange={$GLOBALS['inputPass']}" target="_blank"><H2>각종 도데이터를 강제 변경한다</H2></A>
<UL>
<LI>주로, debug용입니다. 소속을 변경하는 목적 이외로 사용하지 마세요.
</UL>
<A HREF="{$GLOBALS['HbaseDir']}/hako-main.php?settei={$GLOBALS['inputPass']}" target="_blank"><H2>참가{$GLOBALS['AfterName']}도을 강제 삭제한다</H2></A>
<UL>
<LI>「섬 이름과 패스워드의 변경」의 입력 폼으로, 해당의{$GLOBALS['AfterName']} 의  이름을 「무인」{$GLOBALS['AfterName']}으로 변경
<LI>그 때, 패스워드란에는 「특수 패스워드」를 입력해 주세요. (새로운 패스와 패스 확인란은 하늘)
</UL><BR>
<A HREF="{$GLOBALS['HbaseDir']}/hako-main.php?Bfield={$GLOBALS['inputPass']}" target="_blank"><H2>Battle Field를 작성한다</H2></A>
<UL>
<LI>아직 작성중 . 향후 사양이 변경될 가능성이 있습니다.
<LI>인구 0이 되어도 방폐되지 않는{$GLOBALS['AfterName']}도을 작성합니다. 말하자면 「연습{$GLOBALS['AfterName']}」입니다만, 경험치나 난민 돈벌이로는 됩니다.
<LI>{$GLOBALS['AfterName']}도의 등록수에는 관계없이 작성할 수 있습니다만, 최대９{$GLOBALS['AfterName']}까지 밖에 작성할 수 없습니다. (사양)
<LI>처리는 가능한 한 간략화하고 있습니다만, 추가 개조하는 만큼 부하가 증가할테니 주의해 주세요.
<LI><B>Battle Field의 사양</B>
<UL>
<LI>도단위의 이벤트는 모두 처리되지 않습니다. (제재등도 발생하지 않습니다)
<LI>노멀, PP미사일, 이민, 괴수 파견 이외는 받아들이지 않습니다.
<LI>황무지는 꽤 고확률로 평지가 되어, 평지는 숲이나 도시에 접하지 않아도 마을이 발생합니다.
<LI>자연 출현하는 괴수는, 킹 이노라까지로 이동 등은 하지 않습니다. (방어는 한다)
<LI>괴수를 넘어뜨렸을 때의 보장금은, 쓰러트린 도의 자금이 됩니다.
</UL>
</UL><BR>
<FORM action="{$GLOBALS['HbaseDir']}/analyzer.php" method=POST>
<INPUT type=hidden name=password value="{$GLOBALS['inputPass']}">
<INPUT type=hidden name=mode value="analyze">
<INPUT type=hidden name=category value="a">
<INPUT type=submit value='액세스 로그를 본다'>
</FORM>
<UL>
<LI>메인 스크립트(hako-main.php)의 설정으로 「액세스 로그를 취한다」하고 같게 하고 있지 않으면, 볼 수가 없습니다.
<LI>로그를 남기는 동작에 의한 부하증가는 바보가 되지 않으나 , 모형정원 본체의 동작에도 영향이 있는 것을 각오해 주세요. 
</UL><BR>
<A HREF="{$GLOBALS['HbaseDir']}/hako-main.php?SetupV={$GLOBALS['inputPass']}" target="_blank"><H2>설정 일람표시</H2></A>
END;
}

function dataPrint($suf) {
	echo '<HR>';
	if($suf == '') {
		$IN = fopen($GLOBALS['HdirName'] . '/hakojima.dat', 'r');
		echo '<H1>현역 데이터</H1>';
	} else {
		$IN = fopen($GLOBALS['HdirName'] . '.bak' . $suf . '/hakojima.dat', 'r');
		echo '<H1>백업' . $suf . '</H1>';
	}
	if (!$IN) { return; }
	$lastTurn = intval(fgets($IN));
	$lastTime = intval(fgets($IN));
	$islandNumber = intval(fgets($IN));
	fclose($IN);
	$timeString = timeToString($lastTime);
	echo <<<END
<B>턴$lastTurn</B><BR>
<B>최종 갱신 시간</B>:$timeString<BR>
<B>최종 갱신 시간(초수의 표시)</B>:1970년 1월 1일부터$lastTime 초<BR>
<INPUT TYPE="submit" VALUE="이 데이터를 삭제" NAME="DELETE$suf">
END;
	if($suf == '') {
		$lt = localtimeArray($lastTime);
		$sec = $lt['sec']; $min = $lt['min']; $hour = $lt['hour']; $date = $lt['mday']; $mon = $lt['mon'] + 1; $year = $lt['year'] + 1900;
		echo <<<END
<H2>최종 갱신 시간의 변경</H2>
<INPUT TYPE="text" SIZE=4 NAME="YEAR" VALUE="$year">년
<INPUT TYPE="text" SIZE=2 NAME="MON" VALUE="$mon">월
<INPUT TYPE="text" SIZE=2 NAME="DATE" VALUE="$date">일
<INPUT TYPE="text" SIZE=2 NAME="HOUR" VALUE="$hour">시
<INPUT TYPE="text" SIZE=2 NAME="MIN" VALUE="$min">분
<INPUT TYPE="text" SIZE=2 NAME="NSEC" VALUE="$sec">초
<INPUT TYPE="submit" VALUE="변경" NAME="NTIME"><BR>
1970년 1월 1일부터<INPUT TYPE="text" SIZE=32 NAME="SSEC" VALUE="$lastTime">초
<INPUT TYPE="submit" VALUE="초지정으로 변경" NAME="STIME">
<br><br><a href="{$GLOBALS['HthisFile']}">[게임 화면에]</a><br>
END;
	} else {
		echo <<<END
<INPUT TYPE="submit" VALUE="이 데이터를 현역에게" NAME="CURRENT$suf">
END;
	}
}

function timeToString($time) {
	$lt = localtimeArray($time);
	$mon = $lt['mon'] + 1;
	$year = $lt['year'] + 1900;
	return $year . '년 ' . $mon . '월 ' . $lt['mday'] . '일 ' . $lt['hour'] . '시 ' . $lt['min'] . '분 ' . $lt['sec'] . '초';
}

function cgiInput() {
	$line = '';
	if (!empty($_POST)) {
		$line = http_build_query($_POST);
	} else {
		$line = file_get_contents('php://input');
	}
	$line = str_replace('+', ' ', $line);
	$line = preg_replace_callback('/%([a-fA-F0-9][a-fA-F0-9])/', 'hako_hex_decode_callback', $line);

	$getLine = isset($_SERVER['QUERY_STRING']) ? $_SERVER['QUERY_STRING'] : '';

	if(preg_match('/DELETE([0-9]*)/', $line, $m)) {
		$GLOBALS['mainMode'] = 'delete';
		$GLOBALS['deleteID'] = $m[1];
	} elseif(preg_match('/CURRENT([0-9]*)/', $line, $m)) {
		$GLOBALS['mainMode'] = 'current';
		$GLOBALS['currentID'] = $m[1];
	} elseif(preg_match('/NEW/', $line)) {
		$GLOBALS['mainMode'] = 'new';
	} elseif(preg_match('/UNMENTE/', $line)) {
		$GLOBALS['mainMode'] = 'unmente';
		if(preg_match('/ADMIN=([0-9])\&/', $line, $m)) { $GLOBALS['dellcheck'] = $m[1]; }
	} elseif(preg_match('/MENTE/', $line)) {
		$GLOBALS['mainMode'] = 'mente';
		if(preg_match('/ADMIN=([0-9])\&/', $line, $m)) { $GLOBALS['dellcheck'] = $m[1]; }
	} elseif(preg_match('/ADMIN/', $line)) {
		$GLOBALS['mainMode'] = 'admin';
	} elseif(preg_match('/ADMIN=([^\&]*)/', $getLine, $m)) {
		$GLOBALS['mainMode'] = 'admin';
		$GLOBALS['inputPass'] = urldecode($m[1]);
	} elseif(preg_match('/SETUP/', $line)) {
		$GLOBALS['mainMode'] = 'setup';
		if(preg_match('/MPASS1=([^\&]*)\&/', $line, $m)) { $GLOBALS['mpass1'] = $m[1]; }
		if(preg_match('/MPASS2=([^\&]*)\&/', $line, $m)) { $GLOBALS['mpass2'] = $m[1]; }
		if(preg_match('/SPASS1=([^\&]*)\&/', $line, $m)) { $GLOBALS['spass1'] = $m[1]; }
		if(preg_match('/SPASS2=([^\&]*)\&/', $line, $m)) { $GLOBALS['spass2'] = $m[1]; }
		if(preg_match('/DPASS1=([^\&]*)\&/', $line, $m)) { $GLOBALS['dpass1'] = $m[1]; }
		if(preg_match('/DPASS2=([^\&]*)\&/', $line, $m)) { $GLOBALS['dpass2'] = $m[1]; }
	} elseif(preg_match('/NTIME/', $line)) {
		$GLOBALS['mainMode'] = 'time';
		if(preg_match('/YEAR=([0-9]*)/', $line, $m)) { $GLOBALS['ctYear'] = $m[1]; }
		if(preg_match('/MON=([0-9]*)/', $line, $m)) { $GLOBALS['ctMon'] = $m[1]; }
		if(preg_match('/DATE=([0-9]*)/', $line, $m)) { $GLOBALS['ctDate'] = $m[1]; }
		if(preg_match('/HOUR=([0-9]*)/', $line, $m)) { $GLOBALS['ctHour'] = $m[1]; }
		if(preg_match('/MIN=([0-9]*)/', $line, $m)) { $GLOBALS['ctMin'] = $m[1]; }
		if(preg_match('/NSEC=([0-9]*)/', $line, $m)) { $GLOBALS['ctSec'] = $m[1]; }
	} elseif(preg_match('/STIME/', $line)) {
		$GLOBALS['mainMode'] = 'stime';
		if(preg_match('/SSEC=([0-9]*)/', $line, $m)) { $GLOBALS['ctSec'] = $m[1]; }
	} elseif(preg_match('/TOURNAMENTTIME/', $line)) {
		$GLOBALS['mainMode'] = 'tournamenttime';
	} elseif(preg_match('/CHANGE/', $line)) {
		$GLOBALS['mainMode'] = 'change';
	}

	if(preg_match('/PASSWORD=([^\&]*)\&/', $line, $m)) { $GLOBALS['inputPass'] = $m[1]; }
	if($GLOBALS['inputPass'] == '' && isset($_POST['PASSWORD'])) { $GLOBALS['inputPass'] = $_POST['PASSWORD']; }
}

function fileCopy($src, $dist) {
	$IN = fopen($src, 'r');
	$OUT = fopen($dist, 'w');
	if($IN && $OUT) {
		while(!feof($IN)) {
			echoFile($OUT, fgets($IN));
		}
	}
	if($IN) { fclose($IN); }
	if($OUT) { fclose($OUT); }
}

function passCheck() {
	if(crypt($GLOBALS['inputPass'], 'ma') == $GLOBALS['HmasterPassword']) {
		return 1;
	} else {
		echo $GLOBALS['HtagBig_'] . '패스워드가 다른' . $GLOBALS['H_tagBig'];
		return 0;
	}
}

function menteMode() {
    if(!file_exists('./mente_lock')) { mkdir('./mente_lock', $GLOBALS['HdirMode']); }
}

function unmenteMode() {
	if(file_exists('./mente_lock')) { rmdir('./mente_lock'); }
}

function countAroundSea($field, $x, $y) {
	$ax = array(0,1,1,1,0,-1,0);
	$ay = array(0,-1,0,1,1,0,-1);

	$sx = $x + $ax[0];
	$sy = $y + $ay[0];
	if(!($sy % 2) && ($y % 2)) { $sx--; }
	$idx = $sy * $GLOBALS['HoceanSize'] + $sx;
	if (!isset($field[$idx]) || ($field[$idx] != $GLOBALS['HlandSea'])) { return 0; }

	$count = 0;
	for($i = 1; $i < 7; $i++) {
		$sx = $x + $ax[$i];
		$sy = $y + $ay[$i];

		if(!($sy % 2) && ($y % 2)) { $sx--; }

		if(($sx < 0) || ($sx >= $GLOBALS['HoceanSize']) || ($sy < 0) || ($sy >= $GLOBALS['HoceanSize'])) {
		} else {
			$idx = $sy * $GLOBALS['HoceanSize'] + $sx;
			if (isset($field[$idx]) && ($field[$idx] == $GLOBALS['HlandSea'])) { $count++; }
		}
	}

	return $count;
}

function echoFile($fp, $s) {
	if($fp) { fwrite($fp, $s); }
}

function hako_hex_decode_callback($m) {
	return chr(hexdec($m[1]));
}

function localtimeArray($time) {
	$a = getdate($time);
	return array('sec'=>$a['seconds'], 'min'=>$a['minutes'], 'hour'=>$a['hours'], 'mday'=>$a['mday'], 'mon'=>$a['mon'] - 1, 'year'=>$a['year'] - 1900);
}
?>
