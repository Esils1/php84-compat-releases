<?php
require_once './hako-init.php';

$Hinit = array();
$Hhtml = array();
$Hinput = array();
$Hprofile = array();
$Hislands = array();
$HidToNumber = array();
$HislandNumber = 0;
$HmainMode = '';
$HinputPassword = '';
$HdefaultID = '';
$HdefaultPassword = '';

$Hinit['thisFile'] = 'profile.php';
$Hinit['gzip'] = 0;
$Hinit['gzipPath'] = '/bin';
$Hhtml['body'] = '<body>';
$Hhtml['title'] = '모형정원 제도 프로필';
$Hhtml['lineColor']     = 'class=lineColor';
$Hhtml['tdHeaderColor'] = 'class=tdHeaderColor';
$Hhtml['cellColor']     = 'class=cellColor';
$Hhtml['bye'] = $HbaseDir . '/hako-main.php';

main();
exit(0);

function main() {
    global $HmainMode, $Hinput, $Hislands, $HidToNumber, $HdefaultID, $HinputPassword;

    cookieInput();
    cgiInput();

    if(!readIslandsFile()) {
        htmlHeader();
        tempNoDataFile();
        htmlFooter();
        return;
    }

    htmlHeader();
    $id = isset($Hinput['ID']) ? $Hinput['ID'] : '';
    if($id === '' || !isset($HidToNumber[$id])) {
        if($HmainMode == 'edit') {
            $resolved = profileResolveEditID();
            if($resolved !== '' && isset($HidToNumber[$resolved])) {
                $Hinput['ID'] = $resolved;
                $id = $resolved;
            } else {
                getProfileLastModify();
                lastModifySort();
                htmlProfileList();
                htmlFooter();
                return;
            }
        } else {
            getProfileLastModify();
            lastModifySort();
            htmlProfileList();
            htmlFooter();
            return;
        }
    }

    if($HmainMode == 'changeProfile') {
        $checkID = ($HdefaultID !== '' && isset($HidToNumber[$HdefaultID])) ? $HdefaultID : (isset($Hinput['ID']) ? $Hinput['ID'] : '');
        if($checkID !== '' && isset($HidToNumber[$checkID]) && checkPassword($Hislands[$HidToNumber[$checkID]]['password'], $HinputPassword)) {
            writeProfileFile();
        } else {
            tempWrongPassword();
            htmlFooter();
            return;
        }
    }

    readProfileFile();

    if($HmainMode == 'edit') {
        htmlEdit();
    } else {
        htmlProfile();
    }
    htmlFooter();
}

function profile_raw_input() {
    if(!empty($_POST)) { return http_build_query($_POST); }
    $raw = file_get_contents('php://input');
    return ($raw === false) ? '' : $raw;
}

function profile_urldecode($s) {
    return urldecode(str_replace('+', ' ', (string)$s));
}

function checkPassword($p1, $p2) {
    return ((string)$p1 === crypt((string)$p2, 'h2')) ? 1 : 0;
}

function checkUrl($url) {
    $url = (string)$url;
    return (substr($url, 0, 7) === 'http://') ? $url : '';
}

function lastModifySort() {
    global $Hislands, $HislandNumber, $HidToNumber;
    usort($Hislands, 'profile_last_modify_compare');
    $HidToNumber = array();
    $HislandNumber = count($Hislands);
    for($i = 0; $i < $HislandNumber; $i++) {
        $HidToNumber[$Hislands[$i]['id']] = $i;
    }
}

function profile_last_modify_compare($a, $b) {
    $am = isset($a['lastModify']) ? intval($a['lastModify']) : 0;
    $bm = isset($b['lastModify']) ? intval($b['lastModify']) : 0;
    if($am == $bm) { return 0; }
    return ($am > $bm) ? -1 : 1;
}

function cutColumn($s, $c) {
    $s = (string)$s;
    if(strlen($s) <= $c) { return $s; }
    return substr($s, 0, $c);
}

function cgiInput() {
    global $HmainMode, $HinputPassword, $Hprofile, $Hinput, $HdefaultID;

    $line = profile_raw_input();
    parse_str($line, $post);

    if(isset($post['changeProfileButton'])) {
        $HmainMode = 'changeProfile';
    } elseif(isset($_GET['mode']) && $_GET['mode'] == 'edit') {
        $HmainMode = 'edit';
    }

    if(isset($post['PASSWORD'])) { $HinputPassword = profile_urldecode($post['PASSWORD']); }
    if(isset($post['ADDRESS'])) { $Hprofile['address'] = htmlEscape(profile_urldecode($post['ADDRESS'])); }
    if(isset($post['AGE'])) { $Hprofile['age'] = htmlEscape(profile_urldecode($post['AGE'])); }
    if(isset($post['SEX']) && preg_match('/^[1-3]$/', $post['SEX'])) { $Hprofile['sex'] = intval($post['SEX']); }
    if(isset($post['JOB'])) { $Hprofile['job'] = htmlEscape(profile_urldecode($post['JOB'])); }
    if(isset($post['EMAIL'])) { $Hprofile['email'] = htmlEscape(profile_urldecode($post['EMAIL'])); }
    if(isset($post['ICQ'])) { $Hprofile['icq'] = htmlEscape(profile_urldecode($post['ICQ'])); }
    if(isset($post['HPTITLE'])) { $Hprofile['webTitle'] = htmlEscape(profile_urldecode($post['HPTITLE'])); }
    if(isset($post['URL'])) { $Hprofile['webAddress'] = checkUrl(htmlEscape(profile_urldecode($post['URL']))); }
    if(isset($post['PHOTO'])) { $Hprofile['photo'] = checkUrl(htmlEscape(profile_urldecode($post['PHOTO']))); }
    if(isset($post['COMMENT'])) { $Hprofile['comment'] = cutColumn(htmlEscape(profile_urldecode($post['COMMENT'])), 250); }
    if(isset($post['BESTWEB1'])) { $Hprofile['BestWebsite1'] = checkUrl(htmlEscape(profile_urldecode($post['BESTWEB1']))); }
    if(isset($post['BESTWEB2'])) { $Hprofile['BestWebsite2'] = checkUrl(htmlEscape(profile_urldecode($post['BESTWEB2']))); }
    if(isset($post['BESTWEB3'])) { $Hprofile['BestWebsite3'] = checkUrl(htmlEscape(profile_urldecode($post['BESTWEB3']))); }
    if(isset($post['HOMEIMAGE'])) { $Hprofile['MyHomeImage'] = checkUrl(htmlEscape(profile_urldecode($post['HOMEIMAGE']))); }
    if(isset($post['BGIMAGE'])) { $Hprofile['BackgroundImage'] = checkUrl(htmlEscape(profile_urldecode($post['BGIMAGE']))); }
    if(isset($post['BGIMAGEUSE']) && preg_match('/^[1-2]$/', $post['BGIMAGEUSE'])) { $Hprofile['BackgroundUse'] = intval($post['BGIMAGEUSE']); }

    if(isset($_GET['profile']) && preg_match('/^[0-9]+$/', $_GET['profile'])) {
        $Hinput['ID'] = intval($_GET['profile']);
        if($HdefaultID === '' || $HdefaultID === null) { $HdefaultID = $Hinput['ID']; }
    }
}

function getProfileLastModify() {
    global $Hislands, $HislandNumber, $HprofileDir;
    for($i = 0; $i < $HislandNumber; $i++) {
        $id = $Hislands[$i]['id'];
        $fn = $HprofileDir . '/profile' . $id . '.dat';
        if(file_exists($fn)) {
            $fp = fopen($fn, 'r');
            $Hislands[$i]['lastModify'] = $fp ? intval(fgets($fp)) : 0;
            if($fp) { fclose($fp); }
        } else {
            $Hislands[$i]['lastModify'] = 0;
        }
    }
}

function writeProfileFile() {
    global $HprofileDir, $HdirMode, $Hinput, $Hprofile;
    if(!file_exists($HprofileDir)) { mkdir($HprofileDir, $HdirMode); }
    $id = isset($Hinput['ID']) ? intval($Hinput['ID']) : 0;
    $fp = fopen($HprofileDir . '/profile' . $id . '.dat', 'w');
    if(!$fp) { return 0; }
    fwrite($fp, time() . "\n");
    $keys = array('photo','address','age','sex','job','email','icq','webTitle','webAddress','comment','BestWebsite1','BestWebsite2','BestWebsite3','MyHomeImage','BackgroundImage','BackgroundUse');
    foreach($keys as $key) {
        $v = isset($Hprofile[$key]) ? $Hprofile[$key] : '';
        fwrite($fp, $v . "\n");
    }
    fclose($fp);
    return 1;
}

function readProfileFile() {
    global $HprofileDir, $Hinput, $Hprofile;
    $defaults = array(
        'lastModify'=>0, 'photo'=>'', 'address'=>'', 'age'=>'', 'sex'=>0, 'job'=>'', 'email'=>'', 'icq'=>'',
        'webTitle'=>'', 'webAddress'=>'', 'comment'=>'', 'BestWebsite1'=>'', 'BestWebsite2'=>'', 'BestWebsite3'=>'',
        'MyHomeImage'=>'', 'BackgroundImage'=>'', 'BackgroundUse'=>0
    );
    $Hprofile = array_merge($defaults, $Hprofile);
    $id = isset($Hinput['ID']) ? intval($Hinput['ID']) : 0;
    $fn = $HprofileDir . '/profile' . $id . '.dat';
    if(!file_exists($fn)) { return 0; }
    $lines = file($fn, FILE_IGNORE_NEW_LINES);
    if($lines === false) { return 0; }
    $keys = array('lastModify','photo','address','age','sex','job','email','icq','webTitle','webAddress','comment','BestWebsite1','BestWebsite2','BestWebsite3','MyHomeImage','BackgroundImage','BackgroundUse');
    foreach($keys as $i=>$key) {
        if(isset($lines[$i])) { $Hprofile[$key] = ($key == 'lastModify' || $key == 'sex' || $key == 'BackgroundUse') ? intval($lines[$i]) : rtrim($lines[$i]); }
    }
    return 1;
}

function readIslandsFile() {
    global $HdirName, $Hislands, $HislandNumber, $HidToNumber;
    $fn = $HdirName . '/hakojima.dat';
    if(!file_exists($fn)) { return 0; }
    $fp = fopen($fn, 'r');
    if(!$fp) { return 0; }
    fgets($fp);
    fgets($fp);
    $HislandNumber = intval(fgets($fp));
    fgets($fp);
    $Hislands = array();
    $HidToNumber = array();
    for($i = 0; $i < $HislandNumber; $i++) {
        $island = readIslandFromHandle($fp);
        if($island === false) { break; }
        $Hislands[] = $island;
        $HidToNumber[$island['id']] = count($Hislands) - 1;
    }
    $HislandNumber = count($Hislands);
    fclose($fp);
    return 1;
}

function readIslandFromHandle($fp) {
    $line = fgets($fp);
    if($line === false) { return false; }
    $line = rtrim($line);
    $nameParts = explode(',', $line, 2);
    $name = $nameParts[0];
    $id = intval(fgets($fp));
    $ownername = rtrim(fgets($fp));
    fgets($fp);
    fgets($fp);
    fgets($fp);
    $password = rtrim(fgets($fp));
    for($i = 7; $i < 35; $i++) { if(fgets($fp) === false) { break; } }
    return array('id'=>$id, 'name'=>$name, 'ownername'=>$ownername, 'password'=>$password);
}

function profileCookieName($name) {
    return preg_replace('/[^A-Za-z0-9_]/', '_', $name);
}

function profile_cookie_get_value($suffix) {
    global $HthisFile, $HbaseDir;
    $names = array();
    $names[] = $HthisFile . $suffix;
    $names[] = profileCookieName($HthisFile . $suffix);
    $names[] = profileCookieName($HthisFile) . $suffix;
    $names[] = basename($HthisFile) . $suffix;
    $names[] = profileCookieName(basename($HthisFile) . $suffix);
    $names[] = profileCookieName($HbaseDir . '/hako-main.php' . $suffix);
    $names[] = profileCookieName($HbaseDir . '/hako-main.cgi' . $suffix);
    $names[] = $suffix;

    foreach ($names as $name) {
        if (isset($_COOKIE[$name])) {
            $v = $_COOKIE[$name];
            if (preg_match('/^\((.*)\)$/', $v, $m)) { return $m[1]; }
            return $v;
        }
    }

    $cookie = isset($_SERVER['HTTP_COOKIE']) ? $_SERVER['HTTP_COOKIE'] : '';
    foreach ($names as $name) {
        $q = preg_quote($name, '/');
        if (preg_match('/(?:^|;\s*)' . $q . '=\(([^\)]*)\)/', $cookie, $m)) { return $m[1]; }
        if (preg_match('/(?:^|;\s*)' . $q . '=([^;]*)/', $cookie, $m)) { return trim($m[1]); }
    }
    if (preg_match('/(?:^|;\s*)[^;=]*' . preg_quote($suffix, '/') . '=\(([^\)]*)\)/', $cookie, $m)) { return $m[1]; }
    if (preg_match('/(?:^|;\s*)[^;=]*' . preg_quote($suffix, '/') . '=([^;]*)/', $cookie, $m)) { return trim($m[1]); }
    return null;
}

function cookieInput() {
    global $HdefaultID, $HdefaultPassword, $HskinName;
    $v = profile_cookie_get_value('OWNISLANDID');
    if($v !== null && $v !== '') { $HdefaultID = $v; }
    $v = profile_cookie_get_value('OWNISLANDPASSWORD');
    if($v !== null) { $HdefaultPassword = $v; }
    $v = profile_cookie_get_value('SKIN');
    if($v !== null && $v !== '') { $HskinName = $v; }
}

function profileResolveEditID() {
    global $HdefaultID, $Hinput, $HidToNumber, $Hislands, $HislandNumber;
    if($HdefaultID !== '' && isset($HidToNumber[$HdefaultID])) { return $HdefaultID; }
    if(isset($Hinput['ID']) && isset($HidToNumber[$Hinput['ID']])) { return $Hinput['ID']; }
    if($HislandNumber > 0 && isset($Hislands[0]['id'])) { return $Hislands[0]['id']; }
    return $HdefaultID;
}

function htmlEscape($s) {
    $s = (string)$s;
    $s = str_replace('&', '&amp;', $s);
    $s = str_replace('<', '&lt;', $s);
    $s = str_replace('>', '&gt;', $s);
    $s = str_replace('"', '&quot;', $s);
    $s = str_replace("'", '&#39;', $s);
    $s = str_replace("\r\n", '<br>', $s);
    $s = str_replace("\n", '<br>', $s);
    $s = str_replace("\r", '<br>', $s);
    $s = str_replace(' ', '&#32;', $s);
    return $s;
}

function htmlAttr($s) {
    return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}

function timeToString($time) {
    $a = getdate(intval($time));
    return $a['year'] . '년 ' . $a['mon'] . '월 ' . $a['mday'] . '일 ' . $a['hours'] . '시 ' . $a['minutes'] . '분 ' . $a['seconds'] . '초';
}

function out($s) { echo $s; }

function htmlHeader() {
    global $Hhtml, $HbaseDir, $Hinit, $HdefaultID, $HcssFile, $HskinName, $imageDir;
    $editID = profileResolveEditID();
    if($editID === '') { $editID = $HdefaultID; }
    if(!headers_sent()) { header('Content-type: text/html; charset=UTF-8'); }
    $skin = '';
    if(isset($HskinName) && is_string($HskinName) && $HskinName !== '') { $skin = $HskinName; }
    if($skin === '') { $skin = $HcssFile; }
    out("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\n\n");
    out("<HTML>\n<HEAD>\n<TITLE>\n" . $Hhtml['title'] . "\n</TITLE>\n");
    out('<META http-equiv="Content-Type" content="text/html; charset=UTF-8">' . "\n");
    out('<base href="' . $imageDir . '/">' . "\n");
    out('<link rel="stylesheet" type="text/css" href="' . $skin . '">' . "\n");
    out("</HEAD>\n" . $Hhtml['body'] . "\n");
    out("<DIV ID='BodySpecial'><DIV ID='LinkHead'></DIV><DIV ID='LinkTop'>\n");
    out('<A HREF="' . $Hhtml['bye'] . '">[돌아온다]</A>　<a href="' . $HbaseDir . '/' . $Hinit['thisFile'] . '">[프로필 일람]</a>　<a href="' . $HbaseDir . '/' . $Hinit['thisFile'] . '?profile=' . $editID . '&mode=edit">[프로필 편집]</a>' . "\n<HR></DIV>\n");
}

function htmlFooter() {
    out(<<<END
<P>
<I><A HREF="http://club.www.infoseek.co.jp/club.asp?cid=j1100037">Scripted By Watson</A></I>
</P><P></DIV>
</BODY>
</HTML>
END
);
}

function htmlProfileList() {
    global $Hislands, $HislandNumber, $Hhtml, $HbaseDir, $Hinit, $AfterName;
    $after = isset($AfterName) ? $AfterName : '도';
    out(<<<END
  <TABLE BORDER=0 CELLPADDING=1 CELLSPACING=0 WIDTH=100% {$Hhtml['lineColor']}><TR><TD>
<TABLE BORDER=0 CELLPADDING=1 CELLSPACING=1 WIDTH=100%>
<tr><td {$Hhtml['tdHeaderColor']}>섬이름</td><td {$Hhtml['tdHeaderColor']}>사용자명</td><td {$Hhtml['tdHeaderColor']}>갱신 시각</td></tr>
END
);
    for($i = 0; $i < $HislandNumber; $i++) {
        if(isset($Hislands[$i]['lastModify']) && $Hislands[$i]['lastModify'] > 0) {
            $timeString = timeToString($Hislands[$i]['lastModify']);
            $name = htmlspecialchars($Hislands[$i]['name'], ENT_QUOTES, 'UTF-8');
            $owner = htmlspecialchars($Hislands[$i]['ownername'], ENT_QUOTES, 'UTF-8');
            out('<tr><td ' . $Hhtml['cellColor'] . '><a href="' . $HbaseDir . '/' . $Hinit['thisFile'] . '?profile=' . $Hislands[$i]['id'] . '">' . $name . $after . '</a></td><td ' . $Hhtml['cellColor'] . '>' . $owner . '</td><td ' . $Hhtml['cellColor'] . '>' . $timeString . '</td></tr>');
        }
    }
    out("</table>\n</td></tr></table>\n");
}

function htmlProfile() {
    global $Hinput, $HidToNumber, $Hislands, $Hprofile, $Hhtml, $AfterName;
    $num = $HidToNumber[$Hinput['ID']];
    $after = isset($AfterName) ? $AfterName : '도';
    $sex = '비공개';
    if($Hprofile['sex'] == 1) { $sex = '남성'; }
    elseif($Hprofile['sex'] == 2) { $sex = '여성'; }
    $comment = ($Hprofile['comment'] !== '') ? $Hprofile['comment'] : '미설정';
    $email = ($Hprofile['email'] !== '') ? '<a href="mailto:' . $Hprofile['email'] . '">' . $Hprofile['email'] . '</a>' : '미설정';
    $icq = ($Hprofile['icq'] !== '') ? 'UIN : ' . $Hprofile['icq'] . ' - <img src="http://online.mirabilis.com/scripts/online.dll?icq=' . $Hprofile['icq'] . '&img=1">' : '미설정';
    $hp = (($Hprofile['webTitle'] !== '') && preg_match('/http:\/\/.+/', $Hprofile['webAddress'])) ? '<a href="' . $Hprofile['webAddress'] . '">' . $Hprofile['webTitle'] . '</a>' : '미설정';
    $myImage = preg_match('/http:\/\/.+/', $Hprofile['MyHomeImage']) ? '<a href="' . $Hprofile['MyHomeImage'] . '">' . $Hprofile['MyHomeImage'] . '</a>' : '미설정';
    $bgImage = preg_match('/http:\/\/.+/', $Hprofile['BackgroundImage']) ? '<a href="' . $Hprofile['BackgroundImage'] . '">' . $Hprofile['BackgroundImage'] . '</a>' : '미설정';
    $bgUse = ($Hprofile['BackgroundUse'] == 2) ? '표시함' : '표시함';
    $timeString = ($Hprofile['lastModify'] != 0) ? timeToString($Hprofile['lastModify']) : '';
    $name = htmlspecialchars($Hislands[$num]['name'], ENT_QUOTES, 'UTF-8');
    $owner = htmlspecialchars($Hislands[$num]['ownername'], ENT_QUOTES, 'UTF-8');
    out('<p><div align="right">갱신 시각 : ' . $timeString . '</div><div class="bar1"><div class="bar2"><b>프로필</b></div></div></p>');
    out('<table><tr><td valign=top>');
    if(preg_match('/http:\/\/.+/', $Hprofile['photo'])) {
        out('<p><TABLE BORDER=0 CELLPADDING=1 CELLSPACING=0 WIDTH=250 ' . $Hhtml['lineColor'] . '><TR><TD><TABLE BORDER=0 CELLPADDING=1 CELLSPACING=1 WIDTH=100%><tr><td ' . $Hhtml['tdHeaderColor'] . '>사진</td></tr><tr><td ' . $Hhtml['cellColor'] . ' align=center><a href="' . $Hprofile['photo'] . '"><img src="' . $Hprofile['photo'] . '" alt="me" border=0 width=230></a></td></tr></table></td></tr></table></p>');
    }
    out('<p><TABLE BORDER=0 CELLPADDING=1 CELLSPACING=0 WIDTH=250 ' . $Hhtml['lineColor'] . '><TR><TD><TABLE BORDER=0 CELLPADDING=1 CELLSPACING=1 WIDTH=100%>');
    out('<tr><td ' . $Hhtml['tdHeaderColor'] . ' width=80>섬의 이름</td><td ' . $Hhtml['cellColor'] . '>' . $name . $after . '</td></tr>');
    out('<tr><td ' . $Hhtml['tdHeaderColor'] . ' width=80>사용자의 이름</td><td ' . $Hhtml['cellColor'] . '>' . $owner . '</td></tr>');
    out('<tr><td ' . $Hhtml['tdHeaderColor'] . ' width=80>주소</td><td ' . $Hhtml['cellColor'] . '>' . $Hprofile['address'] . '</td></tr>');
    out('<tr><td ' . $Hhtml['tdHeaderColor'] . ' width=80>연령</td><td ' . $Hhtml['cellColor'] . '>' . $Hprofile['age'] . '</td></tr>');
    out('<tr><td ' . $Hhtml['tdHeaderColor'] . ' width=80>성별</td><td ' . $Hhtml['cellColor'] . '>' . $sex . '</td></tr>');
    out('<tr><td ' . $Hhtml['tdHeaderColor'] . ' width=80>직업</td><td ' . $Hhtml['cellColor'] . '>' . $Hprofile['job'] . '</td></tr></table></td></tr></table></p>');
    out('<p><TABLE BORDER=0 CELLPADDING=1 CELLSPACING=0 WIDTH=250 ' . $Hhtml['lineColor'] . '><TR><TD><TABLE BORDER=0 CELLPADDING=1 CELLSPACING=1 WIDTH=100%><tr><td ' . $Hhtml['tdHeaderColor'] . '>E-Mail</td></tr><tr><td ' . $Hhtml['cellColor'] . '>' . $email . '</td></tr></table></td></tr></table></p>');
    out('<p><TABLE BORDER=0 CELLPADDING=1 CELLSPACING=0 WIDTH=250 ' . $Hhtml['lineColor'] . '><TR><TD><TABLE BORDER=0 CELLPADDING=1 CELLSPACING=1 WIDTH=100%><tr><td ' . $Hhtml['tdHeaderColor'] . '>ICQ</td></tr><tr><td ' . $Hhtml['cellColor'] . '>' . $icq . '</td></tr></table></td></tr></table></p>');
    out('</td><td width=10></td><td valign=top>');
    out('<p><TABLE BORDER=0 CELLPADDING=1 CELLSPACING=0 WIDTH=340 ' . $Hhtml['lineColor'] . '><TR><TD><TABLE BORDER=0 CELLPADDING=1 CELLSPACING=1 WIDTH=100%><tr><td ' . $Hhtml['tdHeaderColor'] . '>흥미·관심</td></tr><td ' . $Hhtml['cellColor'] . '>' . $comment . '</td></tr></table></td></tr></table></p>');
    out('<p><TABLE BORDER=0 CELLPADDING=1 CELLSPACING=0 WIDTH=340 ' . $Hhtml['lineColor'] . '><TR><TD><TABLE BORDER=0 CELLPADDING=1 CELLSPACING=1 WIDTH=100%><tr><td ' . $Hhtml['tdHeaderColor'] . '>내 홈 페이지</td></tr><tr><td ' . $Hhtml['cellColor'] . '>' . $hp . '</td></tr></table></td></tr></table></p>');
    out('<p><TABLE BORDER=0 CELLPADDING=1 CELLSPACING=0 WIDTH=340 ' . $Hhtml['lineColor'] . '><TR><TD><TABLE BORDER=0 CELLPADDING=1 CELLSPACING=1 WIDTH=100%><tr><td ' . $Hhtml['tdHeaderColor'] . '>추천 사이트</td></tr><td ' . $Hhtml['cellColor'] . '><ul>');
    foreach(array('BestWebsite1','BestWebsite2','BestWebsite3') as $key) { out(preg_match('/http:\/\/.+/', $Hprofile[$key]) ? '<li><a href="' . $Hprofile[$key] . '">' . $Hprofile[$key] . '</a>' : '<li>'); }
    out('</ul></td></tr></table></td></tr></table></p>');
    out('<p><TABLE BORDER=0 CELLPADDING=1 CELLSPACING=0 WIDTH=340 ' . $Hhtml['lineColor'] . '><TR><TD><TABLE BORDER=0 CELLPADDING=1 CELLSPACING=1 WIDTH=100%><tr><td ' . $Hhtml['tdHeaderColor'] . '>내 홈 이미지 URL</td></tr><tr><td ' . $Hhtml['cellColor'] . '>' . $myImage . '</td></tr><tr><td ' . $Hhtml['tdHeaderColor'] . '>자신의 도 배경 이미지 or 스타일 시트 URL</td></tr><tr><td ' . $Hhtml['cellColor'] . '>' . $bgImage . '</td></tr><tr><td ' . $Hhtml['tdHeaderColor'] . '>자신의 도 배경 이미지 or 스타일 시트 표시</td></tr><tr><td ' . $Hhtml['cellColor'] . '>' . $bgUse . '</td></tr></table></td></tr></table></p>');
    out('</td></tr></table>');
}

function htmlEdit() {
    global $Hinput, $HidToNumber, $Hislands, $Hprofile, $Hhtml, $HbaseDir, $Hinit, $HdefaultID, $HdefaultPassword;
    $num = $HidToNumber[$Hinput['ID']];
    $timeString = ($Hprofile['lastModify'] != 0) ? timeToString($Hprofile['lastModify']) : '';
    $comment = str_replace('<br>', "\n", $Hprofile['comment']);
    out('<p><div align="right">갱신 시각 : ' . $timeString . '</div><div class="bar1"><div class="bar2">프로필 편집</div></div></p>');
    $editID = isset($Hinput['ID']) ? $Hinput['ID'] : $HdefaultID;
    out('<form action="' . $HbaseDir . '/' . $Hinit['thisFile'] . '?profile=' . $editID . '" method="POST"><div style="margin-left:2em">');
    out('※　프로필 설정은 모두 선택사항입니다. 내용이 모두 공개되기 때문에 주의해주세요.');
    out('<TABLE BORDER=0 CELLPADDING=1 CELLSPACING=0  ' . $Hhtml['lineColor'] . '><TR><TD><TABLE BORDER=0 CELLPADDING=1 CELLSPACING=1 WIDTH=100%>');
    out('<tr><td ' . $Hhtml['tdHeaderColor'] . '>섬의 이름</td><td ' . $Hhtml['cellColor'] . '>' . htmlspecialchars($Hislands[$num]['name'], ENT_QUOTES, 'UTF-8') . '섬</td></tr>');
    out('<tr><td ' . $Hhtml['tdHeaderColor'] . '>사용자의 이름</td><td ' . $Hhtml['cellColor'] . '>' . htmlspecialchars($Hislands[$num]['ownername'], ENT_QUOTES, 'UTF-8') . '</td></tr>');
    $fields = array('ADDRESS'=>'주소','AGE'=>'연령','JOB'=>'직업','EMAIL'=>'E-mail','ICQ'=>'ICQ','HPTITLE'=>'홈 페이지 타이틀','URL'=>'홈 페이지 URL','PHOTO'=>'사진이 있는 URL','HOMEIMAGE'=>'내 홈 이미지 URL','BGIMAGE'=>'자신의 배경 이미지 or 스타일 시트 URL');
    $values = array('ADDRESS'=>'address','AGE'=>'age','JOB'=>'job','EMAIL'=>'email','ICQ'=>'icq','HPTITLE'=>'webTitle','URL'=>'webAddress','PHOTO'=>'photo','HOMEIMAGE'=>'MyHomeImage','BGIMAGE'=>'BackgroundImage');
    foreach($fields as $name=>$label) {
        $key = $values[$name];
        $val = $Hprofile[$key];
        if(($name == 'URL' || $name == 'PHOTO') && $val == '') { $val = 'http://'; }
        out('<tr><td ' . $Hhtml['tdHeaderColor'] . '>' . $label . '</td><td ' . $Hhtml['cellColor'] . '><input type="text" name="' . $name . '" size=80 maxlength=80 value="' . htmlAttr($val) . '"></td></tr>');
        if($name == 'AGE') {
            out('<tr><td ' . $Hhtml['tdHeaderColor'] . '>성별</td><td ' . $Hhtml['cellColor'] . '>');
            out('<input type="radio" name="SEX" value="1"' . (($Hprofile['sex']==1)?' checked':'') . '>남성');
            out('<input type="radio" name="SEX" value="2"' . (($Hprofile['sex']==2)?' checked':'') . '>여성');
            out('<input type="radio" name="SEX" value="3"' . (($Hprofile['sex']!=1 && $Hprofile['sex']!=2)?' checked':'') . '>무회답</td></tr>');
        }
        if($name == 'BGIMAGE') {
            out('<tr><td ' . $Hhtml['tdHeaderColor'] . '>자신의 배경 이미지 or 스타일 시트 표시</td><td ' . $Hhtml['cellColor'] . '>');
            out('<input type="radio" name="BGIMAGEUSE" value="1"' . (($Hprofile['BackgroundUse']==1)?' checked':'') . '>ＯＮ');
            out('<input type="radio" name="BGIMAGEUSE" value="2"' . (($Hprofile['BackgroundUse']==2)?' checked':'') . '>ＯＦＦ</td></tr>');
        }
    }
    out('</table></td></tr></table>');
    out('<p>※자신의 배경 이미지 or 스타일 시트 URL는, 반드시 「http://」로부터 설정해 주세요. <br>이미지 파일을 지정하면 자신의 배경 이미지가 설정됩니다. <br>확장자(extension)가 「css」의 파일을 지정하면 자신의 스타일 시트가 설정됩니다. </p>');
    out('<TABLE BORDER=0 CELLPADDING=1 CELLSPACING=0  ' . $Hhtml['lineColor'] . '><TR><TD><TABLE BORDER=0 CELLPADDING=1 CELLSPACING=1 WIDTH=100%><tr><td ' . $Hhtml['tdHeaderColor'] . '>흥미·관심</td></tr><tr><td ' . $Hhtml['cellColor'] . '><textarea cols=50 rows=5 name="COMMENT">' . htmlAttr($comment) . '</textarea></td></tr></table></td></tr></table></p>');
    out('<p><TABLE BORDER=0 CELLPADDING=1 CELLSPACING=0  ' . $Hhtml['lineColor'] . '><TR><TD><TABLE BORDER=0 CELLPADDING=1 CELLSPACING=1 WIDTH=100%><tr><td ' . $Hhtml['tdHeaderColor'] . '>추천 사이트</td></tr><tr><td ' . $Hhtml['cellColor'] . '>');
    for($i=1; $i<=3; $i++) { $key='BestWebsite'.$i; $val=($Hprofile[$key] != '') ? $Hprofile[$key] : 'http://'; out($i . '. <input type="text" name="BESTWEB' . $i . '" size=80 maxlength=80 value="' . htmlAttr($val) . '"><br>'); }
    out('</td></tr></table></td></tr></table></p>');
    out('패스워드 : <input type="password" name="PASSWORD" size=32 maxlength=32 value="' . htmlAttr($HdefaultPassword) . '">');
    out('<input type="hidden" name="changeProfileButton" value="1"><input type="submit" value="변경"></div></form>');
}

function tempNoDataFile() { echo '데이터 파일이 없습니다.'; }
function tempWrongPassword() { echo '패스워드가 틀립니다.'; }
