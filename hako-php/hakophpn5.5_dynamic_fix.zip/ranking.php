<?php

if (!function_exists('ranking_log_path')) {
function ranking_log_path($file) {
    global $HlogdirName, $HdirName;
    $p = $HlogdirName . '/' . $file;
    if (file_exists($p)) { return $p; }
    $alt = $HdirName . '/' . $file;
    if (file_exists($alt)) { return $alt; }
    $alt2 = './' . $file;
    if (file_exists($alt2)) { return $alt2; }
    return $p;
}
}
if (!isset($_hako_fh)) { $_hako_fh = array(); }

if (!isset($GLOBALS['_hako_req_start'])) { $GLOBALS['_hako_req_start'] = microtime(true); }
if (!isset($GLOBALS['_hako_req_ru_start'])) { $GLOBALS['_hako_req_ru_start'] = function_exists('getrusage') ? getrusage() : null; }
if (!function_exists('hako_cpu_times')) {
function hako_cpu_times() {
    $startRu = isset($GLOBALS['_hako_req_ru_start']) ? $GLOBALS['_hako_req_ru_start'] : null;
    if (function_exists('getrusage') && is_array($startRu)) {
        $r = getrusage();
        $u0 = (isset($startRu['ru_utime.tv_sec']) ? $startRu['ru_utime.tv_sec'] : 0) + (isset($startRu['ru_utime.tv_usec']) ? $startRu['ru_utime.tv_usec'] : 0) / 1000000;
        $s0 = (isset($startRu['ru_stime.tv_sec']) ? $startRu['ru_stime.tv_sec'] : 0) + (isset($startRu['ru_stime.tv_usec']) ? $startRu['ru_stime.tv_usec'] : 0) / 1000000;
        $u1 = (isset($r['ru_utime.tv_sec']) ? $r['ru_utime.tv_sec'] : 0) + (isset($r['ru_utime.tv_usec']) ? $r['ru_utime.tv_usec'] : 0) / 1000000;
        $s1 = (isset($r['ru_stime.tv_sec']) ? $r['ru_stime.tv_sec'] : 0) + (isset($r['ru_stime.tv_usec']) ? $r['ru_stime.tv_usec'] : 0) / 1000000;
        $uti = max(0, $u1 - $u0);
        $sti = max(0, $s1 - $s0);
        return array(round($uti + $sti, 4), round($uti, 4), round($sti, 4));
    }
    $start = isset($GLOBALS['_hako_req_start']) ? $GLOBALS['_hako_req_start'] : (isset($_SERVER['REQUEST_TIME_FLOAT']) ? $_SERVER['REQUEST_TIME_FLOAT'] : microtime(true));
    $elapsed = microtime(true) - $start;
    if ($elapsed < 0) { $elapsed = 0; }
    return array(round($elapsed, 4), round($elapsed, 4), 0);
}
}
if (!function_exists('hako_open')) {
  function hako_open($name, $spec) {
    global $_hako_fh;
    $mode = 'r';
    $path = $spec;
    if (substr($path, 0, 2) === '>>') { $mode = 'a'; $path = substr($path, 2); }
    elseif (substr($path, 0, 1) === '>') { $mode = 'w'; $path = substr($path, 1); }
    elseif (substr($path, 0, 1) === '<') { $mode = 'r'; $path = substr($path, 1); }
    $_hako_fh[$name] = @fopen($path, $mode);
    return $_hako_fh[$name];
  }
  function hako_close($name) {
    global $_hako_fh;
    if (isset($_hako_fh[$name]) && $_hako_fh[$name]) { fclose($_hako_fh[$name]); }
  }
  function hako_getline($name) {
    global $_hako_fh;
    if (!isset($_hako_fh[$name]) || !$_hako_fh[$name]) { return false; }
    return fgets($_hako_fh[$name]);
  }
  function hako_write($name, $data) {
    global $_hako_fh;
    if (!isset($_hako_fh[$name]) || !$_hako_fh[$name]) { return false; }
    return fwrite($_hako_fh[$name], $data);
  }
  function hako_cmp($a, $b) {
    if ($a == $b) { return 0; }
    return ($a < $b) ? -1 : 1;
  }
  function hako_reorder($array, $idx) {
    $out = array();
    foreach ($idx as $i) { if (isset($array[$i])) { $out[] = $array[$i]; } }
    return $out;
  }
  function hako_pick($array, $keys) {
    $out = array();
    foreach ($keys as $key) { $out[] = isset($array[$key]) ? $array[$key] : null; }
    return $out;
  }
  function hako_idx($array, $idx) {
    return isset($array[$idx]) ? $array[$idx] : null;
  }
}
// #! /usr/bin/perl

//---------------------------------------------------------------------
//
//	괴수 격퇴 포인트＋획득 상금 랭킹표시
//
//	작성일 : 2001/02/271
//	작성자 : Watson <watson@catnip.freemail.ne.jp>
//
//	탭폭 : 4
//
//	구상의 모형정원 5.17용으로 독자 확장되어 있습니다.
//---------------------------------------------------------------------

//---------------------------------------------------------------------
//	초기설정
//---------------------------------------------------------------------
require_once "./hako-init.php";
require_once "./init-game.php";

//  gzip를 사용해 압축 전송해?  0 : 미사용  1 : 사용
$gzip = 0;

// gzip의 인스톨처
$pathGzip = '/usr/bin';

// 화면의 「돌아온다」링크처(URL)
$bye = $HthisFile;

// 랭킹 데이터의 취득 개시 턴
$start_turn = 1;

// 다른 도의 괴수를 넘어뜨렸을 경우의 포인트 가산율
$ExternalRate  = 0.5; # 반

// 미사일로 배를 넘어뜨렸을 경우의 포인트 가산율
$ExternalSRate  = 0.5; # 반

//----------------------------
//	HTML에 관한 설정
//----------------------------
// 브라우저의 타이틀 바의 명칭
$title = '모형정원 제도 랭킹';

// 화면의 색이나 배경의 설정(HTML)
$body = '<body>';

// 모두의 메세지(HTML 서식) 괴수 격퇴 랭킹용
$headKill = <<<EOF
<h2 class=head2>괴수 격퇴 랭킹</h2>
EOF;

// 모두의 메세지(HTML 서식) 상금 랭킹용?
$headMoney = <<<EOF
<h2 class=head2>상금 랭킹</h2>
EOF;

// 모두의 메세지(HTML 서식) 부문상 랭킹용
$headBumon = <<<EOF
<h2 class=head2>부문상 랭킹</h2>
EOF;

// 모두의 메세지(HTML 서식) 배격침 랭킹용
$headShip = <<<EOF
<h2 class=head2>배 격침 랭킹</h2>
EOF;

$headPointCellcolor	= 'class=headPointCellcolor';    # 겉(표)의 맨 위의 포인트 부분의 셀색
$headNameCellcolor	= 'class=headNameCellcolor';     # 그 아래의 괴수가 표시되고 있는 부분의 셀색
$pointCellcolor		= 'class=pointCellcolor';        # 포인트 부분의 셀색
$nameCellcolor		= 'class=nameCellcolor';         # 이름의 표시부 분의 셀색
$TotalPointColor	= 'class=TotalPointColor';       # 총점의 문자색
$PointColor			= 'class=PointColor';            # 개별의 포인트의 문자색
$ExternalPointColor	= 'class=ExternalPointColor';    # 다른 도의 괴수를 넘어뜨렸을 경우의 문자색

//여기까지-------------------------------------------------------------

array_splice($HmonsterName,32,0,'구상 이노라');
array_splice($HmonsterImage,32,0,'kinora.gif');

// 괴수 격퇴시 포인트
                   // 0  1  2  3  4  5  6  7  8  9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 35 36
$HmonsterPoint   = array( 5, 3, 3, 4, 4, 4, 5, 7, 6, 6, 9, 5,12,16,18, 6, 4,10,15,10,14,13, 5,12, 5, 5,10, 2, 4, 4,14,40,30,15,17,16,20);
array_splice($HshipImage,15,1,'ship163.gif');

// 배격침시 포인트
//                적수이탐거룩한 보물어어어룡류부객풍
$HshipPoint  = array( 6, 3, 6, 3,10,10,11, 5, 2, 3, 4,10, 4, 5, 4, 4);
// 배의 수
$HshipNumber = 16;

htmlHeader();

if(!(readIslandsFile())){
	out("<h2 class=head2>에러가 발생했습니다</h2>\n");
} else {
	if(!(calcKillPoint())){
		out("<H3>아직 괴수 격퇴 랭킹 데이터가 없습니다.</H3>\n");
	}else{
		htmlKillMonster();
		out("<p align=right><span $ExternalPointColor>(　)</span>안은 다른 도의 괴수를 퇴치한 수를 나타내고 있습니다. 포인트는 자신의 섬에 괴수를 퇴치한것의 절반이 가산됩니다. <BR>ST미사일로 퇴치한 괴수는 가산되지 않습니다.</p>");
	}
	if(!(calcMoney())){
		out("<H3>아직 상금 랭킹 데이터가 없습니다.</H3>\n");
	}else{
		htmlMoney();
		out("<p align=right>매장금등 에는 금광맥의 수입도 포함됩니다, 온천등에는, 유전(자금 생산시만), 정제장의 수입도 포함됩니다. </p>");
	}
	if(!(calcBumon())){
		out("<H3>아직 부문상 랭킹 데이터가 없습니다.</H3>\n");
	}else{
		htmlBumon();
		out("<BR><BR>");
	}
	if(!(calcShip())){
		out("<H3>아직 배격침 랭킹 데이터가 없습니다.</H3>\n");
	}else{
		htmlShip();
		out("<p align=right><span $ExternalPointColor>(　)</span>안은 미사일로 격침시킨 수를 나타내고 있습니다. 포인트는 배계로 배계를 격침시킨 것의 절반이 가산됩니다. <BR>ST미사일로 격침시킨 배계는 가산되지 않습니다. </p>");
		out("<BR><BR>");
	}
}
htmlFooter();
//종료
exit(0);

//써브루틴---------------------------------------------------------
//---------------------------------------------------------------------
//	함수명 : readIslandsFile
//	기능 : 도 전체의 데이터를 읽어들인다
//	인수 : 없음
//	반환값 : 0 - 파일 오픈에 실패
//	         1 - 성공
//---------------------------------------------------------------------
function readIslandsFile() {
  $_args = func_get_args();
  extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $HcssFile, $HeachBumon, $HeachMoney, $headBumon, $headKill, $headMoney, $headNameCellcolor, $headPointCellcolor, $headShip, $helpDir, $HidToNumber, $HislandNumber, $Hislands, $HislandTurn, $HkillExtPoint, $HkillPoint, $HmonsterImage, $HmonsterName, $HmonsterNumber, $HmonsterPoint, $HprizeV, $HshipImage, $HshipName, $HshipNumber, $HshipPoint, $HSkillExtPoint, $HSkillPoint, $HStotalPoint, $HthisFile, $HtotalBumon, $HtotalMoney, $HtotalPoint, $hturn, $HturnPrizeNumber, $HunitMoney, $imageDir, $lockMode, $toppage, $versionInfo;
  // 데이터 파일을 연다
  if(!hako_open('IN', "${HdirName}/hakojima.dat")) {
	rename("${HdirName}/hakojima.tmp", "${HdirName}/hakojima.dat");
	if (!hako_open('IN', "${HdirName}/hakojima.dat")) { return 0; }
  }

  //  각 파라미터의 읽어들여
  $HislandTurn	= intval(hako_getline('IN'));	# 턴수
  hako_getline('IN');	# 최종 갱신 시간(사용하지 않는 값이므로 읽어 날린다)

  $HislandNumber	= intval(hako_getline('IN'));	# 도의 총수
  hako_getline('IN');	# 다음에 할당하는 ID(사용하지 않는 값이므로 읽어 날린다)

  // 도의 읽어들여
  $i = null;
  for($i = 0; $i < $HislandNumber; $i++) {
	$Hislands[$i] = readIsland();
	$HidToNumber[$Hislands[$i]['id']] = $i;
  }

  //  파일을 닫는다
  hako_close('IN');

  return 1;
}

//---------------------------------------------------------------------
//	함수명 : readIsland
//	기능 : 각 도에 할당할 수 있고 있는 ID를 취득
//	인수 : 0 .. $HislandNumber
//	반환값 : 도의 ID
//---------------------------------------------------------------------
function readIsland() {
  $_args = func_get_args();
  extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $HcssFile, $HeachBumon, $HeachMoney, $headBumon, $headKill, $headMoney, $headNameCellcolor, $headPointCellcolor, $headShip, $helpDir, $HidToNumber, $HislandNumber, $Hislands, $HislandTurn, $HkillExtPoint, $HkillPoint, $HmonsterImage, $HmonsterName, $HmonsterNumber, $HmonsterPoint, $HprizeV, $HshipImage, $HshipName, $HshipNumber, $HshipPoint, $HSkillExtPoint, $HSkillPoint, $HStotalPoint, $HthisFile, $HtotalBumon, $HtotalMoney, $HtotalPoint, $hturn, $HturnPrizeNumber, $HunitMoney, $imageDir, $lockMode, $toppage, $versionInfo;
  $id = null; $name = null;
  $name = hako_getline('IN');
  preg_match('/(.*),(.*)/', $name, $_m);# 도의 이름
  $name = $_m[1];
  $id = intval(hako_getline('IN'));# ID번호

   // 파일 포인터를 진행시킬 뿐(만큼)이므로 name, ID 이외는 값을 격납하지 않는다
  hako_getline('IN');	# 사용자명
  hako_getline('IN');	# 수상
  hako_getline('IN');	# 연속 자금융통수
  hako_getline('IN');	# 코멘트
  hako_getline('IN');	# 암호화 패스워드
  hako_getline('IN');	# 자금
  hako_getline('IN');	# 식량
  hako_getline('IN');	# 인구
  hako_getline('IN');	# 넓이
  hako_getline('IN');	# 농장
  hako_getline('IN');	# 기후
  hako_getline('IN');	# 공장
  hako_getline('IN');	# 항구
  hako_getline('IN');	# 채굴장;
  hako_getline('IN');	# 상업지
  hako_getline('IN');	# 양식장
  $turnsu   = hako_getline('IN'); # 이월을 제외한 그 도의 턴수, 순위점, 개시 턴
  $hturn = preg_split("/,/", $turnsu);
  hako_getline('IN');	# 
  hako_getline('IN');	# 미사일 발사 가능수
  hako_getline('IN');	# 발사 미사일 총수
  hako_getline('IN');	# 선물
  hako_getline('IN');	# 경험 획득수
  hako_getline('IN');	# 부문상
  hako_getline('IN');	# 
  hako_getline('IN');
  hako_getline('IN');
  hako_getline('IN');
  hako_getline('IN');
  hako_getline('IN');
  hako_getline('IN');
  hako_getline('IN');
  hako_getline('IN');
  hako_getline('IN');
  return array(
	'name' => $name,
	'id' => $id,
	'sturn' => intval($hturn[2]),
  );
}


//---------------------------------------------------------------------
//	함수명 : calcKillPoint
//	기능 : 괴수 격퇴 포인트를 계산
//	인수 : 없음
//	반환값 : 0 - 파일 오픈 에러
//	         1 - 성공
//---------------------------------------------------------------------
function calcKillPoint() {
  extract($GLOBALS, EXTR_SKIP);
  global $HlogdirName, $HidToNumber, $HislandNumber, $Hislands, $HmonsterName, $HmonsterNumber, $HmonsterPoint, $ExternalRate;
  global $HkillExtPoint, $HkillPoint, $HtotalPoint, $Kisland;
  $HkillExtPoint = array(); $HkillPoint = array(); $HtotalPoint = array();
  for ($ii = 0; $ii < $HislandNumber; $ii++) {
    $HtotalPoint[$ii] = 0;
    $HkillPoint[$ii] = array();
    $HkillExtPoint[$ii] = array();
    for ($jj = 0; $jj <= $HmonsterNumber; $jj++) {
      $HkillPoint[$ii][$jj] = 0;
      $HkillExtPoint[$ii][$jj] = 0;
    }
  }
  if (!hako_open('LIN', ranking_log_path('ranking.log'))) { return 0; }

  while (($line = hako_getline('LIN')) !== false) {
    if (!preg_match('/^([0-9]*),([0-9]*),([0-9]*),(.*)$/', rtrim($line), $_m)) { continue; }
    $turn    = intval($_m[1]);
    $id1     = $_m[2];
    $id2     = $_m[3];
    $monster = $_m[4];

    if (!isset($HidToNumber[$id1])) { continue; }
    $num = $HidToNumber[$id1];
    if ($num === '' || !isset($Hislands[$num])) { continue; }
    $island = $Hislands[$num];
    if ($turn <= $island['sturn']) { continue; }

    $i = 0;
    while($i <= $HmonsterNumber && (!isset($HmonsterName[$i]) || $HmonsterName[$i] != $monster)){
      $i++;
    }
    if (!isset($HmonsterPoint[$i])) { $HmonsterPoint[$i] = 0; }
    if($id1 != $id2){
      $HkillExtPoint[$num][$i]++;
      $HtotalPoint[$num] += $HmonsterPoint[$i] * $ExternalRate;
    }else{
      $HkillPoint[$num][$i]++;
      $HtotalPoint[$num] += $HmonsterPoint[$i];
    }
  }
  hako_close('LIN');

  $idx = ($HislandNumber > 0) ? range(0, $HislandNumber - 1) : array();
  usort($idx, function($a, $b) { global $HtotalPoint; $av = isset($HtotalPoint[$a]) ? $HtotalPoint[$a] : 0; $bv = isset($HtotalPoint[$b]) ? $HtotalPoint[$b] : 0; $c = hako_cmp($bv, $av); return ($c != 0) ? $c : hako_cmp($a, $b); });
  $HtotalPoint = hako_reorder($HtotalPoint, $idx);
  $HkillPoint = hako_reorder($HkillPoint, $idx);
  $HkillExtPoint = hako_reorder($HkillExtPoint, $idx);
  $Kisland = hako_reorder($Hislands, $idx);
  $GLOBALS['HtotalPoint'] = $HtotalPoint;
  $GLOBALS['HkillPoint'] = $HkillPoint;
  $GLOBALS['HkillExtPoint'] = $HkillExtPoint;
  $GLOBALS['Kisland'] = $Kisland;

  return 1;
}
function calcMoney() {
  extract($GLOBALS, EXTR_SKIP);
  global $HlogdirName, $HidToNumber, $HislandNumber, $Hislands;
  global $HeachMoney, $HtotalMoney, $Misland;
  $HeachMoney = array(); $HtotalMoney = array();
  for ($ii = 0; $ii < $HislandNumber; $ii++) { $HeachMoney[$ii] = array(); $HtotalMoney[$ii] = 0; }
  if (!hako_open('MIN', "${HlogdirName}/money.log")) { return 0; }
  while (($line = hako_getline('MIN')) !== false) {
    if (!preg_match('/^([0-9]*),([0-9]*),(.*),([0-9]*)$/', rtrim($line), $_m)) { continue; }
    $turn  = intval($_m[1]);
    $id    = $_m[2];
    $kind  = $_m[3];
    $money = intval($_m[4]);

    if (!isset($HidToNumber[$id])) { continue; }
    $num = $HidToNumber[$id];
    if ($num === '' || !isset($Hislands[$num])) { continue; }
    $island = $Hislands[$num];
    if ($turn <= $island['sturn']) { continue; }
    if (!isset($HeachMoney[$num][$kind])) { $HeachMoney[$num][$kind] = 0; }
    $HeachMoney[$num][$kind] += $money;
    $HtotalMoney[$num] += $money;
  }
  hako_close('MIN');
  
  $idx = ($HislandNumber > 0) ? range(0, $HislandNumber - 1) : array();
  usort($idx, function($a, $b) { global $HtotalMoney; $av = isset($HtotalMoney[$a]) ? $HtotalMoney[$a] : 0; $bv = isset($HtotalMoney[$b]) ? $HtotalMoney[$b] : 0; $c = hako_cmp($bv, $av); return ($c != 0) ? $c : hako_cmp($a, $b); });
  $HtotalMoney = hako_reorder($HtotalMoney, $idx);
  $HeachMoney = hako_reorder($HeachMoney, $idx);
  $Misland = hako_reorder($Hislands, $idx);
  $GLOBALS['HtotalMoney'] = $HtotalMoney;
  $GLOBALS['HeachMoney'] = $HeachMoney;
  $GLOBALS['Misland'] = $Misland;

  return 1;
}
function calcBumon() {
  extract($GLOBALS, EXTR_SKIP);
  global $HlogdirName, $HidToNumber, $HislandNumber, $Hislands;
  global $HeachBumon, $HtotalBumon, $Bisland;
  $HeachBumon = array(); $HtotalBumon = array();
  for ($ii = 0; $ii < $HislandNumber; $ii++) { $HeachBumon[$ii] = array(); $HtotalBumon[$ii] = 0; }
  if (!hako_open('MIN', "${HlogdirName}/bumon.log")) { return 0; }
  while (($line = hako_getline('MIN')) !== false) {
    if (!preg_match('/^([0-9]*),([0-9]*),(.*),(.*)$/', rtrim($line), $_m)) { continue; }
    $turn  = intval($_m[1]);
    $id    = $_m[2];
    $kind  = $_m[3];

    if (!isset($HidToNumber[$id])) { continue; }
    $num = $HidToNumber[$id];
    if ($num === '' || !isset($Hislands[$num])) { continue; }
    $island = $Hislands[$num];
    if ($turn <= $island['sturn']) { continue; }
    if (!isset($HeachBumon[$num][$kind])) { $HeachBumon[$num][$kind] = 0; }
    $HeachBumon[$num][$kind]++;
    $HtotalBumon[$num]++;
  }
  hako_close('MIN');
  
  $idx = ($HislandNumber > 0) ? range(0, $HislandNumber - 1) : array();
  usort($idx, function($a, $b) { global $HtotalBumon; $av = isset($HtotalBumon[$a]) ? $HtotalBumon[$a] : 0; $bv = isset($HtotalBumon[$b]) ? $HtotalBumon[$b] : 0; $c = hako_cmp($bv, $av); return ($c != 0) ? $c : hako_cmp($a, $b); });
  $HtotalBumon = hako_reorder($HtotalBumon, $idx);
  $HeachBumon = hako_reorder($HeachBumon, $idx);
  $Bisland = hako_reorder($Hislands, $idx);
  $GLOBALS['HtotalBumon'] = $HtotalBumon;
  $GLOBALS['HeachBumon'] = $HeachBumon;
  $GLOBALS['Bisland'] = $Bisland;

  return 1;
}
function calcShip() {
  extract($GLOBALS, EXTR_SKIP);
  global $HlogdirName, $HidToNumber, $HislandNumber, $Hislands, $HshipNumber, $HshipPoint, $ExternalSRate;
  global $HSkillExtPoint, $HSkillPoint, $HStotalPoint, $Sisland;
  $HSkillExtPoint = array(); $HSkillPoint = array(); $HStotalPoint = array();
  for ($ii = 0; $ii < $HislandNumber; $ii++) {
    $HStotalPoint[$ii] = 0;
    $HSkillPoint[$ii] = array();
    $HSkillExtPoint[$ii] = array();
    for ($jj = 0; $jj < $HshipNumber; $jj++) {
      $HSkillPoint[$ii][$jj] = 0;
      $HSkillExtPoint[$ii][$jj] = 0;
    }
  }
  if (!hako_open('LIN', "${HlogdirName}/ship.log")) { return 0; }

  while (($line = hako_getline('LIN')) !== false) {
    if (!preg_match('/^([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/', rtrim($line), $_m)) { continue; }
    $turn = intval($_m[1]);
    $id1  = $_m[2];
    $id2  = $_m[3];
    $ship = intval($_m[4]);

    if (!isset($HidToNumber[$id1])) { continue; }
    $num = $HidToNumber[$id1];
    if ($num === '' || !isset($Hislands[$num])) { continue; }
    $island = $Hislands[$num];
    if ($turn <= $island['sturn']) { continue; }

    if ($ship >= $HshipNumber) { $ship = 0; }
    if (!isset($HshipPoint[$ship])) { $HshipPoint[$ship] = 0; }
    if($id2 == 99){
      $HSkillExtPoint[$num][$ship]++;
      $HStotalPoint[$num] += $HshipPoint[$ship] * $ExternalSRate;
    }else{
      $HSkillPoint[$num][$ship]++;
      $HStotalPoint[$num] += $HshipPoint[$ship];
    }
  }
  hako_close('LIN');

  $idx = ($HislandNumber > 0) ? range(0, $HislandNumber - 1) : array();
  usort($idx, function($a, $b) { global $HStotalPoint; $av = isset($HStotalPoint[$a]) ? $HStotalPoint[$a] : 0; $bv = isset($HStotalPoint[$b]) ? $HStotalPoint[$b] : 0; $c = hako_cmp($bv, $av); return ($c != 0) ? $c : hako_cmp($a, $b); });
  $HStotalPoint = hako_reorder($HStotalPoint, $idx);
  $HSkillPoint = hako_reorder($HSkillPoint, $idx);
  $HSkillExtPoint = hako_reorder($HSkillExtPoint, $idx);
  $Sisland = hako_reorder($Hislands, $idx);
  $GLOBALS['HStotalPoint'] = $HStotalPoint;
  $GLOBALS['HSkillPoint'] = $HSkillPoint;
  $GLOBALS['HSkillExtPoint'] = $HSkillExtPoint;
  $GLOBALS['Sisland'] = $Sisland;

  return 1;
}
function out() {
  $_args = func_get_args();
  extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $HcssFile, $HeachBumon, $HeachMoney, $headBumon, $headKill, $headMoney, $headNameCellcolor, $headPointCellcolor, $headShip, $helpDir, $HidToNumber, $HislandNumber, $Hislands, $HislandTurn, $HkillExtPoint, $HkillPoint, $HmonsterImage, $HmonsterName, $HmonsterNumber, $HmonsterPoint, $HprizeV, $HshipImage, $HshipName, $HshipNumber, $HshipPoint, $HSkillExtPoint, $HSkillPoint, $HStotalPoint, $HthisFile, $HtotalBumon, $HtotalMoney, $HtotalPoint, $hturn, $HturnPrizeNumber, $HunitMoney, $imageDir, $lockMode, $toppage, $versionInfo;
  print $_args[0];
}

//---------------------------------------------------------------------
//	함수명 : htmlHeader
//	기능 : HTML의 헤더 부분을 출력
//	인수 : 없음
//	반환값 : 없음
//---------------------------------------------------------------------
function htmlHeader() {
  $_args = func_get_args();
  extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $HcssFile, $HeachBumon, $HeachMoney, $headBumon, $headKill, $headMoney, $headNameCellcolor, $headPointCellcolor, $headShip, $helpDir, $HidToNumber, $HislandNumber, $Hislands, $HislandTurn, $HkillExtPoint, $HkillPoint, $HmonsterImage, $HmonsterName, $HmonsterNumber, $HmonsterPoint, $HprizeV, $HshipImage, $HshipName, $HshipNumber, $HshipPoint, $HSkillExtPoint, $HSkillPoint, $HStotalPoint, $HthisFile, $HtotalBumon, $HtotalMoney, $HtotalPoint, $hturn, $HturnPrizeNumber, $HunitMoney, $imageDir, $lockMode, $toppage, $versionInfo;
	if(preg_match('/gzip/', $_SERVER['HTTP_ACCEPT_ENCODING']) && $gzip == 1){
		if (!headers_sent()) {
			header('Content-Type: text/html; charset=UTF-8');
			header('Content-Encoding: gzip');
		}
		hako_open('STDOUT',"| $pathGzip/gzip -1 -c");
		if (preg_match('/MSIE/', $_SERVER['HTTP_USER_AGENT'], $_m)) { print str_repeat(" ", 2048);  }
		print '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">' . "\n\n";
	}else{
		if (!headers_sent()) { header('Content-Type: text/html; charset=UTF-8'); }
		print '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">' . "\n\n";
	}
	$skinName = "";
	$cookie = isset($_SERVER['HTTP_COOKIE']) ? $_SERVER['HTTP_COOKIE'] : '';
	if (preg_match('/(?:^|;\s*)[^;=]*SKIN=\(([^\)]*)\)/', $cookie, $_m)) {
		$skinName = $_m[1];
	} elseif (preg_match('/(?:^|;\s*)[^;=]*SKIN=([^;]*)/', $cookie, $_m)) {
		$skinName = trim($_m[1]);
	}
	$skinName = ($skinName != '') ? "$skinName" : "$HcssFile";
	out(<<<END
<HTML><HEAD>
<TITLE>$title</TITLE>
<base href="$imageDir/">
<link rel="stylesheet" type="text/css" href="$skinName">
</HEAD>
<DIV ID='BodySpecial'><DIV ID='LinkHead'></DIV><DIV ID='LinkTop'>
$body
<A HREF="$bye">[${start_turn}턴]</A></DIV>
END
);
}
//---------------------------------------------------------------------
//	함수명 : htmlFooter
//	기능 : HTML의 footer 부분을 출력
//	인수 : 없음
//	반환값 : 없음
//---------------------------------------------------------------------
function htmlFooter() {
  $_args = func_get_args();
  extract($GLOBALS, EXTR_SKIP);
  global $adminName, $AfterName, $bbs, $bbs2, $Body, $email, $HcssFile, $HeachBumon, $HeachMoney, $headBumon, $headKill, $headMoney, $headNameCellcolor, $headPointCellcolor, $headShip, $helpDir, $HidToNumber, $HislandNumber, $Hislands, $HislandTurn, $HkillExtPoint, $HkillPoint, $HmonsterImage, $HmonsterName, $HmonsterNumber, $HmonsterPoint, $HprizeV, $HshipImage, $HshipName, $HshipNumber, $HshipPoint, $HSkillExtPoint, $HSkillPoint, $HStotalPoint, $HthisFile, $HtotalBumon, $HtotalMoney, $HtotalPoint, $hturn, $HturnPrizeNumber, $HunitMoney, $imageDir, $lockMode, $toppage, $versionInfo;
	list($cpu, $uti, $sti) = hako_cpu_times();
	out(<<<END
<P>
어느 랭킹도 한 번에 복수 증가하는 현상이 이따금 발생합니다만, 수정은 곤란하기 때문에 랜덤으로 받을 수 있는 보너스라고 생각해 주세요. <BR>
${HislandTurn}턴 시점(${start_turn}턴 부터 데이터를 취득)<BR></P><BR>
<DIV align="right"><SMALL>CPU($cpu) : user($uti) system($sti)</SMALL></DIV>
<P><I><A HREF="http://club.www.infoseek.co.jp/club.asp?cid=j1100037">Scripted By Watson</A></I></P>
<P></DIV></DIV>
</BODY></HTML>
END
);
}
//---------------------------------------------------------------------
//	함수명 : htmlKillMonster
//	기능 : HTML의 괴수 격퇴 부분을 출력
//	인수 : 없음
//	반환값 : 없음
//---------------------------------------------------------------------
function htmlKillMonster() {
  extract($GLOBALS, EXTR_SKIP);
  global $HislandNumber, $Kisland, $HtotalPoint, $HkillPoint, $HkillExtPoint;
  global $HmonsterNumber, $HmonsterPoint, $HmonsterImage, $HmonsterName;
  global $headKill, $headPointCellcolor, $headNameCellcolor, $nameCellcolor, $pointCellcolor, $TotalPointColor, $ExternalPointColor;
  out(<<<END
$headKill
<TABLE BORDER=0 CELLPADDING=1 CELLSPACING=0 WIDTH=100% BGCOLOR="#000000"><TR><TD>
<TABLE BORDER=0 CELLPADDING=1 CELLSPACING=1 WIDTH=100%>
<TR>
<TD $headPointCellcolor NOWRAP>&nbsp;</TD>
<TD $headPointCellcolor NOWRAP>포인트</TD>
END
);
  for($i = 1; $i <= $HmonsterNumber; $i++){
    out("<TD $headPointCellcolor NOWRAP>{$HmonsterPoint[$i]}</TD>\n");
  }
  out("<TD $headPointCellcolor NOWRAP>{$HmonsterPoint[0]}</TD></TR>\n");
  out("<TR><TD $headNameCellcolor NOWRAP>섬의 이름</TD>\n");
  out("<TD $headNameCellcolor NOWRAP><span $TotalPointColor>포인트</span></TD>");
  for($i = 1; $i <= $HmonsterNumber; $i++){
    out("<TD $headNameCellcolor NOWRAP><IMG SRC=\"{$HmonsterImage[$i]}\" width=24 height=24 ALT=\"{$HmonsterName[$i]}\" TITLE=\"{$HmonsterName[$i]}\"></TD>\n");
  }
  out("<TD $headNameCellcolor NOWRAP><IMG SRC=\"{$HmonsterImage[0]}\" width=24 height=24 ALT=\"{$HmonsterName[0]}\" TITLE=\"{$HmonsterName[0]}\"></TD></TR>\n");

  for($i = 0; $i < $HislandNumber; $i++){
    $iname = isset($Kisland[$i]['name']) ? $Kisland[$i]['name'] : '';
    out("<TR><TD $nameCellcolor NOWRAP>{$iname}섬</TD>\n");
    $total = isset($HtotalPoint[$i]) ? $HtotalPoint[$i] : 0;
    if($total){ out("<TD $pointCellcolor NOWRAP><span $TotalPointColor>{$total}</span></TD>\n"); }
    else { out("<TD></TD>\n"); }
    for($j = 1; $j <= $HmonsterNumber; $j++){
      $kp = isset($HkillPoint[$i][$j]) ? $HkillPoint[$i][$j] : 0;
      $kep = isset($HkillExtPoint[$i][$j]) ? $HkillExtPoint[$i][$j] : 0;
      if($kep){ out("<TD $pointCellcolor NOWRAP>{$kp}<span $ExternalPointColor>({$kep})</span></TD>\n"); }
      elseif($kp){ out("<TD $pointCellcolor NOWRAP>{$kp}</TD>\n"); }
      else { out("<TD></TD>\n"); }
    }
    $kp = isset($HkillPoint[$i][0]) ? $HkillPoint[$i][0] : 0;
    $kep = isset($HkillExtPoint[$i][0]) ? $HkillExtPoint[$i][0] : 0;
    if($kep){ out("<TD $pointCellcolor NOWRAP>{$kp}<span $ExternalPointColor>({$kep})</span></TD>\n"); }
    elseif($kp){ out("<TD $pointCellcolor NOWRAP>{$kp}</TD>\n"); }
    else { out("<TD></TD>\n"); }
    out("</TR>\n");
  }
  out(<<<END
</TABLE>
</TD></TR></TABLE>
END
);
}
function htmlMoney() {
  extract($GLOBALS, EXTR_SKIP);
  global $HislandNumber, $Misland, $HtotalMoney, $HeachMoney, $HunitMoney;
  global $headMoney, $headNameCellcolor, $nameCellcolor, $pointCellcolor, $TotalPointColor;
  out(<<<END
$headMoney
<TABLE BORDER=0 CELLPADDING=1 CELLSPACING=0 WIDTH=100% BGCOLOR="#000000"><TR><TD>
<TABLE BORDER=0 CELLPADDING=1 CELLSPACING=1 WIDTH=100%>
<TR>
<TD $headNameCellcolor NOWRAP>섬의 이름</TD>
<TD $headNameCellcolor NOWRAP><span $TotalPointColor>총획득 상금액</span></TD>
<TD $headNameCellcolor NOWRAP>괴수 격퇴</TD>
<TD $headNameCellcolor NOWRAP>매장금등</TD>
<TD $headNameCellcolor NOWRAP>온천등</TD>
<TD $headNameCellcolor NOWRAP>보물선</TD>
<TD $headNameCellcolor NOWRAP>바람배</TD>
<TD $headNameCellcolor NOWRAP>트럼프</TD>
</TR>
END
);
  $keys = array('괴수 격파','매장금','온천','보물선','바람배','트럼프');
  for($i = 0; $i < $HislandNumber; $i++){
    $iname = isset($Misland[$i]['name']) ? $Misland[$i]['name'] : '';
    out("<TR><TD $nameCellcolor NOWRAP>{$iname}도</TD>\n");
    $total = isset($HtotalMoney[$i]) ? $HtotalMoney[$i] : 0;
    if($total){ out("<TD $pointCellcolor NOWRAP><span $TotalPointColor>{$total}$HunitMoney</span></TD>\n"); }
    else { out("<TD></TD>\n"); }
    foreach ($keys as $key) {
      $val = isset($HeachMoney[$i][$key]) ? $HeachMoney[$i][$key] : 0;
      if($val){ out("<TD $pointCellcolor NOWRAP><span $TotalPointColor>{$val}$HunitMoney</span></TD>\n"); }
      else { out("<TD></TD>\n"); }
    }
    out("</TR>\n");
  }
  out(<<<END
</TABLE>
</TD></TR></TABLE>
END
);
}
function htmlBumon() {
  extract($GLOBALS, EXTR_SKIP);
  global $HislandNumber, $Bisland, $HtotalBumon, $HeachBumon, $HturnPrizeNumber, $HprizeV;
  global $headBumon, $headNameCellcolor, $nameCellcolor, $pointCellcolor, $TotalPointColor;
  out(<<<END
$headBumon
<TABLE BORDER=0 CELLPADDING=1 CELLSPACING=0 WIDTH=100% BGCOLOR="#000000"><TR><TD>
<TABLE BORDER=0 CELLPADDING=1 CELLSPACING=1 WIDTH=100%>
<TR>
<TD $headNameCellcolor NOWRAP>섬의 이름</TD>
<TD $headNameCellcolor NOWRAP><span $TotalPointColor>총 부문상수</span></TD>
END
);
  for($i = 1; $i <= $HturnPrizeNumber; $i++){
    out("<TD $headNameCellcolor NOWRAP><IMG SRC=\"Vprize{$i}.gif\">{$HprizeV[$i]}</TD>\n");
  }
  out("</TR>");
  for($i = 0; $i < $HislandNumber; $i++){
    $iname = isset($Bisland[$i]['name']) ? $Bisland[$i]['name'] : '';
    out("<TR><TD $nameCellcolor NOWRAP>{$iname}섬</TD>\n");
    $total = isset($HtotalBumon[$i]) ? $HtotalBumon[$i] : 0;
    if($total){ out("<TD $pointCellcolor NOWRAP><span $TotalPointColor>{$total}</span></TD>\n"); }
    else { out("<TD></TD>\n"); }
    for($j = 1; $j <= $HturnPrizeNumber; $j++){
      $key = isset($HprizeV[$j]) ? $HprizeV[$j] : '';
      $bumondata = ($key !== '' && isset($HeachBumon[$i][$key])) ? $HeachBumon[$i][$key] : 0;
      if($bumondata){ out("<TD $pointCellcolor NOWRAP>$bumondata</TD>\n"); }
      else { out("<TD></TD>\n"); }
    }
    out("</TR>\n");
  }
  out(<<<END
</TABLE>
</TD></TR></TABLE>
END
);
}
function htmlShip() {
  extract($GLOBALS, EXTR_SKIP);
  global $HislandNumber, $Sisland, $HStotalPoint, $HSkillPoint, $HSkillExtPoint;
  global $HshipNumber, $HshipPoint, $HshipImage, $HshipName;
  global $headShip, $headPointCellcolor, $headNameCellcolor, $nameCellcolor, $pointCellcolor, $TotalPointColor, $ExternalPointColor;
  out(<<<END
$headShip
<TABLE BORDER=0 CELLPADDING=1 CELLSPACING=0 WIDTH=100% BGCOLOR="#000000"><TR><TD>
<TABLE BORDER=0 CELLPADDING=1 CELLSPACING=1 WIDTH=100%>
<TR>
<TD $headPointCellcolor NOWRAP>&nbsp;</TD>
<TD $headPointCellcolor NOWRAP>포인트</TD>
END
);
  for($i = 0; $i < $HshipNumber; $i++){
    if (($i > 3) && ($i < 6)) { continue; }
    out("<TD $headPointCellcolor NOWRAP>{$HshipPoint[$i]}</TD>\n");
  }
  out("<TR><TD $headNameCellcolor NOWRAP>섬의 이름</TD>\n");
  out("<TD $headNameCellcolor NOWRAP><span $TotalPointColor>포인트</span></TD>");
  for($i = 0; $i < $HshipNumber; $i++){
    if (($i > 3) && ($i < 6)) { continue; }
    out("<TD $headNameCellcolor NOWRAP><IMG SRC=\"{$HshipImage[$i]}\" ALT=\"{$HshipName[$i]}\" TITLE=\"{$HshipName[$i]}\"></TD>\n");
  }
  for($i = 0; $i < $HislandNumber; $i++){
    $iname = isset($Sisland[$i]['name']) ? $Sisland[$i]['name'] : '';
    out("<TR><TD $nameCellcolor NOWRAP>{$iname}섬</TD>\n");
    $total = isset($HStotalPoint[$i]) ? $HStotalPoint[$i] : 0;
    if($total){ out("<TD $pointCellcolor NOWRAP><span $TotalPointColor>{$total}</span></TD>\n"); }
    else { out("<TD></TD>\n"); }
    for($j = 0; $j < $HshipNumber; $j++){
      if (($j > 3) && ($j < 6)) { continue; }
      $sp = isset($HSkillPoint[$i][$j]) ? $HSkillPoint[$i][$j] : 0;
      $sep = isset($HSkillExtPoint[$i][$j]) ? $HSkillExtPoint[$i][$j] : 0;
      if($sep){ out("<TD $pointCellcolor NOWRAP>{$sp}<span $ExternalPointColor>({$sep})</span></TD>\n"); }
      elseif($sp){ out("<TD $pointCellcolor NOWRAP>{$sp}</TD>\n"); }
      else { out("<TD></TD>\n"); }
    }
    out("</TR>\n");
  }
  out(<<<END
</TABLE>
</TD></TR></TABLE>
END
);
}
