<?php
if (!defined('GZIP')) { define('GZIP', false); }
/*******************************************************************

  상정제도 2 for PHP

  
  $Id: hako-html.php, v 1.12 2004/08/10 22:00:41 Watson Exp $

*******************************************************************/

if(GZIP == true) {
  // gzip 압축 전송용
  require_once "HTTP/Compress.php";
  $http = new HTTP_Compress;
}

//--------------------------------------------------------------------
class HTML {

  //---------------------------------------------------
  // HTML 헤더 출력
  //---------------------------------------------------
  static function header($data = "") {
    global $init, $PRODUCT_VERSION, $http;

    // 압축 전송
    if(GZIP == true) {
      $http->start();
    }
    header("X-Product-Version: {$PRODUCT_VERSION}");
    $css = (empty($data['defaultSkin'])) ? $init->cssList[0] : $data['defaultSkin'];
    print <<<END
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html lang="ja">
<head>
<base href="{$init->imgDir}/">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<link rel="stylesheet" type="text/css" href="{$init->cssDir}/{$css}">
<title>{$init->title}</title>
<script type="text/javascript" src="{$init->baseDir}/hako-js.php"></script>
</head>
<body>

<div id="LinkHeader">
<a href="http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html">상정제도 스크립트 배포원</a> 
<a href="http://scrlab.g-7.ne.jp/">[PHP]</a> 　
<a href="http://AFresh.ub.to" target="_blank"><font color=blue>[한글화 배포처]</font></a>　
[<a href="{$GLOBALS['THIS_FILE']}?mode=conf">섬의 등록·설정 변경</a> ]
</div>
<hr>

END;
  }
  //---------------------------------------------------
  // HTML footer 출력
  //---------------------------------------------------
  static function footer() {
    global $init, $http;

    print <<<END
<hr>
<div id="LinkFoot">
관리자：{$init->adminName}(<a href="mailto:{$init->adminEmail}">{$init->adminEmail}</a> )<br>
게시판：(<a href="{$init->urlBbs}">{$init->urlBbs}</a> )<br>
탑 페이지：(<a href="{$init->urlTopPage}">{$init->urlTopPage}</a> )
</div>
</body>
</html>

END;

    if(GZIP == true) {
      $http->output();
    }
  }
  //---------------------------------------------------
  // 최종 갱신 시각 ＋ 다음 턴 갱신 시각 출력
  //---------------------------------------------------
  function lastModified($hako) {
    global $init;
    $timeString = date("Y년 m월 d일　H시", $hako->islandLastTime);
    print <<<END
<h2 class="lastModified">최종 갱신 시간 : $timeString
<span style="font-weight: normal;">
(다음의 턴까지, 나머지
<script type="text/javascript"> <!--
 var nextTime = $hako->islandLastTime + $init->unitTime;
 remainTime(nextTime);
//-->
</script>
</span>
</h2>

END;
   }
}
//--------------------------------------------------------------------
class HtmlTop extends HTML {
  //---------------------------------------------------
  // TOP 페이지
  //---------------------------------------------------
  function main($hako, $data) {
    global $init;

    // 최종 갱신 시각 ＋ 다음 턴 갱신 시각 출력
    $this->lastModified($hako);
    if(empty($data['defaultDevelopeMode']) || $data['defaultDevelopeMode'] == "cgi") {
      $radio = "checked"; $radio2 = "";
    } else {
      $radio = ""; $radio2 = "checked";
    }

    print "<h1>{$init->title}</h1>\n";
    if(DEBUG == true) {
      print <<<END
<form action="{$GLOBALS['THIS_FILE']}" method="post">
<input type="hidden" name="mode" value="debugTurn">
<input type="submit" value="턴을 진행시킨다">
</form>

END;
  }
    print <<<END
<h2 class='Turn'>턴 $hako->islandTurn</h2>
<hr>
<div id="MyIsland">
<h2>자신의 섬으로</h2>
<form action="{$GLOBALS['THIS_FILE']}" method="post">
자신의 섬의 이름은?<br>
<select name="ISLANDID">
$hako->islandList
</select>
<br>
패스워드를 부탁합니다!<br>
<input type="password" name="PASSWORD" value="{$data['defaultPassword']}" size="32" maxlength="32"><br>
<input type="hidden" name="mode" value="owner">
<input type="radio" name="DEVELOPEMODE" value="cgi" id="cgi" $radio><label for="cgi">통상 모드</label>
<input type="radio" name="DEVELOPEMODE" value="java" id="java" $radio2><label for="java">Java 스크립트 모드</label><BR>
<input type="submit" value="개발하러 간다">
</form>
</div>
<hr>

<div ID="IslandView">
<h2>제도의 상황</h2>
<p>
섬의 이름을 클릭하면,<strong>관광</strong>하러 갈 수 있습니다.
</p>
<table border="1">
<tr>
<th {$init->bgTitleCell}>{$init->tagTH_}순위{$init->_tagTH}</th>
<th {$init->bgTitleCell}>{$init->tagTH_}섬{$init->_tagTH}</th>
<th {$init->bgTitleCell}>{$init->tagTH_}인구{$init->_tagTH}</th>
<th {$init->bgTitleCell}>{$init->tagTH_}면적{$init->_tagTH}</th>
<th {$init->bgTitleCell}>{$init->tagTH_}자금{$init->_tagTH}</th>
<th {$init->bgTitleCell}>{$init->tagTH_}식료{$init->_tagTH}</th>
<th {$init->bgTitleCell}>{$init->tagTH_}농장 규모{$init->_tagTH}</th>
<th {$init->bgTitleCell}>{$init->tagTH_}공장 규모{$init->_tagTH}</th>
<th {$init->bgTitleCell}>{$init->tagTH_}채굴장 규모{$init->_tagTH}</th>
</tr>

END;
    for($i = 0; $i < $hako->islandNumber; $i++) {
      $island = $hako->islands[$i];
      $j = $i + 1;
      $id    = $island['id'];
      $pop   = $island['pop'] . $init->unitPop;
      $area  = $island['area'] . $init->unitArea;
      $money = Util::aboutMoney($island['money']);
      $food  = $island['food'] . $init->unitFood;
      $farm  = ($island['farm'] <= 0) ? "보유하지 않음" : $island['farm'] * 10 . $init->unitPop;
      $factory  = ($island['factory'] <= 0) ? "보유하지 않음" : $island['factory'] * 10 . $init->unitPop;
      $mountain = ($island['mountain'] <= 0) ? "보유하지 않음" : $island['mountain'] * 10 . $init->unitPop;
      $comment  = $island['comment'];
      $comment_turn = $island['comment_turn'];
      $monster = '';
      if($island['monster'] > 0) {
        $monster = "<strong class=\"monster\">[괴수{$island['monster']}몸]</strong>";
      }
      
      $name = "";
      if($island['absent']  == 0) {
        $name = "{$init->tagName_}{$island['name']}도{$init->_tagName}";
      } else {
        $name = "{$init->tagName2_}{$island['name']}도({$island['absent']}){$init->_tagName2}";
      }
      if(!empty($island['owner'])) {
        $owner = $island['owner'];
      } else {
        $owner = "?";
      }
      
      $prize = $island['prize'];
      $prize = $hako->getPrizeList($prize);

      if($init->commentNew > 0 && ($comment_turn + $init->commentNew) > $hako->islandTurn) {
        $comment .= " <span class=\"new\">New</span>";
      }
      
      print "<tr>\n";
      print "<th {$init->bgNumberCell} rowspan=\"2\">{$init->tagNumber_}$j{$init->_tagNumber}</th>\n";
      print "<td {$init->bgNameCell} rowspan=\"2\"><a href=\"{$GLOBALS['THIS_FILE']}?Sight={$id}\">{$name}</a>  {$monster}<br>\n{$prize}</td>\n";

      print "<td {$init->bgInfoCell}>$pop</td>\n";
      print "<td {$init->bgInfoCell}>$area</td>\n";
      print "<td {$init->bgInfoCell}>$money</td>\n";
      print "<td {$init->bgInfoCell}>$food</td>\n";
      print "<td {$init->bgInfoCell}>$farm</td>\n";
      print "<td {$init->bgInfoCell}>$factory</td>\n";
      print "<td {$init->bgInfoCell}>$mountain</td>\n";
      print "</tr>\n";
      print "<tr>\n";
      print "<td {$init->bgCommentCell} colspan=\"7\">{$init->tagTH_}{$owner}：{$init->_tagTH}$comment</td>\n";
      print "</tr>\n";
    }
    print "</table>\n</div>\n";
    print "<hr>\n";
    $this->logPrintTop();
    $this->historyPrint();
  }
  //---------------------------------------------------
  // 섬의 등록과 설정
  //---------------------------------------------------
  function regist($hako) {
    $this->newDiscovery($hako->islandNumber);
    $this->changeIslandInfo($hako->islandList);
    $this->changeOwnerName($hako->islandList);
    $this->setStyleSheet();
  }
  //---------------------------------------------------
  // 새로운 섬을 찾는다
  //---------------------------------------------------
  function newDiscovery($number) {
    global $init;

    print "<div id=\"NewIsland\">\n";
    print "<h2>새로운 섬을 찾기</h2>\n";
    if($number < $init->maxIsland) {
      print <<<END
<form action="{$GLOBALS['THIS_FILE']}" method="post">
섬의 이름 <br>
<input type="text" name="ISLANDNAME" size="32" maxlength="32">도<br>
당신의 이름은?(생략가능)<br>
<input type="text" name="OWNERNAME" size="32" maxlength="32"><br>
패스워드는?<br>
<input type="password" name="PASSWORD" size="32" maxlength="32"><br>
만약을 위해 패스워드를 다시 한번<br>
<input type="password" name="PASSWORD2" size="32" maxlength="32"><br>
<input type="hidden" name="mode" value="new">
<input type="submit" value="찾으러 간다">
</form>
END;
    } else {
      print "섬의 수가 최대수입니다···현재 등록할 수 없습니다.\n";
    }
    print "</div>\n";
    print "<hr>\n";
  }
  //---------------------------------------------------
  // 섬의 이름과 패스워드의 변경
  //---------------------------------------------------
  function changeIslandInfo($islandList = "") {
    print <<<END
<div id="ChangeInfo">
<h2>섬의 이름과 패스워드의 변경</h2>
<p>
(주의) 이름의 변경에는 500억원 듭니다.
</p>
<form action="{$GLOBALS['THIS_FILE']}" method="post">
어느 섬입니까?<br>
<select NAME="ISLANDID">
$islandList
</select>
<br>
어떤 이름으로 바꿉니까?(변경하는 경우만)<br>
<input type="text" name="ISLANDNAME" size="32" maxlength="32">도<br>
패스워드는?(필수)<br>
<input type="password" name="OLDPASS" size="32" maxlength="32"><br>
새로운 패스워드는?(변경할 경우)<br>
<input type="password" name="PASSWORD" size="32" maxlength="32"><br>
만약을 위해 패스워드를 다시 한번(변경할 경우)<br>
<input type="password" name="PASSWORD2" size="32" maxlength="32"><br>
<input type="hidden" name="mode" value="change">
<input type="submit" value="변경한다">
</form>
</div>
<hr>

END;
  }
  //---------------------------------------------------
  // 오너의 변경
  //---------------------------------------------------
  function changeOwnerName($islandList = "") {
    print <<<END
<div id="ChangeOwnerName">
<h2>오너의 변경</h2>
<form action="{$GLOBALS['THIS_FILE']}" method="post">
어느 섬입니까?<br>
<select name="ISLANDID">
{$islandList}
</select>
<br>
새로운 오너는?<br>
<input type="text" name="OWNERNAME" size="32" maxlength="32"><br>
패스워드는?<br>
<input type="password" name="OLDPASS" size="32" maxlength="32"><br>
<input type="hidden" name="mode" value="ChangeOwnerName">
<input type="submit" value="변경한다">
</form>
</div>
END;
  }
  //---------------------------------------------------
  // 스타일 시트의 설정
  //---------------------------------------------------
  function setStyleSheet() {
    global $init;
    $styleSheet;
    for($i = 0; $i < count($init->cssList); $i++) {
      $styleSheet .= "<option value=\"{$init->cssList[$i]}\">{$init->cssList[$i]}</option>\n";
    }
    print <<<END
<div id="HakoSkin">
<h2>스타일 시트의 설정</h2>
<form action="{$GLOBALS['THIS_FILE']}" method="post">
<select name="SKIN">
$styleSheet
</select>
<input type="hidden" name="mode" value="skin">
<input type="submit" value="설정">
</form>
</div>
<hr>

END;
  }
  //---------------------------------------------------
  // 최근의 사건
  //---------------------------------------------------
  function logPrintTop() {
    global $init, $HbaseDir, $HtopLogTurn, $HrepeatTurn;
    $baseDir = isset($HbaseDir) ? $HbaseDir : (isset($init->baseDir) ? $init->baseDir : '.');
    $linkTurn = isset($HtopLogTurn) ? intval($HtopLogTurn) : (isset($init->logTopTurn) ? intval($init->logTopTurn) : 0);
    $repeatTurn = isset($HrepeatTurn) ? intval($HrepeatTurn) : $linkTurn;
    print "<DIV ID='RecentlyLog'>\n";
    print "<H1>최근의 사건</H1>\n";
    print '[<A HREF="'.$baseDir.'/history.php?saikin=99" class="M" TARGET=_self>과거'.$linkTurn.'턴의 로그를 표시합니다</A>]<BR><BR>' . "\n";
    print "</DIV>\n";
    for($i = 0; $i < $repeatTurn; $i++) {
      if(function_exists('logFilePrint')) { logFilePrint($i, 0, 0); }
      elseif(class_exists('LogIO') && method_exists('LogIO', 'logFilePrint')) { LogIO::logFilePrint($i, 0, 0); }
    }
  }
  //---------------------------------------------------
  // 발견의 기록
  //---------------------------------------------------
  function historyPrint() {
    print "<div id=\"HistoryLog\">\n";
    print "<h2>발견의 기록</h2>";
    LogIO::historyPrint();
    print "</div>\n";
  }
}
//------------------------------------------------------------------
class HtmlMap extends HTML {
  //---------------------------------------------------
  // 개발 화면
  //---------------------------------------------------
  function owner($hako, $data) {
    global $init;
    $id     = $data['ISLANDID'];
    $number = $hako->idToNumber[$id];
    $island = $hako->islands[$number];

    // 패스워드 체크
    if(!Util::checkPassword($island['password'], $data['PASSWORD'])){
      HakoError::wrongPassword();
      return;
    }
    $this->tempOwer($hako, $data, $number);
    
    if($init->useBbs) {
      print "<div id=\"localBBS\">\n";
      $this->lbbsHead($island);
      $this->lbbsInputOW($island, $data);
      $this->lbbsContents($island);
      print "</div>\n";
    }
    $this->islandRecent($island, 1);
  }

  //---------------------------------------------------
  // 관광 화면
  //---------------------------------------------------
  function visitor($hako, $data) {
    global $init;
    $id     = $data['ISLANDID'];
    $number = $hako->idToNumber[$id];
    $island = $hako->islands[$number];
    print <<<END
<div align="center">
{$init->tagBig_}{$init->tagName_}「{$island['name']}도」{$init->_tagName}에 도착하였습니다.{$init->_tagBig}<br>
{$GLOBALS['BACK_TO_TOP']}<br>
</div>

END;

    $this->islandInfo($island, $number, 0);
    $this->islandMap($hako, $island, 0);

    if($init->useBbs) {
      print "<div id=\"localBBS\">\n";
      $this->lbbsHead($island);
      $this->lbbsInput($island, $data);
      $this->lbbsContents($island);
      print "</div>\n";
    }
    $this->islandRecent($island, 0);
  }
  //---------------------------------------------------
  // 섬의 정보
  //---------------------------------------------------
  function islandInfo($island, $number = 0, $mode = 0) {
    global $init;
    $rank = $number + 1;
    $pop   = $island['pop'] . $init->unitPop;
    $area  = $island['area'] . $init->unitArea;
    $money = ($mode == 0) ? Util::aboutMoney($island['money']) : "{$island['money']}{$init->unitMoney}";
    $food  = $island['food'] . $init->unitFood;
    $farm  = ($island['farm'] <= 0) ? "보유하지 않음" : $island['farm'] * 10 . $init->unitPop;
    $factory  = ($island['factory'] <= 0) ? "보유하지 않음" : $island['factory'] * 10 . $init->unitPop;
    $mountain = ($island['mountain'] <= 0) ? "보유하지 않음" : $island['mountain'] * 10 . $init->unitPop;
    $comment  = $island['comment'];

    print <<<END
<div id="islandInfo">
<table border="1">
<tr>
<th {$init->bgTitleCell}>{$init->tagTH_}순위{$init->_tagTH}</th>
<th {$init->bgTitleCell}>{$init->tagTH_}인구{$init->_tagTH}</th>
<th {$init->bgTitleCell}>{$init->tagTH_}면적{$init->_tagTH}</th>
<th {$init->bgTitleCell}>{$init->tagTH_}자금{$init->_tagTH}</th>
<th {$init->bgTitleCell}>{$init->tagTH_}식료{$init->_tagTH}</th>
<th {$init->bgTitleCell}>{$init->tagTH_}농장 규모{$init->_tagTH}</th>
<th {$init->bgTitleCell}>{$init->tagTH_}공장 규모{$init->_tagTH}</th>
<th {$init->bgTitleCell}>{$init->tagTH_}채굴장 규모{$init->_tagTH}</th>
</tr>
<tr>
<th {$init->bgNumberCell}>{$init->tagNumber_}$rank{$init->_tagNumber}</th>
<td {$init->bgInfoCell}>$pop</td>
<td {$init->bgInfoCell}>$area</td>
<td {$init->bgInfoCell}>$money</td>
<td {$init->bgInfoCell}>$food</td>
<td {$init->bgInfoCell}>$farm</td>
<td {$init->bgInfoCell}>$factory</td>
<td {$init->bgInfoCell}>$mountain</td>
</tr>
<tr>
<td colspan="8" {$init->bgCommentCell}>$comment</td>
</tr>
</table>
</div>

END;
  }
  //---------------------------------------------------
  // 지형 출력
  // $mode = 1 -- 미사일 기지등도 표시
  //---------------------------------------------------
  function islandMap($hako, $island, $mode = 0) {
    global $init;
    $land      = $island['land'];
    $landValue = $island['landValue'];
    $command   = $island['command'];
    if($mode == 1) {
      for($i = 0; $i < $init->commandMax; $i++) {
        $j = $i + 1;
        $com = $command[$i];
        if($com['kind'] < 20) {
          $comStr[$com['x']][$com['y']] .=
            "[{$j}]{$init->comName[$com['kind']]} ";
        }
      }
    }

    print "<div id=\"islandMap\" align=\"center\"><table border=\"1\"><tr><td>\n";
    print "<img src=\"xbar.gif\" width=\"400\" height=\"16\" alt=\"\"><br>\n";
    for($y = 0; $y < $init->islandSize; $y++) {
      if($y % 2 == 0) { print "<img src=\"space{$y}.gif\" width=\"16\" height=\"32\" alt=\"{$y}\">"; }

      for($x = 0; $x < $init->islandSize; $x++) {
        $hako->landString($land[$x][$y], $landValue[$x][$y], $x, $y, $mode, $comStr[$x][$y]);
      }
      
      if($y % 2 == 1) { print "<img src=\"space{$y}.gif\" width=\"16\" height=\"32\" alt=\"{$y}\">"; }

      print "<br>";
    }
    print "<div id=\"NaviView\">&shy;</div>";
    print "</td></tr></table></div>\n";
  }
  //---------------------------------------------------
  // 관광자 통신
  //---------------------------------------------------
  function lbbsHead($island) {
    global $init;
    print <<<END
<hr>
<h2>{$init->tagName_}{$island['name']}도의 {$init->_tagName}관광자 통신</h2>

END;
  }
  //---------------------------------------------------
  // 관광자 통신 입력 부분
  //---------------------------------------------------
  function lbbsInput($island, $data) {
    print <<<END
<div align="center">
<table border="1">
<tr>
<th>이름</th>
<th>내용</th>
<th>동작</th>
</tr>
<tr>
<form action="{$GLOBALS['THIS_FILE']}" method="post">
<td><input type="text" size="32" maxlength="32" name="LBBSNAME" value="{$data['defaultName']}"></td>
<td><input type="text" size="80" name="LBBSMESSAGE"></td>
<td>
<input type="hidden" name="mode" value="lbbs">
<input type="hidden" name="lbbsMode" value="0">
<input type="hidden" name="ISLANDID" value="{$island['id']}">
<input type="hidden" name="DEVELOPEMODE" value="{$data['DEVELOPEMODE']}">
<input type="submit" value="기록한다">
</td>
</form>
</tr>
</table>
</div>

END;
  }
  //---------------------------------------------------
  // 관광자 통신 입력 부분 오너용
  //---------------------------------------------------
  function lbbsInputOW($island, $data) {
    global $init;
    print <<<END
<div align="center">
<table border="1">
<tr>
<th>이름</th>
<th colspan="2">내용</th>
</tr>
<tr>
<form action="{$GLOBALS['THIS_FILE']}" method="post">
<td><input type="text" size="32" maxlength="32" name="LBBSNAME" VALUE="{$data['defaultName']}"></TD>
<td colspan="2"><input type="text" size="80" name="LBBSMESSAGE"></td>
</tr>
<tr>
<th colspan="2">동작</th>
</tr>
<tr>
<td align="right">
<input type="hidden" name="mode" value="lbbs">
<input type="hidden" name="lbbsMode" value="1">
<input type="hidden" name="PASSWORD" value="{$data['defaultPassword']}">
<input type="hidden" name="ISLANDID" value="{$island['id']}">
<input type="hidden" name="DEVELOPEMODE" value="{$data['DEVELOPEMODE']}">
<input type="submit" value="기록한다">
</td>
</form>
<td align="right">
<form action="{$GLOBALS['THIS_FILE']}" method="post">
번호
<select name="NUMBER">

END;
    
    // 발언 번호
    for($i = 0; $i < $init->lbbsMax; $i++) {
      $j = $i + 1;
      print "<option value=\"{$i}\">{$j}</option>\n";
    }
    print <<<END
</select>
<input type="hidden" name="mode" value="lbbs">
<input type="hidden" name="lbbsMode" value="2">
<input type="hidden" name="PASSWORD" value="{$data['defaultPassword']}">
<input type="hidden" name="ISLANDID" value="{$island['id']}">
<input type="hidden" name="DEVELOPEMODE" value="{$data['DEVELOPEMODE']}">
<input type="submit" value="삭제한다">
</form>
</td>
</tr>
</table>
</div>

END;
  }
  //---------------------------------------------------
  // 관광자 통신 기입해진 내용을 출력
  //---------------------------------------------------
  function lbbsContents($island) {
    global $init;
    $lbbs = $island['lbbs'];
    print <<<END
<div align="center">
<table border="1">
<tr>
<th style="width:3em;">번호</th>
<th>기록 내용</th>
</tr>

END;
    for($i = 0; $i < $init->lbbsMax; $i++) {
      $j = $i + 1;
      $line = $lbbs[$i];
      list($mode, $turn, $message) = explode(">", $line);
      print "<tr><th>{$init->tagNumber_}{$j}{$init->_tagNumber}</th>";
      if($mode == 0) {
        // 관광자
        print "<td>{$init->tagLbbsSS_}{$turn} &gt; {$message}{$init->_tagLbbsSS}</td></tr>\n";
      } else {
        // 섬주
        print "<td>{$init->tagLbbsOW_}{$turn} &gt; {$message}{$init->_tagLbbsOW}</td></tr>\n";
      }
      
    }
    print "</table></div>\n";
  }
  //---------------------------------------------------
  // 섬의 근황
  //---------------------------------------------------
  function islandRecent($island, $mode = 0) {
    global $init;
    print "<hr>\n";
    print "<div id=\"RecentlyLog\">\n";
    print "<h2>{$init->tagName_}{$island['name']}도 {$init->_tagName}의 근황</h2>\n";
    for($i = 0; $i < $init->logMax; $i++) {
      LogIO::logFilePrint($i, $island['id'], $mode);
    }
    print "</div>\n";
  }
  //---------------------------------------------------
  // 개발 화면
  //---------------------------------------------------
  function tempOwer($hako, $data, $number = 0) {
    global $init;
    $island = $hako->islands[$number];

    $width  = $init->islandSize * 32 + 50;
    $height = $init->islandSize * 32 + 100;
    $defaultTarget = ($init->targetIsland == 1) ? $island['id'] : $hako->defaultTarget;
    print <<<END
<script type="text/javascript">
<!--
var w;
var p = $defaultTarget;
function ps(x, y) {
  document.InputPlan.POINTX.options[x].selected = true;
  document.InputPlan.POINTY.options[y].selected = true;
  return true;
}

function ns(x) {
  document.InputPlan.NUMBER.options[x].selected = true;
  return true;
}

function settarget(part){
  p = part.options[part.selectedIndex].value;
}
function targetopen() {
  w = window.open("{$GLOBALS['THIS_FILE']}?target=" + p, "","width={$width},height={$height},scrollbars=1,resizable=1,toolbar=1,menubar=1,location=1,directories=0,status=1");
}


//-->
</script>
<div align="center">
{$init->tagBig_}{$init->tagName_}{$island['name']}도{$init->_tagName}개발 계획{$init->_tagBig}<br>
{$GLOBALS['BACK_TO_TOP']}<br>
</div>

END;
    $this->islandInfo($island, $number, 1);
    print <<<END
<div align="center">
<table border="1">
<tr>
<td {$init->bgInputCell}>
<div align="center">
<form action="{$GLOBALS['THIS_FILE']}" method="post" name="InputPlan">
<input type="hidden" name="mode" value="command">
<input type="hidden" name="ISLANDID" value="{$island['id']}">
<input type="hidden" name="PASSWORD" value="{$data['defaultPassword']}">
<input type="submit" value="계획 송신">
<hr>
<strong>계획 번호</strong>
<select name="NUMBER">

END;
    // 계획 번호
    for($i = 0; $i < $init->commandMax; $i++) {
      $j = $i + 1;
      print "<option value=\"{$i}\">{$j}</option>";
    }
    print <<<END
</select><br>
<hr>
<strong>개발 계획</strong><br>
<select name="COMMAND">

END;
    // 커멘드
    for($i = 0; $i < $init->commandTotal; $i++) {
      $kind = $init->comList[$i];
      $cost = $init->comCost[$kind];
      if($cost == 0) {
        $cost = '무료';
      } elseif($cost < 0) {
        $cost  = - $cost;
        $cost .= $init->unitFood;
      } else {
        $cost .= $init->unitMoney;
      }
      if($kind == $data['defaultKind']) {
        $s = 'selected';
      } else {
        $s = '';
      }
      print "<option value=\"{$kind}\" {$s}>{$init->comName[$kind]}({$cost})</option>\n";
    }
    print <<<END
</select>
<hr>
<strong>좌표(</strong>
<select name="POINTX">

END;
    for($i = 0; $i < $init->islandSize; $i++) {
      if($i == $data['defaultX']) {
        print "<option value=\"{$i}\" selected>{$i}</option>\n";
      } else {
        print "<option value=\"{$i}\">{$i}</option>\n";
      }
    }
    print "</select>, <select name=\"POINTY\">";
    for($i = 0; $i < $init->islandSize; $i++) {
      if($i == $data['defaultY']) {
        print "<option value=\"{$i}\" selected>{$i}</option>\n";
      } else {
        print "<option value=\"{$i}\">{$i}</option>\n";
      }
    }
    print <<<END
</select><strong>)</strong>
<hr>
<strong>수량</strong>
<select name="AMOUNT">

END;
     for($i = 0; $i < 100; $i++)
       print "<option value=\"{$i}\">{$i}</option>\n";

     print <<<END
</select>
<hr>
<strong>목표의 섬</strong><br>
<select name="TARGETID" onchange="settarget(this);">
$hako->targetList
</select>
<input type="button" value="목표 포착" onClick="javascript: targetopen();" onkeypress="javascript: targetopen();">
<hr>
<strong>동작</strong><br>
<input type="radio" name="COMMANDMODE" id="insert" value="insert" checked><label for="insert">삽입</label>
<input type="radio" name="COMMANDMODE" id="write" value="write"><label for="write">덧쓰기</label><BR>
<input type="radio" name="COMMANDMODE" id="delete" value="delete"><label for="delete">삭제</label>
<hr>
<input type="hidden" name="DEVELOPEMODE" value="cgi">
<input type="submit" value="계획 송신">
</form>
</div>
</td>
<td {$init->bgMapCell}>

END;
    $this->islandMap($hako, $island, 1);    // 섬의 지도, 소유자 모드
    print <<<END
</td>
<td {$init->bgCommandCell}>
END;
    $command = $island['command'];
    for($i = 0; $i < $init->commandMax; $i++) {
      $this->tempCommand($i, $command[$i], $hako);
    }
    print <<<END
</td>
</tr>
</table>
</div>
<hr>
<div id='CommentBox'>
<h2>코멘트 갱신</h2>
<form action="{$GLOBALS['THIS_FILE']}" method="post">
<input type="text" name="MESSAGE" size="80" value="{$island['comment']}"><br>
<input type="hidden" name="PASSWORD" value="{$data['defaultPassword']}">
<input type="hidden" name="mode" value="comment">
<input type="hidden" name="ISLANDID" value="{$island['id']}">
<input type="hidden" name="DEVELOPEMODE" value="cgi">
<input type="submit" value="코멘트 갱신">
</form>
</div>

END;

  }
  //---------------------------------------------------
  // 입력이 끝난 커멘드 표시
  //---------------------------------------------------
  function tempCommand($number, $command, $hako) {
    global $init;

    $kind   = $command['kind'];
    $target = $command['target'];
    $x      = $command['x'];
    $y      = $command['y'];
    $arg    = $command['arg'];

    $comName = "{$init->tagComName_}{$init->comName[$kind]}{$init->_tagComName}";
    $point   = "{$init->tagName_}({$x},{$y}){$init->_tagName}";
    $target  = $hako->idToName[$target];
    if(empty($target)) {
      $target = "무인";
    }
    $target = "{$init->tagName_}{$target}도{$init->_tagName}";
    $value = $arg * $init->comCost[$kind];
    if($value == 0) {
      $value = $init->comCost[$kind];
    }
    if($value < 0) {
      $value = -$value;
      $value = "{$value}{$init->unitFood}";
    } else {
      $value = "{$value}{$init->unitMoney}";
    }
    $value = "{$init->tagName_}{$value}{$init->_tagName}";

    $j = sprintf("%02d：", $number + 1);

    print "<a href=\"javascript:void(0);\" onclick=\"ns({$number})\" onkeypress=\"ns({$number})\">{$init->tagNumber_}{$j}{$init->_tagNumber}";

    switch($kind) {
    case $init->comDoNothing:
    case $init->comGiveup:
    case $init->comPropaganda:
      $str = "{$comName}";
      break;
    case $init->comMissileNM:
    case $init->comMissilePP:
    case $init->comMissileST:
    case $init->comMissileLD:
      // 미사일계
      $n = ($arg == 0) ? '무제한' : "{$arg}발";
      $str = "{$target}{$point}에{$comName}({$init->tagName_}{$n}{$init->_tagName})";
      break;
    case $init->comSendMonster:
      // 괴수 파견
      $str = "{$target}에 {$comName}";
      break;
    case $init->comSell:
      // 식료 수출
      $str ="{$comName}{$value}";
      break;
    case $init->comMoney:
    case $init->comFood:
      // 원조
      $str = "{$target}에 {$comName}{$value}";
      break;
    case $init->comDestroy:
      // 굴착
      if($arg != 0) {
        $str = "{$point}로 {$comName}(예산{$value})";
      } else {
        $str = "{$point}로 {$comName}";
      }
      break;
    case $init->comFarm:
    case $init->comFactory:
    case $init->comMountain:
      // 회수 첨부
      if($arg == 0) {
        $str = "{$point}로 {$comName}";
      } else {
        $str = "{$point}로 {$comName}({$arg}회)";
      }      
      break;
    default:
      // 좌표 첨부
      $str = "{$point}로 {$comName}";
    }

    print "{$str}</a> <br>";
  }
  //---------------------------------------------------
  // 새롭게 발견한 섬
  //---------------------------------------------------
  function newIslandHead($name) {
    global $init;
    print <<<END
<div align="center">
{$init->tagBig_}섬을 발견했습니다!{$init->_tagBig}<br>
{$init->tagBig_}{$init->tagName_}「{$name}도」을 {$init->_tagName}라고 명명합니다.{$init->_tagBig}<br>
{$GLOBALS['BACK_TO_TOP']}<br>
</div>
END;
  }
  //---------------------------------------------------
  // 목표 포착 모드
  //---------------------------------------------------
  function printTarget($hako, $data) {
    global $init;
    // id로부터 섬번호를 취득
    $id     = $data['ISLANDID'];
    $number = $hako->idToNumber[$id];
    // 왠지 그 섬이 없는 경우
    if($number < 0 || $number > $hako->islandNumber) {
      HakoError::problem();
      return;
    }
    $island = $hako->islands[$number];

print <<<END
<script type="text/javascript">
<!--
function ps(x, y) {
  window.opener.document.InputPlan.POINTX.options[x].selected = true;
  window.opener.document.InputPlan.POINTY.options[y].selected = true;
  return true;
}
//-->
</script>

<div align="center">
{$init->tagBig_}{$init->tagName_}{$island['name']}도{$init->_tagName}{$init->_tagBig}<br>
</div>

END;

    //섬의 지도
    $this->islandMap($hako, $island, 2);

  }
}
//------------------------------------------------------------------
class HtmlJS extends HtmlMap {
  static function header($data = "") {
    global $init, $PRODUCT_VERSION, $http;

    // 압축 전송
    if(GZIP == true) {
      $http->start();
    }
    header("X-Product-Version: {$PRODUCT_VERSION}");
    $css = (empty($data['defaultSkin'])) ? $init->cssList[0] : $data['defaultSkin'];
    print <<<END
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html lang="ja">
<head>
<base href="{$init->imgDir}/">

<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<link rel="stylesheet" type="text/css" href="{$init->cssDir}/{$css}">
<title>{$init->title}</title>
<script type="text/javascript" src="{$init->baseDir}/hako-js.php"></script>
</head>
<body onload="init()">
<div id="LinkHeader">
<a href="http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html">상정제도 스크립트 배포원</a> 
<a href="http://scrlab.g-7.ne.jp/">[PHP]</a> 　
<a href="http://AFresh.ub.to" target="_blank"><font color=red>[한글화 배포처]</font></a>　

[<a href="{$GLOBALS['THIS_FILE']}?mode=conf">섬의 등록·설정 변경</a> ]
</div>
<hr>

END;
  }
  //---------------------------------------------------
  // 개발 화면
  //---------------------------------------------------
  function tempOwer($hako, $data, $number = 0) {
    global $init;
    $island = $hako->islands[$number];

    $width  = $init->islandSize * 32 + 50;
    $height = $init->islandSize * 32 + 100;

    // 커멘드 세트
    $set_com = "";
    $com_max = "";
    for($i = 0; $i < $init->commandMax; $i++) {
      // 각 요소의 꺼내
      $command  = $island['command'][$i];
      $s_kind   = $command['kind'];
      $s_target = $command['target'];
      $s_x      = $command['x'];
      $s_y      = $command['y'];
      $s_arg    = $command['arg'];

      // 커멘드 등록
      if($i == $init->commandMax - 1){
        $set_com .= "[$s_kind, $s_x, $s_y, $s_arg, $s_target]\n";
        $com_max .= "0";
      } else {
        $set_com .= "[$s_kind, $s_x, $s_y, $s_arg, $s_target], \n";
        $com_max .= "0,";
      }
    }

    //커멘드 리스트 세트
    $l_kind;
    $set_listcom = "";
    $click_com = "";
    $click_com2 = "";
    $All_listCom = 0;
    $com_count = count($init->commandDivido);
    for($m = 0; $m < $com_count; $m++) {
      list($aa, $dd, $ff) = explode(",", $init->commandDivido[$m]);
      $set_listcom .= "[ ";
      for($i = 0; $i < $init->commandTotal; $i++) {
        $l_kind = $init->comList[$i];
        $l_cost = $init->comCost[$l_kind];
        if($l_cost == 0) {
          $l_cost = '무료';
        } elseif($l_cost < 0) {
          $l_cost = - $l_cost; $l_cost .= $init->unitFood;
        } else {
          $l_cost .= $init->unitMoney;
        }
        if($l_kind > $dd-1 && $l_kind < $ff+1) {
          $set_listcom .= "[$l_kind, '{$init->comName[$l_kind]}', '{$l_cost}'], \n";
          if($m == 0){
            $click_com .= "<a href='javascript:void(0);' onclick='cominput(InputPlan, 6, {$l_kind})' onkeypress='cominput(InputPlan, 6, {$l_kind})' style='text-decoration:none'>{$init->comName[$l_kind]}({$l_cost})<\\/a><br>\n";
          } elseif($m == 1) {
            $click_com2 .= "<a href='javascript:void(0);' onclick='cominput(InputPlan, 6, {$l_kind})' onkeypress='cominput(InputPlan, 6, {$l_kind})' style='text-decoration:none'>{$init->comName[$l_kind]}({$l_cost})<\\/a><br>\n";
          }
          $All_listCom++;
        }
        if($l_kind < $ff+1) { next; }
      }
      $bai = strlen($set_listcom);
      $set_listcom = substr($set_listcom, 0, $bai - 2);
      $set_listcom .= " ], \n";
    }
    $bai = strlen($set_listcom);
    $set_listcom = substr($set_listcom, 0, $bai - 2);
    if(empty($data['defaultKind'])) {
      $default_Kind = 1;
    } else {
      $default_Kind = $data['defaultKind'];
    }

    // 섬리스트 세트
    $set_island = "";
    for($i = 0; $i < $hako->islandNumber; $i++) {
      $l_name = $hako->islands[$i]['name'];
      $l_name = preg_replace("/'/", "\'", $l_name);
      $l_id = $hako->islands[$i]['id'];
      if($i == $hako->islandNumber - 1){
        $set_island .= "[$l_id, '$l_name']\n";
      }else{
        $set_island .= "[$l_id, '$l_name'], \n";
      }
    }
    $defaultTarget = ($init->targetIsland == 1) ? $island['id'] : $hako->defaultTarget;

    print <<<END
<div align="center">
{$init->tagBig_}{$init->tagName_}{$island['name']}도{$init->_tagName}개발 계획{$init->_tagBig}<BR>
{$GLOBALS['BACK_TO_TOP']}<br>
</div>
<script type="text/javascript">
<!--
var w;
var p = $defaultTarget;

// JAVA 스크립트 개발 화면 배포원
// -암상정제도( http://appoh.execweb.cx/hakoniwa/ )
// Programmed by Jynichi Sakai(―)
// ↑ 삭제하지 마세요.
var str;
g = [$com_max];
k1 = [$com_max];
k2 = [$com_max];
tmpcom1 = [ [0,0,0,0,0] ];
tmpcom2 = [ [0,0,0,0,0] ];
command = [
$set_com];

comlist = [
$set_listcom
];

islname = [
$set_island];


function init() {
  for(i = 0; i < command.length ;i++) {
    for(s = 0; s < $com_count ;s++) {
      var comlist2 = comlist[s];
      for(j = 0; j < comlist2.length ; j++) {
        if(command[i][0] == comlist2[j][0]) {
          g[i] = comlist2[j][1];
        }
      }
    }
  }
  SelectList('');
  outp();
  str = plchg();
  str = '<font color="blue">■ 송신이 끝남 ■<\\/font><br>' + str;
  disp(str, "");

}

function cominput(theForm, x, k) {
  a = theForm.NUMBER.options[theForm.NUMBER.selectedIndex].value;
  b = theForm.COMMAND.options[theForm.COMMAND.selectedIndex].value;
  c = theForm.POINTX.options[theForm.POINTX.selectedIndex].value;
  d = theForm.POINTY.options[theForm.POINTY.selectedIndex].value;
  e = theForm.AMOUNT.options[theForm.AMOUNT.selectedIndex].value;
  f = theForm.TARGETID.options[theForm.TARGETID.selectedIndex].value;
  //  if(x == 6){ b = k; menuclose(); }
  if (x == 1 || x == 6){
    for(i = $init->commandMax - 1; i > a; i--) {
      command[i] = command[i-1];
      g[i] = g[i-1];
    }
  } else if(x == 3) {
    for(i = Math.floor(a); i < ($init->commandMax - 1); i++) {
      command[i] = command[i + 1];
      g[i] = g[i+1];
    }
    command[$init->commandMax - 1] = [41, 0, 0, 0, 0];
    g[$init->commandMax - 1] = '자금융통';
    str = plchg();
    str = '<font color="red"><strong>■ 미송신 ■<\\/strong><\\/font><br>' + str;
    disp(str,"white");
    outp();
    return true;
  } else if(x == 4) {
    i = Math.floor(a);
    if (i == 0){ return true; }
    i = Math.floor(a);
    tmpcom1[i] = command[i];tmpcom2[i] = command[i - 1];
    command[i] = tmpcom2[i];command[i-1] = tmpcom1[i];
    k1[i] = g[i];k2[i] = g[i - 1];
    g[i] = k2[i];g[i-1] = k1[i];
    ns(--i);
    str = plchg();
    str = '<font color="red"><strong>■ 미송신 ■<\\/strong><\\/font><br>' + str;
    disp(str,"white");
    outp();
    return true;
  } else if(x == 5) {
    i = Math.floor(a);
    if (i == $init->commandMax - 1){ return true; }
    tmpcom1[i] = command[i];tmpcom2[i] = command[i + 1];
    command[i] = tmpcom2[i];command[i + 1] = tmpcom1[i];
    k1[i] = g[i];k2[i] = g[i + 1];
    g[i] = k2[i];g[i + 1] = k1[i];
    ns(++i);
    str = plchg();
    str = '<font color="red"><strong>■ 미송신 ■<\\/strong><\\/font><br>' + str;
    disp(str,"white");
    outp();
    return true;
  }

  for(s = 0; s < $com_count; s++) {
    var comlist2 = comlist[s];
    for(i = 0; i < comlist2.length; i++){
      if(comlist2[i][0] == b){
        g[a] = comlist2[i][1];
        break;
      }
    }
  }
  command[a] = [b, c, d, e, f];
  ns(++a);
  str = plchg();
  str = '<font color="red"><b>■ 미송신 ■<\\/b><\\/font><br>' + str;
  disp(str, "white");
  outp();
  return true;
}
function plchg() {
  strn1 = "";
  for(i = 0; i < $init->commandMax; i++) {
    c = command[i];

    kind = '{$init->tagComName_}' + g[i] + '{$init->_tagComName}';
    x = c[1];
    y = c[2];
    tgt = c[4];
    point = '{$init->tagName_}' + "(" + x + "," + y + ")" + '{$init->_tagName}';
    for(j = 0; j < islname.length ; j++) {
      if(tgt == islname[j][0]){
        tgt = '{$init->tagName_}' + islname[j][1] + "도" + '{$init->_tagName}';
      }
    }
    if(c[0] == $init->comDoNothing || c[0] == $init->comGiveup){ // 자금융통, 섬의 방폐
      strn2 = kind;
    }else if(c[0] == $init->comMissileNM || // 미사일 관련
             c[0] == $init->comMissilePP ||
             c[0] == $init->comMissileST ||
             c[0] == $init->comMissileLD){
      if(c[3] == 0) {
        arg = "(무제한)";
      } else {
        arg = "(" + c[3] + "발)";
      }
      strn2 = tgt + point + "에" + kind + arg;
    } else if(c[0] == $init->comSendMonster) { // 괴수 파견
      strn2 = tgt + "에" + kind;
    } else if(c[0] == $init->comSell) { // 식료 수출
      if(c[3] == 0){ c[3] = 1; }
      arg = c[3] * 100;
      arg = "(" + arg + "{$init->unitFood})";
      strn2 = kind + arg;
    } else if(c[0] == $init->comPropaganda) { // 유치 활동
      strn2 = kind;
    } else if(c[0] == $init->comMoney) { // 자금원조
      if(c[3] == 0){ c[3] = 1; }
      arg = c[3] * {$init->comCost[$init->comMoney]};
      arg = "(" + arg + "{$init->unitMoney})";
      strn2 = tgt + "에" + kind + arg;
    } else if(c[0] == $init->comFood) { // 식료 원조
      if(c[3] == 0){ c[3] = 1; }
      arg = c[3] * 100;
      arg = "(" + arg + "{$init->unitFood})";
      strn2 = tgt + "에" + kind + arg;
    } else if(c[0] == $init->comDestroy) { // 굴착
      if(c[3] == 0){
        strn2 = point + "로" + kind;
      } else {
        arg = c[3] * {$init->comCost[$init->comDestroy]};
        arg = "(예\산" + arg + "{$init->unitMoney})";
        strn2 = point + "로" + kind + arg;
      }
    } else if(c[0] == $init->comFarm || // 농장, 공장, 채굴장 정비
              c[0] == $init->comFactory ||
              c[0] == $init->comMountain) {
      if(c[3] != 0){
        arg = "(" + c[3] + "회)";
        strn2 = point + "로" + kind + arg;
      }else{
        strn2 = point + "로" + kind;
      }
    }else{
      strn2 = point + "로" + kind;
    }
    tmpnum = '';
    if(i < 9){ tmpnum = '0'; }
    strn1 +=
      '<a style="text-decoration:none;color:000000" HREF="javascript:void(0);" onclick="ns(' + i + ')" onkeypress="ns(' + i + ')"><nobr>' +
        tmpnum + (i + 1) + ':' +
          strn2 + '<\\/nobr><\\/a><br>';
  }
  return strn1;
}

function disp(str, bgclr) {
  if(str==null)  str = "";

  if(document.getElementById){
    document.getElementById("LINKMSG1").innerHTML = str;
    if(bgclr != "")
      document.getElementById("plan").bgColor = bgclr;
  } else if(document.all){
    el = document.all("LINKMSG1");
    el.innerHTML = str;
    if(bgclr != "")
      document.all.plan.bgColor = bgclr;
  } else if(document.layers) {
    lay = document.layers["PARENT_LINKMSG"].document.layers["LINKMSG1"];
    lay.document.open();
    lay.document.write("<font style='font-size:11pt'>"+str+"<\\/font>");
    lay.document.close();
    if(bgclr != "")
      document.layers["PARENT_LINKMSG"].bgColor = bgclr;
  }
}

function outp() {
  comary = "";

  for(k = 0; k < command.length; k++){
    comary = comary + command[k][0]
      + " " + command[k][1]
        + " " + command[k][2]
          + " " + command[k][3]
            + " " + command[k][4]
              + " " ;
  }
  document.InputPlan.COMARY.value = comary;
}

function ps(x, y) {
  document.InputPlan.POINTX.options[x].selected = true;
  document.InputPlan.POINTY.options[y].selected = true;
  return true;
}


function ns(x) {
  if (x == $init->commandMax){ return true; }
  document.InputPlan.NUMBER.options[x].selected = true;
  return true;
}

function set_com(x, y, land) {
  com_str = land + " ";
  for(i = 0; i < $init->commandMax; i++) {
    c = command[i];
    x2 = c[1];
    y2 = c[2];
    if(x == x2 && y == y2 && c[0] < 30){
      com_str += "[" + (i + 1) +"]" ;
      kind = g[i];
      if(c[0] == $init->comDestroy){
        if(c[3] == 0){
          com_str += kind;
        } else {
          arg = c[3] * 200;
          arg = "(예\산" + arg + "{$init->unitMoney})";
          com_str += kind + arg;
        }
      } else if(c[0] == $init->comFarm ||
                c[0] == $init->comFactory ||
                c[0] == $init->comMountain) {
        if(c[3] != 0){
          arg = "(" + c[3] + "회)";
          com_str += kind + arg;
        } else {
          com_str += kind;
        }
      } else {
        com_str += kind;
      }
      com_str += " ";
    }
  }
  document.InputPlan.COMSTATUS.value= com_str;
}


function SelectList(theForm) {
  var u, selected_ok;
  if(!theForm) { s = '' }
  else { s = theForm.menu.options[theForm.menu.selectedIndex].value; }
  if(s == ''){
    u = 0; selected_ok = 0;
    document.InputPlan.COMMAND.options.length = $All_listCom;
    for (i=0; i<comlist.length; i++) {
      var command = comlist[i];
      for (a=0; a<command.length; a++) {
        comName = command[a][1] + "(" + command[a][2] + ")";
        document.InputPlan.COMMAND.options[u].value = command[a][0];
        document.InputPlan.COMMAND.options[u].text = comName;
        if(command[a][0] == $default_Kind){
          document.InputPlan.COMMAND.options[u].selected = true;
          selected_ok = 1;
        }
        u++;
      }
    }
    if(selected_ok == 0)
      document.InputPlan.COMMAND.selectedIndex = 0;
  } else {
    var command = comlist[s];
    document.InputPlan.COMMAND.options.length = command.length;
    for (i=0; i<command.length; i++) {
      comName = command[i][1] + "(" + command[i][2] + ")";
      document.InputPlan.COMMAND.options[i].value = command[i][0];
      document.InputPlan.COMMAND.options[i].text = comName;
      if(command[i][0] == $default_Kind){
        document.InputPlan.COMMAND.options[i].selected = true;
        selected_ok = 1;
      }
    }
    if(selected_ok == 0)
      document.InputPlan.COMMAND.selectedIndex = 0;
  }
}


function settarget(part){
  p = part.options[part.selectedIndex].value;
}
function targetopen() {
  w = window.open("{$GLOBALS['THIS_FILE']}?target=" + p, "","width={$width},height={$height},scrollbars=1,resizable=1,toolbar=1,menubar=1,location=1,directories=0,status=1");
}

    //-->
</script>
END;

    $this->islandInfo($island, $number, 1);

    print <<<END
<div align="center">
<table border="1">
<tr valign="top">
<td $init->bgInputCell>
<form action="{$GLOBALS['THIS_FILE']}" method="post" name="InputPlan">
<input type="hidden" name="mode" value="command">
<input type="hidden" name="COMARY" value="comary">
<input type="hidden" name="DEVELOPEMODE" value="java">
<div align="center">
<br>
<b>커멘드 입력</b><br>
<b>
<a href="javascript:void(0);" onclick="cominput(InputPlan,1)" onkeypress="cominput(InputPlan,1)">삽입</a> 
　<a href="javascript:void(0);" onclick="cominput(InputPlan,2)" onkeypress="cominput(InputPlan,2)">덧쓰기</a> 
　<a href="javascript:void(0);" onclick="cominput(InputPlan,3)" onkeypress="cominput(InputPlan,3)">삭제</a> 
</b>
<hr>
<b>계획 번호</b>
<select name="NUMBER">
END;

    // 계획 번호
    for($i = 0; $i < $init->commandMax; $i++) {
      $j = $i + 1;
      print "<option value=\"$i\">$j</option>\n";
    }

    if ($HmenuOpen == 'on') {
      $open = "CHECKED";
    }else{
      $open = "";
    }

    print <<<END
</select>
<hr>
<b>개발 계획</b>
<br>
<select name="menu" onchange="SelectList(InputPlan)">
<option value="">전종류</option>

END;

    for($i = 0; $i < $com_count; $i++) {
      list($aa, $tmp) = explode(",", $init->commandDivido[$i], 2);
      print "<option value=\"$i\">{$aa}</option>\n";
    }
    print <<<END
</select><br>
<select name="COMMAND">
<option>　　　　　　　　　　</option>
<option>　　　　　　　　　　</option>
<option>　　　　　　　　　　</option>
<option>　　　　　　　　　　</option>
<option>　　　　　　　　　　</option>
<option>　　　　　　　　　　</option>
<option>　　　　　　　　　　</option>
<option>　　　　　　　　　　</option>
<option>　　　　　　　　　　</option>
<option>　　　　　　　　　　</option>
</select>
<hr>
<b>좌표(</b>
<select name="POINTX">

END;

    for($i = 0; $i < $init->islandSize; $i++) {
      if($i == $data['defaultX']) {
        print "<option value=\"$i\" selected>$i</option>\n";
      } else {
        print "<option value=\"$i\">$i</option>\n";
      }
    }

    print "</select>, <select name=\"POINTY\">\n";

    for($i = 0; $i < $init->islandSize; $i++) {
      if($i == $data['defaultY']) {
        print "<option value=\"$i\" selected>$i</option>\n";
      } else {
        print "<option value=\"$i\">$i</option>\n";
      }
    }

    print <<<END
</select><b> )</b>
<hr>
<b>수량</b><select name="AMOUNT">

END;

    // 수량
    for($i = 0; $i < 100; $i++) {
      print "<option value=\"$i\">$i</option>\n";
    }

    print <<<END
</select>
<hr>
<b>목표의 섬</b><br>
<select name="TARGETID" onchange="settarget(this);">
$hako->targetList
</select>
<input type="button" value="목표 포착" onClick="javascript: targetopen();" onkeypress="javascript: targetopen();">
<hr>
<b>커멘드 이동</b>：
<a href="javascript:void(0);" onclick="cominput(InputPlan,4)" onkeypress="cominput(InputPlan,4)" style="text-decoration:none"> ▲ </a> ··
<a href="javascript:void(0);" onclick="cominput(InputPlan,5)" onkeypress="cominput(InputPlan,5)" style="text-decoration:none"> ▼ </a> 
<hr>
<input type="hidden" name="ISLANDID" value="{$island['id']}">
<input type="hidden" name="PASSWORD" value="{$data['defaultPassword']}">
<input type="submit" value="계획 송신">
<br>마지막에<font color="red">계획 송신 버튼</font>을<br>누르는 것을 잊지 마세요.
</div>
</form>
</td>
<td $init->bgMapCell><div align="center">

END;

    $this->islandMap($hako, $island, 1);    // 섬의 지도, 소유자 모드

    $comment = $hako->islands[$number]['comment'];

    print <<<END
</div>
</td>
<td $init->bgCommandCell id="plan">
<ilayer name="PARENT_LINKMSG" width="100%" height="100%">
<layer name="LINKMSG1" width="200"></layer>
<span id="LINKMSG1"></span>
</ilayer>
<br>
</td>
</tr>
</table>
</div>
<hr>
<div id='CommentBox'>
<h2>코멘트 갱신</h2>
<form action="{$GLOBALS['THIS_FILE']}" method="post">
코멘트<input type="text" name="MESSAGE" size="80" value="{$island['comment']}"><br>
<input type="hidden" name="PASSWORD" value="{$data['defaultPassword']}">
<input type="hidden" name="mode" value="comment">
<input type="hidden" name="DEVELOPEMODE" value="java">
<input type="hidden" name="ISLANDID" value="{$island['id']}">
<input type="submit" value="코멘트 갱신">
</FORM>
</DIV>
END;

  }
}



class HtmlSetted extends HTML {
  function setSkin() {
    global $init;
    print "{$init->tagBig_}스타일 시트를 설정했습니다.{$init->_tagBig}{$GLOBALS['BACK_TO_TOP']}\n";
  }
  function comment() {
    global $init;
    print "{$init->tagBig_}코멘트를 갱신했습니다{$init->_tagBig}<hr>";
  }
  function change() {
    global $init;
    print "{$init->tagBig_}변경 완료했습니다{$init->_tagBig}{$GLOBALS['BACK_TO_TOP']}\n";
  }
  function lbbsDelete() {
    global $init;
    print "{$init->tagBig_}기록 내용을 삭제했습니다{$init->_tagBig}<hr>";
  }
  function lbbsAdd() {
    global $init;
    print "{$init->tagBig_}기록을 실시했습니다{$init->_tagBig}<hr>";
  }
  // 커멘드 삭제
  function commandDelete() {
    global $init;
    print "{$init->tagBig_}커멘드를 삭제했습니다{$init->_tagBig}<hr>\n";
  }

  // 커멘드 등록
  function commandAdd() {
    global $init;
    print "{$init->tagBig_}커멘드를 등록했습니다{$init->_tagBig}<hr>\n";
  }
}
class HakoError {
  static function wrongPassword() {
    global $init;
    print "{$init->tagBig_}패스워드가 다릅니다.{$init->_tagBig}{$GLOBALS['BACK_TO_TOP']}\n";
    HTML::footer();
    exit;
  }
  // hakojima.dat가 없다
  static function noDataFile() {
    global $init;
    print "{$init->tagBig_}데이터 파일이 열리지 않습니다.{$init->_tagBig}{$GLOBALS['BACK_TO_TOP']}\n";
    HTML::footer();
    exit;
  }
  static function newIslandFull() {
    global $init;
    print "{$init->tagBig_}죄송합니다, 더이상 섬이 없어서 등록할 수 없습니다!{$init->_tagBig}{$GLOBALS['BACK_TO_TOP']}\n";
    HTML::footer();
    exit;
  }
  static function newIslandNoName() {
    global $init;
    print "{$init->tagBig_}섬에 붙일 이름이 필요합니다.{$init->_tagBig}{$GLOBALS['BACK_TO_TOP']}\n";
    HTML::footer();
    exit;
  }
  static function newIslandBadName() {
    global $init;
    print "{$init->tagBig_},?()<>\$(이)라든지, 「무인도」든지 이상한 이름은 그만둡시다∼.{$init->_tagBig}{$GLOBALS['BACK_TO_TOP']}\n";
    HTML::footer();
    exit;
  }
  static function newIslandAlready() {
    global $init;
    print "{$init->tagBig_}그 섬이라면 벌써 발견 되었습니다.{$init->_tagBig}{$GLOBALS['BACK_TO_TOP']}\n";
    HTML::footer();
    exit;
  }
  static function newIslandNoPassword() {
    global $init;
    print "{$init->tagBig_}패스워드가 필요합니다.{$init->_tagBig}{$GLOBALS['BACK_TO_TOP']}\n";
    HTML::footer();
    exit;
  }
  static function changeNoMoney() {
    global $init;
    print "{$init->tagBig_}자금부족이기 때문에 변경할 수 없습니다{$init->_tagBig}{$GLOBALS['BACK_TO_TOP']}\n";
    HTML::footer();
    exit;
  }
  static function changeNothing() {
    global $init;
    print "{$init->tagBig_}이름, 패스워드 모두 공백입니다{$init->_tagBig}{$GLOBALS['BACK_TO_TOP']}\n";
    HTML::footer();
    exit;
  }
  static function problem() {
    global $init;
    print "{$init->tagBig_}문제 발생, 우선 돌아와 주세요.{$init->_tagBig}{$GLOBALS['BACK_TO_TOP']}\n";
    HTML::footer();
    exit;
  }
  static function lbbsNoMessage() {
    global $init;
    print "{$init->tagBig_}이름 또는 내용의 란이 공백입니다.{$init->_tagBig}{$GLOBALS['BACK_TO_TOP']}\n";
    HTML::footer();
    exit;
  }
  static function lockFail() {
    global $init;
    print "{$init->tagBig_}동시 액세스 에러입니다.<BR>브라우저의 「돌아온다」버튼을 눌러,<BR>당분간 기다리고 나서 재차 시험해 주세요.{$init->_tagBig}{$GLOBALS['BACK_TO_TOP']}\n";
    HTML::footer();
    exit;
  }
}
?>


<?php
if (!function_exists('hako_v')) {
function hako_v($name, $default = null) {
	return isset($GLOBALS[$name]) ? $GLOBALS[$name] : $default;
}
}

if (!function_exists('hako_c')) {
function hako_c($name, $default = null) {
	return isset($GLOBALS[$name]) ? $GLOBALS[$name] : $default;
}
}

if (!function_exists('hako_is')) {
function hako_is($value, $name) {
	return isset($GLOBALS[$name]) && ((string)$value === (string)$GLOBALS[$name]);
}
}

if (!function_exists('hako_arr_get')) {
function hako_arr_get($data, $key, $default = null) {
	if (is_array($data) && array_key_exists($key, $data)) { return $data[$key]; }
	if (is_object($data) && isset($data->$key)) { return $data->$key; }
	return $default;
}
}

if (!function_exists('hako_grid_get')) {
function hako_grid_get($grid, $x, $y, $default = 0) {
	if (is_array($grid) && isset($grid[$x]) && is_array($grid[$x]) && array_key_exists($y, $grid[$x])) { return $grid[$x][$y]; }
	return $default;
}
}

if (!function_exists('hako_img_get')) {
function hako_img_get($name, $idx, $default = 'land0.gif') {
	$arr = hako_v($name, array());
	return (is_array($arr) && array_key_exists($idx, $arr) && $arr[$idx] !== '') ? $arr[$idx] : $default;
}
}

if (!function_exists('hako_safe_id_number')) {
function hako_safe_id_number($id) {
	if (isset($GLOBALS['HidToNumber']) && is_array($GLOBALS['HidToNumber']) && array_key_exists($id, $GLOBALS['HidToNumber'])) { return $GLOBALS['HidToNumber'][$id]; }
	if (isset($GLOBALS['Hislands']) && is_array($GLOBALS['Hislands'])) {
		foreach ($GLOBALS['Hislands'] as $k => $v) {
			if (hako_arr_get($v, 'id', null) == $id) { return $k; }
		}
	}
	return '';
}
}

if (!function_exists('hako_island_by_number')) {
function hako_island_by_number($num) {
	if ($num !== '' && isset($GLOBALS['Hislands']) && is_array($GLOBALS['Hislands']) && array_key_exists($num, $GLOBALS['Hislands'])) { return $GLOBALS['Hislands'][$num]; }
	return array();
}
}

if (!function_exists('hako_current_island')) {
function hako_current_island() {
	$n = isset($GLOBALS['HcurrentNumber']) ? $GLOBALS['HcurrentNumber'] : hako_safe_id_number(hako_v('HcurrentID', 0));
	if ($n === '') { $n = 0; }
	$GLOBALS['HcurrentNumber'] = $n;
	$island = hako_island_by_number($n);
	if (!$island) {
		$island = array('id'=>0,'name'=>'','land'=>array(),'landValue'=>array(),'landValue2'=>array(),'nation'=>array(),'command'=>array(),'pop'=>0,'area'=>0,'money'=>0,'food'=>0,'farm'=>0,'factory'=>0,'mountain'=>0,'comment'=>'');
	}
	return $island;
}
}

if (!function_exists('hako_name_by_id')) {
function hako_name_by_id($id) {
	if (isset($GLOBALS['HidToName']) && is_array($GLOBALS['HidToName']) && array_key_exists($id, $GLOBALS['HidToName'])) { return $GLOBALS['HidToName'][$id]; }
	$n = hako_safe_id_number($id);
	$island = hako_island_by_number($n);
	return hako_arr_get($island, 'name', '');
}
}

if (!function_exists('hako_myship_cookie')) {
function hako_myship_cookie() {
	if (function_exists('hako_cookie_get_value')) {
		$v = hako_cookie_get_value('MYSHIP');
		if ($v !== null) { return $v; }
	}
	if (isset($GLOBALS['Hmyship']) && $GLOBALS['Hmyship'] !== '') { return $GLOBALS['Hmyship']; }
	$cookie = isset($_SERVER['HTTP_COOKIE']) ? $_SERVER['HTTP_COOKIE'] : '';
	if (preg_match('/MYSHIP=\(([^\)]*)\)/', $cookie, $m)) { return $m[1]; }
	if (preg_match('/(?:^|;\s*)[^;=]*MYSHIP=([^;]*)/', $cookie, $m)) { return trim($m[1]); }
	return '';
}
}

if (!function_exists('hako_land_info')) {
function hako_land_info($l, $lv, $x, $y, $mode, $nation, $dis, $pId) {
global $hp;
	$image = 'land0.gif';
	$alt = '';
	$naviTitle = '';
	$naviText = '';
	$naviExp = "''";
	$tName = '소속 불명';
	$sflg = $nation;
	$tn = hako_safe_id_number($nation);
	if ($tn !== '') {
		$tIsland = hako_island_by_number($tn);
		$tName = hako_arr_get($tIsland, 'name', '');
		$sflg = hako_arr_get($tIsland, 'id', $nation);
	}
	$sAfterName = hako_v('AfterName', '도');
	$HunitPop = hako_v('HunitPop', '00명');
	$HunitTree = hako_v('HunitTree', '00개');
	$HunitMoney = hako_v('HunitMoney', '억엔');
	$HislandTurn = hako_v('HislandTurn', 0);

	if (hako_is($l, 'HlandSea')) {
		if ($mode == 3) { $image = 'cosmo1.gif'; $alt = '허무'; $naviTitle = '허무'; }
		elseif ($mode == 4) { $image = 'land0.gif'; $alt = ($nation > 0) ? '해('.$tName.$sAfterName.')' : '해'; $naviTitle = $alt; }
		elseif ($lv >= 10) { $image = 'land17.gif'; $alt = '양식장('.$lv.'00마리)'; $naviTitle = '양식장'; $naviText = $lv.'00마리'; }
		elseif ($lv == 1) { $image = 'land14.gif'; $alt = '바다(얕은 여울)'; $naviTitle = '얕은 여울'; }
		else { $image = 'land0.gif'; $alt = '바다'; $naviTitle = '바다'; }
	} elseif (hako_is($l, 'HlandWaste')) {
		if ($lv >= 10) { $image = 'land18.gif'; $alt = '온천(매초'.$lv.'리터)'; $naviTitle = '온천'; $naviText = '매초'.$lv.'리터'; }
		elseif ($lv == 1) { $image = 'land13.gif'; $alt = '황무지'; $naviTitle = '황무지'; }
		else { $image = 'land1.gif'; $alt = '황무지'; $naviTitle = '황무지'; }
	} elseif (hako_is($l, 'HlandPlains')) { $image = 'land2.gif'; $alt = '평지'; $naviTitle = '평지';
	} elseif (hako_is($l, 'HlandForest')) { $image = 'land6.gif'; $alt = ($mode == 0) ? '숲' : '숲('.$lv.$HunitTree.')'; $naviTitle = '숲'; if ($mode != 0) { $naviText = $lv.$HunitTree; }
	} elseif (hako_is($l, 'HlandTown')) {
		if ($lv < 30) { $p = 3; $naviTitle = '마을'; }
		elseif ($lv < 100) { $p = 4; $naviTitle = '마을'; }
		else { $p = 5; $naviTitle = '도시'; }
		$image = 'land'.$p.'.gif'; $alt = $naviTitle.'('.$lv.$HunitPop.')'; $naviText = $lv.$HunitPop;
	} elseif (hako_is($l, 'HlandSlum')) { $image = 'land22.gif'; $alt = '슬럼가('.$lv.$HunitPop.')'; $naviTitle = '슬럼가'; $naviText = $lv.$HunitPop;
	} elseif (hako_is($l, 'HlandFarm')) { $image = 'land7.gif'; $alt = '농장('.$lv.'0'.$HunitPop.'규모)'; $naviTitle = '농장'; $naviText = $lv.'0'.$HunitPop.'규모';
	} elseif (hako_is($l, 'HlandFactory')) { $image = 'land8.gif'; $alt = '공장('.$lv.'0'.$HunitPop.'규모)'; $naviTitle = '공장'; $naviText = $lv.'0'.$HunitPop.'규모';
	} elseif (hako_is($l, 'HlandTower')) { $image = 'land23.gif'; $alt = '상업 빌딩('.$lv.'0'.$HunitPop.'규모)'; $naviTitle = '상업'; $naviText = $lv.'0'.$HunitPop.'규모';
	} elseif (hako_is($l, 'HlandPort')) { $image = 'land55.gif'; $alt = '항구('.$lv.'0'.$HunitPop.'규모)'; $naviTitle = '항구'; $naviText = $lv.'0'.$HunitPop.'규모';
	} elseif (hako_is($l, 'HlandPolice')) { $image = 'land56.gif'; $alt = '경찰서'; $naviTitle = '경찰서';
	} elseif (hako_is($l, 'HlandHospital')) { $image = 'land66.gif'; $alt = '병원'; $naviTitle = '병원';
	} elseif (hako_is($l, 'HlandBase')) {
		if ($mode == 0) { $image = 'land6.gif'; $alt = '숲'; $naviTitle = '숲'; }
		else { $level = function_exists('expToLevel') ? expToLevel($l, $lv) : ''; $image = 'land9.gif'; $alt = '미사일 기지 (레벨'.$level.'/경험치 '.$lv.')'; $naviTitle = '미사일 기지'; $naviText = '레벨 '.$level.'/경험치 '.$lv; }
	} elseif (hako_is($l, 'HlandSbase')) {
		if ($mode == 0) { $image = 'land0.gif'; $alt = '바다'; $naviTitle = '바다'; }
		else { $level = function_exists('expToLevel') ? expToLevel($l, $lv) : ''; $image = 'land12.gif'; $alt = '해저 기지 (레벨 '.$level.'/경험치 '.$lv.')'; $naviTitle = '해저 기지'; $naviText = '레벨 '.$level.'/경험치 '.$lv; }
	} elseif (hako_is($l, 'HlandWarp') || hako_is($l, 'HlandWarpR')) {
		$image = 'land36.gif';
		if (hako_is($l, 'HlandWarpR')) {
			if ($mode == 0) { $alt = '전이 장치'; }
			else {
				$dirs = array(1=>'우상',2=>'오른쪽',3=>'우하',4=>'좌하',5=>'왼쪽',6=>'좌상');
				$alt = isset($dirs[$lv]) ? '전이 지정 장치 ('.$dirs[$lv].')' : '전이 지정 장치';
			}
			$naviTitle = $alt;
		} else {
			if ($mode == 0) { $alt = '전이 장치'; }
			else { $alt = '전이 장치 ('.hako_name_by_id($lv).hako_v('AfterName','도').')'; $naviText = hako_name_by_id($lv).hako_v('AfterName','도'); }
			$naviTitle = '전이 장치';
		}
	} elseif (hako_is($l, 'HlandDefence')) {
		$image = 'land10.gif';
		if ($lv == 2) { $alt = 'S방위 시설'; }
		elseif ($lv == 3) { $alt = 'SS방위 시설'; }
		elseif ($lv == 10 || $lv == 11) { if ($mode == 0) { $image = 'land6.gif'; $alt = '숲'; } else { $alt = ($lv == 10) ? 'ST방위 시설' : 'SST방위 시설'; } }
		elseif ($lv == 20) { $alt = '안개 첨부 방위 시설'; }
		elseif ($lv == 21) { $alt = 'S안개 첨부 방위 시설'; }
		else { $alt = '방위 시설'; }
		$naviTitle = $alt;
	} elseif (hako_is($l, 'HlandHaribote')) {
		if ($lv == 0) { $image = 'land10.gif'; $alt = ($mode == 0) ? '방위 시설' : '위장 방위 시설'; $naviTitle = $alt; }
		else { list($kind, $name, $hp) = function_exists('monsterSpec') ? monsterSpec($lv) : array(0, '', 0); $special = hako_img_get('HmonsterSpecial', $kind, 0); $image = hako_img_get('HmonsterImage', $kind, 'monster7.gif'); if ((($special == 3) && (($HislandTurn % 2) == 1)) || (($special == 4) && (($HislandTurn % 2) == 0))) { $image = hako_img_get('HmonsterImage2', $kind, $image); } $alt = '괴수'.$name.'(체력'.$hp.')'; $naviTitle = $name; $naviText = '체력'.$hp; $naviExp = "'MONSTER".$kind."'"; }
	} elseif (hako_is($l, 'HlandOil')) {
		if ($lv == 5) { $image = 'land25.gif'; $alt = '해저 방위 시설'; $naviTitle = '해저 방위 시설'; }
		elseif ($lv == 6) { $image = 'land49.gif'; $alt = '해저 데스트랩'; $naviTitle = '해저 데스트랩'; }
		elseif ($lv == 7) { $image = 'land35.gif'; $alt = '해저 소방서'; $naviTitle = '해저 소방서'; }
		elseif ($lv >= 35) { $image = 'land19.gif'; $alt = '해저 도시('.$lv.$HunitPop.')'; $naviTitle = '해저 도시'; $naviText = $lv.$HunitPop.'규모'; }
		elseif ($lv >= 10) { $image = 'land20.gif'; $alt = '해저 농장('.$lv.'0'.$HunitPop.'규모)'; $naviTitle = '해저 농장'; $naviText = $lv.'0'.$HunitPop.'규모'; }
		else { $image = 'land16.gif'; $alt = '해저 유전'; $naviTitle = '해저 유전'; }
	} elseif (hako_is($l, 'HlandDeathtrap')) { $image = 'land48.gif'; $alt = '데스트랩(LV'.$lv.')'; $naviTitle = '데스트랩'; $naviText = 'LV'.$lv;
	} elseif (hako_is($l, 'HlandWindmill')) { $image = 'land50.gif'; $alt = '풍차'; $naviTitle = '풍차';
	} elseif (hako_is($l, 'HlandMyhome')) { if ($lv > 10) { $image = 'land53.gif'; $alt = '내 집(대저택)'; } elseif ($lv > 5) { $image = 'land52.gif'; $alt = '내 집(지부)'; } else { $image = 'land51.gif'; $alt = '내 집(2 층)'; } $naviTitle = $alt; if (function_exists('readProfileMAP')) { readProfileMAP(hako_v('HcurrentID', 0)); if (isset($GLOBALS['Hprofile']['MyHomeImage']) && substr($GLOBALS['Hprofile']['MyHomeImage'], 0, 7) == 'http://') { $image = $GLOBALS['Hprofile']['MyHomeImage']; } }
	} elseif (hako_is($l, 'HlandOsen')) { $image = 'land21.gif'; $alt = '오염 토양(LV'.$lv.')'; $naviTitle = '오염 토양'; $naviText = 'LV'.$lv;
	} elseif (hako_is($l, 'HlandStadium')) { $image = 'land27.gif'; $alt = '스타디움'; $naviTitle = $alt;
	} elseif (hako_is($l, 'HlandAmusement')) { $image = 'land28.gif'; $alt = '유원지'; $naviTitle = $alt;
	} elseif (hako_is($l, 'HlandCasino')) { $image = 'land29.gif'; $alt = '카지노'; $naviTitle = $alt;
	} elseif (hako_is($l, 'HlandPark')) { $image = 'land30.gif'; $alt = '공원'; $naviTitle = $alt;
	} elseif (hako_is($l, 'HlandSchool')) { $image = 'land31.gif'; $alt = '학교'; $naviTitle = $alt;
	} elseif (hako_is($l, 'HlandDome')) { $image = 'land32.gif'; $alt = '돔'; $naviTitle = $alt;
	} elseif (hako_is($l, 'HlandAirport')) { $image = 'land33.gif'; $alt = '공항'; $naviTitle = $alt;
	} elseif (hako_is($l, 'HlandZoo')) { $image = 'land38.gif'; $alt = '동물원'; $naviTitle = $alt;
	} elseif (hako_is($l, 'HlandBigcity')) { $image = 'land39.gif'; $alt = '대도시'; $naviTitle = $alt;
	} elseif (hako_is($l, 'HlandExpo')) { $image = 'land40.gif'; $alt = '박람회'; $naviTitle = $alt;
	} elseif (hako_is($l, 'HlandMegacity')) { $map = array(1=>array('land42.gif','거대도시◎남서'),2=>array('land41.gif','거대도시◎서쪽'),3=>array('land43.gif','거대도시◎북서'),4=>array('land42.gif','거대도시◎북동'),5=>array('land41.gif','거대도시◎동쪽'),6=>array('land43.gif','거대도시◎남동')); $v = isset($map[$lv])?$map[$lv]:array('land41.gif','거대도시'); $image=$v[0]; $alt=$v[1]; $naviTitle=$alt;
	} elseif (hako_is($l, 'HlandMegatower')) { $map = array(1=>array('land46.gif','거대 빌딩◎남서'),2=>array('land45.gif','거대 빌딩◎서쪽'),3=>array('land46.gif','거대 빌딩◎북서'),4=>array('land46.gif','거대 빌딩◎북동'),5=>array('land44.gif','거대 빌딩◎동쪽'),6=>array('land46.gif','거대 빌딩◎남동')); $v = isset($map[$lv])?$map[$lv]:array('land46.gif','거대 빌딩'); $image=$v[0]; $alt=$v[1]; $naviTitle=$alt;
	} elseif (hako_is($l, 'HlandMegaFact')) { $image = 'land47.gif'; $alt = ($lv >= 1 && $lv <= 6) ? array(1=>'거대 공장◎남서',2=>'거대 공장◎서쪽',3=>'거대 공장◎북서',4=>'거대 공장◎북동',5=>'거대 공장◎동쪽',6=>'거대 공장◎남동')[$lv] : '거대 공장'; $naviTitle = $alt;
	} elseif (hako_is($l, 'HlandMegaFarm')) { $image = 'land65.gif'; $alt = ($lv >= 1 && $lv <= 6) ? array(1=>'거대 농장◎남서',2=>'거대 농장◎서쪽',3=>'거대 농장◎북서',4=>'거대 농장◎북동',5=>'거대 농장◎동쪽',6=>'거대 농장◎남동')[$lv] : '거대 농장'; $naviTitle = $alt;
	} elseif (hako_is($l, 'HlandFuji')) { $image = hako_img_get('HfujiImage', $lv, 'fuji/fuji1.gif'); $alt = '후지산'; $naviTitle = $alt;
	} elseif (hako_is($l, 'HlandTcity')) { $image = 'land58.gif'; $alt = '상업도시(300'.$HunitPop.' '.$lv.'0'.$HunitPop.'규모)'; $naviTitle = '상업도시'; $naviText = '300'.$HunitPop.' '.$lv.'0'.$HunitPop.'규모';
	} elseif (hako_is($l, 'HlandHugecity')) { if ($lv < 50) { $image='land60.gif'; $alt='초거대도시(중심)'; } elseif ($lv < 60) { $image='land61.gif'; $alt='초거대도시(도시)'; } elseif ($lv < 70) { $image='land62.gif'; $alt='초거대도시(공장)'; } elseif ($lv < 80) { $image='land63.gif'; $alt='초거대도시(상업)'; } else { $image='land64.gif'; $alt='초거대도시(농장)'; } $naviTitle=$alt;
	} elseif (hako_is($l, 'HlandBreakwater')) { $image = ($lv == 1) ? 'land59.gif' : 'land59_2.gif'; $alt = '방파제'; $naviTitle = '방파제';
	} elseif (hako_is($l, 'HlandFire')) { $image = ($lv >= 10) ? 'land37.gif' : 'land34.gif'; $alt = ($lv >= 10) ? 'S소방서' : '소방서'; $naviTitle = $alt;
	} elseif (hako_is($l, 'HlandSeisei')) { $image = 'land24.gif'; $alt = ($lv == 10) ? '동 정제장' : (($lv == 30) ? '금 정제장' : '석탄 정제장'); $naviTitle = $alt;
	} elseif (hako_is($l, 'HlandMountain')) { $naviTitle='산'; if ($lv > 0) { $image='land15.gif'; $alt='산(채굴장'.$lv.'0'.$HunitPop.'규모)'; $naviText='채굴장'.$lv.'0'.$HunitPop.'규모'; } else { $image='land11.gif'; $alt='산'; }
	} elseif (hako_is($l, 'HlandMonument')) { $image = hako_img_get('HmonumentImage', $lv, 'monument0.gif'); $alt = hako_img_get('HmonumentName', $lv, '기념비'); $naviTitle = $alt;
	} elseif (hako_is($l, 'HlandSMonument')) { $image = hako_img_get('HsmonumentImage', $lv, 'smonument0.gif'); $alt = hako_img_get('HsmonumentName', $lv, '해저 기념비'); $naviTitle = $alt;
	} elseif (hako_is($l, 'HlandBank')) { if ($mode == 0) { $image='land6.gif'; $alt='숲'; $naviTitle='숲'; } else { $image='land26.gif'; $alt='은행(투자액'.$lv.'000'.$HunitMoney.')'; $naviTitle='은행'; $naviText='투자액'.$lv.'000'.$HunitMoney; }
	} elseif (isset($GLOBALS['HseaChk']) && is_array($GLOBALS['HseaChk']) && isset($GLOBALS['HseaChk'][$l]) && $GLOBALS['HseaChk'][$l] == 2) {
		$base = $l - hako_c('HlandPirate', 101); $image = hako_img_get('HshipImage', $base, 'ship01.gif'); list($order,$hp,$sId) = function_exists('shipSpec') ? shipSpec($lv) : array(0,0,0); $naviTitle = hako_img_get('HshipName', $base, '배');
		if (hako_is($l, 'HlandGhostShip')) { $alt = '바다'; $naviTitle = '바다'; }
		elseif (hako_is($l, 'HlandBalloonS')) { $alt = $naviTitle; $image = $image.$hp.'.gif'; }
		elseif ((string)$sId === (string)$pId && $sId != 0) { $alt = $naviTitle.'('.hako_name_by_id($sId).hako_v('AfterName','도').' H'.$hp.')('.hako_img_get('Hshiporder', $order, '').')'; if (!hako_myship_cookie()) { $image = 'm'.$image; } }
		else { $alt = $naviTitle.'(H'.$hp.')('.hako_img_get('Hshiporder', $order, '').')'; }
		$naviText = $alt;
	} elseif (hako_is($l, 'HlandMonster')) {
		list($kind, $name, $hp) = function_exists('monsterSpec') ? monsterSpec($lv) : array(0, '', 0); $special = hako_img_get('HmonsterSpecial', $kind, 0); $image = hako_img_get('HmonsterImage', $kind, 'monster7.gif'); if ((($special == 3) && (($HislandTurn % 2) == 1)) || (($special == 4) && (($HislandTurn % 2) == 0))) { $image = hako_img_get('HmonsterImage2', $kind, $image); } if ($kind == 26) { $alt='미채'; $naviTitle=$alt; } else { $alt='괴수'.$name.'(체력'.$hp.')'; $naviTitle=$name; $naviText='체력'.$hp; $naviExp="'MONSTER".$kind."'"; }
	} elseif (hako_is($l, 'HlandKInora')) { list($limit,$hp,$ld,$d) = function_exists('bigMonsterSpec') ? bigMonsterSpec($lv) : array(0,0,0,0); $image = 'kinora'.$ld.$d.'.gif'; if ($d == 0) { $alt='괴수 구상 이노라(체력'.$hp.')(잔'.$limit.')'; $naviText='체력'.$hp.' 잔'.$limit; } else { $alt='괴수 구상 이노라'; } $naviTitle='괴수 구상 이노라';
	} elseif (hako_is($l, 'HlandTrump')) { if ($lv < 1 || $lv > 14) { $image='trump0.gif'; $alt='트럼프뒤'; } else { $image='trump'.$lv.'.gif'; $alt=($lv == 14) ? '트럼프 조커' : '트럼프'.$lv; } $naviTitle=$alt;
	} elseif (hako_is($l, 'HlandFlower')) { if ($lv < 1 || $lv > 13) { $lv = 1; } $image='flower'.$lv.'.gif'; $alt=($lv == 13) ? '선인장' : '꽃'; $naviTitle=$alt;
	} elseif (hako_is($l, 'HlandDokan')) { if ($mode == 0) { $image='land6.gif'; $alt='숲'; } else { $image='land57.gif'; $alt='입구'; } $naviTitle=$alt;
	} elseif (hako_is($l, 'HlandOcean')) { $image='ocean_10.gif'; $alt='무인도'; $naviTitle=$alt;
	} elseif (hako_is($l, 'HlandOPlayer')) { $image='ocean_20.gif'; $alt=$tName.$sAfterName; $naviTitle=$alt;
	} elseif (hako_is($l, 'HlandEarth')) { $image='cosmo2.gif'; $alt='지구'; $naviTitle=$alt;
	} elseif (hako_is($l, 'HlandSunit') || hako_is($l, 'HlandSCity') || hako_is($l, 'HlandSFarm') || hako_is($l, 'HlandSFactory') || hako_is($l, 'HlandSpaceBase') || hako_is($l, 'HlandSDefence') || hako_is($l, 'HlandSAEisei')) {
		if (hako_is($l, 'HlandSunit')) { if ($lv == 20) { $image='cosmo6.gif'; $alt='우주 파괴 유닛'; $naviTitle='우주 파괴 유닛'; } elseif ($lv == 1) { $image='cosmo4.gif'; $alt='우주 건설중 유닛'; $naviTitle='우주 건설중 유닛'; } elseif ($lv == 10) { $image='cosmo5.gif'; $alt='우주 유닛'; $naviTitle='우주 유닛'; } else { $image='cosmo3.gif'; $alt='우주 기초 유닛'; $naviTitle='우주 기초 유닛'; } }
		elseif (hako_is($l, 'HlandSCity')) { if ($lv < 30) { $p=7; $n='우주 마을'; $naviTitle='우주 마을'; } elseif ($lv < 100) { $p=8; $n='우주 마을'; $naviTitle='우주 마을'; } else { $p=9; $n='우주 도시'; $naviTitle='우주 도시'; } $naviText=$lv.$HunitPop; $image='cosmo'.$p.'.gif'; $alt=$n.'('.$lv.$HunitPop.')'; }
		elseif (hako_is($l, 'HlandSFarm')) { $image='cosmo10.gif'; $alt='우주 농장('.$lv.'0'.$HunitPop.'규모)'; $naviTitle='우주 농장'; $naviText=$lv.'0'.$HunitPop.'규모'; }
		elseif (hako_is($l, 'HlandSFactory')) { $image='cosmo11.gif'; $alt='우주 공장('.$lv.'0'.$HunitPop.'규모)'; $naviTitle='우주 공장'; $naviText=$lv.'0'.$HunitPop.'규모'; }
		elseif (hako_is($l, 'HlandSpaceBase')) { $level = function_exists('expToLevel') ? expToLevel($l, $lv) : ''; $image='cosmo12.gif'; $alt='우주 미사일 기지 (레벨 '.$level.'/경험치 '.$lv.')'; $naviTitle='우주 미사일 기지'; $naviText='레벨 '.$level.'/경험치 '.$lv; }
		elseif (hako_is($l, 'HlandSDefence')) { $image='cosmo14.gif'; $alt='우주 방위 시설'; $naviTitle='우주 방위 시설'; }
		elseif (hako_is($l, 'HlandSAEisei')) { $idx=intval($lv/1000); $en=$lv%1000; $image=hako_img_get('HsEiseiImage',$idx,'cosmo20.gif'); $alt=hako_img_get('HsEisei',$idx,'우주 위성').'('.$en.'EN)'; $naviTitle=hako_img_get('HsEisei',$idx,'우주 위성'); $naviText=$en.'EN'; }
		if ($nation > 0) { $alt .= '('.$tName.$sAfterName.')'; $naviText .= '('.$tName.$sAfterName.')'; }
		if ($dis > 100) { $alt .= '(불만 정점)'; $naviText .= '(불만 정점)'; } elseif ($dis > 45) { $alt .= '(불만)'; $naviText .= '(불만)'; } elseif ($dis > 30) { $alt .= '(약간 불만)'; $naviText .= '(약간 불만)'; }
	} else {
		if (isset($GLOBALS['HlandName']) && is_array($GLOBALS['HlandName']) && isset($GLOBALS['HlandName'][$l])) { $alt = $GLOBALS['HlandName'][$l]; $naviTitle = $alt; }
	}
	return array($image, $alt, $naviTitle, $naviText, $naviExp, $sflg);
}
}

if (!function_exists('landString')) {
function landString($l, $lv, $x, $y, $mode = 0, $comStr = '', $nation = 0, $dis = 0, $pId = 0, $js = 0) {
	list($image, $alt, $naviTitle, $naviText, $naviExp, $sflg) = hako_land_info($l, $lv, $x, $y, $mode, $nation, $dis, $pId);
	$point = '(' . $x . ',' . $y . ')';
	$HmainMode = hako_v('HmainMode', '');
	$HspaceID = hako_v('HspaceID', 0);
	$myship = hako_myship_cookie();
	$ntmp = '';
	if (hako_v('HdebugMode', 0) > 0 && $nation > 0) {
		$ntmp2 = (hako_v('HdebugMode', 0) == $nation) ? '∪' : $nation;
		$ntmp = '<span style="position:absolute;text-decoration:none;color:#ff0000;font-weight : bold;font-size:12pt;">'.$ntmp2.'</span>';
	}
	$eAlt = htmlspecialchars($point . ' ' . $alt . ' ' . $comStr, ENT_QUOTES, 'UTF-8');
	$jsTitle = str_replace("'", "\\'", $naviTitle);
	$jsText = str_replace("'", "\\'", $naviText);
	if ($js == 1) {
		if ($mode == 3) {
			if (($sflg == $pId) && ($sflg > 0) && ($nation > 0) && (!$myship)) { echo '<td class=b><A HREF="JavaScript:void(0);" onclick="return hakoMapClick(event,'.$x.','.$y.')" data-hako-x="'.$x.'" data-hako-y="'.$y.'" '; }
			elseif ((($l != hako_c('HlandSea')) && ($l != hako_c('HlandEarth'))) && ($nation == 0) && (!$myship)) { echo '<td class=i><A HREF="JavaScript:void(0);" onclick="return hakoMapClick(event,'.$x.','.$y.')" data-hako-x="'.$x.'" data-hako-y="'.$y.'" '; }
			else { echo '<td class=s><A HREF="JavaScript:void(0);" onclick="return hakoMapClick(event,'.$x.','.$y.')" data-hako-x="'.$x.'" data-hako-y="'.$y.'" '; }
		} else { echo '<td class=e><A HREF="JavaScript:void(0);" onclick="return hakoMapClick(event,'.$x.','.$y.')" data-hako-x="'.$x.'" data-hako-y="'.$y.'" '; }
		if ($mode == 1 && $HmainMode != 'landmap') { echo 'onMouseOver="set_com('.$x.', '.$y.', \''.$point.' '.str_replace("'", "\\'", $alt).'\');window.status = \''.$point.' '.str_replace("'", "\\'", $alt.' '.$comStr).'\'; return true;" onMouseOut="not_com();window.status = \''.'\';">'; }
		elseif ($HmainMode == 'landmap') { echo 'onMouseOver="window.status = \''.$point.' '.str_replace("'", "\\'", $alt.' '.$comStr).'\'; return true;" onMouseOut="window.status = \''.'\';">'; }
		echo '<IMG SRC="'.$image.'" ALT="'.$eAlt.'" TITLE="'.$eAlt.'" width=32 height=32 BORDER=0></A></td>';
	} else {
		if ($mode == 1) { echo '<td class=e><A HREF="JavaScript:void(0);" onclick="ps('.$x.','.$y.')">'; }
		elseif ($mode == 3) {
			if ($HspaceID == 0) { echo '<td class=s>'; }
			elseif (($sflg == $pId) && ($sflg > 0) && ($nation > 0) && (!$myship)) { echo '<td class=b>'; }
			elseif (($sflg == $HspaceID) && ($sflg > 0) && ($nation > 0) && (!$myship)) { echo '<td class=e>'; }
			elseif ((($l != hako_c('HlandSea')) && ($l != hako_c('HlandEarth'))) && ($nation == 0) && (!$myship)) { echo '<td class=i>'; }
			else { echo '<td class=s>'; }
			echo '<A HREF="JavaScript:void(0);" onMouseOver="Navi('.$x.', '.$y.',\''.$image.'\', \''.$jsTitle.'\', \''.$jsText.'\', '.$naviExp.');" onMouseOut="NaviClose(); return false">';
		} elseif (hako_is($l, 'HlandOPlayer')) {
			echo '<td class=e><A HREF="'.hako_v('HthisFile','hako-main.php').'?Sight='.$sflg.'" target="_blank" "JavaScript:void(0);" onMouseOver="Navi('.$x.', '.$y.',\''.$image.'\', \''.$jsTitle.'\', \''.$jsText.'\', '.$naviExp.');" onMouseOut="NaviClose(); return false">';
		} else {
			echo '<td class=e><A HREF="JavaScript:void(0);" onMouseOver="Navi('.$x.', '.$y.',\''.$image.'\', \''.$jsTitle.'\', \''.$jsText.'\', '.$naviExp.');" onMouseOut="NaviClose(); return false">';
		}
		echo $ntmp.'<IMG SRC="'.$image.'" ALT="'.$eAlt.'" width=32 height=32 BORDER=0>';
		if (($mode == 1) || ($mode == 3) || hako_is($l, 'HlandOPlayer')) { echo '</A></td>'; } else { echo '</td>'; }
	}
	if (!isset($GLOBALS['LandCount']) || !is_array($GLOBALS['LandCount'])) { $GLOBALS['LandCount'] = array(); }
	if (!isset($GLOBALS['LandCount2']) || !is_array($GLOBALS['LandCount2'])) { $GLOBALS['LandCount2'] = array(); }
	$GLOBALS['LandCount'][$nation] = isset($GLOBALS['LandCount'][$nation]) ? $GLOBALS['LandCount'][$nation] + 1 : 1;
	$GLOBALS['LandCount2'][$naviTitle] = isset($GLOBALS['LandCount2'][$naviTitle]) ? $GLOBALS['LandCount2'][$naviTitle] + 1 : 1;
}
}

if (!function_exists('landString2')) {
function landString2($l, $lv, $x, $y, $mode = 0, $comStr = '', $nation = 0, $js = 0) {
	$point = '(' . $x . ',' . $y . ')';
	$image = 'land54.gif';
	$alt = '농무';
	$eAlt = htmlspecialchars($point . ' ' . $alt . ' ' . $comStr, ENT_QUOTES, 'UTF-8');
	if ($js == 1) {
		echo '<td class=e><A HREF="JavaScript:void(0);" onclick="return hakoMapClick(event,'.$x.','.$y.')" data-hako-x="'.$x.'" data-hako-y="'.$y.'" ><IMG SRC="'.$image.'" ALT="'.$eAlt.'" TITLE="'.$eAlt.'" width=32 height=32 BORDER=0></A></td>';
	} else {
		if ($mode == 1) { echo '<A HREF="JavaScript:void(0);" onclick="ps('.$x.','.$y.')">'; }
		echo '<td class=e><IMG SRC="'.$image.'" ALT="'.$eAlt.'" width=32 height=32 BORDER=0></td>';
		if ($mode == 1) { echo '</A>'; }
	}
	if (!isset($GLOBALS['LandCount2']) || !is_array($GLOBALS['LandCount2'])) { $GLOBALS['LandCount2'] = array(); }
	$GLOBALS['LandCount2'][$alt] = isset($GLOBALS['LandCount2'][$alt]) ? $GLOBALS['LandCount2'][$alt] + 1 : 1;
}
}

if (!function_exists('hako_legacy_land_img')) {
function hako_legacy_land_img($kind, $value, $x, $y, $mode = 0, $nation = 0) {
	landString($kind, $value, $x, $y, $mode, '', $nation, 0, hako_v('HcurrentID', 0), 0);
}
}

if (!function_exists('SearchKiriMons')) {
function SearchKiriMons($land, $landValue) {
	$GLOBALS['Kiri'] = array();
	$size = hako_v('HislandSize', 15);
	for ($x = 0; $x < $size; $x++) { for ($y = 0; $y < $size; $y++) { $GLOBALS['Kiri'][$x][$y] = 0; } }
	$ax = hako_v('ax', array(0,1,1,0,-1,-1,0,2,2,1,0,-1,-2,-2,-1,0,1,2,1));
	$ay = hako_v('ay', array(0,0,1,1,1,0,-1,-1,0,1,2,2,2,1,0,-1,-2,-2,-1));
	for ($y = 0; $y < $size; $y++) {
		for ($x = 0; $x < $size; $x++) {
			$l = hako_grid_get($land, $x, $y, 0);
			$lv = hako_grid_get($landValue, $x, $y, 0);
			$range = 0; $k = 0; $s = 0;
			if ((hako_is($l, 'HlandMonster') || hako_is($l, 'HlandHaribote')) && function_exists('monsterSpec')) {
				list($kind) = monsterSpec($lv);
				$sp = hako_img_get('HmonsterSpecial', $kind, 0);
				if ($sp == 8) { $range = 7; $k = 1; $s = 1; }
			} elseif (hako_is($l, 'HlandDefence')) {
				if ($lv == 20) { $range = 7; $k = 2; $s = 0; }
				elseif ($lv == 21) { $range = 19; $k = 2; $s = 0; }
			}
			if ($range <= 0) { continue; }
			for ($i = $s; $i < $range; $i++) {
				$sx = $x + (isset($ax[$i]) ? $ax[$i] : 0);
				$sy = $y + (isset($ay[$i]) ? $ay[$i] : 0);
				if ((!($sy % 2)) && ($y % 2)) { $sx--; }
				if (!(($sx < 0) || ($sx >= $size) || ($sy < 0) || ($sy >= $size))) {
					if (!isset($GLOBALS['Kiri'][$sx][$sy]) || $GLOBALS['Kiri'][$sx][$sy] != 1) { $GLOBALS['Kiri'][$sx][$sy] = $k; }
				}
			}
		}
	}
}
}

if (!function_exists('tempNavi')) {
function tempNavi($mode = 0) {
	$tHislandSize = ($mode == 4) ? hako_v('HoceanSize', 15) : hako_v('HislandSize', 15);
	echo <<<END
<SCRIPT Language="JavaScript">
<!--

MONSTER0 = "인조 괴수";
MONSTER1 = "";
MONSTER2 = "　홀수 턴은 방어";
MONSTER3 = "";
MONSTER4 = "　최대 2보이동한다";
MONSTER5 = "　최대 몇보 이동하는지 불명";
MONSTER6 = "　짝수 턴은 방어";
MONSTER7 = "";
MONSTER8 = "";
MONSTER9 = "";
MONSTER10 ="";
MONSTER11 ="";
MONSTER12 ="";
MONSTER13 ="";
MONSTER14 ="";
MONSTER15 ="";
MONSTER16 ="";
MONSTER17 ="";
MONSTER18 ="";
MONSTER19 ="";
MONSTER20 ="";
MONSTER21 ="";
MONSTER22 ="";
MONSTER23 ="";
MONSTER24 ="";
MONSTER25 ="";
MONSTER26 ="";
MONSTER27 ="";
MONSTER28 ="";
MONSTER29 ="";
MONSTER30 ="";
MONSTER31 ="";
MONSTER32 ="　매우 일반적인 우주 괴수";
MONSTER33 ="　움직임이 재빠르게 적당히 내구력이 있는 우주 괴수";
MONSTER34 ="　움직임이 매우 민첩한 우주 괴수";
MONSTER35 ="　내구력이 높은 우주 괴수";

function Navi(x, y, img, title, text, exp) {
	StyElm = document.getElementById("NaviView");
	StyElm.style.visibility = "visible";
	if(x + 1 > $tHislandSize / 2) {
		StyElm.style.marginLeft = (x - 5) * 32 -10;
	} else {
		StyElm.style.marginLeft = (x + 1) * 32;
	}
	if(y + 1 == $tHislandSize) {
		StyElm.style.marginTop = (y - $tHislandSize - 1.5) * 32;
	} else if(y + 1 > $tHislandSize / 2) {
		StyElm.style.marginTop = (y - $tHislandSize - 1) * 32;
	} else {
		StyElm.style.marginTop = (y - $tHislandSize) * 32;
	}
	StyElm.innerHTML = "<table><tr><td class='M'><img class='NaviImg' src=" + img + "><\\/td><td class='M'><div class='NaviTitle'>" + title + " (" + x + "," + y + ")<\\/div><div class='NaviText'>" + text + "<\\/div>";
	if(exp) {
		StyElm.innerHTML += "<br><div class='NaviText'>" + eval(exp) + "<\\/div>";
	}
	StyElm.innerHTML += "<\\/td><\\/tr><\\/table>";
}
function NaviClose() {
	StyElm = document.getElementById("NaviView");
	StyElm.style.visibility = "hidden";
}
//-->
</SCRIPT>
END;
}
}

if (!function_exists('islandMap')) {
function islandMap($mode = 0, $pId = 0) {
	if ($mode == 3) { $island = hako_v('Hspace', array()); }
	elseif ($mode == 4) { $island = hako_v('Hocean', array()); }
	else { $island = hako_current_island(); }
	$land = hako_arr_get($island, 'land', array());
	$landValue = hako_arr_get($island, 'landValue', array());
	$nation = hako_arr_get($island, 'nation', array());
	$dis = hako_arr_get($island, 'landValue2', array());
	if ($mode == 1) { $pId = hako_arr_get($island, 'id', $pId); }
	$size = hako_v('HislandSize', 15);
	$widthsize = $size * 32 + 16;
	$cspan = $size + 1;
	$jsMap = ((($mode == 1) && (hako_v('HjavaMode','') == 'java')) || (hako_v('HmainMode','') == 'landmap')) ? 1 : 0;
	if ($mode == 3) { echo "<div id='islandMap'><table border=1><tr><td colspan=$cspan class=s><img src=".hako_v('HspaceSizeImage','sxbar15.gif')." width=$widthsize height=16>"; }
	elseif ($mode == 4) { echo "<div id='islandMap'><table border=1><tr><td colspan=$cspan class=b><img src=".hako_v('HoceanSizeImage','xbar15.gif')." width=$widthsize height=16>"; }
	else { echo "<div id='islandMap'><table border><tr><td colspan=$cspan class=b><img src=".hako_v('HislandSizeImage','xbar15.gif')." width=$widthsize height=16>"; }
	SearchKiriMons($land, $landValue);
	for ($y = 0; $y < $size; $y++) {
		echo '<table border=0 cellspacing=0 cellpadding=0><tr>';
		if (($y % 2) == 0) {
			if ($mode == 3) { echo '<td class=s><img src="sspace'.$y.'.gif" width=16 height=32></td>'; }
			else { echo '<td class=b><img src="space'.$y.'.gif" width=16 height=32></td>'; }
		}
		for ($x = 0; $x < $size; $x++) {
			$kiri = isset($GLOBALS['Kiri'][$x][$y]) ? $GLOBALS['Kiri'][$x][$y] : 0;
			$l = hako_grid_get($land, $x, $y, 0);
			$lv = hako_grid_get($landValue, $x, $y, 0);
			$na = hako_grid_get($nation, $x, $y, 0);
			$di = hako_grid_get($dis, $x, $y, 0);
			if (($kiri == 1) || (($kiri == 2) && ($mode != 1))) { landString2($l, $lv, $x, $y, $mode, '', $na, $jsMap); }
			else { landString($l, $lv, $x, $y, $mode, '', $na, $di, $pId, $jsMap); }
		}
		if (($y % 2) == 1) {
			if ($mode == 3) { echo '<td class=s><img src="sspace'.$y.'.gif" width=16 height=32></td>'; }
			else { echo '<td class=b><img src="space'.$y.'.gif" width=16 height=32></td>'; }
		}
		echo '</tr></table>';
	}
	echo "<div id='NaviView'></div>";
	echo "</table></div>\n";
}
}

if (!function_exists('hako_fmt_owned')) {
function hako_fmt_owned($value, $unit, $prefix = '', $suffix = '') {
	return ($value == 0 || $value === '' || $value === null) ? '보유 안함' : $prefix.$value.$suffix.$unit;
}
}

if (!function_exists('islandInfo')) {
function islandInfo() {
	$island = hako_current_island();
	$turnsu = hako_arr_get($island, 'turnsu', 1);
	$rank = hako_v('HcurrentNumber', 0) + 1;
	if (($turnsu == 0) && (hako_arr_get($island, 'pop', 0) == 10)) { $rank = '-'; }
	$weather = hako_arr_get($island, 'weather', 1114);
	if (function_exists('weatherinfo')) { list($wkind,$wname,$whp,$wkind2,$wkind3) = weatherinfo($weather); }
	else { $wname=''; $whp=''; $wkind2=0; $wkind3=0; }
	$WeatherName = hako_v('WeatherName', array());
	$wname2 = (is_array($WeatherName) && isset($WeatherName[$wkind2])) ? $WeatherName[$wkind2] : '';
	$wname3 = (is_array($WeatherName) && isset($WeatherName[$wkind3])) ? $WeatherName[$wkind3] : '';
	$HunitPop = hako_v('HunitPop','00명'); $HunitArea = hako_v('HunitArea','00만평'); $HunitFood = hako_v('HunitFood','00톤'); $HunitMoney = hako_v('HunitMoney','억엔'); $HunitOre = hako_v('HunitOre','톤'); $HunitOil = hako_v('HunitOil','만 배럴'); $HunitWeapon = hako_v('HunitWeapon','만 톤');
	$farm0 = hako_arr_get($island, 'farm', 0); $factory0 = hako_arr_get($island, 'factory', 0); $port0 = hako_arr_get($island, 'port', 0); $mountain0 = hako_arr_get($island, 'mountain', 0); $tower0 = hako_arr_get($island, 'tower', 0); $yousyoku0 = hako_arr_get($island, 'yousyoku', 0);
	$farm = ($farm0 == 0) ? '보유 안함' : $farm0.'0'.$HunitPop;
	$factory = ($factory0 == 0) ? '보유 안함' : $factory0.'0'.$HunitPop;
	$port = ($port0 == 0) ? '보유 안함' : $port0.'0'.$HunitPop;
	$mountain = ($mountain0 == 0) ? '보유 안함' : $mountain0.'0'.$HunitPop;
	$tower = ($tower0 == 0) ? '보유 안함' : $tower0.'0'.$HunitPop;
	$ore = (hako_arr_get($island, 'ore', 0) == 0) ? '보유 안함' : hako_arr_get($island, 'ore', 0).$HunitOre;
	$oil = (hako_arr_get($island, 'oil', 0) == 0) ? '보유 안함' : hako_arr_get($island, 'oil', 0).$HunitOil;
	$weapon = (hako_arr_get($island, 'weapon', 0) == 0) ? '보유 안함' : hako_arr_get($island, 'weapon', 0).$HunitWeapon;
	$soukei = intval(($factory0 + $port0 + $mountain0 + $tower0 + $farm0 + ($yousyoku0 / 10)) * 10);
	$soukeiTxt = ($soukei == 0) ? '보유 안함' : $soukei.$HunitPop;
	$seisan = $farm0 * 10;
	if ($yousyoku0 == 0) { $yousyoku = '보유 안함'; } else { $seisan += $yousyoku0; $yousyoku = $yousyoku0.'00마리'; }
	$seisanTxt = ($seisan == 0) ? '없음' : $seisan.$HunitFood;
	if ((hako_v('HhideMoneyMode', 2) == 1) || (hako_v('HmainMode','') == 'owner')) { $mStr0 = '<TD '.hako_v('HbgInfoCell','').'>'.hako_arr_get($island,'MissileK','').'</TD>'; $mStr1 = '<TD '.hako_v('HbgInfoCell','').'>'.hako_arr_get($island,'MissileA','').'</TD>'; $mStr3 = '<TD '.hako_v('HbgInfoCell','').'>'.hako_arr_get($island,'money',0).$HunitMoney.'</TD>'; }
	elseif (hako_v('HhideMoneyMode', 2) == 2) { $mTmp = function_exists('aboutMoney') ? aboutMoney(hako_arr_get($island,'money',0)) : hako_arr_get($island,'money',0).$HunitMoney; $mStr0 = '<TD '.hako_v('HbgInfoCell','').'>기밀</TD>'; $mStr1 = '<TD '.hako_v('HbgInfoCell','').'>기밀</TD>'; $mStr3 = '<TD '.hako_v('HbgInfoCell','').'>'.$mTmp.'</TD>'; }
	else { $mStr0 = '<TD '.hako_v('HbgInfoCell','').'>기밀</TD>'; $mStr1 = '<TD '.hako_v('HbgInfoCell','').'>기밀</TD>'; $mStr3 = '<TD '.hako_v('HbgInfoCell','').'>기밀</TD>'; }
	$popspace = hako_arr_get($island, 'popspace', 0); $popspace = ($popspace > 0) ? $popspace.$HunitPop : '　';
	if (hako_v('HmainMode','') == 'bfield') {
		echo "<DIV ID='islandInfo'><TABLE BORDER><TR>\n<TD ".hako_v('HbgTitleCell','').">".hako_v('HtagTH_','')."ID".hako_v('H_tagTH','')."</TD>\n<TD ".hako_v('HbgInfoCell','').">".hako_arr_get($island,'id','')."</TD>\n<TD ".hako_v('HbgTitleCell','').">".hako_v('HtagTH_','')."기후".hako_v('H_tagTH','')."</TD>\n<TD ".hako_v('HbgSubTCell','').">오늘</TD>\n<TD ".hako_v('HbgInfoCell','').">$wname</TD>\n<TD ".hako_v('HbgSubTCell','').">내일</TD>\n<TD ".hako_v('HbgInfoCell','').">$wname2</TD>\n<TD ".hako_v('HbgSubTCell','').">모레</TD>\n<TD ".hako_v('HbgInfoCell','').">$wname3</TD>\n<TD ".hako_v('HbgSubTCell','').">습도</TD>\n<TD ".hako_v('HbgInfoCell','').">$whp</TD>\n</TR></TABLE>\n주의：Battle Field에의 노멀, PP미사일, 기념비 떨어뜨려, 이민, 괴수 파견 이외의 명령은 무시됩니다.<BR>\n</DIV>\n";
		return;
	}
	echo "<DIV ID='islandInfo'><TABLE BORDER>\n";
	echo "<TR><TH ".hako_v('HbgTitleCell','')." colspan=2>".hako_v('HtagTH_','')."성적".hako_v('H_tagTH','')."</TH><TH ".hako_v('HbgTitleCell','')." colspan=2>".hako_v('HtagTH_','')."기후".hako_v('H_tagTH','')."</TH><TH ".hako_v('HbgTitleCell','')." colspan=2>".hako_v('HtagTH_','')."자산".hako_v('H_tagTH','')."</TH><TH ".hako_v('HbgTitleCell','')." colspan=2>".hako_v('HtagTH_','')."일차 산업".hako_v('H_tagTH','')."</TH><TH ".hako_v('HbgTitleCell','')." colspan=2>".hako_v('HtagTH_','')."2차 산업".hako_v('H_tagTH','')."</TH><TH ".hako_v('HbgTitleCell','')." colspan=2>".hako_v('HtagTH_','')."삼차 산업".hako_v('H_tagTH','')."</TH><TH ".hako_v('HbgTitleCell','')." colspan=2>".hako_v('HtagTH_','')."군사력".hako_v('H_tagTH','')."</TH></TR>\n";
	echo "<TR><TD ".hako_v('HbgSubTCell','').">순위</TD><TD ".hako_v('HbgInfoCell','').">".hako_v('HtagNumber_','').$rank.hako_v('H_tagNumber','')."(".hako_arr_get($island,'zyuni','').")</TD><TD ".hako_v('HbgSubTCell','').">오늘</TD><TD ".hako_v('HbgInfoCell','').">$wname</TD><TD ".hako_v('HbgSubTCell','').">자금</TD>$mStr3<TD ".hako_v('HbgSubTCell','').">농장 규모</TD><TD ".hako_v('HbgInfoCell','').">$farm</TD><TD ".hako_v('HbgSubTCell','').">공장</TD><TD ".hako_v('HbgInfoCell','').">$factory</TD><TD ".hako_v('HbgSubTCell','').">상업</TD><TD ".hako_v('HbgInfoCell','').">$tower</TD><TD ".hako_v('HbgSubTCell','').">미사일 발사 가능수</TD>$mStr0</TR>\n";
	echo "<TR><TD ".hako_v('HbgSubTCell','').">총인구</TD><TD ".hako_v('HbgInfoCell','').">".hako_arr_get($island,'pop',0).$HunitPop."</TD><TD ".hako_v('HbgSubTCell','').">내일</TD><TD ".hako_v('HbgInfoCell','').">$wname2</TD><TD ".hako_v('HbgSubTCell','').">식량</TD><TD ".hako_v('HbgInfoCell','').">".hako_arr_get($island,'food',0).$HunitFood."</TD><TD ".hako_v('HbgSubTCell','').">양식장 규모</TD><TD ".hako_v('HbgInfoCell','').">$yousyoku</TD><TD ".hako_v('HbgSubTCell','').">항구</TD><TD ".hako_v('HbgInfoCell','').">$port</TD><TD ".hako_v('HbgSubTCell','').">　</TD><TD ".hako_v('HbgInfoCell','').">　</TD><TD ".hako_v('HbgSubTCell','').">병기량</TD><TD ".hako_v('HbgInfoCell','').">$weapon</TD></TR>\n";
	echo "<TR><TD ".hako_v('HbgSubTCell','').">우주민</TD><TD ".hako_v('HbgInfoCell','').">$popspace</TD><TD ".hako_v('HbgSubTCell','').">모레</TD><TD ".hako_v('HbgInfoCell','').">$wname3</TD><TD ".hako_v('HbgSubTCell','').">광석</TD><TD ".hako_v('HbgInfoCell','').">$ore</TD><TD ".hako_v('HbgSubTCell','').">　</TD><TD ".hako_v('HbgInfoCell','').">　</TD><TD ".hako_v('HbgSubTCell','').">채굴장</TD><TD ".hako_v('HbgInfoCell','').">$mountain</TD><TD ".hako_v('HbgSubTCell','').">　</TD><TD ".hako_v('HbgInfoCell','').">　</TD><TD ".hako_v('HbgSubTCell','').">발사 미사일수</TD>$mStr1</TR>\n";
	echo "<TR><TD ".hako_v('HbgSubTCell','').">면적</TD><TD ".hako_v('HbgInfoCell','').">".hako_arr_get($island,'area',0).$HunitArea."</TD><TD ".hako_v('HbgSubTCell','').">습도</TD><TD ".hako_v('HbgInfoCell','').">$whp</TD><TD ".hako_v('HbgSubTCell','').">원유</TD><TD ".hako_v('HbgInfoCell','').">$oil</TD><TD ".hako_v('HbgSubTCell','').">식량 최대 생산</TD><TD ".hako_v('HbgInfoCell','').">$seisanTxt</TD><TD ".hako_v('HbgSubTCell','').">　</TD><TD ".hako_v('HbgInfoCell','').">　</TD><TD ".hako_v('HbgSubTCell','').">총직수</TD><TD ".hako_v('HbgInfoCell','').">$soukeiTxt</TD><TD ".hako_v('HbgSubTCell','').">총획득 경험치</TD><TD ".hako_v('HbgInfoCell','').">".hako_arr_get($island,'allex','')."</TD></TR></TABLE></DIV>\n";
}
}

if (!function_exists('tempPrintIslandHead')) {
function tempPrintIslandHead($extra = '') {
	echo "<CENTER>\n".hako_v('HtagBig_','').hako_v('HtagName_','')."「".hako_v('HcurrentName','').hako_v('AfterName','도')."」".hako_v('H_tagName','')."도착했습니다!".$extra.hako_v('H_tagBig','')."<BR>\n".hako_v('HtempBack','')."<BR>\n</CENTER>\n";
}
}

if (!function_exists('hako_html_escape_legacy')) {
function hako_html_escape_legacy($s) {
	return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}
}

if (!function_exists('hako_reset_map_count')) {
function hako_reset_map_count() {
	$GLOBALS['LandCount'] = array();
	$GLOBALS['LandCount2'] = array();
}
}

if (!function_exists('hako_option_numbers')) {
function hako_option_numbers($max, $selected) {
	$out = '';
	for ($i = 0; $i < $max; $i++) {
		$s = ((string)$i === (string)$selected) ? ' SELECTED' : '';
		$out .= "<OPTION VALUE=$i$s>$i\n";
	}
	return $out;
}
}

if (!function_exists('hako_amount_options')) {
function hako_amount_options($selected = 0) {
	$out = '';
	for ($i = 0; $i < 50; $i++) {
		$s = ((string)$i === (string)$selected) ? ' SELECTED' : '';
		$out .= "<OPTION VALUE=$i$s>$i\n";
	}
	for ($i = 50; $i <= 950; $i += 50) {
		$s = ((string)$i === (string)$selected) ? ' SELECTED' : '';
		$out .= "<OPTION VALUE=$i$s>$i\n";
	}
	return $out;
}
}

if (!function_exists('hako_get_island_list_options')) {
function hako_get_island_list_options($selected = 0) {
	if (function_exists('getIslandList')) { return getIslandList($selected); }
	$out = '';
	$n = intval(hako_v('HislandNumber', 0));
	for ($i = 0; $i < $n; $i++) {
		$is = hako_island_by_number($i);
		$id = hako_arr_get($is, 'id', '');
		if ($id === '') { continue; }
		$name = hako_arr_get($is, 'name', '');
		$s = ((string)$id === (string)$selected) ? ' SELECTED' : '';
		$out .= '<OPTION VALUE="'.$id.'"'.$s.'>'.$name.hako_v('AfterName','도')."\n";
	}
	return $out;
}
}

if (!function_exists('hako_command_kind_list')) {
function hako_command_kind_list() {
	$list = hako_v('HcomList', null);
	if (is_array($list) && count($list) > 0) { return $list; }

	// CGI 원본 hako-map.cgi 의 @HcomList 순서를 그대로 사용한다.
	// PHP 배열 키 정렬로 대체하면 Java 모드 팝업 커맨드 순서가 CGI와 달라진다.
	$orderNames = array(
		'HcomPrepare', 'HcomPrepare2', 'HcomReclaim', 'HcomReclaim2', 'HcomDestroy', 'HcomDestroy2', 'HcomSearch',
		'HcomSellTree', 'HcomPlant', 'HcomBank', 'HcomPioneer', 'HcomFarm', 'HcomFactory', 'HcomMountain',
		'HcomBase', 'HcomDbase', 'HcomSbase', 'HcomMonument', 'HcomSMonument', 'HcomShipbuild', 'HcomDokan', 'HcomUg', 'HcomHaribote',
		'HcomScity', 'HcomSFarm', 'HcomTower', 'HcomPort', 'HcomBreakwater', 'HcomFire', 'HcomWindmill', 'HcomMyhome', 'HcomPolice', 'HcomHospital',
		'HcomPresent', 'HcomPresentAid', 'HcomWarp', 'HcomDeathtrap', 'HcomTrump', 'HcomFlower',
		'HcomManipulate', 'HcomSTManipulate', 'HcomSpy', 'HcomTeisatu', 'Hcomcolony', 'HcomShip', 'HcomShipM',
		'HcomShipSell', 'HcomBioMissile', 'HcomMissileNM', 'HcomMissilePP', 'HcomMissileSPP', 'HcomMissileRNG',
		'HcomMissileST', 'HcomMissileLD', 'HcomSendMonster', 'HcomSSendMonster',
		'HcomMissileRM', 'HcomMissileSRM', 'HcomMissileGM', 'HcomMissileMGM', 'HcomMissileDM',
		'HcomMissilePLD', 'HcomMissileNCM', 'HcomDummy', 'HcomDoNothing',
		'HcomMonsEgg', 'HcomMonsEsa', 'HcomMonsEnsei', 'HcomMonsTettai', 'HcomMonsEsaAid', 'HcomMonsAid', 'HcomMonsSell', 'HcomMonsExer',
		'HcomSUnit', 'HcomSPioneer', 'HcomSBuild', 'HcomSpaceFarm', 'HcomSFactory', 'HcomSpaceBase', 'HcomSDbase', 'HcomSEisei',
		'HcomSMissileGM', 'HcomSMissilePP', 'HcomSMissile', 'HcomSMissileMGM', 'HcomSOccupy', 'HcomSFood', 'HcomSDestroy',
		'HcomOMissileNM', 'HcomOMissilePP', 'HcomOMissileSPP',
		'HcomSell', 'HcomOreSell', 'HcomOilSell', 'HcomWeponSell',
		'HcomOreBuy', 'HcomOilBuy', 'HcomWeponBuy',
		'HcomMoney', 'HcomFood', 'HcomEmigration', 'HcomPropaganda', 'HcomGiveup',
		'HcomAutoPrepare', 'HcomAutoPrepare2', 'HcomAutoSellTree', 'HcomAutoDelete'
	);
	$out = array();
	foreach ($orderNames as $name) {
		if (isset($GLOBALS[$name])) { $out[] = $GLOBALS[$name]; }
	}
	if (hako_v('Hbuycommand', 0)) {
		array_splice($out, 95, 3);
	}
	$GLOBALS['HcomList'] = $out;
	$GLOBALS['HcommandTotal'] = count($out);
	if (count($out) > 0) { return $out; }

	$names = hako_v('HcomName', array());
	$keys = array();
	if (is_array($names)) {
		foreach ($names as $k => $v) {
			if ($v !== '' && $v !== null) { $keys[] = $k; }
		}
	}
	sort($keys, SORT_NUMERIC);
	return $keys;
}
}

if (!function_exists('hako_command_cost_label')) {
function hako_command_cost_label($kind, $auto = 0) {
	$costs = hako_v('HcomCost', array());
	$cost = (is_array($costs) && isset($costs[$kind])) ? $costs[$kind] : 0;
	if ($cost == 0) { return $auto ? '자동 무료' : '무료'; }
	if ($cost < 0) { return (-$cost).hako_v('HunitFood','00톤'); }
	return $cost.hako_v('HunitMoney','억엔');
}
}

if (!function_exists('hako_command_select_options')) {
function hako_command_select_options($selected = 0) {
	$names = hako_v('HcomName', array());
	$out = '';
	foreach (hako_command_kind_list() as $kind) {
		$name = (is_array($names) && isset($names[$kind])) ? $names[$kind] : ('명령'.$kind);
		$s = ((string)$kind === (string)$selected) ? ' SELECTED' : '';
		$out .= '<OPTION VALUE="'.$kind.'"'.$s.'>'.hako_html_escape_legacy($name).'('.hako_command_cost_label($kind).")\n";
	}
	return $out;
}
}

if (!function_exists('hako_java_command_categories')) {
function hako_java_command_categories() {
	$divs = hako_v('HcommandDivido', array());
	$out = "<OPTION VALUE=>전종류\n\n";
	if (is_array($divs)) {
		foreach ($divs as $i => $v) {
			$parts = explode(',', $v);
			$name = isset($parts[0]) ? $parts[0] : ('분류'.$i);
			$out .= '<OPTION VALUE="'.$i.'">'.hako_html_escape_legacy($name)."\n";
		}
	}
	return $out;
}
}

if (!function_exists('hako_java_command_menu')) {
function hako_java_command_menu() {
	$names = hako_v('HcomName', array());
	$divs = hako_v('HcommandDivido', array());
	$list = hako_command_kind_list();
	$keyName = array();
	$keyMap = array(
		'HcomPrepare2' => '(Z)', 'HcomPlant' => '(S)', 'HcomReclaim' => '(U)', 'HcomDestroy' => '(K)',
		'HcomFarm' => '(N)', 'HcomPresent' => '(P)', 'HcomBase' => '(B)', 'HcomDbase' => '(D)'
	);
	foreach ($keyMap as $g => $v) { $k = intval(hako_v($g, -1)); if ($k >= 0) { $keyName[$k] = $v; } }
	$exclude = array(
		intval(hako_v('HcomHaribote', -9999)) => true,
		intval(hako_v('HcomPolice', -9999)) => true,
		intval(hako_v('HcomMyhome', -9999)) => true,
		intval(hako_v('HcomDon', -9999)) => true,
		intval(hako_v('HcomUg', -9999)) => true
	);
	$out1 = '';
	$out2 = '';
	if (is_array($divs) && count($divs) > 0 && is_array($list) && count($list) > 0) {
		foreach ($divs as $m => $div) {
			$parts = explode(',', $div);
			$dd = isset($parts[1]) ? intval($parts[1]) : -999999;
			$ff = isset($parts[2]) ? intval($parts[2]) : 999999;
			foreach ($list as $kind) {
				$kind = intval($kind);
				if ($kind <= ($dd - 1)) { continue; }
				if ($kind >= ($ff + 1)) { break; }
				if (isset($exclude[$kind])) { continue; }
				$name = (is_array($names) && isset($names[$kind])) ? $names[$kind] : ('명령'.$kind);
				$name = str_replace(array('\\n', "\r", "\n"), '', $name);
				$cost = hako_command_cost_label($kind);
				$key = isset($keyName[$kind]) ? $keyName[$kind] : '';
				$line = "<a href='javascript:void(0);' onClick='cominput(myForm,6,$kind,0)' class='M' TITLE='".hako_html_escape_legacy($cost)."'>".hako_html_escape_legacy($name.$key)."</a>";
				if ($m == 0 || $kind == intval(hako_v('HcomFlower', -1))) {
					if ($kind == intval(hako_v('HcomPrepare2', -1))) {
						$out1 .= $line." (<a href='javascript:void(0);' onClick='cominput(myForm,8,$kind,0)' class='M' TITLE='".hako_html_escape_legacy($cost)."'>ALL</a>)<br>\n";
					} else {
						$out1 .= $line."<br>\n";
					}
				} elseif ($m == 1) {
					$out2 .= $line."<br>\n";
				}
				if ($kind == intval(hako_v('HcomSFarm', -1))) { $out2 .= "<hr>"; }
			}
		}
		foreach (array('HcomShip','HcomEmigration') as $g) {
			$kind = intval(hako_v($g, -1));
			if ($kind >= 0) {
				$name = (is_array($names) && isset($names[$kind])) ? $names[$kind] : ('명령'.$kind);
				$name = str_replace(array('\\n', "\r", "\n"), '', $name);
				$cost = hako_command_cost_label($kind);
				$key = isset($keyName[$kind]) ? $keyName[$kind] : '';
				$out1 .= "<a href='javascript:void(0);' onClick='cominput(myForm,6,$kind,0)' class='M' TITLE='".hako_html_escape_legacy($cost)."'>".hako_html_escape_legacy($name)."</a>".hako_html_escape_legacy($key)."<br>\n";
			}
		}
	} else {
		$i = 0;
		foreach ($list as $k) {
			$name = (is_array($names) && isset($names[$k])) ? $names[$k] : ('명령'.$k);
			$line = "<a href='javascript:void(0);' onClick='cominput(hakoOwnerForm(),6,$k,0)' class='M'>".hako_html_escape_legacy($name)."</a><br>\n";
			if($i < 18) { $out1 .= $line; } else { $out2 .= $line; }
			$i++;
		}
	}
	return array($out1, $out2);
}
}

if (!function_exists('hako_java_presentation_menu')) {
function hako_java_presentation_menu() {
	$island = hako_current_island();
	$present = hako_arr_get($island, 'present', array());
	if (!is_array($present)) { $present = array(); }
	$labels = array('공원','스타디움','돔','카지노','유원지','학교','공항','대도시','동물원','박람회','괴수 기념비','재해의 비');
	$buildKind = intval(hako_v('HcomPresent', 16));
	$giveKind  = intval(hako_v('HcomPresentAid', 98));
	$out = "선물 건설(무료)<br>\n";
	$out .= "선물 양도(무료)<br><br>\n";
	$total = 0;
	for ($i = 0; $i < count($labels); $i++) { $total += intval(isset($present[$i]) ? $present[$i] : 0); }
	if ($total == 0) {
		$out .= "선물이 없습니다.<br><br>\n";
		return $out;
	}
	for ($i = 0; $i < count($labels); $i++) {
		$count = intval(isset($present[$i]) ? $present[$i] : 0);
		if ($count <= 0) { continue; }
		$label = hako_html_escape_legacy($labels[$i]);
		$out .= "<a href='javascript:void(0);' class='M' onClick='cominput(myForm,6,$buildKind,$i)'>".$label." 건설</a><br>\n";
		$out .= "<a href='javascript:void(0);' class='M' onClick='cominput(myForm,6,$giveKind,$i)'>".$label." 양도(".$count.")</a><br>\n";
	}
	return $out;
}
}

if (!function_exists('hako_command_cost_text')) {
function hako_command_cost_text($kind) {
	$costs = hako_v('HcomCost', array());
	if (!is_array($costs) || !isset($costs[$kind])) { return ''; }
	$cost = $costs[$kind];
	if ($cost == 0) { return ''; }
	return '('.hako_command_cost_label($kind).')';
}
}

if (!function_exists('hako_command_cost_raw')) {
function hako_command_cost_raw($kind) {
	$costs = hako_v('HcomCost', array());
	return (is_array($costs) && isset($costs[$kind])) ? intval($costs[$kind]) : 0;
}
}

if (!function_exists('hako_command_text')) {
function hako_command_text($number, $command) {
	$kind = intval(hako_arr_get($command, 'kind', hako_v('HcomDoNothing', 0)));
	$names = hako_v('HcomName', array());
	$nameRaw = (is_array($names) && isset($names[$kind])) ? $names[$kind] : ('명령'.$kind);
	$name = hako_v('HtagComName_','').$nameRaw.hako_v('H_tagComName','');
	$target = hako_arr_get($command, 'target', hako_v('HcurrentID', 0));
	$x = intval(hako_arr_get($command, 'x', 0));
	$y = intval(hako_arr_get($command, 'y', 0));
	$arg = intval(hako_arr_get($command, 'arg', 0));
	$tx = intval(hako_arr_get($command, 'tx', 0));
	$ty = intval(hako_arr_get($command, 'ty', 0));
	$tname = hako_name_by_id($target);
	if ($tname === '') { $tname = '무인'; }
	$targetTxt = hako_v('HtagName_','').$tname.hako_v('AfterName','도').hako_v('H_tagName','');
	$point = hako_v('HtagName_','').'('.$x.','.$y.')'.hako_v('H_tagName','');
	$point2 = hako_v('HtagName_','').'('.$tx.','.$ty.')'.hako_v('H_tagName','');
	$doNothing = intval(hako_v('HcomDoNothing', 97));
	$giveup = intval(hako_v('HcomGiveup', 100));
	$smgm = intval(hako_v('HcomSMissileMGM', -1));
	if (($kind == $doNothing) || ($kind == $giveup) || ($kind == $smgm)) { return $name; }

	$missiles = array('HcomBioMissile','HcomMissileNM','HcomMissilePP','HcomMissileSPP','HcomMissileST','HcomMissileLD','HcomMissileRM','HcomMissileSRM','HcomMissileGM','HcomMissilePLD','HcomMissileNCM','HcomMissileRNG','HcomMissileDM','HcomSMissileGM','HcomSMissilePP','HcomSMissile','HcomOMissileNM','HcomOMissilePP','HcomOMissileSPP','HcomMissileMGM');
	foreach ($missiles as $mk) {
		if ($kind == intval(hako_v($mk, -9999))) {
			if ($kind == intval(hako_v('HcomMissileMGM', -9999))) { return $targetTxt.' 에 '.$name; }
			$n = ($arg == 0) ? '무제한' : ($arg.'발');
			return $targetTxt.$point.' 에 '.$name.'('.hako_v('HtagName_','').$n.hako_v('H_tagName','').')';
		}
	}

	$targetOnly = array('HcomMoney','HcomFood','HcomSendMonster','HcomSSendMonster','HcomOreSell','HcomOilSell','HcomWeponSell','HcomPresentAid','HcomMonsEsaAid','HcomMonsAid','HcomMonsEnsei','HcomTeisatu','HcomSpy');
	foreach ($targetOnly as $mk) {
		if ($kind == intval(hako_v($mk, -9999))) {
			return $targetTxt.' 에 '.$name.(($arg > 0) ? '('.$arg.')' : '');
		}
	}

	if ($kind == intval(hako_v('HcomSell', -9999))) {
		$cnt = ($arg == 0) ? 1 : $arg;
		return $name.'('.($cnt * 100).hako_v('HunitFood','톤').')';
	}
	if ($kind == intval(hako_v('HcomPropaganda', -9999))) {
		return $name.(($arg > 0) ? '('.$arg.'회)' : '');
	}
	if ($kind == intval(hako_v('HcomDestroy', -9999))) {
		if ($arg > 0) { return $point.'으로 '.$name.'(예산'.($arg * hako_command_cost_raw($kind)).hako_v('HunitMoney','원').')'; }
		return $point.'으로 '.$name;
	}
	if ($kind == intval(hako_v('HcomPrepare2', -9999)) && $arg == 22) {
		return hako_v('HtagComName_','').'황무지 모두 땅 고르기'.hako_v('H_tagComName','');
	}
	if ($kind == intval(hako_v('HcomUg', -9999))) {
		return $point.'의 지하'.$point2.'으로 '.$name;
	}
	if (($tx != 0) || ($ty != 0)) {
		return $point.'에서 '.$point2.'로 '.$name;
	}
	if ($arg > 0) {
		return $point.'으로 '.$name.'('.$arg.')';
	}
	return $point.'으로 '.$name;
}
}

if (!function_exists('tempCommand')) {
function tempCommand($number, $command) {
	$j = sprintf('%02d :', $number + 1);
	echo '<A STYLE="text-decoration:none;" HREF="JavaScript:void(0);" onClick="ns('.intval($number).')">'.hako_v('HtagNumber_','').$j.hako_v('H_tagNumber','').hako_v('HnormalColor_','').hako_command_text($number, $command).hako_v('H_normalColor','').'</A><BR>' . "\n";
}
}

if (!function_exists('hako_js_initial_plan_html')) {
function hako_js_initial_plan_html() {
	$island = hako_current_island();
	$commands = hako_arr_get($island, 'command', array());
	$max = intval(hako_v('HcommandMax', 30));
	$out = '<TABLE border=0><TR><TD class="commandjs1"><B>◎◎◎◎ 송신이 끝난 상태 ◎◎◎◎</B><br><br>';
	for ($i = 0; $i < $max; $i++) {
		$c = (is_array($commands) && isset($commands[$i]) && is_array($commands[$i])) ? $commands[$i] : hako_command_row(hako_v('HcomDoNothing',97), 0, 0, 0, 0, 0, 0, 0);
		$j = sprintf('%02d', $i + 1);
		$out .= '<div id="com_'.$i.'" onmouseover="mc_over('.$i.');return false;"><A STYLE="text-decoration:none;color:000000" HREF="JavaScript:void(0);" onClick="ns('.$i.');return false;"><NOBR>'.$j.':'.hako_command_text($i, $c).'</NOBR></A></div>';
	}
	$out .= '<br><B>◎◎◎◎ 송신이 끝난 상태 ◎◎◎◎</B></TD></TR></TABLE>';
	return $out;
}
}

if (!function_exists('hako_auto_command_options')) {
function hako_auto_command_options($selected = 0) {
	$names = hako_v('HcomName', array());
	$divs = hako_v('HcommandDivido', array());
	$lastEnd = 149;
	if (is_array($divs) && count($divs) > 0) {
		$last = $divs[count($divs)-1];
		$parts = explode(',', $last);
		if (isset($parts[2])) { $lastEnd = intval($parts[2]); }
	}
	$out = '';
	foreach (hako_command_kind_list() as $kind) {
		if (!(($kind > $lastEnd) && ($kind < 190))) { continue; }
		if ($kind == intval(hako_v('HcomAutoSellTree', -1))) { continue; }
		$name = (is_array($names) && isset($names[$kind])) ? $names[$kind] : ('명령'.$kind);
		$s = ((string)$kind === (string)$selected) ? ' SELECTED' : '';
		$out .= '<OPTION VALUE="'.$kind.'"'.$s.'>'.hako_html_escape_legacy($name).'('.hako_command_cost_label($kind, 1).")\n";
	}
	return $out;
}
}

if (!function_exists('hako_js_utf8_clean')) {
function hako_js_utf8_clean($data) {
	if (is_array($data)) {
		$out = array();
		foreach ($data as $k => $v) { $out[$k] = hako_js_utf8_clean($v); }
		return $out;
	}
	if (is_string($data)) {
		if (function_exists('mb_check_encoding') && !mb_check_encoding($data, 'UTF-8')) {
			$cv = @iconv('CP932', 'UTF-8//IGNORE', $data);
			if ($cv === false || $cv === '') { $cv = @iconv('EUC-JP', 'UTF-8//IGNORE', $data); }
			if ($cv !== false && $cv !== '') { return $cv; }
		}
		return $data;
	}
	return $data;
}
}

if (!function_exists('hako_js_encode')) {
function hako_js_encode($data) {
	$data = hako_js_utf8_clean($data);
	$flags = defined('JSON_HEX_TAG') ? (JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP) : 0;
	$json = ($flags ? json_encode($data, $flags) : json_encode($data));
	if ($json === false || $json === null || $json === '') {
		if (is_array($data)) { return '[]'; }
		return 'null';
	}
	return $json;
}
}

if (!function_exists('hako_js_command_payload')) {
function hako_js_command_payload() {
	$island = hako_current_island();
	$commands = hako_arr_get($island, 'command', array());
	$max = intval(hako_v('HcommandMax', 30));
	$doNothing = intval(hako_v('HcomDoNothing', 97));
	$cmd = array();
	for ($i = 0; $i < $max; $i++) {
		$c = (is_array($commands) && isset($commands[$i]) && is_array($commands[$i])) ? $commands[$i] : array();
		$cmd[] = array(
			intval(hako_arr_get($c, 'kind', $doNothing)),
			intval(hako_arr_get($c, 'x', 0)),
			intval(hako_arr_get($c, 'y', 0)),
			intval(hako_arr_get($c, 'arg', 0)),
			intval(hako_arr_get($c, 'target', hako_v('HcurrentID', 0))),
			intval(hako_arr_get($c, 'tx', 0)),
			intval(hako_arr_get($c, 'ty', 0))
		);
	}
	$names = hako_v('HcomName', array());
	$divs = hako_v('HcommandDivido', array());
	$comlist = array();
	if (is_array($divs)) {
		foreach ($divs as $div) {
			$parts = explode(',', $div);
			$start = isset($parts[1]) ? intval($parts[1]) : 0;
			$end = isset($parts[2]) ? intval($parts[2]) : 0;
			$list = array();
			foreach (hako_command_kind_list() as $kind) {
				if (($kind < $start) || ($kind > $end)) { continue; }
				$name = (is_array($names) && isset($names[$kind])) ? $names[$kind] : ('명령'.$kind);
				$list[] = array(intval($kind), $name, hako_command_cost_label($kind));
			}
			$comlist[] = $list;
		}
	}
	$islands = array();
	$n = intval(hako_v('HislandNumber', 0));
	for ($i = 0; $i < $n; $i++) {
		$is = hako_island_by_number($i);
		$id = hako_arr_get($is, 'id', '');
		if ($id === '') { continue; }
		$islands[strval($id)] = hako_arr_get($is, 'name', '');
	}
	$islands['999'] = hako_v('SpaceName','우주');
	$islands['888'] = hako_v('OceanName','해역');
	return array($cmd, $comlist, $islands);
}
}

if (!function_exists('hako_js_quote')) {
function hako_js_quote($s) {
	$s = str_replace(array("\\", "\r", "\n", "'"), array("\\\\", "", "\\n", "\\'"), (string)$s);
	return $s;
}
}

if (!function_exists('hako_owner_scripts')) {
function hako_owner_scripts() {
	$hthis = hako_v('HthisFile','hako-main.php');
	$comName = hako_v('HcomName', array());
	$comMsg = hako_v('HcomMsg', array());
	$msg = '';
	foreach (hako_command_kind_list() as $kind) {
		$name = is_array($comName) && isset($comName[$kind]) ? $comName[$kind] : ('명령'.$kind);
		$stat = is_array($comMsg) && isset($comMsg[$kind]) && $comMsg[$kind] !== '' ? $comMsg[$kind] : $name;
		$msg .= 'COMNAME['.intval($kind).'] = \''.hako_js_quote($name).'\';' . "\n";
		$msg .= 'COMMSG['.intval($kind).'] = \''.hako_js_quote($stat).'\';' . "\n";
	}
	$island = hako_current_island();
	$id = intval(hako_arr_get($island, 'id', hako_v('HcurrentID', 0)));
	$commands = hako_arr_get($island, 'command', array());
	$cmdJs = '';
	$max = intval(hako_v('HcommandMax', 30));
	for ($i = 0; $i < $max; $i++) {
		if (!is_array($commands) || !isset($commands[$i]) || !is_array($commands[$i])) { continue; }
		$c = $commands[$i];
		$kind = intval(hako_arr_get($c, 'kind', hako_v('HcomDoNothing', 0)));
		if ($kind >= 50) { continue; }
		$x = intval(hako_arr_get($c, 'x', 0));
		$y = intval(hako_arr_get($c, 'y', 0));
		$name = is_array($comName) && isset($comName[$kind]) ? $comName[$kind] : ('명령'.$kind);
		$cmdJs .= "COMAT['".$x."_".$y."'] = (COMAT['".$x."_".$y."'] || '') + ' [".($i + 1)."]".hako_js_quote($name)."';\n";
	}
	$payload = function_exists('hako_js_command_payload') ? hako_js_command_payload() : array(array(), array(), array());
	$commandJson = hako_js_encode(isset($payload[0]) ? $payload[0] : array());
	$comlistJson = hako_js_encode(isset($payload[1]) ? $payload[1] : array());
	$islandJson = hako_js_encode(isset($payload[2]) ? $payload[2] : array());
	$doNothing = intval(hako_v('HcomDoNothing', 97));
	$giveup = intval(hako_v('HcomGiveup', 100));
	$smgm = intval(hako_v('HcomSMissileMGM', -1));
	$defaultKind = intval(hako_v('HdefaultKind', $doNothing));
	$keyPrepare2 = intval(hako_v('HcomPrepare2', 2));
	$keyPlant = intval(hako_v('HcomPlant', 11));
	$keyReclaim = intval(hako_v('HcomReclaim', 3));
	$keyDestroy = intval(hako_v('HcomDestroy', 5));
	$keyFarm = intval(hako_v('HcomFarm', 12));
	$keyPresent = intval(hako_v('HcomPresent', 16));
	$keyBase = intval(hako_v('HcomBase', 21));
	$keyDbase = intval(hako_v('HcomDbase', 22));
	$keyMissilePP = intval(hako_v('HcomMissilePP', 51));
	$keyMissileMGM = intval(hako_v('HcomMissileMGM', 61));
	$keyPropaganda = intval(hako_v('HcomPropaganda', 96));
	$keyDoNothing = intval(hako_v('HcomDoNothing', 97));
	$javaMode = hako_js_quote(hako_v('HjavaMode','cgi'));
	$hthisJs = hako_js_quote($hthis);
	echo <<<END
<SCRIPT Language="JavaScript">
<!--
var mx = 0;
var my = 0;
var COMNAME = new Array();
var COMMSG = new Array();
var COMAT = new Array();
$msg
$cmdJs
var command = $commandJson;
var comlist = $comlistJson;
var islname = $islandJson;
var HCOMMAND_MAX = $max;
var HCOM_DONOTHING = $doNothing;
var HCOM_GIVEUP = $giveup;
var HCOM_SMISSILE_MGM = $smgm;
var HDEFAULT_KIND = $defaultKind;
var HKEY_PREPARE2 = $keyPrepare2;
var HKEY_PLANT = $keyPlant;
var HKEY_RECLAIM = $keyReclaim;
var HKEY_DESTROY = $keyDestroy;
var HKEY_FARM = $keyFarm;
var HKEY_PRESENT = $keyPresent;
var HKEY_BASE = $keyBase;
var HKEY_DBASE = $keyDbase;
var HKEY_MISSILE_PP = $keyMissilePP;
var HKEY_MISSILE_MGM = $keyMissileMGM;
var HKEY_PROPAGANDA = $keyPropaganda;
var HKEY_DONOTHING = $keyDoNothing;
var HCURRENT_ID = '$id';
var HTHISFILE = '$hthisJs';
var HJAVAMODE = '$javaMode';
function hakoOwnerForm(){ return document.forms['myForm'] || document.myForm || null; }
function hakoAllForm(){ return document.forms['allForm'] || document.allForm || null; }
function hakoInitFormAliases(){ if(!window.myForm) window.myForm = hakoOwnerForm(); if(!window.allForm) window.allForm = hakoAllForm(); }
function hakoMapClick(e, x, y){ Mmove(e || window.event); return ps(x, y); }
function hakoStatusField(){ var f = hakoOwnerForm(); if(f && f.COMSTATUS) return f.COMSTATUS; var a = document.getElementsByName ? document.getElementsByName('COMSTATUS') : []; return (a && a.length) ? a[0] : null; }
function hakoSetSelect(sel, val) {
	if(!sel) return;
	for(var i = 0; i < sel.options.length; i++) {
		if(String(sel.options[i].value) == String(val)) { sel.options[i].selected = true; return; }
	}
	if(sel.options[val]) sel.options[val].selected = true;
}
function hakoGetSelectValue(sel, def) {
	if(!sel || sel.selectedIndex < 0 || !sel.options[sel.selectedIndex]) return def;
	return sel.options[sel.selectedIndex].value;
}
function hakoCommandName(kind) {
	return (COMNAME[kind] != null && COMNAME[kind] !== '') ? COMNAME[kind] : ('명령' + kind);
}
function hakoFillCommands() {
	if(!command) command = [];
	for(var i = 0; i < HCOMMAND_MAX; i++) {
		if(!command[i]) command[i] = [HCOM_DONOTHING,0,0,0,HCURRENT_ID,0,0];
	}
}
function hakoCommandText(i) {
	var c = command[i];
	if(!c) c = [HCOM_DONOTHING,0,0,0,HCURRENT_ID,0,0];
	var num = (i + 1 < 10 ? '0' : '') + (i + 1) + ':';
	var kind = parseInt(c[0], 10);
	var name = hakoCommandName(kind);
	var text;
	if(kind == HCOM_DONOTHING || kind == HCOM_GIVEUP || kind == HCOM_SMISSILE_MGM) {
		text = name;
	} else {
		text = '(' + c[1] + ',' + c[2] + ')으로 ' + name;
		if(parseInt(c[3], 10) > 0) text += '(' + c[3] + ')';
	}
	return '<div id="com_'+i+'" onmouseover="mc_over('+i+');return false;"><A STYLE="text-decoration:none;color:000000" HREF="JavaScript:void(0);" onClick="ns('+i+');return false;"><NOBR>' + num + text + '</NOBR></A></div>';
}
function plchg() {
	var strn = '';
	for(var i = 0; i < HCOMMAND_MAX; i++) strn += hakoCommandText(i);
	return strn;
}
function disp(str,bgclr) {
	var el = document.getElementById ? document.getElementById('LINKMSG1') : null;
	if(!el && document.all) el = document.all['LINKMSG1'];
	if(el) el.innerHTML = str ? str : '';
}
function outp() {
	var comary = '';
	for(var k = 0; k < HCOMMAND_MAX; k++) {
		var c = command[k];
		if(!c) c = [HCOM_DONOTHING,0,0,0,HCURRENT_ID,0,0];
		comary += parseInt(c[0],10) + ' ' + parseInt(c[1],10) + ' ' + parseInt(c[2],10) + ' ' + parseInt(c[3],10) + ' ' + parseInt(c[4],10) + ' ' + parseInt(c[5],10) + ' ' + parseInt(c[6],10) + ' ';
	}
	var mf = hakoOwnerForm(); if(mf && mf.COMARY) mf.COMARY.value = comary;
	return comary;
}
function hakoPlanBox(title, cls) {
	return '<TABLE border=0><TR><TD class="' + cls + '"><B>' + title + '</B><br><br>' + plchg() + '<br><B>' + title + '</B></TD></TR></TABLE>';
}
function refreshPlan() { outp(); disp(hakoPlanBox('◎◎◎◎ 송신이 끝난 상태 ◎◎◎◎', 'commandjs1'), '#ccffcc'); }
function refreshPlanUnsent() { outp(); disp(hakoPlanBox('◎◎◎◎◎미송신◎◎◎◎◎', 'commandjs2'), 'white'); }
function ps(x, y) {
	var mf = hakoOwnerForm();
	var af = hakoAllForm();
	if(typeof event != 'undefined' && event) { Mmove(event); }
	if(mf && mf.xy1 && mf.xy1.checked){
		hakoSetSelect(mf.POINTX, x);
		hakoSetSelect(mf.POINTY, y);
		if(af){ af.POINTX.value = x; af.POINTY.value = y; }
	}
	if(mf && mf.xy2 && mf.xy2.checked){
		hakoSetSelect(mf.POINTTX, x);
		hakoSetSelect(mf.POINTTY, y);
		if(af){ af.POINTTX.value = x; af.POINTTY.value = y; }
	}
	var sf = hakoStatusField();
	if(sf) {
		var note = '(' + x + ',' + y + ')';
		var key = String(x) + '_' + String(y);
		if(COMAT[key]) note += '\\n' + COMAT[key];
		sf.value = note;
	}
	if(mf && mf.MENUOPEN && !(mf.MENUOPEN.checked)) {
		if((!mx && !my)) {
			var map = document.getElementById ? document.getElementById('islandMap') : null;
			if(map) { mx = map.offsetLeft + 48 + (parseInt(x,10) * 32); my = map.offsetTop + 48 + (parseInt(y,10) * 32); }
		}
		var px = (mx || 0) + 10;
		var py = (my || 0) - 50;
		if(py < 10) py = 10;
		if(mf.MENUOPEN2 && mf.MENUOPEN2.checked) { moveLAYER('menu2', px, py); }
		else { moveLAYER('menu', px, py); }
	}
	return false;
}

function SelectPOINT(){
	var mf = hakoOwnerForm();
	var af = hakoAllForm();
	if(!mf || !af) return true;
	if(mf.xy1 && mf.xy1.checked){
		af.POINTX.value = hakoGetSelectValue(mf.POINTX,0);
		af.POINTY.value = hakoGetSelectValue(mf.POINTY,0);
	}
	if(mf.xy2 && mf.xy2.checked){
		af.POINTTX.value = hakoGetSelectValue(mf.POINTTX,0);
		af.POINTTY.value = hakoGetSelectValue(mf.POINTTY,0);
	}
	if(mf.NUMBER) af.NUMBER.value = hakoGetSelectValue(mf.NUMBER,0);
	if(af.submit) af.submit();
	return false;
}

function ns(x) {
	if(x >= HCOMMAND_MAX) return true;
	var mf = hakoOwnerForm();
	var af = hakoAllForm();
	if(mf && mf.NUMBER) hakoSetSelect(mf.NUMBER, x);
	if(af) af.NUMBER.value = x;
	if(typeof selCommand == 'function') selCommand(x);
	return true;
}

function openCUSTOM(){ var f = document.forms['customform']; if(f) f.submit(); return false; }
function openCAMP(){ var f = document.forms['campform']; if(f) f.submit(); return false; }
function openBBS(){ var f = document.forms['bbsform']; if(f) f.submit(); return false; }
function openCHAT(){ var f = document.forms['chatform']; if(f) f.submit(); return false; }
function hakoOpenMapUrl(url) {
	window.open(url, '', 'menubar=yes,toolbar=no,location=no,directories=no,status=yes,scrollbars=yes,resizable=yes,width=570,height=600');
	return false;
}
function jump(theForm, j_mode) {
	if(!theForm || !theForm.TARGETID) return false;
	var url = hakoGetSelectValue(theForm.TARGETID, '');
	if(url !== '') return hakoOpenMapUrl(HTHISFILE + '?IslandMap=' + url + '&JAVAMODE=' + j_mode);
	return false;
}
function jumps(j_mode, str) { return hakoOpenMapUrl(HTHISFILE + '?IslandMap=' + str + '&JAVAMODE=' + j_mode); }
function jumpu(theForm, j_mode) {
	if(!theForm || !theForm.TARGETID) return false;
	var url = parseInt(hakoGetSelectValue(theForm.TARGETID, '0'), 10) + 1000;
	return hakoOpenMapUrl(HTHISFILE + '?IslandMap=' + url + '&JAVAMODE=' + j_mode);
}
function myisland(theForm, id) { if(theForm && theForm.TARGETID) hakoSetSelect(theForm.TARGETID, id); return false; }
function set_com(x, y, land) {
	var com_str = land + "\\n";
	for(var i = 0; i < HCOMMAND_MAX; i++){
		var c = command[i];
		if(c && parseInt(c[1],10) == x && parseInt(c[2],10) == y && parseInt(c[0],10) < 50) {
			com_str += '[' + (i + 1) + ']' + hakoCommandName(parseInt(c[0],10)) + "\\n";
		}
	}
	var sf = hakoStatusField(); if(sf) sf.value = com_str;
}
function not_com() { return true; }
function StatusMsg(num) {
	var sf = hakoStatusField();
	if(sf) {
		sf.value = COMMSG[num] ? COMMSG[num] : (COMNAME[num] ? COMNAME[num] : '');
	}
}
function SelectList(theForm) {
	if(!theForm) theForm = hakoOwnerForm();
	if(!theForm || !theForm.COMMAND) return true;
	var current = hakoGetSelectValue(theForm.COMMAND, HDEFAULT_KIND);
	var list = [];
	if(theForm.menu && theForm.menu.selectedIndex > 0) {
		var ci = parseInt(hakoGetSelectValue(theForm.menu, 0), 10);
		if(comlist[ci]) list = comlist[ci];
	} else {
		for(var i = 0; i < comlist.length; i++) {
			for(var j = 0; j < comlist[i].length; j++) list[list.length] = comlist[i][j];
		}
	}
	if(list.length == 0) {
		for(var key in COMNAME) {
			if(COMNAME.hasOwnProperty(key) && COMNAME[key] !== '') { list[list.length] = [key, COMNAME[key], '']; }
		}
	}
	theForm.COMMAND.options.length = 0;
	for(var k = 0; k < list.length; k++) {
		var v = list[k][0];
		var t = list[k][1] + '(' + list[k][2] + ')';
		theForm.COMMAND.options[k] = new Option(t, v);
		if(String(v) == String(current)) theForm.COMMAND.options[k].selected = true;
	}
	if(theForm.COMMAND.options.length && theForm.COMMAND.selectedIndex < 0) theForm.COMMAND.selectedIndex = 0;
	return true;
}
function selCommand(num) {
	var c = command[num];
	var mf = hakoOwnerForm();
	if(!mf || !c) return true;
	hakoSetSelect(mf.COMMAND, c[0]);
	hakoSetSelect(mf.POINTX, c[1]);
	hakoSetSelect(mf.POINTY, c[2]);
	hakoSetSelect(mf.AMOUNT, c[3]);
	hakoSetSelect(mf.TARGETID, c[4]);
	hakoSetSelect(mf.POINTTX, c[5]);
	hakoSetSelect(mf.POINTTY, c[6]);
	StatusMsg(c[0]);
	return true;
}

function cominput(theForm, x, k, pp, z) {
	if(!theForm) theForm = hakoOwnerForm();
	if(!theForm) return false;
	var a = parseInt(hakoGetSelectValue(theForm.NUMBER,0),10);
	var b = parseInt(hakoGetSelectValue(theForm.COMMAND,HCOM_DONOTHING),10);
	var c = parseInt(hakoGetSelectValue(theForm.POINTX,0),10);
	var d = parseInt(hakoGetSelectValue(theForm.POINTY,0),10);
	var e = parseInt(hakoGetSelectValue(theForm.AMOUNT,0),10);
	var f = parseInt(hakoGetSelectValue(theForm.TARGETID,HCURRENT_ID),10);
	var cc = parseInt(hakoGetSelectValue(theForm.POINTTX,0),10);
	var dd = parseInt(hakoGetSelectValue(theForm.POINTTY,0),10);
	var newNs = a;
	if(x == 8){ x = 6; e = 22; }
	if(x == 6){ b = parseInt(k,10); if(typeof pp != 'undefined') e = parseInt(pp,10); }
	if(x == 1 || x == 2 || x == 6) {
		if(x != 2) { for(var i = HCOMMAND_MAX - 1; i > a; i--) command[i] = command[i - 1]; }
		command[a] = [b,c,d,e,f,cc,dd];
		newNs = (a + 1 < HCOMMAND_MAX) ? a + 1 : a;
		menuclose();
	} else if(x == 3) {
		for(var j = a; j < HCOMMAND_MAX - 1; j++) command[j] = command[j + 1];
		command[HCOMMAND_MAX - 1] = [HCOM_DONOTHING,0,0,0,HCURRENT_ID,0,0];
	} else if(x == 4) {
		if(a > 0) { var tmp = command[a - 1]; command[a - 1] = command[a]; command[a] = tmp; newNs = a - 1; }
	} else if(x == 5) {
		if(a < HCOMMAND_MAX - 1) { var tmp2 = command[a + 1]; command[a + 1] = command[a]; command[a] = tmp2; newNs = a + 1; }
	} else if(x == 7 && typeof k != 'undefined' && typeof z != 'undefined') {
		var from = parseInt(k,10), to = parseInt(z,10);
		if(from >= 0 && from < HCOMMAND_MAX && to >= 0 && to < HCOMMAND_MAX && from != to) {
			var moved = command[from]; command.splice(from,1); command.splice(to,0,moved); command = command.slice(0,HCOMMAND_MAX); newNs = to;
		}
	}
	refreshPlanUnsent();
	ns(newNs);
	var btn = theForm.elements ? theForm.elements['CommandJavaButton'+HCURRENT_ID] : null;
	if(btn) btn.disabled = false;
	return false;
}
function send_command(form) {
	outp();
	if(!window.XMLHttpRequest) return true;
	var xmlhttp = new XMLHttpRequest();
	var btn = form.elements ? form.elements['CommandJavaButton'+HCURRENT_ID] : null;
	if(btn) btn.disabled = true;
	var progress = document.getElementById ? document.getElementById('progress') : null;
	if(progress) progress.innerHTML = 'Sending...';
	var post = 'async=true';
	post += '&CommandJavaButton' + encodeURIComponent(HCURRENT_ID) + '=true';
	post += '&COMMAND=' + encodeURIComponent(hakoGetSelectValue(form.COMMAND,HCOM_DONOTHING));
	post += '&AMOUNT=' + encodeURIComponent(hakoGetSelectValue(form.AMOUNT,0));
	post += '&TARGETID=' + encodeURIComponent(hakoGetSelectValue(form.TARGETID,HCURRENT_ID));
	post += '&POINTX=' + encodeURIComponent(hakoGetSelectValue(form.POINTX,0));
	post += '&POINTY=' + encodeURIComponent(hakoGetSelectValue(form.POINTY,0));
	post += '&POINTTX=' + encodeURIComponent(hakoGetSelectValue(form.POINTTX,0));
	post += '&POINTTY=' + encodeURIComponent(hakoGetSelectValue(form.POINTTY,0));
	post += '&JAVAMODE=java';
	post += '&COMARY=' + encodeURIComponent(form.COMARY ? form.COMARY.value : '');
	post += '&PASSWORD=' + encodeURIComponent(form.PASSWORD ? form.PASSWORD.value : '');
	xmlhttp.onreadystatechange = function() {
		if(xmlhttp.readyState == 4) {
			var okpos = xmlhttp.responseText.indexOf('OK');
			if(xmlhttp.status == 200 && okpos >= 0 && okpos < 4096) {
				refreshPlan();
				if(progress) progress.innerHTML = '';
			} else {
				alert('송신에 실패했습니다.');
				if(btn) btn.disabled = false;
				if(progress) progress.innerHTML = '';
			}
		}
	};
	xmlhttp.open('POST', HTHISFILE, true);
	xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
	xmlhttp.send(post);
	return false;
}
function moveLAYER(layName, x, y){
	var el = document.getElementById ? document.getElementById(layName) : null;
	if(!el && document.all) el = document.all[layName];
	if(!el) return;
	if(x < 0) x = 0; if(y < 0) y = 0;
	el.style.left = x + 'px';
	el.style.top  = y + 'px';
	el.style.display = 'block';
	el.style.visibility = 'visible';
}
function menuclose(){
	var ids = ['menu','menu2','ch_num'];
	for(var i=0; i<ids.length; i++){
		var el = document.getElementById ? document.getElementById(ids[i]) : null;
		if(!el && document.all) el = document.all[ids[i]];
		if(el){ el.style.display = 'none'; el.style.visibility = 'hidden'; }
	}
}
function Mmove(e){
	e = e || window.event;
	if(e.pageX || e.pageY){ mx = e.pageX; my = e.pageY; }
	else { mx = e.clientX + document.body.scrollLeft; my = e.clientY + document.body.scrollTop; }
	return true;
}
function hakoCancelKey(e) {
	if(!e) e = window.event;
	if(e && e.preventDefault) e.preventDefault();
	if(e) e.returnValue = false;
	return false;
}
function Kdown(e){
	e = e || window.event;
	if(!e) return true;
	if(e.ctrlKey || e.altKey) return true;
	var target = e.target || e.srcElement;
	var tag = target && target.tagName ? String(target.tagName).toUpperCase() : '';
	var type = target && target.type ? String(target.type).toLowerCase() : '';
	if(tag == 'TEXTAREA' || (tag == 'INPUT' && type != 'checkbox' && type != 'radio' && type != 'button' && type != 'submit')) return true;
	var mf = hakoOwnerForm();
	if(!mf) return true;
	var code = e.which || e.keyCode || 0;
	var rawKey = (typeof e.key == 'string') ? e.key : '';
	var ch = (rawKey.length == 1) ? rawKey : String.fromCharCode(code);
	var key = ch.toUpperCase();
	if(rawKey == 'Backspace' || code == 8) {
		if(mf.NUMBER && mf.NUMBER.selectedIndex > 0) mf.NUMBER.selectedIndex = mf.NUMBER.selectedIndex - 1;
		cominput(mf, 3);
		return hakoCancelKey(e);
	}
	if(rawKey == 'Delete' || code == 46 || ch == '.') {
		cominput(mf, 3);
		return hakoCancelKey(e);
	}
	if(ch >= '0' && ch <= '9') {
		if(mf.AMOUNT) hakoSetSelect(mf.AMOUNT, parseInt(ch,10));
		return hakoCancelKey(e);
	}
	if(ch >= 'a' && ch <= 'i') {
		if(mf.AMOUNT) hakoSetSelect(mf.AMOUNT, ch.charCodeAt(0) - 96);
		return hakoCancelKey(e);
	}
	var c = null;
	if(key == 'Z') c = HKEY_PREPARE2;
	else if(key == 'S') c = HKEY_PLANT;
	else if(key == 'U') c = HKEY_RECLAIM;
	else if(key == 'K') c = HKEY_DESTROY;
	else if(key == 'N') c = HKEY_FARM;
	else if(key == 'P') c = HKEY_PRESENT;
	else if(key == 'B') c = HKEY_BASE;
	else if(key == 'D') c = HKEY_DBASE;
	else if(key == 'M') c = HKEY_MISSILE_PP;
	else if(key == 'Y') c = HKEY_MISSILE_MGM;
	else if(key == 'A') c = HKEY_PROPAGANDA;
	else if(key == '-') c = HKEY_DONOTHING;
	if(c !== null) {
		StatusMsg(c);
		cominput(mf, 6, c, 0);
		return hakoCancelKey(e);
	}
	return true;
}
function init(){
	hakoInitFormAliases();
	hakoFillCommands();
	var mf = hakoOwnerForm();
	if(mf) {
		SelectList(mf);
		refreshPlan();
		ns(0);
		var btn = mf.elements ? mf.elements['CommandJavaButton'+HCURRENT_ID] : null;
		if(btn) btn.disabled = true;
	}
	var map = document.getElementById ? document.getElementById('islandMap') : null;
	if(map && !map.hakoClickBound) {
		map.hakoClickBound = true;
		var handler = function(ev){
			ev = ev || window.event;
			var t = ev.target || ev.srcElement;
			while(t && t !== map) {
				if(t.getAttribute && t.getAttribute('data-hako-x') != null) {
					var x = parseInt(t.getAttribute('data-hako-x'),10);
					var y = parseInt(t.getAttribute('data-hako-y'),10);
					if(!isNaN(x) && !isNaN(y)) {
						hakoMapClick(ev,x,y);
						if(ev.preventDefault) ev.preventDefault();
						ev.returnValue=false;
						return false;
					}
				}
				t = t.parentNode;
			}
		};
		if(map.addEventListener) map.addEventListener('click', handler, false);
		else map.onclick = handler;
	}
}

if(document.addEventListener) {
	document.addEventListener('mousemove', Mmove, false);
	document.addEventListener('keydown', Kdown, false);
} else {
	document.onmousemove = Mmove;
	document.onkeydown = Kdown;
}
//-->
</SCRIPT>
END;
}
}

if (!function_exists('tempOwnerHeader')) {
function tempOwnerHeader() {
	$island = hako_current_island();
	$id = hako_arr_get($island, 'id', hako_v('HcurrentID', 0));
	$name = hako_arr_get($island, 'name', hako_v('HcurrentName',''));
	$GLOBALS['HcurrentID'] = $id;
	$GLOBALS['HcurrentName'] = $name;
	$monthNames = hako_v('HmonthName', hako_v('Hmonthname', array()));
	$turn = intval(hako_v('HislandTurn', 0));
	$monthname = hako_v('Hmonth', '');
	if (is_array($monthNames) && isset($monthNames[($turn % 12) + 1])) { $monthname = $monthNames[($turn % 12) + 1]; }
	$hthis = hako_v('HthisFile','hako-main.php');
	$pass = hako_html_escape_legacy(hako_v('HdefaultPassword', hako_v('HinputPassword','')));
	$owner = hako_html_escape_legacy(hako_arr_get($island, 'ownername', ''));
	$campPass = hako_v('campPass', array());
	$ally = intval(hako_arr_get($island, 'ally', 0));
	$campPassword = (is_array($campPass) && isset($campPass[$ally])) ? $campPass[$ally] : '';
	echo "<CENTER>\n";
	echo hako_v('HtagBig_','').hako_v('HtagNumber_','').'턴'.$turn.'　('.$monthname.')'.hako_v('H_tagNumber','').hako_v('H_tagBig','').'　'.hako_v('HtagBig_','').hako_v('HtagName_','').$name.hako_v('AfterName','도').hako_v('H_tagName','').'개발 계획'.hako_v('H_tagBig','')."<BR>\n";
	echo '<FORM name="customform" action="'.$hthis.'" method="POST" target=_self><INPUT TYPE=HIDDEN NAME="customButton'.$id.'" VALUE="1"></FORM>' . "\n";
	echo '<FORM name="campform" action="'.$hthis.'" method="POST" target=_blank><INPUT TYPE=HIDDEN NAME=PASSWORD VALUE="'.$pass.'"><INPUT TYPE=HIDDEN NAME="camp'.$id.'" VALUE="1"></FORM>' . "\n";
	echo '<FORM name="bbsform" action="'.hako_v('HcampbbsPath','').'" method="POST" target=_blank><INPUT TYPE=HIDDEN NAME=PASSWORD VALUE="'.$pass.'"><INPUT TYPE=HIDDEN NAME=campPASS VALUE="'.hako_html_escape_legacy($campPassword).'"><INPUT TYPE=HIDDEN NAME=campID VALUE="'.$ally.'"></FORM>' . "\n";
	echo '<FORM name="chatform" action="'.hako_v('HcampchatPath','').'" method="POST" target=_blank><INPUT TYPE=HIDDEN NAME=mode VALUE="top"><INPUT TYPE=HIDDEN NAME=oNAME VALUE="'.$owner.'"><INPUT TYPE=HIDDEN NAME=PASSWORD VALUE="'.$pass.'"><INPUT TYPE=HIDDEN NAME=campPASS VALUE="'.hako_html_escape_legacy($campPassword).'"><INPUT TYPE=HIDDEN NAME=campID VALUE="'.$ally.'"></FORM>' . "\n";
	echo '[<A HREF="'.$hthis.'">탑에 돌아온다</A>]　' . "\n";
	echo '[<A href="'.$hthis.'?Ocean=0" target=_self>해역에</A>]　' . "\n";
	echo '[<A href="'.$hthis.'?space=0" target=_self>우주에</A>]　' . "\n\n";
	echo '[<A HREF="JavaScript:void(0);"  onClick="openCUSTOM();return false;">고유 설정 화면에</A>]　' . "\n";
	if (hako_v('Hallyflg', 0) && hako_v('HallyDisp', 0)) {
		echo '[<A HREF="JavaScript:void(0);" onClick="openCAMP();return false;">진영 화면에</A>]　';
		if (hako_v('Hcampbbs', 0)) { echo '[<A HREF="JavaScript:void(0);" onClick="openBBS();return false;">진영 게시판에</A>]　'; }
		if (hako_v('Hcampchat', 0)) { echo '[<A HREF="JavaScript:void(0);" onClick="openCHAT();return false;">진영 회의실에</A>]'; }
	}
	echo "</CENTER>\n";
	if (!(hako_arr_get($island, 'order', 0) & 8) && file_exists('exchange.php')) {
		require_once('exchange.php');
		if (function_exists('readExchange') && function_exists('infoExchange2')) { readExchange(); infoExchange2(hako_arr_get($island, 'cmdtime', 0)); }
	}
}
}

if (!function_exists('hako_owner_form_head')) {
function hako_owner_form_head($java = 0) {
	$island = hako_current_island();
	$id = hako_arr_get($island, 'id', hako_v('HcurrentID',0));
	$cmdMax = intval(hako_v('HcommandMax', 30));
	$size = intval(hako_v('HislandSize', 15));
	$pass = hako_html_escape_legacy(hako_v('HinputPassword', hako_v('HdefaultPassword','')));
	$numOptions = '';
	for ($i = 0; $i < $cmdMax; $i++) { $j = $i + 1; $numOptions .= "<OPTION VALUE=$i>$j\n"; }
	$pointOptions = hako_option_numbers($size, 1);
	$amountOptions = hako_amount_options();
	$targetList = hako_get_island_list_options($id);
	$commandOptions = hako_command_select_options(hako_v('HdefaultKind', hako_v('HcomDoNothing',0)));
	$javaHidden = $java ? '<INPUT TYPE="hidden" NAME="JAVAMODE" VALUE="java">' : '';
	echo '<FORM name="myForm" action="'.hako_v('HthisFile','hako-main.php').'" method=POST>' . "\n";
	echo $javaHidden . "\n";
	echo '<INPUT TYPE="hidden" NAME="COMARY" value="comary">' . "\n";
	echo '<B>계획 번호</B><SELECT NAME=NUMBER>'.$numOptions.'</SELECT><BR>' . "\n";
	echo '<B>개발 계획</B><SELECT NAME=COMMAND>'.$commandOptions.'</SELECT><BR>' . "\n";
	echo '<B>좌표 1(</B><SELECT NAME=POINTX>'.$pointOptions.'</SELECT>, <SELECT NAME=POINTY>'.$pointOptions.'</SELECT><B>)</B><INPUT TYPE="checkbox" NAME="xy1" CHECKED><BR>' . "\n";
	echo '<B>좌표 2(</B><SELECT NAME=POINTTX>'.$pointOptions.'</SELECT>, <SELECT NAME=POINTTY>'.$pointOptions.'</SELECT><B>)</B><INPUT TYPE="checkbox" NAME="xy2"><BR>' . "\n";
	echo '<B>수량</B><SELECT NAME=AMOUNT>'.$amountOptions.'</SELECT><BR>' . "\n";
	echo '<B>목표의 '.hako_v('AfterName','도').'</B><SELECT NAME=TARGETID>'.$targetList.'</SELECT><BR>' . "\n";
	echo '<INPUT TYPE=submit VALUE="계획 송신" NAME=Command'.($java ? 'Java' : '').'Button'.$id.'> ' . "\n";
	echo '<B>패스워드</B><INPUT TYPE=password NAME=PASSWORD VALUE="'.$pass.'"><BR>' . "\n";
}
}

if (!function_exists('hako_print_command_list')) {
function hako_print_command_list() {
	$island = hako_current_island();
	$commands = hako_arr_get($island, 'command', array());
	$max = intval(hako_v('HcommandMax', 30));
	echo "<DIV ID='commandList'>\n";
	for ($i = 0; $i < $max; $i++) {
		if (is_array($commands) && isset($commands[$i]) && is_array($commands[$i])) { tempCommand($i, $commands[$i]); }
	}
	echo "</DIV>\n";
}
}

if (!function_exists('tempOwner')) {
function tempOwner() {
	tempOwnerHeader();
	hako_owner_scripts();
	$island = hako_current_island();
	$id = hako_arr_get($island, 'id', hako_v('HcurrentID', 0));
	$mapSize = max(intval(hako_v('HislandSize', 15)), intval(hako_v('HoceanSize', 15)));
	$numOptions = '';
	for($i = 0; $i < intval(hako_v('HcommandMax', 30)); $i++) { $j = $i + 1; $numOptions .= "<OPTION VALUE=$i>$j\n"; }
	$point1X = hako_option_numbers($mapSize, hako_v('HdefaultX', 0));
	$point1Y = hako_option_numbers($mapSize, hako_v('HdefaultY', 0));
	$point2X = hako_option_numbers($mapSize, hako_v('HdefaultTX', 0));
	$point2Y = hako_option_numbers($mapSize, hako_v('HdefaultTY', 0));
	$amountOptions = hako_amount_options(hako_v('HcommandArg', 0));
	$targetList = hako_get_island_list_options(hako_v('defaultTarget', $id));
	$commandOptions = hako_command_select_options(hako_v('HdefaultKind', hako_v('HcomDoNothing',0)));
	$pass = hako_html_escape_legacy(hako_v('HinputPassword', hako_v('HdefaultPassword','')));
	$afterName = hako_v('AfterName','도');
	$hthis = hako_v('HthisFile','hako-main.php');
	islandInfo();
	echo <<<END
<CENTER>
<TABLE BORDER>
<TR>
<TD class=InputCell>
<CENTER>
<FORM name="myForm" action="$hthis" method=POST>
<B>패스워드</B></BR>
<INPUT TYPE=password NAME=PASSWORD VALUE="$pass">
<HR>
<INPUT TYPE=submit VALUE="계획 송신" NAME=CommandButton$id>
<HR>
<B>계획 번호</B><SELECT NAME=NUMBER>
$numOptions</SELECT><BR>
<HR>
<B>개발 계획</B><BR>
<SELECT NAME=COMMAND onChange="StatusMsg(this.options[this.selectedIndex].value)" onClick="StatusMsg(this.options[this.selectedIndex].value)">
$commandOptions</SELECT>
<HR><B>좌표１(</B><SELECT NAME=POINTX>$point1X</SELECT>, <SELECT NAME=POINTY>$point1Y</SELECT><B>)</B><INPUT TYPE="checkbox" NAME="xy1" CHECKED><br>
<B>좌표２(</B><SELECT NAME=POINTTX>$point2X</SELECT>, <SELECT NAME=POINTTY>$point2Y</SELECT><B>)</B><INPUT TYPE="checkbox" NAME="xy2">
<HR><B>수량</B><SELECT NAME=AMOUNT>$amountOptions</SELECT>
<HR><B>목표의 $afterName</B>:
<B><A HREF=JavaScript:void(0); onClick="return jump(myForm, 'cgi')">표시</A></B><BR>
<SELECT NAME=TARGETID>$targetList<BR></SELECT>
<HR><B>동작</B><BR>
<INPUT TYPE=radio NAME=COMMANDMODE VALUE=insert CHECKED>삽입
<INPUT TYPE=radio NAME=COMMANDMODE VALUE=write>덧쓰기<BR>
<INPUT TYPE=radio NAME=COMMANDMODE VALUE=delete>삭제<HR>
<INPUT TYPE=submit VALUE="계획 송신" NAME=CommandButton$id>
</CENTER></FORM></TD>
<TD class=MapCell>
END;
	hako_reset_map_count();
	islandMap(1, $id);
	echo "</TD>\n<TD class=CommandCell>\n";
	hako_print_command_list();
	echo "</TD></TR></TABLE></CENTER>\n";
}
}

if (!function_exists('hako_tempOwnerJavaStrict')) {
function hako_tempOwnerJavaStrict() {
	tempOwnerHeader();
	hako_owner_scripts();
	$island = hako_current_island();
	$id = hako_arr_get($island, 'id', hako_v('HcurrentID',0));
	$cmdMax = intval(hako_v('HcommandMax', 30));
	$size = max(intval(hako_v('HislandSize', 15)), intval(hako_v('HoceanSize', 15)));
	list($click1, $click2) = hako_java_command_menu();
	$click3 = hako_java_presentation_menu();
	$numOptions = '';
	for($i = 0; $i < $cmdMax; $i++){ $j = $i + 1; $numOptions .= "<OPTION VALUE=$i>$j\n"; }
	$point1X = hako_option_numbers($size, hako_v('HdefaultX', 0));
	$point1Y = hako_option_numbers($size, hako_v('HdefaultY', 0));
	$point2X = hako_option_numbers($size, hako_v('HdefaultTX', 0));
	$point2Y = hako_option_numbers($size, hako_v('HdefaultTY', 0));
	$amountOptions = hako_amount_options(hako_v('HcommandArg', 0));
	$targetList = hako_get_island_list_options(hako_v('defaultTarget', $id));
	$catList = hako_java_command_categories();
	$commandOptions = hako_command_select_options(hako_v('HdefaultKind', hako_v('HcomDoNothing',0)));
	$autoOptions = hako_auto_command_options(hako_v('HdefaultKind', hako_v('HcomDoNothing',0)));
	$initialPlanHtml = hako_js_initial_plan_html();
	$pass = hako_html_escape_legacy(hako_v('HinputPassword', hako_v('HdefaultPassword','')));
	$hthis = hako_v('HthisFile','hako-main.php');
	$afterName = hako_v('AfterName','도');
	$javaMode = hako_v('HjavaMode','java');
	$myislandID = hako_v('defaultTarget', $id);
	$open = (hako_v('HmenuOpen','') == 'on') ? 'CHECKED' : '';
	islandInfo();
	echo <<<END
<span id="menu" style="position:absolute; top:-500px;left:-500px;">
<table border=0 class="PopupCell"><tr><td nowrap>
$click1
<td nowrap>
$click2
<tr><td nowrap colspan=2>
<a href="Javascript:void(0);" onClick="menuclose();return false;" class='M'>메뉴를 닫는다</A>
</td></tr></table></span>
<span id="menu2" style="position:absolute; top:-500px;left:-500px;">
<table border=0 class="PopupCell"><tr><td nowrap>
$click3
<hr>
<a href="Javascript:void(0);" onClick="menuclose();return false;" class='M'>메뉴를 닫는다</A>
</td></tr></table></span>
<CENTER>
<TABLE BORDER>
<TR valign=top>
<TD class=InputCell width=25%>
<CENTER>
<FORM name="myForm" action="$hthis" method=POST onsubmit="return send_command(this);">
<BR>
<P>
<B>계획 번호</B><SELECT NAME=NUMBER onchange="selCommand(this.selectedIndex)">
$numOptions</SELECT><BR>
<HR>
<B>개발 계획</B>
<INPUT TYPE="checkbox" NAME="MENUOPEN" $open>비표시
<INPUT TYPE="checkbox" NAME="MENUOPEN2" $open>프리젠테이션<br>
<SELECT NAME=menu onchange="SelectList(myForm)">
$catList</SELECT><br>
<SELECT NAME=COMMAND onChange="StatusMsg(this.options[this.selectedIndex].value)" onClick="StatusMsg(this.options[this.selectedIndex].value)">
$commandOptions
</SELECT>
<HR>
<B>커멘드 입력</B><BR><B>
<A HREF=JavaScript:void(0); onClick="cominput(myForm,1)">삽입</A>
　<A HREF=JavaScript:void(0); onClick="cominput(myForm,2)">덧쓰기</A>
　<A HREF=JavaScript:void(0); onClick="cominput(myForm,3)">삭제</A>
</B><HR>
<B>좌표 1(</B><SELECT NAME=POINTX>$point1X</SELECT>, <SELECT NAME=POINTY>$point1Y</SELECT><B>)</B><INPUT TYPE="checkbox" NAME="xy1" CHECKED><br>
<B>좌표 2(</B><SELECT NAME=POINTTX>$point2X</SELECT>, <SELECT NAME=POINTTY>$point2Y</SELECT><B>)</B><INPUT TYPE="checkbox" NAME="xy2"><HR>
<B>수량</B><SELECT NAME=AMOUNT>$amountOptions</SELECT>
<HR>
<B>목표의 $afterName</B>
[<B><A HREF=JavaScript:void(0); onClick="return jump(myForm, '$javaMode')"> 표시</A></B>
][<B><A HREF=JavaScript:void(0); onClick="return myisland(myForm,'$myislandID')">자신 선택</A></B>]
<br>[<B><A HREF=JavaScript:void(0); onClick="return jumps('$javaMode','999')"> 우주 </A></B>
][<B><A HREF=JavaScript:void(0); onClick="return jumps('$javaMode','888')"> 해역 </A></B>
][<B><A HREF=JavaScript:void(0); onClick="return jumpu(myForm, '$javaMode')"> 지하 </A></B>]
<BR>
<SELECT NAME=TARGETID>
$targetList<BR>
</SELECT>
<HR>
<B>커멘드 이동</B>:
<BIG>
<A HREF=JavaScript:void(0); onClick="cominput(myForm,4)" STYLE="text-decoration:none"> ▲ </A>I
<A HREF=JavaScript:void(0); onClick="cominput(myForm,5)" STYLE="text-decoration:none"> ▼ </A>
</BIG>
<HR>
<INPUT TYPE="hidden" NAME="COMARY" value="comary">
<INPUT TYPE="hidden" NAME="JAVAMODE" value="$javaMode">
<INPUT TYPE=submit VALUE="계획 송신" NAME=CommandJavaButton$id>
<span id="progress"></span>
<br><font size=2>마지막에<font color=red>계획 송신 버튼</font>을<br>누르세요.</font>
<HR>
<B>패스워드</B></BR>
<INPUT TYPE=password NAME=PASSWORD VALUE="$pass">
<HR>
</CENTER>
<table border=1 width="100%"><tr><td align=center>키 입력 간이 설명(NN4 불가)</td><tr></table>
<table border=1 width="100%">
<tr><td>숫자=수량</td><td>BS=1개 이전삭제</td></tr>
<tr><td>DEL=삭제</td><td>Z=땅 고르기</td></tr>
<tr><td>S=식림</td><td>U=매립</td></tr>
<tr><td>K=굴착</td><td>N=농장 정비</td></tr>
<tr><td>B=미사일 기지</td><td>D=방위 시설</td></tr>
<tr><td>M=PP미사일 발사</td><td>Y=괴수 유도 미사일</td></tr>
</table>
</TD>
<TD class=MapCell><center>
<TEXTAREA NAME="COMSTATUS" cols="48" rows="2"></TEXTAREA>
</center>
END;
	hako_reset_map_count();
	islandMap(1, $id);
	echo <<<END
</FORM>
</TD>
<TD class=CommandCell id="plan" onmouseout="return false;">
<FORM name="allForm" action="$hthis" method=POST>
<INPUT TYPE="hidden" NAME=PASSWORD VALUE="$pass">
<INPUT TYPE="hidden" NAME=NUMBER VALUE="0">
<INPUT TYPE="hidden" NAME=POINTY VALUE="0">
<INPUT TYPE="hidden" NAME=POINTX VALUE="0">
<INPUT TYPE="hidden" NAME=POINTTY VALUE="0">
<INPUT TYPE="hidden" NAME=POINTTX VALUE="0">
<INPUT TYPE="hidden" NAME=AMOUNT VALUE="1">
<INPUT TYPE="hidden" NAME=TARGETID VALUE="$id">
<INPUT TYPE="hidden" NAME=COMMANDMODE VALUE="insert">
<br><INPUT TYPE="hidden" NAME=JAVAMODE value="$javaMode">
<DIV ID='AutoCommand'><B>자동 계획</B><br>
<SELECT NAME=COMMAND>
$autoOptions</SELECT><br>
<INPUT TYPE="hidden" NAME="CommandButton$id">
<INPUT TYPE="button" onClick="SelectPOINT()" VALUE="자동계획 송신"></DIV><HR>
<ilayer name="PARENT_LINKMSG" width="100%" height="100%">
   <layer name="LINKMSG1" width="200"></layer>
   <span id="LINKMSG1">$initialPlanHtml</span>
</ilayer>
<BR>
</FORM>
</TD></TR></TABLE></CENTER>
<script>
hakoInitFormAliases();
SelectList(hakoOwnerForm());
init();
</script>
END;
}
}

if (!function_exists('hako_command_fill_defaults')) {
function hako_command_fill_defaults(&$commands) {
	$max = intval(hako_v('HcommandMax', 30));
	$doNothing = intval(hako_v('HcomDoNothing', 97));
	if (!is_array($commands)) { $commands = array(); }
	for ($i = 0; $i < $max; $i++) {
		if (!isset($commands[$i]) || !is_array($commands[$i])) {
			$commands[$i] = array('kind'=>$doNothing,'target'=>0,'x'=>0,'y'=>0,'arg'=>0,'tx'=>0,'ty'=>0,'flg'=>0);
		}
	}
	if (count($commands) > $max) { $commands = array_slice($commands, 0, $max); }
}
}

if (!function_exists('hako_command_row')) {
function hako_command_row($kind, $target, $x, $y, $arg, $tx = 0, $ty = 0, $flg = 0) {
	return array('kind'=>intval($kind), 'target'=>intval($target), 'x'=>intval($x), 'y'=>intval($y), 'arg'=>intval($arg), 'tx'=>intval($tx), 'ty'=>intval($ty), 'flg'=>intval($flg));
}
}

if (!function_exists('hako_command_delete_at')) {
function hako_command_delete_at(&$commands, $number) {
	hako_command_fill_defaults($commands);
	$number = intval($number);
	if ($number < 0) { $number = 0; }
	$max = intval(hako_v('HcommandMax', 30));
	if ($number >= $max) { $number = $max - 1; }
	array_splice($commands, $number, 1);
	$commands[] = hako_command_row(hako_v('HcomDoNothing',97), 0, 0, 0, 0, 0, 0, 0);
	hako_command_fill_defaults($commands);
}
}

if (!function_exists('hako_command_insert_at')) {
function hako_command_insert_at(&$commands, $number, $row = null) {
	hako_command_fill_defaults($commands);
	$number = intval($number);
	if ($number < 0) { $number = 0; }
	$max = intval(hako_v('HcommandMax', 30));
	if ($number >= $max) { $number = $max - 1; }
	if ($row === null) { $row = $commands[$number]; }
	array_splice($commands, $number, 0, array($row));
	$commands = array_slice($commands, 0, $max);
}
}

if (!function_exists('hako_command_main_impl')) {
function hako_command_main_impl() {
	if (!hako_set_current_island_by_id(hako_v('HcurrentID', 0))) { if (function_exists('tempWrongPassword')) { tempWrongPassword(); } return; }
	if (!hako_check_current_password()) { if (function_exists('tempWrongPassword')) { tempWrongPassword(); } return; }
	$n = intval(hako_v('HcurrentNumber', 0));
	if (!isset($GLOBALS['Hislands'][$n]['command'])) { $GLOBALS['Hislands'][$n]['command'] = array(); }
	$commands =& $GLOBALS['Hislands'][$n]['command'];
	hako_command_fill_defaults($commands);
	$plan = intval(hako_v('HcommandPlanNumber', 0));
	$kind = intval(hako_v('HcommandKind', hako_v('HcomDoNothing', 97)));
	$target = intval(hako_v('HcommandTarget', hako_v('HcurrentID', 0)));
	$x = intval(hako_v('HcommandX', 0));
	$y = intval(hako_v('HcommandY', 0));
	$arg = intval(hako_v('HcommandArg', 0));
	$tx = intval(hako_v('HcommandTX', 0));
	$ty = intval(hako_v('HcommandTY', 0));
	$mode = hako_v('HcommandMode', 'insert');
	$tempCommandFlag = 1;
	if ($mode == 'delete') {
		hako_command_delete_at($commands, $plan);
		$tempCommandFlag = 0;
	} elseif ($kind == intval(hako_v('HcomAutoDelete', -1))) {
		for ($i = 0; $i < intval(hako_v('HcommandMax', 30)); $i++) { hako_command_delete_at($commands, 0); }
		$tempCommandFlag = 0;
	} elseif (($kind == intval(hako_v('HcomAutoPrepare', -1))) || ($kind == intval(hako_v('HcomAutoPrepare2', -1))) || ($kind == intval(hako_v('HcomAutoSellTree', -1)))) {
		$autoKind = intval(hako_v('HcomPrepare', 1));
		if ($kind == intval(hako_v('HcomAutoPrepare2', -1))) { $autoKind = intval(hako_v('HcomPrepare2', 2)); }
		elseif ($kind == intval(hako_v('HcomAutoSellTree', -1))) { $autoKind = intval(hako_v('HcomSellTree', 6)); }
		if (function_exists('makeRandomPointArray')) { makeRandomPointArray(); }
		$island = hako_current_island();
		$land = hako_arr_get($island, 'land', array());
		$landValue = hako_arr_get($island, 'landValue', array());
		$pointNumber = intval(hako_v('HpointNumber', intval(hako_v('HislandSize',15))*intval(hako_v('HislandSize',15))));
		$inserted = 0;
		$limit = intval(hako_v('HcommandMax', 30));
		$Arg = ($arg == 0) ? 1 : $arg;
		for ($j = 0; ($j < $pointNumber) && ($inserted < $limit); $j++) {
			$rx = isset($GLOBALS['Hrpx'][$j]) ? $GLOBALS['Hrpx'][$j] : ($j % intval(hako_v('HislandSize',15)));
			$ry = isset($GLOBALS['Hrpy'][$j]) ? $GLOBALS['Hrpy'][$j] : intval($j / intval(hako_v('HislandSize',15)));
			$landKind = hako_grid_get($land, $rx, $ry, 0);
			$lv = hako_grid_get($landValue, $rx, $ry, 0);
			if (($landKind == intval(hako_v('HlandMonster', -1))) && function_exists('monsterSpec')) {
				$ms = monsterSpec($lv);
				if (isset($ms[0]) && $ms[0] == 26) { $landKind = intval(hako_v('HlandWaste', -2)); $lv = 0; }
			}
			$ok = 0;
			if (($autoKind == intval(hako_v('HcomSellTree', 6))) && ($landKind == intval(hako_v('HlandForest', -1))) && ($lv <= $Arg)) { $ok = 1; }
			if ((($autoKind == intval(hako_v('HcomPrepare', 1))) || ($autoKind == intval(hako_v('HcomPrepare2', 2)))) && ($landKind == intval(hako_v('HlandWaste', -1))) && ($lv <= 1)) { $ok = 1; }
			if ($ok) { hako_command_insert_at($commands, $plan, hako_command_row($autoKind, 0, $rx, $ry, 0, 0, 0, 0)); $inserted++; }
		}
		$tempCommandFlag = 1;
	} else {
		$row = hako_command_row($kind, $target, $x, $y, $arg, $tx, $ty, 0);
		if ($mode == 'insert') { hako_command_insert_at($commands, $plan, $row); }
		else { $commands[$plan] = $row; }
		$tempCommandFlag = 1;
	}
	$GLOBALS['Hislands'][$n]['cmdTurn'] = hako_v('HislandTurn', 0);
	$GLOBALS['Hislands'][$n]['cmdIp'] = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '';
	$GLOBALS['Hislands'][$n]['cmdId'] = hako_v('defaultID', hako_v('HcurrentID', 0));
	$GLOBALS['Hislands'][$n]['cmdtime'] = time();
	if(!writeIslandsFile(hako_v('HcurrentID', 0), 2)) { unlock(); if (function_exists('tempFailWrite')) { tempFailWrite(); } return; }
	if ($tempCommandFlag) { tempCommandAdd(); } else { tempCommandDelete(); }
	ownerMain();
}
}

if (!function_exists('hako_command_java_main_impl')) {
function hako_command_java_main_impl() {
	if (!hako_set_current_island_by_id(hako_v('HcurrentID', 0))) { if (function_exists('tempWrongPassword')) { tempWrongPassword(); } return; }
	if (!hako_check_current_password()) { if (function_exists('tempWrongPassword')) { tempWrongPassword(); } return; }
	$n = intval(hako_v('HcurrentNumber', 0));
	if (!isset($GLOBALS['Hislands'][$n]['command'])) { $GLOBALS['Hislands'][$n]['command'] = array(); }
	$commands =& $GLOBALS['Hislands'][$n]['command'];
	$max = intval(hako_v('HcommandMax', 30));
	$comary = hako_v('HcommandComary', '');
	preg_match_all('/(-?\d+)\s+(-?\d+)\s+(-?\d+)\s+(-?\d+)\s+(-?\d+)\s+(-?\d+)\s+(-?\d+)\s*/', $comary, $matches, PREG_SET_ORDER);
	$doNothing = intval(hako_v('HcomDoNothing', 97));
	for ($i = 0; $i < $max; $i++) {
		if (isset($matches[$i])) {
			$m = $matches[$i];
			$ckind = intval($m[1]);
			if ($ckind == 0) { $ckind = $doNothing; }
			$commands[$i] = hako_command_row($ckind, intval($m[5]), intval($m[2]), intval($m[3]), intval($m[4]), intval($m[6]), intval($m[7]), 0);
		} else {
			$commands[$i] = hako_command_row($doNothing, 0, 0, 0, 0, 0, 0, 0);
		}
	}
	hako_command_fill_defaults($commands);
	$GLOBALS['Hislands'][$n]['cmdTurn'] = hako_v('HislandTurn', 0);
	$GLOBALS['Hislands'][$n]['cmdIp'] = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '';
	$GLOBALS['Hislands'][$n]['cmdId'] = hako_v('defaultID', hako_v('HcurrentID', 0));
	$GLOBALS['Hislands'][$n]['cmdtime'] = time();
	if(!writeIslandsFile(hako_v('HcurrentID', 0), 2)) { unlock(); if (function_exists('tempFailWrite')) { tempFailWrite(); } return; }
	if (hako_v('Hasync', 0)) { unlock(); echo 'OK'; }
	else { tempCommandAdd(); ownerMain(); }
}
}

if (!function_exists('tempCommandDelete')) {
function tempCommandDelete() { echo hako_v('HtagBig_','').'커멘드를 삭제했습니다'.hako_v('H_tagBig','').'<HR>' . "\n"; }
}
if (!function_exists('tempCommandAdd')) {
function tempCommandAdd() { echo hako_v('HtagBig_','').'커멘드를 등록했습니다'.hako_v('H_tagBig','').'<HR>' . "\n"; }
}
if (!function_exists('tempComment')) {
function tempComment() { echo hako_v('HtagBig_','').'코멘트를 갱신했습니다'.hako_v('H_tagBig','').'<HR>' . "\n"; }
}

if (!function_exists('hako_set_current_island_by_id')) {
function hako_set_current_island_by_id($id) {
	$n = hako_safe_id_number($id);
	if ($n === '') { return false; }
	$GLOBALS['HcurrentNumber'] = $n;
	$GLOBALS['HcurrentID'] = $id;
	$island = hako_island_by_number($n);
	$GLOBALS['HcurrentName'] = hako_arr_get($island, 'name', '');
	return true;
}
}

if (!function_exists('hako_check_current_password')) {
function hako_check_current_password() {
	$island = hako_current_island();
	if (!function_exists('checkPassword')) { return true; }
	$pass = hako_v('HinputPassword','');
	if ($pass === '' || $pass === null) { $pass = hako_v('HdefaultPassword',''); }
	return checkPassword(hako_arr_get($island, 'password', ''), $pass) ? true : false;
}
}

if (!function_exists('printIslandMain')) {
function printIslandMain() {
	unlock();
	if (!hako_set_current_island_by_id(hako_v('HcurrentID', 0))) { if (function_exists('tempProblem')) { tempProblem(); } return; }
	$GLOBALS['HmainMode'] = 'print';
	$island = hako_current_island();
	$cur2 = hako_safe_id_number(hako_v('HprintID', 0));
	$GLOBALS['HprintAlly'] = 0;
	if ($cur2 === '') { $GLOBALS['HprintID'] = 0; }
	else {
		$is2 = hako_island_by_number($cur2);
		if (function_exists('checkPassword') && !checkPassword(hako_arr_get($is2, 'password', ''), hako_v('HinputPassword',''))) { $GLOBALS['HprintID'] = 0; }
		else { $GLOBALS['HprintAlly'] = hako_arr_get($is2, 'ally', 0); }
	}
	if (hako_arr_get($island, 'id', 0) > 90) { $GLOBALS['HmainMode'] = 'bfield'; tempPrintIslandHead('(Battle Field)'); tempNavi(); }
	else { tempPrintIslandHead(); tempNavi(); }
	islandInfo();
	hako_reset_map_count();
	islandMap(0, hako_v('HprintID', 0));
	if (function_exists('ugMap')) { ugMap($island, 0); }
	if (function_exists('islandJamp')) { islandJamp(); }
	if (function_exists('islandmonster')) { islandmonster(2); }
	tempLocalbbs(0);
	tempRecent(0);
	tempMapTotal();
}
}

if (!function_exists('ownerMain')) {
function ownerMain() {
	unlock();
	$GLOBALS['HmainMode'] = 'owner';
	if (hako_v('HcurrentID', 0) < 1) { if (function_exists('tempWrongPassword')) { tempWrongPassword(); } return; }
	if (!hako_set_current_island_by_id(hako_v('HcurrentID', 0))) { if (function_exists('tempWrongPassword')) { tempWrongPassword(); } return; }
	if (!hako_check_current_password()) { if (function_exists('tempWrongPassword')) { tempWrongPassword(); } return; }
	if (hako_v('HjavaMode','') == 'java') { hako_tempOwnerJavaStrict(); }
	else { tempOwner(); }
	$island = hako_current_island();
	$order = hako_arr_get($island, 'order', 0);
	if (($order & 256)) { tempCLbbs(); }
	else {
		if (function_exists('ugMap')) { ugMap($island, 2); }
		if (($order & 64)) { tempLocalbbs(1); tempRecent(1); }
		else { tempRecent(1); tempLocalbbs(1); }
		tempCommentInput();
		tempMapTotal();
	}
}
}

if (!function_exists('commandMain')) { function commandMain(){ hako_command_main_impl(); } }
if (!function_exists('commentMain')) {
function commentMain(){
	if (!hako_set_current_island_by_id(hako_v('HcurrentID', 0))) { if (function_exists('tempWrongPassword')) { tempWrongPassword(); } return; }
	if (!hako_check_current_password()) { if (function_exists('tempWrongPassword')) { tempWrongPassword(); } return; }
	$n = intval(hako_v('HcurrentNumber', 0));
	$GLOBALS['Hislands'][$n]['comment'] = hako_html_escape_legacy(hako_v('Hmessage',''));
	$GLOBALS['Hislands'][$n]['commentLabel0'] = hako_v('HcommentLabel0','');
	$GLOBALS['Hislands'][$n]['commentLabel1'] = hako_v('HcommentLabel1','');
	$GLOBALS['Hislands'][$n]['commentLabel2'] = hako_v('HcommentLabel2','');
	$GLOBALS['Hislands'][$n]['commentLabel3'] = hako_v('HcommentLabel3','');
	$GLOBALS['Hislands'][$n]['commentLabel4'] = hako_v('HcommentLabel4','');
	if(!writeIslandsFile(hako_v('HcurrentID', 0), 1)) { unlock(); if (function_exists('tempFailWrite')) { tempFailWrite(); } return; }
	tempComment();
	ownerMain();
}
}
if (!function_exists('monsMain')) { function monsMain(){ ownerMain(); } }

if (!function_exists('localBbsMain')) {
function localBbsMain() {
	global $Hislands, $Hspace, $Hocean, $HcurrentID, $HcurrentNumber, $HlbbsMode, $HlbbsName, $HlbbsMessage, $HlbbsType, $HinputPassword, $HcommandPlanNumber, $HforeignerID,
	       $HislandTurn, $HlbbsMax, $AfterName;
	$wmode = 2;
	$targetId = intval($HcurrentID);
	if($targetId == 999) { $island =& $Hspace; $wmode = 3; }
	elseif($targetId == 888) { $island =& $Hocean; $wmode = 4; }
	else {
		if (!hako_set_current_island_by_id($targetId)) { unlock(); if(function_exists('tempProblem')) { tempProblem(); } return; }
		$island =& $Hislands[$HcurrentNumber];
	}
	if(!isset($island['lbbs']) || !is_array($island['lbbs'])) { $island['lbbs'] = array(); }
	$lbbs =& $island['lbbs'];
	for($i = 0; $i < intval($HlbbsMax); $i++) { if(!isset($lbbs[$i])) { $lbbs[$i] = '0<<0>>'; } }
	if(($HlbbsMode == 0 || $HlbbsMode == 1 || $HlbbsMode == 3) && ($HlbbsName === '' || $HlbbsMessage === '')) {
		unlock(); tempLbbsNoMessage(); return;
	}
	$speaker = '0<';
	$foreignName = '';
	if($HlbbsMode != 0) {
		if($HlbbsMode == 3 || $HlbbsMode == 4) {
			$foreignId = intval($HforeignerID);
			if(!hako_set_current_island_by_id($foreignId)) { unlock(); if(function_exists('tempProblem')) { tempProblem(); } return; }
			$foreignIsland = $Hislands[$GLOBALS['HcurrentNumber']];
			if($HlbbsType == 'ANON') { $foreignName = '익명'; }
			else {
				$passCheck = checkPasslocalbbs($foreignIsland['password'], $HinputPassword);
				if($passCheck == 0) { unlock(); tempWrongPassword(); return; }
				elseif($passCheck == 3) { $foreignName = '관리자'; }
				elseif($passCheck == 2) { $foreignName = 'GUEST'; }
			}
			if($HlbbsType != 'ANON') {
				if($foreignName === '') { $speaker = $foreignIsland['name'] . $AfterName . hako_v('addr','') . ',' . $foreignId; }
				else { $speaker = $foreignName . hako_v('addr',''); }
			} else { $speaker = isset($_SERVER['REMOTE_HOST']) && $_SERVER['REMOTE_HOST'] ? $_SERVER['REMOTE_HOST'] : (isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : ''); }
			$speaker = ($HlbbsType != 'SECRET') ? ('0<' . $speaker) : ('1<' . $speaker);
		} else {
			$passCheck = checkPassword($island['password'], $HinputPassword);
			if(!$passCheck) { unlock(); tempWrongPassword(); return; }
			$speaker = '0<' . hako_v('addr','');
		}
	}
	if($HlbbsMode == 2) {
		hako_slide_back_lbbs_message($lbbs, intval($HcommandPlanNumber));
	} elseif($HlbbsMode == 4) {
		$idx = intval($HcommandPlanNumber);
		$line = isset($lbbs[$idx]) ? $lbbs[$idx] : '';
		if(preg_match('/([0-9]*)\<(.*)\<([0-9]*)\>(.*)\>(.*)$/', $line, $m)) {
			$parts = explode(',', $m[2]);
			$sID = isset($parts[1]) ? intval($parts[1]) : 0;
			if((($sID != 0) && ($sID == intval($HforeignerID))) || ($foreignName == '관리자')) { hako_slide_back_lbbs_message($lbbs, $idx); }
			else { unlock(); tempWrongPassword(); return; }
		}
	} else {
		hako_slide_lbbs_message($lbbs);
		$messageFlag = ($HlbbsMode == 1) ? '1' : '0';
		$name = $HislandTurn . ' : ' . htmlEscape($HlbbsName);
		$msg = htmlEscape($HlbbsMessage);
		$lbbs[0] = $speaker . '<' . $messageFlag . '>' . $name . '>' . $msg;
	}
	if(!writeIslandsFile($targetId, $wmode)) { unlock(); tempFailWrite(); return; }
	if($HlbbsMode == 2 || $HlbbsMode == 4) { tempLbbsDelete(); } else { tempLbbsAdd(); }
	if($wmode == 3) { echo hako_v('HtagBig_','').'<A href="'.hako_v('HthisFile','hako-main.php').'?space=0">자동으로 우주 맵에 납니다···조금 기다려 주세요.</A>'.hako_v('H_tagBig',''); return; }
	if($wmode == 4) { echo hako_v('HtagBig_','').'<A href="'.hako_v('HthisFile','hako-main.php').'?Ocean=0">자동으로 해역 맵에 납니다···조금 기다려 주세요.</A>'.hako_v('H_tagBig',''); return; }
	if($HlbbsMode == 1 || $HlbbsMode == 2) { ownerMain(); } else { printIslandMain(); }
}
}

if (!function_exists('hako_slide_lbbs_message')) {
function hako_slide_lbbs_message(&$lbbs) {
	$max = intval(hako_v('HlbbsMax', 10));
	if($max <= 0) { $max = 10; }
	for($i = $max - 1; $i > 0; $i--) { $lbbs[$i] = isset($lbbs[$i-1]) ? $lbbs[$i-1] : '0<<0>>'; }
}
}

if (!function_exists('hako_slide_back_lbbs_message')) {
function hako_slide_back_lbbs_message(&$lbbs, $number) {
	$max = intval(hako_v('HlbbsMax', 10));
	if($max <= 0) { $max = 10; }
	$number = intval($number);
	if($number < 0) { $number = 0; }
	for($i = $number; $i < $max - 1; $i++) { $lbbs[$i] = isset($lbbs[$i+1]) ? $lbbs[$i+1] : '0<<0>>'; }
	$lbbs[$max - 1] = '0<<0>>';
}
}

if (!function_exists('tempCLbbs')) {
function tempCLbbs() {
	echo "<HR><FORM action=\"".hako_v('HthisFile','hako-main.php')."\" method=POST>\n";
	echo "<CENTER><INPUT TYPE=submit VALUE=\"코멘트·관광자 통신·근황·괴수 배틀·지하 표시\" NAME=CLBBSButton".hako_v('HcurrentID',0)."><INPUT TYPE=hidden NAME=PASSWORD VALUE=\"".hako_html_escape_legacy(hako_v('HinputPassword',hako_v('HdefaultPassword','')))."\"><INPUT TYPE=hidden NAME=JAVAMODE VALUE=\"".hako_html_escape_legacy(hako_v('HjavaMode',''))."\"></CENTER>\n";
	echo "</FORM>\n";
}
}

if (!function_exists('clbbsMain')) {
function clbbsMain() {
	unlock();
	$GLOBALS['HmainMode'] = 'owner';
	if (!hako_set_current_island_by_id(hako_v('HcurrentID', 0))) { if (function_exists('tempWrongPassword')) { tempWrongPassword(); } return; }
	if (!hako_check_current_password()) { if (function_exists('tempWrongPassword')) { tempWrongPassword(); } return; }
	tempOwnerHeader();
	hako_owner_scripts();
	$island = hako_current_island();
	if (function_exists('ugMap')) { ugMap($island, 2); }
	tempRecent(1);
	tempLocalbbs(1);
	tempCommentInput();
	tempMapTotal();
}
}

if (!function_exists('customMain')) {
function customMain($mode = 0) {
	if (!hako_set_current_island_by_id(hako_v('HcurrentID', 0))) { if (function_exists('tempProblem')) { tempProblem(); } return; }
	$island =& $GLOBALS['Hislands'][$GLOBALS['HcurrentNumber']];
	$GLOBALS['HcurrentName'] = hako_arr_get($island, 'name', hako_v('HcurrentName',''));
	$monthNames = hako_v('HmonthName', hako_v('Hmonthname', array()));
	$turn = intval(hako_v('HislandTurn', 0));
	$monthname = hako_v('Hmonth', '');
	if (is_array($monthNames) && isset($monthNames[($turn % 12) + 1])) { $monthname = $monthNames[($turn % 12) + 1]; }
	if($mode){
		for($i = 0; $i < 12; $i++) {
			$bit = pow(2, $i);
			if(isset($GLOBALS['Hcustom'][$i]) && $GLOBALS['Hcustom'][$i]){ $island['order'] |= $bit; }
			else { if($island['order'] & $bit) { $island['order'] ^= $bit; } }
		}
		if(!writeIslandsFile(hako_v('HcurrentID', 0), 1)) {
			unlock();
			if (function_exists('tempFailWrite')) { tempFailWrite(); }
			return;
		}
		echo hako_v('HtagBig_','').'데이터를 갱신했습니다'.hako_v('H_tagBig','').'<HR>';
	}
	$ccbx = array();
	for($i = 0; $i < 12; $i++) { $ccbx[$i] = (hako_arr_get($island, 'order', 0) & pow(2, $i)) ? ' CHECKED' : ''; }
	$id = hako_arr_get($island, 'id', hako_v('HcurrentID',0));
	$hthis = hako_v('HthisFile','hako-main.php');
	$after = hako_v('AfterName','도');
	$name = hako_html_escape_legacy(hako_v('HcurrentName',''));
	echo <<<END
<CENTER>
END;
	echo hako_v('HtagBig_','').hako_v('HtagNumber_','').'턴'.$turn.'　('.$monthname.')'.hako_v('H_tagNumber','').hako_v('H_tagBig','').'　'.hako_v('HtagBig_','').hako_v('HtagName_','').$name.$after.hako_v('H_tagName','').hako_v('H_tagBig','')."<BR>\n";
	echo hako_v('HtempBack','')."<br>\n";
	echo <<<END
<h1>각{$after}마다의 고유 설정</h1>
<FORM name="customMain" action="$hthis" method="POST">
<table>
<INPUT TYPE="checkbox" NAME="custom4"{$ccbx[4]}>자동 괴수 유도탄 발사(괴수가 있으면 강제적으로 괴수 유도탄 발사)<br>
<INPUT TYPE="checkbox" NAME="custom5"{$ccbx[5]}>채굴장은 자금을 생산한다. (체크를 떼면 광석을 생산)<br>
<INPUT TYPE="checkbox" NAME="custom7"{$ccbx[7]}>공장은 자금을 생산한다. (체크를 떼면 병기를 생산)<br>
<INPUT TYPE="checkbox" NAME="custom11"{$ccbx[11]}>유전은 자금을 생산한다. (체크를 떼면 원유를 생산)<br>
<INPUT TYPE="checkbox" NAME="custom3"{$ccbx[3]}>갱신된 거래 정보를 표시하지 않는다.<br>
<INPUT TYPE="checkbox" NAME="custom8"{$ccbx[8]}>개발 모드로 관광자 통신·최근의 로그 등을 별도 화면화<br>
<INPUT TYPE="checkbox" NAME="custom6"{$ccbx[6]}>개발 모드로 관광자 통신→근황의 차례로 한다.<br>
<INPUT TYPE="checkbox" NAME="custom9"{$ccbx[9]}>기후 이상으로 중지된 명령을 남긴다(최대 10회까지)<br>
<INPUT TYPE="checkbox" NAME="custom10"{$ccbx[10]}>소방서 화재 자동 복구 기능을 사용한다<br>
</table>
<INPUT TYPE=submit value="갱신" NAME=customMButton$id>
</FORM>
</CENTER>
<h2>자동 괴수 유도탄 발사</h2>
턴 개시시에 어떤 괴수이더라도 자신의 도에 1마리 이상의 괴수가 있으면,<br>
명령의 01에 강제적으로 괴수 유도탄 발사가 삽입되고 실행됩니다.<br>
괴수 유도탄 발사가 자동 발사되었을 경우, 본래의 01의 명령은 실행되지 않습니다. (내정이라면 실행됩니다)<br>
어떠한 원인으로 이미 괴수가 없는 경우는 중지의 로그가 흐릅니다만, 본래의 01의 명령이 실행됩니다. <br>

<h2>기후 이상으로 중지된 명령을 남긴다</h2>
해저 도시 건설, 로켓 발사해 콜로니 건설이 기후 이상으로 중지되어도,<br>
당기능을 사용하면 명령 예정 항목에서 사라지지 않습니다. 다만 10회까지입니다. <br>

<h2>소방서 화재 자동 복구 기능</h2>
화재로 소방서 자신이 불타 버린 턴에, 원래 있던 좌표에 자동으로 건설 명령이 맨 위에 입력됩니다. <br>
END;
}
}

if (!function_exists('spaceInfo')) {
function spaceInfo() {
	$space = hako_v('Hspace', array());
	$solar = intval(hako_arr_get($space, 'solarwind', 0));
	$turn = intval(hako_v('HislandTurn', 0));
	if ($solar <= $turn) { $solarTxt = '<b>발생중</b>'; }
	else { $solarTxt = ($solar - $turn + $turn).'턴 부터'; if ($solar > $turn) { $solarTxt = $solar.'턴 부터'; } }
	$farm = hako_arr_get($space, 'farm', 0); $farm = ($farm == 0) ? '보유 안함' : $farm.'0'.hako_v('HunitPop','00명');
	$factory = hako_arr_get($space, 'factory', 0); $factory = ($factory == 0) ? '보유 안함' : $factory.'0'.hako_v('HunitPop','00명');
	echo "<TABLE BORDER><TR><TH ".hako_v('HbgTitleCell','').">우주력</TH><TH ".hako_v('HbgTitleCell','').">개발 면적</TH><TH ".hako_v('HbgTitleCell','').">우주 인구</TH><TH ".hako_v('HbgTitleCell','').">농장 규모</TH><TH ".hako_v('HbgTitleCell','').">공장 규모</TH><TH ".hako_v('HbgTitleCell','').">태양풍 예보</TH></TR>\n";
	echo "<TR><TD ".hako_v('HbgInfoCell','').">".$turn."턴</TD><TD ".hako_v('HbgInfoCell','').">".hako_arr_get($space,'area',0)."Hex</TD><TD ".hako_v('HbgInfoCell','').">".hako_arr_get($space,'pop',0).hako_v('HunitPop','00명')."</TD><TD ".hako_v('HbgInfoCell','').">$farm</TD><TD ".hako_v('HbgInfoCell','').">$factory</TD><TD ".hako_v('HbgInfoCell','').">$solarTxt</TD></TR></TABLE>\n";
}
}

if (!function_exists('spaceInfo2')) {
function spaceInfo2() {
	$space = hako_v('Hspace', array());
	$raw = hako_arr_get($space, 'space', '');
	$list = array();
	if (is_array($raw)) { $list = $raw; }
	else if (is_string($raw) && $raw !== '') { $list = preg_split('/\s*,\s*/', $raw); }
	$rows = array();
	for ($i = 0; $i + 1 < count($list); $i += 2) { $rows[] = array(intval($list[$i]), intval($list[$i+1])); }
	usort($rows, function($a, $b) { if ($a[1] == $b[1]) return 0; return ($a[1] > $b[1]) ? -1 : 1; });
	$hthis = hako_v('HthisFile','hako-main.php');
	echo "<TABLE BORDER><TR><TH ".hako_v('HbgTitleCell','').">우주 자산</TH><TH ".hako_v('HbgTitleCell','').">1위</TH><TH ".hako_v('HbgTitleCell','').">2위</TH><TH ".hako_v('HbgTitleCell','').">3위</TH><TH ".hako_v('HbgTitleCell','').">4위</TH><TH ".hako_v('HbgTitleCell','').">5위</TH></TR><TR><TD ".hako_v('HbgSubTCell','').">　</TD>";
	for ($i = 0; $i < 5; $i++) {
		if (isset($rows[$i])) {
			$id = $rows[$i][0]; $pt = $rows[$i][1]; $name = hako_name_by_id($id); if ($name === '') { $name = '-'; }
			echo '<TD '.hako_v('HbgInfoCell','').'><A HREF="'.$hthis.'?space='.$id.'">'.hako_html_escape_legacy($name).'</A><BR>'.intval($pt).'</TD>';
		} else {
			echo '<TD '.hako_v('HbgInfoCell','').'><A HREF="'.$hthis.'?space=0">-</A></TD>';
		}
	}
	echo "</TR></TABLE>\n";
}
}

if (!function_exists('spaceMap')) {
function spaceMap() {
	unlock();
	echo "<CENTER>\n".hako_v('HtagBig_','').hako_v('HtagName_','')."「<ruby><rb>우주<rp>(<rt>하늘<rp>)</ruby>맵」".hako_v('H_tagName','').hako_v('H_tagBig','')."( 각 섬공유)<BR>\n".hako_v('HtempBack','')."<BR>\n</CENTER>\n";
	$GLOBALS['HcurrentID'] = 999;
	$GLOBALS['HcurrentName'] = hako_v('SpaceName','우주');
	$GLOBALS['HmainMode'] = 'space';
	tempNavi(3);
	spaceInfo();
	$oldAfter = hako_v('AfterName','도');
	$oldSize = hako_v('HislandSize',15);
	$GLOBALS['AfterName'] = '';
	$GLOBALS['HislandSize'] = $oldSize;
	hako_reset_map_count();
	islandMap(3);
	spaceInfo2();
	tempLocalbbs(3);
	tempRecent(0);
	tempMapTotal();
	$GLOBALS['AfterName'] = $oldAfter;
}
}

if (!function_exists('oceanMap')) {
function oceanMap() {
	unlock();
	echo "<CENTER>\n".hako_v('HtagBig_','').hako_v('HtagName_','')."「해역 맵」".hako_v('H_tagName','').hako_v('H_tagBig','')."( 각 섬공유)<BR>\n".hako_v('HtempBack','')."<BR>\n</CENTER>\n";
	$GLOBALS['HcurrentID'] = 888;
	$GLOBALS['HcurrentName'] = hako_v('OceanName','해역');
	$GLOBALS['HmainMode'] = 'ocean';
	tempNavi(4);
	$oldAfter = hako_v('AfterName','도');
	$oldSize = hako_v('HislandSize',15);
	$GLOBALS['AfterName'] = '';
	$GLOBALS['HislandSize'] = hako_v('HoceanSize',15);
	hako_reset_map_count();
	islandMap(4);
	tempLocalbbs(4);
	tempRecent(0);
	tempMapTotal();
	$GLOBALS['HislandSize'] = $oldSize;
	$GLOBALS['AfterName'] = $oldAfter;
}
}



if (!function_exists('ugMap')) {
function ugMap($island, $mode = 0) {
	global $HugMax, $HlandDokan;
	$ugL = (isset($island['ugL']) && is_array($island['ugL'])) ? $island['ugL'] : array();
	$ugV = (isset($island['ugV']) && is_array($island['ugV'])) ? $island['ugV'] : array();
	$land = (isset($island['land']) && is_array($island['land'])) ? $island['land'] : array();
	$ugXArr = (isset($island['ugX']) && is_array($island['ugX'])) ? $island['ugX'] : array();
	$ugYArr = (isset($island['ugY']) && is_array($island['ugY'])) ? $island['ugY'] : array();
	echo "<div id='islandMap'><table border=0 cellspacing=0 cellpadding=0><tr>";
	for ($i = 0; $i < intval($HugMax); $i++) {
		if (!isset($ugXArr[$i]) || !isset($ugYArr[$i])) { continue; }
		$realX = $ugXArr[$i];
		$realY = $ugYArr[$i];
		if ($realX === '' || $realY === '') { continue; }
		$ix = intval($realX); $iy = intval($realY);
		if (!isset($land[$ix][$iy]) || $land[$ix][$iy] != $HlandDokan) { continue; }
		$dispX = $realX; $dispY = $realY;
		if ($mode == 0) { $dispX = '?'; $dispY = '?'; }
		echo "<td><table border=0 cellspacing=0 cellpadding=0><tr>";
		echo "<td colspan=3>지하".$i."(".$dispX.",".$dispY.")</td></tr><tr>";
		ugString(isset($ugL[$i][0]) ? $ugL[$i][0] : 0, isset($ugV[$i][0]) ? $ugV[$i][0] : 0, 0, 0, $mode, $dispX, $dispY);
		ugString(isset($ugL[$i][1]) ? $ugL[$i][1] : 0, isset($ugV[$i][1]) ? $ugV[$i][1] : 0, 1, 0, $mode, $dispX, $dispY);
		ugString(isset($ugL[$i][2]) ? $ugL[$i][2] : 0, isset($ugV[$i][2]) ? $ugV[$i][2] : 0, 2, 0, $mode, $dispX, $dispY);
		echo "</tr><tr>";
		ugString(isset($ugL[$i][3]) ? $ugL[$i][3] : 0, isset($ugV[$i][3]) ? $ugV[$i][3] : 0, 0, 1, $mode, $dispX, $dispY);
		ugString(isset($ugL[$i][4]) ? $ugL[$i][4] : 0, isset($ugV[$i][4]) ? $ugV[$i][4] : 0, 1, 1, $mode, $dispX, $dispY);
		ugString(isset($ugL[$i][5]) ? $ugL[$i][5] : 0, isset($ugV[$i][5]) ? $ugV[$i][5] : 0, 2, 1, $mode, $dispX, $dispY);
		echo "</tr><tr>";
		ugString(isset($ugL[$i][6]) ? $ugL[$i][6] : 0, isset($ugV[$i][6]) ? $ugV[$i][6] : 0, 0, 2, $mode, $dispX, $dispY);
		ugString(isset($ugL[$i][7]) ? $ugL[$i][7] : 0, isset($ugV[$i][7]) ? $ugV[$i][7] : 0, 1, 2, $mode, $dispX, $dispY);
		ugString(isset($ugL[$i][8]) ? $ugL[$i][8] : 0, isset($ugV[$i][8]) ? $ugV[$i][8] : 0, 2, 2, $mode, $dispX, $dispY);
		echo "</tr></table></td>";
	}
	echo "</td></tr></table></div>";
}
}

if (!function_exists('ugString')) {
function ugString($l, $lv, $x, $y, $mode, $xx, $yy) {
    global $HugImage, $Hunderground, $HugTosi, $HunitPop;
    $l = intval($l); $lv = intval($lv);
    $image = (is_array($HugImage) && isset($HugImage[$l])) ? $HugImage[$l] : 'land0.gif';
    $alt = (is_array($Hunderground) && isset($Hunderground[$l])) ? $Hunderground[$l] : '';
    if ($l == $HugTosi) { $alt .= "(".$lv.$HunitPop.")"; }
    $safeAlt = htmlspecialchars("(".$x.",".$y.") ".$alt, ENT_QUOTES, 'UTF-8');
    echo "<td class=e>";
    if ($mode == 1) {
        echo "<A HREF=\"JavaScript:void(0);\" onclick=\"ps($x,$y,$xx,$yy)\" onMouseOver=\"window.status = '$safeAlt'; return true;\" onMouseOut=\"window.status = '';\">";
    }
    echo "<IMG SRC=\"$image\" ALT=\"$safeAlt\" width=32 height=32 BORDER=0>";
    if ($mode == 1) { echo "</A>"; }
    echo "</td>";
}
}

if (!function_exists('tempCommentInput')) {
function tempCommentInput() {
	$island = hako_current_island();
	$id = hako_arr_get($island, 'id', hako_v('HcurrentID',0));
	$pass = hako_html_escape_legacy(hako_v('HdefaultPassword', hako_v('HinputPassword','')));
	$comment = hako_html_escape_legacy(hako_arr_get($island, 'comment', ''));
	$labels = hako_v('HlabelName', array());
	$label0 = (is_array($labels) && isset($labels[0])) ? $labels[0] : '괴수 출현시에 미사일호를 거부한다';
	$label1 = (is_array($labels) && isset($labels[1])) ? $labels[1] : '괴수 배틀로의 일정 수입을 거부';
	$label2 = (is_array($labels) && isset($labels[2])) ? $labels[2] : '자급원조 해줍니다';
	$label3 = (is_array($labels) && isset($labels[3])) ? $labels[3] : '자급원조 해주세요';
	$tmp = explode('<>', $label0);
	if (isset($tmp[0]) && $tmp[0] !== '') { $label0 = $tmp[0]; }
	$sel0 = hako_arr_get($island, 'commentLabel0', '') ? ' CHECKED' : '';
	$sel1 = hako_arr_get($island, 'commentLabel1', '') ? ' CHECKED' : '';
	$sel2 = hako_arr_get($island, 'commentLabel2', '') ? ' CHECKED' : '';
	$sel3 = hako_arr_get($island, 'commentLabel3', '') ? ' CHECKED' : '';
	echo "<DIV ID='CommentBox'>\n";
	if (function_exists('islandmonster')) { islandmonster(0); }
	echo '<HR>'.hako_v('HtagBig_','').'코멘트 갱신'.hako_v('H_tagBig','').'<BR>' . "\n";
	echo '<FORM action="'.hako_v('HthisFile','hako-main.php').'" method="POST">' . "\n";
	echo '<TABLE BORDER><TR>' . "\n";
	echo '<TH '.hako_v('HbgTitleCell','').'>코멘트</TH><TD '.hako_v('HbgNameCell', hako_v('HbgInfoCell','')).' colspan="3"><INPUT TYPE=text NAME=MESSAGE SIZE=110 VALUE="'.$comment.'"></TD>' . "\n";
	echo '</TR><TR>' . "\n";
	echo '<TH '.hako_v('HbgTitleCell','').' rowspan=2>의지 표시</TH><TD '.hako_v('HbgNameCell', hako_v('HbgInfoCell','')).' rowspan=2>' . "\n";
	echo '<INPUT TYPE=checkbox NAME="COMMENT_LABEL0" VALUE="1"'.$sel0.'>'.hako_html_escape_legacy($label0).'<br>' . "\n";
	echo '<INPUT TYPE=checkbox NAME="COMMENT_LABEL1" VALUE="1"'.$sel1.'>'.hako_html_escape_legacy($label1).'<br>' . "\n";
	echo '<INPUT TYPE=checkbox NAME="COMMENT_LABEL2" VALUE="1"'.$sel2.'>'.hako_html_escape_legacy($label2).'<br>' . "\n";
	echo '<INPUT TYPE=checkbox NAME="COMMENT_LABEL3" VALUE="1"'.$sel3.'>'.hako_html_escape_legacy($label3) . "\n";
	echo '</TD>' . "\n";
	echo '<TH '.hako_v('HbgTitleCell','').'>패스워드</TH><TD '.hako_v('HbgNameCell', hako_v('HbgInfoCell','')).'><INPUT TYPE=password NAME=PASSWORD VALUE="'.$pass.'"></TD>' . "\n";
	echo '</TR><TR>' . "\n";
	echo '<TD '.hako_v('HbgTitleCell','').' colspan=2 align=center><INPUT TYPE="hidden" NAME=JAVAMODE VALUE="'.hako_html_escape_legacy(hako_v('HjavaMode','')).'">' . "\n";
	echo '<INPUT TYPE=submit VALUE="코멘트 갱신" NAME=MessageButton'.$id.'>' . "\n";
	echo '</TD></TR></TABLE>' . "\n";
	echo '※　의지 표시에 강제력은 없고,'.hako_v('AfterName','도').' 기분을 나타내는 수단에 지나지 않습니다.' . "\n";
	echo '</FORM></DIV>' . "\n";
}
}

if (!function_exists('tempLocalbbs')) {
function tempLocalbbs($mode) {
	if (!hako_v('HuseLbbs', 0)) { return; }
	echo "<DIV ID='localBBS'><HR>\n";
	if ($mode == 0) {
		echo hako_v('HtagBig_','').hako_v('HtagName_','').hako_v('HcurrentName','').hako_v('AfterName','도').hako_v('H_tagName','')." 관광자 통신".hako_v('H_tagBig','')."<BR>\n";
		tempLbbsInput(); tempLbbsContents(0);
	} elseif ($mode == 1) {
		echo hako_v('HtagBig_','').hako_v('HtagName_','').hako_v('HcurrentName','').hako_v('AfterName','도').hako_v('H_tagName','')."관광자 통신".hako_v('H_tagBig','')."<BR>\n";
		tempLbbsInputOW(); tempLbbsContents(0);
	} elseif ($mode == 3) {
		echo hako_v('HtagBig_','').hako_v('HtagName_','')."「우주 맵」".hako_v('H_tagName','')." 관광자 통신".hako_v('H_tagBig','')."<BR>\n";
		tempLbbsInput(); tempLbbsContents(3);
	} elseif ($mode == 4) {
		echo hako_v('HtagBig_','').hako_v('HtagName_','')."「해역 맵」".hako_v('H_tagName','')." 관광자 통신".hako_v('H_tagBig','')."<BR>\n";
		tempLbbsInput(); tempLbbsContents(4);
	}
	echo "</DIV>\n";
}
}

if (!function_exists('tempLbbsInput')) {
function tempLbbsInput() {
	$id = hako_v('HcurrentID', 0);
	$pass = hako_html_escape_legacy(hako_v('HdefaultPassword', hako_v('HinputPassword','')));
	$name = hako_html_escape_legacy(hako_v('HdefaultName',''));
	$list = hako_get_island_list_options(hako_v('defaultID', hako_v('HcurrentID',0)));
	echo '<FORM action="'.hako_v('HthisFile','hako-main.php').'" method="POST"><TABLE BORDER><TR><TH '.hako_v('HbgTitleCell','').'>이름</TH><TH '.hako_v('HbgTitleCell','').'>내용</TH></TR><TR><TD '.hako_v('HbgInfoCell','').'><INPUT TYPE="text" SIZE=32 MAXLENGTH=32 NAME="LBBSNAME" VALUE="'.$name.'"></TD><TD '.hako_v('HbgInfoCell','').'><INPUT TYPE="text" SIZE=100 NAME="LBBSMESSAGE"></TD></TR><TR><TD '.hako_v('HbgInfoCell','').' colspan="2">자신 도：<SELECT NAME="ISLANDID">'.$list.'</SELECT>';
	if (hako_v('HlbbsAnon',0)) { echo '<INPUT TYPE="radio" NAME="LBBSTYPE" VALUE="ANON">관광객'; }
	echo '<INPUT TYPE="radio" NAME="LBBSTYPE" VALUE="PUBLIC" CHECKED>공개 <INPUT TYPE="radio" NAME="LBBSTYPE" VALUE="SECRET"><FONT COLOR="red">극비</FONT>　패스워드：<INPUT TYPE="password" SIZE=16 MAXLENGTH=32 NAME=PASSWORD VALUE="'.$pass.'"><INPUT TYPE="submit" VALUE="기록 한다" NAME="LbbsButtonFO'.$id.'">번호<SELECT NAME=NUMBER>';
	for ($i = 0; $i < intval(hako_v('HlbbsMax',10)); $i++) { $j = $i + 1; echo "<OPTION VALUE=$i>$j\n"; }
	echo '</SELECT><INPUT TYPE="submit" VALUE="삭제한다" NAME="LbbsButtonFD'.$id.'"></TD></TR></TABLE></FORM>' . "\n";
}
}

if (!function_exists('tempLbbsInputOW')) {
function tempLbbsInputOW() {
	$id = hako_v('HcurrentID', 0);
	$pass = hako_html_escape_legacy(hako_v('HdefaultPassword', hako_v('HinputPassword','')));
	$name = hako_html_escape_legacy(hako_v('HdefaultName',''));
	echo '<FORM action="'.hako_v('HthisFile','hako-main.php').'" method="POST"><INPUT TYPE="hidden" NAME=JAVAMODE VALUE="'.hako_html_escape_legacy(hako_v('HjavaMode','')).'"><TABLE BORDER><TR><TH '.hako_v('HbgTitleCell','').'>이름</TH><TH '.hako_v('HbgTitleCell','').' colspan=2>내용</TH></TR><TR><TD '.hako_v('HbgInfoCell','').'><INPUT TYPE="text" SIZE=32 MAXLENGTH=32 NAME="LBBSNAME" VALUE="'.$name.'"></TD><TD '.hako_v('HbgInfoCell','').' colspan=2><INPUT TYPE="text" SIZE=100 NAME="LBBSMESSAGE"></TD></TR><TR><TH '.hako_v('HbgTitleCell','').'>패스워드</TH><TH '.hako_v('HbgTitleCell','').' colspan=2>동작</TH></TR><TR><TD '.hako_v('HbgInfoCell','').'><INPUT TYPE=password SIZE=32 MAXLENGTH=32 NAME=PASSWORD VALUE="'.$pass.'"></TD><TD '.hako_v('HbgInfoCell','').' align=right><INPUT TYPE="submit" VALUE="기록 한다" NAME="LbbsButtonOW'.$id.'"></TD><TD '.hako_v('HbgInfoCell','').' align=right>번호<SELECT NAME=NUMBER>';
	for ($i = 0; $i < intval(hako_v('HlbbsMax',10)); $i++) { $j = $i + 1; echo "<OPTION VALUE=$i>$j\n"; }
	echo '</SELECT><INPUT TYPE="submit" VALUE="삭제한다" NAME="LbbsButtonDL'.$id.'"></TD></TR></TABLE></FORM>' . "\n";
}
}

if (!function_exists('hako_lbbs_source')) {
function hako_lbbs_source($mode) {
	if ($mode == 3) { return hako_arr_get(hako_v('Hspace', array()), 'lbbs', array()); }
	if ($mode == 4) { return hako_arr_get(hako_v('Hocean', array()), 'lbbs', array()); }
	$island = hako_current_island();
	return hako_arr_get($island, 'lbbs', array());
}
}

if (!function_exists('tempLbbsContents')) {
function tempLbbsContents($mode = 0) {
	$lbbs = hako_lbbs_source($mode);
	echo '<TABLE BORDER><TR><TH '.hako_v('HbgTitleCell','').'>번호</TH><TH '.hako_v('HbgTitleCell','').'>기록 내용</TH></TR>' . "\n";
	$max = intval(hako_v('HlbbsMax', 10));
	for ($i = 0; $i < $max; $i++) {
		$line = (is_array($lbbs) && isset($lbbs[$i])) ? $lbbs[$i] : '';
		if (preg_match('/([0-9]*)\<(.*)\<([0-9]*)\>(.*)\>(.*)$/', $line, $m)) {
			$j = $i + 1;
			$secret = intval($m[1]); $speakerRaw = $m[2]; $speakerType = intval($m[3]); $name = $m[4]; $message = $m[5];
			if ($speakerType == 0 && $secret != 0 && hako_v('HmainMode','') != 'owner') { $body = '<CENTER><FONT COLOR=gray>- 비밀 -</FONT></CENTER>'; }
			else { $body = hako_html_escape_legacy($name).' > '.hako_html_escape_legacy($message); }
			echo '<TR><TD '.hako_v('HbgSubTCell','').'>'.hako_v('HtagNumber_','').$j.hako_v('H_tagNumber','').'</TD><TD '.hako_v('HbgLbbsCell','').'>'.$body.'</TD></TR>' . "\n";
		}
	}
	echo "</TABLE>\n";
}
}

if (!function_exists('tempLbbsNoMessage')) { function tempLbbsNoMessage(){ echo hako_v('HtagBig_','').'이름 또는 내용이 비어있습니다. '.hako_v('H_tagBig','').hako_v('HtempBack',''); } }
if (!function_exists('tempLbbsDelete')) { function tempLbbsDelete(){ echo hako_v('HtagBig_','').'기록 내용을 삭제했습니다'.hako_v('H_tagBig','').'<HR>'; } }
if (!function_exists('tempLbbsAdd')) { function tempLbbsAdd(){ echo hako_v('HtagBig_','').'기록을 실시했습니다'.hako_v('H_tagBig','').'<HR>'; } }

if (!function_exists('tempRecent')) {
function tempRecent($mode = 0) {
	echo "<HR><DIV ID='RecentlyLog2'>\n";
	echo hako_v('HtagBig_','').hako_v('HtagName_','').hako_v('HcurrentName','').hako_v('AfterName','도').hako_v('H_tagName','')." 의  근황".hako_v('H_tagBig','')."<BR>\n";
	if (function_exists('logFilePrint')) {
		$logMax = intval(hako_v('HlogMax', 10)); if ($logMax <= 0) { $logMax = 10; }
		for($i = 0; $i < $logMax; $i++) { logFilePrint($i, hako_v('HcurrentID', 0), $mode); }
	}
	echo "</DIV>\n";
}
}

if (!function_exists('tempMapTotal')) {
function tempMapTotal() {
	$landCount = hako_v('LandCount', array());
	$landCount2 = hako_v('LandCount2', array());
	$point = intval(hako_v('HpointNumber', 0));
	if (hako_v('HmainMode','') == 'ocean') { $point = intval(hako_v('HpointOcean', $point)); }
	if ($point <= 0) { $size = intval(hako_v('HislandSize',15)); $point = $size * $size; }
	if (intval(hako_v('HdebugMode',0)) > 0 && is_array($landCount2) && count($landCount2) > 0) {
		echo "<hr><DIV ID='mapStatistics'>지명의 집계표<table border=0 cellspacing=0 cellpadding=0><tr><td ".hako_v('HbgTitleCell','').">지명</td><td ".hako_v('HbgTitleCell','').">개수</td><td ".hako_v('HbgTitleCell','').">비율</td></tr>";
		arsort($landCount2, SORT_NUMERIC);
		foreach ($landCount2 as $k => $v) { $w = intval($v * 10000 / $point + 0.5) / 100; echo '<tr><td '.hako_v('HbgTitleCell','').'>'.hako_html_escape_legacy($k).' </td><td '.hako_v('HbgInfoCell','').'>'.$v.'</td><td '.hako_v('HbgInfoCell','').'>　'.$w.'%</td></tr>'; }
		echo "</table></DIV>\n";
	}
	echo "<br><DIV ID='mapStatistics'>".hako_v('AfterName','도')."점유 수의 표";
	echo "<table border=0 cellspacing=0 cellpadding=0><tr><td ".hako_v('HbgTitleCell','').">".hako_v('AfterName','도')."명</td><td ".hako_v('HbgTitleCell','').">개수</td><td ".hako_v('HbgTitleCell','').">비율</td></tr>";
	if (!is_array($landCount)) { $landCount = array(); }
	arsort($landCount, SORT_NUMERIC);
	foreach ($landCount as $id => $v) {
		if ($v <= 0) { continue; }
		if (intval($id) > 0) { $name = hako_name_by_id($id); if ($name === '') { $name = '불명'; } else { $name .= hako_v('AfterName','도'); } }
		else { $name = '자신의 섬(도)'; }
		$w = intval($v * 10000 / $point + 0.5) / 100;
		echo '<tr><td '.hako_v('HbgTitleCell','').'>'.hako_html_escape_legacy($name).'</td><td '.hako_v('HbgInfoCell','').'>'.$v.'</td><td '.hako_v('HbgInfoCell','').'>　'.$w.'%</td></tr>';
	}
	echo "</table></DIV>\n";
}
}

if (!function_exists('hako_popup_command_links')) {
function hako_popup_command_links($mode = 0) {
	$names = hako_v('HcomName', array());
	$costs = hako_v('HcomCost', array());
	$list = hako_command_kind_list();
	$divs = hako_v('HcommandDivido', array());
	$out = '';
	$makeLink = function($kind, $arg, $label, $title) {
		$kind = intval($kind);
		$arg = intval($arg);
		$js = "window.opener.cominput(window.opener.document.myForm,6,$kind,$arg); return false;";
		$t = ($title !== '') ? ' TITLE="'.hako_html_escape_legacy($title).'"' : '';
		return "<a href='javascript:void(0);' onClick=\"$js\" class='M'$t>".hako_html_escape_legacy($label)."</a><br>\n";
	};
	if ($mode == 10) {
		$kind = intval(hako_v('HcomUg', 0));
		$cost = hako_command_cost_label($kind);
		$name = (is_array($names) && isset($names[$kind])) ? $names[$kind] : '지하 개발';
		$out .= hako_html_escape_legacy($name).'('.hako_html_escape_legacy($cost).")<br>\n";
		$out .= $makeLink($kind, 0, '지하 도시 건설', $cost);
		$out .= $makeLink($kind, 1, '지하 농장 건설', $cost);
		$out .= $makeLink($kind, 2, '지하 공장 건설', $cost);
		$out .= $makeLink($kind, 3, '지하 미사일 기지 건설', $cost);
		$out .= $makeLink($kind, 4, '지하 합성석유 공장 건설', $cost);
		$out = preg_replace('/<\/a><br>\n$/', "</a>(2400억)<br>\n", $out);
		return $out;
	}

	$popcmd1 = null;
	$popcmd2 = null;
	if ($mode == 3) { $popcmd1 = 6; $popcmd2 = 6; }
	elseif ($mode == 4) { $popcmd1 = 7; $popcmd2 = 7; }
	else { $popcmd1 = 2; $popcmd2 = 3; }

	if (is_array($divs) && count($divs) > 0 && is_array($list) && count($list) > 0) {
		$comCount = count($divs);
		for ($m = 0; $m < $comCount; $m++) {
			$parts = explode(',', $divs[$m]);
			$dd = isset($parts[1]) ? intval($parts[1]) : -999999;
			$ff = isset($parts[2]) ? intval($parts[2]) : 999999;
			for ($i = 0; $i < count($list); $i++) {
				$kind = intval($list[$i]);
				$cost = (is_array($costs) && isset($costs[$kind])) ? hako_command_cost_label($kind) : '무료';
				if ($kind > ($dd - 1) && $kind < ($ff + 1)) {
					if (($m == $popcmd1) || ($m == $popcmd2)) {
						if ($kind == intval(hako_v('HcomSMissileGM', -9999))) { $out .= "<hr>"; }
						if ($kind == intval(hako_v('HcomSBuild', -9999))) {
							// CGI 원본과 동일하게 사용하지 않는 우주 건설계는 표시하지 않는다.
						} elseif ($kind == intval(hako_v('HcomSEisei', -9999))) {
							$seisei = hako_v('HsEisei', array());
							for ($j = 0; $j < 5; $j++) {
								$label = isset($seisei[$j]) ? $seisei[$j] : $j;
								$out .= $makeLink($kind, $j, '우주'.$label.'('.$cost.')', $cost);
							}
						} else {
							$name = (is_array($names) && isset($names[$kind])) ? $names[$kind] : ('명령'.$kind);
							$out .= $makeLink($kind, 0, $name.'('.$cost.')', $cost);
						}
					} else {
						break;
					}
				}
				if ($kind < ($ff + 1)) { continue; }
			}
		}
	}
	return $out;
}
}

if (!function_exists('hako_print_space_java_info')) {
function hako_print_space_java_info() {
	$space = hako_v('Hspace', array());
	$turn = intval(hako_v('HislandTurn', 0));
	$solar = intval(hako_arr_get($space, 'solarwind', 0));
	$solarwind = ($solar <= $turn) ? '<b>발생중</b>' : $solar.'턴 부터';
	$food = hako_arr_get($space, 'food', 0);
	$food = ($food <= 0) ? '0' : $food.hako_v('HunitFood','00톤');
	$pop = hako_arr_get($space, 'pop', 0).hako_v('HunitPop','00명');
	echo "<DIV ID='islandInfo'><TABLE BORDER><TR>
";
	echo '<TD>'.hako_v('HtagTH_','<b>').'우주력'.hako_v('H_tagTH','</b>').'</TD>';
	echo '<TD>'.$turn.'턴</TD>';
	echo '<TD>'.hako_v('HtagTH_','<b>').'태양풍 예보'.hako_v('H_tagTH','</b>').'</TD>';
	echo '<TD>'.$solarwind.'</TD>';
	echo '<TD>'.hako_v('HtagTH_','<b>').'우주 총인구'.hako_v('H_tagTH','</b>').'</TD>';
	echo '<TD>'.$pop.'</TD>';
	echo '<TD>'.hako_v('HtagTH_','<b>').'잔여 식량'.hako_v('H_tagTH','</b>').'</TD>';
	echo '<TD>'.$food.'</TD>';
	echo "</TR></TABLE></DIV>
";
}
}

if (!function_exists('hako_print_island_java_impl')) {
function hako_print_island_java_impl($mode = 0) {
	unlock();
	$oldMode = hako_v('HmainMode','');
	$oldAfter = hako_v('AfterName','도');
	$oldSize = hako_v('HislandSize',15);
	$GLOBALS['HmainMode'] = 'landmap';
	if ($mode == 3) {
		$GLOBALS['HcurrentID'] = 999;
		$GLOBALS['HcurrentName'] = hako_v('SpaceName','우주');
		$GLOBALS['AfterName'] = '';
		$msg = '입력한 명령과 지점이 개발 화면의 예정 명령과 좌표에 반영됩니다. <br>태양풍 발생중은, 모든 명령이 중지가 됩니다.';
	} elseif ($mode == 4) {
		$GLOBALS['HcurrentID'] = 888;
		$GLOBALS['HcurrentName'] = hako_v('OceanName','해역');
		$GLOBALS['AfterName'] = '';
		$GLOBALS['HislandSize'] = hako_v('HoceanSize',15);
		$msg = '입력한 명령과 지점이 개발 화면의 예정 명령과 좌표에 반영됩니다.';
	} else {
		$cid = hako_v('HcurrentID',0);
		if ($cid > 0) { hako_set_current_island_by_id($cid); }
		$hnum = hako_safe_id_number($cid);
		if ($hnum === '') { if (function_exists('tempProblem')) { tempProblem(); } return; }
		$GLOBALS['HcurrentNumber'] = $hnum;
		$island = hako_island_by_number($hnum);
		$GLOBALS['HcurrentName'] = hako_arr_get($island, 'name', '');
		$msg = '공격하는 지점을 클릭해 주세요. <br>클릭한 지점이 개발 화면의 좌표로 설정됩니다.';
	}
	if ($mode == 10) { $msg = '입력한 명령과 지점이 개발 화면의 예정 명령과 좌표 1(입구),<br>좌표 2(지하 좌표)에 반영됩니다.'; }
	$javaMode = hako_v('HjavaMode','cgi');
	$clickCom = hako_popup_command_links($mode);
	$curName = hako_html_escape_legacy(hako_v('HcurrentName',''));
	$after = hako_v('AfterName','도');
	echo <<<END
<SCRIPT Language="JavaScript">
<!--
var mx = 0;
var my = 0;
if(document.addEventListener) document.addEventListener('mousemove', Mmove, false);
else document.onmousemove = Mmove;
function hakoSetSelect(sel, val) {
	if(!sel) return;
	for(var i = 0; i < sel.options.length; i++) {
		if(String(sel.options[i].value) == String(val)) { sel.options[i].selected = true; return; }
	}
	if(sel.options[val]) sel.options[val].selected = true;
}
function ps(x, y, xx, yy) {
	var java = '$javaMode';
	if(window.opener && window.opener.document && window.opener.document.myForm) {
		var f = window.opener.document.myForm;
		var af = window.opener.document.allForm;
		if(typeof xx != 'undefined' && typeof yy != 'undefined') {
			if(String(xx) != '?' && String(yy) != '?') { hakoSetSelect(f.POINTX, xx); hakoSetSelect(f.POINTY, yy); if(af){af.POINTX.value=xx; af.POINTY.value=yy;} }
			hakoSetSelect(f.POINTTX, x); hakoSetSelect(f.POINTTY, y); if(af){af.POINTTX.value=x; af.POINTTY.value=y;}
		} else {
			if(f.xy1 && f.xy1.checked){ hakoSetSelect(f.POINTX, x); hakoSetSelect(f.POINTY, y); if(af){af.POINTX.value=x; af.POINTY.value=y;} }
			if(f.xy2 && f.xy2.checked){ hakoSetSelect(f.POINTTX, x); hakoSetSelect(f.POINTTY, y); if(af){af.POINTTX.value=x; af.POINTTY.value=y;} }
		}
	}
	if(java == 'java') moveLAYER('menu', mx, my);
	return true;
}
function moveLAYER(layName,x,y){
	var el = document.getElementById ? document.getElementById(layName) : null;
	if(!el && document.all) el = document.all[layName];
	if(!el) return;
	el.style.left = (x + 10) + 'px';
	el.style.top = (y - 30) + 'px';
	el.style.display = 'block';
	el.style.visibility = 'visible';
}
function menuclose(){
	var el = document.getElementById ? document.getElementById('menu') : null;
	if(!el && document.all) el = document.all['menu'];
	if(el){ el.style.display = 'none'; el.style.visibility = 'hidden'; }
}
function Mmove(e){
	e = e || window.event;
	if(e.pageX || e.pageY){ mx = e.pageX; my = e.pageY; }
	else { mx = e.clientX + document.body.scrollLeft; my = e.clientY + document.body.scrollTop; }
}
function hakoMapClick(e, x, y){
	Mmove(e || window.event);
	return ps(x, y);
}
//-->
</SCRIPT>
<DIV ID='targetMap'>
<H1>$curName$after</H1><p>$msg
<a href="Javascript:void(0);" onclick="window.close()">화면을 닫는다</A>
</DIV>
<span id="menu" style="position:absolute; visibility:hidden; display:none;">
<table border=0 class="PopupCell"><tr><td nowrap>
$clickCom<HR>
<a href="Javascript:void(0);" onClick="menuclose()" class='M'>메뉴를 닫는다</A>
</td></tr></table></span>
END;
	tempNavi($mode);
	if ($mode == 3 && function_exists('hako_print_space_java_info')) { hako_print_space_java_info(); }
	hako_reset_map_count();
	if ($mode == 10 && function_exists('ugMap')) {
		$island = hako_current_island();
		$ugMode = 0;
		$passId = hako_v('defaultID', hako_v('HcurrentID',''));
		if (function_exists('checkPassword') && checkPassword(hako_arr_get($island, 'password', ''), hako_v('HdefaultPassword','')) && strval(hako_arr_get($island, 'id', '')) === strval($passId)) {
			$ugMode = 1;
		}
		ugMap($island, $ugMode);
	} else {
		islandMap($mode);
		if (function_exists('tempRecent')) { tempRecent(0); }
	}
	$GLOBALS['HmainMode'] = $oldMode;
	$GLOBALS['AfterName'] = $oldAfter;
	$GLOBALS['HislandSize'] = $oldSize;
}
}

if (!function_exists('printIslandJava')) { function printIslandJava($mode = 0){ return hako_print_island_java_impl($mode); } }

if (!function_exists('fight_map')) { function fight_map(){ printIslandMain(); } }
if (!function_exists('FightViewMain')) { function FightViewMain(){ printIslandMain(); } }
?>
