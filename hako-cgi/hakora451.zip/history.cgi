#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}

# RA용에 개조
#---------------------------------------------------------------------
#
#	궁극 구상의 하코니와 최근 사건과 최근 날씨의 이력을 표시
#
#	작성일 : 2001/11/25 (ver0.10)
#	작성자 : 라스티아 <nayupon@mail.goo.ne.jp>
#
#---------------------------------------------------------------------

BEGIN {
	# Perl 5.004 이상이필요
	require 5.004;

########################################
	# 오류 표시
	$SIG{__WARN__} = $SIG{__DIE__} =
	sub {
		my($msg) = @_;

		$msg =~ s/\n/<br>/g;
		print STDOUT <<END;
Content-type: text/html; charset=UTF-8

<p><big><tt><b>ERROR:</b><br>$msg</tt></big></p>
END
		exit(-1);
	};
########################################
}
#---------------------------------------------------------------------
#	초기 설정
#---------------------------------------------------------------------
# 초기 설정용 파일을 읽기
require './hako-init.cgi';
require './hako-io.cgi';

# 섬의 데이터 항목 수
# 궁극 구상의 하코니와(ver3계)는27 ver2계는14 ver1계와 노멀하코니와v2.3은13 RA은24 기타 하코니와는 불명
# 바다전쟁은15 제국 바다전쟁은17(바다전쟁계는 sub logFilePrint 다르면 이상해지므로 주의)
$HislandData = 24;

# 데이터 항목 수를 조정(변경불필요)
$HislandData += 12*$HnewGameO + 8*$HnewGame + $HnewGameM;

#----------------------------
#	HTML 에 관한 설정
#----------------------------
# 브라우저의 제목막대의 명칭
$title = '최근 사건';

# 화면의 색상과 배경 설정(HTML)
$body = '<body bgcolor=#EEFFEE>';

# 화면의'돌아가기'링크선(URL)
$bye = './hako-main.cgi';

# 메인 루틴-------------------------------------------------------
cookieInput();
unless($ENV{HTTP_REFERER} =~ /${HbaseDir}/) {
	if($HskinName ne '' ){
		$baseSKIN = $HskinName;
	} else {
		$baseSKIN = "${efileDir}/$HcssFile";
	}
	print qq{Content-type: text/html; charset=UTF-8\n\n};
	out(<<END);
<HTML>
<HEAD><META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
<TITLE>
$title
</TITLE>
<link rel="stylesheet" type="text/css" href="${baseSKIN}">
</HEAD>
$body
<H1>부정나접속입니다</H1>
</BODY></HTML>
END
	exit(0);
}
cgiInput();
if (-e $HpasswordFile) {
	# 비밀번호 파일 있음
	open(PIN, "<$HpasswordFile") || die $!;
	chomp($HmasterPassword = <PIN>); # 마스터 비밀번호 읽기
	chomp($HspecialPassword = <PIN>); # 특수 비밀번호를 읽기
	close(PIN);
}
if($HhtmlLogMake && ($HcurrentID == 0)) {
	unless(-e "${HhtmlDir}/hakolog.html") {
		# 최근 사건HTML출력
		logPrintHtml();
		tempRefresh(3, '로그 작성안입니다. 그대로 잠시 기다려 주세요');
	} else {
		tempRefresh(0, '잠시 기다려 주세요');
	}
} else {
	if(!readIslandsFile()){
		tempHeader();
		htmlError();
	} else {
		$HislandList = getIslandList($HcurrentID);
		tempHeader();
		out("<DIV ID='RecentlyLog'>\n");

		$HcurrentNumber = $HidToNumber{$HcurrentID};
		my($island) = $Hislands[$HcurrentNumber];
		$HcurrentName = islandName($island);
		# 최근 사건
		if($HMode == 99) {
			if($HcurrentID == 0) {
				logFilePrintAll();
			} else {
				tempIslandHeader($HcurrentID, $HcurrentName);
				# 비밀번호
				if(checkPassword($island, $HinputPassword) && ($HcurrentID eq $defaultID)) {
					logPrintLocal(1);
				} else {
					# password 차이우
					logPrintLocal(0);
				}
			}
		} else {
			if($HcurrentID == 0) {
				logFilePrint($HMode, $HcurrentID, 0);
			} else {
				tempIslandHeader($HcurrentID, $HcurrentName);
				# 비밀번호
				if(checkPassword($island, $HinputPassword) && ($HcurrentID eq $defaultID)) {
					logFilePrint($HMode, $HcurrentID, 1);
				} else {
					# password 오류
					logFilePrint($HMode, $HcurrentID, 0);
				}
			}
		}
		out("</DIV>\n");
	}
}
tempFooter();
#종료
exit(0);

# 서브 루틴---------------------------------------------------------
#---------------------------------------------------------------------
#	함수명 : htmlError
#	기계 능 : HTML 의오류 메시지의 출력
#	인 수 : 없음
#	반환 값 : 없음
#---------------------------------------------------------------------
sub htmlError{
	out("<h2>오류가 발생했습니다</h2>\n");
}
#--------------------------------------------------------------------
#	POST 또는 GET으로 입력된 데이터 가져오기
#--------------------------------------------------------------------
sub cgiInput {
	my($line, $getLine);

	# 입력을 받아 UTF-8로 처리
	$line = <>;
	$line =~ tr/+/ /;
	$line =~ s/%([a-fA-F0-9]{2})/pack(H2, $1)/eg;
#
	$line =~ s/[\x00-\x1f\,]//g;

	# GET 값을 받음
	$getLine = $ENV{'QUERY_STRING'};

	if($line =~ /ID=([0-9]*)/){
		$HcurrentID = $1;
	}
	if($line =~ /PASSWORD=([^\&]*)/) {
		$HinputPassword = $1;
	}
	if($getLine =~ /ID=([0-9]*)/){
		$HcurrentID = $1;
	}
	if($getLine =~ /PASSWORD=([^\&]*)/) {
		$HinputPassword = $1;
	}
	if($getLine =~ /Event=([0-9]*)/){
		$HMode = $1;
	} else {
		$HMode = 0;
	}
}
#cookie 입력
sub cookieInput {
	my($cookie);
	my $HthisFile = "$HbaseDir/hako-main.cgi";

#	$cookie = $ENV{'HTTP_COOKIE'};
	$cookie = $ENV{'HTTP_COOKIE'};

	if($cookie =~ /${HthisFile}OWNISLANDID=\(([^\)]*)\)/) {
		$defaultID = $1;
	}
	if($cookie =~ /${HthisFile}OWNISLANDPASSWORD=\(([^\)]*)\)/) {
		$HdefaultPassword = $1;
	}
	if($cookie =~ /${HthisFile}SKIN=\(([^\)]*)\)/) {
		$HskinName = $1;
	}

}

#---------------------------------------------------------------------
#	HTML 의헤더와 푸터 부분을 출력
#---------------------------------------------------------------------
# 헤더
sub tempHeader {
	if($HskinName ne '' ){
		$baseSKIN = $HskinName;
	} else {
		$baseSKIN = "${efileDir}/$HcssFile";
	}
	if($ENV{'HTTP_ACCEPT_ENCODING'}=~/gzip/ && $Hgzip == 1){
		print qq{Content-type: text/html; charset=UTF-8\n};
		print qq{Content-encoding: gzip\n\n};
		open(STDOUT,"| $HpathGzip/gzip -1 -c");
		print " " x 2048 if($ENV{HTTP_USER_AGENT}=~/MSIE/);
		print qq{<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">\n\n};
	}else{
		print qq{Content-type: text/html; charset=UTF-8\n\n};
		print qq{<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">\n\n};
	}

	out(<<END);
<HTML>
<HEAD>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
<TITLE>
$title
</TITLE>
<link rel="stylesheet" type="text/css" href="${baseSKIN}">
</HEAD>
$body<DIV ID='BodySpecial'>
<DIV ID='LinkHead'>
[<A HREF="http://www8.plala.or.jp/nayupon/">궁극 구상 하코니와 개발</A>]
<HR></DIV>
<A HREF="$bye">[돌아가기]</A><br><br>
END
	logDekigoto();
	out(<<END);
<HR>
<FORM name="recentForm" action="${HbaseDir}/history.cgi" method="POST" style="margin : 2px 0px;">
<B>[최근 사건]</B>
<A HREF="history.cgi?Event=99">[ALL]</A>
END
	my $i, $turn;
	for($i = 0;$i < $HtopLogTurn;$i++) {
		$turn = $HislandTurn - $i;
		last unless($turn> 0);
		out("<A HREF='history.cgi?Event=${i}'>");
		if($i == 0) {
			out("[턴${turn}(현재)]");
		} else {
			out("[${turn}]");
		}
		out("</A>\n");
	}

	out(<<END);
 <B>[링크]</B>
<SELECT NAME="ID">$HislandList</SELECT>
<INPUT type=hidden name=PASSWORD value=$HinputPassword>
<INPUT type="submit" value="를보기">
</FORM>
END

}

# 푸터
sub tempFooter {
	out(<<END);
<HR>
<DIV ID='LinkFoot'>
관리자:$HadminName(<A HREF="mailto:$Hemail">$Hemail</A>)<BR>
게시판(<A HREF="$Hbbs">$Hbbs</A>)<BR>
톱 페이지(<A HREF="$Htoppage">$Htoppage</A>)<BR>
하코니와 제도의 페이지(<A HREF="http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html">http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html</A>)<BR>
Hakoniwa R.A. 의페이지(<A HREF="http://www5b.biglobe.ne.jp/~k-e-i/i.html">http://www5b.biglobe.ne.jp/~k-e-i/i.html</A>)<BR>
END

##### 추가 친분20020307
	if($Hperformance) {
		my($uti, $sti, $cuti, $csti) = times();
		$uti += $cuti;
		$sti += $csti;
		my($cpu) = $uti + $sti;

	#	 로그 파일 쓰기(테스트 계측용, 평소에는 주석 처리해 주세요)
	#	 open(POUT,">>cpu-h.log");
	#	 print POUT "CPU($cpu) : user($uti) system($sti)\n";
	#	 close(POUT);

		out(<<END);
<DIV align="right">
<SMALL>CPU($cpu) : user($uti) system($sti)</SMALL>
</DIV>
END
	}
#####
	out(<<END);
</DIV>
</DIV></BODY>
</HTML>
END
}
# HTML화리후레슈
sub tempRefresh {
	my($delay, $str) = @_;


	unless($Hgzip == 1) {
		print qq{Content-type: text/html; charset=UTF-8\n\n};
		print qq{<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">\n\n};
		out(<<END);
<HTML><HEAD><META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
<TITLE>HTML화</TITLE>
<meta HTTP-EQUIV='refresh' CONTENT='$delay; URL="${htmlDir}/hakolog.html"'>
</HEAD><BODY><DIV ID='BodySpecial'>
<H2>$str</H2>
END
	} else {
		open(IN, "<${HhtmlDir}/hakolog.html") || die $!;
		@buffer = <IN>;
		close(IN);
		if($ENV{'HTTP_ACCEPT_ENCODING'}=~/gzip/) {
			print qq{Content-type: text/html; charset=UTF-8;\n};
			print qq{Content-encoding: gzip\n\n};
			open(STDOUT,"| $HpathGzip/gzip -1 -c");
			print " " x 2048 if($ENV{HTTP_USER_AGENT}=~/MSIE/);
		} else {
			print qq{Content-type: text/html; charset=UTF-8;\n\n};
		}
		print @buffer;
	}
}

# 섬 데이터 드롭다운 메뉴용
sub getIslandList {
	my($select) = @_;
	my($list, $name, $id, $s, $i);

	#섬 목록의 메뉴
	$list = '';
	foreach $i (0..$islandNumber) {
		$name = islandName($Hislands[$i]);
		$name =~ s/<[^<]*>//g;
		$id = $Hislands[$i]->{'id'};
		if($id eq $select) {
			$s = 'SELECTED';
		} else {
			$s = '';
		}
		$list.= "<OPTION VALUE=\"$id\" $s>${name}\n";
	}
	return $list;
}

#---------------------------------------------------------------------
#	섬의 최근 상황의 링크
#---------------------------------------------------------------------
# 헤더
sub tempIslandHeader {
my($id, $name) = @_;

	if(checkPassword($Hislands[$HidToNumber{$id}]->{'password'}, $HinputPassword) && ($HcurrentID eq $defaultID)) {
		out(<<END);
<HR>
<FONT COLOR=\"#FF0000\"><B>[${name}의 최근 상황]</B></FONT>
END
	} else {
		out(<<END);
<HR>
<B>[${name}의 최근 상황]</B>
END
	}

	if($HinputPassword eq '') {
		out("<A HREF='history.cgi?ID=${id}&Event=99'>[ALL]</A>");
	} else {
		out("<A HREF='history.cgi?ID=${id}&PASSWORD=${HinputPassword}&Event=99'>[ALL]</A> ");
	}
	my $i, $turn;
	for($i = 0;$i < $HtopLogTurn;$i++) {
		$turn = $HislandTurn - $i;
		return unless($turn> 0);
		if($HinputPassword eq '') {
			out("<A HREF='history.cgi?ID=${id}&Event=${i}'>");
		} else {
			out("<A HREF='history.cgi?ID=${id}&PASSWORD=${HinputPassword}&Event=${i}'>");
		}
		if($i == 0) {
			out("[턴${turn}(현재)]");
		} else {
			out("[${turn}]");
		}
		out("</A>\n");
	}
	out("<HR>\n");
}
#---------------------------------------------------------------------
#	로그 파일제목
#---------------------------------------------------------------------
sub logDekigoto {
	out(<<END);
<H1>최근 사건</H1>
END
}
#---------------------------------------------------------------------
#	로그 파일 전체 표시
#---------------------------------------------------------------------
sub logFilePrintAll {
	my($i);
	for($i = 0; $i < $HtopLogTurn; $i++) {
		logFilePrint($i, 0, 0);
	}
}
#---------------------------------------------------------------------
# 개별 로그 표시
#---------------------------------------------------------------------
sub logPrintLocal {
	my($mode) = @_;
	my($i);
	for($i = 0; $i < $HtopLogTurn; $i++) {
		logFilePrint($i, $HcurrentID, $mode);
	}
}
#---------------------------------------------------------------------
#	파일 번호를 지정해 로그 표시 #RA용
#---------------------------------------------------------------------
sub logFilePrint {
	my($fileNumber, $id, $mode) = @_;
	my($set_turn) = 0;
	open(LIN, "${HdirName}/hakojima.log$_[0]");
	my($line, $m, $turn, $id1, $id2, $message);
	while($line = <LIN>) {
		$line =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),(.*)$/;
		($m, $turn, $id1, $id2, $message) = ($1, $2, $3, $4, $5);

		# 기밀관계
		if($m == 1) {
			if(($mode == 0) || ($id1 != $id)) {
				# 기밀 표시 권한 없음
				next;
			}
			$m = '<B>(기밀)</B>:';
		} else {
			$m = '';
		}

		# 정확히 표시할지
		if($id != 0) {
			if(($id != $id1) &&
			 ($id != $id2)) {
				next;
			}
		}

		if(!$set_turn){
			if(!$Hseason) {
				out("<B>=====[<span class=number><FONT SIZE=4> 턴$turn </FONT></span>]================================================</B><BR>\n");
			} else {
				# 계절의 표시
				my @seasonName = ('<span class=winter>겨울</span>','<span class=spring>봄</span>','<span class=summer>여름</span>','<span class=autumn>가을</span>');
				my $month = ($turn % 12) + 1;
				my $year = ($turn / 12) + 1;
				my $calender = sprintf('<span class=month><FONT SIZE=2><small>%s</small> %d년 %d월 </FONT></span>', $Halmanac, $year, $month);
				$calender.= "<span class='season'>$seasonName[int(($month - 1) / 3)]</span>";
				out("<B>=====[<span class=number><FONT SIZE=4> <small>턴$turn</small> </FONT></span>]=============================$calender</B><BR>\n");
			}
			$set_turn++;
		}
		out(" ${m}$message<BR>\n");
	}
	close(LIN);
}
#----------------------------------------------------------------------
# HTML생성
#----------------------------------------------------------------------
sub logPrintHtml {
	my($sec, $min, $hour, $date, $mon, $year, $day, $yday, $dummy) = gmtime(time + $Hjst);
	$mon++;
	my($sss) = "${mon}월${date}일 ${hour} 때${min}분${sec}초";

	$html1=<<_HEADER_;
<HTML><HEAD><META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
<TITLE>
최근 사건
</TITLE>
<BASE HREF="$htmlDir/">
<link rel="stylesheet" type="text/css" href="${efileDir}/$HcssFile">
</HEAD>
<BODY $htmlBody><DIV ID='BodySpecial'>
<DIV ID='RecentlyLog'>
<H1>최근 사건</H1>
<FORM>
최신갱신일:$sss..
<INPUT TYPE="button" VALUE=" 다시 읽기" onClick="location.reload()">
</FORM>
<hr>
_HEADER_

$html3=<<_FOOTER_;
</DIV><HR></DIV></BODY></HTML>
_FOOTER_
	my($i);
	for($i = 0; $i < $HhtmlLogTurn; $i++) {
		$id =0;
		$mode = 0;
		my($set_turn) = 0;
		open(LIN, "${HdirName}/hakojima.log$i");
		my($line, $m, $turn, $id1, $id2, $message);
		while($line = <LIN>) {
			$line =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),(.*)$/;
			($m, $turn, $id1, $id2, $message) = ($1, $2, $3, $4, $5);

			# 기밀관계
			if($m) {
				next if(!$mode || ($id1 != $id)); # 기밀 표시 권한 없음
				$m = '<B>(기밀)</B>';
			} else {
				$m = '';
			}

			# 정확히 표시할지
			if($id) {
				next if(($id != $id1) && ($id != $id2));
			}

			# 표시
			if(!$set_turn){
				if(!$Hseason) {
					$html2.= "<B>=====[<span class=number><FONT SIZE=4> 턴$turn </FONT></span>]================================================</B><BR>\n";
				} else {
					# 계절의 표시
					my @seasonName = ('<span class=winter>겨울</span>','<span class=spring>봄</span>','<span class=summer>여름</span>','<span class=autumn>가을</span>');
					my $month = ($turn % 12) + 1;
					my $year = ($turn / 12) + 1;
					my $calender = sprintf('<span class=month><FONT SIZE=2><small>%s</small> %d년 %d월 </FONT></span>', $Halmanac, $year, $month);
					$calender.= "<span class='season'>$seasonName[int(($month - 1) / 3)]</span>";
					$html2.= "<B>=====[<span class=number><FONT SIZE=4> <small>턴$turn</small> </FONT></span>]=============================$calender</B><BR>\n";
				}
				$set_turn++;
			}
			$html2.= "<span class='number'>★</span>:$message<BR>\n";
		}
		close(LIN);
	}
	open(HTML, ">${HhtmlDir}/hakolog.html");
#	print HTML $html1;
#	print HTML $html2;
#	print HTML $html3;
	print HTML $html1;
	print HTML $html2;
	print HTML $html3;
	close (HTML);
	chmod(0666,"${HhtmlDir}/hakolog.html");
}
