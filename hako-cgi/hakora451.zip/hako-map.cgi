#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}
#----------------------------------------------------------------------
# 하코니와 제도 ver2.30
# 지도 모드 모듈(ver1.00)
# 사용 조건과 사용 방법은 hako-readme.txt 파일을 참조해 주세요
#
# 하코니와 제도의 페이지: http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html
#----------------------------------------------------------------------
#----------------------------------------------------------------------
# Hakoniwa R.A. ver2.11
# 메인 스크립트(하코니와 제도 ver2.30)
# 사용 조건, 사용 방법은 read-renas.txt 파일을 참조
#
# KEI PAGE: http://www5b.biglobe.ne.jp/~k-e-i/
#----------------------------------------------------------------------
#----------------------------------------------------------------------
# JavaScript판 -ver1.11-
# 사용 조건, 사용 방법은  배포처를 확인하세요.
# 부속의 js-readme.txt 모오읽기하세요.
# 앗포:http://appoh.execweb.cx/hakoniwa/
#----------------------------------------------------------------------

#----------------------------------------------------------------------
# Java스크립트개발 화면
#----------------------------------------------------------------------
# 헤더
sub tempHeaderJava {
	$baseIMG = $HimageDir;
	if($HskinName ne '' ){
		$baseSKIN = $HskinName;
	} else {
		$baseSKIN = "${efileDir}/$HcssFile";
	}
	if($HseaonImgSet && $Hmonth) {
		$seasonIMG = "$HseasonImg[$Hmonth]/";
	} else {
		$seasonIMG = "";
	}
	my($mapsizeNumber) = $HidToNumber{$defaultID};
	my($mapsize) = $Hislands[$mapsizeNumber]->{'totoyoso'}->[0];
	if($mapsize =~ /\(mapsize\@(\d+)\)/){
		if($1 < 1){ $Hms1 = 1;} elsif($1> 32){ $Hms1 = 32;} else { $Hms1 = $1;}
	}
	else{ $Hms1 = 16;}
	$Hms2 = $Hms1*2;

	if($ENV{'HTTP_ACCEPT_ENCODING'}=~/gzip/ && $Hgzip == 1){
		print qq{Content-type: text/html; charset=UTF-8\n};
		print qq{Content-encoding: gzip\n\n};
		open(STDOUT,"| $HpathGzip/gzip -1 -c");
		print " " x 2048 if($ENV{HTTP_USER_AGENT}=~/MSIE/);
		print qq{<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">\n\n};
	}else{
		print qq{Content-type: text/html; charset=UTF-8\n\n};
		print qq{<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">\n\n};
	}

	out(<<END);
<HTML>
<HEAD>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
<TITLE>
$Htitle
</TITLE>
<BASE HREF="${baseIMG}/${seasonIMG}">
<link rel="stylesheet" type="text/css" href="${baseSKIN}">
</HEAD>
$Body<DIV ID='BodySpecial'>
<DIV ID='LinkHead'>
[<A HREF="http://t.pos.to/hako/">하코니와 제도 스크립트 배포처</A>]
[<A HREF="http://appoh.execweb.cx/hakoniwa/">하코니와 JavaScript판 배포처</A>]
[<A HREF="http://www.din.or.jp/~mkudo/hako/">지도 작성 도구 배포처</A>]
[<A HREF="$Hbbs">게시판</A>]
[<A HREF="$Htoppage">톱 페이지</A>]
<HR>
</DIV>
END
}

# ○○섬개발계획
sub tempOwnerJava {
	$HcurrentNumber = $HidToNumber{$HcurrentID};
	my($island) = $Hislands[$HcurrentNumber];

	# 명령 설정
	$set_com = "";
	$com_max = "";
	for($i = 0; $i < $HcommandMax; $i++) {
		# 각 요소 꺼내기
		my($command) = $island->{'command'}->[$i];
		my($s_kind, $s_target, $s_x, $s_y, $s_arg) =
			(
				$command->{'kind'},
				$command->{'target'},
				$command->{'x'},
				$command->{'y'},
				$command->{'arg'}
			);
		# 명령 등록
		if($i == $HcommandMax-1) {
			$set_com.= "\[$s_kind\,$s_x\,$s_y\,$s_arg\,$s_target\]\n";
			$com_max.= "0";
		}else{
			$set_com.= "\[$s_kind\,$s_x\,$s_y\,$s_arg\,$s_target\]\,\n";
			$com_max.= "0,";
		}
	}

	#명령 목록 설정
	my($l_kind);
	$set_listcom = "";
	@click_com[1..7] = ('', '', '', '', '', '', '');
	$All_listCom = 0;
	$com_count = @HcommandDivido;
	for($m = 0; $m < $com_count; $m++) {
		($aa,$dd,$ff) = split(/,/,$HcommandDivido[$m]);
		$set_listcom.= "\[ ";
		for($i = 0; $i < $HcommandTotal; $i++) {
			$l_kind = $HcomList[$i];
			next if((($l_kind == $HcomSave)||($l_kind == $HcomLoad))&& !($island->{'shr'}));
			if($l_kind == $HcomHouse) {
				$l_cost = $island->{'pts'} * 3;
			} elsif(($l_kind == $HcomBettown) || ($l_kind == $HcomKai)) {
				$l_cost = $island->{'pts'};
			} else {
				$l_cost = $HcomCost[$l_kind];
			}
			if($l_cost == 0) {
				$l_cost = '무료';
			} elsif($l_cost < 0) {
				$l_cost = - $l_cost; $l_cost.= $HunitFood;
			} else {
				$l_cost.= $HunitMoney;
			}
			if($l_kind> $dd-1 && $l_kind < $ff+1) {
				$set_listcom.= "\[$l_kind\,\'$HcomName[$l_kind]\',\'$l_cost\'\]\,\n";
				if(($m> 0) && ($m < 8)) {
#					$click_com[$m].= "<a title='$l_cost' href='javascript:void(0);' onClick='cominput(myForm,6,$l_kind)' STYlE='text-decoration:none'>$HcomName[$l_kind]<font size='-2'>($l_cost)</font></a><br>\n";
					$click_com[$m].= "<a title='$l_cost' href='javascript:void(0);' onClick='cominput(myForm,6,$l_kind)' STYlE='text-decoration:none'>$HcomName[$l_kind]</a><br>\n";
				}
				$All_listCom++;
			}
			next if($l_kind < $ff+1);
		}
		$bai = length($set_listcom);
		$set_listcom = substr($set_listcom, 0,$bai-2);
		$set_listcom.= " \],\n";
	}
	$bai = length($set_listcom);
	$set_listcom = substr($set_listcom, 0,$bai-2);
	if($HdefaultKind eq ''){
		$default_Kind = 1;
	} else {
		$default_Kind = $HdefaultKind;
	}

	#섬 목록 설정
	my($set_island, $l_name, $l_id);
	$set_island = "";
	foreach $i (0..$islandNumber) {
		$l_name = islandName($Hislands[$i]);
		$l_name =~ s/<[^<]*>//g;
		$l_name =~ s/'/\\'/g;
		$l_id = $Hislands[$i]->{'id'};
		if($i == $islandNumber){
			$set_island.= "\[$l_id\,\'$l_name\'\]\n";
		}else{
			$set_island.= "\[$l_id\,\'$l_name\'\]\,\n";
		}
	}
	if($HextraJs) {
		unless(-e "${HefileDir}/hakojima.js") {
			require('./hako-js.cgi');
			makeJS(1);
		}
	}

	out(<<END);
<CENTER>
${HtagBig_}${HtagName_}${HcurrentName}${H_tagName}개발계획${H_tagBig}<BR>
$HtempBack<BR>
</CENTER>
<SCRIPT Language="JavaScript">
<!--
// JavaScript 개발판 배포처
// 앗포암자하코니와 제도( http://appoh.execweb.cx/hakoniwa/ )
// Programmed by Jynichi Sakai(앗포)
// ↑ 삭제하지 마세요.
var str;
d_Kind = $default_Kind;
d_ID = $HcurrentID;
All_list = $All_listCom;
g = [$com_max];
k1 = [$com_max];
k2 = [$com_max];
tmpcom1 = [ [0,0,0,0,0] ];
tmpcom2 = [ [0,0,0,0,0] ];
command = [
$set_com];
comlist = [
$set_listcom
];
islname = [
$set_island];
//-->
</SCRIPT>
END

	if($HextraJs) {
		out(<<END);
<SCRIPT Language="JavaScript" SRC="${efileDir}/hakojima.js"></SCRIPT>
END
	} else {
		require('./hako-js.cgi');
		makeJS(0);
	}

	out(<<END);
<DIV ID="menu" style="position:absolute; visibility:hidden;">
<TABLE BORDER=0 class="PopupCell">
<TR><TD class='T' colspan=2>
<FORM name='POPUP'>
<IMG NAME="NAVIIMG" SRC="" width=32 height=32 align="left">
<TEXTAREA NAME="COMSTATUS" rows="2" class="popupnavi"></TEXTAREA>
</TD></TR>
</FORM>
<TR><TD>
$click_com[1]<hr>
$click_com[2]<hr>
$click_com[3]<hr>
$click_com[7]
</TD><TD>
$click_com[5]
$click_com[4]<hr>
$click_com[6]
</TD></TR>
<TR><TD colspan=2>
<a href="Javascript:void(0);" onClick="menuclose()" STYlE="text-decoration:none">메뉴를 닫기</A>
</TD></TR>
</TABLE>
</DIV>
END

	islandInfo(1);

	out(<<END);
<!-- # 추가(JS 판 ver2.0)IE6대응------->
<CENTER><TABLE BORDER=0><TR><TD class='M'>
<!---여기까지------------------------------>
<CENTER>
<TABLE BORDER>
<TR valign=top>
<TD $HbgInputCell width=25%>
<CENTER>
<FORM name="myForm" action="$HthisFile" method=POST>
<P>
<B>계획번호</B><SELECT NAME=NUMBER>
END
	# 계획번호
	my($j, $i);
	for($i = 0; $i < $HcommandMax; $i++) {
		$j = $i + 1;
		out("<OPTION VALUE=$i>$j\n");
	}

	if ($HmenuOpen eq 'on') {
		$open = "CHECKED";
	}else{
		$open = "";
	}

	out(<<END);
</SELECT><BR>
<HR>
<B>개발계획</B>
<INPUT TYPE="checkbox" NAME="MENUOPEN"onClick="check_menu()" $open>비 표시<br>
<SELECT NAME=menu onchange="SelectList(myForm)">
<OPTION VALUE=>전체종류
END
	for($i = 0; $i < $com_count; $i++) {
		($aa) = split(/,/,$HcommandDivido[$i]);
		out("<OPTION VALUE=$i>$aa\n");
	}
	out(<<END);
</SELECT><br>
<SELECT NAME=COMMAND>
<option> </option>
<option> </option>
<option> </option>
<option> </option>
<option> </option>
<option> </option>
<option> </option>
<option> </option>
<option> </option>
<option> </option>
</SELECT>
<HR>
<B> 명령 입력</B><BR><B>
<A HREF=JavaScript:void(0); onClick="cominput(myForm,1)">삽입</A>
 <A HREF=JavaScript:void(0); onClick="cominput(myForm,2)">덮어쓰기</A>
 <A HREF=JavaScript:void(0); onClick="cominput(myForm,3)">삭제</A>
</B>
<HR>
<B>좌표(</B>
		<SELECT NAME=POINTX>

END
	foreach $i (0..$islandSize) {
		if($i == $HdefaultX) {
			out("<OPTION VALUE=$i SELECTED>$i\n");
		} else {
			out("<OPTION VALUE=$i>$i\n");
		}
	}

	out(<<END);
</SELECT>, <SELECT NAME=POINTY>
END

	foreach $i (0..$islandSize) {
		if($i == $HdefaultY) {
			out("<OPTION VALUE=$i SELECTED>$i\n");
		} else {
			out("<OPTION VALUE=$i>$i\n");
		}
	}
	out(<<END);
</SELECT><B>)</B>
<HR>
<B>수량</B><SELECT NAME=AMOUNT>
END

	# 수량
	for($i = 0; $i < 100; $i++) {
		out("<OPTION VALUE=$i>$i\n");
	}
	my($myislandID) = $defaultTarget;
	$myislandID = $island->{'id'} if($myislandID eq '');

	out(<<END);
</SELECT>
<HR>
<B>목표 ${AfterName}</B>:
<B><A HREF=JavaScript:void(0); onClick="jump(myForm, '$HjavaMode')"> 표시 </A></B>
·
<B><A HREF=JavaScript:void(0); onClick="myisland(myForm,'$myislandID')"> 선택 </A></B><BR>
<SELECT NAME=TARGETID>
$HtargetList<BR>
</SELECT>
<HR>
<B> 명령 이동</B>:
<BIG>
<A HREF=JavaScript:void(0); onClick="cominput(myForm,4)" STYlE="text-decoration:none"> ▲ </A>..
<A HREF=JavaScript:void(0); onClick="cominput(myForm,5)" STYlE="text-decoration:none"> ▼ </A>
</BIG>
<HR>
<INPUT TYPE="hidden" NAME="COMARY" value="comary">
<INPUT TYPE="hidden" NAME="JAVAMODE" value="$HjavaMode">
<INPUT TYPE=submit VALUE="계획 전송" NAME=CommandJavaButton$Hislands[$HcurrentNumber]->{'id'}>
<br><font size=2>마지막에 <span class='attention'>계획 전송 버튼</span>을<br>누르는 것을 잊지 마세요.</font>
<HR>
<B> 비밀번호</B></BR>
<INPUT TYPE=password NAME=PASSWORD VALUE="$HdefaultPassword">
</CENTER>
</TD>
<TD $HbgMapCell><center>
<TEXTAREA NAME="COMSTATUS" cols="48" rows="2"></TEXTAREA>
</center>
END
	islandMap(1, 1); # 섬 지도, 소유자 모드
	my $comment = $Hislands[$HcurrentNumber]->{'comment'};
	my $shutomessage = $island->{'shutomessage'};
	if ($shutomessage == 555) {
		$shutohen = "";
	} else {
		$shutohen = <<"END";
<TR>
<TH>수도 이름 변경<BR><small>(최대 ${HlengthShuto}자)</small></TH>
<TD><INPUT TYPE=text NAME=SHUTOMESSAGE SIZE=32 VALUE=$shutomessage>
<INPUT TYPE=submit VALUE="수도 이름 변경" NAME=ShutoButton$Hislands[$HcurrentNumber]->{'id'}>
</TD></TR>
<TR>
END
	}
	my $totoyoso = $Hislands[$HcurrentNumber]->{'totoyoso'}->[0];
	my $totoyoso2 = $Hislands[$HcurrentNumber]->{'totoyoso'}->[1];
	out(<<END);
</FORM>
</TD>
<TD $HbgCommandCell id="plan">
<FORM name="allForm" action="$HthisFile" method=POST>
<INPUT TYPE="hidden" NAME=PASSWORD VALUE="$HdefaultPassword">
<INPUT TYPE="hidden" NAME=MENUOPEN VALUE="allmenu">
<INPUT TYPE="hidden" NAME=NUMBER VALUE="allno">
<INPUT TYPE="hidden" NAME=POINTY VALUE="0">
<INPUT TYPE="hidden" NAME=POINTX VALUE="0">
<INPUT TYPE="hidden" NAME=JAVAMODE value="$HjavaMode"><br>
<DIV ID='AutoCommand'><B>자동 입력</B><br>
<SELECT NAME=COMMAND>
END
	#명령
	my($kind, $cost, $s);
	my $ff = 0;
	foreach (@HcommandDivido) {
		my $ff0 = (split(/,/,$_))[2];
		$ff = $ff0 if($ff < $ff0);
	}
	for($i = 0; $i < $HcommandTotal; $i++) {
		$kind = $HcomList[$i];
		$cost = $HcomCost[$kind];
		if($kind> $ff){
			if($cost == 0) {
				$cost = '무료';
			}
			if($kind == $HdefaultKind) {
				$s = 'SELECTED';
			} else {
				$s = '';
			}
			out("<OPTION VALUE=$kind $s>$HcomName[$kind]($cost)\n");
		}
	}
	out(<<END);
</SELECT><br>
<B>벌채 수량</B><SELECT NAME=AMOUNT>
END

	# 수량
	for($i = 0; $i < 100; $i++) {
		out("<OPTION VALUE=$i>$i\n");
	}

	out(<<END);
</SELECT>×200본이상<br>
<INPUT TYPE="hidden" NAME="CommandButton$Hislands[$HcurrentNumber]->{'id'}">
<INPUT TYPE="submit" VALUE="자동 입력 계획 전송">
<HR>
</DIV>
<ilayer name="PARENT_LINKMSG" width="100%" height="100%">
<layer name="LINKMSG1" width="200"></layer>
<span id="LINKMSG1"></span>
</ilayer>
<BR>
</FORM>
</TD>
</TR>
</TABLE>
END

	islandData();

	out(<<END);
</CENTER>
</TD></TR><TR><TD class='M'>
<DIV ID='CommentBox'>
<HR>
${HtagBig_}코멘트갱신${H_tagBig}<BR>
<FORM action="$HthisFile" method="POST">
<INPUT TYPE="hidden" NAME=JAVAMODE value="$HjavaMode">
<TABLE BORDER=0>
<TR>
<TH>코멘트<BR><small>(최대 ${HlengthMessage}자)</small></TH><TD><INPUT TYPE=text NAME=MESSAGE SIZE=80 VALUE="$comment"></TD>
</TR>
<TR>
<TH> 비밀번호</TH><TD><INPUT TYPE=password NAME=PASSWORD VALUE="$HdefaultPassword">
<INPUT TYPE=submit VALUE="코멘트갱신" NAME=MessageButton$Hislands[$HcurrentNumber]->{'id'}>
</TD>
</TR>
$shutohen
<TR>
<TH>TOTO 예상(왼쪽)<BR><small>(최대 ${HlengthYoso}자)</small></TH>
<TD><INPUT TYPE=text NAME=YOSOMESSAGE SIZE=44 VALUE=$totoyoso>
<INPUT TYPE=submit VALUE="예상(왼쪽)" NAME=TotoButton$Hislands[$HcurrentNumber]->{'id'}>
</TD></TR>
<TR>
<TH>TOTO 예상(오른쪽)<BR><small>(최대 ${HlengthYoso}자)</small></TH>
<TD><INPUT TYPE=text NAME=YOSOMESSAGE2 SIZE=44 VALUE=$totoyoso2>
<INPUT TYPE=submit VALUE="예상(오른쪽)" NAME=TotosButton$Hislands[$HcurrentNumber]->{'id'}>
</TD></TR>
</TABLE>
</FORM>
</DIV>
<!-- # 추가(JS 판 ver2.0)IE6대응------->
</TD></TR></TABLE></CENTER>
<!---여기까지------------------------------>
END

}

#----------------------------------------------------------------------
# 명령 모드
#----------------------------------------------------------------------
sub commandJavaMain {
	# id에서 섬을 가져옴
	$HcurrentNumber = $HidToNumber{$HcurrentID};
	my($island) = $Hislands[$HcurrentNumber];
	$HcurrentName = islandName($island);

	# 비밀번호
	if(!checkPassword($island,$HinputPassword)) {
		# password 오류
		unlock();
		tempWrongPassword();
		return;
	}

	# 모드에서 분기
	my($command) = $island->{'command'};
	for($i = 0; $i < $HcommandMax; $i++) {
		# 명령 등록
		$HcommandComary =~ s/([0-9]*) ([0-9]*) ([0-9]*) ([0-9]*) ([0-9]*) //;
		my $kind = $1;
		if($kind == 0) {
			$kind = $HcomDoNothing;
		}
		$command->[$i] = {
			'kind' => $kind,
			'x' => $2,
			'y' => $3,
			'arg' => $4,
			'target' => $5
		};
	}
	tempCommandAdd();
	# 데이터 쓰기
	writeIslandsFile($HcurrentID);

	# owner mode 로
	ownerMain();
}

#----------------------------------------------------------------------
# 관광 모드
#----------------------------------------------------------------------
sub printIslandJava {
	# 개방
	unlock();

	# id에서 섬 번호를 가져옴
	$HcurrentNumber = $HidToNumber{$HcurrentID};
	$island = $Hislands[$HcurrentNumber];

	# 왠지그 섬이 없는 경우
	if($HcurrentNumber eq '') {
		tempProblem();
		return;
	}

	# 이름 가져오기
	$HcurrentName = islandName($Hislands[$HcurrentNumber]);

	#명령 목록 설정
	my($l_kind);
	@click_com[8, 9] = ('', '');
	if($HjavaMode eq 'java'){
		$com_count = @HcommandDivido;
		for($m = 0; $m < $com_count; $m++) {
			($aa,$dd,$ff) = split(/,/,$HcommandDivido[$m]);
			for($i = 0; $i < $HcommandTotal; $i++) {
				$l_kind = $HcomList[$i];
				if($l_kind == $HcomHouse) {
					$l_cost = $island->{'pts'} * 3;
				} elsif(($l_kind == $HcomBettown) || ($l_kind == $HcomKai)) {
					$l_cost = $island->{'pts'};
				} else {
					$l_cost = $HcomCost[$l_kind];
				}
				if($l_cost == 0) {
					$l_cost = '무료';
				} else {
					$l_cost.= $HunitMoney;
				}
				if($l_kind> $dd-1 && $l_kind < $ff+1) {
					if(($m == 8) || ($m == 9)) {
#						$click_com[$m].= "<a title='$l_cost' href='javascript:void(0);' onClick='window.opener.cominput(window.opener.document.myForm,6,$l_kind)' STYlE='text-decoration:none'>$HcomName[$l_kind]<font size='-2'>($l_cost)</font></a><br>\n";
						$click_com[$m].= "<a title='$l_cost' href='javascript:void(0);' onClick='window.opener.cominput(window.opener.document.myForm,6,$l_kind)' STYlE='text-decoration:none'>$HcomName[$l_kind]</a><br>\n";
					}
				}
				next if($l_kind < $ff+1);
			}
		}
	}

	out(<<END);
<SCRIPT Language="JavaScript">
<!--
if(document.getElementById) {
	document.onmousemove = Mmove;
} else if(document.layers) {
	window.captureEvents(Event.MOUSEMOVE);
	window.onMouseMove = Mmove;
} else if(document.all) {
	document.onmousemove = Mmove;
}

if((document.layers) || (document.all)){ // IE4,IE5,NN4
	window.document.onmouseup = menuclose;
}

function ps(x, y) {
	var java = '$HjavaMode';
	window.opener.document.myForm.POINTX.options[x].selected = true;
	window.opener.document.myForm.POINTY.options[y].selected = true;
	if(java == 'java')moveLAYER("menu",mx,my);
	return true;
}

function moveLAYER(layName,x,y) {
	if(document.getElementById){		//NN6,IE5
		if(document.all){				//IE5
			el = document.getElementById(layName);
			el.style.left= event.clientX + document.body.scrollLeft + 10;
			el.style.top= event.clientY + document.body.scrollTop - 30;
			el.style.display = "block";
			el.style.visibility ='visible';
		}else{
			el = document.getElementById(layName);
			el.style.left=x+10;
			el.style.top=y-30;
			el.style.display = "block";
			el.style.visibility ='visible';
		}
	} else if(document.layers){				//NN4
		msgLay = document.layers[layName];
		msgLay.moveTo(x+10,y-30);
		msgLay.visibility = "show";
	} else if(document.all){				//IE4
		msgLay = document.all(layName);
		msgLay.style.pixelLeft = x+10;
		msgLay.style.pixelTop = y-30;
		msgLay.style.display = "block";
		msgLay.style.visibility = "visible";
	}

}

function menuclose() {
	if (document.getElementById){
		document.getElementById("menu").style.display = "none";
	} else if (document.layers){
		document.menu.visibility = "hide";
	} else if (document.all){
		window["menu"].style.display = "none";
	}
}

function Mmove(e) {
	if(document.all){
		mx = event.x;
		my = event.y;
	}else if(document.layers){
		mx = e.pageX;
		my = e.pageY;
	}else if(document.getElementById){
		mx = e.pageX;
		my = e.pageY;
	}
}

function set_land(x, y, land, img) {
	com_str = land + "\\n";
	document.POPUP.COMSTATUS.value= com_str;
	document.POPUP.NAVIIMG.src= img;
}
//-->
</SCRIPT>
<DIV ID='targetMap'>
${HtagBig_}${HtagName_}${HcurrentName}${H_tagName}${H_tagBig}<br>
공격할 지점을 클릭해 주세요.<br>클릭한 지점이 개발 화면의 좌표로 설정됩니다.
<DIV ID="menu" style="position:absolute; visibility:hidden;">
<TABLE BORDER=0 class="PopupCell">
<TR><TD class='T'>
<FORM name='POPUP'>
<IMG NAME="NAVIIMG" SRC="" width=32 height=32 align="left">
<TEXTAREA NAME="COMSTATUS" rows="2" class="popupnavi"></TEXTAREA>
</TD></TR>
</FORM>
<TR><TD>
$click_com[8]<hr>
$click_com[9]<HR>
<a href="Javascript:void(0);" onClick="menuclose()" STYlE="text-decoration:none">메뉴를 닫기</A>
</TD></TR>
</TABLE>
</DIV>
END
	if(checkPassword($island, $HdefaultPassword) && ($island->{'id'} eq $defaultID)) {
		islandMap(1, 1); # 섬 지도, 관광 모드
#		exLbbs($island->{'id'}, 1) if($HuseExlbbs);
# 	templandStringFlash(1); # 의사MAP데이터 표시
	} else {
		islandMap(0, 1); # 섬 지도, 관광 모드
#		exLbbs($island->{'id'}, 0) if($HuseExlbbs);
# 	templandStringFlash(0); # 의사MAP데이터 표시
	}
	#의사MAP데이터:RA용의 작성도구는 없으므로, 주석 처리로 있습니다

	# ○○섬 로컬 게시판
#	if($HuseLbbs) {
		#require('./hako-lbbs.cgi');
		#tempLbbsContents(); # 게시판내용
		#길어지므로 표시하지 않음. 표시하는 경우,#tempLbbs.. 의#을 제거.
#	}
	# 외부 게시판
#	if($HuseExlbbs) {
#		if($island->{'password'} eq encode($HdefaultPassword) && ($island->{'id'} eq $defaultID)) {
#			exLbbs($island->{'id'}, 1);
#		}else{
#			exLbbs($island->{'id'}, 0);
#		}
#	}

	# 최근 상황
	tempRecent(0, $HuseHistory2);
	out("</DIV>");
}

sub templandStringFlash {
	my($mode) = @_;
	require './hako-js.cgi';
	landStringFlash($mode); # 의사MAP데이터 표시
}

#----------------------------------------------------------------------
# 관광 모드
#----------------------------------------------------------------------
# 메인
sub printIslandMain {
	# 개방
	unlock();

	if($HadminMode && !checkSpecialPassword($HdefaultPassword)) {
		tempWrongPassword();
		return;
	}

	# id에서 섬 번호를 가져옴
	$HcurrentNumber = $HidToNumber{$HcurrentID};

	# 왠지그 섬이 없는 경우
	if($HcurrentNumber eq '') {
		tempProblem();
		return;
	}

	# 이름 가져오기
	$HcurrentName = islandName($Hislands[$HcurrentNumber]);

	# 관광 화면
	tempPrintIslandHead(); # 수 있도록 말로!!
	islandInfo(0); # 섬의 정보
	islandMap($HadminMode, 0); # 섬 지도, 관광 모드

	islandJamp(); # 섬의 이동
	islandData(); # 각종 데이터

	# ○○섬 로컬 게시판
	if($HuseLbbs) {
		require('./hako-lbbs.cgi');
		tempLbbsMain(0);
	}
	if($HuseExlbbs) { # 외부 게시판
		exLbbs($HcurrentID, 0) ;
	}

	# 최근 상황
	tempRecent(0, $HuseHistory2);

}

#----------------------------------------------------------------------
# 개발 모드
#----------------------------------------------------------------------
# 메인
sub ownerMain {
	# 개방
	unlock();

	# 모드를 명시
	$HmainMode = 'owner';

	# id에서 섬을 가져옴
	$HcurrentNumber = $HidToNumber{$HcurrentID};
	my($island) = $Hislands[$HcurrentNumber];
	$HcurrentName = islandName($island);

	# 비밀번호
	if(!checkPassword($island,$HinputPassword)) {
		# password 오류
		tempWrongPassword();
		return;
	}

	# 개발 화면
	if($HjavaMode eq 'java') {
		tempOwnerJava(); # 'JavaScript개발계획'
	}else{ # '일반 모드개발계획'
		tempOwner();
	}

	# ○○섬 로컬 게시판
	if($HuseLbbs) {
		require('./hako-lbbs.cgi');
		tempLbbsMain(1); # 로컬 게시판
	}
	if($HuseExlbbs) { # 외부 게시판
		exLbbs($HcurrentID, 1) ;
	}

	# 최근 상황
	tempRecent(1, $HuseHistory1);

}
#----------------------------------------------------------------------
# 명령 모드
#----------------------------------------------------------------------
# 메인
sub commandMain {
	# id에서 섬을 가져옴
	$HcurrentNumber = $HidToNumber{$HcurrentID};
	my($island) = $Hislands[$HcurrentNumber];
	$HcurrentName = islandName($island);

	# 비밀번호
	if(!checkPassword($island,$HinputPassword)) {
		# password 오류
		unlock();
		tempWrongPassword();
		return;
	}

	# 모드에서 분기
	my($command) = $island->{'command'};

	if($HcommandMode eq 'delete') {
		slideFront($command, $HcommandPlanNumber);
		tempCommandDelete();
	} elsif(($HcommandKind == $HcomAutoPrepare) ||
			($HcommandKind == $HcomAutoPrepare2)) {
		# 전체 개간, 전체땅고르기
		# 좌표배열을 만들기
		makeRandomPointArray();
		my($land) = $island->{'land'};

		# 명령 종류결정
		my($kind) = $HcomPrepare;
		if($HcommandKind == $HcomAutoPrepare2) {
			$kind = $HcomPrepare2;
		}

		my($i) = 0;
		my($j) = 0;
		while(($j < $HpointNumber) && ($i < $HcommandMax)) {
			my($x) = $Hrpx[$j];
			my($y) = $Hrpy[$j];
			if($land->[$x][$y] == $HlandWaste) {
				slideBack($command, $HcommandPlanNumber);
				$command->[$HcommandPlanNumber] = {
					'kind' => $kind,
					'target' => 0,
					'x' => $x,
					'y' => $y,
					'arg' => 0
					};
				$i++;
			}
			$j++;
		}
		tempCommandAdd();
	} elsif(($HcommandKind == $HcomAutoReclaim) ||
			($HcommandKind == $HcomAutoDestroy)) {
		# 매립, 굴착
		makeRandomPointArray();
		my($land) = $island->{'land'};
		my($landValue) = $island->{'landValue'};

		# 명령 종류결정
		my($kind) = $HcomReclaim;
		if($HcommandKind == $HcomAutoDestroy) {
			$kind = $HcomDestroy;
		}
		my($i) = 0;
		my($j) = 0;
		while(($j < $HpointNumber) && ($i < $HcommandMax)) {
			my($x) = $Hrpx[$j];
			my($y) = $Hrpy[$j];
			if (($land->[$x][$y] == $HlandSea) && ($landValue->[$x][$y] == 1)) {
				slideBack($command, $HcommandPlanNumber);
				$command->[$HcommandPlanNumber] = {
					'kind' => $kind,
					'target' => 0,
					'x' => $x,
					'y' => $y,
					'arg' => 0
				};
				$i++;
			}
			$j++;
		}
		tempCommandAdd();
	} elsif(($HcommandKind == $HcomAutoSellTree) ||
			($HcommandKind == $HcomAutoForestry)) {
		# 벌채, 벌채와 나무심기
		# (수량 × 200그루보다 많음이 숲만이대상)
		makeRandomPointArray();
		my($land) = $island->{'land'};
		my($landValue) = $island->{'landValue'};

		# 명령 종류결정
		my($kind) = ($HcommandKind == $HcomAutoForestry) ? 1 : 0;
		my($i) = 0;
		my($j) = 0;
		while(($j < $HpointNumber) && ($i < $HcommandMax)) {
			my($x) = $Hrpx[$j];
			my($y) = $Hrpy[$j];
			if (($land->[$x][$y] == $HlandForest) && ($landValue->[$x][$y]> $HcommandArg * 2)) {
				if($kind) {
					slideBack($command, $HcommandPlanNumber);
					$command->[$HcommandPlanNumber] = {
						'kind' => $HcomPlant,
						'target' => 0,
						'x' => $x,
						'y' => $y,
						'arg' => 0
					};
					$i++;
				}
				slideBack($command, $HcommandPlanNumber);
				$command->[$HcommandPlanNumber] = {
					'kind' => $HcomSellTree,
					'target' => 0,
					'x' => $x,
					'y' => $y,
					'arg' => 0
				};
				$i++;
			}
			$j++;
		}
		tempCommandAdd();
	} elsif($HcommandKind == $HcomAutoDelete) {
		# 전체 삭제
		my($i);
		for($i = 0; $i < $HcommandMax; $i++) {
			slideFront($command, $HcommandPlanNumber);
		}
		tempCommandDelete();
	} else {
		if($HcommandMode eq 'insert') {
			slideBack($command, $HcommandPlanNumber);
		}
		tempCommandAdd();
		# 명령을 등록
		$command->[$HcommandPlanNumber] = {
			'kind' => $HcommandKind,
			'target' => $HcommandTarget,
			'x' => $HcommandX,
			'y' => $HcommandY,
			'arg' => $HcommandArg
		};
	}

	$HcommandPlanNumber++ if ($HcommandPlanNumber + 1 < $HcommandMax);

	# 데이터 쓰기
	writeIslandsFile($HcurrentID);

	# owner mode 로
	ownerMain();

}

#----------------------------------------------------------------------
# 코멘트입력 모드
#----------------------------------------------------------------------
# 메인
sub commentMain {
	# id에서 섬을 가져옴
	$HcurrentNumber = $HidToNumber{$HcurrentID};
	my($island) = $Hislands[$HcurrentNumber];
	$HcurrentName = islandName($island);

	# 비밀번호
	if(!checkPassword($island,$HinputPassword)) {
		# password 오류
		unlock();
		tempWrongPassword();
		return;
	}

	# 메시지를 갱신
	$island->{'comment'} = htmlEscape($Hmessage);

	# 데이터 쓰기
	writeIslandsFile($HcurrentID);

	# 코멘트갱신 메시지
	tempComment();

	# owner mode 로
	ownerMain();
}

#----------------------------------------------------------------------
# toto 입력 모드
#----------------------------------------------------------------------
# 메인
sub totoInputMain {
	my($num) = @_;

	# id에서 섬을 가져옴
	$HcurrentNumber = $HidToNumber{$HcurrentID};
	my($island) = $Hislands[$HcurrentNumber];

	if(($HislandTurn % 100)>= 75) {
		unlock();
		tempTotoend();
		return;
	}

	# 비밀번호
	if(!checkPassword($island,$HinputPassword)) {
		# password 오류
		unlock();
		tempWrongPassword();
		return;
	}

	# 메시지를 갱신
	$island->{'totoyoso'}->[$num] = htmlEscape($HyosoMessage[$num]);
	# 데이터 쓰기
	writeIslandsFile($HcurrentID);

	# 코멘트갱신 메시지
	tempToto();

	# owner mode 로
	ownerMain();
}

sub shutoMain {

	# id에서 섬을 가져옴
	$HcurrentNumber = $HidToNumber{$HcurrentID};
	my($island) = $Hislands[$HcurrentNumber];

	# 비밀번호
	if(!checkPassword($island,$HinputPassword)) {
		# password 오류
		unlock();
		tempWrongPassword();
		return;
	}

	if($HshutoMessage == 555) {
		tempShutoWrong();
	} else {
		# 메시지를 갱신
		$island->{'shutomessage'} = htmlEscape($HshutoMessage);

		# 데이터 쓰기
		writeIslandsFile($HcurrentID);

		# 코멘트갱신 메시지
		tempShuto();
	}
	# owner mode 로
	ownerMain();
}

#----------------------------------------------------------------------
# 섬 지도
#----------------------------------------------------------------------

# 정보의 표시
sub islandInfo {
	my($mode) = @_;

	my($island) = $Hislands[$HcurrentNumber];
	# 정보 표시
	my($rank) = $HcurrentNumber + 1 - $HbfieldNumber;
	my($farm) = $island->{'farm'};
	my($factory) = $island->{'factory'};
	my($mountain) = $island->{'mountain'};
	my($pts) = $island->{'pts'};
	my($rena, $renae);
	$rena = $island->{'rena'};
	$renae = int($rena / 10 ) + 1;
	my($unemployed);
	$unemployed = ($island->{'pop'} - ($farm + $factory + $mountain) * 10) / $island->{'pop'} * 100 if($island->{'pop'});
	$unemployed = '<span class="'. ($unemployed < 0 ? 'unemploy1' : 'unemploy2'). '">'. sprintf("%.2f%%", $unemployed). '</font>' if($island->{'pop'});
	$farm = ($farm == 0) ? "보유하지 않음" : "${farm}0$HunitPop";
	$factory = ($factory == 0) ? "보유하지 않음" : "${factory}0$HunitPop";
	$mountain = ($mountain == 0) ? "보유하지 않음" : "${mountain}0$HunitPop";
	$pts = ($pts == 0) ? "0pts." : "${pts}pts.";
	$monsterlive = $island->{'monsterlive'};
	$monsm = ($monsterlive == 0) ? "" : "${monsterlive}$HunitMonster 출현안!!";

	my($mStr1) = '';
	my($mStr2) = '';
	if(($HhideMoneyMode == 1) || ($HmainMode eq 'owner') || ($island->{'id'}> 100)) {
		# 무조건또는 owner 모드또는 BattleField
		$mStr1 = "<TH $HbgTitleCell>${HtagTH_} 자금${H_tagTH}</TH>";
		$mStr2 = "<TD $HbgInfoCell align=right>$island->{'money'}$HunitMoney</TD>";
	} elsif(($HhideMoneyMode == 2) || ($HhideMoneyMode == 3)) {
		my($mTmp) = aboutMoney($island->{'money'});

		# 1000억단위 모드
		$mStr1 = "<TH $HbgTitleCell>${HtagTH_} 자금${H_tagTH}</TH>";
		$mStr2 = "<TD $HbgInfoCell align=right>$mTmp</TD>";
	}

	my($bStr, $rStr1, $rStr2, $uStr1, $uStr2, $msStr1, $msStr2) = ('', '', '', '', '', '', '');
	if($island->{'id'} <= 100) {
		# 종합포인트와 순위
		$rStr1 = "<TH $HbgTitleCell>${HtagTH_}순위${H_tagTH}</TH><TH $HbgTitleCell>${HtagTH_}종합 Point${H_tagTH}</TH>";
		$rStr2 = "<TD $HbgNumberCell ROWSPAN=2 align=middle>${HtagNumber_}$rank${H_tagNumber}</TD><TD $HbgPoinCell align=right>${pts}</TD>";
		# 실업률
		$uStr1 = "<TH $HbgTitleCell>${HtagTH_}실업률${H_tagTH}</TH>";
		$uStr2 = "<TD $HbgInfoCell align=right>${unemployed}</TD>";
		# 발사 가능 미사일 수(보유 수)
		if($HhideMissileMode || ($HmainMode eq 'owner')) {
			# 무조건또는 owner 모드
			$msStr1 = "<TH $HbgTitleCell>${HtagTH_}미사일 수";
			$msStr2 = "<TD $HbgInfoCell align=right>$island->{'missiles'}${HunitMissile}";
			if($HhideMissileMode == 2) {
				my($mTmp) = aboutMissile($island->{'missiles'});
				# 10발단위 모드
				$msStr1 = "<TH $HbgTitleCell>${HtagTH_}미사일 수${H_tagTH}</TH>";
				$msStr2 = "<TD $HbgInfoCell align=right>${mTmp}</TD>";
			} elsif($HuseArmSupply) {
				$msStr1.= "(군사 물자)${H_tagTH}</TH>";
				$msStr2.= "($island->{'army'}개)</TD>";
			} else {
				$msStr1.= "${H_tagTH}</TH>";
				$msStr2.= "</TD>";
			}
		}
	} else {
		$bStr = "<TR><TH COLSPAN=11><FONT size='5'>${HtagTH_}Battle Field${H_tagTH}</FONT></TH></TR>";
	}

	# 남은 턴 표시
	my $prize = $island->{'prize'};
	my($prize1, $prize2) = split(/\t/, $prize);
	$prize1 =~ /([0-9]*),([0-9]*),(.*)/;
	my($flags, $monsters, $turns) = ($1, $2, $3);
	$prize = '';
	my($alt);
	while($turns =~ s/([0-9]*),//) {
		$alt.= "$1${Hprize[0]} ";
	}
	$prize.= "<IMG SRC=\"prize0.gif\" ALT=\"$alt\" TITLE=\"$alt\" WIDTH=16 HEIGHT=16> " if ($alt ne '');

	# 이름에 순위 표시 문자를 추가
	my($f) = 1;
	my($i);
	for($i = 1; $i < 10; $i++) {
		if($flags & $f) {
			$prize.= "<IMG SRC=\"prize${i}.gif\" ALT=\"${Hprize[$i]}\" TITLE=\"${Hprize[$i]}\" WIDTH=16 HEIGHT=16> ";
		}
		$f *= 2;
	}

	# 쓰러뜨린 괴수 목록
	$f = 1;
	my $hflag = 0;
	my($max) = -1;
	my($mNameList) = '';
	for($i = 0; $i < $HmonsterNumber; $i++) {
		if($monsters & $f) {
			$mNameList.= "[$HmonsterName[$i]] ";
			$max = $i;
		}
		$f *= 2;
	}
	$f = 1;
	for($i = 0; $i < $HhugeMonsterNumber; $i++) {
		if($prize2 & $f) {
			$mNameList.= "[$HhugeMonsterName[$i]] ";
			$max = $i;
			$hflag = 1;
		}
		$f *= 2;
	}
	if($max != -1) {
		my $image = ($hflag ? $HhugeMonsterImageS[$max] : $HmonsterImage[$max]);
		$prize.= "<IMG SRC=\"${image}\" ALT=\"$mNameList\" TITLE=\"$mNameList\" WIDTH=16 HEIGHT=16>$island->{'taiji'}$HunitMonster 퇴치";
	}

	# 출현 중인괴수 목록
	$f = 1;
	$hflag = 0;
	$max = -1;
	$mNameList = '';
	my($monslivetype) = $island->{'monsterlivetype'};
	my($hmonslivetype) = $island->{'hmonsterlivetype'};
	my($monsliveimg);
	for($i = 0; $i < $HmonsterNumber; $i++) {
		if($monslivetype & $f) {
			$mNameList.= "[$HmonsterName[$i]] ";
			$max = $i;
		}
		$f *= 2;
	}
	$f = 1;
	for($i = 0; $i < $HhugeMonsterNumber; $i++) {
		if($hmonslivetype & $f) {
			$mNameList.= "[$HhugeMonsterName[$i]] ";
			$max = $i;
			$hflag = 1;
		}
		$f *= 2;
	}
	if($max != -1) {
		my $image = ($hflag ? $HhugeMonsterImageS[$max] : $HmonsterImage[$max]);
		$monsliveimg = "<IMG SRC=\"${image}\" ALT=\"$mNameList\" TITLE=\"$mNameList\" WIDTH=16 HEIGHT=16> ";
	}

	# 인공위성
	my($me_sat) = "";
	my($kind);
	my $emp = 0;
	for($i = 1; $i < 7; $i++) {
		$kind = 'eis'. $i;
		$me_sat.= "<IMG SRC=\"$HeiseiImage[$i]\" ALT=\"$HeiseiName[$i]\" TITLE=\"$HeiseiName[$i]\" WIDTH=16 HEIGHT=\"16\">$island->{$kind}%" if ($island->{$kind}>= 1);
		$emp += $island->{$kind};
	}
	$me_sat = " " if (!$emp);

	# 목장계
	my($Farmcpc) = "";
	$tare = $island->{'tare'};
	$zipro = $island->{'zipro'};
	$leje = $island->{'leje'};

	$Farmcpc.= "<IMG SRC=\"niwatori.gif\" ALT=\"닭\" TITLE=\"닭\" WIDTH=16 HEIGHT=\"16\">$tare 만 마리" if($tare);
	$Farmcpc.= "<IMG SRC=\"buta.gif\" ALT=\"돼지\" TITLE=\"돼지\" WIDTH=16 HEIGHT=\"16\">$zipro 만 두" if($zipro);
	$Farmcpc.= "<IMG SRC=\"ushi.gif\" ALT=\"우시\" TITLE=\"우시\" WIDTH=16 HEIGHT=\"16\">$leje 만 두" if($leje);
	$Farmcpc = " " if(!$tare && !$zipro && !$leje);

	# 가
	my($house) = "";
	my $eisei1 = $island->{'eisei1'};
	$pts = $island->{'pts'};
	my $hlv;
	foreach (0..9) {
		$hlv = 9 - $_;
		last if($pts> $HouseLevel[$hlv]);
	}
	my $onm = $island->{'onm'};
	my $n = ('의오두막', '의간이주택', '의주택', '의고급주택', '의저택', '의대저택', '의고급 저택', '의성', '의거성', '의황금성')[$hlv];
	my $zeikin = int($island->{'pop'} * ($hlv + 1) * $eisei1 / 100);
	my $house = "";
	$house.= "<IMG SRC=\"house${hlv}.gif\" ALT=\"$onm$n\" WIDTH=16 HEIGHT=\"16\">세율$eisei1%($zeikin$HunitMoney)" if ($eisei1);

	out(<<END);
<DIV ID='islandInfo' style="text-align:center;">
<TABLE BORDER style="margin:0 auto;">
$bStr
<TR>
$rStr1
<TH $HbgTitleCell>${HtagTH_}인구${H_tagTH}</TH>
$mStr1
<TH $HbgTitleCell>${HtagTH_}식량${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}면적${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}농장${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}직장${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}채굴장${H_tagTH}</TH>
$uStr1
<TH $HbgTitleCell>${HtagTH_}군사 기술${H_tagTH}</TH>
$msStr1
</TR>
<TR>
$rStr2
<TD $HbgInfoCell align=right>$island->{'pop'}$HunitPop</TD>
$mStr2
<TD $HbgInfoCell align=right>$island->{'food'}$HunitFood</TD>
<TD $HbgInfoCell align=right>$island->{'area'}$HunitArea</TD>
<TD $HbgInfoCell align=right>${farm}</TD>
<TD $HbgInfoCell align=right>${factory}</TD>
<TD $HbgInfoCell align=right>${mountain}</TD>
$uStr2
<TD $HbgInfoCell align=right>Lv${renae}</TD>
$msStr2
</TR>
<TR>
<TD $HbgCommentCell COLSPAN=11 align=left>${HtagtTH_}info:<font size="-1"><span class="house">$house</span>$monsliveimg<span class="monsm">$monsm</span>$Farmcpc$me_sat</font></font>
END
	my $AllyBBS = '<TABLE BORDER cellpadding=0 cellspacing=0><TR>';
	if($HallyNumber){
		my $aNo = random(100);
		$aNo *= 10;
		for ($i = 0; $i < $HallyNumber; $i++) {
			my $ally = $Hally[$i];
			my $member = $Hally[$i]->{'memberId'};
			my $flag = 1;
			foreach (@$member) {
				if($island->{'id'} == $_) {
					$flag = 0;
					last;
				}
			}
			next if($flag);
			my $allyId = $Hally[$i]->{'id'};
			my $cpass = $ally->{'password'};
			my $jpass = $ally->{'Takayan'};
			my $set_name = $HcurrentName;
			$set_name =~ s/<FONT COLOR=\"[\w\#]+\"><B>(.*)<\/B><\/FONT>//g;
			$set_name =~ s/<[^<]*>//g;
			$set_name =~ s/\r//g;
			my $allyName = $ally->{'name'};
			$allyName =~ s/[승자!]//g;
			$aNo += $i;
			my $campInfo = '';
			$campInfo.=<<_CAMP_ if($mode && $HarmisticeTurn);
 [<A STYlE="text-decoration:none" HREF="JavaScript:void(0)" onClick="document.allyForm${aNo}.action='${HthisFile}';document.allyForm${aNo}.submit();return false;">작전본부</A>]&nbsp;&nbsp;
_CAMP_
			$campInfo.=<<_CAMP_ if($mode);
<FORM name="allyForm$aNo" action="" method="POST">
<INPUT type=hidden name="camp" value="$allyId">
<INPUT type=hidden name="ally" value="$allyId">
<INPUT type=hidden name="cpass" value="$cpass">
<INPUT type=hidden name="jpass" value="$jpass">
<INPUT type=hidden name="id" value="$island->{'id'}">
</TD>
</FORM>
_CAMP_

			if($mode && $HallyBbs) {
				if($HarmisticeTurn) {
					$AllyBBS.=<<_BBS_;
<TD class='M'>
<FONT COLOR="$ally->{'color'}"><B>$ally->{'mark'}</B></FONT>$ally->{'name'}
 [<A STYlE="text-decoration:none" HREF="JavaScript:void(0)" onClick="document.allyForm${aNo}.action='${HbaseDir}/${HallyBbsScript}';document.allyForm${aNo}.submit();return false;">작전회의 실</A>]
${campInfo}
_BBS_
				} else {
					$AllyBBS.=<<_BBS_;
<TD class='M'>
<A STYlE="text-decoration:none" HREF="JavaScript:void(0)" onClick="document.allyForm${aNo}.action='${HbaseDir}/${HallyBbsScript}';document.allyForm${aNo}.submit();return false;">
<FONT COLOR="$ally->{'color'}"><B>$ally->{'mark'}</B></FONT>$ally->{'name'}</A>${campInfo}
_BBS_
				}
			} else {
				$AllyBBS.=<<_BBS_;
<TD class='M'>
<FONT COLOR="$ally->{'color'}"><B>$ally->{'mark'}</B></FONT>$ally->{'name'}${campInfo}
_BBS_
			}
		}
		$AllyBBS.= '</TR></TABLE>';
	}

	my $allytitle = $HarmisticeTurn ? '진영' : '동맹';
	out(<<END) if($HallyNumber);
</TD></TR><TR>
<TH $HbgTitleCell>${HtagTH_}${allytitle}${H_tagTH}</TH>
<TD $HbgInfoCell colspan=11 class='T'>${AllyBBS}
END

	out(<<END);
</TD></TR></TABLE></DIV>
END
}

# 각종확장 데이터 표시(제국의 흥망)
sub islandData {
	my(@data) = @{$Hislands[$HcurrentNumber]->{'ext'}};

	# 전 처리
	$data[1] = int($data[1] / 10);
	$data[2] = $data[2] ? "$data[2]기준" : '없음';
	$data[3] = $data[3] ? "$data[3]기준" : '없음';
	$data[4] = $data[4] ? "$data[4]00인" : '없음';
	$data[5] = $data[5] ? "$data[5]발" : '없음';
	$data[6] = $data[6] ? "$data[6]발" : '없음';
	$data[7] = $data[7] ? "$data[7]발" : '없음';
	my $monsterkill = $Hislands[$HcurrentNumber]->{'taiji'} ? "$Hislands[$HcurrentNumber]->{'taiji'}$HunitMonster" : '없음';
	my($aStr1, $aStr2) = ('', '');
	if($HallyNumber) {
		$aStr1 = "<TH $HbgTitleCell align=center>${HtagTH_}공헌도${H_tagTH}</TH>";
		$aStr2 = "<TD $HbgInfoCell align=center>$data[1]</TD>";
	}

	out(<<END);
<DIV ID='extInfo'><TABLE BORDER>
<TR>
$aStr1
<TH $HbgTitleCell align=center>${HtagTH_}방어 격파${H_tagTH}</TH>
<TH $HbgTitleCell align=center>${HtagTH_}미사일 격파${H_tagTH}</TH>
<TH $HbgTitleCell align=center>${HtagTH_}난민 구조${H_tagTH}</TH>
<TH $HbgTitleCell align=center>${HtagTH_}날아온 탄환${H_tagTH}</TH>
<TH $HbgTitleCell align=center>${HtagTH_}탄환 발사${H_tagTH}</TH>
<TH $HbgTitleCell align=center>${HtagTH_}탄환 방어${H_tagTH}</TH>
<TH $HbgTitleCell align=center>${HtagTH_}퇴치 수${H_tagTH}</TH>
</TR>
<TR>
$aStr2
<TD $HbgInfoCell align=center>$data[2]</TD>
<TD $HbgInfoCell align=center>$data[3]</TD>
<TD $HbgInfoCell align=center>$data[4]</TD>
<TD $HbgInfoCell align=center>$data[5]</TD>
<TD $HbgInfoCell align=center>$data[6]</TD>
<TD $HbgInfoCell align=center>$data[7]</TD>
<TD $HbgInfoCell align=center>$monsterkill</TD>
</TR>
</TABLE></DIV>
END
}
#----------------------------------------------------------------------
# 지도 표시
#----------------------------------------------------------------------
# $mode 이1이면, 미사일 기지등을 그대로 표시
# $jsmode 이1이면,JS 모드
sub islandMap {
	my($mode, $jsmode) = @_;
	my($island);
	$island = $Hislands[$HcurrentNumber];

	out(<<END);
<DIV ID='islandMap'><TABLE BORDER><TR><TD>
END
	# 지형, 지형 값을 가져옴
	my($land) = $island->{'land'};
	my($landValue) = $island->{'landValue'};
	my($l, $lv);

	local($onm) = $island->{'onm'};
	local($hlv);
	foreach (0..9) {
		$hlv = 9 - $_;
		last if($island->{'pts'}> $HouseLevel[$hlv]);
	}
	local($onm) = $island->{'onm'};
	local($shutomessage) = $island->{'shutomessage'};
	local($eis1) = $island->{'eis1'};
	local($eis2) = $island->{'eis2'};
	local($eis3) = $island->{'eis3'};
	local($eis5) = $island->{'eis5'};
	local($area) = $island->{'area'};
	local($fore) = $island->{'fore'};
	local($pop) = $island->{'pop'};
	local $mikomi = int($pop * 3 * 11 / 500);
	local($mshp, $msap, $msdp, $mssp, $mswin, $msexe, $tet) = split(/,/, $island->{'eisei5'});
	local($sto, $std, $stk, $stwin, $stdrow, $stlose, $stwint, $stdrowt, $stloset, $styusho, $stshoka) = split(/,/, $island->{'eisei4'});
	local $kachiten = $stwin*3 + $stdrow;
	local $nn = ('연습안', '예선 제1전투 대기치', '예선 제2전투 대기치', '예선 제3전투 대기치', '예선 제4전투 대기치', '예선종료대기치',	'준준결승전대기치', '준결승전대기치', '결승전대기치',
			'우승!', '연습안', '예선 탈락', '준준결승', '준결승', '제2위')[$stshoka];
 $nn = '연습안' if($nn eq '');

	# 명령 가져오기
	my($command) = $island->{'command'};
	my($com, @comStr, $i, $cKind);
	if($HmainMode eq 'owner') {
		for($i = 0; $i < $HcommandMax; $i++) {
			my($j) = $i + 1;
			$com = $command->[$i];
			$cKind = $com->{'kind'};
			if(($cKind < 31) ||
				((70 <= $cKind) && ($cKind <= 79)) ||
				((100 <= $cKind) && ($cKind <= 103))) {
				$comStr[$com->{'x'}][$com->{'y'}].= " [${j}]$HcomName[$com->{'kind'}]";
			}
		}
	}

	# 좌표(상)을 출력
	out("<nobr>");

	foreach $y (0..$islandSize) {
		out("<IMG SRC=\"land0.gif\" width=$Hms1 height=$Hms2><IMG SRC=\"space${y}.gif\" width=$Hms1 height=$Hms2>");
	}
	out("<IMG SRC=\"land0.gif\" width=$Hms1 height=$Hms2></nobr><BR>");

	# 각 지형및 줄바꿈을 출력
	my($x, $y);
	foreach $y (0..$islandSize) {
		# 짝 수행이면 번호 출력
		out("<IMG SRC=\"space${y}.gif\" width=$Hms1 height=$Hms2>") if(!($y % 2));

		# 각 지형을 출력
		foreach $x (0..$islandSize) {
			landString($land->[$x][$y], $landValue->[$x][$y], $x, $y, $mode, $comStr[$x][$y], $jsmode);
		}

		# 홀 수행이면 번호 출력
		out("<IMG SRC=\"space${y}.gif\" width=$Hms1 height=$Hms2>") if($y % 2);

		# 줄바꿈을 출력
		out("<BR>");
	}
	out("<div id='NaviView'></div>");
	out("</TD></TR></TABLE></DIV>\n");
}

sub landString {
	my($l, $lv, $x, $y, $mode, $comStr, $jsmode) = @_;
	my($point) = "($x,$y)";
	my($image, $alt);
	my $rt = "\n";
	my($naviTitle);
	my($naviText);
	my($naviExp) = "''";

	if($l == $HlandSea) {

		if($lv) {
			# 얕은 바다
			$image = 'land14.gif';
			$alt = '바다(얕은 바다)';
			$naviTitle = '얕은 바다';
		} else {
			# 바다
			$image = 'land0.gif';
			$alt = '바다';
			$naviTitle = '바다';
		}
	} elsif($l == $HlandWaste) {
		# 황무지
		if($lv) {
			$image = 'land13.gif'; # 착탄 지점
		} else {
			$image = 'land1.gif';
		}
		$alt = '황무지';
		$naviTitle = '황무지';
	} elsif($l == $HlandPlains) {
		# 평지
		$image = 'land2.gif';
		$alt = '평지';
		$naviTitle = '평지';
	} elsif($l == $HlandForest) {
		# 숲
		$image = 'land6.gif';
		$alt = '숲';
		# 관광객에게는 목장 수를 숨김
		$alt.= "(${lv}$HunitTree)" if($mode == 1);
		$naviTitle = '숲';
	} elsif($l == $HlandTown) {
		# 읍
		my($p, $n);
		if($lv < 30) {
			$p = 3;
			$n = '마을';
		} elsif($lv < 100) {
			$p = 4;
			$n = '읍';
		} else {
			$p = 5;
			$n = '도시';
		}

		$image = "land${p}.gif";
		$alt = "$n(${lv}$HunitPop)";
		$naviTitle = $n;
		$naviText = "${lv}${HunitPop}";
	} elsif($l == $HlandProcity) {
		# 읍
		my $c = '방재 도시랭크';
		if($lv < 110) {
			$c.= 'E';
		} elsif($lv < 130) {
			$c.= 'D';
		} elsif($lv < 160) {
			$c.= 'C';
		} elsif($lv < 200) {
			$c.= 'B';
		} else {
			$c.= 'A';
		}

		$image = "land26.gif";
		$alt = "$c(${lv}$HunitPop)";
		$naviTitle = $c;
		$naviText = "${lv}${HunitPop}";
	} elsif($l == $HlandCollege) {
		# 대학
		my($p, $n);
		if($lv == 0) {
			$p = 34;
			$n = '농업대학';
		} elsif($lv == 1) {
			$p = 35;
			$n = '공업대학';
		} elsif($lv == 2) {
			$p = 36;
			$n = '종합대학';
		} elsif($lv == 3) {
			$p = 37;
			$n = '군사대학';
		} elsif($lv == 4) {
			$p = 44;
			$n = "생물 대학 (대기)$rt HP:$mshp AP:$msap DP:$msdp SP:${mssp}$rt $mswin 마리 격파 / 경험치$msexe";
		} elsif($lv == 96) {
			$p = 44;
			$n = "생물 대학 (출입 금지)$rt HP:$mshp AP:$msap DP:$msdp SP:${mssp}$rt $mswin 마리 격파 / 경험치$msexe";
		} elsif($lv == 98) {
			$p = 48;
			$n = "생물 대학 (대기)$rt HP:$mshp AP:$msap DP:$msdp SP:${mssp}$rt $mswin 마리 격파 / 경험치$msexe";
		} elsif($lv == 97) {
			$p = 48;
			$n = "생물 대학 (출입 금지)$rt HP:$mshp AP:$msap DP:$msdp SP:${mssp}$rt $mswin 마리 격파 / 경험치$msexe";
		} elsif($lv == 99) {
			$p = 47;
			$n = '생물 대학 (출동안)';
		} else {
			$p = 46;
			$n = '기상대학';
		}

		$image = "land${p}.gif";
		$alt = "$n";
		$naviTitle = (split(' ',$n))[0];
	} elsif($l == $HlandKyujokai) {
		# 야구장
		$image = 'land23.gif';
		$alt = "다목적경기장$rt 선수$nn$rt 공격($sto) 수비($std)KP($stk)$rt 팀성적 승점$kachiten / $stwin 승$stlose 패$stdrow 분$rt / 통산$stwint 승$stloset 패$stdrowt 분 / 우승$styusho 회)";
		$naviTitle = '다목적경기장';
		$naviText = "선수$nn<br> 공격($sto) 수비($std)KP($stk)<br> 팀성적 승점$kachiten / $stwin 승$stlose 패$stdrow 분<br> / 통산$stwint 승$stloset 패$stdrowt 분 / 우승$styusho 회)";
	} elsif($l == $HlandFarm) {
		# 농장
		$image = 'land7.gif';
		$alt = "농장(${lv}0${HunitPop}규모)";
		$naviTitle = '농장';
		$naviText = "${lv}0${HunitPop}규모";
	} elsif($l == $HlandFoodim) {
		# 연구장소
		my($f);
		if($lv < 480) {
			$f = '식품 연구소';
		} else {
			$f = '방재형식품 연구소';
		}
		$image = "land25.gif";
		$alt = "$f(농장 환산${lv}0${HunitPop}규모)";
		$naviTitle = $f;
		$naviText = "농장 환산${lv}0${HunitPop}규모";
	} elsif($l == $HlandFarmchi) {
		$works = $lv;
		$image = 'land31.gif';
		$alt = "양계장(${lv}만 마리/생산력${works}$HunitFood)";
		$naviTitle = '양계장';
		$naviText = "${lv}만 마리<br>생산력${works}$HunitFood";
	} elsif($l == $HlandFarmpic) {
		$works = $lv*2;
		$image = 'land32.gif';
		$alt = "양돈장(${lv}만 두/생산력${works}$HunitFood)";
		$naviTitle = '양돈장';
		$naviText = "${lv}만 두<br>생산력${works}$HunitFood";
	} elsif($l == $HlandFarmcow) {
		$works = $lv*3;
		$image = 'land33.gif';
		$alt = "목장(${lv}만 두/생산력${works}$HunitFood)";
		$naviTitle = '목장';
		$naviText = "${lv}만 두<br>생산력${works}$HunitFood";
	} elsif($l == $HlandFactory) {
		# 공장
		$image = 'land8.gif';
		$alt = "공장(${lv}0${HunitPop}규모)";
		$naviTitle = '공장';
		$naviText = "${lv}0${HunitPop}규모";
	} elsif($l == $HlandHTFactory) {
		# 첨단 기술 공장
		$image = 'land50.gif';
		$alt = "첨단 기술 다국적 기업(${lv}0${HunitPop}규모)";
		$naviTitle = '첨단 기술 다국적 기업';
		$naviText = "${lv}0${HunitPop}규모";
	} elsif($l == $HlandBase) {
		if($mode == 1) {
			# 미사일 기지
			my($level) = expToLevel($l, $lv);
			$image = 'land9.gif';
			$alt = "미사일 기지 (레벨 ${level}/경험치 $lv)";
		} else {
			# 관광객의 경우 숲인 척
			$image = 'land6.gif';
			$alt = '숲';
		}
		$naviTitle = '숲';
	} elsif($l == $HlandHouse) {
		# 섬주의 가
		my($n) = $onm;
		$n.= ('의오두막', '의간이주택', '의주택', '의고급주택', '의저택', '의대저택', '의고급 저택', '의성', '의거성', '의황금성')[$hlv];
		$image = "house${hlv}.gif";
		$alt = "$n";
		$naviTitle = $n;
	} elsif($l == $HlandSbase) {
		# 해저 기지
		if($mode == 1) {
			my($level) = expToLevel($l, $lv);
			$image = 'land12.gif';
			$alt = "해저 기지 (레벨 ${level}/경험치 $lv)";
		} else {
			# 관광객의 경우 바다인 척
			$image = 'land0.gif';
			$alt = '바다';
		}
		$naviTitle = '바다';
	} elsif($l == $HlandSeacity) {
		# 해저 도시
		if($mode == 1) {
			$image = 'land17.gif';
			$alt = "해저 도시(${lv}$HunitPop)";
		} else {
			# 관광객의 경우 바다인 척
			$image = 'land0.gif';
			$alt = '바다';
		}
		$naviTitle = '바다';
	} elsif($l == $HlandFrocity) {
		# 해상 도시
		$image = 'land39.gif';
		$alt = "해상 도시 메가플로트(${lv}$HunitPop)";
		$naviTitle = '해상 도시 메가플로트';
		$naviText = "${lv}${HunitPop}";
	} elsif($l == $HlandMinato) {
		# 항구
		$image = 'land21.gif';
		$alt = "항구 도시(${lv}$HunitPop)";
		$naviTitle = '항구 도시';
		$naviText = "${lv}${HunitPop}";
	} elsif($l == $HlandOnsen) {
		# 온천
		$image = 'land40.gif';
		$alt = "온천거리(${lv}$HunitPop)";
		$naviTitle = '온천거리';
		$naviText = "${lv}${HunitPop}";
	} elsif($l == $HlandSunahama) {
		# 해변
		$image = 'land38.gif';
		$alt = '해변';
		$naviTitle = '해변';
	} elsif($l == $HlandDefence) {
		# 방위 시설
		$image = 'land10.gif';
		$alt = '방위 시설';
		$naviTitle = '방위 시설';
	} elsif($l == $HlandHaribote) {
		# 가짜 시설
		$image = 'land10.gif';
		if($mode == 1) {
			$alt = '가짜 시설';
		} else {
			# 관광객에게는 방위 시설처럼 표시
			$alt = '방위 시설';
		}
		$naviTitle = '방위 시설';
	} elsif($l == $HlandNursery) {
		# 양식장
		$image = 'nursery.gif';
		$alt = "양식장(${lv}0${HunitPop}규모)";
		$naviTitle = '양식장';
		$naviText = "${lv}0${HunitPop}규모";
	} elsif($l == $HlandMine) {
		if($mode == 1) {
			# 지뢰
			$image = 'land22.gif';
			$alt = "지뢰(피해$lv)";
		} else {
			# 관광객의 경우 숲인 척
			$image = 'land6.gif';
			$alt = '숲';
		}
		$naviTitle = '숲';
	} elsif($l == $HlandIce) {
		if($lv> 0) {
			$image = 'land42.gif';
			$alt = "천그럼스케이트장(종업원${lv}0${HunitPop})";
			$naviTitle = '천그럼스케이트장';
			$naviText = "종업원${lv}0${HunitPop}";
		} else {
			$image = 'land41.gif';
			$alt = '빙하';
			$naviTitle = '빙하';
		}
	} elsif($l == $HlandOil) {
		# 해저 유전
		$image = 'land16.gif';
		$alt = '해저 유전';
		$naviTitle = '해저 유전';
	} elsif($l == $HlandShrine) {
		# 시간의 신전
		$image = 'shrine.gif';
		$alt = "시간의 신전";
		$alt.= "(턴${lv})" if($lv> 0);
		$naviTitle = '시간의 신전';
		$naviText = "턴${lv}" if($lv> 0);
	} elsif($l == $HlandGold) {
		# 금광산
		$image = 'land15.gif';
		$alt = "금광산(채굴장${lv}0${HunitPop}규모)";
		$naviTitle = '금광산';
		$naviText = "채굴장${lv}0${HunitPop}규모";
	} elsif($l == $HlandMountain) {
		# 산
		my($str);
		$str = '';
		if($lv> 0) {
			$image = 'land15.gif';
			$alt = "산(채굴장${lv}0${HunitPop}규모)";
			$naviText = "채굴장${lv}0${HunitPop}규모";
		} else {
			$image = 'land11.gif';
			$alt = '산';
		}
		$naviTitle = '산';
	} elsif($l == $HlandMonument) {
		# 기념비
		$image = $HmonumentImage[$lv];
		$alt = $HmonumentName[$lv];
		$naviTitle = $alt;
	} elsif($l == $HlandFune) {
		# fune
		$image = $HfuneImage[$lv];
		$alt = $HfuneName[$lv];
		$naviTitle = $alt;
		$naviExp = "\'SHIP$lv\'";
	} elsif($l == $HlandMonster) {
		# 괴수
		my($kind, $name, $hp) = monsterSpec($lv);
		my($special) = $HmonsterSpecial[$kind];
		$image = $HmonsterImage[$kind];

		# 경화 중?
		if((($special == 3) && ($HislandTurn % 2)) ||
		 (($special == 8) && !(seqnum($HislandTurn) % 2)) ||
		 (($special == 4) && !($HislandTurn % 2))) {
			# 경화 중
			$image = $HmonsterImage2[$kind];
		}
		$alt = "$name(체력${hp})";
		$naviTitle = $name;
		$naviText = "체력${hp}";
		$naviExp = "\'MONSTER$kind\'";
	} elsif($l == $HlandHugeMonster) {
		# 거대괴수
		my($kind, $sea, $huge, $name, $hp) = hugeMonsterSpec($lv);
		my($special) = $HhugeMonsterSpecial[$kind];

		if($sea < 2) {
			$image = $HhugeMonsterImage3[$kind][$huge];
		} else {
			$image = $HhugeMonsterImage[$kind][$huge];
		}
		# 경화 중?
		if((($special == 3) && ($HislandTurn % 2)) ||
		 (($special == 8) && !(seqnum($HislandTurn) % 2)) ||
		 (($special == 4) && !($HislandTurn % 2))) {
			if($sea < 2) {
				$image = $HhugeMonsterImage4[$kind][$huge];
			} else {
				$image = $HhugeMonsterImage2[$kind][$huge];
			}
		}
		$alt = "$name(체력${hp})";
		$naviTitle = $name;
		$naviText = "체력${hp}";
#		$naviExp = "\'MONSTER$kind\'";
	} elsif($l == $HlandPark) {
		# 놀이공원
		$image = 'land19.gif';
		$alt = "놀이공원(종업원${lv}0${HunitPop}/수익전망${mikomi}$HunitMoney 이상)";
		$naviTitle = '놀이공원';
		$naviText = "종업원${lv}0${HunitPop}<br>수익전망${mikomi}$HunitMoney 이상";
	} elsif($l == $HlandKyujo) {
		# 야구장
		$image = 'land23.gif';
		$alt = '야구장';
		$naviTitle = '야구장';
	} elsif($l == $HlandUmiamu) {
		# 해상 시설
		$image = 'land24.gif';
		$alt = "해상 시설(종업원${lv}0${HunitPop})";
		$naviTitle = '해상 시설';
		$naviText = "종업원${lv}0${HunitPop}";
	} elsif($l == $HlandSeki) {
		# 관문
		$image = 'land27.gif';
		$alt = '관문';
		$naviTitle = '관문';
	} elsif($l == $HlandRottenSea) {
		# 오염된 바다
		$image = 'land20.gif';
		$alt = '오염된 바다';
		$naviTitle = '오염된 바다';
	} elsif($l == $HlandNewtown) {
		# 뉴타운
		my $nwork = int($lv/15);
		$image = 'land28.gif';
		$alt = "뉴타운(${lv}$HunitPop/직장${nwork}0$HunitPop)";
		$naviTitle = '뉴타운';
		$naviText = "${lv}$HunitPop<br>직장${nwork}0$HunitPop";
	} elsif($l == $HlandBigtown) {
		# 현대 도시
		my $mwork = int($lv/20);
		my $lwork = int($lv/30);
		$image = 'land29.gif';
		$alt = "현대 도시(${lv}$HunitPop/직장${mwork}0$HunitPop/농장${lwork}0$HunitPop)";
		$naviTitle = '현대 도시';
		$naviText = "${lv}$HunitPop<br>직장${mwork}0$HunitPop<br>농장${lwork}0$HunitPop";
	} elsif($l == $HlandRizort) {
		# 리조트지
		my $rwork = $lv+$eis1+$eis2+$eis3+$eis5+int($fore/10)+int($rena/10)-$monsterlive*100;
		$image = 'land43.gif';
		$alt = "리조트지(체류 관광객${lv}$HunitPop/수익전망${rwork}$HunitMoney)";
		$naviTitle = '리조트지';
		$naviText = "체류 관광객${lv}$HunitPop<br>수익전망${rwork}$HunitMoney";
	} elsif($l == $HlandBigRizort) {
		# 리조트지
		$image = 'land49.gif';
		$alt = "임시 해변 리조트 호텔(체류 관광객${lv}$HunitPop)";
		$naviTitle = '임시 해변 리조트 호텔';
		$naviText = "체류 관광객${lv}$HunitPop";
	} elsif($l == $HlandShuto) {
		# 수도
		$image = 'land29.gif';
		$alt = "수도$shutomessage(${lv}$HunitPop)";
		$naviTitle = "수도$shutomessage";
		$naviText = "${lv}$HunitPop";
	} elsif($l == $HlandUmishuto) {
		# 바다 수도
		if($mode == 0) {
			# 관광객의 경우 바다인 척
			$image = 'land0.gif';
			$alt = '바다';
		} else {
			$image = 'land30.gif';
			$alt = "해저 수도$totoyoso2(${lv}$HunitPop)";
		}
		$naviTitle = '바다';
	} elsif($l == $HlandBettown) {
		# 휘하기 도시
		$image = 'land45.gif';
		$alt = "휘하기 도시(${lv}$HunitPop)";
		$naviTitle = '휘하기 도시';
		$naviText = "${lv}$HunitPop";
	} elsif($l == $HlandSeatown) {
		# 해저 신도시
		if($mode == 1) {
			my $owork = int($lv/40);
			$image = 'land30.gif';
			$alt = "해저 신도시(${lv}$HunitPop/직장${owork}0$HunitPop/농장${owork}0$HunitPop)";
		} else {
			# 관광객의 경우 바다인 척
			$image = 'land0.gif';
			$alt = '바다';
		}
		$naviTitle = '바다';
	}

	my $alt1 = $alt;
	$alt1 =~ s/$rt//g;
	if($jsmode) {
		out(qq|<A HREF="JavaScript:void(0);" onclick="ps($x,$y);set_land($x, $y, '$point\\n $alt1', '$image');" |);
		if($mode == 1 && $HmainMode ne 'landmap') {
			out(qq|onMouseOver="set_com($x, $y, '$point $alt1');status = '$point $alt1 $comStr'; return true;" onMouseOut="not_com();status = '';">|);
		}elsif($HmainMode eq 'landmap') {
			out(qq|onMouseOver="status = '$point $alt1 $comStr'; return true;" onMouseOut="status = '';">|);
		}
		out("<IMG SRC=\"$image\" TITLE=\"$point $alt $comStr\" width=$Hms2 height=$Hms2 BORDER=0></A>");
	} else {
		if($mode == 1) {
			# 개발 화면일 경우 좌표 설정
			out("<A HREF=\"JavaScript:void(0);\" onclick=\"ps($x,$y)\" ");
			out(qq#onMouseOver="status = '$point $alt1 $comStr'; return true;" onMouseOut="status = '';">#);
			out("<IMG SRC=\"$image\" TITLE=\"$point $alt $comStr\" width=$Hms2 height=$Hms2 BORDER=0>");
		} else {
			out("<A HREF=\"JavaScript:void(0);\" onMouseOver=\"Navi($x, $y,'$image', '$naviTitle', '$naviText', $naviExp);\" onMouseOut=\"NaviClose(); return false\">");
#			out("<A HREF=\"JavaScript:void(0);\" onMouseOver=\"Navi($x, $y,'$image', '$naviTitle', '$naviText', $naviExp); status = '$point $alt1 $comStr'; return true;\" onMouseOut=\"NaviClose(); status = ''; return false\">");
			out("<IMG SRC=\"$image\" width=$Hms2 height=$Hms2 BORDER=0>");
		}
		# 좌표 설정닫기지
		out("</A>");
	}
}


#----------------------------------------------------------------------
# 템플릿기타
#----------------------------------------------------------------------
# 개별 로그 표시
sub logPrintLocal {
	my($mode) = @_;
	my($i);
	for($i = 0; $i < $HlogMax; $i++) {
		logFilePrint($i, $HcurrentID, $mode);
	}
}

# ○○섬으로 수 있도록 말로!!
sub tempPrintIslandHead {

	out(<<END);
<CENTER>
${HtagBig_}${HtagName_}'${HcurrentName}'${H_tagName}되도록!!${H_tagBig}<BR>
$HtempBack<BR>
</CENTER>
<SCRIPT Language="JavaScript">
<!--
MONSTER0 = "인공괴수";
MONSTER1 = "";
MONSTER2 = " 홀 수 턴은 경화";
MONSTER3 = " 미사일 무효화(50%)";
MONSTER4 = " 최대 2칸 이동";
MONSTER5 = " 최대 몇 칸 이동하는지 불명";
MONSTER6 = " 짝 수 턴은 경화";
MONSTER7 = "";
MONSTER8 = " 오염된 바다를 발생시킴<br> 최대 2칸 이동";
MONSTER9 = " 무작위 경화";
MONSTER10 = " 미사일 무효화(50%)";
MONSTER11 = " 이동했습니다 때에90%로 분열";
MONSTER12 = " 최대 몇 칸 이동하는지 불명";
MONSTER13 = " 공격, 미사일 무효화(90%)<br> 충격파로 주변 2hex 괴멸<br> 행복(역대)";
MONSTER14 = " 미사일 흡수(40%)<br> 무작위 경화<br> 주변 1hex에슬라임 분열";
MONSTER15 = " 미사일 무효화(50%)<br> 무작위 경화<br> 도움 괴수를 호출";
MONSTER16 = " 미사일 무효화(50%)<br> 충격파로 주변 1hex 괴멸<br> 자폭";
MONSTER17 = " 요격 미사일 발사(40~90%)<br> 미사일 발사(60%)<br> 다탄두 미사일 발사(40%)<br> 아토믹☆봄 발사(20%)<br> 최대 몇 칸 이동하는지 불명";
MONSTER18 = " 미사일 무효화(60%~)<br> 벌목(60%)<br> 해일(60%)<br> 충격파로 주변 2hex 괴멸";
MONSTER19 = " 메테오, 퀘이크<br> 드레인, 소환<br> 다른 섬에도 영향을 줍니다";
MONSTER20 = " 미사일 무효화(80%)<br> 부패(20%)<br> 리미터 해제(HP>13)<br> 자연 치유(턴+2)<br> 충격파로 주변 1hex 괴멸";
MONSTER21 = " 미사일 무효화(70%)<br> 대공황(15%), 부패(20%)<br> 역병(50%)<br> 자연 치유(턴+3)";
MONSTER22 = " 미사일 무효화(75%)<br> 아이스 스톰(주변 1hex)<br> 아이시클 애로우(괴수, 미사일 기지, 방위 시설, 선박, 유전)";
MONSTER23 = "";
MONSTER24 = "";
MONSTER25 = "";
MONSTER26 = "";
MONSTER27 = "";
MONSTER28 = "";
MONSTER29 = " 다른괴수를 공격<br> 페와 전용";
MONSTER30 = " 한 번에거대나력을 손에했습니다위함에인식각성하고 있는 테트라";

SHIP0 = "[유지비] 5${HunitMoney}<br>[수확] 매 턴290${HunitFood}~320${HunitFood}";
SHIP1 = "[유지비] 5${HunitMoney}<br>[수확] 매 턴290${HunitFood}~320${HunitFood}";
SHIP2 = "[유지비] 20${HunitMoney}<br>[수확] 매 턴490${HunitFood}~530${HunitFood}";
SHIP3 = "[유지비] 300${HunitMoney}<br>[발견확률] 유전(2%)<br> 보물(0.5%:Max50000${HunitMoney})";
SHIP4 = "[유지 식량] 1000${HunitFood}<br>[수입] 매 턴150${HunitMoney}~400${HunitMoney}";
SHIP5 = "[유지비] 60${HunitMoney}<br>[수확] 매 턴690${HunitFood}~730${HunitFood}";
SHIP6 = "[유지비] 30${HunitMoney}/1hex 이동<br>[수입] 매 턴490${HunitFood}~530${HunitFood}/1hex 이동";
SHIP7 = "[유지비] 500${HunitMoney}<br>[발견확률] 유전(4%)<br> 보물(1%:Max100500${HunitMoney})";
SHIP8 = "[유지 식량] 3000${HunitFood}<br>[수입] 매 턴(1500 + 인구/1000)${HunitMoney}<br>[얼음 산격렬돌진확률] 10%";
SHIP9 = "[유지비] 100${HunitMoney}<br>[괴수를 시작동 공격] SPP 미사일100${HunitMoney}/1발";
SHIP10 = "[유지비] 400${HunitMoney}<br>[괴수를 즉사] 많음단계머리 미사일3000${HunitMoney}/1발";
SHIP11 = "[유지비] 60${HunitMoney}/1hex 이동<br>[수입] 매 턴매 턴690${HunitFood}~730${HunitFood}/1hex 이동";
SHIP19 = "[유지비] 1000${HunitMoney}<br>[괴수를 즉사] 에너지포50000${HunitMoney}/1발";

function Navi(x, y, img, title, text, exp) {
	StyElm = document.getElementById("NaviView");
	StyElm.style.visibility = "visible";
	if(x + 1> $HislandSize / 2) {
		// 왼쪽
		StyElm.style.marginLeft = (x - 5) * 32 -10;
	} else {
		// 오른쪽
		StyElm.style.marginLeft = (x + 1) * 32;
	}
	if(y + 1 == $HislandSize) {
		// 아래쪽
		StyElm.style.marginTop = (y - $HislandSize - 1.5) * 32;
	} else if(y + 1> $HislandSize / 2) {
		// 아래쪽
		StyElm.style.marginTop = (y - $islandSize) * 32;
	} else {
		// 상측
		StyElm.style.marginTop = (y - $HislandSize) * 32;
	}
	StyElm.innerHTML = "<div class='NaviTitle'>" + title + " (" + x + "," + y + ")<\\/div><table><tr><td class='M'><img class='NaviImg' src=" + img + "><\\/td><td class='M'><div class='NaviText'>" + text + "<\\/div>";
	if(exp) {
		StyElm.innerHTML += "<div class='NaviText'>" + eval(exp) + "<\\/div>";
	}
	StyElm.innerHTML += "<\\/td><\\/tr><\\/table>";
}
function NaviClose() {
	StyElm = document.getElementById("NaviView");
	StyElm.style.visibility = "hidden";
}

function ps(x, y) {
	if(opener) {
		window.opener.document.lcForm.POINTX.options[x].selected = true;
		window.opener.document.lcForm.POINTY.options[y].selected = true;
		return true;
	}
}
//-->
</SCRIPT>
END
}

# ○○섬개발계획
sub tempOwner {
	$HcurrentNumber = $HidToNumber{$HcurrentID};
	my($island) = $Hislands[$HcurrentNumber];

	out(<<END);
<CENTER>
${HtagBig_}${HtagName_}${HcurrentName}${H_tagName}개발계획${H_tagBig}<BR>
$HtempBack<BR>
</CENTER>
<SCRIPT Language="JavaScript">
<!--
function ps(x, y) {
	with (document.myForm) {
		elements[4].options[x].selected = true;
		elements[5].options[y].selected = true;
		with (elements[7]) {
			var i;
			for (i = 0; i < length; i++) {
				if (options[i].value == $HcurrentID) {
					options[i].selected = true;
					break;
				}
			}
		}
	}
	return true;
}

function ns(x) {
	document.myForm.elements[2].options[x].selected = true;
	return true;
}
function jump(theForm, j_mode) {
	var sIndex = theForm.TARGETID.selectedIndex;
	var url = theForm.TARGETID.options[sIndex].value;
	if (url != "" ) window.open("$HthisFile?IslandMap=" +url+"&JAVAMODE="+j_mode, "", "menubar=yes,toolbar=no,location=no,directories=no,status=yes,scrollbars=yes,resizable=yes,width=450,height=630");
}
//-->
</SCRIPT>
END

	islandInfo(1);

	out(<<END);
<CENTER>
<TABLE BORDER>
<TR valign=top>
<TD $HbgInputCell>
<CENTER>
<FORM name="myForm" action="$HthisFile" method=POST>
<INPUT TYPE=submit VALUE="계획 전송" NAME=CommandButton$Hislands[$HcurrentNumber]->{'id'}>
<HR>
<B> 비밀번호</B></BR>
<INPUT TYPE=password NAME=PASSWORD VALUE="$HdefaultPassword">
<HR>
<B>계획번호</B><SELECT NAME=NUMBER>
END
	# 계획번호
	my($j, $i);
	for($i = 0; $i < $HcommandMax; $i++) {
		$j = $i + 1;
		out("<OPTION VALUE=$i>$j\n");
	}

	out(<<END);
</SELECT><BR>
<HR>
<B>개발계획</B><BR>
<FONT size=-1><SELECT NAME=COMMAND></font>
END

	#명령
	my($kind, $cost, $s);
	for($i = 0; $i < $HcommandTotal; $i++) {
		$kind = $HcomList[$i];
		next if((($kind == $HcomSave)||($kind == $HcomLoad))&& !($Hislands[$HcurrentNumber]->{'shr'}));
		if($kind == $HcomHouse) {
			$cost = $island->{'pts'} * 3;
		} elsif(($kind == $HcomBettown) || ($kind == $HcomKai)) {
			$cost = $island->{'pts'};
		} else {
			$cost = $HcomCost[$kind];
		}
		if($cost == 0) {
			$cost = '무료';
		} elsif($cost < 0) {
			$cost = - $cost;
			$cost.= $HunitFood;
		} else {
			$cost.= $HunitMoney;
		}
		if($kind == $HdefaultKind) {
			$s = 'SELECTED';
		} else {
			$s = '';
		}
		out("<OPTION VALUE=$kind $s>$HcomName[$kind]($cost)\n");
	}

	out(<<END);
</SELECT>
<HR>
<B>좌표(</B>
<SELECT NAME=POINTX>

END
	foreach $i (0..$islandSize) {
		if($i == $HdefaultX) {
			out("<OPTION VALUE=$i SELECTED>$i\n");
		} else {
			out("<OPTION VALUE=$i>$i\n");
		}
	}

	out(<<END);
</SELECT>, <SELECT NAME=POINTY>
END

	foreach $i (0..$islandSize) {
		if($i == $HdefaultY) {
			out("<OPTION VALUE=$i SELECTED>$i\n");
		} else {
			out("<OPTION VALUE=$i>$i\n");
		}
	}
	out(<<END);
</SELECT><B>)</B>
<HR>
<B>수량</B><SELECT NAME=AMOUNT>
END

	# 수량
	for($i = 0; $i < 100; $i++) {
		out("<OPTION VALUE=$i>$i\n");
	}

	out(<<END);
</SELECT>
<HR>
<B>목표 ${AfterName}</B>:
<B><A HREF=JavaScript:void(0); onClick="jump(myForm, '$HjavaMode')"> 표시 </A></B><BR>
<SELECT NAME=TARGETID>
$HtargetList<BR>
</SELECT></FONT>
<HR>
<B>동작</B><BR>
<INPUT TYPE=radio NAME=COMMANDMODE VALUE=insert CHECKED>삽입
<INPUT TYPE=radio NAME=COMMANDMODE VALUE=write>덮어쓰기<BR>
<INPUT TYPE=radio NAME=COMMANDMODE VALUE=delete>삭제
<HR>
<INPUT TYPE=submit VALUE="계획 전송" NAME=CommandButton$Hislands[$HcurrentNumber]->{'id'}>

</CENTER>
</FORM>
</TD>
<TD $HbgMapCell>
END
	my $comment = $Hislands[$HcurrentNumber]->{'comment'};
	my $shutomessage = $island->{'shutomessage'};
	if ($shutomessage == 555) {
		$shutohen = "";
	} else {
		$shutohen = <<"END";
<TR>
<TH>수도 이름 변경<BR><small>(최대 ${HlengthShuto}자)</small></TH>
<TD><INPUT TYPE=text NAME=SHUTOMESSAGE SIZE=32 VALUE=$shutomessage>
<INPUT TYPE=submit VALUE="수도 이름 변경" NAME=ShutoButton$Hislands[$HcurrentNumber]->{'id'}>
</TD></TR>
<TR>
END
	}
	my $totoyoso = $Hislands[$HcurrentNumber]->{'totoyoso'}->[0];
	my $totoyoso2 = $Hislands[$HcurrentNumber]->{'totoyoso'}->[1];
	$mapsize = $totoyoso;
	if($mapsize =~ /\(mapsize\@(\d+)\)/) {
		if($1 < 1){ $Hms1 = 1;} elsif($1> 32){ $Hms1 = 32;} else { $Hms1 = $1;}
	}else{
		$Hms1 = 16;
	}
	$Hms2 = $Hms1*2;
	islandMap(1, 0); # 섬 지도, 소유자 모드
	out(<<END);
<CENTER>
<FORM action="$HthisFile" method="POST">
<B>관광하다${AfterName}</B><SELECT NAME=TARGETID>$HtargetList<BR></SELECT>
<INPUT TYPE="submit" VALUE="화면을 열기" NAME="SightButton">
</FORM>
</CENTER>
</TD>
<TD $HbgCommandCell>
END
	for($i = 0; $i < $HcommandMax; $i++) {
		tempCommand($i, $Hislands[$HcurrentNumber]->{'command'}->[$i], $Hislands[$HcurrentNumber]->{'shr'}, 1);
	}

	out(<<END);
</TD>
</TR>
</TABLE>
END
	islandData();
	out(<<END);
</CENTER>
<DIV ID='CommentBox'>
<HR>
${HtagBig_}코멘트갱신${H_tagBig}<BR>
<FORM action="$HthisFile" method="POST">
<INPUT TYPE="hidden" NAME=JAVAMODE value="$HjavaMode">
<TABLE BORDER=0>
<TR>
<TH>코멘트<BR><small>(최대 ${HlengthMessage}자)</small></TH><TD><INPUT TYPE=text NAME=MESSAGE SIZE=80 VALUE="$comment"></TD>
</TR>
<TR>
<TH> 비밀번호</TH><TD><INPUT TYPE=password NAME=PASSWORD VALUE="$HdefaultPassword">
<INPUT TYPE=submit VALUE="코멘트갱신" NAME=MessageButton$Hislands[$HcurrentNumber]->{'id'}>
</TD>
</TR>
$shutohen
<TR>
<TH>TOTO 예상(왼쪽)<BR><small>(최대 ${HlengthYoso}자)</small></TH>
<TD><INPUT TYPE=text NAME=YOSOMESSAGE SIZE=44 VALUE=$totoyoso>
<INPUT TYPE=submit VALUE="예상(왼쪽)" NAME=TotoButton$Hislands[$HcurrentNumber]->{'id'}>
</TD></TR>
<TR>
<TH>TOTO 예상(오른쪽)<BR><small>(최대 ${HlengthYoso}자)</small></TH>
<TD><INPUT TYPE=text NAME=YOSOMESSAGE2 SIZE=44 VALUE=$totoyoso2>
<INPUT TYPE=submit VALUE="예상(오른쪽)" NAME=TotosButton$Hislands[$HcurrentNumber]->{'id'}>
</TD></TR>
</TABLE>
</FORM>
</DIV>
END

}

# 입력 완료된 명령 표시
sub tempCommand {
	my($number, $command, $shr, $mode) = @_;
	my($kind, $target, $x, $y, $arg) =
		(
			$command->{'kind'},
			$command->{'target'},
			$command->{'x'},
			$command->{'y'},
			$command->{'arg'}
		);
	$HcomName[$kind] = "" if((($kind == $HcomSave)||($kind == $HcomLoad))&& !$shr);
	if($HcomName[$kind] eq "") { $HcomName[$kind] = "이 명령은 사용할 수 없습니다"; }
	my($name) = "$HtagComName_${HcomName[$kind]}$H_tagComName";
	my($point) = "$HtagName_($x,$y)$H_tagName";
	$target = islandName($Hislands[$HidToNumber{$target}]);
	if($target eq '') {
		$target = "무인";
	}
	$target = "$HtagName_${target}$H_tagName";
	my($value) = $arg * $HcomCost[$kind];
	$value = $HcomCost[$kind] if(!$value);
	if($value < 0) {
		$value = -$value;
		$value = "$value$HunitFood";
	} else {
		$value = "$value$HunitMoney";
	}
	$value = "$HtagName_$value$H_tagName";

	my($j) = sprintf("%02d:", $number + 1);

	out("<A STYlE=\"text-decoration:none\" HREF=\"JavaScript:void(0);\" onClick=\"ns($number)\">") if($mode);
	out("$HtagNumber_$j$H_tagNumber$HnormalColor_");

	if(($kind == $HcomDoNothing) ||
	 ($kind == $HcomSave) ||
	 ($kind == $HcomLoad) ||
	 ($kind == $HcomGiveup)) {
		out("$name");
	} elsif(($kind == $HcomFarm) ||
		($kind == $HcomFoodim) ||
		($kind == $HcomFactory) ||
		($kind == $HcomNursery) ||
		($kind == $HcomBoku) ||
		($kind == $HcomPark) ||
		($kind == $HcomUmiamu) ||
		($kind == $HcomMountain) ||
		($kind == $HcomKai) ||
		($kind == $HcomHTget) ||
		($kind == $HcomGivefood) ||
		($kind == $HcomPropaganda)) {
		# 횟수 포함
		if(($arg == 0) ||
		 ($arg == 1)) {
			out("$point 에서$name");
		} else {
			out("$point 에서$name($arg 회)");
		}
	} elsif(($kind == $HcomFune) ||
		($kind == $HcomFarmcpc) ||
		($kind == $HcomMonument)) {
		# 수량 포함
		if($arg == 0) {
			out("$point 에서$name");
		} else {
			out("$point 에서$name($arg)");
		}
	} elsif($kind == $HcomDestroy) {
		# 굴착
		if($arg != 0) {
			out("$point 에서$name(예산${value})");
		} else {
			out("$point 에서$name");
		}
	} elsif($kind == $HcomOnsen) {
		# 온천 굴착
		$arg = 1 if(!$arg);
		out("$point 에서$name(예산${value})");
	} elsif($kind == $HcomMine) {
		# 지뢰
		if ($arg == 0) {
			$arg = 1;
		} elsif ($arg> 9) {
			$arg = 9;
		}
		out("$point 에서$name(피해$arg)");
	} elsif($kind == $HcomArmSupply) {
		my($n) = ($arg == 0 ? $arg++ : $arg);
		out("$name($HtagName_${n}개$H_tagName)");
	} elsif(($kind == $HcomMissileNM) ||
		($kind == $HcomMissilePP) ||
		($kind == $HcomMissileSPP) ||
		($kind == $HcomMissileST) ||
		($kind == $HcomMissileSS) ||
		($kind == $HcomMissileLR) ||
		($kind == $HcomMissileLD)) {
		# 미사일계
		my($n) = ($arg == 0 ? '무제한' : "${arg}발");
		out("$target$point 로$name($HtagName_$n$H_tagName)");
	} elsif($kind == $HcomAlly) {
		# 동맹 가입·탈퇴
		out("$target 의$name");
	} elsif($kind == $HcomSendMonster) {
		# 괴수 파견
		out("$target 로$name");
	} elsif($kind == $HcomSell) {
		# 식량 수출
		out("$name$value");
	} elsif(($kind == $HcomEisei) ||
		($kind == $HcomEiseimente) ||
		($kind == $HcomEiseiAtt)) {
		if(($arg> $HeiseiNumber) ||
		 ($arg == 0)) {
			$arg = 1;
		}
		$t = $HeiseiName[$arg];
		if($kind == $HcomEisei) {
			out("$HtagComName_$t발사$H_tagComName");
		} elsif($kind == $HcomEiseimente) {
			out("$HtagComName_$t복구$H_tagComName");
		} elsif($kind == $HcomEiseiAtt) {
			out("$target 의<B>$t</B>로$name");
		}
	} elsif($kind == $HcomEiseiLzr) {
		out("$target$point 로$t$name");
	} elsif(($kind == $HcomMoney) ||
		($kind == $HcomFood)) {
		# 지원
		out("$target 로$name$value");
	} else {
		# 좌표 포함
		out("$point 에서$name");
	}

	out("$H_normalColor");
	out("</A>") if($mode);
	out("<BR>\n");
}

# 명령 삭제
sub tempCommandDelete {
	out(<<END);
${HtagBig_} 명령을 삭제했습니다${H_tagBig}<HR>
END
}

# 명령 등록
sub tempCommandAdd {
	out(<<END);
${HtagBig_} 명령을 등록했습니다${H_tagBig}<HR>
END
}

# 코멘트 변경성공
sub tempComment {
	out(<<END);
${HtagBig_}코멘트를 갱신했습니다${H_tagBig}<HR>
END
}

# toto 변경성공
sub tempToto {
	out(<<END);
${HtagBig_}예상했습니다${H_tagBig}<HR>
END
}

# toto 변경불능
sub tempTotoend {
	out(<<END);
${HtagBig_}현재, 변경할 수 없습니다${H_tagBig}<HR>$HtempBack
END
}

# shuto 변경성공
sub tempShuto {
	out(<<END);
${HtagBig_}수도 이름을 변경했습니다${H_tagBig}<HR>
END
}

# shuto 변경실패
sub tempShutoWrong {
	out(<<END);
${HtagBig_}그 수도 이름에는 변경할 수 없습니다${H_tagBig}<HR>
END
}

# 최근 상황
sub tempRecent {
	my($mode, $mode2) = @_;

	if($mode2) {
		my($enPass) = $HdefaultPassword;
		my($pass) = $mode ? "<INPUT type=hidden name=PASSWORD value=$enPass size=16 maxlength=16>" : '';
		out(<<END);
<SCRIPT Language="JavaScript">
<!--
function Recent(){
	newRecent = window.open("", "newRecent", "menubar=yes,toolbar=no,location=no,directories=no,status=no,scrollbars=yes,resizable=yes,width=800,height=300");
	document.recentForm.target = "newRecent";
//	document.recentForm.submit();
}
//-->
</SCRIPT>
<DIV ID='RecentlyLog'>
<HR>
<CENTER>
${HtagBig_}${HtagName_}${HcurrentName}${H_tagName}의 최근 상황${H_tagBig}
<FORM name="recentForm" action="${HbaseDir}/history.cgi" method="POST">
<INPUT type=hidden name="ID" value="$HcurrentID">
$pass
<INPUT type="submit" value="최근 상황을 보기" onClick="Recent()">
</FORM>
</CENTER>
</DIV>
END
	} else {
		out(<<END);
<DIV ID='RecentlyLog'>
<HR>
${HtagBig_}${HtagName_}${HcurrentName}${H_tagName}의 최근 상황${H_tagBig}<BR>
END
		logPrintLocal($mode);
		out("</DIV>");
	}
}

# 섬의 이동
sub islandJamp {
	$HtargetList = getIslandList($HcurrentID, 1);
	out(<<END);
<CENTER>
<SCRIPT LANGUAGE="JavaScript">
function jump(theForm) {
	var sIndex = theForm.urlsel.selectedIndex;
	var url = theForm.urlsel.options[sIndex].value;
	if (url != "" ) location.href = "$HthisFile?Sight=" +url;
}
</SCRIPT>
<TABLE align=center border=0>
<TR><TD>
<FORM name="urlForm">
<SELECT NAME="urlsel">
$HtargetList<BR>
</SELECT>
</TD>
<TD><input type="button" value=" GO " onClick="jump(this.form)"></TD>
</TR></TABLE>
</form>
</CENTER>
END
}

sub exLbbs {
	my($bbsID, $mode) = @_;
	my($admin, $id) = ('', '');
	if($mode == 1) {
		$mode = 'yes';
		$id = $bbsID;
		my $island = $Hislands[$HidToNumber{$bbsID}];
		my $onm = $island->{'onm'};
		$onm = "$island->{'name'}$AfterName" if($onm eq '');
		$admin =<<"END";
<INPUT type=hidden name=name value='$onm'>
<INPUT type=hidden name=title value='$island->{'name'}$AfterName 관광 게시판'>
<INPUT type=hidden name=message value='수 있도록 말로!$island->{'name'}$AfterName 관광안내장소로'>
END
	} elsif($defaultID ne '') {
		$mode = 'no';
		$id = $defaultID;
	} else {
		$mode = '';
	}

	out(<<END);
<SCRIPT Language="JavaScript">
<!--
function Exlbbs(){
	newExlbbs = window.open("", "newExlbbs", "menubar=yes,toolbar=no,location=no,directories=no,status=yes,scrollbars=yes,resizable=yes,width=600,height=300");
	document.exLbbs.target = "newExlbbs";
//	document.exLbbs.submit();
}
//-->
</SCRIPT>
<DIV ID='localBBS'>
<HR>
${HtagBig_}${HtagName_}${HcurrentName}${AfterName}${H_tagName}관광객 통신${H_tagBig}<BR>
<FORM name="exLbbs" action="${HlbbsDir}/lbbs.cgi" method=POST encType=multipart/form-data>
<INPUT type=hidden name=mode value='view'>
$admin
<INPUT type=hidden name=owner value="$mode">
<INPUT type=hidden name=logfile value="${bbsID}.cgi">
<INPUT type=hidden name=id value="$id">
<INPUT type=hidden name=pass value="$HdefaultPassword">
<INPUT type=submit value='관광 게시판의 열람·게시' onClick="Exlbbs()">
</FORM>
</DIV>
END
}

1;
