#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}
# 우라에와 -uRAniwa-: http://snow.prohosting.com/awinokah/
#----------------------------------------------------------------------
# 하코니와 제도 ver2.30
# 로컬 게시판모듈(ver1.00)
# 사용 조건과 사용 방법은 hako-readme.txt 파일을 참조해 주세요
#
# 하코니와 제도의 페이지: http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html
#----------------------------------------------------------------------

#――――――――――――――――――――――――――――――――――――
#							 하코니와 제도 2nd
#								 v1.5
#
#					 by 친분 webgame@oyoyo.ne.jp
#					http://www.oyoyo.ne.jp/webgame/
#――――――――――――――――――――――――――――――――――――

#――――――――――――――――――――――――――――――――――――
#							 하코니와 제도 바다전쟁
#								 v1.3
#
#					 by 친분 webgame@oyoyo.ne.jp
#					http://www.oyoyo.ne.jp/webgame/
#――――――――――――――――――――――――――――――――――――

#----------------------------------------------------------------------
# 로컬 게시판 모드
#----------------------------------------------------------------------
# 메인

sub localBbsMain {
	# id에서 섬 번호를 가져옴
	$HcurrentNumber = $HidToNumber{$HcurrentID};
	my($island) = $Hislands[$HcurrentNumber];
	my($speaker);

	# 헤더출력
	tempHeader() if($HjavaMode ne 'java' && $HlbbsMode < 5);

	# 왠지그 섬이 없는 경우
	if($HcurrentNumber eq '') {
		unlock();
		tempProblem();
		return;
	}

	# 삭제 모드가 아니고 이름이나 메시지가 없는 경우
	if($HlbbsMode < 2 || $HlbbsMode == 5) {
		if(($HlbbsName eq '') || ($HlbbsMessage eq '')) {
			tempHeader() if($HlbbsMode == 5);
			unlock();
			tempLbbsNoMessage();
			return;
		}
	}

	my($lbbs);
	$lbbs = $island->{'lbbs'};

	# 관광객 모드가 아닐 때는 비밀번호 확인
	if($HlbbsMode % 2 == 1) {
		if(!checkPassword($island,$HinputPassword)) {
			# password 오류
			tempHeader() if($HlbbsMode == 5 || $HlbbsMode == 7);
			unlock();
			tempWrongPassword();
			return;
		}

		# 소유자 이름을 설정
		# $HlbbsName = $island->{'owner'};
	} elsif ($HlbbsMode == 0) {
		# 관광객 모드
		my($sIsland);

		if ($HlbbsType ne 'ANON') {
			# 공개와 극비

			# id에서 섬 번호를 가져옴
			my($number) = $HidToNumber{$HspeakerID};
			$sIsland = $Hislands[$number];

			# 왠지그 섬이 없는 경우
			if($number eq '') {
				unlock();
				tempProblem();
				return;
			}

			# 비밀번호 확인
			if(!checkPassword($sIsland,$HinputPassword)) {
				# password 오류
				unlock();
				tempWrongPassword();
				return;
			}

			# 소유자 이름을 설정
			# $HlbbsName = $sIsland->{'owner'};

			# 통신비용을 지불우
			my($cost) = ($HlbbsType eq 'PUBLIC') ? $HlbbsMoneyPublic : $HlbbsMoneySecret;
			if ($sIsland->{'money'} < $cost) {
				# 비용부족
				unlock();
				tempLbbsNoMoney();
				return;
			}
			$sIsland->{'money'} -= $cost;
		}

		# 발언자를 기억하다
		if ($HlbbsType ne 'ANON') {
			# 공개와 극비
			my $name = islandName($sIsland);
			$speaker = $name. ','. $HspeakerID;
		} else {
			# 익명
			$speaker = $ENV{'REMOTE_HOST'};
			$speaker = $ENV{'REMOTE_ADDR'} if ($speaker eq '');
		}
	} elsif ($HlbbsMode == 2) {
		# 관광객 삭제 모드
		my($sIsland);

		# id에서 섬 번호를 가져옴
		my($number) = $HidToNumber{$HspeakerID};
		$sIsland = $Hislands[$number];

		# 왠지그 섬이 없는 경우
		if($number eq '') {
			unlock();
			tempProblem();
			return;
		}

		# ID 확인
		$lbbs->[$HcommandPlanNumber] =~ /[0-9]*\<.*,([0-9]*)\<[0-9]*\>.*\>.*$/;
		my $wId = $1;
		if($wId != $HspeakerID) {
			# ID 오류
			unlock();
			tempWrong("당신의 발언이 아닙니다!");
			return;
		}

		# 비밀번호 확인
		if(!checkPassword($sIsland,$HinputPassword)) {
			# password 오류
			unlock();
			tempWrongPassword();
			return;
		}
	} elsif ($HlbbsMode == 4) {
		# 관광객극비통신 확인 모드
		my($sIsland);

		# id에서 섬 번호를 가져옴
		my($number) = $HidToNumber{$HspeakerID};
		$sIsland = $Hislands[$number];

		# 왠지그 섬이 없는 경우
		if($number eq '') {
			unlock();
			tempProblem();
			return;
		}

		# 비밀번호 확인
		if(!checkPassword($sIsland,$HinputPassword)) {
			# password 오류
			unlock();
			tempWrongPassword();
			return;
		}
	}

	# 모드에서 분기
	if($HlbbsMode == 4) {
		printIslandMain();
		return;
	} elsif($HlbbsMode == 2 || $HlbbsMode == 3 || $HlbbsMode == 7) {
		# 삭제 모드
		if(($HlbbsMode == 3 || $HlbbsMode == 7) && ($HcommandPlanNumber == $HlbbsMax)) {
			foreach (0..($HlbbsMax - 1)) {
				$lbbs->[$_] = '0<<0>>';
			}
		} else {
			# 메시지를 앞으로 당기기
			slideBackLbbsMessage($lbbs, $HcommandPlanNumber);
		}
		tempLbbsDelete() if($HlbbsMode != 7);
	} else {
		# 기장 모드
		$speaker = "관리자,0" if($HlbbsMode == 5);
		if ($HlbbsType ne 'SECRET') {
			# 공개와 익명
			$speaker = "0<$speaker";
		} else {
			# 극비
			$speaker = "1<$speaker";
		}
		# 메시지를 뒤에밀기
		slideLbbsMessage($lbbs);

		# 메시지 쓰기
		my($message);
		if($HlbbsMode == 1) {
			$message = '1';
		} else {
			$message = '0';
		}
		$HlbbsName = "$HislandTurn:". htmlEscape($HlbbsName);
		$HlbbsMessage = htmlEscape($HlbbsMessage);
		$lbbs->[0] = "$speaker<$message>$HlbbsName>$HlbbsMessage";

		tempLbbsAdd() if($HlbbsMode != 5);
	}

	# 데이터 쓰기
	writeIslandsFile($HcurrentID);

	# 원래의 모드로
	if($HlbbsMode % 2 == 0) {
		printIslandMain();
	} elsif($HlbbsMode == 5 || $HlbbsMode == 7) {
		tempHeader() if($jumpTug !~ /location/);
		print $jumpTug;
		unlock();
		exit;
	} else {
		ownerMain();
	}
}

# 로컬 게시판의 메시지를 하나뒤에밀기
sub slideLbbsMessage {
	my($lbbs) = @_;
	my($i);
	pop(@$lbbs);
	unshift(@$lbbs, $lbbs->[0]);
}

# 로컬 게시판의 메시지를 하나앞으로 당기기
sub slideBackLbbsMessage {
	my($lbbs, $number) = @_;
	my($i);
	splice(@$lbbs, $number, 1);
	$lbbs->[$HlbbsMax - 1] = '0<<0>>';
}

#----------------------------------------------------------------------
# 템플릿기타
#----------------------------------------------------------------------
sub tempLbbsMain {
	my($mode) = @_;

	out("<DIV ID='localBBS'>");
	tempLbbsHead(); # 로컬 게시판
	# 작성 양식
	if($mode) {
		tempLbbsInputOW();
	} else {
		tempLbbsInput();
	}
	tempLbbsContents(); # 게시판내용
	out("</DIV>");
}

# 로컬 게시판
sub tempLbbsHead {
	out(<<END);
<HR>
${HtagBig_}${HtagName_}${HcurrentName}${H_tagName}관광객 통신${H_tagBig}<BR>
END
}

# 로컬 게시판입력 양식
sub tempLbbsInput {
	out(<<END);
<FORM action="$HthisFile" method="POST">
END
	if ($HlbbsMoneyPublic + $HlbbsMoneySecret> 0) {
		# 발언은 유료
		out("<DIV align='center'><B>참고: </B>");
		out("공개통신은<B>$HlbbsMoneyPublic$HunitMoney</B>입니다.") if ($HlbbsMoneyPublic> 0);
		out("극비통신은<B>$HlbbsMoneySecret$HunitMoney</B>입니다.") if ($HlbbsMoneySecret> 0);
		out("</DIV>");
	}
	my $col = " colspan=2" if(!$HlbbsAnon);

	# out("<B>참고: </B>${AfterName}을 보유한 분은 이름을 변경해도 소유자 이름을 사용할 수 있습니다.");

	out(<<END);
<TABLE BORDER>
<TR>
<TH>이름<small>(최대 ${HlengthLbbsName}자)</small></TH>
<TH$col>내용<small>(최대 ${HlengthLbbsMessage}자)</small></TH>
<TH>통신방법</TH>
</TR>
<TR>
<TD><INPUT TYPE="text" SIZE=32 MAXLENGTH=32 NAME="LBBSNAME" VALUE="$HdefaultName"></TD>
<TD$col><INPUT TYPE="text" SIZE=80 NAME="LBBSMESSAGE"></TD>
<TD>
<INPUT TYPE="radio" NAME="LBBSTYPE" VALUE="PUBLIC" CHECKED>공개
<INPUT TYPE="radio" NAME="LBBSTYPE" VALUE="SECRET"><span class='lbbsST'>극비</span>
</TD>
</TR>
<TR>
<TH> 비밀번호</TH>
<TH>${AfterName}이름</TH>
<TH$col>동작</TH>
</TR>
<TR>
<TD><INPUT TYPE=password SIZE=16 MAXLENGTH=16 NAME=PASSWORD VALUE="$HdefaultPassword"></TD>
<TD>
<SELECT NAME="ISLANDID2">$HislandList</SELECT>
END
	out(<<END) if ($HlbbsAnon);
<INPUT TYPE="radio" NAME="LBBSTYPE" VALUE="ANON">관광객
END

	out(<<END);
</TD>
<TD><DIV align='center'>
<INPUT TYPE="submit" VALUE="기장하다" NAME="LbbsButtonSS$HcurrentID">
<INPUT TYPE="submit" VALUE="극비 확인" NAME="LbbsButtonCK$HcurrentID">
</DIV></TD>
END
	if(!$HlbbsAnon) {
		out(<<END);
<TD align=right>
번호
<SELECT NAME=NUMBER>
END
		# 발언번호
		my($j, $i);
		for($i = 0; $i < $HlbbsMax; $i++) {
			$j = $i + 1;
			out("<OPTION VALUE=$i>$j\n");
		}
		out(<<END);
</SELECT>
<INPUT TYPE="submit" VALUE="삭제" NAME="LbbsButtonDS$HcurrentID">
</TD>
END
	}
	out(<<END);
</TR>
</TABLE>
</FORM>
END
}

# 로컬 게시판입력 양식 owner mode 용
sub tempLbbsInputOW {

	out(<<END);
<FORM action="$HthisFile" method="POST">
<INPUT TYPE="hidden" NAME=JAVAMODE VALUE="$HjavaMode">
END
	# out("<B>참고: </B>이름을 변경해도 소유자 이름을 사용할 수 있습니다.");

	out(<<END);
<TABLE BORDER>
<TR>
<TH>이름<small>(최대 ${HlengthLbbsName}자)</small></TH>
<TH COLSPAN=2>내용<small>(최대 ${HlengthLbbsMessage}자)</small></TH>
</TR>
<TR>
<TD><INPUT TYPE="text" SIZE=32 MAXLENGTH=32 NAME="LBBSNAME" VALUE="$HdefaultName"></TD>
<TD COLSPAN=2><INPUT TYPE="text" SIZE=80 NAME="LBBSMESSAGE"></TD>
</TR>
<TR>
<TH> 비밀번호</TH>
<TH COLSPAN=2>동작</TH>
</TR>
<TR>
<TD><INPUT TYPE=password SIZE=16 MAXLENGTH=16 NAME=PASSWORD VALUE="$HdefaultPassword"></TD>
<TD align=right>
<INPUT TYPE="submit" VALUE="기장하다" NAME="LbbsButtonOW$HcurrentID">
</TD>
<TD align=right>
번호
<SELECT NAME=NUMBER>
END
	# 발언번호
	my($j, $i);
	for($i = 0; $i < $HlbbsMax; $i++) {
		$j = $i + 1;
		out("<OPTION VALUE=$i>$j\n");
	}
	out("<OPTION VALUE=$HlbbsMax>전체\n");
	out(<<END);
</SELECT>
<INPUT TYPE="submit" VALUE="삭제" NAME="LbbsButtonDL$HcurrentID">
</TD>
</TR>
</TABLE>
</FORM>
END
}

# 로컬 게시판내용
sub tempLbbsContents {
	my($lbbs, $line);
	$lbbs = $Hislands[$HcurrentNumber]->{'lbbs'};
	out(<<END);
<TABLE BORDER>
<TR>
<TH>번호</TH>
<TH>기장내용</TH>
</TR>
END

	my($i);
	for($i = 0; $i < $HlbbsMax; $i++) {
		$line = $lbbs->[$i];
		if($line =~ /([0-9]*)\<(.*)\<([0-9]*)\>(.*)\>(.*)$/) {
			my($m, $iName, $os, $tan, $com) = ($1, $2, $3, $4, $5);
			$com =~ s/(http|ftp):\/\/([^\x81-\xFF\s\"\'\(\)\<\>\\\`\[\{\]\}\|]+)/<A href=\"$1:\/\/$2\">$HlbbsAutolinkSymbol<\/A>/g if($HlbbsAutolinkSymbol ne '');
			my($j) = $i + 1;
			out("<TR><TD align=center>$HtagNumber_$j$H_tagNumber</TD>");
			my($speaker);
#			$speaker = "<span class='lbbsST'><B><SMALL>($2)</SMALL></B></span>" if ($HlbbsSpeaker && ($2 ne ''));
			my($sName, $sID) = split(/,/, $iName);
			my $sNo = $HidToNumber{$sID};
			if($HlbbsSpeaker && ($sName ne '')) {
				if(defined $sNo){
					$speaker = "<span class='lbbsST'><B><SMALL>(<A STYlE=\"text-decoration:none\" HREF=\"$HthisFile?Sight=$sID\">$sName</A>)</SMALL></B></span>";
				} else {
					$speaker = "<span class='lbbsST'><B><SMALL>($sName)</SMALL></B></span>";
				}
			}
			if($os == 0) {
				# 관광객
				if ($m == 0) {
					# 공개
					if($sID ne '0') {
						out("<TD>$HtagLbbsSS_$tan> ${com}$H_tagLbbsSS $speaker</TD></TR>");
					} else {
						out("<TD><span class='lbbsAD'>$tan> ${com}</span> $speaker</TD></TR>");
					}
				} else {
					# 극비
					if (($HmainMode ne 'owner') &&(($HspeakerID eq '') || ($sID != $HspeakerID))) {
						# 관광객
						out("<TD><DIV align='center'><span class='lbbsST'>- 극비 -</span></DIV></TD></TR>");
					} else {
						# 소유자
						out("<TD><span class='lbbsST'>$tan>(비밀) ${com}</span> $speaker</TD></TR>");
					}
				}
			} else {
				# 섬주
				out("<TD>$HtagLbbsOW_$tan> ${com}$H_tagLbbsOW $speaker</TD></TR>");
			}
		}
	}

	out(<<END);
</TD></TR></TABLE>
END
}

# 로컬 게시판에서 이름이나 메시지가 없는 경우
sub tempLbbsNoMessage {
	out(<<END);
${HtagBig_}이름 또는 내용이 비어 있습니다..${H_tagBig}$HtempBack
END
}

# 쓰기/삭제
sub tempLbbsDelete {
	out(<<END);
${HtagBig_}기록 내용을 삭제했습니다.${H_tagBig}<HR>
END
}

# 명령 등록
sub tempLbbsAdd {
	out(<<END);
${HtagBig_}기록을 수행했습니다.${H_tagBig}<HR>
END
}

# 통신 자금 부족
sub tempLbbsNoMoney {
	out(<<END);
${HtagBig_} 자금 부족으로 기입할 수 없습니다.${H_tagBig}$HtempBack
END
}

1;
