#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}

# 우라에와 -uRAniwa-: http://snow.prohosting.com/awinokah/
# patchworked by neo_otacky. for 바다전쟁 JS RAJS
# lbbslist.cgi?pass=[마스터 비밀번호]로 접속하면, 게시판도 표시됩니다.
# 게시할 때의 게시 이름은 관리자 이름에서  섬 이름은'관리자'이 됩니다.
# 주!쿠키에 마스터 비밀번호가 저장되어 있는 경우 일반 접속만으로 처리됩니다!
#---------------------------------------------------------------------
#
#	궁극 구상의 하코니와 로컬 게시판을 목록 표시
#
#	작성일 : 2001/10/06 (ver0.10)
#	작성자 : 라스티아 <nayupon@mail.goo.ne.jp>
#
#	관리자가 섬 주민의 발언을 빠짐없이 목록으로 확인하기 위한 기능입니다.
#	lbbslist.cgi?pass=마스터 비밀번호 로 접속하면 극비 통신도 볼 수 있습니다.
#
#	수정이력
#	2001/10/20 V0.20 최근의 발언을 색을변해서 표시할 수 있도록 했습니다.
#	2001/12/31 V0.30 공통 설정부를 config.cgi 부터 처리포함할 수 있도록 했습니다.
#	2002/01/13 V0.31 version4대응
#	2002/02/03 V0.40 CSS 을별도 파일에서 읽어오할 수 있도록 했습니다.
#	2002/04/17 V0.41 부하 표시를 추가. 스크립트를 전체적에재검와 시.
#	2002/07/27 V0.50 극비 통신 대응. 보기 및 기타 항목 개선 등.
#	2002/10/28 V0.60 스타일시트주변을 개량
#
#---------------------------------------------------------------------
#	이 스크립트는 아래 내용을 바탕으로 작성했습니다
#
#	괴수 격퇴 포인트 + 획득 상금 순위 표시
#	작성자 : Watson <watson@catnip.freemail.ne.jp>
#---------------------------------------------------------------------
BEGIN {
	# Perl 5.004 이상이필요
	require 5.004;

########################################
	# 오류 표시
	$SIG{__WARN__} = $SIG{__DIE__} =
	sub {
		my($msg) = @_;

		$msg =~ s/\n/<br>/g;
		print STDOUT <<END;
Content-type: text/html; charset=UTF-8

<p><big><tt><b>ERROR:</b><br>$msg</tt></big></p>
END
		exit(-1);
	};
########################################
}
#---------------------------------------------------------------------
#	초기 설정
#---------------------------------------------------------------------
# 초기 설정용 파일을 읽기
require './hako-init.cgi';
require './hako-io.cgi';
require './init-game.cgi';

# 색을 변해서 표시하다 턴
$kyoutyouturn = 100;

#----------------------------
#	HTML 에 관한 설정
#----------------------------
# 브라우저의 제목막대의 명칭
$title = '관광객 통신 목록';

# 모험머리의 메시지(HTML 서식)
$headKill = <<"EOF";
<h1>$Htitle 관광객 통신 목록(관리용)</h1>
EOF

# 화면의 색상과 배경 설정(HTML)
$body = '<body bgcolor=#EEFFFF>';

# 화면의'돌아가기'링크선(URL)
$bye = $HthisFile;

#여기까지-------------------------------------------------------------

if (-e $HpasswordFile) {
	# 비밀번호 파일 있음
	open(PIN, "<$HpasswordFile") || die $!;
	chomp($HmasterPassword = <PIN>); # 마스터 비밀번호 읽기
	close(PIN);
}
&cookieInput;
&cgiInput;
my($mode) = 0;
if($HdefaultPassword ne '') {
	if(checkMasterPassword($HdefaultPassword)) {
		$mode = 1;
	} else {
		if($HskinName ne '' ){
			$baseSKIN = $HskinName;
		} else {
			$baseSKIN = "${efileDir}/$HcssFile";
		}
		&htmlHeader;
		tempWrongPassword(); # 비밀번호 불일치
		&htmlFooter;
		exit(0);
	}
}
my $bye2 = (!$mode) ? '' : "[<A HREF=\"$HmenteFile?ADMIN=$HdefaultPassword\">점검로</A>] ";

if(!(&readIslandsFile(-1))){
	&htmlHeader;
	&htmlError;
} else {
	&htmlHeader;
	if($HmainMode eq 'news') {
		&newsMain;
	}
	out("<DIV align='center'>");
	out($headKill);
	out("이 스크립트는, 서버에 부하가 걸릴 수 있어 본체에서는 링크를 제공하지 않습니다.<br>");
	out("잦은 접속이나 새로고침은 삼가 주세요!<br>");
	out("<TABLE BORDER><TR><TD>");
	foreach $i (0..$islandNumber) {
		&tempLbbsContents($i);
	}
	out("<TR><TD colspan=2 class='M'><P align='center'>${AfterName}이름을 클릭하면, 관광할 수 있습니다.</P></TD></TR>");
# 헤더 코멘트를 치환할 경우(hako-init.cgi에서 주석 처리된 부분과 연동)
#	&tempNews if($mode);
	out("</TABLE>");
	out("</DIV>");
}
&htmlFooter;
#종료
exit(0);

# 서브 루틴---------------------------------------------------------
#--------------------------------------------------------------------
#	POST 또는 GET으로 입력된 데이터 가져오기
#--------------------------------------------------------------------
sub cgiInput {
	my($line, $getLine);
	$line = <>;
	$line =~ tr/+/ /;
	$line =~ s/%([a-fA-F0-9]{2})/pack(H2, $1)/eg;

	# GET 값을 받음
	$getLine = $ENV{'QUERY_STRING'};

	if($getLine =~ /pass=([^\&]*)/) {
		# 처음의 시작
		$HdefaultPassword = $1;
	} elsif($line =~ /NewsComment=([^\&]*)\&/) {
		$HdefaultPassword = $1;
		$line =~ s/(.*)NEWS=//g;
		$HnewsComment = $line;
		$HmainMode = 'news';
	}
}

#cookie 입력
sub cookieInput {
	my($cookie);
#	$cookie = $ENV{'HTTP_COOKIE'}; # 문자 변환 라이브러리 사용 시
	$cookie = $ENV{'HTTP_COOKIE'};
	if($cookie =~ /${HthisFile}OWNISLANDPASSWORD=\(([^\)]*)\)/) {
		$HdefaultPassword = $1;
	}
}
#---------------------------------------------------------------------
#	함수명 : htmlHeader
#	기계 능 : HTML 의헤더 부분을 출력
#	인 수 : 없음
#	반환 값 : 없음
#---------------------------------------------------------------------
sub htmlHeader {
	if($HskinName ne '' ){
		$baseSKIN = $HskinName;
	} else {
		$baseSKIN = "${efileDir}/$HcssFile";
	}
	if($ENV{'HTTP_ACCEPT_ENCODING'}=~/gzip/ && $Hgzip == 1){
		print qq{Content-type: text/html; charset=UTF-8\n};
		print qq{Content-encoding: gzip\n\n};
		open(STDOUT,"| $HpathGzip/gzip -1 -c");
		print " " x 2048 if($ENV{HTTP_USER_AGENT}=~/MSIE/);
		print qq{<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">\n\n};
	}else{
		print qq{Content-type: text/html; charset=UTF-8\n\n};
		print qq{<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">\n\n};
	}
	my $term = '';
	$term = ($HislandTurn < $HarmisticeTurn) ? "(~$HarmisticeTurn <small>휴전 기간</small>)" : ($HislandTurn == $HarmisticeTurn) ? '(<small>다음 턴보다전투 기간</small>)' : '(<small>전투 기간</small>)' if($HarmisticeTurn);

	out(<<END);
<HTML>
<HEAD><META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
<TITLE>
$title
</TITLE>
<link rel="stylesheet" type="text/css" href="${baseSKIN}">
</HEAD>
$body<DIV ID='BodySpecial'>
<DIV ID='LinkHead'>
$Hheader
END

	# 자신의 사이트등 링크를 추가하는 경우↑에추가해 주세요.
	# 불필요하게 아래에 링크를 추가하지 말아 주세요.JavaScript 오류의 원인이 되는 것이 있습니다.

	out(<<END) if(defined $HleftTime);
<HR><FORM name=TIME style="margin: 1px 0px;">
<H1 style="display:inline;"><SMALL><B>턴</B> </SMALL>$HislandTurn<SMALL>${term}</SMALL> </H1>
<INPUT type=text name=TIME size=52 readonly class="timer">
</FORM>
<SCRIPT language="JavaScript">
<!--
var leftTime = $HleftTime;
var hour, min, sec;

function showTimeLeft() {
	if (leftTime> 0) {
		setTimeout('showTimeLeft()', 1000);

		hour = Math.floor(leftTime / 3600);
		min = Math.floor(leftTime % 3600 / 60);
		sec = leftTime % 60;
		leftTime--;

		document.TIME.TIME.value = '다음 갱신까지 ' + hour + '시간 ' + min + '분 ' + sec + '초 ($HnextTime)';
	} else {
		document.TIME.TIME.value = '턴 갱신 시각이 되었습니다! ($HnextTime)';
	}
}

if ($HplayNow) {
	showTimeLeft();
} else {
	document.TIME.TIME.value = '게임이 종료되었습니다!';
}
//-->
</SCRIPT>
END

	out(<<END);
<HR></DIV>
${bye2}<A HREF="$bye">[돌아가기]</A><br><br>
END
}
#---------------------------------------------------------------------
#	함수명 : htmlFooter
#	기계 능 : HTML 의푸터 부분을 출력
#	인 수 : 없음
#	반환 값 : 없음
#---------------------------------------------------------------------
sub htmlFooter {
	out(<<END);
<HR>
<DIV ID='LinkFoot'>
$Hfooter
<BR></DIV>
END
##### 추가 친분20020307
	if($Hperformance) {
		my($uti, $sti, $cuti, $csti) = times();
		$uti += $cuti;
		$sti += $csti;
		my($cpu) = $uti + $sti;

	#	 로그 파일 쓰기(테스트 계측용, 평소에는 주석 처리해 주세요)
	#	 open(POUT,">>cpu-h.log");
	#	 print POUT "CPU($cpu) : user($uti) system($sti)\n";
	#	 close(POUT);

		out(<<END);
<DIV align="right">
<SMALL>CPU($cpu) : user($uti) system($sti)</SMALL>
</DIV>
END
	}
#####
	out(<<END);
</DIV></BODY>
</HTML>
END
}
#---------------------------------------------------------------------
#	함수명 : htmlError
#	기계 능 : HTML 의오류 메시지의 출력
#	인 수 : 없음
#	반환 값 : 없음
#---------------------------------------------------------------------
sub htmlError{
	out("<H2>오류가 발생했습니다</H2>\n");
}

#---------------------------------------------------------------------
#	함수명 : tempLbbsContents
#	기계 능 : 로컬 게시판내용
#	인 수 : 없음
#	반환 값 : 없음
#---------------------------------------------------------------------
sub tempLbbsContents {
	my($number) = $_[0];
	my($island) = $Hislands[$number];
	my($name) = islandName($island);
	my($id) = $island->{'id'};
	my($owner) = $island->{'owner'};
	my($lbbs) = $island->{'lbbs'};
	my($comment) = $island->{'comment'};
	my($line);
	out(<<END);
<TR><TH $HbgTitleCell>${HtagTH_}${AfterName}이름${H_tagTH}</TH>
<TD $HbgNameCell>
<A STYlE=\"text-decoration:none\" HREF="${HthisFile}?Sight=${id}">
${HtagName_}$name${H_tagName}
</A>
</TD><TH $HbgTitleCell>${HtagTH_} 섬주${H_tagTH}</TH>
<TD $HbgInfoCell>$owner</TD></TR>
<TR><TH $HbgTitleCell>${HtagTH_}코멘트${H_tagTH}</TH><TD $HbgCommentCell colspan=3>$comment</TD></TR>
END

	if($mode) {
		out(<<END);
<TR>
<TD colspan=4>
<FORM action="$HthisFile" method="POST">
<INPUT TYPE="hidden" NAME="LBBSNAME" VALUE="$HadminName">
<INPUT TYPE="hidden" NAME="ISLANDID2" VALUE="0">
com:<INPUT TYPE="text" SIZE=40 NAME="LBBSMESSAGE">
pass:<INPUT TYPE="password" SIZE=16 MAXLENGTH=16 NAME=PASSWORD VALUE="$HdefaultPassword">
<INPUT TYPE="radio" NAME="LBBSTYPE" VALUE="PUBLIC" CHECKED>공개
<INPUT TYPE="radio" NAME="LBBSTYPE" VALUE="SECRET"><span class='lbbsST'>극비</span>
<INPUT TYPE="submit" VALUE="기장하다" NAME="LbbsButtonAD$id">
번호
<SELECT NAME=NUMBER>
END
		# 발언번호
		my($j, $i);
		for($i = 0; $i < $HlbbsMax; $i++) {
			$j = $i + 1;
			out("<OPTION VALUE=$i>$j\n");
		}
		out("<OPTION VALUE=$HlbbsMax>전체\n");
		out(<<END);
</SELECT>
<INPUT TYPE="submit" VALUE="삭제" NAME="LbbsButtonDA$id">
</TD>
</TR>
</FORM>
END
	}

	my($i,$j,$str1,$turn);
	for($i = 0; $i < $HlbbsMax; $i++) {
		$line = $lbbs->[$i];
		if($line =~ /([0-9]*)\<(.*)\<([0-9]*)\>(.*)\>(.*)$/) {
			my($m, $iName, $os, $tan, $com) = ($1, $2, $3, $4, $5);
			$com =~ s/(http|ftp):\/\/([^\x81-\xFF\s\"\'\(\)\<\>\\\`\[\{\]\}\|]+)/<A href=\"$1:\/\/$2\">$HlbbsAutolinkSymbol<\/A>/g if($HlbbsAutolinkSymbol ne '');
			$j = $i + 1;
			out("<TR><TD $HbgNameCell align=center><span class='number'>$j</span></TD>");
			my($speaker);
			my($sName, $sID) = split(/,/, $iName);
			my $sNo = $HidToNumber{$sID};
			if($sName ne '') {
				if(defined $sNo){
					$speaker = "<span class='lbbsST'><B><SMALL>(<A STYlE=\"text-decoration:none\" HREF=\"$HthisFile?Sight=$sID\">$sName</A>)</SMALL></B></span>";
				} else {
					$speaker = "<span class='lbbsST'><B><SMALL>($sName)</SMALL></B></span>";
				}
			}
			my($turn);
			if($tan =~ /^([0-9]*):/) {
				$turn = $1;
			}
			if($turn>= $HislandTurn - $kyoutyouturn) {
				out("<TD class='RankingCell' colspan=3>");
			} else {
				out("<TD $HbgInfoCell colspan=3>");
			}
			if($os == 0) {
				# 관광객
				if ($m == 0) {
					# 공개
					if($sID ne '0') {
						out("<span class='lbbsSS'>$tan> $com</span> $speaker</TD></TR>");
					} else {
						out("<span class='lbbsAD'>$tan> ${com}</span> $speaker</TD></TR>");
					}
				} else {
					# 극비
					if (!$mode) {
						# 관광객
						out("<DIV align='center'><span class='lbbsST'>- 극비 -</span></DIV></TD></TR>");
					} else {
						# 소유자
						out("<span class='lbbsST'>$tan>(비밀) $com</span> $speaker</TD></TR>");
					}
				}
			} else {
				# 섬주
				out("<span class='lbbsOW'>$tan> $com</span> $speaker</TD></TR>");
			}
		}
	}
	out(<<END);
</TD></TR>
END

	out(<<END);
<TR></TR>
<TR></TR>
END
}

sub tempNews {
	out(<<END);
<TR></TR>
<TR></TR>
<FORM name="f01" action="$HlbbsFile" method="POST">
<TR><TD colspan=4><big><B>코멘트 변경(톱 페이지의 맨 위 링크 바로 아래)</B></big>
 <INPUT TYPE="hidden" VALUE="$HdefaultPassword" NAME="NewsComment">
 <INPUT TYPE="submit" VALUE="변경">
</TD></TR>
<TR><TD colspan=4>
<SCRIPT LANGUAGE=javascript>
<!--
function chk01(str){
// var str1 = str.replace(/\<|\>/g,"");
 return str1;
}
//-->
</SCRIPT>
<P ALIGN="center">
<TABLE BORDER=2><TR><TD style="border-style:inset;">
<textarea name="NEWS" cols=80 rows=5 WRAP="soft">$Hnews</textarea><BR>
</TD></TR></TABLE>
↓↓↓ Preview ↓↓↓
<TABLE BORDER=2><TR><TD style="border-style:inset;">
<span ID="outputN1"></span><br>
<SCRIPT LANGUAGE=javascript>
<!--
outputN1.setExpression("innerHTML","f01.NEWS.value");
//-->
</SCRIPT>
</TD></TR></TABLE>
</TD>
</FORM>
</TR>
END
}

sub newsMain {
	if(!$mode){
		&htmlError;
		&htmlFooter;
		#종료
		exit(0);
	}
	if($HnewsComment eq '') {
		unlink('./news.cgi') if(-e "./news.cgi");
	} else {

		my $rn = "\n";
		$HnewsComment =~ s/\r$rn/$rn/eg;
		open(NEWS, ">./news.cgi");
		print NEWS $HnewsComment;
		close(NEWS);
	}
	$Hnews = $HnewsComment;
}
