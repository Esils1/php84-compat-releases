#!/usr/bin/perl

#┌─────────────────────────────
#│ ●등록 키 이미지 표시 모듈
#│ registkey.cgi - 2006/01/18
#│ Copyright (c) KentWeb
#│ webmaster@kent-web.com
#│ http://www.kent-web.com/
#└─────────────────────────────

# 외부 파일 불러오기
require './gifcat.pl';
require './registpl.cgi';

# 등록 키 이미지디렉터리
$gifdir = './keyimg/';

# 파라미터 받기
$buf = $ENV{'QUERY_STRING'};
$buf =~ s/\%21/!/g;
$buf =~ s/<//g;
$buf =~ s/>//g;
$buf =~ s/"//g;
$buf =~ s/&//g;
$buf =~ s/\s//g;
$buf =~ s/\0//g;

# 확인
if ($buf eq "check") {
	&check;
} else {
	# 이미지 표시
	&key_image;
}

#---------------------------------------
#  등록 키 이미지
#---------------------------------------
sub key_image {
	# 복호화
	local($plain) = &pcp_decode($buf, $pcp_passwd);

	# 앞 4글자 추출
	$plain =~ s/^(\d{4}).*/$1/;

	# 이미지 파일 정의
	local(@view);
	foreach ( split(//, $plain) ) {
		push(@view,"$gifdir$_.gif");
	}

	# 이미지 표시
	print "Content-type: image/gif\n\n";
	binmode(STDOUT);
	print &gifcat'gifcat(@view);

	exit;
}

#---------------------------------------
#  등록 키 이미지 확인
#---------------------------------------
sub check {
	print "Content-type: text/html; charset=utf-8\n\n";
	print <<EOM;
<html>
<head>
<META HTTP-EQUIV="Content-type" CONTENT="text/html; charset=utf-8">
</head>
<body>
등록 키 이미지 확인
<ul>
EOM

	foreach (0 .. 9) {
		if (-e "$gifdir/$_.gif") {
			print "<li>$_.gif : OK\n";
		} else {
			print "<li>$gifdir/$_.gif : NG\n";
		}
	}

	print <<EOM;
</ul>
</body>
</html>
EOM
	exit;
}

