#!/usr/bin/perl

# The Return of Neptune: http://hpcgi2.nifty.com/otacky/
#----------------------------------------------------------------------
# hako-yy-bbs.cgi by.neo_otacky
# 해전 「동맹 게시판」용으로 수정
# 　=== 관리용 접속 방법 ===
# 　hako-yy-bbs.cgi?id=0&ally=[동맹 ID]&cpass=[마스터 비밀번호]
# 　[동맹 ID]는 반각 숫자, [마스터 비밀번호]는 영문/숫자입니다([]는 불필요).
#┌─────────────────────────────────
#│ [YY-BOARD]  yyregi.cgi - 2006/01/10
#│  Copyright (c) KentWeb
#│  webmaster@kent-web.com
#│  http://www.kent-web.com/
#└─────────────────────────────────

BEGIN {
	# Perl 5.004 이상이 필요
	require 5.004;

########################################
	# 오류 표시
	$SIG{__WARN__} = $SIG{__DIE__} =
	sub {
		my($msg) = @_;

		$msg =~ s/\n/<br>/g;
		print STDOUT <<END;
Content-type: text/html; charset=utf-8

<p><big><tt><b>ERROR:</b><br>$msg</tt></big></p>
END
		exit(-1);
	};
########################################
}

# 외부 파일 불러오기
require './hako-yy-ini.cgi';

# 메인 처리
&decode;
&read_data;
&file_check;
&axsCheck;
local($cnam,$ceml,$curl,$cpwd,$cico,$ccol,$ccss) = &get_cookie;
if ($mode eq "past") { &past; }
elsif ($mode eq "skin") {
	$ccss = $in{'css'};
	&set_cookie($cnam,$ceml,$curl,$cpwd,$cico,$ccol,$ccss);
	&message("스킨 변경 완료!");
}
elsif (($dead eq '') || ($owner == 2)) {
	if ($mode eq "dele") { &dele; }
	elsif ($mode eq "regist") { &regist($logfile, 1); }
	elsif ($mode eq "edit") { &edit; }
	elsif ($mode eq "diplo") { &diplo; }
	elsif ($mode eq "staff") { &staff; }
	elsif ($mode eq "admin") { &admin; }
}
&error("알 수 없는 처리입니다");

#-------------------------------------------------
#  게시글 등록
#-------------------------------------------------
sub regist {
	my($logfile, $mode) = @_;
	local($flag,$oyaChk,@lines,@data,@new,@tmp);

	# 시간 가져오기
	&get_time;

	# 폼 입력 확인
	&formCheck;

	# 등록 키 확인
	if ($regist_key) {
		require $registkeypl;

		if ($in{'regikey'} !~ /^\d{4}$/) {
			&error("등록 키 입력이 올바르지 않습니다.<p>글쓰기 폼으로 돌아가 새로고침한 뒤 지정된 숫자를 입력해 주세요");
		}

		# 등록 키 확인
		# -1 : 키 불일치
		#  0 : 제한 시간 초과
		#  1 : 키 일치
		local($chk) = &registkey_chk($in{'regikey'}, $in{'str_crypt'});
		if ($chk == 0) {
			&error("등록 키 제한 시간이 지났습니다.<p>글쓰기 폼으로 돌아가 새로고침한 뒤 지정된 숫자를 다시 입력해 주세요");
		} elsif ($chk == -1) {
			&error("등록 키가 올바르지 않습니다.<p>글쓰기 폼으로 돌아가 새로고침한 뒤 지정된 숫자를 입력해 주세요");
		}
	}

	# 파일 잠금
	if ($lockMode) { &lock; }

	# 로그 열기
	@lines = ();
	@new = ();
	@tmp = ();
	@data = ();
	open(IN,"$logfile") || &error("Open Error : $logfile (regist)");
	@lines = <IN>;
	close(IN);

	# 게시글 번호 처리
	$top = shift(@lines);
	($no,$ip,$tim,$mt) = split(/<>/, $top);
	$no++;

	if($mode == 1) {
		# 연속 글쓰기 확인
		$flag=0;
		if ($regCtl == 1) {
			if ($addr eq $ip && $times - $tim < $wait) { $flag=1; }
		} elsif ($regCtl == 2) {
			if ($times - $tim < $wait) { $flag=1; }
		}
		if ($flag) {
			&error("현재 글쓰기 제한 중입니다. 잠시 후 다시 작성해 주세요");
		}
	}

	# 금지어 확인
	if ($deny_word) {
		&deny_word($in{'name'});
		&deny_word($in{'sub'});
		&deny_word($in{'comment'});
	}

	# URL 자동 링크
	#if ($autolink) { &auto_link($in{'comment'}); }

	if($mode == 1) {
		# 중복 확인
		$flag=0;
		foreach (@lines) {
			local($no2,$re,$dat,$nam,$eml,$sub,$com) = split(/<>/, $_);
			if ($in{'name'} eq $nam && $in{'comment'} eq $com) {
				$flag=1; last;
			}
		}
		if ($flag) { &error("중복 게시글이어서 처리를 중단했습니다($logfile)"); }
	}

	# 수정/삭제 키 암호화
	if ($in{'pwd'} ne "") { $pwd = &encrypt($in{'pwd'}); }

	my $iNum = $HidToNumber{$in{'id'}};
	my $idname = '';
	if(defined $iNum) {
		$idname = $Hislands[$iNum]->{'name'};
	} elsif($in{'id'} == 0) {
		$idname = 0;
	}
	my $allyidname = '';
	if($in{'ally'} ne '') {
		my($aFrom, $aTo) = split(/\-/, $in{'ally'});
		$allyidname = "<FONT COLOR=$allyCol[$aFrom]>$ally_head[$aFrom]</FONT>$ally_name[$aFrom]";
		if($aTo ne '') {
			$allyidname .= ",<FONT COLOR=$allyCol[$aTo]>$ally_head[$aTo]</FONT>$ally_name[$aTo]";
			$in{'ally'} = $aFrom if($mode);
		}
	}
	# 원글인 경우
	if ($in{'reno'} eq "") {

		$i=0;
		$stop=0;
		foreach (@lines) {
			($no2,$reno2) = split(/<>/);
			$i++;
			if ($i > $max-1 && $reno2 eq "") { $stop=1; }
			if (!$stop) { push(@new,$_); }
			elsif ($stop && $Hpastkey) { push(@data,$_); }
		}
		unshift(@new,"$no<><>$date<>$in{'name'}<>$in{'email'}<>$in{'sub'}<>$in{'comment'}<>$in{'url'}<>$idname<>$allyidname<>$HislandTurn<>$host<>$pwd<>$col[$in{'color'}]<>$in{'icon'}<>\n");
		if($mode) {
			$top = "$no<>$addr<>$times<>$maintitle<>\n";
		} else {
			$top = "$no<>$ip<>$tim<>$mt<>\n";
		}
		unshift(@new,$top);

		# 지난 로그 갱신
		if (@data > 0) {
			my($aFrom, $aTo) = split(/\-/, $in{'ally'});
			$in{'ally'} = $aTo if(!$mode);
			&pastlog(@data);
			$in{'ally'} = $aFrom . '-' . $aTo if(!$mode);
		}

		# 갱신
		open(OUT,">$logfile") || &error("Write Error : $logfile");
		print OUT @new;
		close(OUT);

	# 답글인 경우: 맨 위 정렬 있음
	} elsif ($in{'reno'} && $topsort) {

		$f=0;
		$oyaChk=0;
		$match=0;
		@new=();
		@tmp=();
		foreach (@lines) {
			($no2,$reno2) = split(/<>/);

			if ($in{'reno'} eq $no2) {
				if ($reno2) { $f++; last; }
				$oyaChk++;
				$match=1;
				push(@new,$_);

			} elsif ($in{'reno'} eq $reno2) {
				push(@new,$_);

			} elsif ($match == 1 && $in{'reno'} ne $reno2) {
				$match=2;
				push(@new,"$no<>$in{'reno'}<>$date<>$in{'name'}<>$in{'email'}<>$in{'sub'}<>$in{'comment'}<>$in{'url'}<>$idname<>$allyidname<>$HislandTurn<>$host<>$pwd<>$col[$in{'color'}]<>$in{'icon'}<>\n");
				push(@tmp,$_);

			} else { push(@tmp,$_); }
		}
		if ($f) { &error("잘못된 답글 요청입니다"); }
		if (!$oyaChk) { &error("원글이 존재하지 않습니다"); }

		if ($match == 1) {
			push(@new,"$no<>$in{'reno'}<>$date<>$in{'name'}<>$in{'email'}<>$in{'sub'}<>$in{'comment'}<>$in{'url'}<>$idname<>$allyidname<>$HislandTurn<>$host<>$pwd<>$col[$in{'color'}]<>$in{'icon'}<>\n");
		}
		push(@new,@tmp);

		# 갱신
		unshift(@new,"$no<>$addr<>$times<>$maintitle<>\n");
		open(OUT,">$logfile") || &error("Write Error : $logfile");
		print OUT @new;
		close(OUT);

	# 답글인 경우: 맨 위 정렬 없음
	} else {
		$f=0;
		$oyaChk=0;
		$match=0;
		@new=();
		foreach (@lines) {
			($no2,$reno2) = split(/<>/);

			if ($in{'reno'} == $no2) { $oyaChk++; }
			if ($match == 0 && $in{'reno'} eq $no2) {
				if ($reno2) { $f++; last; }
				$match=1;

			} elsif ($match == 1 && $in{'reno'} ne $reno2) {
				$match=2;
				push(@new,"$no<>$in{'reno'}<>$date<>$in{'name'}<>$in{'email'}<>$in{'sub'}<>$in{'comment'}<>$in{'url'}<>$idname<>$allyidname<>$HislandTurn<>$host<>$pwd<>$col[$in{'color'}]<>$in{'icon'}<>\n");
			}
			push(@new,$_);
		}
		if ($f) { &error("잘못된 답글 요청입니다"); }
		if (!$oyaChk) { &error("원글이 존재하지 않습니다"); }

		if ($match == 1) {
			push(@new,"$no<>$in{'reno'}<>$date<>$in{'name'}<>$in{'email'}<>$in{'sub'}<>$in{'comment'}<>$in{'url'}<>$idname<>$allyidname<>$HislandTurn<>$host<>$pwd<>$col[$in{'color'}]<>$in{'icon'}<>\n");
		}

		# 갱신
		unshift(@new,"$no<>$addr<>$times<>$maintitle<>\n");
		open(OUT,">$logfile") || &error("Write Error : $logfile");
		print OUT @new;
		close(OUT);
	}

	# 잠금 해제
	if ($lockMode) { &unlock; }

	# 쿠키 발행
	$ccss = $HyycssDefault if($ccss eq '');
	&set_cookie($in{'name'},$in{'email'},$in{'url'},$in{'pwd'},$in{'icon'},$in{'color'},$ccss);

	# 메일 처리
	if ($mailing == 1 && $in{'email'} ne $mailto) { &mail_to; }
	elsif ($mailing == 2) { &mail_to; }

	if($mode) {
		# 다시 불러오기
		if ($location) {
			if ($ENV{'PERLXS'} eq "PerlIS") {
				print "HTTP/1.0 302 Temporary Redirection\r\n";
				print "Content-type: text/html; charset=utf-8\n";
			}
			print "Location: $location\n\n";
			exit;
		} else {
			&message('글이 정상적으로 처리되었습니다');
		}
	}
}

#-------------------------------------------------
#  게시글 삭제
#-------------------------------------------------
sub dele {
	local($flag,$no,$reno,$dat,$nam,$eml,$sub,$com,$url,$idname,$allyidname,$turn,$hos,$pw,$check,@new);

	# POST 전용
	if ($postonly && !$post_flag) { &error("잘못된 접근입니다"); }

	if ($in{'no'} eq '' || $in{'pwd'} eq '')
		{ &error("게시글 번호 또는 수정/삭제 키가 입력되지 않았습니다"); }

	# 잠금 처리
	&lock if ($lockMode);

	$flag=0;
	$flag2=0;
	@new=();
	open(IN,"$logfile") || &error("Open Error: $logfile");
	$top = <IN>;
	while (<IN>) {
		($no,$reno,$dat,$nam,$eml,$sub,$com,$url,$idname,$allyidname,$turn,$hos,$pw,$col,$ico) = split(/<>/);
		if ($in{'no'} == $no) {
			$flag++;
			$pw2 = $pw;
			next;
		} elsif ($in{'no'} == $reno) {
			$flag2=$no if(!$flag2);
			$reno = ($flag2 != $no) ? $flag2 : '';
			push(@new,"$no<>$reno<>$dat<>$nam<>$eml<>$sub<>$com<>$url<>$idname<>$allyidname<>$turn<>$hos<>$pw<>$col<>$ico<>\n");
			next;
		}
		push(@new,$_);
	}
	close(IN);
	if (!$flag) { &error("해당 게시글을 찾을 수 없습니다"); }
	if ($pw2 eq "") { &error("수정/삭제 키가 설정되어 있지 않습니다"); }

	$check = &decrypt($in{'pwd'}, $pw2);
	if ($check != 1) { &error("수정/삭제 키가 틀렸습니다"); }

	unshift(@new,$top);
	open(OUT,">$logfile") || &error("Write Error: $logfile");
	print OUT @new;
	close(OUT);

	# 잠금 해제
	&unlock if ($lockMode);

	# 완료 메시지
	&message("삭제가 완료되었습니다");
}

#-------------------------------------------------
#  게시글 수정
#-------------------------------------------------
sub edit {
	local($top,$flag,$pattern,$no,$reno,$dat,$nam,$eml,$sub,$com,$url,$idname,$allyidname,$turn,$hos,$pw,$col,$ico,$check);

	if ($in{'no'} eq '' || $in{'pwd'} eq '')
		{ &error("게시글 번호 또는 수정/삭제 키가 입력되지 않았습니다"); }

	# 수정 실행
	if ($in{'job'} eq "edit") {

		# 폼 입력 확인
		&formCheck('edit');

		# 금지어 확인
		if ($deny_word) {
			&deny_word($in{'name'});
			&deny_word($in{'sub'});
			&deny_word($in{'comment'});
		}

		#if ($autolink) { &auto_link($in{'comment'}); }

		# 잠금 처리
		&lock if ($lockMode);

		$flag=0;
		open(IN,"$logfile") || &error("Open Error: $logfile");
		$top = <IN>;
		while (<IN>) {
			($no,$reno,$dat,$nam,$eml,$sub,$com,$url,$idname,$allyidname,$turn,$hos,$pw,$col,$ico) = split(/<>/);
			if ($in{'no'} == $no) {
				$flag++;
				$pw2 = $pw;
				my $iNum = $HidToNumber{$in{'id'}};
				my $idname = '';
				if(defined $iNum) {
					$idname = $Hislands[$iNum]->{'name'};
				} elsif($in{'id'} == 0) {
					$idname = 0;
				}
				my $allyidname = '';
				if($in{'ally'} ne '') {
					my($aFrom, $aTo) = split(/\-/, $in{'ally'});
					$allyidname = "<FONT COLOR=$allyCol[$aFrom]>$ally_head[$aFrom]</FONT>$ally_name[$aFrom]";
					if($aTo ne '') { $allyidname .= ",<FONT COLOR=$allyCol[$aTo]>$ally_head[$aTo]</FONT>$ally_name[$aTo]"; }
				}
				$_ = "$no<>$reno<>$dat<>$in{'name'}<>$in{'email'}<>$in{'sub'}<>$in{'comment'}<>$in{'url'}<>$idname<>$allyidname<>$HislandTurn<>$hos<>$pw<>$col[$in{'color'}]<>$in{'icon'}<>\n";
			}
			push(@new,$_);
		}
		close(IN);
		if (!$flag) { &error("해당 게시글을 찾을 수 없습니다"); }
		if ($pw2 eq "") { &error("수정/삭제 키가 설정되어 있지 않습니다"); }

		$check = &decrypt($in{'pwd'}, $pw2);
		if ($check != 1) { &error("수정/삭제 키가 틀렸습니다"); }

		unshift(@new,$top);
		open(OUT,">$logfile") || &error("Write Error: $logfile");
		print OUT @new;
		close(OUT);

		# 잠금 해제
		&unlock if ($lockMode);

		# 완료 메시지
		&message("수정이 완료되었습니다");
	}

	$flag=0;
	open(IN,"$logfile") || &error("Open Error: $logfile");
	$top = <IN>;
	while (<IN>) {
		($no,$reno,$dat,$nam,$eml,$sub,$com,$url,$idname,$allyidname,$turn,$hos,$pw,$col,$ico) = split(/<>/);
		if ($in{'no'} == $no) {
			$pw2 = $pw;
			$flag=1;
			last;
		}
	}
	close(IN);
	if (!$flag) { &error("해당 게시글을 찾을 수 없습니다"); }
	if ($pw2 eq "") { &error("수정/삭제 키가 설정되어 있지 않습니다"); }

	$check = &decrypt($in{'pwd'}, $pw2);
	if ($check != 1) { &error("수정/삭제 키가 틀렸습니다"); }

	$com =~ s/<br>/\n/g;
	$pattern = 'https?\:[\w\.\~\-\/\?\&\+\=\:\@\%\;\#\%]+';
	$com =~ s/<a href="$pattern" target="_blank">($pattern)<\/a>/$1/go;

	if ($ImageView == 1) { &header('ImageUp'); }
	else { &header; }

	print <<EOM;
<form>
<input type=button value="이전 화면으로 돌아가기" onClick="history.back()">
</form>
▽변경할 부분만 수정한 뒤 전송 버튼을 눌러 주세요。
<p>
<form action="$regist" method="POST">
<input type=hidden name=mode value="edit">
<input type=hidden name=job value="edit">
<input type=hidden name=pwd value="$in{'pwd'}">
<input type=hidden name=no value="$in{'no'}">
EOM

	&form($nam,$eml,$url,'??',$ico,$col,$sub,$com);

	print <<EOM;
</form>
</body>
</html>
EOM
	exit;
}

#-------------------------------------------------
#  완료 문구
#-------------------------------------------------
sub message {
	local($msg) = @_;

	&header;
	print <<EOM;
<div align="center">
<hr width=400>
<h3>$msg</h3>
<hr width=400>
<p>
<form action="$script">
<input type=hidden name=ally value="$in{'ally'}">
<input type=hidden name=jpass value="$in{'jpass'}">
<input type=hidden name=cpass value="$in{'cpass'}">
<input type=hidden name=id value="$in{'id'}">
<input type=submit value="게시판으로 돌아가기">
</form>
</div>
</body>
</html>
EOM
	exit;
}

#-------------------------------------------------
#  입력 확인
#-------------------------------------------------
sub formCheck {
	local($task) = @_;
	local($ref);

	# POST 전용
	if ($postonly && !$post_flag) { &error("잘못된 접근입니다"); }

	# 다른 사이트에서 온 접근 차단
#	if ($task ne 'edit' && $baseUrl) {
#		$ref = $ENV{'HTTP_REFERER'};
#		$ref =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("H2", $1)/eg;
#		$baseUrl =~ s/(\W)/\\$1/g;
#		if ($ref && $ref !~ /$baseUrl/i) { &error("잘못된 접근입니다"); }
#		if ($ref !~ /$baseUrl/i) { &error("잘못된 접근입니다"); }
#	}

	# 이름과 댓글은 필수
	if ($in{'name'} eq "") { &error("이름이 입력되지 않았습니다"); }
	if ($in{'comment'} eq "") { &error("댓글이 입력되지 않았습니다"); }
	if ($in_email && $in{'email'} !~ /^[\w\.\-]+\@[\w\.\-]+\.[a-zA-Z]{2,6}$/) {
		&error("이메일 입력 내용이 올바르지 않습니다");
	}

	if ($iconMode) {
#		@ico1 = split(/\s+/, $ico1);
#		@ico2 = split(/\s+/, $ico2);
		if($my_icon) { push(@ico1,$my_gif); }
		if($in{'icon'} !~ /[0-9a-zA-Z]*\.(gif|png|jpg)/){
			if($in{'icon'} < 0 || $in{'icon'} > @ico1) {
				&error("아이콘 정보가 올바르지 않습니다");
			} else {
				$in{'icon'} = $ico1[$in{'icon'}];
			}
		}
		# 관리 아이콘 확인
		if ($my_icon && $in{'icon'} eq $my_gif && !checkPassword($Hally[$HidToAllyNumber{$in{'ally'}}], $in{'pwd'})) {
			&error("관리용 아이콘은 관리자 전용입니다");
		}
	}

#	@col = split(/\s+/, $color);
	if ($in{'color'} =~ /\D/ || $in{'color'} < 0 || $in{'color'} > @col) {
		&error("글자색 정보가 올바르지 않습니다");
	}

	# URL
	if ($in{'url'} eq "http://") { $in{'url'} = ""; }
}

#-------------------------------------------------
#  관리 모드
#-------------------------------------------------
sub admin {
	local($no,$re,$dat,$nam,$eml,$sub,$com,$url,$idname,$allyidname,$turn,$hos,$pw,$next,$back,$top,$i);

	if ($in{'pwd'} eq "") { &enter('admin'); }
	elsif (!checkPassword($Hally[$HidToAllyNumber{$in{'ally'}}], $in{'pwd'})) { &error("비밀번호가 틀렸습니다"); }

	# 수정 화면
	if ($in{'job'} eq "edit" && $in{'no'}) {

		local(@num,@f);
		@num = split(/\0/, $in{'no'});

		open(IN,"$logfile") || &error("Open Error: $logfile");
		$top = <IN>;
		while (<IN>) {
			@f = split(/<>/);

			if ($f[0] == $num[0]) { last; }
		}
		close(IN);

		# 수정 폼
		&edit_form(@f);

	# 수정 실행
	} elsif ($in{'job'} eq "edit2" && $in{'no'}) {

#		local(@col,@ico,@new);
		local(@new);
		if ($in{'url'} eq "http://") { $in{'url'} = ''; }

#		@col = split(/\s+/, $color);
#		@ico = split(/\s+/, $ico1);
		if ($my_icon) {
			push(@ico1,$my_gif);
		}

		# 잠금 시작
		if ($lockkey) { &lock; }

		open(IN,"$logfile") || &error("Open Error: $logfile");
		$top = <IN>;
		while (<IN>) {
			($no,$re,$dat,$nam,$eml,$sub,$com,$url,$idname,$allyidname,$turn,$hos,$pw,$col,$ico) = split(/<>/);
			if ($no == $in{'no'}) {
				my $iNum = $HidToNumber{$in{'id'}};
				my $idname = '';
				if(defined $iNum) {
					$idname = $Hislands[$iNum]->{'name'};
				} elsif($in{'id'} == 0) {
					$idname = 0;
				}
				my $allyidname = '';
				if($in{'ally'} ne '') {
					my($aFrom, $aTo) = split(/\-/, $in{'ally'});
					$allyidname = "<FONT COLOR=$allyCol[$aFrom]>$ally_head[$aFrom]</FONT>$ally_name[$aFrom]";
					if($aTo ne '') { $allyidname .= ",<FONT COLOR=$allyCol[$aTo]>$ally_head[$aTo]</FONT>$ally_name[$aTo]"; }
				}
				$_="$no<>$re<>$dat<>$in{'name'}<>$in{'email'}<>$in{'sub'}<>$in{'comment'}<>$in{'url'}<>$idname<>$allyidname<>$HislandTurn<>$hos<>$pw<>$col[$in{'color'}]<>$ico1[$in{'icon'}]<>\n";
			}
			push(@new,$_);
		}
		close(IN);

		# 갱신
		unshift(@new,$top);
		open(OUT,">$logfile") || &error("Write Error: $logfile");
		print OUT @new;
		close(OUT);

		# 잠금 해제
		if ($lockkey) { &unlock; }

	# 삭제
	} elsif ($in{'job'} eq "dele" && $in{'no'}) {

		# 잠금 시작
		if ($lockkey) { &lock; }

		# 삭제 정보 대조
		local(@new)=();
		open(IN,"$logfile") || &error("Open Error: $logfile");
		$top = <IN>;
		while (<IN>) {
			$flag=0;
			($no,$re) = split(/<>/);
			foreach $del ( split(/\0/, $in{'no'}) ) {
				if ($no == $del || $re == $del) {
					$flag=1; last;
				}
			}
			if ($flag == 0) { push(@new,$_); }
		}
		close(IN);

		# 갱신
		unshift(@new,$top);
		open(OUT,">$logfile") || &error("Write Error: $logfile");
		print OUT @new;
		close(OUT);

		# 잠금 해제
		if ($lockkey) { &unlock; }
	}

	&header;
	print <<EOM;
<form action="$script">
<input type=hidden name=ally value="$in{'ally'}">
<input type=hidden name=jpass value="$in{'jpass'}">
<input type=hidden name=cpass value="$in{'cpass'}">
<input type=hidden name=id value="$in{'id'}">
<input type=submit value="게시판으로 돌아가기">
</form>
<ul>
<li>처리를 선택하고 게시글을 체크한 뒤 전송 버튼을 눌러 주세요。
<li>원글을 삭제하면 답글도 함께 삭제됩니다。
</ul>
<form action="$regist" method="POST">
<input type=hidden name=mode value="admin">
<input type=hidden name=ally value="$in{'ally'}">
<input type=hidden name=jpass value="$in{'jpass'}">
<input type=hidden name=cpass value="$in{'cpass'}">
<input type=hidden name=id value="$in{'id'}">
<input type=hidden name=page value="$page">
<input type=hidden name=pwd value="$in{'pwd'}">
<select name=job>
<option value="edit">수정
<option value="dele">삭제
</select>
<input type=submit value="전송">
<dl>
EOM

	$pastView *= 2;

	$i=0;
	open(IN,"$logfile") || &error("Open Error: $logfile");
	$top = <IN>;
	while (<IN>) {
		($no,$res,$dat,$nam,$eml,$sub,$com,$url,$idname,$allyidname,$turn,$hos,$pw) = split(/<>/);

		if ($res eq "") { $i++; }
		if ($i < $page + 1) { next; }
		if ($i > $page + $pastView) { last; }

		if ($eml) { $nam = "<a href=\"mailto:$eml\">$nam</a>"; }
		($dat) = split(/\(/, $dat);

#		if ($url) { $url = "&lt;<a href=\"$url\" target=\"_top\">URL</a>&gt;"; }
#		else { $url = '&nbsp;'; }

		$com =~ s/<[^>]*(>|$)//g;
		if (length($com) > 40) {
			$com = substr($com,0,40) . "...";
		}
#		if ($re eq "") { print "<tr><th colspan=8><hr></th></tr>\n"; }

		# 삭제 체크박스
#		print "<tr><td>$no<input type=checkbox name=no value=\"$no\"></td>";
#		print "<td>$dat</td><td>$sub</td><th>$nam</th>";
#		print "<td align=center>$url</td><td>$com</td>";
#		print "<td>$hos</td></tr>\n";
		if (!$res) { print "<dt><hr>"; } else { print "<dd>"; }
		print "<input type=checkbox name=no value=\"$no\">";
		print "[<b>$no</b>] <b style='color:$subCol'>$sub</b>\n";
		print "작성자：$nam 등록일：$dat 【$hos】\n";
		print "<dd style='font-size:11px'>$com</dd>\n";
	}
	close(IN);

	print <<EOM;
<dt><hr>
</dl>
</form>
EOM

	$next = $page + $pastView;
	$back = $page - $pastView;

	print "<p><table class='v' cellspacing=0 cellpadding=0><tr><td></td>\n";
	if ($back >= 0) {
		print "<td><form action=\"$regist\" method=\"POST\">\n";
		print "<input type=hidden name=page value=\"$back\">\n";
		print "<input type=hidden name=ally value=\"$in{'ally'}\">\n";
		print "<input type=hidden name=jpass value=\"$in{'jpass'}\">\n";
		print "<input type=hidden name=cpass value=\"$in{'cpass'}\">\n";
		print "<input type=hidden name=id value=\"$in{'id'}\">\n";
		print "<input type=hidden name=pwd value=\"$in{'pwd'}\">\n";
		print "<input type=hidden name=mode value=\"admin\">\n";
		print "<input type=submit value=\"이전 $pastView묶음\"></td></form>\n";
	}
	if ($next < $i) {
		print "<td><form action=\"$regist\" method=\"POST\">\n";
		print "<input type=hidden name=page value=\"$next\">\n";
		print "<input type=hidden name=ally value=\"$in{'ally'}\">\n";
		print "<input type=hidden name=jpass value=\"$in{'jpass'}\">\n";
		print "<input type=hidden name=cpass value=\"$in{'cpass'}\">\n";
		print "<input type=hidden name=id value=\"$in{'id'}\">\n";
		print "<input type=hidden name=pwd value=\"$in{'pwd'}\">\n";
		print "<input type=hidden name=mode value=\"admin\">\n";
		print "<input type=submit value=\"다음 $pastView묶음\"></td></form>\n";
	}

	print <<EOM;
</tr></table>
</body>
</html>
EOM
	exit;
}

#-------------------------------------------------
#  수정 화면
#-------------------------------------------------
sub edit_form {
	local($no,$re,$dat,$nam,$eml,$sub,$com,$url,$idname,$allyidname,$turn,$hos,$pw,$col,$ico) = @_;

	$com =~ s/<br>/\n/g;

	if ($ImageView == 1) { &header('ImageUp'); }
	else { &header; }
	print <<EOM;
<form>
<input type=button value="이전 화면으로 돌아가기" onClick="history.back()">
</form>
▽변경할 부분만 수정한 뒤 전송 버튼을 눌러 주세요。
<p>
<form action="$regist" method="POST">
<input type=hidden name=mode value="admin">
<input type=hidden name=job value="edit2">
<input type=hidden name=pwd value="$in{'pwd'}">
<input type=hidden name=no value="$no">
EOM

	&form($nam,$eml,$url,'??',$ico,$col,$sub,$com);

	print <<EOM;
</form>
</body>
</html>
EOM
	exit;
}

#-------------------------------------------------
#  입장 화면
#-------------------------------------------------
sub enter {
	&header if($_[1] eq '');
	print <<EOM;
<div align="center">
<h4>비밀번호를 입력해 주세요</h4>
<form action="$regist" method="POST">
<input type=hidden name=mode value="$_[0]">
<input type=hidden name=ally value="$in{'ally'}">
<input type=hidden name=jpass value="$in{'jpass'}">
<input type=hidden name=cpass value="$in{'cpass'}">
<input type=hidden name=id value="$in{'id'}">
<input type=password name=pwd size=8 class=f>
<input type=submit value=" 인증 ">
</form>
</div>
</body>
</html>
EOM
	exit;
}

#-------------------------------------------------
#  시간가져오기
#-------------------------------------------------
sub get_time {
#	$ENV{'TZ'} = "JST-9";
	$times = time;
	($sec,$min,$hour,$mday,$mon,$year,$wday) = gmtime($times + $Hjst);
	local(@week) = ('Sun','Mon','Tue','Wed','Thu','Fri','Sat');

	# 일시 형식
	$date = sprintf("%04d/%02d/%02d(%s) %02d:%02d",
			$year+1900,$mon+1,$mday,$week[$wday],$hour,$min);
}

#-------------------------------------------------
#  메일 전송
#-------------------------------------------------
sub mail_to {
	local($msub,$mbody,$email,$ptn);

	# 게시글의 줄바꿈·태그 복원
	$com  = $in{'comment'};
	$com =~ s/<br>/\n/g;
	$ptn = 'https?\:[\w\.\~\-\/\?\&\+\=\:\@\%\;\#\%]+';
	$com =~ s/<a href="$ptn" target="_blank">($ptn)<\/a>/$1/go;
	$com =~ s/&lt;/</g;
	$com =~ s/&gt;/>/g;
	$com =~ s/&quot;/"/g; #"
	$com =~ s/&amp;/&/g;

	# 메일 본문 정의
	$mbody = <<EOM;
등록일시：$date
호스트명：$host
브라우저：$ENV{'HTTP_USER_AGENT'}

작성자명：$in{'name'}
이메일：$in{'email'}
참조 URL  ：$in{'url'}
제목：$in{'sub'}

$com
EOM

	# 제목을 BASE64화
	$msub = &base64("$title (No.$no)");

	# 이메일 주소가 없으면 관리자 주소로 대체
	if ($in{'email'} eq "") { $email = $mailto; }
	else { $email = $in{'email'}; }

	open(MAIL,"| $sendmail -t") || &error("메일 전송 실패");
	print MAIL "To: $mailto\n";
	print MAIL "From: $email\n";
	print MAIL "Subject: $msub\n";
	print MAIL "MIME-Version: 1.0\n";
	print MAIL "Content-type: text/plain; charset=utf-8\n";
	print MAIL "Content-Transfer-Encoding: 8bit\n";
	print MAIL "X-Mailer: $ver\n\n";
	print MAIL "--------------------------------------------------------\n";
	foreach ( split(/\n/, $mbody) ) {
		print MAIL $_, "\n";
	}
	print MAIL "--------------------------------------------------------\n";
	close(MAIL);
}

#-------------------------------------------------
#  BASE64 변환
#-------------------------------------------------
#               토호호의 WWW 입문에서 공개된 루틴을
#               참고했습니다。( http://tohoho.wakusei.ne.jp/ )
sub base64 {
	local($sub) = $_[0];

	$sub =~ s/\x1b\x28\x42/\x1b\x28\x4a/g;
	$sub = "=?UTF-8?B?" . &b64enc($sub) . "?=";
	$sub;
}
sub b64enc {
	local($ch)="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
	local($x, $y, $z, $i);
	$x = unpack("B*", $_[0]);
	for ($i=0; $y=substr($x,$i,6); $i+=6) {
		$z .= substr($ch, ord(pack("B*", "00" . $y)), 1);
		if (length($y) == 2) {
			$z .= "==";
		} elsif (length($y) == 4) {
			$z .= "=";
		}
	}
	$z;
}

#-------------------------------------------------
#  지난 로그 생성
#-------------------------------------------------
sub pastlog {
	local(@data) = @_;
	local($count,$pastfile,$i,$f,@past);

	# 지난 로그 번호 파일
	open(NO,"$nofile") || &error("Open Error: $nofile");
	$count = <NO>;
	close(NO);
	$pastfile = sprintf("%s%04d\.%s\.cgi", $pastdir,$count,($in{'ally'} eq '' ? 0 : $in{'ally'}));

	# 지난 로그 열기
	$i=0; $f=0;
	open(IN,"$pastfile") || &error("Open Error: $pastfile");
	while (<IN>) {
		$i++;
		push(@past,$_);
		if ($i >= $pastmax) { $f++; last; }
	}
	close(IN);

	# 규정 행 수를 초과하면 다음 파일을 자동 생성
	if ($f) {
		# 카운트 파일 갱신
		open(NO,">$nofile") || &error("Write Error: $nofile");
		print NO ++$count;
		close(NO);

		$pastfile = sprintf("%s%04d\.%s\.cgi", $pastdir,$count,($in{'ally'} eq '' ? 0 : $in{'ally'}));
		@past = @data;
	} else {
		unshift(@past,@data);
	}

	# 지난 로그 갱신
	open(OUT,">$pastfile") || &error("Write Error: $pastfile");
	print OUT @past;
	close(OUT);

	if ($f) { chmod(0666, $pastfile); }
}

#-------------------------------------------------
#  지난 로그
#-------------------------------------------------
sub past {
	open(IN,"$nofile") || &error("Open Error: $nofile");
	$no = <IN>;
	close(IN);

	$in{'pastlog'} =~ s/\D//g;
	if (!$in{'pastlog'}) { $in{'pastlog'} = $no; }

	&header;
	print <<"EOM";
[<a href="JavaScript:void(0)" onClick="document.LINK.submit();return false;">게시판으로 돌아가기</a>]
<form name=LINK method="POST" action="$script">
<input type=hidden name=ally value="$in{'ally'}">
<input type=hidden name=jpass value="$in{'jpass'}">
<input type=hidden name=cpass value="$in{'cpass'}">
<input type=hidden name=id value="$in{'id'}">
</form>
<form action="$regist" method="POST">
<input type=hidden name=mode value=past>
<input type=hidden name=ally value="$in{'ally'}">
<input type=hidden name=jpass value="$in{'jpass'}">
<input type=hidden name=cpass value="$in{'cpass'}">
<input type=hidden name=id value="$in{'id'}">
<table class='v' border=0>
<tr><td><b>지난 로그</b> <select name=pastlog class=f>
EOM
	# 지난 로그 선택
	for ($i=$no; $i>0; --$i) {
		my $pastfile = sprintf("%s%04d\.%s\.cgi", $pastdir,$i,($in{'ally'} eq '' ? 0 : $in{'ally'}));
		next unless (-e "${pastfile}");
		if ($in{'pastlog'} == $i) {
			print "<option value=\"$i\" selected>$i\n";
		} else {
			print "<option value=\"$i\">$i\n";
		}
	}

	print <<EOM;
</select>
<input type=submit value="이동"></td></form>
<td width=15></td><td>
<form action="$regist" method="POST">
<input type=hidden name=mode value="past">
<input type=hidden name=ally value="$in{'ally'}">
<input type=hidden name=jpass value="$in{'jpass'}">
<input type=hidden name=cpass value="$in{'cpass'}">
<input type=hidden name=id value="$in{'id'}">
<input type=hidden name=pastlog value="$in{'pastlog'}">
검색어 <input type=text name=word size=35 value="$in{'word'}" class=f>
조건 <select name=cond class=f>
EOM
	if (!$in{'cond'}) { $in{'cond'} = "AND"; }
	foreach ("AND", "OR") {
		if ($in{'cond'} eq $_) {
			print "<option value=\"$_\" selected>$_\n";
		} else {
			print "<option value=\"$_\">$_\n";
		}
	}
	print "</select> 표시 <select name=view class=f>\n";
	if (!$in{'view'}) { $in{'view'} = 10; }
	foreach (10,15,20,25,50,100) {
		if ($in{'view'} == $_) {
			print "<option value=\"$_\" selected>$_건\n";
		} else {
			print "<option value=\"$_\">$_건\n";
		}
	}

	print <<EOM;
</select>
<input type=submit value="검색"></td>
</form>
</tr></table>
EOM

	$file = sprintf("%s%04d\.%s\.cgi", $pastdir,$in{'pastlog'},($in{'ally'} eq '' ? 0 : $in{'ally'}));

	# 검색 처리
	if ($in{'word'} ne "") {

		($i,$next,$back) = &search($file,$in{'word'},$in{'view'},$in{'cond'},0);

		$eword = &url_enc($in{'word'});
		if ($back >= 0) {
			print "[<a href=\"JavaScript:void(0)\" onClick=\"document.PAST.page.value='$back';document.PAST.submit();return false;\">이전 $in{'view'}건</a>]\n";
		}
		if ($next < $i) {
			print "[<a href=\"JavaScript:void(0)\" onClick=\"document.PAST.page.value='$next';document.PAST.submit();return false;\">다음 $in{'view'}건</a>]\n";
		}
		print "<form name=PAST method=\"POST\" action=\"$regist\">";
		print "<input type=hidden name=page value=\"\">";
		print "<input type=hidden name=mode value=\"past\">";
		print "<input type=hidden name=pastlog value=\"$in{'pastlog'}\">";
		print "<input type=hidden name=word value=\"$eword\">";
		print "<input type=hidden name=view value=\"$in{'view'}\">";
		print "<input type=hidden name=cond value=\"$in{'cond'}\">";
		print "<input type=hidden name=ally value=\"$in{'ally'}\">";
		print "<input type=hidden name=jpass value=\"$in{'jpass'}\">";
		print "<input type=hidden name=cpass value=\"$in{'cpass'}\">";
		print "<input type=hidden name=id value=\"$in{'id'}\">";
		print "</form>";
		print "</body></html>\n";
		exit;
	}

	print "<dl>\n";
	$i=0;
	open(IN,"$file") || &error("Open Error: $file");
	while (<IN>) {
		($no,$re,$dat,$nam,$eml,$sub,$com,$url,$idname,$allyidname,$turn,$hos,$pw,$col,$ico) = split(/<>/);

		if ($re eq "") { $i++; }
		if ($i < $page + 1) { next; }
		if ($i > $page + $pastView) { next; }

		if ($eml) { $nam = "<a href=\"mailto:$eml\">$nam</a>"; }
		if ($url) { $url = "&lt;<a href=\"$url\" target=\"_blank\">URL</a>&gt;"; }

		if ($re eq "") { print "<dt><hr>"; } else { print "<dd>"; }

		my $iName = '';
		if($allyidname ne '') {
			if($idname eq '0') {
				$iName = "${atMark}$ally_name[0]";
			} elsif($idname ne '') {
				$iName = "${atMark}${idname}${AfterName}";
			}
		}
		my $turnStr = " [턴<span class='turn'>$turn</span>] " if($turn);
		print "<span class='subject'>$sub</span>&nbsp;
		<b>$nam$iName</b> - $dat $url$turnStr<span class='number'>No.$no</span><br><br>\n";

		if(($dead ne '') || $owner || $amity) {
			1 while $com =~ s/(.*)(&lt;(amity)&gt;(.*)&lt;\/amity&gt;)/$1<span class=\'amity\'>$4<\/span>/i;
		} else {
			1 while $com =~ s/(.*)(&lt;(amity)&gt;(.*)&lt;\/amity&gt;)/$1/i;
		}

		if ($ico) {
			print "<table class='v'><tr><td><img src=\"${HimageDir}/$ico\"></td>
			<td width=10></td><td class='comment'><span style=\"color:$col;\">$com</span></td>
			</tr></table><br>\n";
		} else {
			print "<dd style='color:$col;'>$com</dd><br><br>\n";
		}
	}
	close(IN);
	print <<EOM;
<dt><hr>
</dl>
EOM

	# 페이지이동 버튼표시
	if ($page - $pastView >= 0 || $page + $pastView < $i) {
		&mvbtn($i, $pastView);
		print "<form name=MOVE method=\"POST\" action=\"$regist\">";
		print "<input type=hidden name=mode value=\"past\">";
		print "<input type=hidden name=pastlog value=\"$in{'pastlog'}\">";
		print "<input type=hidden name=page value=\"\">";
		print "<input type=hidden name=bl value=\"0\">";
		print "<input type=hidden name=ally value=\"$in{'ally'}\">";
		print "<input type=hidden name=jpass value=\"$in{'jpass'}\">";
		print "<input type=hidden name=cpass value=\"$in{'cpass'}\">";
		print "<input type=hidden name=id value=\"$in{'id'}\">";
		print "</form>\n";
	}

	print <<EOM;
</tr>
</table>
</body>
</html>
EOM
	exit;
}

#-------------------------------------------------
#  맹주 모드
#-------------------------------------------------
sub staff {

	if (!$StaffLevel && $in{'pwd'} ne "" && !checkPassword($Hally[$HidToAllyNumber{$in{'ally'}}], $in{'pwd'})) {
		&error("비밀번호가 틀렸습니다");
	}

	# 등록 키
	local($str_plain,$str_crypt);
	if ($regist_key) {
		require $registkeypl;

		($str_plain,$str_crypt) = &pcp_makekey;
	}

	if ($in{'comment'} eq "") {
		if ($ImageView == 1) { &header('ImageUp'); }
		else { &header; }
		print "[<a href=\"JavaScript:void(0)\" onClick=\"document.LINK.submit();return false;\">게시판으로 돌아가기</a>]\n";
		print "<form name=LINK method=\"POST\" action=\"$script\">";
		print "<input type=hidden name=ally value=\"$in{'ally'}\">";
		print "<input type=hidden name=jpass value=\"$in{'jpass'}\">";
		print "<input type=hidden name=cpass value=\"$in{'cpass'}\">";
		print "<input type=hidden name=id value=\"$in{'id'}\">";
		print "</form>";
		print "<table class='v' width='100%'><tr><th bgcolor=\"#800080\">\n";
		print "<font color=\"#FFFFFF\">${HallyTopName}모드</font>\n";
		print "</th></tr></table>\n";
	}
	if (!$StaffLevel && $in{'pwd'} eq "") {
		&enter('staff', 1);
	} else {
		my(@lines2, @new);
		# 로그 열기
		if($in{'comment'} ne '') {
			&formCheck; # 폼 입력 확인
			# 등록 키 확인
			if ($regist_key) {
				require $registkeypl;

				if ($in{'regikey'} !~ /^\d{4}$/) {
					&error("등록 키 입력이 올바르지 않습니다.<p>글쓰기 폼으로 돌아가 새로고침한 뒤 지정된 숫자를 입력해 주세요");
				}

				# 등록 키 확인
				# -1 : 키 불일치
				#  0 : 제한 시간 초과
				#  1 : 키 일치
				local($chk) = &registkey_chk($in{'regikey'}, $in{'str_crypt'});
				if ($chk == 0) {
					&error("등록 키 제한 시간이 지났습니다.<p>글쓰기 폼으로 돌아가 새로고침한 뒤 지정된 숫자를 다시 입력해 주세요");
				} elsif ($chk == -1) {
					&error("등록 키가 올바르지 않습니다.<p>글쓰기 폼으로 돌아가 새로고침한 뒤 지정된 숫자를 입력해 주세요");
				}
			}
			&get_time; # 시간 가져오기
			if ($lockMode) { &lock; } # 파일 잠금
			# URL 자동 링크
			#if ($autolink) { &auto_link($in{'comment'}); }
			# 비밀번호 암호화
			$pwd = &encrypt($in{'pwd'});
			my $iNum = $HidToNumber{$in{'id'}};
			my $idname = '';
			if(defined $iNum) {
				$idname = $Hislands[$iNum]->{'name'};
			} elsif($in{'id'} == 0) {
				$idname = 0;
			}
			my $allyidname = '';
			if($in{'ally'} ne '') {
				my($aFrom, $aTo) = split(/\-/, $in{'ally'});
				$allyidname = "<FONT COLOR=$allyCol[$aFrom]>$ally_head[$aFrom]</FONT>$ally_name[$aFrom]";
				if($aTo ne '') { $allyidname .= ",<FONT COLOR=$allyCol[$aTo]>$ally_head[$aTo]</FONT>$ally_name[$aTo]"; }
			}
			push(@new,"$no<><>$date<>$in{'name'}<>$in{'email'}<>$in{'sub'}<>$in{'comment'}<>$in{'url'}<>$idname<>$allyidname<>$HislandTurn<>$host<>$pwd<>$col[$in{'color'}]<>$in{'icon'}<>\n");
			open(OUT,">$logfile2") || &error("Write Error : $logfile2");
			print OUT @new;
			close(OUT);
			if ($lockMode) { &unlock; } # 파일 잠금 해제
			# 메일 처리
			if ($mailing == 1 && $in{'email'} ne $mailto) { &mail_to; }
			elsif ($mailing == 2) { &mail_to; }
			# 다시 불러오기
			if ($location) {
				if ($ENV{'PERLXS'} eq "PerlIS") {
					print "HTTP/1.0 302 Temporary Redirection\r\n";
					print "Content-type: text/html; charset=utf-8\n";
				}
				print "Location: $location\n\n";
			} else {
				&message('글이 정상적으로 처리되었습니다');
			}
			exit;
		}
		open(IN,"$logfile2") || &error("Open Error : $logfile2 (staff)");
		@lines2 = <IN>;
		close(IN);
		my($no,$reno,$dt,$name,$eml,$sub,$com,$url,$idname,$allyidname,$turn,$host,$pw,$color,$icon) = split(/<>/, $lines2[0]);
		$com =~ s/<br>/\n/g;
#		my $pattern = 'http\:[\w\.\~\-\/\?\&\+\=\:\@\%\;\#\%]+';
#		$com =~ s/<a href="$pattern" target='_top'>($pattern)<\/a>/$1/go;
		print <<"EOM";
<P><DIV align='center'><font size=4><B>●중요 공지●</B></font><br>
<P><span class='supplement'>게시판 상단에 중요한 알림 등을 올리고 싶다면 아래 폼에 입력해 주세요.<br>
표시하지 않으려면 「내용」 안의 글자를 모두 지우고 등록해 주세요.</span>
<form method="POST" action="$regist" method="POST">
<input type=hidden name=mode value="staff">
EOM
		&form($name,$eml,$url,$in{'pwd'},$cico,$ccol,$sub,$com);
		print "</form></DIV>\n</body></html>\n";
	}
	exit;
}

#-------------------------------------------------
#  외교 모드
#-------------------------------------------------
sub diplo {

	if (!$DiploLevel && $in{'pwd'} ne "" && !checkPassword($Hally[$HidToAllyNumber{$in{'ally'}}], $in{'pwd'})) {
		&error("비밀번호가 틀렸습니다");
	}

	# 등록 키
	local($str_plain,$str_crypt);
	if ($regist_key) {
		require $registkeypl;

		($str_plain,$str_crypt) = &pcp_makekey;
	}

	if (($in{'comment'} eq "") || ($in{'allyTo'} eq '')) {
		if ($ImageView == 1) { &header('ImageUp'); }
		else { &header; }
		print "[<a href=\"JavaScript:void(0)\" onClick=\"document.LINK.submit();return false;\">게시판으로 돌아가기</a>]\n";
		print "<form name=LINK method=\"POST\" action=\"$script\">";
		print "<input type=hidden name=ally value=\"$in{'ally'}\">";
		print "<input type=hidden name=jpass value=\"$in{'jpass'}\">";
		print "<input type=hidden name=cpass value=\"$in{'cpass'}\">";
		print "<input type=hidden name=id value=\"$in{'id'}\">";
		print "</form>";
		print "<table class='v' width='100%'><tr><th bgcolor=\"#800080\">\n";
		print "<font color=\"#FFFFFF\">외교 모드</font>\n";
		print "</th></tr></table>\n";
	}
	if (!$DiploLevel && $in{'pwd'} eq "") {
		&enter('diplo', 1);
	} else {
		# 로그 열기
		if($in{'comment'} ne '') {
			if($in{'allyTo'} ne '') {
				# 로그 파일
				my $logfile3 = "./${HbbsdirName}/$in{'allyTo'}$Hlogfile_name";
				$in{'ally'} = $in{'ally'} . '-' . $in{'allyTo'};
				&regist($logfile3, 0);
				&regist($logfile, 2);
			} else {
				print "<B><FONT COLOR='red'>보낼 동맹을 선택해 주세요.</FONT></B>";
				$cnam = $in{'name'};
				$ceml = $in{'email'};
				$curl = $in{'url'};
			}
		}
		my $allylist = '';
		my $p = 0;
		my $allyNumber = $HallyNumber - 1;
		foreach (0..$allyNumber) {
			my $aId = $Hally[$_]->{'id'};
			my $aName = $Hally[$_]->{'name'};
			if ($aId ne $in{'ally'} && $aName ne "") {
				$aName = "<FONT COLOR=$allyCol[$aId]>$ally_head[$aId]</FONT>$ally_name[$aId]";
				$allylist .= "<input type=radio name=allyTo value=\"$aId\">$aName\n";
				$p++;
				$allylist .= "<BR>" if($p == 3);
			}
		}
		if($in{'sub'} eq '제목 없음') { $in{'sub'} = ''; }
		print <<"EOM";
<P><DIV align='center'><font size=4><B>●외교 글쓰기 폼●</B></font><br>
<P><span class='supplement'>등록하면 즉시 <b>상대 동맹 게시판</b>으로 전송됩니다.<br>
<b>보낼 곳을 틀리지 않도록 주의</b>해 주세요.<br>
전송한 외교 문서는 삭제하거나 편집할 수 없습니다.<br>
반드시 동맹 내부에서 상의한 뒤 대표자가 문서를 발송해 주세요.<br>
</span>
<form action="$regist" method="POST">
<input type=hidden name=mode value="diplo">
<blockquote>
<table class='v'>
<tr><td nowrap><b>보낼 곳</b></td>
<td>$allylist</td>
</tr>
<tr><td colspan=2>
EOM
		&form($cnam,$ceml,$curl,$in{'pwd'},$cico,$ccol,$in{'sub'},$in{'comment'});
		print "</form></td></tr></table></blockquote></DIV>\n</body></html>\n";
	}
	exit;
}

#-------------------------------------------------
#  금지어
#-------------------------------------------------
sub deny_word {
	local($word) = @_;

	local($flg);
	foreach ( split(/,+/, $deny_word) ) {
		if (index($word,$_) >= 0) { $flg=1; last; }
	}
	if ($flg) { &error("부적절한 게시글이어서 접수할 수 없습니다"); }
}

#-------------------------------------------------
#  등록 키 확인
#-------------------------------------------------
sub regikey_chk {
	local($flg,$id,$key,$tim2,$key2,$chk,@data);
	open(IN,"$keyfile");
	while (<IN>) {
		($id,$key,$tim2) = split(/:/);

		# 30분 이상 지난 데이터는 무시
		next if (time - $tim2 > 1800);

		if ($in{'regi_id'} == $id) {
			$flg = 1;
			$key2 = $key;
		}
		push(@data,$_);
	}
	close(IN);

	if (!$flg) { &error("등록 키가 올바르지 않습니다"); }

	# 대조
	$chk = &decrypt($in{'regikey'}, $key2);
	if ($chk != 1) { &error("등록 키가 올바르지 않습니다"); }

	open(OUT,">$keyfile");
	print OUT @data;
	close(OUT);
}

__END__
