#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}
#----------------------------------------------------------------------
# 하코니와 제도 RA JS ver4.xx
# 게임 설정모듈(ver1.00)
# 사용 조건과 사용 방법은 hako-readme.txt 파일을 참조해 주세요
#
# 우라에와 -uRAniwa-: http://snow.prohosting.com/awinokah/
#----------------------------------------------------------------------
#----------------------------------------------------------------------
# 각종 설정 값
# 아래 설정 값을 서버 환경에 맞게 변경해 주세요.
#----------------------------------------------------------------------
#----------------------------------------
# 게임의 진행야 파일등
#----------------------------------------
# 게임종료 턴 수
# 0으로 하면 자동 종료하지 않습니다
$HgameLimitTurn = 0;

# 실시간 사용(0:사용하지 않음,1:사용함)
$Hrealtimer = 0;

# 톱 페이지에 표시할 섬의 수
# (이보다 늘어나면 여러 페이지로 분할됩니다)
$HviewIslandCount = 30;

# 백업을 몇 턴오키에취는 가
$HbackupTurn = 12;

# 백업을 몇 회분 남음습니까
$HbackupTimes = 4;

# 발견 로그유지 줄 수(10보다 크면이면 표시가 깨집니다. 아래의 수치에서 조정해 주세요)
$HhistoryMax = 10;
# 글 표시부의 최대의 고사.
# height 지정값을 초과하면 스크롤 막대가 표시됩니다.
$HdivHeight = 150; # <DIV style="overflow:auto; height:${HdivHeight}px;">

# Hakoniwa Cup 로그글 표시부의 최대의 고사.
# height 지정값을 초과하면 스크롤 막대가 표시됩니다.
$HdivHeight2 = 100; # <DIV style="overflow:auto; height:${HdivHeight2}px;">

# 포기 명령 자동 입력 턴 수
$HgiveupTurn = 84;

# 공격계, 지원계, 괴수출현에서 섬이 보호되는 기준 인구
# (이 인구를 초과할 때까지개발만 가능합니다)
$HguardPop = 500; # 5만 명

# 로컬 게시판 익명 발언 허용 여부(0:금지,1:허가)
$HlbbsAnon = 0;

# 로컬 게시판 발언에 작성자 이름을 표시할지(0:표시하지 않음,1:표시함)
$HlbbsSpeaker = 1;

# 로컬 게시판 로그를 이관할지(0:이관하지 않음,1:이관함)
# (가동안의 게시판 로그를 극비 발언에 대응하도록 이행할 수 있습니다)
$HlbbsOldToNew = 1;

# 다른 섬의 로컬 게시판에 글을 쓸 때 필요한 비용(0:무료 1:유료)
$HlbbsMoneyPublic = 0; # 공개
$HlbbsMoneySecret = 100; # 극비

# 사거리 안에 괴수·거대괴수·오염된 바다가 없으면, 미사일 발사를 중지할까요?(0:하지 않음,1:함)
$HtargetMonster = 1;

# ST 미사일을 사용할까요?(0:금지)
$HuseMissileST = 1;

# 괴수 파견을 사용할까요?(0:금지)
$HuseSendMonster = 1;

# 기념비발사를 사용할까요?(0:금지)
$HuseBigMissile = 1;

# 전장을 공격할 수 있는 미사일 종류
@HkindBFM = (31); # 허가하다 미사일 발사 명령의 수치
# 전체 OK 이 경우 보통 PP SPP ST 핵 융성 파괴
@HkindBFM = (31, 32, 36, 33, 37, 38, 34);

# 다른 사람이 자금을 볼 수 없게 할지(0:보이지 않음 1:표시 가능 2:100의 위에서 반올림 3:1000의 위에서 반올림)
$HhideMoneyMode = 1;

# 다른 사람에게서 미사일 발사 가능 횟수를 볼 수 없게 할지(0:보이지 않음 1:표시 가능 2:10의 위에서 반올림)
$HhideMissileMode = 1;

# 군사 물자가 없으면 미사일을 발사할 수 없게 할지(0:사용하지 않음 1:사용)
$HuseArmSupply = 0;
# 군사 물자 조달을 턴 소비 없이 할지(0:하지 않음 1:하다)
$HnoturnArmSupply = 0;

# 여러 미사일 발사 명령을 일괄 실행할 수 있도록 할지(0:할 수 없음 1:할 수 있음)
$HanyMissileMode = 0;

# 유전, 놀이공원, 어선계 수입(수확)로그를1본화할까요?(0:하지 않음 1:하다(유지 식량을 차감) 2:하다(유지 식량을 차감하지 않음))
$HlogOmit1 = 1;

# 개간 로그를1본화할까요?(0:하지 않음 1:좌표있음 2:좌표없음)
$HlogOmit2 = 1;

# 신규 작성 시 대학·항구도시·뉴타운을 1개씩, 인공위성을 1개 처음부터 보유하게 할지 (0: 아니오 1: 예)
$HeasyMode = 0;

# JavaScript 의일부를 외부 파일화할까요?(0:하지 않음 1:하다)
$HextraJs = 0;

#----------------------------------------
# 자금, 식량등의 설정 값와 단위
#----------------------------------------
# 초기 자금
$HinitialMoney = 2000;

# 초기 식량
$HinitialFood = 200;

# 최대 자금
$HmaximumMoney = 999999;

# 최대식량
$HmaximumFood = 99999;

# 자금의 단위
$HunitMoney = '억 엔';

# 식량의 단위
$HunitFood = '00톤';

# 인구의 단위
$HunitPop = '00인';

# 면적의 단위
$HunitArea = '00만 평';

# 나무 수의 단위
$HunitTree = '00본';

# 목재 단위당 판매 수입
$HtreeValue = 5;

# 이름 변경의 비용
$HcostChangeName = 500;

# 인구1단위주변의 식량소비량
$HeatenFood = 0.2;

# 미사일의 수의 단위
$HunitMissile = '발';

# 괴수의 수의 단위
$HunitMonster = '마리';
#----------------------------------------
# 기지의 경험치
#----------------------------------------
# 경험치의 최댓값
$HmaxExpPoint = 200; # 단, 최대라도255까지

# 레벨의 최댓값
$maxBaseLevel = 5; # 미사일 기지
$maxSBaseLevel = 4; # 해저 기지

# 경험치가 몇 점이면 레벨업할지
@baseLevelUp = (20, 60, 120, 200);	# 미사일 기지
@sBaseLevelUp = (50, 100, 200);		# 해저 기지

#----------------------------------------
# 섬주의 등급
#----------------------------------------
$HouseLevel[1] = 15000; # 간이주택
$HouseLevel[2] = 20000; # 주택
$HouseLevel[3] = 25000; # 고급주택
$HouseLevel[4] = 30000; # 저택
$HouseLevel[5] = 35000; # 대저택
$HouseLevel[6] = 40000; # 고급 저택
$HouseLevel[7] = 45000; # 성
$HouseLevel[8] = 50000; # 거성
$HouseLevel[9] = 55000; # 황금성

#----------------------------------------
# 방위 시설의 자폭
#----------------------------------------
# 괴수에게 밟혔을 때 자폭하면 1, 아니면 0
$HdBaseAuto = 1;

# 자기 섬이격했음 미사일은 방어되지 않음 수 있도록로 라면1, 하지 않으면0
$HdBaseSelfNoDefence	= 0; # 방위 시설
$HdProcitySelfNoDefence	= 0; # 방위 도시

# 방위 시설이 100% 방어하지 않게 하려면 1, 아니면 0
$HdBaseNoPerfect	= 0; # 방위 시설
$HdProcityNoPerfect	= 0; # 방위 도시
$HdNoPerfectP		= 10; # 방위에 실패하다확률(10%)

# 방위 시설에 직접 명중한 미사일도 방어하려면 1, 아니면 0
$HdBaseSelfDefence = 0; # 방위 시설 & 방위 도시

#----------------------------------------
# 재해
#----------------------------------------
# 수확, 수입배율(일반을1토한 경우에 대한 비율%)
# 계절의 도입 설정은 hako-init.cgi
# 0:계절없음			 0, 1월, 2월, 3월, 4월, 5월, 6월, 7월, 8월, 9월,10월,11월,12월
@Hfood1Incom		= ( 100, 80, 80, 80, 100, 100, 100, 100, 100, 100, 120, 120, 120); # 식량(농업)
@Hfood2Incom		= ( 100, 100, 100, 100, 100, 100, 100, 80, 80, 80, 120, 120, 120); # 식량(어업)
@Hmoney1Incom		= ( 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100); # 자금(공업)
@Hmoney2Incom		= ( 100, 100, 80, 120, 120, 100, 80, 120, 100, 100, 100, 100, 120); # 자금(상업업)
# 식량소비량(일반을1토한 경우에 대한 비율%)
@HeatenFoodS 		= ( 100, 90, 90, 90, 100, 100, 100, 90, 80, 90, 150, 150, 150);

# 일반 재해 발생률(확률은0.1%단위)
# 0:계절없음		0, 1, 2, 3, 4, 5, 6, 7, 8, 9,10,11,12월
@HdisEarthquake	= ( 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5); # 지진
@HdisTsunami	= ( 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5); # 쓰나미
@HdisTyphoon	= ( 5, 1, 1, 1, 2, 3, 5, 7, 8, 9, 9, 5, 2); # 태풍
@HdisMeteo		= ( 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5); # 운석
@HdisHugeMeteo	= ( 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2); # 거대운석
@HdisEruption	= ( 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5); # 분화
@HdisFire		= ( 5, 9, 9, 8, 7, 5, 3, 2, 1, 1, 1, 2, 5); # 화재
@HdisMaizo		= (10,10,10,10,10,10,10,10,10,10,10,10,10); # 매장금

# 지반 침하
$HdisFallBorder = 200; # 안정 전체한계의 면적(Hex 수)
@HdisFalldown = (15,15,15,15,15,15,15,15,15,15,15,15,15); # 그 면적를 초과한 경우 확률

# 괴수
$HdisMonsBorder1 = 5000; # 인구 기준1(괴수레벨1)
$HdisMonsBorder2 = 7500; # 인구 기준2(괴수레벨2)
$HdisMonsBorder3 = 9000; # 인구 기준3(괴수레벨3)
$HdisMonsBorder4 = 10000; # 인구 기준4(괴수레벨4)
@HdisMonster	 =( 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3); # 단위 면적 주변의 출현율(0.01%단위)

# 종류
$HmonsterNumber = 31;

# 각 기준에서 출현하는 괴수 번호의 최대값
$HmonsterLevel1 = 4; # 다크이노라까지
$HmonsterLevel2 = 8; # 옛짐승왕충까지
$HmonsterLevel3 = 12; # 희귀짐승은 네는 무까지
$HmonsterLevel4 = 22; # 아이스 스콜피온까지(전체)

$HmonsterDefence = 500; # 괴수가 미사일을 튕겨낼 확률

# 이름
@HmonsterName =
(
	 '인공메카이노라',		# 0(인공)
	 '괴수이노라',			# 1
	 '괴수 산지라',		# 2
	 '괴수레드이노라',	# 3
	 '괴수다크이노라',	# 4
	 '영짐승이노라 고스트',	# 5
	 '괴수고래',			# 6
	 '괴수킹 이노라',	# 7
	 '옛짐승왕충',			# 8
	 '굳음짐승했습니다는 무',		# 9
	 '괴수바리모아',		# 10
	 '기묘짐승슬라임',		# 11
	 '희귀짐승은 네는 무',		# 12
	 '천사미카엘',		# 13
	 '슬라임 레전드',	# 14
	 '마수 레이지라',		# 15
	 '마수 퀸',	# 16
	 '인공괴수f02',			# 17
	 '천사 우리엘',		# 18
	 '마술사 아루브',		# 19
	 '추락천사이세리아',		# 20
	 '마왕 사탄',			# 21
	 '아이스 스콜피온', # 22
	 '괴수킹 이노라',	# 23
	 '괴수킹 이노라',	# 24
	 '괴수킹 이노라',	# 25
	 '괴수킹 이노라',	# 26
	 '괴수킹 이노라',	# 27
	 '관광 이노라',	# 28
	 '신짐승테트라',			# 29
	 '초신 수테트라'			# 30
);

# 최소체력, 체력의 폭, 특수 능력, 경험치, 시체의 가격
#					 0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30
@HmonsterBHP	 = ( 2, 1, 1, 3, 2, 1, 4, 7, 6, 5, 7, 3, 5,10, 7, 9, 9, 8, 9, 2, 7,10, 9, 7, 7, 7, 7, 7, 0, 5,11);
@HmonsterDHP	 = ( 0, 2, 2, 2, 2, 0, 2, 2, 0, 2, 2, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 2, 2, 2, 2, 0, 0, 0);
@HmonsterSpecial = ( 0, 0, 3, 5, 1, 2, 4, 0, 1, 8, 5, 0, 2, 0, 8, 8, 5, 2, 0, 1, 7, 0, 2,10,11,12,13, 2, 0, 6, 0);
@HmonsterExp	 = ( 5, 5, 7,12,15,10,20,30,45,40,35, 5,40,99,70,55,60,85,90,95, 0,80,40,30,30,30,30,30, 0, 7,99);
@HmonsterValue = ( 0, 400, 500, 1000, 800, 300, 1500, 5555, 2500, 3500, 3000, 100, 3500, 99999, 27000, 10000, 12000, 48000, 80000, 95000, 85000, 0, 4000, 5555, 5555, 5555, 5555, 5555, 1, 2000, 200000);

# 특수 능력의 내용은,
# 0 특별히 없음
# 1 빠른 이동(최대 2걸음)
# 2족 보행이지만 속도는 알 수 없음(최대 몇 칸 이동하는지 불명)
# 3 홀 수 턴은 경화
# 4 짝 수 턴은 경화
# 5 미사일요격
# 6 괴수를 공격
# 7 충격파1
# 8 무작위나 턴에경화
# 9 아이스 스톰
# 11 괴수가주변을 불태우는(주변 6칸괴멸)
# 12 빈사 상태가 되면 대폭발(주변 6칸괴멸)
# 13 동료를 호출부
# 14 와푸하다
# 15 와푸하다(주변의 지형도권키포함무)

# 이미지 파일
@HmonsterImage =
	(
	 'monster7.gif',
	 'monster0.gif',
	 'monster5.gif',
	 'monster1.gif',
	 'monster2.gif',
	 'monster8.gif',
	 'monster6.gif',
	 'monster3.gif',
	 'monster18.gif',
	 'monster25.gif',
	 'monster13.gif',
	 'monster14.gif',
	 'monster16.gif',
	 'monster17.gif',
	 'monster19.gif',
	 'monster22.gif',
	 'monster21.gif',
	 'f02.gif',
	 'monster23.gif',
	 'monster24.gif',
	 'monster26.gif',
	 'monster27.gif',
	 'monster29.gif',
	 'monster3.gif',
	 'monster3.gif',
	 'monster3.gif',
	 'monster3.gif',
	 'monster3.gif',
	 'monster30.gif',
	 'monster10.gif',
	 'monster28.gif'
	 );

# 이미지 파일그2(경화 중)
@HmonsterImage2 =
	('', '', 'monster4.gif', '', '', '', 'monster4.gif', '', '', 'monster25.gif', '', '', '', '', 'monster20.gif', 'monster4.gif', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

#----------------------------------------
# 거대괴수
#----------------------------------------
# 거대괴수가출현하다?(0:하지 않음,1:함)
$HhugeMonsterAppear = 1;
$HdisHugeBorder = 10000; # 인구 기준
$HdisHuge = 1;	# 단위 면적 주변의 출현율(0.01%단위)

# 종류
$HhugeMonsterNumber = 3;

# 거대괴수의 이름
@HhugeMonsterName = (
	'도지라', # 0
	'한질라', # 1
	'방위이노라', # 2
);

# 최소체력, 체력의 폭, 특수 능력, 경험치, 시체의 가격
@HhugeMonsterBHP	 = ( 10, 2, 2);
@HhugeMonsterDHP	 = ( 0, 0, 0);
#@HhugeMonsterSpecial = ( 0x1300, 0x2, 0x2400);
@HhugeMonsterSpecial = ( 0x2, 0x2, 0x2);
@HhugeMonsterExp	 = ( 5, 5, 5);
@HhugeMonsterValue = ( 0, 0, 0);

# 특수 능력의 내용은,
# 0x0 특별히 없음
# 0x1 빠른 이동(최대 2걸음)
# 0x2 2족 보행이지만 속도는 알 수 없음(최대 몇 칸 이동하는지 불명)
# 0x10 홀 수 턴은 경화
# 0x20 짝 수 턴은 경화
# 0x40 무작위 경화
# 0x100 무작위·와푸(체력이짝 수에 한 때다른 섬으로 푸)
# 0x200 출현하고 있는 섬에서 공격만유효
# 0x400 개체 재생을 무작위로 실행
# 0x1000 출현하고 있는 섬에서 다른 섬으로 이민
# 0x2000 코어방위(주변모두를 지우지 않는 한 코어로 공격이 무효)
$HpRebody = 50; # 0x400(체력 재생을 무작위로 수행) 능력의 재생 확률(%)

# 이미지 파일
@HhugeMonsterImage = (
	['gojira.gif', 'gojira6.gif', 'gojira7.gif', 'gojira8.gif', 'gojira9.gif', 'gojira10.gif', 'gojira11.gif'],
	['gojira.gif', '', 'gojira7.gif', '', 'gojira9.gif', '', 'gojira11.gif'],
	['monster0.gif', 'monster0.gif', '', 'monster0.gif', '', 'monster0.gif', ''],
);

# 이미지 파일(톱 페이지 표시용)
@HhugeMonsterImageS = (
	'gojira.gif',
	'gojira.gif',
	'gojira.gif',
);

# 이미지 파일그2(경화 중)
@HhugeMonsterImage2 = (
	['gojira.gif', 'gojira6.gif', 'gojira7.gif', 'gojira8.gif', 'gojira9.gif', 'gojira10.gif', 'gojira11.gif'],
	['gojira.gif', '', 'gojira7.gif', '', 'gojira9.gif', '', 'gojira11.gif'],
	['monster0.gif', 'monster0.gif', '', 'monster0.gif', '', 'monster0.gif', ''],
);

# 이미지 파일그3(바다에 있는)
@HhugeMonsterImage3 = (
	['gojira.gif', 'gojira0.gif', 'gojira1.gif', 'gojira2.gif', 'gojira3.gif', 'gojira4.gif', 'gojira5.gif'],
	['gojira.gif', '', 'gojira1.gif', '', 'gojira3.gif', '', 'gojira5.gif'],
	['monster00.gif', 'monster00.gif', '', 'monster00.gif', '', 'monster00.gif', ''],
);

# 이미지 파일그4(바다에서 경화)
@HhugeMonsterImage4 = (
	['gojira.gif', 'gojira0.gif', 'gojira1.gif', 'gojira2.gif', 'gojira3.gif', 'gojira4.gif', 'gojira5.gif'],
	['gojira.gif', '', 'gojira1.gif', '', 'gojira3.gif', '', 'gojira5.gif'],
	['monster00.gif', 'monster00.gif', '', 'monster00.gif', '', 'monster00.gif', ''],
);

#----------------------------------------
# 유전
#----------------------------------------
# 유전 수입
$HoilMoney = 2500;

# 유전의 고갈확률
$HoilRatio = 80;

# 온천의 고갈확률
$HonsenRatio = 10;

#----------------------------------------
# 기념비
#----------------------------------------
# 몇종류있는 지
$HmonumentNumber = 70;

# 이름
@HmonumentName =
	(
	 '모노리스',		# 0
	 '성나무',			# 1
	 '전쟁이의 비석',		# 2
	 '라스카루',		# 3
	 '관통',			# 4
	 '요제후',		# 5
	 '쿠마',			# 6
	 '쿠마',			# 7
	 '쿠마',			# 8
	 '눈다루마',		# 9
	 '모아이',			# 10
	 '지구의 식',			# 11
	 '바구',			# 12
	 '휴지통',			# 13
	 '다크이노라상',	# 14
	 '테트라상',		# 15
	 '는네는 무상',		# 16
	 '로켓',		# 17
	 '피라미도',		# 18
	 '아사가오',		# 19
	 '바라(적)',		# 20
	 '바라(노랑)',		# 21
	 '팬지',		# 22
	 '선인장(원형형)',	# 23
	 '선인장(소형)',	# 24
	 '마방진',
	 '신전',
	 '신사',
	 '휴지통',
	 '휴지통',
	 '휴지통',		 # 30
	 '휴지통',
	 '휴지통',
	 '휴지통',
	 '휴지통',
	 '휴지통',
	 '휴지통',
	 '휴지통',
	 '휴지통',
	 '휴지통',
	 '휴지통',		 # 40
	 '휴지통',
	 '휴지통',
	 '휴지통',
	 '휴지통',
	 '휴지통',
	 '휴지통',
	 '휴지통',
	 '휴지통',
	 '휴지통',
	 '휴지통',		 # 50
	 '휴지통',
	 '휴지통',
	 '휴지통',
	 '휴지통',
	 '휴지통',
	 '휴지통',
	 '휴지통',
	 '휴지통',
	 '휴지통',
	 '휴지통',		 # 60
	 '휴지통',
	 '휴지통',
	 '휴지통',
	 '휴지통',
	 '휴지통',
	 '휴지통',
	 '휴지통',
	 '휴지통',
	 '휴지통',
	 '휴지통',		 # 70
	 '휴지통',
	 '휴지통',
	 '휴지통',
	 '암석',
	 '지석',
	 '빙석',
	 '풍석',
	 '염석',
	 '광석',
	 '알',			 # 80
	 '알',
	 '알',
	 '알',
	 '고대 유적',
	 'Millennium 크리스마스트리',
	 '파괴된 침략자',
	 '왕충의 탈피 껍질',
	 '벚꽃',
	 '향일아오이',
	 '은은 행',		 # 90
	 '크리스마스트리2001',
	 '눈우사기',
	 '행복의 여신상',
	 '모노리스'
	);

# 이미지 파일
@HmonumentImage =
	(
	 'monument0.gif',	 # 0
	 'monument5.gif',
	 'monument3.gif',
	 'monument12.gif',
	 'monument11.gif',
	 'monument13.gif',
	 'monument16.gif',
	 'monument15.gif',
	 'monument14.gif',
	 'monument17.gif',
	 'monument18.gif',	 # 10
	 'monument19.gif',
	 'monument20.gif',
	 'monument21.gif',
	 'monument4.gif',
	 'monument22.gif',
	 'monument23.gif',
	 'monument27.gif',
	 'monument29.gif',
	 'monument30.gif',
	 'monument31.gif',	 # 20
	 'monument32.gif',
	 'monument33.gif',
	 'monument34.gif',
	 'monument35.gif',
	 'monument40.gif',
	 'monument46.gif',
	 'monument47.gif',
	 'monument21.gif',
	 'monument21.gif',
	 'monument21.gif',	 # 30
	 'monument21.gif',
	 'monument21.gif',
	 'monument21.gif',
	 'monument21.gif',
	 'monument21.gif',
	 'monument21.gif',
	 'monument21.gif',
	 'monument21.gif',
	 'monument21.gif',
	 'monument21.gif',	 # 40
	 'monument21.gif',
	 'monument21.gif',
	 'monument21.gif',
	 'monument21.gif',
	 'monument21.gif',
	 'monument21.gif',
	 'monument21.gif',
	 'monument21.gif',
	 'monument21.gif',
	 'monument21.gif',	 # 50
	 'monument21.gif',
	 'monument21.gif',
	 'monument21.gif',
	 'monument21.gif',
	 'monument21.gif',
	 'monument21.gif',
	 'monument21.gif',
	 'monument21.gif',
	 'monument21.gif',
	 'monument21.gif',	 # 60
	 'monument21.gif',
	 'monument21.gif',
	 'monument21.gif',
	 'monument21.gif',
	 'monument21.gif',
	 'monument21.gif',
	 'monument21.gif',
	 'monument21.gif',
	 'monument21.gif',
	 'monument21.gif',	 # 70
	 'monument21.gif',
	 'monument21.gif',
	 'monument21.gif',
	 'monument53.gif',
	 'monument52.gif',
	 'monument48.gif',
	 'monument49.gif',
	 'monument50.gif',
	 'monument51.gif',
	 'monument41.gif',	 # 80
	 'monument42.gif',
	 'monument43.gif',
	 'monument44.gif',
	 'monument45.gif',
	 'monument9.gif',
	 'monument24.gif',
	 'monument25.gif',
	 'monument26.gif',
	 'monument28.gif',
	 'monument36.gif',	 # 90
	 'monument37.gif',
	 'monument38.gif',
	 'monument54.gif',
	 'monument0.gif'
	 );

#----------------------------------------
# 선박
#----------------------------------------
# 몇종류있는 지
$HfuneNumber = 12;

# 이름
@HfuneName =
	(
	 '소형어선',
	 '소형어선',
	 '안형어선',
	 '해저 탐사선',
	 '범선',
	 '대형어선',
	 '고속어선',
	 '해저 탐사선·개정',
	 '호화려고객선박 TITANIC',
	 '전함 RENAS',
	 '전함 ERADICATE',
	 '어선 MASTER',
	 '모노리스',
	 '모노리스',
	 '모노리스',
	 '모노리스',
	 '모노리스',
	 '모노리스',
	 '모노리스',
	 '전함 ERADICATE·개정'
	);

@HfuneSpecial = ( 0, 0, 0, 0, 0, 0, 1, 2, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 5, 0);
# 특수 능력의 내용은,
# 0 특별히 없음
# 1 빠른 이동(최대 2걸음)
# 2족 보행이지만 속도는 알 수 없음(최대 몇 칸 이동하는지 불명)

# 이미지 파일
@HfuneImage =
	(
	 'fune1.gif',
	 'fune1.gif',
	 'fune2.gif',
	 'fune5.gif',
	 'fune4.gif',
	 'fune3.gif',
	 'fune6.gif',
	 'fune5.gif',
	 'fune7.gif',
	 'fune8.gif',
	 'fune9.gif',
	 'fune10.gif',
	 'monument0.gif',
	 'monument0.gif',
	 'monument0.gif',
	 'monument0.gif',
	 'monument0.gif',
	 'monument0.gif',
	 'monument0.gif',
	 'fune11.gif'
	 );

#----------------------------------------
# 인공위성
#----------------------------------------
# 몇종류있는 지
$HeiseiNumber = 6;

# 이름
@HeiseiName =
	(
	 '기상위성',
	 '기상위성',
	 '관측위성',
	 '요격위성',
	 '군사위성',
	 '방위위성',
	 '비정상'
	);

# 이미지 파일
@HeiseiImage =
	(
	 'kisho.gif',
	 'kisho.gif',
	 'kansoku.gif',
	 'geigeki.gif',
	 'gunji.gif',
	 'bouei.gif',
	 'ire.gif'
	 );

#----------------------------------------
# 수상 관계
#----------------------------------------
# 턴잔을 몇 매 턴출습니까
$HturnPrizeUnit = 100;

# 상의 이름
$Hprize[0] = '턴잔';
$Hprize[1] = '번영상';
$Hprize[2] = '초과 번영상';
$Hprize[3] = '궁극번영상';
$Hprize[4] = '평화상';
$Hprize[5] = '초과 평화상';
$Hprize[6] = '궁극평화상';
$Hprize[7] = '재난상';
$Hprize[8] = '초과 재난상';
$Hprize[9] = '궁극재난상';

#----------------------------------------------------------------------
# 기타 확장용 설정(기본적으로 변경 불가)
#----------------------------------------------------------------------
# ext[0] 진영 id (미사용)
# ext[1] 공로 실적 point
# ext[2] 파괴한 방위 시설의 수
# ext[3] 파괴한 미사일 기지의 수
# ext[4] 구출한 난민의 합계인구
# ext[5] 피해를 받을 미사일 수
# ext[6] 발사한 미사일 수
# ext[7] 방위 시설에서 장전된 미사일 수
#----------------------------------------
# 입력문자 수의 제한(전체 문자 수에서 지정)
#----------------------------------------
# 문자제한을 초과 했습니다 때, 처리를 안판단할까요?(0:하지 않음 1:하다)
$HlengthAlert = 0;

$HlengthIslandName = 15; # 섬 이름
$HlengthOwnerName = 15; # 섬의 소유자의 이름
$HlengthMessage = 40; # 톱 페이지에 표시되는 각 섬의 코멘트
$HlengthLbbsName = 15; # '관광 게시판'의게시자 이름
$HlengthLbbsMessage = 40; # '관광 게시판'의게시
$HlengthYoso = 30; # 예상란
$HlengthShuto = 15; # 수도 이름
$HlengthAllyName = 15; # 동맹 이름
$HlengthAllyComment = 40; # '각 동맹 상황' 화면에 표시되는 맹주의 코멘트
$HlengthAllyTitle = 30; # '동맹 정보'란 화면에 표시되는 맹주 메시지 제목
$HlengthAllyMessage = 1500; # '동맹 정보'란 화면에 표시되는 맹주 메시지
$HlengthPresentLog = 100; # 관리자가 지급한 선물 모드의 메시지
#----------------------------------------
# 화면 표시 관련
#----------------------------------------
# 태그
# 제목문자
$HtagTitle_ = '<div class="title">';
$H_tagTitle = '</div>';

# 큰 글자
$HtagBig_ = '<span class="big">';
$H_tagBig = '</span>';

# 섬 이름 등
$HtagName_ = '<span class="islName">';
$H_tagName = '</span>';

# 숨김 처리하지 않은 섬 이름
$HtagName2_ = '<span class="islName2">';
$H_tagName2 = '</span>';

# 순위 번호 등
$HtagNumber_ = '<span class="number">';
$H_tagNumber = '</span>';

# 순위표 머리글
$HtagTH_ = '<span class="head">';
$H_tagTH = '</span>';

# toto 표 머리글
$HtagtTH_ = '<span class="headToTo">';
$H_tagtTH = '</span>';

# 개발계획의 이름
$HtagComName_ = '<span class="command">';
$H_tagComName = '</span>';

# 재해
$HtagDisaster_ = '<span class="disaster">';
$H_tagDisaster = '</span>';

# 로컬 게시판, 관광객의 표시 문자
$HtagLbbsSS_ = '<span class="lbbsSS">';
$H_tagLbbsSS = '</span>';

# 로컬 게시판, 섬주의 표시 문자
$HtagLbbsOW_ = '<span class="lbbsOW">';
$H_tagLbbsOW = '</span>';

# 자금
$HtagMoney_ = '<span class="money">';
$H_tagMoney = '</span>';

# 식량
$HtagFood_ = '<span class="food">';
$H_tagFood = '</span>';

# 하코니와 컵 승리
$HtagWin_ = '<span class="HCwin">';
$H_tagWin = '</span>';

# 하코니와 컵 패배
$HtagLose_ = '<span class="HClose">';
$H_tagLose = '</span>';

# 일반 문자색
$HnormalColor_ = '<span class="normal">';
$H_normalColor = '</span>';

# 순위표, 세루의 속성
$HbgTitleCell = 'class=TitleCell'; # 순위표 머리글시
$HbgNumberCell = 'class=NumberCell'; # 순위표순위
$HbgNameCell = 'class=NameCell'; # 순위표 섬 이름
$HbgInfoCell = 'class=InfoCell'; # 순위표 섬의 정보
$HbgCommentCell = 'class=CommentCell'; # 순위표코멘트란
$HbgInputCell = 'class=InputCell'; # 개발계획양식
$HbgMapCell = 'class=MapCell'; # 개발계획지도
$HbgCommandCell = 'class=CommandCell'; # 개발계획입력완료미계획
$HbgPoinCell = 'class=PoinCell'; # Point 란
$HbgTotoCell = 'class=TotoCell'; # toto 란

#----------------------------------------------------------------------
# 아래쪽 스크립트는 변경을 전제로 하지 않습니다.
# 그래도 문제는 없습니다.
# 명령 이름과 가격 등은 알아보기 쉽게 두는 편이 좋습니다.
#----------------------------------------------------------------------

#----------------------------------------------------------------------
# 각종 상수
#----------------------------------------------------------------------
# 지형 번호
$HlandSea		= 0; # 바다
$HlandWaste		= 1; # 황무지
$HlandPlains	= 2; # 평지
$HlandTown		= 3; # 마을 계열
$HlandForest	= 4; # 숲
$HlandFarm		= 5; # 농장
$HlandFactory	= 6; # 공장
$HlandBase		= 7; # 미사일 기지
$HlandDefence	= 8; # 방위 시설
$HlandMountain	= 9; # 산
$HlandMonster	= 10; # 괴수
$HlandSbase		= 11; # 해저 기지
$HlandOil		= 12; # 해저 유전
$HlandMonument	= 13; # 기념비
$HlandHaribote	= 14; # 가짜 시설
$HlandSeacity	= 15; # 해저 도시
$HlandPark		= 16; # 놀이공원
$HlandMinato	= 17; # 항구
$HlandFune		= 18; # 선박
$HlandMine		= 19; # 지뢰
$HlandNursery	= 20; # 양식장
$HlandKyujo		= 21; # 야구장
$HlandUmiamu	= 22; # 해상 시설
$HlandFoodim	= 23; # 식품 연구소
$HlandProcity	= 24; # 방재 도시
$HlandGold		= 25; # 금광산
$HlandSeki		= 26; # 관문
$HlandRottenSea	= 27; # 오염된 바다
$HlandNewtown	= 28; # 뉴타운
$HlandBigtown	= 29; # 현대 도시
$HlandSeatown	= 30; # 해저뉴
$HlandFarmchi	= 31; # 양계장
$HlandFarmpic	= 32; # 양돈장
$HlandFarmcow	= 33; # 목장
$HlandCollege	= 34; # 대학
$HlandFrocity	= 35; # 해상 도시
$HlandSunahama	= 36; # 해변
$HlandOnsen		= 37; # 온천
$HlandHouse		= 38; # 섬주의 가
$HlandShuto		= 39; # 수도
$HlandUmishuto	= 40; # 해저 수도
$HlandIce		= 41; # 빙하
$HlandRizort	= 42; # 리조트지
$HlandBettown	= 43; # 휘하기 도시
$HlandKyujokai	= 44; # 다목적경기장
$HlandBigRizort	= 45; # 임시 해변 리조트 호텔
$HlandHTFactory	= 46; # 첨단 기술기업
$HlandShrine	= 98; # 시간의 신전 34
$HlandHugeMonster = 99; # 거대괴수 35

# 계획 번호 설정
# 개간 계열
$HcomPrepare	= 01; # 1 개간
$HcomPrepare2	= 02; # 2 땅고르기
$HcomReclaim	= 03; # 3 매립
$HcomDestroy	= 04; # 4 굴착
$HcomSellTree	= 05; # 5 벌채

$HcomMinato		= 06; # 6 항구개발
$HcomFune		= 07; # 7 조선
$HcomSeki		= 10; # 8 관문건설

# 작루계
$HcomPlant		= 11; # 9 나무심기
$HcomFarm		= 12; # 10 농장 건설
$HcomFactory	= 13; # 11 공장 건설
$HcomMountain	= 14; # 12 채굴장 건설
$HcomBase		= 15; # 13 미사일 기지건설
$HcomDbase		= 16; # 14 방위 시설 건설
$HcomSbase		= 17; # 15 해저 기지건설
$HcomMonument	= 18; # 16 기념비 건조
$HcomHaribote	= 19; # 17 가짜 기지건설

$HcomSeacity	= 20; # 18 해저 도시건설
$HcomMonbuy		= 21; # 19 괴수구매
$HcomMonbuyt	= 22; # 20 tetora 구매
$HcomPark		= 23; # 21 놀이공원건설
$HcomMine		= 24; # 22 지뢰설치
$HcomNursery	= 25; # 23 양식장설치
$HcomKyujo		= 26; # 24 야구장
$HcomUmiamu		= 27; # 25 해상 시설건설
$HcomFoodim		= 28; # 26 식품 연구소건설
$HcomProcity	= 29; # 27 방재화
$HcomBoku		= 30; # 28 나의 이사시
$HcomNewtown	= 70; # 29 뉴타운건설
$HcomBigtown	= 71; # 30 현대 도시건설
$HcomSeatown	= 72; # 31 해저뉴건설
$HcomFarmcpc	= 73; # 32 목장건설
$HcomCollege	= 74; # 대학건설
$HcomOnsen		= 75; # 온천 굴착
$HcomReclaim2	= 76; # 원거리 매립
$HcomHouse		= 77; # 섬주의 가
$HcomRizort		= 78; # 리조트지
$HcomBettown	= 79; # 휘하기 도시
$HcomGivefood	= 100; # 먹이 주기
$HcomKai		= 101; # 개장
$HcomHTget		= 102; # 첨단 기술게와
$HcomArmSupply	= 103; # 군사 물자 조달

# 발사계
$HcomMissileNM	= 31; # 33 미사일 발사
$HcomMissilePP	= 32; # 34 PP 미사일 발사
$HcomMissileST	= 33; # 35 ST 미사일 발사
$HcomMissileLD	= 34; # 36 육지 파괴탄환 발사
$HcomSendMonster= 35; # 37 괴수 파견
$HcomMissileSPP	= 36; # 38 SPP 미사일 발사
$HcomMissileSS	= 37; # 39 핵 미사일 발사
$HcomMissileLR	= 38; # 40 지형융기탄환 발사

$HcomEisei		= 39; # 41 인공위성 발사
$HcomEiseimente	= 40; # 42 인공위성 관리

$HcomEiseiLzr	= 80; # 43 인공위성레자
$HcomEiseiAtt	= 81; # 44 인공위성파괴

# 운영계
$HcomDoNothing	= 41; # 45 자금융통
$HcomSell		= 42; # 46 식량 수출
$HcomMoney		= 43; # 47 자금지원
$HcomFood		= 44; # 48 식량지원
$HcomPropaganda	= 45; # 49 유치 활동
$HcomGiveup		= 46; # 50 섬 포기
$HcomSave		= 47; # 저장
$HcomLoad		= 48; # 복원
$HcomAlly		= 49; # 동맹가입·탈퇴

# 자동 입력
$HcomAutoPrepare	= 111; # 51 전체 개간
$HcomAutoPrepare2	= 112; # 52 전체땅고르기
$HcomAutoDelete		= 113; # 53 전체 명령 삭제
$HcomAutoReclaim	= 114; # 54 매립
$HcomAutoDestroy	= 115; # 55 굴착
$HcomAutoSellTree	= 116; # 56 벌채
$HcomAutoForestry	= 117; # 57 벌채와 나무심기

# 순서
@comList =
	($HcomHouse, $HcomBettown, $HcomKai, $HcomPrepare, $HcomSell, $HcomPrepare2, $HcomReclaim, $HcomReclaim2, $HcomDestroy, $HcomOnsen,
	 $HcomSellTree, $HcomPlant, $HcomFarm, $HcomFoodim, $HcomFarmcpc, $HcomFactory, $HcomHTget, $HcomMountain, $HcomNursery, $HcomCollege,
	 $HcomPark, $HcomKyujo, $HcomUmiamu, $HcomRizort, $HcomBase, $HcomDbase, $HcomSbase, $HcomSeacity,
	 $HcomMonument, $HcomMonbuy, $HcomMonbuyt, $HcomHaribote, $HcomMine,
	 $HcomMinato, $HcomFune, $HcomProcity, $HcomNewtown, $HcomBigtown, $HcomSeatown, $HcomBoku, $HcomSeki,
	 $HcomEisei, $HcomEiseimente,
	 $HcomMissileNM, $HcomMissilePP, $HcomMissileSPP,
	 $HcomMissileST, $HcomMissileLD, $HcomMissileLR, $HcomMissileSS, $HcomEiseiLzr, $HcomEiseiAtt, $HcomSendMonster, $HcomDoNothing,
	 $HcomMoney, $HcomFood, $HcomPropaganda, $HcomGiveup, $HcomGivefood, $HcomSave, $HcomLoad, $HcomArmSupply, $HcomAlly,
	 $HcomAutoReclaim, $HcomAutoDestroy, $HcomAutoSellTree, $HcomAutoForestry,
	 $HcomAutoPrepare, $HcomAutoPrepare2, $HcomAutoDelete);

# 여기에서는 지정하지 말아 주세요
@HcomList = ();
foreach (@comList) {
	next if (($_ == $HcomAlly) && (!$HallyUse || !$HallyJoinComUse || $HarmisticeTurn));
	next if (($_ == $HcomMissileST) && !$HuseMissileST);
	next if (($_ == $HcomSendMonster) && !$HuseSendMonster);
	next if (($_ == $HcomArmSupply) && !$HuseArmSupply);
	push(@HcomList, $_);
}
$HcommandTotal = $#HcomList + 1; # 명령 종류

# 명령 분할
# 이 명령 분할만은, 자동 입력 명령은 설정하지 마세요.
@HcommandDivido =
	(
	'운영,41,50', # 계획번호41~50
	'개간,0,5', # 계획번호00~05
	'건설,11,19', # 계획번호11~19
	'개발,6,10', # 계획번호06~10
	'도시,70,79', # 계획번호70~75
	'시설,20,30', # 계획번호20~30
	'위성,39,40', # 계획번호39~40
	'운영,100,105', # 계획번호100~105
	'공격,31,38', # 계획번호31~38
	'공격,80,85', # 계획번호80~85
	);

# 계획 이름과 비용
$HcomName[$HcomHouse]		= '자택 건설/세율 변경';
$HcomCost[$HcomHouse]		= 'Pointx3';
$HcomName[$HcomBettown]		= '빛나는 도시 계획';
$HcomCost[$HcomBettown]		= 'Point';
$HcomName[$HcomKai]			= '개장·강화';
$HcomCost[$HcomKai]			= 'Point';
$HcomName[$HcomPrepare]		= '개간';
$HcomCost[$HcomPrepare]		= 5;
$HcomName[$HcomPrepare2]	= '땅고르기';
$HcomCost[$HcomPrepare2]	= 100;
$HcomName[$HcomReclaim]		= '매립';
$HcomCost[$HcomReclaim]		= 150;
$HcomName[$HcomReclaim2]	= '원거리 매립';
$HcomCost[$HcomReclaim2]	= 3000;
$HcomName[$HcomDestroy]		= '굴착';
$HcomCost[$HcomDestroy]		= 200;
$HcomName[$HcomMinato]		= '항구 도시개발';
$HcomCost[$HcomMinato]		= 550;
$HcomName[$HcomOnsen]		= '온천 굴착';
$HcomCost[$HcomOnsen]		= 50;
$HcomName[$HcomFune]		= '조선·출항';
$HcomCost[$HcomFune]		= 300;
$HcomName[$HcomSeki]		= '관문건설';
$HcomCost[$HcomSeki]		= 200;
$HcomName[$HcomSellTree]	= '벌채';
$HcomCost[$HcomSellTree]	= 0;
$HcomName[$HcomPlant]		= '나무심기';
$HcomCost[$HcomPlant]		= 50;
$HcomName[$HcomFarm]		= '농장 건설';
$HcomCost[$HcomFarm]		= 20;
$HcomName[$HcomFoodim]		= '식품 연구소건설';
$HcomCost[$HcomFoodim]		= 2500;
$HcomName[$HcomFarmcpc]		= '목장 건설/가축 판매';
$HcomCost[$HcomFarmcpc]		= 1500;
$HcomName[$HcomCollege]		= '대학건설';
$HcomCost[$HcomCollege]		= 500;
$HcomName[$HcomFactory]		= '공장 건설';
$HcomCost[$HcomFactory]		= 100;
$HcomName[$HcomHTget]		= '첨단 기술 유치';
$HcomCost[$HcomHTget]		= 10000;
$HcomName[$HcomMountain]	= '채굴장 건설';
$HcomCost[$HcomMountain]	= 300;
$HcomName[$HcomBase]		= '미사일 기지건설';
$HcomCost[$HcomBase]		= 300;
$HcomName[$HcomDbase]		= '방위 시설 건설';
$HcomCost[$HcomDbase]		= 800;
$HcomName[$HcomSbase]		= '해저 기지건설';
$HcomCost[$HcomSbase]		= 8000;
$HcomName[$HcomSeacity]		= '해저 도시건설';
$HcomCost[$HcomSeacity]		= 77777;
$HcomName[$HcomMonument]	= '기념비 건조';
$HcomCost[$HcomMonument]	= 9999;
$HcomName[$HcomMonbuy]		= '괴수의 구매·배치';
$HcomCost[$HcomMonbuy]		= 3980;
$HcomName[$HcomMonbuyt]		= '테트라의 구매·배치';
$HcomCost[$HcomMonbuyt]		= 10000;
$HcomName[$HcomHaribote]	= '가짜 기지건설';
$HcomCost[$HcomHaribote]	= 1;
$HcomName[$HcomMine]		= '지뢰설치';
$HcomCost[$HcomMine]		= 100;
$HcomName[$HcomPark]		= '놀이공원건설';
$HcomCost[$HcomPark]		= 1000;
$HcomName[$HcomNursery]		= '양식장설치';
$HcomCost[$HcomNursery]		= 50;
$HcomName[$HcomKyujo]		= '야구장건설';
$HcomCost[$HcomKyujo]		= 1000;
$HcomName[$HcomUmiamu]		= '해상 시설건설';
$HcomCost[$HcomUmiamu]		= 15000;
$HcomName[$HcomRizort]		= '리조트 개발';
$HcomCost[$HcomRizort]		= 40000;
$HcomName[$HcomProcity]		= '방재 도시화';
$HcomCost[$HcomProcity]		= 25000;
$HcomName[$HcomNewtown]		= '뉴타운건설';
$HcomCost[$HcomNewtown]		= 950;
$HcomName[$HcomBigtown]		= '현대 도시건설';
$HcomCost[$HcomBigtown]		= 45000;
$HcomName[$HcomSeatown]		= '해저 신도시건설';
$HcomCost[$HcomSeatown]		= 69800;
$HcomName[$HcomBoku]		= '나의 이사시';
$HcomCost[$HcomBoku]		= 1000;
$HcomName[$HcomEisei]		= '인공위성 발사';
$HcomCost[$HcomEisei]		= 9999;
$HcomName[$HcomEiseimente]	= '인공위성복구';
$HcomCost[$HcomEiseimente]	= 5000;
$HcomName[$HcomEiseiLzr]	= '위성 레이저 발사';
$HcomCost[$HcomEiseiLzr]	= 39999;
$HcomName[$HcomEiseiAtt]	= '위성파괴포발사';
$HcomCost[$HcomEiseiAtt]	= 49999;
$HcomName[$HcomMissileNM]	= '미사일 발사';
$HcomCost[$HcomMissileNM]	= 20;
$HcomName[$HcomMissilePP]	= 'PP 미사일 발사';
$HcomCost[$HcomMissilePP]	= 50;
$HcomName[$HcomMissileSPP]	= 'SPP 미사일 발사';
$HcomCost[$HcomMissileSPP]	= 1000;
$HcomName[$HcomMissileST]	= 'ST 미사일 발사';
$HcomCost[$HcomMissileST]	= 50;
$HcomName[$HcomMissileLD]	= '육지 파괴탄환 발사';
$HcomCost[$HcomMissileLD]	= 100000;
$HcomName[$HcomMissileLR]	= '지형융기탄환 발사';
$HcomCost[$HcomMissileLR]	= 600;
$HcomName[$HcomMissileSS]	= '핵 미사일 발사';
$HcomCost[$HcomMissileSS]	= 100000;
$HcomName[$HcomSendMonster]	= '괴수 파견';
$HcomCost[$HcomSendMonster]	= 500;
$HcomName[$HcomDoNothing]	= '자금융통';
$HcomCost[$HcomDoNothing]	= 0;
$HcomName[$HcomSell]		= '식량 수출';
$HcomCost[$HcomSell]		= -100;
$HcomName[$HcomMoney]		= '자금지원';
$HcomCost[$HcomMoney]		= 100;
$HcomName[$HcomFood]		= '식량지원';
$HcomCost[$HcomFood]		= -100;
$HcomName[$HcomPropaganda]	= '유치 활동';
$HcomCost[$HcomPropaganda]	= 1000;
$HcomName[$HcomGiveup]		= "${AfterName}의포기";
$HcomCost[$HcomGiveup]		= 0;
$HcomName[$HcomGivefood]	= '먹이 주기';
$HcomCost[$HcomGivefood]	= -50000;
$HcomName[$HcomAutoPrepare]	= '개간 자동 입력';
$HcomCost[$HcomAutoPrepare]	= 0;
$HcomName[$HcomAutoPrepare2]= '땅고르기 자동 입력';
$HcomCost[$HcomAutoPrepare2]= 0;
$HcomName[$HcomAutoDelete]	= '전체계획을 백지 철회';
$HcomCost[$HcomAutoDelete]	= 0;
$HcomName[$HcomAutoReclaim]	= '매립 자동 입력';
$HcomCost[$HcomAutoReclaim]	= 0;
$HcomName[$HcomAutoDestroy]	= '굴착 자동 입력';
$HcomCost[$HcomAutoDestroy]	= 0;
$HcomName[$HcomAutoSellTree]= '벌채 자동 입력';
$HcomCost[$HcomAutoSellTree]= 0;
$HcomName[$HcomAutoForestry]= '벌채 및 나무심기 자동 입력';
$HcomCost[$HcomAutoForestry]= 0;

$HcomName[$HcomAlly]	= '동맹 가입·탈퇴';
$HcomCost[$HcomAlly]	= 0;
$HcomName[$HcomArmSupply] = '군사 물자 조달';
$HcomCost[$HcomArmSupply] = 10;
$HcomName[$HcomSave]	= '시간 저장';
$HcomCost[$HcomSave]	= 100000;
$HcomName[$HcomLoad]	= '시간 복원';
$HcomCost[$HcomLoad]	= 100000;

1;
