#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}
# ↑은서버에 맞게 변경해 주세요.
# perl5용입니다.

# Hakoniwa R.A. JS.(based on 020610model)
my $versionInfo = "version4.51";
#----------------------------------------------------------------------
# 하코니와 제도 ver2.30
# 메인 스크립트(ver1.02)
# 사용 조건과 사용 방법은 hako-readme.txt 파일을 참조해 주세요
#
# 하코니와 제도의 페이지: http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html
#----------------------------------------------------------------------
#----------------------------------------------------------------------
# Hakoniwa R.A. ver2.11
# 메인 스크립트(하코니와 제도 ver2.30)
# 사용 조건, 사용 방법은 read-renas.txt 파일을 참조
#
# KEI PAGE: http://www5b.biglobe.ne.jp/~k-e-i/
#----------------------------------------------------------------------
BEGIN {
########################################
# 오류 표시
$SIG{__WARN__} =
sub {
	my($msg) = @_;

	print STDOUT <<END;
Content-type: text/html; charset=UTF-8

<p><big><tt>WARNNING: $msg</tt></big></p>
END
};

$SIG{__DIE__} =
sub {
	my($msg) = @_;

	print STDOUT <<END;
Content-type: text/html; charset=UTF-8

<p><big><tt>ERROR: $msg</tt></big></p>
END
exit(-1);
};

$SIG{KILL} =
sub {
	my($msg) = @_;

	print STDOUT <<END;
Content-type: text/html; charset=UTF-8

<p><big><tt>KILL: $msg</tt></big></p>
END
exit(-1);
};
########################################
}

# 초기 설정용 파일을 읽기
require './hako-init.cgi';
require './hako-io.cgi';
require './init-game.cgi';

#----------------------------------------------------------------------
# 아래는 필요에 따라 설정하는 항목입니다
#----------------------------------------------------------------------
# 이상종료 기준 시간
# (잠금 후 몇 초 뒤 강제 해제할지)
my($unlockTime) = 120;

#----------------------------------------------------------------------
# 필요에 따라 설정하는 항목은 여기까지입니다
#----------------------------------------------------------------------
#----------------------------------------------------------------------
# 변수
#----------------------------------------------------------------------

# COOKIE
$defaultID;	 # 섬 이름
$defaultTarget; # 대상의 이름

# 섬의 좌표 수
$HpointNumber = $HislandSize * $HislandSize;
$pointNumber = $HpointNumber - 1;

#----------------------------------------------------------------------
# 메인
#----------------------------------------------------------------------
# 접속제한
my $host = $ENV{'REMOTE_HOST'};
my $addr = $ENV{'REMOTE_ADDR'};
if ($gethostbyaddr && (($host eq '') || ($host eq $addr))) {
	$host = gethostbyaddr(pack("C4", split(/\./, $addr)), 2) || $addr;
} elsif($host eq '') {
	$host = $addr;
}
my $flag = 0;
foreach (@Hdeny) {
	if (!$_) { next; }
	s/\*/\.\*/g;
	if ($host =~ /$_/i) { $flag=1; last; }
}
if ($flag) {
	if($HdenyLocation ne '') {
		print "Location: $HdenyLocation\n\n";
		exit;
	} else {
		tempHeader();
		tempWrong("접속이 허가되어 있지 않습니다");
		tempFooter();
		exit(0);
	}
}

# '돌아가기'링크
$HtempBack = "<A HREF=\"$HthisFile\">${HtagBig_}맨 위로 돌아가기${H_tagBig}</A>";
$Body = "<BODY>";

# 난수의 초기화
srand(time() ^ ($$ + ($$ << 15)));

# COOKIE 읽기
cookieInput();

# CGI 읽기
cgiInput();

# 잠금을 끼치기
if(!$HsepTurnFlag && !hakolock()) {
	# 잠금실패
	# 헤더출력
	tempHeader();

	# 잠금실패 메시지
	tempLockFail();

	# 푸터출력
	tempFooter();

	# 종료
	exit(0);
}

if (-e $HpasswordFile) {
	# 비밀번호 파일 있음
	open(PIN, "<$HpasswordFile") || die $!;
	chomp($HmasterPassword = <PIN>); # 마스터 비밀번호 읽기
	chomp($HspecialPassword = <PIN>); # 특수 비밀번호를 읽기
	close(PIN);
} else {
	unlock();
	tempHeader();
	tempNoPasswordFile();
	tempFooter();
	exit(0);
}

# 섬 데이터 읽기
if(readIslandsFile($HcurrentID) == 0) {
	unlock();
	tempHeader();
	tempNoDataFile();
	tempFooter();
	exit(0);
}

# 템플릿을 초기화
if(($HmainMode eq 'turn') || (($HmainMode eq 'top') && !checkMasterPassword($HinputPassword))) {
	tempInitialize(0);
} else {
	tempInitialize(1);
}

# COOKIE를 이용한 ID 확인
if($HmainMode eq 'owner') {
	unless($ENV{'HTTP_COOKIE'}) {
		cookieOutput(); # COOKIE가 삭제되었는지 쓰기 확인
		next if($ENV{'HTTP_COOKIE'}); # 쓰기 OK
		# 쿠키를 유효로 하지 않음
		axeslog(1, 'cookie invalid') if($HtopAxes && $HtopAxes != 3);
		unlock();
		tempHeader();
		tempWrong("쿠키가 활성화되어 있는지 확인한 뒤 다시 시도해 주세요.");
		tempFooter();
		exit(0);
	}
	my($pcheck) = checkPassword($Hislands[$HidToNumber{$HcurrentID}],$HinputPassword);
	if(!$pcheck) {
		unlock();
		tempHeader();
		if($HinputPassword ne '') {
			tempWrongPassword(); # 비밀번호 불일치
		} else {
			tempWrong("비밀번호를 잊으셨나요?"); # 비밀번호 미입력
		}
		tempFooter();
		exit(0);
	}
	if($checkID || $checkImg) {
		# id에서 섬을 가져옴
		my $free = 0;
		foreach (@freepass){
			$free += 1 if(($_ == $defaultID) || ($_ == $HcurrentID));
		}
		my($icheck) = !($checkID && ($HcurrentID != $defaultID) && $defaultID);
		my($lcheck) = !($checkImg && ($HimgLine eq '' || $HimgLine eq $HimageDir));
		# 비밀번호
		if(($pcheck != 2) && ($free != 2) && (!$icheck || !$lcheck)) {
			# 1개의 섬을 초보자용에해방하다 때등은 ($free != 2) 부분을 !$free 에 변경해 주세요.
			unlock();
			tempHeader();
			if(!$icheck) {
				axeslog(1, 'ID error!') if($HtopAxes && $HtopAxes != 3);
				tempWrong("자신의 섬 이외에는 들어갈 수 없습니다!"); # ID 차이
			} else {
				axeslog(1, 'image invalid') if($HtopAxes && $HtopAxes != 3);
				tempWrong("'이미지 경로 설정'을해 주세요."); # 로컬 설정하지 않음
			}
			tempFooter();
			exit(0);
		}
	}
	# 접속·로그
	if($HtopAxes && ($HcurrentID != $defaultID)) {
		axeslog(1, 'ID differ!');
	} elsif(($HtopAxes == 2) || ($HtopAxes> 3)) {
		axeslog(1);
	}
}

# COOKIE 출력
cookieOutput();

# 헤더출력
if($HmainMode eq 'owner' && $HjavaMode eq 'java' ||
	$HmainMode eq 'commandJava' || # 명령 입력 모드
	$HmainMode eq 'command2' || # 명령 입력 모드(ver1.1부터 추가·자동 입력용)
	$HmainMode eq 'comment' && $HjavaMode eq 'java' || #코멘트입력 모드
	$HmainMode eq 'totoyoso' && $HjavaMode eq 'java' || #TOTO 예상1입력 모드
	$HmainMode eq 'totoyoso2' && $HjavaMode eq 'java' || #TOTO 예상2입력 모드
	$HmainMode eq 'shuto' && $HjavaMode eq 'java' || #수도 이름 변경 모드
	$HmainMode eq 'preab' && $HjavaMode eq 'java' || # 진영공동개발 모드
	$HmainMode eq 'lbbs' && $HjavaMode eq 'java') { #코멘트입력 모드

	$Body = "<BODY onload=\"SelectList('');init()\">";
	require('./hako-map.cgi');
	# 헤더출력
	tempHeaderJava();
	if($HmainMode eq 'commandJava') {
		# 개발 모드
		commandJavaMain();
	} elsif($HmainMode eq 'command2') {
		# 개발 모드2(ver1.1부터 추가·자동 입력 명령용)
		commandMain();
	} elsif($HmainMode eq 'comment') {
		# 코멘트입력 모드
		commentMain();
	} elsif($HmainMode eq 'totoyoso') {
		# TOTO 예상1입력 모드
		totoInputMain(0);
	} elsif($HmainMode eq 'totoyoso2') {
		# TOTO 예상2입력 모드
		totoInputMain(1);
	} elsif($HmainMode eq 'shuto') {
		# 수도 이름 변경 모드
		require('./hako-map.cgi');
		shutoMain();
	} elsif($HmainMode eq 'preab') {
		# 진영공동개발 모드
		require('./hako-map.cgi');
		preabMain();
	} elsif($HmainMode eq 'lbbs') {
		# 로컬 게시판 모드
		require('./hako-lbbs.cgi');
		localBbsMain();
	} else {
		ownerMain();
	}
	# 푸터출력
	tempFooter();
	# 종료
	exit(0);
}elsif($HmainMode eq 'landmap'){
	require('./hako-map.cgi');
	$Body = "<BODY>";
	# 헤더출력
	tempHeaderJava();
	# 관광 모드
	printIslandJava();
	# 푸터출력
	tempFooter();
	# 종료
	exit(0);
} elsif($HmainMode ne 'new' && $HmainMode ne 'lbbs'){
	# 헤더출력
	tempHeader();
}

if($HmainMode eq 'turn') {
	# 턴진행
	require('./hako-turn.cgi');
	turnMain();

} elsif($HmainMode eq 'new') {
	# 섬 신규 생성
	require('./hako-make.cgi');
	require('./hako-map.cgi');
	newIslandMain();

} elsif($HmainMode eq 'newally') {
	# 동맹의 신규작성
	require('./hako-make.cgi');
	require('./hako-top.cgi');
	makeAllyMain();

} elsif($HmainMode eq 'delally') {
	# 동맹의 삭제
	require('./hako-make.cgi');
	require('./hako-top.cgi');
	deleteAllyMain();

} elsif($HmainMode eq 'inoutally') {
	# 동맹의 가입·탈퇴
	require('./hako-make.cgi');
	require('./hako-top.cgi');
	joinAllyMain();

} elsif($HmainMode eq 'allypact') {
	# 맹주코멘트 모드
	require('hako-make.cgi');
	allyPactMain();

} elsif($HmainMode eq 'joinally') {
	# 동맹 설정
	require('./hako-make.cgi');
	newAllyTop();

} elsif($HmainMode eq 'aoa') {
	# 동맹내의 우호국 설정
	require('./hako-top.cgi');
	amityOfAlly();

} elsif($HmainMode eq 'preab') {
	# 진영공동개발 모드
	require('./hako-map.cgi');
	preabMain();

} elsif($HmainMode eq 'camp') {
	# 진영 모드
	require('./hako-map.cgi');
	require('./hako-camp.cgi');
	campMain();

} elsif($HmainMode eq 'asetup') {
	# 우호국 설정 확인 모드
	require('./hako-make.cgi');
	amitySetupMain();

} elsif($HmainMode eq 'print') {
	# 관광 모드
	require('./hako-map.cgi');
	printIslandMain();

} elsif($HmainMode eq 'owner') {
	# 개발 모드
	require('./hako-map.cgi');
	ownerMain();

} elsif($HmainMode eq 'command') {
	# 명령 입력 모드
	require('./hako-map.cgi');
	commandMain();

} elsif($HmainMode eq 'comment') {
	# 코멘트입력 모드
	require('./hako-map.cgi');
	commentMain();


} elsif($HmainMode eq 'lbbs') {
	# 로컬 게시판 모드
	require('./hako-map.cgi');
	require('./hako-lbbs.cgi');
	localBbsMain();

} elsif($HmainMode eq 'change') {
	# 정보 변경 모드
	require('./hako-make.cgi');
	changeMain();

} elsif($HmainMode eq 'totoyoso') {
	# 코멘트입력 모드
	require('./hako-map.cgi');
	totoInputMain(0);

} elsif($HmainMode eq 'totoyoso2') {
	# 코멘트입력 모드
	require('./hako-map.cgi');
	totoInputMain(1);

} elsif($HmainMode eq 'shuto') {
	# 수도 이름 변경 모드
	require('./hako-map.cgi');
	shutoMain();

} elsif($HmainMode eq 'rank') {
	# 순위
	require('./hako-make.cgi');
	rankIslandMain();

} elsif($HmainMode eq 'rekidai') {
	# 역대 최다인구기록
	require('./hako-make.cgi');
	rekidaiPopMain();

} elsif($HmainMode eq 'hcdata') {
	# HakoniwaCup 전쟁실적
	require('./hako-make.cgi');
	hcdataMain();

} elsif($HmainMode eq 'join') {
	# 새 섬을 탐색
	require('./hako-make.cgi');
	newIslandTop();

} elsif($HmainMode eq 'rename') {
	# 섬 이름과 비밀번호 변경
	require('./hako-make.cgi');
	renameIslandMain();

} elsif($HmainMode eq 'localimg') {
	# 이미지 경로 설정
	require('./hako-make.cgi');
	localImgMain();

} elsif($HmainMode eq 'hakoskin') {
	# 하코니와 스킨의 설정
	require('./hako-make.cgi');
	hakoSkinMain();

} elsif($HmainMode eq 'bfield') {
	# BattleField 작성 모드
	require('./hako-make.cgi');
	bfieldMain();

} elsif($HmainMode eq 'present') {
	# 관리자가 지급한 선물 모드
	require('./hako-make.cgi');
	presentMain();

} elsif($HmainMode eq 'punish') {
	# 관리자가 한제재 모드
	require('./hako-make.cgi');
	punishMain();

} elsif($HmainMode eq 'lchange') {
	# 관리자가 한 지형 변경 모드
	require('./hako-make.cgi');
	lchangeMain();

} elsif($HmainMode eq 'predelete') {
	# 관리자가 한보관 모드
	require('./hako-make.cgi');
	preDeleteMain();

} else {
	# 그 외에는 톱 페이지 모드
	require('./hako-top.cgi');
	topPageMain();
}

# 푸터출력
tempFooter();

# 종료
exit(0);

# 명령을 앞으로 당기기
sub slideFront {
	my($command, $number) = @_;

	# 각각밀기
	splice(@$command, $number, 1);

	# 마지막에 자금융통
	$command->[$HcommandMax - 1] = {
		'kind' => $HcomDoNothing,
		'target' => 0,
		'x' => 0,
		'y' => 0,
		'arg' => 0
	};
}

# 명령을 뒤로 밀기
sub slideBack {
	my($command, $number) = @_;

	# 각각밀기
	return if $number == $#$command;
	pop(@$command);
	splice(@$command, $number, 0, $command->[$number]);
}

#----------------------------------------------------------------------
# 입출력
#----------------------------------------------------------------------

# CGI 읽기
sub cgiInput {
	my($line, $getLine);

	# 입력을 받아 UTF-8로 처리
	$line = <>;
	$line =~ tr/+/ /;
	$line =~ s/%([a-fA-F0-9]{2})/pack(H2, $1)/eg;
#
	if($line !~ /Allypact=([^\&]*)\&/) {
		$line =~ s/[\x00-\x1f\,]//g;
	} else {
		# 맹주코멘트 모드
		# 변경 버튼이 눌렸을 때 시작
		$HmainMode = 'allypact';
		$HallyPactMode = 1;
		$HdefaultPassword = $1;
		$line =~ /ALLYCOMMENT=([^\&]*)\&/;
		$HallyComment = cutColumn($1, $HlengthAllyComment*2);
		$line =~ /ALLYTITLE=([^\&]*)\&/;
		$HallyTitle = cutColumn($1, $HlengthAllyTitle*2);
		$line =~ /ISLANDID=([0-9]+)\&/;
		$HcurrentID = $1;
		$line =~ s/(.*)ALLYMESSAGE=//g;
		$HallyMessage = cutColumn($line, $HlengthAllyMessage*2);
		return;
	}

	# GET 값을 받음
	$getLine = $ENV{'QUERY_STRING'};

	# 대상의 섬
	if($line =~ /ISLANDID=([0-9]+)\&/){
		$HcurrentID = $1;
	}

	# 비밀번호
	if($line =~ /OLDPASS=([^\&]*)\&/) {
		$HoldPassword = $1;
		$HdefaultPassword = $1;
	}
	if($line =~ /PASSWORD=([^\&]*)\&/) {
		$HinputPassword = $1;
		$HdefaultPassword = $1;
	}
	if($line =~ /PASSWORD2=([^\&]*)\&/) {
		$HinputPassword2 = $1;
	}

	# Java스크립트 모드
	if($line =~ /JAVAMODE=(cgi|java)/) {
		$HjavaMode = $1;
	} elsif($getLine =~ /JAVAMODE=(cgi|java)/) {
		$HjavaMode = $1;
	}
	if($getLine =~ /UNLOCK=([0-9]*)/) {
		$HsepTurnFlag = $1;
	}

	# main mode 의가져오기
	if($line =~ /TurnButton/) {
		if($Hdebug == 1) {
			$HmainMode = 'Hdebugturn';
		}
	} elsif($line =~ /OwnerButton/) {
		$HmainMode = 'owner';
	} elsif($line =~ /CommandJavaButton([0-9]+)=/) {
		# 명령 전송버튼의 경우(Java스크립트)
		$HcurrentID = $1;
		$HmainMode = 'commandJava';
		$line =~ /COMARY=([^\&]*)\&/;
		$HcommandComary = $1;
		$line =~ /COMMAND=([^\&]*)\&/;
		$HcommandKind = $1;
		$HdefaultKind = $1;
		$line =~ /AMOUNT=([^\&]*)\&/;
		$HcommandArg = $1;
		$line =~ /TARGETID=([^\&]*)\&/;
		$HcommandTarget = $1;
		$defaultTarget = $1;
		$line =~ /POINTX=([^\&]*)\&/;
		$HcommandX = $1;
		$HdefaultX = $1;
		$line =~ /POINTY=([^\&]*)\&/;
		$HcommandY = $1;
		$HdefaultY = $1;
		# 명령의 팝업 메뉴를 열기?
		if($line =~ /MENUOPEN=on/) {
			$HmenuOpen = 'CHECKED';
		} elsif($line =~ /MENUOPEN2=on/) {
			$HmenuOpen2 = 'CHECKED';
		}
	} elsif($line =~ /CommandButton([0-9]+)=/) {
		# 명령 전송버튼의 경우
		$HcurrentID = $1;
		if($HjavaMode eq 'java'){
			$HmainMode = 'command2';
		}else{
			$HmainMode = 'command';
		}

		# 명령 모드의 경우, 명령의 가져오기
		$line =~ /NUMBER=([^\&]*)\&/;
		$HcommandPlanNumber = $1;
		$line =~ /COMMAND=([^\&]*)\&/;
		$HcommandKind = $1;
		$HdefaultKind = $1;
		$line =~ /AMOUNT=([^\&]*)\&/;
		$HcommandArg = $1;
		$line =~ /TARGETID=([^\&]*)\&/;
		$HcommandTarget = $1;
		$defaultTarget = $1;
		$line =~ /POINTX=([^\&]*)\&/;
		$HcommandX = $1;
		$HdefaultX = $1;
		$line =~ /POINTY=([^\&]*)\&/;
		$HcommandY = $1;
		$HdefaultY = $1;
		if($line =~ /COMMANDMODE=(write|insert|delete)/) {
			$HcommandMode = $1;
		}
		# 명령의 팝업 메뉴를 열기?
		if($line =~ /MENUOPEN=on/) {
			$HmenuOpen = 'CHECKED';
		} elsif($line =~ /MENUOPEN2=on/) {
			$HmenuOpen2 = 'CHECKED';
		}
	} elsif($getLine =~ /Sight=([0-9]*)/) {
		$HmainMode = 'print';
		$HcurrentID = $1;
		# 관리자 모드
		if($getLine =~ /ADMINMODE=([0-9]*)/) {
			$HadminMode = 1;
			$HdefaultPassword = $1;
		}
	} elsif($line =~ /SightButton/) {
		$HmainMode = 'print';
		$line =~ /TARGETID=([^\&]*)\&/;
		$HcurrentID = $1;

	} elsif($line =~ /LbbsButton(..)([0-9]*)/) {
		$HmainMode = 'lbbs';
		if($1 eq 'AD') {
			# 관리자
			$HlbbsMode = 5;
		} elsif($1 eq 'DA') {
			# 관리자 삭제
			$HlbbsMode = 7;
		} elsif($1 eq 'OW') {
			# 섬주
			$HlbbsMode = 1;
		} elsif($1 eq 'DL') {
			# 섬주 삭제
			$HlbbsMode = 3;
		} elsif($1 eq 'DS') {
			# 관광객 삭제
			$HlbbsMode = 2;
		} elsif($1 eq 'CK') {
			# 관광객극비 확인
			$HlbbsMode = 4;
		} else {
			# 관광객
			$HlbbsMode = 0;
		}
		$HcurrentID = $2;

		if($line =~ /LBBSNAME=([^\&]*)\&/) {
			$HlbbsName = cutColumn($1, $HlengthLbbsName*2);
			$HdefaultName = $HlbbsName;
		}
		if($line =~ /LBBSMESSAGE=([^\&]*)\&/) {
			my $lbbsMessage = $1;
			my $comment_length = $HlengthLbbsMessage * 2;
			if(($HlbbsAutolinkSymbol ne '') && ($lbbsMessage =~ /((http|ftp):\/\/([^\x81-\xFF\s\"\'\(\)\<\>\\\`\[\{\]\}\|]+))/ )) {
				my $matched_url = $1;
				$comment_length += length($matched_url) - length($HlbbsAutolinkSymbol);
			}
			$HlbbsMessage = cutColumn($lbbsMessage, $comment_length);
		}
		# 게시판의 발언 섬
		$line =~ /ISLANDID2=([0-9]+)\&/;
		$HspeakerID = $1;
		# 게시판의 통신형식
		$line =~ /LBBSTYPE=([^\&]*)\&/;
		$HlbbsType = $1;
		# 삭제할 수 없으므로 번호를 가져옴
		if($line =~ /NUMBER=([^\&]*)\&/) {
			$HcommandPlanNumber = $1;
		}

	} elsif($line =~ /ChangeInfoButton/) {
		$HmainMode = 'change';
		# 이름 지정의 경우
		if($line =~ /ISLANDNAME=([^\&]*)\&/){
			$HcurrentName = cutColumn($1, $HlengthIslandName*2);
		}
		# 소유자 이름 가져오기
		if($line =~ /OWNERNAME=([^\&]*)\&/){
			$HcurrentOwnerName = cutColumn($1, $HlengthOwnerName*2);
		}
	} elsif($line =~ /MessageButton([0-9]*)/) {
		$HmainMode = 'comment';
		$HcurrentID = $1;
		# 메시지
		if($line =~ /MESSAGE=([^\&]*)\&/){
			$Hmessage = cutColumn($1, $HlengthMessage*2);
		}
	} elsif($line =~ /TotoButton([0-9]*)/) {
		$HmainMode = 'totoyoso';
		$HcurrentID = $1;
		# YOSO
		if($line =~ /YOSOMESSAGE=([^\&]*)\&/) {
			$HyosoMessage[0] = cutColumn($1, $HlengthYoso*2);
		}

	} elsif($line =~ /TotosButton([0-9]*)/) {
		$HmainMode = 'totoyoso2';
		$HcurrentID = $1;
		# YOSO2
		if($line =~ /YOSOMESSAGE2=([^\&]*)\&/) {
			$HyosoMessage[1] = cutColumn($1, $HlengthYoso*2);
		}

	} elsif($line =~ /ShutoButton([0-9]*)/) {
		$HmainMode = 'shuto';
		$HcurrentID = $1;
		# shuto
		if($line =~ /SHUTOMESSAGE=([^\&]*)\&/) {
			$HshutoMessage = cutColumn($1, $HlengthShuto*2);
		}

	} elsif($line =~ /PreabButton([0-9]*)/) {
		$HmainMode = 'preab';
		$HcurrentID = $1;
	} elsif($getLine =~ /View=([0-9]*)/) {
		$HmainMode = 'top';
		$HviewIslandNumber = $1;
	} elsif($getLine =~ /IslandMap=([0-9]*)/) {
		$HmainMode = 'landmap';
		$HcurrentID = $1;

	} elsif($getLine =~ /JoinA=([^\&]*)/) {
		$HmainMode = 'joinally';
		$HdefaultPassword = $1;
	} elsif($line =~ /NewAllyButton/) {
		$HmainMode = 'newally';
		# 동맹 이름 가져오기
		if($line =~ /ALLYNUMBER=([0-9]*)\&/) {
			$HcurrentAnumber = $1;
		}
		if($line =~ /ALLYID=([0-9]*)\&/) {
			$HallyID = $1;
		}
		$line =~ /ALLYNAME=([^\&]*)\&/;
		$HallyName = cutColumn($1, $HlengthAllyName*2);
		$line =~ /MARK=([^\&]*)\&/;
		$HallyMark = $1;
		$line =~ /COLOR1=([0-9A-F])\&COLOR2=([0-9A-F])\&COLOR3=([0-9A-F])\&COLOR4=([0-9A-F])\&COLOR5=([0-9A-F])\&COLOR6=([0-9A-F])\&/;
		$HallyColor = $1. $2. $3. $4. $5. $6;
	} elsif($line =~ /DeleteAllyButton/) {
		$HmainMode = 'delally';
		if($line =~ /ALLYID=([0-9]*)\&/) {
			$HallyID = $1;
		}
		$line =~ /ALLYNUMBER=([0-9]*)\&/;
		$HcurrentAnumber = $1;
	} elsif($line =~ /JoinAllyButton/) {
		$HmainMode = 'inoutally';
		$line =~ /ALLYNUMBER=([0-9]*)\&/;
		$HcurrentAnumber = $1;
	} elsif($getLine =~ /AmiOfAlly=([0-9]*)/) {
		$HmainMode = 'aoa';
		$HallyID = $1;
	} elsif($getLine =~ /Allypact=([^\&]*)/) {
		# 맹주코멘트 모드
		# 처음의 시작
		$HmainMode = 'allypact';
		$HallyPactMode = 0;
		$HcurrentID = $1;
	} elsif ($line =~ /camp=([0-9]*)/) {
		$HmainMode = 'camp';
		$HcurrentCampID = $1;
		if($line =~ /jpass=([a-zA-Z0-9]*)/) {
			$HcampPassward = $1; # 진영 비밀번호
		}
		if($line =~ /id=([0-9]*)/) {
			$HcurrentID = $1;
		}

	} elsif($getLine =~ /Rank=([0-9]*)/) {
		$HmainMode = 'rank';
	} elsif($getLine =~ /HCdata=([0-9]*)/) {
		$HmainMode = 'hcdata';
	} elsif($getLine =~ /Rekidai=([0-9]*)/) {
		$HmainMode = 'rekidai';
	} elsif($getLine =~ /Rename=([0-9]*)/) {
		$HmainMode = 'rename';
	} elsif($getLine =~ /Skin=([0-9]*)/) {
		$HmainMode = 'hakoskin';
	} elsif($getLine =~ /Limg=([0-9]*)/) {
		$HmainMode = 'localimg';
	} elsif($getLine =~ /Join=([0-9]*)/) {
		# 누구나 새 섬을 탐색하게 함
		$HmainMode = ($HadminJoinOnly ? 'top' : 'join');
	} elsif($line =~ /Join=([0-9]*)/) {
		# 관리자만 새 섬을 탐색하게 함
		$HmainMode = ($HadminJoinOnly ? 'join' : 'top');
	} elsif($line =~ /NewIslandButton/) {
		$HmainMode = 'new';
		# 이름 가져오기
		$line =~ /ISLANDNAME=([^\&]*)\&/;
		$HcurrentName = cutColumn($1, $HlengthIslandName*2);
		# 소유자 이름 가져오기
		$line =~ /OWNERNAME=([^\&]*)\&/;
		$HcurrentOwnerName = cutColumn($1, $HlengthOwnerName*2);
		if($HarmisticeTurn && $HcampSelectRule == 2) {
			# 진영을 선택 가능이 경우
			if($line =~ /CAMPNUMBER=([\-]?[0-9]+)\&/) {
				$HcampNumber = $1;
			}
		}

# 동맹 설정 확인 모드
	} elsif($getLine =~ /ASetup=([^\&]*)/) {
		$HmainMode = 'asetup';
		$HasetupMode = 0;
		$HdefaultPassword = $1;
	} elsif($line =~ /ASetup=([^\&]*)\&/) {
		# 변경 버튼이 눌렸을 때 시작
		$HmainMode = 'asetup';
		$HasetupMode = 1;
		$HdefaultPassword = $1;
		while($line =~/amity=([^\&]*)\&/g) {
			push(@HamityChange, $1);
		}
		while($line =~/ally=([^\&]*)\&/g) {
			push(@HallyChange, $1);
		}

# BattleField 작성 모드
	} elsif($getLine =~ /Bfield=([^\&]*)/) {
		# 처음의 시작
		$HmainMode = 'bfield';
		$HbfieldMode = 0;
		$HdefaultPassword = $1;
	} elsif($line =~ /Bfield=([^\&]*)\&/) {
		# BattleField 작성 버튼이 눌렸을 때 시작
		$HmainMode = 'bfield';
		$HbfieldMode = 1;
		$HdefaultPassword = $1;

# 관리자가 지급한 선물 모드
	} elsif($getLine =~ /Present/) {
		# 처음의 시작
		$HmainMode = 'present';
		$HpresentMode = 0;
	} elsif($line =~ /Present/) {
		# 선물 버튼이 눌렸을 때 시작
		$HmainMode = 'present';
		$HpresentMode = 1;
		($HpresentMoney) = ($line =~ /PRESENTMONEY=([^\&]*)\&/);
		($HpresentFood ) = ($line =~ /PRESENTFOOD=([^\&]*)\&/);
		$line =~ /PRESENTLOG=([^\&]*)\&/;
		$HpresentLog = cutColumn($1, $HlengthPresentLog*2);

# 관리자가 한제재 모드
	} elsif($getLine =~ /Punish=([^\&]*)/) {
		# 처음의 시작
		$HmainMode = 'punish';
		$HpunishMode = 0;
		$HdefaultPassword = $1;
	} elsif($line =~ /Punish=([^\&]*)\&/) {
		# 제재 버튼이 눌렸을 때 시작
		$HmainMode = 'punish';
		$HpunishMode = 1;
		$HdefaultPassword = $1;

		$line =~ /POINTX=([^\&]*)\&/;
		$HcommandX = $1;
		$HdefaultX = $1;
		$line =~ /POINTY=([^\&]*)\&/;
		$HcommandY = $1;
		$HdefaultY = $1;
		$line =~ /PUNISHID=([^\&]*)\&/;
		$HpunishID = $1;
# 관리자가 한 지형 변경 모드
	} elsif($getLine =~ /Lchange=([^\&]*)/) {
		# 처음의 시작
		$HmainMode = 'lchange';
		$HlchangeMode = 0;
		$HdefaultPassword = $1;
	} elsif($line =~ /Lchange=([^\&]*)\&/) {
		# 변경 버튼이 눌렸을 때 시작
		$HmainMode = 'lchange';
		$HlchangeMode = 1;
		$HdefaultPassword = $1;

		$line =~ /POINTX=([^\&]*)\&/;
		$HcommandX = $1;
		$HdefaultX = $1;
		$line =~ /POINTY=([^\&]*)\&/;
		$HcommandY = $1;
		$HdefaultY = $1;
		$line =~ /LCHANGEKIND=([^\&]*)\&/;
		$HlchangeKIND = $1;
		$line =~ /LCHANGEVALUE=([^\&]*)\&/;
		$HlchangeVALUE = $1;
# 관리자가 한보관 모드
	} elsif($getLine =~ /Pdelete=([^\&]*)/) {
		# 처음의 시작
		$HmainMode = 'predelete';
		$HpreDeleteMode = 0;
		$HdefaultPassword = $1;
	} elsif($line =~ /Pdelete=([^\&]*)\&/) {
		# 변경 버튼이 눌렸을 때 시작
		$HmainMode = 'predelete';
		$HpreDeleteMode = 1;
		$HdefaultPassword = $1;
	} else {
		$HmainMode = 'top';
	}


	if($line =~ /IMGLINEMAC=([^&]*)\&/){
		my($flag) = $1;
		if($flag eq ''){
			$flag = $HimageDir;
		} else {
			$flag =~ s/ /%20/g;
			$flag = 'file:///'. $flag;
		}
		$HimgLine = $flag;
	} elsif($line =~ /IMGLINE=([^\&]*)\&/) {
		my($flag) = $1;
		$flag =~ tr/\\/\//;
		if(($flag eq 'deletemodenow') || ($flag eq '')){
			$flag = $HimageDir;
		} else {
#			$flag =~ s/:/|/g;
			$flag =~ s/\/[\w\.]+\.gif$//g;
			$flag = 'file:///'. $flag;
		}
		$HimgLine = $flag;
	} elsif($line =~ /SKIN=([^\&]*)\&/) {
		my($flag) = $1;
		if(($flag eq 'del') || ($flag eq '')){
			$flag = "${efileDir}/$HcssFile";
		} else {
			$flag = "${efileDir}/${HcssDir}/". $flag;
		}
		$HskinName = $flag;
	}


}

#cookie 입력
sub cookieInput {
	my($cookie);

#	$cookie = $ENV{'HTTP_COOKIE'};
	$cookie = $ENV{'HTTP_COOKIE'};

	if($cookie =~ /${HthisFile}OWNISLANDID=\(([^\)]*)\)/) {
		$defaultID = $1;
	}
	if($cookie =~ /${HthisFile}OWNISLANDPASSWORD=\(([^\)]*)\)/) {
		$HdefaultPassword = $1;
	}
	if($cookie =~ /${HthisFile}TARGETISLANDID=\(([^\)]*)\)/) {
		$defaultTarget = $1;
	}
	if($cookie =~ /${HthisFile}LBBSNAME=\(([^\)]*)\)/) {
		$HdefaultName = $1;
	}
	if($cookie =~ /${HthisFile}POINTX=\(([^\)]*)\)/) {
		$HdefaultX = $1;
	}
	if($cookie =~ /${HthisFile}POINTY=\(([^\)]*)\)/) {
		$HdefaultY = $1;
	}
	if($cookie =~ /${HthisFile}KIND=\(([^\)]*)\)/) {
		$HdefaultKind = $1;
	}
	if($cookie =~ /${HthisFile}JAVAMODESET=\(([^\)]*)\)/) {
		$HjavaModeSet = $1;
	}

	if($cookie =~ /${HthisFile}IMGLINE=\(([^\)]*)\)/) {
		$HimgLine = $1;
	}
	if($cookie =~ /${HthisFile}SKIN=\(([^\)]*)\)/) {
		$HskinName = $1;
	}

}

#cookie 출력
sub cookieOutput {
	my($cookie, $info);

	# 삭제 가능 기한 설정
	my($sec, $min, $hour, $date, $mon, $year, $day, $yday, $dummy) = gmtime(time + 30 * 86400); # 현재 + 30일

	# 2자리화
	$year += 1900;
	$date = "0$date" if($date < 10);
	$hour = "0$hour" if($hour < 10);
	$min = "0$min" if($min < 10);
	$sec = "0$sec" if($sec < 10);

	# 요일일을 문자에
	$day = ("Sunday", "Monday", "Tuesday", "Wednesday",	"Thursday", "Friday", "Saturday")[$day];

	# 월을 문자에
	$mon = ("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")[$mon];

	# 경로와 기간 설정
	$info = "; expires=$day, $date\-$mon\-$year $hour:$min:$sec GMT\n";
	$cookie = '';

	if(($HcurrentID) && ($HmainMode eq 'owner')){
		$cookie.= "Set-Cookie: ${HthisFile}OWNISLANDID=($HcurrentID) $info";
	}
	if($HinputPassword) {
		$cookie.= "Set-Cookie: ${HthisFile}OWNISLANDPASSWORD=($HinputPassword) $info";
	}
	if($HcommandTarget) {
		$cookie.= "Set-Cookie: ${HthisFile}TARGETISLANDID=($HcommandTarget) $info";
	}
	if($HlbbsName) {
		$cookie.= "Set-Cookie: ${HthisFile}LBBSNAME=($HlbbsName) $info";
	}
	if($HcommandX) {
		$cookie.= "Set-Cookie: ${HthisFile}POINTX=($HcommandX) $info";
	}
	if($HcommandY) {
		$cookie.= "Set-Cookie: ${HthisFile}POINTY=($HcommandY) $info";
	}
	if($HcommandKind) {
		# 자동 입력 이외
		$cookie.= "Set-Cookie: ${HthisFile}KIND=($HcommandKind) $info";
	}
	if($HjavaMode) {
		$cookie.= "Set-Cookie: ${HthisFile}JAVAMODESET=($HjavaMode) $info";
	}

	if($HimgLine) {
		$cookie.= "Set-Cookie: ${HthisFile}IMGLINE=($HimgLine) $info";
	}
	if($HskinName) {
		$cookie.= "Set-Cookie: ${HthisFile}SKIN=($HskinName) $info";
	}

	out($cookie);
}

#----------------------------------------------------------------------
# 유티리티
#----------------------------------------------------------------------
sub hakolock {
	if($lockMode == 1) {
		# directory 방식 잠금
		return hakolock1();
	} elsif($lockMode == 2) {
		# flock 방식 잠금
		return hakolock2();
	} elsif($lockMode == 3) {
		# symlink 방식 잠금
		return hakolock3();
	} elsif($lockMode == 4) {
		# 일반 파일 방식 잠금
		return hakolock4();
	} else {
		# rename 방식 잠금
		$lfh = hakolock5() or die return 0;
		return 1;
	}
}

sub hakolock1 {
	# 잠금을 시도
	if(mkdir('hakojimalock', $HdirMode)) {
		# 성공
		return 1;
	} else {
		# 실패
		my($b) = (stat('hakojimalock'))[9];
		if(($b> 0) && ((time() - $b)> $unlockTime)) {
			# 강제 해제
			unlock();

			# 헤더출력
			tempHeader();

			# 강제 해제 메시지
			tempUnlock();

			# 푸터출력
			tempFooter();

			# 종료
			exit(0);
		}
		return 0;
	}
}

sub hakolock2 {
	open(LOCKID, '>>hakojimalockflock');
	if(flock(LOCKID, 2)) {
		# 성공
		return 1;
	} else {
		# 실패
		return 0;
	}
}

sub hakolock3 {
	# 잠금을 시도
	if(symlink('hakojimalockdummy', 'hakojimalock')) {
		# 성공
		return 1;
	} else {
		# 실패
		my($b) = (lstat('hakojimalock'))[9];
		if(($b> 0) && ((time() - $b)> $unlockTime)) {
			# 강제 해제
			unlock();

			# 헤더출력
			tempHeader();

			# 강제 해제 메시지
			tempUnlock();

			# 푸터출력
			tempFooter();

			# 종료
			exit(0);
		}
		return 0;
	}
}

sub hakolock4 {
	# 잠금을 시도
	if(unlink('lockfile')) {
		# 성공
		open(OUT, '>lockfile.lock');
		print OUT time;
		close(OUT);
		return 1;
	} else {
		# 잠금 시간 확인
		if(!open(IN, 'lockfile.lock')) {
			return 0;
		}

		my($t);
		$t = <IN>;
		close(IN);
		if(($t != 0) && (($t + $unlockTime) < time)) {
			# 120초 이상 경과하면 강제로 잠금을 해제
			unlock();

			# 헤더출력
			tempHeader();

			# 강제 해제 메시지
			tempUnlock();

			# 푸터출력
			tempFooter();

			# 종료
			exit(0);
		}
		return 0;
	}
}

# rename 식(Perl 메모 http://www.din.or.jp/~ohzaki/perl.htm#File_Lock)
sub hakolock5 {
	my %lfh = (dir => "./", basename => "lockfile", timeout => $unlockTime, trytime => 3, @_);
	$lfh{path} = $lfh{dir}.$lfh{basename};

	for (my $i = 0; $i < $lfh{trytime}; $i++, sleep 1) {
		return \%lfh if (rename($lfh{path}, $lfh{current} = $lfh{path}. time));
	}

	opendir(LOCKDIR, $lfh{dir});
	my @filelist = readdir(LOCKDIR);
	closedir(LOCKDIR);

	foreach (@filelist) {
		if (/^$lfh{basename}(\d+)/) {
			return \%lfh if (time - $1> $lfh{timeout} and
			rename($lfh{dir}. $_, $lfh{current} = $lfh{path}. time));
			last;
		}
	}
	undef;
}

# 잠금을 해제
sub unlock {
	if($lockMode == 1) {
		# directory 방식 잠금
		rmdir('hakojimalock');
	} elsif($lockMode == 2) {
		# flock 방식 잠금
		close(LOCKID);
	} elsif($lockMode == 3) {
		# symlink 방식 잠금
		unlink('hakojimalock');
	} elsif($lockMode == 4) {
		# 일반 파일 방식 잠금
		my($i);
		$i = rename('lockfile.lock', 'lockfile');
	} else {
		# rename 방식 잠금
		rename($lfh->{current}, $lfh->{path});
	}
}

# 작은 쪽을 반환
sub min {
	return ($_[0] < $_[1]) ? $_[0] : $_[1];
}

# 비밀번호엔코드
sub encode {
	if($cryptOn == 1) {
		return crypt($_[0], 'h2');
	} else {
		return $_[0];
	}
}

# 1000억단위원형메루틴
sub aboutMoney {
	my($m) = @_;

	my $order = 10 ** ($HhideMoneyMode - 2);
	my $money;

	if($m < 500 * $order) {
		$money = 500 * $order;
		return "추정${money}${HunitMoney}미만";
	} else {
		$m = int(($m + 500 * $order) / (1000 * $order));
		$money = $m * 1000 * $order;
		return "추정${money}${HunitMoney}";
	}
}

# 10발단위원형메루틴
sub aboutMissile {
	my($m) = @_;
	if($m < 5) {
		return "추정10${HunitMissile}미만";
	} else {
		$m = int(($m + 5) / 10);
		return "추정${m}0${HunitMissile}";
	}
}

# 이스케이프문자의 처리
sub htmlEscape {
	my($s, $mode) = @_;
	$s =~ s/&/&amp;/g;
	$s =~ s/</&lt;/g;
	$s =~ s/>/&gt;/g;
	$s =~ s/\"/&quot;/g; #"
	if ($mode) {
		$s =~ s/\r\n/<br>/g;
		$s =~ s/\r/<br>/g;
		$s =~ s/\n/<br>/g;
		$s =~ s/(<br>){5,}//g; # 대량 줄바꿈대책
	}
	return $s;
}

# 80자리에절리갖춤에
sub cutColumn {
	my($s, $c) = @_;

	if(length($s) <= $c) {
		return $s;
	} else {
		if($HlengthAlert) {
			unlock();
			tempHeader();
			tempWrong("문자 수 초과 입니다!");
			tempFooter();
			exit(0);
		}
		# 합계80자리가 됨까지절리 처리
		my($ss) = '';
		my($count) = 0;
		while($count < $c) {
			$s =~ s/(^[\x80-\xFF][\x80-\xFF])|(^[\x00-\x7F])//;
			if($1) {
				$ss.= $1;
				$count ++;
			} else {
				$ss.= $2;
			}
			$count ++;
		}
		return $ss;
	}
}

# 괴수의 정보
sub monsterSpec {
	my($lv) = @_;

	# 종류
	my($kind) = ($lv>> 4) & 31;

	# 이름
	my($name);
	$name = $HmonsterName[$kind];

	# 체력
	my($hp) = ($lv & 15);

	return ($kind, $name, $hp);
}

# 괴수의 정보
sub hugeMonsterSpec {
	my($lv) = @_;

	# 종류
	my($kind) = ($lv>> 9) & 7;

	# 육 바다플래그
	my($sea) = ($lv>> 7) & 3;

	# 거대괴수플래그
	my($huge) = ($lv>> 4) & 7;

	# 이름
	my($name);
	$name = $HhugeMonsterName[$kind];

	# 체력
	my($hp) = ($lv & 15);

	return ($kind, $sea, $huge, $name, $hp);
}

# 경험치에서 레벨을 산출
sub expToLevel {
	my($kind, $exp) = @_;
	my($i);
	if($kind == $HlandBase) {
		# 미사일 기지
		for($i = $maxBaseLevel; $i> 1; $i--) {
			if($exp>= $baseLevelUp[$i - 2]) {
				return $i;
			}
		}
		return 1;
	} else {
		# 해저 기지
		for($i = $maxSBaseLevel; $i> 1; $i--) {
			if($exp>= $sBaseLevelUp[$i - 2]) {
				return $i;
			}
		}
		return 1;
	}

}

# (0,0)에서(size - 1, size - 1)까지의 숫자가한 번씩 나오도록
# (@Hrpx, @Hrpy)을 설정
sub makeRandomPointArray {
	# 초기 값
	my($y);
	@Hrpx = (0..$islandSize) x $HislandSize;
	foreach $y (0..$islandSize) {
		push(@Hrpy, ($y) x $HislandSize);
	}

	# 셔터 전체
	my ($i, $j);
	for ($i = $HpointNumber; --$i; ) {
		$j = int(rand($i+1));
		next if($i == $j);
		@Hrpx[$i,$j] = @Hrpx[$j,$i];
		@Hrpy[$i,$j] = @Hrpy[$j,$i];
	}
}

# 0에서(n - 1)의 난수
sub random {
	return int(rand(1) * $_[0]);
}

# 부여했습니다숫자 값에 대응하다의 심유사난수(0에서9의 정수만)
sub seqnum {
	my($v) = sin($_[0] + 1234); # 1234은 임의 정수, 난수의 계열을 변경 가능
	return (substr($v, -2, 1));
}

# 정렬
sub islandSort {
	my($kind, $mode) = @_;

	# 인구가 같으면 이전 턴의 순서를 유지
	my @idx = (0..$#Hislands);
	@idx = sort {
		$Hislands[$b]->{'field'} <=> $Hislands[$a]->{'field'} ||
		$Hislands[$a]->{'dead'} <=> $Hislands[$b]->{'dead'} || # 사멸플래그가 설정되어 있으면후로 로
		$Hislands[$b]->{$kind} <=> $Hislands[$a]->{$kind} ||
		$a <=> $b
	} @idx;
	@Hislands = @Hislands[@idx] if($kind eq 'pts');
	if($mode) {
		my @Hidx;
		foreach (0..$#idx) {
			$Hidx[$idx[$_]] = $_;
		}
		while (my($k,$v) = each %HidToNumber){
			$HidToNumber{$k} = $Hidx[$v];
		}
	}

	return $Hislands[$idx[$HbfieldNumber]];
}

# 인구순에정렬(동맹버전)
sub allySort {
	# 인구가 같으면 이전 턴의 순서를 유지
	my @idx = (0..$#Hally);
	@idx = sort {
			$Hally[$a]->{'dead'} <=> $Hally[$b]->{'dead'} || # 사멸플래그가 설정되어 있으면후로 로
			$Hally[$b]->{'score'} <=> $Hally[$a]->{'score'} ||
			$a <=> $b
		 } @idx;
	@Hally = @Hally[@idx];
	my @Hidx;
	foreach (0..$#idx) {
		$Hidx[$idx[$_]] = $_;
	}
	while (my($k,$v) = each %HidToAllyNumber){
		$HidToAllyNumber{$k} = $Hidx[$v];
	}
}
#----------------------------------------------------------------------
# 로그 표시
#----------------------------------------------------------------------
# 파일 번호를 지정해 로그 표시
sub logFilePrint {
	my($fileNumber, $id, $mode) = @_;
	my($set_turn) = 0;
	open(LIN, "${HdirName}/hakojima.log$_[0]");
	my($line, $m, $turn, $id1, $id2, $message);
	while($line = <LIN>) {
		$line =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),(.*)$/;
		($m, $turn, $id1, $id2, $message) = ($1, $2, $3, $4, $5);

		# 기밀관계
		if($m == 1) {
			if(($mode == 0) || ($id1 != $id)) {
				# 기밀 표시 권한 없음
				next;
			}
			$m = '<B>(기밀)</B>:';
		} else {
			$m = '';
		}

		# 정확히 표시할지
		if($id != 0) {
			if(($id != $id1) &&
			 ($id != $id2)) {
				next;
			}
		}

		if(!$set_turn){
			if(!$Hseason) {
				out("<B>=====[<span class=number><FONT SIZE=4> 턴$turn </FONT></span>]================================================</B><BR>\n");
			} else {
				# 계절의 표시
				my @seasonName = ('<span class=winter>겨울</span>','<span class=spring>봄</span>','<span class=summer>여름</span>','<span class=autumn>가을</span>');
				my $month = ($turn % 12) + 1;
				my $year = ($turn / 12) + 1;
				my $calender = sprintf('<span class=month><FONT SIZE=2><small>%s</small> %d년 %d월 </FONT></span>', $Halmanac, $year, $month);
				$calender.= "<span class='season'>$seasonName[int(($month - 1) / 3)]</span>";
				out("<B>=====[<span class=number><FONT SIZE=4> <small>턴$turn</small> </FONT></span>]=============================$calender</B><BR>\n");
			}
			$set_turn++;
		}
		out(" ${m}$message<BR>\n");
	}
	close(LIN);
}

#----------------------------------------------------------------------
# 템플릿
#----------------------------------------------------------------------
# 초기화
sub tempInitialize {
	my($mode) = @_;

	# 섬 선택(기본값은 자신)
	$HislandList = getIslandList($defaultID, $mode);
	$HtargetList = getIslandList($defaultTarget, $mode);
}

# 섬 데이터 드롭다운 메뉴용
sub getIslandList {
	my($select, $mode) = @_;
	my($list, $name, $id, $s, $i);

	#섬 목록의 메뉴
	$list = '';
	foreach $i (0..$islandNumber) {
		$name = islandName($Hislands[$i]);
		$name =~ s/<[^<]*>//g;
		$id = $Hislands[$i]->{'id'};
		if($id eq $select) {
			$s = 'SELECTED';
		} else {
			$s = '';
		}
		$list.= "<OPTION VALUE=\"$id\" $s>${name}\n" if($mode || ($id <=100));
	}
	return $list;
}

# 잠금실패
sub tempLockFail {
	# 제목
	out(<<END);
${HtagBig_}동시접속오류입니다.<BR>
브라우저의'돌아가기'버튼을 누름시,<BR>
잠시 기다렸다가 다시오시 도시하세요.${H_tagBig}$HtempBack
END
}

# 강제 해제
sub tempUnlock {
	# 제목
	out(<<END);
${HtagBig_}지난 접속이 비정상 종료된 것 같습니다.<BR>
잠금을 강제 해제했습니다.${H_tagBig}$HtempBack
END
}

# 비밀번호 파일이 없음
sub tempNoPasswordFile {
	out(<<END);
${HtagBig_} 비밀번호 파일이열 수 없습니다.${H_tagBig}$HtempBack
END
}

# hakojima.dat 이 없음
sub tempNoDataFile {
	out(<<END);
${HtagBig_}데이터 파일을 열 수 없습니다.${H_tagBig}$HtempBack
END
}

# ID 차이 or 로컬 설정하지 않음 or 쿠키를 설정하지 않음
sub tempWrong {
	my($str) = @_;

	out(<<END);
<SCRIPT Language="JavaScript">
<!--
function init(){
}
function SelectList(theForm){
}
//-->
</SCRIPT>
${HtagBig_}$str${H_tagBig}$HtempBack
END
}

# 무언가문제발생
sub tempProblem {
	out(<<END);
${HtagBig_}문제발생, 일단복귀해 주세요.${H_tagBig}$HtempBack
END
}

# 헤더
sub tempHeader {

	$baseIMG = $HimageDir;
	if($HskinName ne '' ){
		$baseSKIN = $HskinName;
	} else {
		$baseSKIN = "${efileDir}/$HcssFile";
	}
	if($HseaonImgSet && $Hmonth) {
		$seasonIMG = "$HseasonImg[$Hmonth]/";
	} else {
		$seasonIMG = "";
	}
	my($mapsizeNumber) = $HidToNumber{$defaultID};
	my($mapsize) = $Hislands[$mapsizeNumber]->{'totoyoso'}->[0];
	if($mapsize =~ /\(mapsize\@(\d+)\)/){
		if($1 < 1){ $Hms1 = 1;} elsif($1> 32){ $Hms1 = 32;} else { $Hms1 = $1;}
	}
	else{ $Hms1 = 16;}
	$Hms2 = $Hms1*2;

	if($ENV{'HTTP_ACCEPT_ENCODING'}=~/gzip/ && $Hgzip == 1){
		print qq{Content-type: text/html; charset=UTF-8\n};
		print qq{Content-encoding: gzip\n\n};
		open(STDOUT,"| $HpathGzip/gzip -1 -c");
		print " " x 2048 if($ENV{HTTP_USER_AGENT}=~/MSIE/);
		print qq{<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">\n\n};
	}else{
		print qq{Content-type: text/html; charset=UTF-8\n\n};
		print qq{<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">\n\n};
	}

	out(<<END);
<HTML>
<HEAD>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
<TITLE>
$Htitle($versionInfo)
</TITLE>
<BASE HREF="${baseIMG}/${seasonIMG}">
<link rel="stylesheet" type="text/css" href="${baseSKIN}">
</HEAD>
$Body<DIV ID='BodySpecial'>
<DIV ID='LinkHead'>
$Hheader
<HR>
</DIV>
END
}

# 푸터
sub tempFooter {
	out(<<END);
<HR>
<DIV ID='LinkFoot'>
$Hfooter
<BR><BR><DIV align="right">
<B>Hakoniwa R.A. JS.$versionInfo(based on 020610model)</B>
END
##### 추가 친분20020307
	if($Hperformance) {
		my($uti, $sti, $cuti, $csti) = times();
		$uti += $cuti;
		$sti += $csti;
		my($cpu) = $uti + $sti;

	#	 로그 파일 쓰기(테스트 계측용, 평소에는 주석 처리해 주세요)
	#	 open(POUT,">>cpu-h.log");
	#	 print POUT "CPU($cpu) : user($uti) system($sti)\n";
	#	 close(POUT);

		out(<<END);
 <SMALL>CPU($cpu) : user($uti) system($sti)</SMALL>
END
	}
#####
	out(<<END);
</DIV>
</DIV>
</DIV></BODY>
</HTML>
END
}

