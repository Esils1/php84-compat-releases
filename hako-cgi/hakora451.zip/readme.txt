하코니와 동맹 게시판

이 「게시판」은 KENT WEB(http://www.kent-web.com/)의 스크립트를 수정한 것이므로 아래 이용 규정에 동의해야 합니다.

CGI 스크립트 이용 규정 http://www.kent-web.com/pubc/kitei.html

※ 나가네코 님(http://ug.1st.to/)의 접속 분석 스크립트를 수정한 것도 함께 포함되어 있습니다.
　참고로 나가네코 님에게는 재배포 허락을 받았습니다. KENT 님에게도 재배포한다는 내용을 메일로 전달했습니다.

※ 이 스크립트는 무단 재배포를 금지합니다.neo_otacky-lj@infoseek.jp
