#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}
#----------------------------------------------------------------------
# 하코니와 제도 ver2.30
# 입출력용스크립트(ver1.00)
# 사용 조건과 사용 방법은 hako-readme.txt 파일을 참조해 주세요
#
# 하코니와 제도의 페이지: http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html
#----------------------------------------------------------------------
#----------------------------------------------------------------------
# Hakoniwa R.A. ver1.11
# 초기 설정용스크립트(하코니와 제도 ver2.30)
# 사용 조건, 사용 방법은 read-renas.txt 파일을 참조
#
# KEI PAGE: http://www5b.biglobe.ne.jp/~k-e-i/
#----------------------------------------------------------------------

#----------------------------------------------------------------------
# 섬 데이터 입출력
#----------------------------------------------------------------------

# 전체 섬 데이터 읽기
sub readIslandsFile {
	my($num) = @_;	# 0이면 지형읽기 전
					# -1이면 전체 지형을 읽어들임
					# 번호가 지정되면 해당 섬의 지형만 읽어들임

	# 데이터 파일 열기
	if(!open(IN, "${HdirName}/$HmainData")) {
		rename("${HdirName}/hakojima.tmp", "${HdirName}/$HmainData");
		return 0 if(!open(IN, "${HdirName}/$HmainData"));
	}

	# 각매개변수읽기
	my $tmp = <IN>;
	chomp($tmp);
	($HislandTurn, $HplayNow) = split(/,/, $tmp); # 턴 수, 게임안플래그
	$HislandLastTime= int(<IN>); # 최종 갱신 시간
	return 0 if(!$HislandLastTime);
	# unitTime 의덮어쓰기
	if ($HarmisticeTurn && ($HislandTurn < $HarmisticeTurn)) {
		$HarmTime = $HunitTime;
		$HunitTime = $HarmisticeTime;
	}

	$HislandNumber = int(<IN>); # 섬의 총 수
	$islandNumber = $HislandNumber - 1; # 섬의 총 수 - 1
	# 다음에 할당할 ID와 관리자 위임 임시 섬 ID
	my $tmp = <IN>;
	chomp($tmp);
	($HislandNextID, @HpreDeleteID) = split(/,/, $tmp);

	# flexTime 처리
	$HunitTime = 3600 * $HflexTime[($HislandTurn % ($#HflexTime + 1))] if($HflexTimeSet);
	# 계절 처리
	$Hmonth = 0;
	if($Hseason) {
		$Hmonth = ($HislandTurn % 12) + 1;
		$Hyear = ($HislandTurn / 12) + 1;
	}

	# 턴 처리판정
	my($now) = time;
	my $flag = 0;	# 턴 갱신전은0, 갱신 때는1
	my $tempMode = $HmainMode;
	if (
		( ($Hdebug && ($HmainMode eq 'Hdebugturn')) || (($now - $HislandLastTime)>= $HunitTime) )
		&&
		( !$HgameLimitTurn || ($HislandTurn < $HgameLimitTurn) )
		&&
		( !$HsurvivalTurn || ($HislandNumber != 1) || ($HislandTurn <= $HsurvivalTurn) )
		) {
		$HmainMode = 'turn';
		$num = -1; # 전체 섬읽어들임
		$flag = 1; # 갱신플래그를1에
	}

	$HnextTime = $HislandLastTime + $HunitTime;
	if($flag) {
		if($HflexTimeSet) {
			$HnextTime += 3600 * $HflexTime[(($HislandTurn + 1) % ($#HflexTime + 1))];
		} else {
			$HnextTime += $HunitTime;
		}
	}
	if((!$HgameLimitTurn || ($HislandTurn + $flag <= $HgameLimitTurn)) && (!$HsurvivalTurn || ($HislandNumber != 1) || ($HislandTurn <= $HsurvivalTurn))) {
		$HleftTime = $HnextTime - $now;
		$HplayNow = 1;
		$HnextTime = sprintf('%d월 %d일 %d 때', (gmtime($HnextTime + $Hjst))[4] + 1, (gmtime($HnextTime + $Hjst))[3,2]);
	} else {
		$HplayNow = 0;
		$HnextTime = ' ';
	}

	# howner.dat 읽기
	if (!$HnewGameO) {
		if (open(OIN, "<${HdirName}/howner.dat")) {
			foreach $i (0..$islandNumber) {
				my($ownername, @totoyoso, $shutomessage);
				$Hislands[$i]->{'id1'} = int(<OIN>); # 실은, 사용되지 않음
				$ownername = <OIN>;
				chomp($ownername); # 실은, 사용되지 않음
				$Hislands[$i]->{'owner'} = $ownername;
				my $tmp = <OIN>;
				chomp($tmp);
				@totoyoso = split(/,/, $tmp);
				$Hislands[$i]->{'totoyoso'} = \@totoyoso;
				$shutomessage = <OIN>;
				chomp($shutomessage);
				$Hislands[$i]->{'shutomessage'} = $shutomessage;
				$Hislands[$i]->{'kei'} = int(<OIN>);
				$Hislands[$i]->{'rena'} = int(<OIN>);
				# 사용되지 않음'momotan'을'시간의 신전' 플래그에재사용
				my $shr = <OIN>;
				chomp($shr);
				($Hislands[$i]->{'shr'}, $Hislands[$i]->{'shrturn'}) = split(/,/, $shr);
				$Hislands[$i]->{'fore'} = int(<OIN>);
				$Hislands[$i]->{'pika'} = int(<OIN>);
				$Hislands[$i]->{'hamu'} = int(<OIN>);
				$Hislands[$i]->{'monta'} = int(<OIN>);
				$Hislands[$i]->{'tare'} = int(<OIN>);
				$Hislands[$i]->{'zipro'} = int(<OIN>);
				$Hislands[$i]->{'leje'} = int(<OIN>);
			}
			close(OIN);
		} else {
			foreach $i (0..$islandNumber) {
				$Hislands[$i]->{'id1'} = ($Hislands[$i]->{'id'}) + 1;
				$Hislands[$i]->{'owner'} = $Hislands[$i]->{'onm'};
				@totoyoso = ('', '');
				$Hislands[$i]->{'totoyoso'} = \@totoyoso;
				$Hislands[$i]->{'shutomessage'} = 555;
				$Hislands[$i]->{'kei'} = 0;
				$Hislands[$i]->{'rena'} = 0;
				$Hislands[$i]->{'shr'} = 0;
				$Hislands[$i]->{'fore'} = 0;
				$Hislands[$i]->{'pika'} = 0;
				$Hislands[$i]->{'hamu'} = 0;
				$Hislands[$i]->{'monta'} = 0;
				$Hislands[$i]->{'tare'} = 0;
				$Hislands[$i]->{'zipro'} = 0;
				$Hislands[$i]->{'leje'} = 0;
			}
		}
	}

	# 섬읽기
	my($i);
	$HbfieldNumber = 0;
	foreach $i (0..$islandNumber) {
		$Hislands[$i] = readIsland($num, $i);
		$HidToNumber{$Hislands[$i]->{'id'}} = $i;
		if($Hislands[$i]->{'id'}> 100) {
			$HbfieldNumber++;
			$Hislands[$i]->{'field'} = 1;
		} else {
			foreach (@HpreDeleteID) {
				if($Hislands[$i]->{'id'} == $_) {
					$Hislands[$i]->{'predelete'} = 1;
				}
			}
		}
	}
	# No.1
	@HrankingID = split(/,/, <IN>);
	# 파일을 닫기
	close(IN);


	# 괴수출현 수읽기
	if (!$HnewGame) {
		if (open(MIN, "<${HdirName}/monslive.dat")) {
			foreach $i (0..$islandNumber) {
				$Hislands[$i]->{'monsterlive'} = int(<MIN>);
				my $tmp = <MIN>;
				chomp($tmp);
				($Hislands[$i]->{'monsterlivetype'}, $Hislands[$i]->{'hmonsterlivetype'}) = split(/,/, $tmp);
				$Hislands[$i]->{'eisei1'} = int(<MIN>);
				$Hislands[$i]->{'eisei2'} = int(<MIN>);
				$Hislands[$i]->{'eisei3'} = int(<MIN>);
				$Hislands[$i]->{'eisei4'} = <MIN>;
				chomp($Hislands[$i]->{'eisei4'});
				$Hislands[$i]->{'eisei5'} = <MIN>;
				chomp($Hislands[$i]->{'eisei5'});
				$Hislands[$i]->{'eisei6'} = <MIN>;
				chomp($Hislands[$i]->{'eisei6'});
			}
			close(MIN);
		} else {
			foreach $i (0..$islandNumber) {
				$Hislands[$i]->{'monsterlive'} = 0;
				$Hislands[$i]->{'monsterlivetype'} = 0;
				$Hislands[$i]->{'hmonsterlivetype'} = 0;
				$Hislands[$i]->{'eisei1'} = 0;
				$Hislands[$i]->{'eisei2'} = 0;
				$Hislands[$i]->{'eisei3'} = 0;
				$Hislands[$i]->{'eisei4'} = '0,0,0,0,0,0,0,0,0,0,0';
				$Hislands[$i]->{'eisei5'} = '0,0,0,0,0,0,0';
				$Hislands[$i]->{'eisei6'} = '0,0,0,0,0,0,0,0,0,0,0,0';
			}
		}
	}

	# 미사일 발사 가능 횟수 읽기
	if (!$HnewGameM) {
		if (open(MIN, "<${HdirName}/missiles.dat")) {
			foreach $i (0..$islandNumber) {
				$Hislands[$i]->{'missiles'} = int(<MIN>);
			}
			close(MIN);
		} else {
			foreach $i (0..$islandNumber) {
				$Hislands[$i]->{'missiles'} = 0;
			}
		}
	}

	if (
		!$HplayNow ||
		$HitemComplete ||
		($HsurvivalTurn && ($islandNumber == $HbfieldNumber) && ($HislandTurn> $HsurvivalTurn))
	 ) {
		# 중단 모드에 변경
		$HmainMode = ($tempMode ne '') ? $tempMode : 'top';
		$HplayNow = 0;
		$HnextTime = ' ';
	}

	# 동맹 데이터 읽기
	readAllyFile() if($HallyUse || $HsurvivalTurn || ($HmainMode eq 'asetup'));
	return 1;
}

# 섬 하나 읽기
sub readIsland {
	my($num, $iNo) = @_;
	my($name, $id, $prize, $absent, $comment, $password, $money, $food,
	 $pop, $area, $farm, $factory, $mountain, $pts, $eis1, $eis2, $eis3, $eis4, $eis5, $eis6, $taiji, $onm,
	 $id1, $ownername, @totoyoso, $shutomessage, $kei, $rena, $shrtmp, $shr, $shrturn, $fore, $pika, $hamu, $monta, $tare, $zipro, $leje,
	 $monslive, $monslivetype, $hmonslivetype, $eisei1, $eisei2, $eisei3, $eisei4, $eisei5, $eisei6,
	 $missiles, $score, $army_resouce, $extstr, @ext);
	$name = <IN>;	# 섬 이름
	chomp($name);
	if($name =~ s/,(.*)$//g) {
		$score = int($1); # 미사용
	} else {
		$score = 0;
	}
	$id = int(<IN>); # ID 번호
	$prize = <IN>; # 수상
	chomp($prize);
	my $r = "\r";
	$prize =~ s/$r//g;
	$absent = int(<IN>); # 연속 자금융통 수
	$comment = <IN>;	 # 코멘트
	chomp($comment);
	$password = <IN>;	# 암호화 비밀번호
	chomp($password);
	$money = int(<IN>);	 # 자금
	$food = int(<IN>);	 # 식량
	$pop = int(<IN>);	 # 인구
	$area = int(<IN>);	 # 면적
	$farm = int(<IN>);	 # 농장
	$factory = int(<IN>); # 공장
	$mountain = int(<IN>); # 채굴장
	$pts = int(<IN>);	 # 포인트
	$eis1 = int(<IN>); # 기상위성
	$eis2 = int(<IN>); # 관측위성
	$eis3 = int(<IN>); # 요격위성
	$eis4 = int(<IN>); # 군사위성
	$eis5 = int(<IN>); # 방위위성
	$eis6 = int(<IN>); # 비정상
	$extstr = <IN>; # 확장 영역(미사용 $eis7을 재사용)
	chomp($extstr);
	@ext = split(/\,/,$extstr);
	$army_resouce = int(<IN>); # 군사 물자(미사용 $eis8을 재사용)
	$taiji = int(<IN>); # 괴수퇴치 수
	$onm = <IN>; # 소유자 이름
	chomp($onm);
#	my $r = "\r";
#	$onm =~ s/$r//g;
	$id1 = $id; # ID 번호(미사용)
	$ownername = $onm; # 소유자 이름(미사용)

	if($HnewGameO) {
		my $tmp = <IN>; # toto 예상(좌우)
		chomp($tmp);
		@totoyoso = split(/,/, $tmp);
		$shutomessage = <IN>; # 수도 이름
		chomp($shutomessage);
		$kei = int(<IN>); # 기념비의 수
		$rena = int(<IN>); # 미사일 기지와 해저 기지의 경험치
		$shrtmp = <IN>; # 미사용 'momotan'을'시간의 신전' 플래그에재사용
		chomp($shrtmp);
		($shr, $shrturn) = split(/,/, $shrtmp);
		$fore = int(<IN>); # 숲규모
		$pika = int(<IN>); # 증가 자금
		$hamu = int(<IN>); # 증가인구
		$monta = int(<IN>); # 증가포인트
		$tare = int(<IN>); # 양계장규모
		$zipro = int(<IN>); # 양돈장규모
		$leje = int(<IN>); # 목장규모
	} else {
		@totoyoso = ($Hislands[$iNo]->{'totoyoso'}->[0], $Hislands[$iNo]->{'totoyoso'}->[1]);
		$shutomessage = $Hislands[$iNo]->{'shutomessage'};
		$kei = $Hislands[$iNo]->{'kei'};
		$rena = $Hislands[$iNo]->{'rena'};
		$shr = $Hislands[$iNo]->{'shr'};
		$shrturn = $Hislands[$iNo]->{'shrturn'};
		$fore = $Hislands[$iNo]->{'fore'};
		$pika = $Hislands[$iNo]->{'pika'};
		$hamu = $Hislands[$iNo]->{'hamu'};
		$monta = $Hislands[$iNo]->{'monta'};
		$tare = $Hislands[$iNo]->{'tare'};
		$zipro = $Hislands[$iNo]->{'zipro'};
		$leje = $Hislands[$iNo]->{'leje'};
	}
	if($HnewGame) {
		$monslive = int(<IN>); # 괴수출현 수
		my $tmp = <IN>; # 괴수출현종류
		chomp($tmp);
		($monslivetype, $hmonslivetype) = split(/,/, $tmp);
		$eisei1 = int(<IN>); # 세율
		$eisei2 = int(<IN>); # 통산 관광객 수
		$eisei3 = int(<IN>); # 미사용
		$eisei4 = <IN>; # 사카팀·데이터
		chomp($eisei4);
		$eisei5 = <IN>; #페와·데이터
		chomp($eisei5);
		$eisei6 = <IN>; #유니크 지형·데이터
		chomp($eisei6);
	}
	$missiles = int(<IN>) if ($HnewGameM); # 미사일 발사 가능 횟수

	# HidToName 테이블에 저장
	$HidToName{$id} = $name;

	# 지형
	my(@land, @landValue, $line, @command, @lbbs);

	if(($num == -1) || ($num == $id)) {
		if(!open(IIN, "${HdirName}/${id}.${HsubData}")) {
			if(-e "${HdirName}/${id}tmp.${HsubData}") {
				rename("${HdirName}/${id}tmp.${HsubData}", "${HdirName}/${id}.${HsubData}");
			} elsif(-e "${HdirName}/${HsubDataold}.${id}") {
				rename("${HdirName}/${HsubDataold}.${id}", "${HdirName}/${id}.${HsubData}");
			}
			if(!open(IIN, "${HdirName}/${id}.${HsubData}")) {
				exit(0);
			}
		}
		my($x, $y, $i);
		foreach $y (0..$islandSize) {
			$line = <IIN>;
			foreach $x (0..$islandSize) {
				$line =~ s/^(..)(...)//;
				$land[$x][$y] = hex($1);
				$landValue[$x][$y] = hex($2);
				if($land[$x][$y] == $HlandShrine && $landValue[$x][$y]> 0 && $shrturn) {
					$landValue[$x][$y] = $shrturn;
				}
			}
		}

		# 명령
		for($i = 0; $i < $HcommandMax; $i++) {
			$line = <IIN>;
			$line =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
			$command[$i] = {
					'kind' => int($1),
					'target' => int($2),
					'x' => int($3),
					'y' => int($4),
					'arg' => int($5)
				}
		}

		# 로컬 게시판
		for($i = 0; $i < $HlbbsMax; $i++) {
			$line = <IIN>;
			chomp($line);
			if ($HlbbsOldToNew) {
				# 게시판 로그의 형식을 변환하다
				if ($line =~ /^([0-9]*)\>(.*)\>(.*)$/) {
					# 표준 형식 로그임
					$line = "0<<$1>$2>$3";
				}
			}
			$lbbs[$i] = $line;
		}

		close(IIN);
	}

	# 섬 형태로 반환
	return {
		'name' => $name,
		'owner' => $ownername,
		'id' => $id,
		'id1' => $id1,
		'score' => $score,
		'prize' => $prize,
		'absent' => $absent,
		'comment' => $comment,
		'password' => $password,
		'money' => $money,
		'food' => $food,
		'pop' => $pop,
		'area' => $area,
		'farm' => $farm,
		'factory' => $factory,
		'mountain' => $mountain,
		'pts' => $pts,
		'eis1' => $eis1,
		'eis2' => $eis2,
		'eis3' => $eis3,
		'eis4' => $eis4,
		'eis5' => $eis5,
		'eis6' => $eis6,
		'ext' => \@ext,
		'army' => $army_resouce,
		'taiji' => $taiji,
		'onm' => $onm,
		'monsterlive' => $monslive,
		'monsterlivetype' => $monslivetype,
		'hmonsterlivetype' => $hmonslivetype,
		'eisei1' => $eisei1,
		'eisei2' => $eisei2,
		'eisei3' => $eisei3,
		'eisei4' => $eisei4,
		'eisei5' => $eisei5,
		'eisei6' => $eisei6,
		'missiles' => $missiles,
		'totoyoso' => \@totoyoso,
		'shutomessage' => $shutomessage,
		'kei' => $kei,
		'rena' => $rena,
		'shr' => $shr,
		'shrturn' => $shrturn,
		'fore' => $fore,
		'pika' => $pika,
		'hamu' => $hamu,
		'monta' => $monta,
		'tare' => $tare,
		'zipro' => $zipro,
		'leje' => $leje,
		'land' => \@land,
		'landValue' => \@landValue,
		'command' => \@command,
		'lbbs' => \@lbbs,
	};
}

# 전체 섬 데이터 쓰기
sub writeIslandsFile {
	my($num) = @_;

	# 파일을 열기
	open(OUT, ">${HdirName}/hakojima.tmp");

	# 각매개변수쓰기
	print OUT "$HislandTurn\n";
	print OUT "$HislandLastTime\n";
	print OUT "$HislandNumber\n";
	print OUT "$HislandNextID,". join(',', @HpreDeleteID). "\n";

	# 섬의 쓰기
	my($i);
	foreach $i (0..$islandNumber) {
		writeIsland($Hislands[$i], $num);
	}

	print OUT join(',', @HrankingID);
	# 파일을 닫기
	close(OUT);

	# howner.dat 쓰기
	if (!$HnewGameO) {
		if (open(OIN, ">${HdirName}/howner.tmp")) {
			foreach $i (0..$islandNumber) {
				print OIN $Hislands[$i]->{'id1'}. "\n";
				print OIN $Hislands[$i]->{'owner'}. "\n";
				my $totoyoso = $Hislands[$i]->{'totoyoso'};
				print OIN join(',', @$totoyoso). "\n";
				print OIN $Hislands[$i]->{'shutomessage'}. "\n";
				print OIN $Hislands[$i]->{'kei'}. "\n";
				print OIN $Hislands[$i]->{'rena'}. "\n";
				print OIN $Hislands[$i]->{'shr'}. ','. $Hislands[$i]->{'shrturn'}. "\n";
				print OIN $Hislands[$i]->{'fore'}. "\n";
				print OIN $Hislands[$i]->{'pika'}. "\n";
				print OIN $Hislands[$i]->{'hamu'}. "\n";
				print OIN $Hislands[$i]->{'monta'}. "\n";
				print OIN $Hislands[$i]->{'tare'}. "\n";
				print OIN $Hislands[$i]->{'zipro'}. "\n";
				print OIN $Hislands[$i]->{'leje'}. "\n";
			}
			close(OIN);
		}
	}

	# 괴수출현 수의 쓰기
	if (!$HnewGame) {
		if (open(MIN, ">${HdirName}/monslive.tmp")) {
			foreach $i (0..$islandNumber) {
				print MIN $Hislands[$i]->{'monsterlive'}. "\n";
				print MIN $Hislands[$i]->{'monsterlivetype'}. ",". $Hislands[$i]->{'hmonsterlivetype'}. "\n";
				print MIN $Hislands[$i]->{'eisei1'}. "\n";
				print MIN $Hislands[$i]->{'eisei2'}. "\n";
				print MIN $Hislands[$i]->{'eisei3'}. "\n";
				print MIN $Hislands[$i]->{'eisei4'}. "\n";
				print MIN $Hislands[$i]->{'eisei5'}. "\n";
				print MIN $Hislands[$i]->{'eisei6'}. "\n";
			}
			close(MIN);
		}
	}

	# 미사일 발사 가능 횟수 쓰기
	if (!$HnewGameM) {
		if (open(MIN, ">${HdirName}/missiles.tmp")) {
			foreach $i (0..$islandNumber) {
				print MIN $Hislands[$i]->{'missiles'}. "\n";
			}
			close(MIN);
		}
	}

	# 동맹 데이터의 쓰기
	writeAllyFile() if($HallyUse || $HarmisticeTurn || ($HmainMode eq 'asetup'));

	# 섬의 쓰기
	my($i, $id);
	foreach $i (0..$islandNumber) {
		$id = $Hislands[$i]->{'id'};
		if(($num <= -1) || ($num == $id)) {
			unlink("${HdirName}/${id}.${HsubData}");
			rename("${HdirName}/${id}tmp.${HsubData}", "${HdirName}/${id}.${HsubData}");
		}
	}
	# 원래 이름으로
	unlink("${HdirName}/$HmainData");
	rename("${HdirName}/hakojima.tmp", "${HdirName}/$HmainData");
	# howner.dat
	if (!$HnewGameO) {
		unlink("${HdirName}/howner.dat");
		rename("${HdirName}/howner.tmp", "${HdirName}/howner.dat");
	}
	# 괴수출현 수
	if (!$HnewGame) {
		unlink("${HdirName}/monslive.dat");
		rename("${HdirName}/monslive.tmp", "${HdirName}/monslive.dat");
	}
	# 미사일 발사 가능 횟수
	if (!$HnewGameM) {
		unlink("${HdirName}/missiles.dat");
		rename("${HdirName}/missiles.tmp", "${HdirName}/missiles.dat");
	}

}

# 섬 하나 쓰기
sub writeIsland {
	my($island, $num) = @_;
	my($score);
	$score = int($island->{'score'});
	print OUT $island->{'name'}. ",$score\n";
	print OUT $island->{'id'}. "\n";
	print OUT $island->{'prize'}. "\n";
	print OUT $island->{'absent'}. "\n";
	print OUT $island->{'comment'}. "\n";
	print OUT $island->{'password'}. "\n";
	print OUT $island->{'money'}. "\n";
	print OUT $island->{'food'}. "\n";
	print OUT $island->{'pop'}. "\n";
	print OUT $island->{'area'}. "\n";
	print OUT $island->{'farm'}. "\n";
	print OUT $island->{'factory'}. "\n";
	print OUT $island->{'mountain'}. "\n";
	print OUT $island->{'pts'}. "\n";
	print OUT $island->{'eis1'}. "\n";
	print OUT $island->{'eis2'}. "\n";
	print OUT $island->{'eis3'}. "\n";
	print OUT $island->{'eis4'}. "\n";
	print OUT $island->{'eis5'}. "\n";
	print OUT $island->{'eis6'}. "\n";
	print OUT join(',', @{$island->{'ext'}}). "\n";
	print OUT $island->{'army'}. "\n";
	print OUT $island->{'taiji'}. "\n";
	print OUT $island->{'onm'}. "\n";

	# 지형
	my $id = $island->{'id'};
	if(($num <= -1) || ($num == $id)) {
		open(IOUT, ">${HdirName}/${id}tmp.${HsubData}");

		my($land, $landValue);
		$land = $island->{'land'};
		$landValue = $island->{'landValue'};
		my($x, $y);
		foreach $y (0..$islandSize) {
			foreach $x (0..$islandSize) {
				unless($land->[$x][$y] == $HlandShrine && $landValue->[$x][$y]> 0) {
					printf IOUT ("%02x%03x", $land->[$x][$y], $landValue->[$x][$y]);
				} else {
					$island->{'shrturn'} = $landValue->[$x][$y];
					printf IOUT ("%02x%03x", $land->[$x][$y], 1);
				}
			}
			print IOUT "\n";
		}

		# 명령
		my($command, $cur, $i);
		$command = $island->{'command'};
		for($i = 0; $i < $HcommandMax; $i++) {
			printf IOUT ("%d,%d,%d,%d,%d\n",
							 $command->[$i]->{'kind'},
							 $command->[$i]->{'target'},
							 $command->[$i]->{'x'},
							 $command->[$i]->{'y'},
							 $command->[$i]->{'arg'}
						 );
		}

		# 로컬 게시판
		my($lbbs);
		$lbbs = $island->{'lbbs'};
		for($i = 0; $i < $HlbbsMax; $i++) {
			print IOUT $lbbs->[$i]. "\n";
		}

		close(IOUT);
	}

	if($HnewGameO) {
		my $totoyoso = $island->{'totoyoso'};
		print OUT join(',', @$totoyoso). "\n";
		print OUT $island->{'shutomessage'}. "\n";
		print OUT $island->{'kei'}. "\n";
		print OUT $island->{'rena'}. "\n";
		print OUT $island->{'shr'}. ','. $island->{'shrturn'}. "\n";
		print OUT $island->{'fore'}. "\n";
		print OUT $island->{'pika'}. "\n";
		print OUT $island->{'hamu'}. "\n";
		print OUT $island->{'monta'}. "\n";
		print OUT $island->{'tare'}. "\n";
		print OUT $island->{'zipro'}. "\n";
		print OUT $island->{'leje'}. "\n";
	}
	if($HnewGame) {
		print OUT $island->{'monsterlive'}. "\n";
		print OUT $island->{'monsterlivetype'}. ",". $island->{'hmonsterlivetype'}. "\n";
		print OUT $island->{'eisei1'}. "\n";
		print OUT $island->{'eisei2'}. "\n";
		print OUT $island->{'eisei3'}. "\n";
		print OUT $island->{'eisei4'}. "\n";
		print OUT $island->{'eisei5'}. "\n";
		print OUT $island->{'eisei6'}. "\n";
	}
	print OUT $island->{'missiles'}. "\n" if ($HnewGameM);
}

#----------------------------------------------------------------------
# 동맹 데이터입출력
#----------------------------------------------------------------------
# 동맹 데이터 읽기
sub readAllyFile {
	# 데이터 파일 열기
	if(!open(IN, "${HdirName}/${HallyData}")) {
		rename("${HdirName}/ally.tmp", "${HdirName}/${HallyData}");
		if(!open(IN, "${HdirName}/${HallyData}")) {
			return 0;
		}
	}

	# 동맹읽기
	my($i);
	$HallyNumber = int(<IN>); # 동맹의 총 수
	for ($i = 0; $i < $HallyNumber; $i++) {
		$Hally[$i] = readAlly();
		$HidToAllyNumber{$Hally[$i]->{'id'}} = $i;
	}
	# 가입한 동맹의 ID를 저장
	for ($i = 0; $i < $HallyNumber; $i++) {
		my $member = $Hally[$i]->{'memberId'};
		foreach (@$member) {
			my $n = $HidToNumber{$_};
			next unless(defined $n);
			push(@{$Hislands[$n]->{'allyId'}}, $Hally[$i]->{'id'});
		}
	}

	# 파일을 닫기
	close(IN);

	return 1;
}

# 동맹하나읽기
sub readAlly {
	my($name, $mark, $color, $id, $ownerName, $password, $jpass, $score, $number,
		$occupation, $allystr, @allymember, $extstr, @ext, $comment, $title, $message);
	$name = <IN>; # 동맹 이름
	chomp($name);
	$mark = <IN>; # 동맹의 식별 표시
	chomp($mark);
	$color = <IN>; # 식별 표시의 색
	chomp($color);
	$id = int<IN>; # 동맹 ID(주 행사자의 것와 함께)
	$ownerName = <IN>; # 주 행사자의 섬 이름
	chomp($ownerName);
	$password = <IN>; # 비밀번호(주 행사자의 것과 동일)
	chomp($password);
	$jpass = <IN>; # 비밀번호(Takayan 의 jpass:턴 갱신 때 치환용)
	chomp($jpass);
	$score = int(<IN>); # 동맹의 스코어
	$number = int(<IN>); # 동맹에 소속된 섬의 수
	$occupation = int(<IN>); # 점유율
	$allystr = <IN>;
	chomp($allystr);
	@allymember = split(/\,/,$allystr);
	$extstr = <IN>; # 확장 영역
	chomp($extstr);
	@ext = split(/\,/,$extstr);
	# ext[0] 발사한 미사일(unitCount 턴분)
	# ext[1] 피해를 받을 미사일(unitCount 턴분)
	# ext[2] 수입(unitCount 턴분)
	$comment = <IN>;
	chomp($comment);
	$message = <IN>;
	chomp($message);
	($title, $message) = split('<>', $message);

	# 진영 형태로 반환
	return {
		'name' => $name,
		'mark' => $mark,
		'color' => $color,
		'id' => $id,
		'oName' => $ownerName,
		'password' => $password,
		'Takayan' => $jpass,
		'score' => $score,
		'number' => $number,
		'occupation' => $occupation,
		'memberId' => \@allymember,
		'ext' => \@ext,
		'comment' => $comment,
		'title' => $title,
		'message' => $message,
	};
}

# 동맹 데이터 쓰기
sub writeAllyFile {
	# 파일을 열기
	open(OUT, ">${HdirName}/ally.tmp");

	# 진영 데이터의 쓰기
	print OUT "$HallyNumber\n";
	for($i = 0; $i < $HallyNumber; $i++) {
		writeAlly($Hally[$i]);
	}
	# 파일을 닫기
	close(OUT);

	# 원래 이름으로
	unlink("${HdirName}/${HallyData}");
	rename("${HdirName}/ally.tmp", "${HdirName}/${HallyData}");
}

# 동맹하나쓰기
sub writeAlly {
	my($ally) = @_;
	print OUT $ally->{'name'}. "\n";
	print OUT $ally->{'mark'}. "\n";
	print OUT $ally->{'color'}. "\n";
	print OUT $ally->{'id'}. "\n";
	print OUT $ally->{'oName'}. "\n";
	print OUT $ally->{'password'}. "\n";
	print OUT $ally->{'Takayan'}. "\n";
	print OUT $ally->{'score'}. "\n";
	print OUT $ally->{'number'}. "\n";
	print OUT $ally->{'occupation'}. "\n";
	my $memId = $ally->{'memberId'};
	print OUT join(',', @$memId). "\n";
	#확장 영역
	my $ext = $ally->{'ext'};
	print OUT join(',', @$ext). "\n";
	print OUT $ally->{'comment'}. "\n";
	print OUT $ally->{'title'}. '<>'. $ally->{'message'}. "\n";
}

# [a-zA-Z]로 구성된 8문자의 비밀번호를 만들기
sub makeRandomString {
	my($baseString) = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
	my($baseLen) = length($baseString);
	my($i, $passward);

	for ($i = 0; $i < 8; $i++) {
		$passward.= substr($baseString, rand($baseLen), 1);
	}

	return $passward;
}

# 동맹의 점유율의 계산
sub allyOccupy {
	my($i);
	my($totalScore) = 0;

	for ($i = 0; $i < $HallyNumber; $i++) {
		$totalScore += $Hally[$i]->{'score'};
	}
	for ($i = 0; $i < $HallyNumber; $i++) {
		if ($totalScore != 0) {
			$Hally[$i]->{'occupation'} = int($Hally[$i]->{'score'} / $totalScore * 100);
		} else {
			$Hally[$i]->{'occupation'} = int(100 / $HallyNumber);
		}
	}
	return;
}

# 섬포기의 때의 동맹 관련 처리
sub islandDeadAlly {
	my($island, $id, $name) = @_;

	$id = $island->{'id'} if($id eq '');
	$name = $island->{'name'} if($name eq '');
	my $n = $HidToAllyNumber{$id};
	if(defined $n) {
		if(!$HsurvivalTurn || ($Hally[$i]->{'number'} == 1)) {
			make_pastlog($id, $name);
			$Hally[$n]->{'dead'} = 1;
			$HidToAllyNumber{$id} = undef;
			$HallyNumber--;
			allySort();
		}
	} else {
		make_pastlog($id, $name) if(-f "${HlogdirName}/${id}$Hlogfile_name");
		foreach (@{$island->{'allyId'}}) {
			my $i = $HidToAllyNumber{$_};
			my $allyMember = $Hally[$i]->{'memberId'};
			my @newAllyMember = ();
			foreach (@$allyMember) {
				if(!(defined $HidToNumber{$_})) {
				} elsif($_ == $id) {
					$Hally[$i]->{'score'} -= $island->{'pts'};
					$Hally[$i]->{'number'} -= 1;
				} else {
					push(@newAllyMember, $_);
				}
			}
			$Hally[$i]->{'memberId'} = \@newAllyMember;
		}
	}
}

#----------------------------------------
# 과거 로그 처리(YY-BBS)
#----------------------------------------
sub make_pastlog {
	my($id, $name) = @_;
	# 로그 파일
	my $logfile = "${HlogdirName}/${id}$Hlogfile_name";
	my $logfileNew = "${HlogdirName}/${id}-${HislandTurn}$Hlogfile_name";
	return if !(-f $logfile);
	rename($logfile, $logfileNew);
	# 맹주 로그 파일
	my $logfile2 = "${HlogdirName}/${id}$Hlogfile2_name";
	my $logfile2New = "${HlogdirName}/${id}-${HislandTurn}$Hlogfile2_name";
	return if !(-f $logfile2);
	rename($logfile2, $logfile2New);
	# 카운터 파일
	if($Hcounter) {
		my $cntfile = "${HlogdirName}/${id}$Hcntfile_name";
		my $cntfileNew = "${HlogdirName}/${id}-${HislandTurn}$Hcntfile_name";
		return if !(-f $cntfile);
		rename($cntfile, $cntfileNew);
	}
	# 과거 로그용 NO 파일
	if($Hpastkey) {
		my $nofile = "${HlogdirName}/${id}$Hnofile_name";
		return if !(-f $nofile);
		# 과거 NO 을 열기
		open(NO,"$nofile") || die $!;
		my $count = <NO>;
		close(NO);
		my $nofileNew = "${HlogdirName}/${id}-${HislandTurn}$Hnofile_name";
		rename($nofile, $nofileNew);
		foreach (1..$count) {
			my $pastfile = sprintf("%s/%04d\.%d\.cgi", $HpastdirName,$_,$id);
			my $pastfileNew = sprintf("%s/%04d\.%d-%d\.cgi", $HpastdirName,$_,$id,$HislandTurn);
			rename($pastfile, $pastfileNew);
		}
	}
	# 소멸했습니다 동맹의 데이터를 저장
	my $ally = $Hally[$HidToAllyNumber{$id}];
	my $allyName = "<FONT COLOR=\"$ally->{'color'}\"><B>$ally->{'mark'}</B></FONT>$ally->{'name'}";
	if(!open(IN, "${HlogdirName}/dead${HallyData}")) {
		open(LOG, ">${HlogdirName}/dead${HallyData}") || die $!;
		close(LOG);
		open(IN, "${HlogdirName}/dead${HallyData}") || die $!;
	}
	my @lines = <IN>;
	close(IN);
	unshift(@lines, "${id}-${HislandTurn},$allyName,${name}${AfterName}\n");
	open(OUT, ">${HlogdirName}/dead${HallyData}");
	print OUT @lines;
	close(OUT);
}

# 섬 이름을 반환
sub islandName {
	my($island) = @_;

	my($name);
	foreach (@{$island->{'allyId'}}) {
		my $i = $HidToAllyNumber{$_};
		my $mark = $Hally[$i]->{'mark'};
		my $color = $Hally[$i]->{'color'};
		$name.= '<FONT COLOR="'. $color. '"><B>'. $mark. '</B></FONT>';
	}
	$name.= $island->{'name'}. $AfterName;

	return ($name);
}

#----------------------------------------------------------------------
# 비밀번호 확인
#----------------------------------------------------------------------
sub checkPassword {
	my($island, $p2) = @_;
	my $p1 = $island->{'password'};

	# null 확인
	if($p2 eq '') {
		return 0;
	}

	# 마스터 비밀번호 확인
	if(checkMasterPassword($p2)) {
		return 2;
	}

	# 본래의 확인
	if($p1 eq encode($p2)) {
		return 1;
	}

	if($island->{'preab'} && ($HmainMode ne 'preab') && ($HmainMode ne 'change')) {
		my $ally = $Hally[$HidToAllyNumber{$island->{'allyId'}[0]}];
		if($ally->{'Takayan'} eq $p2) {
			return 1;
		}
	}
	return 0;
}

# 마스터 비밀번호의 확인
sub checkMasterPassword {
	my $pass = shift;
	return (crypt($pass, 'ma') eq $HmasterPassword);
}

# 특수 비밀번호의 확인
sub checkSpecialPassword {
	my $pass = shift;
	return (crypt($pass, 'sp') eq $HspecialPassword || crypt($pass, 'ma') eq $HmasterPassword);
}

# 비밀번호의 엔코드
sub encode {
	my $pass = shift;
	return ($cryptOn ? crypt($pass, 'h2') : $pass);
}

# 비밀번호 오류
sub tempWrongPassword {
	axeslog(1, 'PASS error!') if($HtopAxes && $HtopAxes != 3);
	out(<<END);
<SCRIPT Language="JavaScript">
<!--
function init(){
}
function SelectList(theForm){
}
//-->
</SCRIPT>
<span class="big"> 비밀번호가 다릅니다.</span>
<A HREF=\"$HthisFile\"><span class="big">맨 위로 돌아가기</span></A>
END
	if($HpassError) {
		my $agent = $ENV{'HTTP_USER_AGENT'};
		my $addr = $ENV{'REMOTE_ADDR'};
		my $host = $ENV{'REMOTE_HOST'};
		if ($gethostbyaddr && (($host eq '') || ($host eq $addr))) {
			$host = gethostbyaddr(pack("C4", split(/\./, $addr)), 2) || $addr;
		} elsif($host eq '') {
			$host = $addr;
		}
		my($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = gmtime(time + $Hjst);
		my $day = ('일','월','불','수','목','금','와 지')[$wday];
		$year = $year + 1900;
		$mon = $mon + 1;
		my $date = sprintf("%04d/%02d/%02d(%s) %02d:%02d:%02d",$year,$mon,$mday,$day,$hour,$min,$sec);
		out(<<END);
<HR>
<TABLE><TR><TH><span class="big">[<span class='attention'>!경고!</span>]</span></TH></TR>
<TR><TD>당신의 정보를 기록했습니다.
 $date<BR><B>$host - $addr - $agent</B>
</TD></TR>
<TR><TD class='N'>
<BR><A HREF='http://www.ipa.go.jp/security/ciadr/law199908.html'><B>부정 접속 행위의 금지등에 관한법률</B></A>이2001년2월13일에시 행 진행되어했습니다.
<BR><BR>이 법률은 첨단 기술범죄를 방지하고 고도 정보통신 사회의 건전한 발전을 돕기 위해, 기존 형법으로 처벌하기 어려운 부정 접속 행위를 처벌 대상으로 삼는 법률입니다.
<BR><BR>형법에서는 명확한 피해가 발생하지 않으면 처벌하기 어려웠지만, 부정 접속금지법에서는,
<span class='attention'>부정 접속을 실행한 시점부터 처벌 대상이 됩니다.</span>
<BR><BR>실제의 법률을 물기미분쇄있고설명하면,
'<A HREF='http://www.ipa.go.jp/security/ciadr/law199908.html#부정 접속 행위'><B>부정 접속</B></A>란,<B> 비밀번호 등으로 보호된 영역에, 권한이 없는 사람이 임의로 접속하는 것</B>이며,
이를 위반한 경우 '<span class='attention'>1년 이하의 징역 또는 50만 엔 이하의 벌금</span>'이 부과될 수 있습니다.
<BR><BR>단순한 '비밀번호 입력 실수'라면 괜찮지만, 지나치게 빈번하면 <B>관리자로서 대응 조치를 취할 수밖에 없습니다.</B>
<BR><BR>${HtagTH_}반복해서 비밀번호 오류가 발생한 경우, 특별한 사유가 있다면, 아래의 '게시판' 또는 '메일' 링크로 연락해 주세요.${H_tagTH}
</TD></TR></TABLE>
END
	}
}

#----------------------------------------------------------------------
# 접속 로그가져오기
#----------------------------------------------------------------------
sub axeslog {
	my($mode, $error) = @_;
	my @lines;

	my $agent = $ENV{'HTTP_USER_AGENT'};
	my $addr = $ENV{'REMOTE_ADDR'};
	my $host = $ENV{'REMOTE_HOST'};
	my $referer = $ENV{'HTTP_REFERER'} if(!$mode);
	if (($host eq $addr) || ($host eq '')) {
		$host = gethostbyaddr(pack('C4',split(/\./,$addr)),2) || $addr;
	}
	my($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = gmtime(time + $Hjst);
	my $day = ('일','월','불','수','목','금','와 지')[$wday];
	$year = $year + 1900;
	$mon = $mon + 1;
	my $date = sprintf("%04d/%02d/%02d(%s) %02d:%02d:%02d",$year,$mon,$mday,$day,$hour,$min,$sec);
	my($pcheck);
	if($proxycheck) {
		my @proxy_env = (
			'HTTP_CACHE_CONTROL', # FORM 전송 때에 no_cache 이 됨처럼(·_·?
			'HTTP_CACHE_INFO',
			'HTTP_CLIENT_IP',
			'HTTP_FORWARDED',
			'HTTP_FROM',
			'HTTP_PROXY_CONNECTION',
			'HTTP_SP_HOST',
			'HTTP_VIA',
			'HTTP_X_FORWARDED_FOR',
			'HTTP_XONNECTION',
			'HTTP_XROXY_CONNECTION',
		);
		$pcheck = $ENV{'HTTP_CONNECTION'};
		foreach (@proxy_env){
			$pcheck.= '<>'. $ENV{$_};
		}
	}

	open(IN, "$HaxesLogfile");
	my @lines = <IN>;
	close(IN);

	while ($HaxesMax <= @lines) { pop @lines; }
	my $id;
	if($mode) {
		$id = ($defaultID eq $HcurrentID) ? $defaultID : "$defaultID=>$HcurrentID";
	} else {
		$id = $defaultID;
	}
	my $pass = $HinputPassword if(($error =~ /error/) || ($HtopAxes> 4));
	unshift(@lines, "[$date] - $referer - $host - $addr - $agent - $id - $pass - $error - $pcheck\n");

	if(open(OUT, ">$HaxesLogfile")){
		foreach $line (@lines) {
#			print OUT $line; # 문자 변환 라이브러리 사용 시
			print OUT $line;
		}
		close(OUT);
	} else {
		tempProblem();
		return;
	}
}

#----------------------------------------------------------------------
# 입출력
#----------------------------------------------------------------------

# 표준 출력으로 출력
sub out {
# UTF-8 환경에서는 별도 문자 변환 출력이 필요 없습니다
	print STDOUT $_[0];
}

# 디버그 로그
sub HdebugOut {
	open(DOUT, ">>debug.log");
	print DOUT ($_[0]);
	close(DOUT);
}

1;
