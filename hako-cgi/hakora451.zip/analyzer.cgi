#!/usr/bin/perl

#----------------------------------------------------------------------
# 하코니와 제도 ver2.30
# 접속 분석 스크립트(나가네코 님의 analyzer.cgi를 수정) ver1.03
#
# The Return of Neptune: http://hpcgi2.nifty.com/otacky/
#----------------------------------------------------------------------
#==================================================================
#	Log analyzer CGI
#
#  last update: 02/18/2002
#       author: 나가네코
#          url: http://www.midnightroam.org/
#
#
#  miniBBS++ 전용 접속 분석 CGI입니다. 로그 파일명은
#  miniBBS++의 접속 로그 파일을 지정해 주세요.
#
#	Copyright (c) 2000-2002  Twilight Heaven
#==================================================================
BEGIN {
	# Perl 5.004 이상이 필요
	require 5.004;

########################################
	# 오류 표시
	$SIG{__WARN__} = $SIG{__DIE__} =
	sub {
		my($msg) = @_;

		$msg =~ s/\n/<br>/g;
		print STDOUT <<END;
Content-type: text/html; charset=utf-8

<p><big><tt><b>ERROR:</b><br>$msg</tt></big></p>
END
		exit(-1);
	};
########################################
}

#use strict;

# 초기 설정 파일을 읽음
require './hako-init.cgi';
require './hako-io.cgi';

#=========================
# 초기 설정
#=========================
my $title        = 'Log analyzer CGI'; # 제목
my $logfile      = './axes.cgi';       # 로그 파일명(hako-main.cgi와 동일)
my $acss         = "$HcssDir/analyzer.css";       # 스킨 파일명

my $axeslog_no = 50;                   # 접속 로그 표시 수(최대 기록 건수 $HaxesMax보다 작은 값)
my $referer_hide = 0;                  # 리퍼러를 숨김으로 설정(1 -> Yes, 0 -> No)
my $referer_sweep = 1;                 # 링크 대상에 리퍼러를 넘기지 않음(2 -> Yes[JavaScript(IE만)], 1 -> Yes[CGI], 0 -> No)
my $delaytime = 0;                     # 리퍼러를넘기지 않음경우의、새로고침시간

my $separator = ' - ';                 # 각 행 항목의 구분 문자
my $id2name = 2;                       # ID를 섬 이름으로 표시(2 -> Yes[섬 이름(ID)], 1 -> Yes[섬 이름], 0 -> No[ID])
#=========================
# 초기 설정 여기까지
#=========================
my $copyright = "<DIV align=right>[ <A href=\"http://www.midnightroam.org/\">Log analyzer CGI</A> ]\n</DIV>";
my %CATEGORY = (
	'date'    => '일별',
	'hour'    => '시간대',
	'referer' => '리퍼러',
	'host'    => '호스트명',
	'addr'    => 'IP 주소',
	'agent'   => '브라우저명',
	'error'   => 'ERROR',
	'id'      => 'ID',
	'a'       => '접속 로그',
);
my @proxycheck = (
	'실제 IP이거나 익명성이 높은 프록시입니다. 프록시 징후는 전혀 보이지 않습니다.',
	'프록시 특유의 환경 변수가 노출되고 있습니다.',
	'호스트명에서 프록시 징후가 보입니다.',
	'프록시 특유의 환경 변수가 노출되고 있으며, 호스트명에도 프록시 징후가 있습니다.',
	'국가 코드 최상위 도메인(ccTLD)이 JP가 아닌 점이 신경 쓰입니다.',
	'프록시 특유의 환경 변수가 노출되고 있으며, 국가 코드 최상위 도메인(ccTLD)이 JP가 아닌 점도 다소 의심스럽습니다.',
	'호스트명에서 프록시 징후가 보이며, 국가 코드 최상위 도메인(ccTLD)도 JP가 아닙니다.',
	'거의 확실히 프록시입니다.',
	'IP 주소에서 호스트명을 찾지 못했습니다. 그 외 프록시 징후는 보이지 않습니다.',
	'IP 주소에서 호스트명을 찾지 못했지만, 프록시 특유의 환경 변수가 노출되고 있습니다.',
	'특별히 프록시다운 특징은 없지만, HTTP_CONNECTION이 close인 것은 프록시에서 자주 보이는 경향입니다.',
);
my $rs = <<"END" if(!$referer_hide && $referer_sweep);
<script Language="JavaScript">
<!--
function link(url){
  app = navigator.appName.charAt(0);
  if(app == 'M') { 
    w = window.open('','','');
    w.document.write("<html><head><meta HTTP-EQUIV='refresh' CONTENT='$delaytime; URL="+ url +"'></head><body></body></html>");
    w.location.reload();
  } else {
    document.write("<html><head><meta HTTP-EQUIV='refresh' CONTENT='$delaytime; URL="+ url +"'></head><body></body></html>");
  }
}
//-->
</script>
END

if (-e $HpasswordFile) {
	# 비밀번호 파일이 있음
	open(PIN, "<$HpasswordFile") || die $!;
	chomp($HmasterPassword = <PIN>); # 마스터 비밀번호 읽기
	chomp($HspecialPassword = <PIN>); # 특수 비밀번호 읽기
	close(PIN);
}

my $url = $ENV{'QUERY_STRING'};
$url =~ s/^url\=(.*)/$1/;
if ($url eq ''){
	# 폼에서 받은 값을 디코딩
	%FORM = &form_decode;
	$referer_hide = 1 if(!passCheck());

	if ($FORM{'mode'} eq 'analyze') {
		&analyze($FORM{'category'});
	} else {
		&html();
	}
} else {
	print <<"EOF";
Content-type: text/html; charset=utf-8

<html><head><title>Referrer-Sweeper</title>
<meta HTTP-EQUIV="refresh" CONTENT="$delaytime; URL=$url">
</head>$Body
$rs
<h1>접속 중입니다... 잠시 기다려 주세요...<hr><DIV align='center'>
<a href="$url" onclick="link('$url'); return false;">$url</a></DIV></h1></body></html>
EOF
}
#===============================
# 디코딩 처리
#===============================
sub form_decode {

	my($data, @pairs, %FORM);

	# 일반 요청 메서드는 「GET」, 「POST」처럼 대문자지만 안전을 위해 처리
	if (uc($ENV{'REQUEST_METHOD'}) eq 'POST') {
		read(STDIN, $data, $ENV{'CONTENT_LENGTH'});
		@pairs = split(/&/, $data);
		foreach (@pairs) {
			my($name,$value) = split(/=/, $_);
			$value =~ tr/+/ /;
			$value =~ s/%([a-fA-F0-9]{2})/pack(H2, $1)/eg;
			$value =~ s/&/&amp;/g;
			$value =~ s/</&lt;/g;
			$value =~ s/>/&gt;/g;
			$value =~ s/"/&quot;/g; #"
			$value =~ s/'/&#39;/g; #'
			$value =~ s/ /&#32;/g;
			$value =~ s/\r\n/\n/g;
			$value =~ s/\r|\n/<BR>/g;
			$FORM{$name} = $value;
			
			# 잘못된 입력 제거
			$FORM{'select_date'} =~ s/\"|\@|\/|\`|\\//g;
		}
	}
	
	return %FORM;
}
#=========================
# 분석 처리。
#=========================
sub analyze {

	if($id2name) {
		# 섬 데이터 읽기
		if(!readIslandsFile(0)){
			print <<END;
Content-type: text/html; charset=utf-8

<HTML><HEAD><TITLE>READ ERROR</TITLE>
<link rel="stylesheet" type="text/css" href="${HcssDir}/$HcssDefault">
</HEAD>$Body<h2>오류가 발생했습니다</h2></BODY></HTML>
END
		}
	}
	my $category = shift;
	my(@tmps, $tmp, $item, $all, $per, $result, %DATA);
	my $flag = 0;
	foreach ('Date', 'Error', 'ID', 'Host', 'Ip', 'Agent', 'Referer', 'Proxy') {
		$flag += $FORM{$_};
	}

	# 표시 건수가 지정되었으면
	if ($FORM{'line_no'} !~ /^\d+$/) {
		$FORM{'line_no'} = $axeslog_no;
	}
	open(LOG, "$logfile");
	while ( <LOG> ) {
		last if (!$_);
		chomp(@tmps = (split $separator));
		if (($category eq 'a') || ($category eq 'error')) {
			my($fId, $tId) = split(/=>/, $tmps[5]);
			$idPool{$fId} = 1 if(defined $fId);
			$idPool{$tId} = 1 if(defined $tId);
			my $host = $tmps[2];
			if ($host =~ /^.+\.(.+)\.(ac|ne|go|gr|co|or|ad)\.jp$/i) {
				$host = "*\.$1\.$2\.jp";
			} elsif ($host =~ /^YahooBB(\d+)\.bbtec\.net$/i) {
				$host = "YahooBB***.bbtec.net";
			}
			$hostPool{$host}++ if(defined $host);
			next if(($all > $FORM{'line_no'} - 1) ||
				(($tmps[7] eq '') && ($category eq 'error')) ||
				(($FORM{'host'} ne '') && ($FORM{'host'} ne $host)) ||
				(($FORM{'id'} ne '') && ($FORM{'id'} ne $tmps[5]) && ($FORM{'id'} ne $fId) && ($FORM{'id'} ne $tId)));
			$item .= '<TR>';
			$item .= '<TD><nobr>' . substr($tmps[0], 1, 23) . '</nobr></TD>' if ($FORM{'Date'} || !$flag);
			my $p = ($tmps[6] eq '') ? $tmps[6] : (checkMasterPassword($tmps[6])) ? "<span class='M'>$tmps[6]</span>" :  (checkSpecialPassword($tmps[6])) ? "<span class='S'>$tmps[6]</span>" : "$tmps[6]";
			$tmp = ($tmps[7] eq '') ? $tmps[7] : "<span class='E'>$tmps[7]</span><br>";
			$item .= '<TD align=right><nobr>' . $tmp . $p . '</nobr></TD>' if ($FORM{'Error'} || !$flag);
			$tmp = $tmps[5];
			if($id2name) {
				if($id2name == 2) {
					$fId = (defined $HidToNumber{$fId}) ? islandName($Hislands[$HidToNumber{$fId}]) . "($fId)" : ($fId eq '0') ? '관리자' : $fId;
					$tId = (defined $HidToNumber{$tId}) ? islandName($Hislands[$HidToNumber{$tId}]) . "($tId)" : ($tId eq '0') ? '관리자' : $tId;
				} else {
					$fId = (defined $HidToNumber{$fId}) ? islandName($Hislands[$HidToNumber{$fId}]) : ($fId eq '0') ? '관리자' : $fId;
					$tId = (defined $HidToNumber{$tId}) ? islandName($Hislands[$HidToNumber{$tId}]) : ($tId eq '0') ? '관리자' : $tId;
				}
				$tmp = ($tmp =~ /=>/) ? $fId . '=>' . $tId : $fId;
			}
			$tmp = "<span class='E'>$tmp</span>" if($tmp =~ /=>/);
			$item .= '<TD align=right><nobr>' . $tmp . '</nobr></TD>' if ($FORM{'ID'} || !$flag);
			$item .= '<TD><nobr>' . $tmps[2] . '</nobr></TD>' if ($FORM{'Host'} || !$flag);
			$item .= '<TD><nobr>' . $tmps[3] . '</nobr></TD>' if ($FORM{'Ip'} || !$flag);
			$item .= '<TD><nobr>' . $tmps[4] . '</nobr></TD>' if ($FORM{'Agent'} || !$flag);
			if (!$referer_hide && $FORM{'Referer'}) {
				$tmp = $tmps[1];
 				if($referer_sweep == 1) {
					$tmp =~ s/([^=^\"]|^)(http\:[\w\.\~\-\/\?\&\+\=\:\@\%\;\#]+)/$1<A href=\"$HaxesFile\?$2\" target=\"_blank\">$2<\/A>/g;
				} elsif($referer_sweep == 2) {
					$tmp =~ s/([^=^\"]|^)(http\:[\w\.\~\-\/\?\&\+\=\:\@\%\;\#]+)/$1<A href=\"$2\" onclick=\"link(\'$2\')\; return false\;\" target=\"_blank\">$2<\/A>/g;
				} else {
					$tmp =~ s/([^=^\"]|^)(http\:[\w\.\~\-\/\?\&\+\=\:\@\%\;\#]+)/$1<A href=\"$2\" target=\"_blank\">$2<\/A>/g;
				}
				$item .= '<TD><nobr>' . $tmp . '</nobr></TD>';
			}
			if($proxycheck && $FORM{'Proxy'}) {
				my @env = split(/<>/, $tmps[8]);
				my($proxy_flag, $spill_env) = proxy_check($tmps[2], $tmps[3], @env);
				$tmp = $proxycheck[$proxy_flag];
				$tmp .= '<BR>' . $spill_env if($spill_env ne '');
				$item .= '<TD><nobr>' . $tmp . '</nobr></TD>';
			}
			$item .= '</TR>';
		} else {
			if ($category eq 'date') {
				$tmp = $tmps[0];
				$item = substr($tmp, 1, 14);
			} elsif ($category eq 'hour') {
				$tmp = $tmps[0];
				$item = substr($tmp, 16, 2) . '시';
				$item =~ s/^0/&nbsp;/;
			} elsif ($category eq 'referer') {
				if ($referer_hide) {
					&html('<DIV align=center>리퍼러는 현재 비공개 설정입니다.</DIV>');
				}
				$item = $tmps[1];
	 			if($referer_sweep == 1) {
					$item =~ s/([^=^\"]|^)(http\:[\w\.\~\-\/\?\&\+\=\:\@\%\;\#]+)/$1<A href=\"$HaxesFile\?$2\" target=\"_blank\">$2<\/A>/g;
				} elsif($referer_sweep == 2) {
					$item =~ s/([^=^\"]|^)(http\:[\w\.\~\-\/\?\&\+\=\:\@\%\;\#]+)/$1<A href=\"$2\" onclick=\"link(\'$2\')\; return false\;\" target=\"_blank\">$2<\/A>/g;
				} else {
					$item =~ s/([^=^\"]|^)(http\:[\w\.\~\-\/\?\&\+\=\:\@\%\;\#]+)/$1<A href=$2 target=\"_blank\">$2<\/A>/g;
				}
			} elsif ($category eq 'host') {
				$item = $tmps[2];
				if ($item =~ /^.+\.(.+)\.(ac|ne|go|gr|co|or|ad)\.jp$/i) {
					$item = "*\.$1\.$2\.jp";
				} elsif ($item =~ /^YahooBB(\d+)\.bbtec\.net$/i) {
					$item = "YahooBB***.bbtec.net";
				}
			} elsif ($category eq 'addr') {
				$item = $tmps[3];
			} elsif ($category eq 'agent') {
				$item = $tmps[4];
			} elsif ($category eq 'id') {
				$item = $tmps[5];
				if($id2name) {
					my($fId, $tId) = split(/=>/, $item);
					if($id2name == 2) {
						$fId = (defined $HidToNumber{$fId}) ? islandName($Hislands[$HidToNumber{$fId}]) . "($fId)" : ($fId eq '0') ? '관리자' : $fId;
						$tId = (defined $HidToNumber{$tId}) ? islandName($Hislands[$HidToNumber{$tId}]) . "($tId)" : ($tId eq '0') ? '관리자' : $tId;
					} else {
						$fId = (defined $HidToNumber{$fId}) ? islandName($Hislands[$HidToNumber{$fId}]) : ($fId eq '0') ? '관리자' : $fId;
						$tId = (defined $HidToNumber{$tId}) ? islandName($Hislands[$HidToNumber{$tId}]) : ($tId eq '0') ? '관리자' : $tId;
					}
					$item = ($item =~ /=>/) ? $fId . '=>' . $tId : $fId;
				}
			}
			$DATA{$item}++;
		}
		$all++;
	}
	close(LOG);

	if(($category ne 'a') && ($category ne 'error')){
		$result  = "<DIV align=center>\n<TABLE border=0 cellPadding=2 cellSpacing=5>\n";
		$result .= "<TR><TD align=center>$CATEGORY{$category}</TD><TD align=center>횟수</TD><TD align=center>비율</TD></TR>\n";
	
		foreach (sort { $DATA{$b} <=> $DATA{$a} } keys %DATA) {
			if ($_ eq '') {
				$DATA{'none'} = $DATA{$_};
				$_ = 'none';
			}
			$per = sprintf("%.1f", ($DATA{$_} / $all)*100);
			$result .= "<TR><TD>$_</TD><TD align=center>$DATA{$_}</TD><TD align=center>( $per\% )</TD></TR>\n";
		}

		$result .= "<TR><TD colSpan=3><HR color=#FFFFFF size=1 noShade></TD></TR>\n";
		$result .= "<TR><TD><BR></TD><TD align=center>$all</TD><TD align=center><BR></TD></TR>\n";
		$result .= "</TABLE>\n</DIV>";
	} else {
		$result = "<TABLE border=1 cellpadding=1 cellspacing=0><TBODY>\n";
		$result .= "<TR>";
		$result .= "<TH>Date</TH>" if ($FORM{'Date'} || !$flag);
		$result .= "<TH>Error</TH>" if ($FORM{'Error'} || !$flag);
		$result .= "<TH>ID</TH>" if ($FORM{'ID'} || !$flag);
		$result .= "<TH>Host</TH>" if ($FORM{'Host'} || !$flag);
		$result .= "<TH>Ip</TH>" if ($FORM{'Ip'} || !$flag);
		$result .= "<TH>Agent</TH>" if ($FORM{'Agent'} || !$flag);
		$result .= "<TH>Referer</TH>" if (!$referer_hide && $FORM{'Referer'});
		$result .= "<TH>Proxy</TH>" if ($proxycheck && $FORM{'Proxy'});
		$result .= "</TR>\n";
		$result .= $item;
		$result .= "</TBODY></TABLE>";
	}

	&html($result);
}

# 프록시 확인
sub proxy_check{
	my($host, $addr, @env) = @_;

	my @proxy_env = (
		'HTTP_CONNECTION',
		'HTTP_CACHE_CONTROL', # FORM 전송 시 no_cache가 되는 듯함
		'HTTP_CACHE_INFO',
		'HTTP_CLIENT_IP',
		'HTTP_FORWARDED',
		'HTTP_FROM',
		'HTTP_PROXY_CONNECTION',
		'HTTP_SP_HOST',
		'HTTP_VIA',
		'HTTP_X_FORWARDED_FOR',
		'HTTP_XONNECTION',
		'HTTP_XROXY_CONNECTION',
	);
	my $per = 0;
	my $proxy_flag = 0;
	my $spill_env = '';
	my $pn = @proxy_env;
	foreach (2..$pn){
		$env[$_] ? $per += 1 : $per += 0;
		$spill_env .= " [$proxy_env[$_] -&gt; <span class='P'>$env[$_]<\/span>]" if($env[$_]);
	}

	if($per != 0){
		#환경 변수가 노출되고 있습니다.
		$proxy_flag += 1;
	}
	if($host =~ /^(.*)(cache|server|mail|proxy)(.*)$/i){
		#호스트명에 프록시 징후가 있습니다. 원래 그런 도메인명인 경우는 예외입니다.
		$proxy_flag += 2;
	}
	my $cctld = (split(/\./, $host))[-1];
	if ($host eq $addr){
		#IP 주소에서 호스트명을 찾지 못함
		$proxy_flag += 8;
	} elsif ($cctld ne 'jp' && $cctld ne 'JP'){ 
		#국가 코드 최상위 도메인이 JP가 아니었음
		$proxy_flag += 4;
	}
	if($proxy_flag == 0 and $env[0] eq 'close'){
		$proxy_flag += 11;
	}

	return ($proxy_flag, $spill_env);
}

#=========================
# 비밀번호 관련
#=========================
# 비밀번호 확인
sub passCheck {
	if(checkMasterPassword($FORM{'password'})) {
		return 1;
	} elsif($FORM{'password'} ne '') {
		print <<END;
Content-type: text/html; charset=utf-8

<HTML><HEAD><TITLE>READ ERROR</TITLE>
<link rel="stylesheet" type="text/css" href="${HcssDir}/$HcssDefault">
</HEAD>$Body
END
		tempWrongPassword(); # 비밀번호 불일치
		print "</BODY></HTML>";
		exit(0);
	}
}
#=========================
# HTML 출력.
#=========================
sub html {
	my $result = shift;
	my $i = 0;
	my $option_list;

	foreach (sort keys %CATEGORY) {
		next if(!passCheck() && ($_ eq 'a' || $_ eq 'error' || $_ eq 'addr' || $_ eq 'id'));
		if (($FORM{'category'} eq $_) || (($FORM{'category'} eq '') && ($i == 0))) {
			$option_list .= "<OPTION value=\"$_\" selected>$CATEGORY{$_}\n";
			$i++;
		} else {
			$option_list .= "<OPTION value=\"$_\">$CATEGORY{$_}\n";
		}
	}
	chomp $option_list;

	print "Content-Type: text/html; charset=utf-8\n\n";
	print <<"__HTML__";
<HTML>
<HEAD>
<TITLE>$title</TITLE>
<META http-equiv="Content-Style-Type" content="text/css">
<META http-equiv="Content-Type" content="text/html;charset=utf-8">
<link rel="stylesheet" type="text/css" href="${acss}">
__HTML__

	print "$rs" if(!$referer_hide && ($referer_sweep == 2));

	print <<"__HTML__";
</HEAD>
$Body
$title
<HR size=1 color=#FFFFFF width=100% noShade>
<BR>
<BR>
<FORM name='anlyzer' action="$HaxesFile" method=POST>
<B>마스터 비밀번호：</B><INPUT type=password size=16 maxlength=32 name=password value="$FORM{'password'}" class=f>
<BR>
<INPUT type=hidden name=mode value="analyze">
<INPUT type=hidden name=id value="">
<INPUT type=hidden name=host value="">
<SELECT name=category>
$option_list
</SELECT>
<INPUT type=submit value='집계'>
__HTML__

	if(($FORM{'category'} eq 'a') || ($FORM{'category'} eq 'error')) {
		my %s;
		my $flag = 0;
		foreach ('Date', 'Error', 'ID', 'Host', 'Ip', 'Agent', 'Referer', 'Proxy') {
			$flag += $FORM{$_};
		}
		foreach ('Date', 'Error', 'ID', 'Host', 'Ip', 'Agent', 'Referer', 'Proxy') {
			$s{$_} = " checked" if($FORM{$_} || (!$flag && ($_ ne 'Referer') && ($_ ne 'Proxy')));
		}
	print <<"__HTML__";
<BR>
[접속 로그：표시 선택]
<input type=checkbox name=Date value="1"$s{'Date'}>Date　
<input type=checkbox name=Error value="1"$s{'Error'}>Error　
<input type=checkbox name=ID value="1"$s{'ID'}>ID　
<input type=checkbox name=Host value="1"$s{'Host'}>Host　
<input type=checkbox name=Ip value="1"$s{'Ip'}>Ip　
<input type=checkbox name=Agent value="1"$s{'Agent'}>Agent　
<input type=checkbox name=Referer value="1"$s{'Referer'}>Referer　
<input type=checkbox name=Proxy value="1"$s{'Proxy'}>Proxy
<SELECT name=line_no>
__HTML__
		my $k;
		for ($k = $axeslog_no; $k <= $HaxesMax; $k += 10) {
			if($k != $FORM{'line_no'}) {
				print "<OPTION>$k";
			} else {
				print "<OPTION selected>$k";
			}
		}
		print <<"__HTML__";
</SELECT>
__HTML__
	}

	print <<"__HTML__";
</FORM>
__HTML__
	if($FORM{'category'} eq 'a') {
		foreach (sort { $a <=> $b } keys %idPool) {
			next if($_ eq '');
			my $id;
			if($id2name == 2) {
				$id = (defined $HidToNumber{$_}) ? islandName($Hislands[$HidToNumber{$_}]) . "($_)" : ($_ eq '0') ? '관리자' : $_;
			} else {
				$id = (defined $HidToNumber{$_}) ? islandName($Hislands[$HidToNumber{$_}]) : ($_ eq '0') ? '관리자' : $_;
			}
			print "<span class='n'>[<a href=\"JavaScript:void(0)\" onClick=\"document.anlyzer.id.value='$_';document.anlyzer.submit();return false;\">$id</a>]</span> \n";
		}
		print "<BR><BR>\n";
		foreach (sort { $hostPool{$b} <=> $hostPool{$a} } keys %hostPool) {
			next if($_ eq '');
			print "<span class='n'>[<a href=\"JavaScript:void(0)\" onClick=\"document.anlyzer.host.value='$_';document.anlyzer.submit();return false;\">$_</a>($hostPool{$_})]</span> \n";
		}
	}
	print <<"__HTML__";
<BR>
<BR>
$result
<BR>
$copyright
</BODY>
</HTML>
__HTML__

	exit;
}
