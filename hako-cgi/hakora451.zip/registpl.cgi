#!/usr/bin/perl
#┌─────────────────────────────
#│ ●등록 키 실행 모듈
#│ registpl.cgi - 2006/01/18
#│ Copyright (c) KentWeb
#│ webmaster@kent-web.com
#│ http://www.kent-web.com/
#└─────────────────────────────

# 암호화용 비밀번호(영문/숫자 8자)
$pcp_passwd = 'password';

# 허용 시간(분 단위)
#   글쓰기 폼을 표시한 뒤 실제로 전송 버튼이 눌릴 때까지의
#   허용 시간을 분 단위로 지정
$pcp_time = 30;

#---------------------------------------
#  등록 키
#---------------------------------------
sub pcp_makekey {
	local($str_plain, $str_crypt, @number);

	# 임의의 숫자 4자리 생성
	@number = (0 .. 9);
	srand;
	foreach (1 .. 4) {
		$str_plain .= $number[int(rand(@number))];
	}

	# 시간 추가
	$str_plain .= time;

	# 암호화
	$str_crypt = &pcp_encode($str_plain, $pcp_passwd);
	$str_crypt =~ s/\!/%21/g;

	return ($str_plain, $str_crypt);
}

#---------------------------------------
#  등록 키 확인
#---------------------------------------
sub registkey_chk {
	local($input, $crypt) = @_;
	local($plain, $code, $time);

	# 등록 키 복호화
	$crypt =~ s/\%21/!/g;
	$plain = &pcp_decode($crypt, $pcp_passwd);

	# 키와 시간으로 분리
	$plain =~ /^(\d{4})(\d+)/;
	$code = $1;
	$time = $2;

	# 키 일치
	if ($input eq $code) {
		# 제한 시간 초과
		if (time - $time > $pcp_time*60) {
			return 0;

		# 제한 시간 정상
		} else {
			return 1;
		}
	# 키 불일치
	} else {
		return -1;
	}
}

#---------------------------------------
#  간이 암호
#---------------------------------------
#  유이 님의 암호화 서브루틴을 사용했습니다
#  http://www.cup.com/yui/
sub pcp_decode {
  local($comment,$key,$i,$j,@key);
  $comment = $_[0];
  $key = $_[1];
  @key = split(//,$key);
  $i = 0;
  $j =  &pcp_make_Table($key);
  $comment=~ s/./$pcp_table{$&}/g;
  $comment =~ s/.../sprintf("%c",oct($&)^(ord($key[$i++ % @key]) +($j++ % 383)))/ges;
  $comment=~s/\0$//;
  return $comment;
}
sub pcp_encode {
  local($comment,$key,$i,$j,@key);
  $comment = $_[0];
  $key = $_[1];
  $comment .="\0" if(length($comment) % 2);
  @key = split(//,$key);
  $i = 0;
  $j =  &pcp_make_Table($key);
  $comment =~ s/./sprintf("%03o",ord($&)^(ord($key[$i++ % @key])+($j++ % 383)))/ges;
  $comment=~ s/../$pcp_table{$&}/g;
  return $comment;
}
sub pcp_make_Table{
  local(@list,$i,$j,$k,$init_j,@key,@seed);

  @seed = split(//,'q1aZ.XzS5xACs27wD6eE4d8c0!WvQfRFr9Gt3TgBVbNMnJhyKIujUmYkHiLlOoPp');
  @key = split(//,$_[0]);
  $k=@key;
  $init_j=0;
  for($i=0;$i<64;$i++){
    $j=ord($key[$i % $k]);
    $init_j +=$j;
    $list[$i]=splice(@seed,(($j+$k) % (64-$i)),1);
  }

  $k=0;
  for($i=0;$i<8;$i++){
    for($j=0;$j<8;$j++,$k++){
      $pcp_table{"$i$j"}=$list[$k];
      $pcp_table{$list[$k]}="$i$j";
    }
  }
  return ($init_j % 383);
}



1;

