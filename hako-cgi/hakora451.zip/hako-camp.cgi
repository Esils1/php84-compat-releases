#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}
#----------------------------------------------------------------------
# 하코니와 제도 ver2.20
# 진영 화면작성모듈(제국의 흥망원본)
# 사용 조건과 사용 방법은 hako-readme.txt 파일을 참조해 주세요
#
# 하코니와 제도의 페이지: http://t.pos.to/hako/
#----------------------------------------------------------------------
# '제국의 흥망' ver1.0.0 by 할아버지 http://t.pos.to/ozzy/
# 사용 조건은 하코니와 제도와 동일합니다. 자세한 내용은 동봉된 readme.txt 파일을 참조해 주세요
#----------------------------------------------------------------------

#――――――――――――――――――――――――――――――――――――
#							 제국의 흥망 2nd
#								 v1.0
#
#					 by 친분 webgame@oyoyo.ne.jp
#					http://www.oyoyo.ne.jp/webgame/
#――――――――――――――――――――――――――――――――――――

#――――――――――――――――――――――――――――――――――――
#							제국의 흥망 바다전쟁
#								 v1.2
#
#					 by 친분 webgame@oyoyo.ne.jp
#					http://www.oyoyo.ne.jp/webgame/
#――――――――――――――――――――――――――――――――――――

#----------------------------------------------------------------------
# 진영 화면
#----------------------------------------------------------------------
# 메인
sub campMain {
	# 개방
	unlock ();

	$HcurrentCamp = $Hally[$HidToAllyNumber{$HcurrentCampID}];

	# 비밀번호
	if($HcampPassward ne $HcurrentCamp->{'Takayan'}) {
		# password 오류
		tempWrongPassword();
		return;
	}

	tempPrintCampHead (); # 작전본부
	campAllIslandsInfo(); # 진영에 소속된 섬의 정보
}

#----------------------------------------------------------------------
# 템플릿기타
#----------------------------------------------------------------------

# ○○진영 작전본부
sub tempPrintCampHead {
	out(<<END);
<DIV align='center'>
$HtempBack<BR><BR>
${HtagBig_}${HtagName_}'<FONT COLOR="$HcurrentCamp->{'color'}"><B>$HcurrentCamp->{'mark'}</B></FONT>$HcurrentCamp->{'name'}'${H_tagName} 작전본부${H_tagBig}<BR>
진영 비밀번호:'<B>$HcurrentCamp->{'Takayan'}</B>'<BR><BR>
END

	out(<<END) if($HallyBbs);
<A STYlE="text-decoration:none" HREF="JavaScript:void(0)" onClick="document.allyForm.action='${HbaseDir}/${HallyBbsScript}';document.allyForm.submit();return false;">
${HtagBig_}<small>${HtagName_}<FONT COLOR="$HcurrentCamp->{'color'}"><B>$HcurrentCamp->{'mark'}</B></FONT>$HcurrentCamp->{'name'}${H_tagName}작전회의 실로</A></small>${H_tagBig}
<FORM name="allyForm" action="" method="POST">
<INPUT type=hidden name="ally" value="$HcurrentCampID">
<INPUT type=hidden name="cpass" value="$HcurrentCamp->{'password'}">
<INPUT type=hidden name="jpass" value="$HcampPassward">
<INPUT type=hidden name="id" value="$HcurrentID">
</FORM>
END

	out("</DIV>");
}

# 섬의 명령읽기(진영 화면작성용)
sub readCommands {

	my($id) = @_;
	my(@command);


	open(IIN, "${HdirName}/${id}.${HsubData}");
	foreach $y (0..$islandSize) {
		$line = <IIN>; # 버림하고 있는
	}

	# 명령
	my($i);
	my($cnum) = ($HcampCommandTurnNumber);
	for($i = 0; $i < $cnum; $i++) {
		$line = <IIN>;
		$line =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		$command[$i] = {
			'kind' => int($1),
			'target' => int($2),
			'x' => int($3),
			'y' => int($4),
			'arg' => int($5)
		}
	}

	close(IIN);

	# 명령만반환
	return \@command,
}

# 정보의 표시
sub campAllIslandsInfo {

	# 테이블헤더쓰기
	campTableHeader();

	# 진영에 소속된 섬의 명령만 읽어오기
	my($id);
	foreach $id (@{ $HcurrentCamp->{'memberId'} }) {
		$Hislands[$HidToNumber{$id}]->{'command'} = readCommands($id);
	}

	# 각 섬의 정보쓰기
	my($i);
	foreach $i (0..$islandNumber) {
		if ($HcurrentCampID == $Hislands[$i]->{'allyId'}[0]) {
			campIslandInfo($Hislands[$i], $i+1-$HbfieldNumber); # 진영에 소속된 섬만
		}
	}
	# 테이블푸터쓰기
	campTableFooter();

}

sub campIslandInfo {
	my($island, $rank) = @_;

	# 정보 표시
	my($id) = $island->{'id'};
	my($name) = islandName($island);
	my($farm) = $island->{'farm'};
	my($factory) = $island->{'factory'};
	my($mountain) = $island->{'mountain'};
	my($contribution) = int($island->{'ext'}[1] / 10); # 공헌도
	$farm = ($farm == 0) ? "보유하지 않음" : "${farm}0$HunitPop";
	$factory = ($factory == 0) ? "보유하지 않음" : "${factory}0$HunitPop";
	$mountain = ($mountain == 0) ? "보유하지 않음" : "${mountain}0$HunitPop";

	if($island->{'absent'} == 0) {
		$name = "${HtagName_}$name${H_tagName}";
	} else {
		$name = "${HtagName2_}$name($island->{'absent'})${H_tagName2}";
	}
	my($ofname) = $island->{'fleet'};

	out(<<END);
<TR>
<TD $HbgNumberCell ROWSPAN=2 align=center>${HtagNumber_}$rank${H_tagNumber}</TD>
<TD $HbgNameCell ROWSPAN=2 align=left>

<A STYlE=\"text-decoration:none\" HREF="${HthisFile}?Sight=${id}">
$name
</A>
</TD>
<TD $HbgInfoCell align=right>$island->{'pop'}$HunitPop</TD>
<TD $HbgInfoCell align=right>$contribution</TD>
<TD $HbgInfoCell align=right>$island->{'money'}$HunitMoney</TD>
<TD $HbgInfoCell align=right>$island->{'food'}$HunitFood</TD>
<TD $HbgInfoCell align=right>$island->{'area'}$HunitArea</TD>
<TD $HbgInfoCell align=right>${farm}</TD>
<TD $HbgInfoCell align=right>${factory}</TD>
<TD $HbgInfoCell align=right>${mountain}</TD>
</TR>
END

	out("<TR><TD $HbgCommentCell COLSPAN=8 valign=top>${HtagTH_}\n");
	my($cnum) = ($HcampCommandTurnNumber);
	for($i = 0; $i < $cnum; $i++) {
		tempCommand($i, $island->{'command'}->[$i], $island->{'shr'}, 0);
	}
}

sub campTableHeader {
	out(<<END);

<DIV align='center'>
<TABLE BORDER>
<TR>
<TH $HbgTitleCell>${HtagTH_}순위${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}${AfterName}${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}인구${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}공헌헌납${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_} 자금${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}식량${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}면적${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}농장규모${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}공장규모${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}채굴장규모${H_tagTH}</TH>
</TR>
END
}

sub campTableFooter {
	out(<<END);

</TABLE>
</DIV>
END
}

1;
