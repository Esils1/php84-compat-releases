#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}
#----------------------------------------------------------------------
# 하코니와 제도 Hakoniwa R.A. JS ver4.xx
# 서버 설정모듈(ver1.00)
# 사용 조건과 사용 방법은 hako-readme.txt 파일을 참조해 주세요
#
# 우라에와 -uRAniwa-: http://snow.prohosting.com/awinokah/
#----------------------------------------------------------------------

#----------------------------------------
# 서버
#----------------------------------------
# 이 파일을 설치할 디렉터리(끝에 슬래시(/)는 붙이지 않습니다.)
my $HbaseScheme = (($ENV{'HTTPS'} || '') =~ /^(on|1)$/i) ? 'https' : 'http';
my $HbaseHost = $ENV{'HTTP_HOST'} || $ENV{'SERVER_NAME'} || 'localhost';
if (!$ENV{'HTTP_HOST'} && $ENV{'SERVER_PORT'} && !(($HbaseScheme eq 'http' && $ENV{'SERVER_PORT'} == 80) || ($HbaseScheme eq 'https' && $ENV{'SERVER_PORT'} == 443))) {
 $HbaseHost.= ":$ENV{'SERVER_PORT'}";
}
my $HbaseScriptDir = $ENV{'SCRIPT_NAME'} || '';
$HbaseScriptDir =~ s{/[^/]*$}{};
$HbaseDir = "$HbaseScheme://$HbaseHost$HbaseScriptDir";


# 이미지 파일을 둘 디렉터리(끝에 슬래시(/)는 붙이지 않습니다.)
#$HimageDir = "${HbaseDir}/hakorenas";
$HimageDir = "https://esils.com/BBdata/hakorenas";

# 외부 파일(css,js)을 배치할 디렉터리
$efileDir = "${HbaseDir}";
# $HbaseDir에서 $efileDir로 가는 상대 경로입니다. 로컬 설정을 사용하는 경우 이대로 두면 됩니다.
$HefileDir = '.';
# CSS 파일의 이름
$HcssFile = 'style.css';

# 하코니와 스킨의 설정 링크를 톱 페이지에 표시할지
$HcssSetting = 0;
# 설정용 CSS 폴더
$HcssDir = 'css'; # 폴더 이름만(데이터폴더와 같은 방식으로 처리됩니다)
# 주!'외부 파일(css,js)을 배치할 디렉터리'의안에만들어있고하세요.

# 비밀번호 파일 이름
# 마스터 비밀번호와 특수 비밀번호는 암호화되어 비밀번호 파일에 저장되어 있습니다.
$HpasswordFile = 'passwd.cgi';

# GMT 에 대한 JST 의 때차(서버의 시각이광기하고 있을 때만조정해 주세요)
$Hjst = 32400; # 9 시간

# 관리자 이름
$HadminName = '관리자의 이름';

# 관리자의 메일 주소
$Hemail = 'admin@example.com';

# 게시판 주소
#$Hbbs = 'http://서버/게시판.cgi';
# 일반 게시판도 YY-BOARD 을이용하는 경우
$Hbbs = "${HbaseDir}/hako-yy-bbs.cgi";

# 홈페이지 주소
$Htoppage = "${HbaseDir}/";

## 이미지 경로 설정의 설명페이지
$imageExp = "${HbaseDir}/e.html";
# 로컬 이미지 압축 파일(다운로드받음)
$localImg = "${HbaseDir}/navyimg.lzh";

# '상세 변경점'의페이지
$helpHenko = "${HbaseDir}/henko_new.html";

#----------------------------------------
# 데이터
#----------------------------------------
# 디렉터리 권한
# 일반적으로 0755이면 좋지만,0777,0705,0704등에서 없으면 사용 불가는 서버도 있습니다
$HdirMode = 0755;

# 데이터 디렉터리 이름
# 여기에서 설정한 이름의 디렉터리 아래에 데이터가 저장됩니다.
# 기본값에서는'data'로 되어 있지만, 보안상
# 보안을 위해 다른 이름으로 변경해 주세요.
$HdirName = 'data';

# 메인 데이터의 이름
$HmainData = 'hakojima.dat';

# 섬 데이터의 이름(앞에 '섬 ID'가 붙습니다)
$HsubData = 'island.cgi';
#!주의: ver4.48 이전에서 이행하기 위해 아래에 기존 '섬 데이터 이름'을 입력해 주세요.
$HsubDataold = 'island';

# 데이터 쓰기 권한

# 잠금 방식
# 1 디렉터리<mkdir>
# 2 시스템 콜(가능하면 이 방식을 권장합니다)<flock>
# 3 심볼릭 링크<symlink>
# 4 일반 파일(권장하지 않음)<unlink>
# 5 이름 변경<rename>
$lockMode = 5;

# (주)
# 4,5을 선택하는 경우에는,'lockfile'라는, 권한 666의 빈 파일을,
# 이 파일과 같은 위치에 배치해 주세요.

# 이하의3항목의 설정에 대해

# 신규게임라면 1이권장입니다.
# 원본(010713판)에서 이관하는 경우,
# 소유자 데이터와 미사일 발사 가능 횟수 데이터를0에시, 괴수출현 데이터는 원본의 설정에아맞춰해 주세요.
# 또한, 버전 업그레이드의 때의 설정은, 이전의 것와 같은 설정으로 맞춰 주세요.

# 소유자 데이터를 어디에 저장할지(0: howner.dat 1: $HmainData)
$HnewGameO = 1;

# 괴수출현 데이터를 어디에 저장하기카 (0: monslive.dat 1: $HmainData)
$HnewGame = 1;

# 미사일 발사 가능 횟수 데이터를 어디에 저장하기카 (0: missiles.dat 1: $HmainData)
$HnewGameM = 1;

1;
