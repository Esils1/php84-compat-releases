#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}
#----------------------------------------------------------------------
# 하코니와 제도 ver2.30
# 톱 페이지 모듈(ver1.00)
# 사용 조건과 사용 방법은 hako-readme.txt 파일을 참조해 주세요
#
# 하코니와 제도의 페이지: http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html
#----------------------------------------------------------------------
#----------------------------------------------------------------------
# Hakoniwa R.A. ver2.11
# 메인 스크립트(하코니와 제도 ver2.30)
# 사용 조건, 사용 방법은 read-renas.txt 파일을 참조
#
# KEI PAGE: http://www5b.biglobe.ne.jp/~k-e-i/
#----------------------------------------------------------------------


#----------------------------------------------------------------------
# 톱 페이지 모드
#----------------------------------------------------------------------
# 메인
sub topPageMain {
	# 접속·로그
	axeslog(0) if($HtopAxes> 2);
	# 개방
	unlock();

	# 템플릿출력
	tempTopPage();
}

# 톱 페이지
sub tempTopPage {
	out("<DIV ID='LinkTop'>");
	if( $HsurvivalTurn && ($HislandTurn> $HsurvivalTurn) ) {
		out(qq|<B>참고: </B>서바이벌 모드 때문에, 새 ${AfterName}은 탐색세않습니다.<BR>|);
	} elsif(!$HadminJoinOnly) {
		out(qq|[<A href="$HthisFile?Join=0">새 ${AfterName}을 탐색</A>] |);
	} else {
		out(qq|<B>참고: </B>새 ${AfterName}을 찾은 분은'<B>${AfterName}이름, 당신의 이름, 비밀번호</B>'을 관리자에게 메일해 주세요.<BR>|);
	}
	out(<<END);
[<A href="$HthisFile?Rename=0">${AfterName}이름과 비밀번호 변경</A>]
[<A href="$HthisFile?Limg=0">이미지 경로 설정</A>]
END
	if($HcssSetting) {
		out(qq|[<A href="$HthisFile?Skin=0">하코니와 스킨의 설정</A>] |);
	}
	out(qq|[<A href="$HthisFile?JoinA=0">동맹 설정</A>] |) if(($HallyUse == 1) && !$HarmisticeTurn);
	if(!$HhtmlLogMode || !(-e "${HhtmlDir}/hakolog.html") || $Hgzip) {
		out(qq|[<A href="${HbaseDir}/history.cgi?Event=0">최근 사건</A>] |);
	} else {
		out(qq|[<A href="${htmlDir}/hakolog.html">최근 사건</A>] |);
	}

	out(<<END);
[<A href="$HthisFile?Rekidai=0">역대 최다인구기록</A>]
[<A href="$HthisFile?Rank=0">순위</A>]
<hr>
</DIV>

<SCRIPT Language="JavaScript">
<!--
function newdevelope(){
//	newWindow = window.open("", "newWindow");
	document.Island.target = "newWindow";
	document.Island.submit();
}
// -->
</SCRIPT>
END

	# 제목
		out(<<END);
${HtagTitle_}$Htitle${H_tagTitle}
<br>
END

	# 디버그 모드이면 '턴 진행' 버튼
	if($Hdebug) {
		out(<<END);
<FORM action="$HthisFile" method="POST">
<INPUT TYPE="submit" VALUE="턴을 진행하기" NAME="TurnButton">
</FORM>
END
	}

	# 종료 턴 수와 종료일 때를 표시
	my($HlastTurnS, $HlimitTime);
	if(!$HgameLimitTurn) {
		$HlastTurnS = "";
	} elsif(($HislandTurn < $HgameLimitTurn)) {
		my $remainTime = 0;
		if($HflexTimeSet) {
			my $all = 0;
			foreach (@HflexTime) {
				$all += $_;
			}
			my $ts, $tsn, $te, $ten, $i;
			$ts = int($HislandTurn / @HflexTime);
			$tsn = $HislandTurn % @HflexTime;
			$te = int($HgameLimitTurn / @HflexTime);
			$ten = $HgameLimitTurn % @HflexTime;
			$remainTime += $all * ($te - $ts - 1);
			if($tsn) {
				foreach($tsn..$#HflexTime) {
					$remainTime += $HflexTime[$_];
				}
			} else {
				$remainTime += $all;
			}
			if($ten) {
				foreach(0..($ten - 1)) {
					$remainTime += $HflexTime[$_];
				}
			}
#			for($i=$HislandTurn; $i < $HgameLimitTurn; $i++) {
#				$remainTime += $HflexTime[($HislandTurn % ($#HflexTime + 1))];
#			}
			$remainTime *= 3600;
		} else {
			$remainTime = $HunitTime * ($HgameLimitTurn - $HislandTurn);
		}
		$HlimitTime = $HislandLastTime + $remainTime;
		$HlimitTime = sprintf('%d년 %d월 %d일 %d 때', (gmtime($HlimitTime + $Hjst))[5] + 1900, (gmtime($HlimitTime + $Hjst))[4] + 1, (gmtime($HlimitTime + $Hjst))[3,2]);
		$HlastTurnS = "<small>/${HgameLimitTurn}<small>《${HlimitTime}까지》</small></small>";
	} else {
		$HlastTurnS = " (게임은 종료했습니다)";
	}
	if( $HsurvivalTurn && ($HislandNumber == 1) && ($HislandTurn> $HsurvivalTurn) ) {
		$HlastTurnS = " (게임은 종료했습니다)";
	}
	# 현재의 턴을 표시
	my $mode = '';
	$mode = ($HislandTurn < $HarmisticeTurn) ? "(~$HarmisticeTurn <small>휴전 기간</small>)" : ($HislandTurn == $HarmisticeTurn) ? '(<small>다음 턴보다전투 기간</small>)' : '(<small>전투 기간</small>)' if($HarmisticeTurn);
	out("<DIV ID='Turn'>");
	if(!$Hseason) {
		out(qq|<H1><small>턴</small> ${HislandTurn}<SMALL>${mode}${HlastTurnS}</SMALL></H1>|);
	} else {
		# 턴 갱신 때의 표시가깨지지 않도록 하기 위해
		$Hmonth = ($HislandTurn % 12) + 1;
		$Hyear = ($HislandTurn / 12) + 1;
		# 계절의 표시
		my @seasonName = ('<span class=winter>겨울</span>','<span class=spring>봄</span>','<span class=summer>여름</span>','<span class=autumn>가을</span>');
		my $calender = sprintf('<small>%s</small> %d년 %d월 ', $Halmanac, $Hyear, $Hmonth);
		$calender.= "<span class='season'>$seasonName[int(($Hmonth - 1) / 3)]</span>";
		out(qq|<H1>$calender</H1><B><small>턴</small> ${HislandTurn}${mode}${HlastTurnS}</B>|);
	}
	out("</DIV>");

	my($mStr1) = '';
	if($HhideMoneyMode) {
		$mStr1 = "<TH $HbgTitleCell align=center>${HtagTH_} 자금${H_tagTH}</TH>";
	}

	my($msStr1) = '';
	if($HhideMissileMode) {
		$msStr1 = "<TH $HbgTitleCell align=center>${HtagTH_}미사일 수";
		if($HuseArmSupply) {
			$msStr1.= "(군사 물자)${H_tagTH}</TH>";
		} else {
			$msStr1.= "${H_tagTH}</TH>";
		}
	}

	if ($HjavaModeSet eq 'java') {
		$radio = ""; $radio2 = "CHECKED";
	}else{
		$radio = "CHECKED";	$radio2 = "";
	}

	# 다음 갱신 시간 표시
	if($HflexTimeSet) {
		$aaa = $HislandLastTime + 3600 * $HflexTime[($HislandTurn % ($#HflexTime + 1))];
	} else {
		$aaa = $HislandLastTime + $HunitTime;
	}

	my($sec, $min, $hour, $date, $mon, $year, $day, $yday, $dummy) = gmtime(time + $Hjst);
	$mon++;
	my($sss) = "${mon}월 ${date}일 ${hour} 때 ${min}분 ${sec}초";
	my($sec2, $min2, $hour2, $date2, $mon2, $year2, $day2, $yday2, $dummy2) = gmtime($aaa + $Hjst);
	$mon2++;
	my($bbb) = '';
	if(($HgameLimitTurn == 0) || ($HislandTurn < $HgameLimitTurn)) {
		$bbb = "${mon2}월 ${date2}일 ${hour2} 때 ${min2}분";
	} else {
		$bbb = "갱신이 중지되어 있습니다";
	}

	# 다음 턴까지의 시간 표시
	if (!($HmainMode eq 'turn')&&(defined $HleftTime)) {
		$hour2 = int($HleftTime/3600);
		$min2 = int(($HleftTime-$hour2*3600)/60);
		$sec2 = ($HleftTime-$hour2*3600-$min2*60);
		$rtStr = "다음갱신 시간까지남은 $hour2 시간 $min2분 $sec2초";
	} else {
		if ($HplayNow) {
			$rtStr = "턴을 갱신했습니다\n";
		} else {
			$rtStr = "";
		}
	}

# 실시간
	if($Hrealtimer){
		out(<<END) if (defined $HleftTime);
<FORM name=TIME style="margin : 2px 0px;">
<INPUT type=text name=TIME size=50 readonly class=timer></FORM>
<SCRIPT language="JavaScript">
<!--
var leftTime = $HleftTime;
var hour, min, sec;

function showTimeLeft() {
	if (leftTime> 0) {
		setTimeout('showTimeLeft()', 1000);

		hour = Math.floor(leftTime / 3600);
		min = Math.floor(leftTime % 3600 / 60);
		sec = leftTime % 60;
		leftTime--;

		document.TIME.TIME.value = '다음갱신 시간까지남은 ' + hour + '시간 ' + min + '분 ' + sec + '초';
	} else {
		document.TIME.TIME.value = '턴 갱신 시각이 되었습니다! ($HnextTime)';
	}
}

if ($HplayNow) {
	showTimeLeft();
} else {
	document.TIME.TIME.value = '';
}
//-->
</SCRIPT>
END
} else {
	out(<<END);
<DIV class=timer>$rtStr</DIV>
END
}
	# 양식
	out(<<END);
<DIV ID=nexttime>현재의 시간:<b>$sss</b> (다음 갱신 시간:$bbb)</DIV><br>
END

	# 서바이벌 모드 표시
	if($HsurvivalTurn) {
		my $tflag = int(($HislandTurn - $HsurvivalTurn)/$HturnDead);
		$tflag = 0 if($tflag < 0);
		my $turnDead = $HsurvivalTurn + $HturnDead * ($tflag + 1);
		my $sur = '<span class="attention">참고: ';
		if($HislandTurn < $HsurvivalTurn) {
			$sur.= "$HsurvivalTurn 턴이후,$HturnDead 턴마다최하위의 섬이침몰합니다. 처음의 침몰판정은$turnDead 턴입니다.</span><br>"
		} else {

			$sur.= "$HturnDead 턴마다최하위의 섬이침몰합니다. 다음 회의 침몰판정은$turnDead 턴입니다.</span><br>"
		}
		out("$sur");
	}

	out(<<END);
<HR>
<TABLE BORDER=0 width="100%">
<TR valign="top">
<TD width="50%" class="M">
<DIV ID='myIsland'>
<H1>자신의 ${AfterName}으로</H1>
<FORM name="Island" action="$HthisFile" method="POST">
당신의${AfterName}이름은?<BR>
<SELECT NAME="ISLANDID">
$HislandList
</SELECT><BR><BR>
비밀번호를 이용하세요!!<BR>
<INPUT TYPE="hidden" NAME="OwnerButton">
<INPUT TYPE="password" NAME="PASSWORD" VALUE="$HdefaultPassword" SIZE=32 MAXLENGTH=32><BR>
<INPUT TYPE="radio" NAME=JAVAMODE VALUE=cgi $radio>일반 모드
<INPUT TYPE="radio" NAME=JAVAMODE VALUE=java $radio2>JavaScript 모드<BR>
<INPUT TYPE="submit" VALUE="개발 화면으로">
<INPUT TYPE="button" VALUE="새 화면" onClick="newdevelope()">
</FORM>
</DIV>
</TD>
<TD width="50%" class="M">
<DIV ID='HistoryLog'>
<H1>발견 기록</H1>
<DIV style="overflow:auto; height:${HdivHeight}px;">
END

	historyPrint();

	out(<<END);
</DIV></DIV>
</TD></TABLE>
END

	islandSort('pts');
	if($HallyNumber){
		allyInfo(-1);
		my $aStr = ($HarmisticeTurn) ? '진영' : '동맹';
		out(" <B>참고: </B>${aStr}이름을 클릭하면'${aStr}의 정보'란으로");
		out(",${HallyTopName} 섬 이름이라면 '코멘트 변경'란으로") if(!$HarmisticeTurn);
		out("이동합니다.");
	}

	out(<<END);
<A name="View"></A>
<DIV ID='islandView'>
<HR>
<H1>여러${AfterName}의상황</H1>
<P>
${AfterName}이름을 클릭하면,<B>관광</B>할 수 있습니다.
</P>
END

	my($island, $j, $farm, $factory, $mountain, $unemployed, $renae, $pts, $eisei1, $eisei2, $eisei2nd, $monsterlive,
		$monsm, $hcturn, $rieki, $zouka, $seicho, $name, $id, $prize, $ii, $jj, $k, $num);
	$jj = int(($islandNumber + $HviewIslandCount - $HbfieldNumber) / $HviewIslandCount);
	if ($jj> 1) {
		for($ii = 0; $ii < $jj; $ii++) {
			$j = $ii * $HviewIslandCount;
			$k = min($j + $HviewIslandCount, $HislandNumber - $HbfieldNumber);
			$j++;
			$j = "★" if(!$ii && $HbfieldNumber);

			out(qq|<A href="$HthisFile?View=$ii#View">${HtagNumber_}[$j~$k]${H_tagNumber}</A>&nbsp;|);
		}
	}

	out("<TABLE BORDER>");

	my($head);
	$head = <<"END";
<TR>
<TH $HbgTitleCell align=center>${HtagTH_}순위${H_tagTH}</TH>
<TH $HbgTitleCell align=center>${HtagTH_}${AfterName}${H_tagTH}</TH>
<TH $HbgTitleCell align=center>${HtagTH_}인구${H_tagTH}</TH>
<TH $HbgTitleCell align=center>${HtagTH_}면적${H_tagTH}</TH>
$mStr1
<TH $HbgTitleCell align=center>${HtagTH_}식량${H_tagTH}</TH>
<TH $HbgTitleCell align=center>${HtagTH_}농장${H_tagTH}</TH>
<TH $HbgTitleCell align=center>${HtagTH_}직장${H_tagTH}</TH>
<TH $HbgTitleCell align=center>${HtagTH_}채굴장${H_tagTH}</TH>
<TH $HbgTitleCell align=center>${HtagTH_}군사 기술${H_tagTH}</TH>
$msStr1
</TR>
END

	my($col) = 3 + ($HhideMoneyMode != 0) + ($HhideMissileMode != 0);
	my($col1) = 4 + $col;
	my($col2) = 7 + $col;

	$HviewIslandNumber *= $HviewIslandCount;
	my($start, $end) = ($HviewIslandNumber + $HbfieldNumber, min($HviewIslandNumber + $HviewIslandCount + $HbfieldNumber, $HislandNumber));
	$start = 0 if(!$HviewIslandNumber);

	for($ii = $start; $ii < $end; $ii++) {
		$j = $ii + 1 - $HbfieldNumber;
		$island = $Hislands[$ii];
		out("<TR><TH></TH></TR><TR><TH></TH></TR>$head") if(($HbfieldNumber && $j == 1) || ($ii == $start));

		$id			= $island->{'id'};
		$farm		= $island->{'farm'};
		$factory	= $island->{'factory'};
		$mountain	= $island->{'mountain'};
		$unemployed	= ($island->{'pop'} - ($farm + $factory + $mountain) * 10) / $island->{'pop'} * 100 if($island->{'pop'});
		$unemployed	= '<span class="'. ($unemployed < 0 ? 'unemploy1' : 'unemploy2'). '">'. sprintf("%.2f%%", $unemployed). '</span>' if($island->{'pop'});
		$farm		= ($farm == 0) ? "보유하지 않음" : "${farm}0$HunitPop";
		$factory	= ($factory == 0) ? "보유하지 않음" : "${factory}0$HunitPop";
		$mountain	= ($mountain == 0) ? "보유하지 않음" : "${mountain}0$HunitPop";
		$renae		= int($island->{'rena'} / 10 ) + 1;
		$pts		= $island->{'pts'};
		$eisei1		= $island->{'eisei1'};
		$eisei2		= $island->{'eisei2'};
		$eisei2nd	= int($eisei2 / 100 );
		$monsterlive = $island->{'monsterlive'};
		$monsm		= ($monsterlive == 0) ? "" : "${monsterlive}$HunitMonster 출현안!!</span>";
		$rieki		= ($island->{'pika'} < 0) ? "$island->{'pika'}$HunitMoney" : "+$island->{'pika'}$HunitMoney";
		$zouka		= ($island->{'hamu'} < 0) ? "$island->{'hamu'}$HunitPop" : "+$island->{'hamu'}$HunitPop";
		$seicho		= ($island->{'monta'} < 0) ? "$island->{'monta'}pts." : "+$island->{'monta'}pts.";
		$eisei2		= ($eisei2nd == 0) ? "통산 관광객 수1만 명미만<br>" : "통산 관광객 수${eisei2nd}만 명<br>";

		$hcturn = int($HislandTurn/100)*100;
		my $name = islandName($island);
		if($island->{'id'}> 100) {
			$j = "★";
			$name = "${HtagNumber_}$name${H_tagNumber}";
		} elsif($island->{'absent'} == 0) {
			$name = "${HtagName_}$name${H_tagName}";
		} else {
			$name = "${HtagName2_}$name($island->{'absent'})${H_tagName2}";
		}
		$name = "<span class='attention'>[관리자 보관]</span><BR>". $name if($island->{'predelete'});
		my @uniName = ('[천사미카엘]', '[수도]', '[파괴된 침략자]', '[왕충의 탈피 껍질]', '[암석]', '[지석]', '[빙석]', '[풍석]', '[염석]', '[광석]', '[고대 유적]', '[행복의 여신상]');
		my @uniData = split(/,/, $island->{'eisei6'});
		my $unilist = '';
		$island->{'uni'} = 0;
		$island->{'tuni'} = 0;
		foreach (0..$#uniName) {
			$unilist.= " $uniName[$_]\n" if($uniData[$_]> 0);
			$island->{'tuni'} += $uniData[$_];
			$island->{'uni'}++ if($uniData[$_]> 0);
		}
		my $unique;
		my $rt = "\n";
		if ($island->{'uni'}) {
			$unique = "<span class='shuto'><IMG SRC=\"prize10.gif\" TITLE=\"얻기 어려운 유니크 지형:$rt${unilist}/전체12종류\" ";
			$unilist =~ s/$rt//g;
			$unique.= "onMouseOver='status=\"얻기 어려운 유니크 지형:${unilist}/전체12종류\"; return true;' onMouseOut=\"status = '';\" WIDTH=16 HEIGHT=\"16\"> $island->{'tuni'}케장소 </span>";
		} else {
			$unique = "";
		}

		my($sto, $std, $stk, $stwin, $stdrow, $stlose, $stwint, $stdrowt, $stloset, $styusho, $stshoka) = split(/,/, $island->{'eisei4'});
		$island->{'kachiten'} = $stwin*3 + $stdrow;
		$island->{'kachitent'} = $stwint*3 + $stdrowt;
		my $siaisu = $stwint + $stdrowt + $stloset;
		$siaisu = 1 if($siaisu == 0);
		$island->{'shoritu'} = int($stwint / $siaisu * 100);
		$island->{'teamforce'} = $sto + $std + $stk;
		$island->{'styusho'} = $styusho;
		my $nn = ('연습안', '예선 제1전투 대기치', '예선 제2전투 대기치', '예선 제3전투 대기치', '예선 제4전투 대기치', '예선종료대기치',	'준준결승전대기치', '준결승전대기치', '결승전대기치',
				'우승!', '연습안', '예선 탈락', '준준결승', '준결승', '제2위')[$stshoka];
	 $nn = '연습안' if($nn eq '');
		if ($stshoka>= 1) {
			$ssss = "<IMG SRC=\"sc.gif\" TITLE=\"$nn 공격($sto) 수비($std)KP($stk)$rt 팀성적 승점$island->{'kachiten'}/ $stwin 승$stlose 패$stdrow 분$rt / 통산$stwint 승$stloset 패$stdrowt 분 / 우승$styusho 회\" onMouseOver='status=\"$nn 공격($sto) 수비($std)KP($stk) 팀성적 승점$island->{'kachiten'} / $stwin 승$stlose 패$stdrow 분 / 통산$stwint 승$stloset 패$stdrowt 분 / 우승$styusho 회\"; return true;' onMouseOut=\"status = '';\" WIDTH=16 HEIGHT=\"16\"> "
		} elsif ($stshoka == 0)	{
			$ssss = ""
		};

		my($mshp, $msap, $msdp, $mssp, $mswin, $msexe, $tet) = split(/,/, $island->{'eisei5'});
		my $mspet;
		my $force = $mshp+$msap+$msdp+$mssp;
		$island->{'force'} = $force;
		$mspet = "<IMG SRC=\"ms.gif\" TITLE=\"관광 이노라(HP$mshp.AP$msap.DP$msdp.SP$mssp/$mswin 마리 격파/경험치$msexe)\" onMouseOver='status=\"관광 이노라(HP$mshp.AP$msap.DP$msdp.SP$mssp/$mswin 마리 격파/경험치$msexe)\"; return true;' onMouseOut=\"status = '';\" WIDTH=16 HEIGHT=\"16\">Sum($force)" if($mshp);
		$mspet = "<IMG SRC=\"tet.gif\" TITLE=\"초신 수테트라(HP$mshp.AP$msap.DP$msdp.SP$mssp/$mswin 마리 격파/경험치$msexe)\" onMouseOver='status=\"초신 수테트라(HP$mshp.AP$msap.DP$msdp.SP$mssp/$mswin 마리 격파/경험치$msexe)\"; return true;' onMouseOut=\"status = '';\" WIDTH=16 HEIGHT=\"16\">Sum($force)" if($tet);
		$mspet = "" if(!$mshp && !$tet);

		my @elements = ( 'pop', 'farm', 'factory', 'mountain', 'fore', 'tare', 'zipro', 'leje', 'monsterlive', 'taiji', 'monta', 'hamu', 'pika', 'kei', 'rena', 'force', 'eisei2', 'uni', 'teamforce', 'styusho', 'shoritu', 'kachitent', 'kachiten');
		my @bumonName = ('인구', '농장', '직장', '채굴장', '숲', '닭 수', '돼지 수', '소 수', '괴수출현 수', '괴수퇴치 수', '성장도', '인구증가', '수입', '기념비 수', '군사 기술', '생물 대학 능력', '통산 관광객', '유니크 지형 수', '축구팀력', 'HC 우승횟수', 'HC 통산승률', 'HC 통산승점', 'HC 승점');
		my $bumonCount = 0;
		my $bName = '';
		foreach (0..$#HrankingID) {
			my $rID = $HrankingID[$_];
			my $element = $island->{$elements[$_]};
			if(($island->{'id'} == $rID) && ($element ne '') && ($element != 0)) {
				$bumonCount++;
				$bName.= ' ['. $bumonName[$_]. "]\n";
			}
		}
		my $bumons;
		if ($bumonCount) {
			$bumons = "<IMG SRC=\"prize11.gif\" TITLE=\"부문상:$rt$bName\" ";
			$bName =~ s/$rt//g;
			$bumons.= "onMouseOver='status=\"부문상:$bName\"; return true;' onMouseOut=\"status = '';\" WIDTH=16 HEIGHT=\"16\"> $bumonCount 관 ";
		} else {
			$bumons = "";
		}

		my($prize1, $prize2) = split(/\t/, $island->{'prize'});
		$prize1 =~ /([0-9]*),([0-9]*),(.*)/;
		my($flags, $monsters, $turns) = ($1, $2, $3);
		$prize = '';

		# 남은 턴 표시
		my $alt = '';
		my @turnPrize = reverse(split(/,/, $turns));
		my $i = 0;
		foreach (@turnPrize) {
			last if($i> 3);
			$alt.= "\n" if($i++);
			$alt.= "$_${Hprize[0]}";
		}
		my $tNum = @turnPrize;
		$alt.= ($i < $tNum ? "\n타,${tNum}회 수상" : "\n이상${tNum}회 수상") if($tNum);
		my $alt1 = $alt;
		$alt1 =~ s/$rt/ /g;
		$prize.= "<IMG SRC=\"prize0.gif\" TITLE=\"$alt\" onMouseOver='status=\"$alt1\"; return true;' onMouseOut=\"status = '';\" WIDTH=16 HEIGHT=16> " if ($alt ne '');

		# 이름에 순위 표시 문자를 추가
		my($f) = 1;
		for($i = 1; $i < 10; $i++) {
			if($flags & $f) {
				$prize.= "<IMG SRC=\"prize${i}.gif\" TITLE=\"${Hprize[$i]}\" ";
				$prize.= "onMouseOver='status=\"${Hprize[$i]}\"; return true;' onMouseOut=\"status = '';\" WIDTH=16 HEIGHT=16> ";
			}
			$f *= 2;
		}

		# 쓰러뜨린 괴수 목록
		$f = 1;
		my($max) = -1;
		my $mNameList = '';
		my $hflag = 0;
		for($i = 0; $i < $HmonsterNumber; $i++) {
			if($monsters & $f) {
				$mNameList.= "[$HmonsterName[$i]]\n";
				$max = $i;
			}
			$f *= 2;
		}
		$f = 1;
		for($i = 0; $i < $HhugeMonsterNumber; $i++) {
			if($prize2 & $f) {
				$mNameList.= "[$HhugeMonsterName[$i]]\n";
				$max = $i;
				$hflag = 1;
			}
			$f *= 2;
		}
		if($max != -1) {
			my $image = ($hflag ? $HhugeMonsterImageS[$max] : $HmonsterImage[$max]);
			$prize.= "<span class='monsm'><IMG SRC=\"${image}\" TITLE=\"$mNameList\" ";
			$mNameList =~ s/$rt/ /g;
			$prize.= "onMouseOver='status=\"$mNameList\"; return true;' onMouseOut=\"status = '';\" WIDTH=16 HEIGHT=16>$island->{'taiji'}$HunitMonster 퇴치</span>";
		}

		# 출현 중인괴수 목록
		$f = 1;
		$hflag = 0;
		$max = -1;
		$mNameList = '';
		my($monslivetype) = $island->{'monsterlivetype'};
		my($hmonslivetype) = $island->{'hmonsterlivetype'};
		my($monsliveimg);
		for($i = 0; $i < $HmonsterNumber; $i++) {
			if($monslivetype & $f) {
				$mNameList.= "[$HmonsterName[$i]]\n";
				$max = $i;
			}
			$f *= 2;
		}
		$f = 1;
		for($i = 0; $i < $HhugeMonsterNumber; $i++) {
			if($hmonslivetype & $f) {
				$mNameList.= "[$HhugeMonsterName[$i]]\n";
				$max = $i;
				$hflag = 1;
			}
			$f *= 2;
		}
		if($max != -1) {
			my $image = ($hflag ? $HhugeMonsterImageS[$max] : $HmonsterImage[$max]);
			$monsliveimg = "<span class='unemploy2'><IMG SRC=\"${image}\" TITLE=\"$mNameList\" ";
			$mNameList =~ s/$rt//g;
			$monsliveimg.= "onMouseOver='status=\"$mNameList\"; return true;' onMouseOut=\"status = '';\" WIDTH=16 HEIGHT=16> ";
		}

		my($mStr1) = '';
		if($HhideMoneyMode == 1) {
			$mStr1 = "<TD $HbgInfoCell align=right>$island->{'money'}$HunitMoney</TD>";
		} elsif(($HhideMoneyMode == 2) || ($HhideMoneyMode == 3)) {
			my($mTmp) = aboutMoney($island->{'money'});
			$mStr1 = "<TD $HbgInfoCell align=right>$mTmp</TD>";
		}

		my($msStr1) = '';
		if($HhideMissileMode) {
			$msStr1 = "<TD $HbgInfoCell align=right>$island->{'missiles'}${HunitMissile}";
			if($HhideMissileMode == 2) {
				my($mTmp) = aboutMissile($island->{'missiles'});
				$msStr1 = "<TD $HbgInfoCell align=right>${mTmp}</TD>";
			} elsif($HuseArmSupply) {
				$msStr1.= "($island->{'army'}개)</TD>";
			} else {
				$msStr1.= "</TD>";
			}
		}

		my($oStr) = '';
		if($island->{'onm'} eq ''){
			$oStr = "<TD $HbgTotoCell COLSPAN=$col1 align=left>${HtagTH_}코멘트 : ${H_tagTH}$island->{'comment'}</TD>";
		} else {
			$oStr = "<TD $HbgTotoCell COLSPAN=$col1 align=left>${HtagLbbsSS_}$island->{'onm'} : ${H_tagLbbsSS}$island->{'comment'}</TD>";
		}

		# 인공위성
		my($me_sat) = "<span class='eisei'>";
		my($kind, $i);
		my $emp = 0;
		for($i = 1; $i < 7; $i++) {
			$kind = 'eis'. $i;
			$me_sat.= "<IMG SRC=\"$HeiseiImage[$i]\" TITLE=\"$HeiseiName[$i]\" WIDTH=16 HEIGHT=\"16\">$island->{$kind}%" if ($island->{$kind}>= 1);
			$emp += $island->{$kind};
		}
		$me_sat.= "</span>";
		$me_sat = " " if (!$emp);

		# 목장계
		my($Farmcpc) = "<span class='unemploy1'>";
		$tare = $island->{'tare'};
		$zipro = $island->{'zipro'};
		$leje = $island->{'leje'};
		$Farmcpc.= "<IMG SRC=\"niwatori.gif\" TITLE=\"닭\" WIDTH=16 HEIGHT=\"16\">$tare 만 마리" if($tare);
		$Farmcpc.= "<IMG SRC=\"buta.gif\" TITLE=\"돼지\" WIDTH=16 HEIGHT=\"16\">$zipro 만 두" if($zipro);
		$Farmcpc.= "<IMG SRC=\"ushi.gif\" TITLE=\"우시\" WIDTH=16 HEIGHT=\"16\">$leje 만 두" if($leje);
		$Farmcpc.= "</span>";
		$Farmcpc = " " if(!$tare && !$zipro && !$leje);

		# 가
		my($house) = "";
		$eisei1 = $island->{'eisei1'};
		$pts = $island->{'pts'};
		my $hlv;
		foreach (0..9) {
			$hlv = 9 - $_;
			last if($pts> $HouseLevel[$hlv]);
		}
		my $onm = $island->{'onm'};
		my $n = ('의오두막', '의간이주택', '의주택', '의고급주택', '의저택', '의대저택', '의고급 저택', '의성', '의거성', '의황금성')[$hlv];

		my $zeikin = int($island->{'pop'}*($hlv+1)*$eisei1/100);
		if ($eisei1) {
			$house.= "<span class='house'><IMG SRC=\"house${hlv}.gif\" TITLE=\"$onm$n\" WIDTH=16 HEIGHT=\"16\">세율$eisei1%($zeikin$HunitMoney)</span>"
		} else {
			$house = ""
		};

		my $shutoname;
		my $shutomessage = $island->{'shutomessage'};
		if ($shutomessage == 555) {
			$shutoname = ""
		} else {
			$shutoname = "<span class='shuto'>수도:$shutomessage</span><br>"
		};

		out(<<END);
<TR>
<TH $HbgNumberCell ROWSPAN=4 align=center><FONT size="5">${HtagNumber_}$j${H_tagNumber}</FONT></TD>
END

		if($id <= 100) {
			out(<<END);
<TD $HbgNameCell ROWSPAN=4 align=left>
<center>
<A STYlE=\"text-decoration:none\" HREF="${HthisFile}?Sight=${id}" title="ID:${id}">
$name
</A><br>
<font size="-1">$shutoname</font>
ID:(<span class="house"><B>$id</B></span>) <span class="point">$pts</span>pts.<br>
<font size="-1">실업률</font>:($unemployed)<br>
<span class="eisei"><font size="-1">$eisei2</font></span>
<span class="monsm"><font size="-2">(전 턴$seicho$zouka$rieki)</font></span>
</center>
</TD>
END
		} else {
			$msStr1 = "<TD $HbgInfoCell align=right>-</TD>" if($HhideMissileMode);
			$oStr = "<TD $HbgTotoCell COLSPAN=$col1 align=left>${HtagLbbsSS_}$HadminName${H_tagLbbsSS} : </font>$island->{'comment'}</TD>";

			out(<<END);
<TH $HbgNameCell ROWSPAN=4 align=left>
<center>
<A STYlE=\"text-decoration:none\" HREF="${HthisFile}?Sight=${id}" title="ID:${id}">
$name
</A><br>
<br>
${HtagTH_}Battle Field${H_tagTH}</center>
</TH>
END
		}

		out(<<END);
<TD $HbgInfoCell align=right>$island->{'pop'}$HunitPop</TD>
<TD $HbgInfoCell align=right>$island->{'area'}$HunitArea</TD>
$mStr1
<TD $HbgInfoCell align=right>$island->{'food'}$HunitFood</TD>
<TD $HbgInfoCell align=right>$farm</TD>
<TD $HbgInfoCell align=right>$factory</TD>
<TD $HbgInfoCell align=right>$mountain</TD>
<TD $HbgInfoCell align=right>Lv$renae</TD>
$msStr1
</TR>
<TR>
<TD $HbgTotoCell COLSPAN=4 align=left>${HtagtTH_}예상1:${H_tagtTH}$island->{'totoyoso'}->[0]</TD>
<TD $HbgTotoCell COLSPAN=$col align=left>${HtagtTH_}예상2:${H_tagtTH}$island->{'totoyoso'}->[1]</TD>
</TR>
<TR>
$oStr
</TR>
<TR>
<TD $HbgCommentCell COLSPAN=$col1 align=left>${HtagtTH_}<font size="-1">$bumons$prize$ssss$unique$house$monsliveimg$monsm$mspet$Farmcpc$me_sat</font></TD>
</TR>
END
	}

	out(<<END);
</TABLE>
</DIV>
<DIV ID='HakoniwaCup'>
<HR>
<H1><a href="$HthisFile?HCdata=0">Hakoniwa Cup $hcturn</a></H1>
<DIV style="overflow:auto; height:${HdivHeight2}px;">
END
	hcPrint();
	out("</DIV></DIV>");
	out(<<END) if ($HadminJoinOnly);
<HR>
<DIV align="right"><FORM action="$HthisFile" method="POST" style="
	margin : 2px 0px;
"><INPUT type="hidden" name="Join" value=0><INPUT type="password" name="PASSWORD" size=16 maxlength=16><INPUT type="submit" name="submit" value="관리용"></FORM></DIV>
END
}

# Hakoniwa Cup 로그 표시
sub hcPrint {
	open(CIN, "${HdirName}/hakojima.lhc");
	my(@line, $l);
	while($l = <CIN>) {
		chomp($l);
		push(@line, $l);
	}
	@line = reverse(@line);

	foreach $l (@line) {
		$l =~ /^([0-9]*),(.*)$/;
		out("${HtagNumber_}턴${1}${H_tagNumber}:${2}<BR>\n");
	}
	close(CIN);
}

# 기록 파일 표시
sub historyPrint {
	open(HIN, "${HdirName}/hakojima.his");
	my(@line, $l);
	while($l = <HIN>) {
		chomp($l);
		push(@line, $l);
	}
	@line = reverse(@line);

	if(!$Hseason) {
		foreach $l (@line) {
			$l =~ /^([0-9]*),(.*)$/;
			out("${HtagNumber_}턴${1}${H_tagNumber}:${2}<BR>\n");
		}
	} else {
		# 계절의 표시
		out("<TABLE>");
		foreach $l (@line) {
			$l =~ /^([0-9]*),(.*)$/;
			my @seasonName = ('<span class=winter>겨울</span>','<span class=spring>봄</span>','<span class=summer>여름</span>','<span class=autumn>가을</span>');
			my $month = ($1 % 12) + 1;
			my $year = ($1 / 12) + 1;
			my $calender = sprintf('<span class=month><FONT SIZE=2>%d년 %02d월 </FONT><span>', $year, $month);
			$calender.= "<span class='season'>$seasonName[int(($month - 1) / 3)]</span>";
			out("<TR><TD class='M'>${HtagNumber_}턴${1}${H_tagNumber}:${2}</TD><TD class='M'>$calender</TD></TR>\n");
		}
		out("</TABLE>");
	}
	close(HIN);
}

# 동맹 정보
sub amityOfAlly() {
	# 개방
	unlock();

	my $ally = $Hally[$HidToAllyNumber{$HallyID}];
	my $allyName = "<FONT COLOR=\"$ally->{'color'}\"><B>$ally->{'mark'}</B></FONT>$ally->{'name'}";

	out(<<END);
<DIV align='center'>$HtempBack</DIV><BR>
<DIV ID='campInfo'>
<H1>$allyName 의 정보</H1>
END

	allyInfo($HallyID) if($ally->{'number'});

	my($mStr1) = '';
	if($HhideMoneyMode) {
		$mStr1 = "<TH $HbgTitleCell align=center>${HtagTH_} 자금${H_tagTH}</TH>";
		$col++;
	}

	my($msStr1) = '';
	if($HhideMissileMode) {
		$msStr1 = "<TH $HbgTitleCell align=center>${HtagTH_}미사일 수";
		$col++;
		if($HuseArmSupply) {
			$msStr1.= "(군사 물자)${H_tagTH}</TH>";
		} else {
			$msStr1.= "${H_tagTH}</TH>";
		}
	}
	if($ally->{'message'} ne '') {
		my $allyTitle = $ally->{'title'};
		$allyTitle = '맹주의 메시지' if($allyTitle eq '');
		my $allyMessage = $ally->{'message'};
		$allyMessage =~ s/([^=^\"]|^)(http\:[\w\.\~\-\/\?\&\+\=\:\@\%\;\#\%]+)/$1<a href=\"$2\" target='_top'>$2<\/a>/g;
		out(<<END);
<HR>
<TABLE BORDER width=80%>
<TR><TH $HbgTitleCell>${HtagTH_}$allyTitle${H_tagTH}</TH></TR>
<TR><TD $HbgInfoCell><blockquote>$allyMessage</blockquote></TD></TR>
</TABLE>
END
	}

	out(<<END);
<HR>
<TABLE BORDER><TR>
<TH $HbgTitleCell align=center>${HtagTH_}순위${H_tagTH}</TH>
<TH $HbgTitleCell align=center>${HtagTH_}${AfterName}${H_tagTH}</TH>
<TH $HbgTitleCell align=center>${HtagTH_}포인트${H_tagTH}</TH>
<TH $HbgTitleCell align=center>${HtagTH_}인구${H_tagTH}</TH>
<TH $HbgTitleCell align=center>${HtagTH_}면적${H_tagTH}</TH>
$mStr1
<TH $HbgTitleCell align=center>${HtagTH_}식량${H_tagTH}</TH>
<TH $HbgTitleCell align=center>${HtagTH_}농장규모${H_tagTH}</TH>
<TH $HbgTitleCell align=center>${HtagTH_}공장규모${H_tagTH}</TH>
<TH $HbgTitleCell align=center>${HtagTH_}채굴장규모${H_tagTH}</TH>
<TH $HbgTitleCell align=center>${HtagTH_}군사 기술${H_tagTH}</TH>
$msStr1
</TR>
END
	out("<TR><TH colspan=$col>소속하고 있는 섬 없습니다!</TH></TR>") if(!$ally->{'number'});

	my($id, $number, $island, $farm, $factory, $mountain, $farm, $name, $mStr2, $msStr2);
	foreach (@{$ally->{'memberId'}}) {
		$id = $_;
		$number = $HidToNumber{$id};
		$island = $Hislands[$number];
		$number += (1 - $HbfieldNumber);
		$farm = $island->{'farm'};
		$factory = $island->{'factory'};
		$mountain = $island->{'mountain'};
		$farm = ($farm == 0) ? "보유하지 않음" : "${farm}0$HunitPop";
		$factory = ($factory == 0) ? "보유하지 않음" : "${factory}0$HunitPop";
		$mountain = ($mountain == 0) ? "보유하지 않음" : "${mountain}0$HunitPop";
		$name = islandName($island);
		if($island->{'field'}) {
			$number = "★";
			$name = "${HtagNumber_}${name}${H_tagNumber}";
		} elsif($island->{'absent'} == 0) {
			$name = "${HtagName_}${name}${H_tagName}";
		} else {
			$name = "${HtagName2_}${name}($island->{'absent'})${H_tagName2}";
		}
		$name.= '<span class=attention>★</span>' if ($HislandTurn - $island->{'birthday'} <= $HdevelopTurn);
		$name = "<span class=attention>[관리자 보관]</span><BR>". $name if($island->{'predelete'});
		$mStr2 = '';
		if($HhideMoneyMode == 1) {
			$mStr2 = "<TD $HbgInfoCell align=right>$island->{'money'}$HunitMoney</TD>";
		} elsif(($HhideMoneyMode == 2) || ($HhideMoneyMode == 3)) {
			my($mTmp) = aboutMoney($island->{'money'});
			$mStr2 = "<TD $HbgInfoCell align=right>$mTmp</TD>";
		}
		$renae = int($island->{'rena'} / 10 ) + 1;
		$msStr2 = '';
		if($HhideMissileMode) {
			$msStr2 = "<TD $HbgInfoCell align=right>$island->{'missiles'}${HunitMissile}";
			if($HhideMissileMode == 2) {
				my($mTmp) = aboutMissile($island->{'missiles'});
				$msStr2 = "<TD $HbgInfoCell align=right>${mTmp}</TD>";
			} elsif($HuseArmSupply) {
				$msStr2.= "($island->{'army'}개)</TD>";
			} else {
				$msStr2.= "</TD>";
			}
		}

	out(<<END);
<TR>
<TD $HbgNumberCell align=center>${HtagNumber_}$number${H_tagNumber}</TD>
<TD $HbgNameCell align=left>
<A STYlE=\"text-decoration:none\" HREF="${HthisFile}?Sight=${id}">
$name
</A></TD>
<TD $HbgInfoCell align=right>$island->{'pts'}</TD>
<TD $HbgInfoCell align=right>$island->{'pop'}$HunitPop</TD>
<TD $HbgInfoCell align=right>$island->{'area'}$HunitArea</TD>
$mStr2
<TD $HbgInfoCell align=right>$island->{'food'}$HunitFood</TD>
<TD $HbgInfoCell align=right>$farm</TD>
<TD $HbgInfoCell align=right>$factory</TD>
<TD $HbgInfoCell align=right>$mountain</TD>
<TD $HbgInfoCell align=right>Lv$renae</TD>
$msStr2
</TR>
END
	}

		out(<<END);
</TABLE>
END
}

# 동맹의 상황
sub allyInfo() {
	my($num) = @_;

	my $aStr = ($HarmisticeTurn) ? '진영' : '동맹';
	if($num == -1) {
		out(<<END);
<HR>
<DIV ID='campInfo'>
<P><H1 style="display:inline;">각 동맹의 상황</H1>
END
	} else {
		out("<P>");
	}

	out(<<END);
점유율은 <B>포인트</B>를 기준으로 산출됩니다.
</P>
<TABLE BORDER>
<TR>
<TH $HbgTitleCell align=center>${HtagTH_}순위${H_tagTH}</TH>
<TH $HbgTitleCell align=center>${HtagTH_}${aStr}${H_tagTH}</TH>
<TH $HbgTitleCell align=center>${HtagTH_}표시${H_tagTH}</TH>
<TH $HbgTitleCell align=center>${HtagTH_}${AfterName}의 수${H_tagTH}</TH>
<TH $HbgTitleCell align=center>${HtagTH_}포인트${H_tagTH}</TH>
<TH $HbgTitleCell align=center>${HtagTH_}점유율${H_tagTH}</TH>
<TH $HbgTitleCell align=center>${HtagTH_}탄환 발사${H_tagTH}</TH>
<TH $HbgTitleCell align=center>${HtagTH_}날아온 탄환${H_tagTH}</TH>
<TH $HbgTitleCell align=center>${HtagTH_}GNP${H_tagTH}</TH>
</TR>
END

	foreach (0..($HallyNumber - 1)) {
		next if(($num != -1) && ($_ != $HidToAllyNumber{$num}));
		my($n) = $_ + 1;
		my($ally) = $Hally[$_];
		my($missileOut) = ($ally->{'ext'}[0] == 0) ? "없음" : "$ally->{'ext'}[0]발";
		my($missileIn) = ($ally->{'ext'}[1] == 0) ? "없음" : "$ally->{'ext'}[1]발";
		my($gnp) = "$ally->{'ext'}[2]${HunitMoney}";
		my $owner = $HidToNumber{$ally->{'id'}};
		my $row = 2;
		if(defined $owner) {
			$owner = islandName($Hislands[$owner]);
		} else {
			$row = 1;
		}
		my $name;
		if($num == -1) {
			$name = "<A style=\"text-decoration:none\" href=\"$HthisFile?AmiOfAlly=$ally->{'id'}\">$ally->{'name'}</A>";
		} else {
			$name = $ally->{'name'};
		}
		my $comment = $ally->{'comment'};
		out(<<END);
<TR>
<TD $HbgNumberCell rowspan=$row align=center>${HtagNumber_}$n${H_tagNumber}</TD>
<TD $HbgInfoCell rowspan=$row align=center>$name</TD>
<TD $HbgInfoCell align=center><B><FONT COLOR="$ally->{'color'}">$ally->{'mark'}</FONT></B></TD>
<TD $HbgInfoCell align=right>$ally->{'number'}${AfterName}</TD>
<TD $HbgInfoCell align=right>$ally->{'score'}</TD>
<TD $HbgInfoCell align=right>$ally->{'occupation'}\%</TD>
<TD $HbgInfoCell align=right>$missileOut</TD>
<TD $HbgInfoCell align=right>$missileIn</TD>
<TD $HbgInfoCell align=right>$gnp</TD>
</TR>
END
		out(<<END) if($row == 2);
<TR>
<TD $HbgCommentCell colspan=9><A style="text-decoration:none" href="$HthisFile?Allypact=$ally->{'id'}">${owner}</A>:$comment</TD>
</TR>
END
	}

	out("</TABLE>");
	out("</DIV>") if($num == -1);
}

1;
