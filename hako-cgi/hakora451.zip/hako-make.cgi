#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}
#----------------------------------------------------------------------
# 하코니와 제도 ver2.30
# 신규작성모듈(ver1.00)
# 사용 조건과 사용 방법은 hako-readme.txt 파일을 참조해 주세요
#
#----------------------------------------------------------------------

#주변 2헥스의 좌표
#my(@ax) = (0, 1, 1, 1, 0,-1, 0, 1, 2, 2, 2, 1, 0,-1,-1,-2,-1,-1, 0);
#my(@ay) = (0,-1, 0, 1, 1, 0,-1,-2,-1, 0, 1, 2, 2, 2, 1, 0,-1,-2,-2);

#주변 3헥스의 좌표
#my(@ax) = (
#	 0,
#	 1, 1, 1, 0,-1, 0,
#	 1, 2, 0, 2, 2, 1, 0,-1,-1,-2,-1,-1,
#	 2, 2, 1, 3, 0, 3, 3, 2, 2, 1, 0,-1,-2,-2,-3,-2,-2,-1,
#	 );
#my(@ay) = (
#	 0,
#	 -1, 0, 1, 1, 0,-1,
#	 -2,-1,-2, 0, 1, 2, 2, 2, 1, 0,-1,-2,
#	 -3,-2,-3,-1,-3, 0, 1, 2, 3, 3, 3, 3, 2, 1, 0,-1,-2,-3,
#	 );

# 주변 5헥스의 좌표
# 주변 0헥스까지조사하는 경우,0번째의 데이터까지를 조사하기
# 주변 1헥스까지조사하는 경우,6번째의 데이터까지를 조사하기
# 주변 2헥스까지조사하는 경우,18번째의 데이터까지를 조사하기
# 주변 3헥스까지조사하는 경우,36번째의 데이터까지를 조사하기
# 주변 4헥스까지조사하는 경우,60번째의 데이터까지를 조사하기
# 주변 5헥스까지조사하는 경우,90번째의 데이터까지를 조사하기
# 예)주변 2헥스까지조사(1번째~18번째 데이터에서 조사)
# for($i = 1; $i <= 18; $i++) {	 # 주변($x,$y)을 포함먼저
#	 $sx = $x + $ax[$i];
#	 $sy = $y + $ay[$i];
#	 # Y방향 보정(HEX 지도이므로 필요)
#	 $sy-- if((($sy % 2) == 0) && (($y % 2) == 1));
#	 next if(($sx < 0) || ($sx> $islandSize)
#		 || ($sy < 0) || ($sy> $islandSize));
#	 if($land->[$sx][$sy] == $HlandSea) { # 바다?
#		.... 략....
#	 }
# }

my(@ax) = (0,1,1,1,0,-1,0,1,2,2,2,1,0,-1,-1,-2,-1,-1,0,2
		,2,3,3,3,2,2,1,0,-1,-2,-2,-3,-2,-2,-1,0,1,2,3,3
		,4,4,4,3,3,2,1,0,-1,-2,-2,-3,-3,-4,-3,-3,-2,-2,-1,0
		,1,3,3,4,4,5,5,5,4,4,3,3,2,1,0,-1,-2,-3,-3,-4
		,-4,-5,-4,-4,-3,-3,-2,-1,0,1,2);
my(@ay) = (0,-1,0,1,1,0,-1,-2,-1,0,1,2,2,2,1,0,-1,-2,-2,-3
		,-2,-1,0,1,2,3,3,3,3,2,1,0,-1,-2,-3,-3,-3,-4,-3,-2
		,-1,0,1,2,3,4,4,4,4,4,3,2,1,0,-1,-2,-3,-4,-4,-4
		,-4,-5,-4,-3,-2,-1,0,1,2,3,4,5,5,5,5,5,5,4,3,2
		,1,0,-1,-2,-3,-4,-5,-5,-5,-5,-5);

#----------------------------------------------------------------------
# 섬 신규 생성 모드
#----------------------------------------------------------------------
# 메인
sub newIslandMain {
	# 부정 접속을 확인
	if($HadminJoinOnly) {
		unless($ENV{HTTP_REFERER} =~ /^$HthisFile/) {
			unlock();
			tempHeader();
			tempNewIslandillegal();
			return;
		}
	}
	# 섬이 가득 차서 없습니까 확인		서바이벌 모드
	if(($HislandNumber - $HbfieldNumber>= $HmaxIsland) || ( $HsurvivalTurn && ($HislandTurn> $HsurvivalTurn) )) {
		unlock();
		tempHeader();
		tempNewIslandFull();
		return;
	}

	# 이름이 있는 지 확인
	if($HcurrentName eq '') {
		unlock();
		tempHeader();
		tempNewIslandNoName();
		return;
	}

	# 이름이 유효한지 확인
	if($HcurrentName =~ /[,\?\(\)\<\>\$]|^무인|^침몰$/) {
		# 사용 불가 이름
		unlock();
		tempHeader();
		tempNewIslandBadName();
		return;
	}

	# 이름의 중복 확인
	if(nameToNumber($HcurrentName) != -1) {
		# 이미 발견완료
		unlock();
		tempHeader();
		tempNewIslandAlready();
		return;
	}

	# password 의존재판정
	if($HinputPassword eq '') {
		# password 무시
		unlock();
		tempHeader();
		tempNewIslandNoPassword();
		return;
	}

	# 확인용 비밀번호
	if($HinputPassword2 ne $HinputPassword) {
		# password 오류
		unlock();
		tempHeader();
		tempWrongPassword();
		return;
	}

	# 새 섬의 번호 정하기
	$HcurrentNumber = $HislandNumber;
	$HislandNumber++;
	$islandNumber++;
	$Hislands[$HcurrentNumber] = makeNewIsland();
	my($island) = $Hislands[$HcurrentNumber];

	# ID 사용이회시
	my $safety = 0;
	while(defined $HidToNumber{$HislandNextID}) {
		$HislandNextID ++;
		$HislandNextID = 1 if($HislandNextID> 100);
		$safety++;
		last if($safety == 100);
	}

	# 각종의 값을 설정
	$island->{'name'} = $HcurrentName;
	$island->{'id'} = $HislandNextID;
	$HislandNextID ++;
	$HislandNextID = 1 if($HislandNextID> 100);
	$island->{'absent'} = $HgiveupTurn - 3;
	$island->{'comment'} = '(미 등록)';
	$island->{'password'} = encode($HinputPassword);
	$island->{'eisei1'} = 0;
	$island->{'eisei2'} = 0;
	$island->{'eisei3'} = 0;
	$island->{'eisei4'} = '0,0,0,0,0,0,0,0,0,0,0';
	$island->{'eisei5'} = '0,0,0,0,0,0,0';
	$island->{'eisei6'} = '0,0,0,0,0,0,0,0,0,0,0,0';
	$island->{'eis1'} = 0;
	$island->{'eis2'} = 0;
	$island->{'eis3'} = 0;
	$island->{'eis4'} = 0;
	$island->{'eis5'} = 0;
	$island->{'eis6'} = 0;
	$island->{'ext'} = '0,0,0,0,0,0,0,0';
	$island->{'army'} = 0;
	$island->{'taiji'} = 0;
	$island->{'onm'}	= htmlEscape($HcurrentOwnerName);
	$island->{'owner'} = htmlEscape($HcurrentOwnerName);
	$island->{'id1'}	= $HislandNextID;
	$island->{'kei'}	= 0;
	$island->{'rena'} = 0;
	$island->{'shr'}	= 0;
	$island->{'fore'} = 0;
	$island->{'pika'} = 0;
	$island->{'hamu'} = 0;
	$island->{'monta'} = 0;
	$island->{'tare'} = 0;
	$island->{'zipro'} = 0;
	$island->{'leje'} = 0;
	$island->{'shutomessage'} = 555;

	if($HeasyMode) {
		if(random(100) < 50) {
		 $island->{'eis1'} = 200;
		} else {
		 $island->{'eis2'} = 200;
		}
	}
	# 인구기타 산출
	estimate($HcurrentNumber);
	if($HarmisticeTurn) {
		my $ally = $Hally[$campNum];
		$ally->{'score'} += $island->{'pts'};
		push(@{$ally->{'memberId'}}, $island->{'id'});
		$ally->{'number'}++;
		push(@{$island->{'allyId'}}, $ally->{'id'});
	}
	$HidToNumber{$island->{'id'}} = $HcurrentNumber;
	islandSort('pts', 1);
	if($HarmisticeTurn) {
		allyOccupy();
		allySort();
	}

	# 데이터 쓰기
	writeIslandsFile($island->{'id'});
	logDiscover($HcurrentName); # 로그

	$HcurrentID = $HislandNextID - 1;
	$HmainMode = 'owner';
	$HjavaMode = 'java';
	# COOKIE 출력
	cookieOutput();

	# 개방
	unlock();

	# 발견 화면
	tempHeader();
	tempNewIslandHead($HcurrentName); # 발견했습니다!!
	foreach (0..$HcurrentNumber) {
		if($Hislands[$_]->{'id'} == $island->{'id'}) {
			$HcurrentNumber = $_;
			last;
		}
	}
	islandInfo(); # 섬의 정보
	islandMap(1); # 섬 지도, 소유자 모드
}

# 새 섬 만들기
sub makeNewIsland {
	# 지형을 만들기
	my($land, $landValue) = makeNewLand();

	# 초기 명령을 생성
	my(@command, $i);
	for($i = 0; $i < $HcommandMax; $i++) {
		$command[$i] = {
			'kind' => $HcomDoNothing,
			'target' => 0,
			'x' => 0,
			'y' => 0,
			'arg' => 0
		};
	}

	# 초기 게시판 생성
	my(@lbbs);
	for($i = 0; $i < $HlbbsMax; $i++) {
		$lbbs[$i] = "0<<0>>";
	}

	# 섬으로 반환
	return {
		'land' => $land,
		'landValue' => $landValue,
		'command' => \@command,
		'lbbs' => \@lbbs,
		'money' => (!$HarmisticeTurn || !$HislandTurn ? $HinitialMoney : $HinitialMoney2),
		'food' => (!$HarmisticeTurn || !$HislandTurn ? $HinitialFood : $HinitialFood2),
		'prize' => '0,0,',
		'monsterlive' => 0,
		'monsterlivetype' => 0,
		'hmonsterlivetype' => 0,
		'missiles' => 0,
		'ext' => '0,0,0,0,0,0,0,0',
	};
}

# 새 섬 지형 만들기
sub makeNewLand {
	# 기본형 생성
	my(@land, @landValue, $x, $y, $i);

	# 바다에 초기화
	foreach $y (0..$islandSize) {
		foreach $x (0..$islandSize) {
			$land[$x][$y] = $HlandSea;
			$landValue[$x][$y] = 0;
		}
	}

	# 섬 중앙 4×4에 황무지를 배치
	my($center) = $HislandSize / 2 - 1;
	for($y = $center - 1; $y < $center + 3; $y++) {
		for($x = $center - 1; $x < $center + 3; $x++) {
			$land[$x][$y] = $HlandWaste;
		}
	}

	# 8*8범위내에육지를 증식
	for($i = 0; $i < 120; $i++) {
		# 무작위좌표
		$x = random(8) + $center - 3;
		$y = random(8) + $center - 3;

		if(countAround(\@land, $x, $y, 7, $HlandSea) != 7){
			# 주변에 육지가 있는 경우, 얕은 바다로
			# 얕은 바다는 황무지로
			# 황무지는 평지로
			if($land[$x][$y] == $HlandWaste) {
				$land[$x][$y] = $HlandPlains;
				$landValue[$x][$y] = 0;
			} else {
				if($landValue[$x][$y] == 1) {
					$land[$x][$y] = $HlandWaste;
					$landValue[$x][$y] = 0;
				} else {
					$landValue[$x][$y] = 1;
				}
			}
		}
	}

	# 숲을 만들기
	my($count) = 0;
	while($count < 4) {
		# 무작위좌표
		$x = random(4) + $center - 1;
		$y = random(4) + $center - 1;

		# 그곳이이미 숲이 아니면, 숲을 만들기
		if($land[$x][$y] != $HlandForest) {
			$land[$x][$y] = $HlandForest;
			$landValue[$x][$y] = 5; # 처음은500본
			$count++;
		}
	}

	# 읍을 만들기
	$count = 0;
	while($count < 2) {
		# 무작위좌표
		$x = random(4) + $center - 1;
		$y = random(4) + $center - 1;

		# 그곳이 숲이나 도시가 아니면 도시를 만들기
		if(($land[$x][$y] != $HlandTown) &&
		 ($land[$x][$y] != $HlandForest)) {
			$land[$x][$y] = $HlandTown;
			$landValue[$x][$y] = 5; # 처음은500인
			$count++;
		}
	}

	# 산을 만들기
	$count = 0;
	while($count < 1) {
		# 무작위좌표
		$x = random(4) + $center - 1;
		$y = random(4) + $center - 1;

		# 그곳이 숲이나 도시가 아니면 도시를 만들기
		if(($land[$x][$y] != $HlandTown) &&
		 ($land[$x][$y] != $HlandForest)) {
			$land[$x][$y] = $HlandMountain;
			$landValue[$x][$y] = 0; # 처음은 채굴장없음
			$count++;
		}
	}

	# 기지를 만들기
	$count = 0;
	while($count < 1) {
		# 무작위좌표
		$x = random(4) + $center - 1;
		$y = random(4) + $center - 1;

		# 그곳이 숲/도시/산이 아니면 기지
		if(($land[$x][$y] != $HlandTown) &&
		 ($land[$x][$y] != $HlandForest) &&
		 ($land[$x][$y] != $HlandMountain)) {
			$land[$x][$y] = $HlandBase;
			$landValue[$x][$y] = 0;
			$count++;
		}
	}

	return (\@land, \@landValue) if(!$HeasyMode);

	# 뉴타운을 만들기
	$count = 0;
	while($count < 1) {
		# 무작위좌표
		$x = random(4) + $center - 1;
		$y = random(4) + $center - 1;

		# 그곳이 숲/도시/산이 아니면 기지
		if(($land[$x][$y] != $HlandTown) &&
			($land[$x][$y] != $HlandForest) &&
			($land[$x][$y] != $HlandBase) &&
			($land[$x][$y] != $HlandMountain)) {
			$land[$x][$y] = $HlandNewtown;
			$landValue[$x][$y] = 10;
			$count++;
		}
	}

	# 대학을 만들기
	$count = 0;
	while($count < 1) {
		# 무작위좌표
		$x = random(4) + $center - 1;
		$y = random(4) + $center - 1;

		# 그곳이 숲/도시/산이 아니면 기지
		if(($land[$x][$y] != $HlandTown) &&
			($land[$x][$y] != $HlandForest) &&
			($land[$x][$y] != $HlandBase) &&
			($land[$x][$y] != $HlandNewtown) &&
			($land[$x][$y] != $HlandMountain)) {
			$land[$x][$y] = $HlandCollege;
			$landValue[$x][$y] = random(3);

			$count++;
		}
	}

	# 항구를 만들기
	$count = 0;
	while($count < 1) {
		# 무작위좌표
		$x = random(4) + $center - 1;
		$y = random(4) + $center - 1;

		# 주변에육이 있는 지 확인
		my($seaCount) =	countAround($land, $x, $y, 7, $HlandSea);
		if($seaCount != 0) {
			# 그곳이 숲/도시/산이 아니면 기지
			if(($land[$x][$y] != $HlandTown) &&
				($land[$x][$y] != $HlandForest) &&
				($land[$x][$y] != $HlandBase) &&
				($land[$x][$y] != $HlandNewtown) &&
				($land[$x][$y] != $HlandCollege) &&
				($land[$x][$y] != $HlandMountain)) {
				$land[$x][$y] = $HlandMinato;
				$landValue[$x][$y] = 5;
				$count++;
			}
		}
	}

	return (\@land, \@landValue);
}

# 섬 수가 가장 적고, 순위가 최하위의 진영
sub selectMinCamp {
	my($i, $num) = (0, 0);
	for ($i = 1; $i < $HallyNumber; $i++) {
		if ($Hally[$i]->{'number'} <= $Hally[$num]->{'number'}) {
			$num = $i;
		}
	}
	return $num;
}

# 무작위("전체 섬 수/진영 수+1"까지)
sub selectRandomCamp {
	my($i, $j, $ave, $iave, @array, $len);
	# 빈칸 진영배열의 작성
	$ave = $HmaxIsland / $HallyNumber;
	$iave = int($ave);
	if ($iave != $ave) { $iave++; };
	for ($i = 0; $i < $HallyNumber; $i++) {
		for ($j = 0; $j < ($iave - $Hally[$i]->{'number'}); $j++) {
			push(@array, $i);
			$len++;
		}
	}
	return $array[int(rand($len))];
}

# 진영의 선택루틴(설정으로 변경)
sub selectCamp {
	if ($HcampSelectRule == 0) {
		return selectMinCamp();
	} elsif ($HcampSelectRule == 1) {
		return selectRandomCamp();
	} else {
		# 어디든 가능를 선택
		return selectRandomCamp();
	}
}
#----------------------------------------------------------------------
# 정보 변경 모드
#----------------------------------------------------------------------
# 메인
sub changeMain {
	# id에서 섬을 가져옴
	$HcurrentNumber = $HidToNumber{$HcurrentID};
	my($island) = $Hislands[$HcurrentNumber];
	my($flag) = 0;

	# 비밀번호 확인
	if(checkSpecialPassword($HoldPassword)) {
		# 특수 비밀번호
		if($HcurrentName =~ /^로그$/) {
			# 최근 사건강제출력
			logPrintHtml();
			unlock();
			tempChange();
			return;
		} elsif($HcurrentName =~ /^무인$/) {
			# 섬 삭제 모드
			deleteIsland(1);
			return;
		} elsif($HcurrentName =~ /^침몰$/) {
			# 섬 삭제 모드
			deleteIsland(0);
			return;
		} elsif(!checkMasterPassword($HoldPassword)) {
			# 식량/자금 max 모드
			$island->{'money'} = $HmaximumMoney;
			$island->{'food'} = $HmaximumFood;
		}
	} elsif(!checkPassword($island,$HoldPassword)) {
		# password 오류
		unlock();
		tempWrongPassword();
		return;
	}

	# 확인용 비밀번호
	if($HinputPassword2 ne $HinputPassword) {
		# password 오류
		unlock();
		tempWrongPassword();
		return;
	}

	if($HcurrentName ne '') {
		# 섬 이름 변경의 경우
		# 섬 이름이 유효한지 확인
		if($HcurrentName =~ /[,\?\(\)\<\>\$]|^무인|^침몰$/) {
			# 사용 불가 이름
			unlock();
			tempNewIslandBadName();
			return;
		}

		# 이름의 중복 확인
		if(nameToNumber($HcurrentName) != -1) {
			# 이미 발견완료
			unlock();
			tempNewIslandAlready();
			return;
		}

		if($island->{'money'} < $HcostChangeName) {
			# 자금 부족
			unlock();
			tempChangeNoMoney();
			return;
		}

		# 대금
		unless(checkSpecialPassword($HoldPassword)) {
			$island->{'money'} -= $HcostChangeName;
		}

		# 이름을 변경
		logChangeName($island->{'name'}, $HcurrentName);
		$island->{'name'} = $HcurrentName;
		$flag = 1;
	}

	if ($HcurrentOwnerName ne '') {
		# 소유자 이름 변경의 경우
		# 소유자 이름이 유효한지 확인
		if($HcurrentOwnerName =~ /[,\?\(\)\<\>\$]/) {
			# 사용 불가 이름
			unlock();
			tempNewIslandBadOwnerName();
			return;
		}

		if($island->{'money'} < $HcostChangeName) {
			# 자금 부족
			unlock();
			tempChangeNoMoney();
			return;
		}

		# 대금
		unless(checkSpecialPassword($HoldPassword)) {
			$island->{'money'} -= $HcostChangeName;
		}

		# 소유자 이름을 변경
		logChangeOwnerName($island->{'name'}, $HcurrentOwnerName);
		$island->{'onm'} = $HcurrentOwnerName;
		$flag = 1;
	}

	# password 변경의 경우
	if($HinputPassword ne '') {
		# 비밀번호를 변경
		$island->{'password'} = encode($HinputPassword);
		$flag = 1;
	}

	if(($flag == 0) && !checkSpecialPassword($HoldPassword)) {
		# 어느 쪽도 변경되어 있지 않음
		unlock();
		tempChangeNothing();
		return;
	}

	# 데이터 쓰기
	writeIslandsFile($HcurrentID);
	unlock();

	# 변경성공
	tempChange();
}

# 섬 이름으로 번호를 얻음(ID가 아니라 번호)
sub nameToNumber {
	my($name) = @_;

	# 전체 섬에서 찾기
	my($i);
	foreach $i (0..$islandNumber) {
		if($Hislands[$i]->{'name'} eq $name) {
			return $i;
		}
	}

	# 찾을 수 없었던 경우
	return -1;
}

# 동맹 이름에서 ID 을얻기루
sub aNameToId {
	my($name) = @_;

	# 전체 섬에서 찾기
	my($i);
	for($i = 0; $i < $HallyNumber; $i++) {
		if($Hally[$i]->{'name'} eq $name) {
			return $Hally[$i]->{'id'};
		}
	}

	# 찾을 수 없었던 경우
	return -1;
}

# 동맹의 표시에서 ID 을얻기루
sub aMarkToId {
	my($mark) = @_;

	# 전체 섬에서 찾기
	my($i);
	for($i = 0; $i < $HallyNumber; $i++) {
		if($Hally[$i]->{'mark'} eq $mark) {
			return $Hally[$i]->{'id'};
		}
	}

	# 찾을 수 없었던 경우
	return -1;
}

#----------------------------------------------------------------------
# 동맹의 신규작성 모드
#----------------------------------------------------------------------
# 결성·변경메인
sub makeAllyMain {

	my $adminMode = 0;
	# 비밀번호 확인
	if(checkSpecialPassword($HoldPassword)) {
		$adminMode = 1;
		if($HallyID> 200) {
			my $max = $HallyID;
			if($HallyNumber) {
				foreach (0..$#Hally) {
					$max = $Hally[$_]->{'id'} + 1 if($max <= $Hally[$_]->{'id'});
				}
			}
			$HcurrentID = $max;
		} elsif(defined $HcurrentAnumber) {
			$HcurrentID = $Hally[$HcurrentAnumber]->{'id'};
		} else {
			unlock();
			out("${HtagBig_}결성 or 변경할 수 없습니다.${H_tagBig}$HtempBack");
			return;
		}
	}

	# 동맹 이름이 있는 지 확인
	if($HallyName eq '') {
		unlock();
		$AfterName = '동맹';
		tempNewIslandNoName();
		return;
	}

	# 동맹 이름이 유효한지 확인
	if($HallyName =~ /[,\?\(\)\<\>\$]|^무인|^침몰$/) {
		# 사용 불가 이름
		unlock();
		tempNewIslandBadOwnerName();
		return;
	}

	# 이름의 중복 확인
	$HcurrentNumber = $HidToNumber{$HcurrentID};
	if(!($adminMode && ($HallyID ne '') && ($HallyID < 200)) &&
		((nameToNumber($HallyName) != -1) ||
		((aNameToId($HallyName) != -1) && (aNameToId($HallyName) != $HcurrentID)))) {
		# 이미결성완료
		unlock();
		tempNewAllyAlready();
		return;
	}

	# 표시의 중복 확인
	if(!($adminMode && ($HallyID ne '') && ($HallyID < 200)) &&
		((aMarkToId($HallyMark) != -1) && (aMarkToId($HallyMark) != $HcurrentID))) {
		# 이미사용완료
		unlock();
		tempMarkAllyAlready();
		return;
	}

	# password 의판정
	my($island) = $Hislands[$HcurrentNumber];
	if(!$adminMode && !checkPassword($island,$HinputPassword)) {
		unlock();
		tempWrongPassword();
		return;
	}
	if(!$adminMode && $island->{'money'} < $HcostMakeAlly) {
		unlock();
		tempNoMoney();
		return;
	}
	my $n = $HidToAllyNumber{$HcurrentID};
	if(defined $n) {
		if($adminMode && ($HallyID ne '') && ($HallyID < 200)) {
			my $allyMember = $Hally[$n]->{'memberId'};
			my $aIsland = $Hislands[$HidToNumber{$HallyID}];
			my $flag = 0;
			foreach (@$allyMember) {
				if($_ == $HallyID) {
					$flag = 1;
					last;
				}
			}
			if(!$flag) {
				$flag = 2 if(@{$aIsland->{'allyId'}}[0] eq '');
			}
			if(!$flag) {
				unlock();
				out("${HtagBig_}변경할 수 없습니다.${H_tagBig}$HtempBack");
				return;
			}
			$Hally[$n]->{'id'} = $HallyID;
			$Hally[$n]->{'oName'} = $aIsland->{'name'};
			if($flag == 2) {
				$Hally[$n]->{'password'} = $aIsland->{'password'};
				$Hally[$n]->{'score'} = $aIsland->{'pts'};
				$Hally[$n]->{'number'}++;
				push(@{$Hally[$n]->{'memberId'}}, $aIsland->{'id'});
				push(@{$aIsland->{'allyId'}}, $aIsland->{'id'});
			}
		} else {
			# 이미결성완료이면 변경
			logChangeAlly($Hally[$n]->{'name'}, $HallyName) if(!$adminMode && ($Hally[$n]->{'name'} ne $HallyName));
		}
	} else {
		# 다른 섬의 동맹에 가입한 경우에는 결성할 수 없습니다
		my $flag = 0;
		for ($i = 0; $i < $HallyNumber; $i++) {
			my $allyMember = $Hally[$i]->{'memberId'};
			foreach (@$allyMember) {
				if($_ == $HcurrentID) {
					$flag = 1;
					last;
				}
			}
			last if($flag);
		}
		if($flag) {
			unlock();
			tempOtherAlready();
			return;
		}

		# 신규
		$n = $HallyNumber;
		$Hally[$n]->{'id'} = $HcurrentID;
		my @memberId = ();
	 if($HallyID < 200) {
			$Hally[$n]->{'oName'} = $island->{'name'};
			$Hally[$n]->{'password'} = $island->{'password'};
			$Hally[$n]->{'number'} = 1;
			@memberId = ($HcurrentID);
			$Hally[$n]->{'score'} = $island->{'pts'};
		} else {
			$Hally[$n]->{'oName'} = '';
			$Hally[$n]->{'password'} = encode($HinputPassword);
			$Hally[$n]->{'number'} = 0;
			$Hally[$n]->{'score'} = 0;
		}
		$Hally[$n]->{'Takayan'} = makeRandomString();
		$Hally[$n]->{'occupation'} = 0;
		$Hally[$n]->{'memberId'} = \@memberId;
		$island->{'allyId'} = \@memberId;
		my @ext = (0, 0, 0);
		$Hally[$n]->{'ext'} = \@ext;
		$HidToAllyNumber{$HcurrentID} = $n;
		$HallyNumber++;
		logMakeAlly($HallyName, islandName($island)) if(!$adminMode); # 로그
	}

	# 동맹의 각종의 값을 설정
	$Hally[$n]->{'name'} = $HallyName;
	$Hally[$n]->{'mark'} = $HallyMark;
	$Hally[$n]->{'color'} = "#${HallyColor}";

	# 비용을 계산
	$island->{'money'} -= $HcostMakeAlly if(!$adminMode);
	# 데이터 쓰기
	allyOccupy();
	allySort();
	writeIslandsFile();
	$HislandList = getIslandList($HcurrentID, 0);

	# 개방
	unlock();
	# 맨 위로
	topPageMain();
}

# 이미그 이름의 동맹이 있는 경우
sub tempNewAllyAlready {
	out(<<END);
${HtagBig_}그 동맹이면 이미결성되 있습니다.${H_tagBig}$HtempBack
END
}

# 이미그 표시의 동맹이 있는 경우
sub tempMarkAllyAlready {
	out(<<END);
${HtagBig_}그 표시예미사용되 있습니다.${H_tagBig}$HtempBack
END
}

# 별도의 동맹을 결성하고 있는
sub tempLeaderAlready {
	out(<<END);
${HtagBig_}맹주는, 자신의 동맹 이외에는 가입할 수 없습니다.${H_tagBig}$HtempBack
END
}

# 이미 다른 동맹에 가입한 경우
sub tempOtherAlready {
	out(<<END);
${HtagBig_}하나의 동맹에만가입할 수 없습니다.${H_tagBig}$HtempBack
END
}

# 자금 부족
sub tempNoMoney {
	out(<<END);
${HtagBig_} 자금 부족입니다(/_<.)${H_tagBig}$HtempBack
END
}
# 해산
sub deleteAllyMain {

	$HcurrentNumber = $HidToNumber{$HcurrentID};
	my($island) = $Hislands[$HcurrentNumber];
	my $n = $HidToAllyNumber{$HcurrentID};
	my $adminMode = 0;
	# 비밀번호 확인
	if(checkSpecialPassword($HoldPassword)) {
		$n = $HcurrentAnumber;
		$HcurrentID = $Hally[$n]->{'id'};
		$adminMode = 1;
	} else {
		# password 의판정
		if(!checkPassword($island,$HinputPassword)) {
			unlock();
			tempWrongPassword();
			return;
		}
		if(!checkPassword($Hally[$n],$HinputPassword)) {
			unlock();
			tempWrongPassword();
			return;
		}
		# 안전 확인용 ID도 확인
		if($Hally[$n]->{'id'} != $HcurrentID) {
			unlock();
			tempWrongAlly();
			return;
		}
	}
	my $allyMember = $Hally[$n]->{'memberId'};
	if($adminMode && $HarmisticeTurn && ((@{$allyMember}[0] ne '') || !(defined $n))){
		unlock();
		out("${HtagBig_}삭제할 수 없습니다.${H_tagBig}$HtempBack");
		return;
	}
	foreach (@$allyMember) {
		my($island, $aId, @newId);
		$island = $Hislands[$HidToNumber{$_}];
		@newId = ();
		foreach $aId (@{$island->{'allyId'}}) {
			if($aId != $HcurrentID) {
				push(@newId, $aId);
			}
		}
		$island->{'allyId'} = \@newId;
	}
	logDeleteAlly($Hally[$n]->{'name'}) if(!$adminMode);
	$Hally[$n]->{'dead'} = 1;
	$HidToAllyNumber{$HcurrentID} = undef;
	$HallyNumber--;
	# 데이터 쓰기
	allyOccupy();
	allySort();
	writeIslandsFile();
	$HislandList = getIslandList($HcurrentID, 0);

	# 개방
	unlock();
	# 맨 위로
	topPageMain();
}

# ID 확인에히걸립니다
sub tempWrongAlly {
	out(<<END);
${HtagBig_}당신은 맹주가 아닌 것으로 보입니다.${H_tagBig}$HtempBack
END
}

# 가입·탈퇴
sub joinAllyMain {

	# password 의판정
	$HcurrentNumber = $HidToNumber{$HcurrentID};
	my($island) = $Hislands[$HcurrentNumber];
	if(!checkPassword($island,$HinputPassword)) {
		unlock();
		tempWrongPassword();
		return;
	}
	if(defined $HidToAllyNumber{$HcurrentID}) {
		unlock();
		tempLeaderAlready();
		return;
	}
	my $ally = $Hally[$HcurrentAnumber];
	if($HallyJoinOne && ($island->{'allyId'}[0] ne '') && ($island->{'allyId'}[0] != $ally->{'id'})) {
		unlock();
		tempOtherAlready();
		return;
	}
	my $allyMember = $ally->{'memberId'};
	my @newAllyMember = ();
	my $flag = 0;
	foreach (@$allyMember) {
		if(!(defined $HidToNumber{$_})) {
		} elsif($_ == $HcurrentID) {
			$flag = 1;
		} else {
			push(@newAllyMember, $_);
		}
	}
	if($flag) {
		logAllyEnd(islandName($island), $ally->{'name'});
		my @newAlly = ();
		foreach (@{$island->{'allyId'}}) {
			if($_ != $ally->{'id'}) {
				push(@newAlly, $_);
			}
		}
		$island->{'allyId'} = \@newAlly;
		$ally->{'score'} -= $island->{'pts'};
		$ally->{'number'}--;
	} else {
		logAlly(islandName($island), $ally->{'name'});
		push(@newAllyMember, $HcurrentID);
		push(@{$island->{'allyId'}}, $ally->{'id'});
		$ally->{'score'} += $island->{'pts'};
		$ally->{'number'}++;
	}
	$island->{'money'} -= $HcomCost[$HcomAlly];
	$ally->{'memberId'} = \@newAllyMember;
	# 데이터 쓰기
	allyOccupy();
	allySort();
	writeIslandsFile();
	$HislandList = getIslandList($HcurrentID, 0);

	# 개방
	unlock();
	# 맨 위로
	topPageMain();
}

# 결성
sub logMakeAlly {
	my($name, $owner) = @_;
	logHistory("동맹'${HtagName_}${name}${H_tagName}'이${HtagName_}${owner}${H_tagName}에따라${HtagNumber_}결성${H_tagNumber}됩니다.");
}

# 변경
sub logChangeAlly {
	my($oldname, $newname) = @_;
	logHistory("동맹'${HtagName_}${oldname}${H_tagName}'이'${HtagName_}${newname}${H_tagName}'에명칭 변경.");
}

# 해산
sub logDeleteAlly {
	my($name) = @_;
	logHistory("동맹'${HtagName_}${name}${H_tagName}'이${HtagDisaster_}해산!${H_tagDisaster}");
}

# 가입
sub logAlly {
	my($name, $allyName) = @_;
	logHistory("${HtagName_}${name}${H_tagName}이'${HtagName_}${allyName}${H_tagName}'에${HtagNumber_}가입${H_tagNumber}.");
}

# 탈퇴
sub logAllyEnd {
	my($name, $allyName) = @_;
	logHistory("${HtagName_}${name}${H_tagName}이'${HtagName_}${allyName}${H_tagName}'부터${HtagDisaster_}탈퇴!${H_tagDisaster}");
}

#----------------------------------------------------------------------
# 동맹의 결성·변경·해산·가입·탈퇴
#----------------------------------------------------------------------
# 결성·변경·해산·가입·탈퇴
sub newAllyTop {

	my $adminMode = 0;
	# 비밀번호 확인
	if(checkSpecialPassword($HdefaultPassword)) {
		$adminMode = 1;
		$HislandList = getIslandList($Hislands[$HbfieldNumber]->{'id'}, 1);
	}
	# 개방
	unlock();
	my($jsIslandList, $name, $id, $i);
	foreach $i (0..$islandNumber) {
		$name = $Hislands[$i]->{'name'};
		$id = $Hislands[$i]->{'id'};
		$jsIslandList.= "island[$id] = '$name'\;\n";
	}
	my($allyname, $markList, @colorList, @allycolor, $allyList,
		$jsAllyList, $jsAllyIdList, $jsAllyMarkList, $jsAllyColorList);
	my($defaultMark, $defaultAllyId);
	my $n = $HidToAllyNumber{$defaultID};
	if($n eq '') {
		$allyname = '';
		$defaultMark = $Hally[0];
		$defaultAllyId= '';
	} else {
		$allyname = $Hally[$n]->{'name'};
		$defaultMark = $Hally[$n]->{'mark'};
		$defaultAllyId = $Hally[$n]->{'id'};
	}
	foreach (0..$#HallyMark) {
		my $s = '';
		$s = ' SELECTED' if($HallyMark[$_] eq $defaultMark);
		$markList.= "<OPTION VALUE=\"$HallyMark[$_]\"$s>$HallyMark[$_]\n"
	}
	foreach $i (1..6) {
		if($n eq '') {
			$allycolor[$i] = 0;
		} else {
			$allycolor[$i] = substr($Hally[$n]->{'color'}, $i, 1);
		}
		foreach (0..9,A..F) {
			my $s = '';
			$s = ' SELECTED' if($_ eq $allycolor[$i]);
			$colorList[$i].= "<OPTION VALUE=\"$_\"$s>$_\n"
		}
	}
	my $max = 201;
	if($HallyNumber) {
		$jsAllyList = "ally = [";
		$jsAllyIdList = "allyID = [";
		$jsAllyMarkList = "allyMark = [";
		$jsAllyColorList = "allyColor = [";
		foreach (0..$#Hally) {
			my $s = '';
			$s = ' SELECTED' if($Hally[$_]->{'id'} == $defaultAllyId);
			$allyList.= "<OPTION VALUE=\"$_\"$s>$Hally[$_]->{'name'}\n";
			$jsAllyList.= "'$Hally[$_]->{'name'}'";
			$jsAllyIdList.= "$Hally[$_]->{'id'}";
			$jsAllyMarkList.= "'$Hally[$_]->{'mark'}'";
			$jsAllyColorList.= "[";
			foreach $i (1..6) {
				$jsAllyColorList.= '\''. substr($Hally[$_]->{'color'}, $i, 1). '\'';
				$jsAllyColorList.= ',' if($i < 6);
			}
			$jsAllyColorList.= "]";
			if($_ < $#Hally) {
				$jsAllyList.= ",\n";
				$jsAllyIdList.= ",\n";
				$jsAllyMarkList.= ",\n";
				$jsAllyColorList.= ",\n";
			}
			$max = $Hally[$_]->{'id'} + 1 if($max <= $Hally[$_]->{'id'});
		}
		$jsAllyList.= "];\n";
		$jsAllyIdList.= "];\n";
		$jsAllyMarkList.= "];\n";
		$jsAllyColorList.= "];\n";
	}
	my $str1 = $adminMode ? '(점검)' : $HallyJoinComUse ? '' : '·가입·탈퇴';
	my $str2 = $adminMode ? '' : 'onChange=colorPack() onClick=colorPack()';
	my $makeCost = $HcostMakeAlly ? "${HcostMakeAlly}${HunitMoney}" : '무료';
	my $keepCost = $HcostKeepAlly ? "${HcostKeepAlly}${HunitMoney}" : '무료';
	my $joinCost = $HcomCost[$HcomAlly] ? "${$HcomCost[$HcomAlly]}${HunitMoney}" : '무료';
	my $joinStr = $HallyJoinComUse ? '' : "가입·탈퇴의 때의 비용은,${HtagMoney_}$joinCost${H_tagMoney}입니다.<BR>";
	my $str3 = $adminMode ? "특수 비밀번호(필수)<BR>
<INPUT TYPE=\"password\" NAME=\"OLDPASS\" VALUE=\"$HdefaultPassword\" SIZE=32 MAXLENGTH=32 class=f><BR>동맹" : "<span class='attention'>(주의)</span><BR>
동맹의 결성·변경의 비용은,${HtagMoney_}${makeCost}${H_tagMoney}입니다.<BR>
또한, 매 턴 필요한 유지비는${HtagMoney_}$keepCost${H_tagMoney}입니다.<BR>
(유지비는 동맹에 소속된 ${AfterName}이 균등하게 부담합니다)<BR>
$joinStr
</P>
당신의 섬은?(필수)<BR>
<SELECT NAME=\"ISLANDID\" $str2>
$HislandList
</SELECT><BR>당신";

	out(<<END);
<DIV align='center'>$HtempBack</DIV><BR>
<DIV ID='changeInfo'>
<H1>동맹의 결성·변경·해산${str1}</H1>
<table border=0 width=50%><tr><td class="M"><P>
<FORM name="AcForm" action="$HthisFile" method="POST">
$str3
의 비밀번호(필수)<BR>
<INPUT TYPE="password" NAME="PASSWORD" SIZE=32 MAXLENGTH=32 class=f>
END

	if($HallyNumber) {
		my $str4 = $adminMode ? '·결성·변경' : $HallyJoinComUse ? '' : '·가입·탈퇴';
		my $str5 = ($adminMode || $HallyJoinComUse) ? '' : '<INPUT TYPE="submit" VALUE="가입·탈퇴" NAME="JoinAllyButton">';
		out(<<END);
<BR>
<BR><B><FONT SIZE=4>［해산${str4}］</FONT></B>
<BR>도의 동맹입니까?<BR>
<SELECT NAME="ALLYNUMBER" onChange=allyPack() onClick=allyPack()>
$allyList
</SELECT>
<BR>
<INPUT TYPE="submit" VALUE="해산" NAME="DeleteAllyButton">
$str5
<BR>
END
	}

	my $str7 = $adminMode ? "맹주 섬의 변경(상의 메뉴에서 동맹을 선택)<BR>or 동맹 신규 작성(위 메뉴는 무효)<BR><SELECT NAME=\"ALLYID\"><OPTION VALUE=\"$max\">신규작성\n$HislandList</SELECT><BR>" : '<BR><B><FONT SIZE=4>［결성·변경］</FONT></B><BR>';
	out(<<END);
<BR>
$str7
동맹 이름(변경)<small>(최대 ${HlengthAllyName}자)</small><BR>
<INPUT TYPE="text" NAME="ALLYNAME" VALUE="$allyname" SIZE=32 MAXLENGTH=32><BR>
표시(변경)<BR>
<SELECT NAME="MARK" onChange=colorPack() onClick=colorPack()>
$markList
</SELECT>
<ilayer name="PARENT_CTBL" width="100%" height="100%">
 <layer name="CTBL" width="200"></layer>
 <span id="CTBL"></span>
</ilayer>
<BR>
표시의 색코드(변경)<BR><TABLE BORDER=0><TR>
<TD align='center'>RED</TD>
<TD align='center'>GREEN</TD>
<TD align='center'>BLUE</TD>
</TR><TR>
<TD><SELECT NAME="COLOR1" onChange=colorPack() onClick=colorPack()>
$colorList[1]</SELECT><SELECT NAME="COLOR2" onChange=colorPack() onClick=colorPack()>
$colorList[2]</SELECT></TD>
<TD><SELECT NAME="COLOR3" onChange=colorPack() onClick=colorPack()>
$colorList[3]</SELECT><SELECT NAME="COLOR4" onChange=colorPack() onClick=colorPack()>
$colorList[4]</SELECT></TD>
<TD><SELECT NAME="COLOR5" onChange=colorPack() onClick=colorPack()>
$colorList[5]</SELECT><SELECT NAME="COLOR6" onChange=colorPack() onClick=colorPack()>
$colorList[6]</SELECT></TD>
</TR></TABLE>
<INPUT TYPE="submit" VALUE="결성(변경)" NAME="NewAllyButton">
<SCRIPT language="JavaScript">
<!--
END
	if(!$adminMode) {
		out(<<END);
function colorPack() {
	var island = new Array(128);
$jsIslandList
	a = document.AcForm.COLOR1.value;
	b = document.AcForm.COLOR2.value;
	c = document.AcForm.COLOR3.value;
	d = document.AcForm.COLOR4.value;
	e = document.AcForm.COLOR5.value;
	f = document.AcForm.COLOR6.value;
	mark = document.AcForm.MARK.value;
	number = document.AcForm.ISLANDID.value;

	str = "#" + a + b + c + d + e + f;
//	document.AcForm.AcColorValue.value = str;
	str = '표시샘플:'<B><span class="number"><FONT color="' + str +'">' + mark + '</FONT></B>'
	 + island[number] + '${AfterName}</span>'';

	if(document.getElementById){
		document.getElementById("CTBL").innerHTML = str;
	} else if(document.all){
		el = document.all("CTBL");
		el.innerHTML = str;
	} else if(document.layers) {
		lay = document.layers["PARENT_CTBL"].document.layers["CTBL"];
		lay.document.open();
		lay.document.write(str);
		lay.document.close();
	}

	return true;
}
function allyPack() {
$jsAllyList
$jsAllyMarkList
$jsAllyColorList
	document.AcForm.ALLYNAME.value = ally[document.AcForm.ALLYNUMBER.value];
	document.AcForm.MARK.value = allyMark[document.AcForm.ALLYNUMBER.value];
	document.AcForm.COLOR1.value = allyColor[document.AcForm.ALLYNUMBER.value][0];
	document.AcForm.COLOR2.value = allyColor[document.AcForm.ALLYNUMBER.value][1];
	document.AcForm.COLOR3.value = allyColor[document.AcForm.ALLYNUMBER.value][2];
	document.AcForm.COLOR4.value = allyColor[document.AcForm.ALLYNUMBER.value][3];
	document.AcForm.COLOR5.value = allyColor[document.AcForm.ALLYNUMBER.value][4];
	document.AcForm.COLOR6.value = allyColor[document.AcForm.ALLYNUMBER.value][5];
	colorPack();
	return true;
}
END
	} else {
		out(<<END);
function colorPack() {
	var island = new Array(128);
$jsIslandList
	a = document.AcForm.COLOR1.value;
	b = document.AcForm.COLOR2.value;
	c = document.AcForm.COLOR3.value;
	d = document.AcForm.COLOR4.value;
	e = document.AcForm.COLOR5.value;
	f = document.AcForm.COLOR6.value;
	mark = document.AcForm.MARK.value;

	str = "#" + a + b + c + d + e + f;
//	document.AcForm.AcColorValue.value = str;
	str = '표시샘플:'<B><span class="number"><FONT color="' + str +'">' + mark + '</FONT></B>'
	 + '님푸루${AfterName}</span>'';

	if(document.getElementById){
		document.getElementById("CTBL").innerHTML = str;
	} else if(document.all){
		el = document.all("CTBL");
		el.innerHTML = str;
	} else if(document.layers) {
		lay = document.layers["PARENT_CTBL"].document.layers["CTBL"];
		lay.document.open();
		lay.document.write(str);
		lay.document.close();
	}

	return true;
}
function allyPack() {
$jsAllyList
$jsAllyIdList
$jsAllyMarkList
$jsAllyColorList
	document.AcForm.ALLYID.value = allyID[document.AcForm.ALLYNUMBER.value];
	document.AcForm.ALLYNAME.value = ally[document.AcForm.ALLYNUMBER.value];
	document.AcForm.MARK.value = allyMark[document.AcForm.ALLYNUMBER.value];
	document.AcForm.COLOR1.value = allyColor[document.AcForm.ALLYNUMBER.value][0];
	document.AcForm.COLOR2.value = allyColor[document.AcForm.ALLYNUMBER.value][1];
	document.AcForm.COLOR3.value = allyColor[document.AcForm.ALLYNUMBER.value][2];
	document.AcForm.COLOR4.value = allyColor[document.AcForm.ALLYNUMBER.value][3];
	document.AcForm.COLOR5.value = allyColor[document.AcForm.ALLYNUMBER.value][4];
	document.AcForm.COLOR6.value = allyColor[document.AcForm.ALLYNUMBER.value][5];
	colorPack();
	return true;
}
END
	}
	out(<<END);
colorPack();
//-->
</SCRIPT>
</FORM>
</td></tr></table></DIV>
END
}

# 맹주코멘트 모드
sub allyPactMain {
	if (!$HallyPactMode) {
		# 개방
		unlock();
		# 템플릿출력
		tempAllyPactPage();
	} else {
		# 비밀번호 확인
		my $ally = $Hally[$HidToAllyNumber{$HcurrentID}];
		if(checkPassword($ally, $HdefaultPassword)) {

			$HallyComment =~ s/[\x00-\x1f\,]//g;
			$ally->{'comment'} = htmlEscape($HallyComment);
			$ally->{'title'} = htmlEscape($HallyTitle);
			$ally->{'message'} = htmlEscape($HallyMessage, 1);
			# 데이터 쓰기
			writeAllyFile();
			unlock();
			# 변경성공
			tempAllyPactOK($ally->{'name'});
		} else {
			# password 오류
			unlock();
			tempWrongPassword();
			return;
		}
	}
}

# 맹주코멘트 모드의 톱 페이지
sub tempAllyPactPage {
	my $ally = $Hally[$HidToAllyNumber{$HcurrentID}];
	my $allyMessage = $ally->{'message'};
	$allyMessage =~ s/<br>/\n/g;
	$allyMessage =~ s/&amp;/&/g;
	$allyMessage =~ s/&lt;/</g;
	$allyMessage =~ s/&gt;/>/g;
	$allyMessage =~ s/&quot;/\"/g; #"

	out(<<END);
<DIV align='center'>$HtempBack</DIV><BR>
<DIV ID='changeInfo'>
<H1>코멘트 변경($ally->{'name'})</H1>
<table border=0 width=50%><tr><td class="M">
<FORM action="$HthisFile" method="POST">
<B>맹주 비밀번호</B><BR>
<INPUT TYPE="password" NAME="Allypact" VALUE="$HdefaultPassword" SIZE=32 MAXLENGTH=32 class=f>
<INPUT TYPE="hidden" NAME="ISLANDID" VALUE="$ally->{'id'}">
<INPUT TYPE="submit" VALUE="전송" NAME="AllypactButton"><BR>
<B>코멘트</B><small>(최대 ${HlengthAllyComment}자: 톱 페이지의'각 동맹 상황'화면에 표시됩니다)</small><BR>
<INPUT TYPE="text" NAME="ALLYCOMMENT" VALUE="$ally->{'comment'}" SIZE=100 MAXLENGTH=50><BR>
<BR>
<B>메시지·동맹약속등</B>('동맹 정보'란의 화면에 표시됩니다)<BR>
제목<small>(최대 ${HlengthAllyTitle}자)</small><BR>
<INPUT TYPE="text" NAME="ALLYTITLE" VALUE="$ally->{'title'}" SIZE=100 MAXLENGTH=50><BR>
메시지<small>(최대 ${HlengthAllyMessage}자)</small><BR>
<TEXTAREA COLS=50 ROWS=16 NAME="ALLYMESSAGE" WRAP="soft">$allyMessage</TEXTAREA>
<BR>
'제목'을빈칸에하면'맹주의 메시지'라는 제목이 됩니다.<BR>
'메시지'를빈칸에하면'동맹 정보'란에는 아무것도 표시되지 않습니다.
</FORM>
</td></tr></table>
</DIV>
END
}

# 맹주코멘트 변경완료
sub tempAllyPactOK {
	my($name) = @_;
	out(<<END);
${HtagBig_}$name${AfterName}의코멘트를 변경했습니다.${H_tagBig}$HtempBack
END
}

#----------------------------------------------------------------------
# 동맹(진영) 설정
#----------------------------------------------------------------------
sub amitySetupMain() {
	if (!$HasetupMode) {
		# 개방
		unlock();

		# 템플릿출력
		tempAmitySetupPage();
	} else {
		# 비밀번호 확인
		if(checkSpecialPassword($HdefaultPassword)) {
			# 특수 비밀번호
			my($id, $aId);
			foreach (0..$islandNumber) {
				undef $Hislands[$_]->{'allyId'};
			}
			foreach (0..($HallyNumber - 1)) {
				undef $Hally[$_]->{'memberId'};
				undef $Hally[$_]->{'number'};
				undef $Hally[$_]->{'score'};
				my $aId = $Hally[$_]->{'id'};
				if(defined $HidToNumber{$aId}) {
					push(@{$Hally[$_]->{'memberId'}}, $Hally[$_]->{'id'});
					$Hally[$_]->{'score'} += $Hislands[$HidToNumber{$aId}]->{'pts'};
					push(@{$Hislands[$HidToNumber{$aId}]->{'allyId'}}, $aId);
				}
			}
			foreach (@HallyChange) {
				($id, $aId) = split(/-/, $_);
				$Hally[$HidToAllyNumber{$aId}]->{'score'} += $Hislands[$HidToNumber{$id}]->{'pts'};
				next if($id == $aId);
				push(@{$Hally[$HidToAllyNumber{$aId}]->{'memberId'}}, $id);
				push(@{$Hislands[$HidToNumber{$id}]->{'allyId'}}, $aId);
			}
			foreach (0..($HallyNumber - 1)) {
				$Hally[$_]->{'number'} = @{$Hally[$_]->{'memberId'}};
			}
			allyOccupy();
			allySort();
			writeIslandsFile();
			unlock();
			# 변경성공
			tempAmitySetupPage();
		} else {
			# password 오류
			unlock();
			tempWrongPassword();
			return;
		}
	}
}
# 동맹(진영) 설정페이지
sub tempAmitySetupPage() {
	# 개방
	unlock();

	out(<<END);
<DIV align='center'>$HtempBack</DIV><BR>
<DIV ID='campInfo'>
<H1>동맹(진영)소속 설정</H1>
<FORM action="$HthisFile" method="POST">
<INPUT TYPE="hidden" VALUE="$HdefaultPassword" NAME="ASetup">
<TABLE BORDER><TR>
<TH $HbgTitleCell align=center rowspan=2>${HtagTH_} 설정${H_tagTH}<BR><INPUT TYPE="submit" VALUE="변경" NAME="AmityChangeButton"></TH>
END

	foreach (0..$islandNumber) {
		$Hislands[$_]->{'ally'} = $Hislands[$_]->{'allyId'}[0];
	}
	my @idx = (0..$#Hislands);
	@idx = sort {
			$Hislands[$b]->{'field'} <=> $Hislands[$a]->{'field'} || # 전장우선
			$Hislands[$b]->{'ally'} <=> $Hislands[$a]->{'ally'} || # 동맹에서 정렬
			$a <=> $b # $kind가 같으면 이전 순서를 유지
		 } @idx;

	my $aStr = ($HarmisticeTurn) ? '진영' : '동맹';
	out("<TH $HbgTitleCell align=center colspan=$HallyNumber>${HtagTH_}${aStr}${H_tagTH}</TH>") if($HallyNumber);
	out("</TR><TR>\n");
	my($number, $island, $name, $ally);
	foreach (0..($HallyNumber - 1)) {
		$ally = $Hally[$_];
		$name = "<FONT COLOR=\"$ally->{'color'}\"><B>$ally->{'mark'}</B></FONT>$ally->{'name'}";
		out(<<END);
<TD class='T'>$name</TD>
END
	}
	out("</TR>\n");
	foreach (0..$islandNumber) {
		$island = $Hislands[$idx[$_]];
		$name = islandName($island);
		my($id, $amity, %amityFlag, $aId);
		$id = $island->{'id'};
		$amity = $island->{'amity'};
		foreach (@$amity) {
			$amityFlag{$_} = 1;
		}
		out("<TR><TH $HbgTitleCell>$name</TH>");
		for ($i = 0; $i < $HallyNumber; $i++) {
			$ally = $Hally[$i];
			$aId = $ally->{'id'};
			my $member = $Hally[$i]->{'memberId'};
			my $flag = 1;
			foreach (@$member) {
				if($id == $_) {
					$flag = 0;
					last;
				}
			}
			if($flag) {
				out("<TH><input type=checkbox name=ally value=\"$id-$aId\"></TH>");
			} else {
				out("<TH><input type=checkbox name=ally value=\"$id-$aId\" CHECKED></TH>");
			}
		}
		out("</TR>\n");
	}
	out(<<END);
</TABLE><INPUT TYPE="hidden" VALUE="dummy" NAME="AmityChange"></FORM></DIV>
END
}
#----------------------------------------------------------------------
# HTML생성
#----------------------------------------------------------------------
sub logPrintHtml {
	my($sec, $min, $hour, $date, $mon, $year, $day, $yday, $dummy) = gmtime(time + $Hjst);
	$mon++;
	my($sss) = "${mon}월${date}일 ${hour} 때${min}분${sec}초";

	$html1=<<_HEADER_;
<HTML><HEAD><META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
<TITLE>
최근 사건
</TITLE>
<BASE HREF="$htmlDir/">
<link rel="stylesheet" type="text/css" href="${efileDir}/$HcssFile">
</HEAD>
<BODY $htmlBody><DIV ID='BodySpecial'>
<DIV ID='RecentlyLog'>
<H1>최근 사건</H1>
<FORM>
최신갱신일:$sss..
<INPUT TYPE="button" VALUE=" 다시 읽기" onClick="location.reload()">
</FORM>
<hr>
_HEADER_

$html3=<<_FOOTER_;
</DIV><HR></DIV></BODY></HTML>
_FOOTER_
	my($i);
	for($i = 0; $i < $HhtmlLogTurn; $i++) {
		$id =0;
		$mode = 0;
		my($set_turn) = 0;
		open(LIN, "${HdirName}/hakojima.log$i");
		my($line, $m, $turn, $id1, $id2, $message);
		while($line = <LIN>) {
			$line =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),(.*)$/;
			($m, $turn, $id1, $id2, $message) = ($1, $2, $3, $4, $5);

			# 기밀관계
			if($m) {
				next if(!$mode || ($id1 != $id)); # 기밀 표시 권한 없음
				$m = '<B>(기밀)</B>';
			} else {
				$m = '';
			}

			# 정확히 표시할지
			if($id) {
				next if(($id != $id1) && ($id != $id2));
			}

			# 표시
			if(!$set_turn){
				if(!$Hseason) {
					$html2.= "<B>=====[<span class=number><FONT SIZE=4> 턴$turn </FONT></span>]================================================</B><BR>\n";
				} else {
					# 계절의 표시
					my @seasonName = ('<span class=winter>겨울</span>','<span class=spring>봄</span>','<span class=summer>여름</span>','<span class=autumn>가을</span>');
					my $month = ($turn % 12) + 1;
					my $year = ($turn / 12) + 1;
					my $calender = sprintf('<span class=month><FONT SIZE=2><small>%s</small> %d년 %d월 </FONT></span>', $Halmanac, $year, $month);
					$calender.= "<span class='season'>$seasonName[int(($month - 1) / 3)]</span>";
					$html2.= "<B>=====[<span class=number><FONT SIZE=4> <small>턴$turn</small> </FONT></span>]=============================$calender</B><BR>\n";
				}
				$set_turn++;
			}
			$html2.= "${HtagNumber_}★${H_tagNumber}:$message<BR>\n";
		}
		close(LIN);
	}
	open(HTML, ">${HhtmlDir}/hakolog.html");
#	print HTML $html1;
#	print HTML $html2;
#	print HTML $html3;
	print HTML $html1;
	print HTML $html2;
	print HTML $html3;
	close (HTML);
	chmod(0666,"${HhtmlDir}/hakolog.html");
}
#----------------------------------------------------------------------
# 순위
#----------------------------------------------------------------------
sub rankIslandMain {
	my $i;
	foreach $i (0..$islandNumber) {
		my $rena = $Hislands[$i]->{'rena'}; # 군사력
		$Hislands[$i]->{'renae'} = int($rena / 10 ) + 1;

		my($sto, $std, $stk, $stwin, $stdrow, $stlose, $stwint, $stdrowt, $stloset, $styusho, $stshoka) = split(/,/, $Hislands[$i]->{'eisei4'});
		$Hislands[$i]->{'kachiten'} = $stwin*3 + $stdrow;
		$Hislands[$i]->{'kachitent'} = $stwint*3 + $stdrowt;
		my $siaisu = $stwint + $stdrowt + $stloset;
		$siaisu = 1 if($siaisu == 0);
		$Hislands[$i]->{'shoritu'} = int($stwint / $siaisu * 100);
		$Hislands[$i]->{'teamforce'} = $sto + $std + $stk;
		$Hislands[$i]->{'styusho'} = $styusho;

		my($mshp, $msap, $msdp, $mssp) = (split(/,/, $Hislands[$i]->{'eisei5'}))[0..3];
		$Hislands[$i]->{'force'} = $mshp + $msap + $msdp + $mssp;

		foreach (split(/,/, $Hislands[$i]->{'eisei6'})) {
			$Hislands[$i]->{'tuni'} += $_;
			$Hislands[$i]->{'uni'}++ if($_> 0);
		}
	}

	my @elements = ( 'pop', 'farm', 'factory', 'mountain', 'fore', 'tare', 'zipro', 'leje', 'monsterlive', 'taiji', 'monta', 'hamu', 'pika', 'kei', 'renae', 'force', 'eisei2', 'uni', 'teamforce', 'styusho', 'shoritu', 'kachitent', 'kachiten');
	my $hcturn = int($HislandTurn/100) * 100;
	my @bumonName = ('인구', '농장', '직장', '채굴장', '숲', '닭 수', '돼지 수', '소 수', '괴수출현 수', '괴수퇴치 수', '성장도', '인구증가', '수입', '기념비 수', '군사 기술', '생물 대학 능력', '통산 관광객', '유니크 지형 수', '축구팀력', 'HC 우승횟수', 'HC 통산승률', 'HC 통산승점', "HC${hcturn} 승점");
	my @islands;
	my @ids;
	$i = 0;
	foreach (@elements) {
		$islands{$_} = $Hislands[$HidToNumber{$HrankingID[$i]}];
		$ids{$_} = $islands{$_}->{'id'};
		$i++;
	}
	my $tuni = $islands{'uni'}->{'tuni'};
	my($kstwin, $kstdrow, $kstlose) = (split(/,/, $islands{'kachiten'}->{'eisei4'}))[3..5]; #
	my($ktstwint, $ktstdrowt, $ktstloset) = (split(/,/, $islands{'kachitent'}->{'eisei4'}))[6..8]; #
	my($rstwint, $rstdrowt, $rstloset) = (split(/,/, $islands{'shoritu'}->{'eisei4'}))[6..8]; #
	my @bBeforeName = ('', '', '', '', '', '', '', '', '','', '전 턴+', '전 턴+', '전 턴+', '', 'Lv', '합계', '', '', '합계', '', '', '승점', '승점');
	my @bAfterName = ("$HunitPop", "0$HunitPop 규모", "0$HunitPop 규모", "0$HunitPop 규모", "$HunitTree", '만 마리', '만 두', '만 두', "$HunitMonster","$HunitMonster", 'pts.', "$HunitPop", "$HunitMoney", '케장소', "", 'pts.', "$HunitPop", "종류/$tuni 케장소", 'pts.', '회', "%($rstwint 승$rstloset 패$rstdrowt 분)", "($ktstwint 승$ktstloset 패$ktstdrowt 분)", "($kstwin 승$kstlose 패$kstdrow 분)");

	# 개방
	unlock();

	out(<<END);
<DIV ID='Ranking'>
<H1>각부문별도 NO.1</H1>
<P>
목표는 <B>ALL NO.1</B>!! 클릭하면,<B>관광</B>할 수 있습니다.
</P>
END

	foreach (0..$#elements) {
		my $id = $islands{$elements[$_]}->{'id'};
		my $name = islandName($islands{$elements[$_]});
		my $element = $islands{$elements[$_]}->{$elements[$_]};

		out("<TABLE ALIGN=\"center\" width=\"100%\"><TR>\n") if(!($_ % 5));
		out(<<END);
<td width="9%">
<TABLE BORDER=1 width="100%">
<TR><TD class="RankingCell" ALIGN="center" COLSPAN="2">
<span class="bumon">${bumonName[$_]}NO.1</span></TD></TR>
END

		if(($element ne '') && ($element != 0)) {
			out(<<END);
<TR><TD ALIGN="center"><A STYlE="text-decoration:none" HREF="${HthisFile}?Sight=${id}" alt="ID=${id}" title="ID=${id}">${HtagName_}${name}${H_tagName}</TD></TR>
<TR><TD ALIGN="center">${bBeforeName[$_]}${element}${bAfterName[$_]}</TD></TR>
</TABLE></TD>
END
		} else {
			out(<<END);
<TR><TD ALIGN="center">${HtagName_} - ${H_tagName}</TD></TR>
<TR><TD ALIGN="center"> - </TD></TR>
</TABLE></TD>
END
		}
		out("</TR></TABLE>\n") if(!(($_ + 1) % 5));
	}
	out("</TR></TABLE>\n") if((($#elements + 1) % 5));
	out("</DIV>\n");
}
#----------------------------------------------------------------------
# 역대인구기록
#----------------------------------------------------------------------
# 메인
sub rekidaiPopMain {
	my($flag, $line, $j, $id, $pop, $turn, $name, $n, @rekidai, $reki, $oldpop);
	$flag = 0;
	if(!open(RIN, "<${HdirName}/rekidai.dat")) {
		rename("${HdirName}/rekidai.tmp", "${HdirName}/rekidai.dat");
		if(!open(RIN, "<${HdirName}/rekidai.dat")) {
			$flag = 1;
		}
	}
	if(!$flag) {
		$n = 0;
		while($line = <RIN>) {
			$line =~ /^([0-9]*),([0-9]*),([0-9]*),(.*)$/;
			($id, $pop, $turn, $name) = ($1, $2, $3, $4);
			$rekidai[$n]->{'id'} = $id;
			$rekidai[$n]->{'pop'} = $pop;
			$rekidai[$n]->{'turn'} = $turn;
			$rekidai[$n]->{'name'} = $name;
			$n++;
		}
		close(RIN);
	}
	# 개방
	unlock();

	out(<<END);
<CENTER>$HtempBack</CENTER><BR>
<DIV ID='Successive'>
<H1>역대 최다인구기록</H1>
<table border=0 width=50%><tr>
<TH $HbgTitleCell align=center>${HtagTH_}순위${H_tagTH}</TH>
<TH $HbgTitleCell align=center>${HtagTH_}${AfterName}이름${H_tagTH}</TH>
<TH $HbgTitleCell align=center>${HtagTH_}인구${H_tagTH}</TH>
<TH $HbgTitleCell align=center>${HtagTH_}턴${H_tagTH}</TH>
END
	if(!$flag) {
		$j = 0;
		$n = 1;
		$oldpop = 0;
		$pop = 0;
		while(($j < 10) || $flag) {
			$reki = $rekidai[$j];
			last unless(defined $reki->{'pop'});
			$oldpop = $pop;
			($id, $pop, $turn, $name) = ($reki->{'id'}, $reki->{'pop'}, $reki->{'turn'}, $reki->{'name'});
			if(defined $HidToNumber{$id}) {
				$name = "<A STYlE=\"text-decoration:none\" HREF=\"${HthisFile}?Sight=${id}\" alt=\"ID=${id}\" title=\"ID=${id}\">${HtagName_}$name${AfterName}${H_tagName}</A>";
			} else {
				$name = "${HtagName2_}$name${AfterName}${H_tagName2}";
			}
			$j++;
			$n = $j if($oldpop> $pop);
			$reki = $rekidai[$j];
			$flag =0 unless(defined $reki->{'pop'});
			if($reki->{'pop'} < $pop) {
				$flag =0;
			} else {
				$flag =1;
			}
			out(<<END);
</tr><tr>
<TD $HbgNumberCell align=right>${HtagNumber_}$n${H_tagNumber}</TD>
<TD $HbgNameCell align=right>$name</TD>
<TD $HbgInfoCell align=right>$pop${HunitPop}</TD>
<TD $HbgInfoCell align=right>$turn</TD>
END
		}
	} else {
		out(<<END);
</tr><tr><TH colspan=4>데이터 없습니다!</TH>
END
	}
		out(<<END);
</tr></table></DIV>
END
}
#----------------------------------------------------------------------
# HakoniwaCup 전쟁실적
#----------------------------------------------------------------------
# 메인
sub hcdataMain {
	foreach $i (0..$islandNumber) {
		my @hcdata = split(/,/, $Hislands[$i]->{'eisei4'});
		$Hislands[$i]->{'hcdata'} = \@hcdata;
		if($hcdata[10]>= 10) {
			$Hislands[$i]->{'hcover'} = 1;
		}
		if($hcdata[3] + $hcdata[4] + $hcdata[5]> 4) {
			$Hislands[$i]->{'hctmnt'} = $hcdata[3] + $hcdata[4] + $hcdata[5];
		}
	}
	my @HCislands = @Hislands;
	my @idx = (0..$#Hislands);
	@idx = sort { $Hislands[$a]->{'field'} <=> $Hislands[$b]->{'field'} ||
					$Hislands[$a]->{'hcover'} <=> $Hislands[$b]->{'hcover'} ||
					$Hislands[$b]->{'hctmnt'} <=> $Hislands[$a]->{'hctmnt'} ||
					$Hislands[$b]->{'hcdata'}[10] <=> $Hislands[$a]->{'hcdata'}[10] ||
					$Hislands[$b]->{'hcdata'}[3] <=> $Hislands[$a]->{'hcdata'}[3] ||
					$Hislands[$b]->{'hcdata'}[4] <=> $Hislands[$a]->{'hcdata'}[4] ||
					$Hislands[$a]->{'hcdata'}[5] <=> $Hislands[$b]->{'hcdata'}[5] ||
					$Hislands[$b]->{'hcdata'}[6] <=> $Hislands[$a]->{'hcdata'}[6] ||
					$Hislands[$b]->{'hcdata'}[7] <=> $Hislands[$a]->{'hcdata'}[7] ||
					$Hislands[$a]->{'hcdata'}[8] <=> $Hislands[$b]->{'hcdata'}[8] ||
					$a <=> $b
				} @idx;
	@HCislands = @HCislands[@idx];
	my $hcturn = int($HislandTurn/100)*100;
	my($turn1, $str);
	my $turn = $HislandTurn%100;
#	if((0 <= $turn) && ($turn <= 40)) {
#		$turn1 = int(($turn + 9) / 10);
#	} elsif($turn == 41) {
#		$turn1 = 5;
#	} elsif((41 < $turn) && ($turn <= 45)) {
#		$turn1 = 6;
#	} elsif((45 < $turn) && ($turn <= 48)) {
#		$turn1 = 7;
#	} elsif((48 < $turn) && ($turn < 50)) {
#		$turn1 = 8;
#	} else {
#		$turn1 = 9;
#	}
#	if($turn1 == 9) {
#		$str = '[최종결과]';
#	} elsif($turn1 == 8) {
#		$str = '[결승전]';
#	} elsif($turn1 == 7) {
#		$str = '[준결승전]';
#	} elsif($turn1 == 6) {
#		$str = '[준준결승전]';
#	} elsif($turn1 == 5) {
#		$str = '[결승 토너먼트시작!]';
#	} else {
#		$str = '[예선]';
#	}
	# 개방
	unlock();

	out(<<END);
<CENTER>$HtempBack</CENTER><BR>
<DIV ID='Successive'>
<H1>HakoniwaCup $hcturn 전쟁실적<BR>${str}</H1>
<table border=0 width=50%><TR>
<TH $HbgTitleCell align=center rowspan=2>${HtagTH_}순위${H_tagTH}</TH>
<TH $HbgTitleCell align=center rowspan=2>${HtagTH_}${AfterName}이름${H_tagTH}</TH>
<TH $HbgTitleCell align=center rowspan=2>${HtagTH_}승${H_tagTH}</TH>
<TH $HbgTitleCell align=center rowspan=2>${HtagTH_}부담${H_tagTH}</TH>
<TH $HbgTitleCell align=center rowspan=2>${HtagTH_}분${H_tagTH}</TH>
<TH $HbgTitleCell align=center colspan=4>${HtagTH_}합계${H_tagTH}</TH>
<TH $HbgTitleCell align=center colspan=3>${HtagTH_}능력${H_tagTH}</TH>
</TR><TR>
<TH $HbgTitleCell align=center>${HtagTH_}우승횟수${H_tagTH}</TH>
<TH $HbgTitleCell align=center>${HtagTH_}승${H_tagTH}</TH>
<TH $HbgTitleCell align=center>${HtagTH_}부담${H_tagTH}</TH>
<TH $HbgTitleCell align=center>${HtagTH_}분${H_tagTH}</TH>
<TH $HbgTitleCell align=center>${HtagTH_}공격${H_tagTH}</TH>
<TH $HbgTitleCell align=center>${HtagTH_}수비 준비${H_tagTH}</TH>
<TH $HbgTitleCell align=center>${HtagTH_}키파${H_tagTH}</TH>
</TR>
END
	my %hcLog = hclogSet();
	my $n = 0;
	foreach $i (0..$islandNumber) {
		my $hcdata = $HCislands[$i]->{'hcdata'};
		my($sto,$std,$stk,$stwin,$stdrow,$stlose,$stwint,$stdrowt,$stloset,$styusho,$stshoka) = @$hcdata;
		next if($stshoka == 0);
#		next if($stwin + $stdrow + $stlose == 0);
		$n++;
		my $juni = $n;
#		if(($turn1>= 5) && ($n> 8)) {
#			$juni = '예선 탈락';
#		} elsif(($turn1> 6) && ($n> 4)) {
#			$juni = '베스와8';
#		} elsif(($turn1> 7) && ($n> 2)) {
#			$juni = '베스와4';
#		} elsif($turn1> 8) {
#			if($n == 1) {
#				$juni = '우승';
#			} elsif($n == 2) {
#				$juni = '준우승';
#			}
#		}
		my $id = $HCislands[$i]->{'id'};
		my $name = islandName($HCislands[$i]);
		my $kekka = $hcLog{$name};
		$kekka = ' ' if($kekka eq '');
		$name = "<A STYlE=\"text-decoration:none\" HREF=\"${HthisFile}?Sight=${id}\" alt=\"ID=${id}\" title=\"ID=${id}\">${HtagName_}$name${H_tagName}</A>";
		out("<TR><TH></TH></TR>") if($n == 9);
		out(<<END);
<tr>
<TD $HbgNumberCell align=right rowspan=2>${HtagNumber_}$juni${H_tagNumber}</TD>
<TD $HbgNameCell align=right rowspan=2>$name</TD>
<TD $HbgPoinCell align=right rowspan=2>${HtagWin_}$stwin${H_tagWin}</TD>
<TD $HbgInfoCell align=right rowspan=2>${HtagLose_}$stlose${H_tagLose}</TD>
<TD $HbgInfoCell align=right rowspan=2>$stdrow</TD>
<TD $HbgInfoCell align=right>$styusho</TD>
<TD $HbgInfoCell align=right>$stwint</TD>
<TD $HbgInfoCell align=right>$stloset</TD>
<TD $HbgInfoCell align=right>$stdrowt</TD>
<TD $HbgInfoCell align=right>$sto</TD>
<TD $HbgInfoCell align=right>$std</TD>
<TD $HbgInfoCell align=right>$stk</TD>
</tr>
<tr>
<TD $HbgTotoCell align=left colspan=7>$kekka</TD>
</tr>
END
	}
	if(!$n) {
		out(<<END);
<tr><TH colspan=12>데이터 없습니다!</TH></tr>
END
	}
	out(<<END);
</table>
참고: 다목적경기장 데이터가 초기화된 경우,<BR>실제 시뮬레이션 결과와 순위가 다를 수 있습니다. 양해 부탁드립니다..
</DIV>
END
}

# 대전 표시
sub hclogSet {
	my($line, $turn, $message);
	my %hcLog;
	if(!open(LIN, "${HdirName}/hakojima.lhc")) {
		return %hcLog;
	}
	while($line = <LIN>) {
		chomp($line);
		($turn, $message) = split(/,/, $line);
		next unless($message =~ /^<span class="islName">Hakoniwa Cup (.*)<\/span>,(.*)$/);
		my ($no, $kekka) = ($1, $2);
		next unless($kekka =~ /^<span class="([\w]*)">(.*) 섬 대표<\/span><B>VS<\/B><span class="([\w]*)">(.*) 섬 대표<\/span> ⇒ (.*)$/);
		my($wl1, $name1, $wl2, $name2, $score) = ($1, $2, $3, $4, $5);
		if($no !~ /결승/) {
			$score =~ /^<span class="([\w]*)">([0-9]*)<\/span><B>-<\/B><span class="([\w]*)">([0-9]*)<\/span>$/;
			$hcLog{$name1} = '예선' if($hcLog{$name1} eq '');
			$hcLog{$name2} = '예선' if($hcLog{$name2} eq '');
			$hcLog{$name1}.= " <span class=\"$wl1\"><a title=\"$no($2-$4)\">$name2 섬</a></span>";
			$hcLog{$name2}.= " <span class=\"$wl2\"><a title=\"$no($2-$4)\">$name1 섬</a></span>";
		} else {
			if($no =~ /준준결승/) {
				$hcLog{$name1}.= "\n<BR>";
				$hcLog{$name2}.= "\n<BR>";
			}
			$score =~ /^<span class="([\w]*)">([0-9]*)<\/span><B>-<\/B><span class="([\w]*)">([0-9]*)<\/span>$/;
			$hcLog{$name1}.= " <B>${no}vs</B><span class=\"$wl1\"><a title=\"$no($2-$4)\">$name2 섬</a></span>";
			$hcLog{$name2}.= " <B>${no}vs</B><span class=\"$wl2\"><a title=\"$no($2-$4)\">$name1 섬</a></span>";
		}
	}

	close(LIN);
	return %hcLog;
}

#----------------------------------------------------------------------
# 새 섬을 탐색
#----------------------------------------------------------------------
# 메인
sub newIslandTop {
	# 개방
	unlock();

	# 관리자만 새 섬을 탐색하게 함?
	if ($HadminJoinOnly) {
		# 마스터 비밀번호 확인
		unless (checkMasterPassword($HinputPassword)) {
			# password 오류
			tempWrongPassword();
			return;
		}
	}

	out(<<END);
<CENTER>$HtempBack</CENTER><BR>
<DIV ID='newIsland'>
<H1>새 ${AfterName}을 탐색</H1>
END

	if(($HislandNumber - $HbfieldNumber < $HmaxIsland) && ($HmaxIsland <= 100) && (!$HarmisticeTurn || $HallyNumber)) {
		out(<<END);
<FORM action="$HthisFile" method="POST">
END
		if ($HcampSelectRule == 2) {
			my $allyList;
			foreach (0..$#Hally) {
				next if ($Hally[$_]->{'number'}>= ($HmaxIsland / $HallyNumber));
				my $s = '';
				$s = ' SELECTED' if($_ == 0);
				$allyList.= "<OPTION VALUE=\"$_\"$s>$Hally[$_]->{'name'}\n";
			}
			out(<<END);
진영 이름을 선택해 주세요<BR>
<SELECT NAME="CAMPNUMBER">
$allyList
<OPTION VALUE=\"-1\">어디든 가능
</SELECT><BR>
END
		}
		out(<<END);
섬 이름<small>(최대 ${HlengthIslandName}자)</small><BR>
<INPUT TYPE="text" NAME="ISLANDNAME" SIZE=32 MAXLENGTH=32>${AfterName}<BR>
당신의 이름은?<small>(최대 ${HlengthOwnerName}자)</small><BR>
<INPUT TYPE="text" NAME="OWNERNAME" SIZE=32 MAXLENGTH=32><BR>
비밀번호<BR>
<INPUT TYPE="password" NAME="PASSWORD" SIZE=32 MAXLENGTH=32><BR>
비밀번호 재확인<BR>
<INPUT TYPE="password" NAME="PASSWORD2" SIZE=32 MAXLENGTH=32><BR>

<INPUT TYPE="submit" VALUE="찾으러 가기" NAME="NewIslandButton">
</FORM>
</DIV>
END
	} else {
	out(<<END);
		${AfterName}의 수가 최대 수입니다... 현재 등록할 수 없습니다.
</DIV>
END
	}
}

#----------------------------------------------------------------------
# 섬 이름과 비밀번호 변경
#----------------------------------------------------------------------
# 메인
sub renameIslandMain {
	# 개방
	unlock();

	out(<<END);
<CENTER>$HtempBack</CENTER><BR>
<DIV ID='changeInfo'>
<H1>${AfterName}이름과 비밀번호 변경</H1>
<table border=0 width=50%><tr><td class="M"><P>
(주의) ${AfterName} 이름 변경에는 $HcostChangeName${HunitMoney}이 들어갑니다.
</P>
<FORM action="$HthisFile" method="POST">
어느 ${AfterName}입니까?<BR>
<SELECT NAME="ISLANDID">
$HislandList
</SELECT>
<BR>
새 이름을 입력하세요(변경하는 경우만)<small>(최대 ${HlengthIslandName}자)</small><BR>
<INPUT TYPE="text" NAME="ISLANDNAME" SIZE=32 MAXLENGTH=32>${AfterName}<BR>
당신의 이름을 변경할까요?(변경하는 경우만)<small>(최대 ${HlengthOwnerName}자)</small><BR>
<INPUT TYPE="text" NAME="OWNERNAME" SIZE=32 MAXLENGTH=32><BR>
비밀번호(필수)<BR>
<INPUT TYPE="password" NAME="OLDPASS" SIZE=32 MAXLENGTH=32><BR>
새 비밀번호(변경할 경우만)<BR>
<INPUT TYPE="password" NAME="PASSWORD" SIZE=32 MAXLENGTH=32><BR>
비밀번호 재확인(변경할 경우만)<BR>
<INPUT TYPE="password" NAME="PASSWORD2" SIZE=32 MAXLENGTH=32><BR>
<INPUT TYPE="submit" VALUE="변경" NAME="ChangeInfoButton">
</FORM>
</td></tr></table></DIV>
END
}

#----------------------------------------------------------------------
# 이미지 경로 설정
#----------------------------------------------------------------------
# 메인
sub localImgMain {

	my($Himfflag);
	$Himfflag = $HimageDir;
	# 개방
	unlock();

	out(<<END);
<CENTER>$HtempBack</CENTER><BR>
<DIV ID='localImage'>
<H1>이미지 경로 설정</H1>
<table border width=50%><tr><td class='N'>
 이미지전송에 한서버로의 부하를 경감하다만에서 없이, 당신의 PC 에 있예미지를 호출출스이므로, 표시속도가비도약적에업로합니다.<br>
 이미지는<B><a href="$localImg">여기</a></B>에서 다운로드하고,1개의 폴더에압축 해제시, 아래의 설정에서'land0.gif'을지정해 주세요.<br>
 자세한 내용은<B><a href="$imageExp">설명의 페이지</a></B>을 확인해 주세요.
</td></tr></table>
<table border=0 width=50%><tr><td class="M">
현재 설정<B>[</b> ${Himfflag} <B>]</B>
<form action=$HthisFile method=POST>
<INPUT TYPE=file NAME="IMGLINE">
<INPUT TYPE="submit" VALUE="설정" name=IMGSET>
</form>

<form action=$HthisFile method=POST>
Mac 사용자용<BR>
<INPUT TYPE=text NAME="IMGLINEMAC">
<INPUT TYPE="submit" VALUE="설정" name=IMGSET><BR>
<FONT SIZE=-1>Mac 사용자는, 여기를 사용해 주세요.</FONT>
</form>

<form action=$HthisFile method=POST>
<INPUT TYPE=hidden NAME="IMGLINE" value="deletemodenow">
<INPUT TYPE="submit" VALUE="설정 해제" name=IMGSET>
</form>
</td></tr></table>
</DIV>
END
}

#----------------------------------------------------------------------
# 하코니와 스킨의 설정
#----------------------------------------------------------------------
# 메인
sub hakoSkinMain {

	my($Hskinflag);
	if($HskinName eq '' || $HskinName eq "${efileDir}/$HcssFile"){
		$Hskinflag = '<span class=attention>미설정</span>';
	} else {
		$Hskinflag = $HskinName;
	}

	opendir(DIN, "$HefileDir/$HcssDir/");
 my($skinName, @skinlist);
 while($skinName = readdir(DIN)) {
		next if($skinName =~ /^\./);
		push(@skinlist, $skinName);
 }
 closedir(DIN);

	my $select_list = "<OPTION value='del' selected>기본값\n";
	foreach (@skinlist) {
		$select_list.= "<OPTION>$_\n";
	}


	# 개방
	unlock();

	out(<<END);
<CENTER>$HtempBack</CENTER><BR>
<DIV ID='hakoSkin'>
<H1>하코니와 스킨의 설정</H1>
<table border width=50%><tr><td class='N'>
 하코니와 스킨을 변경하고, 오원하는 인타페이스에!<br>
 기분 전환용으로 이용해 주세요. m(_ _)m
</td></tr></table>
<table border=0 width=50%><tr><td class="M">
현재 설정<B>[</b> ${Hskinflag} <B>]</B>
<form action=$HthisFile method=POST>
<SELECT NAME="SKIN">$select_list</SELECT>
<INPUT TYPE="submit" VALUE="설정" name=SKINSET>
</form>

<form action=$HthisFile method=POST>
<INPUT TYPE=hidden NAME="SKIN" value="del">
<INPUT TYPE="submit" VALUE="설정 해제" name=SKINSET>
</form>
</td></tr></table>
</DIV>
END
}

#----------------------------------------------------------------------

# 인구기타의 값을 산출(축소판)
sub estimate {
	my($number) = $_[0];
	my($island);
	my($pop, $area, $missiles, $fore) = (0, 0, 0, 0);

	# 지형을 가져옴
	$island = $Hislands[$number];
	my($land) = $island->{'land'};
	my($landValue) = $island->{'landValue'};

	# 수 가능
	my($x, $y, $kind, $value);
	foreach $y (0..$islandSize) {
		foreach $x (0..$islandSize) {
			$kind = $land->[$x][$y];
			$value = $landValue->[$x][$y];
			if($kind != $HlandSea) {
				$area++;
				if($kind == $HlandTown) {
					# 읍
					$pop += $value;
				} elsif($kind == $HlandForest) {
					$fore += $value;
				}
			}

			if ($kind == $HlandBase) {
				$missiles++;
			}
		}
	}

	# 대입
	$island->{'pop'}		= $pop;
	$island->{'area'}		= $area;
	$island->{'missiles'}	= $missiles; # 미사일 발사 가능 횟수
	$island->{'fore'}		= $fore;

	# 실업자 수
	$island->{'unemployed'} = $pop;

	# 종합 Point
	$island->{'pts'} = int($pop + $island->{'money'}/100 + $island->{'food'}/100 + $area*5);

}

# 범위 안의 지형을 수 가능(복사)(New)
sub countAround {
	my($land, $x, $y, $range, @kind) = @_;
	my($sea, $count, $sx, $sy, @list);
	foreach (@kind){
		$list[$_] = 1;
	}
	$sea = 0;
	$count = 0;
	$range--;
	foreach(0..$range) {
		$sx = $x + $ax[$_];
		$sy = $y + $ay[$_];

		# 행 기준 위치 조정
		$sx-- if(!($sy % 2) && ($y % 2));

		if(($sx < 0) || ($sx> $islandSize) || ($sy < 0) || ($sy> $islandSize)){
			# 범위 밖의 경우
			# 바다에가 산
			$sea++;
		} elsif($list[$land->[$sx][$sy]]) {
			# 범위 안의 경우
			$count++;
		}
	}
	$count += $sea if($list[$HlandSea]); # 바다이면 가 산
	return $count;
}

#----------------------------------------------------------------------
# 관리자 모드
#----------------------------------------------------------------------
# 섬의 강제 삭제(정보 변경에서)
sub deleteIsland {
	my($num) = @_;
	my($island) = $Hislands[$HidToNumber{$HcurrentID}];

	my $aNum = $HidToAllyNumber{$HcurrentID};
	if(defined $aNum) {
		logDeleteAlly($Hally[$aNum]->{'name'});
		$Hally[$aNum]->{'dead'} = 1;
		$HallyNumber--;
	}
	foreach (@{$island->{'allyId'}}) {
		my $ally = $Hally[$HidToAllyNumber{$_}];
		my $allyMember = $ally->{'memberId'};
		my @newAllyMember = ();
		foreach (@$allyMember) {
			if(!(defined $HidToNumber{$_})) {
			} elsif($_ == $HcurrentID) {
				$ally->{'score'} -= $island->{'pts'};
				$ally->{'number'}--;
			} else {
				push(@newAllyMember, $_);
			}
		}
		$ally->{'memberId'} = \@newAllyMember;
	}
	# 섬 테이블 조작
	$island->{'dead'} = 1;
	$island->{'pts'} = 0;
	$island->{'pop'} = 0;
	$island->{'field'} = 0;

	allyOccupy();
	allySort();
	islandSort('pts');

	logDeleteIsland($tmpid, $island->{'name'}) if($num);

	# 메인 데이터의 조작
	$HislandNumber--;
	$islandNumber--;
	writeIslandsFile($HcurrentID);

	unlink("${HdirName}/${HcurrentID}.${HsubData}");
	unlock();
	tempDeleteIsland($island->{'name'});
}

# BattleField 작성 모드
sub bfieldMain {
	if (!$HbfieldMode) {
		# 개방
		unlock();

		# 템플릿출력
		tempBfieldPage();
	} else {
		# 비밀번호 확인
		if(checkSpecialPassword($HdefaultPassword)) {
			# 특수 비밀번호

			# id에서 섬을 가져옴
			$HcurrentNumber = $HidToNumber{$HcurrentID};
			my($island) = $Hislands[$HcurrentNumber];
			my($name) = islandName($island);
			my($id) = $island->{'id'};

			my $bId, $str;
			my $safety = 0;
			if($id < 100) {
				if ($HbfieldNumber> 9) {
					# Battle Field 의 수가 최대(최대에서10)
					tempBfieldNG("최대 등록 수 초과");
					unlock();
					return;
				}

				# 설정
				for($bId = 101; $bId <= 120; $bId++) {
					last if(!(defined $HidToNumber{$bId}));
				}
				$island->{'id'} = $bId;
				$str = "일반 섬 → Battle Field";
			} else {
				if ($HislandNumber - $HbfieldNumber>= $HmaxIsland) {
					# 일반 섬의 수가 최대
					tempBfieldNG("${AfterName}이가득");
					unlock();
					return;
				}
				# 해제
				while(defined $HidToNumber{$HislandNextID}) {
					$HislandNextID ++;
					$HislandNextID = 1 if($HislandNextID> 100);
					$safety++;
					last if($safety == 100);
				}
				$island->{'id'} = $HislandNextID;
				$HislandNextID ++;
				$HislandNextID = 1 if($HislandNextID> 100);
				$str = "Battle Field → 일반 섬";
			}

			if (($bId> 121) || ($safety == 100)) {
				# 변경을 위해 ID 설정 가능
				tempBfieldNG("ID 시쿠오류");
				unlock();
				return;
			}
			# 데이터 쓰기
			writeIslandsFile($HcurrentID);
			rename("${HdirName}/${id}.${HsubData}", "${HdirName}/${island->{'id'}}.${HsubData}");

			unlock();

			# 변경성공
			tempBfieldOK($name, $str);
		} else {
			# password 오류
			unlock();
			tempWrongPassword();
			return;
		}
	}
}

# BattleField 작성 모드의 톱 페이지
sub tempBfieldPage {
	out(<<END);
<CENTER>$HtempBack</CENTER>
<H1>Battle Field 작성</H1>

<FORM action="$HthisFile" method="POST">
<B>Battle Field 설정을 변경${AfterName}은?</B><BR>
<SELECT NAME="ISLANDID">
$HislandList
</SELECT>
<INPUT TYPE="hidden" VALUE="$HdefaultPassword" NAME="Bfield">
<INPUT TYPE="submit" VALUE="설정 변경" NAME="BfieldButton"><BR>
</FORM>
END
}

# BattleField 작성완료
sub tempBfieldOK {
	my($name, $str) = @_;
	out(<<END);
${HtagBig_}$name${AfterName}의 Battle Field 설정을 변경했습니다.<br>$str${H_tagBig}$HtempBack
END
}

# BattleField 작성실패
sub tempBfieldNG {
	my($str) = @_;
	out(<<END);
${HtagBig_}Battle Field 의 설정오류($str).${H_tagBig}$HtempBack
END
}

# 관리자가 지급한 선물 모드
sub presentMain {
	if (!$HpresentMode) {
		# 개방
		unlock();

		# 템플릿출력
		tempPresentPage();
	} else {
		# 비밀번호 확인
		if(checkSpecialPassword($HoldPassword)) {
			# 특수 비밀번호

			if (!$HpresentMoney && !$HpresentFood) {
				# 금도식량도 없음
				tempPresentEmpty();
				unlock();
				return;
			}

			# id에서 섬을 가져옴
			$HcurrentNumber = $HidToNumber{$HcurrentID};
			my($island) = $Hislands[$HcurrentNumber];
			my($name) = islandName($island);

			$island->{'money'} += $HpresentMoney;
			$island->{'money'} = 0 if ($island->{'money'} < 0);
			$island->{'food'} += $HpresentFood;
			$island->{'food'} = 0 if ($island->{'food'} < 0);

			logPresent($HcurrentID, $name, $HpresentLog);

			# 데이터 쓰기
			writeIslandsFile($HcurrentID);
			unlock();

			# 변경성공
			tempPresentOK($name);
		} else {
			# password 오류
			unlock();
			tempWrongPassword();
			return;
		}
	}
}

# 선물 모드의 톱 페이지
sub tempPresentPage {
	out(<<END);
<CENTER>$HtempBack</CENTER>
<H1>참가 ${AfterName}에게 선물 지급</H1>

<FORM action="$HthisFile" method="POST">
<B>선물을 받을 ${AfterName}은?</B><BR>
<SELECT NAME="ISLANDID">
$HislandList
</SELECT><BR>
<BR>
<B>선물의 내용은?(마이너스 값도 가능)</B><BR>
<INPUT TYPE="text" NAME="PRESENTMONEY" VALUE="0" SIZE=16 MAXLENGTH=16>$HunitMoney<BR>
<INPUT TYPE="text" NAME="PRESENTFOOD" VALUE="0" SIZE=16 MAXLENGTH=16>$HunitFood<BR>
<BR>
<B>로그 메시지는?(생략 가능. 선두에${AfterName}이름이삽입됩니다)</B><BR>
○○${AfterName}<INPUT TYPE="text" NAME="PRESENTLOG" VALUE="" SIZE=128 MAXLENGTH=256><BR>
<BR>
<B>마스터 비밀번호</B><BR>
<INPUT TYPE="password" NAME="OLDPASS" VALUE="$HdefaultPassword" SIZE=32 MAXLENGTH=32><BR>
<INPUT TYPE="submit" VALUE="선물 지급" NAME="PresentButton"><BR>
</FORM>
END
}

# 선물완료
sub tempPresentOK {
	my($name) = @_;
	out(<<END);
${HtagBig_}$name${AfterName}에 선물을 지급했습니다${H_tagBig}$HtempBack
END
}

# 선물 내용 이동
sub tempPresentEmpty {
	out(<<END);
${HtagBig_}선물 내용이 올바르지 않습니다${H_tagBig}$HtempBack
END
}

# 관리자가 한제재 모드
sub punishMain {
	if(checkSpecialPassword($HdefaultPassword)) {
		# 특수 비밀번호
		if ($HpunishMode) {
			my(%punish);
			if (open(Fpunish, "<${HdirName}/punish.dat")) {
				local(@_);
				while (<Fpunish>) {
					chomp;
					@_ = split(',');
					my($obj);
					$obj->{id} = shift;
					$obj->{punish} = shift;
					$obj->{x} = shift;
					$obj->{y} = shift;
					$punish{$obj->{id}} = $obj;
				}
				close(Fpunish);
			}

			if (open(Fpunish, ">${HdirName}/punish.dat")) {
				{
					my($obj);
					$obj->{id} = $HcurrentID;
					$obj->{punish} = $HpunishID;
					$obj->{x} = $HcommandX;
					$obj->{y} = $HcommandY;
					$punish{$obj->{id}} = $obj;
				}

				my($key, $obj);
				while (($key, $obj) = each %punish) {
					next if ($obj->{punish} == 0);
					print Fpunish
						$obj->{id}. ','.
						$obj->{punish}. ','.
						$obj->{x}. ','.
						$obj->{y}. "\n";
				}
				close(Fpunish);
			}
		}

		unlock();

		# 템플릿출력
		tempPunishPage();

	} else {
		# 비밀번호가 일치하지 않으면톱 페이지로
		require('hako-top.cgi');
		unlock();
		# 템플릿출력
		tempTopPage();
	}
}

# 제재 모드의 톱 페이지
sub tempPunishPage {
	my(@punishName) =
		(
		 '없음', # 0
		 '지진', # 1
		 '쓰나미', # 2
		 '괴수(인구 조건 제거 때만)', # 3
		 '지반 침하(면적조건지우기 때만)', # 4
		 '태풍', # 5
		 '거대운석(좌표지정)', # 6
		 '운석', # 7
		 '분화(좌표지정)', # 8
		 '거대괴수(인구 조건 제거 때만)', # 9
		 );

	out(<<END);
<CENTER>$HtempBack</CENTER>
<H1>참가 ${AfterName}에게 제재 적용</H1>

<DL>
<DT>·'규칙을 위반했다'고 판단하기 전에, 해당 규칙이 누구나 읽을 수 있는 곳에 게시되어 있는지 확인하세요.</DT>
<DT>·제재 자체는 쉽지만, 정말 관리자의 입장에서 실행해야 할 일인지 먼저 판단해 주세요.</DT>
<DT>·제재가 필요할 만큼 피해가 큰지도 생각해 주세요. 가벼운 마음으로 공격하는 사람은 언제든 있을 수 있습니다.</DT>
<DT>·<span class=attention>제재의 존재는 비공개로 유지하세요.</span>제재 사실이 공개되면 다른 플레이어와의 신뢰 관계도 무너질 수 있습니다.</DT>
</DL>

<FORM name="lcForm" action="$HthisFile" method="POST">
<INPUT TYPE="hidden" VALUE="$HdefaultPassword" NAME="Punish">
<B>제재를 적용할 ${AfterName}은?</B><BR>
<SELECT NAME="ISLANDID">
$HislandList
</SELECT>
<INPUT TYPE="button" VALUE="지도를 열기" onclick="printIsland();">
<BR><BR>
<B>좌표는?(좌표지정할 수 있제재에서 만유효)</B><BR>
<B>(</B><SELECT NAME=POINTX>
END

	my($i);
	foreach $i (0..$islandSize) {
		if($i == $HdefaultX) {
			out("<OPTION VALUE=$i SELECTED>$i\n");
		} else {
			out("<OPTION VALUE=$i>$i\n");
		}
	}

	out(<<END);
</SELECT><B>, </B><SELECT NAME=POINTY>
END

	foreach $i (0..$islandSize) {
		if($i == $HdefaultY) {
			out("<OPTION VALUE=$i SELECTED>$i\n");
		} else {
			out("<OPTION VALUE=$i>$i\n");
		}
	}

	out(<<END);
</SELECT><B>)</B><BR>
<BR>
<B>제재의 내용은?</B><BR>
<SELECT NAME="PUNISHID">
<OPTION VALUE="0">$punishName[0]
<OPTION VALUE="1">$punishName[1]
<OPTION VALUE="2">$punishName[2]
<OPTION VALUE="3">$punishName[3]
<OPTION VALUE="4">$punishName[4]
<OPTION VALUE="5">$punishName[5]
<OPTION VALUE="6">$punishName[6]
<OPTION VALUE="7">$punishName[7]
<OPTION VALUE="8">$punishName[8]
<OPTION VALUE="9">$punishName[9]
</SELECT><BR>
<BR>
<INPUT TYPE="submit" VALUE="제재 적용" NAME="PunishButton"><BR>
</FORM>
<SCRIPT Language="JavaScript">
<!--

function printIsland() {
	var iid;
	with (document.forms[0].elements[1]) {
		iid = options[selectedIndex].value;
	}
	window.open("$HthisFile?Sight=" + iid + "&ADMINMODE=$HdefaultPassword", "punish", "toolbar=0,location=0,directories=0,menubar=0,status=1,scrollbars=1,resizable=1,width=450,height=630");
}
//-->
</SCRIPT>
END

	if (open(Fpunish, "<${HdirName}/punish.dat")) {
		out('<HR>');
		out("<TABLE BORDER><TR><TH>${AfterName}이름</TH><TH>제재내용</TH><TH>좌표</TH></TR>");
		local(@_);
		my($island);
		while (<Fpunish>) {
			chomp;
			@_ = split(',');
			my($obj);
			$obj->{id} = shift;
			$obj->{punish} = shift;
			$obj->{x} = shift;
			$obj->{y} = shift;

			$HcurrentNumber = $HidToNumber{$obj->{id}};
			$island = $Hislands[$HcurrentNumber];
			my $name = islandName($island);
			out("<TR><TD>${name}</TD><TD>$punishName[$obj->{punish}]</TD><TD>($obj->{x}, $obj->{y})</TD></TR>");
		}
		out('</TABLE>');
		close(Fpunish);
	}
}

# 관리자가 한 지형 변경 모드
sub lchangeMain {
	if(checkSpecialPassword($HdefaultPassword)) {
		# 특수 비밀번호
		if ($HlchangeMode) {
			# id에서 섬을 가져옴
			$HcurrentNumber = $HidToNumber{$HcurrentID};
			my($island) = $Hislands[$HcurrentNumber];
			my($land) = $island->{'land'};
			my($landValue) = $island->{'landValue'};

			# 지형 값의 정리합성을 확인(확인하지 않은 경우 주석 처리해 주세요)
#			if(!landCheck($HlchangeKIND, $HlchangeVALUE)) {
#				tempBadValue();
#				unlock();
#				return;
#			}

			$land->[$HcommandX][$HcommandY] = $HlchangeKIND;
			$landValue->[$HcommandX][$HcommandY] = $HlchangeVALUE;

			# 데이터 쓰기
			writeIslandsFile($HcurrentID);
			unlock();

			# 변경성공
			tempLchangeOK(islandName($island));
		}
		unlock();
		# 템플릿출력
		tempLchangePage();
	} else {
		# 비밀번호가 일치하지 않으면톱 페이지로
		require('hako-top.cgi');
		unlock();
		# 템플릿출력
		tempTopPage();
	}
}

# 지형 변경 모드의 톱 페이지
sub tempLchangePage {
	out(<<END);
<CENTER>$HtempBack</CENTER>
<H1>참가 ${AfterName}의 지형 데이터를 변경</H1>

<DL>
<DT>·'지형 값'에 대한 지식이 없으면 사용하기 어렵습니다.</DT>
<DT>·특히 '괴수' 관련 항목은 지식이 있어도 다루기 어렵습니다. 참고로,(지형 값)=(괴수 종류)×16+(괴수 생명력)이며, 종류는 30까지, 생명력은 15까지입니다.</DT>
<!---
<DT>·'지형'에 대해<B>'지형 값'이적절에서 있는 지 간이 판정을 하고 있습니다</B>이므로, 주의해 주세요.</DT>
--->
</DL>

<FORM name="lcForm" action="$HthisFile" method="POST">
<INPUT TYPE="hidden" VALUE="$HdefaultPassword" NAME="Lchange">
<B>지형을 변경${AfterName}은?</B><BR>
<SELECT NAME="ISLANDID">
$HislandList
</SELECT>
<INPUT TYPE="button" VALUE="지도를 열기" onclick="printIsland();">
<BR><BR>
<B>좌표는?</B><BR>
<B>(</B><SELECT NAME=POINTX>
END

	my($i);
	foreach $i (0..$islandSize) {
		if($i == $HdefaultX) {
			out("<OPTION VALUE=$i SELECTED>$i\n");
		} else {
			out("<OPTION VALUE=$i>$i\n");
		}
	}

	out(<<END);
</SELECT><B>, </B><SELECT NAME=POINTY>
END

	foreach $i (0..$islandSize) {
		if($i == $HdefaultY) {
			out("<OPTION VALUE=$i SELECTED>$i\n");
		} else {
			out("<OPTION VALUE=$i>$i\n");
		}
	}

	out(<<END);
</SELECT><B>)</B><BR>
<BR>
<B>지형은?</B><BR>
<SELECT NAME="LCHANGEKIND">
<OPTION VALUE="$HlandSea">바다
<OPTION VALUE="$HlandWaste">황무지
<OPTION VALUE="$HlandPlains">평지
<OPTION VALUE="$HlandTown">마을 계열
<OPTION VALUE="$HlandForest">숲
<OPTION VALUE="$HlandFarm">농장
<OPTION VALUE="$HlandFactory">공장
<OPTION VALUE="$HlandBase">미사일 기지
<OPTION VALUE="$HlandDefence">방위 시설
<OPTION VALUE="$HlandMountain">산
<OPTION VALUE="$HlandMonster">괴수
<OPTION VALUE="$HlandSbase">해저 기지
<OPTION VALUE="$HlandOil">해저 유전
<OPTION VALUE="$HlandMonument">기념비
<OPTION VALUE="$HlandHaribote">가짜 시설
<OPTION VALUE="$HlandSeacity">해저 도시
<OPTION VALUE="$HlandPark">놀이공원
<OPTION VALUE="$HlandMinato">항구
<OPTION VALUE="$HlandFune">선박
<OPTION VALUE="$HlandMine">지뢰
<OPTION VALUE="$HlandNursery">양식장
<OPTION VALUE="$HlandKyujo"> 야구장
<OPTION VALUE="$HlandUmiamu"> 해상 시설
<OPTION VALUE="$HlandFoodim	">식품 연구소
<OPTION VALUE="$HlandProcity">방재 도시
<OPTION VALUE="$HlandGold">금광산
<OPTION VALUE="$HlandSeki">관문
<OPTION VALUE="$HlandRottenSea">오염된 바다
<OPTION VALUE="$HlandNewtown">뉴타운
<OPTION VALUE="$HlandBigtown">현대 도시
<OPTION VALUE="$HlandSeatown">해저 신도시
<OPTION VALUE="$HlandFarmchi"> 양계장
<OPTION VALUE="$HlandFarmpic">양돈장
<OPTION VALUE="$HlandFarmcow">목장
<OPTION VALUE="$HlandCollege">대학
<OPTION VALUE="$HlandFrocity">해상 도시
<OPTION VALUE="$HlandSunahama">해변
<OPTION VALUE="$HlandOnsen">온천
<OPTION VALUE="$HlandHouse"> 섬주의 가
<OPTION VALUE="$HlandShuto">수도
<OPTION VALUE="$HlandUmishuto">해저 수도
<OPTION VALUE="$HlandIce">빙하
<OPTION VALUE="$HlandRizort">리조트지
<OPTION VALUE="$HlandBettown">휘하기 도시
<OPTION VALUE="$HlandKyujokai">다목적경기장
<OPTION VALUE="$HlandBigRizort">임시 해변 리조트 호텔
<OPTION VALUE="$HlandHTFactory">첨단 기술기업
<OPTION VALUE="$HlandShrine"> 시간의 신전
<OPTION VALUE="$HlandHugeMonster">거대괴수
</SELECT><BR>
<BR>
<B>지형 값은?</B><BR>
<INPUT TYPE="text" SIZE=6 NAME="LCHANGEVALUE" VALUE="0"><BR>
<BR>
<INPUT TYPE="submit" VALUE="변경" NAME="LchangeButton"><BR>
</FORM>
<SCRIPT Language="JavaScript">
<!--

function printIsland() {
	var iid;
	with (document.forms[0].elements[1]) {
		iid = options[selectedIndex].value;
	}
	window.open("$HthisFile?Sight=" + iid + "&ADMINMODE=$HdefaultPassword", "lcmap", "toolbar=0,location=0,directories=0,menubar=0,status=1,scrollbars=1,resizable=1,width=450,height=630");
}
//-->
</SCRIPT>
END
}

# 지형 변경완료
sub tempLchangeOK {
	my($name) = @_;
	out(<<END);
${HtagBig_}$name${AfterName}의 지형을 변경했습니다${H_tagBig}
<HR>
END
}

# 지형값 이동
sub tempBadValue {
	out(<<END);
${HtagBig_}지형 값이 올바르지 않습니다${H_tagBig}$HtempBack
END
}

# 지형 값을 확인
sub landCheck {
	my($land, $lv) = @_;
	if($land == $HlandSea) {
		return 0 if(($lv < 0) || ($lv> 1));
	} elsif($land == $HlandWaste) {
		return 0 if(($lv < 0) || ($lv> 1));
	} elsif($land == $HlandPlains) {
		return 0 if($lv != 0);
	} elsif($land == $HlandTown) {
		return 0 if(($lv < 1) || ($lv> 200));
	} elsif($land == $HlandProcity) {
		return 0 if(($lv < 1) || ($lv> 200));
	} elsif($land == $HlandNewtown) {
		return 0 if(($lv < 1) || ($lv> 300));
	} elsif($land == $HlandBigtown) {
		return 0 if(($lv < 1) || ($lv> 500));
	} elsif($land == $HlandSeatown) {
		return 0 if(($lv < 1) || ($lv> 400));
	} elsif($land == $HlandForest) {
		return 0 if(($lv < 1) || ($lv> 200));
	} elsif($land == $HlandFarm) {
		return 0 if(($lv < 10) || ($lv> 50));
#		return if(($lv - 10) % 2 != 0);
	} elsif($land == $HlandFoodim) {
		return 0 if(($lv < 30) || ($lv> 500));
#		return if(($lv - 30) % 10 != 0);
	} elsif($land == $HlandFarmchi) {
		return 0 if(($lv < 1) || ($lv> 4000));
	} elsif($land == $HlandFarmpic) {
		return 0 if(($lv < 1) || ($lv> 4000));
	} elsif($land == $HlandFarmcow) {
		return 0 if(($lv < 1) || ($lv> 4000));
	} elsif($land == $HlandFactory) {
		return 0 if(($lv < 30) || ($lv> 100));
#		return if(($lv - 30) % 10 != 0);
	} elsif($land == $HlandBase) {
		return 0 if(($lv < 0) || ($lv> $HmaxExpPoint));
	} elsif($land == $HlandDefence) {
		return 0 if($lv != 0);
	} elsif($land == $HlandMountain) {
		return 0 if(($lv < 0) || ($lv> 200));
#		return if($lv % 5 != 0);
	} elsif($land == $HlandGold) {
		return 0 if(($lv < 0) || ($lv> 200));
#		return if($lv % 5 != 0);
	} elsif($land == $HlandShrine) {
		return 0 if($lv != 0);
	} elsif($land == $HlandMonster) {
		my($kind, $name, $hp) = monsterSpec($lv);
		return 0 if(($hp < 0) || ($hp> 15) || ($kind < 0) || ($kind> 30));
	} elsif($land == $HlandSbase) {
		return 0 if(($lv < 0) || ($lv> $HmaxExpPoint));
	} elsif($land == $HlandSeacity) {
		return 0 if(($lv < 1) || ($lv> 200));
	} elsif($land == $HlandOil) {
		return 0 if($lv != 0);
	} elsif($land == $HlandMonument) {
		return 0 if(($lv < 0) || ($lv> 94));
	} elsif($land == $HlandHaribote) {
		return 0 if($lv != 0);
	} elsif($land == $HlandPark) {
		return 0 if(($lv < 10) || ($lv> 100));
#		return if(($lv - 10) % 30 != 0);
	} elsif($land == $HlandMinato) {
		return 0 if(($lv < 1) || ($lv> 200));
	} elsif($land == $HlandFune) {
		return 0 if(($lv < 1) || ($lv> 11));
	} elsif($land == $HlandMine) {
		return 0 if(($lv < 0) || ($lv> 9));
	} elsif($land == $HlandNursery) {
		return 0 if(($lv < 20) || ($lv> 100));
#		return if(($lv - 20) % 5 != 0);
	} elsif($land == $HlandKyujo) {
		return 0 if($lv != 0);
	} elsif($land == $HlandUmiamu) {
		return 0 if(($lv < 50) || ($lv> 1000));
#		return if(($lv - 50) % 30 != 0);
	} elsif($land == $HlandSeki) {
		return 0 if($lv != 0);
	} elsif($land == $HlandRottenSea) {
		return 0 if($lv != 1);
	}

	return 1;
}

# 관리자가 한보관 모드
sub preDeleteMain {
	if(checkSpecialPassword($HdefaultPassword)) {
		# 특수 비밀번호
		if($HpreDeleteMode) {
			my @newID = ();
			my $flag = 0;
			foreach (@HpreDeleteID) {
				if(!(defined $HidToNumber{$_})) {
				} elsif($_ == $HcurrentID) {
					$flag = 1;
				} else {
					push(@newID, $_);
				}
			}
			@HpreDeleteID = @newID;
			push(@HpreDeleteID, $HcurrentID) if(!$flag);

			# 데이터 쓰기
			writeIslandsFile($HcurrentID);
			unlock();
			if($flag) {
				tempPreDeleteEnd(islandName($Hislands[$HidToNumber{$HcurrentID}]));
			} else {
				tempPreDelete(islandName($Hislands[$HidToNumber{$HcurrentID}]));
			}
		}
		unlock();
		# 템플릿출력
		tempPdeleteMain();
	} else {
		# 비밀번호가 일치하지 않으면톱 페이지로
		require('hako-top.cgi');
		unlock();
		# 템플릿출력
		tempTopPage();
	}
}

# 보관 모드의 톱 페이지
sub tempPdeleteMain {
	out(<<END);
<CENTER>$HtempBack</CENTER>
<H1>참가 ${AfterName}을 관리자 보관 처리</H1>

<DL>
<DT>·보관 처리된 ${AfterName}은 턴 처리(수입 처리·명령 처리·성장·재해·실업자 이민) 대상에서 제외됩니다.</DT>
<DT>·수상 관계가 처리될 때 다른 ${AfterName}의 공격은 모두 받게 됩니다.</DT>
<DT>·보관 중인 섬이'포기'또는'강제 삭제'된 경우, 보관의ID데이터는, 다음 보관 처리를 할 때까지그대로 남습니다.</DT>
</DL>

<FORM name="pdForm" action="$HthisFile" method="POST">
<INPUT TYPE="hidden" VALUE="$HdefaultPassword" NAME="Pdelete">
<B>관리자 보관로${AfterName}은?</B><BR>
<SELECT NAME="ISLANDID">
$HislandList
</SELECT>
<BR>
<INPUT TYPE="submit" VALUE="설정·해제" NAME="PdeleteButton"><BR>
</FORM>
<TABLE BORDER><TR><TH>보관 중인${AfterName}</TH></TR>
END

	if($HpreDeleteID[0] eq '') {
		out("<TR><TH>관리자 보관의${AfterName} 없습니다!</TH></TR>");
	} else {
		my($name);
		foreach (@HpreDeleteID) {
			next if(!(defined $HidToNumber{$_}));
			$name = islandName($Hislands[$HidToNumber{$_}]);
			out("<TR><TD>$name${AfterName}</TD></TR>");
		}
	}
	out("</TABLE>");
}

# 관리자 보관 설정
sub tempPreDelete {
	my($name) = @_;
	out(<<END);
${HtagBig_}$name${AfterName}을 관리자 보관 상태로 변경했습니다${H_tagBig}
<HR>
END
}

# 관리자 보관 해제
sub tempPreDeleteEnd {
	my($name) = @_;
	out(<<END);
${HtagBig_}$name${AfterName}의 관리자 보관을 해제했습니다${H_tagBig}
<HR>
END
}
#----------------------------------------------------------------------
# 로그템플릿
#----------------------------------------------------------------------
# 기록 로그
sub logHistory {
	open(HOUT, ">>${HdirName}/hakojima.his");
	print HOUT "$HislandTurn,$_[0]\n";
	close(HOUT);
}

# 발견
sub logDiscover {
	my($name) = @_;
	logHistory("${HtagName_}${name}${AfterName}${H_tagName}이 발견됩니다.");
}

# 섬 이름의 변경
sub logChangeName {
	my($name1, $name2) = @_;
	logHistory("${HtagName_}${name1}${AfterName}${H_tagName}, 명칭을${HtagName_}${name2}${AfterName}${H_tagName}에 변경.");
}

# 소유자 이름의 변경
sub logChangeOwnerName {
	my($name1, $name2) = @_;
	logHistory("${HtagName_}${name1}${AfterName}${H_tagName}, 소유자를${HtagName_}${name2}${H_tagName}에 변경.");
}

# 부정 접속
sub tempNewIslandillegal {
	out(<<END);
${HtagBig_}수상한 점은 알려 주세요 m(_ _)m${H_tagBig}$HtempBack
END
}

# 섬이 가득 찬 경우
sub tempNewIslandFull {
	out(<<END);
${HtagBig_}신청이 몰려,${AfterName}이가득 차서 등록할 수 없습니다.${H_tagBig}$HtempBack
END
}

# 신규 등록 시 이름이 없는 경우
sub tempNewIslandNoName {
	out(<<END);
${HtagBig_}${AfterName}이름이 필요합니다.${H_tagBig}$HtempBack
END
}

# 신규 등록 시 이름이 올바르지 않은 경우
sub tempNewIslandBadName {
	out(<<END);
${HtagBig_}',?()<>\$'등을 넣거나,'무인${AfterName}''침몰${AfterName}'등 이상한 이름은 피하세요~${H_tagBig}$HtempBack
END
}

# 신규에서 소유자 이름이 없는 경우
sub tempNewIslandNoOwnerName {
	out(<<END);
${HtagBig_}당신의 이름이필요입니다.${H_tagBig}$HtempBack
END
}

# 신규에서 소유자 이름이부정이 경우
sub tempNewIslandBadOwnerName {
	out(<<END);
${HtagBig_}',?()<>\$'가들어 있예름은 피하세요.${H_tagBig}$HtempBack
END
}

# 이미 같은 이름의 섬이 있는 경우
sub tempNewIslandAlready {
	out(<<END);
${HtagBig_}그${AfterName}라면이미 발견되어 있습니다.${H_tagBig}$HtempBack
END
}

# 비밀번호가 없는 경우
sub tempNewIslandNoPassword {
	out(<<END);
${HtagBig_} 비밀번호가필요입니다.${H_tagBig}$HtempBack
END
}

# 섬을 발견했습니다!!
sub tempNewIslandHead {
	out(<<END);
<CENTER>
${HtagBig_}${AfterName}을 발견했습니다!!${H_tagBig}<BR>
${HtagBig_}${HtagName_}'${HcurrentName}${AfterName}'${H_tagName}을 찾았습니다.${H_tagBig}<BR>
$HtempBack<BR>
</CENTER>
<!-- 이 SCRIPT는 '섬 발견 화면에서 지도를 클릭하면 오류가 발생하는' 버그 수정용 -->
<SCRIPT Language="JavaScript">
<!--
function ps(x, y) {
	return true;
}
//-->
</SCRIPT>
END
}

# 이름 변경실패
sub tempChangeNothing {
	out(<<END);
${HtagBig_}이름과 비밀번호가 모두 비어 있습니다${H_tagBig}$HtempBack
END
}

# 이름 변경 자금 부족
sub tempChangeNoMoney {
	out(<<END);
${HtagBig_} 자금 부족으로 변경할 수 없습니다${H_tagBig}$HtempBack
END
}

# 이름 변경성공
sub tempChange {
	out(<<END);
${HtagBig_}변경을 완료했습니다${H_tagBig}$HtempBack
END
}

# 강제 삭제 로그
sub logDeleteIsland {
	my($id, $name) = @_;
#	logHistory("${HtagName_}${name}${H_tagName},<B>관리자 권한로</B><span class=attention>퇴장</span>이 됩니다.");
#	logHistory("${HtagName_}${name}${H_tagName}에, 돌진그럼<B>천벌이하강리</B>아라는 마에<span class=attention>바다에침몰시</span>흔적도 없이 사라졌습니다.");
	logHistory("${HtagName_}${name}${H_tagName}은, 바다신의<B>분노리에접촉레</B>육지는 모두<span class=attention>침몰했습니다.</span>");
}

# 섬의 강제 삭제(스페샤루 모드)
sub tempDeleteIsland {
	my($name) = @_;
	out(<<END);
${HtagBig_}${name}을강제 삭제했습니다.${H_tagBig}$HtempBack
END
}

# 선물
sub logPresent {
	my($id, $name, $log) = @_;
	logHistory("${HtagName_}${name} 섬${H_tagName}$log") if ($log ne '');
}

1;

