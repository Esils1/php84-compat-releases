#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}
#----------------------------------------------------------------------
# Hakoniwa R.A. ver1.11
# toto & Numbers 스크립트(하코니와 제도 ver2.30)
# 사용 조건, 사용 방법은 read-renas.txt 파일을 참조
#
# KEI PAGE: http://www5b.biglobe.ne.jp/~k-e-i/
#----------------------------------------------------------------------

# toto 처리
sub totoMain {
	# 턴잔의 턴라면

	# toto 정답을 계산
	my(@totoAns);
	foreach (0..4, 9, 19, 29) {
		push(@totoAns, (defined $Hislands[($_ + $HbfieldNumber)]->{'id'} ? $Hislands[($_ + $HbfieldNumber)]->{'id'} : '0'));
	}

	# toto 의적중판정을 하다
	my($allBet, @tempNo);
	my(@totoBet, $i, $j, $k, $n);
	my $buyFlag = 0;
	foreach $i (0..$islandNumber) {
		my @flag = (0, 0);
		$island = $Hislands[$i];
		foreach $j (0,1) {
			if($island->{'totoyoso'}->[$j] =~ /\(toto\@(.*)\)/) {
				$flag[$j] = 1;
				@totoBet = split(/\./, $1);
				$n = 0;
				for($k = 0; $k < 8; $k++) {
					$n++ if($totoAns[$k] == $totoBet[$k]);
				}
				$tempNo[$n].= "$i,"
			}
		}
		next unless($flag[0] || $flag[1]);

		# toto 구매희망라면
		my $betCost = 1000; # 구매비용 1000 억 엔
		if ($island->{'money'} < $betCost) {
			# 구매 비용 없음
			logNoAny($island->{'id'}, islandName($island), 'toto 구매', '자금 부족의');
		} elsif($flag[0] && $flag[1] && ($island->{'money'} < $betCost*2)) {
			# 구매 비용 없음
			$flag[1] = 0;
			$buyFlag = 1;
			logNoAny($island->{'id'}, islandName($island), 'toto 구매(예상2)', '자금 부족의');
			logPropaganda($island->{'id'}, islandName($island), 'toto 구매(예상1)');
		} else {
			# 구매비용이 있음
			$island->{'money'} -= $betCost * ($flag[0] + $flag[1]);
			$allBet += $betCost * ($flag[0] + $flag[1]);
			$buyFlag = 1;
			logPropaganda($island->{'id'}, islandName($island), 'toto 구매(예상1)') if ($flag[0]);
			logPropaganda($island->{'id'}, islandName($island), 'toto 구매(예상2)') if ($flag[1]);
		}
	}
	return if(!$buyFlag);

	# 정답의 로그 작성
	logHistory("${HtagName_}제${HislandTurn}턴 toto${H_tagName} <B>: @totoAns</B>");

	my (@rate, $bet, @no);
	# 적중점 수마다의 지불이복귀시률
	$rate[6] = 2;
	$rate[7] = 8;
	$rate[8] = 20;
	# toto 의지불이복귀시를 하다
	foreach $i (6..8) {
		# ${i}점 단위안
		if($tempNo[$i] ne '') {
			@no = split(/,/, $tempNo[$i]);
			$bet = int($allBet * $rate[$i] / ($#no + 1));
			# 배당 금액 로그 작성
			logHistory("${HtagName_}제${HislandTurn}턴 toto${H_tagName} ${i}점 단위안☆배당금 $bet$HunitMoney");
			foreach (@no) {
				$island = $Hislands[$_];
				$island->{'money'} += $bet;
				my $name = islandName($island);
				logOut("${HtagName_}$name${H_tagName} ${HtagName_}toto${H_tagName} ${i}점 단위안!배당금 $bet$HunitMoney", $island->{'id'});
			}
		} else {
			$rate[$i + 1] += $rate[$i];
		}
	}
}

# Numbers 처리
sub numbersMain {
	my($mode)= @_;
	# Numbers 정답을 계산
	my $totoAns = ($mode == 3) ? random(999) : random(9999);

	my $num = ($mode == 3) ? 'n3' : 'n4';

	# Numbers 의적중판정을 하다
	my($allBet, @no);
	my($i, $j, $n);
	my $buyFlag = 0;
	foreach $i (0..$islandNumber) {
		my @flag = (0, 0);
		$island = $Hislands[$i];
		for($j = 0; $j < 2; $j++) {
			if($island->{'totoyoso'}->[$j] =~ /\($num\@(\d+)\)/) {
				$flag[$j] = 1;
				push(@no, $i) if($totoAns == $1);
			}
		}
		next unless($flag[0] || $flag[1]);

		# Numbers 구매희망라면
		my $betCost = 200; # 구매비용 200 억 엔
		if ($island->{'money'} < $betCost) {
			# 구매 비용 없음
			logNoAny($island->{'id'}, islandName($island), "Numbers${mode}구매", '자금 부족의');
		} elsif($flag[0] && $flag[1] && ($island->{'money'} < $betCost*2)) {
			# 구매 비용 없음
			$flag[1] = 0;
			$buyFlag = 1;
			logNoAny($island->{'id'}, islandName($island), "Numbers${mode}구매(예상2)", '자금 부족의');
			logPropaganda($island->{'id'}, islandName($island), "Numbers${mode}구매(예상1)");
		} else {
			# 구매비용이 있음
			$island->{'money'} -= $betCost * ($flag[0] + $flag[1]);
			$allBet += $betCost * ($flag[0] + $flag[1]);
			$buyFlag = 1;
			logPropaganda($island->{'id'}, islandName($island), "Numbers${mode}구매(예상1)") if ($flag[0]);
			logPropaganda($island->{'id'}, islandName($island), "Numbers${mode}구매(예상2)") if ($flag[1]);
		}
	}
	return if(!$buyFlag);

	# 정답의 로그 작성
	my $totoDisp = ($mode == 3) ? sprintf("%03d", $totoAns) : sprintf("%04d", $totoAns);
	logHistory("${HtagName_}제${HislandTurn}턴 Numbers${mode}${H_tagName} <B>: $totoDisp</B>");

	# 적중점 수마다의 지불이복귀시률
	my $rate = ($mode == 3) ? 100 : 200;

	# Numbers 의지불이복귀시를 하다
	if ($no[0] ne '') {
		# 정답자가 있음
		my $bet = int($allBet * $rate / ($#no + 1));

		# 배당 금액 로그 작성
		logHistory("${HtagName_}제${HislandTurn}턴 Numbers${mode}${H_tagName} 적중☆배당금 $bet$HunitMoney");

		foreach (@no) {
			$island = $Hislands[$_];
			$island->{'money'} += $bet;
			my $name = islandName($island);
			logOut("${HtagName_}$name${H_tagName} ${HtagName_}Numbers${mode}${H_tagName} 적중!배당금 $bet$HunitMoney", $island->{'id'});
		}
	}
}

1;
