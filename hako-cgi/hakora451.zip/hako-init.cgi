#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}
#----------------------------------------------------------------------
# 하코니와 제도 ver2.30
# 초기 설정용스크립트(ver1.02)
# 사용 조건과 사용 방법은 hako-readme.txt 파일을 참조해 주세요
#
# 하코니와 제도의 페이지: http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html
#----------------------------------------------------------------------
#----------------------------------------------------------------------
# Hakoniwa R.A. ver1.11
# 초기 설정용스크립트(하코니와 제도 ver2.30)
# 사용 조건, 사용 방법은 read-renas.txt 파일을 참조
#
# KEI PAGE: http://www5b.biglobe.ne.jp/~k-e-i/
#----------------------------------------------------------------------

# 문자 변환 라이브러리 로드

require './init-server.cgi';

#----------------------------------------------------------------------
# 각종 설정 값
# 아래 설정 값을 서버 환경에 맞게 변경해 주세요.
#----------------------------------------------------------------------

# 디버그 모드(1이면 '턴 진행' 버튼을 사용할 수 있음)
$Hdebug = 0;

# 메인 스크립트
$HthisFile = "${HbaseDir}/hako-main.cgi";

# 하코니와 점검·스크립트
$HmenteFile = "${HbaseDir}/hako-mente.cgi";

# 접속해석스크립트
$HaxesFile = "${HbaseDir}/analyzer.cgi";

# 게임 제목 문자열
$HtitleTag = 'Hakoniwa R.A.'; # 창의 제목
$Htitle = 'Hakoniwa R.A.'; # 중단 화면의 제목

# 관광객 통신 목록(관리용)
$HlbbsFile = "${HbaseDir}/lbbslist.cgi";
$jumpTug = "<meta HTTP-EQUIV='refresh' CONTENT='0; URL=\"${HlbbsFile}\"'></body></html>\n\n";
#$jumpTug = "Location: $HlbbsFile\n\n";

# 헤더 링크(이용 약관상, 하코니와 제도 스크립트 배포처 링크는 삭제하면 안 됩니다)
$Hheader =<<"_H_E_A_D_E_R_";
[<A HREF="$Htoppage">톱 페이지</A>]
[<A HREF="$Hbbs">게시판</A>]
_H_E_A_D_E_R_

# 푸터의 링크
$Hfooter =<<"_F_O_O_T_E_R_";
관리자:$HadminName(<A HREF="mailto:$email">$Hemail</A>)<BR>
게시판(<A HREF="$Hbbs">$Hbbs</A>)<BR>
톱 페이지(<A HREF="$Htoppage">$Htoppage</A>)<BR>
하코니와 제도의 페이지(<A HREF="http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html">http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html</A>)<BR>
Hakoniwa R.A. 의페이지(<A HREF="http://www5b.biglobe.ne.jp/~k-e-i/i.html">http://www5b.biglobe.ne.jp/~k-e-i/i.html</A>)
_F_O_O_T_E_R_

# 새 섬을 탐색하게 함것은 관리자만?
# (관리자만의 경우 $HjoinGiveupTurn 을작게해 주세요)
$HadminJoinOnly = 0;

# 헤더의 코멘트(부하를 가능하면 직접 hako-top.cgi를 수정하는 편이 좋음)
# lbbslist.cgi에서 주석 처리된 '&tempNews if($mode);'와 연동 시, lbbslist.cgi에서 news.cgi를 치환할 수 있습니다.
#if(-e "./news.cgi") {
#	open(NEWS, "./news.cgi");
#	my @news = <NEWS>;
#	close(NEWS);
#	$Hnews = join(/\n/, @news);
#	chomp($Hnews);
#}
#$Hheader.= $Hnews;
#----------------------------------------
# 게임의 진행야 파일등
#----------------------------------------
# 1턴이 몇 초인지
$HunitTime = 3600*3; # 3 시간

# 턴 갱신 간격을 세부적으로 설정할까요?(0:하지 않음,1:함)
$HflexTimeSet = 0;
# 하는 경우, 턴 갱신 간격(시간단위에서 설정해 주세요)를 쉼표로 구분에서 설정해 주세요.
# 0턴에서1턴로의 갱신간격이@HflexTime 의 처음의 수치(시간)이 됩니다.
# x턴에서x+1턴까지의 갱신간격은 (x을 설정한개 수에서 할했음별로+1)번째의 수치
# 참고: 플레이어가 혼란스럽지 않도록 정확히 공지해 주세요.
@HflexTime = (3, 3, 3, 3, 9, 3);

# 섬의 최대 수(최대에서100)
$HmaxIsland = 10;

# 섬 크기(변경할 수 없일 수도)
$HislandSize = 20;

# 새 섬을 탐색하게 함것은 관리자만?(0:하지 않음,1:함)
# (관리자만의 경우 $HjoinGiveupTurn 을작게해 주세요)
$HadminJoinOnly = 0;

# 명령 입력 한계 수
# (게임이 시작된 뒤 변경하면 데이터 파일 호환성이 없어집니다.)
$HcommandMax = 20;

# 로컬 게시판 행 수 사용 여부(0:사용하지 않음,1:사용함)
$HuseLbbs = 1;

# 로컬 게시판의 코멘트를 자동 링크할 때의 링크기호
$HlbbsAutolinkSymbol = '[Link]'; # 비워 두면 자동 링크하지 않습니다.

# 로컬 게시판 줄 수
$HlbbsMax = 10;

# 외부 간이 게시판을 사용할지(0:사용하지 않음,1:사용함)
$HuseExlbbs = 0;
# 사용하는 경우, 이하를 설정
# 외부 간이 게시판의 주소(lbbs.cgi,view.cgi 가 배치된 디렉터리)
# 끝에 슬래시(/)는 붙이지 않습니다.
$HlbbsDir = "${HbaseDir}/lbbs";
# view.cgi 의 마스터 비밀번호
$HviewPass = '0123';
# 주!외부 간이 게시판은 별도로 준비하다필요합니다.

# 이름 뒤에 붙일 접미사(기본값은 "섬")
$AfterName = '섬';

# gzip을 사용해 압축 전송할까요? 0: 미사용 1: 사용
$Hgzip = 0;

# gzip 설치 경로
$HpathGzip = '/usr/bin';

# 로그 파일 유지 턴 수
$HlogMax = 8;

#'최근 사건'에 표시할 로그의 턴 수(로그 파일 유지 턴 수보다클 수 없습니다)
$HtopLogTurn = 8;

#'최근 사건'을 HTML로 만들지 여부(0:하지 않음,1:함)
$HhtmlLogMake = 0;

# HTML로 만드는 경우, 이하를 설정
# HTML 파일(hakolog.html)을 배치할 디렉터리
# my($htmlDir) = 'http://서버/디렉터리';
# 끝에 슬래시(/)는 붙이지 않습니다.
$htmlDir = "${HbaseDir}";
# $HbaseDir에서$htmlDir 로의 상대 경로. 끝에 슬래시(/)는 붙이지 않습니다.
$HhtmlDir = '.';
# HTML 페이지에 표시할 로그의 턴 수(로그 파일 유지 턴 수보다클 수 없습니다)
$HhtmlLogTurn = 8;
#'최근 가능 항목'를 HTML에서 표시할지(0:하지 않음,1:함)
#'최근 가능 항목'를 HTML로 만들지 않은 경우0로 설정해 주세요.
$HhtmlLogMode = 0;

# 각 섬의'최근 상황'을 history.cgi 에서 표시할까요?(0:하지 않음,1:함)
$HuseHistory1 = 1; # 자기 섬(개발 화면)
$HuseHistory2 = 1; # 타 섬(관광 화면 등)

# 계절을 도입할까요?(0:하지 않음,1:함)
# 설정하는 경우,hako-main.cgi 의재해의 곳에서 월마다의 발생률도 설정됩니다.
$Hseason = 0;
# 달력 이름(서력/평성 등으로 표시할 이름. 사용하지 않으려면 ""로 두세요)
$Halmanac = "${HadminName}역사";
# 계절마다이미지를 변경할까요?(0:하지 않음,1:함)
$HseaonImgSet = 0;
# 하는 경우, 이미지폴더 안에계절마다의 폴더를 준비해 주세요.
# 폴더 이름을 아래에서 설정합니다. 월별로 이미지를 변경할 수도 있습니다.
# 참고: 일부만의 변경라도, 계절폴더각각에, 모든 이미지를 이됨필요합니다.
# 로컬 설정도1개의 폴더(예를 들어'img')의 안에계절의 폴더를 만들어있고,
# 'img' 안에는 land0.gif 하나만 넣어 두면 설정에 사용할 수 있습니다.
# 0:계절없음 0, 1월, 2월, 3월, 4월, 5월, 6월, 7월, 8월, 9월,10월,11월,12월
@HseasonImg = ('', 'f', 'f', 'f', 'h', 'h', 'h', 'n', 'n', 'n', 'a', 'a', 'a');

# 부하를 측정할까요?(0:하지 않음,1:측정함)
$Hperformance = 1;

# 소유자·비밀번호 암호화(0:하지 않음 1:하다)
$cryptOn = 1;

#----------------------------------------
# 동맹
#----------------------------------------
# 동맹작성을 허가할까요?(0:하지 않음,1:하다,2:관리자만)
$HallyUse = 1;

# 하나의 동맹에만 가입할 수 있도록 할까요?(0:하지 않음,1:함)
$HallyJoinOne = 0;

# 가입·탈퇴를 명령에서 실행할 수 있도록?(0:하지 않음,1:함)
$HallyJoinComUse = 0;

# 동맹에 가입하면 일반 재해 발생 확률이 감소합니까?(0:하지 않음)
# 대상이 되는 재해:지진, 쓰나미, 태풍, 운석, 거대운석, 분화
$HallyDisDown = 0; # 설정하는 경우, 일반 상태에 대한 배율을 설정.(예)0.5이면반감.2이면배증(^^;;;

# 동맹 데이터의 이름
$HallyData = 'ally.dat';

# 동맹 게시판에 BBS를 사용하기 1:하다 0:하지 않음
$HallyBbs = 1;
# BBS의스크립트 이름
$HallyBbsScript = "hako-yy-bbs.cgi"; # YY-BOARD ver5.03 by KENT
# 로그저장용 디렉터리의 이름
$HlogdirName = 'log';
# 로그 파일 이름:반드시 변경. 확장자는'.cgi'에
$Hlogfile_name = 'allybbs.cgi'; # 일반 로그용
$Hlogfile2_name = 'stuffcom.cgi'; # 중요게시용
# 미니카운터의 설치 (0:no 1:텍스트 2:GIF 이미지)
$Hcounter = 1;
# 카운터 파일 이름
$Hcntfile_name = 'count.cgi';
# 과거 로그 생성 (0=no 1=yes)
$Hpastkey = 1;
# 과거 로그용 NO 파일 이름
$Hnofile_name = 'pastno.cgi';
# 과거 로그의 디렉터리
$HpastdirName = 'past';
# YY-BOARD의 상세 설정은 hako-yy-ini.cgi에서 하세요.

$HcostMakeAlly = 1000; # 동맹의 결성·변경에걸립니다비용
$HcostKeepAlly = 500; # 동맹의 유지비(가입한 섬에서 균등등에부담)

# 동맹의 표시
@HallyMark = (
	'Б','Г','Д','Ж','Й',
	'Ф','Ц','Ш','Э','Ю',
	'Я','б','Θ','Σ','Ψ',
	'Ω','에','이','¶','‡',
	'†','♪','♭','♯','‰',
	'Å','∽','∇','∂','∀',
	'⇔','∨','〒','￡','￠',
	'＠','★','♂','♀','＄',
	'KRW ','℃','같음','마감',
);

# 중요게시 메시지란의 제목'~부터의 메시지''~모드'
$HallyTopName = '맹주'; # 진영전쟁 모드의 때등은'참도'에할 수 있습니다.

# 동맹(진영)외로의 지원 1:불허 0:허가
$HcampAidOnly = 1;

#----------------------------------------------------------------------
# 진영전쟁 모드(조정안)
#----------------------------------------------------------------------
# 휴전 기간
$HarmisticeTurn = 0; # 0에스레파오후가 됩니다

# 휴전 기간 중 턴 갱신 간격
$HarmisticeTime = 21600; # 3 시간

# 승리조건
$HfinishOccupation = 70; # 점유율이이 값이상에 할지종료

# 진영 위임 임시 이관 턴 수
$HpreGiveupTurn = 8;

# 진영의 선택 방법
# 0: 섬 수가 가장 적고, 순위가 최하위의 진영
# 1: 무작위("전체 섬 수/진영 수"를초과하지 않음)
# 2: 선택 가능("전체 섬 수/진영 수"를초과하지 않음)
$HcampSelectRule = 0;

# 진영의 소멸
$HcampDeleteRule = 0; # 1:진영소멸규칙있음,0:없음

# 진영작전본부 명령 표시 수
$HcampCommandTurnNumber = 5;

# 초기 자금
$HinitialMoney2 = 3000; # 게임시작후의 등록

# 초기 식량
$HinitialFood2 = 3000; # 게임시작후의 등록

#----------------------------------------------------------------------
# 서바이벌 모드(규정 턴마다 최하위 섬이 침몰합니다)
#----------------------------------------------------------------------
# 서바이벌 모드에 들어가는 턴(설정값의 다음 턴에서 유효)
$HsurvivalTurn = 0; # 0으로 하면 꺼집니다

# 몇 턴마다 최하위 섬을 멸망시킬지(전투 기간만)
$HturnDead = 10;

#----------------------------------------
# 접속 로그 관련 설정
#----------------------------------------
# COOKIE를 이용한 ID 확인을 할까요?(0:하지 않음,1:함)
# '사용'으로 설정하면 동일 PC에서 여러 섬을 관리할 때 COOKIE를 삭제하지 않으면 다른 섬의 개발 화면에 들어갈 수 없습니다.
# 간이 중복 등록 대책입니다. 섬마다 브라우저를 바꾸는 식으로 우회될 수는 있습니다(/_<.)
$checkID = 1;

# COOKIE를 이용한'이미지 경로 설정'모 확인하다?(0:하지 않음,1:함)
$checkImg = 0;

# COOKIE 확인(위 2개 설정)을 면제할 섬의 ID
# 예:@freepass = (2, 7, 12);
@freepass = ();

# 비밀번호 오류 화면에 경고문을 표시할까요?(0:하지 않음,1:함)
$HpassError = 1;

# 접속 로그를 남길지?
# 0:사용 안 함,1:개발 화면에 들어갈 때 오류가 발생한 경우,2:개발 화면에 들어갈 때(오류 포함 여부 무관),3:톱 페이지만,4:양쪽분
$HtopAxes = 0;
# 1or2에 의한 경우, 이하를 설정
# 로그 파일 이름
$HaxesLogfile = './axes.cgi';
# 최대 기록 건수
$HaxesMax = 500;
# 호스트 이름 조회 방법(0:gethostbyaddr 함수를 사용하지 않고,1:gethostbyaddr 함수를 사용)
$gethostbyaddr = 0;
# proxy 간이 확인을 할까요?(0:하지 않음,1:함)
$proxycheck = 1;

# 접속제한(hako-yy-bbs.cgi 토공통 설정)
# 접속을 제한할 호스트 이름,IP 주소
@Hdeny = (
	"anonymizer.com",
	"cache*.*.interlog.com",
	"211.154.120.*",
#	"127.0.0.1",
	"",
	"",
	"",
	"",
);
# 제한한 IP의 접속을 어디로 이동시킬지
#$HdenyLocation = 'http://www.yahoo.co.jp/'; # 야후로 이동시키는 경우
$HdenyLocation = ''; # 비어 있으면 메시지를 표시합니다.
#----------------------------------------------------------------------
# 특별한 상수
# (게임안에 값을 변경하면 안 됩니다. 데이터가 파괴됩니다)
#----------------------------------------------------------------------
# 턴분할갱신(한 번에 갱신할 섬의 수)
# !이 설정은 위험하므로 0:미설정 상태로 두세요.
# 설정 변경에 따라 데이터의 파손이 발생하거나, 서버 관리자와 문제가 생길 가능성이 있습니다.
$HsepTurn = 0; # 0:미설정... 미설정그대로, 변경하지 마세요m(_ _)m
$Hrefresh = 3; # 리후레슈 시간(초)

# 좌표의 최댓값
$islandSize = $HislandSize - 1;

1;
