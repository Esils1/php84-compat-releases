#!/usr/bin/perl

# The Return of Neptune: http://hpcgi2.nifty.com/otacky/
#----------------------------------------------------------------------
# hako-yy-bbs.cgi by.neo_otacky
# 해전 「동맹 게시판」용으로 수정
# 　=== 관리용 접속 방법 ===
# 　hako-yy-bbs.cgi?id=0&ally=[동맹 ID]&cpass=[마스터 비밀번호]
# 　[동맹 ID]는 반각 숫자, [마스터 비밀번호]는 영문/숫자입니다([]는 불필요).
#┌─────────────────────────────────
#│ YY-BOARD
#│ yybbs.cgi - 2006/01/18
#│  Copyright (c) KentWeb
#│  webmaster@kent-web.com
#│  http://www.kent-web.com/
#└─────────────────────────────────

BEGIN {
	# Perl 5.004 이상이 필요
	require 5.004;

########################################
	# 오류 표시
	$SIG{__WARN__} = $SIG{__DIE__} =
	sub {
		my($msg) = @_;

		$msg =~ s/\n/<br>/g;
		print STDOUT <<END;
Content-type: text/html; charset=utf-8

<p><big><tt><b>ERROR:</b><br>$msg</tt></big></p>
END
		exit(-1);
	};
########################################
}

# 외부 파일 불러오기
require './hako-yy-ini.cgi';

# 메인 처리
&decode;
&read_data;
&file_check;
local($cnam,$ceml,$curl,$cpwd,$cico,$ccol,$ccss) = &get_cookie;
if ($mode eq "image") { &image; }
if ($mode eq "regkey") { &regkey; }
&axsCheck;
if ($mode eq "howto") { &howto; }
elsif ($mode eq "find") { &find; }
elsif ($mode eq "check") { &check; }
elsif ($mode eq "html") { &log2html($in{'htmlname'}, $in{'maxline'}, $in{'amity'}); }
elsif (($dead eq '') || ($owner == 2)) {
	if ($mode eq "res") { &resForm; }
}
&logView;
#-------------------------------------------------
#  답글 폼
#-------------------------------------------------
sub resForm {
	local($f,$no,$reno,$dat,$nam,$eml,$sub,$com,$url,$resub);

	# 등록 키
	local($str_plain,$str_crypt);
	if ($regist_key) {
		require $registkeypl;

		($str_plain,$str_crypt) = &pcp_makekey;
	}

	# 쿠키 가져오기
	if (!$curl) { $curl = 'http://'; }

	# 로그 읽기
	$f = 0;
	open(IN,"$logfile") || &error("Open Error : $logfile (res_form)");
	$top = <IN>;

	# 헤더 출력
	if ($ImageView == 1) { &header('ImageUp'); }
	else { &header; }

	# 관련 글 출력
	print <<EOM;
<form>
<input type="button" value="이전 화면으로 돌아가기" onClick="history.back()">
<input type=hidden name=ally value="$in{'ally'}">
<input type=hidden name=jpass value="$in{'jpass'}">
<input type=hidden name=cpass value="$in{'cpass'}">
<input type=hidden name=id value="$in{'id'}">
</form>
▽아래는 게시글 번호 <B>$in{'no'}</B>에 대한 <a href='#RES'>답글 폼</a>입니다.
<hr>
EOM

	while (<IN>) {
		($no,$reno,$dat,$nam,$eml,$sub,$com,$url,$idname,$allyidname,$turn) = split(/<>/);
		if ($in{'no'} == $no && $reno) { $f++; }
		if ($in{'no'} == $no || $in{'no'} == $reno) {

			if (length($sub) > $sub_len*2) {
				$sub = substr($sub,0,$sub_len*2-4);
				$sub .= "...";
			}
			if ($in{'no'} == $no) { $resub = $sub; }
			if ($url) { $url = "&lt;<a href=\"$url\">Home</a>&gt;"; }
			if ($reno) { print '&nbsp;&nbsp;'; }

			my $iName = '';
			if($allyidname ne '') {
				if($idname eq '0') {
					$iName = "${atMark}$ally_name[0]";
				} elsif($idname ne '') {
					$iName = "${atMark}${idname}${AfterName}";
				}
			}
			if(($dead ne '') || $owner || $amity) {
				1 while $com =~ s/(.*)(&lt;(amity)&gt;(.*)&lt;\/amity&gt;)/$1<span class=\'amity\'>$4<\/span>/i;
			} else {
				1 while $com =~ s/(.*)(&lt;(amity)&gt;(.*)&lt;\/amity&gt;)/$1/i;
			}

			my $turnStr = " [턴<span class='turn'>$turn</span>]" if($turn);
			print "<span class='subject'>$sub</span> ";
			print "작성자：<b>${nam}${iName}</b> 등록일：${dat}${turnStr} $url ";
			print "<span class='number'>No\.$no</span><br>\n";
			print "<blockquote>$com</blockquote><hr>\n";
		}
	}
	close(IN);
	if ($f) { &error("잘못된 답글 요청입니다"); }

	# 제목 이름
	if ($resub !~ /^Re\:/) { $resub = "Re: $resub"; }

	print <<"EOM";
<a name="RES"></a>
<form action="$regist" method="POST">
<input type=hidden name=mode value="regist">
<input type=hidden name=reno value="$in{'no'}">
<input type=hidden name=page value="$page">
<blockquote>
EOM
	&form($cnam,$ceml,$curl,$cpwd,$cico,$ccol,$resub,'');

	print <<EOM;
</form>
</blockquote>
</body>
</html>
EOM
	exit;
}

#-------------------------------------------------
#  주의사항
#-------------------------------------------------
sub howto {
	&header;
	print <<"EOM";
[<a href="JavaScript:void(0)" onClick="document.LINK.submit();return false;">게시판으로 돌아가기</a>]
<form name=LINK method="POST" action="$script">
<input type=hidden name=mode value="">
<input type=hidden name=ally value="$in{'ally'}">
<input type=hidden name=jpass value="$in{'jpass'}">
<input type=hidden name=cpass value="$in{'cpass'}">
<input type=hidden name=id value="$in{'id'}">
</form>
<div align="center">
<table class='n' width="90%" border=1 cellpadding=10>
<tr><td>
<h3>주의사항</h3>
<ol>
<li>이 게시판은 <b>쿠키를 지원</b>합니다. 한 번 글을 작성하면 이름, 이메일, 참조 URL, 수정/삭제 키 정보가 다음 글쓰기부터 자동 입력됩니다. 단, 사용자의 브라우저가 쿠키를 지원해야 합니다.
<li>게시글에는 <b>태그를 사용할 수 없습니다.</b>
	단, <b>&lt;amity&gt;와 &lt;\/amity&gt;로 감싼 부분은 $HallyTopName이 우호국으로 인정한 섬만 볼 수 있습니다.</b>
<li>글 등록 필수 항목은 <b>「이름」</b>과 <b>「내용」</b>입니다. 이메일, 참조 URL, 제목, 수정/삭제 키는 선택 항목입니다.
<li>게시글에는 <b>반각 가나를 사용하지 마세요.</b> 글자 깨짐의 원인이 됩니다.
<li>글을 등록할 때 <b>「수정/삭제 키」</b>에 원하는 비밀번호(영문/숫자 8자 이내)를 입력해 두면, 이후 그 키로 게시글을 수정하거나 삭제할 수 있습니다.
<li>게시글 보관 수는 <b>최대 $max건</b>입니다. 이를 초과하면 오래된 글부터 자동 삭제됩니다.
<li>기존 게시글에 <b>「답글」</b>을 달 수 있습니다. 각 게시글 위쪽의 <b>「답글」</b> 버튼을 누르면 답글 폼이 표시됩니다.
<li>지난 게시글에서 <b>「검색어」로 간단히 검색할 수 있습니다.</b> 상단 메뉴의<a href="JavaScript:void(0)" onClick="document.LINK.mode.value='find';document.LINK.submit();return false;">「단어 검색」</a>링크를 클릭하면 검색 모드로 전환됩니다.
<li>관리자가 심각한 불이익이 있다고 판단한 글이나 타인을 비방·중상하는 글은 예고 없이 삭제될 수 있습니다.
</ol>
</td></tr></table>
</div>
</body>
</html>
EOM
	exit;
}

#-------------------------------------------------
#  단어 검색
#-------------------------------------------------
sub find {
	local($no,$reno,$date,$name,$email,$sub,$com,$url);

	&header;
	print <<"EOM";
[<a href="JavaScript:void(0)" onClick="document.LINK.submit();return false;">게시판으로 돌아가기</a>]
<form name=LINK method="POST" action="$script">
<input type=hidden name=ally value="$in{'ally'}">
<input type=hidden name=jpass value="$in{'jpass'}">
<input type=hidden name=cpass value="$in{'cpass'}">
<input type=hidden name=id value="$in{'id'}">
</form>
<ul>
<li>검색어를 입력하고 「조건」「표시」를 선택한 뒤 검색 버튼을 눌러 주세요.
<li>검색어는 공백으로 구분해 여러 개 지정할 수 있습니다.
<p>
<form action="$script" method="POST">
<input type=hidden name=mode value="find">
<input type=hidden name=ally value="$in{'ally'}">
<input type=hidden name=jpass value="$in{'jpass'}">
<input type=hidden name=cpass value="$in{'cpass'}">
<input type=hidden name=id value="$in{'id'}">
검색어 <input type=text name=word size=35 value="$in{'word'}" class=f>
조건 <select name=cond class=f>
EOM
	if (!$in{'cond'}) { $in{'cond'} = "AND"; }
	foreach ("AND", "OR") {
		if ($in{'cond'} eq $_) {
			print "<option value=\"$_\" selected>$_\n";
		} else {
			print "<option value=\"$_\">$_\n";
		}
	}
	if (!$in{'view'}) { $in{'view'} = 10; }
	print "</select> 표시 <select name=view class=f>\n";
	foreach (10,15,20,25) {
		if ($in{'view'} == $_) {
			print "<option value=\"$_\" selected>$_건\n";
		} else {
			print "<option value=\"$_\">$_건\n";
		}
	}

	print <<EOM;
</select>
<input type=submit value="검색">
</form>
</ul>
EOM

	# 검색 실행
	if ($in{'word'} ne "") {
		($i,$next,$back) = &search($logfile,$in{'word'},$in{'view'},$in{'cond'},1);

		$enwd = &url_enc($in{'word'});
		if ($back >= 0) {
			print "[<a href=\"$script?mode=find&page=$back&word=$enwd&view=$in{'view'}&cond=$in{'cond'}\">이전 $in{'view'}건</a>]\n";
		}
		if ($next < $i) {
			print "[<a href=\"$script?mode=find&page=$next&word=$enwd&view=$in{'view'}&cond=$in{'cond'}\">다음 $in{'view'}건</a>]\n";
		}
	}

	print "</body></html>\n";
	exit;
}

#-------------------------------------------------
#  카운터 처리
#-------------------------------------------------
sub counter {
	local($count, $cntup, @count);

	# 조회할 때만 카운트 증가
	if ($mode eq '') { $cntup = 1; } else { $cntup = 0; }

	if ($lockMode) { &lock; }
	# 카운트 파일 읽기
	open(LOG,"+<$cntfile") || &error("Open Error : $cntfile (counter)");
#	eval "flock(LOG, 2);";
	$count = <LOG>;

	# IP 확인과 로그 손상 확인
	local($cnt, $ip) = split(/:/, $count);
	if ($addr eq $ip || $cnt eq "") { $cntup = 0; }

	# 카운트 증가
	if ($cntup) {
		$cnt++;
		truncate(LOG, 0);
		seek(LOG, 0, 0);
		print LOG "$cnt\:$addr";
	}
	close(LOG);
	if ($lockMode) { &unlock; }

	# 자릿수 조정
	while(length($cnt) < $mini_fig) { $cnt = '0' . $cnt; }
	@count = split(//, $cnt);

	# GIF 카운터 표시
	if ($Hcounter == 2) {
		foreach (0 .. $#count) {
			print "<img src=\"$gif_path$count[$_]\.gif\" alt=\"$count[$_]\" width=\"$mini_w\" height=\"$mini_h\">";
		}
	# 텍스트 카운터 표시
	} else {
		print "<span class='counter'>$cnt</span><br>\n";
	}
}

#-------------------------------------------------
#  이미지 미리보기표시
#-------------------------------------------------
sub image {
	local($i,$j,$stop);

	&header;
	print <<EOM;
<div align="center">
<h4>이미지 미리보기</h4>
<table class='n' border=1 cellpadding=5 cellspacing=0>
<tr>
EOM

#	@ico1 = split(/\s+/, $ico1);
#	@ico2 = split(/\s+/, $ico2);

	$i=0; $j=0;
	$stop = @ico1;
	foreach (0 .. $#ico1) {
		$i++; $j++;
		print "<th>";
		print "<img src=\"${HimageDir}/$ico1[$_]\" ALIGN=middle alt=\"$ico1[$_]\">" if($ico1[$_] ne '');
		print "<br>$ico2[$_]</th>\n";

		if ($j != $stop && $i >= 5) {
			print "</tr><tr>\n";
			$i=0;

		} elsif ($j == $stop) {
			if ($i == 0) { last; }
			while ($i < 5) { print "<th><br></th>"; $i++; }
		}
	}

	print <<EOM;
</tr></table>
<br>
<form>
<input type="button" value="창 닫기" onClick="top.close();">
</form>
</div>
</body>
</html>
EOM
	exit;
}

#-------------------------------------------------
#  HTML 생성
#-------------------------------------------------
sub log2html {
	my($htmlname, $maxline, $amity) = @_;
	my($i,$j,$flag,$htmlfile);
	$maxline = $max if($maxline <= 0 || $maxline > $max);
	# 푸터
	$footer = "</TD></TR></TABLE>\n";
	# 저작권 표시(삭제 불가): 단, MakiMaki 님의 이미지를 사용하지 않는 경우에 한해,
	# MakiMaki 님의 링크를 제거할 수 있음
	$footer .=<<EOM;
$banner2
<p>
<!-- $ver -->
<span style="font-size:10px; font-family:Verdana,Helvetica,Arial">
- <a href='http://www.kent-web.com/' target='_top'>KENT</a> &amp; 
<a href='http://village.infoweb.ne.jp/~fwhf2602/' target='_top'>MakiMaki</a> -
</span>
</div>
<div align='right'>$versionInfo patchworked by <a style="text-decoration:none;" href='http://hpcgi2.nifty.com/otacky/' target='_top'>neo_otacky</a>
EOM
	$footer .= "</div>\n</body>\n</html>\n";

	# 헤더
	my $header = '';
	$header .=<<"EOM";
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html lang="ko">
<head>
<META HTTP-EQUIV="Content-type" CONTENT="text/html; charset=utf-8">
<META HTTP-EQUIV="Content-Style-Type" content="text/css">
<link rel="stylesheet" type="text/css" href="${HyycssDir}/$HyycssDefault">
EOM

	$header .= "<title>$title</title></head>\n";
	if ($backgif) {
		$header .= "<body background=\"$backgif\">\n";
	} else {
		$header .= "$Body\n";
	}

	# 제목부
	$header .= "<div align=\"center\">\n";
	if ($banner1 ne "<!-- 상단 -->") { $header .= "$banner1<P>\n"; }
	if($maintitle eq '') {
		if ($t_img eq '') {
			$header .= "<DIV class='bbstitle'>$title</DIV>\n";
		} else {
			$header .= "<img src=\"$t_img\" width=\"$t_w\" height=\"$t_h\" alt=\"$title\">\n";
		}
	} else {
		$header .= "<DIV class='bbstitle'>$maintitle</DIV>\n";
	}

	$header .=<<EOM;
<hr width='90%'>
[<a href="$Htoppage" target='_top'>첫 페이지</a>]
[<a href="$HthisFile" target='_top'>$HtitleTag</a>]
EOM

	# 게시글 전개
	open(IN,"$logfile") || &error("Open Error : $logfile (html_log)");
	my @lines = <IN>;
	close(IN);
	$top = shift(@lines);
	# 중요 공지 삽입
	open(IN2,"$logfile2") || &error("Open Error : $logfile2 (html_log)");
	my $line2 = <IN2>;
	close(IN2);
	unshift(@lines, $line2);
	# 지난 로그 번호 파일
	open(NO,"$nofile") || &error("Open Error: $nofile");
	my $count = <NO>;
	close(NO);
	for(1..$count) {
		$pastfile = sprintf("%s%04d\.%s\.cgi", $pastdir,$_,($in{'ally'} eq '' ? 0 : $in{'ally'}));
		open(PIN,"$pastfile") || &error("Open Error: $pastfile");
		while (<PIN>) {
			push(@lines,$_);
		}
		close(PIN);
	}
	local($no,$re,$dat,$nam,$eml,$sub,$com,$url,$idname,$allyidname,$turn,$hos,$pw,$col,$ico);
	my @link;
	my $oya = 0;
	foreach (@lines) {
		($no,$re,$dat,$nam,$eml,$sub,$com,$url,$idname,$allyidname,$turn,$hos,$pw,$col,$ico) = split(/<>/);
		if ($re eq "" && $com ne "") { $oya++; }
	}
	my $rest = 1;
	if($oya > $maxline) {
		$j = int($oya / $maxline);
		$rest = $oya % $maxline;
		$j-- if(!$rest);
		foreach $i (0..$j) {
			$link[$i] = "[<span class='n'> page ";
			foreach (0..$j) {
				if($_ == $i) {
					$link[$i] .= "<B>$_</B> ";
				} else {
					$htmlfile = sprintf("%s%04d\.html", $htmlname,$_);
					$link[$i] .= "<a href='$htmlfile'>$_</a> ";
				}
			}
			$link[$i] .= "</span>]\n<hr width='90%'>";
		}
	} else {
		$link[0] = "<hr width='90%'>";
	}
	my $line = '';
	($i,$j,$flag) = (0,0,0);
	foreach (@lines) {
		($no,$re,$dat,$nam,$eml,$sub,$com,$url,$idname,$allyidname,$turn,$hos,$pw,$col,$ico) = split(/<>/);
		if ($re eq "") { $i++; }
		if($i > $maxline) {
			$htmlfile = sprintf("%s%04d\.html", $htmlname,$j);
			open(HTML, ">${HhtmlDir}/$htmlfile");
			print HTML $header;
			print HTML $link[$j];
			print HTML $line;
			print HTML $footer;
			close (HTML);
			chmod(0666,"${HhtmlDir}/$htmlfile");
			$i = 1;
			$j++;
			$line = '';
		}
		if($amity) {
			1 while $com =~ s/(.*)(&lt;(amity)&gt;(.*)&lt;\/amity&gt;)/$1<span class=\'amity\'>$4<\/span>/i;
		} else {
			1 while $com =~ s/(.*)(&lt;(amity)&gt;(.*)&lt;\/amity&gt;)/$1/i;
		}
		my($aidFrom, $aidTo) = split(/\,/, $allyidname);
		my $sPost = 0;
		my $sPostTitle;
		if($no eq '') {
			if($com eq '') { next; }
			$tbCol = 's';
			my $sName = $HallyTopName;
			$sName = $ally_name[0] if($allyidname eq '');
			$sPostTitle = "<B><font color='#FF0000' size=2>● ${sName}의 메시지 ●</font></B>";
			$sPost = 2;
		} else {
			if($aidTo ne '') {
				if($maintitle =~ /$aidTo/) {
					$tbCol = 'df';
					$sPostTitle = "<B><font color='#FF0000' size=2>● 외교 문서 수신 내용 ●</font>　From:${aidFrom}</B>";
				} elsif($maintitle =~ /$aidFrom/) {
					$tbCol = 'dt';
					$sPostTitle = "<B><font color='#FF0000' size=2>● 외교 문서 송신 내용 ●</font>　To:${aidTo}</B>";
				} else {
					$tbCol = 'd';
					$sPostTitle = "<B><font color='#FF0000' size=2>● 외교 문서 ●</font>　From:${aidFrom}　To:${aidTo}</B>";
				}
				$sPost = ($DiploRes) ? 1 : 2;
			} else {
				$tbCol = 'n';
			}
		}
		# 제목 길이
		if (length($sub) > $sub_len*2) {
			$sub = substr($sub,0,$sub_len*2);
			$sub .= "...";
		}

		if ($eml) { $nam = "<a href=\"mailto:$eml\">$nam</a>"; }
		if ($home_icon && $url) {
			$url = "<a href=\"$url\" target=\"_blank\"><img src=\"${HimageDir}/$home_gif\" border=0 align=top alt='HomePage' width=\"$home_wid\" height=\"$home_hei\"></a>";
		} elsif (!$home_icon && $url) {
			$url = "&lt;<a href=\"$url\" target=\"_blank\">Home</a>&gt;";
		}
		if (!$iconMode) { $com = "<blockquote>$com</blockquote>"; }

		if (!$re && $flag) {
			$line .= "</TD></TR></TABLE><br><br>\n";
			$flag=1;
		}
		if (!$re) {
			$line .= "<table class='$tbCol' BORDER=1 WIDTH='90%' CELLSPACING=0 CELLPADDING=2><TR><TD>\n";
			$flag=1;
		}

		if ($re) { $line .= "<hr noshade size=1 width='85%'>\n"; }
		if($sPost) { $line .= "<table class='s$tbCol' border=0 width='100%' cellpadding=1><tr><td>$sPostTitle</td></tr></table>\n"; }
		$line .= "<table class='v' border=0 cellpadding=2><tr>\n";
		if ($re) { $line .= "<td rowspan=2 width=40><br></td>"; }

		$line .= "<td valign=top nowrap><span class='subject'>$sub</span>　";

		my $iName = '';
		if($allyidname ne '') {
			if($idname eq '0') {
				$iName = "${atMark}$ally_name[0]";
			} elsif($idname ne '') {
				$iName = "${atMark}${idname}${AfterName}";
			}
		}
		my $turnStr = " [턴<span class='turn'>$turn</span>] " if($turn);
		if (!$re) { $line .= "작성자：<b>${nam}${iName}</b> 등록일：${dat}${turnStr}"; }
		else { $line .= "<b>${nam}${iName}</b> - ${dat}${turnStr}"; }

		if ($no ne '') { $line .= "<span class='number'>No\.$no</span></td>"; }
		$line .= "<td valign=top nowrap> &nbsp; $url </td><td valign=top>\n";
		$line .= "<br></td>\n";

		$line .= "</tr></table><table class='v' border=0 cellpadding=5><tr>\n";
		if ($re) { $line .= "<td width=32><br></td>\n"; }

		# 아이콘 모드
		if ($iconMode && ($ico ne '')) { $line .= "<td><img src=\"${HimageDir}/$ico\" alt=\"$ico\"></td>"; }
		# URL 자동 링크
		if ($autolink) { &auto_link($com); }

		$line .= "<td class='comment'><span style=\"color:$col;\">$com</span></td></tr></table>\n";
	}
	if($rest || $j) {
		$htmlfile = sprintf("%s%04d\.html", $htmlname,$j);
		open(HTML, ">${HhtmlDir}/$htmlfile");
		print HTML $header;
		print HTML $link[$j];
		print HTML $line;
		print HTML $footer;
		close (HTML);
		chmod(0666,"${HhtmlDir}/$htmlfile");
	}
	$htmlfile = sprintf("%s%04d\.html", $htmlname,0);
	if (-e "${HhtmlDir}/$htmlfile") {
#		if ($ENV{'PERLXS'} eq "PerlIS") {
#			print "HTTP/1.0 302 Temporary Redirection\r\n";
#			print "Content-type: text/html; charset=utf-8\n";
#		}
#		print "Location: ${htmlDir}/$htmlfile\n\n";
		&header;
		print <<EOM;
<div align="center">
<hr width=400>
<h3>정상적으로 처리되었습니다</h3>
<hr width=400>
<a href="${htmlDir}/$htmlfile">$htmlfile</a></div>
</body>
</html>
EOM
	} elsif(!$oya) {
		&header;
		print <<EOM;
<div align="center">
<hr width=400>
<h3>게시글이 없어 HTML로 만들 수 없습니다.</h3>
<hr width=400>
</body>
</html>
EOM
	} else {
		&header;
		print <<EOM;
<div align="center">
<hr width=400>
<h3>알 수 없는 이유로 HTML로 만들 수 없습니다.</h3>
<hr width=400>
</body>
</html>
EOM
	}
	exit;
}

#------------------#
#  확인 모드  #
#------------------#
sub check {
	&header;
	print <<EOM;
<h2>Check Mode</h2>
<ul>
EOM

	# 로그 확인
	local(%path) = (
		$logfile, "로그 파일",
		$cntfile, "카운트 파일",
	);
	foreach ( $logfile, $cntfile ) {
		# 경로
		if (-e $_) {
			print "<li>$path{$_}경로 : OK\n";

			# 권한
			if (-r $_ && -w $_) {
				print "<li>$path{$_}권한 : OK\n";
			} else {
				print "<li>$path{$_}권한 : NG\n";
			}
		} else {
			print "<li>$path{$_}경로 : NG → $_\n";
		}
	}
	# 잠금 디렉터리
	print "<li>잠금 방식：";
	if ($lockMode == 0) {
		print "잠금 설정 없음\n";
	} else {
		if ($lockMode == 1) { print "mkdir\n"; }
		elsif ($lockMode == 2) { print "flock\n"; }
		elsif ($lockMode == 3) { print "symlink\n"; }
		else { print "rename\n"; }

		($lockdir) = $lockfile =~ /(.*)[\\\/].*$/;
		print "<li>잠금 디렉터리：$lockdir\n";

		if (-d $lockdir) { print "<li>잠금 디렉터리 경로：OK\n"; }
		else { print "<li>잠금 디렉터리 경로：NG → $lockdir\n"; }

		if (-r $lockdir && -w $lockdir && -x $lockdir) {
			print "<li>잠금 디렉터리 권한：OK\n";
		} else {
			print "<li>잠금 디렉터리 권한：NG → $lockdir\n";
		}
	}

	# 지난 로그
	print "<li>지난 로그：";
	if ($Hpastkey == 0) {
		print "설정 없음\n";
	} else {
		print "설정 있음\n";

		# 번호 파일
		if (-e $nofile) { print "<li>번호 파일경로：OK\n"; }
		else { print "<li>번호 파일 경로：NG → $nofile\n"; }
		if (-r $nofile && -w $nofile) { print "<li>번호 파일권한：OK\n"; }
		else { print "<li>번호 파일권한：NG → $nofile\n"; }

		# 디렉터리
		if (-d $pastdir) { print "<li>지난 로그 디렉터리경로：OK\n"; }
		else { print "<li>지난 로그 디렉터리 경로：NG → $pastdir\n"; }
		if (-r $pastdir && -w $pastdir && -x $pastdir) {
			print "<li>지난 로그 디렉터리권한：OK\n";
		} else {
			print "<li>지난 로그 디렉터리권한：NG → $pastdir\n";
		}
	}

	# 등록 키
	if ($regist_key) {
		print "<li><a href=\"$registkeycgi?check\">등록 키 이미지 확인</a>";
	}

	print <<EOM;
</ul>
</body>
</html>
EOM
	exit;
}

__END__
