#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}
#----------------------------------------------------------------------
# JavaScript판 -ver1.11-
# 사용 조건, 사용 방법은  배포처를 확인하세요.
# 부속의 js-readme.txt 모오읽기하세요.
# 앗포:http://appoh.execweb.cx/hakoniwa/
#----------------------------------------------------------------------

#----------------------------------------------------------------------
# 의사MAP데이터 생성
#----------------------------------------------------------------------
sub landStringFlash {
	my($mode) = @_;
	my($island);
	$island = $Hislands[$HcurrentNumber];
	my($land) = $island->{'land'};
	my($landValue) = $island->{'landValue'};
	my($l, $lv);
	my($code) = "";
	my($befor) = "a";
	my($Count) = 0;
	my($Comp) = "";
	my($ret) = "";

	# 각 지형을 출력
	my($x, $y);
	foreach $y (0..$islandSize) {

		# 각 지형을 출력
		foreach $x (0..$islandSize) {
			$l = $land->[$x][$y];
			$lv = $landValue->[$x][$y];
			$code = landFlashData($l, $lv, $mode);

			if ($code eq $befor) {
				$Count++;
			} else {
				$Comp.= $befor;
				if( $Count != 0){
					$Comp.= ($Count - 1);
				}
				$Count = 0;
				$befor = $code;
			}
		}
	}
	if($befor ne "a"){
		$Comp.= $befor;
		if( $Count != 0){
			$Comp.= ($Count - 1);
		}
	}
	$Comp.= "\@";
	$Comp = substr($Comp,1);

	# 각 지형을 출력
	my($Compjs) = "";
	foreach $x (0..$islandSize) {

		# 각 지형을 출력
		foreach $y (0..$islandSize) {
			$l = $land->[$x][$y];
			$lv = $landValue->[$x][$y];
			$code = landFlashData($l, $lv, $mode);
			$Compjs.= $code;
		}
	}


	out(<<END);
<DIV ID='mkudoMap'><FORM>
의사MAP작성도구용 데이터(FLASH 판)<BR>
<TEXTAREA NAME="FLASH" cols="50" rows="3">$Comp</TEXTAREA><br>
<A HREF="http://www.din.or.jp/~mkudo/hako/flash/hako-map.html">
의사MAP작성도구(FLASH 판)을 온라인으로 시작</a><P>
의사MAP작성도구용 데이터(JavaScript판)<BR>
<TEXTAREA NAME="FLASH" cols="50" rows="4">$Compjs</TEXTAREA><br>
<A HREF="http://www.din.or.jp/~mkudo/hako/javascript/map.html">
의사MAP작성도구(JavaScript판)을 온라인으로 시작</a><BR><BR><BR>
<A HREF="http://www.din.or.jp/~mkudo/hako/">
의사MAP작성도구(JAVA·FLASH 판)을 다운로드하기</a><p>
</FORM>
</DIV>
END

}

sub landFlashData {
	my($l, $lv, $mode) = @_;
	my($flash_data);

	if($l == $HlandSea) {
		# 얕은 바다
		if($lv == 1) {
			$flash_data = "o";
		} else {
			# 바다
			$flash_data = "a";
		}
	} elsif($l == $HlandWaste) {
		# 황무지
		if($lv == 1) {
			# 착탄 지점
			$flash_data = "n";
		} else {
			$flash_data = "b";
		}
	} elsif($l == $HlandPlains) {
		# 평지
		$flash_data = "c";
	} elsif($l == $HlandForest) {
		# 숲
		$flash_data = "g";
	} elsif($l == $HlandTown) {
		if($lv < 30) {
			# 마을
			$flash_data = "d";
		} elsif($lv < 100) {
			# 읍
			$flash_data = "e";
		} else {
			# 도시
			$flash_data = "f";
		}
	} elsif($l == $HlandFarm) {
		# 농장
		$flash_data = "h";
	} elsif($l == $HlandFactory) {
		# 공장
		$flash_data = "i";
	} elsif($l == $HlandBase) {
		# 자신의 섬은 미사일 기지가 됨
		if($mode == 1) {
			$flash_data = "j";
			# 자신의 섬이외는 미사일 기지는 숲이 됨
		} else {
			$flash_data = "g";
		}
	} elsif($l == $HlandDefence) {
		# 자신의 섬은 방위 시설이 됨
		if($mode == 1) {
			$flash_data = "k";
			# 자신의 섬이외는 방위 시설은 숲이 됨(숲에위장하지 않은 경우'k'와 하다)
		} else {
			$flash_data = "g";
		}
	} elsif($l == $HlandHaribote) {
		# 가짜 시설
		$flash_data = "k";
	} elsif($l == $HlandOil) {
		# 해저 유전
		$flash_data = "q";
	} elsif($l == $HlandMountain) {
		# 산
		if($lv> 0) {
			$flash_data = "p"; # 채굴장
		} else {
			$flash_data = "l";
		}
		#} elsif($l == $HlandMonument) {
		# 기념비
		# $flash_data = "b";
	} else {
		# 기타
		$flash_data = "b";
	}
	return $flash_data;
}

#----------------------------------------------------------------------
# 외부 js 파일작성
#----------------------------------------------------------------------
sub makeJS {
	my($mode) = @_;

	my($src);

	$src = <<"END";

function init() {
	for(i = 0; i < command.length ;i++) {
		for(s = 0; s < $com_count ;s++) {
			var comlist2 = comlist[s];
			for(j = 0; j < comlist2.length ; j++) {
				if(command[i][0] == comlist2[j][0]) {
					g[i] = comlist2[j][1];
				}
			}
		}
	}
	outp();
	str = plchg();
	str = "<TABLE border=0><TR><TD class='commandjs1'><B>---- 전송 완료 ----</B><br><br>"+str+"<br><B>---- 전송 완료 ----</B></TD></TR></TABLE>";
	disp(str, "#ccffcc");

	check_menu();
	if((document.layers) || (document.all)){ // IE4,IE5,NN4
		window.document.onmouseup = menuclose;
	}
}

function cominput(theForm, x, k) {
	a = theForm.NUMBER.options[theForm.NUMBER.selectedIndex].value;
	b = theForm.COMMAND.options[theForm.COMMAND.selectedIndex].value;
	c = theForm.POINTX.options[theForm.POINTX.selectedIndex].value;
	d = theForm.POINTY.options[theForm.POINTY.selectedIndex].value;
	e = theForm.AMOUNT.options[theForm.AMOUNT.selectedIndex].value;
	f = theForm.TARGETID.options[theForm.TARGETID.selectedIndex].value;
	if(x == 6){ b = k; menuclose();	}
	if (x == 1 || x == 6){
		for(i = $HcommandMax - 1; i> a; i--) {
			command[i] = command[i-1];
			g[i] = g[i-1];
		}
	}else if(x == 3){
		for(i = Math.floor(a); i < ($HcommandMax - 1); i++) {
			command[i] = command[i + 1];
			g[i] = g[i+1];
		}
		command[$HcommandMax-1] = [$HcomDoNothing,0,0,0,0];
		g[$HcommandMax-1] = '자금융통';
		str = plchg();
		str = "<TABLE border=0><TR><TD class='commandjs2'><B>-----미전송-----</B><br><br>"+str+"<br><B>-----미전송-----</B></TD></TR></TABLE>";
		disp(str,"white");
		outp();
		return true;
	}else if(x == 4){
		i = Math.floor(a)
			if (i == 0){ return true; }
		i = Math.floor(a)
			tmpcom1[i] = command[i];tmpcom2[i] = command[i - 1];
		command[i] = tmpcom2[i];command[i-1] = tmpcom1[i];
		k1[i] = g[i];k2[i] = g[i - 1];
		g[i] = k2[i];g[i-1] = k1[i];
		ns(--i);
		str = plchg();
		str = "<TABLE border=0><TR><TD class='commandjs2'><B>-----미전송-----</B><br><br>"+str+"<br><B>-----미전송-----</B></TD></TR></TABLE>";
		disp(str,"white");
		outp();
		return true;
	}else if(x == 5){
		i = Math.floor(a)
			if (i == $HcommandMax-1){ return true; }
		tmpcom1[i] = command[i];tmpcom2[i] = command[i + 1];
		command[i] = tmpcom2[i];command[i+1] = tmpcom1[i];
		k1[i] = g[i];k2[i] = g[i + 1];
		g[i] = k2[i];g[i+1] = k1[i];
		ns(++i);
		str = plchg();
		str = "<TABLE border=0><TR><TD class='commandjs2'><B>-----미전송-----</B><br><br>"+str+"<br><B>-----미전송-----</B></TD></TR></TABLE>";
		disp(str,"white");
		outp();
		return true;
	}

	for(s = 0; s < $com_count ;s++) {
		var comlist2 = comlist[s];
		for(i = 0; i < comlist2.length; i++){
			if(comlist2[i][0] == b){
				g[a] = comlist2[i][1];
				break;
			}
		}
	}
	command[a] = [b,c,d,e,f];
	ns(++a);
	str = plchg();
	str = "<TABLE border=0><TR><TD class='commandjs2'><B>-----미전송-----</B><br><br>"+str+"<br><B>-----미전송-----</B></TD></TR></TABLE>";
	disp(str, "white");
	outp();
	return true;
}

function plchg() {
	strn1 = '';
	for(i = 0; i < $HcommandMax; i++)	{
		c = command[i];
		if(g[i] == 0) { g[i] = '이 명령은 사용할 수 없습니다'; }
		kind = '$HtagComName_' + g[i] + '$H_tagComName';
		x = c[1];
		y = c[2];
		tgt = '';
		point = '${HtagName_}(' + x + ',' + y + ')${H_tagName}';
		for(j = 0; j < islname.length ; j++) {
			if(c[4] == islname[j][0]){
				tgt = '$HtagName_' + islname[j][1] + '${H_tagName}';
				break;
			}
		}
		if(tgt == ''){
			tgt = '무인 섬';
		}
		if(c[0] == $HcomDoNothing ||
		 c[0] == $HcomSave ||
		 c[0] == $HcomLoad ||
		 c[0] == $HcomGiveup){ // 자금융통, 섬 포기
			 strn2 = kind;
		}else if(c[0] == $HcomAlly) { // 동맹 가입·탈퇴
			strn2 = tgt + '의' + kind;
		}else if(c[0] == $HcomArmSupply){ // 군사 물자 조달
			if(c[3] == 0){ c[3] = 1; }
			arg = '($HtagName_' + c[3] + '개${H_tagName})';
			strn2 = kind + arg;
		}else if(c[0] == $HcomMissileNM || // 미사일 관련
				 c[0] == $HcomMissilePP ||
				 c[0] == $HcomMissileSPP ||
				 c[0] == $HcomMissileST ||
				 c[0] == $HcomMissileSS ||
				 c[0] == $HcomMissileLR ||
				 c[0] == $HcomMissileLD){
			if(c[3] == 0){
				arg = '($HtagName_무제한${H_tagName})';
			} else {
				arg = '($HtagName_' + c[3] + '발${H_tagName})';
			}
			strn2 = tgt + point + '로' + kind + arg;
		}else if(c[0] == $HcomEiseiLzr){ // 인공위성레자
			strn2 = tgt + point + '로' + kind;
		}else if(c[0] == $HcomSendMonster){ // 괴수 파견
			strn2 = tgt + '로' + kind;
		}else if(c[0] == $HcomSell){ // 식량 수출
			if(c[3] == 0){ c[3] = 1; }
			arg = c[3] * (- ($HcomCost[$HcomSell]));
			arg = '($HtagName_' + arg + '$HunitFood${H_tagName})';
			strn2 = kind + arg;
		}else if(c[0] == $HcomPropaganda){ // 유치 활동
			if(c[3] == 0){ c[3] = 1; }
			if(c[3] == 1){
				strn2 = kind;
			} else {
				arg = '($HtagName_' + c[3] + '회${H_tagName})';
				strn2 = kind + arg;
			}
		}else if(c[0] == $HcomMoney){ // 자금지원
			if(c[3] == 0){ c[3] = 1; }
			arg = c[3] * $HcomCost[$HcomMoney];
			arg = '($HtagName_' + arg + '$HunitMoney${H_tagName})';
			strn2 = tgt + '로' + kind + arg;
		}else if(c[0] == $HcomFood){ // 식량지원
			if(c[3] == 0){ c[3] = 1; }
			arg = c[3] * (- ($HcomCost[$HcomFood]));
			arg = '($HtagName_' + arg + '$HunitFood${H_tagName})';
			strn2 = tgt + '로' + kind + arg;
		}else if(c[0] == $HcomDestroy){ // 굴착
			if(c[3] == 0){
				strn2 = point + ' ' + kind;
			} else {
				arg = c[3] * $HcomCost[$HcomDestroy];
				arg = '(예정\계산$HtagName_' + arg + '$HunitMoney${H_tagName})';
				strn2 = point + ' ' + kind + arg;
			}
		}else if(c[0] == $HcomOnsen){ // 온천 굴착
			if(c[3] == 0){ c[3] = 1; }
			arg = c[3] * $HcomCost[$HcomOnsen];
			arg = '(예정\계산$HtagName_' + arg + '$HunitMoney${H_tagName})';
			strn2 = point + ' ' + kind + arg;
		}else if(c[0] == $HcomFarm || // 농장, 공장, 채굴장 건설
				 c[0] == $HcomFoodim ||
				 c[0] == $HcomFactory ||
				 c[0] == $HcomNursery ||
				 c[0] == $HcomBoku ||
				 c[0] == $HcomPark ||
				 c[0] == $HcomUmiamu ||
				 c[0] == $HcomMountain ||
				 c[0] == $HcomKai ||
				 c[0] == $HcomHTget ||
				 c[0] == $HcomGivefood ||
				 c[0] == $HcomPropaganda) {
			if(c[3] == 0){ c[3] = 1; }
			if(c[3] != 1){
				arg = '($HtagName_' + c[3] + '회${H_tagName})';
				strn2 = point + ' ' + kind + arg;
			}else{
				strn2 = point + ' ' + kind;
			}
		}else if(c[0] == $HcomMine) { // 지뢰설치
			if(c[3] == 0){ c[3] = 1; }
			if(c[3]> 9){ c[3] = 9; }
			arg = '(피해$HtagName_' + c[3] + '${H_tagName})';
			strn2 = point + ' ' + kind + arg;
		}else if(c[0] == $HcomFune || // 조선, 목장, 기념비건설
				 c[0] == $HcomFarmcpc ||
				 c[0] == $HcomMonument) {
			if(c[3] == 0){
				strn2 = point + ' ' + kind;
			} else {
				arg = '($HtagName_' + c[3] + '${H_tagName})';
				strn2 = point + ' ' + kind + arg;
			}
		}else if(c[0] == $HcomEisei || // 인공위성 발사, 관리, 파괴
				 c[0] == $HcomEiseimente ||
				 c[0] == $HcomEiseiAtt) {
			if((c[3]>= 7) || (c[3] == 0)) { c[3] = 1; }
			if(c[3] == 1){ arg = '<B>$HeiseiName[1]</B>'; }
			else if(c[3] == 2){ arg = '<B>$HeiseiName[2]</B>'; }
			else if(c[3] == 3){ arg = '<B>$HeiseiName[3]</B>'; }
			else if(c[3] == 4){ arg = '<B>$HeiseiName[4]</B>'; }
			else if(c[3] == 5){ arg = '<B>$HeiseiName[5]</B>'; }
			else if(c[3] == 6){ arg = '<B>$HeiseiName[6]</B>'; }
			if(c[0] == $HcomEisei){
				strn2 = '$HtagComName_' + arg + '발사$H_tagComName';
			} else if(c[0] == $HcomEiseimente){
				strn2 = '$HtagComName_' + arg + '복구$H_tagComName';
			} else if(c[0] == $HcomEiseiAtt){
				strn2 = tgt + '의' + arg + '로' + kind;
			}
		}else{
			strn2 = point + ' ' + kind;
		}
		tmpnum = '';
		if(i < 9){ tmpnum = '0'; }
		strn1 +=
			'<A STYLE="text-decoration:none;" HREF="JavaScript:void(0);" onClick="ns(' + i + ')">$HtagNumber_' +
				tmpnum + (i + 1) + ':$H_tagNumber<FONT SIZE=-1>$HnormalColor_' +
					strn2 + '$H_normalColor</FONT></A><BR>\\n';
	}
	return strn1;
}

function disp(str,bgclr) {
	if(str==null) str = "";

	if(document.getElementById){
		document.getElementById("LINKMSG1").innerHTML = str;
//		document.getElementById("plan").bgColor = bgclr;
	} else if(document.all){
		el = document.all("LINKMSG1");
		el.innerHTML = str;
//		document.all.plan.bgColor = bgclr;
	} else if(document.layers) {
		lay = document.layers["PARENT_LINKMSG"].document.layers["LINKMSG1"];
		lay.document.open();
		lay.document.write("<font style='font-size:11pt'>"+str+"</font>");
		lay.document.close();
//		document.layers["PARENT_LINKMSG"].bgColor = bgclr;
	}
}

function outp() {
	comary = "";

	for(k = 0; k < command.length; k++){
		comary = comary + command[k][0]
			+" "+command[k][1]
				+" "+command[k][2]
					+" "+command[k][3]
						+" "+command[k][4]
							+" ";
	}
	document.myForm.COMARY.value = comary;
}

function ps(x, y) {
	with (document.myForm) {
		elements[4].options[x].selected = true;
		elements[5].options[y].selected = true;
		with (elements[7]) {
			var i;
			for (i = 0; i < length; i++) {
				if (options[i].value == d_ID) {
					options[i].selected = true;
					break;
				}
			}
		}
	}
	document.allForm.POINTX.value = x;
	document.allForm.POINTY.value = y;
	if(!(document.myForm.MENUOPEN.checked))
		moveLAYER("menu",mx,my);
	return true;
}

function ns(x) {
	if (x == $HcommandMax){ return true; }
	document.myForm.elements[0].options[x].selected = true;
	document.allForm.NUMBER.value = x;
	return true;
}

function set_land(x, y, land, img) {
	com_str = land + "\\n";
	for(i = 0; i < $HcommandMax; i++)	{
		c = command[i];
		x2 = c[1];
		y2 = c[2];
		if(x == x2 && y == y2 && (c[0] < 30 ||(c[0]> 69 && c[0] < 80))){
			com_str += "[" + (i + 1) +"]" ;
			kind = g[i];
			if(c[0] == $HcomDestroy){
				if(c[3] == 0){
					com_str += kind;
				} else {
					arg = c[3] * 200;
					arg = "(예정\계산" + arg + "$HunitMoney)";
					com_str += kind + arg;
				}
			}else if(c[0] == $HcomFarm ||
					 c[0] == $HcomNursery ||
					 c[0] == $HcomFactory ||
					 c[0] == $HcomMountain ||
					 c[0] == $HcomFoodim ||
					 c[0] == $HcomBoku ||
					 c[0] == $HcomPark ||
					 c[0] == $HcomUmiamu) {
				if(c[3] == 0){ c[3] = 1; }
				if(c[3] != 1){
					arg = "(" + c[3] + "회)";
					com_str += kind + arg;
				}else{
					com_str += kind;
				}
			}else if(c[0] == $HcomFune || // 조선, 목장, 기념비건설
					 c[0] == $HcomFarmcpc ||
					 c[0] == $HcomMonument) {
				if(c[3] == 0){
					com_str += kind;
				} else {
					arg = "(" + c[3] + ")";
					com_str += kind + arg;
				}
			}else{
				com_str += kind;
			}
			com_str += " ";
		}
	}
	document.POPUP.COMSTATUS.value= com_str;
	document.POPUP.NAVIIMG.src= img;
}

function set_com(x, y, land) {
	com_str = land + "\\n";
	for(i = 0; i < $HcommandMax; i++)	{
		c = command[i];
		x2 = c[1];
		y2 = c[2];
		if(x == x2 && y == y2 && (c[0] < 30 ||(c[0]> 69 && c[0] < 80))){
			com_str += "[" + (i + 1) +"]" ;
			kind = g[i];
			if(c[0] == $HcomDestroy){
				if(c[3] == 0){
					com_str += kind;
				} else {
					arg = c[3] * 200;
					arg = "(예정\계산" + arg + "$HunitMoney)";
					com_str += kind + arg;
				}
			}else if(c[0] == $HcomFarm ||
					 c[0] == $HcomNursery ||
					 c[0] == $HcomFactory ||
					 c[0] == $HcomMountain ||
					 c[0] == $HcomFoodim ||
					 c[0] == $HcomBoku ||
					 c[0] == $HcomPark ||
					 c[0] == $HcomUmiamu) {
				if(c[3] == 0){ c[3] = 1; }
				if(c[3] != 1){
					arg = "(" + c[3] + "회)";
					com_str += kind + arg;
				}else{
					com_str += kind;
				}
			}else if(c[0] == $HcomFune || // 조선, 목장, 기념비건설
					 c[0] == $HcomFarmcpc ||
					 c[0] == $HcomMonument) {
				if(c[3] == 0){
					com_str += kind;
				} else {
					arg = "(" + c[3] + ")";
					com_str += kind + arg;
				}
			}else{
				com_str += kind;
			}
			com_str += " ";
		}
	}
	document.myForm.COMSTATUS.value= com_str;
}

function not_com() {
//	document.myForm.COMSTATUS.value="";
}

function myisland(theForm,myid) {
	for(i = 0; i < islname.length ;i++) {
		if(islname[i][0] == myid) {
			break;
		}
	}
	theForm.TARGETID.selectedIndex = i;
}

function jump(theForm, j_mode) {
	var sIndex = theForm.TARGETID.selectedIndex;
	var url = theForm.TARGETID.options[sIndex].value;
	if (url != "" ) window.open("$HthisFile?IslandMap=" +url+"&JAVAMODE="+j_mode, "", "menubar=yes,toolbar=no,location=no,directories=no,status=yes,scrollbars=yes,resizable=yes,width=450,height=630");
}

function SelectList(theForm) {
	var u, selected_ok;
	if(!theForm){s = ''}
	else { s = theForm.menu.options[theForm.menu.selectedIndex].value; }
	if(s == ''){
		u = 0; selected_ok = 0;
		document.myForm.COMMAND.options.length = All_list;
		for (i=0; i<comlist.length; i++) {
			var command = comlist[i];
			for (a=0; a<command.length; a++) {
				comName = command[a][1] + "(" + command[a][2] + ")";
				document.myForm.COMMAND.options[u].value = command[a][0];
				document.myForm.COMMAND.options[u].text = comName;
				if(command[a][0] == d_Kind){
					document.myForm.COMMAND.options[u].selected = true;
					selected_ok = 1;
				}
				u++;
			}
		}
		if(selected_ok == 0)
			document.myForm.COMMAND.selectedIndex = 0;
	} else {
		var command = comlist[s];
		document.myForm.COMMAND.options.length = command.length;
		for (i=0; i<command.length; i++) {
			comName = command[i][1] + "(" + command[i][2] + ")";
			document.myForm.COMMAND.options[i].value = command[i][0];
			document.myForm.COMMAND.options[i].text = comName;
			if(command[i][0] == d_Kind){
				document.myForm.COMMAND.options[i].selected = true;
				selected_ok = 1;
			}
		}
		if(selected_ok == 0)
			document.myForm.COMMAND.selectedIndex = 0;
	}
}

function chkwindowsize(){ // 이함수에서  창의 대크기를 조사하기. 320x365,372x464
// body.clientWidth 은, 페이지구성건축후에만가져오기할 수 없으므로, 함수로 하고 onload 후에호출출하합니다.
	if (document.all){
		wX = document.body.clientWidth; // 가로 축
		wY = document.body.clientHeight; // 세로 축
	} else {
		wX = window.innerWidth;
		wY = window.innerHeight;
	}
// NN 용,4.7모6모사용 가능.
}

function moveLAYER(layName,x,y) {
	winX = 210; winY = 350; //팝업 메뉴의 가로 세로의 크기
	chkwindowsize();
	if(x + winX*3/4> wX) { cX = -20 - winX; } else { cX = 10; }
	if(y + winY/2> wY) { cY = 30 - winY; } else if(y + winY> wY){ cY = 30 - winY/2; } else { cY = -30; }
	if(document.getElementById){		//NN6,IE5
		if(document.all){				//IE5
			if(event.clientX + winX*3/4> wX) { cX = -20 - winX; } else { cX = 10; }
			if(event.clientY + winY/2> wY) { cY = 30 - winY; } else if(event.clientY + winY> wY){ cY = 30 - winY/2; } else { cY = -30; }
			el = document.getElementById(layName);
			el.style.left= event.clientX + document.body.scrollLeft + cX;
			el.style.top= event.clientY + document.body.scrollTop + cY;
			el.style.display = "block";
			el.style.visibility ='visible';
		}else{
			el = document.getElementById(layName);
			el.style.left=x + cX;
			el.style.top=y + cY;
			el.style.display = "block";
			el.style.visibility ='visible';
		}
	} else if(document.layers){				//NN4
		msgLay = document.layers[layName];
		msgLay.moveTo(x + cX,y + cY);
		msgLay.visibility = "show";
	} else if(document.all){				//IE4
		msgLay = document.all(layName);
		msgLay.style.pixelLeft = x + cX;
		msgLay.style.pixelTop = y + cY;
		msgLay.style.display = "block";
		msgLay.style.visibility = "visible";
	}

}

function menuclose() {
	if (document.getElementById){
		document.getElementById("menu").style.display = "none";
	} else if (document.layers){
		document.menu.visibility = "hide";
	} else if (document.all){
		window["menu"].style.display = "none";
	}
}

function check_menu() {
	if(!(document.myForm.MENUOPEN.checked)){
		if(document.getElementById){ //NN6,IE5
			document.onmousemove = Mmove;
			document.onkeydown = Kdown;
		} else if(document.layers){ // NN4 KEYDOWN 이벤트는 Win98계로 문자 깨짐하다이므로 코멘트화
			window.captureEvents(Event.MOUSEMOVE);
//			window.captureEvents(Event.MOUSEMOVE | Event.KEYDOWN);
			window.onMouseMove = Mmove;
//			window.onKeyDown = Kdown;
		} else if(document.all){ // IE4
			document.onmousemove = Mmove;
			document.onkeydown = Kdown;
		}
		document.allForm.MENUOPEN.value="";
	}else{
		document.allForm.MENUOPEN.value="on";
	}
}

function Mmove(e) {
	if(document.all){
		mx = event.x;
		my = event.y;
	}else if(document.layers){
		mx = e.pageX;
		my = e.pageY;
	}else if(document.getElementById){
		mx = e.pageX;
		my = e.pageY;
	}
}

function Kdown(e) {
	var c, el;
	if(document.all){
		if (event.altKey || event.ctrlKey || event.shiftKey) return;
		c = event.keyCode;
		el = new String(event.srcElement.tagName);
		el = el.toUpperCase();
		if (el == "INPUT") return;
//	}else if(document.layers){// NN4 KEYDOWN 이벤트는 Win98계로 문자 깨짐하다이므로 코멘트화
//		if (e.modifiers != 0) return;
//		c = e.which;
//		if ((c>= 97) && (c <= 122)) c -= 32; // 영어소문자를 영어대문자로
//		el = new String(e.target);
//		el = el.toUpperCase();
//		if (el.indexOf("<INPUT")>= 0) return;
		}else if(document.getElementById){
			if (e.altKey || e.ctrlKey || e.shiftKey) return;
			c = e.which;
			el = new String(e.target.tagName);
			el = el.toUpperCase();
			if (el == "INPUT") return;
		}
	c = String.fromCharCode(c);

	// 눌린 키에 따라 계획 번호를 설정
	switch (c) {
		case 'M': c = $HcomMine; break; // 지뢰설치
		case 'D': c = $HcomMissileLD; break; // 육지 파괴탄환 발사
		case 'S': c = $HcomMissileSPP; break; // SPP 미사일 발사
		case 'R': c = $HcomMissileLR; break; // 지형융기탄환 발사
		case '-': c = $HcomDoNothing; break; //INS 자금융통
		case '.': cominput(myForm,3); return; //DEL 삭제
		case 'W': chkwindowsize(); alert("가로 축:"+wX+", "+"세로 축"+wY); return;
		case'\b': //BS 하나전 삭제
			var no = document.myForm.COMMAND.selectedIndex;
			if(no> 0) document.myForm.COMMAND.selectedIndex = no - 1;
			cominput(myForm,3);
			return;
		case '0':case'`': document.myForm.AMOUNT.selectedIndex = 0; return;
		case '1':case'a': document.myForm.AMOUNT.selectedIndex = 1; return;
		case '2':case'b': document.myForm.AMOUNT.selectedIndex = 2; return;
		case '3':case'c': document.myForm.AMOUNT.selectedIndex = 3; return;
		case '4':case'd': document.myForm.AMOUNT.selectedIndex = 4; return;
		case '5':case'e': document.myForm.AMOUNT.selectedIndex = 5; return;
		case '6':case'f': document.myForm.AMOUNT.selectedIndex = 6; return;
		case '7':case'g': document.myForm.AMOUNT.selectedIndex = 7; return;
		case '8':case'h': document.myForm.AMOUNT.selectedIndex = 8; return;
		case '9':case'i': document.myForm.AMOUNT.selectedIndex = 9; return;
		default:
			// IE에서는 새로 고침용 F5까지 잡히므로 여기에서 처리할 필요가 없음
				return;
	}
	cominput(document.myForm, 6, c);
}
END

	if($mode) {
		open(OUT,">${HefileDir}/hakojima.js");
#		print OUT $src;
		print OUT $src;
		close(OUT);
		chmod(0666, "${HefileDir}/hakojima.js");
	} else {
		out(<<END);
<SCRIPT Language="JavaScript">
<!--
$src
//-->
</SCRIPT>
END
	}
}

1;
