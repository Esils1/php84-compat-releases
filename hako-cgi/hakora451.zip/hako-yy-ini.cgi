#!/usr/bin/perl
# The Return of Neptune: http://hpcgi2.nifty.com/otacky/
#----------------------------------------------------------------------
# hako-yy-bbs.cgi by.neo_otacky
# 해전 「동맹 게시판」용으로 수정
$versionInfo = "version1.11";
# 　=== 관리용 접속 방법 ===
# 　hako-yy-bbs.cgi?id=0&ally=[동맹 ID]&cpass=[마스터 비밀번호]
# 　[동맹 ID]는 반각 숫자, [마스터 비밀번호]는 영문/숫자입니다([]는 불필요).
#┌─────────────────────────────────
#│ YY-BOARD v5.8
#│ yyini.cgi - 2006/01/18
#│  Copyright (c) KentWeb
#│  webmaster@kent-web.com
#│  http://www.kent-web.com/
#└─────────────────────────────────
$ver = 'YY-BOARD v5.8';
#┌─────────────────────────────────
#│ [주의사항]
#│ 1. 이 스크립트는 프리 소프트웨어입니다. 이 스크립트를 사용하여 발생한
#│    어떠한 손해에 대해서도 제작자는 책임을 지지 않습니다.
#│ 2. 설치 관련 질문은 지원 게시판을 이용해 주세요.
#│    직접 메일을 통한 질문은 받지 않습니다.
#│ 3. 첨부된 home.gif는 L.O.V.E의 mayuRin 님이 제작한 이미지입니다.
#└─────────────────────────────────
#
# 【파일 구성 예】
#
#  public_html (홈 디렉터리)
#      |
#      +-- yybbs / yybbs.cgi  [705]
#            |     yyregi.cgi [705]
#            |     yyini.cgi  [604]
#            |     yylog.cgi  [606]
#            |     count.dat  [606]
#            |     pastno.dat [606]
#            |     gifcat.pl  [604]    … 등록 키 옵션용
#            |     registkey.cgi [705] … 등록 키 옵션용
#            |     registpl.cgi  [604] … 등록 키 옵션용
#            |
#            +-- img / home.gif, bear.gif, ...
#            |
#            +-- lock [707] /
#            |
#            +-- past [707] / 0001.cgi [606] ...

# 외부 파일 불러오기
require './hako-init.cgi';
require './hako-io.cgi';
#-------------------------------------------------
# ▼설정 항목
#-------------------------------------------------
# 최대 게시글 수
$max = 100;

# 1페이지당 게시글 표시 수 (원글)
$pageView = 10;

# 지난 로그 1파일의 행 수
#  → 이 행 수를 초과하면 다음 페이지를 자동 생성합니다
$pastmax = 650;

# 지난 로그 1페이지당 게시글 표시 수 (원글)
$pastView = 10;

# URL 자동 링크 (0=no 1=yes)
$autolink = 1;

# 답글이 달리면 원글을 맨 위로 이동 (0=no 1=yes)
$topsort = 1;

# 게시글 갱신은 method=POST 전용 (0=no 1=yes)
# → 보안 대책
$postonly = 1;

# 글쓰기 제한(보안 대책)
#  0 : 하지 않음
#  1 : 동일 IP 주소의 글쓰기 간격을 제한한다
#  2 : 모든 글쓰기 간격을 제한한다
$regCtl = 1;

# 제한 글쓰기 간격(초)
#  → $regCtl에서의 글쓰기 간격
$wait = 100;

# 등록 키 사용(스팸 대책)
# → 0=no 1=yes
$regist_key = 1;

# 등록 키 이미지 생성 파일($regist_key=1일 때)
$registkeycgi = './registkey.cgi';

# 등록 키 실행 파일($regist_key=1일 때)
$registkeypl = './registpl.cgi';

# 등록 후 처리
#  → 게시판 자신의 URL을 적어 두면 등록 후 다시 불러옵니다
#  → 브라우저를 새로고침해도 중복 등록되지 않도록 하기 위한 조치입니다.
#  → Location 헤더를 사용할 수 있는 서버에서만 사용
# $location = "${HbaseDir}/hako-yybbs.cgi";
# ！동맹 게시판에서는 사용하지 마세요
$location = '';

# 금지어
#  → 쉼표로 구분해 여러 개 지정(예)$deny_word = '성인,만남,커플';
$deny_word = '';

# 아이콘 모드 (0=no 1=yes)
$iconMode = 1;

# 지난 로그 1파일의 행 수
# → 이 행 수를 초과하면 다음 페이지를 자동 생성합니다
$log_line = 600;

# 「맹주용」(중요 공지란)의사용 허가 레벨(0:맹주만、1:구성원에게도 공개、2:맹주 우호국 구성원만)
$StaffLevel = 2;

# 「외교용」(다른 동맹으로 보내는 글)의사용 허가(0:맹주만、1:구성원에게도 공개、2:맹주 우호국 구성원만)
$DiploLevel = 2;

# 외교 통신에 진영 내부 답글 버튼을 붙임(0:붙이지 않음、1:붙임)
$DiploRes = 1;

#----------------#
#    외형 관련    #
#----------------#
# 제목 이름 지정
$title = "해전 게시판";

# 제목에 GIF 이미지를 사용할 때 (http://부터 입력)
$t_img = "";
$t_w = 150; # 이미지 너비 (픽셀)
$t_h = 50;  #   〃  높이 (픽셀)

# 게시글 [제목] 부분의 길이 (전각 문자 기준)
$sub_len = '30';

# 배경 이미지를 지정할 경우(http://부터 지정)
$backgif = "";

# 글자색 설정。
@col = ('#800000','#DF0000','#008040','#0000FF','#C100C1','#FF80C0','#FF8040','#000080');

# 태그 광고 삽입 옵션
#   → <!-- 상단 --> <!-- 하단 --> 대신 「광고 태그」를 삽입한다.
#   → 광고 태그 외에도 MIDI 태그나 LimeCounter 등의 태그에도 사용할 수 있습니다.
$banner1 = '<!-- 상단 -->'; # 게시판 상단에 삽입
$banner2 = '<!-- 하단 -->'; # 게시판 하단에 삽입

#----------------#
#  스킨 설정  #
#----------------#
# CSS를 둘 디렉터리
$HyycssDir = "$HcssDir";
# 기본 CSS 파일 이름
$HyycssDefault = 'yybbs.css';

# 스킨 설정
%HyycssFile = (
	"$HyycssDefault" => 'Default', # 'CSS 파일명' => '스킨 이름'으로 추가. 「,」를 빠뜨리지 않도록 주의
	"yybbs2.css" => 'NoAds',
#	"space.css" => 'TurnOver', # 이런 작성 방식
);
#----------------#
# 아이콘 모드 #
#----------------#
# 아이콘 정의(위아래는 반드시 쌍으로)
@ico1 = (
	'',
	'monster7.gif',
	'monster0.gif',
	'monster5.gif',
	'monster1.gif',
	'monster2.gif',
	'monster8.gif',
	'monster6.gif',
	'monster3.gif',
	'monument0.gif',
	'monument1.gif',
	'monument2.gif',
	'navy0.gif',
	'navy1.gif',
#	'navy8.gif',
#	'ship1.gif',
#	'ship2.gif',
#	'navy6.gif',
#	'navy7.gif',
	'navy2.gif',
	'navy3.gif',
	'navy4.gif',
	'navy5.gif',
#	'navy10.gif',
#	'navy9.gif',
);
@ico2 = (
	'없음',
	'메카 이노라',     # 0(인조)
	'이노라',         # 1
	'산질라',	      # 2
	'레드 이노라',   # 3
	'다크 이노라',   # 4
	'이노라 고스트', # 5
	'고래',         # 6
	'킹 이노라',   # 7
	'모노리스', 
	'평화기념비', 
	'전쟁기념비',
	'군항',     # 0 항구(변경 불가)
	'구축함',   # 1 대잠　대함
#	'무역함',   # 2 무역　대함
#	'범선',     # 3
#	'어선',     # 4
#	'보급함',   # 5 대잠　대함 　보급 타 섬 원정 시 전투함에 보급
#	'조사함',   # 6 대잠
	'순양함',   # 7 　　　대함　대지
	'전함',     # 8 　　　대함　대지
	'항공모함', # 9 　　　대함　대지
	'잠수함',   # 10 대잠　대함
#	'약탈선',   # 11 해적 대함
#	'육지 파쇄함'    # 12 육지 굴착 대함　대지
);

# 이미지 보기 화면의 표시 형태
#  1 : JavaScript
#  2 : HTML (JavaScript가 불안정한 브라우저가 많을 때는 이쪽)
$ImageView = 1;

# 이미지 보기 화면 크기 (JavaScript일 경우)
$img_w = 550; # 가로폭
$img_h = 450; # 높이

# 관리자 전용 아이콘 기능 (0=no 1=yes)
# → 【사용 방법】글을 작성할 때「관리자아이콘」를선택하고、비밀번호에
#             「관리용 비밀번호」를 입력해 주세요.
$my_icon = 0;

# 관리자 전용 아이콘의 「파일명」을 지정
$my_gif  = 'admin.gif';

#--------------#
# 미니 카운터 #
#--------------#
# 미니 카운터 자릿수
$mini_fig = 6;

# 이미지 방식일 때：이미지디렉터리를 지정
# → 마지막은 반드시 / 로 끝내기
$gif_path = "./img/";
$mini_w = 8;  # 이미지 가로 크기
$mini_h = 12; # 이미지 세로 크기

# 홈 아이콘 사용 (0=no 1=yes)
$home_icon = 0;
$home_gif = "home.gif"; # 홈 아이콘 파일명
$home_wid = 16;         # 이미지 가로 크기
$home_hei = 20;         #   〃  세로크기

# 이메일 주소 입력 필수 (0=no 1=yes)
$in_email = 0;

# 글이 등록되면 메일 알림 (sendmail필수)
#  0 : 알리지 않음
#  1 : 알리지만, 자신이 작성한 글은 메일로 알리지 않음.
#  2 : 알림. 자신이 작성한 글도 알림.
$mailing = 0;

# 이메일 주소(메일 알림 시)
#$mailto = 'xxx@xxx.xxx';
$mailto = $Hemail;

# sendmail 경로(메일 알림 시)
$sendmail = '/usr/lib/sendmail';

# 접근 제한(반각 공백으로 구분, 별표 사용 가능)
#  → 거부할 호스트명을 입력(후방 일치)【예】*.anonymizer.com
$deny_host = '';
#  → 거부할 IP 주소를 입력(전방 일치)【예】210.12.345.*
$deny_addr = '';

# 1회당 최대 게시글 크기 (bytes)
$maxData = 51200;

# 다른 사이트에서 온 글쓰기를 차단할 때 지정 (http://부터 작성)
$baseUrl = $HbaseDir;

# 호스트 취득 방법
# 0 : gethostbyaddr 함수를 사용하지 않음
# 1 : gethostbyaddr 함수를 사용
$gethostbyaddr = 0;

#--------------------#
#   파일명 등   #
#--------------------#
# 본체 파일 URL (파일명을 hako-init.cgi에서 설정)
$script  = "./${HallyBbsScript}";

# 갱신 파일 URL
$regist = './hako-yy-reg.cgi';

# 잠금 파일명
$lockfilename = 'yybbs.lock';

# 앳마크
$atMark = "<span class='atmark'>＠</span>";
#-------------------------------------------------
# ▲설정 완료
#-------------------------------------------------


#--------------------#
#  파일 확인  #
#--------------------#
sub file_check {
	# 로그 파일
	$logfile = "./${HbbsdirName}/$in{'ally'}$Hlogfile_name";
	# 맹주 로그 파일
	$logfile2 = "./${HbbsdirName}/$in{'ally'}$Hlogfile2_name";
	if (!(-f $logfile)) {
		if(!opendir(DIN, "${HbbsdirName}/")) {
			mkdir("${HbbsdirName}", $HdirMode);
		} else {
			closedir(DIN);
		}
		&error("Error : 동맹 ID가 올바르지 않습니다。") if($in{'ally'} ne '' && !(defined $HidToAllyNumber{$in{'ally'}}));
		open(LOG,">$logfile") || &error("Open Error : 로그 파일");
		print LOG "0\n";
		close(LOG);
	}
	if (!(-f $logfile2)) {
		open(LOG,">$logfile2") || &error("Open Error : ${HallyTopName}로그 파일");
		print LOG "<>\n";
		close(LOG);
	}
	# 카운터 파일
	if($Hcounter) {
		$cntfile = "./${HbbsdirName}/$in{'ally'}$Hcntfile_name";
		if (!(-f $cntfile)) {
			open(LOG,">$cntfile") || &error("Open Error : 카운터 파일");
			print LOG "0\n";
			close(LOG);
		}
	}
	# 지난 로그용 번호 파일
	if($Hpastkey) {
		$nofile  = "./${HbbsdirName}/$in{'ally'}$Hnofile_name";
		$pastdir = "./${HpastdirName}/";
		if (!(-f $nofile)) {
			open(LOG,">$nofile") || &error("Open Error : 지난 로그용 번호 파일");
			print LOG "1\n";
			close(LOG);
			$pastfile = sprintf("%s%04d\.%s\.cgi", $pastdir,1,($in{'ally'} eq '' ? 0 : $in{'ally'}));
			if (!(-f $pastfile)) {
				if(!opendir(DIN, "${HpastdirName}/")) {
					mkdir("${HpastdirName}", $HdirMode);
				} else {
					closedir(DIN);
				}
				open(PAST,">$pastfile") || &error("Open Error : 지난 로그 파일");
				close(PAST);
			}
		}
	}
	# 잠금 파일
	$lockfile  = "./${HbbsdirName}/$in{'ally'}$lockfilename";
	if(($lockMode >= 4) && !(-f $lockfile) && !(-f "${lockfile}.lock")) {
		open(LOCK,">$lockfile") || &error("Open Error : 잠금 파일");
		close(LOCK);
	}
	# 다시 불러오기(사용하지 않음)
#	if($location ne '') {
#		$location .= "?ally=$in{'ally'}&jpass=$in{'jpass'}&cpass=$in{'cpass'}&id=$in{'id'}";
#	}
}

#----------------------#
#  하코니와 데이터 읽기  #
#----------------------#
sub read_data {
	if (-e $HpasswordFile) {
		# 비밀번호 파일이 있음
		open(PIN, "<$HpasswordFile") || die $!;
		chomp($HmasterPassword  = <PIN>); # 마스터 비밀번호 읽기
		chomp($HspecialPassword = <PIN>); # 특수 비밀번호 읽기
		close(PIN);
	}
	# 관리자용마스터 비밀번호
	$pass = $HmasterPassword;

	$ally_name[0]  = '해전 운영본부'; # 본부 이름
	$ally_head[0]  = '◆';           # 본부 마크
	$allyCol[0] = '#0000FF';      # 본부 마크 색상
	if($in{'cpass'} ne '') {
		if(!readIslandsFile(0)){
			&error("하코니와 파일 읽기에 실패했습니다");
		}
		for ($i = 0; $i < $HallyNumber; $i++) {
			$ally_name[$Hally[$i]->{'id'}]  = $Hally[$i]->{'name'};     # 동맹 이름
			$ally_head[$Hally[$i]->{'id'}]  = $Hally[$i]->{'mark'};     # 동맹 마크
			$allyCol[$Hally[$i]->{'id'}]    = $Hally[$i]->{'color'};    # 마크 색상
			$jpass[$Hally[$i]->{'id'}]      = $Hally[$i]->{'Takayan'};  # Takayan의 jpass
		}
	}
	if($in{'ally'} ne '') {
		($allyid, $dead) = split(/-/, $in{'ally'});
		if($dead eq '') {
			$title = "$ally_head[$in{'ally'}]$ally_name[$in{'ally'}]작전 회의실";
			$maintitle = "<FONT COLOR=$allyCol[$in{'ally'}]><B>$ally_head[$in{'ally'}]</B></FONT>$ally_name[$in{'ally'}]작전 회의실";
		} else {
			my $logfile = "./${HbbsdirName}/$in{'ally'}$Hlogfile_name";
			open(IN,"$logfile") || &error("Open Error : $logfile (read_data)");
			my $top = <IN>;
			close(IN);
			$maintitle = (split(/<>/, $top))[3];
			if($maintitle eq '') {
				my $dflag = 1;
				if(-f "${HbbsdirName}/dead${HallyData}") {
					open(DIN,"${HbbsdirName}/dead${HallyData}") || &error("Open Error : ${HbbsdirName}/dead${HallyData} (read_data)");
					my @ddata = <DIN>;
					close(DIN);
					foreach (@ddata) {
						my($dally, $daName, $diName) = split(/\,/, $_);
						if($in{'ally'} eq $dally) {
							$maintitle = $daName . '작전 회의실';
							$dflag = 0;
						}
					}
				}
				if($dflag) {
					$maintitle = '이름 불명 동맹 작전 회의실';
				}
			}
			$title = $maintitle;
			$title =~ s/<[^<]*>//g;
		}
	}
}
#-------------------------------------------------
#  접근 제한
#-------------------------------------------------
sub axsCheck {
	# 관리자 비밀번호인 경우 확인하지 않는다.
	if (checkMasterPassword($in{'cpass'})) { 
		if(($in{'id'} == 0) && ($in{'id'} ne '')) {
			$in{'name'} = "관리자" if($in{'name'} eq '');
			$owner = 2;
			return;
		}
	}

	# IP와 호스트 가져오기
	$host = $ENV{'REMOTE_HOST'};
	$addr = $ENV{'REMOTE_ADDR'};
	if ($gethostbyaddr && (($host eq '') || ($host eq $addr))) {
		$host = gethostbyaddr(pack("C4", split(/\./, $addr)), 2) || $addr;
	}
	local($flag)=0;
	foreach (@Hdeny) {
		if (!$_) { next; }
		s/\*/\.\*/g;
		if ($host =~ /$_/i || $addr =~ /$_/i) { $flag=1; last; }
	}
	# IP확인
	local($flg);
	foreach ( split(/\s+/, $deny_addr) ) {
		s/\./\\\./g;
		s/\*/\.\*/g;

		if ($addr =~ /^$_/i) { $flg = 1; last; }
	}
	if ($flag) {
		if($HdenyLocation ne '') {
			print "Location: $HdenyLocation\n\n";
			exit;
		} else {
			&error("접근이 허용되지 않았습니다");
		}
	# 호스트 확인
	} elsif ($host) {

		foreach ( split(/\s+/, $deny_host) ) {
			s/\./\\\./g;
			s/\*/\.\*/g;

			if ($host =~ /$_$/i) { $flg = 1; last; }
		}
		if ($flg) {
			if($HdenyLocation ne '') {
				print "Location: $HdenyLocation\n\n";
				exit;
			} else {
				&error("접근이 허용되지 않았습니다");
			}
		}
	}
	if ($host eq "") { $host = $addr; }

	# 다른 사이트에서 온 접근 차단
	if (($in{'ally'} ne '') && $baseUrl) {
		$ref = $ENV{'HTTP_REFERER'};
		if ($ref !~ /$baseUrl/i) { &error("ERROR:잘못된 접근입니다。(referer)"); }
	}

	if (($in{'ally'} ne '') && ($dead eq '')) {
		if($in{'cpass'} ne $Hally[$HidToAllyNumber{$in{'ally'}}]->{'password'} ||
			$in{'cpass'} eq "" ||
			$in{'jpass'} eq "" ||
			$in{'jpass'} ne $jpass[$in{'ally'}] ) {
			&error("동맹용 비밀번호가 틀렸습니다.<BR>개발 화면에서 다시 들어와 주세요.");
		}
		# 구성원확인
		my @allyId = @{$Hally[$HidToAllyNumber{$in{'ally'}}]->{'memberId'}};
		my @amity = @{$Hislands[$HidToNumber{$in{'ally'}}]->{'amity'}};
		my $aId = shift @allyId;
		if ($aId == $in{'id'}) {
			$owner = 1;
		} else {
			foreach $aId (@allyId) {
				if ($aId == $in{'id'}) {
					$member = 1;
					last;
				}
			}
			foreach $aId (@amity) {
				if ($aId == $in{'id'}) {
					$amity = 1;
					last;
				}
			}
		}
		if (!$owner && !$member) { &error("ERROR:잘못된 접근입니다。(member)"); }
	}
}

#-------------------------------------------------
#  글쓰기 화면
#-------------------------------------------------
sub form {
	local($nam,$eml,$url,$pwd,$ico,$col,$sub,$com) = @_;
#	local(@ico1,@ico2,@col);

	if ($url eq "") { $url = 'http://'; }
	$pattern = 'https?\:[\w\.\~\-\/\?\&\+\=\:\@\%\;\#\%]+';
	$com =~ s/<a href="$pattern" target="_blank">($pattern)<\/a>/$1/go;

	print <<EOM;
<table class='v' border=0 cellspacing=1>
<tr>
  <td><b>이름</b></td>
  <td><input type=text name=name size=28 value="$nam" class=f></td>
</tr>
<tr>
  <td><b>이메일</b></td>
  <td><input type=text name=email size=28 value="$eml" class=f style="ime-mode:inactive"></td>
</tr>
<tr>
  <td><b>제목</b></td>
  <td>
    <input type=text name=sub size=36 value="$sub" class=f>
    <input type=submit value="등록"><input type=reset value="초기화">
  </td>
</tr>
<tr>
  <td colspan=2>
    <b>내용</b><br>
    <textarea cols=56 rows=7 name=comment wrap="soft" class=f>$com</textarea>
  </td>
</tr>
<tr>
  <td><b>참조 URL</b></td>
  <td><input type=text size=52 name=url value="$url" class=f style="ime-mode:inactive"></td>
</tr>
EOM

	# 관리자 아이콘을 배열에 추가
#	@ico1 = split(/\s+/, $ico1);
#	@ico2 = split(/\s+/, $ico2);
	if ($my_icon) {
		push(@ico1,$my_gif);
		push(@ico2,"관리자용");
	}
	if ($iconMode) {
		print "<tr><td><b>이미지</b></td>
		<td><select name=icon class=f>\n";
		foreach(0 .. $#ico1) {
			if ($ico eq $ico1[$_]) {
				print "<option value=\"$_\" selected>$ico2[$_]\n";
			} else {
				print "<option value=\"$_\">$ico2[$_]\n";
			}
		}
		print "</select><font size=\"-1\">&nbsp;\n";

		# 이미지 보기 링크
		if ($ImageView == 1) {
			print "[<a href=\"javascript:ImageUp()\">이미지 보기</a>]";
		} else {
			print "[<a href=\"$script?mode=image\" target=\"_blank\">이미지 보기</a>]";
		}
		print "</font></td></tr>\n";
	}

	if ($pwd ne "??") {
		print "<tr><td><b>수정/삭제 키</b></td>";
		print "<td><input type=password name=pwd size=8 maxlength=8 value=\"$pwd\" class=f>\n";
		print "<font size=\"-1\">(영문/숫자 8자 이내)</font></td></tr>\n";

		# 등록 키
		if ($regist_key) {
			print "<tr><td><b>등록 키</b></td>";
			print "<td><input type=text name=regikey size=6 style=\"ime-mode:inactive\" class=f value=\"\">\n";
			print "<font size=\"-1\">(등록할 때 <img src=\"$registkeycgi?$str_crypt\"> 를 입력해 주세요)</font></td></tr>\n";
			print "<input type=hidden name=str_crypt value=\"$str_crypt\">\n";
		}
	}
	print "<tr><td><b>글자색</b></td><td>";

	# 색상 정보
#	@col = split(/\s+/, $color);
	if ($col eq "") { $col = 0; }
	foreach (0 .. $#col) {
		if ($col eq $col[$_] || $col == $_) {
			print "<input type=radio name=color value=\"$_\" checked>";
			print "<font color=\"$col[$_]\">■</font>\n";
		} else {
			print "<input type=radio name=color value=\"$_\">";
			print "<font color=\"$col[$_]\">■</font>\n";
		}
	}

	print <<EOM;
<input type=hidden name=ally value="$in{'ally'}">
<input type=hidden name=jpass value="$in{'jpass'}">
<input type=hidden name=cpass value="$in{'cpass'}">
<input type=hidden name=id value="$in{'id'}">
</td></tr></table>
EOM
}

#-------------------------------------------------
#  게시글 표시부
#-------------------------------------------------
sub logView {
	local($next,$back,$i,$flag);

	# 쿠키 가져오기
	if (!$curl) { $curl = 'http://'; }

	# 헤더 출력
	if ($ImageView == 1) { &header('ImageUp'); }
	else { &header; }

	# 카운터 처리
	if ($Hcounter) { &counter; }

	# 등록 키
	local($str_plain,$str_crypt);
	if ($regist_key) {
		require $registkeypl;

		($str_plain,$str_crypt) = &pcp_makekey;
	}

	# 턴과 다음 갱신까지의 시간 표시
	my($rtStr);
	if(($dead eq '') && ($in{'ally'} ne '')) {
		my($remainTime, $mode);
		if($HarmisticeTurn) {
			$mode = ($HislandTurn < $HarmisticeTurn) ? '(휴전 기간)' : ($HislandTurn == $HarmisticeTurn) ? '(다음 턴부터 전투 기간)' : '(전투 기간)';
		}
		$remainTime = $HunitTime - time() + $HislandLastTime;
		$rtStr = "다음 갱신${mode}까지"; 
		$rtStr .= int($remainTime / 3600) . "시간";
		$rtStr .= int(($remainTime % 3600) / 60) . "분";
		$rtStr .= $remainTime % 60 . "초";
		$rtStr = "<P>턴 <span class='turn'>$HislandTurn</span>：$rtStr<P>\n";
	}
	# 제목부
	print "<div align=\"center\">\n";
	if ($banner1 ne "<!-- 상단 -->") { print "$banner1<P>\n"; }
	if($maintitle eq '') {
		if ($t_img eq '') {
			print "<DIV class='bbstitle'>$title</DIV>\n";
		} else {
			print "<img src=\"$t_img\" width=\"$t_w\" height=\"$t_h\" alt=\"$title\">\n";
		}
	} else {
		print "<DIV class='bbstitle'>$maintitle</DIV>\n";
	}
	print "$rtStr";
	if ($HarmisticeTurn && ($dead eq '') && ($member || $owner) && $in{'ally'}) {
		print <<_CAMP_
<A STYlE="text-decoration:none" HREF="JavaScript:void(0)" onClick="document.allyForm${aNo}.action='${HthisFile}';document.allyForm${aNo}.submit();return false;"><B><FONT COLOR=$allyCol[$in{'ally'}]>$ally_head[$in{'ally'}]</FONT></B>$ally_name[$in{'ally'}]작전 본부로</A>
<FORM name="allyForm$aNo" action="" method="POST" target="_blank">
<input type=hidden name=camp value="$in{'ally'}">
<input type=hidden name=jpass value="$in{'jpass'}">
<input type=hidden name=cpass value="$in{'cpass'}">
<input type=hidden name=id value="$in{'id'}">
</FORM>
_CAMP_
	}

	print <<EOM;
<hr width='90%'>
[<a href="$Htoppage" target='_top'>첫 페이지</a>]
[<a href="$HthisFile" target='_top'>$HtitleTag</a>]
[<a href="JavaScript:void(0)" onClick="document.LINK.mode.value='howto';document.LINK.submit();return false;">주의사항</a>]
[<a href="JavaScript:void(0)" onClick="document.LINK.mode.value='find';document.LINK.submit();return false;">단어 검색</a>]
EOM

	# 지난 로그 링크부 표시
	if ($Hpastkey) { print "[<a href=\"JavaScript:void(0)\" onClick=\"document.REGIST.mode.value='past';document.REGIST.submit();return false;\">지난 로그</a>]\n"; }
	if (($StaffLevel == 2 && $amity) || ($StaffLevel == 1 && $member) || $owner && (($dead eq '') || ($owner == 2))) {
		print "[<a href=\"JavaScript:void(0)\" onClick=\"document.REGIST.mode.value='staff';document.REGIST.submit();return false;\">${HallyTopName}용</a>]\n";
	}
	if (($DiploLevel == 2 && $amity) || ($DiploLevel == 1 && $member) || $owner && (($dead eq '') || ($owner == 2))) {
		print "[<a href=\"JavaScript:void(0)\" onClick=\"document.REGIST.mode.value='diplo';document.REGIST.submit();return false;\">외교용</a>]\n";
	}
	if (checkMasterPassword($in{'cpass'})) { print "[<a href=\"JavaScript:void(0)\" onClick=\"document.REGIST.mode.value='admin';document.REGIST.submit();return false;\">관리용</a>]\n"; }

	if(($in{'ally'} eq '') && (-f "${HbbsdirName}/dead${HallyData}")) {
		open(DIN, "${HbbsdirName}/dead${HallyData}") || die $!;
		my @dead = <DIN>;
		close(DIN);
		if(@dead > 0) {
			print "<hr width='90%'>";
			print "【소멸한 동맹】 ";
		}
		foreach (@dead) {
			my($dally, $daName, $diName) = split(/\,/, $_);
			my($did, $dturn) = split(/-/, $dally);
			print "<nobr><a style=\"text-decoration:none;\" title=\"$HallyTopName：$diName(턴 $dturn에 소멸)\" ";
			print "href=\"JavaScript:void(0)\" onClick=\"document.LINK.ally.value='$dally';document.LINK.submit();return false;\">$daName</a> </nobr>";
		}
	}
	print <<"EOM";
<hr width='90%'>
<form name=LINK method="POST" action="$script">
<input type=hidden name=mode value="">
<input type=hidden name=ally value="$in{'ally'}">
<input type=hidden name=jpass value="$in{'jpass'}">
<input type=hidden name=cpass value="$in{'cpass'}">
<input type=hidden name=id value="$in{'id'}">
</form>
<form name=REGIST method="POST" action="$regist">
<input type=hidden name=mode value="">
<input type=hidden name=ally value="$in{'ally'}">
<input type=hidden name=jpass value="$in{'jpass'}">
<input type=hidden name=cpass value="$in{'cpass'}">
<input type=hidden name=id value="$in{'id'}">
</form>
</div>
EOM

	if($dead eq '') {
		print <<"EOM";
<blockquote>
<table class='v' BORDER=1 WIDTH='90%' BGCOLOR="#FFFFFF" CELLSPACING=0 CELLPADDING=2><TR><TD>
<a href="javascript: displayInputForm();" id="toggleMesBtn">글쓰기 영역 보이기</a>
</TD></TR></TABLE><DIV align='center'>
<form method="POST" action="$regist" id="inputForm">
<input type=hidden name=mode value="regist">
<input type=hidden name=page value="$page">
EOM
	&form($cnam,$ceml,$curl,$cpwd,$cico,$ccol,'','');

	print <<EOM;
</form></DIV>
<script type="text/javascript">
<!--
function displayInputForm() {
  if(document.getElementById){
    var obj = document.getElementById('inputForm');
    if (obj.style.display == 'block'){
      document.getElementById('toggleMesBtn').firstChild.nodeValue='글쓰기 영역 보이기';
      obj.style.display='none';
    } else {
      document.getElementById('toggleMesBtn').firstChild.nodeValue='글쓰기 영역 숨기기';
      obj.style.display='block';
    }
  }
}
-->
</script>
</blockquote>
<br>
EOM
	}
	print "<div align=\"center\">";

	local($no,$re,$dat,$nam,$eml,$sub,$com,$url,$idname,$allyidname,$turn,$hos,$pw,$col,$ico);

	# 게시글 전개
	open(IN,"$logfile") || &error("Open Error : $logfile (html_log)");
	my @lines2 = <IN>;
	close(IN);
	$top = shift(@lines2);
	# 중요 공지 삽입
	open(IN2,"$logfile2") || &error("Open Error : $logfile2 (html_log)");
	my $line = <IN2>;
	close(IN2);
	unshift(@lines2, $line);
	$i = 0;
	$flag = 0;
	foreach (@lines2) {
		($no,$re,$dat,$nam,$eml,$sub,$com,$url,$idname,$allyidname,$turn,$hos,$pw,$col,$ico) = split(/<>/);
		if ($re eq "") { $i++; }
		if ($i < $page + 1) { next; }
		if ($i > $page + $pageView) { next; }

		if(($dead ne '') || $owner || $amity) {
			1 while $com =~ s/(.*)(&lt;(amity)&gt;(.*)&lt;\/amity&gt;)/$1<span class=\'amity\'>$4<\/span>/i;
		} else {
			1 while $com =~ s/(.*)(&lt;(amity)&gt;(.*)&lt;\/amity&gt;)/$1/i;
		}

		my($aidFrom, $aidTo) = split(/\,/, $allyidname);
		my $sPost = 0;
		my $sPostTitle;
		if($no eq '') {
			if($com eq '') { next; }
			$tbCol = 's';
			my $sName = $HallyTopName;
			$sName = $ally_name[0] if($allyidname eq '');
			$sPostTitle = "<span class='subjects'>● ${sName}의 메시지 ●</span>";
			$sPost = 2;
		} else {
			if($aidTo ne '') {
				if($maintitle =~ /$aidTo/) {
					$tbCol = 'df';
					$sPostTitle = "<span class='subjects'>● 외교 문서 수신 내용 ●</span>　<B>From:${aidFrom}</B>";
				} elsif($maintitle =~ /$aidFrom/) {
					$tbCol = 'dt';
					$sPostTitle = "<span class='subjects'>● 외교 문서 송신 내용 ●</span>　<B>To:${aidTo}</B>";
				} else {
					$tbCol = 'd';
					$sPostTitle = "<span class='subjects'>● 외교 문서 ●</span>　<B>From:${aidFrom}　To:${aidTo}</B>";
				}
				$sPost = ($DiploRes) ? 1 : 2;
			} else {
				$tbCol = 'n';
			}
		}
		# 제목 길이
		if (length($sub) > $sub_len*2) {
			$sub = substr($sub,0,$sub_len*2);
			$sub .= "...";
		}

		if ($eml) { $nam = "<a href=\"mailto:$eml\">$nam</a>"; }
		if ($home_icon && $url) {
			$url = "<a href=\"$url\" target=\"_blank\"><img src=\"${HimageDir}/$home_gif\" border=0 align=top alt='HomePage' width=\"$home_wid\" height=\"$home_hei\"></a>";
		} elsif (!$home_icon && $url) {
			$url = "&lt;<a href=\"$url\" target=\"_blank\">Home</a>&gt;";
		}
		if (!$iconMode) { $com = "<blockquote>$com</blockquote>"; }

		if (!$re && $flag) {
			print "</TD></TR></TABLE><br><br>\n";
			$flag=1;
		}
		if (!$re) {
			print "<table class='$tbCol' BORDER=1 WIDTH='90%' CELLSPACING=0 CELLPADDING=2><TR><TD>\n";
			$flag=1;
		}

		if ($re) { print "<hr noshade size=1 width='85%'>\n"; }
		if($sPost) { print "<table class='s$tbCol' border=0 width='100%' cellpadding=1><tr><td>$sPostTitle</td></tr></table>\n"; }
		print "<table class='v' border=0 cellpadding=2><tr>\n";
		if ($re) { print "<td rowspan=2 width=40><br></td>"; }

		print "<td valign=top nowrap><span class='subject'>$sub</span>　";

		my $iName = '';
		if($allyidname ne '') {
			if($idname eq '0') {
				$iName = "${atMark}$ally_name[0]";
			} elsif($idname ne '') {
				$iName = "${atMark}${idname}${AfterName}";
			}
		}
		my $turnStr = " [턴<span class='turn'>$turn</span>] " if($turn);
		if (!$re) { print "작성자：<b>${nam}${iName}</b> 등록일：${dat}${turnStr}"; }
		else { print "<b>${nam}${iName}</b> - ${dat}${turnStr}"; }

		if ($no ne '') { print "<span class='number'>No\.$no</span></td>"; }
		print "<td valign=top nowrap> &nbsp; $url </td><td valign=top>\n";

		if (($dead eq '') && !$re && ($sPost != 2)) {
			print "<form action=\"$script\" method=POST>\n";
			print "<input type=hidden name=mode value=res>\n";
			print "<input type=hidden name=no value=\"$no\">\n";
			print "<input type=hidden name=ally value=\"$in{'ally'}\">\n";
			print "<input type=hidden name=jpass value=\"$in{'jpass'}\">\n";
			print "<input type=hidden name=cpass value=\"$in{'cpass'}\">\n";
			print "<input type=hidden name=id value=\"$in{'id'}\">\n";
			if($sPost) {
				print "<input type=submit value='동맹 내부 답글'></td></form>\n";
			} else {
				print "<input type=submit value='답글'></td></form>\n";
			}
		} else {
			print "<br></td>\n";
		}

		print "</tr></table><table class='v' border=0 cellpadding=5><tr>\n";
		if ($re) { print "<td width=32><br></td>\n"; }

		# 아이콘 모드
		if ($iconMode && ($ico ne '')) { print "<td><img src=\"${HimageDir}/$ico\" alt=\"$ico\"></td>"; }
		# URL 자동 링크
		if ($autolink) { &auto_link($com); }

		print "<td class='comment'><span style=\"color:$col;\">$com</span></td></tr></table>\n";
	}
	print "</TD></TR></TABLE></div>\n";

	# 페이지이동 버튼표시
	if ($page - $pageView >= 0 || $page + $pageView < $i) {
		print "<p><blockquote><table width=\"90%\"><tr><td>\n";
		&mvbtn($i, $pageView);
		print "<form name=MOVE method=\"POST\" action=\"$script\">";
		print "<input type=hidden name=page value=\"\">";
		print "<input type=hidden name=bl value=\"0\">";
		print "<input type=hidden name=ally value=\"$in{'ally'}\">";
		print "<input type=hidden name=jpass value=\"$in{'jpass'}\">";
		print "<input type=hidden name=cpass value=\"$in{'cpass'}\">";
		print "<input type=hidden name=id value=\"$in{'id'}\">";
		print "</td></form></tr></table></blockquote>\n";
	}
	print "<div align='center'>\n";
	print "<P><table class='v' cellpadding=0 cellspacing=0><tr>\n";
	if($dead eq '') {
		print <<EOM;
<td>
<form action="$regist" method="POST">
<input type=hidden name=ally value="$in{'ally'}">
<input type=hidden name=jpass value="$in{'jpass'}">
<input type=hidden name=cpass value="$in{'cpass'}">
<input type=hidden name=id value="$in{'id'}">
<select name=mode class="f">
<option value=edit>수정
<option value=dele>삭제
</select>
<span class="n">
NO:<input type=text name=no size=3 class="f">
PASS:<input type=password name=pwd size=6 maxlength=8 class="f">
</span>
<input type=submit value="전송" class="f">
</td></form><td width=20></td>
EOM
	}
	my $select_list;
	foreach (keys %HyycssFile) {
		my $s = ($_ eq $ccss) ? ' selected' : '';
		$select_list .= "<OPTION value='$_'$s>$HyycssFile{$_}\n";
	}
	print <<EOS;
<td>
<form action="$regist" method="POST">
<input type=hidden name=mode value=skin class=f>
<input type=hidden name=ally value="$in{'ally'}">
<input type=hidden name=jpass value="$in{'jpass'}">
<input type=hidden name=cpass value="$in{'cpass'}">
<input type=hidden name=id value="$in{'id'}">
<span class=n>
SKIN:<select name=css class=f>
$select_list
</select>
</span>
<input type=submit value="변경" class=f>
</td></form></table>
EOS
	# 저작권 표시(삭제 불가): 단, MakiMaki 님의 이미지를 사용하지 않는 경우에 한해,
	# MakiMaki 님의 링크를 제거할 수 있음
	print <<EOM;
$banner2
<p>
<!-- $ver -->
<span style="font-size:10px; font-family:Verdana,Helvetica,Arial">
- <a href='http://www.kent-web.com/' target='_top'>KENT</a> &amp; 
<a href="http://homepage3.nifty.com/makiz/" target="_top">MakiMaki</a> -
</span>
</div>
<div align='right'>
EOM
	if($Hperformance) {
		my($uti, $sti, $cuti, $csti) = times();
		$uti += $cuti;
		$sti += $csti;
		my($cpu) = $uti + $sti;
		print "　<SMALL>CPU($cpu) : user($uti) system($sti)</SMALL>\n";
	}
	print "<HR><B>AllyBBS $versionInfo</B> patchworked by <a style='text-decoration:none;' href='http://hpcgi2.nifty.com/otacky/' target='_top'>neo_otacky</a>";
	print "</div>\n</body>\n</html>\n";
	exit;
}

#-------------------------------------------------
#  자동 URL 링크
#-------------------------------------------------
sub auto_link {
	$_[0] =~ s/([^=^\"]|^)(https?\:[\w\.\~\-\/\?\&\+\=\:\@\%\;\#\%]+)/$1<A href=\"$2\" onclick=\"location.href=\'${HaxesFile}?$2\'\; return false\;\" target=\"_blank\">$2<\/a>/g;
}

#-------------------------------------------------
#  폼 디코딩
#-------------------------------------------------
sub decode {
	local($buf,$key,$val);
	undef(%in);

	if ($ENV{'REQUEST_METHOD'} eq "POST") {
		$post_flag=1;
		if ($ENV{'CONTENT_LENGTH'} > $maxData) {
			&error("게시글 용량이 너무 큽니다");
		}
		read(STDIN, $buf, $ENV{'CONTENT_LENGTH'});
	} else {
		$post_flag=0;
		$buf = $ENV{'QUERY_STRING'};
	}

	undef(%in);
	foreach ( split(/&/, $buf) ) {
		($key, $val) = split(/=/);
		$val =~ tr/+/ /;
#		$val =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
		$val =~ s/%([a-fA-F0-9]{2})/pack("H2", $1)/eg;

		# UTF-8 환경에서는 별도 문자셋 변환을 사용하지 않음

		# 이스케이프
		$val =~ s/&/&amp;/g;
		$val =~ s/"/&quot;/g; #"
		$val =~ s/</&lt;/g;
		$val =~ s/>/&gt;/g;
		$val =~ s/\0//g;
		$val =~ s/'/&#x27;/g; #'
		$val =~ s/ /&#32;/g;

		$val =~ s/\r\n/<br>/g;
		$val =~ s/\r/<br>/g;
		$val =~ s/\n/<br>/g;
		$val =~ s/(<br>){5,}//g; # 대량 줄바꿈 대책
		$val =~ s/\r//g;
		$val =~ s/\n//g;
		#$val =~ s/[\x00-\x20]+/ /g;

		$in{$key} .= "\0" if (defined($in{$key}));
		$in{$key} .= $val;
	}
	if ($in{'sub'} eq "") { $in{'sub'} = "제목 없음"; }
	$page = $in{'page'};
	$page =~ s/\D//g;
	if ($page < 0) { $page = 0; }
	$mode = $in{'mode'};

	$lockflag=0;
	$headflag=0;
}

#-------------------------------------------------
#  오류처리
#-------------------------------------------------
sub error {
	# 잠금 중이면 해제
	if ($lockflag) { &unlock; }

	&header if (!$headflag);
	print <<EOM;
<div align="center">
<hr width=400><h3>ERROR !</h3>
<font color="red">$_[0]</font>
<p>
<hr width=400>
<p>
<form>
<input type=button value="이전 화면으로 돌아가기" onClick="history.back()">
</form>
</div>
</body>
</html>
EOM
	exit;
}

#-------------------------------------------------
#  HTML 헤더
#-------------------------------------------------
sub header {
	$head_flag=1;
	if($ccss ne ''){
		$baseSKIN = "${HyycssDir}/$ccss";
	} else {
		$baseSKIN = "${HyycssDir}/$HyycssDefault";
	}
	print "Content-type: text/html; charset=utf-8\n\n";
	print <<"EOM";
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html lang="ko">
<head>
<META HTTP-EQUIV="Content-type" CONTENT="text/html; charset=utf-8">
<META HTTP-EQUIV="Content-Style-Type" content="text/css">
<link rel="stylesheet" type="text/css" href="$baseSKIN">

EOM
	# JavaScript헤더
	if ($ImageView == 1 && $_[0] eq "ImageUp") {
		print "<META http-equiv=\"Content-Script-Type\" content=\"text/javascript\">\n";
		print "<SCRIPT type=\"text/javascript\">\n";
		print "<!--\nfunction ImageUp() {\n";
		print "window.open(\"$script?mode=image\",\"window1\",\"width=$img_w,height=$img_h,scrollbars=1\");\n}\n//-->\n</SCRIPT>\n";
	}

	print "<title>$title</title></head>\n";
	if ($backgif) {
		print "<body background=\"$backgif\">\n";
	} else {
		print "$Body\n";
	}
}

#-------------------------------------------------
#  잠금 처리
#-------------------------------------------------
sub lock {
	# 재시도 횟수
	local($retry) = 5;

	# 잠금은 삭제한다
	if (-e $lockfile) {
		local($mtime) = (stat($lockfile))[9];
		if ($mtime < time - 30) { &unlock; }
	}
	# mkdir 함수 방식 잠금
	if ($lockMode == 1) {
		while (!mkdir($lockfile, 0755)) {
			if (--$retry <= 0) { &error('LOCK is BUSY'); }
			sleep(1);
		}
	# flock 함수 방식 잠금
	} elsif ($lockMode == 2) {
		open(LOCKID, ">>$lockfile") || &error("LOCK is BUSY");
		while (!flock(LOCKID, 2)) {
			if (--$retry <= 0) { &error('LOCK is BUSY'); }
			sleep(1);
		}
	# symlink 함수 방식 잠금
	} elsif ($lockMode == 3) {
		while (!symlink(".", $lockfile)) {
			if (--$retry <= 0) { &error('LOCK is BUSY'); }
			sleep(1);
		}
	# rename 함수 방식 잠금
	} elsif ($lockMode >= 4) {
		while (!rename($lockfile, "${lockfile}.lock")) {
			if (--$retry <= 0) { &error('LOCK is BUSY'); }
			sleep(1);
		}
	}
	$lockflag=1;
}

#-------------------------------------------------
#  잠금 해제
#-------------------------------------------------
sub unlock {
	if ($lockMode == 1) {
		rmdir($lockfile);
	} elsif ($lockMode == 2) {
		close(LOCKID);
	} elsif ($lockMode == 3) {
		unlink($lockfile);
	} elsif ($lockMode >= 4) {
		rename("${lockfile}.lock", $lockfile);
	}
	$lockflag=0;
}

#-------------------------------------------------
#  쿠키 발행
#-------------------------------------------------
sub set_cookie {
	local(@cook) = @_;
	local($gmt, $cook, @t, @m, @w);

	@t = gmtime(time + 60*24*60*60);
	@m = ('Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec');
	@w = ('Sun','Mon','Tue','Wed','Thu','Fri','Sat');

	# 국제 표준시 정의
	$gmt = sprintf("%s, %02d-%s-%04d %02d:%02d:%02d GMT",
			$w[$t[6]], $t[3], $m[$t[4]], $t[5]+1900, $t[2], $t[1], $t[0]);

	# 저장 데이터를 URL 인코딩
	foreach (@cook) {
		s/(\W)/sprintf("%%%02X", unpack("C", $1))/eg;
		$cook .= "$_<>";
	}

	# 저장
	print "Set-Cookie: YY_BOARD=$cook; expires=$gmt\n";
}

#-------------------------------------------------
#  쿠키 가져오기
#-------------------------------------------------
sub get_cookie {
	local($key, $val, *cook);

	# 쿠키 가져오기
	$cook = $ENV{'HTTP_COOKIE'};

	# 해당 ID 가져오기
	foreach ( split(/;/, $cook) ) {
		($key, $val) = split(/=/);
		$key =~ s/\s//g;
		$cook{$key} = $val;
	}

	# 데이터를 URL 디코딩해 복원
	@cook=();
	foreach ( split(/<>/, $cook{'YY_BOARD'}) ) {
#		s/%([0-9A-Fa-f][0-9A-Fa-f])/pack("C", hex($1))/eg;
		s/%([0-9A-Fa-f][0-9A-Fa-f])/pack("H2", $1)/eg;

		push(@cook,$_);
	}
	return (@cook);
}

#-------------------------------------------------
#  이동 버튼
#-------------------------------------------------
sub mvbtn {
	local($i,$view) = @_;
	local($start,$end,$x,$y,$bk_bl,$fw_bl);

#	if ($in{'view'}) { $view = $in{'view'}; }

	if ($in{'bl'}) {
		$start = $in{'bl'}*10 + 1;
		$end   = $start + 9;
	} else {
		$in{'bl'} = 0;
		$start = 1;
		$end   = 10;
	}

	$x=1; $y=0;
	while ($i > 0) {
		# 현재 페이지
		if ($page == $y) {

			print "| <b style='color:red' class=n>$x</b>\n";

		# 전환 페이지
		} elsif ($x >= $start && $x <= $end) {

			print "| <a href=\"JavaScript:void(0)\" onClick=\"document.MOVE.page.value='$y';document.MOVE.bl.value='$in{'bl'}';document.MOVE.submit();return false;\" class=n>$x</a>\n";

		# 이전 블록
		} elsif ($x == $start-1) {

			$bk_bl = $in{'bl'}-1;
			print "| <a href=\"JavaScript:void(0)\" onClick=\"document.MOVE.page.value='$y';document.MOVE.bl.value='$bk_bl';document.MOVE.submit();return false;\" class=n>←</a>\n";

		# 다음 블록
		} elsif ($x == $end+1) {

			$fw_bl = $in{'bl'}+1;
			print "| <a href=\"JavaScript:void(0)\" onClick=\"document.MOVE.page.value='$y';document.MOVE.bl.value='$fw_bl';document.MOVE.submit();return false;\" class=n>→</a>\n";

		}

		$x++;
		$y += $view;
		$i -= $view;
	}

	print "|\n";
}

#-------------------------------------------------
#  검색 처리
#-------------------------------------------------
sub search {
	local($file,$word,$view,$cond,$mode) = @_;
	local($i,$f,$top,$wd,$next,$back,@wd);

	# 검색어를 배열화
	$word =~ s/　/ /g;
	@wd = split(/\s+/, $word);

	# 파일 전개
	print "<dl>\n";
	$i = 0;
	open(IN,"$file") || &error("Open Error: $file");
#	$top = <IN> if($mode);
	$top = <IN> if ($mode ne "past");
	while (<IN>) {
		$f = 0;
		foreach $wd (@wd) {
			if (index($_,$wd) >= 0) {
				$f++;
				if ($cond eq 'OR') { last; }
			} else {
				if ($cond eq 'AND') { $f=0; last; }
			}
		}

		# 일치한 경우
		if ($f) {
			$i++;
			next if ($i < $page + 1);
			next if ($i > $page + $view);

			($no,$reno,$dat,$nam,$eml,$sub,$com,$url,$idname,$allyidname,$turn,$hos,$pw,$col,$ico) = split(/<>/);
			if ($eml) { $nam = "<a href=\"mailto:$eml\">$nam</a>"; }
			if ($url) { $url = "&lt;<a href=\"$url\" target=\"_blank\">Home</a>&gt;"; }
			if(($dead ne '') || $owner || $amity) {
				1 while $com =~ s/(.*)(&lt;(amity)&gt;(.*)&lt;\/amity&gt;)/$1<span class=\'amity\'>$4<\/span>/i;
			} else {
				1 while $com =~ s/(.*)(&lt;(amity)&gt;(.*)&lt;\/amity&gt;)/$1/i;
			}
			my $iName = '';
			if($allyidname ne '') {
				if($idname eq '0') {
					$iName = "${atMark}$ally_name[0]";
				} elsif($idname ne '') {
					$iName = "${atMark}${idname}${AfterName}";
				}
			}
			my $turnStr = " [턴<span class='turn'>$turn</span>] " if($turn);

			# 결과 표시
			print "<dt><hr>[<b>$no</b>] <span class='subject'>$sub</span> ";
			print "작성자：<b>$nam$iName</b> 등록일：$dat $url$turnStr<br><br>\n";
			print "<dd style='color:$col'>$com\n";
		}
	}
	close(IN);

	print <<EOM;
<dt><hr>
검색 결과：<b>$i</b>건
</dl>
EOM
	$next = $page + $view;
	$back = $page - $view;
	return ($i, $next, $back);
}

#-------------------------------------------------
#  URL 인코딩
#-------------------------------------------------
sub url_enc {
	local($_) = @_;

	s/(\W)/'%' . unpack('H2', $1)/eg;
	s/\s/+/g;
	$_;
}

#-------------------------------------------------
#  crypt 암호
#-------------------------------------------------
sub encrypt {
	local($inpw) = @_;
	local(@char, $salt, $encrypt);

	@char = ('a'..'z', 'A'..'Z', '0'..'9', '.', '/');
	srand;
	$salt = $char[int(rand(@char))] . $char[int(rand(@char))];
	$encrypt = crypt($inpw, $salt) || crypt ($inpw, '$1$' . $salt);
	$encrypt;
}

#-------------------------------------------------
#  crypt 대조
#-------------------------------------------------
sub decrypt {
	local($in, $dec) = @_;

	local $salt = $dec =~ /^\$1\$(.*)\$/ && $1 || substr($dec, 0, 2);
	if (crypt($in, $salt) eq $dec || crypt($in, '$1$' . $salt) eq $dec) {
		return (1);
	} else {
		return (0);
	}
}

1;

__END__
