#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}
#----------------------------------------------------------------------
# 하코니와 제도 ver2.30
# 턴진행모듈(ver1.02)
# 사용 조건과 사용 방법은 hako-readme.txt 파일을 참조해 주세요
#
# 하코니와 제도의 페이지: http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html
#----------------------------------------------------------------------
#----------------------------------------------------------------------
# Hakoniwa R.A. ver1.11
# 메인 스크립트(하코니와 제도 ver2.30)
# 사용 조건, 사용 방법은 read-renas.txt 파일을 참조
#
# KEI PAGE: http://www5b.biglobe.ne.jp/~k-e-i/
#----------------------------------------------------------------------

# 주변 8헥스의 좌표
@ax = (0,1,1,1,0,-1,0,1,2,2,2,1,0,-1,-1,-2,-1,-1,0,2,2,3,3,3,2,2,1,0,-1,-2,-2,-3,-2,-2,-1,0,1,2,3,3,4,4,4,3,3,2,1,0,-1,-2,-2,-3,-3,-4,-3,-3,-2,-2,-1,0,1,3,3,4,4,5,5,5,4,4,3,3,2,1,0,-1,-2,-3,-3,-4,-4,-5,-4,-4,-3,-3,-2,-1,0,1,2,3,4,4,5,5,6,6,6,5,5,4,4,3,2,1,0,-1,-2,-3,-3,-4,-4,-5,-5,-6,-5,-5,-4,-4,-3,-3,-2,-1,0,1,2,4,4,5,5,6,6,7,7,7,6,6,5,5,4,4,3,2,1,0,-1,-2,-3,-4,-4,-5,-5,-6,-6,-7,-6,-6,-5,-5,-4,-4,-3,-2,-1,0,1,2,3,4,5,5,6,6,7,7,8,8,8,7,7,6,6,5,5,4,3,2,1,0,-1,-2,-3,-4,-4,-5,-5,-6,-6,-7,-7,-8,-7,-7,-6,-6,-5,-5,-4,-4,-3,-2,-1,0,1,2,3);
@ay = (0,-1,0,1,1,0,-1,-2,-1,0,1,2,2,2,1,0,-1,-2,-2,-3,-2,-1,0,1,2,3,3,3,3,2,1,0,-1,-2,-3,-3,-3,-4,-3,-2,-1,0,1,2,3,4,4,4,4,4,3,2,1,0,-1,-2,-3,-4,-4,-4,-4,-5,-4,-3,-2,-1,0,1,2,3,4,5,5,5,5,5,5,4,3,2,1,0,-1,-2,-3,-4,-5,-5,-5,-5,-5,-6,-5,-4,-3,-2,-1,0,1,2,3,4,5,6,6,6,6,6,6,6,5,4,3,2,1,0,-1,-2,-3,-4,-5,-6,-6,-6,-6,-6,-6,-7,-6,-5,-4,-3,-2,-1,0,1,2,3,4,5,6,7,7,7,7,7,7,7,7,6,5,4,3,2,1,0,-1,-2,-3,-4,-5,-6,-7,-7,-7,-7,-7,-7,-7,-8,-7,-6,-5,-4,-3,-2,-1,0,1,2,3,4,5,6,7,8,8,8,8,8,8,8,8,8,7,6,5,4,3,2,1,0,-1,-2,-3,-4,-5,-6,-7,-8,-8,-8,-8,-8,-8,-8,-8);

@Htowns = ($HlandTown, $HlandProcity, $HlandMinato, $HlandFrocity, $HlandNewtown, $HlandBigtown, $HlandBettown, $HlandOnsen, $HlandRizort, $HlandBigRizort, $HlandShuto, $HlandUmishuto, $HlandSeatown, $HlandSeacity);
@Hseas = ($HlandSea, $HlandSbase, $HlandSeacity, $HlandSeatown, $HlandIce, $HlandFrocity, $HlandUmishuto, $HlandFune, $HlandUmiamu, $HlandOil, $HlandNursery);
#----------------------------------------------------------------------
# 턴진행 모드
#----------------------------------------------------------------------
# 메인
sub turnMain {
	# 순서결메
	my(@order, @line);

	$HsepTurnFlag = 0;
	$sepTurn = $HsepTurn;
	if(!$HsepTurn || $HsepTurn>= $HislandNumber) {
		@order = randomArray($HislandNumber);
		$sepTurn = $HislandNumber;
	} else {
		$HsepTurnFlag = 1;
		unless(-e "${HdirName}/septurn.cgi") {
			@order = randomArray($HislandNumber);
			if(!open(SOUT, ">${HdirName}/septurn.cgi")) {
				unlock();
				tempProblem();
				exit(0);
			}
			my $c = 0;
			foreach (@order) {
				$c++;
				print SOUT $_;
				if(($c % $HsepTurn == 0) || ($c == $HislandNumber)) {
					print SOUT "\n";
				} else {
					print SOUT ",";
				}
			}
			close(SOUT);
		}
		if(!open(IN, "${HdirName}/septurn.cgi")) {
			unlock();
			tempProblem();
			exit(0);
		}
		@line = <IN>;
		close(IN);
		if($line[0] ne '') {
			chomp($line[0]);
			@order = split(',', $line[0]);
			close(IN);
			$rest = $#order + 1;
			$sepTurn = $rest if($HsepTurn> $rest);
			if(!open(SOUT, ">${HdirName}/septurn.cgi")) {
				unlock();
				tempProblem();
				exit(0);
			}
			shift(@line);
			print SOUT join('', @line);
			close(SOUT);
		} else {
			unlink("${HdirName}/septurn.cgi");
			$HsepTurnFlag = 0;
			$sepTurn = 0;
		}
	}

	# 최종 갱신 시간을 갱신
	$HislandLastTime += $HunitTime;
	# 턴번호
	$HislandTurn++;

	if($HallyNumber) { # 동맹의 정세를 표시스 데이터의 지우기
		for($i = 0; $i < $HallyNumber; $i++) {
			$Hally[$i]->{'ext'}[0] = 0;
			$Hally[$i]->{'ext'}[1] = 0;
			$Hally[$i]->{'ext'}[2] = 0;
			$Hally[$i]->{'ext'}[3] = 0;
			$Hally[$i]->{'ext'}[4] = 0;
		}
	}

	my($i, $j, $s, $d);

	# 좌표배열을 만들기
	makeRandomPointArray();

	unlink("${HdirName}/hakojima.lhc") if((-e "${HdirName}/hakojima.lhc") && !($HislandTurn % 100));

	if($HarmisticeTurn && ($HislandTurn < $HarmisticeTurn)) {
		# 휴전 기간은 무재해
		$HnoDisFlag = 1;
	} else {
		# 재해있음
		$HnoDisFlag = 0;
	}

	# 수입, 소비단계
	for($i = 0; $i < $sepTurn; $i++) {
		# 턴 시작 전의 포인트, 자금, 인구를 기록
		$Hislands[$order[$i]]->{'oldPts'} = $Hislands[$order[$i]]->{'pts'};
		$Hislands[$order[$i]]->{'oldMoney'} = $Hislands[$order[$i]]->{'money'};
		$Hislands[$order[$i]]->{'oldFood'} = $Hislands[$order[$i]]->{'food'};
		$Hislands[$order[$i]]->{'oldPop'} = $Hislands[$order[$i]]->{'pop'};
		# 각종의 값을 계산
		estimate($order[$i]);
		next if($Hislands[$order[$i]]->{'predelete'});
		# 수입단계
		income($Hislands[$order[$i]]);
	}

	# 명령 처리
	my($island);
	for($i = 0; $i < $sepTurn; $i++) {
		$island = $Hislands[$order[$i]];
		next if($island->{'predelete'});
		# 반환 값1이 이 될 때까지 반복
		while(!doCommand($island)){};
		# 개간 로그(정리해서 로그 출력)
		logMatome($island, $HlogOmit2, 'seichi') if($HlogOmit2);
	}

	# 성장 및 단일 헥스 재해
	for($i = 0; $i < $sepTurn; $i++) {
		next if($Hislands[$order[$i]]->{'predelete'});
		$HflagKai = 0;
		doEachHex($Hislands[$order[$i]]);
	}

	# 참가 섬에 대한 제재 내용을 읽기
	readPunishData();

	my($remainCampNumber);
	if($HarmisticeTurn) {
		# 진영소멸판정
		$remainCampNumber = $HallyNumber;
		if ($HcampDeleteRule) {
			my($threshold) = 100 / $HallyNumber / 2;
			for ($i=0; $i<$HallyNumber; $i++) {
				if ($Hally[$i]->{'occupation'} < $threshold) {
					islandDeadAlly('', $Hally[$i]->{'id'}, $Hally[$i]->{'name'});
					foreach (@{$Hally[$i]->{'memberId'}}){
						$Hislands[$HidToNumber{$_}]->{'dead'} = 1;
					}
					$remainCampNumber--;
					logCampDelete($Hally[$i]->{'name'});
				}
			}
		}
	}
	# 섬 전체 처리
	for($i = 0; $i < $sepTurn; $i++) {
		$island = $Hislands[$order[$i]];
		next if($island->{'predelete'});
		doIslandProcess($order[$i], $island);
		doIslandunemployed($order[$i], $island) if($island->{'id'} <= 100);
	}

	if(!$HsepTurnFlag){
		my($remainNumber) = $HislandNumber;
		@order = randomArray($HislandNumber) if($HsepTurn);
		# 수상 관계와 증가률 처리
		foreach $i (0..$islandNumber) {
			$island = $Hislands[$order[$i]];
			doPrize($order[$i], $island) if(!$HsepTurn || $HsepTurn> $islandNumber);

			# 사멸판정
			if($island->{'dead'}) {
				$island->{'pop'} = 0;
				$island->{'pts'} = 0;
				$island->{'field'} = 0;
				$remainNumber--;
			} elsif(($island->{'pop'} == 0) && ($island->{'id'} <= 100)) {
				$island->{'dead'} = 1;
				$island->{'pts'} = 0;
				$remainNumber--;
				# 사멸 메시지
				my($tmpid) = $island->{'id'};
				islandDeadAlly($island) if($HallyNumber);
				$HidToNumber{$tmpid} = undef;
				logDead($tmpid, islandName($island));
				unlink("${HdirName}/${tmpid}.${HsubData}");
				unlink("${HdirName}/savedata.$tmpid") if(-e "${HdirName}/savedata.$tmpid");
			}
		}

		# Ranking 기록
		@HrankingID = ();
		foreach $i (0..$islandNumber) {
			my @hcdata = split(/,/, $Hislands[$i]->{'eisei4'});
			$Hislands[$i]->{'hcdata'} = \@hcdata;
			if($hcdata[10]>= 10) {
				$Hislands[$i]->{'hcover'} = 1;
			}
			$Hislands[$i]->{'kachiten'} = $hcdata[3]*3 + $hcdata[4];
			$Hislands[$i]->{'kachitent'} = $hcdata[6]*3 + $hcdata[7];
			my $siaisu = $hcdata[6] + $hcdata[7] + $hcdata[8];
			$siaisu = 1 if($siaisu == 0);
			$Hislands[$i]->{'shoritu'} = int($hcdata[6] / $siaisu * 100);
			$Hislands[$i]->{'teamforce'} = $hcdata[0] + $hcdata[1] + $hcdata[2];
			$Hislands[$i]->{'styusho'} = $hcdata[9];

			my($mshp, $msap, $msdp, $mssp) = (split(/,/, $Hislands[$i]->{'eisei5'}))[0..3];
			$Hislands[$i]->{'force'} = $mshp + $msap + $msdp + $mssp;

			foreach (split(/,/, $Hislands[$i]->{'eisei6'})) {
				$Hislands[$i]->{'tuni'} += $_;
				$Hislands[$i]->{'uni'}++ if($_> 0);
			}
		}
		my @elements = ( 'pop', 'farm', 'factory', 'mountain', 'fore', 'tare', 'zipro', 'leje', 'monsterlive', 'taiji', 'monta', 'hamu', 'pika', 'kei', 'rena', 'force', 'eisei2', 'uni', 'teamforce', 'styusho', 'shoritu', 'kachitent', 'kachiten');
		my @islands;
		my @ids;
		foreach (@elements) {
			$islands{$_} = islandSort($_);
			push(@HrankingID, $islands{$_}->{'id'});
		}

		if(($HislandTurn % 100) == 41) {
			my $stsin = '';
			my @HCislands = @Hislands;
			my @idx = (0..$#Hislands);
			@idx = sort { $Hislands[$a]->{'field'} <=> $Hislands[$b]->{'field'} ||
							$Hislands[$a]->{'hcover'} <=> $Hislands[$b]->{'hcover'} ||
							$Hislands[$b]->{'hcdata'}[3] <=> $Hislands[$a]->{'hcdata'}[3] ||
							$Hislands[$b]->{'hcdata'}[4] <=> $Hislands[$a]->{'hcdata'}[4] ||
							$Hislands[$a]->{'hcdata'}[5] <=> $Hislands[$b]->{'hcdata'}[5] ||
							$Hislands[$b]->{'hcdata'}[6] <=> $Hislands[$a]->{'hcdata'}[6] ||
							$Hislands[$b]->{'hcdata'}[7] <=> $Hislands[$a]->{'hcdata'}[7] ||
							$Hislands[$a]->{'hcdata'}[8] <=> $Hislands[$b]->{'hcdata'}[8] ||
							$a <=> $b } @idx;
			@HCislands = @HCislands[@idx];

			for($i = 0; $i < 8; $i++) {
				my($sto, $std, $stk, $stwin, $stdrow, $stlose, $stwint, $stdrowt, $stloset, $styusho, $stshoka) = split(/,/, $HCislands[$i]->{'eisei4'});
				if($stshoka != 0) {
					$stshoka = 6;
					$HCislands[$i]->{'eisei4'} = "$sto,$std,$stk,$stwin,$stdrow,$stlose,$stwint,$stdrowt,$stloset,$styusho,$stshoka";
					$stsin.= islandName($HCislands[$i]). ",";
				}
			}
			logHCsin($id, $name, $stsin) if($stsin ne '');
		}
		# 포인트순에정렬
		islandSort('pts', 1);

		# 역대 최다인구기록 처리
		islandReki();

		# 시상 대상 턴이면, 그 처리
		if(!($HislandTurn % $HturnPrizeUnit) || !($HislandTurn % 1111)) {
			my($island) = $Hislands[$HbfieldNumber];

			my($value, $str);
			$value = $HislandTurn + random(1001);
			$island->{'money'} += $value;
			logPrizet($island->{'id'}, islandName($island), "$HislandTurn${Hprize[0]}", "$value$HunitMoney");
			if($island->{'sin'}> 0) {
				$value = $HislandTurn + random(1001);
				$island->{'money'} += $value;
				logSinMoney($island->{'id'}, islandName($island), "$value$HunitMoney");
			}
			if($island->{'jin'}> 0) {
				$value = $HislandTurn + random(1001);
				$island->{'money'} += $value;
				logJinMoney($island->{'id'}, islandName($island), "$value$HunitMoney");
			}

			my($prize1, $prize2) = split(/\t/, $island->{'prize'});
			$prize1.= "${HislandTurn},";
			$island->{'prize'} = "$prize1\t$prize2";
		}

		# 섬 수자르기
		$HislandNumber = $remainNumber;
		$islandNumber = $remainNumber - 1;

		# 최하위 탈락 시의 턴이면 처리(서바이벌 모드)
		if( $HsurvivalTurn && !(($HislandTurn - $HsurvivalTurn) % $HturnDead) && ($HislandTurn> $HsurvivalTurn) ) {
			if($islandNumber> $HbfieldNumber){
				my $i = 1;
				my($island) = $Hislands[$islandNumber];
				$island->{'dead'} = 1;
				$island->{'pop'} = 0;
				$island->{'pts'} = 0;
				$remainNumber--;
				# 사멸 메시지
				my($tmpid) = $island->{'id'};
				islandDeadAlly($island) if($HallyNumber);
				logTDead($tmpid, islandName($island));
				unlink("${HdirName}/${tmpid}.${HsubData}");
				unlink("${HdirName}/savedata.$tmpid") if(-e "${HdirName}/savedata.$tmpid");

				# 섬 수자르기
				$HislandNumber = $remainNumber;
				$islandNumber = $remainNumber - 1;
			}
		}

		if($HallyNumber) { # 동맹 관련 처리
			# 진영자르기(소멸규칙)
			$HallyNumber = $remainCampNumber if($HarmisticeTurn);
			for($i = 0; $i < $HallyNumber; $i++) {
				$Hally[$i]->{'score'} = 0;
				# 유지비(무인 섬이 되었을 때의 머릿수 할당에서 처리)
				my $keepCost = int($HcostKeepAlly / $Hally[$i]->{'number'}) if($Hally[$i]->{'number'});
				$Hally[$i]->{'number'} = 0;
				my $allyMember = $Hally[$i]->{'memberId'};
				foreach (@$allyMember) {
					my $no = $HidToNumber{$_};
					if(defined $no) {
						$Hally[$i]->{'score'} += $Hislands[$no]->{'pts'};
						$Hally[$i]->{'number'}++;
						# 유지비징 수
						$Hislands[$no]->{'money'} -= $keepCost if(!$HarmisticeTurn);;
						$Hislands[$no]->{'money'} = 0 if($Hislands[$no]->{'money'} < 0);
						# 공헌도(인구라면1만 명에 관련1포인트)
						$Hislands[$no]->{'ext'}[1] += int($island->{'pop'}/10);
					}
				}
				$Hally[$i]->{'Takayan'} = makeRandomString();
			}
			allyOccupy();
			allySort();
		}

		# 승자판정(서바이벌 모드)
		if( $HsurvivalTurn && ($islandNumber == $HbfieldNumber) && ($HislandTurn> $HsurvivalTurn) ) {
			$Hislands[$HbfieldNumber]->{'name'} = '[승자!]'. $Hislands[$HbfieldNumber]->{'name'};
		}

		# 종료조건의 판정
		my $n = gameOver();
		if ($HarmisticeTurn && ($HislandTurn <= $HgameLimitTurn) && $n != -1) {
			logHistory("${HtagName_}${Hally[$n]->{'name'}}${H_tagName}이<B>승리</B>했습니다!");
			$Hally[$n]->{'name'} = '[승자!]'. $Hally[$n]->{'name'};
			$repeatTurn = 0;
			$HplayNow = 0;
		}

		##### toto&Numbers 처리여기에서
		unless($HislandTurn % 10) {
			require('./hako-toto.cgi');

			totoMain() unless ($HislandTurn % $HturnPrizeUnit);
			numbersMain(3) if(!($HislandTurn % 20));
			numbersMain(4) if(($HislandTurn % 20) == 10);
		}
		##### 여기까지

		# Hakoniwa Cup 개최 로그
		logHC($id, $name, $Hstsanka) if(!($HislandTurn % 100) && $Hstsanka);

		# 백업 턴이면 삭제 전에 rename
		if(!($HislandTurn % $HbackupTurn)) {
			my($i);
			my($tmp) = $HbackupTimes - 1;
			myrmtree("${HdirName}.bak$tmp");
			for($i = $tmp; $i> 0; $i--) {
				my($j) = $i - 1;
				rename("${HdirName}.bak$j", "${HdirName}.bak$i");
			}
			rename("${HdirName}", "${HdirName}.bak0");
			mkdir("${HdirName}", $HdirMode);

			# 로그 파일을 복사
			for($i = 0; $i <= $HlogMax; $i++) {
				copy("${HdirName}.bak0/hakojima.log$i", "${HdirName}/hakojima.log$i") if(-e "${HdirName}.bak0/hakojima.log$i");
			}
			copy("${HdirName}.bak0/hakojima.his", "${HdirName}/hakojima.his") if(-e "${HdirName}.bak0/hakojima.his");
			copy("${HdirName}.bak0/hakojima.lhc", "${HdirName}/hakojima.lhc") if(-e "${HdirName}.bak0/hakojima.lhc");
			copy("${HdirName}.bak0/rekidai.dat", "${HdirName}/rekidai.dat") if(-e "${HdirName}.bak0/rekidai.dat");

			# savedata(시간 저장)이있다면복사
			foreach $i (0..$islandNumber) {
				my($island) = $Hislands[$i];
				copy("${HdirName}.bak0/savedata.$island->{'id'}", "${HdirName}/savedata.$island->{'id'}") if(-e "${HdirName}.bak0/savedata.$island->{'id'}");
			}
			if($HsepTurn) {
				rename("${HdirName}.bak0/secret.tmp", "${HdirName}/secret.tmp");
				rename("${HdirName}.bak0/late.tmp", "${HdirName}/late.tmp");
				rename("${HdirName}.bak0/log.tmp", "${HdirName}/log.tmp");
			}
		}

		# 파일에쓰기
		writeIslandsFile(-1);

		# 로그 파일을 뒤에밀기
		for($i = ($HlogMax - 1); $i>= 0; $i--) {
			$j = $i + 1;
			$s = "${HdirName}/hakojima.log$i";
			$d = "${HdirName}/hakojima.log$j";
			unlink($d);
			rename($s, $d);
		}

##### 추가 친분20020307
		if($Hperformance) {
			my($uti, $sti, $cuti, $csti) = times();
			$uti += $cuti;
			$sti += $csti;
			my($cpu) = $uti + $sti;
#			로그 파일 쓰기(테스트 계측용, 평소에는 주석 처리해 주세요)
#			open(POUT,">>cpu-t.log");
#			print POUT "CPU($cpu) : user($uti) system($sti)\n";
#			close(POUT);
			logLate("<SMALL>부하계측 CPU($cpu) : user($uti) system($sti)</SMALL>",0);
		}
#####

		if($HsepTurn && ($HsepTurn < $HislandNumber)) {
			my(@tmpSecretLogPool, @tmpLateLogPool, @tmpLogPool);
			open(LIN, "${HdirName}/secret.tmp");
			@tmpSecretLogPool = <LIN>;
			chomp(@tmpSecretLogPool);
			close(LIN);
			unlink("${HdirName}/secret.tmp");

			open(LIN, "${HdirName}/late.tmp");
			@tmpLateLogPool = <LIN>;
			chomp(@tmpLateLogPool);
			close(LIN);
			unlink("${HdirName}/late.tmp");

			open(LIN, "${HdirName}/log.tmp");
			@tmpLogPool = <LIN>;
			chomp(@tmpLogPool);
			close(LIN);
			unlink("${HdirName}/log.tmp");

			@HsecretLogPool = (@tmpSecretLogPool, @HsecretLogPool);
			@HlateLogPool = (@tmpLateLogPool, @HlateLogPool);
			@HlogPool = (@tmpLogPool, @HlogPool);
		}
		# 로그 쓰기
		logFlush();

		# 기록 로그 조정
#		logHistoryTrim();
#		logHcupTrim();# 참고: 전쟁실적 표시 때문에 자르기

		if($HhtmlLogMake) {
			if(-e "${HhtmlDir}/hakolog.html") {
				unlink("${HhtmlDir}/hakolog.html");
			}
		}
		# 맨 위로
		require('./hako-top.cgi');
		topPageMain();
	} else {
		for($i = 0; $i < $sepTurn; $i++) {
			$island = $Hislands[$order[$i]];
			doPrize($order[$i], $island);

			# 사멸판정
			if($island->{'dead'}) {
				$island->{'pop'} = 0;
				$island->{'pts'} = 0;
				$island->{'field'} = 0;
			}
		}
		# 최종 갱신 시간을 갱신
		$HislandLastTime -= $HunitTime;
		# 턴번호
		$HislandTurn--;
		# 파일에쓰기
		writeIslandsFile(-1);

##### 추가 친분20020307
		if($Hperformance) {
			my($uti, $sti, $cuti, $csti) = times();
			$uti += $cuti;
			$sti += $csti;
			my($cpu) = $uti + $sti;
#			로그 파일 쓰기(테스트 계측용, 평소에는 주석 처리해 주세요)
#			open(POUT,">>cpu-t.log");
#			print POUT "CPU($cpu) : user($uti) system($sti)\n";
#			close(POUT);
			logLate("<SMALL>부하계측 CPU($cpu) : user($uti) system($sti)</SMALL>",0);
		}
#####

		# tmp 로그 쓰기
		tempLogFlush();

		if($HhtmlLogMake) {
			if(-e "${HhtmlDir}/hakolog.html") {
				unlink("${HhtmlDir}/hakolog.html");
			}
		}
		my $all = $HislandNumber / $HsepTurn + 1;
		my $all = ($all == int($all)) ? $all : int($all) + 1;
		my $count = $all - $#line - 2;
		tempRefresh($Hrefresh, "턴 갱신 중(${count}/${all})<BR>그대로 잠시 기다려 주세요");
	}
}

# 종료여부
sub gameOver {
	# 시간절레
	if($HgameLimitTurn) {
		if ($HislandTurn>= $HgameLimitTurn) {
			# 중단된 진영을 되돌림
			return 0;
		}
	}
	# 콜드
	my($i);
	for ($i = 0; $i < $HallyNumber; $i++) {
		if ($Hally[$i]->{'occupation'}>= $HfinishOccupation) {
			return $i;
		}
	}
	return -1;
}

# 파일을 원형마다복사
sub copy {
	my($src, $dest) = @_;

	open(FS, "<$src") || die $!;
	open(FD, ">$dest") || die $!;
	binmode(FS); # Windows 로컬에서는 필요
	binmode(FD); # Windows 로컬에서는 필요

	my $buf;
	while (read(FS, $buf, 1024 * 8)> 0) {
		print FD $buf;
	}

	close(FD);
	close(FS);
}

# 디렉터리 삭제
sub myrmtree {
	my($dn) = @_;
	opendir(DIN, "$dn/");
	my($fileName);
	while($fileName = readdir(DIN)) {
		unlink("$dn/$fileName");
	}
	closedir(DIN);
	rmdir($dn);
}

# 참가 섬에 대한 제재 내용을 읽기
sub readPunishData
{
	if (open(Fpunish, "<${HdirName}/punish.dat")) {
		local(@_);
		my($island);
		while (<Fpunish>) {
			chomp;
			@_ = split(',');
			my($obj);
			$obj->{id} = shift;
			$obj->{punish} = shift;
			$obj->{x} = shift;
			$obj->{y} = shift;

			$HpunishInfo{$obj->{id}} = $obj;
		}
		close(Fpunish);
	}

	# 제재 데이터를 삭제
	unlink("${HdirName}/punish.dat");
}

sub tempRefresh {
	my($delay, $str) = @_;
	my $next = $HislandTurn + 1;
		out(<<END);
<meta HTTP-EQUIV='refresh' CONTENT='$delay; URL="$HthisFile?UNLOCK=$HsepTurnFlag"'>
<H1><small>턴</small> ${HislandTurn} => ${next}</H1>
<H2>$str</H2>
END
}

# 수입, 소비단계
sub income {
	my($island) = @_;
	my($pop, $farm, $factory, $mountain) =
	(
		$island->{'pop'},
		$island->{'farm'} * 10,
		$island->{'factory'},
		$island->{'mountain'}
	);

	# 수입
	if($pop> $farm) {
		# 농업만으로 인력이 남는 경우
		$island->{'food'} += int($farm * ($co0 + 1) * $Hfood1Incom[$Hmonth]/100); # 농장 전체가동
		$island->{'money'} += int(min(int(($pop - $farm) / 10), $factory + $mountain) * ($co1 + 1) * $Hmoney1Incom[$Hmonth]/100);
	} else {
		# 농장 규모가 최대치인 경우
		$island->{'food'} += int($pop * ($co0 + 1) * $Hfood1Incom[$Hmonth]/100); # 전체나 생 직원일
	}

	# 식량소비
	$island->{'food'} -= int($pop * $HeatenFood * $HeatenFoodS[$Hmonth]/100);
	$island->{'food'} = 0 if(($island->{'id'}> 100) && ($island->{'food'} < 0));
}


# 명령 단계
sub doCommand {
	my($island) = @_;
	# 명령 처리 시작
	my($comArray, $command);
	$comArray = $island->{'command'};
	$command = $comArray->[0]; # 첫 항목을 꺼냄
	slideFront($comArray, 0); # 이후를 막힘하기

	# 각 요소 꺼내기
	my($kind, $target, $x, $y, $arg) =
	(
		$command->{'kind'},
		$command->{'target'},
		$command->{'x'},
		$command->{'y'},
		$command->{'arg'}
	);

	# 도출 값
	my($name) = islandName($island);
	my($id) = $island->{'id'};
	my($land) = $island->{'land'};
	my($landValue) = $island->{'landValue'};
	my($landKind) = $land->[$x][$y];
	my($lv) = $landValue->[$x][$y];
	my($cost) = $HcomCost[$kind];
	my($comName) = $HcomName[$kind];
	my($point) = "($x, $y)";
	my($landName) = landName($landKind, $lv);

	if(($kind == $HcomDoNothing) && ($id <= 100)) {
		# 자금융통
#		logPropaganda($id, $name, $comName);
		$island->{'money'} += int(10 * $Hmoney1Incom[$Hmonth]/100);
		if($HeasyMode) {
			$island->{'money'} += random(100);
			if(random(100) < 5) {
				my $value = 1+ random(1999);
				$island->{'money'} += $value;
				# 수입 로그
				logEnjo($id, $name, landName($landKind, $lv), "($x, $y)", "$value$HunitMoney") if ($value> 0);
			}
		}
		$island->{'absent'} ++;

		# 진영 위임 임시판정
		if ($HarmisticeTurn && ($island->{'absent'}> $HpreGiveupTurn)) {
			# passward 을 진영 비밀번호에 변경(매 턴)
#			$island->{'password'} = encode($ally->{'Takayan'});
			$island->{'preab'} = 1;
			$island->{'comment'} = "이 ${AfterName}은 진영 위임 임시 상태가 되었습니다.";
		}

		# 자동포기
		if($island->{'absent'}>= $HgiveupTurn) {
			$comArray->[0] = {
				'kind' => $HcomGiveup,
				'target' => 0,
				'x' => 0,
				'y' => 0,
				'arg' => 0
			}
		}
		return 1;
	}

	$island->{'absent'} = 0;

	if($kind == $HcomHouse) {
		$cost = $island->{'pts'} * 3;
	} elsif(($kind == $HcomBettown) || ($kind == $HcomKai)) {
		$cost = $island->{'pts'};
	}
	if ($island->{'htf'}> 0) {
		$cost = int($cost * 2 / 3);
	}
	# 비용 확인
	if(($cost> 0) && ($island->{'money'} < $cost) && ($kind != $HcomFarmcpc)){# 금의 경우(가축판매의 경우, 비용 확인하지 않음)
		logNoAny($id, $name, $comName, "자금 부족의");
		return 0;
	} elsif(($cost < 0) && ($island->{'food'} < (-$cost))){# 식량의 경우
		logNoAny($id, $name, $comName, "비축 식량 부족의");
		return 0;
	}

	# 명령에서 분기
	if(($kind == $HcomPrepare) || ($kind == $HcomPrepare2)) {
		# 개간, 땅고르기
		if(($landKind == $HlandSea) ||
			($landKind == $HlandSbase) ||
			($landKind == $HlandSeacity) ||
			($landKind == $HlandSeatown) ||
			($landKind == $HlandNursery) ||
			($landKind == $HlandOil) ||
			($landKind == $HlandIce) ||
			($landKind == $HlandFune) ||
			($landKind == $HlandFrocity) ||
			($landKind == $HlandUmiamu) ||
			($landKind == $HlandGold) ||
			($landKind == $HlandShrine) ||
			($landKind == $HlandRottenSea) ||
			($landKind == $HlandMountain) ||
			($landKind == $HlandHugeMonster) ||
			($landKind == $HlandUmishuto) ||
			($landKind == $HlandMonster)) {
			# 바다, 해저 기지, 해저 도시, 해저 신도시, 유전, 선박, 양식장, 해상 시설, 금광산, 시간의 신전, 오염된 바다, 산, 괴수는 개간할 수 없
			logLandFail($id, $name, $comName, $landName, $point);
			return 0;
		}
		if($landKind == $HlandMonument) {
			if((79 < $lv) && ($lv < 84)) {
				$island->{'food'} += 20000; # 먹은 만큼
			} elsif((73 < $lv) && ($lv < 80)) {
				$island->{'money'} += 20000; # 보물석회회사매각
			}
		}
		# 대상 위치를 평지로
		$land->[$x][$y] = $HlandPlains;
		$landValue->[$x][$y] = 0;
		if($HlogOmit2) {
			my $sno = $island->{'seichi'};
			$island->{'seichi'}++;
			if($HlogOmit2 == 1) {
				my $seichipnt;
				($seichipnt->{x}, $seichipnt->{y}) = ($x, $y);
				$island->{'seichipnt'}->[$sno] = $seichipnt;
			}
		} else {
			logLandSuc($id, $name, '개간', $point);
		}
		# 돈을 차감
		$island->{'money'} -= $cost;

		if($kind == $HcomPrepare2) { # 땅고르기
			$island->{'prepare2'}++;
			# 턴 소비하지 않고
			return 0;
		} else {
			# 땅고르기이면 매장금 발견 가능성 있음
			if(!$HnoDisFlag && random(1000) < $HdisMaizo[$Hmonth]) {
				my($v) = 100 + random(901);
				$island->{'money'} += $v;
				logMaizo($id, $name, $comName, $v);
			}
			return 1;
		}

	} elsif(($kind == $HcomReclaim) || ($kind == $HcomReclaim2) || ($kind == $HcomMinato) || ($kind == $HcomSeki)) {
		# 매립, 원거리 매립, 항구, 관문

		my $flag = 1;
		# 주변에육이 있는 지 확인
		my($seaCount) = countAround($land, $x, $y, 7, @Hseas);
		if(($seaCount == 7) && ($kind != $HcomReclaim2) && ($kind != $HcomSeki)) {
			# 전체 바다의 때, 매립, 항구건설은 불능
			logLandFail2($id, $name, $comName, $point, "주변에육지가 없었습니다");
			return 0;
		}

		if(($kind == $HcomReclaim) || ($kind == $HcomReclaim2)) {
			# 매립
			if(($landKind != $HlandSea) &&
				($landKind != $HlandSbase) &&
				($landKind != $HlandSeacity) &&
				($landKind != $HlandSeatown) &&
				($landKind != $HlandNursery) &&
				($landKind != $HlandOil) &&
				($landKind != $HlandUmiamu) &&
				($landKind != $HlandPlains) &&
				($landKind != $HlandUmishuto) &&
				($landKind != $HlandWaste)) {
				# 바다, 유전, 해상 시설, 해저 기지, 해저 도시, 해저 신도시, 평지, 황무지, 양식장, 만매립할 수 없
				logLandFail($id, $name, $comName, $landName, $point);
				return 0;
			}
			if(($landKind == $HlandSea) && ($lv == 1)) {
				# 얕은 바다의 경우
				# 대상 위치를 황무지로
				$land->[$x][$y] = $HlandWaste;
				$landValue->[$x][$y] = 0;
			} elsif($landKind == $HlandPlains || $landKind == $HlandWaste) {
				# 평지, 황무지라면, 대상 위치를 산로
				$land->[$x][$y] = $HlandMountain;
				$landValue->[$x][$y] = 0;
				$flag = 0;
			} else {
				# 바다, 유전, 양식장, 해상 시설, 해저 기지, 해저 도시, 해저 신도시라면, 대상 위치를 얕은 바다로
				$land->[$x][$y] = $HlandSea;
				$landValue->[$x][$y] = 1;
				$flag = 0;
			}

		} elsif($kind == $HcomMinato) {
			# 항구
			unless(($landKind == $HlandSea) && ($lv == 1)){
				# 얕은 바다만항구에할 수 없
				logLandFail($id, $name, $comName, $landName, $point);
				return 0;
			}
			# 대상 위치를 항구로
			$land->[$x][$y] = $HlandMinato;
			$landValue->[$x][$y] = 0;

		} elsif($kind == $HcomSeki) {
			# 관문
			if(($landKind != $HlandSea) || ($lv != 1)){
				# 얕은 바다만관문에할 수 없
				logLandFail($id, $name, $comName, $landName, $point);
				return 0;
			}
			# 대상 위치를 관문로
			$land->[$x][$y] = $HlandSeki;
			$landValue->[$x][$y] = 0;
		}
		logLandSuc($id, $name, $comName, $point);

		if($flag) {
			$island->{'area'}++;
			if($seaCount <= 4) {
			# 주변 바다가 3헥스 이내이므로, 얕은 바다로
				my($i, $sx, $sy);
				for($i = 1; $i < 7; $i++) {
					$sx = $x + $ax[$i];
					$sy = $y + $ay[$i];
					# 행 기준 위치 조정
					$sx-- if(!($sy % 2) && ($y % 2));
					# 범위 안의 경우
					if(($sx>= 0) && ($sx < $HislandSize) && ($sy>= 0) && ($sy < $HislandSize) &&
						($land->[$sx][$sy] == $HlandSea)) {
						$landValue->[$sx][$sy] = 1;
					}
				}
			}
		}
		# 돈을 차감
		$island->{'money'} -= $cost;
		return 1;

	} elsif($kind == $HcomFune) {
		# 조선·출항
		if($landKind != $HlandSea) {
			# 바다만조선할 수 없
			logLandFail($id, $name, $comName, $landName, $point);
			return 0;
		}
		# 주변에 항구가 있는 지 확인
		my($seaCount) = countAround($land, $x, $y, 7, $HlandMinato);
		if($seaCount == 0) {
			# 항구가 없으면 조선 불가
			logLandFail2($id, $name, $comName, $point, "주변에 항구 도시가 없었습니다");
			return 0;
		}
		# 비용 확인
		$value = $arg * $cost;
		if($island->{'money'} < $value) {
			logNoAny($id, $name, $comName, "자금 부족의");
			return 0;
		}
		if($arg == 77) {
			# 해상 도시로
			$land->[$x][$y] = $HlandFrocity;
			$landValue->[$x][$y] = 1;
		} else {
			# 대상 위치를 선박로
			$land->[$x][$y] = $HlandFune;
			$arg = 1 if($arg>= $HfuneNumber || !$arg);
			$landValue->[$x][$y] = $arg;
		}
		logLandSuc($id, $name, $comName, $point);
		# 돈을 차감
		$island->{'money'} -= $value;
		return 1;

	} elsif($kind == $HcomDestroy) {
		# 굴착
		if(($landKind == $HlandSbase) ||
			($landKind == $HlandSeacity) ||
			($landKind == $HlandSeatown) ||
			($landKind == $HlandNursery) ||
			($landKind == $HlandOil) ||
			($landKind == $HlandFune) ||
			($landKind == $HlandUmiamu) ||
			($landKind == $HlandFrocity) ||
			($landKind == $HlandRottenSea) ||
			($landKind == $HlandHugeMonster) ||
			($landKind == $HlandUmishuto) ||
			($landKind == $HlandMonster)) {
			# 해저 기지, 해저 도시, 해저 신도시, 유전, 선박, 양식장, 해상 시설, 오염된 바다, 괴수는 굴착할 수 없
			logLandFail($id, $name, $comName, $landName, $point);
			return 0;
		}
		if(($landKind == $HlandSea) && !$lv) {
			# 바다이면 유전 탐사 시
			# 투자액결정
			if ($HarmisticeTurn && ($HislandTurn <= $HgameLimitTurn)) {
				# 개발 기간 안은 유전금지
				logNotAvail($id, $name, $comName);
				return 0;
			}
			$arg = 1 if($arg == 0);
			my($value, $p);
			$p = ($arg * $cost> $island->{'money'}) ? int($island->{'money'} / $cost) : $arg;
			$value = $p * $cost;
			$island->{'money'} -= $value;
			# 보기사용는 가판정
			if($p> random(100) + $island->{'oil'} * 25) {
				# 유전보기사용루
				logOilFound($id, $name, $point, $comName, "$value$HunitMoney");
				$land->[$x][$y] = $HlandOil;
				$landValue->[$x][$y] = 0;
				$island->{'oil'}++;

				if($island->{'sin'}> 0) {
					$value = random(1001);
					$island->{'money'} += $value;
					# 수입 로그
					logSinMoney($id, $name, "$value$HunitMoney");
				}
				if($island->{'jin'}> 0) {
					$value = random(1001);
					$island->{'money'} += $value;
					# 수입 로그
					logJinMoney($id, $name, "$value$HunitMoney");
				}
			} else {
				# 헛발사치에끝나쁨
				logOilFail($id, $name, $point, $comName, "$value$HunitMoney");
			}
			return 1;
		}
		# 대상 위치를 얕은 바다로. 산, 금광산, 시간의 신전이면 황무지에. 얕은 바다이면 바다에.
		if(($landKind == $HlandMountain) || ($landKind == $HlandGold) || ($landKind == $HlandShrine)){
			$land->[$x][$y] = $HlandWaste;
			$landValue->[$x][$y] = 0;
		} elsif($landKind == $HlandSea) {
			$landValue->[$x][$y] = 0;
		} else {
			$land->[$x][$y] = $HlandSea;
			$landValue->[$x][$y] = 1;
			$island->{'area'}-- if($landKind != $HlandIce);
		}
		logLandSuc($id, $name, $comName, $point);
		# 돈을 차감
		$island->{'money'} -= $cost;
		return 1;

	} elsif($kind == $HcomOnsen) {
		# 온천 굴착
		if(($landKind == $HlandMountain) && ($lv == 0)) {
			# 산이면 온천 탐색 시
			# 투자액결정
			$arg = 1 if(!$arg);
			my($value, $p);
			$value = min($arg * ($cost), $island->{'money'});
			$p = int($value / $cost);
			$value = $p * $cost;
			$island->{'money'} -= $value;

			# 보기사용는 가판정
			if(random(10000) < $p * 15) {
				my($v) = 1000 + random(2001);
				$island->{'money'} += $v;
				$land->[$x][$y] = $HlandGold;
				$landValue->[$x][$y] = 1;
				logGold($id, $name, $comName, $v);

				if($island->{'sin'}> 0) {
					$value = random(1001);
					$island->{'money'} += $value;
					# 수입 로그
					logSinMoney($id, $name, "$value$HunitMoney");
				}
				if($island->{'jin'}> 0) {
					$value = random(1001);
					$island->{'money'} += $value;
					# 수입 로그
					logJinMoney($id, $name, "$value$HunitMoney");
				}

			} elsif(random(1000) < 50) {
				logEggFound($id, $name, $comName);
				$land->[$x][$y] = $HlandMonument;
				$landValue->[$x][$y] = 80 + random(3);
			} elsif(random(1000) < 50) {
				logIsekiFound($id, $name, $comName);
				$land->[$x][$y] = $HlandMonument;
				$landValue->[$x][$y] = 84;
			} elsif($p> random(100) + $island->{'hot'} * 30) {
				# 온천보기사용루
				logHotFound($id, $name, $point, $comName, "$value$HunitMoney");
				$land->[$x][$y] = $HlandOnsen;
				$landValue->[$x][$y] = 1;
			} else {
				# 헛발사치에끝나쁨
				logHotFail($id, $name, $point, $comName, "$value$HunitMoney");
			}

			if(random(1000) < 15) {
				my($v) = 100 + random(901);
				$island->{'money'} += $v;
				logMaizo($id, $name, $comName, $v);
			}

			return 1;
		} else {
			# 산이외는 굴착할 수 없
			logLandFail($id, $name, $comName, $landName, $point);
			return 0;
		}

	} elsif($kind == $HcomSellTree) {
		# 벌채
		if($landKind != $HlandForest) {
			# 숲이외는 벌채할 수 없
			logLandFail($id, $name, $comName, $landName, $point);
			return 0;
		}
		# 대상 위치를 평지로
		$land->[$x][$y] = $HlandPlains;
		$landValue->[$x][$y] = 0;
		logLandSuc($id, $name, $comName, $point);
		if(random(1000) < 75) {
			logEggFound($id, $name, $comName);
			$land->[$x][$y] = $HlandMonument;
			$landValue->[$x][$y] = 80 + random(3);
		}
		# 매각금을 얻기루
		$island->{'money'} += $HtreeValue * $lv;
		return 0; # 턴 소비 없음

		# 지상건설계
	} elsif(($kind == $HcomPlant) ||	# 나무심기
			($kind == $HcomFarm) ||		# 농장
			($kind == $HcomFoodim) ||	# 식품 연구소
			($kind == $HcomFarmcpc) ||	# 목장
			($kind == $HcomCollege) ||	# 대학설치
			($kind == $HcomFactory) ||	# 공장
			($kind == $HcomBase) ||		# 미사일 기지
			($kind == $HcomMonument) ||	# 기념비
			($kind == $HcomHaribote) ||	# 가짜 시설
			($kind == $HcomMonbuy) ||	# 괴수구매
			($kind == $HcomMonbuyt) ||	# 테트라구매
			($kind == $HcomPark) ||		# 놀이공원
			($kind == $HcomMine) ||		# 지뢰
			($kind == $HcomNursery) ||	# 양식장
			($kind == $HcomKyujo) ||	# 야구장
			($kind == $HcomUmiamu) ||	# 해상 시설
			($kind == $HcomNewtown) ||	# 뉴타운
			($kind == $HcomRizort) ||	# 리조트
			($kind == $HcomDbase)) {	# 방위 시설

		if(!
			(($landKind == $HlandPlains) ||
			($landKind == $HlandTown) ||
			(($landKind == $HlandPark) && ($kind == $HcomPark)) ||
			(($landKind == $HlandIce) && ($kind == $HcomPark)) ||
			((($landKind == $HlandUmiamu) || (($landKind == $HlandSea) && !$lv) && ($kind == $HcomUmiamu)) ||
			(($landKind == $HlandMonument) && ($kind == $HcomMonument)) ||
			(($landKind == $HlandFarm) && ($kind == $HcomFarm)) ||
			((($landKind == $HlandFarmchi) || ($landKind == $HlandFarmpic) || ($landKind == $HlandFarmcow)) && ($kind == $HcomFarmcpc)) ||
			(($landKind == $HlandCollege) && ($kind == $HcomCollege)) ||
			(($landKind == $HlandFoodim) && ($kind == $HcomFoodim)) ||
			(($landKind == $HlandFactory) && ($kind == $HcomFactory)) ||
			((($landKind == $HlandSea) && $lv) || ($landKind == $HlandNursery)) && ($kind == $HcomNursery)) ||
			(($landKind == $HlandDefence) && ($kind == $HcomDbase)))) {
			# 부적절나 지형
			logLandFail($id, $name, $comName, $landName, $point);
			return 0;
		}

		# 종류에서 분기
		if($kind == $HcomPlant) {
			# 나무심기
			$land->[$x][$y] = $HlandForest;
			$landValue->[$x][$y] = 1; # 목은 최소단위
			logPBSuc($id, $name, $comName, $point);

		} elsif(($kind == $HcomMonbuy) || ($kind == $HcomMonbuyt)) {
			# 괴수구매·테트라구매
			my $mKind = random($HmonsterLevel3) + 1;
			$mKind = 29 if($kind == $HcomMonbuyt); # 신짐승테트라
			$lv = ($mKind << 4) + $HmonsterBHP[$mKind] + random($HmonsterDHP[$mKind]);
			$land->[$x][$y] = $HlandMonster;
			$landValue->[$x][$y] = $lv;
			# 괴수 정보
			my($mName) = (monsterSpec($lv))[1];
			# 메시지
			logMonsFree($id, $name, $mName, $point);

		} elsif($kind == $HcomBase) {
			# 미사일 기지
			$land->[$x][$y] = $HlandBase;
			$landValue->[$x][$y] = 0; # 경험치0
			logPBSuc($id, $name, $comName, $point);

		} elsif($kind == $HcomHaribote) {
			# 가짜 시설
			$land->[$x][$y] = $HlandHaribote;
			$landValue->[$x][$y] = 0;
			logHariSuc($id, $name, $comName, $HcomName[$HcomDbase], $point);

		} elsif($kind == $HcomPark) {
			# 놀이공원
			if($landKind == $HlandPark) {
				# 이미놀이공원의 경우
				$landValue->[$x][$y] += 30; # 규모 + 30000인
				$landValue->[$x][$y] = 100 if($landValue->[$x][$y]> 100); # 최대 100000인
			} elsif($landKind == $HlandIce) {
				# 이미빙아래의 경우
				$landValue->[$x][$y] += 25; # 규모 + 25000인
				$landValue->[$x][$y] = 100 if($landValue->[$x][$y]> 100); # 최대 100000인
			} else {
				# 대상 위치를 놀이공원에
				$land->[$x][$y] = $HlandPark;
				$landValue->[$x][$y] = 10; # 규모 = 10000인
				$island->{'par'}++;
			}
			logLandSuc($id, $name, $comName, $point);

		} elsif($kind == $HcomMine) {
			# 지뢰설치
			$arg = 1 if($arg == 0);
			$arg = 9 if($arg> 9);
			$arg = min($arg, int($island->{'money'} / $cost));
			$cost *= $arg;
			$land->[$x][$y] = $HlandMine;
			$landValue->[$x][$y] = $arg;
			logPBSuc($id, $name, $comName, $point);

		} elsif($kind == $HcomNursery) {
			# 양식장
			if($landKind == $HlandNursery) {
				# 이미 양식장의 경우
				$landValue->[$x][$y] += 5; # 규모 + 5000인
				$landValue->[$x][$y] = 100 if($landValue->[$x][$y]> 100); # 최대 100000인
			} elsif(($landKind == $HlandSea) && $lv) {
				# 대상 위치를 양식장에
				$land->[$x][$y] = $HlandNursery;
				$landValue->[$x][$y] = 20; # 규모 = 20000인
			} else {
				# 부적절나 지형
				logLandFail($id, $name, $comName, $landName, $point);
				return 0;
			}
			logLandSuc($id, $name, $comName, $point);

		} elsif($kind == $HcomKyujo) {
			# 야구장
			$land->[$x][$y] = $HlandKyujo;
			$landValue->[$x][$y] = 0;
			logLandSuc($id, $name, $comName, $point);

		} elsif($kind == $HcomNewtown) {
			# 뉴타운
			$land->[$x][$y] = $HlandNewtown;
			$landValue->[$x][$y] = 1;
			logLandSuc($id, $name, $comName, $point);

		} elsif($kind == $HcomRizort) {
			# 대상 위치를 리조트로
			$land->[$x][$y] = $HlandRizort;
			$landValue->[$x][$y] = 1;
			logLandSuc($id, $name, $comName, $point);

		} elsif($kind == $HcomUmiamu) {
			# 해상 시설
			if($landKind == $HlandUmiamu) {
				# 이미 해상 시설의 경우
				$landValue->[$x][$y] += 30; # 규모 + 30000인
				$landValue->[$x][$y] = 1000 if($landValue->[$x][$y]> 1000); # 최대 1000000인
			} elsif(($landKind == $HlandSea) && !$lv) {
				# 바다라면, 대상 위치를 해상 시설에
				$land->[$x][$y] = $HlandUmiamu;
				$landValue->[$x][$y] = 50; # 규모 = 50000인
			} else {
				# 부적절나 지형
				logLandFail($id, $name, $comName, $landName, $point);
				return 0;
			}
			logLandSuc($id, $name, $comName, $point);

		} elsif($kind == $HcomFarm) {
			# 농장
			if($landKind == $HlandFarm) {
				# 이미 농장의 경우
				$landValue->[$x][$y] += 2; # 규모 + 2000인
				$landValue->[$x][$y] = 50 if($landValue->[$x][$y]> 50); # 최대 50000인
			} else {
				# 대상 위치를 농장에
				$land->[$x][$y] = $HlandFarm;
				$landValue->[$x][$y] = 10; # 규모 = 10000인
			}
			logLandSuc($id, $name, $comName, $point);

		} elsif($kind == $HcomFoodim) {
			# 식품 연구소
			if($landKind == $HlandFoodim) {
				# 이미식품 연구소의 경우
				$landValue->[$x][$y] += 10; # 규모 + 10000인
				$landValue->[$x][$y] = 500 if($landValue->[$x][$y]> 500); # 최대 500000인
			} else {
				# 대상 위치를 식품 연구소에
				$land->[$x][$y] = $HlandFoodim;
				$landValue->[$x][$y] = 30; # 규모 = 30000인
			}
			logLandSuc($id, $name, $comName, $point);

		} elsif($kind == $HcomCollege) {
			# 대학설치
			if(($landKind == $HlandCollege) && (($lv == 4) || ($lv == 96))) {
				$landValue->[$x][$y] = 100 - $lv;
				logLandSuc($id, $name, $comName, $point);
				return 0;
			} elsif(($landKind == $HlandCollege) && (($lv == 97) || ($lv == 98))) {
				$landValue->[$x][$y] = 195 - $lv;
				logLandSuc($id, $name, $comName, $point);
				return 0;
			} else {
				$land->[$x][$y] = $HlandCollege;
				if(random(100) < 30) {
					$landValue->[$x][$y] = 0;
				} elsif(random(100) < 30) {
					$landValue->[$x][$y] = 1;
				} elsif(random(100) < 15) {
					$landValue->[$x][$y] = 2;
				} elsif(random(100) < 15) {
					$landValue->[$x][$y] = 3;
				} elsif(random(100) < 15) {
					$landValue->[$x][$y] = 4;
					if(($island->{'co4'} == 0) && ($island->{'co99'} == 0) && ($island->{'c28'} == 0)) {
						$island->{'eisei5'} = "3,5,5,5,0,0,0";
					}
				} else {
					$landValue->[$x][$y] = 5;
				}
			}
			logLandSuc($id, $name, $comName, $point);

		} elsif($kind == $HcomFarmcpc) {
			# 목장
			$arg = 1 if(($arg>= 4) || ($arg == 0));
			my @ltmp = ($HlandFarmchi, $HlandFarmpic, $HlandFarmcow);
			my @mtmp = (10, 20, 50);
			my($l, $flag);
			$flag = 0;
			foreach $l (@ltmp) {
				if($landKind == $l) {
					$island->{'money'} += $lv * $mtmp[$flag];
					last;
				}
				$flag++;
			}
			if($flag == 3){
				# 비용 확인
				my $value = $arg * $cost;
				if($island->{'money'} < $value) {
					logNoAny($id, $name, $comName, "자금 부족의");
					return 0;
				}
				$land->[$x][$y] = $ltmp[$arg - 1];
				$island->{'money'} -= $value;
			}
			$landValue->[$x][$y] = 1;
			logLandSuc($id, $name, $comName, $point);
			if($flag == 3){
				return 1;
			} else {
				return 0;
			}

		} elsif($kind == $HcomFactory) {
			# 공장
			if($landKind == $HlandFactory) {
				# 이미 공장의 경우
				$landValue->[$x][$y] += 10; # 규모 + 10000인
				$landValue->[$x][$y] = 100 if($landValue->[$x][$y]> 100); # 최대 100000인
			} else {
				# 대상 위치를 공장에
				$land->[$x][$y] = $HlandFactory;
				$landValue->[$x][$y] = 30; # 규모 = 30000인
			}
			logLandSuc($id, $name, $comName, $point);

		} elsif($kind == $HcomDbase) {
			# 방위 시설
			if($landKind == $HlandDefence) {
				# 이미 방위 시설인 경우
				$landValue->[$x][$y] = 1; # 자폭장치 설정
				logBombSet($id, $name, $landName, $point);
			} else {
				# 대상 위치를 방위 시설에
				$land->[$x][$y] = $HlandDefence;
				$landValue->[$x][$y] = 0;
				logLandSuc($id, $name, $comName, $point);
			}

		} elsif($kind == $HcomMonument) {
			# 기념비
			if($landKind == $HlandMonument) {
				return 0 if(!$HuseBigMissile);
				# 이미 기념비인 경우
				# 대상 가져오기
				my($tn) = $HidToNumber{$target};
				# 대상이 이미 없는 경우 아무 메시지도 출력하지 않음
				return 0 unless(defined $tn);

				my($aId, %amityFlag);
				foreach $aId (@{$island->{'allyId'}}) {
					foreach (@{$Hally[$HidToAllyNumber{$aId}]->{'memberId'}}) {
						next if($_ == $id);
						$amityFlag{$_} = 1;
					}
				}
				# 개발 기간이면 명령 무시
				if ($HarmisticeTurn && ($HislandTurn <= $HarmisticeTurn || $amityFlag{$target})) {
					# 공격이 허가되어 있지 않음
					logNotAvail($id, $name, $comName);
					return 0;
				}

				my($tIsland) = $Hislands[$tn];
				# 자기 섬의 인구가 적거나, 대상 섬의 인구가 적거나 BattleField 이면, 실행은 허가되지 않는
				if(($tIsland->{'id'} != $island->{'id'}) && (($island->{'pop'} < $HguardPop) || ($tIsland->{'pop'} < $HguardPop) || ($tIsland->{'id'}>100))) {
					logNoAny($id, $name, $comName, "실행이허가되지 않는");
					return 0;
				}
				$tIsland->{'bigmissile'}++;
				# 그장소는 황무지에
				$land->[$x][$y] = $HlandWaste;
				$landValue->[$x][$y] = 0;
				logMonFly($id, $name, $landName, $point);
			} else {
				# 대상 위치를 기념비에
				$land->[$x][$y] = $HlandMonument;
				$arg = 0 if($arg>= $HmonumentNumber);
				$landValue->[$x][$y] = $arg;
				logLandSuc($id, $name, $comName, $point);
			}
		}
		# 이상, 지상 건설계에서 return하지 않은 명령을 정리
		# 돈을 차감
		$island->{'money'} -= $cost;
		# 횟수 지정이면, 명령을 되돌림
		if(($kind == $HcomFarm)	||
			($kind == $HcomFoodim) ||
			($kind == $HcomNursery) ||
			($kind == $HcomPark)	||
			($kind == $HcomUmiamu) ||
			($kind == $HcomFactory)) {
			if($arg> 1) {
				$arg--;
				slideBack($comArray, 0);
				$comArray->[0] = {
					'kind' => $kind,
					'target' => $target,
					'x' => $x,
					'y' => $y,
					'arg' => $arg
				};
			}
		}
		return 1;

	} elsif($kind == $HcomMountain) {
		# 채굴장
		if($landKind == $HlandMountain) {
			# 이미채굴장의 경우
			$landValue->[$x][$y] += 5; # 규모 + 5000인
			$landValue->[$x][$y] = 200 if($landValue->[$x][$y]> 200); # 최대 200000인
		} elsif($landKind == $HlandGold) {
			# 이미금광산의 경우
			$landValue->[$x][$y] += 20; # 규모 + 20000인
			$landValue->[$x][$y] = 200 if($landValue->[$x][$y]> 200); # 최대 200000인
		} elsif($landKind == $HlandShrine) {
			# 시간의 신전의 경우
			$land->[$x][$y] = $HlandMountain;
			$landValue->[$x][$y] += 5; # 규모 + 5000인
		} else {
			# 부적절나 지형
			logLandFail($id, $name, $comName, $landName, $point);
			return 0;
		}
		logLandSuc($id, $name, $comName, $point);

		if(random(1000) < 9) { # 0.9%로 금광산에
			my($v) = 1000 + random(4001); # 1000~5000억 수입
			$island->{'money'} += $v;
			$land->[$x][$y] = $HlandGold;
			logGold($id, $name, $comName, $v);

			if($island->{'sin'}> 0) {
				my $value = random(1001);
				$island->{'money'} += $value;
				# 수입 로그
				logSinMoney($id, $name, "$value$HunitMoney");
			}
			if($island->{'jin'}> 0) {
				my $value = random(1001);
				$island->{'money'} += $value;
				# 수입 로그
				logJinMoney($id, $name, "$value$HunitMoney");
			}
		}
		# 돈을 차감
		$island->{'money'} -= $cost;
		# 횟수 지정라면 명령을 되돌림
		if($arg> 1) {
			$arg--;
			slideBack($comArray, 0);
			$comArray->[0] = {
				'kind' => $kind,
				'target' => $target,
				'x' => $x,
				'y' => $y,
				'arg' => $arg
			};
		}
		return 1;

	} elsif($kind == $HcomHTget) {
		# 첨단 기술
		if($landKind == $HlandHTFactory) {
			# 이미채굴장의 경우
			$landValue->[$x][$y] += 10; # 규모 + 10000인
			$landValue->[$x][$y] = 500 if($landValue->[$x][$y]> 500); # 최대 500000인
		} elsif($landKind == $HlandFactory) {
			if($lv == 100) {
				$land->[$x][$y] = $HlandHTFactory;
			} else {
				logLandFail2($id, $name, $comName, $point, "조건을 충족하지 않는 <B>$landName</B> 때문에");
				return 0;
			}
		} else {
			# 부적절나 지형
			logLandFail($id, $name, $comName, $landName, $point);
			return 0;
		}
		logLandSuc($id, $name, $comName, $point);

		# 돈을 차감
		$island->{'money'} -= $cost;
		if($arg> 1) {
			$arg--;
			slideBack($comArray, 0);
			$comArray->[0] = {
				'kind' => $kind,
				'target' => $target,
				'x' => $x,
				'y' => $y,
				'arg' => $arg
			};
		}
		return 1;

	} elsif($kind == $HcomHouse) {
		# 섬주의 가
		if($island->{'hou'}> 0) {
			# 세율 변경
			$island->{'eisei1'} = $arg;
			logLandSuc($id, $name, $comName, $point);
			return 0;
		} else {
			if(($landKind != $HlandPlains) && ($landKind != $HlandTown)) {
				# 부적절나 지형
				logLandFail($id, $name, $comName, $landName, $point);
				return 0;
			} else {
				$arg = 5 if(!$arg);
				$island->{'eisei1'} = $arg;
				$land->[$x][$y] = $HlandHouse;
				my $hlv;
				foreach (0..9) {
					$hlv = 9 - $_;
					last if($island->{'pts'}> $HouseLevel[$hlv]);
				}
				$landValue->[$x][$y] = $hlv;
				logLandSuc($id, $name, $comName, $point);
				# 돈을 차감
				$island->{'money'} -= $cost;
				return 1;
			}
		}

	} elsif($kind == $HcomBettown) {
		my($shutoCount) = countAround($land, $x, $y, 7, $HlandShuto, $HlandUmishuto);
		my($betCount) = countAround($land, $x, $y, 7, $HlandBettown);

		if($landKind != $HlandBigtown){
			# 부적절나 지형
			logLandFail($id, $name, $comName, $landName, $point);
			return 0;
		}

		if(($island->{'shu'}> 0) && (($shutoCount> 0) || ($betCount> 1))) {
			$land->[$x][$y] = $HlandBettown;
			logLandSuc($id, $name, $comName, $point);
			# 돈을 차감
			$island->{'money'} -= $cost;
			return 1;
		} else {
			logLandFail2($id, $name, $comName, $point, "조건을 충족하지 않는 <B>$landName</B> 때문에");
			return 0;
		}

	} elsif($kind == $HcomKai) {
		if($landKind == $HlandKyujo) {
			$island->{'eisei4'} = "1,1,1,0,0,0,0,0,0,0,10";
			$land->[$x][$y] = $HlandKyujokai;
			$landValue->[$x][$y] = 0;
			logLandSuc($id, $name, $comName, $point);
			# 돈을 차감
			$island->{'money'} -= $cost;
			return 1;
		} elsif($landKind == $HlandKyujokai) {
			my($sto, $std, $stk, $stwin, $stdrow, $stlose, $stwint, $stdrowt, $stloset, $styusho, $stshoka) = split(/,/, $island->{'eisei4'});
			$sto++;
			$std++;
			$stk++;
			$island->{'eisei4'} = "$sto,$std,$stk,$stwin,$stdrow,$stlose,$stwint,$stdrowt,$stloset,$styusho,$stshoka";
			logLandSuc($id, $name, $comName, $point);
			# 돈을 차감
			$island->{'money'} -= $cost;
			if($arg> 1) {
				$arg--;
				slideBack($comArray, 0);
				$comArray->[0] = {
					'kind' => $kind,
					'target' => $target,
					'x' => $x,
					'y' => $y,
					'arg' => $arg
				};
			}
			return 1;
		} elsif(($landKind == $HlandFune) && ($lv == 10)) {
			$landValue->[$x][$y] = 19;
			logLandSuc($id, $name, $comName, $point);
			# 돈을 차감
			$island->{'money'} -= $cost;
			return 1;
		} elsif($landKind == $HlandRizort) {
			my($seaCount) = countAround($land, $x, $y, 7, @Hseas);
			my($rizortCount) = countAround($land, $x, $y, 7, $HlandRizort, $HlandBigRizort);
			my($value);
			$value = $lv+$island->{'eis1'}+$island->{'eis2'}+$island->{'eis3'}+$island->{'eis5'}+int($island->{'fore'}/10)+int($island->{'rena'}/10)-$island->{'monsterlive'}*100;
			if(($seaCount> 2) &&
				($value> 500) &&
				($rizortCount> 2)) {
				$land->[$x][$y] = $HlandBigRizort;
				logLandSuc($id, $name, $comName, $point);
				# 돈을 차감
				$island->{'money'} -= $cost;
				return 1;
			} else {
				logLandFail2($id, $name, $comName, $point, "조건을 충족하지 않는 <B>$landName</B> 때문에");
				return 0;
			}
		} else {
			# 부적절나 지형
			logLandFail($id, $name, $comName, $landName, $point);
			return 0;
		}
	} elsif($kind == $HcomSbase) {
		# 해저 기지
		unless(($landKind == $HlandSea) && !$lv){
			# 바다이외에는 만들 수 없음
			logLandFail($id, $name, $comName, $landName, $point);
			return 0;
		}
		$land->[$x][$y] = $HlandSbase;
		$landValue->[$x][$y] = 0;# 경험치0
		logLandSuc($id, $name, $comName, '(?, ?)');
		# 돈을 차감
		$island->{'money'} -= $cost;
		return 1;

	} elsif($kind == $HcomSeacity) {
		# 해저 도시
		if(($landKind != $HlandSea) || $lv){
			# 바다이외에는 만들 수 없음
			logLandFail($id, $name, $comName, $landName, $point);
			return 0;
		}
		$land->[$x][$y] = $HlandSeacity;
		$landValue->[$x][$y] = 0; # 인구0
		logLandSuc($id, $name, $comName, '(?, ?)');
		# 돈을 차감
		$island->{'money'} -= $cost;
		return 1;

	} elsif($kind == $HcomProcity) {
		# 방재화
		if(($landKind != $HlandTown) || ($lv != 100)){
			# 1만 명 도시이외에는 만들 수 없음
			logLandFail($id, $name, $comName, $landName, $point);
			return 0;
		}
		$land->[$x][$y] = $HlandProcity;
		$landValue->[$x][$y] = 100; # 인구10000
		logLandSuc($id, $name, $comName, $point);
		# 돈을 차감
		$island->{'money'} -= $cost;
		return 1;

	} elsif($kind == $HcomBigtown) {
		# 현대화
		if(($landKind != $HlandNewtown) || ($lv < 150) ||
			(countAround($land, $x, $y, 19, @Htowns) < 16)){
			# 15000인 이상의 뉴타운이 아니면 만들 수 없음
			# 주변의 도시의 개수가 적으면 건설 불가
			logLandFail2($id, $name, $comName, $point, "조건을 충족하지 않는 <B>$landName</B> 때문에");
			return 0;
		}
		$land->[$x][$y] = $HlandBigtown;
		logLandSuc($id, $name, $comName, $point);
		# 돈을 차감
		$island->{'money'} -= $cost;
		return 1;

	} elsif($kind == $HcomSeatown) {
		# 해저 신도시
		if(($landKind != $HlandSeacity) || ($lv < 200) ||
			(countAround($land, $x, $y, 19, @Htowns) < 16)){
			# 20000인 이상의 해저 도시가 아니면 만들 수 없음
			# 주변의 도시의 개수가 적으면 건설 불가
			logLandFail2($id, $name, $comName, '(?, ?)', "조건을 충족하지 않는 <B>$landName</B> 때문에");
			return 0;
		}
		$land->[$x][$y] = $HlandSeatown;
		logLandSuc($id, $name, $comName, '(?, ?)');
		# 돈을 차감
		$island->{'money'} -= $cost;
		return 1;

	} elsif($kind == $HcomBoku) {
		# 나의 이사시
		my($towncount) = countAround($land, $x, $y, 19, $HlandTown);
		if(($landKind != $HlandProcity) || !$towncount) {
			# 방재 도시 이외에서는 실행 불가
			# 주변에 도시가 없으면 실행 불가
			logLandFail2($id, $name, $comName, $point, "조건을 충족한 도시가 아니었습니다");
			return 0;
		}
		$landValue->[$x][$y] += 10; # 규모 + 1000명
		$landValue->[$x][$y] = 200 if($landValue->[$x][$y]> 200); # 최대 20000인
		my($i,$sx,$sy);
		for($i = 1; $i < 19; $i++) {
			$sx = $x + $ax[$i];
			$sy = $y + $ay[$i];
			if($land->[$sx][$sy] == $HlandTown){
				$landValue->[$sx][$sy] -= int(20 / $towncount);
				if($landValue->[$sx][$sy] <= 0) {
					# 평지로 되돌리기
					$land->[$sx][$sy] = $HlandPlains;
					$landValue->[$sx][$sy] = 0;
					next;
				}
			}
		}
		logLandSuc($id, $name, $comName, $point);
		# 돈을 차감
		$island->{'money'} -= $cost;
		# 횟수 지정라면 명령을 되돌림
		if($arg> 1) {
			$arg--;
			slideBack($comArray, 0);
			$comArray->[0] = {
				'kind' => $kind,
				'target' => $target,
				'x' => $x,
				'y' => $y,
				'arg' => $arg
				};
		}
		return 1;


	} elsif($kind == $HcomGivefood) {
		# 에사
		if($landKind == $HlandMonster) {
			my($mKind, $mName, $mHp) = monsterSpec($landValue->[$x][$y]);
			$lv += random(5) if($mHp < 10);
			$landValue->[$x][$y] = $lv;
		} elsif((($landKind == $HlandCollege) && ($lv == 4)) ||
			(($landKind == $HlandCollege) && ($lv == 96)) ||
			(($landKind == $HlandCollege) && ($lv == 97)) ||
			(($landKind == $HlandCollege) && ($lv == 98))) {
			my($mshp, $msap, $msdp, $mssp, $mswin, $msexe, $tet) = split(/,/, $island->{'eisei5'});
			if(random(100) < 30) {
				$msap++;
			} elsif (random(100) < 30) {
				$msdp++;
			} elsif (random(100) < 30) {
				$mssp++;
			} else {
				$mshp++;
				$mshp = 15 if($mshp> 15);
			}
			$island->{'eisei5'} = "$mshp,$msap,$msdp,$mssp,$mswin,$msexe,$tet";
		} else {
			# 부적절나 지형
			logLandFail($id, $name, $comName, $landName, $point);
			return 0;
		}
		logLandSuc($id, $name, $comName, $point);

		# 돈을 차감
		$island->{'food'} += $cost;
		if($arg> 1) {
			$arg--;
			slideBack($comArray, 0);
			$comArray->[0] = {
				'kind' => $kind,
				'target' => $target,
				'x' => $x,
				'y' => $y,
				'arg' => $arg
			};
		}
		return 1;

	} elsif($kind == $HcomEisei) {
		# 인공위성 발사
		$arg = 1 if(($arg> 6) || !$arg);
		my $value = $arg * $cost;
		# 기상, 관측, 요격, 군사, 방위, 이레
		my @rocket = (1, 1, 2, 3, 4, 10);
		my @tech = (10, 40, 100, 250, 1000, 2000);
		my @failp = (700, 500, 600, 400, 200, 3000);
		my @failq = (100, 100, 10, 10, 10, 1);

		if($island->{'m17'} < $rocket[$arg - 1]) { # 로켓이 $rocket 이상이어야 함
			logNoAny($id, $name, $comName, "로켓이 부족함");
			return 0;
		} elsif($island->{'rena'} < $tech[$arg - 1]) { # 군사 기술 Lv$tech 이상이어야 함
			logNoAny($id, $name, $comName, "군사 기술 부족");
			return 0;
		} elsif($island->{'money'} < $value) {
			logNoAny($id, $name, $comName, "자금 부족의");
			return 0;
		} elsif(random(10000)> $failp[$arg - 1] + $failq[$arg - 1] * $island->{'rena'}) {
			logEiseifail($id, $name, $comName, $point);
			# 돈을 차감
			$island->{'money'} -= $value;
			return 1;
		}
		my $nkind = 'eis'. $arg;
		$island->{$nkind} = ($arg == 6) ? 250 : 100;
		logPropaganda($id, $name, $comName);
		# 돈을 차감
		$island->{'money'} -= $value;
		return 1;

		# 인공위성복구
	} elsif($kind == $HcomEiseimente) {
		$arg = 1 if(($arg> 5) || !$arg);
		my $nkind = 'eis'. $arg;
		if($island->{$nkind}) {
			$island->{$nkind} = 150;
			logPropaganda($id, $name, $comName);
		} else {
			logNoAny($id, $name, $comName, "지정의 인공위성이 없음");
			return 0;
		}
		# 돈을 차감
		$island->{'money'} -= $cost;
		return 1;

		# 위성파괴포
	} elsif($kind == $HcomEiseiAtt) {
		my($aId, %amityFlag);
		foreach $aId (@{$island->{'allyId'}}) {
			foreach (@{$Hally[$HidToAllyNumber{$aId}]->{'memberId'}}) {
				next if($_ == $id);
				$amityFlag{$_} = 1;
			}
		}
		# 개발 기간이면 명령 무시
		if ($HarmisticeTurn && ($HislandTurn <= $HarmisticeTurn || $amityFlag{$target})) {
			# 공격이 허가되어 있지 않음
			logNotAvail($id, $name, $comName);
			return 0;
		}
		# 대상 가져오기
		my($tn) = $HidToNumber{$target};
		if($tn eq '') {
			# 대상이 이미 없음
			logNoAny($id, $name, $comName, "목표 ${AfterName}에 대상이 없음");
			return 0;
		}
		# 사전준비
		my($tIsland) = $Hislands[$tn];
		my($tName) = islandName($tIsland);

		my($tkind, $eName, $p, $nkind);
		$arg = 1 if(($arg> 6) || !$arg);
		$tkind = 'eis'. $arg;
		my($eis6, $eis4) = ($island->{'eis6'}, $island->{'eis4'});

		if($eis6 || $eis4) { # 비정상 군사위성이 있는 경우
			$eName = $HeiseiName[$arg];
			$p = ($eis6>= 1) ? 110 : 70;
			if($tIsland->{$tkind}) {
				if(random(100) < $p - 10 * $arg) {
					$tIsland->{$tkind} = 0;
					logEiseiAtts($id, $target, $name, $tName, $comName, $eName);
				} else {
					logEiseiAttf($id, $target, $name, $tName, $comName, $eName);
				}
			} else {
				logNoAny($id, $name, $comName, "지정의 인공위성이 없음");
				return 0;
			}

			$nkind = ($eis6>= 1) ? 'eis6' : 'eis4';
			$island->{$nkind} -= 30;
			if($island->{$nkind} < 1) {
				$island->{$nkind} = 0;
				logEiseiEnd($id, $name, ($eis6>= 1) ? $HeiseiName[6] : $HeiseiName[4]);
			}
			# 돈을 차감
			$island->{'money'} -= $cost;
			return 1;

		} else { # 비정상도군사위성도 없는 경우
			logNoAny($id, $name, $comName, "필요한인공위성이 없음");
			return 0;
		}

		# 위성레자
	} elsif($kind == $HcomEiseiLzr) {
		my($aId, %amityFlag);
		foreach $aId (@{$island->{'allyId'}}) {
			foreach (@{$Hally[$HidToAllyNumber{$aId}]->{'memberId'}}) {
				next if($_ == $id);
				$amityFlag{$_} = 1;
			}
		}
		# 개발 기간이면 명령 무시
		if ($HarmisticeTurn && ($HislandTurn <= $HarmisticeTurn || $amityFlag{$target})) {
			# 공격이 허가되어 있지 않음
			logNotAvail($id, $name, $comName);
			return 0;
		}
		my($tn) = $HidToNumber{$target};
		unless(defined $tn) {
			# 대상이 이미 없음
			logNoAny($id, $name, $comName, "목표 ${AfterName}에 대상이 없음");
			return 0;
		}
		# 사전준비
		my($tIsland) = $Hislands[$tn];
		my($tName) = islandName($tIsland);
		my($tLand) = $tIsland->{'land'};
		my($tLandValue) = $tIsland->{'landValue'};
		# 자기 섬의 인구가 적거나, 대상 섬의 인구가 적거나 BattleField 이면, 실행은 허가되지 않는
		if(($tIsland->{'id'} != $island->{'id'}) && (($island->{'pop'} < $HguardPop) || ($tIsland->{'pop'} < $HguardPop) || ($tIsland->{'id'}>100))) {
			logNoAny($id, $name, $comName, "실행이허가되지 않는");
			return 0;
		}
		# 착탄 지점오차없음
		# 착탄 지점의 지형등 산출
		my($tL) = $tLand->[$x][$y];
		my($tLv) = $tLandValue->[$x][$y];
		my($tLname) = landName($tL, $tLv);
		my($tPoint) = "($x, $y)";

		my($eis6, $eis4) = ($island->{'eis6'}, $island->{'eis4'});

		if($eis6 || $eis4) { # 비정상 군사위성이 있는 경우
			if(($tL == $HlandSea)	 ||
				($tL == $HlandHugeMonster) ||
				($tL == $HlandWaste)	||
				($tL == $HlandMountain) ||
				($tL == $HlandGold)	 ||
				($tL == $HlandShrine)	||
				($tL == $HlandSeacity) ||
				($tL == $HlandSeatown) ||
				($tL == $HlandUmishuto) ||
				($tL == $HlandUmiamu)	||
				($tL == $HlandSbase)) {
				# 효과가 없는 지형
				logLzr($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint, "정화되었습니다.");
			} elsif(($tL == $HlandOil)	 ||
					($tL == $HlandNursery) ||
					($tL == $HlandFrocity) ||
					($tL == $HlandIce) ||
					($tL == $HlandFune)) {
				logLzr($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint, "불타 없어졌습니다.");
				$tLand->[$x][$y] = $HlandSea;
				$tLandValue->[$x][$y] = 1;
			} elsif($tL == $HlandOnsen) {
				logLzr($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint, "불타 없어졌습니다.");
				$tLand->[$x][$y] = $HlandMountain;
				$tLandValue->[$x][$y] = 0;
			} else {
				logLzr($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint, "불타 없어졌습니다.");
				$tLand->[$x][$y] = $HlandWaste;
				$tLandValue->[$x][$y] = 0;
				if (random(1000) < 100) {
					$tLand->[$x][$y] = $HlandMonument;
					$tLandValue->[$x][$y] = 79;
				}
			}
			my $nkind = ($eis6> 0) ? 'eis6' : 'eis4';
			$island->{$nkind} -= (($eis6> 0) ? 5 : 10);
			if($island->{$nkind} < 1) {
				$island->{$nkind} = 0;
				logEiseiEnd($id, $name, ($eis6> 0) ? $HeiseiName[6] : $HeiseiName[4]);
			}
			$island->{'money'} -= $cost;
			return 1;
		} else {
			logNoAny($id, $name, $comName, "필요한인공위성이 없음");
			return 0;
		}

	} elsif($kind == $HcomArmSupply) {
		return 0 if(!$HuseArmSupply);
		# 군사 물자 조달
		$arg = 1 if(!$arg);
		my($value, $p);
		$value = min($arg * ($cost), $island->{'money'});
		$p = int($value / $cost);
		$value = $p * $cost;

		# 돈을 차감
		$island->{'money'} -= $value;
		$island->{'army'} += $p;

		logArmSupply($id, $name, $HcomName[$kind], $p);

		if($HnoturnArmSupply) {
			return 0;
		} else {
			return 1;
		}

		# 미사일계
	} elsif(($kind == $HcomMissileNM) || # 일반 미사일
			($kind == $HcomMissilePP) || # PP 미사일
			($kind == $HcomMissileSPP) || # SPP 미사일
			($kind == $HcomMissileST) || # ST 미사일
			($kind == $HcomMissileSS) || # 핵 미사일
			($kind == $HcomMissileLR) || # 지형융기탄
			($kind == $HcomMissileLD)) { # 육지 파괴탄
		my($aId, %amityFlag);
		foreach $aId (@{$island->{'allyId'}}) {
			foreach (@{$Hally[$HidToAllyNumber{$aId}]->{'memberId'}}) {
				next if($_ == $id);
				$amityFlag{$_} = 1;
			}
		}
		# 개발 기간이면 명령 무시
		if ($HarmisticeTurn && ($HislandTurn <= $HarmisticeTurn || $amityFlag{$target})) {
			# 공격이 허가되어 있지 않음
			logNotAvail($id, $name, $comName);
			return 0;
		}
		# 대상 가져오기
		my($tn) = $HidToNumber{$target};
		unless(defined $tn) {
			# 대상이 이미 없음
			logNoAny($id, $name, $comName, "목표 ${AfterName}에 대상이 없음");
			return 0;
		}

		my($flag) = 0;
		if($HuseArmSupply && !$island->{'army'}) {
			logNoAny($id, $name, $comName, "군사 물자가 없음");
			return 0;
		}
		if(!$arg || ($HuseArmSupply && ($arg> $island->{'army'}))) {
			# 0, 또는, 군사 물자보다 많음이 경우
			$arg = ($HuseArmSupply) ? $island->{'army'} : 100;
			# RA은 Max 에서100발처럼입니다
		}

		# 사전준비
		my($tIsland) = $Hislands[$tn];
		my($tName) = islandName($tIsland);
		my($tLand) = $tIsland->{'land'};
		my($tLandValue) = $tIsland->{'landValue'};
		my($tx, $ty, $err);

		# BattleField가 아니면, 자기 섬의 인구가 적거나, 대상 섬의 인구가 적으면, 실행은 허가되지 않는
		if(($tIsland->{'id'} <= 100) && ($tIsland->{'id'} != $island->{'id'}) && (($island->{'pop'} < $HguardPop) || ($tIsland->{'pop'} < $HguardPop))) {
			logNoAny($id, $name, $comName, "실행이허가되지 않는");
			return 0;
		}

		# 난민의 수
		my($boat) = 0;

		# 오차
		if($kind == $HcomMissilePP) { # PP 미사일
			$err = 7;
		} elsif($kind == $HcomMissileSS) { # 핵 미사일
			$err = 7;
		} elsif($kind == $HcomMissileSPP) { # SPP 미사일
			$err = 1;
		} else {
			$err = 19;
		}

		# 대상 섬의 인구가 BattleField 이면,@HkindBFM 이외는 허가되지 않는
		my $flagBFM = 1;
		foreach (@HkindBFM) {
			if($kind == $_) {
				$flagBFM = 0;
				last;
			}
		}
		if($tIsland->{'id'}> 100) {
			if($flagBFM) {
				logNoAny($id, $name, $comName, "허가되지 않은 종류의 미사일입니다");
				return 0;
			}
		} elsif(($tIsland->{'id'} != $island->{'id'}) && $HtargetMonster &&
			!countAround($tLand, $x, $y, $err, $HlandMonster, $HlandHugeMonster, $HlandRottenSea)) {
			# 사거리 안에 괴수·거대괴수·오염된 바다가 없으면, 발사 중지
			logNoTarget($id, $name, $comName);
			return 0;
		}

		my($mukou, $bouei, $kaijumukou, $kaijuhit, $total,$fuhatu,$alltotal) = (0, 0, 0, 0, 0, 0, 0);

		# 자금이 부족하면 지정수량을 충족하거나 전체 기지 가격에 도달할 때까지 반복
		my($bx, $by, $count) = (0,0,0);
		while(($arg> 0) && ($island->{'money'}>= $cost)) {
			# 기지를 찾을 때까지 반복
			while($count < $HpointNumber) {
				$bx = $Hrpx[$count];
				$by = $Hrpy[$count];
				last if(($land->[$bx][$by] == $HlandBase) || ($land->[$bx][$by] == $HlandSbase));
				$count++;
			}
			last if($count> $pointNumber); # 찾을 수 없으면 그곳까지
			$flag = 1; # 최소하나기지가 있었던이므로,flag 을설립하고 있는

			# 기지의 레벨을 산출
			my($missiles) = $island->{'missiles'}->[$bx][$by];
			my($level) = expToLevel($land->[$bx][$by], $landValue->[$bx][$by]) - $missiles;
			if($level <= 0) { $count++; next; }; # 이기지는 전체탄환 발사하고 있는

			# 기지내에서 루프
			while(($level> 0) && ($arg> 0) && ($island->{'money'}> $cost)) {
				if(random(300) < $alltotal-int($island->{'rena'}/100)) {
					$level--;
					$arg--;
					$island->{'money'} -= $cost;
					$total++;
					$alltotal++;
					$fuhatu++;
					# 군사 물자를 감하게 함
					$island->{'army'}-- if($HuseArmSupply);
					last if(!$level || !$arg || ($island->{'money'} < $cost));
				}
				if($kind != $HcomMissileST) {
					$island->{'ext'}[1] += $cost; # 공헌도
					$island->{'ext'}[6]++; # 발사한 미사일의 수
					if($HallyNumber) {
						foreach (@{$island->{'allyId'}}) {
							$Hally[$HidToAllyNumber{$_}]->{'ext'}[0]++;
						}
					}
				}
				if($HallyNumber) {
					my $allyflag = 0;
					my $ai;
					foreach $ai (@{$island->{'allyId'}}) {
						foreach (@{$tIsland->{'allyId'}}) {
							if($_ == $ai) {
								$allyflag = 1;
								last;
							}
						}
					}
					if($allyflag) {
						# 아군을 공격한 경우 공헌도 감소(피해를 받을 미사일의 수는 카운트하지 않음)
						$tIsland->{'ext'}[1] -= $cost; # 공헌도
					} else {
						# 적을 공격한 경우 공헌도 증가
						$tIsland->{'ext'}[1] += $cost; # 공헌도
						$tIsland->{'ext'}[5]++; # 피해를 받을 미사일의 수
					}
					foreach (@{$tIsland->{'allyId'}}) {
						$Hally[$HidToAllyNumber{$_}]->{'ext'}[1]++;
					}
				}
				# 명중이 확정이므로, 각 값을 소도
				$level--;
				$missiles++;
				$arg--;
				$island->{'money'} -= $cost;
				$total++;
				$alltotal++;
				# 군사 물자를 감하게 함
				$island->{'army'}-- if($HuseArmSupply);

				# 착탄 지점 산출
				my($r) = random($err);
				$tx = $x + $ax[$r];
				$ty = $y + $ay[$r];
				$tx-- if((($ty % 2) == 0) && (($y % 2) == 1));

				# 착탄 지점범위안팎 확인
				if(($tx < 0) || ($tx> $islandSize) || ($ty < 0) || ($ty> $islandSize)) {
					# 범위 밖
					$mukou++;
					next;
				}

				# 착탄 지점의 지형등 산출
				my($tL) = $tLand->[$tx][$ty];
				my($tLv) = $tLandValue->[$tx][$ty];
				my($tLname) = landName($tL, $tLv);
				my($tPoint) = "($tx, $ty)";

				# 방위 시설 판정
				my($defence) = 0;
				if($kind == $HcomMissileSPP) {
					if(!($HdBaseSelfNoDefence) || ($id != $tIsland->{'id'})) {
						$defence = 1;
						$defence = 0 if($HdBaseNoPerfect && (random(100) < $HdNoPerfectP));
					}
				}
				if($HdefenceHex[$id][$tx][$ty] == 1) {
					$defence = 1;
				} elsif($HdefenceHex[$id][$tx][$ty] == -1) {
					$defence = 0;
				} else {
					if(!($HdBaseSelfDefence) && (($tL == $HlandDefence) ||
												 (($tL == $HlandProcity) && ($tLv < 160)))) {
						# 방위 시설에 명중
						# 플래그를 지우기
						my($i, $count, $sx, $sy);
						for($i = 0; $i < 19; $i++) {
							$sx = $tx + $ax[$i];
							$sy = $ty + $ay[$i];

							# 행 기준 위치 조정
							$sx-- if(!($sy % 2) && ($ty % 2));
							# 범위 안의 경우
							$HdefenceHex[$id][$sx][$sy] = 0 if(($sx>= 0) && ($sx < $HislandSize) && ($sy>= 0) && ($sy < $HislandSize));
						}
						if(($tL == $HlandDefence) && ($kind != $HcomMissileST)) {
							$island->{'ext'}[2]++; # 파괴한 방위 시설의 수
						}
					} elsif(countAround($tLand, $tx, $ty, 19, $HlandDefence)) {
						if(!($HdBaseSelfNoDefence) || ($id != $tIsland->{'id'})) {
							$HdefenceHex[$id][$tx][$ty] = 1;
							$defence = 1;
							$defence = 0 if($HdBaseNoPerfect && (random(100) < $HdNoPerfectP));
						}
					} elsif(countAround($tLand, $tx, $ty, 7, $HlandProcity)) {
						if(!($HdProcitySelfNoDefence) || ($id != $tIsland->{'id'})) {
							$HdefenceHex[$id][$tx][$ty] = 1;
							$defence = 1;
							$defence = 0 if($HdProcityNoPerfect && (random(100) < $HdNoPerfectP));
						}
					} elsif(countAround($tLand, $tx, $ty, 1, $HlandHouse)) {
						$HdefenceHex[$id][$tx][$ty] = 1;
						$defence = 1;
					} elsif(countAround($tLand, $tx, $ty, 7, $HlandShuto)) {
						$HdefenceHex[$id][$tx][$ty] = 1;
						$defence = 1;
					} else {
						$HdefenceHex[$id][$tx][$ty] = -1;
						$defence = 0;
					}
				}

				if($defence == 1) {
					# 공안폭파
					$bouei++;
					$tIsland->{'ext'}[7]++; # 방위 시설에서 방어한 미사일의 수
					next;
				}

				if($tIsland->{'eis5'}) { # 방위위성이 있는 경우
					if(random(5000) < $tIsland->{'rena'}) {
						$tIsland->{'eis5'} -= 2;
						if($tIsland->{'eis5'} < 1) {
							$tIsland->{'eis5'} = 0;
							logEiseiEnd($target, $tName, $HeiseiName[5]);
						}
						$bouei++;
						next;
					}
				}

				# '효과 없음' hex를 먼저 판정
				if(($kind != $HcomMissileLR) && # 지형융기탄에서 없으면
					((($tL == $HlandSea) && ($tLv == 0)) || # 깊은 바다
					((($tL == $HlandSea)	 || # 바다또는...
					 ($tL == $HlandSbase)	|| # 해저 기지또는...
					 ($tL == $HlandSeacity) || # 해저 도시또는...
					 ($tL == $HlandSeatown) || # 해저 신도시또는...
					 ($tL == $HlandUmishuto) || # 바다 수도또는...
					 ($tL == $HlandUmiamu) || # 해상 시설또는...
					 ($tL == $HlandGold)	|| # 금광산또는...
					 ($tL == $HlandShrine) || # 시간의 신전또는...
					 ($tL == $HlandMountain)) # 산에서...
					 && ($kind != $HcomMissileLD)))){ # 육상 파괴탄라도없음
					# 해저 기지, 해저 도시, 해저 신도시의 경우, 바다처럼 처리
					if(($tL == $HlandSbase)	||
						($tL == $HlandSeatown) ||
						($tL == $HlandUmishuto) ||
						($tL == $HlandSeacity)) {
						$tL = $HlandSea;
					}
					$tLname = landName($tL, $tLv);

					# 무효화
					$mukou++;
					next;
				}

				# 탄 종류에서 분기
				if($kind == $HcomMissileLR) {
					# 지형융기탄

					if(($tL == $HlandMountain) || ($tL == $HlandGold) || ($tL == $HlandShrine)) {
						# 산, 시간의 신전에 착탄한 경우무효
						$mukou++;
						next;
					} elsif(($tL == $HlandSbase) || ($tL == $HlandSeacity) || ($tL == $HlandSeatown) || ($tL == $HlandUmishuto) ||
							($tL == $HlandOil) || ($tL == $HlandFune) || ($tL == $HlandFrocity) || ($tL == $HlandUmiamu)) {
						# 해저 기지, 해저 도시, 해저 신도시, 유전, 선박, 해상 시설라면, 대상 위치를 얕은 바다로
						$tLand->[$tx][$ty] = $HlandSea;
						$tLandValue->[$tx][$ty] = 1;
						logMsLSbase($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint, "융기하여 얕은 바다가 되었습니다.");
						next;
					} elsif($tL == $HlandRottenSea) {
						# 오염된 바다라면, 대상 위치를 산로
						$tLand->[$tx][$ty] = $HlandMountain;
						$tLandValue->[$tx][$ty] = 0;
						logMsLOther($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint, "오염된 바다는 융기하여 산이 되었습니다.");
						next;
					} elsif(($tL == $HlandSea) || ($tL == $HlandIce)) {
						if(($tLv == 1) || ($tL == $HlandIce)){
							# 얕은 바다의 경우
							$tLand->[$tx][$ty] = $HlandWaste;
							$tLandValue->[$tx][$ty] = 0;
							logMsLOther($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint, "융기하여 황무지가 되었습니다.");
							$tIsland->{'area'}++;

							if($seaCount <= 4) {
							# 주변 바다가 3헥스 이내이므로, 얕은 바다로
								my($i, $sx, $sy);
								for($i = 1; $i < 7; $i++) {
									$sx = $x + $ax[$i];
									$sy = $y + $ay[$i];

									# 행 기준 위치 조정
									$sx-- if(!($sy % 2) && ($y % 2));

									if(($sx>= 0) && ($sx < $HislandSize) && ($sy>= 0) && ($sy < $HislandSize) &&
										($tLand->[$sx][$sy] == $HlandSea)) {
										# 범위 안의 경우
										$tLandValue->[$sx][$sy] = 1;
									}
						 		}
							}
							next;
						} else {
							# 바다이면 대상 위치를 얕은 바다로 변경
							$tLand->[$tx][$ty] = $HlandSea;
							$tLandValue->[$tx][$ty] = 1;
							logMsLSbase($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint, "융기하여 얕은 바다가 되었습니다.");
							next;
						}
					} elsif($tL == $HlandMonster){
						# 괴수라면
						logMsLMonster($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint, "융기시 산이 생겼습니다.");
						# 산이 됨
						$tLand->[$tx][$ty] = $HlandMountain;
						$tLandValue->[$tx][$ty] = 0;
						next;
					} elsif($tL == $HlandHugeMonster){
						# 거대괴수
						my($mKind, $mSea, $mHuge, $mName, $mHp) = hugeMonsterSpec($tLv);
						my($special) = $HhugeMonsterSpecial[$mKind];

						# 출현하고 있는 섬 공격이외무효
						if(($special & 0x200) && ($tIsland->{'id'} != $island->{'id'}) && ($tIsland->{'id'} <= 100)) {
							$kaijumukou++;
							next;
						}

						if($mHuge == 0) {
							my($i, $sx, $sy);
							my $deflag = 0;
							for($i = 1; $i < 7; $i++) {
								next if($HhugeMonsterImage[$mKind][$i] eq '');
								$sx = $tx + $ax[$i];
								$sy = $ty + $ay[$i];
								# 행 기준 위치 조정
								$sx-- if((($sy % 2) == 0) && (($ty % 2) == 1));

								next if($tLand->[$sx][$sy] != $HlandHugeMonster);
								my($mKind2, $mSea2, $mHuge2, $mName2, $mHp2) = hugeMonsterSpec($tLandValue->[$sx][$sy]);
								next if($mHuge2 != $i);
								# 코어의 주변이남겨 둔 것 경우 공격무효
								if($special & 0x2000) {
									$deflag = 1;
									$kaijumukou++;
									last;
								} elsif ($mSea2 < 2) {
									$tLand->[$sx][$sy] = $HlandSea;
									$tLandValue->[$sx][$sy] = $mSea2;
								} else {
									$tLand->[$sx][$sy] = $HlandWaste;
									$tLandValue->[$sx][$sy] = 1;
								}
							}
							next if($deflag);
						}
						if ($mSea == 0) {
							# 바다에 있는
							logMsLMonster($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint, "융기하여 얕은 바다가 되었습니다.");
							# 얕은 바다로
							$tLand->[$tx][$ty] = $HlandSea;
							$tLandValue->[$tx][$ty] = 1;
						} elsif ($mSea == 1) {
							# 얕은 바다에 있는
							logMsLMonster($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint, "융기하여 황무지가 되었습니다.");
							# 황무지로
							$tLand->[$tx][$ty] = $HlandWaste;
							$tLandValue->[$tx][$ty] = 1;
						} else {
							logMsLMonster($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint, "융기시 산이 생겼습니다.");
							# 산이 됨
							$tLand->[$tx][$ty] = $HlandMountain;
							$tLandValue->[$tx][$ty] = 0;
						}
						next;
					} elsif(($tL == $HlandTown)	||
							($tL == $HlandMinato) ||
							($tL == $HlandNewtown) ||
							($tL == $HlandOnsen) ||
							($tL == $HlandBigtown)) {
						# 도시, 항구, 뉴타운, 현대 도시의 경우
						if(($land->[$bx][$by] == $HlandBase) ||
							($land->[$bx][$by] == $HlandSbase)) {
							# 경험치
							# 아직 기지인 경우만
							$landValue->[$bx][$by] += int($tLv / 20);
							$landValue->[$bx][$by] = $HmaxExpPoint if($landValue->[$bx][$by]> $HmaxExpPoint);
						}
						logMsLOther($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint, "융기시 산이 생겼습니다.");
						# 산이 됨
						$tLand->[$tx][$ty] = $HlandMountain;
						$tLandValue->[$tx][$ty] = 0;
						if (random(1000) < 22) {
							$tLand->[$tx][$ty] = $HlandMonument;
							$tLandValue->[$tx][$ty] = 75;
						}
						next;
					} else {
						# 기타
						logMsLOther($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint, "융기시 산이 생겼습니다.");
						# 산이 됨
						$tLand->[$tx][$ty] = $HlandMountain;
						$tLandValue->[$tx][$ty] = 0;
						if (random(1000) < 22) {
							$tLand->[$tx][$ty] = $HlandMonument;
							$tLandValue->[$tx][$ty] = 75;
						}
						next;
					}
					# 지형융기탄여기까지

				} elsif($kind == $HcomMissileSS) {
					# 핵 미사일
					logMsSS($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint);
					wideDamageli($target, $tName, $tLand, $tLandValue, $tx, $ty);

				} elsif($kind == $HcomMissileLD) {
					# 육지 파괴탄
					if(($tL == $HlandMountain) || ($tL == $HlandGold) || ($tL == $HlandShrine) || ($tL == $HlandOnsen)) {
						# 산(황무지가 됨)
						logMsMonster($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint, "사라지고 황무지가 되었습니다.");
						# 황무지가 됨
						$tLand->[$tx][$ty] = $HlandWaste;
						$tLandValue->[$tx][$ty] = 0;
						next;

					} elsif(($tL == $HlandSbase)	||
							($tL == $HlandFune)	||
							($tL == $HlandFrocity) ||
							($tL == $HlandUmiamu) ||
							($tL == $HlandSeatown) ||
							($tL == $HlandUmishuto) ||
							($tL == $HlandSeacity)) {
						# 해저 기지, 선박, 해상 시설, 해저 도시, 해저 신도시
						logMsLSbase($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint, "흔적도 없이 날아갔습니다.");
					} elsif($tL == $HlandMonster) {
						# 괴수
						logMsLMonster($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint, "수몰되었습니다.");
					} elsif($tL == $HlandHugeMonster){
						# 거대괴수
						my($mKind, $mSea, $mHuge, $mName, $mHp) = hugeMonsterSpec($tLv);
						my($special) = $HhugeMonsterSpecial[$mKind];

						# 출현하고 있는 섬 공격이외무효
						if(($special & 0x200) && ($tIsland->{'id'} != $island->{'id'}) && ($tIsland->{'id'} <= 100)) {
							# 경화 중
							$kaijumukou++;
							next;
						}

						if($mHuge == 0) {
							my($i, $sx, $sy);
							my $deflag = 0;
							for($i = 1; $i < 7; $i++) {
								next if($HhugeMonsterImage[$mKind][$i] eq '');
								$sx = $tx + $ax[$i];
								$sy = $ty + $ay[$i];
								# 행 기준 위치 조정
								$sx-- if((($sy % 2) == 0) && (($ty % 2) == 1));

								next if($tLand->[$sx][$sy] != $HlandHugeMonster);
								my($mKind2, $mSea2, $mHuge2, $mName2, $mHp2) = hugeMonsterSpec($tLandValue->[$sx][$sy]);
								next if($mHuge2 != $i);
								if($special & 0x2000) {
									$deflag = 1;
									$kaijumukou++;
									last;
								} elsif ($mSea2 < 2) {
									$tLand->[$sx][$sy] = $HlandSea;
									$tLandValue->[$sx][$sy] = $mSea2;
								} else {
									$tLand->[$sx][$sy] = $HlandWaste;
									$tLandValue->[$sx][$sy] = 1;
								}
							}
							next if($deflag);
						}
						if ($mSea < 2) {
							# 바다, 얕은 바다에 있는
							logMsLMonster($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint, "해저가 깎였습니다.");
							# 바다로
							$tLand->[$tx][$ty] = $HlandSea;
							$tLandValue->[$tx][$ty] = 0;
						} else {
							logMsLMonster($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint, "얕은 바다가 되었습니다.");
							# 산이 됨
							$tLand->[$tx][$ty] = $HlandSea;
							$tLandValue->[$tx][$ty] = 1;
						}
						next;
					} elsif($tL == $HlandRottenSea) {
						# 오염된 바다
						logMsLOther($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint, "오염된 바다는 바다에침몰봄했습니다.");
					} elsif(($tL == $HlandSea) || ($tL == $HlandIce)) {
						# 얕은 바다
						logMsLOther($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint, "해저가 깎였습니다.");
					} else {
						# 기타
						logMsLOther($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint, "육지가 수몰되었습니다.");
					}

					if(($tL == $HlandTown)	||
						($tL == $HlandMinato) ||
						($tL == $HlandNewtown) ||
						($tL == $HlandBigtown)) {
						# 도시, 항구, 뉴타운, 현대 도시의 경우
						if(($land->[$bx][$by] == $HlandBase) ||
							($land->[$bx][$by] == $HlandSbase)) {
							# 경험치
							# 아직 기지인 경우만
							$landValue->[$bx][$by] += int($tLv / 20);
							$landValue->[$bx][$by] = $HmaxExpPoint if($landValue->[$bx][$by]> $HmaxExpPoint);
						}
					}

					# 얕은 바다가 됨
					$tLand->[$tx][$ty] = $HlandSea;
					$tIsland->{'area'}--;
					$tLandValue->[$tx][$ty] = 1;

					# 라도유전, 얕은 바다, 해저 기지였으면 바다
					if(($tL == $HlandOil)	 ||
						($tL == $HlandSea)	 ||
						($tL == $HlandSeacity) ||
						($tL == $HlandIce) ||
						($tL == $HlandSeatown) ||
						($tL == $HlandUmishuto)	||
						($tL == $HlandFune)	||
						($tL == $HlandFrocity) ||
						($tL == $HlandUmiamu) ||
						($tL == $HlandSbase)) {
						$tLandValue->[$tx][$ty] = 0;
					}
					# 육지 파괴탄여기까지

				} else {
					# 기타 미사일
					if($tL == $HlandWaste) {
						$mukou++;
					} elsif($tL == $HlandRottenSea) {
						# 오염된 바다
						if($kind == $HcomMissileST) {
							# 스텔스
							logMsNormalS($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint, "오염된 바다는 불타 없어졌습니다.");
						} else {
							# 일반
							logMsNormal($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint, "오염된 바다는 불타 없어졌습니다.");
						}
					} elsif($tL == $HlandMonster) {
						# 괴수
						my($mKind, $mName, $mHp) = monsterSpec($tLv);
						my($special) = $HmonsterSpecial[$mKind];

						# 경화 중?
						if((($special == 3) && ($HislandTurn % 2)) ||
							(($special == 8) && !(seqnum($HislandTurn) % 2)) ||
							(($special == 4) && !($HislandTurn % 2))) {
							# 경화 중
							$kaijumukou++;
							next;
						} else {
							# 경화 중이 아님
							my $rflag = random(1000)+$island->{'co4'}*100+$island->{'co99'}*100;
							if((($special == 5) || ($mKind == 15)) && ($rflag < $HmonsterDefence)){
								$kaijumukou++;
								next;
							} elsif(($mKind == 13 && $rflag < 900) ||
									($mKind == 20 && $rflag < 800) ||
									($mKind == 21 && $rflag < 700) ||
									($mKind == 22 && $rflag < 750) ||
									($mKind == 18 && $rflag < (600+random(400))) ||
									($mKind == 30 && $rflag < (950+random(50))) ||
									($mKind == 19 && $rflag < (666+random(400)))) {
								$kaijumukou++;
								next;
							} elsif($mKind == 14 && $rflag < 400){
								$kaijumukou++;
								next;
							} elsif($mKind == 17 && $rflag < (400+random(500))){
								$kaijumukou++;
								next;
							}

							if($mHp == 1) {
								# 괴수를 처치했습니다
								if(($land->[$bx][$by] == $HlandBase) ||
									($land->[$bx][$by] == $HlandSbase)) {
									# 경험치
									$landValue->[$bx][$by] += $HmonsterExp[$mKind];
									$landValue->[$bx][$by] = $HmaxExpPoint if($landValue->[$bx][$by]> $HmaxExpPoint);
								}

								if($mKind == 8) { # 오무라면
									# 오염된 바다발생
									my($point) = "($tx, $ty)";
									logRottenSeaBorn($id, $tName, $point);
									$tLand->[$tx][$ty] = $HlandRottenSea;
									$tLandValue->[$tx][$ty] = 1;
									next;
								}

								if($kind == $HcomMissileST) {
									# 스텔스
									logMsMonsterS($id, $target, $name, $tName, $comName, $mName, $point, $tPoint, "힘이 다해 쓰러졌습니다.");
								} else {
									# 일반
									logMsMonster($id, $target, $name, $tName, $comName, $mName, $point, $tPoint, "힘이 다해 쓰러졌습니다.");
								}

								# 수입
								my($value) = $HmonsterValue[$mKind];
								if($value> 0) {
									if($tIsland->{'id'} <= 100) {
										$tIsland->{'money'} += $value;
										logMsMonMoney($target, $mName, $value);
									} else {
										$island->{'money'} += $value;
										logMsMonMoney($id, $mName, $value);
									}
									if($island->{'sin'}> 0) {
										my($value, $str);
										$value = $HmonsterValue[$mKind] + random(101);
										$island->{'money'} += $value;
										$str = "$value$HunitMoney";
										# 수입 로그
										logSinMoney($id, $name, $str);
									}
									if($island->{'jin'}> 0) {
										my($value, $str);
										$value = $HmonsterValue[$mKind] + random(101);
										$island->{'money'} += $value;
										$str = "$value$HunitMoney";
										# 수입 로그
										logJinMoney($id, $name, $str);
									}
								}

								# 괴수퇴치 수
								$island->{'taiji'}++;

								# 수상 관계
								my($prize) = $island->{'prize'};
								my($prize1, $prize2) = split(/\t/, $prize);
								$prize1 =~ /([0-9]*),([0-9]*),(.*)/;
								my($flags) = $1;
								my($monsters) = $2;
								my($turns) = $3;
								my($v) = 2 ** $mKind;
								$monsters |= $v;
								$island->{'prize'} = "$flags,$monsters,$turns\t$prize2";
							} else {
								# 괴수살아하고 있는
								$kaijuhit++;
								# HP가 1 감소
								$tLandValue->[$tx][$ty]--;
								next;
							}
						}

					} elsif($tL == $HlandHugeMonster){
						# 거대괴수
						my($mKind, $mSea, $mHuge, $mName, $mHp) = hugeMonsterSpec($tLv);
						my($special) = $HhugeMonsterSpecial[$mKind];

						# 출현하고 있는 섬 공격이외무효
						if(($special & 0x200) && ($tIsland->{'id'} != $island->{'id'}) && ($tIsland->{'id'} <= 100)) {
							# 경화 중
							$kaijumukou++;
							next;
						}

						# 경화 중?
						if((($special & 0x10) && ($HislandTurn % 2)) ||
							(($special & 0x40) && !(seqnum($HislandTurn) % 2)) ||
							(($special & 0x20) && !($HislandTurn % 2))) {
							# 경화 중
							$kaijumukou++;
						} else {
							# 경화 중이 아님
							if(($mHp == 1) || (($special & 0x100) && ($mHp % 2 == 1) && ($mHuge == 0) && ($HislandNumber> 1))) {
								if($mHuge == 0) {
									# 코어이면 시와 했습니다
									my($i, $sx, $sy, $bx, $by, $mSea2);
									my $deflag = 0;
									for($i = 1; $i < 7; $i++) {
										next if($HhugeMonsterImage[$mKind][$i] eq '');
										$sx = $tx + $ax[$i];
										$sy = $ty + $ay[$i];
										# 행 기준 위치 조정
										$sx-- if((($sy % 2) == 0) && (($ty % 2) == 1));

										next if($tLand->[$sx][$sy] != $HlandHugeMonster);
										my($mKind2, $mSea2, $mHuge2, $mName2, $mHp2) = hugeMonsterSpec($tLandValue->[$sx][$sy]);
										next if($mHuge2 != $i);
										# 코어의 주변이남겨 둔 것 경우 공격무효
										if($special & 0x2000) {
											$deflag = 1;
											$kaijumukou++;
											last;
										} elsif ($mSea2 < 2) {
											$tLand->[$sx][$sy] = $HlandSea;
											$tLandValue->[$sx][$sy] = $mSea2;
										} else {
											$tLand->[$sx][$sy] = $HlandWaste;
											$tLandValue->[$sx][$sy] = 1;
										}
									}
									next if($deflag);
									if($mHp != 1) {
										$kaijuhit++;
										if ($mSea < 2) {
											# 바다, 얕은 바다에 있는
											$tLand->[$tx][$ty] = $HlandSea;
											$tLandValue->[$tx][$ty] = $mSea;
										} else {
											$tLand->[$tx][$ty] = $HlandWaste;
											$tLandValue->[$tx][$ty] = 1;
										}
										$mHp--;
										my $sNo = $HidToNumber{$tIsland->{'id'}} + random($HislandNumber - 2) + 1;
										$sNo %= $HislandNumber;
										my $sIsland = $Hislands[$sNo];
										my $sId = $sIsland->{'id'};
										my $sName = islandName($sIsland);
										my $sLand = $sIsland->{'land'};
										my $sLandValue = $sIsland->{'landValue'};

										# 어디에 출현할지 결정
										$bx = random($HislandSize - 2) + 1;
										$by = random($HislandSize - 2) + 1;
										# 지형 이름
										my($lName) = landName($sLand->[$bx][$by], $sLandValue->[$bx][$by]);

										for($i = 0; $i < 7; $i++) {
											next if($HhugeMonsterImage[$mKind][$i] eq '');
											$sx = $bx + $ax[$i];
											$sy = $by + $ay[$i];
											# 행 기준 위치 조정
											$sx-- if(!($sy % 2) && ($by % 2));
											my $ssL = $sLand->[$sx][$sy];
											my $ssLv = $sLandValue->[$sx][$sy];
											if($ssL == $HlandSea) {
												$mSea2 = $ssLv;
											} elsif(($ssL == $HlandSbase) ||
												($ssL == $HlandSeacity) ||
												($ssL == $HlandSeatown) ||
												($ssL == $HlandNursery) ||
												($ssL == $HlandOil) ||
												($ssL == $HlandIce) ||
												($ssL == $HlandFrocity) ||
												($ssL == $HlandUmishuto) ||
												($ssL == $HlandFune) ||
												($ssL == $HlandUmiamu)) {
												$mSea2 = 0;
											} else {
												$mSea2 = 3;
											}
											# lv 의 값을 결하기
											my $lv = ($mKind<<9) + ($mSea2<<7) + ($i<<4) + $mHp;
											# 해당 헥스를 괴수로
											$Hislands[$sNo]->{'land'}->[$sx][$sy] = $HlandHugeMonster;
											$Hislands[$sNo]->{'landValue'}->[$sx][$sy] = $lv;
										}
										# 메시지
										logMonsCome($sId, $sName, $HhugeMonsterName[$mKind], "($bx, $by)", $lName);
										next;
									}
									if($kind == $HcomMissileST) {
										# 스텔스
										logMsMonsterS($id, $target, $name, $tName, $comName, $mName, $point, $tPoint, "힘이 다해 쓰러졌습니다.");
									} else {
										# 일반
										logMsMonster($id, $target, $name, $tName, $comName, $mName, $point, $tPoint, "힘이 다해 쓰러졌습니다.");
									}

									# 수입
									my($value) = $HhugeMonsterValue[$mKind];
									if($value> 0) {
										if($tIsland->{'id'} <= 100) {
											$tIsland->{'money'} += $value;
											logMsMonMoney($target, $mName, $value);
										} else {
											$island->{'money'} += $value;
											logMsMonMoney($id, $mName, $value);
										}
									}

									# 괴수퇴치 수
									$island->{'taiji'}++;

									# 수상 관계
									my($prize) = $island->{'prize'};
									my($prize1, $prize2) = split(/\t/, $prize);
									$prize1 =~ /([0-9]*),([0-9]*),(.*)/;
									my($flags) = $1;
									my($monsters) = $2;
									my($turns) = $3;
									my($v) = 2 ** $mKind;
									$prize2 |= $v;
									$island->{'prize'} = "$flags,$monsters,$turns\t$prize2";
								} else {
									if($kind == $HcomMissileST) {
										# 스텔스
										logMsMonsterS($id, $target, $name, $tName, $comName, $mName, $point, $tPoint, "체의 일부를 실패지금했습니다.");
									} else {
										# 일반
										logMsMonster($id, $target, $name, $tName, $comName, $mName, $point, $tPoint, "체의 일부를 실패지금했습니다.");
									}
								}
								# 시와 했습니다?
								if(($land->[$bx][$by] == $HlandBase) ||
									($land->[$bx][$by] == $HlandSbase)) {
									# 경험치
									$landValue->[$bx][$by] += $HhugeMonsterExp[$mKind];
									$landValue->[$bx][$by] = $HmaxExpPoint if($landValue->[$bx][$by]> $HmaxExpPoint);
								}
								if ($mSea < 2) {
									# 바다, 얕은 바다에 있는
									$tLand->[$tx][$ty] = $HlandSea;
									$tLandValue->[$tx][$ty] = $mSea;
								} else {
									$tLand->[$tx][$ty] = $HlandWaste;
									$tLandValue->[$tx][$ty] = 1;
								}
							} else {
								$kaijuhit++;
								# 괴수살아하고 있는
								# HP가 1 감소
								$tLandValue->[$tx][$ty]--;
							}
						}
						next;
					} else {
						# 일반 지형
						if($kind == $HcomMissileST) {
							# 스텔스
							logMsNormalS($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint, "일대가 괴멸되었습니다.");
						} else {
							# 일반
							logMsNormal($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint, "일대가 괴멸되었습니다.");
							$island->{'ext'}[3]++ if ($tL == $HlandBase); # 격파했습니다 미사일 기지의 수
						}
					}

					# 경험치
					if(($tL == $HlandTown) ||
						($tL == $HlandMinato) ||
						($tL == $HlandNewtown) ||
						($tL == $HlandBigtown)) {
						if(($land->[$bx][$by] == $HlandBase) ||
							($land->[$bx][$by] == $HlandSbase)) {
							$landValue->[$bx][$by] += int($tLv / 20);
							$boat += $tLv; # 일반 미사일이므로 난민에플러스
							$landValue->[$bx][$by] = $HmaxExpPoint if($landValue->[$bx][$by]> $HmaxExpPoint);
						}
					}

					# 황무지가 됨
					$tLand->[$tx][$ty] = $HlandWaste;
					$tLandValue->[$tx][$ty] = 1; # 착탄 지점

					my($mKind, $mName, $mHp) = monsterSpec($tLv);
					my($special) = $HmonsterSpecial[$mKind];

					if($mKind == 17 && $tL == $HlandMonster){
						$tLand->[$tx][$ty] = $HlandMonument;
						$tLandValue->[$tx][$ty] = 86;
					}
					if(($tLv == 25 && ($tL == $HlandMonument)) && (random(10000) < $island->{'rena'}) && ($island->{'rena'}> 2000)) {
						$kind = random($HmonsterLevel4) + 1;
						$lv = ($kind << 4) + $HmonsterBHP[$kind] + random($HmonsterDHP[$kind]);
						$tLand->[$tx][$ty] = $HlandMonster;
						$tLandValue->[$tx][$ty] = $lv;
						# 괴수 정보
						my($mKind, $mName, $mHp) = monsterSpec($lv);

						# 메시지
						logMonsComemagic($id, $target, $name, $tName, $mName, "($tx, $ty)", $lName);
					}
					# 라도유전였으면 바다
					if(($tL == $HlandOil) ||
						($tL == $HlandFrocity) ||
						($tL == $HlandFune)) {
						$tLand->[$tx][$ty] = $HlandSea;
						$tLandValue->[$tx][$ty] = 0;
					} elsif(($tL == $HlandNursery) || ($tL == $HlandIce)) {
						# 양식장이면 얕은 바다
						$tLand->[$tx][$ty] = $HlandSea;
						$tLandValue->[$tx][$ty] = 1;
					} elsif($tL == $HlandOnsen) {
						# 라도온천이면 산
						$tLand->[$tx][$ty] = $HlandMountain;
						$tLandValue->[$tx][$ty] = 0;
					}
				}
			}
			# 이 기지의 미사일 발사 수를 기억
			$island->{'missiles'}->[$bx][$by] = $missiles;
			# 카운트 증가
			$count++;
		}

		# 로그
		if($kind == $HcomMissileST) {
			# 스텔스
			logMsTotalS($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint, $total, $mukou, $bouei, $kaijumukou, $kaijuhit, $fuhatu);
		} else {
			# 일반
			logMsTotal($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint, $total, $mukou, $bouei, $kaijumukou, $kaijuhit, $fuhatu);
		}

		if(!$flag) {
			# 기지가 하나도 없어진 경우
			logMsNoBase($id, $name, $comName);
			return 0;
		}

		# 난민판정
		$boat = int($boat / 2);
		if($boat && ($id != $target) && ($kind != $HcomMissileST)) {
			# 난민표착
			my($achive); # 도달난민
			my($i);
			for($i = 0; ($i < $HpointNumber && $boat> 0); $i++) {
				$bx = $Hrpx[$i];
				$by = $Hrpy[$i];
				if($land->[$bx][$by] == $HlandTown) {
					# 읍의 경우
					my($lv) = $landValue->[$bx][$by];
					if($boat> 50) {
						$lv += 50;
						$boat -= 50;
						$achive += 50;
					} else {
						$lv += $boat;
						$achive += $boat;
						$boat = 0;
					}
					if($lv> 200) {
						$boat += ($lv - 200);
						$achive -= ($lv - 200);
						$lv = 200;
					}
					$landValue->[$bx][$by] = $lv;
				} elsif($land->[$bx][$by] == $HlandPlains) {
					# 평지의 경우
					$land->[$bx][$by] = $HlandTown;;
					if($boat> 10) {
						$landValue->[$bx][$by] = 5;
						$boat -= 10;
						$achive += 10;
					} elsif($boat> 5) {
						$landValue->[$bx][$by] = $boat - 5;
						$achive += $boat;
						$boat = 0;
					}
				}
				last if($boat <= 0);
			}
			if($achive> 0) {
				# 조금이라도 도착한 경우 로그를 출력
				logMsBoatPeople($id, $name, $achive);
				$island->{'ext'}[4] += int($achive); # 구출한 난민의 합계인구

				# 난민의 수가일정수이상라면, 평화상의 가능성있음
				if($achive>= 200) {
					my($prize) = $island->{'prize'};
					my($prize1, $prize2) = split(/\t/, $prize);
					$prize1 =~ /([0-9]*),([0-9]*),(.*)/;
					my($flags) = $1;
					my($monsters) = $2;
					my($turns) = $3;

					if((!($flags & 8)) && $achive>= 200){
						$flags |= 8;
						logPrize($id, $name, $Hprize[4]);
					} elsif((!($flags & 16)) && $achive> 500){
						$flags |= 16;
						logPrize($id, $name, $Hprize[5]);
					} elsif((!($flags & 32)) && $achive> 800){
						$flags |= 32;
						logPrize($id, $name, $Hprize[6]);
					}
					$island->{'prize'} = "$flags,$monsters,$turns\t$prize2";
				}
			}
		}

		if($HanyMissileMode){#복수 미사일 발사 가능 모드
			# 다음 명령도 미사일 계열인가요?
			$kind = $comArray->[0]->{'kind'};
			if(($kind == $HcomMissileNM) ||
				($kind == $HcomMissilePP) ||
				($kind == $HcomMissileST) ||
				($kind == $HcomMissileLD)) {
				# 미사일계

				# 미사일 발사 수에남은 이있는 지조사하기
				my($flag);
				$count--;
				while ($count < $HpointNumber) {
					$bx = $Hrpx[$count];
					$by = $Hrpy[$count];
					if(($land->[$bx][$by] == $HlandBase) ||
						($land->[$bx][$by] == $HlandSbase)) {
						$flag = expToLevel($land->[$bx][$by], $landValue->[$bx][$by]) - $island->{'missiles'}->[$bx][$by];
						return 0 if($flag); # 남은 이있다면 턴을 소비하지 않음
					}
					$count++;
				}
			}
		}
		return 1;

	} elsif($kind == $HcomSendMonster) {
		# 괴수 파견
		my($aId, %amityFlag);
		foreach $aId (@{$island->{'allyId'}}) {
			foreach (@{$Hally[$HidToAllyNumber{$aId}]->{'memberId'}}) {
				next if($_ == $id);
				$amityFlag{$_} = 1;
			}
		}
		# 개발 기간이면 명령 무시
		if ($HarmisticeTurn && ($HislandTurn <= $HarmisticeTurn || $amityFlag{$target})) {
			# 공격이 허가되어 있지 않음
			logNotAvail($id, $name, $comName);
			return 0;
		}
		# 대상 가져오기
		my($tn) = $HidToNumber{$target};
		my($tIsland) = $Hislands[$tn];
		my($tName) = islandName($tIsland);

		unless(defined $tn) {
			# 대상이 이미 없음
			logNoAny($id, $name, $comName, "목표 ${AfterName}에 대상이 없음");
			return 0;
		}

		# 자기 섬의 인구가 적거나, 대상 섬의 인구가 적으면, 실행은 허가되지 않는
		if(($tIsland->{'id'} != $island->{'id'}) && (($island->{'pop'} < $HguardPop) || ($tIsland->{'pop'} < $HguardPop))) {
			logNoAny($id, $name, $comName, "실행이허가되지 않는");
			return 0;
		}

		# 메시지
		logMonsSend($id, $target, $name, $tName);
		$tIsland->{'monstersend'}++;

		$island->{'money'} -= $cost;
		return 1;

	} elsif($kind == $HcomAlly) {
		# 동맹 가입·탈퇴
		# 대상 가져오기
		return if(!$HallyUse || !$HallyJoinComUse || $HarmisticeTurn);
		my($tn) = $HidToNumber{$target};
		my($tan) = $HidToAllyNumber{$target};
		if(($tn eq '') || ($tan eq '')) {
			# 대상이 이미 없음
			logNoAny($id, $name, $comName, "목표 ${AfterName}에 대상이 없음");
			return 0;
		}
		my $tName = islandName($Hislands[$tn]);
		if(defined $HidToAllyNumber{$id}) {
			logLeaderAlready($id, $name, $tName, $comName);
			return;
		}
		my $ally = $Hally[$tan];
		if($HallyJoinOne && ($island->{'allyId'}[0] ne '') && ($island->{'allyId'}[0] != $ally->{'id'})) {
			logOtherAlready($id, $name, $tName, $comName);
			return;
		}
		my $allyMember = $ally->{'memberId'};
		my @newAllyMember = ();
		my $flag = 0;
		foreach (@$allyMember) {
			if(!(defined $HidToNumber{$_})) {
			} elsif($_ == $id) {
				$flag = 1;
			} else {
				push(@newAllyMember, $_);
			}
		}
		if($flag) {
			logAllyEnd($id, $target, islandName($island), $ally->{'name'});
			my @newAlly = ();
			foreach (@{$island->{'allyId'}}) {
				if($_ != $ally->{'id'}) {
					push(@newAlly, $_);
				}
			}
			$island->{'allyId'} = \@newAlly;
			$ally->{'score'} -= $island->{'pts'};
			$ally->{'number'}--;
		} else {
			logAlly($id, $target, islandName($island), $ally->{'name'});
			push(@newAllyMember, $id);
			push(@{$island->{'allyId'}}, $ally->{'id'});
			$ally->{'score'} += $island->{'pts'};
			$ally->{'number'}++;
		}
		$island->{'money'} -= $HcomCost[$HcomAlly];
		$ally->{'memberId'} = \@newAllyMember;
		return 1;

	} elsif($kind == $HcomSell) {
		# 식량 수출
		# 수출량 결정
		$arg = 1 if(!$arg);
		my($value) = min($arg * (-$cost), $island->{'food'});

		# 수출 로그
		logSell($id, $name, $comName, $value);
		$island->{'food'} -= $value;
		$island->{'money'} += ($value / 10);
		return 0;

	} elsif(($kind == $HcomFood) ||
			($kind == $HcomMoney)) {
		# 지원계
		my($aId, %amityFlag);
		foreach $aId (@{$island->{'allyId'}}) {
			foreach (@{$Hally[$HidToAllyNumber{$aId}]->{'memberId'}}) {
				next if($_ == $id);
				$amityFlag{$_} = 1;
			}
		}
		# 대상 가져오기
		my($tn) = $HidToNumber{$target};
		my($tIsland) = $Hislands[$tn];
		my($tName) = islandName($tIsland);

		# 다른 진영에는 지원할 수 없
		if ($HarmisticeTurn && $HcampAidOnly && !$amityFlag{$target}) {
			logAidFail($id, $target, $name, $tName, $comName);
			return 0;
		}
		# 자기 섬의 인구가 적으면, 실행은 허가되지 않는
		if(($tIsland->{'id'} != $island->{'id'}) && ($island->{'pop'} < $HguardPop)) {
			logNoAny($id, $name, $comName, "실행이허가되지 않는");
			return 0;
		}

		# 지원량 결정
		$arg = 1 if(!$arg);
		my($value, $str);
		if($cost < 0) {
			$value = min($arg * (-$cost), $island->{'food'});
			$str = "${HtagFood_}$value$HunitFood${H_tagFood}";
		} else {
			$value = min($arg * ($cost), $island->{'money'});
			$str = "${HtagMoney_}$value$HunitMoney${H_tagMoney}";
		}

		# 지원 로그
		logAid($id, $target, $name, $tName, $comName, $str);

		if($cost < 0) {
			$island->{'food'} -= $value;
			$tIsland->{'food'} += $value;
			$island->{'ext'}[1] += int($value/10); # 공헌도
			$tIsland->{'ext'}[1] -= int($value/10); # 공헌도
		} else {
			$island->{'money'} -= $value;
			$tIsland->{'money'} += $value;
			$island->{'ext'}[1] += $value; # 공헌도
			$tIsland->{'ext'}[1] -= $value; # 공헌도
		}
		return 0;

	} elsif($kind == $HcomPropaganda) {
		# 유치 활동
		logPropaganda($id, $name, $comName);
		$island->{'propaganda'} = 1;
		$island->{'money'} -= $cost;
		if($arg> 1) {
			$arg--;
			slideBack($comArray, 0);
			$comArray->[0] = {
				'kind' => $kind,
				'target' => $target,
				'x' => $x,
				'y' => $y,
				'arg' => $arg
			};
		}
		return 1;

	} elsif($kind == $HcomSave) {
		# 시간 저장
		return 0 unless($island->{'shr'});
		if(-e "${HdirName}/${id}.${HsubData}") {
			copy("${HdirName}/${id}.${HsubData}", "${HdirName}/savedata.$id");
			$island->{'money'} -= $cost;
			logSaveLoad($id, $name, $comName, "을 실행했습니다.");
			my($sx, $sy);
			foreach $sy (0..$islandSize) {
				foreach $sx (0..$islandSize) {
					$landValue->[$sx][$sy] = $HislandTurn if($land->[$sx][$sy] == $HlandShrine);
				}
			}
		} else {
			logSaveLoad($id, $name, $comName, "에 실패했습니다.");
			return 0;
		}
		return 1;

	} elsif($kind == $HcomLoad) {
		# 시간 복원
		return 0 unless($island->{'shr'});
		if(-e "${HdirName}/savedata.$id") {
			# 지형 데이터 읽기
			if(!open(IIN, "${HdirName}/savedata.$id")) {
				logSaveLoad($id, $name, $comName, "에 실패했습니다.");
				return 0;
			}
			my(@sland, @slandValue, $sline, $sx, $sy);
			foreach $sy (0..$islandSize) {
				$sline = <IIN>;
				foreach $sx (0..$islandSize) {
					$sline =~ s/^(..)(...)//;
					$sland[$sx][$sy] = hex($1);
					$slandValue[$sx][$sy] = hex($2);
					$landValue->[$sx][$sy] = 0 if($land->[$sx][$sy] == $HlandShrine);
				}
			}
			close(IIN);
			$island->{'land'} = \@sland;
			$island->{'landValue'} = \@slandValue;
			unlink("${HdirName}/savedata.$id");
			logSaveLoad($id, $name, $comName, "을 실행했습니다.");
			$island->{'money'} -= $cost;
			return 1;
		} else {
			logSaveLoad($id, $name, $comName, "에 실패했습니다.");
			return 0;
		}

	} elsif($kind == $HcomGiveup) {
		# 포기
		$island->{'dead'} = 1;
		islandDeadAlly($island) if($HallyNumber);
		logGiveup($id, $name);
		unlink("${HdirName}/${id}.${HsubData}");
		unlink("${HdirName}/savedata.$id") if(-e "${HdirName}/savedata.$id");
		return 1;
	}

	return 1;
}

# 성장 및 단일 헥스 재해
sub doEachHex {
	my($island) = @_;
	my(@monsterMove);

	# 도출 값
	my($name) = islandName($island);
	my($id) = $island->{'id'};
	my($land) = $island->{'land'};
	my($landValue) = $island->{'landValue'};
	my $reason;

	my($msseigen, $kougekiseigen, $kougekiseigenm) = (0, 0, 0);

	# 늘어나면인구의 타네 값
	my($addpop) = 10; # 마을, 읍
	my($addpop2) = 0; # 도시
	if($island->{'food'} < 0) {
		# 식량 부족
		$addpop = -30;
		$reason = '식량 부족';
	} elsif($island->{'propaganda'}) {
		# 유치 활동 중
		$addpop = 30;
		$addpop2 = 3;
	} elsif(random(20) < $island->{'rot'}) {
		# 포자!?
		$addpop = -10;
		$reason = '포자';
		logRotsick($id, $name);
	} elsif(random(2) < $island->{'c21'}) {
		# 역병!?
		$addpop = -3;
		$island->{'food'} -= int($island->{'food'} / 2);
		$reason = '역병';
		logSatansick($id, $name);
	} elsif($island->{'fim'} && !random(100)) {
		# 부작용?!
		$addpop = -20;
		logStarvefood($id, $name);
		$reason = '부작용';
	}

	# 루프
	my($x, $y, $i);
	foreach $i (0..$pointNumber) {
		$x = $Hrpx[$i];
		$y = $Hrpy[$i];
		my($landKind) = $land->[$x][$y];
		my($lv) = $landValue->[$x][$y];
		my($lName) = landName($landKind, $lv);

		if(($landKind == $HlandTown) ||
			($landKind == $HlandMinato) ||
			($landKind == $HlandSeacity)) {
			# 마을 계열
			my($monsterCount) = countAround($land, $x, $y, 7, $HlandMonster);
			if($monsterCount> 0) {
				$lv -= random(20)+10;
				$landValue->[$x][$y] = $lv;
				my $point = ($landKind == $HlandSeacity) ? '(?, ?)' : "($x, $y)";
				logMonsAttacks($id, $name, landName($landKind, $lv), $point);
				if(($lv <= 0) &&
				 ($landKind == $HlandSeacity)) {
					# 평지로 되돌리기
					$land->[$x][$y] = $HlandSea;
					$landValue->[$x][$y] = 0;
					next;
				} elsif($lv <= 0) {
					# 평지로 되돌리기
					$land->[$x][$y] = $HlandWaste;
					$landValue->[$x][$y] = 0;
					next;
				}
			}
			my($townCount) = countAround($land, $x, $y, 19, @Htowns);

			$land->[$x][$y] = $HlandBigtown if(($townCount> 17) && !random(1000) && ($lv> 195) && ($landKind == $HlandTown));

			if($addpop < 0) {
				# 부족
				$lv -= (random(-$addpop) + 1);
				if($lv <= 0) {
					if($landKind == $HlandTown) {
						# 평지로 되돌리기
						$land->[$x][$y] = $HlandPlains;
						$landValue->[$x][$y] = 0;
					} else {
						# 바다로 되돌림
						$land->[$x][$y] = $HlandSea;
						$landValue->[$x][$y] = 0;
						# 황무지로 되돌림
						$land->[$x][$y] = $HlandWaste if($landKind == $HlandMinato);
					}
					my($tName) = landName($land->[$x][$y], $landValue->[$x][$y]);
					logPopDecrease($id, $name, $lName, $tName, $reason, "($x, $y)");
					next;
				}
			} else {
				# 성장
				if($lv < 100) {
					$lv += random($addpop) + 1;
					$lv = 100 if($lv> 100);
				} else {
					# 도시가 되면 성장 지연이
					$lv += random($addpop2) + 1 if($addpop2);
				}
			}
			$lv = 200 if($lv> 200);
			$landValue->[$x][$y] = $lv;

		} elsif($landKind == $HlandProcity) {
			# 방재 도시
			if($addpop < 0) {
				# 부족
				$lv -= (random(-$addpop) + 1);
				if($lv <= 0) {
					# 평지로 되돌리기
					$land->[$x][$y] = $HlandPlains;
					$landValue->[$x][$y] = 0;
					logPopDecrease($id, $name, $lName, "평지", $reason, "($x, $y)");
					next;
				}
			} else {
				# 성장
				if($lv < 100) {
					$lv += random($addpop) + 1;
					if($lv> 100) {
						$lv = 100;
					}
				} else {
					# 도시가 되면 성장 지연이
					if($addpop2> 0) {
						$lv += random($addpop2) + 1;
					}
				}
			}
			if($lv> 200) {
				$lv = 200;
			}
			$landValue->[$x][$y] = $lv;

			if($lv == 200) {

				my($i, $sx, $sy);
				for($i = 1; $i < 7; $i++) {
					$sx = $x + $ax[$i];
					$sy = $y + $ay[$i];
					# 행 기준 위치 조정
					$sx-- if(!($sy % 2) && ($y % 2));
					# 범위 밖
					next if(($sx < 0) || ($sx> $islandSize) || ($sy < 0) || ($sy> $islandSize));
					if($land->[$sx][$sy] == $HlandMonster){
						# 주변 1Hex에 다른 괴수가 있으면 그 괴수를 공격

						# 대상이 되는 괴수각 요소 꺼내기
						my($tKind, $tName, $tHp) = monsterSpec($landValue->[$sx][$sy]);
						my($tlv) = $landValue->[$sx][$sy];
						my($tspecial) = $HmonsterSpecial[$tKind];

						logBariaAttack($id, $name, $tName, "($sx, $sy)");
						# 대상의 괴수가 쓰러져 황무지가 됨
						$land->[$sx][$sy] = $HlandWaste;
						$landValue->[$sx][$sy] = 1;
					}
				}
			}

		} elsif($landKind == $HlandNewtown) {
			# 뉴타운계
			my($townCount) = countAround($land, $x, $y, 19, @Htowns);

			$land->[$x][$y] = $HlandBigtown if(($townCount> 17) && (random(1000) < 3) && ($lv> 295));

			if($addpop < 0) {
				# 부족
				$lv -= (random(-$addpop) + 1);
				if($lv <= 0) {
					# 평지로 되돌리기
					$land->[$x][$y] = $HlandPlains;
					$landValue->[$x][$y] = 0;
					logPopDecrease($id, $name, $lName, "평지", $reason, "($x, $y)");
					next;
				}
			} else {
				# 성장
				if($lv < 100) {
					$lv += random($addpop) + 1;
					if($lv> 100) {
						$lv = 100;
					}
				} else {
					# 도시가 되면 성장 지연이
					$lv += random($addpop2) + 1 if($addpop2);
				}
			}
			$lv = 300 if($lv> 300);
			$landValue->[$x][$y] = $lv;

		} elsif($landKind == $HlandBigtown) {
			# 현대 도시계
			my($monsterCount) = countAround($land, $x, $y, 7, $HlandMonster);
			if($monsterCount> 0) {
				$lv -= random(20)+10;
				$landValue->[$x][$y] = $lv;
				logMonsAttacks($id, $name, landName($landKind, $lv), "($x, $y)");
				if($lv <= 0) {
					# 평지로 되돌리기
					$land->[$x][$y] = $HlandWaste;
					$landValue->[$x][$y] = 0;
					logPopDecrease($id, $name, $lName, "황무지", "괴수 공격", "($x, $y)");
					next;
				}
			}


			my($townCount) = countAround($land, $x, $y, 19, @Htowns);
			my($houseCount) = countAround($land, $x, $y, 7, $HlandHouse);
			if(($island->{'shu'} == 0) && ($houseCount == 1) &&
				($townCount> 16) && (random(1000) < 300)) {
				$land->[$x][$y] = $HlandShuto;
				my($onm);
				$onm = $island->{'onm'};
				$island->{'shutomessage'} = "$onm 시티";
				logShuto($id, $name, landName($landKind, $lv), "$onm 시티", "($x, $y)");
				$island->{'shu'}++;
			}
			if($addpop < 0) {
				# 부족
				$lv -= (random(-$addpop) + 1);
				if($lv <= 0) {
					# 평지로 되돌리기
					$land->[$x][$y] = $HlandPlains;
					$landValue->[$x][$y] = 0;
					logPopDecrease($id, $name, $lName, "평지", $reason, "($x, $y)");
					next;
				}
			} else {
				# 성장
				if($lv < 200) {
					$lv += random($addpop) + 1;
					$lv = 200 if($lv> 200);
				} else {
					# 도시가 되면 성장 지연이
					$lv += random($addpop2) + 1 if($addpop2);
				}
			}
			$lv = 500 if($lv> 500);
			$landValue->[$x][$y] = $lv;

		} elsif($landKind == $HlandSeatown) {
			# 해저 신도시계
			my($townCount) = countAround($land, $x, $y, 19, @Htowns);
			my($houseCount) = countAround($land, $x, $y, 7, $HlandHouse);
			if(($island->{'shu'} == 0) && ($houseCount == 1) &&
				($townCount> 16) && (random(1000) < 300)) {
				$land->[$x][$y] = $HlandUmishuto;
				my($onm);
				$onm = $island->{'onm'};
				$island->{'shutomessage'} = "$onm 시티";
				logShuto($id, $name, landName($landKind, $lv), "$onm 시티", "($x, $y)");
				$island->{'shu'}++;
			}
			if($addpop < 0) {
				# 부족
				$lv -= (random(-$addpop) + 1);
				if($lv <= 0) {
					# 평지로 되돌리기
					$land->[$x][$y] = $HlandSea;
					$landValue->[$x][$y] = 0;
					logPopDecrease($id, $name, $lName, "바다", $reason, "($x, $y)");
					next;
				}
			} else {
				# 성장
				if($lv < 250) {
					$lv += random($addpop) + 1;
					$lv = 250 if($lv> 250);
				} else {
					# 도시가 되면 성장 지연이
					$lv += random($addpop2) + 1 if($addpop2);
				}
			}
			$lv = 400 if($lv> 400);
			$landValue->[$x][$y] = $lv;

		} elsif($landKind == $HlandBettown) {

			my($monsterCount) = countAround($land, $x, $y, 7, $HlandMonster);
			if($monsterCount> 0) {
				$lv -= random(20)+10;
				$landValue->[$x][$y] = $lv;
				logMonsAttacks($id, $name, landName($landKind, $lv), "($x, $y)");
				if($lv <= 0) {
					# 평지로 되돌리기
					$land->[$x][$y] = $HlandWaste;
					$landValue->[$x][$y] = 0;
					logPopDecrease($id, $name, $lName, "황무지", "괴수 공격", "($x, $y)");
					next;
				}
			}

			my($shutoCount) = countAround($land, $x, $y, 7, $HlandShuto, $HlandUmishuto);
			my($betCount) = countAround($land, $x, $y, 7, $HlandBettown);

			if($addpop < 0) {
				# 부족
				$lv -= (random(-$addpop) + 1);
				if($lv <= 0) {
					# 평지로 되돌리기
					$land->[$x][$y] = $HlandPlains;
					$landValue->[$x][$y] = 0;
					logPopDecrease($id, $name, $lName, "평지", $reason, "($x, $y)");
					next;
				}
			} else {
				# 성장
				if(($island->{'shu'}> 0) &&
					(($shutoCount> 0) || ($betCount> 1))) {
					if($lv < 1000) {
						$lv += random($addpop) + 1;
						if($lv> 1000) {
							$lv = 1000;
						}
					} else {
						# 도시가 되면 성장 지연이
						if($addpop2> 0) {
							$lv += random($addpop2) + 1;
						}
					}

				}
			}
			if($lv> 2000) {
				$lv = 2000;
			}
			$landValue->[$x][$y] = $lv;

		} elsif(($landKind == $HlandShuto) || ($landKind == $HlandUmishuto)) {
			# 수도계
			my($monsterCount) = countAround($land, $x, $y, 7, $HlandMonster);
			if($monsterCount> 0) {
				$lv -= random(100)+200;
				$landValue->[$x][$y] = $lv;
				my $point = ($landKind == $HlandUmishuto) ? '(?, ?)' : "($x, $y)";
				logMonsAttacks($id, $name, landName($landKind, $lv), $point);
				if($lv <= 0) {
					if($landKind == $HlandUmishuto) {
						# 바다로 되돌림
						$land->[$x][$y] = $HlandSea;
					} elsif($landKind == $HlandShuto) {
						# 평지로 되돌리기
						$land->[$x][$y] = $HlandPlains;
					}
					$landValue->[$x][$y] = 0;
					my($tName) = landName($land->[$x][$y], $landValue->[$x][$y]);
					logPopDecrease($id, $name, $lName, $tName, "괴수 공격", "($x, $y)");
					next;
				}
			}

			if($addpop < 0) {
				# 부족
				$lv -= (random(-$addpop) + 1);
				if($lv <= 0) {
					if($landKind == $HlandUmishuto) {
						# 바다로 되돌림
						$land->[$x][$y] = $HlandSea;
					} elsif($landKind == $HlandShuto) {
						# 평지로 되돌리기
						$land->[$x][$y] = $HlandPlains;
					}
					$landValue->[$x][$y] = 0;
					my($tName) = landName($land->[$x][$y], $landValue->[$x][$y]);
					logPopDecrease($id, $name, $lName, $tName, $reason, "($x, $y)");
					next;
				}
			} else {
				# 성장
				if($lv < 750) {
					$lv += random($addpop) + 1;
					if($lv> 750) {
						$lv = 750;
					}
				} else {
					# 도시가 되면 성장 지연이
					if($addpop2> 0) {
						$lv += random($addpop2) + 1;
					}
				}
			}
			if($lv> 4000) {
				$lv = 4000;
			}
			$landValue->[$x][$y] = $lv;

		} elsif(($landKind == $HlandRizort) || ($landKind == $HlandBigRizort)) {
			# 리조트계
			# 관광은 좋습니다
			if((($landKind == $HlandRizort) && ($lv < 400) && (random(100) < 25)) ||
				(($landKind == $HlandBigRizort) && ($lv < 1000) && (random(100) < 30))) {
				my(@order) = randomArray($HislandNumber);
				my($migrate);

				# 관광선을 탐색
				my($tIsland);
				my($n) = min($HislandNumber, 5);
				my($i);
				for($i = 0; $i < $n; $i++) { # 5섬까지조사하기
					$tIsland = $Hislands[$order[$i]];

					# 인구의 많음이 섬에 관광하다
					if ($island->{'pop'} < $tIsland->{'pop'}) {
						my($seaCount) = countAround($land, $x, $y, 19, $HlandSea);
						my($forestCount) = countAround($land, $x, $y, 19, $HlandForest, $HlandMountain);
						my($parkCount) = countAround($land, $x, $y, 19, $HlandPark, $HlandKyujo, $HlandKyujokai);
						my($umiamuCount) = countAround($land, $x, $y, 19, $HlandUmiamu);
						my($sunahamaCount) = countAround($land, $x, $y, 19, $HlandSunahama);
						my($rizortCount) = (countAround($land, $x, $y, 19, $HlandRizort, $HlandBigRizort));
						$landKind = $land->[$x][$y];
						$lv = $landValue->[$x][$y];
						$migrate = $seaCount*2 + $forestCount*3 + $parkCount*4 + $umiamuCount*7 + $sunahamaCount*6 + $rizortCount*5;
						$lv += $migrate;
						logKankouMigrate($id, $tIsland->{'id'}, $name, landName($landKind, $lv), islandName($tIsland), "($x, $y)", $migrate);
					}
					last if ($employed <= 0);
				}

				$island->{'eisei2'} += $migrate;
				$island->{'pop'} += $migrate;
				$tIsland->{'pop'} -= $migrate;

				# 관광객이 되어 빠져나간 만큼 인구 감소
				my($tLand) = $tIsland->{'land'};
				my($tLandValue) = $tIsland->{'landValue'};
				my($employed) = $migrate;
				my($x, $y, $landKind, $lv);
				foreach $i (0..$pointNumber) {
					$x = $Hrpx[$i];
					$y = $Hrpy[$i];
					$landKind = $tLand->[$x][$y];
					$lv = $tLandValue->[$x][$y];

					if(($lv> 1) && (($landKind == $HlandTown) ||
						($landKind == $HlandMinato) ||
						($landKind == $HlandProcity) ||
						($landKind == $HlandFrocity) ||
						($landKind == $HlandNewtown) ||
						($landKind == $HlandBigtown) ||
						($landKind == $HlandBettown) ||
						($landKind == $HlandSeatown) ||
						($landKind == $HlandRizort) ||
						($landKind == $HlandBigRizort) ||
						($landKind == $HlandShuto) ||
						($landKind == $HlandUmishuto) ||
						($landKind == $HlandOnsen) ||
						($landKind == $HlandSeacity))) {
						# 읍
						$n = min($lv - 1, $employed);
						$tLandValue->[$x][$y] -= $n;
						$employed -= $n;
					}
				}
			}

			if($addpop < 0) {
				# 부족
				$lv -= (random(-$addpop) + 1);
				if($lv <= 0) {
					# 평지로 되돌리기
					$land->[$x][$y] = $HlandPlains;
					$landValue->[$x][$y] = 0;
					next;
				}
			} else {
				# 성장
				if($lv < 10) {
					$lv += random($addpop) + 1;
					if($lv> 10) {
						$lv = 10;
					}
				} else {
					if($addpop2> 0) {
						$lv += random($addpop2) + 1;
					}
				}
			}

			if($landKind == $HlandRizort) {
				$lv = 400 if($lv> 400);
				my $value = $lv+$island->{'eis1'}+$island->{'eis2'}+$island->{'eis3'}+$island->{'eis5'}+int($island->{'fore'}/10)+int($island->{'rena'}/10)-$island->{'monsterlive'}*100;
				$island->{'money'} += $value if ($value> 0);
			} else {
				$lv = 1000 if($lv> 1000);
				if(countAround($land, $x, $y, 7, $HlandMonster)> 0) {
					$lv -= random(20)+10;
					logMonsAttacks($id, $name, landName($landKind, $lv), "($x, $y)");
					if($lv <= 0) {
						# 평지로 되돌리기
						$land->[$x][$y] = $HlandWaste;
						$lv = 0;
						logPopDecrease($id, $name, $lName, "황무지", "괴수 공격", "($x, $y)");
					}
				}
			}
			$landValue->[$x][$y] = $lv;

		} elsif($landKind == $HlandOnsen) {
			# 온천계
			if($addpop < 0) {
				# 부족
				$lv -= (random(-$addpop) + 1);
				if($lv <= 0) {
					# 산으로 되돌림
					$land->[$x][$y] = $HlandMountain;
					$landValue->[$x][$y] = 0;
					next;
				}
			} else {
				# 성장
				if($lv < 50) {
					$lv += random($addpop) + 1;
					if($lv> 50) {
						$lv = 50;
					}
				} else {
					# 도시가 되면 성장 지연이
					if($addpop2> 0) {
						$lv += random($addpop2) + 1;
					}
				}
			}
			if($lv> 100) {
				$lv = 100;
			}
			$landValue->[$x][$y] = $lv;

			my($nt) = countAround($land, $x, $y, 19, @Htowns);
			my($value) = random($nt * 20 + $lv * 5 + int($island->{'pop'} / 20)) + random(100) + 100;
			if ($value> 0) {
				$island->{'money'} += $value;

				# 수입 로그
				my($str) = "$value$HunitMoney";
				logOilMoney($id, $name, landName($landKind, $lv), "($x, $y)", $str, "수익");
			}

			# 온천고갈판정
			if(!$HnoDisFlag && random(1000) < $HonsenRatio) {
				# 고갈
				logDamageAny($id, $name, landName($landKind, $lv), "($x, $y)", "고갈된 것 같습니다.");
				$land->[$x][$y] = $HlandMountain;
				$landValue->[$x][$y] = 0;
			}

		} elsif(($landKind == $HlandSea) && ($lv == 1)) {
			# 얕은 바다
			if(random(100) < 5) {
				$land->[$x][$y] = $HlandSunahama;
				$landValue->[$x][$y] = 0;
			}
			if(random(100) < 1) {
				$land->[$x][$y] = $HlandIce;
				$landValue->[$x][$y] = 0;
			}

		} elsif($landKind == $HlandSunahama) {
			# 해변
			if(random(100) < 30) {
				$land->[$x][$y] = $HlandSea;
				$landValue->[$x][$y] = 1;
			}

		} elsif($landKind == $HlandIce) {
			# 빙하
			my($lv) = $landValue->[$x][$y];
			if($lv> 0) {
				my $value = $lv * 25 + random(501);
				$island->{'money'} += $value;
				# 수입 로그
				logOilMoney($id, $name, landName($landKind, $lv), "($x, $y)", "$value$HunitMoney", "수익");
			}
			if(random(100) < 10) {
				$land->[$x][$y] = $HlandSea;
				$landValue->[$x][$y] = 1;
			}

		} elsif($landKind == $HlandPlains) {
			# 평지
			my $tflag = ($id> 100) ? 1 : countGrow($land, $landValue, $x, $y);
			if(!random(5) && $tflag) {
				# 주변에 농장, 읍이 있다면, 여기도 마을이 됨
				$land->[$x][$y] = $HlandTown;
				$landValue->[$x][$y] = 1;
				if(random(1000) < $island->{'nto'}*3) {
					$land->[$x][$y] = $HlandNewtown;
					$landValue->[$x][$y] = 1;
				}
			}
		} elsif($landKind == $HlandWaste) {
			# 황무지(BattleField)
			if(!random(3) && ($id> 100)) {
				if(!$landValue->[$x][$y]) {
					$land->[$x][$y] = $HlandPlains;
				} else {
					$landValue->[$x][$y]--;
				}
			}
		} elsif($landKind == $HlandForest) {
			# 숲
			$landValue->[$x][$y]++ if($lv < 200); # 나무가 늘어남
		} elsif(($landKind == $HlandFarmchi) ||
			($landKind == $HlandFarmpic) ||
			($landKind == $HlandFarmcow)){
			# 양계장, 양돈장, 목장
			my($FarmCount) = countAround($land, $x, $y, 7, $HlandFarm);
			my(@rflag);
			if($landKind == $HlandFarmchi) {
				@rflag = (1, 8 + $FarmCount * 2, 5);
			} elsif($landKind == $HlandFarmpic){
				@rflag = (2, 4 + $FarmCount * 2, 3);
			} else {
				@rflag = (3, 4 + $FarmCount, 1);
			}
			$value = $lv * $rflag[0];
			$island->{'food'} += $value;
			$lv += random($rflag[1]) + $rflag[2];
			$lv = 4000 if($lv> 4000);
			$landValue->[$x][$y] = $lv;

		} elsif($landKind == $HlandHouse) {
			# 섬주의 가
			my $hlv;
			foreach (0..9) {
				$hlv = 9 - $_;
				last if($island->{'pts'}> $HouseLevel[$hlv]);
			}
			$landValue->[$x][$y] = $hlv;
			$zeikin = int($island->{'pop'} * ($hlv + 1) * $island->{'eisei1'} / 100);
			if($zeikin> 10000) {
				$island->{'money'} += $zeikin if($HislandTurn % 5 == 0);
			} elsif($zeikin> 5000) {
				$island->{'money'} += $zeikin if($HislandTurn % 2 == 0);
			} else {
				$island->{'money'} += $zeikin;
			}

		} elsif($landKind == $HlandDefence) {
			if($lv == 1) {
				# 방위 시설 자폭
				my($lName) = landName($landKind, $lv);
				logBombFire($id, $name, $lName, "($x, $y)");

				# 광역 피해 루틴
				wideDamage($id, $name, $land, $landValue, $x, $y);
			}
		} elsif($landKind == $HlandOil) {
			# 해저 유전
			my($value, $str, $lName);
			$lName = landName($landKind, $lv);
			$value = $HoilMoney + random(1001);
			$island->{'money'} += $value;

			$island->{'oilincome'} += $value if($HlogOmit1);
			# 수입 로그
			logOilMoney($id, $name, $lName, "($x, $y)", "$value$HunitMoney", "수익") if(!$HlogOmit1);

			# 고갈판정
			if(!$HnoDisFlag && random(1000) < $HoilRatio) {
				# 고갈
				logDamageAny($id, $name, $lName, "($x, $y)", "고갈된 것 같습니다.");
				$land->[$x][$y] = $HlandSea;
				$landValue->[$x][$y] = 0;
			}

		} elsif($landKind == $HlandSeki) {
			# 관문
			if(random(1000) < 7) {
				my $lName = landName($landKind, $lv);
				my $value = $HoilMoney + random(1001);
				$island->{'money'} += $value;

				# 수입 로그
				logOilMoney($id, $name, $lName, "($x, $y)", "$value$HunitMoney", "관계세수익");
			}

		} elsif($landKind == $HlandGold) {
			# 금광산
			my $lName = landName($landKind, $lv);
			my $value = $lv * 25 + random(501);
			$island->{'money'} += $value;

			# 수입 로그
			logOilMoney($id, $name, $lName, "($x, $y)", "$value$HunitMoney", "수익");

			# 고갈판정
			if(random(100) < 7) {
				# 고갈
				logGoldEnd($id, $name, $lName, "($x, $y)");
				$land->[$x][$y] = $HlandMountain;
			}

		} elsif(($landKind == $HlandPark) || ($landKind == $HlandKyujo) || ($landKind == $HlandUmiamu)) {
			# 놀이공원, 야구장, 해상 시설
			my($value, $event, $closed) = (0, 0, 0);
			if($landKind == $HlandPark) {
				# 놀이공원
				$event = 7;
				$closed = 2;
				unless($island->{'par'}> 5) {
					my($nv) = (countAround($land, $x, $y, 7, $HlandPark, $HlandKyujo, $HlandUmiamu));
					my($nx) = 3 * ($nv + 10) / 10;
					$value = int(int($island->{'pop'} / 50) * $nx * $Hmoney2Incom[$Hmonth]/100);
				}

			} elsif($landKind == $HlandKyujo) {
				# 야구장
				$closed = 1;
				unless(($island->{'kyu'}> 1) || ($island->{'amu'}> 1)) {
					my($nt) = (countAround($land, $x, $y, 19, @Htowns) - 6);
					my($np) = ( 1 + 2 * countAround($land, $x, $y, 19, $HlandPark));
					my($na) = ( 1 + 3 * countAround($land, $x, $y, 19, $HlandUmiamu));
					my($nu) = ( 10 + random(10));
					$value = int(($nt * $np * $na * $nu + int($island->{'pop'} / 25)) * $Hmoney2Incom[$Hmonth]/100);
				}

				if(random(100) < 3) {
					my($value, $str);
					$value = 500+ random(500);
					$island->{'money'} += $value;
					$str = "$value$HunitMoney";
					# 수입 로그
					logYusho($id, $name, landName($landKind, $lv), "($x, $y)", $str);
				}

			} elsif($landKind == $HlandUmiamu) {
				# 해상 시설
				unless(($island->{'kyu'}> 1) || ($island->{'amu'}> 1)) {
					my($nt) = (countAround($land, $x, $y, 19, @Htowns) - 3);
					my($np) = ( 1 + 3 * countAround($land, $x, $y, 19, $HlandPark));
					my($na) = ( 1 + 4 * countAround($land, $x, $y, 19, $HlandKyujo));
					my($nqk) = ($HeasyMode ? 1 + 4 * countAround($land, $x, $y, 19, $HlandKyujokai) : 1);
					my($nu) = ( 5 + random(5));
					$value = int(($nt * $np * $na * $nqk * $nu + int($island->{'pop'} / 25)+ random(200)) * $Hmoney2Incom[$Hmonth]/100);
				}

			}

			if($value> 0) {
				$island->{'money'} += $value;
				# 수입 로그
				if($HlogOmit1 && $event) {
					$island->{'parkincome'} += $value;
				} else {
					logOilMoney($id, $name, landName($landKind, $lv), "($x, $y)", "$value$HunitMoney", "수익");
				}
			}
			# 이벤트판정
			if(random(100) < (10 - $event)) { # 매 턴 10% 확률로 이벤트가 발생하다
				$value = int($island->{'pop'} / 50 * 10 * $Hmoney2Incom[$Hmonth]/100); # 인구5천 명마다1000톤의 식량소비
				$island->{'food'} -= $value;
				$str = "$value$HunitFood";
				logParkEvent($id, $name, landName($landKind, $lv), "($x, $y)", $str) if($value);
			}
			# 노후화판정
			if(random(100) < $closed) {
				# 시설이 노후화했기 때문에 폐원
				logDamageAny($id, $name, landName($landKind, $lv), "($x, $y)", "시설이 노후화했기 때문에 철거되었습니다.");
				$land->[$x][$y] = $HlandPlains;
				$landValue->[$x][$y] = 0;
			}

		} elsif($landKind == $HlandKyujokai) {
			# 야구장개정
			# 이벤트판정
			if(random(100) < 10) { # 매 턴 30% 확률로 이벤트가 발생하다
				# 야구장의 이벤트
				$value = int($island->{'pop'} / 50) * 10; # 인구5천 명마다1000톤의 식량소비
				$island->{'food'} -= $value;
				$str = "$value$HunitFood";
				logParkEvent($id, $name, landName($landKind, $lv), "($x, $y)", $str) if ($value> 0);
			}
			next if($HflagKai);
			$HflagKai = 1;
			unless(($island->{'kyu'}> 1) || ($island->{'amu'}> 1)) {
				my($nt) = (countAround($land, $x, $y, 19, @Htowns) - 6);
				my($ns) = ( 1 + 2 * countAround($land, $x, $y, 19, $HlandPark));
				my($nr) = ( 1 + 3 * countAround($land, $x, $y, 19, $HlandUmiamu));
				my($nu) = ( 10 + random(10));
				my($value);
				$value = ($nt * $nu * $ns * $nr + int($island->{'pop'} / 25));
				if ($value> 0) {
					$island->{'money'} += $value;
					# 수입 로그
					logOilMoney($id, $name, landName($landKind, $lv), "($x, $y)", "$value$HunitMoney", "수익");
				}
			}

			# HakoniwaCup
			my($sto, $std, $stk, $stwin, $stdrow, $stlose, $stwint, $stdrowt, $stloset, $styusho, $stshoka) = split(/,/, $island->{'eisei4'});
			my $yosengameendm = 0;
			my $hcgameseigen = 1;
			my $turn = $HislandTurn % 100;
			my $otry = 3;
			my($turn1, $goal, $tgoal);
			if((0 < $turn) && ($turn < 41)) {
				$turn1 = int(($turn + 9) / 10);
				$hcgameseigen = 3 unless($HislandNumber < 21);
				$otry = 5;
			} elsif((41 < $turn) && ($turn < 47)) {
				$turn1 = 6;
			} elsif((46 < $turn) && ($turn < 50)) {
				$turn1 = 7;
			} elsif((49 < $turn) && ($turn < 52)) {
				$turn1 = 8;
			} elsif($turn == 0) {
				$stwin = 0;
				$stdrow = 0;
				$stlose = 0;
				$stshoka = 1;
				$Hstsanka++;
				$island->{'eisei4'} = "$sto,$std,$stk,$stwin,$stdrow,$stlose,$stwint,$stdrowt,$stloset,$styusho,$stshoka";
				if ($Hstsanka == 1) {
					$island->{'stsankahantei'}++;
				}
			}

			if(!$turn1) {
				if(($stshoka == 10) || ($stshoka == 11)) {
					my($stup);
					$stup = random(3);
					if($stup == 0) {
						$sto++;
					} elsif($stup == 1) {
						$std++;
					} else {
						$stk++;
					}
				}
				next;
			}
			if(($stshoka == $turn1) && ($Hyosengameend < $hcgameseigen)) {
				my($tIsland);
				my($i);
				my(@order) = randomArray($HislandNumber);
				foreach $i (0..$islandNumber) {
					last if($yosengameendm);
					$tIsland = $Hislands[$order[$i]];
					my($tSto, $tStd, $tStk, $tStwin, $tStdrow, $tStlose, $tStwint, $tStdrowt, $tStloset, $tStyusho, $tStshoka) = split(/,/, $tIsland->{'eisei4'});
					next if ($island->{'id'} == $tIsland->{'id'});
					next if(($tStshoka != $turn1) || ($Hyosengameend>= $hcgameseigen));

					my($uphey, $tuphey, $uppoint, $tuppoint, $value, $str, $str1, $str2);
					$goal=0;
					$tgoal=0;
					foreach (1..$otry) {
						if((random($sto)> random($tStd)) &&
							(random($sto)> random($tStk))) {
							$goal++;
						}
						next if($_> 3);
						if((random($tSto)> random($std)) &&
							(random($tSto)> random($stk))) {
							$tgoal++;
						}
					}
					if(
					($turn1> 5) &&
					($goal == $tgoal)) {
						if(random(100) < 60) {
							$goal++;
						} else {
							$tgoal++;
						}
					}
					$uphey = int(($sto + $std + $stk) / 3);
					$tuphey = int(($tSto + $tStd + $tStk) / 3);
					$uppoint = int(($tuphey - $uphey) / 2) + 5;
					$tuppoint = int(($uphey - $tuphey) / 2) + 5;
					if($turn1 == 8) {
						$str1 = '결승전';
						$str2 = '우승';
						$uppoint = 50;
						$tuppoint = 50;
					} elsif($turn1 == 7) {
						$str1 = '준결승전';
						$str2 = '결승진출';
						$uppoint = 30;
						$tuppoint = 30;
					} elsif($turn1 == 6) {
						$str1 = '준준결승전';
						$str2 = '준결승진출';
						$uppoint = 30;
						$tuppoint = 30;
					} else {
						$str1 = "예선 제${turn1}전쟁";
						$str2 = '승리';
					}
					my($stup) = random(3);
					$Hyosengameend++;
					$yosengameendm++;
					$stshoka++;
					$tStshoka++;
					if($goal> $tgoal) {
						$stwin++;
						$stwint++;
						$styusho++ if($turn1 == 8);
						$tStlose++;
						$tStloset++;
						$tStshoka = $turn1 + 6 if($turn1> 5);
						$value = (($stwin * 3 + $stdrow) * 1000);
						$value *= 2 if($turn1 == 8);
						$island->{'money'} += $value;
						$str = "$value$HunitMoney";
						logHCwin($id, $name, $str2, $str);
						if($stup == 0) {
							$tSto += $tuppoint;
							$tStd += $tuppoint if($turn1 < 5);
						} elsif($stup == 1) {
							$tStd += $tuppoint;
							$tStk += $tuppoint if($turn1 < 5);
						} else {
							$tStk += $tuppoint;
							$tSto += $tuppoint if($turn1 < 5);
						}
					} elsif($goal < $tgoal) {
						$tStwin++;
						$tStwint++;
						$tStyusho++ if($turn1 == 8);
						$stlose++;
						$stloset++;
						$stshoka = $turn1 + 6 if($turn1> 5);
						my($value);
						$value = (($tStwin * 3 + $tStdrow) * 1000);
						$value *= 2 if($turn1 == 8);
						$tIsland->{'money'} += $value;
						$str = "$value$HunitMoney";
						logHCwin($tIsland->{'id'}, islandName($tIsland), $str2, $str);
						if($stup == 0) {
							$sto += $uppoint;
							$std += $uppoint if($turn1 < 5);
						} elsif($stup == 1) {
							$std += $uppoint;
							$stk += $uppoint if($turn1 < 5);
						} else {
							$stk += $uppoint;
							$sto += $uppoint if($turn1 < 5);
						}
					} else {
						$stdrow++;
						$stdrowt++;
						$tStdrow++;
						$tStdrowt++;
					}
					logHCgame($id, $tIsland->{'id'}, $name, islandName($tIsland), landName($landKind, $lv), "${str1}", $goal, $tgoal);
					if($turn1 == 8) {
						if($goal> $tgoal) {
							logHCwintop($id, $name, int($HislandTurn / 100) * 100);
						} elsif($goal < $tgoal) {
							logHCwintop($tIsland->{'id'}, islandName($tIsland), int($HislandTurn / 100) * 100);
						}
					}
					$tIsland->{'eisei4'} = "$tSto,$tStd,$tStk,$tStwin,$tStdrow,$tStlose,$tStwint,$tStdrowt,$tStloset,$tStyusho,$tStshoka";
				}
			}

			if((($turn == 10) && ($stshoka == 1)) ||
				(($turn == 20) && ($stshoka == 2)) ||
				(($turn == 30) && ($stshoka == 3)) ||
				(($turn == 40) && ($stshoka == 4))) {
				logHCantiwin($id, $name, "예선 제${stshoka}전쟁");
				$stwin++;
				$stwint++;
				$stshoka++;
			}
			if(($turn1 == 6) && ($stshoka < 6)) {
				$stshoka = 11;
			}
			if(($turn == 46) && ($stshoka == 6)) {
				$stwin++;
				$stwint++;
				$stshoka++;
				logHCantiwin($id, $name, "준준결승전");
			}
			if(($turn == 49) && ($stshoka == 7)) {
				$stwin++;
				$stwint++;
				$stshoka++;
				logHCantiwin($id, $name, "준결승전");
			}
			if(($turn == 51) && ($stshoka == 8)) {
				$stwin++;
				$stwint++;
				$stshoka++;
				$styusho++;
				logHCantiwin($id, $name, "결승전");
				my($value);
				$value = (($stwin * 3 + $stdrow) * 1000)*2;
				$island->{'money'} += $value;
				$str = "$value$HunitMoney";
				logHCwin($id, $name, "일단의 우승", $str);
				$hcturn = int($HislandTurn/100)*100;
				logHCwintop($id, $name, $hcturn);
			}

			if(($turn == 52) && ($stshoka != 9)) {
				$stshoka = 10;
			}
			if(($stshoka == 10) || ($stshoka == 11)) {
				my($stup);
				$stup = random(3);
				if($stup == 0) {
					$sto++;
				} elsif($stup == 1) {
					$std++;
				} else {
					$stk++;
				}
			}
			$island->{'eisei4'} = "$sto,$std,$stk,$stwin,$stdrow,$stlose,$stwint,$stdrowt,$stloset,$styusho,$stshoka";

		} elsif($landKind == $HlandRottenSea) {
			# 오염된 바다
			my($i, $sx, $sy, $kind, $lv);
			for($i = 1; $i < 7; $i++) {
				$sx = $x + $ax[$i];
				$sy = $y + $ay[$i];

				# 행 기준 위치 조정
				$sx-- if(!($sy % 2) && ($y % 2));
				# 범위 밖
				next if(($sx < 0) || ($sx> $islandSize) || ($sy < 0) || ($sy> $islandSize));

				my $sL = $land->[$sx][$sy];
				my $sLv = $landValue->[$sx][$sy];
				my $lName = landName($sL, $sLv);
				# 바다, 바다 기준, 해저 도시, 해저 신도시, 선박, 해상 시설, 유전, 양식장, 오염된 바다이외
				if(($sL != $HlandSea) &&
					($sL != $HlandSbase) &&
					($sL != $HlandIce) &&
					($sL != $HlandSeacity) &&
					($sL != $HlandSeatown) &&
					($sL != $HlandUmishuto) &&
					($sL != $HlandFune) &&
					($sL != $HlandFrocity) &&
					($sL != $HlandUmiamu) &&
					($sL != $HlandOil) &&
					($sL != $HlandNursery) &&
					($sL != $HlandHugeMonster) &&
					($sL != $HlandRottenSea)) {
					my($n) = countAround($land, $sx, $sy, 7, $HlandRottenSea);
					my($point) = "($sx, $sy)";
					if(($n>= 4) && (random(100) < 60)) {
						# 주변에오염된 바다가4칸이상있다면 60% 확률로 흡수함
						logDamageAny($id, $name, $lName, $point, "<B>오염된 바다</B>에빗나갔습니다.");
						$land->[$sx][$sy] = $HlandRottenSea;
						$landValue->[$sx][$sy] = 1;
					} elsif($n && (random(100) < 20)) {
						# 주변에오염된 바다가1칸이상있다면20% 확률로 흡수함
						logDamageAny($id, $name, $lName, $point, "<B>오염된 바다</B>에빗나갔습니다.");
						$land->[$sx][$sy] = $HlandRottenSea;
						$landValue->[$sx][$sy] = 1;
					}
				}
			}

		} elsif($landKind == $HlandShrine) {
			# 시간의 신전
			if($landValue->[$x][$y]) {
				# 서버 문제 등으로 데이터가 없어졌으면 값을 0으로
				unless(-e "${HdirName}/savedata.$id") {
					$landValue->[$x][$y]= 0 ;
					logSaveLoadVanish($id, $name);
				}
			}
			unless((countAround($land, $x, $y, 7, $HlandForest) == 6) &&
					(countAround($land, $x, $y, 19, $HlandSea) == 12)) {
				# 주변 1Hex가 모두 숲이고, 추가로 주변이 모두 바다(또는 얕은 바다)라는 조건이 깨짐
				unlink("${HdirName}/savedata.$id") if(-e "${HdirName}/savedata.$id");
				$land->[$x][$y] = $HlandMountain;
				$landValue->[$x][$y] = 0;
			}
		} elsif($landKind == $HlandCollege) {
			# 대학
			# 각 요소 꺼내기
			my($clv) = $landValue->[$x][$y];
			if(($clv == 99) && !$island->{'c28'}) {
				$land->[$x][$y] = $HlandPlains;
				$landValue->[$x][$y] = 0;
				logMstakeoff($id, $name, landName($landKind, $lv),"($x, $y)");
			}
			my $monsno = $island->{'monsterlive'};
			next if(!$monsno);

			my $take = 0;
			my($i, $sx, $sy, $monsArray, $monspnt);
			$monsArray = $island->{'monspnt'};

			if($clv == 4) {
				for($i = 0; $i < $monsno; $i++){
					$monspnt = $monsArray->[$i];
					($sx, $sy) = ($monspnt->{x}, $monspnt->{y});
					if($land->[$sx][$sy] == $HlandMonster) {
						# 대상이 되는 괴수각 요소 꺼내기
						my($tKind, $tName, $tHp) = monsterSpec($landValue->[$sx][$sy]);
						my($tlv) = $landValue->[$sx][$sy];
						my($tspecial) = $HmonsterSpecial[$tKind];
						if($tKind == 28) {
						} else {
							my($ssx, $ssy, $i, $landKind, $landName, $lv, $point);
							for($i = 1; $i < 7; $i++) {
								$ssx = $sx + $ax[$i];
								$ssy = $sy + $ay[$i];
								# 행 기준 위치 조정
								$ssx-- if(!($ssy % 2) && ($sy % 2));
								# 범위 밖 판정
								next if(($ssx < 0) || ($ssx> $islandSize) || ($ssy < 0) || ($ssy> $islandSize));

								if(!$take && ($land->[$ssx][$ssy] == $HlandWaste) && !$island->{'c28'}) {
									my($mshp, $msap, $msdp, $mssp, $mswin, $msexe, $tet) = split(/,/, $island->{'eisei5'});
									my $kind = 28;
									$landValue->[$ssx][$ssy] = ($kind << 4) + $mshp;
									$land->[$ssx][$ssy] = $HlandMonster;
									logMstakeon($id, $name, "생물 대학의 관광 이노라","($x, $y)");

									$landValue->[$x][$y] = 99;
									$take++;
									$island->{'co99'}++;
									$island->{'monsterlive'}++;
									last;
								}
							}
						}
					}
					last if($take);
				}
			} elsif($clv == 98) {
				for($i = 0; $i < $monsno; $i++){
					$monspnt = $monsArray->[$i];
					($sx, $sy) = ($monspnt->{x}, $monspnt->{y});
					if($land->[$sx][$sy] == $HlandMonster) {
						# 대상이 되는 괴수각 요소 꺼내기
						my($tKind, $tName, $tHp) = monsterSpec($landValue->[$sx][$sy]);
						my($tlv) = $landValue->[$sx][$sy];
						my($tspecial) = $HmonsterSpecial[$tKind];
						if($tKind == 30) {
						} else {
							my($ssx, $ssy, $i, $landKind, $landName, $lv, $point);
							for($i = 1; $i < 7; $i++) {
								$ssx = $sx + $ax[$i];
								$ssy = $sy + $ay[$i];
								# 행 기준 위치 조정
								$ssx-- if(!($ssy % 2) && ($sy % 2));
								# 범위 밖 판정
								next if(($ssx < 0) || ($ssx> $islandSize) || ($ssy < 0) || ($ssy> $islandSize));

								if(!$take && ($land->[$ssx][$ssy] == $HlandWaste) && !$island->{'c28'}) {
									my($mshp, $msap, $msdp, $mssp, $mswin, $msexe, $tet) = split(/,/, $island->{'eisei5'});
									my $kind = 30;
									$landValue->[$ssx][$ssy] = ($kind << 4) + $mshp;
									$land->[$ssx][$ssy] = $HlandMonster;
									logMstakeon($id, $name, "초신 수테트라","($x, $y)");

									$landValue->[$x][$y] = 99;
									$take++;
									$island->{'co99'}++;
									$island->{'monsterlive'}++;
									last;
								}
							}
						}
					}
					last if($take);
				}
			}
		} elsif($landKind == $HlandMonument) {
			# 기념비
			# 각 요소 꺼내기
			my($molv) = $landValue->[$x][$y];
			my($lName) = landName($landKind, $lv);

			if(($molv == 0) || ($molv == 10) || ($molv == 15) || ($molv == 16)) {
				if(random(100) < 5) {
					# 간주 게
					my $value = 1+ random(49);
					$island->{'money'} += $value;
					logMiyage($id, $name, $lName, "($x, $y)", "$value$HunitMoney") if($value);
				}
			} elsif($molv == 1) {
				if(random(100) < 1) {
					# 수확
					my $value = int($island->{'pop'} / 100) * 10+ random(11); # 인구1만 명마다1000톤 수확
					$island->{'food'} += $value;
					logParkEventt($id, $name, $lName, "($x, $y)", "$value$HunitFood") if($value);
				}
			} elsif(($molv == 80) || ($molv == 81) || ($molv == 82) || ($molv == 83)){
				# 알부활
				$molv -= 80;
				my @rflag = (5, 3, 3, 5);
				my @mflag = ([5, 25, 35, 25], [3, 20, 40, 15], [3, 30, 40, 30], [10, 25, 30, 30]);
				if(random(100) < $rflag[$molv]) {
					my ($i, $sx, $sy);
					for($i = 0; $i < 7; $i++) {
						$sx = $x + $ax[$i];
						$sy = $y + $ay[$i];
						# 행 기준 위치 조정
						$sx-- if(!($sy % 2) && ($y % 2));
						# 범위 밖
						next if(($sx < 0) || ($sx> $islandSize) || ($sy < 0) || ($sy> $islandSize));

						my $sLname = landName($land->[$sx][$sy], $landValue->[$sx][$sy]);
						my($mKind, $mName, $mHp);
						# 범위에 한분기
						if($i < 1) {
							# 중심 및 1헥스
							if(random(100) < $mflag[$molv][0]) {
								$mKind = 13; # 미카엘
							} elsif(random(100) < $mflag[$molv][1]) {
								$mKind = 29; # 테트라
							} elsif(random(100) < $mflag[$molv][2]) {
								$mKind = 14; # 스라레제
							} elsif(random(100) < $mflag[$molv][3]) {
								$mKind = 12; # 은네는 무
							} else {
								$mKind = 1; # 이노라(임의)
							}

							$mHp = $HmonsterBHP[$mKind] + random($HmonsterDHP[$mKind]);
							my $sLv = ($mKind << 4) + $mHp;
							$land->[$sx][$sy] = $HlandMonster;
							$landValue->[$sx][$sy] = $sLv;
							logEggBomb($id, $name, $sLname, $HmonsterName[$mKind], "($sx, $sy)");

						} else {
							# 2헥스
							unless(($landKind == $HlandSea) ||
								($landKind == $HlandOil) ||
								($landKind == $HlandMountain) ||
								($landKind == $HlandGold) ||
								($landKind == $HlandOnsen) ||
								($landKind == $HlandSeacity) ||
								($landKind == $HlandUmishuto) ||
								($landKind == $HlandSeatown) ||
								($landKind == $HlandUmiamu) ||
								($landKind == $HlandFune) ||
								($landKind == $HlandFrocity) ||
								($landKind == $HlandSbase)) {
								logEggDamage($id, $name, $sLname, $point);
								$land->[$sx][$sy] = $HlandSea;
								$landValue->[$sx][$sy] = 0;
							}
						}
					}
				}

			} elsif($molv == 84) {
				# 고대 유적
				if(random(100) < 75) {
					# 수확
					my($nt) = countAround($land, $x, $y, 19, @Htowns);
					my $value = random($nt * 20 + $lv * 5 + int($island->{'pop'} / 20)) + random(100) + 100;
					if ($value> 0) {
						$island->{'money'} += $value;
						# 수입 로그
						logOilMoney($id, $name, $lName, "($x, $y)", "$value$HunitMoney", "수익");
					}
				}

				if(($island->{'shr'} < 1) &&
					(countAround($land, $x, $y, 7, $HlandForest) == 6) &&
					(countAround($land, $x, $y, 19, $HlandSea) == 12)) {
					# 주변 1Hex가 모두 숲이고, 추가로 주변이 모두 바다(또는 얕은 바다)이면 '시간의 신전'이 됨
					$land->[$x][$y] = $HlandShrine;
					$landValue->[$x][$y] = 0;
				}
			} elsif($molv == 93) {
				# 행운
				my $value = $HoilMoney+ random(500);
				$island->{'money'} += $value;
				logMiyage($id, $name, $lName, "($x, $y)", "$value$HunitMoney") if($value);

				$value = int($island->{'pop'} / 20) + random(11); # 인구5천 명마다1000톤의 식량소비
				$island->{'food'} += $value;
				logParkEventt($id, $name, $lName, "($x, $y)", "$value$HunitFood") if($value);
			}

		} elsif($landKind == $HlandFrocity) {

			if($addpop < 0) {
				# 부족
				$lv -= (random(-$addpop) + 1);
				if($lv <= 0) {
					# 평지로 되돌리기
					$land->[$x][$y] = $HlandPlains;
					$landValue->[$x][$y] = 0;
					next;
				}
			} else {
				# 성장
				if($lv < 100) {
					$lv += random($addpop) + 1;
					if($lv> 100) {
						$lv = 100;
					}
				} else {
					# 도시가 되면 성장 지연이
					if($addpop2> 0) {
						$lv += random($addpop2) + 1;
					}
				}
			}
			if($lv> 200) {
				$lv = 200;
			}
			$landValue->[$x][$y] = $lv;

			# 이동 방향을 결정
			my($d, $sx, $sy);
			my($i);
			for($i = 0; $i < 3; $i++) {
				$d = random(6) + 1;
				$sx = $x + $ax[$d];
				$sy = $y + $ay[$d];

				# 행 기준 위치 조정
				if((($sy % 2) == 0) && (($y % 2) == 1)) {
					$sx--;
				}

				# 범위 밖 판정
				if(($sx < 0) || ($sx> $islandSize) ||
					($sy < 0) || ($sy> $islandSize)) {
					next;
				}

				# 바다, 바다 기준, 해저 도시, 유전, 괴수, 산, 기념비 이외
				if(($land->[$sx][$sy] != $HlandWaste) &&
					($land->[$sx][$sy] != $HlandPlains) &&
					($land->[$sx][$sy] != $HlandTown) &&
					($land->[$sx][$sy] != $HlandForest) &&
					($land->[$sx][$sy] != $HlandFarm) &&
					($land->[$sx][$sy] != $HlandFoodim) &&
					($land->[$sx][$sy] != $HlandFarmchi) &&
					($land->[$sx][$sy] != $HlandFarmpic) &&
					($land->[$sx][$sy] != $HlandFarmcow) &&
					($land->[$sx][$sy] != $HlandCollege) &&
					($land->[$sx][$sy] != $HlandFactory) &&
					($land->[$sx][$sy] != $HlandHTFactory) &&
					($land->[$sx][$sy] != $HlandBase) &&
					($land->[$sx][$sy] != $HlandDefence) &&
					($land->[$sx][$sy] != $HlandMinato) &&
					($land->[$sx][$sy] != $HlandSeki) &&
					($land->[$sx][$sy] != $HlandPark) &&
					($land->[$sx][$sy] != $HlandHaribote) &&
					($land->[$sx][$sy] != $HlandSbase) &&
					($land->[$sx][$sy] != $HlandSeacity) &&
					($land->[$sx][$sy] != $HlandFune) &&
					($land->[$sx][$sy] != $HlandIce) &&
					($land->[$sx][$sy] != $HlandFrocity) &&
					($land->[$sx][$sy] != $HlandUmiamu) &&
					($land->[$sx][$sy] != $HlandOil) &&
					($land->[$sx][$sy] != $HlandGold) &&
					($land->[$sx][$sy] != $HlandMountain) &&
					($land->[$sx][$sy] != $HlandOnsen) &&
					($land->[$sx][$sy] != $HlandMonument) &&
					($land->[$sx][$sy] != $HlandMine) &&
					($land->[$sx][$sy] != $HlandNursery) &&
					($land->[$sx][$sy] != $HlandKyujo) &&
					($land->[$sx][$sy] != $HlandKyujokai) &&
					($land->[$sx][$sy] != $HlandRottenSea) &&
					($land->[$sx][$sy] != $HlandProcity) &&
					($land->[$sx][$sy] != $HlandNewtown) &&
					($land->[$sx][$sy] != $HlandBigtown) &&
					($land->[$sx][$sy] != $HlandBettown) &&
					($land->[$sx][$sy] != $HlandSeatown) &&
					($land->[$sx][$sy] != $HlandRizort) &&
					($land->[$sx][$sy] != $HlandBigRizort) &&
					($land->[$sx][$sy] != $HlandShuto) &&
					($land->[$sx][$sy] != $HlandUmishuto) &&
					($land->[$sx][$sy] != $HlandHouse) &&
					($land->[$sx][$sy] != $HlandHugeMonster) &&
					($land->[$sx][$sy] != $HlandMonster)) {
					last;
				}
			}

			if($i == 3) {
				# 작동없었습니다
				next;
			}

			# 이동한 위치의 지형에 따라 처리
			my($l) = $land->[$sx][$sy];
			my($lv) = $landValue->[$sx][$sy];
			my($lName) = landName($l, $lv);
			my($point) = "($sx, $sy)";

			# 이동
			$land->[$sx][$sy] = $land->[$x][$y];
			$landValue->[$sx][$sy] = $landValue->[$x][$y];

			# 원래 위치를 바다로
			$land->[$x][$y] = $HlandSea;
			$landValue->[$x][$y] = 0;

		} elsif($landKind == $HlandFune) {
			# 선박
			# 이미 이동한 후
			next if($funeMove[$x][$y] == 2);

			# 각 요소 꺼내기
			my($funespe) = $HfuneSpecial[$lv];
			my($lName) = landName($landKind, $lv);
			my($mvalue, $tvalue, $fvalue, $fvalue2, $movalue) = (0, 0, 0, 0, 0);

			my($sinkflag) = ((($lv> 7) && ($lv < 11) || ($lv == 19)) ? 5 : 30);

			# 침몰판정
			if(random(1000) < $sinkflag) {
				# 사고 때문에 침몰
				logDamageAny($id, $name, $lName, "($x, $y)", "사고 때문에 침몰했습니다.");
				$land->[$x][$y] = $HlandSea;
				$landValue->[$x][$y] = 0;

				# 보험 수입
				$mvalue = 1+ random(399);
				$island->{'money'} += $mvalue;
				logHoken($id, $name, $lName, "($x, $y)", "$mvalue$HunitMoney");
				next;
			}

			if(!$lv) { # 소형어선(수정)
				$lv = 1;
				$landValue->[$x][$y] = 1;
			}

			if($lv == 1) { # 소형어선
				$mvalue = -5; # 유지비
				$fvalue = 290+ random(30); # 수확

			} elsif($lv == 2) { # 안형어선
				$mvalue = -20; # 유지비
				$fvalue = 490+ random(40); # 수확

			} elsif($lv == 3) { # 해저 탐사선
				$mvalue = -300; # 유지비
				if(random(1000) < 5) {
					# 보물 발견(유지비면제)
					$tvalue = 1 + random(49999);
				}

			} elsif($lv == 4) { # 범선
				$mvalue = int((150+ random(250)) * $Hmoney2Incom[$Hmonth]/100); # 관광 수입
				$fvalue2 = -1000; # 유지 식량

			} elsif($lv == 5) { # 대형어선
				$mvalue = -60; # 유지비
				$fvalue = 690+ random(40); # 수확

			} elsif($lv == 6) { # 고속어선
				$mvalue = -30; # 유지비
				$fvalue = 490+ random(40); # 수확

			} elsif($lv == 7) { # 해저 탐사선·개정
				$mvalue = -500; # 유지비
				if(random(100) < 1) {
					# 보물 발견(유지비면제)
					$tvalue = 500+ random(99999);
				}

			} elsif($lv == 8) { # 호화려고객선박 TITANIC
				$mvalue = int((1500 + int($island->{'pop'} / 10) * 1) * $Hmoney2Incom[$Hmonth]/100);	# 관광 수입
				$fvalue2 = -3000; # 유지 식량

				if(random(100) < 10) {
					# 얼음 산
					$land->[$x][$y] = $HlandIce;
					$landValue->[$x][$y] = 0;
					$movalue = int($island->{'pop'} / 10) * 2;	# 영화화
				}

			} elsif($lv == 9) { # 전함 RENAS
				$mvalue = -100; # 유지비

				my($i, $sx, $sy, $monsno);
				$monsno = $island->{'monsterlive'};
				if($monsno> 0) {
					my($monsArray, $monspnt);
					$monsArray = $island->{'monspnt'};
					for($i = 0; $i < $monsno; $i++){
						last if($kougekiseigen> 1);
						$monspnt = $monsArray->[$i];
						($sx, $sy) = ($monspnt->{x}, $monspnt->{y});
						if($land->[$sx][$sy] == $HlandMonster){
							my $value = 100;
							$island->{'money'} -= $value;

							# 대상이 되는 괴수각 요소 꺼내기
							my($tKind, $tName, $tHp) = monsterSpec($landValue->[$sx][$sy]);
							my($tlv) = $landValue->[$sx][$sy];
							my($tspecial) = $HmonsterSpecial[$tKind];

							# 대상이 경화 중이면 효과 없음
							next if((($tspecial == 3) && ($HislandTurn % 2)) ||
									(($tspecial == 8) && !(seqnum($HislandTurn) % 2)) ||
									(($tspecial == 4) && !($HislandTurn % 2)));

							logMonsAttackt($id, $name, $lName, "($x, $y)", $tName, $tPoint);
							$kougekiseigen++;

							# 대상의 체력을 감하게 함
							$tHp--;

							if($tHp> 1){
								$tlv--;
								$landValue->[$sx][$sy] = $tlv;
							} else {
								# 대상의 괴수가 쓰러져 황무지가 됨
								$land->[$sx][$sy] = $HlandWaste;
								$landValue->[$sx][$Sy] = 0;
								$island->{'monsterlive'} -= 1;
								# 포상금
								my($value) = $HmonsterValue[$tKind];
								$island->{'money'} += $value;
								logMsMonMoney($id, $tName, $value);
							}
							next;
						}
					}
				}

			} elsif($lv == 10) { # 전함 ERADICATE
				$mvalue = -400; # 유지비

				my($i, $sx, $sy, $monsno);
				$monsno = $island->{'monsterlive'};
				if($monsno> 0) {
					my($monsArray, $monspnt);
					$monsArray = $island->{'monspnt'};
					for($i = 0; $i < $monsno; $i++){
						$monspnt = $monsArray->[$i];
						($sx, $sy) = ($monspnt->{x}, $monspnt->{y});
						if($land->[$sx][$sy] == $HlandMonster){
							my $value = 3000;
							$island->{'money'} -= $value;

							# 대상이 되는 괴수각 요소 꺼내기
							my($tKind, $tName, $tHp) = monsterSpec($landValue->[$sx][$sy]);
							logFuneAttack($id, $name, $lName, "($x, $y)", $tName, "($sx, $sy)");

							my($ssx, $ssy, $i, $sLandKind, $sLandName, $sLv, $point);

							for($i = 0; $i < 7; $i++) {
								$ssx = $sx + $ax[$i];
								$ssy = $sy + $ay[$i];

								# 행 기준 위치 조정
								$ssx-- if(!($ssy % 2) && ($sy % 2));

								# 범위 밖 판정
								next if(($ssx < 0) || ($ssx> $islandSize) || ($ssy < 0) || ($ssy> $islandSize));

								$sLandKind = $land->[$ssx][$ssy];
								$sLv = $landValue->[$ssx][$ssy];
								$sLandName = landName($sLandKind, $sLv);
								$point = "($ssx, $ssy)";

								# 범위에 한분기
								if($i < 1) {
									# 주변
									$land->[$ssx][$ssy] = $HlandSea;
									$landValue->[$ssx][$ssy] = 1;
									$island->{'monsterlive'} -= 1;
									logDamageAny($id, $name, $sLandName, $point, "분출한 영향으로 수몰되었습니다.");
								} else {
									# 1헥스
									if(($sLandKind == $HlandWaste)	||
										($sLandKind == $HlandMountain) ||
										($sLandKind == $HlandIce) ||
										($sLandKind == $HlandOnsen) ||
										($sLandKind == $HlandUmishuto) ||
										($sLandKind == $HlandFrocity) ||
										($sLandKind == $HlandGold)	 ||
										($sLandKind == $HlandShrine)	||
										($sLandKind == $HlandSea) ||
										($sLandKind == $HlandSbase) ||
										($sLandKind == $HlandSeacity) ||
										($sLandKind == $HlandSeatown) ||
										($sLandKind == $HlandOil) ||
										($sLandKind == $HlandFune) ||
										($sLandKind == $HlandUmiamu)) {
										# 피해의 없음 지형
									} else {
										$land->[$ssx][$ssy] = $HlandWaste;
										$landValue->[$ssx][$ssy] = 0;
										if($sLandKind == $HlandMonster) {
											logDamageAny($id, $name, $sLandName, $point, "사라졌습니다.");
										} elsif($sLandKind == $HlandHugeMonster) {
											logDamageAny($id, $name, $sLandName, $point, "체의 일부가사라졌습니다.");
											my($sSea) = (hugeMonsterSpec($sLv))[1];
											if ($sSea < 2) {
												# 바다, 얕은 바다에 있는
												$land->[$ssx][$ssy] = $HlandSea;
												$landValue->[$ssx][$ssy] = $sSea;
											}
										} else {
											logDamageAny($id, $name, $sLandName, $point, "한순간에 <B>황무지</B>가 되었습니다.");
										}
									}
								}
							}
							next;
						}
					}
				}

			} elsif($lv == 11) { # 어선 MASTER
				$mvalue = -60; # 유지비
				$fvalue = 690+ random(40); # 수확

			} elsif($lv == 19) { # 신형전함
				$mvalue = -1000; # 유지비

				my $heat = 0;
				my($i, $sx, $sy, $monsno);
				$monsno = $island->{'monsterlive'};
				if($monsno> 0) {
					my($monsArray, $monspnt);
					$monsArray = $island->{'monspnt'};
					for($i = 0; $i < $monsno; $i++){
						$monspnt = $monsArray->[$i];
						($sx, $sy) = ($monspnt->{x}, $monspnt->{y});
						if($land->[$sx][$sy] == $HlandMonster){
							my $value = 50000;
							$island->{'money'} -= $value;

							# 대상이 되는 괴수각 요소 꺼내기
							my($tKind, $tName, $tHp) = monsterSpec($landValue->[$sx][$sy]);
							logFuneAttackSSS($id, $name, $lName, "($x, $y)", $tName, "($sx, $sy)");
							$land->[$sx][$sy] = $HlandWaste;
							$landValue->[$sx][$sy] = 0;
							$heat++;

							my $rena = $island->{'rena'};
							if (random($rena)> (3000 + $heat * 1000)) {
								logFuneAttackSSSR($id, $name, $lName, "($x, $y)", $tName, "($sx, $sy)");
							} else {
								logFuneAttackSSST($id, $name, $lName, "($x, $y)", $tName, "($sx, $sy)");
								my($ssx, $ssy, $i, $sLandKind, $sLandName, $sLv, $point);

								for($i = 0; $i < 7; $i++) {
									$ssx = $x + $ax[$i];
									$ssy = $y + $ay[$i];

									# 행 기준 위치 조정
									$ssx-- if(!($ssy % 2) && ($y % 2));

									# 범위 밖 판정
									next if(($ssx < 0) || ($ssx> $islandSize) || ($ssy < 0) || ($ssy> $islandSize));

									$sLandKind = $land->[$ssx][$ssy];
									$sLv = $landValue->[$ssx][$ssy];
									$sLandName = landName($sLandKind, $sLv);
									$point = "($ssx, $ssy)";

									# 범위에 한분기
									if($i < 1) {
										# 주변
										$land->[$ssx][$ssy] = $HlandSea;
										$landValue->[$ssx][$ssy] = 1;
										$island->{'monsterlive'} -= 1;
										logDamageAny($id, $name, $sLandName, $point, "분출한 영향으로 수몰되었습니다.");
									} else {
										# 1헥스
										if(($sLandKind == $HlandWaste)	||
											($sLandKind == $HlandMountain) ||
											($sLandKind == $HlandIce) ||
											($sLandKind == $HlandOnsen) ||
											($sLandKind == $HlandUmishuto) ||
											($sLandKind == $HlandFrocity) ||
											($sLandKind == $HlandGold)	 ||
											($sLandKind == $HlandShrine)	||
											($sLandKind == $HlandSea) ||
											($sLandKind == $HlandSbase) ||
											($sLandKind == $HlandSeacity) ||
											($sLandKind == $HlandSeatown) ||
											($sLandKind == $HlandOil) ||
											($sLandKind == $HlandFune) ||
											($sLandKind == $HlandUmiamu)) {
											# 피해의 없음 지형
										} else {
											$land->[$ssx][$ssy] = $HlandWaste;
											$landValue->[$ssx][$ssy] = 0;
											if($sLandKind == $HlandMonster) {
												logDamageAny($id, $name, $sLandName, $point, "사라졌습니다.");
											} elsif($sLandKind == $HlandHugeMonster) {
												logDamageAny($id, $name, $sLandName, $point, "체의 일부가사라졌습니다.");
												my($sSea) = (hugeMonsterSpec($sLv))[1];
												if ($sSea < 2) {
													# 바다, 얕은 바다에 있는
													$land->[$ssx][$ssy] = $HlandSea;
													$landValue->[$ssx][$ssy] = $sSea;
												}
											} else {
												logDamageAny($id, $name, $sLandName, $point, "한순간에 <B>황무지</B>가 되었습니다.");
											}
										}
									}
								}
								next;
							}
						}
					}
				}
			}

			# 관광 수입, 유지비
			$island->{'money'} += $mvalue;
			logOilMoney($id, $name, $lName, "($x, $y)", "$mvalue$HunitMoney", "관광 수입") if($mvalue> 0);
			# 보물
			$island->{'money'} += $tvalue;
			logTansaku($id, $name, $lName, "($x, $y)", "$tvalue$HunitMoney") if($tvalue);
			# 영화화
			$island->{'money'} += $movalue;
			logDamageAny($id, $name, $lName, "($x, $y)", "빙산에 격렬하게 충돌해 순식간에 침몰했습니다.") if($movalue);
			logTitanicEnd($id, $name, $lName, "($x, $y)", "$movalue$HunitMoney") if($movalue);
			# 어선
			$fvalue = int($fvalue * $Hfood2Incom[$month]/100);
			$fvalue2 = int($fvalue2 * $HeatenFoodS[$month]/100);
			$island->{'food'} += ($fvalue + $fvalue2);
			logParkEventf($id, $name, $lName, "($x, $y)", "$fvalue$HunitFood") if(($fvalue + $fvalue2> 0) && !$HlogOmit1);
			$island->{'fishcatch'} += $fvalue if($HlogOmit1);
			$island->{'fishcatch'} += $fvalue2 if($HlogOmit1 == 2);

			# 이동 방향을 결정
			my($d, $sx, $sy);
			my($i);
			for($i = 0; $i < 3; $i++) {
				$d = random(6) + 1;
				$sx = $x + $ax[$d];
				$sy = $y + $ay[$d];

				# 행 기준 위치 조정
				$sx-- if(!($sy % 2) && ($y % 2));
				# 범위 밖 판정
				next if(($sx < 0) || ($sx> $islandSize) || ($sy < 0) || ($sy> $islandSize));
				# 바다이면 이동
				last if($land->[$sx][$sy] == $HlandSea);
			}

			# 작동없었습니다
			next if($i == 3);

			# 이동
			$land->[$sx][$sy] = $land->[$x][$y];
			$landValue->[$sx][$sy] = $landValue->[$x][$y];
			# 원래 위치를 바다로
			$land->[$x][$y] = $HlandSea;
			$landValue->[$x][$y] = 0;

			if( (($lv == 3) && (random(100) < 2)) || # 유전보기케
				 (($lv == 7) && (random(100) < 4)) ) {
				logTansakuoil($id, $name, $lName, "($x, $y)");
				$land->[$x][$y] = $HlandOil;
				$landValue->[$x][$y] = 0;
			}

			# 이동 완료 플래그
			if($funespe == 2) {
				# 이동 완료 플래그가 설정되어 있지 않음
			} elsif($funespe) {
				# 속이선박
				$funeMove[$sx][$sy] = $funeMove[$x][$y] + 1;
			} else {
				# 일반 선박
				$funeMove[$sx][$sy] = 2;
			}

		} elsif($landKind == $HlandMonster) {
			# 괴수
			next if($monsterMove[$x][$y] == 2);
			# 이미 이동한 후

			# 각 요소 꺼내기
			my($mKind, $mName, $mHp) = monsterSpec($lv);
			my($special) = $HmonsterSpecial[$mKind];

			# 와푸하다?
			if(($special == 14) || ($special == 15)) {
				my($r) = random(100);
				if($r < 40) { # 40%
					# 와푸하다
					my($tIsland) = $island;

					$r = random(100);
					# 50% 확률로 워프
					$tIsland = $Hislands[random($HislandNumber)] if($r < 50);
					my($tId) = $tIsland->{'id'};
					my($tName) = islandName($tIsland);

					# 와푸지점을 결하기
					my($i, $bx, $by);
					my($tLand)	 = $tIsland->{'land'};
					my($tLandValue) = $tIsland->{'landValue'};
					foreach $i (0..$pointNumber) {
						$bx = $Hrpx[$i];
						$by = $Hrpy[$i];
						last if($tLand->[$bx][$by] == $HlandTown);
					}
					next if($tLand->[$bx][$by] != $HlandTown);

					# 와푸!
					logMonsWarp($id, $name, "($x, $y)", $mName);
					$island->{'monsterlive'} -= 1;
					logMonsCome($tId, $tName, $mName, "($bx, $by)", landName($tLand->[$bx][$by], $tLandValue->[$bx][$by]));
					$tIsland->{'monsterlive'} += 1;

					$tLand->[$bx][$by]	 = $land->[$x][$y];
					$tLandValue->[$bx][$by] = $landValue->[$x][$y];

					$land->[$x][$y]	 = $HlandWaste;
					$landValue->[$x][$y] = 0;

					if(($special == 15) && (random(100) < 50)) { # 50%
						# 주변의 지형을 권키포함무
						my($sx, $sy, $tx, $ty, $sKind, $sLv, $tKind, $tLv);
						for ($i = 1; $i < 7; $i++) {
							$sx = $x + $ax[$i];
							$sy = $y + $ay[$i];
							$tx = $bx + $ax[$i];
							$ty = $by + $ay[$i];

							$sx-- if(!($sy % 2) && ($y % 2));
							$tx-- if(!($ty % 2) && ($by % 2));

							if(($sx < 0) || ($sx> $islandSize) || ($sy < 0) || ($sy> $islandSize)) {
								$sKind = $HlandSea;
								$sLv	= 0;
							} else {
								$sKind = $land->[$sx][$sy];
								$sLv	= $landValue->[$sx][$sy];
								if($sKind == $HlandHugeMonster) {
									my($sSea, $sHuge) = (hugeMonsterSpec($sLv))[1, 2];
									if($sHuge == 0) {
										my($j, $ssx, $ssy);
										for($j = 1; $j < 7; $j++) {
											next if($HhugeMonsterImage[$mKind][$j] eq '');
											$ssx = $sx + $ax[$j];
											$ssy = $sy + $ay[$j];
											# 행 기준 위치 조정
											$ssx-- if((($ssy % 2) == 0) && (($sy % 2) == 1));

											next if($land->[$ssx][$ssy] != $HlandHugeMonster);
											my($mKind2, $mSea2, $mHuge2, $mName2, $mHp2) = hugeMonsterSpec($landValue->[$ssx][$ssy]);
											next if($mHuge2 != $j);
											if ($mSea2 < 2) {
												$land->[$ssx][$ssy] = $HlandSea;
												$landValue->[$ssx][$ssy] = $mSea2;
											} else {
												$land->[$ssx][$ssy] = $HlandWaste;
												$landValue->[$ssx][$ssy] = 1;
											}
										}
										$island->{'monsterlive'} -= 1;
										$tIsland->{'monsterlive'} += 1;
									} else {
										if ($sSea < 2) {
											# 바다, 얕은 바다에 있는
											$sKind = $HlandSea;
											$sLv = $sSea;
										} else {
											$sKind = $HlandWaste;
											$sLv = 0;
										}
									}
								}
							}
							if(($tx < 0) || ($tx> $islandSize) || ($ty < 0) || ($ty> $islandSize)) {
								$tKind = $HlandSea;
								$tLv	= 0;
							} else {
								$tKind = $tLand->[$tx][$ty];
								$tLv	= $tLandValue->[$tx][$ty];
								if($tKind == $HlandHugeMonster) {
									my($tSea, $tHuge) = (hugeMonsterSpec($tLv))[1, 2];
									if($tHuge == 0) {
										my($j, $ttx, $tty);
										for($j = 1; $j < 7; $j++) {
											next if($HhugeMonsterImage[$mKind][$j] eq '');
											$ttx = $tx + $ax[$j];
											$tty = $ty + $ay[$j];
											# 행 기준 위치 조정
											$ttx-- if((($tty % 2) == 0) && (($ty % 2) == 1));

											next if($land->[$ttx][$tty] != $HlandHugeMonster);
											my($mKind2, $mSea2, $mHuge2, $mName2, $mHp2) = hugeMonsterSpec($landValue->[$ttx][$tty]);
											next if($mHuge2 != $j);
											if ($mSea2 < 2) {
												$tLand->[$ssx][$ssy] = $HlandSea;
												$tLandValue->[$ssx][$ssy] = $mSea2;
											} else {
												$tLand->[$ssx][$ssy] = $HlandWaste;
												$tLandValue->[$ssx][$ssy] = 1;
											}
										}
									} else {
										if ($tSea < 2) {
											# 바다, 얕은 바다에 있는
											$tKind = $HlandSea;
											$tLv = $tSea;
										} else {
											$tKind = $HlandWaste;
											$tLv = 0;
										}
									}
								}
							}

							if(($sx>= 0) && ($sx < $HislandSize) && ($sy>= 0) && ($sy < $HislandSize)) {
								# 범위 안의 경우
								$land->[$sx][$sy]	 = $tKind;
								$landValue->[$sx][$sy] = $tLv;
								logMonsWarpLand($id, $name, landName($tKind, $tLv), "($sx, $sy)");
							}
							if(($tx>= 0) && ($tx < $HislandSize) && ($ty>= 0) && ($ty < $HislandSize)) {
								# 범위 안의 경우
								$tLand->[$tx][$ty]	 = $sKind;
								$tLandValue->[$tx][$ty] = $sLv;
								logMonsWarpLand($tId, $tName, landName($sKind, $sLv), "($tx, $ty)");
							}
						}
					}
					next;

				} else {
					# 와푸하지 않음
				}
			}

			if($special == 12) {
				# 빈사 상태로 사망하면 폭발해 광역 피해를 발생시키는 괴수
				if($mHp <= 1) { # 남은 체력1이면
					# 빈사 상태이므로 폭발
					logMonsExplosion($id, $name, "($x, $y)", $mName);
					$island->{'monsterlive'} -= 1;
					wideDamage($id, $name, $land, $landValue, $x, $y);
					next;
				}
			}

			if($special == 13) {
				# 동료를 호출부괴수
				if(random(100) < 50) { # 50%
					# 괴수출현
					my($pop) = $island->{'pop'};
					logMonsHelpMe($id, $name, $mName, "($x, $y)");

					# 종류를 결하기
					my($nLv, $nKind);
					if($pop>= $HdisMonsBorder4) {
						# level4까지
						$nKind = random($HmonsterLevel4) + 1;
					} elsif($pop>= $HdisMonsBorder3) {
						# level3까지
						$nKind = random($HmonsterLevel3) + 1;
					} elsif($pop>= $HdisMonsBorder2) {
						# level2까지
						$nKind = random($HmonsterLevel2) + 1;
					} else {
						# level1만
						$nKind = random($HmonsterLevel1) + 1;
					}

					# lv 의 값을 결하기
					$nLv = ($nKind << 4) + $HmonsterBHP[$nKind] + random($HmonsterDHP[$nKind]);

					# 어디에 출현할지 결정
					my($bx, $by, $i);
					foreach $i (0..$pointNumber) {
						$bx = $Hrpx[$i];
						$by = $Hrpy[$i];
						if($land->[$bx][$by] == $HlandTown) {
							# 지형 이름
							my($lName) = landName($HlandTown, $landValue->[$bx][$by]);

							# 해당 헥스를 괴수로
							$land->[$bx][$by] = $HlandMonster;
							$landValue->[$bx][$by] = $nLv;

							# 괴수 정보
							my($nName) = (monsterSpec($nLv))[1];

							# 메시지
							logMonsCome($id, $name, $nName, "($bx, $by)", $lName);
							$island->{'monsterlive'} += 1;
							last;
						}
					}
				}
			}

			if($mKind == 13) { # 천사미카엘
				# 행운
				my $value = $HoilMoney+ random(500); # 날개근 수입
				$island->{'money'} += $value;
				logOilMoneyt($id, $name, $mName, "($x, $y)", "$value$HunitMoney", "수익");

				$value = int($island->{'pop'} / 20) + random(11); # 풍요작
				$island->{'food'} += $value;
				logParkEventt($id, $name, $mName, "($x, $y)", "$value$HunitFood") if($value> 0);
			}

			# 경화 중?
			if((($special == 3) && ($HislandTurn % 2)) ||
				(($special == 8) && !(seqnum($HislandTurn) % 2)) ||
				(($special == 4) && !($HislandTurn % 2))) {
				# 경화 중
				next;

			} elsif(($mKind == 16)&&(($HislandTurn % 2) == 0)&&($mHp < 4)&&(random(1000) < 700)) { # 마수 퀸
				logMonsBomb($id, $name, $lName, "($x, $y)", $mName);
				# 광역 피해 루틴
				wideDamage($id, $name, $land, $landValue, $x, $y);
				if (random(1000) < 250) {
					$land->[$x][$y] = $HlandMonument;
					$landValue->[$x][$y] = 78;
				}

			} elsif($mKind == 17) { # 인공괴수f02
				my($tx, $ty, $tL, $tLv);
				# 발사
				$tx = random($HislandSize);
				$ty = random($HislandSize);
				$tL = $land->[$tx][$ty];
				$tLv = $landValue->[$tx][$ty];

				next if($tL == $HlandHugeMonster);

				if(random(1000) < 600) {

					if(($tL == $HlandSea) ||
						($tL == $HlandMountain) ||
						($tL == $HlandGold)	 ||
						($tL == $HlandShrine)	||
						($tL == $HlandSeacity) ||
						($tL == $HlandOnsen) ||
						($tL == $HlandIce) ||
						($tL == $HlandUmishuto) ||
						($tL == $HlandSeatown) ||
						($tL == $HlandUmiamu)	||
						($tL == $HlandSbase)) {
						logMekaAttack($id, $name, $mName, "($x, $y)", landName($tL, $tLv), "($tx, $ty)", "미사일");
						next;
					}

					$land->[$tx][$ty] = $HlandWaste;
					$landValue->[$tx][$ty] = 1;
					logMekaAttack($id, $name, $mName, "($x, $y)", landName($tL, $tLv), "($tx, $ty)", "미사일", "일대가괴멸시");

				} elsif(random(1000) < 400) {
					logMekaAttack($id, $name, $mName, "($x, $y)", landName($tL, $tLv), "($tx, $ty)", "${HtagDisaster_}다탄두 미사일${H_tagDisaster}");
					my($ssx, $ssy, $i, $ssL, $ssLv);
					for($i = 0; $i < 7; $i++) {
						$ssx = $tx + $ax[$i];
						$ssy = $ty + $ay[$i];

						# 행 기준 위치 조정
						$ssx-- if(!($ssy % 2) && ($ty % 2));

						$ssL = $land->[$ssx][$ssy];
						$ssLv = $landValue->[$ssx][$ssy];
						# 범위 밖 판정
						next if(($ssx < 0) || ($ssx> $islandSize) || ($ssy < 0) || ($ssy> $islandSize));

						# 범위에 한분기
						if($i < 1) {
							# 주변
							if(($ssL == $HlandSea) ||
								($ssL == $HlandSeacity) ||
								($ssL == $HlandSeatown) ||
								($ssL == $HlandUmishuto) ||
								($ssL == $HlandUmiamu) ||
								($ssL == $HlandSbase)) {
								next;
							}
							$land->[$ssx][$ssy] = $HlandSea;
							$landValue->[$ssx][$ssy] = 1;
							logDamageAny($id, $name, landName($ssL, $ssLv), "($ssx, $ssy)", "분출한 영향으로 수몰되었습니다.");

						} else {
							# 1헥스
							if(($sL == $HlandWaste)	||
								($sL == $HlandMountain) ||
								($sL == $HlandGold)	 ||
								($sL == $HlandShrine)	||
								($sL == $HlandIce) ||
								($sL == $HlandOnsen) ||
								($sL == $HlandUmishuto) ||
								($sL == $HlandFrocity) ||
								($sL == $HlandSea) ||
								($sL == $HlandSbase) ||
								($sL == $HlandSeacity) ||
								($sL == $HlandSeatown) ||
								($sL == $HlandOil) ||
								($sL == $HlandFune) ||
								($sL == $HlandUmiamu)) {
								# 피해의 없음 지형
								next;
							} elsif($sL == $HlandMonster) {
								logDamageAny($id, $name, landName($ssL, $ssLv), "($ssx, $ssy)", "사라졌습니다.");
								$land->[$ssx][$ssy] = $HlandWaste;
								$landValue->[$ssx][$ssy] = 0;
								$island->{'monsterlive'} -= 1;
							} elsif($sL == $HlandHugeMonster) {
								my($sSea, $sHuge) = (hugeMonsterSpec($sLv))[1, 2];
								next if($sHuge == 0);
								logDamageAny($id, $name, landName($ssL, $ssLv), "($ssx, $ssy)", "체의 일부가사라졌습니다.");
								if ($sSea < 2) {
									# 바다, 얕은 바다에 있는
									$land->[$ssx][$ssy] = $HlandSea;
									$landValue->[$ssx][$ssy] = $sSea;
								} else {
									$land->[$ssx][$ssy] = $HlandWaste;
									$landValue->[$ssx][$ssy] = 0;
								}
							} else {
								logDamageAny($id, $name, landName($ssL, $ssLv), "($ssx, $ssy)", "한순간에 <B>황무지</B>가 되었습니다.");
								$land->[$ssx][$ssy] = $HlandWaste;
								$landValue->[$ssx][$ssy] = 0;
							}
						}
					}
				} elsif(random(1000) < 200) {
					my($sx, $sy, $sL, $sLv);
					# 낙하
					$sx = random($HislandSize);
					$sy = random($HislandSize);
					$sL = $land->[$sx][$sy];
					$sLv = $landValue->[$sx][$sy];
					# 메시지
					logMekaAttack($id, $name, $mName, "($x, $y)", landName($sL, $sLv), "($sx, $sy)", "${HtagDisaster_}아토믹☆봄${H_tagDisaster}", "대폭발");
					# 광역 피해 루틴
					wideDamage($id, $name, $land, $landValue, $sx, $sy);
				}

			} elsif($mKind == 18) { # 천사 우리엘
				my($i, $sx, $sy, $monsno);
				$monsno = $island->{'monsterlive'};
				if($monsno> 0) {
					my($monsArray, $monspnt);
					$monsArray = $island->{'monspnt'};
					for($i = 0; $i < $monsno; $i++){
						$monspnt = $monsArray->[$i];
						($sx, $sy) = ($monspnt->{x}, $monspnt->{y});
						if($land->[$sx][$sy] == $HlandMonster) {
							# 섬에 다른 괴수가 있으면 그 괴수를 공격

							# 대상이 되는 괴수각 요소 꺼내기
							my($tKind, $tName, $tHp) = monsterSpec($landValue->[$sx][$sy]);
							my($tlv) = $landValue->[$sx][$sy];
							my($tSpecial) = $HmonsterSpecial[$tKind];

							if((($tSpecial == 3) && (($HislandTurn % 2) == 1)) ||
								(($tSpecial == 8) && ((seqnum($HislandTurn) % 2) == 0)) ||
								(($tSpecial == 4) && (($HislandTurn % 2) == 0))) {
								# 대상이 경화 중이면 효과 없음
								next;
							}
							if(random(1000) < 600) {
								if(($tKind == 28) ||
									($tKind == 30)) {

									logItiAttackms($id, $name, $mName, "($x, $y)", $tName, "($sx, $sy)");
									$dmge = random(4);
									$tHp -= $dmge;
									$tlv -= $dmge;
									$landValue->[$sx][$sy] = $tlv;

									if($tHp < 1){
										# 대상의 괴수가 쓰러져 황무지가 됨
										$land->[$sx][$sy] = $HlandWaste;
										$landValue->[$sx][$sy] = 0;
										$island->{'monsterlive'} -= 1;
										# 포상금
										my($value) = $HmonsterValue[$tKind];
								 		$island->{'money'} += $value;
										logMsMonMoney($id, $tName, $value);
									}
								} elsif($tKind != 18) { # 천사 우리엘
									logItiAttack($id, $name, $mName, "($x, $y)", $tName, "($sx, $sy)");

									# 대상의 괴수가 쓰러져 황무지가 됨
									$land->[$sx][$sy] = $HlandWaste;
									$landValue->[$sx][$sy] = 0;
									$island->{'monsterlive'} -= 1;
									# 포상금
									my($value) = $HmonsterValue[$tKind];
									$island->{'money'} += $value;
									logMsMonMoney($id, $tName, $value);
								}
							}
						}
					}
					if(random(1000) < 600) {
						my($tx, $ty, $tL, $tLv);
						# 발사
						$tx = random($HislandSize);
						$ty = random($HislandSize);
						$tL = $land->[$tx][$ty];
						$tLv = $landValue->[$tx][$ty];

						if(($tL == $HlandSea) ||
							($tL == $HlandMountain) ||
							($tL == $HlandShrine) ||
							($tL == $HlandHugeMonster) ||
							($tL == $HlandGold)) {
							next;
						}
						$land->[$tx][$ty] = $HlandSea;
						$landValue->[$tx][$ty] = 1;
						logUrieruMeteo($id, $name, $mName, "($x, $y)", landName($tL, $tLv), "($tx, $ty)");
						if (random(1000) < 100) {
							$land->[$tx][$ty] = $HlandMonument;
							$landValue->[$tx][$ty] = 79;
						}
					}
				}
			} elsif ($mKind == 22) { # 아이스 스콜피온
				my($i, $sx, $sy);
				foreach $i (0..$pointNumber) {
					$sx = $Hrpx[$i];
					$sy = $Hrpy[$i];
					if($land->[$sx][$sy] == $HlandMonster) {
						# 섬에 다른 괴수가 있으면 그 괴수를 공격

						# 대상이 되는 괴수각 요소 꺼내기
						my($tKind, $tName, $tHp) = monsterSpec($landValue->[$sx][$sy]);
						my($tlv) = $landValue->[$sx][$sy];
						my($tSpecial) = $HmonsterSpecial[$tKind];

						if((($tSpecial == 3) && (($HislandTurn % 2) == 1)) ||
						 (($tSpecial == 8) && ((seqnum($HislandTurn) % 2) == 0)) ||
						 (($tSpecial == 4) && (($HislandTurn % 2) == 0))) {
							# 대상이 경화 중이면 효과 없음
							next;
						}
						if (random(1000) < 600) {
							if(($tKind == 28) || ($tKind == 30)) {
								logIceAttack($id, $name, $mName, "($x, $y)", $tName, "($sx, $sy)");
								$dmge = random(4);
								$tHp -= $dmge;
								$tlv -= $dmge;
								$landValue->[$sx][$sy] = $tlv;

								if($tHp < 1){
									# 대상의 괴수가 쓰러져빙하가 됨
									$land->[$sx][$sy] = $HlandIce;
									$landValue->[$sx][$sy] = 0;
									$island->{'monsterlive'} -= 1;
									# 포상금
									my($value) = $HmonsterValue[$tKind];
									$island->{'money'} += $value;
									logMsMonMoney($id, $tName, $value);
								}
							} elsif($tKind != 22) {
								logIceAttack($id, $name, $mName, "($x, $y)", $tName, "($sx, $sy)");

								# 대상의 괴수가 쓰러져빙하가 됨
								$land->[$sx][$sy] = $HlandIce;
								$landValue->[$sx][$sy] = 0;
								$island->{'monsterlive'} -= 1;

								if (random(1000) < 100) {
									$land->[$sx][$sy] = $HlandMonument;
									$landValue->[$sx][$sy] = 76;
								}
								# 포상금
								my($value) = $HmonsterValue[$tKind];
								$island->{'money'} += $value;
								logMsMonMoney($id, $tName, $value);
							}
						}
					} elsif(($land->[$sx][$sy] == $HlandBase) ||
						($land->[$sx][$sy] == $HlandDefence) ||
						($land->[$sx][$sy] == $HlandOil) ||
						($land->[$sx][$sy] == $HlandFune)) {
						# 섬에 있는 미사일 기지, 방위 시설, 유전, 선박을 얼음 산이나 빙석으로

						my $tKind = $land->[$sx][$sy];
						my $tlv = $landValue->[$sx][$sy];

						if (random(1000) < 200) {
							logIceAttack($id, $name, $mName, "($x, $y)", landName($tKind, $tlv), "($sx, $sy)");
							$land->[$sx][$sy] = $HlandIce;
							$landValue->[$sx][$sy] = 0;
							if (random(1000) < 100) {
								$land->[$sx][$sy] = $HlandMonument;
								$landValue->[$sx][$sy] = 76;
							}
						}
					}
				}
			} elsif($mKind == 19) { # 마술사 아루브
				if(random(1000) < 300) {
					logMgSpel($id, $name, $mName, "($x, $y)", "금지저주메테오");
					$HdisMeteo[$Hmonth] = 500;
					my($sx, $sy, $sL, $sLv, $first, $sName);
					$first = 1;
					while(!random(2) || $first) {
						$first = 0;
						# 낙하
						$sx = random($HislandSize);
						$sy = random($HislandSize);
						$sL = $land->[$sx][$sy];
						$sLv = $landValue->[$sx][$sy];
						$sName = landName($sL, $sLv);

						next if($HlandHugeMonster);

						if(($sL == $HlandSea) && ($sLv == 0)){
							# 바다포차
							logMeteo($id, $name, $sName, "($sx, $sy)", "시");
						} elsif(($sL == $HlandMountain) || ($sL == $HlandGold) || ($sL == $HlandShrine) || ($sL == $HlandOnsen)){
							# 산파괴
							logMeteo($id, $name, $sName, "($sx, $sy)", ",<B>$sName</B>은 사라지고");
							$land->[$sx][$sy] = $HlandWaste;
							$landValue->[$sx][$sy] = 0;
							next;
						} elsif(($sL == $HlandSbase) ||
								($sL == $HlandSeacity) ||
								($sL == $HlandSeatown) ||
								($sL == $HlandUmishuto) ||
								($sL == $HlandFrocity) ||
								($sL == $HlandFune) ||
								($sL == $HlandUmiamu)) {
							logMeteo($id, $name, $sName, "($sx, $sy)", ",<B>$sName</B>은 붕괴시");
						} elsif($sL == $HlandMonster) {
							$island->{'monsterlive'} -= 1;
							logMeteoMonster($id, $name, $sName, "($sx, $sy)");
						} elsif(($sL == $HlandSea) || ($sL == $HlandIce)) {
							# 얕은 바다
							logMeteo($id, $name, $sName, "($sx, $sy)", "、 해저가 깎였습니다");
						} else {
							logMeteo($id, $name, $sName, "($sx, $sy)", ", 일대가 수몰시");
						}
						$land->[$sx][$sy] = $HlandSea;
						$landValue->[$sx][$sy] = 0;
					}
				}

				if(random(1000) < 200) {
					logMgSpel($id, $name, $mName, "($x, $y)", "금지저주메테오");
					$HdisMeteo[$Hmonth] = 300;
					my($sx, $sy);
					# 낙하
					$sx = random($HislandSize);
					$sy = random($HislandSize);
					# 메시지
					logHugeMeteo($id, $name, "($sx, $sy)");
					# 광역 피해 루틴
					wideDamage($id, $name, $land, $landValue, $sx, $sy);
				}

				if(random(1000) < 400) {
					logMgSpel($id, $name, $mName, "($x, $y)", "퀘이크");
					$HdisEarthquake[$Hmonth] = 500;
					# 지진발생
					logEarthquake($id, $name);
					my($sx, $sy, $sL, $sLv, $i);
					foreach $i (0..$pointNumber) {
						$sx = $Hrpx[$i];
						$sy = $Hrpy[$i];
						$sL = $land->[$sx][$sy];
						$sLv = $landValue->[$sx][$sy];

						if((($sL == $HlandTown) && ($sLv>= 100)) ||
							(($sL == $HlandFoodim) && ($sLv < 480)) ||
							(($sL == $HlandProcity) && ($sLv < 130)) ||
							(($sL == $HlandNewtown) && ($sLv < 300)) ||
							(($sL == $HlandBigtown) && ($sLv < 300)) ||
							(($sL == $HlandHTFactory) && ($sLv < 500)) ||
							($sL == $HlandRizort) ||
							($sL == $HlandBigRizort) ||
							($sL == $HlandHaribote) ||
							($sL == $HlandPark) ||
							($sL == $HlandMinato) ||
							($sL == $HlandKyujo) ||
							($sL == $HlandKyujokai) ||
							($sL == $HlandOnsen) ||
							($sL == $HlandFactory)) {
							# 1/4에서 괴멸
							if(!random(4)) {
								logDamageAny($id, $name, landName($sL, $sLv), "($sx, $sy)", "${HtagDisaster_}지진${H_tagDisaster}으로 괴멸되었습니다.");
								$land->[$sx][$sy] = $HlandWaste;
								$landValue->[$sx][$sy] = 0;
								if ($sL == $HlandOnsen) {
									# 온천은 산에돌아가기
									$land->[$sx][$sy] = $HlandMountain;
								}
							}
						}
					}
				}

				my($i, $sx, $sy, $monsno);
				$monsno = $island->{'monsterlive'};
				if($monsno> 0) { # 드레인
					my($monsArray, $monspnt);
					$monsArray = $island->{'monspnt'};
					for($i = 0; $i < $monsno; $i++){
						$monspnt = $monsArray->[$i];
						($sx, $sy) = ($monspnt->{x}, $monspnt->{y});
						if($land->[$sx][$sy] == $HlandMonster){
							my($tKind, $tName, $tHp) = monsterSpec($landValue->[$sx][$sy]);
							my($tlv) = $landValue->[$sx][$sy];
							my($tSpecial) = $HmonsterSpecial[$tKind];
							if($tKind != 19){
								if($tHp> $mHp){
									next if((($tSpecial == 3) && (($HislandTurn % 2) == 1)) ||
											(($tSpecial == 8) && ((seqnum($HislandTurn) % 2) == 0)) ||
											(($tSpecial == 4) && (($HislandTurn % 2) == 0)));

									logMgDrain($id, $name, $mName, $tName, "($x, $y)");

									$tlv-=($tHp-$mHp);
									$landValue->[$sx][$sy] = $tlv;
									$lv+=($tHp-$mHp) if($mHp < 9);
									$landValue->[$x][$y] = $lv;
								}
								next;
							}
						}
					}
					my($nKind, $nName, $nHp) = monsterSpec($landValue->[$x][$y]);
					$nKind = 21 if($nKind> 21);
					$nHp = 1 if($nHp < 1);
					$landValue->[$x][$y] = ($nKind << 4) + $nHp;
				}

			} elsif($mKind == 20) { # 추락천사이세리아
				$lv += 2;
				$landValue->[$x][$y] = $lv;
				($mKind, $mName, $mHp) = monsterSpec($lv);

				if(random(1000) < 200) {
					$island->{'food'} -= int($island->{'food'} / 2);
					logFushoku($id, $name, $mName, "($x, $y)");
				}
				if($mHp> 13) {
					logUmlimit($id, $name, $mName, "($x, $y)");
					# 광역 피해 루틴
					wideDamage($id, $name, $land, $landValue, $x, $y);
					my($sx, $sy, $sL, $sLv, $i);
					foreach $i (0..$pointNumber) {
						$sx = $Hrpx[$i];
						$sy = $Hrpy[$i];
						$sL = $land->[$sx][$sy];
						$sLv = $landValue->[$sx][$sy];

						if((($sL == $HlandTown) && ($sLv>= 100)) ||
							(($sL == $HlandFoodim) && ($sLv < 480)) ||
							(($sL == $HlandProcity) && ($sLv < 130)) ||
							($sL == $HlandHaribote) ||
							($sL == $HlandPark) ||
							($sL == $HlandMinato) ||
							($sL == $HlandKyujo) ||
							($sL == $HlandKyujokai) ||
							($sL == $HlandBase) ||
							($sL == $HlandFactory)) {
							# 1/6에서 괴멸
							if(!random(6)) {
								logUmlimitDamage($id, $name, $mName, landName($sL, $sLv), "($sx, $sy)");
								$land->[$sx][$sy] = $HlandWaste;
								$landValue->[$sx][$sy] = 0;
								if (random(1000) < 150) {
									$land->[$sx][$sy] = $HlandMonument;
									$landValue->[$sx][$sy] = 74;
								}
							}
						}
					}
					# 마왕 사탄에변내용
					$mKind = 21;
					$lv = ($mKind << 4) + $HmonsterBHP[$mKind] + random($HmonsterDHP[$mKind]);
					$land->[$x][$y] = $HlandMonster;
					$landValue->[$x][$y] = $lv;
				}

			} elsif($mKind == 21) { # 마왕 사탄
				$lv += 3 if($mHp < 9);
				$landValue->[$x][$y] = $lv;
				if(random(1000) < 150) {
					$island->{'money'} -= int($island->{'money'} / 2);
					logKyoukou($id, $name, $mName, "($x, $y)");
				}
				if(random(1000) < 200) {
					$island->{'food'} = 0;
					logFushoku($id, $name, $mName, "($x, $y)");
				}

				my($i,$sx,$sy);
				foreach $i (0..$pointNumber) {
					$sx = $Hrpx[$i];
					$sy = $Hrpy[$i];
					if(($land->[$sx][$sy] == $HlandPlains) ||
						($land->[$sx][$sy] == $HlandForest) ||
						($land->[$sx][$sy] == $HlandNursery) ||
						($land->[$sx][$sy] == $HlandFarmchi) ||
						($land->[$sx][$sy] == $HlandFarmpic) ||
						($land->[$sx][$sy] == $HlandFarmcow) ||
						($land->[$sx][$sy] == $HlandRottenSea)) {
						# 섬에 있는 평지, 숲, 양식장, 양계장, 양돈장, 목장, 오염된 바다를 황무지카암석카염석로
						$tKind = $land->[$sx][$sy];
						$tlv = $landValue->[$sx][$sy];

						if (random(1000) < 200) {
							logHellAttack($id, $name, $mName, "($x, $y)", landName($tKind, $tlv), "($sx, $sy)");
							$land->[$sx][$sy] = $HlandWaste;
							$landValue->[$sx][$sy] = 0;
							if(random(1000) < 100) {
								$land->[$sx][$sy] = $HlandMonument;
								$landValue->[$sx][$sy] = 78;
							} elsif(random(1000) < 100) {
								$land->[$sx][$sy] = $HlandMonument;
								$landValue->[$sx][$sy] = 74;
							}
						}
					}
				}

			} elsif($mKind == 30) { # 초신 수테트라
				if($island->{'monsterlive'} == $island->{'c28'}){
					# 테트라 전용?
					if($island->{'co99'} == 0){
						logMstakeiede($id, $name, "출격안의 초신 수테트라","($sx, $sy)",landName($landKind, $lv));
					} else {
						my($i,$sx,$sy);
						foreach $i (0..$pointNumber) {
							$sx = $Hrpx[$i];
							$sy = $Hrpy[$i];
							$landKind = $land->[$sx][$sy];
							$lv = $landValue->[$sx][$sy];
							$landName = landName($landKind, $lv);
							if(($land->[$sx][$sy] == $HlandCollege) && ($lv == 99)){
								$landValue->[$sx][$sy] = 98;
								$island->{'monsterlive'} -= 1;
								logMstakeokaeri($id, $name, "출격안의 초신 수테트라","($sx, $sy)",landName($landKind, $lv));
							}
						}
					}
					$land->[$x][$y] = $HlandWaste;
					$landValue->[$x][$y] = 0;
				}

				my($i, $sx, $sy, $monsno);
				$monsno = $island->{'monsterlive'};
				if($monsno> 0) {
					my($monsArray, $monspnt);
					$monsArray = $island->{'monspnt'};
					for($i = 0; $i < $monsno; $i++){
						$monspnt = $monsArray->[$i];
						($sx, $sy) = ($monspnt->{x}, $monspnt->{y});
						if($land->[$sx][$sy] == $HlandMonster){
							if($msseigen < 1) {
								# 섬에 다른 괴수가 있으면 그 괴수를 공격

								# 대상이 되는 괴수각 요소 꺼내기
								my($tKind, $tName, $tHp) = monsterSpec($landValue->[$sx][$sy]);
								my($tlv) = $landValue->[$sx][$sy];
								my($tSpecial) = $HmonsterSpecial[$tKind];

								if($tKind == 30) {
								} else {
									my($mshp, $msap, $msdp, $mssp, $mswin, $msexe, $tet) = split(/,/, $island->{'eisei5'});

									$attackdamege = random($msap-$tKind);
									$counterdamege = random($tKind-$msdp);
									if(random(5+$tKind)> $mssp){
										$attackdamege = 0;
									} elsif($attackdamege < 1){
										$attackdamege = 2;
									}
									if(random(5+$tKind) < $mssp){
										$counterdamege = 0;
									} elsif($counterdamege < 1){
										$counterdamege = 1;
									}

									logMsAttackt($id, $name, "초신 수테트라", $attackdamege, $counterdamege, $tName, $tPoint);
									$msseigen++;
									$tHp -= $attackdamege;
									$tlv -= $attackdamege;
									$landValue->[$sx][$sy] = $tlv;
									$mHp -= $counterdamege;
									$lv -= $counterdamege;
									$landValue->[$x][$y] = $lv;

									if($tHp < 1){
										# 대상의 괴수가 쓰러져 황무지가 됨
										$land->[$sx][$sy] = $HlandWaste;
										$landValue->[$sx][$sy] = 0;
										$island->{'monsterlive'} -= 1;
										if($tKind == 13) {
											$land->[$sx][$sy] = $HlandMonument;
											$landValue->[$sx][$sy] = 93;
											logMsAttackmika($id, $name, "초신 수테트라", $attackdamege, $counterdamege, $tName, $tPoint);
										}
										# 포상금
										my($value) = $HmonsterValue[$tKind];
										$island->{'money'} += $value;

										if(random(1000) < $value) {
											if(random(100) < 30) {
												$msap++;
											} elsif (random(100) < 30) {
												$msdp++;
											} elsif (random(100) < 30) {
												$mssp++;
											} else {
												$mshp++;
												$mshp = 15 if($mshp> 15);
											}
										}

										$msexe += $HmonsterExp[$tKind];
										$mswin ++;
										# 괴수퇴치 수
										$island->{'taiji'}++;

										# 수상 관계
										my($prize) = $island->{'prize'};
										my($prize1, $prize2) = split(/\t/, $prize);
										$prize1 =~ /([0-9]*),([0-9]*),(.*)/;
										my($flags) = $1;
										my($monsters) = $2;
										my($turns) = $3;
										my($v) = 2 ** $tKind;
										$monsters |= $v;
										$island->{'prize'} = "$flags,$monsters,$turns\t$prize2";
										$island->{'eisei5'} = "$mshp,$msap,$msdp,$mssp,$mswin,$msexe,$tet";
										logMsMonMoney($id, $tName, $value);

									}
									if($mHp < 1){
										# 초신 수테트라가 쓰러져 황무지가 됨
										$land->[$x][$y] = $HlandWaste;
										$landValue->[$x][$y] = 0;
										$island->{'monsterlive'} -= 1;
										# 포상금
										my($value) = $HmonsterValue[$mKind];
										$island->{'money'} += $value;
										logMsMonMoney($id, $mName, $value);
									}
								}
							} else {
								last;
							}
						}
					}
				}

			} elsif ($mKind == 29) {

				if($island->{'monsterlive'} == 1){
					# 지금테트라 전용?
					if($island->{'co99'} == 0){
					} else {
						my($i,$sx,$sy);
						foreach $i (0..$pointNumber) {
							$sx = $Hrpx[$i];
							$sy = $Hrpy[$i];
							$landKind = $land->[$sx][$sy];
							$lv = $landValue->[$sx][$sy];
							$landName = landName($landKind, $lv);
							if(($land->[$sx][$sy] == $HlandCollege) && ($lv == 99)){
								$landValue->[$sx][$sy] = 98;
								$land->[$x][$y] = $HlandWaste;
								$landValue->[$x][$y] = 0;
								logMstakeokaeri($id, $name, "테트라","($sx, $sy)",landName($landKind, $lv));
								last;
							}
						}
					}
				}


			} elsif ($mKind == 28) {

				if($island->{'monsterlive'} == $island->{'c28'}){
					# 관광 이노라 전용?
					if($island->{'co99'} == 0){
						logMstakeiede($id, $name, "출격안의 관광 이노라","($sx, $sy)",landName($landKind, $lv));
					} else {
						my($i,$sx,$sy);
						foreach $i (0..$pointNumber) {
							$sx = $Hrpx[$i];
							$sy = $Hrpy[$i];
							$landKind = $land->[$sx][$sy];
							$lv = $landValue->[$sx][$sy];
							$landName = landName($landKind, $lv);
							if(($land->[$sx][$sy] == $HlandCollege) && ($lv == 99)){
								$landValue->[$sx][$sy] = 4;
								$island->{'monsterlive'} -= 1;
								logMstakeokaeri($id, $name, "출격안의 관광 이노라","($sx, $sy)",landName($landKind, $lv));
								last;
							}
						}
					}
					$land->[$x][$y] = $HlandWaste;
					$landValue->[$x][$y] = 0;
				}

				my($i, $sx, $sy, $monsno);
				$monsno = $island->{'monsterlive'};
				if($monsno> 0) {
					my($monsArray, $monspnt);
					$monsArray = $island->{'monspnt'};
					for($i = 0; $i < $monsno; $i++){
						$monspnt = $monsArray->[$i];
						($sx, $sy) = ($monspnt->{x}, $monspnt->{y});
						if($land->[$sx][$sy] == $HlandMonster){
							if($msseigen < 1) {
								# 섬에 다른 괴수가 있으면 그 괴수를 공격

								# 대상이 되는 괴수각 요소 꺼내기
								my($tKind, $tName, $tHp) = monsterSpec($landValue->[$sx][$sy]);
								my($tlv) = $landValue->[$sx][$sy];
								my($tSpecial) = $HmonsterSpecial[$tKind];

								if($tKind == 28) {
								} else {
									my($mshp, $msap, $msdp, $mssp, $mswin, $msexe, $tet) = split(/,/, $island->{'eisei5'});

									$attackdamege = random($msap-$tKind);
									$counterdamege = random($tKind-$msdp);
									if(random(5+$tKind)> $mssp){
										$attackdamege = 0;
									} elsif($attackdamege < 1){
										$attackdamege = 1;
									}
									if(random(5+$tKind) < $mssp){
										$counterdamege = 0;
									} elsif($counterdamege < 1){
										$counterdamege = 1;
									}

									logMsAttackt($id, $name, "관광 이노라", $attackdamege, $counterdamege, $tName, $tPoint);
									$msseigen++;
									$tHp -= $attackdamege;
									$tlv -= $attackdamege;
									$landValue->[$sx][$sy] = $tlv;
									$mHp -= $counterdamege;
									$lv -= $counterdamege;
									$landValue->[$x][$y] = $lv;

									if($tHp < 1){
										# 대상의 괴수가 쓰러져 황무지가 됨
										$land->[$sx][$sy] = $HlandWaste;
										$landValue->[$sx][$sy] = 0;
										$island->{'monsterlive'} -= 1;
										# 포상금
										my($value) = $HmonsterValue[$tKind];
										$island->{'money'} += $value;

										if(random(1000) < $value) {
											if(random(100) < 30) {
												$msap++;
											} elsif (random(100) < 30) {
												$msdp++;
											} elsif (random(100) < 30) {
												$mssp++;
											} else {
												$mshp++;
												$mshp = 15 if($mshp> 15);
											}
										}

										$msexe += $HmonsterExp[$tKind];
										$mswin ++;
										# 괴수퇴치 수
										$island->{'taiji'}++;
										# 수상 관계
										my($prize) = $island->{'prize'};
										my($prize1, $prize2) = split(/\t/, $prize);
										$prize1 =~ /([0-9]*),([0-9]*),(.*)/;
										my($flags) = $1;
										my($monsters) = $2;
										my($turns) = $3;
										my($v) = 2 ** $tKind;
										$monsters |= $v;
										$island->{'prize'} = "$flags,$monsters,$turns\t$prize2";
										$island->{'eisei5'} = "$mshp,$msap,$msdp,$mssp,$mswin,$msexe,$tet";
										logMsMonMoney($id, $tName, $value);
									}
									if($mHp < 1){
										# 관광 이노라가 쓰러져 황무지가 됨
										$land->[$x][$y] = $HlandWaste;
										$landValue->[$x][$y] = 0;
										$island->{'monsterlive'} -= 1;
										# 포상금
										my($value) = $HmonsterValue[$mKind];
										$island->{'money'} += $value;
										logMsMonMoney($id, $mName, $value);
									}
								}
							} else {
								last;
							}
						}
					}
				}
			}
			if(($special == 6) || ($mKind == 13)) { # 천사미카엘
				my($i, $sx, $sy, $monsno);
				$monsno = $island->{'monsterlive'};
				if($monsno> 0) {
					my($monsArray, $monspnt);
					$monsArray = $island->{'monspnt'};
					for($i = 0; $i < $monsno; $i++){
						$monspnt = $monsArray->[$i];
						($sx, $sy) = ($monspnt->{x}, $monspnt->{y});
						if($land->[$sx][$sy] == $HlandMonster){
							# 섬에 다른 괴수가 있으면 그 괴수를 공격

							# 대상이 되는 괴수각 요소 꺼내기
							my($sLv) = $landValue->[$sx][$sy];
							my($sKind, $sName, $sHp) = monsterSpec($sLv);
							my($sSpecial) = $HmonsterSpecial[$sKind];

							if($mHp> $sHp){ # 대상보다 체력이 높은 경우
								if((($sSpecial == 3) && (($HislandTurn % 2) == 1)) ||
									(($sSpecial == 8) && ((seqnum($HislandTurn) % 2) == 0)) ||
									(($sSpecial == 4) && (($HislandTurn % 2) == 0))) {
									# 대상이 경화 중이면 효과 없음
									next;
								}
								last if($kougekiseigenm> 1);

								if($mKind == 13) { # 천사미카엘
									logMonsAttackt($id, $name, $mName, "($x, $y)", $sName, "($sx, $sy)");
								}else{
									logMonsAttack($id, $name, $mName, "($x, $y)", $sName, "($sx, $sy)");
								}

								$kougekiseigenm++;
								# 대상의 괴수의 체력을 탈취라고자신의 체력을 회복
								$sHp--;
								if($sHp> 0){
									# 대상의 체력을 감하게 함
									$sLv--;
									$landValue->[$sx][$sy] = $sLv;
								}else{
									# 대상의 괴수가 쓰러져 황무지가 됨
									$land->[$sx][$sy] = $HlandWaste;
									$landValue->[$sx][$sy] = 0;
									$island->{'monsterlive'} -= 1;
									# 포상금
									my($value) = $HmonsterValue[$sKind];
									$island->{'money'} += $value;
									logMsMonMoney($id, $sName, $value);
								}
								$lv++ if($mHp < 9);
								$landValue->[$x][$y] = $lv;
							}
							# 대상보다 체력이 낮은 경우 아무것도 하지 않음
						}
					}
					my($nKind, $nName, $nHp) = monsterSpec($landValue->[$x][$y]);
					$nKind = 30 if($nKind> 30);
					$nHp = 1 if($nHp < 1);
					$landValue->[$x][$y] = ($nKind << 4) + $nHp;
				}
			}

			# 이동 방향을 결정
			my($d, $sx, $sy);
			my($i);
			for($i = 0; $i < 3; $i++) {
				$d = random(6) + 1;
				$sx = $x + $ax[$d];
				$sy = $y + $ay[$d];
				# 행 기준 위치 조정
				$sx-- if(!($sy % 2) && ($y % 2));
				# 범위 밖 판정
				next if(($sx < 0) || ($sx> $islandSize) || ($sy < 0) || ($sy> $islandSize));

				my $l = $land->[$sx][$sy];
				# 바다, 바다 기준, 해저 도시, 유전, 괴수, 산, 기념비 이외
				if(($l != $HlandSea) &&
					($l != $HlandSbase) &&
					($l != $HlandSeacity) &&
					($l != $HlandSeatown) &&
					($l != $HlandNursery) &&
					($l != $HlandOil) &&
					($l != $HlandBigtown) &&
					($l != $HlandBettown) &&
					($l != $HlandShuto) &&
					($l != $HlandUmishuto) &&
					($l != $HlandFrocity) &&
					($l != $HlandBigRizort) &&
					($l != $HlandOnsen) &&
					($l != $HlandHouse) &&
					($l != $HlandFune) &&
					($l != $HlandUmiamu) &&
					($l != $HlandGold) &&
					($l != $HlandShrine) &&
					($l != $HlandMountain) &&
					($l != $HlandMonument) &&
					($l != $HlandRottenSea) &&
					($l != $HlandHugeMonster) &&
					($l != $HlandMonster)) {
					last;
				}
			}
			# 작동없었습니다
			next if($i == 3);

			if (($mKind == 28) || ($mKind == 30)) {
				if($land->[$sx][$sy] != $HlandWaste) {
					next;
				}
			}

			# 이동한 위치의 지형에 따라 처리
			my($sL) = $land->[$sx][$sy];
			my($sLv) = $landValue->[$sx][$sy];
			my($sName) = landName($sL, $sLv);
			my($point) = "($sx, $sy)";

			my($mi, $mx, $my);
			for($mi = 0; $mi < $island->{'monsterlive'}; $mi++){
				($mx, $my) = ($island->{'monspnt'}->[$mi]->{x}, $island->{'monspnt'}->[$mi]->{y});
				if(($mx == $x) && ($my == $y)) {
					$island->{'monspnt'}->[$mi] = { x => $sx, y => $sy };
					last;
				}
			}

			# 이동
			$land->[$sx][$sy] = $land->[$x][$y];
			$landValue->[$sx][$sy] = $landValue->[$x][$y];

			# 원래 위치를 황무지로
			$land->[$x][$y] = $HlandWaste;
			$landValue->[$x][$y] = 0;

			if($mKind == 11) { # 기묘수 슬라임이면(이노라를 전용)
				if(((random(1000) < 900) && ($island->{'monsterlive'} < 7)) || # 90% 확률로 분열하다
					((random(20000) < 400-$island->{'monsterlive'}) && ($island->{'monsterlive'}> 7))) { # 90% 확률로 분열하다
					lognewMonsterBorn($id, $name, "($x, $y)");
					$lv = ($mKind << 4) + $HmonsterBHP[$mKind] + random($HmonsterDHP[$mKind]);
					$land->[$x][$y] = $HlandMonster;
					$landValue->[$x][$y] = $lv;
					$island->{'monspnt'}->[$island->{'monsterlive'}] = { x => $x, y => $y };
					$island->{'monsterlive'}++;
				}
			}

			if(($mKind == 15) || ($mKind == 19)) { # 마수 레이지라, 마술사 아루브이면(이노라를 전용)
				if((random(1000) < 600) && ($island->{'monsterlive'} < 7)) { # 60% 확률로 소환하다(도움케가쿠루)
					my $nKind = random($HmonsterLevel3) + 1;
					$lv = ($nKind << 4) + $HmonsterBHP[$nKind] + random($HmonsterDHP[$nKind]);
					$land->[$x][$y] = $HlandMonster;
					$landValue->[$x][$y] = $lv;
					$island->{'monspnt'}->[$island->{'monsterlive'}] = { x => $x, y => $y };
					$island->{'monsterlive'}++;
					my($nName) = (monsterSpec($lv))[1];
					if($mKind == 15) { # 마수 레이지라
						lognewKaiju($id, $name, $nName, "($x, $y)");
					}else{
						logShoukan($id, $name, $mName, $nName, "($x, $y)");
					}
				}
			}

			if($mKind == 8) { # 오무라면 여기에서 추가
				if(random(1000) < 400) { # 40% 확률로 오염된 바다가생된
					logRottenSeaBorn($id, $name, "($x, $y)");
					$land->[$x][$y] = $HlandRottenSea;
					$landValue->[$x][$y] = 1;
				} elsif(random(1000) < 200) { # 탈피 껍질
					logNuginugi($id, $name, "($x, $y)");
					$land->[$x][$y] = $HlandMonument;
					$landValue->[$x][$y] = 87;
					my $nKind = 8;
					$lv = ($nKind << 4) + $HmonsterBHP[$nKind] + random(3);
					$land->[$sx][$sy] = $HlandMonster;
					$landValue->[$sx][$sy] = $lv;
				}
			}#여기까지추가

			# 괴수가주변을 불태우는 능력·충격파
			if(($special == 7) || ($special == 11) || ($mKind == 16) || # 마수 퀸(주변 1Hex)
				($mKind == 13) || ($mKind == 18)) { # 천사미카엘, 천사 우리엘(주변 2Hex)
				my $r = 7;
				$r = 19 if(($mKind == 13) || ($mKind == 18));
				my($i, $ssx, $ssy, $ssL, $ssLv);
				for($i = 1; $i < $r; $i++) {
					$ssx = $sx + $ax[$i];
					$ssy = $sy + $ay[$i];

					# 행 기준 위치 조정
					$ssx-- if(!($ssy % 2) && ($sy % 2));
					# 범위 밖
					next if(($ssx < 0) || ($ssx> $islandSize) || ($ssy < 0) || ($ssy> $islandSize));

					$ssL = $land->[$ssx][$ssy];
					$ssLv = $landValue->[$ssx][$ssy];

					if(($ssL == $HlandSea) ||
						($ssL == $HlandSeacity) ||
						($ssL == $HlandSeatown) ||
						($ssL == $HlandUmishuto) ||
						($ssL == $HlandIce) ||
						($ssL == $HlandWaste) ||
						($ssL == $HlandUmiamu) ||
						($ssL == $HlandHugeMonster) ||
						($ssL == $HlandSbase)) {
						# 바다와 해저 기지는 소각되지 않음
						next;
					} elsif(($ssL == $HlandOil) ||
							 ($ssL == $HlandFrocity) ||
							 ($ssL == $HlandFune)) {
						# 유전·선박은 바다에돌아가기
						$land->[$ssx][$ssy] = $HlandSea; # 바다가 됨
						$landValue->[$ssx][$ssy] = 0;
					} elsif($ssL == $HlandNursery) {
						# 양식장은 바다에돌아가기
						$land->[$ssx][$ssy] = $HlandSea; # 바다가 됨
						$landValue->[$ssx][$ssy] = 1;
					} elsif(($ssL == $HlandGold) ||
							 ($ssL == $HlandShrine) ||
							 ($ssL == $HlandOnsen) ||
							 (($ssL == $HlandMountain) && ($ssLv> 0))) {
						# 금광산·채굴장·시간의 신전은 산에돌아가기
						$land->[$ssx][$ssy] = $HlandMountain; # 산이 됨
						$landValue->[$ssx][$ssy] = 0; # 채굴장의 작업원은 괴멸
					} elsif ($ssL == $HlandMonster) {
						# 괴수는
						# 대상이 되는 괴수각 요소 꺼내기
						my($tKind, $tName, $tHp) = monsterSpec($ssLv);
						my($tlv) = $landValue->[$ssx][$ssy];
						my($tspecial) = $HmonsterSpecial[$tKind];
						if(($tKind == 28) || ($tKind == 30)) {
							$dmge = random(4);
							$tHp -= $dmge;
							$tlv -= $dmge;
							$landValue->[$ssx][$ssy] = $tlv;

							if($tHp < 1){
								# 대상의 괴수가 쓰러져 황무지가 됨
								$land->[$ssx][$ssy] = $HlandWaste;
								$landValue->[$ssx][$ssy] = 0;
								# 포상금
								my($value) = $HmonsterValue[$tKind];
							 $island->{'money'} += $value;
								logMsMonMoney($id, $tName, $value);
							}
						}
					} else {
						# 전체가불태됩니다
						$land->[$ssx][$ssy] = $HlandWaste; # 황무지가 됨
						$landValue->[$ssx][$ssy] = 0;
					}

					# 로그 생성
					if($special == 11) {
						logMonsFireS($id, $name, landName($ssL, $ssLv), "($ssx, $ssy)", $mName);
					} else {
						logMonsFire($id, $name, landName($ssL, $ssLv), "($ssx, $ssy)", $mName);
					}
				}
			}


			# 동결되지 않음
			if (($special == 9) || ($mKind == 22)) {
				my($i, $ssx, $ssy, $kind, $lv);
				for($i = 1; $i < 7; $i++) {
					$ssx = $sx + $ax[$i];
					$ssy = $sy + $ay[$i];

					# 행 기준 위치 조정
					if((($ssy % 2) == 0) && (($sy % 2) == 1)) {
						$ssx--;
					}
					if(($ssx < 0) || ($ssx> $islandSize) || ($ssy < 0) || ($ssy> $islandSize)) {
						# 범위 밖
						next;
					}

					$kind = $land->[$ssx][$ssy];
					$lv = $landValue->[$ssx][$ssy];

					if (($kind == $HlandSeacity) ||
						($kind == $HlandSeatown) ||
						($kind == $HlandUmishuto) ||
						($kind == $HlandIce) ||
						($kind == $HlandUmiamu) ||
						($kind == $HlandSbase)) {
						# 바다와 해저 기지는 소각되지 않음
						next;
					} elsif(($kind == $HlandOil) || ($kind == $HlandFune) || ($kind == $HlandFrocity)|| ($kind == $HlandNursery)) {
						# 유전, 선박, 해상 도시, 양식장
						$land->[$ssx][$ssy] = $HlandIce; # 빙하가 됨
						$landValue->[$ssx][$ssy] = 0;
					} elsif ($kind == $HlandMonster) {
						# 괴수는
						# 대상이 되는 괴수각 요소 꺼내기
						my($tKind, $tName, $tHp) = monsterSpec($landValue->[$ssx][$ssy]);
						my($tlv) = $landValue->[$ssx][$ssy];
						my($tspecial) = $HmonsterSpecial[$tKind];
						if(($tKind == 28) || ($tKind == 30)) {
							$dmge = random(4);
							$tHp -= $dmge;
							$tlv -= $dmge;
							$landValue->[$ssx][$ssy] = $tlv;
							if($tHp < 1){
								# 대상의 괴수가 쓰러져빙하가 됨
								$land->[$ssx][$ssy] = $HlandIce;
								$landValue->[$ssx][$ssy] = 0;
								# 포상금
								my($value) = $HmonsterValue[$tKind];
								$island->{'money'} += $value;
								logMsMonMoney($id, $tName, $value);
							}
						}
					} else {
						# 전체 동결 플래그
						$land->[$ssx][$ssy] = $HlandIce; # 빙하가 됨
						$landValue->[$ssx][$ssy] = 0;
					}

					# 로그 생성
					logMonsCold($id, $name, landName($kind, $lv), "($ssx, $ssy)", $mName);
				}
			}

			if(($mKind == 14) && ($island->{'monsterlive'} < 7)) { # 슬라임 레전드 분열
				my($i, $ssx, $ssy, $ssL, $ssLv);
				for($i = 1; $i < 7; $i++) {
					$ssx = $sx + $ax[$i];
					$ssy = $sy + $ay[$i];

					# 행 기준 위치 조정
					$ssx-- if(!($ssy % 2) && ($sy % 2));
					# 범위 밖
					next if(($ssx < 0) || ($ssx> $islandSize) || ($ssy < 0) || ($ssy> $islandSize));

					$ssL = $land->[$ssx][$ssy];
					$ssLv = $landValue->[$ssx][$ssy];

					unless(($ssL == $HlandSea) ||
						($ssL == $HlandSeacity) ||
						($ssL == $HlandIce) ||
						($ssL == $HlandUmishuto) ||
						($ssL == $HlandSeatown) ||
						($ssL == $HlandOil) ||
						($ssL == $HlandFune) ||
						($ssL == $HlandNursery) ||
						($ssL == $HlandUmiamu) ||
						($ssL == $HlandMountain) ||
						($ssL == $HlandGold) ||
						($ssL == $HlandShrine) ||
						($ssL == $HlandOnsen) ||
						($ssL == $HlandMonster) ||
						($ssL == $HlandHugeMonster) ||
						($ssL == $HlandSbase)) {
						# 바다계와 해저 기지, 산계에는 분열하지 않음
						# 분열
						my $nKind = 11;
						$lv = ($nKind << 4) + $HmonsterBHP[$nKind] + random($HmonsterDHP[$nKind]);
						$land->[$ssx][$ssy] = $HlandMonster;
						$landValue->[$ssx][$ssy] = $lv;
						$island->{'monspnt'}->[$island->{'monsterlive'}] = { x => $ssx, y => $ssy };
						$island->{'monsterlive'}++;
					}
					if (random(1000) < 50) {
						$land->[$ssx][$ssy] = $HlandMonument;
						$landValue->[$ssx][$ssy] = 77;
					}

					# 로그 생성
					lognewMonsterBorn($id, $name, "($ssx, $ssy)");
				}
			}

			# 이동 완료 플래그
			if($HmonsterSpecial[$mKind] == 2) {
				# 이동 완료 플래그가 설정되어 있지 않음
			} elsif($HmonsterSpecial[$mKind] == 1) {
				# 속이괴수
				$monsterMove[$sx][$sy] = $monsterMove[$x][$y] + 1;
			} else {
				# 일반 괴수
				$monsterMove[$sx][$sy] = 2;
			}

			if(($sL == $HlandDefence) && $HdBaseAuto) {
				# 방위 시설을 밟습니다
				logMonsMoveDefence($id, $name, $sName, $point, $mName);
				# 광역 피해 루틴
				wideDamage($id, $name, $land, $landValue, $sx, $sy);
			} elsif($sL == $HlandMine) {
				# 지뢰를 밟습니다
				if($mHp < $sLv) {
					# 사망하고 시체가 흩어짐
					logMonsMine($id, $name, $sName, $point, $mName, "사라졌습니다.");
				} elsif($mHp == $sLv) {
					# 사망하고 시체가 남음
					logMonsMine($id, $name, $sName, $point, $mName, "힘이 다해 쓰러졌습니다.");

					# 수입
					my($value) = $HmonsterValue[$mKind];
					if($value> 0) {
						$island->{'money'} += $value;
						logMsMonMoney($id, $mName, $value);
					}
					# 괴수퇴치 수
					$island->{'taiji'}++;
					# 수상 관계
					my($prize) = $island->{'prize'};
					my($prize1, $prize2) = split(/\t/, $prize);
					$prize1 =~ /([0-9]*),([0-9]*),(.*)/;
					my($flags) = $1;
					my($monsters) = $2;
					my($turns) = $3;
					my($v) = 2 ** $mKind;
					$monsters |= $v;
					$island->{'prize'} = "$flags,$monsters,$turns\t$prize2";
				} else {
					# 살아남음했음
					logMonsMine($id, $name, $sName, $point, $mName, "고통스러운 듯 포효했습니다.");
					$landValue->[$sx][$sy] -= $sLv;
					next;
				}

				# 괴수는 황무지에
				$land->[$sx][$sy] = $HlandWaste;
				$landValue->[$sx][$sy] = 1;
			} else {
				# 이동 로그
				logMonsMove($id, $name, $sName, $point, $mName) if ($sL != $HlandWaste);
			}

		} elsif($landKind == $HlandHugeMonster) {
			# 거대괴수
			next if($monsterMove[$x][$y] == 2);
			# 이미 이동한 후

			# 각 요소 꺼내기
			my($mKind, $mSea, $mHuge, $mName, $mHp) = hugeMonsterSpec($lv);
			next if($mHuge != 0);
			my($special) = $HhugeMonsterSpecial[$mKind];

			$island->{'migrateByMons'} = 1 if($special & 0x1000);
			# 경화 중?
			if((($special & 0x10) && ($HislandTurn % 2)) ||
				(($special & 0x40) && !(seqnum($HislandTurn) % 2)) ||
				(($special & 0x20) && !($HislandTurn % 2))) {
				# 경화 중
				next;
			}

			my($d, $d2, $sx, $sy, $ssx, $ssy, $dmove, $rebody);
			my($i, $j);
			# 거대괴수의 코어 이외를 일반 지형으로 되돌림
			for($i = 1; $i < 7; $i++) {
				next if($HhugeMonsterImage[$mKind][$i] eq '');
				$sx = $x + $ax[$i];
				$sy = $y + $ay[$i];

				# 행 기준 위치 조정
				$sx-- if (!($sy % 2) && ($y % 2));

				if($land->[$sx][$sy] != $HlandHugeMonster) {
					$rebody.= "$i";
					next;
				}
				# 각 요소 꺼내기
				my($mSea2, $mHuge2) = (hugeMonsterSpec($landValue->[$sx][$sy]))[1, 2];
				next if($mHuge2 != $i);
				if ($mSea2 < 2) {
					# 바다에있었음
					$land->[$sx][$sy] = $HlandSea;
					$landValue->[$sx][$sy] = $mSea2;
				} else {
					# 육지에있었음
					$land->[$sx][$sy] = $HlandWaste;
					$landValue->[$sx][$sy] = 0;
				}
			}
			# 이동 방향을 결정
			for($i = 0; $i < 3; $i++) {
				$d = random(6) + 1;
				$sx = $x + $ax[$d];
				$sy = $y + $ay[$d];
				# 행 기준 위치 조정
				$sx-- if(!($sy % 2) && ($y % 2));
				# 범위 밖 판정
				next if(($sx < 0) || ($sx> $islandSize) || ($sy < 0) || ($sy> $islandSize));

				$dmove = 0;
				for($j = 0; $j < 7; $j++) {
					next if($HhugeMonsterImage[$mKind][$j] eq '');
					$d2 = ($d + 3) % 6;
					$d2 = 6 if($d2 == 0);
					next if($j == $d2);
					$ssx = $sx + $ax[$j];
					$ssy = $sy + $ay[$j];
					# 행 기준 위치 조정
					$ssx-- if (!($ssy % 2) && ($sy % 2));

					# 범위 밖 판정
					if(($ssx < 0) || ($ssx> $islandSize) || ($ssy < 0) || ($ssy> $islandSize)) {
						$dmove = 1;
						next;
					}
					my $l = $land->[$ssx][$ssy];
					# 괴수, 산, 기념비이면 이동하지 않음
					if(($l == $HlandGold) ||
						($l == $HlandShrine) ||
						($l == $HlandMountain) ||
						($l == $HlandMonument) ||
						($l == $HlandRottenSea) ||
						($l == $HlandHugeMonster) ||
						($l == $HlandMonster)) {
						$dmove = 1;
						next;
					}
				}
				next if($dmove);
				last;
			}
			# 작동없었습니다
			if($i == 3) {
				for($j = 1; $j < 7; $j++) {
					next if($HhugeMonsterImage[$mKind][$j] eq '');
					$sx = $x + $ax[$j];
					$sy = $y + $ay[$j];

					# 행 기준 위치 조정
					$sx-- if (!($sy % 2) && ($y % 2));
					# 이동할 수 없음 지형이면 복원하지 않음
					my $l = $land->[$sx][$sy];
					next if(($l == $HlandGold) ||
						(($l == $HlandDefence) && $HdBaseAuto) ||
						($l == $HlandShrine) ||
						($l == $HlandMountain) ||
						($l == $HlandMonument) ||
						($l == $HlandRottenSea) ||
						($l == $HlandHugeMonster) ||
						($l == $HlandMonster));

					my($mSea2);
					my $mHp2 = $mHp;

					if ($l == $HlandSea) {
						$mSea2 = $ssLv;
					} elsif ($l == $HlandWaste) {
						$mSea2 = 3;
					}
					if($rebody =~ /$i/) {
						next if(($special & 0x400) && (random(100)>= $HpRebody));
						logMonsRebody($id, $name, "($sx, $sy)", $mName);
					}
					$land->[$sx][$sy] = $HlandHugeMonster;
					$landValue->[$sx][$sy] = ($mKind<<9) + ($mSea2<<7) + ($j<<4) + $mHp2;
				}
				next;
			}

			# 이동한 위치의 지형에 따라 처리
			my($sL) = $land->[$sx][$sy];
			my($sLv) = $landValue->[$sx][$sy];
			my($sName) = landName($sL, $sLv);
			my($point) = "($sx, $sy)";

			# 이동
			my($msSea, $huge);
			$huge = 1;

			if($sL == $HlandSea) {
				$msSea = $sLv;
			} elsif(($sL == $HlandSbase) ||
				($sL == $HlandSeacity) ||
				($sL == $HlandSeatown) ||
				($sL == $HlandNursery) ||
				($sL == $HlandOil) ||
				($sL == $HlandFune) ||
				($sL == $HlandIce) ||
				($sL == $HlandFrocity) ||
				($sL == $HlandUmishuto) ||
				($sL == $HlandUmiamu)) {
				$msSea = 0;
			} elsif($sL == $HlandMine) {
				# 지뢰를 밟습니다
				$mHp -= $sLv;
				if($mHp < 0) {
					# 사망하고 시체가 흩어짐
					logMonsMine($id, $name, $sName, $point, $mName, "사라졌습니다.");
				} elsif($mHp == 0) {
					# 사망하고 시체가 남음
					logMonsMine($id, $name, $sName, $point, $mName, "힘이 다해 쓰러졌습니다.");

					# 수입
					my($value) = $HhugeMonsterValue[$mKind];
					if($value> 0) {
						$island->{'money'} += $value;
						logMsMonMoney($id, $mName, $value);
					}
					# 괴수퇴치 수
					$island->{'taiji'}++;
					# 수상 관계
					my($prize) = $island->{'prize'};
					my($prize1, $prize2) = split(/\t/, $prize);
					$prize1 =~ /([0-9]*),([0-9]*),(.*)/;
					my($flags) = $1;
					my($monsters) = $2;
					my($turns) = $3;
					my($prize2) = 2 ** $mKind;
					$monsters |= $v;
					$island->{'prize'} = "$flags,$monsters,$turns\t$prize2";
				} else {
					# 살아남음했음
					logMonsMine($id, $name, $sName, $point, $mName, "고통스러운 듯 포효했습니다.");
				}
#			} elsif($sL == $HlandHugeMonster) {
#				$msSea = (hugeMonsterSpec($sLv))[1];
			} else {
				$msSea = 3;
			}
			if($mHp < 1) {
				# 괴수 처치됨
				$land->[$sx][$sy] = $HlandWaste;
				$landValue->[$sx][$sy] = 1;
				$huge = 0;
			} else {
				# 이동 로그
				if($HhugeMonsterImage[$mKind][$d] eq '') {
					if(msSea2 < 2) {
						logMonsMoveSea($id, $name, $sName, $point, $mName);
					} else {
						logMonsMove($id, $name, $sName, $point, $mName);
					}
				}
				$land->[$sx][$sy] = $HlandHugeMonster;
				$landValue->[$sx][$sy] = ($mKind<<9) + ($msSea<<7) + $mHp;
			}
			# 원래있음타 위치
			if ($mSea < 2) {
				# 바다에있었음
				$land->[$x][$y] = $HlandSea;
				$landValue->[$x][$y] = $mSea;
			} else {
				# 육지에있었음
				$land->[$x][$y] = $HlandWaste;
				$landValue->[$x][$y] = 0;
			}

			my $dflag = 0;
			my($lName2, $point2);
			if($huge) {
				for($i = 1; $i < 7; $i++) {
					next if($HhugeMonsterImage[$mKind][$i] eq '');
					$ssx = $sx + $ax[$i];
					$ssy = $sy + $ay[$i];

					# 행 기준 위치 조정
					$ssx-- if (!($ssy % 2) && ($sy % 2));

					# 이동 대상의 지형에보안 되지
					my $ssL = $land->[$ssx][$ssy];
					my $ssLv = $landValue->[$ssx][$ssy];
					$lName2 = landName($land->[$ssx][$ssy], $landValue->[$ssx][$ssy]);
					$point2 = "($ssx, $ssy)";

					my($mSea2);
					my $mHp2 = $mHp;

					if($ssL == $HlandSea) {
						$mSea2 = $ssLv;
					} elsif(($ssL == $HlandSbase) ||
						($ssL == $HlandSeacity) ||
						($ssL == $HlandSeatown) ||
						($ssL == $HlandNursery) ||
						($ssL == $HlandOil) ||
						($ssL == $HlandIce) ||
						($ssL == $HlandFrocity) ||
						($ssL == $HlandUmishuto) ||
						($ssL == $HlandFune) ||
						($ssL == $HlandUmiamu)) {
						$mSea2 = 0;
					} elsif($ssL == $HlandMine) {
						# 지뢰를 밟습니다
						$mHp2 -= $ssLv;
						if($mHp2 < 0) {
							# 사망하고 시체가 흩어짐
							logMonsMine($id, $name, $lName2, $point2, $mName, "체의 일부가사라졌습니다.");
						} elsif($mHp2 == 0) {
							# 사망하고 시체가 남음
							logMonsMine($id, $name, $lName2, $point2, $mName, "체의 일부를 실패지금했습니다.");

							# 수입
							my($value) = $HhugeMonsterValue[$mKind];
							if($value> 0) {
								$island->{'money'} += $value;
								logMsMonMoney($id, $mName, $value);
							}
						} else {
							# 살아남음했음
							logMonsMine($id, $name, $lName2, $point2, $mName, "고통스러운 듯 포효했습니다.");
						}
#					} elsif($ssL == $HlandHugeMonster) {
#						$msSea2 = (hugeMonsterSpec($ssLv))[1];
					} elsif (($ssL == $HlandDefence) && $HdBaseAuto) {
						# 방위 시설을 밟습니다
						$dflag = 1;
						last;
					} else {
						$mSea2 = 3;
					}
					if($mHp2 < 1) {
						# 체의 일부를 실패했음
						$land->[$ssx][$ssy] = $HlandWaste;
						$landValue->[$ssx][$ssy] = 1;
					} else {
						if(($i == $d) && ($HhugeMonsterImage[$mKind][$d] ne '')) {
							if(mSea2 < 2) {
								logMonsMoveSea($id, $name, $sName, $point, $mName);
							} else {
								logMonsMove($id, $name, $sName, $point, $mName);
							}
						}
						if($rebody =~ /$i/) {
							next if(($special & 0x400) && (random(100)>= $HpRebody));
							logMonsRebody($id, $name, "($ssx, $ssy)", $mName);
						}
						$land->[$ssx][$ssy] = $HlandHugeMonster;
						$landValue->[$ssx][$ssy] = ($mKind<<9) + ($mSea2<<7) + ($i<<4) + $mHp2;
					}
				}
			}
# 이동 확인(디버그용)
#			if($id> 100) {
#				HdebugOut("turn=$HislandTurn : ($x,$y)->($sx,$sy) [$d] ::: ");
#				for($i = 0; $i < 7; $i++) {
#					next if($HhugeMonsterImage[$mKind][$i] eq '');
#					$ssx = $sx + $ax[$i];
#					$ssy = $sy + $ay[$i];
#					# 행 기준 위치 조정
#					$ssx-- if (!($ssy % 2) && ($sy % 2));
#					my($mSea3) = (hugeMonsterSpec($landValue->[$ssx][$ssy]))[1];
#					HdebugOut("[$i] $landValue->[$ssx][$ssy] ($mSea3)");
#				}
#				HdebugOut("\n");
#			}
			# 이동 완료 플래그
			if($HhugeMonsterSpecial[$mKind] & 0x2) {
				# 이동 완료 플래그가 설정되어 있지 않음
			} elsif($HhugeMonsterSpecial[$mKind] & 0x1) {
				# 속이괴수
				$monsterMove[$sx][$sy] = $monsterMove[$x][$y] + 1;
			} else {
				# 일반 괴수
				$monsterMove[$sx][$sy] = 2;
			}

			if ((($sL == $HlandDefence) || ($dflag)) && $HdBaseAuto) {
				($sName, $point, $sx, $sy) = ($lName2, $point2, $ssx, $ssy) if($dflag);
				# 방위 시설을 밟습니다
				logMonsMoveDefence($id, $name, $sName, $point, $mName);
				# 광역 피해 루틴
				wideDamage($id, $name, $land, $landValue, $sx, $sy);
			}
		}

		# 화재판정
		my $fflag = 0;
		if((($landKind == $HlandTown) && ($lv> 30)) ||
			($landKind == $HlandHaribote) ||
			($landKind == $HlandMinato) ||
			($landKind == $HlandFoodim) ||
			($landKind == $HlandOnsen) ||
			($landKind == $HlandHTFactory) ||
			($landKind == $HlandFactory)) {
			$fflag = 1;
		} elsif(($landKind == $HlandNewtown) ||
			($landKind == $HlandRizort) ||
			($landKind == $HlandBigRizort) ||
			($landKind == $HlandBettown) ||
			($landKind == $HlandBigtown)) {
			$fflag = 2;
		}

		if($fflag) {
			my $rfflag = ($fflag == 1) ? random(1000) : random(750);
			my $ffflag = 1 if(!$HnoDisFlag && $rfflag < $HdisFire[$Hmonth] - int($island->{'eis1'}/20));

			if($ffflag) {
				# 주변의 숲과 기념비를 흡수 가능
				my $fw = countAround($land, $x, $y, 7, $HlandForest, $HlandProcity, $HlandHouse, $HlandMonument);
				unless($fw) {
					# 없어진 경우 화재로 괴멸
					my($l) = $land->[$x][$y];
					my($lv) = $landValue->[$x][$y];
					my($point) = "($x, $y)";
					my($lName) = landName($l, $lv);
					if($fflag == 2) {
						logFirenot($id, $name, $lName, $point);
						$landValue->[$x][$y] -= random(100) + 50;
					}
					if($fflag == 1 || ($landValue->[$x][$y] <= 0)) {
						logFire($id, $name, $lName, $point);
						$land->[$x][$y] = $HlandWaste;
						$landValue->[$x][$y] = 0;
						if ($l == $HlandOnsen) {
							# 금광산은 산에돌아가기
							$land->[$x][$y] = $HlandMountain; # 바다가 됨
							$landValue->[$x][$y] = 0;
						}
					}
				}
			}
		}
	}
}

# 주변의 읍, 농장이 있는 지반정
sub countGrow {
	my($land, $landValue, $x, $y) = @_;
	my($i, $sx, $sy);
	for($i = 1; $i < 7; $i++) {
		$sx = $x + $ax[$i];
		$sy = $y + $ay[$i];

		# 행 기준 위치 조정
		$sx-- if(!($sy % 2) && ($y % 2));

		if((($sx>= 0) && ($sx < $HislandSize) && ($sy>= 0) && ($sy < $HislandSize)) && # 범위 안의 경우
			(($land->[$sx][$sy] == $HlandTown) ||
			($land->[$sx][$sy] == $HlandProcity) ||
			($land->[$sx][$sy] == $HlandNewtown) ||
			($land->[$sx][$sy] == $HlandRizort) ||
			($land->[$sx][$sy] == $HlandBigRizort) ||
			($land->[$sx][$sy] == $HlandBettown) ||
			($land->[$sx][$sy] == $HlandBigtown) ||
			($land->[$sx][$sy] == $HlandFarm))) {
				return 1 if($landValue->[$sx][$sy] != 1);
		}
	}
	return 0;
}

# 실업자는 어디로?
sub doIslandunemployed {
	my($number, $island) = @_;

	# 도출 값
	my($name) = islandName($island);
	my($id) = $island->{'id'};
	my($land) = $island->{'land'};
	my($landValue) = $island->{'landValue'};

	# 실업자의 이민
	if((($island->{'unemployed'}>= 100) || ($island->{'migrateByMons'})) && (random(100) < 25)) {
		# 실업자가1만 명이상있으면 25% 확률로 이민을 희망하다
		my(@order) = randomArray($HislandNumber);
		my($migrate);
		# 이민선을 탐색
		my($tIsland);
		my($n) = min($HislandNumber, 5);
		my($i);
		my $unemployed = ($island->{'migrateByMons'}) ? int($island->{'pop'} * random(50) / 1000) : $island->{'unemployed'};
		my $str = ($island->{'migrateByMons'}) ? '거대괴수에서 도망됨' : '일을 요청하기';
		for($i = 0; $i < $n; $i++) { # 5섬까지조사하기
			$tIsland = $Hislands[$order[$i]];

			# 일자리가 있는 섬으로 이민
			if($tIsland->{'unemployed'} < 0) {
				$migrate = min($unemployed, -$tIsland->{'unemployed'});
				last;
			}
		}

		if($i>= $n) {
			# 이민선을 찾지 못하면 폭동 또는 구직 이동

			$migrate = random($unemployed - 100) + 100;
			$n = 0;
			my($x, $y, $landKind, $lv);
			foreach $i (0..$pointNumber) {
				$x = $Hrpx[$i];
				$y = $Hrpy[$i];
				$landKind = $land->[$x][$y];
				$lv = $landValue->[$x][$y];

				if(($landKind == $HlandFarm) ||
					($landKind == $HlandFactory) ||
					($landKind == $HlandHTFactory) ||
					($landKind == $HlandFarmchi) ||
					($landKind == $HlandFarmpic) ||
					($landKind == $HlandFarmcow) ||
					($landKind == $HlandCollege) ||
					($landKind == $HlandBase) ||
					($landKind == $HlandFoodim) ||
					($landKind == $HlandNursery) ||
					($landKind == $HlandMine) ||
					($landKind == $HlandPark) ||
					($landKind == $HlandKyujo) ||
					($landKind == $HlandKyujo) ||
					($landKind == $HlandKyujokai)) {
					# 25% 확률로 괴멸
					if(random(100) < 25) {
						$n++;
						logUnemployedRiot($id, $name, landName($landKind, $lv), $migrate, "($x, $y)", $str);
						$land->[$x][$y] = $HlandWaste;
						$landValue->[$x][$y] = 0;
					}
				}
			}

			# 아무것도 파괴하지 못했을 때도 진행 처리
			logUnemployedDemo($id, $name, $migrate, $str) if(!$n);

		} else {
			# 이민선이보기사용했음이므로 이민
			my($tLand) = $tIsland->{'land'};
			my($tLandValue) = $tIsland->{'landValue'};

			my($employed) = $migrate;
			my($x, $y, $landKind, $lv);
			foreach $i (0..$pointNumber) {
				$x = $Hrpx[$i];
				$y = $Hrpy[$i];
				$landKind = $tLand->[$x][$y];
				$lv = $tLandValue->[$x][$y];

				if($landKind == $HlandSeki) {
					logUnemployedReturn($id, $tIsland->{'id'}, $name, landName($landKind, $lv), islandName($tIsland), $migrate, $str);
					return 1;
				}
			}

			# 이민선의 읍에가를 준비하다
			my($employed) = $migrate;
			my($x, $y, $landKind, $lv);
			foreach $i (0..$pointNumber) {
				$x = $Hrpx[$i];
				$y = $Hrpy[$i];
				$landKind = $tLand->[$x][$y];
				$lv = $tLandValue->[$x][$y];

				if(($landKind == $HlandOnsen) || # 100
					($landKind == $HlandTown) || # 200
					($landKind == $HlandMinato) || # 200
					($landKind == $HlandSeacity) || # 200
					($landKind == $HlandFrocity) || # 200
					($landKind == $HlandNewtown)) { # 300
#					($landKind == $HlandProcity) || # 200
#					($landKind == $HlandSeatown) || # 400
#					($landKind == $HlandBigtown) || # 500
#					($landKind == $HlandBettown) || # 2000
#					($landKind == $HlandShuto) || # 4000
#					($landKind == $HlandUmishuto) # 4000
					# 읍
					my $nMax = ($landKind == $HlandNewtown) ? 300 : ($landKind == $HlandOnsen) ? 100 : 200;
					$n = int(($nMax - $lv) / 2);
					$n = min(int($n + random($n)), $employed);
					$employed -= $n;
					$tLandValue->[$x][$y] += $n;
				} elsif($landKind == $HlandPlains) {
					# 평지
					$n = int((200 - $lv) / 2);
					$n = min(int($n + random($n)), $employed);
					$employed -= $n;
					$tLand->[$x][$y] = $HlandTown;
					$tLandValue->[$x][$y] = $n;
				}
				last if($employed <= 0);
			}
			$migrate -= $employed;
			$island->{'unemployed'} -= $migrate;
			$tIsland->{'unemployed'} += $migrate;
			$island->{'pop'} -= $migrate;
			$tIsland->{'pop'} += $migrate;

			# 기존 거주지를 처분
			$employed = $migrate;
			foreach $i (0..$pointNumber) {
				$x = $Hrpx[$i];
				$y = $Hrpy[$i];
				$landKind = $land->[$x][$y];
				$lv = $landValue->[$x][$y];

				if(($lv> 1) && (($landKind == $HlandTown) || ($landKind == $HlandMinato) ||
					($landKind == $HlandProcity) || ($landKind == $HlandNewtown) ||
					($landKind == $HlandFrocity) || ($landKind == $HlandBettown) ||
					($landKind == $HlandShuto) || ($landKind == $HlandUmishuto) ||
					($landKind == $HlandBigtown) || ($landKind == $HlandSeatown) ||
					($landKind == $HlandOnsen) || ($landKind == $HlandSeacity))) {
					# 읍
					$n = min($lv - 1, $employed);
					$landValue->[$x][$y] -= $n;
					$employed -= $n;
				}
				last if($employed <= 0);
			}

			logUnemployedMigrate($id, $tIsland->{'id'}, $name, islandName($tIsland), $migrate, $str);
			# 재난상판정 때문에 에이민을 기억
			$island->{'migrate'} = $migrate if(!$island->{'migrateByMons'});
		}
	}
}

# 섬 전체
sub doIslandProcess {
	my($number, $island) = @_;

	# 도출 값
	my($name) = islandName($island);
	my($id) = $island->{'id'};
	my($land) = $island->{'land'};
	my($landValue) = $island->{'landValue'};
	my $disdown = 1;
	if($HallyDisDown && ($island->{'allyId'}[0] ne '')) {
		$disdown = $HallyDisDown;
	}

	# 수입 로그(정리해서 로그 출력)
	logOilMoney($id, $name, "유전", "", "총액$island->{'oilincome'}${HunitMoney}", "수익") if($HlogOmit1 && ($island->{'oilincome'}> 0));
	logOilMoney($id, $name, "놀이공원", "", "총액$island->{'parkincome'}${HunitMoney}", "수익") if($HlogOmit1 && ($island->{'parkincome'}> 0));
	logParkEventf($id, $name, "어업조합", "", "총어업획득고$island->{'fishcatch'}${HunitFood}") if($HlogOmit1 && ($island->{'fishcatch'}> 0));

	if ($island->{'stsankahantei'} == 1) {
		$value = $Hstsanka*random(2000);
		$island->{'money'} += $value;
		logHCstart($id, $name, "$value$HunitMoney");
	}

	if ($island->{'htf'}> 0) {
		$pika2 = int($island->{'pika'}/2);
		if ($pika2 < 0) {
			$pika2 = 0;
		}
		$island->{'money'} -= $pika2;
	}

	# 지진판정
	if(($HpunishInfo{$id}->{punish} == 1) || (!$HnoDisFlag && random(1000) < int(($island->{'prepare2'} + 1) * $HdisEarthquake[$Hmonth] * $disdown - $island->{'eis2'}/15))) {
		# 지진발생
		logEarthquake($id, $name);

		my($x, $y, $landKind, $lv, $i);
		foreach $i (0..$pointNumber) {
			$x = $Hrpx[$i];
			$y = $Hrpy[$i];
			$landKind = $land->[$x][$y];
			$lv = $landValue->[$x][$y];

			if((($landKind == $HlandTown) && ($lv>= 100)) ||
				(($landKind == $HlandFoodim) && ($lv < 480)) ||
				(($landKind == $HlandProcity) && ($lv < 130)) ||
				($landKind == $HlandHaribote) ||
				($landKind == $HlandPark) ||
				($landKind == $HlandMinato) ||
				($landKind == $HlandOnsen) ||
				($landKind == $HlandKyujo) ||
				($landKind == $HlandKyujokai) ||
				($landKind == $HlandFactory)) {
				# 1/4에서 괴멸
				if(!random(4+$island->{'co5'}*5)) {
					logDamageAny($id, $name, landName($landKind, $lv), "($x, $y)", "${HtagDisaster_}지진${H_tagDisaster}으로 괴멸되었습니다.");
					$land->[$x][$y] = $HlandWaste;
					$landValue->[$x][$y] = 0;
					if ($landKind == $HlandOnsen) {
						# 온천은 산에돌아가기
						$land->[$x][$y] = $HlandMountain; # 바다가 됨
						$landValue->[$x][$y] = 0;
					}
				}
			}
			if((($landKind == $HlandBigtown) && ($lv>= 100)) ||
				(($landKind == $HlandBettown) && ($lv>= 100)) ||
				(($landKind == $HlandShuto) && ($lv>= 100)) ||
				(($landKind == $HlandUmishuto) && ($lv>= 100)) ||
				(($landKind == $HlandRizort) && ($lv>= 10)) ||
				(($landKind == $HlandBigRizort) && ($lv>= 10)) ||
				(($landKind == $HlandHTFactory) && ($lv>= 10)) ||
				(($landKind == $HlandNewtown) && ($lv>= 100))) {
				# 1/4에서 괴멸
				if(!random(3+$island->{'co5'}*5)) {
					logDamageAny($id, $name, landName($landKind, $lv), "($x, $y)", "${HtagDisaster_}지진${H_tagDisaster}로 피해를 받했습니다.");
					$landValue->[$x][$y] -= random(100)+50;
				}
				if($landValue->[$x][$y] <= 0) {
					# 평지로 되돌리기
					$land->[$x][$y] = $HlandWaste;
					$landValue->[$x][$y] = 0;
					logDamageAny($id, $name, landName($landKind, $lv), "($x, $y)", "${HtagDisaster_}지진${H_tagDisaster}으로 괴멸되었습니다.");
					next;
				}
			}
			if(($landKind == $HlandFarmchi) ||
				($landKind == $HlandFarmpic) ||
				($landKind == $HlandFarmcow)) {
				if(!random(6)) {
					logDamageAny($id, $name, landName($landKind, $lv), "($x, $y)", "${HtagDisaster_}지진${H_tagDisaster}로 피해를 받했습니다.");
					$landValue->[$x][$y] -= random(400)+50;
				}
				if($landValue->[$x][$y] <= 0) {
					# 평지로 되돌리기
					$land->[$x][$y] = $HlandWaste;
					$landValue->[$x][$y] = 0;
					logDamageAny($id, $name, landName($landKind, $lv), "($x, $y)", "${HtagDisaster_}지진${H_tagDisaster}으로 괴멸되었습니다.");
					next;
				}
			}
		}
	}

	# 중과 세에키됨주민
	if(random(100) < int(($island->{'eisei1'} - 10 - random(5)) * $disdown)) {
		# 부족 메시지
		logKire($id, $name);

		my($x, $y, $landKind, $lv, $i);
		foreach $i (0..$pointNumber) {
			$x = $Hrpx[$i];
			$y = $Hrpy[$i];
			$landKind = $land->[$x][$y];
			$lv = $landValue->[$x][$y];

			if(($landKind == $HlandFarm) ||
				($landKind == $HlandCollege) ||
				($landKind == $HlandFactory) ||
				($landKind == $HlandHTFactory) ||
				($landKind == $HlandNursery) ||
				($landKind == $HlandBase) ||
				($landKind == $HlandPark) ||
				($landKind == $HlandKyujo) ||
				($landKind == $HlandKyujokai) ||
				($landKind == $HlandHouse) ||
				($landKind == $HlandDefence)) {
				# 1/4에서 괴멸
				if(random(100) < $island->{'eisei1'}) {
					logKireDamage($id, $name, landName($landKind, $lv), "($x, $y)");
					$land->[$x][$y] = $HlandWaste;
					$landValue->[$x][$y] = 0;
					# 양식장이면 얕은 바다
					if($landKind == $HlandNursery) {
						$land->[$x][$y] = $HlandSea;
						$landValue->[$x][$y] = 1;
					}
				}
			}
			if(($landKind == $HlandTown) ||
				($landKind == $HlandMinato) ||
				($landKind == $HlandFoodim) ||
				($landKind == $HlandProcity) ||
				($landKind == $HlandFarmchi) ||
				($landKind == $HlandFarmpic) ||
				($landKind == $HlandFarmcow)) {
				# 1/4에서 괴멸
				if(random(100) < $island->{'eisei1'}-30) {
					logKireDamage($id, $name, landName($landKind, $lv), "($x, $y)");
					$land->[$x][$y] = $HlandWaste;
					$landValue->[$x][$y] = 0;
				}
			}
			if(($landKind == $HlandSbase) ||
				($landKind == $HlandSeacity) ||
				($landKind == $HlandUmiamu) ||
				($landKind == $HlandFrocity)) {
				# 1/4에서 괴멸
				if(random(100) < $island->{'eisei1'}-60) {
					logKireDamage($id, $name, landName($landKind, $lv), "($x, $y)");
					$land->[$x][$y] = $HlandSea;
					$landValue->[$x][$y] = 0;
				}
			}
		}
	}

	# 식량 부족
	if(($island->{'food'} <= 0) && ($id <= 100)) {
		# 부족 메시지
		logStarve($id, $name);
		$island->{'food'} = 0;

		my($x, $y, $landKind, $lv, $i);
		foreach $i (0..$pointNumber) {
			$x = $Hrpx[$i];
			$y = $Hrpy[$i];
			$landKind = $land->[$x][$y];
			$lv = $landValue->[$x][$y];

			if(($landKind == $HlandFarm) ||
				($landKind == $HlandFoodim) ||
				($landKind == $HlandFarmchi) ||
				($landKind == $HlandFarmpic) ||
				($landKind == $HlandFarmcow) ||
				($landKind == $HlandFactory) ||
				($landKind == $HlandHTFactory) ||
				($landKind == $HlandCollege) ||
				($landKind == $HlandNursery) ||
				($landKind == $HlandBase) ||
				($landKind == $HlandMine) ||
				($landKind == $HlandDefence)) {
				# 1/4에서 괴멸
				if(!random(4)) {
					logSvDamage($id, $name, landName($landKind, $lv), "($x, $y)");
					$land->[$x][$y] = $HlandWaste;
					$landValue->[$x][$y] = 0;
					# 양식장이면 얕은 바다
					if($landKind == $HlandNursery) {
						$land->[$x][$y] = $HlandSea;
						$landValue->[$x][$y] = 1;
					}
				}
			}
		}
	}

	# 쓰나미판정
	if(($HpunishInfo{$id}->{punish} == 2) || (!$HnoDisFlag && random(1000) < int($HdisTsunami[$Hmonth] * $disdown - $island->{'eis2'}/15))) {
		# 쓰나미발생
		logTsunami($id, $name);

		my($x, $y, $landKind, $lv, $i);
		foreach $i (0..$pointNumber) {
			$x = $Hrpx[$i];
			$y = $Hrpy[$i];
			$landKind = $land->[$x][$y];
			$lv = $landValue->[$x][$y];

			if(($landKind == $HlandTown) ||
				(($landKind == $HlandProcity) && ($lv < 110)) ||
				($landKind == $HlandFarm) ||
				($landKind == $HlandFarmchi) ||
				($landKind == $HlandFarmpic) ||
				($landKind == $HlandFarmcow) ||
				($landKind == $HlandFoodim) ||
				($landKind == $HlandFactory) ||
				($landKind == $HlandHTFactory) ||
				($landKind == $HlandCollege) ||
				($landKind == $HlandBase) ||
				($landKind == $HlandDefence) ||
				($landKind == $HlandPark) ||
				($landKind == $HlandMinato) ||
				($landKind == $HlandFune) ||
				($landKind == $HlandSeki) ||
				($landKind == $HlandMine) ||
				($landKind == $HlandNursery) ||
				($landKind == $HlandKyujo) ||
				($landKind == $HlandKyujokai) ||
				($landKind == $HlandBettown) ||
				($landKind == $HlandRizort) ||
				($landKind == $HlandBigRizort) ||
				($landKind == $HlandShuto) ||
				($landKind == $HlandNewtown) ||
				($landKind == $HlandBigtown) ||
				($landKind == $HlandHaribote)) {
				# 1d12 <= (주변의 바다 - 1) 데붕괴
				my @seas = @Hseas;
				pop(@seas);
				if(random(12+$island->{'co5'}*5) < (countAround($land, $x, $y, 7, @seas) - 1)) {
					logDamageAny($id, $name, landName($landKind, $lv), "($x, $y)", "${HtagDisaster_}쓰나미${H_tagDisaster}로 붕괴했습니다.");
					if($landKind == $HlandFune) {
						$land->[$x][$y] = $HlandSea;
						$landValue->[$x][$y] = 0;
						# 양식장이면 얕은 바다
					} elsif($landKind == $HlandNursery) {
						$land->[$x][$y] = $HlandSea;
						$landValue->[$x][$y] = 1;
					} else {
						$land->[$x][$y] = $HlandWaste;
						$landValue->[$x][$y] = 0;
					}
				}
			}
		}
	}

	# 괴수판정
	my($r, $pop);
	if($island->{'id'}> 100) {
		$r = random(5000);
		$pop = 0;
		my $i;
		foreach $i ($HbfieldNumber..$islandNumber) {
			$pop += $Hislands[$i]->{'missile'} * 100; # 발사 가능 미사일총 수×10000인
		}
		$pop = $HdisMonsBorder1 if($pop < $HdisMonsBorder1);
	} else {
		$r = random(10000);
		$pop = $island->{'pop'};
	}
	$r = $HdisMonster * $island->{'area'} if ($HnoDisFlag);
	$r = 0 if ($HpunishInfo{$id}->{punish} == 3);
	do{
		if((($r < int($HdisMonster[$Hmonth] * $disdown * $island->{'area'})) &&
			($pop>= $HdisMonsBorder1)) || ($island->{'monstersend'}> 0)) {
			# 괴수출현
			# 종류를 결하기
			my($lv, $kind);
			if($island->{'monstersend'}) {
				# 인공
				$kind = 0;
				$island->{'monstersend'}--;
			} elsif($pop>= $HdisMonsBorder4) {
				# level4까지
				$kind = random($HmonsterLevel4) + 1;
			} elsif($pop>= $HdisMonsBorder3) {
				# level3까지
				$kind = random($HmonsterLevel3) + 1;
			} elsif($pop>= $HdisMonsBorder2) {
				# level2까지
				$kind = random($HmonsterLevel2) + 1;
			} else {
				# level1만
				$kind = random($HmonsterLevel1) + 1;
			}

			# lv 의 값을 결하기
			$lv = ($kind << 4) + $HmonsterBHP[$kind] + random($HmonsterDHP[$kind]);

			# 어디에 출현할지 결정
			my($bx, $by, $i);
			foreach $i (0..$pointNumber) {
				$bx = $Hrpx[$i];
				$by = $Hrpy[$i];
				if(($land->[$bx][$by] == $HlandTown) ||
					($land->[$bx][$by] == $HlandBigtown) ||
					($land->[$bx][$by] == $HlandBettown) ||
					($land->[$bx][$by] == $HlandRizort) ||
					($land->[$bx][$by] == $HlandBigRizort) ||
					($land->[$bx][$by] == $HlandNewtown)) {

					# 지형 이름
					my($lName) = landName($land->[$bx][$by], $landValue->[$bx][$by]);

					# 해당 헥스를 괴수로
					$land->[$bx][$by] = $HlandMonster;
					$landValue->[$bx][$by] = $lv;

					# 괴수 정보
					my($mKind, $mName, $mHp) = monsterSpec($lv);

					# 메시지
					logMonsCome($id, $name, $mName, "($bx, $by)", $lName);
					last;
				}
			}
		}
	} while($island->{'monstersend'});

	# 거대괴수판정
	if($island->{'id'}> 100) {
		$r = random(5000);
		$pop = $HdisHugeBorder;
	} else {
		$r = random(10000);
		$pop = $island->{'pop'};
	}
	$r = $HdisHuge * $island->{'area'} if ($HnoDisFlag);
	$r = 0 if ($HpunishInfo{$id}->{punish} == 9);
	$HdisHuge = 0 if(!$HhugeMonsterAppear);
	do{
		if((($r < int($HdisHuge * $disdown * $island->{'area'})) &&
			($pop>= $HdisHugeBorder)) || ($island->{'hmonstersend'}> 0)) {
			# 괴수출현
			# 종류를 결하기
			my($lv, $kind);
			if($island->{'hmonstersend'}) {
				# 인공
				$kind = 0;
				$island->{'hmonstersend'}--;
			} elsif($pop>= $HdisHugeBorder) {
				$kind = random($HhugeMonsterNumber);
			}

			# 어디에 출현할지 결정
			my($bx, $by, $i, $j, $monsflag);
			foreach $i (0..$pointNumber) {
				$bx = $Hrpy[$i];
				$by = $Hrpx[$i];
				next if(($bx < 1) || ($bx>= $islandSize) || ($by < 1) || ($by>= $islandSize));
				next if(countAround($land, $bx, $by, 7, $HlandGold, $HlandDefence, $HlandShrine, $HlandMountain, $HlandMonument, $HlandRottenSea, $HlandHugeMonster, $HlandMonster));

				# 지형 이름
				my($lName) = landName($land->[$bx][$by], $landValue->[$bx][$by]);
				my($sx, $sy, $mSea);

				# 메시지
				logMonsCome($id, $name, $HhugeMonsterName[$kind], "($bx, $by)", $lName);
				for($i = 0; $i < 7; $i++) {
					next if($HhugeMonsterImage[$kind][$i] eq '');
					$sx = $bx + $ax[$i];
					$sy = $by + $ay[$i];
					# 행 기준 위치 조정
					$sx-- if(!($sy % 2) && ($by % 2));
					my $ssL = $land->[$sx][$sy];
					my $ssLv = $landValue->[$sx][$sy];

					if($ssL == $HlandSea) {
						$mSea = $ssLv;
					} elsif(($ssL == $HlandSbase) ||
						($ssL == $HlandSeacity) ||
						($ssL == $HlandSeatown) ||
						($ssL == $HlandNursery) ||
						($ssL == $HlandOil) ||
						($ssL == $HlandIce) ||
						($ssL == $HlandFrocity) ||
						($ssL == $HlandUmishuto) ||
						($ssL == $HlandFune) ||
						($ssL == $HlandUmiamu)) {
						$mSea = 0;
					} else {
						$mSea = 3;
					}
					# lv 의 값을 결하기
					$lv = ($kind<<9) + ($mSea<<7) + ($i<<4) + $HhugeMonsterBHP[$kind] + random($HhugeMonsterDHP[$kind]);
					# 해당 헥스를 괴수로
					$land->[$sx][$sy] = $HlandHugeMonster;
					$landValue->[$sx][$sy] = $lv;

				}
				last
			}
		}
	} while($island->{'hmonstersend'});

	# 지반 침하판정
	if((($HpunishInfo{$id}->{punish} == 4) || (!$HnoDisFlag && random(1000) < int($HdisFalldown[$Hmonth] * $disdown))) && ($island->{'area'}> $HdisFallBorder)) {
		# 지반 침하발생
		logFalldown($id, $name);

		my($x, $y, $landKind, $lv, $i);
		foreach $i (0..$pointNumber) {
			$x = $Hrpx[$i];
			$y = $Hrpy[$i];
			$landKind = $land->[$x][$y];
			$lv = $landValue->[$x][$y];

			if(($landKind != $HlandSea) &&
				($landKind != $HlandSbase) &&
				($landKind != $HlandIce) &&
				($landKind != $HlandSeacity) &&
				($landKind != $HlandSeatown) &&
				($landKind != $HlandFune) &&
				($landKind != $HlandUmishuto) &&
				($landKind != $HlandUmiamu) &&
				($landKind != $HlandOil) &&
				($landKind != $HlandGold) &&
				($landKind != $HlandShrine) &&
				($landKind != $HlandOnsen) &&
				($landKind != $HlandHugeMonster) &&
				($landKind != $HlandMountain)) {

				# 주변에 바다가 있다면, 값을-1에
				my @seas = @Hseas;
				pop(@seas);
				pop(@seas);
				if(countAround($land, $x, $y, 7, @seas)) {
					logDamageAny($id, $name, landName($landKind, $lv), "($x, $y)", "바다의 안로 침몰봄했습니다.");
					$land->[$x][$y] = -1;
					$landValue->[$x][$y] = 0;
				}
			}
		}

		foreach $i (0..$pointNumber) {
			$x = $Hrpx[$i];
			$y = $Hrpy[$i];
			$landKind = $land->[$x][$y];

			if($landKind == -1) {
				# -1에나하고 있는 장소를 얕은 바다에
				$land->[$x][$y] = $HlandSea;
				$landValue->[$x][$y] = 1;
			} elsif($landKind == $HlandSea) {
				# 얕은 바다는 바다에
				$landValue->[$x][$y] = 0;
			}

		}
	}

	# 태풍판정
	if(($HpunishInfo{$id}->{punish} == 5) || (!$HnoDisFlag && random(1000) < int($HdisTyphoon[$Hmonth] * $disdown - $island->{'eis1'}/10))) {
		# 태풍발생
		logTyphoon($id, $name);

		my($x, $y, $landKind, $lv, $i);
		foreach $i (0..$pointNumber) {
			$x = $Hrpx[$i];
			$y = $Hrpy[$i];
			$landKind = $land->[$x][$y];
			$lv = $landValue->[$x][$y];

			if(($landKind == $HlandFarm) || ($landKind == $HlandHaribote)) {
				# 1d12 <= (6 - 주변의 숲) 데붕괴
				if(random(12+$island->{'co5'}*5) < (6 - countAround($land, $x, $y, 7, $HlandForest, $HlandMonument))) {
					logDamageAny($id, $name, landName($landKind, $lv), "($x, $y)", "${HtagDisaster_}태풍${H_tagDisaster}으로 날아갔습니다.");
					$land->[$x][$y] = $HlandPlains;
					$landValue->[$x][$y] = 0;
				}
			}

			if((($landKind == $HlandFune) || ($landKind == $HlandNursery)) && (random(100+$island->{'co5'}*50) < 10)) {
				logDamageAny($id, $name, landName($landKind, $lv), "($x, $y)", "${HtagDisaster_}태풍${H_tagDisaster}에따라파손했습니다.");
				$land->[$x][$y] = $HlandSea;
				$landValue->[$x][$y] = 1;
			}
		}
	}

	# 거대운석판정
	if(($HpunishInfo{$id}->{punish} == 6) || (!$HnoDisFlag && random(1000) < int($HdisHugeMeteo[$Hmonth] * $disdown - $island->{'eis3'}/50))) {
		my($x, $y, $landKind, $lv, $point);

		# 낙하
		$x = random($HislandSize);
		$y = random($HislandSize);
		if ($HpunishInfo{$id}->{punish} == 6) {
			$x = $HpunishInfo{$id}->{x};
			$y = $HpunishInfo{$id}->{y};
		}
		$landKind = $land->[$x][$y];
		$lv = $landValue->[$x][$y];
		$point = "($x, $y)";

		# 메시지
		logHugeMeteo($id, $name, $point);

		# 광역 피해 루틴
		wideDamage($id, $name, $land, $landValue, $x, $y);
		if (random(1000) < 100) {
			$land->[$x][$y] = $HlandMonument;
			$landValue->[$x][$y] = 79;
		}
	}

	# 거대 미사일판정
	while($island->{'bigmissile'}) {
		$island->{'bigmissile'}--;
		my($x, $y, $landKind, $lv, $point);

		# 낙하
		$x = random($HislandSize);
		$y = random($HislandSize);
		$landKind = $land->[$x][$y];
		$lv = $landValue->[$x][$y];
		$point = "($x, $y)";

		# 메시지
		logMonDamage($id, $name, $point);

		# 광역 피해 루틴
		wideDamage($id, $name, $land, $landValue, $x, $y);
	}

	# 운석판정
	if(($HpunishInfo{$id}->{punish} == 7) || (!$HnoDisFlag && random(1000) < int($HdisMeteo[$Hmonth] * $disdown - $island->{'eis3'}/40))) {
		my($x, $y, $landKind, $lv, $lName, $point, $first);
		$first = 1;
		while(!random(2) || $first) {
			$first = 0;

			# 낙하
			$x = random($HislandSize);
			$y = random($HislandSize);
			$landKind = $land->[$x][$y];
			$lv = $landValue->[$x][$y];
			$point = "($x, $y)";
			$lName = landName($landKind, $lv);

			if(($landKind == $HlandSea) && !$lv){
				# 바다포차
				logMeteo($id, $name, $lName, $point, "시");
			} elsif(($landKind == $HlandMountain) || ($landKind == $HlandGold) || ($landKind == $HlandShrine) || ($landKind == $HlandOnsen)) {
				# 산, 금광산, 시간의 신전파괴
				logMeteo($id, $name, $lName, $point, ",<B>$lName</B>은 사라지고");
				$land->[$x][$y] = $HlandWaste;
				$landValue->[$x][$y] = 0;
				next;
			} elsif(($landKind == $HlandSbase) ||
					($landKind == $HlandSeacity) ||
					($landKind == $HlandSeatown) ||
					($landKind == $HlandFune) ||
					($landKind == $HlandUmishuto) ||
					($landKind == $HlandFrocity) ||
					($landKind == $HlandUmiamu)) {
				logMeteo($id, $name, $lName, $point, ",<B>$lName</B>은 붕괴시");
			} elsif($landKind == $HlandMonster) {
				logMeteoMonster($id, $name, $lName, $point);
			} elsif($landKind == $HlandHugeMonster) {
				my($mHuge) = (hugeMonsterSpec($lv))[2];
				next if(!$mHuge);
				logMeteoMonster($id, $name, $lName, $point);
			} elsif(($landKind == $HlandSea) || ($landKind == $HlandIce)) {
				# 얕은 바다
				logMeteo($id, $name, $lName, $point, "、 해저가 깎였습니다");
			} else {
				logMeteo($id, $name, $lName, $point, ", 일대가 수몰시");
			}
			$land->[$x][$y] = $HlandSea;
			$landValue->[$x][$y] = 0;
			if (random(1000) < 50) {
				$land->[$x][$y] = $HlandMonument;
				$landValue->[$x][$y] = 79;
			}
		}
	}

	# 분화 판정정
	if(($HpunishInfo{$id}->{punish} == 8) || (!$HnoDisFlag && random(1000) < int($HdisEruption[$Hmonth] * $disdown - $island->{'eis2'}/40))) {
		my($x, $y, $sx, $sy, $i, $landKind, $lv, $point);
		$x = random($HislandSize);
		$y = random($HislandSize);
		if ($HpunishInfo{$id}->{punish} == 8) {
			$x = $HpunishInfo{$id}->{x};
			$y = $HpunishInfo{$id}->{y};
		}
		$landKind = $land->[$x][$y];
		$lv = $landValue->[$x][$y];
		$point = "($x, $y)";
		my($mKind, $mSea, $mHuge, $mHp) = hugeMonsterSpec($lv);
		if(($landKind == $HlandHugeMonster) && !$mHuge) {
			logEruption2($id, $name, landName($landKind, $lv), $point, "체력이 최대가 되었습니다.");
			$mHp = 15;
			$landValue->[$x][$y] = ($mKind<<9) + ($mSea<<7) + ($mHuge<<4) + $mHp;
		} else {
			logEruption($id, $name, landName($landKind, $lv), $point);
			$land->[$x][$y] = $HlandMountain;
			$landValue->[$x][$y] = 0;
			if (random(1000) < 100) {
				$land->[$x][$y] = $HlandMonument;
				$landValue->[$x][$y] = 75;
			} elsif (random(1000) < 50) {
				$land->[$x][$y] = $HlandMonument;
				$landValue->[$x][$y] = 78;
			}
		}
		for($i = 1; $i < 7; $i++) {
			$sx = $x + $ax[$i];
			$sy = $y + $ay[$i];

			# 행 기준 위치 조정
			$sx-- if(!($sy % 2) && ($y % 2));

			$landKind = $land->[$sx][$sy];
			$lv = $landValue->[$sx][$sy];
			$point = "($sx, $sy)";

			if(($sx>= 0) && ($sx < $HislandSize) && ($sy>= 0) && ($sy < $HislandSize)) {
				# 범위 안의 경우
				$landKind = $land->[$sx][$sy];
				$lv = $landValue->[$sx][$sy];
				$point = "($sx, $sy)";
				if(($landKind == $HlandSea) ||
					($landKind == $HlandOil) ||
					($landKind == $HlandFune) ||
					($landKind == $HlandUmiamu) ||
					($landKind == $HlandIce) ||
					($landKind == $HlandFrocity) ||
					($landKind == $HlandUmishuto) ||
					($landKind == $HlandSeacity) ||
					($landKind == $HlandSeatown) ||
					($landKind == $HlandSbase)) {
					# 바다의 경우
					if(($lv == 1) || ($landKind == $HlandIce)) {
						# 얕은 바다
						logEruption2($id, $name, landName($landKind, $lv), $point, "육지가 되었습니다.");
					} else {
						logEruption2($id, $name, landName($landKind, $lv), $point, "해저가 융기하여, 얕은 바다가 되었습니다.");
						$land->[$sx][$sy] = $HlandSea;
						$landValue->[$sx][$sy] = 1;
						next;
					}
				} elsif(($landKind == $HlandMountain) ||
						($landKind == $HlandMonster) ||
						($landKind == $HlandHugeMonster) ||
						($landKind == $HlandGold) ||
						($landKind == $HlandShrine) ||
						($landKind == $HlandOnsen) ||
						($landKind == $HlandWaste)) {
					next;
				} else {
					# 그 외의 경우
					logEruption2($id, $name, landName($landKind, $lv), $point, "괴멸되었습니다.");
				}
				$land->[$sx][$sy] = $HlandWaste;
				$landValue->[$sx][$sy] = 0;

				if (random(1000) < 50) {
					$land->[$sx][$sy] = $HlandMonument;
					$landValue->[$sx][$sy] = 75;
				}
			}
		}
	}

	# 인공위성에너지감소
	my($kind, $i);
	for($i = 1; $i < 7; $i++) {
		$kind = 'eis'. $i;
		if($island->{$kind}) {
			$island->{$kind} -= random(2);
			if($island->{$kind} < 1) {
				$island->{$kind} = 0;
				logEiseiEnd($id, $name, $HeiseiName[$i]);
			}
		}
	}
	if($island->{'eis6'}) {
		my($i, $sx, $sy, $monsno);
		$monsno = $island->{'monsterlive'};
		if($monsno) {
			my($monsArray, $monspnt);
			$monsArray = $island->{'monspnt'};
			for($i = 0; $i < $monsno; $i++){
				$monspnt = $monsArray->[$i];
				($sx, $sy) = ($monspnt->{x}, $monspnt->{y});
				if($land->[$sx][$sy] == $HlandMonster){
					# 괴수가 있으면 그 괴수를 공격
					# 대상이 되는 괴수각 요소 꺼내기
					my($tKind, $tName, $tHp) = monsterSpec($landValue->[$sx][$sy]);
					my($tlv) = $landValue->[$sx][$sy];
					my($tspecial) = $HmonsterSpecial[$tKind];
					$point = int($island->{'rena'}/1000);
					logIreAttackt($id, $name, "비정상", $point, $tName, $tPoint);

					$island->{'eis6'} -= 10;

					$tHp -= int($island->{'rena'}/1000);
					$tlv -= int($island->{'rena'}/1000);
					$landValue->[$sx][$sy] = $tlv;
					if($tHp < 1){
						# 대상의 괴수가 쓰러져 황무지가 됨
						$land->[$sx][$sy] = $HlandWaste;
						$landValue->[$sx][$Sy] = 0;
						$island->{'monsterlive'} -= 1;
						# 포상금
						my($value) = $HmonsterValue[$tKind];
						$island->{'money'} += $value;
						logMsMonMoney($id, $tName, $value);
					}
					next;
				}
			}
		}
	}
}

# 수상 관계와 증가률 처리
sub doPrize {
	my($number, $island) = @_;

	# 도출 값
	my($name) = islandName($island);
	my($id) = $island->{'id'};

	# 식량이 넘치면 환전
	if($island->{'food'}> $HmaximumFood) {
		$island->{'money'} += int(($island->{'food'} - $HmaximumFood) / 10);
		$island->{'food'} = $HmaximumFood;
	}

	# 수입 확인
	$island->{'pika'} = $island->{'money'} - $island->{'oldMoney'};

	# 자금이 넘치면 잘라냄
	$island->{'money'} = $HmaximumMoney if($island->{'money'}> $HmaximumMoney);

	if($HallyNumber) {
		$gnp = int($island->{'money'} - $island->{'oldMoney'} + ($island->{'food'} - $island->{'oldFood'})/10);
		foreach (@{$island->{'allyId'}}) {
			${Hally[$HidToAllyNumber{$_}]->{'ext'}[2]} += $gnp;
		}
	}

	# 각종의 값을 계산
	estimate($number);

	# 번영, 재난상
	my($pop) = $island->{'pop'};
	my($damage) = $island->{'oldPop'} - $pop - $island->{'migrate'}; # 이민은 재해어려움에이레없음
	my($prize) = $island->{'prize'};
	my($prize1, $prize2) = split(/\t/, $prize);
	$prize1 =~ /([0-9]*),([0-9]*),(.*)/;
	my($flags) = $1;
	my($monsters) = $2;
	my($turns) = $3;

	$island->{'hamu'} = $island->{'pop'} - $island->{'oldPop'};
	$island->{'monta'} = $island->{'pts'} - $island->{'oldPts'};

	# 번영상
	if((!($flags & 1)) && $pop>= 3000){
		$flags |= 1;
		logPrize($id, $name, $Hprize[1]);
		if($island->{'sin'}> 0) {
			my($value, $str);
			$value = random(3001);
			$island->{'money'} += $value;
			$str = "$value$HunitMoney";
			# 수입 로그
			logSinMoney($id, $name, $str);
		}
		if($island->{'jin'}> 0) {
			my($value, $str);
			$value = random(3001);
			$island->{'money'} += $value;
			$str = "$value$HunitMoney";
			# 수입 로그
			logJinMoney($id, $name, $str);
		}
	} elsif((!($flags & 2)) && $pop>= 5000){
		$flags |= 2;
		logPrize($id, $name, $Hprize[2]);
		if($island->{'sin'}> 0) {
			my($value, $str);
			$value = random(4001);
			$island->{'money'} += $value;
			$str = "$value$HunitMoney";
			# 수입 로그
			logSinMoney($id, $name, $str);
		}
		if($island->{'jin'}> 0) {
			my($value, $str);
			$value = random(4001);
			$island->{'money'} += $value;
			$str = "$value$HunitMoney";
			# 수입 로그
			logJinMoney($id, $name, $str);
		}
	} elsif((!($flags & 4)) && $pop>= 10000){
		$flags |= 4;
		logPrize($id, $name, $Hprize[3]);
		if($island->{'sin'}> 0) {
			my($value, $str);
			$value = random(5001);
			$island->{'money'} += $value;
			$str = "$value$HunitMoney";
			# 수입 로그
			logSinMoney($id, $name, $str);
		}
		if($island->{'jin'}> 0) {
			my($value, $str);
			$value = random(5001);
			$island->{'money'} += $value;
			$str = "$value$HunitMoney";
			# 수입 로그
			logJinMoney($id, $name, $str);
		}
	}

	# 재난상
	if((!($flags & 64)) && $damage>= 500){
		$flags |= 64;
		logPrize($id, $name, $Hprize[7]);
	} elsif((!($flags & 128)) && $damage>= 1000){
		$flags |= 128;
		logPrize($id, $name, $Hprize[8]);
	} elsif((!($flags & 256)) && $damage>= 2000){
		$flags |= 256;
		logPrize($id, $name, $Hprize[9]);
	}

	$island->{'prize'} = "$flags,$monsters,$turns\t$prize2";
}

# 광역 피해 루틴
sub wideDamage {
	my($id, $name, $land, $landValue, $x, $y) = @_;
	my($sx, $sy, $i, $landKind, $landName, $lv, $point);

	for($i = 0; $i < 19; $i++) {
		$sx = $x + $ax[$i];
		$sy = $y + $ay[$i];

		# 행 기준 위치 조정
		$sx-- if(!($sy % 2) && ($y % 2));
		# 범위 밖 판정
		next if(($sx < 0) || ($sx> $islandSize) || ($sy < 0) || ($sy> $islandSize));

		$landKind = $land->[$sx][$sy];
		$lv = $landValue->[$sx][$sy];
		$landName = landName($landKind, $lv);
		$point = "($sx, $sy)";

		# 범위에 한분기
		if($i < 7) {
			# 중심 및 1헥스
			if($landKind == $HlandSea) {
				$landValue->[$sx][$sy] = 0;
				next;
			} elsif(($landKind == $HlandSbase) ||
					($landKind == $HlandSeacity) ||
					($landKind == $HlandSeatown) ||
					($landKind == $HlandUmishuto) ||
					($landKind == $HlandIce) ||
					($landKind == $HlandFrocity) ||
					($landKind == $HlandFune) ||
					($landKind == $HlandUmiamu) ||
					($landKind == $HlandOil)) {
				logDamageAny($id, $name, $landName, $point, "흔적도 없이 사라졌습니다.");
				$land->[$sx][$sy] = $HlandSea;
				$landValue->[$sx][$sy] = 0;
			} else {
				if($landKind == $HlandMonster) {
					my($mKind, $mName, $mHp) = monsterSpec($lv);
					next if((($mKind == 20) && !$i) || (($mKind == 21) && !$i));
					logWideDamageMonsterSea($id, $name, $landName, $point);
				} elsif($landKind == $HlandHugeMonster) {
					my($mSea, $mHuge) = (hugeMonsterSpec($lv))[1, 2];
					next if($mHuge == 0);
					logDamageAny($id, $name, $landName, $point, "체의 일부가사라졌습니다.");
				} else {
					logDamageAny($id, $name, $landName, $point, "<B>수몰</B>했습니다.");
				}
				$land->[$sx][$sy] = $HlandSea;
				if(!$i) {
					# 바다
					$landValue->[$sx][$sy] = 0;
				} else {
					# 얕은 바다
					$landValue->[$sx][$sy] = 1;
				}
			}
		} else {
			# 2헥스
			if(($landKind == $HlandWaste) ||
				($landKind == $HlandMountain) ||
				($landKind == $HlandGold) ||
				($landKind == $HlandShrine) ||
				($landKind == $HlandSea) ||
				($landKind == $HlandSbase) ||
				($landKind == $HlandSeacity) ||
				($landKind == $HlandSeatown) ||
				($landKind == $HlandOnsen) ||
				($landKind == $HlandIce) ||
				($landKind == $HlandUmishuto) ||
				($landKind == $HlandFrocity) ||
				($landKind == $HlandOil) ||
				($landKind == $HlandFune) ||
				($landKind == $HlandUmiamu)) {
				# 피해의 없음 지형
				next;
			} elsif($landKind == $HlandMonster) {
				logDamageAny($id, $name, $landName, $point, "사라졌습니다.");
				$land->[$sx][$sy] = $HlandWaste;
				$landValue->[$sx][$sy] = 0;
			} elsif($landKind == $HlandHugeMonster) {
				my($mSea, $mHuge) = (hugeMonsterSpec($lv))[1, 2];
				next if($mHuge == 0);
				logDamageAny($id, $name, $landName, $point, "체의 일부가사라졌습니다.");
				if ($mSea < 2) {
					# 바다, 얕은 바다에 있는
					$land->[$sx][$sy] = $HlandSea;
					$landValue->[$sx][$sy] = $mSea;
				} else {
					$land->[$sx][$sy] = $HlandWaste;
					$landValue->[$sx][$sy] = 0;
				}
			} else {
				logDamageAny($id, $name, $landName, $point, "한순간에 <B>황무지</B>가 되었습니다.");
				$land->[$sx][$sy] = $HlandWaste;
				$landValue->[$sx][$sy] = 0;
			}
		}
	}
}

# 광역 피해 루틴·미니
sub wideDamageli {
	my($target, $tName, $tLand, $tLandValue, $tx, $ty) = @_;
	my($sx, $sy, $i, $tL, $landName, $tLv, $point);

	for($i = 0; $i < 19; $i++) {
		$sx = $tx + $ax[$i];
		$sy = $ty + $ay[$i];

		# 행 기준 위치 조정
		$sx-- if(!($sy % 2) && ($ty % 2));
		# 범위 밖 판정
		next if(($sx < 0) || ($sx> $islandSize) || ($sy < 0) || ($sy> $islandSize));

		$tL = $tLand->[$sx][$sy];
		$tLv = $tLandValue->[$sx][$sy];
		$landName = landName($tL, $tLv);
		$point = "($sx, $sy)";

		if(($tL == $HlandSea) ||
			($tL == $HlandOil) ||
			($tL == $HlandWaste) ||
			($tL == $HlandSeacity) ||
			($tL == $HlandSeatown) ||
			($tL == $HlandIce) ||
			($tL == $HlandUmishuto) ||
			($tL == $HlandFrocity) ||
			($tL == $HlandFune) ||
			($tL == $HlandUmiamu) ||
			($tL == $HlandSbase)) {
			next;
		} elsif($tL == $HlandMonster) {
			logDamageAny($target, $tName, $landName, $point, "사라졌습니다.");
			$tLand->[$sx][$sy] = $HlandWaste;
			$tLandValue->[$sx][$sy] = 0;
		} elsif($tL == $HlandHugeMonster) {
			my($mSea, $mHuge) = (hugeMonsterSpec($tLv))[1, 2];
			next if($mHuge == 0);
			logDamageAny($target, $tName, $landName, $point, "체의 일부가사라졌습니다.");
			if ($mSea < 2) {
				# 바다, 얕은 바다에 있는
				$tLand->[$sx][$sy] = $HlandSea;
				$tLandValue->[$sx][$sy] = $mSea;
			} else {
				$tLand->[$sx][$sy] = $HlandWaste;
				$tLandValue->[$sx][$sy] = 0;
			}
		} else {
			logDamageAny($target, $tName, $landName, $point, "한순간에 <B>황무지</B>가 되었습니다.");
			$tLand->[$sx][$sy] = $HlandWaste;
			$tLandValue->[$sx][$sy] = 0;
		}
	}
}

# 지형의 호출분
sub landName {
	my($land, $lv) = @_;
	if($land == $HlandSea) {
		if($lv == 1) {
			return '얕은 바다';
		} else {
			return '바다';
		}
	} elsif($land == $HlandIce) {
		if($lv> 0) {
			return '천그럼스케이트장';
		} else {
			return '빙하';
		}
	} elsif($land == $HlandWaste) {
		return '황무지';
	} elsif($land == $HlandPlains) {
		return '평지';
	} elsif($land == $HlandTown) {
		if($lv < 30) {
			return '마을';
		} elsif($lv < 100) {
			return '읍';
		} else {
			return '도시';
		}
	} elsif($land == $HlandProcity) {
		return '방재 도시';
	} elsif($land == $HlandNewtown) {
		return '뉴타운';
	} elsif($land == $HlandBigtown) {
		return '현대 도시';
	} elsif($land == $HlandBettown) {
		return '휘하기 도시';
	} elsif($land == $HlandSeatown) {
		return '해저 신도시';
	} elsif($land == $HlandRizort) {
		return '리조트지';
	} elsif($land == $HlandBigRizort) {
		return '임시 해변 리조트 호텔';
	} elsif($land == $HlandShuto) {
		return '수도';
	} elsif($land == $HlandUmishuto) {
		return '해저 수도';
	} elsif($land == $HlandForest) {
		return '숲';
	} elsif($land == $HlandFarm) {
		return '농장';
	} elsif($land == $HlandFoodim) {
		if($lv < 480) {
			return '식품 연구소';
		} else {
			return '방재형식품 연구소';
		}
	} elsif($land == $HlandFarmchi) {
		return '양계장';
	} elsif($land == $HlandFarmpic) {
		return '양돈장';
	} elsif($land == $HlandFarmcow) {
		return '목장';

	} elsif($land == $HlandCollege) {
		if($lv == 0) {
			return '농업대학';
		} elsif($lv == 1) {
			return '공업대학';
		} elsif($lv == 2) {
			return '종합대학';
		} elsif($lv == 3) {
			return '군사대학';
		} elsif($lv == 4) {
			return '생물 대학(대기안)';
		} elsif($lv == 98) {
			return '생물 대학(대기안)';
		} elsif($lv == 96) {
			return '생물 대학(출입 금지안)';
		} elsif($lv == 97) {
			return '생물 대학(출입 금지안)';
		} elsif($lv == 99) {
			return '생물 대학(출동안)';
		} else {
			return '기상대학';
		}
	} elsif($land == $HlandHouse) {
		if($lv == 0) {
			return '오두막';
		} elsif($lv == 1) {
			return '간이주택';
		} elsif($lv == 2) {
			return '주택';
		} elsif($lv == 3) {
			return '고급주택';
		} elsif($lv == 4) {
			return '저택';
		} elsif($lv == 5) {
			return '대저택';
		} elsif($lv == 6) {
			return '고급 저택';
		} elsif($lv == 7) {
			return '성';
		} elsif($lv == 8) {
			return '거성';
		} else {
			return '황금성';
		}
	} elsif($land == $HlandFactory) {
		return '공장';
	} elsif($land == $HlandHTFactory) {
		return '첨단 기술 다국적 기업';
	} elsif($land == $HlandBase) {
		return '미사일 기지';
	} elsif($land == $HlandDefence) {
		return '방위 시설';
	} elsif($land == $HlandMountain) {
		return '산';
	} elsif($land == $HlandGold) {
		return '금광산';
	} elsif($land == $HlandOnsen) {
		return '온천거리';
	} elsif($land == $HlandShrine) {
		if($lv) {
			return "시간의 신전(턴${lv})";
		} else {
			return '시간의 신전';
		}
	} elsif($land == $HlandMonster) {
		my($name) = (monsterSpec($lv))[1];
		return $name;
	} elsif($land == $HlandHugeMonster) {
		my($name) = (hugeMonsterSpec($lv))[3];
		return $name;
	} elsif($land == $HlandSbase) {
		return '해저 기지';
	} elsif($land == $HlandSeacity) {
		return '해저 도시';
	} elsif($land == $HlandOil) {
		return '해저 유전';
	} elsif($land == $HlandMonument) {
		return $HmonumentName[$lv];
	} elsif($land == $HlandHaribote) {
		return '가짜 시설';
	} elsif($land == $HlandPark) {
		return '놀이공원';
	} elsif($land == $HlandMinato) {
		return '항구 도시';
	} elsif($land == $HlandFune) {
		return $HfuneName[$lv];
	} elsif($land == $HlandFrocity) {
		return '해상 도시';
	} elsif($land == $HlandSunahama) {
		return '해변';
	} elsif($land == $HlandMine) {
		return '지뢰';
	} elsif($land == $HlandNursery) {
		return '양식장';
	} elsif($land == $HlandKyujo) {
		return '야구장';
	} elsif($land == $HlandKyujokai) {
		return '다목적경기장';
	} elsif($land == $HlandUmiamu) {
		return '해상 시설';
	} elsif($land == $HlandSeki) {
		return '관문';
	} elsif($land == $HlandRottenSea) {
		return '오염된 바다';
	}
}

# 인구기타의 값을 산출
sub estimate {
	my($number) = $_[0];
	my($island);
	my($pop, $area, $farm, $factory, $mountain) = (0, 0, 0, 0, 0, 0);
	my($monslive, $monslivetype, $hmonslivetype, $missiles) = (0, 0, 0, 0);
	my($kei, $rena, $fore, $tare, $zipro, $leje) = (0, 0, 0, 0, 0, 0);
	my($oil, $bas, $kyu, $amu, $par, $fim, $rot, $sci, $sba, $pro, $kin, $shr, $nto, $m26, $m27, $m17, $c21)
		= (0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
	my($c11, $c13, $c28, $co0, $co1, $co2, $co3, $co4, $co5, $co99, $hou, $shu, $sin, $jin)
		= (0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
	my($m74, $m75, $m76, $m77, $m78, $m79, $m84, $m93, $ky2, $htf)
		= (0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
	my(@monspnt);

	# 지형을 가져옴
	$island = $Hislands[$number];
	my($land) = $island->{'land'};
	my($landValue) = $island->{'landValue'};

	my($mshp, $msap, $msdp, $mssp, $mswin, $msexe, $tet) = split(/,/, $island->{'eisei5'});
	$tet = 0;
	# 수 가능
	my($i, $x, $y, $kind, $value);
	foreach $i (0..$pointNumber) {
		$x = $Hrpx[$i];
		$y = $Hrpy[$i];
		$kind = $land->[$x][$y];
		$value = $landValue->[$x][$y];
		my($mKind, $mName, $mHp) = monsterSpec($value);
		if(($kind != $HlandSea) &&
			($kind != $HlandSbase) &&
			($kind != $HlandIce) &&
			($kind != $HlandFrocity) &&
			($kind != $HlandFune) &&
			($kind != $HlandNursery) &&
			($kind != $HlandUmiamu) &&
			($kind != $HlandSeacity) &&
			($kind != $HlandSeatown) &&
			($kind != $HlandUmishuto) &&
			($kind != $HlandHugeMonster) &&
			($kind != $HlandOil)){

			$area++;

			if(($kind == $HlandTown) ||
				($kind == $HlandProcity) ||
				($kind == $HlandMinato)) {
				# 읍
				$pop += $value;
				$pro++ if($kind == $HlandProcity);
			} elsif(($kind == $HlandFarm) ||
					($kind == $HlandFoodim)) {
				# 농장
				$farm += $value;
				$fim++ if(($kind == $HlandFoodim) && ($value < 480));
			} elsif($kind == $HlandFarmchi) {
				# 양계장
				$tare += $value;
				$factory += int($value/100)+1;
			} elsif($kind == $HlandFarmpic) {
				# 양돈장
				$zipro += $value;
				$factory += int($value/80)+1;
			} elsif($kind == $HlandFarmcow) {
				# 목장
				$leje += $value;
				$factory += int($value/50)+1;
			} elsif(($kind == $HlandFactory) ||
					($kind == $HlandHTFactory) ||
					($kind == $HlandPark)) {
				# 공장
				$factory += $value;
				$par++ if($kind == $HlandPark);
			} elsif(($kind == $HlandMountain) ||
					($kind == $HlandGold)) {
				# 산, 금광산
				$mountain += $value;
				$kin++ if($kind == $HlandGold);
			} elsif($kind == $HlandForest) {
				# 숲
				$fore += $value;
			} elsif($kind == $HlandNewtown) {
				# 뉴타운
				$pop += $value;
				$nwork = int($value/15);
				$factory += $nwork;
				$nto++;
			} elsif($kind == $HlandBigtown) {
				# 현대 도시
				$pop += $value;
				$mwork = int($value/20);
				$lwork = int($value/30);
				$factory += $mwork;
				$farm += $lwork;
			} elsif($kind == $HlandBettown) {
				# 휘하기 도시
				$pop += $value;
			} elsif($kind == $HlandRizort) {
				# 리조트지
				$pop += $value;
			} elsif($kind == $HlandBigRizort) {
				# 리조트지
				$pop += $value;
			} elsif($kind == $HlandOnsen) {
				$pop += $value;
				$hot++;
			} elsif($kind == $HlandHouse) {
				$hou++;
			} elsif($kind == $HlandShuto) {
				$pop += $value;
				$shu++;
			} elsif($kind == $HlandBase) {
				# 기지
				$bas += $value;
				$rena += $value;
				$missiles += expToLevel($kind, $value);
			} elsif($kind == $HlandMonument) {
				$kei++;
				if($value == 17) {
					$m17++;
				} elsif($value == 26) {
					$sin++;
				} elsif($value == 27) {
					$jin++;
				} elsif($value == 86) {
					$m26++;
				} elsif($value == 87) {
					$m27++;
				} elsif($value == 74) {
					$m74++;
				} elsif($value == 75) {
					$m75++;
				} elsif($value == 76) {
					$m76++;
				} elsif($value == 77) {
					$m77++;
				} elsif($value == 78) {
					$m78++;
				} elsif($value == 79) {
					$m79++;
				} elsif($value == 84) {
					$m84++;
				} elsif($value == 93) {
					$m93++;
				}
			} elsif($kind == $HlandCollege) {
				if($value == 0) {
					$co0++;
				} elsif($value == 1) {
					$co1++;
				} elsif($value == 2) {
					$co0++;
					$co1++;
					$co2++;
				} elsif($value == 3) {
					$co3++;
				} elsif(($value == 4) || ($value == 96)){
					$co4++;
				} elsif($value == 5) {
					$co5++;
				} elsif($value == 99) {
					$co99++;
				} elsif(($value == 98) || ($value == 97)){
					$co4++;
					$tet++;
				}
			} elsif($kind == $HlandMonster) {
				if($mKind == 11) {
					$c11++;
				} elsif($mKind == 13) {
					$c13++;
				} elsif($mKind == 21) {
					$c21++;
				} elsif($mKind == 28) {
					$c28++;
				} elsif($mKind == 30) {
					$c28++;
					$tet++;
				}
				$monslive++;
				push(@monspnt, { x => $x, y => $y });
				$monslivetype |= (2 ** $mKind);
			} elsif($kind == $HlandKyujokai) {
				$kyu++;
				$ky2++;
			} elsif($kind == $HlandKyujo) {
				$kyu++;
			} elsif($kind == $HlandRottenSea) {
				$rot++;
			} elsif($kind == $HlandShrine) {
				$shr++;
			}
		} elsif($kind == $HlandNursery) {
			# 양식장은 농장의 일종
			$farm += $value;
		} elsif($kind == $HlandUmiamu) {
			# 해상 시설
			$factory += $value;
			$amu++;
		} elsif($kind == $HlandIce) {
			$factory += $value;
		} elsif($kind == $HlandSeacity) {
			# 해저 도시
			$pop += $value;
			$sci++;

		} elsif ($kind == $HlandFrocity) {
			$pro++;
			$pop += $value;
		} elsif ($kind == $HlandUmishuto) {
			$pop += $value;
			$shu++;
		} elsif($kind == $HlandSeatown) {
			# 해저 신도시
			$pop += $value;
			$owork = int($value/40);
			$factory += $owork;
			$farm += $owork;
			$sci += 2;
		} elsif($kind == $HlandSbase) {
			# 해저 기지
			$bas += $value;
			$rena += $value;
			$sba++;
			$missiles += expToLevel($kind, $value);
		} elsif($kind == $HlandHTFactory) {
			$htf++;
		} elsif($kind == $HlandOil) {
			$oil++;
		} elsif($kind == $HlandHugeMonster) {
			my ($mKind, $mSea, $mHuge) = (hugeMonsterSpec($value))[0..2];
			$area++ if($mSea> 1);
			if($mHuge == 0) {
				$monslive++;
				$hmonslivetype |= (2 ** $mKind);
			}
		}
	}

	# 대입
	$island->{'pop'} = $pop;
	$island->{'area'} = $area;
	$island->{'farm'} = $farm;
	$island->{'factory'} = $factory;
	$island->{'mountain'} = $mountain;

	$island->{'oil'} = $oil;
	$island->{'bas'} = $bas;
	$island->{'kyu'} = $kyu;
	$island->{'ky2'} = $ky2;
	$island->{'amu'} = $amu;
	$island->{'par'} = $par;
	$island->{'fim'} = $fim;
	$island->{'rot'} = $rot;
	$island->{'sci'} = $sci;
	$island->{'sba'} = $sba;
	$island->{'pro'} = $pro;
	$island->{'kin'} = $kin;
	$island->{'shr'} = $shr;
	$island->{'nto'} = $nto;
	$island->{'m26'} = $m26;
	$island->{'m27'} = $m27;
	$island->{'m17'} = $m17;
	$island->{'c11'} = $c11;
	$island->{'c13'} = $c13;
	$island->{'c21'} = $c21;
	$island->{'c28'} = $c28;
	$island->{'co0'} = $co0;
	$island->{'co1'} = $co1;
	$island->{'co2'} = $co2;
	$island->{'co3'} = $co3;
	$island->{'co4'} = $co4;
	$island->{'co5'} = $co5;
	$island->{'co99'} = $co99;
	$island->{'tet'} = $tet;
	$island->{'hot'} = $hot;
	$island->{'hou'} = $hou;
	$island->{'shu'} = $shu;
	$island->{'sin'} = $sin;
	$island->{'jin'} = $jin;
	$island->{'m74'} = $m74;
	$island->{'m75'} = $m75;
	$island->{'m76'} = $m76;
	$island->{'m77'} = $m77;
	$island->{'m78'} = $m78;
	$island->{'m79'} = $m79;
	$island->{'m84'} = $m84;
	$island->{'m93'} = $m93;
	$island->{'htf'} = $htf;

	# 섬주의 가판정
	$island->{'eisei1'} = 0 if(!$hou);

	# 수도판정
	if(!$shu) {
		$island->{'shutomessage'} = 555;
	} elsif($island->{'shutomessage'} == 555) {
		$island->{'shutomessage'} = '';
	}

	# 통산 관광객
	$island->{'eisei2'} = 0 if($island->{'eisei2'} < 0);

	my($sto, $std, $stk, $stwin, $stdrow, $stlose, $stwint, $stdrowt, $stloset, $styusho, $stshoka) = map { int($_) } split(/,/, $island->{'eisei4'});
	$kachiten = $stwin*3 + $stdrow;
	$island->{'kachiten'} = $kachiten;

	if(!$ky2) {
#		$island->{'eisei4'} = "0,0,0,0,0,0,0,0,0,0,0";
		$island->{'eisei4'} = "$sto,$std,$stk,0,0,0,$stwint,$stdrowt,$stloset,$styusho,0";
	} else {
		$island->{'eisei4'} = "$sto,$std,$stk,$stwin,$stdrow,$stlose,$stwint,$stdrowt,$stloset,$styusho,$stshoka";
	}


	$island->{'monsterlive'} = $monslive; # 괴수출현 수
	$island->{'monsterlivetype'} = $monslivetype; # 괴수출현종류
	$island->{'hmonsterlivetype'} = $hmonslivetype; # 괴수출현종류
	$island->{'monspnt'} = \@monspnt; # 괴수출현좌표
	$island->{'missiles'} = $missiles; # 미사일 발사 가능 횟수

	$island->{'kei'} = $kei;
	$island->{'rena'} = $rena + $co2*100 + $co3*500 + $msexe;
	$island->{'fore'} = $fore;
	$island->{'tare'} = $tare;
	$island->{'zipro'} = $zipro;
	$island->{'leje'} = $leje;

	# 관광 괴수 판정
	if(!$co4 && !$co99 && !$c28) {
		$island->{'eisei5'} = "0,0,0,0,0,0,0";
	} elsif($co4 && !$mshp) {
		$island->{'eisei5'} = "3,5,5,5,0,0,0";
	} else {
		$island->{'eisei5'} = "$mshp,$msap,$msdp,$mssp,$mswin,$msexe,$tet";
	}
	$island->{'eisei6'} = "$c13,$shu,$m26,$m27,$m74,$m75,$m76,$m77,$m78,$m79,$m84,$m93";

	# 실업자 수
	$island->{'unemployed'} = $pop - ($farm + $factory + $mountain) * 10;

	my $ep1 = 100 + $island->{'eis1'}*2 if($island->{'eis1'});
	my $ep2 = 300 + $island->{'eis2'}*2 if($island->{'eis2'});
	my $ep3 = 500 + $island->{'eis3'}*2 if($island->{'eis3'});
	my $ep4 = 900 + $island->{'eis4'}*2 if($island->{'eis4'});
	my $ep5 = 1500 + $island->{'eis5'}*2 if($island->{'eis5'});
	my $ep6 = 2000 + $island->{'eis6'}*2 if($island->{'eis6'});

	# 종합 Point
	$island->{'pts'} = int($pop + $island->{'money'}/100 + $island->{'food'}/100 + ($farm*2 + $factory + $mountain*2) + $bas + $area*5 + $sci*30 + $pro*20 + $sba*10 + $amu*10 + $oil*500 + $kin*500 + $m26*300 + $m27*200 + $m74*250 + $m75*250 + $m76*250 + $m77*250 + $m78*250 + $m79*250 + $m93*500 + int($tare/15) + int($zipro/12) + int($leje/10) + $ep1 + $ep2 + $ep3 + $ep4 + $ep5 + $ep6 + $hou*500);

}

# 범위 안의 지형을 수 가능(New)
sub countAround {
	my($land, $x, $y, $range, @kind) = @_;
	my($i, $count, $sx, $sy, @list);
	$count = 0;
	for($i = 0; $i < $range; $i++) {
		$sx = $x + $ax[$i];
		$sy = $y + $ay[$i];

		# 행 기준 위치 조정
		$sx-- if(!($sy % 2) && ($y % 2));

		if(($sx < 0) || ($sx> $islandSize) || ($sy < 0) || ($sy> $islandSize)) {
			# 범위 밖의 경우
			# 바다에가 산
			$list[$HlandSea]++;
		} else {
			# 범위 안의 경우
			$list[$land->[$sx][$sy]]++;
		}
	}
	foreach (@kind){
		$count += $list[$_];
	}
	return $count;
}

# 0에서(n - 1)까지의 숫자가한 번씩출해 옵니다 수열을 만들기
sub randomArray {
	my($n) = @_;
	my(@list, $i);

	# 초기 값
	$n = 1 if($n == 0);
	@list = (0..$n-1);

	# 셔터 전체
	for ($i = $n; --$i; ) {
		my($j) = int(rand($i+1));
		next if($i == $j);
		@list[$i,$j] = @list[$j,$i];
	}

	return @list;
}

# 역대 최다인구기록
sub islandReki {
	my($line, $i, $id, $pop, $turn, $name, $n, $island, @rekidai, $reki);
	my $j = 0;

	if(!open(RIN, "<${HdirName}/rekidai.dat")) {
		rename("${HdirName}/rekidai.tmp", "${HdirName}/rekidai.dat");
		if(!open(RIN, "${HdirName}/rekidai.dat")) {
			# 인구순에정렬
			my @idx = (0..$#Hislands);
			@idx = sort { $Hislands[$b]->{'field'} <=> $Hislands[$a]->{'field'} || $Hislands[$b]->{'pop'} <=> $Hislands[$a]->{'pop'} || $a <=> $b } @idx;
			open(ROUT, ">${HdirName}/rekidai.tmp");
			foreach $i ($HbfieldNumber..$islandNumber) {# 현재 존재하는 섬모두를 기록
				$island = $Hislands[$idx[$i]];
				$id = $island->{'id'};
				$name = islandName($island);
				$pop = $island->{'pop'};
				print ROUT "$id,$pop,$HislandTurn,$name\n";
			}
			close(ROUT);
			rename("${HdirName}/rekidai.tmp", "${HdirName}/rekidai.dat");
			return;
		}
	}

	while($line = <RIN>) {
		$line =~ /^([0-9]*),([0-9]*),([0-9]*),(.*)$/;
		($id, $pop, $turn, $name) = ($1, $2, $3, $4);
		if(defined $HidToNumber{$id}) {
			$HidToNumberR{$id} = $j;
			$rekidai[$j]->{'id'} = $id;
		}
		$rekidai[$j]->{'pop'} = $pop;
		$rekidai[$j]->{'turn'} = $turn;
		$rekidai[$j]->{'name'} = $name;
		$j++;
	}
	close(RIN);

	foreach $i ($HbfieldNumber..$islandNumber) {
		$island = $Hislands[$i];
		$id = $island->{'id'};
		$name = $island->{'name'};
		$pop = $island->{'pop'};
		$n = $HidToNumberR{$id};
		if(defined $n) {
			if($pop> $rekidai[$n]->{'pop'}) {
				$rekidai[$n]->{'pop'} = $pop;
				$rekidai[$n]->{'turn'} = $HislandTurn;
				$rekidai[$n]->{'name'} = $name;
			}
		} else {
			$rekidai[$j]->{'id'} = $id;
			$rekidai[$j]->{'pop'} = $pop;
			$rekidai[$j]->{'turn'} = $HislandTurn;
			$rekidai[$j]->{'name'} = $name;
			$j++;
		}
	}

	# 인구가 같으면 이전 턴의 순서를 유지
	my @idx = (0..$#rekidai);
	@idx = sort { $rekidai[$b]->{'pop'} <=> $rekidai[$a]->{'pop'} || $a <=> $b } @idx;
	@rekidai = @rekidai[@idx];

	open(ROUT, ">${HdirName}/rekidai.tmp");
	my $recordNo = ($HmaxIsland < 15) ? 15 : $HmaxIsland;
	for($i = 0; $i < $recordNo; $i++) { # 최대에서 섬의 최대 수와 같은 만기록. 최소에서15 섬.
		$reki = $rekidai[$i];
		$n = $i + 1;
		if(defined $reki->{'pop'}) {
			($id, $pop, $turn, $name) = ($reki->{'id'}, $reki->{'pop'}, $reki->{'turn'}, $reki->{'name'});
			print ROUT "$id,$pop,$turn,$name\n";
		}
	}
	close(ROUT);
	unlink("${HdirName}/rekidai.dat");
	rename("${HdirName}/rekidai.tmp", "${HdirName}/rekidai.dat");
}

# 로그를 정리하기
sub logMatome {
	my($island, $flag, $kind) = @_;

	my($sno, $i, $sArray, $spnt, $x, $y, $point);
	$sno = $island->{$kind};
	$point = "";
	if($sno> 0) {
		if($flag == 1) {
			$kind.= 'pnt';
			$sArray = $island->{$kind};
			for($i = 0; $i < $sno; $i++) {
				$spnt = $sArray->[$i];
				last if($spnt eq "");
				($x, $y) = ($spnt->{x}, $spnt->{y});
				$point.= "($x, $y)";
				$point.= "<br> " unless(($i+1)%20);
			}
		}
		$point.= "의<B>$sno 케장소</B>" if($i> 1 || $flag != 1);
	}
	unless($point eq "") {
		if(($flag == 1) && ($sno> 1)) {
			logLandSucMatome($island->{'id'}, islandName($island), '개간', "$point");
		} else {
			logLandSuc($island->{'id'}, islandName($island), '개간', "$point");
		}
	}
}

# 로그로 출력
# 제1인 수:메시지
# 제2인 수:당사자
# 제3인 수:상대
# 일반 로그
sub logOut {
	push(@HlogPool,"0,$HislandTurn,$_[1],$_[2],$_[0]");
}

# 지연 로그
sub logLate {
	push(@HlateLogPool,"0,$HislandTurn,$_[1],$_[2],$_[0]");
}

# 기밀 로그
sub logSecret {
	push(@HsecretLogPool,"1,$HislandTurn,$_[1],$_[2],$_[0]");
}

# Hakoniwa Cup 로그
sub logHcup {
	open(COUT, ">>${HdirName}/hakojima.lhc");
	print COUT "$HislandTurn,$_[0]\n";
	close(COUT);
}

# 기록 로그
sub logHistory {
	push(@HhistoryLogPool,"$HislandTurn,$_[0]\n");
#	open(HOUT, ">>${HdirName}/hakojima.his");
#	print HOUT "$HislandTurn,$_[0]\n";
#	close(HOUT);
}

# 기록 로그 조정
#sub logHistoryTrim {
#	open(HIN, "${HdirName}/hakojima.his");
#	my @lines = <HIN>;
#	close(HIN);
#	while ($HhistoryMax < @lines) { shift @lines; }

#	open(HOUT, ">${HdirName}/hakojima.his");
#	print HOUT @lines;
#	close(HOUT);
#}

# Hakoniwa Cup 로그 조정(참고: 전쟁실적 표시 때문에 자르기)
#sub logHcupTrim {
#	# Hakoniwa Cup 로그 유지 줄 수
#	$HhcMax = 300; # 우승할 때까지 삭제하지 않으면 이 정도면 될까?(어차피 100턴마다 전체 삭제됩니다)
#	open(CIN, "${HdirName}/hakojima.lhc");
#	my @lines = <CIN>;
#	close(CIN);
#	while ($HhcMax < @lines) { shift @lines; }
#	open(COUT, ">${HdirName}/hakojima.his");
#	print COUT @lines;
#	close(COUT);
#}

# 로그 쓰기
sub logFlush {
	open(LOUT, ">${HdirName}/hakojima.log0");
	# 전체를 역순으로 출력
	foreach (reverse(@HlogPool, @HlateLogPool, @HsecretLogPool)) {
		next if($_ eq ',,,,,');
		print LOUT $_. "\n";
	}
	close(LOUT);

	# 기록 로그 쓰기와 조정
	open(HIN, "${HdirName}/hakojima.his");
	my @lines = <HIN>;
	close(HIN);
	@lines = (@lines, @HhistoryLogPool);
	while ($HhistoryMax < @lines) { shift @lines; }
	open(HOUT, ">${HdirName}/hakojima.his");
	print HOUT @lines;
	close(HOUT);

	undef @HsecretLogPool;
	undef @HlateLogPool;
	undef @HlogPool;
	undef @HhistoryLogPool;
}

# 로그 쓰기(분할갱신)
sub tempLogFlush {
	# 그대로 출력
	open(LOUT, ">>${HdirName}/secret.tmp");
	my($i);
	foreach (@HsecretLogPool) {
		print LOUT $_. "\n";
	}
	close(LOUT);
	open(LOUT, ">>${HdirName}/late.tmp");
	foreach (@HlateLogPool) {
		print LOUT $_. "\n";
	}
	close(LOUT);
	open(LOUT, ">>${HdirName}/log.tmp");
	foreach (@HlogPool) {
		print LOUT $_. "\n";
	}
	close(LOUT);
}

#----------------------------------------------------------------------
# 로그템플릿
#----------------------------------------------------------------------
# 군사 물자 조달
sub logArmSupply {
	my($id, $name, $comName, $num) = @_;
	logOut("${HtagName_}${name}${H_tagName}이 ${HtagNumber_}$num 개${H_tagNumber}의${HtagComName_}$comName${H_tagComName}을 실행했습니다.",$id);
}

# 수도 가능
sub logShuto {
 my($id, $name, $lName, $sName, $point) = @_;
 logOut("${HtagName_}${name}$point${H_tagName}의<B>$lName</B>은,<B>수도$sName</B>로서${AfterName}의 중심 도시가 되었습니다.",$id);
 logHistory("${HtagName_}${name} 섬${H_tagName}에<B>수도$sName</B>이 생겼습니다.");
}

# 온천 발견
sub logHotFound {
 my($id, $name, $point, $comName, $str) = @_;
 logOut("${HtagName_}${name}$point${H_tagName}에서<B>$str</B>의 예산을 투입하여${HtagComName_}${comName}${H_tagComName}이 진행되어,<B>온천이 발견되었습니다</B>.",$id);
}

# 온천 발견여부
sub logHotFail {
 my($id, $name, $point, $comName, $str) = @_;
 logOut("${HtagName_}${name}$point${H_tagName}에서<B>$str</B>의 예산을 투입하여${HtagComName_}${comName}${H_tagComName}이 실행되었지만, 온천은 발견되지 않았습니다.",$id);
}

# 신전에서 수입
sub logSinMoney {
 my($id, $name, $str) = @_;
 logOut("${HtagName_}${name}$point${H_tagName}의<B>신전</B>로 축하이의 축제리가 진행되어,<B>$str</B> 수익이 발생했습니다.",$id);
}

# 신사에서 수입
sub logJinMoney {
 my($id, $name, $str) = @_;
 logOut("${HtagName_}${name}$point${H_tagName}의<B>신사</B>로 축하이의 축제리가 진행되어,<B>$str</B> 수익이 발생했습니다.",$id);
}

# 자금융통에서 수입
sub logEnjo {
 my($id, $name, $lName, $point, $str) = @_;
 logOut("개발진흥위원회에서${HtagName_}${name}${H_tagName}에<B>$str</B>의 자금융통이 지급되었습니다!",$id);
}

# 미사일 정리 메시지 로그
sub logMsTotal {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint, $count, $mukou, $bouei, $kaijumukou, $kaijuhit, $fuhatu) = @_;
 logOut("${HtagName_}${name}${H_tagName}이${HtagName_}${tName}$point${H_tagName}지점을 향해${HtagComName_}$count 발의${comName}${H_tagComName}을 실행했습니다.<br> ${HtagName_}결과${H_tagName}⇒(무효$mukou 발/방위$bouei 발/괴수 상쇄$kaijumukou 발/괴수 명중$kaijuhit 발/불발탄$fuhatu 발)",$id, $tId);
}

# 스텔스 미사일 정리 메시지 로그
sub logMsTotalS {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint, $count, $mukou, $bouei, $kaijumukou, $kaijuhit, $fuhatu) = @_;
 logSecret("${HtagName_}${name}${H_tagName}이${HtagName_}${tName}$point${H_tagName}지점을 향해${HtagComName_}$count 발의${comName}${H_tagComName}을 실행했습니다.<br> ${HtagName_}결과${H_tagName}⇒(무효$mukou 발/방위$bouei 발/괴수 상쇄$kaijumukou 발/괴수 명중$kaijuhit 발/불발탄$fuhatu 발)",$id);
 logLate("<B>누군가</B>가${HtagName_}${tName}$point${H_tagName}지점을 향해${HtagComName_}$count 발의${comName}${H_tagComName}을 실행했습니다.<br> ${HtagName_}결과${H_tagName}⇒(무효$mukou 발/방위$bouei 발/괴수 상쇄$kaijumukou 발/괴수 명중$kaijuhit 발)", $tId);
}

# 수도를 공격
sub logMonsAttacks {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name}$point${H_tagName}의<B>$lName</B>은 괴수에${HtagDisaster_}공격${H_tagDisaster}됨 피해를 받했습니다.",$id);
}

# 자금·식량·위성부족함, 허가되지 않는
sub logNoAny { #20
	my($id, $name, $comName, $str) = @_;
	logOut("${HtagName_}${name}${H_tagName}에서 예정되어 있던${HtagComName_}$comName${H_tagComName}은,$str 때문에 중지되었습니다.",$id);
}

# 관광 괴수가 공격
sub logMsAttackt {
 my($id, $name, $mName, $point, $cPoint, $tName, $tPoint) = @_;
 logOut("${HtagName_}${name}${H_tagName}의<B>$mName</B>이$tPoint<B>$tName</B>을 공격시${HtagDisaster_}$point${H_tagDisaster}의 피해를 부여에${HtagDisaster_}$cPoint${H_tagDisaster}의 피해를 받했습니다.",$id, $tId);
}

# 미카엘상완성
sub logMsAttackmika {
 my($id, $name, $mName, $point, $cPoint, $tName, $tPoint) = @_;
 logOut("${HtagName_}${name}${H_tagName}의 <B>$mName</B>와 <B>$tName</B>의 전쟁은 전설이 되었고, ${AfterName}민은 <B>행복의 여신상</B>을 건조했습니다.",$id, $tId);
}

# 공격에서 머리는 네
sub logItiAttackms {
 my($id, $name, $mName, $point, $tName, $tPoint) = @_;
 logOut("${HtagName_}${name}$point${H_tagName}의<B>$mName</B>이$tPoint<B>$tName</B>을 베어냈습니다.",$id, $tId);
}


# 얼음에서 꼬치찌르기시
sub logIceAttack {
 my($id, $name, $mName, $point, $tName, $tPoint) = @_;
 logOut("${HtagName_}${name}$point${H_tagName}의<B>$mName</B>의 발사한 얼음 화살은${HtagName_}$tPoint${H_tagName}의<B>$tName</B>의 중심부를 관통했습니다.",$id, $tId);
}

# 헤루파이아
sub logHellAttack {
 my($id, $name, $mName, $point, $tName, $tPoint) = @_;
 logOut("${HtagName_}${name}$point${H_tagName}의<B>$mName</B>의 호출발생코했습니다지지옥의 불꽃은${HtagName_}$tPoint${H_tagName}의<B>$tName</B>을 불태우했습니다.",$id, $tId);
}

# 신형 군함이 공격
sub logFuneAttackSSS {
 my($id, $name, $lName, $point, $tName, $tPoint) = @_;
 logOut("${HtagName_}${name}$point${H_tagName}의<B>$lName</B>이<B>에너지포</B>을 발사시,<B>$tName</B>에 명중했습니다.",$id, $tId);
}

# 신형 군함이 공격
sub logFuneAttackSSSR {
 my($id, $name, $lName, $point, $tName, $tPoint) = @_;
 logOut("${HtagName_}${name}${H_tagName}의<B>$tName</B>은<B>산산조각</B>이 되었습니다.",$id, $tId);
}

# 신형 군함이 공격
sub logFuneAttackSSST {
 my($id, $name, $lName, $point, $tName, $tPoint) = @_;
 logOut("${HtagName_}${name}${H_tagName}의<B>$tName</B>은<B>산산조각</B>이 났고,<B>$lName</B>은${HtagDisaster_}과열${H_tagDisaster}되어 ${HtagDisaster_}대폭발${H_tagDisaster}했습니다.",$id, $tId);
}

# 알부화
sub logEggBomb {
	my($id, $name, $lName, $mName, $point) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}의<B>$lName</B>에서<B>$mName</B>이출현했습니다.",$id);
}

# 알해제 피해
sub logEggDamage {
	my($id, $name, $landName, $point) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}의<B>$landName</B>은${HtagDisaster_}알의 파괴균열에 한에너지${H_tagDisaster}로 수몰되었습니다.",$id);
}

# 이노라출격
sub logMstakeon {
	my($id, $name, $lName, $point) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}의<B>$lName</B>은<B>괴수퇴치</B>에향카지금했습니다.",$id);
}

# 이노라귀환집
sub logMstakeokaeri {
	my($id, $name, $lName, $point, $tName) = @_;
	logOut("${HtagName_}${name}${H_tagName}의<B>$lName</B>이${HtagName_}$point${H_tagName}의<B>$tName</B>에돌아왔습니다. 수고하셨습니다.",$id);
}

# 이노라가출
sub logMstakeiede {
	my($id, $name, $lName, $point, $tName) = @_;
	logOut("${HtagName_}${name}${H_tagName}의<B>$lName</B>은 귀환루베키가가 없어서 에여 행에 출했습니다.",$id);
}

# 이노라 줄분불명
sub logMstakeoff {
	my($id, $name, $lName, $point) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}의<B>$lName</B>은<B>관광 괴수</B>손실 때문에 운영이 어려워졌습니다.",$id);
}

# 중과 세역기레
sub logKire {
	my($id, $name) = @_;
	logOut("${HtagName_}${name}${H_tagName}의<B>중과 세</B>에${AfterName}민은${HtagDisaster_}키레${H_tagDisaster}했습니다!!",$id);
}

# 중과 세 피해
sub logKireDamage {
	my($id, $name, $lName, $point) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}의<B>$lName</B>은${HtagDisaster_}폭됨${AfterName}민${H_tagDisaster}에따라${HtagDisaster_}파괴${H_tagDisaster}됨했습니다.",$id);
}

# 괴수 출현(마방진)
sub logMonsComemagic {
	my($id, $tId, $name, $tName, $mName, $point, $lName) = @_;
	logOut("--- ${HtagName_}$point${H_tagName}의파괴된 <B>마방진</B>에서<B>$mName</B> 출현!!",$id, $tId);	my($id, $name, $mName, $point, $lName) = @_;
}

# 괴수 주변을 모두 동결 처리
sub logMonsCold {
	my($id, $name, $lName, $point, $mName) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}의<B>$lName</B>은<B>$mName</B>을 처리 과정에서 얼어붙었습니다.",$id);
}

# 알
sub logEggFound {
	my($id, $name, $comName) = @_;
	logOut("${HtagName_}${name}${H_tagName}에서 ${HtagComName_}$comName${H_tagComName} 중에,<B>무언가의 알</B>이 발견되어${HtagComName_}$comName 업자${H_tagComName}에는 파괴할 수 없으므로이므 로그대로 두기로 했습니다.",$id);
}

# 유적흔적
sub logIsekiFound {
	my($id, $name, $comName) = @_;
	logOut("${HtagName_}${name}${H_tagName}에서 ${HtagComName_}$comName${H_tagComName} 중에,<B>고대 유적</B>이 발견되어<B>${AfterName}의중요매립저장문화재정</B>에지정됨했습니다.",$id);
}

# 수상
sub logPrizet {
	my($id, $name, $pName, $value) = @_;
	my $str = "(상금${HtagMoney_}$value${H_tagMoney})" if($value> 0);
	logOut("${HtagName_}${name}${H_tagName}이<B>$pName</B>을 수상했습니다.$str",$id);
	logHistory("${HtagName_}${name}${H_tagName},<B>$pName</B>을 수상$str");
}

# 하코니와 컵
sub logHC {
	my($id, $name, $stsanka) = @_;
	if($stsanka) {
#		logHistory("${HtagName_}Hakoniwa Cup $HislandTurn${H_tagName}개최!<B>참가 수</B>${HtagNumber_}$stsanka${AfterName}!${H_tagNumber}");
		logHcup("${HtagName_}Hakoniwa Cup $HislandTurn${H_tagName}개최!<B>참가 수</B>${HtagNumber_}$stsanka${AfterName}!${H_tagNumber}");
	} else {
		logHcup("${HtagName_}Hakoniwa Cup $HislandTurn${H_tagName}은, 참가할 ${AfterName}이 없었기 때문에 ${HtagNumber_}취소되었습니다.${H_tagNumber}");
	}
}

# 하코니와 컵개회식
sub logHCstart {
	my($id, $name, $str) = @_;
#	logHistory("${HtagName_}${name}${H_tagName}에서<B>Hakoniwa Cup 개회식</B>이 진행되며,${HtagMoney_}$str${H_tagMoney}의 경제 효과를 발생시켰습니다.",$id);
	logLate("${HtagName_}${name}${H_tagName}에서<B>Hakoniwa Cup 개회식</B>이 진행되며,${HtagMoney_}$str${H_tagMoney}의 경제 효과를 발생시켰습니다.",$id);
	logHcup("${HtagName_}${name}${H_tagName}에서<B>Hakoniwa Cup 개회식</B>이 진행되며,${HtagMoney_}$str${H_tagMoney}의 경제 효과를 발생시켰습니다.");
}

# 하코니와 컵시도합
sub logHCgame {
	my($id, $tId, $name, $tName, $lName, $gName, $goal, $tgoal) = @_;
	my($home, $away);
	if($goal < $tgoal) {
		$str = "${HtagLose_}${name} 대표${H_tagLose}<B>VS</B>${HtagWin_}${tName} 대표${H_tagWin} ⇒ ${HtagLose_}$goal${H_tagLose}<B>-</B>${HtagWin_}$tgoal${H_tagWin}";
	} else {
		$str = "${HtagWin_}${name} 대표${H_tagWin}<B>VS</B>${HtagLose_}${tName} 대표${H_tagLose} ⇒ ${HtagWin_}$goal${H_tagWin}<B>-</B>${HtagLose_}$tgoal${H_tagLose}";
	}
	logLate("${HtagName_}${name}${H_tagName}에서<B>Hakoniwa Cup $gName</B>이 실행되었습니다.$str",$id, $tId);
	logHcup("${HtagName_}Hakoniwa Cup ${gName}${H_tagName},$str");
}

# 하코니와 컵 승리
sub logHCwin {
	my($id, $name, $cName, $str) = @_;
	logLate("${HtagName_}${name}대표${H_tagName}의<B>$cName</B>은${HtagName_}${name}${H_tagName}에${HtagMoney_}$str${H_tagMoney}의 경제 효과를 발생시켰습니다.",$id);
}

# 하코니와 컵우승
sub logHCwintop {
	my($id, $name, $cName) = @_;
#	logHistory("${HtagName_}${name}대표${H_tagName},${HtagWin_}Hakoniwa Cup $cName 우승!${H_tagWin}",$id);
	logLate("${HtagWin_}${name} 대표${H_tagWin},${HtagName_}Hakoniwa Cup $cName${H_tagName}${HtagWin_}우승!${H_tagWin}",$id);
	logHcup("${HtagWin_}${name} 대표${H_tagWin},${HtagName_}Hakoniwa Cup $cName${H_tagName}${HtagWin_}우승!${H_tagWin}");
}

# 하코니와 컵부전승
sub logHCantiwin {
	my($id, $name, $gName) = @_;
	logLate("${HtagName_}Hakoniwa Cup ${gName}${H_tagName},${HtagWin_}${name} 대표${H_tagWin}은, 상대 팀이 없어 ${HtagWin_}부전승${H_tagWin}가 되었습니다.",$id);
	logHcup("${HtagName_}Hakoniwa Cup ${gName}${H_tagName},${HtagWin_}${name} 대표${H_tagWin}은, 상대 팀이 없어 ${HtagWin_}부전승${H_tagWin}.");
}

# 하코니와 컵
sub logHCsin {
	my($id, $name, $stsin) = @_;
#	logHistory("${HtagName_}Hakoniwa Cup 결승 토너먼트진출${AfterName}!!${H_tagName}<br><font size=\"-1\"><B>$stsin</B></font>");
	logHcup("${HtagName_}Hakoniwa Cup 결승 토너먼트진출${AfterName}!!${H_tagName}<br><font size=\"-1\"><B>$stsin</B></font>");
}

# 관광객 방문
sub logKankouMigrate {
	my($id, $tId, $name, $lName, $tName, $point, $pop) = @_;
	logOut("${HtagName_}${tName}${H_tagName}에서${HtagName_}${name}$point${H_tagName}의<B>$lName</B>로<B>$pop${HunitPop}</B>의 관광객이 찾아왔습니다. 활기가 느껴집니다.",$id, $tId);
}

# 미사일 발사를 시도했지만 기지가 없음
sub logMsNoBase { #1
	my($id, $name, $comName) = @_;
	logOut("${HtagName_}${name}${H_tagName}에서 예정되어 있던${HtagComName_}${comName}${H_tagComName}은,<B>미사일 설비가 없어</B> 실행할 수 없었습니다.",$id);
}

# 대상 지형 종류 때문에 실패
sub logLandFail { #14
	my($id, $name, $comName, $kind, $point) = @_;
	logOut("${HtagName_}${name}${H_tagName}에서 예정되어 있던${HtagComName_}$comName${H_tagComName}은, 예정지 ${HtagName_}$point${H_tagName}이<B>$kind</B>였기 때문에 중지되었습니다.",$id);
}

# 대상 지형 종류 때문에 실패2
sub logLandFail2 { #5
	my($id, $name, $comName, $point, $str) = @_;
	logOut("${HtagName_}${name}${H_tagName}에서 예정되어 있던${HtagComName_}$comName${H_tagComName}은, 예정지 ${HtagName_}$point${H_tagName}이$str 때문에 중지되었습니다.",$id);
}

# 개간 계열 성공
sub logLandSuc { #25
	my($id, $name, $comName, $point) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}에서${HtagComName_}${comName}${H_tagComName}이 실행되었습니다.",$id);
}

# 개간 계열 로그 정리 메시지
sub logLandSucMatome {
	my($id, $name, $comName, $point) = @_;
	logOut("${HtagName_}${name}${H_tagName}에서${HtagComName_}${comName}${H_tagComName}이 실행되었습니다.<br> <B>⇒</B> $point",$id);
}

# 위성격침
sub logEiseifail { #1
	my($id, $name, $comName, $point) = @_;
	logOut("${HtagName_}${name}${H_tagName}에서${HtagComName_}${comName}${H_tagComName}이 실행되었지만발사는${HtagDisaster_}실패${H_tagDisaster}한 것 같습니다.",$id);
}

# 유전 발견
sub logOilFound { #1
	my($id, $name, $point, $comName, $str) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}에서${HtagMoney_}$str${H_tagMoney}의 예산을 투입하여${HtagComName_}${comName}${H_tagComName}이 진행되어,<B>유전이 채굴되었습니다</B>.",$id);
}

# 유전 발견 여부
sub logOilFail { #1
	my($id, $name, $point, $comName, $str) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}에서${HtagMoney_}$str${H_tagMoney}의 예산을 투입하여${HtagComName_}${comName}${H_tagComName}이 실행되었지만, 유전은 발견되지 않았습니다.",$id);
}

# 유전·관문·놀이공원·범선에서 수입
sub logOilMoney { #9
	my($id, $name, $lName, $point, $value, $str) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}의<B>$lName</B>에서 ${HtagMoney_}$value${H_tagMoney}의 $str이 발생했습니다.",$id);
}

# 유전 고갈, 광역 피해기타
sub logDamageAny { #29
	my($id, $name, $lName, $point, $str) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}의<B>$lName</B>은$str",$id);
}

# 놀이공원의 이벤트
sub logParkEvent { #4
	my($id, $name, $lName, $point, $str) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}의<B>$lName</B>로 이벤트가 개최되며,${HtagFood_}$str${H_tagFood}의 식량이 소비되었습니다.",$id);
}

# 보험에서 수입
sub logHoken { #1
	my($id, $name, $lName, $point, $str) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}의<B>$lName</B>의 사고로 ${HtagMoney_}$str${H_tagMoney}의 보험금이 지급되었습니다.",$id);
}

# 토지 산에서 수입
sub logMiyage { #1
	my($id, $name, $lName, $point, $str) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}의<B>$lName 기념비 공원</B>의 기념품 가게에서${HtagMoney_}$str${H_tagMoney} 수입이 발생했습니다.",$id);
}

# 우승에서 수입
sub logYusho { #1
	my($id, $name, $lName, $point, $str) = @_;
	logOut("${HtagName_}${name}${H_tagName}의 야구팀은${HtagName_}$point${H_tagName}의<B>$lName</B>가 출전한 하코니와 리그 결승전에서 우승하여,${HtagMoney_}$str${H_tagMoney}의 경제 효과가 발생했습니다.",$id);
}

# TITANIC 영화화
sub logTitanicEnd { #1
	my($id, $name, $lName, $point, $str) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}의<B>$lName</B>의 침몰 사고는 영화화되어 많은 사람이 눈물을 흘렸습니다.(${HtagMoney_}$str${H_tagMoney}의 이익 수입)",$id);
}

# 해저 탐색에서 수입
sub logTansaku { #1
	my($id, $name, $lName, $point, $str) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}의<B>$lName</B>이 보물을 발견!${HtagMoney_}$str${H_tagMoney}의 가치가 있는 것으로 확인되었습니다.",$id);
	logHistory("${HtagName_}${name}${H_tagName}의<B>$lName</B>이 보물을 발견!");
}

# 해저 탐색의 유전
sub logTansakuoil { #1
	my($id, $name, $lName, $point) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}에서<B>$lName</B>이유전을 발견!",$id);
}

# 행운
sub logOilMoneyt { #1
	my($id, $name, $lName, $point, $str) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}의<B>$lName</B>이락와 했습니다날개근에${HtagMoney_}$str${H_tagMoney}의 값어치가 있었습니다.",$id);
}

# 행운2
sub logParkEventt { #2
	my($id, $name, $lName, $point, $str) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}의<B>$lName</B>풍년이 들어 추가로${HtagFood_}$str${H_tagFood}의 식량이 생겼습니다.",$id);
}

# 선박 수확
sub logParkEventf { #2
	my($id, $name, $lName, $point, $str) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}의<B>$lName</B>은,${HtagFood_}$str${H_tagFood}의 식량을 얻었습니다.",$id);
}

# 방위 시설, 자폭 설정
sub logBombSet { #1
	my($id, $name, $lName, $point) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}의<B>$lName</B>의<B>자폭장치가 설정</B>되었습니다.",$id);
}

# 방위 시설, 자폭 작동
sub logBombFire { #1
	my($id, $name, $lName, $point) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}의<B>$lName</B>,${HtagDisaster_}자폭장치 작동!!${H_tagDisaster}",$id);
}

# 기념비, 발사
sub logMonFly { #1
	my($id, $name, $lName, $point) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}의<B>$lName</B>이<B>굉음과 함께 흔들렸습니다</B>.",$id);
}

# 기념비, 낙하
sub logMonDamage { #1
	my($id, $name, $point) = @_;
	logOut("<B>정체불명의 물체</B>가${HtagName_}${name}$point${H_tagName}지점에 낙하했습니다!!",$id);
}

# 나무심기 or 미사일 기지
sub logPBSuc { #3
	my($id, $name, $comName, $point) = @_;
	logSecret("${HtagName_}${name}$point${H_tagName}에서${HtagComName_}${comName}${H_tagComName}이 실행되었습니다.",$id);
	logOut("어디선가 ${HtagName_}${name}${H_tagName}의<B>숲</B>이 늘어난 것 같습니다.",$id);
}

# 가짜 시설
sub logHariSuc { #1
	my($id, $name, $comName, $comName2, $point) = @_;
	logSecret("${HtagName_}${name}$point${H_tagName}에서${HtagComName_}${comName}${H_tagComName}이 실행되었습니다.",$id);
	logLandSuc($id, $name, $comName2, $point);
}

# 사거리 안에 괴수 없음
sub logNoTarget {
	my($id, $name, $comName) = @_;
	logOut("${HtagName_}${name}${H_tagName}에서 예정되어 있던${HtagComName_}$comName${H_tagComName}은, 사거리 안에 괴수가 없었기 때문에 중지되었습니다.",$id);
}

# 미사일 발사 결과 범위 밖
sub logMsOut { #1
	my($id, $tId, $name, $tName, $comName, $point) = @_;
	logOut("${HtagName_}${name}${H_tagName}이${HtagName_}${tName}$point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행했지만,<B>영역 밖의 바다</B>로 빗나간 모양입니다.",$id, $tId);
}

# 스텔스 미사일 발사 결과 범위 밖
sub logMsOutS { #1
	my($id, $tId, $name, $tName, $comName, $point) = @_;
	logSecret("${HtagName_}${name}${H_tagName}이${HtagName_}${tName}$point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행했지만,<B>영역 밖의 바다</B>로 빗나간 모양입니다.",$id);
	logLate("<B>누군가</B>가${HtagName_}${tName}$point${H_tagName}을 대상으로${HtagComName_}${comName}${H_tagComName}을 실행했지만,<B>영역 밖의 바다</B>로 빗나간 모양입니다.",$tId);
}

# 위성파괴성공
sub logEiseiAtts { #1
	my($id, $tId, $name, $tName, $comName, $tEiseiname) = @_;
	logOut("${HtagName_}${name}${H_tagName}이${HtagName_}${tName}${H_tagName}을 대상으로${HtagComName_}${comName}${H_tagComName}을 실행하여,<B>$tEiseiname</B>에 명중.<B>$tEiseiname</B>은 흔적도 없이 사라졌습니다.",$id, $tId);
}

# 위성파괴실패
sub logEiseiAttf { #1
	my($id, $tId, $name, $tName, $comName, $tEiseiname) = @_;
	logOut("${HtagName_}${name}${H_tagName}이${HtagName_}${tName}${H_tagName}의<B>$tEiseiname</B>을 대상으로${HtagComName_}${comName}${H_tagComName}을 실행했지만, 아무것도 명중하지 않고 우주 저편으로 사라져 버렸습니다.",$id, $tId);
}

# 미사일이 방위 시설에 포착됨
sub logMsCaught { #2
	my($id, $tId, $name, $tName, $comName, $point, $tPoint) = @_;
	logOut("${HtagName_}${name}${H_tagName}이${HtagName_}${tName}$point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행했지만,${HtagName_}$tPoint${H_tagName}지점 상공에서 역장에 포착되어,<B>공중 폭발</B>했습니다.",$id, $tId);
}

# 스텔스 미사일이 방위 시설에 포착됨
sub logMsCaughtS { #2
	my($id, $tId, $name, $tName, $comName, $point, $tPoint) = @_;
	logSecret("${HtagName_}${name}${H_tagName}이${HtagName_}${tName}$point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행했지만,${HtagName_}$tPoint${H_tagName}지점 상공에서 역장에 포착되어,<B>공중 폭발</B>했습니다.",$id);
	logLate("<B>누군가</B>가${HtagName_}${tName}$point${H_tagName}을 대상으로${HtagComName_}${comName}${H_tagComName}을 실행했지만,${HtagName_}$tPoint${H_tagName}지점 상공에서 역장에 포착되어,<B>공중 폭발</B>했습니다.",$tId);
}

# 미사일격했음이방위위성에서 캬치(ST 바합니다)
sub logMsCaughtE { #1
	my($id, $tId, $name, $tName, $comName, $point, $tPoint) = @_;
	logOut("${HtagName_}${name}${H_tagName}이${HtagName_}${tName}$point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행했지만,<B>방위위성</B>에 격추되었습니다.",$id, $tId);
}

# 미사일 발사 결과 효과 없음
sub logMsNoDamage { #3
	my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint, $flag) = @_;
	my $noga = '의';
	$noga = '가' if($flag);
	logOut("${HtagName_}${name}${H_tagName}이${HtagName_}${tName}$point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행했지만,${HtagName_}$tPoint${H_tagName}${noga}<B>$tLname</B>에 빗나가 피해가 없었습니다.",$id, $tId);
}

# 스텔스 미사일 발사 결과 효과 없음
sub logMsNoDamageS { #2
	my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint, $flag) = @_;
	my $noga = '의';
	$noga = '가' if($flag);
	logSecret("${HtagName_}${name}${H_tagName}이${HtagName_}${tName}$point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행했지만,${HtagName_}$tPoint${H_tagName}${noga}<B>$tLname</B>에 빗나가 피해가 없었습니다.",$id);
	logLate("<B>누군가</B>가${HtagName_}${tName}$point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행했지만,${HtagName_}$tPoint${H_tagName}${noga}<B>$tLname</B>에 빗나가 피해가 없었습니다.",$tId);
}

# 일반 미사일, 괴수에 명중, 피해·살상 or 육지 파괴탄(LD), 산에 명중
sub logMsMonster { #3
	my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint, $str) = @_;
	logOut("${HtagName_}${name}${H_tagName}이${HtagName_}${tName}$point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행하여,${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 명중.<B>$tLname</B>은$str",$id, $tId);
}

# 스텔스 미사일, 괴수에 명중, 피해·살상
sub logMsMonsterS { #1
	my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint, $str) = @_;
	logSecret("${HtagName_}${name}${H_tagName}이${HtagName_}${tName}$point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행하여,${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 명중.<B>$tLname</B>은$str",$id);
	logLate("<B>누군가</B>가${HtagName_}${tName}$point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행하여,${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 명중.<B>$tLname</B>은$str",$tId);
}

# 육지 파괴탄(LD), 지형융기탄(LR), 해저 기지에 명중
sub logMsLSbase { #3
	my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint, $str) = @_;
	logOut("${HtagName_}${name}${H_tagName}이${HtagName_}${tName}$point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행하여,${HtagName_}$tPoint${H_tagName}에 착탄한 뒤 폭발, 같은 지점에 있던<B>$tLname</B>은$str",$id, $tId);
}

# 육지 파괴탄(LD), 지형융기탄(LR), 괴수에 명중
sub logMsLMonster { #2
	my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint, $str) = @_;
	logOut("${HtagName_}${name}${H_tagName}이${HtagName_}${tName}$point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행하여,${HtagName_}$tPoint${H_tagName}에 착탄해 폭발. 육지는<B>$tLname</B>째로 $str",$id, $tId);
}

# 육지 파괴탄(LD)지형융기탄(LR)얕은 바다·오염된 바다·기타의 지형에 명중
sub logMsLOther { #7
	my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint, $str) = @_;
	logOut("${HtagName_}${name}${H_tagName}이${HtagName_}${tName}$point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행하여,${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 착탄.$str",$id, $tId);
}

# 핵 미사일, 착탄
sub logMsSS { #1
	my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
	logOut("${HtagName_}${name}${H_tagName}이${HtagName_}${tName}$point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행하여,${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 착탄하여 대폭발했습니다.",$id, $tId);
}

# 일반 미사일 일반 지형·오염된 바다·괴수(경화 중)에 명중
sub logMsNormal { #3
	my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint, $str) = @_;
	logOut("${HtagName_}${name}${H_tagName}이${HtagName_}${tName}$point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행하여,${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 명중,$str",$id, $tId);
}

# 스텔스 미사일 일반 지형·오염된 바다·괴수(경화 중)에 명중
sub logMsNormalS { #3
	my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint, $str) = @_;
	logSecret("${HtagName_}${name}${H_tagName}이${HtagName_}${tName}$point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행하여,${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 명중,$str",$id);
	logLate("<B>누군가</B>가${HtagName_}${tName}$point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행하여,${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 명중,$str",$tId);
}

# 괴수의 시체
sub logMsMonMoney { #6
	my($tId, $mName, $value) = @_;
	logOut("<B>$mName</B>의 잔해에는,<B>$value$HunitMoney</B>의 값어치가 있었습니다.",$tId);
}

# 난민 도착
sub logMsBoatPeople { #1
	my($id, $name, $achive) = @_;
	logOut("${HtagName_}${name}${H_tagName}에어디선가<B>$achive${HunitPop}명의 난민</B>이 표류해 왔습니다.${HtagName_}${name}${H_tagName}은 살기 좋아진 것 같습니다.",$id);
}

# 스텔스 미사일, 황무지에 착탄
sub logMsWasteS { #1
	my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
	logSecret("${HtagName_}${name}${H_tagName}이${HtagName_}${tName}$point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행했지만,${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 떨어졌습니다.",$id);
	logLate("<B>누군가</B>가${HtagName_}${tName}$point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행했지만,${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 떨어졌습니다.",$tId);
}

# 스텔스 미사일, 괴수에타타키락가 됩니다
sub logMsMonsCautS { #1
	my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
	logSecret("${HtagName_}${name}${H_tagName}이${HtagName_}${tName}$point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행했지만,${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에타타키락와 됨했습니다.",$id);
}

# 스텔스 미사일, 천사에타타키락가 됩니다
sub logMsMonsCauttS { #1
	my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
	logSecret("${HtagName_}${name}${H_tagName}이${HtagName_}${tName}$point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행했지만,${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 격추되었습니다.",$id);
}

# 스텔스 미사일, 슬라임에타타키락가 됩니다
sub logMsMonsCautlS { #1
	my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
	logSecret("${HtagName_}${name}${H_tagName}이${HtagName_}${tName}$point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행했지만,${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에빗나갔습니다.",$id);
}

# 스텔스 미사일, 메카에 명중하면 격추됩니다
sub logMsMonsCautmS { #1
	my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
	logSecret("${HtagName_}${name}${H_tagName}이${HtagName_}${tName}$point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행했지만,${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>의 요격 미사일에 격추되었습니다.",$id);
}

# 일반 미사일은 괴수에 명중하거나 황무지에 착탄
sub logMsMonsCaut { #5
	my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint, $str) = @_;
	logOut("${HtagName_}${name}${H_tagName}이${HtagName_}${tName}$point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행했지만,${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에$str",$id, $tId);
}

# 괴수가 공격
sub logMonsAttack { #2
	my($id, $name, $mName, $point, $tName, $tPoint) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}의<B>$mName</B>이$tPoint<B>$tName</B>에향해 불꽃을 내뿜었습니다.",$id, $tId);
}

# 천사가 공격
sub logMonsAttackt { #1
	my($id, $name, $mName, $point, $tName, $tPoint) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}의<B>$mName</B>이$tPoint<B>$tName</B>을 공격했습니다.",$id, $tId);
}

# 이레가 공격
sub logIreAttackt { #2
	my($id, $name, $mName, $point, $tName, $tPoint) = @_;
	logOut("${HtagName_}${name}${H_tagName}의<B>$mName</B>이$tPoint<B>$tName</B>을 공격시${HtagDisaster_}$point${H_tagDisaster}의 피해를 부여했습니다.",$id, $tId);
}

# 공격에서 머리는 네
sub logItiAttack { #1
	my($id, $name, $mName, $point, $tName, $tPoint) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}의<B>$mName</B>이$tPoint<B>$tName</B>의 머리를 베기네했습니다.",$id, $tId);
}

# 역장에서 괴수아중
sub logBariaAttack { #1
	my($id, $name, $tName, $tPoint) = @_;
	logOut("${HtagName_}${name}$tPoint${H_tagName}의<B>$tName</B>이강력나역장에누름시파괴됨했습니다.",$id, $tId);
}

# 마법메테오, 퀘이크
sub logMgSpel { #3
	my($id, $name, $mName, $point, $spel) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}의<B>$mName</B>은${HtagDisaster_}$spel${H_tagDisaster}을 시전했습니다.",$id);
}

# 마법 드레인
sub logMgDrain { #1
	my($id, $name, $mName, $tName, $point) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}의<B>$mName</B>은<B>$tName</B>에 대해${HtagDisaster_}드레인${H_tagDisaster}을 시전했습니다.",$id);
}

# 소환
sub logShoukan { #1
	my($id, $name, $nName, $mName, $point) = @_;
	logOut("<B>$nName</B>은${HtagName_}${name}$point${H_tagName}에<B>$mName</B>을${HtagDisaster_}소환${H_tagDisaster}했습니다.",$id);
}

# 대공황
sub logKyoukou { #1
	my($id, $name, $mName, $point) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}의<B>$mName</B>은${HtagName_}${name}${H_tagName}에${HtagDisaster_}대공황${H_tagDisaster}을 일으켰습니다.",$id);
}

# 부패식
sub logFushoku { #2
	my($id, $name, $mName, $point) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}의<B>$mName</B>은${HtagName_}${name}${H_tagName}의비축해 둔 <B>식량</B>을 ${HtagDisaster_}부패${H_tagDisaster}시킨 것 같습니다.",$id);
}

# big 요격?!
sub logEiseiBigcome { #0
	my($id, $name) = @_;
	logOut("${HtagName_}${name}${H_tagName}의<B>요격위성</B>은${HtagName_}${name}${H_tagName}을 향해 날아오는 ${HtagDisaster_}거대 운석${H_tagDisaster}을 격추한 것 같습니다!!",$id);
}

# 요격?!
sub logEiseicome { #0
	my($id, $name) = @_;
	logOut("${HtagName_}${name}${H_tagName}의<B>요격위성</B>은${HtagName_}${name}${H_tagName}을 향해 날아오는 ${HtagDisaster_}운석${H_tagDisaster}을 격추한 것 같습니다!!",$id);
}

# 위성소멸?!
sub logEiseiEnd { #4
	my($id, $name, $tEiseiname) = @_;
	logOut("${HtagName_}${name}${H_tagName}의<B>$tEiseiname</B>은${HtagDisaster_}붕괴${H_tagDisaster}한 것 같습니다!!",$id);
}

# 봉인해제
sub logUmlimit { #1
	my($id, $name, $mName, $point) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}의<B>$mName</B>의<B>봉인</B>이 ${HtagDisaster_}해제${H_tagDisaster}된 것 같습니다.",$id);
}

# 봉인해제 피해
sub logUmlimitDamage { #1
	my($id, $name, $mName, $lName, $point) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}의<B>$lName</B>은<B>$mName</B>의${HtagDisaster_}방출된 에너지${H_tagDisaster}로 괴멸되었습니다.",$id);
}

# 우리에루의 코메와~
sub logUrieruMeteo { #1
	my($id, $name, $lName, $point, $tName, $tPoint) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}의<B>$lName</B>이 끌어들인 ${HtagDisaster_}소운석${H_tagDisaster}이${HtagName_}$tPoint${H_tagName}의<B>$tName</B>에낙하시일대가 괴멸되었습니다.",$id, $tId);
}

# 신형 군함이 공격
sub logFuneAttack { #1
	my($id, $name, $lName, $point, $tName, $tPoint) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}의<B>$lName</B>이다탄두 미사일을 발사시,${HtagName_}$tPoint${H_tagName}의<B>$tName</B>에 명중했습니다.",$id, $tId);
}

# 메카 공격
sub logMekaAttack { #4
	my($id, $name, $lName, $point, $tName, $tPoint, $kind, $str) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}의<B>$lName</B>이 발사한$kind 이${HtagName_}$tPoint${H_tagName}의<B>$tName</B>에 착탄하여 $str 했습니다.",$id, $tId);
}

# 오염된 바다가생된
sub logRottenSeaBorn { #2
	my($id, $name, $point) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}에<B>왕충</B>에서<B>오염된 바다</B>이 발생했습니다.",$id);
}

# 탈피 껍질로 간주
sub logNuginugi { #1
	my($id, $name, $point) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}에<B>왕충</B>이탈피 껍질했습니다.",$id);
}

# 레이저 명중,,
sub logLzr { #3
	my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint, $str) = @_;
	logOut("${HtagName_}${name}${H_tagName}이${HtagName_}${tName}$point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행하여,<B>$tLname</B>에 명중,<B>$tLname</B>은$str",$id, $tId);
}

# 괴수 파견
sub logMonsSend { #1
	my($id, $tId, $name, $tName) = @_;
	logOut("${HtagName_}${name}${H_tagName}이<B>인공괴수</B>를 만들었습니다.${HtagName_}${tName}${H_tagName}로 보냈습니다.",$id, $tId);
}

# 별도의 동맹을 결성하고 있는
sub logLeaderAlready {
	my($id, $name, $tName, $comName) = @_;
	logOut("${HtagName_}${name}${H_tagName}에서 예정되어 있던${HtagName_}${tName}${H_tagName}의${HtagComName_}${comName}${H_tagComName}은, 이미 자신의 동맹을 결성했기 때문에 중지되었습니다.",$id);
}

# 이미 다른 동맹에 가입한 경우
sub logOtherAlready {
	my($id, $name, $tName, $comName) = @_;
	logOut("${HtagName_}${name}${H_tagName}에서 예정되어 있던${HtagName_}${tName}${H_tagName}의${HtagComName_}${comName}${H_tagComName}은, 이미 다른 동맹에 가입되어 있어 중지되었습니다.",$id);
}

# 가입
sub logAlly {
	my($id, $tId, $name, $allyName) = @_;
	logOut("${HtagName_}${name}${H_tagName}이'${HtagName_}${allyName}${H_tagName}'에${HtagNumber_}가입${H_tagNumber}했습니다.", $id, $tId);
}

# 탈퇴
sub logAllyEnd {
	my($id, $tId, $name, $allyName) = @_;
	logOut("${HtagName_}${name}${H_tagName}이'${HtagName_}${allyName}${H_tagName}'부터${HtagDisaster_}탈퇴${H_tagDisaster}했습니다.", $id, $tId);
}

# 수출
sub logSell { #1
	my($id, $name, $comName, $value) = @_;
	logOut("${HtagName_}${name}${H_tagName}이${HtagFood_}$value$HunitFood${H_tagFood}의${HtagComName_}${comName}${H_tagComName}을 실행했습니다.",$id);
}

# 지원
sub logAid { #1
	my($id, $tId, $name, $tName, $comName, $str) = @_;
	logOut("${HtagName_}${name}${H_tagName}이${HtagName_}${tName}${H_tagName}로$str 의${HtagComName_}${comName}${H_tagComName}을 실행했습니다.",$id, $tId);
}

# 진영 밖 지원(불허)
sub logAidFail {
	my($id, $tId, $name, $tName, $comName) = @_;
	logOut("${HtagName_}${name}${H_tagName}에서 예정되어 있던${HtagName_}${tName}${H_tagName}에서 ${HtagComName_}${comName}${H_tagComName}은 허가되어 있지 않아 중지되었습니다.",$id, $tId);
}

# 공격금지
sub logNotAvail {
	my($id, $name, $comName) = @_;
	logOut("${HtagName_}${name}${H_tagName}에서 예정되어 있던${HtagComName_}${comName}${H_tagComName}은 허가되어 있지 않아 중지되었습니다.",$id);
}

# 유치 활동, 자금융통(주석 처리로합니다)
sub logPropaganda { #4
	my($id, $name, $comName) = @_;
	logOut("${HtagName_}${name}${H_tagName}에서${HtagComName_}${comName}${H_tagComName}이 실행되었습니다.",$id);
}

# 포기
sub logGiveup { #1
	my($id, $name) = @_;
	logOut("${HtagName_}${name}${H_tagName}은 포기되어,<B>무인${AfterName}</B>이 되었습니다.",$id);
	logHistory("${HtagName_}${name}${H_tagName}, 포기되어 <B>무인${AfterName}</B>이 됩니다.");
}

# 시간 저장, 시간 복원
sub logSaveLoad { #5
	my($id, $name, $comName, $str) = @_;
	logOut("${HtagName_}${name}${H_tagName}이 ${HtagComName_}${comName}${H_tagComName}$str",$id);
}

# 시간 저장, 시간 복원, 실패
sub logSaveLoadFail { #3
	my($id, $name, $comName) = @_;
	logOut("${HtagName_}${name}${H_tagName}이 ${HtagComName_}${comName}${H_tagComName}",$id);
}

# 시간 저장 데이터소실
sub logSaveLoadVanish { #1
	my($id, $name) = @_;
	logOut("${HtagName_}${name}${H_tagName}에서  때의 관리자가 혼선을 일으켜${HtagDisaster_} 시간 저장을 삭제되었습니다.${H_tagDisaster}",$id);
}

# 사멸
sub logDead { #1
	my($id, $name) = @_;
	logOut("${HtagName_}${name}${H_tagName}에서 주민이 사라져,<B>무인${AfterName}</B>이 되었습니다.",$id);
	logHistory("${HtagName_}${name}${H_tagName}, 주민이 사라져 <B>무인${AfterName}</B>이 됩니다.");
}

# 사멸(서바이벌 모드)
sub logTDead { #1
	my($id, $name) = @_;
	logOut("${HtagName_}${name}${H_tagName}은,<B>침몰</B>시흔적도 없이 사라졌습니다.",$id);
	logHistory("${HtagName_}${name}${H_tagName},<B>침몰</B>하다.");
}

# 기아
sub logStarve { #1
	my($id, $name) = @_;
	logOut("${HtagName_}${name}${H_tagName}의${HtagDisaster_}식량이 부족${H_tagDisaster}하고 있습니다!!",$id);
}

# 부작용?!
sub logStarvefood { #1
	my($id, $name) = @_;
	logOut("${HtagName_}${name}${H_tagName}의<B>유적전달자조환에식물</B>에${HtagDisaster_}부작용${H_tagDisaster}이있었던것 같습니다!!",$id);
}

# 포자?!
sub logRotsick { #1
	my($id, $name) = @_;
	logOut("${HtagName_}${name}${H_tagName}의<B>오염된 바다</B>가 발생시킨 <B>포자</B>는${HtagName_}${name}${H_tagName}에${HtagDisaster_}역병${H_tagDisaster}을 퍼뜨린 것 같습니다!!",$id);
}

# 역병?!
sub logSatansick { #1
	my($id, $name) = @_;
	logOut("<B>마왕 사탄</B>은${HtagName_}${name}${H_tagName}의<B>식량</B>을${HtagDisaster_}부패${H_tagDisaster}하게,${HtagName_}${name}${H_tagName}에서는${HtagDisaster_}역병${H_tagDisaster}이퍼지고 있는 것 같습니다!!",$id);
}

# 괴수 출현
sub logMonsCome { #3
	my($id, $name, $mName, $point, $lName) = @_;
	logOut("${HtagName_}${name}${H_tagName}에<B>$mName</B> 출현!!${HtagName_}$point${H_tagName}의<B>$lName</B>이 짓밟혀 파괴되었습니다.",$id);
}

# 괴수 방치
sub logMonsFree { #1
	my($id, $name, $mName, $point) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}에서<B>$mName</B>을 구매·방치했습니다.",$id);
}

# 괴수 이동
sub logMonsMove { #1
	my($id, $name, $lName, $point, $mName) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}의<B>$lName</B>이<B>$mName</B>에게 짓밟혀 파괴되었습니다.",$id);
}

# 괴수 이동(바다)
sub logMonsMoveSea {
	my($id, $name, $lName, $point, $mName) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}의<B>$lName</B>을<B>$mName</B>이 이동하고 있습니다.",$id);
}

# 거대괴수일부재생
sub logMonsRebody {
	my($id, $name, $point, $mName) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}에서<B>$mName</B>의 일부가재생했습니다.",$id);
}

# 괴수는 방위 시설을 밟지 않음
sub logMonsMoveDefence { #1
	my($id, $name, $lName, $point, $mName) = @_;
	logOut("<B>$mName</B>이${HtagName_}${name}$point${H_tagName}의<B>$lName</B>로 도달,<B>${lName}의 자폭장치가 작동!!</B>",$id);
}

# 괴수와 푸
sub logMonsWarp { #1
	my($id, $name, $point, $mName) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}의<B>괴수$mName</B>이소에제거되었습니다!",$id);
}

# 괴수의 주변 지형와 푸
sub logMonsWarpLand { #2
	my($id, $name, $lName, $point) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}에<B>$lName</B>이출현했습니다!",$id);
}

# 슬라임이분열했습니다
sub lognewMonsterBorn { #1
	my($id, $name, $point) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}에<B>슬라임</B>이분열했습니다.",$id);
}

# 도움케호출입니다
sub lognewKaiju { #1
	my($id, $name, $mName, $point) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}에<B>$mName</B>이도움케에옴했습니다.",$id);
}

# 괴수, 자폭입니다
sub logMonsBomb { #1
	my($id, $name, $lName, $point, $mName) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}의<B>$mName</B>이${HtagDisaster_}메루와 다운${H_tagDisaster}을일으켜자폭했습니다.",$id);
}

# 괴수, 동료를 호출부
sub logMonsHelpMe { #1
	my($id, $name, $mName, $point) = @_;
	logOut("${HtagName_}${name}${point}${H_tagName}의<B>괴수$mName</B>이하늘을 향해 포효했습니다!",$id);
}

# 괴수가 폭발
sub logMonsExplosion { #1
	my($id, $name, $point, $mName) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}의<B>괴수$mName</B>이<B>대폭발</B>을 발생코했습니다!",$id);
}

# 괴수, 주변을 불태우는
sub logMonsFire { #1
	my($id, $name, $lName, $point, $mName) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}의<B>$lName</B>이<B>$mName</B>의 충격파로 괴멸되었습니다.",$id);
}

# 괴수, 주변을 불태우는
sub logMonsFireS { #1
	my($id, $name, $lName, $point, $mName) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}의<B>$lName</B>이<B>괴수$mName</B>의 배출키출했습니다불꽃에서 불태우됨했습니다.",$id);
}

# 괴수는 지뢰를 밟지 않음
sub logMonsMine { #3
	my($id, $name, $lName, $point, $mName, $str) = @_;
	logOut("<B>괴수$mName</B>이${HtagName_}${name}$point${H_tagName}의<B>$lName</B>을 밟아 폭발,<B>괴수$mName</B>은$str",$id);
}

# 화재
sub logFire { #1
	my($id, $name, $lName, $point) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}의<B>$lName</B>이${HtagDisaster_}화재${H_tagDisaster}로 괴멸되었습니다.",$id);
}

# 화재미 수행
sub logFirenot { #1
	my($id, $name, $lName, $point) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}의<B>$lName</B>이${HtagDisaster_}화재${H_tagDisaster}로 피해를 받했습니다.",$id);
}

# 매장금
sub logMaizo { #1
	my($id, $name, $comName, $value) = @_;
	logOut("${HtagName_}${name}${H_tagName}에서 ${HtagComName_}$comName${H_tagComName} 중에,${HtagMoney_}$value$HunitMoney${H_tagMoney}상당의 <B>매장금</B>을 발견했습니다.",$id);
}

# 금괴
sub logGold { #1
	my($id, $name, $comName, $value) = @_;
	logOut("${HtagName_}${name}${H_tagName}에서 ${HtagComName_}$comName${H_tagComName} 중에,<B>금괴</B>가 발견되어${HtagMoney_}$value$HunitMoney${H_tagMoney}의 이익이 발생했습니다.",$id);
}

# 금고갈
sub logGoldEnd { #1
	my($id, $name, $lName, $point) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}의<B>$lName</B>에서 금이채택레없이나했은 것 같습니다.",$id);
}

# 지진발생
sub logEarthquake { #2
	my($id, $name) = @_;
	logOut("${HtagName_}${name}${H_tagName}로 대규모${HtagDisaster_}지진${H_tagDisaster}이 발생!!",$id);
}

# 식량 부족 피해
sub logSvDamage { #1
	my($id, $name, $lName, $point) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}의<B>$lName</B>에<B>식량을 찾는 주민이 몰려들었습니다</B>.<B>$lName</B>은 괴멸되었습니다.",$id);
}

# 쓰나미발생
sub logTsunami { #1
	my($id, $name) = @_;
	logOut("${HtagName_}${name}${H_tagName}부근에서${HtagDisaster_}쓰나미${H_tagDisaster} 발생!!",$id);
}

# 태풍발생
sub logTyphoon { #1
	my($id, $name) = @_;
	logOut("${HtagName_}${name}${H_tagName}에${HtagDisaster_}태풍${H_tagDisaster} 상륙!!",$id);
}

# 운석, 낙하
sub logMeteo { #10
	my($id, $name, $lName, $point, $str) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}의<B>$lName</B>에${HtagDisaster_}운석${H_tagDisaster}이 낙하$str 했습니다.",$id);
}

# 운석, 괴수
sub logMeteoMonster { #2
	my($id, $name, $lName, $point) = @_;
	logOut("<B>$lName</B>이 있던${HtagName_}${name}$point${H_tagName}지점에${HtagDisaster_}운석${H_tagDisaster}이 낙하, 육지는<B>$lName</B>째로 수몰되었습니다.",$id);
}

# 운석, 기타
sub logHugeMeteo { #2
	my($id, $name, $point) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}지점에${HtagDisaster_}거대운석${H_tagDisaster}이 낙하!!",$id);
}

# 분화
sub logEruption { #1
	my($id, $name, $lName, $point) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}지점에서${HtagDisaster_}화산이 분화${H_tagDisaster},<B>산</B>이 생겼습니다.",$id);
}

# 분화2
sub logEruption2 { #3
	my($id, $name, $lName, $point, $str) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}지점의<B>$lName</B>은,${HtagDisaster_}분화${H_tagDisaster}의 영향으로$str",$id);
}

# 지반 침하발생
sub logFalldown { #1
	my($id, $name) = @_;
	logOut("${HtagName_}${name}${H_tagName}에서${HtagDisaster_}지반 침하${H_tagDisaster}가 발생했습니다!!",$id);
}

# 광역 피해, 괴수수몰
sub logWideDamageMonsterSea { #1
	my($id, $name, $lName, $point) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}의 육지는<B>$lName</B>째로 수몰되었습니다.",$id);
}

# 수상
sub logPrize { #10
	my($id, $name, $pName) = @_;
	logOut("${HtagName_}${name}${H_tagName}이<B>$pName</B>을 수상했습니다.",$id);
	logHistory("${HtagName_}${name}${H_tagName},<B>$pName</B>을 수상");
}

# 실업자가에서 모
sub logUnemployedDemo { #1
	my($id, $name, $pop, $str) = @_;
	logOut("${HtagName_}${name}${H_tagName}에서 ${str}<B>$pop${HunitPop}</B>이 일자리를 찾아 이동했습니다.",$id);
}

# 실업자가폭동
sub logUnemployedRiot { #1
	my($id, $name, $lName, $pop, $point, $str) = @_;
	logOut("${HtagName_}${name}${H_tagName}에서${str}<B>$pop${HunitPop}</B>이${HtagDisaster_}폭동${H_tagDisaster}을발생코하고${HtagName_}$point${H_tagName}지점의<B>$lName</B>에<B>쇄도</B>.<B>$lName</B>은 괴멸되었습니다.",$id);
}

# 실업자가이민
sub logUnemployedMigrate { #1
	my($id, $tId, $name, $tName, $pop, $str) = @_;
	logOut("${HtagName_}${name}${H_tagName}에서${HtagName_}${tName}${H_tagName}로${str}<B>$pop${HunitPop}</B>의 이민이도착했습니다.${HtagName_}${tName}${H_tagName}은 살기 좋아진 것 같습니다.",$id, $tId);
}

# 이민 처리
sub logUnemployedReturn { #1
	my($id, $tId, $name, $lName, $tName, $pop, $str) = @_;
	logOut("${HtagName_}${name}${H_tagName}에서${HtagName_}${tName}${H_tagName}로${str}<B>$pop${HunitPop}</B>의 이민이도착했지만,${HtagName_}${tName}${H_tagName}의<B>$lName</B>은 수용를 거부한 것 같습니다.",$id, $tId);
}

# 인구감소
sub logPopDecrease { #5
	my($id, $name, $lName, $tName, $str, $point) = @_;
	logOut("${HtagName_}${name}$point${H_tagName}의<B>$lName</B>이${HtagDisaster_}${str}${H_tagDisaster}의 인구 감소로<B>$tName</B>이 되었습니다.",$id);
}

1;
