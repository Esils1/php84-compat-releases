use utf8;
#----------------------------------------------------------------------
# 모형정원 제도 ver2.30
# 설정 파일
# 사용 조건, 사용 방법 등은 hako-readme.txt 파일 참조
#
# 모형정원 제도 페이지: http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html
#----------------------------------------------------------------------
# 이노라 제도
#----------------------------------------------------------------------

#----------------------------------------------------------------------
# 각종 설정값
#----------------------------------------------------------------------

#----------------------------------------------------------------------
# 아래는 반드시 설정해야 하는 부분
#----------------------------------------------------------------------

# 이 파일을 놓는 디렉터리
# 마지막에 슬래시(/)는 붙이지 않습니다.
$baseDir = 'https://esils.com/hako/inora-1_10';

# 이미지 파일을 놓는 디렉터리
$imageDir = './hakopng';

# 이미지 로컬 설정 설명 페이지
$imageExp = './imgexp';


# 마스터 비밀번호
# 모든 섬의 비밀번호를 대체할 수 있습니다.
$masterPassword = '1064';

# 특수 비밀번호
# 이 비밀번호로 이름 변경을 하면 그 섬의 자금, 식량이 최대값이 됩니다.
$HspecialPassword = '1004';

# 관리자 이름
$adminName = '관리자';

# 관리자 메일 주소
$email = '****@***.**.**';

# 게시판 이름
$bbsname = '이노라 제도 게시판';

# 게시판 주소
$bbs = 'https://esils.com/hako/inora-1_10/bbs/petit.cgi';

# 게시판 로그 파일
$bbs_log = './bbs/petit.log';

# 홈페이지 주소
$toppage = 'https://esils.com/hako/inora-1_10/';

# 매뉴얼 주소
$manual = './man.html';

# 디렉터리 퍼미션
$HdirMode = 0755;

# 데이터 디렉터리 이름
$HdirName = 'data';

#----------------------------------------------------------------------
# 반드시 설정해야 하는 부분은 여기까지
#----------------------------------------------------------------------

#----------------------------------------------------------------------
# 아래는 취향에 따라 설정하는 부분
#----------------------------------------------------------------------

#----------------------------------------
# 게임 진행, 파일 관련
#----------------------------------------

# 1턴이 몇 초인지
$HunitTime = 3600; # 4시간

# 마지막 턴
$HislandLastTurn = 500;

# 비정상 종료 기준 시간
# 락 후 몇 초가 지나면 강제 해제할지
$unlockTime = 120;

# 섬 최대 수
$HmaxIsland = 30;

# 톱 페이지에 표시할 로그 턴 수
$HtopLogTurn = 1;

# 로그 파일 보관 턴 수
$HlogMax = 8;

# 백업을 몇 턴마다 만들지
$HbackupTurn = 12;

# 백업을 몇 개 남길지
$HbackupTimes = 4;

# 발견 로그 보관 줄 수
$HhistoryMax = 10;

# 방치 섬 포기 명령 자동 입력 턴 수
$HgiveupTurn = 28;

# 명령 입력 한계 수
# 게임 시작 후 변경하면 데이터 파일 호환성이 깨질 수 있습니다.
$HcommandMax = 30;

# 로컬 게시판 사용 여부
# 0: 사용 안 함, 1: 사용
$HuseLbbs = 1;

# 로컬 게시판 줄 수
$HlbbsMax = 10;

# 섬 크기
$HislandSize = 12;

# 다른 사람에게 자금을 보이게 할지
# 0: 보이지 않음
# 1: 보임
# 2: 100 단위 반올림
$HhideMoneyMode = 2;

# 비밀번호 암호화
# 0: 암호화 안 함, 1: 암호화
$cryptOn = 1;

# 디버그 모드
# 1이면 턴 진행 버튼 사용 가능
$Hdebug = 0;

# ----------------------------------------------------------------
# 부정 접근 금지 설정
# 다른 서버에서 모형정원 스크립트로 직접 링크하는 것을 막는 설정입니다.
#
# 1: 다른 사이트 접근 금지
# 0: 사용 안 함
$Href = 0;

# 모형정원 설치 페이지
$ref_page = 'http://localhost/';

# 부정 접근 시 이동할 링크
$ref_main = 'http://localhost/';

# ----------------------------------------------------------------

#----------------------------------------
# 자금, 식량 등의 설정값과 단위
#----------------------------------------

# 초기 자금
$HinitialMoney = 1000;

# 초기 식량
$HinitialFood = 3000;

# 돈 단위
$HunitMoney = '억원';

# 식량 단위
$HunitFood = '00톤';

# 인구 단위
$HunitPop = '00명';

# 넓이 단위
$HunitArea = '00만평';

# 나무 수 단위
$HunitTree = '00그루';

# 나무 1단위당 판매 가격
$HtreeValue = 5;

# 1턴에 늘어나는 나무 수
$HtreeUp = 1;

# 이름 변경 비용
$HcostChangeName = 0;

# 인구 1단위당 식량 소비량
$HeatenFood = 0.2;

#----------------------------------------
# 기지 경험치
#----------------------------------------

# 경험치 최대값
$HmaxExpPoint = 200;

# 레벨 최대값
$maxBaseLevel = 5;  # 미사일 기지
$maxSBaseLevel = 3; # 해저 기지

# 경험치가 몇일 시 레벨업하는지
@baseLevelUp = (20, 60, 120, 200); # 미사일 기지
@sBaseLevelUp = (50, 200);         # 해저 기지

#----------------------------------------
# 방위 시설 자폭
#----------------------------------------

# 괴수에게 밟혔을 시 자폭할지
# 1: 자폭, 0: 자폭 안 함
$HdBaseAuto = 0;

#----------------------------------------
# 재해
#----------------------------------------

# 일반 재해 발생률
# 확률은 0.1% 단위
$HdisEarthquake = 3;   # 지진
$HdisTsunami    = 10;  # 해일
$HdisTyphoon    = 15;  # 태풍
$HdisMeteo      = 15;  # 운석
$HdisHugeMeteo  = 0;   # 거대 운석
$HdisEruption   = 10;  # 분화
$HdisFire       = 5;   # 화재
$HdisMaizo      = 20;  # 매장금
$HdisVirus      = 200; # 이노라 질병
$HdisTyphIno    = 300; # 이노라가 태풍에 날아감

# 이노라 질병
$VIRUS[0] = '감기에 걸려';
$VIRUS[1] = '전염병에 걸려';
$VIRUS[2] = '맹장이 되어';
$VIRUS[3] = '두통이 심해서';
$VIRUS[4] = '복통이 심해서';

# 지반 침하
$HdisFallBorder = 200; # 안전 한계 넓이
$HdisFalldown   = 0;   # 그 넓이를 넘었을 시 확률

# 괴수
$HdisMonsBorder1 = 2000; # 인구 기준 1
$HdisMonsBorder2 = 3000; # 인구 기준 2
$HdisMonsBorder3 = 4000; # 인구 기준 3
$HdisMonster     = 2;    # 단위 면적당 출현률

# 괴수 종류 수
$HmonsterNumber  = 4;

# 각 기준에서 나오는 괴수 번호의 최대값
$HmonsterLevel1  = 1;
$HmonsterLevel2  = 2;
$HmonsterLevel3  = 3;

# 괴수 이름
@HmonsterName =
    (
     '메카 이노라',
     '괴수 산지라',
     '괴수 이노라 고스트',
     '괴수 고래',
     '베이비 이노라',
     '비만 이노라',
     '그린 이노라',
     '레드 이노라',
     '다크 이노라',
     '킹 이노라',
     '퀸 이노라',
     '그레이 이노라'
);

# 최저 체력, 체력 폭, 특수 능력, 경험치, 시체 가격
@HmonsterBHP     = ( 2, 1, 1, 4,  1, 1, 1, 1);
@HmonsterDHP     = ( 0, 2, 0, 2,  0, 0, 0, 0);
@HmonsterSpecial = ( 0, 3, 2, 4,  2, 0, 0, 0, 1);
@HmonsterExp     = ( 5, 7, 10,20);
@HmonsterValue   = ( 0, 500, 300, 1500);

# 특수 능력 내용
# 0: 없음
# 1: 발이 빠름
# 2: 발이 매우 빠름
# 3: 홀수 턴 경화
# 4: 짝수 턴 경화
# 5: 자주 잠
# 6: 쉽게 화냄

# 괴수 이미지 파일
$HmonsterImage[0]  = 'monster0.png';
$HmonsterImage[1]  = 'monster1.png';
$HmonsterImage[2]  = 'monster2.png';
$HmonsterImage[3]  = 'monster3.png';
$HmonsterImage[4]  = 'monster5.png';
$HmonsterImage[5]  = 'monster6.png';
$HmonsterImage[6]  = 'monster7.png';
$HmonsterImage[7]  = 'monster8.png';
$HmonsterImage[8]  = 'monster9.png';
$HmonsterImage[9]  = 'monster10.png';
$HmonsterImage[10] = 'monster11.png';
$HmonsterImage[11] = 'monster6.png';

# 괴수 이미지 파일 2
# 경화 중
@HmonsterImage2 =
    ('', 'monster4.png', '', 'monster4.png');

# 이노라 성장도
$INORA[0] = 100;
$INORA[1] = 200;
$INORA[2] = 400;

# 식량 소비율 보정
$FOOD[4]  = 5;  # 베이비 이노라
$FOOD[5]  = 20; # 비만 이노라
$FOOD[6]  = 10; # 그린 이노라
$FOOD[7]  = 10; # 레드 이노라
$FOOD[8]  = 10; # 다크 이노라
$FOOD[9]  = 15; # 킹 이노라
$FOOD[10] = 12; # 퀸 이노라
$FOOD[11] = 8;  # 그레이 이노라

# 기본 수면 턴 수
$SLEEP[4]  = 6;
$SLEEP[5]  = 7;
$SLEEP[6]  = 3;
$SLEEP[7]  = 3;
$SLEEP[8]  = 3;
$SLEEP[9]  = 4;
$SLEEP[10] = 4;
$SLEEP[11] = 2;

# 기본 행동 턴 수
$WAKE[4]  = 4;
$WAKE[5]  = 3;
$WAKE[6]  = 7;
$WAKE[7]  = 7;
$WAKE[8]  = 7;
$WAKE[9]  = 6;
$WAKE[10] = 6;
$WAKE[11] = 8;

# 명령에 의한 성장 보정값
@rebi_def  = (50, 100, 300, 0);
@rebi_ang  = (0,0,0,0, 0, 0, 1, 1, 1, 2, 0, 3);
@rebi_heal = (0,0,0,0, 0, 0, 2, 2, 2, 1, 0, 3);
@rebi_hp   = (0,0,0,0, 1, 2, 1, 1, 1, 1, 0, 0);
@rebi_arm  = (0,0,0,0, 1, 1, 2, 1, 0, 1, 0, 2);
@rebi_cute = (0,0,0,0, 1, 1, 0, 2, 1, 1, 0, 0);
@rebi_int  = (0,0,0,0, 1, 1, 1, 0, 2, 1, 0, 0);

# 이노라 이벤트
$HinoraEventQuake = 250;  # 기분이 나빠서 지진

#----------------------------------------
# 유전
#----------------------------------------

# 유전 수입
$HoilMoney = 1000;

# 유전 고갈 확률
$HoilRatio = 40;

#----------------------------------------
# 기념비
#----------------------------------------

# 기념비 종류 수
$HmonumentNumber = 4;

# 기념비 이름
@HmonumentName =
    (
     '모노리스',
     '평화 기념비',
     '전쟁의 비',
     '이노라 기념비'
    );

# 기념비 이미지 파일
@HmonumentImage =
    (
     'monument0.png',
     'monument0.png',
     'monument0.png',
     'monument1.png'
    );

#----------------------------------------
# 상 관련
#----------------------------------------

# 턴 컵을 몇 턴마다 줄지
$HturnPrizeUnit = 100;

# 상 이름
$Hprize[0]  = '턴 컵';
$Hprize[1]  = '번영상';
$Hprize[2]  = '초번영상';
$Hprize[3]  = '궁극 번영상';
$Hprize[4]  = '평화상';
$Hprize[5]  = '초평화상';
$Hprize[6]  = '궁극 평화상';
$Hprize[7]  = '재난상';
$Hprize[8]  = '초재난상';
$Hprize[9]  = '궁극 재난상';
$Hprize[10] = '이노라 힘자랑';
$Hprize[11] = '이노라 콘테스트';
$Hprize[12] = '이노라 퀴즈 대회';

#----------------------------------------
# 외형 관련
#----------------------------------------

# BODY 태그 옵션
$htmlBody = 'BGCOLOR="#EEFFFF"';

# 게임 제목
$Htitle = '이노라 제도';

# 태그

# 제목 문자
$HtagTitle_ = '<FONT SIZE=7 COLOR="#8888ff">';
$H_tagTitle = '</FONT>';

# H1 태그용
$HtagHeader_ = '<FONT COLOR="#4444ff">';
$H_tagHeader = '</FONT>';

# 큰 글자
$HtagBig_ = '<FONT SIZE=6>';
$H_tagBig = '</FONT>';

# 이노라 이름
$HtagIName_ = '<FONT COLOR="#4444ff"><B>';
$H_tagIName = '</B></FONT>';

# 섬 이름 등
$HtagName_ = '<FONT COLOR="#a06040"><B>';
$H_tagName = '</B></FONT>';

# 흐린 섬 이름
$HtagName2_ = '<FONT COLOR="#808080"><B>';
$H_tagName2 = '</B></FONT>';

# 순위 번호 등
$HtagNumber_ = '<FONT COLOR="#800000"><B>';
$H_tagNumber = '</B></FONT>';

# 순위표 제목
$HtagTH_ = '<FONT COLOR="#C00000"><B>';
$H_tagTH = '</B></FONT>';

# 개발 계획 이름
$HtagComName_ = '<FONT COLOR="#d08000"><B>';
$H_tagComName = '</B></FONT>';

# 재해
$HtagDisaster_ = '<FONT COLOR="#ff0000"><B>';
$H_tagDisaster = '</B></FONT>';

# 로컬 게시판, 관광객 글
$HtagLbbsSS_ = '<FONT COLOR="#0000ff"><B>';
$H_tagLbbsSS = '</B></FONT>';

# 로컬 게시판, 섬 주인 글
$HtagLbbsOW_ = '<FONT COLOR="#ff0000"><B>';
$H_tagLbbsOW = '</B></FONT>';

# 로컬 게시판, 섬 없는 관광객 글
$HtagLbbsSK_ = '<FONT COLOR="#003333"><B>';
$H_tagLbbsSK = '</B></FONT>';

# 일반 문자색
$HnormalColor = '#000000';

# 순위표, 셀 속성
$HbgTitleCell   = 'BGCOLOR="#ccffcc"';
$HbgNumberCell  = 'BGCOLOR="#ccffcc"';
$HbgNameCell    = 'BGCOLOR="#ccffff"';
$HbgInfoCell    = 'BGCOLOR="#ccffff"';
$HbgCommentCell = 'BGCOLOR="#ccffcc"';
$HbgInputCell   = 'BGCOLOR="#ccffcc"';
$HbgMapCell     = 'BGCOLOR="#ccffcc"';
$HbgCommandCell = 'BGCOLOR="#ccffcc"';

#----------------------------------------
# 헤더 / 푸터
#----------------------------------------

# 헤더
sub tempHeader {
    return if($Hasync);

    my($HimgFlag) = 0;
    if($HimgLine eq '' || $HimgLine eq $imageDir){
        $baseIMG = $imageDir;
        $HimgFlag = 1;
    } else {
        $baseIMG = $HimgLine;
    }

    # 이미지 로컬 설정 오류를 강제로 해제
    $baseIMG =~ s/筑集眺餅/데스크톱/g;

    my $time_ = get_time((stat($bbs_log))[9],1);

    out(<<END);
Content-Type: text/html; charset=UTF-8

<HTML>
<HEAD>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
<TITLE>
$Htitle
</TITLE>
<STYLE type="text/css">
<!--
a:link      { color:#3300CC }
a:visited   { color:#3300CC }
a:active    { color:#FF0000 }
a:hover     { color:#FF0000 }
th          { filter:blur(direction=120,strength=2) }
-->
</STYLE>
<BASE HREF="$baseIMG/">
</HEAD>
$BODY
<NOBR>
<A HREF="http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html">모형정원 제도 스크립트 배포처</A>
　<A HREF="http://appoh.execweb.cx/hakoniwa/">모형정원 Java 스크립트판 배포처</A>
　<A HREF="http://espion.just-size.jp/archives/dist_hako/">이노라 제도 스크립트 배포처</A>
　<A HREF="$toppage">톱 페이지</A>
　<A HREF="$bbs">$bbsname</A>$time_
　<A HREF="$HthisFile?LogFileView=1" target=_blank>최근 사건</A>
　<A HREF="$manual">매뉴얼</A>
</NOBR>
<HR>
END

    if($HimgFlag) {
        out("<FONT COLOR=RED>서버 부하를 줄이기 위해 이미지 로컬 설정을 해 주세요.</FONT>");
        out("<HR>");
    }
}

# 푸터
sub tempFooter {
    out(<<END);
<HR>
<P align=right>
<NOBR>
<A HREF="http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html" target=_blank>모형정원 제도 스크립트 배포처</A>
　　<A HREF="$toppage">톱 페이지</A>
　　<A HREF="$bbs">$bbsname</A>
　　<A HREF="$HthisFile?LogFileView=1" target=_blank>최근 사건</A>
</NOBR><BR><BR>
관리자:$adminName(<A HREF="mailto:$email">$email</A>)<BR>
</P>
</BODY>
</HTML>
END
}

1;
