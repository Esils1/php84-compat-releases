#!/usr/bin/perl
use utf8;
use Encode ();
BEGIN {
    require FindBin;
    FindBin->import();
    chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
    unshift @INC, $FindBin::Bin;
    binmode STDOUT, ':encoding(UTF-8)';
    binmode STDERR, ':encoding(UTF-8)';
}
# ↑ 서버에 맞게 변경해 주세요.
# perl5용입니다.

#----------------------------------------------------------------------
# 箱庭諸島 ver2.30
# 메인 스크립트
# 사용 조건, 사용 방법 등은 hako-readme.txt 파일을 참조
#
# 箱庭諸島 페이지: http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html
#----------------------------------------------------------------------
# 이노라 제도
#----------------------------------------------------------------------

require ('hako-ini.cgi');

#----------------------------------------------------------------------
# 이 이후의 스크립트는 변경될 것을 전제로 하지 않지만,
# 수정해도 상관없습니다.
# 명령의 이름, 가격 등은 이해하기 쉬울 것입니다.
#----------------------------------------------------------------------

#----------------------------------------------------------------------
# 각종 상수
#----------------------------------------------------------------------

# 이 파일
$HthisFile = "$baseDir/hako-main.cgi";

# 지형 번호
$HlandSea       = 0;  # 바다
$HlandWaste     = 1;  # 황무지
$HlandPlains    = 2;  # 평지
$HlandTown      = 3;  # 마을 계열
$HlandForest    = 4;  # 숲
$HlandFarm      = 5;  # 농장
$HlandFactory   = 6;  # 공장
$HlandBase      = 7;  # 미사일 기지
$HlandDefence   = 8;  # 방위 시설
$HlandMountain  = 9;  # 산
$HlandMonster   = 10; # 괴수
$HlandSbase     = 11; # 해저 기지
$HlandOil       = 12; # 해저 유전
$HlandMonument  = 13; # 기념비
$HlandHaribote  = 14; # 허수 시설

# 명령
$HcommandTotal = 36; # 명령 종류 수

# 명령 분류
# 이 명령 분류에는 자동 입력 계열 명령을 설정하지 마세요.
@HcommandDivido = 
        (
        '개발,0,10',   # 계획 번호 00〜10
        '건설,11,24',  # 계획 번호 11〜30
        '이노라,25,34',# 계획 번호 25〜34
        '공격,35,40',  # 계획 번호 31〜40
        '운영,41,60'   # 계획 번호 41〜60
        );

# 주의: 공백을 넣지 마세요.
# ○→        '개발,0,10',        # 계획 번호 00〜10
# ×→        '개발, 0  ,10  ',   # 계획 번호 00〜10

# 계획 번호 설정
# 개간 계열
$HcomPrepare  = 01; # 개간
$HcomPrepare2 = 02; # 땅 고르기
$HcomReclaim  = 03; # 매립
$HcomDestroy  = 04; # 굴착
$HcomSellTree = 05; # 벌채
$HcomFastRec  = 06; # 고속 매립
$HcomFastDes  = 07; # 고속 굴착

# 건설 계열
$HcomPlant      = 11; # 식림
$HcomFarm       = 12; # 농장 건설
$HcomFactory    = 13; # 공장 건설
$HcomMountain   = 14; # 채굴장 정비
$HcomBase       = 15; # 미사일 기지 건설
$HcomDbase      = 16; # 방위 시설 건설
$HcomSbase      = 17; # 해저 기지 건설
$HcomMonument   = 18; # 기념비 건조
$HcomHaribote   = 19; # 허수 시설 설치
$HcomFastPlant  = 20; # 고속 식림
$HcomFastFarm   = 21; # 고속 농장 건설
$HcomFastFact   = 22; # 고속 공장 건설
$HcomFastBase   = 23; # 고속 미사일 기지 건설
$HcomFastDbase  = 24; # 고속 방위 시설 건설

# 이노라 계열
$HcomSchool   = 25; # 이노라 학교
$HcomEste     = 26; # 이노라 에스테
$HcomTreaning = 27; # 이노라 헬스장
$HcomRest     = 28; # 이노라 요양
$HcomPlay     = 29; # 이노라 놀이

# 발사 계열
$HcomMissileNM  = 35; # 미사일 발사
$HcomMissilePP  = 36; # PP 미사일 발사

# 운영 계열
$HcomDoNothing  = 41; # 자금 조달
$HcomSell       = 42; # 식량 수출
$HcomMoney      = 43; # 자금 지원
$HcomFood       = 44; # 식량 지원
$HcomPropaganda = 45; # 이노라 대행진
$HcomGiveup     = 46; # 섬 포기

# 자동 입력 계열
$HcomAutoPrepare  = 61; # 전체 개간
$HcomAutoPrepare2 = 62; # 전체 땅 고르기
$HcomAutoDelete   = 63; # 전체 명령 삭제

# 순서
@HcomList =
    ($HcomPrepare, $HcomSell, $HcomPrepare2, $HcomReclaim, $HcomDestroy,
     $HcomSellTree, $HcomFastRec, $HcomFastDes, $HcomPlant, $HcomFarm, 
     $HcomFactory, $HcomMountain, $HcomBase, $HcomDbase, $HcomFastPlant,
     $HcomFastFarm, $HcomFastFact, $HcomFastBase, 
     $HcomFastDbase, $HcomMonument, $HcomHaribote,
     $HcomSchool, $HcomEste, $HcomTreaning, $HcomRest, $HcomPlay,
     $HcomMissileNM, $HcomMissilePP, $HcomDoNothing,
     $HcomMoney, $HcomFood, $HcomPropaganda, $HcomGiveup,
     $HcomAutoPrepare, $HcomAutoPrepare2, $HcomAutoDelete);

# 계획 이름과 가격
$HcomName[$HcomPrepare]      = '개간';
$HcomCost[$HcomPrepare]      = 1;
$HcomName[$HcomPrepare2]     = '땅 고르기';
$HcomCost[$HcomPrepare2]     = 30;
$HcomName[$HcomReclaim]      = '매립';
$HcomCost[$HcomReclaim]      = 100;
$HcomName[$HcomDestroy]      = '굴착';
$HcomCost[$HcomDestroy]      = 300;
$HcomName[$HcomSellTree]     = '벌채';
$HcomCost[$HcomSellTree]     = 0;
$HcomName[$HcomPlant]        = '식림';
$HcomCost[$HcomPlant]        = 50;
$HcomName[$HcomFarm]         = '농장 건설';
$HcomCost[$HcomFarm]         = 10;
$HcomName[$HcomFactory]      = '공장 건설';
$HcomCost[$HcomFactory]      = 50;
$HcomName[$HcomMountain]     = '채굴장 정비';
$HcomCost[$HcomMountain]     = 300;
$HcomName[$HcomBase]         = '미사일 기지 건설';
$HcomName2[$HcomBase]        = '미사일 기지';
$HcomCost[$HcomBase]         = 200;
$HcomName[$HcomDbase]        = '방위 시설 건설';
$HcomName2[$HcomDbase]       = '방위 시설';
$HcomCost[$HcomDbase]        = 500;
$HcomName[$HcomFastRec]      = '고속 매립';
$HcomName2[$HcomFastRec]     = '고속 매립';
$HcomCost[$HcomFastRec]      = 500;
$HcomName[$HcomFastDes]      = '고속 굴착';
$HcomCost[$HcomFastDes]      = 1500;
$HcomName[$HcomFastPlant]    = '고속 식림';
$HcomCost[$HcomFastPlant]    = 1000;
$HcomName[$HcomFastFarm]     = '고속 농장 건설';
$HcomName2[$HcomFastFarm]    = '고속 농장';
$HcomCost[$HcomFastFarm]     = 500;
$HcomName[$HcomFastFact]     = '고속 공장 정비';
$HcomName2[$HcomFastFact]    = '고속 공장';
$HcomCost[$HcomFastFact]     = 1000;
$HcomName[$HcomFastBase]     = '고속 미사일 기지 건설';
$HcomName2[$HcomFastBase]    = '고속 미사일 기지';
$HcomCost[$HcomFastBase]     = 900;
$HcomName[$HcomFastDbase]    = '고속 방위 시설 건설';
$HcomName2[$HcomFastDbase]   = '고속 방위';
$HcomCost[$HcomFastDbase]    = 2000;
$HcomName[$HcomSbase]        = '해저 기지 건설';
$HcomCost[$HcomSbase]        = 999999;
$HcomName[$HcomMonument]     = '기념비 건조';
$HcomCost[$HcomMonument]     = 9999;
$HcomName[$HcomHaribote]     = '허수 시설 설치';
$HcomCost[$HcomHaribote]     = 1;
$HcomName[$HcomSchool]       = '이노라 학교';
$HcomName2[$HcomSchool]      = '학교';
$HcomCost[$HcomSchool]       = 300;
$HcomName[$HcomEste]         = '이노라 에스테';
$HcomName2[$HcomEste]        = '에스테';
$HcomCost[$HcomEste]         = 300;
$HcomName[$HcomTreaning]     = '이노라 헬스장';
$HcomName2[$HcomTreaning]    = '헬스장';
$HcomCost[$HcomTreaning]     = 800;
$HcomName[$HcomRest]         = '이노라 요양';
$HcomName2[$HcomRest]        = '요양';
$HcomCost[$HcomRest]         = 500;
$HcomName[$HcomPlay]         = '이노라 놀이';
$HcomName2[$HcomPlay]        = '놀이';
$HcomCost[$HcomPlay]         = 400;
$HcomName[$HcomMissileNM]    = '미사일 발사';
$HcomCost[$HcomMissileNM]    = 20;
$HcomName[$HcomMissilePP]    = 'PP 미사일 발사';
$HcomCost[$HcomMissilePP]    = 40;
$HcomName[$HcomDoNothing]    = '자금 조달';
$HcomCost[$HcomDoNothing]    = 0;
$HcomName[$HcomSell]         = '식량 수출';
$HcomCost[$HcomSell]         = -100;
$HcomName[$HcomMoney]        = '자금 지원';
$HcomCost[$HcomMoney]        = 100;
$HcomName[$HcomFood]         = '식량 지원';
$HcomCost[$HcomFood]         = -100;
$HcomName[$HcomPropaganda]   = '이노라 대행진';
$HcomCost[$HcomPropaganda]   = 1000;
$HcomName[$HcomGiveup]       = '섬 포기';
$HcomCost[$HcomGiveup]       = 0;
$HcomName[$HcomAutoPrepare]  = '개간 자동 입력';
$HcomCost[$HcomAutoPrepare]  = 0;
$HcomName[$HcomAutoPrepare2] = '땅 고르기 자동 입력';
$HcomCost[$HcomAutoPrepare2] = 0;
$HcomName[$HcomAutoDelete]   = '전체 계획 백지화';
$HcomCost[$HcomAutoDelete]   = 0;

#----------------------------------------------------------------------
# 변수
#----------------------------------------------------------------------

# COOKIE
my($defaultID);       # 섬 이름
my($defaultTarget);   # 대상 이름

# 섬 좌표 수
$HpointNumber = $HislandSize * $HislandSize;

#----------------------------------------------------------------------
# 메인
#----------------------------------------------------------------------


if($Href) {
    my($page) = $ENV{'HTTP_REFERER'};
    $page =~ tr/+/ /;
    $page =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
    if (!($page =~ /$ref_page/i)) { &access; }
}

sub access {
    print "Content-type: text/html; charset=UTF-8\n\n";
    out (<<'END');
<HTML>
	
<HEAD>
	<TITLE>접근 금지</TITLE></HEAD>
<BODY><BR><BR><center><H1>접근 금지</H1><br>
<font size=+1>TOP 페이지에서 들어와 주세요.<BR><br>
<A HREF=$ref_main>$ref_main</A>
</font>
</BODY></HTML>
END
    exit;
}

# 돌아가기 링크
$HtempBack = "<A HREF=\"$HthisFile\">${HtagBig_}TOP으로 돌아가기${H_tagBig}</A>";
$BODY = "<BODY $htmlBody>";

# 락 걸기
if(!hakolock()) {
    # 락 실패
    # 헤더 출력
    tempHeader();

    # 락 실패 메시지
    tempLockFail();

    # 푸터 출력
    tempFooter();

    # 종료
    exit(0);
}

# 난수 초기화
srand(time^$$);

# COOKIE 읽기
cookieInput();

# CGI 읽기
cgiInput();

# 섬 데이터 읽기
if(readIslandsFile($HcurrentID) == 0) {
    unlock();
    tempHeader();
    tempNoDataFile();
    tempFooter();
    exit(0);
}

# 템플릿 초기화
tempInitialize();

# COOKIE 출력
cookieOutput();

# 헤더 출력
if($HmainMode eq 'owner' && $HjavaMode eq 'java' ||
   $HmainMode eq 'commandJava' || # 명령 입력 모드
   $HmainMode eq 'comment' && $HjavaMode eq 'java' || # 댓글 입력 모드
   $HmainMode eq 'lbbs' && $HjavaMode eq 'java') { # 댓글 입력 모드
    $BODY = "<BODY onload=\"init()\" $htmlBody>";
    require('hako-js.cgi');
    require('hako-map.cgi');

    # 헤더 출력
    tempHeader();

    if($HmainMode eq 'commandJava') {
        # 개발 모드
        commandJavaMain();
    } elsif($HmainMode eq 'comment') {
        # 댓글 입력 모드
        commentMain();
    } elsif($HmainMode eq 'lbbs') {
        # 로컬 게시판 모드
        localBbsMain();
    }else{
        ownerMain();
    }

    # 푸터 출력
    tempFooter();

    # 종료
    exit(0);
}else{
    # 헤더 출력
    tempHeader();
}

if($HmainMode eq 'turn') {
    # 턴 진행
    require('hako-turn.cgi');
    require('hako-top.cgi');
    turnMain();

} elsif($HmainMode eq 'new') {
    # 섬 신규 작성
    require('hako-turn.cgi');
    require('hako-map.cgi');
    newIslandMain();

} elsif($HmainMode eq 'print') {
    # 관광 모드
    require('hako-map.cgi');
    printIslandMain();

} elsif($HmainMode eq 'owner') {

    # 개발 모드
    require('hako-map.cgi');
    ownerMain();

} elsif($HmainMode eq 'command') {
    # 명령 입력 모드
    require('hako-map.cgi');
    commandMain();

} elsif($HmainMode eq 'comment') {
    # 댓글 입력 모드
    require('hako-map.cgi');
    commentMain();

} elsif($HmainMode eq 'lbbs') {

    # 로컬 게시판 모드
    require('hako-map.cgi');
    localBbsMain();

} elsif($HmainMode eq 'change') {
    # 정보 변경 모드
    require('hako-turn.cgi');
    require('hako-top.cgi');
    changeMain();

} elsif($HmainMode eq 'logView') {
    # LOG 모드
    require('hako-top.cgi');
    logViewMain();

} else {
    # 그 외의 경우 TOP 페이지 모드
    require('hako-top.cgi');
    topPageMain();
}

# 푸터 출력
tempFooter();

# 종료
exit(0);

# 명령을 앞으로 당김
sub slideFront {
    my($command, $number) = @_;
    my($i);

    # 각각 당김
    splice(@$command, $number, 1);

    # 마지막에는 자금 조달
    $command->[$HcommandMax - 1] = {
        'kind' => $HcomDoNothing,
        'target' => 0,
        'x' => 0,
        'y' => 0,
        'arg' => 0
        };
}

# 명령을 뒤로 밀기
sub slideBack {
    my($command, $number) = @_;
    my($i);

    # 각각 밀기
    return if $number == $#$command;
    pop(@$command);
    splice(@$command, $number, 0, $command->[$number]);
}

#----------------------------------------------------------------------
# 섬 데이터 입출력
#----------------------------------------------------------------------

# 전체 섬 데이터 읽기
sub readIslandsFile {
    my($num) = @_; # 0이면 지형 읽지 않음
                   # -1이면 전체 지형을 읽음
                   # 번호이면 해당 섬의 지형만 읽음

    # 데이터 파일 열기
    if(!open(IN, "<:raw", "${HdirName}/hakojima.dat")) {
        rename("${HdirName}/hakojima.tmp", "${HdirName}/hakojima.dat");
        if(!open(IN, "<:raw", "${HdirName}/hakojima.dat")) {
            return 0;
        }
    }

    # 각 파라미터 읽기
    $HislandTurn     = int(<IN>); # 턴 수
    if($HislandTurn == 0) {
        return 0;
    }
    $HislandLastTime = int(<IN>); # 최종 갱신 시간
    if($HislandLastTime == 0) {
        return 0;
    }
    $HislandNumber   = int(<IN>); # 섬 총수
    $HislandNextID   = int(<IN>); # 다음에 할당할 ID

    # 턴 처리 판정
    my($now) = time;
    if((($Hdebug == 1) && 
        ($HmainMode eq 'Hdebugturn')) ||
       (($now - $HislandLastTime) >= $HunitTime)) {
        if($HislandLastTurn > $HislandTurn) {
            $turnMode = "debug" if($HmainMode eq 'Hdebugturn');
            $HmainMode = 'turn';
            $num = -1; # 전체 섬 읽기
        }
    }

    # 섬 읽기
    my($i);
    for($i = 0; $i < $HislandNumber; $i++) {
         $Hislands[$i] = readIsland($num);
         $HidToNumber{$Hislands[$i]->{'id'}} = $i;
    }

    # 파일 닫기
    close(IN);

    return 1;
}

# 섬 하나 읽기
sub readIsland {
    my($num) = @_;
    my($name, $id, $prize, $absent, $comment, $password, $money, $food,
       $pop, $area, $farm, $factory, $mountain, $score, $fire, $ownername);
    my($i_name, $i_cont, $i_gene, $i_age, $i_type, $i_ang, $i_heal,
         $i_hp, $i_cute, $i_arm, $i_int, $i_sleep);

    $name = <IN>; # 섬 이름
    chomp($name);
    if($name =~ s/,(.*)$//g) {
        $score = int($1);
    } else {
        $score = 0;
    }
    $name = normalizeText($name);
    $id = int(<IN>);        # ID 번호
    $prize = <IN>;          # 수상
    chomp($prize);
    $prize = normalizeText($prize);
    $absent = int(<IN>);    # 연속 자금 조달 수
    $comment = <IN>;        # 댓글
    chomp($comment);
    $comment = normalizeText($comment);
    $password = <IN>;       # 암호화 비밀번호
    chomp($password);
    $money = int(<IN>);     # 자금
    $food = int(<IN>);      # 식량
    $pop = int(<IN>);       # 인구
    $area = int(<IN>);      # 넓이
    $farm = int(<IN>);      # 농장
    $factory = int(<IN>);   # 공장
    $mountain = int(<IN>);  # 채굴장
    $fire = int(<IN>);      # 미사일 발사 수
    $ownername = <IN>;      # 오너 이름
    chomp($ownername);
    $ownername = normalizeText($ownername);
    $i_name = <IN>;         # 이노라 이름
    chomp($i_name);
    $i_name = normalizeText($i_name);
    $i_cont = <IN>;         # 이노라 콘테스트 수상 수
    chomp($i_cont);
    $i_cont = normalizeText($i_cont);
    $i_gene = int(<IN>);    # 이노라 세대
    $i_age = int(<IN>);     # 이노라 나이
    $i_type = int(<IN>);    # 이노라 종류
    $i_ang = int(<IN>);     # 이노라 기분
    $i_heal = int(<IN>);    # 이노라 건강도
    $i_hp = int(<IN>);      # 이노라 체력
    $i_cute = int(<IN>);    # 이노라 매력
    $i_arm = int(<IN>);     # 이노라 완력
    $i_int = int(<IN>);     # 이노라 지력
    $i_sleep = int(<IN>);   # 이노라 수면 플래그

    # HidToName 테이블에 저장
    $HidToName{$id} = $name;

    # 지형
    my(@land, @landValue, $line, @command, @lbbs);

    if(($num == -1) || ($num == $id)) {
        if(!open(IIN, "<:raw", "${HdirName}/island.$id")) {
            rename("${HdirName}/islandtmp.$id", "${HdirName}/island.$id");
            if(!open(IIN, "<:raw", "${HdirName}/island.$id")) {
                exit(0);
            }
        }
        my($x, $y);
        for($y = 0; $y < $HislandSize; $y++) {
            $line = <IIN>;
            for($x = 0; $x < $HislandSize; $x++) {
                $line =~ s/^(.)(..)//;
                $land[$x][$y] = hex($1);
                $landValue[$x][$y] = hex($2);
            }
        }

        # 명령
        my($i);
        for($i = 0; $i < $HcommandMax; $i++) {
            $line = <IIN>;
            $line =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
            $command[$i] = {
                'kind' => int($1),
                'target' => int($2),
                'x' => int($3),
                'y' => int($4),
                'arg' => int($5)
                }
        }

        # 로컬 게시판
        for($i = 0; $i < $HlbbsMax; $i++) {
            $line = <IIN>;
            chomp($line);
            $lbbs[$i] = normalizeText($line);
        }

        close(IIN);
    }

    # 섬 형식으로 반환
    return {
         'name' => $name,
         'id' => $id,
         'score' => $score,
         'prize' => $prize,
         'absent' => $absent,
         'comment' => $comment,
         'password' => $password,
         'money' => $money,
         'food' => $food,
         'pop' => $pop,
         'area' => $area,
         'farm' => $farm,
         'factory' => $factory,
         'mountain' => $mountain,
         'fire' => $fire,
         'ownername' => $ownername,
         'i_name' => $i_name,
         'i_cont' => $i_cont,
         'i_gene' => $i_gene,
         'i_age'  => $i_age,
         'i_type' => $i_type,
         'i_ang'  => $i_ang,
         'i_heal' => $i_heal,
         'i_hp'   => $i_hp,
         'i_cute' => $i_cute,
         'i_arm'  => $i_arm,
         'i_int'  => $i_int,
         'i_sleep'  => $i_sleep,
         'land' => \@land,
         'landValue' => \@landValue,
         'command' => \@command,
         'lbbs' => \@lbbs,
    };
}

# 전체 섬 데이터 쓰기
sub writeIslandsFile {
    my($num) = @_;

    # 파일 열기
    open(OUT, ">:encoding(UTF-8)", "${HdirName}/hakojima.tmp");

    # 각 파라미터 쓰기
    print OUT "$HislandTurn\n";
    print OUT "$HislandLastTime\n";
    print OUT "$HislandNumber\n";
    print OUT "$HislandNextID\n";

    # 섬 쓰기
    my($i);
    for($i = 0; $i < $HislandNumber; $i++) {
         writeIsland($Hislands[$i], $num);
    }

    # 파일 닫기
    close(OUT);

    # 본래 이름으로 변경
    unlink("${HdirName}/hakojima.dat");
    rename("${HdirName}/hakojima.tmp", "${HdirName}/hakojima.dat");
}

# 섬 하나 쓰기
sub writeIsland {
    my($island, $num) = @_;
    my($score);
    $score = int($island->{'score'});
    print OUT $island->{'name'} . ",$score\n";
    print OUT $island->{'id'} . "\n";
    print OUT $island->{'prize'} . "\n";
    print OUT $island->{'absent'} . "\n";
    print OUT $island->{'comment'} . "\n";
    print OUT $island->{'password'} . "\n";
    print OUT $island->{'money'} . "\n";
    print OUT $island->{'food'} . "\n";
    print OUT $island->{'pop'} . "\n";
    print OUT $island->{'area'} . "\n";
    print OUT $island->{'farm'} . "\n";
    print OUT $island->{'factory'} . "\n";
    print OUT $island->{'mountain'} . "\n";
    print OUT $island->{'fire'} . "\n";
    print OUT $island->{'ownername'} . "\n";
    print OUT $island->{'i_name'} . "\n";
    print OUT $island->{'i_cont'} . "\n";
    print OUT $island->{'i_gene'} . "\n";
    print OUT $island->{'i_age'} . "\n";
    print OUT $island->{'i_type'} . "\n";
    print OUT $island->{'i_ang'} . "\n";
    print OUT $island->{'i_heal'} . "\n";
    print OUT $island->{'i_hp'} . "\n";
    print OUT $island->{'i_cute'} . "\n";
    print OUT $island->{'i_arm'} . "\n";
    print OUT $island->{'i_int'} . "\n";
    print OUT $island->{'i_sleep'} . "\n";

    # 지형
    if(($num <= -1) || ($num == $island->{'id'})) {
        open(IOUT, ">:encoding(UTF-8)", "${HdirName}/islandtmp.$island->{'id'}");

        my($land, $landValue);
        $land = $island->{'land'};
        $landValue = $island->{'landValue'};
        my($x, $y);
        for($y = 0; $y < $HislandSize; $y++) {
            for($x = 0; $x < $HislandSize; $x++) {
                printf IOUT ("%x%02x", $land->[$x][$y], $landValue->[$x][$y]);
            }
            print IOUT "\n";
        }

        # 명령
        my($command, $cur, $i);
        $command = $island->{'command'};
        for($i = 0; $i < $HcommandMax; $i++) {
            printf IOUT ("%d,%d,%d,%d,%d\n", 
                         $command->[$i]->{'kind'},
                         $command->[$i]->{'target'},
                         $command->[$i]->{'x'},
                         $command->[$i]->{'y'},
                         $command->[$i]->{'arg'}
                         );
        }

        # 로컬 게시판
        my($lbbs);
        $lbbs = $island->{'lbbs'};
        for($i = 0; $i < $HlbbsMax; $i++) {
            print IOUT $lbbs->[$i] . "\n";
        }

        close(IOUT);
        unlink("${HdirName}/island.$island->{'id'}");
        rename("${HdirName}/islandtmp.$island->{'id'}", "${HdirName}/island.$island->{'id'}");
    }
}

#----------------------------------------------------------------------
# 입출력
#----------------------------------------------------------------------

# 표준 출력으로 출력
sub out {
print STDOUT ($_[0]);
}

# 디버그 로그
sub HdebugOut {
   open(DOUT, ">>debug.log");
   print DOUT ($_[0]);
   close(DOUT);
}

# CGI 읽기
sub cgiInput {
    my($line, $getLine);

    # 입력값은 UTF-8을 우선으로 읽고, 기존 데이터 호환을 위해 CP949/EUC-KR/Shift_JIS도 보정
    $line = <>;
    $line = '' unless defined($line);
    $line =~ tr/+/ /;
    $line =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
    $line = normalizeText($line);
    $line =~ s/[\x00-\x1f\,]//g;

    # GET 값도 받기
    $getLine = $ENV{'QUERY_STRING'};
    $getLine = '' unless defined($getLine);

    # 대상 섬
    if($line =~ /CommandButton([0-9]+)=/) {
        # 명령 전송 버튼인 경우
        $HcurrentID = $1;
        $defaultID = $1;
    }

    if($line =~ /ISLANDNAME=([^\&]*)\&/){
        # 이름 지정인 경우
        $HcurrentName = cutColumn($1, 32);
    }
    if($line =~ /MONSTERNAME=([^\&]*)\&/){
        # 이름 지정인 경우
        $Hi_name = cutColumn($1, 32);
    }

    if($line =~ /ISLANDID=([0-9]+)\&/){
        # 그 외의 경우
        $HcurrentID = $1;
        $defaultID = $1;
    }

    # 비밀번호
    if($line =~ /OLDPASS=([^\&]*)\&/) {
        $HoldPassword = $1;
        $HdefaultPassword = htmlEscape(cutColumn($1,32));
    }
    if($line =~ /PASSWORD=([^\&]*)\&/) {
        $HinputPassword = $1;
        $HdefaultPassword = htmlEscape(cutColumn($1,32));
    }
    if($line =~ /PASSWORD2=([^\&]*)\&/) {
        $HinputPassword2 = $1;
    }

    # 메시지
    if($line =~ /MESSAGE=([^\&]*)\&/) {
        $Hmessage = cutColumn($1, 80);
    }

    # 로컬 게시판
    if($line =~ /LBBSNAME=([^\&]*)\&/) {
        $HlbbsName = $1;
        $HdefaultName = htmlEscape(cutColumn($1,32));
    }
    if($line =~ /LBBSMESSAGE=([^\&]*)\&/) {
        $HlbbsMessage = cutColumn($1, 80);
    }

    if($line =~ /IMGLINEMAC=([^&]*)\&/){
        my($flag) = 'file:///' . $1;
        $HimgLine = htmlEscape($flag);
    }

    if($line =~ /IMGLINE=([^&]*)\&/){
        my($flag) = substr($1, 0 , -10);
        $flag =~ tr/\\/\//;
        if($flag eq 'del'){ $flag = $imageDir; } else { $flag = 'file:///' . $flag; }
        $HimgLine = htmlEscape($flag);
    }

    if($line =~ /OWNERNAME=([^\&]*)\&/){
        # 오너 이름 지정인 경우
        $HownerName = cutColumn($1, 22);
    }

    # Java 스크립트 모드
    if($line =~ /JAVAMODE=(cgi|java)/) {
        $HjavaMode = $1;
    }

    # 비동기 통신 플래그
    if($line =~ /async=true\&/) {
        $Hasync = 1;
    }

    if($line =~ /CommandJavaButton([0-9]+)=/) {
        # 명령 전송 버튼인 경우 Java 스크립트
        $HcurrentID = $1;
        $defaultID = $1;
    }

    # main mode 취득
    if($line =~ /TurnButton/) {
        if($Hdebug == 1) {
            $HmainMode = 'Hdebugturn';
        }
    } elsif($line =~ /OwnerButton/) {
        $HmainMode = 'owner';
    } elsif($getLine =~ /Sight=([0-9]*)/) {
        $HmainMode = 'print';
        $HcurrentID = $1;
    } elsif($line =~ /ChangeOwnerName/) {
        $HmainMode = 'change';
    } elsif($getLine =~ /LogFileView=([0-9]*)/) {
        $HmainMode = 'logView';
        $Hlogturn = ($1 > $HlogMax) ? $HlogMax : $1;
    } elsif($line =~ /NewIslandButton/) {
        $HmainMode = 'new';
    } elsif($line =~ /LbbsButton(..)([0-9]*)/) {
        $HmainMode = 'lbbs';
        if($1 eq 'FO') {
            # 관광객
            $HlbbsMode = 0;
            $HforID = $HcurrentID;
        } elsif($1 eq 'OW') {
            # 섬 주인
            $HlbbsMode = 1;
        } else {
            # 삭제
            $HlbbsMode = 2;
        }
        $HcurrentID = $2;

        # 삭제일 수 있으므로 번호 취득
        $line =~ /NUMBER=([^\&]*)\&/;
        $HcommandPlanNumber = $1;

    } elsif($line =~ /ChangeInfoButton/) {
        $HmainMode = 'change';
    } elsif($line =~ /MessageButton([0-9]*)/) {
        $HmainMode = 'comment';
        $HcurrentID = $1;
    } elsif($line =~ /CommandJavaButton/) {
        $HmainMode = 'commandJava';
        $line =~ /COMARY=([^\&]*)\&/;
        $HcommandComary = $1;
    } elsif($line =~ /CommandButton/) {
        $HmainMode = 'command';

        # 명령 모드인 경우 명령 취득
        $line =~ /NUMBER=([^\&]*)\&/;
        $HcommandPlanNumber = $1;
        $line =~ /COMMAND=([^\&]*)\&/;
        $HcommandKind = $1;
        $HdefaultKind = $1;
        $line =~ /AMOUNT=([^\&]*)\&/;
        $HcommandArg = $1;
        $line =~ /TARGETID=([^\&]*)\&/;
        $HcommandTarget = $1;
        $defaultTarget = $1;
        $line =~ /POINTX=([^\&]*)\&/;
        $HcommandX = $1;
        $HdefaultX = $1;
        $line =~ /POINTY=([^\&]*)\&/;
        $HcommandY = $1;
        $HdefaultY = $1;
        $line =~ /COMMANDMODE=(write|insert|delete)/;
        $HcommandMode = $1;

    } else {
        $HmainMode = 'top';
    }

}

# cookie 입력
sub cookieInput {
    my($cookie);

	$cookie = ($ENV{'HTTP_COOKIE'});

    if($cookie =~ /${HthisFile}OWNISLANDID=\(([^\)]*)\)/) {
        $defaultID = $1;
    }
    if($cookie =~ /${HthisFile}OWNISLANDPASSWORD=\(([^\)]*)\)/) {
        $HdefaultPassword = $1;
    }
    if($cookie =~ /${HthisFile}LBBSNAME=\(([^\)]*)\)/) {
        $HdefaultName = $1;
    }
    if($cookie =~ /${HthisFile}POINTX=\(([^\)]*)\)/) {
        $HdefaultX = $1;
    }
    if($cookie =~ /${HthisFile}POINTY=\(([^\)]*)\)/) {
        $HdefaultY = $1;
    }
    if($cookie =~ /${HthisFile}KIND=\(([^\)]*)\)/) {
        $HdefaultKind = $1;
    }
    if($cookie =~ /${HthisFile}IMGLINE=\(([^\)]*)\)/) {
        $HimgLine = $1;
    }
    if($cookie =~ /${HthisFile}JAVAMODE=\(([^\)]*)\)/) {
        $makeMode = $1;
    }

}

# cookie 출력
sub cookieOutput {
    my($cookie, $info);

    # 삭제되는 기한 설정
    my($sec, $min, $hour, $date, $mon, $year, $day, $yday, $dummy) =
        gmtime(time + 30 * 86400); # 현재 + 30일

    # 두 자리화
    $year += 1900;
    if ($date < 10) { $date = "0$date"; }
    if ($hour < 10) { $hour = "0$hour"; }
    if ($min < 10) { $min  = "0$min"; }
    if ($sec < 10) { $sec  = "0$sec"; }

    # 요일을 문자로
    $day = ("Sunday", "Monday", "Tuesday", "Wednesday",
            "Thursday", "Friday", "Saturday")[$day];

    # 월을 문자로
    $mon = ("Jan", "Feb", "Mar", "Apr", "May", "Jun",
            "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")[$mon];

    # 경로와 기한 세트
    $info = "; expires=$day, $date\-$mon\-$year $hour:$min:$sec GMT\n";
    $cookie = '';
    
    if(($HcurrentID) && ($HmainMode eq 'owner')){
        $cookie .= "Set-Cookie: ${HthisFile}OWNISLANDID=($HcurrentID) $info";
    }
    if($HinputPassword) {
        $cookie .= "Set-Cookie: ${HthisFile}OWNISLANDPASSWORD=($HinputPassword) $info";
    }
    if($HlbbsName) {
        $cookie .= "Set-Cookie: ${HthisFile}LBBSNAME=($HlbbsName) $info";
    }
    if($HcommandX) {
        $cookie .= "Set-Cookie: ${HthisFile}POINTX=($HcommandX) $info";
    }
    if($HcommandY) {
        $cookie .= "Set-Cookie: ${HthisFile}POINTY=($HcommandY) $info";
    }
    if($HcommandKind) {
        # 자동 계열 이외
        $cookie .= "Set-Cookie: ${HthisFile}KIND=($HcommandKind) $info";
    }
    if($HimgLine) {
        $cookie .= "Set-Cookie: ${HthisFile}IMGLINE=($HimgLine) $info";
    }
    if($HjavaMode) {
        $cookie .= "Set-Cookie: ${HthisFile}JAVAMODE=($HjavaMode) $info";
    }
    out($cookie);
}

#----------------------------------------------------------------------
# 유틸리티
#----------------------------------------------------------------------

sub hakolock {
    # 락 시도
    $lfh = file_lock() or die return 0;
    return 1;
}

# 락 해제
sub unlock {
    # rename 방식 락
    return unless defined($lfh) && defined($lfh->{current}) && defined($lfh->{path});
    rename($lfh->{current}, $lfh->{path});
}

# 새 락 방식
sub file_lock {
    my %lfh = (dir => "./", basename => "lock/lockfile", timeout => $unlockTime, trytime => 3, @_);
    $lfh{path} = $lfh{dir}.$lfh{basename};

    my $lockdir = $lfh{path};
    $lockdir =~ s{/[^/]+$}{};
    my $lockbase = $lfh{path};
    $lockbase =~ s{.*/}{};

    if(!-d $lockdir) {
        mkdir($lockdir, 0777) or return undef;
        chmod 0777, $lockdir;
    }

    # 일반 lockfile이 있으면 먼저 정상 락을 시도한다.
    for (my $i = 0; $i < $lfh{trytime}; $i++, sleep 1) {
        return \%lfh if (rename($lfh{path}, $lfh{current} = $lfh{path} . time));
    }

    # 비정상 종료로 남은 lockfile<timestamp>는 timeout 이후 회수한다.
    if(opendir(LOCKDIR, $lockdir)) {
        my @filelist = readdir(LOCKDIR);
        closedir(LOCKDIR);
        foreach (@filelist) {
            if (/^\Q$lockbase\E(\d+)$/) {
                return \%lfh if (time - $1 > $lfh{timeout} and
                rename($lockdir . '/' . $_, $lfh{current} = $lfh{path} . time));
                return undef;
            }
        }
    }

    # 새 설치/압축 해제 후 lockfile이 없으면 생성 후 다시 락을 건다.
    if(!-e $lfh{path}) {
        if(open(my $init_lock, '>', $lfh{path})) {
            close($init_lock);
            chmod 0666, $lfh{path};
        } else {
            return undef;
        }
    }

    for (my $i = 0; $i < $lfh{trytime}; $i++, sleep 1) {
        return \%lfh if (rename($lfh{path}, $lfh{current} = $lfh{path} . time));
    }
    undef;
}

# 텍스트 인코딩 보정: UTF-8 저장을 기본으로 하되 기존 CP949/EUC-KR/Shift_JIS 데이터도 표시 가능하게 처리
# 이미 한 번 깨진 UTF-8 모지바케(예: í•œê¸€/ì... 형태)도 가능한 범위에서 복구한다.
sub normalizeText {
    my($s) = @_;
    return '' unless defined($s);
    $s =~ s/\r?\n\z//;
    $s =~ s/\r\z//;

    my $decoded;
    if(Encode::is_utf8($s)) {
        $decoded = $s;
    } else {
        foreach my $enc ('UTF-8', 'cp949', 'euc-kr', 'shift_jis') {
            $decoded = eval { Encode::decode($enc, $s, Encode::FB_CROAK); };
            last if defined($decoded);
        }
        $decoded = Encode::decode('UTF-8', $s, Encode::FB_DEFAULT) unless defined($decoded);
    }

    $decoded = repairMojibake($decoded);
    return $decoded;
}

sub repairMojibake {
    my($s) = @_;
    return '' unless defined($s);
    # UTF-8 한글이 CP1252/Latin 계열로 잘못 해석된 뒤 다시 UTF-8로 저장된 흔적만 복구한다.
    if(($s =~ /[ÃÂ]/) || ($s =~ /[ìíëê][\x{0080}-\x{00ff}\x{2018}-\x{201d}\x{2020}-\x{2026}\x{20ac}]/)) {
        my $raw = eval { Encode::encode('cp1252', $s, Encode::FB_CROAK); };
        if(defined($raw)) {
            my $fixed = eval { Encode::decode('UTF-8', $raw, Encode::FB_CROAK); };
            if(defined($fixed) && ($fixed =~ /[가-힣]/)) {
                return $fixed;
            }
        }
        # 일부 서버에서는 Latin-1로 깨진 문자열이 저장된다.
        $raw = eval { Encode::encode('latin1', $s, Encode::FB_CROAK); };
        if(defined($raw)) {
            my $fixed = eval { Encode::decode('UTF-8', $raw, Encode::FB_CROAK); };
            if(defined($fixed) && ($fixed =~ /[가-힣]/)) {
                return $fixed;
            }
        }
    }
    return $s;
}


# 작은 값을 반환
sub min {
    return ($_[0] < $_[1]) ? $_[0] : $_[1];
}

# 비밀번호 인코딩
sub encode {
    if($cryptOn == 1) {
        return crypt($_[0], 'h2');
    } else {
        return $_[0];
    }
}

# 비밀번호 체크
sub checkPassword {
    my($p1, $p2) = @_;

    # null 체크
    if($p2 eq '') {
        return 0;
    }

    # 마스터 비밀번호 체크
    if($masterPassword eq $p2) {
        return 1;
    }

    # 본래 체크
    if($p1 eq encode($p2)) {
        return 1;
    }

    return 0;
}

# 1000억 단위 반올림 루틴
sub aboutMoney {
    my($m) = @_;
    if($m < 500) {
        return "추정 500${HunitMoney} 미만";
    } else {
        $m = int(($m + 500) / 1000);
        return "추정 ${m}000${HunitMoney}";
    }
}

# 이스케이프 문자 처리
sub htmlEscape {
    my($s) = @_;
    $s =~ s/&/&amp;/g;
    $s =~ s/</&lt;/g;
    $s =~ s/>/&gt;/g;
    $s =~ s/\"/&quot;/g; #"
    $s =~ s/'/&#39;/g;
    $s =~ s/ /&#32;/g;
    return $s;
}

# 지정한 길이로 잘라 맞춤
sub cutColumn {
    my($s, $c) = @_;
    if(length($s) <= $c) {
        return $s;
    } else {
        # 지정한 길이가 될 시까지 잘라냄
        my($ss) = '';
        my($count) = 0;
        while($count < $c) {
            $s =~ s/(^[\x80-\xFF][\x80-\xFF])|(^[\x00-\x7F])//;
            if($1) {
                $ss .= $1;
                $count ++;
            } else {
                $ss .= $2;
            }
            $count ++;
        }
        return $ss;
    }
}

# 섬 이름에서 번호를 얻음 ID가 아니라 번호
sub nameToNumber {
    my($name) = @_;

    # 전체 섬에서 찾기
    my($i);
    for($i = 0; $i < $HislandNumber; $i++) {
        if($Hislands[$i]->{'name'} eq $name) {
            return $i;
        }
    }

    # 찾지 못한 경우
    return -1;
}

# 괴수 정보
sub monsterSpec {
    my($lv,$island) = @_;

    # 종류
    my($kind) = int($lv / 10);

    # 이름
    my($name);
    $name = $HmonsterName[$kind];

    # 체력
    my($hp) = $lv - ($kind * 10);

    if($kind >= 4 and $island) {
        $kind = $island->{'i_type'};
        $hp = $island->{'i_hp'};
        $name = $island->{'i_name'};
    }

    return ($kind, $name, $hp);
}

# 경험치에서 레벨 산출
sub expToLevel {
    my($kind, $exp) = @_;
    my($i);
    if($kind == $HlandBase) {
        # 미사일 기지
        for($i = $maxBaseLevel; $i > 1; $i--) {
            if($exp >= $baseLevelUp[$i - 2]) {
                return $i;
            }
        }
        return 1;
    } else {
        # 해저 기지
        for($i = $maxSBaseLevel; $i > 1; $i--) {
            if($exp >= $sBaseLevelUp[$i - 2]) {
                return $i;
            }
        }
        return 1;
    }

}

# (0,0)부터 (size - 1, size - 1)까지의 숫자가 한 번씩 나오도록
# (@Hrpx, @Hrpy)를 설정
sub makeRandomPointArray {
    # 초기값
    my($y);
    @Hrpx = (0..$HislandSize-1) x $HislandSize;
    for($y = 0; $y < $HislandSize; $y++) {
        push(@Hrpy, ($y) x $HislandSize);
    }

    # 셔플
    my ($i);
    for ($i = $HpointNumber; --$i; ) {
        my($j) = int(rand($i+1)); 
        if($i == $j) { next; }
        @Hrpx[$i,$j] = @Hrpx[$j,$i];
        @Hrpy[$i,$j] = @Hrpy[$j,$i];
    }
}

# 0부터 n - 1까지의 난수
sub random {
    return int(rand(1) * $_[0]);
}

#----------------------------------------------------------------------
# 로그 표시
#----------------------------------------------------------------------

# 파일 번호 지정으로 로그 표시
sub logFilePrint {
    my($fileNumber, $id, $mode, $kankou) = @_;
    open(LIN, "<:raw", "${HdirName}/hakojima.log$_[0]");
    my($line, $m, $turn, $id1, $id2, $message);
    my($fi) = 0;

    while($line = <LIN>) {
        $line =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),(.*)$/;
        ($m, $turn, $id1, $id2, $message) = ($1, $2, $3, $4, normalizeText($5));

        # 기밀 관계
        if($m == 1) {
            if(($mode == 0) || ($id1 != $id)) {
                # 기밀 표시 권한 없음
                next;
            }
            $m = '<B>(기밀)</B>';
        } else {
            $m = '';
        }

        # 표시 대상인지 확인
        if($id != 0) {
            if(($id != $id1) &&
               ($id != $id2)) {
                next;
            }
        }

        # 표시
        if($kankou == 1) {

        out("<NOBR>${HtagNumber_}턴 $turn$m${H_tagNumber}：$message</NOBR><BR>\n");

    } elsif(($fi == 0) && ($mode == 0)) {
     out("<NOBR><BR><B><I><FONT COLOR='#000000' SIZE=+2>턴 $turn$m：</FONT></I></B><BR><HR width=50% align=center>\n");
        out("<NOBR>${HtagNumber_}턴 $turn$m${H_tagNumber}：$message</NOBR><BR>\n");
          $fi++;
        } else {
        out("<NOBR>${HtagNumber_}턴 $turn$m${H_tagNumber}：$message</NOBR><BR>\n");
        }
    }

    close(LIN);
}

#----------------------------------------------------------------------
# 템플릿
#----------------------------------------------------------------------

# 초기화
sub tempInitialize {
    # 섬 선택 기본값은 자기 섬
    $HislandList = getIslandList($defaultID);
    $HtargetList = getIslandList($defaultID);
}

# 섬 데이터 풀다운 메뉴용
sub getIslandList {
    my($select) = @_;
    my($list, $name, $id, $s, $i);

    # 섬 목록 메뉴
    $list = '';
    for($i = 0; $i < $HislandNumber; $i++) {
        $name = $Hislands[$i]->{'name'};
        $id = $Hislands[$i]->{'id'};
        if($id eq $select) {
            $s = 'SELECTED';
        } else {
            $s = '';
        }
        $list .=
            "<OPTION VALUE=\"$id\" $s>${name}섬\n";
    }
    return $list;
}

# 락 실패
sub tempLockFail {
    # 제목
    out(<<END);
${HtagBig_}동시 접속 오류입니다.<BR>
브라우저의 「뒤로」 버튼을 누르고,<BR>
잠시 기다린 뒤 다시 시도해 주세요.${H_tagBig}$HtempBack
END
}

# 강제 해제
sub tempUnlock {
    # 제목
    out(<<END);
${HtagBig_}이전 접속이 비정상 종료된 것 같습니다.<BR>
락을 강제로 해제했습니다.${H_tagBig}$HtempBack
END
}

# hakojima.dat가 없음
sub tempNoDataFile {
    out(<<END);
${HtagBig_}데이터 파일을 열 수 없습니다.${H_tagBig}$HtempBack
END
}

# 비밀번호 틀림
sub tempWrongPassword {
    out(<<END);
${HtagBig_}비밀번호가 틀립니다.${H_tagBig}$HtempBack
END
}

# 뭔가 문제 발생
sub tempProblem {
    out(<<END);
${HtagBig_}문제가 발생했습니다. 일단 돌아가 주세요.${H_tagBig}$HtempBack
END
}

# 시간 취득
sub get_time {
    my $time_;
    my $TZ_JST=3600*9;
    my($sec,$min,$hour,$mday,$mon,$year)=gmtime($_[0]+$TZ_JST);
    my $now=time();
    my($nsec,$nmin,$nhour,$nmday,$nmon,$nyear)=gmtime($now+$TZ_JST);

    if($_[0]<$now-12*3600 && ($nyear!=$year || $nmon!=$mon || $nmday!=$mday)) {
        $mon = ($mon < 9) ? "0".($mon+1) : $mon + 1;
        $mday = ($mday < 10) ? "0".$mday : $mday;
        $time_ = "(".$mon."/".$mday.")";
    } else {
        $hour = ($hour < 10) ? "0".$hour : $hour;
        $min = ($min < 10) ? "0".$min : $min;
        $time_ = "(<B>$hour:$min</B>)";
    }

    return $time_;
}
