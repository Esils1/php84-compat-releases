use utf8;
#----------------------------------------------------------------------
# 모형정원 제도 ver2.30
# 턴 진행 모듈
# 사용 조건, 사용 방법 등은 hako-readme.txt 파일을 참조
#
# 모형정원 제도 페이지: http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html
#----------------------------------------------------------------------
# 이노라 제도
#----------------------------------------------------------------------

#주변 2헥스의 좌표
my(@ax) = (0, 1, 1, 1, 0,-1, 0, 1, 2, 2, 2, 1, 0,-1,-1,-2,-1,-1, 0);
my(@ay) = (0,-1, 0, 1, 1, 0,-1,-2,-1, 0, 1, 2, 2, 2, 1, 0,-1,-2,-2);

#----------------------------------------------------------------------
# 섬 신규 생성 모드
#----------------------------------------------------------------------
# 메인
sub newIslandMain {
	# 섬 수가 가득 차지 않았는지 확인
	if($HislandNumber >= $HmaxIsland) {
		unlock();
		tempNewIslandFull();
		return;
	}

	# 이름이 있는지 확인
	if($HcurrentName eq '') {
		unlock();
		tempNewIslandNoName("섬");
		return;
	}

	# 이름이 올바른지 확인
	if($HcurrentName =~ /[,\?\(\)\<\>\$]|^무인$/) {
		# 사용할 수 없는 이름
		unlock();
		tempNewIslandBadName();
		return;
	}

	# 이름 중복 확인
	if(nameToNumber($HcurrentName) != -1) {
		# 이미 발견됨
		unlock();
		tempNewIslandAlready();
		return;
	}

	# password 존재 여부 판정
	if($HinputPassword eq '') {
		# password 없음
		unlock();
		tempNewIslandNoPassword();
		return;
	}

	# 확인용 패스워드
	if($HinputPassword2 ne $HinputPassword) {
		# password 틀림
		unlock();
		tempWrongPassword();
		return;
	}

	if($Hi_name eq '') {
		# 이노라의 이름
		unlock();
		tempNewIslandNoName("이노라");
		return;
	}

	# 새 섬 번호 결정
	$HcurrentNumber = $HislandNumber;
	$HislandNumber++;
	$Hislands[$HcurrentNumber] = makeNewIsland();
	my($island) = $Hislands[$HcurrentNumber];

	# 각종 값 설정
	$island->{'name'} = $HcurrentName;
	$island->{'id'} = $HislandNextID;
	$HislandNextID ++;
	$island->{'absent'} = $HgiveupTurn - 3;
	$island->{'comment'} = '(미등록)';
	$island->{'password'} = encode($HinputPassword);
	
	# 인구 및 기타 산출
	estimate($HcurrentNumber);

	# 데이터 쓰기
	writeIslandsFile($island->{'id'});
	logDiscover($HcurrentName); # 로그

	# 해제
	unlock();

	# 발견 화면
	tempNewIslandHead($HcurrentName); # 발견했습니다!!
	islandInfo(); # 섬 정보
	islandMap(1); # 섬 지도, owner 모드
}

# 새 섬을 생성한다
sub makeNewIsland {
	# 지형을 만든다
	my($land, $landValue) = makeNewLand();

	# 초기 명령 생성
	my(@command, $i);
	for($i = 0; $i < $HcommandMax; $i++) {
		 $command[$i] = {
			 'kind' => $HcomDoNothing,
			 'target' => 0,
			 'x' => 0,
			 'y' => 0,
			 'arg' => 0
		 };
	}

	# 초기 게시판 생성
	my(@lbbs);
	for($i = 0; $i < $HlbbsMax; $i++) {
		 $lbbs[$i] = "0>>";
	}

	my $sleep = random(15) + 115;
	# 섬으로 만들어 반환
	return {
		'land' => $land,
		'landValue' => $landValue,
		'command' => \@command,
		'lbbs' => \@lbbs,
		'money' => $HinitialMoney,
		'food' => $HinitialFood,
		'prize' => '0,0,',
		'ownername' => '0',
		'i_name' => $Hi_name,
		'i_cont' => '0,0,',
		'i_gene' => '1',
		'i_age'  => $HislandTurn,
		'i_type' => 4,
		'i_ang'  => 2000,
		'i_heal' => 2000,
		'i_hp'   => 1000,
		'i_cute' => 1000,
		'i_arm'  => 1000,
		'i_int'  => 1000,
		'i_sleep' => $sleep
	};
}

# 새 섬의 지형을 생성한다
sub makeNewLand {
	# 기본 형태 생성
	my(@land, @landValue, $x, $y, $i);

	# 바다로 초기화
	for($y = 0; $y < $HislandSize; $y++) {
		 for($x = 0; $x < $HislandSize; $x++) {
			 $land[$x][$y] = $HlandSea;
			 $landValue[$x][$y] = 0;
		 }
	}

	# 중앙 4*4에 황무지를 배치
	my($center) = int($HislandSize / 2 - 1);
	for($y = $center - 1; $y < $center + 3; $y++) {
		 for($x = $center - 1; $x < $center + 3; $x++) {
			 $land[$x][$y] = $HlandWaste;
		 }
	}

	# 8*8 범위 안에 육지를 확장
	for($i = 0; $i < 120; $i++) {
		 # 무작위 좌표
		 $x = random(8) + $center - 3;
		 $y = random(8) + $center - 3;

		 my($tmp) = countAround(\@land, $x, $y, $HlandSea, 7);
		 if(countAround(\@land, $x, $y, $HlandSea, 7) != 7){
			 # 주변에 육지가 있는 경우 얕은 바다로 만든다
			 # 얕은 바다는 황무지로 만든다
			 # 황무지는 평지로 만든다
			 if($land[$x][$y] == $HlandWaste) {
				 $land[$x][$y] = $HlandPlains;
				 $landValue[$x][$y] = 0;
			 } else {
				 if($landValue[$x][$y] == 1) {
					 $land[$x][$y] = $HlandWaste;
					 $landValue[$x][$y] = 0;
				 } else {
					 $landValue[$x][$y] = 1;
				 }
			 }
		 }
	}

	# 숲을 만든다
	my($count) = 0;
	while($count < 4) {
		 # 무작위 좌표
		 $x = random(4) + $center - 1;
		 $y = random(4) + $center - 1;

		 # 그곳이 이미 숲이 아니면 숲을 만든다
		 if($land[$x][$y] != $HlandForest) {
			 $land[$x][$y] = $HlandForest;
			 $landValue[$x][$y] = 5; # 처음에는 500그루
			 $count++;
		 }
	}

	# 마을을 만든다
	$count = 0;
	while($count < 2) {
		 # 무작위 좌표
		 $x = random(4) + $center - 1;
		 $y = random(4) + $center - 1;

		 # 그곳이 숲이나 마을이 아니면 마을을 만든다
		 if(($land[$x][$y] != $HlandTown) &&
			($land[$x][$y] != $HlandForest)) {
			 $land[$x][$y] = $HlandTown;
			 $landValue[$x][$y] = 5; # 처음에는 500명
			 $count++;
		 }
	}

	# 산을 만든다
	$count = 0;
	while($count < 1) {
		 # 무작위 좌표
		 $x = random(4) + $center - 1;
		 $y = random(4) + $center - 1;

		 # 그곳이 숲이나 마을이 아니면 마을을 만든다
		 if(($land[$x][$y] != $HlandTown) &&
			($land[$x][$y] != $HlandForest)) {
			 $land[$x][$y] = $HlandMountain;
			 $landValue[$x][$y] = 0; # 처음에는 채굴장 없음
			 $count++;
		 }
	}

	# 기지를 만든다
	$count = 0;
	while($count < 1) {
		 # 무작위 좌표
		 $x = random(4) + $center - 1;
		 $y = random(4) + $center - 1;

		 # 그곳이 숲/마을/산이 아니면 기지
		 if(($land[$x][$y] != $HlandTown) &&
			($land[$x][$y] != $HlandForest) &&
			($land[$x][$y] != $HlandMountain)) {
			 $land[$x][$y] = $HlandBase;
			 $landValue[$x][$y] = 0;
			 $count++;
		 }
	}

	# 이노라를 배치
	$count = 0;
	while($count < 1) {
		# 무작위 좌표
		$x = random(4) + $center - 1;
		$y = random(4) + $center - 1;

		# 그곳이 숲/마을/산/기지가 아니면 괴수
		if(($land[$x][$y] != $HlandTown) &&
			($land[$x][$y] != $HlandForest) &&
			($land[$x][$y] != $HlandBase) &&
			($land[$x][$y] != $HlandMountain)) {
			 $land[$x][$y] = $HlandMonster;
			 $landValue[$x][$y] = 41;
			 $count++;
		}
	}

	return (\@land, \@landValue);
}

#----------------------------------------------------------------------
# 정보 변경 모드
#----------------------------------------------------------------------
# 메인
sub changeMain {
	# id에서 섬을 가져옴
	$HcurrentNumber = $HidToNumber{$HcurrentID};
	my($island) = $Hislands[$HcurrentNumber];
	my($flag) = 0;

	# 패스워드 확인
	if($HoldPassword eq $HspecialPassword) {
		# 특수 패스워드
		$island->{'money'} = 9999;
		$island->{'food'} = 9999;
	} elsif(!checkPassword($island->{'password'},$HoldPassword)) {
		# password 틀림
		unlock();
		tempWrongPassword();
		return;
	}

	# 확인용 패스워드
	if($HinputPassword2 ne $HinputPassword) {
		# password 틀림
		unlock();
		tempWrongPassword();
		return;
	}

	if($HcurrentName ne '') {
		# 이름 변경인 경우		
		# 이름이 올바른지 확인
		if($HcurrentName =~ /[,\?\(\)\<\>]|^무인$/) {
			# 사용할 수 없는 이름
			unlock();
			tempNewIslandBadName();
			return;
		}

		# 이름 중복 확인
		if(nameToNumber($HcurrentName) != -1) {
			# 이미 발견됨
			unlock();
			tempNewIslandAlready();
			return;
		}

		if($island->{'money'} < $HcostChangeName) {
			# 자금이 부족함
			unlock();
			tempChangeNoMoney();
			return;
		}

		# 대금
		if($HoldPassword ne $HspecialPassword) {
			$island->{'money'} -= $HcostChangeName;
		}

		# 이름 변경
		logChangeName($island->{'name'}, $HcurrentName);
		$island->{'name'} = $HcurrentName;
		$flag = 1;
	}

	# password 변경인 경우
	if($HinputPassword ne '') {
		# 패스워드 변경
		$island->{'password'} = encode($HinputPassword);
		$flag = 1;
	}

	if($HownerName ne '') {
		# 오너 이름 변경
		$island->{'ownername'} = $HownerName;
		$flag = 1;
	}

	if(($flag == 0) && ($HoldPassword ne $HspecialPassword)) {
		# 어느 쪽도 변경되지 않음
		unlock();
		tempChangeNothing();
		return;
	}

	# 데이터 쓰기
	writeIslandsFile($HcurrentID);
	unlock();

	# 변경 성공
	tempChange();
}

#----------------------------------------------------------------------
# 턴 진행 모드
#----------------------------------------------------------------------
# 메인
sub turnMain {
	# 최종 갱신 시간을 갱신
	$HislandLastTime += $HunitTime if($turnMode ne 'debug');

	# 로그 파일을 뒤로 이동
	my($i, $j, $s, $d);
	for($i = ($HlogMax - 1); $i >= 0; $i--) {
		$j = $i + 1;
		my($s) = "${HdirName}/hakojima.log$i";
		my($d) = "${HdirName}/hakojima.log$j";
		unlink($d);
		rename($s, $d);
	}

	# 좌표 배열 생성
	makeRandomPointArray();

	# 턴 번호
	$HislandTurn++;

	# 순서 결정
	my(@order) = randomArray($HislandNumber);

	# 수입, 소비 페이즈
	for($i = 0; $i < $HislandNumber; $i++) {
		estimate($order[$i]);
		income($Hislands[$order[$i]]);

		# 턴 시작 전 인구와 수면 플래그를 기록
		$Hislands[$order[$i]]->{'oldPop'} = $Hislands[$order[$i]]->{'pop'};
		$Hislands[$order[$i]]->{'old_i_sleep'} = $Hislands[$order[$i]]->{'i_sleep'};
	}

	# 명령 처리
	for($i = 0; $i < $HislandNumber; $i++) {
		# 반환값이 1이 될 시까지 반복
		while(doCommand($Hislands[$order[$i]]) == 0){};
	}

	# 성장 및 단일 헥스 재해
	for($i = 0; $i < $HislandNumber; $i++) {
		doEachHex($Hislands[$order[$i]]);
	}

	# 대사 파일 읽기
	require ('speak.cgi');

	# 섬 전체 처리
	my($remainNumber) = $HislandNumber;
	my($island);
	for($i = 0; $i < $HislandNumber; $i++) {
		$island = $Hislands[$order[$i]];
		doIslandProcess($order[$i], $island); 

		# 소멸 판정
		if($island->{'dead'} == 1) {
			$island->{'pop'} = 0;
			$remainNumber--;
		} elsif($island->{'pop'} == 0) {
			$island->{'dead'} = 1;
			$remainNumber--;
			# 소멸 메시지
			my($tmpid) = $island->{'id'};
			logDead($tmpid, $island->{'name'});
			unlink("island.$tmpid");
		}
	}

	# 인구순으로 정렬
	islandSort();

	# 턴 컵 대상 턴이면 해당 처리
	if(($HislandTurn % $HturnPrizeUnit) == 0) {
		# 턴 컵
		my($island) = $Hislands[0];
		logPrize($island->{'id'}, $island->{'name'}, "$HislandTurn${Hprize[0]}");
		$island->{'prize'} .= "${HislandTurn},";

		# 체력 자랑
		inora_sort("i_arm");
		$island = $Hislands[0];
		logContest($island->{'id'}, $island->{'name'}, $Hprize[10], $island->{'i_name'});
		my($arm, $cute, $int) = split(",",$island->{'i_cont'});
		$arm++;
		$island->{'i_cont'} = "$arm,$cute,$int";

		# 콘테스트
		inora_sort("i_cute");
		$island = $Hislands[0];
		logContest($island->{'id'}, $island->{'name'}, $Hprize[11], $island->{'i_name'});
		my($arm, $cute, $int) = split(",",$island->{'i_cont'});
		$cute++;
		$island->{'i_cont'} = "$arm,$cute,$int";

		# 퀴즈 대회
		inora_sort("i_int");
		$island = $Hislands[0];
		logContest($island->{'id'}, $island->{'name'}, $Hprize[12], $island->{'i_name'});
		my($arm, $cute, $int) = split(",",$island->{'i_cont'});
		$int++;
		$island->{'i_cont'} = "$arm,$cute,$int";

		# 인구순으로 다시 정렬
		islandSort();
	}

	# 섬 수 조정
	$HislandNumber = $remainNumber;

	# 백업 턴이면 쓰기 전에 rename
	if(($HislandTurn % $HbackupTurn) == 0) {
		my($i);
		my($tmp) = $HbackupTimes - 1;
		myrmtree("${HdirName}.bak$tmp");
		for($i = ($HbackupTimes - 1); $i > 0; $i--) {
			my($j) = $i - 1;
			rename("${HdirName}.bak$j", "${HdirName}.bak$i");
		}
		rename("${HdirName}", "${HdirName}.bak0");
		mkdir("${HdirName}", $HdirMode);

		# 로그 파일만 되돌림
		for($i = 0; $i <= $HlogMax; $i++) {
			rename("${HdirName}.bak0/hakojima.log$i",
				   "${HdirName}/hakojima.log$i");
		}
		rename("${HdirName}.bak0/hakojima.his",
			   "${HdirName}/hakojima.his");
	}

	# 파일에 쓰기
	writeIslandsFile(-1);

	# 로그 쓰기
	logFlush();

	# 기록 로그 조정
	logHistoryTrim();

	# 상단으로
	topPageMain();
}

# 디렉터리 삭제
sub myrmtree {
	my($dn) = @_;
	opendir(DIN, "$dn/");
	my($fileName);
	while($fileName = readdir(DIN)) {
		unlink("$dn/$fileName");
	} 
	closedir(DIN);
	rmdir($dn);
}

# 수입, 소비 페이즈
sub income {
	my($island) = @_;
	my($pop, $farm, $factory, $mountain) = 
		(	  
		 $island->{'pop'},
		 $island->{'farm'} * 10,
		 $island->{'factory'},
		 $island->{'mountain'}
		 );

	# 수입
	if($pop > $farm) {
		# 농업만으로는 인력이 남는 경우
		$island->{'food'} += $farm; # 농장 완전 가동
		$island->{'money'} +=
			min(int(($pop - $farm) / 10),
				 $factory + $mountain);
	} else {
		# 농업만으로도 벅찬 경우
		$island->{'food'} += $pop; # 전원 농사일
	}

	# 식량 소비
	$island->{'food'} = int(($island->{'food'}) - ($pop * $HeatenFood));
}


# 명령 페이즈
sub doCommand {
	my($island) = @_;

	# 명령 꺼내기
	my($comArray, $command);
	$comArray = $island->{'command'};
	$command = $comArray->[0]; # 첫 번째 것을 꺼냄
	slideFront($comArray, 0); # 이후 항목을 앞으로 당김

	# 각 요소 꺼내기
	my($kind, $target, $x, $y, $arg) = 
		(
		 $command->{'kind'},
		 $command->{'target'},
		 $command->{'x'},
		 $command->{'y'},
		 $command->{'arg'}
		 );

	# 도출값
	my($name) = $island->{'name'};
	my($id) = $island->{'id'};
	my($land) = $island->{'land'};
	my($landValue) = $island->{'landValue'};
	my($landKind) = $land->[$x][$y];
	my($lv) = $landValue->[$x][$y];
	my($cost) = $HcomCost[$kind];
	my($comName) = $HcomName[$kind];
	my($point) = "($x, $y)";
	my($landName) = landName($landKind, $lv);

	if($kind == $HcomDoNothing) {
		# 자금 조달
		logDoNothing($id, $name, $comName);
		$island->{'money'} += 10;
		$island->{'absent'} ++;
		
		# 자동 포기
		if($island->{'absent'} >= $HgiveupTurn) {
			$comArray->[0] = {
				'kind' => $HcomGiveup,
				'target' => 0,
				'x' => 0,
				'y' => 0,
				'arg' => 0
			}
		}
		return 1;
	}

	$island->{'absent'} = 0;

	# 비용 확인
	if($cost > 0) {
		# 자금인 경우
		if($island->{'money'} < $cost) {
			logNoMoney($id, $name, $comName);
			return 0;
		}
	} elsif($cost < 0) {
		# 식량인 경우
		if($island->{'food'} < (-$cost)) {
			logNoFood($id, $name, $comName);
			return 0;
		}
	}

	# 명령에 따라 분기
	if(($kind == $HcomPrepare) ||
	   ($kind == $HcomPrepare2)) {
		# 개간, 땅고르기
		if(($landKind == $HlandSea) || 
		   ($landKind == $HlandSbase) ||
		   ($landKind == $HlandOil) ||
		   ($landKind == $HlandMountain) ||
		   ($landKind == $HlandMonster)) {
			# 바다, 해저기지, 유전, 산, 괴수는 개간할 수 없음
			logLandFail($id, $name, $comName, $landName, $point);
			return 0;
		}

		# 목표 위치를 평지로 만든다
		$land->[$x][$y] = $HlandPlains;
		$landValue->[$x][$y] = 0;
		logLandSuc($id, $name, '개간', $point);

		# 자금을 차감
		$island->{'money'} -= $cost;

		if($kind == $HcomPrepare2) {
			# 땅고르기
			$island->{'prepare2'}++;
			
			# 턴을 소비하지 않음
			return 0;
		} else {
			# 개간라면 매장금 가능성 있음
			if(random(1000) < $HdisMaizo) {
				my($v) = 100 + random(901);
				$island->{'money'} += $v;
				logMaizo($id, $name, $comName, $v);
			}
			return 1;
		}
	} elsif($kind == $HcomReclaim or $kind == $HcomFastRec) {
		# 매립
		if(($landKind != $HlandSea) &&
		   ($landKind != $HlandOil) &&
		   ($landKind != $HlandSbase)) {
			# 바다, 해저기지, 유전만 매립할 수 있음
			logLandFail($id, $name, $comName, $landName, $point);
			return 0;
		}

		# 주변에 육지가 있는지 확인
		my($seaCount) =
			countAround($land, $x, $y, $HlandSea, 7) +
			countAround($land, $x, $y, $HlandOil, 7) +
			countAround($land, $x, $y, $HlandSbase, 7);

		if($seaCount == 7) {
			# 전부 바다라 매립 불가
			logNoLandAround($id, $name, $comName, $point);
			return 0;
		}

		if(($landKind == $HlandSea) && ($lv == 1)) {
			# 얕은 바다인 경우
			# 목표 위치를 황무지로 만든다
			$land->[$x][$y] = $HlandWaste;
			$landValue->[$x][$y] = 0;
			logLandSuc($id, $name, $comName, $point);
			$island->{'area'}++;

			if($seaCount <= 4) {
				# 주변 바다가 3헥스 이내라 얕은 바다로 만든다
				my($i, $sx, $sy);

				for($i = 1; $i < 7; $i++) {
					$sx = $x + $ax[$i];
					$sy = $y + $ay[$i];

					# 행에 따른 위치 보정
					if((($sy % 2) == 0) && (($y % 2) == 1)) {
						$sx--;
					}

					if(($sx < 0) || ($sx >= $HislandSize) ||
					   ($sy < 0) || ($sy >= $HislandSize)) {
					} else {
						# 범위 안인 경우
						if($land->[$sx][$sy] == $HlandSea) {
							$landValue->[$sx][$sy] = 1;
						}
					}
				}
			}
		} else {
			# 바다라면 목표 위치를 얕은 바다로 만든다
			$land->[$x][$y] = $HlandSea;
			$landValue->[$x][$y] = 1;
			logLandSuc($id, $name, $comName, $point);
		}
		
		# 자금을 차감
		$island->{'money'} -= $cost;
		return 0 if($kind == $HcomFastRec);
		return 1;
	} elsif($kind == $HcomDestroy or $kind == $HcomFastDes) {
		# 굴착
		if(($landKind == $HlandSbase) ||
		   ($landKind == $HlandOil) ||
		   ($landKind == $HlandMonster)) {
			# 해저기지, 유전, 괴수는 굴착할 수 없음
			logLandFail($id, $name, $comName, $landName, $point);
			return 0;
		}

		if(($landKind == $HlandSea) && ($lv == 0)) {
			# 바다라면 유전 찾기
			# 투자액 결정
			if($arg == 0) { $arg = 1; }
			my($value, $str, $p);
			$value = min($arg * ($cost), $island->{'money'});
			$str = "$value$HunitMoney";
			$p = int($value / $cost);
			$island->{'money'} -= $value;

			# 발견 여부 판정
			if($p > random(100)) {
				# 유전 발견
				logOilFound($id, $name, $point, $comName, $str);
				$land->[$x][$y] = $HlandOil;
				$landValue->[$x][$y] = 0;
			} else {
				# 헛수고로 끝남
				logOilFail($id, $name, $point, $comName, $str);
			}
			return 0 if($kind == $HcomFastDes);
			return 1;
		}

		# 목표 위치를 바다로 만든다. 산이면 황무지로, 얕은 바다면 바다로.
		if($landKind == $HlandMountain) {
			$land->[$x][$y] = $HlandWaste;
			$landValue->[$x][$y] = 0;
		} elsif($landKind == $HlandSea) {
			$landValue->[$x][$y] = 0;
		} else {
			$land->[$x][$y] = $HlandSea;
			$landValue->[$x][$y] = 1;
			$island->{'area'}--;
		}
		logLandSuc($id, $name, $comName, $point);

		# 자금을 차감
		$island->{'money'} -= $cost;
		return 0 if($kind == $HcomFastDes);
		return 1;
	} elsif($kind == $HcomSellTree) {
		# 벌채
		if($landKind != $HlandForest) {
			# 숲 이외는 벌채할 수 없음
			logLandFail($id, $name, $comName, $landName, $point);
			return 0;
		}

		# 목표 위치를 평지로 만든다
		$land->[$x][$y] = $HlandPlains;
		$landValue->[$x][$y] = 0;
		logLandSuc($id, $name, $comName, $point);

		# 매각금을 얻음
		$island->{'money'} += $HtreeValue * $lv;
		return 1;
	} elsif(($kind == $HcomPlant) ||
			($kind == $HcomFarm) ||
			($kind == $HcomFactory) ||
			($kind == $HcomBase) ||
			($kind == $HcomMonument) ||
			($kind == $HcomHaribote) ||
			($kind == $HcomFastPlant) || 
			($kind == $HcomFastFarm) || 
			($kind == $HcomFastFact) || 
			($kind == $HcomFastBase) || 
			($kind == $HcomFastDbase) || 
			($kind == $HcomDbase)) {

		# 지상 건설 계열
		if(!
		   (($landKind == $HlandPlains) ||
			($landKind == $HlandTown) ||
			(($landKind == $HlandFarm) && ($kind == $HcomFarm)) ||
			(($landKind == $HlandFactory) && ($kind == $HcomFactory)))) {
			# 부적합한 지형
			logLandFail($id, $name, $comName, $landName, $point);
			return 0;
		}

		# 종류에 따라 분기
		if($kind == $HcomPlant or $kind == $HcomFastPlant) {
			# 목표 위치를 숲으로 만든다.
			$land->[$x][$y] = $HlandForest;
			$landValue->[$x][$y] = 1; # 나무는 최소 단위
			logPBSuc($id, $name, $comName, $point);
		} elsif($kind == $HcomBase or $kind == $HcomFastBase) {
			# 목표 위치를 미사일 기지로 만든다.
			$land->[$x][$y] = $HlandBase;
			$landValue->[$x][$y] = 0; # 경험치 0
			logLandSuc($id, $name, $comName, $point);
		} elsif($kind == $HcomHaribote) {
			# 목표 위치를 허수아비로 만든다
			$land->[$x][$y] = $HlandHaribote;
			$landValue->[$x][$y] = 0;
			logHariSuc($id, $name, $comName, $HcomName[$HcomDbase], $point);
		} elsif($kind == $HcomFarm or $kind == $HcomFastFarm) {
			# 농장
			if($landKind == $HlandFarm) {
				# 이미 농장인 경우
				$landValue->[$x][$y] += 5; # 규모 + 5000명
				if($landValue->[$x][$y] > 250) {
					$landValue->[$x][$y] = 250; # 최대 250000명
				}
			} else {
				# 목표 위치를 농장으로
				$land->[$x][$y] = $HlandFarm;
				$landValue->[$x][$y] = 20; # 규모 = 20000명
			}
			logLandSuc($id, $name, $comName, $point);
		} elsif($kind == $HcomFactory or $kind == $HcomFastFact) {
			# 공장
			if($landKind == $HlandFactory) {
				# 이미 공장인 경우
				$landValue->[$x][$y] += 10; # 규모 + 10000명
				if($landValue->[$x][$y] > 100) {
					$landValue->[$x][$y] = 100; # 최대 100000명
				}
			} else {
				# 목표 위치를 공장으로
				$land->[$x][$y] = $HlandFactory;
				$landValue->[$x][$y] = 30; # 규모 = 10000명
			}
			logLandSuc($id, $name, $comName, $point);
		} elsif($kind == $HcomDbase or $kind == $HcomFastDbase) {
			# 방위시설
			# 목표 위치를 방위시설로
			$land->[$x][$y] = $HlandDefence;
			$landValue->[$x][$y] = 0;
			logLandSuc($id, $name, $comName, $point);
		} elsif($kind == $HcomMonument) {
			# 기념비
			# 목표 위치를 기념비로
			$land->[$x][$y] = $HlandMonument;
			if($arg >= $HmonumentNumber) {
				$arg = 0;
			}
			$landValue->[$x][$y] = $arg;
			logLandSuc($id, $name, $comName, $point);
		}

		# 자금을 차감
		$island->{'money'} -= $cost;

		# 횟수가 지정되어 있으면 명령을 되돌림
		if(($kind == $HcomFarm) ||
		   ($kind == $HcomFactory)) {
			if($arg > 1) {
				my($command);
				$arg--;
				slideBack($comArray, 0);
				$comArray->[0] = {
					'kind' => $kind,
					'target' => $target,
					'x' => $x,
					'y' => $y,
					'arg' => $arg
					};
			}
		}
		return 0 if($kind == $HcomFastPlant or$kind == $HcomFastFarm or 
					$kind == $HcomFastFarm or $kind == $HcomFastFact or 
					$kind == $HcomFastFact or $kind == $HcomFastBase or 
					$kind == $HcomFastBase or $kind == $HcomFastDbase);
		return 1;
	} elsif($kind == $HcomMountain) {
		# 채굴장
		if($landKind != $HlandMountain) {
			# 산 이외에는 만들 수 없음
			logLandFail($id, $name, $comName, $landName, $point);
			return 0;
		}

		$landValue->[$x][$y] += 5; # 규모 + 5000명
		if($landValue->[$x][$y] > 200) {
			$landValue->[$x][$y] = 200; # 최대 200000명
		}
		logLandSuc($id, $name, $comName, $point);

		# 자금을 차감
		$island->{'money'} -= $cost;
		if($arg > 1) {
			my($command);
			$arg--;
			slideBack($comArray, 0);
			$comArray->[0] = {
				'kind' => $kind,
				'target' => $target,
				'x' => $x,
				'y' => $y,
				'arg' => $arg
				};
		}
		return 1;
	} elsif($kind == $HcomSbase) {
		# 해저기지
		if(($landKind != $HlandSea) || ($lv != 0)){
			# 바다 이외에는 만들 수 없음
			logLandFail($id, $name, $comName, $landName, $point);
			return 0;
		}

		$land->[$x][$y] = $HlandSbase;
		$landValue->[$x][$y] = 0; # 경험치 0
		logLandSuc($id, $name, $comName, '(?, ?)');

		# 자금을 차감
		$island->{'money'} -= $cost;
		return 1;
	} elsif(($kind == $HcomMissileNM) ||
			($kind == $HcomMissilePP)) {
		# 미사일 계열
		# 타깃 가져오기
		my($tn) = $HidToNumber{$target};
		if($tn eq '') {
			# 타깃이 이미 없음
			logMsNoTarget($id, $name, $comName);
			return 0;
		}

		my($flag) = 0;
		if($arg == 0) {
			# 0인 경우 쏠 수 있는 만큼
			$arg = 10000;
		}

		# 사전 준비
		my($tIsland) = $Hislands[$tn];
		my($tName) = $tIsland->{'name'};
		my($tLand) = $tIsland->{'land'};
		my($tLandValue) = $tIsland->{'landValue'};
		my($tx, $ty, $err);

		# 난민 수
		my($boat) = 0;

		# 오차
		if($kind == $HcomMissilePP) {
			$err = 7;
		} else {
			$err = 19;
		}

		# 자금이 바닥나거나 지정 수에 도달하거나 모든 기지가 발사할 시까지 루프
		my($bx, $by, $count) = (0,0,0);
		while(($arg > 0) &&
			  ($island->{'money'} >= $cost)) {
			# 기지를 찾을 시까지 루프
			while($count < $HpointNumber) {
				$bx = $Hrpx[$count];
				$by = $Hrpy[$count];
				if(($land->[$bx][$by] == $HlandBase) ||
				   ($land->[$bx][$by] == $HlandSbase)) {
					last;
				}
				$count++;
			}
			if($count >= $HpointNumber) {
				# 찾지 못하면 거기까지
				last;
			}
			# 최소 하나의 기지가 있었으므로 flag를 세움
			$flag = 1;		   

			# 기지 레벨 산출
			my($level) = expToLevel($land->[$bx][$by], $landValue->[$bx][$by]);
			# 기지 내부 루프
			while(($level > 0) &&
				  ($arg > 0) &&
				  ($island->{'money'} > $cost)) {
				# 발사가 확정되었으므로 각 값을 소모
				$level--;
				$arg--;
				$island->{'money'} -= $cost;

				# 착탄점 산출
				my($r) = random($err);
				$tx = $x + $ax[$r];
				$ty = $y + $ay[$r];
				if((($ty % 2) == 0) && (($y % 2) == 1)) {
					$tx--;
				}

				# 착탄점 범위 안/밖 확인
				if(($tx < 0) || ($tx >= $HislandSize) ||
				   ($ty < 0) || ($ty >= $HislandSize)) {
					# 범위 밖
					if($kind == $HcomMissileST) {
						# 스텔스
						logMsOutS($id, $target, $name, $tName,
								   $comName, $point);
					} else {
						# 일반계
						logMsOut($id, $target, $name, $tName,
								  $comName, $point);
					}
					next;
				}

				# 착탄점의 지형 등 산출
				my($tL) = $tLand->[$tx][$ty];
				my($tLv) = $tLandValue->[$tx][$ty];
				my($tLname) = landName($tL, $tLv);
				my($tPoint) = "($tx, $ty)";

				# 방위시설 판정
				my($defence) = 0;
				if($HdefenceHex[$id][$tx][$ty] == 1) {
					$defence = 1;
				} elsif($HdefenceHex[$id][$tx][$ty] == -1) {
					$defence = 0;
				} else {
					if($tL == $HlandDefence) {
						# 방위시설에 명중
						# 플래그 클리어
						my($i, $count, $sx, $sy);
						for($i = 0; $i < 19; $i++) {
							$sx = $tx + $ax[$i];
							$sy = $ty + $ay[$i];

							# 행에 따른 위치 보정
							if((($sy % 2) == 0) && (($ty % 2) == 1)) {
								$sx--;
							}

							if(($sx < 0) || ($sx >= $HislandSize) ||
							   ($sy < 0) || ($sy >= $HislandSize)) {
								# 범위 밖인 경우 아무것도 하지 않음
							} else {
								# 범위 안인 경우
								$HdefenceHex[$id][$sx][$sy] = 0;
							}
						}
					} elsif(countAround($tLand, $tx, $ty, $HlandDefence, 19)) {
						$HdefenceHex[$id][$tx][$ty] = 1;
						$defence = 1;
					} else {
						$HdefenceHex[$id][$tx][$ty] = -1;
						$defence = 0;
					}
				}
				
				if($defence == 1) {
					# 공중 폭파
					if($kind == $HcomMissileST) {
						# 스텔스
						logMsCaughtS($id, $target, $name, $tName,
									  $comName, $point, $tPoint);
					} else {
						# 일반계
						logMsCaught($id, $target, $name, $tName,
									 $comName, $point, $tPoint);
					}
					next;
				}

				# “효과 없음” 헥스를 먼저 판정
				if((($tL == $HlandSea) && ($tLv == 0))|| # 깊은 바다
				   ((($tL == $HlandSea) ||   # 바다 또는...
					 ($tL == $HlandSbase) ||   # 해저기지 또는...
					 ($tL == $HlandMountain)) # 산이고...
					&& ($kind != $HcomMissileLD))) { # 육지파괴탄 이외
					# 해저기지인 경우 바다인 척함
					if($tL == $HlandSbase) {
						$tL = $HlandSea;
					}
					$tLname = landName($tL, $tLv);

					# 무효화
					if($kind == $HcomMissileST) {
						# 스텔스
						logMsNoDamageS($id, $target, $name, $tName,
										$comName, $tLname, $point, $tPoint);
					} else {
						# 일반계
						logMsNoDamage($id, $target, $name, $tName,
									   $comName, $tLname, $point, $tPoint);
					}
					next;
				}

				# 탄 종류에 따라 분기
				if($kind == $HcomMissileLD) {
					# 육지파괴탄
					if($tL == $HlandMountain) {
						# 산(황무지가 됨)
						logMsLDMountain($id, $target, $name, $tName,
										 $comName, $tLname, $point, $tPoint);
						# 황무지가 됨
						$tLand->[$tx][$ty] = $HlandWaste;
						$tLandValue->[$tx][$ty] = 0;
						next;

					} elsif($tL == $HlandSbase) {
						# 해저기지
						logMsLDSbase($id, $target, $name, $tName,
									  $comName, $tLname, $point, $tPoint);
					} elsif($tL == $HlandMonster) {
						# 괴수
						logMsLDMonster($id, $target, $name, $tName,
										$comName, $tLname, $point, $tPoint);
					} elsif($tL == $HlandSea) {
						# 얕은 바다
						logMsLDSea1($id, $target, $name, $tName,
									$comName, $tLname, $point, $tPoint);
					} else {
						# 기타
						logMsLDLand($id, $target, $name, $tName,
									 $comName, $tLname, $point, $tPoint);
					}
					
					# 경험치
					if($tL == $HlandTown) {
						if(($land->[$bx][$by] == $HlandBase) ||
						   ($land->[$bx][$by] == $HlandSbase)) {
							# 아직 기지인 경우에만
							$landValue->[$bx][$by] += int($tLv / 20);
							if($landValue->[$bx][$by] > $HmaxExpPoint) {
								$landValue->[$bx][$by] = $HmaxExpPoint;
							}
						}
					}

					# 얕은 바다가 됨
					$tLand->[$tx][$ty] = $HlandSea;
					$tIsland->{'area'}--;
					$tLandValue->[$tx][$ty] = 1;

					# 단, 유전/얕은 바다/해저기지라면 바다
					if(($tL == $HlandOil) ||
						($tL == $HlandSea) ||
					   ($tL == $HlandSbase)) {
						$tLandValue->[$tx][$ty] = 0;
					}
				} else {
					# 기타 미사일
					if($tL == $HlandWaste) {
						# 황무지(피해 없음)
						if($kind == $HcomMissileST) {
							# 스텔스
							logMsWasteS($id, $target, $name, $tName,
										 $comName, $tLname, $point, $tPoint);
						} else {
							# 일반
							logMsWaste($id, $target, $name, $tName,
										$comName, $tLname, $point, $tPoint);
						}
					} elsif($tL == $HlandMonster) {
						# 괴수
						my($mKind, $mName, $mHp) = monsterSpec($tLv,$tIsland);
						my($special) = $HmonsterSpecial[$mKind];

						# 경화 중?
						if((($special == 3) && (($HislandTurn % 2) == 1)) ||
						   (($special == 4) && (($HislandTurn % 2) == 0))) {
							# 경화 중
							if($kind == $HcomMissileST) {
								# 스텔스
								logMsMonNoDamageS($id, $target, $name, $tName,
											 $comName, $mName, $point,
											 $tPoint);
							} else {
								# 일반탄
								logMsMonNoDamage($id, $target, $name, $tName,
											 $comName, $mName, $point,
											 $tPoint);
							}
							next;
						} else {
							# 경화 중이 아님
							if($mHp == 1 and $mKind < 4) {
								# 괴수를 처치함
								if(($land->[$bx][$by] == $HlandBase) ||
								   ($land->[$bx][$by] == $HlandSbase)) {
									# 경험치
									$landValue->[$bx][$by] += $HmonsterExp[$mKind];
									if($landValue->[$bx][$by] > $HmaxExpPoint) {
										$landValue->[$bx][$by] = $HmaxExpPoint;
									}
								}

								if($kind == $HcomMissileST) {
									# 스텔스
									logMsMonKillS($id, $target, $name, $tName,
												  $comName, $mName, $point,
												  $tPoint);
								} else {
									# 일반
									logMsMonKill($id, $target, $name, $tName,
												 $comName, $mName, $point,
												 $tPoint);
								}

								# 수입
								my($value) = $HmonsterValue[$mKind];
								if($value > 0) {
									$tIsland->{'money'} += $value;
									logMsMonMoney($target, $mName, $value);
								}

								# 수상 관련
								my($prize) = $island->{'prize'};
								$prize =~ /([0-9]*),([0-9]*),(.*)/;
								my($flags) = $1;
								my($monsters) = $2;
								my($turns) = $3;
								my($v) = 2 ** $mKind;
								$monsters |= $v;
								$island->{'prize'} = "$flags,$monsters,$turns";
							} else {
								# 괴수가 살아 있음
								if($kind == $HcomMissileST) {
									# 스텔스
									logMsMonsterS($id, $target, $name, $tName,
												  $comName, $mName, $point,
												  $tPoint);
								} else {
									# 일반
									logMsMonster($id, $target, $name, $tName,
												 $comName, $mName, $point,
												 $tPoint);
								}
								# HP가 감소
								if($mKind >= 4) {
									$island->{'speak'} = 7;
									$island->{'i_sleep'} -= 5 if($island->{'i_sleep'} > 100 and $island->{'i_sleep'} < 200);
									$island->{'i_hp'}   -= 500;
									$island->{'i_ang'}  -= random($INORA[2]);
									$island->{'i_heal'} -= random($INORA[2]);
								} else {
									$tLandValue->[$tx][$ty]--;
								}
								next;
							}

						}
					} else {
						# 일반 지형
						if($kind == $HcomMissileST) {
							# 스텔스
							logMsNormalS($id, $target, $name, $tName,
										   $comName, $tLname, $point,
										   $tPoint);
						} else {
							# 일반
							logMsNormal($id, $target, $name, $tName,
										 $comName, $tLname, $point,
										 $tPoint);
						}
					}
					# 경험치
					if($tL == $HlandTown) {
						if(($land->[$bx][$by] == $HlandBase) ||
							($land->[$bx][$by] == $HlandSbase)) {
							$landValue->[$bx][$by] += int($tLv / 20);
							$boat += $tLv; # 일반 미사일이므로 난민에 추가
							if($landValue->[$bx][$by] > $HmaxExpPoint) {
								$landValue->[$bx][$by] = $HmaxExpPoint;
							}
						}
					}
					
					# 황무지가 됨
					$tLand->[$tx][$ty] = $HlandWaste;
					$tLandValue->[$tx][$ty] = 1; # 착탄점

					# 단, 유전이면 바다
					if($tL == $HlandOil) {
						$tLand->[$tx][$ty] = $HlandSea;
						$tLandValue->[$tx][$ty] = 0;
					}
				} 
			}

			# 카운트를 증가시켜 둠
			$count++;
		}


		if($flag == 0) {
			# 기지가 하나도 없었던 경우
			logMsNoBase($id, $name, $comName);
			return 0;
		}

		# 난민 판정
		$boat = int($boat / 2);
		if(($boat > 0) && ($id != $target) && ($kind != $HcomMissileST)) {
			# 난민 표착
			my($achive); # 도착한 난민
			my($i);
			for($i = 0; ($i < $HpointNumber && $boat > 0); $i++) {
				$bx = $Hrpx[$i];
				$by = $Hrpy[$i];
				if($land->[$bx][$by] == $HlandTown) {
					# 마을인 경우
					my($lv) = $landValue->[$bx][$by];
					if($boat > 50) {
						$lv += 50;
						$boat -= 50;
						$achive += 50;
					} else {
						$lv += $boat;
						$achive += $boat;
						$boat = 0;
					}
					if($lv > 200) {
						$boat += ($lv - 200);
						$achive -= ($lv - 200);
						$lv = 200;
					}
					$landValue->[$bx][$by] = $lv;
				} elsif($land->[$bx][$by] == $HlandPlains) {
					# 평지인 경우
					$land->[$bx][$by] = $HlandTown;
					if($boat > 10) {
						$landValue->[$bx][$by] = 5;
						$boat -= 10;
						$achive += 10;
					} elsif($boat > 5) {
						$landValue->[$bx][$by] = $boat - 5;
						$achive += $boat;
						$boat = 0;
					}
				}
				if($boat <= 0) {
					last;
				}
			}
			if($achive > 0) {
				# 조금이라도 도착한 경우 로그 출력
				logMsBoatPeople($id, $name, $achive);

				# 난민 수가 일정 이상이면 평화상 가능성 있음
				if($achive >= 200) {
					my($prize) = $island->{'prize'};
					$prize =~ /([0-9]*),([0-9]*),(.*)/;
					my($flags) = $1;
					my($monsters) = $2;
					my($turns) = $3;

					if((!($flags & 8)) &&  $achive >= 200){
						$flags |= 8;
						logPrize($id, $name, $Hprize[4]);
					} elsif((!($flags & 16)) &&  $achive > 500){
						$flags |= 16;
						logPrize($id, $name, $Hprize[5]);
					} elsif((!($flags & 32)) &&  $achive > 800){
						$flags |= 32;
						logPrize($id, $name, $Hprize[6]);
					}
					$island->{'prize'} = "$flags,$monsters,$turns";
				}
			}
		}
		return 1;
	} elsif($kind == $HcomSell) {
		# 수출량 결정
		if($arg == 0) { $arg = 1; }
		my($value) = min($arg * (-$cost), $island->{'food'});

		# 수출 로그
		logSell($id, $name, $comName, $value);
		$island->{'food'} -=  $value;
		$island->{'money'} += ($value / 10);
		return 0;
	} elsif(($kind == $HcomFood) ||
			($kind == $HcomMoney)) {
		# 원조 계열
		# 타깃 가져오기
		my($tn) = $HidToNumber{$target};
		my($tIsland) = $Hislands[$tn];
		my($tName) = $tIsland->{'name'};

		# 원조량 결정
		if($arg == 0) { $arg = 1; }
		my($value, $str);
		if($cost < 0) {
			$value = min($arg * (-$cost), $island->{'food'});
			$str = "$value$HunitFood";
		} else {
			$value = min($arg * ($cost), $island->{'money'});
			$str = "$value$HunitMoney";
		}

		# 원조 로그
		logAid($id, $target, $name, $tName, $comName, $str);

		if($cost < 0) {
			$island->{'food'} -= $value;
			$tIsland->{'food'} += $value;
		} else {
			$island->{'money'} -= $value;
			$tIsland->{'money'} += $value;
		}
		return 0;
	} elsif($kind == $HcomPropaganda) {
		# 유치 활동
		logPropaganda($id, $name, $comName);
		$island->{'propaganda'} = 1;
		$island->{'money'} -= $cost;
		return 1;
	} elsif($kind == $HcomSchool) {
		# 이노라학교
		if($island->{'i_sleep'} > 100) {
			# 이노라수면 중
			logSleepInora($id, $name, $island->{'i_name'}, $comName);
			return 0;
		}
		my $init = 1;
		if($landKind == $HlandMonster) {
			# 괴수
			my($mKind, $mName, $mHp) = monsterSpec($lv,$island);
			$init = 2 if($mKind >= 4);
		}
		logLandInora($id, $name, $comName, $point, $island->{'i_name'});
		$island->{'i_arm'}	 -= random($INORA[2]) + 100;
		$island->{'i_int'}	 += (random($INORA[2]) + $rebi_def[$rebi_int[$island->{'i_type'}]]) * $init;
		$island->{'money'}	 -= $cost;
		return 1;
	} elsif($kind == $HcomEste) {
		# 이노라에스테
		if($island->{'i_sleep'} > 100) {
			# 이노라수면 중
			logSleepInora($id, $name, $island->{'i_name'}, $comName);
			return 0;
		}
		my $init = 1;
		if($landKind == $HlandMonster) {
			# 괴수
			my($mKind, $mName, $mHp) = monsterSpec($lv,$island);
			$init = 2 if($mKind >= 4);
		}
		logLandInora($id, $name, $comName, $point, $island->{'i_name'});
		$island->{'i_cute'}	 += (random($INORA[2]) + $rebi_def[$rebi_cute[$island->{'i_type'}]]) * $init;
		$island->{'i_int'}	 -= random($INORA[2]) + 100;
		$island->{'money'}	 -= $cost;
		return 1;
	} elsif($kind == $HcomTreaning) {
		# 이노라짐
		if($island->{'i_sleep'} > 100) {
			# 이노라수면 중
			logSleepInora($id, $name, $island->{'i_name'}, $comName);
			return 0;
		}
		my $init = 1;
		if($landKind == $HlandMonster) {
			# 괴수
			my($mKind, $mName, $mHp) = monsterSpec($lv,$island);
			$init = 2 if($mKind >= 4);
		}
		logLandInora($id, $name, $comName, $point, $island->{'i_name'});
		$island->{'i_hp'}	 += (random($INORA[1]) + $rebi_def[$rebi_hp[$island->{'i_type'}]]) * $init;
		$island->{'i_cute'}	 -= random($INORA[1]) + 100;
		$island->{'i_arm'}	 += (random($INORA[0]) + $rebi_def[$rebi_arm[$island->{'i_type'}]]) * $init;
		$island->{'i_int'}	 -= random($INORA[1]) + 100;
		$island->{'money'}	 -= $cost;
		return 1;
	} elsif($kind == $HcomRest) {
		# 이노라요양
		if($island->{'i_sleep'} > 100 and $island->{'i_sleep'} < 200) {
			# 이노라수면 중
			logSleepInora($id, $name, $island->{'i_name'}, $comName);
			return 0;
		}
		my $init = 1;
		if($landKind == $HlandMonster) {
			# 괴수
			my($mKind, $mName, $mHp) = monsterSpec($lv,$island);
			$init = 2 if($mKind >= 4);
		}
		logLandInora($id, $name, $comName, $point, $island->{'i_name'});
		$island->{'i_ang'}	 += (random($INORA[1]) + $rebi_def[$rebi_ang[$island->{'i_type'}]]) * $init;
		$island->{'i_heal'}	 += (random($INORA[2]) + $rebi_def[$rebi_heal[$island->{'i_type'}]]) * $init;
		$island->{'i_arm'}	 -= random($INORA[2]) + 100;
		$island->{'money'}	 -= $cost;
		return 1;
	} elsif($kind == $HcomPlay) {
		# 이노라놀이
		if($island->{'i_sleep'} > 100) {
			# 이노라수면 중
			logSleepInora($id, $name, $island->{'i_name'}, $comName);
			return 0;
		}
		my $init = 1;
		if($landKind == $HlandMonster) {
			# 괴수
			my($mKind, $mName, $mHp) = monsterSpec($lv,$island);
			$init = 2 if($mKind >= 4);
		}
		logLandInora($id, $name, $comName, $point, $island->{'i_name'});
		$island->{'i_ang'}	 += (random($INORA[2]) + $rebi_def[$rebi_ang[$island->{'i_type'}]]) * $init;
		$island->{'i_cute'}	 -= random($INORA[0]) + 100;
		$island->{'i_int'}	 -= random($INORA[0]) + 100;
		$island->{'money'}	 -= $cost;
		return 1;
	} elsif($kind == $HcomGiveup) {
		# 포기
		logGiveup($id, $name);
		$island->{'dead'} = 1;
		unlink("island.$id");
		return 1;
	}

	return 1;
}


# 성장 및 단일 헥스 재해
sub doEachHex {
	my($island) = @_;
	my(@monsterMove);

	# 도출값
	my($name) = $island->{'name'};
	my($id) = $island->{'id'};
	my($land) = $island->{'land'};
	my($landValue) = $island->{'landValue'};

	# 이노라식사
	my $foods = int($island->{'i_hp'} * $FOOD[$island->{'i_type'}] / 100);
	$island->{'food'} -= $foods if($island->{'i_sleep'} <= 100);

	# 증가 인구의 기본값
	my($addpop)  = 10;  # 촌락, 마을
	my($addpop2) = 0; # 도시
	if($island->{'food'} < 0) {
		# 식량 부족
		$addpop = -30;
	} elsif($island->{'propaganda'} == 1) {
		# 유치 활동 중
		$addpop = 30;
		$addpop2 = 3;
	}

	# 루프
	my($x, $y, $i);
	for($i = 0; $i < $HpointNumber; $i++) {
		$x = $Hrpx[$i];
		$y = $Hrpy[$i];
		my($landKind) = $land->[$x][$y];
		my($lv) = $landValue->[$x][$y];

		if($landKind == $HlandTown) {
			# 마을 계열
			if($addpop < 0) {
				# 부족
				$lv -= (random(-$addpop) + 1);
				if($lv <= 0) {
					# 평지로 되돌림
					$land->[$x][$y] = $HlandPlains;
					$landValue->[$x][$y] = 0;
					next;
				}
			} else {
				# 성장
				if($lv < 100) {
					$lv += random($addpop) + 1;
					if($lv > 100) {
						$lv = 100;
					}
				} else {
					# 도시가 되면 성장이 느림
					if($addpop2 > 0) {
						$lv += random($addpop2) + 1;
					}
				}
			}
			if($lv > 200) {
				$lv = 200;
			}
			$landValue->[$x][$y] = $lv;
		} elsif($landKind == $HlandPlains) {
			# 평지
			if(random(4) == 0) {
				# 주변에 농장이나 마을이 있으면 이곳도 마을이 됨
				if(countGrow($land, $landValue, $x, $y)){
					$land->[$x][$y] = $HlandTown;
					$landValue->[$x][$y] = 1;
				}
			}
		} elsif($landKind == $HlandForest) {
			# 숲
			if($lv < 200) {
				# 나무를 늘림
				$landValue->[$x][$y] += $HtreeUp;
			}
		} elsif($landKind == $HlandOil) {
			# 해저유전
			my($value, $str, $lName);
			$lName = landName($landKind, $lv);
			$value = $HoilMoney;
			$island->{'money'} += $value;
			$str = "$value$HunitMoney";

			# 수입 로그
			logOilMoney($id, $name, $lName, "($x, $y)", $str);

			# 고갈 판정
			if(random(1000) < $HoilRatio) {
				# 고갈
				logOilEnd($id, $name, $lName, "($x, $y)");
				$land->[$x][$y] = $HlandSea;
				$landValue->[$x][$y] = 0;
			}

		} elsif($landKind == $HlandMonster) {
			# 괴수
			if($monsterMove[$x][$y] == 2) {
				# 이미 이동한 후
				next;
			}

			# 각 요소 꺼내기
			my($mKind, $mName, $mHp) = monsterSpec($landValue->[$x][$y],$island);
			my($special) = $HmonsterSpecial[$mKind];

			# 자고 있음
			if($island->{'i_sleep'} > 100 and $mKind >= 4) {
				next;
			}

			# 경화 중?
			if((($special == 3) && (($HislandTurn % 2) == 1)) ||
			   (($special == 4) && (($HislandTurn % 2) == 0))) {
				# 경화 중
				next;
			}

			# 이동 방향 결정
			my($d, $sx, $sy);
			my($i);
			for($i = 0; $i < 4; $i++) {
				$d = random(6) + 1;
				$sx = $x + $ax[$d];
				$sy = $y + $ay[$d];

				# 행에 따른 위치 보정
				if((($sy % 2) == 0) && (($y % 2) == 1)) {
					$sx--;
				}

				# 범위 밖 판정
				if(($sx < 0) || ($sx >= $HislandSize) ||
				   ($sy < 0) || ($sy >= $HislandSize)) {
					next;
				}

				# 바다, 해저기지, 유전, 괴수, 산, 기념비 이외
				if(($land->[$sx][$sy] != $HlandSea) &&
				   ($land->[$sx][$sy] != $HlandSbase) &&
				   ($land->[$sx][$sy] != $HlandOil) &&
				   ($land->[$sx][$sy] != $HlandMountain) &&
				   ($land->[$sx][$sy] != $HlandMonument) &&
				   ($land->[$sx][$sy] != $HlandMonster)) {
					last;
				}
			}

			if($i == 4) {
				# 움직이지 않음
				if($mKind >= 4 and random(5) == 0) {
					$island->{'i_sleep'} = random($SLEEP[$mKind]) + 101;
				}
				next;
			}

			# 이동한 곳의 지형에 따라 메시지
			my($l) = $land->[$sx][$sy];
			my($lv) = $landValue->[$sx][$sy];
			my($lName) = landName($l, $lv);
			my($point) = "($sx, $sy)";

			# 이동
			$land->[$sx][$sy] = $land->[$x][$y];
			$landValue->[$sx][$sy] = $landValue->[$x][$y];

			# 원래 있던 위치를 황무지로
			$land->[$x][$y] = $HlandWaste;
			$landValue->[$x][$y] = 0;

			# 이동 완료 플래그
			if($HmonsterSpecial[$mKind] == 2) {
				# 이동 완료 플래그는 세우지 않음
			} elsif($HmonsterSpecial[$mKind] == 1) {
				# 빠른 괴수
				$monsterMove[$sx][$sy] = $monsterMove[$x][$y] + 1;
			} else {
				# 보통 괴수
				$monsterMove[$sx][$sy] = 2;
			}

			if($mKind >= 4) {
				if($l == $HlandTown and $lv >= 30) {
					$island->{'i_arm'}  += random($INORA[1]) + $rebi_def[$rebi_arm[$island->{'i_type'}]];
					$island->{'i_heal'} += random($INORA[1]) + $rebi_def[$rebi_heal[$island->{'i_type'}]];
					$island->{'i_int'}  -= random($INORA[0]) + 100;
				} elsif($l == $HlandFarm) {
					$island->{'i_ang'}  += random($INORA[2]) + $rebi_def[$rebi_ang[$island->{'i_type'}]];
					$island->{'i_heal'} += random($INORA[2]) + $rebi_def[$rebi_heal[$island->{'i_type'}]];
					$island->{'i_hp'}   += random($INORA[2]) + $rebi_def[$rebi_hp[$island->{'i_type'}]];
				} elsif($l == $HlandFactory) {
					$island->{'i_heal'} -= random($INORA[2]) + 100;
					$island->{'i_int'}  -= random($INORA[1]) + 100;
				} elsif($l == $HlandBase) {
					$island->{'i_ang'}  -= random($INORA[1]) + 100;
					$island->{'i_hp'}   -= random($INORA[1]) + 100;
					$island->{'i_arm'}  += random($INORA[2]) + $rebi_def[$rebi_arm[$island->{'i_type'}]];
				} elsif($l == $HlandDefence) {
					$island->{'i_ang'}  -= random($INORA[2]) + 100;
					$island->{'i_heal'} -= random($INORA[2]) + 100;
					$island->{'i_hp'}   -= random($INORA[2]) + 100;
					$island->{'i_arm'}  += random($INORA[2]) + $rebi_def[$rebi_arm[$island->{'i_type'}]];
				} elsif($l == $HlandForest) {
					$island->{'i_arm'}  += random($INORA[1]) + $rebi_def[$rebi_arm[$island->{'i_type'}]];
					$island->{'i_ang'}  += random($INORA[1]) + $rebi_def[$rebi_ang[$island->{'i_type'}]];
					$island->{'i_heal'} += random($INORA[1]) + $rebi_def[$rebi_heal[$island->{'i_type'}]];
				}
			}

			# 이동지가 황무지가 됨
			logMonsMove($id, $name, $lName, $point, $mName);
		}

		# 화재 판정
		if((($landKind == $HlandTown) && ($lv > 30)) ||
		   ($landKind == $HlandHaribote) ||
		   ($landKind == $HlandFactory)) {
			if(random(1000) < $HdisFire) {
				# 주변 숲과 기념비를 셈
				if((countAround($land, $x, $y, $HlandForest, 7) +
					countAround($land, $x, $y, $HlandMonument, 7)) == 0) {
					# 없었던 경우 화재로 괴멸
					my($l) = $land->[$x][$y];
					my($lv) = $landValue->[$x][$y];
					my($point) = "($x, $y)";
					my($lName) = landName($l, $lv);
					logFire($id, $name, $lName, $point);
					$land->[$x][$y] = $HlandWaste;
					$landValue->[$x][$y] = 0;
				}
			}
		}
	}
}

# 주변에 마을/농장이 있는지 판정
sub countGrow {
	my($land, $landValue, $x, $y) = @_;
	my($i, $sx, $sy);
	for($i = 1; $i < 7; $i++) {
		 $sx = $x + $ax[$i];
		 $sy = $y + $ay[$i];

		 # 행에 따른 위치 보정
		 if((($sy % 2) == 0) && (($y % 2) == 1)) {
			 $sx--;
		 }

		 if(($sx < 0) || ($sx >= $HislandSize) ||
			($sy < 0) || ($sy >= $HislandSize)) {
		 } else {
			 # 범위 안인 경우
			 if(($land->[$sx][$sy] == $HlandTown) ||
				($land->[$sx][$sy] == $HlandFarm)) {
				 if($landValue->[$sx][$sy] != 1) {
					 return 1;
				 }
			 }
		 }
	}
	return 0;
}

# 섬 전체
sub doIslandProcess {
	my $angry;
	my($number, $island) = @_;

	# 도출값
	my($name) = $island->{'name'};
	my($id) = $island->{'id'};
	my($land) = $island->{'land'};
	my($landValue) = $island->{'landValue'};
	if($island->{'i_ang'} < 1000 and $island->{'i_sleep'} <= 100) {
		# 기분 나쁨
		logAngryMonster($id, $name, $island->{'i_name'});
		if(random(1000) < $HinoraEventQuake) {
			logAngryQuakeMonster($id, $name, $island->{'i_name'});
			$angry++;
		}
	}
	# 지진 판정
	if(random(1000) < (($island->{'prepare2'} + 1) * $HdisEarthquake) or $angry == 1) {
		# 지진 발생
		logEarthquake($id, $name);

		my($x, $y, $landKind, $lv, $i);
		for($i = 0; $i < $HpointNumber; $i++) {
			$x = $Hrpx[$i];
			$y = $Hrpy[$i];
			$landKind = $land->[$x][$y];
			$lv = $landValue->[$x][$y];

			if((($landKind == $HlandTown) && ($lv >= 100)) ||
			   ($landKind == $HlandHaribote) ||
			   ($landKind == $HlandFactory)) {
				# 1/4 확률로 괴멸
				if(random(4) == 0) {
					logEQDamage($id, $name, landName($landKind, $lv),
								"($x, $y)");
					$land->[$x][$y] = $HlandWaste;
					$landValue->[$x][$y] = 0;
				}
			}

		}
	}

	# 이노라병
	if($island->{'i_heal'} < 1000 and $island->{'i_sleep'} <= 100) {
		if(random(1000) < $HdisVirus) {
			my $msg = random($#VIRUS);
			logSickMonster($id, $name, $island->{'i_name'}, $VIRUS[$msg]);
			$island->{'i_sleep'} = 310 + random(10);
			$island->{'i_heal'} = 0;
		}
	}

	# 식량 부족
	if($island->{'food'} <= 0) {
		# 부족 메시지
		logStarve($id, $name);
		$island->{'food'} = 0;
		$island->{'speak'} = 1;

		my($x, $y, $landKind, $lv, $i);
		for($i = 0; $i < $HpointNumber; $i++) {
			$x = $Hrpx[$i];
			$y = $Hrpy[$i];
			$landKind = $land->[$x][$y];
			$lv = $landValue->[$x][$y];

			if(($landKind == $HlandFarm) ||
			   ($landKind == $HlandFactory) ||
			   ($landKind == $HlandBase) ||
			   ($landKind == $HlandDefence)) {
				# 1/4 확률로 괴멸
				if(random(4) == 0) {
					logSvDamage($id, $name, landName($landKind, $lv),
								"($x, $y)");
					$land->[$x][$y] = $HlandWaste;
					$landValue->[$x][$y] = 0;
				}
			}
		}
	}

	# 쓰나미 판정
	if(random(1000) < $HdisTsunami) {
		# 쓰나미 발생
		logTsunami($id, $name);

		my($x, $y, $landKind, $lv, $i);
		for($i = 0; $i < $HpointNumber; $i++) {
			$x = $Hrpx[$i];
			$y = $Hrpy[$i];
			$landKind = $land->[$x][$y];
			$lv = $landValue->[$x][$y];

			if(($landKind == $HlandTown) ||
			   ($landKind == $HlandFarm) ||
			   ($landKind == $HlandFactory) ||
			   ($landKind == $HlandBase) ||
			   ($landKind == $HlandDefence) ||
			   ($landKind == $HlandHaribote)) {
				# 1d12 <= (주변 바다 - 1)이면 붕괴
				if(random(12) <
				   (countAround($land, $x, $y, $HlandOil, 7) +
					countAround($land, $x, $y, $HlandSbase, 7) +
					countAround($land, $x, $y, $HlandSea, 7) - 1)) {
					logTsunamiDamage($id, $name, landName($landKind, $lv),
									 "($x, $y)");
					$land->[$x][$y] = $HlandWaste;
					$landValue->[$x][$y] = 0;
				}
			}

		}
	}

	# 괴수 판정
	my($r) = random(10000);
	my($pop) = $island->{'pop'};
	do{
		if((($r < ($HdisMonster * $island->{'area'})) &&
			($pop >= $HdisMonsBorder1)) ||
		   ($island->{'monstersend'} > 0)) {
			# 괴수 출현
			# 종류 결정
			my($lv, $kind);
			if($pop >= $HdisMonsBorder3) {
				# level3까지
				$kind = random($HmonsterLevel3) + 1;
			} elsif($pop >= $HdisMonsBorder2) {
				# level2까지
				$kind = random($HmonsterLevel2) + 1;
			} else {
				# level1만
				$kind = random($HmonsterLevel1) + 1;
			}

			# lv 값 결정
			$lv = $kind * 10
				+ $HmonsterBHP[$kind] + random($HmonsterDHP[$kind]);

			# 어디에 나타날지 결정
			my($bx, $by, $i);
			for($i = 0; $i < $HpointNumber; $i++) {
				$bx = $Hrpx[$i];
				$by = $Hrpy[$i];
				if($land->[$bx][$by] == $HlandTown) {

					# 지형명
					my($lName) = landName($HlandTown, $landValue->[$bx][$by]);

					# 그 헥스를 괴수로
					$land->[$bx][$by] = $HlandMonster;
					$landValue->[$bx][$by] = $lv;

					# 괴수 정보
					my($mKind, $mName, $mHp) = monsterSpec($lv);

					# 메시지
					logMonsCome($id, $name, $mName, "($bx, $by)", $lName);
					last;
				}
			}
		}
	} while($island->{'monstersend'} > 0);

	# 지반 침하 판정
	if(($island->{'area'} > $HdisFallBorder) &&
	   (random(1000) < $HdisFalldown)) {
		# 지반 침하 발생
		logFalldown($id, $name);

		my($x, $y, $landKind, $lv, $i);
		for($i = 0; $i < $HpointNumber; $i++) {
			$x = $Hrpx[$i];
			$y = $Hrpy[$i];
			$landKind = $land->[$x][$y];
			$lv = $landValue->[$x][$y];

			if(($landKind != $HlandSea) &&
			   ($landKind != $HlandSbase) &&
			   ($landKind != $HlandOil) &&
			   ($landKind != $HlandMonster) &&
			   ($landKind != $HlandMountain)) {

				# 주변에 바다가 있으면 값을 -1로
				if(countAround($land, $x, $y, $HlandSea, 7) + 
				   countAround($land, $x, $y, $HlandSbase, 7)) {
					logFalldownLand($id, $name, landName($landKind, $lv),
								"($x, $y)");
					$land->[$x][$y] = -1;
					$landValue->[$x][$y] = 0;
				}
			}
		}

		for($i = 0; $i < $HpointNumber; $i++) {
			$x = $Hrpx[$i];
			$y = $Hrpy[$i];
			$landKind = $land->[$x][$y];

			if($landKind == -1) {
				# -1이 된 곳을 얕은 바다로
				$land->[$x][$y] = $HlandSea;
				$landValue->[$x][$y] = 1;
			} elsif ($landKind == $HlandSea) {
				# 얕은 바다는 바다로
				$landValue->[$x][$y] = 0;
			}

		}
	}

	# 태풍 판정
	if(random(1000) < $HdisTyphoon) {
		# 태풍 발생
		logTyphoon($id, $name);

		my($x, $y, $landKind, $lv, $i);
		for($i = 0; $i < $HpointNumber; $i++) {
			$x = $Hrpx[$i];
			$y = $Hrpy[$i];
			$landKind = $land->[$x][$y];
			$lv = $landValue->[$x][$y];

			if(($landKind == $HlandFarm) ||
			   ($landKind == $HlandHaribote) || 
			   ($landKind == $HlandMonster and $island->{'i_typhoon'} == 0 and $lv > 40 and 
				$island->{'i_age'} + 50 < $HislandTurn and random(1000) < $HdisTyphIno)) {
				if($landKind == $HlandMonster) {
					# 이노라도 날아감
					logTyphoonDamage($id, $name, $island->{'i_name'}, "($x, $y)");
					$land->[$x][$y] = $HlandWaste;
					$landValue->[$x][$y] = 0;
					$island->{'i_typhoon'} = 1;
					# 어디에 나타날지 결정
					my($bx, $by, $i);
					for($i = 0; $i < $HpointNumber; $i++) {
						$bx = $Hrpx[$i];
						$by = $Hrpy[$i];
						if($land->[$bx][$by] == $HlandTown) {
							# 지형명
							# 그 헥스를 괴수로
							$land->[$bx][$by] = $HlandMonster;
							$landValue->[$bx][$by] = $lv;
							last;
						}
					}
				} else {
					# 1d12 <= (6 - 주변 숲)이면 붕괴
					if(random(12) < 
					   (6
						- countAround($land, $x, $y, $HlandForest, 7)
						- countAround($land, $x, $y, $HlandMonument, 7))) {
							logTyphoonDamage($id, $name, landName($landKind, $lv),
										 "($x, $y)");
						$land->[$x][$y] = $HlandPlains;
						$landValue->[$x][$y] = 0;
					}
				}
			}

		}
	}

	# 운석 판정
	if(random(1000) < $HdisMeteo) {
		my($x, $y, $landKind, $lv, $point, $first);
		$first = 1;
		while((random(2) == 0) || ($first == 1)) {
			$first = 0;
			
			# 낙하
			$x = random($HislandSize);
			$y = random($HislandSize);
			$landKind = $land->[$x][$y];
			$lv = $landValue->[$x][$y];
			$point = "($x, $y)";

			if(($landKind == $HlandSea) && ($lv == 0)){
				# 바다에 빠짐
				logMeteoSea($id, $name, landName($landKind, $lv),
							$point);
			} elsif($landKind == $HlandMountain) {
				# 산 파괴
				logMeteoMountain($id, $name, landName($landKind, $lv),
								 $point);
				$land->[$x][$y] = $HlandWaste;
				$landValue->[$x][$y] = 0;
				next;
			} elsif($landKind == $HlandSbase) {
				logMeteoSbase($id, $name, landName($landKind, $lv),
							  $point);
			} elsif($landKind == $HlandMonster) {
				my($mKind, $mName, $mHp) = monsterSpec($lv,$island);
				if($mKind >= 4) {
					logMeteoMonster2($id, $name, $mName, $point);
					$island->{'i_sleep'} -= 10 if($island->{'i_sleep'} > 100 and $island->{'i_sleep'} < 200);
					$island->{'speak'} = 7;
					$island->{'i_hp'}   -= 1000;
					$island->{'i_ang'}  -= random($INORA[2]) + 100;
					$island->{'i_heal'} -= random($INORA[2]) + 100;
					next;
				} else {
					logMeteoMonster($id, $name, $mName, $point);
				}
			} elsif($landKind == $HlandSea) {
				# 얕은 바다
				logMeteoSea1($id, $name, landName($landKind, $lv),
							 $point);
			} else {
				logMeteoNormal($id, $name, landName($landKind, $lv),
							   $point);
			}
			$land->[$x][$y] = $HlandSea;
			$landValue->[$x][$y] = 0;
		}
	}

	# 분화 판정
	if(random(1000) < $HdisEruption) {
		my($x, $y, $sx, $sy, $i, $landKind, $lv, $point);
		$x = random($HislandSize);
		$y = random($HislandSize);
		$landKind = $land->[$x][$y];
		if($landKind != $HlandMonster) {
			$lv = $landValue->[$x][$y];
			$point = "($x, $y)";
			logEruption($id, $name, landName($landKind, $lv),
						$point);
			$land->[$x][$y] = $HlandMountain;
			$landValue->[$x][$y] = 0;

			for($i = 1; $i < 7; $i++) {
				$sx = $x + $ax[$i];
				$sy = $y + $ay[$i];

				# 행에 따른 위치 보정
				if((($sy % 2) == 0) && (($y % 2) == 1)) {
					$sx--;
				}

				$landKind = $land->[$sx][$sy];
				$lv = $landValue->[$sx][$sy];
				$point = "($sx, $sy)";

				if(($sx < 0) || ($sx >= $HislandSize) ||
				   ($sy < 0) || ($sy >= $HislandSize)) {
				} else {
					# 범위 안인 경우
					$landKind = $land->[$sx][$sy];
					$lv = $landValue->[$sx][$sy];
					$point = "($sx, $sy)";
					if(($landKind == $HlandSea) ||
					   ($landKind == $HlandOil) ||
					   ($landKind == $HlandSbase)) {
						# 바다인 경우
						if($lv == 1) {
							# 얕은 바다
							logEruptionSea1($id, $name, landName($landKind, $lv),
											$point);
						} else {
							logEruptionSea($id, $name, landName($landKind, $lv),
										   $point);
							$land->[$sx][$sy] = $HlandSea;
							$landValue->[$sx][$sy] = 1;
							next;
						}
					} elsif(($landKind == $HlandMountain) ||
							($landKind == $HlandMonster) ||
							($landKind == $HlandWaste)) {
						next;
					} else {
						# 그 밖의 경우
						logEruptionNormal($id, $name, landName($landKind, $lv),
										  $point);
					}
					$land->[$sx][$sy] = $HlandWaste;
					$landValue->[$sx][$sy] = 0;
				}
			}
		}
	}

	# 식량이 넘치면 현금화
	if($island->{'food'} > 9999) {
		$island->{'money'} += int(($island->{'food'} - 9999) / 10);
		$island->{'food'} = 9999;
	} 

	# 자금이 넘치면 버림
	if($island->{'money'} > 9999) {
		$island->{'money'} = 9999;
	} 

	# 각종 값 계산
	estimate($number);

	# 번영상, 재난상
	$pop = $island->{'pop'};
	my($damage) = $island->{'oldPop'} - $pop;
	my($prize) = $island->{'prize'};
	$prize =~ /([0-9]*),([0-9]*),(.*)/;
	my($flags) = $1;
	my($monsters) = $2;
	my($turns) = $3;

	# 번영상
	if((!($flags & 1)) &&  $pop >= 3000){
		$flags |= 1;
		logPrize($id, $name, $Hprize[1]);
	} elsif((!($flags & 2)) &&  $pop >= 5000){
		$flags |= 2;
		logPrize($id, $name, $Hprize[2]);
	} elsif((!($flags & 4)) &&  $pop >= 10000){
		$flags |= 4;
		logPrize($id, $name, $Hprize[3]);
	}

	# 재난상
	if((!($flags & 64)) &&  $damage >= 500){
		$flags |= 64;
		logPrize($id, $name, $Hprize[7]);
	} elsif((!($flags & 128)) &&  $damage >= 1000){
		$flags |= 128;
		logPrize($id, $name, $Hprize[8]);
	} elsif((!($flags & 256)) &&  $damage >= 2000){
		$flags |= 256;
		logPrize($id, $name, $Hprize[9]);
	}

	$island->{'prize'} = "$flags,$monsters,$turns";

	my $sleep = $island->{'i_sleep'};
	my $old_sleep = $island->{'old_i_sleep'};
	if($old_sleep > 100 or $sleep > 200) {
		# 수면 중
		$sleep--;
		if($sleep <= 100) {
			# 일어남
			$sleep = 90 - random($WAKE[$island->{'i_type'}]);
			logWakeUpMonster($id, $name, $island->{'i_name'});
			$island->{'speak'} = 6;
		}
		$island->{'i_heal'} += random($INORA[0]);
		if($sleep >= 300) {
			if($sleep == 300 or $island->{'i_heal'} > 1000) {
				logGenki($id, $name, $island->{'i_name'});
				$sleep = 90 - random($WAKE[$island->{'i_type'}]);
				$island->{'i_heal'} = 1500;
			} else {
				$island->{'i_ang'}  -= random($INORA[1]) + 100;
				$island->{'i_hp'}   -= random($INORA[1]) + 100;
				$island->{'i_cute'} -= random($INORA[1]) + 100;
				$island->{'i_arm'}  -= random($INORA[1]) + 100;
				$island->{'i_int'}  -= random($INORA[1]) + 100;
			}
		}
	} else {
		# 활동 중
		$sleep++;
		if($sleep >= 100) {
			# 잠듦
			$sleep = random($SLEEP[$island->{'i_type'}]) + 101;
			logSleepMonster($id, $name, $island->{'i_name'});
		}
		# 이노라파라미터 자연 감소
		my $tax = ($island->{'i_heal'} < 1000) ? 1 : 5;
		$island->{'i_ang'}  -= random($INORA[0]/$tax) + 50;
		$island->{'i_heal'} -= random($INORA[0]/$tax) + 50;
		$island->{'i_hp'}   -= random($INORA[0]/$tax);
		$island->{'i_cute'} -= random($INORA[0]/$tax);
		$island->{'i_arm'}  -= random($INORA[0]/$tax);
		$island->{'i_int'}  -= random($INORA[0]/$tax);
	}
	$island->{'i_sleep'} = $sleep;


	# 이노라진화
	my $type;
	my $old_type = $island->{'i_type'};
	$old_type = 5.5 if($old_type == 11);
	if($island->{'i_hp'} >= 20000 and $island->{'i_cute'} >= 20000 and 
		$island->{'i_int'} >= 20000 and $island->{'i_arm'} >= 20000) {
		# 퀸이노라
		$type = 10;
	} elsif($island->{'i_hp'} >= 10000 and $island->{'i_cute'} >= 10000 and 
		$island->{'i_int'} >= 10000 and $island->{'i_arm'} >= 10000) {
		# 킹이노라
		$type = 9;
	} elsif($island->{'i_hp'} >= 3000 and $island->{'i_int'} >= 4000) {
		# 다크이노라
		$type = 8;
	} elsif($island->{'i_hp'} >= 3000 and $island->{'i_cute'} >= 4000) {
		# 레드이노라
		$type = 7;
	} elsif($island->{'i_hp'} >= 3000 and $island->{'i_arm'} >= 5000) {
		# 그린이노라
		$type = 6;
	} elsif($island->{'i_arm'} >= 4000 and ($old_type == 4 or $old_type == 5.5)) {
		# 그레이이노라
		$type = 5.5;
	} elsif($island->{'i_hp'} >= 4000 and ($old_type == 4 or $old_type == 5)) {
		# 비만이노라
		$type = 5;
	} else {
		# 베이비이노라
		$type = 4;
	}
	if($type > $old_type) {
		$island->{'i_ang'}	+= $INORA[0];
		$island->{'i_heal'}	+= $INORA[0];
		$island->{'i_hp'}	+= $INORA[0];
		$island->{'i_cute'}	+= $INORA[0];
		$island->{'i_int'}	+= $INORA[0];
		$island->{'i_arm'}	+= $INORA[0];
		$type = 11 if($type == 5.5);
		logGrowUp($id, $name, $type, $island->{'i_name'});
	} elsif($type < $old_type) {
		$island->{'i_ang'}	-= int($INORA[0]/2);
		$island->{'i_heal'}	-= int($INORA[0]/2);
		$island->{'i_hp'}	-= int($INORA[0]/2);
		$island->{'i_cute'}	-= int($INORA[0]/2);
		$island->{'i_int'}	-= int($INORA[0]/2);
		$island->{'i_arm'}	-= int($INORA[0]/2);
		$type = 11 if($type == 5.5);
		logGrowDown($id, $name, $type, $island->{'i_name'});
	}
	$type = 11 if($type == 5.5);
	$island->{'i_type'} = $type;
	$island->{'i_ang'}  = 3000 if($island->{'i_ang'} > 3000);
	$island->{'i_heal'} = 2000 if($island->{'i_heal'} > 2000);
	$island->{'i_ang'}  = 0 if($island->{'i_ang'} < 0);
	$island->{'i_heal'} = 0 if($island->{'i_heal'} < 0);
	$island->{'i_hp'}   = 500 if($island->{'i_hp'} < 500);
	$island->{'i_cute'} = 500 if($island->{'i_cute'} < 500);
	$island->{'i_arm'}  = 500 if($island->{'i_arm'} < 500);
	$island->{'i_int'}  = 500 if($island->{'i_int'} < 500);

	$island->{'speak'} = 2 if(!$island->{'speak'} and $island->{'i_ang'} >= 2900);
	$island->{'speak'} = 3 if(!$island->{'speak'} and $island->{'i_ang'} <= 1300);
	$island->{'speak'} = 4 if(!$island->{'speak'} and $island->{'i_heal'} >= 1900);
	$island->{'speak'} = 5 if(!$island->{'speak'} and $island->{'i_heal'} <= 1300);

	if($sleep <= 100 and (random(5) == 0 or ($island->{'speak'} and random(3) == 0))) {
		# 이노라말하기
		my $msg;
		my $speak = ($island->{'speak'}) ? $island->{'speak'} : 0;
		my $count = $SPEAK[$island->{'i_type'}][$speak][0];
		$count = random($count) + 1;
		$msg = $SPEAK[$island->{'i_type'}][$speak][$count];
		logSpeak($id, $name, $island->{'i_name'}, $msg);
	}
}

# 인구순으로 정렬
sub islandSort {
	my($flag, $i, $tmp);

	# 인구가 같을 시는 직전 턴의 순서 그대로
	my @idx = (0..$#Hislands);
	@idx = sort { $Hislands[$b]->{'pop'} <=> $Hislands[$a]->{'pop'} || $a <=> $b } @idx;
	@Hislands = @Hislands[@idx];
}

# 이노라의 순위 매기기
sub inora_sort {
	my $mode = $_[0];
	my($flag, $i, $tmp);

	# 같을 시는 인구가 높은 쪽을 상위로
	my @idx = (0..$#Hislands);
	@idx = sort { $Hislands[$b]->{$mode} <=> $Hislands[$a]->{$mode} || $a <=> $b } @idx;
	@Hislands = @Hislands[@idx];

}

# 로그 출력
# 제1인수: 메시지
# 제2인수: 당사자
# 제3인수: 상대
# 일반 로그
sub logOut {
	push(@HlogPool,"0,$HislandTurn,$_[1],$_[2],$_[0]");
}

# 지연 로그
sub logLate {
	push(@HlateLogPool,"0,$HislandTurn,$_[1],$_[2],$_[0]");
}

# 비밀 로그
sub logSecret {
	push(@HsecretLogPool,"1,$HislandTurn,$_[1],$_[2],$_[0]");
}

# 기록 로그
sub logHistory {
	open(HOUT, ">>:encoding(UTF-8)", "${HdirName}/hakojima.his");
	print HOUT "$HislandTurn,$_[0]\n";
	close(HOUT);
}

# 기록 로그 조정
sub logHistoryTrim {
	open(HIN, "<:raw", "${HdirName}/hakojima.his");
	my(@line, $l, $count);
	$count = 0;
	while($l = <HIN>) {
		chomp($l);
		push(@line, $l);
		$count++;
	}
	close(HIN);

	if($count > $HhistoryMax) {
		open(HOUT, ">:encoding(UTF-8)", "${HdirName}/hakojima.his");
		my($i);
		for($i = ($count - $HhistoryMax); $i < $count; $i++) {
			print HOUT "$line[$i]\n";
		}
		close(HOUT);
	}
}

# 로그 쓰기
sub logFlush {
	open(LOUT, ">:encoding(UTF-8)", "${HdirName}/hakojima.log0");

	# 전부 역순으로 하여 출력
	my($i);
	for($i = $#HsecretLogPool; $i >= 0; $i--) {
		print LOUT $HsecretLogPool[$i];
		print LOUT "\n";
	}
	for($i = $#HlateLogPool; $i >= 0; $i--) {
		print LOUT $HlateLogPool[$i];
		print LOUT "\n";
	}
	for($i = $#HlogPool; $i >= 0; $i--) {
		print LOUT $HlogPool[$i];
		print LOUT "\n";
	}
	close(LOUT);
}

#----------------------------------------------------------------------
# 로그 템플릿
#----------------------------------------------------------------------
# 자금 부족
sub logNoMoney {
	my($id, $name, $comName) = @_;
	logOut("${HtagName_}${name}섬${H_tagName}에서 예정되어 있던${HtagComName_}$comName${H_tagComName}은(는) 자금 부족으로 중지되었습니다.",$id);
}

# 식량 부족
sub logNoFood {
	my($id, $name, $comName) = @_;
	logOut("${HtagName_}${name}섬${H_tagName}에서 예정되어 있던${HtagComName_}$comName${H_tagComName}은(는) 비축 식량 부족으로 중지되었습니다.",$id);
}

# 대상 지형 종류로 인한 실패
sub logLandFail {
	my($id, $name, $comName, $kind, $point) = @_;
	logOut("${HtagName_}${name}섬${H_tagName}에서 예정되어 있던${HtagComName_}$comName${H_tagComName}은(는) 예개간의 ${HtagName_}$point${H_tagName}이(가)<B>$kind</B>였기 시문에 중지되었습니다.",$id);
END
}

# 주변에 육지가 없어 매립 실패
sub logNoLandAround {
	my($id, $name, $comName, $point) = @_;
	logOut("${HtagName_}${name}섬${H_tagName}에서 예정되어 있던${HtagComName_}$comName${H_tagComName}은(는) 예개간의 ${HtagName_}$point${H_tagName} 주변에 육지가 없었기 시문에 중지되었습니다.",$id);
END
}

# 개간 계열 성공
sub logLandSuc {
	my($id, $name, $comName, $point) = @_;
	logOut("${HtagName_}${name}섬$point${H_tagName}에서${HtagComName_}${comName}${H_tagComName}이(가) 실행되었습니다.",$id);
END
}

# 이노라계열 성공
sub logLandInora {
	my($id, $name, $comName, $point, $monsName) = @_;
	logOut("${HtagName_}${name}섬${H_tagName}의 <b>$monsName</b>은(는) ${HtagComName_}${comName}${H_tagComName}에 갔습니다.",$id);
END
}

# 유전 발견
sub logOilFound {
	my($id, $name, $point, $comName, $str) = @_;
	logOut("${HtagName_}${name}섬$point${H_tagName}에서 <B>$str</B>의 예산을 투입한 ${HtagComName_}${comName}${H_tagComName}이(가) 실행되어 <B>유전이 발견되었습니다</B>.",$id);
END
}

# 유전 발견 실패
sub logOilFail {
	my($id, $name, $point, $comName, $str) = @_;
	logOut("${HtagName_}${name}섬$point${H_tagName}에서 <B>$str</B>의 예산을 투입한 ${HtagComName_}${comName}${H_tagComName}이(가) 실행되었지만, 유전은 발견되지 않았습니다.",$id);
END
}

# 유전 수입
sub logOilMoney {
	my($id, $name, $lName, $point, $str) = @_;
	logOut("${HtagName_}${name}섬$point${H_tagName}의 <B>$lName</B>에서 <B>$str</B>의 수익이 발생했습니다.",$id);
END
}

# 유전 고갈
sub logOilEnd {
	my($id, $name, $lName, $point) = @_;
	logOut("${HtagName_}${name}섬$point${H_tagName}의 <B>$lName</B>은(는) 고갈된 것 같습니다.",$id);
END
}

# 조림 또는 미사일 기지
sub logPBSuc {
	my($id, $name, $comName, $point) = @_;
	logSecret("${HtagName_}${name}섬$point${H_tagName}에서${HtagComName_}${comName}${H_tagComName}이(가) 실행되었습니다.",$id);
	logOut("왠지 모르게 ${HtagName_}${name}섬${H_tagName}의 <B>숲</B>이 늘어난 것 같습니다.",$id);
END
}

# 허수아비
sub logHariSuc {
	my($id, $name, $comName, $comName2, $point) = @_;
	logSecret("${HtagName_}${name}섬$point${H_tagName}에서${HtagComName_}${comName}${H_tagComName}이(가) 실행되었습니다.",$id);
	logLandSuc($id, $name, $comName2, $point);
END
}

# 미사일을 쏘려고 했지만(또는 괴수를 파견하려 했지만) 타깃이 없음
sub logMsNoTarget {
	my($id, $name, $comName) = @_;
	logOut("${HtagName_}${name}섬${H_tagName}에서 예정되어 있던${HtagComName_}${comName}${H_tagComName}은(는) 목표 섬에 사람이 보이지 않아 중지되었습니다.",$id);
END
}

# 미사일을 쏘려 했지만 기지가 없음
sub logMsNoBase {
	my($id, $name, $comName) = @_;
	logOut("${HtagName_}${name}섬${H_tagName}에서 예정되어 있던${HtagComName_}${comName}${H_tagComName}은(는) <B>미사일 설비를 보유하지 않았기</B> 시문에 실행할 수 없었습니다.",$id);
END
}

# 미사일을 쐈지만 범위 밖
sub logMsOut {
	my($id, $tId, $name, $tName, $comName, $point) = @_;
	logOut("${HtagName_}${name}섬${H_tagName}이(가) ${HtagName_}${tName}섬$point${H_tagName}지점을 향해 ${HtagComName_}${comName}${H_tagComName}을(를) 실행했지만, <B>영역 밖의 바다</B>에 떨어진 모양입니다.",$id, $tId);
}

# 스텔스 미사일을 쐈지만 범위 밖
sub logMsOutS {
	my($id, $tId, $name, $tName, $comName, $point) = @_;
	logSecret("${HtagName_}${name}섬${H_tagName}이(가) ${HtagName_}${tName}섬$point${H_tagName}지점을 향해 ${HtagComName_}${comName}${H_tagComName}을(를) 실행했지만, <B>영역 밖의 바다</B>에 떨어진 모양입니다.",$id, $tId);
	logLate("<B>누군가</B>이(가) ${HtagName_}${tName}섬$point${H_tagName}를 향해 ${HtagComName_}${comName}${H_tagComName}을(를) 실행했지만, <B>영역 밖의 바다</B>에 떨어진 모양입니다.",$tId);
}

# 미사일을 쐈지만 방위시설에 포착됨
sub logMsCaught {
	my($id, $tId, $name, $tName, $comName, $point, $tPoint) = @_;
	logOut("${HtagName_}${name}섬${H_tagName}이(가) ${HtagName_}${tName}섬$point${H_tagName}지점을 향해 ${HtagComName_}${comName}${H_tagComName}을(를) 실행했지만, ${HtagName_}$tPoint${H_tagName} 지점 상공에서 역장에 붙잡혀 <B>공중 폭발</B>했습니다.",$id, $tId);
}

# 스텔스 미사일을 쐈지만 방위시설에 포착됨
sub logMsCaughtS {
	my($id, $tId, $name, $tName, $comName, $point, $tPoint) = @_;
	logSecret("${HtagName_}${name}섬${H_tagName}이(가) ${HtagName_}${tName}섬$point${H_tagName}지점을 향해 ${HtagComName_}${comName}${H_tagComName}을(를) 실행했지만, ${HtagName_}$tPoint${H_tagName} 지점 상공에서 역장에 붙잡혀 <B>공중 폭발</B>했습니다.",$id, $tId);
	logLate("<B>누군가</B>이(가) ${HtagName_}${tName}섬$point${H_tagName}를 향해 ${HtagComName_}${comName}${H_tagComName}을(를) 실행했지만, ${HtagName_}$tPoint${H_tagName} 지점 상공에서 역장에 붙잡혀 <B>공중 폭발</B>했습니다.",$tId);
}

# 미사일을 쐈지만 효과 없음
sub logMsNoDamage {
	my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
	logOut("${HtagName_}${name}섬${H_tagName}이(가) ${HtagName_}${tName}섬$point${H_tagName}지점을 향해 ${HtagComName_}${comName}${H_tagComName}을(를) 실행했지만, ${HtagName_}$tPoint${H_tagName}의 <B>$tLname</B>에 떨어져 피해가 없었습니다.",$id, $tId);
}

# 스텔스 미사일을 쐈지만 효과 없음
sub logMsNoDamageS {
	my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
	logSecret("${HtagName_}${name}섬${H_tagName}이(가) ${HtagName_}${tName}섬$point${H_tagName}지점을 향해 ${HtagComName_}${comName}${H_tagComName}을(를) 실행했지만, ${HtagName_}$tPoint${H_tagName}의 <B>$tLname</B>에 떨어져 피해가 없었습니다.",$id, $tId);

	logLate("<B>누군가</B>이(가) ${HtagName_}${tName}섬$point${H_tagName}지점을 향해 ${HtagComName_}${comName}${H_tagComName}을(를) 실행했지만, ${HtagName_}$tPoint${H_tagName}의 <B>$tLname</B>에 떨어져 피해가 없었습니다.",$tId);
}

# 육지파괴탄, 산에 명중
sub logMsLDMountain {
	my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
	logOut("${HtagName_}${name}섬${H_tagName}이(가) ${HtagName_}${tName}섬$point${H_tagName}지점을 향해 ${HtagComName_}${comName}${H_tagComName}을(를) 실행하여 ${HtagName_}$tPoint${H_tagName}의 <B>$tLname</B>에 명중. <B>$tLname</B>은(는) 날아가 황무지가 되었습니다.",$id, $tId);
}

# 육지파괴탄, 해저기지에 명중
sub logMsLDSbase {
	my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
	logOut("${HtagName_}${name}섬${H_tagName}이(가) ${HtagName_}${tName}섬$point${H_tagName}지점을 향해 ${HtagComName_}${comName}${H_tagComName}을(를) 실행하여 ${HtagName_}$tPoint${H_tagName}에 착수 후 폭발하여, 같은 지점에 있던 <B>$tLname</B>은(는) 흔적도 없이 날아갔습니다.",$id, $tId);
}

# 육지파괴탄, 괴수에 명중
sub logMsLDMonster {
	my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
	logOut("${HtagName_}${name}섬${H_tagName}이(가) ${HtagName_}${tName}섬$point${H_tagName}지점을 향해 ${HtagComName_}${comName}${H_tagComName}을(를) 실행하여 ${HtagName_}$tPoint${H_tagName}에 착탄해 폭발. 육지는 <B>$tLname</B>째로 수몰되었습니다.",$id, $tId);
}

# 육지파괴탄, 얕은 바다에 명중
sub logMsLDSea1 {
	my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
	logOut("${HtagName_}${name}섬${H_tagName}이(가) ${HtagName_}${tName}섬$point${H_tagName}지점을 향해 ${HtagComName_}${comName}${H_tagComName}을(를) 실행하여 ${HtagName_}$tPoint${H_tagName}의 <B>$tLname</B>에 착탄. 해저가 파였습니다.",$id, $tId);
}

# 육지파괴탄, 기타 지형에 명중
sub logMsLDLand {
	my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
	logOut("${HtagName_}${name}섬${H_tagName}이(가) ${HtagName_}${tName}섬$point${H_tagName}지점을 향해 ${HtagComName_}${comName}${H_tagComName}을(를) 실행하여 ${HtagName_}$tPoint${H_tagName}의 <B>$tLname</B>에 착탄. 육지는 수몰되었습니다.",$id, $tId);
}

# 일반 미사일, 황무지에 착탄
sub logMsWaste {
	my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
	logOut("${HtagName_}${name}섬${H_tagName}이(가) ${HtagName_}${tName}섬$point${H_tagName}지점을 향해 ${HtagComName_}${comName}${H_tagComName}을(를) 실행했지만, ${HtagName_}$tPoint${H_tagName}의 <B>$tLname</B>에 떨어졌습니다.",$id, $tId);
}

# 스텔스 미사일, 황무지에 착탄
sub logMsWasteS {
	my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
	logSecret("${HtagName_}${name}섬${H_tagName}이(가) ${HtagName_}${tName}섬$point${H_tagName}지점을 향해 ${HtagComName_}${comName}${H_tagComName}을(를) 실행했지만, ${HtagName_}$tPoint${H_tagName}의 <B>$tLname</B>에 떨어졌습니다.",$id, $tId);
	logLate("<B>누군가</B>이(가) ${HtagName_}${tName}섬$point${H_tagName}지점을 향해 ${HtagComName_}${comName}${H_tagComName}을(를) 실행했지만, ${HtagName_}$tPoint${H_tagName}의 <B>$tLname</B>에 떨어졌습니다.",$tId);
}

# 일반 미사일, 괴수에 명중, 경화 중이라 무상
sub logMsMonNoDamage {
	my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
	logOut("${HtagName_}${name}섬${H_tagName}이(가) ${HtagName_}${tName}섬$point${H_tagName}지점을 향해 ${HtagComName_}${comName}${H_tagComName}을(를) 실행하여 ${HtagName_}$tPoint${H_tagName}의 <B>$tLname</B>에 명중했지만, 경화 상태였기 시문에 효과가 없었습니다.",$id, $tId);
}

# 스텔스 미사일, 괴수에 명중, 경화 중이라 무상
sub logMsMonNoDamageS {
	my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
	logSecret("${HtagName_}${name}섬${H_tagName}이(가) ${HtagName_}${tName}섬$point${H_tagName}지점을 향해 ${HtagComName_}${comName}${H_tagComName}을(를) 실행하여 ${HtagName_}$tPoint${H_tagName}의 <B>$tLname</B>에 명중했지만, 경화 상태였기 시문에 효과가 없었습니다.",$id, $tId);
	logOut("<B>누군가</B>이(가) ${HtagName_}${tName}섬$point${H_tagName}지점을 향해 ${HtagComName_}${comName}${H_tagComName}을(를) 실행하여 ${HtagName_}$tPoint${H_tagName}의 <B>$tLname</B>에 명중했지만, 경화 상태였기 시문에 효과가 없었습니다.",$tId);
}

# 일반 미사일, 괴수에 명중, 처치
sub logMsMonKill {
	my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
	logOut("${HtagName_}${name}섬${H_tagName}이(가) ${HtagName_}${tName}섬$point${H_tagName}지점을 향해 ${HtagComName_}${comName}${H_tagComName}을(를) 실행하여 ${HtagName_}$tPoint${H_tagName}의 <B>$tLname</B>에 명중. <B>$tLname</B>은(는) 힘이 다해 쓰러졌습니다.",$id, $tId);
}

# 스텔스 미사일, 괴수에 명중, 처치
sub logMsMonKillS {
	my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
	logSecret("${HtagName_}${name}섬${H_tagName}이(가) ${HtagName_}${tName}섬$point${H_tagName}지점을 향해 ${HtagComName_}${comName}${H_tagComName}을(를) 실행하여 ${HtagName_}$tPoint${H_tagName}의 <B>$tLname</B>에 명중. <B>$tLname</B>은(는) 힘이 다해 쓰러졌습니다.",$id, $tId);
	logLate("<B>누군가</B>이(가) ${HtagName_}${tName}섬$point${H_tagName}지점을 향해 ${HtagComName_}${comName}${H_tagComName}을(를) 실행하여 ${HtagName_}$tPoint${H_tagName}의 <B>$tLname</B>에 명중. <B>$tLname</B>은(는) 힘이 다해 쓰러졌습니다.", $tId);
}

# 일반 미사일, 괴수에 명중, 피해
sub logMsMonster {
	my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
	logOut("${HtagName_}${name}섬${H_tagName}이(가) ${HtagName_}${tName}섬$point${H_tagName}지점을 향해 ${HtagComName_}${comName}${H_tagComName}을(를) 실행하여 ${HtagName_}$tPoint${H_tagName}의 <B>$tLname</B>에 명중. <B>$tLname</B>은(는) 괴로운 듯 포효했습니다.",$id, $tId);
}

# 스텔스 미사일, 괴수에 명중, 피해
sub logMsMonsterS {
	my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
	logSecret("${HtagName_}${name}섬${H_tagName}이(가) ${HtagName_}${tName}섬$point${H_tagName}지점을 향해 ${HtagComName_}${comName}${H_tagComName}을(를) 실행하여 ${HtagName_}$tPoint${H_tagName}의 <B>$tLname</B>에 명중. <B>$tLname</B>은(는) 괴로운 듯 포효했습니다.",$id, $tId);
	logLate("<B>누군가</B>이(가) ${HtagName_}${tName}섬$point${H_tagName}지점을 향해 ${HtagComName_}${comName}${H_tagComName}을(를) 실행하여 ${HtagName_}$tPoint${H_tagName}의 <B>$tLname</B>에 명중. <B>$tLname</B>은(는) 괴로운 듯 포효했습니다.",$tId);
}

# 괴수의 시체
sub logMsMonMoney {
	my($tId, $mName, $value) = @_;
	logOut("<B>$mName</B>의 잔해에는 <B>$value$HunitMoney</B>의 값이 매겨졌습니다.",$tId);
}

# 일반 미사일, 일반 지형에 명중
sub logMsNormal {
	my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
	logOut("${HtagName_}${name}섬${H_tagName}이(가) ${HtagName_}${tName}섬$point${H_tagName}지점을 향해 ${HtagComName_}${comName}${H_tagComName}을(를) 실행하여 ${HtagName_}$tPoint${H_tagName}의 <B>$tLname</B>에 명중하여 일대가 괴멸했습니다.",$id, $tId);
}

# 스텔스 미사일, 일반 지형에 명중
sub logMsNormalS {
	my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
	logSecret("${HtagName_}${name}섬${H_tagName}이(가) ${HtagName_}${tName}섬$point${H_tagName}지점을 향해 ${HtagComName_}${comName}${H_tagComName}을(를) 실행하여 ${HtagName_}$tPoint${H_tagName}의 <B>$tLname</B>에 명중하여 일대가 괴멸했습니다.",$id, $tId);
	logLate("<B>누군가</B>이(가) ${HtagName_}${tName}섬$point${H_tagName}지점을 향해 ${HtagComName_}${comName}${H_tagComName}을(를) 실행하여 ${HtagName_}$tPoint${H_tagName}의 <B>$tLname</B>에 명중하여 일대가 괴멸했습니다.",$tId);
}

# 미사일 난민 도착
sub logMsBoatPeople {
	my($id, $name, $achive) = @_;
	logOut("${HtagName_}${name}섬${H_tagName}에 어디선가 <B>$achive${HunitPop}의 난민</B>이 표착했습니다.${HtagName_}${name}섬${H_tagName}은(는) 기꺼이 받아들인 것 같습니다.",$id);
}

# 괴수 파견
sub logMonsSend {
	my($id, $tId, $name, $tName) = @_;
	logOut("${HtagName_}${name}섬${H_tagName}이(가) <B>인조 괴수</B>를 건조했습니다. ${HtagName_}${tName}섬${H_tagName}에 보냈습니다.",$id, $tId);
}

# 자금 조달
sub logDoNothing {
	my($id, $name, $comName) = @_;
#	logOut("${HtagName_}${name}섬${H_tagName}에서${HtagComName_}${comName}${H_tagComName}이(가) 실행되었습니다.",$id);
}

# 이노라진화
sub logGrowUp {
	my($id, $name, $typeName, $inoraName) = @_;
	$typeName = $HmonsterName[$typeName];
	logOut("${HtagName_}${name}섬${H_tagName}의 <b>${inoraName}</b>은(는) ${HtagComName_}${typeName}${H_tagComName}로 진화했습니다!!",$id);
}

# 이노라퇴화
sub logGrowDown {
	my($id, $name, $typeName, $inoraName) = @_;
	$typeName = $HmonsterName[$typeName];
	logOut("${HtagName_}${name}섬${H_tagName}의 <b>${inoraName}</b>은(는) ${HtagComName_}${typeName}${H_tagComName}로 퇴화했습니다?!",$id);
}

# 이노라말하기
sub logSpeak {
	my($id, $name, $mName, $msg) = @_;
	logOut("${HtagName_}${name}섬${H_tagName}:<b>${mName}</b> <FONT SIZE=+1>“${msg}”</FONT>",$id);
}

# 수출
sub logSell {
	my($id, $name, $comName, $value) = @_;
	logOut("${HtagName_}${name}섬${H_tagName}이(가) <B>$value$HunitFood</B>의 ${HtagComName_}${comName}${H_tagComName}을(를) 실행했습니다.",$id);
}

# 원조
sub logAid {
	my($id, $tId, $name, $tName, $comName, $str) = @_;
	logOut("${HtagName_}${name}섬${H_tagName}이(가) ${HtagName_}${tName}섬${H_tagName}에 <B>$str</B>의 ${HtagComName_}${comName}${H_tagComName}을(를) 실행했습니다.",$id, $tId);
}

# 유치 활동
sub logPropaganda {
	my($id, $name, $comName) = @_;
	logOut("${HtagName_}${name}섬${H_tagName}에서${HtagComName_}${comName}${H_tagComName}이(가) 실행되었습니다.",$id);
}

# 포기
sub logGiveup {
	my($id, $name) = @_;
	logOut("${HtagName_}${name}섬${H_tagName}은(는) 포기되어 <B>무인도</B>가 되었습니다.",$id);
	logHistory("${HtagName_}${name}섬${H_tagName}, 포기되어 <B>무인도</B>가 됨.");
}

# 소멸
sub logDead {
	my($id, $name) = @_;
	logOut("${HtagName_}${name}섬${H_tagName}에서 사람이 사라져 <B>무인도</B>가 되었습니다.",$id);
	logHistory("${HtagName_}${name}섬${H_tagName}, 사람이 사라져 <B>무인도</B>가 됨.");
}

# 발견
sub logDiscover {
	my($name) = @_;
	logHistory("${HtagName_}${name}섬${H_tagName}이(가) 발견됨.");
}

# 이름 변경
sub logChangeName {
	my($name1, $name2) = @_;
	logHistory("${HtagName_}${name1}섬${H_tagName}, 명칭을 ${HtagName_}${name2}섬${H_tagName}로 변경함.");
}

# 기아
sub logStarve {
	my($id, $name) = @_;
	logOut("${HtagName_}${name}섬${H_tagName}의 ${HtagDisaster_}식량이 부족${H_tagDisaster}합니다!!",$id);
}

# 괴수 나타남
sub logMonsCome {
	my($id, $name, $mName, $point, $lName) = @_;
	logOut("${HtagName_}${name}섬${H_tagName}에 <B>$mName</B> 출현!!${HtagName_}$point${H_tagName}의 <B>$lName</B>이(가) 짓밟혔습니다.",$id);
}

# 괴수 이동
sub logMonsMove {
	my($id, $name, $lName, $point, $mName) = @_;
	logOut("${HtagName_}${name}섬$point${H_tagName}의 <B>$lName</B>이(가) <B>$mName</B>에게 짓밟혔습니다.",$id);
}

# 괴수, 방위시설을 밟음
sub logMonsMoveDefence {
	my($id, $name, $lName, $point, $mName) = @_;
	logOut("<B>$mName</B>이(가) ${HtagName_}${name}섬$point${H_tagName}의 <B>$lName</B>에 도달, <B>${lName}의 자폭 장치가 작동!!</B>",$id);
}

# 화재
sub logFire {
	my($id, $name, $lName, $point) = @_;
	logOut("${HtagName_}${name}섬$point${H_tagName}의 <B>$lName</B>이(가) ${HtagDisaster_}화재${H_tagDisaster}로 괴멸했습니다.",$id);
}

# 매장금
sub logMaizo {
	my($id, $name, $comName, $value) = @_;
	logOut("${HtagName_}${name}섬${H_tagName}에서의 ${HtagComName_}$comName${H_tagComName} 도중에 <B>$value$HunitMoney의 매장금</B>이 발견되었습니다.",$id);
}

# 지진 발생
sub logEarthquake {
	my($id, $name) = @_;
	logOut("${HtagName_}${name}섬${H_tagName}에서 대규모 ${HtagDisaster_}지진${H_tagDisaster}이 발생!!",$id);
}

# 지진 피해
sub logEQDamage {
	my($id, $name, $lName, $point) = @_;
	logOut("${HtagName_}${name}섬$point${H_tagName}의 <B>$lName</B>은(는) ${HtagDisaster_}지진${H_tagDisaster}으로 괴멸했습니다.",$id);
}

# 식량 부족 피해
sub logSvDamage {
	my($id, $name, $lName, $point) = @_;
	logOut("${HtagName_}${name}섬$point${H_tagName}의 <B>$lName</B>에 <B>식량을 구하려는 주민들이 몰려들었습니다</B>. <B>$lName</B>은(는) 괴멸했습니다.",$id);
}

# 쓰나미 발생
sub logTsunami {
	my($id, $name) = @_;
	logOut("${HtagName_}${name}섬${H_tagName} 부근에서 ${HtagDisaster_}쓰나미${H_tagDisaster} 발생!!",$id);
}

# 쓰나미 피해
sub logTsunamiDamage {
	my($id, $name, $lName, $point) = @_;
	logOut("${HtagName_}${name}섬$point${H_tagName}의 <B>$lName</B>은(는) ${HtagDisaster_}쓰나미${H_tagDisaster}로 붕괴했습니다.",$id);
}

# 태풍 발생
sub logTyphoon {
	my($id, $name) = @_;
	logOut("${HtagName_}${name}섬${H_tagName}에 ${HtagDisaster_}태풍${H_tagDisaster} 상륙!!",$id);
}

# 태풍 피해
sub logTyphoonDamage {
	my($id, $name, $lName, $point) = @_;
	logOut("${HtagName_}${name}섬$point${H_tagName}의 <B>$lName</B>은(는) ${HtagDisaster_}태풍${H_tagDisaster}으로 날아갔습니다.",$id);
}

# 운석, 바다
sub logMeteoSea {
	my($id, $name, $lName, $point) = @_;
	logOut("${HtagName_}${name}섬$point${H_tagName}의 <B>$lName</B>에 ${HtagDisaster_}운석${H_tagDisaster}이 떨어졌습니다.",$id);
}

# 운석, 산
sub logMeteoMountain {
	my($id, $name, $lName, $point) = @_;
	logOut("${HtagName_}${name}섬$point${H_tagName}의 <B>$lName</B>에 ${HtagDisaster_}운석${H_tagDisaster}이 떨어져, <B>$lName</B>은(는) 날아갔습니다.",$id);
}

# 운석, 해저기지
sub logMeteoSbase {
	my($id, $name, $lName, $point) = @_;
	logOut("${HtagName_}${name}섬$point${H_tagName}의 <B>$lName</B>에 ${HtagDisaster_}운석${H_tagDisaster}이 떨어져, <B>$lName</B>은(는) 붕괴했습니다.",$id);
}

# 운석, 괴수에 명중, 피해
sub logMeteoMonster2 {
	my($id, $name, $tLname, $point) = @_;
	logOut("${HtagName_}${name}섬$point${H_tagName}의 <B>$tLname</B>에 ${HtagDisaster_}운석${H_tagDisaster}이 떨어져, <B>$tLname</B>은(는) 괴로운 듯 포효했습니다.",$id);
}

# 운석, 괴수
sub logMeteoMonster {
	my($id, $name, $lName, $point) = @_;
	logOut("<B>$lName</B>이(가) 있던 ${HtagName_}${name}섬$point${H_tagName}지점에 ${HtagDisaster_}운석${H_tagDisaster}이 떨어져, 육지는 <B>$lName</B>째로 수몰되었습니다.",$id);
}

# 운석, 얕은 바다
sub logMeteoSea1 {
	my($id, $name, $lName, $point) = @_;
	logOut("${HtagName_}${name}섬$point${H_tagName}지점에 ${HtagDisaster_}운석${H_tagDisaster}이 떨어져, 해저가 파였습니다.",$id);
}

# 운석, 기타
sub logMeteoNormal {
	my($id, $name, $lName, $point) = @_;
	logOut("${HtagName_}${name}섬$point${H_tagName}지점의 <B>$lName</B>에 ${HtagDisaster_}운석${H_tagDisaster}이 떨어져, 일대가 수몰되었습니다.",$id);
}

# 운석, 기타
sub logHugeMeteo {
	my($id, $name, $point) = @_;
	logOut("${HtagName_}${name}섬$point${H_tagName}지점에 ${HtagDisaster_}거대 운석${H_tagDisaster}이 낙하!!",$id);
}

# 분화
sub logEruption {
	my($id, $name, $lName, $point) = @_;
	logOut("${HtagName_}${name}섬$point${H_tagName}지점에서 ${HtagDisaster_}화산이 분화${H_tagDisaster}하여, <B>산</B>이 생겼습니다.",$id);
}

# 분화, 얕은 바다
sub logEruptionSea1 {
	my($id, $name, $lName, $point) = @_;
	logOut("${HtagName_}${name}섬$point${H_tagName}지점의 <B>$lName</B>은(는) ${HtagDisaster_}분화${H_tagDisaster}의 영향으로 육지가 되었습니다.",$id);
}

# 분화, 바다 또는 해저기지
sub logEruptionSea {
	my($id, $name, $lName, $point) = @_;
	logOut("${HtagName_}${name}섬$point${H_tagName}지점의 <B>$lName</B>은(는) ${HtagDisaster_}분화${H_tagDisaster}의 영향으로 해저가 융기하여 얕은 바다가 되었습니다.",$id);
}

# 분화, 기타
sub logEruptionNormal {
	my($id, $name, $lName, $point) = @_;
	logOut("${HtagName_}${name}섬$point${H_tagName}지점의 <B>$lName</B>은(는) ${HtagDisaster_}분화${H_tagDisaster}의 영향으로 괴멸했습니다.",$id);
}

# 지반 침하 발생
sub logFalldown {
	my($id, $name) = @_;
	logOut("${HtagName_}${name}섬${H_tagName}에서 ${HtagDisaster_}지반 침하${H_tagDisaster}가 발생했습니다!!",$id);
}

# 지반 침하 피해
sub logFalldownLand {
	my($id, $name, $lName, $point) = @_;
	logOut("${HtagName_}${name}섬$point${H_tagName}의 <B>$lName</B>은(는) 바닷속으로 가라앉았습니다.",$id);
}

# 수상
sub logPrize {
	my($id, $name, $pName) = @_;
	logOut("${HtagName_}${name}섬${H_tagName}이(가) <B>$pName</B>을(를) 수상했습니다.",$id);
	logHistory("${HtagName_}${name}섬${H_tagName}, <B>$pName</B>을(를) 수상");
}

# 콘테스트 우승
sub logContest {
	my($id, $name, $pName, $mName) = @_;
	logOut("${HtagName_}${name}섬${H_tagName}의 <b>$mName</b>이(가) <B>$pName</B>에서 우승했습니다.",$id);
	logHistory("${HtagName_}${name}섬${H_tagName}의 <b>$mName</b>이(가) <B>$pName</B>에서 우승");
}

# 이노라수면 중
sub logSleepInora {
	my($id, $name, $mName, $comName) = @_;
	logOut("${HtagName_}${name}섬${H_tagName}에서 예정되어 있던${HtagComName_}$comName${H_tagComName}은(는) <B>$mName</B>이(가) 수면 중이었기 시문에 중지되었습니다.",$id);
}

# 괴수 난동
sub logAngryQuakeMonster {
	my($id, $name, $mName) = @_;
	logOut("${HtagName_}${name}섬${H_tagName}의 <B>$mName</B>이(가) 날뛰기 시작했습니다.",$id);
}

# 괴수 기분 나쁨
sub logAngryMonster {
	my($id, $name, $mName) = @_;
	logOut("${HtagName_}${name}섬${H_tagName}의 <B>$mName</B>은(는) ${HtagComName_}기분이 나쁜${H_tagComName} 모습입니다.",$id);
}

# 괴수 깨어남
sub logWakeUpMonster {
	my($id, $name, $mName) = @_;
	logOut("${HtagName_}${name}섬${H_tagName}의 <B>$mName</B>이(가) 눈을 떴습니다.",$id);
}

# 괴수 잠듦
sub logSleepMonster {
	my($id, $name, $mName) = @_;
	logOut("${HtagName_}${name}섬${H_tagName}의 <B>$mName</B>이(가) 잠들었습니다.",$id);
}

# 괴수 병
sub logSickMonster {
	my($id, $name, $mName, $sick) = @_;
	logOut("${HtagName_}${name}섬${H_tagName}의 <B>$mName</B>이(가) ${HtagDisaster_}$sick${H_tagDisaster}(으)로 앓아누웠습니다!!",$id);
}

# 괴수 회복
sub logGenki {
	my($id, $name, $mName) = @_;
	logOut("${HtagName_}${name}섬${H_tagName}의 <B>$mName</B>은(는) <b>건강</b>해졌습니다.",$id);
}

# 선물
sub logPresent {
	my($id, $name, $log) = @_;
	logHistory("${HtagName_}${name}섬${H_tagName}$log") if ($log ne '');
}

# 섬이 가득 찬 경우
sub tempNewIslandFull {
	out(<<END);
${HtagBig_}죄송합니다. 섬이 가득 차서 등록할 수 없습니다!!${H_tagBig}$HtempBack
END
}

# 신규 생성 시 이름이 없는 경우
sub tempNewIslandNoName {
	my($name) = $_[0];
	out(<<END);
${HtagBig_}${name}에 붙일 이름이 필요합니다.${H_tagBig}$HtempBack
END
}

# 신규 생성 시 이름이 부정확한 경우
sub tempNewIslandBadName {
	out(<<END);
${HtagBig_}',?()<>\$' 등이 들어가 있거나, '무인도' 같은 이상한 이름은 사용하지 말아 주세요~${H_tagBig}$HtempBack
END
}

# 이미 그 이름의 섬이 있는 경우
sub tempNewIslandAlready {
	out(<<END);
${HtagBig_}그 섬은 이미 발견되어 있습니다.${H_tagBig}$HtempBack
END
}

# 패스워드가 없는 경우
sub tempNewIslandNoPassword {
	out(<<END);
${HtagBig_}패스워드가 필요합니다.${H_tagBig}$HtempBack
END
}

# 섬을 발견했습니다!!
sub tempNewIslandHead {
	out(<<END);
<SCRIPT LANGUAGE="JavaScript">
<!--
function ShowMsg(n) {
		window.status = n;
}
//-->
</SCRIPT>
<CENTER>
${HtagBig_}섬을 발견했습니다!!${H_tagBig}<BR>
${HtagBig_}${HtagName_}“${HcurrentName}섬”${H_tagName}라고 명명합니다.${H_tagBig}<BR>
$HtempBack<BR>
</CENTER>
END
}

# 지형의 호칭
sub landName {
	my($land, $lv) = @_;
	if($land == $HlandSea) {
		if($lv == 1) {
			return '바다(얕은 바다)';
		} else {
			return '바다';
		}
	} elsif($land == $HlandWaste) {
		return '황무지';
	} elsif($land == $HlandPlains) {
		return '평지';
	} elsif($land == $HlandTown) {
		if($lv < 30) {
			return '촌락';
		} elsif($lv < 100) {
			return '마을';
		} else {
			return '도시';
		}
	} elsif($land == $HlandForest) {
		return '숲';
	} elsif($land == $HlandFarm) {
		return '농장';
	} elsif($land == $HlandFactory) {
		return '공장';
	} elsif($land == $HlandBase) {
		return '미사일 기지';
	} elsif($land == $HlandDefence) {
		return '방위시설';
	} elsif($land == $HlandMountain) {
		return '산';
	} elsif($land == $HlandMonster) {
		my($kind, $name, $hp) = monsterSpec($lv);
		$name = "이노라" if($kind >= 4);
		return $name;
	} elsif($land == $HlandSbase) {
		return '해저기지';
	} elsif($land == $HlandOil) {
		return '해저유전';
	} elsif($land == $HlandMonument) {
		return $HmonumentName[$lv];
	} elsif($land == $HlandHaribote) {
		return '허수아비';
	}
}

# 인구 및 기타 값을 산출
sub estimate {
	my($number) = $_[0];
	my($island);
	my($pop, $area, $farm, $factory, $mountain, $burnmis) = (0, 0, 0, 0, 0, 0, 0);

	# 지형을 가져옴
	$island = $Hislands[$number];
	my($land) = $island->{'land'};
	my($landValue) = $island->{'landValue'};

	# 셈
	my($x, $y, $kind, $value);
	for($y = 0; $y < $HislandSize; $y++) {
		for($x = 0; $x < $HislandSize; $x++) {
			$kind = $land->[$x][$y];
			$value = $landValue->[$x][$y];
			if(($kind != $HlandSea) &&
			   ($kind != $HlandSbase) &&
			   ($kind != $HlandOil)){
				$area++;
				if($kind == $HlandTown) {
					# 마을
					$pop += $value;
				} elsif($kind == $HlandFarm) {
					# 농장
					$farm += $value;
				} elsif($kind == $HlandFactory) {
					# 공장
					$factory += $value;
				} elsif($kind == $HlandMountain) {
					# 산
					$mountain += $value;
				} elsif($kind == $HlandBase) {
					# 미사일 기지
					$burnmis += expToLevel($kind, $value);
				}
			}elsif($kind == $HlandSbase) {
				# 해저기지
				$burnmis += expToLevel($kind, $value);
			}
		}
	}

	# 대입
	$island->{'pop'}	  = $pop;
	$island->{'area'}	 = $area;
	$island->{'farm'}	 = $farm;
	$island->{'factory'}  = $factory;
	$island->{'mountain'} = $mountain;
	$island->{'fire'}	 = $burnmis;
}


# 범위 안의 지형을 셈
sub countAround {
	my($land, $x, $y, $kind, $range) = @_;
	my($i, $count, $sx, $sy);
	$count = 0;
	for($i = 0; $i < $range; $i++) {
		 $sx = $x + $ax[$i];
		 $sy = $y + $ay[$i];

		 # 행에 따른 위치 보정
		 if((($sy % 2) == 0) && (($y % 2) == 1)) {
			 $sx--;
		 }

		 if(($sx < 0) || ($sx >= $HislandSize) ||
			($sy < 0) || ($sy >= $HislandSize)) {
			 # 범위 밖인 경우
			 if($kind == $HlandSea) {
				 # 바다면 가산
				 $count++;
			 }
		 } else {
			 # 범위 안인 경우
			 if($land->[$sx][$sy] == $kind) {
				 $count++;
			 }
		 }
	}
	return $count;
}

# 0부터 (n - 1)까지의 숫자가 한 번씩 나오는 수열을 만든다
sub randomArray {
	my($n) = @_;
	my(@list, $i);

	# 초기값
	if($n == 0) {
		$n = 1;
	}
	@list = (0..$n-1);

	# 셔플
	for ($i = $n; --$i; ) {
		my($j) = int(rand($i+1));
		if($i == $j) { next; };
		@list[$i,$j] = @list[$j,$i];
	}

	return @list;
}

# 이름 변경 실패
sub tempChangeNothing {
	out(<<END);
${HtagBig_}이름과 패스워드가 모두 비어 있습니다${H_tagBig}$HtempBack
END
}

# 이름 변경 자금 부족
sub tempChangeNoMoney {
	out(<<END);
${HtagBig_}자금 부족으로 변경할 수 없습니다${H_tagBig}$HtempBack
END
}

# 이름 변경 성공
sub tempChange {
	out(<<END);
${HtagBig_}변경 완료했습니다${H_tagBig}$HtempBack
END
}

1;
