use utf8;
#----------------------------------------------------------------------
# 箱庭諸島 ver2.30
# 지도 모드 모듈
# 사용 조건, 사용 방법 등은 hako-readme.txt 파일을 참조
#
# 箱庭諸島 페이지: http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html
#----------------------------------------------------------------------
# 이노라 제도
#----------------------------------------------------------------------

#----------------------------------------------------------------------
# 관광 모드
#----------------------------------------------------------------------
# 메인
sub printIslandMain {
	# 개방
	unlock();

	# id에서 섬 번호 취득
	$HcurrentNumber = $HidToNumber{$HcurrentID};

	# 어째서인지 해당 섬이 없는 경우
	if($HcurrentNumber eq '') {
		tempProblem();
		return;
	}

	# 이름 취득
	$HcurrentName = $Hislands[$HcurrentNumber]->{'name'};

	# 관광 화면
	tempPrintIslandHead(); # 어서 오세요!!
	islandInfo(); # 섬 정보
	islandMap(0); # 섬 지도, 관광 모드

	# ○○섬 로컬 게시판
	if($HuseLbbs) {
		tempLbbsHead();	 # 로컬 게시판
		tempLbbsInput();   # 작성 폼
		tempLbbsContents(); # 게시판 내용
	}

	# 근황
	tempRecent(0);
}

#----------------------------------------------------------------------
# 개발 모드
#----------------------------------------------------------------------
# 메인
sub ownerMain {
	# 개방
	unlock();

	# 모드 명시
	$HmainMode = 'owner';

	# id에서 섬 취득
	$HcurrentNumber = $HidToNumber{$HcurrentID};
	my($island) = $Hislands[$HcurrentNumber];
	$HcurrentName = $island->{'name'};

	# 비밀번호
	if(!checkPassword($island->{'password'},$HinputPassword)) {
		# 비밀번호 틀림
		tempWrongPassword();
		return;
	}

	# 개발 화면
	if($HjavaMode eq 'java') {
		tempOwnerJava(); # Java 스크립트 개발 계획
	}else{			   # 일반 모드 개발 계획
		tempOwner();
	}

	# ○○섬 로컬 게시판
	if($HuseLbbs) {
		# 로컬 게시판
		tempLbbsHead();
		if($HjavaMode eq 'java') {
			# Java 스크립트용 작성 폼
			tempLbbsInputJava();
		}else{
			# 로컬 게시판
			tempLbbsInputOW();
		}
		tempLbbsContents(); # 게시판 내용
	}

	# 근황
	tempRecent(1);
}

#----------------------------------------------------------------------
# 명령 모드
#----------------------------------------------------------------------
# 메인
sub commandMain {
	# id에서 섬 취득
	$HcurrentNumber = $HidToNumber{$HcurrentID};
	my($island) = $Hislands[$HcurrentNumber];
	$HcurrentName = $island->{'name'};

	# 비밀번호
	if(!checkPassword($island->{'password'},$HinputPassword)) {
		# 비밀번호 틀림
		unlock();
		tempWrongPassword();
		return;
	}

	# 모드로 분기
	my($command) = $island->{'command'};

	if($HcommandMode eq 'delete') {
		slideFront($command, $HcommandPlanNumber);
		tempCommandDelete();
	} elsif(($HcommandKind == $HcomAutoPrepare) ||
			($HcommandKind == $HcomAutoPrepare2)) {
		# 전체 개간, 전체 땅 고르기
		# 좌표 배열 작성
		makeRandomPointArray();
		my($land) = $island->{'land'};

		# 명령 종류 결정
		my($kind) = $HcomPrepare;
		if($HcommandKind == $HcomAutoPrepare2) {
			$kind = $HcomPrepare2;
		}

		my($i) = 0;
		my($j) = 0;
		while(($j < $HpointNumber) && ($i < $HcommandMax)) {
			my($x) = $Hrpx[$j];
			my($y) = $Hrpy[$j];
			if($land->[$x][$y] == $HlandWaste) {
				slideBack($command, $HcommandPlanNumber);
				$command->[$HcommandPlanNumber] = {
					'kind' => $kind,
					'target' => 0,
					'x' => $x,
					'y' => $y,
					'arg' => 0
					};
				$i++;
			}
			$j++;
		}
		tempCommandAdd();
	} elsif($HcommandKind == $HcomAutoDelete) {
		# 전체 삭제
		my($i);
		for($i = 0; $i < $HcommandMax; $i++) {
			slideFront($command, $HcommandPlanNumber);
		}
		tempCommandDelete();
	} else {
		if($HcommandMode eq 'insert') {
			slideBack($command, $HcommandPlanNumber);
		}
		tempCommandAdd();

		# 명령 등록
		$command->[$HcommandPlanNumber] = {
			'kind' => $HcommandKind,
			'target' => $HcommandTarget,
			'x' => $HcommandX,
			'y' => $HcommandY,
			'arg' => $HcommandArg
			};
	}

	# 데이터 쓰기
	writeIslandsFile($HcurrentID);

	# owner mode로
	ownerMain();

}

#----------------------------------------------------------------------
# 댓글 입력 모드
#----------------------------------------------------------------------
# 메인
sub commentMain {
	# id에서 섬 취득
	$HcurrentNumber = $HidToNumber{$HcurrentID};
	my($island) = $Hislands[$HcurrentNumber];
	$HcurrentName = $island->{'name'};

	# 비밀번호
	if(!checkPassword($island->{'password'},$HinputPassword)) {
		# 비밀번호 틀림
		unlock();
		tempWrongPassword();
		return;
	}

	# 메시지 갱신
	$island->{'comment'} = htmlEscape($Hmessage);

	# 데이터 쓰기
	writeIslandsFile($HcurrentID);

	# 댓글 갱신 메시지
	tempComment();

	# owner mode로
	ownerMain();
}

#----------------------------------------------------------------------
# 로컬 게시판 모드
#----------------------------------------------------------------------
# 메인

sub localBbsMain {
	# id에서 섬 번호 취득
	$HcurrentNumber = $HidToNumber{$HcurrentID};
	my($island) = $Hislands[$HcurrentNumber];
	my($foreignName);

	# 어째서인지 해당 섬이 없는 경우
	if($HcurrentNumber eq '' && $HcurrentID != 0) {
		unlock();
		tempProblem();
		return;
	}

	# 삭제 모드가 아니고 이름 또는 메시지가 없는 경우
	if($HlbbsMode != 2) {
		if(($HlbbsName eq '') || ($HlbbsMessage eq '')) {
			unlock();
			tempLbbsNoMessage();
			return;
		}
	}

   # 섬 없는 관광객 이외는 비밀번호 체크
		if($HlbbsMode == 0 && $HforID != 0) {
			# 외국인 모드
			my($foreignNumber) = $HidToNumber{$HforID};
			if($foreignNumber eq ''){
				unlock();
				tempProblem();
				return;
			}
			my($fIsland) = $Hislands[$foreignNumber];
			if(!checkPassword($fIsland->{'password'},$HinputPassword)) {
				unlock();
				tempWrongPassword();
				return;
			}
			$foreignName = $fIsland->{'name'};
		} elsif($HlbbsMode) {
			# 섬 주인 모드
			if(!checkPassword($island->{'password'},$HinputPassword)) {
				# 비밀번호 틀림
				unlock();
				tempWrongPassword();
				return;
			}
		}

	my($lbbs);
	$lbbs = $island->{'lbbs'};

	# 모드로 분기
	if($HlbbsMode == 2) {
		# 삭제 모드
		# 메시지를 앞으로 당김
		slideBackLbbsMessage($lbbs, $HcommandPlanNumber);
		tempLbbsDelete();
	} else {
		# 기록 모드
		# 메시지를 뒤로 밀기
		slideLbbsMessage($lbbs);

		if($HforID == 0 and $HlbbsMode == 0){
			$HlbbsMessage = htmlEscape($HlbbsMessage);
			$message = '3';
		} elsif (($HlbbsMode == 0) && ($HforID != $island->{'id'})){
			$HlbbsMessage = htmlEscape($HlbbsMessage) . "　　<font size=-1 color=gray>(${foreignName}섬)</font>";
			$message = '0';
		} else {
			$HlbbsMessage = htmlEscape($HlbbsMessage);
			$message = '1';
		}
		$HlbbsName = "$HislandTurn：" . htmlEscape($HlbbsName);
		$lbbs->[0] = "$message>$HlbbsName>$HlbbsMessage";

		tempLbbsAdd();
	}

	# 데이터 쓰기
	writeIslandsFile($HcurrentID);

	# 원래 모드로
	if($HlbbsMode == 0) {
		printIslandMain();
	} else {
		ownerMain();
	}
}

# 로컬 게시판 메시지를 하나 뒤로 밀기
sub slideLbbsMessage {
	my($lbbs) = @_;
	my($i);
	pop(@$lbbs);
	unshift(@$lbbs, $lbbs->[0]);
}

# 로컬 게시판 메시지를 하나 앞으로 당기기
sub slideBackLbbsMessage {
	my($lbbs, $number) = @_;
	my($i);
	splice(@$lbbs, $number, 1);
	$lbbs->[$HlbbsMax - 1] = '0>>';
}

#----------------------------------------------------------------------
# 섬 지도
#----------------------------------------------------------------------

# 정보 표시
sub islandInfo {
	my($island) = $Hislands[$HcurrentNumber];

	# 정보 표시
	my($rank) = $HcurrentNumber + 1;
	my($farm) = $island->{'farm'};
	my($factory) = $island->{'factory'};
	my($mountain) = $island->{'mountain'};
	$farm = ($farm == 0) ? "보유하지 않음" : "${farm}0$HunitPop";
	$factory = ($factory == 0) ? "보유하지 않음" : "${factory}0$HunitPop";
	$mountain = ($mountain == 0) ? "보유하지 않음" : "${mountain}0$HunitPop";

	my($mStr1) = '';
	my($mStr2) = '';
	if(($HhideMoneyMode == 1) || ($HmainMode eq 'owner')) {
		# 무조건 또는 owner 모드
		$mStr1 = "<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}자금${H_tagTH}</NOBR></TH>";
		$mStr2 = "<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$island->{'money'}$HunitMoney</NOBR></TD>";
	} elsif($HhideMoneyMode == 2) {
		my($mTmp) = aboutMoney($island->{'money'});

		# 1000억 단위 모드
		$mStr1 = "<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}자금${H_tagTH}</NOBR></TH>";
		$mStr2 = "<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$mTmp</NOBR></TD>";
	}
	my($comname) ="${HtagTH_}댓글：${H_tagTH}";
	if(($island->{'ownername'} ne '0') && ($island->{'ownername'} ne "댓글")){
		$comname = "<FONT COLOR=\"blue\"><B>$island->{'ownername'}：</b></font>";
	}

	my $i_hp   = int($island->{'i_hp'} / 1000);
	my $i_arm  = int($island->{'i_arm'} / 1000);
	my $i_int  = int($island->{'i_int'} / 1000);
	my $i_cute = int($island->{'i_cute'} / 1000);
	$i_hp = 1 if($i_hp < 1);
	$i_arm = 0 if($i_arm < 1);
	$i_int = 0 if($i_int < 1);
	$i_cute = 0 if($i_cute < 1);

	# 시간 표시
	my($hour, $min, $sec);
	my($now) = time;
	my($showTIME) = ($HislandLastTime + $HunitTime - $now);
	$hour = int($showTIME / 3600);
	$min  = int(($showTIME - ($hour * 3600)) / 60);
	$sec  = $showTIME - ($hour * 3600) - ($min * 60);

	out(<<END);
<CENTER>
<BR><B><font size=+1>턴 $HislandTurn</font></b>（남은 시간, $hour시간 $min분 $sec초）
<TABLE BORDER CELLSPACING=1>
<TR>
<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}순위${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}인구${H_tagTH}</NOBR></TH>
$mStr1
<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}식량${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}면적${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}농장 규모${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}공장 규모${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}채굴장 규모${H_tagTH}</NOBR></TH>
</TR>
<TR>
<TD $HbgNumberCell align=middle nowrap=nowrap><NOBR>${HtagNumber_}$rank${H_tagNumber}</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$island->{'pop'}$HunitPop</NOBR></TD>
$mStr2
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$island->{'food'}$HunitFood</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$island->{'area'}$HunitArea</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>${farm}</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>${factory}</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>${mountain}</NOBR></TD>
</TR>
<TR>
<TD $HbgCommentCell COLSPAN=8 align=center nowrap=nowrap><NOBR>$comname$island->{'comment'}</NOBR></TD>
</TR>
</TABLE>
<TABLE BORDER CELLSPACING=1>
<TR>
<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}이름${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}종류${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}생일${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}체력${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}완력${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}매력${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}지력${H_tagTH}</NOBR></TH>
</TR>
<TR>
<TD $HbgInfoCell ALIGN=CENTER nowrap=nowrap><NOBR>$island->{'i_name'}</NOBR></TD>
<TD $HbgInfoCell ALIGN=CENTER nowrap=nowrap><NOBR>$HmonsterName[$island->{'i_type'}]</NOBR></TD>
<TD $HbgInfoCell ALIGN=right nowrap=nowrap><NOBR>턴 $island->{'i_age'}</NOBR></TD>
<TD $HbgInfoCell ALIGN=right nowrap=nowrap><NOBR>$i_hp</NOBR></TD>
<TD $HbgInfoCell ALIGN=right nowrap=nowrap><NOBR>$i_arm</NOBR></TD>
<TD $HbgInfoCell ALIGN=right nowrap=nowrap><NOBR>$i_cute</NOBR></TD>
<TD $HbgInfoCell ALIGN=right nowrap=nowrap><NOBR>$i_int</NOBR></TD>
</TR>
END

	if($HinputPassword eq $masterPassword) {
		out(<<END);
<TR>
<TD $HbgInfoCell ALIGN=CENTER nowrap=nowrap><NOBR>기분 $island->{'i_ang'}</NOBR></TD>
<TD $HbgInfoCell ALIGN=right nowrap=nowrap><NOBR>건강 $island->{'i_heal'}</NOBR></TD>
<TD $HbgInfoCell ALIGN=CENTER nowrap=nowrap><NOBR>수면 $island->{'i_sleep'}</NOBR></TD>
<TD $HbgInfoCell ALIGN=right nowrap=nowrap><NOBR>$island->{'i_hp'}</NOBR></TD>
<TD $HbgInfoCell ALIGN=right nowrap=nowrap><NOBR>$island->{'i_arm'}</NOBR></TD>
<TD $HbgInfoCell ALIGN=right nowrap=nowrap><NOBR>$island->{'i_cute'}</NOBR></TD>
<TD $HbgInfoCell ALIGN=right nowrap=nowrap><NOBR>$island->{'i_int'}</NOBR></TD>
</TR>
END
	}
	out("</TABLE>\n</CENTER>\n");
}

# 지도 표시
# 인수가 1이면 미사일 기지 등을 그대로 표시
sub islandMap {
	my($mode) = @_;
	my($island);
	$island = $Hislands[$HcurrentNumber];

	out(<<END);
<CENTER><TABLE BORDER CELLSPACING=0><TR><TD>
END

	# 지형, 지형값 취득
	my($land) = $island->{'land'};
	my($landValue) = $island->{'landValue'};
	my($l, $lv);

	# 명령 취득
	my($command) = $island->{'command'};
	my($com, @comStr, $i);
	if($HmainMode eq 'owner') {
		for($i = 0; $i < $HcommandMax; $i++) {
			my($j) = $i + 1;
			$com = $command->[$i];
			if($com->{'kind'} < 34) {
				$comStr[$com->{'x'}][$com->{'y'}] .=
					" [${j}]$HcomName[$com->{'kind'}]";
			}
		}
	}

	# 좌표 위쪽 출력
	out("<IMG SRC=\"xbar.png\" width=400 height=16><BR>");

	# 각 지형 및 줄바꿈 출력
	my($x, $y);
	for($y = 0; $y < $HislandSize; $y++) {
		# 짝수 줄이면 번호 출력
		if(($y % 2) == 0) {
			out("<IMG SRC=\"space${y}.gif\" width=16 height=32>");
		}

		# 각 지형 출력
		for($x = 0; $x < $HislandSize; $x++) {
			$l = $land->[$x][$y];
			$lv = $landValue->[$x][$y];
			landString($l, $lv, $x, $y, $mode, $comStr[$x][$y], 0, $island);
		}

		# 홀수 줄이면 번호 출력
		if(($y % 2) == 1) {
			out("<IMG SRC=\"space${y}.gif\" width=16 height=32>");
		}

		# 줄바꿈 출력
		out("<BR>");
	}
	out("</TD></TR></TABLE></CENTER>\n");
}

sub landString {
	my($l, $lv, $x, $y, $mode, $comStr, $ikkatu, $island) = @_;
	my($point) = "($x,$y)";
	my($image, $alt);

	if($l == $HlandSea) {

		if($lv == 1) {
			# 얕은 바다
			$image = 'land14.png';
			$alt = '바다(얕은 바다)';
		} else {
			# 바다
			$image = 'land0.png';
			$alt = '바다';
		}
	} elsif($l == $HlandWaste) {
		# 황무지
		if($lv == 1) {
			$image = 'land13.png'; # 착탄 지점
			$alt = '황무지';
		} else {
			$image = 'land1.png';
			$alt = '황무지';
		}
	} elsif($l == $HlandPlains) {
		# 평지
		$image = 'land2.png';
		$alt = '평지';
	} elsif($l == $HlandForest) {
		# 숲
		if($mode == 1) {
			$image = 'land6.png';
			$alt = "숲(${lv}$HunitTree)";
		} else {
			# 관광객의 경우 나무 수를 숨김
			$image = 'land6.png';
			$alt = '숲';
		}
	} elsif($l == $HlandTown) {
		# 마을
		my($p, $n);
		if($lv < 30) {
			$p = 3;
			$n = '마을';
		} elsif($lv < 100) {
			$p = 4;
			$n = '마을';
		} else {
			$p = 5;
			$n = '도시';
		}

		$image = "land${p}.png";
		$alt = "$n(${lv}$HunitPop)";
	} elsif($l == $HlandFarm) {
		# 농장
		$image = 'land7.png';
		$alt = "농장(${lv}0${HunitPop} 규모)";
	} elsif($l == $HlandFactory) {
		# 공장
		$image = 'land8.png';
		$alt = "공장(${lv}0${HunitPop} 규모)";
	} elsif($l == $HlandBase) {
		# 미사일 기지
		my($level) = expToLevel($l, $lv);
		$image = 'land9.png';
		$alt = "미사일 기지 (레벨 ${level}/경험치 $lv)";
	} elsif($l == $HlandSbase) {
		# 해저 기지
		my($level) = expToLevel($l, $lv);
		$image = 'land12.png';
		$alt = "해저 기지 (레벨 ${level}/경험치 $lv)";
	} elsif($l == $HlandDefence) {
		# 방위 시설
		$image = 'land10.png';
		$alt = '방위 시설';
	} elsif($l == $HlandHaribote) {
		# 허수 시설
		$image = 'land10.png';
		if($mode == 0) {
			# 관광객의 경우 방위 시설인 척
			$alt = '방위 시설';
		} else {
			$alt = '허수 시설';
		}
	} elsif($l == $HlandOil) {
		# 해저 유전
		$image = 'land16.png';
		$alt = '해저 유전';
	} elsif($l == $HlandMountain) {
		# 산
		my($str);
		$str = '';
		if($lv > 0) {
			$image = 'land15.png';
			$alt = "산(채굴장 ${lv}0${HunitPop} 규모)";
		} else {
			$image = 'land11.png';
			$alt = '산';
		}
	} elsif($l == $HlandMonument) {
		# 기념비
		$image = $HmonumentImage[$lv];
		$alt = $HmonumentName[$lv];
	} elsif($l == $HlandMonster) {
		# 괴수
		my($kind, $name, $hp) = monsterSpec($lv);
		my($special) = $HmonsterSpecial[$kind];
		if($kind < 4) {
			$image = $HmonsterImage[$kind];

			# 경화 중?
			if((($special == 3) && (($HislandTurn % 2) == 1)) ||
			   (($special == 4) && (($HislandTurn % 2) == 0))) {
				# 경화 중
				$image = $HmonsterImage2[$kind];
			}
			$alt = "$name(체력 ${hp})";
		} else {
			$image = $HmonsterImage[$island->{'i_type'}];
			$image2 = $image;
			$image = "an_".$image2 if($island->{'i_ang'} < 1000);
			$image = "sl_".$image2 if($island->{'i_sleep'} > 100);
			$island->{'i_name'} .= "(질병)" if($island->{'i_sleep'} > 200);
			$alt = $island->{'i_name'};
		}
	}

	# 개발 화면의 경우 좌표 설정
	out(qq#<A HREF="JavaScript:void(0);" #);
	if($ikkatu and $mode) {
		# JS 일괄 화면용 오너
		out(qq#onclick="ps($x,$y)" #);
		out(qq#onMouseOver="set_com($x, $y, '$point $alt');return true;">#);
		$comStr = "";
	}elsif($mode) {
		out("onclick=\"ps($x,$y)\" onMouseOver=\"ShowMsg('$point $alt $comStr'); return true;\">");
	} else {
		out("onMouseOver=\"ShowMsg('$point $alt $comStr'); return true;\">");
	}

	out("<IMG SRC=\"$image\" TITLE=\"$point $alt $comStr\" ALT=\"$point $alt $comStr\" width=32 height=32 BORDER=0></A>");

}


#----------------------------------------------------------------------
# 템플릿 기타
#----------------------------------------------------------------------

# 개별 로그 표시
sub logPrintLocal {
	my($mode) = @_;
	my($i);
	for($i = 0; $i < $HlogMax; $i++) {
		logFilePrint($i, $HcurrentID, $mode, 1);
	}
}

# ○○섬에 오신 것을 환영합니다!!
sub tempPrintIslandHead {
	out(<<END);
<CENTER>
${HtagBig_}${HtagName_}「${HcurrentName}섬」${H_tagName}에 오신 것을 환영합니다!!${H_tagBig}<BR>
$HtempBack<BR>
</CENTER>
<SCRIPT Language="JavaScript">
<!--
function ShowMsg(n){
		window.status = n;
}
//-->
</SCRIPT>
END
}

# ○○섬 개발 계획
sub tempOwner {
    # 명령 목록 세트
	my($l_kind);
	$set_listcom = "";
	$All_listCom = 0;
	$com_count = @HcommandDivido;
	for($m = 0; $m < $com_count; $m++) {
		($aa,$dd,$ff) = split(/,/,$HcommandDivido[$m]);
		$set_listcom .= "\[ ";
	    for($i = 0; $i < $HcommandTotal; $i++) {
			$l_kind = $HcomList[$i];
			$l_cost = $HcomCost[$l_kind];
			if($l_cost == 0) { $l_cost = '무료'	}
			elsif($l_cost < 0) { $l_cost = - $l_cost; $l_cost .= $HunitFood; }
			else { $l_cost .= $HunitMoney; }
			if($l_kind > $dd-1 && $l_kind < $ff+1) {
				$set_listcom .= "\[$l_kind\,\'$HcomName[$l_kind]\',\'$l_cost\'\]\,\n";
				$All_listCom++;
			}
			if($l_kind < $ff+1) { next; }
		}
		$bai = length($set_listcom);
		$set_listcom = substr($set_listcom, 0,$bai-2);
		$set_listcom .= " \],\n";
	}
	$bai = length($set_listcom);
	$set_listcom = substr($set_listcom, 0,$bai-2);
	if($HdefaultKind eq ''){ $default_Kind = 1;}
	else{ $default_Kind = $HdefaultKind; }

	out(<<END);
<CENTER>
${HtagBig_}${HtagName_}${HcurrentName}섬${H_tagName} 개발 계획${HtagBig}<BR>
$HtempBack<BR>
</CENTER>
<SCRIPT Language="JavaScript">
<!--
comlist = [
$set_listcom];

function ps(x, y) {
	document.forms[0].elements[5].options[x].selected = true;
	document.forms[0].elements[6].options[y].selected = true;
	return true;
}

function ns(x) {
	document.forms[0].elements[2].options[x].selected = true;
	return true;
}
function ShowMsg(n){
		window.status = n;
}

function SelectList(theForm){
	var u, selected_ok;
	if(!theForm){s = ''}
	else { s = theForm.menu.options[theForm.menu.selectedIndex].value; }
	if(s == ''){
		u = 0; selected_ok = 0;
		document.my_form.COMMAND.options.length = $All_listCom;
		for (i=0; i<comlist.length; i++) {
			var command = comlist[i];
			for (a=0; a<command.length; a++) {
				comName = command[a][1] + "(" + command[a][2] + ")";
				document.my_form.COMMAND.options[u].value = command[a][0];
				document.my_form.COMMAND.options[u].text = comName;
				if(command[a][0] == $default_Kind){
					document.my_form.COMMAND.options[u].selected = true;
					selected_ok = 1;
				}
				u++;
			}
		}
		if(selected_ok == 0)
		document.my_form.COMMAND.selectedIndex = 0;
	} else {
		var command = comlist[s];
		document.my_form.COMMAND.options.length = command.length;
		for (i=0; i<command.length; i++) {
			comName = command[i][1] + "(" + command[i][2] + ")";
			document.my_form.COMMAND.options[i].value = command[i][0];
			document.my_form.COMMAND.options[i].text = comName;
			if(command[i][0] == $default_Kind){
				document.my_form.COMMAND.options[i].selected = true;
				selected_ok = 1;
			}
		}
		if(selected_ok == 0)
		document.my_form.COMMAND.selectedIndex = 0;
	}
}


//-->
</SCRIPT>
END

	islandInfo();

	out(<<END);
<CENTER>
<TABLE BORDER CELLSPACING=0>
<TR>
<TD $HbgInputCell WIDTH=200>
<CENTER>
<FORM action="$HthisFile" method=POST NAME="my_form">
<INPUT TYPE=submit VALUE="계획 전송" NAME=CommandButton$Hislands[$HcurrentNumber]->{'id'}>
<HR>
<B>비밀번호</B></BR>
<INPUT TYPE=password NAME=PASSWORD VALUE="$HdefaultPassword">
<HR>
<B>계획 번호</B><SELECT NAME=NUMBER>
END
	# 계획 번호
	my($j, $i);
	for($i = 0; $i < $HcommandMax; $i++) {
		$j = $i + 1;
		out("<OPTION VALUE=$i>$j\n");
	}

	out(<<END);
</SELECT><BR>
<HR>
<B>개발 계획：</B>
<SELECT NAME=menu onchange="SelectList(my_form)">
<OPTION VALUE=>전체 종류
END
	for($i = 0; $i < $com_count; $i++) {
		($aa) = split(/,/,$HcommandDivido[$i]);
		out("<OPTION VALUE=$i>$aa\n");
	}
    out(<<END);
</SELECT><br>
<SELECT NAME=COMMAND>
END

	# 명령
	my($kind, $cost, $s);
	for($i = 0; $i < $HcommandTotal; $i++) {
		$kind = $HcomList[$i];
		$cost = $HcomCost[$kind];
		if($cost == 0) {
			$cost = '무료'
		} elsif($cost < 0) {
			$cost = - $cost;
			$cost .= $HunitFood;
		} else {
			$cost .= $HunitMoney;
		}
		if($kind == $HdefaultKind) {
			$s = 'SELECTED';
		} else {
			$s = '';
		}
		out("<OPTION VALUE=$kind $s>$HcomName[$kind]($cost)\n");
	}

	out(<<END);
</SELECT>
<HR>
<B>좌표(</B>
<SELECT NAME=POINTX>

END
	for($i = 0; $i < $HislandSize; $i++) {
		if($i == $HdefaultX) {
			out("<OPTION VALUE=$i SELECTED>$i\n");
		} else {
			out("<OPTION VALUE=$i>$i\n");
		}
	}

	out(<<END);
</SELECT>, <SELECT NAME=POINTY>
END

	for($i = 0; $i < $HislandSize; $i++) {
		if($i == $HdefaultY) {
			out("<OPTION VALUE=$i SELECTED>$i\n");
		} else {
			out("<OPTION VALUE=$i>$i\n");
		}
	}
	out(<<END);
</SELECT><B>)</B>
<HR>
<B>수량</B><SELECT NAME=AMOUNT>
END

	# 수량
	for($i = 0; $i < 100; $i++) {
		out("<OPTION VALUE=$i>$i\n");
	}

	out(<<END);
</SELECT>
<HR>
<B>목표 섬</B><BR>
<SELECT NAME=TARGETID>
$HislandList<BR>
</SELECT>
<HR>
<B>동작</B><BR>
<INPUT TYPE=radio NAME=COMMANDMODE VALUE=insert CHECKED>삽입
<INPUT TYPE=radio NAME=COMMANDMODE VALUE=write>덮어쓰기<BR>
<INPUT TYPE=radio NAME=COMMANDMODE VALUE=delete>삭제
<HR>
<INPUT TYPE=submit VALUE="계획 전송" NAME=CommandButton$Hislands[$HcurrentNumber]->{'id'}>

</CENTER>
</FORM>
<nobr><center>미사일 발사 상한 수 [<b> $Hislands[$HcurrentNumber]->{'fire'} </b>]발</center></nobr>
</TD>
<TD $HbgMapCell>
END
	islandMap(1);	# 섬 지도, 소유자 모드
	out(<<END);
</TD>
<TD $HbgCommandCell>
END
	for($i = 0; $i < $HcommandMax; $i++) {
		tempCommand($i, $Hislands[$HcurrentNumber]->{'command'}->[$i]);
	}

	out(<<END);

</TD>
</TR>
</TABLE>
</CENTER>
<HR>
<CENTER>
${HtagBig_}댓글 갱신${H_tagBig}<BR>
<FORM action="$HthisFile" method="POST">
댓글<INPUT TYPE=text NAME=MESSAGE SIZE=80><BR>
비밀번호<INPUT TYPE=password NAME=PASSWORD VALUE="$HdefaultPassword">
<INPUT TYPE=submit VALUE="댓글 갱신" NAME=MessageButton$Hislands[$HcurrentNumber]->{'id'}>
</FORM>
</CENTER>
END

}

# 입력 완료된 명령 표시
sub tempCommand {
	my($number, $command) = @_;
	my($kind, $target, $x, $y, $arg) =
		(
		 $command->{'kind'},
		 $command->{'target'},
		 $command->{'x'},
		 $command->{'y'},
		 $command->{'arg'}
		 );
	my($name) = "$HtagComName_${HcomName[$kind]}$H_tagComName";
	my($point) = "$HtagName_($x,$y)$H_tagName";
	$target = $HidToName{$target};
	if($target eq '') {
		$target = "무인";
	}
	$target = "$HtagName_${target}섬$H_tagName";
	my($value) = $arg * $HcomCost[$kind];
	if($value == 0) {
		$value = $HcomCost[$kind];
	}
	if($value < 0) {
		$value = -$value;
		$value = "$value$HunitFood";
	} else {
		$value = "$value$HunitMoney";
	}
	$value = "$HtagName_$value$H_tagName";

	my($j) = sprintf("%02d：", $number + 1);

	out("<A STYlE=\"text-decoration:none\" HREF=\"JavaScript:void(0);\" onClick=\"ns($number)\"><NOBR>$HtagNumber_$j$H_tagNumber<FONT COLOR=\"$HnormalColor\">");

	if(($kind == $HcomDoNothing) ||
	   ($kind == $HcomGiveup)) {
		out("$name");
	} elsif(($kind == $HcomMissileNM) ||
			($kind == $HcomMissilePP)) {
		# 미사일 계열
		my($n) = ($arg == 0 ? '무제한' : "${arg}발");
		out("$target$point에 $name($HtagName_$n$H_tagName)");
	} elsif($kind == $HcomSell) {
		# 식량 수출
		out("$name$value");
	} elsif($kind == $HcomPropaganda) {
		# 유치 활동
		out("$name");
	} elsif(($kind == $HcomMoney) ||
			($kind == $HcomFood)) {
		# 지원
		out("$target에 $name$value");
	} elsif($kind == $HcomDestroy) {
		# 굴착
		if($arg != 0) {
			out("$point에서 $name(예산 ${value})");
		} else {
			out("$point에서 $name");
		}
	} elsif(($kind == $HcomFarm) ||
			 ($kind == $HcomFactory) ||
			 ($kind == $HcomMountain)) {
		# 횟수 포함
		if($arg == 0) {
			out("$point에서 $name");
		} else {
			out("$point에서 $name($arg회)");
		}
	} else {
		# 좌표 포함
		out("$point에서 $name");
	}

	out("</FONT></NOBR></A><BR>");
}

# 로컬 게시판
sub tempLbbsHead {
	out(<<END);
<HR>
<CENTER>
${HtagBig_}${HtagName_}${HcurrentName}섬${H_tagName} 관광자 통신${H_tagBig}<BR>
</CENTER>
END
}

# 로컬 게시판 입력 폼
sub tempLbbsInput {
	out(<<END);
<CENTER>
<FORM action="$HthisFile" method="POST">
<font color=red><B>섬이 없는 분도 기록할 수 있습니다. 또한 게임 내용과 관계없는 발언은 가능하면 ${bbsname}에 부탁드립니다.</b></font>
<TABLE BORDER CELLSPACING=0>
<TR>
<TH>이름</TH>
<TH>내용</TH>
</TR>
<TR>
<TD><INPUT TYPE="text" SIZE=32 MAXLENGTH=32 NAME="LBBSNAME" VALUE="$HdefaultName"></TD>
<TD><INPUT TYPE="text" SIZE=80 NAME="LBBSMESSAGE"></TD>
</TR>
<TR>
<TD colspan="2">자신의 섬：
<SELECT NAME="ISLANDID">
<OPTION value="0">섬 없는 관광자
$HislandList</SELECT>
　비밀번호：<INPUT TYPE="password" SIZE=32 MAXLENGTH=32 NAME=PASSWORD VALUE="$HdefaultPassword">
<INPUT TYPE="submit" VALUE="기록하기" NAME="LbbsButtonFO$HcurrentID"></TD>
</TR>
</TABLE>
</FORM>
</CENTER>
END
}

# 로컬 게시판 입력 폼 owner mode용
sub tempLbbsInputOW {
	out(<<END);
<CENTER>
<FORM action="$HthisFile" method="POST">
<TABLE BORDER CELLSPACING=0>
<TR>
<TH>이름</TH>
<TH COLSPAN=2>내용</TH>
</TR>
<TR>
<TD><INPUT TYPE="text" SIZE=32 MAXLENGTH=32 NAME="LBBSNAME" VALUE="$HdefaultName"></TD>
<TD COLSPAN=2><INPUT TYPE="text" SIZE=80 NAME="LBBSMESSAGE"></TD>
</TR>
<TR>
<TH>비밀번호</TH>
<TH COLSPAN=2>동작</TH>
</TR>
<TR>
<TD><INPUT TYPE=password SIZE=32 MAXLENGTH=32 NAME=PASSWORD VALUE="$HdefaultPassword"></TD>
<TD align=right>
<INPUT TYPE="submit" VALUE="기록하기" NAME="LbbsButtonOW$HcurrentID">
</TD>
<TD align=right>
번호
<SELECT NAME=NUMBER>
END
	# 발언 번호
	my($j, $i);
	for($i = 0; $i < $HlbbsMax; $i++) {
		$j = $i + 1;
		out("<OPTION VALUE=$i>$j\n");
	}
	out(<<END);
</SELECT>
<INPUT TYPE="submit" VALUE="삭제하기" NAME="LbbsButtonDL$HcurrentID">
</TD>
</TR>
</TABLE>
</FORM>
</CENTER>
END
}

# 로컬 게시판 내용
sub tempLbbsContents {
	my($lbbs, $line);
	$lbbs = $Hislands[$HcurrentNumber]->{'lbbs'};
	out(<<END);
<CENTER>
<TABLE BORDER CELLSPACING=0>
<TR>
<TH>번호</TH>
<TH>기록 내용</TH>
</TR>
END

	my($i);
	for($i = 0; $i < $HlbbsMax; $i++) {
		$line = $lbbs->[$i];
		if($line =~ /([0-9]*)\>(.*)\>(.*)$/) {
			my($j) = $i + 1;
			out("<TR><TD align=center>$HtagNumber_$j$H_tagNumber</TD>");
			if($1 == 0) {
				# 관광자
				out("<TD>$HtagLbbsSS_$2 > $3$H_tagLbbsSS</TD></TR>");
			} elsif($1 == 3) {
				# 섬 없는 관광자
				out("<TD>$HtagLbbsSK_$2 > $3$H_tagLbbsSK</TD></TR>");
			} else {
				# 섬 주인
				out("<TD>$HtagLbbsOW_$2 > $3$H_tagLbbsOW</TD></TR>");
			}
		}
	}

	out(<<END);
</TD></TR></TABLE></CENTER>
END
}

# 로컬 게시판에서 이름 또는 메시지가 없는 경우
sub tempLbbsNoMessage {
	out(<<END);
${HtagBig_}이름 또는 내용 칸이 비어 있습니다.${H_tagBig}$HtempBack
END
}

# 기록 삭제
sub tempLbbsDelete {
	out(<<END);
${HtagBig_}기록 내용을 삭제했습니다${H_tagBig}<HR>
END
}

# 기록 등록
sub tempLbbsAdd {
	out(<<END);
${HtagBig_}기록했습니다${H_tagBig}<HR>
END
}

# 명령 삭제
sub tempCommandDelete {
	out(<<END);
${HtagBig_}명령을 삭제했습니다${H_tagBig}<HR>
END
}

# 명령 등록
sub tempCommandAdd {
	out(<<END);
${HtagBig_}명령을 등록했습니다${H_tagBig}<HR>
END
}

# 댓글 변경 성공
sub tempComment {
	out(<<END);
${HtagBig_}댓글을 갱신했습니다${H_tagBig}<HR>
END
}

# 근황
sub tempRecent {
	my($mode) = @_;
	out(<<END);
<HR>
${HtagBig_}${HtagName_}${HcurrentName}섬${H_tagName}의 근황${H_tagBig}<BR>
END
	logPrintLocal($mode);
}

1;