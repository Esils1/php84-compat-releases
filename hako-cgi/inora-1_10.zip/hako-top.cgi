use utf8;
#----------------------------------------------------------------------
# 箱庭諸島 ver2.30
# TOP 모듈
# 사용 조건, 사용 방법 등은 hako-readme.txt 파일을 참조
#
# 箱庭諸島 페이지: http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html
#----------------------------------------------------------------------
# 이노라 제도
#----------------------------------------------------------------------

#----------------------------------------------------------------------
# TOP 페이지 모드
#----------------------------------------------------------------------
# 메인
sub topPageMain {
	# 개방
	unlock();

	# 템플릿 출력
	tempTopPage();
}

# TOP 페이지
sub tempTopPage {
	# 제목
	out("${HtagTitle_}$Htitle${H_tagTitle}");

	# 디버그 모드라면 “턴 진행” 버튼
	if($Hdebug == 1) {
		out(<<END);
<FORM action="$HthisFile" method="POST">
<INPUT TYPE="submit" VALUE="턴 진행" NAME="TurnButton">
</FORM>
END
	}
	if($makeMode eq 'cgi') {
		$owner = ' checked';
	} else {
		$java = ' checked';
	}
	my($mStr1) = '';
	if($HhideMoneyMode != 0) {
		$mStr1 = "<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}자금${H_tagTH}</NOBR></TH>";
	}

	# 시간 표시
	my($hour, $min, $sec);
	my($now) = time;
	my($showTIME) = ($HislandLastTime + $HunitTime - $now);
	$hour = int($showTIME / 3600);
	$min  = int(($showTIME - ($hour * 3600)) / 60);
	$sec  = $showTIME - ($hour * 3600) - ($min * 60);

	if ($sec < 0){
		out(<<END);
<H1>${HtagHeader_}턴 $HislandTurn/$HislandLastTurn${H_tagHeader}　$fightmode</H1><B><font size=+1>（${HtagHeader_}갱신해 주세요${H_tagHeader}）</font></b>
END
	} else {
		out(<<END);
<H1>${HtagHeader_}턴 $HislandTurn/$HislandLastTurn${H_tagHeader} <font size=+1>（다음 턴까지 앞으로 $hour 시간 $min 분 $sec 초）</font></b></H1>
END
	}

	# 폼
	out(<<END);
<SCRIPT language="JavaScript">
<!--
function develope(){
		if(document.Island.CHBOX.checked)
				document.Island.target = "_blank";
		else
				document.Island.target = "";
				return true;
}

//-->
</SCRIPT>
<HR>
<H1>${HtagHeader_}내 섬으로${H_tagHeader}</H1>
<FORM name="Island" action="$HthisFile" method="POST">
당신의 섬 이름은?<BR>
<SELECT NAME="ISLANDID">
$HislandList
</SELECT><BR>

비밀번호를 입력하세요!!<BR>
<INPUT TYPE="password" NAME="PASSWORD" VALUE="$HdefaultPassword" SIZE=32 MAXLENGTH=32><BR>
<INPUT TYPE="submit" VALUE="개발하러 가기" NAME="OwnerButton" onClick="develope()">
<INPUT TYPE="checkbox" NAME="CHBOX" VALUE="on">새 창에서 개발<BR>
<INPUT TYPE="radio" NAME=JAVAMODE VALUE=cgi${owner}>일반 모드
<INPUT TYPE="radio" NAME=JAVAMODE VALUE=java${java}>Java 스크립트 모드
</FORM>

<HR>

<H1>${HtagHeader_}섬의 정보${H_tagHeader}</H1>
<P>
섬 이름을 클릭하면 <B>관광</B>할 수 있습니다.
</P>
<TABLE BORDER CELLSPACING=1>
<TR>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}순위${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}섬${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}이노라 정보${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}인구${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}면적${H_tagTH}</NOBR></TH>
$mStr1
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}식량${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}농장 규모${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}공장 규모${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}채굴장 규모${H_tagTH}</NOBR></TH>
</TR>
END

	my($island, $j, $farm, $factory, $mountain, $name, $id, $prize, $ii, $contest);
	for($ii = 0; $ii < $HislandNumber; $ii++) {
		$j = $ii + 1;
		$island = $Hislands[$ii];

		$id = $island->{'id'};
		$farm = $island->{'farm'};
		$factory = $island->{'factory'};
		$mountain = $island->{'mountain'};
		$farm = ($farm == 0) ? "보유하지 않음" : "${farm}0$HunitPop";
		$factory = ($factory == 0) ? "보유하지 않음" : "${factory}0$HunitPop";
		$mountain = ($mountain == 0) ? "보유하지 않음" : "${mountain}0$HunitPop";
		if($island->{'absent'}  == 0) {
			$name = "${HtagName_}$island->{'name'}섬${H_tagName}";
		} else {
			$name = "${HtagName2_}$island->{'name'}섬($island->{'absent'})${H_tagName2}";
		}

		$prize = $island->{'prize'};
		my($flags, $monsters, $turns);
		$prize =~ /([0-9]*),([0-9]*),(.*)/;
		$flags = $1;
		$monsters= $2;
		$turns = $3;
		$prize = '';

		# 턴 컵 표시
		while($turns =~ s/([0-9]*),//) {
			$prize .= "<IMG SRC=\"prize0.png\" ALT=\"$1${Hprize[0]}\" WIDTH=16 HEIGHT=16> ";
		}

		# 이름에 상 표시 추가
		my($f) = 1;
		my($i);
		for($i = 1; $i < 10; $i++) {
			if($flags & $f) {
				$prize .= "<IMG SRC=\"prize${i}.png\" ALT=\"${Hprize[$i]}\" WIDTH=16 HEIGHT=16> ";
			}
			$f *= 2;
		}

		# 쓰러뜨린 괴수 목록
		$f = 1;
		my($max) = -1;
		my($mNameList) = '';
		for($i = 0; $i < $HmonsterNumber; $i++) {
			if($monsters & $f) {
				$mNameList .= "[$HmonsterName[$i]] ";
				$max = $i;
			}
			$f *= 2;
		}
		if($max != -1) {
			$prize .= "<IMG SRC=\"${HmonsterImage[$max]}\" ALT=\"$mNameList\" WIDTH=16 HEIGHT=16> ";
		}

		$prize .= "<BR>";
		my($c_arm, $c_cute, $c_int) = split(",",$island->{'i_cont'});
		for($co = 0;$co < $c_arm;$co++) {
			$prize .= "<IMG SRC=\"monster7.png\" ALT=\"${Hprize[10]} 우승\" WIDTH=16 HEIGHT=16> ";
		}
		for($co = 0;$co < $c_cute;$co++) {
			$prize .= "<IMG SRC=\"monster8.png\" ALT=\"${Hprize[11]} 우승\" WIDTH=16 HEIGHT=16> ";
		}
		for($co = 0;$co < $c_int;$co++) {
			$prize .= "<IMG SRC=\"monster9.png\" ALT=\"${Hprize[12]} 우승\" WIDTH=16 HEIGHT=16> ";
		}

		my($mStr1) = '';
		if($HhideMoneyMode == 1) {
			$mStr1 = "<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$island->{'money'}$HunitMoney</NOBR></TD>";
		} elsif($HhideMoneyMode == 2) {
			my($mTmp) = aboutMoney($island->{'money'});
			$mStr1 = "<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$mTmp</NOBR></TD>";
		}

		my($comname) ="${HtagTH_}댓글：${H_tagTH}";
		if(($island->{'ownername'} ne '0') && ($island->{'ownername'} ne "댓글")){
			$comname = "<FONT COLOR=\"blue\"><B>$island->{'ownername'}：</b></font>";
		}

		my($image_name);
		$image_name = $HmonsterImage[$island->{'i_type'}];
		$image_name2 = $image_name;
		$image_name = "an_".$image_name2 if($island->{'i_ang'} < 1000);
		$image_name = "sl_".$image_name2 if($island->{'i_sleep'} > 100);
		$i_image = "<IMG SRC=\"${image_name}\" WIDTH=48 HEIGHT=48 ALIGN=CENTER> ";

		my $i_hp   = int($island->{'i_hp'} / 1000);
		my $i_arm  = int($island->{'i_arm'} / 1000);
		my $i_int  = int($island->{'i_int'} / 1000);
		my $i_cute = int($island->{'i_cute'} / 1000);
		$i_hp = 1 if($i_hp < 1);
		$i_arm = 0 if($i_arm < 1);
		$i_int = 0 if($i_int < 1);
		$i_cute = 0 if($i_cute < 1);

		out(<<END);
<TR>
<TD $HbgNumberCell ROWSPAN=2 align=center nowrap=nowrap><NOBR>${HtagNumber_}$j${H_tagNumber}</NOBR></TD>
<TD $HbgNameCell ROWSPAN=2 align=center nowrap=nowrap>
<NOBR>
<A STYlE=\"text-decoration:none\" HREF="${HthisFile}?Sight=${id}">
$name
</A><BR>
$prize
</NOBR>
</TD>
<TD $HbgNameCell ROWSPAN=2 nowrap=nowrap>
<TABLE CELLSPACING=0 CELLPADDING=0>
<TR><TD>
<NOBR>
$i_image
<TD nowrap=nowrap>
이름：${HtagIName_}$island->{'i_name'}${H_tagIName}<BR>
종류：$HmonsterName[$island->{'i_type'}]<BR>
체：${i_hp} </b>
완：${i_arm} </b>
매：${i_cute} </b>
지：${i_int}<BR></b>
</TABLE>
</TD>
<TD $HbgInfoCell align=right nowrap=nowrap>
<NOBR>$island->{'pop'}$HunitPop</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$island->{'area'}$HunitArea</NOBR></TD>
$mStr1
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$island->{'food'}$HunitFood</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$farm</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$factory</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$mountain</NOBR></TD>
</TR>
<TR>
<TD $HbgCommentCell COLSPAN=7 align=center nowrap=nowrap><NOBR>$comname$island->{'comment'}</NOBR></TD>
</TR>
END
	}

	out(<<END);
</TABLE>
<HR>
<H1>${HtagHeader_}새로운 섬 찾기${H_tagHeader}</H1>
END

	if($HislandNumber < $HmaxIsland) {
		out(<<END);
<FORM action="$HthisFile" method="POST">
섬 이름<BR>
<INPUT TYPE="text" NAME="ISLANDNAME" SIZE=32 MAXLENGTH=32>섬<BR>
이노라 이름(<FONT COLOR=RED>중간 변경 불가　10글자 정도 권장</FONT>)<BR>
<INPUT TYPE="text" NAME="MONSTERNAME" SIZE=32 MAXLENGTH=64><BR>
비밀번호는?<BR>
<INPUT TYPE="password" NAME="PASSWORD" SIZE=32 MAXLENGTH=32><BR>
확인을 위해 비밀번호를 한 번 더<BR>
<INPUT TYPE="password" NAME="PASSWORD2" SIZE=32 MAXLENGTH=32><BR>

<INPUT TYPE="submit" VALUE="찾으러 가기" NAME="NewIslandButton">
</FORM>
END
	} else {
		out(<<END);
		섬 수가 최대치입니다…현재 등록할 수 없습니다.
END
	}

	my($Himfflag);
	if($HimgLine eq '' || $HimgLine eq $imageDir){
		$Himfflag = '<FONT COLOR=RED>미설정</FONT>';
	} else {
		$Himfflag = $baseIMG;
	}

	out(<<END);
<HR><P>
<TABLE>
<TR><TD WIDTH=420 ROWSPAN=2 VALIGN=TOP>
<H1>${HtagHeader_}정보 변경${H_tagHeader}</H1>
<P>
(주의) 이름 변경에는 $HcostChangeName${HunitMoney}가 필요합니다.
</P>
<FORM action="$HthisFile" method="POST">
어느 섬입니까?<BR>
<SELECT NAME="ISLANDID">
$HislandList
</SELECT>
<BR>
어떤 이름으로 바꾸겠습니까? 변경할 경우만 입력<BR>
<INPUT TYPE="text" NAME="ISLANDNAME" SIZE=32 MAXLENGTH=32>섬<BR>
비밀번호는? 필수<BR>
<INPUT TYPE="password" NAME="OLDPASS" SIZE=32 MAXLENGTH=32><BR>
새 비밀번호는? 변경할 시만 입력<BR>
<INPUT TYPE="password" NAME="PASSWORD" SIZE=32 MAXLENGTH=32><BR>
확인을 위해 비밀번호를 한 번 더 변경할 시만 입력<BR>
<INPUT TYPE="password" NAME="PASSWORD2" SIZE=32 MAXLENGTH=32><BR>

<INPUT TYPE="submit" VALUE="변경하기" NAME="ChangeInfoButton">
</FORM>

</TD>

<TD VALIGN=TOP WIDTH=350>
<H1>${HtagHeader_}이미지 로컬 설정${H_tagHeader}</H1>
<NOBR>현재 설정<B>[</b> $Himfflag <B>]</B></NOBR>
<BR><A HREF=${imageExp} target=_blank><FONT SIZE=+1> 설명 </FONT></A>
<form action=$HthisFile method=POST>
<INPUT TYPE=file NAME="IMGLINE">
<INPUT TYPE="submit" VALUE="설정" name=IMGSET>
</form>

<form action=$HthisFile method=POST>
Mac 사용자용<BR>
<INPUT TYPE=text NAME="IMGLINEMAC">
<INPUT TYPE="submit" VALUE="설정" name=IMGSET><BR>
<FONT SIZE=-1>Mac 사용자는 이쪽을 사용해 주세요.</FONT>
</form>
</TD></TR>

<TR HEIGHT=100><TD ALIGN=CENTER>
<form action=$HthisFile method=POST>
<INPUT TYPE=hidden NAME="IMGLINE" value="deletemodenow">
<INPUT TYPE="submit" VALUE="설정 해제" name=IMGSET>
</form>
</TD></TR>
</TABLE>
<HR>
<H1>${HtagHeader_}오너 이름 결정!${H_tagHeader}</H1>
<FORM action="$HthisFile" method="POST">
당신의 섬은?
<SELECT NAME="ISLANDID">
$HislandList
</SELECT>　　이름 입력
<INPUT TYPE="text" NAME="OWNERNAME" SIZE=16 MAXLENGTH=32>
　　비밀번호
<INPUT TYPE="password" NAME="OLDPASS" SIZE=16 MAXLENGTH=32>
<INPUT TYPE="submit" VALUE="이걸로 하기" NAME="ChangeOwnerName">
</form>
<HR>
<H1>${HtagHeader_}발견 기록${H_tagHeader}</H1>
END
	historyPrint();
}

# 기록 파일 표시
sub historyPrint {
	open(HIN, "<:raw", "${HdirName}/hakojima.his");
	my(@line, $l);
	while($l = <HIN>) {
		chomp($l);
		push(@line, $l);
	}
	@line = reverse(@line);

	foreach $l (@line) {
		$l =~ /^([0-9]*),(.*)$/;
		my $histMessage = normalizeText($2);
		out("<NOBR>${HtagNumber_}턴 ${1}${H_tagNumber}：${histMessage}</NOBR><BR>\n");
	}
	close(HIN);
}


#----------------------------------------------------------------------
# 로그 표시 모드
#----------------------------------------------------------------------
# 메인
sub logViewMain {

	# 개방
	unlock();

	# 템플릿 출력
	tempLogPage();
}

sub tempLogPage {

	out(<<END);

<font size=+3><b>${HtagHeader_}최근 사건${H_tagHeader}</b></font>　
　<a href="$HthisFile?LogFileView=1"><FONT COLOR="blue" size=2><B>현재 턴</a>
　<a href="$HthisFile?LogFileView=2">2턴분 표시</a>
END
for($i = 3; $i -1 < $HlogMax; $i++) {
		out("　<a href=\"$HthisFile?LogFileView=${i}\">${i}턴분</a>\n");
}
	out(<<END);
</b></font><br>
END
	logPrintTop();

}

# 로그 표시
sub logPrintTop {
	my($i);
	for($i = 0; $i < $Hlogturn; $i++) {
		out("<hr>\n");
		logFilePrint($i, 0, 0);

	}
}

1;