#!/usr/bin/perl
use utf8;
# ↑ 서버에 맞게 변경해 주세요.

#----------------------------------------------------------------------
# 箱庭諸島 ver2.30
# 유지보수 도구
# 사용 조건, 사용 방법 등은 hako-readme.txt 파일을 참조
#
# 箱庭諸島 페이지: http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html
#----------------------------------------------------------------------
# 이노라 제도
#----------------------------------------------------------------------

require ('hako-ini.cgi');

# 이 파일
my($thisFile) = './hako-mente.cgi';

# use Time::Local을 사용할 수 없는 환경에서는 'use Time::Local' 줄을 삭제해 주세요.
# 단, 갱신 시간 변경은 '초 지정으로 변경'만 가능해집니다.
use Time::Local;

# ――――――――――――――――――――――――――――――
# 설정 항목은 여기까지
# ――――――――――――――――――――――――――――――

# 각종 변수
my($mainMode);
my($inputPass);
my($deleteID);
my($currentID);
my($ctYear);
my($ctMon);
my($ctDate);
my($ctHour);
my($ctMin);
my($ctSec);

print <<END;
Content-type: text/html; charset=UTF-8

<HTML>
<HEAD>
<TITLE>箱島２ 유지보수 도구</TITLE>
<META http-equiv="Content-Style-Type" content="text/css">
<META http-equiv="Content-Type" content="text/html;charset=UTF-8">
</HEAD>
<BODY>
END

cgiInput();

if($mainMode eq 'delete') {
	if(passCheck()) {
		deleteMode();
	}
} elsif($mainMode eq 'current') {
	if(passCheck()) {
		currentMode();
	}
} elsif($mainMode eq 'time') {
	if(passCheck()) {
		timeMode();
	}
} elsif($mainMode eq 'stime') {
	if(passCheck()) {
		stimeMode();
	}
} elsif($mainMode eq 'new') {
	if(passCheck()) {
		newMode();
	}
}
mainMode();

print <<END;
</FORM>
</BODY>
</HTML>
END

sub myrmtree {
	my($dn) = @_;
	opendir(DIN, "$dn/");
	my($fileName);
	while($fileName = readdir(DIN)) {
		unlink("$dn/$fileName");
	} 
	closedir(DIN);
	rmdir($dn);
}

sub currentMode {
	myrmtree "${HdirName}";
	mkdir("${HdirName}", $HdirMode);
	opendir(DIN, "${HdirName}.bak$currentID/");
	my($fileName);
	while($fileName = readdir(DIN)) {
		fileCopy("${HdirName}.bak$currentID/$fileName", "${HdirName}/$fileName");
	} 
	closedir(DIN);
}

sub deleteMode {
	if($deleteID eq '') {
		myrmtree "${HdirName}";
	} else {
		myrmtree "${HdirName}.bak$deleteID";
	}
	unlink "hakojimalockflock";
}

sub newMode {
	mkdir($HdirName, $HdirMode);

	# 현재 시간 취득
	my($now) = time;
	$now = $now - ($now % ($HunitTime));

	open(OUT, ">$HdirName/hakojima.dat"); # 파일 열기
	print OUT "1\n";		 # 턴 수 1
	print OUT "$now\n";		 # 시작 시간
	print OUT "0\n";		 # 섬 수
	print OUT "1\n";		 # 다음에 할당할 ID

	# 파일 닫기
	close(OUT);
}

sub timeMode {
	$ctMon--;
	$ctYear -= 1900;
	$ctSec = timelocal($ctSec, $ctMin, $ctHour, $ctDate, $ctMon, $ctYear);
	stimeMode();
}

sub stimeMode {
	my($t) = $ctSec;
	open(IN, "${HdirName}/hakojima.dat");
	my(@lines);
	@lines = <IN>;
	close(IN);

	$lines[1] = "$t\n";

	open(OUT, ">${HdirName}/hakojima.dat");
	print OUT @lines;
	close(OUT);
}

sub mainMode {
	opendir(DIN, "./");

	print <<END;
<FORM action="$thisFile" method="POST">
<H1>箱島２ 유지보수 도구</H1>
<B>비밀번호:</B><INPUT TYPE=password SIZE=32 MAXLENGTH=32 NAME=PASSWORD></TD>
END

	# 현재 데이터
	if(-d "${HdirName}") {
		dataPrint("");
	} else {
		print <<END;
	<HR>
	<INPUT TYPE="submit" VALUE="새 데이터 만들기" NAME="NEW">
END
	}

	# 백업 데이터
	my($dn);
	while($dn = readdir(DIN)) {
		if($dn =~ /^${HdirName}.bak(.*)/) {
			dataPrint($1);
		}
	} 
	closedir(DIN);
}

# 표시 모드
sub dataPrint {
	my($suf) = @_;

	print "<HR>";
	if($suf eq "") {
		open(IN, "${HdirName}/hakojima.dat");
		print "<H1>현재 데이터</H1>";
	} else {
		open(IN, "${HdirName}.bak$suf/hakojima.dat");
		print "<H1>백업$suf</H1>";
	}

	my($lastTurn);
	$lastTurn = <IN>;
	my($lastTime);
	$lastTime = <IN>;

	my($timeString) = timeToString($lastTime);

	print <<END;
	<B>턴 $lastTurn</B><BR>
	<B>최종 갱신 시간</B>:$timeString<BR>
	<B>최종 갱신 시간(초 표시)</B>:1970년 1월 1일부터 $lastTime 초<BR>
	<INPUT TYPE="submit" VALUE="이 데이터 삭제" NAME="DELETE$suf">
END

	if($suf eq "") {
		my($sec, $min, $hour, $date, $mon, $year, $day, $yday, $dummy) =
			localtime($lastTime);
		$mon++;
		$year += 1900;

		print <<END;
	<H2>최종 갱신 시간 변경</H2>
	<INPUT TYPE="text" SIZE=4 NAME="YEAR" VALUE="$year">년
	<INPUT TYPE="text" SIZE=2 NAME="MON" VALUE="$mon">월
	<INPUT TYPE="text" SIZE=2 NAME="DATE" VALUE="$date">일
	<INPUT TYPE="text" SIZE=2 NAME="HOUR" VALUE="$hour">시
	<INPUT TYPE="text" SIZE=2 NAME="MIN" VALUE="$min">분
	<INPUT TYPE="text" SIZE=2 NAME="NSEC" VALUE="$sec">초
	<INPUT TYPE="submit" VALUE="변경" NAME="NTIME"><BR>
	1970년 1월 1일부터 <INPUT TYPE="text" SIZE=32 NAME="SSEC" VALUE="$lastTime">초
	<INPUT TYPE="submit" VALUE="초 지정으로 변경" NAME="STIME">

END
	} else {
		print <<END;
		<INPUT TYPE="submit" VALUE="이 데이터를 현재 데이터로" NAME="CURRENT$suf">
END
	}
}

sub timeToString {
	my($sec, $min, $hour, $date, $mon, $year, $day, $yday, $dummy) =
		localtime($_[0]);
	$mon++;
	$year += 1900;

	return "${year}년 ${mon}월 ${date}일 ${hour}시 ${min}분 ${sec}초";
}

# CGI 읽기
sub cgiInput {
	my($line);

	# 입력 받기
	$line = <>;
	$line =~ tr/+/ /;
	$line =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;

	if($line =~ /DELETE([0-9]*)/) {
		$mainMode = 'delete';
		$deleteID = $1;
	} elsif($line =~ /CURRENT([0-9]*)/) {
		$mainMode = 'current';
		$currentID = $1;
	} elsif($line =~ /NEW/) {
		$mainMode = 'new';
	} elsif($line =~ /NTIME/) {
		$mainMode = 'time';
		if($line =~ /YEAR=([0-9]*)/) {
			$ctYear = $1; 
		}
		if($line =~ /MON=([0-9]*)/) {
			$ctMon = $1; 
		}
		if($line =~ /DATE=([0-9]*)/) {
			$ctDate = $1; 
		}
		if($line =~ /HOUR=([0-9]*)/) {
			$ctHour = $1; 
		}
		if($line =~ /MIN=([0-9]*)/) {
			$ctMin = $1; 
		}
		if($line =~ /NSEC=([0-9]*)/) {
			$ctSec = $1; 
		}
	} elsif($line =~ /STIME/) {
		$mainMode = 'stime';
		if($line =~ /SSEC=([0-9]*)/) {
			$ctSec = $1; 
		}
	}

	if($line =~ /PASSWORD=([^\&]*)\&/) {
		$inputPass = $1;
	}
}

# 파일 복사
sub fileCopy {
	my($src, $dist) = @_;
	open(IN, $src);
	open(OUT, ">$dist");
	while(<IN>) {
		print OUT;
	}
	close(IN);
	close(OUT);
}

# 비밀번호 체크
sub passCheck {
	if($inputPass eq $masterPassword) {
		return 1;
	} else {
		print <<END;
   <FONT SIZE=7>비밀번호가 틀립니다.</FONT>
END
		return 0;
	}
}

1;