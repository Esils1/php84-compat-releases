#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}
# ↑은서버에 맞게 변경해 주세요.
# perl5용입니다.

#----------------------------------------------------------------------
# 모형정원 제도 ver2.30
# 메인 스크립트(ver1.02)
# 사용 조건과 사용 방법은 hako-readme.txt 파일을 참조해 주세요
#
# 모형정원 제도의 페이지: http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html
#----------------------------------------------------------------------
# 모형정원 팀 토너먼트
# 메인 스크립트
# $Id: hako-main.cgi 17 2005-12-22 07:44:11Z takayama $

require './hako-ini.cgi';

#----------------------------------------
# 기지의 경험치
#----------------------------------------
# 경험치의 최댓값
$HmaxExpPoint = 200; # 단, 최대라도255까지

# 레벨의 최댓값
my($maxBaseLevel) = 5; # 미사일 기지
my($maxSBaseLevel) = 3; # 해저 기지

# 경험치가 몇 점이면 레벨업할지
my(@baseLevelUp, @sBaseLevelUp);
@baseLevelUp = (20, 60, 120, 200); # 미사일 기지
@sBaseLevelUp = (50, 200); # 해저 기지

#----------------------------------------
# 재해
#----------------------------------------
# 지반 침하
$HdisFallBorder = 110; # 안정 전체한계의 면적(Hex 수)
$HdisFalldown = 30; # 그 면적를 초과한 경우 확률

#----------------------------------------
# 수상 관계
#----------------------------------------

# 상의 이름
$Hprize[0] = '턴잔';
$Hprize[1] = '번영상';
$Hprize[2] = '초과 번영상';
$Hprize[3] = '궁극번영상';
$Hprize[4] = '평화상';
$Hprize[5] = '초과 평화상';
$Hprize[6] = '궁극평화상';
$Hprize[7] = '재난상';
$Hprize[8] = '초과 재난상';
$Hprize[9] = '궁극재난상';

#----------------------------------------
# 화면 표시 관련
#----------------------------------------
# <BODY>태그의 옵션
my($htmlBody) = 'BGCOLOR="#EEFFFF"';
$Body = "<BODY $htmlBody>";
# 태그
# 제목문자
$HtagTitle_ = '<FONT SIZE=7 COLOR="#8888ff">';
$H_tagTitle = '</FONT>';

# H1태그용
$HtagHeader_ = '<FONT COLOR="#4444ff">';
$H_tagHeader = '</FONT>';

# 큰 글자
$HtagBig_ = '<FONT SIZE=6>';
$H_tagBig = '</FONT>';

# 섬 이름 등
$HtagName_ = '<FONT COLOR="#a06040"><B>';
$H_tagName = '</B></FONT>';

# 팀의 이름
$HtagTName_ = '<FONT COLOR="#A0522D"><B>[';
$H_tagTName = ']</B></FONT>';

#$HtagTName_ = '<FONT COLOR="#A0522D"><B>&lt';
#$H_tagTName = '&gt</B></FONT>';

# 숨김 처리하지 않은 섬 이름
$HtagName2_ = '<FONT COLOR="#808080"><B>';
$H_tagName2 = '</B></FONT>';

# 비활성 처리하지 않은 팀 이름
$HtagTName2_ = '<FONT COLOR="#808080"><B>[';
$H_tagTName2 = ']</B></FONT>';

# 순위 번호 등
$HtagNumber_ = '<FONT COLOR="#800000"><B>';
$H_tagNumber = '</B></FONT>';

# 순위표 머리글
$HtagTH_ = '<FONT COLOR="#C00000"><B>';
$H_tagTH = '</B></FONT>';

# 개발계획의 이름
$HtagComName_ = '<FONT COLOR="#d08000"><B>';
$H_tagComName = '</B></FONT>';

# 재해
$HtagDisaster_ = '<FONT COLOR="#ff0000"><B>';
$H_tagDisaster = '</B></FONT>';

# 로컬 게시판, 관광객의 표시 문자
$HtagLbbsSS_ = '<FONT COLOR="#0000ff"><B>';
$H_tagLbbsSS = '</B></FONT>';

# 로컬 게시판, 섬주의 표시 문자
$HtagLbbsOW_ = '<FONT COLOR="#ff0000"><B>';
$H_tagLbbsOW = '</B></FONT>';

# 로컬 게시판, 섬무시 관광객의 표시 문자
$HtagLbbsSK_ = '<FONT COLOR="#003333"><B>';
$H_tagLbbsSK = '</B></FONT>';

# 일반 문자색(BODY 태그의 옵션도 함께 변해야 합니다
$HnormalColor = '#000000';

# 몇회전목
$HtagFico_ = '<FONT SIZE="7" COLOR="#4444ff">';
$H_tagFico = '</FONT>';

# 순위표, 세루의 속성
$HbgTitleCell = 'BGCOLOR="#ccffcc"'; # 순위표 머리글시
$HbgNumberCell = 'BGCOLOR="#ccffcc"'; # 순위표순위
$HbgNameCell = 'BGCOLOR="#ccffff"'; # 순위표 섬 이름
$HbgInfoCell = 'BGCOLOR="#ccffff"'; # 순위표 섬의 정보
$HbgCommentCell = 'BGCOLOR="#ccffcc"'; # 순위표코멘트란
$HbgInputCell = 'BGCOLOR="#ccffcc"'; # 개발계획양식
$HbgMapCell = 'BGCOLOR="#ccffcc"'; # 개발계획지도
$HbgCommandCell = 'BGCOLOR="#ccffcc"'; # 개발계획입력완료미계획

# 예선용락치레도라인
$YbgNumberCell = 'BGCOLOR="#F0BBDA"'; # 순위표순위
$YbgNameCell = 'BGCOLOR="#E4CCF5"'; # 순위표 섬 이름
$YbgInfoCell = 'BGCOLOR="#E4CCF5"'; # 순위표 섬의 정보
$YbgCommentCell = 'BGCOLOR="#F0BBDA"'; # 순위표코멘트란

#----------------------------------------------------------------------
# 필요에 따라 설정하는 항목은 여기까지입니다
#----------------------------------------------------------------------

#----------------------------------------------------------------------
# 아래쪽 스크립트는 변경을 전제로 하지 않습니다.
# 그래도 문제는 없습니다.
# 명령 이름과 가격 등은 알아보기 쉽게 두는 편이 좋습니다.
#----------------------------------------------------------------------

#----------------------------------------------------------------------
# 각종 상수
#----------------------------------------------------------------------
# 이 파일
$HthisFile = "$baseDir/hako-main.cgi";

# 애플릿통신용 CGI
$HjavaFile = "$baseDir/hako-java.cgi";

# 지형 번호
$HlandSea = 0; # 바다
$HlandWaste = 1; # 황무지
$HlandPlains = 2; # 평지
$HlandTown = 3; # 마을 계열
$HlandForest = 4; # 숲
$HlandFarm = 5; # 농장
$HlandFactory = 6; # 공장
$HlandBase = 7; # 미사일 기지
$HlandDefence = 8; # 방위 시설
$HlandSbase = 9; # 해저 기지
$HlandHaribote = 12; # 가짜 시설

# 명령
$HcommandTotal = 22; # 명령 종류

# 계획 번호 설정
# 개간 계열
$HcomPrepare = 01; # 개간
$HcomPrepare2 = 02; # 땅고르기
$HcomReclaim = 03; # 매립
$HcomDestroy = 04; # 굴착
$HcomSellTree = 05; # 벌채
$HcomPrepRecr = 06; # 매립 + 땅고르기

# 작루계
$HcomPlant = 11; # 나무심기
$HcomFarm = 12; # 농장 건설
$HcomFactory = 13; # 공장 건설
$HcomBase = 14; # 미사일 기지건설
$HcomDbase = 15; # 방위 시설 건설
$HcomHaribote = 16; # 가짜 기지건설
$HcomFastFarm = 17; # 고속 농장 건설

# 발사계
$HcomMissileNM = 31; # 미사일 발사
$HcomMissilePP = 32; # PP 미사일 발사

# 운영계
$HcomDoNothing = 41; # 자금 조달
$HcomSell = 42; # 식량 수출
$HcomFood = 43; # 식량지원
$HcomPropaganda = 44; # 유치 활동

# 자동 입력
$HcomAutoPrepare = 61; # 전체 개간
$HcomAutoPrepare2 = 62; # 전체땅고르기
$HcomAutoDelete = 63; # 전체 명령 삭제
$HcomAutoPrepare3 = 64; # 일괄 자동 땅고르기

# 순서
@HcomList =
 ($HcomPrepare, $HcomPrepare2, $HcomReclaim, $HcomDestroy, $HcomPrepRecr,
 $HcomSellTree, $HcomPlant, $HcomFarm, $HcomFactory, $HcomFastFarm,
 $HcomBase, $HcomDbase, $HcomMissileNM, $HcomMissilePP,
 $HcomDoNothing, $HcomSell, $HcomFood, $HcomPropaganda,
 $HcomAutoPrepare, $HcomAutoPrepare2, $HcomAutoPrepare3, $HcomAutoDelete);

# 계획 이름과 비용
$HcomName[$HcomPrepare] = '개간';
$HcomCost[$HcomPrepare] = 5;
$HcomName[$HcomPrepare2] = '땅고르기';
$HcomCost[$HcomPrepare2] = 100;
$HcomName[$HcomReclaim] = '매립';
$HcomCost[$HcomReclaim] = 100;
$HcomName[$HcomPrepRecr] = '매립 + 땅고르기';
$HcomCost[$HcomPrepRecr] = 0;
$HcomName[$HcomDestroy] = '굴착';
$HcomCost[$HcomDestroy] = 200;
$HcomName[$HcomSellTree] = '벌채';
$HcomCost[$HcomSellTree] = 0;
$HcomName[$HcomPlant] = '나무심기';
$HcomCost[$HcomPlant] = 10;
$HcomName[$HcomFarm] = '농장 건설';
$HcomCost[$HcomFarm] = 20;
$HcomName[$HcomFastFarm] = '고속 농장 건설';
$HcomCost[$HcomFastFarm] = 500;
$HcomName[$HcomFactory] = '공장 건설';
$HcomCost[$HcomFactory] = 100;
$HcomName[$HcomBase] = '미사일 기지건설';
$HcomCost[$HcomBase] = 300;
$HcomName[$HcomDbase] = '방위 시설 건설';
$HcomCost[$HcomDbase] = 600;
$HcomName[$HcomHaribote] = '가짜 기지건설';
$HcomCost[$HcomHaribote] = 1;
$HcomName[$HcomMissileNM] = '미사일 발사';
$HcomCost[$HcomMissileNM] = 20;
$HcomName[$HcomMissilePP] = 'PP 미사일 발사';
$HcomCost[$HcomMissilePP] = 50;
$HcomName[$HcomPropaganda] = '유치 활동';
$HcomCost[$HcomPropaganda] = 800;
$HcomName[$HcomDoNothing] = '자금 조달';
$HcomCost[$HcomDoNothing] = 0;
$HcomName[$HcomSell] = '식량 수출';
$HcomCost[$HcomSell] = -100;
$HcomName[$HcomFood] = '식량지원';
$HcomCost[$HcomFood] = -100;
$HcomName[$HcomAutoPrepare] = '개간 자동 입력';
$HcomCost[$HcomAutoPrepare] = 0;
$HcomName[$HcomAutoPrepare2] = '땅고르기 자동 입력';
$HcomCost[$HcomAutoPrepare2] = 0;
$HcomName[$HcomAutoPrepare3] = '일괄 자동 땅고르기';
$HcomCost[$HcomAutoPrepare3] = 0;
$HcomName[$HcomAutoDelete] = '전체계획을 백지 철회';
$HcomCost[$HcomAutoDelete] = 0;

#----------------------------------------------------------------------
# 변수
#----------------------------------------------------------------------

# COOKIE
my($defaultID); # 섬 이름
my($defaultTarget); # 대상의 이름


# 섬의 좌표 수
$HpointNumber = $HislandSize * $HislandSize;

#----------------------------------------------------------------------
# 메인
#----------------------------------------------------------------------

# 문자 변환 라이브러리 로드

# '돌아가기'링크
$HtempBack = "<A HREF=\"$HthisFile?\">${HtagBig_}맨 위로 돌아가기${H_tagBig}</A>";

# 잠금을 끼치기
if(!hakolock()) {
 # 잠금실패
 # 헤더출력
 tempHeader();

 # 잠금실패 메시지
 tempLockFail();

 # 푸터출력
 tempFooter();

 # 종료
 exit(0);
}

# 난수의 초기화
srand(time^$$);

# COOKIE 읽기
cookieInput();

# CGI 읽기
cgiInput();

# 섬 데이터 읽기
if(readIslandsFile($HcurrentID) == 0) {
 unlock();
 tempHeader();
 tempNoDataFile();
 tempFooter();
 exit(0);
}

# 팀 데이터 읽기
if(readTeamsFile() == 0) {
 unlock();
 tempHeader();
 tempNoDataFile();
 tempFooter();
 exit(0);
}


# 템플릿을 초기화
tempInitialize();

# COOKIE 출력
cookieOutput();

# 헤더출력
#tempHeader();
if($HmainMode eq 'owner' && $HjavaMode eq 'java' ||
 $HmainMode eq 'commandJava' || # 명령 입력 모드
 $HmainMode eq 'comment' && $HjavaMode eq 'java' || #코멘트입력 모드
 $HmainMode eq 'lbbs' && $HjavaMode eq 'java') { #코멘트입력 모드
	$Body = "<BODY onload=\"init()\" $htmlBody>";
 	require('hako-js.cgi');
	require('hako-map.cgi');
	# 헤더출력
	tempHeader();
 if($HmainMode eq 'commandJava') {
 	# 개발 모드
 	commandJavaMain();
 } elsif($HmainMode eq 'comment') {
 	# 코멘트입력 모드
 	commentMain();
 } elsif($HmainMode eq 'lbbs') {
	# 로컬 게시판 모드
 localBbsMain();
 }else{
	ownerMain();
 }
	# 푸터출력
	tempFooter();
	# 종료
	exit(0);
 }elsif($HmainMode eq 'landmap'){
 	require('hako-js.cgi');
 require('hako-map.cgi');
	$Body = "<BODY $htmlBody>";
	# 헤더출력
	tempHeaderJava();
 # 관광 모드
 printIslandJava();
	# 푸터출력
	tempFooter();
	# 종료
	exit(0);
}else{
	# 헤더출력
	tempHeader();
}

if($HmainMode eq 'turn') {
 # 턴진행
 require('hako-turn.cgi');
 require('hako-top.cgi');
 turnMain();

} elsif($HmainMode eq 'new') {
 # 섬 신규 생성
 require('hako-turn.cgi');
 require('hako-map.cgi');
 newIslandMain();

} elsif($HmainMode eq 'print') {
 # 관광 모드
 require('hako-map.cgi');
 printIslandMain();

} elsif($HmainMode eq 'owner') {

 # 개발 모드
 require('hako-map.cgi');
 ownerMain();

} elsif($HmainMode eq 'command') {
 # 명령 입력 모드
 require('hako-map.cgi');
 commandMain();

} elsif($HmainMode eq 'comment') {
 # 코멘트입력 모드
 require('hako-map.cgi');
 commentMain();

} elsif($HmainMode eq 'lbbs') {

 # 로컬 게시판 모드
 require('hako-map.cgi');
 localBbsMain();

} elsif($HmainMode eq 'change') {
 # 정보 변경 모드
 require('hako-turn.cgi');
 require('hako-top.cgi');
 changeMain();

} elsif($HmainMode eq 'logView') {
 # LOG 모드
 require('hako-more.cgi');
 logViewMain();

} elsif($HmainMode eq 'logTeam') {
 # LOG 모드
 require('hako-more.cgi');
 logTeamMain();

} elsif($HmainMode eq 'help') {
 # ☆HELP 모드
 require('hako-more.cgi');
 helpMain();

} elsif($HmainMode eq 'teamdata') {
 # 작전본부
 require('hako-more.cgi');
 teamDataMain();

} elsif($HmainMode eq 'HchangeTName') {
 # 팀 이름 변경
 require('hako-more.cgi');
 changeTeamNameMain();

} elsif($HmainMode eq 'fightlog') {
 # ☆전투 기록 모드
 require('hako-more.cgi');
 fightlogMain();

} elsif($HmainMode eq 'adminpage') {
 # 관리자 화면
 require('hako-more.cgi');
 pageAdminMain();

} elsif($HmainMode eq 'delete') {
 # 섬 삭제 모드
 require('hako-turn.cgi');
 require('hako-top.cgi');
 changeMain();

} else {
 # 그 외에는 톱 페이지 모드
 require('hako-top.cgi');
 topPageMain();
}

# 푸터출력
tempFooter();

# 종료
exit(0);

# 명령을 앞으로 당기기
sub slideFront {
 my($command, $number) = @_;
 my($i);

 # 각각밀기
 splice(@$command, $number, 1);

 # 마지막에 자금 조달
 $command->[$HcommandMax - 1] = {
	'kind' => $HcomDoNothing,
	'target' => 0,
	'x' => 0,
	'y' => 0,
	'arg' => 0
	};
}

# 명령을 뒤로 밀기
sub slideBack {
 my($command, $number) = @_;
 my($i);

 # 각각밀기
 return if $number == $#$command;
 pop(@$command);
 splice(@$command, $number, 0, $command->[$number]);
}

#----------------------------------------------------------------------
# 섬 데이터 입출력
#----------------------------------------------------------------------

# 전체 섬 데이터 읽기
sub readIslandsFile {
 my($num) = @_; # 0이면 지형읽기 전
 # -1이면 전체 지형을 읽어들임
 # 번호가 지정되면 해당 섬의 지형만 읽어들임

 # 데이터 파일 열기
 if(!open(IN, "${HdirName}/hakojima.dat")) {
	rename("${HdirName}/hakojima.tmp", "${HdirName}/hakojima.dat");
	if(!open(IN, "${HdirName}/hakojima.dat")) {
	 return 0;
	}
 }

 # 각매개변수읽기
 $HislandTurn = int(<IN>); # 턴 수

 $HislandLastTime = int(<IN>); # 최종 갱신 시간
 if($HislandLastTime == 0) {
	return 0;
 }
 $HislandNumber = int(<IN>); # 섬의 총 수
 $HislandNextID = int(<IN>); # 다음에 할당할 ID
 $HteamNumber = int(<IN>); # 팀 수
 $HturnCount = int(<IN>); # 갱신 횟수
 $HnextCTurn = int(<IN>); # 전환에 턴
 $HfightMode = int(<IN>); # 현재의 전투 모드
 $HfightCount = int(<IN>); # 몇회전목카

 # 턴 처리판정
 my($now) = time;
 if(((($Hdebug == 1) &&
	($HmainMode eq 'Hdebugturn')) ||
 (($now - $HislandLastTime)>= $HunitTime)) && ($HteamNumber> 1)) {
	$HmainMode = 'turn';
	$num = -1; # 전체 섬읽어들임
 }

 # 섬읽기
 my($i);
 for($i = 0; $i < $HislandNumber; $i++) {
	 $Hislands[$i] = readIsland($num);
	 $HidToNumber{$Hislands[$i]->{'id'}} = $i;
 }

 # 파일을 닫기
 close(IN);

 return 1;
}

# 섬 하나 읽기
sub readIsland {
 my($num) = @_;
 my($name, $id, $prize, $absent, $comment, $password, $food,
 $pop, $area, $farm, $factory, $teamid, $defence, $fire, $ownername);
 $name = <IN>; # 섬 이름
 chomp($name);
 if($name =~ s/,(.*)$//g) {
	$defence = int($1);
 } else {
	$defence = 0;
 }
 $id = int(<IN>); # ID 번호
 $prize = int(<IN>); # 수상
 $absent = int(<IN>); # 연속 자금 조달 수
 $comment = <IN>; # 코멘트
 chomp($comment);
 $password = <IN>; # 암호화 비밀번호
 chomp($password);
 $food = int(<IN>); # 식량
 $pop = int(<IN>); # 인구
 $area = int(<IN>); # 면적
 $farm = int(<IN>); # 농장
 $factory = int(<IN>); # 공장
 $teamid = int(<IN>); # 팀 ID
 $fire = int(<IN>); # 미사일 발사 가능 횟수
 $ownername = <IN>; # 소유자네무
 chomp($ownername);

 # HidToName 테이블에 저장
 $HidToName{$id} = $name;	#

 # 지형
 my(@land, @landValue, $line, @command, @lbbs);

 if(($num == -1) || ($num == $id)) {
	if(!open(IIN, "${HdirName}/island.$id")) {
	 rename("${HdirName}/islandtmp.$id", "${HdirName}/island.$id");
	 if(!open(IIN, "${HdirName}/island.$id")) {
		exit(0);
	 }
	}
	my($x, $y);
	for($y = 0; $y < $HislandSize; $y++) {
	 $line = <IIN>;
	 for($x = 0; $x < $HislandSize; $x++) {
		$line =~ s/^(.)(..)//;
		$land[$x][$y] = hex($1);
		$landValue[$x][$y] = hex($2);
	 }
	}

	# 명령
	my($i);
	for($i = 0; $i < $HcommandMax; $i++) {
	 $line = <IIN>;
	 $line =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	 $command[$i] = {
		'kind' => int($1),
		'target' => int($2),
		'x' => int($3),
		'y' => int($4),
		'arg' => int($5)
		}
	}

	# 로컬 게시판
	for($i = 0; $i < $HlbbsMax; $i++) {
	 $line = <IIN>;
	 chomp($line);
	 $lbbs[$i] = $line;
	}

	close(IIN);
 }

 # 섬 형태로 반환
 return {
	 'name' => $name,
	 'id' => $id,
	 'defence' => $defence,
	 'prize' => $prize,
	 'absent' => $absent,
	 'comment' => $comment,
	 'password' => $password,
	 'food' => $food,
	 'pop' => $pop,
	 'area' => $area,
	 'farm' => $farm,
	 'factory' => $factory,
	 'teamid' => $teamid,
	 'fire' => $fire,
	 'ownername' => $ownername,
	 'land' => \@land,
	 'landValue' => \@landValue,
	 'command' => \@command,
	 'lbbs' => \@lbbs,
 };
}

# 전체 섬 데이터 쓰기
sub writeIslandsFile {
 my($num) = @_;

 # 파일을 열기
 open(OUT, ">${HdirName}/hakojima.tmp");

 # 각매개변수쓰기
 print OUT "$HislandTurn\n";
 print OUT "$HislandLastTime\n";
 print OUT "$HislandNumber\n";
 print OUT "$HislandNextID\n";
 print OUT "$HteamNumber\n";
 print OUT "$HturnCount\n";
 print OUT "$HnextCTurn\n";
 print OUT "$HfightMode\n";
 print OUT "$HfightCount\n";

 # 섬의 쓰기
 my($i);
 for($i = 0; $i < $HislandNumber; $i++) {
	 writeIsland($Hislands[$i], $num);
 }

 # 파일을 닫기
 close(OUT);

 # 원래 이름으로
 unlink("${HdirName}/hakojima.dat");
 rename("${HdirName}/hakojima.tmp", "${HdirName}/hakojima.dat");
}

# 섬 하나 쓰기
sub writeIsland {
 my($island, $num) = @_;
 my($defence);
 $defence = int($island->{'defence'});
 print OUT $island->{'name'}. ",$defence\n";
 print OUT $island->{'id'}. "\n";
 print OUT $island->{'prize'}. "\n";
 print OUT $island->{'absent'}. "\n";
 print OUT $island->{'comment'}. "\n";
 print OUT $island->{'password'}. "\n";
 print OUT $island->{'food'}. "\n";
 print OUT $island->{'pop'}. "\n";
 print OUT $island->{'area'}. "\n";
 print OUT $island->{'farm'}. "\n";
 print OUT $island->{'factory'}. "\n";
 print OUT $island->{'teamid'}. "\n";
 print OUT $island->{'fire'}. "\n";
 print OUT $island->{'ownername'}. "\n";

 # 지형
 if(($num <= -1) || ($num == $island->{'id'})) {
	open(IOUT, ">${HdirName}/islandtmp.$island->{'id'}");

	my($land, $landValue);
	$land = $island->{'land'};
	$landValue = $island->{'landValue'};
	my($x, $y);
	for($y = 0; $y < $HislandSize; $y++) {
	 for($x = 0; $x < $HislandSize; $x++) {
		printf IOUT ("%x%02x", $land->[$x][$y], $landValue->[$x][$y]);
	 }
	 print IOUT "\n";
	}

	# 명령
	my($command, $cur, $i);
	$command = $island->{'command'};
	for($i = 0; $i < $HcommandMax; $i++) {
	 printf IOUT ("%d,%d,%d,%d,%d\n",
			 $command->[$i]->{'kind'},
			 $command->[$i]->{'target'},
			 $command->[$i]->{'x'},
			 $command->[$i]->{'y'},
			 $command->[$i]->{'arg'}
			 );
	}

	# 로컬 게시판
	my($lbbs);
	$lbbs = $island->{'lbbs'};
	for($i = 0; $i < $HlbbsMax; $i++) {
	 print IOUT $lbbs->[$i]. "\n";
	}

	close(IOUT);
	unlink("${HdirName}/island.$island->{'id'}");
	rename("${HdirName}/islandtmp.$island->{'id'}", "${HdirName}/island.$island->{'id'}");
 }
}

#----------------------------------------------------------------------
# 팀 데이터입출력
#----------------------------------------------------------------------

# 전체 섬 데이터 읽기
sub readTeamsFile {

 # 데이터 파일 열기
 if(!open(IN, "${HdirName}/teams.dat")) {
	rename("${HdirName}/teams.tmp", "${HdirName}/teams.dat");
	if(!open(IN, "${HdirName}/teams.dat")) {
	 return 0;
	}
 }
 # 팀읽기
 my($i);
 for($i = 0; $i < $HteamNumber; $i++) {
	 $Hteams[$i] = readTeam();
	 $HidToTeamNumber{$Hteams[$i]->{'id'}} = $i;
 }

 # 파일을 닫기
 close(IN);

 return 1;
}

# 팀하나읽기
sub readTeam {

 my($name, $id, $password, $money, $food, $pop, $farm, $factory, $fightid, $prize, $reward, $rewturn);
 $name = <IN>; # 팀의 이름
 chomp($name);
 $id = int(<IN>); # ID 번호
 $member = <IN>; # 팀원의 섬 ID
 chomp($member);
 $password = <IN>; # 암호화 비밀번호
 chomp($password);
 $money = int(<IN>); # 자금
 $food = int(<IN>); # 식량
 $pop = int(<IN>); # 인구
 $farm = int(<IN>); # 농장
 $factory = int(<IN>); # 공장
 $fightid = int(<IN>); # 상대 팀 ID
 $prize = int(<IN>); # 상
 $reward = int(<IN>); # 보상금
 $rewturn = int(<IN>); # 보상금용 턴 수

 # HidToName 테이블에 저장
 $HidToTeamName{$id} = $name;


 # 섬 형태로 반환
 return {
	 'name' => $name,
	 'id' => $id,
	 'member' => $member,
	 'password' => $password,
	 'money' => $money,
	 'food' => $food,
	 'pop' => $pop,
	 'farm' => $farm,
	 'factory' => $factory,
	 'fightid' => $fightid,
	 'prize' => $prize,
	 'reward' => $reward,
	 'rewturn' => $rewturn,
 };
}

# 전체팀 데이터 쓰기
sub writeTeamsFile {

 # 파일을 열기
 open(OUT, ">${HdirName}/teams.tmp");

 # 섬의 쓰기
 my($i);
 for($i = 0; $i < $HteamNumber; $i++) {
	 writeTeam($Hteams[$i]);
 }

 # 파일을 닫기
 close(OUT);

 # 원래 이름으로
 unlink("${HdirName}/teams.dat");
 rename("${HdirName}/teams.tmp", "${HdirName}/teams.dat");
}

# 팀 데이터하나쓰기
sub writeTeam {

 my($team) = @_;
 print OUT $team->{'name'}. "\n";
 print OUT $team->{'id'}. "\n";
 print OUT $team->{'member'}. "\n";
 print OUT $team->{'password'}. "\n";
 print OUT $team->{'money'}. "\n";
 print OUT $team->{'food'}. "\n";
 print OUT $team->{'pop'}. "\n";
 print OUT $team->{'farm'}. "\n";
 print OUT $team->{'factory'}. "\n";
 print OUT $team->{'fightid'}. "\n";
 print OUT $team->{'prize'}. "\n";
 print OUT $team->{'reward'}. "\n";
 print OUT $team->{'rewturn'}. "\n";

}

#----------------------------------------------------------------------
# 입출력
#----------------------------------------------------------------------

# 표준 출력으로 출력
sub out {
 print STDOUT $_[0];
}


# 전투 기록저장
sub HfightLog {
 my(@fightLog) = @_;
 $fCount2 = $#fightLog + 1;
 push(@offset,"$HfightCount\n");
 push(@offset,"$fCount2\n");
 for($i = 0 ; $i <= $#fightLog; $i++) {
	if($i %2 == 0) {
	 $HbgCell = $HbgInfoCell;
	} else {
	 $HbgCell = $HbgCommentCell;
	}
	my($fight) = $fightLog[$i];
	my($name,$pop,$money,$tname,$tpop,$member) = split(/<>/,$fight);
	push(@offset,"<TR><TD $HbgCell><NOBR> ${HtagTName_}${name}${H_tagTName}</nobr></td>");
	push(@offset,"<TD $HbgCell align=center><NOBR><B>${pop}$HunitPop</b></nobr></td>");
	push(@offset,"<TD $HbgCell><NOBR> ${HtagTName2_}${tname}${H_tagTName2}</nobr></td>");
	push(@offset,"<TD $HbgCell align=center><NOBR><B>${tpop}$HunitPop</b></nobr></td>");
	push(@offset,"<TD $HbgCell align=right><NOBR><B>${money}억 엔</b></nobr></td></TR>");
	push(@offset,"<TR><TD $HbgCell COLSPAN=2><NOBR>${HtagTH_}멤버:${HtagName_}");
	my($island) = '';
	while($member =~ s/([0-9]*),//) {
	 if($1 eq '') {
		push(@offset,"${H_tagName}</NOBR></TD><TD $HbgCell COLSPAN=2><NOBR>${HtagTH_}멤버:${HtagName2_}");
		$island = '';
		next;
	 } elsif($island ne '') {
		push(@offset," : ");
	 }
	 $island = $Hislands[$HidToNumber{$1}];
	 push(@offset,"$island->{'name'} 섬");

	}
	push(@offset,"${H_tagName2}</NOBR></TD><TD $HbgCell> </TD></TR>\n");
 }
}

# 예선 탈락
sub HyosenLog {
 my(@fightLog) = @_;
 $fCount2 = $#fightLog + 1;
 push(@offset,"0\n");
 push(@offset,"$fCount2\n");
 for($i = 0 ; $i <= $#fightLog; $i++) {
	if($i %2 == 0) {
	 $HbgCell = $HbgInfoCell;
	} else {
	 $HbgCell = $HbgCommentCell;
	}
	my($fight) = $fightLog[$i];
	my($name,$pop,$member) = split(/<>/,$fight);
	push(@offset,"<TR><TD $HbgCell><NOBR> ${HtagTName2_}${name}${H_tagTName2}</nobr></td>");
	push(@offset,"<TD $HbgCell align=center><NOBR><B>${pop}$HunitPop</b></nobr></td>");
	push(@offset,"<TR><TD $HbgCell COLSPAN=2><NOBR>${HtagTH_}멤버:${H_tagTH}${HtagName2_}");
	my($island) = '';
	while($member =~ s/([0-9]*),//) {
	 if($island ne '') {
		push(@offset," : ");
	 }
	 $island = $Hislands[$HidToNumber{$1}];
	 push(@offset,"$island->{'name'} 섬");

	}
	push(@offset,"${H_tagName2}</NOBR></TD></TR>\n");
 }
}

# CGI 읽기
sub cgiInput {
 my($line, $getLine);

 # 입력을 받아 UTF-8로 처리
 $line = <>;
 $line =~ tr/+/ /;
 $line =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
 $line = $line;
 $line =~ s/[\x00-\x1f\,]//g;

 # GET 값을 받음
 $getLine = $ENV{'QUERY_STRING'};

 # 대상의 섬
 if($line =~ /CommandButton([0-9]+)=/) {
	# 명령 전송버튼의 경우
	$HcurrentID = $1;
	$defaultID = $1;
 }

 if($line =~ /ISLANDNAME=([^\&]*)\&/){
	# 이름 지정의 경우
	$HcurrentName = cutColumn($1, 32);
 }

 if($line =~ /ISLANDID=([0-9]+)\&/){
	# 기타의 경우
	$HcurrentID = $1;
	$defaultID = $1;
 }

 if($line =~ /TEAMID=([0-9]+)\&/){
	# 기타의 경우
	$HteamID = $1;
 }

 # 비밀번호
 if($line =~ /OLDPASS=([^\&]*)\&/) {
	$HoldPassword = $1;
	$HdefaultPassword = htmlEscape(cutColumn($1,32));
 }
 if($line =~ /PASSWORD=([^\&]*)\&/) {
	$HinputPassword = $1;
	$HdefaultPassword = htmlEscape(cutColumn($1,32));
 }
 if($line =~ /PASSWORD2=([^\&]*)\&/) {
	$HinputPassword2 = $1;
 }

 # 메시지
 if($line =~ /MESSAGE=([^\&]*)\&/) {
	$Hmessage = cutColumn($1, 80);
 }

 if($line =~ /JAVAMODE=(cgi|java)/) {
	$HjavaMode = $1;
 }

 if($line =~ /CommandJavaButton([0-9]+)=/) {
	# 명령 전송버튼의 경우(Java스크립트)
	$HcurrentID = $1;
	$defaultID = $1;
 }

 # 로컬 게시판
 if($line =~ /LBBSNAME=([^\&]*)\&/) {
	$HlbbsName = $1;
	$HdefaultName = htmlEscape(cutColumn($1,32));
 }
 if($line =~ /LBBSMESSAGE=([^\&]*)\&/) {
	$HlbbsMessage = cutColumn($1, 80);
 }
 if($line =~ /OWNERNAME=([^\&]*)\&/){
	# 소유자 이름 지정의 경우
	$HownerName = cutColumn($1, 22);
 }

 if($line =~ /IMGLINEMAC=([^&]*)\&/){
	my($flag) = 'file:///'. $1;
	$HimgLine = htmlEscape($flag);
 }

 if($line =~ /IMGLINE=([^&]*)\&/){
	my($flag) = substr($1, 0, -10);
	$flag =~ tr/\\/\//;
	if($flag eq 'del'){ $flag = $imageDir; } else { $flag = 'file:///'. $flag; }
	$HimgLine = htmlEscape($flag);
 }

 if($line =~ /CTEAMNAME=([^\&]*)\&/){
	# 팀 이름 지정의 경우
	$teamName = $1;
 }

 if($line =~ /DELISLAND=([0-9]+)\&/){
	# 삭제용
	$deleteID = $1;
 }

 # main mode 의가져오기
 if($line =~ /TurnButton/) {
	if($Hdebug == 1) {
	 $HmainMode = 'Hdebugturn';
	}
 } elsif($line =~ /OwnerButton/) {
	$HmainMode = 'owner';
 } elsif($line =~ /teamData/) {
	$HmainMode = 'teamdata';
 } elsif($line =~ /ChangeOwnerName/) {
	$HmainMode = 'change';
 } elsif($line =~ /ChangeTeamName/) {
	$HmainMode = 'HchangeTName';
 } elsif($getLine =~ /Sight=([0-9]*)/) {
	$HmainMode = 'print';
	$HcurrentID = $1;
 } elsif($getLine =~ /IslandMap=([0-9]*)/) {
	$HmainMode = 'landmap';
	$HcurrentID = $1;
 } elsif($getLine =~ /TEAM=([0-9]*)/) {
	$HteamMode = $1;
 } elsif($line =~ /AdminPage/) {
	$HmainMode = 'adminpage';
 } elsif($line =~ /DeleteIsland/) {
 $HmainMode = 'delete';		# 삭제 모드
 } elsif($getLine =~ /FightLog/) {
	$HmainMode = 'fightlog';
 } elsif($getLine =~ /HELP/) {
	$HmainMode = 'help';
 } elsif($line =~ /NewIslandButton/) {
	$HmainMode = 'new';
 } elsif($getLine =~ /LogFileView=([0-9]*)/) {
	$HmainMode = 'logView';
	$Hlogturn = ($1> $HlogMax) ? $HlogMax : $1;
 } elsif($getLine =~ /LogFileTeam=([0-9]*)/) {
	$HmainMode = 'logTeam';
	$HlogteamID = $1;
 } elsif($line =~ /LbbsButton(..)([0-9]*)/) {
	$HmainMode = 'lbbs';
	if($1 eq 'FO') {
	 # 관광객
	 $HlbbsMode = 0;
	 $HforID = $HcurrentID;
	} elsif($1 eq 'OW') {
	 # 섬주
	 $HlbbsMode = 1;
	} else {
	 # 삭제
	 $HlbbsMode = 2;
	}
	$HcurrentID = $2;

	# 삭제할 수 없으므로 번호를 가져옴
	$line =~ /NUMBER=([^\&]*)\&/;
	$HcommandPlanNumber = $1;

 } elsif($line =~ /ChangeInfoButton/) {
	$HmainMode = 'change';
 } elsif($line =~ /MessageButton([0-9]*)/) {
	$HmainMode = 'comment';
	$HcurrentID = $1;
 } elsif($line =~ /CommandJavaButton/) {
	$HmainMode = 'commandJava';
	$line =~ /COMARY=([^\&]*)\&/;
	$HcommandComary = $1;
 } elsif($line =~ /CommandButton/) {
	$HmainMode = 'command';

	# 명령 모드의 경우, 명령의 가져오기
	$line =~ /NUMBER=([^\&]*)\&/;
	$HcommandPlanNumber = $1;
	$line =~ /COMMAND=([^\&]*)\&/;
	$HcommandKind = $1;
	$HdefaultKind = $1;
	$line =~ /AMOUNT=([^\&]*)\&/;
	$HcommandArg = $1;
	$line =~ /TARGETID=([^\&]*)\&/;
	$HcommandTarget = $1;
	$defaultTarget = $1;
	$line =~ /POINTX=([^\&]*)\&/;
	$HcommandX = $1;
	$HdefaultX = $1;
 $line =~ /POINTY=([^\&]*)\&/;
	$HcommandY = $1;
	$HdefaultY = $1;
	$line =~ /COMMANDMODE=(write|insert|delete)/;
	$HcommandMode = $1;
 } else {
	$HmainMode = 'top';
 }

}


#cookie 입력
sub cookieInput {
 my($cookie);

 $cookie = htmlEscape($ENV{'HTTP_COOKIE'});

 if($cookie =~ /${HthisFile}OWNISLANDID=\(([^\)]*)\)/) {
	$defaultID = $1;
 }
 if($cookie =~ /${HthisFile}OWNISLANDPASSWORD=\(([^\)]*)\)/) {
	$HdefaultPassword = $1;
 }
 if($cookie =~ /${HthisFile}TARGETISLANDID=\(([^\)]*)\)/) {
	$defaultTarget = $1;
 }
 if($cookie =~ /${HthisFile}LBBSNAME=\(([^\)]*)\)/) {
	$HdefaultName = $1;
 }
 if($cookie =~ /${HthisFile}POINTX=\(([^\)]*)\)/) {
	$HdefaultX = $1;
 }
 if($cookie =~ /${HthisFile}POINTY=\(([^\)]*)\)/) {
	$HdefaultY = $1;
 }
 if($cookie =~ /${HthisFile}KIND=\(([^\)]*)\)/) {
	$HdefaultKind = $1;
 }
 if($cookie =~ /${HthisFile}IMGLINE=\(([^\)]*)\)/) {
	$HimgLine = $1;
 }
 if($cookie =~ /${HthisFile}JAVAMODE=\(([^\)]*)\)/) {
	$CjavaMode = $1;
 }
}

#cookie 출력
sub cookieOutput {
 my($cookie, $info);

 # 삭제 가능 기한 설정
 my($sec, $min, $hour, $date, $mon, $year, $day, $yday, $dummy) =
	gmtime(time + 30 * 86400); # 현재 + 30일

 # 2자리화
 $year += 1900;
 if ($date < 10) { $date = "0$date"; }
 if ($hour < 10) { $hour = "0$hour"; }
 if ($min < 10) { $min = "0$min"; }
 if ($sec < 10) { $sec = "0$sec"; }

 # 요일일을 문자에
 $day = ("Sunday", "Monday", "Tuesday", "Wednesday",
	 "Thursday", "Friday", "Saturday")[$day];

 # 월을 문자에
 $mon = ("Jan", "Feb", "Mar", "Apr", "May", "Jun",
	 "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")[$mon];

 # 경로와 기간 설정
 $info = "; expires=$day, $date\-$mon\-$year $hour:$min:$sec GMT\n";
 $cookie = '';

 if(($HcurrentID) && ($HmainMode eq 'owner')){
	$cookie.= "Set-Cookie: ${HthisFile}OWNISLANDID=($HcurrentID) $info";
 }
 if($HinputPassword) {
	$cookie.= "Set-Cookie: ${HthisFile}OWNISLANDPASSWORD=($HinputPassword) $info";
 }
 if($HcommandTarget) {
	$cookie.= "Set-Cookie: ${HthisFile}TARGETISLANDID=($HcommandTarget) $info";
 }
 if($HlbbsName) {
	$cookie.= "Set-Cookie: ${HthisFile}LBBSNAME=($HlbbsName) $info";
 }
 if($HcommandX) {
	$cookie.= "Set-Cookie: ${HthisFile}POINTX=($HcommandX) $info";
 }
 if($HcommandY) {
	$cookie.= "Set-Cookie: ${HthisFile}POINTY=($HcommandY) $info";
 }
 if($HcommandKind) {
	# 자동 입력 이외
	$cookie.= "Set-Cookie: ${HthisFile}KIND=($HcommandKind) $info";
 }
 if($HimgLine) {
	$cookie.= "Set-Cookie: ${HthisFile}IMGLINE=($HimgLine) $info";
 }
 if($HjavaMode) {
	$cookie.= "Set-Cookie: ${HthisFile}JAVAMODE=($HjavaMode) $info";
 }
 print $cookie;
}

#----------------------------------------------------------------------
# 유티리티
#----------------------------------------------------------------------
sub hakolock {
 if($lockMode == 1) {
	# directory 방식 잠금
	return hakolock1();

 } elsif($lockMode == 2) {
	# flock 방식 잠금
	return hakolock2();
 } elsif($lockMode == 3) {
	# symlink 방식 잠금
	return hakolock3();
 } else {
	# 일반 파일 방식 잠금
	return hakolock4();
 }
}

sub hakolock1 {
 # 잠금을 시도
 if(mkdir('hakojimalock', $HdirMode)) {
	# 성공
	return 1;
 } else {
	# 실패
	my($b) = (stat('hakojimalock'))[9];
	if(($b> 0) && ((time() - $b)> $unlockTime)) {
	 # 강제 해제
	 unlock();

	 # 헤더출력
	 tempHeader();

	 # 강제 해제 메시지
	 tempUnlock();

	 # 푸터출력
	 tempFooter();

	 # 종료
	 exit(0);
	}
	return 0;
 }
}

sub hakolock2 {
 open(LOCKID, '>>hakojimalockflock');
 if(flock(LOCKID, 2)) {
	# 성공
	return 1;
 } else {
	# 실패
	return 0;
 }
}

sub hakolock3 {
 # 잠금을 시도
 if(symlink('hakojimalockdummy', 'hakojimalock')) {
	# 성공
	return 1;
 } else {
	# 실패
	my($b) = (lstat('hakojimalock'))[9];
	if(($b> 0) && ((time() - $b)> $unlockTime)) {
	 # 강제 해제
	 unlock();

	 # 헤더출력
	 tempHeader();

	 # 강제 해제 메시지
	 tempUnlock();

	 # 푸터출력
	 tempFooter();

	 # 종료
	 exit(0);
	}
	return 0;
 }
}

sub hakolock4 {
 # 잠금을 시도
 if(unlink('key-free')) {
	# 성공
	open(OUT, '>key-locked');
	print OUT time;
	close(OUT);
	return 1;
 } else {
	# 잠금 시간 확인
	if(!open(IN, 'key-locked')) {
	 return 0;
	}

	my($t);
	$t = <IN>;
	close(IN);
	if(($t != 0) && (($t + $unlockTime) < time)) {
	 # 120초 이상 경과하면 강제로 잠금을 해제
	 unlock();

	 # 헤더출력
	 tempHeader();

	 # 강제 해제 메시지
	 tempUnlock();

	 # 푸터출력
	 tempFooter();

	 # 종료
	 exit(0);
	}
	return 0;
 }
}

# 잠금을 해제
sub unlock {
 if($lockMode == 1) {
	# directory 방식 잠금
	rmdir('hakojimalock');

 } elsif($lockMode == 2) {
	# flock 방식 잠금
	close(LOCKID);

 } elsif($lockMode == 3) {
	# symlink 방식 잠금
	unlink('hakojimalock');
 } else {
	# 일반 파일 방식 잠금
	my($i);
	$i = rename('key-locked', 'key-free');
 }
}

# 작은 쪽을 반환
sub min {
 return ($_[0] < $_[1]) ? $_[0] : $_[1];
}

# 비밀번호엔코드
sub encode {
 if($cryptOn == 1) {
	return crypt($_[0], 'h2');
 } else {
	return $_[0];
 }
}

# 비밀번호 확인
sub checkPassword {
 my($p1, $p2) = @_;

 # null 확인
 if($p2 eq '') {
	return 0;
 }

 # 마스터 비밀번호 확인
 if($masterPassword eq $p2) {
	return 1;
 }

 # 본래의 확인
 if($p1 eq encode($p2)) {
	return 1;
 }

 return 0;
}

# 1000억단위원형메루틴
sub aboutMoney {
 my($m) = @_;
 if($m < 500) {
	return "추정500${HunitMoney}미만";
 } else {
	$m = int(($m + 500) / 1000);
	return "추정${m}000${HunitMoney}";
 }
}

# 이스케이프문자의 처리
sub htmlEscape {
 my($s) = @_;
 $s =~ s/&/&amp;/g;
 $s =~ s/</&lt;/g;
 $s =~ s/>/&gt;/g;
 $s =~ s/\"/&quot;/g; #"
 $s =~ s/'/&#39;/g;
 $s =~ s/ /&#32;/g;
 return $s;
}

# 80자리에절리갖춤에
sub cutColumn {
 my($s, $c) = @_;
 if(length($s) <= $c) {
	return $s;
 } else {
	# 합계80자리가 됨까지절리 처리
	my($ss) = '';
	my($count) = 0;
	while($count < $c) {
	 $s =~ s/(^[\x80-\xFF][\x80-\xFF])|(^[\x00-\x7F])//;
	 if($1) {
		$ss.= $1;
		$count ++;
	 } else {
		$ss.= $2;
	 }
	 $count ++;
	}
	return $ss;
 }
}

# 섬 이름으로 번호를 얻음(ID가 아니라 번호)
sub nameToNumber {
 my($name) = @_;

 # 전체 섬에서 찾기
 my($i);
 for($i = 0; $i < $HislandNumber; $i++) {
	if($Hislands[$i]->{'name'} eq $name) {
	 return $i;
	}
 }

 # 찾을 수 없었던 경우
 return -1;
}

# 팀 이름에서 번호를 얻음(ID가 없으면 번호)
sub nameToTeamNumber {
 my($name) = @_;

 # 전체 섬에서 찾기
 my($i);
 for($i = 0; $i < $HteamNumber; $i++) {
	if($Hteams[$i]->{'name'} eq $name) {
	 return $i;
	}
 }

 # 찾을 수 없었던 경우
 return -1;
}

# 경험치에서 레벨을 산출
sub expToLevel {
 my($kind, $exp) = @_;
 my($i);
 if($kind == $HlandBase) {
	# 미사일 기지
	for($i = $maxBaseLevel; $i> 1; $i--) {
	 if($exp>= $baseLevelUp[$i - 2]) {
		return $i;
	 }
	}
	return 1;
 } else {
	# 해저 기지
	for($i = $maxSBaseLevel; $i> 1; $i--) {
	 if($exp>= $sBaseLevelUp[$i - 2]) {
		return $i;
	 }
	}
	return 1;
 }

}

# (0,0)에서(size - 1, size - 1)까지의 숫자가한 번씩 나오도록
# (@Hrpx, @Hrpy)을 설정
sub makeRandomPointArray {
 # 초기 값
 my($y);
 @Hrpx = (0..$HislandSize-1) x $HislandSize;
 for($y = 0; $y < $HislandSize; $y++) {
	push(@Hrpy, ($y) x $HislandSize);
 }

 # 셔터 전체
 my ($i);
 for ($i = $HpointNumber; --$i; ) {
	my($j) = int(rand($i+1));
	if($i == $j) { next; }
	@Hrpx[$i,$j] = @Hrpx[$j,$i];
	@Hrpy[$i,$j] = @Hrpy[$j,$i];
 }
}

# 0에서(n - 1)의 난수
sub random {
 return int(rand(1) * $_[0]);
}

#----------------------------------------------------------------------
# 로그 표시
#----------------------------------------------------------------------
# 파일 번호를 지정해 로그 표시
sub logFilePrint {
 my($fileNumber, $id, $mode, $kankou) = @_;
 open(LIN, "${HdirName}/hakojima.log$_[0]");
 my($line, $m, $turn, $id1, $id2, $message);
 my($fi) = 0;

 while($line = <LIN>) {
	$line =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),(.*)$/;
	($m, $turn, $id1, $id2, $message) = ($1, $2, $3, $4, $5);

	# 기밀관계
	if($m == 1) {
	 if(($mode == 0) || ($id1 != $id)) {
		# 기밀 표시 권한 없음
		next;
	 }
	 $m = '<B>(기밀)</B>';
	} else {
	 $m = '';
	}

	# 정확히 표시할지
	if($id != 0) {
	 if(($id != $id1) &&
	 ($id != $id2)) {
		next;
	 }
	}

	# 표시
	if($kankou == 1) {

	out("<NOBR>${HtagNumber_}턴$turn$m${H_tagNumber}:$message</NOBR><BR>\n");

 } elsif(($fi == 0) && ($mode == 0)) {
 out("<NOBR><BR><B><I><FONT COLOR='#000000' SIZE=+2>턴$turn$m:</FONT></I></B><BR><HR width=50% align=left>\n");
	out("<NOBR>${HtagNumber_}턴$turn$m${H_tagNumber}:$message</NOBR><BR>\n");
	 $fi++;
	} else {
	out("<NOBR>${HtagNumber_}턴$turn$m${H_tagNumber}:$message</NOBR><BR>\n");
	}
 }
#	out("<hr>\n");
 close(LIN);
}
#----------------------------------------------------------------------
# 템플릿
#----------------------------------------------------------------------
# 초기화
sub tempInitialize {
 # 섬 선택(기본값은 자신)
 $HislandList = getIslandList($defaultID);
}

# 섬 데이터 드롭다운 메뉴용
sub getIslandList {
 my($select) = @_;
 my($list, $name, $id, $s, $i);

 #섬 목록의 메뉴
 $list = '';
 for($i = 0; $i < $HislandNumber; $i++) {
	$name = $Hislands[$i]->{'name'};
	$id = $Hislands[$i]->{'id'};
	if($id eq $select) {
	 $s = 'SELECTED';
	} else {
	 $s = '';
	}
	$list.=
	 "<OPTION VALUE=\"$id\" $s>${name} 섬\n";
 }
 return $list;
}

# 섬 데이터 드롭다운 메뉴용
sub getTargetList {
 my($id,$tId) = @_;
 my($list, $s, $tTeam, $island, $tNumMember);
 my($team) = $Hteams[$HidToTeamNumber{$id}];
 $currentTNumber = $HidToTeamNumber{$tId};
 if($currentTNumber ne '') {
	$tTeam = $Hteams[$currentTNumber];
	$tNumMember = $tTeam->{'member'};
 }
 $list = '';

 #섬 목록의 메뉴
 while($tNumMember =~ s/([0-9]*),//) {
	$island = $Hislands[$HidToNumber{$1}];
	if($island->{'id'} eq $defaultTarget) {
	 $s = 'SELECTED';
	} else {
	 $s = '';
	}
	$list.= "<OPTION VALUE=\"$island->{'id'}\" $s>$island->{'name'} 섬\n";
 }
 my($numMember) = $team->{'member'};
 while($numMember =~ s/([0-9]*),//) {
	$island = $Hislands[$HidToNumber{$1}];
	if($island->{'id'} eq $defaultTarget) {
	 $s = 'SELECTED';
	} else {
	 $s = '';
	}
	$list.= "<OPTION VALUE=\"$island->{'id'}\" $s>$island->{'name'} 섬\n";
 }
 return $list;
}

# 헤더
sub tempHeader {
	out("Content-type: text/html; charset=UTF-8\n\n");
	my($HimgFlag) = 0;
		 $baseIMG = $imageDir;
	 $HimgFlag = 1;
	$baseIMG =~ s/데스크톱/데스크톱/g;
 out(<<END);
<HTML>
<HEAD>
<TITLE>
$Htitle
</TITLE>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
<STYLE type="text/css">
<!--
a:link { color:#3300CC }
a:visited { color:#3300CC }
a:active { color:#FF0000 }
a:hover { color:#FF0000 }
small { font-size: 9pt}
-->
</STYLE>
<SCRIPT Language="JavaScript">
<!--
function ShowMsg(n){
	window.status = n;
}
//-->
</SCRIPT>
<BASE HREF="$baseIMG/">
</HEAD>
$Body<nobr>
<A HREF="http://t.pos.to/hako/">모형정원 제도 스크립트 배포처</A> /
<A HREF="http://appoh.execweb.cx/hakoniwa/">모형정원 JavaScript판 배포처</A>
<A HREF="http://espion.just-size.jp/archives/dist_hako/">모형정원 팀 토너먼트 배포처 </A>
<BR>
<IMG SRC="$cleangif" width=0 height=3><BR>
 <A HREF="$toppage">톱 페이지</A> /
<A HREF="$bbs">$bbsname</A> /
<A HREF="$HthisFile?LogFileView=1">최근 사건</A> /
<A HREF="$HthisFile?LogFileTeam=0">팀별도 사건</A> /
<A HREF="$HthisFile?HELP"> 설정도움말</A></nobr>
<DIV ALIGN=RIGHT>
</DIV>
<HR>
END
if($HimgFlag) {
 out(<<END);
<FONT COLOR=RED><B>서버 부하를 줄이기 위해 압축파일을 등록, 이미지 경로 설정을 할수있게 해뒀습니다.</B></FONT><HR>
END
}
}

# 푸터
sub tempFooter {
 out(<<END);
<HR>
<P align=right>
<NOBR>
<A HREF="http://t.pos.to/hako/">모형정원 제도 스크립트 배포처</A> /
<A HREF="http://appoh.execweb.cx/hakoniwa/">모형정원 JavaScript판 배포처</A>
<BR>
<IMG SRC="$cleangif" width=600 height=3><BR>
<A HREF="$toppage">톱 페이지</A> /
<A HREF="$bbs">$bbsname</A> /
<A HREF="$HthisFile?LogFileView=1">최근 사건</A> /
<A HREF="$HthisFile?LogFileTeam=0">팀별도 사건</A> /
<A HREF="$HthisFile?HELP"> 설정도움말</A>
</nobr><BR><BR>
관리자:$adminName(<A HREF="mailto:$email">$email</A>)<BR>
</P>
</BODY>
</HTML>
END
}

# 잠금실패
sub tempLockFail {
 # 제목
 out(<<END);
${HtagBig_}동시접속오류입니다.<BR>
브라우저의'돌아가기'버튼을 누름시,<BR>
잠시 기다렸다가 다시오시 도시하세요.${H_tagBig}$HtempBack
END
}

# 강제 해제
sub tempUnlock {
 # 제목
 out(<<END);
${HtagBig_}지난 접속이 비정상 종료된 것 같습니다.<BR>
잠금을 강제 해제했습니다.${H_tagBig}$HtempBack
END
}

# hakojima.dat 이 없음
sub tempNoDataFile {
 out(<<END);
${HtagBig_}데이터 파일을 열 수 없습니다.${H_tagBig}$HtempBack
END
}

# 비밀번호 오류
sub tempWrongPassword {
 out(<<END);
${HtagBig_} 비밀번호가 다릅니다.${H_tagBig}$HtempBack
END
}

# 멤 최대 수보다 많음이
sub tempOverMember {
 out(<<END);
${HtagBig_}이 팀에는 더 이상 들어갈 수 없습니다.${H_tagBig}$HtempBack
END
}

# 무언가문제발생
sub tempProblem {
 out(<<END);
${HtagBig_}문제발생, 일단복귀해 주세요.${H_tagBig}$HtempBack
END
}
