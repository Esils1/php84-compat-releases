#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}
#----------------------------------------------------------------------
# 모형정원 제도 ver2.30
# 톱 페이지 모듈(ver1.00)
# 사용 조건과 사용 방법은 hako-readme.txt 파일을 참조해 주세요
#
# 모형정원 제도의 페이지: http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html
#----------------------------------------------------------------------
# 모형정원 팀 토너먼트
# 톱 페이지 모듈
# $Id: hako-top.cgi 12 2004-02-18 05:24:25Z gaba $

#----------------------------------------------------------------------
# 톱 페이지 모드
#----------------------------------------------------------------------
# 메인
sub topPageMain {
 # 개방
 unlock();

 # 템플릿출력
 tempTopPage();
}

# 톱 페이지
sub tempTopPage {

my($fightmode);

if($HislandTurn < $HyosenTurn){
 $fightmode = '<font color=blue>개발 기간</font>[턴'. ($HyosenTurn). '까지예선]';
} elsif($HfightMode) {
 $fightmode = '<font color=red>전투 기간</font>';
 if($HnextCTurn == $HislandTurn){
 $fightmode.= '[다음 턴보다<font color=blue>개발 기간</font>]';
 } else {
 $fightmode.= '[턴'. ($HnextCTurn). '까지전투]';
 }
} else {
 $fightmode = '<font color=blue>개발 기간</font>';
 if($HnextCTurn == $HislandTurn){
 $fightmode.= '[다음 턴보다<font color=red>전투 시작</font>]';
 } else {
 $fightmode.= '[턴'. ($HnextCTurn + 1). '보다전투 시작]';
 }
}
 # 제목
 out(<<END);
${HtagTitle_}$Htitle${H_tagTitle}
END
if($HteamNumber == 2 && $HislandTurn != 0){
 out(<<END);
${HtagFico_}≪결승전≫${H_tagFico}
END
} elsif($HteamNumber == 1 && $HislandTurn != 0) {
 out(<<END);
${HtagFico_}≪종료≫${H_tagFico}
END
} elsif($HislandTurn < $HyosenTurn) {
 out(<<END);
${HtagFico_}≪예선≫${H_tagFico}
END
} else {
 out(<<END);
${HtagFico_}≪제$HfightCount 회전≫${H_tagFico}
END
}
 # 디버그 모드이면 '턴 진행' 버튼
 if($Hdebug == 1) {
 out(<<END);
<FORM action="$HthisFile" method="POST">
<INPUT TYPE="submit" VALUE="턴을 진행하기" NAME="TurnButton">
</FORM>
END
 }

 my($mStr1) = '';
 if($HhideMoneyMode != 0) {
	$mStr1 = "<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_} 자금${H_tagTH}</NOBR></TH>";
 }
 if($CjavaMode eq java) {
	$javacheck = 'checked';
 } else { $cgicheck = 'checked'; }
 out(<<END);
<H1>${HtagHeader_}턴$HislandTurn${H_tagHeader} $fightmode</H1>
END

# 시간 표시
my($hour, $min, $sec);
my($now) = time;
my($showTIME) = ($HislandLastTime + $HunitTime - $now);
$hour = int($showTIME / 3600);
$min = int(($showTIME - ($hour * 3600)) / 60);
$sec = $showTIME - ($hour * 3600) - ($min * 60);
if ($sec < 0){
 if($HteamNumber> 1) {
 out("<B><font size=+1>(${HtagHeader_}갱신해 주세요${H_tagHeader})</font></b>");
 }
} else {
 out("<B><font size=+1>(다음 턴까지, 남은 $hour 시간 $min 분 $sec 초)</font></b>");
}
 # 양식
 out(<<END);
<SCRIPT language="JavaScript">
<!--
function develope(){

		//window.open("", "newWin");
		document.Island.target = "newWin";
		document.Island.submit();

		document.Island.target = "";
		return true;
}

//-->
</SCRIPT>
<HR>
<H1>${HtagHeader_}자신의 섬으로${H_tagHeader}</H1>
<FORM name="Island" action="$HthisFile" method="POST">
당신의 섬 이름은?<BR>
<SELECT NAME="ISLANDID">
$HislandList
</SELECT><BR>
<INPUT TYPE=HIDDEN NAME="OwnerButton">
비밀번호 입력!!<BR>
<INPUT TYPE="password" NAME="PASSWORD" VALUE="$HdefaultPassword" SIZE=32 MAXLENGTH=32><BR>
<INPUT TYPE="submit" VALUE="개발 화면으로">
<INPUT TYPE="BUTTON" VALUE="새창" onClick="develope()"><BR>
<INPUT TYPE="radio" NAME=JAVAMODE VALUE=cgi $cgicheck>일반 모드
<INPUT TYPE="radio" NAME=JAVAMODE VALUE=java $javacheck>JavaScript 모드
<BR>
</FORM>
<a name=data>
<HR>
<BR>
<a href="$HthisFile?LogFileView=1" STYlE="text-decoration:none">
<font size=+1><b>${HtagHeader_}[최근사건]${H_tagHeader}</b></font></a>

<a href="$HthisFile?LogFileTeam=${HteamMode}" STYlE="text-decoration:none">
<font size=+1><b>${HtagHeader_}[팀별도 사건]${H_tagHeader}</b></font></a>

<a href="$HthisFile?FightLog" STYlE="text-decoration:none">
<font size=+1><b>${HtagHeader_}[대전 기록]${H_tagHeader}</b></font></a>
<BR><BR>
<HR>
END
if($HteamMode == 0 and $HteamMode ne '') {
 out(<<END);
<TABLE><TR><TD WIDTH=250>
<H1>${HtagHeader_}섬의 정보${H_tagHeader}</H1></TD>
<TD>
<FORM ACTION="${HthisFile}" METHOD=GET>
<INPUT TYPE=SUBMIT VALUE="팀의 상황 목록 표시">
</FORM>
</TD></TR></TABLE>
<P>
섬 이름을 클릭하면,<B>관광</B>할 수 있습니다.<BR>
팀의 이름을 클릭하면, 팀 섬의 목록을 표시합니다.
</P>
<TABLE BORDER>
<TR>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}순위${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_} 섬${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}소속팀${H_tagTH}/${HtagTH_}상대 팀${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}인구${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}면적${H_tagTH}</NOBR></TH>
$mStr1
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}식량${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}농장규모${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}공장규모${H_tagTH}</NOBR></TH>
</TR>
END

 my($island, $j, $farm, $factory, $name, $id, $prize, $ii, $team);
 for($ii = 0; $ii < $HislandNumber; $ii++) {
	$j = $ii + 1;
	$island = $Hislands[$ii];
	$team = $Hteams[$HidToTeamNumber{$island->{'teamid'}}];
	$id = $island->{'id'};
	$farm = $island->{'farm'};
	$factory = $island->{'factory'};
	$farm = ($farm == 0) ? "보유하지 않음" : "${farm}0$HunitPop";
	$factory = ($factory == 0) ? "보유하지 않음" : "${factory}0$HunitPop";
	if($island->{'absent'} == 0) {
		$name = "${HtagName_}$island->{'name'} 섬${H_tagName}";
	} else {
	 $name = "${HtagName2_}$island->{'name'} 섬($island->{'absent'})${H_tagName2}";
	}

	$flags = $island->{'prize'};
	$prize = '';

	# 이름에 순위 표시 문자를 추가
	my($f) = 1;
	my($i);
	for($i = 1; $i < 10; $i++) {
	 if($flags & $f) {
		$prize.= "<IMG SRC=\"prize${i}.gif\" ALT=\"${Hprize[$i]}\" WIDTH=16 HEIGHT=16> ";
	 }
	 $f *= 2;
	}

	my($mStr1) = '';
	if($HhideMoneyMode == 1) {
	 $mStr1 = "<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$Hteams[$HidToTeamNumber{$island->{'teamid'}}]->{'money'}$HunitMoney</NOBR></TD>";
	} elsif($HhideMoneyMode == 2) {
	 my($mTmp) = aboutMoney($Hteams[$HidToTeamNumber{$island->{'teamid'}}]->{'money'});
	 $mStr1 = "<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$mTmp</NOBR></TD>";
	}
	my($fightName) = '';
	if($team->{'fightid'}) {
	 $fightName = " VS <A STYlE=\"text-decoration:none\" HREF=$HthisFile?TEAM=$team->{'fightid'}#data>${HtagTName_}$Hteams[$HidToTeamNumber{$team->{'fightid'}}]->{'name'}${H_tagTName}</A>";
	} else {
	 $fightName = "${HtagName_}<CENTER>- - -${H_tagName}</CENTER>";
	}
	my($comname) ="${HtagTH_}코멘트:${H_tagTH}";
	if(($island->{'ownername'} ne '0') && ($island->{'ownername'} ne "코멘트")){
	 $comname = "<FONT COLOR=\"blue\"><B>$island->{'ownername'}:</b></font>";
	}
	out(<<END);
<TR>
<TD $HbgNumberCell ROWSPAN=2 align=center nowrap=nowrap><NOBR>${HtagNumber_}$j${H_tagNumber}</NOBR></TD>
<TD $HbgNameCell ROWSPAN=2 align=left nowrap=nowrap>
<NOBR>
<A STYlE=\"text-decoration:none\" HREF="${HthisFile}?Sight=${id}">
$name
</A>
</NOBR><BR>
$prize
</TD>
<TD $HbgInfoCell align=left nowrap=nowrap>
<NOBR><A STYlE=\"text-decoration:none\" HREF=$HthisFile?TEAM=$team->{'id'}#data>${HtagTName_}$team->{'name'}${H_tagTName}</A></NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap>
<NOBR>$island->{'pop'}$HunitPop</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$island->{'area'}$HunitArea</NOBR></TD>
$mStr1
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$island->{'food'}$HunitFood</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$farm</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$factory</NOBR></TD>
</TR>
<TR>
<TD $HbgInfoCell align=left nowrap=nowrap>
<NOBR>$fightName</NOBR></TD>
<TD $HbgCommentCell COLSPAN=6 align=left nowrap=nowrap><NOBR>${HtagTH_}$comname${H_tagTH}$island->{'comment'}</NOBR></TD>
</TR>
END
 }


} elsif($HteamMode) {

 my($team, $g, $tname, $tmoney, $tpop, $tfarm, $tfactory, $jj, $flags, $prize);
 $number = $HidToTeamNumber{$HteamMode};
 $team = $Hteams[$number];
 if($number ne '') {

	$jj = $number + 1;
	$id = $team->{'id'};
	$tfarm = $team->{'farm'};
	$tfactory = $team->{'factory'};
	$tfarm = ($tfarm == 0) ? "보유하지 않음" : "${tfarm}0$HunitPop";
	$tfactory = ($tfactory == 0) ? "보유하지 않음" : "${tfactory}0$HunitPop";
	my($numMember) = $team->{'member'};
	my($member) = '';
	while($numMember =~ s/([0-9]*),//) {
	 push(@islanddata,$HidToNumber{$1});
	}
	@islanddata = sort { $a <=> $b } @islanddata;
	$flags = $team->{'prize'};
	$prize = '';

	# 이름에 순위 표시 문자를 추가
	my($f) = 1;
	my($i);
	for($i = 1; $i < 10; $i++) {
	 if($flags & $f) {
		$prize.= "<IMG SRC=\"prize${i}.gif\" ALT=\"${Hprize[$i]}\" WIDTH=16 HEIGHT=16> ";
	 }
	 $f *= 2;
	}

	my($mStr2) = '';
	if($HhideMoneyMode == 1) {
	 $mStr2 = "<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$team->{'money'}$HunitMoney</NOBR></TD>";
	} elsif($HhideMoneyMode == 2) {
	 my($mTmp) = aboutMoney($team->{'money'});
	 $mStr2 = "<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$mTmp</NOBR></TD>";
	}
	my($fightName) = '';
	if($team->{'fightid'}> 0) {
	 $fightName = "<A STYlE=\"text-decoration:none\" HREF=$HthisFile?TEAM=$team->{'fightid'}#data>${HtagTName_}$Hteams[$HidToTeamNumber{$team->{'fightid'}}]->{'name'}${H_tagTName}</A>";
	} else {
	 $fightName = "${HtagName_}<CENTER>- - -${H_tagName}</CENTER>";
	}

 out(<<END);
<TABLE><TR><TD WIDTH=250>
<NOBR><H1>${HtagHeader_}$team->{'name'}의상황${H_tagHeader} </H1></NOBR></TD>
<TD>
<FORM ACTION="${HthisFile}" METHOD=GET>
 <INPUT TYPE=HIDDEN VALUE="0" NAME="TEAM">
<INPUT TYPE=SUBMIT VALUE="섬의 정보">
</FORM>
</TD>
<TD>
<FORM ACTION="${HthisFile}" METHOD=GET>
 <INPUT TYPE=SUBMIT VALUE="팀의 상황 목록">
</FORM>
</TD>
</TR></TABLE>
<FORM ACTION="${HthisFile}#data" METHOD=GET>
<SELECT NAME="TEAM">
END
for($if = 0;$if < $HteamNumber;$if++) {
	if($team->{'id'} == $Hteams[$if]->{'id'}) {
	 out("<OPTION VALUE=$Hteams[$if]->{'id'} SELECTED>$Hteams[$if]->{'name'}\n");
	} else {
	 out("<OPTION VALUE=$Hteams[$if]->{'id'}>$Hteams[$if]->{'name'}\n");
	}
}
 out(<<END);
</SELECT>
<INPUT TYPE=SUBMIT VALUE="이팀의 상황 표시">
</FORM>
<P>
섬 이름을 클릭하면,<B>관광</B>할 수 있습니다.
</P>
<TABLE BORDER>
<TR>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}순위${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}팀${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}상대 팀${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}인구${H_tagTH}</NOBR></TH>
$mStr1
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}식량${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}농장규모${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}공장규모${H_tagTH}</NOBR></TH>
</TR>
<TR>
<TD $HbgNumberCell align=center nowrap=nowrap><NOBR>${HtagNumber_}${jj}${H_tagNumber}</NOBR></TD>
<TD $HbgNameCell ROWSPAN=2 align=left nowrap=nowrap>
<NOBR>${HtagTName_}$team->{'name'}${H_tagTName}
</NOBR><BR>
$prize</TD>
<TD $HbgNameCell align=left nowrap=nowrap>
<NOBR>${fightName}</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><A NAME=team$team->{'id'}>
<NOBR>$team->{'pop'}$HunitPop</NOBR></TD>
$mStr2
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$team->{'food'}$HunitFood</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$tfarm</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$tfactory</NOBR></TD>
</TR>
</TABLE><BR><BR>
<TABLE BORDER>
<TR>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}순위${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_} 섬${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}인구${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}면적${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}식량${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}농장규모${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}공장규모${H_tagTH}</NOBR></TH>
</TR>
END
for($g = 0;$g < $HmenberCount;$g++) {
	$iNumber = $islanddata[$g];
 if($iNumber ne '') {
	$j = $iNumber + 1;
	$island = $Hislands[$iNumber];
	$id = $island->{'id'};
	$farm = $island->{'farm'};
	$factory = $island->{'factory'};
	$farm = ($farm == 0) ? "보유하지 않음" : "${farm}0$HunitPop";
	$factory = ($factory == 0) ? "보유하지 않음" : "${factory}0$HunitPop";
	if($island->{'absent'} == 0) {
		$name = "${HtagName_}$island->{'name'} 섬${H_tagName}";
	} else {
	 $name = "${HtagName2_}$island->{'name'} 섬($island->{'absent'})${H_tagName2}";
	}

	$flags = $island->{'prize'};
	$prize = '';

	# 이름에 순위 표시 문자를 추가
	my($f) = 1;
	my($i);
	for($i = 1; $i < 10; $i++) {
	 if($flags & $f) {
		$prize.= "<IMG SRC=\"prize${i}.gif\" ALT=\"${Hprize[$i]}\" WIDTH=16 HEIGHT=16> ";
	 }
	 $f *= 2;
	}

	my($comname) ="${HtagTH_}코멘트:${H_tagTH}";
	if(($island->{'ownername'} ne '0') && ($island->{'ownername'} ne "코멘트")){
	 $comname = "<FONT COLOR=\"blue\"><B>$island->{'ownername'}:</b></font>";
	}
	out(<<END);
<TR>
<TD $HbgNumberCell ROWSPAN=2 align=center nowrap=nowrap><NOBR>${HtagNumber_}$j${H_tagNumber}</NOBR></TD>
<TD $HbgNameCell ROWSPAN=2 align=left nowrap=nowrap>
<NOBR>
<A STYlE=\"text-decoration:none\" HREF="${HthisFile}?Sight=${id}">
$name
</A>
</NOBR><BR>
$prize
</TD>
<TD $HbgInfoCell align=right nowrap=nowrap>
<NOBR>$island->{'pop'}$HunitPop</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$island->{'area'}$HunitArea</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$island->{'food'}$HunitFood</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$farm</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$factory</NOBR></TD>
</TR>
<TR>
<TD $HbgCommentCell COLSPAN=8 align=left nowrap=nowrap><NOBR>${HtagTH_}$comname${H_tagTH}$island->{'comment'}</NOBR></TD>
</TR>
END
 }
}
 }
} else {

 out(<<END);
<TABLE><TR><TD WIDTH=250>
<H1>${HtagHeader_}팀의 상황${H_tagHeader}</H1></TD>
<TD>
<FORM ACTION="${HthisFile}" METHOD=GET>
<INPUT TYPE=HIDDEN VALUE="0" NAME="TEAM">
<INPUT TYPE=SUBMIT VALUE="섬의 정보 표시">
</FORM>
</TD></TR></TABLE>
<P>
섬 이름을 클릭하면,<B>관광</B>할 수 있습니다.<BR>
팀의 이름을 클릭하면, 팀 섬의 상황이 목록 표시됩니다.<BR>
상대 팀의 이름을 클릭하면, 그순위로 이동합니다.
</P>
<TABLE BORDER>
<TR>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}순위${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}팀${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}상대 팀${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}인구${H_tagTH}</NOBR></TH>
$mStr1
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}식량${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}농장규모${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}공장규모${H_tagTH}</NOBR></TH>
</TR>
END
my($team, $g, $tname, $tmoney, $tpop, $tfarm, $tfactory, $jj, $flags, $prize);
for($g = 0;$g < $HteamNumber;$g++) {

if($g == $yteamNum){
 $HbgInfoCell = $YbgInfoCell;
 $HbgCommentCell = $YbgCommentCell;
 $HbgNameCell = $YbgNameCell;
 $HbgNumberCell = $YbgNumberCell;
 out ("<TR><TD colspan=10> </TD></TR>");
}

	$jj = $g + 1;
	$team = $Hteams[$g];
	$id = $team->{'id'};
	$tfarm = $team->{'farm'};
	$tfactory = $team->{'factory'};
	$tfarm = ($tfarm == 0) ? "보유하지 않음" : "${tfarm}0$HunitPop";
	$tfactory = ($tfactory == 0) ? "보유하지 않음" : "${tfactory}0$HunitPop";
	my($numMember) = $team->{'member'};
	my($member) = '';
	while($numMember =~ s/([0-9]*),//) {
	 if($member ne '') { $member.= "<B> : </B>"; }
	 my($island) = $Hislands[$HidToNumber{$1}];
	 $member.= "<A STYlE=\"text-decoration:none\" HREF=\"${HthisFile}?Sight=$island->{'id'}\">${HtagName_}$island->{'name'} 섬${H_tagName}</A>";
	}

	$flags = $team->{'prize'};
	$prize = '';

	# 이름에 순위 표시 문자를 추가
	my($f) = 1;
	my($i);
	for($i = 1; $i < 10; $i++) {
	 if($flags & $f) {
		$prize.= "<IMG SRC=\"prize${i}.gif\" ALT=\"${Hprize[$i]}\" WIDTH=16 HEIGHT=16> ";
	 }
	 $f *= 2;
	}

	my($mStr1) = '';
	if($HhideMoneyMode == 1) {
	 $mStr1 = "<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$team->{'money'}$HunitMoney</NOBR></TD>";
	} elsif($HhideMoneyMode == 2) {
	 my($mTmp) = aboutMoney($team->{'money'});
	 $mStr1 = "<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$mTmp</NOBR></TD>";
	}
	my($fightName) = '';
	if($team->{'fightid'}> 0) {
	 $fightName = "<A STYlE=\"text-decoration:none\" HREF=$HthisFile?#team$team->{'fightid'}>${HtagTName_}$Hteams[$HidToTeamNumber{$team->{'fightid'}}]->{'name'}${H_tagTName}</A>";
	} else {
	 $fightName = "${HtagName_}<CENTER>- - -${H_tagName}</CENTER>";
	}
	out(<<END);
<TR>
<TD $HbgNumberCell ROWSPAN=2 align=center nowrap=nowrap><NOBR>${HtagNumber_}${jj}${H_tagNumber}</NOBR></TD>
<TD $HbgNameCell ROWSPAN=2 align=left nowrap=nowrap>
<NOBR><A STYlE="text-decoration:none" HREF=$HthisFile?TEAM=$team->{'id'}#data>${HtagTName_}$team->{'name'}${H_tagTName}</A>
</NOBR><BR>
$prize</TD>
<TD $HbgNameCell ROWSPAN=2 align=left nowrap=nowrap>
<NOBR>${fightName}</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><A NAME=team$team->{'id'}>
<NOBR>$team->{'pop'}$HunitPop</NOBR></TD>
$mStr1
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$team->{'food'}$HunitFood</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$tfarm</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$tfactory</NOBR></TD>
</TR>
<TR>
<TD $HbgCommentCell COLSPAN=5 align=left nowrap=nowrap><NOBR>${HtagTH_}멤버:${H_tagTH}$member</NOBR></TD>
</TR>
END

}


}
if(!($HteamMode)) {

 out(<<END);
</TABLE>

<HR>
<H1>${HtagHeader_}새 섬을 탐색${H_tagHeader}</H1>
END

 if($HislandNumber < $HmaxIsland && $HislandTurn == 0) {
	out(<<END);
<FORM action="$HthisFile" method="POST">
먼저 팀을 선택해 주세요<BR>
<SELECT NAME=TEAMID>
END
for($i = 0;$i < $HteamNumber;$i++) {
 my($numMember) = $Hteams[$i]->{'member'};
 my($count) = 0;
 while($numMember =~ s/([0-9]*),//) { $count++; }
 if($HmenberCount == $count){ next; }
	out(<<END);
<OPTION VALUE=$Hteams[$i]->{'id'}>$Hteams[$i]->{'name'}
END
}
	out(<<END);
</SELECT><BR>
섬 이름<BR>
<INPUT TYPE="text" NAME="ISLANDNAME" SIZE=32 MAXLENGTH=32> 섬<BR>
비밀번호<BR>
<INPUT TYPE="password" NAME="PASSWORD" SIZE=32 MAXLENGTH=32><BR>
비밀번호 재확인<BR>
<INPUT TYPE="password" NAME="PASSWORD2" SIZE=32 MAXLENGTH=32><BR>

<INPUT TYPE="submit" VALUE="찾으러 가기" NAME="NewIslandButton">
</FORM>
END
 } elsif($HislandTurn> 0) {
	out(<<END);
 도중에참가할 수 없습니다. 다음 회차 등록 시작까지, 잠시 기다려 주세요.<BR>
END
 } else {
	out(<<END);
 섬의 수가 최대 수입니다... 현재 등록할 수 없습니다.
END
 }

 out(<<END);
<HR>
<TABLE>
<TR><TD WIDTH=420 ROWSPAN=2>
<NOBR><H1>${HtagHeader_} 정보 변경${H_tagHeader}</H1></NOBR>
<P>
(주의) 이름 변경에는 <B>$HcostChangeName${HunitMoney}</b>이 들어갑니다.
</P>
<FORM action="$HthisFile" method="POST">
어느 섬입니까?<BR>
<SELECT NAME="ISLANDID">
$HislandList
</SELECT><BR>
새 이름을 입력하세요(변경하는 경우만)<BR>
<INPUT TYPE="text" NAME="ISLANDNAME" SIZE=32 MAXLENGTH=32> 섬<BR>
비밀번호(필수)<BR>
<INPUT TYPE="password" NAME="OLDPASS" SIZE=32 MAXLENGTH=32><BR>
새 비밀번호(변경할 경우만)<BR>
<INPUT TYPE="password" NAME="PASSWORD" SIZE=32 MAXLENGTH=32><BR>
비밀번호 재확인(변경할 경우만)<BR>
<INPUT TYPE="password" NAME="PASSWORD2" SIZE=32 MAXLENGTH=32><BR>
<INPUT TYPE="submit" VALUE="변경" NAME="ChangeInfoButton">
</FORM>


END
my($Himfflag);
$Himfflag = $imageDir;

 out(<<END);
</TD>

<TD VALIGN=TOP WIDTH=350>
<H1>${HtagHeader_}이미지 경로 설정${H_tagHeader}</H1>
현재 설정<B>[</b> ${Himfflag} <B>]</B>
 <A HREF=${imageExp}><FONT SIZE=+1> 설명 </FONT></A>
<form action=$HthisFile method=POST>
<INPUT TYPE=file NAME="IMGLINE">
<INPUT TYPE="submit" VALUE="설정" name=IMGSET>
</form>

<form action=$HthisFile method=POST>
Mac 사용자용<BR>
<INPUT TYPE=text NAME="IMGLINEMAC">
<INPUT TYPE="submit" VALUE="설정" name=IMGSET><BR>
<FONT SIZE=-1>Mac 사용자는, 여기를 사용해 주세요.</FONT>
</form>
</TD></TR>

<TR HEIGHT=100><TD ALIGN=CENTER>
<form action=$HthisFile method=POST>
<INPUT TYPE=hidden NAME="IMGLINE" value="deletemodenow">
<INPUT TYPE="submit" VALUE="설정 해제" name=IMGSET>
</form>
</TD></TR>
</TABLE>

<HR>
<H1>${HtagHeader_}소유자 이름 결정!${H_tagHeader}</H1>
<FORM action="$HthisFile" method="POST">
당신의 섬은?
<SELECT NAME="ISLANDID">
$HislandList
</SELECT> 이름 입력
<INPUT TYPE="text" NAME="OWNERNAME" SIZE=16 MAXLENGTH=32>
 비밀번호
<INPUT TYPE="password" NAME="OLDPASS" SIZE=16 MAXLENGTH=32>
<INPUT TYPE="submit" VALUE="이것로" NAME="ChangeOwnerName">
</form>
<HR>

<H1>${HtagHeader_}발견 기록${H_tagHeader}</H1>
END
 historyPrint();
 out(<<END);
<BR><HR><div align=right><table><TR><td>
<FORM action="$HthisFile" method="POST">
<INPUT TYPE="password" NAME="OLDPASS" SIZE=16 MAXLENGTH=32>
<INPUT TYPE="submit" VALUE="관리자용" NAME="AdminPage">
</FORM></td></tr></table>
</div>
END
} else {
 out(<<END);
</TABLE>
END

}
}
# 기록 파일 표시
sub historyPrint {
 open(HIN, "${HdirName}/hakojima.his");
 my(@line, $l);
 while($l = <HIN>) {
	chomp($l);
	push(@line, $l);
 }
 @line = reverse(@line);

 foreach $l (@line) {
	$l =~ /^([0-9]*),(.*)$/;
	out("<NOBR>${HtagNumber_}턴${1}${H_tagNumber}:${2}</NOBR><BR>\n");
 }
 close(HIN);
}

1;
