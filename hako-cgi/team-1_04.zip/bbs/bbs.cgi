#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}

BEGIN {
	*Utf8Text = sub {
		my($s)=@_;
		return '' unless defined $s;
		utf8::decode($s) unless utf8::is_utf8($s);
		return $s;
	} unless defined &Utf8Text;

	*Utf8InPlace = sub {
		utf8::decode($_[0]) if defined $_[0] && !utf8::is_utf8($_[0]);
	} unless defined &Utf8InPlace;
}
## Petit Board v4.5 (00/04/02)
## Copyright(C) KENT-WEB 1997-2000
## webmaster@kent-web.com
## http://www.kent-web.com/

$ver = 'PETIT v4.5'; # 버전 정보

## ---[주의 사항]------------------------------------------------------
## 1. 이 스크립트는 프리 소프트웨어입니다. 이 스크립트 사용으로
## 발생한 손해에 대해 제작자는 책임을 지지 않습니다.
## 2. 설치 관련 질문은 지원 게시판을 이용해 주세요. 직접 메일로
## 보내는 질문에는 답변하지 않을 수 있습니다.
## 3. 동봉된 'home.gif' 아이콘은 '소 사육않으면아이콘의 방
## (http://www.ushikai.com/)'의 자료이며, 제작자의 동의하에
## 재배포하는 것입니다.
## -------------------------------------------------------------------

#============#
# 설정 항목 #
#============#

# 문자 변환 라이브러리가 같은 디렉터리에 있는 경우

# 제목 이름
$title = "전략실";

# 제목문자의 색
$t_color = "#DD0000";

# 제목문자의 대크기(font size)
$t_size = 6;

# 제목문자의 글꼴유형
$t_face = "MS P고시쿠";

# 배경 화면을 사양하는 경우(http://부터지정)
$backgif = "";

# 배경색을 지정
$bgcolor = "#E1F0F0";

# 문자색을 지정
$text = "#000000";

# 링크색을 지정
$link = "#0000FF";	# 미방문질문
$vlink = "#800080";	# 방문질문완료
$alink = "#FF0000";	# 방문질문안


# 복귀리선의 URL (index.html 등)
$homepage = "../../../hako";

# 모형정원의 URL
$hakopage = "../hako-main.cgi";

# 원글 최대글 수 (너무 많으면 위험)
# --> 답글 기사의 수는 최대글 수에는 포함되지 않습니다
$max = 50;

# 관리자용 마스터 비밀번호(영숫자)
$pass = 'password';

# 아이콘이미지의 있음'디렉터리'
# --> petit.cgi와 다른 디렉터리에 둘 경우 http://부터 입력합니다.
$icon_dir = ".";

# 답글이 달리면 원글을 맨 위로 이동 (0=no 1=yes)
$res_sort = 0;

# 호스트 이름가져오기 모드
# --> 0 : $ENV{'REMOTE_HOST'} 데가져오기할 수 이 경우
# --> 1 : gethostbyaddr 데가져오기할 수 이 경우
$get_remotehost = 0;

# 제목에 GIF 이미지를 사용하기 시 (http://부터기술)
$title_gif = "";
$tg_w = '150';		# GIF 이미지의 폭(픽셀)
$tg_h = '50';		# 〃 고사(픽셀)

# 파일 잠금형식
# --> 0=no 1=symlink 함수 2=open 함수
# --> 1 or 2을 설정하는 경우, 잠금 파일을 생성하다 디렉터리
# 권한은 777 에 설정하기.
$lockkey = 0;

# 잠금 파일 이름
$lockfile = "./petit.lock";

# 카운터의 잠금 파일 이름
$cntlock = "./ptcnt.lock";

# 미니카운터의 설치
# --> 0=no 1=텍스트 2=GIF 이미지
$counter = 0;
$mini_fig = 5;			# 미니카운터의 자릿 수
$cnt_color = "#dd0000";		# 텍스트의 시:미니카운터의 색
$gif_path = ".";		# GIF의 시 :이미지까지의 디렉터리
$mini_w = 8;			# 〃 :이미지의 가로 크기
$mini_h = 12;			# 〃 :이미지의 세로 크기
$cntfile = "./count.dat";	# 카운터 파일

# 태그의 허가 (0=no 1=yes)
$tagkey = 0;

# 스크립트 파일
$script = "./bbs.cgi";

# 로그 파일을 지정
# --> 전체경로 에서 지정하는 경우 / 로 시작하는 전체경로 에서.
#$logfile = "./petit.cgi";

# 일부의 유형 (0=양식 1=화합식)
$date_type = 0;

# 글의 [제목] 부의 색
$sbj_color = "#006400";

# 글 표시부의 하지의 색
$tbl_color = "#FFFFFF";

# 가아이콘 사용 (0=no 1=yes)
$home_icon = 0;
$home_gif = "home.gif";	# 가아이콘의 파일 이름
$home_wid = 25;		# 이미지의 가로 크기
$home_hei = 22;		# 〃 세로 크기

# method 의형식 (POST/GET)
$method = 'POST';

# 1페이지당거나의 글 표시 수 (원글)
$pagelog = 15;

# 게시가 있으면메일통지하다 (0=no 1=yes)
# --> sendmail 필수
$mailing = 0;

# 메일 주소(메일통지하다 시)
$mailto = 'foo@host.ne.jp';

# sendmail 경로(메일통지하다 시)
$sendmail = '/usr/lib/sendmail';

# 자신의 글은 메일전송 (0=no 1=yes)
$mail_me = 0;

# 타사이트에서 게시배제하다 시에지정 (http://부터서쿠)
$base_url = "";

# 문자색의 설정. 상아래의 배열은 반드시페아에서.
@COLORS = ('000000','800000','DF0000','008040','0000FF','C100C1','FF80C0','FF8040','000080');
@IROIRO = ('검정','차','적','미도리','청','보라','핑크','오렌지','아이색');

# 줄바꿈형식 (수동=soft 강제=hard)
$wrap = 'soft';

# URL 의자동링크 (0=no 1=yes)
# --> 태그허가의 경우 no로 설정할 것.
$autolink = 0;

# 태그 광고 삽입 옵션 (FreeWeb 등)
# → <!--상부--> 또는 <!--하부--> 뒤에 '광고 태그'를 삽입합니다.
# → 광고 태그 외에도 MIDI 태그나 LimeCounter 등의 태그에 사용할 수 있습니다.
$banner1 = '<!--상부-->'; # 게시판 상단에 삽입
$banner2 = '<!--하부-->'; # 게시판 하단에 삽입

# 과거 로그 생성 (0=no 1=yes)
$pastkey = 0;
$nofile = "./pastno.dat";	# 과거 로그용 NO 파일
$past_dir = ".";		# 과거 로그의 디렉터리
$log_line = '150';		# 과거 로그1파일의 줄 수
$petit2 = "./petit2.cgi";	# 과거 로그 관리 파일

#============#
# 설정완료 #
#============#

#$ref_main = 'http://www.elsia.com/com/hako';
#$ref_page = 'http://www.elsia.com/com/tyotou';

#$page = $ENV{'HTTP_REFERER'};
#$page =~ tr/+/ /;
#$page =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
#if (!($page =~ /$ref_page/i)) { &access; }

# 메인 처리
&decode;
&logpass;
if ($mode eq "howto") { &howto; }
if ($mode eq "find") { &find; }
if ($mode eq "usr_del") { &usr_del; }
if ($mode eq "msg_del") { &msg_del; }
if ($mode eq "msg") { &regist; }
if ($mode eq "res_msg") { &res_msg; }
if ($mode eq "admin") { &admin; }
if ($mode eq "admin_del") { &admin_del; }
&html_log;

#--------------#
# 글 표시부 #
#--------------#
sub html_log {
	# 쿠키를 가져옴
	&get_cookie;

	# 양식장을 조정
	&get_bros;

	# 로그를 읽기
	open(IN,"$logfile") || &error("Can't open $logfile");
	@lines = <IN>;
	close(IN);

	# 글번호를 자르기
	shift(@lines);

	# 원글만의 배열 데이터를 작성
	@new = ();
	foreach $line (@lines) {
		local($num,$k,$date,$name,$email,
			$subj,$com,$url,$host,$pw,$color) = split(/<>/,$line);
		# 원글을 모음약속
		if ($k eq "") { push(@new,$line); }
	}

	# 답글 기사는 답글순에붙이기위해배열을 역순로
	@lines = reverse(@lines);

	# 헤더를 출력
	&header;

	# 카운터 처리
	if ($counter) { &counter; }

	print "<center>$banner1<P>\n";

	# 제목부
	if ($title_gif eq '') {
		print "<font color=$t_color size=$t_size face=\"$t_face\">";
		print "<b>$title</b></font>\n";
	} else {
		print "<img src=\"$title_gif\" width=\"$tg_w\" height=\"$tg_h\">\n";
	}

	print "<hr width=90%>\n";
	print "[<a href=\"$homepage\" target='_top'>중단에돌아가기</a>]\n";
	print "[<a href=\"$hakopage\" target='_top'>모형정원 에돌아가기</a>]\n";
	print "[<a href=\"$script?mode=howto&teamID=$tid&tPASS=$tpass\">사용이분</a>]\n";
	print "[<a href=\"$script?mode=find&teamID=$tid&tPASS=$tpass\">워드검색</a>]\n";

	if ($pastkey) {
		print "[<a href=\"$petit2\">과거 로그</a>]\n";
	}

	print <<"EOM";
[<a href="$script?teamID=$tid&tPASS=$tpass&mode=msg_del">글 삭제</a>]
[<a href="${script}?teamID=$tid&tPASS=$tpass&mode=admin">관리용</a>]
<hr width="90%">
<BR><FONT SIZE=+2>
<A HREF="chat/chat.cgi?teamID=$tid&tPASS=$tpass&mode=top">회의 실(차와)</A>
</FONT>
</center>
<form method="$method" action="$script">
<input type=hidden name=teamID value="$tid">
<input type=hidden name=tPASS value="$tpass">
<input type=hidden name=mode value="msg">
<blockquote>
<table border=0 cellspacing=0>
<tr>
 <td nowrap><b>이름</b></td>
 <td>
 <input type=text name=name size="$nam_wid" value="$c_name">
 </td>
</tr>
<tr>
 <td nowrap><b>E메일</b></td>
 <td>
 <input type=text name=email size="$nam_wid" value="$c_email">
 </td>
</tr>
<tr>
 <td nowrap><b>제목 이름</b></td>
 <td>
 <input type=text name=subj size="$subj_wid">
 <input type=submit value="게시하다"><input type=reset value="리 설정">
 </td>
</tr>
<tr>
 <td colspan=2>
 <b>코멘트</b><br>
 <textarea cols="$com_wid" rows=7 name=comment wrap="$wrap"></textarea>
 </td>
</tr>

<tr>
 <td nowrap><b>삭제키</b></td>
 <td>
 <input type=password name=pwd size=8 maxlength=8 value="$c_pwd">
 <small>(자신의 글을 삭제 시에 사용. 영숫자 8자 이내)</small>
 </td>
</tr>
<tr>
 <td nowrap>
 <b>문자색</b>
 </td>
 <td>
EOM

	if ($c_color eq "") { $c_color = "$COLORS[0]"; }
	foreach (@COLORS) {
		if ($c_color eq "$_") {
			print "<input type=radio name=color value=\"$_\" checked>";
			print "<font color=$_>■</font>\n";
		} else {
			print "<input type=radio name=color value=\"$_\">";
			print "<font color=$_>■</font>\n";
		}
	}

	print "</td></tr></table></form></blockquote><hr>\n";

	if ($FORM{'page'} eq '') { $page = 0; }
	else { $page = $FORM{'page'}; }

	# 글 수를 가져옴
	$end_data = @new - 1;
	$page_end = $page + ($pagelog - 1);

	if ($page_end>= $end_data) { $page_end = $end_data; }
	foreach ($page.. $page_end) {
		($num,$k,$date,$name,$email,$sbj,
			$com,$url,$host,$pwd,$color) = split(/<>/, $new[$_]);

		if ($email) { $name = "<a href=mailto\:$email>$name</a>"; }
		if (!$sbj) { $sbj = "Untitled"; }

		# URL 표시
		if ($url && $home_icon) {
			$url = "<a href=\"http://$url\" target=_top><img src=\"$icon_dir\/$home_gif\" border=0 align=top HSPACE=10 WIDTH=\"$home_wid\" HEIGHT=\"$home_hei\"></a>";

		} elsif ($url && $home_icon == 0) {
			$url = "<small>[<a href=\"http://$url\" target=_top>HOME</a>]</small>";
		}

		# 자동링크
		if ($autolink) { &auto_link($com); }

		print "<center><table border=1 width=95% cellpadding=5 cellspacing=0 bgcolor=$tbl_color>\n";
		print "<tr><td>\n";
		print "<table border=0 cellspacing=0><tr>\n";
		print "<td>[<b>$num</b>] <font color=$sbj_color><b>$sbj</b></font></td>\n";
		print "<td width=10></td><td>게시자:<font color=$link><b>$name</b></font></td>\n";
		print "<td><small>게시일:$date</small></td><td>$url</td></tr></table>\n";
		print "<blockquote><font color=\"$color\">$com</font></blockquote>\n";

		## 답글 메시지를 표시
		$flag = 0;
		foreach $line (@lines) {
			($rnum,$rk,$rd,$rname,$rem,
				$rsub,$rcom,$rurl,$rho,$rp,$rc) = split(/<>/, $line);

			if ($num eq "$rk") {
				if ($flag == 0) { print "<P><hr width=95% size=1>\n"; $flag=1; }

				# 자동링크
				if ($autolink) { &auto_link($rcom); }

				print "<table border=0 width=100% cellspacing=0><tr>\n";
				print "<td><font color=$rc><b>$rname</b>> $rcom ";
				print "<small>($rd)</small></font></td></tr></table>\n";
			}
		}

		print "</td></tr></table>\n";
		print "<form action=\"$script\" method=$method>\n";
		print "<input type=hidden name=teamID value=\"$tid\">\n";
		print "<input type=hidden name=tPASS value=\"$tpass\">\n";
		print "<a href=./bbs.cgi?teamID=$tid&tPASS=$tpass>새로 고침</a>\n";
		print "<input type=hidden name=mode value=\"msg\">\n";
		print "<input type=hidden name=resno value=\"$num\">\n";
		print "<input type=hidden name=page value=\"$FORM{'page'}\">\n";
		print "<input type=hidden name=email value=\"$c_email\">\n";
		print "<input type=hidden name=url value=\"$c_url\">\n";

		print "이름<input type=text name=name size=$nam_wid2 value=\"$c_name\">\n";
		print "답글<input type=text name=comment size=$subj_wid>\n";
		print "문자색<select name=color>\n";

		foreach (0.. $#COLORS) {
			if ($c_color eq "$COLORS[$_]") {
				print "<option value=\"$COLORS[$_]\" selected>$IROIRO[$_]\n";
			} else {
				print "<option value=\"$COLORS[$_]\">$IROIRO[$_]\n";
			}
		}

		print "</select> 삭제키<input type=password name=pwd size=4 value=\"$c_pwd\">\n";
		print "<input type=submit value=\"답장하다\"></form></center><hr>\n";
	}

	print "<table border=0><tr>\n";

	# 개정페이지 처리
	$next_line = $page_end + 1;
	$back_line = $page - $pagelog;

	# 전페이지 처리
	if ($back_line>= 0) {
		print "<td><form method=\"$method\" action=\"$script\">\n";
		print "<input type=hidden name=teamID value=\"$tid\">\n";
		print "<input type=hidden name=tPASS value=\"$tpass\">\n";
		print "<input type=hidden name=page value=\"$back_line\">\n";
		print "<input type=hidden name=mode value=\"page\">\n";
		print "<input type=submit value=\"전의$pagelog 건\">\n";
		print "</form></td>\n";
	}

	# 다음페이지 처리
	if ($page_end ne $end_data) {
		print "<td><form method=\"$method\" action=\"$script\">\n";
		print "<input type=hidden name=teamID value=\"$tid\">\n";
		print "<input type=hidden name=tPASS value=\"$tpass\">\n";
		print "<input type=hidden name=page value=\"$next_line\">\n";
		print "<input type=hidden name=mode value=\"page\">\n";
		print "<input type=submit value=\"다음$pagelog 건\">\n";
		print "</form></td>\n";
	}

	print "</tr></table>\n";
	&footer;
	exit;
}

#--------------------#
# 로그 쓰기 처리 #
#--------------------#
sub regist {
	# 타 사이트에서의 접속을 차단
	if ($base_url) {
		$ref_url = $ENV{'HTTP_REFERER'};
		$ref_url =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
		if ($ref_url !~ /$base_url/i) { &error("부정나접속입니다"); }
	}

	# 이름과 코멘트는 필수
	if ($name eq "") { &error("이름이입력됨되어 있지 않습니다"); }
	if ($comment eq "") { &error("코멘트이입력됨되어 있지 않습니다"); }
	if ($email && $email !~ /(.*)\@(.*)\.(.*)/) {
		&error("E메일의 입력내용이정하 없습니다");
	}

	# 호스트 이름을 가져옴
	&get_host;

	# 파일 잠금
	if ($lockkey == 1) { &lock1; }
	elsif ($lockkey == 2) { &lock2; }

	# 로그를 열기
	open(IN,"$logfile") || &error("Can't open $logfile");
	@lines = <IN>;
	close(IN);

	# 원글 NO 처리
	$oya = $lines[0];
	if ($oya =~ /<>/) {
		&error("로그가정하 없습니다.<P>
			(v2.5이전의 로그의 경우변환의 필요합니다)");
	}
	$oya =~ s/\n//;
	shift(@lines);

	# 이중게시의 금지
	local($flag) = 0;
	foreach $line (@lines) {
		($knum,$kk,$kd,$kname,$kem,$ksub,$kcom) = split(/<>/,$line);
		if ($name eq "$kname" && $comment eq "$kcom") {
			$flag=1; last;
		}
	}
	if ($flag) { &error("이중게시는 금지입니다"); }

	# 원글의 경우, 글 No 을카운트업로드시, 쿠키를 발 줄
	if ($FORM{'resno'} eq "") { $oya++; }
	&set_cookie;
	$number = $oya;

	# 삭제키를 암호화
	if ($pwd) { $ango = &passwd_encode($pwd); }

	# 시간을 가져옴
	&get_time;

	# 로그를 형식
	$new_msg = "$number<>$FORM{'resno'}<>$date<>$name<>$email<>$subj<>$comment<>$url<>$host<>$ango<>$color<>\n";

	## 자동정렬 시는, 답글 기사게시 시는 원글은 맨 위로 이동
	if ($res_sort && $FORM{'resno'} ne "") {
		@res_data = ();
		@new = ();
		foreach $line (@lines) {
		 $flag = 0;
		 ($num,$k,$d,$na,$em,$sub,$com,$u,$ho,$p,$c,$ico) = split(/<>/,$line);

		 # 원글을 추출
		 if ($k eq "" && $FORM{'resno'} eq "$num") {
			$new_line = "$line";
			$flag = 1;
		 }
		 # 관련 답글 기사를 추출
		 elsif ($k eq "$FORM{'resno'}") {
			push(@res_data,$line);
			$flag = 1;
		 }
		 if ($flag == 0) { push(@new,$line); }
		}

		# 관련답글 기사를 맨 위로
		unshift(@new,@res_data);

		# 신규 메시지를 맨 위로
		unshift(@new,$new_msg);

		# 원글을 맨 위로
		unshift(@new,$new_line);

	## 원글의 경우, 최대글 수를 초과한 글을 자르기
	} elsif ($FORM{'resno'} eq "") {

		$i = 0;
		$stop = 0;
		foreach $line (@lines) {
		 ($num,$k,$d,$na,$em,$sub,$com,$u,$ho,$p,$c,$ico)=split(/<>/,$line);

		 if ($k eq "") { $i++; }
		 if ($i> $max-1) {
			$stop = 1;
			if ($pastkey == 0) { last; }
			else {
				if ($k eq "") { $kflag=1; push(@past_data,$line); }
				else { push(@past_res,$line); }
			}
		 }
		 if ($stop == 0) { push(@new,$line); }
		}

		## 과거글 생성
		if ($kflag) {
			@past_res = reverse(@past_res);
			push(@past_data,@past_res);
			&pastlog;
		}

		unshift(@new,$new_msg);

	## 답글 기사는 글 수의 조정은 하지 않음
	} else {
		@res_data = ();
		@new = ();

		foreach $line (@lines) {
		 $flag = 0;
		 ($num,$k,$d,$na,$em,$sub,$com,$u,$ho,$p,$c,$ico) = split(/<>/,$line);

		 # 원글을 추출
		 if ($k eq "" && $FORM{'resno'} eq "$num") {
			$new_line = "$line";
			$flag = 2;
		 }
		 if ($flag == 0) { push(@new,$line); }
		 elsif ($flag == 2) {
			push(@new,$new_line);
			push(@new,$new_msg);
		 }
		}
	}

	# 원글 NO 을부가
	unshift (@new,"$oya\n");

	# 로그를 갱신
	open(OUT,">$logfile") || &error("Can't write $logfile");
	print OUT @new;
	close(OUT);

	# 잠금해제
	if (-e $lockfile) { unlink($lockfile); }

	# 메일 처리
	if ($mailing && $mail_me) { &mail_to; }
	elsif ($mailing && $mail_me == 0 && $email ne "$mailto") { &mail_to; }
}

#---------------#
# 데코드 처리 #
#---------------#
sub decode {
	if ($ENV{'REQUEST_METHOD'} eq "POST") {
		if ($ENV{'CONTENT_LENGTH'}> 51200) { &error("게시량이대키너무 깁니다"); }
		read(STDIN, $buffer, $ENV{'CONTENT_LENGTH'});
	} else { $buffer = $ENV{'QUERY_STRING'}; }

	@pairs = split(/&/,$buffer);
	foreach $pair (@pairs) {
		($name, $value) = split(/=/, $pair);
		$value =~ tr/+/ /;
		$value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;

		# 문자코드변환
		Utf8InPlace($value);

		# 태그 처리
		if ($tagkey == 0) {
			$value =~ s/</&lt\;/g;
			$value =~ s/>/&gt\;/g;
		} else {
			$value =~ s/<!--(.|\n)*-->//g;
			$value =~ s/<>/&lt\;&gt\;/g;
		}

		# 일괄 삭제용
		if ($name eq 'del') { push(@delete,$value); }

		$FORM{$name} = $value;
	}
	$name = $FORM{'name'};
	$comment = $FORM{'comment'};
	$comment =~ s/\r\n/<br>/g;
	$comment =~ s/\r|\n/<br>/g;
	$email = $FORM{'email'};
	$url = $FORM{'url'};
	$url =~ s/^http\:\/\///;
	$mode = $FORM{'mode'};
	$subj = $FORM{'subj'};
	$pwd = $FORM{'pwd'};
	$color = $FORM{'color'};
}

#----------------------------#
# 게시판 사용이분 메시지 #
#----------------------------#
sub howto {
	if ($tagkey == 0) { $tag_msg = "게시내용에는,<b>태그는 절대사용할 수 없습니다.</b>\n"; }
	else { $tag_msg = "코멘트란에는,<b>태그사용을 할 수 있습니다.</b>\n"; }

	&header;
	print <<"HTML";
[<a href="$script?teamID=$tid&tPASS=$tpass\">게시판에돌아가기</a>]
<table width="100%"><tr><th bgcolor="#0000A0">
<font color="#FFFFFF">게시판의 이용상의 주의</font>
</th></tr></table>
<P><center>
<table width=90% border=1 cellpadding=10>
<tr><td bgcolor="$tbl_color">
<OL>
<LI>이 게시판은 <b>쿠키 지원</b> 게시판입니다. 한 번 글을 올리면 이름, E메일, URL, 삭제키 정보가 다음 글부터 자동 입력됩니다. 단, 이용자의 브라우저가 쿠키를 지원해야 합니다.<P>
<LI>$tag_msg<P>
<LI>글을 게시할 시 필수 입력 항목은<b>'이름'</b>과 <b>'메시지'</b>입니다.E메일,URL, 제목, 삭제키는 선택 사항입니다.<P>
<LI>글에는 <b>반각 가나를 절대 사용하지 마세요.</b> 문자 깨짐의 원인이 됩니다.<P>
<LI>글을 올릴 시<b>'삭제키'</b>에 비밀번호(영숫자 8자 이내)를 입력해 두면, 그 글은 다음에 <b>삭제키</b>로 삭제할 수 있습니다.<P>
<LI>글 보존 건수는<b>최대 $max 건</b>입니다. 이를 초과하면 오래된 순서대로 자동 삭제됩니다.<P>
<LI>기존 글에 <b>'1줄 답글'</b>을 달 수 있습니다. 글 표시란 하단의 답장 양식에서 글을 올릴 수 있습니다.<P>
<LI>기존 게시글에서 <b>'키워드'로 간이 검색을 할 수 있습니다.</b> 톱 메뉴의 <a href="$script?mode=find&teamID=$tid&tPASS=$tpass">'워드 검색'</a> 링크를 클릭하면 검색 모드가 됩니다.<P>
<LI>관리자가 현저히 불이익하다고 판단한 글이나 타인을 비방·중상하는 글은 사전 고지 없이 삭제될 수 있습니다.
</OL>
</td></tr></table>
</center><hr>
HTML
	&footer;
	exit;
}

#--------------------------#
# 워드검색서브루틴 #
#--------------------------#
sub find {
	&header;
	print <<"HTML";
[<a href="$script?teamID=$tid&tPASS=$tpass">게시판에돌아가기</a>]
<table width="100%"><tr><th bgcolor="#0000A0">
<font color="#FFFFFF">워드검색</font></th></tr></table>
<P><center>
<table cellpadding=5>
<tr><td bgcolor="$tbl_color" nowrap>
 <UL>
 <LI>검색할 <b>키워드</b>를 입력한 뒤, 검색 영역을 선택하고 '검색' 버튼을 눌러 주세요.
 <LI>키워드를'반각 공백'로 구분라고복수지정할 수 있습니다.
 </UL>
</td></tr></table><P>
<form action="$script" method="$method">
<input type=hidden name=teamID value="$tid">
<input type=hidden name=tPASS value="$tpass">
<input type=hidden name=mode value="find">
<table border=1>
<tr>
 <th colspan=2>키워드 <input type=text name=word size=30></th>
</tr>
<tr>
 <td>검색조건</td>
 <td>
 <input type=radio name=cond value="and" checked>AND
 <input type=radio name=cond value="or">OR
 </td>
</tr>
<tr>
 <th colspan=2>
 <input type=submit value="검색하다"><input type=reset value="리 설정">
 </th>
</tr>
</table>
</form>
</center>
HTML
	# 워드검색의 실행와 결과 표시
	if ($FORM{'word'} ne "") {

		# 입력내용을 정리
		$cond = $FORM{'cond'};
		$word = $FORM{'word'};
		$word =~ s/ / /g;
		$word =~ s/\t/ /g;
		@pairs = split(/ /,$word);

		# 파일을 읽기
		open(DB,"$logfile") || &error("Can't open $logfile");
		@lines = <DB>;
		close(DB);

		# 검색 처리
		foreach (1.. $#lines) {
			$flag = 0;
			foreach $pair (@pairs){
				if (index($lines[$_],$pair)>= 0){
					$flag = 1;
					if ($cond eq 'or') { last; }
				} else {
					if ($cond eq 'and'){ $flag = 0; last; }
				}
			}
			if ($flag == 1) { push(@new,$lines[$_]); }
		}

		# 검색종료
		$count = @new;
		print "<hr><b><font color=$t_color>검색결과:$count 건</font></b><P>\n";
		print "<OL>\n";

		foreach $line (@new) {
			($num,$k,$date,$name,$email,$sub,$com,$url) = split(/<>/, $line);
			if (!$sub) { $sub = "Untitled"; }
			if ($email) { $name = "<a href=mailto\:$email>$name</a>"; }
			if ($url) { $url = "[<a href=\"http://$url\" target=_top>HOME</a>]"; }

			if ($k) { $num = "$k로의 답글"; }

			# 결과 를 표시
			print "<LI>[$num] <font color=$sbj_color><b>$sub</b></font>\n";
			print "게시자:<b>$name</b> <small>$url 게시일:$date</small><P>\n";
			print "<blockquote>$com</blockquote><hr size=2>\n";
		}

		print "</OL><P>\n";
	}
	&footer;
	exit;
}

#--------------#
# 일 시의 가져오기 #
#--------------#
sub get_time {
	$ENV{'TZ'} = "JST-9";
	($sec,$min,$hour,$mday,$mon,$year,$wday,$dmy,$dmy) = localtime(time);
	$year += 1900;
	$mon++;
	if ($mon < 10) { $mon = "0$mon"; }
	if ($mday < 10) { $mday = "0$mday"; }
	if ($hour < 10) { $hour = "0$hour"; }
	if ($min < 10) { $min = "0$min"; }
	if ($sec < 10) { $sec = "0$sec"; }

	# 일 시의 형식
	if ($date_type && $FORM{'resno'} eq "") {
		$youbi = ('일','월','불','수','목','금','와 지') [$wday];
		$date = "$year 년$mon 월$mday 일 ($youbi) $hour 시$min 분$sec 초";
	} else {
		$youbi = ('Sun','Mon','Tue','Wed','Thu','Fri','Sat') [$wday];
		$date = "$year/$mon/$mday($youbi) $hour\:$min\:$sec";
	}
}

#------------------------------------#
# 브라우저를 판단시양식폭을 조정 #
#------------------------------------#
sub get_bros {
	# 브라우저 이름을 가져옴
	$agent = $ENV{'HTTP_USER_AGENT'};

	if ($agent =~ /MSIE 3/i) {
		$nam_wid = 30;
		$subj_wid = 40;
		$com_wid = 65;
		$url_wid = 48;
		$nam_wid2 = 15;
	} elsif ($agent =~ /MSIE 4/i || $agent =~ /MSIE 5/i) {
		$nam_wid = 30;
		$subj_wid = 40;
		$com_wid = 65;
		$url_wid = 78;
		$nam_wid2 = 15;
	} else {
		$nam_wid = 20;
		$subj_wid = 25;
		$com_wid = 56;
		$url_wid = 50;
		$nam_wid2 = 10;
	}
}

#------------#
# 삭제 화면 #
#------------#
sub msg_del {
	if ($FORM{'action'} eq 'admin' && $FORM{'pass'} ne "$pass") {
		&error("비밀번호가 다릅니다");
	}

	open(DB,$logfile) || &error("Can't open $logfile");
	@lines = <DB>;
	close(DB);

	shift(@lines);

	# 원글만의 배열 데이터를 작성
	@new = ();
	foreach $line (@lines) {
		local($num,$k,$date,$name,
			$email,$sub,$com,$url,$host,$pw) = split(/<>/,$line);

		# RES 글을 해제
		if ($k eq "") { push(@new,$line); }
	}

	@lines = reverse(@lines);

	&header;
	print "[<a href=\"$script?teamID=$tid&tPASS=$tpass\">게시판에 돌아가기</a>]\n";
	print "<table width=100%><tr><th bgcolor=\"#0000A0\">\n";
	print "<font color=\"#FFFFFF\">코멘트 삭제 화면</font></th></tr></table>\n";
	print "<P><center>\n";
	print "<table border=0 cellpadding=5><tr>\n";
	print "<td bgcolor=\"$tbl_color\">\n";

	if ($FORM{'action'} eq '') {
		print "■게시 시에기입했습니다'삭제키'로, 글을 삭제합니다.<br>\n";
	}

	print "■삭제할 글의 확인란에 체크하고, 아래 입력란에 '삭제키'를 입력해 주세요.<br>\n";
	print "■원글을 삭제하는 경우, 그 답글 메시지도 동시에 삭제될 수 있으므로, 주의해 주세요.<br>\n";
	print "</td></tr></table><P>\n";
	print "<form action=\"$script\" method=$method>\n";

	if ($FORM{'action'} eq '') {
		print "<input type=hidden name=mode value=\"usr_del\">\n";
		print "<b>삭제키</b> <input type=text name=del_key size=10>\n";
	} else {
		print "<input type=hidden name=mode value=\"admin_del\">\n";
		print "<input type=hidden name=action value=\"admin\">\n";
		print "<input type=hidden name=pass value=\"$FORM{'pass'}\">\n";
	}
	print "<input type=hidden name=teamID value=\"$tid\">\n";
	print "<input type=hidden name=tPASS value=\"$tpass\">\n";
	print "<input type=submit value=\"삭제\"><input type=reset value=\"리 설정\">\n";
	print "<P><table border=1>\n";
	print "<tr><th>삭제</th><th>글 No</th><th>제목</th><th>게시자</th>";
	print "<th>게시일</th><th>코멘트</th>\n";

	if ($FORM{'action'} eq 'admin') { print "<th>호스트 이름</th>\n"; }

	print "</tr>\n";

	if ($FORM{'page'} eq '') { $page = 0; }
	else { $page = $FORM{'page'}; }

	# 글 수를 가져옴
	$end_data = @new - 1;
	$page_end = $page + ($pagelog - 1);
	if ($page_end>= $end_data) { $page_end = $end_data; }

	foreach ($page.. $page_end) {
		($num,$k,$date,$name,$email,$sub,
			$com,$url,$host,$pw,$color) = split(/<>/,$new[$_]);

		if ($email) { $name="<a href=mailto\:$email>$name</a>"; }
		if (!$sub) { $sub = "Untitled"; }

		$com =~ s/<br>/ /g;
		if ($tagkey) { $com =~ s/</&lt;/g; $com =~ s/>/&gt;/g; }
		if (length($com)> 60) { $com=substr($com,0,58); $com=$com. '..'; }

		if ($FORM{'action'} eq 'admin') {
			print "<tr><th><input type=checkbox name=del value=\"$date\"></th>\n";

		} else {
			print "<tr><th><input type=radio name=del value=\"$date\"></th>\n";
		}

		print "<th>$num</th><td>$sub</td><td>$name</td>\n";
		print "<td><small>$date</small></td><td>$com</td>\n";

		if ($FORM{'action'} eq 'admin') { print "<td>$host</td>\n"; }

		print "</tr>\n";

		## 답글 메시지를 표시
		foreach (@lines) {
			($rnum,$rk,$rd,$rname,$rem,$rsub,
				$rcom,$rurl,$rho,$rp,$rc) = split(/<>/, $_);

			$rcom =~ s/<br>/ /g;
			if ($tagkey) { $rcom =~ s/</&lt;/g; $rcom =~ s/>/&gt;/g; }
			if (length($rcom)> 60) { $rcom=substr($rcom,0,58); $rcom=$rcom. '..'; }
			if ($num eq "$rk"){

				if ($FORM{'action'} eq 'admin') {
					print "<tr><th><input type=checkbox name=del value=\"$rd\"></th>\n";
				} else {
					print "<tr><th><input type=radio name=del value=\"$rd\"></th>\n";
				}

				print "<td colspan=2 align=center><b>$num</b>로의 답글</td>\n";
				print "<td>$rname</td><td><small>$rd</small></td><td>$rcom</td>\n";

				if ($FORM{'action'} eq 'admin') { print "<td>$rho</td>\n"; }

				print "</tr>\n";
			}
		}
	}
	print "</table></form>\n";
	print "<table border=0 width=100%><tr>\n";

	# 개정페이지 처리
	$next_line = $page_end + 1;
	$back_line = $page - $pagelog;

	# 전페이지 처리
	if ($back_line>= 0) {
		print "<td><form method=\"$method\" action=\"$script\">\n";
		print "<input type=hidden name=teamID value=\"$tid\">\n";
		print "<input type=hidden name=tPASS value=\"$tpass\">\n";
		print "<input type=hidden name=page value=\"$back_line\">\n";
		print "<input type=hidden name=mode value=msg_del>\n";
		print "<input type=submit value=\"전의 원글$pagelog 건\">\n";

		if ($FORM{'action'} eq 'admin') {
		 print "<input type=hidden name=action value=\"admin\">\n";
		 print "<input type=hidden name=pass value=\"$FORM{'pass'}\">\n";
		}

		print "</form></td>\n";
	}

	# 다음페이지 처리
	if ($page_end ne $end_data) {
		print "<td><form method=\"$method\" action=\"$script\">\n";
		print "<input type=hidden name=teamID value=\"$tid\">\n";
		print "<input type=hidden name=tPASS value=\"$tpass\">\n";
		print "<input type=hidden name=page value=\"$next_line\">\n";
		print "<input type=hidden name=mode value=msg_del>\n";
		print "<input type=submit value=\"다음원글$pagelog 건\">\n";

		if ($FORM{'action'} eq 'admin') {
		 print "<input type=hidden name=action value=\"admin\">\n";
		 print "<input type=hidden name=pass value=\"$FORM{'pass'}\">\n";
		}

		print "</form></td>\n";
	}

	print "</tr></table><P><hr><P>\n";
	&footer;
	exit;
}

## --- 유자글 삭제 처리
sub usr_del {
	if ($FORM{'del_key'} eq "") { &error("삭제키가 입력되지 않았습니다."); }
	if ($FORM{'del'} eq "") { &error("라지오버튼의 선택 없습니다."); }

	# 잠금시작
	if ($lockkey == 1) { &lock1; }
	elsif ($lockkey == 2) { &lock2; }

	# 로그를 읽기
	open(DB,"$logfile") || &error("Can't open $logfile");
	@lines = <DB>;
	close(DB);

	# 원글 NO
	$oya = $lines[0];
	if ($oya =~ /<>/) {
		&error("로그가정하 없습니다.<P><small>\(v2.5이전의 로그의 경우변환의 필요합니다\)<\/small>");
	}

	shift(@lines);

	## 삭제키에 한글 삭제 ##
	@new=();
	foreach $line (@lines) {
		$dflag = 0;
		($num,$k,$dt,$name,$email,$sub,$com,$url,$host,$pw) = split(/<>/,$line);

		if ($FORM{'del'} eq "$dt") {
			$dflag = 1;
			$encode_pwd = $pw;
			$del_num = $num;
			if ($k eq '') { $oyaflag=1; }

		} elsif ($oyaflag && $del_num eq "$k") {
			$dflag = 1;
		}

		if ($dflag == 0) { push(@new,$line); }
	}

	if ($del_num eq '') { &error("삭제대상글을 찾을 수 없습니다"); }
	else {
		if ($encode_pwd eq '') { &error("삭제키가 설정됨되어 있지 않습니다"); }
		$check = &passwd_decode("$FORM{'del_key'}","$encode_pwd");
		if ($check ne 'yes') { &error("비밀번호가 다릅니다"); }
	}

	# 원글 NO 을부가
	unshift(@new,$oya);

	## 로그를 갱신 ##
	open(DB,">$logfile") || &error("Can't write $logfile");
	print DB @new;
	close(DB);

	# 잠금해제
	if (-e $lockfile) { unlink($lockfile); }

	# 삭제 화면에돌아가기
	&msg_del;
}

#----------------------#
# 관리자일괄글 삭제 #
#----------------------#
sub admin_del {
	if ($FORM{'pass'} ne "$pass") { &error("비밀번호가 다릅니다"); }
	if ($FORM{'del'} eq "") { &error("확인상자의 선택 없습니다"); }

	# 잠금시작
	if ($lockkey == 1) { &lock1; }
	elsif ($lockkey == 2) { &lock2; }

	# 로그를 읽기
	open(DB,"$logfile") || &error("Can't open $logfile");
	@lines = <DB>;
	close(DB);

	# 원글 NO
	$oya = $lines[0];
	if ($oya =~ /<>/) {
		&error("로그가정하 없습니다.<P><small>\(v2.5이전의 로그의 경우변환의 필요합니다\)<\/small>");
	}

	shift(@lines);

	## 삭제 처리
	foreach $line (@lines) {
		$dflag=0;
		($num,$k,$dt,$name,$email,$sub,$com,$url,$host,$pw) = split(/<>/,$line);

		foreach $del (@delete) {
			if ($del eq "$dt") {
				$dflag = 1;
				$del_num = $num;
				if ($k eq '') { $oyaflag=1; }

			} elsif ($oyaflag && $del_num eq "$k") {
				$dflag = 1;
			}
		}
		if ($dflag == 0) { push(@new,$line); }
	}

	# 원글 NO 을부가
	unshift(@new,$oya);

	## 로그를 갱신 ##
	open(DB,">$logfile") || &error("Can't write $logfile");
	print DB @new;
	close(DB);

	# 잠금해제
	if (-e $lockfile) { unlink($lockfile); }

	# 삭제 화면에돌아가기
	&msg_del;
}

## --- 관리자입실 화면
sub admin {
	&header;
	print "<center><h4> 비밀번호를 입력해 주세요</h4>\n";
	print "<form action=\"$script\" method=$method>\n";
	print "<input type=hidden name=teamID value=\"$tid\">\n";
	print "<input type=hidden name=tPASS value=\"$tpass\">\n";
	print "<input type=hidden name=mode value=\"msg_del\">\n";
	print "<input type=hidden name=action value=\"admin\">\n";
	print "<input type=password name=pass size=8><input type=submit value='인증'>\n";
	print "</form></center>\n";
	print "</body></html>\n";
	exit;
}

## --- 카운터 처리
sub counter {
	# 열람 시만카운트업로드
	$match=0;
	if ($FORM{'mode'} eq '') {
		# 카운터 잠금
		if ($lockkey) { &lock3; }

		$match=1;
	}

	# 카운트 파일을 읽기
	open(NO,"$cntfile") || &error("Can't open $cntfile",'0');
	$cnt = <NO>;
	close(NO);

	# 카운트업로드
	if ($match) { $cnt++; }

	# 갱신
	open(OUT,">$cntfile") || &error("Write Error : $cntfile");
	print OUT $cnt;
	close(OUT);

	# 카운터 잠금해제
	if (-e $cntlock) { unlink($cntlock); }

	# 자릿 수조정
	while(length($cnt) < $mini_fig) { $cnt = '0'. "$cnt"; }
	@cnts = split(//,$cnt);

	print "<table><tr><td>\n";

	# GIF 카운터 표시
	if ($counter == 2) {
		foreach (0.. $#cnts) {
			print "<img src=\"$gif_path/$cnts[$_]\.gif\" alt=\"$cnts[$_]\" width=\"$mini_w\" height=\"$mini_h\">";
		}

	# 텍스트카운터 표시
	} else {
		print "<font color=\"$cnt_color\" face=\"verdana,Times New Roman,Arial\">$cnt</font>";
	}

	print "</td></tr></table>\n";
}

## --- 잠금 파일(symlink 함수)
sub lock1 {
	local($retry) = 5;
	while (!symlink(".", $lockfile)) {
		if (--$retry <= 0) { &error('LOCK is BUSY'); }
		sleep(1);
	}
}

## --- 잠금 파일(open 함수)
sub lock2 {
	local($flag) = 0;
	foreach (1.. 5) {
		if (-e $lockfile) { sleep(1); }
		else {
			open(LOCK,">$lockfile");
			close(LOCK);
			$flag = 1;
			last;
		}
	}
	if ($flag == 0) { &error("LOCK is BUSY"); }
}

## --- 카운터 잠금
sub lock3 {
	$cnt_flag = 0;
	foreach (1.. 7) {
		if (-e $cntlock) { sleep(1); }
		else {
			open(LOCK,">$cntlock");
			close(LOCK);
			$cnt_flag = 1;
			last;
		}
	}
	if (!$cnt_flag) { unlink($cntlock); }
}

## --- 메일전송
sub mail_to {
	$mail_subj = "$title 에게시가 있었습니다.";

 	Utf8InPlace($mail_subj);
 	Utf8InPlace($name);
 	Utf8InPlace($subj);
 	Utf8InPlace($comment);
	if ($date_type && $FORM{'resno'} eq "") { Utf8InPlace($date); }

	$comment =~ s/<br>/\n/g;
	$comment =~ s/\&lt\;/</g;
	$comment =~ s/\&gt\;/>/g;

	open(MAIL,"| $sendmail $mailto") || &error("Can't post sendmail");
	print MAIL "To: $mailto\n";

	# 메일 주소가 없는 경우다미메일에배치키환에
	if ($FORM{'email'} eq "") { $email = 'nomail@xxx.xxx'; }

	print MAIL "From: $email\n";
	print MAIL "Subject: $mail_subj\n";
	print MAIL "MIME-Version: 1.0\n";
	print MAIL "Content-type: text/plain; charset=UTF-8\n";
	print MAIL "Content-Transfer-Encoding: 7bit\n";
	print MAIL "X-Mailer: $ver\n\n";
	print MAIL "$mail_subj\n";
	print MAIL "--------------------------------------------------------\n";
	print MAIL "TIME : $date\n";
	print MAIL "NAME : $name\n";
	print MAIL "EMAIL: $FORM{'email'}\n";
	if ($url ne "") { print MAIL "URL : http://$url\n"; }

	if ($FORM{'resno'} ne "") { $subj = "(Res Message)"; }
	elsif ($FORM{'resno'} eq "" && $subj eq "") { $subj = "no title"; }

	print MAIL "TITLE: $subj\n\n";
	print MAIL "$comment\n";
	print MAIL "--------------------------------------------------------\n";
	close(MAIL);
}

#----------------------#
# 비밀번호암호 처리 #
#----------------------#
sub passwd_encode {
	$inpw = $_[0];
	@SALT = ('a'..'z', 'A'..'Z', '0'..'9', '.', '/');
	srand;
	$salt = $SALT[int(rand(@SALT))]. $SALT[int(rand(@SALT))];
	return crypt($inpw, $salt);
}

#----------------------#
# 비밀번호대조 처리 #
#----------------------#
sub passwd_decode {
	($inpw, $logpw) = @_;
	if ($logpw =~ /^\$1\$/) { $key = 3; } else { $key = 0; }

	local($check) = "no";
	if (crypt($inpw, substr($logpw,$key,2)) eq "$logpw") {
		$check = "yes";
	}
}

#--------------#
# 자동링크 #
#--------------#
sub auto_link {
	$_[0] =~ s/([^=^\"]|^)(http\:[\w\.\~\-\/\?\&\+\=\:\@\%\;\#]+)/$1<a href=$2 target=_top>$2<\/a>/g;
}

#------------------#
# HTML 의헤더 #
#------------------#
sub header {
	print "Content-type: text/html; charset=UTF-8\n\n";
	print <<"EOM";
<html>
<head>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
<title>$title</title></head>
<body background="$backgif" bgcolor="$bgcolor" text="$text" link="$link" vlink="$vlink" alink="$alink">
EOM
}

## --- HTML 의푸터
sub footer {
	## 저작권 표시(삭제불가)
	print "<center>$banner2<P><small><!-- $ver -->\n";
	print "- <a href=\"http://www.kent-web.com/\" target='_top'>Petit Board</a> -\n";
	print "<BR>Edit:<a href=\"http://espion.s7.xrea.com/\" target='_top'>Web note</a> -\n";
	print "</small></center>\n";
	print "</body></html>\n";
}

## --- 쿠키의 발 줄
sub set_cookie {
	# 쿠키는60일간유효
	($secg,$ming,$hourg,$mdayg,$mong,$yearg,$wdayg) = gmtime(time + 60*24*60*60);

	$yearg += 1900;
	if ($secg < 10) { $secg = "0$secg"; }
	if ($ming < 10) { $ming = "0$ming"; }
	if ($hourg < 10) { $hourg = "0$hourg"; }
	if ($mdayg < 10) { $mdayg = "0$mdayg"; }

	$month = ('Jan','Feb','Mar','Apr','May','Jun',
			'Jul','Aug','Sep','Oct','Nov','Dec')[$mong];
	$youbi = ('Sunday','Monday','Tuesday','Wednesday',
			'Thursday','Friday','Saturday')[$wdayg];

	$date_gmt = "$youbi, $mdayg\-$month\-$yearg $hourg:$ming:$secg GMT";
	$cook="name\:$name\,email\:$email\,url\:$url\,pwd\:$pwd\,color\:$color";
	print "Set-Cookie: PETIT=$cook; expires=$date_gmt\n";
}

## --- 쿠키를 가져옴
sub get_cookie {
	@pairs = split(/\;/, $ENV{'HTTP_COOKIE'});
	foreach $pair (@pairs) {
		local($name, $value) = split(/\=/, $pair);
		$name =~ s/ //g;
		$DUMMY{$name} = $value;
	}
	@pairs = split(/\,/, $DUMMY{'PETIT'});
	foreach $pair (@pairs) {
		local($name, $value) = split(/\:/, $pair);
		$COOKIE{$name} = $value;
	}

	$c_name = $COOKIE{'name'};
	$c_email = $COOKIE{'email'};
	$c_url = $COOKIE{'url'};
	$c_pwd = $COOKIE{'pwd'};
	$c_color = $COOKIE{'color'};

	if ($FORM{'name'}) { $c_name = $FORM{'name'}; }
	if ($FORM{'email'}) { $c_email = $FORM{'email'}; }
	if ($FORM{'url'}) { $c_url = $url; }
	if ($FORM{'pwd'}) { $c_pwd = $FORM{'pwd'}; }
	if ($FORM{'color'}) { $c_color = $FORM{'color'}; }
}

## --- 오류 처리
sub error {
	if (-e $lockfile) { unlink($lockfile); }
	if ($_[1] ne '0') { &header; }

	print "<center><hr width=\"75%\"><P><h3>ERROR !</h3>\n";
	print "<P><font color=red><B>$_[0]\n";
	print "<P>＊팀 비밀번호가 변경되었을 가능성이 있으므로, 다시 개발 화면에 들어가 주세요</B></font>\n";
	print "<P><hr width=\"75%\"></center>\n";
	&footer;
	exit;
}

## --- 호스트 이름가져오기
sub get_host {
	$host = $ENV{'REMOTE_HOST'};
	$addr = $ENV{'REMOTE_ADDR'};

	if ($get_remotehost) {
		if ($host eq "" || $host eq "$addr") {
			$host = gethostbyaddr(pack("C4", split(/\./, $addr)), 2);
		}
	}
	if ($host eq "") { $host = $addr; }
}

## --- 과거 로그 생성
sub pastlog {
	$new_flag = 0;

	# 과거 NO 을 열기
	open(NO,"$nofile") || &error("Can't open $nofile");
	$count = <NO>;
	close(NO);

	# 과거 로그의 파일 이름을 정의
	$pastfile = "$past_dir/$count\.html";

	# 과거 로그가 없는 경우, 신규에자동 생성하다
	unless(-e $pastfile) { &new_log; }

	# 과거 로그를 열기
	if ($new_flag == 0) {
		open (IN,"$pastfile") || &error("Can't open $pastfile");
		@past = <IN>;
		close(IN);
	}

	# 규정의 줄 수를 초과 하면, 다음 파일을 자동 생성하다
	if ($#past> $log_line) { &next_log; }

	foreach $pst_line (@past_data) {
		($pnum,$pk,$pdt,$pname,$pemail,$psub,$pcom,
			$purl,$phost,$ppw) = split(/<>/, $pst_line);

		if ($pk eq "" && $psub eq "") { $psub = "no title"; }
		if ($pemail) { $pname = "<a href=mailto:$pemail>$pname</a>"; }
		if ($purl) { $purl="<a href=http://$purl target=_top>http://$purl</a>"; }
		if ($pk) { $pnum = "$pk 로의 답글"; }

		# 자동링크
		if ($autolink) { &auto_link($pcom); }

		# 저장글을 형식
		$html = <<"HTML";
[$pnum] <font color=$sbj_color><b>$psub</b></font><!--T--> 게시자:<font color=$link><b>$pname</b></font> <small>게시일:$pdt</small><p><blockquote>$pcom<p>$purl</blockquote><!--$phost--><hr>
HTML
		push(@htmls,"$html");
	}


	@news = ();
	foreach $line (@past) {
		if ($line =~ /<!--OWARI-->/i) { last; }
		push (@news,$line);
		if ($line =~ /<!--HAJIME-->/i) { push (@news,@htmls); }
	}

	push (@news,"<!--OWARI-->\n</body></html>\n");

	# 과거 로그를 갱신
	open(OUT,">$pastfile") || &error("Can't write $pastfile");
	print OUT @news;
	close(OUT);

}

## --- 과거 로그다음 파일 생성루틴
sub next_log {
	# 다음 파일 때문에 의카운트업로드
	$count++;

	# 카운트 파일갱신
	open(NO,">$nofile") || &error("Can't write $nofile");
	print NO "$count";
	close(NO);

	$pastfile = "$past_dir/$count\.html";

	&new_log;
}

## --- 신규과거 로그 파일 생성루틴
sub new_log {
	$new_flag = 1;

	if ($backgif) { $bgkey = "background=\"$backgif\""; }
	else { $bgkey = "bgcolor=$bgcolor"; }

	$past[0] = "<html><head><META HTTP-EQUIV=\"Content-Type\" CONTENT=\"text/html; charset=UTF-8\"><title>과거 로그</title></head>\n";
	$past[1] = "<body $bgkey text=$text link=$link vlink=$vlink alink=$alink><hr size=1>\n";
	$past[2] = "<\!--HAJIME-->\n";
	$past[3] = "<\!--OWARI-->\n";
	$past[4] = "</body></html>\n";

	# 신규과거 로그 파일을 생성갱신
	open(OUT,">$pastfile") || &error("Can't write $pastfile");
	print OUT @past;
	close(OUT);

	# 권한을666로.
	chmod(0666,"$pastfile");
}

###-----------------------------------------------------------------###
# 접속금지 명령

sub access {

print <<_HTML_;

<HTML><HEAD><META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8"><TITLE>---</TITLE></HEAD>
<body bgcolor=#EEFFFF>
<BR><BR><center><H1>부정나접속입니다</H1><br>
 <font size=+1>톱 페이지는 여기입니다<BR><br>
 <A HREF=
_HTML_

 print $ref_main. ">". $ref_main;

print <<_HTML_;
</A></font>
</BODY></HTML>
_HTML_

exit;

}
###-----------------------------------------------------------------###
# 로그 파일 OPEN

sub logpass {


# 로그를 읽기
open(IN,"../team.cgi") || &error("Can't open LogFile");

 while($l = <IN>) {
	$tid = int($l);
	$tname = <IN>;
	chomp($tname);
	$tpass = <IN>;
	chomp($tpass);
	if($FORM{'teamID'} eq $tid && $FORM{'tPASS'} eq $tpass){
	 $logfile = $tid. '.cgi';
	 $title = $tname. '전략실';
	 return;
	}
	$team += 1;
 }
close(IN);

}

