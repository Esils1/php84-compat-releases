#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}

BEGIN {
	*Utf8Text = sub {
		my($s)=@_;
		return '' unless defined $s;
		utf8::decode($s) unless utf8::is_utf8($s);
		return $s;
	} unless defined &Utf8Text;

	*Utf8InPlace = sub {
		utf8::decode($_[0]) if defined $_[0] && !utf8::is_utf8($_[0]);
	} unless defined &Utf8InPlace;
}
## PONNY CHAT v3.4 (2000/12/13)
## Copyright(C) Kent Web 2000
## webmaster@kent-web.com
## http://www.kent-web.com/

$ver = 'PONNY v3.4'; # 버전 정보

#--- [주의 사항] ------------------------------------------------#
# 1. 이 스크립트는 프리 소프트웨어입니다. 이 스크립트를 사용했습니다	#
# 어떠한 손해에 대해서도 제작자는 책임을 지지 않습니다.		#
# 2. 설치에 관한질문은 지원 게시판에 확인해 주세요.	#
# 직접메일에 한질문은 절대오받있었음하고 있는 않습니다.	#
#---------------------------------------------------------------#

#============#
# 설정 항목 #
#============#

# UTF-8 환경에서는 외부 문자 변환 라이브러리를 사용하지 않습니다.

# 제목문자의 색
$t_color = "#008040";

# 제목의 대크기
$t_size = '16pt';

# 본문의 문자대크기
$b_size = '10pt';

# body 태그
$body = '<body bgcolor="#F1F1F1" text="#000000">';

# 복귀리선의 URL (index.html 등)
$homepage = '../../../hako/';

# 전략실(게시판)
$bbs = '../bbs.cgi';

# 최대글 수
$max = 25;

# 문자색을 지정(상아래의 배열은 반드시페아에서)
@COLORS = ('0000FF','DF0000','008040','800000','C100C1','FF80C0','FF8040','000080');
@IROIRO = ('청','적','미도리','차','보라','핑크','오렌지','아이색');

# 새로 고침 시간
@retime = (0,30,40,50,60);

# 새로 고침 시간(초기 값)
$retime = 40;

# 코멘트간의 구조절(<br>=줄바꿈 <P>=단계락 <hr>=괘선선)
$sikiri = '<hr>';

# 입퇴실 시 메시지
$in_msg = "님, 어서 오세요.";	# 입실 시
$out_msg = "님, 할 수 있도록라면~.";	# 퇴실 시

# 입퇴실안내 메시지의 색
$rep_color = "#808080";

# method 의형식(POST/GET)
$method = 'POST';

# 스크립트 파일 이름
$script = './chat.cgi';

# 잠금 파일
$lockfile = './ponny.lock';

#============#
# 설정완료 #
#============#

&decode;
&logpass;
if ($in{'mode'} eq "form") { &form1; }
elsif ($in{'mode'} eq "into") { &form2; }
elsif ($in{'comment'} && $in{'mode'} eq "regist") { &regist; }
elsif ($in{'mode'} eq "byebye") { &byebye; }
elsif ($in{'mode'} eq "top") { &top_view; }
&log_view;


#----------------------#
# 양식1 : 입실 시 #
#----------------------#
sub form1 {
	&header('body');
	print <<"EOM";
<center>
<form method="$method" action="$script" target="form" name="ponny">
<input type=hidden name=teamID value="$in{'teamID'}">
<input type=hidden name=tPASS value="$in{'tPASS'}">
<input type=hidden name=mode value="into">
<table border=2 cellspacing=0>
<tr><th colspan=2><font color="$t_color" size=5><b style="font-size:$t_size">$title</b></font></th></tr>
<tr><td><b>이름</b> <input type=text name=name size=20></td></tr>
<tr><td>새로 고침 <select name=retime>
EOM
	$in{'retime'} = $retime;
	foreach (@retime) {
		if ($in{'retime'} == $_) { print "<option value=$_ selected>$_초\n"; }
		else { print "<option value=$_>$_초\n"; }
	}
	print "</select> 문자색 <select name=color>\n";
	foreach (0.. $#COLORS) {
		print "<option value=\"$COLORS[$_]\">$IROIRO[$_]\n";
	}

	print <<"EOM";
</select></td></tr></table>
<table cellpadding=0 cellspacing=0><tr>
<th><input type=submit value="입실하다"></th></form>
<th><form action="$homepage" target="_top"><input type=submit value="돌아가기"></th>
</form></tr></table>
<SCRIPT LANGUAGE="JavaScript">
<!--
self.document.ponny.name.focus();
//-->
</SCRIPT>
</body></html>
EOM
	exit;
}

#----------------------#
# 양식2 : 발언부 #
#----------------------#
sub form2 {
	&regist('into');

	# MSIE 은 양식장을 조정
 	if ($ENV{'HTTP_USER_AGENT'} =~ /MSIE/i) { $text_width = 90; }
	else { $text_width = 50; }

	# 이하의 JavaScript(발언자동 삭제기능)은'유이차와'부터이식했습니다
	# http://www.cup.com/yui/
	&header;
	print <<"EOM";
<SCRIPT LANGUAGE="JavaScript">
<!--
function autoclear() {
 if (self.document.send) {
 if (self.document.cmode && self.document.cmode.autoclear) {
 if (self.document.cmode.autoclear.checked) {
 if (self.document.send.comment) {
 self.document.send.comment.value = "";
 self.document.send.comment.focus();
 }
 }
 }
 }
}
// -->
</SCRIPT>
</head>
$body
<form name=send method=$method action="$script" target="log" onSubmit="setTimeout(&quot;autoclear()&quot;,10)">
<input type=hidden name=mode value="regist">
<input type=hidden name=name value="$in{'name'}">
<input type=hidden name=teamID value="$in{'teamID'}">
<input type=hidden name=tPASS value="$in{'tPASS'}">
<input type=hidden name=name value="$in{'name'}">
<b>발언</b>:<input type=text size="$text_width" name=comment><br>
새로 고침 <select name=retime>
EOM
	foreach (@retime) {
		if ($in{'retime'} == $_) { print "<option value=$_ selected>$_초\n"; }
		else { print "<option value=$_>$_초\n"; }
	}
	print "</select> 문자색 <select name=color>\n";
	foreach (0.. $#COLORS) {
		if ($in{'color'} eq "$COLORS[$_]") {
			print "<option value=$COLORS[$_] selected>$IROIRO[$_]\n";
		} else {
			print "<option value=$COLORS[$_]>$IROIRO[$_]\n";
		}
	}

	print <<"EOM";
</select>
<input type=submit value="발언/새로 고침"><input type=reset value="지우기"></form>
<form action="$script" method="$method" target=form>
<table><tr>
<td>
 <input type=submit value="퇴실하다">
 <input type=hidden name=teamID value="$in{'teamID'}">
 <input type=hidden name=tPASS value="$in{'tPASS'}">
 <input type=hidden name=mode value="byebye">
 <input type=hidden name=name value="$in{'name'}">
</td></form>
<td valign=top>
 <form name="cmode">
 <input type="checkbox" name="autoclear" checked>발언자동 삭제
</td></form></tr></table>
</body></html>
EOM
	exit;
}

#------------#
# 글 표시 #
#------------#
sub log_view {
	if ($in{'retime'} eq "") { $in{'retime'} = $retime; }
	&header;
	if ($in{'retime'} != 0) {
		print "<META HTTP-EQUIV=\"refresh\" CONTENT=\"$in{'retime'}; URL=$script?retime=$in{'retime'}&teamID=$in{'teamID'}&tPASS=$in{'tPASS'}\">\n";
	}
	print "</head>\n$body\n";
	print "<TABLE WIDTH=100%><TR><TD><A HREF=$bbs?teamID=$in{'teamID'}&tPASS=$in{'tPASS'} target=_top>전략실</A>\n";
	print "</TD><TD align=right>새로 고침 설정:";
	if ($in{'retime'} == 0) { print "수동"; } else { print "$in{'retime'}초"; }
	print "</TD></TR></TABLE><hr>\n";

	open(IN,"$logfile") || &error("Open Error : $logfile");
	while (<IN>) {
		($date,$name,$com,$color) = split(/<>/);
		print "<font color=\"$color\"><b>$name</b>> $com</font> ($date)$sikiri\n";
	}
	close(IN);

	# 저작권을 표시(삭제불가)
	print "<center><small><!-- $ver -->\n";
	print "- <a href='http://www.kent-web.com/' target='_top'>Ponny Chat</a> -\n";
 print "<BR>Edit:<a href=\"http://espion.s7.xrea.com/\" target='_top'>Web note</a> -\n";
	print "</small></center>\n</body></html>\n";
	exit;
}

#----------------#
# 로그서포함 처리 #
#----------------#
sub regist {
	# 일 시의 가져오기
	($sec,$min,$hour,$mday,$mon) = localtime(time);
	$date = sprintf("%02d/%02d-%02d:%02d:%02d",$mon+1,$mday,$hour,$min,$sec);

	# 로그형태를 판단
	if ($_[0] eq 'into') {
		$in{'comment'} = "<b>$in{'name'}</b>$in_msg";
		$name = "MASTER";
		$color = $rep_color;
	} elsif ($_[0] eq 'bye') {
		$in{'comment'} = "<b>$in{'name'}</b>$out_msg";
		$name = "MASTER";
		$color = $rep_color;
	} else {
		$name = $in{'name'};
		$color = $in{'color'};
	}

	# 잠금시작
	&lock;

	open(IN,"$logfile") || &error("Open Error : $logfile");
	@lines = <IN>;
	close(IN);

	# 갱신 처리
	while ($max <= @lines) { pop(@lines); }
	unshift (@lines,"$date<>$name<>$in{'comment'}<>$color<>$ENV{'REMOTE_ADDR'}\n");
	open(OUT,">$logfile") || &error("Write Error : $logfile");
	print OUT @lines;
	close(OUT);

	# 잠금해제
	unlink($lockfile) if (-e $lockfile);

}

#----------------#
# 데코드 처리 #
#----------------#
sub decode {
	if ($ENV{'REQUEST_METHOD'} eq "POST") {
		read(STDIN, $buffer, $ENV{'CONTENT_LENGTH'});
	} else { $buffer = $ENV{'QUERY_STRING'}; }
	@pairs = split(/&/, $buffer);
	foreach (@pairs) {
		($name,$value) = split(/=/);
		$value =~ tr/+/ /;
		$value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;

		# 문자코드를 시후와 JIS 변환
		Utf8InPlace($value);

		# 줄바꿈은 삭제
		$value =~ s/\r//g;
		$value =~ s/\n//g;

		$value =~ s/</&lt;/g; $value =~ s/>/&gt;/g;

		$in{$name} = $value;
	}
	if ($in{'name'} eq "") { $in{'name'} = "이름무시의 곤베에"; }
}

#------------#
# 퇴실 처리 #
#------------#
sub byebye {
	&regist('bye');
	&header('body');
	print <<"EOM";
<center><h3>$in{'name'}님, 이용해 주셔서 감사합니다</h3>
[<a href="$bbs?teamID=$in{'teamID'}&tPASS=$in{'tPASS'}" target="_top">전략실로 돌아가기</a>]
[<a href="$homepage" target="_top">맨 위로 돌아가기</a>]

</center>
</body></html>
EOM
	exit;
}

#--------------#
# 오류 처리 #
#--------------#
sub error {
	unlink($lockfile) if (-e $lockfile);

	&header('body') if (!$head_flag);
	print "<center><hr width='70%'><h3>ERROR !</h3>\n";
	print "<font color=red><B>$_[0]</B></font>\n";
	print "<P><hr width='70%'></center>\n</body></html>\n";
	exit;
}

#--------------#
# HTML 헤더 #
#--------------#
sub header {
	$head_flag = 1;
	print "Content-type: text/html; charset=UTF-8\n\n";
	print <<"EOM";
<html><head>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
<STYLE TYPE="text/css">
<!-- body,tr,td,th { font-size:$b_size } -->
</STYLE>
<title>$title</title>
EOM
	if ($_[0] eq "body") { print "</head>\n$body\n"; }
}

#----------------------#
# 잠금 파일 처리 #
#----------------------#
sub lock {
	local($flag)=0;
	foreach (1.. 5) {
		if (-e $lockfile) { sleep(1); }
		else {
			open(LOCK,">$lockfile") || &error("Lock Error");
			close(LOCK);
			$flag=1; last;
		}
	}
	if (!$flag) { &error("LOCK is BUSY"); }
}

#--------------#
# 중단 표시 #
#--------------#
sub top_view {
print "Content-type: text/html; charset=UTF-8\n\n";
print <<_HTML_;

<html>
<head><META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8"><title>${title}</title>
</head>
<frameset rows="135,*">
<frame name="form" src="./${script}?mode=form&teamID=$in{'teamID'}&tPASS=$in{'tPASS'}" target="_self">
<frame name="log" src="./${script}?teamID=$in{'teamID'}&tPASS=$in{'tPASS'}">
<noframes>
<body>
<h3>프레임비대응의 브라우저의 분은 이용할 수 없습니다</h3>
</body></noframes>
</frameset>
</html>


_HTML_

exit;

}

#----------------#
# 로그 파일 #
#----------------#
sub logpass {
	my($i) = 0;

	# 로그를 읽기
	open(IN,"../../team.cgi") || &error("Can't open LogFile");

 while($l = <IN>) {
		$i = int($l);
		$tname = <IN>;
		chomp($tname);
		$tpass = <IN>;
		chomp($tpass);
		if($in{'teamID'} == $i && $in{'tPASS'} eq $tpass){
		 $logfile = $i. ".cgi";
			$lockfile = $i. ".lock";

		 $title = $tname. '전략회의 실';
			last;
		}
 }
	close(IN);
	if(!$logfile) {
		&error2();
	}
}

#---------------#
# 오류 처리2 #
#---------------#
sub error2 {
	unlink($lockfile) if (-e $lockfile);

	&header('body') if (!$head_flag);
	print<<_HTML_;

<center><hr width='70%'><h3>ERROR !</h3>
<font color=red><B>
턴이 갱신되었을 가능성이 있으므로,<BR>
번거롭겠지만 개발 화면에서 다시 들어가 주세요.<BR>
</B>
</font>
<P><hr width='70%'>
</center>
</body>
</html>

_HTML_

	exit;
}

