#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}
#----------------------------------------------------------------------
# 모형정원 제도 ver2.30
# 지도 모드 모듈(ver1.00)
# 사용 조건과 사용 방법은 hako-readme.txt 파일을 참조해 주세요
#
# 모형정원 제도의 페이지: http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html
#----------------------------------------------------------------------
# 모형정원 팀 토너먼트
# 지도 모드 모듈
# $Id: hako-map.cgi 2 2003-07-02 03:09:48Z gaba $

#----------------------------------------------------------------------
# 관광 모드
#----------------------------------------------------------------------
# 메인
sub printIslandMain {
	# 개방
	unlock();

	# id에서 섬 번호를 가져옴
	$HcurrentNumber = $HidToNumber{$HcurrentID};

	# 왠지그 섬이 없는 경우
	if($HcurrentNumber eq '') {
		tempProblem();
		return;
	}

	# 이름 가져오기
	$HcurrentName = $Hislands[$HcurrentNumber]->{'name'};

	# 관광 화면
	tempPrintIslandHead(); # 수 있도록 말로!!
	islandInfo(); # 섬의 정보
	islandMap(0); # 섬 지도, 관광 모드
	islandJump();
	# ○○섬 로컬 게시판
	if($HuseLbbs) {
		tempLbbsHead();	 # 로컬 게시판
		tempLbbsInput(); # 작성 양식
		tempLbbsContents(); # 게시판내용
	}

	# 최근 상황
	tempRecent(0);
}

#----------------------------------------------------------------------
# 개발 모드
#----------------------------------------------------------------------
# 메인
sub ownerMain {
	# 개방
	unlock();

	# 모드를 명시
	$HmainMode = 'owner';

	# id에서 섬을 가져옴
	$HcurrentNumber = $HidToNumber{$HcurrentID};
	my($island) = $Hislands[$HcurrentNumber];
	$HcurrentName = $island->{'name'};

	# 비밀번호
	if(!checkPassword($island->{'password'},$HinputPassword)) {
		# password 오류
		tempWrongPassword();
		return;
	}
	writeownerlog($HimgLine);

	# 개발 화면
	if($HjavaMode eq 'java') {
		tempOwnerJava(); # 'JavaScript개발계획'
	}else{			 # '일반 모드개발계획'
		tempOwner();
	}


	# ○○섬 로컬 게시판
#	if($HuseLbbs) {
#		tempLbbsHead();	 # 로컬 게시판
#		tempLbbsInputOW(); # 작성 양식
#		tempLbbsContents(); # 게시판내용
#	}

	# ○○섬 로컬 게시판
	if($HuseLbbs) {
		tempLbbsHead();	 # 로컬 게시판
				if($HjavaMode eq 'java') { # JavaScript용작성 양식
						tempLbbsInputJava();
				}else{ tempLbbsInputOW(); } # 일반 모드의 작성 양식
		tempLbbsContents(); # 게시판내용
	}

	# 최근 상황
	tempRecent(1);
}

#----------------------------------------------------------------------
# 명령 모드
#----------------------------------------------------------------------
# 메인
sub commandMain {
	# id에서 섬을 가져옴
	$HcurrentNumber = $HidToNumber{$HcurrentID};
	my($island) = $Hislands[$HcurrentNumber];
	$HcurrentName = $island->{'name'};

	# 비밀번호
	if(!checkPassword($island->{'password'},$HinputPassword)) {
		# password 오류
		unlock();
		tempWrongPassword();
		return;
	}

	# 모드에서 분기
	my($command) = $island->{'command'};

	if($HcommandMode eq 'delete') {
		slideFront($command, $HcommandPlanNumber);
		tempCommandDelete();
	} elsif(($HcommandKind == $HcomAutoPrepare) ||
			($HcommandKind == $HcomAutoPrepare2)) {
		# 전체 개간, 전체땅고르기
		# 좌표배열을 만들기
		makeRandomPointArray();
		my($land) = $island->{'land'};

		# 자동 입력 시작 위치 보정: 지정이 없으면 기존 명령 아래 첫 빈 슬롯부터 추가
		if($HcommandPlanNumber !~ /^[0-9]+$/) {
			my($emptyNo) = $HcommandMax - 1;
			for(my $pi = 0; $pi < $HcommandMax; $pi++) {
				if($command->[$pi]->{'kind'} == $HcomDoNothing) { $emptyNo = $pi; last; }
			}
			$HcommandPlanNumber = $emptyNo;
		}

		# 명령 종류결정
		my($kind) = $HcomPrepare;
		if($HcommandKind == $HcomAutoPrepare2) {
			$kind = $HcomPrepare2;
		}

		my($i) = 0;
		my($j) = 0;
		while(($j < $HpointNumber) && ($i < $HcommandMax)) {
			my($x) = $Hrpx[$j];
			my($y) = $Hrpy[$j];
			if($land->[$x][$y] == $HlandWaste) {
				slideBack($command, $HcommandPlanNumber);
				$command->[$HcommandPlanNumber] = {
					'kind' => $kind,
					'target' => 0,
					'x' => $x,
					'y' => $y,
					'arg' => 0
					};
				$i++;
			}
			$j++;
		}
		tempCommandAdd();
	} elsif($HcommandKind == $HcomAutoDelete) {
		# 전체 삭제
		my($i);
		for($i = 0; $i < $HcommandMax; $i++) {
			slideFront($command, $HcommandPlanNumber);
		}
		tempCommandDelete();
	} elsif($HcommandKind == $HcomPrepRecr) {
		# 매립 + 땅고르기
		if($HcommandMode eq 'insert') {
			slideBack($command, $HcommandPlanNumber);
		}
		slideBack($command, $HcommandPlanNumber);
		tempCommandAdd();
		# 명령을 등록
		$command->[$HcommandPlanNumber] = {
			'kind' => $HcomReclaim,
			'target' => $HcommandTarget,
			'x' => $HcommandX,
			'y' => $HcommandY,
			'arg' => $HcommandArg
			};
		$command->[$HcommandPlanNumber + 1] = {
			'kind' => $HcomPrepare2,
			'target' => $HcommandTarget,
			'x' => $HcommandX,
			'y' => $HcommandY,
			'arg' => $HcommandArg
			};
	} else {
		if($HcommandMode eq 'insert') {
			slideBack($command, $HcommandPlanNumber);
		}
		tempCommandAdd();
		# 명령을 등록
		$command->[$HcommandPlanNumber] = {
			'kind' => $HcommandKind,
			'target' => $HcommandTarget,
			'x' => $HcommandX,
			'y' => $HcommandY,
			'arg' => $HcommandArg
			};
	}

	# 데이터 쓰기
	writeIslandsFile($HcurrentID);

	# owner mode 로
	ownerMain();

}

#----------------------------------------------------------------------
# 코멘트입력 모드
#----------------------------------------------------------------------
# 메인
sub commentMain {
	# id에서 섬을 가져옴
	$HcurrentNumber = $HidToNumber{$HcurrentID};
	my($island) = $Hislands[$HcurrentNumber];
	$HcurrentName = $island->{'name'};

	# 비밀번호
	if(!checkPassword($island->{'password'},$HinputPassword)) {
		# password 오류
		unlock();
		tempWrongPassword();
		return;
	}

	# 메시지를 갱신
	$island->{'comment'} = htmlEscape($Hmessage);

	# 데이터 쓰기
	writeIslandsFile($HcurrentID);

	# 코멘트갱신 메시지
	tempComment();

	# owner mode 로
	ownerMain();
}

#----------------------------------------------------------------------
# 로컬 게시판 모드
#----------------------------------------------------------------------
# 메인

sub localBbsMain {
	# id에서 섬 번호를 가져옴
	$HcurrentNumber = $HidToNumber{$HcurrentID};
	my($island) = $Hislands[$HcurrentNumber];
	my($foreignName);

	# 왠지그 섬이 없는 경우
	if($HcurrentNumber eq '' && $HcurrentID != 0) {
		unlock();
		tempProblem();
		return;
	}

	# 삭제 모드가 아니고 이름이나 메시지가 없는 경우
	if($HlbbsMode != 2) {
		if(($HlbbsName eq '') || ($HlbbsMessage eq '')) {
			unlock();
			tempLbbsNoMessage();
			return;
		}
	}

	# 섬무시 관광객이외는 비밀번호 확인
		if($HlbbsMode == 0 && $HforID != 0) {
			# 외국자 모드
			my($foreignNumber) = $HidToNumber{$HforID};
			if($foreignNumber eq ''){
				unlock();
				tempProblem();
				return;
			}
			my($fIsland) = $Hislands[$foreignNumber];
			if(!checkPassword($fIsland->{'password'},$HinputPassword)) {
				unlock();
				tempWrongPassword();
				return;
			}
			$foreignName = $fIsland->{'name'};
		} elsif($HlbbsMode) {
			# 섬주 모드
			if(!checkPassword($island->{'password'},$HinputPassword)) {
				# password 오류
				unlock();
				tempWrongPassword();
				return;
			}
		}

	my($lbbs);
	$lbbs = $island->{'lbbs'};

	# 모드에서 분기
	if($HlbbsMode == 2) {
		# 삭제 모드
		# 메시지를 앞으로 당기기
		slideBackLbbsMessage($lbbs, $HcommandPlanNumber);
		tempLbbsDelete();
	} else {
		# 기장 모드
		# 메시지를 뒤에밀기
		slideLbbsMessage($lbbs);

		if($HforID == 0 and $HlbbsMode == 0){
			$HlbbsMessage = htmlEscape($HlbbsMessage);
			$message = '3';
		} elsif (($HlbbsMode == 0) && ($HforID != $island->{'id'})){
			$HlbbsMessage = htmlEscape($HlbbsMessage). " <font size=-1 color=gray>(${foreignName} 섬)</font>";
			$message = '0';
		} else {
			$HlbbsMessage = htmlEscape($HlbbsMessage);
			$message = '1';
		}
		$HlbbsName = "$HislandTurn:". htmlEscape($HlbbsName);
		$lbbs->[0] = "$message>$HlbbsName>$HlbbsMessage";

		tempLbbsAdd();
	}

	# 데이터 쓰기
	writeIslandsFile($HcurrentID);

	# 원래의 모드로
	if($HlbbsMode == 0) {
		printIslandMain();
	} else {
		ownerMain();
	}
}

# 로컬 게시판의 메시지를 하나뒤에밀기
sub slideLbbsMessage {
	my($lbbs) = @_;
	my($i);
#	pop(@$lbbs);
#	push(@$lbbs, $lbbs->[0]);
	pop(@$lbbs);
	unshift(@$lbbs, $lbbs->[0]);
}

# 로컬 게시판의 메시지를 하나앞으로 당기기
sub slideBackLbbsMessage {
	my($lbbs, $number) = @_;
	my($i);
	splice(@$lbbs, $number, 1);
	$lbbs->[$HlbbsMax - 1] = '0>>';
}

#----------------------------------------------------------------------
# 섬 지도
#----------------------------------------------------------------------

# 정보의 표시
sub islandInfo {
	my($island) = $Hislands[$HcurrentNumber];
	my($team) = $Hteams[$HidToTeamNumber{$island->{'teamid'}}];

	# 정보 표시
	my($rank) = $HcurrentNumber + 1;
	my($farm) = $island->{'farm'};
	my($factory) = $island->{'factory'};
	$farm = ($farm == 0) ? "보유하지 않음" : "${farm}0$HunitPop";
	$factory = ($factory == 0) ? "보유하지 않음" : "${factory}0$HunitPop";

	my($mStr1) = '';
	my($mStr2) = '';
	if(($HhideMoneyMode == 1) || ($HmainMode eq 'owner')) {
		# 무조건또는 owner 모드
		$mStr1 = "<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_} 자금${H_tagTH}</NOBR></TH>";
		$mStr2 = "<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$team->{'money'}$HunitMoney</NOBR></TD>";
	} elsif($HhideMoneyMode == 2) {
		my($mTmp) = aboutMoney($team->{'money'});

		# 1000억단위 모드
		$mStr1 = "<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_} 자금${H_tagTH}</NOBR></TH>";
		$mStr2 = "<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$mTmp</NOBR></TD>";
	}
	my($fightName) = '';
	my($fightMember) = '';
	if($team->{'fightid'}) {
		$fightName = "<A STYlE=\"text-decoration:none\" HREF=$HthisFile?TEAM=$team->{'fightid'}#data>${HtagTName_}$Hteams[$HidToTeamNumber{$team->{'fightid'}}]->{'name'}${H_tagTName}</A>";
		$fightMember = $Hteams[$HidToTeamNumber{$team->{'fightid'}}]->{'member'};
	} else {
		$fightName = "${HtagName_}<CENTER>- - -${H_tagName}</CENTER>";
	}
	my($comname) ="${HtagTH_}코멘트:${H_tagTH}";
	if(($island->{'ownername'} ne '0') && ($island->{'ownername'} ne "코멘트")){
		$comname = "<FONT COLOR=\"blue\"><B>$island->{'ownername'}:</b></font>";
	}
 if($HmainMode eq 'owner') {
		@access = stat("${teambbs}/$island->{'teamid'}.cgi");
		local($sec2,$min2,$hour2,$mday2,$mon2,$year) = localtime($access[9]);
		if($min2 < 10) { $min2 = "0" . $min2; }
		if($hour2 < 10) { $hour2 = "0" . $hour2; } $mon2++;
		$accessTime = " <B>전략회의실 최종갱신일 시</B> ($mon2/$mday2 $hour2:$min2)";
	}
# 시간 표시
my($hour, $min, $sec);
my($now) = time;
my($showTIME) = ($HislandLastTime + $HunitTime - $now);
$hour = int($showTIME / 3600);
$min = int(($showTIME - ($hour * 3600)) / 60);
$sec = $showTIME - ($hour * 3600) - ($min * 60);

	out(<<END);
<CENTER>
<B>턴$HislandTurn</B> (다음 턴까지,$hour 시간 $min 분 $sec 초)
$accessTime<TABLE BORDER>
<TR>
<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}순위${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}소속팀${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}상대 팀${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}인구${H_tagTH}</NOBR></TH>
$mStr1
<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}식량${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}면적${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}농장규모${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}공장규모${H_tagTH}</NOBR></TH>
</TR>
<TR>
<TD $HbgNumberCell align=middle nowrap=nowrap><NOBR>${HtagNumber_}$rank${H_tagNumber}</NOBR></TD>
<TD $HbgInfoCell align=left nowrap=nowrap><NOBR>
<A STYlE=\"text-decoration:none\" HREF=$HthisFile?TEAM=$team->{'id'}#data>${HtagTName_}$team->{'name'}${H_tagTName}</A>
</NOBR></TD>
<TD $HbgInfoCell align=left nowrap=nowrap><NOBR>$fightName</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$island->{'pop'}$HunitPop</NOBR></TD>
$mStr2
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$island->{'food'}$HunitFood</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$island->{'area'}$HunitArea</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>${farm}</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>${factory}</NOBR></TD>
</TR><TR>
<TD $HbgCommentCell COLSPAN=9 align=left nowrap=nowrap><NOBR>$comname$island->{'comment'}


END
	if($fightMember ne '') {
		out("</NOBR></TD></TR><TR><TD $HbgCommentCell COLSPAN=9 align=left nowrap=nowrap><NOBR>${HtagTH_}상대 팀멤버:${H_tagTH}");
		while($fightMember =~ s/([0-9]*),//) {
			my($tIsland) = $Hislands[$HidToNumber{$1}];
			out("<A STYlE=\"text-decoration:none\" HREF=$HthisFile?Sight=$tIsland->{'id'}>${HtagName_}$tIsland->{'name'} 섬${H_tagName}</A> ");
		}
	}
out("</NOBR></TD></TR></TABLE></CENTER>");

}

# 지도 표시
# 인 수가1이면, 미사일 기지등을 그대로 표시
sub islandMap {
	my($mode) = @_;
	my($island);
	$island = $Hislands[$HcurrentNumber];

	out(<<END);
<CENTER><TABLE BORDER><TR><TD>
END
	# 지형, 지형 값을 가져옴
	my($land) = $island->{'land'};
	my($landValue) = $island->{'landValue'};
	my($l, $lv);

	# 명령 가져오기
	my($command) = $island->{'command'};
	my($com, @comStr, $i);
	if($HmainMode eq 'owner') {
		for($i = 0; $i < $HcommandMax; $i++) {
			my($j) = $i + 1;
			$com = $command->[$i];
			if($com->{'kind'} < 20) {
				$comStr[$com->{'x'}][$com->{'y'}].=
					" [${j}]$HcomName[$com->{'kind'}]";
			}
		}
	}

	# 좌표(상)을 출력
	out("<IMG SRC=\"xbar.gif\" width=400 height=16><BR>");

	# 각 지형및 줄바꿈을 출력
	my($x, $y);
	for($y = 0; $y < $HislandSize; $y++) {
		# 짝 수행이면 번호 출력
		if(($y % 2) == 0) {
			out("<IMG SRC=\"space${y}.gif\" width=16 height=32>");
		}

		# 각 지형을 출력
		for($x = 0; $x < $HislandSize; $x++) {
			$l = $land->[$x][$y];
			$lv = $landValue->[$x][$y];
			landString($l, $lv, $x, $y, $mode, $comStr[$x][$y]);
		}

		# 홀 수행이면 번호 출력
		if(($y % 2) == 1) {
			out("<IMG SRC=\"space${y}.gif\" width=16 height=32>");
		}

		# 줄바꿈을 출력
		out("<BR>");
	}
	out("</TD></TR></TABLE></CENTER>\n");
}

sub landString {
	my($l, $lv, $x, $y, $mode, $comStr) = @_;
	my($point) = "($x,$y)";
	my($image, $alt);

	if($l == $HlandSea) {

		if($lv == 1) {
			# 얕은 바다
			$image = 'land14.gif';
			$alt = '바다(얕은 바다)';
		} else {
			# 바다
			$image = 'land0.gif';
			$alt = '바다';
		}
	} elsif($l == $HlandWaste) {
		# 황무지
		if($lv == 1) {
			$image = 'land13.gif'; # 착탄 지점
			$alt = '황무지';
		} else {
			$image = 'land1.gif';
			$alt = '황무지';
		}
	} elsif($l == $HlandPlains) {
		# 평지
		$image = 'land2.gif';
		$alt = '평지';
	} elsif($l == $HlandForest) {
		# 숲
		if($mode == 1) {
			$image = 'land6.gif';
			$alt = "숲(${lv}$HunitTree)";
		} else {
			# 관광객에게는 목장 수를 숨김
			$image = 'land6.gif';
			$alt = '숲';
		}
	} elsif($l == $HlandTown) {
		# 마을
		my($p, $n);
		if($lv < 30) {
			$p = 3;
			$n = '마을';
		} elsif($lv < 100) {
			$p = 4;
			$n = '마을';
		} else {
			$p = 5;
			$n = '도시';
		}

		$image = "land${p}.gif";
		$alt = "$n(${lv}$HunitPop)";
	} elsif($l == $HlandFarm) {
		# 농장
		$image = 'land7.gif';
		$alt = "농장(${lv}0${HunitPop}규모)";
	} elsif($l == $HlandFactory) {
		# 공장
		$image = 'land8.gif';
		$alt = "공장(${lv}0${HunitPop}규모)";
	} elsif($l == $HlandBase) {
		if($mode == 0) {
			# 관광객의 경우 숲인 척
			$image = 'land6.gif';
			$alt = '숲';
		} else {
			# 미사일 기지
			my($level) = expToLevel($l, $lv);
			$image = 'land9.gif';
			$alt = "미사일 기지 (레벨 ${level}/경험치 $lv)";
		}
	} elsif($l == $HlandDefence) {
		# 방위 시설
		if($mode == 0) {
			# 관광객의 경우 숲인 척
			$image = 'land6.gif';
			$alt = '숲';
		} else {
			$image = 'land10.gif';
			$alt = '방위 시설';
		}
	} elsif($l == $HlandHaribote) {
		# 가짜 시설
		$image = 'land10.gif';
		if($mode == 0) {
			# 관광객에게는 방위 시설처럼 표시
			$alt = '방위 시설';
		} else {
			$alt = '가짜 시설';
		}
	} elsif($l == $HlandMonument) {
		# 기념비
		$image = $HmonumentImage[$lv];
		$alt = $HmonumentName[$lv];
	}


	# 개발 화면일 경우 좌표 설정
	if($mode == 1) {
		out("<A HREF=\"JavaScript:void(0);\" onclick=\"ps($x,$y)\" onMouseOver=\"ShowMsg('$point $alt $comStr'); return true;\">");
	} else{
		out("<A HREF=\"JavaScript:void(0);\" onMouseOver=\"ShowMsg('$point $alt $comStr'); return true;\">");
	}

	out("<IMG SRC=\"$image\" ALT=\"$point $alt $comStr\" width=32 height=32 BORDER=0>");

	# 좌표 설정닫기지
	out("</A>");
}


#----------------------------------------------------------------------
# 템플릿기타
#----------------------------------------------------------------------
# 개별 로그 표시
sub logPrintLocal {
	my($mode) = @_;
	my($i);
	for($i = 0; $i < $HlogMax; $i++) {
		logFilePrint($i, $HcurrentID, $mode, 1);
	}
}

# ○○섬으로 수 있도록 말로!!
sub tempPrintIslandHead {
	out(<<END);
<CENTER>
${HtagBig_}${HtagName_}'${HcurrentName} 섬'${H_tagName}되도록!!${H_tagBig}<BR>
$HtempBack<BR>
</CENTER>
END
}

# ○○섬개발계획
sub tempOwner {
	my($island);
	$island = $Hislands[$HcurrentNumber];
	my($team) = $Hteams[$HidToTeamNumber{$island->{'teamid'}}];
	out(<<END);
<CENTER>
${HtagBig_}${HtagName_}${HcurrentName} 섬${H_tagName}개발계획${H_tagBig}<BR>
$HtempBack<BR>

<SCRIPT Language="JavaScript">
<!--
function ps(x, y) {
	document.forms[0].elements[4].options[x].selected = true;
	document.forms[0].elements[5].options[y].selected = true;
	return true;
}

function ns(x) {
	document.forms[0].elements[2].options[x].selected = true;
	return true;
}
function openBBS()
{
 document.bbsform.submit();
}

function openTEAM()
{
 document.teamform.submit();
}
//-->
</SCRIPT>

</CENTER>

END

	islandInfo();

	out(<<END);
<CENTER>
<TABLE BORDER>
<TR>
<TD $HbgInputCell>
<CENTER>
<FORM name="myForm" action="$HthisFile" method=POST>
<INPUT TYPE=submit VALUE="계획 전송" NAME=CommandButton$island->{'id'}>
<HR>
<B> 비밀번호</B></BR>
<INPUT TYPE=password NAME=PASSWORD VALUE="$HdefaultPassword">
<HR>
<B>계획번호</B><SELECT NAME=NUMBER>
END
	# 계획번호
	my($j, $i);
	for($i = 0; $i < $HcommandMax; $i++) {
		$j = $i + 1;
		out("<OPTION VALUE=$i>$j\n");
	}

	out(<<END);
</SELECT><BR>
<HR>
<B>개발계획</B><BR>
<SELECT NAME=COMMAND>
END

	#명령
	my($kind, $cost, $s);
	for($i = 0; $i < $HcommandTotal; $i++) {
		$kind = $HcomList[$i];
		$cost = $HcomCost[$kind];
		if($cost == 0) {
			$cost = '무료'
		} elsif($cost < 0) {
			$cost = - $cost;
			$cost.= $HunitFood;
		} else {
			$cost.= $HunitMoney;
		}
		if($kind == $HdefaultKind) {
			$s = 'SELECTED';
		} else {
			$s = '';
		}
#		print "<OPTION VALUE=$kind $s>$HcomName[$kind]($cost)\n";
		out("<OPTION VALUE=$kind $s>$HcomName[$kind]($cost)\n");
	}

	out(<<END);
</SELECT>
<HR>
<B>좌표(</B>
<SELECT NAME=POINTX>

END
	for($i = 0; $i < $HislandSize; $i++) {
		if($i == $HdefaultX) {
			out("<OPTION VALUE=$i SELECTED>$i\n");
		} else {
			out("<OPTION VALUE=$i>$i\n");
		}
	}

	out(<<END);
</SELECT>, <SELECT NAME=POINTY>
END

	for($i = 0; $i < $HislandSize; $i++) {
		if($i == $HdefaultY) {
			out("<OPTION VALUE=$i SELECTED>$i\n");
		} else {
			out("<OPTION VALUE=$i>$i\n");
		}
	}
	out(<<END);
</SELECT><B>)</B>
<HR>
<B>수량</B><SELECT NAME=AMOUNT>
END

	# 수량
	for($i = 0; $i < 50; $i++) {
		out("<OPTION VALUE=$i>$i\n");
	}

	out(<<END);
</SELECT>
<HR>
<B>대상 섬</B><BR>
<SELECT NAME=TARGETID>
END
out(getTargetList($team->{'id'},$team->{'fightid'}));
	out(<<END);
<BR>
</SELECT>
<HR>
<B>동작</B><BR>
<INPUT TYPE=radio NAME=COMMANDMODE VALUE=insert CHECKED>삽입
<INPUT TYPE=radio NAME=COMMANDMODE VALUE=write>덮어쓰기<BR>
<INPUT TYPE=radio NAME=COMMANDMODE VALUE=delete>삭제
<HR>
<INPUT TYPE=submit VALUE="계획 전송" NAME=CommandButton$island->{'id'}>

</CENTER>
</FORM>
<FORM NAME=bbsform ACTION="${baseDir}/${teambbs}/bbs.cgi" METHOD=POST>
<INPUT TYPE=HIDDEN NAME=teamID VALUE=$team->{'id'}>
<INPUT TYPE=HIDDEN NAME=tPASS VALUE=$team->{'password'}>
</FORM>
<FORM NAME=teamform ACTION=$HthisFile METHOD=POST>
<INPUT TYPE=HIDDEN NAME=TEAMID VALUE=$team->{'id'}>
<INPUT TYPE=HIDDEN NAME=PASSWORD2 VALUE=$team->{'password'}>
<INPUT TYPE=HIDDEN NAME=teamData VALUE=''>
</FORM>
<nobr><center>미사일 발사상한 수[<b> $island->{'fire'} </b>]발</center></nobr>
</TD>
<TD $HbgMapCell ALIGN=CENTER>
<FONT SIZE=+1><B>
<A HREF="JavaScript:void(0);" STYlE="text-decoration:none" onClick="openBBS();return false;">
전략회의실로</A>

<A HREF="JavaScript:void(0);" STYlE="text-decoration:none" onClick="openTEAM();return false;">
 작전본부로 </A>
</B>
</FONT>
END
	islandMap(1);	# 섬 지도, 소유자 모드
	out(<<END);
</TD>
<TD $HbgCommandCell>
END
	for($i = 0; $i < $HcommandMax; $i++) {
		tempCommand($i, $island->{'command'}->[$i]);
	}

	out(<<END);

</TD>
</TR>
</TABLE>
</CENTER>
<HR>
<CENTER>
${HtagBig_}코멘트갱신${H_tagBig}<BR>
<FORM action="$HthisFile" method="POST">
코멘트<INPUT TYPE=text NAME=MESSAGE SIZE=80 VALUE="$island->{'comment'}"><BR>
비밀번호<INPUT TYPE=password NAME=PASSWORD VALUE="$HdefaultPassword">
<INPUT TYPE=submit VALUE="코멘트갱신" NAME=MessageButton$island->{'id'}>
</FORM>
</CENTER>
END

}

# 입력 완료된 명령 표시
sub tempCommand {
	my($number, $command) = @_;
	my($kind, $target, $x, $y, $arg) =
		(
		 $command->{'kind'},
		 $command->{'target'},
		 $command->{'x'},
		 $command->{'y'},
		 $command->{'arg'}
		 );
	my($name) = "$HtagComName_${HcomName[$kind]}$H_tagComName";
	my($point) = "$HtagName_($x,$y)$H_tagName";
	$target = $HidToName{$target};
	if($target eq '') {
		$target = "무인";
	}
	$target = "$HtagName_${target} 섬$H_tagName";
	my($value) = $arg * $HcomCost[$kind];
	if($value == 0) {
		$value = $HcomCost[$kind];
	}
	if($value < 0) {
		$value = -$value;
		$value = "$value$HunitFood";
	} else {
		$value = "$value$HunitMoney";
	}
	$value = "$HtagName_$value$H_tagName";

	my($j) = sprintf("%02d:", $number + 1);

	out("<A STYlE=\"text-decoration:none\" HREF=\"JavaScript:void(0);\" onClick=\"ns($number)\"><NOBR>$HtagNumber_$j$H_tagNumber<FONT COLOR=\"$HnormalColor\">");

	if(($kind == $HcomDoNothing) || ($kind == $HcomAutoPrepare3) ||
	 ($kind == $HcomGiveup)) {
		out("$name");
	} elsif(($kind == $HcomMissileNM) ||
			($kind == $HcomMissilePP)) {
		# 미사일계
		my($n) = ($arg == 0 ? '무제한' : "${arg}발");
		out("$target$point 로$name($HtagName_$n$H_tagName)");
	} elsif($kind == $HcomSell) {
		# 식량 수출
		out("$name$value");
	} elsif($kind == $HcomPropaganda) {
		# 유치 활동
		out("$name");
	} elsif($kind == $HcomFood) {
		# 지원
		out("$target 로$name$value");
	} elsif($kind == $HcomDestroy) {
		# 굴착
		if($arg != 0) {
			out("$point 에서$name(예산${value})");
		} else {
			out("$point 에서$name");
		}
	} elsif(($kind == $HcomFarm) ||
			 ($kind == $HcomFactory)) {
		# 횟수 포함
		if($arg == 0) {
			out("$point 에서$name");
		} else {
			out("$point 에서$name($arg 회)");
		}
	} else {
		# 좌표 포함
		out("$point 에서$name");
	}

	out("</FONT></NOBR></A><BR>");
}

# 로컬 게시판
sub tempLbbsHead {
	out(<<END);
<CENTER>
<HR>
${HtagBig_}${HtagName_}${HcurrentName} 섬${H_tagName}관광객 통신${H_tagBig}<BR>
</CENTER>
END
}

# 로컬 게시판입력 양식
sub tempLbbsInput {
	out(<<END);
<CENTER>
<FORM action="$HthisFile" method="POST">
<font color=red><B> 섬이 없는 분도 글을 남길 수 있습니다. 게임 내용과 관계없는 발언은 가능하면 ${bbsname}에 작성해 주세요.</b></font>
<TABLE BORDER>
<TR>
<TH>이름</TH>
<TH>내용</TH>
</TR>
<TR>
<TD><INPUT TYPE="text" SIZE=32 MAXLENGTH=32 NAME="LBBSNAME" VALUE="$HdefaultName"></TD>
<TD><INPUT TYPE="text" SIZE=80 NAME="LBBSMESSAGE"></TD>
</TR>
<TR>
<TD colspan="2">자신의 섬:
<SELECT NAME="ISLANDID">
<OPTION value="0"> 섬 외 관광객
$HislandList</SELECT>
 비밀번호:<INPUT TYPE="password" SIZE=32 MAXLENGTH=32 NAME=PASSWORD VALUE="$HdefaultPassword">
<INPUT TYPE="submit" VALUE="등록" NAME="LbbsButtonFO$HcurrentID"></TD>
</TR>
</TABLE>
</FORM>
</CENTER>
END
}

# 로컬 게시판입력 양식 owner mode 용
sub tempLbbsInputOW {
	out(<<END);
<CENTER>
<FORM action="$HthisFile" method="POST">
<TABLE BORDER>
<TR>
<TH>이름</TH>
<TH COLSPAN=2>내용</TH>
</TR>
<TR>
<TD><INPUT TYPE="text" SIZE=32 MAXLENGTH=32 NAME="LBBSNAME" VALUE="$HdefaultName"></TD>
<TD COLSPAN=2><INPUT TYPE="text" SIZE=80 NAME="LBBSMESSAGE"></TD>
</TR>
<TR>
<TH> 비밀번호</TH>
<TH COLSPAN=2>동작</TH>
</TR>
<TR>
<TD><INPUT TYPE=password SIZE=32 MAXLENGTH=32 NAME=PASSWORD VALUE="$HdefaultPassword"></TD>
<TD align=right>
<INPUT TYPE="submit" VALUE="등록" NAME="LbbsButtonOW$HcurrentID">
</TD>
<TD align=right>
번호
<SELECT NAME=NUMBER>
END
	# 발언번호
	my($j, $i);
	for($i = 0; $i < $HlbbsMax; $i++) {
		$j = $i + 1;
		out("<OPTION VALUE=$i>$j\n");
	}
	out(<<END);
</SELECT>
<INPUT TYPE="submit" VALUE="삭제" NAME="LbbsButtonDL$HcurrentID">
</TD>
</TR>
</TABLE>
</FORM>
</CENTER>
END
}

# 로컬 게시판내용
sub tempLbbsContents {
	my($lbbs, $line);
	$lbbs = $Hislands[$HcurrentNumber]->{'lbbs'};
	out(<<END);
<CENTER>
<TABLE BORDER>
<TR>
<TH>번호</TH>
<TH>내용</TH>
</TR>
END

	my($i);
	for($i = 0; $i < $HlbbsMax; $i++) {
		$line = $lbbs->[$i];
		if($line =~ /([0-9]*)\>(.*)\>(.*)$/) {
			my($j) = $i + 1;
			out("<TR><TD align=center>$HtagNumber_$j$H_tagNumber</TD>");
			if($1 == 0) {
				# 관광객
				out("<TD>$HtagLbbsSS_$2> $3$H_tagLbbsSS</TD></TR>");
			} elsif($1 == 3) {
				# 섬무시 관광객
				out("<TD>$HtagLbbsSK_$2> $3$H_tagLbbsSK</TD></TR>");
			} else {
				# 섬주
				out("<TD>$HtagLbbsOW_$2> $3$H_tagLbbsOW</TD></TR>");
			}
		}
	}

	out(<<END);
</TD></TR></TABLE></CENTER>
END
}

# 로컬 게시판에서 이름이나 메시지가 없는 경우
sub tempLbbsNoMessage {
	out(<<END);
${HtagBig_}이름 또는 내용이 비어 있습니다..${H_tagBig}$HtempBack
END
}

# 쓰기/삭제
sub tempLbbsDelete {
	out(<<END);
${HtagBig_}기록 내용을 삭제했습니다${H_tagBig}<HR>
END
}

# 명령 등록
sub tempLbbsAdd {
	out(<<END);
${HtagBig_}기록을 수행했습니다${H_tagBig}<HR>
END
}

# 명령 삭제
sub tempCommandDelete {
	out(<<END);
${HtagBig_} 명령을 삭제했습니다${H_tagBig}<HR>
END
}

# 명령 등록
sub tempCommandAdd {
	out(<<END);
${HtagBig_} 명령을 등록했습니다${H_tagBig}<HR>
END
}

# 코멘트 변경성공
sub tempComment {
	out(<<END);
${HtagBig_}코멘트를 갱신했습니다${H_tagBig}<HR>
END
}

# 최근 상황
sub tempRecent {
	my($mode) = @_;
	out(<<END);
<HR>
${HtagBig_}${HtagName_}${HcurrentName} 섬${H_tagName}의 최근 상황${H_tagBig}<BR>
END
	logPrintLocal($mode);
}

#개발자방문질문 로그 생성
sub writeownerlog {
	my($view) = @_;
	if($view eq '') { $view = 'NO'; } else { $view = 'LOCAL'; }
	if($HjavaMode eq 'java') { $wJavaMode = 'JS'; } else { $wJavaMode = 'NO'; }
	$HcurrentNumber = $HidToNumber{$HcurrentID};
	my($island) = $Hislands[$HcurrentNumber];
	$id = $island->{'id'};
	my($team) = $Hteams[$HidToTeamNumber{$island->{'teamid'}}];

	my($userName, $userIP);
	my($sec, $min, $hour, $day, $month, $Year, $wday, $isdst) = localtime;
	$month ++;
	$Year += 1900;
	my($log_file) = "access_log/tag_". $month. "-". $day. ".cgi";
	#먼저출력
	open(OwOut, ">>${log_file}");
		$userIP = $ENV{'REMOTE_ADDR'};

		printf OwOut "%04d\/%02d\/%02d %02d:%02d:%02d", $Year, $month, $day, $hour, $min, $sec;
		print OwOut ", $userIP, ${HcurrentName} 섬, $team->{'name'}, ${view}, ${wJavaMode}\n";

	close(OwOut);

}
sub islandJump {
	out(<<END);

<CENTER>
<FORM action="$HthisFile" method="GET">
<SELECT NAME="Sight">
END
out(getIslandList($HcurrentID));
	out(<<END);
</SELECT>
<input type="submit" value=" GO ">
</FORM>
</CENTER>
END

}
1;
