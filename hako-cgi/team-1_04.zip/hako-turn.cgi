#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}
#----------------------------------------------------------------------
# 모형정원 제도 ver2.30
# 턴진행모듈(ver1.02)
# 사용 조건과 사용 방법은 hako-readme.txt 파일을 참조해 주세요
#
# 모형정원 제도의 페이지: http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html
#----------------------------------------------------------------------
# 모형정원 팀 토너먼트
# 턴진행모듈
# $Id: hako-turn.cgi 13 2004-02-18 05:35:38Z gaba $

#주변 2헥스의 좌표
my(@ax) = (0, 1, 1, 1, 0,-1, 0, 1, 2, 2, 2, 1, 0,-1,-1,-2,-1,-1, 0);
my(@ay) = (0,-1, 0, 1, 1, 0,-1,-2,-1, 0, 1, 2, 2, 2, 1, 0,-1,-2,-2);

#----------------------------------------------------------------------
# 섬 신규 생성 모드
#----------------------------------------------------------------------
# 메인
sub newIslandMain {
	# 섬이 가득 차서 없습니까 확인
	if($HislandNumber>= $HmaxIsland or $HislandTurn) {
		unlock();
		tempNewIslandFull();
		return;
	}

	# 이름이 있는 지 확인
	if($HcurrentName eq '') {
		unlock();
		tempNewIslandNoName();
		return;
	}

	# 이름이 유효한지 확인
	if($HcurrentName =~ /[,\?\(\)\<\>\$]|^무인$/) {
		# 사용 불가 이름
		unlock();
		tempNewIslandBadName();
		return;
	}

	# 이름의 중복 확인
	if(nameToNumber($HcurrentName) != -1) {
		# 이미 발견완료
		unlock();
		tempNewIslandAlready();
		return;
	}

	# password 의존재판정
	if($HinputPassword eq '') {
		# password 무시
		unlock();
		tempNewIslandNoPassword();
		return;
	}

	# 확인용 비밀번호
	if($HinputPassword2 ne $HinputPassword) {
		# password 오류
		unlock();
		tempWrongPassword();
		return;
	}

	# 새 섬의 번호 정하기
	$HcurrentNumber = $HislandNumber;
	$HislandNumber++;
	$Hislands[$HcurrentNumber] = makeNewIsland();
	my($island) = $Hislands[$HcurrentNumber];

	# 각종의 값을 설정
	$island->{'name'} = $HcurrentName;
	$island->{'id'} = $HislandNextID;
	$HislandNextID ++;
	$island->{'absent'} = 1;
	$island->{'comment'} = '(미 등록)';
	$island->{'password'} = encode($HinputPassword);
	$island->{'teamid'} = $HteamID;
	my($team) = $Hteams[$HidToTeamNumber{$island->{'teamid'}}];
	my($numMember) = $team->{'member'};
	my($count) = 0;
	while($numMember =~ s/([0-9]*),//) {
		$count++;
		if($HmenberCount == $count){
			unlock();
			tempOverMember();
			return;
		}
	}
	if($HteamID == 0) {
		unlock();
		tempOverMember();
		return;
	}
	# 인구기타 산출
	estimate($HcurrentNumber);
	teamEstimate($HcurrentNumber);
	$team->{'member'}.= $island->{'id'}. ",";
	$team->{'money'} += $HinitialMoney;
	# 데이터 쓰기
	writeIslandsFile($island->{'id'});
	writeTeamsFile();
	logDiscover($HcurrentName); # 로그

	# 개방
	unlock();

	# 발견 화면
	tempNewIslandHead($HcurrentName); # 발견했습니다!!
	islandInfo(); # 섬의 정보
	islandMap(1); # 섬 지도, 소유자 모드
}

# 새 섬 만들기
sub makeNewIsland {
	# 지형을 만들기
	my($land, $landValue) = makeNewLand();

	# 초기 명령을 생성
	my(@command, $i);
	for($i = 0; $i < $HcommandMax; $i++) {
		 $command[$i] = {
			 'kind' => $HcomDoNothing,
			 'target' => 0,
			 'x' => 0,
			 'y' => 0,
			 'arg' => 0
		 };
	}

	# 초기 게시판 생성
	my(@lbbs);
	for($i = 0; $i < $HlbbsMax; $i++) {
		 $lbbs[$i] = "0>>";
	}

	# 섬으로 반환
	return {
		'land' => $land,
		'landValue' => $landValue,
		'command' => \@command,
		'lbbs' => \@lbbs,
		'food' => $HinitialFood,
		'ownername' => '0'
	};
}

# 새 섬 지형 만들기
sub makeNewLand {
	# 기본형 생성
	my(@land, @landValue, $x, $y, $i);

	# 바다에 초기화
	for($y = 0; $y < $HislandSize; $y++) {
		 for($x = 0; $x < $HislandSize; $x++) {
			 $land[$x][$y] = $HlandSea;
			 $landValue[$x][$y] = 0;
		 }
	}

	# 섬 중앙 4×4에 황무지를 배치
	my($center) = int($HislandSize / 2 - 1);
	for($y = $center - 1; $y < $center + 3; $y++) {
		 for($x = $center - 1; $x < $center + 3; $x++) {
			 $land[$x][$y] = $HlandWaste;
		 }
	}

		# 초기의 섬의 면적고정규칙
		my($size,$seacon) = (16,0);

		# 8*8범위내에육지를 증식
		while($size < $HlandSizeValue){
			# 무작위좌표
			$x = random(8) + $center - 3;
			$y = random(8) + $center - 3;


			my($tmp) = countAround(\@land, $x, $y, $HlandSea, 7);
			if(countAround(\@land, $x, $y, $HlandSea, 7) != 7){
				# 주변에 육지가 있는 경우, 얕은 바다로
				# 얕은 바다는 황무지로
				# 황무지는 평지로
			 if($land[$x][$y] == $HlandSea) {
					if($landValue[$x][$y] == 1) {
						$land[$x][$y] = $HlandPlains;
						$landValue[$x][$y] = 0;
						$size++;
						$seacon--;
					} else {
		 				$landValue[$x][$y] = 1;
						$seacon++;
					}
			 }
			}
		}

	makeRandomPointArray();
	for($i = 0; $i < $HpointNumber; $i++) {
		last if($seacon == $HseaNum);
		$x = $Hrpx[$i];
		$y = $Hrpy[$i];
		if(countAround(\@land, $x, $y, $HlandPlains, 7) && $land[$x][$y] == $HlandSea && $landValue[$x][$y] == 0){
			$landValue[$x][$y] = 1;
			$seacon += $sea_flag ? -1: 1;
		}
	}

	# 숲을 만들기
	my($count) = 0;
	while($count < 4) {
		 # 무작위좌표
		 $x = random(4) + $center - 1;
		 $y = random(4) + $center - 1;

		 # 그곳이이미 숲이 아니면, 숲을 만들기
		 if($land[$x][$y] != $HlandForest) {
			 $land[$x][$y] = $HlandForest;
			 $landValue[$x][$y] = 5; # 처음은500본
			 $count++;
		 }
	}

	# 마을을 만들기
	$count = 0;
	while($count < 2) {
		 # 무작위좌표
		 $x = random(4) + $center - 1;
		 $y = random(4) + $center - 1;

		 # 그곳이 숲이나 도시가 아니면 도시를 만들기
		 if(($land[$x][$y] != $HlandTown) &&
			($land[$x][$y] != $HlandForest)) {
			 $land[$x][$y] = $HlandTown;
			 $landValue[$x][$y] = 5; # 처음은500인
			 $count++;
		 }
	}


	# 기지를 만들기
	$count = 0;
	while($count < $HlandFirstMiss) {
		 # 무작위좌표
		 $x = random(4) + $center - 1;
		 $y = random(4) + $center - 1;

		 # 그곳이 숲이나 도시가 아니면 기지
		 if(($land[$x][$y] != $HlandTown) &&
			($land[$x][$y] != $HlandBase) &&
			($land[$x][$y] != $HlandForest)) {
			 $land[$x][$y] = $HlandBase;
			 $landValue[$x][$y] = 0;
			 $count++;
		 }
	}

	return (\@land, \@landValue);
}

#----------------------------------------------------------------------
# 정보 변경 모드
#----------------------------------------------------------------------
# 메인
sub changeMain {
	# id에서 섬을 가져옴
	$HcurrentNumber = $HidToNumber{$HcurrentID};
	my($island) = $Hislands[$HcurrentNumber];
	my($flag) = 0;

	# 비밀번호 확인
	if($HoldPassword eq $HspecialPassword) {
		# 특수 비밀번호
	} elsif(!checkPassword($island->{'password'},$HoldPassword)) {
		# password 오류
		unlock();
		tempWrongPassword();
		return;
	}

	# 확인용 비밀번호
	if($HinputPassword2 ne $HinputPassword) {
		# password 오류
		unlock();
		tempWrongPassword();
		return;
	}

	if($HcurrentName ne '') {
		# 이름 변경의 경우
		# 이름이 유효한지 확인
		if($HcurrentName =~ /[,\?\(\)\<\>]|^무인$/) {
			# 사용 불가 이름
			unlock();
			tempNewIslandBadName();
			return;
		}

		# 이름의 중복 확인
		if(nameToNumber($HcurrentName) != -1) {
			# 이미 발견완료
			unlock();
			tempNewIslandAlready();
			return;
		}

		if($team->{'money'} < $HcostChangeName) {
			# 자금 부족
			unlock();
			tempChangeNoMoney();
			return;
		}

		# 대금
		if($HoldPassword ne $HspecialPassword) {
			$team->{'money'} -= $HcostChangeName;
		}

		# 이름을 변경
		logChangeName($island->{'name'}, $HcurrentName);
		$island->{'name'} = $HcurrentName;
		$flag = 1;
	}

	# password 변경의 경우
	if($HinputPassword ne '') {
		# 비밀번호를 변경
		$island->{'password'} = encode($HinputPassword);
		$flag = 1;
	}

	if($HownerName ne '') {
		# 소유자 이름을 변경
		$island->{'ownername'} = $HownerName;
		$flag = 1;
	}

	if($HcurrentID == $deleteID and $masterPassword eq $HoldPassword and $HislandTurn == 0){
		# 섬 삭제 모드
		$team = $Hteams[$HidToTeamNumber{$island->{'teamid'}}];
		$team->{'pop'} -= $island->{'pop'};
		$team->{'money'} -= $HinitialMoney;
		$team->{'food'} -= $HinitialFood;
		$team->{'member'} =~ s/${HcurrentID},//;
		$island->{'pop'} = 0;
		$HislandNumber -= 1;
		islandSort();
		$flag = 1;
		writeTeamsFile();
	}

	if(($flag == 0) && ($HoldPassword ne $HspecialPassword)) {
		# 어느 쪽도 변경되어 있지 않음
		unlock();
		tempChangeNothing();
		return;
	}

	# 데이터 쓰기
	writeIslandsFile($HcurrentID);
	unlock();

	# 변경성공
	tempChange();
}

#----------------------------------------------------------------------
# 턴진행 모드
#----------------------------------------------------------------------
# 메인
sub turnMain {


	# 로그 파일을 뒤에밀기
	my($i, $j, $s, $d);
	for($i = ($HlogMax - 1); $i>= 0; $i--) {
		$j = $i + 1;
		my($s) = "${HdirName}/hakojima.log$i";
		my($d) = "${HdirName}/hakojima.log$j";
		unlink($d);
		rename($s, $d);
	}

	# 좌표배열을 만들기
	makeRandomPointArray();

	# 턴번호
	$HislandTurn++;

	# 전투 기간로의 이후등
	$winlose = 0;
	if($HnextCTurn == 0 && $HislandTurn == $HyosenTurn) {
		$HnextCTurn = $HyosenTurn + $HdevTurn;
		$winlose = 2;
	} elsif($HislandTurn == $HnextCTurn && $HislandTurn> $HyosenTurn && $HfightMode == 1) {
		$winlose = 1;
	} elsif($HislandTurn> $HnextCTurn && $HislandTurn> $HyosenTurn) {
		if($HfightMode) {
			$HfightMode = 0;
			$HfightCount++;
			$HnextCTurn += $HdevTurn;
			$winlose = 2;
		} else {
			$HfightMode = 1;
			$HnextCTurn += $HfigTurn;
			# 결승전은 전투 기간연장장
			if($HteamNumber == 2) { $HnextCTurn += $HfigRepTurn;}
			$winlose = 3;
		}
	}

	if($HturnCount> 1) {
		$HturnCount--;
	} elsif($winlose == 1) {
		# 최종 갱신 시간을 갱신
		$HislandLastTime += $HinterTime;
		$HturnCount = $HdevRepTurn;
	} elsif($HfightMode or $HislandTurn == $HnextCTurn) {
		# 전투 기간
		$HislandLastTime += $HfightTime;
		$HturnCount = $HfigRepTurn;
	} else {
		# 개발 기간
		$HislandLastTime += $HunitTime;
		$HturnCount = $HdevRepTurn;
	}

	# 순서결메
	my(@order) = randomArray($HislandNumber);

	# 수입, 소비단계
	for($i = 0; $i < $HislandNumber; $i++) {
		estimate($order[$i]);
		income($Hislands[$order[$i]]);

		# 턴시작전의 인구를 메모루
		$Hislands[$order[$i]]->{'oldPop'} = $Hislands[$order[$i]]->{'pop'};
	}

	# 팀 비밀번호결정 BBS 용 파일에쓰기
	for($i = 0; $i < $HteamNumber; $i++) {
		my($team) = $Hteams[$i];
		# 턴시작전의 인구를 메모루
		$team->{'oldPop'} = $team->{'pop'};
		$team->{'pop'} = 0;
		$team->{'farm'} = 0;
		$team->{'factory'} = 0;
		$team->{'food'} = 0;

		my($passkey) = random(1200);
		$team->{'password'} = crypt($team->{'id'} * $passkey * $HislandTurn,hp);
		open(DAT, ">>team.tmp.cgi");
			print DAT "$team->{'id'}\n";
			print DAT "$team->{'name'}\n";
			print DAT "$team->{'password'}\n";
		close(DAT);
	}
	rename ("team.tmp.cgi", "team.cgi");

	# 명령 처리
	for($i = 0; $i < $HislandNumber; $i++) {
		# 반환 값1이 이 될 시까지 반복
		while(doCommand($Hislands[$order[$i]]) == 0){};
	}

	# 성장 및 단일 헥스 재해
	for($i = 0; $i < $HislandNumber; $i++) {
		doEachHex($Hislands[$order[$i]]);
	}

	# 섬 전체 처리
	my($remainNumber) = $HislandNumber;
	my($island);
	for($i = 0; $i < $HislandNumber; $i++) {
		$island = $Hislands[$order[$i]];
		doIslandProcess($order[$i], $island);
	}

	for($i = 0; $i < $HislandNumber; $i++) {
		teamEstimate($order[$i]);
	}

	my($remainTNumber) = $HteamNumber;
	if($HislandTurn == $HyosenTurn) {
		teamSort();
		for($i = $yteamNum; $i < $HteamNumber; $i++) {
			$team = $Hteams[$i];
			# 패자
			logDeadyt($team->{'name'});
			push(@fightLog, "$team->{'name'}<>$team->{'pop'}<>$team->{'member'}");
			$team->{'pop'} = -1;
			my($numTTMember) = $team->{'member'};
			while($numTTMember =~ s/([0-9]*),//) {
				my($HcurrentNumber) = $HidToNumber{$1};
				my($Disland) = $Hislands[$HcurrentNumber];
				$Disland->{'pop'} = -1;
				$remainNumber--;
				logDeady($Disland->{'name'});
			}
			$remainTNumber--;

		}
		HyosenLog(@fightLog);
	}

	# 승패판정
	if($winlose == 1) {
		my($team,@fightLog);
		for($i = 0; $i < $HteamNumber; $i++) {
			$team = $Hteams[$i];
			my($HcurrentTNumber) = $HidToTeamNumber{$team->{'fightid'}};
			my($tTeam) = $Hteams[$HcurrentTNumber];
			if($team->{'pop'}>= $tTeam->{'pop'}) {
				# 승자
				# 보상금
				my($rewardMoney) = $tTeam->{'reward'} * $tTeam->{'rewturn'} * 5 + $team->{'waste'} * $HcomCost[$HcomPrepare2];
				$team->{'reward'} = 0;
				$team->{'rewturn'} = 0;
				$team->{'money'} += $rewardMoney;
				logWin(0,$team->{'name'},$rewardMoney,$tTeam->{'name'});
				my($numMember) = $team->{'member'};
				while($numMember =~ s/([0-9]*),//) {
					my($HcurrenTNumber) = $HidToNumber{$1};
					my($island) = $Hislands[$HcurrenTNumber];
					logWin($island->{'id'},$island->{'name'},$rewardMoney,$tTeam->{'name'});
				}
				$team->{'fightid'} = 0;
				push(@fightLog, "$team->{'name'}<>$team->{'pop'}<>$rewardMoney<>$tTeam->{'name'}<>$tTeam->{'pop'}<>$team->{'member'},$tTeam->{'member'}");

				# 패자
				logDead($tTeam->{'name'});
				$tTeam->{'pop'} = -1;
				my($numTTMember) = $tTeam->{'member'};
				while($numTTMember =~ s/([0-9]*),//) {
					my($HcurrentNumber) = $HidToNumber{$1};
					my($Disland) = $Hislands[$HcurrentNumber];
					$Disland->{'pop'} = -1;
					$remainNumber--;
					logDead($Disland->{'name'}. "섬");
				}
				$remainTNumber--;
			}
		}
		HfightLog(@fightLog);
	} elsif($winlose == 2) {
		# 대전 상대결정
		if($HislandTurn == $HyosenTurn) {
			$HTnumber = $remainTNumber;
		} else {
			$HTnumber = $HteamNumber;
		}
		my(@ordert) = randomArray($HTnumber);
		my($team);
		for($i = 0; $i < $HTnumber; $i++) {
			$team = $Hteams[$ordert[$i]];
			if($team->{'fightid'} <= 0) {
				my($jj) = $i + 1;
				$tTeam = $Hteams[$ordert[$jj]];
				$team->{'fightid'} = $tTeam->{'id'};
				$tTeam->{'fightid'} = $team->{'id'};
			}
		}
	}

	# 대전 기록저장
	open(FOUT, "${HdirName}/fight.log");
		while($f = <FOUT>){
			chomp($f);
			push(@offset,"$f\n");
		}
	close(FOUT);

	# 인구순에정렬
	islandSort();
	teamSort();

	# 섬 수자르기
	$HislandNumber = $remainNumber;
	$HteamNumber = $remainTNumber;

	# 백업 턴이면 삭제 전에 rename
	if(($HislandTurn % $HbackupTurn) == 0) {
		my($i);
		my($tmp) = $HbackupTimes - 1;
		myrmtree("${HdirName}.bak$tmp");
		for($i = ($HbackupTimes - 1); $i> 0; $i--) {
			my($j) = $i - 1;
			rename("${HdirName}.bak$j", "${HdirName}.bak$i");
		}
		rename("${HdirName}", "${HdirName}.bak0");
		mkdir("${HdirName}", $HdirMode);

		# 로그 파일만 복구
		for($i = 0; $i <= $HlogMax; $i++) {
			rename("${HdirName}.bak0/hakojima.log$i",
				 "${HdirName}/hakojima.log$i");
		}
		rename("${HdirName}.bak0/hakojima.his",
			 "${HdirName}/hakojima.his");
	}

	# 파일에쓰기
	writeIslandsFile(-1);
	writeTeamsFile();

	# 대전 기록저장
	open(FOUT, ">${HdirName}/fight.log");
		print FOUT @offset;
	close(FOUT);

	# 로그 쓰기
	logFlush();

	# 기록 로그 조정
	logHistoryTrim();

	# 데이터 읽기
	readTeamsFile();
	readIslandsFile();

	# 맨 위로
	topPageMain();
}

# 디렉터리 삭제
sub myrmtree {
	my($dn) = @_;
	opendir(DIN, "$dn/");
	my($fileName);
	while($fileName = readdir(DIN)) {
		unlink("$dn/$fileName");
	}
	closedir(DIN);
	rmdir($dn);
}

# 수입, 소비단계
sub income {
	my($island) = @_;
	my($HcurrentTNumber) = $HidToTeamNumber{$island->{'teamid'}};
	my($team) = $Hteams[$HcurrentTNumber];
	my($pop, $farm, $factory) =
		(
		 $island->{'pop'},
		 $island->{'farm'} * 10,
		 $island->{'factory'},
		 );

	# 수입
	if($pop> $farm) {
		# 농업만으로 인력이 남는 경우
		$island->{'food'} += $farm; # 농장 전체가동
		$team->{'money'} +=
			min(int(($pop - $farm) / 10),
				 $factory );
	} else {
		# 농장 규모가 최대치인 경우
		$island->{'food'} += $pop; # 전체나 생 직원일
	}

	# 식량소비
	$island->{'food'} = int(($island->{'food'}) - ($pop * $HeatenFood));
}


# 명령 단계
sub doCommand {
	my($island) = @_;
	my($HcurrentTNumber) = $HidToTeamNumber{$island->{'teamid'}};
	my($team) = $Hteams[$HcurrentTNumber];

	# 명령 처리 시작
	my($comArray, $command);
	$comArray = $island->{'command'};
	$command = $comArray->[0]; # 첫 항목을 꺼냄
	slideFront($comArray, 0); # 이후를 막힘하기

	# 각 요소 꺼내기
	my($kind, $target, $x, $y, $arg) =
		(
		 $command->{'kind'},
		 $command->{'target'},
		 $command->{'x'},
		 $command->{'y'},
		 $command->{'arg'}
		 );

	# 도출 값
	my($name) = $island->{'name'};
	my($id) = $island->{'id'};
	my($land) = $island->{'land'};
	my($landValue) = $island->{'landValue'};
	my($landKind) = $land->[$x][$y];
	my($lv) = $landValue->[$x][$y];
	my($cost) = $HcomCost[$kind];
	my($comName) = $HcomName[$kind];
	my($point) = "($x, $y)";
	my($landName) = landName($landKind, $lv);

	if($kind == $HcomDoNothing) {
		# 자금 조달
		logDoNothing($id, $name, $comName);
		$team->{'money'} += 10;
		$island->{'absent'} ++;

		# 자동포기
		if($island->{'absent'}>= $HgiveupTurn) {
			$island->{'password'} = encode($team->{'password'});
			$island->{'comment'} = $HgiveupComment;
		}
		return 1;
	}

	$island->{'absent'} = 0;

	# 비용 확인
	if($cost> 0) {
		# 금의 경우
		if($team->{'money'} < $cost) {
			logNoMoney($id, $name, $comName);
			return 0;
		}
	} elsif($cost < 0) {
		# 식량의 경우
		if($island->{'food'} < (-$cost)) {
			logNoFood($id, $name, $comName);
			return 0;
		}
	}

	if(($kind == $HcomAutoPrepare3 or $kind == $HcomFastFarm) && ($HfightMode)){
		logLandNG($id, $name, $comName, $landName, $point, '현재전투 기간 중이어서 ');
		return 0;
	}

	# 명령에서 분기
	if(($kind == $HcomPrepare) ||
	 ($kind == $HcomPrepare2)) {
		# 개간, 땅고르기
		if(($landKind == $HlandSea) ||
		 ($landKind == $HlandSbase)) {
			# 바다, 해저 기지, 은개간할 수 없
			logLandFail($id, $name, $comName, $landName, $point);
			return 0;
		}

		# 대상 위치를 평지로
		$land->[$x][$y] = $HlandPlains;
		$landValue->[$x][$y] = 0;
		logLandSuc($id, $name, '개간', $point);

		# 돈을 차감
		$team->{'money'} -= $cost;

		if($kind == $HcomPrepare2) {
			# 땅고르기
			return 0;
		} else {
			return 1;
		}
	} elsif($kind == $HcomAutoPrepare3) {
		# 일괄 자동 땅고르기
		my($prepareM, $preFlag) = ($HcomCost[$HcomPrepare2], 0);
		for($i = 0; $i < $HpointNumber; $i++) {
			$bx = $Hrpx[$i];
			$by = $Hrpy[$i];
			if(($land->[$bx][$by] == $HlandWaste) && ($team->{'money'}>= $prepareM)){
				# 대상 위치를 평지로
				$land->[$bx][$by] = $HlandPlains;
				$landValue->[$bx][$by] = 0;
				logLandSuc($id, $name, '개간', "($bx, $by)");
				# 돈을 차감
				$team->{'money'} -= $prepareM;
				$preFlag++;
				if($preFlag == $precheap){ $prepareM = int($prepareM * $precheap2 / 10); }
			}
		}
		# 턴 소비하지 않고
		return 0;
	} elsif($kind == $HcomReclaim) {
		# 매립
		if(($landKind != $HlandSea) &&
		 ($landKind != $HlandSbase)) {
			# 바다, 해저 기지, 만매립할 수 없
			logLandFail($id, $name, $comName, $landName, $point);
			return 0;
		}

		# 주변에육이 있는 지 확인
		my($seaCount) =
			countAround($land, $x, $y, $HlandSea, 7) +
			countAround($land, $x, $y, $HlandSbase, 7);

		if($seaCount == 7) {
			# 전체 바다다에서 매립불능
			logNoLandAround($id, $name, $comName, $point);
			return 0;
		}

		if(($landKind == $HlandSea) && ($lv == 1)) {
			# 얕은 바다의 경우
			# 대상 위치를 황무지로
			$land->[$x][$y] = $HlandWaste;
			$landValue->[$x][$y] = 0;
			logLandSuc($id, $name, $comName, $point);
			$island->{'area'}++;

			if($seaCount <= 4) {
				# 주변 바다가 3헥스 이내이므로, 얕은 바다로
				my($i, $sx, $sy);

				for($i = 1; $i < 7; $i++) {
					$sx = $x + $ax[$i];
					$sy = $y + $ay[$i];

					# 행 기준 위치 조정
					if((($sy % 2) == 0) && (($y % 2) == 1)) {
						$sx--;
					}

					if(($sx < 0) || ($sx>= $HislandSize) ||
					 ($sy < 0) || ($sy>= $HislandSize)) {
					} else {
						# 범위 안의 경우
						if($land->[$sx][$sy] == $HlandSea) {
							$landValue->[$sx][$sy] = 1;
						}
					}
				}
			}
		} else {
			# 바다이면 대상 위치를 얕은 바다로 변경
			$land->[$x][$y] = $HlandSea;
			$landValue->[$x][$y] = 1;
			logLandSuc($id, $name, $comName, $point);
		}

		# 돈을 차감
		$team->{'money'} -= $cost;
		return 1;
	} elsif($kind == $HcomDestroy) {
		# 굴착
		if(($landKind == $HlandSea && $lv == 0) && ($landKind == $HlandSbase)) {
			# 바다, 해저 기지는 굴착할 수 없
			logLandFail($id, $name, $comName, $landName, $point);
			return 0;
		}
		# 대상 위치를 바다로. 얕은 바다이면 바다에.
		if($landKind == $HlandSea) {
			$landValue->[$x][$y] = 0;
		} else {
			$land->[$x][$y] = $HlandSea;
			$landValue->[$x][$y] = 1;
			$island->{'area'}--;
		}
		logLandSuc($id, $name, $comName, $point);

		# 돈을 차감
		$team->{'money'} -= $cost;
		return 1;
	} elsif($kind == $HcomSellTree) {
		# 벌채
		if($landKind != $HlandForest) {
			# 숲이외는 벌채할 수 없
			logLandFail($id, $name, $comName, $landName, $point);
			return 0;
		}

		# 대상 위치를 평지로
		$land->[$x][$y] = $HlandPlains;
		$landValue->[$x][$y] = 0;
		logLandSuc($id, $name, $comName, $point);

		# 매각금을 얻기루
		$team->{'money'} += $HtreeValue * $lv;
		return 0;
	} elsif(($kind == $HcomPlant) ||
			($kind == $HcomFarm) ||
			($kind == $HcomFastFarm) ||
			($kind == $HcomFactory) ||
			($kind == $HcomBase) ||
			($kind == $HcomHaribote) ||
			($kind == $HcomDbase)) {

		# 지상건설계
		if(!
		 (($landKind == $HlandPlains) ||
			($landKind == $HlandTown) ||
			(($landKind == $HlandFarm) && ($kind == $HcomFarm)) ||
			(($landKind == $HlandFactory) && ($kind == $HcomFactory)))) {
			# 부적절나 지형
			logLandFail($id, $name, $comName, $landName, $point);
			return 0;
		}

		# 종류에서 분기
		if($kind == $HcomPlant) {
			# 대상 위치를 숲로.
			$land->[$x][$y] = $HlandForest;
			$landValue->[$x][$y] = 1; # 목은 최소단위
			logPBSuc($id, $name, $comName, $point);
		} elsif($kind == $HcomBase) {
			# 대상 위치를 미사일 기지로.
			$land->[$x][$y] = $HlandBase;
			$landValue->[$x][$y] = 0; # 경험치0
			logPBSuc($id, $name, $comName, $point);
			if($HfightMode) { $team->{'rewturn'}++; } # 전투 기간에는 카운트
		} elsif($kind == $HcomHaribote) {
			# 대상 위치를 가짜 시설로
			$land->[$x][$y] = $HlandHaribote;
			$landValue->[$x][$y] = 0;
			logHariSuc($id, $name, $comName, $HcomName[$HcomDbase], $point);
		} elsif(($kind == $HcomFarm) || ($kind == $HcomFastFarm)) {
			# 농장
			if($landKind == $HlandFarm) {
				# 이미 농장의 경우
				$landValue->[$x][$y] += 2; # 규모 + 2000인
				if($landValue->[$x][$y]> 50) {
					$landValue->[$x][$y] = 50; # 최대 50000인
				}
			} else {
				# 대상 위치를 농장에
				$land->[$x][$y] = $HlandFarm;
				$landValue->[$x][$y] = 10; # 규모 = 10000인
			}
			logLandSuc($id, $name, $comName, $point);
			if($kind == $HcomFastFarm){
				$team->{'money'} -= $cost;
				return 0;
			}
		} elsif($kind == $HcomFactory) {
			# 공장
			if($landKind == $HlandFactory) {
				# 이미 공장의 경우
				$landValue->[$x][$y] += 10; # 규모 + 10000인
				if($landValue->[$x][$y]> 100) {
					$landValue->[$x][$y] = 100; # 최대 100000인
				}
			} else {
				# 대상 위치를 공장에
				$land->[$x][$y] = $HlandFactory;
				$landValue->[$x][$y] = 30; # 규모 = 10000인
			}
			logLandSuc($id, $name, $comName, $point);
		} elsif($kind == $HcomDbase) {
			# 방위 시설
			# 대상 위치를 방위 시설에
			$land->[$x][$y] = $HlandDefence;
			$landValue->[$x][$y] = 0;
			logPBSuc($id, $name, $comName, $point);
			if($HfightMode) { $team->{'rewturn'}++; } # 전투 기간에는 카운트
		}

		# 돈을 차감
		$team->{'money'} -= $cost;

		# 횟수 지정이면, 명령을 되돌림
		if(($kind == $HcomFarm) ||
		 ($kind == $HcomFactory)) {
			if($arg> 1) {
				my($command);
				$arg--;
				slideBack($comArray, 0);
				$comArray->[0] = {
					'kind' => $kind,
					'target' => $target,
					'x' => $x,
					'y' => $y,
					'arg' => $arg
					};
			}
		}

		return 1;
	} elsif(($kind == $HcomMissileNM) ||
			($kind == $HcomMissilePP)) {
		# 미사일계
		# 대상 가져오기
		my($tn) = $HidToNumber{$target};
		if($tn eq '') {
			# 대상이 이미 없음
			logMsNoTarget($id, $name, $comName);
			return 0;
		}

		my($flag) = 0;
		if($arg == 0) {
			# 값이 0이면 공격 중인 대상만
			$arg = 10000;
		}

		# 사전준비
		my($tIsland) = $Hislands[$tn];
		my($tName) = $tIsland->{'name'};
		my($tLand) = $tIsland->{'land'};
		my($tLandValue) = $tIsland->{'landValue'};
		my($tx, $ty, $err);

		# 난민의 수
		my($boat) = 0;

		if(($HfightMode == 0) && ($tIsland->{'teamid'} != $island->{'teamid'})){
			# 개발 기간 안은 취소
			logLandNG($id, $name, $comName, $landName, $point, '현재 개발 기간 중이어서 ');
			return 0;
		} elsif($HfightMode && $tIsland->{'teamid'} != $team->{'fightid'} && $tIsland->{'teamid'} != $island->{'teamid'}){
			# 대전 상대이외는 취소
			logLandNG($id, $name, $comName, $landName, $point, '목표가 상대 팀에 없어 ');
			return 0;
		} elsif($island->{'pop'} < 1000 and $HteamNumber> 2) {
			 logLandNG($id, $name, $comName, $landName, $point, '인구가10만 명이하의 위함');
			 return 0;
		}

		# 오차
		if($kind == $HcomMissilePP) {
			$err = 7;
		} else {
			$err = 19;
		}

		# 자금이 부족하면 지정수량을 충족하거나 전체 기지 가격에 도달할 시까지 반복
		my($bx, $by, $count) = (0,0,0);
		while(($arg> 0) &&
			 ($team->{'money'}>= $cost)) {
			# 기지를 찾을 시까지 반복
			while($count < $HpointNumber) {
				$bx = $Hrpx[$count];
				$by = $Hrpy[$count];
				if(($land->[$bx][$by] == $HlandBase) ||
				 ($land->[$bx][$by] == $HlandSbase)) {
					last;
				}
				$count++;
			}
			if($count>= $HpointNumber) {
				# 찾을 수 없으면 그곳까지
				last;
			}
			# 최소하나기지가 있었던이므로,flag 을설립하고 있는
			$flag = 1;

			# 기지의 레벨을 산출
			my($level) = expToLevel($land->[$bx][$by], $landValue->[$bx][$by]);
			# 기지내에서 루프
			while(($level> 0) &&
				 ($arg> 0) &&
				 ($team->{'money'}> $cost)) {
				# 명중이 확정이므로, 각 값을 소도
				$level--;
				$arg--;
				$team->{'money'} -= $cost;

				# 착탄 지점 산출
				my($r) = random($err);
				$tx = $x + $ax[$r];
				$ty = $y + $ay[$r];
				if((($ty % 2) == 0) && (($y % 2) == 1)) {
					$tx--;
				}

				# 착탄 지점범위안팎 확인
				if(($tx < 0) || ($tx>= $HislandSize) ||
				 ($ty < 0) || ($ty>= $HislandSize)) {
					# 범위 밖
					# 일반계
					logMsOut($id, $target, $name, $tName,
								 $comName, $point);
					next;
				}

				# 착탄 지점의 지형등 산출
				my($tL) = $tLand->[$tx][$ty];
				my($tLv) = $tLandValue->[$tx][$ty];
				my($tLname) = landName($tL, $tLv);
				my($tPoint) = "($tx, $ty)";

				# 방위 시설 판정
				my($defence) = 0;
				if($HdefenceHex[$id][$tx][$ty] == 1) {
					$defence = 1;
				} elsif($HdefenceHex[$id][$tx][$ty] == -1) {
					$defence = 0;
				} else {
					if($tL == $HlandDefence) {
						# 방위 시설에 명중
						# 플래그를 지우기
						my($i, $count, $sx, $sy);
						for($i = 0; $i < 19; $i++) {
							$sx = $tx + $ax[$i];
							$sy = $ty + $ay[$i];

							# 행 기준 위치 조정
							if((($sy % 2) == 0) && (($ty % 2) == 1)) {
								$sx--;
							}

							if(($sx < 0) || ($sx>= $HislandSize) ||
							 ($sy < 0) || ($sy>= $HislandSize)) {
								# 범위 밖이면 아무것도 하지 않음
							} else {
								# 범위 안의 경우
								$HdefenceHex[$id][$sx][$sy] = 0;
							}
						}
					} elsif(countAround($tLand, $tx, $ty, $HlandDefence, 19)) {
						$HdefenceHex[$id][$tx][$ty] = 1;
						$defence = 1;
					} else {
						$HdefenceHex[$id][$tx][$ty] = -1;
						$defence = 0;
					}
				}

				if($defence == 1) {
					# 공안폭파
					# 일반계
					logMsCaught($id, $target, $name, $tName,
									 $comName, $point, $tPoint);
					next;
				}

				# '효과 없음' hex를 먼저 판정
				if((($tL == $HlandSea) && ($tLv == 0))|| # 깊은 바다
				 (($tL == $HlandSea) || # 바다또는...
					 ($tL == $HlandSbase))) { # 해저 기지이외
					# 해저 기지는 바다처럼 표시
					if($tL == $HlandSbase) {
						$tL = $HlandSea;
					}
					$tLname = landName($tL, $tLv);

					# 무효화
					logMsNoDamage($id, $target, $name, $tName,
									 $comName, $tLname, $point, $tPoint);
					next;
				}

					if($tL == $HlandWaste) {
						# 황무지(피해없음)
						logMsWaste($id, $target, $name, $tName,
										$comName, $tLname, $point, $tPoint);
					} else {
						# 일반 지형
						logMsNormal($id, $target, $name, $tName,
										 $comName, $tLname, $point,
										 $tPoint);
					}
					# 경험치
					if($tL == $HlandTown) {
						if(($land->[$bx][$by] == $HlandBase) ||
							($land->[$bx][$by] == $HlandSbase)) {
							$landValue->[$bx][$by] += int($tLv / 20);
							$boat += $tLv; # 일반 미사일이므로 난민에플러스
							if($landValue->[$bx][$by]> $HmaxExpPoint) {
								$landValue->[$bx][$by] = $HmaxExpPoint;
							}
						}
						$tIsland->{'pop'} -= $tLv;
					}

					# 황무지가 됨
					$tLand->[$tx][$ty] = $HlandWaste;
					$tLandValue->[$tx][$ty] = 1; # 착탄 지점

			}

			# 카운트 증가
			$count++;
		}


		if($flag == 0) {
			# 기지가 하나도 없어진 경우
			logMsNoBase($id, $name, $comName);
			return 0;
		}

		if($HfightMode) {
			# 전투 기간에는 카운트
			$team->{'rewturn'}++;
		}

		# 난민판정
		$boat = int($boat / 2);
		if(($boat> 0) && ($id != $target)) {
			# 난민표착
			my($achive); # 도달난민
			my($i);
			for($i = 0; ($i < $HpointNumber && $boat> 0); $i++) {
				$bx = $Hrpx[$i];
				$by = $Hrpy[$i];
				if($land->[$bx][$by] == $HlandTown) {
					# 마을의 경우
					my($lv) = $landValue->[$bx][$by];
					if($boat> 50) {
						$lv += 50;
						$boat -= 50;
						$achive += 50;
					} else {
						$lv += $boat;
						$achive += $boat;
						$boat = 0;
					}
					if($lv> 200) {
						$boat += ($lv - 200);
						$achive -= ($lv - 200);
						$lv = 200;
					}
					$landValue->[$bx][$by] = $lv;
				} elsif($land->[$bx][$by] == $HlandPlains) {
					# 평지의 경우
					$land->[$bx][$by] = $HlandTown;;
					if($boat> 10) {
						$landValue->[$bx][$by] = 5;
						$boat -= 10;
						$achive += 10;
					} elsif($boat> 5) {
						$landValue->[$bx][$by] = $boat - 5;
						$achive += $boat;
						$boat = 0;
					}
				}
				if($boat <= 0) {
					last;
				}
			}
			if($achive> 0) {
				# 조금이라도 도착한 경우 로그를 출력
				logMsBoatPeople($id, $name, $achive);
				$island->{'achive'} = $achive;
				# 난민의 수가일정수이상라면, 평화상의 가능성있음
				if($achive>= 200) {
					my($flags) = $island->{'prize'};

					if((!($flags & 8)) && $achive>= 200){
						$flags |= 8;
						logPrize($id, $name, $Hprize[4]);
					} elsif((!($flags & 16)) && $achive> 500){
						$flags |= 16;
						logPrize($id, $name, $Hprize[5]);
					} elsif((!($flags & 32)) && $achive> 800){
						$flags |= 32;
						logPrize($id, $name, $Hprize[6]);
					}
					$island->{'prize'} = $flags;
				}
			}
		}
		return 1;
	} elsif($kind == $HcomSell) {
		# 수출량 결정
		if($arg == 0) { $arg = 1; }
		my($value) = min($arg * (-$cost), $island->{'food'});

		# 수출 로그
		logSell($id, $name, $comName, $value);
		$island->{'food'} -= $value;
		$team->{'money'} += ($value / 10);
		return 0;
	} elsif($kind == $HcomFood) {
		# 지원계
		# 대상 가져오기
		my($tn) = $HidToNumber{$target};
		my($tIsland) = $Hislands[$tn];
		my($tName) = $tIsland->{'name'};
		if($island->{'teamid'} != $tIsland->{'teamid'}) {
			logLandNG($id, $name, $comName, $landName, $point, '지원선이타팀의 위함에');
			return 0;
		}
		# 지원량 결정
		if($arg == 0) { $arg = 1; }
		my($value, $str);
		$value = min($arg * (-$cost), $island->{'food'});
		$str = "$value$HunitFood";

		# 지원 로그
		logAid($id, $target, $name, $tName, $comName, $str);

		$island->{'food'} -= $value;
		$tIsland->{'food'} += $value;
		return 0;
	} elsif($kind == $HcomPropaganda) {
		# 유치 활동
		if($HyosenTurn>= $HislandTurn) {
			 logLandNG($id, $name, $comName, $landName, $point, '예선 기간의 위함');
			 return 0;
		}
		logPropaganda($id, $name, $comName);
		$island->{'propaganda'} = 1;
		$island->{'money'} -= $cost;
		return 1;
	}

	return 1;
}


# 성장 및 단일 헥스 재해
sub doEachHex {
	my($island) = @_;

	# 도출 값
	my($name) = $island->{'name'};
	my($id) = $island->{'id'};
	my($land) = $island->{'land'};
	my($landValue) = $island->{'landValue'};
	my($HcurrentTNumber) = $HidToTeamNumber{$island->{'teamid'}};
	my($team) = $Hteams[$HcurrentTNumber];

	# 늘어나면인구의 타네 값
	my($addpop) = 10; # 마을, 마을
	my($addpop2) = 0; # 도시
	if($island->{'food'} < 0) {
		# 식량 부족
		$addpop = -30;
	}
	if($island->{'absent'}>= $HstopAddPop) {
		$addpop = -10;
	} elsif($island->{'propaganda'}) {
		# 유치 활동 중
		$addpop = 30;
		$addpop2 = 3;
	}
	# 루프
	my($x, $y, $i);
	for($i = 0; $i < $HpointNumber; $i++) {
		$x = $Hrpx[$i];
		$y = $Hrpy[$i];
		my($landKind) = $land->[$x][$y];
		my($lv) = $landValue->[$x][$y];

		if($landKind == $HlandTown) {
			# 마을 계열
			if($addpop < 0) {
				# 부족
				$lv -= (random(-$addpop) + 1);
				if($lv <= 0) {
					# 평지로 되돌리기
					$land->[$x][$y] = $HlandPlains;
					$landValue->[$x][$y] = 0;
					next;
				}
			} elsif($addpop> 0) {
				# 성장
				if($lv < 100) {
					$lv += random($addpop) + 1;
					if($lv> 100) {
						$lv = 100;
					}
				} else {
					# 도시가 되면 성장 지연이
					if($addpop2> 0) {
						$lv += random($addpop2) + 1;
					}
				}
			}
			if($lv> 200) {
				$lv = 200;
			}
			$landValue->[$x][$y] = $lv;
		} elsif($landKind == $HlandPlains) {
			# 평지
			if(random(5) == 0) {
				# 주변에 농장, 마을이 있다면, 여기도 마을이 됨
				if(countGrow($land, $landValue, $x, $y) || $island->{'propaganda'}){
					$land->[$x][$y] = $HlandTown;
					$landValue->[$x][$y] = 1;
				}
			}
		} elsif($landKind == $HlandForest) {
			# 숲
			if($lv < 200) {
				# 나무가 늘어남
				$landValue->[$x][$y] += $HtreeUp;
			}
		}
	}
}

# 주변의 마을, 농장이 있는 지반정
sub countGrow {
	my($land, $landValue, $x, $y) = @_;
	my($i, $sx, $sy);
	for($i = 1; $i < 7; $i++) {
		 $sx = $x + $ax[$i];
		 $sy = $y + $ay[$i];

		 # 행 기준 위치 조정
		 if((($sy % 2) == 0) && (($y % 2) == 1)) {
			 $sx--;
		 }

		 if(($sx < 0) || ($sx>= $HislandSize) ||
			($sy < 0) || ($sy>= $HislandSize)) {
		 } else {
			 # 범위 안의 경우
			 if(($land->[$sx][$sy] == $HlandTown) ||
				($land->[$sx][$sy] == $HlandFarm)) {
				 if($landValue->[$sx][$sy] != 1) {
					 return 1;
				 }
			 }
		 }
	}
	return 0;
}

# 섬 전체
sub doIslandProcess {
	my($number, $island) = @_;

	# 도출 값
	my($name) = $island->{'name'};
	my($id) = $island->{'id'};
	my($land) = $island->{'land'};
	my($landValue) = $island->{'landValue'};
	my($HcurrentTNumber) = $HidToTeamNumber{$island->{'teamid'}};
	my($team) = $Hteams[$HcurrentTNumber];

	# 식량 부족
	if($island->{'food'} < 0) {
		# 부족 메시지
		logStarve($id, $name);
		$island->{'food'} = 0;

		my($x, $y, $landKind, $lv, $i);
		for($i = 0; $i < $HpointNumber; $i++) {
			$x = $Hrpx[$i];
			$y = $Hrpy[$i];
			$landKind = $land->[$x][$y];
			$lv = $landValue->[$x][$y];

			if(($landKind == $HlandFarm) ||
			 ($landKind == $HlandFactory) ||
			 ($landKind == $HlandBase) ||
			 ($landKind == $HlandDefence)) {
				# 1/4에서 괴멸
				if(random(4) == 0) {
					logSvDamage($id, $name, landName($landKind, $lv),
								"($x, $y)");
					$land->[$x][$y] = $HlandWaste;
					$landValue->[$x][$y] = 0;
				}
			}
		}
	}

	# 지반 침하판정
	if(($island->{'area'}> $HdisFallBorder) &&
	 (random(1000) < $HdisFalldown)) {
		# 지반 침하발생
		logFalldown($id, $name);

		my($x, $y, $landKind, $lv, $i);
		for($i = 0; $i < $HpointNumber; $i++) {
			$x = $Hrpx[$i];
			$y = $Hrpy[$i];
			$landKind = $land->[$x][$y];
			$lv = $landValue->[$x][$y];

			if(($landKind != $HlandSea) &&
			 ($landKind != $HlandSbase)) {

				# 주변에 바다가 있다면, 값을-1에
				if(countAround($land, $x, $y, $HlandSea, 7) +
				 countAround($land, $x, $y, $HlandSbase, 7)) {
					logFalldownLand($id, $name, landName($landKind, $lv),
								"($x, $y)");
					$land->[$x][$y] = -1;
					$landValue->[$x][$y] = 0;
				}
			}
		}

		for($i = 0; $i < $HpointNumber; $i++) {
			$x = $Hrpx[$i];
			$y = $Hrpy[$i];
			$landKind = $land->[$x][$y];

			if($landKind == -1) {
				# -1에나하고 있는 장소를 얕은 바다에
				$land->[$x][$y] = $HlandSea;
				$landValue->[$x][$y] = 1;
			} elsif ($landKind == $HlandSea) {
				# 얕은 바다는 바다에
				$landValue->[$x][$y] = 0;
			}

		}
	}

	# 식량이 넘치면 환전
	if($island->{'food'}> 9999) {
		$team->{'money'} += int(($island->{'food'} - 9999) / 10);
		$island->{'food'} = 9999;
	}

	# 각종의 값을 계산
	estimate($number);

	# 번영, 재난상
	$pop = $island->{'pop'};
	my($damage) = $island->{'oldPop'} - $pop;
	my($flags) = $island->{'prize'};


	# 번영상
	if((!($flags & 1)) && $pop>= 3000){
		$flags |= 1;
		logPrize($id, $name, $Hprize[1]);
	} elsif((!($flags & 2)) && $pop>= 5000){
		$flags |= 2;
		logPrize($id, $name, $Hprize[2]);
	} elsif((!($flags & 4)) && $pop>= 10000){
		$flags |= 4;
		logPrize($id, $name, $Hprize[3]);
	}

	# 재난상
	if((!($flags & 64)) && $damage>= 500){
		$flags |= 64;
		logPrize($id, $name, $Hprize[7]);
	} elsif((!($flags & 128)) && $damage>= 1000){
		$flags |= 128;
		logPrize($id, $name, $Hprize[8]);
	} elsif((!($flags & 256)) && $damage>= 2000){
		$flags |= 256;
		logPrize($id, $name, $Hprize[9]);
	}

	$island->{'prize'} = $flags;
}

# 인구순에정렬
sub islandSort {
	my($flag, $i, $tmp);

	# 인구가 같으면 이전 턴의 순서를 유지
	my @idx = (0..$#Hislands);
	@idx = sort { $Hislands[$b]->{'pop'} <=> $Hislands[$a]->{'pop'} || $a <=> $b } @idx;
	@Hislands = @Hislands[@idx];
}
# 인구순에정렬
sub teamSort {
	my($flag, $i, $tmp);

	# 인구가 같으면 이전 턴의 순서를 유지
	my @idx = (0..$#Hteams);
	@idx = sort { $Hteams[$b]->{'pop'} <=> $Hteams[$a]->{'pop'} || $a <=> $b } @idx;
	@Hteams = @Hteams[@idx];
}

# 로그로 출력
# 제1인 수:메시지
# 제2인 수:당사자
# 제3인 수:상대
# 일반 로그
sub logOut {
	push(@HlogPool,"0,$HislandTurn,$_[1],$_[2],$_[0]");
}

# 지연 로그
sub logLate {
	push(@HlateLogPool,"0,$HislandTurn,$_[1],$_[2],$_[0]");
}

# 기밀 로그
sub logSecret {
	push(@HsecretLogPool,"1,$HislandTurn,$_[1],$_[2],$_[0]");
}

# 기록 로그
sub logHistory {
	open(HOUT, ">>${HdirName}/hakojima.his");
	print HOUT "$HislandTurn,$_[0]\n";
	close(HOUT);
}

# 기록 로그 조정
sub logHistoryTrim {
	open(HIN, "${HdirName}/hakojima.his");
	my(@line, $l, $count);
	$count = 0;
	while($l = <HIN>) {
		chomp($l);
		push(@line, $l);
		$count++;
	}
	close(HIN);

	if($count> $HhistoryMax) {
		open(HOUT, ">${HdirName}/hakojima.his");
		my($i);
		for($i = ($count - $HhistoryMax); $i < $count; $i++) {
			print HOUT "$line[$i]\n";
		}
		close(HOUT);
	}
}

# 로그 쓰기
sub logFlush {
	open(LOUT, ">${HdirName}/hakojima.log0");

	# 전체를 역순으로 출력
	my($i);
	for($i = $#HsecretLogPool; $i>= 0; $i--) {
		print LOUT $HsecretLogPool[$i];
		print LOUT "\n";
	}
	for($i = $#HlateLogPool; $i>= 0; $i--) {
		print LOUT $HlateLogPool[$i];
		print LOUT "\n";
	}
	for($i = $#HlogPool; $i>= 0; $i--) {
		print LOUT $HlogPool[$i];
		print LOUT "\n";
	}
	close(LOUT);
}

#----------------------------------------------------------------------
# 로그템플릿
#----------------------------------------------------------------------

# 승리
sub logWin {
	my($id, $name, $money, $tName) = @_;
	$fTurn = $HfightCount + 1;
	if($HteamNumber == 4) {
		$fTurn = '결승전';
	} elsif($HteamNumber == 8) {
		$fTurn = '준결승';
	} else {
		$fTurn.= '회전';
	}
	if($HteamNumber == 2) {
		if($id) {
			logOut("${HtagName_}${name} 섬${H_tagName}<B>우승!!</B>",$id);
		} else {
			logOut("${HtagTName_}${name}${H_tagTName}이${HtagName_}${tName}${H_tagName}에승리시,<B>우승!!</B>");
			logHistory("${HtagTName_}${name}${H_tagTName},<B>우승!!</B>");
		}
	} elsif($id) {
		logOut("${HtagName_}${name} 섬${H_tagName}승리시,<B>$fTurn</B>진출!",$id);
		logOut("<B>보상금</B>로서,<B>$money$HunitMoney</B>지급되었습니다.",$id);
	} else {
		logOut("${HtagTName_}${name}${H_tagTName}이${HtagTName_}${tName}${H_tagTName}에승리시,<B>$fTurn</B>진출!");
		logHistory("${HtagTName_}${name}${H_tagTName},<B>$fTurn</B>진출!");
	}
}
# 사멸
sub logDead {
	my($name) = @_;
	logOut("${HtagName_}${name}${H_tagName}, 패배.");
}

# 사멸 예선 탈락
sub logDeady {
	my($name) = @_;
	logOut("${HtagName_}${name} 섬${H_tagName}, 예선 탈락.");
}

# 사멸 예선 탈락 팀
sub logDeadyt {
	my($name) = @_;
	logOut("${HtagTName_}${name}${H_tagTName}, 예선 탈락.");
}

# 개발 기간 때문에 실패
sub logLandNG {
	my($id, $name, $comName, $kind, $point, $cancel) = @_;
	logOut("${HtagName_}${name} 섬${H_tagName}에서 예정되어 있던${HtagComName_}$comName${H_tagComName}은,<B>$cancel</B>, 실행할 수 없었습니다.",$id);
END
}

# 자금 부족
sub logNoMoney {
	my($id, $name, $comName) = @_;
	logOut("${HtagName_}${name} 섬${H_tagName}에서 예정되어 있던${HtagComName_}$comName${H_tagComName}은, 자금이 부족해 중지되었습니다.",$id);
}

# 식량 부족
sub logNoFood {
	my($id, $name, $comName) = @_;
	logOut("${HtagName_}${name} 섬${H_tagName}에서 예정되어 있던${HtagComName_}$comName${H_tagComName}은, 비축 식량 부족으로 중지되었습니다.",$id);
}

# 대상 지형 종류 때문에 실패
sub logLandFail {
	my($id, $name, $comName, $kind, $point) = @_;
	logSecret("${HtagName_}${name} 섬${H_tagName}에서 예정되어 있던${HtagComName_}$comName${H_tagComName}은, 예정지 ${HtagName_}$point${H_tagName}이<B>$kind</B>였기 때문에 중지되었습니다.",$id);
END
}

# 주변에 육지가 없으면 매립 실패
sub logNoLandAround {
	my($id, $name, $comName, $point) = @_;
	logOut("${HtagName_}${name} 섬${H_tagName}에서 예정되어 있던${HtagComName_}$comName${H_tagComName}은, 예정지 ${HtagName_}$point${H_tagName} 주변에 육지가 없었기 때문에 중지되었습니다.",$id);
END
}

# 개간 계열 성공
sub logLandSuc {
	my($id, $name, $comName, $point) = @_;
	logOut("${HtagName_}${name} 섬 $point${H_tagName}에서${HtagComName_}${comName}${H_tagComName}이 실행되었습니다.",$id);
END
}

# 나무심기 or 미사일 기지
sub logPBSuc {
	my($id, $name, $comName, $point) = @_;
	logSecret("${HtagName_}${name} 섬 $point${H_tagName}에서${HtagComName_}${comName}${H_tagComName}이 실행되었습니다.",$id);
	logOut("어디선가 ${HtagName_}${name} 섬${H_tagName}의<B>숲</B>이 늘어난 것 같습니다.",$id);
END
}

# 가짜 시설
sub logHariSuc {
	my($id, $name, $comName, $comName2, $point) = @_;
	logSecret("${HtagName_}${name} 섬 $point${H_tagName}에서${HtagComName_}${comName}${H_tagComName}이 실행되었습니다.",$id);
	logLandSuc($id, $name, $comName2, $point);
END
}

# 미사일 발사를 시도했지만 기지가 없음
sub logMsNoBase {
	my($id, $name, $comName) = @_;
	logOut("${HtagName_}${name} 섬${H_tagName}에서 예정되어 있던${HtagComName_}${comName}${H_tagComName}은,<B>미사일 설비가 없어</B> 실행할 수 없었습니다.",$id);
END
}

# 미사일 발사 결과 범위 밖
sub logMsOut {
	my($id, $tId, $name, $tName, $comName, $point) = @_;
	logOut("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행했지만,<B>영역 밖의 바다</B>로 빗나간 모양입니다.",$id, $tId);
}

# 미사일이 방위 시설에 포착됨
sub logMsCaught {
	my($id, $tId, $name, $tName, $comName, $point, $tPoint) = @_;
	logOut("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행했지만,${HtagName_}$tPoint${H_tagName}지점 상공에서 역장에 포착되어,<B>공중 폭발</B>했습니다.",$id, $tId);
}

# 미사일 발사 결과 효과 없음
sub logMsNoDamage {
	my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
	logOut("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행했지만,${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 빗나가 피해가 없었습니다.",$id, $tId);
}

# 일반 미사일, 황무지에 착탄
sub logMsWaste {
	my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
	logOut("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행했지만,${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 떨어졌습니다.",$id, $tId);
}

# 일반 미사일 일반 지형에 명중
sub logMsNormal {
	my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
	logOut("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행하여,${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 명중, 일대가 괴멸되었습니다.",$id, $tId);
}

# 난민 도착
sub logMsBoatPeople {
	my($id, $name, $achive) = @_;
	logOut("${HtagName_}${name} 섬${H_tagName}에어디선가<B>$achive${HunitPop}명의 난민</B>이 표류해 왔습니다.${HtagName_}${name} 섬${H_tagName}은 살기 좋아진 것 같습니다.",$id);
}

# 자금 조달
sub logDoNothing {
	my($id, $name, $comName) = @_;
#	logOut("${HtagName_}${name} 섬${H_tagName}에서${HtagComName_}${comName}${H_tagComName}이 실행되었습니다.",$id);
}

# 수출
sub logSell {
	my($id, $name, $comName, $value) = @_;
	logOut("${HtagName_}${name} 섬${H_tagName}이<B>$value$HunitFood</B>의${HtagComName_}${comName}${H_tagComName}을 실행했습니다.",$id);
}

# 지원
sub logAid {
	my($id, $tId, $name, $tName, $comName, $str) = @_;
	logOut("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬${H_tagName}로<B>$str</B>의${HtagComName_}${comName}${H_tagComName}을 실행했습니다.",$id, $tId);
}

# 유치 활동
sub logPropaganda {
	my($id, $name, $comName) = @_;
	logOut("${HtagName_}${name} 섬${H_tagName}에서${HtagComName_}${comName}${H_tagComName}이 실행되었습니다.",$id);
}

# 발견
sub logDiscover {
	my($name) = @_;
	logHistory("${HtagName_}${name} 섬${H_tagName}이 발견됩니다.");
}

# 이름의 변경
sub logChangeName {
	my($name1, $name2) = @_;
	logHistory("${HtagName_}${name1} 섬${H_tagName}, 명칭을${HtagName_}${name2} 섬${H_tagName}에 변경.");
}

# 기아
sub logStarve {
	my($id, $name) = @_;
	logOut("${HtagName_}${name} 섬${H_tagName}의${HtagDisaster_}식량이 부족${H_tagDisaster}하고 있습니다!!",$id);
}

# 식량 부족 피해
sub logSvDamage {
	my($id, $name, $lName, $point) = @_;
	logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>에<B>식량을 찾는 주민이 몰려들었습니다</B>.<B>$lName</B>은 괴멸되었습니다.",$id);
}

# 지반 침하발생
sub logFalldown {
	my($id, $name) = @_;
	logOut("${HtagName_}${name} 섬${H_tagName}에서${HtagDisaster_}지반 침하${H_tagDisaster}가 발생했습니다!!",$id);
}

# 지반 침하 피해
sub logFalldownLand {
	my($id, $name, $lName, $point) = @_;
	logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>은 바다의 안로 침몰봄했습니다.",$id);
}

# 수상
sub logPrize {
	my($id, $name, $pName) = @_;
	logOut("${HtagName_}${name} 섬${H_tagName}이<B>$pName</B>을 수상했습니다.",$id);
	logHistory("${HtagName_}${name} 섬${H_tagName},<B>$pName</B>을 수상");
}

# 수상(팀)
sub logTPrize {
	my($name, $pName) = @_;
	logHistory("${HtagTName_}${name}${H_tagTName},<B>$pName</B>을 수상");
}

# 섬이 가득 찬 경우
sub tempNewIslandFull {
	out(<<END);
${HtagBig_}신청이 몰려, 섬이 가득 차서 등록할 수 없습니다.${H_tagBig}$HtempBack
END
}

# 신규 등록 시 이름이 없는 경우
sub tempNewIslandNoName {
	out(<<END);
${HtagBig_} 섬 이름이 필요합니다.${H_tagBig}$HtempBack
END
}

# 신규 등록 시 이름이 올바르지 않은 경우
sub tempNewIslandBadName {
	out(<<END);
${HtagBig_}',?()<>\$'등을 넣거나,'무인 섬'등 이상한 이름은 피하세요~${H_tagBig}$HtempBack
END
}

# 이미 같은 이름의 섬이 있는 경우
sub tempNewIslandAlready {
	out(<<END);
${HtagBig_}그 섬이면 이미 발견되어 있습니다.${H_tagBig}$HtempBack
END
}

# 비밀번호가 없는 경우
sub tempNewIslandNoPassword {
	out(<<END);
${HtagBig_} 비밀번호가필요입니다.${H_tagBig}$HtempBack
END
}

# 섬을 발견했습니다!!
sub tempNewIslandHead {
	out(<<END);
<CENTER>
${HtagBig_} 섬을 발견했습니다!!${H_tagBig}<BR>
${HtagBig_}${HtagName_}'${HcurrentName} 섬'${H_tagName}을 찾았습니다.${H_tagBig}<BR>
$HtempBack<BR>
</CENTER>
END
}

# 지형의 호출분
sub landName {
	my($land, $lv) = @_;
	if($land == $HlandSea) {
		if($lv == 1) {
			return '얕은 바다';
		} else {
			return '바다';
		}
	} elsif($land == $HlandWaste) {
		return '황무지';
	} elsif($land == $HlandPlains) {
		return '평지';
	} elsif($land == $HlandTown) {
		if($lv < 30) {
			return '마을';
		} elsif($lv < 100) {
			return '마을';
		} else {
			return '도시';
		}
	} elsif($land == $HlandForest) {
		return '숲';
	} elsif($land == $HlandFarm) {
		return '농장';
	} elsif($land == $HlandFactory) {
		return '공장';
	} elsif($land == $HlandBase) {
		return '미사일 기지';
	} elsif($land == $HlandDefence) {
		return '방위 시설';
	} elsif($land == $HlandHaribote) {
		return '가짜 시설';
	}
}

# 인구기타의 값을 산출
sub estimate {
	my($number) = $_[0];
	my($island);
	my($pop, $area, $farm, $factory, $burnmis, $reward, $defence, $waste) = (0, 0, 0, 0, 0, 0, 0, 0);

	# 지형을 가져옴
	$island = $Hislands[$number];
	my($land) = $island->{'land'};
	my($landValue) = $island->{'landValue'};

	# 수 가능
	my($x, $y, $kind, $value);
	for($y = 0; $y < $HislandSize; $y++) {
		for($x = 0; $x < $HislandSize; $x++) {
			$kind = $land->[$x][$y];
			$value = $landValue->[$x][$y];
			if(($kind != $HlandSea) &&
			 ($kind != $HlandSbase)){
				$area++;
				if($kind == $HlandTown) {
					# 마을
					$pop += $value;
				} elsif($kind == $HlandFarm) {
					# 농장
					$farm += $value;
				} elsif($kind == $HlandFactory) {
					# 공장
					$factory += $value;
				} elsif($kind == $HlandWaste and $value == 1) {
					# 황무지
					$waste++;
				} elsif($kind == $HlandBase) {
					# 미사일 기지
					$burnmis += expToLevel($kind, $value);
					$reward++;
				} elsif($kind == $HlandDefence) {
					# 방위 시설
					$defence++;
				}
			}
		}
	}

	# 대입
	$island->{'pop'}	 = $pop;
	$island->{'area'}	 = $area;
	$island->{'farm'}	 = $farm;
	$island->{'factory'} = $factory;
	$island->{'fire'}	 = $burnmis;
	$island->{'defence'} = $defence;
	if($winlose == 3 and $island->{'rewflag'} == 0) {
		$island->{'reward'} = $reward + $defence * 2;
		$island->{'rewflag'} = 1;
	} elsif($winlose == 1) {
		$island->{'waste'} = $waste;
	}
}

# 인구기타의 값을 산출
sub teamEstimate {
	my($number) = $_[0];
	my($island);
	$island = $Hislands[$number];
	my($HcurrentTNumber) = $HidToTeamNumber{$island->{'teamid'}};
	my($team) = $Hteams[$HcurrentTNumber];

	$team->{'pop'} += $island->{'pop'};
	$team->{'farm'} += $island->{'farm'};
	$team->{'factory'} += $island->{'factory'};
	$team->{'food'} += $island->{'food'};
	$team->{'achive'} += $island->{'achive'};
	if($winlose == 3) { $team->{'reward'} += $island->{'reward'};
	} elsif($winlose == 1) { $team->{'waste'} += $island->{'waste'}; }
	$team->{'estiMateFlag'}++;

	if($team->{'estiMateFlag'} != $HmenberCount) {
		return;
	}

	# 번영, 재난상
	my($pop) = $team->{'pop'};
	my($damage) = $team->{'oldPop'} - $pop;
	my($flags) = $team->{'prize'};
	my($name) = $team->{'name'};
	my($achive) = $team->{'achive'};

	# 번영상
	if((!($flags & 1)) && $pop>= $HprizePoint[1]){
		$flags |= 1;
		logTPrize($name, $Hprize[1]);
	} elsif((!($flags & 2)) && $pop>= $HprizePoint[2]){
		$flags |= 2;
		logTPrize($name, $Hprize[2]);
	} elsif((!($flags & 4)) && $pop>= $HprizePoint[3]){
		$flags |= 4;
		logTPrize($name, $Hprize[3]);
	}

	if((!($flags & 8)) && $achive>= $HprizePoint[4]){
		$flags |= 8;
		logTPrize($name, $Hprize[4]);
	} elsif((!($flags & 16)) && $achive> $HprizePoint[5]){
		$flags |= 16;
		logTPrize($name, $Hprize[5]);
	} elsif((!($flags & 32)) && $achive> $HprizePoint[6]){
		$flags |= 32;
		logTPrize($name, $Hprize[6]);
	}

	# 재난상
	if((!($flags & 64)) && $damage>= $HprizePoint[7]){
		$flags |= 64;
		logTPrize($name, $Hprize[7]);
	} elsif((!($flags & 128)) && $damage>= $HprizePoint[8]){
		$flags |= 128;
		logTPrize($name, $Hprize[8]);
	} elsif((!($flags & 256)) && $damage>= $HprizePoint[9]){
		$flags |= 256;
		logTPrize($name, $Hprize[9]);
	}

	$team->{'prize'} = $flags;

}


# 범위 안의 지형을 수 가능
sub countAround {
	my($land, $x, $y, $kind, $range) = @_;
	my($i, $count, $sx, $sy);
	$count = 0;
	for($i = 0; $i < $range; $i++) {
		 $sx = $x + $ax[$i];
		 $sy = $y + $ay[$i];

		 # 행 기준 위치 조정
		 if((($sy % 2) == 0) && (($y % 2) == 1)) {
			 $sx--;
		 }

		 if(($sx < 0) || ($sx>= $HislandSize) ||
			($sy < 0) || ($sy>= $HislandSize)) {
			 # 범위 밖의 경우
			 if($kind == $HlandSea) {
				 # 바다이면 가 산
				 $count++;
			 }
		 } else {
			 # 범위 안의 경우
			 if($land->[$sx][$sy] == $kind) {
				 $count++;
			 }
		 }
	}
	return $count;
}

# 0에서(n - 1)까지의 숫자가한 번씩출해 옵니다 수열을 만들기
sub randomArray {
	my($n) = @_;
	my(@list, $i);

	# 초기 값
	if($n == 0) {
		$n = 1;
	}
	@list = (0..$n-1);

	# 셔터 전체
	for ($i = $n; --$i; ) {
		my($j) = int(rand($i+1));
		if($i == $j) { next; };
		@list[$i,$j] = @list[$j,$i];
	}

	return @list;
}

# 이름 변경실패
sub tempChangeNothing {
	out(<<END);
${HtagBig_}이름과 비밀번호가 모두 비어 있습니다${H_tagBig}$HtempBack
END
}

# 이름 변경 자금 부족
sub tempChangeNoMoney {
	out(<<END);
${HtagBig_} 자금 부족으로 변경할 수 없습니다${H_tagBig}$HtempBack
END
}

# 이름 변경성공
sub tempChange {
	out(<<END);
${HtagBig_}변경을 완료했습니다${H_tagBig}$HtempBack
END
}

1;
