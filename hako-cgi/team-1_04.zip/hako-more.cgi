#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}
#----------------------------------------------------------------------
# 모형정원 팀 토너먼트 추가모듈
# Kyosuke Takayama (돈 가바초): support@mc.neweb.ne.jp
# 매의 섬 http://espion.just-size.jp/
# 질문은 받지 않습니다
#----------------------------------------------------------------------
# 모형정원 팀 토너먼트
# 추가모듈
# $Id: hako-more.cgi 15 2004-06-02 02:04:26Z gaba $

#----------------------------------------------------------------------
# 로그 표시 모드
#----------------------------------------------------------------------
# 메인
sub logViewMain {

 # 개방
 unlock();

 # 템플릿출력
 tempLogPage();
}

sub tempLogPage {

 out(<<END);

<font size=+3><b>${HtagHeader_}최근 사건${H_tagHeader}</b></font>
 <a href="$HthisFile?LogFileView=1"><FONT COLOR="blue" size=2><B>현 턴</a>
 <a href="$HthisFile?LogFileView=2">2턴분 표시</a>
END
for($i = 3; $i -1 < $HlogMax; $i++) {
	out(" <a href=\"$HthisFile?LogFileView=${i}\">${i}턴분</a>\n");
}
 out(<<END);
</b></font><br>
END
 logPrintTop();

}

# 로그 표시
sub logPrintTop {
 my($i);
 for($i = 0; $i < $Hlogturn; $i++) {
	out("<hr>\n");
	logFilePrint($i, 0, 0);

 }
}

#----------------------------------------------------------------------
# 설정도움말 모드
#----------------------------------------------------------------------
# 메인
# 도움말페이지
sub helpMain {

 # 개방
 unlock();
my($devrep) = '';
my($firep) = '';
my($unit) = $HunitTime / 3600;
my($fiunit) = $HfightTime / 3600;

if($HdevRepTurn> 1){ $devrep = '('. $HdevRepTurn. '턴정리해서갱신)'; }
if($HfigRepTurn> 1){ $firep = '('. $HfigRepTurn. '턴정리해서갱신)'; }

 out(<<END);
${HtagTitle_} 설정도움말${H_tagTitle}
<BR><BR><BR>

<H1>${HtagHeader_}각종 설정 값${H_tagHeader}</H1>
<table width=300 border $HbgNameCell>
<TR>
<TD colspan=2 $HbgTitleCell>${HtagTH_} 섬 수관계${H_tagTH}</TD>
</TR>
<TR>
<TD> ${HtagName_}팀 수${H_tagName} </TD><TD><B>$teamNum 팀</b></TD>
</TR>
<TR>
<TD> ${HtagName_}멤버 수${H_tagName} </TD><TD><B>$HmenberCount 섬</b></TD>
</TR>
<TR><TD> ${HtagName_}예선돌진파괴${H_tagName}</TD><TD><B>$yteamNum 팀</b></TD>
</TR>
<TR>
<TD colspan=2 $HbgTitleCell>${HtagTH_} 섬의 초기 값${H_tagTH}</TD>
</TR>
<TR><TD> ${HtagName_}면적${H_tagName} </TD><TD><B>${HlandSizeValue}${HunitArea}</b></TD></TR>
<TR><TD> ${HtagName_}황무지의 수${H_tagName}</TD><TD><B>10케장소</b></TD></TR>
<TR><TD> ${HtagName_}얕은 바다의 수${H_tagName}</TD><TD><B>${HseaNum}케장소</b></TD></TR>
<TR><TD> ${HtagName_}미사일 기지의 수${H_tagName} </TD><TD><B>${HlandFirstMiss}기계</b></TD></TR>
<TR><TD> ${HtagName_} 자금${H_tagName} </TD><TD><B>${HinitialMoney}${HunitMoney}</b></TD></TR>
<TR><TD> ${HtagName_}식량${H_tagName} </TD><TD><B>${HinitialFood}${HunitFood}</b></TD></TR>

<TR>
<TD colspan=2 $HbgTitleCell>${HtagTH_}기타 설정 값${H_tagTH}</TD>
</TR>
<TR><TD> ${HtagName_}자동포기 턴${H_tagName}</TD><TD><B>${HgiveupTurn}턴</b></TD></TR>
<TR><TD> ${HtagName_}최대 명령 입력 수${H_tagName}</TD><TD><B>${HcommandMax}개</b></TD></TR>
</table>
<BR><HR>
<H1>${HtagHeader_}턴 진행 도움말${H_tagHeader}</H1>
<table width=300 border $HbgNameCell>
<TR>
<TD colspan=2 $HbgTitleCell>${HtagTH_}턴 갱신 시간${H_tagTH}</TD>
</TR>
<TR>
<td WIDTH=100><NOBR> ${HtagName_}개발 기간${H_tagName}</NOBR></TD><TD NOWRAP><B>$unit 시간</b> ${devrep}</TD>
</TR>
<TR><TD><NOBR> ${HtagName_}전투 기간${H_tagName}</NOBR></TD><TD NOWRAP><B>$fiunit 시간</b> ${firep}</TD>
</TR>
<TR>
<TD colspan=2 $HbgTitleCell>${HtagTH_}각 기간의 턴 수${H_tagTH}</TD>
</TR>
<TR>
<TD> ${HtagName_}예선${H_tagName} </TD><TD><B>$HyosenTurn 턴까지</b></TD>
</TR>
<TR><TD> ${HtagName_}개발 기간${H_tagName}</TD><TD><B><NOBR>$HdevTurn 턴</NOBR></b></TD>
</TR>
<TR><TD NOWRAP> ${HtagName_}전투 기간${H_tagName}</TD><TD NOWRAP><B>$HfigTurn 턴</b> (결승전은 + $HfigRepTurn 턴)</TD>
</TR>
</table>
END

my($fitone) = $HdevTurn + $HyosenTurn;
my($fittwo) = $fitone + $HfigTurn;
my($fitNum) = 1;
 out(<<END);
<BR><HR>
<H1>${HtagHeader_}턴 진행 과정 간이빠름보기표${H_tagHeader}</H1>
<table height=125 border $HbgNameCell>
<TR>
<td>${HtagName_}예선${H_tagName}</td>
<TD $HbgCommentCell><B>0 ~ $HyosenTurn</B></td>
</tr>
END

for($i = 2;$i <= $yteamNum;$i*=2) {

 if($i>= $yteamNum) { $fittwo += $HfigRepTurn; }

 out(<<END);
<TR>
<TD>$tes${HtagName_}제$fitNum 회전개발 기간${H_tagName}</td>
<TD $HbgCommentCell><B>$HyosenTurn ~ $fitone</b></td>
</tr>
<TR>
<TD align=right>${HtagName_}전투 기간${H_tagName}</td><TD $HbgCommentCell><B>
END

 out (($fitone + 1). " ~ $fittwo</b></td></tr>\n");
 $fitNum++;
 $HyosenTurn = $fittwo + 1;
 $fitone = $HyosenTurn + $HdevTurn - 1;
 $fittwo = $fitone + $HfigTurn;
}

 out(<<END);
</table>
<BR>
<hr><center>$HtempBack</center></hr>
END

}

#----------------------------------------------------------------------
# 작전본부 모드
#----------------------------------------------------------------------
# 메인
sub teamDataMain {

 my($currentTID) = $HidToTeamNumber{$HteamID};
 my($team) = $Hteams[$currentTID];
 my($trank) = $currentTID + 1;
 # 왠지그팀이 없는 경우
 if($currentTID eq '') {
	unlock();
	tempProblem();
	return;
 }
 if($team->{'password'} ne $HinputPassword2) {
	unlock();
	tempWrongPassword();
	return;
 }
# 시간 표시
my($hour, $min, $sec);
my($now) = time;
my($showTIME) = ($HislandLastTime + $HunitTime - $now);
$hour = int($showTIME / 3600);
$min = int(($showTIME - ($hour * 3600)) / 60);
$sec = $showTIME - ($hour * 3600) - ($min * 60);
 out(<<END);
<CENTER>
${HtagBig_}${HtagTName_}$team->{'name'}${H_tagTName}작전본부${H_tagBig}<P>
팀 비밀번호[ $team->{'password'} ]
<P>
<B>턴$HislandTurn</B> (다음 턴까지,$hour 시간 $min 분 $sec 초)
<TABLE BORDER>
<TR>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}순위${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}팀${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}상대 팀${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}인구${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_} 자금${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}식량${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}농장규모${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}공장규모${H_tagTH}</NOBR></TH>
</TR>
END
	$id = $team->{'id'};
	$tfarm = $team->{'farm'};
	$tfactory = $team->{'factory'};
	$tfarm = ($tfarm == 0) ? "보유하지 않음" : "${tfarm}0$HunitPop";
	$tfactory = ($tfactory == 0) ? "보유하지 않음" : "${tfactory}0$HunitPop";
	my($fightName) = '';
	my($fightMember) = '';
	if($team->{'fightid'}> 0) {
	 $fightName = "<A STYlE=\"text-decoration:none\" HREF=$HthisFile?TEAM=$team->{'fightid'}#data>${HtagTName_}$Hteams[$HidToTeamNumber{$team->{'fightid'}}]->{'name'}${H_tagTName}</A>";
	 $fightMember = $Hteams[$HidToTeamNumber{$team->{'fightid'}}]->{'member'};
	} else {
	 $fightName = "${HtagName_}<CENTER>- - -${H_tagName}</CENTER>";
	}

	 $mStr1 = "<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$team->{'money'}$HunitMoney</NOBR></TD>";
	out(<<END);
<TR>
<TD $HbgNumberCell ROWSPAN=2 align=center nowrap=nowrap><NOBR>${HtagNumber_}${trank}${H_tagNumber}</NOBR></TD>
<TD $HbgNameCell align=left nowrap=nowrap>
<NOBR>${HtagTName_}$team->{'name'}${H_tagTName}</NOBR></TD>
<TD $HbgNameCell align=left nowrap=nowrap>
<NOBR>${fightName}</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><A NAME=team$team->{'id'}>
<NOBR>$team->{'pop'}$HunitPop</NOBR></TD>
$mStr1
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$team->{'food'}$HunitFood</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$tfarm</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$tfactory
END
 if($fightMember ne '') {
	out("</NOBR></TD></TR><TR><TD $HbgCommentCell COLSPAN=9 align=left nowrap=nowrap><NOBR>${HtagTH_}상대 팀멤버:${H_tagTH}");
	while($fightMember =~ s/([0-9]*),//) {
	 my($tIsland) = $Hislands[$HidToNumber{$1}];
	 out("<A STYlE=\"text-decoration:none\" HREF=$HthisFile?Sight=$tIsland->{'id'}>${HtagName_}$tIsland->{'name'} 섬${H_tagName}</A> ");
	}
 }
 out(<<END);
</NOBR></TD>
</TR></TABLE>
<P>
<TABLE BORDER>
<TR>
<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}순위${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_} 섬${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}인구${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}식량${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}면적${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}농장규모${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}공장규모${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}미사일${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}방위 시설${H_tagTH}</NOBR></TH>
</TR>
END
 my($numMember) = $team->{'member'};
 while($numMember =~ s/([0-9]*),//) {
	$iNumber = $HidToNumber{$1};
	push(@islanddata,$iNumber);
 }
 @islanddata = sort { $a <=> $b } @islanddata;
for($g = 0;$g < $HmenberCount;$g++) {
	$iNumber = $islanddata[$g];
	if($iNumber eq '') { last; }

	readIslandsFile($Hislands[$islanddata[$g]]->{'id'});
	$island = $Hislands[$iNumber];
	# 정보 표시
	my($rank) = $iNumber + 1;
	my($farm) = $island->{'farm'};
	my($factory) = $island->{'factory'};
	$farm = ($farm == 0) ? "보유하지 않음" : "${farm}0$HunitPop";
	$factory = ($factory == 0) ? "보유하지 않음" : "${factory}0$HunitPop";
	my($comname) ="${HtagTH_}코멘트:${H_tagTH}";
	if(($island->{'ownername'} ne '0') && ($island->{'ownername'} ne "코멘트")){
	 $comname = "<FONT COLOR=\"blue\"><B>$island->{'ownername'}:</b></font>";
	}
	if($island->{'absent'} == 0) {
		$name = "${HtagName_}$island->{'name'} 섬${H_tagName}";
	} else {
	 $name = "${HtagName2_}$island->{'name'} 섬($island->{'absent'})${H_tagName2}";
	}
	out(<<END);
<TR>
<TD $HbgNumberCell ROWSPAN=3 align=middle nowrap=nowrap><NOBR>${HtagNumber_}$rank${H_tagNumber}</NOBR></TD>
<TD $HbgInfoCell ROWSPAN=2 nowrap=nowrap><NOBR>
<A STYlE=\"text-decoration:none\" HREF=$HthisFile?Sight=$island->{'id'}>$name</A>
</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$island->{'pop'}$HunitPop</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$island->{'food'}$HunitFood</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$island->{'area'}$HunitArea</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>${farm}</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>${factory}</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$island->{'fire'}발</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$island->{'defence'}기준</NOBR></TD>
</TR>
<TR>
<TD $HbgCommentCell COLSPAN=7 nowrap=nowrap><NOBR>$comname$island->{'comment'}</NOBR>
</TD>
<TR>
<TD $HbgInfoCell COLSPAN=3 nowrap=nowrap>
END
 for($i = 0; $i < 6; $i++) {
	if($i == 3) {
	 out("</TD><TD $HbgInfoCell COLSPAN=5 nowrap=nowrap VALIGN=TOP>");
	}
	tempCommand($i, $island->{'command'}->[$i]);
 }
	out(<<END);

</TD></TR>
END
 }

 unlock();

	out(<<END);

</TABLE>
<SCRIPT language=JavaScript>
<!--
 function chengeTeamName() {
	CTNAME = window.open("hako-main.cgi", 'CTNAME', 'menubar=no,toolbar=no,location=no,directories=no,status=no,scrollbars=no,resizable=no,width=750,height=250');
 }
//-->
</SCRIPT>

<FORM ACTION=$HthisFile METHOD=POST TARGET="CTNAME">
<INPUT TYPE=HIDDEN NAME=TEAMID VALUE=$team->{'id'}>
<INPUT TYPE=HIDDEN NAME=PASSWORD2 VALUE=$team->{'password'}>
<INPUT TYPE=TEXT NAME=CTEAMNAME VALUE="$team->{'name'}" SIZE="25">
<INPUT TYPE=SUBMIT VALUE="팀 이름 변경" onClick="chengeTeamName()" name=ChangeTeamName>
</FORM>
</CENTER>

END

}

# 입력 완료된 명령 표시
sub tempCommand {
 my($number, $command) = @_;
 my($kind, $target, $x, $y, $arg) =
	(
	 $command->{'kind'},
	 $command->{'target'},
	 $command->{'x'},
	 $command->{'y'},
	 $command->{'arg'}
	 );
 my($name) = "$HtagComName_${HcomName[$kind]}$H_tagComName";
 my($point) = "$HtagName_($x,$y)$H_tagName";
 $target = $HidToName{$target};
 if($target eq '') {
	$target = "무인";
 }
 $target = "$HtagName_${target} 섬$H_tagName";
 my($value) = $arg * $HcomCost[$kind];
 if($value == 0) {
	$value = $HcomCost[$kind];
 }
 if($value < 0) {
	$value = -$value;
	$value = "$value$HunitFood";
 } else {
	$value = "$value$HunitMoney";
 }
 $value = "$HtagName_$value$H_tagName";

 my($j) = sprintf("%02d:", $number + 1);

 out("<NOBR>$HtagNumber_$j$H_tagNumber<FONT COLOR=\"$HnormalColor\">");

 if(($kind == $HcomDoNothing) || ($kind == $HcomAutoPrepare3) ||
 ($kind == $HcomGiveup)) {
	out("$name");
 } elsif(($kind == $HcomMissileNM) ||
	 ($kind == $HcomMissilePP)) {
	# 미사일계
	my($n) = ($arg == 0 ? '무제한' : "${arg}발");
	out("$target$point 로$name($HtagName_$n$H_tagName)");
 } elsif($kind == $HcomSell) {
	# 식량 수출
	out("$name$value");
 } elsif($kind == $HcomPropaganda) {
	# 유치 활동
	out("$name");
 } elsif($kind == $HcomFood) {
	# 지원
	out("$target 로$name$value");
 } elsif($kind == $HcomDestroy) {
	# 굴착
	out("$point 에서$name");
 } elsif(($kind == $HcomFarm) ||
	 ($kind == $HcomFactory)) {
	# 횟수 포함
	if($arg == 0) {
	 out("$point 에서$name");
	} else {
	 out("$point 에서$name($arg 회)");
	}
 } else {
	# 좌표 포함
	out("$point 에서$name");
 }

 out("</FONT></NOBR><BR>");
}

#----------------------------------------------------------------------
# 팀별도 로그 표시 모드
#----------------------------------------------------------------------
# 메인
sub logTeamMain {
 # 개방
 unlock();

 # 템플릿출력
 tempTeamLogPage();
}

sub tempTeamLogPage {
 my($HcurrentTNumber) = $HidToTeamNumber{$HlogteamID};
 my($team) = $Hteams[$HcurrentTNumber];
 # 왠지그팀이 없는 경우
 if($HcurrentTNumber eq '' and $HlogteamID != 0) {
	tempProblem();
	return;
 }
 if($HlogteamID != 0) { $tName = $team->{'name'}; } else { $tName = '팀별도'; }
 out(<<END);
<CENTER>
<font size=+3><b>${HtagHeader_}${HtagName_}$tName ${H_tagName}최근 사건${H_tagHeader}</b></font>
<FORM ACTION=$HthisFile METHOD=GET>
<SELECT NAME=LogFileTeam>
END
 for($i = 0; $i < $HteamNumber; $i++) {
	my($tTeam) = $Hteams[$i];
	out("<OPTION VALUE=$tTeam->{'id'}>$tTeam->{'name'}\n");
 }
 out(<<END);
</SELECT>
<INPUT TYPE=SUBMIT VALUE="표시">
</FORM>
</CENTER>
END
 if($HlogteamID != 0) { logPrintTeamTop($team); }

}

# 로그 표시
sub logPrintTeamTop {
 my($i,$f) = (0,0);
 my($team) = @_;
 my($numMember) = $team->{'member'};
 while($numMember =~ s/([0-9]*),//) {
	my($HcurrentNumber) = $HidToNumber{$1};
	my($island) = $Hislands[$HcurrentNumber];
	$teamLog[$f] = $island->{'id'};
	$f++;
 }
 for($i = 0; $i < 3; $i++) {
	out("<hr>\n");
	for($j = 0; $j <= $#teamLog; $j++) {
	 logFilePrint($i, $teamLog[$j], 0, 1);
	}
 }
}

#----------------------------------------------------------------------
# 정보 변경 모드
#----------------------------------------------------------------------
# 메인
sub changeTeamNameMain {
 # id에서 섬을 가져옴
 my($currentTID) = $HidToTeamNumber{$HteamID};
 my($team) = $Hteams[$currentTID];
 $tempclose = '</TD><TD><INPUT TYPE="BUTTON" VALUE=" CLOSE " onClick="top.close();"></TD></TR></TABLE>';
 # 왠지그팀이 없는 경우
 if($currentTID eq '') {
	unlock();
	tempProblem();
	return;
 }
 if($team->{'password'} ne $HinputPassword2) {
	unlock();
	tempWrongPassword();
	return;
 }
 out ("<TABLE><TR><TD>\n");

 if($teamName ne '') {
	# 이름 변경의 경우
	# 이름이 유효한지 확인
	if($teamName =~ /[,\?\(\)\<\>]|^무인$/) {
	 # 사용 불가 이름
	 unlock();
	 tempNewTeamBadName();
	 return;
	}

	# 이름의 중복 확인
	if(nameToTeamNumber($teamName) != -1){
	 # 이미 발견완료
	 unlock();
	 tempNewTeamAlready();
	 return;
	}

	# 이름을 변경
	logChangeName($team->{'name'}, $teamName);
	$team->{'name'} = $teamName;
 } else {
	unlock();
	tempChangeNothing();
	return;
 }

 for($i = 0; $i < $HteamNumber; $i++) {
	my($team) = $Hteams[$i];
	open(DAT, ">>team.tmp.cgi");
	 print DAT "$team->{'id'}\n";
	 print DAT "$team->{'name'}\n";
	 print DAT "$team->{'password'}\n";
	close(DAT);
 }
 rename ("team.tmp.cgi", "team.cgi");

 # 데이터 쓰기
 writeTeamsFile();
 unlock();

 # 변경성공
 tempChange();
}

# 이름의 변경
sub logChangeName {
 my($name1, $name2) = @_;
 logHistory("${HtagTName_}${name1}${H_tagTName}, 명칭을${HtagTName_}${name2}${H_tagTName}에 변경.");
}

# 변경성공
sub tempChange {
 out(<<END);
${HtagBig_}변경을 완료했습니다${H_tagBig}$tempclose
END
}

# 이미 같은 이름의 섬이 있는 경우
sub tempNewTeamAlready {
 out(<<END);
${HtagBig_}그팀은, 이 있습니다.${H_tagBig}$tempclose
END
}

# 신규 등록 시 이름이 올바르지 않은 경우
sub tempNewTeamBadName {
 out(<<END);
${HtagBig_}',?()<>\$'등을 넣거나,<BR>'무인'등 이상한 이름은 피하세요~${H_tagBig}$tempclose
END
}

# 이름 변경실패
sub tempChangeNothing {
 out(<<END);
${HtagBig_}빈칸은 불필요목입니다${H_tagBig}$tempclose
END
}

# 기록 로그
sub logHistory {
 open(HOUT, ">>${HdirName}/hakojima.his");
 print HOUT "$HislandTurn,$_[0]\n";
 close(HOUT);
}

#----------------------------------------------------------------------
# 전투 기록 모드
#----------------------------------------------------------------------
# 메인
sub fightlogMain {

	out ("${HtagTitle_}대전 기록${H_tagTitle}<P>\n");
 # 대전 기록읽기
 open(FOUT, "${HdirName}/fight.log");
	while($f = <FOUT>){
	 chomp($f);
	 $data = <FOUT>;
	 if($f == 0) {
		$fcount = "예선 탈락";
	 } elsif($data == 1) {
		$fcount = "결승전";
	 } else {
		$fcount = "제". $f. "회전";
	 }
 out(<<END);
<HR><BLOCKQUOTE>
<H1>${HtagHeader_} $fcount${H_tagHeader}</H1>
<TABLE BORDER>
<TR>
END

if($f) {
 out(<<END);
<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}승자${H_tagTH}</TH>
<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}인구${H_tagTH}</TH>
<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}패자${H_tagTH}</TH>
<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}인구${H_tagTH}</TH>
<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}보상금${H_tagTH}</TH></TR>
END
} else {
 out(<<END);
<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}팀${H_tagTH}</TH>
<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}인구${H_tagTH}</TH>
END

}
	 for($i = 0;$i < $data;$i++) {
		$fdata = <FOUT>;
		out("$fdata");
	 }
 out(<<END);
</TABLE></BLOCKQUOTE><BR>
END

	}
 close(FOUT);


 # 개방
 unlock();


}

#----------------------------------------------------------------------
# 관리자 전용페이지
#----------------------------------------------------------------------
# 메인
sub pageAdminMain {

 # 비밀번호 확인
 if($HoldPassword ne $masterPassword) {
	# password 오류
	unlock();
	tempWrongPassword();
	return;
 }

 # 개방
 unlock();
 out(<<END);
<table><TR><TD width=100>
</TD>
<TD valign=top>
<H1>${HtagHeader_} 섬의 강제퇴제거${H_tagHeader}</H1>

<FORM action="$HthisFile" method="POST">
도의 섬을 삭제하시겠습니까?<BR>
<SELECT NAME="ISLANDID">
$HislandList
</SELECT><BR><BR>
확인을 위해 한 번 더<BR>
<SELECT NAME="DELISLAND">
$HislandList
</SELECT><BR>
<INPUT TYPE="hidden" NAME ="OLDPASS" VALUE="$masterPassword"><BR>
<INPUT TYPE="submit" VALUE=" 삭제 제외 " NAME="DeleteIsland"><BR><BR>
<font color=red><B>위험!</B></font>오오류에무키님부탁드립니다.
</FORM>
</TD>
</TR></table>


<HR>
<center>$HtempBack</center>
END

}

1;
