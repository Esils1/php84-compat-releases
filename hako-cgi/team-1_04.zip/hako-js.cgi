#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}
#----------------------------------------------------------------------
# 모형정원 제도 ver2.30
# 톱 페이지 모듈(ver1.00)
# 사용 조건과 사용 방법은 hako-readme.txt 파일을 참조해 주세요
#
# 모형정원 제도의 페이지: http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html
#----------------------------------------------------------------------
# 모형정원 팀 토너먼트
# JS 개발 화면모듈
# $Id: hako-js.cgi 15 2004-06-02 02:04:26Z gaba $

#----------------------------------------------------------------------
# Java스크립트개발 화면
#----------------------------------------------------------------------
# ○○섬개발계획
sub tempOwnerJava {
	$HcurrentNumber = $HidToNumber{$HcurrentID};
	my($island) = $Hislands[$HcurrentNumber];
 my($team) = $Hteams[$HidToTeamNumber{$island->{'teamid'}}];
	# 명령 설정
	$set_com = "";
	$com_max = "";
	for($i = 0; $i < $HcommandMax; $i++) {
		# 각 요소 꺼내기
		my($command) = $island->{'command'}->[$i];
		my($s_kind, $s_target, $s_x, $s_y, $s_arg) =
		(
		$command->{'kind'},
		$command->{'target'},
		$command->{'x'},
		$command->{'y'},
		$command->{'arg'}
		);
		# 명령 등록
		if($i == $HcommandMax-1){
			$set_com.= "\[$s_kind\,$s_x\,$s_y\,$s_arg\,$s_target\]\n";
			$com_max.= "0"
		}else{
			$set_com.= "\[$s_kind\,$s_x\,$s_y\,$s_arg\,$s_target\]\,\n";
			$com_max.= "0,"
		}
	}

 #명령 목록 설정
	my($l_kind);
	$set_listcom = "";
	for($i = 0; $i < $HcommandTotal; $i++) {
		$l_kind = $HcomList[$i];
		if($l_kind < 60 && $l_kind != 6) {
			$set_listcom.= "\[$l_kind\,\'$HcomName[$l_kind]\'\]\,\n";
		}
		if($l_kind == $HcomAutoPrepare3) {
			$set_listcom.= "\[64\,\'일괄 자동 땅고르기\'\]\n";
		}
	}

	my($set_island, $l_name, $l_id);
	#섬 목록 설정
	$set_island = "";
	for($i = 0; $i < $HislandNumber; $i++) {
		$l_name = $Hislands[$i]->{'name'};
		$l_name =~ s/'/\\'/g;
		$l_id = $Hislands[$i]->{'id'};
		if($i == $HislandNumber-1){
			$set_island.= "\[$l_id\,\'$l_name\'\]\n";
		}else{
			$set_island.= "\[$l_id\,\'$l_name\'\]\,\n";
		}
	}

 $nextTurn = $HunitTime - time() + $HislandLastTime;
 out(<<END);
<CENTER>
${HtagBig_}${HtagName_}${HcurrentName} 섬${H_tagName}개발계획${H_tagBig}<BR>
$HtempBack<BR>
</CENTER>
<SCRIPT Language="JavaScript">
<!--
// JavaScript 개발판 배포처
// 앗포암자모형정원 제도( http://appoh.execweb.cx/hakoniwa/ )
// Programmed by Jynichi Sakai(앗포)
isIE4 = (navigator.appVersion.charAt(0)>=4 && (navigator.appVersion).indexOf("MSIE") != -1);
isNN4 = (navigator.appVersion.charAt(0)>=4 && (navigator.appName).indexOf("Netscape")!=-1);
isNN6 = (document.getElementById);

var str;
var mouseX = 0;
var mouseY = 0;

g = [$com_max];
k1 = [$com_max];
k2 = [$com_max];
tmpcom1 = [ [0,0,0,0,0] ];
tmpcom2 = [ [0,0,0,0,0] ];
command = [
$set_com];

comlist = [
$set_listcom];

islname = [
$set_island];

function init(){
	for(i = 0; i < command.length ;i++) {
		for(j = 0; j < comlist.length ; j++) {
			if(command[i][0] == comlist[j][0]) {
				g[i] = comlist[j][1];
			}
		}
	}
	outp();
	str = plchg();
	str = "<NOBR><font color=blue>---- 전송 완료 ----</font></NOBR><br>"+str;
	disp(str, "#ccffcc");
	document.onkeydown = commandKeyDown;
/*
 if(isIE4){
	window.document.onmouseup = menuclose;
 } else {
	document.captureEvents(Event.MOUSEDOWN)
	document.onmousedown = getMouseData;
	if(!(isNN6)) {
	 window.document.onmouseup = menuclose;
	}
 }
*/
}

function cominput(x, k, z) {
	a = document.myForm.NUMBER.options[document.myForm.NUMBER.selectedIndex].value;
	b = document.myForm.COMMAND.options[document.myForm.COMMAND.selectedIndex].value;
	c = document.myForm.POINTX.options[document.myForm.POINTX.selectedIndex].value;
	d = document.myForm.POINTY.options[document.myForm.POINTY.selectedIndex].value;
	e = document.myForm.AMOUNT.options[document.myForm.AMOUNT.selectedIndex].value;
	f = document.myForm.TARGETID.options[document.myForm.TARGETID.selectedIndex].value;
	if(x == 6){ b = k; }
	if(z) { f = z; }
	if (x == 1 || x == 6)	{
		for(i = $HcommandMax - 1; i> a; i--) {
			command[i] = command[i-1];
			g[i] = g[i-1];
		}
	}else if(x == 3){
		for(i = Math.floor(a); i < ($HcommandMax - 1); i++) {
			command[i] = command[i + 1];
			g[i] = g[i+1];
		}
		command[$HcommandMax-1] = [41,0,0,0,0];
		g[$HcommandMax-1] = '자금 조달';
		str = plchg();
		str = "<NOBR><font color=red><b>-----미전송-----</b></font></NOBR><br>"+str;
		disp(str,"white");
		outp();
		return true;
	}else if(x == 4){
		i = Math.floor(a)
		if (i == 0){ return true; }
		i = Math.floor(a)
		tmpcom1[i] = command[i];tmpcom2[i] = command[i - 1];
		command[i] = tmpcom2[i];command[i-1] = tmpcom1[i];
		k1[i] = g[i];k2[i] = g[i - 1];
		g[i] = k2[i];g[i-1] = k1[i];
		ns(--i);
		str = plchg();
		str = "<NOBR><font color=red><b>-----미전송-----</b></font></NOBR><br>"+str;
		disp(str,"white");
		outp();
		return true;
	}else if(x == 5){
		i = Math.floor(a)
		if (i == $HcommandMax-1){ return true; }
		tmpcom1[i] = command[i];tmpcom2[i] = command[i + 1];
		command[i] = tmpcom2[i];command[i+1] = tmpcom1[i];
		k1[i] = g[i];k2[i] = g[i + 1];
		g[i] = k2[i];g[i+1] = k1[i];
		ns(++i);
		str = plchg();
		str = "<NOBR><font color=red><b>-----미전송-----</b></font></NOBR><br>"+str;
		disp(str,"white");
		outp();
		return true;
	}

	for(i = 0;i < comlist.length; i++){
		if(comlist[i][0] == b){
			g[a] = comlist[i][1];
			break;
		}
	}
	command[a] = [b,c,d,e,f];
	ns(++a);
	str = plchg();
	str = "<NOBR><font color=red><b>-----미전송-----</b></font></NOBR><br>"+str;
	disp(str, "white");
	outp();
	menuclose();
	return true;
}


function commandKeyDown(e) {
	e = e || window.event;
	var src = e.target || e.srcElement;
	var tag = src && src.tagName ? src.tagName.toUpperCase() : '';
	if(tag == 'INPUT' || tag == 'TEXTAREA' || tag == 'SELECT') { return true; }
	var code = e.keyCode || e.which;
	if(code == 46) {
		cominput(3);
		if(e.preventDefault) { e.preventDefault(); }
		return false;
	}
	return true;
}

function commandNameByKind(kind) {
	for(var i = 0; i < comlist.length; i++) {
		if(Number(comlist[i][0]) == Number(kind)) { return comlist[i][1]; }
	}
	return '자금 조달';
}

function firstEmptySlot(start) {
	start = Number(start) || 0;
	for(var i = start; i < $HcommandMax; i++) {
		if(Number(command[i][0]) == $HcomDoNothing) { return i; }
	}
	return -1;
}

function selectPlanNumber(value) {
	var sel = document.myForm.NUMBER;
	for(var i = 0; i < sel.options.length; i++) {
		if(Number(sel.options[i].value) == Number(value)) {
			sel.selectedIndex = i;
			return true;
		}
	}
	return false;
}

function autoInput() {
	var sel = (document.myForm && document.myForm.AUTOCOMMAND) ? document.myForm.AUTOCOMMAND : document.getElementById('AUTOCOMMAND');
	if(!sel) { return false; }
	var kind = Number(sel.options[sel.selectedIndex].value);
	if(kind == $HcomAutoDelete) {
		for(var i = 0; i < $HcommandMax; i++) {
			command[i] = [$HcomDoNothing,0,0,0,0];
			g[i] = commandNameByKind($HcomDoNothing);
		}
		selectPlanNumber(0);
	} else {
		var idx = firstEmptySlot(0);
		if(idx < 0) { idx = $HcommandMax - 1; }
		command[idx] = [kind,0,0,0,0];
		g[idx] = commandNameByKind(kind);
		var next = firstEmptySlot(idx + 1);
		selectPlanNumber(next < 0 ? idx : next);
	}
	str = plchg();
	str = "<NOBR><font color=red><b>-----미전송-----</b></font></NOBR><br>"+str;
	disp(str,"white");
	outp();
	return false;
}

function plchg(){
	strn1 = "";
	for(i = 0; i < $HcommandMax; i++)	{
		c = command[i];
		kind = '<FONT COLOR="#d08000"><B>' + g[i] + '</B></FONT>';
		x = c[1];
		y = c[2];
		tgt = c[4];
		point = '<FONT COLOR="#a06040"><B>' + "(" + x + "," + y + ")" + '</B></FONT>';
		for(j = 0; j < islname.length ; j++) {
			if(tgt == islname[j][0]){
				tgt = '<FONT COLOR="#a06040"><B>' + islname[j][1] + "섬" + '</B></FONT>';
			}
		}
		if(c[0] == $HcomDoNothing || c[0] == $HcomAutoPrepare3){ // 자금 조달 일괄 자동 땅고르기
			strn2 = kind;
		}else if(c[0] == $HcomMissileNM || // 미사일 관련
			c[0] == $HcomMissilePP){
			if(c[3] == 0){
				arg = "(무제한)";
			} else {
				arg = "(" + c[3] + "발)";
			}
			strn2 = tgt + point + "로" + kind + arg;
		}else if(c[0] == $HcomSell){ // 식량 수출
			if(c[3] == 0){ c[3] = 1; }
			arg = c[3] * 100;
			arg = "(" + arg + "$HunitFood)";
			strn2 = kind + arg;
		}else if(c[0] == $HcomFood){ // 식량지원
			if(c[3] == 0){ c[3] = 1; }
			arg = c[3] * 100;
			arg = "(" + arg + "$HunitFood)";
			strn2 = tgt + "로" + kind + arg;
		}else if(c[0] == $HcomDestroy){ // 굴착
			if(c[3] == 0){
				strn2 = point + " " + kind;
			} else {
				arg = c[3] * $HcomCost[$HcomDestroy];
				arg = "(예정\계산" + arg + "$HunitMoney)";
				strn2 = point + " " + kind + arg;
			}
		}else if(c[0] == $HcomPropaganda) { // 유치 활동
			strn2 = kind;
		}else if(c[0] == $HcomFarm || // 농장, 공장, 채굴장 건설
			c[0] == $HcomFactory) {
			if(c[3] != 0){
				arg = "(" + c[3] + "회)";
				strn2 = point + " " + kind + arg;
			}else{
				strn2 = point + " " + kind;
			}
		}else{
			strn2 = point + " " + kind;
		}
		tmpnum = '';
		if(i < 9){ tmpnum = '0'; }
		strn1 +=
		'<A STYLE="text-decoration:none;color:000000" HREF="JavaScript:void(0);" onClick="ns(' + i + ')"><NOBR>' +
		tmpnum + (i + 1) + ':' +
		strn2 + '</NOBR></A><BR>\\n';
	}
	return strn1;
}

function disp(str,bgclr){
	if(str==null) str = "";

	if(isNN6) {
		el = document.getElementById("LINKMSG1");
		el.innerHTML = str;
		document.getElementById("plan").bgColor = bgclr;
	} else if(isIE4) {
		el = document.all("LINKMSG1");
		el.innerHTML = str;
		document.all.plan.bgColor = bgclr;
	}
	else if(isNN4) {
		lay = document.layers["PARENT_LINKMSG"].document.layers["LINKMSG1"];
		lay.document.open();
		lay.document.write("<font style='font-size:11pt'>"+str+"</font>");
		lay.document.close();
		document.layers["PARENT_LINKMSG"].bgColor = bgclr;
	}
}

function outp(){
	comary = "";

	for(k = 0; k < command.length; k++){
	comary = comary + command[k][0]
	+" "+command[k][1]
	+" "+command[k][2]
	+" "+command[k][3]
	+" "+command[k][4]
	+" ";
	}
	document.myForm.COMARY.value = comary;
}

function ps(e, x, y) {
	if(typeof y == "undefined") {
		y = x;
		x = e;
		e = window.event;
	}
	getMouseData(e);
	document.forms[0].elements[3].options[x].selected = true;
	document.forms[0].elements[4].options[y].selected = true;
	showMenu();
	return true;
}

function ns(x) {
	if (x == $HcommandMax){ return true; }
	document.forms[0].elements[1].options[x].selected = true;
	return true;
}

function set_com(x, y, land) {
	com_str = land + "\\n";
	for(i = 0; i < $HcommandMax; i++)	{
		c = command[i];
		x2 = c[1];
		y2 = c[2];
		if(x == x2 && y == y2 && c[0] < 30){
			com_str += "[" + (i + 1) +"]" ;
			kind = g[i];
			if(c[0] == $HcomDestroy){
				if(c[3] == 0){
					com_str += kind;
				} else {
					arg = c[3] * 200;
					arg = "(예정\계산" + arg + "$HunitMoney)";
					com_str += kind + arg;
				}
			}else if(c[0] == $HcomFarm ||
				c[0] == $HcomFactory) {
				if(c[3] != 0){
					arg = "(" + c[3] + "회)";
					com_str += kind + arg;
				}else{
					com_str += kind;
				}
			}else{
				com_str += kind;
			}
			com_str += " ";
		}
	}
	window.status = com_str;
	document.myForm.COMSTATUS.value= com_str;
}

function jump(theForm) {
 var sIndex = theForm.TARGETID.selectedIndex;
 var url = theForm.TARGETID.options[sIndex].value;
 if (url != "" ) window.open("$HthisFile?IslandMap=" +url,"", "menubar=yes,toolbar=no,location=no,directories=no,status=yes,scrollbars=yes,resizable=yes,width=450,height=630");
}

function openBBS()
{
 document.bbsform.target = "bbs";
 document.bbsform.submit();
}

function openTEAM()
{
 document.teamform.target = "camp";
 document.teamform.submit();
}

function showMenu() {
	if((isNN6) && !(isIE4)){
	 document.getElementById("menu").style.left = mouseX + "px";
	 document.getElementById("menu").style.top = (mouseY - 50) + "px";
 document.getElementById("menu").style.display = "block";
 document.getElementById("menu").style.visibility = "visible";
	} else if(isNN4) {
 document.menu.left = mouseX; // 가로
 document.menu.top = mouseY - 30; // 세로
 document.menu.visibility = "show";
	} else if(isIE4) {
	 getMouseData(window.event);
	 menu.style.left= mouseX + "px";
	 menu.style.top = (mouseY - 50) + "px";
	 menu.style.display = "block";
	 menu.style.visibility = "visible";
 }
}

function menuclose() {
 if(isNN6) {
 document.getElementById("menu").style.display = "none";
 } else if(isNN4) {
	document.menu.visibility = "hide";
 } else {
	window["menu"].style.display = "none";
 }
}

function getMouseData(e) {
	e = e || window.event;
	if(!e) { return true; }
	if(typeof e.pageX == "number") {
		mouseX = e.pageX;
		mouseY = e.pageY;
	} else {
		mouseX = e.clientX + (document.documentElement.scrollLeft || document.body.scrollLeft || 0);
		mouseY = e.clientY + (document.documentElement.scrollTop || document.body.scrollTop || 0);
	}
	return true;
}

//-->
</SCRIPT>
<DIV ID="menu" STYLE="position:absolute; visibility:hidden;">
<TABLE BORDER=0 BGCOLOR=#ccffcc>
<TR><TD NOWRAP>

END
 local($kind, $cost, $s, $tak);
 $tak = $HcommandTotal - 3;
 for($i = 0; $i < $tak; $i++) {
	$kind = $HcomList[$i];
	if($kind> 30 || $kind == 6){ next; }
	$cost = $HcomCost[$kind];
	if($cost == 0) {
	 $cost = '무료'
	} elsif($kind == $HcomOil or $kind == $HcomSellOil) {
	 $cost = $cost;
	 $cost.= $HunitOil;
	} elsif($cost < 0) {
	 $cost = - $cost;
	 $cost.= $HunitFood;
	} else {
	 $cost.= $HunitMoney;
	}
if($i == 7){ out("<HR>"); }
	out("<a href=\"javascript:void(0);\" onClick=\"cominput(6,${kind})\" STYlE=\"text-decoration:none\">$HcomName[$kind]($cost)<BR></A>\n");
 }

 out(<<END);
<HR>
<a href="Javascript:void(0);" onClick="menuclose()" STYlE="text-decoration:none">메뉴를 닫기</A>
</TD></TR>
</TABLE>
</DIV>
END
 islandInfo();

 out(<<END);
<CENTER>
<TABLE BORDER>
<TR valign=top>
<TD $HbgInputCell>
<CENTER>
<FORM name="myForm" action="$HthisFile" method=POST>
<B> 비밀번호</B></BR>
<INPUT TYPE=password NAME=PASSWORD VALUE="$HdefaultPassword">
<HR>
<B>동작</B><BR>
<A HREF=JavaScript:void(0); onClick="cominput(1)">삽입</A>
<A HREF=JavaScript:void(0); onClick="cominput(2)">덮어쓰기</A>
<A HREF=JavaScript:void(0); onClick="cominput(3);return false;">삭제</A>
<HR>
<B>계획번호</B><SELECT NAME=NUMBER>
END
 # 계획번호
 my($j, $i);
 for($i = 0; $i < $HcommandMax; $i++) {
	$j = $i + 1;
	out("<OPTION VALUE=$i>$j\n");
 }

 out(<<END);
</SELECT><BR>
<HR>
<B>개발계획</B><BR>
<SELECT NAME=COMMAND>
END

 #명령
 my($kind, $cost, $s);
 for($i = 0; $i < $HcommandTotal; $i++) {
	$kind = $HcomList[$i];
	$cost = $HcomCost[$kind];
	if($cost == 0) {
	 $cost = '무료'
	} elsif($cost < 0) {
	 $cost = - $cost;
	 $cost.= $HunitFood;
	} else {
	 $cost.= $HunitMoney;
	}
	if($kind == $HdefaultKind) {
	 $s = 'SELECTED';
	} else {
	 $s = '';
	}
	if(($kind < 60 && $kind != 6) || ($kind == $HcomAutoPrepare3)){
	$set_cost = "($cost)";
	out("<OPTION VALUE=$kind $s>$HcomName[$kind]$set_cost\n");
	}
 }

 out(<<END);
</SELECT>
<HR>
<B>좌표(</B>
<SELECT NAME=POINTX>

END
 for($i = 0; $i < $HislandSize; $i++) {
	if($i == $HdefaultX) {
	 out("<OPTION VALUE=$i SELECTED>$i\n");
 } else {
	 out("<OPTION VALUE=$i>$i\n");
 }
 }

 out(<<END);
</SELECT>, <SELECT NAME=POINTY>
END

 for($i = 0; $i < $HislandSize; $i++) {
	if($i == $HdefaultY) {
	 out("<OPTION VALUE=$i SELECTED>$i\n");
 } else {
	 out("<OPTION VALUE=$i>$i\n");
 }
 }
 out(<<END);
</SELECT><B>)</B>
<HR>
<B>수량</B><SELECT NAME=AMOUNT>
END

 # 수량
 for($i = 0; $i < 50; $i++) {
	out("<OPTION VALUE=$i>$i\n");
 }

 out(<<END);
</SELECT>
<HR>
<B>대상 섬</B>:
<B><BIG><A HREF=JavaScript:void(0); onClick="jump(myForm)" STYlE="text-decoration:none"> 표시 </A></BIG></B><BR>
<SELECT NAME=TARGETID>
END
out(getTargetList($team->{'id'},$team->{'fightid'}));
 out(<<END);
</SELECT>
<HR>
<B> 명령 이동</B><br>
<BIG><A HREF=JavaScript:void(0); onClick="cominput(4)" STYlE="text-decoration:none"> ▲ </A>..
<A HREF=JavaScript:void(0); onClick="cominput(5)" STYlE="text-decoration:none"> ▼ </A></BIG>
<HR>
<INPUT TYPE="hidden" NAME="COMARY" value="comary">
<INPUT TYPE="hidden" NAME=JAVAMODE value="$HjavaMode">
<INPUT TYPE=submit VALUE="계획 전송" NAME=CommandJavaButton$Hislands[$HcurrentNumber]->{'id'}>
<p><font size=2>마지막에 <font color=red>계획 전송 버튼</font>을<br>누르는 것을 잊지 마세요.</font>
</CENTER><BR>
<nobr><center>미사일 발사상한 수[<b> $island->{'fire'} </b>]발</center></nobr>
</TD>
<TD $HbgMapCell><center>
<FONT SIZE=+1><B>
<A HREF="JavaScript:void(0);" STYlE="text-decoration:none" onClick="openBBS();return false;">
전략회의실로</A>

<A HREF="JavaScript:void(0);" STYlE="text-decoration:none" onClick="openTEAM();return false;">
 작전본부로 </A>
</B>
</FONT><BR>
<TEXTAREA NAME="COMSTATUS" cols="48" rows="2"></TEXTAREA></center>
END
 islandMapJava(1); # 섬 지도, 소유자 모드
 my $comment = $Hislands[$HcurrentNumber]->{'comment'};
 out(<<END);
</FORM>
<FORM NAME=bbsform ACTION="${baseDir}/${teambbs}/bbs.cgi" METHOD=POST>
<INPUT TYPE=HIDDEN NAME=teamID VALUE=$team->{'id'}>
<INPUT TYPE=HIDDEN NAME=tPASS VALUE=$team->{'password'}>
</FORM>
<FORM NAME=teamform ACTION=$HthisFile METHOD=POST>
<INPUT TYPE=HIDDEN NAME=TEAMID VALUE=$team->{'id'}>
<INPUT TYPE=HIDDEN NAME=PASSWORD2 VALUE=$team->{'password'}>
<INPUT TYPE=HIDDEN NAME=teamData VALUE=''>
</FORM>
</TD>
<TD $HbgCommandCell id="plan">
<CENTER><B>자동 입력</B><BR>
<SELECT NAME=AUTOCOMMAND ID=AUTOCOMMAND>
<OPTION VALUE="$HcomAutoPrepare3">$HcomName[$HcomAutoPrepare3](무료)
<OPTION VALUE="$HcomAutoDelete">$HcomName[$HcomAutoDelete](무료)
</SELECT><BR>
<INPUT TYPE=button VALUE="자동 입력 계획 전송" onClick="return autoInput();">
</CENTER>
<HR>
<ilayer name="PARENT_LINKMSG" width="100%" height="100%">
 <layer name="LINKMSG1" width="200"></layer>
 <span id="LINKMSG1"></span>
</ilayer>
<BR>
</TD>
</TR>
</TABLE>
</CENTER>
<HR>
<CENTER>
${HtagBig_}코멘트갱신${H_tagBig}<BR>
<FORM action="$HthisFile" method="POST">
코멘트<INPUT TYPE=text NAME=MESSAGE SIZE=80 VALUE="$comment"><BR>
비밀번호<INPUT TYPE=password NAME=PASSWORD VALUE="$HdefaultPassword">
<INPUT TYPE="hidden" NAME=JAVAMODE VALUE="$HjavaMode">
<INPUT TYPE=submit VALUE="코멘트갱신" NAME=MessageButton$Hislands[$HcurrentNumber]->{'id'}>
</FORM>
</CENTER>
END

}

#----------------------------------------------------------------------
# 로컬 게시판입력 양식 Java스크립트 mode 용
#----------------------------------------------------------------------
sub tempLbbsInputJava {
 out(<<END);
<CENTER>
<FORM action="$HthisFile" method="POST">
<TABLE BORDER>
<TR>
<TH>이름</TH>
<TH COLSPAN=2>내용</TH>
</TR>
<TR>
<TD><INPUT TYPE="text" SIZE=32 MAXLENGTH=32 NAME="LBBSNAME" VALUE="$HdefaultName"></TD>
<TD COLSPAN=2><INPUT TYPE="text" SIZE=80 NAME="LBBSMESSAGE"></TD>
</TR>
<TR>
<TH> 비밀번호</TH>
<TH COLSPAN=2>동작</TH>
</TR>
<TR>
<TD><INPUT TYPE=password SIZE=32 MAXLENGTH=32 NAME=PASSWORD VALUE="$HdefaultPassword"></TD>
<TD align=right>
<INPUT TYPE="submit" VALUE="등록" NAME="LbbsButtonOW$HcurrentID">
</TD>
<TD align=right>
번호
<SELECT NAME=NUMBER>
END
 # 발언번호
 my($j, $i);
 for($i = 0; $i < $HlbbsMax; $i++) {
	$j = $i + 1;
	out("<OPTION VALUE=$i>$j\n");
 }
 out(<<END);
</SELECT>
<INPUT TYPE="submit" VALUE="삭제" NAME="LbbsButtonDL$HcurrentID">
<INPUT TYPE="hidden" NAME=JAVAMODE VALUE="$HjavaMode">
</TD>
</TR>
</TABLE>
</FORM>
</CENTER>
END
}

#----------------------------------------------------------------------
# 명령 모드
#----------------------------------------------------------------------
sub commandJavaMain {
 # id에서 섬을 가져옴
 $HcurrentNumber = $HidToNumber{$HcurrentID};
 my($island) = $Hislands[$HcurrentNumber];
 $HcurrentName = $island->{'name'};

 # 비밀번호
 if(!checkPassword($island->{'password'},$HinputPassword)) {
	# password 오류
	unlock();
	tempWrongPassword();
	return;
 }

 # 모드에서 분기
 my($command) = $island->{'command'};
	for($i = 0; $i < $HcommandMax; $i++) {
		# 명령 등록
		$HcommandComary =~ s/([0-9]*) ([0-9]*) ([0-9]*) ([0-9]*) ([0-9]*) //;
	 if($1 == 0) {
			$1 = 41;
		}
		$command->[$i] = {
			'kind' => $1,
			'x' => $2,
			'y' => $3,
			'arg' => $4,
			'target' => $5
		};
	}
	tempCommandAdd();
	# 데이터 쓰기
 writeIslandsFile($HcurrentID);

 # owner mode 로
 ownerMain();
}

#----------------------------------------------------------------------
# 지도 표시
#----------------------------------------------------------------------
sub islandMapJava {
 my($mode) = @_;
 my($island);
 $island = $Hislands[$HcurrentNumber];

 # 지형, 지형 값을 가져옴
 my($land) = $island->{'land'};
 my($landValue) = $island->{'landValue'};
 my($l, $lv);

 out(<<END);
<CENTER><TABLE BORDER><TR><TD>
END
 # 명령 가져오기
 my($command) = $island->{'command'};
 my($com, @comStr, $i);
 if($HmainMode eq 'owner') {
	for($i = 0; $i < $HcommandMax; $i++) {
	 my($j) = $i + 1;
	 $com = $command->[$i];
	 if($com->{'kind'} < 21) {
		$comStr[$com->{'x'}][$com->{'y'}].=
		 " [${j}]$HcomName[$com->{'kind'}]";
	 }
	}
 }

 # 좌표(상)을 출력
 out("<IMG SRC=\"xbar.gif\" width=400 height=16><BR>");

 # 각 지형및 줄바꿈을 출력
 my($x, $y);
 for($y = 0; $y < $HislandSize; $y++) {
	# 짝 수행이면 번호 출력
 if(($y % 2) == 0) {
	 out("<IMG SRC=\"space${y}.gif\" width=16 height=32>");
	}

	# 각 지형을 출력
	for($x = 0; $x < $HislandSize; $x++) {
	 $l = $land->[$x][$y];
	 $lv = $landValue->[$x][$y];
	 landStringJava($l, $lv, $x, $y, $comStr[$x][$y], $mode);
	}

	# 홀 수행이면 번호 출력
 if(($y % 2) == 1) {
	 out("<IMG SRC=\"space${y}.gif\" width=16 height=32>");
	}

	# 줄바꿈을 출력
	out("<BR>");
 }
 out("</TD></TR></TABLE></CENTER>\n");
}

#----------------------------------------------------------------------
# MAP아이콘 표시
#----------------------------------------------------------------------
sub landStringJava {
 my($l, $lv, $x, $y, $comStr,$mode) = @_;
 my($point) = "($x,$y)";
 my($image, $alt);

 if($l == $HlandSea) {

	if($lv == 1) {
	 # 얕은 바다
	 $image = 'land14.gif';
	 $alt = '바다(얕은 바다)';
 } else {
 # 바다
	 $image = 'land0.gif';
	 $alt = '바다';
 }
 } elsif($l == $HlandWaste) {
	# 황무지
	if($lv == 1) {
	 $image = 'land13.gif'; # 착탄 지점
	 $alt = '황무지';
	} else {
	 $image = 'land1.gif';
	 $alt = '황무지';
	}
 } elsif($l == $HlandPlains) {
	# 평지
	$image = 'land2.gif';
	$alt = '평지';
 } elsif($l == $HlandForest) {
	# 숲
	if($mode == 0) {
	 # 관광객에게는 목장 수를 숨김
	 $image = 'land6.gif';
	 $alt = '숲';
	} else {
	 $image = 'land6.gif';
	 $alt = "숲(${lv}$HunitTree)";
	}
 } elsif($l == $HlandTown) {
	# 마을
	my($p, $n);
	if($lv < 30) {
	 $p = 3;
	 $n = '마을';
	} elsif($lv < 100) {
	 $p = 4;
	 $n = '마을';
	} else {
	 $p = 5;
	 $n = '도시';
	}

	$image = "land${p}.gif";
	$alt = "$n(${lv}$HunitPop)";
 } elsif($l == $HlandFarm) {
	# 농장
	$image = 'land7.gif';
	$alt = "농장(${lv}0${HunitPop}규모)";
 } elsif($l == $HlandFactory) {
	# 공장
	$image = 'land8.gif';
	$alt = "공장(${lv}0${HunitPop}규모)";
 } elsif($l == $HlandBase) {
	if($mode == 0) {
	 # 관광객의 경우 숲인 척
	 $image = 'land6.gif';
	 $alt = '숲';
	} else {
	 # 미사일 기지
	 my($level) = expToLevel($l, $lv);
	 $image = 'land9.gif';
	 $alt = "미사일 기지 (레벨 ${level}/경험치 $lv)";
	}
 } elsif($l == $HlandDefence) {
	if($mode == 0) {
	 # 관광객의 경우 숲인 척
	 $image = 'land6.gif';
	 $alt = '숲';
	} else {
		# 방위 시설
		$image = 'land10.gif';
		$alt = '방위 시설';
	}
 } elsif($l == $HlandHaribote) {
	# 가짜 시설
	$image = 'land10.gif';
	if($mode == 0) {
	 # 관광객에게는 방위 시설처럼 표시
	 $alt = '방위 시설';
	} else {
	 $alt = '가짜 시설';
	}
 }

 if($mode == 1) {
 out(qq#<A HREF="JavaScript:void(0);" onclick="ps(event,$x,$y)" #);
 out(qq#onMouseOver="set_com($x, $y, '$point $alt'); return true;" onMouseOut="window.status = '';">#);
 }elsif($HmainMode eq 'landmap') {
 out(qq#<A HREF="JavaScript:void(0);" onclick="ps(event,$x,$y)" #);
 out(qq#onMouseOver="window.status = '$point $alt $comStr'; return true;" onMouseOut="window.status = '';">#);
	}else{
 out(qq#<A HREF="JavaScript:void(0);" #);
 out(qq#onMouseOver="window.status = '$point $alt $comStr'; return true;" onMouseOut="window.status = '';">#);
	}
 out("<IMG SRC=\"$image\" ALT=\"$point $alt $comStr\" TITLE=\"$point $alt $comStr\" width=32 height=32 BORDER=0></A>");
}

#----------------------------------------------------------------------
# 관광 모드
#----------------------------------------------------------------------
sub printIslandJava {
 # 개방
 unlock();

 # id에서 섬 번호를 가져옴
 $HcurrentNumber = $HidToNumber{$HcurrentID};

 # 왠지그 섬이 없는 경우
 if($HcurrentNumber eq '') {
	tempProblem();
	return;
 }

 # 이름 가져오기
 $HcurrentName = $Hislands[$HcurrentNumber]->{'name'};

out(<<END);
<SCRIPT Language="JavaScript">
<!--

isIE4 = (navigator.appVersion.charAt(0)>=4 && (navigator.appVersion).indexOf("MSIE") != -1);
isNN4 = (navigator.appVersion.charAt(0)>=4 && (navigator.appName).indexOf("Netscape")!=-1);
isNN6 = (document.getElementById);
var mouseX = 0;
var mouseY = 0;

window.document.onmouseup = menuclose;
document.onmousedown = getMouseData;
function ps(e, x, y) {
	if(typeof y == "undefined") {
		y = x;
		x = e;
		e = window.event;
	}
	getMouseData(e);
	window.opener.document.myForm.POINTX.options[x].selected = true;
	window.opener.document.myForm.POINTY.options[y].selected = true;
	showMenu();
	return true;
}
function showMenu() {
	if((isNN6) && !(isIE4)){
	 document.getElementById("menu").style.left = mouseX + "px";
	 document.getElementById("menu").style.top = (mouseY - 20) + "px";
 document.getElementById("menu").style.visibility = "visible";
 document.getElementById("menu").style.display = "block";
	} else if(isNN4) {
 document.menu.left = mouseX; // 가로
 document.menu.top = mouseY - 15; // 세로
 document.menu.visibility = "show";
	} else if(isIE4) {
	 getMouseData(window.event);
	 menu.style.visibility = 'visible';
	 menu.style.display = 'block';
	 menu.style.left= mouseX + "px";
	 menu.style.top = (mouseY - 20) + "px";
 }
}

function menuclose() {
 if(isNN6) {
 document.getElementById("menu").style.display = "none";
 } else if(isNN4) {
	document.menu.visibility = "hide";
 } else {
	window["menu"].style.display = "none";
 }
}

function getMouseData(e) {
	e = e || window.event;
	if(!e) { return true; }
	if(typeof e.pageX == "number") {
		mouseX = e.pageX;
		mouseY = e.pageY;
	} else {
		mouseX = e.clientX + (document.documentElement.scrollLeft || document.body.scrollLeft || 0);
		mouseY = e.clientY + (document.documentElement.scrollTop || document.body.scrollTop || 0);
	}
	return true;
}
function cominput(kind) {
 window.opener.cominput(6, kind, $HcurrentID);
 menuclose();
}

function ShowMsg(n){
	window.status = n;
}
//-->
</SCRIPT>

<DIV ID="menu" STYLE="position:absolute; visibility:hidden;">
<TABLE BORDER=0 BGCOLOR=#ccffcc>
<TR><TD NOWRAP>

END
 local($kind, $cost, $s, $tak);
 $tak = $HcommandTotal - 3;
 for($i = 0; $i < $tak; $i++) {
	$kind = $HcomList[$i];
	if(!($kind>= 30 and $kind <= 35)){ next; }
	$cost = $HcomCost[$kind];
	if($cost == 0) {
	 $cost = '무료'
	} elsif($cost < 0) {
	 $cost = - $cost;
	 $cost.= $HunitFood;
	} else {
	 $cost.= $HunitMoney;
	}
if($i == 7){ out("<HR>"); }
	out("<a href=\"javascript:void(0);\" onClick=\"cominput(${kind})\" STYlE=\"text-decoration:none\">$HcomName[$kind]($cost)<BR></A>\n");
 }

 out(<<END);
<HR>
<a href="Javascript:void(0);" onClick="menuclose()" STYlE="text-decoration:none">메뉴를 닫기</A>
</TD></TR>
</TABLE>
</DIV>
<center>${HtagBig_}${HtagName_}'${HcurrentName} 섬'${H_tagName}${H_tagBig}
</center>
END
 islandMapJava(0); # 섬 지도, 관광 모드
 landStringFlash(); # 의사MAP데이터 표시

 # 최근 상황
 tempRecent(0);
 out(<<END);
<HR></BODY></HTML>
END
}

#----------------------------------------------------------------------
# 의사MAP데이터 생성
#----------------------------------------------------------------------
sub landStringFlash {
 my($island);
 $island = $Hislands[$HcurrentNumber];
 my($land) = $island->{'land'};
 my($landValue) = $island->{'landValue'};
 my($l, $lv);
 my($code) = "";
 my($befor) = "a";
	my($Count) = 0;
	my($Comp) = "";
	my($ret) = "";

 # 각 지형을 출력
 my($x, $y);
 for($y = 0; $y < $HislandSize; $y++) {

	# 각 지형을 출력
	for($x = 0; $x < $HislandSize; $x++) {
	 $l = $land->[$x][$y];
	 $lv = $landValue->[$x][$y];
	 $code = landFlashData($l, $lv);

		if ($code eq $befor) {
			$Count++;
		} else {
			$Comp.= $befor;
			if( $Count != 0){
				$Comp.= ($Count - 1);
			}
			$Count = 0;
			$befor = $code;
		}
	}
 	}
	if($befor ne "a"){
		$Comp.= $befor;
		if( $Count != 0){
			$Comp += ($Count - 1);
		}
	}
	$Comp.= "\@";
	$Comp = substr($Comp,1);

 # 각 지형을 출력
	my($Compjs) = "";
	for($x = 0; $x < $HislandSize; $x++) {

	# 각 지형을 출력
 for($y = 0; $y < $HislandSize; $y++) {
	 $l = $land->[$x][$y];
	 $lv = $landValue->[$x][$y];
	 $code = landFlashData($l, $lv);
		$Compjs.= $code;
	}
 	}

 out(<<END);
<CENTER><FORM>
의사MAP작성도구용 데이터(FLASH 판)<BR>
<TEXTAREA NAME="FLASH" cols="50" rows="3">$Comp</TEXTAREA><br>
<A HREF="http://www.din.or.jp/~mkudo/hako/flash/hako-map.html">
의사MAP작성도구(FLASH 판)을 온라인으로 시작</a><P>
의사MAP작성도구용 데이터(JavaScript판)<BR>
<TEXTAREA NAME="FLASH" cols="50" rows="4">$Compjs</TEXTAREA><br>
<A HREF="http://www.din.or.jp/~mkudo/hako/javascript/map.html">
의사MAP작성도구(JavaScript판)을 온라인으로 시작</a><BR><BR><BR>
<A HREF="http://www.din.or.jp/~mkudo/hako/">
의사MAP작성도구(JAVA·FLASH 판)을 다운로드하기</a><p>
</FORM>
</CENTER>
END

}

sub landFlashData {
 my($l, $lv) = @_;
 my($flash_data);

 if($l == $HlandSea) {
	 # 얕은 바다
		if($lv == 1) {
			$flash_data = "o";
 } else {
 # 바다
			$flash_data = "a";
 }
 } elsif($l == $HlandWaste) {
		# 황무지
		if($lv == 1) {
	 	# 착탄 지점
			$flash_data = "n";
		} else {
			$flash_data = "b";
		}
 } elsif($l == $HlandPlains) {
		# 평지
		$flash_data = "c";
 } elsif($l == $HlandForest) {
		# 숲
		$flash_data = "g";
 } elsif($l == $HlandTown) {
		if($lv < 30) {
	 	# 마을
			$flash_data = "d";
		} elsif($lv < 100) {
	 	# 마을
			$flash_data = "e";
		} else {
	 	# 도시
			$flash_data = "f";
		}
 } elsif($l == $HlandFarm) {
		# 농장
		$flash_data = "h";
 } elsif($l == $HlandFactory) {
		# 공장
		$flash_data = "i";
 } elsif($l == $HlandBase) {
	 # 미사일 기지는 숲이 됨
		#$flash_data = "j";
		$flash_data = "g";
 } elsif($l == $HlandDefence) {
		# 방위 시설
		#$flash_data = "k";
		# 방위 시설은 숲이 됨
		$flash_data = "g";
 } elsif($l == $HlandHaribote) {
		# 가짜 시설
		$flash_data = "k";
 } else {
		# 기타
		$flash_data = "b";
 }
	return $flash_data;
}


# 헤더
sub tempHeaderJava {

my($HimgFlag) = 0;
 $baseIMG = $imageDir;
 $HimgFlag = 1;
	$baseIMG =~ s/데스크톱/데스크톱/g;

 out(<<END);
Content-type: text/html; charset=UTF-8

<HTML>
<HEAD>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
<TITLE>
$Htitle
</TITLE>
<STYLE type="text/css">
<!--
a:link { color:#3300CC }
a:visited { color:#3300CC }
a:active { color:#FF0000 }
a:hover { color:#FF0000 }
small { font-size: 9pt}
-->
</STYLE>
<BASE HREF="$baseIMG/">
</HEAD>
$Body<nobr>
<A HREF="http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html">모형정원 제도 스크립트 배포처</A>/
<A HREF="http://appoh.execweb.cx/hakoniwa/">모형정원 JavaScript판 배포처</A>/
<A HREF="http://www.din.or.jp/~mkudo/hako/">지도 작성 도구 배포처</A>/ <br>
<A HREF="$bbs">$bbsname</A>/
<A HREF="$toppage">톱 페이지</A>/<HR>
END
}


1;

