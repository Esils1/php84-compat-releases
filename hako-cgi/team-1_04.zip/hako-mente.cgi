#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}
# ↑은서버에 맞게 변경해 주세요.

#----------------------------------------------------------------------
# 모형정원 제도 ver2.30
# 관리 도구(ver1.01)
# 사용 조건과 사용 방법은 hako-readme.txt 파일을 참조해 주세요
#
# 모형정원 제도의 페이지: http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html
#----------------------------------------------------------------------
# 모형정원 팀 토너먼트
# 관리 도구
# $Id: hako-mente.cgi 2 2003-07-02 03:09:48Z gaba $

require './hako-ini.cgi';

# ――――――――――――――――――――――――――――――
# 각종 설정 값
# ――――――――――――――――――――――――――――――


# 이 파일
my($thisFile) = './hako-mente.cgi';


# use Time::Local을 사용할 수 없는 환경에서는 'use Time::Local' 줄을 삭제해 주세요.
# 단, 갱신 시간의 변경은 '초 지정에서 변경'만불가능해집니다.
use Time::Local;

# ――――――――――――――――――――――――――――――
# 설정 항목은 여기까지
# ――――――――――――――――――――――――――――――

# 각종변수
my($mainMode);
my($inputPass);
my($deleteID);
my($currentID);
my($ctYear);
my($ctMon);
my($ctDate);
my($ctHour);
my($ctMin);
my($ctSec);

print <<END;
Content-type: text/html; charset=UTF-8

<HTML>
<HEAD><META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
<TITLE>모형정원 제도 2 관리 도구</TITLE>
</HEAD>
<BODY>
END

cgiInput();

if($mainMode eq 'delete') {
 if(passCheck()) {
	deleteMode();
 }
} elsif($mainMode eq 'current') {
 if(passCheck()) {
	currentMode();
 }
} elsif($mainMode eq 'time') {
 if(passCheck()) {
	timeMode();
 }
} elsif($mainMode eq 'stime') {
 if(passCheck()) {
	stimeMode();
 }
} elsif($mainMode eq 'new') {
 if(passCheck()) {
	newMode();
 }
}
mainMode();

print <<END;
</FORM>
</BODY>
</HTML>
END

sub myrmtree {
 my($dn) = @_;
 opendir(DIN, "$dn/");
 my($fileName);
 while($fileName = readdir(DIN)) {
	unlink("$dn/$fileName");
 }
 closedir(DIN);
 rmdir($dn);
}

sub currentMode {
 myrmtree "${HdirName}";
 mkdir("${HdirName}", $HdirMode);
 opendir(DIN, "${HdirName}.bak$currentID/");
 my($fileName);
 while($fileName = readdir(DIN)) {
	fileCopy("${HdirName}.bak$currentID/$fileName", "${HdirName}/$fileName");
 }
 closedir(DIN);
 open(FIN, "${HdirName}/teams.dat");
	while($name = <FIN>) {
	 chomp($name);
	 $id = int(<FIN>);
	 $dummy = <FIN>;
	 $password = <FIN>;
	 chomp($password);
	 $dummy = <FIN>;
	 $dummy = <FIN>;
	 $dummy = <FIN>;
	 $dummy = <FIN>;
	 $dummy = <FIN>;
	 $dummy = <FIN>;
	 $dummy = <FIN>;
	 $dummy = <FIN>;
	 $dummy = <FIN>; # 보상금용 턴 수
	 $fightcgi.= "${id}\n${name}\n${password}\n";
#	 chop(@fightcgi);
	}
 close(FIN);

 open(DAT, ">>team.tmp.cgi");
	print DAT "$fightcgi";
 close(DAT);

 rename ("team.tmp.cgi", "team.cgi");

}

sub deleteMode {
 if($deleteID eq '') {
	myrmtree "${HdirName}";
 } else {
	myrmtree "${HdirName}.bak$deleteID";
 }
 unlink "hakojimalockflock";
}

sub newMode {
 mkdir($HdirName, $HdirMode);

 # 현재의 시간을 가져옴
 my($now) = time;
 $now = $now - ($now % ($HunitTime));
 $now += $HunitTime;
 open(OUT, ">$HdirName/hakojima.dat"); # 파일을 열기
 print OUT "0\n"; # 턴 수1
 print OUT "$now\n"; # 시작 시간
 print OUT "0\n"; # 섬의 수
 print OUT "1\n"; # 다음에 할당할 ID
 print OUT "$teamNum\n"; # 팀 수
 print OUT "$HdevRepTurn\n";# 갱신 횟수
 print OUT "0\n"; # 전환에 턴
 print OUT "0\n"; # 현재의 전투 모드
 print OUT "1\n"; # 몇회전목카

 # 파일을 닫기
 close(OUT);
 open(DOUT, ">$HdirName/teams.dat"); # 파일을 열기
 my($passkey) = rand(1200) + 1;
 for($i= 1 ;$i <= $teamNum;$i++) {
	print DOUT "팀${i}:명칭미설정\n";
	print DOUT "$i\n";
	print DOUT "\n";
	$tpass[$i] = crypt($i * $passkey,hp);
	print DOUT "$tpass[$i]\n";
	for($f= 4 ;$f < $teamFileNum;$f++) {
	 print DOUT "\n";
	}
 }

 # 파일을 닫기
 close(DOUT);

 open(TOUT, ">team.cgi");
	for($i= 1 ;$i <= $teamNum;$i++) {
	 print TOUT "$i\n";
	 print TOUT "팀${i}:명칭미설정\n";
	 print TOUT "$tpass[$i]\n";
	}
 close(TOUT);

 for ($f = 1;$f <= $teamNum;$f++) {
	open(BOUT, ">${teambbs}/${f}.cgi");
	 print BOUT "0\n";
	close(BOUT);
	open(BOUT, ">${teambbs}/chat/${f}.cgi");
	close(BOUT);

 }
}

sub timeMode {
 $ctMon--;
 $ctYear -= 1900;
 $ctSec = timelocal($ctSec, $ctMin, $ctHour, $ctDate, $ctMon, $ctYear);
 stimeMode();
}

sub stimeMode {
 my($t) = $ctSec;
 open(IN, "${HdirName}/hakojima.dat");
 my(@lines);
 @lines = <IN>;
 close(IN);

 $lines[1] = "$t\n";

 open(OUT, ">${HdirName}/hakojima.dat");
 print OUT @lines;
 close(OUT);
}

sub mainMode {
 opendir(DIN, "./");

 print <<END;
<FORM action="$thisFile" method="POST">
<H1>모형정원 제도 2 관리 도구(팀토너먼트)</H1>
<B> 비밀번호:</B><INPUT TYPE=password SIZE=32 MAXLENGTH=32 NAME=PASSWORD></TD>
END

 # 현재 데이터
 if(-d "${HdirName}") {
	dataPrint("");
 } else {
	print <<END;
 <HR>
 <INPUT TYPE="submit" VALUE="새 데이터 만들기" NAME="NEW">
END
 }

 # 백업 데이터
 my($dn);
 while($dn = readdir(DIN)) {
	if($dn =~ /^${HdirName}.bak(.*)/) {
	 dataPrint($1);
	}
 }
 closedir(DIN);
}

# 표시 모드
sub dataPrint {
 my($suf) = @_;

 print "<HR>";
 if($suf eq "") {
	open(IN, "${HdirName}/hakojima.dat");
	print "<H1>현재 데이터</H1>";
 } else {
	open(IN, "${HdirName}.bak$suf/hakojima.dat");
	print "<H1>백업$suf</H1>";
 }

 my($lastTurn);
 $lastTurn = <IN>;
 my($lastTime);
 $lastTime = <IN>;

 my($timeString) = timeToString($lastTime);

 print <<END;
 <B>턴$lastTurn</B><BR>
 <B>최종 갱신 시간</B>:$timeString<BR>
 <B>최종 갱신 시간(초 단위 표시)</B>:1970년1월1일에서$lastTime 초<BR>
 <INPUT TYPE="submit" VALUE="이 데이터 삭제" NAME="DELETE$suf">
END

 if($suf eq "") {
	my($sec, $min, $hour, $date, $mon, $year, $day, $yday, $dummy) =
	 localtime($lastTime);
	$mon++;
	$year += 1900;

	print <<END;
 <H2>최종 갱신 시간의 변경</H2>
 <INPUT TYPE="text" SIZE=4 NAME="YEAR" VALUE="$year">년
 <INPUT TYPE="text" SIZE=2 NAME="MON" VALUE="$mon">월
 <INPUT TYPE="text" SIZE=2 NAME="DATE" VALUE="$date">일
 <INPUT TYPE="text" SIZE=2 NAME="HOUR" VALUE="$hour"> 시
 <INPUT TYPE="text" SIZE=2 NAME="MIN" VALUE="$min">분
 <INPUT TYPE="text" SIZE=2 NAME="NSEC" VALUE="$sec">초
 <INPUT TYPE="submit" VALUE="변경" NAME="NTIME"><BR>
 1970년1월1일에서<INPUT TYPE="text" SIZE=32 NAME="SSEC" VALUE="$lastTime">초
 <INPUT TYPE="submit" VALUE="초지정에서 변경" NAME="STIME">

END
 } else {
	print <<END;
	<INPUT TYPE="submit" VALUE="이 데이터를 현재 데이터로 사용" NAME="CURRENT$suf">
END
 }
}

sub timeToString {
 my($sec, $min, $hour, $date, $mon, $year, $day, $yday, $dummy) =
	localtime($_[0]);
 $mon++;
 $year += 1900;

 return "${year}년 ${mon}월 ${date}일 ${hour} 시 ${min}분 ${sec}초";
}

# CGI 읽기
sub cgiInput {
 my($line);

 # 입력을 받음
 $line = <>;
 $line =~ tr/+/ /;
 $line =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;

 if($line =~ /DELETE([0-9]*)/) {
	$mainMode = 'delete';
	$deleteID = $1;
 } elsif($line =~ /CURRENT([0-9]*)/) {
	$mainMode = 'current';
	$currentID = $1;
 } elsif($line =~ /NEW/) {
	$mainMode = 'new';
 } elsif($line =~ /NTIME/) {
	$mainMode = 'time';
	if($line =~ /YEAR=([0-9]*)/) {
	 $ctYear = $1;
	}
	if($line =~ /MON=([0-9]*)/) {
	 $ctMon = $1;
	}
	if($line =~ /DATE=([0-9]*)/) {
	 $ctDate = $1;
	}
	if($line =~ /HOUR=([0-9]*)/) {
	 $ctHour = $1;
	}
	if($line =~ /MIN=([0-9]*)/) {
	 $ctMin = $1;
	}
	if($line =~ /NSEC=([0-9]*)/) {
	 $ctSec = $1;
	}
 } elsif($line =~ /STIME/) {
	$mainMode = 'stime';
	if($line =~ /SSEC=([0-9]*)/) {
	 $ctSec = $1;
	}
 }

 if($line =~ /PASSWORD=([^\&]*)\&/) {
	$inputPass = $1;
 }
}

# 파일의 복사
sub fileCopy {
 my($src, $dist) = @_;
 open(IN, $src);
 open(OUT, ">$dist");
 while(<IN>) {
	print OUT;
 }
 close(IN);
 close(OUT);
}

# 경로 확인
sub passCheck {
 if($inputPass eq $masterPassword) {
	return 1;
 } else {
	print <<END;
 <FONT SIZE=7> 비밀번호가 다릅니다.</FONT>
END
 return 0;
 }
}

1;
