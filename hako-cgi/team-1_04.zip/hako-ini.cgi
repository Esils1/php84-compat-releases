#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}
#----------------------------------------------------------------------
# 각종 설정 값
# 아래 설정 값을 서버 환경에 맞게 변경해 주세요.
#----------------------------------------------------------------------
# 모형정원 팀 토너먼트
# 설정 파일
# $Id: hako-ini.cgi 2 2003-07-02 03:09:48Z gaba $

#----------------------------------------------------------------------
# 아래는 반드시 설정해야 하는 항목입니다
#----------------------------------------------------------------------

# 게임 제목 문자열
$Htitle = '모형정원 팀 토너먼트';

# 마스터 비밀번호
# 이 비밀번호는, 모든 섬의 비밀번호를 대신 사용할 수 있습니다.
# 예를 들어,'다른 섬의 비밀번호 변경'등도 할 수 있습니다.
$masterPassword = '1064';

# 특수 비밀번호
# 이 비밀번호로 '이름 변경'을 실행하면, 그 섬의 자금, 식량이 최댓값이 됩니다.
# (실제로 이름이 변경될 필요는 없습니다.)
$HspecialPassword = 'special';


# 이 파일을 설치할 디렉터리
# $baseDir = 'http://서버/디렉터리';
#
# 예)
# http://cgi2.bekkoame.ne.jp/cgi-bin/user/u5534/hakoniwa/hako-main.cgi
# 처럼 배치한 경우,
# $baseDir = 'http://cgi2.bekkoame.ne.jp/cgi-bin/user/u5534/hakoniwa';
# 지합니다. 끝에 슬래시(/)는 붙이지 않습니다.

my($scriptBaseScheme) = (($ENV{'HTTPS'} || '') =~ /^(on|1)$/i) ? 'https' : 'http';
my($scriptBaseHost) = $ENV{'HTTP_HOST'} || $ENV{'SERVER_NAME'} || 'localhost';
if (!$ENV{'HTTP_HOST'} && $ENV{'SERVER_PORT'} && !(($scriptBaseScheme eq 'http' && $ENV{'SERVER_PORT'} == 80) || ($scriptBaseScheme eq 'https' && $ENV{'SERVER_PORT'} == 443))) {
 $scriptBaseHost.= ":$ENV{'SERVER_PORT'}";
}
my($scriptBasePath) = $ENV{'SCRIPT_NAME'} || '';
$scriptBasePath =~ s{/[^/]*$}{};
$baseDir = "$scriptBaseScheme://$scriptBaseHost$scriptBasePath";


# 이미지 파일을 둘 디렉터리
# $imageDir = 'http://서버/디렉터리';
# $imageDir = $baseDir;
$imageDir = 'https://esils.com/BBdata/hakoimg';

# 이미지 경로 설정의 설명페이지
$imageExp = "${baseDir}/imgexp/index.html";

# 문자 변환 라이브러리 위치

# UTF-8 환경에서는 외부 문자 변환 라이브러리를 사용하지 않습니다.
# UTF-8 환경에서는 외부 문자 변환 라이브러리를 사용하지 않습니다.
# 일반적으로 0755이면 좋지만,0777,0705,0704등에서 없으면 사용 불가는 서버도 있습니다
$HdirMode = 0754;

# 데이터 디렉터리 이름
# 여기에서 설정한 이름의 디렉터리 아래에 데이터가 저장됩니다.
# 기본값에서는'data'로 되어 있지만, 보안상
# 보안을 위해 다른 이름으로 변경해 주세요.
$HdirName = 'data';

# 관리자 이름
$adminName = '관리자';

# 관리자의 메일 주소
$email = '***@********.***';

# 게시판의 명칭
$bbsname = '게시판';

# 게시판 주소
$bbs = "${baseDir}/bbs/bbs.cgi";

# 투명이미지의 위치
$cleangif = "${baseDir}/clean.gif";

# 팀용 게시판 디렉터리 이름
$teambbs = 'bbs';

# 홈페이지 주소
$toppage = "${baseDir}/";

# 데이터 쓰기 권한

# 잠금 방식
# 1 디렉터리
# 2 시스템 콜(가능하면 이 방식을 권장합니다)
# 3 심볼릭 링크
# 4 일반 파일(권장하지 않음)
$lockMode = 1;

# (주)
# 4을 선택하는 경우에는,'key-free'라는, 권한 666의 빈 파일을,
# 이 파일과 같은 위치에 배치해 주세요.

#----------------------------------------------------------------------
# 반드시 설정하는 부분은 이상
#----------------------------------------------------------------------

#----------------------------------------------------------------------
# 아래는 필요에 따라 설정하는 항목입니다
#----------------------------------------------------------------------
#----------------------------------------
# 게임의 진행야 파일등
#----------------------------------------
# 1팀의 인원 수
$HmenberCount = 3;

# 예선 기간 턴 수
$HyosenTurn = 48;

# 개발 기간 턴 수
$HdevTurn = 24;

# 개발(예선) 기간을 몇 턴 단위로 일괄 진행할지
$HdevRepTurn = 1;

# 전투 기간 턴 수
$HfigTurn = 12;

# 전투 기간을 몇 턴 단위로 일괄 진행할지
$HfigRepTurn = 3;

# 개발(예선)기간의 갱신 시간
$HunitTime = 10800; # 3 시간

# 전투 기간의 갱신 시간
$HfightTime = 86400; # 24 시간

# 전투 기간종료후의 인타바루
$HinterTime = 97200; # 27 시간

# 이상종료 기준 시간
# (잠금 후 몇 초 뒤 강제 해제할지)
$unlockTime = 60;

# 섬의 최대 수
$HmaxIsland = 60;

# 톱 페이지에 표시할 로그 턴 수
$HtopLogTurn = 1;

# 로그 파일 유지 턴 수
$HlogMax = 8;

# 백업을 몇 턴오키에취는 가
$HbackupTurn = 3;

# 백업을 몇 회분 남음습니까
$HbackupTimes = 3;

# 발견 로그유지 줄 수
$HhistoryMax = 10;

# 포기 명령 자동 입력 턴 수
$HgiveupTurn = 5;

# 포기후의 코멘트
$HgiveupComment = '<FONT COLOR=RED>팀 위임 임시!</FONT>';

# 명령 입력 한계 수
# (게임이 시작된 뒤 변경하면 데이터 파일 호환성이 없어집니다.)
$HcommandMax = 30;

# 로컬 게시판 행 수 사용 여부(0:사용하지 않음,1:사용함)
$HuseLbbs = 1;

# 로컬 게시판 줄 수
$HlbbsMax = 8;

# 섬 크기
# (변경할 수 없일 수도)
$HislandSize = 12;

# 팀 수
$teamNum = 20;

# 예선통과 팀 수
$yteamNum = 16;

# 1팀당 데이터 줄 수입니다. 일반적으로 이 값 그대로 사용하면 됩니다.
$teamFileNum = 13;

# 다른 사람이 자금을 볼 수 없게 할지
# 0 보이지 않음
# 1 표시 가능
# 2 100의 위에서 반올림
$HhideMoneyMode = 2;

# 비밀번호 암호화(0: 암호화하지 않음, 1: 암호화함)
$cryptOn = 1;

# 디버그 모드(1이면 '턴 진행' 버튼을 사용할 수 있음)
$Hdebug = 0;

#----------------------------------------
# 자금, 식량등의 설정 값
#----------------------------------------
# 초기 자금
$HinitialMoney = 2000;

# 초기 식량
$HinitialFood = 1000;

# 초기면적
$HlandSizeValue = 32;

# 초기얕은 바다의 수
$HseaNum = 20;

#----------------------------------------
# 자금, 식량등의 설정 값와 단위
#----------------------------------------
# 자금의 단위
$HunitMoney = '억 엔';

# 식량의 단위
$HunitFood = '00톤';

# 인구의 단위
$HunitPop = '00인';

# 면적의 단위
$HunitArea = '00만 평';

# 나무 수의 단위
$HunitTree = '00본';

# 목재 단위당 판매 수입
$HtreeValue = 5;

# 이름 변경의 비용
$HcostChangeName = 0;

# 인구 1단위당 식량 소비량
$HeatenFood = 0.2;

# 초기 미사일 기지의 수
$HlandFirstMiss = 0;

# 일괄 자동 땅고르기용
# 몇 번째 황무지부터 할인할지(이 수 다음의 황무지부터)
$precheap = 10;
# 그 시의 할인률(8로 설정하면 20% 할인이라는 뜻입니다)
$precheap2 = 8;

# 1턴에서 목의 늘어나면개 수
$HtreeUp = 2;

# 자금 조달이 몇 턴 계속되면 인구 증가를 중단할까요?
$HstopAddPop = 3;

# 팀용 각상의 가져오기규모
$HprizePoint[1] = '5000'; # 번영상
$HprizePoint[2] = '10000'; # 초과 번영상
$HprizePoint[3] = '15000'; # 궁극번영상
$HprizePoint[4] = '500'; # 평화상
$HprizePoint[5] = '800'; # 초과 평화상
$HprizePoint[6] = '1500'; # 궁극평화상
$HprizePoint[7] = '1000'; # 재난상
$HprizePoint[8] = '2000'; # 초과 재난상
$HprizePoint[9] = '3000'; # 궁극재난상


1;
