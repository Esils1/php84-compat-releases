#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}
#----------------------------------------------------------------------
# 모형정원 제도 ver2.30
# 지도 모드 모듈(ver1.00)
# 사용 조건과 사용 방법은 hako-readme.txt 파일을 참조해 주세요
#
# 모형정원 제도의 페이지: http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html
#----------------------------------------------------------------------
# 모형정원 토너먼트 2
# 지도 모드 모듈
# $Id: hako-map.cgi 54 2004-11-30 09:20:18Z takayama $

#----------------------------------------------------------------------
# 관광 모드
#----------------------------------------------------------------------
# 메인
sub printIslandMain {
	# 개방
	unlock();

	# id에서 섬 번호를 가져옴
	$HcurrentNumber = $HidToNumber{$HcurrentID};

	# 왠지그 섬이 없는 경우
	if($HcurrentNumber eq '') {
		tempProblem();
		return;
	}

	# 이름 가져오기
	$HcurrentName = $Hislands[$HcurrentNumber]->{'name'};

	# 관광 화면
	tempPrintIslandHead();	# 수 있도록 말로!!
	islandInfo();			# 섬의 정보
	islandMap(0) if(!$easy_mode); # 섬 지도, 관광 모드

	# ○○섬 로컬 게시판
	if($HuseLbbs) {
		tempLbbsHead();		# 로컬 게시판
		tempLbbsInput();	# 작성 양식
		tempLbbsContents();	# 게시판내용
	}

	# 최근 상황 간이 관광객 통신의 경우 표시하지 않음
	tempRecent(0) if(!$easy_mode);
}

#----------------------------------------------------------------------
# 개발 모드
#----------------------------------------------------------------------
# 메인
sub ownerMain {
	# 개방
	unlock();

	# 모드를 명시
	$HmainMode = 'owner';

	# id에서 섬을 가져옴
	$HcurrentNumber = $HidToNumber{$HcurrentID};
	my($island) = $Hislands[$HcurrentNumber];
	$HcurrentName = $island->{'name'};

	# 비밀번호
	if(!checkPassword($island->{'password'},$HinputPassword)) {
		# password 오류
		tempWrongPassword();
		return;
	}

 # 개발 화면
 if($HjavaMode eq 'java') {
		write_access_log("JS"); # 접속 로그
		tempOwnerJava();	# 'JavaScript개발계획'
 } else {
		write_access_log("NM"); # 접속 로그
		tempOwner();		# '일반 모드개발계획'
 }

 # ○○섬 로컬 게시판
 if($HuseLbbs) {
		tempLbbsHead();			# 로컬 게시판
		tempLbbsInputOW();		# 작성 양식
		tempLbbsContents();		# 게시판내용
 }

	# 최근 상황
	tempRecent(1);
}

#----------------------------------------------------------------------
# 명령 모드
#----------------------------------------------------------------------
# 메인
sub commandMain {
	# id에서 섬을 가져옴
	$HcurrentNumber = $HidToNumber{$HcurrentID};
	my($island) = $Hislands[$HcurrentNumber];
	$HcurrentName = $island->{'name'};

	# 비밀번호
	if(!checkPassword($island->{'password'},$HinputPassword)) {
		# password 오류
		unlock();
		tempWrongPassword();
		return;
	}

	commandAdd($island);

	# owner mode 로
	ownerMain();

}

# 명령 등록
sub commandAdd {
	my $island = shift;
	my($command) = $island->{'command'};

	$HcommandKind =~ tr/0-9//dc;
	$HcommandArg =~ tr/0-9//dc;
	$HcommandX =~ tr/0-9//dc;
	$HcommandY =~ tr/0-9//dc;

	# 모드에서 분기
	if($HcommandMode eq 'delete') {
		slideFront($command, $HcommandPlanNumber);
		tempCommandDelete();
	} elsif(($HcommandKind == $HcomAutoPrepare) ||
			($HcommandKind == $HcomAutoPrepare2)) {
		# 전체 개간, 전체땅고르기
		# 좌표배열을 만들기
		makeRandomPointArray();
		my($land) = $island->{'land'};

		# 자동 입력 시작 위치 보정: 지정이 없으면 기존 명령 아래 첫 빈 슬롯부터 추가
		if($HcommandPlanNumber !~ /^[0-9]+$/) {
			my($emptyNo) = $HcommandMax - 1;
			for(my $pi = 0; $pi < $HcommandMax; $pi++) {
				if($command->[$pi]->{'kind'} == $HcomDoNothing) { $emptyNo = $pi; last; }
			}
			$HcommandPlanNumber = $emptyNo;
		}

		# 명령 종류결정
		my($kind) = $HcomPrepare;
		if($HcommandKind == $HcomAutoPrepare2) {
			$kind = $HcomPrepare2;
		}

		my($i) = 0;
		my($j) = 0;
		while(($j < $HpointNumber) && ($i < $HcommandMax)) {
			my($x) = $Hrpx[$j];
			my($y) = $Hrpy[$j];
			if($land->[$x][$y] == $HlandWaste) {
				slideBack($command, $HcommandPlanNumber);
				$command->[$HcommandPlanNumber] = {
					'kind' => $kind,
					'target' => 0,
					'x' => $x,
					'y' => $y,
					'arg' => 0
					};
				$i++;
			}
			$j++;
		}
		tempCommandAdd();
	} elsif($HcommandKind == $HcomAutoDelete) {
		# 전체 삭제
		my($i);
		for($i = 0; $i < $HcommandMax; $i++) {
			slideFront($command, $HcommandPlanNumber);
		}
		tempCommandDelete();

	} elsif($HcommandKind == $HcomPrepRecr) {
		# 매립 + 땅고르기
		if($HcommandMode eq 'insert') {
			slideBack($command, $HcommandPlanNumber);
		}
		slideBack($command, $HcommandPlanNumber);
		tempCommandAdd();
		# 명령을 등록
		$command->[$HcommandPlanNumber] = {
			'kind' => $HcomReclaim,
			'target' => $HcommandTarget,
			'x' => $HcommandX,
			'y' => $HcommandY,
			'arg' => $HcommandArg
			};
		$command->[$HcommandPlanNumber + 1] = {
			'kind' => $HcomPrepare2,
			'target' => $HcommandTarget,
			'x' => $HcommandX,
			'y' => $HcommandY,
			'arg' => $HcommandArg
		};

	} else {
		if($HcommandMode eq 'insert') {
			slideBack($command, $HcommandPlanNumber);
		}
		tempCommandAdd();
		# 명령을 등록
		$command->[$HcommandPlanNumber] = {
			'kind' => $HcommandKind,
			'target' => $HcommandTarget,
			'x' => $HcommandX,
			'y' => $HcommandY,
			'arg' => $HcommandArg
			};
	}

	# 데이터 쓰기
	writeIslandsFile($HcurrentID);
}

#----------------------------------------------------------------------
# 코멘트입력 모드
#----------------------------------------------------------------------
# 메인
sub commentMain {
	# id에서 섬을 가져옴
	$HcurrentNumber = $HidToNumber{$HcurrentID};
	my($island) = $Hislands[$HcurrentNumber];
	$HcurrentName = $island->{'name'};

	# 비밀번호
	if(!checkPassword($island->{'password'},$HinputPassword)) {
		# password 오류
		unlock();
		tempWrongPassword();
		return;
	}

	# 메시지를 갱신
	$island->{'comment'} = htmlEscape($Hmessage);

	# 데이터 쓰기
	writeIslandsFile($HcurrentID);

	# 코멘트갱신 메시지
	tempComment();

	# owner mode 로
	ownerMain();
}

#----------------------------------------------------------------------
# 로컬 게시판 모드
#----------------------------------------------------------------------
# 메인

sub localBbsMain {
	# id에서 섬 번호를 가져옴
	$HcurrentNumber = $HidToNumber{$HcurrentID};
	my($island) = $Hislands[$HcurrentNumber];
	my($foreignName);

	# 왠지그 섬이 없는 경우
	if($HcurrentNumber eq '' && $HcurrentID != 0) {
		unlock();
		tempProblem();
		return;
	}

	# 삭제 모드가 아니고 이름이나 메시지가 없는 경우
	if($HlbbsMode != 2) {
		if(($HlbbsName eq '') || ($HlbbsMessage eq '')) {
			unlock();
			tempLbbsNoMessage();
			return;
		}
	}

	# 섬무시 관광객이외는 비밀번호 확인
	if($HlbbsMode == 0 && $HforID != 0) {
		# 외국자 모드
		my($foreignNumber) = $HidToNumber{$HforID};
		if($foreignNumber eq ''){
			unlock();
			tempProblem();
			return;
		}
		my($fIsland) = $Hislands[$foreignNumber];
		if(!checkPassword($fIsland->{'password'},$HinputPassword)) {
			unlock();
			tempWrongPassword();
			return;
		}
		$foreignName = "<A HREF=\"".$HthisFile."?BBS=".$fIsland->{'id'}."\" STYlE=\"text-decoration:none\">";
		$foreignName.= "<font size=-1 color=gray>(".$fIsland->{'name'}."섬)</font></A>";
	} elsif($HlbbsMode) {
		# 섬주 모드
		if(!checkPassword($island->{'password'},$HinputPassword)) {
			# password 오류
			unlock();
			tempWrongPassword();
			return;
		}
	}

	my($lbbs);
	$lbbs = $island->{'lbbs'};

	# 모드에서 분기
	if($HlbbsMode == 2) {
		# 삭제 모드
		# 메시지를 앞으로 당기기
		slideBackLbbsMessage($lbbs, $HcommandPlanNumber);
		tempLbbsDelete();
	} else {
		# 기장 모드
		# 메시지를 뒤에밀기
		slideLbbsMessage($lbbs);

		if($HforID == 0 and $HlbbsMode == 0){
			$HlbbsMessage = htmlEscape($HlbbsMessage);
			$message = '3';
		} elsif (($HlbbsMode == 0) && ($HforID != $island->{'id'})){
			$HlbbsMessage = htmlEscape($HlbbsMessage). " ".$foreignName;
			$message = '0';
		} else {
			$HlbbsMessage = htmlEscape($HlbbsMessage);
			$message = '1';
		}
		$HlbbsName = "$HislandTurn:". htmlEscape($HlbbsName);
		my $now = time;
		$lbbs->[0] = "$message>$HlbbsName>$HlbbsMessage&$now";

		tempLbbsAdd();
	}

	# 데이터 쓰기
	writeIslandsFile($HcurrentID);

	# 원래의 모드로
	if($HlbbsMode == 0) {
		printIslandMain();
	} else {
		ownerMain();
	}
}

# 로컬 게시판의 메시지를 하나뒤에밀기
sub slideLbbsMessage {
	my($lbbs) = @_;
	my($i);
	pop(@$lbbs);
	unshift(@$lbbs, $lbbs->[0]);
}

# 로컬 게시판의 메시지를 하나앞으로 당기기
sub slideBackLbbsMessage {
	my($lbbs, $number) = @_;
	my($i);
	splice(@$lbbs, $number, 1);
	$lbbs->[$HlbbsMax - 1] = '0>>';
}

#----------------------------------------------------------------------
# 섬 지도
#----------------------------------------------------------------------

# 정보의 표시
sub islandInfo {
	my($island) = $Hislands[$HcurrentNumber];
	# 정보 표시
	my($rank) = $HcurrentNumber + 1;
	my($farm) = $island->{'farm'};
	my($factory) = $island->{'factory'};
	my($mountain) = $island->{'mountain'};
	my($mStr3) = '';
	my($cmt_) = 7;

	# 예선 기간, 실업자가상한을 상회라고 있었음라경고
	if($HislandTurn < $HyosenTurn) {
		my $tmp = int($island->{'pop'} - ($farm + $factory + $mountain) * 10);
		$tmp = 0 if($tmp < 0);
		$mStr3 = "<FONT COLOR=RED><B>실업자가".$Hno_work.$HunitPop.
					"이상출하고 있으므로, 인구 증가가 중단합니다. 생산시설을 건설테테하세요.</B></FONT>" if($tmp>= $Hno_work);
		$cmt_++;
	}
	$farm = ($farm == 0) ? "보유하지 않음" : "${farm}0$HunitPop";
	$factory = ($factory == 0) ? "보유하지 않음" : "${factory}0$HunitPop";
	$mountain = ($mountain == 0) ? "보유하지 않음" : "${mountain}0$HunitPop";

	my($mStr1) = '';
	my($mStr2) = '';
	if(($HhideMoneyMode == 1) || ($HmainMode eq 'owner')) {
		# 무조건또는 owner 모드
		$mStr1 = "<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_} 자금${H_tagTH}</NOBR></TH>";
		$mStr2 = "<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$island->{'money'}$HunitMoney</NOBR></TD>";
		$cmt_++;
	} elsif($HhideMoneyMode == 2) {
		my($mTmp) = aboutMoney($island->{'money'});
		# 1000억단위 모드
		$mStr1 = "<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_} 자금${H_tagTH}</NOBR></TH>";
		$mStr2 = "<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$mTmp</NOBR></TD>";
		$cmt_++;

		$farm 	 = "기밀" if($Hhide_farm == 2);
		$factory = "기밀" if($Hhide_factory == 2);

	}

	my($comname) ="${HtagTH_}코멘트:${H_tagTH}";
	if(($island->{'ownername'} ne '0') && ($island->{'ownername'} ne "코멘트")){
		$comname = "<FONT COLOR=\"blue\"><B>$island->{'ownername'}:</b></font>";
	}

	# 대전 상대의 표시
	my $fight_name = '';
	if($island->{'fight_id'}> 0 and $island->{'pop'}> 0) {
		my $HcurrentNumber = $HidToNumber{$island->{'fight_id'}};
		if($HcurrentNumber ne '') {
			my $tIsland = $Hislands[$HcurrentNumber];
			my $name = '<A HREF="'.$HthisFile."?Sight=".$tIsland->{'id'}."\">$tIsland->{'name'} 섬</A>";
			$fight_name = "<TR><TD $HbgCommentCell COLSPAN=".$cmt_." align=CENTER nowrap=nowrap><NOBR><B>대전 상대는$name 입니다</B></NOBR></TD></TR>";
		}
	}

	# 개발 정지의 표시
	my $rest_msg = '';
	if($island->{'rest'}> 0 and $HislandNumber> 1 and $island->{'pop'}> 0) {
		$rest_msg = "<TR><TH $HbgCommentCell COLSPAN=".$cmt_." nowrap=nowrap><NOBR>\n";
		$rest_msg.= "부전승으로 개발 정지 중 ";
		$rest_msg.= "남은<FONT COLOR=RED>".$island->{'rest'}."</FONT>턴</NOBR></TH></TR>";
	}

	my $time;
	if($HislandNumber> 1) {
		# 시간 표시
		my($hour, $min, $sec);
		my($now) = time;
		my($showTIME) = ($HislandLastTime + $HunitTime - $now);
		$hour = int($showTIME / 3600);
		$min = int(($showTIME - ($hour * 3600)) / 60);
		$sec = $showTIME - ($hour * 3600) - ($min * 60);
		$time = "<BR><B>턴${HislandTurn}</B> (다음 턴까지,$hour 시간 $min 분 $sec 초)";
	}

	# 인구의 표시
	$pop = (!$Hhide_town or $HmainMode eq 'owner') ? $island->{'pop'}.$HunitPop : aboutPop($island->{'pop'});

	out(<<END);
<CENTER>
${time}
<TABLE BORDER>
<TR>
<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}순위${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}인구${H_tagTH}</NOBR></TH>
$mStr1
<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}식량${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}면적${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}농장규모${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}공장규모${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}채굴장규모${H_tagTH}</NOBR></TH>
</TR>
<TR>
<TD $HbgNumberCell align=middle nowrap=nowrap><NOBR>${HtagNumber_}$rank${H_tagNumber}</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$pop</NOBR></TD>
$mStr2
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$island->{'food'}$HunitFood</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$island->{'area'}$HunitArea</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>${farm}</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>${factory}</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>${mountain}</NOBR></TD>
</TR>
<TR>
<TD $HbgCommentCell COLSPAN=${cmt_} align=left nowrap=nowrap><NOBR>$comname$island->{'comment'}</NOBR></TD>
</TR>
$rest_msg
$fight_name
</TABLE>
$mStr3</CENTER>
END
}

# 지도 표시
# 인 수가1이면, 미사일 기지등을 그대로 표시
sub islandMap {
	my($mode, $js) = @_;
	my($island);
	$island = $Hislands[$HcurrentNumber];

	# 지형, 지형 값을 가져옴
	my($land) = $island->{'land'};
	my($landValue) = $island->{'landValue'};
	my($l, $lv);

	out("<CENTER><TABLE BORDER><TR><TD>");

	# 명령 가져오기
	my($command) = $island->{'command'};
	my($com, @comStr, $i);
	if($HmainMode eq 'owner') {
		for($i = 0; $i < $HcommandMax; $i++) {
			my($j) = $i + 1;
			$com = $command->[$i];
			if($com->{'kind'} < 20) {
				$comStr[$com->{'x'}][$com->{'y'}].=
					" [${j}]$HcomName[$com->{'kind'}]";
			}
		}
	}

	# 좌표(상)을 출력
	out("<IMG SRC=\"xbar.gif\" width=400 height=16><BR>");

	# 각 지형및 줄바꿈을 출력
	my($x, $y);
	for($y = 0; $y < $HislandSize; $y++) {
		# 짝 수행이면 번호 출력
		if(($y % 2) == 0) {
			out("<IMG SRC=\"space${y}.gif\" width=16 height=32>");
		}

		# 각 지형을 출력
		for($x = 0; $x < $HislandSize; $x++) {
			$l = $land->[$x][$y];
			$lv = $landValue->[$x][$y];
			landString($l, $lv, $x, $y, $mode, $comStr[$x][$y], $js);
		}

		# 홀 수행이면 번호 출력
		if(($y % 2) == 1) {
			out("<IMG SRC=\"space${y}.gif\" width=16 height=32>");
		}

		# 줄바꿈을 출력
		out("<BR>");
	}
	out("</TD></TR></TABLE></CENTER>\n");
}

sub landString {
	my($l, $lv, $x, $y, $mode, $comStr, $j_mode) = @_;
	my($point) = "($x,$y)";
	my($image, $alt);

	if($l == $HlandSea) {
		if($lv == 1) {
			# 얕은 바다
			$image = 'land14.gif';
			$alt = '바다(얕은 바다)';
		} else {
			# 바다
			$image = 'land0.gif';
			$alt = '바다';
		}
	} elsif($l == $HlandWaste) {
		# 황무지
		if($lv == 1) {
			$image = 'land13.gif'; # 착탄 지점
			$alt = '황무지';
		} else {
			$image = 'land1.gif';
			$alt = '황무지';
		}
	} elsif($l == $HlandPlains) {
		# 평지
		$image = 'land2.gif';
		$alt = '평지';
	} elsif($l == $HlandForest) {
		# 숲
		if($mode == 1) {
			$image = 'land6.gif';
			$alt = "숲(${lv}$HunitTree)";
		} else {
			# 관광객에게는 목장 수를 숨김
			$image = 'land6.gif';
			$alt = '숲';
		}
	} elsif($l == $HlandTown) {
		# 마을
		my($p, $n);
		if($lv < 30) {
			$p = 3;
			$n = '마을';
		} elsif($lv < 100) {
			$p = 4;
			$n = '마을';
		} else {
			$p = 5;
			$n = '도시';
		}

		$image = "land${p}.gif";
		$alt = "$n(${lv}$HunitPop)";
		$alt = $n if($Hhide_town and $mode == 0);
	} elsif($l == $HlandFarm) {
		# 농장
		$image = 'land7.gif';
		$alt = "농장(${lv}0${HunitPop}규모)";
		($image,$alt) = ('land6.gif','숲') if($Hhide_farm and $mode == 0)
	} elsif($l == $HlandFactory) {
		# 공장
		$image = 'land8.gif';
		$alt = "공장(${lv}0${HunitPop}규모)";
		($image,$alt) = ('land6.gif','숲') if($Hhide_factory and $mode == 0)
	} elsif($l == $HlandBase) {
		if($mode == 0) {
			# 관광객의 경우
			($image,$alt) = ($Hhide_missile) ? ('land6.gif','숲') : ('land9.gif','미사일 기지');
		} else {
			# 미사일 기지
			my($level) = expToLevel($l, $lv);
			$image = 'land9.gif';
			$alt = "미사일 기지 (레벨 ${level}/경험치 $lv)";
		}
	} elsif($l == $HlandDefence) {
		# 방위 시설
		$image = 'land10.gif';
		$alt = '방위 시설';
		($image,$alt) = ('land6.gif','숲') if($Hhide_deffence and $mode == 0)
	} elsif($l == $HlandHaribote) {
		# 가짜 시설
		$image = 'land10.gif';
		if($mode == 0) {
			# 관광객에게는 방위 시설처럼 표시
			$alt = '방위 시설';
		} else {
			$alt = '가짜 시설';
		}
	} elsif($l == $HlandMountain) {
		# 산
		my($str);
		$str = '';
		if($lv> 0) {
			$image = 'land15.gif';
			$alt = "산(채굴장${lv}0${HunitPop}규모)";
		} else {
			$image = 'land11.gif';
			$alt = '산';
		}
	}


	# 개발 화면일 경우 좌표 설정
	if($j_mode) {
		if($mode == 1) {
			out(qq#<A HREF="JavaScript:void(0);" onclick="ps($x,$y)" #);
			out(qq#onMouseOver="set_com($x, $y, '$point $alt'); return true;" onMouseOut="window.status = '';">#);
			$comStr = '';
		} else {
			out(qq#<A HREF="JavaScript:void(0);" onclick="ps($x,$y)" #);
			out(qq#onMouseOver="window.status='$point $alt $comStr'; return true;" onMouseOut="window.status = '';">#);
		}
	} elsif($mode == 1) {
		out("<A HREF=\"JavaScript:void(0);\" onclick=\"ps($x,$y)\" onMouseOver=\"ShowMsg('$point $alt $comStr'); return true;\">");
	} else {
		out("<A HREF=\"JavaScript:void(0);\" onMouseOver=\"ShowMsg('$point $alt $comStr'); return true;\">");
	}

	out("<IMG SRC=\"$image\" TITLE=\"$point $alt $comStr\" ALT=\"$point $alt $comStr\" width=32 height=32 BORDER=0 ID='${x}x${y}'></A>");

}

sub islandMarking {
 out(<<END);
<script type="text/javascript">
<!--
var mArray = new Array();
var lastX = 0;
var lastY = 0;
var lastN = 19;
var lastF = 0;

// 미사일범위의 마킹을 설정
function set_mark(x, y) {
 if(!document.mark_form.mark.checked) return false;
 if(!document.getElementById) {
 alert("대변신청이 몰려가, 오사용이의 브라우저예기능을 지원하 없습니다.");
 return false;
 }

 var num = document.mark_form.number_mark.value;
 var kind = document.mark_form.kind_mark.value;

 if(kind == '') {
 do_mark(lastX, lastY, lastN, '-');

 if(lastF == 1 && lastX == x && lastY == y) {
 lastX = 0;
 lastY = 0;
 lastF = 0;
 return;
 }
 lastX = x;
 lastY = y;
 lastF = 1;
 kind = 'FFFF00';
 }

 do_mark(x, y, num, kind);
}

function do_mark(x, y, num, kind) {
 var xArray = new Array(0, 1, 1, 1, 0,-1, 0, 1, 2, 2, 2, 1, 0,-1,-1,-2,-1,-1, 0);
 var yArray = new Array(0,-1, 0, 1, 1, 0,-1,-2,-1, 0, 1, 2, 2, 2, 1, 0,-1,-2,-2);

 for (i = 0; i < num; i++) {
 var targetX = x + xArray[i];
 var targetY = y + yArray[i];

 // 행 기준 위치 조정
 if(((targetY % 2) == 0) && ((y % 2) == 1)) {
 targetX = targetX - 1;
 }
 if(!(targetX < 0 || targetX>= $HislandSize || targetY < 0 || targetY>= $HislandSize)) {
 if(kind == '-') {
 unset_highlight(targetX, targetY);
 mArray[targetX+"x"+targetY] = 0;
 } else {
 set_highlight(targetX, targetY, kind);
 mArray[targetX+"x"+targetY] = 1;
 }
 }
 }
}

// 이미지를 마킹화
function set_highlight(x, y, color) {
 if(document.getElementById) {
 document.getElementById(x+"x"+y).width = "30";
 document.getElementById(x+"x"+y).height = "30";
 document.getElementById(x+"x"+y).border = "1";
 document.getElementById(x+"x"+y).style.borderColor = "#"+color;
 }
}

// 마킹해제
function unset_highlight(x, y) {
 if(document.getElementById) {
 document.getElementById(x+"x"+y).width = "32";
 document.getElementById(x+"x"+y).height = "32";
 document.getElementById(x+"x"+y).border = "0";
 }
}

// 전체의 마킹을 해제
function unset_all_highlight() {
 for (f=0;f<$HislandSize;f++) {
 for (i=0;i<$HislandSize;i++) {
 if(mArray[i+"x"+f] == 1) {
 unset_highlight(i, f);
 }
 }
 }
}
 //-->
</script>

<FORM NAME="mark_form">
마킹<INPUT TYPE=CHECKBOX NAME="mark">
종류
<SELECT NAME="kind_mark">
<OPTION VALUE="">표준
<OPTION VALUE="FFFF00">Yellow
<OPTION VALUE="FF0000">Red
<OPTION VALUE="0000FF">Blue
<OPTION VALUE="00FF00">Green
<OPTION VALUE="FF00FF">Purple
<OPTION VALUE="CCCCBB">Gray
<OPTION VALUE="-">None
</SELECT>
범위
<SELECT NAME="number_mark">
<OPTION VALUE="1">0HEX
<OPTION VALUE="7">1HEX
<OPTION VALUE="19" SELECTED>2HEX
</SELECT>
 <INPUT TYPE="BUTTON" VALUE="해제" onClick="unset_all_highlight();">
</FORM>
END
}


#----------------------------------------------------------------------
# 템플릿기타
#----------------------------------------------------------------------
# 개별 로그 표시
sub logPrintLocal {
	my($mode) = @_;
	my($i);
	for($i = 0; $i < $HlogMax; $i++) {
		logFilePrint($i, $HcurrentID, $mode, 1);
	}
}

# ○○섬으로 수 있도록 말로!!
sub tempPrintIslandHead {
	out(<<END);
<CENTER>
${HtagBig_}${HtagName_}'${HcurrentName} 섬'${H_tagName}되도록!!${H_tagBig}<BR>
END
	out($HtempBack."<BR>") if(!$Htop_blank);
	out(<<END);
</CENTER>
<SCRIPT Language="JavaScript">
<!--
function ShowMsg(n){
		window.status = n;
}
//-->
</SCRIPT>
END
}

# ○○섬개발계획
sub tempOwner {

	my($island) = $Hislands[$HcurrentNumber];
	out(<<END);
<CENTER>
${HtagBig_}${HtagName_}${HcurrentName} 섬${H_tagName}개발계획${H_tagBig}<BR>
$HtempBack<BR>
</CENTER>
<SCRIPT Language="JavaScript">
<!--
function ps(x, y) {
 if(document.mark_form.mark.checked) {
 set_mark(x, y);
 } else {
 document.forms[0].elements[4].options[x].selected = true;
 document.forms[0].elements[5].options[y].selected = true;
 }
 return true;
}

function ns(x) {
	document.forms[0].elements[2].options[x].selected = true;
	return true;
}
function ShowMsg(n){
		window.status = n;
		document.forms[0].COMSTATUS.value= n;
}
//-->
</SCRIPT>
END

	islandInfo();

	out(<<END);
<CENTER>
<TABLE BORDER>
<TR>
<TD $HbgInputCell VALIGN=TOP>
<CENTER>
<nobr><BR>미사일 발사상한 수[<b> $island->{'fire'} </b>]발</nobr>
<FORM action="$HthisFile" method=POST>
<INPUT TYPE=submit VALUE="계획 전송" NAME=CommandButton$Hislands[$HcurrentNumber]->{'id'}>
<INPUT TYPE=HIDDEN NAME=PASSWORD VALUE="$HdefaultPassword">
<HR>
<B>계획번호</B><SELECT NAME=NUMBER>
END
	# 계획번호
	my($j, $i);
	for($i = 0; $i < $HcommandMax; $i++) {
		$j = $i + 1;
		out("<OPTION VALUE=$i>$j\n");
	}

	out(<<END);
</SELECT><BR>
<HR>
<B>개발계획</B><BR>
<SELECT NAME=COMMAND>
END

	#명령
	my($kind, $cost, $s);
	for($i = 0; $i < $HcommandTotal; $i++) {
		$kind = $HcomList[$i];
		$cost = $HcomCost[$kind];
		if($cost == 0) {
			$cost = '무료'
		} elsif($cost < 0) {
			$cost = - $cost;
			$cost.= $HunitFood;
		} else {
			$cost.= $HunitMoney;
		}
		if($kind == $HdefaultKind) {
			$s = 'SELECTED';
		} else {
			$s = '';
		}
		out("<OPTION VALUE=$kind $s>$HcomName[$kind]($cost)\n");
	}

	out(<<END);
</SELECT>
<HR>
<B>좌표(</B>
<SELECT NAME=POINTX>

END
	for($i = 0; $i < $HislandSize; $i++) {
		if($i == $HdefaultX) {
			out("<OPTION VALUE=$i SELECTED>$i\n");
		} else {
			out("<OPTION VALUE=$i>$i\n");
		}
	}

	out(<<END);
</SELECT>, <SELECT NAME=POINTY>
END

	for($i = 0; $i < $HislandSize; $i++) {
		if($i == $HdefaultY) {
			out("<OPTION VALUE=$i SELECTED>$i\n");
		} else {
			out("<OPTION VALUE=$i>$i\n");
		}
	}
	out(<<END);
</SELECT><B>)</B>
<HR>
<B>수량</B><SELECT NAME=AMOUNT>
END

	# 수량
	for($i = 0; $i < 50; $i++) {
		out("<OPTION VALUE=$i>$i\n");
	}

	out(<<END);
</SELECT>
<HR>
<B>대상 섬</B><BR>
<SELECT NAME=TARGETID>
END
	out(getIslandList($island->{'id'},1,$island->{'fight_id'}));
	out(<<END);
<BR>
</SELECT>
<HR>
<B>동작</B><BR>
<INPUT TYPE=radio NAME=COMMANDMODE VALUE=insert CHECKED>삽입
<INPUT TYPE=radio NAME=COMMANDMODE VALUE=write>덮어쓰기<BR>
<INPUT TYPE=radio NAME=COMMANDMODE VALUE=delete>삭제
<HR>
<INPUT TYPE=submit VALUE="계획 전송" NAME=CommandButton$Hislands[$HcurrentNumber]->{'id'}>
</CENTER>
</TD>
<TD $HbgMapCell VALIGN=TOP><center>
<TEXTAREA NAME="COMSTATUS" cols="48" rows="2"></TEXTAREA></center>
END
	islandMap(1);	# 섬 지도, 소유자 모드
 out("</FORM>");
 islandMarking();
	out(<<END);
</TD>
<TD $HbgCommandCell>
END
	for($i = 0; $i < $HcommandMax; $i++) {
		tempCommand($i, $Hislands[$HcurrentNumber]->{'command'}->[$i]);
	}

	out(<<END);
</TD>
</TR>
</TABLE>
</CENTER>
<HR>
<CENTER>
${HtagBig_}코멘트갱신${H_tagBig}<BR>
<FORM action="$HthisFile" method="POST">
코멘트<INPUT TYPE=text NAME=MESSAGE SIZE=80><BR>
비밀번호<INPUT TYPE=password NAME=PASSWORD VALUE="$HdefaultPassword">
<INPUT TYPE=submit VALUE="코멘트갱신" NAME=MessageButton$Hislands[$HcurrentNumber]->{'id'}>
</FORM>
</CENTER>
END

}

# 입력 완료된 명령 표시
sub tempCommand {
	my($number, $command) = @_;
	my($kind, $target, $x, $y, $arg) =
		(
		 $command->{'kind'},
		 $command->{'target'},
		 $command->{'x'},
		 $command->{'y'},
		 $command->{'arg'}
		 );
	my($name) = "$HtagComName_${HcomName[$kind]}$H_tagComName";
	my($point) = "$HtagName_($x,$y)$H_tagName";
	$target = $HidToName{$target};
	if($target eq '') {
		$target = "무인";
	}
	$target = "$HtagName_${target} 섬$H_tagName";
	my($value) = $arg * $HcomCost[$kind];
	if($value == 0) {
		$value = $HcomCost[$kind];
	}
	if($value < 0) {
		$value = -$value;
		$value = "$value$HunitFood";
	} else {
		$value = "$value$HunitMoney";
	}
	$value = "$HtagName_$value$H_tagName";

	my($j) = sprintf("%02d:", $number + 1);

	out("<A STYlE=\"text-decoration:none\" HREF=\"JavaScript:void(0);\" onClick=\"ns($number)\"><NOBR>$HtagNumber_$j$H_tagNumber<FONT COLOR=\"$HnormalColor\">");

	if(($kind == $HcomDoNothing) || ($kind == $HcomAutoPrepare3) ||
	 ($kind == $HcomGiveup)) {
		out("$name");
	} elsif(($kind == $HcomMissileNM) ||
			($kind == $HcomMissilePP)) {
		# 미사일계
		my($n) = ($arg == 0 ? '무제한' : "${arg}발");
		out("$target$point 로$name($HtagName_$n$H_tagName)");
	} elsif($kind == $HcomSell) {
		# 식량 수출
		out("$name$value");
	} elsif(($kind == $HcomFarm) || ($kind == $HcomFactory) || ($kind == $HcomMountain)) {
		# 횟수 포함
		if($arg == 0) {
			out("$point 에서$name");
		} else {
			out("$point 에서$name($arg 회)");
		}
	} else {
		# 좌표 포함
		out("$point 에서$name");
	}

	out("</FONT></NOBR></A><BR>");
}

# 로컬 게시판
sub tempLbbsHead {
	out(<<END);
<HR>
<CENTER>
${HtagBig_}${HtagName_}${HcurrentName} 섬${H_tagName}관광객 통신${H_tagBig}<BR>
</CENTER>
END
}

# 로컬 게시판입력 양식
sub tempLbbsInput {
	out(<<END);
<CENTER>
<FORM action="$HthisFile" method="POST">
<font color=red> 섬이 없는 분도 글을 남길 수 있습니다. 게임 내용과 관계없는 발언은 가능하면 ${bbsname}에 작성해 주세요.</font>
<TABLE BORDER>
<TR>
<TH>이름</TH>
<TH>내용</TH>
</TR>
<TR>
<TD><INPUT TYPE="text" SIZE=32 MAXLENGTH=32 NAME="LBBSNAME" VALUE="$HdefaultName"></TD>
<TD><INPUT TYPE="text" SIZE=80 NAME="LBBSMESSAGE"></TD>
</TR>
<TR>
<TD colspan="2">자신의 섬:
<SELECT NAME="ISLANDID">
<OPTION value="0"> 섬 외 관광객
$HislandList</SELECT>
 비밀번호:<INPUT TYPE="password" SIZE=32 MAXLENGTH=32 NAME=PASSWORD VALUE="$HdefaultPassword">
<INPUT TYPE="submit" VALUE="등록" NAME="LbbsButtonFO$HcurrentID"></TD>
</TR>
</TABLE>
END
	out("<INPUT TYPE=HIDDEN NAME='BBSMODE'>") if($easy_mode);
	my $msg = ($easy_mode) ? "Sight=$HcurrentID>->일반 관광 화면로..." : "BBS=$HcurrentID>->간이 관광객 통신으로...";
	out("<B><A STYlE=\"text-decoration:none\" HREF=".$HthisFile."?".$msg."</A></B>");
	out("</FORM>\n</CENTER>\n");
}

# 로컬 게시판입력 양식 owner mode 용
sub tempLbbsInputOW {
	out(<<END);
<CENTER>
<FORM action="$HthisFile" method="POST">
<TABLE BORDER>
<TR>
<TH>이름</TH>
<TH COLSPAN=2>내용</TH>
</TR>
<TR>
<TD><INPUT TYPE="text" SIZE=32 MAXLENGTH=32 NAME="LBBSNAME" VALUE="$HdefaultName"></TD>
<TD COLSPAN=2><INPUT TYPE="text" SIZE=80 NAME="LBBSMESSAGE"></TD>
</TR>
<TR>
<TH> 비밀번호</TH>
<TH COLSPAN=2>동작</TH>
</TR>
<TR>
<TD><INPUT TYPE=password SIZE=32 MAXLENGTH=32 NAME=PASSWORD VALUE="$HdefaultPassword"></TD>
<TD align=right>
<INPUT TYPE="submit" VALUE="등록" NAME="LbbsButtonOW$HcurrentID">
</TD>
<TD align=right>
번호
<SELECT NAME=NUMBER>
END
	# 발언번호
	my($j, $i);
	for($i = 0; $i < $HlbbsMax; $i++) {
		$j = $i + 1;
		out("<OPTION VALUE=$i>$j\n");
	}
	out(<<END);
</SELECT>
<INPUT TYPE="submit" VALUE="삭제" NAME="LbbsButtonDL$HcurrentID">
<INPUT TYPE="hidden" NAME=JAVAMODE VALUE="$HjavaMode">
</TD>
</TR>
</TABLE>
</FORM>
</CENTER>
END
}

# 로컬 게시판내용
sub tempLbbsContents {
	my($lbbs, $line);
	$lbbs = $Hislands[$HcurrentNumber]->{'lbbs'};
	out(<<END);
<CENTER>
<font color=red><b> 섬 이름을 클릭하면, 간이 관광객 통신으로 이동합니다</b></font>
<TABLE BORDER>
<TR>
<TH>번호</TH>
<TH>내용</TH>
</TR>
END

	my($i);
	$HlbbsView = $HlbbsMax if($easy_mode);
	for($i = 0; $i < $HlbbsView; $i++) {
		$line = $lbbs->[$i];
		if($line =~ /([0-9]*)\>(.*)\>(.*)$/) {
			my($j) = $i + 1;
			my ($mes) = split(/&/,$3);
			out("<TR><TD align=center>$HtagNumber_$j$H_tagNumber</TD>");
			if($1 == 0) {
				# 관광객
				out("<TD>$HtagLbbsSS_$2> $mes$H_tagLbbsSS</TD></TR>");
			} elsif($1 == 3) {
				# 섬무시 관광객
				out("<TD>$HtagLbbsSK_$2> $mes$H_tagLbbsSK</TD></TR>");
			} else {
				# 섬주
				out("<TD>$HtagLbbsOW_$2> $mes$H_tagLbbsOW</TD></TR>");
			}
		}
	}

	out(<<END);
</TD></TR></TABLE></CENTER>
END

}

# 대전 기록
sub FightViewMain {

	open(IN, "$HdirName/fight.log");
	my @lines = <IN>;
	close(IN);
	unlock();

	out ("${HtagTitle_}대전 기록${H_tagTitle}<BR><DIV ALIGN=right>*패자의 섬 이름을 클릭하면 패전 당시의 상황을 볼 수 있습니다</DIV>\n");

	foreach $line(@lines) {
		chop($line);
		if($line =~ /<[0-9]*>/) {
			out("</blockquote>\n");
			out("<hr><blockquote>\n<H1> ");
			$line =~ s/<|>//g;
			my $msg = ($line == 0) ? "예선 탈락" : ($line == 99) ? "결승전" : $line."회전";
			out(${HtagHeader_}.$msg.${H_tagHeader}."</H1>");
		} else {
			out($line);
		}
	}
	out("</blockquote>\n");
}

sub fight_map {
 my($l, $lv);
 my($land, $landValue, $line);

	open(LIN, "${Hdirfdata}/island.${HcurrentID}");
	$islandName = <LIN>;
	my($x, $y);
	for($y = 0; $y < $HislandSize; $y++) {
		$line = <LIN>;
		for($x = 0; $x < $HislandSize; $x++) {
			$line =~ s/^(.)(..)//;
			$land->[$x][$y] = hex($1);
			$landValue->[$x][$y] = hex($2);
		}
	}
 close(LIN);
	unlock();
 out (<<END);
<SCRIPT Language="JavaScript">
<!--
function ps(x, y) {
 return true;
}

function ns(x) {
 return true;
}

function ShowMsg(n){
	window.status = n;
}
//-->
</SCRIPT>
<CENTER>
${HtagBig_}${HtagName_}'${islandName} 섬'${H_tagName}패전쟁 시의 님자${H_tagBig}<BR>
<a href=${HthisFile}?FightLog=0>${HtagBig_}돌아가기${H_tagBig}</a><BR>
<BR>
<TABLE BORDER><TR><TD>
END
	# 좌표(상)을 출력
	out("<IMG SRC=\"xbar.gif\" width=400 height=16><BR>");

	# 각 지형및 줄바꿈을 출력
	my($x, $y);
	for($y = 0; $y < $HislandSize; $y++) {
		# 짝 수행이면 번호 출력
		if(($y % 2) == 0) {
			out("<IMG SRC=\"space${y}.gif\" width=16 height=32>");
		}

		# 각 지형을 출력
		for($x = 0; $x < $HislandSize; $x++) {
			$l = $land->[$x][$y];
			$lv = $landValue->[$x][$y];
			landString($l, $lv, $x, $y, 1, $comStr[$x][$y]);
		}

		# 홀 수행이면 번호 출력
		if(($y % 2) == 1) {
			out("<IMG SRC=\"space${y}.gif\" width=16 height=32>");
		}

		# 줄바꿈을 출력
		out("<BR>");
	}
	out("</TD></TR></TABLE></CENTER>\n");
}

# 접속 로그저장
sub write_access_log {
	my $i;
	my $view = $_[0];

	foreach (%ENV) {
		s/&(?!(?:amp|quot|lt|gt);)/&amp;/g;
		s/"/&quot;/g;
		s/</&lt;/g;
		s/>/&gt;/g;
		last if($i> 200 and $i++);
	}
	my $xip = $ENV{'HTTP_X_FORWARDED_FOR'};
	my $ip = $ENV{'REMOTE_ADDR'};

	my($sec, $min, $hour, $day, $month, $Year, $wday, $isdst) = localtime;
	$month ++;

	my($log_file) = $Hdiraccess."/". $month. "-". $day. ".cgi";
	my($agent) = $ENV{'HTTP_USER_AGENT'};
	open(ACS, ">>${log_file}");
	print ACS time(). ", ${ip}, ${xip}, ${HcurrentID}, ${HcurrentName} 섬, ${view}, ${agent},\n";
	close(ACS);
}

# 로컬 게시판에서 이름이나 메시지가 없는 경우
sub tempLbbsNoMessage {
	out(<<END);
${HtagBig_}이름 또는 내용이 비어 있습니다..${H_tagBig}$HtempBack
END
}

# 쓰기/삭제
sub tempLbbsDelete {
	out(<<END);
${HtagBig_}기록 내용을 삭제했습니다${H_tagBig}<HR>
END
}

# 코멘트 등록
sub tempLbbsAdd {
	out(<<END);
${HtagBig_}기록을 수행했습니다${H_tagBig}<HR>
END
}

# 명령 삭제
sub tempCommandDelete {
	out(<<END);
${HtagBig_} 명령을 삭제했습니다${H_tagBig}<HR>
END
}

# 명령 등록
sub tempCommandAdd {
	out(<<END);
${HtagBig_} 명령을 등록했습니다${H_tagBig}<HR>
END
}

# 코멘트 변경성공
sub tempComment {
	out(<<END);
${HtagBig_}코멘트를 갱신했습니다${H_tagBig}<HR>
END
}

# 최근 상황
sub tempRecent {
	my($mode) = @_;
	out(<<END);
<HR>
${HtagBig_}${HtagName_}${HcurrentName} 섬${H_tagName}의 최근 상황${H_tagBig}<BR>
END
	logPrintLocal($mode);
}

1;
