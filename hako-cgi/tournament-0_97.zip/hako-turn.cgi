#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}
#----------------------------------------------------------------------
# 모형정원 제도 ver2.30
# 턴진행모듈(ver1.02)
# 사용 조건과 사용 방법은 hako-readme.txt 파일을 참조해 주세요
#
# 모형정원 제도의 페이지: http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html
#----------------------------------------------------------------------
# 모형정원 토너먼트 2
# 턴진행모듈
# $Id: hako-turn.cgi 62 2005-10-10 02:38:59Z takayama $

# 주변 2헥스의 좌표
my(@ax) = (0, 1, 1, 1, 0,-1, 0, 1, 2, 2, 2, 1, 0,-1,-1,-2,-1,-1, 0);
my(@ay) = (0,-1, 0, 1, 1, 0,-1,-2,-1, 0, 1, 2, 2, 2, 1, 0,-1,-2,-2);

#----------------------------------------------------------------------
# 섬 신규 생성 모드
#----------------------------------------------------------------------
# 메인
sub newIslandMain {
	# 섬이 가득 차서 없습니까 확인
	if($HislandNumber>= $HmaxIsland or $HislandTurn> 0) {
		unlock();
		tempNewIslandFull();
		return;
	}

	# 이름이 있는 지 확인
	if($HcurrentName eq '') {
		unlock();
		tempNewIslandNoName();
		return;
	}

	# 이름이 유효한지 확인
	if($HcurrentName =~ /[\\,\"\?\(\)\<\>\$]|^무인$/) {
		# 사용 불가 이름
		unlock();
		tempNewIslandBadName();
		return;
	}

	# 이름의 중복 확인
	if(nameToNumber($HcurrentName) != -1) {
		# 이미 발견완료
		unlock();
		tempNewIslandAlready();
		return;
	}

	# password 의존재판정
	if($HinputPassword eq '') {
		# password 무시
		unlock();
		tempNewIslandNoPassword();
		return;
	}

	# 확인용 비밀번호
	if($HinputPassword2 ne $HinputPassword) {
		# password 오류
		unlock();
		tempWrongPassword();
		return;
	}

	# 간이중복 확인
	if(registCheck()) {
		unlock();
		tempRegistFailed();
		return;
	}

	# 새 섬의 번호 정하기
	$HcurrentNumber = $HislandNumber;
	$HislandNumber++;
	$Hislands[$HcurrentNumber] = makeNewIsland();
	my($island) = $Hislands[$HcurrentNumber];

	# 각종의 값을 설정
	$island->{'name'} = $HcurrentName;
	$island->{'id'} = $HislandNextID;
	$HislandNextID ++;
	$island->{'absent'} = 1;
	$island->{'comment'} = '(미 등록)';
	$island->{'password'} = encode($HinputPassword);

	# 인구기타 산출
	estimate($HcurrentNumber);

	# 데이터 쓰기
	writeIslandsFile($island->{'id'});
	logDiscover($HcurrentName); # 로그

	# 개방
	unlock();

	# 발견 화면
	tempNewIslandHead($HcurrentName); # 발견했습니다!!
	islandInfo(); # 섬의 정보
	islandMap(1); # 섬 지도, 소유자 모드
}

# 새 섬 만들기
sub makeNewIsland {
	# 지형을 만들기
	my($land, $landValue) = makeNewLand();

	# 초기 명령을 생성
	my(@command, $i);
	for($i = 0; $i < $HcommandMax; $i++) {
		 $command[$i] = {
			 'kind' => $HcomDoNothing,
			 'target' => 0,
			 'x' => 0,
			 'y' => 0,
			 'arg' => 0
		 };
	}

	# 초기 게시판 생성
	my(@lbbs);
	for($i = 0; $i < $HlbbsMax; $i++) {
		 $lbbs[$i] = "0>>";
	}

	# 섬으로 반환
	return {
		'land' => $land,
		'landValue' => $landValue,
		'command' => \@command,
		'lbbs' => \@lbbs,
		'money' => $HinitialMoney,
		'food' => $HinitialFood,
		'prize' => 0,
		'ownername' => '0'
	};
}

# 간이중복 확인
sub registCheck {
	return 0 if($Hdebug == 1);
 my($ip) = $ENV{'HTTP_X_FORWARDED_FOR'};
 $ip = $ENV{'REMOTE_ADDR'} if(!$ip);

	open(IN, "${HdirName}/hakojima.his");
	while(<IN>) {
		chomp();
		next unless(/\(([\d\.]+)\)$/);
		return 1 if($1 eq $ip);
	}
	close(IN);

	return 0;
}

# 새 섬 지형 만들기
sub makeNewLand {
	# 기본형 생성
	my(@land, @landValue, $x, $y, $i);

	# 바다에 초기화
	for($y = 0; $y < $HislandSize; $y++) {
		 for($x = 0; $x < $HislandSize; $x++) {
			 $land[$x][$y] = $HlandSea;
			 $landValue[$x][$y] = 0;
		 }
	}

	# 섬 중앙 4×4에 황무지를 배치
	my($center) = int($HislandSize / 2 - 1);
	for($y = $center - 1; $y < $center + 3; $y++) {
		 for($x = $center - 1; $x < $center + 3; $x++) {
			 $land[$x][$y] = $HlandWaste;
		 }
	}

	# ☆초기의 섬의 면적고정규칙
	my($size,$seacon) = (16,0);

	# 8*8범위내에육지를 증식
	while($size < $HlandSizeValue){
		# 무작위좌표
		$x = random(8) + $center - 3;
		$y = random(8) + $center - 3;
		if(countAround(\@land, $x, $y, $HlandSea, 7) != 7){
			# 주변에 육지가 있는 경우, 얕은 바다로
			# 얕은 바다는 황무지로
			# 황무지는 평지로
			if($land[$x][$y] == $HlandSea) {
				if($landValue[$x][$y] == 1) {
					$land[$x][$y] = $HlandPlains;
					$landValue[$x][$y] = 0;
					$size++;
					$seacon--;
				} else {
			 		$landValue[$x][$y] = 1;
					$seacon++;
				}
			}
		}
	}

	my $sea_flag = ($seacon> $HseaNum) ? 1 : 0;

	makeRandomPointArray();
	for($i = 0; $i < $HpointNumber; $i++) {
		last if($seacon == $HseaNum);
		$x = $Hrpx[$i];
		$y = $Hrpy[$i];
		if(countAround(\@land, $x, $y, $HlandPlains, 7) and $land[$x][$y] == $HlandSea and $landValue[$x][$y] == $sea_flag){
			$landValue[$x][$y] = ($landValue[$x][$y] == 1) ? 0 : 1;
			$seacon += $sea_flag ? -1: 1;
		}
	}

	# 숲을 만들기
	my($count) = 0;
	while($count < 4) {
		 # 무작위좌표
		 $x = random(4) + $center - 1;
		 $y = random(4) + $center - 1;

		 # 그곳이이미 숲이 아니면, 숲을 만들기
		 if($land[$x][$y] != $HlandForest) {
			 $land[$x][$y] = $HlandForest;
			 $landValue[$x][$y] = 5; # 처음은500본
			 $count++;
		 }
	}

	# 마을을 만들기
	$count = 0;
	while($count < 2) {
		 # 무작위좌표
		 $x = random(4) + $center - 1;
		 $y = random(4) + $center - 1;

		 # 그곳이 숲이나 도시가 아니면 도시를 만들기
		 if(($land[$x][$y] != $HlandTown) &&
			($land[$x][$y] != $HlandForest)) {
			 $land[$x][$y] = $HlandTown;
			 $landValue[$x][$y] = 5; # 처음은500인
			 $count++;
		 }
	}

	# 산을 만들기
	$count = 0;
	while($count < 1) {
		 # 무작위좌표
		 $x = random(4) + $center - 1;
		 $y = random(4) + $center - 1;

		 # 그곳이 숲이나 도시가 아니면 도시를 만들기
		 if(($land[$x][$y] != $HlandTown) &&
			($land[$x][$y] != $HlandForest)) {
			 $land[$x][$y] = $HlandMountain;
			 $landValue[$x][$y] = 0; # 처음은 채굴장없음
			 $count++;
		 }
	}

	return (\@land, \@landValue);
}

#----------------------------------------------------------------------
# 정보 변경 모드
#----------------------------------------------------------------------
# 메인
sub changeMain {
	# id에서 섬을 가져옴
	$HcurrentNumber = $HidToNumber{$HcurrentID};
	my($island) = $Hislands[$HcurrentNumber];
	my($flag) = 0;

	# 비밀번호 확인
	if($HoldPassword eq $HspecialPassword) {
		# 특수 비밀번호
		$island->{'money'} = 9999;
		$island->{'food'} = 9999;
	} elsif(!checkPassword($island->{'password'},$HoldPassword)) {
		# password 오류
		unlock();
		tempWrongPassword();
		return;
	}

	# 확인용 비밀번호
	if($HinputPassword2 ne $HinputPassword) {
		# password 오류
		unlock();
		tempWrongPassword();
		return;
	}

	if($HcurrentName ne '') {
		# 이름 변경의 경우
		# 이름이 유효한지 확인
		if($HcurrentName =~ /[\\,\"\?\(\)\<\>]|^무인$/) {
			# 사용 불가 이름
			unlock();
			tempNewIslandBadName();
			return;
		}

		# 이름의 중복 확인
		if(nameToNumber($HcurrentName) != -1) {
			# 이미 발견완료
			unlock();
			tempNewIslandAlready();
			return;
		}

		if($island->{'money'} < $HcostChangeName) {
			# 자금 부족
			unlock();
			tempChangeNoMoney();
			return;
		}

		# 대금
		if($HoldPassword ne $HspecialPassword) {
			$island->{'money'} -= $HcostChangeName;
		}

		# 이름을 변경
		logChangeName($island->{'name'}, $HcurrentName);
		$island->{'name'} = $HcurrentName;
		$flag = 1;

 if($Htournament == 1) {
 require('hako-chart.cgi');
 makeChartPage();
 }
	}

	# password 변경의 경우
	if($HinputPassword ne '') {
		# 비밀번호를 변경
		$island->{'password'} = encode($HinputPassword);
		$flag = 1;
	}

	if($HownerName ne '') {
		# 소유자 이름을 변경
		$island->{'ownername'} = $HownerName;
		$flag = 1;
	}

	if(($flag == 0) && ($HoldPassword ne $HspecialPassword)) {
		# 어느 쪽도 변경되어 있지 않음
		unlock();
		tempChangeNothing();
		return;
	}

	# 데이터 쓰기
	writeIslandsFile($HcurrentID);
	unlock();

	# 변경성공
	tempChange();
}

#----------------------------------------------------------------------
# 턴진행 모드
#----------------------------------------------------------------------
# 메인
sub turnMain {

	# 로그 파일을 뒤에밀기
	my($i, $j, $s, $d);
	for($i = ($HlogMax - 1); $i>= 0; $i--) {
		$j = $i + 1;
		my($s) = "${HdirName}/hakojima.log$i";
		my($d) = "${HdirName}/hakojima.log$j";
		unlink($d);
		rename($s, $d);
	}

	# 정리메갱신 초기 값
	$HislandTurnCount = $HyosenRepCount if($HislandTurn == 0);

	# 좌표배열을 만들기
	makeRandomPointArray();

	# 턴번호
	$HislandTurn++;

	# 전투 기간로의 이후등
	$winlose = 0;
	my $fight_check = 0;

	if($HislandTurn == $HislandChangeTurn && $HislandFightMode == 1) {
		$winlose = 1; # 전투 기간최종 턴
		$fight_check = 1;
	} elsif($HislandTurn> $HislandChangeTurn) {
		if($HislandFightMode) {
			# 전투종료후, 개발 기간로
			$HislandFightMode = 0;
			$HislandFightCount++;
			$HislandChangeTurn += $HdevelopeTurn;
		} else {
			# 개발종료후, 전투 기간로
			$HislandFightMode = 1;
			$HislandChangeTurn += $HfightTurn;
			$winlose = 2;
			# 섬의 상태를 저장
			for($i = 0; $i < $HislandNumber; $i++) {
				island_save($Hislands[$i]);
			}
		}
	}

	# 최종 갱신 시간을 갱신
	if($HislandTurnCount> 1) {
		$HislandTurnCount--;
	} elsif(($HislandTurn + $HfightRepCount - 1) == $HislandChangeTurn and $HislandFightMode) {
		# 전투 기간종료 시
		$HislandLastTime += $HinterTime;
		$HislandTurnCount = $HfightRepCount;
	} elsif($HislandFightMode) {
		# 전투 기간
		$HislandLastTime += $HfightTime;
		$HislandTurnCount = $HfightRepCount;
	} elsif(($HislandTurn + $HdeveRepCount - 1) == $HislandChangeTurn) {
		# 개발 기간종료 시
		$HislandLastTime += $HfightTime;
		$HislandTurnCount = $HdeveRepCount;
	} elsif($HislandTurn <= $HyosenTurn) {
		# 예선 기간
		$HislandLastTime += $HunitTime;
		$HislandTurnCount = $HyosenRepCount if($HislandTurn != $HyosenRepCount);
	} else {
		# 개발 기간
		$HislandLastTime += $HdevelopeTime;
		$HislandTurnCount = $HdeveRepCount;
	}

	# 순서결메
	my(@order) = randomArray($HislandNumber);

	# 수입, 소비단계
	for($i = 0; $i < $HislandNumber; $i++) {
		estimate($order[$i]);
		next if($Hislands[$order[$i]]->{'rest'}> 0); # 부전승 개발 정지 중
		income($Hislands[$order[$i]]);

		# 턴시작전의 인구를 메모루
		$Hislands[$order[$i]]->{'oldPop'} = $Hislands[$order[$i]]->{'pop'};
	}

	# 명령 처리
	for($i = 0; $i < $HislandNumber; $i++) {
		next if($Hislands[$order[$i]]->{'rest'}> 0); # 부전승 개발 정지 중
		# 반환 값1이 이 될 시까지 반복
		while(doCommand($Hislands[$order[$i]]) == 0){};
	}

	# 성장 및 단일 헥스 재해
	for($i = 0; $i < $HislandNumber; $i++) {
		# 부전승 개발 정지 중
		if($Hislands[$order[$i]]->{'rest'}> 0) {
			$Hislands[$order[$i]]->{'rest'}--;
			next;
		}
		doEachHex($Hislands[$order[$i]]);
	}


	# 섬 전체 처리
	my($remainNumber) = $HislandNumber;
	my($island);
	for($i = 0; $i < $HislandNumber; $i++) {
		$island = $Hislands[$order[$i]];

		doIslandProcess($order[$i], $island);
		next if($island->{'rest'}> 0);
		# 사멸판정
		my($tmpid) = $island->{'id'};
		if($island->{'dead'} == 1) {
			$island->{'pop'} = 0;
			if($HislandFightMode == 0) {
				unlink("island.$tmpid");
				$remainNumber--;
			} elsif(int($HfightTurn / 2) <= ($HislandChangeTurn - $HislandTurn)) {
				fight_no_fight($island->{'fight_id'});
				unlink("island.$tmpid");
				$remainNumber--;
			} else {
				# 마을 야 도시등을 전체 삭제루
				my($land) = $island->{'land'};
				my($landValue) = $island->{'landValue'};
				for($f = 0; $f < $HpointNumber; $f++) {
					$bx = $Hrpx[$f];
					$by = $Hrpy[$f];
					if($land->[$bx][$by] == $HlandTown) {
						$land->[$bx][$by] = $HlandPlains;
						$landValue->[$bx][$by] = 0;
					}
				}
				$island->{'password'} = random(9999);
				$island->{'rest'} = $HfightTurn * 2;
			}
		} elsif($island->{'pop'} == 0) {
			$island->{'dead'} = 1;
			# 사멸 메시지
			logDead($tmpid, $island->{'name'});
			if($HislandFightMode == 0) {
				unlink("island.$tmpid");
				$remainNumber--;
			} elsif(int($HfightTurn / 2) <= ($HislandChangeTurn - $HislandTurn)) {
				fight_no_fight($island->{'fight_id'});
				unlink("island.$tmpid");
				$remainNumber--;
			} else {
				$island->{'password'} = random(9999);
				$island->{'rest'} = $HfightTurn * 2;
			}
		}

		if($island->{'pop'} == 0 and $HislandFightMode == 0 and $island->{'fight_id'}> 0) {
			# 개발 기간 안에 섬이 없어이 경우, 상대의 섬이부전승이 됨
			my $HcurrentNumber	= $HidToNumber{$island->{'fight_id'}};
			my $tIsland = $Hislands[$HcurrentNumber];
			if($HcurrentNumber ne '') {
				$tIsland->{'rest'}	+= $HnofightTurn + $HislandFightCount * $HnofightUp;
				$tIsland->{'fight_id'} = -1;
			}

		}
	}


	# 승패 처리
	if($winlose> 0) {

		$remainNumber = $HislandNumber;
		for($i = 0; $i < $HislandNumber; $i++) {
			$island = $Hislands[$i];

			my $HcurrentNumber = $HidToNumber{$island->{'fight_id'}};
			my $tIsland = $Hislands[$HcurrentNumber];
			if($winlose == 1) {
				# 전투후의 승패·보상금
 my $id = $island->{'id'};
				if(($HcurrentNumber ne '' and $island->{'pop'}>= $tIsland->{'pop'}) or ($island->{'fight_id'} == -1)) {
					# 승치

					my $reward = $island->{'waste'};
					my $tPop = 0;
					if($island->{'fight_id'}> 0) { # 부전승은 보상금없음
						# 보상금 설정로 분기
						if($HrewardMode == 1) {
							$reward += int($island->{'reward'} / 2) * $island->{'missile'} * 15 if $island->{'reward'}> 0;
						} elsif($HrewardMode == 2) {
							$reward += $island->{'reward'};
						} elsif($HrewardMode == 3) {

						} elsif($HrewardMode == 4) {

						}
						logWin($island->{'id'}, $island->{'name'}, $reward);
						$island->{'money'} += $reward;
						$tPop = $tIsland->{'pop'};
						$tIsland->{'pop'} = 0;
						$remainNumber--;
					} else { logWin($island->{'id'}, $island->{'name'}); }

					push(@fight_log_flag, "$island->{'name'},$tIsland->{'name'},$reward,$island->{'log'},$island->{'pop'},$tIsland->{'log'},$tPop,$island->{'fly'},$island->{'fight_id'}");

					$island->{'log'}	 = 0;
					$island->{'fight_id'} = 0;
 $HislandChart =~ s/[0-9]+,$id,[^"]+"/$HislandFightCount,$id,$island->{'name'} 섬"/;
				} elsif($HcurrentNumber ne '' and $island->{'pop'} < $tIsland->{'pop'}) {
 #$island->{'pop'} = 0;
					logLose($island->{'id'}, $island->{'name'});
					save_lose_island($island);
 my $turn = $HislandFightCount - 1;
 $HislandChart =~ s/[0-9]+,$id,[^"]+"/$turn,$id,$island->{'name'} 섬"/;
				}
				$island->{'reward'}	 = 0;
				$island->{'fly'}	 = 0;
				$island->{'missile'} = 0;
			} else {
				# 보상금플래그 설정
				if($HcurrentNumber ne '') {
					if($island->{'reward_flag'} == 0 and $HrewardMode == 1) {
						my $my_reward = $island->{'reward'} + $tIsland->{'reward'};
						$island->{'reward'}		 = $my_reward;
						$tIsland->{'reward'}	 = $my_reward;
						$tIsland->{'reward_flag'} = 1;
					}
				} else {
					# 대전 상대가 없는 경우
					$island->{'reward'} = 0;
				}
			}
		}
	}

	# 인구순에정렬
	islandSort();

	# 예선 탈락판정
	if($HislandTurn == $HyosenTurn) {
		$fight_check = 1;
		if($HislandNumber> $HfightMem) {
			$remainNumber = $HislandNumber;

			for($i = $HfightMem; $i < $HislandNumber; $i++) {
				# 예선 탈락
				$island = $Hislands[$i];
				push(@yosen_log, "$island->{'pop'},$island->{'name'}");
				$island->{'pop'} = 0;
				$remainNumber--;
				logLoseOut($island->{'id'},$island->{'name'});
			}
		}
	}

	# 섬 수자르기
	$HislandNumber = $remainNumber;

	# 대전 상대결정
	if($fight_check == 1) {
 if($Htournament == 1) {
 undef %HidToNumber;
 # HidToNumber 작성 (곧바로 위에서 islandSort를 실행하므로)
 for($i = 0; $i < $HislandNumber; $i++) {
 my $island = $Hislands[$i];
 $HidToNumber{$Hislands[$i]->{'id'}} = $i;
 }
 }

 if($Htournament == 1 and $HislandChart) {
 # 토너먼트 표형식

 # 위에서부터 순서대로 할당
 my $chart = $HislandChart;
 while($chart =~ s/$HislandFightCount,([0-9]+),//) {
 my $num = $HidToNumber{$1};
 my $island = $Hislands[$num];

 if($chart =~ s/$HislandFightCount,([0-9]+),//) {
 my $num2 = $HidToNumber{$1};
 my $tIsland = $Hislands[$num2];
 $island->{'fight_id'} = $tIsland->{'id'};
 $tIsland->{'fight_id'} = $island->{'id'};
 } else {
 # 부전승
 $island->{'fight_id'} = -1;
 $island->{'rest'} += $HnofightTurn + $HislandFightCount * $HnofightUp;
 }
 }
 } else {
 # 섬력순

 # 섬력계산
 for($i = 0; $i < $HislandNumber; $i++) {
 doIslandPower($Hislands[$i]);
 }

 # 섬력순에정렬
 islandPowerSort();

 # 대전 상대결정
 for($i = 0; $i < $HislandNumber; $i++) {
 $island = $HislandPower[$i];
 next if($island->{'fight_id'}> 0);

 if($i + 1 == $HislandNumber) {
 # 부전승 개발 정지
 $island->{'fight_id'} = -1;
 $island->{'rest'}	 += $HnofightTurn + $HislandFightCount * $HnofightUp;
 $HislandChart.= "0,$island->{'id'},$island->{'name'} 섬\"0,-\"";
 } else {
 $tIsland = $HislandPower[$i+1];
 $island->{'fight_id'} = $tIsland->{'id'};
 $tIsland->{'fight_id'} = $island->{'id'};
 $HislandChart.= "0,$island->{'id'},$island->{'name'} 섬\"0,$tIsland->{'id'},$tIsland->{'name'} 섬\"";
 }
 }
 }

 if($Htournament == 1) {
 require('hako-chart.cgi');
 makeChartPage();
 }
	}

	# 대전 기록백업용
	if(($winlose == 1) or (($HislandTurn % $HbackupTurn) == 0)){
		open(FOUT, "${HdirName}/fight.log");
		while($f = <FOUT>){
			chomp($f);
			push(@offset,"$f\n");
		}
		close(FOUT);
	}

	# 백업 턴이면 삭제 전에 rename
	if(($HislandTurn % $HbackupTurn) == 0) {
		my($i);
		my($tmp) = $HbackupTimes - 1;
		myrmtree("${HdirName}.bak$tmp");
		for($i = ($HbackupTimes - 1); $i> 0; $i--) {
			my($j) = $i - 1;
			rename("${HdirName}.bak$j", "${HdirName}.bak$i");
		}
		rename("${HdirName}", "${HdirName}.bak0");
		mkdir("${HdirName}", $HdirMode);

		# 로그 파일만 복구
		for($i = 0; $i <= $HlogMax; $i++) {
			rename("${HdirName}.bak0/hakojima.log$i",
				 "${HdirName}/hakojima.log$i");
		}
		rename("${HdirName}.bak0/hakojima.his",
			 "${HdirName}/hakojima.his");

		# 대전 기록저장
		open(BDOUT, ">${HdirName}/fight.log.bak");
		print BDOUT @offset;
		close(BDOUT);
		rename("${HdirName}/fight.log.bak","${HdirName}/fight.log");
	}

	Hlog_yosen() if($HislandTurn == $HyosenTurn);

	Hfihgt_log() if($winlose == 1);

	# 파일에쓰기
	writeIslandsFile(-1);

	# 파일읽기
	readIslandsFile();

	# 로그 쓰기
	logFlush();

	# 로그 삭제
	log_delete() if(@delete_log);

	# 기록 로그 조정
	logHistoryTrim();

	# 맨 위로
	topPageMain();
}

# 디렉터리 삭제
sub myrmtree {
	my($dn) = @_;
	opendir(DIN, "$dn/");
	my($fileName);
	while($fileName = readdir(DIN)) {
		unlink("$dn/$fileName");
	}
	closedir(DIN);
	rmdir($dn);
}

# 수입, 소비단계
sub income {
	my($island) = @_;
	my($pop, $farm, $factory, $mountain) =
		(
		 $island->{'pop'},
		 $island->{'farm'} * 10,
		 $island->{'factory'},
		 $island->{'mountain'}
		 );

	# 수입
	if($pop> $farm) {
		# 농업만으로 인력이 남는 경우
		$island->{'food'} += $farm; # 농장 전체가동
		$island->{'money'} +=
			min(int(($pop - $farm) / 10), $factory + $mountain);
	} else {
		# 농장 규모가 최대치인 경우
		$island->{'food'} += $pop; # 전체나 생 직원일
	}

	# 식량소비
	$island->{'food'} = int(($island->{'food'}) - ($pop * $HeatenFood));
	$island->{'down'} = 1 if($pop - ($farm + $factory * 10 + $mountain * 10)>= $Hno_work);
}


# 명령 단계
sub doCommand {
	my($island) = @_;

	# 명령 처리 시작
	my($comArray, $command);
	$comArray = $island->{'command'};
	$command = $comArray->[0];		# 첫 항목을 꺼냄
	slideFront($comArray, 0);		# 이후를 막힘하기

	# 각 요소 꺼내기
	my($kind, $target, $x, $y, $arg) =
		(
		 $command->{'kind'},
		 $command->{'target'},
		 $command->{'x'},
		 $command->{'y'},
		 $command->{'arg'}
		 );

	# 도출 값
	my($name) = $island->{'name'};
	my($id) = $island->{'id'};
	my($land) = $island->{'land'};
	my($landValue) = $island->{'landValue'};
	my($landKind) = $land->[$x][$y];
	my($lv) = $landValue->[$x][$y];
	my($cost) = $HcomCost[$kind];
	my($comName) = $HcomName[$kind];
	my($point) = "($x, $y)";
	my($landName) = landName($landKind, $lv);

	if($kind == $HcomDoNothing) {
		# 자금 조달
		logDoNothing($id, $name, $comName);
		$island->{'money'} += 10;
		$island->{'absent'} ++;

		# 자동포기
		if($island->{'absent'}>= $HgiveupTurn) {
			$comArray->[0] = {
				'kind' => $HcomGiveup,
				'target' => 0,
				'x' => 0,
				'y' => 0,
				'arg' => 0
			}
		}
		return 1;
	}

	$island->{'absent'} = 0;

	# 비용 확인
	if($cost> 0) {
		# 금의 경우
		if($island->{'money'} < $cost) {
			logNoMoney($id, $name, $comName);
			return 0;
		}
	} elsif($cost < 0) {
		# 식량의 경우
		if($island->{'food'} < (-$cost)) {
			logNoFood($id, $name, $comName);
			return 0;
		}
	}

	if(($kind == $HcomAutoPrepare3 or $kind == $HcomFastFarm) and ($HislandFightMode == 1)){
		logLandNG($id, $name, $comName, '현재전투 기간 중이어서 ');
		return 0;
	}

	# 명령에서 분기
	if(($kind == $HcomPrepare) ||
	 ($kind == $HcomPrepare2)) {
		# 개간, 땅고르기
		if(($landKind == $HlandSea) ||
		 ($landKind == $HlandMountain)) {
			# 바다, 산, 괴수는 개간할 수 없
			logLandFail($id, $name, $comName, $landName, $point);
			return 0;
		}

		# 대상 위치를 평지로
		$land->[$x][$y] = $HlandPlains;
		$landValue->[$x][$y] = 0;
		logLandSuc($id, $name, '개간', $point);

		# 돈을 차감
		$island->{'money'} -= $cost;

		if($kind == $HcomPrepare2) {
			# 땅고르기
			# 턴 소비하지 않고
			return 0;
		} else {
			# 개간
			return 1;
		}
	} elsif($kind == $HcomAutoPrepare3) {
		# 일괄 자동 땅고르기
		my($prepareM, $preFlag) = ($HcomCost[$HcomPrepare2], 0);
		for($i = 0; $i < $HpointNumber; $i++) {
			$bx = $Hrpx[$i];
			$by = $Hrpy[$i];
			if(($land->[$bx][$by] == $HlandWaste) && ($island->{'money'}>= $prepareM)){
				# 대상 위치를 평지로
				$land->[$bx][$by] = $HlandPlains;
				$landValue->[$bx][$by] = 0;
				logLandSuc($id, $name, '개간', "($bx, $by)");
				# 돈을 차감
				$island->{'money'} -= $prepareM;
				$island->{'prepare2'}++;
				$preFlag++;
				if($preFlag == $precheap){ $prepareM = int($prepareM * $precheap2 / 10); }
			}
		}
		# 턴 소비하지 않고
		return 0;
	} elsif($kind == $HcomReclaim) {
		# 매립
		if($landKind != $HlandSea) {
			# 바다, 만매립할 수 없
			logLandFail($id, $name, $comName, $landName, $point);
			return 0;
		}

		# 주변에육이 있는 지 확인
		my($seaCount) =	(countAround($land, $x, $y, $HlandSea, 7));

		if($seaCount == 7) {
			# 전체 바다다에서 매립불능
			logNoLandAround($id, $name, $comName, $point);
			return 0;
		}

		if(($landKind == $HlandSea and $lv == 1) or $HeasyReclaim) {
			# 얕은 바다의 경우
			# 대상 위치를 황무지로
			$land->[$x][$y] = $HlandWaste;
			$landValue->[$x][$y] = 0;
			logLandSuc($id, $name, $comName, $point);
			$island->{'area'}++;

			if($seaCount <= 4) {
				# 주변 바다가 3헥스 이내이므로, 얕은 바다로
				my($i, $sx, $sy);

				for($i = 1; $i < 7; $i++) {
					$sx = $x + $ax[$i];
					$sy = $y + $ay[$i];

					# 행 기준 위치 조정
					if((($sy % 2) == 0) && (($y % 2) == 1)) {
						$sx--;
					}

					if(($sx < 0) || ($sx>= $HislandSize) ||
					 ($sy < 0) || ($sy>= $HislandSize)) {
					} else {
						# 범위 안의 경우
						if($land->[$sx][$sy] == $HlandSea) {
							$landValue->[$sx][$sy] = 1;
						}
					}
				}
			}
		} else {
			# 바다이면 대상 위치를 얕은 바다로 변경
			$land->[$x][$y] = $HlandSea;
			$landValue->[$x][$y] = 1;
			logLandSuc($id, $name, $comName, $point);
		}

		# 돈을 차감
		$island->{'money'} -= $cost;
		return 1;
	} elsif($kind == $HcomDestroy) {
		# 굴착
		if($landKind == $HlandSea and $lv == 0) {
			# 바다는 굴착할 수 없
			logLandFail($id, $name, $comName, $landName, $point);
			return 0;
		}

		# 대상 위치를 바다로 변경. 산이면 황무지로, 얕은 바다이면 바다로 변경.
		if($landKind == $HlandMountain) {
			$land->[$x][$y] = $HlandWaste;
			$landValue->[$x][$y] = 0;
		} elsif($landKind == $HlandSea) {
			$landValue->[$x][$y] = 0;
		} else {
			$land->[$x][$y] = $HlandSea;
			$landValue->[$x][$y] = 1;
			$island->{'area'}--;
		}
		logLandSuc($id, $name, $comName, $point);

		# 돈을 차감
		$island->{'money'} -= $cost;
		return 1;
	} elsif($kind == $HcomSellTree) {
		# 벌채
		if(!(($landKind == $HlandForest) || ($landKind == $HlandDefence))) {
			# 숲, 방위 시설이외는 벌채할 수 없
			logLandFail($id, $name, $comName, $landName, $point);
			return 0;
		}

		# 대상 위치를 평지로
		$land->[$x][$y] = $HlandPlains;
		$landValue->[$x][$y] = 0;
		logLandSuc($id, $name, $comName, $point);

		# 매각금을 얻기루
		if($landKind == $HlandDefence){
			$island->{'money'} += $HdefenceValue;
			logSecretSell($id, $name, $landName, $point);
		} else {
			$island->{'money'} += $HtreeValue * $lv;
		}

		return 0;
	} elsif(($kind == $HcomPlant) ||
			($kind == $HcomFarm) ||
			($kind == $HcomFactory) ||
			($kind == $HcomBase) ||
			($kind == $HcomHaribote) ||
			($kind == $HcomFastFarm) ||
			($kind == $HcomDbase)) {

		# 지상건설계
		if(!
		 (($landKind == $HlandPlains) ||
			($landKind == $HlandTown) ||
			(($landKind == $HlandFarm) && ($kind == $HcomFarm)) ||
			(($landKind == $HlandFarm) && ($kind == $HcomFastFarm)) ||
			(($landKind == $HlandFactory) && ($kind == $HcomFactory)))) {
			# 부적절나 지형
			logLandFail($id, $name, $comName, $landName, $point);
			return 0;
		}

		# 종류에서 분기
		if($kind == $HcomPlant) {
			# 대상 위치를 숲로.
			$land->[$x][$y] = $HlandForest;
			$landValue->[$x][$y] = 1; # 목은 최소단위
			logPBSuc($id, $name, $comName, $point);
		} elsif($kind == $HcomBase) {
			# 대상 위치를 미사일 기지로.
			$land->[$x][$y] = $HlandBase;
			$landValue->[$x][$y] = 0; # 경험치0
			logPBSuc($id, $name, $comName, $point) if($Hhide_missile);
			logLandSuc($id, $name, $comName, $point) if(!$Hhide_missile);
			$island->{'missile'}++ if($HislandFightMode == 1);
		} elsif($kind == $HcomHaribote) {
			# 대상 위치를 가짜 시설로
			$land->[$x][$y] = $HlandHaribote;
			$landValue->[$x][$y] = 0;
			logHariSuc($id, $name, $comName, $HcomName[$HcomDbase], $point);
		} elsif($kind == $HcomFarm or $kind == $HcomFastFarm) {
			# 농장
			if($landKind == $HlandFarm) {
				# 이미 농장의 경우
				$landValue->[$x][$y] += 2; # 규모 + 2000인
				if($landValue->[$x][$y]> 50) {
					$landValue->[$x][$y] = 50; # 최대 50000인
				}
			} else {
				# 대상 위치를 농장에
				$land->[$x][$y] = $HlandFarm;
				$landValue->[$x][$y] = 10; # 규모 = 10000인
			}
			logPBSuc($id, $name, $comName, $point) if($Hhide_farm);
			logLandSuc($id, $name, $comName, $point) if(!$Hhide_farm);
			if($kind == $HcomFastFarm){
				$island->{'money'} -= $cost;
				return 0;
			}
		} elsif($kind == $HcomFactory) {
			# 공장
			if($landKind == $HlandFactory) {
				# 이미 공장의 경우
				$landValue->[$x][$y] += 10; # 규모 + 10000인
				if($landValue->[$x][$y]> 100) {
					$landValue->[$x][$y] = 100; # 최대 100000인
				}
			} else {
				# 대상 위치를 공장에
				$land->[$x][$y] = $HlandFactory;
				$landValue->[$x][$y] = 30; # 규모 = 10000인
			}
			logPBSuc($id, $name, $comName, $point) if($Hhide_factory);
			logLandSuc($id, $name, $comName, $point) if(!$Hhide_factory);
		} elsif($kind == $HcomDbase) {
			# 방위 시설
			# 대상 위치를 방위 시설에
			$land->[$x][$y] = $HlandDefence;
			$landValue->[$x][$y] = 0;
			logPBSuc($id, $name, $comName, $point) if($Hhide_deffence);
			logLandSuc($id, $name, $comName, $point) if(!$Hhide_deffence);
			$island->{'missile'}++ if($HislandFightMode == 1);
		}

		# 돈을 차감
		$island->{'money'} -= $cost;

		# 횟수 지정이면, 명령을 되돌림
		if(($kind == $HcomFarm) ||
		 ($kind == $HcomFactory)) {
			if($arg> 1) {
				my($command);
				$arg--;
				slideBack($comArray, 0);
				$comArray->[0] = {
					'kind' => $kind,
					'target' => $target,
					'x' => $x,
					'y' => $y,
					'arg' => $arg
					};
			}
		}

		return 1;
	} elsif($kind == $HcomMountain) {
		# 채굴장
		if($landKind != $HlandMountain) {
			# 산이외에는 만들 수 없음
			logLandFail($id, $name, $comName, $landName, $point);
			return 0;
		}

		$landValue->[$x][$y] += 5; # 규모 + 5000인
		if($landValue->[$x][$y]> 200) {
			$landValue->[$x][$y] = 200; # 최대 200000인
		}
		logLandSuc($id, $name, $comName, $point);

		# 돈을 차감
		$island->{'money'} -= $cost;
		if($arg> 1) {
			my($command);
			$arg--;
			slideBack($comArray, 0);
			$comArray->[0] = {
				'kind' => $kind,
				'target' => $target,
				'x' => $x,
				'y' => $y,
				'arg' => $arg
				};
		}
		return 1;
	} elsif($kind == $HcomMissileNM || $kind == $HcomMissilePP) {
		# 미사일계
		# 대상 가져오기
		my($tn) = $HidToNumber{$target};
		if($tn eq '') {
			# 대상이 이미 없음
			logMsNoTarget($id, $name, $comName);
			return 0;
		}

		my($flag) = 0;
		if($arg == 0) {
			# 값이 0이면 공격 중인 대상만
			$arg = 10000;
		}

		# 사전준비
		my($tIsland) = $Hislands[$tn];
		my($tName) = $tIsland->{'name'};
		my($tLand) = $tIsland->{'land'};
		my($tLandValue) = $tIsland->{'landValue'};
		my($tx, $ty, $err);

		# 발사 가능아니오 확인
		if($HislandFightMode == 0) {
			# 개발 기간이므로 중지
			logLandNG($id, $name, $comName, '현재 개발 기간 중이어서 ');
			return 0;
		} elsif($island->{'fight_id'} != $tIsland->{'id'}) {
			# 대전 상대가 아닌 경우
			logLandNG($id, $name, $comName, '목표가 대전 상대가 아니어서 ');
			return 0;
		}

		# 난민의 수
		my($boat) = 0;

		# 오차
		if($kind == $HcomMissilePP) {
			$err = 7;
		} else {
			$err = 19;
		}

		# 전투 행위 횟수카운트
		$island->{'missile'}++ if($HislandFightMode == 1);

		# 자금이 부족하면 지정수량을 충족하거나 전체 기지 가격에 도달할 시까지 반복
		my($bx, $by, $count, $ms_count) = (0,0,0,0);
		while(($arg> 0) &&
			 ($island->{'money'}>= $cost)) {
			# 기지를 찾을 시까지 반복
			while($count < $HpointNumber) {
				$bx = $Hrpx[$count];
				$by = $Hrpy[$count];
				if($land->[$bx][$by] == $HlandBase) {
					last;
				}
				$count++;
			}
			if($count>= $HpointNumber) {
				# 찾을 수 없으면 그곳까지
				last;
			}
			# 최소하나기지가 있었던이므로,flag 을설립하고 있는
#			$flag++;

			# 기지의 레벨을 산출
			my($level) = expToLevel($land->[$bx][$by], $landValue->[$bx][$by]);
			# 기지내에서 루프
			while(($level> 0) &&
				 ($arg> 0) &&
				 ($island->{'money'}> $cost)) {
				# 명중이 확정이므로, 각 값을 소도
				$level--;
				$arg--;
				$island->{'money'} -= $cost;

				# 미사일 발사 수카운트
				$island->{'fly'}++;
				$tIsland->{'fly'}++;
				$flag++;

				# 착탄 지점 산출
				my($r) = random($err);
				$tx = $x + $ax[$r];
				$ty = $y + $ay[$r];
				if((($ty % 2) == 0) && (($y % 2) == 1)) {
					$tx--;
				}

				# 착탄 지점범위안팎 확인
				if(($tx < 0) || ($tx>= $HislandSize) ||
				 ($ty < 0) || ($ty>= $HislandSize)) {
					# 범위 밖
					logMsOut($id, $target, $name, $tName, $comName, $point);
					next;
				}

				# 착탄 지점의 지형등 산출
				my($tL) = $tLand->[$tx][$ty];
				my($tLv) = $tLandValue->[$tx][$ty];
				my($tLname) = landName($tL, $tLv);
				my($tPoint) = "($tx, $ty)";

				# 방위 시설 판정
				my($defence) = 0;
				if($HdefenceHex[$id][$tx][$ty] == 1) {
					$defence = 1;
				} elsif($HdefenceHex[$id][$tx][$ty] == -1) {
					$defence = 0;
				} else {
					if($tL == $HlandDefence) {
						# 방위 시설에 명중
						# 플래그를 지우기
						my($i, $count, $sx, $sy);
						for($i = 0; $i < 19; $i++) {
							$sx = $tx + $ax[$i];
							$sy = $ty + $ay[$i];

							# 행 기준 위치 조정
							if((($sy % 2) == 0) && (($ty % 2) == 1)) {
								$sx--;
							}

							if(($sx < 0) || ($sx>= $HislandSize) ||
							 ($sy < 0) || ($sy>= $HislandSize)) {
								# 범위 밖이면 아무것도 하지 않음
							} else {
								# 범위 안의 경우
								$HdefenceHex[$id][$sx][$sy] = 0;
							}
						}
					} elsif(countAround($tLand, $tx, $ty, $HlandDefence, 19)) {
						$HdefenceHex[$id][$tx][$ty] = 1;
						$defence = 1;
					} else {
						$HdefenceHex[$id][$tx][$ty] = -1;
						$defence = 0;
					}
				}

				if($defence == 1) {
					# 공안폭파
					logMsCaught($id, $target, $name, $tName, $comName, $point, $tPoint);
					next;
				}

				# '효과 없음' hex를 먼저 판정: 바다 또는 산
				if($tL == $HlandSea || $tL == $HlandMountain) {
					$tLname = landName($tL, $tLv);

					# 무효화
					logMsNoDamage($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint);
					next;
				}

				# 미사일
				if($tL == $HlandWaste) {
					# 황무지(피해없음)
					logMsWaste($id, $target, $name, $tName,	$comName, $tLname, $point, $tPoint);
				} else {
					if($tL == $HlandTown) {
						# 도시
						logMsTown($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint, $tLv);
					} else {
						# 일반 지형
						logMsNormal($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint);
					}
				}

				# 경험치
				if($tL == $HlandTown) {
					if($land->[$bx][$by] == $HlandBase) {
						$landValue->[$bx][$by] += int($tLv / 20);
						$boat += $tLv; # 일반 미사일이므로 난민에플러스
						if($landValue->[$bx][$by]> $HmaxExpPoint) {
							$landValue->[$bx][$by] = $HmaxExpPoint;
						}
					}
				} elsif($tL == $HlandDefence){
					# 대전 기록용유지
					$island->{'log'} += 1000;
					$tIsland->{'reward'} += $HcomCost[$HcomDbase] if($HrewardMode == 2);
				} elsif($tL == $HlandBase){
					$island->{'log'} ++;
					$tIsland->{'reward'} += $HcomCost[$HcomBase] if($HrewardMode == 2);
				} elsif($tL == $HlandFarm and $HrewardMode == 2){
					$tIsland->{'reward'} += $HcomCost[$HcomFarm];
				} elsif($tL == $HlandFactory and $HrewardMode == 2){
					$tIsland->{'reward'} += $HcomCost[$HcomFactory];
				}


				# 황무지가 됨
				$tLand->[$tx][$ty] = $HlandWaste;
				$tLandValue->[$tx][$ty] = 1; # 착탄 지점

			}

			# 카운트 증가
			$count++;
		}


		if($flag> 0) {
			# 미사일 발사 수
			logComMissle($id, $name, $tName, $comName, $point, $flag) if($Hmissile_log);
		} else {
			# 기지가 하나도 없어진 경우
			logMsNoBase($id, $name, $comName);
			return 0;
		}

		# 난민판정
		$boat = int($boat / 2);
		if(($boat> 0) && ($id != $target) && ($kind != $HcomMissileST)) {
			# 난민표착
			my($achive); # 도달난민
			my($i);
			for($i = 0; ($i < $HpointNumber && $boat> 0); $i++) {
				$bx = $Hrpx[$i];
				$by = $Hrpy[$i];
				if($land->[$bx][$by] == $HlandTown) {
					# 마을의 경우
					my($lv) = $landValue->[$bx][$by];
					if($boat> 50) {
						$lv += 50;
						$boat -= 50;
						$achive += 50;
					} else {
						$lv += $boat;
						$achive += $boat;
						$boat = 0;
					}
					if($lv> 200) {
						$boat += ($lv - 200);
						$achive -= ($lv - 200);
						$lv = 200;
					}
					$landValue->[$bx][$by] = $lv;
				} elsif($land->[$bx][$by] == $HlandPlains) {
					# 평지의 경우
					$land->[$bx][$by] = $HlandTown;;
					if($boat> 10) {
						$landValue->[$bx][$by] = 5;
						$boat -= 10;
						$achive += 10;
					} elsif($boat> 5) {
						$landValue->[$bx][$by] = $boat - 5;
						$achive += $boat;
						$boat = 0;
					}
				}
				if($boat <= 0) {
					last;
				}
			}
			if($achive> 0) {
				# 조금이라도 도착한 경우 로그를 출력
				logMsBoatPeople($id, $name, $achive);

				# 난민의 수가일정수이상라면, 평화상의 가능성있음
				if($achive>= 200) {
					my($flags) = $island->{'prize'};

					if((!($flags & 8)) && $achive>= 200){
						$flags |= 8;
						logPrize($id, $name, $Hprize[4]);
					} elsif((!($flags & 16)) && $achive> 500){
						$flags |= 16;
						logPrize($id, $name, $Hprize[5]);
					} elsif((!($flags & 32)) && $achive> 800){
						$flags |= 32;
						logPrize($id, $name, $Hprize[6]);
					}
					$island->{'prize'} = $flags;
				}
			}
		}
		return 1;
	} elsif($kind == $HcomSell) {
		# 수출량 결정
		if($arg == 0) { $arg = 1; }
		my($value) = min($arg * (-$cost), $island->{'food'});

		# 수출 로그
		logSell($id, $name, $comName, $value);
		$island->{'food'} -= $value;
		$island->{'money'} += ($value / 10);
		return 0;
	} elsif($kind == $HcomGiveup) {
		# 포기
		logGiveup($id, $name);
		$island->{'dead'} = 1;
		return 1;
	}

	return 1;
}


# 성장 및 단일 헥스 재해
sub doEachHex {
	my($island) = @_;

	# 도출 값
	my($name) = $island->{'name'};
	my($id) = $island->{'id'};
	my($land) = $island->{'land'};
	my($landValue) = $island->{'landValue'};

	# 늘어나면인구의 타네 값
	my($addpop) = $HtownUp; # 마을, 마을
	$addpop = 0 if(($HislandTurn <= $HyosenTurn) and 	# 연속 자금 조달 또는 생산시설 부족이 없는 경우 중단
				($island->{'absent'}>= $HstopAddPop or $island->{'down'}));
	$addpop = -30 if($island->{'food'} < 0);	# 식량 부족

	# 루프
	my($x, $y, $i);
	for($i = 0; $i < $HpointNumber; $i++) {
		$x = $Hrpx[$i];
		$y = $Hrpy[$i];
		my($landKind) = $land->[$x][$y];
		my($lv) = $landValue->[$x][$y];

		if($landKind == $HlandTown) {
			# 마을 계열
			if($addpop < 0) {
				# 부족
				$lv -= (random(-$addpop) + 1);
				if($lv <= 0) {
					# 평지로 되돌리기
					$land->[$x][$y] = $HlandPlains;
					$landValue->[$x][$y] = 0;
					next;
				}
			} elsif($addpop> 0) {
				# 성장
				if($lv < 100) {
					$lv += random($addpop) + 1;
					$lv = 100 if($lv> 100);
				}
			}

			$lv = 200 if($lv> 200);
			$landValue->[$x][$y] = $lv;
		} elsif($landKind == $HlandPlains and $addpop> 0) {
			# 평지
			if($HtownGlow>=random(100)) {
				# 주변에 농장, 마을이 있다면, 여기도 마을이 됨
				if(countGrow($land, $landValue, $x, $y)){
					$land->[$x][$y] = $HlandTown;
					$landValue->[$x][$y] = 1;
				}
			}
		} elsif($landKind == $HlandForest) {
			# 숲
			$lv += $HtreeUp;			# 나무가 늘어남
			$lv = 200 if($lv> 200);	# 최대 수 초과한 경우
			$landValue->[$x][$y] = $lv; # 대입
		}
	}

	if($HislandFightMode == 1) {
		if((int($HfightTurn / 2) == ($HislandChangeTurn - $HislandTurn)) and ($island->{'missile'} < $do_fight)) {
			if($island->{'fight_id'}> 0) {
				my $HcurrentNumber = $HidToNumber{$island->{'fight_id'}};
				my $tIsland = $Hislands[$HcurrentNumber];
				if($tIsland->{'dead'} == 0) {
					logGiveup_no_do_fight($id, $name);
					$island->{'dead'} = 1;
				}
			}
		}
	}

}

# 주변의 마을, 농장이 있는 지반정
sub countGrow {
	my($land, $landValue, $x, $y) = @_;
	my($i, $sx, $sy);
	for($i = 1; $i < 7; $i++) {
		 $sx = $x + $ax[$i];
		 $sy = $y + $ay[$i];

		 # 행 기준 위치 조정
		 if((($sy % 2) == 0) && (($y % 2) == 1)) {
			 $sx--;
		 }

		 if(($sx < 0) || ($sx>= $HislandSize) ||
			($sy < 0) || ($sy>= $HislandSize)) {
		 } else {
			 # 범위 안의 경우
			 if(($land->[$sx][$sy] == $HlandTown) ||
				($land->[$sx][$sy] == $HlandFarm)) {
				 if($landValue->[$sx][$sy] != 1) {
					 return 1;
				 }
			 }
		 }
	}
	return 0;
}

# 섬 전체
sub doIslandProcess {
	my($number, $island) = @_;

	# 도출 값
	my($name) = $island->{'name'};
	my($id) = $island->{'id'};
	my($land) = $island->{'land'};
	my($landValue) = $island->{'landValue'};

	# 식량 부족
	if($island->{'food'} < 0) {
		# 부족 메시지
		logStarve($id, $name);
		$island->{'food'} = 0;

		my($x, $y, $landKind, $lv, $i);
		for($i = 0; $i < $HpointNumber; $i++) {
			$x = $Hrpx[$i];
			$y = $Hrpy[$i];
			$landKind = $land->[$x][$y];
			$lv = $landValue->[$x][$y];

			if(($landKind == $HlandFarm) ||
			 ($landKind == $HlandFactory) ||
			 ($landKind == $HlandBase) ||
			 ($landKind == $HlandDefence)) {
				# 1/4에서 괴멸
				if(random(4) == 0) {
					logSvDamage($id, $name, landName($landKind, $lv),
								"($x, $y)");
					$land->[$x][$y] = $HlandWaste;
					$landValue->[$x][$y] = 0;
				}
			}
		}
	}


	# 지반 침하판정
	if(($island->{'area'}> $HdisFallBorder) &&
	 (random(1000) < $HdisFalldown)) {
		# 지반 침하발생
		logFalldown($id, $name);

		my($x, $y, $landKind, $lv, $i);
		for($i = 0; $i < $HpointNumber; $i++) {
			$x = $Hrpx[$i];
			$y = $Hrpy[$i];
			$landKind = $land->[$x][$y];
			$lv = $landValue->[$x][$y];

			if(($landKind != $HlandSea) &&
			 ($landKind != $HlandMountain)) {

				# 주변에 바다가 있다면, 값을-1에
				if(countAround($land, $x, $y, $HlandSea, 7)) {
					logFalldownLand($id, $name, landName($landKind, $lv),
								"($x, $y)");
					$land->[$x][$y] = -1;
					$landValue->[$x][$y] = 0;
				}
			}
		}

		for($i = 0; $i < $HpointNumber; $i++) {
			$x = $Hrpx[$i];
			$y = $Hrpy[$i];
			$landKind = $land->[$x][$y];

			if($landKind == -1) {
				# -1에나하고 있는 장소를 얕은 바다에
				$land->[$x][$y] = $HlandSea;
				$landValue->[$x][$y] = 1;
			} elsif ($landKind == $HlandSea) {
				# 얕은 바다는 바다에
				$landValue->[$x][$y] = 0;
			}

		}
	}

	# 식량이 넘치면 환전
	if($island->{'food'}> 9999) {
		$island->{'money'} += int(($island->{'food'} - 9999) / 10);
		$island->{'food'} = 9999;
	}

	# 각종의 값을 계산
	estimate($number);

	# 번영, 재난상
	$pop = $island->{'pop'};
	my($damage) = $island->{'oldPop'} - $pop;
	my($flags) = $island->{'prize'};

	# 번영상
	if((!($flags & 1)) && $pop>= 3000){
		$flags |= 1;
		logPrize($id, $name, $Hprize[1]);
	} elsif((!($flags & 2)) && $pop>= 5000){
		$flags |= 2;
		logPrize($id, $name, $Hprize[2]);
	} elsif((!($flags & 4)) && $pop>= 10000){
		$flags |= 4;
		logPrize($id, $name, $Hprize[3]);
	}

	# 재난상
	if((!($flags & 64)) && $damage>= 500){
		$flags |= 64;
		logPrize($id, $name, $Hprize[7]);
	} elsif((!($flags & 128)) && $damage>= 1000){
		$flags |= 128;
		logPrize($id, $name, $Hprize[8]);
	} elsif((!($flags & 256)) && $damage>= 2000){
		$flags |= 256;
		logPrize($id, $name, $Hprize[9]);
	}

	$island->{'prize'} = $flags;
}

# 섬력계산
sub doIslandPower {
	my($island) = @_;

	my $power = 25 * ($island->{'farm'} + $island->{'factory'} + $island->{'mountain'} + $island->{'pop'} / 10)
	 + 700 * $island->{'area'} + 1000 * $island->{'army'} +
	 aboutMoney2($island->{'money'}) + $island->{'forest'} - $island->{'waste'};

	$island->{'power'} = random($power) if $power> 0;
}

# 섬력순에정렬
sub islandPowerSort {
	my($flag, $i, $tmp);

	# 인구가 같으면 이전 턴의 순서를 유지
	my @idx = (0..$#Hislands);
	@idx = sort { $Hislands[$b]->{'power'} <=> $Hislands[$a]->{'power'} || $a <=> $b } @idx;
	@HislandPower = @Hislands[@idx];
}

# 인구순에정렬
sub islandSort {
	my($flag, $i, $tmp);

	# 인구가 같으면 이전 턴의 순서를 유지
	my @idx = (0..$#Hislands);
	@idx = sort { $Hislands[$b]->{'pop'} <=> $Hislands[$a]->{'pop'} || $a <=> $b } @idx;
	@Hislands = @Hislands[@idx];
}

# 로그로 출력
# 제1인 수:메시지
# 제2인 수:당사자
# 제3인 수:상대
# 일반 로그
sub logOut {
	push(@HlogPool,"0,$HislandTurn,$_[1],$_[2],$_[0]");
}

# 지연 로그
sub logLate {
	push(@HlateLogPool,"0,$HislandTurn,$_[1],$_[2],$_[0]");
}

# 기밀 로그
sub logSecret {
	push(@HsecretLogPool,"1,$HislandTurn,$_[1],$_[2],$_[0]");
}

# 미사일 발사 로그
sub logOutM {
	push(@HlogPool,"2,$HislandTurn,$_[1],$_[2],$_[0]");
}

# 기록 로그
sub logHistory {
	open(HOUT, ">>${HdirName}/hakojima.his");
	print HOUT "$HislandTurn,$_[0]\n";
	close(HOUT);
}

# 기록 로그 조정
sub logHistoryTrim {
	open(HIN, "${HdirName}/hakojima.his");
	my(@line, $l, $count);
	$count = 0;
	while($l = <HIN>) {
		chomp($l);
		push(@line, $l);
		$count++;
	}
	close(HIN);

	if($count> $HhistoryMax) {
		open(HOUT, ">${HdirName}/hakojima.his");
		my($i);
		for($i = ($count - $HhistoryMax); $i < $count; $i++) {
			print HOUT "$line[$i]\n";
		}
		close(HOUT);
	}
}

# 로그 쓰기
sub logFlush {
	open(LOUT, ">${HdirName}/hakojima.log0");

	# 전체를 역순으로 출력
	my($i);
	for($i = $#HsecretLogPool; $i>= 0; $i--) {
		print LOUT $HsecretLogPool[$i];
		print LOUT "\n";
	}
	for($i = $#HlateLogPool; $i>= 0; $i--) {
		print LOUT $HlateLogPool[$i];
		print LOUT "\n";
	}
	for($i = $#HlogPool; $i>= 0; $i--) {
		print LOUT $HlogPool[$i];
		print LOUT "\n";
	}
	close(LOUT);
}

# 로그 삭제
sub log_delete {
	my ($line,$bk);
	for($i = 0;$i < $HlogMax;$i++) {
		my @lines;
		my @olines;
		open(LIN, "${HdirName}/hakojima.log${i}");
		@lines = <LIN>;
		close(LIN);

		foreach $line (@lines) {
			my $ng = 0;
			$bk = $line;
			$line =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),(.*)$/;
			($m, $turn, $id1, $id2, $message) = ($1, $2, $3, $4, $5);
			for($f = 0;$f <= $#delete_log;$f++) {
				$ng = 1 if($delete_log[$f] == $id1 or $delete_log[$f] == $id2);
			}
			push(@olines,$bk) if($ng == 0);
		}

		open(LOUT, ">${HdirName}/hakojima.log${i}");
		print LOUT @olines;
		close(LOUT);
	}
}

#----------------------------------------------------------------------
# 로그템플릿
#----------------------------------------------------------------------
sub log_debug {
	my($one, $two, $three) = @_;
	logOut("$one - $two - $three");
}

# 승리 로그
sub logWin {
	my($id, $name, $money) = @_;
	my $fTurn = $HislandFightCount + 1;
	if($HislandNumber == 4) {
		$fTurn = '결승전';
	} elsif($HislandNumber == 8) {
		$fTurn = '준결승';
	} else {
		$fTurn.= '회전';
	}
	if($HislandNumber == 2) {
		logOut("${HtagName_}${name} 섬${H_tagName}승리시,<B>우승!!</B>",$id);
		logHistory("${HtagName_}${name} 섬${H_tagName},<B>우승!!</B>");
	} elsif($money == 0) {
		logOut("${HtagName_}${name} 섬${H_tagName}승리시,<B>$fTurn 진출!</B>",$id);
	} else {
		logOut("${HtagName_}${name} 섬${H_tagName}승리시,<B>$fTurn 진출! $money$HunitMoney</B>의 보상금이 지급되었습니다.",$id);
	}
}

# 패배
sub logLose {
	my($id, $name) = @_;
	logOut("${HtagName_}${name} 섬${H_tagName},<B>패배</B>.",$id);
}

# 예선 탈락
sub logLoseOut {
	my($id, $name) = @_;
	logOut("${HtagName_}${name} 섬${H_tagName},<B>예선 탈락</B>.",$id);
	logHistory("${HtagName_}${name} 섬${H_tagName},<B>예선 탈락</B>.");
}

# 개발 기간 때문에 실패
sub logLandNG {
	my($id, $name, $comName, $cancel) = @_;
	logOut("${HtagName_}${name} 섬${H_tagName}에서 예정되어 있던${HtagComName_}$comName${H_tagComName}은,<B>$cancel</B>, 실행할 수 없었습니다.",$id);
END
}

# 자금 부족
sub logNoMoney {
	my($id, $name, $comName) = @_;
	logOut("${HtagName_}${name} 섬${H_tagName}에서 예정되어 있던${HtagComName_}$comName${H_tagComName}은, 자금이 부족해 중지되었습니다.",$id);
}

# 식량 부족
sub logNoFood {
	my($id, $name, $comName) = @_;
	logOut("${HtagName_}${name} 섬${H_tagName}에서 예정되어 있던${HtagComName_}$comName${H_tagComName}은, 비축 식량 부족으로 중지되었습니다.",$id);
}

# 대상 지형 종류 때문에 실패
sub logLandFail {
	my($id, $name, $comName, $kind, $point) = @_;
	logSecret("${HtagName_}${name} 섬${H_tagName}에서 예정되어 있던${HtagComName_}$comName${H_tagComName}은, 예정지 ${HtagName_}$point${H_tagName}이<B>$kind</B>였기 때문에 중지되었습니다.",$id);
END
}

# 주변에 육지가 없으면 매립 실패
sub logNoLandAround {
	my($id, $name, $comName, $point) = @_;
	logOut("${HtagName_}${name} 섬${H_tagName}에서 예정되어 있던${HtagComName_}$comName${H_tagComName}은, 예정지 ${HtagName_}$point${H_tagName} 주변에 육지가 없었기 때문에 중지되었습니다.",$id);
END
}

# 개간 계열 성공
sub logLandSuc {
	my($id, $name, $comName, $point) = @_;
	logOut("${HtagName_}${name} 섬 $point${H_tagName}에서${HtagComName_}${comName}${H_tagComName}이 실행되었습니다.",$id);
END
}

# 나무심기 or 미사일 기지
sub logPBSuc {
	my($id, $name, $comName, $point) = @_;
	logSecret("${HtagName_}${name} 섬 $point${H_tagName}에서${HtagComName_}${comName}${H_tagComName}이 실행되었습니다.",$id);
	logOut("어디선가 ${HtagName_}${name} 섬${H_tagName}의<B>숲</B>이 늘어난 것 같습니다.",$id);
END
}

# 방위 시설매각
sub logSecretSell {
 my($id, $name, $landName, $point) = @_;
 logSecret("${HtagName_}${name} 섬 $point${H_tagName}지점의<B>${landName}</b>이,${HtagComName_}매각${H_tagComName}됨했습니다.",$id);
END
}

# 가짜 시설
sub logHariSuc {
	my($id, $name, $comName, $comName2, $point) = @_;
	logSecret("${HtagName_}${name} 섬 $point${H_tagName}에서${HtagComName_}${comName}${H_tagComName}이 실행되었습니다.",$id);
	logLandSuc($id, $name, $comName2, $point);
END
}

# 미사일 발사 또는 괴수 파견 대상이 없음
sub logMsNoTarget {
	my($id, $name, $comName) = @_;
	logOut("${HtagName_}${name} 섬${H_tagName}에서 예정되어 있던${HtagComName_}${comName}${H_tagComName}은, 대상 섬이 무인도이므로 중지되었습니다.",$id);
END
}

# 미사일 발사실행
sub logComMissle {
	my($id, $name, $tName, $comName, $point, $count) = @_;
	logOutM("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해<b>$count 발</b>의${HtagComName_}${comName}${H_tagComName}을 실행했습니다.",$id);
END
}

# 미사일 발사를 시도했지만 기지가 없음
sub logMsNoBase {
	my($id, $name, $comName) = @_;
	logOut("${HtagName_}${name} 섬${H_tagName}에서 예정되어 있던${HtagComName_}${comName}${H_tagComName}은,<B>미사일 설비가 없어</B> 실행할 수 없었습니다.",$id);
END
}

# 미사일 발사 결과 범위 밖
sub logMsOut {
	my($id, $tId, $name, $tName, $comName, $point) = @_;
	logOut("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행했지만,<B>영역 밖의 바다</B>로 빗나간 모양입니다.",$id, $tId);
}

# 미사일이 방위 시설에 포착됨
sub logMsCaught {
	my($id, $tId, $name, $tName, $comName, $point, $tPoint) = @_;
	logOut("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행했지만,${HtagName_}$tPoint${H_tagName}지점 상공에서 역장에 포착되어,<B>공중 폭발</B>했습니다.",$id, $tId);
}

# 미사일 발사 결과 효과 없음
sub logMsNoDamage {
	my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
	logOut("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행했지만,${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 빗나가 피해가 없었습니다.",$id, $tId);
}

# 일반 미사일, 황무지에 착탄
sub logMsWaste {
	my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
	logOut("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행했지만,${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 떨어졌습니다.",$id, $tId);
}

# 일반 미사일 일반 지형에 명중
sub logMsNormal {
	my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
	logOut("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행하여,${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 명중, 일대가 괴멸되었습니다.",$id, $tId);
}

# 일반 미사일 도시 지형에 명중
sub logMsTown {
	my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint, $tLv) = @_;
	logOut("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행하여,${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 명중.<B>${tLv}${HunitPop}</B>의 희생희생자가였습니다.",$id, $tId);
}

# 난민 도착
sub logMsBoatPeople {
	my($id, $name, $achive) = @_;
	logOut("${HtagName_}${name} 섬${H_tagName}에어디선가<B>$achive${HunitPop}명의 난민</B>이 표류해 왔습니다.${HtagName_}${name} 섬${H_tagName}은 살기 좋아진 것 같습니다.",$id);
}

# 자금 조달
sub logDoNothing {
	my($id, $name, $comName) = @_;
#	logOut("${HtagName_}${name} 섬${H_tagName}에서${HtagComName_}${comName}${H_tagComName}이 실행되었습니다.",$id);
}

# 수출
sub logSell {
	my($id, $name, $comName, $value) = @_;
	logOut("${HtagName_}${name} 섬${H_tagName}이<B>$value$HunitFood</B>의${HtagComName_}${comName}${H_tagComName}을 실행했습니다.",$id);
}

# 포기
sub logGiveup {
	my($id, $name) = @_;
	logOut("${HtagName_}${name} 섬${H_tagName}은 포기되어 <B>무인 섬</B>이 되었습니다.",$id);
	logHistory("${HtagName_}${name} 섬${H_tagName}, 포기되어 <B>무인 섬</B>이 됩니다.");
}

# 추방
sub logGiveup_no_do_fight {
	my($id, $name) = @_;
	logOut("${HtagName_}${name} 섬${H_tagName}은규정된 횟수만큼 전투 행위를 하지 않았기 때문에,<B>무인 섬</B>이 되었습니다.",$id);
	logHistory("${HtagName_}${name} 섬${H_tagName}, 규정된 횟수만큼 전투 행위를 하지 않았기 때문에,<B>무인 섬</B>이 됩니다.");
}

# 사멸
sub logDead {
	my($id, $name) = @_;
	logOut("${HtagName_}${name} 섬${H_tagName}에서 주민이 사라져 <B>무인 섬</B>이 되었습니다.",$id);
	logHistory("${HtagName_}${name} 섬${H_tagName}, 주민이 사라져 <B>무인 섬</B>이 됩니다.");
}

# 발견
sub logDiscover {
	my($name) = @_;
	my($ip) = $ENV{'HTTP_X_FORWARDED_FOR'};
	$ip = $ENV{'REMOTE_ADDR'} if(!$ip);
	logHistory("${HtagName_}${name} 섬${H_tagName}이 발견됩니다.(${ip})");
}

# 이름의 변경
sub logChangeName {
	my($name1, $name2) = @_;
	logHistory("${HtagName_}${name1} 섬${H_tagName}, 명칭을${HtagName_}${name2} 섬${H_tagName}에 변경.");
}

# 기아
sub logStarve {
	my($id, $name) = @_;
	logOut("${HtagName_}${name} 섬${H_tagName}의${HtagDisaster_}식량이 부족${H_tagDisaster}하고 있습니다!!",$id);
}

# 식량 부족 피해
sub logSvDamage {
	my($id, $name, $lName, $point) = @_;
	logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>에<B>식량을 찾는 주민이 몰려들었습니다</B>.<B>$lName</B>은 괴멸되었습니다.",$id);
}

# 지반 침하발생
sub logFalldown {
	my($id, $name) = @_;
	logOut("${HtagName_}${name} 섬${H_tagName}에서${HtagDisaster_}지반 침하${H_tagDisaster}가 발생했습니다!!",$id);
}

# 지반 침하 피해
sub logFalldownLand {
	my($id, $name, $lName, $point) = @_;
	logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>은 바다의 안로 침몰봄했습니다.",$id);
}

# 수상
sub logPrize {
	my($id, $name, $pName) = @_;
	logOut("${HtagName_}${name} 섬${H_tagName}이<B>$pName</B>을 수상했습니다.",$id);
	logHistory("${HtagName_}${name} 섬${H_tagName},<B>$pName</B>을 수상");
}

# 섬이 가득 찬 경우
sub tempNewIslandFull {
	out(<<END);
${HtagBig_}신청이 몰려, 섬이 가득 차서 등록할 수 없습니다.${H_tagBig}$HtempBack
END
}

# 신규 등록 시 이름이 없는 경우
sub tempNewIslandNoName {
	out(<<END);
${HtagBig_} 섬 이름이 필요합니다.${H_tagBig}$HtempBack
END
}

# 신규 등록 시 이름이 올바르지 않은 경우
sub tempNewIslandBadName {
	out(<<END);
${HtagBig_}',"?()<>\$'등을 넣거나,'무인 섬'등 이상한 이름은 피하세요~${H_tagBig}$HtempBack
END
}

# 이미 같은 이름의 섬이 있는 경우
sub tempNewIslandAlready {
	out(<<END);
${HtagBig_}그 섬이면 이미 발견되어 있습니다.${H_tagBig}$HtempBack
END
}

# 이도목의 등록의 경우
sub tempRegistFailed {
	out(<<END);
${HtagBig_}연속하고 등록은 사용할 수 없습니다.${H_tagBig}$HtempBack
END
}

# 비밀번호가 없는 경우
sub tempNewIslandNoPassword {
	out(<<END);
${HtagBig_} 비밀번호가필요입니다.${H_tagBig}$HtempBack
END
}

# 섬을 발견했습니다!!
sub tempNewIslandHead {
	out(<<END);
<SCRIPT Language="JavaScript">
<!--
function ShowMsg(n){
	status = n;
}
//-->
</SCRIPT>
<CENTER>
${HtagBig_} 섬을 발견했습니다!!${H_tagBig}<BR>
${HtagBig_}${HtagName_}'${HcurrentName} 섬'${H_tagName}을 찾았습니다.${H_tagBig}<BR>
$HtempBack<BR>
</CENTER>
END
}

# 지형의 호출분
sub landName {
	my($land, $lv) = @_;
	if($land == $HlandSea) {
		if($lv == 1) {
			return '얕은 바다';
		} else {
			return '바다';
		}
	} elsif($land == $HlandWaste) {
		return '황무지';
	} elsif($land == $HlandPlains) {
		return '평지';
	} elsif($land == $HlandTown) {
		if($lv < 30) {
			return '마을';
		} elsif($lv < 100) {
			return '마을';
		} else {
			return '도시';
		}
	} elsif($land == $HlandForest) {
		return '숲';
	} elsif($land == $HlandFarm) {
		return '농장';
	} elsif($land == $HlandFactory) {
		return '공장';
	} elsif($land == $HlandBase) {
		return '미사일 기지';
	} elsif($land == $HlandDefence) {
		return '방위 시설';
	} elsif($land == $HlandMountain) {
		return '산';
	} elsif($land == $HlandHaribote) {
		return '가짜 시설';
	}
}

# 인구기타의 값을 산출
sub estimate {
	my($number) = $_[0];
	my($island);
	my($pop, $area, $farm, $factory, $mountain, $burnmis, $forest) = (0, 0, 0, 0, 0, 0, 0, 0);
	my($waste, $army_m, $army_d) = (0, 0, 0);

	# 지형을 가져옴
	$island = $Hislands[$number];
	my($land) = $island->{'land'};
	my($landValue) = $island->{'landValue'};

	# 수 가능
	my($x, $y, $kind, $value);
	for($y = 0; $y < $HislandSize; $y++) {
		for($x = 0; $x < $HislandSize; $x++) {
			$kind = $land->[$x][$y];
			$value = $landValue->[$x][$y];
			if($kind != $HlandSea) {
				$area++;
				if($kind == $HlandTown) {
					# 마을
					$pop += $value;
				} elsif($kind == $HlandFarm) {
					# 농장
					$farm += $value;
				} elsif($kind == $HlandFactory) {
					# 공장
					$factory += $value;
				} elsif($kind == $HlandMountain) {
					# 산
					$mountain += $value;
				} elsif($kind == $HlandBase) {
					# 미사일 기지
					$burnmis += expToLevel($kind, $value);
					$army_m++;
				} elsif($kind == $HlandDefence) {
					# 방위 시설
					$army_d++;
				} elsif($kind == $HlandWaste and $value == 1) {
					# 미사일흔적
					$waste++;
				} elsif($kind == $HlandForest) {
					# 숲
					$forest += $value;
				}
			}
		}
	}

	# 대입
	$island->{'pop'}	 = $pop;
	$island->{'area'}	 = $area;
	$island->{'farm'}	 = $farm;
	$island->{'factory'} = $factory;
	$island->{'mountain'} = $mountain;
	$island->{'fire'}	 = $burnmis;
	$island->{'army'}	 = $army_m + $army_d;
	$island->{'forest'}	 = $forest * $HtreeValue;
	$island->{'waste'}	 = $waste * $HcomCost[$HcomPrepare2]; # 땅고르기대

	if($winlose == 2 and $HrewardMode != 2 and $island->{'reward'} == 0) {
		$island->{'reward'} = $army_m + $army_d * 2;
	}
}

# 전투 기간시작 시의 섬의 상태를 저장
sub island_save {
	my($island) = @_;
	my($id) = $island->{'id'};

	open(IOUT, ">${Hdirmdata}/islandtmp.$island->{'id'}");
	print IOUT $island->{'money'}."\n";
	print IOUT $island->{'food'}."\n";

	my $land = $island->{'land'};
	my $landValue = $island->{'landValue'};
	my($x, $y);
	for($y = 0; $y < $HislandSize; $y++) {
		for($x = 0; $x < $HislandSize; $x++) {
			printf IOUT ("%x%02x", $land->[$x][$y], $landValue->[$x][$y]);
		}
		print IOUT "\n";
	}
	close(IOUT);
	unlink("${Hdirmdata}/island.$island->{'id'}");
	rename("${Hdirmdata}/islandtmp.$island->{'id'}", "${Hdirmdata}/island.$island->{'id'}");
}

# 패자의 섬의 상태저장
sub save_lose_island {
	my($island) = @_;
	my($id) = $island->{'id'};

	open(IOUT, ">${Hdirfdata}/islandtmp.$island->{'id'}");
	print IOUT $island->{'name'}."\n";

	my $land = $island->{'land'};
	my $landValue = $island->{'landValue'};
	my($x, $y);
	for($y = 0; $y < $HislandSize; $y++) {
		for($x = 0; $x < $HislandSize; $x++) {
			printf IOUT ("%x%02x", $land->[$x][$y], $landValue->[$x][$y]);
		}
		print IOUT "\n";
	}
	close(IOUT);
	unlink("${Hdirfdata}/island.$island->{'id'}");
	rename("${Hdirfdata}/islandtmp.$island->{'id'}", "${Hdirfdata}/island.$island->{'id'}");
}

# 전투 기간 안에부전승
sub fight_no_fight {
	my $id = $_[0];
	my $HcurrentNumber = $HidToNumber{$id};
	my $island = $Hislands[$HcurrentNumber];

	return 0 if($HcurrentNumber eq "");
	my $rest_turn = ($HnofightTurn + $HislandFightCount * $HnofightUp) - ($HfightTurn - ($HislandChangeTurn - $HislandTurn));
	$island->{'rest'} += $rest_turn if($rest_turn> 0);
	open(IN, "$Hdirmdata/island.$island->{'id'}");
	$island->{'money'} = int(<IN>);
	$island->{'food'} = int(<IN>);
	my($x, $y);
	for($y = 0; $y < $HislandSize; $y++) {
		$line = <IN>;
		for($x = 0; $x < $HislandSize; $x++) {
			$line =~ s/^(.)(..)//;
			$island->{'land'}[$x][$y] = hex($1);
			$island->{'landValue'}[$x][$y] = hex($2);
		}
	}
	close(IN);

	$island->{'fight_id'} = -1;
	push(@delete_log,$island->{'id'});

	# 각종의 값을 계산
	estimate($HcurrentNumber);
}


# 범위 안의 지형을 수 가능
sub countAround {
	my($land, $x, $y, $kind, $range) = @_;
	my($i, $count, $sx, $sy);
	$count = 0;
	for($i = 0; $i < $range; $i++) {
		 $sx = $x + $ax[$i];
		 $sy = $y + $ay[$i];

		 # 행 기준 위치 조정
		 if((($sy % 2) == 0) && (($y % 2) == 1)) {
			 $sx--;
		 }

		 if(($sx < 0) || ($sx>= $HislandSize) ||
			($sy < 0) || ($sy>= $HislandSize)) {
			 # 범위 밖의 경우
			 if($kind == $HlandSea) {
				 # 바다이면 가 산
				 $count++;
			 }
		 } else {
			 # 범위 안의 경우
			 if($land->[$sx][$sy] == $kind) {
				 $count++;
			 }
		 }
	}
	return $count;
}

# 0에서(n - 1)까지의 숫자가한 번씩출해 옵니다 수열을 만들기
sub randomArray {
	my($n) = @_;
	my(@list, $i);

	# 초기 값
	if($n == 0) {
		$n = 1;
	}
	@list = (0..$n-1);

	# 셔터 전체
	for ($i = $n; --$i; ) {
		my($j) = int(rand($i+1));
		if($i == $j) { next; };
		@list[$i,$j] = @list[$j,$i];
	}

	return @list;
}

# 이름 변경실패
sub tempChangeNothing {
	out(<<END);
${HtagBig_}이름과 비밀번호가 모두 비어 있습니다${H_tagBig}$HtempBack
END
}

# 이름 변경 자금 부족
sub tempChangeNoMoney {
	out(<<END);
${HtagBig_} 자금 부족으로 변경할 수 없습니다${H_tagBig}$HtempBack
END
}

# 이름 변경성공
sub tempChange {
	out(<<END);
${HtagBig_}변경을 완료했습니다${H_tagBig}$HtempBack
END
}

1;
