#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}
#----------------------------------------------------------------------
# 모형정원 토너먼트 2
# 설정 파일
# $Id: hako-ini.cgi 67 2005-12-22 08:08:58Z takayama $

#----------------------------------------------------------------------
# 각종 설정 값
#----------------------------------------------------------------------

#----------------------------------------------------------------------
# 아래는 반드시 설정해야 하는 항목입니다
#----------------------------------------------------------------------

# 이 파일을 설치할 디렉터리 끝에 슬래시(/)는 붙이지 않습니다.
my($scriptBaseScheme) = (($ENV{'HTTPS'} || '') =~ /^(on|1)$/i) ? 'https' : 'http';
my($scriptBaseHost) = $ENV{'HTTP_HOST'} || $ENV{'SERVER_NAME'} || 'localhost';
if (!$ENV{'HTTP_HOST'} && $ENV{'SERVER_PORT'} && !(($scriptBaseScheme eq 'http' && $ENV{'SERVER_PORT'} == 80) || ($scriptBaseScheme eq 'https' && $ENV{'SERVER_PORT'} == 443))) {
 $scriptBaseHost.= ":$ENV{'SERVER_PORT'}";
}
my($scriptBasePath) = $ENV{'SCRIPT_NAME'} || '';
$scriptBasePath =~ s{/[^/]*$}{};
$baseDir = "$scriptBaseScheme://$scriptBaseHost$scriptBasePath";


# 이미지 파일을 둘 디렉터리
#$imageDir = $baseDir;
$imageDir = 'https://esils.com/BBdata/hakoimg';

$toppage = "${baseDir}/";			# 홈페이지 주소
$bbsname 	= '게시판';							# 게시판의 명칭
$bbs = "${baseDir}/bbs/";		# 게시판 주소
$bbsLog		= './bbs/log.dat';					# 게시판의 로그 파일 이름
$imageExp = "${baseDir}/imgexp/";	# 이미지 경로 설정의 설명페이지
$masterPassword		= '1064';					# 마스터 비밀번호
$HspecialPassword	= 'special';				# 특수 비밀번호
$adminName			= '관리자의 이름';			# 관리자 이름
$email				= '관리자@어디. 어디. 어디';	# 관리자의 메일 주소
$version			= "0.97";					# 버전표기용(기본적으로 변경하지 않도록 !)

$HdirMode			= 0755;						# 데이터 디렉터리 권한
$HdirName			= 'data';					# 데이터 디렉터리 이름
$Hdirfdata			= 'fdata';					# 대전 기록유지 디렉터리
$Hdirmdata			= 'mdata';					# 전투 시작 시의 섬 데이터
$Hdiraccess			= 'access_log';				# 접속 로그유지 디렉터리

# 데이터 쓰기 권한
# 잠금 방식
# 1 파일 이름 변경(주)
# 2 시스템 콜(가능하면 이 방식을 권장합니다)
$lockMode = 1;

# (주)
# 1을 선택하는 경우에는,'lockfile'라는, 권한 666의 빈 파일을,
# 이 파일과 같은 위치에 배치해 주세요.

#----------------------------------------------------------------------
# 반드시 설정하는 부분은 이상
#----------------------------------------------------------------------

#----------------------------------------------------------------------
# 아래는 필요에 따라 설정하는 항목입니다
#----------------------------------------------------------------------
#----------------------------------------
# 게임의 진행야 파일등
#----------------------------------------
$unlockTime		= 90;		# 비정상 종료 기준 시간(잠금 후 몇 초가 지나면 강제로 해제할지)
$HlogMax		= 8;		# 로그 파일 유지 턴 수
$HhistoryMax	= 10;		# 발견 로그유지 줄 수
$HbackupTurn	= 3;		# 백업을 몇 턴오키에취는 가
$HbackupTimes	= 3;		# 백업을 몇 회분 남음습니까
$HgiveupTurn	= 15;		# 포기 명령 자동 입력 턴 수
$HcommandMax	= 30;		# 명령 입력 한계 수
$HislandSize	= 12;		# 섬 크기
$HuseLbbs		= 1;		# 로컬 게시판 사용 여부(0:사용하지 않음)
$HlbbsMax		= 10;		# 로컬 게시판 저장 줄 수
$HlbbsView		= 5;		# 로컬 게시판, 일반 관광 화면에서 표시하다 줄 수(HlbbsMax 보다작게하다사)
$Htop_blank		= 0;		# 중단에서 섬 이름 클릭으로 새 화면에서 표시(0:같은 화면 1:새 화면)
$cryptOn		= 1;		# 비밀번호 암호화(1이면암호화함)
$Hdebug			= 0;		# 디버그 모드(1이면 '턴 진행' 버튼을 사용할 수 있음)
$Hmobile		= 0;		# 휴대 화면 테스트용(1이면 강제로 휴대용 화면 표시)
$Htime_mode		= 0;		# 다음 갱신까지의 일 시가 표시됨없는 경우여기를1로 설정해 주세요
$Hmissile_log	= 0;		# 미사일 발사의 로그를 간단략화 표시하다(0:하지 않음 1:설정하기)

# 보상금 설정 (마지막에황무지(미사일흔적)대를 족스것은 전체공통)
# 여기에 지정된 숫자 이외의 값을 넣으면 이상한 결과가 됩니다
# 1: (양측 미사일 기지의 수 + 양측 방위 시설의 수 * 2) / 2 * 자신의 전투 행위 횟수 * 15
# 2: 파괴된 시설의 대금(농장·공장·미사일 기지·방위 시설)전체 합산형
# 상대의 강사로 ＊예정 설정하지 마세요
# 상대대적나강사 ＊예정 설정하지 마세요
$HrewardMode	= 1;

# 대전 상대 결정 방식
# 0: (기본값) 섬력이라는 섬의 강도를 판정하는 방식
# 1: 토너먼트 표를 사용했음 방식 처음의 대전 상대결정만 섬력을 계산 (부전승이 발생하면, 정상적으로 동작하지 않습니다)
# 완료 전체나무작위 ＊예정 설정하지 마세요
$Htournament	= 0;

#----------------------------------------
# 갱신 시간야, 섬 수
#----------------------------------------
$HmaxIsland		= 100;		# 섬의 최대 수
$HfightMem 		= 32;		# 예선 통과 섬 수(2의 거듭제곱로 베키)
$HyosenTurn		= 48;		# 예선 기간 턴 수(0에하지 말아 주세요)
$HdevelopeTurn	= 24;		# 개발 기간 턴 수
$HfightTurn		= 12;		# 전투 기간 턴 수
$HunitTime		= 43200;	# 예선 기간 갱신 시간(3600초=1 시간)
$HdevelopeTime	= 7200;		# 개발 기간 갱신 시간 # 2 시간
$HfightTime		= 86400;	# 전투 기간 갱신 시간 # 24 시간
$HinterTime		= 93600;	# 전투 기간종료후의 개발 기간로의 이전까지의 시간
$HyosenRepCount	= 3;		# 예선 기간에 한 번에 갱신할 턴 수(예: 3으로 설정하면 한 번에 3턴 진행)
$HdeveRepCount	= 1;		# 개발 기간에 한 번에 갱신할 턴 수
$HfightRepCount	= 3;		# 전투 기간에 한 번에 갱신할 턴 수
$HstopAddPop	= 3;		# 인구증가스중단하다 자금 조달횟수
$do_fight		= 3;		# 부전승을 피하기 위해 필요한 전투 행위 횟수

# 부전승의 개발 정지 턴 수
$HnofightTurn	= 12;		# 기본값
$HnofightUp		= 4;		# 위 수치 + 이숫자 값×라운드 수으로 됩니다

#----------------------------------------
# 자금, 식량등의 설정 값와 단위
#----------------------------------------
$HinitialMoney		= 2000;		# 초기 자금
$HinitialFood		= 1000;		# 초기 식량
$HlandSizeValue		= 32;		# 초기면적
$HseaNum			= 20;		# 초기얕은 바다의 수
$HunitMoney			= '억 엔';	# 자금의 단위
$HunitFood			= '00톤';	# 식량의 단위
$HunitPop			= '00인';	# 인구의 단위
$HunitArea			= '00만 평';	# 면적의 단위
$HunitTree			= '00본';	# 나무 수의 단위
$HtreeValue			= 5;		# 목재 단위당 판매 수입
$HtreeUp			= 2;		# 1턴에서 목의 늘어나면개 수
$HtownUp			= 10;		# 인구의 증가폭(10이면 최대1000명)
$HeatenFood			= 0.2;		# 인구 1단위당 식량 소비량
$HtownGlow			= 25;		# 마을 의 발생률(%)
$Hno_work			= 500;		# 실업자 수의 테두리라인(10이면1000명)
								# 이 수치를 초과하면, 인구 증가가 중단합니다(예선만)
$HcostChangeName	= 0;		# 이름 변경의 비용
$HdefenceValue		= 400;		# 방위 시설의 매각 값

# 일괄 자동 땅고르기용
$precheap			= 10;		# 몇 번째 황무지부터 할인할지(이 수 다음의 황무지부터)
$precheap2			= 8;		# 그 시의 할인률(8로 설정하면 20% 할인이라는 뜻입니다)

#----------------------------------------
# 위장 설정(도시이외는 숲에서 위장)
#----------------------------------------
$HhideMoneyMode		= 2;		# 자금의 표시(0:보이지 않음 1: 표시 가능 2:100의 위에서 반올림)
$Hhide_missile		= 1;		# 미사일 기지 0:하지 않음 1:하다
$Hhide_deffence		= 1;		# 방위 시설 0:하지 않음 1:하다
$Hhide_town			= 0;		# 도시계 0:하지 않음 1:하다
$Hhide_farm			= 0;		# 농장 0:하지 않음 1:하다 2:규모도 은폐
$Hhide_factory		= 0;		# 공장 0:하지 않음 1:하다 2:규모도 은폐

#----------------------------------------
# 특수 설정(상세한 설명은 readme 참고)
#----------------------------------------
# 0:설정하지 않음 1:설정하기
$HeasyReclaim		= 0;		# 매립의 간이화

#----------------------------------------
# 기지의 경험치
#----------------------------------------
$HmaxExpPoint	= 200;		# 경험치의 최댓값(최대255)
$maxBaseLevel	= 5;		# 미사일 기지 레벨의 최댓값
@baseLevelUp	= (20, 60, 120, 200);	# 경험치

#----------------------------------------
# 재해
#----------------------------------------
# 지반 침하발생률(확률은0.1%단위)
$HdisFallBorder	= 90;	# 안정 전체한계의 면적(Hex 수)
$HdisFalldown	= 30;	# 그 면적를 초과한 경우 확률

#----------------------------------------
# 수상 관계
#----------------------------------------
# 상의 이름
$Hprize[0] = '턴잔';
$Hprize[1] = '번영상';
$Hprize[2] = '초과 번영상';
$Hprize[3] = '궁극번영상';
$Hprize[4] = '평화상';
$Hprize[5] = '초과 평화상';
$Hprize[6] = '궁극평화상';
$Hprize[7] = '재난상';
$Hprize[8] = '초과 재난상';
$Hprize[9] = '궁극재난상';

#----------------------------------------
# 화면 표시 관련등
#----------------------------------------
$htmlBody	= 'BGCOLOR="#EEFFFF"';		# <BODY>태그의 옵션
$Htitle		= '모형정원 토너먼트 2';		# 게임 제목 문자열

# 태그
# 제목문자
$HtagTitle_ = '<FONT SIZE=7 COLOR="#8888ff">';
$H_tagTitle = '</FONT>';

# 몇회전목
$HtagFico_ = '<FONT SIZE="7" COLOR="#4444ff">';
$H_tagFico = '</FONT>';

# H1태그용
$HtagHeader_ = '<FONT COLOR="#4444ff">';
$H_tagHeader = '</FONT>';

# 큰 글자
$HtagBig_ = '<FONT SIZE=6>';
$H_tagBig = '</FONT>';

# 섬 이름 등
$HtagName_ = '<FONT COLOR="#a06040"><B>';
$H_tagName = '</B></FONT>';

# 숨김 처리하지 않은 섬 이름
$HtagName2_ = '<FONT COLOR="#808080"><B>';
$H_tagName2 = '</B></FONT>';

# 순위 번호 등
$HtagNumber_ = '<FONT COLOR="#800000"><B>';
$H_tagNumber = '</B></FONT>';

# 순위표 머리글
$HtagTH_ = '<FONT COLOR="#C00000"><B>';
$H_tagTH = '</B></FONT>';

# 개발계획의 이름
$HtagComName_ = '<FONT COLOR="#d08000"><B>';
$H_tagComName = '</B></FONT>';

# 재해
$HtagDisaster_ = '<FONT COLOR="#ff0000"><B>';
$H_tagDisaster = '</B></FONT>';

# 로컬 게시판, 관광객의 표시 문자
$HtagLbbsSS_ = '<FONT COLOR="#0000ff"><B>';
$H_tagLbbsSS = '</B></FONT>';

# 로컬 게시판, 섬주의 표시 문자
$HtagLbbsOW_ = '<FONT COLOR="#ff0000"><B>';
$H_tagLbbsOW = '</B></FONT>';

# 로컬 게시판, 섬무시 관광객의 표시 문자
$HtagLbbsSK_ = '<FONT COLOR="#003333"><B>';
$H_tagLbbsSK = '</B></FONT>';

# 일반 문자색(BODY 태그의 옵션도 함께 변해야 합니다
$HnormalColor = '#000000';

# 순위표, 세루의 속성
$HbgTitleCell = 'BGCOLOR="#ccffcc"';	# 순위표 머리글시
$HbgNumberCell = 'BGCOLOR="#ccffcc"';	# 순위표순위
$HbgNameCell	= 'BGCOLOR="#ccffff"';	# 순위표 섬 이름
$HbgInfoCell	= 'BGCOLOR="#ccffff"';	# 순위표 섬의 정보
$HbgCommentCell = 'BGCOLOR="#ccffcc"';	# 순위표코멘트란
$HbgInputCell = 'BGCOLOR="#ccffcc"';	# 개발계획양식
$HbgMapCell		= 'BGCOLOR="#ccffcc"';	# 개발계획지도
$HbgCommandCell = 'BGCOLOR="#ccffcc"';	# 개발계획입력완료미계획

# 예선용락치레도라인
$YbgNumberCell = 'BGCOLOR="#F0BBDA"'; # 순위표순위
$YbgNameCell = 'BGCOLOR="#E4CCF5"'; # 순위표 섬 이름
$YbgInfoCell = 'BGCOLOR="#E4CCF5"'; # 순위표 섬의 정보
$YbgCommentCell = 'BGCOLOR="#F0BBDA"'; # 순위표코멘트란

#----------------------------------------
# 헤더 푸터
#----------------------------------------
# 헤더
sub tempHeader {

	my($HimgFlag) = 0;
			$baseIMG = $imageDir;
		$HimgFlag = 1;
	$baseIMG =~ s/데스크톱/데스크톱/g;

	out("Content-type: text/html; charset=UTF-8\n\n");
	return if($Hasync);

	if($Hmobile == 0) {
		my $bbTime = get_time((stat($bbsLog))[9], 1, 1);
		out(<<END);
<HTML>
<HEAD><META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
<TITLE>$Htitle</TITLE>
<BASE HREF="$baseIMG/">
</HEAD>
$Body
 <A HREF="http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html">모형정원 제도 스크립트 배포처</A>
 / <A HREF="http://appoh.execweb.cx/hakoniwa/">모형정원 JavaScript판 배포처</A>
 / <A HREF="http://espion.just-size.jp/archives/dist_hako/">모형정원 토너먼트 2 배포처</A>
 / <A HREF="http://espion.just-size.jp/files/link/link.cgi">모형정원 토너먼트 링크 모음</A>
<B><BR>
<A HREF="$toppage">톱 페이지</A>
 / <A HREF="$bbs">$bbsname</A>$bbTime
 / <A HREF="$HthisFile?LogFileView=1">최근 사건</A>
 / <A HREF="$HthisFile?help=1"> 설정 목록</A>
 / <A HREF="$HthisFile?exp=1">매뉴얼</A>
 / <A HREF="$baseDir/hako-main.cgi">돌아가기</A>
</B>
</nobr>
<HR>
END
		if($HimgFlag) {
			out("<FONT COLOR=RED>서버 부하를 줄이기 위해 압축파일을 등록, 이미지 경로 설정을 할수있게 해뒀습니다.</FONT><HR>");
		}
	} else {
 out(<<END);
<HTML>
<HEAD><META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
<TITLE>$Htitle</TITLE>
</HEAD>
<BODY bgcolor="#ffffff">
<a href="./hako-main.cgi">중단</a> <a href="./hako-main.cgi?help=1">도움말</a> <a href="./hako-main.cgi?exp=1">링크</a>
<hr>
END
 }
}

# 푸터
sub tempFooter {
	if($Hmobile == 0) {
		out(<<END);
<HR>
<P align=right>
<NOBR>
<A HREF="http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html">모형정원 제도 스크립트 배포처</A>
 <A HREF="$toppage">톱 페이지</A>
 <A HREF="$bbs">$bbsname</A>
 <A HREF="$HthisFile?LogFileView=1">최근 사건</A>
</nobr><BR><BR>
관리자:$adminName(<A HREF="mailto:$email">$email</A>)<BR>
</P>
END
	}
	out(<<END);
</BODY>
</HTML>
END
}

require('local-ini.cgi') if(-e 'local-ini.cgi');

1;
