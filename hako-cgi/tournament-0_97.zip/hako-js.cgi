#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}
#----------------------------------------------------------------------
# 모형정원 제도 ver2.30
# 톱 페이지 모듈(ver1.00)
# 사용 조건과 사용 방법은 hako-readme.txt 파일을 참조해 주세요
#
# 모형정원 제도의 페이지: http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html
#----------------------------------------------------------------------
# 모형정원 토너먼트 2
# JS 개발 화면모듈
# $Id: hako-js.cgi 63 2005-10-10 03:27:08Z takayama $

#----------------------------------------------------------------------
# Java스크립트개발 화면
#----------------------------------------------------------------------
# ○○섬개발계획
sub tempOwnerJava {

	$HcurrentNumber = $HidToNumber{$HcurrentID};
	my($island) = $Hislands[$HcurrentNumber];
	# 명령 설정
	$set_com = "";
	$com_max = "";
	for($i = 0; $i < $HcommandMax; $i++) {
		# 각 요소 꺼내기
		my($command) = $island->{'command'}->[$i];
		my($s_kind, $s_target, $s_x, $s_y, $s_arg) =
			(
			$command->{'kind'},
			$command->{'target'},
			$command->{'x'},
			$command->{'y'},
			$command->{'arg'}
			);
		# 명령 등록
		if($i == $HcommandMax-1){
			$set_com.= "\[$s_kind\,$s_x\,$s_y\,$s_arg\,$s_target\]\n";
			$com_max.= "0"
		} else {
			$set_com.= "\[$s_kind\,$s_x\,$s_y\,$s_arg\,$s_target\]\,\n";
			$com_max.= "0,"
		}
	}

	#명령 목록 설정
	my($l_kind);
	$set_listcom = "";
	for($i = 0; $i < $HcommandTotal; $i++) {
		$l_kind = $HcomList[$i];
		if($l_kind < 46 and $l_kind != $HcomPrepRecr) {
			$set_listcom.= "\[$l_kind\,\'$HcomName[$l_kind]\'\]\,\n";
		}
		if($l_kind == $HcomGiveup) {
			$set_listcom.= "\[46\,\'섬 포기\'\]\n";
		}
	}
	my($set_land) = '';
	my($land) = $island->{'land'};
	for(my $lx = 0; $lx < $HislandSize; $lx++) {
		$set_land .= '[';
		for(my $ly = 0; $ly < $HislandSize; $ly++) {
			$set_land .= $land->[$lx][$ly];
			$set_land .= ',' if($ly != $HislandSize - 1);
		}
		$set_land .= ']';
		$set_land .= ",\n" if($lx != $HislandSize - 1);
	}


	my($set_island, $l_name, $l_id);
	#섬 목록 설정
	$set_island = "";
	for($i = 0; $i < $HislandNumber; $i++) {
		$l_name = $Hislands[$i]->{'name'};
		$l_name =~ s/'/\\'/g;
		$l_id = $Hislands[$i]->{'id'};
		if($i == $HislandNumber-1){
			$set_island.= "'$l_id'\:\'$l_name\'\n";
		} else {
			$set_island.= "'$l_id'\:\'$l_name\'\,\n";
		}
	}

	$nextTurn = $HunitTime - time() + $HislandLastTime;
	out(<<END);
<CENTER>
${HtagBig_}${HtagName_}${HcurrentName} 섬${H_tagName}개발계획${H_tagBig}<BR>
$HtempBack<BR>
</CENTER>
<SCRIPT Language="JavaScript">
<!--
// JavaScript 개발판 배포처
// 앗포암자모형정원 제도( http://appoh.execweb.cx/hakoniwa/ )
// Programmed by Jynichi Sakai(앗포)
var xmlhttp;

var str;

g = [$com_max];
k1 = [$com_max];
k2 = [$com_max];
tmpcom1 = [ [0,0,0,0,0] ];
tmpcom2 = [ [0,0,0,0,0] ];
command = [
$set_com];

comlist = [
$set_listcom];

islname = {
$set_island
};

landmap = [
$set_land
];
var AUTO_BULK_PREPARE = -101;
var AUTO_BULK_RECLAIM = -102;
var LAND_SEA = $HlandSea;
var LAND_WASTE = $HlandWaste;
var LAND_SBASE = -1;
var COM_PREPARE = $HcomPrepare;
var COM_RECLAIM = $HcomReclaim;

function init(){
	for(i = 0; i < command.length ;i++) {
		for(j = 0; j < comlist.length ; j++) {
			if(command[i][0] == comlist[j][0]) {
				g[i] = comlist[j][1];
			}
		}
	}
	outp();
	str = plchg();
	str = "<NOBR><font color=blue>---- <B>전송 완료</B> ----</font></NOBR><br>"+str;
	disp(str, "#ccffcc");
	document.onkeydown = commandKeyDown;

 xmlhttp = new_http();

 if(document.layers) {
 document.captureEvents(Event.MOUSEMOVE | Event.MOUSEUP);
 }
 document.onmouseup = Mup;
 document.onmousemove = Mmove;
 document.myForm.CommandJavaButton$island->{'id'}.disabled = true;
 ns(0);
}

function cominput(x, k, z, f2) {
	a = document.myForm.NUMBER.options[document.myForm.NUMBER.selectedIndex].value;
	b = document.myForm.COMMAND.options[document.myForm.COMMAND.selectedIndex].value;
	c = document.myForm.POINTX.options[document.myForm.POINTX.selectedIndex].value;
	d = document.myForm.POINTY.options[document.myForm.POINTY.selectedIndex].value;
	e = document.myForm.AMOUNT.options[document.myForm.AMOUNT.selectedIndex].value;
	f = document.myForm.TARGETID.options[document.myForm.TARGETID.selectedIndex].value;
	if(f2) { f = f2; }

	var newNs = a;
	if (x == 1 || x == 2 || x == 6){
		if(x == 6) b = k;
		if(x != 2) {
			for(i = $HcommandMax - 1; i> a; i--) {
				command[i] = command[i-1];
				g[i] = g[i-1];
			}
		}

		var comlist2 = comlist;
		for(i = 0; i < comlist2.length; i++){
			if(comlist2[i][0] == b){
				g[a] = comlist2[i][1];
				break;
			}
		}
		command[a] = [b,c,d,e,f];
		newNs++;
		menuclose();
	} else if(x == 3) {
		var num = (k) ? k-1 : a;
		for(i = Math.floor(num); i < ($HcommandMax - 1); i++) {
			command[i] = command[i + 1];
			g[i] = g[i+1];
		}
		command[$HcommandMax-1] = [41,0,0,0,0];
		g[$HcommandMax-1] = '자금 조달';
	} else if(x == 4) {
		i = Math.floor(a)
		if (i == 0){ return true; }
		i = Math.floor(a)
		tmpcom1[i] = command[i];tmpcom2[i] = command[i - 1];
		command[i] = tmpcom2[i];command[i-1] = tmpcom1[i];
		k1[i] = g[i];k2[i] = g[i - 1];
		g[i] = k2[i];g[i-1] = k1[i];
		newNs = i-1;
	} else if(x == 5) {
		i = Math.floor(a)
		if (i == $HcommandMax-1){ return true; }
		tmpcom1[i] = command[i];tmpcom2[i] = command[i + 1];
		command[i] = tmpcom2[i];command[i+1] = tmpcom1[i];
		k1[i] = g[i];k2[i] = g[i + 1];
		g[i] = k2[i];g[i+1] = k1[i];
		newNs = i+1;
	} else if(x == 7) {
		// 이동
		var ctmp = command[k];
		var gtmp = g[k];
		if(z> k) {
			// 위에서 아래로
			for(i = k; i < z-1; i++) {
				command[i] = command[i+1];
				g[i] = g[i+1];
			}
		} else {
			// 하에서 상로
			for(i = k; i> z; i--) {
				command[i] = command[i-1];
				g[i] = g[i-1];
			}
		}
		command[i] = ctmp;
		g[i] = gtmp;
	}

	str = plchg();
	str = "<NOBR><font color=red><b>-----미전송-----</b></font></NOBR><br>"+str;
	disp(str, "#CCDDFF");
	outp();
	document.myForm.CommandJavaButton$island->{'id'}.disabled = false;
	ns(newNs);
	return true;
}


function commandKeyDown(e) {
	e = e || window.event;
	var src = e.target || e.srcElement;
	var tag = src && src.tagName ? src.tagName.toUpperCase() : '';
	if(tag == 'INPUT' || tag == 'TEXTAREA' || tag == 'SELECT') { return true; }
	var code = e.keyCode || e.which;
	if(code == 46) {
		cominput(3);
		if(e.preventDefault) { e.preventDefault(); }
		return false;
	}
	return true;
}

function commandNameByKind(kind) {
	for(var i = 0; i < comlist.length; i++) {
		if(Number(comlist[i][0]) == Number(kind)) { return comlist[i][1]; }
	}
	return '자금 조달';
}

function firstEmptySlot(start) {
	start = Number(start) || 0;
	for(var i = start; i < $HcommandMax; i++) {
		if(Number(command[i][0]) == $HcomDoNothing) { return i; }
	}
	return -1;
}

function selectPlanNumber(value) {
	var sel = document.myForm.NUMBER;
	for(var i = 0; i < sel.options.length; i++) {
		if(Number(sel.options[i].value) == Number(value)) {
			sel.selectedIndex = i;
			return true;
		}
	}
	return false;
}

function waterLike(kind) {
	return (Number(kind) == LAND_SEA || Number(kind) == LAND_SBASE);
}

function waterCountAround(x, y) {
	var ax = [0, 1, 1, 1, 0, -1, 0];
	var ay = [0,-1, 0, 1, 1,  0,-1];
	var count = 0;
	for(var i = 0; i < 7; i++) {
		var sx = Number(x) + ax[i];
		var sy = Number(y) + ay[i];
		if(((sy % 2) == 0) && ((Number(y) % 2) == 1)) { sx--; }
		if(sx < 0 || sx >= $HislandSize || sy < 0 || sy >= $HislandSize) {
			count++;
		} else if(waterLike(landmap[sx][sy])) {
			count++;
		}
	}
	return count;
}

function addBulkCommand(realKind, realName, testFunc) {
	var idx = firstEmptySlot(0);
	if(idx < 0) { idx = $HcommandMax - 1; }
	for(var y = 0; y < $HislandSize; y++) {
		for(var x = 0; x < $HislandSize; x++) {
			idx = firstEmptySlot(idx);
			if(idx < 0) { break; }
			if(testFunc(x, y)) {
				command[idx] = [realKind,x,y,0,0];
				g[idx] = realName;
				idx++;
			}
		}
		if(idx < 0) { break; }
	}
	var next = firstEmptySlot(0);
	selectPlanNumber(next < 0 ? $HcommandMax - 1 : next);
}

function ensureCommandJavaButton(form) {
	var name = 'CommandJavaButton$island->{'id'}';
	var el = form.elements[name];
	if(!el || (el.type && String(el.type).toLowerCase() == 'submit')) {
		el = document.createElement('input');
		el.type = 'hidden';
		el.name = name;
		form.appendChild(el);
	}
	el.value = '1';
	return true;
}

function autoInput() {
	var sel = (document.myForm && document.myForm.AUTOCOMMAND) ? document.myForm.AUTOCOMMAND : document.getElementById('AUTOCOMMAND');
	if(!sel) { return false; }
	var kind = Number(sel.options[sel.selectedIndex].value);
	if(kind == $HcomAutoDelete) {
		for(var i = 0; i < $HcommandMax; i++) {
			command[i] = [$HcomDoNothing,0,0,0,0];
			g[i] = commandNameByKind($HcomDoNothing);
		}
		selectPlanNumber(0);
	} else if(kind == AUTO_BULK_PREPARE) {
		addBulkCommand(COM_PREPARE, commandNameByKind(COM_PREPARE), function(x, y) { return Number(landmap[x][y]) == LAND_WASTE; });
	} else if(kind == AUTO_BULK_RECLAIM) {
		addBulkCommand(COM_RECLAIM, commandNameByKind(COM_RECLAIM), function(x, y) { return waterLike(landmap[x][y]) && waterCountAround(x, y) < 7; });
	} else {
		var idx = firstEmptySlot(0);
		if(idx < 0) { idx = $HcommandMax - 1; }
		command[idx] = [kind,0,0,0,0];
		g[idx] = commandNameByKind(kind);
		var next = firstEmptySlot(idx + 1);
		selectPlanNumber(next < 0 ? idx : next);
	}
	str = plchg();
	str = "<NOBR><font color=red><b>-----미전송-----</b></font></NOBR><br>"+str;
	disp(str,"white");
	outp();
	return true;
}

function autoInputSubmit() {
	if(!autoInput()) { return false; }
	outp();
	ensureCommandJavaButton(document.myForm);
	// 일반 '계획 전송'과 같은 POST 제출로 처리한다.
	document.myForm.submit();
	return false;
}

function plchg(){
	strn1 = "";
	for(i = 0; i < $HcommandMax; i++) {
		c = command[i];
		kind = '<FONT COLOR="#d08000"><B>' + g[i] + '</B></FONT>';
		x = c[1];
		y = c[2];
		tgt = c[4];
		point = '<FONT COLOR="#a06040"><B>' + "(" + x + "," + y + ")" + '</B></FONT>';
	 	tgt = '<FONT COLOR="#a06040"><B>' + islname[tgt] + "섬" + '</B></FONT>';
		if(c[0] == $HcomDoNothing || c[0] == $HcomAutoPrepare3){ // 자금 조달 일괄 자동 땅고르기
			strn2 = kind;
		} else if(c[0] == $HcomMissileNM || // 미사일 관련
			c[0] == $HcomMissilePP){
			if(c[3] == 0){
				arg = "(무제한)";
			} else {
				arg = "(" + c[3] + "발)";
			}
			strn2 = tgt + point + "로" + kind + arg;
		} else if(c[0] == $HcomSell){ // 식량 수출
			if(c[3] == 0){ c[3] = 1; }
			arg = c[3] * 100;
			arg = "(" + arg + "$HunitFood)";
			strn2 = kind + arg;
		} else if(c[0] == $HcomDestroy){ // 굴착
			strn2 = point + " " + kind;
		} else if(c[0] == $HcomFarm || c[0] == $HcomMountain || // 농장, 공장, 채굴장 건설
			c[0] == $HcomFactory || c[0] == $HcomFastFarm) {
			if(c[3] != 0) {
				arg = "(" + c[3] + "회)";
				strn2 = point + " " + kind + arg;
			} else {
				strn2 = point + " " + kind;
			}
		} else {
			strn2 = point + " " + kind;
		}
		tmpnum = '';
		if(i < 9){ tmpnum = '0'; }
			strn1 +=
			'<div id="com_'+i+'" '+
			'onmouseover="mc_over('+i+');return false;" '+
			'><A STYLE="text-decoration:none;color:000000" HREF="JavaScript:void(0);" onClick="ns(' + i + ')" '+
			'onmousedown="return comListMove('+i+');" '+
			'><NOBR>' +

			tmpnum + (i + 1) + ':' +
			strn2 + '</NOBR></A></div>\\n';
		}
	return strn1;
}

function disp(str,bgclr){
	if(str==null) str = "";

	if(document.getElementById || document.all){
		LayWrite('LINKMSG1', str);
		SetBG('plan', bgclr);
	} else if(document.layers) {
		lay = document.layers["PARENT_LINKMSG"].document.layers["LINKMSG1"];
		lay.document.open();
		lay.document.write("<font style='font-size:11pt'>"+str+"</font>");
		lay.document.close();
		SetBG("PARENT_LINKMSG", bgclr);
	}
}

function outp(){
	comary = "";

	for(k = 0; k < command.length; k++){
		comary = comary + command[k][0]
		+" "+command[k][1]
		+" "+command[k][2]
		+" "+command[k][3]
		+" "+command[k][4]
		+" ";
	}
	document.myForm.COMARY.value = comary;
}

function ps(x, y) {
 if(document.mark_form.mark.checked) {
 set_mark(x, y);
 } else {
 document.myForm.POINTX.options[x].selected = true;
 document.myForm.POINTY.options[y].selected = true;
 moveLAYER("menu",mx+10,my-50);
 }
 return true;
}

function ns(x) {
	if (x == $HcommandMax){ return true; }
	document.myForm.NUMBER.options[x].selected = true;
	selCommand(x);
	return true;
}

function set_com(x, y, land) {
	com_str = land + "\\n";
	for(i = 0; i < $HcommandMax; i++) {
		c = command[i];
		x2 = c[1];
		y2 = c[2];
		if(x == x2 && y == y2 && c[0] < 30) {
			com_str += "[" + (i + 1) +"]" ;
			kind = g[i];
			if(c[0] == $HcomFarm ||
				c[0] == $HcomFactory) {
				if(c[3] != 0) {
					arg = "(" + c[3] + "회)";
					com_str += kind + arg;
				} else {
					com_str += kind;
				}
			} else {
				com_str += kind;
			}
			com_str += " ";
		}
	}
	window.status = com_str;
	document.myForm.COMSTATUS.value= com_str;
}

function jump(theForm) {
	var sIndex = theForm.TARGETID.selectedIndex;
	var url = theForm.TARGETID.options[sIndex].value;
	if (url != "" ) window.open("$HthisFile?IslandMap=" +url,"", "menubar=yes,toolbar=no,location=no,directories=no,status=yes,scrollbars=yes,resizable=yes,width=450,height=630");
}

function moveLAYER(layName,x,y){
 if(document.getElementById){		//NN6,IE5
 el = document.getElementById(layName);
 el.style.left = x;
 el.style.top = y;
 } else if(document.layers){				//NN4
 msgLay = document.layers[layName];
 msgLay.moveTo(x,y);
 } else if(document.all){				//IE4
 msgLay = document.all(layName).style;
 msgLay.pixelLeft = x;
 msgLay.pixelTop = y;
 }
}

function menuclose() {
 moveLAYER("menu",-500,-500);
}

function Mmove(e){
 if(document.all){
 mx = event.x + document.body.scrollLeft;
 my = event.y + document.body.scrollTop;
 }else if(document.layers){
 mx = e.pageX;
 my = e.pageY;
 }else if(document.getElementById){
 mx = e.pageX;
 my = e.pageY;
 }

 return moveLay.move();
}

function LayWrite(layName, str) {
 if(document.getElementById){
 document.getElementById(layName).innerHTML = str;
 } else if(document.all){
 document.all(layName).innerHTML = str;
 } else if(document.layers){
 lay = document.layers[layName];
 lay.document.open();
 lay.document.write(str);
 lay.document.close();
 }
}

function SetBG(layName, bgclr) {
 if(document.getElementById) document.getElementById(layName).style.backgroundColor = bgclr;
 else if(document.all) document.all.layName.bgColor = bgclr;
 //else if(document.layers) document.layers[layName].bgColor = bgclr;
}

var oldNum=0;
function selCommand(num) {
 document.getElementById('com_'+oldNum).style.backgroundColor = '';
 document.getElementById('com_'+num).style.backgroundColor = '#FFFFAA';
 oldNum = num;
}


/* 명령 드래그 앤 드롭용 추가 스크립트 */
var moveLay = new MoveFalse();

var newLnum = -2;
var Mcommand = false;

function Mup() {
 moveLay.up();
 moveLay = new MoveFalse();
}

function setBorder(num, color) {
 if(document.getElementById) {
 if(color.length == 4) document.getElementById('com_'+num).style.borderTop = ' 1px solid '+color;
 else document.getElementById('com_'+num).style.border = '0px';
 }
}

function mc_out() {
 if(Mcommand && newLnum>= 0) {
 setBorder(newLnum, '');
 newLnum = -1;
 }
}

function mc_over(num) {
 if(Mcommand) {
 if(newLnum>= 0) setBorder(newLnum, '');
 newLnum = num;
 setBorder(newLnum, '#116'); // blue
 }
}

function comListMove(num) { moveLay = new MoveComList(num); return (document.layers) ? true : false; }

function MoveFalse() {
 this.move = function() { }
 this.up = function() { }
}

function MoveComList(num) {
 var setLnum = num;
 Mcommand = true;

 LayWrite('mc_div', '<NOBR><strong>'+(num+1)+': '+g[num]+'</strong></NOBR>');

 this.move = function() {
 moveLAYER('mc_div',mx+10,my-30);
 return false;
 }

 this.up = function() {
 if(newLnum>= 0) {
 var com = command[setLnum];
 cominput(7,setLnum,newLnum);
 }
 else if(newLnum == -1) cominput(3,setLnum+1);

 mc_out();
 newLnum = -2;

 Mcommand = false;
 moveLAYER("mc_div",-50,-50);
 }
}


/* 화면 이동 없이 명령을 전송하기 위한 추가 스크립트 */

function new_http() {
 if(document.getElementById) {
 try{
 return new ActiveXObject("Msxml2.XMLHTTP");
 } catch (e){
 try {
 return new ActiveXObject("Microsoft.XMLHTTP");
 } catch (E){
 if(typeof XMLHttpRequest != 'undefined') return new XMLHttpRequest;
 }
 }
 }
}

function send_command(form) {
 if (!xmlhttp) return true;

 form.CommandJavaButton$island->{'id'}.disabled = true;

 var progress = document.getElementById('progress');
 progress.innerHTML = '<blink>Sending...</blink>';

 if (xmlhttp.readyState == 1 || xmlhttp.readyState == 2 || xmlhttp.readyState == 3) return;

 xmlhttp.open("POST", "$HthisFile", true);
 if(!window.opera) xmlhttp.setRequestHeader("referer", "$HthisFile");

 xmlhttp.onreadystatechange = function() {
 if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
 var result = xmlhttp.responseText;
 if(result.indexOf('OK') == 0 || result.indexOf('OK') == 2048) {
 str = plchg();
 str = "<font color=blue>---- 전송 완료 ----</font><br>"+str;
 disp(str, "#CCFFDD");
 selCommand(document.myForm.NUMBER.selectedIndex);
 } else {
 alert("전송에 실패했습니다.");
 form.CommandJavaButton$island->{'id'}.disabled = false;
 }
 progress.innerHTML = '';
 }
 }

 var post = "";
 post += 'async=true&';
 post += 'CommandJavaButton$island->{'id'}=true&';
 post += 'JAVAMODE=java&';
 post += 'COMARY='+form.COMARY.value+'&';
 post += 'PASSWORD='+form.PASSWORD.value+'&';

 xmlhttp.send(post);
 return false;
}

//-->
</SCRIPT>
<DIV ID="mc_div" style="background-color:white;position:absolute;top:-50;left:-50;height:1.2em">&nbsp;</DIV>
<DIV ID="menu" style="position:absolute; top:-500;left:-500;">
<TABLE BORDER=0 BGCOLOR=#ccffcc>
<TR><TD NOWRAP>

END
	local($kind, $cost, $s, $tak);
	$tak = $HcommandTotal - 3;
	for($i = 0; $i < $tak; $i++) {
		$kind = $HcomList[$i];
		if($kind> 30 || $kind == 6){ next; }
		$cost = $HcomCost[$kind];
		if($cost == 0) {
			$cost = '무료'
		} elsif($cost < 0) {
			$cost = - $cost;
			$cost.= $HunitFood;
		} else {
			$cost.= $HunitMoney;
		}
		if($i == 7){ out("<HR SIZE=1>"); }
		out("<a href=\"javascript:void(0);\" onClick=\"cominput(6,${kind})\" STYlE=\"text-decoration:none\">$HcomName[$kind]($cost)<BR></A>\n");
	}

	out(<<END);
<HR SIZE=1>
<a href="Javascript:void(0);" onClick="menuclose()" STYlE="text-decoration:none">메뉴를 닫기</A>
</TD></TR>
</TABLE>
</DIV>
END
	islandInfo();

	out(<<END);
<CENTER>
<TABLE BORDER>
<TR valign=top>
<TD $HbgInputCell>
<CENTER>
<FORM name="myForm" action="$HthisFile" method=POST onsubmit="return send_command(this);">
<BR><nobr><center>미사일 발사상한 수[<b> $island->{'fire'} </b>]발</center></nobr><BR>
<INPUT TYPE=HIDDEN NAME=PASSWORD VALUE="$HdefaultPassword">
<HR>
<B>동 작<BR>
<A HREF=JavaScript:void(0); onClick="cominput(1)">삽입</A>
<A HREF=JavaScript:void(0); onClick="cominput(2)">덮어쓰기</A>
<A HREF=JavaScript:void(0); onClick="cominput(3);return false;">삭제</A></B>
<HR>
<B>계획번호</B><SELECT NAME=NUMBER onchange="selCommand(this.selectedIndex)">
END
	# 계획번호
	my($j, $i);
	for($i = 0; $i < $HcommandMax; $i++) {
		$j = $i + 1;
		out("<OPTION VALUE=$i>$j\n");
	}

	out(<<END);
</SELECT><BR>
<HR>
<B>개발계획</B><BR>
<SELECT NAME=COMMAND>
END

	#명령
	my($kind, $cost);
	for($i = 0; $i < $HcommandTotal; $i++) {
		$kind = $HcomList[$i];
		$cost = $HcomCost[$kind];
		if($cost == 0) {
			$cost = '무료'
		} elsif($cost < 0) {
			$cost = - $cost;
			$cost.= $HunitFood;
		} else {
			$cost.= $HunitMoney;
		}
		if(($kind < 60 && $kind != $HcomPrepRecr) || ($kind == $HcomAutoPrepare3)){
			$set_cost = "($cost)";
			out("<OPTION VALUE=$kind>$HcomName[$kind]$set_cost\n");
		}
	}

	out(<<END);
</SELECT>
<HR>
<B>좌표(</B>
<SELECT NAME=POINTX>

END
	for($i = 0; $i < $HislandSize; $i++) {
		out("<OPTION VALUE=$i>$i\n");
	}

	out(<<END);
</SELECT>, <SELECT NAME=POINTY>
END

	for($i = 0; $i < $HislandSize; $i++) {
		out("<OPTION VALUE=$i>$i\n");
	}
	out(<<END);
</SELECT><B>)</B>
<HR>
<B>수량</B><SELECT NAME=AMOUNT>
END

	# 수량
	for($i = 0; $i < 50; $i++) {
		out("<OPTION VALUE=$i>$i\n");
	}

	out(<<END);
</SELECT>
<HR>
<B>대상 섬</B>:
<B><BIG><A HREF=JavaScript:void(0); onClick="jump(myForm)" STYlE="text-decoration:none"> 표시 </A></BIG></B><BR>
<SELECT NAME=TARGETID>
END
	out(getIslandList($island->{'id'},1,$island->{'fight_id'}));
	out(<<END);
<BR>
</SELECT>
<HR>
<B> 명령 이동</B><br>
<BIG><A HREF=JavaScript:void(0); onClick="cominput(4)" STYlE="text-decoration:none"> ▲ </A>..
<A HREF=JavaScript:void(0); onClick="cominput(5)" STYlE="text-decoration:none"> ▼ </A></BIG>
<HR>
<INPUT TYPE="hidden" NAME="COMARY" value="comary">
<INPUT TYPE="hidden" NAME=JAVAMODE value="$HjavaMode">
<INPUT TYPE=submit VALUE="계획 전송" NAME=CommandJavaButton$island->{'id'}>
<span id="progress"></span>
<p><font size=2>마지막에 <font color=red>계획 전송 버튼</font>을<br>누르는 것을 잊지 마세요.</font>
</CENTER><BR>
</TD>
<TD $HbgMapCell><center>
<TEXTAREA NAME="COMSTATUS" cols="48" rows="2">
마지막에 계획 전송을 잊지 마세요.
삽입·덮어쓰기·삭제에서 계획의 입력이 가능합니다.
</TEXTAREA></center>
END
	islandMap(1, 1);	# 섬 지도, 소유자 모드
 out("</FORM>");
 islandMarking();
	my $comment = $Hislands[$HcurrentNumber]->{'comment'};
	out(<<END);
</TD>
<TD $HbgCommandCell id="plan" onmouseout="mc_out();return false;">
<CENTER><B>자동 입력</B><BR>
<SELECT NAME=AUTOCOMMAND ID=AUTOCOMMAND>
<OPTION VALUE="-101">일괄 자동 개간(무료)
<OPTION VALUE="-102">일괄 자동 매립(무료)
<OPTION VALUE="$HcomAutoPrepare3">$HcomName[$HcomAutoPrepare3](무료)
<OPTION VALUE="$HcomAutoDelete">$HcomName[$HcomAutoDelete](무료)
</SELECT><BR>
<INPUT TYPE=button VALUE="자동 계획 전송" onClick="return autoInputSubmit();">
</CENTER>
<HR>
<ilayer name="PARENT_LINKMSG" width="100%" height="100%">
 <layer name="LINKMSG1" width="200"></layer>
 <span id="LINKMSG1"></span>
</ilayer>
<BR>
</TD>
</TR>
</TABLE>
</CENTER>
<HR>
<CENTER>
${HtagBig_}코멘트갱신${H_tagBig}<BR>
<FORM action="$HthisFile" method="POST">
코멘트<INPUT TYPE=text NAME=MESSAGE SIZE=80 VALUE="$comment"><BR>
비밀번호<INPUT TYPE=password NAME=PASSWORD VALUE="$HdefaultPassword">
<INPUT TYPE="hidden" NAME=JAVAMODE VALUE="$HjavaMode">
<INPUT TYPE=submit VALUE="코멘트갱신" NAME=MessageButton$Hislands[$HcurrentNumber]->{'id'}>
</FORM>
</CENTER>
END

}

#----------------------------------------------------------------------
# 명령 모드
#----------------------------------------------------------------------
sub commandJavaMain {
	# id에서 섬을 가져옴
	$HcurrentNumber = $HidToNumber{$HcurrentID};
	my($island) = $Hislands[$HcurrentNumber];
	$HcurrentName = $island->{'name'};

	# 비밀번호
	if(!checkPassword($island->{'password'},$HinputPassword)) {
		# password 오류
		unlock();
		tempWrongPassword();
		return;
	}

	# 모드에서 분기
	my($command) = $island->{'command'};
	for($i = 0; $i < $HcommandMax; $i++) {
		# 명령 등록
		$HcommandComary =~ s/([0-9]*) ([0-9]*) ([0-9]*) ([0-9]*) ([0-9]*) //;
		$command->[$i] = {
			'kind' => $1==0 ? $HcomDoNothing : $1,
			'x' => $2,
			'y' => $3,
			'arg' => $4,
			'target' => $5
		};
	}
	# 데이터 쓰기
	writeIslandsFile($HcurrentID);

	if($Hasync) {
		unlock();
		out("OK");
	} else {
		tempCommandAdd();
		# owner mode 로
		ownerMain();
	}
}

#----------------------------------------------------------------------
# 관광 모드
#----------------------------------------------------------------------
sub printIslandJava {
	# 개방
	unlock();

	# id에서 섬 번호를 가져옴
	$HcurrentNumber = $HidToNumber{$HcurrentID};

	# 왠지그 섬이 없는 경우
	if($HcurrentNumber eq '') {
		tempProblem();
		return;
	}

	# 이름 가져오기
	$HcurrentName = $Hislands[$HcurrentNumber]->{'name'};

out(<<END);
<SCRIPT Language="JavaScript">
<!--

isIE4 = (navigator.appVersion.charAt(0)>=4 && (navigator.appVersion).indexOf("MSIE") != -1);
isNN4 = (navigator.appVersion.charAt(0)>=4 && (navigator.appName).indexOf("Netscape")!=-1);
isNN6 = (document.getElementById);

	if(isIE4){
		window.document.onmouseup = menuclose;
	} else {
		document.captureEvents(Event.MOUSEDOWN)
		document.onmousedown = getMouseData;
		if(!(isNN6)) {
			window.document.onmouseup = menuclose;
		}
	}

function ps(x, y) {
 if(document.mark_form.mark.checked) {
 set_mark(x, y);
 } else {
 window.opener.document.myForm.POINTX.options[x].selected = true;
 window.opener.document.myForm.POINTY.options[y].selected = true;
 showMenu();
 }
 return true;
}

function showMenu() {
	if((isNN6) && !(isIE4)){
		document.getElementById("menu").style.left = mx;
		document.getElementById("menu").style.top = my - 20;
		document.getElementById("menu").style.visibility = "visible";
		document.getElementById("menu").style.display = "block";
	} else if(isNN4) {
		document.menu.left = mx; // 가로
		document.menu.top = my - 15; // 세로
		document.menu.visibility = "show";
	} else if(isIE4) {
		menu.style.visibility = 'visible';
		menu.style.display = 'block';
		menu.style.left= event.clientX + document.body.scrollLeft;
		menu.style.top = event.clientY + document.body.scrollTop - 20;
	}
}

function menuclose() {
	if(isNN6) {
		document.getElementById("menu").style.display = "none";
	} else if(isNN4) {
		document.menu.visibility = "hide";
	} else {
		window["menu"].style.display = "none";
	}
}

function getMouseData(e) {
	mx = e.pageX;
	my = e.pageY;
}
function cominput(kind) {
	window.opener.cominput(6, kind, '', $HcurrentID);
	menuclose();
}

function ShowMsg(n){
	window.status = n;
}
//-->
</SCRIPT>

<DIV ID="menu" STYLE="position:absolute; visibility:hidden;">
<TABLE BORDER=0 BGCOLOR=#ccffcc>
<TR><TD NOWRAP>

END
	local($kind, $cost, $s, $tak);
	$tak = $HcommandTotal - 3;
	for($i = 0; $i < $tak; $i++) {
		$kind = $HcomList[$i];
		if(!($kind>= 30 and $kind <= 35)){ next; }
		$cost = $HcomCost[$kind];
		if($cost == 0) {
			$cost = '무료'
		} elsif($cost < 0) {
			$cost = - $cost;
			$cost.= $HunitFood;
		} else {
			$cost.= $HunitMoney;
		}
		if($i == 7){ out("<HR>"); }
		out("<a href=\"javascript:void(0);\" onClick=\"cominput(${kind})\" STYlE=\"text-decoration:none\">$HcomName[$kind]($cost)<BR></A>\n");
	}

	out(<<END);
<HR>
<a href="Javascript:void(0);" onClick="menuclose()" STYlE="text-decoration:none">메뉴를 닫기</A>
</TD></TR>
</TABLE>
</DIV>
<center>${HtagBig_}${HtagName_}'${HcurrentName} 섬'${H_tagName}${H_tagBig}
</center>
END
	islandMap(0, 1); # 섬 지도, 관광 모드
 islandMarking();
	landStringFlash(); # 의사MAP데이터 표시

	# 최근 상황
	tempRecent(0);

}

#----------------------------------------------------------------------
# 의사MAP데이터 생성
#----------------------------------------------------------------------
sub landStringFlash {
	my($island);
	$island = $Hislands[$HcurrentNumber];
	my($land) = $island->{'land'};
	my($landValue) = $island->{'landValue'};
	my($l, $lv);
	my($code) = "";
	my($befor) = "a";
	my($Count) = 0;
	my($Comp) = "";
	my($ret) = "";

	# 각 지형을 출력
	my($x, $y);
	for($y = 0; $y < $HislandSize; $y++) {

		# 각 지형을 출력
		for($x = 0; $x < $HislandSize; $x++) {
			$l = $land->[$x][$y];
			$lv = $landValue->[$x][$y];
			$code = landFlashData($l, $lv);

				if ($code eq $befor) {
					$Count++;
				} else {
					$Comp.= $befor;
					if( $Count != 0){
						$Comp.= ($Count - 1);
					}
					$Count = 0;
					$befor = $code;
				}
		}
 	}

	if($befor ne "a"){
		$Comp.= $befor;
		if( $Count != 0) {
			$Comp.= ($Count - 1);
		}
	}
	$Comp.= "\@";
	$Comp = substr($Comp,1);

	# 각 지형을 출력
	my($Compjs) = "";
	for($x = 0; $x < $HislandSize; $x++) {
		# 각 지형을 출력
		for($y = 0; $y < $HislandSize; $y++) {
			$l = $land->[$x][$y];
			$lv = $landValue->[$x][$y];
			$code = landFlashData($l, $lv);
			$Compjs.= $code;
		}
 	}

	out(<<END);
<CENTER><FORM>
의사MAP작성도구용 데이터(FLASH 판)<BR>
<TEXTAREA NAME="FLASH" cols="50" rows="3">$Comp</TEXTAREA><br>
<A HREF="http://www.din.or.jp/~mkudo/hako/flash/hako-map.html">
의사MAP작성도구(FLASH 판)을 온라인으로 시작</a><P>
의사MAP작성도구용 데이터(JavaScript판)<BR>
<TEXTAREA NAME="FLASH" cols="50" rows="4">$Compjs</TEXTAREA><br>
<A HREF="http://www.din.or.jp/~mkudo/hako/javascript/map.html">
의사MAP작성도구(JavaScript판)을 온라인으로 시작</a><BR><BR><BR>
<A HREF="http://www.din.or.jp/~mkudo/hako/">
의사MAP작성도구(JAVA·FLASH 판)을 다운로드하기</a><p>
</FORM>
</CENTER>
END

}

sub landFlashData {
	my($l, $lv) = @_;
	my($flash_data);

	if($l == $HlandSea) {
		# 얕은 바다
		if($lv == 1) {
			$flash_data = "o";
		} else {
			# 바다
			$flash_data = "a";
		}
	} elsif($l == $HlandWaste) {
		# 황무지
		if($lv == 1) {
			# 착탄 지점
			$flash_data = "n";
		} else {
			$flash_data = "b";
		}
	} elsif($l == $HlandPlains) {
		# 평지
		$flash_data = "c";
	} elsif($l == $HlandForest) {
		# 숲
		$flash_data = "g";
	} elsif($l == $HlandMountain) {
		# 산
		$flash_data = "l";
	} elsif($l == $HlandTown) {
		if($lv < 30) {
			# 마을
			$flash_data = "d";
		} elsif($lv < 100) {
			# 마을
			$flash_data = "e";
		} else {
			# 도시
			$flash_data = "f";
		}
	} elsif($l == $HlandFarm) {
		# 농장
		$flash_data = ($Hhide_farm) ? "g" : "h";;
	} elsif($l == $HlandFactory) {
		# 공장
		$flash_data = ($Hhide_factory) ? "g" : "i";
	} elsif($l == $HlandBase) {
		# 미사일 기지
		$flash_data = ($Hhide_missile) ? "g" : "j";
	} elsif($l == $HlandDefence) {
		# 방위 시설
		#$flash_data = "k";
		# 방위 시설은 숲이 됨
		$flash_data = ($Hhide_deffence) ? "g" : "k";
	} elsif($l == $HlandHaribote) {
		# 가짜 시설
		$flash_data = "k";
	} else {
		# 기타
		$flash_data = "b";
	}
	return $flash_data;
}




1;

