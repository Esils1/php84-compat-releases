#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}
#----------------------------------------------------------------------
# 모형정원 제도 ver2.30
# 톱 페이지 모듈(ver1.00)
# 사용 조건과 사용 방법은 hako-readme.txt 파일을 참조해 주세요
#
# 모형정원 제도의 페이지: http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html
#----------------------------------------------------------------------
# 모형정원 토너먼트 2
# 톱 페이지 모듈
# $Id: hako-top.cgi 31 2004-11-03 11:01:20Z gaba $

#----------------------------------------------------------------------
# 톱 페이지 모드
#----------------------------------------------------------------------
# 메인
sub topPageMain {
	# 개방
	unlock();

	# 템플릿출력
	tempTopPage();
}

# 톱 페이지
sub tempTopPage {

 # 제목
 out("${HtagTitle_}$Htitle${H_tagTitle}\n");

	# 라운드 수의 표시
	if($HislandTurn < $HyosenTurn) {
		out("${HtagFico_}≪예선≫${H_tagFico}\n");
	} elsif(($HislandNumber == 2) && ($HislandTurn != 0)) {
		out("${HtagFico_}≪결승전≫${H_tagFico}\n");
	} elsif($HislandNumber == 1 and $HislandTurn != 0) {
		out("${HtagFico_}≪종료≫${H_tagFico}\n");
	} else {
		out("${HtagFico_}≪제$HislandFightCount 회전≫${H_tagFico}\n");
	}

	# 새 화면을 열기 모드라면
	my $blank = ($Htop_blank) ? "" : "";

	# 디버그 모드이면 '턴 진행' 버튼
	if($Hdebug == 1) {
		out(<<END);
<FORM action="$HthisFile" method="POST">
<INPUT TYPE="submit" VALUE="턴을 진행하기" NAME="TurnButton">
</FORM>
END
	}

	my $cmt_ = 7;
	my($mStr1) = '';
	if($HhideMoneyMode != 0) {
		$mStr1 = "<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_} 자금${H_tagTH}</NOBR></TH>";
		$cmt_++;
	}

	my $fightmode = "";
	if($HislandFightMode == 1) {
		$fightmode = '<font color=red>전투 기간</font>';
		if($HislandChangeTurn == $HislandTurn){
			$fightmode.= '[다음 턴<font color=red>공격불가</font>]';
		} else {
			$fightmode.= '[턴'. ($HislandChangeTurn + 1). '는 공격불가]';
		}
	} elsif($HislandTurn < $HyosenTurn) {
		$fightmode = '<font color=blue>개발 기간</font>[턴'. ($HyosenTurn). '까지예선]';
	} else {
		$fightmode = '<font color=blue>개발 기간</font>';
		if($HislandChangeTurn == $HislandTurn){
			$fightmode.= '[다음 턴보다<font color=red>전투 시작</font>]';
		} else {
			$fightmode.= '[턴'. ($HislandChangeTurn + 1). '보다전투 시작]';
		}
	}
	out("<H1>${HtagHeader_}턴$HislandTurn${H_tagHeader} $fightmode</H1>");

	if($HislandNumber> 1 or $HislandTurn == 0) {
		# 시간 표시
		my($hour, $min, $sec);
		my($now) = time;
		my($showTIME) = ($HislandLastTime + $HunitTime - $now);
		$hour = int($showTIME / 3600);
		$min = int(($showTIME - ($hour * 3600)) / 60);
		$sec = $showTIME - ($hour * 3600) - ($min * 60);
		if ($sec < 0 or $HislandTurnCount> 1){
			out("<B><font size=+1>(${HtagHeader_}갱신해 주세요${H_tagHeader})</font></b>");
		} else {
			if(!$Htime_mode) {
				my($sec2,$min2,$hour2,$mday2,$mon2) = get_time($HislandLastTime + $HunitTime);
				out("<B><font size=+1>다음 갱신일 시 $mon2월$mday2일$hour2 시$min2분 남은 $hour 시간 $min 분 $sec 초</font></b>");
			} else {
				out("<B><font size=+1>(다음 턴까지, 남은 $hour 시간 $min 분 $sec 초)</font></b>");
			}
		}
	}

	# 개발 모드를 Cookie 보다읽기
 if($CjavaMode eq java) {
		$javacheck = 'checked';
 } else {
		$cgicheck = 'checked';
	}

 my $add;
 if($Htournament == 1) {
 $add = " <a href='$HthisFile?chart=1' STYlE='text-decoration:none'>".
 "${HtagHeader_}토너먼트 표${H_tagHeader}</a>";
 }
	# 양식
	out(<<END);
<SCRIPT language="JavaScript">
<!--
function develope(){
	//window.open("", "newWinTyotouA","menubar=no,toolbar=no,location=no,directories=no,status=yes,scrollbars=yes,resizable=yes,width=800,height=640");
	document.Island.target = "newWinTyotouA";
	document.Island.submit();
	document.Island.target = "";
	return true;
}

//-->
</SCRIPT>
<HR>

<TABLE>
<TR>
<TD>
<H1>${HtagHeader_}자신의 섬으로${H_tagHeader}</H1>
<FORM name="Island" action="$HthisFile" method="POST">
당신의 섬 이름은?<BR>
<SELECT NAME="ISLANDID">
$HislandList
</SELECT><BR>

비밀번호 입력!!<BR>
<INPUT TYPE="password" NAME="PASSWORD" VALUE="$HdefaultPassword" SIZE=32 MAXLENGTH=32><BR>
<INPUT TYPE="submit" VALUE="개발 화면으로">
<INPUT TYPE="BUTTON" VALUE="새창" onClick="develope()"><BR>
<INPUT TYPE="radio" NAME=JAVAMODE VALUE=cgi $cgicheck>일반 모드
<INPUT TYPE="radio" NAME=JAVAMODE VALUE=java $javacheck>JavaScript 모드
<INPUT TYPE="HIDDEN" NAME="OwnerButton">
</FORM>
</TD>
<TD WIDTH=50> </TD>
<TD>
<FONT size=+2><B>
<A HREF="$HthisFile?LogFileView=1" STYlE="text-decoration:none">${HtagHeader_}최근 사건${H_tagHeader}</A>
<BR><BR><BR>
<A HREF="$HthisFile?FightLog=0" STYlE="text-decoration:none">${HtagHeader_}대전 기록${H_tagHeader}</A>
$add
<BR><BR><BR>
</TD>
</TR></TABLE>
<HR>

<H1>${HtagHeader_}섬의 정보${H_tagHeader}</H1>
<P>
섬 이름을 클릭하면,<B>관광</B>할 수 있습니다.<BR>
순위를 클릭하면<B>간이 관광객 통신</B>을 표시합니다.
</P>
<TABLE BORDER>
<TR>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}순위${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_} 섬${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}대전 상대${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}인구${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}면적${H_tagTH}</NOBR></TH>
$mStr1
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}식량${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}농장규모${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}공장규모${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}채굴장규모${H_tagTH}</NOBR></TH>
</TR>
END

	my($island, $j, $farm, $factory, $mountain, $name, $id, $prize, $ii);
	for($ii = 0; $ii < $HislandNumber; $ii++) {
		# 레도라인용
		if($ii == $HfightMem){
			$HbgInfoCell	= $YbgInfoCell;
			$HbgCommentCell	= $YbgCommentCell;
			$HbgNameCell	= $YbgNameCell;
			$HbgNumberCell	= $YbgNumberCell;
			out ("<TR><TH colspan=".($cmt_+2)."><FONT SIZE=+1 COLOR=#C00000><i>- 예선통과 라인 -</I></FONT></TH></TR>");
		}
		$j = $ii + 1;
		$island = $Hislands[$ii];

		$id = $island->{'id'};
		$farm = $island->{'farm'};
		$factory = $island->{'factory'};
		$mountain = $island->{'mountain'};
		$farm	 = ($farm == 0) ? "보유하지 않음" : "${farm}0$HunitPop";
		$factory = ($factory == 0) ? "보유하지 않음" : "${factory}0$HunitPop";
		$mountain = ($mountain == 0) ? "보유하지 않음" : "${mountain}0$HunitPop";
		$farm 	 = "기밀" if($Hhide_farm == 2);
		$factory = "기밀" if($Hhide_factory == 2);

		if($island->{'absent'} == 0) {
			$name = "${HtagName_}$island->{'name'} 섬${H_tagName}";
		} else {
			$name = "${HtagName2_}$island->{'name'} 섬($island->{'absent'})${H_tagName2}";
		}

		my($flags);
		$flags = $island->{'prize'};
		$prize = '';

		# 이름에 순위 표시 문자를 추가
		my($f) = 1;
		my($i);
		for($i = 1; $i < 10; $i++) {
			if($flags & $f) {
				$prize.= "<IMG SRC=\"prize${i}.gif\" ALT=\"${Hprize[$i]}\" WIDTH=16 HEIGHT=16> ";
			}
			$f *= 2;
		}

		my($mStr1) = '';
		if($HhideMoneyMode == 1) {
			$mStr1 = "<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$island->{'money'}$HunitMoney</NOBR></TD>";
		} elsif($HhideMoneyMode == 2) {
			my($mTmp) = aboutMoney($island->{'money'});
			$mStr1 = "<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$mTmp</NOBR></TD>";
		}

		my($comname) ="${HtagTH_}코멘트:${H_tagTH}";
		if(($island->{'ownername'} ne '0') && ($island->{'ownername'} ne "코멘트")){
			$comname = "<FONT COLOR=\"blue\"><B>$island->{'ownername'}:</b></font>";
		}
		my $fight_name = '<CENTER>---</CENTER>';

		if($island->{'pop'} == 0) {
			$fight_name = "패배";
		} elsif($island->{'fight_id'}> 0) {
			my $HcurrentNumber = $HidToNumber{$island->{'fight_id'}};
			if($HcurrentNumber ne '') {
				my $tIsland = $Hislands[$HcurrentNumber];
				$fight_name = $tIsland->{'name'}."섬";
			}
		} elsif($HislandNumber == 1 and $HislandTurn> 0) {
			$fight_name = "<CENTER>우승!</CENTER>";
		} elsif($island->{'fight_id'} == -1) {
			$fight_name = "<CENTER>부전승</CENTER>";
		}
		$pop = ($Hhide_town) ? aboutPop($island->{'pop'}) : $island->{'pop'}.$HunitPop;

		out(<<END);
<TR>
<TD $HbgNumberCell ROWSPAN=2 align=center nowrap=nowrap><NOBR>
<A STYlE=\"text-decoration:none\" HREF="${HthisFile}?BBS=${id}"${blank}>${HtagNumber_}$j${H_tagNumber}</A></NOBR></TD>
<TD $HbgNameCell ROWSPAN=2 align=left nowrap=nowrap>
<NOBR>
<A STYlE=\"text-decoration:none\" HREF="${HthisFile}?Sight=${id}"${blank}>
$name
</A>
</NOBR><BR>
$prize
</TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$fight_name</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$pop</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$island->{'area'}$HunitArea</NOBR></TD>
$mStr1
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$island->{'food'}$HunitFood</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$farm</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$factory</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$mountain</NOBR></TD>
</TR>
<TR>
<TD $HbgCommentCell COLSPAN=$cmt_ align=left nowrap=nowrap><NOBR>$comname$island->{'comment'}</NOBR></TD>
</TR>
END
	}

	out(<<END);
</TABLE>

<HR>
<H1>${HtagHeader_}새 섬을 탐색${H_tagHeader}</H1>
END
	if($HislandTurn> 0) {
 out("도중에참가할 수 없습니다. 다음 회차 등록 시작까지, 잠시 기다려 주세요.<BR>\n");
	} elsif($HislandNumber < $HmaxIsland) {
		out(<<END);
<FORM action="$HthisFile" method="POST">
섬 이름<BR>
<INPUT TYPE="text" NAME="ISLANDNAME" SIZE=32 MAXLENGTH=32> 섬<BR>
비밀번호<BR>
<INPUT TYPE="password" NAME="PASSWORD" SIZE=32 MAXLENGTH=32><BR>
비밀번호 재확인<BR>
<INPUT TYPE="password" NAME="PASSWORD2" SIZE=32 MAXLENGTH=32><BR>

<INPUT TYPE="submit" VALUE="찾으러 가기" NAME="NewIslandButton"><BR><BR>
<font color=red>참고: 다른분와 동의 IP 주소에될 우려가 있는 분은, 사전에 메일에서 알려 주세요.
(가족·회회사등)<BR>
 중복 등록 및 오류 선택 발생할수 있습니다.<br>
도중에참가할 수 없습니다. 등록을 희망하는 분은 빠르게 신청해 주세요.
</font>
</FORM>
END
	} else {
		out("섬의 수가 최대 수입니다... 현재 등록할 수 없습니다.\n");
	}

	my($Himfflag);
	$Himfflag = $imageDir;

	out(<<END);
<HR><P>
<TABLE>
<TR><TD WIDTH=420 ROWSPAN=2 VALIGN=TOP>
<H1>${HtagHeader_} 정보 변경${H_tagHeader}</H1>
<P>
(주의) 이름 변경에는 $HcostChangeName${HunitMoney}이 들어갑니다.
</P>
<FORM action="$HthisFile" method="POST">
어느 섬입니까?<BR>
<SELECT NAME="ISLANDID">
$HislandList
</SELECT>
<BR>
새 이름을 입력하세요(변경하는 경우만)<BR>
<INPUT TYPE="text" NAME="ISLANDNAME" SIZE=32 MAXLENGTH=32> 섬<BR>
비밀번호(필수)<BR>
<INPUT TYPE="password" NAME="OLDPASS" SIZE=32 MAXLENGTH=32><BR>
새 비밀번호(변경할 경우만)<BR>
<INPUT TYPE="password" NAME="PASSWORD" SIZE=32 MAXLENGTH=32><BR>
비밀번호 재확인(변경할 경우만)<BR>
<INPUT TYPE="password" NAME="PASSWORD2" SIZE=32 MAXLENGTH=32><BR>

<INPUT TYPE="submit" VALUE="변경" NAME="ChangeInfoButton">
</FORM>

</TD>

<TD VALIGN=TOP WIDTH=350>
<H1>${HtagHeader_}이미지 경로 설정${H_tagHeader}</H1>
<NOBR>현재 설정<B>[</b> ${Himfflag} <B>]</B></NOBR>
<BR><A HREF=${imageExp}><FONT SIZE=+1> 설명 </FONT></A>
<form action=$HthisFile method=POST>
<INPUT TYPE=file NAME="IMGLINE">
<INPUT TYPE="submit" VALUE="설정" name=IMGSET>
</form>

<form action=$HthisFile method=POST>
Mac 사용자용<BR>
<INPUT TYPE=text NAME="IMGLINEMAC">
<INPUT TYPE="submit" VALUE="설정" name=IMGSET><BR>
<FONT SIZE=-1>Mac 사용자는, 여기를 사용해 주세요.</FONT>
</form>
</TD></TR>

<TR HEIGHT=100><TD ALIGN=CENTER>
<form action=$HthisFile method=POST>
<INPUT TYPE=hidden NAME="IMGLINE" value="deletemodenow">
<INPUT TYPE="submit" VALUE="설정 해제" name=IMGSET>
</form>
</TD></TR>
</TABLE>
<HR>
<H1>${HtagHeader_}소유자 이름 결정!${H_tagHeader}</H1>
<FORM action="$HthisFile" method="POST">
당신의 섬은?
<SELECT NAME="ISLANDID">
$HislandList
</SELECT> 이름 입력
<INPUT TYPE="text" NAME="OWNERNAME" SIZE=16 MAXLENGTH=32>
 비밀번호
<INPUT TYPE="password" NAME="OLDPASS" SIZE=16 MAXLENGTH=32>
<INPUT TYPE="submit" VALUE="이것로" NAME="ChangeOwnerName">
</form>
<HR>
<H1>${HtagHeader_}발견 기록${H_tagHeader}</H1>
END
	historyPrint();
}

# 기록 파일 표시
sub historyPrint {
	open(HIN, "${HdirName}/hakojima.his");
	my(@line, $l);
	while($l = <HIN>) {
		chomp($l);
		push(@line, $l);
	}
	@line = reverse(@line);

	foreach $l (@line) {
		$l =~ /^([0-9]*),(.*)$/;
		out("<NOBR>${HtagNumber_}턴${1}${H_tagNumber}:${2}</NOBR><BR>\n");
	}
	close(HIN);
}

#----------------------------------------------------------------------
# 로그 표시 모드
#----------------------------------------------------------------------
# 메인
sub logViewMain {

	# 개방
	unlock();

	# 템플릿출력
	tempLogPage();
}

sub tempLogPage {

	out(<<END);

<font size=+3><b>${HtagHeader_}최근 사건${H_tagHeader}</b></font>
 <FONT COLOR="blue" size=2><B><a href="$HthisFile?LogFileView=1">현 턴</a>
 <a href="$HthisFile?LogFileView=2">2턴분 표시</a>
END
	for($i = 3; $i -1 < $HlogMax; $i++) {
		out(" <a href=\"$HthisFile?LogFileView=${i}\">${i}턴분</a>\n");
	}
	out(<<END);
</b></font><br>
END
	logPrintTop();

}

# 로그 표시
sub logPrintTop {
	my($i);
	for($i = 0; $i < $Hlogturn; $i++) {
		out("<hr>\n");
		logFilePrint($i, 0, 0);

	}
}



1;
