#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}
#----------------------------------------------------------------------
# 모형정원 토너먼트 2
# 도움말모듈
# $Id: hako-help.cgi 60 2005-01-23 07:22:47Z takayama $

#----------------------------------------------------------------------
# 도움말페이지 모드
#----------------------------------------------------------------------
# 메인
sub helpPageMain {
	# 개방
	unlock();

	# 템플릿출력
	tempHelpPage();
}


sub tempHelpPage {

	# 데이터의 표시용 설정
	my($yosrep,$devrep,$firep);
	my($unit) = $HunitTime / 3600;
	my($deve) = $HdevelopeTime / 3600;
	my($fiunit) = $HfightTime / 3600;
	my($inter) = $HinterTime / 3600;
	$HdisFalldown /= 10;
	$HdisFallBorder++;

	$yosrep = '('. $HyosenRepCount. '턴정리해서갱신)' if($HyosenRepCount> 1);
	$devrep = '('. $HdeveRepCount. '턴정리해서갱신)' if($HdeveRepCount> 1);
	$firep = '('. $HfightRepCount. '턴정리해서갱신)' if($HfightRepCount> 1);

	$hide_mon = qw(은폐 표시 가능 100의 위에서 반올림)[$HhideMoneyMode];
	$hide_twn = qw(표시 가능 규모를 은 폐)[$Hhide_town];
	$hide_frm = qw(표시 가능 숲에위장 숲에위장\(규모도 은폐\))[$Hhide_farm];
	$hide_fac = qw(표시 가능 숲에위장 숲에위장\(규모도 은폐\))[$Hhide_factory];
	$hide_mis = qw(표시 가능 숲에위장)[$Hhide_missile];
	$hide_def = qw(표시 가능 숲에위장)[$Hhide_deffence];

	# 보상금 설정을 표시
 my $price;
	if($HrewardMode == 1) {
		$price = "(양측 미사일 기지의 수 + 양측 방위 시설의 수 × 2) ÷ ".
					"2 × 자신의 전투 행위 횟수 × 15 + 황무지(미사일 흔적만) × ".
 "$HcomCost[$HcomPrepare2] ".$HunitMoney;
	} elsif($HrewardMode == 2) {
		$price = "파괴되었습니다 농장·공장·미사일 기지·방위 시설의 건설비 + 황무지(미사일 흔적만) × ".
 "$HcomCost[$HcomPrepare2] ".$HunitMoney;
	} else {
		$price = "<FONT COLOR=RED>보상금 설정이정하 없습니다</FONT>";
	}

 # 대전 상대 결정 방식
 my $battle;
 if($Htournament == 1) {
 $battle = "토너먼트 표에종우";
 } else {
 $battle = "기본값 설정";
 }

 # 특수 설정
	my $mStr;
	if($HeasyReclaim) {
		$mStr.= "<H3>${HtagTH_}☆매립의 간이화${H_tagTH}</H3>\n";
		$mStr.= "→ 일반, 바다를 매립하면 얕은 바다가 되지만, 그 과정을를 거치지 않고 황무지가 됩니다.<BR>\n";
		$mStr.= "즉, 육지에 접한 바다라면, 한 번에서 황무지가 됩니다.<BR>\n";
		$mStr.= "원하는 형태의 섬을 만들기 쉬워지지만, 그만큼 마을이 생기기 어려워지므로,<BR>\n";
		$mStr.= "적당한 정도로만 사용하세요.<BR><BR>\n";
		$mStr.= "일반적으로 얕은 바다에서도 발생하지만, 성능은 같으므로 특별히 신경 쓸 필요는 없습니다.<BR>\n";
	}
	$mStr = "<B>없음</B><BR>" if(!$mStr);

	out(<<END);
${HtagTitle_} 설정 목록${H_tagTitle}
<BR>
<DIV ALIGN=RIGHT><I>system version ${version}</I></DIV><HR>
<BR>
<H1>${HtagHeader_}보상금 설정${H_tagHeader}</H1>
<B>
$price
</B><BR>
<BR><HR>
<H1>${HtagHeader_}대전 상대 결정 방식${H_tagHeader}</H1>
<B>
$battle
</B><BR>
<BR><HR>
<H1>${HtagHeader_}특수 설정${H_tagHeader}</H1>
<FONT SIZE=+1>${mStr}</FONT>
<BR><HR>
<H1>${HtagHeader_}각종 설정 값${H_tagHeader}</H1>
<table width=300 border $HbgNameCell>
<TR><TD colspan=2 $HbgTitleCell>${HtagTH_} 섬 수관계${H_tagTH}</TD></TR>
<TR><TD> ${HtagName_}최대 등록 수${H_tagName} </TD><TD><B>$HmaxIsland 섬</b></TD></TR>
<TR><TD> ${HtagName_}예선돌진파괴${H_tagName}</TD><TD><B>$HfightMem 위이상</b></TD></TR>

<TR><TD colspan=2 $HbgTitleCell>${HtagTH_} 섬의 초기 값${H_tagTH}</TD></TR>
<TR><TD> ${HtagName_}면적${H_tagName} </TD><TD><B>${HlandSizeValue}${HunitArea}</b></TD></TR>
<TR><TD> ${HtagName_}황무지의 수${H_tagName}</TD><TD><B>9케장소</b></TD></TR>
<TR><TD> ${HtagName_}얕은 바다의 수${H_tagName}</TD><TD><B>${HseaNum}케장소</b></TD></TR>
<TR><TD> ${HtagName_} 자금${H_tagName} </TD><TD><B>${HinitialMoney}${HunitMoney}</b></TD></TR>
<TR><TD> ${HtagName_}식량${H_tagName} </TD><TD><B>${HinitialFood}${HunitFood}</b></TD></TR>

<TR><TD colspan=2 $HbgTitleCell>${HtagTH_}위장 설정${H_tagTH}</TD></TR>
<TR><TD> ${HtagName_} 자금${H_tagName} </TD><TD><B>${hide_mon}</b></TD></TR>
<TR><TD> ${HtagName_}도시계${H_tagName} </TD><TD><B>${hide_twn}</b></TD></TR>
<TR><TD> ${HtagName_}농장${H_tagName} </TD><TD><B>${hide_frm}</b></TD></TR>
<TR><TD> ${HtagName_}공장${H_tagName} </TD><TD><B>${hide_fac}</b></TD></TR>
<TR><TD> ${HtagName_}미사일 기지${H_tagName} </TD><TD><B>${hide_mis}</b></TD></TR>
<TR><TD> ${HtagName_}방위 시설${H_tagName} </TD><TD><B>${hide_def}</b></TD></TR>

<TR><TD colspan=2 $HbgTitleCell>${HtagTH_}기타 설정 값${H_tagTH}</TD></TR>
<TR><TD> ${HtagName_}마을 발생률${H_tagName}</TD><TD><B>${HtownGlow}%</b></TD></TR>
<TR><TD> ${HtagName_}실업자 수상한${H_tagName}</TD><TD><B>${Hno_work}${HunitPop}</b></TD></TR>
<TR><TD> ${HtagName_}인구증가폭${H_tagName}</TD><TD><B>100~${HtownUp}${HunitPop}/턴</b></TD></TR>
<TR><TD> ${HtagName_}목의 늘어나면개 수${H_tagName}</TD><TD><B>${HtreeUp}00본/턴</b></TD></TR>
<TR><TD> ${HtagName_}방위 시설벌채대금${H_tagName}</TD><TD><B>${HdefenceValue}${HunitMoney}</b></TD></TR>
<TR><TD> ${HtagName_}자동포기 턴${H_tagName}</TD><TD><B>${HgiveupTurn}턴</b></TD></TR>
<TR><TD> ${HtagName_}최대 명령 입력 수${H_tagName}</TD><TD><B>${HcommandMax}개</b></TD></TR>
<TR><TD> ${HtagName_}지반 침하${H_tagName}</TD><TD><B>${HdisFallBorder}${HunitArea}/${HdisFalldown}%</b></TD></TR>

</table>
<BR><HR>
<H1>${HtagHeader_}턴 진행 도움말${H_tagHeader}</H1>
<table width=300 border $HbgNameCell>
<TR><TD colspan=2 $HbgTitleCell>${HtagTH_}턴 갱신 시간${H_tagTH}</TD></TR>
<TR><TD><NOBR> ${HtagName_}예선 기간${H_tagName}</NOBR></TD><TD NOWRAP><B>$unit 시간</b> ${yosrep}</TD></TR>
<TR><td WIDTH=100><NOBR> ${HtagName_}개발 기간${H_tagName}</NOBR></TD><TD NOWRAP><B>$deve 시간</b> ${devrep}</TD></TR>
<TR><TD><NOBR> ${HtagName_}전투 기간${H_tagName}</NOBR></TD><TD NOWRAP><B>$fiunit 시간</b> ${firep}</TD></TR>
<TR><TD><NOBR> ${HtagName_}전투에서 개발이전${H_tagName}</NOBR></TD><TD NOWRAP><B>$inter 시간후</b></TD></TR>

<TR><TD colspan=2 $HbgTitleCell>${HtagTH_}각 기간의 턴 수${H_tagTH}</TD></TR>
<TR><TD> ${HtagName_}예선${H_tagName} </TD><TD><B>$HyosenTurn 턴까지</b></TD></TR>
<TR><TD> ${HtagName_}개발 기간${H_tagName}</TD><TD><B><NOBR>$HdevelopeTurn 턴</NOBR></b></TD></TR>
<TR><TD NOWRAP> ${HtagName_}전투 기간${H_tagName}</TD><TD NOWRAP><B>$HfightTurn 턴</b></TD></TR>
<TR><TD NOWRAP> ${HtagName_}부전승 시의 개발 정지 ${H_tagName}</TD><TD NOWRAP><B>($HnofightUp	× 라운드 수 + $HnofightTurn)턴</b></TD></TR>

</table>
END

	my($fitone) = $HdevelopeTurn + $HyosenTurn;
	my($fittwo) = $fitone + $HfightTurn;
	my($fitNum) = 1;
	my($v_mode,$v_time,$v_turn,$v_text);
	$v_text = " ";

	# 턴 과정 일정표 표시용
	if(!$Htime_mode and $HislandTurn < $HyosenTurn) {
		$v_time = (($HyosenTurn - $HislandTurn) / $HyosenRepCount - 1) * $HunitTime + $HislandLastTime + $HunitTime;
		my($sec,$min,$hour,$mday,$mon) = get_time($v_time);
		$v_text = " ~ ".$mon."월".$mday."일".$hour."시".$min."분";
		$v_mode = 1;
		$v_time -= $HinterTime;
	}
	out(<<END);
<BR><HR>
<H1>${HtagHeader_}턴 진행 과정 빠름보기표${H_tagHeader}</H1>
참고: 이표가오류하고 있는 가능성이조금바 임시있으므로, 참고정도에보류해서하세요.
<table height=125 border $HbgNameCell>
<TR>
<td>${HtagName_}예선${H_tagName}</td>
<TD $HbgCommentCell><B>0 ~ $HyosenTurn</B></td>
<TD>$v_text</TD>
</tr>
END

	$HyosenTurn++;
	$v_time += $HunitTime;

	for($i = 2;$i <= $HfightMem;$i*=2) {
		my $kaisen = ($i*2> $HfightMem) ? "결승" : "제$fitNum 회";
		# 턴 과정 일정표 표시용
		if(!$Htime_mode and !$v_mode and $HislandTurn + 1>= $HyosenTurn and $HislandTurn + 1 <= $fitone) {
			$v_time += (($fitone - $HislandTurn) / $HdeveRepCount - 1) * $HdevelopeTime + $HislandLastTime;
			my($sec,$min,$hour,$mday,$mon) = get_time($v_time);
			$v_text = " ~ ".$mon."월".$mday."일".$hour."시".$min."분";
			$v_mode = 1;
		} elsif(!$Htime_mode and $v_mode) {
			$v_time += $HinterTime;
			my($sec,$min,$hour,$mday,$mon) = get_time($v_time);
			$v_time = $v_time + (($HdevelopeTurn - $HdeveRepCount) / $HdeveRepCount * $HdevelopeTime);
			my($sec2,$min2,$hour2,$mday2,$mon2) = get_time($v_time);
			$v_text = $mon."월".$mday."일".$hour."시".$min."분 ~ ". $mon2."월".$mday2."일".$hour2."시".$min2."분";
		}
	out(<<END);
<TR>
<TD ALIGN=RIGHT>${HtagName_}${kaisen}전쟁개발 기간${H_tagName}</td>
<TD $HbgCommentCell><B>$HyosenTurn ~ $fitone</b></td>
<TD>$v_text</TD>
</TR>
<TR>
<TD align=right>${HtagName_}전투 기간${H_tagName}</TD><TD $HbgCommentCell><B>
END
		# 턴 과정 일정표 표시용
		if(!$Htime_mode and !$v_mode and $HislandTurn + 1>= $fitone and $HislandTurn + 1 <= $fittwo) {
			$v_time += (($fittwo - $HislandTurn) / $HfightRepCount - 1) * $HfightTime + $HislandLastTime;
			my($sec,$min,$hour,$mday,$mon) = get_time($v_time);
			$v_text = " ~ ".$mon."월".$mday."일".$hour."시".$min."분";
			$v_mode = 1;
		} elsif(!$Htime_mode and $v_mode) {
			my($sec,$min,$hour,$mday,$mon) = get_time($v_time + $HfightTime);
			$v_time = $v_time + ($HfightTurn / $HfightRepCount * $HfightTime);
			my($sec2,$min2,$hour2,$mday2,$mon2) = get_time($v_time);
			$v_text = $mon."월".$mday."일".$hour."시".$min."분 ~ ". $mon2."월".$mday2."일".$hour2."시".$min2."분";
		}
		out (($fitone + 1). " ~ $fittwo</b></td><TD>$v_text</TD></tr>\n");
		$fitNum++;
		$HyosenTurn = $fittwo + 1;
		$fitone = $HyosenTurn + $HdevelopeTurn - 1;
		$fittwo = $fitone + $HfightTurn;
	}
	out("</table>\n<BR></hr>\n");
	out("<HR>${HtempBack}");
}

#----------------------------------------------------------------------
# 매뉴얼페이지 모드
#----------------------------------------------------------------------
# 메인
sub expPageMain {
	# 개방
	unlock();

	# 템플릿출력
	tempexpPage();
}

sub tempexpPage {

	# 표시용 설정
	$HunitTime /= 3600;
	$HdevelopeTime /= 3600;
	$HfightTime /= 3600;
	$HinterTime /= 3600;
	$HdisFalldown /= 10;
	$HdisFallBorder++;
	$precheap++;
	$precheap2 = $HcomCost[$HcomPrepare2] * $precheap2 / 10;
	$HfightTurnH = $HfightTurn / 2;

	# 보상금 설정
	if($HrewardMode == 1) {
		$reward_msg = "(양측 미사일 기지의 수 + 양측 방위 시설의 수 × 2) ÷ ".
					"2 × 자신의 전투 행위 횟수<SMALL>*</SMALL> × 15 + 황무지(미사일 흔적만) × ".
 "$HcomCost[$HcomPrepare2] ".$HunitMoney;
	} elsif($HrewardMode == 2) {
		$reward_msg = "파괴되었습니다 농장·공장·미사일 기지·방위 시설의 건설비 + 황무지(미사일 흔적만) × ".
 "$HcomCost[$HcomPrepare2] ".$HunitMoney;
	} else {
		$reward_msg = "<FONT COLOR=RED>보상금 설정이정하 없습니다</FONT>";
	}

	# 원형1페이지분의 HTML
	out("Content-type: text/html; charset=UTF-8\n\n");
	out(<<END);
<html>
<head>
<title>모형정원 토너먼트 2매뉴얼</title>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">

<STYLE type="text/css">
<!--
body	 { font-size: 13pt}
tr,td,th { font-size: 11pt}
a:link { font-size: 13pt; color:#000066 }
a:alink { font-size: 13pt; color:#000066 }
a:visited { font-size: 13pt; color:#000066 }
a:hover { font-size: 13pt; color:#FF0000 }
span { font-size: 25pt }
big { font-size: 15pt }
small { font-size: 11pt }
b { color:#ff3333 }
h2 { color:#006600 }
-->
</STYLE>
</head>
<body bgcolor="#ccccff">
<span><font color=#00cc99>모형정원 토너먼트 2</font></span>
<BR><BR>
기본은, 원본의 모형정원2와 같습니다.
<BR>원본의 모형정원2의 규칙은<a href=http://www.nn.iij4u.or.jp/~flora/>이주변</a>을 확인해 주세요.<BR>
<BR>
이 매뉴얼에서 설명하지 않은 사항은 기본적으로 위 내용의 원본판과 동일한 설정입니다.<BR>
잘 모르겠거나 의문이 있으면 부담 없이 게시판에서 질문해 주세요.

<BR><BR><HR><BR>
<h2>■어떤 게임인가요?</h2>
<B>1대1</b>의 토너먼트전쟁입니다.
<BR>정해진 대전 상대를 전투 기간 안에 격파하면 다음으로 진행합니다.<BR>
이를 수회반복해서, 최종적에남음했음<B>1섬</b>이우승입니다.<BR><BR><BR>

<h2>■먼저예선…</h2>
등록 후 처음의<B>제${HyosenTurn}턴</b>까지는, 예선 기간입니다.<BR>
제${HyosenTurn}턴의 시점에서 <B>합계${HfightMem} 섬</b>이 할 수 있도록 <u>인구가 적은</u> 섬이<B>예선 탈락</B>으로 됩니다.<BR>
이 기간은, 타 섬으로의 미사일 발사 명령은 모두 <B>취소</b>됩니다.<BR><BR>
추가로, 이후 1회전의 대전 상대가 결정. 개발 기간으로 이어집니다.<BR><BR>
방치되어 있어도 인구는 계속 증가하므로,<B> 자금 조달${HstopAddPop}회째부터는,</b><BR>
그 이후 인구의<B>자연 증가는 중단</b>합니다.<BR>
명령을 입력하면 원래대로 자연 증가합니다.<BR><BR>
또한, 마찬가지로<B>실업자</B>의 수가<B>${Hno_work}${HunitPop}이상</B>이 되면인구의<B>자연 증가는 중단</b>합니다.<BR>
실업자란 전혀 일하지 않는 주민을 말합니다.
<BR><BR>
이 기간의 인구 자연 증가는,<B>예선 기간만</B>입니다.<BR>
<BR><BR>
<h2>■개발 기간, 전투 기간에 대해</h2>

그후<B>${HdevelopeTurn}턴</b>은, 개발 기간입니다.<BR>
이 기간도,<B>미사일은 발사할 수 없음</b>이므로, 개발에 전념해 주세요.<BR>
개발 기간이 끝나면, 전투 기간이 됩니다.(전투 기간은${HfightTurn}턴)<BR>
전투 기간에는, 자신의<B>대전 상대에게만</b>미사일 발사가 허용됩니다.<BR>
살아남기 위해서는, 상대를 파괴해야 합니다.<BR>
전투 기간종료 시에,<B>인구가 많은</b>쪽이 승리가 됩니다.<BR>
패자의 섬은, 즉시 포기 처리됩니다. 최선을 다해 주세요.<BR>
<BR>
그후, 개발 기간>전투 기간>개발 기간... 로 계속 이어지며, 마지막 1섬이 됨까지, 계속됩니다.<BR>
<B>개발 기간</b>의 첫 턴에, 대전 상대가 결정합니다.<BR>
<BR><BR>

<h2>■턴 갱신에 대해</h2>
예선 기간 안은,<B>${HunitTime} 시간에서${HyosenRepCount}턴</b>진행됩니다.<BR>
개발 기간 안은,<B>${HdevelopeTime} 시간에서${HdeveRepCount}턴</b>진행됩니다.<BR>
전투 기간에는,<B>${HfightTime} 시간에서${HfightRepCount}턴</B>진행됩니다.<BR><BR>
개발 기간 마지막 턴 다음의 턴 갱신은 <B>${HfightTime}시간 후</B>가 됩니다. 약간 알기 어렵지만...<BR>
즉, 전투 기간에 들어가기까지 ${HfightTime}시간이 비어 있다는 뜻입니다.<BR>
또한, 전투 기간 종료 시점의 다음 턴은 ${HinterTime}시간 후에 갱신됩니다.<BR>
<B>설정 목록</B>이라는 의미이므로 확인해 주세요.
<BR><BR><BR>
<h2>■승패</h2>
승패는, 인구로 결정합니다.<BR>
만약, 인구가 완전히 <B>같다면</B>, 전 턴에서 더 높은 순위였던 쪽이 승자가 됩니다.<BR>
섬의 총수가 2로 나누어떨어지지 않으면, 어느 한 섬은 부전승이 됩니다.<BR>
또한, 승리 섬은,<B>보상금</b>을 받게 됩니다. 당연히 부전승한 섬은 보상금은 받지 않습니다.<BR><BR>
<B>보상금</b>은,<BR>
$reward_msg
입니다.<BR><BR>
또한, 전투 기간의 절반(${HfightTurnH}턴)이 경과할 시까지, 전투 행위 횟수<SMALL>*</SMALL>가 ${do_fight}턴을 채우지 못하면 패배 처리됩니다.<BR>
<BR><BR>

<h2>■부전승</h2>
대전 상대가 없는 경우·개발 기간종료 시까지에, 대전 상대가 없는 경우(포기등에서)는,<B>부전승</b>으로 됩니다.<BR>
부전승이 된 경우,<B>몇 턴 동안 <B>개발이 정지</b>합니다.<BR>
즉, 명령이 진행되지 않으며, 재해도 발생하지 않습니다.<BR>
개발 화면(또는 관광 화면)에서  남은 정지 턴이 표시되므로,0이 될 시까지정지 상태가 됩니다.<BR><BR>
개발 정지 기간은,<B>라운드 수×${HnofightUp}+${HnofightTurn}</b>입니다.<BR>
즉, 제1회전에서의 정지 기간은,16턴으로 됩니다.<BR><BR>
또한, 전투 기간의 절반(${HfightTurnH}턴)이 경과할 시까지,'상대가 없는 경우'및'상대의 전투 행위 횟수<SMALL>*</SMALL>가${do_fight}턴을 채우지 못한 경우'는 부전승으로 처리됩니다.<BR>
이 경우, 전투 시작 시의 섬의 상태로 복구되고, 개발 정지가 됩니다.<BR>
정지 기간은,<B>(라운드 수×${HnofightUp}+${HnofightTurn})- 경과 턴 수</B>입니다.
<BR><BR>
아직, 부전승은 하위권의 섬이 될 확률이 높습니다.
<BR><BR>
주:
전투 행위→미사일 기지건설·방위 시설 건설·각종 미사일 발사<BR>
<BR><BR>
<h2>■대전 상대 결정 방식</h2>
조금 복잡하지만, 대전 상대 결정 방법은 다음과 같습니다.<BR><BR>
END
 if($Htournament == 1) {
 out(<<END);
먼저, 예선 기간종료와 동시에 섬별로<b>'섬력'</b>을 할당합니다.<BR>
섬력은 아래 계산식을 기준으로 할당됩니다.<BR><BR>
250 × (인구 + 농장 + 공장 + 채굴장규모) + 면적 × 700 + 군사시설 수 × 1000 + 추정 자금 + 나무 수 × $HtreeValue - 황무지 × $HcomCost[$HcomPrepare2]<BR><BR>
다음에0~할당된 숫자값의 간에서 숫자를 하나, 무작위로 뽑습니다.<BR>
예를 들어 섬력이5000의 경우, 최종 섬력은,0~5000의 범위 중 하나가 됩니다.<BR><BR>
이최종적에할당된 섬 전력을, 상위 순서대로 나열하고, 위에서부터 순서대로 토너먼트 표에 배치합니다.
END
 } else {
 out(<<END);
먼저, 전투(예선) 기간 종료와 동시에 섬별로<b>'섬력'</b>을 할당합니다.<BR>
섬력은 아래 계산식을 기준으로 할당됩니다.<BR><BR>
250 × (인구 + 농장 + 공장 + 채굴장규모) + 면적 × 700 + 군사시설 수 × 1000 + 추정 자금 + 나무 수 × $HtreeValue - 황무지 × $HcomCost[$HcomPrepare2]<BR><BR>
다음에0~할당된 숫자값의 간에서 숫자를 하나, 무작위로 뽑습니다.<BR>
예를 들어 섬력이5000의 경우, 최종 섬력은,0~5000의 범위 중 하나가 됩니다.<BR><BR>
최종적으로 할당된 섬 전력을 상위 순서대로 나열하고, 위에서부터 차례대로 대전 상대로 배치합니다.
END
 }

 out(<<END);
<BR><BR><BR>
<h2>■폐지·변경·신규 명령 목록</h2>
<B>이하의 명령은 사용할 수 없습니다.</b><BR>
·식량지원<BR>
·자금지원<BR>
·유치 활동<BR>
·해저 기지건설<BR>
·ST미사일 발사<BR>
·육지 파괴탄환 발사<br>
·괴수 파견<BR>
·기념비 건조(발사)<BR><BR>
<B>이하의 명령은 변경되었습니다.</b><BR>
·각종 미사일 발사 -> 예선·개발 기간 안은, 발사할 수 없습니다. 전투 기간에는, 대전 상대에게만발사할 수 없습니다.<BR>
·굴착 -> 유전을 채굴할 수 없게 되었습니다. 바다에 실행하면, 취소됩니다.<BR>
·나무심기 -> ${HcomCost[$HcomPlant]}${HunitMoney}.<BR>
·벌채 -> 턴을 소비하지 않음. 방위시설에 실행하면,${HdefenceValue}${HunitMoney}로 매각 가능합니다. 물론 턴 소비 없음.<BR>
·방위 시설 -> ${HcomCost[$HcomDbase]}${HunitMoney} 관광객에게는 숲으로 보입니다. 매각할 수 있습니다.<BR><BR>
<B>아래는 새 명령입니다</b><BR>
·고속 농장 건설<BR>-> ${HcomCost[$HcomFastFarm]}${HunitMoney} 턴을 소비하지 않음 농장 건설 전투 기간에는 사용할 수 없습니다.<BR>
·일괄 자동 땅고르기<BR>-> 이 명령 하나로, 모든 황무지를 개간할 수 있습니다.${precheap}번째 황무지에서는, 비용이${precheap2}${HunitMoney}와 됩니다. 마찬가지로 전투 기간에는 사용 불가.<BR>
<BR><BR>

<h2>■재해</h2>

자연재해는 발생하지 않습니다.<BR>
발생하는 재해는 다음과 같습니다입니다.<BR><BR>

지반 침하 -> ${HdisFallBorder}헥스 이상이면${HdisFalldown}%<BR>

<BR><BR>

<h2>■섬의 초기 값·설정 등</h2>
설정 목록을 확인해 주세요.<BR>
<B>*중요한 설정이 있는 경우가 있으므로, 반드시 확인해 주세요.</B><BR>
<BR><BR>

<!--
<h2>■등록방법</h2>
등록은 <a href=mail.html>여기</a>에서 접수합니다.<BR>
기타 등록 방법은 접수하지 않습니다.<BR>
단, 게임 도중에서의 참가할 수 없습니다.<BR>
<B>선착순</b>이므로, 빈자리가 있어도 참가하지 못할 수 있습니다. 양해해 주세요.<BR>

<BR><BR>
-->
END

 my $log = int($HlogMax / 2);
 my $cmd = int($HcommandMax / 2);

 out(<<END);
<h2>■휴대전화대응</h2>
어디까지나 보조 기능이지만, 휴대전화에서 개발 계획을 입력할 수 있습니다.<BR>
<BR>

아래에 휴대전화 조작 방법을 설명하지만, 어느 정도 휴대전화와 모형정원 제도에 익숙한 사용자를 전제로 합니다.<BR>
그 때문에 이해하기 어려운 점도 많을 수 있으니 미리 양해해 주세요.<BR>
<BR>

먼저 가장 중요한 점은, 가로 폭이25바이트이상 표시할 수 없는 단말에서는 지도가정 화면에 표시되지 않습니다.<BR>
무슨 뜻인지 잘 모르겠다면, 아래 설명을 따라 개발 화면까지 진행해 보세요.<BR>
지도의 가로 폭이 화면 안에 들어간다고 있으면문제없습니다.<BR>
이 점은 앞으로도 변경할 수 없으므로, 기본 화면에 표시되지 않는 경우에는 포기해 주세요.<BR>
<BR>

휴대전화에서의 접속에는 자신의 섬의<B> 섬 번호</B>가 필요가 됩니다.<BR>
대전 상대가 있는 경우, 그 섬의<B> 섬 번호</B>함께 확인해 두는 것이 좋습니다.<BR>
<B> 섬 번호</B>은, 관광 화면에서 확인할 수 있습니다.<BR>
관광 화면으로 들어가면 주소가 '$HthisFile?Sight=12' 같은 형식으로 표시됩니다. 끝의 <B>12</B> 숫자가 해당 섬의 <B>섬 번호</B>입니다.<BR>
자신의 섬으로 관광을 가서 번호를 확인해 둡시다.<BR>
<BR>

여기까지 확인했으면 빠른 속도의 휴대전화로 접속해 봅시다.<BR>
휴대전화 전용의 주소등은 없으므로, PC 와 같은 주소에접속해 주세요.<BR>
접속하면, 입력 양식이 표시되면 ID 항목에 앞서 확인한 <B>섬 번호</B>를,
PS란에는<B> 비밀번호</B>을 입력하고 그 아래에 있는 버튼을 누릅시다.<BR>
색상 모드와 마지막 항목은 현재 사용하지 않으므로 기본값 그대로 두면 됩니다.<BR>
<BR>

'개발'을 클릭하면, 간이적나개발 화면이 표시됩니다.<BR>
여기에서 계획을 입력하거나, 사건을 확인할 수 있습니다.<BR>
지도 읽는 방법은 '도움말'을 보면 이해할 수 있습니다.<BR>
<BR>

'사건'을 클릭하면, 최근 사건이 표시됩니다.<BR>
PC 상에서 보기와 달리,${log}턴분의 로그만 표시되지 않습니다.<BR><BR>

'계획 목록'을 클릭하면, 입력 완료된 개발 계획이 표시됩니다.<BR>
<B>수량</B>은 x0처럼 간략화된 형식으로 표시됩니다.<BR>
<BR>

'계획입력'을 클릭하면, 개발 계획을 입력합니다.<BR>
화면 하단에는 입력완료미의 계획이${cmd}건 표시되 있습니다.<BR>
이 화면에서는, 이른바'일반 모드'와 같은 방식으로 계획의 입력을 합니다.<BR>
PC 와의 차이는, 계획번호, 좌표, 수량에 대해 수치를 직접 입력해야 한다는 점 정도입니다.<BR>
[]내의 수치에 대응하는 키를 입력하면, 해당 입력란에 바로 이동할 수 있습니다.<BR>
예를 들어 1을 입력하면 계획 번호 입력이 시작됩니다.(단말에 따라 이 기능이 지원되지 않을 수도 있습니다.)<BR>
<BR>

섬 번호와 비밀번호는 저장되지 않으므로, 매번 입력해야 합니다.<BR>
그래서, 북마크로의 등록해 두면, 입력 수고를 줄일 수 있습니다.<BR>
구체적으로는'$HthisFile?ID=12&PS=0123'라는 주소에접속하면, 자동으로 섬 번호12, 비밀번호0123와 입력 완료된 상태에서 접속 가능합니다.<BR>
ID 토 PS 부분에는 자신의 섬 번호와 비밀번호를 설정해 둡시다.<BR>
다른 사람에게북마크를 노출되면 비밀번호가 노출될 수 있으므로, 노출되면 위험한 비밀번호의 경우 비밀번호의 부분은 빈칸으로 두는 것을 권장합니다.<BR>
<BR>

마지막에<B>색상 모드</B>란, 각 헥스의 색 표시 상태를 표시합니다.<BR>
'표준'이 경우, 숲, 미사일 기지, 방위 시설이외의 헥스에는 색이 붙지 않습니다.<BR>
'전체색상'에서는 바다이외의 전체 헥스에 색이 붙습니다.<BR>
<B>전체색상</B>에서 는 용량도 상당히 커지므로, 이른바패킷량도 많아집니다.<BR>
<B>표준</B>라면용량도 작으므로이므로, 환경에 따라원하는 분을 선택해 주세요.<BR>
<BR>

<B>색상 모드</B>의 선택 상태도 섬 번호나 비밀번호와 같이 북마크로의 주소에 포함해 저장할 수 있습니다.<BR>
주소창의 끝에'&MP=1'와 추가하기만 하면 자동으로 전체색상이 선택됩니다.<BR>
<BR>

아직, 관광객 통신나 코멘트란등의 기능은 이용할 수 없습니다.<BR>
<BR><BR>

<h2>■주의 사항</h2>
살아남는 전쟁이므로, 미사일을 쏘는 것를 전제로 합니다.<BR>
미사일을 쏘지도 맞지도 않으려는 평화 지향 플레이어는 참가하지 않는 것을 권합니다.<BR><BR>
또한, 도중에 접속이 불가능해질 우려가 있는 분의 참가는 신중히 판단해 주세요.<BR>
도중에 포기하면, 그 시의 대전 상대가 유리해집니다.<BR><BR>
전투 기간에 들어가면, 전력을 다해 상대를 공격해 주세요.<BR>
고장의 에 바다을 대상으로 쏘거나, 대전 상대가 유리가 할 수 있도록 조작한 경우,<B>영구 추방</B>합니다.<BR><BR>
당연하지만, 중복 등록·복수 섬 관리·타사이트에서의, 뒷거래는 금지입니다.<BR>
발견되는 즉시, 문답 없이에서 삭제합니다.<BR>
여기는, 엄격하게 처리하겠습니다.<BR><BR>
추가로, 턴 갱신 시간에서의 브라우저 새로고침는<B>절대</b>하지 말아 주세요.<BR>
<B>데이터 파일이 손상될</b> 가능성이 있습니다!<BR><BR>
<HR>
<BR>
</body>
</htML>

END

}

1;
