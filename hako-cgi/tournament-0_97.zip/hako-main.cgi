#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}
# ↑은서버에 맞게 변경해 주세요.
# perl5용입니다.

#----------------------------------------------------------------------
# 모형정원 제도 ver2.30
# 메인 스크립트(ver1.02)
# 사용 조건과 사용 방법은 hako-readme.txt 파일을 참조해 주세요
#
# 모형정원 제도의 페이지: http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html
#----------------------------------------------------------------------
# 모형정원 토너먼트 2
# 메인 스크립트
# $Id: hako-main.cgi 66 2005-12-22 08:05:37Z takayama $

# 오류 확인용
#use CGI::Carp qw(fatalsToBrowser);

# 설정 파일읽기
require ('hako-ini.cgi');

#----------------------------------------------------------------------
# 아래쪽 스크립트는 변경을 전제로 하지 않습니다.
# 그래도 문제는 없습니다.
# 명령 이름과 가격 등은 알아보기 쉽게 두는 편이 좋습니다.
#----------------------------------------------------------------------

#----------------------------------------------------------------------
# 각종 상수
#----------------------------------------------------------------------

# 이 파일
$HthisFile = "$baseDir/hako-main.cgi";

# 지형 번호
$HlandSea		= 0; # 바다
$HlandWaste		= 1; # 황무지
$HlandPlains	= 2; # 평지
$HlandTown		= 3; # 마을 계열
$HlandForest	= 4; # 숲
$HlandFarm		= 5; # 농장
$HlandFactory	= 6; # 공장
$HlandBase		= 7; # 미사일 기지
$HlandDefence	= 8; # 방위 시설
$HlandMountain	= 9; # 산
$HlandHaribote	= 14; # 가짜 시설

# 명령
$HcommandTotal = 22; # 명령 종류
					 # 명령을 늘릴 경우, 부속의 readme 의주의사항을 반드시 읽어 주세요

# 계획 번호 설정
# 개간 계열
$HcomPrepare = 01; # 개간
$HcomPrepare2 = 02; # 땅고르기
$HcomReclaim = 03; # 매립
$HcomDestroy = 04; # 굴착
$HcomSellTree = 05; # 벌채
$HcomPrepRecr = 06; # 매립했을 시 + 땅고르기

# 작루계
$HcomPlant		= 11; # 나무심기
$HcomFarm		= 12; # 농장 건설
$HcomFactory	= 13; # 공장 건설
$HcomMountain	= 14; # 채굴장 건설
$HcomBase		= 15; # 미사일 기지건설
$HcomDbase		= 16; # 방위 시설 건설
$HcomHaribote	= 18; # 가짜 기지건설
$HcomFastFarm	= 19; # 고속 농장 건설

# 발사계
$HcomMissileNM	= 31; # 미사일 발사
$HcomMissilePP	= 32; # PP 미사일 발사

# 운영계
$HcomDoNothing	= 41; # 자금 조달
$HcomSell		= 42; # 식량 수출
$HcomGiveup		= 46; # 섬 포기

# 자동 입력
$HcomAutoPrepare	= 61; # 전체 개간
$HcomAutoPrepare2	= 62; # 전체땅고르기
$HcomAutoDelete		= 63; # 전체 명령 삭제
$HcomAutoPrepare3	= 45; # 일괄 자동 땅고르기

# 순서
@HcomList =
	($HcomPrepare, $HcomPrepare2, $HcomReclaim, $HcomDestroy,
	 $HcomSellTree, $HcomPrepRecr, $HcomPlant, $HcomFarm, $HcomFactory, $HcomMountain,
	 $HcomFastFarm, $HcomBase, $HcomDbase,
	 $HcomMissileNM, $HcomMissilePP, $HcomDoNothing, $HcomSell,
	 $HcomAutoPrepare, $HcomAutoPrepare2, $HcomAutoPrepare3, $HcomAutoDelete, $HcomGiveup);

# 계획 이름과 비용
$HcomName[$HcomPrepare]		= '개간';
$HcomCost[$HcomPrepare]		= 5;
$HcomName[$HcomPrepare2]	= '땅고르기';
$HcomCost[$HcomPrepare2]	= 100;
$HcomName[$HcomReclaim]		= '매립';
$HcomCost[$HcomReclaim]		= 100;
$HcomName[$HcomDestroy]		= '굴착';
$HcomCost[$HcomDestroy]		= 200;
$HcomName[$HcomPrepRecr]	= '매립 + 땅고르기';
$HcomCost[$HcomPrepRecr]	= 0;
$HcomName[$HcomSellTree]	= '벌채';
$HcomCost[$HcomSellTree]	= 0;
$HcomName[$HcomPlant]		= '나무심기';
$HcomCost[$HcomPlant]		= 10;
$HcomName[$HcomFarm]		= '농장 건설';
$HcomCost[$HcomFarm]		= 20;
$HcomName[$HcomFactory]		= '공장 건설';
$HcomCost[$HcomFactory]		= 100;
$HcomName[$HcomMountain]	= '채굴장 건설';
$HcomCost[$HcomMountain]	= 300;
$HcomName[$HcomFastFarm]	= '고속 농장 건설';
$HcomCost[$HcomFastFarm]	= 500;
$HcomName[$HcomBase]		= '미사일 기지건설';
$HcomCost[$HcomBase]		= 300;
$HcomName[$HcomDbase]		= '방위 시설 건설';
$HcomCost[$HcomDbase]		= 600;
$HcomName[$HcomHaribote]	= '가짜 기지건설';
$HcomCost[$HcomHaribote]	= 1;
$HcomName[$HcomMissileNM]	= '미사일 발사';
$HcomCost[$HcomMissileNM]	= 20;
$HcomName[$HcomMissilePP]	= 'PP 미사일 발사';
$HcomCost[$HcomMissilePP]	= 50;
$HcomName[$HcomDoNothing]	= '자금 조달';
$HcomCost[$HcomDoNothing]	= 0;
$HcomName[$HcomSell]		= '식량 수출';
$HcomCost[$HcomSell]		= -100;
$HcomName[$HcomGiveup]		= '섬 포기';
$HcomCost[$HcomGiveup]		= 0;
$HcomName[$HcomAutoPrepare]	= '개간 자동 입력';
$HcomCost[$HcomAutoPrepare]	= 0;
$HcomName[$HcomAutoPrepare2]= '땅고르기 자동 입력';
$HcomCost[$HcomAutoPrepare2]= 0;
$HcomName[$HcomAutoPrepare3] = '일괄 자동 땅고르기';
$HcomCost[$HcomAutoPrepare3] = 0;
$HcomName[$HcomAutoDelete]	= '전체계획을 백지 철회';
$HcomCost[$HcomAutoDelete]	= 0;

#----------------------------------------------------------------------
# 변수
#----------------------------------------------------------------------

# COOKIE
my($defaultID);		# 섬 이름

# 섬의 좌표 수
$HpointNumber = $HislandSize * $HislandSize;

# 디버그 모드 중에는 턴 일괄 갱신을 하지 않음
if($Hdebug == 1) {
	$HyosenRepCount	= 1;
	$HdeveRepCount	= 1;
	$HfightRepCount	= 1;
}

#----------------------------------------------------------------------
# 메인
#----------------------------------------------------------------------

# 문자 변환 라이브러리 로드

# '돌아가기'링크
$HtempBack = "<A HREF=\"$HthisFile\">${HtagBig_}맨 위로 돌아가기${H_tagBig}</A>";

$Body = "<BODY $htmlBody>";

my $agent=$ENV{'HTTP_USER_AGENT'};
if($agent =~ /(DoCoMo|J-PHONE|UP\.Browser|DDIPOCKET|ASTEL|PDXGW)/i) {
 # 휴대 단말
 $Hmobile = 1;
}

mente_mode() if(-e "./mente_lock");

# 잠금을 끼치기
if(!hakolock()) {
	# 잠금실패
	# 헤더출력
	tempHeader();

	# 잠금실패 메시지
	tempLockFail();

	# 푸터출력
	tempFooter();

	# 종료
	exit(0);
}

# 난수의 초기화
srand(time^$$);

# COOKIE 읽기
cookieInput();

# CGI 읽기
cgiInput();

# 섬 데이터 읽기
if(readIslandsFile($HcurrentID) == 0) {
	unlock();
	tempHeader();
	tempNoDataFile();
	tempFooter();
	exit(0);
}

if($Hmobile) {
	require('hako-mobile.cgi');
	exit(0);
}

# 템플릿을 초기화
tempInitialize();

# COOKIE 출력
cookieOutput();


if($HmainMode eq 'owner' && $HjavaMode eq 'java' ||
 $HmainMode eq 'commandJava' ||						# 명령 입력 모드
 $HmainMode eq 'comment' && $HjavaMode eq 'java' ||	# 코멘트입력 모드
 $HmainMode eq 'lbbs' && $HjavaMode eq 'java') {		# 로컬 BBS 모드

	$Body = "<BODY onload=\"init()\" $htmlBody>";
	require('hako-js.cgi');
	require('hako-map.cgi');

	# 헤더출력
	tempHeader();

	if($HmainMode eq 'commandJava') {
		# 개발 모드
		commandJavaMain();
	} elsif($HmainMode eq 'comment') {
		# 코멘트입력 모드
		commentMain();
	} elsif($HmainMode eq 'lbbs') {
		# 로컬 게시판 모드
		localBbsMain();
	} else {
		ownerMain();
	}

	# 푸터출력
	tempFooter();

	# 종료
	exit(0);

} elsif($HmainMode eq 'landmap') {
	require('hako-js.cgi');
	require('hako-map.cgi');
	$Body = "<BODY $htmlBody>";

	# 헤더출력
	tempHeader();
	# 관광 모드
	printIslandJava();
	# 푸터출력
	tempFooter();
	# 종료
	exit(0);
} elsif($HmainMode ne "expView") {
	# 헤더출력
	tempHeader();
}

if($HmainMode eq 'turn') {
	# 턴진행
	require('hako-turn.cgi');
	require('hako-top.cgi');
	turnMain();

} elsif($HmainMode eq 'new') {
	# 섬 신규 생성
	require('hako-turn.cgi');
	require('hako-map.cgi');
	newIslandMain();

} elsif($HmainMode eq 'print') {
	# 관광 모드
	require('hako-map.cgi');
	printIslandMain();

} elsif($HmainMode eq 'owner') {

	# 개발 모드
	require('hako-map.cgi');
	ownerMain();

} elsif($HmainMode eq 'command') {
	# 명령 입력 모드
	require('hako-map.cgi');
	commandMain();

} elsif($HmainMode eq 'comment') {
	# 코멘트입력 모드
	require('hako-map.cgi');
	commentMain();

} elsif($HmainMode eq 'lbbs') {
	# 로컬 게시판 모드
	require('hako-map.cgi');
	localBbsMain();

} elsif($HmainMode eq 'change') {
	# 정보 변경 모드
	require('hako-turn.cgi');
	changeMain();

} elsif($HmainMode eq 'FightView') {
	# LOG 모드
	require('hako-map.cgi');
	FightViewMain();

} elsif($HmainMode eq 'FightIsland') {
	# 패자의 섬 표시
	require('hako-map.cgi');
	fight_map();

} elsif($HmainMode eq 'logView') {
	# LOG 모드
	require('hako-top.cgi');
	logViewMain();

} elsif($HmainMode eq 'helpView') {
	# HELP 모드
	require('hako-help.cgi');
	helpPageMain();

} elsif($HmainMode eq 'chartView') {
	# 토너먼트 표 모드
	require('hako-chart.cgi');
	chartPageMain();

} elsif($HmainMode eq 'expView') {
	# exp 모드
	require('hako-help.cgi');
	expPageMain();

} else {
	# 그 외에는 톱 페이지 모드
	require('hako-top.cgi');
	topPageMain();
}

# 푸터출력
tempFooter() if($HmainMode ne "expView");

# 종료
exit(0);

# 명령을 앞으로 당기기
sub slideFront {
	my($command, $number) = @_;
	my($i);

	# 각각밀기
	splice(@$command, $number, 1);

	# 마지막에 자금 조달
	$command->[$HcommandMax - 1] = {
		'kind' => $HcomDoNothing,
		'target' => 0,
		'x' => 0,
		'y' => 0,
		'arg' => 0
		};
}

# 명령을 뒤로 밀기
sub slideBack {
	my($command, $number) = @_;
	my($i);

	# 각각밀기
	return if $number == $#$command;
	pop(@$command);
	splice(@$command, $number, 0, $command->[$number]);
}

#----------------------------------------------------------------------
# 섬 데이터 입출력
#----------------------------------------------------------------------

# 전체 섬 데이터 읽기
sub readIslandsFile {
	my($num) = @_; # 0이면 지형읽기 전
				 # -1이면 전체 지형을 읽어들임
				 # 번호가 지정되면 해당 섬의 지형만 읽어들임

	# 데이터 파일 열기
	if(!open(IN, "${HdirName}/hakojima.dat")) {
		rename("${HdirName}/hakojima.tmp", "${HdirName}/hakojima.dat");
		if(!open(IN, "${HdirName}/hakojima.dat")) {
			return 0;
		}
	}

	# 각매개변수읽기
	$HislandTurn	 = int(<IN>); # 턴 수
	$HislandLastTime = int(<IN>); # 최종 갱신 시간

	if($HislandLastTime == 0) {
		return 0;
	}
	$HislandNumber		= int(<IN>); # 섬의 총 수
	$HislandNextID		= int(<IN>); # 다음에 할당할 ID
	$HislandFightMode	= int(<IN>); # 현재의 전투 모드
	$HislandChangeTurn	= int(<IN>); # 전환에 턴
	$HislandFightCount	= int(<IN>); # 몇회전목카
	$HislandTurnCount	= int(<IN>); # 턴 갱신 횟수
	$HislandChart		= <IN>; # 토너먼트 표
	chomp($HislandChart);

	# 턴 처리판정
	my($now) = time;
	if((($Hdebug == 1 and $HmainMode eq 'Hdebugturn') or
		(($now - $HislandLastTime)>= $HunitTime) or ($HislandTurnCount> 1)) and $HislandNumber> 1) {
		$HmainMode = 'turn';
		$num = -1; # 전체 섬읽어들임
	}

	# 섬읽기
	my($i);
	for($i = 0; $i < $HislandNumber; $i++) {
		 $Hislands[$i] = readIsland($num);
		 $HidToNumber{$Hislands[$i]->{'id'}} = $i;
	}

	# 파일을 닫기
	close(IN);

	return 1;
}

# 섬 하나 읽기
sub readIsland {
	my($num) = @_;
	my($name, $id, $prize, $absent, $comment, $password, $money, $food,
	 $pop, $area, $farm, $factory, $mountain, $score, $fire, $ownername,
	 $fight_id, $reward, $missile, $log, $fly, $rest);
	$name = <IN>; # 섬 이름
	chomp($name);
	if($name =~ s/,(.*)$//g) {
		$score = int($1);
	} else {
		$score = 0;
	}
	$id = int(<IN>);		# ID 번호
	$prize = int(<IN>);		# 수상
	$absent = int(<IN>);	# 연속 자금 조달 수
	$comment = <IN>;		# 코멘트
	chomp($comment);
	$password = <IN>;		# 암호화 비밀번호
	chomp($password);
	$money = int(<IN>);		# 자금
	$food = int(<IN>);		# 식량
	$pop = int(<IN>);		# 인구
	$area = int(<IN>);		# 면적
	$farm = int(<IN>);		# 농장
	$factory = int(<IN>);	# 공장
	$mountain = int(<IN>);	# 채굴장
	$fire = int(<IN>);		# 미사일 발사 수
	$ownername = <IN>;		# 소유자네무
	chomp($ownername);
	$fight_id = int(<IN>);	# 대전 상대 ID
	$reward = int(<IN>);	# 보상금용플래그
	$missile = int(<IN>);	# 보상금용플래그2
	$log = int(<IN>);		# 시설파괴수
	$fly = int(<IN>);		# 피격 미사일 수
	$rest = int(<IN>);		# 오휴식미 기간

	# HidToName 테이블에 저장
	$HidToName{$id} = $name;

	# 지형
	my(@land, @landValue, $line, @command, @lbbs);

	if(($num == -1) || ($num == $id)) {
		if(!open(IIN, "${HdirName}/island.$id")) {
			rename("${HdirName}/islandtmp.$id", "${HdirName}/island.$id");
			if(!open(IIN, "${HdirName}/island.$id")) {
				exit(0);
			}
		}
		my($x, $y);
		for($y = 0; $y < $HislandSize; $y++) {
			$line = <IIN>;
			for($x = 0; $x < $HislandSize; $x++) {
				$line =~ s/^(.)(..)//;
				$land[$x][$y] = hex($1);
				$landValue[$x][$y] = hex($2);
			}
		}

		# 명령
		my($i);
		for($i = 0; $i < $HcommandMax; $i++) {
			$line = <IIN>;
			$line =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
			$command[$i] = {
				'kind' => int($1),
				'target' => int($2),
				'x' => int($3),
				'y' => int($4),
				'arg' => int($5)
				}
		}

		# 로컬 게시판
		for($i = 0; $i < $HlbbsMax; $i++) {
			$line = <IIN>;
			chomp($line);
			$lbbs[$i] = $line;
		}

		close(IIN);
	}

	# 섬 형태로 반환
	return {
		 'name' => $name,
		 'id' => $id,
		 'score' => $score,
		 'prize' => $prize,
		 'absent' => $absent,
		 'comment' => $comment,
		 'password' => $password,
		 'money' => $money,
		 'food' => $food,
		 'pop' => $pop,
		 'area' => $area,
		 'farm' => $farm,
		 'factory' => $factory,
		 'mountain' => $mountain,
		 'fire' => $fire,
		 'ownername' => $ownername,
		 'fight_id' => $fight_id,
		 'reward' => $reward,
		 'missile' => $missile,
		 'log' => $log,
		 'fly' => $fly,
		 'rest' => $rest,
		 'land' => \@land,
		 'landValue' => \@landValue,
		 'command' => \@command,
		 'lbbs' => \@lbbs,
	};
}

# 전체 섬 데이터 쓰기
sub writeIslandsFile {
	my($num) = @_;

	# 파일을 열기
	open(OUT, ">${HdirName}/hakojima.tmp");

	# 각매개변수쓰기
	print OUT "$HislandTurn\n";
	print OUT "$HislandLastTime\n";
	print OUT "$HislandNumber\n";
	print OUT "$HislandNextID\n";
	print OUT "$HislandFightMode\n";
	print OUT "$HislandChangeTurn\n";
	print OUT "$HislandFightCount\n";
	print OUT "$HislandTurnCount\n";
	print OUT "$HislandChart\n";

	# 섬의 쓰기
	my($i);
	for($i = 0; $i < $HislandNumber; $i++) {
		 writeIsland($Hislands[$i], $num);
	}

	# 파일을 닫기
	close(OUT);

	# 원래 이름으로
	unlink("${HdirName}/hakojima.dat");
	rename("${HdirName}/hakojima.tmp", "${HdirName}/hakojima.dat");
}

# 섬 하나 쓰기
sub writeIsland {
	my($island, $num) = @_;
	my($score);
	$score = int($island->{'score'});
	print OUT $island->{'name'}. ",$score\n";
	print OUT $island->{'id'}. "\n";
	print OUT $island->{'prize'}. "\n";
	print OUT $island->{'absent'}. "\n";
	print OUT $island->{'comment'}. "\n";
	print OUT $island->{'password'}. "\n";
	print OUT $island->{'money'}. "\n";
	print OUT $island->{'food'}. "\n";
	print OUT $island->{'pop'}. "\n";
	print OUT $island->{'area'}. "\n";
	print OUT $island->{'farm'}. "\n";
	print OUT $island->{'factory'}. "\n";
	print OUT $island->{'mountain'}. "\n";
	print OUT $island->{'fire'}. "\n";
	print OUT $island->{'ownername'}. "\n";
	print OUT $island->{'fight_id'}. "\n";
	print OUT $island->{'reward'}. "\n";
	print OUT $island->{'missile'}. "\n";
	print OUT $island->{'log'}. "\n";
	print OUT $island->{'fly'}. "\n";
	print OUT $island->{'rest'}. "\n";

	# 지형
	if(($num <= -1) || ($num == $island->{'id'})) {
		open(IOUT, ">${HdirName}/islandtmp.$island->{'id'}");

		my($land, $landValue);
		$land = $island->{'land'};
		$landValue = $island->{'landValue'};
		my($x, $y);
		for($y = 0; $y < $HislandSize; $y++) {
			for($x = 0; $x < $HislandSize; $x++) {
				printf IOUT ("%x%02x", $land->[$x][$y], $landValue->[$x][$y]);
			}
			print IOUT "\n";
		}

		# 명령
		my($command, $cur, $i);
		$command = $island->{'command'};
		for($i = 0; $i < $HcommandMax; $i++) {
			printf IOUT ("%d,%d,%d,%d,%d\n",
						 $command->[$i]->{'kind'},
						 $command->[$i]->{'target'},
						 $command->[$i]->{'x'},
						 $command->[$i]->{'y'},
						 $command->[$i]->{'arg'}
						 );
		}

		# 로컬 게시판
		my($lbbs);
		$lbbs = $island->{'lbbs'};
		for($i = 0; $i < $HlbbsMax; $i++) {
			print IOUT $lbbs->[$i]. "\n";
		}

		close(IOUT);
		unlink("${HdirName}/island.$island->{'id'}");
		rename("${HdirName}/islandtmp.$island->{'id'}", "${HdirName}/island.$island->{'id'}");
	}
}

#----------------------------------------------------------------------
# 입출력
#----------------------------------------------------------------------

# 표준 출력으로 출력
sub out {
	print STDOUT $_[0];
}

# 대전 기록 로그
sub Hfihgt_log {
	my $fight;

	# 라운드 수수대입
	my $fTurn = $HislandFightCount;
	# 결승전의 경우99로
	$fTurn = 99 if($HislandNumber == 1);

	open(DOUT, ">$HdirName/fight.log.bak");
	print DOUT "<${fTurn}>\n";
	print DOUT "<TABLE BORDER>\n";
	print DOUT "<tr><TH colspan=4></th><th $HbgTitleCell colspan=4>${HtagTH_}승자${H_tagTH}</th><TH colspan=1></th>\n";
	print DOUT "<TH $HbgTitleCell colspan=3>${HtagTH_}패자${H_tagTH}</th></tr>\n";
	print DOUT "<TR>\n";
	print DOUT "<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}승자${H_tagTH}</NOBR></TH>\n";
	print DOUT "<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}패자${H_tagTH}</NOBR></TH>\n";
	print DOUT "<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}피격 미사일 수${H_tagTH}</NOBR></TH>\n";
	print DOUT "<TH $HbgTitleCell width=15 nowrap=nowrap> </TH>\n";
	print DOUT "<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}보상금${H_tagTH}</NOBR></TH>\n";
	print DOUT "<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}인구${H_tagTH}</NOBR></TH>\n";
	print DOUT "<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}파괴미 기준 수${H_tagTH}</NOBR></TH>\n";
	print DOUT "<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}파괴 방어시 행 수${H_tagTH}</NOBR></TH>\n";
	print DOUT "<TH $HbgTitleCell width=15 nowrap=nowrap> </TH>\n";
	print DOUT "<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}인구${H_tagTH}</NOBR></TH>\n";
	print DOUT "<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}파괴미 기준 수${H_tagTH}</NOBR></TH>\n";
	print DOUT "<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}파괴 방어시 행 수${H_tagTH}</NOBR></TH>\n";
	print DOUT "</tr>\n";

	foreach $fight (@fight_log_flag) {
		my ($name,$tName,$reward,$log,$pop,$tLog,$tPop,$fly,$id) = split(",",$fight);
		$logD	= int($log / 1000)."기계";
		$logM	= ($log - $logD * 1000)."기계";
		$tLogD	= int($tLog / 1000)."기계";
		$tLogM	= ($tLog - $tLogD * 1000)."기계";
		$tName	= "<A STYlE=\"text-decoration:none\" HREF=\"".$HthisFile."?LoseMap=".$id."\">".
					$HtagName2_.$tName."섬".$H_tagName2."</A>";
		$tPop	.= ${HunitPop};
		if($id == -1) {
			$tName = "${HtagName2_}부전승${H_tagName2}";
			$tPop = "-";
			$tLogM = "-";
			$tLogD = "-";
		}
		print DOUT "<TR><TD $HbgInfoCell align=right><NOBR>${HtagName_}${name} 섬${H_tagName}</nobr></td>";
		print DOUT "<TD $HbgInfoCell align=center><NOBR>${tName}</nobr></td>\n";
		print DOUT "<TH $HbgInfoCell><NOBR>${fly}발</nobr></TH>\n";
		print DOUT "<TD $HbgInfoCell><NOBR> </nobr></td>\n";
		print DOUT "<TH $HbgInfoCell><NOBR>${reward}${HunitMoney}</nobr></TH>\n";
		print DOUT "<TH $HbgInfoCell><NOBR>${pop}${HunitPop}</nobr></TH>\n";
		print DOUT "<TH $HbgInfoCell><NOBR>${logM}</nobr></TH>\n";
		print DOUT "<TH $HbgInfoCell><NOBR>${logD}</nobr></TH>\n";
		print DOUT "<TD $HbgInfoCell><NOBR> </nobr></td>\n";
		print DOUT "<TH $HbgInfoCell><NOBR>${tPop}</nobr></TH>\n";
		print DOUT "<TH $HbgInfoCell><NOBR>${tLogM}</nobr></TH>\n";
		print DOUT "<TH $HbgInfoCell><NOBR>${tLogD}</nobr></TH>\n";
		print DOUT "</tr>\n";
	}
	print DOUT "</TABLE>\n";
	print DOUT @offset;
	close(DOUT);
	rename("${HdirName}/fight.log.bak","${HdirName}/fight.log");
}

# 예선 탈락 로그
sub Hlog_yosen {
	my $yosen;
	open(DOUT, ">$HdirName/fight.log");
	print DOUT "<0>\n";
	print DOUT "<TABLE BORDER>\n";
	print DOUT "<TR>\n";
	print DOUT "<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_} 섬${H_tagTH}</NOBR></TH>\n";
	print DOUT "<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}인구${H_tagTH}</NOBR></TH></tr>";
	foreach $yosen (@yosen_log) {
		my ($pop,$name) = split(",",$yosen);
		print DOUT "<TR><TD $HbgInfoCell align=right><NOBR>${HtagName_}${name} 섬${H_tagName}</nobr></td>";
		print DOUT "<TD $HbgInfoCell align=center><NOBR><B>${pop}$HunitPop</b></nobr></td></tr>\n";
	}
	print DOUT "</TABLE>\n";
	close(DOUT);
}

# CGI 읽기
sub cgiInput {
	my($line, $getLine);

	# 입력을 받아 UTF-8로 처리
	$line = <>;
	$line =~ tr/+/ /;
	$line =~ s/%([0-9A-Fa-f][0-9A-Fa-f])/pack('H2', $1)/eg;
	$line = $line;
	$line =~ s/[\x00-\x1f\,]//g;

	# GET 값을 받음
	$getLine = $ENV{'QUERY_STRING'};

	# 대상의 섬
	if($line =~ /CommandButton([0-9]+)=/) {
		# 명령 전송버튼의 경우
		$HcurrentID = $1;
		$defaultID = $1;
	}

	if($line =~ /ISLANDNAME=([^\&]*)\&/){
		# 이름 지정의 경우
		$HcurrentName = cutColumn($1, 32);
	}

	if($line =~ /ISLANDID=([0-9]+)\&/){
		# 기타의 경우
		$HcurrentID = $1;
		$defaultID = $1;
	}

	# 비밀번호
	if($line =~ /OLDPASS=([^\&]*)\&/) {
		$HoldPassword = $1;
		$HdefaultPassword = htmlEscape(cutColumn($1,32));
	}
	if($line =~ /PASSWORD=([^\&]*)\&/) {
		$HinputPassword = $1;
		$HdefaultPassword = htmlEscape(cutColumn($1,32));
	}
	if($line =~ /PASSWORD2=([^\&]*)\&/) {
		$HinputPassword2 = $1;
	}

	if($line =~ /JAVAMODE=(cgi|java)/) {
		$HjavaMode = $1;
	}

	# 비동기화통신플래그
	if($line =~ /async=true\&/) {
		$Hasync = 1;
	}

	# 메시지
	if($line =~ /MESSAGE=([^\&]*)\&/) {
		$Hmessage = cutColumn($1, 80);
	}

	# 로컬 게시판
	if($line =~ /LBBSNAME=([^\&]*)\&/) {
		$HlbbsName = $1;
		$HdefaultName = htmlEscape(cutColumn($1,32));
	}
	if($line =~ /LBBSMESSAGE=([^\&]*)\&/) {
		$HlbbsMessage = cutColumn($1, 80);
	}

	# 이미지 경로 설정 MAC 용
	if($line =~ /IMGLINEMAC=([^&]*)\&/){
		my($flag) = 'file:///'. $1;
		$HimgLine = htmlEscape($flag);
	}

	# 이미지 경로 설정
	if($line =~ /IMGLINE=([^&]*)\&/){
		my($flag) = substr($1, 0, -10);
		$flag =~ tr/\\/\//;
		if($flag eq 'del'){ $flag = $imageDir; } else { $flag = 'file:///'. $flag; }
		$HimgLine = htmlEscape($flag);
	}

	if($line =~ /OWNERNAME=([^\&]*)\&/){
		# 소유자 이름 지정의 경우
		$HownerName = cutColumn($1, 22);
	}

	if($line =~ /CommandJavaButton([0-9]+)=/) {
		# 명령 전송버튼의 경우(Java스크립트)
		$HcurrentID = $1;
		$defaultID = $1;
	}

	# 간이 관광객 통신의 경우
	if($line =~ /BBSMODE/) {
		$easy_mode = 1;
	}

	# main mode 의가져오기
	if($line =~ /TurnButton/) {
		if($Hdebug == 1) {
			$HmainMode = 'Hdebugturn';
		}
	} elsif($line =~ /OwnerButton/) {
		$HmainMode = 'owner';
	} elsif($getLine =~ /Sight=([0-9]*)/) {
		$HmainMode = 'print';
		$HcurrentID = $1;
	} elsif($getLine =~ /BBS=([0-9]*)/) {
		$HmainMode = 'print';
		$HcurrentID = $1;
		$easy_mode = 1;
	} elsif($line =~ /ChangeOwnerName/) {
		$HmainMode = 'change';
	} elsif($getLine =~ /LogFileView=([0-9]*)/) {
		$HmainMode = 'logView';
		$Hlogturn = ($1> $HlogMax) ? $HlogMax : $1;
	} elsif($getLine =~ /help/) {
		$HmainMode = 'helpView';
	} elsif($getLine =~ /chart/) {
		$HmainMode = 'chartView';
	} elsif($getLine =~ /exp/) {
		$HmainMode = 'expView';
	} elsif($getLine =~ /LoseMap=([0-9]*)/) {
		$HmainMode = 'FightIsland';
		$HcurrentID = $1;
	} elsif($getLine =~ /FightLog/) {
		$HmainMode = 'FightView';
	} elsif($getLine =~ /IslandMap=([0-9]*)/) {
		$HmainMode = 'landmap';
		$HcurrentID = $1;
	} elsif($line =~ /NewIslandButton/) {
		$HmainMode = 'new';
	} elsif($line =~ /LbbsButton(..)([0-9]*)/) {
		$HmainMode = 'lbbs';
		if($1 eq 'FO') {
			# 관광객
			$HlbbsMode = 0;
			$HforID = $HcurrentID;
		} elsif($1 eq 'OW') {
			# 섬주
			$HlbbsMode = 1;
		} else {
			# 삭제
			$HlbbsMode = 2;
		}
		$HcurrentID = $2;

		# 삭제할 수 없으므로 번호를 가져옴
		$line =~ /NUMBER=([^\&]*)\&/;
		$HcommandPlanNumber = $1;

	} elsif($line =~ /ChangeInfoButton/) {
		$HmainMode = 'change';
	} elsif($line =~ /MessageButton([0-9]*)/) {
		$HmainMode = 'comment';
		$HcurrentID = $1;
	} elsif($line =~ /CommandJavaButton/) {
		$HmainMode = 'commandJava';
		$line =~ /COMARY=([^\&]*)\&/;
		$HcommandComary = $1;
	} elsif($line =~ /CommandButton/) {
		$HmainMode = 'command';

		# 명령 모드의 경우, 명령의 가져오기
		$line =~ /NUMBER=([^\&]*)\&/;
		$HcommandPlanNumber = $1;
		$line =~ /COMMAND=([^\&]*)\&/;
		$HcommandKind = $1;
		$HdefaultKind = $1;
		$line =~ /AMOUNT=([^\&]*)\&/;
		$HcommandArg = $1;
		$line =~ /TARGETID=([^\&]*)\&/;
		$HcommandTarget = $1;
		$line =~ /POINTX=([^\&]*)\&/;
		$HcommandX = $1;
		$HdefaultX = $1;
		$line =~ /POINTY=([^\&]*)\&/;
		$HcommandY = $1;
		$HdefaultY = $1;
		$line =~ /COMMANDMODE=(write|insert|delete)/;
		$HcommandMode = $1;
	} elsif($line =~ /Mobile([0-9]*)/) {
		$HmainMode = $1;
	} else {
		$HmainMode = 'top';
	}

}


#cookie 입력
sub cookieInput {
	my($cookie);

	$cookie = htmlEscape($ENV{'HTTP_COOKIE'});

	if($cookie =~ /${HthisFile}OWNISLANDID=\(([^\)]*)\)/) {
		$defaultID = $1;
	}
	if($cookie =~ /${HthisFile}OWNISLANDPASSWORD=\(([^\)]*)\)/) {
		$HdefaultPassword = $1;
	}
	if($cookie =~ /${HthisFile}LBBSNAME=\(([^\)]*)\)/) {
		$HdefaultName = $1;
	}
	if($cookie =~ /${HthisFile}POINTX=\(([^\)]*)\)/) {
		$HdefaultX = $1;
	}
	if($cookie =~ /${HthisFile}POINTY=\(([^\)]*)\)/) {
		$HdefaultY = $1;
	}
	if($cookie =~ /${HthisFile}KIND=\(([^\)]*)\)/) {
		$HdefaultKind = $1;
	}
	if($cookie =~ /${HthisFile}IMGLINE=\(([^\)]*)\)/) {
		$HimgLine = $1;
		$HimgLine =~ s/데스크톱/데스크톱/g;
	}
	if($cookie =~ /${HthisFile}JAVAMODE=\(([^\)]*)\)/) {
		$CjavaMode = $1;
	}

}

#cookie 출력
sub cookieOutput {
	my($cookie, $info);

	# 삭제 가능 기한 설정
	my($sec, $min, $hour, $date, $mon, $year, $day, $yday, $dummy) =
		gmtime(time + 30 * 86400); # 현재 + 30일

	# 2자리화
	$year += 1900;
	if ($date < 10) { $date = "0$date"; }
	if ($hour < 10) { $hour = "0$hour"; }
	if ($min < 10) { $min = "0$min"; }
	if ($sec < 10) { $sec = "0$sec"; }

	# 요일일을 문자에
	$day = ("Sunday", "Monday", "Tuesday", "Wednesday",
			"Thursday", "Friday", "Saturday")[$day];

	# 월을 문자에
	$mon = ("Jan", "Feb", "Mar", "Apr", "May", "Jun",
			"Jul", "Aug", "Sep", "Oct", "Nov", "Dec")[$mon];

	# 경로와 기간 설정
	$info = "; expires=$day, $date\-$mon\-$year $hour:$min:$sec GMT\n";
	$cookie = '';

	if(($HcurrentID) && ($HmainMode eq 'owner')){
		$cookie.= "Set-Cookie: ${HthisFile}OWNISLANDID=($HcurrentID) $info";
	}
	if($HinputPassword) {
		$cookie.= "Set-Cookie: ${HthisFile}OWNISLANDPASSWORD=($HinputPassword) $info";
	}
	if($HcommandTarget) {
		$cookie.= "Set-Cookie: ${HthisFile}TARGETISLANDID=($HcommandTarget) $info";
	}
	if($HlbbsName) {
		$cookie.= "Set-Cookie: ${HthisFile}LBBSNAME=($HlbbsName) $info";
	}
	if($HcommandX) {
		$cookie.= "Set-Cookie: ${HthisFile}POINTX=($HcommandX) $info";
	}
	if($HcommandY) {
		$cookie.= "Set-Cookie: ${HthisFile}POINTY=($HcommandY) $info";
	}
	if($HcommandKind) {
		# 자동 입력 이외
		$cookie.= "Set-Cookie: ${HthisFile}KIND=($HcommandKind) $info";
	}
	if($HimgLine) {
		$cookie.= "Set-Cookie: ${HthisFile}IMGLINE=($HimgLine) $info";
	}
	if($HjavaMode) {
		$cookie.= "Set-Cookie: ${HthisFile}JAVAMODE=($HjavaMode) $info";
	}
	out($cookie);
}

#----------------------------------------------------------------------
# 유티리티
#----------------------------------------------------------------------
sub hakolock {
	if($lockMode == 1) {
		# rename 방식 잠금
		return hakolock1();

	} elsif($lockMode == 2) {
		# flock 방식 잠금
		return hakolock2();
	}
}

sub hakolock1 {
	# 잠금을 시도
	$lfh = file_lock() or die return 0;
	return 1;
}

sub hakolock2 {
	open(LOCKID, '>>hakojimalockflock');
	if(flock(LOCKID, 2)) {
		# 성공
		return 1;
	} else {
		# 실패
		return 0;
	}
}

# 잠금을 해제
sub unlock {
	if($lockMode == 1) {
		# rename 방식 잠금
		rename($lfh->{current}, $lfh->{path});
	} elsif($lockMode == 2) {
		# flock 방식 잠금
		close(LOCKID);

	}
}

# 새 잠금 방식
sub file_lock {
	my %lfh = (dir => "./", basename => "lockfile", timeout => $unlockTime, trytime => 3, @_);
	$lfh{path} = $lfh{dir}.$lfh{basename};

	for (my $i = 0; $i < $lfh{trytime}; $i++, sleep 1) {
		return \%lfh if (rename($lfh{path}, $lfh{current} = $lfh{path}. time));
	}

	opendir(LOCKDIR, $lfh{dir});
	my @filelist = readdir(LOCKDIR);
	closedir(LOCKDIR);

	foreach (@filelist) {
		if (/^$lfh{basename}(\d+)/) {
			return \%lfh if (time - $1> $lfh{timeout} and
			rename($lfh{dir}. $_, $lfh{current} = $lfh{path}. time));
			last;
		}
	}
	undef;
}

# 작은 쪽을 반환
sub min {
	return ($_[0] < $_[1]) ? $_[0] : $_[1];
}

# 비밀번호엔코드
sub encode {
	if($cryptOn == 1) {
		return crypt($_[0], 'h2');
	} else {
		return $_[0];
	}
}

# 비밀번호 확인
sub checkPassword {
	my($p1, $p2) = @_;
	$p1 =~ s/\r|\n//;

	# null 확인
	if($p2 eq '') {
		return 0;
	}

	# 마스터 비밀번호 확인
	if($masterPassword eq $p2) {
		return 1;
	}

	# 본래의 확인
	if($p1 eq encode($p2)) {
		return 1;
	}

	return 0;
}

# 1000명단위원형메루틴
sub aboutPop {
	my($p) = @_;
	if($p < 500) {
		return "추정5만 명이하";
	} else {
		$p = int(($p + 250) / 500) * 5;
		return "추정".$p."만 명";
	}
}

# 1000억단위원형메루틴
sub aboutMoney {
	my($m) = @_;
	if($m < 500) {
		return "추정500${HunitMoney}미만";
	} else {
		$m = int(($m + 500) / 1000);
		return "추정${m}000${HunitMoney}";
	}
}

# 1000억단위원형메루틴 섬력계산용
sub aboutMoney2 {
	my($m) = @_;
	if($m < 500) {
		return 500;
	} else {
		$m = int(($m + 500) / 1000);
		return $m;
	}
}

# 이스케이프문자의 처리
sub htmlEscape {
	my($s) = @_;
	$s =~ s/&/&amp;/g;
	$s =~ s/</&lt;/g;
	$s =~ s/>/&gt;/g;
	$s =~ s/\"/&quot;/g; #"
	$s =~ s/'/&#39;/g;
	$s =~ s/ /&#32;/g;
	return $s;
}

# 80자리에절리갖춤에
sub cutColumn {
	my($s, $c) = @_;
	if(length($s) <= $c) {
		return $s;
	} else {
		# 합계80자리가 됨까지절리 처리
		my($ss) = '';
		my($count) = 0;
		while($count < $c) {
			$s =~ s/(^[\x80-\xFF][\x80-\xFF])|(^[\x00-\x7F])//;
			if($1) {
				$ss.= $1;
				$count ++;
			} else {
				$ss.= $2;
			}
			$count ++;
		}
		return $ss;
	}
}

# 섬 이름으로 번호를 얻음(ID가 아니라 번호)
sub nameToNumber {
	my($name) = @_;

	# 전체 섬에서 찾기
	my($i);
	for($i = 0; $i < $HislandNumber; $i++) {
		if($Hislands[$i]->{'name'} eq $name) {
			return $i;
		}
	}

	# 찾을 수 없었던 경우
	return -1;
}

# 경험치에서 레벨을 산출
sub expToLevel {
	my($kind, $exp) = @_;
	my($i);
	if($kind == $HlandBase) {
		# 미사일 기지
		for($i = $maxBaseLevel; $i> 1; $i--) {
			if($exp>= $baseLevelUp[$i - 2]) {
				return $i;
			}
		}
		return 1;
	}
}

# (0,0)에서(size - 1, size - 1)까지의 숫자가한 번씩 나오도록
# (@Hrpx, @Hrpy)을 설정
sub makeRandomPointArray {
	# 초기 값
	my($y);
	@Hrpx = (0..$HislandSize-1) x $HislandSize;
	for($y = 0; $y < $HislandSize; $y++) {
		push(@Hrpy, ($y) x $HislandSize);
	}

	# 셔터 전체
	my ($i);
	for ($i = $HpointNumber; --$i; ) {
		my($j) = int(rand($i+1));
		if($i == $j) { next; }
		@Hrpx[$i,$j] = @Hrpx[$j,$i];
		@Hrpy[$i,$j] = @Hrpy[$j,$i];
	}
}

# 0에서(n - 1)의 난수
sub random {
	return int(rand(1) * $_[0]);
}

#
sub get_time {
	my $time = $_[0];
	my($sec,$min,$hour,$mday,$mon) = localtime($time);
	$mon = "0".$mon if($mon++ < 9);
	$mday = "0".$mday if($mday < 10);
	$hour = "0".$hour if($hour < 10);
	$min = "0".$min if($min < 10);
	if($_[1] == 1) {
		return '' if($time == 1);
		if($time + 60000 < time()) {
			$date = sprintf("</b>%02d/%02d<b>", $mon,$mday);
		} else {
			$date = sprintf("<b>%02d:%02d</b>", $hour,$min);
		}
		return "(${date})";
	}
	return ($sec,$min,$hour,$mday,$mon);
}

#----------------------------------------------------------------------
# 로그 표시
#----------------------------------------------------------------------
# 파일 번호를 지정해 로그 표시
sub logFilePrint {
	my($fileNumber, $id, $mode, $kankou) = @_;
	open(LIN, "${HdirName}/hakojima.log$_[0]");
	my($line, $m, $turn, $id1, $id2, $message);
	my($fi) = 0;

	while($line = <LIN>) {
		$line =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),(.*)$/;
		($m, $turn, $id1, $id2, $message) = ($1, $2, $3, $4, $5);

		# 기밀관계
		if($m == 1) {
			if(($mode == 0) || ($id1 != $id)) {
				# 기밀 표시 권한 없음
				next;
			}
			$m = '<B>(기밀)</B>';
		} elsif($m == 2 and !$id) {
			next;
		} else {
			$m = '';
		}

		# 정확히 표시할지
		if($id != 0) {
			if(($id != $id1) &&
			 ($id != $id2)) {
				next;
			}
		}
		next if($id and $id2 and $id != $id2 and $Hmissile_log);

		# 표시
 if($kankou == 2) {
 $message =~ s/<[^>]*>//g;
			out("[$turn] $m $message<BR>\n");
 } elsif($kankou == 1) {
			out("<NOBR>${HtagNumber_}턴$turn$m${H_tagNumber}:$message</NOBR><BR>\n");
		} elsif(($fi == 0) && ($mode == 0)) {
			out("<NOBR><BR><B><I><FONT COLOR='#000000' SIZE=+2>턴$turn$m:</FONT></I></B><BR><HR width=50% align=left>\n");
			out("<NOBR>${HtagNumber_}턴$turn$m${H_tagNumber}:$message</NOBR><BR>\n");
			$fi++;
		} else {
			out("<NOBR>${HtagNumber_}턴$turn$m${H_tagNumber}:$message</NOBR><BR>\n");
		}
	}

	close(LIN);
}

#----------------------------------------------------------------------
# 템플릿
#----------------------------------------------------------------------
# 초기화
sub tempInitialize {
	# 섬 선택(기본값은 자신)
	$HislandList = getIslandList($defaultID);
}

# 섬 데이터 드롭다운 메뉴용
sub getIslandList {
	my($select,$mode,$target) = @_;
	my($list, $name, $id, $s, $i);

	#섬 목록의 메뉴
	$list = '';
	for($i = 0; $i < $HislandNumber; $i++) {
		$name = $Hislands[$i]->{'name'};
		$id = $Hislands[$i]->{'id'};
		if($mode and $id != $select and $id != $target) {
			next;
		}
		if(($id eq $select and !$mode) or ($id eq $target and $mode)) {
			$s = 'SELECTED';
		} else {
			$s = '';
		}
		$list.=
			"<OPTION VALUE=\"$id\" $s>${name} 섬\n";
	}
	return $list;
}

# 잠금실패
sub tempLockFail {
	# 제목
	out(<<END);
${HtagBig_}동시접속오류입니다.<BR>
브라우저의'돌아가기'버튼을 누름시,<BR>
잠시 기다렸다가 다시오시 도시하세요.${H_tagBig}$HtempBack
END
}

# 강제 해제
sub tempUnlock {
	# 제목
	out(<<END);
${HtagBig_}지난 접속이 비정상 종료된 것 같습니다.<BR>
잠금을 강제 해제했습니다.${H_tagBig}$HtempBack
END
}

# hakojima.dat 이 없음
sub tempNoDataFile {
	out(<<END);
${HtagBig_}데이터 파일을 열 수 없습니다.${H_tagBig}$HtempBack
END
}

# 비밀번호 오류
sub tempWrongPassword {
	out(<<END);
${HtagBig_} 비밀번호가 다릅니다.${H_tagBig}$HtempBack
<SCRIPT LANGUAGE="JavaScript">
<!--
function init() {}
//-->
</SCRIPT>
END
}

# 무언가문제발생
sub tempProblem {
	out(<<END);
${HtagBig_}문제발생, 일단복귀해 주세요.${H_tagBig}$HtempBack
END
}

# 점검안
sub mente_mode {
	# 헤더출력
	tempHeader();

	# 메시지
	out("${HtagBig_}단지지금점검안입니다.<BR>잠시쿠기다려 주세요.${H_tagBig}");

	# 푸터출력
	tempFooter();

	# 종료
	exit(0);
}
