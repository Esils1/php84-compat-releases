#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}
#----------------------------------------------------------------------
# 모형정원 토너먼트 2
# 휴대 단말모듈
# $Id: hako-mobile.cgi 60 2005-01-23 07:22:47Z takayama $

McgiInput();

tempHeader();

if($HmainMode eq 'turn') {
 # 턴 갱신대기치
 MturnPageMain();
} elsif($HmainMode eq 0) {
 # 관광 화면
 MprintMain(0);
} elsif($HmainMode eq 1) {
 # 사건
 MlogMain();
} elsif($HmainMode eq 2) {
 # 개발 화면
 MprintMain(1);
} elsif($HmainMode eq 3) {
 # 계획 목록
 McmdMain(0);
} elsif($HmainMode eq 4) {
 # 계획입력
 McmdMain(1);
} elsif($HmainMode eq 'command') {
 # 계획입력
 McmdInputMain();
} elsif($HmainMode eq 'chartView') {
 # 섬 번호 목록
 MlistPageMain();
} elsif($HmainMode eq 'helpView') {
 # 섬 번호 목록
 MhelpPageMain();
} elsif($HmainMode eq 'expView') {
 # 섬 번호 목록
 MlinkPageMain();
} else {
 MtopPageMain();
}

tempFooter();

#----------------------------------------------------------------------
# 유티리티
#----------------------------------------------------------------------

# CGI 읽기
sub McgiInput {
 my $getLine = $ENV{'QUERY_STRING'};

 if($getLine =~ /ID=([0-9]+)/){
 $HcurrentID = $1;
 }
 if($getLine =~ /PS=([^\&]*)/){
 $HinputPassword = $1;
 }
 if($getLine =~ /MP=([0-9]+)/){
 $HlbbsName = $1;
 }

 if($HmainMode eq 'print') {
 $HmainMode = 0;
 }

 $HlbbsName =~ tr/0-9//cd;
}

# 섬의 존재 확인
sub MexistCheck {
 my $mode = shift;
 unlock() if(!$mode);

 $HcurrentNumber = $HidToNumber{$HcurrentID};

 # 왠지그 섬이 없는 경우
 if($HcurrentNumber eq '') {
 tempProblem();
 return 1;
 }

 return 0;
}

# 비밀번호 확인
sub MpassCheck {
 my $island = $Hislands[$HcurrentNumber];

 # 비밀번호
 if(!checkPassword($island->{'password'},$HinputPassword)) {
 # password 오류
 tempWrongPassword();
 return 1;
 }

 return 0;
}

# 지도 모드
sub MprintMain {
 my $mode = shift;

 if(MexistCheck()) {
 return;
 }
 if($mode) {
 if(MpassCheck()) {
 return;
 }
 }

 MislandInfo($mode); # 섬의 정보
 MislandMap($mode); # 섬 지도
}

# 사건
sub MlogMain {
 my $mode = 0;

 if(MexistCheck()) {
 return;
 }

 if($HinputPassword) {
 if(MpassCheck()) {
 return;
 }

 $mode = 1;
 }

 MtoMapLink($mode);

 my $i;
 for($i = 0; $i < $HlogMax/2; $i++) {
 logFilePrint($i, $HcurrentID, $mode, 2);
 }
}

# 개발계획
sub McmdMain {
 my $mode = shift;

 if(MexistCheck() or MpassCheck()) {
 return;
 }

 MtoMapLink(1);
 if($mode == 0) {
 McmdListPageMain($HcommandMax);
 } else {
 McmdInputPageMain();
 }
}

# 개발계획입력 처리
sub McmdInputMain {
 if(MexistCheck(1) or MpassCheck()) {
 unlock();
 return;
 }

 require('hako-map.cgi');

 my $island = $Hislands[$HcurrentNumber];

 $HcommandPlanNumber--;

 commandAdd($island);

 unlock();

 $HcommandPlanNumber++;
 MtoMapLink(1);
 McmdInputPageMain();
}

# 섬의 정보
sub MislandInfo {
 my $mode = shift;
 my $island = $Hislands[$HcurrentNumber];

 # 정보 표시
 my $rank = $HcurrentNumber + 1;
 my $farm = $island->{'farm'};
 my $factory = $island->{'factory'};
 my $mountain = $island->{'mountain'};
 my $name;

 # 예선 기간, 실업자가상한을 상회라고 있었음라경고
 my $mStr1 = '';
 if($HislandTurn < $HyosenTurn) {
 my $tmp = int($island->{'pop'} - ($farm + $factory + $mountain) * 10);
 $tmp = 0 if($tmp < 0);
 $mStr1 = "<FONT COLOR=RED>실업자가".$Hno_work.$HunitPop.
 "이상출하고 있으므로, 인구 증가가 중단합니다. 생산시설을 건설테테하세요.</FONT><br>" if($tmp>= $Hno_work);
 }

 $farm = ($farm == 0) ? "-" : "${farm}0$HunitPop";
 $factory = ($factory == 0) ? "-" : "${factory}0$HunitPop";
 $mountain = ($mountain == 0) ? "-" : "${mountain}0$HunitPop";
 $farm = "기밀" if($Hhide_farm == 2);
 $factory = "기밀" if($Hhide_factory == 2);

 my($mStr2) = '';
 if(($HhideMoneyMode == 1) || ($mode == 1)) {
 # 무조건또는 owner 모드
 $mStr2 = "$island->{'money'}$HunitMoney";
 } elsif($HhideMoneyMode == 2) {
 $mStr2 = aboutMoney($island->{'money'});
 }

 # 대전 상대의 표시
 my $fight_name = '';
 if($island->{'fight_id'}> 0 and $island->{'pop'}> 0) {
 my $HcurrentNumber = $HidToNumber{$island->{'fight_id'}};
 if($HcurrentNumber ne '') {
 my $tIsland = $Hislands[$HcurrentNumber];
 my $name = '<A HREF="'.$HthisFile."?Sight=$tIsland->{'id'}&MP=$HlbbsName\">$tIsland->{'name'} 섬</A>";
 $fight_name = "상대: $name<br>";
 }
 }

 # 개발 정지의 표시
 my $rest_msg = '';
 if($island->{'rest'}> 0 and $HislandNumber> 1 and $island->{'pop'}> 0) {
 $rest_msg = "부전승으로 개발 정지 중 ";
 $rest_msg.= "남은<FONT COLOR=RED>".$island->{'rest'}."</FONT>턴<br>";
 }

 # 인구의 표시
 $pop = (!$Hhide_town or $mode == 1) ? $island->{'pop'}.$HunitPop : aboutPop($island->{'pop'});

 my $cmd;
 if($mode) {
 $name = "$island->{'name'} 섬개발 화면";
 $cmd = '<br><input type="submit" name="Mobile3" value="계획 목록">';
 $cmd.= '<input type="submit" name="Mobile4" value="계획입력">';
 } else {
 $name = "$island->{'name'} 섬 관광 화면";
 }

 out(<<END);
$name<br>
<hr>
순위: $rank<br>
인구: $pop<br>
자금: $mStr2<br>
식량: $island->{'food'}$HunitFood<br>
면적: $island->{'area'}$HunitArea<br>
농장: $farm<br>
공장: $factory<br>
채택채굴: $mountain<br>
$rest_msg
$fight_name
$mStr1
<hr>
<form action="./hako-main.cgi" method="POST">
<input type="hidden" name="ISLANDID" value="$island->{'id'}">
<input type="hidden" name="PASSWORD" value="$HinputPassword">
<input type="hidden" name="LBBSNAME" value="$HlbbsName">
<input type="submit" name="Mobile1" value="사건">
$cmd
</form>
<hr>
END
}

# 섬 지도
sub MislandMap {
 my $mode = shift;
 my $island = $Hislands[$HcurrentNumber];

 # 지형, 지형 값을 가져옴
 my($x, $y);
 my $land = $island->{'land'};
 my $landValue = $island->{'landValue'};

 # 좌표(상)을 출력
 for($x = 0; $x < $HislandSize; $x++) {
 out(qw(0 1 2 3 4 5 6 7 8 9)[($x%10)]);
 }
 out("<br>\n");

 # 각 지형및 줄바꿈을 출력
 for($y = 0; $y < $HislandSize; $y++) {
 # 짝 수행이면 번호 출력
 if(($y % 2) == 0) {
 my $line = ($y>= 10) ? $y-10 : $y;
 out($line);
 }

 # 각 지형을 출력
 for($x = 0; $x < $HislandSize; $x++) {
 my $l = $land->[$x][$y];
 my $lv = $landValue->[$x][$y];
 MlandString($l, $lv, $x, $y, $mode);
 }

 # 홀 수행이면 번호 출력
 if(($y % 2) == 1) {
 my $line = ($y>= 10) ? $y-10 : $y;
 out($line);
 }

 # 줄바꿈을 출력
 out("<br>\n");
 }

 out("&nbsp;");
 for($x = 0; $x < $HislandSize; $x++) {
 out(qw(0 1 2 3 4 5 6 7 8 9)[($x%10)]);
 }
 out("<br>\n");
}

# 1헥스
sub MlandString {
 my($l, $lv, $x, $y, $mode, $comStr) = @_;
 my($point) = "($x,$y)";
 my($alt, $color, $img);

 if($l == $HlandSea) {
 if($lv == 1) {
 # 얕은 바다
 $alt = '-';
 $color = '#6666FF';
 } else {
 # 바다
 $alt = '·';
 }
 } elsif($l == $HlandWaste) {
 # 황무지
 $alt = '■';
 $color = '#800000';
 } elsif($l == $HlandPlains) {
 # 평지
 $alt = '□';
 $color = '#00F000';
 } elsif($l == $HlandForest) {
 # 숲
 $alt = "숲";
 $color = '#008800';
 } elsif($l == $HlandTown) {
 if($lv < 30) {
 $alt = '마을';
 $color = '#999900';
 } elsif($lv < 100) {
 $alt = '마을';
 $color = '#996600';
 } elsif($lv < 200) {
 $alt = '도시';
 $color = '#666600';
 } else {
 $alt = '거대';
 $color = '#660000';
 }
 } elsif($l == $HlandFarm) {
 # 농장
 if($Hhide_farm and $mode == 0) {
 $alt = '숲';
 $color = '#008800';
 } else {
 $alt = "농업";
 $color = '#0000FF';
 }
 } elsif($l == $HlandFactory) {
 # 공장
 if($Hhide_factory and $mode == 0) {
 $alt = '숲';
 $color = '#008800';
 } else {
 $alt = "공사";
 $color = '#606060';
 }
 } elsif($l == $HlandBase) {
 if($mode == 0) {
 # 관광객의 경우
 $alt = ($Hhide_missile) ? '숲' : '미';
 } else {
 # 미사일 기지
 $alt = "미";
 }
 $color = '#008800';
 } elsif($l == $HlandDefence) {
 # 방위 시설
 if($Hhide_deffence and $mode == 0) {
 $alt = '숲';
 $color = '#008800';
 } else {
 $alt = '방어';
 $color = '#FF0000';
 }
 } elsif($l == $HlandHaribote) {
 # 가짜 시설
 if($mode == 0) {
 # 관광객에게는 방위 시설처럼 표시
 $alt = '방어';
 } else {
 $alt = '하';
 }
 $color = '#FF0000';
 } elsif($l == $HlandMountain) {
 # 산
 if($lv> 0) {
 $alt = "채택";
 } else {
 $alt = '산';
 }
 $color = '#C03030';
 }

 if($color and $HlbbsName == 1) {
 $alt = "<font color='$color'>$alt</font>";
 } elsif($color eq '#008800' or $colore eq '#FF0000') {
 $alt = "<font color='$color'>$alt</font>";
 }

 out $alt;
}

#----------------------------------------------------------------------
# HTML 출력
#----------------------------------------------------------------------
# 턴 갱신대기치
sub MturnPageMain {
 unlock();

 out("턴 갱신대기치입니다. 잠시 기다렸다가 접속해 주세요.");
}

# 섬 번호 목록
sub MlistPageMain {
 unlock();

 out("[순위] 섬 번호: 섬 이름<hr>");
 for($i = 0; $i < $HislandNumber; $i++) {
 my $j = $i + 1;
 my $island = $Hislands[$i];
 out("[$j] $island->{'id'}: $island->{'name'} 섬<br>\n");
 }
}

# 계획입력
sub McmdInputPageMain {
 my $island = $Hislands[$HcurrentNumber];

 $HcommandPlanNumber++;
 $HcommandKind = 0 if($HcommandKind eq '');
 $HcommandArg = 0 if($HcommandArg eq '');
 $HcommandX = 0 if($HcommandX eq '');
 $HcommandY = 0 if($HcommandY eq '');
 $HcommandMode = 'insert' if($HcommandMode eq '');

 out(<<END);
<form action="./hako-main.cgi" method="POST">
계획번호(1~$HcommandMax)<br>
[1]<input type="text" name="NUMBER" value="$HcommandPlanNumber" size="2" accesskey="1" istyle="4"><br>
<br>

계획<br>
<select name="COMMAND" accesskey="2">
END

 #명령
 my($kind, $cost);
 for($i = 0; $i < $HcommandTotal; $i++) {
 my $s;
 $kind = $HcomList[$i];
 $cost = $HcomCost[$kind];
 if($cost == 0) {
 $cost = '무료'
 } elsif($cost < 0) {
 $cost = - $cost;
 $cost.= $HunitFood;
 } else {
 $cost.= $HunitMoney;
 }
 $s = ' selected' if($kind == $HcommandKind);

 out("<option value='$kind'$s>$HcomName[$kind]($cost)\n");
 }

 out(<<END);
</select><br>
<br>
좌표(가로, 세로)<br>
[2]<input type="text" name="POINTX" value="$HcommandX" size="2" accesskey="2" istyle="4">,
[3]<input type="text" NAME="POINTY" value="$HcommandY" size="2" accesskey="3" istyle="4"><br>
<br>

수량(0~49)<br>
[4]<input type="text" name="AMOUNT" value="$HcommandArg" size="2" accesskey="4" istyle="4"><br>
<br>

목표<br>
<select name="TARGETID" accesskey="6">
END
 out(getIslandList($island->{'id'},1,$island->{'fight_id'}));
 out(<<END);
<br>
</select><br>
<br>
동작<br>
<input type="radio" name="COMMANDMODE" value="insert" accesskey="5" checked>[5]삽입<br>
<input type="radio" name="COMMANDMODE" value="write" accesskey="6">[6] 덮어쓰기<br>
<input type="radio" name="COMMANDMODE" value="delete" accesskey="7">[7] 삭제<br>
<br>
<input type="hidden" name="PASSWORD" value="$HinputPassword">
<input type="hidden" name="LBBSNAME" value="$HlbbsName">
<input type="submit" value="계획 전송" name="CommandButton$island->{'id'}">
</form>
<hr>
END
 McmdListPageMain($HcommandMax/2);
}

# 계획 목록
sub McmdListPageMain {
 my $max = shift;

 for($i = 0; $i < $max; $i++) {
 MtempCommand($i, $Hislands[$HcurrentNumber]->{'command'}->[$i]);
 }
}

# 계획 표시
sub MtempCommand {
 my($number, $command) = @_;
 my($kind, $target, $x, $y, $arg) =
 (
 $command->{'kind'},
 $command->{'target'},
 $command->{'x'},
 $command->{'y'},
 $command->{'arg'}
 );
 my $name = "${HcomName[$kind]}";
 my $point = "($x,$y)";

 my($j) = sprintf("[%02d] ", $number + 1);

 out("$j");

 if(($kind == $HcomDoNothing) || ($kind == $HcomAutoPrepare3) || ($kind == $HcomGiveup)) {
 out($name);
 } elsif(($kind == $HcomMissileNM) || ($kind == $HcomMissilePP)) {
 # 미사일계
 $target = $HidToName{$target};
 $target = ($target eq '') ? "무인 섬" : "${target} 섬";

 $name =~ s/발사//;
 out("$target$point 로${name}x$arg");
 } elsif($kind == $HcomSell) {
 # 식량 수출
 out("${name}x$arg");
 } elsif(($kind == $HcomFarm) || ($kind == $HcomFactory) || ($kind == $HcomMountain)) {
 # 횟수 포함
 if($arg == 0) {
 out("$point 에서$name");
 } else {
 out("$point 에서$name($arg 회)");
 }
 } else {
 # 좌표 포함
 out("$point 에서$name");
 }

 out("<br>\n");
}

# 각종링크
sub MlinkPageMain {
 my $bbTime = get_time((stat($bbsLog))[9], 1, 1);
 unlock();

 out(<<END);
- <A HREF="http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html">모형정원 제도 스크립트 배포처</A><br>
<BR>
- <A HREF="$toppage">홈</A><br>
- <A HREF="$bbs">$bbsname</A>$bbTime<br>
END
}

# 지도도움말
sub MhelpPageMain {
 unlock();

 out(<<END);
<font color="#6666FF">-</font> → 얕은 바다<br>
· → 바다<br>
<font color="#800000">■</font> → 황무지<br>
<font color="#00F000">□</font> → 평지<br>
<font color="#008800">숲</font> → 숲<br>

<font color="#999900">마을</font> → 마을<br>
<font color="#996600">마을</font> → 마을<br>
<font color="#666600">도시</font> → 도시<br>
<font color="#660000">거대</font> → 2만 명규것 도시<br>

<font color="#0000FF">농업</font> → 농장<br>
<font color="#606060">공사</font> → 공장<br>
<font color="#C03030">채택</font> → 채굴장<br>
<font color="#C03030">산</font> → 산<br>

<font color="#008800">미</font> → 미사일 기지<br>
<font color="#FF0000">방어</font> → 방위 시설<br>
<font color="#FF0000">하</font> → 가짜 시설<br>
END
}

# 톱 페이지
sub MtopPageMain {
 unlock();

 if($HlbbsName ne '') {
 $sL[$HlbbsName] = ' selected';
 } else {
 $sL[0] = ' selected';
 }

 if($HislandNumber> 1 or $HislandTurn == 0) {
 # 시간 표시
 my($hour, $min, $sec);
 my($now) = time;
 my($showTIME) = ($HislandLastTime + $HunitTime - $now);
 $hour = int($showTIME / 3600);
 $min = int(($showTIME - ($hour * 3600)) / 60);
 $sec = $showTIME - ($hour * 3600) - ($min * 60);
 if ($sec < 0 or $HislandTurnCount> 1){
 out("(턴 갱신대기치입니다. 잠시 기다렸다가 접속해 주세요.)");
 } else {
 if(!$Htime_mode) {
 my($sec2,$min2,$hour2,$mday2,$mon2) = get_time($HislandLastTime + $HunitTime);
 out("다음 갱신일 시 $mon2월$mday2일$hour2 시$min2분<br>남은 $hour 시간 $min 분 $sec 초");
 } else {
 out("(다음 턴까지, 남은 $hour 시간 $min 분 $sec 초)");
 }
 }
 }

 out(<<END);
<hr>
<form action="./hako-main.cgi" method="POST">
ID:<input type="text" name="ISLANDID" size="3" value="$HcurrentID" istyle="4"><br>
PS:<input type="text" name="PASSWORD" size="6" value="$HinputPassword" istyle="3"><br>
색상 모드:<br>
<select name="LBBSNAME">
<option$sL[0] value="0">표준
<option$sL[1] value="1">전체색상
</select><br>
<input type="submit" name="Mobile2" value="개발">
<input type="submit" name="Mobile0" value="관광">
<input type="submit" name="Mobile1" value="사건">
</form>

<br>
<a href="./hako-main.cgi?chart=1"> 섬 번호 목록</a>
END
}

# 지도 화면로의 양식링크
sub MtoMapLink {
 my $mode = shift;

 my $name = ($mode) ? '개발' : '관광';
 my $num = ($mode) ? 2 : 0;

 out(<<END);
<form action="./hako-main.cgi" method="POST">
<input type="hidden" name="ISLANDID" value="$HcurrentID">
<input type="hidden" name="PASSWORD" value="$HinputPassword">
<input type="hidden" name="LBBSNAME" value="$HlbbsName">
<input type="submit" name="Mobile${num}" value="${name} 화면">
</form>
<hr>
END
}

1;

