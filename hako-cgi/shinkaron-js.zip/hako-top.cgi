#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}
#----------------------------------------------------------------------
# 모형정원 제도 ver2.30
# 톱 페이지 모듈(ver1.00)
# 사용 조건과 사용 방법은 hako-readme.txt 파일을 참조해 주세요
#
# 모형정원 제도의 페이지: http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html
#----------------------------------------------------------------------


#----------------------------------------------------------------------
# 톱 페이지 모드
#----------------------------------------------------------------------
# 메인
sub topPageMain {
 # 개방
 unlock();

 # 템플릿출력
 tempTopPage();
}

# 톱 페이지
sub tempTopPage {
 # 제목
 out(<<END);
${HtagTitle_}$Htitle${H_tagTitle}$Hver
END

 # 디버그 모드이면 '턴 진행' 버튼
 if($Hdebug == 1) {
 out(<<END);
<FORM action="$HthisFile" method="POST">
<INPUT TYPE="submit" VALUE="턴을 진행하기" NAME="TurnButton">
</FORM>
END
 }

 my($mStr1) = '';
 if($HhideMoneyMode != 0) {
	$mStr1 = "<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_} 자금${H_tagTH}</NOBR></TH>";
 }

	# 다음 턴까지의 시간 표시
	if ($HmainMode ne 'turn') {
		my($now) = $HislandLastTime + $HunitTime - time;
		$hour2 = int($now/3600);
		$min2 = int(($now-$hour2*3600)/60);
		$sec2 = ($now-$hour2*3600-$min2*60);
		$rtStr = "다음갱신 시간까지<b>남은$hour2 시간$min2분$sec2초</b>";
	} else {
		$rtStr = "턴을 갱신했습니다\n";
	}

	# 다음 갱신 시간 표시
 my($now) = time;
 $aaa = $HislandLastTime + $HunitTime;
 my($sec, $min, $hour, $date, $mon, $year, $day, $yday, $dummy) = localtime(time);
	$mon++;
 my($sss) = "${mon}월 ${date}일 ${hour} 시 ${min}분 ${sec}초";
 my($sec2, $min2, $hour2, $date2, $mon2, $year2, $day2, $yday2, $dummy2) = localtime($aaa);
	$mon2++;
 my($bbb) = "${mon2}월${date2}일${hour2} 시${min2}분";

 if ($HjavaModeSet eq 'java') {
		$radio = ""; $radio2 = "CHECKED";
	}else{
		$radio = "CHECKED";	$radio2 = "";
	}

 # 양식
 out(<<END);
<H1>${HtagHeader_}턴$HislandTurn/300($rtStr)</H1>${H_tagHeader}
<font size=4>현재의 시간:<b>$sss</b>(다음 갱신 시간:$bbb)</FONT><br>
<font size=4 color=red><b>중복 등록금지입니다.1인1섬에서 부탁드립니다.</b></font>
<HR>
<H1>${HtagHeader_}자신의 섬으로${H_tagHeader}</H1>
<SCRIPT language="JavaScript">
<!--
function newdevelope(){
	newWindow = window.open("", "newWindow");
	document.Island.target = "newWindow";
	document.Island.submit();
}
function develope(){
	document.Island.target = "";
}
//-->
</SCRIPT>
<FORM name="Island" action="$HthisFile" method="POST">
당신의 섬 이름은?<BR>
<SELECT NAME="ISLANDID">
$HislandList
</SELECT><BR>
비밀번호 입력!!<BR>
<INPUT TYPE="hidden" NAME="OwnerButton">
<INPUT TYPE="password" NAME="PASSWORD" VALUE="$HdefaultPassword" SIZE=32 MAXLENGTH=32><BR>
<INPUT TYPE="radio" NAME=JAVAMODE VALUE=cgi $radio>일반 모드
<INPUT TYPE="radio" NAME=JAVAMODE VALUE=java $radio2>JavaScript 모드<BR>
<INPUT TYPE="submit" VALUE="개발 화면으로" onClick="develope()">
<INPUT TYPE="button" VALUE="새 화면" onClick="newdevelope()">
</FORM>
<HR>
<A STYlE="text-decoration:none" HREF="${baseDir}/hakolog.html" target="_blank">
<FONT SIZE=6><B>${HtagHeader_}최근 사건${H_tagHeader}</B></FONT>
</A>
<HR>

<H1>${HtagHeader_}섬의 정보${H_tagHeader}</H1>
<P>
섬 이름을 클릭하면,<B>관광</B>할 수 있습니다.
</P>
<TABLE BORDER>
<TR>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}순위${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_} 섬${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_} 섬주의 격${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}진화도${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}입신뢰 턴${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}인구${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}면적${H_tagTH}</NOBR></TH>
$mStr1
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}식량${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}농장규모${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}공장규모${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}채굴장규모${H_tagTH}</NOBR></TH>
</TR>
END

 my($island, $j, $farm, $factory, $mountain, $name, $id, $prize, $ii);
 for($ii = 0; $ii < $HislandNumber; $ii++) {
	$j = $ii + 1;
	$island = $Hislands[$ii];

	$id = $island->{'id'};
	$farm = $island->{'farm'};
	$factory = $island->{'factory'};
	$mountain = $island->{'mountain'};
	$farm = ($farm == 0) ? "보유하지 않음" : "${farm}0$HunitPop";
	$factory = ($factory == 0) ? "보유하지 않음" : "${factory}0$HunitPop";
	$mountain = ($mountain == 0) ? "보유하지 않음" : "${mountain}0$HunitPop";
	if($island->{'absent'} == 0) {
		$name = "${HtagName_}$island->{'name'} 섬${H_tagName}";
	} else {
	 $name = "${HtagName2_}$island->{'name'} 섬($island->{'absent'})${H_tagName2}";
	}

	$prize = $island->{'prize'};
	my($flags, $monsters, $turns);
	$prize =~ /([0-9]*),([0-9]*),(.*)/;
	$flags = $1;
	$monsters= $2;
	$turns = $3;
	$prize = '';

	# 남은 턴 표시
	while($turns =~ s/([0-9]*),//) {
	 $prize.= <<EOP;
<A HREF="JavaScript:void(0);" onMouseOver="status = '$1${Hprize[0]}'; return true;" onMouseOut="status = '';">
<IMG SRC="prize0.gif" ALT="$1${Hprize[0]}" TITLE="$1${Hprize[0]}" WIDTH=16 HEIGHT=16 BORDER=0></A>
EOP
	}

	# 이름에 순위 표시 문자를 추가
	my($f) = 1;
	my($i);
	for($i = 1; $i < 10; $i++) {
	 if($flags & $f) {
		$prize.= <<EOP;
<A HREF="JavaScript:void(0);" onMouseOver="status = '${Hprize[$i]}'; return true;" onMouseOut="status = '';">
<IMG SRC="prize${i}.gif" ALT="${Hprize[$i]}" TITLE="$1${Hprize[$i]}" WIDTH=16 HEIGHT=16 BORDER=0></A>
EOP
	 }
	 $f *= 2;
	}

	# 쓰러뜨린 괴수 목록
	$f = 1;
	my($max) = -1;
	my($mNameList) = '';
	for($i = 0; $i < $HmonsterNumber; $i++) {
	 if($monsters & $f) {
		$mNameList.= "[$HmonsterName[$i]] ";
		$max = $i;
	 }
	 $f *= 2;
	}
	if($max != -1) {
	 $prize.= <<EOP;
<A HREF="JavaScript:void(0);" onMouseOver="status = '$mNameList'; return true;" onMouseOut="status = '';">
<IMG SRC="${HmonsterImage[$max]}" ALT="$mNameList" TITLE="$mNameList" WIDTH=16 HEIGHT=16 BORDER=0></A>
EOP
	}


	my($mStr1) = '';
	if($HhideMoneyMode == 1) {
	 $mStr1 = "<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$island->{'money'}$HunitMoney</NOBR></TD>";
	} elsif($HhideMoneyMode == 2) {
	 my($mTmp) = aboutMoney($island->{'money'});
	 $mStr1 = "<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$mTmp</NOBR></TD>";
	}

 my($comname) ="${HtagTH_}코멘트:${H_tagTH}";
 if(($island->{'ownername'} ne '0') && ($island->{'ownername'} ne "코멘트")){
 $comname = "<FONT COLOR=\"blue\"><B>$island->{'ownername'}:</b></font>";
 }

 my($kaku) = $island->{'kaku'};
 my($kakuname);
 if($kaku == 0) {
 $kakuname = '뉴유형';
 } elsif($kaku == 1) {
 $kakuname = '인종류';
 } elsif($kaku == 2) {
 $kakuname = '먹임젖종류';
 } elsif($kaku == 3) {
 $kakuname = '기어감벌레종류';
 } elsif($kaku == 4) {
 $kakuname = '양쪽생종류';
 } elsif($kaku == 5) {
 $kakuname = '물고기종류';
 } elsif($kaku == 6) {
 $kakuname = '단세부포생물';
 }

	 my($sinkou) = sprintf("%2.1f",$island->{'shinkado'} / 100);

	out(<<END);
<TR>
<TD $HbgNumberCell ROWSPAN=2 align=center nowrap=nowrap><NOBR>${HtagNumber_}$j${H_tagNumber}</NOBR></TD>
<TD $HbgNameCell ROWSPAN=2 align=left nowrap=nowrap>
<NOBR>
<A STYlE=\"text-decoration:none\" HREF="${HthisFile}?Sight=${id}">
$name
</A>
</NOBR><BR>
$prize
</TD>
<TD $HbgInfoCell align=center nowrap=nowrap>
<NOBR>$kakuname</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap>
<NOBR>${sinkou}%</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap>
<NOBR>$island->{jointurn}턴</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap>
<NOBR>$island->{'pop'}$HunitPop</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$island->{'area'}$HunitArea</NOBR></TD>
$mStr1
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$island->{'food'}$HunitFood</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$farm</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$factory</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$mountain</NOBR></TD>
</TR>
<TR>
<TD $HbgCommentCell COLSPAN=10 align=left nowrap=nowrap><NOBR>$comname$island->{'comment'}</NOBR></TD></TR>
END
 }

 out(<<END);
</TABLE>

<HR>
<H1>${HtagHeader_}새 섬을 탐색${H_tagHeader}</H1>
END

 if($HislandNumber < $HmaxIsland) {
	out(<<END);
<FORM action="$HthisFile" method="POST">
섬 이름<BR>
<INPUT TYPE="text" NAME="ISLANDNAME" SIZE=32 MAXLENGTH=32> 섬<BR>
비밀번호<BR>
<INPUT TYPE="password" NAME="PASSWORD" SIZE=32 MAXLENGTH=32><BR>
비밀번호 재확인<BR>
<INPUT TYPE="password" NAME="PASSWORD2" SIZE=32 MAXLENGTH=32><BR>

<INPUT TYPE="submit" VALUE="찾으러 가기" NAME="NewIslandButton">
</FORM>
END
 } else {
	out(<<END);
 섬의 수가 최대 수입니다... 현재 등록할 수 없습니다.
END
 }
my($Himfflag);
$Himfflag = $imageDir;

 out(<<END);
<HR><P>
<TABLE>
<TR><TD WIDTH=420 ROWSPAN=2 VALIGN=TOP>
<H1>${HtagHeader_} 정보 변경${H_tagHeader}</H1>
<P>
(주의) 이름 변경에는 $HcostChangeName${HunitMoney}이 들어갑니다.
</P>
<FORM action="$HthisFile" method="POST">
어느 섬입니까?<BR>
<SELECT NAME="ISLANDID">
$HislandList
</SELECT>
<BR>
새 이름을 입력하세요(변경하는 경우만)<BR>
<INPUT TYPE="text" NAME="ISLANDNAME" SIZE=32 MAXLENGTH=32> 섬<BR>
비밀번호(필수)<BR>
<INPUT TYPE="password" NAME="OLDPASS" SIZE=32 MAXLENGTH=32><BR>
새 비밀번호(변경할 경우만)<BR>
<INPUT TYPE="password" NAME="PASSWORD" SIZE=32 MAXLENGTH=32><BR>
비밀번호 재확인(변경할 경우만)<BR>
<INPUT TYPE="password" NAME="PASSWORD2" SIZE=32 MAXLENGTH=32><BR>

<INPUT TYPE="submit" VALUE="변경" NAME="ChangeInfoButton">
</FORM>

</TD>

<TD VALIGN=TOP WIDTH=350>
<H1>${HtagHeader_}이미지 경로 설정${H_tagHeader}</H1>
<NOBR>현재 설정<B>[</b> ${Himfflag} <B>]</B></NOBR>
<BR><A HREF=${imageExp} target=_blank><FONT SIZE=+1> 설명 </FONT></A>
<form action=$HthisFile method=POST>
<INPUT TYPE=file NAME="IMGLINE">
<INPUT TYPE="submit" VALUE="설정" name=IMGSET>
</form>

<form action=$HthisFile method=POST>
Mac 사용자용<BR>
<INPUT TYPE=text NAME="IMGLINEMAC">
<INPUT TYPE="submit" VALUE="설정" name=IMGSET><BR>
<FONT SIZE=-1>Mac 사용자는, 여기를 사용해 주세요.</FONT>
</form>
</TD></TR>

<TR HEIGHT=100><TD ALIGN=CENTER>
<form action=$HthisFile method=POST>
<INPUT TYPE=hidden NAME="IMGLINE" value="deletemodenow">
<INPUT TYPE="submit" VALUE="설정 해제" name=IMGSET>
</form>
</TD></TR>
</TABLE>
<HR>
<H1>${HtagHeader_}소유자 이름 결정!${H_tagHeader}</H1>
<FORM action="$HthisFile" method="POST">
당신의 섬은?
<SELECT NAME="ISLANDID">
$HislandList
</SELECT> 이름 입력
<INPUT TYPE="text" NAME="OWNERNAME" SIZE=16 MAXLENGTH=32>
 비밀번호
<INPUT TYPE="password" NAME="OLDPASS" SIZE=16 MAXLENGTH=32>
<INPUT TYPE="submit" VALUE="이것로" NAME="ChangeOwnerName">
</form>
<HR>

END
# logPrintTop();
 out(<<END);
<H1>${HtagHeader_}발견 기록${H_tagHeader}</H1>
END
 historyPrint();
}

# 톱 페이지용 로그 표시
sub logPrintTop {
 my($i);
 for($i = 0; $i < $HtopLogTurn; $i++) {
	logFilePrint($i, 0, 0);
 }
}

# 기록 파일 표시
sub historyPrint {
 open(HIN, "${HdirName}/hakojima.his");
 my(@line, $l);
 while($l = <HIN>) {
	chomp($l);
	push(@line, $l);
 }
 @line = reverse(@line);

 foreach $l (@line) {
	$l =~ /^([0-9]*),(.*)$/;
	out("<NOBR>${HtagNumber_}턴${1}${H_tagNumber}:${2}</NOBR><BR>\n");
 }
 close(HIN);
}

1;



