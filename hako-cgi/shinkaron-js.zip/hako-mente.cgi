#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}
# ↑은서버에 맞게 변경해 주세요.

#----------------------------------------------------------------------
# 모형정원 제도 ver2.30
# 관리 도구(ver1.01)
# 사용 조건과 사용 방법은 hako-readme.txt 파일을 참조해 주세요
#
# 모형정원 제도의 페이지: http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html
#----------------------------------------------------------------------


# ――――――――――――――――――――――――――――――
# 각종 설정 값
# ――――――――――――――――――――――――――――――

# 마스터 비밀번호
my($masterpassword) = '1064';

# 1턴이 몇 초인지
my($unitTime) = 3600 * 6; # 6 시간

# 디렉터리 권한
my($dirMode) = 0755;

# 이 파일
my($thisFile) = './hako-mente.cgi';

# 데이터 디렉터리 이름
# hakojima.cgi 안의 것으로 맞춰해 주세요.
my($dirName) = 'data';


# use Time::Local을 사용할 수 없는 환경에서는 'use Time::Local' 줄을 삭제해 주세요.
# 단, 갱신 시간의 변경은 '초 지정에서 변경'만불가능해집니다.
use Time::Local;

# ――――――――――――――――――――――――――――――
# 설정 항목은 여기까지
# ――――――――――――――――――――――――――――――

# 각종변수
my($mainMode);
my($inputPass);
my($deleteID);
my($currentID);
my($ctYear);
my($ctMon);
my($ctDate);
my($ctHour);
my($ctMin);
my($ctSec);

print <<END;
Content-type: text/html; charset=UTF-8

<HTML>
<HEAD><META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
<TITLE>모형정원 제도 2 관리 도구</TITLE>
</HEAD>
<BODY>
END

cgiInput();

if($mainMode eq 'delete') {
 if(passCheck()) {
	deleteMode();
 }
} elsif($mainMode eq 'current') {
 if(passCheck()) {
	currentMode();
 }
} elsif($mainMode eq 'time') {
 if(passCheck()) {
	timeMode();
 }
} elsif($mainMode eq 'stime') {
 if(passCheck()) {
	stimeMode();
 }
} elsif($mainMode eq 'new') {
 if(passCheck()) {
	newMode();
 }
}
mainMode();

print <<END;
</FORM>
</BODY>
</HTML>
END

sub myrmtree {
 my($dn) = @_;
 opendir(DIN, "$dn/");
 my($fileName);
 while($fileName = readdir(DIN)) {
	unlink("$dn/$fileName");
 }
 closedir(DIN);
 rmdir($dn);
}

sub currentMode {
 myrmtree "${dirName}";
 mkdir("${dirName}", $dirMode);
 opendir(DIN, "${dirName}.bak$currentID/");
 my($fileName);
 while($fileName = readdir(DIN)) {
	fileCopy("${dirName}.bak$currentID/$fileName", "${dirName}/$fileName");
 }
 closedir(DIN);
}

sub deleteMode {
 if($deleteID eq '') {
	myrmtree "${dirName}";
 } else {
	myrmtree "${dirName}.bak$deleteID";
 }
 unlink "hakojimalockflock";
}

sub newMode {
 mkdir($dirName, $dirMode);

 # 현재의 시간을 가져옴
 my($now) = time;
 $now = $now - ($now % ($unitTime));

 open(OUT, ">$dirName/hakojima.dat"); # 파일을 열기
 print OUT "1\n"; # 턴 수1
 print OUT "$now\n"; # 시작 시간
 print OUT "0\n"; # 섬의 수
 print OUT "1\n"; # 다음에 할당할 ID

 # 파일을 닫기
 close(OUT);
}

sub timeMode {
 $ctMon--;
 $ctYear -= 1900;
 $ctSec = timelocal($ctSec, $ctMin, $ctHour, $ctDate, $ctMon, $ctYear);
 stimeMode();
}

sub stimeMode {
 my($t) = $ctSec;
 open(IN, "${dirName}/hakojima.dat");
 my(@lines);
 @lines = <IN>;
 close(IN);

 $lines[1] = "$t\n";

 open(OUT, ">${dirName}/hakojima.dat");
 print OUT @lines;
 close(OUT);
}

sub mainMode {
 opendir(DIN, "./");

 print <<END;
<FORM action="$thisFile" method="POST">
<H1>모형정원 제도 2 관리 도구</H1>
<B> 비밀번호:</B><INPUT TYPE=password SIZE=32 MAXLENGTH=32 NAME=PASSWORD></TD>
END

 # 현재 데이터
 if(-d "${dirName}") {
	dataPrint("");
 } else {
	print <<END;
 <HR>
 <INPUT TYPE="submit" VALUE="새 데이터 만들기" NAME="NEW">
END
 }

 # 백업 데이터
 my($dn);
 while($dn = readdir(DIN)) {
	if($dn =~ /^${dirName}.bak(.*)/) {
	 dataPrint($1);
	}
 }
 closedir(DIN);
}

# 표시 모드
sub dataPrint {
 my($suf) = @_;

 print "<HR>";
 if($suf eq "") {
	open(IN, "${dirName}/hakojima.dat");
	print "<H1>현재 데이터</H1>";
 } else {
	open(IN, "${dirName}.bak$suf/hakojima.dat");
	print "<H1>백업$suf</H1>";
 }

 my($lastTurn);
 $lastTurn = <IN>;
 my($lastTime);
 $lastTime = <IN>;

 my($timeString) = timeToString($lastTime);

 print <<END;
 <B>턴$lastTurn</B><BR>
 <B>최종 갱신 시간</B>:$timeString<BR>
 <B>최종 갱신 시간(초 단위 표시)</B>:1970년1월1일에서$lastTime 초<BR>
 <INPUT TYPE="submit" VALUE="이 데이터 삭제" NAME="DELETE$suf">
END

 if($suf eq "") {
	my($sec, $min, $hour, $date, $mon, $year, $day, $yday, $dummy) =
	 localtime($lastTime);
	$mon++;
	$year += 1900;

	print <<END;
 <H2>최종 갱신 시간의 변경</H2>
 <INPUT TYPE="text" SIZE=4 NAME="YEAR" VALUE="$year">년
 <INPUT TYPE="text" SIZE=2 NAME="MON" VALUE="$mon">월
 <INPUT TYPE="text" SIZE=2 NAME="DATE" VALUE="$date">일
 <INPUT TYPE="text" SIZE=2 NAME="HOUR" VALUE="$hour"> 시
 <INPUT TYPE="text" SIZE=2 NAME="MIN" VALUE="$min">분
 <INPUT TYPE="text" SIZE=2 NAME="NSEC" VALUE="$sec">초
 <INPUT TYPE="submit" VALUE="변경" NAME="NTIME"><BR>
 1970년1월1일에서<INPUT TYPE="text" SIZE=32 NAME="SSEC" VALUE="$lastTime">초
 <INPUT TYPE="submit" VALUE="초지정에서 변경" NAME="STIME">

END
 } else {
	print <<END;
	<INPUT TYPE="submit" VALUE="이 데이터를 현재 데이터로 사용" NAME="CURRENT$suf">
END
 }
}

sub timeToString {
 my($sec, $min, $hour, $date, $mon, $year, $day, $yday, $dummy) =
	localtime($_[0]);
 $mon++;
 $year += 1900;

 return "${year}년 ${mon}월 ${date}일 ${hour} 시 ${min}분 ${sec}초";
}

# CGI 읽기
sub cgiInput {
 my($line);

 # 입력을 받음
 $line = <>;
 $line =~ tr/+/ /;
 $line =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;

 if($line =~ /DELETE([0-9]*)/) {
	$mainMode = 'delete';
	$deleteID = $1;
 } elsif($line =~ /CURRENT([0-9]*)/) {
	$mainMode = 'current';
	$currentID = $1;
 } elsif($line =~ /NEW/) {
	$mainMode = 'new';
 } elsif($line =~ /NTIME/) {
	$mainMode = 'time';
	if($line =~ /YEAR=([0-9]*)/) {
	 $ctYear = $1;
	}
	if($line =~ /MON=([0-9]*)/) {
	 $ctMon = $1;
	}
	if($line =~ /DATE=([0-9]*)/) {
	 $ctDate = $1;
	}
	if($line =~ /HOUR=([0-9]*)/) {
	 $ctHour = $1;
	}
	if($line =~ /MIN=([0-9]*)/) {
	 $ctMin = $1;
	}
	if($line =~ /NSEC=([0-9]*)/) {
	 $ctSec = $1;
	}
 } elsif($line =~ /STIME/) {
	$mainMode = 'stime';
	if($line =~ /SSEC=([0-9]*)/) {
	 $ctSec = $1;
	}
 }

 if($line =~ /PASSWORD=([^\&]*)\&/) {
	$inputPass = $1;
 }
}

# 파일의 복사
sub fileCopy {
 my($src, $dist) = @_;
 open(IN, $src);
 open(OUT, ">$dist");
 while(<IN>) {
	print OUT;
 }
 close(IN);
 close(OUT);
}

# 경로 확인
sub passCheck {
 if($inputPass eq $masterpassword) {
	return 1;
 } else {
	print <<END;
 <FONT SIZE=7> 비밀번호가 다릅니다.</FONT>
END
 return 0;
 }
}

1;



