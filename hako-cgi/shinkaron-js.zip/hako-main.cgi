#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}
# ↑은서버에 맞게 변경해 주세요.
# perl5용입니다.

#----------------------------------------------------------------------
# 모형정원 제도 ver2.30
# 메인 스크립트(ver1.02)
# 사용 조건과 사용 방법은 hako-readme.txt 파일을 참조해 주세요
#
# 모형정원 제도의 페이지: http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html
#----------------------------------------------------------------------
# JavaScript판'모형정원 제도'-ver1.1-
# 사용 조건, 사용 방법은  배포처를 확인하세요.
# 부속의 js-readme.txt 모오읽기하세요.
# 앗포:http://appoh.execweb.cx/hakoniwa/
#----------------------------------------------------------------------
# JavaScript판 미사일진행화논의 ver1.00
# 사용 조건및사용 방법은 hako-readme.txt,js-readme.txt 에준합니다.
#
# 아호아호오차의 회:http://www.ahooo.net/
#----------------------------------------------------------------------

#----------------------------------------------------------------------
# 각종 설정 값
# 아래 설정 값을 서버 환경에 맞게 변경해 주세요.
#----------------------------------------------------------------------

#----------------------------------------------------------------------
# 아래는 반드시 설정해야 하는 항목입니다
#----------------------------------------------------------------------

# 이 파일을 설치할 디렉터리
# my($baseDir) = 'http://서버/디렉터리';
#
# 예)
# http://cgi2.bekkoame.ne.jp/cgi-bin/user/u5534/hakoniwa/hako-main.cgi
# 처럼 배치한 경우,
# my($baseDir) = 'http://cgi2.bekkoame.ne.jp/cgi-bin/user/u5534/hakoniwa';
# 지합니다. 끝에 슬래시(/)는 붙이지 않습니다.

#my($baseDir) = 'http://서버/디렉터리';

#my($baseDir) = 'http://127.0.0.1/shinkaron';
my($scriptBaseScheme) = (($ENV{'HTTPS'} || '') =~ /^(on|1)$/i) ? 'https' : 'http';
my($scriptBaseHost) = $ENV{'HTTP_HOST'} || $ENV{'SERVER_NAME'} || 'localhost';
if (!$ENV{'HTTP_HOST'} && $ENV{'SERVER_PORT'} && !(($scriptBaseScheme eq 'http' && $ENV{'SERVER_PORT'} == 80) || ($scriptBaseScheme eq 'https' && $ENV{'SERVER_PORT'} == 443))) {
 $scriptBaseHost.= ":$ENV{'SERVER_PORT'}";
}
my($scriptBasePath) = $ENV{'SCRIPT_NAME'} || '';
$scriptBasePath =~ s{/[^/]*$}{};
my($baseDir) = "$scriptBaseScheme://$scriptBaseHost$scriptBasePath";


# 이미지 파일을 둘 디렉터리
# my($imageDir) = 'http://서버/디렉터리';
#my($imageDir) = $baseDir;
my($imageDir) = 'https://esils.com/BBdata/hakoimg';
# 문자 변환 라이브러리 위치

# UTF-8 환경에서는 외부 문자 변환 라이브러리를 사용하지 않습니다.
# UTF-8 환경에서는 외부 문자 변환 라이브러리를 사용하지 않습니다.
# 이 비밀번호는, 모든 섬의 비밀번호를 대신 사용할 수 있습니다.
# 예를 들어,'다른 섬의 비밀번호 변경'등도 할 수 있습니다.
my($masterPassword) = '1064';

# 특수 비밀번호
# 이 비밀번호로 '이름 변경'을 실행하면, 그 섬의 자금, 식량이 최댓값이 됩니다.
# (실제로 이름이 변경될 필요는 없습니다.)
$HspecialPassword = 'specialpass';

# 관리자 이름
my($adminName) = '아호아호오차의 회';

# 관리자의 메일 주소
my($email) = '당신의@메일 주소';

# 게시판 주소
my($bbs) = $baseDir;

# 홈페이지 주소
my($toppage) = "$baseDir/";

# 디렉터리 권한
# 일반적으로 0755이면 좋지만,0777,0705,0704등에서 없으면 사용 불가는 서버도 있습니다
$HdirMode = 0755;

# 데이터 디렉터리 이름
# 여기에서 설정한 이름의 디렉터리 아래에 데이터가 저장됩니다.
# 기본값에서는'data'로 되어 있지만, 보안상
# 보안을 위해 다른 이름으로 변경해 주세요.
$HdirName = 'data';

# 데이터 쓰기 권한

# 잠금 방식
# 1 디렉터리
# 2 시스템 콜(가능하면 이 방식을 권장합니다)
# 3 심볼릭 링크
# 4 일반 파일(권장하지 않음)
my($lockMode) = 2;

# (주)
# 4을 선택하는 경우에는,'key-free'라는, 권한 666의 빈 파일을,
# 이 파일과 같은 위치에 배치해 주세요.

#----------------------------------------------------------------------
# 반드시 설정하는 부분은 이상
#----------------------------------------------------------------------

#----------------------------------------------------------------------
# 아래는 필요에 따라 설정하는 항목입니다
#----------------------------------------------------------------------
#----------------------------------------
# 게임의 진행야 파일등
#----------------------------------------
# 1턴이 몇 초인지
$HunitTime = 3600 *3; # 6 시간

# 이상종료 기준 시간
# (잠금 후 몇 초 뒤 강제 해제할지)
my($unlockTime) = 120;

# 섬의 최대 수
$HmaxIsland = 40;

# 톱 페이지에 표시할 로그 턴 수
$HtopLogTurn = 4;

# 로그 파일 유지 턴 수
$HlogMax = 8;

# 백업을 몇 턴오키에취는 가
$HbackupTurn = 2;

# 백업을 몇 회분 남음습니까
$HbackupTimes = 4;

# 발견 로그유지 줄 수
$HhistoryMax = 10;

# 포기 명령 자동 입력 턴 수
$HgiveupTurn = 28;

# 명령 입력 한계 수
# (게임이 시작된 뒤 변경하면 데이터 파일 호환성이 없어집니다.)
$HcommandMax = 20;

# 로컬 게시판 행 수 사용 여부(0:사용하지 않음,1:사용함)
$HuseLbbs = 1;

# 로컬 게시판 줄 수
$HlbbsMax = 10;

# 섬 크기
# (변경할 수 없일 수도)
$HislandSize = 12;

# 다른 사람이 자금을 볼 수 없게 할지
# 0 보이지 않음
# 1 표시 가능
# 2 100의 위에서 반올림
$HhideMoneyMode = 2;

# 비밀번호 암호화(0: 암호화하지 않음, 1: 암호화함)
my($cryptOn) = 1;

# 디버그 모드(1이면 '턴 진행' 버튼을 사용할 수 있음)
$Hdebug = 0;

#----------------------------------------
# 자금, 식량등의 설정 값와 단위
#----------------------------------------
# 초기 자금
$HinitialMoney = 100;

# 초기 식량
$HinitialFood = 100;

# 자금의 단위
$HunitMoney = '억 엔';

# 식량의 단위
$HunitFood = '00톤';

# 인구의 단위
$HunitPop = '00인';

# 면적의 단위
$HunitArea = '00만 평';

# 나무 수의 단위
$HunitTree = '00본';

# 목재 단위당 판매 수입
$HtreeValue = 5;

# 1턴에서 목의 늘어나면개 수
$HtreeUp = 1;

# 이름 변경의 비용
$HcostChangeName = 500;

# 인구 1단위당 식량 소비량
$HeatenFood = 0.2;

#----------------------------------------
# 기지의 경험치
#----------------------------------------
# 경험치의 최댓값
$HmaxExpPoint = 200; # 단, 최대라도255까지

# 레벨의 최댓값
my($maxBaseLevel) = 5; # 미사일 기지
my($maxSBaseLevel) = 3; # 해저 기지

# 경험치가 몇 점이면 레벨업할지
my(@baseLevelUp, @sBaseLevelUp);
@baseLevelUp = (20, 60, 120, 200); # 미사일 기지
@sBaseLevelUp = (50, 200); # 해저 기지

#----------------------------------------
# 방위 시설의 자폭
#----------------------------------------
# 괴수에게 밟혔을 시 자폭하면 1, 아니면 0
$HdBaseAuto = 1;

#----------------------------------------
# 재해
#----------------------------------------
# 일반 재해 발생률(확률은0.1%단위)
$HdisEarthquake = 5; # 지진
$HdisTsunami = 15; # 쓰나미
$HdisTyphoon = 20; # 태풍
$HdisMeteo = 15; # 운석
$HdisHugeMeteo = 5; # 거대운석
$HdisEruption = 10; # 분화
$HdisFire = 10; # 화재
$HdisMaizo = 10; # 매장금

# 지반 침하
$HdisFallBorder = 90; # 안정 전체한계의 면적(Hex 수)
$HdisFalldown = 30; # 그 면적를 초과한 경우 확률

# 괴수
$HdisMonsBorder1 = 1000; # 인구 기준1(괴수레벨1)
$HdisMonsBorder2 = 2500; # 인구 기준2(괴수레벨2)
$HdisMonsBorder3 = 4000; # 인구 기준3(괴수레벨3)
$HdisMonster = 3; # 단위 면적 주변의 출현율(0.01%단위)

# 종류
$HmonsterNumber = 8;

# 각 기준에서 출현하는 괴수 번호의 최대값
$HmonsterLevel1 = 2; # 산지라까지
$HmonsterLevel2 = 5; # 이노라 고스트까지
$HmonsterLevel3 = 7; # 킹 이노라까지(전체)

# 이름
@HmonsterName =
 (
 '메카이노라', # 0(인공)
 '이노라', # 1
 '산지라', # 2
 '레드이노라', # 3
 '다크이노라', # 4
 '이노라 고스트', # 5
 '고래', # 6
 '킹 이노라' # 7
);

# 최소체력, 체력의 폭, 특수 능력, 경험치, 시체의 가격
@HmonsterBHP = ( 2, 1, 1, 3, 2, 1, 4, 5);
@HmonsterDHP = ( 0, 2, 2, 2, 2, 0, 2, 2);
@HmonsterSpecial = ( 0, 0, 3, 0, 1, 2, 4, 0);
@HmonsterExp = ( 5, 5, 7,12,15,10,20,30);
@HmonsterValue = ( 0, 400, 500, 1000, 800, 300, 1500, 2000);

# 특수 능력의 내용은,
# 0 특별히 없음
# 1 빠른 이동(최대 2걸음)
# 2족 보행이지만 속도는 알 수 없음(최대 몇 칸 이동하는지 불명)
# 3 홀 수 턴은 경화
# 4 짝 수 턴은 경화

# 이미지 파일
@HmonsterImage =
 (
 'monster7.gif',
 'monster0.gif',
 'monster5.gif',
 'monster1.gif',
 'monster2.gif',
 'monster8.gif',
 'monster6.gif',
 'monster3.gif'
 );

# 이미지 파일그2(경화 중)
@HmonsterImage2 =
 ('', '', 'monster4.gif', '', '', '', 'monster4.gif', '');


#----------------------------------------
# 유전
#----------------------------------------
# 유전 수입
$HoilMoney = 1000;

# 유전의 고갈확률
$HoilRatio = 40;

#----------------------------------------
# 기념비
#----------------------------------------
# 몇종류있는 지
$HmonumentNumber = 3;

# 이름
@HmonumentName =
 (
 '모노리스',
 '평화기념비',
 '전쟁이의 비석'
 );

# 이미지 파일
@HmonumentImage =
 (
 'monument0.gif',
 'monument0.gif',
 'monument0.gif'
 );

#----------------------------------------
# 수상 관계
#----------------------------------------
# 턴잔을 몇 매 턴출습니까
$HturnPrizeUnit = 100;

# 상의 이름
$Hprize[0] = '턴잔';
$Hprize[1] = '번영상';
$Hprize[2] = '초과 번영상';
$Hprize[3] = '궁극번영상';
$Hprize[4] = '평화상';
$Hprize[5] = '초과 평화상';
$Hprize[6] = '궁극평화상';
$Hprize[7] = '재난상';
$Hprize[8] = '초과 재난상';
$Hprize[9] = '궁극재난상';

#----------------------------------------
# 화면 표시 관련
#----------------------------------------
# <BODY>태그의 옵션
my($htmlBody) = 'BGCOLOR="#EEFFFF"';

# 게임 제목 문자열
$Htitle = '미사일 진화론 for Js';
$Hver ='1.00';

# 태그
# 제목문자
$HtagTitle_ = '<FONT SIZE=7 COLOR="#8888ff">';
$H_tagTitle = '</FONT>';

# H1태그용
$HtagHeader_ = '<FONT COLOR="#4444ff">';
$H_tagHeader = '</FONT>';

# 큰 글자
$HtagBig_ = '<FONT SIZE=6>';
$H_tagBig = '</FONT>';

# 섬 이름 등
$HtagName_ = '<FONT COLOR="#a06040"><B>';
$H_tagName = '</B></FONT>';

# 숨김 처리하지 않은 섬 이름
$HtagName2_ = '<FONT COLOR="#808080"><B>';
$H_tagName2 = '</B></FONT>';

# 순위 번호 등
$HtagNumber_ = '<FONT COLOR="#800000"><B>';
$H_tagNumber = '</B></FONT>';

# 순위표 머리글
$HtagTH_ = '<FONT COLOR="#C00000"><B>';
$H_tagTH = '</B></FONT>';

# 개발계획의 이름
$HtagComName_ = '<FONT COLOR="#d08000"><B>';
$H_tagComName = '</B></FONT>';

# 재해
$HtagDisaster_ = '<FONT COLOR="#ff0000"><B>';
$H_tagDisaster = '</B></FONT>';

# 로컬 게시판, 관광객의 표시 문자
$HtagLbbsSS_ = '<FONT COLOR="#0000ff"><B>';
$H_tagLbbsSS = '</B></FONT>';

# 로컬 게시판, 섬주의 표시 문자
$HtagLbbsOW_ = '<FONT COLOR="#ff0000"><B>';
$H_tagLbbsOW = '</B></FONT>';

# 로컬 게시판, 섬무시 관광객의 표시 문자
$HtagLbbsSK_ = '<FONT COLOR="#003333"><B>';
$H_tagLbbsSK = '</B></FONT>';

# 일반 문자색(BODY 태그의 옵션도 함께 변해야 합니다
$HnormalColor = '#000000';

# 순위표, 세루의 속성
$HbgTitleCell = 'BGCOLOR="#ccffcc"'; # 순위표 머리글시
$HbgNumberCell = 'BGCOLOR="#ccffcc"'; # 순위표순위
$HbgNameCell = 'BGCOLOR="#ccffff"'; # 순위표 섬 이름
$HbgInfoCell = 'BGCOLOR="#ccffff"'; # 순위표 섬의 정보
$HbgCommentCell = 'BGCOLOR="#ccffcc"'; # 순위표코멘트란
$HbgInputCell = 'BGCOLOR="#ccffcc"'; # 개발계획양식
$HbgMapCell = 'BGCOLOR="#ccffcc"'; # 개발계획지도
$HbgCommandCell = 'BGCOLOR="#ccffcc"'; # 개발계획입력완료미계획

#----------------------------------------------------------------------
# 필요에 따라 설정하는 항목은 여기까지입니다
#----------------------------------------------------------------------

#----------------------------------------------------------------------
# 아래쪽 스크립트는 변경을 전제로 하지 않습니다.
# 그래도 문제는 없습니다.
# 명령 이름과 가격 등은 알아보기 쉽게 두는 편이 좋습니다.
#----------------------------------------------------------------------

#----------------------------------------------------------------------
# 각종 상수
#----------------------------------------------------------------------
# 이 파일
$HthisFile = "$baseDir/hako-main.cgi";

# 지형 번호
$HlandSea = 0; # 바다
$HlandWaste = 1; # 황무지
$HlandPlains = 2; # 평지
$HlandTown = 3; # 마을 계열
$HlandForest = 4; # 숲
$HlandFarm = 5; # 농장
$HlandFactory = 6; # 공장
$HlandBase = 7; # 미사일 기지
$HlandDefence = 8; # 방위 시설
$HlandMountain = 9; # 산
$HlandMonster = 10; # 괴수
$HlandSbase = 11; # 해저 기지
$HlandOil = 12; # 해저 유전
$HlandMonument = 13; # 기념비
$HlandHaribote = 14; # 가짜 시설

# 명령
$HcommandTotal = 33; # 명령 종류

# 명령 분할
# 이 명령 분할만은, 자동 입력 명령은 설정하지 마세요.
@HcommandDivido =
	(
	'개발,0,10', # 계획번호00~10
	'건설,11,30', # 계획번호11~30
	'공격,31,40', # 계획번호31~40
	'운영,41,60' # 계획번호41~60
	);
# 주의:공백은 넣지 않도록
# ○→	'개발,0,10', # 계획번호00~10
# ×→	'개발, 0,10 ', # 계획번호00~10

# 계획 번호 설정
# 개간 계열
$HcomPrepare = 01; # 개간
$HcomPrepare2 = 02; # 땅고르기
$HcomReclaim = 03; # 매립
$HcomDestroy = 04; # 굴착
$HcomSellTree = 05; # 벌채

# 작루계
$HcomPlant = 11; # 나무심기
$HcomFarm = 12; # 농장 건설
$HcomFactory = 13; # 공장 건설
$HcomMountain = 14; # 채굴장 건설
$HcomBase = 15; # 미사일 기지건설
$HcomDbase = 16; # 방위 시설 건설
$HcomSbase = 17; # 해저 기지건설
$HcomMonument = 18; # 기념비 건조
$HcomHaribote = 19; # 가짜 기지건설

# 발사계
$HcomMissileNM = 31; # 미사일 발사
$HcomMissilePP = 32; # PP 미사일 발사
$HcomMissileST = 33; # ST 미사일 발사
$HcomMissileLD = 34; # 육지 파괴탄환 발사
$HcomSendMonster = 35; # 괴수 파견

# 운영계
$HcomDoNothing = 41; # 자금 조달
$HcomSell = 42; # 식량 수출
$HcomMoney = 43; # 자금지원
$HcomFood = 44; # 식량지원
$HcomPropaganda = 45; # 유치 활동
$HcomGiveup = 46; # 섬 포기

# 자동 입력
$HcomAutoPrepare = 61; # 전체 개간
$HcomAutoPrepare2 = 62; # 전체땅고르기
$HcomAutoReclaim = 63; # 전체매립
$HcomAutoReclaim2 = 64; # 매립 + 개간
$HcomAutoReclaim3 = 65; # 매립 + 땅고르기
$HcomAutoComPlant = 66; # 개간 + 나무심기
$HcomAutoComPlant2 = 67; # 땅고르기 + 나무심기
$HcomAutoDelete = 68; # 전체 명령 삭제

# 순서
@HcomList =
 ($HcomPrepare, $HcomSell, $HcomPrepare2, $HcomReclaim, $HcomDestroy,
 $HcomSellTree, $HcomPlant, $HcomFarm, $HcomFactory, $HcomMountain,
 $HcomBase, $HcomDbase, $HcomSbase, $HcomMonument, $HcomHaribote,
 $HcomMissileNM, $HcomMissilePP,
 $HcomMissileST, $HcomMissileLD, $HcomSendMonster, $HcomDoNothing,
 $HcomMoney, $HcomFood, $HcomPropaganda, $HcomGiveup,
 $HcomAutoPrepare, $HcomAutoPrepare2, $HcomAutoReclaim,$HcomAutoReclaim2,
	 $HcomAutoReclaim3,$HcomAutoComPlant,$HcomAutoComPlant2,$HcomAutoDelete);

# 계획 이름과 비용
$HcomName[$HcomPrepare] = '개간';
$HcomCost[$HcomPrepare] = 5;
$HcomName[$HcomPrepare2] = '땅고르기';
$HcomCost[$HcomPrepare2] = 100;
$HcomName[$HcomReclaim] = '매립';
$HcomCost[$HcomReclaim] = 150;
$HcomName[$HcomDestroy] = '굴착';
$HcomCost[$HcomDestroy] = 200;
$HcomName[$HcomSellTree] = '벌채';
$HcomCost[$HcomSellTree] = 0;
$HcomName[$HcomPlant] = '나무심기';
$HcomCost[$HcomPlant] = 50;
$HcomName[$HcomFarm] = '농장 건설';
$HcomCost[$HcomFarm] = 20;
$HcomName[$HcomFactory] = '공장 건설';
$HcomCost[$HcomFactory] = 100;
$HcomName[$HcomMountain] = '채굴장 건설';
$HcomCost[$HcomMountain] = 300;
$HcomName[$HcomBase] = '미사일 기지건설';
$HcomCost[$HcomBase] = 300;
$HcomName[$HcomDbase] = '방위 시설 건설';
$HcomCost[$HcomDbase] = 800;
$HcomName[$HcomSbase] = '해저 기지건설';
$HcomCost[$HcomSbase] = 8000;
$HcomName[$HcomMonument] = '기념비 건조';
$HcomCost[$HcomMonument] = 9999;
$HcomName[$HcomHaribote] = '가짜 기지건설';
$HcomCost[$HcomHaribote] = 1;
$HcomName[$HcomMissileNM] = '미사일 발사';
$HcomCost[$HcomMissileNM] = 20;
$HcomName[$HcomMissilePP] = 'PP 미사일 발사';
$HcomCost[$HcomMissilePP] = 50;
$HcomName[$HcomMissileST] = 'ST 미사일 발사';
$HcomCost[$HcomMissileST] = 50;
$HcomName[$HcomMissileLD] = '육지 파괴탄환 발사';
$HcomCost[$HcomMissileLD] = 100;
$HcomName[$HcomSendMonster] = '괴수 파견';
$HcomCost[$HcomSendMonster] = 3000;
$HcomName[$HcomDoNothing] = '자금 조달';
$HcomCost[$HcomDoNothing] = 0;
$HcomName[$HcomSell] = '식량 수출';
$HcomCost[$HcomSell] = -100;
$HcomName[$HcomMoney] = '자금지원';
$HcomCost[$HcomMoney] = 100;
$HcomName[$HcomFood] = '식량지원';
$HcomCost[$HcomFood] = -100;
$HcomName[$HcomPropaganda] = '유치 활동';
$HcomCost[$HcomPropaganda] = 1000;
$HcomName[$HcomGiveup] = '섬 포기';
$HcomCost[$HcomGiveup] = 0;
$HcomName[$HcomAutoPrepare] = '개간 자동 입력';
$HcomCost[$HcomAutoPrepare] = 0;
$HcomName[$HcomAutoPrepare2] = '땅고르기 자동 입력';
$HcomCost[$HcomAutoPrepare2] = 0;
$HcomName[$HcomAutoReclaim] = '매립 자동 입력';
$HcomCost[$HcomAutoReclaim] = 0;
$HcomName[$HcomAutoReclaim2] = '매립 + 개간 입력';
$HcomCost[$HcomAutoReclaim2] = 0;
$HcomName[$HcomAutoReclaim3] = '매립 + 땅고르기입력';
$HcomCost[$HcomAutoReclaim3] = 0;
$HcomName[$HcomAutoComPlant] = '개간 + 나무심기 입력';
$HcomCost[$HcomAutoComPlant] = 0;
$HcomName[$HcomAutoComPlant2] = '땅고르기 + 나무심기입력';
$HcomCost[$HcomAutoComPlant2] = 0;
$HcomName[$HcomAutoDelete] = '전체계획을 백지 철회';
$HcomCost[$HcomAutoDelete] = 0;

#----------------------------------------------------------------------
# 변수
#----------------------------------------------------------------------

# COOKIE
my($defaultID); # 섬 이름
my($defaultTarget); # 대상의 이름


# 섬의 좌표 수
$HpointNumber = $HislandSize * $HislandSize;

#----------------------------------------------------------------------
# 메인
#----------------------------------------------------------------------

# 문자 변환 라이브러리 로드

# '돌아가기'링크
$HtempBack = "<A HREF=\"$HthisFile\">${HtagBig_}맨 위로 돌아가기${H_tagBig}</A>";
$Body = "<BODY $htmlBody>";

# 잠금을 끼치기
if(!hakolock()) {
 # 잠금실패
 # 헤더출력
 tempHeader();

 # 잠금실패 메시지
 tempLockFail();

 # 푸터출력
 tempFooter();

 # 종료
 exit(0);
}

# 난수의 초기화
srand(time^$$);

# COOKIE 읽기
cookieInput();

# CGI 읽기
cgiInput();

# 섬 데이터 읽기
if(readIslandsFile($HcurrentID) == 0) {
 unlock();
 tempHeader();
 tempNoDataFile();
 tempFooter();
 exit(0);
}

# 템플릿을 초기화
tempInitialize();

# COOKIE 출력
cookieOutput();

if($HmainMode eq 'owner' && $HjavaMode eq 'java' ||
 $HmainMode eq 'commandJava' || # 명령 입력 모드
 $HmainMode eq 'command2' || # 명령 입력 모드(ver1.1부터 추가·자동 입력용)
 $HmainMode eq 'comment' && $HjavaMode eq 'java' || #코멘트입력 모드
 $HmainMode eq 'lbbs' && $HjavaMode eq 'java') { #코멘트입력 모드
	$Body = "<BODY onload=\"SelectList('');init()\" $htmlBody>";
 	require('hako-js.cgi');
 require('hako-map.cgi');
	# 헤더출력
	tempHeaderJava($bbs, $toppage,$imageDir);
	if($HmainMode eq 'commandJava') {
 	# 개발 모드
 	commandJavaMain();
	} elsif($HmainMode eq 'command2') {
 	# 개발 모드2(ver1.1부터 추가·자동 입력 명령용)
	 commandMain();
	} elsif($HmainMode eq 'comment') {
 	# 코멘트입력 모드
 	commentMain();
	} elsif($HmainMode eq 'lbbs') {
	 # 로컬 게시판 모드
 	localBbsMain();
	}else{
	 ownerMain();
	}
	# 푸터출력
	tempFooter();
	# 종료
	exit(0);
}elsif($HmainMode eq 'landmap'){
 	require('hako-js.cgi');
 require('hako-map.cgi');
	$Body = "<BODY $htmlBody>";
	# 헤더출력
	tempHeaderJava($bbs, $toppage,$imageDir);
 # 관광 모드
 printIslandJava();
	# 종료
	exit(0);
}else{
	# 헤더출력
	tempHeader();
}

if($HmainMode eq 'turn') {
 # 턴진행
 require('hako-turn.cgi');
 require('hako-top.cgi');
 turnMain();

} elsif($HmainMode eq 'new') {
 # 섬 신규 생성
 require('hako-turn.cgi');
 require('hako-map.cgi');
 newIslandMain();

} elsif($HmainMode eq 'print') {
 # 관광 모드
 require('hako-map.cgi');
 printIslandMain();

} elsif($HmainMode eq 'owner') {

 # 개발 모드
 require('hako-map.cgi');
 ownerMain();

} elsif($HmainMode eq 'command') {
 # 명령 입력 모드
 require('hako-map.cgi');
 commandMain();

} elsif($HmainMode eq 'comment') {
 # 코멘트입력 모드
 require('hako-map.cgi');
 commentMain();

} elsif($HmainMode eq 'lbbs') {

 # 로컬 게시판 모드
 require('hako-map.cgi');
 localBbsMain();

} elsif($HmainMode eq 'change') {
 # 정보 변경 모드
 require('hako-turn.cgi');
 require('hako-top.cgi');
 changeMain();

} else {
 # 그 외에는 톱 페이지 모드
 require('hako-top.cgi');
 topPageMain();
}

# 푸터출력
tempFooter();

# 종료
exit(0);

# 명령을 앞으로 당기기
sub slideFront {
 my($command, $number) = @_;
 my($i);

 # 각각밀기
 splice(@$command, $number, 1);

 # 마지막에 자금 조달
 $command->[$HcommandMax - 1] = {
	'kind' => $HcomDoNothing,
	'target' => 0,
	'x' => 0,
	'y' => 0,
	'arg' => 0
	};
}

# 명령을 뒤로 밀기
sub slideBack {
 my($command, $number) = @_;
 my($i);

 # 각각밀기
 return if $number == $#$command;
 pop(@$command);
 splice(@$command, $number, 0, $command->[$number]);
}

#----------------------------------------------------------------------
# 섬 데이터 입출력
#----------------------------------------------------------------------

# 전체 섬 데이터 읽기
sub readIslandsFile {
 my($num) = @_; # 0이면 지형읽기 전
 # -1이면 전체 지형을 읽어들임
 # 번호가 지정되면 해당 섬의 지형만 읽어들임

 # 데이터 파일 열기
 if(!open(IN, "${HdirName}/hakojima.dat")) {
	rename("${HdirName}/hakojima.tmp", "${HdirName}/hakojima.dat");
	if(!open(IN, "${HdirName}/hakojima.dat")) {
	 return 0;
	}
 }

 # 각매개변수읽기
 $HislandTurn = int(<IN>); # 턴 수
 if($HislandTurn == 0) {
	return 0;
 }
 $HislandLastTime = int(<IN>); # 최종 갱신 시간
 if($HislandLastTime == 0) {
	return 0;
 }
 $HislandNumber = int(<IN>); # 섬의 총 수
 $HislandNextID = int(<IN>); # 다음에 할당할 ID

 # 턴 처리판정
 my($now) = time;
 if((($Hdebug == 1) &&
	($HmainMode eq 'Hdebugturn')) ||
 (($now - $HislandLastTime)>= $HunitTime)) {
	$HmainMode = 'turn';
	$num = -1; # 전체 섬읽어들임
 }

 # 섬읽기
 my($i);
 for($i = 0; $i < $HislandNumber; $i++) {
	 $Hislands[$i] = readIsland($num);
	 $HidToNumber{$Hislands[$i]->{'id'}} = $i;

	# score 에서격붙이기
	if(($HislandTurn - 50) < ($Hislands[$i]->{'jointurn'})) {
		$Hislands[$i]->{'kaku'} = 6; # 보기학습이
	} elsif($i == 0) {
		$Hislands[$i]->{'kaku'} = 0;
	} elsif($i < 4) {
		$Hislands[$i]->{'kaku'} = 1;
	} elsif($i < 9) {
		$Hislands[$i]->{'kaku'} = 2;
	} elsif($i < 16) {
		$Hislands[$i]->{'kaku'} = 3;
	} elsif($i < 25) {
		$Hislands[$i]->{'kaku'} = 4;
	} else {
		$Hislands[$i]->{'kaku'} = 5;
	}
 }

 # 파일을 닫기
 close(IN);

 return 1;
}

# 섬 하나 읽기
sub readIsland {
 my($num) = @_;
 my($name, $id, $prize, $absent, $comment, $password, $money, $food,
 $pop, $area, $farm, $factory, $mountain, $jointurn, $shinkado, $score, $score2, $fire, $ownername);
 $name = <IN>; # 섬 이름
 chomp($name);
 if($name =~ s/,(.*)$//g) {
	$score = int($1);
	$score2 = int($2);
 } else {
	$score = 0;
 $score2 = 0;
 }
 $id = int(<IN>); # ID 번호
 $prize = <IN>; # 수상
 chomp($prize);
 $absent = int(<IN>); # 연속 자금 조달 수
 $comment = <IN>; # 코멘트
 chomp($comment);
 $password = <IN>; # 암호화 비밀번호
 chomp($password);
 $money = int(<IN>); # 자금
 $food = int(<IN>); # 식량
 $pop = int(<IN>); # 인구
 $area = int(<IN>); # 면적
 $farm = int(<IN>); # 농장
 $factory = int(<IN>); # 공장
 $mountain = int(<IN>); # 채굴장
 $jointurn = int(<IN>); # 시작 턴
 $shinkado = int(<IN>); # 진화도
 $fire = int(<IN>); # 미사일 발사 수
 $ownername = <IN>; # 소유자네무
 chomp($ownername);

 # HidToName 테이블에 저장
 $HidToName{$id} = $name;	#

 # 지형
 my(@land, @landValue, $line, @command, @lbbs);

 if(($num == -1) || ($num == $id)) {
	if(!open(IIN, "${HdirName}/island.$id")) {
	 rename("${HdirName}/islandtmp.$id", "${HdirName}/island.$id");
	 if(!open(IIN, "${HdirName}/island.$id")) {
		exit(0);
	 }
	}
	my($x, $y);
	for($y = 0; $y < $HislandSize; $y++) {
	 $line = <IIN>;
	 for($x = 0; $x < $HislandSize; $x++) {
		$line =~ s/^(.)(..)//;
		$land[$x][$y] = hex($1);
		$landValue[$x][$y] = hex($2);
	 }
	}

	# 명령
	my($i);
	for($i = 0; $i < $HcommandMax; $i++) {
	 $line = <IIN>;
	 $line =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	 $command[$i] = {
		'kind' => int($1),
		'target' => int($2),
		'x' => int($3),
		'y' => int($4),
		'arg' => int($5)
		}
	}

	# 로컬 게시판
	for($i = 0; $i < $HlbbsMax; $i++) {
	 $line = <IIN>;
	 chomp($line);
	 $lbbs[$i] = $line;
	}

	close(IIN);
 }

 # 섬 형태로 반환
 return {
	 'name' => $name,
	 'id' => $id,
	 'score' => $score,
	 'score2' => $score2,
	 'prize' => $prize,
	 'absent' => $absent,
	 'comment' => $comment,
	 'password' => $password,
	 'money' => $money,
	 'food' => $food,
	 'pop' => $pop,
	 'area' => $area,
	 'farm' => $farm,
	 'factory' => $factory,
	 'mountain' => $mountain,
	 'jointurn' => $jointurn,
	 'shinkado' => $shinkado,
 'fire' => $fire,
 'ownername' => $ownername,
	 'land' => \@land,
	 'landValue' => \@landValue,
	 'command' => \@command,
	 'lbbs' => \@lbbs,
 };
}

# 전체 섬 데이터 쓰기
sub writeIslandsFile {
 my($num) = @_;

 # 파일을 열기
 open(OUT, ">${HdirName}/hakojima.tmp");

 # 각매개변수쓰기
 print OUT "$HislandTurn\n";
 print OUT "$HislandLastTime\n";
 print OUT "$HislandNumber\n";
 print OUT "$HislandNextID\n";

 # 섬의 쓰기
 my($i);
 for($i = 0; $i < $HislandNumber; $i++) {
	 writeIsland($Hislands[$i], $num);
 }

 # 파일을 닫기
 close(OUT);

 # 원래 이름으로
 unlink("${HdirName}/hakojima.dat");
 rename("${HdirName}/hakojima.tmp", "${HdirName}/hakojima.dat");
}

# 섬 하나 쓰기
sub writeIsland {
 my($island, $num) = @_;
 my($score, $score2);
 $score = int($island->{'score'});
 $score2 = int($island->{'score2'});
 print OUT $island->{'name'}. ",$score,$score2\n";
 print OUT $island->{'id'}. "\n";
 print OUT $island->{'prize'}. "\n";
 print OUT $island->{'absent'}. "\n";
 print OUT $island->{'comment'}. "\n";
 print OUT $island->{'password'}. "\n";
 print OUT $island->{'money'}. "\n";
 print OUT $island->{'food'}. "\n";
 print OUT $island->{'pop'}. "\n";
 print OUT $island->{'area'}. "\n";
 print OUT $island->{'farm'}. "\n";
 print OUT $island->{'factory'}. "\n";
 print OUT $island->{'mountain'}. "\n";
 print OUT $island->{'jointurn'}. "\n";
 print OUT $island->{'shinkado'}. "\n";
 print OUT $island->{'fire'}. "\n";
 print OUT $island->{'ownername'}. "\n";

 # 지형
 if(($num <= -1) || ($num == $island->{'id'})) {
	open(IOUT, ">${HdirName}/islandtmp.$island->{'id'}");

	my($land, $landValue);
	$land = $island->{'land'};
	$landValue = $island->{'landValue'};
	my($x, $y);
	for($y = 0; $y < $HislandSize; $y++) {
	 for($x = 0; $x < $HislandSize; $x++) {
		printf IOUT ("%x%02x", $land->[$x][$y], $landValue->[$x][$y]);
	 }
	 print IOUT "\n";
	}

	# 명령
	my($command, $cur, $i);
	$command = $island->{'command'};
	for($i = 0; $i < $HcommandMax; $i++) {
	 printf IOUT ("%d,%d,%d,%d,%d\n",
			 $command->[$i]->{'kind'},
			 $command->[$i]->{'target'},
			 $command->[$i]->{'x'},
			 $command->[$i]->{'y'},
			 $command->[$i]->{'arg'}
			 );
	}

	# 로컬 게시판
	my($lbbs);
	$lbbs = $island->{'lbbs'};
	for($i = 0; $i < $HlbbsMax; $i++) {
	 print IOUT $lbbs->[$i]. "\n";
	}

	close(IOUT);
	unlink("${HdirName}/island.$island->{'id'}");
	rename("${HdirName}/islandtmp.$island->{'id'}", "${HdirName}/island.$island->{'id'}");
 }
}

#----------------------------------------------------------------------
# 입출력
#----------------------------------------------------------------------

# 표준 출력으로 출력
sub out {
 print STDOUT $_[0];
}

# 디버그 로그
sub HdebugOut {
 open(DOUT, ">>debug.log");
 print DOUT ($_[0]);
 close(DOUT);
}

# CGI 읽기
sub cgiInput {
 my($line, $getLine);

 # 입력을 받아 UTF-8로 처리
 $line = <>;
 $line =~ tr/+/ /;
 $line =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
 $line = $line;
 $line =~ s/[\x00-\x1f\,]//g;

 # GET 값을 받음
 $getLine = $ENV{'QUERY_STRING'};

 # 대상의 섬
 if($line =~ /CommandButton([0-9]+)=/) {
	# 명령 전송버튼의 경우
	$HcurrentID = $1;
	$defaultID = $1;
 }

 if($line =~ /ISLANDNAME=([^\&]*)\&/){
	# 이름 지정의 경우
	$HcurrentName = cutColumn($1, 32);
 }

 if($line =~ /ISLANDID=([0-9]+)\&/){
	# 기타의 경우
	$HcurrentID = $1;
	$defaultID = $1;
 }

 # 비밀번호
 if($line =~ /OLDPASS=([^\&]*)\&/) {
	$HoldPassword = $1;
	$HdefaultPassword = $1;
 }
 if($line =~ /PASSWORD=([^\&]*)\&/) {
	$HinputPassword = $1;
	$HdefaultPassword = $1;
 }
 if($line =~ /PASSWORD2=([^\&]*)\&/) {
	$HinputPassword2 = $1;
 }

 # 메시지
 if($line =~ /MESSAGE=([^\&]*)\&/) {
	$Hmessage = cutColumn($1, 80);
 }

 # Java스크립트 모드
	if($line =~ /JAVAMODE=(cgi|java)/) {
	$HjavaMode = $1;
	}
	if($getLine =~ /JAVAMODE=(cgi|java)/) {
	$HjavaMode = $1;
	}
 # 명령의 팝업 메뉴를 열기?
	if($line =~ /MENUOPEN=([a-zA-Z]*[0-9]*)/) {
	$HmenuOpen = $1;
	}

 if($line =~ /CommandJavaButton([0-9]+)=/) {
	# 명령 전송버튼의 경우(Java스크립트)
	$HcurrentID = $1;
	$defaultID = $1;
 }

 # 로컬 게시판
 if($line =~ /LBBSNAME=([^\&]*)\&/) {
 $HlbbsName = $1;
 $HdefaultName = $1;
 }
 if($line =~ /LBBSMESSAGE=([^\&]*)\&/) {
 $HlbbsMessage = cutColumn($1, 80);
 }

 if($line =~ /IMGLINEMAC=([^&]*)\&/){
 my($flag) = 'file:///'. $1;
 $HimgLine = $flag;
 }

 if($line =~ /IMGLINE=([^&]*)\&/){
 my($flag) = substr($1, 0, -10);
 $flag =~ tr/\\/\//;
 if($flag eq 'del'){ $flag = $imageDir; } else { $flag = 'file:///'. $flag; }
 $HimgLine = $flag;
 }

 if($line =~ /OWNERNAME=([^\&]*)\&/){
 # 소유자 이름 지정의 경우
 $HownerName = cutColumn($1, 22);
 }

 # main mode 의가져오기
 if($line =~ /TurnButton/) {
	if($Hdebug == 1) {
	 $HmainMode = 'Hdebugturn';
	}
 } elsif($line =~ /OwnerButton/) {
	$HmainMode = 'owner';
 } elsif($getLine =~ /Sight=([0-9]*)/) {
	$HmainMode = 'print';
	$HcurrentID = $1;
 } elsif($line =~ /ChangeOwnerName/) {
 $HmainMode = 'change';
 } elsif($getLine =~ /IslandMap=([0-9]*)/) {
	$HmainMode = 'landmap';
	$HcurrentID = $1;
 } elsif($line =~ /NewIslandButton/) {
	$HmainMode = 'new';
 } elsif($line =~ /LbbsButton(..)([0-9]*)/) {
 $HmainMode = 'lbbs';
 if($1 eq 'FO') {
 # 관광객
 $HlbbsMode = 0;
 $HforID = $HcurrentID;
 } elsif($1 eq 'OW') {
 # 섬주
 $HlbbsMode = 1;
 } else {
 # 삭제
 $HlbbsMode = 2;
	}
	$HcurrentID = $2;

	# 삭제할 수 없으므로 번호를 가져옴
	$line =~ /NUMBER=([^\&]*)\&/;
	$HcommandPlanNumber = $1;

 } elsif($line =~ /ChangeInfoButton/) {
	$HmainMode = 'change';
 } elsif($line =~ /MessageButton([0-9]*)/) {
	$HmainMode = 'comment';
	$HcurrentID = $1;
 } elsif($line =~ /CommandJavaButton/) {
	$HmainMode = 'commandJava';
	$line =~ /COMARY=([^\&]*)\&/;
	$HcommandComary = $1;
	$line =~ /COMMAND=([^\&]*)\&/;
	$HdefaultKind = $1;
	$line =~ /POINTX=([^\&]*)\&/;
	$HdefaultX = $1;
	$line =~ /POINTY=([^\&]*)\&/;
	$HdefaultY = $1;
 } elsif($line =~ /CommandButton/) {
	if($HjavaMode eq 'java'){
	$HmainMode = 'command2';
	}else{
	$HmainMode = 'command';
	}

	# 명령 모드의 경우, 명령의 가져오기
	$line =~ /NUMBER=([^\&]*)\&/;
	$HcommandPlanNumber = $1;
	$line =~ /COMMAND=([^\&]*)\&/;
	$HcommandKind = $1;
	$HdefaultKind = $1;
	$line =~ /AMOUNT=([^\&]*)\&/;
	$HcommandArg = $1;
	$line =~ /TARGETID=([^\&]*)\&/;
	$HcommandTarget = $1;
	$defaultTarget = $1;
	$line =~ /POINTX=([^\&]*)\&/;
	$HcommandX = $1;
	$HdefaultX = $1;
	$line =~ /POINTY=([^\&]*)\&/;
	$HcommandY = $1;
	$HdefaultY = $1;
	$line =~ /COMMANDMODE=(write|insert|delete)/;
	$HcommandMode = $1;
 } else {
	$HmainMode = 'top';
 }

}


#cookie 입력
sub cookieInput {
 my($cookie);

 $cookie = $ENV{'HTTP_COOKIE'};

 if($cookie =~ /${HthisFile}OWNISLANDID=\(([^\)]*)\)/) {
	$defaultID = $1;
 }
 if($cookie =~ /${HthisFile}OWNISLANDPASSWORD=\(([^\)]*)\)/) {
	$HdefaultPassword = $1;
 }
 if($cookie =~ /${HthisFile}TARGETISLANDID=\(([^\)]*)\)/) {
	$defaultTarget = $1;
 }
 if($cookie =~ /${HthisFile}LBBSNAME=\(([^\)]*)\)/) {
	$HdefaultName = $1;
 }
 if($cookie =~ /${HthisFile}POINTX=\(([^\)]*)\)/) {
	$HdefaultX = $1;
 }
 if($cookie =~ /${HthisFile}POINTY=\(([^\)]*)\)/) {
	$HdefaultY = $1;
 }
 if($cookie =~ /${HthisFile}KIND=\(([^\)]*)\)/) {
	$HdefaultKind = $1;
 }
 if($cookie =~ /${HthisFile}IMGLINE=\(([^\)]*)\)/) {
 $HimgLine = $1;
 }
 if($cookie =~ /${HthisFile}JAVAMODESET=\(([^\)]*)\)/) {
	$HjavaModeSet = $1;
 }

}

#cookie 출력
sub cookieOutput {
 my($cookie, $info);

 # 삭제 가능 기한 설정
 my($sec, $min, $hour, $date, $mon, $year, $day, $yday, $dummy) =
	gmtime(time + 30 * 86400); # 현재 + 30일

 # 2자리화
 $year += 1900;
 if ($date < 10) { $date = "0$date"; }
 if ($hour < 10) { $hour = "0$hour"; }
 if ($min < 10) { $min = "0$min"; }
 if ($sec < 10) { $sec = "0$sec"; }

 # 요일일을 문자에
 $day = ("Sunday", "Monday", "Tuesday", "Wednesday",
	 "Thursday", "Friday", "Saturday")[$day];

 # 월을 문자에
 $mon = ("Jan", "Feb", "Mar", "Apr", "May", "Jun",
	 "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")[$mon];

 # 경로와 기간 설정
 $info = "; expires=$day, $date\-$mon\-$year $hour:$min:$sec GMT\n";
 $cookie = '';

 if(($HcurrentID) && ($HmainMode eq 'owner')){
	$cookie.= "Set-Cookie: ${HthisFile}OWNISLANDID=($HcurrentID) $info";
 }
 if($HinputPassword) {
	$cookie.= "Set-Cookie: ${HthisFile}OWNISLANDPASSWORD=($HinputPassword) $info";
 }
 if($HcommandTarget) {
	$cookie.= "Set-Cookie: ${HthisFile}TARGETISLANDID=($HcommandTarget) $info";
 }
 if($HlbbsName) {
	$cookie.= "Set-Cookie: ${HthisFile}LBBSNAME=($HlbbsName) $info";
 }
 if($HcommandX) {
	$cookie.= "Set-Cookie: ${HthisFile}POINTX=($HcommandX) $info";
 }
 if($HcommandY) {
	$cookie.= "Set-Cookie: ${HthisFile}POINTY=($HcommandY) $info";
 }
 if($HcommandKind) {
	# 자동 입력 이외
	$cookie.= "Set-Cookie: ${HthisFile}KIND=($HcommandKind) $info";
 }
 if($HimgLine) {
 $cookie.= "Set-Cookie: ${HthisFile}IMGLINE=($HimgLine) $info";
 }
 if($HjavaMode) {
	$cookie.= "Set-Cookie: ${HthisFile}JAVAMODESET=($HjavaMode) $info";
 }

 out($cookie);
}

#----------------------------------------------------------------------
# 유티리티
#----------------------------------------------------------------------
sub hakolock {
 if($lockMode == 1) {
	# directory 방식 잠금
	return hakolock1();

 } elsif($lockMode == 2) {
	# flock 방식 잠금
	return hakolock2();
 } elsif($lockMode == 3) {
	# symlink 방식 잠금
	return hakolock3();
 } else {
	# 일반 파일 방식 잠금
	return hakolock4();
 }
}

sub hakolock1 {
 # 잠금을 시도
 if(mkdir('hakojimalock', $HdirMode)) {
	# 성공
	return 1;
 } else {
	# 실패
	my($b) = (stat('hakojimalock'))[9];
	if(($b> 0) && ((time() - $b)> $unlockTime)) {
	 # 강제 해제
	 unlock();

	 # 헤더출력
	 tempHeader();

	 # 강제 해제 메시지
	 tempUnlock();

	 # 푸터출력
	 tempFooter();

	 # 종료
	 exit(0);
	}
	return 0;
 }
}

sub hakolock2 {
 open(LOCKID, '>>hakojimalockflock');
 if(flock(LOCKID, 2)) {
	# 성공
	return 1;
 } else {
	# 실패
	return 0;
 }
}

sub hakolock3 {
 # 잠금을 시도
 if(symlink('hakojimalockdummy', 'hakojimalock')) {
	# 성공
	return 1;
 } else {
	# 실패
	my($b) = (lstat('hakojimalock'))[9];
	if(($b> 0) && ((time() - $b)> $unlockTime)) {
	 # 강제 해제
	 unlock();

	 # 헤더출력
	 tempHeader();

	 # 강제 해제 메시지
	 tempUnlock();

	 # 푸터출력
	 tempFooter();

	 # 종료
	 exit(0);
	}
	return 0;
 }
}

sub hakolock4 {
 # 잠금을 시도
 if(unlink('key-free')) {
	# 성공
	open(OUT, '>key-locked');
	print OUT time;
	close(OUT);
	return 1;
 } else {
	# 잠금 시간 확인
	if(!open(IN, 'key-locked')) {
	 return 0;
	}

	my($t);
	$t = <IN>;
	close(IN);
	if(($t != 0) && (($t + $unlockTime) < time)) {
	 # 120초 이상 경과하면 강제로 잠금을 해제
	 unlock();

	 # 헤더출력
	 tempHeader();

	 # 강제 해제 메시지
	 tempUnlock();

	 # 푸터출력
	 tempFooter();

	 # 종료
	 exit(0);
	}
	return 0;
 }
}

# 잠금을 해제
sub unlock {
 if($lockMode == 1) {
	# directory 방식 잠금
	rmdir('hakojimalock');

 } elsif($lockMode == 2) {
	# flock 방식 잠금
	close(LOCKID);

 } elsif($lockMode == 3) {
	# symlink 방식 잠금
	unlink('hakojimalock');
 } else {
	# 일반 파일 방식 잠금
	my($i);
	$i = rename('key-locked', 'key-free');
 }
}

# 작은 쪽을 반환
sub min {
 return ($_[0] < $_[1]) ? $_[0] : $_[1];
}

# 비밀번호엔코드
sub encode {
 if($cryptOn == 1) {
	return crypt($_[0], 'h2');
 } else {
	return $_[0];
 }
}

# 비밀번호 확인
sub checkPassword {
 my($p1, $p2) = @_;

 # null 확인
 if($p2 eq '') {
	return 0;
 }

 # 마스터 비밀번호 확인
 if($masterPassword eq $p2) {
	return 1;
 }

 # 본래의 확인
 if($p1 eq encode($p2)) {
	return 1;
 }

 return 0;
}

# 1000억단위원형메루틴
sub aboutMoney {
 my($m) = @_;
 if($m < 500) {
	return "추정500${HunitMoney}미만";
 } else {
	$m = int(($m + 500) / 1000);
	return "추정${m}000${HunitMoney}";
 }
}

# 이스케이프문자의 처리
sub htmlEscape {
 my($s) = @_;
 $s =~ s/&/&amp;/g;
 $s =~ s/</&lt;/g;
 $s =~ s/>/&gt;/g;
 $s =~ s/\"/&quot;/g; #"
 return $s;
}

# 80자리에절리갖춤에
sub cutColumn {
 my($s, $c) = @_;
 if(length($s) <= $c) {
	return $s;
 } else {
	# 합계80자리가 됨까지절리 처리
	my($ss) = '';
	my($count) = 0;
	while($count < $c) {
	 $s =~ s/(^[\x80-\xFF][\x80-\xFF])|(^[\x00-\x7F])//;
	 if($1) {
		$ss.= $1;
		$count ++;
	 } else {
		$ss.= $2;
	 }
	 $count ++;
	}
	return $ss;
 }
}

# 섬 이름으로 번호를 얻음(ID가 아니라 번호)
sub nameToNumber {
 my($name) = @_;

 # 전체 섬에서 찾기
 my($i);
 for($i = 0; $i < $HislandNumber; $i++) {
	if($Hislands[$i]->{'name'} eq $name) {
	 return $i;
	}
 }

 # 찾을 수 없었던 경우
 return -1;
}

# 괴수의 정보
sub monsterSpec {
 my($lv) = @_;

 # 종류
 my($kind) = int($lv / 10);

 # 이름
 my($name);
 $name = $HmonsterName[$kind];

 # 체력
 my($hp) = $lv - ($kind * 10);

 return ($kind, $name, $hp);
}

# 경험치에서 레벨을 산출
sub expToLevel {
 my($kind, $exp) = @_;
 my($i);
 if($kind == $HlandBase) {
	# 미사일 기지
	for($i = $maxBaseLevel; $i> 1; $i--) {
	 if($exp>= $baseLevelUp[$i - 2]) {
		return $i;
	 }
	}
	return 1;
 } else {
	# 해저 기지
	for($i = $maxSBaseLevel; $i> 1; $i--) {
	 if($exp>= $sBaseLevelUp[$i - 2]) {
		return $i;
	 }
	}
	return 1;
 }

}

# (0,0)에서(size - 1, size - 1)까지의 숫자가한 번씩 나오도록
# (@Hrpx, @Hrpy)을 설정
sub makeRandomPointArray {
 # 초기 값
 my($y);
 @Hrpx = (0..$HislandSize-1) x $HislandSize;
 for($y = 0; $y < $HislandSize; $y++) {
	push(@Hrpy, ($y) x $HislandSize);
 }

 # 셔터 전체
 my ($i);
 for ($i = $HpointNumber; --$i; ) {
	my($j) = int(rand($i+1));
	if($i == $j) { next; }
	@Hrpx[$i,$j] = @Hrpx[$j,$i];
	@Hrpy[$i,$j] = @Hrpy[$j,$i];
 }
}

# 0에서(n - 1)의 난수
sub random {
 return int(rand(1) * $_[0]);
}

#----------------------------------------------------------------------
# 로그 표시
#----------------------------------------------------------------------
# 파일 번호를 지정해 로그 표시
sub logFilePrint {
 my($fileNumber, $id, $mode) = @_;
 open(LIN, "${HdirName}/hakojima.log$_[0]");
 my($line, $m, $turn, $id1, $id2, $message);
 my($set_turn) = 0;
 while($line = <LIN>) {
	$line =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),(.*)$/;
	($m, $turn, $id1, $id2, $message) = ($1, $2, $3, $4, $5);

	# 기밀관계
	if($m == 1) {
	 if(($mode == 0) || ($id1 != $id)) {
		# 기밀 표시 권한 없음
		next;
	 }
	 $m = '<B>(기밀)</B>';
	} else {
	 $m = '';
	}

	# 정확히 표시할지
	if($id != 0) {
	 if(($id != $id1) &&
	 ($id != $id2)) {
		next;
	 }
	}

	# 표시
	if($set_turn == 0){
	out("<NOBR><B>=====[<FONT SIZE=4 COLOR=BLUE> 턴$turn </FONT>]================================================</B><NOBR><BR>\n");
	$set_turn++;
	}

	out("<NOBR>${HtagNumber_}턴$turn$m${H_tagNumber}:$message</NOBR><BR>\n");
 }
 close(LIN);
}

#----------------------------------------------------------------------
# HTML생성
#----------------------------------------------------------------------
sub logPrintHtml {
	my($sec, $min, $hour, $date, $mon, $year, $day, $yday, $dummy) = localtime(time);
	$mon++;
	my($sss) = "${mon}월${date}일 ${hour} 시${min}분${sec}초";

	$html1=<<_HEADER_;
<HTML><HEAD><META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
<TITLE>
최근 사건
</TITLE>
<BASE HREF="$imageDir/">
</HEAD>
<BODY $htmlBody>
<H1>${HtagHeader_}최근 사건${H_tagHeader}</H1>
<FORM>
최신갱신일:$sss..
<INPUT TYPE="button" VALUE=" 다시 읽기" onClick="location.reload()">
</FORM>
<hr>
_HEADER_

$html3=<<_HEADER_;
<HR>
</BODY>
</HTML>
_HEADER_
	my($i);
	for($i = 0; $i < $HtopLogTurn; $i++) {
		$id =0;
		$mode = 0;
		my($set_turn) = 0;
		open(LIN, "${HdirName}/hakojima.log$i");
		my($line, $m, $turn, $id1, $id2, $message);
		while($line = <LIN>) {
			$line =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),(.*)$/;
			($m, $turn, $id1, $id2, $message) = ($1, $2, $3, $4, $5);

			# 기밀관계
			if($m == 1) {
				if(($mode == 0) || ($id1 != $id)) {
				# 기밀 표시 권한 없음
				next;
				}
				$m = '<B>(기밀)</B>';
			} else {
				$m = '';
			}

			# 정확히 표시할지
			if($id != 0) {
				if(($id != $id1) &&	($id != $id2)) {
					next;
				}
			}

			# 표시
			if($set_turn == 0){
				$html2.= "<NOBR><B>=====[<FONT SIZE=4 COLOR=BLUE>턴$turn </FONT>]================================================</B><NOBR><BR>\n";
				$set_turn++;
			}
			$html2.= "<NOBR>${HtagNumber_}★:${H_tagNumber}$message</NOBR><BR>\n";
		}
		close(LIN);
	}
	open(HTML, ">hakolog.html");
	print HTML $html1;
	print HTML $html2;
	print HTML $html3;
	close (HTML);
	chmod(0666,"hakolog.html");
}

#----------------------------------------------------------------------
# 템플릿
#----------------------------------------------------------------------
# 초기화
sub tempInitialize {
 # 섬 선택(기본값은 자신)
 $HislandList = getIslandList($defaultID);
 $HtargetList = getIslandList($defaultTarget);
}

# 섬 데이터 드롭다운 메뉴용
sub getIslandList {
 my($select) = @_;
 my($list, $name, $id, $s, $i);

 #섬 목록의 메뉴
 $list = '';
 for($i = 0; $i < $HislandNumber; $i++) {
	$name = $Hislands[$i]->{'name'};
	$id = $Hislands[$i]->{'id'};
	if($id eq $select) {
	 $s = 'SELECTED';
	} else {
	 $s = '';
	}
	$list.=
	 "<OPTION VALUE=\"$id\" $s>${name} 섬\n";
 }
 return $list;
}


# 헤더
sub tempHeader {

my($HimgFlag) = 0;
 $baseIMG = $imageDir;
 $HimgFlag = 1;
	# 이미지 경로 설정의 오류를 강제로해제(문자 깨짐 문제가 아닙니다)
	$baseIMG =~ s/데스크톱/데스크톱/g;
 out(<<END);
Content-type: text/html; charset=UTF-8

<HTML>
<HEAD><META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
<TITLE>
$Htitle
</TITLE>
<BASE HREF="$baseIMG/">
</HEAD>
<BODY $htmlBody>
<A HREF="http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html">모형정원 제도 스크립트 배포처</A> / <A HREF=http://www.ahooo.net/>아호아호오차의 회</A> / <A HREF="$bbs">게시판</A> / <A HREF=$baseDir/hakolog.html>최근 사건</A> / <A HREF="$toppage">톱 페이지</A><HR>
END
}

# 푸터
sub tempFooter {
 out(<<END);
<HR>
<P align=right>
<A HREF="$toppage">톱 페이지</A> / <A HREF=$baseDir/hakolog.html>최근 사건</A> / <A HREF="$bbs">게시판</A> / <A HREF=http://www.ahooo.net/>아호아호오차의 회</A> / <A HREF="http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html">모형정원 제도 스크립트 배포처</A><BR>
<A HREF="mailto:$email">관리자:$adminName</A><BR>
</P>
</BODY>
</HTML>
END
}

# 잠금실패
sub tempLockFail {
 # 제목
 out(<<END);
${HtagBig_}동시접속오류입니다.<BR>
브라우저의'돌아가기'버튼을 누름시,<BR>
잠시 기다렸다가 다시오시 도시하세요.${H_tagBig}$HtempBack
END
}

# 강제 해제
sub tempUnlock {
 # 제목
 out(<<END);
${HtagBig_}지난 접속이 비정상 종료된 것 같습니다.<BR>
잠금을 강제 해제했습니다.${H_tagBig}$HtempBack
END
}

# hakojima.dat 이 없음
sub tempNoDataFile {
 out(<<END);
${HtagBig_}데이터 파일을 열 수 없습니다.${H_tagBig}$HtempBack
END
}

# 비밀번호 오류
sub tempWrongPassword {
 out(<<END);
${HtagBig_} 비밀번호가 다릅니다.${H_tagBig}$HtempBack
END
}

# 무언가문제발생
sub tempProblem {
 out(<<END);
${HtagBig_}문제발생, 일단복귀해 주세요.${H_tagBig}$HtempBack
END
}



