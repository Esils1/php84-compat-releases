#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}
#----------------------------------------------------------------------
# JavaScript판 -ver1.11-
# 사용 조건, 사용 방법은  배포처를 확인하세요.
# 부속의 js-readme.txt 모오읽기하세요.
# 앗포:http://appoh.execweb.cx/hakoniwa/
#----------------------------------------------------------------------

#----------------------------------------------------------------------
# Java스크립트개발 화면
#----------------------------------------------------------------------
# ○○섬개발계획
sub tempOwnerJava {
	$HcurrentNumber = $HidToNumber{$HcurrentID};
	my($island) = $Hislands[$HcurrentNumber];

	# 명령 설정
	$set_com = "";
	$com_max = "";
	for($i = 0; $i < $HcommandMax; $i++) {
		# 각 요소 꺼내기
		my($command) = $island->{'command'}->[$i];
		my($s_kind, $s_target, $s_x, $s_y, $s_arg) =
		(
		$command->{'kind'},
		$command->{'target'},
		$command->{'x'},
		$command->{'y'},
		$command->{'arg'}
		);
		# 명령 등록
		if($i == $HcommandMax-1){
			$set_com.= "\[$s_kind\,$s_x\,$s_y\,$s_arg\,$s_target\]\n";
			$com_max.= "0"
		}else{
			$set_com.= "\[$s_kind\,$s_x\,$s_y\,$s_arg\,$s_target\]\,\n";
			$com_max.= "0,"
		}
	}

 #명령 목록 설정
	my($l_kind);
	$set_listcom = "";
	$click_com = "";
	$click_com2 = "";
	$All_listCom = 0;
	$com_count = @HcommandDivido;
	for($m = 0; $m < $com_count; $m++) {
		($aa,$dd,$ff) = split(/,/,$HcommandDivido[$m]);
		$set_listcom.= "\[ ";
	 for($i = 0; $i < $HcommandTotal; $i++) {
			$l_kind = $HcomList[$i];
			$l_cost = $HcomCost[$l_kind];
			if($l_cost == 0) { $l_cost = '무료'	}
			elsif($l_cost < 0) { $l_cost = - $l_cost; $l_cost.= $HunitFood; }
			else { $l_cost.= $HunitMoney; }
			if($l_kind> $dd-1 && $l_kind < $ff+1) {
				$set_listcom.= "\[$l_kind\,\'$HcomName[$l_kind]\',\'$l_cost\'\]\,\n";
				if($m == 0){
					$click_com.= "<a href='javascript:void(0);' onClick='cominput(myForm,6,$l_kind)' STYlE='text-decoration:none'>$HcomName[$l_kind]($l_cost)</a><br>\n";
				}elsif($m == 1){
					$click_com2.= "<a href='javascript:void(0);' onClick='cominput(myForm,6,$l_kind)' STYlE='text-decoration:none'>$HcomName[$l_kind]($l_cost)</a><br>\n";
				}
				$All_listCom++;
			}
			if($l_kind < $ff+1) { next; }
		}
		$bai = length($set_listcom);
		$set_listcom = substr($set_listcom, 0,$bai-2);
		$set_listcom.= " \],\n";
	}
	$bai = length($set_listcom);
	$set_listcom = substr($set_listcom, 0,$bai-2);
	if($HdefaultKind eq ''){ $default_Kind = 1;}
	else{ $default_Kind = $HdefaultKind; }

	#섬 목록 설정
	my($set_island, $l_name, $l_id);
	$set_island = "";
	for($i = 0; $i < $HislandNumber; $i++) {
		$l_name = $Hislands[$i]->{'name'};
		$l_name =~ s/'/\\'/g;
		$l_id = $Hislands[$i]->{'id'};
		if($i == $HislandNumber-1){
			$set_island.= "\[$l_id\,\'$l_name\'\]\n";
		}else{
			$set_island.= "\[$l_id\,\'$l_name\'\]\,\n";
		}
	}

 out(<<END);
<CENTER>
${HtagBig_}${HtagName_}${HcurrentName} 섬${H_tagName}개발계획${H_tagBig}<BR>
$HtempBack<BR>
</CENTER>
<SCRIPT Language="JavaScript">
<!--
// JavaScript 개발판 배포처
// 앗포암자모형정원 제도( http://appoh.execweb.cx/hakoniwa/ )
// Programmed by Jynichi Sakai(앗포)
// ↑ 삭제하지 마세요.
var str;
g = [$com_max];
k1 = [$com_max];
k2 = [$com_max];
tmpcom1 = [ [0,0,0,0,0] ];
tmpcom2 = [ [0,0,0,0,0] ];
command = [
$set_com];

comlist = [
$set_listcom
];

islname = [
$set_island];

function init(){
	document.onkeydown = commandKeyDown;
	for(i = 0; i < command.length ;i++) {
		for(s = 0; s < $com_count ;s++) {
		var comlist2 = comlist[s];
		for(j = 0; j < comlist2.length ; j++) {
			if(command[i][0] == comlist2[j][0]) {
				g[i] = comlist2[j][1];
			}
		}
		}
	}
	outp();
	str = plchg();
	str = "<font color=blue>---- 전송 완료 ----</font><br>"+str;
	disp(str, "#ccffcc");

	check_menu();
	if((document.layers) || (document.all)){ // IE4,IE5,NN4
		window.document.onmouseup = menuclose;
	}
}

function cominput(theForm, x, k) {
	a = theForm.NUMBER.options[theForm.NUMBER.selectedIndex].value;
	b = theForm.COMMAND.options[theForm.COMMAND.selectedIndex].value;
	c = theForm.POINTX.options[theForm.POINTX.selectedIndex].value;
	d = theForm.POINTY.options[theForm.POINTY.selectedIndex].value;
	e = theForm.AMOUNT.options[theForm.AMOUNT.selectedIndex].value;
	f = theForm.TARGETID.options[theForm.TARGETID.selectedIndex].value;
	if(x == 6){ b = k; menuclose();	}
	if (x == 1 || x == 6){
		for(i = $HcommandMax - 1; i> a; i--) {
			command[i] = command[i-1];
			g[i] = g[i-1];
		}
	}else if(x == 3){
		for(i = Math.floor(a); i < ($HcommandMax - 1); i++) {
			command[i] = command[i + 1];
			g[i] = g[i+1];
		}
		command[$HcommandMax-1] = [41,0,0,0,0];
		g[$HcommandMax-1] = '자금 조달';
		str = plchg();
		str = "<font color=red><b>-----미전송------</b></font><br>"+str;
		disp(str,"white");
		outp();
		return true;
	}else if(x == 4){
		i = Math.floor(a)
		if (i == 0){ return true; }
		i = Math.floor(a)
		tmpcom1[i] = command[i];tmpcom2[i] = command[i - 1];
		command[i] = tmpcom2[i];command[i-1] = tmpcom1[i];
		k1[i] = g[i];k2[i] = g[i - 1];
		g[i] = k2[i];g[i-1] = k1[i];
		ns(--i);
		str = plchg();
		str = "<font color=red><b>-----미전송------</b></font><br>"+str;
		disp(str,"white");
		outp();
		return true;
	}else if(x == 5){
		i = Math.floor(a)
		if (i == $HcommandMax-1){ return true; }
		tmpcom1[i] = command[i];tmpcom2[i] = command[i + 1];
		command[i] = tmpcom2[i];command[i+1] = tmpcom1[i];
		k1[i] = g[i];k2[i] = g[i + 1];
		g[i] = k2[i];g[i+1] = k1[i];
		ns(++i);
		str = plchg();
		str = "<font color=red><b>-----미전송------</b></font><br>"+str;
		disp(str,"white");
		outp();
		return true;
	}

	for(s = 0; s < $com_count ;s++) {
	var comlist2 = comlist[s];
	for(i = 0; i < comlist2.length; i++){
		if(comlist2[i][0] == b){
			g[a] = comlist2[i][1];
			break;
		}
	}
	}
	command[a] = [b,c,d,e,f];
	ns(++a);
	str = plchg();
	str = "<font color=red><b>-----미전송------</b></font><br>"+str;
	disp(str, "white");
	outp();
	return true;
}

function plchg(){
	strn1 = "";
	for(i = 0; i < $HcommandMax; i++)	{
		c = command[i];
		kind = '<FONT COLOR="#d08000"><B>' + g[i] + '</B></FONT>';
		x = c[1];
		y = c[2];
		tgt = c[4];
		point = '<FONT COLOR="#a06040"><B>' + "(" + x + "," + y + ")" + '</B></FONT>';
		for(j = 0; j < islname.length ; j++) {
			if(tgt == islname[j][0]){
				tgt = '<FONT COLOR="#a06040"><B>' + islname[j][1] + "섬" + '</B></FONT>';
			}
		}
		if(c[0] == $HcomDoNothing || c[0] == $HcomGiveup){ // 자금 조달, 섬 포기
			strn2 = kind;
		}else if(c[0] == $HcomMissileNM || // 미사일 관련
			c[0] == $HcomMissilePP ||
			c[0] == $HcomMissileST ||
			c[0] == $HcomMissileLD){
			if(c[3] == 0){
				arg = "(무제한)";
			} else {
				arg = "(" + c[3] + "발)";
			}
			strn2 = tgt + point + "로" + kind + arg;
		}else if(c[0] == $HcomSendMonster){ // 괴수 파견
			strn2 = tgt + "로" + kind;
		}else if(c[0] == $HcomSell){ // 식량 수출
			if(c[3] == 0){ c[3] = 1; }
			arg = c[3] * 100;
			arg = "(" + arg + "$HunitFood)";
			strn2 = kind + arg;
		}else if(c[0] == $HcomPropaganda){ // 유치 활동
			strn2 = kind;
		}else if(c[0] == $HcomMoney){ // 자금지원
			if(c[3] == 0){ c[3] = 1; }
			arg = c[3] * $HcomCost[$HcomMoney];
			arg = "(" + arg + "$HunitMoney)";
			strn2 = tgt + "로" + kind + arg;
		}else if(c[0] == $HcomFood){ // 식량지원
			if(c[3] == 0){ c[3] = 1; }
			arg = c[3] * 100;
			arg = "(" + arg + "$HunitFood)";
			strn2 = tgt + "로" + kind + arg;
		}else if(c[0] == $HcomDestroy){ // 굴착
			if(c[3] == 0){
				strn2 = point + " " + kind;
			} else {
				arg = c[3] * $HcomCost[$HcomDestroy];
				arg = "(예정\계산" + arg + "$HunitMoney)";
				strn2 = point + " " + kind + arg;
			}
		}else if(c[0] == $HcomFarm || // 농장, 공장, 채굴장 건설
			c[0] == $HcomFactory ||
			c[0] == $HcomMountain) {
			if(c[3] != 0){
				arg = "(" + c[3] + "회)";
				strn2 = point + " " + kind + arg;
			}else{
				strn2 = point + " " + kind;
			}
		}else{
			strn2 = point + " " + kind;
		}
		tmpnum = '';
		if(i < 9){ tmpnum = '0'; }
		strn1 +=
		'<A STYLE="text-decoration:none;color:000000" HREF="JavaScript:void(0);" onClick="ns(' + i + ')"><NOBR>' +
		tmpnum + (i + 1) + ':' +
		strn2 + '</NOBR></A><BR>\\n';
	}
	return strn1;
}

function disp(str,bgclr){
	if(str==null) str = "";

	if(document.getElementById){
		document.getElementById("LINKMSG1").innerHTML = str;
		document.getElementById("plan").bgColor = bgclr;
	} else if(document.all){
		el = document.all("LINKMSG1");
		el.innerHTML = str;
		document.all.plan.bgColor = bgclr;
	} else if(document.layers) {
		lay = document.layers["PARENT_LINKMSG"].document.layers["LINKMSG1"];
		lay.document.open();
		lay.document.write("<font style='font-size:11pt'>"+str+"</font>");
		lay.document.close();
		document.layers["PARENT_LINKMSG"].bgColor = bgclr;
	}
}

function outp(){
	comary = "";

	for(k = 0; k < command.length; k++){
	comary = comary + command[k][0]
	+" "+command[k][1]
	+" "+command[k][2]
	+" "+command[k][3]
	+" "+command[k][4]
	+" ";
	}
	document.myForm.COMARY.value = comary;
}

function ps(x, y) {
	document.forms[0].elements[4].options[x].selected = true;
	document.forms[0].elements[5].options[y].selected = true;
	document.allForm.POINTX.value = x;
	document.allForm.POINTY.value = y;
	if(!(document.myForm.MENUOPEN.checked))
		moveLAYER("menu",mx,my);
	return true;
}

function firstEmptySlot(){
	for(var i = 0; i < $HcommandMax; i++) {
		if(Number(command[i][0]) == $HcomDoNothing) { return i; }
	}
	return $HcommandMax - 1;
}

function commandKeyDown(e) {
	e = e || window.event;
	var src = e.target || e.srcElement;
	var tag = src && src.tagName ? src.tagName.toUpperCase() : '';
	if(tag == 'INPUT' || tag == 'TEXTAREA' || tag == 'SELECT') { return true; }
	var code = e.keyCode || e.which;
	if(code == 46) {
		cominput(document.myForm,3);
		if(e.preventDefault) { e.preventDefault(); }
		return false;
	}
	return true;
}

function SelectPOINT(){
	document.allForm.POINTX.value = document.forms[0].elements[4].options[document.forms[0].elements[4].selectedIndex].value;
	document.allForm.POINTY.value = document.forms[0].elements[5].options[document.forms[0].elements[5].selectedIndex].value;
	document.allForm.NUMBER.value = firstEmptySlot();
	document.allForm.submit();
}

function ns(x) {
	if (x == $HcommandMax){ return true; }
	document.forms[0].elements[0].options[x].selected = true;
	document.allForm.NUMBER.value = x;
	return true;
}

function set_com(x, y, land) {
	com_str = land + "\\n";
	for(i = 0; i < $HcommandMax; i++)	{
		c = command[i];
		x2 = c[1];
		y2 = c[2];
		if(x == x2 && y == y2 && c[0] < 30){
			com_str += "[" + (i + 1) +"]" ;
			kind = g[i];
			if(c[0] == $HcomDestroy){
				if(c[3] == 0){
					com_str += kind;
				} else {
					arg = c[3] * 200;
					arg = "(예정\계산" + arg + "$HunitMoney)";
					com_str += kind + arg;
				}
			}else if(c[0] == $HcomFarm ||
				c[0] == $HcomFactory ||
				c[0] == $HcomMountain) {
				if(c[3] != 0){
					arg = "(" + c[3] + "회)";
					com_str += kind + arg;
				}else{
					com_str += kind;
				}
			}else{
				com_str += kind;
			}
			com_str += " ";
		}
	}
	document.myForm.COMSTATUS.value= com_str;
}

function not_com() {
//	document.myForm.COMSTATUS.value="";
}

function jump(theForm, j_mode) {
	var sIndex = theForm.TARGETID.selectedIndex;
	var url = theForm.TARGETID.options[sIndex].value;
	if (url != "" ) window.open("$HthisFile?IslandMap=" +url+"&JAVAMODE="+j_mode, "", "menubar=yes,toolbar=no,location=no,directories=no,status=yes,scrollbars=yes,resizable=yes,width=450,height=630");
}

function SelectList(theForm){
	var u, selected_ok;
	if(!theForm){s = ''}
	else { s = theForm.menu.options[theForm.menu.selectedIndex].value; }
	if(s == ''){
		u = 0; selected_ok = 0;
		document.myForm.COMMAND.options.length = $All_listCom;
		for (i=0; i<comlist.length; i++) {
			var command = comlist[i];
			for (a=0; a<command.length; a++) {
				comName = command[a][1] + "(" + command[a][2] + ")";
				document.myForm.COMMAND.options[u].value = command[a][0];
				document.myForm.COMMAND.options[u].text = comName;
				if(command[a][0] == $default_Kind){
					document.myForm.COMMAND.options[u].selected = true;
					selected_ok = 1;
				}
				u++;
			}
		}
		if(selected_ok == 0)
		document.myForm.COMMAND.selectedIndex = 0;
	} else {
		var command = comlist[s];
		document.myForm.COMMAND.options.length = command.length;
		for (i=0; i<command.length; i++) {
			comName = command[i][1] + "(" + command[i][2] + ")";
			document.myForm.COMMAND.options[i].value = command[i][0];
			document.myForm.COMMAND.options[i].text = comName;
			if(command[i][0] == $default_Kind){
				document.myForm.COMMAND.options[i].selected = true;
				selected_ok = 1;
			}
		}
		if(selected_ok == 0)
		document.myForm.COMMAND.selectedIndex = 0;
	}
}

function moveLAYER(layName,x,y){
	if(document.getElementById){		//NN6,IE5
		if(document.all){				//IE5
			el = document.getElementById(layName);
			el.style.left= event.clientX + document.body.scrollLeft + 10;
			el.style.top= event.clientY + document.body.scrollTop - 30;
			el.style.display = "block";
			el.style.visibility ='visible';
		}else{
			el = document.getElementById(layName);
			el.style.left=x+10;
			el.style.top=y-30;
			el.style.display = "block";
			el.style.visibility ='visible';
		}
	} else if(document.layers){				//NN4
		msgLay = document.layers[layName];
		msgLay.moveTo(x+10,y-30);
		msgLay.visibility = "show";
	} else if(document.all){				//IE4
		msgLay = document.all(layName);
		msgLay.style.pixelLeft = x+10;
		msgLay.style.pixelTop = y-30;
		msgLay.style.display = "block";
		msgLay.style.visibility = "visible";
	}

}

function menuclose(){
	if (document.getElementById){
		document.getElementById("menu").style.display = "none";
	} else if (document.layers){
		document.menu.visibility = "hide";
	} else if (document.all){
		window["menu"].style.display = "none";
	}
}

function Mmove(e){
	if(document.all){
		mx = event.x;
		my = event.y;
	}else if(document.layers){
		mx = e.pageX;
		my = e.pageY;
	}else if(document.getElementById){
		mx = e.pageX;
		my = e.pageY;
	}
}

function check_menu(){
	if(!(document.myForm.MENUOPEN.checked)){
		if(document.getElementById){
			document.onmousemove = Mmove;
		} else if(document.layers){
			window.captureEvents(Event.MOUSEMOVE);
			window.onMouseMove = Mmove;
		} else if(document.all){
			document.onmousemove = Mmove;
		}
		document.allForm.MENUOPEN.value="";
	}else{
		document.allForm.MENUOPEN.value="on";
	}
}

//-->
</SCRIPT>
<DIV ID="menu" style="position:absolute; visibility:hidden;">
<TABLE BORDER=0 BGCOLOR=#e0ffff>
<TR><TD NOWRAP>
$click_com<hr>
$click_com2<HR>
<a href="Javascript:void(0);" onClick="menuclose()" STYlE="text-decoration:none">메뉴를 닫기</A>
</TD></TR>
</TABLE>
</DIV>
END

 islandInfo();

 out(<<END);
<CENTER>
<TABLE BORDER>
<TR valign=top>
<TD $HbgInputCell width=25%>
<CENTER>
<FORM name="myForm" action="$HthisFile" method=POST>
<P>
<B> 명령 입력</B><BR><B>
<A HREF=JavaScript:void(0); onClick="cominput(myForm,1)">삽입</A>
 <A HREF=JavaScript:void(0); onClick="cominput(myForm,2)">덮어쓰기</A>
 <A HREF=JavaScript:void(0); onClick="cominput(myForm,3);return false;">삭제</A>
</B><HR>
<B>계획번호</B><SELECT NAME=NUMBER>
END
 # 계획번호
 my($j, $i);
 for($i = 0; $i < $HcommandMax; $i++) {
	$j = $i + 1;
	out("<OPTION VALUE=$i>$j\n");
 }

 if ($HmenuOpen eq 'on') {
		$open = "CHECKED";
	}else{
		$open = "";
	}

 out(<<END);
</SELECT><BR>
<HR>
<B>개발계획</B>
<INPUT TYPE="checkbox" NAME="MENUOPEN"onClick="check_menu()" $open>비 표시<br>
<SELECT NAME=menu onchange="SelectList(myForm)">
<OPTION VALUE=>전체종류
END
	for($i = 0; $i < $com_count; $i++) {
		($aa) = split(/,/,$HcommandDivido[$i]);
		out("<OPTION VALUE=$i>$aa\n");
	}
 out(<<END);
</SELECT><br>
<SELECT NAME=COMMAND>
<option> </option>
<option> </option>
<option> </option>
<option> </option>
<option> </option>
<option> </option>
<option> </option>
<option> </option>
<option> </option>
<option> </option>
</SELECT>
<HR>
<B>좌표(</B>
<SELECT NAME=POINTX>

END
 for($i = 0; $i < $HislandSize; $i++) {
	if($i == $HdefaultX) {
	 out("<OPTION VALUE=$i SELECTED>$i\n");
 } else {
	 out("<OPTION VALUE=$i>$i\n");
 }
 }

 out(<<END);
</SELECT>, <SELECT NAME=POINTY>
END

 for($i = 0; $i < $HislandSize; $i++) {
	if($i == $HdefaultY) {
	 out("<OPTION VALUE=$i SELECTED>$i\n");
 } else {
	 out("<OPTION VALUE=$i>$i\n");
 }
 }
 out(<<END);
</SELECT><B>)</B>
<HR>
<B>수량</B><SELECT NAME=AMOUNT>
END

 # 수량
 for($i = 0; $i < 100; $i++) {
	out("<OPTION VALUE=$i>$i\n");
 }

 out(<<END);
</SELECT>
<HR>
<B>대상 섬</B>:
<B><A HREF=JavaScript:void(0); onClick="jump(myForm, '$HjavaMode')"> 표시 </A></B><BR>
<SELECT NAME=TARGETID>
$HtargetList<BR>
</SELECT>
<HR>
<B> 명령 이동</B>:
<BIG>
<A HREF=JavaScript:void(0); onClick="cominput(myForm,4)" STYlE="text-decoration:none"> ▲ </A>..
<A HREF=JavaScript:void(0); onClick="cominput(myForm,5)" STYlE="text-decoration:none"> ▼ </A>
</BIG>
<HR>
<INPUT TYPE="hidden" NAME="COMARY" value="comary">
<INPUT TYPE="hidden" NAME="JAVAMODE" value="$HjavaMode">
<INPUT TYPE=submit VALUE="계획 전송" NAME=CommandJavaButton$Hislands[$HcurrentNumber]->{'id'}>
<br><font size=2>마지막에 <font color=red>계획 전송 버튼</font>을<br>누르는 것을 잊지 마세요.</font>
<HR>
<B> 비밀번호</B></BR>
<INPUT TYPE=password NAME=PASSWORD VALUE="$HdefaultPassword">
</CENTER>
<BR><nobr><center>미사일 발사상한 수[<b> $Hislands[$HcurrentNumber]->{'fire'} </b>]발</center></nobr>
</TD>
<TD $HbgMapCell><center>
<TEXTAREA NAME="COMSTATUS" cols="48" rows="2"></TEXTAREA>
</center>
END
 islandMapJava(1); # 섬 지도, 소유자 모드
 my $comment = $Hislands[$HcurrentNumber]->{'comment'};
 out(<<END);
</FORM>
</TD>
<TD $HbgCommandCell id="plan">
<FORM name="allForm" action="$HthisFile" method=POST>
<INPUT TYPE="hidden" NAME=PASSWORD VALUE="$HdefaultPassword">
<INPUT TYPE="hidden" NAME=MENUOPEN VALUE="allmenu">
<INPUT TYPE="hidden" NAME=NUMBER VALUE="allno">
<INPUT TYPE="hidden" NAME=POINTY VALUE="0">
<INPUT TYPE="hidden" NAME=POINTX VALUE="0"><br>
<INPUT TYPE="hidden" NAME=JAVAMODE value="$HjavaMode">
<CENTER><B>자동 입력</B><br>
<SELECT NAME=COMMAND>
END
 #명령
 my($kind, $cost, $s);
	my($m) = @HcommandDivido;
	my($aa,$dd,$ff) = split(/,/,$HcommandDivido[$m-1]);
 for($i = 0; $i < $HcommandTotal; $i++) {
	$kind = $HcomList[$i];
	$cost = $HcomCost[$kind];
	if($kind> $ff){
		if($cost == 0) {
	 	$cost = '무료'
		}
		if($kind == $HdefaultKind) {
	 	$s = 'SELECTED';
		} else {
	 	$s = '';
		}
		out("<OPTION VALUE=$kind $s>$HcomName[$kind]($cost)\n");
 	}
 }
 out(<<END);
</SELECT><br>
<INPUT TYPE="hidden" NAME="CommandButton$Hislands[$HcurrentNumber]->{'id'}">
<INPUT TYPE="button" onClick="SelectPOINT()" VALUE="자동 입력 계획 전송">
</CENTER>
<HR>
<ilayer name="PARENT_LINKMSG" width="100%" height="100%">
 <layer name="LINKMSG1" width="200"></layer>
 <span id="LINKMSG1"></span>
</ilayer>
<BR>
</FORM>
</TD>
</TR>
</TABLE>
</CENTER>
<HR>
<CENTER>
${HtagBig_}코멘트갱신${H_tagBig}<BR>
<FORM action="$HthisFile" method="POST">
코멘트<INPUT TYPE=text NAME=MESSAGE SIZE=80 VALUE="$comment"><BR>
비밀번호<INPUT TYPE=password NAME=PASSWORD VALUE="$HdefaultPassword">
<INPUT TYPE="hidden" NAME=JAVAMODE VALUE="$HjavaMode">
<INPUT TYPE=submit VALUE="코멘트갱신" NAME=MessageButton$Hislands[$HcurrentNumber]->{'id'}>
</FORM>
</CENTER>
END

}

#----------------------------------------------------------------------
# 로컬 게시판입력 양식 Java스크립트 mode 용
#----------------------------------------------------------------------
sub tempLbbsInputJava {
 out(<<END);
<CENTER>
<FORM action="$HthisFile" method="POST">
<TABLE BORDER>
<TR>
<TH>이름</TH>
<TH COLSPAN=2>내용</TH>
</TR>
<TR>
<TD><INPUT TYPE="text" SIZE=32 MAXLENGTH=32 NAME="LBBSNAME" VALUE="$HdefaultName"></TD>
<TD COLSPAN=2><INPUT TYPE="text" SIZE=80 NAME="LBBSMESSAGE"></TD>
</TR>
<TR>
<TH> 비밀번호</TH>
<TH COLSPAN=2>동작</TH>
</TR>
<TR>
<TD><INPUT TYPE=password SIZE=32 MAXLENGTH=32 NAME=PASSWORD VALUE="$HdefaultPassword"></TD>
<TD align=right>
<INPUT TYPE="submit" VALUE="등록" NAME="LbbsButtonOW$HcurrentID">
</TD>
<TD align=right>
번호
<SELECT NAME=NUMBER>
END
 # 발언번호
 my($j, $i);
 for($i = 0; $i < $HlbbsMax; $i++) {
	$j = $i + 1;
	out("<OPTION VALUE=$i>$j\n");
 }
 out(<<END);
</SELECT>
<INPUT TYPE="submit" VALUE="삭제" NAME="LbbsButtonDL$HcurrentID">
<INPUT TYPE="hidden" NAME=JAVAMODE VALUE="$HjavaMode">
</TD>
</TR>
</TABLE>
</FORM>
</CENTER>
END
}

#----------------------------------------------------------------------
# 명령 모드
#----------------------------------------------------------------------
sub commandJavaMain {
 # id에서 섬을 가져옴
 $HcurrentNumber = $HidToNumber{$HcurrentID};
 my($island) = $Hislands[$HcurrentNumber];
 $HcurrentName = $island->{'name'};

 # 비밀번호
 if(!checkPassword($island->{'password'},$HinputPassword)) {
	# password 오류
	unlock();
	tempWrongPassword();
	return;
 }

 # 모드에서 분기
 my($command) = $island->{'command'};
	for($i = 0; $i < $HcommandMax; $i++) {
		# 명령 등록
		$HcommandComary =~ s/([0-9]*) ([0-9]*) ([0-9]*) ([0-9]*) ([0-9]*) //;
	 if($1 == 0) {
			$1 = 41;
		}
		$command->[$i] = {
			'kind' => $1,
			'x' => $2,
			'y' => $3,
			'arg' => $4,
			'target' => $5
		};
	}
	tempCommandAdd();
	# 데이터 쓰기
 writeIslandsFile($HcurrentID);

 # owner mode 로
 ownerMain();
}

#----------------------------------------------------------------------
# 지도 표시
#----------------------------------------------------------------------
sub islandMapJava {
 my($mode) = @_;
 my($island);
 $island = $Hislands[$HcurrentNumber];

 # 지형, 지형 값을 가져옴
 my($land) = $island->{'land'};
 my($landValue) = $island->{'landValue'};
 my($l, $lv);

 out(<<END);
<CENTER><TABLE BORDER><TR><TD>
END
 # 명령 가져오기
 my($command) = $island->{'command'};
 my($com, @comStr, $i);
 if($HmainMode eq 'owner') {
	for($i = 0; $i < $HcommandMax; $i++) {
	 my($j) = $i + 1;
	 $com = $command->[$i];
	 if($com->{'kind'} < 21) {
		$comStr[$com->{'x'}][$com->{'y'}].=
		 " [${j}]$HcomName[$com->{'kind'}]";
	 }
	}
 }

 # 좌표(상)을 출력
 out("<IMG SRC=\"xbar.gif\" width=400 height=16><BR>");

 # 각 지형및 줄바꿈을 출력
 my($x, $y);
 for($y = 0; $y < $HislandSize; $y++) {
	# 짝 수행이면 번호 출력
 if(($y % 2) == 0) {
	 out("<IMG SRC=\"space${y}.gif\" width=16 height=32>");
	}

	# 각 지형을 출력
	for($x = 0; $x < $HislandSize; $x++) {
	 $l = $land->[$x][$y];
	 $lv = $landValue->[$x][$y];
	 landStringJava($l, $lv, $x, $y, $comStr[$x][$y], $mode);
	}

	# 홀 수행이면 번호 출력
 if(($y % 2) == 1) {
	 out("<IMG SRC=\"space${y}.gif\" width=16 height=32>");
	}

	# 줄바꿈을 출력
	out("<BR>");
 }
 out("</TD></TR></TABLE></CENTER>\n");
}

#----------------------------------------------------------------------
# MAP아이콘 표시
#----------------------------------------------------------------------
sub landStringJava {
 my($l, $lv, $x, $y, $comStr,$mode) = @_;
 my($point) = "($x,$y)";
 my($image, $alt);

 if($l == $HlandSea) {

	if($lv == 1) {
	 # 얕은 바다
	 $image = 'land14.gif';
	 $alt = '바다(얕은 바다)';
 } else {
 # 바다
	 $image = 'land0.gif';
	 $alt = '바다';
 }
 } elsif($l == $HlandWaste) {
	# 황무지
	if($lv == 1) {
	 $image = 'land13.gif'; # 착탄 지점
	 $alt = '황무지';
	} else {
	 $image = 'land1.gif';
	 $alt = '황무지';
	}
 } elsif($l == $HlandPlains) {
	# 평지
	$image = 'land2.gif';
	$alt = '평지';
 } elsif($l == $HlandForest) {
	# 숲
	if($mode == 0) {
	 # 관광객에게는 목장 수를 숨김
	 $image = 'land6.gif';
	 $alt = '숲';
	} else {
	 $image = 'land6.gif';
	 $alt = "숲(${lv}$HunitTree)";
	}
 } elsif($l == $HlandTown) {
	# 마을
	my($p, $n);
	if($lv < 30) {
	 $p = 3;
	 $n = '마을';
	} elsif($lv < 100) {
	 $p = 4;
	 $n = '마을';
	} else {
	 $p = 5;
	 $n = '도시';
	}

	$image = "land${p}.gif";
	$alt = "$n(${lv}$HunitPop)";
 } elsif($l == $HlandFarm) {
	# 농장
	$image = 'land7.gif';
	$alt = "농장(${lv}0${HunitPop}규모)";
 } elsif($l == $HlandFactory) {
	# 공장
	$image = 'land8.gif';
	$alt = "공장(${lv}0${HunitPop}규모)";
 } elsif($l == $HlandBase) {
	if($mode == 0) {
	 # 관광객의 경우 숲인 척
	 $image = 'land6.gif';
	 $alt = '숲';
	} else {
	 # 미사일 기지
	 my($level) = expToLevel($l, $lv);
	 $image = 'land9.gif';
	 $alt = "미사일 기지 (레벨 ${level}/경험치 $lv)";
	}
 } elsif($l == $HlandSbase) {
	# 해저 기지
	if($mode == 0) {
	 # 관광객의 경우 바다인 척
	 $image = 'land0.gif';
	 $alt = '바다';
	} else {
	 my($level) = expToLevel($l, $lv);
	 $image = 'land12.gif';
	 $alt = "해저 기지 (레벨 ${level}/경험치 $lv)";
	}
 } elsif($l == $HlandDefence) {
	if($mode == 0) { # 방위 시설을 숲에하지 않은 경우'#if'와 하다
	 # 관광객의 경우 숲인 척
	 $image = 'land6.gif';
	 $alt = '숲';
	} else { # 방위 시설을 숲에하지 않은 경우'#} else'와 하다
		# 방위 시설
		$image = 'land10.gif';
		$alt = '방위 시설';
	} # 방위 시설을 숲에하지 않은 경우'#}'와 하다
 } elsif($l == $HlandHaribote) {
	# 가짜 시설
	$image = 'land10.gif';
	if($mode == 0) {
	 # 관광객에게는 방위 시설처럼 표시
	 $alt = '방위 시설';
	} else {
	 $alt = '가짜 시설';
	}
 } elsif($l == $HlandOil) {
	# 해저 유전
	$image = 'land16.gif';
	$alt = '해저 유전';
 } elsif($l == $HlandMountain) {
	# 산
	my($str);
	$str = '';
	if($lv> 0) {
	 $image = 'land15.gif';
	 $alt = "산(채굴장${lv}0${HunitPop}규모)";
	} else {
	 $image = 'land11.gif';
	 $alt = '산';
	}
 } elsif($l == $HlandMonument) {
	# 기념비
	$image = $HmonumentImage[$lv];
	$alt = $HmonumentName[$lv];
 } elsif($l == $HlandMonster) {
	# 괴수
	my($kind, $name, $hp) = monsterSpec($lv);
	my($special) = $HmonsterSpecial[$kind];
	$image = $HmonsterImage[$kind];

	# 경화 중?
	if((($special == 3) && (($HislandTurn % 2) == 1)) ||
	 (($special == 4) && (($HislandTurn % 2) == 0))) {
	 # 경화 중
	 $image = $HmonsterImage2[$kind];
	}
	$alt = "괴수$name(체력${hp})";
 }

 out(qq#<A HREF="JavaScript:void(0);" onclick="ps($x,$y)" #);
 if($mode == 1 && $HmainMode ne 'landmap') {
 out(qq#onMouseOver="set_com($x, $y, '$point $alt');status = '$point $alt $comStr'; return true;" onMouseOut="not_com();status = '';">#);
 }elsif($HmainMode eq 'landmap') {
 out(qq#onMouseOver="status = '$point $alt $comStr'; return true;" onMouseOut="status = '';">#);
	}
 out("<IMG SRC=\"$image\" ALT=\"$point $alt $comStr\" TITLE=\"$point $alt $comStr\" width=32 height=32 BORDER=0></A>");
}

#----------------------------------------------------------------------
# 관광 모드
#----------------------------------------------------------------------
sub printIslandJava {
 # 개방
 unlock();

 # id에서 섬 번호를 가져옴
 $HcurrentNumber = $HidToNumber{$HcurrentID};
 $island = $Hislands[$HcurrentNumber];

 # 왠지그 섬이 없는 경우
 if($HcurrentNumber eq '') {
	tempProblem();
	return;
 }

 # 이름 가져오기
 $HcurrentName = $Hislands[$HcurrentNumber]->{'name'};

 #명령 목록 설정
	my($l_kind);
	$click_com = "";
	if($HjavaMode eq 'java'){
		$com_count = @HcommandDivido;
		for($m = 0; $m < $com_count; $m++) {
			($aa,$dd,$ff) = split(/,/,$HcommandDivido[$m]);
	 	for($i = 0; $i < $HcommandTotal; $i++) {
				$l_kind = $HcomList[$i];
				$l_cost = $HcomCost[$l_kind];
				if($l_cost == 0) { $l_cost = '무료'	}
				else { $l_cost.= $HunitMoney; }
				if($l_kind> $dd-1 && $l_kind < $ff+1) {
					if($m == 2){
						$click_com.= "<a href='javascript:void(0);' onClick='window.opener.cominput(window.opener.document.myForm,6,$l_kind)' STYlE='text-decoration:none'>$HcomName[$l_kind]($l_cost)</a><br>\n";
					}
				}
				if($l_kind < $ff+1) { next; }
				elsif($m> 2){ last; }
			}
		}
	}

out(<<END);
<SCRIPT Language="JavaScript">
<!--
if(document.getElementById){
	document.onmousemove = Mmove;
} else if(document.layers){
	window.captureEvents(Event.MOUSEMOVE);
	window.onMouseMove = Mmove;
} else if(document.all){
	document.onmousemove = Mmove;
}

if((document.layers) || (document.all)){ // IE4,IE5,NN4
	window.document.onmouseup = menuclose;
}

function ps(x, y) {
	var java = '$HjavaMode';
	window.opener.document.myForm.POINTX.options[x].selected = true;
	window.opener.document.myForm.POINTY.options[y].selected = true;
	if(java == 'java')moveLAYER("menu",mx,my);
	return true;
}

function moveLAYER(layName,x,y){
	if(document.getElementById){		//NN6,IE5
		if(document.all){				//IE5
			el = document.getElementById(layName);
			el.style.left= event.clientX + document.body.scrollLeft + 10;
			el.style.top= event.clientY + document.body.scrollTop - 30;
			el.style.display = "block";
			el.style.visibility ='visible';
		}else{
			el = document.getElementById(layName);
			el.style.left=x+10;
			el.style.top=y-30;
			el.style.display = "block";
			el.style.visibility ='visible';
		}
	} else if(document.layers){				//NN4
		msgLay = document.layers[layName];
		msgLay.moveTo(x+10,y-30);
		msgLay.visibility = "show";
	} else if(document.all){				//IE4
		msgLay = document.all(layName);
		msgLay.style.pixelLeft = x+10;
		msgLay.style.pixelTop = y-30;
		msgLay.style.display = "block";
		msgLay.style.visibility = "visible";
	}

}

function menuclose(){
	if (document.getElementById){
		document.getElementById("menu").style.display = "none";
	} else if (document.layers){
		document.menu.visibility = "hide";
	} else if (document.all){
		window["menu"].style.display = "none";
	}
}

function Mmove(e){
	if(document.all){
		mx = event.x;
		my = event.y;
	}else if(document.layers){
		mx = e.pageX;
		my = e.pageY;
	}else if(document.getElementById){
		mx = e.pageX;
		my = e.pageY;
	}
}
//-->
</SCRIPT>
<center>$HcurrentName 섬<p>
공격할 지점을 클릭해 주세요.<br>클릭한 지점이 개발 화면의 좌표로 설정됩니다.
</center>
<DIV ID="menu" style="position:absolute; visibility:hidden;">
<TABLE BORDER=0 BGCOLOR=#e0ffff>
<TR><TD NOWRAP>
$click_com<HR>
<a href="Javascript:void(0);" onClick="menuclose()" STYlE="text-decoration:none">메뉴를 닫기</A>
</TD></TR>
</TABLE>
</DIV>
END
 if($island->{'password'} eq encode($HdefaultPassword) && $island->{'id'} eq $defaultID) {
 	islandMapJava(1); # 섬 지도, 관광 모드
 	landStringFlash(1); # 의사MAP데이터 표시
 }else{
	 islandMapJava(0); # 섬 지도, 관광 모드
 	landStringFlash(0); # 의사MAP데이터 표시
	}

 # ○○섬 로컬 게시판
 if($HuseLbbs) {
	#tempLbbsContents(); # 게시판내용
	#길어지므로 표시하지 않음. 표시하는 경우,#tempLbbs.. 의#을 제거.
 }

 # 최근 상황
 tempRecent(0);
 out(<<END);
<HR></BODY></HTML>
END
}

#----------------------------------------------------------------------
# 의사MAP데이터 생성
#----------------------------------------------------------------------
sub landStringFlash {
 my($mode) = @_;
 my($island);
 $island = $Hislands[$HcurrentNumber];
 my($land) = $island->{'land'};
 my($landValue) = $island->{'landValue'};
 my($l, $lv);
 my($code) = "";
 my($befor) = "a";
	my($Count) = 0;
	my($Comp) = "";
	my($ret) = "";

 # 각 지형을 출력
 my($x, $y);
 for($y = 0; $y < $HislandSize; $y++) {

	# 각 지형을 출력
	for($x = 0; $x < $HislandSize; $x++) {
	 $l = $land->[$x][$y];
	 $lv = $landValue->[$x][$y];
	 $code = landFlashData($l, $lv, $mode);

		if ($code eq $befor) {
			$Count++;
		} else {
			$Comp.= $befor;
			if( $Count != 0){
				$Comp.= ($Count - 1);
			}
			$Count = 0;
			$befor = $code;
		}
	}
 	}
	if($befor ne "a"){
		$Comp.= $befor;
		if( $Count != 0){
			$Comp += ($Count - 1);
		}
	}
	$Comp.= "\@";
	$Comp = substr($Comp,1);

 # 각 지형을 출력
	my($Compjs) = "";
	for($x = 0; $x < $HislandSize; $x++) {

	# 각 지형을 출력
 for($y = 0; $y < $HislandSize; $y++) {
	 $l = $land->[$x][$y];
	 $lv = $landValue->[$x][$y];
	 $code = landFlashData($l, $lv, $mode);
		$Compjs.= $code;
	}
 	}

 out(<<END);
<CENTER><FORM>
의사MAP작성도구용 데이터(FLASH 판)<BR>
<TEXTAREA NAME="FLASH" cols="50" rows="3">$Comp</TEXTAREA><br>
<A HREF="http://www.din.or.jp/~mkudo/hako/flash/hako-map.html" target="_blank">
의사MAP작성도구(FLASH 판)을 온라인으로 시작</a><P>
의사MAP작성도구용 데이터(JavaScript판)<BR>
<TEXTAREA NAME="FLASH" cols="50" rows="4">$Compjs</TEXTAREA><br>
<A HREF="http://www.din.or.jp/~mkudo/hako/javascript/map.html" target="_blank">
의사MAP작성도구(JavaScript판)을 온라인으로 시작</a><BR><BR><BR>
<A HREF="http://www.din.or.jp/~mkudo/hako/" target="_blank">
의사MAP작성도구(JAVA·FLASH 판)을 다운로드하기</a><p>
</FORM>
</CENTER>
END

}

sub landFlashData {
 my($l, $lv, $mode) = @_;
 my($flash_data);

 if($l == $HlandSea) {
	 # 얕은 바다
		if($lv == 1) {
			$flash_data = "o";
 } else {
 # 바다
			$flash_data = "a";
 }
 } elsif($l == $HlandWaste) {
		# 황무지
		if($lv == 1) {
	 	# 착탄 지점
			$flash_data = "n";
		} else {
			$flash_data = "b";
		}
 } elsif($l == $HlandPlains) {
		# 평지
		$flash_data = "c";
 } elsif($l == $HlandForest) {
		# 숲
		$flash_data = "g";
 } elsif($l == $HlandTown) {
		if($lv < 30) {
	 	# 마을
			$flash_data = "d";
		} elsif($lv < 100) {
	 	# 마을
			$flash_data = "e";
		} else {
	 	# 도시
			$flash_data = "f";
		}
 } elsif($l == $HlandFarm) {
		# 농장
		$flash_data = "h";
 } elsif($l == $HlandFactory) {
		# 공장
		$flash_data = "i";
 } elsif($l == $HlandBase) {
	 # 자신의 섬은 미사일 기지가 됨
		if($mode == 1) {
			$flash_data = "j";
	 # 자신의 섬이외는 미사일 기지는 숲이 됨
		} else {
			$flash_data = "g";
		}
 } elsif($l == $HlandDefence) {
	 # 자신의 섬은 방위 시설이 됨
		if($mode == 1) {
			$flash_data = "k";
	 # 자신의 섬이외는 방위 시설은 숲이 됨(숲에위장하지 않은 경우'k'와 하다)
		} else {
			$flash_data = "g";
		}
 } elsif($l == $HlandHaribote) {
		# 가짜 시설
		$flash_data = "k";
 } elsif($l == $HlandOil) {
		# 해저 유전
		$flash_data = "q";
 } elsif($l == $HlandMountain) {
		# 산
		if($lv> 0) {
			$flash_data = "p"; # 채굴장
		} else {
			$flash_data = "l";
		}
 #} elsif($l == $HlandMonument) {
		# 기념비
		# $flash_data = "b";
 } else {
		# 기타
		$flash_data = "b";
 }
	return $flash_data;
}

# 헤더
sub tempHeaderJava {
 my($bbs, $toppage,$imageDir) = @_;
 out(<<END);
Content-type: text/html; charset=UTF-8

<HTML>
<HEAD>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
<TITLE>
$Htitle
</TITLE>
<BASE HREF="$imageDir/">
</HEAD>
$Body
<A HREF="http://t.pos.to/hako/" target="_blank">모형정원 제도 스크립트 배포처</A>/
<A HREF="http://appoh.execweb.cx/hakoniwa/" target="_blank">모형정원 JavaScript판 배포처</A>/
<A HREF="http://www.din.or.jp/~mkudo/hako/" target="_blank">지도 작성 도구 배포처</A>/ <br>
<A HREF="$bbs">게시판</A>/
<A HREF="$toppage">톱 페이지</A>/<HR>
END
}

1;


