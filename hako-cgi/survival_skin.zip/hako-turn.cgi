#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}
#----------------------------------------------------------------------
# 모형정원 제도 ver2.30
# 턴진행모듈(ver1.02)
# 사용 조건과 사용 방법은 hako-readme.txt 파일을 참조해 주세요
#
# 모형정원 제도의 페이지: http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html
#----------------------------------------------------------------------


#주변 2헥스의 좌표
my(@ax) = (0, 1, 1, 1, 0,-1, 0, 1, 2, 2, 2, 1, 0,-1,-1,-2,-1,-1, 0);
my(@ay) = (0,-1, 0, 1, 1, 0,-1,-2,-1, 0, 1, 2, 2, 2, 1, 0,-1,-2,-2);

#----------------------------------------------------------------------
# 섬 신규 생성 모드
#----------------------------------------------------------------------
# 메인
sub newIslandMain {
 # 섬이 가득 차서 없습니까 확인
 if($HislandNumber>= $HmaxIsland) {
	unlock();
	tempNewIslandFull();
	return;
 }

 # 이름이 있는 지 확인
 if($HcurrentName eq '') {
	unlock();
	tempNewIslandNoName();
	return;
 }

 # 이름이 유효한지 확인
 if(($HcurrentName =~ /[,\?\(\)\<\>\$]|^무인$/)||($HcurrentName =~ /[,\?\(\)\<\>\$]|^어딘가의$/)) {
	# 사용 불가 이름
	unlock();
	tempNewIslandBadName();
	return;
 }

 # 이름의 중복 확인
 if(nameToNumber($HcurrentName) != -1) {
	# 이미 발견완료
	unlock();
	tempNewIslandAlready();
	return;
 }

 # password 의존재판정
 if($HinputPassword eq '') {
	# password 무시
	unlock();
	tempNewIslandNoPassword();
	return;
 }

 # 확인용 비밀번호
 if($HinputPassword2 ne $HinputPassword) {
	# password 오류
	unlock();
	tempWrongPassword();
	return;
 }

 # 새 섬의 번호 정하기
 $HcurrentNumber = $HislandNumber;
 $HislandNumber++;
 $Hislands[$HcurrentNumber] = makeNewIsland();
 my($island) = $Hislands[$HcurrentNumber];

 # 각종의 값을 설정
 $island->{'name'} = $HcurrentName;
 $island->{'id'} = $HislandNextID;
 $HislandNextID ++;
 $island->{'absent'} = $HgiveupTurn - 3;
 $island->{'comment'} = '(미 등록)';
 $island->{'password'} = encode($HinputPassword);
 $island->{'pond'} = 0;
 $island->{'MOUT'} = 0;
 $island->{'totalMOUT'} = 0;
 $island->{'MIN'} = 0;
 $island->{'nowNB'} = 0;
 $island->{'getNB'} = 0;
 $island->{'ownername'} = htmlEscape($HcurrentOwnerName); # 소유자 이름

 # 인구기타 산출
 estimate($HcurrentNumber);

 # 데이터 쓰기
 writeIslandsFile($island->{'id'});
 logDiscover($HcurrentName); # 로그

 # IP 등기록
 $island->{'ip'} = $ENV{'REMOTE_ADDR'};
 writeIP($island->{'id'}, $HcurrentName,$island->{'ip'});

 # 개방
 unlock();

 # 발견 화면
 tempNewIslandHead($HcurrentName); # 발견했습니다!!
 islandInfo(); # 섬의 정보
 islandMap(1); # 섬 지도, 소유자 모드
}

# 새 섬 만들기
sub makeNewIsland {
 # 지형을 만들기
 my($land, $landValue) = makeNewLand();

 # 초기 명령을 생성
 my(@command, $i);
 for($i = 0; $i < $HcommandMax; $i++) {
	 $command[$i] = {
	 'kind' => $HcomDoNothing,
	 'target' => 0,
	 'x' => 0,
	 'y' => 0,
	 'arg' => 0
	 };
 }

 # 초기 게시판 생성
 my(@lbbs);
 for($i = 0; $i < $HlbbsMax; $i++) {
	 $lbbs[$i] = "0>>";
 }

 # 섬으로 반환
 return {
	'land' => $land,
	'landValue' => $landValue,
	'command' => \@command,
	'lbbs' => \@lbbs,
	'money' => $HinitialMoney,
	'food' => $HinitialFood,
	'prize' => '0,0,',
 };
}

# 새 섬 지형 만들기
sub makeNewLand {
 # 기본형 생성
 my(@land, @landValue, $x, $y, $i);

 # 바다에 초기화
 for($y = 0; $y < $HislandSize; $y++) {
	 for($x = 0; $x < $HislandSize; $x++) {
	 $land[$x][$y] = $HlandSea;
	 $landValue[$x][$y] = 0;
	 }
 }

 # 중앙의4*4에평지를 배치
 my($center) = $HislandSize / 2 - 1;
 for($y = $center - 1; $y < $center + 3; $y++) {
	 for($x = $center - 1; $x < $center + 3; $x++) {
	 $land[$x][$y] = $HlandPlains;
	 }
 }

 my($count);

 # 평지를 만들기
 $count = 0;
 while($count < 16) {
	 # 무작위좌표
	 $x = random(8) + $center - 3;
	 $y = random(8) + $center - 3;

	 # 그곳이 바다에서 또한주변에육이 있다면, 평지를 만들기
	 if(($land[$x][$y] == $HlandSea)&&
	 (countAround(\@land, $x, $y, $HlandSea, 7) != 7)) {
	 $land[$x][$y] = $HlandPlains;
	 $count++;
	 }
 }

 # 얕은 바다를 만들기
 $count = 0;
 while($count < 16) {
	 # 무작위좌표
	 $x = random(8) + $center - 3;
	 $y = random(8) + $center - 3;

	 # 그곳이 바다에서 또한주변에육이 있다면, 얕은 바다를 만들기
	 if(($land[$x][$y] == $HlandSea)&&
 ($landValue[$x][$y] == 0)&&
 (countAround(\@land, $x, $y, $HlandSea, 7) != 7)) {
	 $landValue[$x][$y] = 1;
	 $count++;
	 }
 }

 # 황무지를 만들기
 $count = 0;
 while($count < 8) {
	 # 무작위좌표
	 $x = random(8) + $center - 3;
	 $y = random(8) + $center - 3;

	 # 그곳이이미평지라면, 황무지를 만들기
	 if($land[$x][$y] == $HlandPlains) {
	 $land[$x][$y] = $HlandWaste;
	 $count++;
	 }
 }

 # 숲을 만들기
 $count = 0;
 while($count < 4) {
	 # 무작위좌표
	 $x = random(7) + $center - 3;
	 $y = random(7) + $center - 3;

	 # 그곳이이미 숲에서 없이또한평지라면, 숲을 만들기
	 if(($land[$x][$y] != $HlandForest)&&($land[$x][$y] == $HlandPlains)) {
	 $land[$x][$y] = $HlandForest;
	 $landValue[$x][$y] = 10; # 처음은1000본
	 $count++;
	 }
 }

 # 마을을 만들기
 $count = 0;
 while($count < 10) {
	 # 무작위좌표
	 $x = random(7) + $center - 3;
	 $y = random(7) + $center - 3;

	 # 그곳이 숲이나 도시가 아니며 평지라면 마을을 만들기
	 if(($land[$x][$y] != $HlandTown) &&
	 ($land[$x][$y] != $HlandForest)&&
	 ($land[$x][$y] == $HlandPlains)) {
	 $land[$x][$y] = $HlandTown;
	 $landValue[$x][$y] = 100; # 처음에서10000인
	 $count++;
	 }
 }

# # 산을 만들기
# $count = 0;
# while($count < 1) {
#	 # 무작위좌표
#	 $x = random(5) + $center - 1;
#	 $y = random(5) + $center - 1;
#
#	 # 그곳이 숲이나 도시가 아니며 평지라면 산을 만들기
#	 if(($land[$x][$y] != $HlandTown) &&
#	 ($land[$x][$y] != $HlandForest)&&
#	 ($land[$x][$y] == $HlandPlains)) {
#	 $land[$x][$y] = $HlandMountain;
#	 $landValue[$x][$y] = 0; # 처음은 채굴장없음
#	 $count++;
#	 }
# }

# # 기지를 만들기
# $count = 0;
# while($count < 1) {
#	 # 무작위좌표
#	 $x = random(5) + $center - 1;
#	 $y = random(5) + $center - 1;
#
#	 # 그곳이 숲·도시·산이 아니며 평지라면 기지
#	 if(($land[$x][$y] != $HlandTown) &&
#	 ($land[$x][$y] != $HlandForest) &&
#	 ($land[$x][$y] != $HlandMountain)&&
# ($land[$x][$y] == $HlandPlains)) {
#	 $land[$x][$y] = $HlandBase;
#	 $landValue[$x][$y] = 0;
#	 $count++;
#	 }
# }

 return (\@land, \@landValue);
}

#----------------------------------------------------------------------
# 정보 변경 모드
#----------------------------------------------------------------------
# 메인
sub changeMain {
 # id에서 섬을 가져옴
 $HcurrentNumber = $HidToNumber{$HcurrentID};
 my($island) = $Hislands[$HcurrentNumber];
 my($flag) = 0;

 # 비밀번호 확인
 if($HoldPassword eq $HspecialPassword) {
	# 특수 비밀번호
	if($HcurrentName =~ /^무인$/) {
	 # 섬 삭제 모드
	 deleteIsland();
	 unlock();
	 tempDeleteIsland($island->{'name'});
	 return;
	} elsif($HcurrentName =~ /^로그$/) {
	 # 최근 사건강제출력
		logPrintHtml();
		unlock();
 	tempChange();
	 return;
	}else {
	 # 식량/자금 max 모드
		$island->{'money'} = 9999;
		$island->{'food'} = 0;
	}
 } elsif(!checkPassword($island->{'password'},$HoldPassword)) {
	# password 오류
	unlock();
	tempWrongPassword();
	return;
 }

 # 확인용 비밀번호
 if($HinputPassword2 ne $HinputPassword) {
	# password 오류
	unlock();
	tempWrongPassword();
	return;
 }

 if($HcurrentName ne '') {
	# 이름 변경의 경우
	# 이름이 유효한지 확인
	if(($HcurrentName =~ /[,\?\(\)\<\>]|^무인$/)||($HcurrentName =~ /[,\?\(\)\<\>]|^어딘가의$/)) {
	 # 사용 불가 이름
	 unlock();
	 tempNewIslandBadName();
	 return;
	}

	# 이름의 중복 확인
	if(nameToNumber($HcurrentName) != -1) {
	 # 이미 발견완료
	 unlock();
	 tempNewIslandAlready();
	 return;
	}

	if($island->{'money'} < $HcostChangeName) {
	 # 자금 부족
	 unlock();
	 tempChangeNoMoney();
	 return;
	}

	# 대금
	if($HoldPassword ne $HspecialPassword) {
	 $island->{'money'} -= $HcostChangeName;
	}

	# 이름을 변경
	logChangeName($island->{'name'}, $HcurrentName);
	$island->{'name'} = $HcurrentName;
	$flag = 1;
 }

 # password 변경의 경우
 if($HinputPassword ne '') {
	# 비밀번호를 변경
	$island->{'password'} = encode($HinputPassword);
	$flag = 1;
 }

 if(($flag == 0) && ($HoldPassword ne $HspecialPassword)) {
	# 어느 쪽도 변경되어 있지 않음
	unlock();
	tempChangeNothing();
	return;
 }

 # 데이터 쓰기
 writeIslandsFile($HcurrentID);
 unlock();

 # 변경성공
 tempChange();
}

sub changeOwner {

 # id에서 섬을 가져옴
 $HcurrentNumber = $HidToNumber{$HcurrentID};
 my($island) = $Hislands[$HcurrentNumber];
 my($flag) = 0;

 if(!checkPassword($island->{'password'},$HoldPassword)) {
	# password 오류
	unlock();
	tempWrongPassword();
	return;
 }
 # 소유자 이름을 변경
 $island->{'ownername'} = htmlEscape($HcurrentOwnerName);
 $flag = 1;

 # 데이터 쓰기
 writeIslandsOwner($HcurrentID);
 unlock();

 # 변경성공
 tempChange();
}

# 섬의 강제 삭제
sub deleteIsland {
 my($island) = $Hislands[$HidToNumber{$HcurrentID}];

 # 섬 테이블 조작

 $island->{'pop'} = 0;
 islandSort();

 logDeleteIsland($tmpid, $island->{'name'});

 # 메인 데이터의 조작
 $HislandNumber -= 1;
 writeIslandsFile($HcurrentID);
 unlink("island.$HcurrentID");
}

#----------------------------------------------------------------------
# 턴진행 모드
#----------------------------------------------------------------------
# 메인
sub turnMain {
 my($noDisFlag) = 0; # 재해는 발생하지 않음플래그

 # unitCount 회 턴을 진행하다까지 시간을 족사없음
 if ($HislandTurn % $HunitCount == ($HunitCount-1)) {
	# 최종 갱신 시간을 갱신
	$HislandLastTime += $HunitTime;
 } else {
	# 무재해
	$noDisFlag = 1;
 }

 if ($noDisFlag) {
	# 마지막의 턴이외는 재해는 발생하지 않음
	$HdisEarthquake = 0; # 지진
	$HdisTsunami = 0; # 쓰나미
	$HdisTyphoon = 0; # 태풍
	$HdisMeteo = 0; # 운석
	$HdisHugeMeteo = 0; # 거대운석
	$HdisEruption = 0; # 분화
	$HdisFire = 0; # 화재
	$HdisMaizo = 0; # 매장금
	$HdisFalldown = 0; # 지반 침하
	$HdisMonster = 0; # 괴수
	$HoilRatio = 0; # 유전 고갈
 }

 if ($HunitCount < 0 || $HislandTurn % $HunitCount == 0){
	my($i);
	# 각 섬의 M피격 수를 재설정
	for($i=0; $i < $HislandNumber; $i++){
	 $Hislands[$i]->{'MIN'}=0;
	 $Hislands[$i]->{'MOUT'}=0;
	}
 }

 # 로그 파일을 뒤에밀기
 my($i, $j, $s, $d);
 for($i = ($HlogMax - 1); $i>= 0; $i--) {
	$j = $i + 1;
	my($s) = "${HdirName}/hakojima.log$i";
	my($d) = "${HdirName}/hakojima.log$j";
	unlink($d);
	rename($s, $d);
 }

 # 좌표배열을 만들기
 makeRandomPointArray();

 # 턴번호
 $HislandTurn++;

 # 순서결메
 my(@order) = randomArray($HislandNumber);

 # 수입, 소비단계
 for($i = 0; $i < $HislandNumber; $i++) {
	estimate($order[$i]);
	income($Hislands[$order[$i]]);

	# 턴시작전의 인구를 메모루
	$Hislands[$order[$i]]->{'oldPop'} = $Hislands[$order[$i]]->{'pop'};
 }

 # 명령 처리
 for($i = 0; $i < $HislandNumber; $i++) {
	# 반환 값1이 이 될 시까지 반복
	while(doCommand($Hislands[$order[$i]]) == 0){};
 }

 # 성장 및 단일 헥스 재해
 for($i = 0; $i < $HislandNumber; $i++) {
	doEachHex($Hislands[$order[$i]]);
 }

 # 섬 전체 처리
 my($remainNumber) = $HislandNumber;
 my($island);
 for($i = 0; $i < $HislandNumber; $i++) {
	$island = $Hislands[$order[$i]];
	doIslandProcess($order[$i], $island);

	# 사멸판정
	if($island->{'dead'} == 1) {
	 $island->{'pop'} = 0;
	 $remainNumber--;
	} elsif($island->{'pop'} == 0) {
	 $island->{'dead'} = 1;
	 $remainNumber--;
	 # 사멸 메시지
	 my($tmpid) = $island->{'id'};
	 logDead($tmpid, $island->{'name'});
	 unlink("island.$tmpid");
	}
 }

 # 섬 수자르기
 $HislandNumber = $remainNumber;

 if($HislandTurn> $HarmisticeTurn){

	# 인구÷(전체 섬의 인구의 합계÷100)이(100÷섬 수)÷2보다 적을 시, 그 섬은 소멸

	my($allpop, $i);
	for($i=0; $i < $HislandNumber; $i++){
	 $allpop += $Hislands[$i]->{'pop'};
	}
#	$allpop = int($allpop/100);

	for($i=0; $i < $HislandNumber; $i++){
	 my($island) = $Hislands[$i];

 if((int(($island->{'pop'}*100)/$allpop))<(int(50/$HislandNumber))){

		if($HislandNumber> 1){
		 $island->{'dead'} = 1;
		 $remainNumber--;
		 # 사멸 메시지
		 my($tmpid) = $island->{'id'};
		 logTDead($tmpid, $island->{'name'});
		 unlink("island.$tmpid");
	 }

	 }
 }
 }

 # 인구순에정렬
 islandSort();

 # 섬 수자르기
 $HislandNumber = $remainNumber;

 # 최하위 탈락 시의 턴이면 처리
 if( (($HislandTurn % $HturnDead) == 0) && ($HislandTurn> $HarmisticeTurn) ) {
 if($HislandNumber> 1){

	 my($island) = $Hislands[$HislandNumber-1];
	 $island->{'dead'} = 1;
	 $remainNumber--;

	 # 사멸 메시지
	 my($tmpid) = $island->{'id'};
	 logTDead($tmpid, $island->{'name'});
	 unlink("island.$tmpid");

 }
 }

 # 섬 수자르기
 $HislandNumber = $remainNumber;

 # 시상 대상 턴이면, 그 처리
 if(($HislandTurn % $HturnPrizeUnit) == 0) {
	my($island) = $Hislands[0];
	logPrize($island->{'id'}, $island->{'name'}, "$HislandTurn${Hprize[0]}");
	$island->{'prize'}.= "${HislandTurn},";
 }

 # 백업 턴이면 삭제 전에 rename
 if(($HislandTurn % $HbackupTurn) == 0) {
	my($i);
	my($tmp) = $HbackupTimes - 1;
	myrmtree("${HdirName}.bak$tmp");
	for($i = ($HbackupTimes - 1); $i> 0; $i--) {
	 my($j) = $i - 1;
	 rename("${HdirName}.bak$j", "${HdirName}.bak$i");
	}
	rename("${HdirName}", "${HdirName}.bak0");
	mkdir("${HdirName}", $HdirMode);

	# 로그 파일만 복구
	for($i = 0; $i <= $HlogMax; $i++) {
	 rename("${HdirName}.bak0/hakojima.log$i",
		 "${HdirName}/hakojima.log$i");
	}
	rename("${HdirName}.bak0/hakojima.his",
	 "${HdirName}/hakojima.his");
 }

 # 종료조건의 판정
 if($Hfinish == 0){ $Hfinish = 1; }
 if ($HislandNumber == $Hfinish) {
	$HislandLastTime += 2592000; # 다음갱신 시간을1케월선로
	for($i=0;$Hfinish> $i;$i++){
	 my($island) = $Hislands[$i];
	 $island->{'name'} = '[승자!]'. $island->{'name'};
	}
 }

 # 파일에쓰기
 writeIslandsFile(-1);

 # 로그 쓰기
 logFlush();

 # 기록 로그 조정
 logHistoryTrim();

	# 최근 사건HTML출력 ←이를 추가
 if ($HunitCount < 0 || $HislandTurn % $HunitCount == 0) {
	logPrintHtml();
	}

 # 맨 위로
 topPageMain();
}

# 디렉터리 삭제
sub myrmtree {
 my($dn) = @_;
 opendir(DIN, "$dn/");
 my($fileName);
 while($fileName = readdir(DIN)) {
	unlink("$dn/$fileName");
 }
 closedir(DIN);
 rmdir($dn);
}

# 수입, 소비단계
sub income {
 my($island) = @_;
 my($pop, $farm, $factory, $mountain,$pond) =
	(
	 $island->{'pop'},
	 $island->{'farm'} * 10,
	 $island->{'factory'},
	 $island->{'mountain'},
	 $island->{'pond'} * 5
	 );

 # 수입
 if($pop> $farm) {
	# 농업만으로 인력이 남는 경우
	$island->{'food'} += $farm; # 농장 전체가동
	$island->{'money'} +=
	 min(int(($pop - $farm) / 5),
		 ($factory + $mountain)*2);
 } else {
	# 농장 규모가 최대치인 경우
	$island->{'food'} += $pop; # 전체나 생 직원일
 }

 if($pond> 0) {
	# 연못이 있다면식량에가나쁨
	$island->{'food'} += $pond;
 }

 # 식량소비
 $island->{'food'} = int(($island->{'food'}) - ($pop * $HeatenFood));
}


# 명령 단계
sub doCommand {
 my($island) = @_;

 # 명령 처리 시작
 my($comArray, $command);
 $comArray = $island->{'command'};
 $command = $comArray->[0]; # 첫 항목을 꺼냄
 slideFront($comArray, 0); # 이후를 막힘하기

 # 각 요소 꺼내기
 my($kind, $target, $x, $y, $arg) =
	(
	 $command->{'kind'},
	 $command->{'target'},
	 $command->{'x'},
	 $command->{'y'},
	 $command->{'arg'}
	 );

 # 도출 값
 my($name) = $island->{'name'};
 my($id) = $island->{'id'};
 my($land) = $island->{'land'};
 my($landValue) = $island->{'landValue'};
 my($landKind) = $land->[$x][$y];
 my($lv) = $landValue->[$x][$y];
 my($cost) = $HcomCost[$kind];
 my($comName) = $HcomName[$kind];
 my($point) = "($x, $y)";
 my($landName) = landName($landKind, $lv);

 if($kind == $HcomDoNothing) {
	# 자금 조달
	logDoNothing($id, $name, $comName);
	$island->{'money'} += 100;
	$island->{'absent'} ++;
	$island->{'donothing'} = 1;

	# 자동포기
	if($island->{'absent'}>= $HgiveupTurn) {
	 $comArray->[0] = {
		'kind' => $HcomGiveup,
		'target' => 0,
		'x' => 0,
		'y' => 0,
		'arg' => 0
	 }
	}
	return 1;
 }

 $island->{'absent'} = 0;

 # 비용 확인
 if($cost> 0) {
	# 금의 경우
	if($island->{'money'} < $cost) {
	 logNoMoney($id, $name, $comName);
	 return 0;
	}
 } elsif($cost < 0) {
	# 식량의 경우
	if($island->{'food'} < (-$cost)) {
	 logNoFood($id, $name, $comName);
	 return 0;
	}
 }

 # 명령에서 분기
 if(($kind == $HcomPrepare) ||
 ($kind == $HcomPrepare2)) {
	# 개간, 땅고르기
	if(($landKind == $HlandSea) ||
	 ($landKind == $HlandSbase) ||
	 ($landKind == $HlandOil) ||
	 ($landKind == $HlandMountain) ||
	 ($landKind == $HlandMonster)) {
	 # 바다, 해저 기지, 유전, 산, 괴수는 개간할 수 없
	 logLandFail($id, $name, $comName, $landName, $point);
	 return 0;
	}

	# 대상 위치를 평지로
	$land->[$x][$y] = $HlandPlains;
	$landValue->[$x][$y] = 0;
	logLandSuc($id, $name, '개간', $point);

	# 돈을 차감
	$island->{'money'} -= $cost;

	if($kind == $HcomPrepare2) {
	 # 땅고르기
	 $island->{'prepare2'}++;

	 # 턴 소비하지 않고
	 return 0;
	} else {
	 # 땅고르기이면 매장금 발견 가능성 있음
	 if(random(1000) < $HdisMaizo) {
		my($v) = 100 + random(901);
		$island->{'money'} += $v;
		logMaizo($id, $name, $comName, $v);
	 }
	 return 1;
	}

 } elsif($kind == $HcomPrepare3) {
	# 일괄땅고르기
	my($i);
	for($i = 0; $i < $HpointNumber; $i++) {
	 $bx = $Hrpx[$i];
	 $by = $Hrpy[$i];
	 if(($land->[$bx][$by] == $HlandWaste) &&
	 ($island->{'money'}>= $HcomCost[$HcomPrepare2] )){
		# 대상 위치를 평지로
		$land->[$bx][$by] = $HlandPlains;
		$landValue->[$bx][$by] = 0;
		# 돈을 차감
		$island->{'money'} -= $HcomCost[$HcomPrepare2];
		# 땅고르기
#	 $island->{'prepare2'}++;
	 }
	}
	logAllPrepare($id, $name, $comName);
	return 0;

 } elsif($kind == $HcomReclaim) {
	# 매립
	if(($landKind != $HlandSea) &&
	 ($landKind != $HlandOil) &&
	 ($landKind != $HlandPlains) &&
	 ($landKind != $HlandWaste) &&
	 ($landKind != $HlandTown) &&
	 ($landKind != $HlandSbase)) {
	 # 바다, 해저 기지, 평지, 황무지, 마을 계열, 유전만매립할 수 없
	 logLandFail($id, $name, $comName, $landName, $point);
	 return 0;
	}

	# 주변에육이 있는 지 확인
	my($seaCount) =
	 countAround($land, $x, $y, $HlandSea, 7) +
	 countAround($land, $x, $y, $HlandOil, 7) +
 countAround($land, $x, $y, $HlandSbase, 7);

 if($seaCount == 7) {
	 # 전체 바다다에서 매립불능
	 logNoLandAround($id, $name, $comName, $point);
	 return 0;
	}

	if(($landKind == $HlandSea) && ($lv == 1)) {
	 # 얕은 바다의 경우
	 # 대상 위치를 황무지로
	 $land->[$x][$y] = $HlandWaste;
	 $landValue->[$x][$y] = 0;
	 logLandSuc($id, $name, $comName, $point);
	 $island->{'area'}++;

	 if($seaCount <= 4) {
		# 주변 바다가 3헥스 이내이므로, 얕은 바다로
		my($i, $sx, $sy);

		for($i = 1; $i < 7; $i++) {
		 $sx = $x + $ax[$i];
		 $sy = $y + $ay[$i];

		 # 행 기준 위치 조정
		 if((($sy % 2) == 0) && (($y % 2) == 1)) {
			$sx--;
		 }

		 if(($sx < 0) || ($sx>= $HislandSize) ||
		 ($sy < 0) || ($sy>= $HislandSize)) {
		 } else {
			# 범위 안의 경우
			if($land->[$sx][$sy] == $HlandSea) {
			 $landValue->[$sx][$sy] = 1;
			}
		 }
		}
	 }
	} elsif(($landKind == $HlandSea) && ($lv == 0)) {
	 # 바다이면 대상 위치를 얕은 바다로 변경
	 $land->[$x][$y] = $HlandSea;
	 $landValue->[$x][$y] = 1;
	 logLandSuc($id, $name, $comName, $point);
	} else {
	 # 그 외라면, 대상 위치를 산로
	 $land->[$x][$y] = $HlandMountain;
	 $landValue->[$x][$y] = 0;
	 logLandSuc($id, $name, $comName, $point);
	}

	# 돈을 차감
	$island->{'money'} -= $cost;

	if($HislandTurn <= $HarmisticeTurn){
	 return 1;
	} else {
	 return 0;
	}

 } elsif($kind == $HcomDestroy) {
	# 굴착
	if(($landKind == $HlandSea) ||
	 ($landKind == $HlandSbase) ||
	 ($landKind == $HlandOil) ||
	 ($landKind == $HlandMonster)) {
	 # 바다, 해저 기지, 유전, 괴수는 굴착할 수 없
	 logLandFail($id, $name, $comName, $landName, $point);

	if($HislandTurn <= $HarmisticeTurn){
	 return 1;
	} else {
	 return 0;
	}

	}

	if(($landKind == $HlandSea) && ($lv == 0)) {
	 # 바다이면 유전 탐사 시
	 # 투자액결정
	 if($arg == 0) { $arg = 1; }
	 my($value, $str, $p);
	 $value = min($arg * ($cost), $island->{'money'});
	 $str = "$value$HunitMoney";
	 $p = int($value / $cost);
	 $island->{'money'} -= $value;

	 # 보기사용는 가판정
	 if($p> random(100)) {
		# 유전보기사용루
		logOilFound($id, $name, $point, $comName, $str);
		$land->[$x][$y] = $HlandOil;
		$landValue->[$x][$y] = 0;
	 } else {
		# 헛발사치에끝나쁨
		logOilFail($id, $name, $point, $comName, $str);
	 }
	 return 1;
	}

	# 대상 위치를 바다로 변경. 산이면 황무지로, 얕은 바다이면 바다로 변경.
	if($landKind == $HlandMountain) {
	 $land->[$x][$y] = $HlandWaste;
	 $landValue->[$x][$y] = 0;
	} elsif($landKind == $HlandSea) {
	 $landValue->[$x][$y] = 0;
	} else {
	 $land->[$x][$y] = $HlandSea;
	 $landValue->[$x][$y] = 1;
	 $island->{'area'}--;
	}
	logLandSuc($id, $name, $comName, $point);

	# 돈을 차감
	$island->{'money'} -= $cost;

	if($HislandTurn <= $HarmisticeTurn){
	 return 1;
	} else {
	 return 0;
	}

 } elsif($kind == $HcomSellTree) {
	# 벌채
	if($landKind != $HlandForest) {
	 # 숲이외는 벌채할 수 없
	 logLandFail($id, $name, $comName, $landName, $point);
	 return 0;
	}

	# 대상 위치를 평지로
	$land->[$x][$y] = $HlandPlains;
	$landValue->[$x][$y] = 0;
	logLandSuc($id, $name, $comName, $point);

	# 매각금을 얻기루
	$island->{'money'} += $HtreeValue * $lv;
	return 0;
 } elsif(($kind == $HcomPlant) ||
	 ($kind == $HcomFarm) ||
	 ($kind == $HcomFactory) ||
	 ($kind == $HcomPond) ||
	 ($kind == $HcomBase) ||
	 ($kind == $HcomMonument) ||
	 ($kind == $HcomHaribote) ||
	 ($kind == $HcomDbase)) {

	# 지상건설계
	if(!
	 (($landKind == $HlandPlains) ||
	 ($landKind == $HlandTown) ||
	 (($landKind == $HlandMonument) && ($kind == $HcomMonument)) ||
	 (($landKind == $HlandFarm) && ($kind == $HcomFarm)) ||
	 (($landKind == $HlandFactory) && ($kind == $HcomFactory)) ||
	 (($landKind == $HlandPond) && ($kind == $HcomPond)) ||
	 (($landKind == $HlandDefence) && ($kind == $HcomDbase)))) {
	 # 부적절나 지형
	 logLandFail($id, $name, $comName, $landName, $point);
	 return 0;
	}

	# 종류에서 분기
	if($kind == $HcomPlant) {
	 # 대상 위치를 숲로.
	 $land->[$x][$y] = $HlandForest;
	 $landValue->[$x][$y] = 1; # 목은 최소단위
	 logPBSuc($id, $name, $comName, $point);
	} elsif($kind == $HcomBase) {
	 # 대상 위치를 미사일 기지로.
	 $land->[$x][$y] = $HlandBase;
	 $landValue->[$x][$y] = 0; # 경험치0
	 logPBSuc($id, $name, $comName, $point);
	} elsif($kind == $HcomHaribote) {
	 # 대상 위치를 가짜 시설로
	 $land->[$x][$y] = $HlandHaribote;
	 $landValue->[$x][$y] = 0;
	 logHariSuc($id, $name, $comName, $HcomName[$HcomDbase], $point);
	} elsif($kind == $HcomFarm) {
	 # 농장
	 if($landKind == $HlandFarm) {
		# 이미 농장의 경우
		$landValue->[$x][$y] += 10; # 규모 + 10,000인
		if($landValue->[$x][$y]> 50) {
		 $landValue->[$x][$y] = 50; # 최대 50,000인
		}
	 } else {
		# 대상 위치를 농장에
		$land->[$x][$y] = $HlandFarm;
		$landValue->[$x][$y] = 20; # 규모 = 20,000인
	 }
	 logPBSuc($id, $name, $comName, $point);
#	 logLandSuc($id, $name, $comName, $point);
	} elsif($kind == $HcomFactory) {
	 # 공장
	 if($landKind == $HlandFactory) {
		# 이미 공장의 경우
		$landValue->[$x][$y] += 10; # 규모 + 10,000인
		if($landValue->[$x][$y]> 100) {
		 $landValue->[$x][$y] = 100; # 최대 100,000인
		}
	 } else {
		# 대상 위치를 공장에
		$land->[$x][$y] = $HlandFactory;
		$landValue->[$x][$y] = 50; # 규모 = 50,000인
	 }
	 logPBSuc($id, $name, $comName, $point);
#	 logLandSuc($id, $name, $comName, $point);
	} elsif($kind == $HcomPond) {
	 # 수원
	 if($landKind == $HlandPond) {
		# 이미 수원의 경우
		$landValue->[$x][$y] += 10; # 규모 + 10,000리와 루
		if($landValue->[$x][$y]> 50) {
		 $landValue->[$x][$y] = 50; # 최대 50,000리와 루
		}
	 } else {
		# 대상 위치를 수원에
		$land->[$x][$y] = $HlandPond;
		$landValue->[$x][$y] = 20; # 규모 = 20,000리와 루
	 }
	 logPBSuc($id, $name, $comName, $point);
#	 logLandSuc($id, $name, $comName, $point);
	} elsif($kind == $HcomDbase) {
	 # 방위 시설
	 if($landKind == $HlandDefence) {
		# 이미 방위 시설인 경우
		$landValue->[$x][$y] = 1; # 자폭장치 설정
		logBombSet($id, $name, $landName, $point);
	 } else {
		# 대상 위치를 방위 시설에
		$land->[$x][$y] = $HlandDefence;
		$landValue->[$x][$y] = 0;
		if ($HdBaseHide) { # 방위 시설을 숲에위장하다?
		 logPBSuc($id, $name, $comName, $point);
		} else {
		 logLandSuc($id, $name, $comName, $point);
		}
	 }
	} elsif($kind == $HcomMonument) {
	 # 기념비
	 if($landKind == $HlandMonument) {
		# 이미 기념비인 경우

		if($HislandTurn <= $HarmisticeTurn){
		 # 공격이 허가되어 있지 않음
		 logNotAvail($id, $name, $comName);
		 return 0;
		}

		# 대상 가져오기
		my($tn) = $HidToNumber{$target};
		if($tn eq '') {
		 # 대상이 이미 없음
		 # 아무 메시지도 출력하지 않음
		 return 0;
		}
		my($tIsland) = $Hislands[$tn];
		$tIsland->{'bigmissile'}++;

		# 그장소는 황무지에
		$land->[$x][$y] = $HlandWaste;
		$landValue->[$x][$y] = 0;
		logMonFly($id, $name, $landName, $point);
	 } else {
		# 대상 위치를 기념비에
		$land->[$x][$y] = $HlandMonument;
		if($arg>= $HmonumentNumber) {
		 $arg = 0;
		}
		$landValue->[$x][$y] = $arg;
		logLandSuc($id, $name, $comName, $point);
	 }
	}

	# 돈을 차감
	$island->{'money'} -= $cost;

	# 횟수 지정이면, 명령을 되돌림
	if(($kind == $HcomFarm) ||
	 ($kind == $HcomFactory)) {
	 if($arg> 1) {
		my($command);
		$arg--;
		slideBack($comArray, 0);
		$comArray->[0] = {
		 'kind' => $kind,
		 'target' => $target,
		 'x' => $x,
		 'y' => $y,
		 'arg' => $arg
		 };
	 }
	}

	if($HislandTurn <= $HarmisticeTurn){
	 return 1;
	} else {
	 return 0;
	}

 } elsif($kind == $HcomMountain) {
	# 채굴장
	if($landKind != $HlandMountain) {
	 # 산이외에는 만들 수 없음
	 logLandFail($id, $name, $comName, $landName, $point);
	 return 0;
	}

	$landValue->[$x][$y] += 10; # 규모 + 10,000인
	if($landValue->[$x][$y]> 200) {
	 $landValue->[$x][$y] = 200; # 최대 200,000인
	}
	logLandSuc($id, $name, $comName, $point);

	# 돈을 차감
	$island->{'money'} -= $cost;
	if($arg> 1) {
	 my($command);
	 $arg--;
	 slideBack($comArray, 0);
	 $comArray->[0] = {
		'kind' => $kind,
		'target' => $target,
		'x' => $x,
		'y' => $y,
		'arg' => $arg
		};
	}

	if($HislandTurn <= $HarmisticeTurn){
	 return 1;
	} else {
	 return 0;
	}

 } elsif($kind == $HcomSbase) {
	# 해저 기지
	if(($landKind != $HlandSea) || ($lv != 0)){
	 # 바다이외에는 만들 수 없음
	 logLandFail($id, $name, $comName, $landName, $point);
	 return 0;
	}

	$land->[$x][$y] = $HlandSbase;
	$landValue->[$x][$y] = 0; # 경험치0
	logLandSuc($id, $name, $comName, '(?, ?)');

	# 돈을 차감
	$island->{'money'} -= $cost;

	if($HislandTurn <= $HarmisticeTurn){
	 return 1;
	} else {
	 return 0;
	}

 } elsif($kind == $HcomMissileNB){
	# 스나이파탄

	if($island->{'nowNB'} <= 0){
	 # 소유하지 않음
	 logNoNB($id, $name, $comName);
	 return 0;
	}

	if($HislandTurn <= $HarmisticeTurn){
	 # 공격이 허가되어 있지 않음
	 logNotAvail($id, $name, $comName);
	 return 0;
	}

	# 대상 가져오기
	my($tn) = $HidToNumber{$target};
	if($tn eq '') {
	 # 대상이 이미 없음
	 logMsNoTarget($id, $name, $comName);
	 return 0;
	}

	my($bx, $by, $count) = (0,0,0);
	# 기지를 찾을 시까지 반복
	while($count < $HpointNumber) {
	 $bx = $Hrpx[$count];
	 $by = $Hrpy[$count];
	 if(($land->[$bx][$by] == $HlandBase) ||
	 ($land->[$bx][$by] == $HlandSbase)) {
	 last;
	 }
	 $count++;
	}
	if($count>= $HpointNumber) {
	 # 찾을 수 없으면 그곳까지
	 logMsNoBase($id, $name, $comName);
	 return 0;
	}

	# 스나이파탄폭발균열

	# 사전준비
	my($tIsland) = $Hislands[$tn];
	my($tName) = $tIsland->{'name'};
	my($tLand) = $tIsland->{'land'};
	my($tLandValue) = $tIsland->{'landValue'};
	my($tx) = $x;
	my($ty) = $y;

	my($sx, $sy, $i, $tlandKind, $tlv, $point);
	$tlandKind = $tLand->[$tx][$ty];
	$tlv = $tLandValue->[$tx][$ty];
	$point = "($tx, $ty)";
	my($tLname) = landName($tlandKind, $tlv);

	if(($tlandKind == $HlandSea) ||
	 ($tlandKind == $HlandOil) ||
	 ($tlandKind == $HlandWaste)||
	 ($tlandKind == $HlandSbase)) {

		logNBfail($id, $target, $name, $tName, $comName, $tLname, $point);

	} else {

		logNB($id, $target, $name, $tName, $comName, $tLname, $point);
		$tLand->[$tx][$ty] = $HlandWaste;
		$tLandValue->[$tx][$ty] = 1;

	}

	# 금과 보유 수를 확인
	$island->{'money'} -= $cost;
	$island->{'nowNB'} -= 1;

	# 턴진행은 무시
	return 0;

 } elsif(($kind == $HcomMissileNM) ||
	 ($kind == $HcomMissilePP) ||
	 ($kind == $HcomMissileST) ||
	 ($kind == $HcomMissileRN) ||
	 ($kind == $HcomMissileLD)) {
	# 미사일계

	if($HislandTurn <= $HarmisticeTurn){
	 # 공격이 허가되어 있지 않음
	 logNotAvail($id, $name, $comName);
	 return 0;
	}

	# 대상 가져오기
	my($tn) = $HidToNumber{$target};

	if($kind == $HcomMissileRN){
	 # 무작위탄의 경우대상이직접없어짐까지무작위로대상선택하고
	 $tn = random($HislandNumber);
	 while($Hislands[$tn]->{'id'} == $island->{'id'}){
		$tn = random($HislandNumber);
	 }

	 $target = $Hislands[$tn]->{'id'};

	}

	if($tn eq '') {
	 # 대상이 이미 없음
	 logMsNoTarget($id, $name, $comName);
	 return 0;
	}

	my($flag) = 0;
	if($arg == 0) {
	 # 값이 0이면 공격 중인 대상만
	 $arg = 10000;
	}

	# 사전준비
	my($tIsland) = $Hislands[$tn];
	my($tName) = $tIsland->{'name'};
	my($tLand) = $tIsland->{'land'};
	my($tLandValue) = $tIsland->{'landValue'};
	my($tx, $ty, $err);

	# 난민의 수
	my($boat) = 0;

	# 오차
	if($kind == $HcomMissilePP) {
	 $err = 7;
	} else {
	 $err = 19;
	}

	# 자금이 부족하면 지정수량을 충족하거나 전체 기지 가격에 도달할 시까지 반복
	my($mCount, $nCount) = (0,0);
	my($bx, $by, $count) = (0,0,0);
	while(($arg> 0) &&
	 ($island->{'money'}>= $cost)) {
	 # 기지를 찾을 시까지 반복
	 while($count < $HpointNumber) {
		$bx = $Hrpx[$count];
		$by = $Hrpy[$count];
		if(($land->[$bx][$by] == $HlandBase) ||
		 ($land->[$bx][$by] == $HlandSbase)) {
		 last;
		}
		$count++;
	 }
	 if($count>= $HpointNumber) {
		# 찾을 수 없으면 그곳까지
		last;
	 }
	 # 최소하나기지가 있었던이므로,flag 을설립하고 있는
	 $flag = 1;

	 # 기지의 레벨을 산출
	 my($level) = expToLevel($land->[$bx][$by], $landValue->[$bx][$by]);
	 # 기지내에서 루프
	 while(($level> 0) &&
		 ($arg> 0) &&
		 ($island->{'money'}> $cost)) {
		# 명중이 확정이므로, 각 값을 소도
		$level--;
		$arg--;
		$island->{'money'} -= $cost;

		# 상대의 피격 미사일+
		$tIsland->{'MIN'} ++;
		$mCount++;

		# 자신의 발사 미사일 수(스텔스이외)+
		if($kind != $HcomMissileST) {
		 $island->{'MOUT'} ++;
		 $island->{'totalMOUT'} ++;
		}

		# 착탄 지점 산출
		my($r) = random($err);
		$tx = $x + $ax[$r];
		$ty = $y + $ay[$r];
		if((($ty % 2) == 0) && (($y % 2) == 1)) {
		 $tx--;
		}

		# 착탄 지점범위안팎 확인
		if(($tx < 0) || ($tx>= $HislandSize) ||
		 ($ty < 0) || ($ty>= $HislandSize)) {
#		 # 범위 밖
#		 if($kind == $HcomMissileST) {
#			# 스텔스
#			logMsOutS($id, $target, $name, $tName,
#				 $comName, $point);
#		 } else {
#			# 일반계
#			logMsOut($id, $target, $name, $tName,
#				 $comName, $point);
#		 }
		 $nCount++;
		 next;
		}

		# 착탄 지점의 지형등 산출
		my($tL) = $tLand->[$tx][$ty];
		my($tLv) = $tLandValue->[$tx][$ty];
		my($tLname) = landName($tL, $tLv);
		my($tPoint) = "($tx, $ty)";

		# 방위 시설 판정
		my($defence) = 0;
		if($HdefenceHex[$id][$tx][$ty] == 1) {
		 $defence = 1;
		} elsif($HdefenceHex[$id][$tx][$ty] == -1) {
		 $defence = 0;
		} else {
		 if($tL == $HlandDefence) {
			# 방위 시설에 명중
			# 플래그를 지우기
			my($i, $count, $sx, $sy);
			for($i = 0; $i < 19; $i++) {
			 $sx = $tx + $ax[$i];
			 $sy = $ty + $ay[$i];

			 # 행 기준 위치 조정
			 if((($sy % 2) == 0) && (($ty % 2) == 1)) {
				$sx--;
			 }

			 if(($sx < 0) || ($sx>= $HislandSize) ||
			 ($sy < 0) || ($sy>= $HislandSize)) {
				# 범위 밖이면 아무것도 하지 않음
			 } else {
				# 범위 안의 경우
				$HdefenceHex[$id][$sx][$sy] = 0;
			 }
			}
		 } elsif(countAround($tLand, $tx, $ty, $HlandDefence, 19)) {
			$HdefenceHex[$id][$tx][$ty] = 1;
			$defence = 1;
		 } else {
			$HdefenceHex[$id][$tx][$ty] = -1;
			$defence = 0;
		 }
		}

		if($defence == 1) {
		 # 공안폭파
		 if($kind == $HcomMissileST) {
			# 스텔스
			logMsCaughtS($id, $target, $name, $tName,
				 $comName, $point, $tPoint);
		 } else {
			# 일반계
			logMsCaught($id, $target, $name, $tName,
				 $comName, $point, $tPoint);
		 }
		 $nCount++;
		 next;
		}

		# '효과 없음' hex를 먼저 판정
		if((($tL == $HlandSea) && ($tLv == 0))|| # 깊은 바다
		 ((($tL == $HlandSea) || # 바다또는...
		 ($tL == $HlandSbase) || # 해저 기지또는...
		 ($tL == $HlandMountain)) # 산에서...
		 && ($kind != $HcomMissileLD))) { # 육상 파괴탄이외
#		 # 해저 기지는 바다처럼 표시
#		 if($tL == $HlandSbase) {
#			$tL = $HlandSea;
#		 }
#		 $tLname = landName($tL, $tLv);
#
#		 # 무효화
#		 if($kind == $HcomMissileST) {
#			# 스텔스
#			logMsNoDamageS($id, $target, $name, $tName,
#					$comName, $tLname, $point, $tPoint);
#		 } else {
#			# 일반계
#			logMsNoDamage($id, $target, $name, $tName,
#				 $comName, $tLname, $point, $tPoint);
#		 }
		 $nCount++;
		 next;
		}

		# 탄 종류에서 분기
		if($kind == $HcomMissileLD) {
		 # 육지 파괴탄
		 if($tL == $HlandMountain) {
			# 산(황무지가 됨)
			logMsLDMountain($id, $target, $name, $tName,
					 $comName, $tLname, $point, $tPoint);
			# 황무지가 됨
			$tLand->[$tx][$ty] = $HlandWaste;
			$tLandValue->[$tx][$ty] = 0;
			next;

		 } elsif($tL == $HlandSbase) {
			# 해저 기지
			logMsLDSbase($id, $target, $name, $tName,
				 $comName, $tLname, $point, $tPoint);
		 } elsif($tL == $HlandMonster) {
			# 괴수
			logMsLDMonster($id, $target, $name, $tName,
					$comName, $tLname, $point, $tPoint);
		 } elsif($tL == $HlandSea) {
			# 얕은 바다
			logMsLDSea1($id, $target, $name, $tName,
				 $comName, $tLname, $point, $tPoint);
		 } else {
			# 기타
			logMsLDLand($id, $target, $name, $tName,
				 $comName, $tLname, $point, $tPoint);
		 }

		 # 경험치
		 if($tL == $HlandTown) {
			if(($land->[$bx][$by] == $HlandBase) ||
			 ($land->[$bx][$by] == $HlandSbase)) {
			 # 아직 기지인 경우만
			 $landValue->[$bx][$by] += int($tLv / 20);
			 if($landValue->[$bx][$by]> $HmaxExpPoint) {
				$landValue->[$bx][$by] = $HmaxExpPoint;
			 }
			}
		 }

		 # 얕은 바다가 됨
		 $tLand->[$tx][$ty] = $HlandSea;
		 $tIsland->{'area'}--;
		 $tLandValue->[$tx][$ty] = 1;

		 # 라도유전, 얕은 바다, 해저 기지였으면 바다
		 if(($tL == $HlandOil) ||
			($tL == $HlandSea) ||
		 ($tL == $HlandSbase)) {
			$tLandValue->[$tx][$ty] = 0;
		 }
		} else {
		 # 기타 미사일
		 if($tL == $HlandWaste) {
#			# 황무지(피해없음)
#			if($kind == $HcomMissileST) {
#			 # 스텔스
#			 logMsWasteS($id, $target, $name, $tName,
#					 $comName, $tLname, $point, $tPoint);
#			} else {
#			 # 일반
#			 logMsWaste($id, $target, $name, $tName,
#					$comName, $tLname, $point, $tPoint);
#			}
			$nCount++;
		 } elsif($tL == $HlandMonster) {
			# 괴수
			my($mKind, $mName, $mHp) = monsterSpec($tLv);
			my($special) = $HmonsterSpecial[$mKind];

			# 경화 중?
			if((($special == 3) && (($HislandTurn % 2) == 1)) ||
			 (($special == 4) && (($HislandTurn % 2) == 0))) {
			 # 경화 중
			 if($kind == $HcomMissileST) {
				# 스텔스
				logMsMonNoDamageS($id, $target, $name, $tName,
					 $comName, $mName, $point,
					 $tPoint);
			 } else {
				# 일반탄
				logMsMonNoDamage($id, $target, $name, $tName,
					 $comName, $mName, $point,
					 $tPoint);
			 }
			 next;
			} else {
			 # 경화 중이 아님
			 if($mHp == 1) {
				# 괴수를 처치했습니다
				if(($land->[$bx][$by] == $HlandBase) ||
				 ($land->[$bx][$by] == $HlandSbase)) {
				 # 경험치
				 $landValue->[$bx][$by] += $HmonsterExp[$mKind];
				 if($landValue->[$bx][$by]> $HmaxExpPoint) {
					$landValue->[$bx][$by] = $HmaxExpPoint;
				 }
				}

				if($kind == $HcomMissileST) {
				 # 스텔스
				 logMsMonKillS($id, $target, $name, $tName,
						 $comName, $mName, $point,
						 $tPoint);
				} else {
				 # 일반
				 logMsMonKill($id, $target, $name, $tName,
						 $comName, $mName, $point,
						 $tPoint);
				}

				# 수입
				my($value) = $HmonsterValue[$mKind];
				if($value> 0) {
				 $tIsland->{'money'} += $value;
				 logMsMonMoney($target, $mName, $value);
				}

				# 수상 관계
				my($prize) = $island->{'prize'};
				$prize =~ /([0-9]*),([0-9]*),(.*)/;
				my($flags) = $1;
				my($monsters) = $2;
				my($turns) = $3;
				my($v) = 2 ** $mKind;
				$monsters |= $v;
				$island->{'prize'} = "$flags,$monsters,$turns";
			 } else {
				# 괴수살아하고 있는
				if($kind == $HcomMissileST) {
				 # 스텔스
				 logMsMonsterS($id, $target, $name, $tName,
						 $comName, $mName, $point,
						 $tPoint);
				} else {
				 # 일반
				 logMsMonster($id, $target, $name, $tName,
						 $comName, $mName, $point,
						 $tPoint);
				}
				# HP가 1 감소
				$tLandValue->[$tx][$ty]--;
				next;
			 }

			}
		 } else {
			# 일반 지형
			if($kind == $HcomMissileST) {
			 # 스텔스
			 logMsNormalS($id, $target, $name, $tName,
					 $comName, $tLname, $point,
					 $tPoint);
			} else {
			 # 일반
			 logMsNormal($id, $target, $name, $tName,
					 $comName, $tLname, $point,
					 $tPoint);
			}
		 }
		 # 경험치
		 if($tL == $HlandTown) {
			if(($land->[$bx][$by] == $HlandBase) ||
			 ($land->[$bx][$by] == $HlandSbase)) {
			 $landValue->[$bx][$by] += int($tLv / 20);
			 $boat += $tLv; # 일반 미사일이므로 난민에플러스
			 if($landValue->[$bx][$by]> $HmaxExpPoint) {
				$landValue->[$bx][$by] = $HmaxExpPoint;
			 }
			}
		 }

 # 황무지가 됨
		 $tLand->[$tx][$ty] = $HlandWaste;
		 $tLandValue->[$tx][$ty] = 1; # 착탄 지점

		 # 라도유전였으면 바다
		 if($tL == $HlandOil) {
			$tLand->[$tx][$ty] = $HlandSea;
			$tLandValue->[$tx][$ty] = 0;
		 }
		}
	 }

	 # 카운트 증가
	 $count++;
	}


	if($flag == 0) {
	 # 기지가 하나도 없어진 경우
	 logMsNoBase($id, $name, $comName);
	 return 0;
	} else {
	 logMsCount($id, $target, $name, $tName, $comName, $mCount, $nCount, $point);
	}

	# 난민판정
#	$boat = int($boat / 2);
	if(($boat> 0) && ($id != $target) && ($kind != $HcomMissileST)) {
	 # 난민표착
	 my($achive); # 도달난민
	 my($i);
	 for($i = 0; ($i < $HpointNumber && $boat> 0); $i++) {
		$bx = $Hrpx[$i];
		$by = $Hrpy[$i];
		if($land->[$bx][$by] == $HlandTown) {
		 # 마을의 경우
		 my($lv) = $landValue->[$bx][$by];
		 if($boat> 50) {
			$lv += 50;
			$boat -= 50;
			$achive += 50;
		 } else {
			$lv += $boat;
			$achive += $boat;
			$boat = 0;
		 }
		 if($lv> 200) {
			$boat += ($lv - 200);
			$achive -= ($lv - 200);
			$lv = 200;
		 }
		 $landValue->[$bx][$by] = $lv;
		} elsif($land->[$bx][$by] == $HlandPlains) {
		 # 평지의 경우
		 $land->[$bx][$by] = $HlandTown;;
		 if($boat> 20) {
			$landValue->[$bx][$by] = 10;
			$boat -= 20;
			$achive += 20;
		 } elsif($boat> 0) {
			$landValue->[$bx][$by] = $boat;
			$achive += $boat;
			$boat = 0;
		 }
		}
		if($boat <= 0) {
		 last;
		}
	 }
	 if($achive> 0) {
		# 조금이라도 도착한 경우 로그를 출력
		logMsBoatPeople($id, $name, $achive);

		# 난민의 수가일정수이상라면, 평화상의 가능성있음
		if($achive>= 200) {
		 my($prize) = $island->{'prize'};
		 $prize =~ /([0-9]*),([0-9]*),(.*)/;
		 my($flags) = $1;
		 my($monsters) = $2;
		 my($turns) = $3;

		 if((!($flags & 8)) && $achive>= 200){
			$flags |= 8;
			logPrize($id, $name, $Hprize[4]);
		 } elsif((!($flags & 16)) && $achive> 500){
			$flags |= 16;
			logPrize($id, $name, $Hprize[5]);
		 } elsif((!($flags & 32)) && $achive> 800){
			$flags |= 32;
			logPrize($id, $name, $Hprize[6]);
		 }
		 $island->{'prize'} = "$flags,$monsters,$turns";
		}
	 }
	}
	return 1;
 } elsif($kind == $HcomSendMonster) {
	# 괴수 파견

	if($HislandTurn <= $HarmisticeTurn){
	 # 공격이 허가되어 있지 않음
	 logNotAvail($id, $name, $comName);
	 return 0;
	}

	# 대상 가져오기
	my($tn) = $HidToNumber{$target};
	my($tIsland) = $Hislands[$tn];
	my($tName) = $tIsland->{'name'};

	if($tn eq '') {
	 # 대상이 이미 없음
	 logMsNoTarget($id, $name, $comName);
	 return 0;
	}

	# 메시지
	logMonsSend($id, $target, $name, $tName);
	$tIsland->{'monstersend'}++;

	$island->{'money'} -= $cost;
	return 1;
 } elsif($kind == $HcomSell) {
	# 수출량 결정
	if($arg == 0) { $arg = 1; }
	my($value) = min($arg * (-$cost), $island->{'food'});

	# 수출 로그
	logSell($id, $name, $comName, $value);
	$island->{'food'} -= $value;
	$island->{'money'} += ($value / 5);
	return 0;
 } elsif(($kind == $HcomFood) ||
	 ($kind == $HcomMoney)) {
	# 지원계
	# 대상 가져오기
	my($tn) = $HidToNumber{$target};
	my($tIsland) = $Hislands[$tn];
	my($tName) = $tIsland->{'name'};

	# 지원량 결정
	if($arg == 0) { $arg = 1; }
	my($value, $str);
	if($cost < 0) {
	 $value = min($arg * (-$cost), $island->{'food'});
	 $str = "$value$HunitFood";
	} else {
	 $value = min($arg * ($cost), $island->{'money'});
	 $str = "$value$HunitMoney";
	}

	# 지원 로그
	logAid($id, $target, $name, $tName, $comName, $str);

	if($cost < 0) {
	 $island->{'food'} -= $value;
	 $tIsland->{'food'} += $value;
	} else {
	 $island->{'money'} -= $value;
	 $tIsland->{'money'} += $value;
	}
	return 0;
 } elsif($kind == $HcomPropaganda) {
	# 유치 활동
	logPropaganda($id, $name, $comName);
	$island->{'propaganda'} = 1;
	$island->{'money'} -= $cost;
	return 0;
 } elsif($kind == $HcomGiveup) {
	# 포기
	logGiveup($id, $name);
	$island->{'dead'} = 1;
	unlink("island.$id");
	return 1;
 }

 return 1;
}


# 성장 및 단일 헥스 재해
sub doEachHex {
 my($island) = @_;
 my(@monsterMove);

 # 도출 값
 my($name) = $island->{'name'};
 my($id) = $island->{'id'};
 my($land) = $island->{'land'};
 my($landValue) = $island->{'landValue'};

 # 늘어나면인구의 타네 값
 my($addpop) = 5; # 마을, 마을
 my($addpop2) = 0; # 도시

 if($HislandTurn <= $HarmisticeTurn){
	$addpop = 40; # 마을, 마을
 }

 if($island->{'food'} < 0) {
	# 식량 부족
	$addpop = -30;
 } elsif($island->{'propaganda'} == 1) {
	# 유치 활동 중
	$addpop = 10;
	$addpop2 = 3;
	if($HislandTurn <= $HarmisticeTurn){
	 $addpop = 60;
	 $addpop2 = 10;
	}
 }

 # 루프
 my($x, $y, $i);
 for($i = 0; $i < $HpointNumber; $i++) {
	$x = $Hrpx[$i];
	$y = $Hrpy[$i];
	my($landKind) = $land->[$x][$y];
	my($lv) = $landValue->[$x][$y];

	if($landKind == $HlandTown) {
	 # 마을 계열
	 if($addpop < 0) {
		# 부족
		$lv -= (random(-$addpop) + 1);
		if($lv <= 0) {
		 # 평지로 되돌리기
		 $land->[$x][$y] = $HlandPlains;
		 $landValue->[$x][$y] = 0;
		 next;
		}
	 } else {
		# 성장
		if($lv < 100) {
		 if($island->{'donothing'} == 0){
			$lv += random($addpop) + 1;
		 }
		 if($lv> 100) {
			$lv = 100;
		 }
		} else {
		 # 도시가 되면 성장 지연이
		 if($addpop2> 0) {
			$lv += random($addpop2) + 1;
		 }
		}
	 }
	 if($lv> 200) {
		$lv = 200;
	 }
	 $landValue->[$x][$y] = $lv;
	} elsif($landKind == $HlandPlains) {
	 # 평지

	if($HislandTurn <= $HarmisticeTurn){
	 if((random(3) == 0)&&($island->{'donothing'} == 0)) {
		# 주변에 농장, 마을이 있다면, 여기도 마을이 됨
	 if(countGrow($land, $landValue, $x, $y)){
		 $land->[$x][$y] = $HlandTown;
		 $landValue->[$x][$y] = 1;
		}
	 }
	} else {

	 if((random(11) == 0)&&($island->{'donothing'} == 0)) {
		# 주변에 농장, 마을이 있다면, 여기도 마을이 됨
	 if(countGrow($land, $landValue, $x, $y)){
		 $land->[$x][$y] = $HlandTown;
		 $landValue->[$x][$y] = 1;
		}
	 }
	}

	} elsif($landKind == $HlandForest) {
	 # 숲
	 if($lv < 200) {
		# 나무가 늘어남
		$landValue->[$x][$y] += $HtreeGrow;
	 }
	} elsif($landKind == $HlandDefence) {
	 if($lv == 1) {
		# 방위 시설 자폭
		my($lName) = &landName($landKind, $lv);
		logBombFire($id, $name, $lName, "($x, $y)");

		# 광역 피해 루틴
		wideDamage($id, $name, $land, $landValue, $x, $y);
	 }
	} elsif($landKind == $HlandOil) {
	 # 해저 유전
	 my($value, $str, $lName);
	 $lName = landName($landKind, $lv);
	 $value = $HoilMoney;
	 $island->{'money'} += $value;
	 $str = "$value$HunitMoney";

	 # 수입 로그
	 logOilMoney($id, $name, $lName, "($x, $y)", $str);

	 # 고갈판정
	 if(random(1000) < $HoilRatio) {
		# 고갈
		logOilEnd($id, $name, $lName, "($x, $y)");
		$land->[$x][$y] = $HlandSea;
		$landValue->[$x][$y] = 0;
	 }

	} elsif($landKind == $HlandMonster) {
	 # 괴수
	 if($monsterMove[$x][$y] == 2) {
		# 이미 이동한 후
		next;
	 }

	 # 각 요소 꺼내기
	 my($mKind, $mName, $mHp) = monsterSpec($landValue->[$x][$y]);
	 my($special) = $HmonsterSpecial[$mKind];

	 # 경화 중?
	 if((($special == 3) && (($HislandTurn % 2) == 1)) ||
	 (($special == 4) && (($HislandTurn % 2) == 0))) {
		# 경화 중
		next;
	 }

	 # 이동 방향을 결정
	 my($d, $sx, $sy);
	 my($i);
	 for($i = 0; $i < 3; $i++) {
		$d = random(6) + 1;
		$sx = $x + $ax[$d];
		$sy = $y + $ay[$d];

		# 행 기준 위치 조정
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		 $sx--;
		}

		# 범위 밖 판정
		if(($sx < 0) || ($sx>= $HislandSize) ||
		 ($sy < 0) || ($sy>= $HislandSize)) {
		 next;
		}

		# 바다, 바다 기준, 유전, 괴수, 산, 기념비 이외
		if(($land->[$sx][$sy] != $HlandSea) &&
		 ($land->[$sx][$sy] != $HlandSbase) &&
		 ($land->[$sx][$sy] != $HlandOil) &&
		 ($land->[$sx][$sy] != $HlandMountain) &&
		 ($land->[$sx][$sy] != $HlandMonument) &&
		 ($land->[$sx][$sy] != $HlandMonster)) {
		 last;
		}
	 }

	 if($i == 3) {
		# 작동없었습니다
		next;
	 }

	 # 이동한 위치의 지형에 따라 처리
	 my($l) = $land->[$sx][$sy];
	 my($lv) = $landValue->[$sx][$sy];
	 my($lName) = landName($l, $lv);
	 my($point) = "($sx, $sy)";

	 # 이동
	 $land->[$sx][$sy] = $land->[$x][$y];
	 $landValue->[$sx][$sy] = $landValue->[$x][$y];

	 # 원래 위치를 황무지로
	 $land->[$x][$y] = $HlandWaste;
	 $landValue->[$x][$y] = 0;

	 # 이동 완료 플래그
	 if($HmonsterSpecial[$mKind] == 2) {
		# 이동 완료 플래그가 설정되어 있지 않음
	 } elsif($HmonsterSpecial[$mKind] == 1) {
		# 속이괴수
		$monsterMove[$sx][$sy] = $monsterMove[$x][$y] + 1;
	 } else {
		# 일반 괴수
		$monsterMove[$sx][$sy] = 2;
	 }

	 if(($l == $HlandDefence) && ($HdBaseAuto == 1)) {
		# 방위 시설을 밟습니다
		logMonsMoveDefence($id, $name, $lName, $point, $mName);

		# 광역 피해 루틴
		wideDamage($id, $name, $land, $landValue, $sx, $sy);
	 } else {
		# 연결선이황무지가 됨
		logMonsMove($id, $name, $lName, $point, $mName);
	 }
	}

	# 화재판정
	if((($landKind == $HlandTown) && ($lv> 30)) ||
	 ($landKind == $HlandHaribote) ||
	 ($landKind == $HlandFactory)) {
	 if(random(1000) < $HdisFire) {
		# 주변의 숲과 기념비를 흡수 가능
		if((countAround($land, $x, $y, $HlandForest, 7) +
		 countAround($land, $x, $y, $HlandMonument, 7)) == 0) {
		 # 없어진 경우 화재로 괴멸
		 my($l) = $land->[$x][$y];
		 my($lv) = $landValue->[$x][$y];
		 my($point) = "($x, $y)";
		 my($lName) = landName($l, $lv);
		 logFire($id, $name, $lName, $point);
		 $land->[$x][$y] = $HlandWaste;
		 $landValue->[$x][$y] = 0;
		}
	 }
	}
 }
}

# 주변의 마을, 농장이 있는 지반정
sub countGrow {
 my($land, $landValue, $x, $y) = @_;
 my($i, $sx, $sy);
 for($i = 1; $i < 7; $i++) {
	 $sx = $x + $ax[$i];
	 $sy = $y + $ay[$i];

	 # 행 기준 위치 조정
	 if((($sy % 2) == 0) && (($y % 2) == 1)) {
	 $sx--;
	 }

	 if(($sx < 0) || ($sx>= $HislandSize) ||
	 ($sy < 0) || ($sy>= $HislandSize)) {
	 } else {
	 # 범위 안의 경우
	 if(($land->[$sx][$sy] == $HlandTown) ||
		($land->[$sx][$sy] == $HlandFarm)) {
		 if($landValue->[$sx][$sy] != 1) {
		 return 1;
		 }
	 }
	 }
 }
 return 0;
}

# 섬 전체
sub doIslandProcess {
 my($number, $island) = @_;

 # 도출 값
 my($name) = $island->{'name'};
 my($id) = $island->{'id'};
 my($land) = $island->{'land'};
 my($landValue) = $island->{'landValue'};

 # 지진판정
 if(random(1000) < (($island->{'prepare2'} + 1) * $HdisEarthquake)) {
	# 지진발생
	logEarthquake($id, $name);

	my($x, $y, $landKind, $lv, $i);
	for($i = 0; $i < $HpointNumber; $i++) {
	 $x = $Hrpx[$i];
	 $y = $Hrpy[$i];
	 $landKind = $land->[$x][$y];
	 $lv = $landValue->[$x][$y];

	 if((($landKind == $HlandTown) && ($lv>= 100)) ||
	 ($landKind == $HlandHaribote) ||
	 ($landKind == $HlandFactory)) {
		# 1/4에서 괴멸
		if(random(4) == 0) {
		 logEQDamage($id, $name, landName($landKind, $lv),
				"($x, $y)");
		 $land->[$x][$y] = $HlandWaste;
		 $landValue->[$x][$y] = 0;
		}
	 }

	}
 }

 # 식량 부족
 if($island->{'food'} <= 0) {
	# 부족 메시지
	logStarve($id, $name);
	$island->{'food'} = 0;

	my($x, $y, $landKind, $lv, $i);
	for($i = 0; $i < $HpointNumber; $i++) {
	 $x = $Hrpx[$i];
	 $y = $Hrpy[$i];
	 $landKind = $land->[$x][$y];
	 $lv = $landValue->[$x][$y];

	 if(($landKind == $HlandFarm) ||
	 ($landKind == $HlandFactory) ||
	 ($landKind == $HlandBase) ||
	 ($landKind == $HlandDefence)) {
		# 1/4에서 괴멸
		if(random(4) == 0) {
		 logSvDamage($id, $name, landName($landKind, $lv),
				"($x, $y)");
		 $land->[$x][$y] = $HlandWaste;
		 $landValue->[$x][$y] = 0;
		}
	 }
	}
 }

 # 쓰나미판정
 if(random(1000) < $HdisTsunami) {
	# 쓰나미발생
	logTsunami($id, $name);

	my($x, $y, $landKind, $lv, $i);
	for($i = 0; $i < $HpointNumber; $i++) {
	 $x = $Hrpx[$i];
	 $y = $Hrpy[$i];
	 $landKind = $land->[$x][$y];
	 $lv = $landValue->[$x][$y];

	 if(($landKind == $HlandTown) ||
	 ($landKind == $HlandFarm) ||
	 ($landKind == $HlandFactory) ||
	 ($landKind == $HlandBase) ||
	 ($landKind == $HlandDefence) ||
	 ($landKind == $HlandHaribote)) {
		# 1d12 <= (주변의 바다 - 1) 데붕괴
		if(random(12) <
		 (countAround($land, $x, $y, $HlandOil, 7) +
		 countAround($land, $x, $y, $HlandSbase, 7) +
		 countAround($land, $x, $y, $HlandSea, 7) - 1)) {
		 logTsunamiDamage($id, $name, landName($landKind, $lv),
				 "($x, $y)");
		 $land->[$x][$y] = $HlandWaste;
		 $landValue->[$x][$y] = 0;
		}
	 }

	}
 }

 # 괴수판정
 my($r) = random(10000);
 my($pop) = $island->{'pop'};
 do{
	if((($r < ($HdisMonster * $island->{'area'})) &&
	 ($pop>= $HdisMonsBorder1)) ||
	 ($island->{'monstersend'}> 0)) {
	 # 괴수출현
	 # 종류를 결하기
	 my($lv, $kind);
	 if($island->{'monstersend'}> 0) {
		# 인공
		$kind = 0;
		$island->{'monstersend'}--;
	 } elsif($pop>= $HdisMonsBorder3) {
		# level3까지
		$kind = random($HmonsterLevel3) + 1;
	 } elsif($pop>= $HdisMonsBorder2) {
		# level2까지
		$kind = random($HmonsterLevel2) + 1;
	 } else {
		# level1만
		$kind = random($HmonsterLevel1) + 1;
	 }

	 # lv 의 값을 결하기
	 $lv = $kind * 10
		+ $HmonsterBHP[$kind] + random($HmonsterDHP[$kind]);

	 # 어디에 출현할지 결정
	 my($bx, $by, $i);
	 for($i = 0; $i < $HpointNumber; $i++) {
		$bx = $Hrpx[$i];
		$by = $Hrpy[$i];
		if($land->[$bx][$by] == $HlandTown) {

		 # 지형 이름
		 my($lName) = landName($HlandTown, $landValue->[$bx][$by]);

		 # 해당 헥스를 괴수로
		 $land->[$bx][$by] = $HlandMonster;
		 $landValue->[$bx][$by] = $lv;

		 # 괴수 정보
		 my($mKind, $mName, $mHp) = monsterSpec($lv);

		 # 메시지
		 logMonsCome($id, $name, $mName, "($bx, $by)", $lName);
		 last;
		}
	 }
	}
 } while($island->{'monstersend'}> 0);

 # 지반 침하판정
 if(($island->{'area'}> $HdisFallBorder) &&
 (random(1000) < $HdisFalldown)) {
	# 지반 침하발생
	logFalldown($id, $name);

	my($x, $y, $landKind, $lv, $i);
	for($i = 0; $i < $HpointNumber; $i++) {
	 $x = $Hrpx[$i];
	 $y = $Hrpy[$i];
	 $landKind = $land->[$x][$y];
	 $lv = $landValue->[$x][$y];

	 if(($landKind != $HlandSea) &&
	 ($landKind != $HlandSbase) &&
	 ($landKind != $HlandOil) &&
	 ($landKind != $HlandMountain)) {

		# 주변에 바다가 있다면, 값을-1에
		if(countAround($land, $x, $y, $HlandSea, 7) +
		 countAround($land, $x, $y, $HlandSbase, 7)) {
		 logFalldownLand($id, $name, landName($landKind, $lv),
				"($x, $y)");
		 $land->[$x][$y] = -1;
		 $landValue->[$x][$y] = 0;
		}
	 }
	}

	for($i = 0; $i < $HpointNumber; $i++) {
	 $x = $Hrpx[$i];
	 $y = $Hrpy[$i];
	 $landKind = $land->[$x][$y];

	 if($landKind == -1) {
		# -1에나하고 있는 장소를 얕은 바다에
		$land->[$x][$y] = $HlandSea;
		$landValue->[$x][$y] = 1;
	 } elsif ($landKind == $HlandSea) {
		# 얕은 바다는 바다에
		$landValue->[$x][$y] = 0;
	 }

	}
 }

 # 태풍판정
 if(random(1000) < $HdisTyphoon) {
	# 태풍발생
	logTyphoon($id, $name);

	my($x, $y, $landKind, $lv, $i);
	for($i = 0; $i < $HpointNumber; $i++) {
	 $x = $Hrpx[$i];
	 $y = $Hrpy[$i];
	 $landKind = $land->[$x][$y];
	 $lv = $landValue->[$x][$y];

	 if(($landKind == $HlandFarm) ||
	 ($landKind == $HlandHaribote)) {

		# 1d12 <= (6 - 주변의 숲) 데붕괴
		if(random(12) <
		 (6
		 - countAround($land, $x, $y, $HlandForest, 7)
		 - countAround($land, $x, $y, $HlandMonument, 7))) {
		 logTyphoonDamage($id, $name, landName($landKind, $lv),
				 "($x, $y)");
		 $land->[$x][$y] = $HlandPlains;
		 $landValue->[$x][$y] = 0;
		}
	 }

	}
 }

 # 거대운석판정
 if(random(1000) < $HdisHugeMeteo) {
	my($x, $y, $landKind, $lv, $point);

	# 낙하
	$x = random($HislandSize);
	$y = random($HislandSize);
	$landKind = $land->[$x][$y];
	$lv = $landValue->[$x][$y];
	$point = "($x, $y)";

	# 메시지
	logHugeMeteo($id, $name, $point);

	# 광역 피해 루틴
	wideDamage($id, $name, $land, $landValue, $x, $y);
 }

 # 거대 미사일판정
 while($island->{'bigmissile'}> 0) {
	$island->{'bigmissile'} --;

	my($x, $y, $landKind, $lv, $point);

	# 낙하
	$x = random($HislandSize);
	$y = random($HislandSize);
	$landKind = $land->[$x][$y];
	$lv = $landValue->[$x][$y];
	$point = "($x, $y)";

	# 메시지
	logMonDamage($id, $name, $point);

	# 광역 피해 루틴
	wideDamage($id, $name, $land, $landValue, $x, $y);
 }

 # 운석판정
 if(random(1000) < $HdisMeteo) {
	my($x, $y, $landKind, $lv, $point, $first);
	$first = 1;
	while((random(2) == 0) || ($first == 1)) {
	 $first = 0;

	 # 낙하
	 $x = random($HislandSize);
	 $y = random($HislandSize);
	 $landKind = $land->[$x][$y];
	 $lv = $landValue->[$x][$y];
	 $point = "($x, $y)";

	 if(($landKind == $HlandSea) && ($lv == 0)){
		# 바다포차
		logMeteoSea($id, $name, landName($landKind, $lv),
			 $point);
	 } elsif($landKind == $HlandMountain) {
		# 산파괴
		logMeteoMountain($id, $name, landName($landKind, $lv),
				 $point);
		$land->[$x][$y] = $HlandWaste;
		$landValue->[$x][$y] = 0;
		next;
	 } elsif($landKind == $HlandSbase) {
		logMeteoSbase($id, $name, landName($landKind, $lv),
			 $point);
	 } elsif($landKind == $HlandMonster) {
		logMeteoMonster($id, $name, landName($landKind, $lv),
				$point);
	 } elsif($landKind == $HlandSea) {
		# 얕은 바다
		logMeteoSea1($id, $name, landName($landKind, $lv),
			 $point);
	 } else {
		logMeteoNormal($id, $name, landName($landKind, $lv),
			 $point);
	 }
	 $land->[$x][$y] = $HlandSea;
	 $landValue->[$x][$y] = 0;
	}
 }

 # 분화 판정정
 if(random(1000) < $HdisEruption) {
	my($x, $y, $sx, $sy, $i, $landKind, $lv, $point);
	$x = random($HislandSize);
	$y = random($HislandSize);
	$landKind = $land->[$x][$y];
	$lv = $landValue->[$x][$y];
	$point = "($x, $y)";
	logEruption($id, $name, landName($landKind, $lv),
		 $point);
	$land->[$x][$y] = $HlandMountain;
	$landValue->[$x][$y] = 0;

	for($i = 1; $i < 7; $i++) {
	 $sx = $x + $ax[$i];
	 $sy = $y + $ay[$i];

	 # 행 기준 위치 조정
	 if((($sy % 2) == 0) && (($y % 2) == 1)) {
		$sx--;
	 }

	 $landKind = $land->[$sx][$sy];
	 $lv = $landValue->[$sx][$sy];
	 $point = "($sx, $sy)";

	 if(($sx < 0) || ($sx>= $HislandSize) ||
	 ($sy < 0) || ($sy>= $HislandSize)) {
	 } else {
		# 범위 안의 경우
		$landKind = $land->[$sx][$sy];
		$lv = $landValue->[$sx][$sy];
		$point = "($sx, $sy)";
		if(($landKind == $HlandSea) ||
		 ($landKind == $HlandOil) ||
		 ($landKind == $HlandSbase)) {
		 # 바다의 경우
		 if($lv == 1) {
			# 얕은 바다
			logEruptionSea1($id, $name, landName($landKind, $lv),
					$point);
		 } else {
			logEruptionSea($id, $name, landName($landKind, $lv),
				 $point);
			$land->[$sx][$sy] = $HlandSea;
			$landValue->[$sx][$sy] = 1;
			next;
		 }
		} elsif(($landKind == $HlandMountain) ||
			($landKind == $HlandMonster) ||
			($landKind == $HlandWaste)) {
		 next;
		} else {
		 # 그 외의 경우
		 logEruptionNormal($id, $name, landName($landKind, $lv),
				 $point);
		}
		$land->[$sx][$sy] = $HlandWaste;
		$landValue->[$sx][$sy] = 0;
	 }
	}
 }

 # 식량이 넘치면 환전
 if($island->{'food'}> 99999) {
	$island->{'money'} += int(($island->{'food'} - 99999) / 10);
	$island->{'food'} = 99999;
 }

 # 자금이 넘치면 잘라냄
 if($island->{'money'}> 99999) {
	$island->{'money'} = 99999;
 }

 # 미사일 수에 따라 스나이퍼 타깃
 if($island->{'getNB'} < 10) {
	while($island->{'totalMOUT'} - (($island->{'getNB'}+1)*$NB)>= 0){
	 $island->{'getNB'} += 1;
	 $island->{'nowNB'} += 1;
	}
 } else {
	while($island->{'totalMOUT'} - (($island->{'getNB'}+1)*$NB2)>= 0){
	 $island->{'getNB'} += 1;
	 $island->{'nowNB'} += 1;
	}
 }

 # 각종의 값을 계산
 estimate($number);

 # 번영, 재난상
 $pop = $island->{'pop'};
 my($damage) = $island->{'oldPop'} - $pop;
 my($prize) = $island->{'prize'};
 $prize =~ /([0-9]*),([0-9]*),(.*)/;
 my($flags) = $1;
 my($monsters) = $2;
 my($turns) = $3;

 # 번영상
 if((!($flags & 1)) && $pop>= 3000){
	$flags |= 1;
	logPrize($id, $name, $Hprize[1]);
 } elsif((!($flags & 2)) && $pop>= 5000){
	$flags |= 2;
	logPrize($id, $name, $Hprize[2]);
 } elsif((!($flags & 4)) && $pop>= 10000){
	$flags |= 4;
	logPrize($id, $name, $Hprize[3]);
 }

 # 재난상
 if((!($flags & 64)) && $damage>= 500){
	$flags |= 64;
	logPrize($id, $name, $Hprize[7]);
 } elsif((!($flags & 128)) && $damage>= 1000){
	$flags |= 128;
	logPrize($id, $name, $Hprize[8]);
 } elsif((!($flags & 256)) && $damage>= 2000){
	$flags |= 256;
	logPrize($id, $name, $Hprize[9]);
 }

 $island->{'prize'} = "$flags,$monsters,$turns";
}

# 인구순에정렬
sub islandSort {
 my($flag, $i, $tmp);

 # 인구가 같으면 이전 턴의 순서를 유지
 my @idx = (0..$#Hislands);
 @idx = sort { $Hislands[$b]->{'pop'} <=> $Hislands[$a]->{'pop'} || $a <=> $b } @idx;
 @Hislands = @Hislands[@idx];
}

# 광역 피해 루틴
sub wideDamage {
 my($id, $name, $land, $landValue, $x, $y) = @_;
 my($sx, $sy, $i, $landKind, $landName, $lv, $point);

 for($i = 0; $i < 19; $i++) {
	$sx = $x + $ax[$i];
	$sy = $y + $ay[$i];

	# 행 기준 위치 조정
	if((($sy % 2) == 0) && (($y % 2) == 1)) {
	 $sx--;
	}

	$landKind = $land->[$sx][$sy];
	$lv = $landValue->[$sx][$sy];
	$landName = landName($landKind, $lv);
	$point = "($sx, $sy)";

	# 범위 밖 판정
	if(($sx < 0) || ($sx>= $HislandSize) ||
	 ($sy < 0) || ($sy>= $HislandSize)) {
	 next;
	}

	# 범위에 한분기
	if($i < 7) {
	 # 중심 및 1헥스
	 if($landKind == $HlandSea) {
		$landValue->[$sx][$sy] = 0;
		next;
	 } elsif(($landKind == $HlandSbase) ||
		 ($landKind == $HlandOil)) {
		logWideDamageSea2($id, $name, $landName, $point);
		$land->[$sx][$sy] = $HlandSea;
		$landValue->[$sx][$sy] = 0;
	 } else {
		if($landKind == $HlandMonster) {
		 logWideDamageMonsterSea($id, $name, $landName, $point);
		} else {
		 logWideDamageSea($id, $name, $landName, $point);
		}
		$land->[$sx][$sy] = $HlandSea;
		if($i == 0) {
		 # 바다
		 $landValue->[$sx][$sy] = 0;
		} else {
		 # 얕은 바다
		 $landValue->[$sx][$sy] = 1;
		}
	 }
	} else {
	 # 2헥스
	 if(($landKind == $HlandSea) ||
	 ($landKind == $HlandOil) ||
	 ($landKind == $HlandWaste) ||
	 ($landKind == $HlandMountain) ||
	 ($landKind == $HlandSbase)) {
		next;
	 } elsif($landKind == $HlandMonster) {
		logWideDamageMonster($id, $name, $landName, $point);
		$land->[$sx][$sy] = $HlandWaste;
		$landValue->[$sx][$sy] = 0;
	 } else {
		logWideDamageWaste($id, $name, $landName, $point);
		$land->[$sx][$sy] = $HlandWaste;
		$landValue->[$sx][$sy] = 0;
	 }
	}
 }
}

# 로그로 출력
# 제1인 수:메시지
# 제2인 수:당사자
# 제3인 수:상대
# 일반 로그
sub logOut {
 push(@HlogPool,"0,$HislandTurn,$_[1],$_[2],$_[0]");
}

# 지연 로그
sub logLate {
 push(@HlateLogPool,"0,$HislandTurn,$_[1],$_[2],$_[0]");
}

# 기밀 로그
sub logSecret {
 push(@HsecretLogPool,"1,$HislandTurn,$_[1],$_[2],$_[0]");
}

# 기록 로그
sub logHistory {
 open(HOUT, ">>${HdirName}/hakojima.his");
 print HOUT "$HislandTurn,$_[0]\n";
 close(HOUT);
}

# 기록 로그 조정
sub logHistoryTrim {
 open(HIN, "${HdirName}/hakojima.his");
 my(@line, $l, $count);
 $count = 0;
 while($l = <HIN>) {
	chomp($l);
	push(@line, $l);
	$count++;
 }
 close(HIN);

 if($count> $HhistoryMax) {
	open(HOUT, ">${HdirName}/hakojima.his");
	my($i);
	for($i = ($count - $HhistoryMax); $i < $count; $i++) {
	 print HOUT "$line[$i]\n";
	}
	close(HOUT);
 }
}

# 로그 쓰기
sub logFlush {
 open(LOUT, ">${HdirName}/hakojima.log0");

 # 전체를 역순으로 출력
 my($i);
 for($i = $#HsecretLogPool; $i>= 0; $i--) {
	print LOUT $HsecretLogPool[$i];
	print LOUT "\n";
 }
 for($i = $#HlateLogPool; $i>= 0; $i--) {
	print LOUT $HlateLogPool[$i];
	print LOUT "\n";
 }
 for($i = $#HlogPool; $i>= 0; $i--) {
	print LOUT $HlogPool[$i];
	print LOUT "\n";
 }
 close(LOUT);
}

#----------------------------------------------------------------------
# 로그템플릿
#----------------------------------------------------------------------
# 자금 부족
sub logNoMoney {
 my($id, $name, $comName) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}에서 예정되어 있던${HtagComName_}$comName${H_tagComName}은, 자금이 부족해 중지되었습니다.",$id);
}

# 식량 부족
sub logNoFood {
 my($id, $name, $comName) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}에서 예정되어 있던${HtagComName_}$comName${H_tagComName}은, 비축 식량 부족으로 중지되었습니다.",$id);
}

# 일괄땅고르기
sub logAllPrepare {
 my($id, $name, $comName) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}에서${HtagComName_}$comName${H_tagComName}이 실행되었습니다.",$id);
}

# 대상 지형 종류 때문에 실패
sub logLandFail {
 my($id, $name, $comName, $kind, $point) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}에서 예정되어 있던${HtagComName_}$comName${H_tagComName}은, 예정지 ${HtagName_}$point${H_tagName}이<B>$kind</B>였기 때문에 중지되었습니다.",$id);
END
}

# 주변에 육지가 없으면 매립 실패
sub logNoLandAround {
 my($id, $name, $comName, $point) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}에서 예정되어 있던${HtagComName_}$comName${H_tagComName}은, 예정지 ${HtagName_}$point${H_tagName} 주변에 육지가 없었기 때문에 중지되었습니다.",$id);
END
}

# 개간 계열 성공
sub logLandSuc {
 my($id, $name, $comName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}에서${HtagComName_}${comName}${H_tagComName}이 실행되었습니다.",$id);
END
}

# 유전 발견
sub logOilFound {
 my($id, $name, $point, $comName, $str) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}에서<B>$str</B>의 예산을 투입하여${HtagComName_}${comName}${H_tagComName}이 진행되어,<B>유전이 채굴되었습니다</B>.",$id);
END
}

# 유전 발견 여부
sub logOilFail {
 my($id, $name, $point, $comName, $str) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}에서<B>$str</B>의 예산을 투입하여${HtagComName_}${comName}${H_tagComName}이 실행되었지만, 유전은 발견되지 않았습니다.",$id);
END
}

# 유전에서 수입
sub logOilMoney {
 my($id, $name, $lName, $point, $str) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>에서 <B>$str</B> 수익이 발생했습니다.",$id);
END
}

# 유전 고갈
sub logOilEnd {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>은 고갈된 것 같습니다.",$id);
END
}

# 방위 시설, 자폭 설정
sub logBombSet {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>의<B>자폭장치가 설정</B>되었습니다.",$id);
END
}

# 방위 시설, 자폭 작동
sub logBombFire {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>,${HtagDisaster_}자폭장치 작동!!${H_tagDisaster}",$id);
END
}

# 기념비, 발사
sub logMonFly {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>이<B>굉음과 함께 흔들렸습니다</B>.",$id);
END
}

# 기념비, 낙하
sub logMonDamage {
 my($id, $name, $point) = @_;
 logOut("<B>정체불명의 물체</B>가${HtagName_}${name} 섬 $point${H_tagName}지점에 낙하했습니다!!",$id);
}

# 나무심기 or 미사일 기지
sub logPBSuc {
 my($id, $name, $comName, $point) = @_;
 logSecret("${HtagName_}${name} 섬 $point${H_tagName}에서${HtagComName_}${comName}${H_tagComName}이 실행되었습니다.",$id);
 logOut("어디선가 ${HtagName_}${name} 섬${H_tagName}의<B>숲</B>이 늘어난 것 같습니다.",$id);
END
}

# 가짜 시설
sub logHariSuc {
 my($id, $name, $comName, $comName2, $point) = @_;
 logSecret("${HtagName_}${name} 섬 $point${H_tagName}에서${HtagComName_}${comName}${H_tagComName}이 실행되었습니다.",$id);
 logLandSuc($id, $name, $comName2, $point);
END
}

# 미사일 발사 또는 괴수 파견 대상이 없음
sub logMsNoTarget {
 my($id, $name, $comName) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}에서 예정되어 있던${HtagComName_}${comName}${H_tagComName}은, 대상 섬이 무인도이므로 중지되었습니다.",$id);
END
}

# 미사일 발사를 시도했지만 기지가 없음
sub logMsNoBase {
 my($id, $name, $comName) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}에서 예정되어 있던${HtagComName_}${comName}${H_tagComName}은,<B>미사일 설비가 없어</B> 실행할 수 없었습니다.",$id);
END
}

# 미사일 발사 결과 범위 밖
sub logMsOut {
 my($id, $tId, $name, $tName, $comName, $point) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행했지만,<B>영역 밖의 바다</B>로 빗나간 모양입니다.",$id, $tId);
}

# 스텔스 미사일 발사 결과 범위 밖
sub logMsOutS {
 my($id, $tId, $name, $tName, $comName, $point) = @_;
 logSecret("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행했지만,<B>영역 밖의 바다</B>로 빗나간 모양입니다.",$id, $tId);
 logLate("<B>누군가</B>가${HtagName_}${tName} 섬 $point${H_tagName}을 대상으로${HtagComName_}${comName}${H_tagComName}을 실행했지만,<B>영역 밖의 바다</B>로 빗나간 모양입니다.",$tId);
}

# 미사일이 방위 시설에 포착됨
sub logMsCaught {
 my($id, $tId, $name, $tName, $comName, $point, $tPoint) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행했지만,${HtagName_}$tPoint${H_tagName}지점 상공에서 역장에 포착되어,<B>공중 폭발</B>했습니다.",$id, $tId);
}

# 스텔스 미사일이 방위 시설에 포착됨
sub logMsCaughtS {
 my($id, $tId, $name, $tName, $comName, $point, $tPoint) = @_;
 logSecret("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행했지만,${HtagName_}$tPoint${H_tagName}지점 상공에서 역장에 포착되어,<B>공중 폭발</B>했습니다.",$id, $tId);
 logLate("<B>누군가</B>가${HtagName_}${tName} 섬 $point${H_tagName}을 대상으로${HtagComName_}${comName}${H_tagComName}을 실행했지만,${HtagName_}$tPoint${H_tagName}지점 상공에서 역장에 포착되어,<B>공중 폭발</B>했습니다.",$tId);
}

# 미사일 발사 결과 효과 없음
sub logMsNoDamage {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행했지만,${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 빗나가 피해가 없었습니다.",$id, $tId);
}

# 스텔스 미사일 발사 결과 효과 없음
sub logMsNoDamageS {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logSecret("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행했지만,${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 빗나가 피해가 없었습니다.",$id, $tId);

 logLate("<B>누군가</B>가${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행했지만,${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 빗나가 피해가 없었습니다.",$tId);
}

# 육지 파괴탄, 산에 명중
sub logMsLDMountain {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행하여,${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 명중.<B>$tLname</B>은 사라지고, 황무지가 되었습니다.",$id, $tId);
}

# 육지 파괴탄, 해저 기지에 명중
sub logMsLDSbase {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행하여,${HtagName_}$tPoint${H_tagName}에 착탄한 뒤 폭발, 같은 지점에 있던<B>$tLname</B>은 흔적도 없이 날아갔습니다.",$id, $tId);
}

# 육지 파괴탄, 괴수에 명중
sub logMsLDMonster {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행하여,${HtagName_}$tPoint${H_tagName}에 착탄해 폭발. 육지는<B>괴수 $tLname</B>까지 수몰되었습니다.",$id, $tId);
}

# 육지 파괴탄, 얕은 바다에 명중
sub logMsLDSea1 {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행하여,${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 착탄. 해저가 깎였습니다.",$id, $tId);
}

# 육지 파괴탄, 기타의 지형에 명중
sub logMsLDLand {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행하여,${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 착탄. 육지가 수몰되었습니다.",$id, $tId);
}

# 일반 미사일, 황무지에 착탄
sub logMsWaste {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행했지만,${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 떨어졌습니다.",$id, $tId);
}

# 스텔스 미사일, 황무지에 착탄
sub logMsWasteS {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logSecret("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행했지만,${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 떨어졌습니다.",$id, $tId);
 logLate("<B>누군가</B>가${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행했지만,${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 떨어졌습니다.",$tId);
}

# 일반 미사일, 괴수에 명중, 경화 중에서 무사
sub logMsMonNoDamage {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행하여,${HtagName_}$tPoint${H_tagName}의<B>괴수$tLname</B>에 명중, 그러나 경화 상태였기 때문에 효과가 없었습니다.",$id, $tId);
}

# 스텔스 미사일, 괴수에 명중, 경화 중에서 무사
sub logMsMonNoDamageS {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logSecret("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행하여,${HtagName_}$tPoint${H_tagName}의<B>괴수$tLname</B>에 명중, 그러나 경화 상태였기 때문에 효과가 없었습니다.",$id, $tId);
 logOut("<B>누군가</B>가${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행하여,${HtagName_}$tPoint${H_tagName}의<B>괴수$tLname</B>에 명중, 그러나 경화 상태였기 때문에 효과가 없었습니다.",$tId);
}

# 일반 미사일, 괴수에 명중, 살상
sub logMsMonKill {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행하여,${HtagName_}$tPoint${H_tagName}의<B>괴수$tLname</B>에 명중.<B>괴수$tLname</B>은 힘이 다해 쓰러졌습니다.",$id, $tId);
}

# 스텔스 미사일, 괴수에 명중, 살상
sub logMsMonKillS {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logSecret("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행하여,${HtagName_}$tPoint${H_tagName}의<B>괴수$tLname</B>에 명중.<B>괴수$tLname</B>은 힘이 다해 쓰러졌습니다.",$id, $tId);
 logLate("<B>누군가</B>가${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행하여,${HtagName_}$tPoint${H_tagName}의<B>괴수$tLname</B>에 명중.<B>괴수$tLname</B>은 힘이 다해 쓰러졌습니다.", $tId);
}

# 일반 미사일, 괴수에 명중, 피해
sub logMsMonster {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행하여,${HtagName_}$tPoint${H_tagName}의<B>괴수$tLname</B>에 명중.<B>괴수$tLname</B>은 고통스러운 듯 포효했습니다.",$id, $tId);
}

# 스텔스 미사일, 괴수에 명중, 피해
sub logMsMonsterS {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logSecret("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행하여,${HtagName_}$tPoint${H_tagName}의<B>괴수$tLname</B>에 명중.<B>괴수$tLname</B>은 고통스러운 듯 포효했습니다.",$id, $tId);
 logLate("<B>누군가</B>가${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행하여,${HtagName_}$tPoint${H_tagName}의<B>괴수$tLname</B>에 명중.<B>괴수$tLname</B>은 고통스러운 듯 포효했습니다.",$tId);
}

# 괴수의 시체
sub logMsMonMoney {
 my($tId, $mName, $value) = @_;
 logOut("<B>괴수$mName</B>의 잔해에는,<B>$value$HunitMoney</B>의 값어치가 있었습니다.",$tId);
}

# 일반 미사일카운트
sub logMsCount {
 my($id, $tId, $name, $tName, $comName, $mCount, $nCount, $point) = @_;
 logOut("<B>군사보고 </B>${HtagName_}${name}국${H_tagName}이${HtagName_}${tName}국$point${H_tagName}지점을 향해합계<B>$mCount 회</B>의${HtagComName_}${comName}${H_tagComName}을 실행했습니다.(무 피해 수<B>$nCount 회</B>)",$id, $tId);
}

# 일반 미사일 일반 지형에 명중
sub logMsNormal {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행하여,${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 명중, 일대가 괴멸되었습니다.",$id, $tId);
}

# 스텔스 미사일 일반 지형에 명중
sub logMsNormalS {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logSecret("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행하여,${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 명중, 일대가 괴멸되었습니다.",$id, $tId);
 logLate("<B>누군가</B>가${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행하여,${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 명중, 일대가 괴멸되었습니다.",$tId);
}

# 난민 도착
sub logMsBoatPeople {
 my($id, $name, $achive) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}에어디선가<B>$achive${HunitPop}명의 난민</B>이 표류해 왔습니다.${HtagName_}${name} 섬${H_tagName}은 살기 좋아진 것 같습니다.",$id);
}

# 괴수 파견
sub logMonsSend {
 my($id, $tId, $name, $tName) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}이<B>인공괴수</B>를 만들었습니다.${HtagName_}${tName} 섬${H_tagName}로 보냈습니다.",$id, $tId);
}

# 자금 조달
sub logDoNothing {
 my($id, $name, $comName) = @_;
# logOut("${HtagName_}${name} 섬${H_tagName}에서${HtagComName_}${comName}${H_tagComName}이 실행되었습니다.",$id);
}

# 수출
sub logSell {
 my($id, $name, $comName, $value) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}이<B>$value$HunitFood</B>의${HtagComName_}${comName}${H_tagComName}을 실행했습니다.",$id);
}

# 지원
sub logAid {
 my($id, $tId, $name, $tName, $comName, $str) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬${H_tagName}로<B>$str</B>의${HtagComName_}${comName}${H_tagComName}을 실행했습니다.",$id, $tId);
}

# 공격금지
sub logNotAvail {
 my($id, $name, $comName) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}에서 예정되어 있던${HtagComName_}${comName}${H_tagComName}은규정에 따라 중지되었습니다.",$id);
}

# 유치 활동
sub logPropaganda {
 my($id, $name, $comName) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}에서${HtagComName_}${comName}${H_tagComName}이 실행되었습니다.",$id);
}

# 포기
sub logGiveup {
 my($id, $name) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}은 포기되어 <B>무인 섬</B>이 되었습니다.",$id);
 logHistory("${HtagName_}${name} 섬${H_tagName}, 포기되어 <B>무인 섬</B>이 됩니다.");
}

# 사멸
sub logDead {
 my($id, $name) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}에서 주민이 사라져 <B>무인 섬</B>이 되었습니다.",$id);
 logHistory("${HtagName_}${name} 섬${H_tagName}, 주민이 사라져 <B>무인 섬</B>이 됩니다.");
}

# 사멸
sub logTDead {
 my($id, $name) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}은,<B>침몰</B>시흔적도 없이 사라졌습니다.",$id);
 logHistory("${HtagName_}${name} 섬${H_tagName},<B>침몰</B>하다.");
}

# 강제 삭제
sub logDeleteIsland {
 my($id, $name) = @_;
 logHistory("${HtagName_}${name} 섬${H_tagName}, 관리자 권한으로<B>퇴장</B>이 됩니다.");
}

# 발견
sub logDiscover {
 my($name) = @_;
 logHistory("${HtagName_}${name} 섬${H_tagName}이 발견됩니다.");
}

# 이름의 변경
sub logChangeName {
 my($name1, $name2) = @_;
 logHistory("${HtagName_}${name1} 섬${H_tagName}, 명칭을${HtagName_}${name2} 섬${H_tagName}에 변경.");
}

# 기아
sub logStarve {
 my($id, $name) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}의${HtagDisaster_}식량이 부족${H_tagDisaster}하고 있습니다!!",$id);
}

# 괴수 출현
sub logMonsCome {
 my($id, $name, $mName, $point, $lName) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}에<B>괴수$mName</B> 출현!!${HtagName_}$point${H_tagName}의<B>$lName</B>이 짓밟혀 파괴되었습니다.",$id);
}

# 괴수 이동
sub logMonsMove {
 my($id, $name, $lName, $point, $mName) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>이<B>괴수$mName</B>에게 짓밟혀 파괴되었습니다.",$id);
}

# 괴수는 방위 시설을 밟지 않음
sub logMonsMoveDefence {
 my($id, $name, $lName, $point, $mName) = @_;
 logOut("<B>괴수$mName</B>이${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>로 도달,<B>${lName}의 자폭장치가 작동!!</B>",$id);
}

# 화재
sub logFire {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>이${HtagDisaster_}화재${H_tagDisaster}로 괴멸되었습니다.",$id);
}

# 매장금
sub logMaizo {
 my($id, $name, $comName, $value) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}에서 ${HtagComName_}$comName${H_tagComName} 중에,<B>$value$HunitMoney 상당의 매장금</B>을 발견했습니다.",$id);
}

# 지진발생
sub logEarthquake {
 my($id, $name) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}로 대규모${HtagDisaster_}지진${H_tagDisaster}이 발생!!",$id);
}

# 지진 피해
sub logEQDamage {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>은${HtagDisaster_}지진${H_tagDisaster}으로 괴멸되었습니다.",$id);
}

# 식량 부족 피해
sub logSvDamage {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>에<B>식량을 찾는 주민이 몰려들었습니다</B>.<B>$lName</B>은 괴멸되었습니다.",$id);
}

# 쓰나미발생
sub logTsunami {
 my($id, $name) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}부근에서${HtagDisaster_}쓰나미${H_tagDisaster} 발생!!",$id);
}

# 쓰나미 피해
sub logTsunamiDamage {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>은${HtagDisaster_}쓰나미${H_tagDisaster}로 붕괴했습니다.",$id);
}

# 태풍발생
sub logTyphoon {
 my($id, $name) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}에${HtagDisaster_}태풍${H_tagDisaster} 상륙!!",$id);
}

# 태풍 피해
sub logTyphoonDamage {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>은${HtagDisaster_}태풍${H_tagDisaster}으로 날아갔습니다.",$id);
}

# 운석, 바다
sub logMeteoSea {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>에${HtagDisaster_}운석${H_tagDisaster}이 낙하했습니다.",$id);
}

# 운석, 산
sub logMeteoMountain {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>에${HtagDisaster_}운석${H_tagDisaster}이 낙하,<B>$lName</B>은 사라졌습니다.",$id);
}

# 운석, 해저 기지
sub logMeteoSbase {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>에${HtagDisaster_}운석${H_tagDisaster}이 낙하,<B>$lName</B>은 붕괴했습니다.",$id);
}

# 운석, 괴수
sub logMeteoMonster {
 my($id, $name, $lName, $point) = @_;
 logOut("<B>괴수$lName</B>이 있던${HtagName_}${name} 섬 $point${H_tagName}지점에${HtagDisaster_}운석${H_tagDisaster}이 낙하, 육지는<B>괴수 $lName</B>까지 수몰되었습니다.",$id);
}

# 운석, 얕은 바다
sub logMeteoSea1 {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}지점에${HtagDisaster_}운석${H_tagDisaster}이 낙하, 해저가 깎였습니다.",$id);
}

# 운석, 기타
sub logMeteoNormal {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}지점의<B>$lName</B>에${HtagDisaster_}운석${H_tagDisaster}이 낙하, 일대가 수몰되었습니다.",$id);
}

# 운석, 기타
sub logHugeMeteo {
 my($id, $name, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}지점에${HtagDisaster_}거대운석${H_tagDisaster}이 낙하!!",$id);
}

# 분화
sub logEruption {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}지점에서${HtagDisaster_}화산이 분화${H_tagDisaster},<B>산</B>이 생겼습니다.",$id);
}

# 분화, 얕은 바다
sub logEruptionSea1 {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}지점의<B>$lName</B>은,${HtagDisaster_}분화${H_tagDisaster}의 영향으로 육지가 되었습니다.",$id);
}

# 분화, 바다 or 바다 기준
sub logEruptionSea {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}지점의<B>$lName</B>은,${HtagDisaster_}분화${H_tagDisaster}의 영향으로 해저가 융기하여, 얕은 바다가 되었습니다.",$id);
}

# 분화, 기타
sub logEruptionNormal {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}지점의<B>$lName</B>은,${HtagDisaster_}분화${H_tagDisaster}의 영향으로 괴멸되었습니다.",$id);
}

# 공격금지
sub logNoNB {
 my($id, $name, $comName) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}에서 예정되어 있던${HtagComName_}${comName}${H_tagComName}은나파무탄을 소유하고 있지 않아서 중지되었습니다.",$id);
}

# 스나이파탄
sub logNB {
 my($id, $tId, $name, $tName, $comName, $tLname, $point) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행하여,<B>$tLname</B>은 한순간에 <B>황무지</B>가 되었습니다.",$id, $tId);
}

# 스나이파탄의미무시
sub logNBfail {
 my($id, $tId, $name, $tName, $comName, $tLname, $point) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행했지만,<B>$tLname</B>되었습니다.",$id, $tId);
}

# 스나이파탄, 일반
sub logNBN {
 my($id, $tId, $tName, $tLname, $point) = @_;
 logOut("${HtagName_}${tName} 섬 $point${H_tagName}지점의,<B>$tLname</B>은, 한순간에 <B>황무지</B>가 되었습니다.",$id, $tId);
}

# 지반 침하발생
sub logFalldown {
 my($id, $name) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}에서${HtagDisaster_}지반 침하${H_tagDisaster}가 발생했습니다!!",$id);
}

# 지반 침하 피해
sub logFalldownLand {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>은 바다의 안로 침몰봄했습니다.",$id);
}

# 광역 피해, 수몰
sub logWideDamageSea {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>은<B>수몰</B>했습니다.",$id);
}

# 광역 피해, 바다의 건설
sub logWideDamageSea2 {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>은 흔적도 없이 사라졌습니다.",$id);
}

# 광역 피해, 괴수수몰
sub logWideDamageMonsterSea {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의 육지는<B>괴수 $lName</B>까지 수몰되었습니다.",$id);
}

# 광역 피해, 괴수
sub logWideDamageMonster {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>괴수$lName</B>은 사라졌습니다.",$id);
}

# 광역 피해, 황무지
sub logWideDamageWaste {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>은 한순간에 <B>황무지</B>가 되었습니다.",$id);
}

# 수상
sub logPrize {
 my($id, $name, $pName) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}이<B>$pName</B>을 수상했습니다.",$id);
 logHistory("${HtagName_}${name} 섬${H_tagName},<B>$pName</B>을 수상");
}

# 섬이 가득 찬 경우
sub tempNewIslandFull {
 out(<<END);
${HtagBig_}신청이 몰려, 섬이 가득 차서 등록할 수 없습니다.${H_tagBig}$HtempBack
END
}

# 신규 등록 시 이름이 없는 경우
sub tempNewIslandNoName {
 out(<<END);
${HtagBig_} 섬 이름이 필요합니다.${H_tagBig}$HtempBack
END
}

# 신규 등록 시 이름이 올바르지 않은 경우
sub tempNewIslandBadName {
 out(<<END);
${HtagBig_}',?()<>\$'가 들어 있거나'무인 섬''어딘가의 섬'라예름은 사용할 수 없습니다.${H_tagBig}$HtempBack
END
}

# 이미 같은 이름의 섬이 있는 경우
sub tempNewIslandAlready {
 out(<<END);
${HtagBig_}그 섬이면 이미 발견되어 있습니다.${H_tagBig}$HtempBack
END
}

# 비밀번호가 없는 경우
sub tempNewIslandNoPassword {
 out(<<END);
${HtagBig_} 비밀번호가필요입니다.${H_tagBig}$HtempBack
END
}

# 섬을 발견했습니다!!
sub tempNewIslandHead {
 out(<<END);
<CENTER>
${HtagBig_} 섬을 발견했습니다!!${H_tagBig}<BR>
${HtagBig_}${HtagName_}'${HcurrentName} 섬'${H_tagName}을 찾았습니다.${H_tagBig}<BR>
$HtempBack<BR>
</CENTER>
END
}

# 지형의 호출분
sub landName {
 my($land, $lv) = @_;
 if($land == $HlandSea) {
	if($lv == 1) {
 return '얕은 바다';
 } else {
 return '바다';
	}
 } elsif($land == $HlandWaste) {
	return '황무지';
 } elsif($land == $HlandPlains) {
	return '평지';
 } elsif($land == $HlandTown) {
	if($lv < 30) {
	 return '마을';
	} elsif($lv < 100) {
	 return '마을';
	} else {
	 return '도시';
	}
 } elsif($land == $HlandForest) {
	return '숲';
 } elsif($land == $HlandFarm) {
	return '농장';
 } elsif($land == $HlandFactory) {
	return '공장';
 } elsif($land == $HlandPond) {
	return '수원';
 } elsif($land == $HlandBase) {
	return '미사일 기지';
 } elsif($land == $HlandDefence) {
	return '방위 시설';
 } elsif($land == $HlandMountain) {
	return '산';
 } elsif($land == $HlandMonster) {
	my($kind, $name, $hp) = monsterSpec($lv);
	return $name;
 } elsif($land == $HlandSbase) {
	return '해저 기지';
 } elsif($land == $HlandOil) {
	return '해저 유전';
 } elsif($land == $HlandMonument) {
	return $HmonumentName[$lv];
 } elsif($land == $HlandHaribote) {
	return '가짜 시설';
 }
}

# 인구기타의 값을 산출
sub estimate {
 my($number) = $_[0];
 my($island);
 my($pop, $area, $farm, $factory, $mountain, $burnmis, $pond) = (0, 0, 0, 0, 0, 0, 0);

 # 지형을 가져옴
 $island = $Hislands[$number];
 my($land) = $island->{'land'};
 my($landValue) = $island->{'landValue'};

 # 수 가능
 my($x, $y, $kind, $value);
 for($y = 0; $y < $HislandSize; $y++) {
	for($x = 0; $x < $HislandSize; $x++) {
	 $kind = $land->[$x][$y];
	 $value = $landValue->[$x][$y];
	 if(($kind != $HlandSea) &&
	 ($kind != $HlandSbase) &&
	 ($kind != $HlandOil)){$area++;}
	 if(($kind != $HlandSea) &&
	 ($kind != $HlandOil)){
		if($kind == $HlandTown) {
		 # 마을
		 $pop += $value;
		} elsif($kind == $HlandFarm) {
		 # 농장
		 $farm += $value;
		} elsif($kind == $HlandFactory) {
		 # 공장
		 $factory += $value;
		} elsif($kind == $HlandMountain) {
		 # 산
		 $mountain += $value;
		} elsif(($kind == $HlandBase)||($kind == $HlandSbase)) {
		 # 미사일 기지
		 $burnmis += expToLevel($kind, $value);
		} elsif($kind == $HlandPond) {
		 # 수원
		 $pond += $value;
		}
	 }
	}
 }

 # 대입
 $island->{'pop'} = $pop;
 $island->{'area'} = $area;
 $island->{'farm'} = $farm;
 $island->{'factory'} = $factory;
 $island->{'mountain'} = $mountain;
 $island->{'fire'} = $burnmis;
 $island->{'pond'} = $pond;
}


# 범위 안의 지형을 수 가능
sub countAround {
 my($land, $x, $y, $kind, $range) = @_;
 my($i, $count, $sx, $sy);
 $count = 0;
 for($i = 0; $i < $range; $i++) {
	 $sx = $x + $ax[$i];
	 $sy = $y + $ay[$i];

	 # 행 기준 위치 조정
	 if((($sy % 2) == 0) && (($y % 2) == 1)) {
	 $sx--;
	 }

	 if(($sx < 0) || ($sx>= $HislandSize) ||
	 ($sy < 0) || ($sy>= $HislandSize)) {
	 # 범위 밖의 경우
	 if($kind == $HlandSea) {
		 # 바다이면 가 산
		 $count++;
	 }
	 } else {
	 # 범위 안의 경우
	 if($land->[$sx][$sy] == $kind) {
		 $count++;
	 }
	 }
 }
 return $count;
}

# 0에서(n - 1)까지의 숫자가한 번씩출해 옵니다 수열을 만들기
sub randomArray {
 my($n) = @_;
 my(@list, $i);

 # 초기 값
 if($n == 0) {
	$n = 1;
 }
 @list = (0..$n-1);

 # 셔터 전체
 for ($i = $n; --$i; ) {
	my($j) = int(rand($i+1));
	if($i == $j) { next; };
	@list[$i,$j] = @list[$j,$i];
 }

 return @list;
}

# 이름 변경실패
sub tempChangeNothing {
 out(<<END);
${HtagBig_}이름과 비밀번호가 모두 비어 있습니다${H_tagBig}$HtempBack
END
}

# 이름 변경 자금 부족
sub tempChangeNoMoney {
 out(<<END);
${HtagBig_} 자금 부족으로 변경할 수 없습니다${H_tagBig}$HtempBack
END
}

# 이름 변경성공
sub tempChange {
 out(<<END);
${HtagBig_}변경을 완료했습니다${H_tagBig}$HtempBack
END
}

1;



