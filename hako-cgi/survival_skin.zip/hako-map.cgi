#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}
#----------------------------------------------------------------------
# 모형정원 제도 ver2.30
# 지도 모드 모듈(ver1.00)
# 사용 조건과 사용 방법은 hako-readme.txt 파일을 참조해 주세요
#
# 모형정원 제도의 페이지: http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html
#----------------------------------------------------------------------


#----------------------------------------------------------------------
# 관광 모드
#----------------------------------------------------------------------
# 메인
sub printIslandMain {
 # 개방
 unlock();

 # id에서 섬 번호를 가져옴
 $HcurrentNumber = $HidToNumber{$HcurrentID};

 # 왠지그 섬이 없는 경우
 if($HcurrentNumber eq '') {
	tempProblem();
	return;
 }

 # 이름 가져오기
 $HcurrentName = $Hislands[$HcurrentNumber]->{'name'};

 # 관광 화면
 tempPrintIslandHead(); # 수 있도록 말로!!
 islandInfo(); # 섬의 정보
 islandMap(0); # 섬 지도, 관광 모드
 islandJamp();# 섬의 이동

 # ○○섬 로컬 게시판
 if($HuseLbbs) {
	out("<DIV ID='localBBS'>");
	tempLbbsHead(); # 로컬 게시판
	tempLbbsInput(); # 작성 양식
	tempLbbsContents(); # 게시판내용
	out("</DIV>");
 }

 # 최근 상황
 tempRecent(0);
}

#----------------------------------------------------------------------
# 개발 모드
#----------------------------------------------------------------------
# 메인
sub ownerMain {
 # 개방
 unlock();

 # 모드를 명시
 $HmainMode = 'owner';

 # id에서 섬을 가져옴
 $HcurrentNumber = $HidToNumber{$HcurrentID};
 my($island) = $Hislands[$HcurrentNumber];
 $HcurrentName = $island->{'name'};

 # 비밀번호
 if(!checkPassword($island->{'password'},$HinputPassword)) {
	# password 오류
	tempWrongPassword();
	return;
 }

 # 개발 화면
	if($HjavaMode eq 'java') {
	 tempOwnerJava(); # 'JavaScript개발계획'
	}else{ # '일반 모드개발계획'
		tempOwner();
	}

 # ○○섬 로컬 게시판
 if($HuseLbbs) {
	out("<DIV ID='localBBS'>");
	tempLbbsHead(); # 로컬 게시판
		if($HjavaMode eq 'java') { # JavaScript용작성 양식
			tempLbbsInputJava();
		}else{ tempLbbsInputOW(); } # 일반 모드의 작성 양식
	tempLbbsContents(); # 게시판내용
	out("</DIV>");
 }

 # 최근 상황
 tempRecent(1);
}

#----------------------------------------------------------------------
# 명령 모드
#----------------------------------------------------------------------
# 메인
sub commandMain {
 # id에서 섬을 가져옴
 $HcurrentNumber = $HidToNumber{$HcurrentID};
 my($island) = $Hislands[$HcurrentNumber];
 $HcurrentName = $island->{'name'};

 # 비밀번호
 if(!checkPassword($island->{'password'},$HinputPassword)) {
	# password 오류
	unlock();
	tempWrongPassword();
	return;
 }

 # 모드에서 분기
 my($command) = $island->{'command'};

 if($HcommandMode eq 'delete') {
	slideFront($command, $HcommandPlanNumber);
	tempCommandDelete();
 } elsif(($HcommandKind == $HcomAutoPrepare) ||
 ($HcommandKind == $HcomAutoReclaim) ||
	 ($HcommandKind == $HcomAutoPrepare2)) {
	# 전체 개간, 전체땅고르기, 전체매립
	# 좌표배열을 만들기
	makeRandomPointArray();
	my($land) = $island->{'land'};

		# 전체 자동 입력은 기존 명령 아래의 첫 빈 슬롯부터 추가한다.
		if($HcommandPlanNumber !~ /^[0-9]+$/) {
			my($emptyNo) = $HcommandMax - 1;
			for(my $pi = 0; $pi < $HcommandMax; $pi++) {
				if($command->[$pi]->{'kind'} == $HcomDoNothing) {
					$emptyNo = $pi;
					last;
				}
			}
			$HcommandPlanNumber = $emptyNo;
		}

	# 자동 입력 시작 위치 보정: 지정이 없으면 기존 명령 아래 첫 빈 슬롯부터 추가
	if($HcommandPlanNumber !~ /^[0-9]+$/) {
		my($emptyNo) = $HcommandMax - 1;
		for(my $pi = 0; $pi < $HcommandMax; $pi++) {
			if($command->[$pi]->{'kind'} == $HcomDoNothing) { $emptyNo = $pi; last; }
		}
		$HcommandPlanNumber = $emptyNo;
	}

	# 명령 종류결정
	my($kind) = $HcomPrepare;
	if($HcommandKind == $HcomAutoPrepare2) {
	 $kind = $HcomPrepare2;
	}elsif($HcommandKind == $HcomAutoReclaim){
	 $kind = $HcomReclaim;
	}

	my($i) = 0;
	my($j) = 0;
	while(($j < $HpointNumber) && ($i < $HcommandMax)) {
	 my($x) = $Hrpx[$j];
	 my($y) = $Hrpy[$j];
		my($landValue) = $island->{'landValue'};
		my($lv) = $landValue->[$x][$y];
 	if(($HcommandKind == $HcomAutoPrepare) ||
	 ($HcommandKind == $HcomAutoPrepare2)) {
	 if($land->[$x][$y] == $HlandWaste) {
		slideBack($command, $HcommandPlanNumber);
		$command->[$HcommandPlanNumber] = {
		 'kind' => $kind,
		 'target' => 0,
		 'x' => $x,
		 'y' => $y,
		 'arg' => 0
		 };
		$i++;
	 }
	 }else{
 		if(($land->[$x][$y] == $HlandSea) && ($lv == 1)){
		slideBack($command, $HcommandPlanNumber);
		$command->[$HcommandPlanNumber] = {
		 'kind' => $kind,
		 'target' => 0,
		 'x' => $x,
		 'y' => $y,
		 'arg' => 0
		 };
		$i++;
	 }
		}
	 $j++;
	}
	tempCommandAdd();
 } elsif($HcommandKind == $HcomAutoDelete) {
	# 전체 삭제
	my($i);
	for($i = 0; $i < $HcommandMax; $i++) {
	 slideFront($command, $HcommandPlanNumber);
	}
	tempCommandDelete();
 } elsif($HcommandKind == $HcomAutoReclaim2 || $HcommandKind == $HcomAutoReclaim3) {
		# 매립 + 개간(땅고르기)
		if($HcommandKind == $HcomAutoReclaim3) {
		 $kind = $HcomPrepare2;
		}elsif($HcommandKind == $HcomAutoReclaim2){
	 	$kind = $HcomPrepare;
		}
 	my($x) = $HcommandX;
 	my($y) = $HcommandY;
		slideBack($command, $HcommandPlanNumber);
		$command->[$HcommandPlanNumber] = {
	 	'kind' => $kind,
	 	'target' => $HcommandTarget,
	 	'x' => $HcommandX,
	 	'y' => $HcommandY,
	 	'arg' => $HcommandArg
	 };
 	$kind = $HcomReclaim;
		slideBack($command, $HcommandPlanNumber);
		$command->[$HcommandPlanNumber] = {
	 	'kind' => $kind,
	 	'target' => $HcommandTarget,
	 	'x' => $HcommandX,
	 	'y' => $HcommandY,
	 	'arg' => $HcommandArg
	 };
		my($landValue) = $island->{'landValue'};
		my($lv) = $landValue->[$x][$y];
 	if(($land->[$x][$y] == $HlandSea) && ($lv != 1)) {
	 	$kind = $HcomReclaim;
			slideBack($command, $HcommandPlanNumber);
			$command->[$HcommandPlanNumber] = {
		 	'kind' => $kind,
	 		'target' => $HcommandTarget,
	 		'x' => $HcommandX,
	 		'y' => $HcommandY,
	 		'arg' => $HcommandArg
	 	};
		}
		tempCommandAdd();
 } elsif($HcommandKind == $HcomAutoComPlant || $HcommandKind == $HcomAutoComPlant2) {
		# 개간(땅고르기)+ 나무심기
 	$kind = $HcomPlant;
		slideBack($command, $HcommandPlanNumber);
		$command->[$HcommandPlanNumber] = {
	 	'kind' => $kind,
	 	'target' => $HcommandTarget,
	 	'x' => $HcommandX,
	 	'y' => $HcommandY,
	 	'arg' => $HcommandArg
	 };
		if($HcommandKind == $HcomAutoComPlant2) {
		 $kind = $HcomPrepare2;
		}elsif($HcommandKind == $HcomAutoComPlant){
	 	$kind = $HcomPrepare;
		}
 	my($x) = $HcommandX;
 	my($y) = $HcommandY;
		slideBack($command, $HcommandPlanNumber);
		$command->[$HcommandPlanNumber] = {
	 	'kind' => $kind,
	 	'target' => $HcommandTarget,
	 	'x' => $HcommandX,
	 	'y' => $HcommandY,
	 	'arg' => $HcommandArg
	 };
		tempCommandAdd();
 } else {
	if($HcommandMode eq 'insert') {
	 slideBack($command, $HcommandPlanNumber);
	}
	tempCommandAdd();
	# 명령을 등록
	$command->[$HcommandPlanNumber] = {
	 'kind' => $HcommandKind,
	 'target' => $HcommandTarget,
	 'x' => $HcommandX,
	 'y' => $HcommandY,
	 'arg' => $HcommandArg
	 };
 }

 # 데이터 쓰기
 writeIslandsFile($HcurrentID);

 # owner mode 로
 ownerMain();

}

#----------------------------------------------------------------------
# 코멘트입력 모드
#----------------------------------------------------------------------
# 메인
sub commentMain {
 # id에서 섬을 가져옴
 $HcurrentNumber = $HidToNumber{$HcurrentID};
 my($island) = $Hislands[$HcurrentNumber];
 $HcurrentName = $island->{'name'};

 # 비밀번호
 if(!checkPassword($island->{'password'},$HinputPassword)) {
	# password 오류
	unlock();
	tempWrongPassword();
	return;
 }

 # 메시지를 갱신
 $island->{'comment'} = htmlEscape($Hmessage);

 # 데이터 쓰기
 writeIslandsFile($HcurrentID);

 # 코멘트갱신 메시지
 tempComment();

 # owner mode 로
 ownerMain();
}

#----------------------------------------------------------------------
# 로컬 게시판 모드
#----------------------------------------------------------------------
# 메인

sub localBbsMain {
 # id에서 섬 번호를 가져옴
 $HcurrentNumber = $HidToNumber{$HcurrentID};
 my($island) = $Hislands[$HcurrentNumber];

 # 왠지그 섬이 없는 경우
 if($HcurrentNumber eq '') {
	unlock();
	tempProblem();
	return;
 }

 # 삭제 모드가 아니고 이름이나 메시지가 없는 경우
 if($HlbbsMode != 2) {
	if(($HlbbsName eq '') || ($HlbbsName eq '')) {
	 unlock();
	 tempLbbsNoMessage();
	 return;
	}
 }

 # 관광객 모드가 아닐 시는 비밀번호 확인
 if($HlbbsMode != 0) {
	if(!checkPassword($island->{'password'},$HinputPassword)) {
	 # password 오류
	 unlock();
	 tempWrongPassword();
	 return;
	}
 }

 my($lbbs);
 $lbbs = $island->{'lbbs'};

 # 모드에서 분기
 if($HlbbsMode == 2) {
	# 삭제 모드
	# 메시지를 앞으로 당기기
	slideBackLbbsMessage($lbbs, $HcommandPlanNumber);
	tempLbbsDelete();
 } else {
	# 기장 모드
	# 메시지를 뒤에밀기
	slideLbbsMessage($lbbs);

	# 메시지 쓰기
	my($message);
	if($HlbbsMode == 0) {
	 $message = '0';
	} else {
	 $message = '1';
	}
	$HlbbsName = "$HislandTurn:". htmlEscape($HlbbsName);
	$HlbbsMessage = htmlEscape($HlbbsMessage);
	$lbbs->[0] = "$message>$HlbbsName>$HlbbsMessage <font size=2>($ENV{'REMOTE_ADDR'})</font>";

	tempLbbsAdd();
 }

 # 데이터 쓰기
 writeIslandsFile($HcurrentID);

 # 원래의 모드로
 if($HlbbsMode == 0) {
	printIslandMain();
 } else {
	ownerMain();
 }
}

# 로컬 게시판의 메시지를 하나뒤에밀기
sub slideLbbsMessage {
 my($lbbs) = @_;
 my($i);
# pop(@$lbbs);
# push(@$lbbs, $lbbs->[0]);
 pop(@$lbbs);
 unshift(@$lbbs, $lbbs->[0]);
}

# 로컬 게시판의 메시지를 하나앞으로 당기기
sub slideBackLbbsMessage {
 my($lbbs, $number) = @_;
 my($i);
 splice(@$lbbs, $number, 1);
 $lbbs->[$HlbbsMax - 1] = '0>>';
}

#----------------------------------------------------------------------
# 섬 지도
#----------------------------------------------------------------------

# 정보의 표시
sub islandInfo {
 my($island) = $Hislands[$HcurrentNumber];
 # 정보 표시
 my($rank) = $HcurrentNumber + 1;
 my($farm) = $island->{'farm'};
 my($factory) = $island->{'factory'};
 my($mountain) = $island->{'mountain'};
 my($pond) = $island->{'pond'};
 $farm = ($farm == 0) ? "보유하지 않음" : "${farm}0$HunitPop";
 $factory = ($factory == 0) ? "보유하지 않음" : "${factory}0$HunitPop";
 $mountain = ($mountain == 0) ? "보유하지 않음" : "${mountain}0$HunitPop";
 $pond = ($pond == 0) ? "보유하지 않음" : "${pond}000리와 루";

 my($mStr1) = '';
 my($mStr2) = '';
 if(($HhideMoneyMode == 1) || ($HmainMode eq 'owner')) {
	# 무조건또는 owner 모드
	$mStr1 = "<TH $HbgTitleCell>${HtagTH_} 자금${H_tagTH}</TH>";
	$mStr2 = "<TD $HbgInfoCell align=right>$island->{'money'}$HunitMoney</TD>";
 } elsif($HhideMoneyMode == 2) {
	my($mTmp) = aboutMoney($island->{'money'});

	# 1000억단위 모드
	$mStr1 = "<TH $HbgTitleCell>${HtagTH_} 자금${H_tagTH}</TH>";
	$mStr2 = "<TD $HbgInfoCell align=right>$mTmp</TD>";
 }

 my($remainTime, $rtStr);
	$remainTime = $HunitTime - time() + $HislandLastTime;
	$rtStr = "다음갱신 시간까지";
	$rtStr.= int($remainTime / 3600). "시간";
	$rtStr.= int(($remainTime % 3600) / 60). "분";
	$rtStr.= $remainTime % 60 . "초";

 out(<<END);
<DIV ID='islandInfo'>
<DIV ID=nexttime>턴$HislandTurn
($rtStr)</DIV>
<TABLE BORDER>
<TR>
<TH $HbgTitleCell>${HtagTH_}순위${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}인구${H_tagTH}</TH>
$mStr1
<TH $HbgTitleCell>${HtagTH_}식량${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}면적${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}농장규모/수원규모${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}공장규모${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}채굴장규모${H_tagTH}</TH>

</TR>
<TR>
<TD $HbgNumberCell align=middle>${HtagNumber_}$rank${H_tagNumber}</TD>
<TD $HbgInfoCell align=right>$island->{'pop'}$HunitPop</TD>
$mStr2
<TD $HbgInfoCell align=right>$island->{'food'}$HunitFood</TD>
<TD $HbgInfoCell align=right>$island->{'area'}$HunitArea</TD>
<TD $HbgInfoCell align=right>${farm}/${pond}</TD>
<TD $HbgInfoCell align=right>${factory}</TD>
<TD $HbgInfoCell align=right>${mountain}</TD>
</TR>
</TABLE>
<br>
<TABLE BORDER>
<TR>
<TH $HbgTitleCell>${HtagTH_}소유스나이파탄${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}M발사${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}M발사(합계)${H_tagTH}</TH>
<TH $HbgTitleCell>${HtagTH_}M피격${H_tagTH}</TH>
</TR>
<TR>
<TD $HbgInfoCell align=right>$island->{'nowNB'}발</TD>
<TD $HbgInfoCell align=right>$island->{'MOUT'}발</TD>
<TD $HbgInfoCell align=right>$island->{'totalMOUT'}발</TD>
<TD $HbgInfoCell align=right>$island->{'MIN'}발</TD>
</TR>
</TABLE>

</DIV>
END
}

# 지도 표시
# 인 수가1이면, 미사일 기지등을 그대로 표시
sub islandMap {
 my($mode) = @_;
 my($island);
 $island = $Hislands[$HcurrentNumber];

 out(<<END);
<DIV ID='islandMap'><TABLE BORDER><TR><TD>
END
 # 지형, 지형 값을 가져옴
 my($land) = $island->{'land'};
 my($landValue) = $island->{'landValue'};
 my($l, $lv);

 # 명령 가져오기
 my($command) = $island->{'command'};
 my($com, @comStr, $i);
 if($HmainMode eq 'owner') {
	for($i = 0; $i < $HcommandMax; $i++) {
	 my($j) = $i + 1;
	 $com = $command->[$i];
	 if($com->{'kind'} < 20) {
		$comStr[$com->{'x'}][$com->{'y'}].=
		 " [${j}]$HcomName[$com->{'kind'}]";
	 }
	}
 }

 # 좌표(상)을 출력
 out("<IMG SRC=\"xbar.gif\" width=400 height=16><BR>");

 # 각 지형및 줄바꿈을 출력
 my($x, $y);
 for($y = 0; $y < $HislandSize; $y++) {
	# 짝 수행이면 번호 출력
 if(($y % 2) == 0) {
	 out("<IMG SRC=\"space${y}.gif\" width=16 height=32>");
	}

	# 각 지형을 출력
	for($x = 0; $x < $HislandSize; $x++) {
	 $l = $land->[$x][$y];
	 $lv = $landValue->[$x][$y];
	 landString($l, $lv, $x, $y, $mode, $comStr[$x][$y]);
	}

	# 홀 수행이면 번호 출력
 if(($y % 2) == 1) {
	 out("<IMG SRC=\"space${y}.gif\" width=16 height=32>");
	}

	# 줄바꿈을 출력
	out("<BR>");
 }
 out("</TD></TR></TABLE></DIV>\n");
}

sub landString {
 my($l, $lv, $x, $y, $mode, $comStr) = @_;
 my($point) = "($x,$y)";
 my($image, $alt);

 if($l == $HlandSea) {

	if($lv == 1) {
	 # 얕은 바다
	 $image = 'land14.gif';
	 $alt = '바다(얕은 바다)';
 } else {
 # 바다
	 $image = 'land0.gif';
	 $alt = '바다';
 }
 } elsif($l == $HlandWaste) {
	# 황무지
	if($lv == 1) {
	 $image = 'land13.gif'; # 착탄 지점
	 $alt = '황무지';
	} else {
	 $image = 'land1.gif';
	 $alt = '황무지';
	}
 } elsif($l == $HlandPlains) {
	# 평지
	$image = 'land2.gif';
	$alt = '평지';
 } elsif($l == $HlandForest) {
	# 숲
	if($mode == 1) {
	 $image = 'land6.gif';
	 $alt = "숲(${lv}$HunitTree)";
	} else {
	 # 관광객에게는 목장 수를 숨김
	 $image = 'land6.gif';
	 $alt = '숲';
	}
 } elsif($l == $HlandTown) {
	# 마을
	my($p, $n);
	if($lv < 30) {
	 $p = 3;
	 $n = '마을';
	} elsif($lv < 100) {
	 $p = 4;
	 $n = '마을';
	} else {
	 $p = 5;
	 $n = '도시';
	}

	$image = "land${p}.gif";
	$alt = "$n(${lv}$HunitPop)";
 } elsif($l == $HlandFarm) {
	if($mode == 0) {
	 # 관광객의 경우 숲인 척
	 $image = 'land6.gif';
	 $alt = '숲';
	} else {
	 # 농장
	 $image = 'land7.gif';
	 $alt = "농장(${lv}0${HunitPop}규모)";
	}
 } elsif($l == $HlandFactory) {
	if($mode == 0) {
	 # 관광객의 경우 숲인 척
	 $image = 'land6.gif';
	 $alt = '숲';
	} else {
	 # 공장
	 $image = 'land8.gif';
	 $alt = "공장(${lv}0${HunitPop}규모)";
	}
 } elsif($l == $HlandPond) {
	if($mode == 0) {
	 # 관광객의 경우 숲인 척
	 $image = 'land6.gif';
	 $alt = '숲';
	} else {
	 # 수원
	 $image = 'land17.gif';
	 $alt = "수원(${lv}000리와 루)";
	}
 } elsif($l == $HlandBase) {
	if($mode == 0) {
	 # 관광객의 경우 숲인 척
	 $image = 'land6.gif';
	 $alt = '숲';
	} else {
	 # 미사일 기지
	 my($level) = expToLevel($l, $lv);
	 $image = 'land9.gif';
	 $alt = "미사일 기지 (레벨 ${level}/경험치 $lv)";
	}
 } elsif($l == $HlandSbase) {
	# 해저 기지
	if($mode == 0) {
	 # 관광객의 경우 바다인 척
	 $image = 'land0.gif';
	 $alt = '바다';
	} else {
	 my($level) = expToLevel($l, $lv);
	 $image = 'land12.gif';
	 $alt = "해저 기지 (레벨 ${level}/경험치 $lv)";
	}
 } elsif($l == $HlandDefence) {
	if($mode == 0 && $HdBaseHide) {
	 # 관광객의 경우 숲인 척
	 $image = 'land6.gif';
	 $alt = '숲';
	} else {
		# 방위 시설
		$image = 'land10.gif';
		$alt = '방위 시설';
	}
 } elsif($l == $HlandHaribote) {
	# 가짜 시설
	$image = 'land10.gif';
	if($mode == 0) {
	 # 관광객에게는 방위 시설처럼 표시
	 $alt = '방위 시설';
	} else {
	 $alt = '가짜 시설';
	}
 } elsif($l == $HlandOil) {
	# 해저 유전
	$image = 'land16.gif';
	$alt = '해저 유전';
 } elsif($l == $HlandMountain) {
	# 산
	my($str);
	$str = '';
	if($lv> 0) {
	 $image = 'land15.gif';
	 $alt = "산(채굴장${lv}0${HunitPop}규모)";
	} else {
	 $image = 'land11.gif';
	 $alt = '산';
	}
 } elsif($l == $HlandMonument) {
	# 기념비
	$image = $HmonumentImage[$lv];
	$alt = $HmonumentName[$lv];
 } elsif($l == $HlandMonster) {
	# 괴수
	my($kind, $name, $hp) = monsterSpec($lv);
	my($special) = $HmonsterSpecial[$kind];
	$image = $HmonsterImage[$kind];

	# 경화 중?
	if((($special == 3) && (($HislandTurn % 2) == 1)) ||
	 (($special == 4) && (($HislandTurn % 2) == 0))) {
	 # 경화 중
	 $image = $HmonsterImage2[$kind];
	}
	$alt = "괴수$name(체력${hp})";
 }


 # JavaScript 을이용했습니다 표시
 out(qq#<A HREF="JavaScript:void(0);" #);
 # 개발 화면일 경우 좌표 설정
 if($mode != 0) {
	out("onclick=\"ps($x,$y)\" ");
 }
 out(qq#onMouseOver="status = '$point $alt $comStr'; return true;" onMouseOut="status = '';">#);
 out("<IMG SRC=\"$image\" ALT=\"$point $alt $comStr\" TITLE=\"$point $alt $comStr\" width=32 height=32 BORDER=0>");

 # 좌표 설정닫기지
 out("</A>");

}


#----------------------------------------------------------------------
# 템플릿기타
#----------------------------------------------------------------------
# 개별 로그 표시
sub logPrintLocal {
 my($mode) = @_;
 my($i);
 for($i = 0; $i < $HlogMax; $i++) {
	logFilePrint($i, $HcurrentID, $mode);
 }
}

# ○○섬으로 수 있도록 말로!!
sub tempPrintIslandHead {
 out(<<END);
<CENTER>
${HtagBig_}${HtagName_}'${HcurrentName} 섬'${H_tagName}되도록!!${H_tagBig}<BR>
$HtempBack<BR>
</CENTER>
END
}

# ○○섬개발계획
sub tempOwner {
 out(<<END);
<CENTER>
${HtagBig_}${HtagName_}${HcurrentName} 섬${H_tagName}개발계획${H_tagBig}<BR>
$HtempBack<BR>
</CENTER>
<SCRIPT Language="JavaScript">
<!--
function ps(x, y) {
 document.forms[0].elements[4].options[x].selected = true;
 document.forms[0].elements[5].options[y].selected = true;
 return true;
}

function ns(x) {
 document.forms[0].elements[2].options[x].selected = true;
 return true;
}

function jump(theForm, j_mode) {
	var sIndex = theForm.TARGETID.selectedIndex;
	var url = theForm.TARGETID.options[sIndex].value;
	if (url != "" ) window.open("$HthisFile?IslandMap=" +url+"&JAVAMODE="+j_mode, "", "menubar=yes,toolbar=no,location=no,directories=no,status=yes,scrollbars=yes,resizable=yes,width=450,height=630");
}
//-->
</SCRIPT>
END

 islandInfo();

 out(<<END);
<CENTER>
<TABLE BORDER>
<TR valign=top>
<TD $HbgInputCell>
<CENTER>
<FORM name="myForm" action="$HthisFile" method=POST>
<INPUT TYPE=submit VALUE="계획 전송" NAME=CommandButton$Hislands[$HcurrentNumber]->{'id'}>
<HR>
<B> 비밀번호</B></BR>
<INPUT TYPE=password NAME=PASSWORD VALUE="$HdefaultPassword">
<HR>
<B>계획번호</B><SELECT NAME=NUMBER>
END
 # 계획번호
 my($j, $i);
 for($i = 0; $i < $HcommandMax; $i++) {
	$j = $i + 1;
	out("<OPTION VALUE=$i>$j\n");
 }

 out(<<END);
</SELECT><BR>
<HR>
<B>개발계획</B><BR>
<SELECT NAME=COMMAND>
END

 #명령
 my($kind, $cost, $s);
 for($i = 0; $i < $HcommandTotal; $i++) {
	$kind = $HcomList[$i];
	$cost = $HcomCost[$kind];
	if($kind> 60) {
	 $cost = ''
	} elsif($cost == 0) {
	 $cost = '무료'
	} elsif($cost < 0) {
	 $cost = - $cost;
	 $cost.= $HunitFood;
	} else {
	 $cost.= $HunitMoney;
	}
	if($kind == $HdefaultKind) {
	 $s = 'SELECTED';
	} else {
	 $s = '';
	}
	if($kind < 60) {
	$set_cost = "($cost)";
	}else{
	$set_cost = "";
	}
	out("<OPTION VALUE=$kind $s>$HcomName[$kind]$set_cost\n");
 }

 out(<<END);
</SELECT>
<HR>
<B>좌표(</B>
<SELECT NAME=POINTX>

END
 for($i = 0; $i < $HislandSize; $i++) {
	if($i == $HdefaultX) {
	 out("<OPTION VALUE=$i SELECTED>$i\n");
 } else {
	 out("<OPTION VALUE=$i>$i\n");
 }
 }

 out(<<END);
</SELECT>, <SELECT NAME=POINTY>
END

 for($i = 0; $i < $HislandSize; $i++) {
	if($i == $HdefaultY) {
	 out("<OPTION VALUE=$i SELECTED>$i\n");
 } else {
	 out("<OPTION VALUE=$i>$i\n");
 }
 }
 out(<<END);
</SELECT><B>)</B>
<HR>
<B>수량</B><SELECT NAME=AMOUNT>
END

 # 수량
 for($i = 0; $i < 100; $i++) {
	out("<OPTION VALUE=$i>$i\n");
 }

 out(<<END);
</SELECT>
<HR>
<B>대상 섬</B>:
<B><A HREF=JavaScript:void(0); onClick="jump(myForm, '$HjavaMode')"> 표시 </A></B><BR>
<SELECT NAME=TARGETID>
$HtargetList<BR>
</SELECT>
<HR>
<B>동작</B><BR>
<INPUT TYPE=radio NAME=COMMANDMODE VALUE=insert CHECKED>삽입
<INPUT TYPE=radio NAME=COMMANDMODE VALUE=write>덮어쓰기<BR>
<INPUT TYPE=radio NAME=COMMANDMODE VALUE=delete>삭제
<HR>
<INPUT TYPE=submit VALUE="계획 전송" NAME=CommandButton$Hislands[$HcurrentNumber]->{'id'}>

</CENTER>
</FORM>
<center>미사일 발사상한 수[<b> $Hislands[$HcurrentNumber]->{'fire'} </b>]발</center>
</TD>
<TD $HbgMapCell>
END
 islandMap(1); # 섬 지도, 소유자 모드
 out(<<END);
</TD>
<TD $HbgCommandCell>
END
 for($i = 0; $i < $HcommandMax; $i++) {
	tempCommand($i, $Hislands[$HcurrentNumber]->{'command'}->[$i]);
 }

 out(<<END);

</TD>
</TR>
</TABLE>
</CENTER>
<HR>
<DIV ID='CommentBox'>
${HtagBig_}코멘트갱신${H_tagBig}<BR>
<FORM action="$HthisFile" method="POST">
코멘트<INPUT TYPE=text NAME=MESSAGE SIZE=80><BR>
비밀번호<INPUT TYPE=password NAME=PASSWORD VALUE="$HdefaultPassword">
<INPUT TYPE=submit VALUE="코멘트갱신" NAME=MessageButton$Hislands[$HcurrentNumber]->{'id'}>
</FORM>
</DIV>
END

}

# 입력 완료된 명령 표시
sub tempCommand {
 my($number, $command) = @_;
 my($kind, $target, $x, $y, $arg) =
	(
	 $command->{'kind'},
	 $command->{'target'},
	 $command->{'x'},
	 $command->{'y'},
	 $command->{'arg'}
	 );
 my($name) = "$HtagComName_${HcomName[$kind]}$H_tagComName";
 my($point) = "$HtagName_($x,$y)$H_tagName";
 $target = $HidToName{$target};
 if($target eq '') {
	$target = "무인";
 }
 $target = "$HtagName_${target} 섬$H_tagName";
 my($value) = $arg * $HcomCost[$kind];
 if($value == 0) {
	$value = $HcomCost[$kind];
 }
 if($value < 0) {
	$value = -$value;
	$value = "$value$HunitFood";
 } else {
	$value = "$value$HunitMoney";
 }
 $value = "$HtagName_$value$H_tagName";

 my($j) = sprintf("%02d:", $number + 1);

 out("<A STYlE=\"text-decoration:none\" HREF=\"JavaScript:void(0);\" onClick=\"ns($number)\">$HtagNumber_$j$H_tagNumber${HnormalColor_}");

 if(($kind == $HcomDoNothing) ||
 ($kind == $HcomGiveup)) {
	out("$name");
 } elsif(($kind == $HcomMissileNM) ||
	 ($kind == $HcomMissilePP) ||
	 ($kind == $HcomMissileST) ||
	 ($kind == $HcomMissileLD)) {
	# 미사일계
	my($n) = ($arg == 0 ? '무제한' : "${arg}발");
	out("$target$point 로$name($HtagName_$n$H_tagName)");
 } elsif($kind == $HcomMissileRN) {
	# 무작위탄
	my($n) = ($arg == 0 ? '무제한' : "${arg}발");
	out("$HtagName_어딘가의 섬$H_tagName$point 로$name($HtagName_$n$H_tagName)");
 } elsif($kind == $HcomMissileNB) {
	# 스나이파탄
	out("$target$point 로$name");
 } elsif($kind == $HcomSendMonster) {
	# 괴수 파견
	out("$target 로$name");
 } elsif($kind == $HcomSell) {
	# 식량 수출
	out("$name$value");
 } elsif(($kind == $HcomPrepare3)||($kind == $HcomPropaganda)) {
	# 유치 활동
	out("$name");
 } elsif(($kind == $HcomMoney) ||
	 ($kind == $HcomFood)) {
	# 지원
	out("$target 로$name$value");
 } elsif($kind == $HcomDestroy) {
	# 굴착
	if($arg != 0) {
	 out("$point 에서$name(예산${value})");
	} else {
	 out("$point 에서$name");
	}
 } elsif(($kind == $HcomFarm) ||
	 ($kind == $HcomFactory) ||
	 ($kind == $HcomMountain) ||
	 ($kind == $HcomPond)) {
	# 횟수 포함
	if($arg == 0) {
	 out("$point 에서$name");
	} else {
	 out("$point 에서$name($arg 회)");
	}
 } else {
	# 좌표 포함
	out("$point 에서$name");
 }

 out("${H_normalColor}</FONT></A><BR>");
}

# 로컬 게시판
sub tempLbbsHead {
 out(<<END);
<HR>
${HtagBig_}${HtagName_}${HcurrentName} 섬${H_tagName}관광객 통신${H_tagBig}<BR>
END
}

# 로컬 게시판입력 양식
sub tempLbbsInput {
 out(<<END);
<FORM action="$HthisFile" method="POST">
<TABLE BORDER>
<TR>
<TH>이름</TH>
<TH>내용</TH>
<TH>동작</TH>
</TR>
<TR>
<TD><INPUT TYPE="text" SIZE=32 MAXLENGTH=32 NAME="LBBSNAME" VALUE="$HdefaultName"></TD>
<TD><INPUT TYPE="text" SIZE=80 NAME="LBBSMESSAGE"></TD>
<TD><INPUT TYPE="submit" VALUE="등록" NAME="LbbsButtonSS$HcurrentID"></TD>
</TR>
</TABLE>
</FORM>
END
}

# 로컬 게시판입력 양식 owner mode 용
sub tempLbbsInputOW {
 out(<<END);
<FORM action="$HthisFile" method="POST">
<TABLE BORDER>
<TR>
<TH>이름</TH>
<TH COLSPAN=2>내용</TH>
</TR>
<TR>
<TD><INPUT TYPE="text" SIZE=32 MAXLENGTH=32 NAME="LBBSNAME" VALUE="$HdefaultName"></TD>
<TD COLSPAN=2><INPUT TYPE="text" SIZE=80 NAME="LBBSMESSAGE"></TD>
</TR>
<TR>
<TH> 비밀번호</TH>
<TH COLSPAN=2>동작</TH>
</TR>
<TR>
<TD><INPUT TYPE=password SIZE=32 MAXLENGTH=32 NAME=PASSWORD VALUE="$HdefaultPassword"></TD>
<TD align=right>
<INPUT TYPE="submit" VALUE="등록" NAME="LbbsButtonOW$HcurrentID">
</TD>
<TD align=right>
번호
<SELECT NAME=NUMBER>
END
 # 발언번호
 my($j, $i);
 for($i = 0; $i < $HlbbsMax; $i++) {
	$j = $i + 1;
	out("<OPTION VALUE=$i>$j\n");
 }
 out(<<END);
</SELECT>
<INPUT TYPE="submit" VALUE="삭제" NAME="LbbsButtonDL$HcurrentID">
</TD>
</TR>
</TABLE>
</FORM>
END
}

# 로컬 게시판내용
sub tempLbbsContents {
 my($lbbs, $line);
 $lbbs = $Hislands[$HcurrentNumber]->{'lbbs'};
 out(<<END);
<TABLE BORDER>
<TR>
<TH>번호</TH>
<TH>내용</TH>
</TR>
END

 my($i);
 for($i = 0; $i < $HlbbsMax; $i++) {
	$line = $lbbs->[$i];
	if($line =~ /([0-9]*)\>(.*)\>(.*)$/) {
	 my($j) = $i + 1;
	 out("<TR><TD align=center>$HtagNumber_$j$H_tagNumber</TD>");
	 if($1 == 0) {
		# 관광객
		out("<TD>$HtagLbbsSS_$2> $3$H_tagLbbsSS</TD></TR>");
	 } else {
		# 섬주
		out("<TD>$HtagLbbsOW_$2> $3$H_tagLbbsOW</TD></TR>");
	 }
	}
 }

 out(<<END);
</TD></TR></TABLE>
END
}

# 로컬 게시판에서 이름이나 메시지가 없는 경우
sub tempLbbsNoMessage {
 out(<<END);
${HtagBig_}이름 또는 내용이 비어 있습니다..${H_tagBig}$HtempBack
END
}

# 쓰기/삭제
sub tempLbbsDelete {
 out(<<END);
${HtagBig_}기록 내용을 삭제했습니다${H_tagBig}<HR>
END
}

# 명령 등록
sub tempLbbsAdd {
 out(<<END);
${HtagBig_}기록을 수행했습니다${H_tagBig}<HR>
END
}

# 명령 삭제
sub tempCommandDelete {
 out(<<END);
${HtagBig_} 명령을 삭제했습니다${H_tagBig}<HR>
END
}

# 명령 등록
sub tempCommandAdd {
 out(<<END);
${HtagBig_} 명령을 등록했습니다${H_tagBig}<HR>
END
}

# 코멘트 변경성공
sub tempComment {
 out(<<END);
${HtagBig_}코멘트를 갱신했습니다${H_tagBig}<HR>
END
}

# 최근 상황
sub tempRecent {
 my($mode) = @_;
 out(<<END);
<DIV ID='RecentlyLog'>
<HR>
${HtagBig_}${HtagName_}${HcurrentName} 섬${H_tagName}의 최근 상황${H_tagBig}<BR>
END
 logPrintLocal($mode);
 out("</DIV>");
}

# 섬의 이동
sub islandJamp {
 $HtargetList = getIslandList($HcurrentID);
 out(<<END);
<CENTER>
<SCRIPT LANGUAGE="JavaScript">
function jump(theForm) {
 var sIndex = theForm.urlsel.selectedIndex;
 var url = theForm.urlsel.options[sIndex].value;
 if (url != "" ) location.href = "$HthisFile?Sight=" +url;
}
</SCRIPT>
<TABLE align=center border=0>
<TR><TD>
<FORM name="urlForm">
<SELECT NAME="urlsel">
$HtargetList<BR>
</SELECT>
</TD>
<TD><input type="button" value=" GO " onClick="jump(this.form)"></TD>
</TR></TABLE>
</form>
</CENTER>
END
}

1;

