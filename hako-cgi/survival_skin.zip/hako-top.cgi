#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}
#----------------------------------------------------------------------
# 모형정원 제도 ver2.30
# 톱 페이지 모듈(ver1.00)
# 사용 조건과 사용 방법은 hako-readme.txt 파일을 참조해 주세요
#
# 모형정원 제도의 페이지: http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html
#----------------------------------------------------------------------


#----------------------------------------------------------------------
# 톱 페이지 모드
#----------------------------------------------------------------------
# 메인
sub topPageMain {
 # 개방
 unlock();

 # 템플릿출력
 tempTopPage();
}

# 톱 페이지
sub tempTopPage {
 # 제목
 out(<<END);
${HtagTitle_}$Htitle${H_tagTitle}
END

 # 디버그 모드이면 '턴 진행' 버튼
 if($Hdebug == 1) {
 out(<<END);
<FORM action="$HthisFile" method="POST">
<INPUT TYPE="submit" VALUE="턴을 진행하기" NAME="TurnButton">
</FORM>
END
 }

 my($mStr1) = '';
 if($HhideMoneyMode != 0) {
	$mStr1 = "<TH $HbgTitleCell align=center>${HtagTH_} 자금${H_tagTH}</TH>";
 }

# # 갱신 시간 표시
# my($mode, $remainTime, $rtStr);
# if ($HmainMode ne 'turn') {
#	$mode = ($HislandTurn < $HarmisticeTurn) ? '휴전 기간' : '전투 기간';
#	$remainTime = $HunitTime - time() + $HislandLastTime;
#	$rtStr = "다음 갱신($mode)까지,";
#	$rtStr.= int($remainTime / 3600). "시간 ";
#	$rtStr.= int(($remainTime % 3600) / 60). "분 ";
#	$rtStr.= $remainTime % 60 . "초";
# }
# else {
#	$rtStr = "턴을 갱신했습니다";
# }
#
#	# 다음 갱신 시간 표시
# my($now) = time;
# $aaa = $HislandLastTime + $HunitTime;
# my($sec, $min, $hour, $date, $mon, $year, $day, $yday, $dummy) = localtime(time);
#	$mon++;
# my($sss) = "${mon}월 ${date}일 ${hour} 시 ${min}분 ${sec}초";
# my($sec2, $min2, $hour2, $date2, $mon2, $year2, $day2, $yday2, $dummy2) = localtime($aaa);
#	$mon2++;
# my($bbb) = "${mon2}월${date2}일${hour2} 시${min2}분";

 if ($HjavaModeSet eq 'java') {
		$radio = ""; $radio2 = "CHECKED";
	}else{
		$radio = "CHECKED";	$radio2 = "";
	}

 my($nextDeadTurn)=0;
 while(($HislandTurn>= $nextDeadTurn)||($HarmisticeTurn>= $nextDeadTurn)){
	$nextDeadTurn += $HturnDead;
 }

 my($ccc);
 if($HislandNumber> 0){
	$ccc = int(50/$HislandNumber);
 }

 my($mode);
 $mode = ($HislandTurn < $HarmisticeTurn) ? '휴전 기간' : '전투 기간';

 # 양식
my($remain) = $HunitTime + $HislandLastTime - time; #★
out(<<END);
<DIV ID='Turn'>
<H1>${HtagHeader_}턴$HislandTurn${H_tagHeader}(다음 턴 $mode)</H1>
</DIV>
<FORM name="RemainForm"><INPUT name="RemainTime" size="30" type="text" readonly class=timer></FORM><SCRIPT language="JavaScript">
<!--
nextTurn = ${remain}; loadDate = new Date();
timerID = setTimeout('dispRemainTime()', 100);
function dispRemainTime() { clearTimeout(timerID);
document.RemainForm.RemainTime.value = getRemainTime();
timerID = setTimeout('dispRemainTime()', 1000);}
function getRemainTime() {
now = new Date();msec = now.getTime() - loadDate.getTime();
msec -= msec % 1000; msec /= 1000;msec = nextTurn - msec;
if (msec < 0) {msec = 0;}
sec = msec % 60; msec = (msec - sec) / 60;
min = msec % 60; hour = (msec - min) / 60;
if (hour < 10) {hour = "0" + hour;}
if (min < 10) {min = "0" + min;}
if (sec < 10) {sec = "0" + sec;}
return "다음 턴까지 남은 " + hour + ":" + min + ":" + sec;}
//-->
</SCRIPT>

<!--
JavaScript 없이 문자로 '다음 갱신까지'를 표시하는 경우의 절차,
(줄 번호는 현시점 기준입니다. 줄을 줄이면 당연히 번호가 밀리므로 오류가 없도록 주의해 주세요.)
1. 43~65번째 줄 앞의 '#'를 제거합니다
2. '($rtStr)'을 89번째 줄의 '턴$HislndTurn' 뒤에 넣습니다
3. 마찬가지로 89번째 줄의 (다음 턴 $mode)를 제거합니다
4. 90~108번째 줄을 제거합니다
5. #★가 붙은 줄을 제거합니다. 여기서 위쪽은 1위치, 아래쪽은 2위치입니다.
-->

다음 <span class='attention'><font size=4>$nextDeadTurn 턴</font></span>에 최하위 섬이 소멸됩니다<br>
점유율이 <span class='attention'><font size=4>$ccc% 미만</font></span>이면 소멸됩니다<br>
<!--
참고: 위 표시보다 각 섬의 점유율 표시가 더 자세할 수 있지만,
점유율 계산에서는 소 수점 이하를 엄밀하게 처리하지 않을 수 있습니다.
해당 기능이 필요 없으면 위 줄은 삭제해도 됩니다.
-->
<br>

<!-- #★
<DIV ID='nexttime'>현재의 시간:<b>$sss</b><br>
다음 갱신:$bbb<br></DIV>
#★ -->

<HR>
<DIV ID='myIsland'>
<H1>${HtagHeader_}자신의 섬으로${H_tagHeader}</H1>
<SCRIPT language="JavaScript">
<!--
function newdevelope(){
	newWindow = window.open("", "newWindow");
	document.Island.target = "newWindow";
	document.Island.submit();
}
function develope(){
	document.Island.target = "";
}
//-->
</SCRIPT>
<FORM name="Island" action="$HthisFile" method="POST">
당신의 섬 이름은?<BR>
<SELECT NAME="ISLANDID">
$HislandList
</SELECT><BR>
비밀번호 입력!!<BR>
<INPUT TYPE="hidden" NAME="OwnerButton">
<INPUT TYPE="password" NAME="PASSWORD" VALUE="$HdefaultPassword" SIZE=32 MAXLENGTH=32><BR>
<INPUT TYPE="radio" NAME=JAVAMODE VALUE=cgi $radio>일반 모드
<INPUT TYPE="radio" NAME=JAVAMODE VALUE=java $radio2 checked>JavaScript 모드<BR>
<INPUT TYPE="submit" VALUE="개발 화면으로" onClick="develope()">
<INPUT TYPE="button" VALUE="새 화면" onClick="newdevelope()">
</FORM>
</DIV>
<HR>
<DIV ID='RecentlyLog'>
<A STYlE="text-decoration:none" HREF="${baseDir}/hakolog.html" target="_blank">
<FONT SIZE=6><B>${HtagHeader_}최근 사건${H_tagHeader}</B></FONT>
</A>
</DIV>
<HR>
<DIV ID='islandView'>
<H1>${HtagHeader_}섬의 정보${H_tagHeader}</H1>
<P>
섬 이름을 클릭하면,<B>관광</B>할 수 있습니다.
</P>
<TABLE BORDER>
<TR>
<TH $HbgTitleCell align=center>${HtagTH_}순위${H_tagTH}</TH>
<TH $HbgTitleCell align=center>${HtagTH_} 섬${H_tagTH}</TH>
<TH $HbgTitleCell align=center>${HtagTH_}인구/점유율${H_tagTH}</TH>
<TH $HbgTitleCell align=center>${HtagTH_}면적${H_tagTH}</TH>
$mStr1
<TH $HbgTitleCell align=center>${HtagTH_}식량${H_tagTH}</TH>
<TH $HbgTitleCell align=center>${HtagTH_}농장규모/수원규모${H_tagTH}</TH>
<TH $HbgTitleCell align=center>${HtagTH_}공장규모${H_tagTH}</TH>
<TH $HbgTitleCell align=center>${HtagTH_}채굴장규모${H_tagTH}</TH>
<TH $HbgTitleCell align=center>${HtagTH_}M발사${H_tagTH}</TH>
<TH $HbgTitleCell align=center>${HtagTH_}M피격${H_tagTH}</TH>
<TH $HbgTitleCell align=center>${HtagTH_}S탄${H_tagTH}</TH>
</TR>
END

 my($allpop, $i);
 for($i=0; $i < $HislandNumber; $i++){
	$allpop += $Hislands[$i]->{'pop'};
 }
# $allpop = int($allpop/100);

 my($island, $j, $farm, $factory, $mountain, $pond, $name, $id, $prize, $ii, $occupation);
 for($ii = 0; $ii < $HislandNumber; $ii++) {
	$j = $ii + 1;
	$island = $Hislands[$ii];

	# 점유율
 $occupation = int(($island->{'pop'}*100)/$allpop);
	if($occupation> 100){ $occupation = 100; }

	$id = $island->{'id'};
	$farm = $island->{'farm'};
	$factory = $island->{'factory'};
	$mountain = $island->{'mountain'};
	$pond = $island->{'pond'};
	$farm = ($farm == 0) ? "보유하지 않음" : "${farm}0$HunitPop";
	$factory = ($factory == 0) ? "보유하지 않음" : "${factory}0$HunitPop";
	$mountain = ($mountain == 0) ? "보유하지 않음" : "${mountain}0$HunitPop";
	$pond = ($pond == 0) ? "보유하지 않음" : "${pond}000리와 루";
	if($island->{'absent'} == 0) {
		$name = "${HtagName_}$island->{'name'} 섬${H_tagName}";
	} else {
	 $name = "${HtagName2_}$island->{'name'} 섬($island->{'absent'})${H_tagName2}";
	}

	$prize = $island->{'prize'};
	my($flags, $monsters, $turns);
	$prize =~ /([0-9]*),([0-9]*),(.*)/;
	$flags = $1;
	$monsters= $2;
	$turns = $3;
	$prize = '';

	# 남은 턴 표시
	while($turns =~ s/([0-9]*),//) {
	 $prize.= <<EOP;
<A HREF="JavaScript:void(0);" onMouseOver="status = '$1${Hprize[0]}'; return true;" onMouseOut="status = '';">
<IMG SRC="prize0.gif" ALT="$1${Hprize[0]}" TITLE="$1${Hprize[0]}" WIDTH=16 HEIGHT=16 BORDER=0></A>
EOP
	}

	# 이름에 순위 표시 문자를 추가
	my($f) = 1;
	my($i);
	for($i = 1; $i < 10; $i++) {
	 if($flags & $f) {
		$prize.= <<EOP;
<A HREF="JavaScript:void(0);" onMouseOver="status = '${Hprize[$i]}'; return true;" onMouseOut="status = '';">
<IMG SRC="prize${i}.gif" ALT="${Hprize[$i]}" TITLE="$1${Hprize[$i]}" WIDTH=16 HEIGHT=16 BORDER=0></A>
EOP
	 }
	 $f *= 2;
	}

	# 쓰러뜨린 괴수 목록
	$f = 1;
	my($max) = -1;
	my($mNameList) = '';
	for($i = 0; $i < $HmonsterNumber; $i++) {
	 if($monsters & $f) {
		$mNameList.= "[$HmonsterName[$i]] ";
		$max = $i;
	 }
	 $f *= 2;
	}
	if($max != -1) {
	 $prize.= <<EOP;
<A HREF="JavaScript:void(0);" onMouseOver="status = '$mNameList'; return true;" onMouseOut="status = '';">
<IMG SRC="${HmonsterImage[$max]}" ALT="$mNameList" TITLE="$mNameList" WIDTH=16 HEIGHT=16 BORDER=0></A>
EOP
	}


	my($mStr1) = '';
	if($HhideMoneyMode == 1) {
	 $mStr1 = "<TD $HbgInfoCell align=right>$island->{'money'}$HunitMoney</TD>";
	} elsif($HhideMoneyMode == 2) {
	 my($mTmp) = aboutMoney($island->{'money'});
	 $mStr1 = "<TD $HbgInfoCell align=right>$mTmp</TD>";
	}

	my($oStr) = '';
	if($island->{'ownername'} eq ''){
	 $oStr = "<TD $HbgCommentCell COLSPAN=9 align=left><B>${HtagTH_}코멘트:</B>${H_tagTH}$island->{'comment'}</TD>";
	} else {
	 $oStr = "<TD $HbgCommentCell COLSPAN=9 align=left><B><font color=#0000ff>$island->{'ownername'}:</B></font>$island->{'comment'}</TD>";
	}

	out(<<END);
<TR>
<TD $HbgNumberCell ROWSPAN=2 align=center>${HtagNumber_}$j${H_tagNumber}</TD>
<TD $HbgNameCell ROWSPAN=2 align=left>

<A STYlE=\"text-decoration:none\" HREF="${HthisFile}?Sight=${id}" target="_blank">
$name
</A>
<BR>
$prize
</TD>
<TD $HbgInfoCell align=right>
$island->{'pop'}$HunitPop/$occupation%</TD>
<TD $HbgInfoCell align=right>$island->{'area'}$HunitArea</TD>
$mStr1
<TD $HbgInfoCell align=right>$island->{'food'}$HunitFood</TD>
<TD $HbgInfoCell align=right>$farm/$pond</TD>
<TD $HbgInfoCell align=right>$factory</TD>
<TD $HbgInfoCell align=right>$mountain</TD>
<TD $HbgInfoCell align=right>$island->{'MOUT'}</TD>
<TD $HbgInfoCell align=right>$island->{'MIN'}</TD>
<TD $HbgInfoCell align=right>$island->{'nowNB'}</TD>
</TR>
<TR>
$oStr
</TR>
END
 }

 out(<<END);
</TABLE>
</DIV>

<HR>
<DIV ID='newIsland'>
<H1>${HtagHeader_}새 섬을 탐색${H_tagHeader}</H1>
END

 if($HislandNumber < $HmaxIsland) {
	out(<<END);
<font color=red><b>1인1섬에서 부탁드립니다.</b></font><br>
<br>
<FORM action="$HthisFile" method="POST">
섬 이름<BR>
<INPUT TYPE="text" NAME="ISLANDNAME" SIZE=32 MAXLENGTH=16> 섬<BR>
소유자 이름(생략 가능)<br>
<INPUT TYPE="text" NAME="OWNERNAME" SIZE=$Htext_wid MAXLENGTH=16><BR>
비밀번호<BR>
<INPUT TYPE="password" NAME="PASSWORD" SIZE=32 MAXLENGTH=32><BR>
비밀번호 재확인<BR>
<INPUT TYPE="password" NAME="PASSWORD2" SIZE=32 MAXLENGTH=32><BR>

<INPUT TYPE="submit" VALUE="찾으러 가기" NAME="NewIslandButton">
</FORM>
END
 } else {
	out(<<END);
 게임이 시작되었거나 섬 수가 최대치에 도달하여 현재 등록할 수 없습니다.
END
 }

 out(<<END);
</DIV>
<HR>
<DIV ID='changeInfo'>
<H1>${HtagHeader_} 정보 변경${H_tagHeader}</H1>
<P>
(주의) 이름 변경에는 $HcostChangeName${HunitMoney}이 들어갑니다.
</P>
<FORM action="$HthisFile" method="POST">
어느 섬입니까?<BR>
<SELECT NAME="ISLANDID">
$HislandList
</SELECT>
<BR>
새 이름을 입력하세요(변경하는 경우만)<BR>
<INPUT TYPE="text" NAME="ISLANDNAME" SIZE=32 MAXLENGTH=32> 섬<BR>
비밀번호(필수)<BR>
<INPUT TYPE="password" NAME="OLDPASS" SIZE=32 MAXLENGTH=32><BR>
새 비밀번호(변경할 경우만)<BR>
<INPUT TYPE="password" NAME="PASSWORD" SIZE=32 MAXLENGTH=32><BR>
비밀번호 재확인(변경할 경우만)<BR>
<INPUT TYPE="password" NAME="PASSWORD2" SIZE=32 MAXLENGTH=32><BR>

<INPUT TYPE="submit" VALUE="변경" NAME="ChangeInfoButton">
</FORM>

<H1>${HtagHeader_}소유자 이름의 변경${H_tagHeader}</H1>
<FORM action="$HthisFile" method="POST">
어느 섬입니까?<BR>
<SELECT NAME="ISLANDID"><BR>
$HislandList
</SELECT>
<BR>
소유자 이름<BR>
<INPUT TYPE="text" NAME="OWNERNAME" SIZE=32 MAXLENGTH=32><BR>
비밀번호(필수)<BR>
<INPUT TYPE="password" NAME="OLDPASS" SIZE=32 MAXLENGTH=32><BR>
<INPUT TYPE="submit" VALUE="변경" NAME="ChangeOwnerButton">
</FORM>
</DIV>
<HR>
END

 my($Hskinflag);
 if($HskinName eq '' || $HskinName eq "$HcssFile"){
 $Hskinflag = '<span class=attention>미설정</span>';
 } else {
 $Hskinflag = $HskinName;
 }

 opendir(DIN, "$HcssDir/");
 my($skinName, @skinlist);
 while($skinName = readdir(DIN)) {
 next if($skinName =~ /^\./);
 push(@skinlist, $skinName);
 }
 closedir(DIN);

 my $select_list = "<OPTION value='del' selected>기본값\n";
 foreach (@skinlist) {
 $select_list.= "<OPTION>$_\n";
 }

 out(<<END);
<DIV ID='hakoSkin'>
<H1>${HtagHeader_}모형정원 스킨의 설정${H_tagHeader}</H1>
<P>
기분 전환용으로 이용해 주세요. m(_ _)m
</P>
현재 설정<B>[</b> ${Hskinflag} <B>]</B>
<form action=$HthisFile method=POST>
<SELECT NAME="SKIN">$select_list</SELECT>
<INPUT TYPE="submit" VALUE="설정" name=SKINSET>
</form>
</DIV>
<HR>
END
# out("<DIV ID='RecentlyLog'>");
# logPrintTop();
# out("</DIV>");
 out(<<END);
<DIV ID='RecentlyLog'>
<H1>${HtagHeader_}발견 기록${H_tagHeader}</H1>
END
 historyPrint();
 out("</DIV>");
}

# 톱 페이지용 로그 표시
sub logPrintTop {
 my($i);
 for($i = 0; $i < $HtopLogTurn; $i++) {
	logFilePrint($i, 0, 0);
 }
}

# 기록 파일 표시
sub historyPrint {
 open(HIN, "${HdirName}/hakojima.his");
 my(@line, $l);
 while($l = <HIN>) {
	chomp($l);
	push(@line, $l);
 }
 @line = reverse(@line);

 foreach $l (@line) {
	$l =~ /^([0-9]*),(.*)$/;
	out("${HtagNumber_}턴${1}${H_tagNumber}:${2}<BR>\n");
 }
 close(HIN);
}

1;



