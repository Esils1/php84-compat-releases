#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}
#----------------------------------------------------------------------
# 하코니와 제도 ver2.30
# 턴 진행 모듈(ver1.02)
# 사용 조건, 사용 방법 등은,hako-readme.txt 파일을 참조
#
# 하코니와 제도의 페이지: http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html
#----------------------------------------------------------------------
#----------------------------------------------------------------------
# Hakoniwa R.A. Final Edition
# 메인스크립트(하코니와 제도 ver2.30)
# 사용 조건, 사용 방법 등은,read-renas.txt 파일을 참조
#
# KEI PAGE: http://www5b.biglobe.ne.jp/~k-e-i/
#----------------------------------------------------------------------

#주변 2헥스의 좌표
my(@ax) = (0, 1, 1, 1, 0,-1, 0, 1, 2, 2, 2, 1, 0,-1,-1,-2,-1,-1, 0);
my(@ay) = (0,-1, 0, 1, 1, 0,-1,-2,-1, 0, 1, 2, 2, 2, 1, 0,-1,-2,-2);

#----------------------------------------------------------------------
# 섬 신규 생성 모드
#----------------------------------------------------------------------
# 메인
sub newIslandMain {
 # 섬이 가득 차서 없습니까 확인
 if($HislandNumber>= $HmaxIsland) {
	unlock();
	tempNewIslandFull();
	return;
 }

 # 이름이 있는 지 확인
 if($HcurrentName eq '') {
	unlock();
	tempNewIslandNoName();
	return;
 }

 # 이름이 있는 지 확인
 if($HcurrentOwnerName eq '') {
	unlock();
	tempNewIslandNoName();
	return;
 }

 # 이름이 있는 지 확인
 if($Hmessage eq '') {
	unlock();
	tempNewIslandNoName();
	return;
 }

 # 이름이 유효한지 확인
 if($HcurrentName =~ /[,\?\(\)\<\>\$]|^무인$/) {
	# 사용 불가 이름
	unlock();
	tempNewIslandBadName();
	return;
 }

 # 이름의 중복 확인
 if(nameToNumber($HcurrentName) != -1) {
	# 이미 발견완료
	unlock();
	tempNewIslandAlready();
	return;
 }

 # password 의존재판정
 if($HinputPassword eq '') {
	# password 무시
	unlock();
	tempNewIslandNoPassword();
	return;
 }

 # 확인용 비밀번호
 if($HinputPassword2 ne $HinputPassword) {
	# password 오류
	unlock();
	tempWrongPassword();
	return;
 }

	# IP 취득
	$speaker = $ENV{'REMOTE_HOST'};
	$speaker = $ENV{'REMOTE_ADDR'} if ($speaker eq '');

 # IP 의중복 확인
 if($IPcut == 1) {
 if(ipToNumber($speaker) != -1) {
	# 이미 발견완료
	unlock();
	tempIPIslandAlready();
	return;
 }
 }

 # 새 섬의 번호 정하기
 $HcurrentNumber = $HislandNumber;
 $HislandNumber++;
 $Hislands[$HcurrentNumber] = makeNewIsland();
 my($island) = $Hislands[$HcurrentNumber];

 # 각종의 값을 설정
 $island->{'name'} = $HcurrentName;
 $island->{'id'} = $HislandNextID;
 $HislandNextID ++;
 $island->{'absent'} = $HgiveupTurn - 3;
 $island->{'comment'} = htmlEscape($Hmessage);
 $island->{'password'} = encode($HinputPassword);
 $island->{'eisei1'} = 0;
 $island->{'eisei2'} = 0;
 $island->{'eisei3'} = '0,0,0,0,0';
 $island->{'eisei4'} = '0,0,0,0,0,0,0,0,0,0,0';
 $island->{'eisei5'} = '0,0,0,0,0,0,0';
 $island->{'eisei6'} = '0,0,0,0,0,0,0,0,0,0,0,0';
 $island->{'eis1'} = 0;
 $island->{'eis2'} = 0;
 $island->{'eis3'} = 0;
 $island->{'eis4'} = 0;
 $island->{'eis5'} = 0;
 $island->{'eis6'} = 0;
 $island->{'eis7'} = 0;
 $island->{'eis8'} = '(미 등록)';
 $island->{'taiji'} = 0;
 $island->{'onm'} = htmlEscape($HcurrentOwnerName);
 $island->{'ownername'} = htmlEscape($HcurrentOwnerName);
 $island->{'id1'} = $HislandNextID;
 $island->{'totoyoso'} = '(미 등록)';
 $island->{'totoyoso2'}= 555;
 $island->{'kei'} = 0;
 $island->{'rena'} = 0;
 $island->{'momotan'} = 0;
 $island->{'fore'} = 0;
 $island->{'pika'} = 0;
 $island->{'hamu'} = 0;
 $island->{'monta'} = 0;
 $island->{'tare'} = 0;
 $island->{'zipro'} = 0;
 $island->{'leje'} = 0;

 $island->{'ipname'} = $HcurrentName;
 $island->{'ip0'} = "$speaker";
 $island->{'ip1'} = "$speaker";
 $island->{'ip2'} = "$speaker";
 $island->{'ip3'} = "$speaker";
 $island->{'ip4'} = "$speaker";
 $island->{'ip5'} = "$speaker";
 $island->{'ip6'} = 0;
 $island->{'ip7'} = 0;
 $island->{'ip8'} = 0;
 $island->{'ip9'} = 0;
 $island->{'etc0'} = 0;
 $island->{'etc1'} = 0;
 $island->{'etc2'} = 0;
 $island->{'etc3'} = 0;
 $island->{'etc4'} = 0;
 $island->{'etc5'} = '0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0';
 $island->{'etc6'} = '0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0';
 $island->{'etc7'} = '0,0,0';
 $island->{'etc8'} = '0,0,0,0,0,0,0';
 $island->{'etc9'} = '0,0,0,0,0,0,0';
 $island->{'auc0'} = '0,0,0,0,0';
 $island->{'auc1'} = 0;
 $island->{'auc2'} = 0;
 $island->{'auc3'} = 0;
 $island->{'auc4'} = '0,0,0';
 $island->{'auc5'} = '0,0,0,0,0';
 $island->{'auc6'} = '0,0,0';
 $island->{'auc7'} = 0;
 $island->{'auc8'} = 0;
 $island->{'auc9'} = '0,0,0,0,0';

 if($anothermood == 1) {
	my($onm);
	$onm = $island->{'onm'};
	$island->{'totoyoso2'} = "$onm 시티";
	$island->{'shu'}++;
	$island->{'eisei1'} = 7;
 }

	 if(random(100) < 50) {
	 $island->{'eis1'} = 200;
	 } else {
	 $island->{'eis2'} = 200;
	 }

 # 인구기타 산출
 estimate($HcurrentNumber);

 # 데이터 쓰기
 writeIslandsFile($island->{'id'});
 logDiscover($HcurrentName); # 로그

 # 개방
 unlock();

 # 발견 화면
 tempNewIslandHead($HcurrentName); # 발견했습니다!!
 islandInfo(); # 섬의 정보
 islandMap(1); # 섬 지도, 소유자 모드
}

# 새 섬 만들기
sub makeNewIsland {
 # 지형을 만들기
 my($land, $landValue) = makeNewLand();

 # 초기 명령을 생성
 my(@command, $i);
 for($i = 0; $i < $HcommandMax; $i++) {
	 $command[$i] = {
	 'kind' => $HcomDoNothing,
	 'target' => 0,
	 'x' => 0,
	 'y' => 0,
	 'arg' => 0
	 };
 }

 # 초기 게시판 생성
 my(@lbbs);
 for($i = 0; $i < $HlbbsMax; $i++) {
 $lbbs[$i] = "0<<0>>";
 }

 # 섬으로 하고반환
 return {
	'land' => $land,
	'landValue' => $landValue,
	'command' => \@command,
	'lbbs' => \@lbbs,
	'money' => $HinitialMoney,
	'food' => $HinitialFood,
	'prize' => '0,0,',
 'monsterlive' => 0,
 'monsterlivetype' => 0,
 };
}

# 새 섬 지형 만들기
sub makeNewLand {
 # 기본형 생성
 my(@land, @landValue, $x, $y, $i);

 # 바다에 초기화
 for($y = 0; $y < $HislandSize; $y++) {
	 for($x = 0; $x < $HislandSize; $x++) {
	 $land[$x][$y] = $HlandSea;
	 $landValue[$x][$y] = 0;
	 }
 }

 # 섬 중앙 4×4에 황무지를 배치
 my($center) = $HislandSize / 2 - 1;
 for($y = $center - 1; $y < $center + 3; $y++) {
	 for($x = $center - 1; $x < $center + 3; $x++) {
	 $land[$x][$y] = $HlandWaste;
	 }
 }

 # 8*8범위내에육지를 증식
 for($i = 0; $i < 120; $i++) {
	 # 무작위좌표
	 $x = random(8) + $center - 3;
	 $y = random(8) + $center - 3;

	 my($tmp) = countAround(\@land, $x, $y, $HlandSea, 7);
	 if(countAround(\@land, $x, $y, $HlandSea, 7) != 7){
	 # 주변에 육지가 있는 경우, 얕은 바다로
	 # 얕은 바다는 황무지로
	 # 황무지는 평지로
	 if($land[$x][$y] == $HlandWaste) {
		 $land[$x][$y] = $HlandPlains;
		 $landValue[$x][$y] = 0;
	 } else {
		 if($landValue[$x][$y] == 1) {
 $land[$x][$y] = $HlandWaste;
 $landValue[$x][$y] = 0;
		 } else {
		 $landValue[$x][$y] = 1;
		 }
	 }
	 }
 }

 # 숲을 만들기
 my($count) = 0;
 while($count < 4) {
	 # 무작위좌표
	 $x = random(4) + $center - 1;
	 $y = random(4) + $center - 1;

	 # 그곳이이미 숲이 아니면, 숲을 만들기
	 if($land[$x][$y] != $HlandForest) {
	 $land[$x][$y] = $HlandForest;
	 $landValue[$x][$y] = 5; # 처음은500본
	 $count++;
	 }
 }

 # 읍을 만들기
 $count = 0;
 while($count < 2) {
	 # 무작위좌표
	 $x = random(4) + $center - 1;
	 $y = random(4) + $center - 1;

	 # 그곳이 숲이나 도시가 아니면 도시를 만들기
	 if(($land[$x][$y] != $HlandTown) &&
	 ($land[$x][$y] != $HlandForest)) {
	 $land[$x][$y] = $HlandTown;
	 $landValue[$x][$y] = 5; # 처음은500명
	 $count++;
	 }
 }

 # 산을 만들기
 $count = 0;
 while($count < 1) {
	 # 무작위좌표
	 $x = random(4) + $center - 1;
	 $y = random(4) + $center - 1;

	 # 그곳이 숲이나 도시가 아니면 도시를 만들기
	 if(($land[$x][$y] != $HlandTown) &&
	 ($land[$x][$y] != $HlandForest)) {
	 $land[$x][$y] = $HlandMountain;
	 $landValue[$x][$y] = 0; # 처음은 채굴장없음
	 $count++;
	 }
 }

 # 기지를 만들기
 $count = 0;
 while($count < 1) {
	 # 무작위좌표
	 $x = random(4) + $center - 1;
	 $y = random(4) + $center - 1;

	 # 그곳이 숲/도시/산이 아니면 기지
	 if(($land[$x][$y] != $HlandTown) &&
	 ($land[$x][$y] != $HlandForest) &&
	 ($land[$x][$y] != $HlandMountain)) {
	 $land[$x][$y] = $HlandBase;
	 $landValue[$x][$y] = 0;
	 $count++;
	 }
 }

 # 뉴타운을 만들기
 $count = 0;
 while($count < 1) {
	 # 무작위좌표
	 $x = random(4) + $center - 1;
	 $y = random(4) + $center - 1;

	 # 그곳이 숲/도시/산이 아니면 기지
	 if(($land[$x][$y] != $HlandTown) &&
	 ($land[$x][$y] != $HlandForest) &&
	 ($land[$x][$y] != $HlandBase) &&
	 ($land[$x][$y] != $HlandMountain)) {
	 $land[$x][$y] = $HlandNewtown;
	 $landValue[$x][$y] = 10;
	 $count++;
	 }
 }

 # 대학을 만들기
 $count = 0;
 while($count < 1) {
	 # 무작위좌표
	 $x = random(4) + $center - 1;
	 $y = random(4) + $center - 1;

	 # 그곳이 숲/도시/산이 아니면 기지
	 if(($land[$x][$y] != $HlandTown) &&
	 ($land[$x][$y] != $HlandForest) &&
	 ($land[$x][$y] != $HlandBase) &&
	 ($land[$x][$y] != $HlandNewtown) &&
	 ($land[$x][$y] != $HlandMountain)) {
	 $land[$x][$y] = $HlandCollege;
	 $landValue[$x][$y] = random(3);

	 $count++;
	 }
 }

 # 항구를 만들기
 $count = 0;
 while($count < 1) {
	 # 무작위좌표
	 $x = random(4) + $center - 1;
	 $y = random(4) + $center - 1;

	# 주변에 육지가 있는지 확인
	my($seaCount) =
	 countAround($land, $x, $y, $HlandSea, 7);

 if($seaCount == 0) {

	 } else {
	 # 그곳이 숲/도시/산이 아니면 기지
	 if(($land[$x][$y] != $HlandTown) &&
	 ($land[$x][$y] != $HlandForest) &&
	 ($land[$x][$y] != $HlandBase) &&
	 ($land[$x][$y] != $HlandNewtown) &&
	 ($land[$x][$y] != $HlandCollege) &&
	 ($land[$x][$y] != $HlandMountain)) {
	 $land[$x][$y] = $HlandMinato;
	 $landValue[$x][$y] = 5;
	 $count++;
	 }
	 }
 }

 # 발전소를 만들기
 $count = 0;
 while($count < 1) {
	 # 무작위좌표
	 $x = random(4) + $center - 1;
	 $y = random(4) + $center - 1;

	 # 그곳이 숲/도시/산이 아니면 기지
	 if(($land[$x][$y] != $HlandTown) &&
	 ($land[$x][$y] != $HlandForest) &&
	 ($land[$x][$y] != $HlandBase) &&
	 ($land[$x][$y] != $HlandNewtown) &&
	 ($land[$x][$y] != $HlandCollege) &&
	 ($land[$x][$y] != $HlandMinato) &&
	 ($land[$x][$y] != $HlandMountain)) {
	 $land[$x][$y] = $HlandEneWd;
	 $landValue[$x][$y] = 50;
	 $count++;
	 }
 }

 # 발전소를 만들기
 $count = 0;
 while($count < 1) {
	 # 무작위좌표
	 $x = random(4) + $center - 1;
	 $y = random(4) + $center - 1;

	 # 그곳이 숲/도시/산이 아니면 기지
	 if(($land[$x][$y] != $HlandTown) &&
	 ($land[$x][$y] != $HlandForest) &&
	 ($land[$x][$y] != $HlandBase) &&
	 ($land[$x][$y] != $HlandNewtown) &&
	 ($land[$x][$y] != $HlandCollege) &&
	 ($land[$x][$y] != $HlandMinato) &&
	 ($land[$x][$y] != $HlandEneWd) &&
	 ($land[$x][$y] != $HlandMountain)) {
	 $land[$x][$y] = $HlandConden;
	 $landValue[$x][$y] = 100;

		if(random(100) < 10) {
	 	$land[$x][$y] = $HlandConden3;
	 	$landValue[$x][$y] = 0;
		}

	 $count++;
	 }
 }

 if($anothermood == 1) {
 # 발전소를 만들기
 $count = 0;
 while($count < 1) {
	 # 무작위좌표
	 $x = random(4) + $center - 1;
	 $y = random(4) + $center - 1;

	 # 그곳이 숲/도시/산이 아니면 기지
	 if(($land[$x][$y] != $HlandTown) &&
	 ($land[$x][$y] != $HlandForest) &&
	 ($land[$x][$y] != $HlandBase) &&
	 ($land[$x][$y] != $HlandNewtown) &&
	 ($land[$x][$y] != $HlandCollege) &&
	 ($land[$x][$y] != $HlandMinato) &&
	 ($land[$x][$y] != $HlandEneWd) &&
	 ($land[$x][$y] != $HlandConden) &&
	 ($land[$x][$y] != $HlandConden3) &&
	 ($land[$x][$y] != $HlandMountain)) {
	 $land[$x][$y] = $HlandShuto;
	 $landValue[$x][$y] = 50;
	 $count++;
	 }
 }
 # 발전소를 만들기
 $count = 0;
 while($count < 1) {
	 # 무작위좌표
	 $x = random(4) + $center - 1;
	 $y = random(4) + $center - 1;

	 # 그곳이 숲/도시/산이 아니면 기지
	 if(($land[$x][$y] != $HlandTown) &&
	 ($land[$x][$y] != $HlandForest) &&
	 ($land[$x][$y] != $HlandBase) &&
	 ($land[$x][$y] != $HlandNewtown) &&
	 ($land[$x][$y] != $HlandCollege) &&
	 ($land[$x][$y] != $HlandMinato) &&
	 ($land[$x][$y] != $HlandEneWd) &&
	 ($land[$x][$y] != $HlandConden) &&
	 ($land[$x][$y] != $HlandConden3) &&
	 ($land[$x][$y] != $HlandShuto) &&
	 ($land[$x][$y] != $HlandMountain)) {
	 $land[$x][$y] = $HlandHouse;
	 $landValue[$x][$y] = 0;
	 $count++;
	 }
 }
 }


 return (\@land, \@landValue);
}

#----------------------------------------------------------------------
# 정보 변경 모드
#----------------------------------------------------------------------
# 메인
sub changeMain {
 # id 에서 섬을 가져옴
 $HcurrentNumber = $HidToNumber{$HcurrentID};
 my($island) = $Hislands[$HcurrentNumber];
 my($flag) = 0;

 # 비밀번호 확인
 if($HoldPassword eq $HspecialPassword) {
	# 특수 비밀번호
	$island->{'money'} = 999999;
	$island->{'food'} = 99999;
 } elsif($HoldPassword eq $HshutoPassword) {
	$island->{'totoyoso2'} = htmlEscape($HcurrentOwnerName);
	$flag = 1;
 } elsif($HoldPassword eq $HomamoriPassword) {
	 $etc8 = $island->{'etc8'};
	 $etc8 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	 ($toto1, $toto2, $toto3, $toto4, $toto5, $toto6, $toto7) = ($1, $2, $3, $4, $5, $6, $7);
	 $toto2++;
	 $island->{'etc8'} = "$toto1,$toto2,$toto3,$toto4,$toto5,$toto6,$toto7";
	$flag = 1;
 } elsif($HoldPassword eq $HijiriPassword) {
	$sthenko = htmlEscape($HcurrentOwnerName);

	if($sthenko eq id) {
	 rename("${HdirName}/island.$island->{'id'}", "${HdirName}/island.$HcurrentName");
	}

	 $eisei5 = $island->{'eisei5'};
	 $eisei5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	 ($mshp, $msap, $msdp, $mssp, $mswin, $msexe, $tetsub) = ($1, $2, $3, $4, $5, $6, $7);

	if($sthenko eq msexe) {
	 $island->{'eisei5'} = "$mshp,$msap,$msdp,$mssp,$mswin,$HcurrentName,$tetsub";
	} elsif($sthenko eq mshp) {
	 $island->{'eisei5'} = "$HcurrentName,$msap,$msdp,$mssp,$mswin,$msexe,$tetsub";
	} elsif($sthenko eq msap) {
	 $island->{'eisei5'} = "$mshp,$HcurrentName,$msdp,$mssp,$mswin,$msexe,$tetsub";
	} elsif($sthenko eq msdp) {
	 $island->{'eisei5'} = "$mshp,$msap,$HcurrentName,$mssp,$mswin,$msexe,$tetsub";
	} elsif($sthenko eq mssp) {
	 $island->{'eisei5'} = "$mshp,$msap,$msdp,$HcurrentName,$mswin,$msexe,$tetsub";
	} else {
	 $island->{"$sthenko"} = "$HcurrentName";
	}

	writeIslandsFile($HcurrentID);
	unlock();
	tempChange();
	return;
 } elsif($HoldPassword eq $HipPassword) {
	$island->{'ip0'} = 0;
	$island->{'ip1'} = 0;
	$island->{'ip2'} = 0;
	$island->{'ip3'} = 0;
	$island->{'ip4'} = 0;
	$island->{'ip5'} = 0;
	$island->{'ip6'} = 0;
	$island->{'ip7'} = 0;
	$island->{'ip8'} = 0;
	$island->{'ip9'} = 0;
	$flag = 1;
 } elsif(!checkPassword($island->{'password'},$HoldPassword)) {
	# password 오류
	unlock();
	tempWrongPassword();
	return;
 }

 # 확인용 비밀번호
 if($HinputPassword2 ne $HinputPassword) {
	# password 오류
	unlock();
	tempWrongPassword();
	return;
 }

 if($HcurrentName ne '') {
	# 이름 변경의 경우
	# 이름이 유효한지 확인
	if($HcurrentName =~ /[,\?\(\)\<\>]|^무인$/) {
	 # 사용 불가 이름
	 unlock();
	 tempNewIslandBadName();
	 return;
	}

	# 이름의 중복 확인
	if(nameToNumber($HcurrentName) != -1) {
	 # 이미 발견완료
	 unlock();
	 tempNewIslandAlready();
	 return;
	}

	if($island->{'money'} < $HcostChangeName) {
	 # 자금 부족
	 unlock();
	 tempChangeNoMoney();
	 return;
	}

	# 대금
	if($HoldPassword ne $HspecialPassword) {
	 $island->{'money'} -= $HcostChangeName;
	}

	# 이름을 변경
	logChangeName($island->{'name'}, $HcurrentName);
	$island->{'name'} = $HcurrentName;
	$flag = 1;
 }

 # password 변경의 경우
 if($HinputPassword ne '') {
	# 비밀번호를 변경
	$island->{'password'} = encode($HinputPassword);
	$flag = 1;
 }

 if($HcurrentOwnerName ne '') {
	$island->{'onm'} = htmlEscape($HcurrentOwnerName);
	$flag = 1;
 }

 if(($flag == 0) && ($HoldPassword ne $HspecialPassword)) {
	# 어느 쪽도 변경되어 있지 않음
	unlock();
	tempChangeNothing();
	return;
 }

 # 데이터 쓰기
 writeIslandsFile($HcurrentID);
 unlock();

 # 변경성공
 tempChange();
}

sub changeOwner {
 # id 에서 섬을 가져옴
 $HcurrentNumber = $HidToNumber{$HcurrentID};
 my($island) = $Hislands[$HcurrentNumber];
 my($flag) = 0;

 if(!checkPassword($island->{'password'},$HoldPassword)) {
 # password 오류
 unlock();
 tempWrongPassword();
 return;
 }
 # 소유자 이름을 변경
 $island->{'ownername'} = htmlEscape($HcurrentOwnerName);
 $flag = 1;

 # 데이터 쓰기
 writeIslandsOwner($HcurrentID);
 unlock();

 # 변경성공
 tempChange();
}

#----------------------------------------------------------------------
# 턴진행 모드
#----------------------------------------------------------------------
# 메인
sub turnMain {
 # 최종 갱신 시간을 갱신
 $HislandLastTime += $HunitTime;

 # 로그 파일을 뒤에밀기
 my($i, $j, $s, $d);
 for($i = ($HlogMax - 1); $i>= 0; $i--) {
	$j = $i + 1;
	my($s) = "${HdirName}/hakojima.log$i";
	my($d) = "${HdirName}/hakojima.log$j";
	unlink($d);
	rename($s, $d);
 }

 # 좌표배열을 만들기
 makeRandomPointArray();

 # 턴번호
 $HislandTurn++;

 # 순서결메
 my(@order) = randomArray($HislandNumber);

 # 수입, 소비단계
 for($i = 0; $i < $HislandNumber; $i++) {

	estimate($order[$i]);
	income($Hislands[$order[$i]]);

	# 턴시작전의 인구를 메모루
	$Hislands[$order[$i]]->{'oldPop'} = $Hislands[$order[$i]]->{'pop'};
	$Hislands[$order[$i]]->{'oldMoney'} = $Hislands[$order[$i]]->{'money'};
	$Hislands[$order[$i]]->{'oldPts'} = $Hislands[$order[$i]]->{'pts'};
 }

 $island->{'Typhoonflag'} = 0;

 # 명령 처리
 for($i = 0; $i < $HislandNumber; $i++) {
	# 반환 값1이 이 될 때까지 반복
	while(doCommand($Hislands[$order[$i]]) == 0){};
 }

 # 성장 및 단일 헥스 재해
 for($i = 0; $i < $HislandNumber; $i++) {
	doEachHex($Hislands[$order[$i]]);
 }

 # 섬 전체 처리
 my($remainNumber) = $HislandNumber;
 my($island);
 for($i = 0; $i < $HislandNumber; $i++) {
	$island = $Hislands[$order[$i]];
	doIslandProcess($order[$i], $island);

	doIslandunemployed($order[$i], $island);

 }

 if(($HislandTurn % 100) == 41) {
	islandSortHC();

	for($i = 0; $i < 8; $i++) {
	$island = $Hislands[$i];
	$eisei4 = $island->{'eisei4'};
	$eisei4 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	($sto, $std, $stk, $stwin, $stdrow, $stlose, $stwint, $stdrowt, $stloset, $styusho, $stshoka) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11);

	if($stshoka != 0) {

	$stshoka = 6;
	$island->{'eisei4'} = "$sto,$std,$stk,$stwin,$stdrow,$stlose,$stwint,$stdrowt,$stloset,$styusho,$stshoka";
	$stsin.= "$island->{'name'} 섬,";
	 }
	 }
	logHCsin($id, $name, $stsin);
 }

	islandSortPop();
 my($islandp) = $Hislands[0];
	islandSortFarm();
 my($islandfm) = $Hislands[0];
	islandSortFactory();
 my($islandfc) = $Hislands[0];
	islandSortMountain();
 my($islandm) = $Hislands[0];
	islandSortMonument();
 my($islandf) = $Hislands[0];
	islandSortLive();
 my($islandl) = $Hislands[0];
	islandSortRena();
 my($islandr) = $Hislands[0];
	islandSortKill();
 my($islandk) = $Hislands[0];
	islandSortFore();
 my($islandw) = $Hislands[0];
	islandSortTare();
 my($islandtare) = $Hislands[0];
	islandSortZipro();
 my($islandzipro) = $Hislands[0];
	islandSortLeje();
 my($islandleje) = $Hislands[0];
	islandSortForce();
 my($islandforce) = $Hislands[0];
	islandSortEisei2();
 my($islandeisei2) = $Hislands[0];
	islandSortUni();
 my($islanduni) = $Hislands[0];

	islandSorthck();
 my($islandhck) = $Hislands[0];
	islandSorthckt();
 my($islandhckt) = $Hislands[0];
	islandSorthcr();
 my($islandhcr) = $Hislands[0];
	islandSorthcy();
 my($islandhcy) = $Hislands[0];
	islandSorthct();
 my($islandhct) = $Hislands[0];

	 $islandp->{'bumon'} ++;
	 $islandfm->{'bumon'} ++;
	 $islandfc->{'bumon'} ++;
	 $islandm->{'bumon'} ++;
	 $islandf->{'bumon'} ++;
	 $islandl->{'bumon'} ++;
	 $islandr->{'bumon'} ++;
	 $islandk->{'bumon'} ++;
	 $islandw->{'bumon'} ++;
	 $islandtare->{'bumon'} ++;
	 $islandzipro->{'bumon'} ++;
	 $islandleje->{'bumon'} ++;
	 $islandforce->{'bumon'} ++;
	 $islandeisei2->{'bumon'} ++;
	 $islanduni->{'bumon'} ++;
	 $islandhck->{'bumon'} ++;
	 $islandhckt->{'bumon'} ++;
	 $islandhcr->{'bumon'} ++;
	 $islandhcy->{'bumon'} ++;
	 $islandhct->{'bumon'} ++;

 my($remainNumber) = $HislandNumber;
 my($island);
 for($i = 0; $i < $HislandNumber; $i++) {
	estimate($order[$i]);

	$island = $Hislands[$order[$i]];
	# 사멸판정
	if($island->{'dead'} == 1) {
	 $island->{'pop'} = 0;
	 $island->{'pts'} = 0;
	 $remainNumber--;
	} elsif($island->{'pop'} == 0) {
	 $island->{'dead'} = 1;
	 $island->{'pts'} = 0;
	 $remainNumber--;
	 # 사멸 메시지
	 my($tmpid) = $island->{'id'};
	 logDead($tmpid, $island->{'name'});
	 unlink("island.$tmpid");
	}

 }

 if(($HislandTurn % $HturnPrizeUnit) == 0) {

	islandSortac4();

	my($island, $ii, $j);
	for($ii = 0; $ii < $HislandNumber; $ii++) {
	 $j = $ii + 1;
	 $island = $Hislands[$ii];
	 $auc0 = $island->{'auc0'};
	 $auc0 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	 ($auc0a, $auc0b, $auc0c, $auc0d, $auc0e) = ($1, $2, $3, $4, $5);
	 $island->{'auc0'} = "$auc0a,$auc0b,$auc0c,$auc0d,$j";

		 $auc4 = $island->{'auc4'};
		 $auc4 =~ /^([0-9]*),([0-9]*),([0-9]*)$/;
		 ($auc4a, $auc4b, $auc4c) = ($1, $2, $3);

		if($ii == 0) {
		 $auc4a++;
		 $auc4b++;
			if($auc4b>= $aucshouhin) {
			 $auc4b = $aucshouhin;
			}
		 $island->{'auc4'} = "$auc4a,$auc4b,$auc4c";
		} else {
		 $island->{'auc4'} = "$auc4a,0,0";
		}

	}

	my($island) = $Hislands[0];
	 my($value, $str);
	 $value = $HislandTurn + random(1001);
	 $island->{'money'} += $value;
	 $str = "$value$HunitMoney";

		 $str.= "/부적 1개";
		 $etc8 = $island->{'etc8'};
		 $etc8 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		 ($toto1, $toto2, $toto3, $toto4, $toto5, $toto6, $toto7) = ($1, $2, $3, $4, $5, $6, $7);
		 $toto2+=1;
		 $island->{'etc8'} = "$toto1,$toto2,$toto3,$toto4,$toto5,$toto6,$toto7";

	 logPrizeAuc($island->{'id'}, $island->{'name'}, "$HislandTurn${Hprize[0]}", $str);

 }

 # 인구순에정렬
 islandSort();

 # 시상 대상 턴이면, 그 처리
 if(($HislandTurn % $HturnPrizeUnit) == 0) {
	my($island) = $Hislands[0];
	 my($value, $str);
	 $value = $HislandTurn + random(1001);
	 $island->{'money'} += $value;
	 $str = "$value$HunitMoney";
	logPrizet($island->{'id'}, $island->{'name'}, "$HislandTurn${Hprize[0]}", $str);
	 if($island->{'sin'}> 0) {
	 my($value, $str);
	 $value = $HislandTurn + random(1001);
	 $island->{'money'} += $value;
	 $str = "$value$HunitMoney";
	 # 수입 로그
	 logSinMoney($island->{'id'}, $island->{'name'}, $str);
	 }
	 if($island->{'jin'}> 0) {
	 my($value, $str);
	 $value = $HislandTurn + random(1001);
	 $island->{'money'} += $value;
	 $str = "$value$HunitMoney";
	 # 수입 로그
	 logJinMoney($island->{'id'}, $island->{'name'}, $str);
	 }
	$island->{'prize'}.= "${HislandTurn},";
 }

 if(($HislandTurn % $HturnPrizeUnit) == 0) {

	$auction1 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	($shuppin1, $avalue1, $ajoutai1, $topvalue1, $topid1) = ($1, $2, $3, $4, $5);

	$shuppin = random(28)+1;
	 $value = 0;
	 if($shuppin == 9) {
		$value = 1 + random(5);
	 } elsif($shuppin == 10) {
		$value = 1000 + random(1500);
	 } elsif($shuppin == 11) {
		$value = 500 + random(1000);
	 } elsif($shuppin == 12) {
		$value = 2000 + random(2000);
	 } elsif($shuppin == 17) {
		$value = 500 + random(750);
	 } elsif($shuppin == 18) {
		$value = 300 + random(500);
	 } elsif($shuppin == 22) {
		$value = 1 + random(4);
	 } elsif($shuppin == 23) {
		$value = 1 + random(4);
	 } elsif($shuppin == 24) {
		$value = 1 + random(999);
	 } elsif($shuppin == 25) {
		$value = 80 + random(3);
	 } elsif($shuppin == 27) {
		$value = 500 + random(2000);
	 } elsif($shuppin == 28) {
		$value = 500 + random(2000);
	 }

	 $ajoutai = 0;

	 if(($aucflag1 < 90) && ($shuppin1 != 29)) {
		$shuppin = 29;
		$ajoutai = 15;
	 }

		$motone = random($shuppin);

	$auction1 = "$shuppin,$value,$ajoutai,$motone,0";


	$auction2 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	($shuppin2, $avalue2, $ajoutai2, $topvalue2, $topid2) = ($1, $2, $3, $4, $5);

	$shuppin = random(28)+1;
	 $value = 0;
	 if($shuppin == 9) {
		$value = 1 + random(5);
	 } elsif($shuppin == 10) {
		$value = 1000 + random(1500);
	 } elsif($shuppin == 11) {
		$value = 500 + random(1000);
	 } elsif($shuppin == 12) {
		$value = 2000 + random(2000);
	 } elsif($shuppin == 17) {
		$value = 500 + random(750);
	 } elsif($shuppin == 18) {
		$value = 300 + random(500);
	 } elsif($shuppin == 22) {
		$value = 1 + random(4);
	 } elsif($shuppin == 23) {
		$value = 1 + random(4);
	 } elsif($shuppin == 24) {
		$value = 1 + random(999);
	 } elsif($shuppin == 25) {
		$value = 80 + random(3);
	 } elsif($shuppin == 27) {
		$value = 500 + random(2000);
	 } elsif($shuppin == 28) {
		$value = 500 + random(2000);
	 }

	 if($HislandNumber < 20) {
		$shuppin = 29;
	 }
	 if(random(1000) < 100-$HislandNumber+$oyasumiritu*25) {
		$shuppin = 29;
	 }

	 $ajoutai = 0;
	 if($shuppin == 29) {
		$ajoutai = 15;
	 }

	 if(($aucflag2 < 120) && ($shuppin2 != 29)) {
		$shuppin = 29;
		$ajoutai = 15;
	 }

		$motone = random($shuppin)*2;

	$auction2 = "$shuppin,$value,$ajoutai,$motone,0";


	$auction3 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	($shuppin3, $avalue3, $ajoutai3, $topvalue3, $topid3) = ($1, $2, $3, $4, $5);

	$shuppin = random(28)+1;
	 $value = 0;
	 if($shuppin == 9) {
		$value = 1 + random(5);
	 } elsif($shuppin == 10) {
		$value = 1000 + random(1500);
	 } elsif($shuppin == 11) {
		$value = 500 + random(1000);
	 } elsif($shuppin == 12) {
		$value = 2000 + random(2000);
	 } elsif($shuppin == 17) {
		$value = 500 + random(750);
	 } elsif($shuppin == 18) {
		$value = 300 + random(500);
	 } elsif($shuppin == 22) {
		$value = 1 + random(4);
	 } elsif($shuppin == 23) {
		$value = 1 + random(4);
	 } elsif($shuppin == 24) {
		$value = 1 + random(999);
	 } elsif($shuppin == 25) {
		$value = 80 + random(3);
	 } elsif($shuppin == 27) {
		$value = 500 + random(2000);
	 } elsif($shuppin == 28) {
		$value = 500 + random(2000);
	 }

	 if($HislandNumber < 30) {
		$shuppin = 29;
	 }

	 if(random(1000) < $oyasumiritu*12.5) {
		$shuppin = 29;
	 }

	 $ajoutai = 0;
	 if($shuppin == 29) {
		$ajoutai = 15;
	 }

	 if(($aucflag3 < 60) && ($shuppin3 != 29)) {
		$shuppin = 29;
		$ajoutai = 15;
	 }

		$motone = random($shuppin);

	$auction3 = "$shuppin,$value,$ajoutai,$motone,0";
 }

 $auction1 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
 ($shuppin1, $avalue1, $ajoutai1, $topvalue1, $topid1) = ($1, $2, $3, $4, $5);
	if($ajoutai1 < 15) {
	 $ajoutai1++;
	}
	if((($HislandTurn % $HturnPrizeUnit)> 74) && (random(100) < 5)) {
	 $ajoutai1 = 15;
	}
 $auction1 = "$shuppin1,$avalue1,$ajoutai1,$topvalue1,$topid1";

 $auction2 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
 ($shuppin2, $avalue2, $ajoutai2, $topvalue2, $topid2) = ($1, $2, $3, $4, $5);
	if($ajoutai2 < 15) {
	 $ajoutai2++;
	}
	if((($HislandTurn % $HturnPrizeUnit)> 74) && (random(100) < 5)) {
	 $ajoutai2 = 15;
	}
 $auction2 = "$shuppin2,$avalue2,$ajoutai2,$topvalue2,$topid2";

 $auction3 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
 ($shuppin3, $avalue3, $ajoutai3, $topvalue3, $topid3) = ($1, $2, $3, $4, $5);
	if($ajoutai3 < 15) {
	 $ajoutai3++;
	}
	if((($HislandTurn % $HturnPrizeUnit)> 74) && (random(100) < 5)) {
	 $ajoutai3 = 15;
	}
 $auction3 = "$shuppin3,$avalue3,$ajoutai3,$topvalue3,$topid3";

 # 섬 수자르기
 $HislandNumber = $remainNumber;

##### 여기에서
 # toto 처리
 unless ($HislandTurn % $HturnPrizeUnit) {
 # 턴잔의 턴라면

 # toto 정답을 계산
 my(@totoAns, $island);
 foreach $island (@Hislands[0..4, 9, 19, 29]) {
 push(@totoAns, (defined $island->{'id'} ? $island->{'id'} : '0'));
 }

 # 정답의 로그 작성
 logHistory("${HtagName_}제${HislandTurn}턴 toto${H_tagName} <B>: @totoAns</B>");

 # toto의 적중판정을 하다
 my($allBet, @totoID);
 my(@totoBet, $i, $j, $n);
 for ($i = 0; $i < $HislandNumber; $i++) {
 $island = $Hislands[$i];
 next unless (@totoBet = ($island->{'eis8'} =~ /\(toto\@(\d+)\.(\d+)\.(\d+)\.(\d+)\.(\d+)\.(\d+)\.(\d+)\.(\d+)\)/));

 # toto 구매희망라면
 my $betCost = 1000; # 구매비용 1000 억 엔
 if ($island->{'money'} < $betCost) {
 # 구매 비용 없음
 logNoMoney($island->{'id'}, $island->{'name'}, 'toto 구매');
 } else {
 # 구매비용이 있음
 $island->{'money'} -= $betCost;
 $allBet += $betCost;

 # 적중점 수의 판정
 for ($n = 0, $j = 0; $j <= $#totoAns; $j++) {
 $n++ if ($totoAns[$j] == $totoBet[$j]);
 }

 # 구매결과 를기억
 $totoID[$n].= "$i,";
 }
 }

 # 적중 점수별 배당률
 my @rate;
 $rate[8] = 20;
 $rate[7] = 8;
 $rate[6] = 2;

 # toto 배당을 처리
 # (6점 적중~8점 적중)
 my(@id, $bet);
 foreach $i (6..8) {
 if ($totoID[$i] ne '') {
 # 정답자가 있음
 @id = split(/,/, $totoID[$i]);
 $bet = int($allBet * $rate[$i] / ($#id + 1));

 # 배당 금액 로그 작성
 logHistory("${HtagName_}제${HislandTurn}턴 toto${H_tagName} ${i}점 적중 ☆ 배당금 옥션 자금 융통 $bet$HunitMoney");

 foreach $n (@id) {
 $island = $Hislands[$n];

		$auc9 = $island->{'auc9'};
		$auc9 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		($auc9a, $auc9b, $auc9c, $auc9d, $auc9e) = ($1, $2, $3, $4, $5);
		$auc9c += $bet;
		$auc9c2 = int($auc9c/10000);
		$auc9a = $auc9b + $auc9c2 + $auc9d + $auc9e;
		$island->{'auc9'} = "$auc9a,$auc9b,$auc9c,$auc9d,$auc9e";

	 $totoget=$i-5;
 logOut("${HtagName_}$island->{'name'} 섬${H_tagName} ${HtagName_}toto${H_tagName} ${i}점 적중! 부적 ${totoget}개 획득!", $island->{'id'});

	 $etc8 = $island->{'etc8'};
	 $etc8 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	 ($toto1, $toto2, $toto3, $toto4, $toto5, $toto6, $toto7) = ($1, $2, $3, $4, $5, $6, $7);
	 $toto1++;
	 $toto2+=$i-5;
	 $island->{'etc8'} = "$toto1,$toto2,$toto3,$toto4,$toto5,$toto6,$toto7";

 }
 } else {
 # 정답자 없음
 $rate[$i + 1] += $rate[$i]; # 배당 예산을 상위 등급으로 이월
 }
 }
 }
##### 여기까지

 # HCtoto 처리

 if((($HislandTurn % 100) == 50) && (($yushouflag == 1) || ($yushouflag == 2))) {

 # toto 정답을 계산

 my @totoAns = ($yushounamber, $yushounamber2);

 # 정답의 로그 작성
 logHistory("${HtagName_}제${HislandTurn}턴 Hakoniwa Cup toto${H_tagName} <B>: @totoAns</B>");
 # toto의 적중판정을 하다
 my($allBet, @totoID);
 my(@totoBet, $i, $j, $n);
 for ($i = 0; $i < $HislandNumber; $i++) {
 $island = $Hislands[$i];
 next unless (@totoBet = ($island->{'eis8'} =~ /\(hc\@(\d+)\.(\d+)\)/));

 # toto 구매희망라면
 my $betCost = 10000; # 구매비용 1000 억 엔
 if ($island->{'money'} < $betCost) {
 # 구매 비용 없음
 logNoMoney($island->{'id'}, $island->{'name'}, 'Hakoniwa Cup toto');
 } else {
 # 구매비용이 있음
 $island->{'money'} -= $betCost;
 $allBet += $betCost;

 # 적중점 수의 판정
 for ($n = 0, $j = 0; $j <= $#totoAns; $j++) {
 $n++ if ($totoAns[$j] == $totoBet[$j]);
 }

 # 구매결과 를기억
 $totoID[$n].= "$i,";
 }
 }

 # 적중 점수별 배당률
 my @rate;
 $rate[2] = 10;
 $rate[1] = 3;

 # toto 배당을 처리
 # (6점 적중~8점 적중)
 my(@id, $bet);
 foreach $i (1..2) {
 if ($totoID[$i] ne '') {
 # 정답자가 있음
 @id = split(/,/, $totoID[$i]);
 $bet = int($allBet * $rate[$i] / ($#id + 1));

 # 배당 금액 로그 작성
 logHistory("${HtagName_}제${HislandTurn}턴 Hakoniwa Cup toto${H_tagName} ${i}점 적중 ☆ 배당금 옥션 자금 융통 $bet$HunitMoney");

 foreach $n (@id) {
 $island = $Hislands[$n];

		$auc9 = $island->{'auc9'};
		$auc9 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		($auc9a, $auc9b, $auc9c, $auc9d, $auc9e) = ($1, $2, $3, $4, $5);
		$auc9c += $bet;
		$auc9c2 = int($auc9c/10000);
		$auc9a = $auc9b + $auc9c2 + $auc9d + $auc9e;
		$island->{'auc9'} = "$auc9a,$auc9b,$auc9c,$auc9d,$auc9e";

		if($i == 1) {
		 $totoget=1;
		}
		if($i == 2) {
		 $totoget=2;
		}

	 $etc8 = $island->{'etc8'};
	 $etc8 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	 ($toto1, $toto2, $toto3, $toto4, $toto5, $toto6, $toto7) = ($1, $2, $3, $4, $5, $6, $7);
	 $toto1++;
	 $toto2+=$totoget;
	 $island->{'etc8'} = "$toto1,$toto2,$toto3,$toto4,$toto5,$toto6,$toto7";

 logOut("${HtagName_}$island->{'name'} 섬${H_tagName} ${HtagName_}Hakoniwa Cup toto${H_tagName} ${i}점 적중! 부적 ${totoget}개 획득!", $island->{'id'});

 }
 } else {
 # 정답자 없음
 $rate[$i + 1] += $rate[$i]; # 배당 예산을 상위 등급으로 이월
 }
 }
 }

##### 여기까지

 # Numbers3 처리

 if(($HislandTurn % 20) == 0) {

 # toto 정답을 계산
 my @totoAns = (random(999));

 # 정답의 로그 작성
 logHistory("${HtagName_}제${HislandTurn}턴 Numbers3${H_tagName} <B>: @totoAns</B>");

 # toto의 적중판정을 하다
 my($allBet, @totoID);
 my(@totoBet, $i, $j, $n);
 for ($i = 0; $i < $HislandNumber; $i++) {
 $island = $Hislands[$i];
 next unless (@totoBet = ($island->{'eis8'} =~ /\(n3\@(\d+)\)/));

 # toto 구매희망라면
 my $betCost = 200; # 구매비용 200 억 엔
 if ($island->{'money'} < $betCost) {
 # 구매 비용 없음
 logNoMoney($island->{'id'}, $island->{'name'}, 'Numbers3구매');
 } else {
 # 구매비용이 있음
 $island->{'money'} -= $betCost;
 $allBet += $betCost;

 # 적중점 수의 판정
 for ($n = 0, $j = 0; $j <= $#totoAns; $j++) {
 $n++ if ($totoAns[$j] == $totoBet[$j]);
 }

 # 구매결과 를기억
 $totoID[$n].= "$island->{'id'},";
 }
 }

 # 적중 점수별 배당률
 my @rate;
 $rate[1] = 100;

 # toto 배당을 처리
 # (6점 적중~8점 적중)
 my(@id, $bet);
 foreach $i (1) {
 if ($totoID[$i] ne '') {
 # 정답자가 있음
 @id = split(/,/, $totoID[$i]);
 $bet = int($allBet * $rate[$i] / ($#id + 1));

 # 배당 금액 로그 작성
 logHistory("${HtagName_}제${HislandTurn}턴 Numbers3${H_tagName} 적중☆배당금 $bet$HunitMoney");

 foreach $n (@id) {
 $island = $Hislands[$HidToNumber{$n}];
 $island->{'money'} += $bet;
 logOut("${HtagName_}$island->{'name'} 섬${H_tagName} ${HtagName_}Numbers3${H_tagName} 적중!", $n);
 }
 } else {
 # 정답자 없음
 $rate[$i + 1] += $rate[$i]; # 배당 예산을 상위 등급으로 이월
 }
 }
 }
##### 여기까지

 # Numbers4 처리

 if(($HislandTurn % 20) == 10) {

 # toto 정답을 계산
 my @totoAns = (random(9999));

 # 정답의 로그 작성
 logHistory("${HtagName_}제${HislandTurn}턴 Numbers4${H_tagName} <B>: @totoAns</B>");

 # toto의 적중판정을 하다
 my($allBet, @totoID);
 my(@totoBet, $i, $j, $n);
 for ($i = 0; $i < $HislandNumber; $i++) {
 $island = $Hislands[$i];
 next unless (@totoBet = ($island->{'eis8'} =~ /\(n4\@(\d+)\)/));

 # toto 구매희망라면
 my $betCost = 200; # 구매비용 200 억 엔
 if ($island->{'money'} < $betCost) {
 # 구매 비용 없음
 logNoMoney($island->{'id'}, $island->{'name'}, 'Numbers4구매');
 } else {
 # 구매비용이 있음
 $island->{'money'} -= $betCost;
 $allBet += $betCost;

 # 적중점 수의 판정
 for ($n = 0, $j = 0; $j <= $#totoAns; $j++) {
 $n++ if ($totoAns[$j] == $totoBet[$j]);
 }

 # 구매결과 를기억
 $totoID[$n].= "$island->{'id'},";
 }
 }

 # 적중 점수별 배당률
 my @rate;
 $rate[1] = 200;

 # toto 배당을 처리
 # (6점 적중~8점 적중)
 my(@id, $bet);
 foreach $i (1) {
 if ($totoID[$i] ne '') {
 # 정답자가 있음
 @id = split(/,/, $totoID[$i]);
 $bet = int($allBet * $rate[$i] / ($#id + 1));

 # 배당 금액 로그 작성
 logHistory("${HtagName_}제${HislandTurn}턴 Numbers4${H_tagName} 적중☆배당금 $bet$HunitMoney");

 foreach $n (@id) {
 $island = $Hislands[$HidToNumber{$n}];
 $island->{'money'} += $bet;
 logOut("${HtagName_}$island->{'name'} 섬${H_tagName} ${HtagName_}Numbers4${H_tagName} 적중!", $n);
 }
 } else {
 # 정답자 없음
 $rate[$i + 1] += $rate[$i]; # 배당 예산을 상위 등급으로 이월
 }
 }
 }
##### 여기까지

 if(($HislandTurn % 100) == 0) {
 $stsanka = $stsanka - 1;
 logHC($id, $name, $stsanka);
 }

 if($AnkeitoOnOff == 0) {
	$an1 = 0;
	$an2 = 0;
	$an3 = 0;
	$an4 = 0;
	$an5 = 0;
 }

 # 백업 턴이면 삭제 전에 rename
 if(($HislandTurn % $HbackupTurn) == 0) {
	my($i);
	my($tmp) = $HbackupTimes - 1;
	myrmtree("${HdirName}.bak$tmp");
	for($i = ($HbackupTimes - 1); $i> 0; $i--) {
	 my($j) = $i - 1;
	 rename("${HdirName}.bak$j", "${HdirName}.bak$i");
	}
	rename("${HdirName}", "${HdirName}.bak0");
	mkdir("${HdirName}", $HdirMode);

	# 로그 파일만 복구
	for($i = 0; $i <= $HlogMax; $i++) {
	 rename("${HdirName}.bak0/hakojima.log$i",
		 "${HdirName}/hakojima.log$i");
	}
	rename("${HdirName}.bak0/hakojima.his",
	 "${HdirName}/hakojima.his");
	rename("${HdirName}.bak0/hakojima.lhc",
	 "${HdirName}/hakojima.lhc");
	rename("${HdirName}.bak0/hakojima.auc",
	 "${HdirName}/hakojima.auc");
 }

 # 파일에쓰기
 writeIslandsFile(-1);

 my($uti, $sti, $cuti, $csti) = times();
 $uti += $cuti;
 $sti += $csti;
 my($cpu) = $uti + $sti;
 logOut("<SMALL>부하계측 CPU($cpu) : user($uti) system($sti) Ver.050309</SMALL>",0);

 # 로그 쓰기
 logFlush();

 # 기록 로그 조정
 logHistoryTrim();

 logHcupTrim();

 logAucTrim();

 # 맨 위로
 topPageMain();
}

# 디렉터리 삭제
sub myrmtree {
 my($dn) = @_;
 opendir(DIN, "$dn/");
 my($fileName);
 while($fileName = readdir(DIN)) {
	unlink("$dn/$fileName");
 }
 closedir(DIN);
 rmdir($dn);
}

# 수입, 소비단계
sub income {
 my($island) = @_;
 my($pop, $farm, $factory, $mountain) =
	(
	 $island->{'pop'},
	 $island->{'farm'} * 10,
	 $island->{'factory'},
	 $island->{'mountain'}
	 );

	$factory =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	($factory1, $factory2, $co0, $co1, $htf, $shtf, $co95, $co95, $co95, $co95) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10);

 $island->{'incomemoney'} = 0;

 # 수입
 if($pop> $farm) {
	# 농업만으로 인력이 남는 경우
	$island->{'food'} += $farm * ($island->{'co0'} + 1); # 농장 전체가동


	 if($factory2 * 10> ($pop - $farm)) {

		 $auc9 = $island->{'auc9'};
		 $auc9 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		 ($auc9a, $auc9b, $auc9c, $auc9d, $auc9e) = ($1, $2, $3, $4, $5);

			$auc9c += int(($pop - $farm) / 10);

		 $auc9c2 = int($auc9c/10000);
		 $auc9a = $auc9b + $auc9c2 + $auc9d + $auc9e;
		 $island->{'auc9'} = "$auc9a,$auc9b,$auc9c,$auc9d,$auc9e";

	 } else {

		 $auc9 = $island->{'auc9'};
		 $auc9 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		 ($auc9a, $auc9b, $auc9c, $auc9d, $auc9e) = ($1, $2, $3, $4, $5);

			$auc9c += $factory2;

		 if($island->{'shouhi'}> $island->{'ene'}) {

			$island->{'money'} +=
			 min(int(($pop - $farm - $factory2*10) / 20),
				 int(($factory1 + $mountain)/2));
			$island->{'incomemoney'} +=
			 min(int(($pop - $farm - $factory2*10) / 20),
				 int(($factory1 + $mountain)/2));
			logStarve2($island->{'id'}, $island->{'name'});
		 } else {
			$island->{'money'} +=
			 min(int(($pop - $farm - $factory2*10) / 10),
				 $factory1 + $mountain) * ($island->{'co1'} + 1);
			$island->{'incomemoney'} +=
			 min(int(($pop - $farm - $factory2*10) / 10),
				 $factory1 + $mountain) * ($island->{'co1'} + 1);
		 }

		 $auc9c2 = int($auc9c/10000);
		 $auc9a = $auc9b + $auc9c2 + $auc9d + $auc9e;
		 $island->{'auc9'} = "$auc9a,$auc9b,$auc9c,$auc9d,$auc9e";
	 }

 } else {
	# 농장 규모가 최대치의 경우
	$island->{'food'} += $pop * ($island->{'co0'} + 1); # 전체나 생 직원일
 }

 # 식량소비
 $island->{'food'} = int(($island->{'food'}) - ($pop * $HeatenFood));
}


# 명령단계
sub doCommand {
 my($island) = @_;

 # 명령 처리 시작
 my($comArray, $command);
 $comArray = $island->{'command'};
 $command = $comArray->[0]; # 첫 항목을 꺼냄
 slideFront($comArray, 0); # 이후를 막힘하기

 # 각 요소 꺼내기
 my($kind, $target, $x, $y, $arg) =
	(
	 $command->{'kind'},
	 $command->{'target'},
	 $command->{'x'},
	 $command->{'y'},
	 $command->{'arg'}
	 );

 # 도출 값
 my($name) = $island->{'name'};
 my($id) = $island->{'id'};
 my($land) = $island->{'land'};
 my($landValue) = $island->{'landValue'};
 my($landKind) = $land->[$x][$y];
 my($lv) = $landValue->[$x][$y];
 my($cost) = $HcomCost[$kind];
 my($comName) = $HcomName[$kind];
 my($point) = "($x, $y)";
 my($landName) = landName($landKind, $lv);

	$jikkouarg = 0;

 if($kind == $HcomDoNothing) {
	# 자금 융통
	logDoNothing($id, $name, $comName);
	$island->{'money'} += 100;
	$island->{'money'} += random(100);
		 if(random(100) < 5) {
		 my($value, $str, $lName);
		 $lName = landName($landKind, $lv);
		 $value = 1+ random(1999);
		 $island->{'money'} += $value;
		 $str = "$value$HunitMoney";
	 # 수입 로그
	 logEnjo($id, $name, $lName, "($x, $y)", $str) if ($value> 0);
		 }
	$island->{'absent'} ++;

	# 자동포기
	if($island->{'absent'}>= $HgiveupTurn) {
	 $comArray->[0] = {
		'kind' => $HcomGiveup,
		'target' => 0,
		'x' => 0,
		'y' => 0,
		'arg' => 0
	 }
	}
	return 1;
 }

 $island->{'absent'} = 0;

 if($anothermood == 1) {
	 if($kind == $HcomHouse) {
		$cost = $island->{'pts'}*2;
	 }
	 if($kind == $HcomKai) {
		$cost = $island->{'pts'}*2;
	 }
	 if($kind == $HcomBoku2) {
		$cost = $island->{'pts'}*4;
	 }
 } else {
	 if($kind == $HcomHouse) {
		$cost = $island->{'pts'}*3;
	 }
	 if($kind == $HcomBettown) {
		$cost = $island->{'pts'};
	 }
	 if($kind == $HcomKai) {
		$cost = $island->{'pts'};
	 }
	 if($kind == $HcomBoku2) {
		$cost = $island->{'pts'}*4;
	 }
 }

			 if($island->{'pts'}> $HouseLevel9) {
			 	 $costx = 2;
			 } elsif($island->{'pts'}> $HouseLevel8) {
			 	 $costx = 1.8;
			 } elsif($island->{'pts'}> $HouseLevel7) {
				 $costx = 1.8;
			 } elsif($island->{'pts'}> $HouseLevel6) {
			 	 $costx = 1.6;
			 } elsif($island->{'pts'}> $HouseLevel5) {
				 $costx = 1.6;
			 } elsif($island->{'pts'}> $HouseLevel4) {
			 	 $costx = 1.4;
			 } elsif($island->{'pts'}> $HouseLevel3) {
				 $costx = 1.4;
			 } elsif($island->{'pts'}> $HouseLevel2) {
			 	 $costx = 1.2;
			 } elsif($island->{'pts'}> $HouseLevel1) {
				 $costx = 1;
			 } else {
				 $costx = 1;
			 }

 if (($anothermood != 1) && ($kind != $HcomKura) && ($kind != $HcomKura2) && ($kind != $HcomKuraf) && ($kind != $HcomHouse) && ($kind != $HcomBettown) && ($kind != $HcomKai) && ($kind != $HcomBoku2) && ($kind != $HcomEneCs) && ($kind != $HcomEneNF) && ($kind != $HcomEisei) && ($kind != $HcomSell) && ($kind != $HcomMoney) && ($kind != $HcomFood) && ($kind != $HcomGivefood)) {
	$cost = $cost * $costx;
 }

 if (($island->{'htf'}> 0) && ($kind != $HcomKura) && ($kind != $HcomKura2) && ($kind != $HcomKuraf) && ($kind != $HcomSell) && ($kind != $HcomMoney) && ($kind != $HcomFood) && ($kind != $HcomGivefood)) {
	$cost = int($cost * 2 / 3);
 } elsif (($island->{'shtf'}> 0) && ($kind != $HcomKura) && ($kind != $HcomKura2) && ($kind != $HcomKuraf) && ($kind != $HcomSell) && ($kind != $HcomMoney) && ($kind != $HcomFood) && ($kind != $HcomGivefood)) {
	$cost = int($cost * 9 / 10);
 }

 $costco95 = 0.975**$island->{'co95'};

	 if($costco95 < 0.9) {
		$costco95 = 0.9;
	 }

 if (($island->{'co95'}> 0) && ($kind != $HcomKura) && ($kind != $HcomKura2) && ($kind != $HcomKuraf) && ($kind != $HcomSell) && ($kind != $HcomMoney) && ($kind != $HcomFood) && ($kind != $HcomGivefood)) {
	$cost = int($cost * $costco95);
 }

 $etc5 = $island->{'etc5'};
 $etc5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
 ($s00,$s01,$s02,$s03,$s04,$s05,$s06,$s07,$s08,$s09,$s10,$s11,$s12,$s13,$s14,$s15,$s16,$s17,$s18,$s19,$s20,$s21,$s22,$s23,$s24,$s25,$s26,$s27,$s28,$s29,$s30) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);

 $costseisaku = $s01+$s03+$s05+$s07+$s09+$s11+$s13+$s15+$s17+$s19+$s21+$s23+$s25+$s27+$s29+$s02+$s04+$s06+$s08+$s10+$s12+$s14+$s16+$s18+$s20+$s22+$s24+$s26+$s28+$s30;
 $costseisaku2 = 0.9975**$costseisaku;

 if($costseisaku2 < 0.75) {
	$costseisaku2 = 0.75;
 }

 if (($s00> 0) && ($kind != $HcomKura) && ($kind != $HcomKura2) && ($kind != $HcomKuraf) && ($kind != $HcomSell) && ($kind != $HcomMoney) && ($kind != $HcomFood) && ($kind != $HcomGivefood)) {
	$cost = int($cost * $costseisaku2);
 }

 $s12b = int($s12/5)+1;
 if($s12b> 10) {$s12b = 10;}

 $costmoney = $island->{'money'}/5/(999999*$s12b)+0.8;

 if (($kind != $HcomKura) && ($kind != $HcomKura2) && ($kind != $HcomKuraf) && ($kind != $HcomSell) && ($kind != $HcomMoney) && ($kind != $HcomFood) && ($kind != $HcomGivefood)) {
	$cost = int($cost * $costmoney);
 }

 # 비용 확인
 if($cost> 0) {
	# 금의 경우
	if($island->{'money'} < $cost) {
	if((($landKind == $HlandFarmchi) && ($kind == $HcomFarmcpc)) ||
	 (($landKind == $HlandFarmpic) && ($kind == $HcomFarmcpc)) ||
	 (($landKind == $HlandFarmcow) && ($kind == $HcomFarmcpc))) {
	} else {
	 logNoMoney($id, $name, $comName);
	 return 0;
	}
	}
 } elsif($cost < 0) {
	# 식량의 경우
	if($island->{'food'} < (-$cost)) {
	 logNoFood($id, $name, $comName);
	 return 0;
	}
 }

 # 명령에서 분기
 if(($kind == $HcomPrepare) ||
 ($kind == $HcomPrepare2)) {
	# 개간, 땅고르기
	if(($landKind == $HlandSea) ||
	 ($landKind == $HlandSbase) ||
	 ($landKind == $HlandSeacity) ||
	 ($landKind == $HlandSeatown) ||
	 ($landKind == $HlandOil) ||
	 ($landKind == $HlandIce) ||
	 ($landKind == $HlandFune) ||
	 ($landKind == $HlandFrocity) ||
 ($landKind == $HlandNursery) ||
	 ($landKind == $HlandUmiamu) ||
	 ($landKind == $HlandGold) ||
	 ($landKind == $HlandRottenSea) ||
	 ($landKind == $HlandMountain) ||
	 ($landKind == $HlandUmishuto) ||
	 ($landKind == $HlandMonster)) {
	 # 바다, 해저 기지, 유전, 산, 괴수는 개간할 수 없
	 logLandFail($id, $name, $comName, $landName, $point);
	 return 0;
	}

 if ((($landKind == $HlandMonument) && ($lv == 80)) ||
	 (($landKind == $HlandMonument) && ($lv == 81)) ||
	 (($landKind == $HlandMonument) && ($lv == 82)) ||
	 (($landKind == $HlandMonument) && ($lv == 83))) {
		$island->{'food'} += 20000; # 먹은 만큼
	}

 if ((($landKind == $HlandMonument) && ($lv == 74)) ||
	 (($landKind == $HlandMonument) && ($lv == 75)) ||
	 (($landKind == $HlandMonument) && ($lv == 76)) ||
	 (($landKind == $HlandMonument) && ($lv == 77)) ||
	 (($landKind == $HlandMonument) && ($lv == 78)) ||
	 (($landKind == $HlandMonument) && ($lv == 79))) {
		$island->{'money'} += 20000; # 보물석회회사매각
	}

	# 대상 위치를 평지로
	$land->[$x][$y] = $HlandPlains;
	$landValue->[$x][$y] = 0;

	logLandSuc($id, $name, '개간', $point);

	# 돈을 차감
	$island->{'money'} -= $cost;

	if($kind == $HcomPrepare2) {
	 # 땅고르기
	 $island->{'prepare2'}++;

	 # 턴소비하지 않고
	 return 0;
	} else {
	 # 땅고르기이면 매장금 발견 가능성 있음
	 if(random(1000) < $HdisMaizo) {
		my($v) = 100 + random(901);
		$island->{'money'} += $v;
		logMaizo($id, $name, $comName, $v);
	 }
	 return 1;
	}
 } elsif(($kind == $HcomReclaim) ||
	 ($kind == $HcomReclaim2) ||
	 ($kind == $HcomReclaim3)) {
	# 매립
	if(($landKind != $HlandSea) &&
	 ($landKind != $HlandPlains) &&
	 ($landKind != $HlandPlains2) &&
	 ($landKind != $HlandWaste) &&
	 ($landKind != $HlandOil) &&
 ($landKind != $HlandNursery) &&
	 ($landKind != $HlandUmiamu) &&
	 ($landKind != $HlandSbase) &&
	 ($landKind != $HlandSeatown) &&
	 ($landKind != $HlandUmishuto) &&
	 ($landKind != $HlandSeacity)) {
	 # 바다, 해저 기지, 유전만매립할 수 없
	 logLandFail($id, $name, $comName, $landName, $point);
	 return 0;
	}

	# 주변에 육지가 있는지 확인
	my($seaCount) =
	 countAround($land, $x, $y, $HlandSea, 7) +
	 countAround($land, $x, $y, $HlandOil, 7) +
	 countAround($land, $x, $y, $HlandIce, 7) +
	 countAround($land, $x, $y, $HlandSbase, 7) +
	 countAround($land, $x, $y, $HlandFune, 7) +
	 countAround($land, $x, $y, $HlandFrocity, 7) +
 countAround($land, $x, $y, $HlandNursery, 7) +
	 countAround($land, $x, $y, $HlandUmiamu, 7) +
	 countAround($land, $x, $y, $HlandSeatown, 7) +
	 countAround($land, $x, $y, $HlandUmishuto, 7) +
 countAround($land, $x, $y, $HlandSeacity, 7);

 if(($seaCount == 7) &&
	 (($kind == $HcomReclaim)||($kind == $HcomReclaim3))) {
	 # 전체 바다다에서 매립불능
	 logNoLandAround($id, $name, $comName, $point);
	 return 0;
	}

	if(($landKind == $HlandSea) && ($lv == 1)) {
	 # 얕은 바다의 경우
	 # 대상 위치를 황무지로
	 $land->[$x][$y] = $HlandWaste;
	 $landValue->[$x][$y] = 0;

		if($kind == $HcomReclaim3) {
		 $land->[$x][$y] = $HlandMountain;
		 $landValue->[$x][$y] = 0;
		}

	 logLandSuc($id, $name, $comName, $point);
	 $island->{'area'}++;

	 if($seaCount <= 4) {
		# 주변 바다가 3헥스 이내이므로 얕은 바다로
		my($i, $sx, $sy);

		for($i = 1; $i < 7; $i++) {
		 $sx = $x + $ax[$i];
		 $sy = $y + $ay[$i];

		 # 행 기준 위치 조정
		 if((($sy % 2) == 0) && (($y % 2) == 1)) {
			$sx--;
		 }

		 if(($sx < 0) || ($sx>= $HislandSize) ||
		 ($sy < 0) || ($sy>= $HislandSize)) {
		 } else {
			# 범위 안의 경우
			if($land->[$sx][$sy] == $HlandSea) {
			 $landValue->[$sx][$sy] = 1;
			}
		 }
		}
	 }
	} elsif($landKind == $HlandPlains || $landKind == $HlandPlains2 || $landKind == $HlandWaste) {
	 # 바다이면 대상 위치를 얕은 바다로 변경
	 $land->[$x][$y] = $HlandMountain;
	 $landValue->[$x][$y] = 0;
	 logLandSuc($id, $name, $comName, $point);
	} elsif(($kind == $HcomReclaim3) && ($landKind == $HlandSea) && ($lv == 1)) {
	 # 바다이면 대상 위치를 얕은 바다로 변경
	 $land->[$x][$y] = $HlandMountain;
	 $landValue->[$x][$y] = 0;
	 logLandSuc($id, $name, $comName, $point);
	} elsif($kind == $HcomReclaim3) {
	 # 바다이면 대상 위치를 얕은 바다로 변경
	 $land->[$x][$y] = $HlandWaste;
	 $landValue->[$x][$y] = 0;
	 logLandSuc($id, $name, $comName, $point);
	} else {
	 # 바다이면 대상 위치를 얕은 바다로 변경
	 $land->[$x][$y] = $HlandSea;
	 $landValue->[$x][$y] = 1;
	 logLandSuc($id, $name, $comName, $point);
	}

	# 돈을 차감
	$island->{'money'} -= $cost;
	return 1;
 } elsif($kind == $HcomMinato) {
	# 항구
	if(($landKind != $HlandSea) &&
	 ($landKind != $HlandOil) &&
	 ($landKind != $HlandSbase) &&
 ($landKind != $HlandNursery) &&
	 ($landKind != $HlandUmiamu) &&
	 ($landKind != $HlandSeatown) &&
	 ($landKind != $HlandUmishuto) &&
	 ($landKind != $HlandSeacity)) {
	 # 바다, 해저 기지, 유전만매립할 수 없
	 logLandFail($id, $name, $comName, $landName, $point);
	 return 0;
	}

	# 주변에 육지가 있는지 확인
	my($seaCount) =
	 countAround($land, $x, $y, $HlandSea, 7) +
	 countAround($land, $x, $y, $HlandOil, 7) +
	 countAround($land, $x, $y, $HlandIce, 7) +
	 countAround($land, $x, $y, $HlandSbase, 7) +
	 countAround($land, $x, $y, $HlandFune, 7) +
	 countAround($land, $x, $y, $HlandFrocity, 7) +
 countAround($land, $x, $y, $HlandNursery, 7) +
	 countAround($land, $x, $y, $HlandUmiamu, 7) +
	 countAround($land, $x, $y, $HlandSeatown, 7) +
	 countAround($land, $x, $y, $HlandUmishuto, 7) +
 countAround($land, $x, $y, $HlandSeacity, 7);

 if($seaCount == 7) {
	 # 전체 바다다에서 매립불능
	 logNoLandAround($id, $name, $comName, $point);
	 return 0;
	}

	if(($landKind == $HlandSea) && ($lv == 1)) {
	 # 얕은 바다의 경우
	 # 대상 위치를 황무지로
	 $land->[$x][$y] = $HlandMinato;
	 $landValue->[$x][$y] = 0;
	 logLandSuc($id, $name, $comName, $point);
	 $island->{'area'}++;

	 if($seaCount <= 4) {
		# 주변 바다가 3헥스 이내이므로 얕은 바다로
		my($i, $sx, $sy);

		for($i = 1; $i < 7; $i++) {
		 $sx = $x + $ax[$i];
		 $sy = $y + $ay[$i];

		 # 행 기준 위치 조정
		 if((($sy % 2) == 0) && (($y % 2) == 1)) {
			$sx--;
		 }

		 if(($sx < 0) || ($sx>= $HislandSize) ||
		 ($sy < 0) || ($sy>= $HislandSize)) {
		 } else {
			# 범위 안의 경우
			if($land->[$sx][$sy] == $HlandSea) {
			 $landValue->[$sx][$sy] = 1;
			}
		 }
		}
	 }
	} else {
	 # 바다이면 대상 위치를 얕은 바다로 변경
	 $land->[$x][$y] = $HlandSea;
	 $landValue->[$x][$y] = 1;
	 logLandSuc($id, $name, $comName, $point);
	}

	# 돈을 차감
	$island->{'money'} -= $cost;
	return 1;

 } elsif($kind == $HcomFune) {
	# 선박
	if(($landKind != $HlandSea) &&
	 ($landKind != $HlandOil) &&
	 ($landKind != $HlandSbase) &&
 ($landKind != $HlandNursery) &&
	 ($landKind != $HlandUmiamu) &&
	 ($landKind != $HlandSeatown) &&
	 ($landKind != $HlandUmishuto) &&
	 ($landKind != $HlandSeacity)) {
	 # 바다, 해저 기지, 유전만매립할 수 없
	 logLandFail($id, $name, $comName, $landName, $point);
	 return 0;
	}

	# 주변에 육지가 있는지 확인
	my($seaCount) =
	 countAround($land, $x, $y, $HlandMinato, 7);

 if($seaCount == 0) {
	 # 전체 바다다에서 매립불능
	 logNoLandAroundm($id, $name, $comName, $point);
	 return 0;
	}

	if($landKind == $HlandSea) {
	 # 얕은 바다의 경우
	 # 대상 위치를 황무지로
			if($arg == 77) {
			$land->[$x][$y] = $HlandFrocity;
			$landValue->[$x][$y] = 1;
			# 돈을 차감
			$value = min($arg * ($cost), $island->{'money'});
			$island->{'money'} -= $value;
			logLandSuc($id, $name, $comName, $point);
			return 1;
			}

	 $land->[$x][$y] = $HlandFune;
		if(($arg>= $HfuneNumber) ||
		 ($arg == 0)) {
		 $arg = 1;
		}
		$landValue->[$x][$y] = $arg;
		logLandSuc($id, $name, $comName, $point);
			if(($arg == 1) ||
			 ($arg == 2) ||
			 ($arg == 5) ||
			 ($arg == 6) ||
			 ($arg == 11)) {
			 $island->{'gyo'}++;
			}

	} else {
	 logLandFail($id, $name, $comName, $landName, $point);
	 return 0;
	}

	# 돈을 차감
	$value = min($arg * ($cost), $island->{'money'});
	$island->{'money'} -= $value;
	return 1;

 } elsif($kind == $HcomSeki) {
	# 관문
	if(($landKind != $HlandSea) &&
	 ($landKind != $HlandOil) &&
	 ($landKind != $HlandSbase) &&
 ($landKind != $HlandNursery) &&
	 ($landKind != $HlandUmiamu) &&
	 ($landKind != $HlandSeatown) &&
	 ($landKind != $HlandUmishuto) &&
	 ($landKind != $HlandSeacity)) {
	 # 바다, 해저 기지, 유전만매립할 수 없
	 logLandFail($id, $name, $comName, $landName, $point);
	 return 0;
	}

	my($seaCount) =
	 countAround($land, $x, $y, $HlandSea, 7) +
	 countAround($land, $x, $y, $HlandOil, 7) +
	 countAround($land, $x, $y, $HlandIce, 7) +
	 countAround($land, $x, $y, $HlandSbase, 7) +
	 countAround($land, $x, $y, $HlandFune, 7) +
	 countAround($land, $x, $y, $HlandFrocity, 7) +
 countAround($land, $x, $y, $HlandNursery, 7) +
	 countAround($land, $x, $y, $HlandUmiamu, 7) +
	 countAround($land, $x, $y, $HlandSeatown, 7) +
	 countAround($land, $x, $y, $HlandUmishuto, 7) +
 countAround($land, $x, $y, $HlandSeacity, 7);

	if(($landKind == $HlandSea) && ($lv == 1)) {
	 # 얕은 바다의 경우
	 # 대상 위치를 황무지로
	 $land->[$x][$y] = $HlandSeki;
	 $landValue->[$x][$y] = 0;
	 logLandSuc($id, $name, $comName, $point);
	 $island->{'area'}++;

	 if($seaCount <= 4) {
		# 주변 바다가 3헥스 이내이므로 얕은 바다로
		my($i, $sx, $sy);

		for($i = 1; $i < 7; $i++) {
		 $sx = $x + $ax[$i];
		 $sy = $y + $ay[$i];

		 # 행 기준 위치 조정
		 if((($sy % 2) == 0) && (($y % 2) == 1)) {
			$sx--;
		 }

		 if(($sx < 0) || ($sx>= $HislandSize) ||
		 ($sy < 0) || ($sy>= $HislandSize)) {
		 } else {
			# 범위 안의 경우
			if($land->[$sx][$sy] == $HlandSea) {
			 $landValue->[$sx][$sy] = 1;
			}
		 }
		}
	 }
	} else {
	 # 바다이면 대상 위치를 얕은 바다로 변경
	 logLandFail($id, $name, $comName, $landName, $point);
	 return 0;
	}

	# 돈을 차감
	$island->{'money'} -= $cost;
	return 1;

 } elsif(($kind == $HcomDestroy)||($kind == $HcomDestroy3)) {
	# 굴착
	if(($landKind == $HlandSbase) ||
	 ($landKind == $HlandSeacity) ||
	 ($landKind == $HlandSeatown) ||
	 ($landKind == $HlandOil) ||
	 ($landKind == $HlandFune) ||
	 ($landKind == $HlandFrocity) ||
 ($landKind == $HlandNursery) ||
	 ($landKind == $HlandUmiamu) ||
	 ($landKind == $HlandRottenSea) ||
	 ($landKind == $HlandUmishuto) ||
	 ($landKind == $HlandMonster)) {
	 # 해저 기지, 유전, 괴수는 굴착할 수 없
	 logLandFail($id, $name, $comName, $landName, $point);
	 return 0;
	}

	if(($landKind == $HlandSea) && ($lv == 0)) {
	 # 바다이면 유전 탐사 시
	 # 투자액결정
	 if($arg == 0) { $arg = 1; }
	 my($value, $str, $p);
	 $value = min($arg * ($cost), $island->{'money'});
	 $str = "$value$HunitMoney";
	 $p = int($value / $cost);
	 $island->{'money'} -= $value;

	 # 보기사용는 가판정
 if($p> random(100) + $island->{'oil'} * 25) {
		# 유전보기사용루
		logOilFound($id, $name, $point, $comName, $str);
		$land->[$x][$y] = $HlandOil;
		$landValue->[$x][$y] = 0;
		$island->{'oil'}++;

	 if($island->{'sin'}> 0) {
	 my($value, $str);
	 $value = random(1001);
	 $island->{'money'} += $value;
	 $str = "$value$HunitMoney";
	 # 수입 로그
	 logSinMoney($id, $name, $str);
	 }
	 if($island->{'jin'}> 0) {
	 my($value, $str);
	 $value = random(1001);
	 $island->{'money'} += $value;
	 $str = "$value$HunitMoney";
	 # 수입 로그
	 logJinMoney($id, $name, $str);
	 }

	 } else {
		# 헛발사치에끝나쁨
		logOilFail($id, $name, $point, $comName, $str);
	 }
	 return 1;
	}

	# 대상 위치를 바다로 변경. 산이면 황무지로, 얕은 바다이면 바다로 변경.
	if($landKind == $HlandMountain) {
	 $land->[$x][$y] = $HlandWaste;
	 $landValue->[$x][$y] = 0;
		if($kind == $HcomDestroy3) {
		 $land->[$x][$y] = $HlandSea;
		 $landValue->[$x][$y] = 1;
		}
	} elsif($landKind == $HlandGold) {
	 $land->[$x][$y] = $HlandWaste;
	 $landValue->[$x][$y] = 0;
		if($kind == $HcomDestroy3) {
		 $land->[$x][$y] = $HlandSea;
		 $landValue->[$x][$y] = 1;
		}
	} elsif($landKind == $HlandIce) {
	 $land->[$x][$y] = $HlandSea;
	 $landValue->[$x][$y] = 1;
		if($kind == $HcomDestroy3) {
		 $land->[$x][$y] = $HlandSea;
		 $landValue->[$x][$y] = 0;
		}
	} elsif($kind == $HcomDestroy3) {
	 $land->[$x][$y] = $HlandSea;
	 $landValue->[$x][$y] = 0;
	} elsif($landKind == $HlandSea) {
	 $landValue->[$x][$y] = 0;
	} else {
	 $land->[$x][$y] = $HlandSea;
	 $landValue->[$x][$y] = 1;
	 $island->{'area'}--;
	}
	logLandSuc($id, $name, $comName, $point);

	# 돈을 차감
	$island->{'money'} -= $cost;
	return 1;


 } elsif($kind == $HcomOnsen) {
	# 온천 굴착
	if($landKind != $HlandMountain) {
	 # 산이외는 굴착할 수 없
	 logLandFail($id, $name, $comName, $landName, $point);
	 return 0;
	}

	if(($landKind == $HlandMountain) && ($lv == 0)) {
	 # 산이면 온천 탐색 시
	 # 투자액결정
	 if($arg == 0) { $arg = 1; }
	 my($value, $str, $p);
	 $value = min($arg * ($cost), $island->{'money'});
	 $str = "$value$HunitMoney";
	 $p = int($value / $cost);
	 $island->{'money'} -= $value;

	 # 보기사용는 가판정
	 if(random(10000) < $p * 15) {
		my($v) = 1000 + random(2001);
		$island->{'money'} += $v;
		$land->[$x][$y] = $HlandGold;
		$landValue->[$x][$y] = 1;
		logGold($id, $name, $comName, $v);

	 if($island->{'sin'}> 0) {
	 my($value, $str);
	 $value = random(1001);
	 $island->{'money'} += $value;
	 $str = "$value$HunitMoney";
	 # 수입 로그
	 logSinMoney($id, $name, $str);
	 }
	 if($island->{'jin'}> 0) {
	 my($value, $str);
	 $value = random(1001);
	 $island->{'money'} += $value;
	 $str = "$value$HunitMoney";
	 # 수입 로그
	 logJinMoney($id, $name, $str);
	 }

	 } elsif(random(1000) < 50) {
		logEggFound($id, $name, $comName, $value);
		$land->[$x][$y] = $HlandMonument;
		$eggnum = 80+random(3);
		$landValue->[$x][$y] = $eggnum;
	 } elsif((random(1000) < 50) && ($island->{'m84'} < 4)) {
		logIsekiFound($id, $name, $comName, $value);
		$land->[$x][$y] = $HlandMonument;
		$landValue->[$x][$y] = 84;
	 } elsif($p> random(100) + $island->{'hot'} * 30) {
		# 유전보기사용루
		logHotFound($id, $name, $point, $comName, $str);
		$land->[$x][$y] = $HlandOnsen;
		$landValue->[$x][$y] = 1;
	 } else {
		# 헛발사치에끝나쁨
		logHotFail($id, $name, $point, $comName, $str);
	 }

	 if(random(1000) < 15) {
		my($v) = 100 + random(901);
		$island->{'money'} += $v;
		logMaizo($id, $name, $comName, $v);
	 }

		# 돈을 차감
		$island->{'money'} -= $cost;
	 return 1;
	}

 } elsif($kind == $HcomSellTree) {
	# 벌채
	if($landKind != $HlandForest) {
	 # 숲이외는 벌채할 수 없
	 logLandFail($id, $name, $comName, $landName, $point);
	 return 0;
	}

	# 대상 위치를 평지로
	$land->[$x][$y] = $HlandPlains;
	$landValue->[$x][$y] = 0;
	logLandSuc($id, $name, $comName, $point);
	 if(random(1000) < 75) {
		logEggFound($id, $name, $comName, $value);
		$land->[$x][$y] = $HlandMonument;
		$eggnum = 80+random(3);
		$landValue->[$x][$y] = $eggnum;
	 }

	# 매각금을 얻음
	$island->{'money'} += $HtreeValue * $lv;
	return 0;
 } elsif(($kind == $HcomPlant) ||
	 ($kind == $HcomFarm) ||
	 ($kind == $HcomEneAt) ||
	 ($kind == $HcomEneFw) ||
	 ($kind == $HcomEneWt) ||
	 ($kind == $HcomEneWd) ||
	 ($kind == $HcomEneBo) ||
	 ($kind == $HcomEneSo) ||
	 ($kind == $HcomEneCs) ||
	 ($kind == $HcomEneNF) ||
	 ($kind == $HcomConden) ||
	 ($kind == $HcomFoodim) ||
	 ($kind == $HcomFarmcpc) ||
	 ($kind == $HcomCollege) ||
	 ($kind == $HcomFactory) ||
	 ($kind == $HcomBase) ||
	 ($kind == $HcomMonument) ||
	 ($kind == $HcomHaribote) ||
	 ($kind == $HcomMonbuy) ||
	 ($kind == $HcomMonbuyt) ||
 ($kind == $HcomPark) ||
 ($kind == $HcomZoo) ||
 ($kind == $HcomMine) ||
 ($kind == $HcomNursery) ||
 ($kind == $HcomKyujo) ||
 ($kind == $HcomUmiamu) ||
 ($kind == $HcomNewtown) ||
 ($kind == $HcomRizort) ||
 ($kind == $HcomYoyaku) ||
 ($kind == $HcomYakusho) ||
 ($kind == $HcomKura) ||
 ($kind == $HcomKuraf) ||
 ($kind == $HcomKura2) ||
 ($kind == $HcomTrain) ||
	 ($kind == $HcomDbase)) {

	# 지상건설계
	if(!
	 (($landKind == $HlandPlains) ||
	 ($landKind == $HlandPlains2) ||
	 ($landKind == $HlandTown) ||
	 (($landKind == $HlandMinato) && ($kind == $HcomMinato)) ||
	 (($landKind == $HlandPark) && ($kind == $HcomPark)) ||
	 (($landKind == $HlandZoo) && ($kind == $HcomZoo)) ||
	 (($landKind == $HlandIce) && ($kind == $HcomPark)) ||
	 (($landKind == $HlandUmiamu) && ($kind == $HcomUmiamu)) ||
	 (($landKind == $HlandSea) && ($lv == 0) && ($kind == $HcomUmiamu)) ||
	 (($landKind == $HlandMonument) && ($kind == $HcomMonument)) ||
	 (($landKind == $HlandFarm) && ($kind == $HcomFarm)) ||
	 (($landKind == $HlandEneAt) && ($kind == $HcomEneAt)) ||
	 (($landKind == $HlandEneFw) && ($kind == $HcomEneFw)) ||
	 (($landKind == $HlandEneWt) && ($kind == $HcomEneWt)) ||
	 (($landKind == $HlandEneWd) && ($kind == $HcomEneWd)) ||
	 (($landKind == $HlandEneBo) && ($kind == $HcomEneBo)) ||
	 (($landKind == $HlandEneSo) && ($kind == $HcomEneSo)) ||
	 (($landKind == $HlandEneCs) && ($kind == $HcomEneCs)) ||
	 (($landKind == $HlandFarmchi) && ($kind == $HcomFarmcpc)) ||
	 (($landKind == $HlandFarmpic) && ($kind == $HcomFarmcpc)) ||
	 (($landKind == $HlandFarmcow) && ($kind == $HcomFarmcpc)) ||
	 (($landKind == $HlandCollege) && ($kind == $HcomCollege)) ||
	 (($landKind == $HlandFoodim) && ($kind == $HcomFoodim)) ||
	 (($landKind == $HlandFactory) && ($kind == $HcomFactory)) ||
 (($landKind == $HlandSea) && ($lv == 1) && ($kind == $HcomNursery)) ||
 (($landKind == $HlandCollege) && ($lv == 77) && ($kind == $HcomYakusho)) ||
 (($landKind == $HlandCollege) && ($lv == 78) && ($kind == $HcomYakusho)) ||
 (($landKind == $HlandCollege) && ($lv == 79) && ($kind == $HcomYakusho)) ||
 (($landKind == $HlandCollege) && ($lv == 80) && ($kind == $HcomYakusho)) ||
 (($landKind == $HlandNursery) && ($kind == $HcomNursery)) ||
 (($landKind == $HlandKura) && ($kind == $HcomKura)) ||
 (($landKind == $HlandKuraf) && ($kind == $HcomKuraf)) ||
 (($landKind == $HlandKura) && ($kind == $HcomKura2)) ||
 (($landKind == $HlandKuraf) && ($kind == $HcomKura2)) ||
	 (($landKind == $HlandTrain) && ($lv == 0) && ($kind == $HcomTrain)) ||
	 (($landKind == $HlandDefence) && ($kind == $HcomDbase)))) {
	 # 부적절나 지형
	 logLandFail($id, $name, $comName, $landName, $point);
	 return 0;
	}

	# 종류에서 분기
	if($kind == $HcomPlant) {
	 # 대상 위치를 숲로.
	 $land->[$x][$y] = $HlandForest;
	 $landValue->[$x][$y] = 1; # 목은 최소단위
	 logPBSuc($id, $name, $comName, $point);
	} elsif($kind == $HcomMonbuy) {
	 # 대상 위치를 괴수로.
	 $kind = random($HmonsterLevel3) + 1;
	 $lv = $lv = ($kind << 4)
		+ $HmonsterBHP[$kind] + random($HmonsterDHP[$kind]);
	 $land->[$x][$y] = $HlandMonster;
	 $landValue->[$x][$y] = $lv;
	 # 괴수 정보
	 my($mKind, $mName, $mHp) = monsterSpec($lv);
	 # 메시지
	 logMonsFree($id, $name, $mName, $point);
	} elsif($kind == $HcomMonbuyt) {
	 # 대상 위치를 괴수로.
	 $kind = 29;
	 $lv = $lv = ($kind << 4)
		+ $HmonsterBHP[$kind] + random($HmonsterDHP[$kind]);
	 $land->[$x][$y] = $HlandMonster;
	 $landValue->[$x][$y] = $lv;
	 # 괴수 정보
	 my($mKind, $mName, $mHp) = monsterSpec($lv);
	 # 메시지
	 logMonsFree($id, $name, $mName, $point);
	} elsif($kind == $HcomBase) {
	if($island->{'shouhi'}> $island->{'ene'}) {
	 logMsNoEne($id, $name, $comName);
	 return 0;
	}
	 # 대상 위치를 미사일 기지로.
	 $land->[$x][$y] = $HlandBase;
	 $landValue->[$x][$y] = 0; # 경험치0
	 logPBSuc($id, $name, $comName, $point);
	} elsif($kind == $HcomHaribote) {
	 # 대상 위치를 가짜 기지로
	 $land->[$x][$y] = $HlandHaribote;
	 $landValue->[$x][$y] = 0;
	 logHariSuc($id, $name, $comName, $HcomName[$HcomDbase], $point);
 } elsif($kind == $HcomPark) {
	if($island->{'shouhi'}> $island->{'ene'}) {
	 logMsNoEne($id, $name, $comName);
	 return 0;
	}
 # 대상 위치를 놀이공원로
	 if($landKind == $HlandPark) {
		# 이미놀이공원의 경우
		$landValue->[$x][$y] += 30; # 규모 + 10000명
		if($landValue->[$x][$y]> 100) {
		 $landValue->[$x][$y] = 100; # 최대 100000명
		}
	 } elsif($landKind == $HlandIce) {
		# 이미놀이공원의 경우
		$landValue->[$x][$y] += 25; # 규모 + 10000명
		if($landValue->[$x][$y]> 100) {
		 $landValue->[$x][$y] = 100; # 최대 100000명
		}
	 } else {
		# 대상 위치를 놀이공원에
		$land->[$x][$y] = $HlandPark;
		$landValue->[$x][$y] = 10; # 규모 = 10000명
		$island->{'par'}++;
	 }
	 logLandSuc($id, $name, $comName, $point);
 } elsif($kind == $HcomZoo) {

 if ($arg> 30) {
 $arg = 30;
 }

	if($island->{'shouhi'}> $island->{'ene'}) {
	 logMsNoEne($id, $name, $comName);
	 return 0;
	}
 # 대상 위치를 놀이공원로
	 if($landKind == $HlandZoo) {

		$etc6 = $island->{'etc6'};
		$etc6 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		($z0,$z1,$z2,$z3,$z4,$z5,$z6,$z7,$z8,$z9,$z10,$z11,$z12,$z13,$z14,$z15,$z16,$z17,$z18,$z19,$z20,$z21,$z22,$z23,$z24,$z25,$z26,$z27,$z28,$z29,$z30) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);
		($z->{'0'},$z->{'1'},$z->{'2'},$z->{'3'},$z->{'4'},$z->{'5'},$z->{'6'},$z->{'7'},$z->{'8'},$z->{'9'},$z->{'10'},$z->{'11'},$z->{'12'},$z->{'13'},$z->{'14'},$z->{'15'},$z->{'16'},$z->{'17'},$z->{'18'},$z->{'19'},$z->{'20'},$z->{'21'},$z->{'22'},$z->{'23'},$z->{'24'},$z->{'25'},$z->{'26'},$z->{'27'},$z->{'28'},$z->{'29'},$z->{'30'}) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);


		$nigekaiju = $arg;
		$nigeflag = 0;
	 if ($z->{"$nigekaiju"}> 0) {

			my($i, $sx, $sy, $kind, $lv);
			for($i = 1; $i < 7; $i++) {
			 $sx = $x + $ax[$i];
			 $sy = $y + $ay[$i];

			 # 행 기준 위치 조정
			 if((($sy % 2) == 0) && (($y % 2) == 1)) {
				$sx--;
			 }

			 $landKind = $land->[$sx][$sy];
			 $lv = $landValue->[$sx][$sy];
			 $point = "($sx, $sy)";

			 if(($sx < 0) || ($sx>= $HislandSize) ||
			 ($sy < 0) || ($sy>= $HislandSize)) {
			 } else {
				# 범위 안의 경우
				$landKind = $land->[$sx][$sy];
				$lv = $landValue->[$sx][$sy];
				$point = "($sx, $sy)";
				if(($landKind == $HlandSea) ||
				 ($landKind == $HlandIce) ||
				 ($landKind == $HlandOil) ||
				 ($landKind == $HlandFune) ||
				 ($landKind == $HlandFrocity) ||
				 ($landKind == $HlandUmiamu) ||
				 ($landKind == $HlandSeacity) ||
				 ($landKind == $HlandSeatown) ||
				 ($landKind == $HlandMonster) ||
				 ($landKind == $HlandZoo) ||
				 ($landKind == $HlandUmishuto) ||
				 ($landKind == $HlandSbase)) {
				} else {
					if ($nigeflag < 1) {
						$nigeflag++;
						$z->{"$nigekaiju"} -= 1;
						$kind = $nigekaiju;
						$lv = $lv = ($kind << 4)
						+ $HmonsterBHP[$kind] + random($HmonsterDHP[$kind]);
						$land->[$sx][$sy] = $HlandMonster;
						$landValue->[$sx][$sy] = $lv;
						my($mKind, $mName, $mHp) = monsterSpec($lv);
						logNige2($id, $name, landName($landKind, $lv), $mName, "($x, $y)");
						$island->{'etc6'} = "$z->{'0'},$z->{'1'},$z->{'2'},$z->{'3'},$z->{'4'},$z->{'5'},$z->{'6'},$z->{'7'},$z->{'8'},$z->{'9'},$z->{'10'},$z->{'11'},$z->{'12'},$z->{'13'},$z->{'14'},$z->{'15'},$z->{'16'},$z->{'17'},$z->{'18'},$z->{'19'},$z->{'20'},$z->{'21'},$z->{'22'},$z->{'23'},$z->{'24'},$z->{'25'},$z->{'26'},$z->{'27'},$z->{'28'},$z->{'29'},$z->{'30'}";
					}
				}
			 }
			}


				if ($nigeflag < 1) {
				 $kind = $nigekaiju;
				 $lv = ($kind << 4)
					+ $HmonsterBHP[$kind] + random($HmonsterDHP[$kind]);
				 # 어디에 출현할지 결정
				 my($bx, $by, $i);
				 for($i = 0; $i < $HpointNumber; $i++) {
					$bx = $Hrpx[$i];
					$by = $Hrpy[$i];
					if(($land->[$bx][$by] == $HlandTown) ||
					 ($land->[$bx][$by] == $HlandBigtown) ||
					 ($land->[$bx][$by] == $HlandBettown) ||
					 ($land->[$bx][$by] == $HlandSkycity) ||
					 ($land->[$bx][$by] == $HlandUmicity) ||
					 ($land->[$bx][$by] == $HlandRizort) ||
					 ($land->[$bx][$by] == $HlandKajino) ||
					 ($land->[$bx][$by] == $HlandBigRizort) ||
					 ($land->[$bx][$by] == $HlandNewtown)) {

					 # 지형 이름
					 my($lName) = landName($HlandTown, $landValue->[$bx][$by]);

					 # 그헥스를 괴수에
					 $land->[$bx][$by] = $HlandMonster;
					 $landValue->[$bx][$by] = $lv;

					 $z->{"$nigekaiju"} -= 1;
					 $island->{'etc6'} = "$z->{'0'},$z->{'1'},$z->{'2'},$z->{'3'},$z->{'4'},$z->{'5'},$z->{'6'},$z->{'7'},$z->{'8'},$z->{'9'},$z->{'10'},$z->{'11'},$z->{'12'},$z->{'13'},$z->{'14'},$z->{'15'},$z->{'16'},$z->{'17'},$z->{'18'},$z->{'19'},$z->{'20'},$z->{'21'},$z->{'22'},$z->{'23'},$z->{'24'},$z->{'25'},$z->{'26'},$z->{'27'},$z->{'28'},$z->{'29'},$z->{'30'}";

					 # 괴수 정보
					 my($mKind, $mName, $mHp) = monsterSpec($lv);

					 # 메시지
					 logMonsCome($id, $name, $mName, "($bx, $by)", $lName);
					 last;
					}
				 }
	 		}


	 }
			return 0;
	 } else {
		# 대상 위치를 놀이공원에
		$land->[$x][$y] = $HlandZoo;
		$landValue->[$x][$y] = 10; # 규모 = 10000명

		 if($island->{'zoo'} < 1) {
			my($first);
			$first = 1;
			while((random(5) != 0) || ($first == 1)) {
			 $first = 0;
			 $mKind = random(12);

			$etc6 = $island->{'etc6'};
			$etc6 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
			($z0,$z1,$z2,$z3,$z4,$z5,$z6,$z7,$z8,$z9,$z10,$z11,$z12,$z13,$z14,$z15,$z16,$z17,$z18,$z19,$z20,$z21,$z22,$z23,$z24,$z25,$z26,$z27,$z28,$z29,$z30) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);
			($z->{'0'},$z->{'1'},$z->{'2'},$z->{'3'},$z->{'4'},$z->{'5'},$z->{'6'},$z->{'7'},$z->{'8'},$z->{'9'},$z->{'10'},$z->{'11'},$z->{'12'},$z->{'13'},$z->{'14'},$z->{'15'},$z->{'16'},$z->{'17'},$z->{'18'},$z->{'19'},$z->{'20'},$z->{'21'},$z->{'22'},$z->{'23'},$z->{'24'},$z->{'25'},$z->{'26'},$z->{'27'},$z->{'28'},$z->{'29'},$z->{'30'}) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);

			$z->{"$mKind"}++;
			$island->{'zoo'}++;
			$island->{'etc6'} = "$z->{'0'},$z->{'1'},$z->{'2'},$z->{'3'},$z->{'4'},$z->{'5'},$z->{'6'},$z->{'7'},$z->{'8'},$z->{'9'},$z->{'10'},$z->{'11'},$z->{'12'},$z->{'13'},$z->{'14'},$z->{'15'},$z->{'16'},$z->{'17'},$z->{'18'},$z->{'19'},$z->{'20'},$z->{'21'},$z->{'22'},$z->{'23'},$z->{'24'},$z->{'25'},$z->{'26'},$z->{'27'},$z->{'28'},$z->{'29'},$z->{'30'}";
			}
		 }

	 }
	 logLandSuc($id, $name, $comName, $point);
 } elsif($kind == $HcomMine) {
 # 대상 위치를 지뢰로
 if ($arg == 0) {
 $arg = 1;
 } elsif ($arg> 9) {
 $arg = 9;
 }
 $arg = min($arg, int($island->{'money'} / $cost));
 $cost *= $arg;
 $land->[$x][$y] = $HlandMine;
 $landValue->[$x][$y] = $arg;
 logPBSuc($id, $name, $comName, $point);
 } elsif($kind == $HcomConden) {
 if ($arg == 0) {
 $arg = 1;
 } elsif ($arg>= 2) {
 $arg = 2;
 }
 $arg = min($arg, int($island->{'money'} / $cost));
 $cost *= $arg;
 if ($arg == 1) {
 $land->[$x][$y] = $HlandConden;
 } elsif ($arg == 2) {
 $land->[$x][$y] = $HlandConden2;
 }
 $landValue->[$x][$y] = 0;
 logLandSuc($id, $name, $comName, $point);
 } elsif($kind == $HcomTrain) {
	if($island->{'shouhi'}> $island->{'ene'}) {
	 logMsNoEne($id, $name, $comName);
	 return 0;
	}
 if ($arg> 9) {
 $arg = 0;
 }
 if(($landKind == $HlandTrain) && ($lv == 0) && ($arg == 1)) {
	 $landValue->[$x][$y] = 10;
 } elsif (($landKind == $HlandTrain) && ($lv == 0) && ($arg == 2)) {
	 $landValue->[$x][$y] = 20;
 } else {
		$land->[$x][$y] = $HlandTrain;
		$landValue->[$x][$y] = $arg;
 }
 logLandSuc($id, $name, $comName, $point);

 } elsif($kind == $HcomKura) {
 if ($arg == 0) {
 $arg = 1;
 }

	 $seq = int($lv/100);
	 $choki = $lv%100;
 $arg = min($arg, int($island->{'money'} / $cost));
 $cost *= $arg;

	 if($landKind == $HlandKura) {
		$choki += $arg;
		if($choki> 99) {
		 $choki = 99;
		}
		$landValue->[$x][$y] = $seq*100+$choki;
 } else {
		$land->[$x][$y] = $HlandKura;
		$landValue->[$x][$y] = $seq*100+$arg;
	 }

 logLandSuc($id, $name, $comName, $point);

 } elsif($kind == $HcomKuraf) {
	 if ($arg == 0) {
	 $arg = 1;
	 } elsif ($arg> 9) {
	 $arg = 9;
	 }

	 $choki = int($lv/10);
	 $kibo = $lv%10;
 $arg = min($arg, int($island->{'food'} / -$cost));
 $cost *= $arg;

	 if($landKind == $HlandKuraf) {
		$choki += $arg;
		if($choki> 400-40*(9-$kibo)) {
		 $choki = 400-40*(9-$kibo);
		}
		$landValue->[$x][$y] = $choki*10+$kibo;
 } else {
		$choki = 0;
		$kibo = 0;
		$land->[$x][$y] = $HlandKuraf;
		$landValue->[$x][$y] = $arg*10;
	 }
	 $island->{'food'} -= 10000*$arg;
 logLandSuc($id, $name, $comName, $point);

 } elsif($kind == $HcomKura2) {
 if ($arg == 0) {
 $arg = 1;
 }

	 $seq = int($lv/100);
	 $choki = $lv%100;
 if ($arg> $choki) {
 $arg = $choki;
 }
 $cost *= $arg;

	 if($landKind == $HlandKura) {
		$choki -= $arg;
		if($choki < 0) {
		 $choki = 0;
		}
		$landValue->[$x][$y] = $seq*100+$choki;
		$island->{'money'} += 10000*$arg;
		logLandSuc($id, $name, $comName, $point);
 return 0;

 } elsif($landKind == $HlandKuraf) {
		 if ($arg == 0) {
		 $arg = 1;
		 } elsif ($arg> 9) {
		 $arg = 9;
		 }
	 $choki = int($lv/10);
	 $kibo = $lv%10;
 if ($arg> $choki) {
 $arg = $choki;
 }
 $cost *= $arg;

		$choki -= $arg;
		if($choki < 0) {
		 $choki = 0;
		}
		$landValue->[$x][$y] = $choki*10+$kibo;
		$island->{'food'} += 10000*$arg;
		logLandSuc($id, $name, $comName, $point);
 return 0;

 } else {
 # 부적절나 지형
 logLandFail($id, $name, $comName, $landName, $point);
 return 0;
	 }

 } elsif($kind == $HcomYoyaku) {
 $jikkouarg ++;
 $jikkouarg = min($jikkouarg, int($island->{'money'} / $cost));
 $cost *= $jikkouarg;
 $cost *= $jikkouarg;
 $land->[$x][$y] = $HlandPlains2;
 $landValue->[$x][$y] = 0;
 logLandSuc($id, $name, $comName, $point);
	 return 0;
 } elsif($kind == $HcomNursery) {
 # 양식장
 if($landKind == $HlandNursery) {
 # 이미 양식장의 경우
 $landValue->[$x][$y] += 5; # 규모 + 5000명
 if($landValue->[$x][$y]> 100) {
 $landValue->[$x][$y] = 100; # 최대 100000명
 }
 } elsif(($landKind == $HlandSea) && ($lv == 1)) {
 # 대상 위치를 양식장에
 $land->[$x][$y] = $HlandNursery;
 $landValue->[$x][$y] = 20; # 규모 = 20000명
 } else {
 # 부적절나 지형
 logLandFail($id, $name, $comName, $landName, $point);
 return 0;
 }
 logLandSuc($id, $name, $comName, $point);
 } elsif($kind == $HcomYakusho) {
	my($shutoCount) =
	 countAround($land, $x, $y, $HlandShuto, 7) +
	 countAround($land, $x, $y, $HlandUmishuto, 7);

	 if(($island->{'shu'} == 0) || ($shutoCount == 0)) {
		logJoFail($id, $name, $comName, $landName, $point);
		return 0;
	 }

 if(($landKind == $HlandCollege) && ($lv == 77) && ($costseisaku> 35)) {
		$land->[$x][$y] = $HlandCollege;
		$landValue->[$x][$y] = 78;
		logLandSuc($id, $name, $comName, $point);
 } elsif(($landKind == $HlandCollege) && ($lv == 78) && ($costseisaku> 60)) {
		$land->[$x][$y] = $HlandCollege;
		$landValue->[$x][$y] = 79;
		logLandSuc($id, $name, $comName, $point);
 } elsif(($landKind == $HlandCollege) && ($lv == 79) && ($costseisaku> 110)) {
		$land->[$x][$y] = $HlandCollege;
		$landValue->[$x][$y] = 80;
		logLandSuc($id, $name, $comName, $point);
 } elsif($landKind == $HlandCollege) {
		$land->[$x][$y] = $HlandCollege;
		$landValue->[$x][$y] = 77;
		logLandSuc($id, $name, $comName, $point);
 } else {
		$land->[$x][$y] = $HlandYakusho;
		$landValue->[$x][$y] = 0;
		logLandSuc($id, $name, $comName, $point);
 }

 } elsif($kind == $HcomKyujo) {
	if($island->{'shouhi'}> $island->{'ene'}) {
	 logMsNoEne($id, $name, $comName);
	 return 0;
	}
 # 대상 위치를 야구장로
 $land->[$x][$y] = $HlandKyujo;
 $landValue->[$x][$y] = 0;
 logLandSuc($id, $name, $comName, $point);
 } elsif($kind == $HcomNewtown) {
 # 대상 위치를 야구장로
 $land->[$x][$y] = $HlandNewtown;
 $landValue->[$x][$y] = 1;
 logLandSuc($id, $name, $comName, $point);
 } elsif($kind == $HcomRizort) {
	if($island->{'shouhi'}> $island->{'ene'}) {
	 logMsNoEne($id, $name, $comName);
	 return 0;
	}
 # 대상 위치를 야구장로
 $land->[$x][$y] = $HlandRizort;
 $landValue->[$x][$y] = 1;
 logLandSuc($id, $name, $comName, $point);
 } elsif($kind == $HcomUmiamu) {
	if($island->{'shouhi'}> $island->{'ene'}) {
	 logMsNoEne($id, $name, $comName);
	 return 0;
	}
 # 대상 위치를 해상 시설로
	 if($landKind == $HlandUmiamu) {
		# 이미 해상 시설의 경우
		$landValue->[$x][$y] += 30; # 규모 + 30000명
		if($landValue->[$x][$y]> 1000) {
		 $landValue->[$x][$y] = 1000; # 최대 1000000명
		}
	 } elsif(($landKind == $HlandSea) && ($lv == 0)) {
		# 대상 위치를 해상 시설에
		$land->[$x][$y] = $HlandUmiamu;
		$landValue->[$x][$y] = 50; # 규모 = 50000명
 } else {
 # 부적절나 지형
 logLandFail($id, $name, $comName, $landName, $point);
 return 0;
	 }
	 logLandSuc($id, $name, $comName, $point);
	} elsif($kind == $HcomFarm) {
	 # 농장
	 if($landKind == $HlandFarm) {
		# 이미 농장의 경우
		$landValue->[$x][$y] += 2; # 규모 + 2000명
		if($landValue->[$x][$y]> 50) {
		 $landValue->[$x][$y] = 50; # 최대 50000명
		}
	 } else {
		# 대상 위치를 농장에
		$land->[$x][$y] = $HlandFarm;
		$landValue->[$x][$y] = 10; # 규모 = 10000명
	 }
	 logLandSuc($id, $name, $comName, $point);
	} elsif($kind == $HcomEneAt) {
	 if($landKind == $HlandEneAt) {
		$landValue->[$x][$y] += 30;
		if($landValue->[$x][$y]> 1500) {
		 $landValue->[$x][$y] = 1500;
		}
	 } else {
		$land->[$x][$y] = $HlandEneAt;
		$landValue->[$x][$y] = 50;
	 }
	 logLandSuc($id, $name, $comName, $point);
	} elsif($kind == $HcomEneFw) {

	my($seaCount) =
	 countAround($land, $x, $y, $HlandSea, 7) +
	 countAround($land, $x, $y, $HlandOil, 7) +
	 countAround($land, $x, $y, $HlandIce, 7) +
	 countAround($land, $x, $y, $HlandSbase, 7) +
	 countAround($land, $x, $y, $HlandFune, 7) +
	 countAround($land, $x, $y, $HlandFrocity, 7) +
 countAround($land, $x, $y, $HlandNursery, 7) +
	 countAround($land, $x, $y, $HlandUmiamu, 7) +
	 countAround($land, $x, $y, $HlandSeatown, 7) +
	 countAround($land, $x, $y, $HlandUmishuto, 7) +
 countAround($land, $x, $y, $HlandSeacity, 7);

	 if($seaCount == 0) {
		 # 전체 바다다에서 매립불능
		 logNoLandArounde($id, $name, $comName, $point, "바다");
		 return 0;
		}

	 if($landKind == $HlandEneFw) {
		$landValue->[$x][$y] += 30;
		if($landValue->[$x][$y]> 500) {
		 $landValue->[$x][$y] = 500;
		}
	 } else {
		$land->[$x][$y] = $HlandEneFw;
		$landValue->[$x][$y] = 20;
	 }
	 logLandSuc($id, $name, $comName, $point);
	} elsif($kind == $HcomEneWt) {

	my($mountainCount) =
	 countAround($land, $x, $y, $HlandMountain, 7) +
 countAround($land, $x, $y, $HlandGold, 7);

	 if($mountainCount == 0) {
		 # 전체 바다다에서 매립불능
		 logNoLandArounde($id, $name, $comName, $point, "산");
		 return 0;
		}

	 if($landKind == $HlandEneWt) {
		$landValue->[$x][$y] += 15;
		if($landValue->[$x][$y]> 250) {
		 $landValue->[$x][$y] = 250;
		}
	 } else {
		$land->[$x][$y] = $HlandEneWt;
		$landValue->[$x][$y] = 10;
	 }
	 logLandSuc($id, $name, $comName, $point);
	} elsif($kind == $HcomEneWd) {

	my($PlainsCount) =
	 countAround($land, $x, $y, $HlandPlains, 7) +
 countAround($land, $x, $y, $HlandPlains2, 7);

	 if($PlainsCount == 0) {
		 # 전체 바다다에서 매립불능
		 logNoLandArounde($id, $name, $comName, $point, "평지");
		 return 0;
		}

	 if($landKind == $HlandEneWd) {
		$landValue->[$x][$y] += 25;
		if($landValue->[$x][$y]> 150) {
		 $landValue->[$x][$y] = 150;
		}
	 } else {
		$land->[$x][$y] = $HlandEneWd;
		$landValue->[$x][$y] = 25;
	 }
	 logLandSuc($id, $name, $comName, $point);
	} elsif($kind == $HcomEneBo) {

	my($FoodimCount) = countAround($land, $x, $y, $HlandFoodim, 7);

	 if($FoodimCount == 0) {
		 # 전체 바다다에서 매립불능
		 logNoLandArounde($id, $name, $comName, $point, "식품 연구소");
		 return 0;
		}

	 if($landKind == $HlandEneBo) {
		$landValue->[$x][$y] += 50;
		if($landValue->[$x][$y]> 2000) {
		 $landValue->[$x][$y] = 2000;
		}
	 } else {
		$land->[$x][$y] = $HlandEneBo;
		$landValue->[$x][$y] = 100;
	 }
	 logLandSuc($id, $name, $comName, $point);
	} elsif($kind == $HcomEneCs) {

	 if($island->{'eis7'} == 0) {
	 logNesEisei($id, $name, $comName);
		 return 0;
		}

	 if($landKind == $HlandEneCs) {
		$landValue->[$x][$y] += 200;
		if($landValue->[$x][$y]> 4000) {
		 $landValue->[$x][$y] = 4000;
		}
	 } else {
		$land->[$x][$y] = $HlandEneCs;
		$landValue->[$x][$y] = 400;
	 }
	 logLandSuc($id, $name, $comName, $point);
	} elsif($kind == $HcomEneSo) {

	 if($landKind == $HlandEneSo) {
		$landValue->[$x][$y] += 1000;
		if($landValue->[$x][$y]> 1000) {
		 $landValue->[$x][$y] = 1000;
		}
	 } else {
		$land->[$x][$y] = $HlandEneSo;
		$landValue->[$x][$y] = 1000;
	 }
	 logLandSuc($id, $name, $comName, $point);
	} elsif($kind == $HcomEneNF) {
	 $etc9 = $island->{'etc9'};
	 $etc9 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	 ($co7, $magicf, $magici, $magica, $magicw, $magicl, $magicd) = ($1, $2, $3, $4, $5, $6, $7);
	 if(($magica != $magicl) || ($magicl == 0) || ($island->{'con99'}> 0) || ($island->{'co77'} == 0)) {
		logEiseifail($id, $name, $comName, $point);
		# 광역 피해 루틴
		wideDamage($id, $name, $land, $landValue, $x, $y);
 return 0;
	 } else {
		$land->[$x][$y] = $HlandConden4;
		$landValue->[$x][$y] = 99;
	 }
	 logLandSuc($id, $name, $comName, $point);
	} elsif($kind == $HcomFoodim) {
	 if($landKind == $HlandFoodim) {
		# 이미 농장의 경우
		$landValue->[$x][$y] += 10; # 규모 + 10000명
		if($landValue->[$x][$y]> 500) {
		 $landValue->[$x][$y] = 500; # 최대 500000명
		}
	 } else {
		# 대상 위치를 농장에
		$land->[$x][$y] = $HlandFoodim;
		$landValue->[$x][$y] = 30; # 규모 = 30000명
	 }
	 logLandSuc($id, $name, $comName, $point);
	} elsif($kind == $HcomCollege) {

	 if(($landKind == $HlandCollege) && ($lv == 4)) {
		$landValue->[$x][$y] = 96;
		logLandSuc($id, $name, $comName, $point);
 return 0;
	 } elsif(($landKind == $HlandCollege) && ($lv == 98)) {
		$landValue->[$x][$y] = 97;
		logLandSuc($id, $name, $comName, $point);
 return 0;
	 } elsif(($landKind == $HlandCollege) && ($lv == 96)) {
		$landValue->[$x][$y] = 4;
		logLandSuc($id, $name, $comName, $point);
 return 0;
	 } elsif(($landKind == $HlandCollege) && ($lv == 97)) {
		$landValue->[$x][$y] = 98;
		logLandSuc($id, $name, $comName, $point);
 return 0;
	 } elsif(($landKind == $HlandCollege) && ($lv == 6)) {
			if($island->{'money'} < 250000) {
			logNoMoney($id, $name, $comName);
			return 0;
			}
		$landValue->[$x][$y] = 95;
		$island->{'money'} -= 250000;
	 } elsif(($landKind == $HlandCollege) && ($lv == 95)) {
		$landValue->[$x][$y] = 6;
		$island->{'money'} += 250000;
		logLandSuc($id, $name, $comName, $point);
 return 0;
	 } else {
		$land->[$x][$y] = $HlandCollege;
	 if(random(100) < 30) {
		$landValue->[$x][$y] = 0;

		 if(random(100) < 40) {
			$landValue->[$x][$y] = 8;
		 }

	 } elsif(random(100) < 30) {
		$landValue->[$x][$y] = 1;

		 if(random(100) < 30) {
			$landValue->[$x][$y] = 7;
		 }

	 } elsif(random(100) < 25) {
		$landValue->[$x][$y] = 6;
	 } elsif(random(100) < 15) {
		$landValue->[$x][$y] = 2;
	 } elsif(random(100) < 15) {
		$landValue->[$x][$y] = 3;
	 } elsif(random(100) < 15) {
		$landValue->[$x][$y] = 4;
		if(($island->{'co4'} == 0) &&
		 ($island->{'co99'} == 0) &&
		 ($island->{'c28'} == 0)) {
		$island->{'eisei5'} = "3,5,5,5,0,0,0";
		}
	 } else {
		$landValue->[$x][$y] = 5;
	 }
	 }
	 logLandSuc($id, $name, $comName, $point);


		$etc5 = $island->{'etc5'};
		$etc5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		($s00,$s01,$s02,$s03,$s04,$s05,$s06,$s07,$s08,$s09,$s10,$s11,$s12,$s13,$s14,$s15,$s16,$s17,$s18,$s19,$s20,$s21,$s22,$s23,$s24,$s25,$s26,$s27,$s28,$s29,$s30) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);

		$s10b = int($s10/5)+1;

		if(($island->{'co77'}> 0) && ($arg < 10) && ($arg != 0) && ($arg-1 < $s10b)) {
			if($arg == 0) {
			 $arg = 1;
			}
		$landValue->[$x][$y] = $arg-1;
		$island->{'money'} -= $arg * 10000;
			if(($arg == 4) &&
			 ($island->{'co4'} == 0) &&
		 	 ($island->{'co99'} == 0) &&
		 	 ($island->{'c28'} == 0)) {
			$island->{'eisei5'} = "3,5,5,5,0,0,0";
			}
		}

	} elsif($kind == $HcomFarmcpc) {
	 # 목장
	 if(($arg>= 4) ||
	 ($arg == 0)) {
	 $arg = 1;
	 }
	 if(($landKind == $HlandFarmchi) ||
		($landKind == $HlandFarmpic) ||
		($landKind == $HlandFarmcow)) {
		# 이미목장의 경우
		if($landKind == $HlandFarmchi) {
		$island->{'money'} += $lv * 10;
		$land->[$x][$y] = $HlandFarmchi;
		$landValue->[$x][$y] = 1;
	 } elsif($landKind == $HlandFarmpic) {
		$island->{'money'} += $lv * 20;
		$land->[$x][$y] = $HlandFarmpic;
		$landValue->[$x][$y] = 1;
	 } elsif($landKind == $HlandFarmcow) {
		$island->{'money'} += $lv * 50;
		$land->[$x][$y] = $HlandFarmcow;
		$landValue->[$x][$y] = 1;
	 }
		logLandSuc($id, $name, $comName, $point);
	 $cost *= 0;
		return 0;
	 } else {
		if($arg == 1) {
		$land->[$x][$y] = $HlandFarmchi;
		$landValue->[$x][$y] = 1;
	 } elsif($arg == 2) {
		$land->[$x][$y] = $HlandFarmpic;
		$landValue->[$x][$y] = 1;
	 } elsif($arg == 3) {
		$land->[$x][$y] = $HlandFarmcow;
		$landValue->[$x][$y] = 1;
	 }
		# 돈을 차감
	 $arg = min($arg, int($island->{'money'} / $cost));
	 $cost *= $arg;
	 }
	 logLandSuc($id, $name, $comName, $point);
	} elsif($kind == $HcomFactory) {
	 # 공장
	 if($landKind == $HlandFactory) {
		# 이미 공장의 경우
		$landValue->[$x][$y] += 10; # 규모 + 10000명
		if($landValue->[$x][$y]> 100) {
		 $landValue->[$x][$y] = 100; # 최대 100000명
		}
	 } else {
		# 대상 위치를 공장에
		$land->[$x][$y] = $HlandFactory;
		$landValue->[$x][$y] = 30; # 규모 = 10000명
	 }
	 logLandSuc($id, $name, $comName, $point);
	} elsif($kind == $HcomDbase) {
	if($island->{'shouhi'}> $island->{'ene'}) {
	 logMsNoEne($id, $name, $comName);
	 return 0;
	}
	 # 방위 시설
	 if($landKind == $HlandDefence) {
		# 이미 방위 시설의 경우
		$landValue->[$x][$y] = 1; # 자폭장치 설정
		logBombSet($id, $name, $landName, $point);
	 } else {
		# 대상 위치를 방위 시설에
		$land->[$x][$y] = $HlandDefence;
		$landValue->[$x][$y] = 0;
		logLandSuc($id, $name, $comName, $point);
	 }
	} elsif($kind == $HcomMonument) {
	 # 기념비
	 if($landKind == $HlandMonument) {
		# 이미 기념비의 경우
		# 대상 가져오기
		my($tn) = $HidToNumber{$target};
		if($tn eq '') {
		 # 대상이 이미 없음
		 # 아무 말 없이 중지
		 return 0;
		}
		my($tIsland) = $Hislands[$tn];

 # 자기 섬의 인구가 적거나, 대상 섬의 인구가 적으면, 실행은 허가되지 않는
 if (($island->{'pop'} < $HguardPop) || ($tIsland->{'pop'} < $HguardPop)) {
 logForbidden($id, $name, $comName);
 return 0;
 }

		if($lovePeace == 1) {
		$island->{'bigmissile'}++;
		$island->{'money'} = 0;

		 my($i,$sx,$sy);
		 for($i = 0; $i < $HpointNumber; $i++){
			$sx = $Hrpx[$i];
			$sy = $Hrpy[$i];
		 if($land->[$sx][$sy] == $HlandSbase) {
				$land->[$sx][$sy] = $HlandSea;
				$landValue->[$sx][$sy] = 0;
		 } elsif(($land->[$sx][$sy] == $HlandBase) ||
			 ($land->[$sx][$sy] == $HlandMonument)) {
				$land->[$sx][$sy] = $HlandWaste;
				$landValue->[$sx][$sy] = 0;

		 }
		}
		logNiwaren($id, $name);

	 } else {
		$tIsland->{'bigmissile'}++;
	 }

		# 그장소는 황무지에
		$land->[$x][$y] = $HlandWaste;
		$landValue->[$x][$y] = 0;
		logMonFly($id, $name, $landName, $point);
	 } else {
		# 대상 위치를 기념비에
		$land->[$x][$y] = $HlandMonument;

		my($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);
		my $day = ('일','월','불','수','목','금','와 지')[$wday];
		$year = $year + 1900;
		$mon = $mon + 1;
		my $date = sprintf("%04d/%02d/%02d(%s) %02d:%02d:%02d",$year,$mon,$mday,$day,$hour,$min,$sec);

		if(($arg == 88) && ($mon> 2) && ($mon < 6)) {
		 $arg = 88;
		}

		elsif(($arg == 73) && ($mon> 2) && ($mon < 6)) {
		 $arg = 73;
		}

		elsif(($arg == 89) && ($mon> 5) && ($mon < 9)) {
		 $arg = 89;
		}

		elsif(($arg == 94) && ($mon> 5) && ($mon < 9)) {
		 $arg = 94;
		}

		elsif(($arg == 90) && ($mon> 8) && ($mon < 12)) {
		 $arg = 90;
		}

		elsif(($arg == 92) && ($mon> 11) && ($mon < 3)) {
		 $arg = 92;
		}

		elsif(($arg == 85) && ($mon == 12) && ($mday == 24)) {
		 $arg = 85;
		}

		elsif(($arg == 91) && ($mon == 12) && ($mday == 25)) {
		 $arg = 91;
		}

		elsif(($arg == 95) && ($mon == 12)) {
		 $arg = 95;
		}

		elsif($arg>= $HmonumentNumber) {
		 $arg = 0;
		}
		$landValue->[$x][$y] = $arg;
		logLandSuc($id, $name, $comName, $point);
	 }
	}

	# 돈을 차감
	$island->{'money'} -= $cost;

	# 횟수 지정이면, 명령을 되돌림
	if(($kind == $HcomFarm) ||
 ($kind == $HcomFoodim) ||
 ($kind == $HcomNursery) ||
 ($kind == $HcomEneAt) ||
 ($kind == $HcomEneFw) ||
 ($kind == $HcomEneWt) ||
 ($kind == $HcomEneWd) ||
 ($kind == $HcomEneBo) ||
 ($kind == $HcomEneSo) ||
 ($kind == $HcomEneCs) ||
 ($kind == $HcomPark) ||
 ($kind == $HcomUmiamu) ||
	 ($kind == $HcomFactory)) {
	 if($arg> 1) {
		my($command);
		$arg--;
		slideBack($comArray, 0);
		$comArray->[0] = {
		 'kind' => $kind,
		 'target' => $target,
		 'x' => $x,
		 'y' => $y,
		 'arg' => $arg
		 };
	 }
	}

	return 1;
 } elsif($kind == $HcomMountain) {
	# 채굴장
 if($landKind == $HlandMountain) {
 # 이미채굴장의 경우
 $landValue->[$x][$y] += 5; # 규모 + 5000명
 if($landValue->[$x][$y]> 200) {
 $landValue->[$x][$y] = 200; # 최대 200000명
 }
 } elsif($landKind == $HlandGold) {
 # 이미금광산의 경우
 $landValue->[$x][$y] += 20; # 규모 + 20000명
 if($landValue->[$x][$y]> 200) {
 $landValue->[$x][$y] = 200; # 최대 200000명
 }
 } else {
 # 부적절나 지형
 logLandFail($id, $name, $comName, $landName, $point);
 return 0;
 }
 logLandSuc($id, $name, $comName, $point);

	# 돈을 차감
	$island->{'money'} -= $cost;
	if($arg> 1) {
	 my($command);
	 $arg--;
	 slideBack($comArray, 0);
	 $comArray->[0] = {
		'kind' => $kind,
		'target' => $target,
		'x' => $x,
		'y' => $y,
		'arg' => $arg
		};
	}

	 if(random(1000) < 9) {
		my($v) = 1000 + random(4001);
		$island->{'money'} += $v;
		$land->[$x][$y] = $HlandGold;
		logGold($id, $name, $comName, $v);

	 if($island->{'sin'}> 0) {
	 my($value, $str);
	 $value = random(1001);
	 $island->{'money'} += $value;
	 $str = "$value$HunitMoney";
	 # 수입 로그
	 logSinMoney($id, $name, $str);
	 }
	 if($island->{'jin'}> 0) {
	 my($value, $str);
	 $value = random(1001);
	 $island->{'money'} += $value;
	 $str = "$value$HunitMoney";
	 # 수입 로그
	 logJinMoney($id, $name, $str);
	 }

	 }

	return 1;

 } elsif($kind == $HcomHTget) {
	if($island->{'shouhi'}> $island->{'ene'}) {
	 logMsNoEne($id, $name, $comName);
	 return 0;
	}
	# 첨단 기술
 if($landKind == $HlandHTFactory) {
 # 이미채굴장의 경우
 $landValue->[$x][$y] += 10; # 규모 + 10000명
 if($landValue->[$x][$y]> 500) {
 $landValue->[$x][$y] = 500; # 최대 500000명
 }
 } elsif($landKind == $HlandFactory) {
			if($lv == 100) {
			 $land->[$x][$y] = $HlandHTFactory;
			} else {
			logJoFail($id, $name, $comName, $landName, $point);
			return 0;
			}
 } else {
 # 부적절나 지형
 logLandFail($id, $name, $comName, $landName, $point);
 return 0;
 }
 logLandSuc($id, $name, $comName, $point);

	# 돈을 차감
	$island->{'money'} -= $cost;
	if($arg> 1) {
	 my($command);
	 $arg--;
	 slideBack($comArray, 0);
	 $comArray->[0] = {
		'kind' => $kind,
		'target' => $target,
		'x' => $x,
		'y' => $y,
		'arg' => $arg
		};
	}
	return 1;

	} elsif($kind == $HcomHouse) {
	 if($island->{'hou'}> 0) {
		$island->{'eisei1'} = $arg;
	 logLandSuc($id, $name, $comName, $point);
 return 0;

	 } else {
		if(!
		 (($landKind == $HlandPlains) ||
		 ($landKind == $HlandPlains2) ||
		 ($landKind == $HlandTown))) {
		 # 부적절나 지형
		 logLandFail($id, $name, $comName, $landName, $point);
		 return 0;
		} else {
		if($arg == 0) {
		 $arg = 5;
		}
		$island->{'eisei1'} = $arg;
		$land->[$x][$y] = $HlandHouse;



	 if($island->{'pts'}> $HouseLevel9) {
		 $landValue->[$x][$y] = 9;
	 } elsif($island->{'pts'}> $HouseLevel8) {
	 	 $landValue->[$x][$y] = 8;
	 } elsif($island->{'pts'}> $HouseLevel7) {
		 $landValue->[$x][$y] = 7;
	 } elsif($island->{'pts'}> $HouseLevel6) {
	 	 $landValue->[$x][$y] = 6;
	 } elsif($island->{'pts'}> $HouseLevel5) {
		 $landValue->[$x][$y] = 5;
	 } elsif($island->{'pts'}> $HouseLevel4) {
	 	 $landValue->[$x][$y] = 4;
	 } elsif($island->{'pts'}> $HouseLevel3) {
		 $landValue->[$x][$y] = 3;
	 } elsif($island->{'pts'}> $HouseLevel2) {
	 	 $landValue->[$x][$y] = 2;
	 } elsif($island->{'pts'}> $HouseLevel1) {
		 $landValue->[$x][$y] = 1;
	 } else {
		 $landValue->[$x][$y] = 0;
	 }
		logLandSuc($id, $name, $comName, $point);
		# 돈을 차감
		$island->{'money'} -= $cost;
		return 1;
		}
	 }

	} elsif($kind == $HcomBettown) {
	my($shutoCount) =
	 countAround($land, $x, $y, $HlandShuto, 7) +
	 countAround($land, $x, $y, $HlandUmishuto, 7);
	my($betCount) =
	 countAround($land, $x, $y, $HlandBettown, 7);

		if($landKind != $HlandBigtown){
		 # 부적절나 지형
		 logLandFail($id, $name, $comName, $landName, $point);
		 return 0;
		}

			if(($island->{'shu'}> 0) &&
			 (($shutoCount> 0) ||
			 ($betCount> 1))) {
			 $land->[$x][$y] = $HlandBettown;
			logLandSuc($id, $name, $comName, $point);
			# 돈을 차감
			$island->{'money'} -= $cost;
			return 1;
			} else {
			logJoFail($id, $name, $comName, $landName, $point);
			return 0;
			}

	} elsif($kind == $HcomKai) {
	if($island->{'shouhi'}> $island->{'ene'}) {
	 logMsNoEne($id, $name, $comName);
	 return 0;
	}
		if($landKind == $HlandKyujo) {

			if($island->{'ky2'} == 0) {
			$island->{'eisei4'} = "1,1,1,0,0,0,0,0,0,0,10";
			}

		$land->[$x][$y] = $HlandKyujokai;
		$landValue->[$x][$y] = 0;
			logLandSuc($id, $name, $comName, $point);
			# 돈을 차감
			$island->{'money'} -= $cost;
			return 1;
		} elsif($landKind == $HlandKyujokai) {
			$eisei4 = $island->{'eisei4'};
			$eisei4 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
			($sto, $std, $stk, $stwin, $stdrow, $stlose, $stwint, $stdrowt, $stloset, $styusho, $stshoka) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11);
			$sto++;
			$std++;
			$stk++;
			$island->{'eisei4'} = "$sto,$std,$stk,$stwin,$stdrow,$stlose,$stwint,$stdrowt,$stloset,$styusho,$stshoka";
			logLandSuc($id, $name, $comName, $point);
			# 돈을 차감
			$island->{'money'} -= $cost;
			if($arg> 1) {
			 my($command);
			 $arg--;
			 slideBack($comArray, 0);
			 $comArray->[0] = {
				'kind' => $kind,
				'target' => $target,
				'x' => $x,
				'y' => $y,
				'arg' => $arg
				};
			}
			return 1;
		} elsif(($landKind == $HlandConden4) && ($lv == 2)) {
			$land->[$x][$y] = $HlandConden2;
			$landValue->[$x][$y] = 0;
			logLandSuc($id, $name, $comName, $point);
			# 돈을 차감
			$island->{'money'} -= $cost;
			return 1;
		} elsif(($landKind == $HlandConden4) && ($lv == 3)) {
			$land->[$x][$y] = $HlandConden3;
			$landValue->[$x][$y] = 0;
			logLandSuc($id, $name, $comName, $point);
			# 돈을 차감
			$island->{'money'} -= $cost;
			return 1;
		} elsif(($landKind == $HlandFune) && ($lv == 10)) {
			$landValue->[$x][$y] = 19;
			logLandSuc($id, $name, $comName, $point);
			# 돈을 차감
			$island->{'money'} -= $cost;
			return 1;
		} elsif(($landKind == $HlandFoodim) && ($lv>= 480)) {
			$land->[$x][$y] = $HlandFoodka;
			$landValue->[$x][$y] = 1;
			logLandSuc($id, $name, $comName, $point);
			# 돈을 차감
			$island->{'money'} -= $cost;
			return 1;
		} elsif($landKind == $HlandEneSo) {
			$landValue->[$x][$y] = 1250;
			logLandSuc($id, $name, $comName, $point);
			# 돈을 차감
			$island->{'money'} -= $cost;
			return 1;
		} elsif($landKind == $HlandZoo) {
			$landValue->[$x][$y] += 10;
			if($landValue->[$x][$y]> int($island->{'rena'}/75)) {
			 $landValue->[$x][$y] = int($island->{'rena'}/75);
			}
			if($landValue->[$x][$y]> 200) {
			 $landValue->[$x][$y] = 200;
			}
			logLandSuc($id, $name, $comName, $point);
			# 돈을 차감
			$island->{'money'} -= $cost;
			if($arg> 1) {
			 my($command);
			 $arg--;
			 slideBack($comArray, 0);
			 $comArray->[0] = {
				'kind' => $kind,
				'target' => $target,
				'x' => $x,
				'y' => $y,
				'arg' => $arg
				};
			}
			return 1;
		} elsif($landKind == $HlandDefence) {
			$landValue->[$x][$y] = 77;
			logLandSuc($id, $name, $comName, $point);
			# 돈을 차감
			$island->{'money'} -= $cost;
			return 1;
		} elsif($landKind == $HlandHTFactory) {
			$land->[$x][$y] = $HlandSHTF;
			logLandSuc($id, $name, $comName, $point);
			# 돈을 차감
			$island->{'money'} -= $cost;
			return 1;
		} elsif($landKind == $HlandSHTF) {
			$land->[$x][$y] = $HlandHTFactory;
			logLandSuc($id, $name, $comName, $point);
			# 돈을 차감
			$island->{'money'} -= $cost;
			return 1;
		} elsif($landKind == $HlandKura) {

		 $seq = int($lv/100);
		 $choki = $lv%100;
			$seq ++;
			if($seq> 9) {
			 $seq = 9;
			}
			$landValue->[$x][$y] = $seq*100+$choki;

			logLandSuc($id, $name, $comName, $point);
			# 돈을 차감
			$island->{'money'} -= $cost;
			if($arg> 1) {
			 my($command);
			 $arg--;
			 slideBack($comArray, 0);
			 $comArray->[0] = {
				'kind' => $kind,
				'target' => $target,
				'x' => $x,
				'y' => $y,
				'arg' => $arg
				};
			}
			return 1;

		} elsif($landKind == $HlandKuraf) {

		 $choki = int($lv/10);
		 $kibo = $lv%10;
			$kibo ++;
			if($kibo> 9) {
			 $kibo = 9;
			}
			$landValue->[$x][$y] = $choki*10+$kibo;

			logLandSuc($id, $name, $comName, $point);
			# 돈을 차감
			$island->{'money'} -= $cost;
			if($arg> 1) {
			 my($command);
			 $arg--;
			 slideBack($comArray, 0);
			 $comArray->[0] = {
				'kind' => $kind,
				'target' => $target,
				'x' => $x,
				'y' => $y,
				'arg' => $arg
				};
			}
			return 1;

		} elsif($landKind == $HlandRizort) {
		my($seaCount) =
		 countAround($land, $x, $y, $HlandSea, 7) +
		 countAround($land, $x, $y, $HlandOil, 7) +
		 countAround($land, $x, $y, $HlandIce, 7) +
		 countAround($land, $x, $y, $HlandSbase, 7) +
		 countAround($land, $x, $y, $HlandFune, 7) +
		 countAround($land, $x, $y, $HlandFrocity, 7) +
	 countAround($land, $x, $y, $HlandNursery, 7) +
		 countAround($land, $x, $y, $HlandUmiamu, 7) +
		 countAround($land, $x, $y, $HlandSeatown, 7) +
		 countAround($land, $x, $y, $HlandUmishuto, 7) +
	 countAround($land, $x, $y, $HlandSeacity, 7);
		my($rizortCount) =
		 countAround($land, $x, $y, $HlandRizort, 7) +
		 countAround($land, $x, $y, $HlandKajino, 7) +
		 countAround($land, $x, $y, $HlandBigRizort, 7);
 my($value);
 $value = $lv+$island->{'eis1'}+$island->{'eis2'}+$island->{'eis3'}+$island->{'eis5'}+int($island->{'fore'}/10)+int($island->{'rena'}/10)-$island->{'monsterlive'}*100;
			if(($seaCount> 1) &&
			 ($value> 500) &&
			 ($rizortCount> 2)) {
			 $land->[$x][$y] = $HlandBigRizort;
			logLandSuc($id, $name, $comName, $point);
			# 돈을 차감
			$island->{'money'} -= $cost;
			return 1;
			} else {
			logJoFail($id, $name, $comName, $landName, $point);
			return 0;
			}

		} elsif($landKind == $HlandBigRizort) {
			if($island->{'rena'} < 15000) {
			logJo2Fail($id, $name, $comName, $landName, $point);
			return 0;
			} else {
			$land->[$x][$y] = $HlandKajino;
			logLandSuc($id, $name, $comName, $point);
			# 돈을 차감
			$island->{'money'} -= $cost;
			return 1;
			}

		} else {
		 # 부적절나 지형
		 logLandFail($id, $name, $comName, $landName, $point);
		 return 0;
		}

 } elsif($kind == $HcomSbase) {
	if($island->{'shouhi'}> $island->{'ene'}) {
	 logMsNoEne($id, $name, $comName);
	 return 0;
	}
	# 해저 기지
	if(($landKind != $HlandSea) || ($lv != 0)){
	 # 바다이외에는 만들 수 없음
	 logLandFail($id, $name, $comName, $landName, $point);
	 return 0;
	}

	$land->[$x][$y] = $HlandSbase;
	$landValue->[$x][$y] = 0; # 경험치0
	logLandSuc($id, $name, $comName, '(?, ?)');

	# 돈을 차감
	$island->{'money'} -= $cost;
	return 1;
 } elsif($kind == $HcomSeacity) {
	if($island->{'shouhi'}> $island->{'ene'}) {
	 logMsNoEne($id, $name, $comName);
	 return 0;
	}
	# 해저 도시
	if(($landKind != $HlandSea) || ($lv != 0)){
	 # 바다이외에는 만들 수 없음
	 logLandFail($id, $name, $comName, $landName, $point);
	 return 0;
	}

	$land->[$x][$y] = $HlandSeacity;
	$landValue->[$x][$y] = 0; # 인구 0
	logLandSuc($id, $name, $comName, '(?, ?)');

	# 돈을 차감
	$island->{'money'} -= $cost;
	return 1;
 } elsif($kind == $HcomProcity) {
	# 방재화
	if(($landKind != $HlandTown) || ($lv != 100)){
	 # 바다이외에는 만들 수 없음
	 logLandFail($id, $name, $comName, $landName, $point);
	 return 0;
	}

	$land->[$x][$y] = $HlandProcity;
	$landValue->[$x][$y] = 100; # 경험치0
	logLandSuc($id, $name, $comName, $point);

	# 돈을 차감
	$island->{'money'} -= $cost;
	return 1;
 } elsif($kind == $HcomBigtown) {
	# 현대화
	if(($landKind != $HlandNewtown) || ($lv < 149)){
	 # 바다이외에는 만들 수 없음
	 logJoFail($id, $name, $comName, $landName, $point);
	 return 0;
	}
	my($townCount) =
	 countAround($land, $x, $y, $HlandTown, 19) +
	 countAround($land, $x, $y, $HlandProcity, 19) +
 countAround($land, $x, $y, $HlandNewtown, 19) +
	 countAround($land, $x, $y, $HlandBigtown, 19) +
	 countAround($land, $x, $y, $HlandBettown, 19) +
	 countAround($land, $x, $y, $HlandSkycity, 19) +
	 countAround($land, $x, $y, $HlandUmicity, 19) +
	 countAround($land, $x, $y, $HlandSeatown, 19) +
	 countAround($land, $x, $y, $HlandRizort, 19) +
	 countAround($land, $x, $y, $HlandKajino, 19) +
	 countAround($land, $x, $y, $HlandBigRizort, 19) +
	 countAround($land, $x, $y, $HlandShuto, 19) +
	 countAround($land, $x, $y, $HlandUmishuto, 19) +
	 countAround($land, $x, $y, $HlandMinato, 19) +
	 countAround($land, $x, $y, $HlandFrocity, 19) +
	 countAround($land, $x, $y, $HlandOnsen, 19) +
 countAround($land, $x, $y, $HlandSeacity, 19);
 if($townCount < 16) {
	 # 전체 바다다에서 매립불능
	 logJoFail($id, $name, $comName, $landName, $point);
	 return 0;
	}

	$land->[$x][$y] = $HlandBigtown;
	logLandSuc($id, $name, $comName, $point);

	# 돈을 차감
	$island->{'money'} -= $cost;
	return 1;
 } elsif($kind == $HcomSeatown) {
	# 현대화
	if(($landKind != $HlandSeacity) || ($lv < 200)){
	 # 바다이외에는 만들 수 없음
	 logJoFail($id, $name, $comName, $landName, '(?, ?)');
	 return 0;
	}
	my($townCount) =
	 countAround($land, $x, $y, $HlandTown, 19) +
	 countAround($land, $x, $y, $HlandProcity, 19) +
 countAround($land, $x, $y, $HlandNewtown, 19) +
	 countAround($land, $x, $y, $HlandBigtown, 19) +
	 countAround($land, $x, $y, $HlandBettown, 19) +
	 countAround($land, $x, $y, $HlandSkycity, 19) +
	 countAround($land, $x, $y, $HlandUmicity, 19) +
	 countAround($land, $x, $y, $HlandSeatown, 19) +
	 countAround($land, $x, $y, $HlandRizort, 19) +
	 countAround($land, $x, $y, $HlandKajino, 19) +
	 countAround($land, $x, $y, $HlandBigRizort, 19) +
	 countAround($land, $x, $y, $HlandShuto, 19) +
	 countAround($land, $x, $y, $HlandUmishuto, 19) +
	 countAround($land, $x, $y, $HlandMinato, 19) +
	 countAround($land, $x, $y, $HlandFrocity, 19) +
	 countAround($land, $x, $y, $HlandOnsen, 19) +
 countAround($land, $x, $y, $HlandSeacity, 19);
 if($townCount < 16) {
	 # 전체 바다다에서 매립불능
	 logJoFail($id, $name, $comName, $landName, '(?, ?)');
	 return 0;
	}

	$land->[$x][$y] = $HlandSeatown;
	logLandSuc($id, $name, $comName, '(?, ?)');

	# 돈을 차감
	$island->{'money'} -= $cost;
	return 1;
 } elsif($kind == $HcomBoku) {
	# 주민 이주
	if($landKind != $HlandProcity){
	 # 바다이외에는 만들 수 없음
	 logBokuFail($id, $name, $comName, $landName, $point);
	 return 0;
	}

	# 주변에 육지가 있는지 확인
	my($townCount) =
	 countAround($land, $x, $y, $HlandTown, 19);

 if($townCount == 0) {
	 # 전체 바다다에서 매립불능
	 logNoTownAround($id, $name, $comName, $point);
	 return 0;
	}

	$landValue->[$x][$y] += 10; # 규모 + 1000명
	if($landValue->[$x][$y]> 200) {
	 $landValue->[$x][$y] = 200; # 최대 20000명
	}
	 my($i,$sx,$sy);
	 for($i = 1; $i < 19; $i++) {
	 $sx = $x + $ax[$i];
	 $sy = $y + $ay[$i];
	 if($land->[$sx][$sy] == $HlandTown){
	 $landValue->[$sx][$sy] -= int(20/$townCount);
			if($landValue->[$sx][$sy] <= 0) {
			 # 평지로 되돌리기
			 $land->[$sx][$sy] = $HlandPlains;
			 $landValue->[$sx][$sy] = 0;
			 next;
			}
	 }
	 }
	logLandSuc($id, $name, $comName, $point);

	# 돈을 차감
	$island->{'money'} -= $cost;
	if($arg> 1) {
	 my($command);
	 $arg--;
	 slideBack($comArray, 0);
	 $comArray->[0] = {
		'kind' => $kind,
		'target' => $target,
		'x' => $x,
		'y' => $y,
		'arg' => $arg
		};
	}
	return 1;

 } elsif($kind == $HcomBoku2) {
	# 주민 이주2

	if($landKind == $HlandMonster) {
	my($mKind, $mName, $mHp) = monsterSpec($landValue->[$x][$y]);
	my($special) = $HmonsterSpecial[$mKind];
	 logBokuFail2($id, $name, $comName, $mName, $point);
	return 0;
	}

	if((($landKind == $HlandPlains) || ($landKind == $HlandSea)) && ($island->{'stockflag'} == 55)) {
		$land->[$x][$y] = $island->{'stocklandkind'};
		$landValue->[$x][$y] = $island->{'stocklandvalue'};
		$island->{'pointb'}.= "($x, $y)";
		logLandSuc($id, $name, $comName, $island->{'pointb'});

		if($HislandSize> 16) {
		$sizekeisu = 5;
		} else {
		$sizekeisu = 1;
		}

		if(($island->{'stocklandkind'} == $HlandHouse) && ($island->{'stocklandvalue'} == 9) && ($island->{'co01'}> $sizekeisu) && ($island->{'co8'}> $sizekeisu)) {

		$island->{'condenmekki'} = 0;

 my($i, $sx, $sy, $kind, $lv);
 for($i = 1; $i < 7; $i++) {
 $sx = $x + $ax[$i];
 $sy = $y + $ay[$i];

 # 행 기준 위치 조정
 if((($sy % 2) == 0) && (($y % 2) == 1)) {
 $sx--;
 }
		 if(($sx < 0) || ($sx>= $HislandSize) ||
		 ($sy < 0) || ($sy>= $HislandSize)) {
		 # 범위 밖
		 next;
		 }

 $kind = $land->[$sx][$sy];
 $lv = $landValue->[$sx][$sy];
		 my($mKind, $mName, $mHp) = monsterSpec($lv);

		 if (($kind == $HlandMonster) && ($mKind == 14)) {
		 $island->{'condenmekki'} = 3;
		 }

		 }

		if ($island->{'condenmekki'} == 3) {

	 my($i, $sx, $sy, $kind, $lv);
	 for($i = 1; $i < 19; $i++) {
	 $sx = $x + $ax[$i];
	 $sy = $y + $ay[$i];

	 # 행 기준 위치 조정
	 if((($sy % 2) == 0) && (($y % 2) == 1)) {
	 $sx--;
	 }
			 if(($sx < 0) || ($sx>= $HislandSize) ||
			 ($sy < 0) || ($sy>= $HislandSize)) {
			 # 범위 밖
			 next;
			 }

	 $kind = $land->[$sx][$sy];
	 $lv = $landValue->[$sx][$sy];

	 if ($kind == $HlandConden2) {
	 $land->[$sx][$sy] = $HlandConden3;
	 logConsFire($id, $name, landName($kind, $lv), "($sx, $sy)", $comName);
			 return 1;
			 }
			 }

		}

		}

		$island->{'money'} -= $cost;

	return 1;

	} elsif(($landKind == $HlandMountain) && ($island->{'stockflag'} == 55) && ((($island->{'stocklandkind'} == $HlandBettown) && ($island->{'stocklandvalue'}> 1500)) || (($island->{'stocklandkind'} == $HlandKajino) && ($island->{'stocklandvalue'}> 2000)))) {

		$land->[$x][$y] = $HlandSkycity;
		$landValue->[$x][$y] = $island->{'stocklandvalue'};
		$island->{'pointb'}.= "($x, $y)";
		logLandSuc($id, $name, $comName, $island->{'pointb'});

		$island->{'money'} -= $cost;

	return 1;

	} elsif(($landKind == $HlandFrocity) && ($island->{'stockflag'} == 55) && ((($island->{'stocklandkind'} == $HlandBettown) && ($island->{'stocklandvalue'}> 1500)) || (($island->{'stocklandkind'} == $HlandKajino) && ($island->{'stocklandvalue'}> 2000)))) {

		$land->[$x][$y] = $HlandUmicity;
		$landValue->[$x][$y] += $island->{'stocklandvalue'};
		$island->{'pointb'}.= "($x, $y)";
		logLandSuc($id, $name, $comName, $island->{'pointb'});

		$island->{'money'} -= $cost;

	return 1;

	} else {
		$island->{'stocklandkind'} = $land->[$x][$y];
		$island->{'stocklandvalue'} = $landValue->[$x][$y];
		$land->[$x][$y] = $HlandPlains;
		$landValue->[$x][$y] = 0;
		$island->{'pointb'} = "($x, $y)~";
		$island->{'stockflag'} = 55;
	return 0;
	}


 } elsif($kind == $HcomAuction) {

	$auc6 = $island->{'auc6'};
	$auc6 =~ /^([0-9]*),([0-9]*),([0-9]*)$/;
	($auc6a, $auc6x, $auc6y) = ($1, $2, $3);

	$landKind = $land->[$x][$y];
	$lv = $landValue->[$x][$y];
	$aucland = $landKind * $lv;

	if($auc6a != 1) {
	 logMsNoEne3($id, $name, $comName);
	 return 0;
	}

	$auction1 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	($shuppin1, $avalue1, $ajoutai1, $topvalue1, $topid1) = ($1, $2, $3, $4, $5);
	$auction2 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	($shuppin2, $avalue2, $ajoutai2, $topvalue2, $topid2) = ($1, $2, $3, $4, $5);
	$auction3 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	($shuppin3, $avalue3, $ajoutai3, $topvalue3, $topid3) = ($1, $2, $3, $4, $5);

	if($shuppin1 == 29) {
	 $island->{'auc6'} = "2,$x,$y";
	 $island->{'auc7'} = "$name 섬($x, $y)의$landName";
	 $auction1 = "30,$id,0,$arg,$aucland";
		$island->{'money'} -= $cost;
		logLandSuc($id, $name, $comName, $point);
		return 1;
	} elsif($shuppin2 == 29) {
	 $island->{'auc6'} = "2,$x,$y";
	 $island->{'auc7'} = "$name 섬($x, $y)의$landName";
	 $auction2 = "30,$id,0,$arg,$aucland";
		$island->{'money'} -= $cost;
		logLandSuc($id, $name, $comName, $point);
		return 1;
	} elsif($shuppin3 == 29) {
	 $island->{'auc6'} = "2,$x,$y";
	 $island->{'auc7'} = "$name 섬($x, $y)의$landName";
	 $auction3 = "30,$id,0,$arg,$aucland";
		$island->{'money'} -= $cost;
		logLandSuc($id, $name, $comName, $point);
		return 1;
	}

	 logMsNoEne4($id, $name, $comName);
	 return 0;

 } elsif($kind == $HcomGivefood) {
	# 에사
 if($landKind == $HlandMonster) {
	 my($mKind, $mName, $mHp) = monsterSpec($landValue->[$x][$y]);
	 my($special) = $HmonsterSpecial[$mKind];
		if($mHp < 10){$lv+=random(5);}
		$landValue->[$x][$y] = $lv;
 } elsif((($landKind == $HlandCollege) && ($lv == 4)) ||
		 (($landKind == $HlandCollege) && ($lv == 96)) ||
		 (($landKind == $HlandCollege) && ($lv == 97)) ||
		 (($landKind == $HlandCollege) && ($lv == 98))) {
		$eisei5 = $island->{'eisei5'};
		$eisei5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		($mshp, $msap, $msdp, $mssp, $mswin, $msexe, $tet) = ($1, $2, $3, $4, $5, $6, $7);
		 if(rand(100) < 30) {
		 $msap++;
		 } elsif (rand(100) < 30) {
		 $msdp++;
		 } elsif (rand(100) < 30) {
		 $mssp++;
		 } else {
		 $mshp++;
			if($mshp> 15){
			$mshp = 15;
			}
		 }
		 $island->{'eisei5'} = "$mshp,$msap,$msdp,$mssp,$mswin,$msexe,$tet";
 } else {
 # 부적절나 지형
 logLandFail($id, $name, $comName, $landName, $point);
 return 0;
 }
 logLandSuc($id, $name, $comName, $point);

	# 돈을 차감
	$island->{'food'} += $cost;
	if($arg> 1) {
	 my($command);
	 $arg--;
	 slideBack($comArray, 0);
	 $comArray->[0] = {
		'kind' => $kind,
		'target' => $target,
		'x' => $x,
		'y' => $y,
		'arg' => $arg
		};
	}
	return 1;

 } elsif($kind == $HcomEisei) {

	if($island->{'shouhi'}> $island->{'ene'}) {
	 logMsNoEne($id, $name, $comName);
	 return 0;
	}

	if($arg == 99) {
	 $arg = 99;
	} elsif(($arg>= 7) ||
	 ($arg == 0)) {
	 $arg = 1;
	}
	if($arg == 1) {
	 if($island->{'m17'} < 1) {
		logNoRoke($id, $name, $comName, $point);
	 return 0;
	 }
	 if($island->{'rena'} < 10) {
		logNoTech($id, $name, $comName, $point);
	 return 0;
	 }
	 if(random(100)> 70+$island->{'rena'}) {
		logEiseifail($id, $name, $comName, $point);
		# 돈을 차감
		$value = min($arg * ($cost), $island->{'money'});
		$island->{'money'} -= $value;
	 return 1;
	 }
	 $island->{'eis1'} = 100;
	logLandSucmini($id, $name, $comName, $point);
	}
	if($arg == 2) {
	 if($island->{'m17'} < 1) {
		logNoRoke($id, $name, $comName, $point);
	 return 0;
	 }
	 if($island->{'rena'} < 40) {
		logNoTech($id, $name, $comName, $point);
	 return 0;
	 }
	 if(random(100)> 50+$island->{'rena'}) {
		logEiseifail($id, $name, $comName, $point);
		# 돈을 차감
		$value = min($arg * ($cost), $island->{'money'});
		$island->{'money'} -= $value;
	 return 1;
	 }
	 $island->{'eis2'} = 100;
	logLandSucmini($id, $name, $comName, $point);
	}
	if($arg == 3) {
	 if($island->{'m17'} < 2) {
		logNoRoke($id, $name, $comName, $point);
	 return 0;
	 }
	 if($island->{'rena'} < 100) {
		logNoTech($id, $name, $comName, $point);
	 return 0;
	 }
	 if(random(1000)> 600+$island->{'rena'}) {
		logEiseifail($id, $name, $comName, $point);
		# 돈을 차감
		$value = min($arg * ($cost), $island->{'money'});
		$island->{'money'} -= $value;
	 return 1;
	 }
	 $island->{'eis3'} = 100;
	logLandSucmini($id, $name, $comName, $point);
	}
	if($arg == 4) {
	 if($island->{'m17'} < 3) {
		logNoRoke($id, $name, $comName, $point);
	 return 0;
	 }
	 if($island->{'rena'} < 250) {
		logNoTech($id, $name, $comName, $point);
	 return 0;
	 }
	 if(random(1000)> 400+$island->{'rena'}) {
		logEiseifail($id, $name, $comName, $point);
		# 돈을 차감
		$value = min($arg * ($cost), $island->{'money'});
		$island->{'money'} -= $value;
	 return 1;
	 }
	 $island->{'eis4'} = 100;
	logLandSucmini($id, $name, $comName, $point);
	}
	if($arg == 5) {
	 if($island->{'m17'} < 4) {
		logNoRoke($id, $name, $comName, $point);
	 return 0;
	 }
	 if($island->{'rena'} < 1000) {
		logNoTech($id, $name, $comName, $point);
	 return 0;
	 }
	 if(random(1000)> 200+$island->{'rena'}) {
		logEiseifail($id, $name, $comName, $point);
		# 돈을 차감
		$value = min($arg * ($cost), $island->{'money'});
		$island->{'money'} -= $value;
	 return 1;
	 }
	 $island->{'eis5'} = 100;
	logLandSucmini($id, $name, $comName, $point);
	}
	if($arg == 6) {
	 if($island->{'m17'} < 10) {
		logNoRoke($id, $name, $comName, $point);
	 return 0;
	 }
	 if($island->{'rena'} < 2000) {
		logNoTech($id, $name, $comName, $point);
	 return 0;
	 }
	 if(random(10000)> 3000+$island->{'rena'}) {
		logEiseifail($id, $name, $comName, $point);
		# 돈을 차감
		$value = min($arg * ($cost), $island->{'money'});
		$island->{'money'} -= $value;
	 return 1;
	 }
	 $island->{'eis6'} = 250;
	logLandSucmini($id, $name, $comName, $point);
	}
	if($arg == 99) {
	 if($island->{'money'} < 1000000) {
		logNoMoney($id, $name, $comName);
		return 0;
	 }
	 if($island->{'m17'} < 10) {
		logNoRoke($id, $name, $comName, $point);
	 return 0;
	 }
	 if($island->{'rena'} < 5000) {
		logNoTech($id, $name, $comName, $point);
	 return 0;
	 }
	 if(random(10000)> 3000+$island->{'rena'}) {
		logEiseifail($id, $name, $comName, $point);
		# 돈을 차감
		$island->{'money'} -= 1000000;
	 return 1;
	 }
	 $island->{'eis7'} = 124;
	logLandSucmini($id, $name, $comName, $point);
	$island->{'money'} -= 1000000;
	return 1;
	}

	# 돈을 차감
	$value = min($arg * ($cost), $island->{'money'});
	$island->{'money'} -= $value;
	return 1;
 } elsif($kind == $HcomEiseimente) {

	if($island->{'shouhi'}> $island->{'ene'}) {
	 logMsNoEne($id, $name, $comName);
	 return 0;
	}

	if($arg == 99) {
	 $arg = 99;
	} elsif(($arg>= 6) ||
	 ($arg == 0)) {
	 $arg = 1;
	}
	if($arg == 1) {
	 if($island->{'eis1'}>= 1) {
	 $island->{'eis1'} = 150;
		logLandSucmini($id, $name, $comName, $point);
	 } else {
	 logNoEisei($id, $name, $comName);
		return 0;
	 }
	}
	if($arg == 2) {
	 if($island->{'eis2'}>= 1) {
	 $island->{'eis2'} = 150;
		logLandSucmini($id, $name, $comName, $point);
	 } else {
	 logNoEisei($id, $name, $comName);
		return 0;
	 }
	}
	if($arg == 3) {
	 if($island->{'eis3'}>= 1) {
	 $island->{'eis3'} = 150;
		logLandSucmini($id, $name, $comName, $point);
	 } else {
	 logNoEisei($id, $name, $comName);
		return 0;
	 }
	}
	if($arg == 4) {
	 if($island->{'eis4'}>= 1) {
	 $island->{'eis4'} = 150;
		logLandSucmini($id, $name, $comName, $point);
	 } else {
	 logNoEisei($id, $name, $comName);
		return 0;
	 }
	}
	if($arg == 5) {
	 if($island->{'eis5'}>= 1) {
	 $island->{'eis5'} = 150;
		logLandSucmini($id, $name, $comName, $point);
	 } else {
	 logNoEisei($id, $name, $comName);
		return 0;
	 }
	}
	if($arg == 99) {
	 $eis7 = $island->{'eis7'};
	 $cstpop = int($eis7/100);
	 $csten = $eis7%100;
	 if($csten>= 1) {
	 $csten += 25;

	 if($csten> 99) {
		$csten = 99;
		$cstpop+=100;
	 }
		logLandSucmini($id, $name, $comName, $point);
	 $island->{'eis7'} = $cstpop*100+$csten;
	 } else {
	 logNoEisei($id, $name, $comName);
		return 0;
	 }
	}

	# 돈을 차감
	$island->{'money'} -= $cost;
	return 1;

 } elsif($kind == $HcomEiseiAtt) {
	if($arg == 99) {
	 $arg = 99;
	} elsif(($arg>= 7) ||
	 ($arg == 0)) {
	 $arg = 1;
	}
	# 대상 가져오기
	my($tn) = $HidToNumber{$target};
	if($tn eq '') {
	 # 대상이 이미 없음
	 logMsNoTarget($id, $name, $comName);
	 return 0;
	}
	# 사전준비
	my($tIsland) = $Hislands[$tn];
	my($tName) = $tIsland->{'name'};
	my($tEisei1) = $tIsland->{'eis1'};
	my($tEisei2) = $tIsland->{'eis2'};
	my($tEisei3) = $tIsland->{'eis3'};
	my($tEisei4) = $tIsland->{'eis4'};
	my($tEisei5) = $tIsland->{'eis5'};
	my($tEisei6) = $tIsland->{'eis6'};
	my($tEisei7) = $tIsland->{'eis7'};


	$etc7 = $island->{'etc7'};
	$etc7 =~ /^([0-9]*),([0-9]*),([0-9]*)$/;
	($msjotai, $nokotan, $msid) = ($1, $2, $3);
	if((($msjotai != 2) ||
	 ($tIsland->{'id'} != $msid)) && ($lovePeace == 1)) {
		logNiwaren3($id, $name, $comName);
		return 1;
 }


	if($island->{'eis6'}>= 1) {
	 if($arg == 1) {
	 if($tEisei1>= 1) {
		 if(random(100) < 100) {
	 $tIsland->{'eis1'} = 0;
	 logEiseiAtts($id, $tId, $name, $tName, $comName, "기상위성");
	 } else {
	 logEiseiAttf($id, $tId, $name, $tName, $comName, "기상위성");
		 }
	 } else {
	 logNoEisei($id, $name, $comName);
		 return 0;
	 }
	 }
	 if($arg == 2) {
	 if($tEisei2>= 1) {
		 if(random(100) < 90) {
	 $tIsland->{'eis2'} = 0;
	 logEiseiAtts($id, $tId, $name, $tName, $comName, "관측위성");
	 } else {
	 logEiseiAttf($id, $tId, $name, $tName, $comName, "관측위성");
		 }
	 } else {
	 logNoEisei($id, $name, $comName);
		 return 0;
	 }
	 }
	 if($arg == 3) {
	 if($tEisei3>= 1) {
		 if(random(100) < 80) {
	 $tIsland->{'eis3'} = 0;
	 logEiseiAtts($id, $tId, $name, $tName, $comName, "요격위성");
	 } else {
	 logEiseiAttf($id, $tId, $name, $tName, $comName, "요격위성");
		 }
	 } else {
	 logNoEisei($id, $name, $comName);
		 return 0;
	 }
	 }
	 if($arg == 4) {
	 if($tEisei4>= 1) {
		 if(random(100) < 70) {
	 $tIsland->{'eis4'} = 0;
	 logEiseiAtts($id, $tId, $name, $tName, $comName, "군사위성");
	 } else {
	 logEiseiAttf($id, $tId, $name, $tName, $comName, "군사위성");
		 }
	 } else {
	 logNoEisei($id, $name, $comName);
		 return 0;
	 }
	 }
	 if($arg == 5) {
	 if($tEisei5>= 1) {
		 if(random(100) < 60) {
	 $tIsland->{'eis5'} = 0;
	 logEiseiAtts($id, $tId, $name, $tName, $comName, "방위위성");
	 } else {
	 logEiseiAttf($id, $tId, $name, $tName, $comName, "방위위성");
		 }
	 } else {
	 logNoEisei($id, $name, $comName);
		 return 0;
	 }
	 }
	 if($arg == 6) {
	 if($tEisei6>= 1) {
		 if(random(100) < 50) {
	 $tIsland->{'eis6'} = 0;
	 logEiseiAtts($id, $tId, $name, $tName, $comName, "비정상");
	 } else {
	 logEiseiAttf($id, $tId, $name, $tName, $comName, "비정상");
		 }
	 } else {
	 logNoEisei($id, $name, $comName);
		 return 0;
	 }
	 }
	 if($arg == 99) {
	 if($tEisei7>= 1) {
			$tcstpop = int($tEisei7/100);
			$tcsten = $tEisei7%100;
			$tdmg = random(100);
			$tcstpop = int($tcstpop*$tdmg/100);
			$tcsten = int($tcsten*$tdmg/100);
			$tIsland->{'eis7'} = $tcstpop*100+$tcsten;
			$tdmg = 100-$tdmg;
	 logEiseiAttcst($id, $tId, $name, $tName, $comName, "우주 정거장", $tdmg);

			if($tcsten < $tdmg) {
			$tIsland->{'eis7'} = 0;
			logEiseiEnd($id, $name, "우주 정거장");
			}

	 } else {
	 logNoEisei($id, $name, $comName);
		 return 0;
	 }
	 }
	# 돈을 차감
 $island->{'eis6'} -= 30;
 if($island->{'eis6'} < 1) {
 $island->{'eis6'} = 0;
		logEiseiEnd($id, $name, "비정상");
 }
	$island->{'money'} -= $cost;
	return 1;
	}
	elsif($island->{'eis4'}>= 1) {
	 if($arg == 1) {
	 if($tEisei1>= 1) {
		 if(random(100) < 70) {
	 $tIsland->{'eis1'} = 0;
	 logEiseiAtts($id, $tId, $name, $tName, $comName, "기상위성");
	 } else {
	 logEiseiAttf($id, $tId, $name, $tName, $comName, "기상위성");
		 }
	 } else {
	 logNoEisei($id, $name, $comName);
		 return 0;
	 }
	 }
	 if($arg == 2) {
	 if($tEisei2>= 1) {
		 if(random(100) < 60) {
	 $tIsland->{'eis2'} = 0;
	 logEiseiAtts($id, $tId, $name, $tName, $comName, "관측위성");
	 } else {
	 logEiseiAttf($id, $tId, $name, $tName, $comName, "관측위성");
		 }
	 } else {
	 logNoEisei($id, $name, $comName);
		 return 0;
	 }
	 }
	 if($arg == 3) {
	 if($tEisei3>= 1) {
		 if(random(100) < 50) {
	 $tIsland->{'eis3'} = 0;
	 logEiseiAtts($id, $tId, $name, $tName, $comName, "요격위성");
	 } else {
	 logEiseiAttf($id, $tId, $name, $tName, $comName, "요격위성");
		 }
	 } else {
	 logNoEisei($id, $name, $comName);
		 return 0;
	 }
	 }
	 if($arg == 4) {
	 if($tEisei4>= 1) {
		 if(random(100) < 40) {
	 $tIsland->{'eis4'} = 0;
	 logEiseiAtts($id, $tId, $name, $tName, $comName, "군사위성");
	 } else {
	 logEiseiAttf($id, $tId, $name, $tName, $comName, "군사위성");
		 }
	 } else {
	 logNoEisei($id, $name, $comName);
		 return 0;
	 }
	 }
	 if($arg == 5) {
	 if($tEisei5>= 1) {
		 if(random(100) < 30) {
	 $tIsland->{'eis5'} = 0;
	 logEiseiAtts($id, $tId, $name, $tName, $comName, "방위위성");
	 } else {
	 logEiseiAttf($id, $tId, $name, $tName, $comName, "방위위성");
		 }
	 } else {
	 logNoEisei($id, $name, $comName);
		 return 0;
	 }
	 }
	 if($arg == 6) {
	 if($tEisei6>= 1) {
		 if(random(100) < 20) {
	 $tIsland->{'eis6'} = 0;
	 logEiseiAtts($id, $tId, $name, $tName, $comName, "비정상");
	 } else {
	 logEiseiAttf($id, $tId, $name, $tName, $comName, "비정상");
		 }
	 } else {
	 logNoEisei($id, $name, $comName);
		 return 0;
	 }
	 }
	 if($arg == 99) {
	 if($tEisei7>= 1) {
			$tcstpop = int($tEisei7/100);
			$tcsten = $tEisei7%100;
			$tdmg = random(100);
			$tcstpop = int($tcstpop*$tdmg/100);
			$tcsten = int($tcsten*$tdmg/100);
			$tIsland->{'eis7'} = $tcstpop*100+$tcsten;
			$tdmg = 100-$tdmg;
	 logEiseiAttcst($id, $tId, $name, $tName, $comName, "우주 정거장", $tdmg);

			if($tcsten < $tdmg) {
			$tIsland->{'eis7'} = 0;
			logEiseiEnd($id, $name, "우주 정거장");
			}

	 } else {
	 logNoEisei($id, $name, $comName);
		 return 0;
	 }
	 }
	# 돈을 차감
 $island->{'eis4'} -= 30;
 if($island->{'eis4'} < 1) {
 $island->{'eis4'} = 0;
		logEiseiEnd($id, $name, "군사위성");
 }
	$island->{'money'} -= $cost;
	return 1;
	} else {
	 logNesEisei($id, $name, $comName);
		 return 0;
 }


 } elsif($kind == $HcomEiseiLzr) {
	my($tn) = $HidToNumber{$target};
	if($tn eq '') {
	 # 대상이 이미 없음
	 logMsNoTarget($id, $name, $comName);
	 return 0;
	}
	# 사전준비
	my($tIsland) = $Hislands[$tn];
	my($tName) = $tIsland->{'name'};
	my($tLand) = $tIsland->{'land'};
	my($tLandValue) = $tIsland->{'landValue'};
	my($tx, $ty);


	$etc7 = $island->{'etc7'};
	$etc7 =~ /^([0-9]*),([0-9]*),([0-9]*)$/;
	($msjotai, $nokotan, $msid) = ($1, $2, $3);
	if((($msjotai != 2) ||
	 ($tIsland->{'id'} != $msid)) && ($lovePeace == 1)) {
		logNiwaren3($id, $name, $comName);
		return 1;
 }


 # 자기 섬의 인구가 적거나, 대상 섬의 인구가 적으면, 실행은 허가되지 않는
 if (($island->{'pop'} < $HguardPop) || ($tIsland->{'pop'} < $HguardPop)) {
 logForbidden($id, $name, $comName);
 return 0;
 }
		# 착탄점 산출
		$err = 1;
		my($r) = random($err);
		$tx = $x + $ax[$r];
		$ty = $y + $ay[$r];
		if((($ty % 2) == 0) && (($y % 2) == 1)) {
		 $tx--;
		}

		# 착탄점의 지형등 산출
		my($tL) = $tLand->[$tx][$ty];
		my($tLv) = $tLandValue->[$tx][$ty];
		my($tLname) = landName($tL, $tLv);
		my($tPoint) = "($tx, $ty)";

	if($island->{'eis6'}>= 1){
	 if(($tL == $HlandSea) ||
	 ($tL == $HlandWaste) ||
	 ($tL == $HlandMountain) ||
	 ($tL == $HlandGold) ||
	 ($tL == $HlandSeacity) ||
	 ($tL == $HlandSeatown) ||
	 ($tL == $HlandUmishuto) ||
	 ($tL == $HlandUmiamu) ||
	 ($tL == $HlandSbase)) {
		logLzrefc($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint);
	 } elsif(($tL == $HlandOil) ||
	 ($tL == $HlandNursery) ||
	 ($tL == $HlandFrocity) ||
	 ($tL == $HlandIce) ||
	 ($tL == $HlandFune)) {
		logLzrhit($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint);
 $tLand->[$tx][$ty] = $HlandSea;
 $tLandValue->[$tx][$ty] = 1;
	 } elsif($tL == $HlandOnsen) {
		logLzrhit($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint);
 $tLand->[$tx][$ty] = $HlandMountain;
 $tLandValue->[$tx][$ty] = 0;
	 } else {
		logLzrhit($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint);
 $tLand->[$tx][$ty] = $HlandWaste;
 $tLandValue->[$tx][$ty] = 0;
		 if (rand(1000) < 100) {
		 $land->[$tx][$ty] = $HlandMonument;
		 $landValue->[$tx][$ty] = 79;
		 }
	 }
	 	$island->{'eis6'} -= 5;
		if($island->{'eis6'} < 1) {
		 $island->{'eis6'} = 0;
		 logEiseiEnd($id, $name, "비정상");
		}
		$island->{'money'} -= $cost;
		return 1;
	} elsif($island->{'eis4'}>= 1){
	 if(($tL == $HlandSea) ||
	 ($tL == $HlandWaste) ||
	 ($tL == $HlandMountain) ||
	 ($tL == $HlandGold) ||
	 ($tL == $HlandSeacity) ||
	 ($tL == $HlandSeatown) ||
	 ($tL == $HlandUmishuto) ||
	 ($tL == $HlandUmiamu) ||
	 ($tL == $HlandSbase)) {
		logLzrefc($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint);
	 } elsif(($tL == $HlandOil) ||
	 ($tL == $HlandNursery) ||
	 ($tL == $HlandFrocity) ||
	 ($tL == $HlandIce) ||
	 ($tL == $HlandFune)) {
		logLzrhit($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint);
 $tLand->[$tx][$ty] = $HlandSea;
 $tLandValue->[$tx][$ty] = 1;
	 } elsif($tL == $HlandOnsen) {
		logLzrhit($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint);
 $tLand->[$tx][$ty] = $HlandMountain;
 $tLandValue->[$tx][$ty] = 0;
	 } else {
		logLzrhit($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint);
 $tLand->[$tx][$ty] = $HlandWaste;
 $tLandValue->[$tx][$ty] = 0;
		 if (rand(1000) < 100) {
		 $land->[$tx][$ty] = $HlandMonument;
		 $landValue->[$tx][$ty] = 79;
		 }
	 }
	 	$island->{'eis4'} -= 10;
		if($island->{'eis4'} < 1) {
		 $island->{'eis4'} = 0;
		 logEiseiEnd($id, $name, "군사위성");
		}
		$island->{'money'} -= $cost;
		return 1;
	} else {
	 logNesEisei($id, $name, $comName);
		 return 0;
 }


 } elsif(($kind == $HcomMissileNM) ||
	 ($kind == $HcomMissilePP) ||
	 ($kind == $HcomMissileSPP) ||
	 ($kind == $HcomMissileST) ||
	 ($kind == $HcomMissileSS) ||
	 ($kind == $HcomMissileLR) ||
	 ($kind == $HcomMissileLD)) {
	# 미사일계
	# 대상 가져오기
	my($tn) = $HidToNumber{$target};
	if($tn eq '') {
	 # 대상이 이미 없음
	 logMsNoTarget($id, $name, $comName);
	 return 0;
	}

	if($island->{'shouhi'}> $island->{'ene'}) {
	 logMsNoEne($id, $name, $comName);
	 return 0;
	}

	my($flag) = 0;
	if($arg == 0) {
	 # 0의 경우격하고 있는 만
	 $arg = 100;
	}

	# 사전준비
	my($tIsland) = $Hislands[$tn];
	my($tName) = $tIsland->{'name'};
	my($tLand) = $tIsland->{'land'};
	my($tLandValue) = $tIsland->{'landValue'};
	my($tx, $ty, $err);

	$etc7 = $island->{'etc7'};
	$etc7 =~ /^([0-9]*),([0-9]*),([0-9]*)$/;
	($msjotai, $nokotan, $msid) = ($1, $2, $3);

	my($doumei) = 0;

	 my($dx, $dy, $landKindd, $ttlv, $i);
	 for($i = 0; $i < $HpointNumber; $i++) {
		$dx = $Hrpx[$i];
		$dy = $Hrpy[$i];
		$landKindd = $land->[$dx][$dy];
		if($landKindd == $HlandTaishi) {
		 $ttlv = $landValue->[$dx][$dy];
		 if($ttlv == $tIsland->{'id'}) {
			$doumei = 1;
	 }
		}
	 }

		if(($lovePeace == 1) &&
		 ($msjotai == 2) &&
		 ($tIsland->{'id'} == $msid)) {

	 } elsif(($lovePeace == 1) &&
		 ($doumei == 1) &&
		 ($island->{'id'} != $tIsland->{'id'})) {

	 } elsif(($lovePeace == 1) &&
		 ($tIsland->{'monsterlive'} == 0) &&
		 ($tIsland->{'rot'} == 0) &&
		 ($island->{'id'} != $tIsland->{'id'})) {

		$island->{'money'} = 0;

		logNiwaren2($id, $name, $comName);
		return 0;
	 } elsif(($lovePeace == 1) &&
			($kind != $HcomMissileSPP) &&
			($island->{'id'} != $tIsland->{'id'})) {
		logNiwaren3($id, $name, $comName);
		return 0;
	 }


 # 자기 섬의 인구가 적거나, 대상 섬의 인구가 적으면, 실행은 허가되지 않는
 if ((($island->{'pop'} < $HguardPop) || ($tIsland->{'pop'} < $HguardPop)) && ($tIsland->{'rot'} == 0)) {
 logForbidden($id, $name, $comName);
 return 0;
 }

	# 난민의 수
	my($boat) = 0;

	# 오차
	if($kind == $HcomMissilePP) {
	 $err = 7;
	} elsif($kind == $HcomMissileSS) {
	 $err = 7;
	} elsif($kind == $HcomMissileSPP) {
	 $err = 1;
	} else {
	 $err = 19;
	}

	$mukou = 0;
	$bouei = 0;
	$kaijumukou = 0;
	$kaijuhit = 0;
	$total = 0;
	$fuhatu = 0;

	# 자금이 부족하면 지정수량을 충족하거나 전체 기지 가격에 도달할 때까지 반복
	my($bx, $by, $count) = (0,0,0);
	while(($arg> 0) &&
	 ($island->{'money'}>= $cost)) {
	 # 기지를 찾을 때까지 반복
	 while($count < $HpointNumber) {
		$bx = $Hrpx[$count];
		$by = $Hrpy[$count];
		if(($land->[$bx][$by] == $HlandBase) ||
		 ($land->[$bx][$by] == $HlandSbase)) {
		 last;
		}
		$count++;
	 }
	 if($count>= $HpointNumber) {
		# 찾을 수 없었습니다라그곳까지
		last;
	 }

	 # 최소하나기지가 있었던이므로,flag 을설립하고 있는
	 $flag = 1;

	 # 기지의 레벨을 산출
	 my($level) = expToLevel($land->[$bx][$by], $landValue->[$bx][$by]);
	 # 기지내에서 루프
	 while(($level> 0) &&
		 ($arg> 0) &&
		 ($island->{'money'}> $cost)) {
			if(rand(300) < $alltotal-int($island->{'rena'}/100)) {
			$level--;
			$arg--;
			$island->{'money'} -= $cost;
			$total++;
			$alltotal++;
			$fuhatu++;
			}
		# 명중이 확정이므로, 각 값을 소도
		$level--;
		$arg--;
		$island->{'money'} -= $cost;
		$total++;
		$alltotal++;
		# 착탄점 산출
		my($r) = random($err);
		$tx = $x + $ax[$r];
		$ty = $y + $ay[$r];
		if((($ty % 2) == 0) && (($y % 2) == 1)) {
		 $tx--;
		}

		# 착탄점범위안팎 확인
		if(($tx < 0) || ($tx>= $HislandSize) ||
		 ($ty < 0) || ($ty>= $HislandSize)) {
		 # 범위 밖
		 if($kind == $HcomMissileST) {
			$mukou++;
		 } else {
			$mukou++;
		 }
		 next;
		}

		# 착탄점의 지형등 산출
		my($tL) = $tLand->[$tx][$ty];
		my($tLv) = $tLandValue->[$tx][$ty];
		my($tLname) = landName($tL, $tLv);
		my($tPoint) = "($tx, $ty)";

		# 방위 시설판정
		my($defence) = 0;
		if($kind == $HcomMissileSPP) {
		 $defence = 1;
		}
		if($HdefenceHex[$id][$tx][$ty] == 1) {
		 $defence = 1;
		} elsif($HdefenceHex[$id][$tx][$ty] == -1) {
		 $defence = 0;
		} else {
		 if(($tL == $HlandDefence) ||
		 (($tL == $HlandProcity) && ($tLv < 160))) {
			# 방위 시설에 명중
			# 플래그를 지우기
			my($i, $count, $sx, $sy);
			for($i = 0; $i < 19; $i++) {
			 $sx = $tx + $ax[$i];
			 $sy = $ty + $ay[$i];

			 # 행 기준 위치 조정
			 if((($sy % 2) == 0) && (($ty % 2) == 1)) {
				$sx--;
			 }

			 if(($sx < 0) || ($sx>= $HislandSize) ||
			 ($sy < 0) || ($sy>= $HislandSize)) {
				# 범위 밖이면 아무것도 하지 않음
			 } else {
				# 범위 안의 경우
				$HdefenceHex[$id][$sx][$sy] = 0;
			 }
			}
		 } elsif((countAround($tLand, $tx, $ty, $HlandDefence, 19))&&($island->{'sabun'}> 0)) {
			$HdefenceHex[$id][$tx][$ty] = 1;
			$defence = 1;
		 } elsif((countAround($tLand, $tx, $ty, $HlandProcity, 7))&&($island->{'sabun'}> 0)) {
			$HdefenceHex[$id][$tx][$ty] = 1;
			$defence = 1;
		 } elsif((countAround($tLand, $tx, $ty, $HlandHouse, 1))&&($island->{'sabun'}> 0)) {
			$HdefenceHex[$id][$tx][$ty] = 1;
			$defence = 1;
		 } elsif((countAround($tLand, $tx, $ty, $HlandShuto, 7))&&($island->{'sabun'}> 0)) {
			$HdefenceHex[$id][$tx][$ty] = 1;
			$defence = 1;
		 } else {
			$HdefenceHex[$id][$tx][$ty] = -1;
			$defence = 0;
		 }
		}

		if($defence == 1) {
		 # 공안폭파
		 if($kind == $HcomMissileST) {
			$bouei++;
		 } else {
			$bouei++;
		 }
		 next;
		}

	 if($tIsland->{'eis5'}>= 1) {
		 if(random(5000) < $tIsland->{'rena'}) {
	 $tIsland->{'eis5'} -= 2;
			if($tIsland->{'eis5'} < 1) {
			 $tIsland->{'eis5'} = 0;
			 logEiseiEnd($id, $name, "방위위성");
			}
			$bouei++;
		 next;
		 }
	 }

	 if($tIsland->{'c23'}>= 1) {
			$kaijumukou++;
		 next;
	 }

	 if(($tIsland->{'h10'}>= 1) && ($island->{'id'} != $tIsland->{'id'})) {
			$bouei++;
		 next;
	 }

		# '효과 없음'hex 을처음에판정
		if(($kind != $HcomMissileLR) &&
		 ((($tL == $HlandSea) && ($tLv == 0)) || # 깊은 바다
		 ((($tL == $HlandSea) || # 바다또는...
		 ($tL == $HlandSbase) || # 해저 기지또는...
		 ($tL == $HlandSeacity) ||
		 ($tL == $HlandSeatown) ||
		 ($tL == $HlandUmishuto) ||
		 ($tL == $HlandUmiamu) ||
		 ($tL == $HlandGold) ||
		 ($tL == $HlandMountain)) # 산에서...
		 && ($kind != $HcomMissileLD)))){ # 육상 파괴탄이외
		 # 해저 기지는 바다처럼 표시
		 if(($tL == $HlandSbase) ||
		 ($tL == $HlandSeatown) ||
		 ($tL == $HlandUmishuto) ||
		 ($tL == $HlandSeacity)) {
			$tL = $HlandSea;
		 }
		 $tLname = landName($tL, $tLv);

		 # 무효화
		 if($kind == $HcomMissileST) {
			# 스텔스
			$mukou++;
		 } else {
			# 일반계
			$mukou++;
		 }
		 next;
		}

		# 탄 종류에서 분기
 if($kind == $HcomMissileLR) {
 if(($tL == $HlandMountain) ||
	 ($tL == $HlandGold)) {
 # 산에 착탄한 경우무효
			$mukou++;
 next;
 }
 if($tL == $HlandSbase) {
 # 해저 기지이면 대상 위치를 얕은 바다로 변경
 $land->[$tx][$ty] = $HlandSea;
 $landValue->[$tx][$ty] = 1;
 logMsLRSbase($id, $target, $name, $tName,
 $comName, $tLname, $point, $tPoint);
 next;
 } elsif($tL == $HlandSeacity) {
 # 해저 기지이면 대상 위치를 얕은 바다로 변경
 $land->[$tx][$ty] = $HlandSea;
 $landValue->[$tx][$ty] = 1;
 logMsLRSbase($id, $target, $name, $tName,
 $comName, $tLname, $point, $tPoint);
 next;
 } elsif($tL == $HlandUmishuto) {
 # 해저 기지이면 대상 위치를 얕은 바다로 변경
 $land->[$tx][$ty] = $HlandSea;
 $landValue->[$tx][$ty] = 1;
 logMsLRSbase($id, $target, $name, $tName,
 $comName, $tLname, $point, $tPoint);
 next;
 } elsif($tL == $HlandSeatown) {
 # 해저 기지이면 대상 위치를 얕은 바다로 변경
 $land->[$tx][$ty] = $HlandSea;
 $landValue->[$tx][$ty] = 1;
 logMsLRSbase($id, $target, $name, $tName,
 $comName, $tLname, $point, $tPoint);
 next;
 } elsif($tL == $HlandOil) {
 # 해저 기지이면 대상 위치를 얕은 바다로 변경
 $land->[$tx][$ty] = $HlandSea;
 $landValue->[$tx][$ty] = 1;
 logMsLRSbase($id, $target, $name, $tName,
 $comName, $tLname, $point, $tPoint);
 next;
 } elsif($tL == $HlandFune) {
 # 해저 기지이면 대상 위치를 얕은 바다로 변경
 $land->[$tx][$ty] = $HlandSea;
 $landValue->[$tx][$ty] = 1;
 logMsLRSbase($id, $target, $name, $tName,
 $comName, $tLname, $point, $tPoint);
 next;
 } elsif($tL == $HlandFrocity) {
 # 해저 기지이면 대상 위치를 얕은 바다로 변경
 $land->[$tx][$ty] = $HlandSea;
 $landValue->[$tx][$ty] = 1;
 logMsLRSbase($id, $target, $name, $tName,
 $comName, $tLname, $point, $tPoint);
 next;
 } elsif($tL == $HlandUmiamu) {
 # 해저 기지이면 대상 위치를 얕은 바다로 변경
 $land->[$tx][$ty] = $HlandSea;
 $landValue->[$tx][$ty] = 1;
 logMsLRSbase($id, $target, $name, $tName,
 $comName, $tLname, $point, $tPoint);
 next;
 } elsif($tL == $HlandRottenSea) {
 # 해저 기지이면 대상 위치를 얕은 바다로 변경
 $land->[$tx][$ty] = $HlandMountain;
 $landValue->[$tx][$ty] = 0;
 logMsLRSeaRotten($id, $target, $name, $tName,
 $comName, $tLname, $point, $tPoint);
 next;
 } elsif(($tL == $HlandSea) ||
		($tL == $HlandIce)) {
 if($tLv == 1){
 # 얕은 바다의 경우
 $tLand->[$tx][$ty] = $HlandWaste;
 $tLandValue->[$tx][$ty] = 0;
 logMsLRSea1($id, $target, $name, $tName,
 $comName, $tLname, $point, $tPoint);

 $tIsland->{'area'}++;

 if($seaCount <= 4) {
 # 주변 바다가 3헥스 이내이므로 얕은 바다로
 my($i, $sx, $sy);
 for($i = 1; $i < 7; $i++) {
 $sx = $x + $ax[$i];
 $sy = $y + $ay[$i];

 # 행 기준 위치 조정
 if((($sy % 2) == 0) && (($y % 2) == 1)) {
 $sx--;
 }

 if(($sx < 0) || ($sx>= $HislandSize) ||
 ($sy < 0) || ($sy>= $HislandSize)) {
 } else {
 # 범위 안의 경우
 if($tLand->[$sx][$sy] == $HlandSea) {
 $tLandValue->[$sx][$sy] = 1;
 }
 }
 }
 }
 next;
 } else {
 # 바다이면 대상 위치를 얕은 바다로 변경
 $tLand->[$tx][$ty] = $HlandSea;
 $tLandValue->[$tx][$ty] = 1;
 logMsLRSbase($id, $target, $name, $tName,
 $comName, $tLname, $point, $tPoint);

 next;

 }
 } elsif($tL == $HlandMonster){
 logMsLRMonster($id, $target, $name, $tName,
 $comName, $tLname, $point, $tPoint);
 # 산이 됨
 $tLand->[$tx][$ty] = $HlandMountain;
 $tLandValue->[$tx][$ty] = 0;
 next;
 }

 logMsLRLand($id, $target, $name, $tName,
 $comName, $tLname, $point, $tPoint);
 # 산이 됨
 $tLand->[$tx][$ty] = $HlandMountain;
 $tLandValue->[$tx][$ty] = 0;
		 if (rand(1000) < 22) {
		 $tLand->[$tx][$ty] = $HlandMonument;
		 $tLandValue->[$tx][$ty] = 75;
		 }
 next;
		 # 경험치
		 if(($tL == $HlandTown) ||
			 ($tL == $HlandMinato) ||
			 ($tL == $HlandOnsen) ||
			 ($tL == $HlandNewtown) ||
			 ($tL == $HlandBigtown)) {
			if(($land->[$bx][$by] == $HlandBase) ||
			($land->[$bx][$by] == $HlandSbase)) {
			# 아직 기지인 경우만
			$landValue->[$bx][$by] += int($tLv / 20);
			if($landValue->[$bx][$by]> $HmaxExpPoint) {
			$landValue->[$bx][$by] = $HmaxExpPoint;
			}
			}
		 logMsLRLand($id, $target, $name, $tName,
		 $comName, $tLname, $point, $tPoint);
		 # 산이 됨
		 $tLand->[$tx][$ty] = $HlandMountain;
		 $tLandValue->[$tx][$ty] = 0;
		 next;
		 } else {
		 # 기타
		 logMsLRLand($id, $target, $name, $tName,
		 $comName, $tLname, $point, $tPoint);
		 # 산이 됨
		 $tland->[$tx][$ty] = $HlandMountain;
 		 $tlandValue->[$tx][$ty] = 0;

		 if (rand(1000) < 20) {
		 $tland->[$tx][$ty] = $HlandMonument;
		 $tlandValue->[$tx][$ty] = 75;
		 }

		 next;
		 }


		} elsif($kind == $HcomMissileSS) {
			logMsSS($id, $target, $name, $tName,
				 $comName, $tLname, $point, $tPoint);
		wideDamageli($target, $tName, $tLand, $tLandValue, $tx, $ty);

		} elsif($kind == $HcomMissileLD) {
		 # 육지 파괴탄
		 if(($tL == $HlandMountain) ||
		 ($tL == $HlandOnsen) ||
		 ($tL == $HlandGold)) {
			# 산(황무지가 됨)
			logMsLDMountain($id, $target, $name, $tName,
					 $comName, $tLname, $point, $tPoint);
			# 황무지가 됨
			$tLand->[$tx][$ty] = $HlandWaste;
			$tLandValue->[$tx][$ty] = 0;
			next;

		 } elsif(($tL == $HlandSbase) ||
			 ($tL == $HlandFune) ||
			 ($tL == $HlandFrocity) ||
			 ($tL == $HlandUmiamu) ||
			 ($tL == $HlandSeatown) ||
			 ($tL == $HlandUmishuto) ||
		 ($tL == $HlandSeacity)) {
			# 해저 기지 해저 도시
			logMsLDSbase($id, $target, $name, $tName,
				 $comName, $tLname, $point, $tPoint);
		 } elsif($tL == $HlandMonster) {
			# 괴수
			logMsLDMonster($id, $target, $name, $tName,
					$comName, $tLname, $point, $tPoint);
		 } elsif($tL == $HlandRottenSea) {
			# 괴수
			logMsLDSeaRotten($id, $target, $name, $tName,
					$comName, $tLname, $point, $tPoint);
		 } elsif(($tL == $HlandSea) ||
			 ($tL == $HlandIce)) {
			# 얕은 바다
			logMsLDSea1($id, $target, $name, $tName,
				 $comName, $tLname, $point, $tPoint);
		 } else {
			# 기타
			logMsLDLand($id, $target, $name, $tName,
				 $comName, $tLname, $point, $tPoint);
		 }

		 # 경험치
		 if(($tL == $HlandTown) ||
			 ($tL == $HlandMinato) ||
			 ($tL == $HlandNewtown) ||
			 ($tL == $HlandBigtown)) {
			if(($land->[$bx][$by] == $HlandBase) ||
			 ($land->[$bx][$by] == $HlandSbase)) {
			 # 아직 기지인 경우만
			 $landValue->[$bx][$by] += int($tLv / 20);
			 if($landValue->[$bx][$by]> $HmaxExpPoint) {
				$landValue->[$bx][$by] = $HmaxExpPoint;
			 }
			}
		 }

		 # 얕은 바다가 됨
		 $tLand->[$tx][$ty] = $HlandSea;
		 $tIsland->{'area'}--;
		 $tLandValue->[$tx][$ty] = 1;

		 # 유전, 얕은 바다, 해저 기지라면 바다로
		 if(($tL == $HlandOil) ||
			($tL == $HlandSea) ||
			($tL == $HlandIce) ||
			($tL == $HlandSeacity) ||
			($tL == $HlandSeatown) ||
			($tL == $HlandUmishuto) ||
			($tL == $HlandFune) ||
			($tL == $HlandFrocity) ||
			($tL == $HlandUmiamu) ||
		 ($tL == $HlandSbase)) {
			$tLandValue->[$tx][$ty] = 0;
		 }
		} else {
		 # 기타 미사일
		 if($tL == $HlandWaste) {
			# 황무지(피해없음)
			if($kind == $HcomMissileST) {
			$mukou++;
			} else {
			$mukou++;
			}
		 } elsif($tL == $HlandRottenSea) {
			if($kind == $HcomMissileST) {
			 # 스텔스
			 logMsNormalSRotten($id, $target, $name, $tName,
					 $comName, $tLname, $point, $tPoint);
			} else {
			 # 일반
			 logMsNormalRotten($id, $target, $name, $tName,
					$comName, $tLname, $point, $tPoint);
			}
		 } elsif($tL == $HlandMonster) {
			# 괴수
			my($mKind, $mName, $mHp) = monsterSpec($tLv);
			my($special) = $HmonsterSpecial[$mKind];

			# 경화 중?
			if((($special == 3) && (($HislandTurn % 2) == 1)) ||
 (($special == 8) && ((seqnum($HislandTurn) % 2) == 0)) ||
			 (($special == 4) && (($HislandTurn % 2) == 0))) {
			 # 경화 중
			 if($kind == $HcomMissileST) {
				# 스텔스
				$kaijumukou++;
			 } else {
				# 일반탄
				$kaijumukou++;
			 }
			 next;
			} else {
			 # 경화 중이 아님
			 if(($special == 5 && random(1000)+$island->{'co4'}*100+$island->{'co99'}*100 < $HmonsterDefence) ||
				($mKind == 15 && random(1000)+$island->{'co4'}*100+$island->{'co99'}*100 < $HmonsterDefence)) {
			 if($kind == $HcomMissileST) {
				$kaijumukou++;
			 } else{
				$kaijumukou++;
			 }
			 next;
			 }elsif(($mKind == 13 && random(1000)+$island->{'co4'}*100+$island->{'co99'}*100 < 900) ||
				 ($mKind == 20 && random(1000)+$island->{'co4'}*100+$island->{'co99'}*100 < 800) ||
				 ($mKind == 21 && random(1000)+$island->{'co4'}*100+$island->{'co99'}*100 < 700) ||
				 ($mKind == 22 && random(1000)+$island->{'co4'}*100+$island->{'co99'}*100 < 750) ||
				 ($mKind == 18 && random(1000)+$island->{'co4'}*100+$island->{'co99'}*100 < (600+random(400))) ||
				 ($mKind == 30 && random(1000)+$island->{'co4'}*100+$island->{'co99'}*100 < (950+random(50))) ||
				 ($mKind == 19 && random(1000)+$island->{'co4'}*100+$island->{'co99'}*100 < (666+random(400)))) {
			 if($kind == $HcomMissileST) {
				$kaijumukou++;
			 } else{
				$kaijumukou++;
			 }
			 next;
			 }elsif($mKind == 14 && random(1000)+$island->{'co4'}*100+$island->{'co99'}*100 < 400){
			 if($kind == $HcomMissileST) {
				$kaijumukou++;
			 } else{
				$kaijumukou++;
			 }
			 next;
			 }elsif($mKind == 17 && random(1000)+$island->{'co4'}*100+$island->{'co99'}*100 < (400+random(500))){
			 if($kind == $HcomMissileST) {
				$kaijumukou++;
			 } else{
				$kaijumukou++;
			 }
			 next;
			 }
			 if($mHp == 1) {
				# 괴수를 처치했습니다
				if(($land->[$bx][$by] == $HlandBase) ||
				 ($land->[$bx][$by] == $HlandSbase)) {
				 # 경험치
				 $landValue->[$bx][$by] += $HmonsterExp[$mKind];
				 if($landValue->[$bx][$by]> $HmaxExpPoint) {
					$landValue->[$bx][$by] = $HmaxExpPoint;
				 }
				}

 if ($mKind == 8) { # 오무라면
 # 오염된 바다발생
 my($point) = "($tx, $ty)";
 logRottenSeaBorn($id, $name, $point);
 $tLand->[$tx][$ty] = $HlandRottenSea;
 $tLandValue->[$tx][$ty] = 1;
 next;
 }

				if($kind == $HcomMissileST) {
				 # 스텔스
				 logMsMonKillS($id, $target, $name, $tName,
						 $comName, $mName, $point,
						 $tPoint);
				} else {
				 # 일반
				 logMsMonKill($id, $target, $name, $tName,
						 $comName, $mName, $point,
						 $tPoint);
				}

				# 수입
				my($value) = $HmonsterValue[$mKind];
				if($value> 0) {
				 $tIsland->{'money'} += $value;
				 logMsMonMoney($target, $mName, $value);

	 if($island->{'sin'}> 0) {
	 my($value, $str);
	 $value = $HmonsterValue[$mKind] + random(101);
	 $island->{'money'} += $value;
	 $str = "$value$HunitMoney";
	 # 수입 로그
	 logSinMoney($id, $name, $str);
	 }
	 if($island->{'jin'}> 0) {
	 my($value, $str);
	 $value = $HmonsterValue[$mKind] + random(101);
	 $island->{'money'} += $value;
	 $str = "$value$HunitMoney";
	 # 수입 로그
	 logJinMoney($id, $name, $str);
	 }

				}

 # 괴수퇴치 수
 $island->{'taiji'}++;

				# 수상 관계
				my($prize) = $island->{'prize'};
				$prize =~ /([0-9]*),([0-9]*),(.*)/;
				my($flags) = $1;
				my($monsters) = $2;
				my($turns) = $3;
				my($v) = 2 ** $mKind;
				$monsters |= $v;
				$island->{'prize'} = "$flags,$monsters,$turns";
			 } else {
				# 괴수살아하고 있는
				if($kind == $HcomMissileST) {
				 # 스텔스
					$kaijuhit++;
				} else {
				 # 일반
					$kaijuhit++;
				}
				# HP 가 1 감소
				$tLandValue->[$tx][$ty]--;
				next;
			 }

			}
		 } else {
			# 일반 지형
			if($kind == $HcomMissileST) {
			 # 스텔스
			 logMsNormalS($id, $target, $name, $tName,
					 $comName, $tLname, $point,
					 $tPoint);
			} else {
			 # 일반
			 logMsNormal($id, $target, $name, $tName,
					 $comName, $tLname, $point,
					 $tPoint);
			}
		 }
		 # 경험치
		 if(($tL == $HlandTown) ||
			($tL == $HlandMinato) ||
			($tL == $HlandNewtown) ||
			($tL == $HlandBigtown)) {
			if(($land->[$bx][$by] == $HlandBase) ||
			 ($land->[$bx][$by] == $HlandSbase)) {
			 $landValue->[$bx][$by] += int($tLv / 20);
			 $boat += $tLv; # 일반 미사일이므로 난민에플러스
			 if($landValue->[$bx][$by]> $HmaxExpPoint) {
				$landValue->[$bx][$by] = $HmaxExpPoint;
			 }
			}
		 }

 # 황무지가 됨
		 $tLand->[$tx][$ty] = $HlandWaste;
		 $tLandValue->[$tx][$ty] = 1; # 착탄점

		 my($mKind, $mName, $mHp) = monsterSpec($tLv);
		 my($special) = $HmonsterSpecial[$mKind];
		 if(($mKind == 17) && ($tL == $HlandMonster)) {
			$tLand->[$tx][$ty] = $HlandMonument;
			$tLandValue->[$tx][$ty] = 86;
		 }

		 if(($tLv == 25) && ($tL == $HlandMonument) && (random(10000) < $island->{'rena'}) && ($island->{'rena'}> 2000)) {
		 $kind = random($HmonsterLevel4) + 1;
		 $lv = $lv = ($kind << 4)
			+ $HmonsterBHP[$kind] + random($HmonsterDHP[$kind]);
		 $tLand->[$tx][$ty] = $HlandMonster;
		 $tLandValue->[$tx][$ty] = $lv;
		 # 괴수 정보
		 my($mKind, $mName, $mHp) = monsterSpec($lv);

		 # 메시지
		 logMonsComemagic($id, $name, $mName, "($bx, $by)", $lName);
		 }

		 # 유전이라면 바다로
		 if(($tL == $HlandOil) ||
		 ($tL == $HlandFrocity) ||
		 ($tL == $HlandFune)) {
			$tLand->[$tx][$ty] = $HlandSea;
			$tLandValue->[$tx][$ty] = 0;
		 }
 # 양식장이면 얕은 바다
 if($tL == $HlandNursery) {
 $tLand->[$tx][$ty] = $HlandSea;
 $tLandValue->[$tx][$ty] = 1;
 }
 if($tL == $HlandIce) {
 $tLand->[$tx][$ty] = $HlandSea;
 $tLandValue->[$tx][$ty] = 1;
 }
 if($tL == $HlandOnsen) {
 $tLand->[$tx][$ty] = $HlandMountain;
 $tLandValue->[$tx][$ty] = 0;
 }
		}
	 }

	 # 카운트 증가
	 $count++;
	}
	 # 로그
		if($kind == $HcomMissileST) {
			 # 스텔스
		logMsTotalS($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint, $total, $mukou, $bouei, $kaijumukou, $kaijuhit, $fuhatu);

		} else {
			 # 일반
		logMsTotal($id, $target, $name, $tName, $comName, $tLname, $point, $tPoint, $total, $mukou, $bouei, $kaijumukou, $kaijuhit, $fuhatu);

			}

	if($flag == 0) {
	 # 기지가 하나도 없어진 경우
	 logMsNoBase($id, $name, $comName);
	 return 0;
	}

	# 난민판정
	$boat = int($boat / 2);
	if(($boat> 0) && ($id != $target) && ($kind != $HcomMissileST)) {
	 # 난민표착
	 my($achive); # 도달난민
	 my($i);
	 for($i = 0; ($i < $HpointNumber && $boat> 0); $i++) {
		$bx = $Hrpx[$i];
		$by = $Hrpy[$i];
		if($land->[$bx][$by] == $HlandTown) {
		 # 읍의 경우
		 my($lv) = $landValue->[$bx][$by];
		 if($boat> 50) {
			$lv += 50;
			$boat -= 50;
			$achive += 50;
		 } else {
			$lv += $boat;
			$achive += $boat;
			$boat = 0;
		 }
		 if($lv> 200) {
			$boat += ($lv - 200);
			$achive -= ($lv - 200);
			$lv = 200;
		 }
		 $landValue->[$bx][$by] = $lv;
		} elsif($land->[$bx][$by] == $HlandPlains) {
		 # 평지의 경우
		 $land->[$bx][$by] = $HlandTown;;
		 if($boat> 10) {
			$landValue->[$bx][$by] = 5;
			$boat -= 10;
			$achive += 10;
		 } elsif($boat> 5) {
			$landValue->[$bx][$by] = $boat - 5;
			$achive += $boat;
			$boat = 0;
		 }
		}
		if($boat <= 0) {
		 last;
		}
	 }
	 if($achive> 0) {
		# 조금이라도 도착한 경우 로그를 출력
		logMsBoatPeople($id, $name, $achive);

		# 난민의 수가일정수이상라면, 평화상의 가능성있음
		if($achive>= 200) {
		 my($prize) = $island->{'prize'};
		 $prize =~ /([0-9]*),([0-9]*),(.*)/;
		 my($flags) = $1;
		 my($monsters) = $2;
		 my($turns) = $3;

		 if((!($flags & 8)) && $achive>= 200){
			$flags |= 8;
			logPrize($id, $name, $Hprize[4]);
		 } elsif((!($flags & 16)) && $achive> 500){
			$flags |= 16;
			logPrize($id, $name, $Hprize[5]);
		 } elsif((!($flags & 32)) && $achive> 800){
			$flags |= 32;
			logPrize($id, $name, $Hprize[6]);
		 }
		 $island->{'prize'} = "$flags,$monsters,$turns";
		}
	 }
	}
	return 1;
 } elsif($kind == $HcomSendMonster) {
	if($island->{'shouhi'}> $island->{'ene'}) {
	 logMsNoEne($id, $name, $comName);
	 return 0;
	}
	# 괴수 파견
	# 대상 가져오기
	my($tn) = $HidToNumber{$target};
	my($tIsland) = $Hislands[$tn];
	my($tName) = $tIsland->{'name'};

	if($tn eq '') {
	 # 대상이 이미 없음
	 logMsNoTarget($id, $name, $comName);
	 return 0;
	}

 # 자기 섬의 인구가 적거나, 대상 섬의 인구가 적으면, 실행은 허가되지 않는
 if (($island->{'pop'} < $HguardPop) || ($tIsland->{'pop'} < $HguardPop)) {
 logForbidden($id, $name, $comName);
 return 0;
 }

	$etc7 = $island->{'etc7'};
	$etc7 =~ /^([0-9]*),([0-9]*),([0-9]*)$/;
	($msjotai, $nokotan, $msid) = ($1, $2, $3);
	if(($msjotai != 2) ||
	 ($tIsland->{'id'} != $msid)) {
		logNiwaren3($id, $name, $comName);
		return 0;
 }

 if ($arg> 30) {
 $arg = 30;
 }

	$kind = $arg;
	$lv = ($kind << 4)
	 + $HmonsterBHP[$kind] + random($HmonsterDHP[$kind]);
	my($mKind, $mName, $mHp) = monsterSpec($lv);

		if($lovePeace == 1) {

		 $etc6 = $island->{'etc6'};
		 $etc6 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		 ($z0,$z1,$z2,$z3,$z4,$z5,$z6,$z7,$z8,$z9,$z10,$z11,$z12,$z13,$z14,$z15,$z16,$z17,$z18,$z19,$z20,$z21,$z22,$z23,$z24,$z25,$z26,$z27,$z28,$z29,$z30) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);
		 ($z->{'0'},$z->{'1'},$z->{'2'},$z->{'3'},$z->{'4'},$z->{'5'},$z->{'6'},$z->{'7'},$z->{'8'},$z->{'9'},$z->{'10'},$z->{'11'},$z->{'12'},$z->{'13'},$z->{'14'},$z->{'15'},$z->{'16'},$z->{'17'},$z->{'18'},$z->{'19'},$z->{'20'},$z->{'21'},$z->{'22'},$z->{'23'},$z->{'24'},$z->{'25'},$z->{'26'},$z->{'27'},$z->{'28'},$z->{'29'},$z->{'30'}) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);

		 $etc6t = $tIsland->{'etc6'};
		 $etc6t =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		 ($z0t,$z1t,$z2t,$z3t,$z4t,$z5t,$z6t,$z7t,$z8t,$z9t,$z10t,$z11t,$z12t,$z13t,$z14t,$z15t,$z16t,$z17t,$z18t,$z19t,$z20t,$z21t,$z22t,$z23t,$z24t,$z25t,$z26t,$z27t,$z28t,$z29t,$z30t) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);
		 ($zt->{'0'},$zt->{'1'},$zt->{'2'},$zt->{'3'},$zt->{'4'},$zt->{'5'},$zt->{'6'},$zt->{'7'},$zt->{'8'},$zt->{'9'},$zt->{'10'},$zt->{'11'},$zt->{'12'},$zt->{'13'},$zt->{'14'},$zt->{'15'},$zt->{'16'},$zt->{'17'},$zt->{'18'},$zt->{'19'},$zt->{'20'},$zt->{'21'},$zt->{'22'},$zt->{'23'},$zt->{'24'},$zt->{'25'},$zt->{'26'},$zt->{'27'},$zt->{'28'},$zt->{'29'},$zt->{'30'}) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);

		 $eisei5 = $island->{'eisei5'};
		 $eisei5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		 ($mshp, $msap, $msdp, $mssp, $mswin, $msexe, $tetsub) = ($1, $2, $3, $4, $5, $6, $7);

		 $eisei5t = $tIsland->{'eisei5'};
		 $eisei5t =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		 ($mshpt, $msapt, $msdpt, $msspt, $mswint, $msexet, $tetsubt) = ($1, $2, $3, $4, $5, $6, $7);

		 $tradeexe = $HmonsterExp[$arg] * 2;

	 if (($z->{"$arg"}> 0) && ($tIsland->{'zoo'}> 0) && ($msexet> $tradeexe) && ($tIsland->{'rena'}> $arg*500)) {
			$z->{"$arg"} -= 1;
			$zt->{"$arg"} += 1;
			$island->{'etc6'} = "$z->{'0'},$z->{'1'},$z->{'2'},$z->{'3'},$z->{'4'},$z->{'5'},$z->{'6'},$z->{'7'},$z->{'8'},$z->{'9'},$z->{'10'},$z->{'11'},$z->{'12'},$z->{'13'},$z->{'14'},$z->{'15'},$z->{'16'},$z->{'17'},$z->{'18'},$z->{'19'},$z->{'20'},$z->{'21'},$z->{'22'},$z->{'23'},$z->{'24'},$z->{'25'},$z->{'26'},$z->{'27'},$z->{'28'},$z->{'29'},$z->{'30'}";
			$tIsland->{'etc6'} = "$zt->{'0'},$zt->{'1'},$zt->{'2'},$zt->{'3'},$zt->{'4'},$zt->{'5'},$zt->{'6'},$zt->{'7'},$zt->{'8'},$zt->{'9'},$zt->{'10'},$zt->{'11'},$zt->{'12'},$zt->{'13'},$zt->{'14'},$zt->{'15'},$zt->{'16'},$zt->{'17'},$zt->{'18'},$zt->{'19'},$zt->{'20'},$zt->{'21'},$zt->{'22'},$zt->{'23'},$zt->{'24'},$zt->{'25'},$zt->{'26'},$zt->{'27'},$zt->{'28'},$zt->{'29'},$zt->{'30'}";

			$msexe += $tradeexe;
			$msexet -= $tradeexe;
			$island->{'eisei5'} = "$mshp,$msap,$msdp,$mssp,$mswin,$msexe,$tetsub";
			$tIsland->{'eisei5'} = "$mshpt,$msapt,$msdpt,$msspt,$mswint,$msexet,$tetsubt";

			$cost *= $arg;
			$island->{'money'} += $cost;
			$tIsland->{'money'} -= $cost;

			logMonsSend2($id, $target, $name, $tName, $mName);

		 } else {
			logNoMoney2($id, $name, $comName);
			return 0;
		 }


	 } else {

		 $etc6 = $island->{'etc6'};
		 $etc6 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		 ($z0,$z1,$z2,$z3,$z4,$z5,$z6,$z7,$z8,$z9,$z10,$z11,$z12,$z13,$z14,$z15,$z16,$z17,$z18,$z19,$z20,$z21,$z22,$z23,$z24,$z25,$z26,$z27,$z28,$z29,$z30) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);
		 ($z->{'0'},$z->{'1'},$z->{'2'},$z->{'3'},$z->{'4'},$z->{'5'},$z->{'6'},$z->{'7'},$z->{'8'},$z->{'9'},$z->{'10'},$z->{'11'},$z->{'12'},$z->{'13'},$z->{'14'},$z->{'15'},$z->{'16'},$z->{'17'},$z->{'18'},$z->{'19'},$z->{'20'},$z->{'21'},$z->{'22'},$z->{'23'},$z->{'24'},$z->{'25'},$z->{'26'},$z->{'27'},$z->{'28'},$z->{'29'},$z->{'30'}) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);

	 if ($z->{"$arg"}> 0) {
			$z->{"$arg"} -= 1;
			$island->{'etc6'} = "$z->{'0'},$z->{'1'},$z->{'2'},$z->{'3'},$z->{'4'},$z->{'5'},$z->{'6'},$z->{'7'},$z->{'8'},$z->{'9'},$z->{'10'},$z->{'11'},$z->{'12'},$z->{'13'},$z->{'14'},$z->{'15'},$z->{'16'},$z->{'17'},$z->{'18'},$z->{'19'},$z->{'20'},$z->{'21'},$z->{'22'},$z->{'23'},$z->{'24'},$z->{'25'},$z->{'26'},$z->{'27'},$z->{'28'},$z->{'29'},$z->{'30'}";
		 }

		$tIsland->{'monstersend'}++;
		$tIsland->{'monstersendkind'} = $arg;

		$cost *= $arg;
		$island->{'money'} -= $cost;

		# 메시지
		logMonsSend($id, $target, $name, $tName, $mName);

	 }

	return 1;
 } elsif($kind == $HcomTaishi) {
	# 대사 파견
	# 대상 가져오기
	my($tn) = $HidToNumber{$target};
	my($tIsland) = $Hislands[$tn];
	my($tName) = $tIsland->{'name'};
	my($tLand) = $tIsland->{'land'};
	my($tLandValue) = $tIsland->{'landValue'};
	my($tx, $ty, $err);

	if($tn eq '') {
	 # 대상이 이미 없음
	 logMsNoTarget($id, $name, $comName);
	 return 0;
	}

	if($island->{'id'}> 4090) {
	 # 대상이큰
 logForbidden($id, $name, $comName);
	 return 0;
	}

 # 자기 섬의 인구가 적거나, 대상 섬의 인구가 적으면, 실행은 허가되지 않는
 if (($island->{'pop'} < $HguardPop) || ($tIsland->{'pop'} < $HguardPop)) {
 logForbidden($id, $name, $comName);
 return 0;
 }

 # 동일 id 이면, 실행은 허가되지 않는
 if ($island->{'id'} == $tIsland->{'id'}) {
 logForbidden($id, $name, $comName);
 return 0;
 }

 # 자기 섬의 인구가 적거나, 대상 섬의 인구가 적으면, 실행은 허가되지 않는
 if ($tIsland->{'tai'}> 2) {
 logForbidden($id, $name, $comName);
 return 0;
 }

	$etc7 = $island->{'etc7'};
	$etc7 =~ /^([0-9]*),([0-9]*),([0-9]*)$/;
	($msjotai, $nokotan, $msid) = ($1, $2, $3);

	if(($lovePeace == 1) &&
	 ($msjotai != 2) &&
	 ($tIsland->{'id'} != $msid)) {
 logForbidden($id, $name, $comName);
 return 0;
 }

	$tx = $x;
	$ty = $y;
	if((($ty % 2) == 0) && (($y % 2) == 1)) {
	 $tx--;
	}

	# 착탄점범위안팎 확인
	if(($tx < 0) || ($tx>= $HislandSize) ||
	 ($ty < 0) || ($ty>= $HislandSize)) {
	 next;
	}

	# 착탄점의 지형등 산출
	my($tL) = $tLand->[$tx][$ty];
	my($tLv) = $tLandValue->[$tx][$ty];
	my($tLname) = landName($tL, $tLv);
	my($tPoint) = "($tx, $ty)";
	$id = $island->{'id'};

	if($tL != $HlandPlains) {
	 logLandFail($id, $name, $comName, $tLname, $tPoint);
	 return 0;
	}

 $tLand->[$tx][$ty] = $HlandTaishi;
 $tLandValue->[$tx][$ty] = $id;

	logTaishi($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint);

	$island->{'money'} -= $cost;
	return 1;

 } elsif($kind == $HcomMagic) {

	if($island->{'shouhi'}> $island->{'ene'}) {
	 logMsNoEne($id, $name, $comName);
	 return 0;
	}

	# 마술사 파견
	# 대상 가져오기
	my($tn) = $HidToNumber{$target};
	my($tIsland) = $Hislands[$tn];
	my($tName) = $tIsland->{'name'};
	my($tLand) = $tIsland->{'land'};
	my($tLandValue) = $tIsland->{'landValue'};
	my($tx, $ty, $err);

	$etc9 = $island->{'etc9'};
	$etc9 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	($co7, $magicf, $magici, $magica, $magicw, $magicl, $magicd) = ($1, $2, $3, $4, $5, $6, $7);

	if($tn eq '') {
	 # 대상이 이미 없음
	 logMsNoTarget($id, $name, $comName);
	 return 0;
	}

	if($co7 == 0) {
	 logMagicNoTarget($id, $name, $comName);
	 return 0;
	}

	$tx = $x;
	$ty = $y;
	if((($ty % 2) == 0) && (($y % 2) == 1)) {
	 $tx--;
	}

	# 착탄점범위안팎 확인
	if(($tx < 0) || ($tx>= $HislandSize) ||
	 ($ty < 0) || ($ty>= $HislandSize)) {
	 next;
	}

	# 착탄점의 지형등 산출
	my($tL) = $tLand->[$tx][$ty];
	my($tLv) = $tLandValue->[$tx][$ty];
	my($tLname) = landName($tL, $tLv);
	my($tPoint) = "($tx, $ty)";
	$id = $island->{'id'};

	if($arg>= 8) {
	 $arg = 0;
	}
	 if($arg == 0) {
		$t = "불 계열 마술사 파견";
	 }
	 if($arg == 1) {
		$t = "얼음계 마술사 파견";
	 }
	 if($arg == 2) {
		$t = "땅 계열 마술사 파견";
	 }
	 if($arg == 3) {
		$t = "바람 계열 마술사 파견";
	 }
	 if($arg == 4) {
		$t = "빛 계열마술사 파견";
	 }
	 if($arg == 5) {
		$t = "어둠 계열마술사 파견";
	 }
	 if($arg == 6) {
		$t = "천공성포격";
	 }
	 if($arg == 7) {
		$t = "동물원 사육·육성 관련 파견";
	 }

 if ($island->{'id'} == $tIsland->{'id'}) {

		if($tL == $HlandMonster) {

			logTaishi2($id, $tIsland->{'id'}, $name, $tName, $comName, $tLname, $point, $tPoint, $t);

		 if(($arg == 0)&&($island->{'ene'}> 4000+$magicf*400)) {
			# 대상이 되는 괴수각 요소 꺼내기
				my($tKind, $tName, $tHp) = monsterSpec($landValue->[$tx][$ty]);
				my($tlv) = $landValue->[$tx][$ty];
				my($tspecial) = $HmonsterSpecial[$tKind];
				$dpoint = $magicf;
			 $island->{'shouhi'} += 4000+$magicf*400;
			 $island->{'money'} -= $cost;
			 logIreAttackt2($id, $name, "불 계열 마술사", "작열의 불꽃", $dpoint, $tName, $tPoint);

			 $tHp -= $dpoint;
			 $tlv -= $dpoint;
				$landValue->[$tx][$ty] = $tlv;
			 if($tHp < 1){
			 # 대상의 괴수가 쓰러져 황무지가 됨
				$land->[$tx][$ty] = $HlandWaste;
				$landValue->[$tx][$ty] = 0;
			 # 포상금
				my($value) = $HmonsterValue[$tKind];
				 $island->{'money'} += $value;
				 logMsMonMoney($id, $tName, $value);
 # 괴수퇴치 수
 $island->{'taiji'}++;

				# 수상 관계
				my($prize) = $island->{'prize'};
				$prize =~ /([0-9]*),([0-9]*),(.*)/;
				my($flags) = $1;
				my($monsters) = $2;
				my($turns) = $3;
				my($v) = 2 ** $tKind;
				$monsters |= $v;
				$island->{'prize'} = "$flags,$monsters,$turns";
				}
			 next;
		 }
		 if(($arg == 1)&&($island->{'ene'}> 6000+$magici*500)) {
			# 대상이 되는 괴수각 요소 꺼내기
				my($tKind, $tName, $tHp) = monsterSpec($landValue->[$tx][$ty]);
				my($tlv) = $landValue->[$tx][$ty];
				my($tspecial) = $HmonsterSpecial[$tKind];
				$dpoint = $magici+random($magici);
			 $island->{'shouhi'} += 6000+$magici*500;
			 $island->{'money'} -= $cost;
			 logIreAttackt2($id, $name, "얼음계 마술사", "아이시클 애로우", $dpoint, $tName, $tPoint);

			 $tHp -= $dpoint;
			 $tlv -= $dpoint;
				$landValue->[$tx][$ty] = $tlv;
			 if($tHp < 1){
			 # 대상의 괴수가 쓰러져 황무지가 됨
				$land->[$tx][$ty] = $HlandIce;
				$landValue->[$tx][$ty] = 0;
			 # 포상금
				my($value) = $HmonsterValue[$tKind];
				 $island->{'money'} += $value;
				 logMsMonMoney($id, $tName, $value);
 # 괴수퇴치 수
 $island->{'taiji'}++;

				# 수상 관계
				my($prize) = $island->{'prize'};
				$prize =~ /([0-9]*),([0-9]*),(.*)/;
				my($flags) = $1;
				my($monsters) = $2;
				my($turns) = $3;
				my($v) = 2 ** $tKind;
				$monsters |= $v;
				$island->{'prize'} = "$flags,$monsters,$turns";
				}
			 next;
		 }
		 if(($arg == 2)&&($island->{'ene'}> 10000)) {
			# 대상이 되는 괴수각 요소 꺼내기
				my($tKind, $tName, $tHp) = monsterSpec($landValue->[$tx][$ty]);
				my($tlv) = $landValue->[$tx][$ty];
				my($tspecial) = $HmonsterSpecial[$tKind];
				$dpoint = $magica*2;
			 $island->{'shouhi'} += 10000;
			 $island->{'money'} -= $cost;
			 logIreAttackt2($id, $name, "땅 계열 마술사", "아스퀘이크", $dpoint, $tName, $tPoint);

			 $tHp -= $dpoint;
			 $tlv -= $dpoint;
				$landValue->[$tx][$ty] = $tlv;
			 if($tHp < 1){
			 # 대상의 괴수가 쓰러져 황무지가 됨
				$land->[$tx][$ty] = $HlandMountain;
				$landValue->[$tx][$ty] = 0;
			 # 포상금
				my($value) = $HmonsterValue[$tKind];
				 $island->{'money'} += $value;
				 logMsMonMoney($id, $tName, $value);
 # 괴수퇴치 수
 $island->{'taiji'}++;

				# 수상 관계
				my($prize) = $island->{'prize'};
				$prize =~ /([0-9]*),([0-9]*),(.*)/;
				my($flags) = $1;
				my($monsters) = $2;
				my($turns) = $3;
				my($v) = 2 ** $tKind;
				$monsters |= $v;
				$island->{'prize'} = "$flags,$monsters,$turns";
				}
			 next;
		 }
		 if(($arg == 3)&&($island->{'ene'}> 1000+$magicw*1000)) {
			# 대상이 되는 괴수각 요소 꺼내기
				my($tKind, $tName, $tHp) = monsterSpec($landValue->[$tx][$ty]);
				my($tlv) = $landValue->[$tx][$ty];
				my($tspecial) = $HmonsterSpecial[$tKind];
				$dpoint = random($magicw*2);
			 $island->{'shouhi'} += 1000+$magicw*1000;
			 $island->{'money'} -= $cost;
			 logIreAttackt2($id, $name, "바람 계열 마술사", "질풍바람의 칼날", $dpoint, $tName, $tPoint);

			 $tHp -= $dpoint;
			 $tlv -= $dpoint;
				$landValue->[$tx][$ty] = $tlv;
			 if($tHp < 1){
			 # 대상의 괴수가 쓰러져 황무지가 됨
				$land->[$tx][$ty] = $HlandWaste;
				$landValue->[$tx][$ty] = 0;
			 # 포상금
				my($value) = $HmonsterValue[$tKind];
				 $island->{'money'} += $value;
				 logMsMonMoney($id, $tName, $value);
 # 괴수퇴치 수
 $island->{'taiji'}++;

				# 수상 관계
				my($prize) = $island->{'prize'};
				$prize =~ /([0-9]*),([0-9]*),(.*)/;
				my($flags) = $1;
				my($monsters) = $2;
				my($turns) = $3;
				my($v) = 2 ** $tKind;
				$monsters |= $v;
				$island->{'prize'} = "$flags,$monsters,$turns";
				}
			 next;
		 }
		 if(($arg == 4)&&($island->{'ene'}> 10000)) {
			# 대상이 되는 괴수각 요소 꺼내기
				my($tKind, $tName, $tHp) = monsterSpec($landValue->[$tx][$ty]);
				my($tlv) = $landValue->[$tx][$ty];
				my($tspecial) = $HmonsterSpecial[$tKind];
				$dpoint = random($magicl*4);
			 $island->{'shouhi'} += 10000;
			 $island->{'money'} -= $cost;
			 logIreAttackt2($id, $name, "빛 계열마술사", "라이트닝 볼트", $dpoint, $tName, $tPoint);

			 $tHp -= $dpoint;
			 $tlv -= $dpoint;
				$landValue->[$tx][$ty] = $tlv;
			 if($tHp < 1){
			 # 대상의 괴수가 쓰러져 황무지가 됨
				$land->[$tx][$ty] = $HlandWaste;
				$landValue->[$tx][$ty] = 0;
			 # 포상금
				my($value) = $HmonsterValue[$tKind];
				 $island->{'money'} += $value;
				 logMsMonMoney($id, $tName, $value);
 # 괴수퇴치 수
 $island->{'taiji'}++;

				# 수상 관계
				my($prize) = $island->{'prize'};
				$prize =~ /([0-9]*),([0-9]*),(.*)/;
				my($flags) = $1;
				my($monsters) = $2;
				my($turns) = $3;
				my($v) = 2 ** $tKind;
				$monsters |= $v;
				$island->{'prize'} = "$flags,$monsters,$turns";
				}
			 next;
		 }
		 if(($arg == 5)&&($island->{'ene'}> 10000)) {
			# 대상이 되는 괴수각 요소 꺼내기
				my($tKind, $tName, $tHp) = monsterSpec($landValue->[$tx][$ty]);
				my($tlv) = $landValue->[$tx][$ty];
				my($tspecial) = $HmonsterSpecial[$tKind];
				$dpoint = random($magicd*3);
			 $island->{'shouhi'} += 10000;
			 $island->{'money'} -= $cost;
			 logIreAttackt3($id, $name, "어둠 계열마술사", "다크아로", $dpoint, $tName, $tPoint);

			 if(random(100) < $magicd*10){
			 # 대상의 괴수가 쓰러져 황무지가 됨
				$land->[$tx][$ty] = $HlandWaste;
				$landValue->[$tx][$ty] = 0;
			 # 포상금
				my($value) = $HmonsterValue[$tKind];
				 $island->{'money'} += $value;
				 logMsMonMoney($id, $tName, $value);
 # 괴수퇴치 수
 $island->{'taiji'}++;

				# 수상 관계
				my($prize) = $island->{'prize'};
				$prize =~ /([0-9]*),([0-9]*),(.*)/;
				my($flags) = $1;
				my($monsters) = $2;
				my($turns) = $3;
				my($v) = 2 ** $tKind;
				$monsters |= $v;
				$island->{'prize'} = "$flags,$monsters,$turns";
				}
			 next;
		 }
		 if(($arg == 7)&&($island->{'zoo'}> 0)) {

			 my($i,$sx,$sy);
			 my($zlv) = (0);
			 for($i = 0; $i < $HpointNumber; $i++){
				$sx = $Hrpx[$i];
				$sy = $Hrpy[$i];
			 if($land->[$sx][$sy] == $HlandZoo){
				$zlv += $landValue->[$sx][$sy];
			 }
			 }

			$etc6 = $island->{'etc6'};
			$etc6 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
			($z0,$z1,$z2,$z3,$z4,$z5,$z6,$z7,$z8,$z9,$z10,$z11,$z12,$z13,$z14,$z15,$z16,$z17,$z18,$z19,$z20,$z21,$z22,$z23,$z24,$z25,$z26,$z27,$z28,$z29,$z30) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);
			($z->{'0'},$z->{'1'},$z->{'2'},$z->{'3'},$z->{'4'},$z->{'5'},$z->{'6'},$z->{'7'},$z->{'8'},$z->{'9'},$z->{'10'},$z->{'11'},$z->{'12'},$z->{'13'},$z->{'14'},$z->{'15'},$z->{'16'},$z->{'17'},$z->{'18'},$z->{'19'},$z->{'20'},$z->{'21'},$z->{'22'},$z->{'23'},$z->{'24'},$z->{'25'},$z->{'26'},$z->{'27'},$z->{'28'},$z->{'29'},$z->{'30'}) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);

			$zookazu = $z0+$z1+$z2+$z3+$z4+$z5+$z6+$z7+$z8+$z9+$z10+$z11+$z12+$z13+$z14+$z15+$z16+$z17+$z18+$z19+$z20+$z21+$z22+$z23+$z24+$z25+$z26+$z27+$z28+$z29+$z30;

			# 대상이 되는 괴수각 요소 꺼내기
				my($tKind, $tName, $tHp) = monsterSpec($landValue->[$tx][$ty]);
				my($tlv) = $landValue->[$tx][$ty];
				my($tspecial) = $HmonsterSpecial[$tKind];
				$dpoint = random($magicd*3);

				if($tKind*1000+1000> $island->{'ene'}) {
				 $island->{'money'} -= $cost;
				 logMsNoEne2($id, $name, $comName);
				 return 0;
				}

				$island->{'shouhi'} += $tKind*1000;
				$island->{'money'} -= $cost;

				$prize = $island->{'prize'};
				my($flags, $monsters, $turns);
				$prize =~ /([0-9]*),([0-9]*),(.*)/;
				$flags = $1;
				$monsters= $2;
				$turns = $3;
				$prize = '';
				$f = 1;
				for($i = 0; $i < $HmonsterNumber; $i++) {
				 if($monsters & $f) {
					$taiji->{"$i"}++;
				 }
				 $f *= 2;
				}


			 if(($tKind*500*$tHp < $island->{'rena'}+$island->{'co4'}*1000+$island->{'co99'}*1000) && ($taiji->{"$tKind"}> 0)) {


					 if($zlv < $zookazu){

						logIreAttackt7($id, $name, "동물원 사육·육성 관계", "포획 도구", $dpoint, $tName, $tPoint);

					 } else {

					 logIreAttackt5($id, $name, "동물원 사육·육성 관계", "포획 도구", $dpoint, $tName, $tPoint);
					 # 대상의 괴수가 쓰러져 황무지가 됨
						$land->[$tx][$ty] = $HlandWaste;
						$landValue->[$tx][$ty] = 0;

						$etc6 = $island->{'etc6'};
						$etc6 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
						($z0,$z1,$z2,$z3,$z4,$z5,$z6,$z7,$z8,$z9,$z10,$z11,$z12,$z13,$z14,$z15,$z16,$z17,$z18,$z19,$z20,$z21,$z22,$z23,$z24,$z25,$z26,$z27,$z28,$z29,$z30) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);
						($z->{'0'},$z->{'1'},$z->{'2'},$z->{'3'},$z->{'4'},$z->{'5'},$z->{'6'},$z->{'7'},$z->{'8'},$z->{'9'},$z->{'10'},$z->{'11'},$z->{'12'},$z->{'13'},$z->{'14'},$z->{'15'},$z->{'16'},$z->{'17'},$z->{'18'},$z->{'19'},$z->{'20'},$z->{'21'},$z->{'22'},$z->{'23'},$z->{'24'},$z->{'25'},$z->{'26'},$z->{'27'},$z->{'28'},$z->{'29'},$z->{'30'}) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);

						$z->{"$tKind"}++;
						$island->{'etc6'} = "$z->{'0'},$z->{'1'},$z->{'2'},$z->{'3'},$z->{'4'},$z->{'5'},$z->{'6'},$z->{'7'},$z->{'8'},$z->{'9'},$z->{'10'},$z->{'11'},$z->{'12'},$z->{'13'},$z->{'14'},$z->{'15'},$z->{'16'},$z->{'17'},$z->{'18'},$z->{'19'},$z->{'20'},$z->{'21'},$z->{'22'},$z->{'23'},$z->{'24'},$z->{'25'},$z->{'26'},$z->{'27'},$z->{'28'},$z->{'29'},$z->{'30'}";

					 }

				} else {
				logIreAttackt6($id, $name, "동물원 사육·육성 관계", "포획 도구", $dpoint, $tName, $tPoint);
				}
			return 1;
		 }
		}

 } else {
		if(($tL == $HlandPlains)&&($island->{'ene'}> 2000)) {
		 if(($arg == 0)&&($magicf>2)) {
			$tLand->[$tx][$ty] = $HlandMonument;
			$tLandValue->[$tx][$ty] = 96+$arg;
		 }
		 if(($arg == 1)&&($magici>2)) {
			$tLand->[$tx][$ty] = $HlandMonument;
			$tLandValue->[$tx][$ty] = 96+$arg;
		 }
		 if(($arg == 2)&&($magica>2)) {
			$tLand->[$tx][$ty] = $HlandMonument;
			$tLandValue->[$tx][$ty] = 96+$arg;
		 }
		 if(($arg == 3)&&($magicw>2)) {
			$tLand->[$tx][$ty] = $HlandMonument;
			$tLandValue->[$tx][$ty] = 96+$arg;
		 }
		 if(($arg == 4)&&($magicl>2)) {
			$tLand->[$tx][$ty] = $HlandMonument;
			$tLandValue->[$tx][$ty] = 96+$arg;
		 }
		 if(($arg == 5)&&($magicd>2)) {
			$tLand->[$tx][$ty] = $HlandMonument;
			$tLandValue->[$tx][$ty] = 96+$arg;
		 }
		 if(($arg == 6)&&($island->{'h11'}>0)) {
			$tLand->[$tx][$ty] = $HlandMonument;
			$tLandValue->[$tx][$ty] = 100;
		 }
		$island->{'shouhi'} += 2000;
		$island->{'money'} -= $cost;
		}


		if($tL == $HlandRottenSea) {
		 if($arg == 0) {
			logTaishi2($id, $tIsland->{'id'}, $name, $tName, $comName, $tLname, $point, $tPoint, $t);
			$magicshouhiene = 600-$magicf*50;
			$magicnenshoene = 0;
			if($magicshouhiene < 300) {
			$magicshouhiene = 300;
			}
			 for($i = 0; $i < 19; $i++) {
				$sx = $tx + $ax[$i];
				$sy = $ty + $ay[$i];

				# 행 기준 위치 조정
				if((($sy % 2) == 0) && (($ty % 2) == 1)) {
				 $sx--;
				}

				$landKind = $tLand->[$sx][$sy];
				$lv = $tLandValue->[$sx][$sy];
				$landName = landName($landKind, $lv);
				$point = "($sx, $sy)";

				# 범위 밖 판정
				if(($sx < 0) || ($sx>= $HislandSize) ||
				 ($sy < 0) || ($sy>= $HislandSize)) {
				 next;
				}
				if($landKind == $HlandRottenSea) {
				 $tLand->[$sx][$sy] = $HlandWaste;
				 $tLandValue->[$sx][$sy] = 0;
				 $island->{'shouhi'} += $magicshouhiene;
				 $magicnenshoene++;
				}
				if($island->{'shouhi'}> $island->{'ene'}) {
				 $island->{'money'} -= $cost;
				 logIreAttackt4($tIsland->{'id'}, $name, "불 계열 마술사", "작열의 불꽃", $magicnenshoene, "오염된 바다", "불태웠습니다");
				return 1;
				}
			 }
				 $island->{'money'} -= $cost;
				 logIreAttackt4($tIsland->{'id'}, $name, "불 계열 마술사", "작열의 불꽃", $magicnenshoene, "오염된 바다", "불태웠습니다");
				return 1;
		 }
		 if($arg == 4) {
			logTaishi2($id, $tIsland->{'id'}, $name, $tName, $comName, $tLname, $point, $tPoint, $t);
			$magicshouhiene = 700-$magicl*100;
			$magicnenshoene = 0;
			if($magicshouhiene < 500) {
			$magicshouhiene = 500;
			}

			 for($i = 0; $i < $HpointNumber; $i++){
				$sx = $Hrpx[$i];
				$sy = $Hrpy[$i];

				$landKind = $tLand->[$sx][$sy];
				$lv = $tLandValue->[$sx][$sy];
				$landName = landName($landKind, $lv);
				$point = "($sx, $sy)";

				if(($landKind == $HlandRottenSea)&&(random(10) < $magicl)) {
				 $tLand->[$sx][$sy] = $HlandWaste;
				 $tLandValue->[$sx][$sy] = 0;
				 $island->{'shouhi'} += $magicshouhiene;
				 $magicnenshoene++;
				}
				if($island->{'shouhi'}> $island->{'ene'}) {
				 $island->{'money'} -= $cost;
				 logIreAttackt4($tIsland->{'id'}, $name, "빛 계열마술사", "라이트닝 볼트", $magicnenshoene, "오염된 바다", "불태웠습니다");
				return 1;
				}
			 }
				 $island->{'money'} -= $cost;
				 logIreAttackt4($tIsland->{'id'}, $name, "빛 계열마술사", "라이트닝 볼트", $magicnenshoene, "오염된 바다", "불태웠습니다");
				return 1;
		 }
		 if($arg == 5) {
			logTaishi2($id, $tIsland->{'id'}, $name, $tName, $comName, $tLname, $point, $tPoint, $t);
			$magicshouhiene = 200;
			$magicnenshoene = 0;
			if($magicshouhiene < 200) {
			$magicshouhiene = 200;
			}

			 for($i = 0; $i < $HpointNumber; $i++){
				$sx = $Hrpx[$i];
				$sy = $Hrpy[$i];

				$landKind = $tLand->[$sx][$sy];
				$lv = $tLandValue->[$sx][$sy];
				$landName = landName($landKind, $lv);
				$point = "($sx, $sy)";

				if(($landKind == $HlandRottenSea)&&(random(5) < $magicd)) {
				 $tLandValue->[$sx][$sy] += 10+$magicd;
				 $island->{'shouhi'} += $magicshouhiene;
				 $magicnenshoene++;
				}
				if($island->{'shouhi'}> $island->{'ene'}) {
				 $island->{'money'} -= $cost;
				 logIreAttackt4($tIsland->{'id'}, $name, "어둠 계열마술사", "다크아로", $magicnenshoene, "오염된 바다", "노후화하게");
				return 1;
				}
			 }
				 $island->{'money'} -= $cost;
				 logIreAttackt4($tIsland->{'id'}, $name, "어둠 계열마술사", "다크아로", $magicnenshoene, "오염된 바다", "노후화하게");
				return 1;
		 }

		 if($arg == 6) {
			logTaishi2($id, $tIsland->{'id'}, $name, $tName, $comName, $tLname, $point, $tPoint, $t);
			$magicnenshoene = 0;
			 for($i = 0; $i < $HpointNumber; $i++){
				$sx = $Hrpx[$i];
				$sy = $Hrpy[$i];

				$landKind = $tLand->[$sx][$sy];
				$lv = $tLandValue->[$sx][$sy];
				$landName = landName($landKind, $lv);
				$point = "($sx, $sy)";

				if($landKind == $HlandRottenSea) {
				 $tLand->[$sx][$sy] = $HlandWaste;
				 $tLandValue->[$sx][$sy] = 1;
				 $island->{'shouhi'} += random(2500);
				 $magicnenshoene++;
				}
				if($island->{'shouhi'}> $island->{'ene'}) {
				 $island->{'money'} -= $cost;
				 logIreAttackt4($tIsland->{'id'}, $name, "천공성", "하늘의 심판", $magicnenshoene, "오염된 바다", "분출되어 날아감");
				return 1;
				}
			 }
				 $island->{'money'} -= $cost;
				 logIreAttackt4($tIsland->{'id'}, $name, "천공성", "하늘의 심판", $magicnenshoene, "오염된 바다", "분출되어 날아감");
				return 1;
		 }

		}

		if($tL == $HlandMonster) {

		 if(($arg == 0)&&($island->{'ene'}> 4000+$magicf*400)) {
			# 대상이 되는 괴수각 요소 꺼내기
				my($tKind, $tName, $tHp) = monsterSpec($tLandValue->[$tx][$ty]);
				my($tlv) = $tLandValue->[$tx][$ty];
				my($tspecial) = $HmonsterSpecial[$tKind];
				$dpoint = $magicf;
			 $island->{'shouhi'} += 4000+$magicf*400;
			 $island->{'money'} -= $cost;
			 logIreAttackt2($tIsland->{'id'}, $name, "불 계열 마술사", "작열의 불꽃", $dpoint, $tName, $tPoint);

			 $tHp -= $dpoint;
			 $tlv -= $dpoint;
				$tLandValue->[$tx][$ty] = $tlv;
			 if($tHp < 1){
			 # 대상의 괴수가 쓰러져 황무지가 됨
				$tLand->[$tx][$ty] = $HlandWaste;
				$tLandValue->[$tx][$ty] = 0;
			 # 포상금
				my($value) = $HmonsterValue[$tKind];
				 $tIsland->{'money'} += $value;
				 logMsMonMoney($tIsland->{'id'}, $tName, $value);
 # 괴수퇴치 수
 $island->{'taiji'}++;

				# 수상 관계
				my($prize) = $island->{'prize'};
				$prize =~ /([0-9]*),([0-9]*),(.*)/;
				my($flags) = $1;
				my($monsters) = $2;
				my($turns) = $3;
				my($v) = 2 ** $tKind;
				$monsters |= $v;
				$island->{'prize'} = "$flags,$monsters,$turns";
				}
		 }
		 if(($arg == 1)&&($island->{'ene'}> 6000+$magici*500)) {
			# 대상이 되는 괴수각 요소 꺼내기
				my($tKind, $tName, $tHp) = monsterSpec($tLandValue->[$tx][$ty]);
				my($tlv) = $tLandValue->[$tx][$ty];
				my($tspecial) = $HmonsterSpecial[$tKind];
				$dpoint = $magici+random($magici);
			 $island->{'shouhi'} += 6000+$magici*500;
			 $island->{'money'} -= $cost;
			 logIreAttackt2($tIsland->{'id'}, $name, "얼음계 마술사", "아이시클 애로우", $dpoint, $tName, $tPoint);

			 $tHp -= $dpoint;
			 $tlv -= $dpoint;
				$tLandValue->[$tx][$ty] = $tlv;
			 if($tHp < 1){
			 # 대상의 괴수가 쓰러져 황무지가 됨
				$tLand->[$tx][$ty] = $HlandIce;
				$tLandValue->[$tx][$ty] = 0;
			 # 포상금
				my($value) = $HmonsterValue[$tKind];
				 $tIsland->{'money'} += $value;
				 logMsMonMoney($tIsland->{'id'}, $tName, $value);
 # 괴수퇴치 수
 $island->{'taiji'}++;

				# 수상 관계
				my($prize) = $island->{'prize'};
				$prize =~ /([0-9]*),([0-9]*),(.*)/;
				my($flags) = $1;
				my($monsters) = $2;
				my($turns) = $3;
				my($v) = 2 ** $tKind;
				$monsters |= $v;
				$island->{'prize'} = "$flags,$monsters,$turns";
				}
		 }
		 if(($arg == 2)&&($island->{'ene'}> 10000)) {
			# 대상이 되는 괴수각 요소 꺼내기
				my($tKind, $tName, $tHp) = monsterSpec($tLandValue->[$tx][$ty]);
				my($tlv) = $tLandValue->[$tx][$ty];
				my($tspecial) = $HmonsterSpecial[$tKind];
				$dpoint = $magica*2;
			 $island->{'shouhi'} += 10000;
			 $island->{'money'} -= $cost;
			 logIreAttackt2($tIsland->{'id'}, $name, "땅 계열 마술사", "아스퀘이크", $dpoint, $tName, $tPoint);

			 $tHp -= $dpoint;
			 $tlv -= $dpoint;
				$tLandValue->[$tx][$ty] = $tlv;
			 if($tHp < 1){
			 # 대상의 괴수가 쓰러져 황무지가 됨
				$tLand->[$tx][$ty] = $HlandMountain;
				$tLandValue->[$tx][$ty] = 0;
			 # 포상금
				my($value) = $HmonsterValue[$tKind];
				 $tIsland->{'money'} += $value;
				 logMsMonMoney($tIsland->{'id'}, $tName, $value);
 # 괴수퇴치 수
 $island->{'taiji'}++;

				# 수상 관계
				my($prize) = $island->{'prize'};
				$prize =~ /([0-9]*),([0-9]*),(.*)/;
				my($flags) = $1;
				my($monsters) = $2;
				my($turns) = $3;
				my($v) = 2 ** $tKind;
				$monsters |= $v;
				$island->{'prize'} = "$flags,$monsters,$turns";
				}
		 }
		 if(($arg == 3)&&($island->{'ene'}> 1000+$magicw*1000)) {
			# 대상이 되는 괴수각 요소 꺼내기
				my($tKind, $tName, $tHp) = monsterSpec($tLandValue->[$tx][$ty]);
				my($tlv) = $tLandValue->[$tx][$ty];
				my($tspecial) = $HmonsterSpecial[$tKind];
				$dpoint = random($magicw*2);
			 $island->{'shouhi'} += 1000+$magicw*1000;
			 $island->{'money'} -= $cost;
			 logIreAttackt2($tIsland->{'id'}, $name, "바람 계열 마술사", "질풍바람의 칼날", $dpoint, $tName, $tPoint);

			 $tHp -= $dpoint;
			 $tlv -= $dpoint;
				$tLandValue->[$tx][$ty] = $tlv;
			 if($tHp < 1){
			 # 대상의 괴수가 쓰러져 황무지가 됨
				$tLand->[$tx][$ty] = $HlandWaste;
				$tLandValue->[$tx][$ty] = 0;
			 # 포상금
				my($value) = $HmonsterValue[$tKind];
				 $tIsland->{'money'} += $value;
				 logMsMonMoney($tIsland->{'id'}, $tName, $value);
 # 괴수퇴치 수
 $island->{'taiji'}++;

				# 수상 관계
				my($prize) = $island->{'prize'};
				$prize =~ /([0-9]*),([0-9]*),(.*)/;
				my($flags) = $1;
				my($monsters) = $2;
				my($turns) = $3;
				my($v) = 2 ** $tKind;
				$monsters |= $v;
				$island->{'prize'} = "$flags,$monsters,$turns";
				}
		 }
		 if(($arg == 4)&&($island->{'ene'}> 10000)) {
			# 대상이 되는 괴수각 요소 꺼내기
				my($tKind, $tName, $tHp) = monsterSpec($tLandValue->[$tx][$ty]);
				my($tlv) = $tLandValue->[$tx][$ty];
				my($tspecial) = $HmonsterSpecial[$tKind];
				$dpoint = random($magicl*4);
			 $island->{'shouhi'} += 10000;
			 $island->{'money'} -= $cost;
			 logIreAttackt2($tIsland->{'id'}, $name, "빛 계열마술사", "라이트닝 볼트", $dpoint, $tName, $tPoint);

			 $tHp -= $dpoint;
			 $tlv -= $dpoint;
				$tLandValue->[$tx][$ty] = $tlv;
			 if($tHp < 1){
			 # 대상의 괴수가 쓰러져 황무지가 됨
				$tLand->[$tx][$ty] = $HlandWaste;
				$tLandValue->[$tx][$ty] = 0;
			 # 포상금
				my($value) = $HmonsterValue[$tKind];
				 $tIsland->{'money'} += $value;
				 logMsMonMoney($tIsland->{'id'}, $tName, $value);
 # 괴수퇴치 수
 $island->{'taiji'}++;

				# 수상 관계
				my($prize) = $island->{'prize'};
				$prize =~ /([0-9]*),([0-9]*),(.*)/;
				my($flags) = $1;
				my($monsters) = $2;
				my($turns) = $3;
				my($v) = 2 ** $tKind;
				$monsters |= $v;
				$island->{'prize'} = "$flags,$monsters,$turns";
				}
		 }
		 if(($arg == 5)&&($island->{'ene'}> 10000)) {
			# 대상이 되는 괴수각 요소 꺼내기
				my($tKind, $tName, $tHp) = monsterSpec($tLandValue->[$tx][$ty]);
				my($tlv) = $tLandValue->[$tx][$ty];
				my($tspecial) = $HmonsterSpecial[$tKind];
				$dpoint = random($magicd*3);
			 $island->{'shouhi'} += 10000;
			 $island->{'money'} -= $cost;
			 logIreAttackt3($tIsland->{'id'}, $name, "어둠 계열마술사", "다크아로", $dpoint, $tName, $tPoint);

			 if(random(100) < $magicd*10){
			 # 대상의 괴수가 쓰러져 황무지가 됨
				$tLand->[$tx][$ty] = $HlandWaste;
				$tLandValue->[$tx][$ty] = 0;
			 # 포상금
				my($value) = $HmonsterValue[$tKind];
				 $tIsland->{'money'} += $value;
				 logMsMonMoney($tIsland->{'id'}, $tName, $value);
 # 괴수퇴치 수
 $island->{'taiji'}++;

				# 수상 관계
				my($prize) = $island->{'prize'};
				$prize =~ /([0-9]*),([0-9]*),(.*)/;
				my($flags) = $1;
				my($monsters) = $2;
				my($turns) = $3;
				my($v) = 2 ** $tKind;
				$monsters |= $v;
				$island->{'prize'} = "$flags,$monsters,$turns";
				}
		 }
		 if(($arg == 6)&&($island->{'h11'}> 0)) {
			# 대상이 되는 괴수각 요소 꺼내기
				my($tKind, $tName, $tHp) = monsterSpec($tLandValue->[$tx][$ty]);
				my($tlv) = $tLandValue->[$tx][$ty];
				my($tspecial) = $HmonsterSpecial[$tKind];
			 $island->{'shouhi'} += random(20000);
			 $island->{'money'} -= $cost;
			 logIreAttackt3($tIsland->{'id'}, $name, "천공성", "하늘의 심판", $dpoint, $tName, $tPoint);

			 # 대상의 괴수가 쓰러져 황무지가 됨
				$tLand->[$tx][$ty] = $HlandWaste;
				$tLandValue->[$tx][$ty] = 1;
			 # 포상금
				my($value) = $HmonsterValue[$tKind];
				 $tIsland->{'money'} += $value;
				 logMsMonMoney($tIsland->{'id'}, $tName, $value);
 # 괴수퇴치 수
 $island->{'taiji'}++;

				# 수상 관계
				my($prize) = $island->{'prize'};
				$prize =~ /([0-9]*),([0-9]*),(.*)/;
				my($flags) = $1;
				my($monsters) = $2;
				my($turns) = $3;
				my($v) = 2 ** $tKind;
				$monsters |= $v;
				$island->{'prize'} = "$flags,$monsters,$turns";
		 }

		}
 }

	logTaishi2($id, $tIsland->{'id'}, $name, $tName, $comName, $tLname, $point, $tPoint, $t);
	return 1;

 } elsif($kind == $HcomSell) {
	# 수출량 결정
	if($arg == 0) { $arg = 1; }
	my($value) = min($arg * (-$cost), $island->{'food'});

	# 수출 로그
	logSell($id, $name, $comName, $value);
	$island->{'food'} -= $value;
	$island->{'money'} += ($value / 10);
	return 0;
 } elsif(($kind == $HcomFood) ||
	 ($kind == $HcomMoney)) {
	# 지원계
	# 대상 가져오기
	my($tn) = $HidToNumber{$target};
	my($tIsland) = $Hislands[$tn];
	my($tName) = $tIsland->{'name'};

 # 자기 섬의 인구가 적으면, 실행은 허가되지 않는
 if ($island->{'pop'} < $HguardPop) {
 logForbidden($id, $name, $comName);
 return 0;
 }

	# 지원량 결정
	if($arg == 0) { $arg = 1; }
	my($value, $str);
	if($cost < 0) {
	 $value = min($arg * (-$cost), $island->{'food'});
	 $str = "$value$HunitFood";
	} else {
	 $value = min($arg * ($cost), $island->{'money'});
	 $str = "$value$HunitMoney";
	}

	# 지원 로그
	logAid($id, $target, $name, $tName, $comName, $str);

	if($cost < 0) {
	 $island->{'food'} -= $value;
	 $tIsland->{'food'} += $value;
	} else {
	 $island->{'money'} -= $value;
	 $tIsland->{'money'} += $value;
	}
	return 0;
 } elsif($kind == $HcomEneGive) {
	my($tn) = $HidToNumber{$target};
	my($tIsland) = $Hislands[$tn];
	my($tName) = $tIsland->{'name'};
	my($tLand) = $tIsland->{'land'};
	my($tLandValue) = $tIsland->{'landValue'};

	# 지원량 결정
	if($arg == 0) { $arg = 1; }
	my($value, $str);

	 $value = min($arg * ($cost), $island->{'ene'});
	 $str = "$value 만 kW";

	# 지원 로그
	logAid($id, $target, $name, $tName, $comName, $str);

	 $island->{'money'} -= $value;
	 $island->{'shouhi'} += $value;
	 $tIsland->{'sabun'} = $value;

	 if ($tIsland->{'sabun'}> 0) {
		my($x, $y, $landKind, $lv, $i);
		for($i = 0; $i < $HpointNumber; $i++) {
		 $x = $Hrpx[$i];
		 $y = $Hrpy[$i];
		 $landKind = $tLand->[$x][$y];
		 $lv = $tLandValue->[$x][$y];
		 if(($landKind == $HlandConden) && ($lv < 2000)) {

	 $n = int((2000 - $lv) / 2);
	 $n = min(int($n + $n), $tIsland->{'sabun'});
	 $tIsland->{'sabun'} -= $n;
	 $tLandValue->[$x][$y] += $n;
			if ($value> 2000) {
	 $tLandValue->[$x][$y] = 2000;
			}

		 }
	 	 if(($landKind == $HlandConden2) && ($lv < 4000)) {

	 $n = int((4000 - $lv) / 10);
	 $n = min(int($n*9 + rand($n)), $tIsland->{'sabun'});
	 $tIsland->{'sabun'} -= $n;
	 $tLandValue->[$x][$y] += $n;
			if ($value> 4000) {
	 $tLandValue->[$x][$y] = 4000;
			}

		 }
		 if(($landKind == $HlandConden3) && ($lv < 7000)) {

	 $n = int((7000 - $lv) / 2);
	 $n = min(int($n + $n), $tIsland->{'sabun'});
	 $tIsland->{'sabun'} -= $n/2;
	 $tLandValue->[$x][$y] += $n/2;
			if ($value> 7000) {
	 $tLandValue->[$x][$y] = 7000;
			}

		 }

	 last if ($tIsland->{'sabun'} <= 0);
		}
	 }
	return 1;
 } elsif($kind == $HcomPropaganda) {
	# 유치 활동
	logPropaganda($id, $name, $comName);
	$island->{'propaganda'} = 1;
	$island->{'money'} -= $cost;
	if($arg> 1) {
	 my($command);
	 $arg--;
	 slideBack($comArray, 0);
	 $comArray->[0] = {
		'kind' => $kind,
		'target' => $target,
		'x' => $x,
		'y' => $y,
		'arg' => $arg
		};
	}
	return 1;
 } elsif($kind == $HcomGiveup) {
	# 포기
	logGiveup($id, $name);
	$island->{'dead'} = 1;
	unlink("island.$id");
	return 1;
 }

 return 1;
}


# 성장 및 단일 헥스 재해
sub doEachHex {
 my($island) = @_;
 my(@monsterMove);

 # 도출 값
 my($name) = $island->{'name'};
 my($id) = $island->{'id'};
 my($land) = $island->{'land'};
 my($landValue) = $island->{'landValue'};

 if($anothermood == 1) {
	$island->{'amarimoney'} = $island->{'money'};
	$island->{'money'} = 0;
 }

 $etc5 = $island->{'etc5'};
 $etc5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
 ($s00,$s01,$s02,$s03,$s04,$s05,$s06,$s07,$s08,$s09,$s10,$s11,$s12,$s13,$s14,$s15,$s16,$s17,$s18,$s19,$s20,$s21,$s22,$s23,$s24,$s25,$s26,$s27,$s28,$s29,$s30) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);
 $s06b = int($s06/5);
 $s08b = int($s08/5);
 $s12b = int($s12/5)+1;
 if($s12b> 10) {$s12b = 10;}

 if(random(20000000)+$s12b*1500000 < $island->{'fukeikimoney'}-$island->{'co6'}*100000) {
	logFukeiki($id, $name);
	$island->{'money'} += 10;
	return 1;
 }

 $aucflag1 = 0;
 $aucflag2 = 0;
 $aucflag3 = 0;

 $zooflag = 0;
 $seisakuflag = 1;

 $msseigen = 0;
 $kougekiseigen = 0;
 $kougekiseigenm = 0;

 $oilincome = 0;
 $parkincome = 0;
 $rizortincome = 0;
 $m84income = 0;
 $gyosenincome = 0;
 $island->{'trainmoney'} = 0;
 $island->{'trainmoney2'} = 0;
 $island->{'hcsankaflag'} = 0;
 $island->{'roudenflag'} = 0;
 $island->{'urikireflag'} = 0;

 # 늘어나면인구의 타네 값
 my($addpop) = 10; # 마을, 읍
 my($addpop2) = 0; # 도시
 if($island->{'food'} < 0) {
	# 식량부족
	$addpop = -30;
 } elsif($island->{'propaganda'} == 1) {
	# 유치 활동 중
	$addpop = 30;
	$addpop2 = 3;
 } elsif((rand(1000)+$island->{'m73'}*250) < $island->{'rot'} * 50) {
	# 포자!?

	if($island->{'ownfe'} == 1) {
	 logRotsick($id, $name);
	 $value = $island->{'pop'}*3 + random($island->{'pop'})*5;
	 $island->{'money'} += $value;
	 $str = "$value$HunitMoney";

		if(random(100) < 20) {
		 $island->{'urikireflag'} = 1;
		 logMiyage2c($id, $name, "$island->{'onm'}", $str, "오염된 바다의 독소시약");
		} else {
		 logMiyage2b($id, $name, "$island->{'onm'}", $str, "오염된 바다의 독소시약");
		}

	} elsif($island->{'ownfe'}> 1) {

	} else {
	 logRotsick($id, $name);
	 $addpop = -10;
	}

 } elsif(random(1000) < $island->{'c21'} * 500) {
	# 역병!?
	$addpop = -3;
	$island->{'food'} -= int($island->{'food'} / 2);
	logSatansick($id, $name);
 } elsif($island->{'fim'}> 0) {
	# 부작용?!
	 if(random(1000) < 10) {
		$addpop = -20;
		logStarvefood($id, $name);
	 }
 }

 # 루프
 my($x, $y, $i);
 for($i = 0; $i < $HpointNumber; $i++) {
	$x = $Hrpx[$i];
	$y = $Hrpy[$i];
	my($landKind) = $land->[$x][$y];
	my($lv) = $landValue->[$x][$y];


	 if(($landKind == $HlandPlains) && (($island->{'co78'}> 0) || ($island->{'co80'}> 0) || ($island->{'yaku'}> 0))) {
		$land->[$x][$y] = $HlandPlains2;
		$landValue->[$x][$y] = 0;
		$island->{'money'} -= 10000*$seisakuflag;
		$seisakuflag++;
	 }
	 if((($landKind == $HlandWaste) || ($landKind == $HlandSunahama)) && (($island->{'co79'}> 0) || ($island->{'co80'}> 0))) {
		$land->[$x][$y] = $HlandPlains;
		$landValue->[$x][$y] = 0;
		$island->{'money'} -= 30000*$seisakuflag;
		$seisakuflag++;
	 }


	if(($landKind == $HlandTown) ||
	 ($landKind == $HlandMinato) ||
	 ($landKind == $HlandSeacity)) {
	 # 읍계


	my($monsterCount) =
	 countAround($land, $x, $y, $HlandMonster, 7);
 if($monsterCount> 0) {
	 $lv -= random(20)+10;
	 $landValue->[$x][$y] = $lv;
	 logMonsAttacks($id, $name, landName($landKind, $lv), "($x, $y)");
		if(($lv <= 0) &&
		 ($landKind == $HlandSeacity)) {
		 # 평지로 되돌리기
		 $land->[$x][$y] = $HlandSea;
		 $landValue->[$x][$y] = 0;
		 next;
		} elsif($lv <= 0) {
		 # 평지로 되돌리기
		 $land->[$x][$y] = $HlandWaste;
		 $landValue->[$x][$y] = 0;
		 next;
		}
	 }


	my($townCount) =
	 countAround($land, $x, $y, $HlandTown, 19) +
	 countAround($land, $x, $y, $HlandProcity, 19) +
 countAround($land, $x, $y, $HlandNewtown, 19) +
	 countAround($land, $x, $y, $HlandBigtown, 19) +
	 countAround($land, $x, $y, $HlandBettown, 19) +
	 countAround($land, $x, $y, $HlandSkycity, 19) +
	 countAround($land, $x, $y, $HlandUmicity, 19) +
	 countAround($land, $x, $y, $HlandSeatown, 19) +
	 countAround($land, $x, $y, $HlandRizort, 19) +
	 countAround($land, $x, $y, $HlandKajino, 19) +
	 countAround($land, $x, $y, $HlandBigRizort, 19) +
	 countAround($land, $x, $y, $HlandShuto, 19) +
	 countAround($land, $x, $y, $HlandUmishuto, 19) +
	 countAround($land, $x, $y, $HlandMinato, 19) +
	 countAround($land, $x, $y, $HlandFrocity, 19) +
	 countAround($land, $x, $y, $HlandOnsen, 19) +
 countAround($land, $x, $y, $HlandSeacity, 19);
 if($townCount> 17) {
	 if(random(1000) < 1) {
		 if($lv> 195) {
			if($landKind == $HlandTown) {
		 $land->[$x][$y] = $HlandBigtown;
		 }
		 }
		}
	 }
	 if($addpop < 0) {
		# 부족
		$lv -= (random(-$addpop) + 1);
		if($lv <= 0) {
			if($landKind == $HlandSeacity) {
		 	$land->[$x][$y] = $HlandSea;
		 	$landValue->[$x][$y] = 0;
		 	next;
			}
		 # 평지로 되돌리기
		 $land->[$x][$y] = $HlandPlains;
		 $landValue->[$x][$y] = 0;
		 next;
		}
	 } else {
		# 성장
		if($lv < 100) {
		 $lv += random($addpop) + 1;
		 if($lv> 100) {
			$lv = 100;
		 }
		} else {
		 # 도시가 되면성장지연이
		 if($addpop2> 0) {
			$lv += random($addpop2) + 1;
		 }
		}
	 }
	 if($lv> 200) {
		$lv = 200;
	 }
	 $landValue->[$x][$y] = $lv;
	} elsif($landKind == $HlandPlains) {
	 # 평지
	 if(random(5) == 0) {
		# 주변에 농장, 읍이 있다면, 여기도 마을이 됨
	 if(countGrow($land, $landValue, $x, $y)){
		 $land->[$x][$y] = $HlandTown;
		 $landValue->[$x][$y] = 1;
		 if(random(1000) < $island->{'nto'}*3) {
		 $land->[$x][$y] = $HlandNewtown;
		 $landValue->[$x][$y] = 1;
		 }
		}
	 }
	} elsif($landKind == $HlandFarmchi) {

	my($FarmCount) = countAround($land, $x, $y, $HlandFarm, 7);
	my($FoodkaCount) = countAround($land, $x, $y, $HlandFoodka, 7);

		$value = $lv;

		if(($FoodkaCount> 0) && ($island->{'shouhi'} < $island->{'ene'})) {
	 $valuek = int($lv/$FoodkaCount);
		 my($i,$sx,$sy);
		 for($i = 1; $i < 7; $i++) {
		 $sx = $x + $ax[$i];
		 $sy = $y + $ay[$i];
			 # 행 기준 위치 조정
			 if((($sy % 2) == 0) && (($y % 2) == 1)) {
				$sx--;
			 }
			 if(($sx < 0) || ($sx>= $HislandSize) ||
			 ($sy < 0) || ($sy>= $HislandSize)) {
			 } else {

				if(($land->[$sx][$sy] == $HlandFoodka) && ($landValue->[$sx][$sy] == 1)) {
					$island->{'money'} += int($valuek*0.175);
					$island->{'shouhi'} += int($valuek*0.005);
				} elsif(($land->[$sx][$sy] == $HlandFoodka) && ($landValue->[$sx][$sy] == 2)) {
					$island->{'money'} += int($valuek*0.25);
					$island->{'shouhi'} += int($valuek*0.015);
				} elsif(($land->[$sx][$sy] == $HlandFoodka) && ($landValue->[$sx][$sy] == 3)) {
					$island->{'money'} += int($valuek*0.4);
					$island->{'shouhi'} += int($valuek*0.03);
				} else {

				}
			 }
			}
 } else {
	 $island->{'food'} += $value;
 }

		 $lv += random(8 + $FarmCount * 3) + 5 + $s08b;

 if($lv> 4000) {
 $lv = 4000;
 }

	 $landValue->[$x][$y] = $lv;

	} elsif($landKind == $HlandFarmpic) {

	my($FarmCount) = countAround($land, $x, $y, $HlandFarm, 7);
	my($FoodkaCount) = countAround($land, $x, $y, $HlandFoodka, 7);

		$value = 2 * $lv;

		if(($FoodkaCount> 0) && ($island->{'shouhi'} < $island->{'ene'})) {
	 $valuek = int($lv*2/$FoodkaCount);
		 my($i,$sx,$sy);
		 for($i = 1; $i < 7; $i++) {
		 $sx = $x + $ax[$i];
		 $sy = $y + $ay[$i];
			 # 행 기준 위치 조정
			 if((($sy % 2) == 0) && (($y % 2) == 1)) {
				$sx--;
			 }
			 if(($sx < 0) || ($sx>= $HislandSize) ||
			 ($sy < 0) || ($sy>= $HislandSize)) {
			 } else {

				if(($land->[$sx][$sy] == $HlandFoodka) && ($landValue->[$sx][$sy] == 1)) {
					$island->{'money'} += int($valuek*0.175);
					$island->{'shouhi'} += int($valuek*0.005);
				} elsif(($land->[$sx][$sy] == $HlandFoodka) && ($landValue->[$sx][$sy] == 2)) {
					$island->{'money'} += int($valuek*0.25);
					$island->{'shouhi'} += int($valuek*0.015);
				} elsif(($land->[$sx][$sy] == $HlandFoodka) && ($landValue->[$sx][$sy] == 3)) {
					$island->{'money'} += int($valuek*0.4);
					$island->{'shouhi'} += int($valuek*0.03);
				} else {

				}
			 }
			}
 } else {
	 $island->{'food'} += $value;
 }

		 $lv += random(4 + $FarmCount * 2 + $s08b) + 3 + $s08b;

 if($lv> 4000) {
 $lv = 4000;
 }

	 $landValue->[$x][$y] = $lv;

	} elsif($landKind == $HlandFarmcow) {

	my($FarmCount) = countAround($land, $x, $y, $HlandFarm, 7);
	my($FoodkaCount) = countAround($land, $x, $y, $HlandFoodka, 7);

		$value = 3 * $lv;

		if(($FoodkaCount> 0) && ($island->{'shouhi'} < $island->{'ene'})) {
	 $valuek = int($lv*3/$FoodkaCount);
		 my($i,$sx,$sy);
		 for($i = 1; $i < 7; $i++) {
		 $sx = $x + $ax[$i];
		 $sy = $y + $ay[$i];
			 # 행 기준 위치 조정
			 if((($sy % 2) == 0) && (($y % 2) == 1)) {
				$sx--;
			 }
			 if(($sx < 0) || ($sx>= $HislandSize) ||
			 ($sy < 0) || ($sy>= $HislandSize)) {

			 } else {

				if(($land->[$sx][$sy] == $HlandFoodka) && ($landValue->[$sx][$sy] == 1)) {
					$island->{'money'} += int($valuek*0.175);
					$island->{'shouhi'} += int($valuek*0.005);
				} elsif(($land->[$sx][$sy] == $HlandFoodka) && ($landValue->[$sx][$sy] == 2)) {
					$island->{'money'} += int($valuek*0.25);
					$island->{'shouhi'} += int($valuek*0.015);
				} elsif(($land->[$sx][$sy] == $HlandFoodka) && ($landValue->[$sx][$sy] == 3)) {
					$island->{'money'} += int($valuek*0.4);
					$island->{'shouhi'} += int($valuek*0.03);
				} else {

				}
			 }
			}

 } else {
	 $island->{'food'} += $value;
 }

		 $lv += random(4 + $FarmCount + $s08b) + 1 + int($s08b/2);

 if($lv> 4000) {
 $lv = 4000;
 }

	 $landValue->[$x][$y] = $lv;

	} elsif($landKind == $HlandFoodka) {
	my($FarmchiCount) = countAround($land, $x, $y, $HlandFarmchi, 7);
	my($FarmpicCount) = countAround($land, $x, $y, $HlandFarmpic, 7);
	my($FarmcowCount) = countAround($land, $x, $y, $HlandFarmcow, 7);
	my($FarmCount) = countAround($land, $x, $y, $HlandFarm, 7);
	my($townCount) =
	 countAround($land, $x, $y, $HlandTown, 19) +
	 countAround($land, $x, $y, $HlandProcity, 19) +
 countAround($land, $x, $y, $HlandNewtown, 19) +
	 countAround($land, $x, $y, $HlandBigtown, 19) +
	 countAround($land, $x, $y, $HlandBettown, 19) +
	 countAround($land, $x, $y, $HlandSkycity, 19) +
	 countAround($land, $x, $y, $HlandUmicity, 19) +
	 countAround($land, $x, $y, $HlandSeatown, 19) +
	 countAround($land, $x, $y, $HlandRizort, 19) +
	 countAround($land, $x, $y, $HlandKajino, 19) +
	 countAround($land, $x, $y, $HlandBigRizort, 19) +
	 countAround($land, $x, $y, $HlandShuto, 19) +
	 countAround($land, $x, $y, $HlandUmishuto, 19) +
	 countAround($land, $x, $y, $HlandMinato, 19) +
	 countAround($land, $x, $y, $HlandFrocity, 19) +
	 countAround($land, $x, $y, $HlandOnsen, 19) +
 countAround($land, $x, $y, $HlandSeacity, 19);
	my($townCounta) =
	 countAround($land, $x, $y, $HlandTown, 19) +
 countAround($land, $x, $y, $HlandNewtown, 19) +
	 countAround($land, $x, $y, $HlandBigtown, 19) +
	 countAround($land, $x, $y, $HlandBettown, 19) +
	 countAround($land, $x, $y, $HlandSkycity, 19) +
	 countAround($land, $x, $y, $HlandUmicity, 19) +
	 countAround($land, $x, $y, $HlandRizort, 19) +
	 countAround($land, $x, $y, $HlandKajino, 19) +
	 countAround($land, $x, $y, $HlandBigRizort, 19);
	 if($island->{'shouhi'}> $island->{'ene'}) {
		 $lv = 0;
 } elsif(($FarmCount> 0) && ($FarmcowCount> 0) && ($FarmchiCount> 0) && ($townCounta> 3)) {
		 $lv = 3;
 } elsif(($FarmCount> 0) && ($FarmcowCount> 0) && ($townCount> 2)) {
		 $lv = 2;
 } elsif(($FarmchiCount> 0) || ($FarmpicCount> 0) || ($FarmcowCount> 0)) {
		 $lv = 1;
 } else {
		 $lv = 0;
 }
	 $landValue->[$x][$y] = $lv;

	} elsif($landKind == $HlandEneBo) {
	 $island->{'food'} -= $lv*5;

	} elsif($landKind == $HlandEneSo) {
		$landValue->[$x][$y] -= random(20);
		if($landValue->[$x][$y] <= 0) {
		 # 평지로 되돌리기
		 $land->[$x][$y] = $HlandPlains;
		 $landValue->[$x][$y] = 0;
		 next;
		}

	} elsif($landKind == $HlandEneAt) {
		if(random(1000) < (50-int($lv/100))) {
		 $AtAttackslog = 0;
		 my($sx, $sy, $i, $landKind, $landName, $lv, $point);
		 for($i = 0; $i < 19; $i++) {
			$sx = $x + $ax[$i];
			$sy = $y + $ay[$i];

			# 행 기준 위치 조정
			if((($sy % 2) == 0) && (($y % 2) == 1)) {
			 $sx--;
			}

			$landKind = $land->[$sx][$sy];
			$lv = $landValue->[$sx][$sy];
			$landName = landName($landKind, $lv);
			$point = "($sx, $sy)";

			# 범위 밖 판정
			if(($sx < 0) || ($sx>= $HislandSize) ||
			 ($sy < 0) || ($sy>= $HislandSize)) {
			 next;
			}
	 if((($landKind == $HlandTown) && ($lv> 1)) ||
			 (($landKind == $HlandMinato) && ($lv> 1)) ||
			 (($landKind == $HlandProcity) && ($lv> 1)) ||
			 (($landKind == $HlandFrocity) && ($lv> 1)) ||
			 (($landKind == $HlandNewtown) && ($lv> 1)) ||
			 (($landKind == $HlandBigtown) && ($lv> 1)) ||
			 (($landKind == $HlandBettown) && ($lv> 1)) ||
			 (($landKind == $HlandSkycity) && ($lv> 1)) ||
			 (($landKind == $HlandUmicity) && ($lv> 1)) ||
			 (($landKind == $HlandRizort) && ($lv> 1)) ||
			 (($landKind == $HlandKajino) && ($lv> 1)) ||
			 (($landKind == $HlandBigRizort) && ($lv> 1)) ||
			 (($landKind == $HlandShuto) && ($lv> 1)) ||
			 (($landKind == $HlandOnsen) && ($lv> 1))) {
	 # 읍
				$landValue->[$sx][$sy] -= random(25);
				if($lv <= 0) {
				 # 평지로 되돌리기
				 $land->[$sx][$sy] = $HlandPlains;
				 $landValue->[$sx][$sy] = 0;
				 next;
				}
				if($AtAttackslog <= 0) {
				$landKind = $land->[$x][$y];
				$lv = $landValue->[$x][$y];
				$landName = landName($landKind, $lv);
				logAtAttacks($id, $name, landName($landKind, $lv), "($x, $y)");
				$AtAttackslog++;
				}
	 }
		 }
		}

	} elsif($landKind == $HlandHTFactory) {

		if ($island->{'pika'}> 0) {
 	$landValue->[$x][$y] += 2;
 	if($landValue->[$x][$y]> 500) {
 	 $landValue->[$x][$y] = 500;
 	}
		}

	} elsif($landKind == $HlandSHTF) {

		if ($island->{'pika'}> 0) {
 	$landValue->[$x][$y] += 1;
 	if($landValue->[$x][$y]> 500) {
 	 $landValue->[$x][$y] = 500;
 	}
		}

	} elsif($landKind == $HlandForest) {
	 my($forestCount) = countAround($land, $x, $y, $HlandForest, 19);
	 # 숲
	 if($lv < 200+$forestCount*200) {
		# 나무가 늘어남
		$landValue->[$x][$y] += 1+random($forestCount)+$s08b;
	 }

	 if($lv> 200+$forestCount*200) {
		$landValue->[$x][$y] = 200+$forestCount*200;
	 }

	} elsif($landKind == $HlandTrain) {
	 if($lv == 10) {
		if(random(100) < 50) {
		$sx = $x + 1;
		$sy = $y + 0;
		# 행 기준 위치 조정
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		 $sx--;
		}
		# 범위 밖 판정
		if(($sx < 0) || ($sx>= $HislandSize) ||
		 ($sy < 0) || ($sy>= $HislandSize)) {
		 next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 1) || ($slv == 2) || ($slv == 3) || ($slv == 6) || ($slv == 8))) {

			$landValue->[$sx][$sy] += 10;
			$landValue->[$x][$y] -= 10;
			$island->{'money'} += 1000;
			$island->{'trainmoney'} += 1000;
			$island->{'shouhi'} += 100;

			 if($island->{'shouhi'}> $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 10;
				logStarve3($id, $name, "일반 열차", "($sx, $sy)");
		 }

			}
	 } else {
		$sx = $x - 1;
		$sy = $y + 0;
		# 행 기준 위치 조정
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		 $sx--;
		}
		# 범위 밖 판정
		if(($sx < 0) || ($sx>= $HislandSize) ||
		 ($sy < 0) || ($sy>= $HislandSize)) {
		 next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 1) || ($slv == 4) || ($slv == 5) || ($slv == 7) || ($slv == 9))) {

			$landValue->[$sx][$sy] += 10;
			$landValue->[$x][$y] -= 10;
			$island->{'money'} += 1000;
			$island->{'trainmoney'} += 1000;
			$island->{'shouhi'} += 100;

			 if($island->{'shouhi'}> $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 10;
				logStarve3($id, $name, "일반 열차", "($sx, $sy)");
		 }

			}
		}
	 } elsif($lv == 11) {
		if(random(100) < 50) {
		$sx = $x + 1;
		$sy = $y + 0;
		# 행 기준 위치 조정
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		 $sx--;
		}
		# 범위 밖 판정
		if(($sx < 0) || ($sx>= $HislandSize) ||
		 ($sy < 0) || ($sy>= $HislandSize)) {
		 next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 0) || ($slv == 1) || ($slv == 2) || ($slv == 3) || ($slv == 6) || ($slv == 8))) {

			$landValue->[$sx][$sy] += 10;
			$landValue->[$x][$y] -= 10;
			$island->{'money'} += 1000;
			$island->{'trainmoney'} += 1000;
			$island->{'shouhi'} += 100;

			 if($island->{'shouhi'}> $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 10;
				logStarve3($id, $name, "일반 열차", "($sx, $sy)");
		 }

			}
	 } else {
		$sx = $x - 1;
		$sy = $y + 0;
		# 행 기준 위치 조정
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		 $sx--;
		}
		# 범위 밖 판정
		if(($sx < 0) || ($sx>= $HislandSize) ||
		 ($sy < 0) || ($sy>= $HislandSize)) {
		 next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 0) || ($slv == 1) || ($slv == 4) || ($slv == 5) || ($slv == 7) || ($slv == 9))) {

			$landValue->[$sx][$sy] += 10;
			$landValue->[$x][$y] -= 10;
			$island->{'money'} += 1000;
			$island->{'trainmoney'} += 1000;
			$island->{'shouhi'} += 100;

			 if($island->{'shouhi'}> $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 10;
				logStarve3($id, $name, "일반 열차", "($sx, $sy)");
		 }

			}
		}
	 } elsif($lv == 12) {
		if(random(100) < 50) {
		$sx = $x + 1;
		$sy = $y - 1;
		# 행 기준 위치 조정
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		 $sx--;
		}
		# 범위 밖 판정
		if(($sx < 0) || ($sx>= $HislandSize) ||
		 ($sy < 0) || ($sy>= $HislandSize)) {
		 next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 5) || ($slv == 7) || ($slv == 8))) {

			$landValue->[$sx][$sy] += 10;
			$landValue->[$x][$y] -= 10;
			$island->{'money'} += 1000;
			$island->{'trainmoney'} += 1000;
			$island->{'shouhi'} += 100;

			 if($island->{'shouhi'}> $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 10;
				logStarve3($id, $name, "일반 열차", "($sx, $sy)");
		 }

			}
	 } else {
		$sx = $x - 1;
		$sy = $y + 0;
		# 행 기준 위치 조정
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		 $sx--;
		}
		# 범위 밖 판정
		if(($sx < 0) || ($sx>= $HislandSize) ||
		 ($sy < 0) || ($sy>= $HislandSize)) {
		 next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 0) || ($slv == 1) || ($slv == 4) || ($slv == 5) || ($slv == 7) || ($slv == 9))) {

			$landValue->[$sx][$sy] += 10;
			$landValue->[$x][$y] -= 10;
			$island->{'money'} += 1000;
			$island->{'trainmoney'} += 1000;
			$island->{'shouhi'} += 100;

			 if($island->{'shouhi'}> $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 10;
				logStarve3($id, $name, "일반 열차", "($sx, $sy)");
		 }

			}
		}
	 } elsif($lv == 13) {
		if(random(100) < 50) {
		$sx = $x + 1;
		$sy = $y + 1;
		# 행 기준 위치 조정
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		 $sx--;
		}
		# 범위 밖 판정
		if(($sx < 0) || ($sx>= $HislandSize) ||
		 ($sy < 0) || ($sy>= $HislandSize)) {
		 next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 4) || ($slv == 7))) {

			$landValue->[$sx][$sy] += 10;
			$landValue->[$x][$y] -= 10;
			$island->{'money'} += 1000;
			$island->{'trainmoney'} += 1000;
			$island->{'shouhi'} += 100;

			 if($island->{'shouhi'}> $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 10;
				logStarve3($id, $name, "일반 열차", "($sx, $sy)");
		 }

			}
	 } else {
		$sx = $x - 1;
		$sy = $y + 0;
		# 행 기준 위치 조정
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		 $sx--;
		}
		# 범위 밖 판정
		if(($sx < 0) || ($sx>= $HislandSize) ||
		 ($sy < 0) || ($sy>= $HislandSize)) {
		 next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 0) || ($slv == 1) || ($slv == 4) || ($slv == 5) || ($slv == 7) || ($slv == 9))) {

			$landValue->[$sx][$sy] += 10;
			$landValue->[$x][$y] -= 10;
			$island->{'money'} += 1000;
			$island->{'trainmoney'} += 1000;
			$island->{'shouhi'} += 100;

			 if($island->{'shouhi'}> $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 10;
				logStarve3($id, $name, "일반 열차", "($sx, $sy)");
		 }

			}
		}
	 } elsif($lv == 14) {
		if(random(100) < 50) {
		$sx = $x + 1;
		$sy = $y + 0;
		# 행 기준 위치 조정
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		 $sx--;
		}
		# 범위 밖 판정
		if(($sx < 0) || ($sx>= $HislandSize) ||
		 ($sy < 0) || ($sy>= $HislandSize)) {
		 next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 0) || ($slv == 1) || ($slv == 2) || ($slv == 3) || ($slv == 6) || ($slv == 8))) {

			$landValue->[$sx][$sy] += 10;
			$landValue->[$x][$y] -= 10;
			$island->{'money'} += 1000;
			$island->{'trainmoney'} += 1000;
			$island->{'shouhi'} += 100;

			 if($island->{'shouhi'}> $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 10;
				logStarve3($id, $name, "일반 열차", "($sx, $sy)");
		 }

			}
	 } else {
		$sx = $x - 1;
		$sy = $y - 1;
		# 행 기준 위치 조정
		if((($sy % 2) == 1) && (($y % 2) == 0)) {
		 $sx++;
		}
		# 범위 밖 판정
		if(($sx < 0) || ($sx>= $HislandSize) ||
		 ($sy < 0) || ($sy>= $HislandSize)) {
		 next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 3) || ($slv == 6) || ($slv == 9))) {

			$landValue->[$sx][$sy] += 10;
			$landValue->[$x][$y] -= 10;
			$island->{'money'} += 1000;
			$island->{'trainmoney'} += 1000;
			$island->{'shouhi'} += 100;

			 if($island->{'shouhi'}> $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 10;
				logStarve3($id, $name, "일반 열차", "($sx, $sy)");
		 }

			}
		}
	 } elsif($lv == 15) {
		if(random(100) < 50) {
		$sx = $x + 1;
		$sy = $y + 0;
		# 행 기준 위치 조정
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		 $sx--;
		}
		# 범위 밖 판정
		if(($sx < 0) || ($sx>= $HislandSize) ||
		 ($sy < 0) || ($sy>= $HislandSize)) {
		 next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 0) || ($slv == 1) || ($slv == 2) || ($slv == 3) || ($slv == 6) || ($slv == 8))) {

			$landValue->[$sx][$sy] += 10;
			$landValue->[$x][$y] -= 10;
			$island->{'money'} += 1000;
			$island->{'trainmoney'} += 1000;
			$island->{'shouhi'} += 100;

			 if($island->{'shouhi'}> $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 10;
				logStarve3($id, $name, "일반 열차", "($sx, $sy)");
		 }

			}
	 } else {
		$sx = $x - 1;
		$sy = $y + 1;
		# 행 기준 위치 조정
		if((($sy % 2) == 1) && (($y % 2) == 0)) {
		 $sx++;
		}
		# 범위 밖 판정
		if(($sx < 0) || ($sx>= $HislandSize) ||
		 ($sy < 0) || ($sy>= $HislandSize)) {
		 next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 2) || ($slv == 6))) {

			$landValue->[$sx][$sy] += 10;
			$landValue->[$x][$y] -= 10;
			$island->{'money'} += 1000;
			$island->{'trainmoney'} += 1000;
			$island->{'shouhi'} += 100;

			 if($island->{'shouhi'}> $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 10;
				logStarve3($id, $name, "일반 열차", "($sx, $sy)");
		 }

			}
		}
	 } elsif($lv == 16) {
		if(random(100) < 33) {
		$sx = $x + 1;
		$sy = $y - 1;
		# 행 기준 위치 조정
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		 $sx--;
		}
		# 범위 밖 판정
		if(($sx < 0) || ($sx>= $HislandSize) ||
		 ($sy < 0) || ($sy>= $HislandSize)) {
		 next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 5) || ($slv == 7) || ($slv == 8))) {

			$landValue->[$sx][$sy] += 10;
			$landValue->[$x][$y] -= 10;
			$island->{'money'} += 1000;
			$island->{'trainmoney'} += 1000;
			$island->{'shouhi'} += 100;

			 if($island->{'shouhi'}> $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 10;
				logStarve3($id, $name, "일반 열차", "($sx, $sy)");
		 }

			}
	 } elsif(random(100) < 50) {
		$sx = $x + 1;
		$sy = $y + 1;
		# 행 기준 위치 조정
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		 $sx--;
		}
		# 범위 밖 판정
		if(($sx < 0) || ($sx>= $HislandSize) ||
		 ($sy < 0) || ($sy>= $HislandSize)) {
		 next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 4) || ($slv == 7))) {

			$landValue->[$sx][$sy] += 10;
			$landValue->[$x][$y] -= 10;
			$island->{'money'} += 1000;
			$island->{'trainmoney'} += 1000;
			$island->{'shouhi'} += 100;

			 if($island->{'shouhi'}> $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 10;
				logStarve3($id, $name, "일반 열차", "($sx, $sy)");
		 }

			}
	 } else {
		$sx = $x - 1;
		$sy = $y + 0;
		# 행 기준 위치 조정
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		 $sx--;
		}
		# 범위 밖 판정
		if(($sx < 0) || ($sx>= $HislandSize) ||
		 ($sy < 0) || ($sy>= $HislandSize)) {
		 next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 0) || ($slv == 1) || ($slv == 4) || ($slv == 5) || ($slv == 7) || ($slv == 9))) {

			$landValue->[$sx][$sy] += 10;
			$landValue->[$x][$y] -= 10;
			$island->{'money'} += 1000;
			$island->{'trainmoney'} += 1000;
			$island->{'shouhi'} += 100;

			 if($island->{'shouhi'}> $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 10;
				logStarve3($id, $name, "일반 열차", "($sx, $sy)");
		 }

			}
		}
	 } elsif($lv == 17) {
		if(random(100) < 33) {
		$sx = $x - 1;
		$sy = $y - 1;
		# 행 기준 위치 조정
		if((($sy % 2) == 1) && (($y % 2) == 0)) {
		 $sx++;
		}
		# 범위 밖 판정
		if(($sx < 0) || ($sx>= $HislandSize) ||
		 ($sy < 0) || ($sy>= $HislandSize)) {
		 next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 3) || ($slv == 6) || ($slv == 9))) {

			$landValue->[$sx][$sy] += 10;
			$landValue->[$x][$y] -= 10;
			$island->{'money'} += 1000;
			$island->{'trainmoney'} += 1000;
			$island->{'shouhi'} += 100;

			 if($island->{'shouhi'}> $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 10;
				logStarve3($id, $name, "일반 열차", "($sx, $sy)");
		 }

			}
	 } elsif(random(100) < 50) {
		$sx = $x - 1;
		$sy = $y + 1;
		# 행 기준 위치 조정
		if((($sy % 2) == 1) && (($y % 2) == 0)) {
		 $sx++;
		}
		# 범위 밖 판정
		if(($sx < 0) || ($sx>= $HislandSize) ||
		 ($sy < 0) || ($sy>= $HislandSize)) {
		 next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 2) || ($slv == 6))) {

			$landValue->[$sx][$sy] += 10;
			$landValue->[$x][$y] -= 10;
			$island->{'money'} += 1000;
			$island->{'trainmoney'} += 1000;
			$island->{'shouhi'} += 100;

			 if($island->{'shouhi'}> $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 10;
				logStarve3($id, $name, "일반 열차", "($sx, $sy)");
		 }

			}
	 } else {
		$sx = $x + 1;
		$sy = $y + 0;
		# 행 기준 위치 조정
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		 $sx--;
		}
		# 범위 밖 판정
		if(($sx < 0) || ($sx>= $HislandSize) ||
		 ($sy < 0) || ($sy>= $HislandSize)) {
		 next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 0) || ($slv == 1) || ($slv == 2) || ($slv == 3) || ($slv == 6) || ($slv == 8))) {

			$landValue->[$sx][$sy] += 10;
			$landValue->[$x][$y] -= 10;
			$island->{'money'} += 1000;
			$island->{'trainmoney'} += 1000;
			$island->{'shouhi'} += 100;

			 if($island->{'shouhi'}> $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 10;
				logStarve3($id, $name, "일반 열차", "($sx, $sy)");
		 }

			}
		}
	 } elsif($lv == 18) {
		if(random(100) < 50) {
		$sx = $x - 1;
		$sy = $y + 0;
		# 행 기준 위치 조정
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		 $sx--;
		}
		# 범위 밖 판정
		if(($sx < 0) || ($sx>= $HislandSize) ||
		 ($sy < 0) || ($sy>= $HislandSize)) {
		 next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 0) || ($slv == 1) || ($slv == 4) || ($slv == 5) || ($slv == 7) || ($slv == 9))) {

			$landValue->[$sx][$sy] += 10;
			$landValue->[$x][$y] -= 10;
			$island->{'money'} += 1000;
			$island->{'trainmoney'} += 1000;
			$island->{'shouhi'} += 100;

			 if($island->{'shouhi'}> $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 10;
				logStarve3($id, $name, "일반 열차", "($sx, $sy)");
		 }

			}
	 } else {
		$sx = $x - 1;
		$sy = $y + 1;
		# 행 기준 위치 조정
		if((($sy % 2) == 1) && (($y % 2) == 0)) {
		 $sx++;
		}
		# 범위 밖 판정
		if(($sx < 0) || ($sx>= $HislandSize) ||
		 ($sy < 0) || ($sy>= $HislandSize)) {
		 next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 2) || ($slv == 6))) {

			$landValue->[$sx][$sy] += 10;
			$landValue->[$x][$y] -= 10;
			$island->{'money'} += 1000;
			$island->{'trainmoney'} += 1000;
			$island->{'shouhi'} += 100;

			 if($island->{'shouhi'}> $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 10;
				logStarve3($id, $name, "일반 열차", "($sx, $sy)");
		 }

			}
		}
	 } elsif($lv == 19) {
		if(random(100) < 50) {
		$sx = $x + 0;
		$sy = $y + 0;
		# 행 기준 위치 조정
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		 $sx--;
		}
		# 범위 밖 판정
		if(($sx < 0) || ($sx>= $HislandSize) ||
		 ($sy < 0) || ($sy>= $HislandSize)) {
		 next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 0) || ($slv == 1) || ($slv == 2) || ($slv == 3) || ($slv == 6) || ($slv == 8))) {

			$landValue->[$sx][$sy] += 10;
			$landValue->[$x][$y] -= 10;
			$island->{'money'} += 1000;
			$island->{'trainmoney'} += 1000;
			$island->{'shouhi'} += 100;

			 if($island->{'shouhi'}> $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 10;
				logStarve3($id, $name, "일반 열차", "($sx, $sy)");
		 }

			}
	 } else {
		$sx = $x + 1;
		$sy = $y + 1;
		# 행 기준 위치 조정
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		 $sx--;
		}
		# 범위 밖 판정
		if(($sx < 0) || ($sx>= $HislandSize) ||
		 ($sy < 0) || ($sy>= $HislandSize)) {
		 next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 4) || ($slv == 7))) {

			$landValue->[$sx][$sy] += 10;
			$landValue->[$x][$y] -= 10;
			$island->{'money'} += 1000;
			$island->{'trainmoney'} += 1000;
			$island->{'shouhi'} += 100;

			 if($island->{'shouhi'}> $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 10;
				logStarve3($id, $name, "일반 열차", "($sx, $sy)");
		 }

			}
		}
	 }

	 if($lv == 20) {
		if(random(100) < 50) {
		$sx = $x + 1;
		$sy = $y + 0;
		# 행 기준 위치 조정
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		 $sx--;
		}
		# 범위 밖 판정
		if(($sx < 0) || ($sx>= $HislandSize) ||
		 ($sy < 0) || ($sy>= $HislandSize)) {
		 next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 1) || ($slv == 2) || ($slv == 3) || ($slv == 6) || ($slv == 8))) {

			$landValue->[$sx][$sy] += 20;
			$landValue->[$x][$y] -= 20;
			$island->{'money'} += 500;
			$island->{'trainmoney2'} += 500;
			$island->{'shouhi'} += 10;

			 if($island->{'shouhi'}> $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 20;
				logStarve3($id, $name, "화물 열차", "($sx, $sy)");
		 }

			}
	 } else {
		$sx = $x - 1;
		$sy = $y + 0;
		# 행 기준 위치 조정
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		 $sx--;
		}
		# 범위 밖 판정
		if(($sx < 0) || ($sx>= $HislandSize) ||
		 ($sy < 0) || ($sy>= $HislandSize)) {
		 next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 1) || ($slv == 4) || ($slv == 5) || ($slv == 7) || ($slv == 9))) {

			$landValue->[$sx][$sy] += 20;
			$landValue->[$x][$y] -= 20;
			$island->{'money'} += 500;
			$island->{'trainmoney2'} += 500;
			$island->{'shouhi'} += 10;

			 if($island->{'shouhi'}> $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 20;
				logStarve3($id, $name, "화물 열차", "($sx, $sy)");
		 }

			}
		}
	 } elsif($lv == 21) {
		if(random(100) < 50) {
		$sx = $x + 1;
		$sy = $y + 0;
		# 행 기준 위치 조정
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		 $sx--;
		}
		# 범위 밖 판정
		if(($sx < 0) || ($sx>= $HislandSize) ||
		 ($sy < 0) || ($sy>= $HislandSize)) {
		 next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 0) || ($slv == 1) || ($slv == 2) || ($slv == 3) || ($slv == 6) || ($slv == 8))) {

			$landValue->[$sx][$sy] += 20;
			$landValue->[$x][$y] -= 20;
			$island->{'money'} += 500;
			$island->{'trainmoney2'} += 500;
			$island->{'shouhi'} += 10;

			 if($island->{'shouhi'}> $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 20;
				logStarve3($id, $name, "화물 열차", "($sx, $sy)");
		 }

			}
	 } else {
		$sx = $x - 1;
		$sy = $y + 0;
		# 행 기준 위치 조정
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		 $sx--;
		}
		# 범위 밖 판정
		if(($sx < 0) || ($sx>= $HislandSize) ||
		 ($sy < 0) || ($sy>= $HislandSize)) {
		 next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 0) || ($slv == 1) || ($slv == 4) || ($slv == 5) || ($slv == 7) || ($slv == 9))) {

			$landValue->[$sx][$sy] += 20;
			$landValue->[$x][$y] -= 20;
			$island->{'money'} += 500;
			$island->{'trainmoney2'} += 500;
			$island->{'shouhi'} += 10;

			 if($island->{'shouhi'}> $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 20;
				logStarve3($id, $name, "화물 열차", "($sx, $sy)");
		 }

			}
		}
	 } elsif($lv == 22) {
		if(random(100) < 50) {
		$sx = $x + 1;
		$sy = $y - 1;
		# 행 기준 위치 조정
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		 $sx--;
		}
		# 범위 밖 판정
		if(($sx < 0) || ($sx>= $HislandSize) ||
		 ($sy < 0) || ($sy>= $HislandSize)) {
		 next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 5) || ($slv == 7) || ($slv == 8))) {

			$landValue->[$sx][$sy] += 20;
			$landValue->[$x][$y] -= 20;
			$island->{'money'} += 500;
			$island->{'trainmoney2'} += 500;
			$island->{'shouhi'} += 10;

			 if($island->{'shouhi'}> $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 20;
				logStarve3($id, $name, "화물 열차", "($sx, $sy)");
		 }

			}
	 } else {
		$sx = $x - 1;
		$sy = $y + 0;
		# 행 기준 위치 조정
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		 $sx--;
		}
		# 범위 밖 판정
		if(($sx < 0) || ($sx>= $HislandSize) ||
		 ($sy < 0) || ($sy>= $HislandSize)) {
		 next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 0) || ($slv == 1) || ($slv == 4) || ($slv == 5) || ($slv == 7) || ($slv == 9))) {

			$landValue->[$sx][$sy] += 20;
			$landValue->[$x][$y] -= 20;
			$island->{'money'} += 500;
			$island->{'trainmoney2'} += 500;
			$island->{'shouhi'} += 10;

			 if($island->{'shouhi'}> $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 20;
				logStarve3($id, $name, "화물 열차", "($sx, $sy)");
		 }

			}
		}
	 } elsif($lv == 23) {
		if(random(100) < 50) {
		$sx = $x + 1;
		$sy = $y + 1;
		# 행 기준 위치 조정
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		 $sx--;
		}
		# 범위 밖 판정
		if(($sx < 0) || ($sx>= $HislandSize) ||
		 ($sy < 0) || ($sy>= $HislandSize)) {
		 next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 4) || ($slv == 7))) {

			$landValue->[$sx][$sy] += 20;
			$landValue->[$x][$y] -= 20;
			$island->{'money'} += 500;
			$island->{'trainmoney2'} += 500;
			$island->{'shouhi'} += 10;

			 if($island->{'shouhi'}> $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 20;
				logStarve3($id, $name, "화물 열차", "($sx, $sy)");
		 }

			}
	 } else {
		$sx = $x - 1;
		$sy = $y + 0;
		# 행 기준 위치 조정
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		 $sx--;
		}
		# 범위 밖 판정
		if(($sx < 0) || ($sx>= $HislandSize) ||
		 ($sy < 0) || ($sy>= $HislandSize)) {
		 next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 0) || ($slv == 1) || ($slv == 4) || ($slv == 5) || ($slv == 7) || ($slv == 9))) {

			$landValue->[$sx][$sy] += 20;
			$landValue->[$x][$y] -= 20;
			$island->{'money'} += 500;
			$island->{'trainmoney2'} += 500;
			$island->{'shouhi'} += 10;

			 if($island->{'shouhi'}> $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 20;
				logStarve3($id, $name, "화물 열차", "($sx, $sy)");
		 }

			}
		}
	 } elsif($lv == 24) {
		if(random(100) < 50) {
		$sx = $x + 1;
		$sy = $y + 0;
		# 행 기준 위치 조정
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		 $sx--;
		}
		# 범위 밖 판정
		if(($sx < 0) || ($sx>= $HislandSize) ||
		 ($sy < 0) || ($sy>= $HislandSize)) {
		 next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 0) || ($slv == 1) || ($slv == 2) || ($slv == 3) || ($slv == 6) || ($slv == 8))) {

			$landValue->[$sx][$sy] += 20;
			$landValue->[$x][$y] -= 20;
			$island->{'money'} += 500;
			$island->{'trainmoney2'} += 500;
			$island->{'shouhi'} += 10;

			 if($island->{'shouhi'}> $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 20;
				logStarve3($id, $name, "화물 열차", "($sx, $sy)");
		 }

			}
	 } else {
		$sx = $x - 1;
		$sy = $y - 1;
		# 행 기준 위치 조정
		if((($sy % 2) == 1) && (($y % 2) == 0)) {
		 $sx++;
		}
		# 범위 밖 판정
		if(($sx < 0) || ($sx>= $HislandSize) ||
		 ($sy < 0) || ($sy>= $HislandSize)) {
		 next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 3) || ($slv == 6) || ($slv == 9))) {

			$landValue->[$sx][$sy] += 20;
			$landValue->[$x][$y] -= 20;
			$island->{'money'} += 500;
			$island->{'trainmoney2'} += 500;
			$island->{'shouhi'} += 10;

			 if($island->{'shouhi'}> $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 20;
				logStarve3($id, $name, "화물 열차", "($sx, $sy)");
		 }

			}
		}
	 } elsif($lv == 25) {
		if(random(100) < 50) {
		$sx = $x + 1;
		$sy = $y + 0;
		# 행 기준 위치 조정
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		 $sx--;
		}
		# 범위 밖 판정
		if(($sx < 0) || ($sx>= $HislandSize) ||
		 ($sy < 0) || ($sy>= $HislandSize)) {
		 next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 0) || ($slv == 1) || ($slv == 2) || ($slv == 3) || ($slv == 6) || ($slv == 8))) {

			$landValue->[$sx][$sy] += 20;
			$landValue->[$x][$y] -= 20;
			$island->{'money'} += 500;
			$island->{'trainmoney2'} += 500;
			$island->{'shouhi'} += 10;

			 if($island->{'shouhi'}> $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 20;
				logStarve3($id, $name, "화물 열차", "($sx, $sy)");
		 }

			}
	 } else {
		$sx = $x - 1;
		$sy = $y + 1;
		# 행 기준 위치 조정
		if((($sy % 2) == 1) && (($y % 2) == 0)) {
		 $sx++;
		}
		# 범위 밖 판정
		if(($sx < 0) || ($sx>= $HislandSize) ||
		 ($sy < 0) || ($sy>= $HislandSize)) {
		 next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 2) || ($slv == 6))) {

			$landValue->[$sx][$sy] += 20;
			$landValue->[$x][$y] -= 20;
			$island->{'money'} += 500;
			$island->{'trainmoney2'} += 500;
			$island->{'shouhi'} += 10;

			 if($island->{'shouhi'}> $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 20;
				logStarve3($id, $name, "화물 열차", "($sx, $sy)");
		 }

			}
		}
	 } elsif($lv == 26) {
		if(random(100) < 33) {
		$sx = $x + 1;
		$sy = $y - 1;
		# 행 기준 위치 조정
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		 $sx--;
		}
		# 범위 밖 판정
		if(($sx < 0) || ($sx>= $HislandSize) ||
		 ($sy < 0) || ($sy>= $HislandSize)) {
		 next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 5) || ($slv == 7) || ($slv == 8))) {

			$landValue->[$sx][$sy] += 20;
			$landValue->[$x][$y] -= 20;
			$island->{'money'} += 500;
			$island->{'trainmoney2'} += 500;
			$island->{'shouhi'} += 10;

			 if($island->{'shouhi'}> $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 20;
				logStarve3($id, $name, "화물 열차", "($sx, $sy)");
		 }

			}
	 } elsif(random(100) < 50) {
		$sx = $x + 1;
		$sy = $y + 1;
		# 행 기준 위치 조정
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		 $sx--;
		}
		# 범위 밖 판정
		if(($sx < 0) || ($sx>= $HislandSize) ||
		 ($sy < 0) || ($sy>= $HislandSize)) {
		 next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 4) || ($slv == 7))) {

			$landValue->[$sx][$sy] += 20;
			$landValue->[$x][$y] -= 20;
			$island->{'money'} += 500;
			$island->{'trainmoney2'} += 500;
			$island->{'shouhi'} += 10;

			 if($island->{'shouhi'}> $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 20;
				logStarve3($id, $name, "화물 열차", "($sx, $sy)");
		 }

			}
	 } else {
		$sx = $x - 1;
		$sy = $y + 0;
		# 행 기준 위치 조정
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		 $sx--;
		}
		# 범위 밖 판정
		if(($sx < 0) || ($sx>= $HislandSize) ||
		 ($sy < 0) || ($sy>= $HislandSize)) {
		 next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 0) || ($slv == 1) || ($slv == 4) || ($slv == 5) || ($slv == 7) || ($slv == 9))) {

			$landValue->[$sx][$sy] += 20;
			$landValue->[$x][$y] -= 20;
			$island->{'money'} += 500;
			$island->{'trainmoney2'} += 500;
			$island->{'shouhi'} += 10;

			 if($island->{'shouhi'}> $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 20;
				logStarve3($id, $name, "화물 열차", "($sx, $sy)");
		 }

			}
		}
	 } elsif($lv == 27) {
		if(random(100) < 33) {
		$sx = $x - 1;
		$sy = $y - 1;
		# 행 기준 위치 조정
		if((($sy % 2) == 1) && (($y % 2) == 0)) {
		 $sx++;
		}
		# 범위 밖 판정
		if(($sx < 0) || ($sx>= $HislandSize) ||
		 ($sy < 0) || ($sy>= $HislandSize)) {
		 next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 3) || ($slv == 6) || ($slv == 9))) {

			$landValue->[$sx][$sy] += 20;
			$landValue->[$x][$y] -= 20;
			$island->{'money'} += 500;
			$island->{'trainmoney2'} += 500;
			$island->{'shouhi'} += 10;

			 if($island->{'shouhi'}> $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 20;
				logStarve3($id, $name, "화물 열차", "($sx, $sy)");
		 }

			}
	 } elsif(random(100) < 50) {
		$sx = $x - 1;
		$sy = $y + 1;
		# 행 기준 위치 조정
		if((($sy % 2) == 1) && (($y % 2) == 0)) {
		 $sx++;
		}
		# 범위 밖 판정
		if(($sx < 0) || ($sx>= $HislandSize) ||
		 ($sy < 0) || ($sy>= $HislandSize)) {
		 next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 2) || ($slv == 6))) {

			$landValue->[$sx][$sy] += 20;
			$landValue->[$x][$y] -= 20;
			$island->{'money'} += 500;
			$island->{'trainmoney2'} += 500;
			$island->{'shouhi'} += 10;

			 if($island->{'shouhi'}> $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 20;
				logStarve3($id, $name, "화물 열차", "($sx, $sy)");
		 }

			}
	 } else {
		$sx = $x + 1;
		$sy = $y + 0;
		# 행 기준 위치 조정
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		 $sx--;
		}
		# 범위 밖 판정
		if(($sx < 0) || ($sx>= $HislandSize) ||
		 ($sy < 0) || ($sy>= $HislandSize)) {
		 next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 0) || ($slv == 1) || ($slv == 2) || ($slv == 3) || ($slv == 6) || ($slv == 8))) {

			$landValue->[$sx][$sy] += 20;
			$landValue->[$x][$y] -= 20;
			$island->{'money'} += 500;
			$island->{'trainmoney2'} += 500;
			$island->{'shouhi'} += 10;

			 if($island->{'shouhi'}> $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 20;
				logStarve3($id, $name, "화물 열차", "($sx, $sy)");
		 }

			}
		}
	 } elsif($lv == 28) {
		if(random(100) < 50) {
		$sx = $x - 1;
		$sy = $y + 0;
		# 행 기준 위치 조정
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		 $sx--;
		}
		# 범위 밖 판정
		if(($sx < 0) || ($sx>= $HislandSize) ||
		 ($sy < 0) || ($sy>= $HislandSize)) {
		 next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 0) || ($slv == 1) || ($slv == 4) || ($slv == 5) || ($slv == 7) || ($slv == 9))) {

			$landValue->[$sx][$sy] += 20;
			$landValue->[$x][$y] -= 20;
			$island->{'money'} += 500;
			$island->{'trainmoney2'} += 500;
			$island->{'shouhi'} += 10;

			 if($island->{'shouhi'}> $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 20;
				logStarve3($id, $name, "화물 열차", "($sx, $sy)");
		 }

			}
	 } else {
		$sx = $x - 1;
		$sy = $y + 1;
		# 행 기준 위치 조정
		if((($sy % 2) == 1) && (($y % 2) == 0)) {
		 $sx++;
		}
		# 범위 밖 판정
		if(($sx < 0) || ($sx>= $HislandSize) ||
		 ($sy < 0) || ($sy>= $HislandSize)) {
		 next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 2) || ($slv == 6))) {

			$landValue->[$sx][$sy] += 20;
			$landValue->[$x][$y] -= 20;
			$island->{'money'} += 500;
			$island->{'trainmoney2'} += 500;
			$island->{'shouhi'} += 10;

			 if($island->{'shouhi'}> $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 20;
				logStarve3($id, $name, "화물 열차", "($sx, $sy)");
		 }

			}
		}
	 } elsif($lv == 29) {
		if(random(100) < 50) {
		$sx = $x + 1;
		$sy = $y + 0;
		# 행 기준 위치 조정
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		 $sx--;
		}
		# 범위 밖 판정
		if(($sx < 0) || ($sx>= $HislandSize) ||
		 ($sy < 0) || ($sy>= $HislandSize)) {
		 next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 0) || ($slv == 1) || ($slv == 2) || ($slv == 3) || ($slv == 6) || ($slv == 8))) {

			$landValue->[$sx][$sy] += 20;
			$landValue->[$x][$y] -= 20;
			$island->{'money'} += 500;
			$island->{'trainmoney2'} += 500;
			$island->{'shouhi'} += 10;

			 if($island->{'shouhi'}> $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 20;
				logStarve3($id, $name, "화물 열차", "($sx, $sy)");
		 }

			}
	 } else {
		$sx = $x + 1;
		$sy = $y + 1;
		# 행 기준 위치 조정
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		 $sx--;
		}
		# 범위 밖 판정
		if(($sx < 0) || ($sx>= $HislandSize) ||
		 ($sy < 0) || ($sy>= $HislandSize)) {
		 next;
		}
			my($sl) = $land->[$sx][$sy];
			my($slv) = $landValue->[$sx][$sy];
			if(($land->[$sx][$sy] == $HlandTrain) && (($slv == 4) || ($slv == 7))) {

			$landValue->[$sx][$sy] += 20;
			$landValue->[$x][$y] -= 20;
			$island->{'money'} += 500;
			$island->{'trainmoney2'} += 500;
			$island->{'shouhi'} += 10;

			 if($island->{'shouhi'}> $island->{'ene'}) {
				$landValue->[$sx][$sy] -= 20;
				logStarve3($id, $name, "화물 열차", "($sx, $sy)");
		 }

			}
		}
	 }

	} elsif($landKind == $HlandKura) {
	 $seq = int($lv/100);
	 $choki = $lv%100;
	 if(random(100) < 9-$seq) {
		$choki = int($choki/100*random(100));
		$seq--;
			if($seq < 0) {
			$seq = 0;
			}
		$landValue->[$x][$y] = $seq*100+$choki;
		my($lName) = &landName($landKind, $lv);
		logKuralupin($id, $name, $lName, "($x, $y)");
	 }

	 if($anothermood == 1) {
		$choki -= int($choki/100*$seq);
			if($choki < 0) {
			$choki = 0;
			}
		$landValue->[$x][$y] = $seq*100+$choki;
	 }

	} elsif($landKind == $HlandHouse) {

		$zeikin = int($island->{'pop'}*($lv+1)*$island->{'eisei1'}/100);

		if($anothermood == 1) {
 $island->{'money'} += $zeikin;
		}else{

		if($zeikin> 10000) {
		 if($HislandTurn % 5 == 0) {
 $island->{'money'} += $zeikin;
		 }else{
		 }
		}elsif($zeikin> 5000) {
		 if($HislandTurn % 2 == 0) {
 $island->{'money'} += $zeikin;
		 }else{
		 }
		}else{
 $island->{'money'} += $zeikin;
		}

		}

	} elsif($landKind == $HlandDefence) {
	 if($lv == 1) {
		# 방위 시설 자폭
		my($lName) = &landName($landKind, $lv);
		logBombFire($id, $name, $lName, "($x, $y)");

		# 광역 피해 루틴
		wideDamage($id, $name, $land, $landValue, $x, $y);
	 }
	} elsif($landKind == $HlandProcity) {
	 # 방재 도시
	 if($addpop < 0) {
		# 부족
		$lv -= (random(-$addpop) + 1);
		if($lv <= 0) {
		 # 평지로 되돌리기
		 $land->[$x][$y] = $HlandPlains;
		 $landValue->[$x][$y] = 0;
		 next;
		}
	 } else {
		# 성장
		if($lv < 100) {
		 $lv += random($addpop) + 1;
		 if($lv> 100) {
			$lv = 100;
		 }
		} else {
		 # 도시가 되면성장지연이
		 if($addpop2> 0) {
			$lv += random($addpop2) + 1;
		 }
		}
	 }
	 if($lv> 200) {
		$lv = 200;
	 }
	 $landValue->[$x][$y] = $lv;

	 if($lv == 200) {

	 my($i,$sx,$sy);
	 for($i = 1; $i < 7; $i++) {
	 $sx = $x + $ax[$i];
	 $sy = $y + $ay[$i];
	 if($land->[$sx][$sy] == $HlandMonster){
		# 주변 2Hex 에 다른 괴수가 있으면 그 괴수를 공격

		# 대상이 되는 괴수각 요소 꺼내기
		my($tKind, $tName, $tHp) = monsterSpec($landValue->[$sx][$sy]);
		my($tlv) = $landValue->[$sx][$sy];
		my($tspecial) = $HmonsterSpecial[$tKind];

		 logBariaAttack($id, $name, $tName, "($sx, $sy)");
	 # 대상의 괴수가 쓰러져 황무지가 됨
		$land->[$sx][$sy] = $HlandWaste;
		$landValue->[$sx][$sy] = 1;
	 next;
	 }
	 }
	 }

	} elsif($landKind == $HlandNewtown) {
	 # 뉴타운계
	my($townCount) =
	 countAround($land, $x, $y, $HlandTown, 19) +
	 countAround($land, $x, $y, $HlandProcity, 19) +
 countAround($land, $x, $y, $HlandNewtown, 19) +
	 countAround($land, $x, $y, $HlandBigtown, 19) +
	 countAround($land, $x, $y, $HlandBettown, 19) +
	 countAround($land, $x, $y, $HlandSkycity, 19) +
	 countAround($land, $x, $y, $HlandUmicity, 19) +
	 countAround($land, $x, $y, $HlandSeatown, 19) +
	 countAround($land, $x, $y, $HlandRizort, 19) +
	 countAround($land, $x, $y, $HlandKajino, 19) +
	 countAround($land, $x, $y, $HlandBigRizort, 19) +
	 countAround($land, $x, $y, $HlandShuto, 19) +
	 countAround($land, $x, $y, $HlandUmishuto, 19) +
	 countAround($land, $x, $y, $HlandMinato, 19) +
	 countAround($land, $x, $y, $HlandFrocity, 19) +
	 countAround($land, $x, $y, $HlandOnsen, 19) +
 countAround($land, $x, $y, $HlandSeacity, 19);
 if($townCount> 17) {
	 if(random(1000) < 3) {
		 if($lv> 295) {
		 $land->[$x][$y] = $HlandBigtown;
		 }
		}
	 }
	 if($addpop < 0) {
		# 부족
		$lv -= (random(-$addpop) + 1);
		if($lv <= 0) {
		 # 평지로 되돌리기
		 $land->[$x][$y] = $HlandPlains;
		 $landValue->[$x][$y] = 0;
		 next;
		}
	 } else {
		# 성장
		if($lv < 100) {
		 $lv += random($addpop) + 1;
		 if($lv> 100) {
			$lv = 100;
		 }
		} else {
		 # 도시가 되면성장지연이
		 if($addpop2> 0) {
			$lv += random($addpop2) + 1;
		 }
		}
	 }
	 if($lv> 300) {
		$lv = 300;
	 }
	 $landValue->[$x][$y] = $lv;

	} elsif($landKind == $HlandBigtown) {


	my($monsterCount) =
	 countAround($land, $x, $y, $HlandMonster, 7);
 if($monsterCount> 0) {
	 $lv -= random(20)+10;
	 $landValue->[$x][$y] = $lv;
	 logMonsAttacks($id, $name, landName($landKind, $lv), "($x, $y)");
		if($lv <= 0) {
		 # 평지로 되돌리기
		 $land->[$x][$y] = $HlandWaste;
		 $landValue->[$x][$y] = 0;
		 next;
		}
	 }


	my($townCount) =
	 countAround($land, $x, $y, $HlandTown, 19) +
	 countAround($land, $x, $y, $HlandProcity, 19) +
 countAround($land, $x, $y, $HlandNewtown, 19) +
	 countAround($land, $x, $y, $HlandBigtown, 19) +
	 countAround($land, $x, $y, $HlandBettown, 19) +
	 countAround($land, $x, $y, $HlandSkycity, 19) +
	 countAround($land, $x, $y, $HlandUmicity, 19) +
	 countAround($land, $x, $y, $HlandSeatown, 19) +
	 countAround($land, $x, $y, $HlandRizort, 19) +
	 countAround($land, $x, $y, $HlandKajino, 19) +
	 countAround($land, $x, $y, $HlandBigRizort, 19) +
	 countAround($land, $x, $y, $HlandShuto, 19) +
	 countAround($land, $x, $y, $HlandUmishuto, 19) +
	 countAround($land, $x, $y, $HlandMinato, 19) +
	 countAround($land, $x, $y, $HlandFrocity, 19) +
	 countAround($land, $x, $y, $HlandOnsen, 19) +
 countAround($land, $x, $y, $HlandSeacity, 19);
	my($houseCount) =
	 countAround($land, $x, $y, $HlandHouse, 7);
 if(($island->{'shu'} == 0) &&
		($houseCount == 1) &&
		($townCount> 16) &&
		(random(1000) < 300)) {
		 $land->[$x][$y] = $HlandShuto;
			my($onm);
			$onm = $island->{'onm'};
			$island->{'totoyoso2'} = "$onm 시티";
				logShuto($id, $name, landName($landKind, $lv), "$onm 시티", "($x, $y)");
		 $island->{'shu'}++;
	 }
	 # 현대 도시계
	 if($addpop < 0) {
		# 부족
		$lv -= (random(-$addpop) + 1);
		if($lv <= 0) {
		 # 평지로 되돌리기
		 $land->[$x][$y] = $HlandPlains;
		 $landValue->[$x][$y] = 0;
		 next;
		}
	 } else {
		# 성장
		if($lv < 200) {
		 $lv += random($addpop) + 1;
		 if($lv> 200) {
			$lv = 200;
		 }
		} else {
		 # 도시가 되면성장지연이
		 if($addpop2> 0) {
			$lv += random($addpop2) + 1;
		 }
		}
	 }
	 if($lv> 500) {
		$lv = 500;
	 }
	 $landValue->[$x][$y] = $lv;

	} elsif($landKind == $HlandSeatown) {
	 # 해저 신도시계
	my($townCount) =
	 countAround($land, $x, $y, $HlandTown, 19) +
	 countAround($land, $x, $y, $HlandProcity, 19) +
 countAround($land, $x, $y, $HlandNewtown, 19) +
	 countAround($land, $x, $y, $HlandBigtown, 19) +
	 countAround($land, $x, $y, $HlandBettown, 19) +
	 countAround($land, $x, $y, $HlandSkycity, 19) +
	 countAround($land, $x, $y, $HlandUmicity, 19) +
	 countAround($land, $x, $y, $HlandSeatown, 19) +
	 countAround($land, $x, $y, $HlandRizort, 19) +
	 countAround($land, $x, $y, $HlandKajino, 19) +
	 countAround($land, $x, $y, $HlandBigRizort, 19) +
	 countAround($land, $x, $y, $HlandShuto, 19) +
	 countAround($land, $x, $y, $HlandUmishuto, 19) +
	 countAround($land, $x, $y, $HlandMinato, 19) +
	 countAround($land, $x, $y, $HlandFrocity, 19) +
	 countAround($land, $x, $y, $HlandOnsen, 19) +
 countAround($land, $x, $y, $HlandSeacity, 19);
	my($houseCount) =
	 countAround($land, $x, $y, $HlandHouse, 7);
 if(($island->{'shu'} == 0) &&
		($houseCount == 1) &&
		($townCount> 16) &&
		(random(1000) < 300)) {
		 $land->[$x][$y] = $HlandUmishuto;
			my($onm);
			$onm = $island->{'onm'};
			$island->{'totoyoso2'} = "$onm 시티";
				logShuto($id, $name, landName($landKind, $lv), "$onm 시티", "($x, $y)");
		 $island->{'shu'}++;
	 }
	 if($addpop < 0) {
		# 부족
		$lv -= (random(-$addpop) + 1);
		if($lv <= 0) {
		 # 평지로 되돌리기
		 $land->[$x][$y] = $HlandSea;
		 $landValue->[$x][$y] = 0;
		 next;
		}
	 } else {
		# 성장
		if($lv < 250) {
		 $lv += random($addpop) + 1;
		 if($lv> 250) {
			$lv = 250;
		 }
		} else {
		 # 도시가 되면성장지연이
		 if($addpop2> 0) {
			$lv += random($addpop2) + 1;
		 }
		}
	 }
	 if($lv> 400) {
		$lv = 400;
	 }
	 $landValue->[$x][$y] = $lv;



	} elsif($landKind == $HlandBettown) {


	my($monsterCount) =
	 countAround($land, $x, $y, $HlandMonster, 7);
 if($monsterCount> 0) {
	 $lv -= random(20)+10;
	 $landValue->[$x][$y] = $lv;
	 logMonsAttacks($id, $name, landName($landKind, $lv), "($x, $y)");
		if($lv <= 0) {
		 # 평지로 되돌리기
		 $land->[$x][$y] = $HlandWaste;
		 $landValue->[$x][$y] = 0;
		 next;
		}
	 }

	my($shutoCount) =
	 countAround($land, $x, $y, $HlandShuto, 7) +
	 countAround($land, $x, $y, $HlandUmishuto, 7);
	my($betCount) =
	 countAround($land, $x, $y, $HlandBettown, 7);

	 if($addpop < 0) {
		# 부족
		$lv -= (random(-$addpop) + 1);
		if($lv <= 0) {
		 # 평지로 되돌리기
		 $land->[$x][$y] = $HlandPlains;
		 $landValue->[$x][$y] = 0;
		 next;
		}
	 } else {
		# 성장

		if(($island->{'shu'}> 0) &&
		 (($shutoCount> 0) ||
		 ($betCount> 1))) {

		if($lv < 1000) {
		 $lv += random($addpop) + 1;
		 if($lv> 1000) {
			$lv = 1000;
		 }
		} else {
		 # 도시가 되면성장지연이
		 if($addpop2> 0) {
			$lv += random($addpop2) + 1;
		 }
		}

		}

	 }
	 if($lv> 2000) {
		$lv = 2000;
	 }
	 $landValue->[$x][$y] = $lv;

	} elsif($landKind == $HlandSkycity) {


	my($monsterCount) =
	 countAround($land, $x, $y, $HlandMonster, 7);
 if($monsterCount> 0) {
	 $lv -= random(20)+10;
	 $landValue->[$x][$y] = $lv;
	 logMonsAttacks($id, $name, landName($landKind, $lv), "($x, $y)");
		if($lv <= 0) {
		 # 평지로 되돌리기
		 $land->[$x][$y] = $HlandWaste;
		 $landValue->[$x][$y] = 0;
		 next;
		}
	 }

	 if($addpop < 0) {
		# 부족
		$lv -= (random(-$addpop) + 1);
		if($lv <= 0) {
		 # 평지로 되돌리기
		 $land->[$x][$y] = $HlandPlains;
		 $landValue->[$x][$y] = 0;
		 next;
		}
	 } else {
		# 성장

		if($lv < 2250) {
		 $lv += random($addpop) + 1;
		} else {
		 # 도시가 되면성장지연이
		 if($addpop2> 0) {
			$lv += random($addpop2) + 1;
		 }
		}

	 }
	 if($lv> 3000) {
		$lv = 3000;
	 }
	 $landValue->[$x][$y] = $lv;

	} elsif($landKind == $HlandUmicity) {

	my($monsterCount) =
	 countAround($land, $x, $y, $HlandMonster, 7);
 if($monsterCount> 0) {
	 $lv -= random(20)+10;
	 $landValue->[$x][$y] = $lv;
	 logMonsAttacks($id, $name, landName($landKind, $lv), "($x, $y)");
		if($lv <= 0) {
		 # 평지로 되돌리기
		 $land->[$x][$y] = $HlandSea;
		 $landValue->[$x][$y] = 0;
		 next;
		}
	 }

	 if($addpop < 0) {
		# 부족
		$lv -= (random(-$addpop) + 1);
		if($lv <= 0) {
		 # 평지로 되돌리기
		 $land->[$x][$y] = $HlandSea;
		 $landValue->[$x][$y] = 0;
		 next;
		}
	 } else {
		# 성장

		if($lv < 2500) {
		 $lv += random($addpop) + 1;
		} else {
		 # 도시가 되면성장지연이
		 if($addpop2> 0) {
			$lv += random($addpop2) + 1;
		 }
		}

	 }
	 if($lv> 3000) {
		$lv = 3000;
	 }
	 $landValue->[$x][$y] = $lv;

	} elsif(($landKind == $HlandShuto) ||
		($landKind == $HlandUmishuto)) {
	 # 수도계

		if($island->{'shu'}> 1) {
		 $land->[$x][$y] = $HlandPlains2;
		 $landValue->[$x][$y] = 0;
		 $island->{'shu'} -= 1;
		}

	my($monsterCount) =
	 countAround($land, $x, $y, $HlandMonster, 7);
 if($monsterCount> 0) {
	 $lv -= random(100)+200;
	 $landValue->[$x][$y] = $lv;
	 logMonsAttacks($id, $name, landName($landKind, $lv), "($x, $y)");
		if(($lv <= 0) &&
		 ($landKind == $HlandUmishuto)) {
		 # 평지로 되돌리기
		 $land->[$x][$y] = $HlandSea;
		 $landValue->[$x][$y] = 0;
		 next;
		}
		if(($lv <= 0) &&
		 ($landKind == $HlandShuto)) {
		 # 평지로 되돌리기
		 $land->[$x][$y] = $HlandPlains;
		 $landValue->[$x][$y] = 0;
		 next;
		}
	 }

	 if($addpop < 0) {
		# 부족
		$lv -= (random(-$addpop) + 1);
		if($lv <= 0) {
		 # 평지로 되돌리기
		 $land->[$x][$y] = $HlandSea;
		 $landValue->[$x][$y] = 0;
		 next;
		}
	 } else {
		# 성장
		if($lv < 750) {
		 $lv += random($addpop) + 1;
		 if($lv> 750) {
			$lv = 750;
		 }
		} else {
		 # 도시가 되면성장지연이
		 if($addpop2> 0) {
			$lv += random($addpop2) + 1;
		 }
		}
	 }
	 if($lv> 4000) {
		$lv = 4000;
	 }
	 $landValue->[$x][$y] = $lv;

	} elsif($landKind == $HlandRizort) {
	 # 리조트계

 # 관광은 좋습니다
 if(($lv < 400) && (rand(500) < 15+$s06b*2)) {
 my(@order) = randomArray($HislandNumber);
 my($migrate);

 # 관광선을 탐색
 my($tIsland);
 my($n) = min($HislandNumber, 5);
 my($i);
 for($i = 0; $i < $n; $i++) { # 5섬까지조사하기
 $tIsland = $Hislands[$order[$i]];

	 $tetc5 = $tIsland->{'etc5'};
	 $tetc5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	 ($ts00,$ts01,$ts02,$ts03,$ts04,$ts05,$ts06,$ts07,$ts08,$ts09,$ts10,$ts11,$ts12,$ts13,$ts14,$ts15,$ts16,$ts17,$ts18,$ts19,$ts20,$ts21,$ts22,$ts23,$ts24,$ts25,$ts26,$ts27,$ts28,$ts29,$ts30) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);
	 $ts06b = int($ts06/5);

 # 인구의 많음이 섬에 관광하다
 if ($island->{'pop'} < $tIsland->{'pop'}) {
		my($seaCount) = countAround($land, $x, $y, $HlandSea, 19);
		my($forestCount) = countAround($land, $x, $y, $HlandForest, 19);
		my($mountainCount) = countAround($land, $x, $y, $HlandMountain, 19);
		my($parkCount) = countAround($land, $x, $y, $HlandPark, 19);
		my($kyujoCount) = countAround($land, $x, $y, $HlandKyujo, 19);
		my($kyujoCount) = countAround($land, $x, $y, $HlandKyujokai, 19);
		my($umiamuCount) = countAround($land, $x, $y, $HlandUmiamu, 19);
		my($sunahamaCount) = countAround($land, $x, $y, $HlandSunahama, 19);
		my($rizortCount) = (countAround($land, $x, $y, $HlandRizort, 19) + countAround($land, $x, $y, $HlandKajino, 19) + countAround($land, $x, $y, $HlandBigRizort, 19));
 $landKind = $land->[$x][$y];
 $lv = $landValue->[$x][$y];
		$migrate = $seaCount*3 + $forestCount*3 + $mountainCount*3 + $parkCount*4 + $kyujoCount*4 + $umiamuCount*7 + $sunahamaCount*10 + $rizortCount*5 + $s06b*10 - $ts06b*10;

			if ($migrate < 0) {
			 $migrate = 1;
			}

		$lv += $migrate;
 logKankouMigrate($id, $tIsland->{'id'}, $name, landName($landKind, $lv), $tIsland->{'name'}, "($x, $y)", $migrate);
 }
 last if ($employed <= 0);
 }

 $island->{'eisei2'} += $migrate;
 $island->{'pop'} += $migrate;
 $tIsland->{'pop'} -= $migrate;

 # 관광객 유입으로 빠져나간 인구를 감소 처리
 my($tLand) = $tIsland->{'land'};
 my($tLandValue) = $tIsland->{'landValue'};
 my($employed) = $migrate;
 my($x, $y, $landKind, $lv);
 for($i = 0; $i < $HpointNumber; $i++) {
 $x = $Hrpx[$i];
 $y = $Hrpy[$i];
 $landKind = $tLand->[$x][$y];
 $lv = $tLandValue->[$x][$y];

 if((($landKind == $HlandTown) && ($lv> 1)) ||
		 (($landKind == $HlandMinato) && ($lv> 1)) ||
		 (($landKind == $HlandProcity) && ($lv> 1)) ||
		 (($landKind == $HlandFrocity) && ($lv> 1)) ||
		 (($landKind == $HlandNewtown) && ($lv> 1)) ||
		 (($landKind == $HlandBigtown) && ($lv> 1)) ||
		 (($landKind == $HlandBettown) && ($lv> 1)) ||
		 (($landKind == $HlandSkycity) && ($lv> 1)) ||
		 (($landKind == $HlandUmicity) && ($lv> 1)) ||
		 (($landKind == $HlandSeatown) && ($lv> 1)) ||
		 (($landKind == $HlandRizort) && ($lv> 1)) ||
		 (($landKind == $HlandKajino) && ($lv> 1)) ||
		 (($landKind == $HlandBigRizort) && ($lv> 1)) ||
		 (($landKind == $HlandShuto) && ($lv> 1)) ||
		 (($landKind == $HlandUmishuto) && ($lv> 1)) ||
		 (($landKind == $HlandOnsen) && ($lv> 1)) ||
		 (($landKind == $HlandSeacity) && ($lv> 1))) {
 # 읍
 $n = min($lv - 1, $employed);
 $tLandValue->[$x][$y] -= $n;
 $employed -= $n;

			if($tLandValue->[$x][$y] <= 0) {
			 $tLand->[$x][$y] = $HlandPlains;
			 $tLandValue->[$x][$y] = 0;
			}

 }
 }
	}

	 if($addpop < 0) {
		# 부족
		$lv -= (random(-$addpop) + 1);
		if($lv <= 0) {
		 # 평지로 되돌리기
		 $land->[$x][$y] = $HlandPlains;
		 $landValue->[$x][$y] = 0;
		 next;
		}
	 } else {
		# 성장
		if($lv < 10) {
		 $lv += random($addpop) + 1;
		 if($lv> 10) {
			$lv = 10;
		 }
		} else {
		 if($addpop2> 0) {
			$lv += random($addpop2) + 1;
		 }
		}
	 }
	 if($lv> 400) {
		$lv = 400;
	 }
	 $landValue->[$x][$y] = $lv;

		my($seaCount) = countAround($land, $x, $y, $HlandSea, 7);
		my($forestCount) = countAround($land, $x, $y, $HlandForest, 7);
		my($mountainCount) = countAround($land, $x, $y, $HlandMountain, 7);
		my($sunahamaCount) = countAround($land, $x, $y, $HlandSunahama, 7);
		my($onsenCount) = countAround($land, $x, $y, $HlandOnsen, 7);
		my($parkCount) = countAround($land, $x, $y, $HlandPark, 7);
		my($kajinoCount) = countAround($land, $x, $y, $HlandKajino, 7);

		$miryoku = ((2*$seaCount/10)+(5*$forestCount/10)+(5*$mountainCount/10)+(20*$sunahamaCount/10)+(20*$onsenCount/10)+(10*$parkCount/10)+(2*$kajinoCount/10))+1;

 my($value);
 $value = $miryoku * ($lv+$island->{'eis1'}+$island->{'eis2'}+$island->{'eis3'}+$island->{'eis5'}+int($island->{'fore'}/10)+int($island->{'rena'}/25)-$island->{'monsterlive'}*100);

	 if($island->{'shouhi'}> $island->{'ene'}) {
 $value = int($value/2);
 }

 if ($value> 0) {
 $rizortincome += int($value);
		$island->{'money'} += int($value);
 }

	} elsif($landKind == $HlandBigRizort) {
	 # 리조트계

 # 관광은 좋습니다
 if(($lv < 1000) && (rand(500) < 20+$s06b*2)) {
 my(@order) = randomArray($HislandNumber);
 my($migrate);

 # 관광선을 탐색
 my($tIsland);
 my($n) = min($HislandNumber, 5);
 my($i);
 for($i = 0; $i < $n; $i++) { # 5섬까지조사하기
 $tIsland = $Hislands[$order[$i]];

	 $tetc5 = $tIsland->{'etc5'};
	 $tetc5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	 ($ts00,$ts01,$ts02,$ts03,$ts04,$ts05,$ts06,$ts07,$ts08,$ts09,$ts10,$ts11,$ts12,$ts13,$ts14,$ts15,$ts16,$ts17,$ts18,$ts19,$ts20,$ts21,$ts22,$ts23,$ts24,$ts25,$ts26,$ts27,$ts28,$ts29,$ts30) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);
	 $ts06b = int($ts06/5);

 # 인구의 많음이 섬에 관광하다
 if ($island->{'pop'} < $tIsland->{'pop'}) {
		my($seaCount) = countAround($land, $x, $y, $HlandSea, 19);
		my($forestCount) = countAround($land, $x, $y, $HlandForest, 19);
		my($mountainCount) = countAround($land, $x, $y, $HlandMountain, 19);
		my($parkCount) = countAround($land, $x, $y, $HlandPark, 19);
		my($kyujoCount) = countAround($land, $x, $y, $HlandKyujo, 19);
		my($kyujoCount) = countAround($land, $x, $y, $HlandKyujokai, 19);
		my($umiamuCount) = countAround($land, $x, $y, $HlandUmiamu, 19);
		my($sunahamaCount) = countAround($land, $x, $y, $HlandSunahama, 19);
		my($rizortCount) = (countAround($land, $x, $y, $HlandRizort, 19) + countAround($land, $x, $y, $HlandKajino, 19) + countAround($land, $x, $y, $HlandBigRizort, 19));
 $landKind = $land->[$x][$y];
 $lv = $landValue->[$x][$y];
		$migrate = $seaCount*3 + $forestCount*3 + $mountainCount*3 + $parkCount*4 + $kyujoCount*4 + $umiamuCount*7 + $sunahamaCount*10 + $rizortCount*5 + $s06b*10 - $ts06b*10;

			if ($migrate < 0) {
			 $migrate = 1;
			}

		$lv += $migrate;
 logKankouMigrate($id, $tIsland->{'id'}, $name, landName($landKind, $lv), $tIsland->{'name'}, "($x, $y)", $migrate);
 }
 last if ($employed <= 0);
 }

 $island->{'eisei2'} += $migrate;
 $island->{'pop'} += $migrate;
 $tIsland->{'pop'} -= $migrate;

 # 관광객 유입으로 빠져나간 인구를 감소 처리
 my($tLand) = $tIsland->{'land'};
 my($tLandValue) = $tIsland->{'landValue'};
 my($employed) = $migrate;
 my($x, $y, $landKind, $lv);
 for($i = 0; $i < $HpointNumber; $i++) {
 $x = $Hrpx[$i];
 $y = $Hrpy[$i];
 $landKind = $tLand->[$x][$y];
 $lv = $tLandValue->[$x][$y];

 if((($landKind == $HlandTown) && ($lv> 1)) ||
		 (($landKind == $HlandMinato) && ($lv> 1)) ||
		 (($landKind == $HlandProcity) && ($lv> 1)) ||
		 (($landKind == $HlandFrocity) && ($lv> 1)) ||
		 (($landKind == $HlandNewtown) && ($lv> 1)) ||
		 (($landKind == $HlandBigtown) && ($lv> 1)) ||
		 (($landKind == $HlandBettown) && ($lv> 1)) ||
		 (($landKind == $HlandSkycity) && ($lv> 1)) ||
		 (($landKind == $HlandUmicity) && ($lv> 1)) ||
		 (($landKind == $HlandSeatown) && ($lv> 1)) ||
		 (($landKind == $HlandRizort) && ($lv> 1)) ||
		 (($landKind == $HlandKajino) && ($lv> 1)) ||
		 (($landKind == $HlandBigRizort) && ($lv> 1)) ||
		 (($landKind == $HlandShuto) && ($lv> 1)) ||
		 (($landKind == $HlandUmishuto) && ($lv> 1)) ||
		 (($landKind == $HlandOnsen) && ($lv> 1)) ||
		 (($landKind == $HlandSeacity) && ($lv> 1))) {
 # 읍
 $n = min($lv - 1, $employed);
 $tLandValue->[$x][$y] -= $n;
 $employed -= $n;

			if($tLandValue->[$x][$y] <= 0) {
			 $tLand->[$x][$y] = $HlandPlains;
			 $tLandValue->[$x][$y] = 0;
			}

 }
 }
	}

	 if($addpop < 0) {
		# 부족
		$lv -= (random(-$addpop) + 1);
		if($lv <= 0) {
		 # 평지로 되돌리기
		 $land->[$x][$y] = $HlandPlains;
		 $landValue->[$x][$y] = 0;
		 next;
		}
	 } else {
		# 성장
		if($lv < 10) {
		 $lv += random($addpop) + 1;
		 if($lv> 10) {
			$lv = 10;
		 }
		} else {
		 if($addpop2> 0) {
			$lv += random($addpop2) + 1;
		 }
		}
	 }
	 if($lv> 1000) {
		$lv = 1000;
	 }
	 $landValue->[$x][$y] = $lv;

	my($monsterCount) =
	 countAround($land, $x, $y, $HlandMonster, 7);
 if($monsterCount> 0) {
	 $lv -= random(20)+10;
	 $landValue->[$x][$y] = $lv;
	 logMonsAttacks($id, $name, landName($landKind, $lv), "($x, $y)");
		if($lv <= 0) {
		 # 평지로 되돌리기
		 $land->[$x][$y] = $HlandWaste;
		 $landValue->[$x][$y] = 0;
		 next;
		}
	 }
	} elsif($landKind == $HlandKajino) {
	 # 리조트계

 # 관광은 좋습니다
 if(($lv < 2000) && (rand(500) < 15+$s06b*2)) {
 my(@order) = randomArray($HislandNumber);
 my($migrate);

 # 관광선을 탐색
 my($tIsland);
 my($n) = min($HislandNumber, 5);
 my($i);
 for($i = 0; $i < $n; $i++) { # 5섬까지조사하기
 $tIsland = $Hislands[$order[$i]];

	 $tetc5 = $tIsland->{'etc5'};
	 $tetc5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	 ($ts00,$ts01,$ts02,$ts03,$ts04,$ts05,$ts06,$ts07,$ts08,$ts09,$ts10,$ts11,$ts12,$ts13,$ts14,$ts15,$ts16,$ts17,$ts18,$ts19,$ts20,$ts21,$ts22,$ts23,$ts24,$ts25,$ts26,$ts27,$ts28,$ts29,$ts30) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);
	 $ts06b = int($ts06/5);

 # 인구의 많음이 섬에 관광하다
 if ($island->{'pop'} < $tIsland->{'pop'}) {
		my($seaCount) = countAround($land, $x, $y, $HlandSea, 19);
		my($forestCount) = countAround($land, $x, $y, $HlandForest, 19);
		my($mountainCount) = countAround($land, $x, $y, $HlandMountain, 19);
		my($parkCount) = countAround($land, $x, $y, $HlandPark, 19);
		my($kyujoCount) = countAround($land, $x, $y, $HlandKyujo, 19);
		my($kyujoCount) = countAround($land, $x, $y, $HlandKyujokai, 19);
		my($umiamuCount) = countAround($land, $x, $y, $HlandUmiamu, 19);
		my($sunahamaCount) = countAround($land, $x, $y, $HlandSunahama, 19);
		my($rizortCount) = (countAround($land, $x, $y, $HlandRizort, 19) + countAround($land, $x, $y, $HlandKajino, 19) + countAround($land, $x, $y, $HlandBigRizort, 19));
 $landKind = $land->[$x][$y];
 $lv = $landValue->[$x][$y];
		$migrate = $seaCount*3 + $forestCount*3 + $mountainCount*3 + $parkCount*4 + $kyujoCount*4 + $umiamuCount*7 + $sunahamaCount*10 + $rizortCount*5 + $s06b*10 - $ts06b*10;

			if ($migrate < 0) {
			 $migrate = 1;
			}

		$lv += $migrate;
 logKankouMigrate($id, $tIsland->{'id'}, $name, landName($landKind, $lv), $tIsland->{'name'}, "($x, $y)", $migrate);
 }
 last if ($employed <= 0);
 }

 $island->{'eisei2'} += $migrate;
 $island->{'pop'} += $migrate;
 $tIsland->{'pop'} -= $migrate;

 # 관광객 유입으로 빠져나간 인구를 감소 처리
 my($tLand) = $tIsland->{'land'};
 my($tLandValue) = $tIsland->{'landValue'};
 my($employed) = $migrate;
 my($x, $y, $landKind, $lv);
 for($i = 0; $i < $HpointNumber; $i++) {
 $x = $Hrpx[$i];
 $y = $Hrpy[$i];
 $landKind = $tLand->[$x][$y];
 $lv = $tLandValue->[$x][$y];

 if((($landKind == $HlandTown) && ($lv> 1)) ||
		 (($landKind == $HlandMinato) && ($lv> 1)) ||
		 (($landKind == $HlandProcity) && ($lv> 1)) ||
		 (($landKind == $HlandFrocity) && ($lv> 1)) ||
		 (($landKind == $HlandNewtown) && ($lv> 1)) ||
		 (($landKind == $HlandBigtown) && ($lv> 1)) ||
		 (($landKind == $HlandBettown) && ($lv> 1)) ||
		 (($landKind == $HlandSkycity) && ($lv> 1)) ||
		 (($landKind == $HlandUmicity) && ($lv> 1)) ||
		 (($landKind == $HlandSeatown) && ($lv> 1)) ||
		 (($landKind == $HlandRizort) && ($lv> 1)) ||
		 (($landKind == $HlandKajino) && ($lv> 1)) ||
		 (($landKind == $HlandBigRizort) && ($lv> 1)) ||
		 (($landKind == $HlandShuto) && ($lv> 1)) ||
		 (($landKind == $HlandUmishuto) && ($lv> 1)) ||
		 (($landKind == $HlandOnsen) && ($lv> 1)) ||
		 (($landKind == $HlandSeacity) && ($lv> 1))) {
 # 읍
 $n = min($lv - 1, $employed);
 $tLandValue->[$x][$y] -= $n;
 $employed -= $n;

			if($tLandValue->[$x][$y] <= 0) {
			 $tLand->[$x][$y] = $HlandPlains;
			 $tLandValue->[$x][$y] = 0;
			}

 }
 }
	}

	 if($addpop < 0) {
		# 부족
		$lv -= (random(-$addpop) + 1);
		if($lv <= 0) {
		 # 평지로 되돌리기
		 $land->[$x][$y] = $HlandPlains;
		 $landValue->[$x][$y] = 0;
		 next;
		}
	 } else {
		# 성장
		if($lv < 10) {
		 $lv += random($addpop) + 1;
		 if($lv> 10) {
			$lv = 10;
		 }
		} else {
		 if($addpop2> 0) {
			$lv += random($addpop2) + 1;
		 }
		}
	 }
	 if($lv> 2500) {
		$lv = 2500;
	 }
	 $landValue->[$x][$y] = $lv;

		my($seaCount) = countAround($land, $x, $y, $HlandSea, 7);
		my($forestCount) = countAround($land, $x, $y, $HlandForest, 7);
		my($mountainCount) = countAround($land, $x, $y, $HlandMountain, 7);
		my($sunahamaCount) = countAround($land, $x, $y, $HlandSunahama, 7);
		my($onsenCount) = countAround($land, $x, $y, $HlandOnsen, 7);
		my($parkCount) = countAround($land, $x, $y, $HlandPark, 7);
		my($kajinoCount) = countAround($land, $x, $y, $HlandRizort, 7);

		$miryoku = ((2*$seaCount/10)+(5*$forestCount/10)+(5*$mountainCount/10)+(20*$sunahamaCount/10)+(20*$onsenCount/10)+(10*$parkCount/10)+(2*$kajinoCount/10))+1;

 my($value);
 $value = int(($lv+$island->{'eis1'}+$island->{'eis2'}+$island->{'eis3'}+$island->{'eis5'}+int($island->{'fore'}/10)+int($island->{'rena'}/10)-$island->{'monsterlive'}*100) / 5 * $miryoku);

	 if($island->{'shouhi'}> $island->{'ene'}) {
 $value = -($value*10);

		$lv -= (random(250) + 100);
		if($lv <= 0) {
		 # 평지로 되돌리기
		 $land->[$x][$y] = $HlandPlains;
		 $landValue->[$x][$y] = 0;
		 next;
		}
		$landValue->[$x][$y] = $lv;

 }

 $rizortincome += int($value);
		$island->{'money'} += int($value);

	my($monsterCount) =
	 countAround($land, $x, $y, $HlandMonster, 7);
 if($monsterCount> 0) {
	 $lv -= random(20)+10;
	 $landValue->[$x][$y] = $lv;
	 logMonsAttacks($id, $name, landName($landKind, $lv), "($x, $y)");
		if($lv <= 0) {
		 # 평지로 되돌리기
		 $land->[$x][$y] = $HlandWaste;
		 $landValue->[$x][$y] = 0;
		 next;
		}
	 }

	} elsif($landKind == $HlandOnsen) {
	 # 온천계
	 if($addpop < 0) {
		# 부족
		$lv -= (random(-$addpop) + 1);
		if($lv <= 0) {
		 # 평지로 되돌리기
		 $land->[$x][$y] = $HlandPlains;
		 $landValue->[$x][$y] = 0;
		 next;
		}
	 } else {
		# 성장
		if($lv < 50) {
		 $lv += random($addpop) + 1;
		 if($lv> 50) {
			$lv = 50;
		 }
		} else {
		 # 도시가 되면성장지연이
		 if($addpop2> 0) {
			$lv += random($addpop2) + 1;
		 }
		}
	 }
	 if($lv> 100) {
		$lv = 100;
	 }
	 $landValue->[$x][$y] = $lv;

 my($nt) = (countAround($land, $x, $y, $HlandTown, 19) + countAround($land, $x, $y, $HlandProcity, 19) + countAround($land, $x, $y, $HlandMinato, 19) + countAround($land, $x, $y, $HlandSeacity, 19) + countAround($land, $x, $y, $HlandFrocity, 19) + countAround($land, $x, $y, $HlandNewtown, 19) + countAround($land, $x, $y, $HlandBigtown, 19) + countAround($land, $x, $y, $HlandBettown, 19) + countAround($land, $x, $y, $HlandSkycity, 19) + countAround($land, $x, $y, $HlandUmicity, 19) + countAround($land, $x, $y, $HlandSeatown, 19) + countAround($land, $x, $y, $HlandOnsen, 19) + countAround($land, $x, $y, $HlandShuto, 19) + countAround($land, $x, $y, $HlandUmishuto, 19) + countAround($land, $x, $y, $HlandRizort, 19) + countAround($land, $x, $y, $HlandKajino, 19) + countAround($land, $x, $y, $HlandBigRizort, 19));
 my($value);
 $value = random($nt * 20 + $lv * 5 + int($island->{'pop'} / 20)) + random(100) + 100;
 if ($value> 0) {
 $island->{'money'} += $value;

 # 수입 로그
 my($str) = "$value$HunitMoney";
 logOilMoney($id, $name, landName($landKind, $lv), "($x, $y)", $str);
 }

	 # 고갈판정
	 if(random(1000) < 10) {
		# 고갈
		logOilEnd($id, $name, landName($landKind, $lv), "($x, $y)");
		$land->[$x][$y] = $HlandMountain;
		$landValue->[$x][$y] = 0;
	 }

	} elsif($landKind == $HlandOil) {
	 # 해저 유전
	 my($value, $str, $lName);
	 $lName = landName($landKind, $lv);
	 $value = $HoilMoney+ random(1001);
	 $island->{'money'} += $value;
	 $str = "$value$HunitMoney";
	 $oilincome += $value;

	 # 고갈판정
	 if(random(1000) < $HoilRatio) {
		# 고갈
		logOilEnd($id, $name, $lName, "($x, $y)");
		$land->[$x][$y] = $HlandSea;
		$landValue->[$x][$y] = 0;
	 }

	} elsif(($landKind == $HlandSea) && ($lv == 1)) {
	 # 얕은 바다
	 if(random(100) < 5) {

		$land->[$x][$y] = $HlandSunahama;
		$landValue->[$x][$y] = 0;

	 }
	 if(random(100) < 1) {

		$land->[$x][$y] = $HlandIce;
		$landValue->[$x][$y] = 0;

	 }

	} elsif($landKind == $HlandSunahama) {
	 # 얕은 바다
	 if(random(100) < 30) {

		$land->[$x][$y] = $HlandSea;
		$landValue->[$x][$y] = 1;

	 }

	} elsif($landKind == $HlandIce) {
	 # 얕은 바다
	 my($lv) = $landValue->[$x][$y];

	 if($lv> 0) {
	 my($value, $str, $lName);
	 $lName = landName($landKind, $lv);
	 $value = $lv * 25 + random(501);
	 $island->{'money'} += $value;
	 $str = "$value$HunitMoney";
	 # 수입 로그
	 logOilMoney($id, $name, $lName, "($x, $y)", $str);
	 }

	 if(random(100) < 10) {
		$land->[$x][$y] = $HlandSea;
		$landValue->[$x][$y] = 1;
	 }

	} elsif($landKind == $HlandSeki) {
	 # 관문
	 if(random(1000) < 7) {

	 my($value, $str, $lName);
	 $lName = landName($landKind, $lv);
	 $value = $HoilMoney+ random(1001);
	 $island->{'money'} += $value;
	 $str = "$value$HunitMoney";

	 # 수입 로그
	 logSekiMoney($id, $name, $lName, "($x, $y)", $str);

	 }

	} elsif($landKind == $HlandYakusho) {

		if(($island->{'co0'}> 0) &&
		 ($island->{'co01'}> 0) &&
		 ($island->{'co2'}> 0) &&
		 ($island->{'co3'}> 0) &&
		 ($island->{'co4'}> 0) &&
		 ($island->{'co5'}> 0) &&
		 ($island->{'co6'}> 0) &&
		 ($island->{'co7'}> 0) &&
		 ($island->{'co8'}> 0) &&
		 ($island->{'eis7'}> 1000000) &&
		 ($island->{'rena'}> 10000) &&
		 ($island->{'pts'}> $HouseLevel7)) {
		$land->[$x][$y] = $HlandCollege;
		$landValue->[$x][$y] = 77;
		}

	} elsif($landKind == $HlandGold) {
	 # 금광산
	 my($lv) = $landValue->[$x][$y];
	 my($value, $str, $lName);
	 $lName = landName($landKind, $lv);
	 $value = $lv * 25 + random(501);
	 $island->{'money'} += $value;
	 $str = "$value$HunitMoney";

	 # 수입 로그
	 logOilMoney($id, $name, $lName, "($x, $y)", $str);

	 # 고갈판정
	 if(random(100) < 7) {
		# 고갈
		logGoldEnd($id, $name, $lName, "($x, $y)");
		$land->[$x][$y] = $HlandMountain;
	 }

 } elsif($landKind == $HlandPark) {
 # 놀이공원
 if ($island->{'par'}> 5) {
 } else {
 my($lName);
 $lName = landName($landKind, $lv);
 my($nv) = (countAround($land, $x, $y, $HlandPark, 7) + countAround($land, $x, $y, $HlandKyujo, 7) + countAround($land, $x, $y, $HlandKyujokai, 7) + countAround($land, $x, $y, $HlandUmiamu, 7));
 my($nx) = $nv + 10;
 my($value);
 $value = int(int($island->{'pop'} / 50) * 3 * $nx / 10);

	 if($island->{'shouhi'}> $island->{'ene'}) {
 $value = int($value/10);
 }

 if ($value> 0) {
 $island->{'money'} += $value;
 $str = "$value$HunitMoney";
	 $parkincome += $value;
 }
 }

 # 이벤트판정
 if(random(100) < 3) { # 매 턴 30% 확률로 이벤트가 발생하다
 # 놀이공원의 이벤트
 $value = int($island->{'pop'} / 50) * 10; # 인구 5천 명마다1000톤의 식량소비
 $island->{'food'} -= $value;
 $str = "$value$HunitFood";

 logParkEvent($id, $name, landName($landKind, $lv), "($x, $y)", $str) if ($value> 0);
 }

 # 노후화판정
 if(random(100) < 2) {
 # 시설이 노후화했기 때문에 폐원
 logParkEnd($id, $name, landName($landKind, $lv), "($x, $y)");
 $land->[$x][$y] = $HlandPlains;
 $landValue->[$x][$y] = 0;
 }


 } elsif($landKind == $HlandZoo) {

	 $etc6 = $island->{'etc6'};
	 $etc6 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	 ($z0,$z1,$z2,$z3,$z4,$z5,$z6,$z7,$z8,$z9,$z10,$z11,$z12,$z13,$z14,$z15,$z16,$z17,$z18,$z19,$z20,$z21,$z22,$z23,$z24,$z25,$z26,$z27,$z28,$z29,$z30) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);
	 ($z->{'0'},$z->{'1'},$z->{'2'},$z->{'3'},$z->{'4'},$z->{'5'},$z->{'6'},$z->{'7'},$z->{'8'},$z->{'9'},$z->{'10'},$z->{'11'},$z->{'12'},$z->{'13'},$z->{'14'},$z->{'15'},$z->{'16'},$z->{'17'},$z->{'18'},$z->{'19'},$z->{'20'},$z->{'21'},$z->{'22'},$z->{'23'},$z->{'24'},$z->{'25'},$z->{'26'},$z->{'27'},$z->{'28'},$z->{'29'},$z->{'30'}) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);

	 $zookazu = $z0+$z1+$z2+$z3+$z4+$z5+$z6+$z7+$z8+$z9+$z10+$z11+$z12+$z13+$z14+$z15+$z16+$z17+$z18+$z19+$z20+$z21+$z22+$z23+$z24+$z25+$z26+$z27+$z28+$z29+$z30;
	 $zookazus = $z0*2+$z1+$z2+$z3+$z4+$z5+$z6+$z7+$z8*2+$z9+$z10+$z11+$z12*2+$z13*3+$z14*3+$z15*3+$z16*3+$z17*4+$z18*4+$z19*5+$z20*4+$z21*5+$z22*3+$z23*3+$z24*3+$z25*3+$z26*3+$z27*3+$z28*4+$z29+$z30*4;

 # 놀이공원
 if ($zooflag> 0) {

 } else {

	 $zooflag = 1;
	 $mshurui = 0;
	 foreach $i (0..30) {
		 if($z->{"$i"}> 0) {
			$mshurui++;
		 }
	 }

 my($lName);
 $lName = landName($landKind, $lv);
 my($value);
 $value = $zookazus*15+$mshurui*150;
 $valuef = $zookazu*250;

	 if($island->{'shouhi'}> $island->{'ene'}) {
 $value = int($value/10);
 }


 if(random(1000) < 25 + $s08) {
		my($i,$sx,$sy);
		my($zlv) = (0);
		for($i = 0; $i < $HpointNumber; $i++){
		 $sx = $Hrpx[$i];
		 $sy = $Hrpy[$i];
			if($land->[$sx][$sy] == $HlandZoo){
			 $zlv += $landValue->[$sx][$sy];
			}
		}

		my($siire);
		$siire = random(12);
	 if(random(100) < 20) {
			$siire = random(10)+13;
	 }

		$prize = $island->{'prize'};
		my($flags, $monsters, $turns);
		$prize =~ /([0-9]*),([0-9]*),(.*)/;
		$flags = $1;
		$monsters= $2;
		$turns = $3;
		$prize = '';
		$f = 1;
		for($i = 0; $i < $HmonsterNumber; $i++) {
		 if($monsters & $f) {
			$taiji->{"$i"}++;
		 }
		 $f *= 2;
		}

		if(($taiji->{"$siire"}> 0) && ($zlv> $zookazu)) {
		$z->{"$siire"}++;
		$value = $value*$siire;
 logSiire($id, $name, landName($landKind, $lv), "$HmonsterName[$siire]", "($x, $y)");
		$island->{'etc6'} = "$z->{'0'},$z->{'1'},$z->{'2'},$z->{'3'},$z->{'4'},$z->{'5'},$z->{'6'},$z->{'7'},$z->{'8'},$z->{'9'},$z->{'10'},$z->{'11'},$z->{'12'},$z->{'13'},$z->{'14'},$z->{'15'},$z->{'16'},$z->{'17'},$z->{'18'},$z->{'19'},$z->{'20'},$z->{'21'},$z->{'22'},$z->{'23'},$z->{'24'},$z->{'25'},$z->{'26'},$z->{'27'},$z->{'28'},$z->{'29'},$z->{'30'}";
		}

 }

 if ($value> 0) {
 $island->{'money'} += $value;
 # 수입 로그
 my($str) = "$value$HunitMoney";
 my($str2) = "$valuef$HunitFood";
 logOilMoney2($id, $name, landName($landKind, $lv), "($x, $y)", $str, $str2);
 }

 }


		if(($island->{'rena'} < $zookazus*25) && (random(100) < 15)) {
		$nigekaiju = random(30);
	 if ($z->{"$nigekaiju"}> 0) {
			$z->{"$nigekaiju"} -= 1;
			$kind = $nigekaiju;
			$lv = $lv = ($kind << 4)
			+ $HmonsterBHP[$kind] + random($HmonsterDHP[$kind]);
			$land->[$x][$y] = $HlandMonster;
			$landValue->[$x][$y] = $lv;
			my($mKind, $mName, $mHp) = monsterSpec($lv);
			logNige($id, $name, landName($landKind, $lv), $mName, "($x, $y)");
			logMonsMove($id, $name, landName($landKind, $lv), "($x, $y)", $mName);
			$island->{'etc6'} = "$z->{'0'},$z->{'1'},$z->{'2'},$z->{'3'},$z->{'4'},$z->{'5'},$z->{'6'},$z->{'7'},$z->{'8'},$z->{'9'},$z->{'10'},$z->{'11'},$z->{'12'},$z->{'13'},$z->{'14'},$z->{'15'},$z->{'16'},$z->{'17'},$z->{'18'},$z->{'19'},$z->{'20'},$z->{'21'},$z->{'22'},$z->{'23'},$z->{'24'},$z->{'25'},$z->{'26'},$z->{'27'},$z->{'28'},$z->{'29'},$z->{'30'}";
	 }
		}

		if(($island->{'rena'} < $zookazus*50) || ($island->{'shouhi'}> $island->{'ene'})) {
		$nigekaiju = random(30);
	 if ($z->{"$nigekaiju"}> 0) {
			$nigeflag = 0;
			my($i, $sx, $sy, $kind, $lv);
			for($i = 1; $i < 7; $i++) {
			 $sx = $x + $ax[$i];
			 $sy = $y + $ay[$i];

			 # 행 기준 위치 조정
			 if((($sy % 2) == 0) && (($y % 2) == 1)) {
				$sx--;
			 }

			 $landKind = $land->[$sx][$sy];
			 $lv = $landValue->[$sx][$sy];
			 $point = "($sx, $sy)";

			 if(($sx < 0) || ($sx>= $HislandSize) ||
			 ($sy < 0) || ($sy>= $HislandSize)) {
			 } else {
				# 범위 안의 경우
				$landKind = $land->[$sx][$sy];
				$lv = $landValue->[$sx][$sy];
				$point = "($sx, $sy)";
				if(($landKind == $HlandSea) ||
				 ($landKind == $HlandIce) ||
				 ($landKind == $HlandOil) ||
				 ($landKind == $HlandFune) ||
				 ($landKind == $HlandFrocity) ||
				 ($landKind == $HlandUmiamu) ||
				 ($landKind == $HlandSeacity) ||
				 ($landKind == $HlandSeatown) ||
				 ($landKind == $HlandMonster) ||
				 ($landKind == $HlandZoo) ||
				 ($landKind == $HlandUmishuto) ||
				 ($landKind == $HlandSbase)) {
				} else {
				 if ($nigeflag == 0) {
					$nigeflag++;
					$z->{"$nigekaiju"} -= 1;
					$kind = $nigekaiju;
					$lv = $lv = ($kind << 4)
					+ $HmonsterBHP[$kind] + random($HmonsterDHP[$kind]);
					$land->[$sx][$sy] = $HlandMonster;
					$landValue->[$sx][$sy] = $lv;
					my($mKind, $mName, $mHp) = monsterSpec($lv);
					logNige($id, $name, landName($landKind, $lv), $mName, "($x, $y)");
					$island->{'etc6'} = "$z->{'0'},$z->{'1'},$z->{'2'},$z->{'3'},$z->{'4'},$z->{'5'},$z->{'6'},$z->{'7'},$z->{'8'},$z->{'9'},$z->{'10'},$z->{'11'},$z->{'12'},$z->{'13'},$z->{'14'},$z->{'15'},$z->{'16'},$z->{'17'},$z->{'18'},$z->{'19'},$z->{'20'},$z->{'21'},$z->{'22'},$z->{'23'},$z->{'24'},$z->{'25'},$z->{'26'},$z->{'27'},$z->{'28'},$z->{'29'},$z->{'30'}";
				 }
				}
			 }

			}
	 }
		}

 } elsif($landKind == $HlandKyujokai) {

	$yosengameendm=0;
	if($HmaxIsland < 21) {
	 $hcgameseigen=1;
	} else {
	 $hcgameseigen=3;
	}

	$eisei4 = $island->{'eisei4'};
	$eisei4 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	($sto, $std, $stk, $stwin, $stdrow, $stlose, $stwint, $stdrowt, $stloset, $styusho, $stshoka) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11);

	 if(($HislandTurn % 100) == 0) {
		$stwin = 0;
		$stdrow = 0;
		$stlose = 0;
		$stshoka = 1;

		if($island->{'hcsankaflag'} == 0) {
		$stsanka++;
		$island->{'hcsankaflag'} = 1;
		}


		$island->{'eisei4'} = "$sto,$std,$stk,$stwin,$stdrow,$stlose,$stwint,$stdrowt,$stloset,$styusho,$stshoka";

		if ($stsanka == 1) {
		$island->{'stsankahantei'}++;
		}

	 }

	 foreach $i (1..10) {
	 if(($HislandTurn % 100) == $i) {

		if(($stshoka == 1) &&
		 ($yosengameendm == 0) &&
		 ($yosengameend < $hcgameseigen)) {
	 my($tIsland);
	 my($i);
	 for($i = 0; $i < $HislandNumber; $i++) {
	 $tIsland = $Hislands[$i];

		 if ($island->{'id'} == $tIsland->{'id'}){
		 } else {

			$tEisei4 = $tIsland->{'eisei4'};
			$tEisei4 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
			($tSto, $tStd, $tStk, $tStwin, $tStdrow, $tStlose, $tStwint, $tStdrowt, $tStloset, $tStyusho, $tStshoka) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11);


		 if (($tStshoka == 1) &&
			($yosengameendm == 0) &&
			($yosengameend < $hcgameseigen)) {

			$goal=0;
			$tgoal=0;


			for($k = 0; $k < 5; $k++) {
			 if((random($sto)>random($tStd)) &&
				(random($sto)>random($tStk))) {
				$goal++;
			 }
			}
			for($k = 0; $k < 3; $k++) {
			 if((random($tSto)>random($std)) &&
				(random($tSto)>random($stk))) {
				$tgoal++;
			 }
			}

			if($goal> $tgoal) {
			$stwin++;
			$stwint++;
			$stshoka++;
			$tStshoka++;
			$tStlose++;
			$tStloset++;
			$yosengameend++;
			$yosengameendm++;
				my($value);
				$value = (($stwin * 3 + $stdrow) * 1000);

				$auc9 = $island->{'auc9'};
				$auc9 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
				($auc9a, $auc9b, $auc9c, $auc9d, $auc9e) = ($1, $2, $3, $4, $5);
				$auc9c += $value;
				$auc9c2 = int($auc9c/10000);
				$auc9a = $auc9b + $auc9c2 + $auc9d + $auc9e;
				$island->{'auc9'} = "$auc9a,$auc9b,$auc9c,$auc9d,$auc9e";
				$str = "옥션 자금 융통$value$HunitMoney";

				logHCwin($id, $name, "승리", $str);
				my($stup);
				$stup = random(3);
				$uphey = int(($sto+$std+$stk)/3);
				$tuphey = int(($tSto+$tStd+$tStk)/3);
				$uppoint = int(($uphey-$tuphey)/2)+5;
				if($stup == 0) {
				 $tSto += $uppoint;
				 $tStd += $uppoint;
				} elsif($stup == 1) {
				 $tStd += $uppoint;
				 $tStk += $uppoint;
				} else {
				 $tStk += $uppoint;
				 $tSto += $uppoint;
				}
			} elsif($goal < $tgoal) {
			$tStwin++;
			$tStwint++;
			$stshoka++;
			$tStshoka++;
			$stlose++;
			$stloset++;
			$yosengameend++;
			$yosengameendm++;
				my($value);
				$value = (($tStwin * 3 + $tStdrow) * 1000);

				$tauc9 = $tIsland->{'auc9'};
				$tauc9 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
				($tauc9a, $tauc9b, $tauc9c, $tauc9d, $tauc9e) = ($1, $2, $3, $4, $5);
				$tauc9c += $value;
				$tauc9c2 = int($tauc9c/10000);
				$tauc9a = $tauc9b + $tauc9c2 + $tauc9d + $tauc9e;
				$tIsland->{'auc9'} = "$tauc9a,$tauc9b,$tauc9c,$tauc9d,$tauc9e";
				$str = "옥션 자금 융통$value$HunitMoney";

				logHCwin($tIsland->{'id'}, $tIsland->{'name'}, "승리", $str);
				my($stup);
				$stup = random(3);
				$uphey = int(($sto+$std+$stk)/3);
				$tuphey = int(($tSto+$tStd+$tStk)/3);
				$uppoint = int(($tuphey-$uphey)/2)+5;
				if($stup == 0) {
				 $sto += $uppoint;
				 $std += $uppoint;
				} elsif($stup == 1) {
				 $std += $uppoint;
				 $stk += $uppoint;
				} else {
				 $stk += $uppoint;
				 $sto += $uppoint;
				}
			} else {
			$stdrow++;
			$stdrowt++;
			$tStdrow++;
			$tStdrowt++;
			$stshoka++;
			$tStshoka++;
			$yosengameend++;
			$yosengameendm++;
			}

			logHCgame($id, $tIsland->{'id'}, $name, $tIsland->{'name'}, landName($landKind, $lv), "Hakoniwa Cup 예선 제1전쟁", $goal, $tgoal);

		 }

			$island->{'eisei4'} = "$sto,$std,$stk,$stwin,$stdrow,$stlose,$stwint,$stdrowt,$stloset,$styusho,$stshoka";
			$tIsland->{'eisei4'} = "$tSto,$tStd,$tStk,$tStwin,$tStdrow,$tStlose,$tStwint,$tStdrowt,$tStloset,$tStyusho,$tStshoka";
		}
		}
		}
	 }
	 }

	 if(($HislandTurn % 100) == 11) {
		if($stshoka == 1) {
			$stwin++;
			$stwint++;
			$stshoka++;
			logHCantiwin($id, $name, "Hakoniwa Cup 예선 제1전쟁은 부전승");
			$island->{'eisei4'} = "$sto,$std,$stk,$stwin,$stdrow,$stlose,$stwint,$stdrowt,$stloset,$styusho,$stshoka";
	 }
	 }

	 foreach $i (11..20) {
	 if(($HislandTurn % 100) == $i) {

		if(($stshoka == 2) &&
		 ($yosengameendm == 0) &&
		 ($yosengameend < $hcgameseigen)) {
	 my($tIsland);
	 my($i);
	 for($i = 0; $i < $HislandNumber; $i++) {
	 $tIsland = $Hislands[$i];

		 if ($island->{'id'} == $tIsland->{'id'}){
		 } else {

			$tEisei4 = $tIsland->{'eisei4'};
			$tEisei4 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
			($tSto, $tStd, $tStk, $tStwin, $tStdrow, $tStlose, $tStwint, $tStdrowt, $tStloset, $tStyusho, $tStshoka) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11);


		 if (($tStshoka == 2) &&
			($yosengameendm == 0) &&
			($yosengameend < $hcgameseigen)) {

			$goal=0;
			$tgoal=0;


			for($k = 0; $k < 5; $k++) {
			 if((random($sto)>random($tStd)) &&
				(random($sto)>random($tStk))) {
				$goal++;
			 }
			}
			for($k = 0; $k < 3; $k++) {
			 if((random($tSto)>random($std)) &&
				(random($tSto)>random($stk))) {
				$tgoal++;
			 }
			}

			if($goal> $tgoal) {
			$stwin++;
			$stwint++;
			$stshoka++;
			$tStshoka++;
			$tStlose++;
			$tStloset++;
			$yosengameend++;
			$yosengameendm++;
				my($value);
				$value = (($stwin * 3 + $stdrow) * 1000);

				$auc9 = $island->{'auc9'};
				$auc9 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
				($auc9a, $auc9b, $auc9c, $auc9d, $auc9e) = ($1, $2, $3, $4, $5);
				$auc9c += $value;
				$auc9c2 = int($auc9c/10000);
				$auc9a = $auc9b + $auc9c2 + $auc9d + $auc9e;
				$island->{'auc9'} = "$auc9a,$auc9b,$auc9c,$auc9d,$auc9e";
				$str = "옥션 자금 융통$value$HunitMoney";

				logHCwin($id, $name, "승리", $str);
				my($stup);
				$stup = random(3);
				$uphey = int(($sto+$std+$stk)/3);
				$tuphey = int(($tSto+$tStd+$tStk)/3);
				$uppoint = int(($uphey-$tuphey)/2)+5;
				if($stup == 0) {
				 $tSto += $uppoint;
				 $tStd += $uppoint;
				} elsif($stup == 1) {
				 $tStd += $uppoint;
				 $tStk += $uppoint;
				} else {
				 $tStk += $uppoint;
				 $tSto += $uppoint;
				}
			} elsif($goal < $tgoal) {
			$tStwin++;
			$tStwint++;
			$stshoka++;
			$tStshoka++;
			$stlose++;
			$stloset++;
			$yosengameend++;
			$yosengameendm++;
				my($value);
				$value = (($tStwin * 3 + $tStdrow) * 1000);

				$tauc9 = $tIsland->{'auc9'};
				$tauc9 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
				($tauc9a, $tauc9b, $tauc9c, $tauc9d, $tauc9e) = ($1, $2, $3, $4, $5);
				$tauc9c += $value;
				$tauc9c2 = int($tauc9c/10000);
				$tauc9a = $tauc9b + $tauc9c2 + $tauc9d + $tauc9e;
				$tIsland->{'auc9'} = "$tauc9a,$tauc9b,$tauc9c,$tauc9d,$tauc9e";
				$str = "옥션 자금 융통$value$HunitMoney";

				logHCwin($tIsland->{'id'}, $tIsland->{'name'}, "승리", $str);
				my($stup);
				$stup = random(3);
				$uphey = int(($sto+$std+$stk)/3);
				$tuphey = int(($tSto+$tStd+$tStk)/3);
				$uppoint = int(($tuphey-$uphey)/2)+5;
				if($stup == 0) {
				 $sto += $uppoint;
				 $std += $uppoint;
				} elsif($stup == 1) {
				 $std += $uppoint;
				 $stk += $uppoint;
				} else {
				 $stk += $uppoint;
				 $sto += $uppoint;
				}
			} else {
			$stdrow++;
			$stdrowt++;
			$tStdrow++;
			$tStdrowt++;
			$stshoka++;
			$tStshoka++;
			$yosengameend++;
			$yosengameendm++;
			}

			logHCgame($id, $tIsland->{'id'}, $name, $tIsland->{'name'}, landName($landKind, $lv), "Hakoniwa Cup 예선 제2전쟁", $goal, $tgoal);

		 }

			$island->{'eisei4'} = "$sto,$std,$stk,$stwin,$stdrow,$stlose,$stwint,$stdrowt,$stloset,$styusho,$stshoka";
			$tIsland->{'eisei4'} = "$tSto,$tStd,$tStk,$tStwin,$tStdrow,$tStlose,$tStwint,$tStdrowt,$tStloset,$tStyusho,$tStshoka";
		}
		}
		}
	 }
	 }

	 if(($HislandTurn % 100) == 21) {
		if($stshoka == 2) {
			$stwin++;
			$stwint++;
			$stshoka++;
			logHCantiwin($id, $name, "Hakoniwa Cup 예선 제2전쟁은 부전승");
			$island->{'eisei4'} = "$sto,$std,$stk,$stwin,$stdrow,$stlose,$stwint,$stdrowt,$stloset,$styusho,$stshoka";
	 }
	 }

	 foreach $i (21..30) {
	 if(($HislandTurn % 100) == $i) {

		if(($stshoka == 3) &&
		 ($yosengameendm == 0) &&
		 ($yosengameend < $hcgameseigen)) {
	 my($tIsland);
	 my($i);
	 for($i = 0; $i < $HislandNumber; $i++) {
	 $tIsland = $Hislands[$i];

		 if ($island->{'id'} == $tIsland->{'id'}){
		 } else {

			$tEisei4 = $tIsland->{'eisei4'};
			$tEisei4 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
			($tSto, $tStd, $tStk, $tStwin, $tStdrow, $tStlose, $tStwint, $tStdrowt, $tStloset, $tStyusho, $tStshoka) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11);


		 if (($tStshoka == 3) &&
			($yosengameendm == 0) &&
			($yosengameend < $hcgameseigen)) {

			$goal=0;
			$tgoal=0;


			for($k = 0; $k < 5; $k++) {
			 if((random($sto)>random($tStd)) &&
				(random($sto)>random($tStk))) {
				$goal++;
			 }
			}
			for($k = 0; $k < 3; $k++) {
			 if((random($tSto)>random($std)) &&
				(random($tSto)>random($stk))) {
				$tgoal++;
			 }
			}

			if($goal> $tgoal) {
			$stwin++;
			$stwint++;
			$stshoka++;
			$tStshoka++;
			$tStlose++;
			$tStloset++;
			$yosengameend++;
			$yosengameendm++;
				my($value);
				$value = (($stwin * 3 + $stdrow) * 1000);

				$auc9 = $island->{'auc9'};
				$auc9 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
				($auc9a, $auc9b, $auc9c, $auc9d, $auc9e) = ($1, $2, $3, $4, $5);
				$auc9c += $value;
				$auc9c2 = int($auc9c/10000);
				$auc9a = $auc9b + $auc9c2 + $auc9d + $auc9e;
				$island->{'auc9'} = "$auc9a,$auc9b,$auc9c,$auc9d,$auc9e";
				$str = "옥션 자금 융통$value$HunitMoney";

				logHCwin($id, $name, "승리", $str);
				my($stup);
				$stup = random(3);
				$uphey = int(($sto+$std+$stk)/3);
				$tuphey = int(($tSto+$tStd+$tStk)/3);
				$uppoint = int(($uphey-$tuphey)/2)+5;
				if($stup == 0) {
				 $tSto += $uppoint;
				 $tStd += $uppoint;
				} elsif($stup == 1) {
				 $tStd += $uppoint;
				 $tStk += $uppoint;
				} else {
				 $tStk += $uppoint;
				 $tSto += $uppoint;
				}
			} elsif($goal < $tgoal) {
			$tStwin++;
			$tStwint++;
			$stshoka++;
			$tStshoka++;
			$stlose++;
			$stloset++;
			$yosengameend++;
			$yosengameendm++;
				my($value);
				$value = (($tStwin * 3 + $tStdrow) * 1000);

				$tauc9 = $tIsland->{'auc9'};
				$tauc9 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
				($tauc9a, $tauc9b, $tauc9c, $tauc9d, $tauc9e) = ($1, $2, $3, $4, $5);
				$tauc9c += $value;
				$tauc9c2 = int($tauc9c/10000);
				$tauc9a = $tauc9b + $tauc9c2 + $tauc9d + $tauc9e;
				$tIsland->{'auc9'} = "$tauc9a,$tauc9b,$tauc9c,$tauc9d,$tauc9e";
				$str = "옥션 자금 융통$value$HunitMoney";

				logHCwin($tIsland->{'id'}, $tIsland->{'name'}, "승리", $str);
				my($stup);
				$stup = random(3);
				$uphey = int(($sto+$std+$stk)/3);
				$tuphey = int(($tSto+$tStd+$tStk)/3);
				$uppoint = int(($tuphey-$uphey)/2)+5;
				if($stup == 0) {
				 $sto += $uppoint;
				 $std += $uppoint;
				} elsif($stup == 1) {
				 $std += $uppoint;
				 $stk += $uppoint;
				} else {
				 $stk += $uppoint;
				 $sto += $uppoint;
				}
			} else {
			$stdrow++;
			$stdrowt++;
			$tStdrow++;
			$tStdrowt++;
			$stshoka++;
			$tStshoka++;
			$yosengameend++;
			$yosengameendm++;
			}

			logHCgame($id, $tIsland->{'id'}, $name, $tIsland->{'name'}, landName($landKind, $lv), "Hakoniwa Cup 예선 제3전쟁", $goal, $tgoal);

		 }

			$island->{'eisei4'} = "$sto,$std,$stk,$stwin,$stdrow,$stlose,$stwint,$stdrowt,$stloset,$styusho,$stshoka";
			$tIsland->{'eisei4'} = "$tSto,$tStd,$tStk,$tStwin,$tStdrow,$tStlose,$tStwint,$tStdrowt,$tStloset,$tStyusho,$tStshoka";
		}
		}
		}
	 }
	 }

	 if(($HislandTurn % 100) == 31) {
		if($stshoka == 3) {
			$stwin++;
			$stwint++;
			$stshoka++;
			logHCantiwin($id, $name, "Hakoniwa Cup 예선 제3전쟁은 부전승");
			$island->{'eisei4'} = "$sto,$std,$stk,$stwin,$stdrow,$stlose,$stwint,$stdrowt,$stloset,$styusho,$stshoka";
	 }
	 }

	 foreach $i (31..40) {
	 if(($HislandTurn % 100) == $i) {

		if(($stshoka == 4) &&
		 ($yosengameendm == 0) &&
		 ($yosengameend < $hcgameseigen)) {
	 my($tIsland);
	 my($i);
	 for($i = 0; $i < $HislandNumber; $i++) {
	 $tIsland = $Hislands[$i];

		 if ($island->{'id'} == $tIsland->{'id'}){
		 } else {

			$tEisei4 = $tIsland->{'eisei4'};
			$tEisei4 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
			($tSto, $tStd, $tStk, $tStwin, $tStdrow, $tStlose, $tStwint, $tStdrowt, $tStloset, $tStyusho, $tStshoka) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11);


		 if (($tStshoka == 4) &&
			($yosengameendm == 0) &&
			($yosengameend < $hcgameseigen)) {

			$goal=0;
			$tgoal=0;


			for($k = 0; $k < 5; $k++) {
			 if((random($sto)>random($tStd)) &&
				(random($sto)>random($tStk))) {
				$goal++;
			 }
			}
			for($k = 0; $k < 3; $k++) {
			 if((random($tSto)>random($std)) &&
				(random($tSto)>random($stk))) {
				$tgoal++;
			 }
			}

			if($goal> $tgoal) {
			$stwin++;
			$stwint++;
			$stshoka++;
			$tStshoka++;
			$tStlose++;
			$tStloset++;
			$yosengameend++;
			$yosengameendm++;
				my($value);
				$value = (($stwin * 3 + $stdrow) * 1000);

				$auc9 = $island->{'auc9'};
				$auc9 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
				($auc9a, $auc9b, $auc9c, $auc9d, $auc9e) = ($1, $2, $3, $4, $5);
				$auc9c += $value;
				$auc9c2 = int($auc9c/10000);
				$auc9a = $auc9b + $auc9c2 + $auc9d + $auc9e;
				$island->{'auc9'} = "$auc9a,$auc9b,$auc9c,$auc9d,$auc9e";
				$str = "옥션 자금 융통$value$HunitMoney";

				logHCwin($id, $name, "승리", $str);
				my($stup);
				$stup = random(3);
				$uphey = int(($sto+$std+$stk)/3);
				$tuphey = int(($tSto+$tStd+$tStk)/3);
				$uppoint = int(($uphey-$tuphey)/2)+5;
				if($stup == 0) {
				 $tSto += $uppoint;
				 $tStd += $uppoint;
				} elsif($stup == 1) {
				 $tStd += $uppoint;
				 $tStk += $uppoint;
				} else {
				 $tStk += $uppoint;
				 $tSto += $uppoint;
				}
			} elsif($goal < $tgoal) {
			$tStwin++;
			$tStwint++;
			$stshoka++;
			$tStshoka++;
			$stlose++;
			$stloset++;
			$yosengameend++;
			$yosengameendm++;
				my($value);
				$value = (($tStwin * 3 + $tStdrow) * 1000);

				$tauc9 = $tIsland->{'auc9'};
				$tauc9 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
				($tauc9a, $tauc9b, $tauc9c, $tauc9d, $tauc9e) = ($1, $2, $3, $4, $5);
				$tauc9c += $value;
				$tauc9c2 = int($tauc9c/10000);
				$tauc9a = $tauc9b + $tauc9c2 + $tauc9d + $tauc9e;
				$tIsland->{'auc9'} = "$tauc9a,$tauc9b,$tauc9c,$tauc9d,$tauc9e";
				$str = "옥션 자금 융통$value$HunitMoney";

				logHCwin($tIsland->{'id'}, $tIsland->{'name'}, "승리", $str);
				my($stup);
				$stup = random(3);
				$uphey = int(($sto+$std+$stk)/3);
				$tuphey = int(($tSto+$tStd+$tStk)/3);
				$uppoint = int(($tuphey-$uphey)/2)+5;
				if($stup == 0) {
				 $sto += $uppoint;
				 $std += $uppoint;
				} elsif($stup == 1) {
				 $std += $uppoint;
				 $stk += $uppoint;
				} else {
				 $stk += $uppoint;
				 $sto += $uppoint;
				}
			} else {
			$stdrow++;
			$stdrowt++;
			$tStdrow++;
			$tStdrowt++;
			$stshoka++;
			$tStshoka++;
			$yosengameend++;
			$yosengameendm++;
			}

			logHCgame($id, $tIsland->{'id'}, $name, $tIsland->{'name'}, landName($landKind, $lv), "Hakoniwa Cup 예선 제4전쟁", $goal, $tgoal);

		 }

			$island->{'eisei4'} = "$sto,$std,$stk,$stwin,$stdrow,$stlose,$stwint,$stdrowt,$stloset,$styusho,$stshoka";
			$tIsland->{'eisei4'} = "$tSto,$tStd,$tStk,$tStwin,$tStdrow,$tStlose,$tStwint,$tStdrowt,$tStloset,$tStyusho,$tStshoka";
		}
		}
		}
	 }
	 }

	 if(($HislandTurn % 100) == 41) {
		if($stshoka == 4) {
			$stwin++;
			$stwint++;
			$stshoka++;
			logHCantiwin($id, $name, "Hakoniwa Cup 예선 제4전쟁은 부전승");
			$island->{'eisei4'} = "$sto,$std,$stk,$stwin,$stdrow,$stlose,$stwint,$stdrowt,$stloset,$styusho,$stshoka";
	 }
	 }

	 foreach $i (42..46) {
	 if(($HislandTurn % 100) == $i) {

		if($stshoka < 6) {
		$stshoka = 11;
		$island->{'eisei4'} = "$sto,$std,$stk,$stwin,$stdrow,$stlose,$stwint,$stdrowt,$stloset,$styusho,$stshoka";
		}

		if(($stshoka == 6) &&
		 ($yosengameendm == 0) &&
		 ($yosengameend < 1)) {
	 my($tIsland);
	 my($i);
	 for($i = 0; $i < $HislandNumber; $i++) {
	 $tIsland = $Hislands[$i];

		 if ($island->{'id'} == $tIsland->{'id'}){
		 } else {

			$tEisei4 = $tIsland->{'eisei4'};
			$tEisei4 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
			($tSto, $tStd, $tStk, $tStwin, $tStdrow, $tStlose, $tStwint, $tStdrowt, $tStloset, $tStyusho, $tStshoka) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11);


		 if (($tStshoka == 6) &&
			($yosengameendm == 0) &&
			($yosengameend < 1)) {

			$goal=0;
			$tgoal=0;


			for($k = 0; $k < 3; $k++) {
			 if((random($sto)>random($tStd)) &&
				(random($sto)>random($tStk))) {
				$goal++;
			 }
			}
			for($k = 0; $k < 3; $k++) {
			 if((random($tSto)>random($std)) &&
				(random($tSto)>random($stk))) {
				$tgoal++;
			 }
			}
			if($goal == $tgoal) {
				if(random(100) < 60) {
				 $goal++;
				} else {
				 $tgoal++;
				}
			}
			if($goal> $tgoal) {
			$stwin++;
			$stwint++;
			$stshoka++;
			$tStshoka = 12;
			$tStlose++;
			$tStloset++;
			$yosengameend++;
			$yosengameendm++;
				my($value);
				$value = (($stwin * 3 + $stdrow) * 1000);

				$auc9 = $island->{'auc9'};
				$auc9 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
				($auc9a, $auc9b, $auc9c, $auc9d, $auc9e) = ($1, $2, $3, $4, $5);
				$auc9c += $value;
				$auc9c2 = int($auc9c/10000);
				$auc9a = $auc9b + $auc9c2 + $auc9d + $auc9e;
				$island->{'auc9'} = "$auc9a,$auc9b,$auc9c,$auc9d,$auc9e";
				$str = "옥션 자금 융통$value$HunitMoney";

				logHCwin($id, $name, "준결승진출", $str);
				my($stup);
				$stup = random(3);
				if($stup == 0) {
				 $tSto += 30;
				} elsif($stup == 1) {
				 $tStd += 30;
				} else {
				 $tStk += 30;
				}
			} elsif($goal < $tgoal) {
			$tStwin++;
			$tStwint++;
			$tStshoka++;
			$stshoka = 12;
			$stlose++;
			$stloset++;
			$yosengameend++;
			$yosengameendm++;
				my($value);
				$value = (($tStwin * 3 + $tStdrow) * 1000);

				$tauc9 = $tIsland->{'auc9'};
				$tauc9 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
				($tauc9a, $tauc9b, $tauc9c, $tauc9d, $tauc9e) = ($1, $2, $3, $4, $5);
				$tauc9c += $value;
				$tauc9c2 = int($tauc9c/10000);
				$tauc9a = $tauc9b + $tauc9c2 + $tauc9d + $tauc9e;
				$tIsland->{'auc9'} = "$tauc9a,$tauc9b,$tauc9c,$tauc9d,$tauc9e";
				$str = "옥션 자금 융통$value$HunitMoney";

				logHCwin($tIsland->{'id'}, $tIsland->{'name'}, "준결승진출", $str);
				my($stup);
				$stup = random(3);
				if($stup == 0) {
				 $sto += 30;
				} elsif($stup == 1) {
				 $std += 30;
				} else {
				 $stk += 30;
				}
			} else {
			$stdrow++;
			$stdrowt++;
			$tStdrow++;
			$tStdrowt++;
			$stshoka++;
			$tStshoka++;
			$yosengameend++;
			$yosengameendm++;
			}

			logHCgame($id, $tIsland->{'id'}, $name, $tIsland->{'name'}, landName($landKind, $lv), "Hakoniwa Cup 준준결승전", $goal, $tgoal);

		 }

			$island->{'eisei4'} = "$sto,$std,$stk,$stwin,$stdrow,$stlose,$stwint,$stdrowt,$stloset,$styusho,$stshoka";
			$tIsland->{'eisei4'} = "$tSto,$tStd,$tStk,$tStwin,$tStdrow,$tStlose,$tStwint,$tStdrowt,$tStloset,$tStyusho,$tStshoka";
		}
		}
		}
	 }
	 }

	 if(($HislandTurn % 100) == 46) {
		if($stshoka == 6) {
			$stwin++;
			$stwint++;
			$stshoka++;
			logHCantiwin($id, $name, "Hakoniwa Cup 준준결승전은 부전승");
			$island->{'eisei4'} = "$sto,$std,$stk,$stwin,$stdrow,$stlose,$stwint,$stdrowt,$stloset,$styusho,$stshoka";
	 }
	 }

	 foreach $i (47..49) {
	 if(($HislandTurn % 100) == $i) {

		if(($stshoka == 7) &&
		 ($yosengameendm == 0) &&
		 ($yosengameend < 1)) {
	 my($tIsland);
	 my($i);
	 for($i = 0; $i < $HislandNumber; $i++) {
	 $tIsland = $Hislands[$i];

		 if ($island->{'id'} == $tIsland->{'id'}){
		 } else {

			$tEisei4 = $tIsland->{'eisei4'};
			$tEisei4 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
			($tSto, $tStd, $tStk, $tStwin, $tStdrow, $tStlose, $tStwint, $tStdrowt, $tStloset, $tStyusho, $tStshoka) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11);


		 if (($tStshoka == 7) &&
			($yosengameendm == 0) &&
			($yosengameend < 1)) {

			$goal=0;
			$tgoal=0;


			for($k = 0; $k < 3; $k++) {
			 if((random($sto)>random($tStd)) &&
				(random($sto)>random($tStk))) {
				$goal++;
			 }
			}
			for($k = 0; $k < 3; $k++) {
			 if((random($tSto)>random($std)) &&
				(random($tSto)>random($stk))) {
				$tgoal++;
			 }
			}
			if($goal == $tgoal) {
				if(random(100) < 60) {
				 $goal++;
				} else {
				 $tgoal++;
				}
			}
			if($goal> $tgoal) {
			$stwin++;
			$stwint++;
			$stshoka++;
			$tStshoka = 13;
			$tStlose++;
			$tStloset++;
			$yosengameend++;
			$yosengameendm++;
				my($value);
				$value = (($stwin * 3 + $stdrow) * 1000);

				$auc9 = $island->{'auc9'};
				$auc9 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
				($auc9a, $auc9b, $auc9c, $auc9d, $auc9e) = ($1, $2, $3, $4, $5);
				$auc9c += $value;
				$auc9c2 = int($auc9c/10000);
				$auc9a = $auc9b + $auc9c2 + $auc9d + $auc9e;
				$island->{'auc9'} = "$auc9a,$auc9b,$auc9c,$auc9d,$auc9e";
				$str = "옥션 자금 융통$value$HunitMoney";

				logHCwin($id, $name, "결승진출", $str);
				my($stup);
				$stup = random(3);
				if($stup == 0) {
				 $tSto += 30;
				} elsif($stup == 1) {
				 $tStd += 30;
				} else {
				 $tStk += 30;
				}
			} elsif($goal < $tgoal) {
			$tStwin++;
			$tStwint++;
			$tStshoka++;
			$stshoka = 13;
			$stlose++;
			$stloset++;
			$yosengameend++;
			$yosengameendm++;
				my($value);
				$value = (($tStwin * 3 + $tStdrow) * 1000);

				$tauc9 = $tIsland->{'auc9'};
				$tauc9 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
				($tauc9a, $tauc9b, $tauc9c, $tauc9d, $tauc9e) = ($1, $2, $3, $4, $5);
				$tauc9c += $value;
				$tauc9c2 = int($tauc9c/10000);
				$tauc9a = $tauc9b + $tauc9c2 + $tauc9d + $tauc9e;
				$tIsland->{'auc9'} = "$tauc9a,$tauc9b,$tauc9c,$tauc9d,$tauc9e";
				$str = "옥션 자금 융통$value$HunitMoney";

				logHCwin($tIsland->{'id'}, $tIsland->{'name'}, "결승진출", $str);
				my($stup);
				$stup = random(3);
				if($stup == 0) {
				 $sto += 30;
				} elsif($stup == 1) {
				 $std += 30;
				} else {
				 $stk += 30;
				}
			} else {
			$stdrow++;
			$stdrowt++;
			$tStdrow++;
			$tStdrowt++;
			$stshoka++;
			$tStshoka++;
			$yosengameend++;
			$yosengameendm++;
			}

			logHCgame($id, $tIsland->{'id'}, $name, $tIsland->{'name'}, landName($landKind, $lv), "Hakoniwa Cup 준결승전", $goal, $tgoal);

		 }

			$island->{'eisei4'} = "$sto,$std,$stk,$stwin,$stdrow,$stlose,$stwint,$stdrowt,$stloset,$styusho,$stshoka";
			$tIsland->{'eisei4'} = "$tSto,$tStd,$tStk,$tStwin,$tStdrow,$tStlose,$tStwint,$tStdrowt,$tStloset,$tStyusho,$tStshoka";
		}
		}
		}
	 }
	 }

	 if(($HislandTurn % 100) == 49) {
		if($stshoka == 7) {
			$stwin++;
			$stwint++;
			$stshoka++;
			logHCantiwin($id, $name, "Hakoniwa Cup 준결승전은 부전승");
			$island->{'eisei4'} = "$sto,$std,$stk,$stwin,$stdrow,$stlose,$stwint,$stdrowt,$stloset,$styusho,$stshoka";
	 }
	 }

	 foreach $i (50..51) {
	 if(($HislandTurn % 100) == $i) {

		if(($stshoka == 8) &&
		 ($yosengameendm == 0) &&
		 ($yosengameend < 1)) {
	 my($tIsland);
	 my($i);
	 for($i = 0; $i < $HislandNumber; $i++) {
	 $tIsland = $Hislands[$i];

		 if ($island->{'id'} == $tIsland->{'id'}){
		 } else {

			$tEisei4 = $tIsland->{'eisei4'};
			$tEisei4 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
			($tSto, $tStd, $tStk, $tStwin, $tStdrow, $tStlose, $tStwint, $tStdrowt, $tStloset, $tStyusho, $tStshoka) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11);


		 if (($tStshoka == 8) &&
			($yosengameendm == 0) &&
			($yosengameend < 1)) {

			$goal=0;
			$tgoal=0;


			for($k = 0; $k < 3; $k++) {
			 if((random($sto)>random($tStd)) &&
				(random($sto)>random($tStk))) {
				$goal++;
			 }
			}
			for($k = 0; $k < 3; $k++) {
			 if((random($tSto)>random($std)) &&
				(random($tSto)>random($stk))) {
				$tgoal++;
			 }
			}
			if($goal == $tgoal) {
				if(random(100) < 60) {
				 $goal++;
				} else {
				 $tgoal++;
				}
			}
			if($goal> $tgoal) {
			$stwin++;
			$stwint++;
			$styusho++;
			$stshoka++;
			$tStshoka = 14;
			$tStlose++;
			$tStloset++;
			$yosengameend++;
			$yosengameendm++;
				my($value);
				$value = (($stwin * 3 + $stdrow) * 1000)*2;

				$auc9 = $island->{'auc9'};
				$auc9 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
				($auc9a, $auc9b, $auc9c, $auc9d, $auc9e) = ($1, $2, $3, $4, $5);
				$auc9c += $value;
				$auc9c2 = int($auc9c/10000);
				$auc9a = $auc9b + $auc9c2 + $auc9d + $auc9e;
				$island->{'auc9'} = "$auc9a,$auc9b,$auc9c,$auc9d,$auc9e";
				$str = "옥션 자금 융통$value$HunitMoney";

				$yushouflag = 1;
				$yushounamber = $island->{'id'};
				$yushounamber2 = $tIsland->{'id'};

				logHCwin($id, $name, "우승", $str);
				$hcturn = int($HislandTurn/100)*100;
				logHCwintop($id, $name, $hcturn);
				my($stup);
				$stup = random(3);
				if($stup == 0) {
				 $tSto += 50;
				} elsif($stup == 1) {
				 $tStd += 50;
				} else {
				 $tStk += 50;
				}
			} elsif($goal < $tgoal) {
			$tStwin++;
			$tStwint++;
			$tStyusho++;
			$tStshoka++;
			$stshoka = 14;
			$stlose++;
			$stloset++;
			$yosengameend++;
			$yosengameendm++;
				my($value);
				$value = (($tStwin * 3 + $tStdrow) * 1000)*2;

				$tauc9 = $tIsland->{'auc9'};
				$tauc9 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
				($tauc9a, $tauc9b, $tauc9c, $tauc9d, $tauc9e) = ($1, $2, $3, $4, $5);
				$tauc9c += $value;
				$tauc9c2 = int($tauc9c/10000);
				$tauc9a = $tauc9b + $tauc9c2 + $tauc9d + $tauc9e;
				$tIsland->{'auc9'} = "$tauc9a,$tauc9b,$tauc9c,$tauc9d,$tauc9e";
				$str = "옥션 자금 융통$value$HunitMoney";

				$yushouflag = 2;
				$yushounamber = $tIsland->{'id'};
				$yushounamber2 = $island->{'id'};

				logHCwin($tIsland->{'id'}, $tIsland->{'name'}, "우승", $str);
				$hcturn = int($HislandTurn/100)*100;
				logHCwintop($tIsland->{'id'}, $tIsland->{'name'}, $hcturn);
				my($stup);
				$stup = random(3);
				if($stup == 0) {
				 $sto += 50;
				} elsif($stup == 1) {
				 $std += 50;
				} else {
				 $stk += 50;
				}
			} else {
			$stdrow++;
			$stdrowt++;
			$tStdrow++;
			$tStdrowt++;
			$stshoka++;
			$tStshoka++;
			$yosengameend++;
			$yosengameendm++;
			}

			logHCgame($id, $tIsland->{'id'}, $name, $tIsland->{'name'}, landName($landKind, $lv), "Hakoniwa Cup 결승전", $goal, $tgoal);

		 }

			$island->{'eisei4'} = "$sto,$std,$stk,$stwin,$stdrow,$stlose,$stwint,$stdrowt,$stloset,$styusho,$stshoka";
			$tIsland->{'eisei4'} = "$tSto,$tStd,$tStk,$tStwin,$tStdrow,$tStlose,$tStwint,$tStdrowt,$tStloset,$tStyusho,$tStshoka";
		}
		}
		}
	 }
	 }

	 if(($HislandTurn % 100) == 51) {
		if($stshoka == 8) {
			$stwin++;
			$stwint++;
			$stshoka++;
			$styusho++;
			logHCantiwin($id, $name, "Hakoniwa Cup 결승전은 부전승");
				my($value);
				$value = (($stwin * 3 + $stdrow) * 1000)*2;

				$auc9 = $island->{'auc9'};
				$auc9 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
				($auc9a, $auc9b, $auc9c, $auc9d, $auc9e) = ($1, $2, $3, $4, $5);
				$auc9c += $value;
				$auc9c2 = int($auc9c/10000);
				$auc9a = $auc9b + $auc9c2 + $auc9d + $auc9e;
				$island->{'auc9'} = "$auc9a,$auc9b,$auc9c,$auc9d,$auc9e";
				$str = "옥션 자금 융통$value$HunitMoney";

				logHCwin($id, $name, "일단의 우승", $str);
				$hcturn = int($HislandTurn/100)*100;
				logHCwintop($id, $name, $hcturn);
			$island->{'eisei4'} = "$sto,$std,$stk,$stwin,$stdrow,$stlose,$stwint,$stdrowt,$stloset,$styusho,$stshoka";
	 }
	 }

	 if(($HislandTurn % 100) == 52) {
		if($stshoka != 9) {
		$stshoka = 10;
		$island->{'eisei4'} = "$sto,$std,$stk,$stwin,$stdrow,$stlose,$stwint,$stdrowt,$stloset,$styusho,$stshoka";
		}
	 }

	 if(($stshoka == 10) ||
		($stshoka == 11)) {
		my($stup);
		$stup = random(3);
		if($stup == 0) {
		 $sto++;
		} elsif($stup == 1) {
		 $std++;
		} else {
		 $stk++;
		}
		$island->{'eisei4'} = "$sto,$std,$stk,$stwin,$stdrow,$stlose,$stwint,$stdrowt,$stloset,$styusho,$stshoka";
	 }

 # 야구장개정
 if (($island->{'kyu'}> 1) ||
		($island->{'amu'}> 1)) {
 } else {
 my($nt) = (countAround($land, $x, $y, $HlandTown, 19) + countAround($land, $x, $y, $HlandProcity, 19) + countAround($land, $x, $y, $HlandMinato, 19) + countAround($land, $x, $y, $HlandSeacity, 19) + countAround($land, $x, $y, $HlandFrocity, 19) + countAround($land, $x, $y, $HlandNewtown, 19) + countAround($land, $x, $y, $HlandBigtown, 19) + countAround($land, $x, $y, $HlandBettown, 19) + countAround($land, $x, $y, $HlandSkycity, 19) + countAround($land, $x, $y, $HlandUmicity, 19) + countAround($land, $x, $y, $HlandSeatown, 19) + countAround($land, $x, $y, $HlandOnsen, 19) + countAround($land, $x, $y, $HlandShuto, 19) + countAround($land, $x, $y, $HlandUmishuto, 19) + countAround($land, $x, $y, $HlandRizort, 19) + countAround($land, $x, $y, $HlandKajino, 19) + countAround($land, $x, $y, $HlandBigRizort, 19) - 6);
 my($ns) = ( 1 + 2 * countAround($land, $x, $y, $HlandPark, 19));
 my($nr) = ( 1 + 3 * countAround($land, $x, $y, $HlandUmiamu, 19));
 my($nu) = ( 10 + random(10));
 my($value);
 $value = ($nt * $nu * $ns * $nr + int($island->{'pop'} / 25));

	 if($island->{'shouhi'}> $island->{'ene'}) {
 $value = int($value/5);
 }

 if ($value> 0) {
 $island->{'money'} += $value;

 # 수입 로그
 my($str) = "$value$HunitMoney";
 logOilMoney($id, $name, landName($landKind, $lv), "($x, $y)", $str);
 }
 }

 # 이벤트판정
 if(random(100) < 10) { # 매 턴 30% 확률로 이벤트가 발생하다
 # 야구장의 이벤트
 $value = int($island->{'pop'} / 50) * 10; # 인구 5천 명마다1000톤의 식량소비
 $island->{'food'} -= $value;
 $str = "$value$HunitFood";

 logParkEvent($id, $name, landName($landKind, $lv), "($x, $y)", $str) if ($value> 0);
 }


 } elsif($landKind == $HlandKyujo) {
 # 야구장
 if (($island->{'kyu'}> 1) ||
		($island->{'amu'}> 1)) {
 } else {
 my($nt) = (countAround($land, $x, $y, $HlandTown, 19) + countAround($land, $x, $y, $HlandProcity, 19) + countAround($land, $x, $y, $HlandMinato, 19) + countAround($land, $x, $y, $HlandSeacity, 19) + countAround($land, $x, $y, $HlandFrocity, 19) + countAround($land, $x, $y, $HlandNewtown, 19) + countAround($land, $x, $y, $HlandBigtown, 19) + countAround($land, $x, $y, $HlandBettown, 19) + countAround($land, $x, $y, $HlandSkycity, 19) + countAround($land, $x, $y, $HlandUmicity, 19) + countAround($land, $x, $y, $HlandSeatown, 19) + countAround($land, $x, $y, $HlandOnsen, 19) + countAround($land, $x, $y, $HlandShuto, 19) + countAround($land, $x, $y, $HlandUmishuto, 19) + countAround($land, $x, $y, $HlandRizort, 19) + countAround($land, $x, $y, $HlandKajino, 19) + countAround($land, $x, $y, $HlandBigRizort, 19) - 6);
 my($ns) = ( 1 + 2 * countAround($land, $x, $y, $HlandPark, 19));
 my($nr) = ( 1 + 3 * countAround($land, $x, $y, $HlandUmiamu, 19));
 my($nu) = ( 10 + random(10));
 my($value);
 $value = ($nt * $nu * $ns * $nr + int($island->{'pop'} / 25));

	 if($island->{'shouhi'}> $island->{'ene'}) {
 $value = int($value/5);
 }

 if ($value> 0) {
 $island->{'money'} += $value;

 # 수입 로그
 my($str) = "$value$HunitMoney";
 logOilMoney($id, $name, landName($landKind, $lv), "($x, $y)", $str);
 }
 }

 # 이벤트판정
 if(random(100) < 10) { # 매 턴 30% 확률로 이벤트가 발생하다
 # 야구장의 이벤트
 $value = int($island->{'pop'} / 50) * 10; # 인구 5천 명마다1000톤의 식량소비
 $island->{'food'} -= $value;
 $str = "$value$HunitFood";

 logParkEvent($id, $name, landName($landKind, $lv), "($x, $y)", $str) if ($value> 0);
 }

 # 노후화판정
 if(random(100) < 1) {
 # 시설이 노후화했기 때문에 폐원
 logParkEnd($id, $name, landName($landKind, $lv), "($x, $y)");
 $land->[$x][$y] = $HlandPlains;
 $landValue->[$x][$y] = 0;
 }
	 if(random(100) < 3) {
	 my($value, $str, $lName);
	 $lName = landName($landKind, $lv);
	 $value = 500+ random(500);
	 $island->{'money'} += $value;
	 $str = "$value$HunitMoney";
 # 수입 로그
 logYusho($id, $name, $lName, "($x, $y)", $str) if ($value> 0);
	 }

 } elsif($landKind == $HlandUmiamu) {
 # 해상 시설
 if (($island->{'kyu'}> 1) ||
		($island->{'amu'}> 1)) {
 } else {
 my($no) = (countAround($land, $x, $y, $HlandTown, 19) + countAround($land, $x, $y, $HlandProcity, 19) + countAround($land, $x, $y, $HlandMinato, 19) + countAround($land, $x, $y, $HlandSeacity, 19) + countAround($land, $x, $y, $HlandFrocity, 19) + countAround($land, $x, $y, $HlandNewtown, 19) + countAround($land, $x, $y, $HlandBigtown, 19) + countAround($land, $x, $y, $HlandBettown, 19) + countAround($land, $x, $y, $HlandSkycity, 19) + countAround($land, $x, $y, $HlandUmicity, 19) + countAround($land, $x, $y, $HlandSeatown, 19) + countAround($land, $x, $y, $HlandOnsen, 19) + countAround($land, $x, $y, $HlandShuto, 19) + countAround($land, $x, $y, $HlandUmishuto, 19) + countAround($land, $x, $y, $HlandRizort, 19) + countAround($land, $x, $y, $HlandKajino, 19) + countAround($land, $x, $y, $HlandBigRizort, 19) - 3);
 my($np) = ( 1 + 3 * countAround($land, $x, $y, $HlandPark, 19));
 my($nq) = ( 1 + 4 * countAround($land, $x, $y, $HlandKyujo, 19));
 my($nqk) = ( 1 + 4 * countAround($land, $x, $y, $HlandKyujokai, 19));
 my($nu) = ( 5 + random(5));
 my($value);
 $value = ($no * $np * $nq * $nqk * $nu + int($island->{'pop'} / 25)+ random(200));

	 if($island->{'shouhi'}> $island->{'ene'}) {
 $value = int($value/7);
 }

 if ($value> 0) {
 $island->{'money'} += $value;

 # 수입 로그
 my($str) = "$value$HunitMoney";
 logOilMoney($id, $name, landName($landKind, $lv), "($x, $y)", $str);
 }
 }

 # 이벤트판정
 if(random(100) < 10) { # 매 턴 30% 확률로 이벤트가 발생하다
 # 야구장의 이벤트
 $value = int($island->{'pop'} / 50) * 10; # 인구 5천 명마다1000톤의 식량소비
 $island->{'food'} -= $value;
 $str = "$value$HunitFood";

 logParkEvent($id, $name, landName($landKind, $lv), "($x, $y)", $str) if ($value> 0);
 }

 } elsif(($landKind == $HlandRottenSea) && ($lv < 20)) {
 # 오염된 바다
	$landValue->[$x][$y]++;
 my($i, $sx, $sy, $kind, $lv);
 for($i = 1; $i < 7; $i++) {
 $sx = $x + $ax[$i];
 $sy = $y + $ay[$i];

 # 행 기준 위치 조정
 if((($sy % 2) == 0) && (($y % 2) == 1)) {
 $sx--;
 }

		if(($sx < 0) || ($sx>= $HislandSize) ||
		 ($sy < 0) || ($sy>= $HislandSize)) {
		 # 범위 밖
		 next;
		}

 $landKind = $land->[$sx][$sy];
 $lv = $landValue->[$sx][$sy];
	 $lName = landName($landKind, $lv);
		# 바다, 바다 기준, 해저 도시, 유전, 괴수, 산, 기념비이외
		if(($land->[$sx][$sy] != $HlandSea) &&
		 ($land->[$sx][$sy] != $HlandSbase) &&
		 ($land->[$sx][$sy] != $HlandIce) &&
		 ($land->[$sx][$sy] != $HlandSeacity) &&
		 ($land->[$sx][$sy] != $HlandSeatown) &&
		 ($land->[$sx][$sy] != $HlandUmishuto) &&
		 ($land->[$sx][$sy] != $HlandFune) &&
		 ($land->[$sx][$sy] != $HlandFrocity) &&
		 ($land->[$sx][$sy] != $HlandUmiamu) &&
		 ($land->[$sx][$sy] != $HlandOil) &&
		 ($land->[$sx][$sy] != $HlandNursery) &&
		 ($land->[$sx][$sy] != $HlandRottenSea)) {
	 my($n) = countAround($land, $sx, $sy, $HlandRottenSea, 7);
	 my($point) = "($sx, $sy)";
	 if (($n>= 4) && ((rand(1000)+$island->{'m73'}*100) < 300)) {
	 # 주변에오염된 바다가4칸이상있다면 60% 확률로 마심미포함무
	 logRottenSeaGrow($id, $name, $lName, $point);
	 $land->[$sx][$sy] = $HlandRottenSea;
	 $landValue->[$sx][$sy] = 1;
	 } elsif ($n && ((rand(1000)+$island->{'m73'}*100) < 200)) {
	 # 주변에오염된 바다가1칸이상있다면20% 확률로 마심미포함무
	 logRottenSeaGrow($id, $name, $lName, $point);
	 $land->[$sx][$sy] = $HlandRottenSea;
	 $landValue->[$sx][$sy] = 1;
	 }
	 }
	 }

 } elsif(($landKind == $HlandRottenSea) && ($lv>= 20)) {
	$landValue->[$x][$y]++;
		if($landValue->[$x][$y]> 4000) {
		 $land->[$x][$y] = $HlandWaste;
		 $landValue->[$x][$y] = 0;
		} elsif(($landValue->[$x][$y]> 1000) && (random(250) == 0)) {
		 $land->[$x][$y] = $HlandMonument;
		 $landValue->[$x][$y] = 80+random(3);
		} elsif(($landValue->[$x][$y]> 750) && (random(250) == 0)) {
		 $land->[$x][$y] = $HlandMonument;
		 $landValue->[$x][$y] = 73;
		} elsif(($landValue->[$x][$y]> 500) && (random(250) == 0)) {
		 $land->[$x][$y] = $HlandMonument;
		 $landValue->[$x][$y] = 74+random(5);
		} elsif(($landValue->[$x][$y]> 250) && (random(250) == 0)) {
		 $land->[$x][$y] = $HlandMonument;
		 $landValue->[$x][$y] = 87;
		} elsif(($landValue->[$x][$y]> 125) && (random(250) == 0) && ($island->{'m84'} < 4)) {
		 $land->[$x][$y] = $HlandMonument;
		 $landValue->[$x][$y] = 84;
		}

	} elsif($landKind == $HlandCollege) {
	 # 각 요소 꺼내기
	 my($clv) = $landValue->[$x][$y];

	 if($clv == 4) {

	 my($i,$sx,$sy);
	 for($i = 0; $i < $HpointNumber; $i++){
		$sx = $Hrpx[$i];
		$sy = $Hrpy[$i];
	 if($land->[$sx][$sy] == $HlandMonster) {
		# 대상이 되는 괴수각 요소 꺼내기
		my($tKind, $tName, $tHp) = monsterSpec($landValue->[$sx][$sy]);
		my($tlv) = $landValue->[$sx][$sy];
		my($tspecial) = $HmonsterSpecial[$tKind];
		if($tKind == 28) {
		} else {
		 my($ssx, $ssy, $i, $landKind, $landName, $lv, $point);
		 for($i = 0; $i < 7; $i++) {
			$ssx = $sx + $ax[$i];
			$ssy = $sy + $ay[$i];

			# 행 기준 위치 조정
			if((($ssy % 2) == 0) && (($sy % 2) == 1)) {
			 $ssx--;
			}

			$landKind = $land->[$ssx][$ssy];
			$lv = $landValue->[$ssx][$ssy];
			$landName = landName($landKind, $lv);
			$point = "($ssx, $ssy)";

			# 범위 밖 판정
			if(($ssx < 0) || ($ssx>= $HislandSize) ||
			 ($ssy < 0) || ($ssy>= $HislandSize)) {
			 next;
			}

			# 범위에 한분기
			if($i < 1) {
				next;
			} else {
			 # 2헥스
			 if($take < 1) {
			 if(($landKind == $HlandWaste) &&
				($island->{'c28'} == 0)) {
				$eisei5 = $island->{'eisei5'};
				$eisei5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
				($mshp, $msap, $msdp, $mssp, $mswin, $msexe, $tet) = ($1, $2, $3, $4, $5, $6, $7);

				$kind = 28;
				$lv = $lv = ($kind << 4)
				+ $HmonsterBHP[$kind] + random($HmonsterDHP[$kind])+$mshp;
				$land->[$ssx][$ssy] = $HlandMonster;
				$landValue->[$ssx][$ssy] = $lv;
				logMstakeon($id, $name, "생물 대학의 칸코와이노라","($x, $y)");

				$landValue->[$x][$y] = 99;
				$take++;
				$island->{'co99'}++;
				$island->{'monsterlive'}++;
				}
			 }
			}
		 }
		 }
		}
		}
	 }

	 if($clv == 98) {

	 my($i,$sx,$sy);
	 for($i = 0; $i < $HpointNumber; $i++){
		$sx = $Hrpx[$i];
		$sy = $Hrpy[$i];
	 if($land->[$sx][$sy] == $HlandMonster) {
		# 대상이 되는 괴수각 요소 꺼내기
		my($tKind, $tName, $tHp) = monsterSpec($landValue->[$sx][$sy]);
		my($tlv) = $landValue->[$sx][$sy];
		my($tspecial) = $HmonsterSpecial[$tKind];
		if($tKind == 30) {
		} else {
		 my($ssx, $ssy, $i, $landKind, $landName, $lv, $point);
		 for($i = 0; $i < 7; $i++) {
			$ssx = $sx + $ax[$i];
			$ssy = $sy + $ay[$i];

			# 행 기준 위치 조정
			if((($ssy % 2) == 0) && (($sy % 2) == 1)) {
			 $ssx--;
			}

			$landKind = $land->[$ssx][$ssy];
			$lv = $landValue->[$ssx][$ssy];
			$landName = landName($landKind, $lv);
			$point = "($ssx, $ssy)";

			# 범위 밖 판정
			if(($ssx < 0) || ($ssx>= $HislandSize) ||
			 ($ssy < 0) || ($ssy>= $HislandSize)) {
			 next;
			}

			# 범위에 한분기
			if($i < 1) {
				next;
			} else {
			 # 2헥스
			 if($take < 1) {
			 if(($landKind == $HlandWaste) &&
				($island->{'c28'} == 0)) {
				$eisei5 = $island->{'eisei5'};
				$eisei5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
				($mshp, $msap, $msdp, $mssp, $mswin, $msexe, $tet) = ($1, $2, $3, $4, $5, $6, $7);

				$kind = 30;
				$lv = $lv = ($kind << 4)
				+ $HmonsterBHP[$kind] + random($HmonsterDHP[$kind])+$mshp;
				$land->[$ssx][$ssy] = $HlandMonster;
				$landValue->[$ssx][$ssy] = $lv;
				logMstakeon($id, $name, "초신 수테트라","($x, $y)");

				$landValue->[$x][$y] = 99;
				$take++;
				$island->{'co99'}++;
				$island->{'monsterlive'}++;
				}
			 }
			}
		 }
		 }
		}
		}
	 }

	 if($clv == 99) {
		if($island->{'c28'} == 0) {
 $land->[$x][$y] = $HlandPlains;
 $landValue->[$x][$y] = 0;
		logMstakeoff($id, $name, landName($landKind, $lv),"($x, $y)");
		}
	 }

	 if($clv == 80) {
		my($shutoCount) = (0);
		my($houseCount) = (0);
		my($foodimCount) = (0);
		my($htfCount) = (0);
		my($shtfCount) = (0);
		my($i, $sx, $sy, $kind, $lv);
		for($i = 1; $i < 7; $i++) {
		 $sx = $x + $ax[$i];
		 $sy = $y + $ay[$i];

		 # 행 기준 위치 조정
		 if((($sy % 2) == 0) && (($y % 2) == 1)) {
			$sx--;
		 }

		 $landKind = $land->[$sx][$sy];
		 $lv = $landValue->[$sx][$sy];
		 $point = "($sx, $sy)";

		 if(($sx < 0) || ($sx>= $HislandSize) ||
		 ($sy < 0) || ($sy>= $HislandSize)) {
		 } else {
			# 범위 안의 경우
			$landKind = $land->[$sx][$sy];
			$lv = $landValue->[$sx][$sy];
			$point = "($sx, $sy)";
			if(($landKind == $HlandShuto) || ($landKind == $HlandUmishuto)) {
			 $shutoCount++;
			} elsif($landKind == $HlandHouse) {
			 $houseCount++;
			} elsif(($landKind == $HlandFoodim) && ($lv == 500)) {
			 $foodimCount++;
			} elsif(($landKind == $HlandHTFactory) && ($lv == 500)) {
			 $htfCount++;
			} elsif(($landKind == $HlandSHTF) && ($lv == 500)) {
			 $shtfCount++;
			}
		 }
		}

		if(($island->{'ownf'} == 0) && ($shutoCount == 1) && ($houseCount == 1) && ($foodimCount == 1) && ($htfCount == 1) && ($shtfCount == 1)) {
		 my($onm);
		 $onm = $island->{'onm'};
		 logOwnFac($id, $name, landName($land->[$x][$y], $landValue->[$x][$y]),"($x, $y)", "$onm");
		 $land->[$x][$y] = $HlandOWNF;
		 $landValue->[$x][$y] = 111;
			my($i, $sx, $sy, $kind, $lv);
			for($i = 1; $i < 7; $i++) {
			 $sx = $x + $ax[$i];
			 $sy = $y + $ay[$i];
			 if((($sy % 2) == 0) && (($y % 2) == 1)) {
				$sx--;
			 }
			 $landKind = $land->[$sx][$sy];
			 $lv = $landValue->[$sx][$sy];
			 $point = "($sx, $sy)";
			 if(($sx < 0) || ($sx>= $HislandSize) ||
			 ($sy < 0) || ($sy>= $HislandSize)) {
			 } else {
				$landKind = $land->[$sx][$sy];
				$lv = $landValue->[$sx][$sy];
				$point = "($sx, $sy)";
				if(($landKind == $HlandFoodim) && ($lv == 500)) {
				 $land->[$sx][$sy] = $HlandPlains2;
				 $landValue->[$sx][$sy] = 0;
				} elsif(($landKind == $HlandHTFactory) && ($lv == 500)) {
				 $land->[$sx][$sy] = $HlandPlains2;
				 $landValue->[$sx][$sy] = 0;
				} elsif(($landKind == $HlandSHTF) && ($lv == 500)) {
				 $land->[$sx][$sy] = $HlandPlains2;
				 $landValue->[$sx][$sy] = 0;
				}
			 }
			}
		}

	 }

	 if(($clv == 77) || ($clv == 78) || ($clv == 79) || ($clv == 80)) {
		if(($island->{'co0'} < 1) ||
		 ($island->{'co01'} < 1) ||
		 ($island->{'co2'} < 1) ||
		 ($island->{'co3'} < 1) ||
		 ($island->{'co4'} < 1) ||
		 ($island->{'co5'} < 1) ||
		 ($island->{'co6'} < 1) ||
		 ($island->{'co7'} < 1) ||
		 ($island->{'co8'} < 1) ||
		 ($island->{'eis7'} < 1000000) ||
		 ($island->{'rena'} < 10000) ||
		 ($island->{'pts'} < $HouseLevel7)) {
		$land->[$x][$y] = $HlandYakusho;
		$landValue->[$x][$y] = 0;
		}
	 }

	} elsif($landKind == $HlandOWNF) {
	 $ownfe = int($lv/1000);
	 $shts = int($lv/100)%10;
	 $hts = int($lv%100/10);
	 $noujous = $lv%10;
	 $totals = $shts + $hts + $noujous;
	 $etc5 = $island->{'etc5'};
	 $etc5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	 ($s00,$s01,$s02,$s03,$s04,$s05,$s06,$s07,$s08,$s09,$s10,$s11,$s12,$s13,$s14,$s15,$s16,$s17,$s18,$s19,$s20,$s21,$s22,$s23,$s24,$s25,$s26,$s27,$s28,$s29,$s30) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);
	 $costseisaku = $s01+$s03+$s05+$s07+$s09+$s11+$s13+$s15+$s17+$s19+$s21+$s23+$s25+$s27+$s29+$s02+$s04+$s06+$s08+$s10+$s12+$s14+$s16+$s18+$s20+$s22+$s24+$s26+$s28+$s30;

	 my($onm);
	 $onm = $island->{'onm'};
	 my($unemployed);
	 $unemployed = ($island->{'pop'} - ($island->{'farm'} + $island->{'factoryt'} + $island->{'mountain'}) * 10) / $island->{'pop'} * 100;
		if($unemployed < 0) {
		 $unemployed = -1*$unemployed;
		}
		if($island->{'ownf'}> 1) {
		 $land->[$x][$y] = $HlandPlains2;
		 $landValue->[$x][$y] = 0;
		 $island->{'ownf'} -= 1;
		}

	 if($island->{'urikireflag'} == 1) {
			$landValue->[$x][$y] = "$shts$hts$noujous";
		 }

	 if((random(1000) < int($island->{'rena'}/1000)) && ($ownfe == 0)) {
			$landValue->[$x][$y] = "1$shts$hts$noujous";
			logMiyage2($id, $name, "$onm", "($x, $y)", "오염된 바다의 독소시약");
		 }

		my($shutoCount) = (0);
		my($houseCount) = (0);
		my($i, $sx, $sy, $kind, $lv);
		for($i = 1; $i < 7; $i++) {
		 $sx = $x + $ax[$i];
		 $sy = $y + $ay[$i];

		 # 행 기준 위치 조정
		 if((($sy % 2) == 0) && (($y % 2) == 1)) {
			$sx--;
		 }

		 $landKind = $land->[$sx][$sy];
		 $lv = $landValue->[$sx][$sy];
		 $point = "($sx, $sy)";

		 if(($sx < 0) || ($sx>= $HislandSize) ||
		 ($sy < 0) || ($sy>= $HislandSize)) {
		 } else {
			# 범위 안의 경우
			$landKind = $land->[$sx][$sy];
			$lv = $landValue->[$sx][$sy];
			$point = "($sx, $sy)";
			if(($landKind == $HlandShuto) || ($landKind == $HlandUmishuto)) {
			 $shutoCount++;
			} elsif($landKind == $HlandHouse) {
			 $houseCount++;
			}
		 }
		}
			my($i, $sx, $sy, $kind, $lv);
			for($i = 1; $i < 7; $i++) {
			 $sx = $x + $ax[$i];
			 $sy = $y + $ay[$i];
			 if((($sy % 2) == 0) && (($y % 2) == 1)) {
				$sx--;
			 }
			 $landKind = $land->[$sx][$sy];
			 $lv = $landValue->[$sx][$sy];
			 $point = "($sx, $sy)";
			 if(($sx < 0) || ($sx>= $HislandSize) ||
			 ($sy < 0) || ($sy>= $HislandSize)) {
			 } else {
				$landKind = $land->[$sx][$sy];
				$lv = $landValue->[$sx][$sy];
				$point = "($sx, $sy)";
				if(($landKind == $HlandFoodim) && ($lv == 500) && ($noujous < 8) && ((8-$noujous)*20> $unemployed) && ($shutoCount == 1) && ($houseCount == 1) && ($noujous*15 < $costseisaku) && ((24-$totals)*5> $unemployed) && ($totals*5 < $costseisaku) && ($totals*800 < $island->{'rena'}) && ($noujous*1875 < $island->{'rena'})) {
					logOwnFac2($id, $name, landName($land->[$x][$y], $landValue->[$x][$y]), landName($land->[$sx][$sy], $landValue->[$sx][$sy]),"($x, $y)", "$onm");
				 $land->[$sx][$sy] = $HlandPlains2;
				 $landValue->[$sx][$sy] = 0;
				 $landValue->[$x][$y] += 1;
				 $noujous++;
				 $totals++;
				} elsif(($landKind == $HlandHTFactory) && ($lv == 500) && ($hts < 8) && ((8-$hts)*20> $unemployed) && ($shutoCount == 1) && ($houseCount == 1) && ($hts*15 < $costseisaku) && ((24-$totals)*5> $unemployed) && ($totals*5 < $costseisaku) && ($totals*800 < $island->{'rena'}) && ($hts*1875 < $island->{'rena'})) {
					logOwnFac2($id, $name, landName($land->[$x][$y], $landValue->[$x][$y]), landName($land->[$sx][$sy], $landValue->[$sx][$sy]),"($x, $y)", "$onm");
				 $land->[$sx][$sy] = $HlandPlains2;
				 $landValue->[$sx][$sy] = 0;
				 $landValue->[$x][$y] += 10;
				 $hts++;
				 $totals++;
				} elsif(($landKind == $HlandSHTF) && ($lv == 500) && ($shts < 8) && ((8-$shts)*20> $unemployed) && ($shutoCount == 1) && ($houseCount == 1) && ($shts*15 < $costseisaku) && ((24-$totals)*5> $unemployed) && ($totals*5 < $costseisaku) && ($totals*800 < $island->{'rena'}) && ($shts*1875 < $island->{'rena'})) {
					logOwnFac2($id, $name, landName($land->[$x][$y], $landValue->[$x][$y]), landName($land->[$sx][$sy], $landValue->[$sx][$sy]),"($x, $y)", "$onm");
				 $land->[$sx][$sy] = $HlandPlains2;
				 $landValue->[$sx][$sy] = 0;
				 $landValue->[$x][$y] += 100;
				 $shts++;
				 $totals++;
				}
			 }
			}

	} elsif($landKind == $HlandMonument) {

	 # 각 요소 꺼내기
	 my($molv) = $landValue->[$x][$y];

	 if(($molv == 0) ||
		($molv == 15) ||
		($molv == 16) ||
	 ($molv == 10)) {
	 if(random(100) < 5) {
		 # 수확
		 my($value, $str, $lName);
		 $lName = landName($landKind, $lv);
		 $value = 1+ random(49);
		 $island->{'money'} += $value;
		 $str = "$value$HunitMoney";
	 logMiyage($id, $name, $lName, "($x, $y)", $str) if ($value> 0);
		 }
	 } elsif($molv == 1) {
	 if(random(100) < 1) {
		 # 수확
		 my($value, $str, $lName);
		 $lName = landName($landKind, $lv);
	 $value = int($island->{'pop'} / 100) * 10+ random(11); # 인구 5천 명마다1000톤의 식량소비
	 $island->{'food'} += $value;
	 $str = "$value$HunitFood";

	 logParkEventt($id, $name, $lName, "($x, $y)", $str) if ($value> 0);
		 }

	 } elsif($molv == 80) {
	 if(random(100) < 5) {
		 # 알부활
		 for($i = 0; $i < 7; $i++) {
			$sx = $x + $ax[$i];
			$sy = $y + $ay[$i];

			# 행 기준 위치 조정
			if((($sy % 2) == 0) && (($y % 2) == 1)) {
			 $sx--;
			}

			$landKind = $land->[$sx][$sy];
			$lv = $landValue->[$sx][$sy];
			$landName = landName($landKind, $lv);
			$point = "($sx, $sy)";

			# 범위 밖 판정
			if(($sx < 0) || ($sx>= $HislandSize) ||
			 ($sy < 0) || ($sy>= $HislandSize)) {
			 next;
			}

			# 범위에 한분기
			if($i < 1) {
			 # 중심 및 1헥스
		 if(random(100) < 5) {
				$kind = 13; # 미카엘
			 } elsif(random(100) < 25) {
				$kind = 29; # 테트라
			 } elsif(random(100) < 35) {
				$kind = 14; # 스라레제
			 } elsif(random(100) < 25) {
				$kind = 12; # 은네는 무
			 } else {
				$kind = 1; # 이노라(은즈레)
			 }

				$lv = $lv = ($kind << 4)
				 + $HmonsterBHP[$kind] + random($HmonsterDHP[$kind]);
				$land->[$sx][$sy] = $HlandMonster;
				$landValue->[$sx][$sy] = $lv;
				 my($mKind, $mName, $mHp) = monsterSpec($lv);
				 logEggBomb($id, $name, $landName, $mName, $point);

			} else {
			 # 2헥스
			 if(($landKind == $HlandSea) ||
			 ($landKind == $HlandOil) ||
			 ($landKind == $HlandMountain) ||
			 ($landKind == $HlandGold) ||
			 ($landKind == $HlandOnsen) ||
			 ($landKind == $HlandSeacity) ||
			 ($landKind == $HlandUmishuto) ||
			 ($landKind == $HlandSeatown) ||
			 ($landKind == $HlandUmiamu) ||
			 ($landKind == $HlandFune) ||
			 ($landKind == $HlandFrocity) ||
			 ($landKind == $HlandSbase)) {
				next;
			 } else {
				$landName = landName($landKind, $lv);
				logEggDamage($id, $name, $landName, $point);
				$land->[$sx][$sy] = $HlandSea;
				$landValue->[$sx][$sy] = 0;
			 }
			}
		 }
		}

	 } elsif($molv == 81) {
	 if(random(100) < 3) {
		 # 알부활
		 for($i = 0; $i < 7; $i++) {
			$sx = $x + $ax[$i];
			$sy = $y + $ay[$i];

			# 행 기준 위치 조정
			if((($sy % 2) == 0) && (($y % 2) == 1)) {
			 $sx--;
			}

			$landKind = $land->[$sx][$sy];
			$lv = $landValue->[$sx][$sy];
			$landName = landName($landKind, $lv);
			$point = "($sx, $sy)";

			# 범위 밖 판정
			if(($sx < 0) || ($sx>= $HislandSize) ||
			 ($sy < 0) || ($sy>= $HislandSize)) {
			 next;
			}

			# 범위에 한분기
			if($i < 1) {
			 # 중심 및 1헥스
		 if(random(100) < 3) {
				$kind = 13; # 미카엘
			 } elsif(random(100) < 20) {
				$kind = 29; # 테트라
			 } elsif(random(100) < 40) {
				$kind = 14; # 스라레제
			 } elsif(random(100) < 15) {
				$kind = 12; # 은네는 무
			 } else {
				$kind = 1; # 이노라(은즈레)
			 }

				$lv = $lv = ($kind << 4)
				 + $HmonsterBHP[$kind] + random($HmonsterDHP[$kind]);
				$land->[$sx][$sy] = $HlandMonster;
				$landValue->[$sx][$sy] = $lv;
				 my($mKind, $mName, $mHp) = monsterSpec($lv);
				 logEggBomb($id, $name, $landName, $mName, $point);

			} else {
			 # 2헥스
			 if(($landKind == $HlandSea) ||
			 ($landKind == $HlandOil) ||
			 ($landKind == $HlandMountain) ||
			 ($landKind == $HlandGold) ||
			 ($landKind == $HlandOnsen) ||
			 ($landKind == $HlandSeacity) ||
			 ($landKind == $HlandSeatown) ||
			 ($landKind == $HlandUmishuto) ||
			 ($landKind == $HlandUmiamu) ||
			 ($landKind == $HlandFune) ||
			 ($landKind == $HlandFrocity) ||
			 ($landKind == $HlandSbase)) {
				next;
			 } else {
				$landName = landName($landKind, $lv);
				logEggDamage($id, $name, $landName, $point);
				$land->[$sx][$sy] = $HlandSea;
				$landValue->[$sx][$sy] = 0;
			 }
			}
		 }
		}

	 } elsif($molv == 82) {
	 if(random(100) < 3) {
		 # 알부활
		 for($i = 0; $i < 7; $i++) {
			$sx = $x + $ax[$i];
			$sy = $y + $ay[$i];

			# 행 기준 위치 조정
			if((($sy % 2) == 0) && (($y % 2) == 1)) {
			 $sx--;
			}

			$landKind = $land->[$sx][$sy];
			$lv = $landValue->[$sx][$sy];
			$landName = landName($landKind, $lv);
			$point = "($sx, $sy)";

			# 범위 밖 판정
			if(($sx < 0) || ($sx>= $HislandSize) ||
			 ($sy < 0) || ($sy>= $HislandSize)) {
			 next;
			}

			# 범위에 한분기
			if($i < 1) {
			 # 중심 및 1헥스
		 if(random(100) < 3) {
				$kind = 13; # 미카엘
			 } elsif(random(100) < 30) {
				$kind = 29; # 테트라
			 } elsif(random(100) < 40) {
				$kind = 14; # 스라레제
			 } elsif(random(100) < 30) {
				$kind = 12; # 은네는 무
			 } else {
				$kind = 1; # 이노라(은즈레)
			 }

				$lv = $lv = ($kind << 4)
				 + $HmonsterBHP[$kind] + random($HmonsterDHP[$kind]);
				$land->[$sx][$sy] = $HlandMonster;
				$landValue->[$sx][$sy] = $lv;
				 my($mKind, $mName, $mHp) = monsterSpec($lv);
				 logEggBomb($id, $name, $landName, $mName, $point);

			} else {
			 # 2헥스
			 if(($landKind == $HlandSea) ||
			 ($landKind == $HlandOil) ||
			 ($landKind == $HlandMountain) ||
			 ($landKind == $HlandGold) ||
			 ($landKind == $HlandOnsen) ||
			 ($landKind == $HlandSeacity) ||
			 ($landKind == $HlandSeatown) ||
			 ($landKind == $HlandUmishuto) ||
			 ($landKind == $HlandUmiamu) ||
			 ($landKind == $HlandFune) ||
			 ($landKind == $HlandFrocity) ||
			 ($landKind == $HlandSbase)) {
				next;
			 } else {
				$landName = landName($landKind, $lv);
				logEggDamage($id, $name, $landName, $point);
				$land->[$sx][$sy] = $HlandSea;
				$landValue->[$sx][$sy] = 0;
			 }
			}
		 }
		}

	 } elsif($molv == 83) {
	 if(random(100) < 5) {
		 # 알부활
		 for($i = 0; $i < 7; $i++) {
			$sx = $x + $ax[$i];
			$sy = $y + $ay[$i];

			# 행 기준 위치 조정
			if((($sy % 2) == 0) && (($y % 2) == 1)) {
			 $sx--;
			}

			$landKind = $land->[$sx][$sy];
			$lv = $landValue->[$sx][$sy];
			$landName = landName($landKind, $lv);
			$point = "($sx, $sy)";

			# 범위 밖 판정
			if(($sx < 0) || ($sx>= $HislandSize) ||
			 ($sy < 0) || ($sy>= $HislandSize)) {
			 next;
			}

			# 범위에 한분기
			if($i < 1) {
			 # 중심 및 1헥스
		 if(random(100) < 10) {
				$kind = 13; # 미카엘
			 } elsif(random(100) < 25) {
				$kind = 29; # 테트라
			 } elsif(random(100) < 30) {
				$kind = 14; # 스라레제
			 } elsif(random(100) < 30) {
				$kind = 12; # 은네는 무
			 } else {
				$kind = 1; # 이노라(은즈레)
			 }

				$lv = $lv = ($kind << 4)
				 + $HmonsterBHP[$kind] + random($HmonsterDHP[$kind]);
				$land->[$sx][$sy] = $HlandMonster;
				$landValue->[$sx][$sy] = $lv;
				 my($mKind, $mName, $mHp) = monsterSpec($lv);
				 logEggBomb($id, $name, $landName, $mName, $point);

			} else {
			 # 2헥스
			 if(($landKind == $HlandSea) ||
			 ($landKind == $HlandOil) ||
			 ($landKind == $HlandMountain) ||
			 ($landKind == $HlandGold) ||
			 ($landKind == $HlandOnsen) ||
			 ($landKind == $HlandSeacity) ||
			 ($landKind == $HlandSeatown) ||
			 ($landKind == $HlandUmishuto) ||
			 ($landKind == $HlandUmiamu) ||
			 ($landKind == $HlandFune) ||
			 ($landKind == $HlandFrocity) ||
			 ($landKind == $HlandSbase)) {
				next;
			 } else {
				$landName = landName($landKind, $lv);
				logEggDamage($id, $name, $landName, $point);
				$land->[$sx][$sy] = $HlandSea;
				$landValue->[$sx][$sy] = 0;
			 }
			}
		 }
		}

	 } elsif($molv == 84) {
	 if(random(100) < 75) {
		 # 수확
		 my($lName);
		 $lName = landName($landKind, $lv);
	 my($nt) = (countAround($land, $x, $y, $HlandTown, 19) + countAround($land, $x, $y, $HlandProcity, 19) + countAround($land, $x, $y, $HlandMinato, 19) + countAround($land, $x, $y, $HlandSeacity, 19) + countAround($land, $x, $y, $HlandFrocity, 19) + countAround($land, $x, $y, $HlandNewtown, 19) + countAround($land, $x, $y, $HlandBigtown, 19) + countAround($land, $x, $y, $HlandBettown, 19) + countAround($land, $x, $y, $HlandSkycity, 19) + countAround($land, $x, $y, $HlandUmicity, 19) + countAround($land, $x, $y, $HlandSeatown, 19) + countAround($land, $x, $y, $HlandOnsen, 19) + countAround($land, $x, $y, $HlandShuto, 19) + countAround($land, $x, $y, $HlandUmishuto, 19) + countAround($land, $x, $y, $HlandRizort, 19) + countAround($land, $x, $y, $HlandKajino, 19) + countAround($land, $x, $y, $HlandBigRizort, 19));
	 my($value);
	 $value = random($nt * 20 + $lv * 5 + int($island->{'pop'} / 20)) + random(100) + 100;
	 if ($value> 0) {
	 $island->{'money'} += $value;

			$m84income += $value;
	 }
		 }
	 } elsif($molv == 93) {
		 # 행운
		 my($value, $str, $lName);
		 $lName = landName($landKind, $lv);
		 $value = $HoilMoney+ random(500);
		 $island->{'money'} += $value;
		 $str = "$value$HunitMoney";

	 $value = int($island->{'pop'} / 20) + random(11); # 인구 5천 명마다1000톤의 식량소비
	 $island->{'food'} += $value;
	 $str = "$value$HunitFood";

	 } elsif($molv == 94) {

		 my($i,$sx,$sy);
		 for($i = 1; $i < 7; $i++) {
		 $sx = $x + $ax[$i];
		 $sy = $y + $ay[$i];
			 if($land->[$sx][$sy] == $HlandMonster){
				# 주변 2Hex 에 다른 괴수가 있으면 그 괴수를 공격

				# 대상이 되는 괴수각 요소 꺼내기
				my($tKind, $tName, $tHp) = monsterSpec($landValue->[$sx][$sy]);
				my($tlv) = $landValue->[$sx][$sy];
				my($tspecial) = $HmonsterSpecial[$tKind];

				 logBariaAttack($id, $name, $tName, "($sx, $sy)");
			 # 대상의 괴수가 쓰러져 황무지가 됨
				$land->[$sx][$sy] = $HlandWaste;
				$landValue->[$sx][$sy] = 1;
			 next;
			 }
		 }
	 }

	} elsif($landKind == $HlandFrocity) {

	 if($addpop < 0) {
		# 부족
		$lv -= (random(-$addpop) + 1);
		if($lv <= 0) {
		 # 평지로 되돌리기
		 $land->[$x][$y] = $HlandPlains;
		 $landValue->[$x][$y] = 0;
		 next;
		}
	 } else {
		# 성장
		if($lv < 100) {
		 $lv += random($addpop) + 1;
		 if($lv> 100) {
			$lv = 100;
		 }
		} else {
		 # 도시가 되면성장지연이
		 if($addpop2> 0) {
			$lv += random($addpop2) + 1;
		 }
		}
	 }
	 if($lv> 200) {
		$lv = 200;
	 }
	 $landValue->[$x][$y] = $lv;

	 # 이동 방향을 결정
	 my($d, $sx, $sy);
	 my($i);
	 for($i = 0; $i < 3; $i++) {
		$d = random(6) + 1;
		$sx = $x + $ax[$d];
		$sy = $y + $ay[$d];

		# 행 기준 위치 조정
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		 $sx--;
		}

		# 범위 밖 판정
		if(($sx < 0) || ($sx>= $HislandSize) ||
		 ($sy < 0) || ($sy>= $HislandSize)) {
		 next;
		}

		# 바다, 바다 기준, 해저 도시, 유전, 괴수, 산, 기념비이외
		if(($land->[$sx][$sy] != $HlandWaste) &&
		 ($land->[$sx][$sy] != $HlandPlains) &&
		 ($land->[$sx][$sy] != $HlandPlains2) &&
		 ($land->[$sx][$sy] != $HlandTown) &&
		 ($land->[$sx][$sy] != $HlandForest) &&
		 ($land->[$sx][$sy] != $HlandFarm) &&
		 ($land->[$sx][$sy] != $HlandEneAt) &&
		 ($land->[$sx][$sy] != $HlandEneFw) &&
		 ($land->[$sx][$sy] != $HlandEneWt) &&
		 ($land->[$sx][$sy] != $HlandEneWd) &&
		 ($land->[$sx][$sy] != $HlandEneBo) &&
		 ($land->[$sx][$sy] != $HlandEneSo) &&
		 ($land->[$sx][$sy] != $HlandEneCs) &&
		 ($land->[$sx][$sy] != $HlandConden) &&
		 ($land->[$sx][$sy] != $HlandConden2) &&
		 ($land->[$sx][$sy] != $HlandConden3) &&
		 ($land->[$sx][$sy] != $HlandConden4) &&
		 ($land->[$sx][$sy] != $HlandFoodim) &&
		 ($land->[$sx][$sy] != $HlandFoodka) &&
		 ($land->[$sx][$sy] != $HlandFarmchi) &&
		 ($land->[$sx][$sy] != $HlandFarmpic) &&
		 ($land->[$sx][$sy] != $HlandFarmcow) &&
		 ($land->[$sx][$sy] != $HlandCollege) &&
		 ($land->[$sx][$sy] != $HlandYakusho) &&
		 ($land->[$sx][$sy] != $HlandFactory) &&
		 ($land->[$sx][$sy] != $HlandHTFactory) &&
		 ($land->[$sx][$sy] != $HlandSHTF) &&
		 ($land->[$sx][$sy] != $HlandOWNF) &&
		 ($land->[$sx][$sy] != $HlandBase) &&
		 ($land->[$sx][$sy] != $HlandDefence) &&
		 ($land->[$sx][$sy] != $HlandMinato) &&
		 ($land->[$sx][$sy] != $HlandSeki) &&
		 ($land->[$sx][$sy] != $HlandPark) &&
		 ($land->[$sx][$sy] != $HlandHaribote) &&
		 ($land->[$sx][$sy] != $HlandSbase) &&
		 ($land->[$sx][$sy] != $HlandSeacity) &&
		 ($land->[$sx][$sy] != $HlandFune) &&
		 ($land->[$sx][$sy] != $HlandIce) &&
		 ($land->[$sx][$sy] != $HlandFrocity) &&
		 ($land->[$sx][$sy] != $HlandUmiamu) &&
		 ($land->[$sx][$sy] != $HlandOil) &&
		 ($land->[$sx][$sy] != $HlandGold) &&
		 ($land->[$sx][$sy] != $HlandMountain) &&
		 ($land->[$sx][$sy] != $HlandOnsen) &&
		 ($land->[$sx][$sy] != $HlandMonument) &&
		 ($land->[$sx][$sy] != $HlandMine) &&
		 ($land->[$sx][$sy] != $HlandNursery) &&
		 ($land->[$sx][$sy] != $HlandKyujo) &&
		 ($land->[$sx][$sy] != $HlandKyujokai) &&
		 ($land->[$sx][$sy] != $HlandZoo) &&
		 ($land->[$sx][$sy] != $HlandRottenSea) &&
		 ($land->[$sx][$sy] != $HlandProcity) &&
		 ($land->[$sx][$sy] != $HlandNewtown) &&
		 ($land->[$sx][$sy] != $HlandBigtown) &&
		 ($land->[$sx][$sy] != $HlandBettown) &&
		 ($land->[$sx][$sy] != $HlandSkycity) &&
		 ($land->[$sx][$sy] != $HlandUmicity) &&
		 ($land->[$sx][$sy] != $HlandSeatown) &&
		 ($land->[$sx][$sy] != $HlandRizort) &&
		 ($land->[$sx][$sy] != $HlandKajino) &&
		 ($land->[$sx][$sy] != $HlandBigRizort) &&
		 ($land->[$sx][$sy] != $HlandShuto) &&
		 ($land->[$sx][$sy] != $HlandUmishuto) &&
		 ($land->[$sx][$sy] != $HlandHouse) &&
		 ($land->[$sx][$sy] != $HlandTaishi) &&
		 ($land->[$sx][$sy] != $HlandTrain) &&
		 ($land->[$sx][$sy] != $HlandKura) &&
		 ($land->[$sx][$sy] != $HlandKuraf) &&
		 ($land->[$sx][$sy] != $HlandMonster)) {
		 last;
		}
	 }

	 if($i == 3) {
		# 작동없었습니다
		next;
	 }

	 # 이동한 위치의 지형에 따라 처리
	 my($l) = $land->[$sx][$sy];
	 my($lv) = $landValue->[$sx][$sy];
	 my($lName) = landName($l, $lv);
	 my($point) = "($sx, $sy)";

	 # 이동
	 $land->[$sx][$sy] = $land->[$x][$y];
	 $landValue->[$sx][$sy] = $landValue->[$x][$y];

	 # 원래 위치를 황무지로
	 $land->[$x][$y] = $HlandSea;
	 $landValue->[$x][$y] = 0;

	} elsif($landKind == $HlandFune) {
	 # 괴수
	 if($funeMove[$x][$y] == 2) {
		# 이미 이동한 후
		next;
	 }

	 # 각 요소 꺼내기
	 my($flv) = $landValue->[$x][$y];
	 my($funespe) = $HfuneSpecial[$lv];

 # 노후화판정
	 my($lName) = &landName($landKind, $lv);
	 if(($flv == 8) ||
	 ($flv == 9) ||
	 ($flv == 19) ||
	 ($flv == 10)) {
		if(random(1000) < 5) {
 # 시설이 노후화했기 때문에 폐원
 logParkEndf($id, $name, $lName, "($x, $y)");
 $land->[$x][$y] = $HlandSea;
 $landValue->[$x][$y] = 0;
 }
 } else {
		if(random(100) < 3) {
 # 시설이 노후화했기 때문에 폐원
 logParkEndf($id, $name, $lName, "($x, $y)");
 $land->[$x][$y] = $HlandSea;
 $landValue->[$x][$y] = 0;
 }
 }

	 my($flv) = $landValue->[$x][$y];
	 my($funespe) = $HfuneSpecial[$lv];

	 if($flv == 0) {
	 # 수확
	 my($value, $str, $lName);
	 $lName = landName($landKind, $lv);
	 $value = 1+ random(399);
	 $island->{'money'} += $value;
	 $str = "$value$HunitMoney";
 logHoken($id, $name, $lName, "($x, $y)", $str) if ($value> 0);

	 }
	 elsif($flv == 1) {
	 # 수확
	 my($value, $str, $lName);
	 $lName = landName($landKind, $lv);
	 $value = 5;
	 $island->{'money'} -= $value;
	 $str = "$value$HunitMoney";

 $value = 290+ random(30); #
 $island->{'food'} += $value;
 $str = "$value$HunitFood";
 $gyosenincome += $value;

	 }
	 elsif($flv == 2) {
	 # 수확
	 my($value, $str, $lName);
	 $lName = landName($landKind, $lv);
	 $value = 20;
	 $island->{'money'} -= $value;
	 $str = "$value$HunitMoney";

 $value = 490+ random(40); #
 $island->{'food'} += $value;
 $str = "$value$HunitFood";
 $gyosenincome += $value;

	 }
	 elsif($flv == 3) {
	 # 수확
	 my($value, $str, $lName);
	 $lName = landName($landKind, $lv);
	 $value = 300;
	 $island->{'money'} -= $value;
	 $str = "$value$HunitMoney";

		 if(random(1000) < 5) {
		 my($value, $str, $lName);
		 $lName = landName($landKind, $lv);
		 $value = 1+ random(49999);
		 $island->{'money'} += $value;
		 $str = "$value$HunitMoney";
	 # 수입 로그
	 logTansaku($id, $name, $lName, "($x, $y)", $str) if ($value> 0);
		 }
	 }
	 elsif($flv == 4) {
	 # 수확
	 my($value, $str, $lName);
	 $lName = landName($landKind, $lv);
	 $value = 150+ random(250);
	 $island->{'money'} += $value;
	 $str = "$value$HunitMoney";
 # 수입 로그
 logParkMoneyf($id, $name, $lName, "($x, $y)", $str) if ($value> 0);

 $value = 1000; #
 $island->{'food'} -= $value;
 $str = "$value$HunitFood";
	 }
	 elsif($flv == 5) {
	 # 수확
	 my($value, $str, $lName);
	 $lName = landName($landKind, $lv);
	 $value = 60;
	 $island->{'money'} -= $value;
	 $str = "$value$HunitMoney";

 $value = 690+ random(40); #
 $island->{'food'} += $value;
 $str = "$value$HunitFood";
 $gyosenincome += $value;

	 }
	 elsif($flv == 6) {
	 # 수확
	 my($value, $str, $lName);
	 $lName = landName($landKind, $lv);
	 $value = 30;
	 $island->{'money'} -= $value;
	 $str = "$value$HunitMoney";

 $value = 490+ random(40); #
 $island->{'food'} += $value;
 $str = "$value$HunitFood";
 $gyosenincome += $value;

	 }
	 elsif($flv == 7) {
	 # 수확
	 my($value, $str, $lName);
	 $lName = landName($landKind, $lv);
	 $value = 500;
	 $island->{'money'} -= $value;
	 $str = "$value$HunitMoney";

		 if(random(100) < 1) {
		 my($value, $str, $lName);
		 $lName = landName($landKind, $lv);
		 $value = 1+ random(29999);
		 $island->{'money'} += $value;
		 $str = "$value$HunitMoney";
	 # 수입 로그
	 logTansaku($id, $name, $lName, "($x, $y)", $str) if ($value> 0);
		 }
	 }
	 elsif($flv == 8) {
	 # 수확
	 my($value, $str, $lName);
	 $lName = landName($landKind, $lv);
	 $value = 1500+ int($island->{'pop'} / 10) * 1;
	 $island->{'money'} += $value;
	 $str = "$value$HunitMoney";
 # 수입 로그
 logParkMoneyf($id, $name, $lName, "($x, $y)", $str) if ($value> 0);
 $value = 3000; #
 $island->{'food'} -= $value;
 $str = "$value$HunitFood";
 if(random(100) < 10) {
 # 시설이 노후화했기 때문에 폐원
 logTitanic($id, $name, $lName, "($x, $y)");
	 $lName = landName($landKind, $lv);
	 $value = int($island->{'pop'} / 10) * 2;
	 $island->{'money'} += $value;
	 $str = "$value$HunitMoney";
 # 수입 로그
 logTitanicEnd($id, $name, $lName, "($x, $y)", $str) if ($value> 0);

 $land->[$x][$y] = $HlandIce;
 $landValue->[$x][$y] = 0;
 }
	 }

	 elsif($flv == 9) {
	 my($value, $str, $lName);
	 $lName = landName($landKind, $lv);
	 $value = 100;
	 $island->{'money'} -= $value;
	 $str = "$value$HunitMoney";

	 my($i,$sx,$sy);
	 for($i = 0; $i < $HpointNumber; $i++){
		$sx = $Hrpx[$i];
		$sy = $Hrpy[$i];
	 if($land->[$sx][$sy] == $HlandMonster) {
		if($kougekiseigen < 2) {
		# 주변 2Hex 에 다른 괴수가 있으면 그 괴수를 공격

		# 대상이 되는 괴수각 요소 꺼내기
		my($tKind, $tName, $tHp) = monsterSpec($landValue->[$sx][$sy]);
		my($tlv) = $landValue->[$sx][$sy];
		my($tspecial) = $HmonsterSpecial[$tKind];

		if((($tspecial == 3) && (($HislandTurn % 2) == 1)) ||
 (($tspecial == 8) && ((seqnum($HislandTurn) % 2) == 0)) ||
		 (($tspecial == 4) && (($HislandTurn % 2) == 0))) {
		# 대상이 경화 중이면 효과 없음
	 next;
	 }

	 logMonsAttackt($id, $name, $lName, "($x, $y)", $tName, $tPoint);
	 $kougekiseigen++;

	 $tHp--;
	 if($tHp != 0){
	 # 대상의 체력을 감하게 함
	 $tlv--;
		$landValue->[$sx][$sy] = $tlv;
	 }else{
	 # 대상의 괴수가 쓰러져 황무지가 됨
		$land->[$sx][$sy] = $HlandWaste;
		$landValue->[$sx][$sy] = 0;
	 # 포상금
		my($value) = $HmonsterValue[$tKind];
		 $island->{'money'} += $value;
		 logMsMonMoney($id, $tName, $value);
		}
	 next;
	 }
	 }
	}
	}
	 elsif($flv == 10) {
	 my($value, $str, $lName);
	 $lName = landName($landKind, $lv);
	 $value = 400;
	 $island->{'money'} -= $value;
	 $str = "$value$HunitMoney";

	 my($i,$sx,$sy);
	 for($i = 0; $i < $HpointNumber; $i++){
		$sx = $Hrpx[$i];
		$sy = $Hrpy[$i];
	 if($land->[$sx][$sy] == $HlandMonster){
		# 주변 2Hex 에 다른 괴수가 있으면 그 괴수를 공격
	 my($value, $str, $lName);
	 $lName = landName($landKind, $lv);
	 $value = 3000;
	 $island->{'money'} -= $value;
	 $str = "$value$HunitMoney";

		# 대상이 되는 괴수각 요소 꺼내기
		my($tKind, $tName, $tHp) = monsterSpec($landValue->[$sx][$sy]);
		my($tlv) = $landValue->[$sx][$sy];
		my($tspecial) = $HmonsterSpecial[$tKind];
		 logFuneAttack($id, $name, $lName, "($x, $y)", $tName, "($sx, $sy)");

		 my($ssx, $ssy, $i, $landKind, $landName, $lv, $point);

		 for($i = 0; $i < 7; $i++) {
			$ssx = $sx + $ax[$i];
			$ssy = $sy + $ay[$i];

			# 행 기준 위치 조정
			if((($ssy % 2) == 0) && (($sy % 2) == 1)) {
			 $ssx--;
			}

			$landKind = $land->[$ssx][$ssy];
			$lv = $landValue->[$ssx][$ssy];
			$landName = landName($landKind, $lv);
			$point = "($ssx, $ssy)";

			# 범위 밖 판정
			if(($ssx < 0) || ($ssx>= $HislandSize) ||
			 ($ssy < 0) || ($ssy>= $HislandSize)) {
			 next;
			}

			# 범위에 한분기
			if($i < 1) {
			 # 중심 및 1헥스
				$land->[$ssx][$ssy] = $HlandSea;
				$landValue->[$ssx][$ssy] = 1;
				 logFuneMonsterSea($id, $name, $landName, $point);

			} else {
			 # 2헥스
			 if(($landKind == $HlandSea) ||
			 ($landKind == $HlandOil) ||
			 ($landKind == $HlandIce) ||
			 ($landKind == $HlandWaste) ||
			 ($landKind == $HlandMountain) ||
			 ($landKind == $HlandGold) ||
			 ($landKind == $HlandOnsen) ||
			 ($landKind == $HlandSeacity) ||
			 ($landKind == $HlandSeatown) ||
			 ($landKind == $HlandUmishuto) ||
			 ($landKind == $HlandUmiamu) ||
			 ($landKind == $HlandFune) ||
			 ($landKind == $HlandFrocity) ||
			 ($landKind == $HlandSbase)) {
				next;
			 } elsif($landKind == $HlandMonster) {
				logWideDamageMonster($id, $name, $landName, $point);
				$land->[$ssx][$ssy] = $HlandWaste;
				$landValue->[$ssx][$ssy] = 0;
			 } else {
				logWideDamageWaste($id, $name, $landName, $point);
				$land->[$ssx][$ssy] = $HlandWaste;
				$landValue->[$ssx][$ssy] = 0;
			 }
			}
		 }

	 next;
	 }
	}
	}
	 elsif($flv == 11) {
	 # 수확
	 my($value, $str, $lName);
	 $lName = landName($landKind, $lv);
	 $value = 60;
	 $island->{'money'} -= $value;
	 $str = "$value$HunitMoney";

 $value = 690+ random(40); #
 $island->{'food'} += $value;
 $str = "$value$HunitFood";
 $gyosenincome += $value;

	 }

	 elsif($flv == 19) {
	 my($value, $str, $lName);
	 $lName = landName($landKind, $lv);
	 $value = 1000;
	 $island->{'money'} -= $value;
	 $str = "$value$HunitMoney";

	 my($i,$sx,$sy);
	 for($i = 0; $i < $HpointNumber; $i++){
		$sx = $Hrpx[$i];
		$sy = $Hrpy[$i];
	 if($land->[$sx][$sy] == $HlandMonster){
		# 주변 2Hex 에 다른 괴수가 있으면 그 괴수를 공격
	 my($value, $str, $lName);
	 $lName = landName($landKind, $lv);
	 $value = 50000;
	 $island->{'money'} -= $value;
	 $str = "$value$HunitMoney";

		# 대상이 되는 괴수각 요소 꺼내기
		my($tKind, $tName, $tHp) = monsterSpec($landValue->[$sx][$sy]);
		my($tlv) = $landValue->[$sx][$sy];
		my($tspecial) = $HmonsterSpecial[$tKind];
		 logFuneAttackSSS($id, $name, $lName, "($x, $y)", $tName, "($sx, $sy)");
			$land->[$sx][$sy] = $HlandWaste;
			$landValue->[$sx][$sy] = 0;
			$heat++;

		$rena = $island->{'rena'};
		if (rand($rena)> (3000+$heat*1000)) {
		 logFuneAttackSSSR($id, $name, $lName, "($x, $y)", $tName, "($sx, $sy)");
		} else {

		 logFuneAttackSSST($id, $name, $lName, "($x, $y)", $tName, "($sx, $sy)");
		 my($ssx, $ssy, $i, $landKind, $landName, $lv, $point);

		 for($i = 0; $i < 4; $i++) {
			$ssx = $x + $ax[$i];
			$ssy = $y + $ay[$i];

			# 행 기준 위치 조정
			if((($ssy % 2) == 0) && (($y % 2) == 1)) {
			 $ssx--;
			}

			$landKind = $land->[$ssx][$ssy];
			$lv = $landValue->[$ssx][$ssy];
			$landName = landName($landKind, $lv);
			$point = "($ssx, $ssy)";

			# 범위 밖 판정
			if(($ssx < 0) || ($ssx>= $HislandSize) ||
			 ($ssy < 0) || ($ssy>= $HislandSize)) {
			 next;
			}

			# 범위에 한분기
			if($i < 1) {
			 # 중심 및 1헥스
				$land->[$ssx][$ssy] = $HlandSea;
				$landValue->[$ssx][$ssy] = 0;
			} else {
			 # 2헥스
			 if(($landKind == $HlandSea) ||
			 ($landKind == $HlandOil) ||
			 ($landKind == $HlandIce) ||
			 ($landKind == $HlandWaste) ||
			 ($landKind == $HlandMountain) ||
			 ($landKind == $HlandGold) ||
			 ($landKind == $HlandOnsen) ||
			 ($landKind == $HlandSeacity) ||
			 ($landKind == $HlandSeatown) ||
			 ($landKind == $HlandUmishuto) ||
			 ($landKind == $HlandUmiamu) ||
			 ($landKind == $HlandFune) ||
			 ($landKind == $HlandFrocity) ||
			 ($landKind == $HlandSbase)) {
				next;
			 } elsif($landKind == $HlandMonster) {
				logWideDamageMonster($id, $name, $landName, $point);
				$land->[$ssx][$ssy] = $HlandWaste;
				$landValue->[$ssx][$ssy] = 0;
			 } else {
				logWideDamageWaste($id, $name, $landName, $point);
				$land->[$ssx][$ssy] = $HlandWaste;
				$landValue->[$ssx][$ssy] = 0;
			 }
			}
		 }
		}

	 next;
	 }
	}
	}

	 # 이동 방향을 결정
	 my($d, $sx, $sy);
	 my($i);
	 for($i = 0; $i < 3; $i++) {
		$d = random(6) + 1;
		$sx = $x + $ax[$d];
		$sy = $y + $ay[$d];

		# 행 기준 위치 조정
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		 $sx--;
		}

		# 범위 밖 판정
		if(($sx < 0) || ($sx>= $HislandSize) ||
		 ($sy < 0) || ($sy>= $HislandSize)) {
		 next;
		}

		# 바다, 바다 기준, 해저 도시, 유전, 괴수, 산, 기념비이외
		if(($land->[$sx][$sy] != $HlandWaste) &&
		 ($land->[$sx][$sy] != $HlandPlains) &&
		 ($land->[$sx][$sy] != $HlandPlains2) &&
		 ($land->[$sx][$sy] != $HlandTown) &&
		 ($land->[$sx][$sy] != $HlandForest) &&
		 ($land->[$sx][$sy] != $HlandFarm) &&
		 ($land->[$sx][$sy] != $HlandEneAt) &&
		 ($land->[$sx][$sy] != $HlandEneFw) &&
		 ($land->[$sx][$sy] != $HlandEneWt) &&
		 ($land->[$sx][$sy] != $HlandEneWd) &&
		 ($land->[$sx][$sy] != $HlandEneBo) &&
		 ($land->[$sx][$sy] != $HlandEneSo) &&
		 ($land->[$sx][$sy] != $HlandEneCs) &&
		 ($land->[$sx][$sy] != $HlandConden) &&
		 ($land->[$sx][$sy] != $HlandConden2) &&
		 ($land->[$sx][$sy] != $HlandConden3) &&
		 ($land->[$sx][$sy] != $HlandConden4) &&
		 ($land->[$sx][$sy] != $HlandFoodim) &&
		 ($land->[$sx][$sy] != $HlandFoodka) &&
		 ($land->[$sx][$sy] != $HlandFarmchi) &&
		 ($land->[$sx][$sy] != $HlandFarmpic) &&
		 ($land->[$sx][$sy] != $HlandFarmcow) &&
		 ($land->[$sx][$sy] != $HlandCollege) &&
		 ($land->[$sx][$sy] != $HlandYakusho) &&
		 ($land->[$sx][$sy] != $HlandFactory) &&
		 ($land->[$sx][$sy] != $HlandHTFactory) &&
		 ($land->[$sx][$sy] != $HlandSHTF) &&
		 ($land->[$sx][$sy] != $HlandOWNF) &&
		 ($land->[$sx][$sy] != $HlandBase) &&
		 ($land->[$sx][$sy] != $HlandDefence) &&
		 ($land->[$sx][$sy] != $HlandMinato) &&
		 ($land->[$sx][$sy] != $HlandSeki) &&
		 ($land->[$sx][$sy] != $HlandPark) &&
		 ($land->[$sx][$sy] != $HlandHaribote) &&
		 ($land->[$sx][$sy] != $HlandSbase) &&
		 ($land->[$sx][$sy] != $HlandSeacity) &&
		 ($land->[$sx][$sy] != $HlandFune) &&
		 ($land->[$sx][$sy] != $HlandIce) &&
		 ($land->[$sx][$sy] != $HlandFrocity) &&
		 ($land->[$sx][$sy] != $HlandUmiamu) &&
		 ($land->[$sx][$sy] != $HlandOil) &&
		 ($land->[$sx][$sy] != $HlandGold) &&
		 ($land->[$sx][$sy] != $HlandMountain) &&
		 ($land->[$sx][$sy] != $HlandOnsen) &&
		 ($land->[$sx][$sy] != $HlandMonument) &&
		 ($land->[$sx][$sy] != $HlandMine) &&
		 ($land->[$sx][$sy] != $HlandNursery) &&
		 ($land->[$sx][$sy] != $HlandKyujo) &&
		 ($land->[$sx][$sy] != $HlandKyujokai) &&
		 ($land->[$sx][$sy] != $HlandZoo) &&
		 ($land->[$sx][$sy] != $HlandRottenSea) &&
		 ($land->[$sx][$sy] != $HlandProcity) &&
		 ($land->[$sx][$sy] != $HlandNewtown) &&
		 ($land->[$sx][$sy] != $HlandBigtown) &&
		 ($land->[$sx][$sy] != $HlandBettown) &&
		 ($land->[$sx][$sy] != $HlandSkycity) &&
		 ($land->[$sx][$sy] != $HlandUmicity) &&
		 ($land->[$sx][$sy] != $HlandSeatown) &&
		 ($land->[$sx][$sy] != $HlandRizort) &&
		 ($land->[$sx][$sy] != $HlandKajino) &&
		 ($land->[$sx][$sy] != $HlandBigRizort) &&
		 ($land->[$sx][$sy] != $HlandShuto) &&
		 ($land->[$sx][$sy] != $HlandUmishuto) &&
		 ($land->[$sx][$sy] != $HlandHouse) &&
		 ($land->[$sx][$sy] != $HlandTaishi) &&
		 ($land->[$sx][$sy] != $HlandTrain) &&
		 ($land->[$sx][$sy] != $HlandKura) &&
		 ($land->[$sx][$sy] != $HlandKuraf) &&
		 ($land->[$sx][$sy] != $HlandMonster)) {
		 last;
		}
	 }

	 if($i == 3) {
		# 작동없었습니다
		next;
	 }

	 # 이동한 위치의 지형에 따라 처리
	 my($l) = $land->[$sx][$sy];
	 my($lv) = $landValue->[$sx][$sy];
	 my($lName) = landName($l, $lv);
	 my($point) = "($sx, $sy)";

	 # 이동
	 $land->[$sx][$sy] = $land->[$x][$y];
	 $landValue->[$sx][$sy] = $landValue->[$x][$y];

	 # 원래 위치를 황무지로
	 $land->[$x][$y] = $HlandSea;
	 $landValue->[$x][$y] = 0;

		if ($flv == 3) { # 유전 표시
		if (rand(1000) < 30 - $island->{'oil'} * 3)
		{
	 my($l) = $land->[$sx][$sy];
	 my($lv) = $landValue->[$sx][$sy];
	 my($lName) = landName($l, $lv);
	 my($point) = "($x, $y)";
		logTansakuoil($id, $name, $lName, $point);
		$land->[$x][$y] = $HlandOil;
		$landValue->[$x][$y] = 0;
		$island->{'oil'}++;
		}
		}
		elsif ($flv == 7) { # 유전 표시
		if (rand(1000) < 40 - $island->{'oil'} * 4)
		{
	 my($l) = $land->[$sx][$sy];
	 my($lv) = $landValue->[$sx][$sy];
	 my($lName) = landName($l, $lv);
	 my($point) = "($x, $y)";
		logTansakuoil($id, $name, $lName, $point);
		$land->[$x][$y] = $HlandOil;
		$landValue->[$x][$y] = 0;
		$island->{'oil'}++;
		}
		}

	 # 이동 완료 플래그
	 if($funespe == 2) {
		# 이동 완료 플래그가 설정되어 있지 않음
	 } elsif($funespe == 1) {
		# 속이괴수
		$funeMove[$sx][$sy] = $funeMove[$x][$y] + 1;
	 } else {
		# 일반의 괴수
		$funeMove[$sx][$sy] = 2;
	 }

	} elsif($landKind == $HlandMonster) {
	 # 괴수
	 if($monsterMove[$x][$y] == 2) {
		# 이미 이동한 후
		next;
	 }

	 # 각 요소 꺼내기
	 my($mKind, $mName, $mHp) = monsterSpec($landValue->[$x][$y]);
	 my($special) = $HmonsterSpecial[$mKind];

	 if($mKind == 13) {
	 # 행운
	 my($value, $str, $lName);
	 $lName = landName($landKind, $lv);
	 $value = $HoilMoney+ random(500);
	 $island->{'money'} += $value;
	 $str = "$value$HunitMoney";

 $value = int($island->{'pop'} / 20) + random(11); # 인구 5천 명마다1000톤의 식량소비
 $island->{'food'} += $value;
 $str = "$value$HunitFood";

	 }

	 # 경화 중?
	 if((($special == 3) && (($HislandTurn % 2) == 1)) ||
 (($special == 8) && ((seqnum($HislandTurn) % 2) == 0)) ||
	 (($special == 4) && (($HislandTurn % 2) == 0))) {
		# 경화 중
		next;


	 } elsif (($mKind == 16)&&(($HislandTurn % 2) == 0)&&($mHp < 4)&&(rand(1000) < 700)) {
 logMonsBomb($id, $name, $lName, "($x, $y)", $mName);
		# 광역 피해 루틴
		wideDamage($id, $name, $land, $landValue, $x, $y);
		 if (rand(1000) < 250) {
		 $land->[$x][$y] = $HlandMonument;
		 $landValue->[$x][$y] = 78;
		 }

 } elsif ($mKind == 17) {
		my($tx, $ty, $landKind, $lv, $point);
		# 발사
		$tx = random($HislandSize);
		$ty = random($HislandSize);
		$landKind = $land->[$tx][$ty];
		$lv = $landValue->[$tx][$ty];
		$point = "($tx, $ty)";

		if (rand(1000) < 600) {

		 if(($landKind == $HlandSea) ||
			($landKind == $HlandMountain) ||
			($landKind == $HlandGold) ||
			($landKind == $HlandOnsen) ||
			($landKind == $HlandIce) ||
			($landKind == $HlandSeacity) ||
			($landKind == $HlandSeatown) ||
			($landKind == $HlandUmishuto) ||
			($landKind == $HlandUmiamu) ||
			($landKind == $HlandSbase)) {
			logMekaNdamage($id, $name, $mName, "($x, $y)", landName($landKind, $lv), "($tx, $ty)");

			next;
		 }

			$land->[$tx][$ty] = $HlandWaste;
			$landValue->[$tx][$ty] = 1;
			logMekaNmiss($id, $name, $mName, "($x, $y)", landName($landKind, $lv), "($tx, $ty)");


		} elsif (rand(1000) < 400) {
			logMekaSmiss($id, $name, $mName, "($x, $y)", landName($landKind, $lv), "($tx, $ty)");
		 my($ssx, $ssy, $i, $landKind, $landName, $lv, $point);
		 for($i = 0; $i < 7; $i++) {
			$ssx = $tx + $ax[$i];
			$ssy = $ty + $ay[$i];

			# 행 기준 위치 조정
			if((($ssy % 2) == 0) && (($ty % 2) == 1)) {
			 $ssx--;
			}

			$landKind = $land->[$ssx][$ssy];
			$lv = $landValue->[$ssx][$ssy];
			$landName = landName($landKind, $lv);
			$point = "($ssx, $ssy)";

			# 범위 밖 판정
			if(($ssx < 0) || ($ssx>= $HislandSize) ||
			 ($ssy < 0) || ($ssy>= $HislandSize)) {
			 next;
			}

			# 범위에 한분기
			if($i < 1) {
			 # 중심 및 1헥스
			 if(($landKind == $HlandSea) ||
			 ($landKind == $HlandSeacity) ||
			 ($landKind == $HlandSeatown) ||
			 ($landKind == $HlandUmishuto) ||
			 ($landKind == $HlandUmiamu) ||
			 ($landKind == $HlandSbase)) {
				next;
			 }
				$land->[$ssx][$ssy] = $HlandSea;
				$landValue->[$ssx][$ssy] = 1;
				 logFuneMonsterSea($id, $name, $landName, $point);

			} else {
			 # 2헥스
			 if(($landKind == $HlandSea) ||
			 ($landKind == $HlandOil) ||
			 ($landKind == $HlandIce) ||
			 ($landKind == $HlandWaste) ||
			 ($landKind == $HlandMountain) ||
			 ($landKind == $HlandGold) ||
			 ($landKind == $HlandOnsen) ||
			 ($landKind == $HlandSeacity) ||
			 ($landKind == $HlandSeatown) ||
			 ($landKind == $HlandUmishuto) ||
			 ($landKind == $HlandUmiamu) ||
			 ($landKind == $HlandFune) ||
			 ($landKind == $HlandFrocity) ||
			 ($landKind == $HlandSbase)) {
				next;
			 } elsif($landKind == $HlandMonster) {
				logWideDamageMonster($id, $name, $landName, $point);
				$land->[$ssx][$ssy] = $HlandWaste;
				$landValue->[$ssx][$ssy] = 0;
			 } else {
				logWideDamageWaste($id, $name, $landName, $point);
				$land->[$ssx][$ssy] = $HlandWaste;
				$landValue->[$ssx][$ssy] = 0;
			 }
			}
		 }
	 }
		 elsif (rand(1000) < 200) {
			my($sx, $sy, $landKind, $lv, $point);
			# 낙하
			$sx = random($HislandSize);
			$sy = random($HislandSize);
			$landKind = $land->[$sx][$sy];
			$lv = $landValue->[$sx][$sy];
			$point = "($sx, $sy)";

			# 메시지
			logMekaAB($id, $name, $mName, "($x, $y)", landName($landKind, $lv), "($sx, $sy)");

			# 광역 피해 루틴
			wideDamage($id, $name, $land, $landValue, $sx, $sy);
		 }

 } elsif ($mKind == 18) {
		 my($i,$sx,$sy);
		 for($i = 0; $i < $HpointNumber; $i++){
			$sx = $Hrpx[$i];
			$sy = $Hrpy[$i];
		 if($land->[$sx][$sy] == $HlandMonster) {
			# 주변 2Hex 에 다른 괴수가 있으면 그 괴수를 공격

			# 대상이 되는 괴수각 요소 꺼내기
			my($tKind, $tName, $tHp) = monsterSpec($landValue->[$sx][$sy]);
			my($tlv) = $landValue->[$sx][$sy];
			my($tspecial) = $HmonsterSpecial[$tKind];

		 if((($tspecial == 3) && (($HislandTurn % 2) == 1)) ||
	 (($tspecial == 8) && ((seqnum($HislandTurn) % 2) == 0)) ||
			 (($tspecial == 4) && (($HislandTurn % 2) == 0))) {
			# 대상이 경화 중이면 효과 없음
		 next;
		 }
			if (rand(1000) < 600) {
		 if ($tKind == 18) {
			 } elsif(($tKind == 28) ||
				 ($tKind == 30)) {

			 logItiAttackms($id, $name, $mName, "($x, $y)", $tName, $tPoint);
				$dmge = random(4);
				$tHp -= $dmge;
				$tlv -= $dmge;
				$landValue->[$sx][$sy] = $tlv;

				if($tHp < 1){
				# 대상의 괴수가 쓰러져 황무지가 됨
				$land->[$sx][$sy] = $HlandWaste;
				$landValue->[$sx][$sy] = 0;
				# 포상금
				my($value) = $HmonsterValue[$tKind];
				 $island->{'money'} += $value;
				 logMsMonMoney($id, $tName, $value);
				}

			 }else{
			 logItiAttack($id, $name, $mName, "($x, $y)", $tName, $tPoint);

			 # 대상의 괴수가 쓰러져 황무지가 됨
				$land->[$sx][$sy] = $HlandWaste;
				$landValue->[$sx][$sy] = 0;
			 # 포상금
				my($value) = $HmonsterValue[$tKind];
				 $island->{'money'} += $value;
				 logMsMonMoney($id, $tName, $value);
			 }
			}
		 }
		}
		if (rand(1000) < 600) {
		my($tx, $ty, $landKind, $lv, $point);
		# 발사
		$tx = random($HislandSize);
		$ty = random($HislandSize);
		$landKind = $land->[$tx][$ty];
		$lv = $landValue->[$tx][$ty];
		$point = "($tx, $ty)";

		 if(($landKind == $HlandSea) ||
			($landKind == $HlandMountain) ||
			($landKind == $HlandGold)) {
			next;
		 }

			$land->[$tx][$ty] = $HlandSea;
			$landValue->[$tx][$ty] = 1;
			logUrieruMeteo($id, $name, $mName, "($x, $y)", landName($landKind, $lv), "($tx, $ty)");

		 if (rand(1000) < 100) {
		 $land->[$tx][$ty] = $HlandMonument;
		 $landValue->[$tx][$ty] = 79;
		 }

		}


 } elsif ($mKind == 22) {
		 my($i,$sx,$sy);
		 for($i = 0; $i < $HpointNumber; $i++){
			$sx = $Hrpx[$i];
			$sy = $Hrpy[$i];
		 if($land->[$sx][$sy] == $HlandMonster) {
			# 주변 2Hex 에 다른 괴수가 있으면 그 괴수를 공격

			# 대상이 되는 괴수각 요소 꺼내기
			my($tKind, $tName, $tHp) = monsterSpec($landValue->[$sx][$sy]);
			my($tlv) = $landValue->[$sx][$sy];
			my($tspecial) = $HmonsterSpecial[$tKind];

		 if((($tspecial == 3) && (($HislandTurn % 2) == 1)) ||
	 (($tspecial == 8) && ((seqnum($HislandTurn) % 2) == 0)) ||
			 (($tspecial == 4) && (($HislandTurn % 2) == 0))) {
			# 대상이 경화 중이면 효과 없음
		 next;
		 }
			if (rand(1000) < 600) {
		 if ($tKind == 22) {
			 } elsif(($tKind == 28) ||
				 ($tKind == 30)) {

			 logIceAttack($id, $name, $mName, "($x, $y)", $tName, "($sx, $sy)");
				$dmge = random(4);
				$tHp -= $dmge;
				$tlv -= $dmge;
				$landValue->[$sx][$sy] = $tlv;

				if($tHp < 1){
				# 대상의 괴수가 쓰러져 황무지가 됨
				$land->[$sx][$sy] = $HlandWaste;
				$landValue->[$sx][$sy] = 0;
				# 포상금
				my($value) = $HmonsterValue[$tKind];
				 $island->{'money'} += $value;
				 logMsMonMoney($id, $tName, $value);
				}
			 }else{
			 logIceAttack($id, $name, $mName, "($x, $y)", $tName, "($sx, $sy)");

			 # 대상의 괴수가 쓰러져 황무지가 됨
				$land->[$sx][$sy] = $HlandIce;
				$landValue->[$sx][$sy] = 0;

		 if (rand(1000) < 100) {
		 $land->[$sx][$sy] = $HlandMonument;
		 $landValue->[$sx][$sy] = 76;
		 }
			 # 포상금
				my($value) = $HmonsterValue[$tKind];
				 $island->{'money'} += $value;
				 logMsMonMoney($id, $tName, $value);
			 }
			}
		 } elsif(($land->[$sx][$sy] == $HlandBase) ||
			 ($land->[$sx][$sy] == $HlandDefence) ||
			 ($land->[$sx][$sy] == $HlandOil) ||
			 ($land->[$sx][$sy] == $HlandFune)) {
			# 대상이 되는 괴수각 요소 꺼내기
			$tKind = $land->[$sx][$sy];
			$tlv = $landValue->[$sx][$sy];

			if (rand(1000) < 200) {
			 logIceAttack($id, $name, $mName, "($x, $y)", landName($tKind, $tlv), "($sx, $sy)");
				$land->[$sx][$sy] = $HlandIce;
				$landValue->[$sx][$sy] = 0;
		 if (rand(1000) < 100) {
		 $land->[$sx][$sy] = $HlandMonument;
		 $landValue->[$sx][$sy] = 76;
		 }
			}
		 }
		}


	 } elsif ($mKind == 19) {
	 if (rand(1000) < 333) {
			logMgMeteo($id, $name, $mName, "($x, $y)");
		my($sx, $sy, $landKind, $lv, $point, $first);
		$first = 1;
		while((random(3) == 0) || ($first == 1)) {
		 $first = 0;
		 # 낙하
		 $sx = random($HislandSize);
		 $sy = random($HislandSize);
		 $landKind = $land->[$sx][$sy];
		 $lv = $landValue->[$sx][$sy];
		 $point = "($sx, $sy)";

		 if(($landKind == $HlandSea) && ($lv == 0)){
			# 바다포차
			logMeteoSea($id, $name, landName($landKind, $lv),
				 $point);
		 } elsif($landKind == $HlandMountain) {
			# 산파괴
			logMeteoMountain($id, $name, landName($landKind, $lv),
					 $point);
			$land->[$sx][$sy] = $HlandWaste;
			$landValue->[$sx][$sy] = 0;
			next;
		 } elsif($landKind == $HlandGold) {
			# 산파괴
			logMeteoMountain($id, $name, landName($landKind, $lv),
					 $point);
			$land->[$sx][$sy] = $HlandWaste;
			$landValue->[$sx][$sy] = 0;
			next;
		 } elsif($landKind == $HlandOnsen) {
			# 산파괴
			logMeteoMountain($id, $name, landName($landKind, $lv),
					 $point);
			$land->[$sx][$sy] = $HlandWaste;
			$landValue->[$sx][$sy] = 0;
			next;
		 } elsif($landKind == $HlandSbase) {
			logMeteoSbase($id, $name, landName($landKind, $lv),
				 $point);
		 } elsif($landKind == $HlandSeacity) {
			logMeteoSbase($id, $name, landName($landKind, $lv),
				 $point);
		 } elsif($landKind == $HlandSeatown) {
			logMeteoSbase($id, $name, landName($landKind, $lv),
				 $point);
		 } elsif($landKind == $HlandUmishuto) {
			logMeteoSbase($id, $name, landName($landKind, $lv),
				 $point);
		 } elsif($landKind == $HlandFune) {
			logMeteoSbase($id, $name, landName($landKind, $lv),
				 $point);
		 } elsif($landKind == $HlandFrocity) {
			logMeteoSbase($id, $name, landName($landKind, $lv),
				 $point);
		 } elsif($landKind == $HlandUmiamu) {
			logMeteoSbase($id, $name, landName($landKind, $lv),
				 $point);
		 } elsif($landKind == $HlandMonster) {
			logMeteoMonster($id, $name, landName($landKind, $lv),
					$point);
		 } elsif($landKind == $HlandSea) {
			# 얕은 바다
			logMeteoSea1($id, $name, landName($landKind, $lv),
				 $point);
		 } elsif($landKind == $HlandIce) {
			# 얕은 바다
			logMeteoSea1($id, $name, landName($landKind, $lv),
				 $point);
		 } else {
			logMeteoNormal($id, $name, landName($landKind, $lv),
				 $point);
		 }
		 $land->[$sx][$sy] = $HlandSea;
		 $landValue->[$sx][$sy] = 0;
		 }
		}

	 if (rand(1000) < 400) {
			logMgMeteo($id, $name, $mName, "($x, $y)");
		my($sx, $sy, $landKind, $lv, $point);

		# 낙하
		$sx = random($HislandSize);
		$sy = random($HislandSize);
		$landKind = $land->[$sx][$sy];
		$lv = $landValue->[$sx][$sy];
		$point = "($sx, $sy)";

		# 메시지
		logHugeMeteo($id, $name, $point);

		# 광역 피해 루틴
		wideDamage($id, $name, $land, $landValue, $sx, $sy);
	 }

	 if(random(1000) < 450) {
		logMgEarthquake($id, $name, $mName, "($x, $y)");

		# 지진발생
		logEarthquake($id, $name);
		my($sx, $sy, $landKind, $lv, $i);
		for($i = 0; $i < $HpointNumber; $i++) {
		 $sx = $Hrpx[$i];
		 $sy = $Hrpy[$i];
		 $landKind = $land->[$sx][$sy];
		 $lv = $landValue->[$sx][$sy];

		 if((($landKind == $HlandTown) && ($lv>= 100)) ||
		 (($landKind == $HlandFoodim) && ($lv < 480)) ||
		 (($landKind == $HlandProcity) && ($lv < 130)) ||
		 (($landKind == $HlandNewtown) && ($lv < 300)) ||
		 (($landKind == $HlandBigtown) && ($lv < 300)) ||
		 (($landKind == $HlandHTFactory) && ($lv < 500)) ||
		 (($landKind == $HlandSHTF) && ($lv < 500)) ||
		 ($landKind == $HlandRizort) ||
		 ($landKind == $HlandKajino) ||
		 ($landKind == $HlandBigRizort) ||
		 ($landKind == $HlandHaribote) ||
	 ($landKind == $HlandPark) ||
		 ($landKind == $HlandMinato) ||
	 ($landKind == $HlandKyujo) ||
	 ($landKind == $HlandKyujokai) ||
	 ($landKind == $HlandOnsen) ||
		 ($landKind == $HlandFactory)) {
			# 1/4에서 괴멸
			if(random(4) == 0) {
			 logEQDamage($id, $name, landName($landKind, $lv),
					"($sx, $sy)");
			 $land->[$sx][$sy] = $HlandWaste;
			 $landValue->[$sx][$sy] = 0;
				if ($kind == $HlandOnsen) {
 	# 금광산은 산에돌아가기
 	$land->[$sx][$sy] = $HlandMountain; # 바다가 됨
 	$landValue->[$sx][$sy] = 0;
 		}
			}
		 }

		}
	 }

		 my($i,$sx,$sy);
		 for($i = 0; $i < $HpointNumber; $i++){
			$sx = $Hrpx[$i];
			$sy = $Hrpy[$i];
		 if($land->[$sx][$sy] == $HlandMonster){
			my($tKind, $tName, $tHp) = monsterSpec($landValue->[$sx][$sy]);
			my($tlv) = $landValue->[$sx][$sy];
			my($tspecial) = $HmonsterSpecial[$tKind];
		 if($tKind != 19){
		 if($tHp> $mHp){
			if((($tspecial == 3) && (($HislandTurn % 2) == 1)) ||
	 (($tspecial == 8) && ((seqnum($HislandTurn) % 2) == 0)) ||
			 (($tspecial == 4) && (($HislandTurn % 2) == 0))) {
		 next;
		 }

		 logMgDrain($id, $name, $mName, $tName, "($x, $y)");


		 $tlv-=($tHp-$mHp);
			$landValue->[$sx][$sy] = $tlv;
		 if($mHp < 9){$lv+=($tHp-$mHp);}
			$landValue->[$x][$y] = $lv;
		 }else{
		 }
		 next;
		 }
		 }
		}


	 } elsif ($mKind == 20) {
	 $lv+=2;
		$landValue->[$x][$y] = $lv;
		if (random(1000) < 200) {
		$island->{'food'} -= int($island->{'food'} / 2);
		logFushoku($id, $name, $mName, "($x, $y)");
 	}
		if ($mHp> 13) {
		logUmlimit($id, $name, $mName, "($x, $y)");
		# 광역 피해 루틴
		wideDamage($id, $name, $land, $landValue, $x, $y);

		my($sx, $sy, $landKind, $lv, $i);
		for($i = 0; $i < $HpointNumber; $i++) {
		 $sx = $Hrpx[$i];
		 $sy = $Hrpy[$i];
		 $landKind = $land->[$sx][$sy];
		 $lv = $landValue->[$sx][$sy];

		 if((($landKind == $HlandTown) && ($lv>= 100)) ||
		 (($landKind == $HlandFoodim) && ($lv < 480)) ||
		 (($landKind == $HlandProcity) && ($lv < 130)) ||
		 ($landKind == $HlandHaribote) ||
	 ($landKind == $HlandPark) ||
		 ($landKind == $HlandMinato) ||
	 ($landKind == $HlandKyujo) ||
	 ($landKind == $HlandKyujokai) ||
		 ($landKind == $HlandBase) ||
		 ($landKind == $HlandFactory)) {
			# 1/6에서 괴멸
			if(random(6) == 0) {
			 logUmlimitDamage($id, $name, $mName, landName($landKind, $lv),
					"($sx, $sy)");
			 $land->[$sx][$sy] = $HlandWaste;
			 $landValue->[$sx][$sy] = 0;

		 if (rand(1000) < 150) {
		 $land->[$sx][$sy] = $HlandMonument;
		 $landValue->[$sx][$sy] = 74;
		 }
			}
		 }
		}
		 $kind = 21;
		 $lv = $lv = ($kind << 4)
			+ $HmonsterBHP[$kind] + random($HmonsterDHP[$kind]);
		 $land->[$x][$y] = $HlandMonster;
		 $landValue->[$x][$y] = $lv;
 	}


	 } elsif ($mKind == 21) {
		if($mHp < 9){$lv+=3;}
		$landValue->[$x][$y] = $lv;
		if (random(1000) < 150) {
		$island->{'money'} -= int($island->{'money'} / 2);
		logKyoukou($id, $name, $mName, "($x, $y)");
 	}
		if (random(1000) < 200) {
		$island->{'food'} = 0;
		logFushoku($id, $name, $mName, "($x, $y)");
 	}
		 my($i,$sx,$sy);
		 for($i = 0; $i < $HpointNumber; $i++){
			$sx = $Hrpx[$i];
			$sy = $Hrpy[$i];
			 if(($land->[$sx][$sy] == $HlandPlains) ||
			 ($land->[$sx][$sy] == $HlandPlains2) ||
			 ($land->[$sx][$sy] == $HlandForest) ||
			 ($land->[$sx][$sy] == $HlandNursery) ||
			 ($land->[$sx][$sy] == $HlandFarmchi) ||
			 ($land->[$sx][$sy] == $HlandFarmpic) ||
			 ($land->[$sx][$sy] == $HlandFarmcow) ||
			 ($land->[$sx][$sy] == $HlandRottenSea)) {
			# 대상이 되는 괴수각 요소 꺼내기
			$tKind = $land->[$sx][$sy];
			$tlv = $landValue->[$sx][$sy];

			if (rand(1000) < 200) {
			 logHellAttack($id, $name, $mName, "($x, $y)", landName($tKind, $tlv), "($sx, $sy)");
				$land->[$sx][$sy] = $HlandWaste;
				$landValue->[$sx][$sy] = 0;
		 if (rand(1000) < 100) {
		 $land->[$sx][$sy] = $HlandMonument;
		 $landValue->[$sx][$sy] = 78;
		 }
		 if (rand(1000) < 100) {
		 $land->[$sx][$sy] = $HlandMonument;
		 $landValue->[$sx][$sy] = 74;
		 }
			}
		 }
		}

	 } elsif ($mKind == 30) {


	 if($island->{'monsterlive'} - $island->{'c28'} == 0){
		# 테트라 전용?
		if($island->{'co99'} == 0){
			logMstakeiede($id, $name, "출격안의 초신 수테트라","($sx, $sy)",landName($landKind, $lv));
	 } else {
			my($i,$sx,$sy);
			for($i = 1; $i < $HpointNumber; $i++){
			 $sx = $Hrpx[$i];
			 $sy = $Hrpy[$i];
				$landKind = $land->[$sx][$sy];
				$lv = $landValue->[$sx][$sy];
				$landName = landName($landKind, $lv);
			if(($land->[$sx][$sy] == $HlandCollege) && ($lv == 99)){
			$landValue->[$sx][$sy] = 98;
			logMstakeokaeri($id, $name, "출격안의 초신 수테트라","($sx, $sy)",landName($landKind, $lv));
		 }
		 }
		}
		 $land->[$x][$y] = $HlandWaste;
		 $landValue->[$x][$y] = 0;
	 }


	 my($i,$sx,$sy);
	 for($i = 1; $i < $HpointNumber; $i++){
		$sx = $Hrpx[$i];
		$sy = $Hrpy[$i];
	 if($land->[$sx][$sy] == $HlandMonster){
		if($msseigen < 1) {
		# 주변 2Hex 에 다른 괴수가 있으면 그 괴수를 공격

		# 대상이 되는 괴수각 요소 꺼내기
		my($tKind, $tName, $tHp) = monsterSpec($landValue->[$sx][$sy]);
		my($tlv) = $landValue->[$sx][$sy];
		my($tspecial) = $HmonsterSpecial[$tKind];

		if(($tKind == 30)||($tKind == 23)) {
		} else {

		$eisei5 = $island->{'eisei5'};
		$eisei5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		($mshp, $msap, $msdp, $mssp, $mswin, $msexe, $tet) = ($1, $2, $3, $4, $5, $6, $7);

		$attackdamege = random($msap-$tKind);
		$counterdamege = random($tKind-$msdp);
		if($attackdamege < 1){
		$attackdamege = 2;
		}
		if($counterdamege < 1){
		$counterdamege = 1;
		}

		if(rand(5+$tKind)> $mssp){
		$attackdamege = 0;
		}
		if(rand(5+$tKind) < $mssp){
		$counterdamege = 0;
		}

		logMsAttackt($id, $name, "초신 수테트라", $attackdamege, $counterdamege, $tName, "($sx, $sy)");
		$msseigen++;
		$tHp -= $attackdamege;
		$tlv -= $attackdamege;
		$landValue->[$sx][$sy] = $tlv;
		$mHp -= $counterdamege;
		$lv -= $counterdamege;
		$landValue->[$x][$y] = $lv;

		if($tHp < 1){
		# 대상의 괴수가 쓰러져 황무지가 됨
		$land->[$sx][$sy] = $HlandWaste;
		$landValue->[$sx][$sy] = 0;
		if($tKind == 13) {
		$land->[$sx][$sy] = $HlandMonument;
		$landValue->[$sx][$sy] = 93;
		logMsAttackmika($id, $name, "초신 수테트라", $attackdamege, $counterdamege, $tName, $tPoint);
		}
		# 포상금
		my($value) = $HmonsterValue[$tKind];
		 $island->{'money'} += $value;

		if(rand(1000) < $value) {
		 if(rand(100) < 30) {
		 $msap++;
		 } elsif (rand(100) < 30) {
		 $msdp++;
		 } elsif (rand(100) < 30) {
		 $mssp++;
		 } else {
		 $mshp++;
			if($mshp> 15){
			$mshp = 15;
			}
		 }
		}

		 $msexe += $HmonsterExp[$tKind];
		 $mswin ++;
 # 괴수퇴치 수
 $island->{'taiji'}++;

				# 수상 관계
				my($prize) = $island->{'prize'};
				$prize =~ /([0-9]*),([0-9]*),(.*)/;
				my($flags) = $1;
				my($monsters) = $2;
				my($turns) = $3;
				my($v) = 2 ** $tKind;
				$monsters |= $v;
				$island->{'prize'} = "$flags,$monsters,$turns";

		 $island->{'eisei5'} = "$mshp,$msap,$msdp,$mssp,$mswin,$msexe,$tet";
		 logMsMonMoney($id, $tName, $value);
		}
		if($mHp < 1){
		# 대상의 괴수가 쓰러져 황무지가 됨
		$land->[$x][$y] = $HlandWaste;
		$landValue->[$x][$y] = 0;
		# 포상금
		my($value) = $HmonsterValue[$mKind];
		 $island->{'money'} += $value;
		 logMsMonMoney($id, $mName, $value);
		}
	 }
	 }
	 next;
	 }
	 }



	 } elsif ($mKind == 29) {

	 if($island->{'monsterlive'} == 1){
		# 지금테트라 전용?
		if($island->{'co99'} == 0){
	 } else {
			my($i,$sx,$sy);
			for($i = 1; $i < $HpointNumber; $i++){
			 $sx = $Hrpx[$i];
			 $sy = $Hrpy[$i];
				$landKind = $land->[$sx][$sy];
				$lv = $landValue->[$sx][$sy];
				$landName = landName($landKind, $lv);
			if(($land->[$sx][$sy] == $HlandCollege) && ($lv == 99)){
			$landValue->[$sx][$sy] = 98;
			$land->[$x][$y] = $HlandWaste;
			$landValue->[$x][$y] = 0;
			logMstakeokaeri($id, $name, "테트라","($sx, $sy)",landName($landKind, $lv));
		 }
		 }
		}
	 }


	 } elsif ($mKind == 28) {

	 if($island->{'monsterlive'} - $island->{'c28'} == 0){
		# 칸코와이노라 전용?
		if($island->{'co99'} == 0){
			logMstakeiede($id, $name, "출격안의 칸코와이노라","($sx, $sy)",landName($landKind, $lv));
	 } else {
			my($i,$sx,$sy);
			for($i = 1; $i < $HpointNumber; $i++){
			 $sx = $Hrpx[$i];
			 $sy = $Hrpy[$i];
				$landKind = $land->[$sx][$sy];
				$lv = $landValue->[$sx][$sy];
				$landName = landName($landKind, $lv);
			if(($land->[$sx][$sy] == $HlandCollege) && ($lv == 99)){
			$landValue->[$sx][$sy] = 4;
			logMstakeokaeri($id, $name, "출격안의 칸코와이노라","($sx, $sy)",landName($landKind, $lv));
		 }
		 }
		}
		 $land->[$x][$y] = $HlandWaste;
		 $landValue->[$x][$y] = 0;
	 }


	 my($i,$sx,$sy);
	 for($i = 1; $i < $HpointNumber; $i++){
		$sx = $Hrpx[$i];
		$sy = $Hrpy[$i];
	 if($land->[$sx][$sy] == $HlandMonster){
		if($msseigen < 1) {
		# 주변 2Hex 에 다른 괴수가 있으면 그 괴수를 공격

		# 대상이 되는 괴수각 요소 꺼내기
		my($tKind, $tName, $tHp) = monsterSpec($landValue->[$sx][$sy]);
		my($tlv) = $landValue->[$sx][$sy];
		my($tspecial) = $HmonsterSpecial[$tKind];

		if(($tKind == 28)||($tKind == 23)) {
		} else {

		$eisei5 = $island->{'eisei5'};
		$eisei5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		($mshp, $msap, $msdp, $mssp, $mswin, $msexe, $tet) = ($1, $2, $3, $4, $5, $6, $7);

		$attackdamege = random($msap-$tKind);
		$counterdamege = random($tKind-$msdp);
		if($attackdamege < 1){
		$attackdamege = 1;
		}
		if($counterdamege < 1){
		$counterdamege = 1;
		}

		if(rand(5+$tKind)> $mssp){
		$attackdamege = 0;
		}
		if(rand(5+$tKind) < $mssp){
		$counterdamege = 0;
		}

		logMsAttackt($id, $name, "칸코와이노라", $attackdamege, $counterdamege, $tName, "($sx, $sy)");
		$msseigen++;
		$tHp -= $attackdamege;
		$tlv -= $attackdamege;
		$landValue->[$sx][$sy] = $tlv;
		$mHp -= $counterdamege;
		$lv -= $counterdamege;
		$landValue->[$x][$y] = $lv;

		if($tHp < 1){
		# 대상의 괴수가 쓰러져 황무지가 됨
		$land->[$sx][$sy] = $HlandWaste;
		$landValue->[$sx][$sy] = 0;
		# 포상금
		my($value) = $HmonsterValue[$tKind];
		 $island->{'money'} += $value;

		if(rand(1000) < $value) {
		 if(rand(100) < 30) {
		 $msap++;
		 } elsif (rand(100) < 30) {
		 $msdp++;
		 } elsif (rand(100) < 30) {
		 $mssp++;
		 } else {
		 $mshp++;
			if($mshp> 15){
			$mshp = 15;
			}
		 }
		}

		 $msexe += $HmonsterExp[$tKind];
		 $mswin ++;
 # 괴수퇴치 수
 $island->{'taiji'}++;

				# 수상 관계
				my($prize) = $island->{'prize'};
				$prize =~ /([0-9]*),([0-9]*),(.*)/;
				my($flags) = $1;
				my($monsters) = $2;
				my($turns) = $3;
				my($v) = 2 ** $tKind;
				$monsters |= $v;
				$island->{'prize'} = "$flags,$monsters,$turns";

		 $island->{'eisei5'} = "$mshp,$msap,$msdp,$mssp,$mswin,$msexe,$tet";
		 logMsMonMoney($id, $tName, $value);
		}
		if($mHp < 1){
		# 대상의 괴수가 쓰러져 황무지가 됨
		$land->[$x][$y] = $HlandWaste;
		$landValue->[$x][$y] = 0;
		# 포상금
		my($value) = $HmonsterValue[$mKind];
		 $island->{'money'} += $value;
		 logMsMonMoney($id, $mName, $value);
		}
	 }
	 }
	 next;
	 }
	 }



	 } elsif(($special == 6) ||
		 ($mKind == 13)) {
	 my($i,$sx,$sy);
	 for($i = 0; $i < $HpointNumber; $i++){
		$sx = $Hrpx[$i];
		$sy = $Hrpy[$i];
	 if($land->[$sx][$sy] == $HlandMonster){
		if($kougekiseigenm < 2) {
		# 주변 2Hex 에 다른 괴수가 있으면 그 괴수를 공격

		# 대상이 되는 괴수각 요소 꺼내기
		my($tKind, $tName, $tHp) = monsterSpec($landValue->[$sx][$sy]);
		my($tlv) = $landValue->[$sx][$sy];
		my($tspecial) = $HmonsterSpecial[$tKind];

	 if($mHp> $tHp){ # 대상보다체력이많음카한 경우
		if((($tspecial == 3) && (($HislandTurn % 2) == 1)) ||
 (($tspecial == 8) && ((seqnum($HislandTurn) % 2) == 0)) ||
		 (($tspecial == 4) && (($HislandTurn % 2) == 0))) {
		# 대상이 경화 중이면 효과 없음
	 next;
	 }

	 if($mKind == 13) {
	 logMonsAttackt($id, $name, $mName, "($x, $y)", $tName, $tPoint);
	 }else{
	 logMonsAttack($id, $name, $mName, "($x, $y)", $tName, $tPoint);
	 }

	 $kougekiseigenm++;

	 $tHp--;
	 if($tHp != 0){
	 # 대상의 체력을 감하게 함
	 $tlv--;
		$landValue->[$sx][$sy] = $tlv;
	 }else{
	 # 대상의 괴수가 쓰러져 황무지가 됨
		$land->[$sx][$sy] = $HlandWaste;
		$landValue->[$sx][$sy] = 0;
	 # 포상금
		my($value) = $HmonsterValue[$tKind];
		 $island->{'money'} += $value;
		 logMsMonMoney($id, $tName, $value);
		}
	 # 대상의 괴수의 체력을 탈취라고자신의 체력을 회복
	 if($mHp < 9){$lv++;}
		$landValue->[$x][$y] = $lv;
	 }else{ # 대상보다체력이저카한 경우
	 # 아무것도 하지 않음
	 }
	 next;
	 }
	 }
	}
	}

	 # 이동 방향을 결정
	 my($d, $sx, $sy);
	 my($i);
	 for($i = 0; $i < 3; $i++) {
		$d = random(6) + 1;
		$sx = $x + $ax[$d];
		$sy = $y + $ay[$d];

		# 행 기준 위치 조정
		if((($sy % 2) == 0) && (($y % 2) == 1)) {
		 $sx--;
		}

		# 범위 밖 판정
		if(($sx < 0) || ($sx>= $HislandSize) ||
		 ($sy < 0) || ($sy>= $HislandSize)) {
		 next;
		}

		# 바다, 바다 기준, 해저 도시, 유전, 괴수, 산, 기념비이외
		if(($land->[$sx][$sy] != $HlandSea) &&
		 ($land->[$sx][$sy] != $HlandSbase) &&
		 ($land->[$sx][$sy] != $HlandSeacity) &&
		 ($land->[$sx][$sy] != $HlandSeatown) &&
		 ($land->[$sx][$sy] != $HlandBigtown) &&
		 ($land->[$sx][$sy] != $HlandBettown) &&
		 ($land->[$sx][$sy] != $HlandSkycity) &&
		 ($land->[$sx][$sy] != $HlandUmicity) &&
		 ($land->[$sx][$sy] != $HlandShuto) &&
		 ($land->[$sx][$sy] != $HlandUmishuto) &&
		 ($land->[$sx][$sy] != $HlandFune) &&
		 ($land->[$sx][$sy] != $HlandFrocity) &&
		 ($land->[$sx][$sy] != $HlandUmiamu) &&
		 ($land->[$sx][$sy] != $HlandOil) &&
		 ($land->[$sx][$sy] != $HlandZoo) &&
		 ($land->[$sx][$sy] != $HlandNursery) &&
		 ($land->[$sx][$sy] != $HlandBigRizort) &&
		 ($land->[$sx][$sy] != $HlandKajino) &&
		 ($land->[$sx][$sy] != $HlandGold) &&
		 ($land->[$sx][$sy] != $HlandMountain) &&
		 ($land->[$sx][$sy] != $HlandOnsen) &&
		 ($land->[$sx][$sy] != $HlandMonument) &&
		 ($land->[$sx][$sy] != $HlandRottenSea) &&
		 ($land->[$sx][$sy] != $HlandHouse) &&
		 ($land->[$sx][$sy] != $HlandTaishi) &&
		 ($land->[$sx][$sy] != $HlandMonster)) {
		 last;
		}
	 }

	 if($i == 3) {
		# 작동없었습니다
		next;
	 }

	 if (($mKind == 28) ||
		($mKind == 30)) {
		if($land->[$sx][$sy] != $HlandWaste) {
		 next;
		}
	 }

	 # 이동한 위치의 지형에 따라 처리
	 my($l) = $land->[$sx][$sy];
	 my($lv) = $landValue->[$sx][$sy];
	 my($lName) = landName($l, $lv);
	 my($point) = "($sx, $sy)";

	 # 이동
	 $land->[$sx][$sy] = $land->[$x][$y];
	 $landValue->[$sx][$sy] = $landValue->[$x][$y];

	 # 원래 위치를 황무지로
	 $land->[$x][$y] = $HlandWaste;
	 $landValue->[$x][$y] = 0;

		if ($mKind == 11) {
		 if((rand(1000) < 900) &&
		 ($island->{'monsterlive'} < 7)) { # 슬라임라면90% 확률로 분열하다
		 my($point) = "($x, $y)";
		 $kind = 11;
		 $lv = $lv = ($kind << 4)
			+ $HmonsterBHP[$kind] + random($HmonsterDHP[$kind]);
		 $land->[$x][$y] = $HlandMonster;
		 $landValue->[$x][$y] = $lv;
		 } elsif((rand(20000) < 400-$island->{'monsterlive'}) &&
		 ($island->{'monsterlive'}> 7)) {
		 my($point) = "($x, $y)";
		 $kind = 11;
		 $lv = $lv = ($kind << 4)
			+ $HmonsterBHP[$kind] + random($HmonsterDHP[$kind]);
		 $land->[$x][$y] = $HlandMonster;
		 $landValue->[$x][$y] = $lv;
			lognewMonsterBorn($id, $name, $point);
		 }
		}

		if (($mKind == 15) ||
		 ($mKind == 19)) { # 슬라임라면(이노라를 흐름용)
		if ((rand(1000) < 600) &&
		($island->{'monsterlive'} < 7)) {
		my($point) = "($x, $y)";
		 $kind = random($HmonsterLevel3) + 1;
		 $lv = $lv = ($kind << 4)
			+ $HmonsterBHP[$kind] + random($HmonsterDHP[$kind]);
		 $land->[$x][$y] = $HlandMonster;
		 $landValue->[$x][$y] = $lv;
		 my($mKind, $mName, $mHp) = monsterSpec($lv);
		if ($mKind == 15) {
			lognewKaiju($id, $name, $mName, $point);
		}else{
		 my($l) = $land->[$sx][$sy];
		 my($lv) = $landValue->[$sx][$sy];
		 my($nName) = landName($l, $lv);
			logShoukan($id, $name, $nName, $mName, $point);
		}
		}
		}

 if ($mKind == 8) { # 오무라면 여기에서 추가
 if (rand(1000) < 400) {
 # 0.1% 확률로 오염된 바다가생된
 my($point) = "($x, $y)";
 logRottenSeaBorn($id, $name, $point);
 $land->[$x][$y] = $HlandRottenSea;
 $landValue->[$x][$y] = 1;
 } elsif (rand(1000) < 200) {
 # 탈피 껍질
 my($point) = "($x, $y)";
 logNuginugi($id, $name, $point);
 $land->[$x][$y] = $HlandMonument;
 $landValue->[$x][$y] = 87;
		 $kind = 8;
		 $lv = $lv = ($kind << 4)
			+ $HmonsterBHP[$kind] + random(3);
		 $land->[$sx][$sy] = $HlandMonster;
		 $landValue->[$sx][$sy] = $lv;
 }
 }#여기까지추가

 # 괴수가주변을 불태우는 능력
 if (($special == 7) ||
		($mKind == 16)) {
 my($i, $ssx, $ssy, $kind, $lv);
 for($i = 1; $i < 7; $i++) {
 $ssx = $sx + $ax[$i];
 $ssy = $sy + $ay[$i];

 # 행 기준 위치 조정
 if((($ssy % 2) == 0) && (($sy % 2) == 1)) {
 $ssx--;
 }
		 if(($ssx < 0) || ($ssx>= $HislandSize) ||
		 ($ssy < 0) || ($ssy>= $HislandSize)) {
		 # 범위 밖
		 next;
		 }

 $kind = $land->[$ssx][$ssy];
 $lv = $landValue->[$ssx][$ssy];

 if (($kind == $HlandSea) ||
 ($kind == $HlandSeacity) ||
 ($kind == $HlandSeatown) ||
 ($kind == $HlandUmishuto) ||
 ($kind == $HlandIce) ||
 ($kind == $HlandWaste) ||
 ($kind == $HlandUmiamu) ||
 ($kind == $HlandSbase)) {
 # 바다와 해저 기지는 소각되지 않음
 next;
 } elsif ($kind == $HlandOil) {
 # 유전은 바다에돌아가기
 $land->[$ssx][$ssy] = $HlandSea; # 바다가 됨
 $landValue->[$ssx][$ssy] = 0;
 } elsif ($kind == $HlandFune) {
 # 유전은 바다에돌아가기
 $land->[$ssx][$ssy] = $HlandSea; # 바다가 됨
 $landValue->[$ssx][$ssy] = 0;
 } elsif ($kind == $HlandFrocity) {
 # 유전은 바다에돌아가기
 $land->[$ssx][$ssy] = $HlandSea; # 바다가 됨
 $landValue->[$ssx][$ssy] = 0;
 } elsif ($kind == $HlandNursery) {
 # 유전은 바다에돌아가기
 $land->[$ssx][$ssy] = $HlandSea; # 바다가 됨
 $landValue->[$ssx][$ssy] = 1;
	 } elsif ($kind == $HlandGold) {
 # 금광산은 산에돌아가기
 $land->[$ssx][$ssy] = $HlandMountain; # 바다가 됨
 $landValue->[$ssx][$ssy] = 0;
	 } elsif ($kind == $HlandOnsen) {
 # 금광산은 산에돌아가기
 $land->[$ssx][$ssy] = $HlandMountain; # 바다가 됨
 $landValue->[$ssx][$ssy] = 0;
 } elsif (($kind == $HlandMountain) && ($lv> 0)) {
 # 채굴장은 산에돌아가기
 $landValue->[$ssx][$ssy] = 0; # 채굴장의 작업원은 괴멸
	 } elsif ($kind == $HlandMonster) {
 # 괴수는
			# 대상이 되는 괴수각 요소 꺼내기
			my($tKind, $tName, $tHp) = monsterSpec($landValue->[$ssx][$ssy]);
			my($tlv) = $landValue->[$ssx][$ssy];
			my($tspecial) = $HmonsterSpecial[$tKind];
			 if(($tKind == 28) ||
				($tKind == 30)) {
				$dmge = random(4);
				$tHp -= $dmge;
				$tlv -= $dmge;
				$landValue->[$ssx][$ssy] = $tlv;

				if($tHp < 1){
				# 대상의 괴수가 쓰러져 황무지가 됨
				$land->[$ssx][$ssy] = $HlandWaste;
				$landValue->[$ssx][$ssy] = 0;
				# 포상금
				my($value) = $HmonsterValue[$tKind];
				 $island->{'money'} += $value;
				 logMsMonMoney($id, $tName, $value);
				}
			 }

 } else {
 # 전체가불태됩니다
 $land->[$ssx][$ssy] = $HlandWaste; # 황무지가 됨
 $landValue->[$ssx][$ssy] = 0;
 }

 # 로그 생성
 logMonsFire($id, $name, landName($kind, $lv), "($ssx, $ssy)", $mName);
 }
 }
 # 괴수가주변을 불태우는 능력
 if (($mKind == 13) ||
		($mKind == 18)) {
 my($i, $ssx, $ssy, $kind, $lv);
 for($i = 1; $i < 19; $i++) {
 $ssx = $sx + $ax[$i];
 $ssy = $sy + $ay[$i];

 # 행 기준 위치 조정
 if((($ssy % 2) == 0) && (($sy % 2) == 1)) {
 $ssx--;
 }
		 if(($ssx < 0) || ($ssx>= $HislandSize) ||
		 ($ssy < 0) || ($ssy>= $HislandSize)) {
		 # 범위 밖
		 next;
		 }

 $kind = $land->[$ssx][$ssy];
 $lv = $landValue->[$ssx][$ssy];

 if (($kind == $HlandSea) ||
 ($kind == $HlandIce) ||
 ($kind == $HlandSeacity) ||
 ($kind == $HlandSeatown) ||
 ($kind == $HlandUmishuto) ||
 ($kind == $HlandWaste) ||
 ($kind == $HlandUmiamu) ||
 ($kind == $HlandSbase)) {
 # 바다와 해저 기지는 소각되지 않음
 next;
 } elsif ($kind == $HlandOil) {
 # 유전은 바다에돌아가기
 $land->[$ssx][$ssy] = $HlandSea; # 바다가 됨
 $landValue->[$ssx][$ssy] = 0;
 } elsif ($kind == $HlandFune) {
 # 유전은 바다에돌아가기
 $land->[$ssx][$ssy] = $HlandSea; # 바다가 됨
 $landValue->[$ssx][$ssy] = 0;
 } elsif ($kind == $HlandFrocity) {
 # 유전은 바다에돌아가기
 $land->[$ssx][$ssy] = $HlandSea; # 바다가 됨
 $landValue->[$ssx][$ssy] = 0;
 } elsif ($kind == $HlandNursery) {
 # 유전은 바다에돌아가기
 $land->[$ssx][$ssy] = $HlandSea; # 바다가 됨
 $landValue->[$ssx][$ssy] = 1;
	 } elsif ($kind == $HlandGold) {
 # 금광산은 산에돌아가기
 $land->[$ssx][$ssy] = $HlandMountain; # 바다가 됨
 $landValue->[$ssx][$ssy] = 0;
	 } elsif ($kind == $HlandOnsen) {
 # 금광산은 산에돌아가기
 $land->[$ssx][$ssy] = $HlandMountain; # 바다가 됨
 $landValue->[$ssx][$ssy] = 0;
 } elsif (($kind == $HlandMountain) && ($lv> 0)) {
 # 채굴장은 산에돌아가기
 $landValue->[$ssx][$ssy] = 0; # 채굴장의 작업원은 괴멸

	 } elsif ($kind == $HlandMonster) {
 # 괴수는
			# 대상이 되는 괴수각 요소 꺼내기
			my($tKind, $tName, $tHp) = monsterSpec($landValue->[$ssx][$ssy]);
			my($tlv) = $landValue->[$ssx][$ssy];
			my($tspecial) = $HmonsterSpecial[$tKind];
			 if(($tKind == 28) ||
				($tKind == 30)) {
				$dmge = random(4);
				$tHp -= $dmge;
				$tlv -= $dmge;
				$landValue->[$ssx][$ssy] = $tlv;

				if($tHp < 1){
				# 대상의 괴수가 쓰러져 황무지가 됨
				$land->[$ssx][$ssy] = $HlandWaste;
				$landValue->[$ssx][$ssy] = 0;
				# 포상금
				my($value) = $HmonsterValue[$tKind];
				 $island->{'money'} += $value;
				 logMsMonMoney($id, $tName, $value);
				}
			 }

 } else {
 # 전체가불태됩니다
 $land->[$ssx][$ssy] = $HlandWaste; # 황무지가 됨
 $landValue->[$ssx][$ssy] = 0;
 }

 # 로그 생성
 logMonsFire($id, $name, landName($kind, $lv), "($ssx, $ssy)", $mName);
 }
 }


 # 동결되지 않음
 if (($special == 9) ||
		($mKind == 22)) {
 my($i, $ssx, $ssy, $kind, $lv);
 for($i = 1; $i < 7; $i++) {
 $ssx = $sx + $ax[$i];
 $ssy = $sy + $ay[$i];

 # 행 기준 위치 조정
 if((($ssy % 2) == 0) && (($sy % 2) == 1)) {
 $ssx--;
 }
		 if(($ssx < 0) || ($ssx>= $HislandSize) ||
		 ($ssy < 0) || ($ssy>= $HislandSize)) {
		 # 범위 밖
		 next;
		 }

 $kind = $land->[$ssx][$ssy];
 $lv = $landValue->[$ssx][$ssy];

 if (($kind == $HlandSeacity) ||
 ($kind == $HlandSeatown) ||
 ($kind == $HlandUmishuto) ||
 ($kind == $HlandIce) ||
 ($kind == $HlandUmiamu) ||
 ($kind == $HlandSbase)) {
 # 바다와 해저 기지는 소각되지 않음
 next;
 } elsif ($kind == $HlandOil) {
 # 유전은 바다에돌아가기
 $land->[$ssx][$ssy] = $HlandIce; # 바다가 됨
 $landValue->[$ssx][$ssy] = 0;
 } elsif ($kind == $HlandFune) {
 # 유전은 바다에돌아가기
 $land->[$ssx][$ssy] = $HlandIce; # 바다가 됨
 $landValue->[$ssx][$ssy] = 0;
 } elsif ($kind == $HlandFrocity) {
 # 유전은 바다에돌아가기
 $land->[$ssx][$ssy] = $HlandIce; # 바다가 됨
 $landValue->[$ssx][$ssy] = 0;
 } elsif ($kind == $HlandNursery) {
 # 유전은 바다에돌아가기
 $land->[$ssx][$ssy] = $HlandIce; # 바다가 됨
 $landValue->[$ssx][$ssy] = 1;
	 } elsif ($kind == $HlandMonster) {
 # 괴수는
			# 대상이 되는 괴수각 요소 꺼내기
			my($tKind, $tName, $tHp) = monsterSpec($landValue->[$ssx][$ssy]);
			my($tlv) = $landValue->[$ssx][$ssy];
			my($tspecial) = $HmonsterSpecial[$tKind];
			 if(($tKind == 28) ||
				($tKind == 30)) {
				$dmge = random(4);
				$tHp -= $dmge;
				$tlv -= $dmge;
				$landValue->[$ssx][$ssy] = $tlv;

				if($tHp < 1){
				# 대상의 괴수가 쓰러져 황무지가 됨
				$land->[$ssx][$ssy] = $HlandIce;
				$landValue->[$ssx][$ssy] = 0;
				# 포상금
				my($value) = $HmonsterValue[$tKind];
				 $island->{'money'} += $value;
				 logMsMonMoney($id, $tName, $value);
				}
			 }
 } else {
 # 전체가불태됩니다
 $land->[$ssx][$ssy] = $HlandIce; # 황무지가 됨
 $landValue->[$ssx][$ssy] = 0;
 }

 # 로그 생성
 logMonsCold($id, $name, landName($kind, $lv), "($ssx, $ssy)", $mName);
 }
 }


 if (($mKind == 14) &&
		($island->{'monsterlive'} < 7)) {
 my($i, $ssx, $ssy, $kind, $lv);
 for($i = 1; $i < 7; $i++) {
 $ssx = $sx + $ax[$i];
 $ssy = $sy + $ay[$i];

 # 행 기준 위치 조정
 if((($ssy % 2) == 0) && (($sy % 2) == 1)) {
 $ssx--;
 }
		 if(($ssx < 0) || ($ssx>= $HislandSize) ||
		 ($ssy < 0) || ($ssy>= $HislandSize)) {
		 # 범위 밖
		 next;
		 }

 $kind = $land->[$ssx][$ssy];
 $lv = $landValue->[$ssx][$ssy];

 if (($kind == $HlandSea) ||
 ($kind == $HlandSeacity) ||
 ($kind == $HlandSeatown) ||
 ($kind == $HlandUmishuto) ||
 ($kind == $HlandOil) ||
 ($kind == $HlandFune) ||
 ($kind == $HlandFrocity) ||
 ($kind == $HlandNursery) ||
 ($kind == $HlandUmiamu) ||
 ($kind == $HlandMountain) ||
 ($kind == $HlandGold) ||
 ($kind == $HlandOnsen) ||
 ($kind == $HlandMonster) ||
 ($kind == $HlandSbase)) {
 # 바다와 해저 기지는 소각되지 않음
 next;
 } else {
 # 전체가불태됩니다
		 $kind = 11;
		 $lv = $lv = ($kind << 4)
			+ $HmonsterBHP[$kind] + random($HmonsterDHP[$kind]);
		 $land->[$ssx][$ssy] = $HlandMonster;
		 $landValue->[$ssx][$ssy] = $lv;
 }
		 if (rand(1000) < 50) {
		 $land->[$ssx][$ssy] = $HlandMonument;
		 $landValue->[$ssx][$ssy] = 77;
		 }
 # 로그 생성
		 lognewMonsterBorn($id, $name, "($ssx, $ssy)");
 }
 }

	 # 이동 완료 플래그
	 if($HmonsterSpecial[$mKind] == 2) {
		# 이동 완료 플래그가 설정되어 있지 않음
	 } elsif($HmonsterSpecial[$mKind] == 1) {
		# 속이괴수
		$monsterMove[$sx][$sy] = $monsterMove[$x][$y] + 1;
	 } else {
		# 일반의 괴수
		$monsterMove[$sx][$sy] = 2;
	 }

	 if(($l == $HlandDefence) && ($HdBaseAuto == 1)) {
		# 방위 시설을 밟음입니다
		logMonsMoveDefence($id, $name, $lName, $point, $mName);

		# 광역 피해 루틴
		wideDamage($id, $name, $land, $landValue, $sx, $sy);
 } elsif ($l == $HlandMine) {
 # 지뢰를 밟음입니다
 if ($mHp < $lv) {
 # 사망하여 시체가 흩어짐
 logMonsMineKill($id, $name, $lName, $point, $mName);
 } elsif ($mHp == $lv) {
 # 사망하여 시체가 남음
 logMonsMineDead($id, $name, $lName, $point, $mName);

 # 수입
 my($value) = $HmonsterValue[$mKind];
 if($value> 0) {
 $island->{'money'} += $value;
 logMsMonMoney($id, $mName, $value);
 }

 # 괴수퇴치 수
 $island->{'taiji'}++;

 # 수상 관계
 my($prize) = $island->{'prize'};
 $prize =~ /([0-9]*),([0-9]*),(.*)/;
 my($flags) = $1;
 my($monsters) = $2;
 my($turns) = $3;
 my($v) = 2 ** $mKind;
 $monsters |= $v;
 $island->{'prize'} = "$flags,$monsters,$turns";
 } else {
 # 살아남음
 logMonsMineHit($id, $name, $lName, $point, $mName);
 $landValue->[$sx][$sy] -= $lv;
 next;
 }

 # 괴수는 황무지에
 $land->[$sx][$sy] = $HlandWaste;
 $landValue->[$sx][$sy] = 1;
	 } else {
		# 연결선이황무지가 됨
 if ($l == $HlandWaste) {
 } else {
		 logMonsMove($id, $name, $lName, $point, $mName);
 }
	 }
	}

	if(($landKind == $HlandConden4) && ($lv == 99)) {
	 my($l) = $land->[$x][$y];
	 my($lv) = $landValue->[$x][$y];
	 my($point) = "($x, $y)";
	 my($lName) = landName($l, $lv);
	 $etc9 = $island->{'etc9'};
	 $etc9 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	 ($co7, $magicf, $magici, $magica, $magicw, $magicl, $magicd) = ($1, $2, $3, $4, $5, $6, $7);

	 if($magica != $magicl) {
	 logRouden2($id, $name, $lName, $point);

		 my($sx, $sy, $i, $landKind, $landName, $lv, $point);

		 my($yh) = 19;
			# 범위 밖 판정
			if($s02>= 25) {
			 $yh = 7;
			}

		 for($i = 1; $i < $yh; $i++) {
			$sx = $x + $ax[$i];
			$sy = $y + $ay[$i];

			# 행 기준 위치 조정
			if((($sy % 2) == 0) && (($y % 2) == 1)) {
			 $sx--;
			}

			$landKind = $land->[$sx][$sy];
			$lv = $landValue->[$sx][$sy];
			$landName = landName($landKind, $lv);
			$point = "($sx, $sy)";

			# 범위 밖 판정
			if(($sx < 0) || ($sx>= $HislandSize) ||
			 ($sy < 0) || ($sy>= $HislandSize)) {
			 next;
			}

			# 범위에 한분기
			if($i < 7) {
			 # 중심 및 1헥스
			 if($landKind == $HlandSea) {
				$landValue->[$sx][$sy] = 0;
				next;
			 } elsif(($landKind == $HlandSbase) ||
				 ($landKind == $HlandSeacity) ||
				 ($landKind == $HlandSeatown) ||
				 ($landKind == $HlandUmishuto) ||
				 ($landKind == $HlandFune) ||
				 ($landKind == $HlandIce) ||
				 ($landKind == $HlandFrocity) ||
				 ($landKind == $HlandUmiamu) ||
				 ($landKind == $HlandOil)) {
				logWideDamageSea2($id, $name, $landName, $point);
				$land->[$sx][$sy] = $HlandSea;
				$landValue->[$sx][$sy] = 0;
			 } else {

				 logBariaAttack($id, $name, $landName, $point);

				$land->[$sx][$sy] = $HlandSea;
				if($i == 0) {
				 # 바다
				 $landValue->[$sx][$sy] = 0;
				} else {
				 # 얕은 바다
				 $landValue->[$sx][$sy] = 1;
				}
			 }
			} else {
			 # 2헥스
			 if(($landKind == $HlandSea) ||
			 ($landKind == $HlandIce) ||
			 ($landKind == $HlandOil) ||
			 ($landKind == $HlandWaste) ||
			 ($landKind == $HlandMountain) ||
			 ($landKind == $HlandGold) ||
			 ($landKind == $HlandOnsen) ||
			 ($landKind == $HlandSeacity) ||
			 ($landKind == $HlandUmishuto) ||
			 ($landKind == $HlandSeatown) ||
			 ($landKind == $HlandFune) ||
			 ($landKind == $HlandFrocity) ||
			 ($landKind == $HlandUmiamu) ||
			 ($landKind == $HlandSbase)) {
				next;
			 } else {
				logBariaAttack($id, $name, $landName, $point);
				$land->[$sx][$sy] = $HlandWaste;
				$landValue->[$sx][$sy] = 0;
			 }
			}
		 }

	 }
	}

	if((($landKind == $HlandConden2) || ($landKind == $HlandConden3)) && ($island->{'roudenflag'} == 0)) {
	 my($l) = $land->[$x][$y];
	 my($lv) = $landValue->[$x][$y];
	 my($point) = "($x, $y)";
	 my($lName) = landName($l, $lv);

	 if(random(150000) < 125+$island->{'co8'}/2.5) {
	 logRouden($id, $name, $lName, $point);
	 $land->[$x][$y] = $HlandConden4;
	 $island->{'roudenflag'}++;

		if($landKind == $HlandConden2) {
		$landValue->[$x][$y] = 2;
		}
		if($landKind == $HlandConden3) {
		$landValue->[$x][$y] = 3;
		}
	 }
	}

	if((($landKind == $HlandConden2) || ($landKind == $HlandConden3) || (($landKind == $HlandCollege) && ($lv == 8))) && ($island->{'roudenflag'} == 0)) {
	 my($l) = $land->[$x][$y];
	 my($lv) = $landValue->[$x][$y];
	 my($point) = "($x, $y)";
	 my($lName) = landName($l, $lv);
	# 안형운석판정

	if((random(333333) < 100+$island->{'co8'}/3) && ($island->{'ene'}> 5000000)) {

	 my($i, $count, $sx, $sy);
	 $count = 0;
	 for($i = 0; $i < 7; $i++) {
		 $sx = $x + $ax[$i];
		 $sy = $y + $ay[$i];

		 # 행 기준 위치 조정
		 if((($sy % 2) == 0) && (($y % 2) == 1)) {
		 $sx--;
		 }

		 if(($sx < 0) || ($sx>= $HislandSize) ||
		 ($sy < 0) || ($sy>= $HislandSize)) {
		 # 범위 밖의 경우
		 if($kind == $HlandSea) {
			 # 바다이면 가 산
			 $count++;
		 }
		 } else {
		 # 범위 안의 경우
		 if(($land->[$sx][$sy] == $HlandDefence) && ($landValue->[$sx][$sy] == 77)) {
			logTrainEnd2($id, $name, "방위 시설·개정", "($sx, $sy)");
			$land->[$sx][$sy] = $HlandWaste;
			$landValue->[$sx][$sy] = 0;
			 $count++;
		 }
		 }
	 }

	 if(($count> 0) && ($island->{'eis5'}>= 1)) {

		logMidMeteo2($id, $name, $point);
		$island->{'roudenflag'}++;
		$island->{'eis5'} -= random(50);
		 if($island->{'eis5'} < 1) {
		 $island->{'eis5'} = 0;
				logEiseiEnd($id, $name, "방위위성");
		 }

		} else {

		logMidMeteo($id, $name, $point);
		$island->{'roudenflag'}++;

		 for($i = 0; $i < 7; $i++) {
			$sx = $x + $ax[$i];
			$sy = $y + $ay[$i];

			# 행 기준 위치 조정
			if((($sy % 2) == 0) && (($y % 2) == 1)) {
			 $sx--;
			}

			$landKind = $land->[$sx][$sy];
			$lv = $landValue->[$sx][$sy];
			$landName = landName($landKind, $lv);
			$point = "($sx, $sy)";

			# 범위 밖 판정
			if(($sx < 0) || ($sx>= $HislandSize) ||
			 ($sy < 0) || ($sy>= $HislandSize)) {
			 next;
			}

			# 범위에 한분기
			if($i < 1) {
			 if($landKind == $HlandSea) {
				$landValue->[$sx][$sy] = 0;
				next;
			 } elsif(($landKind == $HlandSbase) ||
				 ($landKind == $HlandSeacity) ||
				 ($landKind == $HlandSeatown) ||
				 ($landKind == $HlandUmishuto) ||
				 ($landKind == $HlandFune) ||
				 ($landKind == $HlandIce) ||
				 ($landKind == $HlandFrocity) ||
				 ($landKind == $HlandUmiamu) ||
				 ($landKind == $HlandOil)) {
				logWideDamageSea2($id, $name, $landName, $point);
				$land->[$sx][$sy] = $HlandSea;
				$landValue->[$sx][$sy] = 1;
			 }
			 # 중심 및 1헥스
				logWideDamageSea($id, $name, $landName, $point);
				$land->[$sx][$sy] = $HlandSea;
				$landValue->[$sx][$sy] = 1;
			 } else {
			 if(($landKind == $HlandSea) ||
				 ($landKind == $HlandSbase) ||
				 ($landKind == $HlandSeacity) ||
				 ($landKind == $HlandSeatown) ||
				 ($landKind == $HlandUmishuto) ||
				 ($landKind == $HlandFune) ||
				 ($landKind == $HlandIce) ||
				 ($landKind == $HlandFrocity) ||
				 ($landKind == $HlandUmiamu) ||
				 ($landKind == $HlandWaste) ||
				 ($landKind == $HlandOil)) {
				next;
			 }
				if(random(100) < 40) {
				logWideDamageWaste($id, $name, $landName, $point);
				$land->[$sx][$sy] = $HlandWaste;
				$landValue->[$sx][$sy] = 0;
				}
			 }
		 }
		}
	 }
	}

	# 화재판정
	if((($landKind == $HlandTown) && ($lv> 30)) ||
	 ($landKind == $HlandHaribote) ||
	 ($landKind == $HlandMinato) ||
	 ($landKind == $HlandFoodim) ||
	 ($landKind == $HlandFoodka) ||
	 ($landKind == $HlandOnsen) ||
	 ($landKind == $HlandKura) ||
	 ($landKind == $HlandKuraf) ||
	 ($landKind == $HlandHTFactory) ||
	 ($landKind == $HlandSHTF) ||
	 ($landKind == $HlandFactory)) {
	 if(random(1000) < $HdisFire-int($island->{'eis1'}/20)) {
		# 주변의 숲와 기념비를 수 가능
		if((countAround($land, $x, $y, $HlandForest, 7) +
		 countAround($land, $x, $y, $HlandProcity, 7) +
		 countAround($land, $x, $y, $HlandHouse, 7) +
		 countAround($land, $x, $y, $HlandTaishi, 7) +
		 countAround($land, $x, $y, $HlandMonument, 7)) == 0) {
		 # 없어진 경우 화재로 괴멸
		 my($l) = $land->[$x][$y];
		 my($lv) = $landValue->[$x][$y];
		 my($point) = "($x, $y)";
		 my($lName) = landName($l, $lv);
		 logFire($id, $name, $lName, $point);
		 $land->[$x][$y] = $HlandWaste;
		 $landValue->[$x][$y] = 0;
				if ($kind == $HlandOnsen) {
 	# 금광산은 산에돌아가기
 	$land->[$x][$y] = $HlandMountain; # 바다가 됨
 	$landValue->[$x][$y] = 0;
 		}
		}
	 }
	}

	# 화재판정2
	if(($landKind == $HlandNewtown) ||
	 ($landKind == $HlandRizort) ||
	 ($landKind == $HlandKajino) ||
	 ($landKind == $HlandBigRizort) ||
	 ($landKind == $HlandBettown) ||
	 ($landKind == $HlandSkycity) ||
	 ($landKind == $HlandUmicity) ||
	 ($landKind == $HlandBigtown)) {
	 if(random(750) < $HdisFire-int($island->{'eis1'}/20)) {
		# 주변의 숲와 기념비를 수 가능
		if((countAround($land, $x, $y, $HlandForest, 7) +
		 countAround($land, $x, $y, $HlandProcity, 7) +
		 countAround($land, $x, $y, $HlandHouse, 7) +
		 countAround($land, $x, $y, $HlandTaishi, 7) +
		 countAround($land, $x, $y, $HlandMonument, 7)) == 0) {
		 # 없어진 경우 화재로 괴멸
		 my($l) = $land->[$x][$y];
		 my($lv) = $landValue->[$x][$y];
		 my($point) = "($x, $y)";
		 my($lName) = landName($l, $lv);
		 logFirenot($id, $name, $lName, $point);
	 $landValue->[$x][$y] -= random(100)+50;
		}
			if($landValue->[$x][$y] <= 0) {
			 # 평지로 되돌리기
			 my($l) = $land->[$x][$y];
			 my($lv) = $landValue->[$x][$y];
			 my($point) = "($x, $y)";
			 my($lName) = landName($l, $lv);
			 $land->[$x][$y] = $HlandWaste;
			 $landValue->[$x][$y] = 0;
		 	 logFire($id, $name, $lName, $point);
			 next;
			}
	 }
	}
 }

 if ($rizortincome> 0) {
 logParkMoney($id, $name, "$rizortincome$HunitMoney", $island->{'riz'},"리조트 시설");
 }

 if ($m84income> 0) {
 logParkMoney($id, $name, "$m84income$HunitMoney", $island->{'m84'},"고대 유적");
 }

 if ($island->{'par'}> 0) {
 logParkMoney($id, $name, "$parkincome$HunitMoney", $island->{'par'},"놀이공원");
 }

 if ($island->{'oil'}> 0) {
 logParkMoney($id, $name, "$oilincome$HunitMoney", $island->{'oil'},"유전");
 }

 if ($island->{'gyo'}> 0) {
 logParkMoney($id, $name, "$gyosenincome$HunitFood", $island->{'gyo'},"어선");
 }

 if ($island->{'trainmoney'}> 0) {
 logParkMoney($id, $name, "$island->{'trainmoney'}$HunitMoney", $island->{'tra1'},"일반 열차");
 }
 if ($island->{'trainmoney2'}> 0) {
 logParkMoney($id, $name, "$island->{'trainmoney2'}$HunitMoney", $island->{'tra2'},"화물 열차");
 }

}


# 주변의 읍, 농장이 있는 지판정
sub countGrow {
 my($land, $landValue, $x, $y) = @_;
 my($i, $sx, $sy);
 for($i = 1; $i < 7; $i++) {
	 $sx = $x + $ax[$i];
	 $sy = $y + $ay[$i];

	 # 행 기준 위치 조정
	 if((($sy % 2) == 0) && (($y % 2) == 1)) {
	 $sx--;
	 }

	 if(($sx < 0) || ($sx>= $HislandSize) ||
	 ($sy < 0) || ($sy>= $HislandSize)) {
	 } else {
	 # 범위 안의 경우
	 if(($land->[$sx][$sy] == $HlandTown) ||
		($land->[$sx][$sy] == $HlandProcity) ||
		($land->[$sx][$sy] == $HlandNewtown) ||
		($land->[$sx][$sy] == $HlandRizort) ||
		($land->[$sx][$sy] == $HlandKajino) ||
		($land->[$sx][$sy] == $HlandBigRizort) ||
		($land->[$sx][$sy] == $HlandBettown) ||
		($land->[$sx][$sy] == $HlandSkycity) ||
		($land->[$sx][$sy] == $HlandUmicity) ||
		($land->[$sx][$sy] == $HlandBigtown) ||
		($land->[$sx][$sy] == $HlandFarm)) {
		 if($landValue->[$sx][$sy] != 1) {
		 return 1;
		 }
	 }
	 }
 }
 return 0;
}


# 실업자는 어디로?
sub doIslandunemployed {
 my($number, $island) = @_;

 # 도출 값
 my($name) = $island->{'name'};
 my($id) = $island->{'id'};
 my($land) = $island->{'land'};
 my($landValue) = $island->{'landValue'};

 # 실업자의 이민
 if(($island->{'unemployed'}>= 100) && (rand(100) < 25)) {
 # 실업자가1만 명이상있으면 25% 확률로 이민을 희망하다

 my(@order) = randomArray($HislandNumber);
 my($migrate);

 # 이민선을 탐색
 my($tIsland);
 my($n) = min($HislandNumber, 5);
 my($i);
 for($i = 0; $i < $n; $i++) { # 5섬까지조사하기
 $tIsland = $Hislands[$order[$i]];

 # 일자리가 있는 섬으로 이민
 if ($tIsland->{'unemployed'} < 0) {
 $migrate = min($island->{'unemployed'}, -$tIsland->{'unemployed'});
		$migrate2 = $migrate;
 last;
 }
 }

 if ($i>= $n) {
 # 이민선을 찾지 못하면 폭동 처리로 진행

 $migrate = random($island->{'unemployed'} - 100) + 100;
 $n = 0;
 my($x, $y, $landKind, $lv);
 for($i = 0; $i < $HpointNumber; $i++) {
 $x = $Hrpx[$i];
 $y = $Hrpy[$i];
 $landKind = $land->[$x][$y];
 $lv = $landValue->[$x][$y];

 if(($landKind == $HlandFarm) ||
 ($landKind == $HlandFactory) ||
 ($landKind == $HlandHTFactory) ||
 ($landKind == $HlandSHTF) ||
 ($landKind == $HlandOWNF) ||
 ($landKind == $HlandFarmchi) ||
 ($landKind == $HlandFarmpic) ||
 ($landKind == $HlandFarmcow) ||
 ($landKind == $HlandEneAt) ||
 ($landKind == $HlandEneFw) ||
 ($landKind == $HlandEneWt) ||
 ($landKind == $HlandEneWd) ||
 ($landKind == $HlandEneBo) ||
 ($landKind == $HlandEneSo) ||
 ($landKind == $HlandEneCs) ||
 ($landKind == $HlandCollege) ||
 ($landKind == $HlandYakusho) ||
 ($landKind == $HlandBase) ||
		 ($landKind == $HlandFoodim) ||
		 ($landKind == $HlandFoodka) ||
	 ($landKind == $HlandNursery) ||
	 ($landKind == $HlandMine) ||
 ($landKind == $HlandPark) ||
 ($landKind == $HlandKyujo) ||
 ($landKind == $HlandKyujokai) ||
 ($landKind == $HlandZoo) ||
 ($landKind == $HlandKura) ||
 ($landKind == $HlandKuraf) ||
 ($landKind == $HlandDefence)) {
 # 25% 확률로 괴멸
 if(rand(100) < 25) {
 $n++;
 logUnemployedRiot($id, $name, landName($landKind, $lv), $migrate2, "($x, $y)");
 $land->[$x][$y] = $HlandWaste;
 $landValue->[$x][$y] = 0;
 }
 }
 }

 # 아무것도 파괴되지 않았을 때도 처리 진행
 logUnemployedDemo($id, $name, $migrate2) if ($n == 0);

 } else {
 # 이민선을 사용했으므로 이민 처리
 my($tLand) = $tIsland->{'land'};
 my($tLandValue) = $tIsland->{'landValue'};

 my($employed) = $migrate;
 my($x, $y, $landKind, $lv);
 for($i = 0; $i < $HpointNumber; $i++) {
 $x = $Hrpx[$i];
 $y = $Hrpy[$i];
 $landKind = $tLand->[$x][$y];
 $lv = $tLandValue->[$x][$y];

	 if($landKind == $HlandSeki) {
 logUnemployedReturn($id, $tIsland->{'id'}, $name, landName($landKind, $lv), $tIsland->{'name'}, $migrate2);
		 return 1;
		 }
	 }

 # 이민선의 읍에가를 준비하다
 my($employed) = $migrate;
 my($x, $y, $landKind, $lv);
 for($i = 0; $i < $HpointNumber; $i++) {
 $x = $Hrpx[$i];
 $y = $Hrpy[$i];
 $landKind = $tLand->[$x][$y];
 $lv = $tLandValue->[$x][$y];

 if(($landKind == $HlandTown) ||
 ($landKind == $HlandMinato) ||
 ($landKind == $HlandNewtown) ||
 ($landKind == $HlandFrocity) ||
 ($landKind == $HlandOnsen) ||
 ($landKind == $HlandSeacity)) {
 # 읍
 $n = int((255 - $lv) / 2);
 $n = min(int($n + rand($n)), $employed);
 $employed -= $n;
 $tLandValue->[$x][$y] += $n;
 } elsif ($landKind == $HlandPlains) {
 # 평지
 $n = int((255 - $lv) / 2);
 $n = min(int($n + rand($n)), $employed);
 $employed -= $n;
 $tLand->[$x][$y] = $HlandTown;
 $tLandValue->[$x][$y] = $n;
 }

 last if ($employed <= 0);
 }
 $migrate -= $employed;
 $island->{'unemployed'} -= $migrate;
 $tIsland->{'unemployed'} += $migrate;
 $island->{'pop'} -= $migrate;
 $tIsland->{'pop'} += $migrate;

 # 기존 거주지를 처분
 $employed = $migrate;
 for($i = 0; $i < $HpointNumber; $i++) {
 $x = $Hrpx[$i];
 $y = $Hrpy[$i];
 $landKind = $land->[$x][$y];
 $lv = $landValue->[$x][$y];

 if((($landKind == $HlandTown) && ($lv> 1)) ||
		 (($landKind == $HlandMinato) && ($lv> 1)) ||
		 (($landKind == $HlandProcity) && ($lv> 1)) ||
		 (($landKind == $HlandFrocity) && ($lv> 1)) ||
		 (($landKind == $HlandNewtown) && ($lv> 1)) ||
		 (($landKind == $HlandBigtown) && ($lv> 1)) ||
		 (($landKind == $HlandBettown) && ($lv> 1)) ||
		 (($landKind == $HlandSkycity) && ($lv> 1)) ||
		 (($landKind == $HlandUmicity) && ($lv> 1)) ||
		 (($landKind == $HlandSeatown) && ($lv> 1)) ||
		 (($landKind == $HlandShuto) && ($lv> 1)) ||
		 (($landKind == $HlandUmishuto) && ($lv> 1)) ||
		 (($landKind == $HlandOnsen) && ($lv> 1)) ||
		 (($landKind == $HlandSeacity) && ($lv> 1))) {
 # 읍
 $n = min($lv - 1, $employed);
 $landValue->[$x][$y] -= $n;
 $employed -= $n;

			if($landValue->[$x][$y] <= 0) {
			 $land->[$x][$y] = $HlandPlains;
			 $landValue->[$x][$y] = 0;
			}

 }
 }

 logUnemployedMigrate($id, $tIsland->{'id'}, $name, $tIsland->{'name'}, $migrate2);
 }
 }
}

# 섬 전체
sub doIslandProcess {
 my($number, $island) = @_;

 # 도출 값
 my($name) = $island->{'name'};
 my($id) = $island->{'id'};
 my($land) = $island->{'land'};
 my($landValue) = $island->{'landValue'};


 $etc5 = $island->{'etc5'};
 $etc5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
 ($s00,$s01,$s02,$s03,$s04,$s05,$s06,$s07,$s08,$s09,$s10,$s11,$s12,$s13,$s14,$s15,$s16,$s17,$s18,$s19,$s20,$s21,$s22,$s23,$s24,$s25,$s26,$s27,$s28,$s29,$s30) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);


 $etc7 = $island->{'etc7'};
 $etc7 =~ /^([0-9]*),([0-9]*),([0-9]*)$/;
 ($msjotai, $nokotan, $msid) = ($1, $2, $3);
	$nokotan -= 1;
	$island->{'etc7'} = "$msjotai,$nokotan,$msid";
	if ($nokotan < 1) {
	 $island->{'etc7'} = '0,0,0';
	}

 if ($island->{'stsankahantei'} == 1) {
	$value = $stsanka*random(2000);
	$island->{'money'} += $value;
	$str = "$value$HunitMoney";
	logHCstart($id, $name, $str);
 }


 if ($island->{'htf'}> 0) {
	 if($anothermood == 1) {
		$pika2 = int($island->{'amarimoney'}/2)
	 } else {
		$pika2 = int($island->{'pika'}/2);
	 }
	if ($pika2 < 0) {
	 $pika2 = 0;
	}
	$island->{'money'} -= $pika2;
 }

 elsif ($island->{'shtf'}> 0) {
	 if($anothermood == 1) {
		$pika2 = int($island->{'amarimoney'}/5)
	 } else {
		$pika2 = int($island->{'pika'}/5);
	 }
	if ($pika2 < 0) {
	 $pika2 = 0;
	}
	$island->{'money'} -= $pika2;
 }

 if(($HislandTurn % 100) == 0) {
	$island->{'ip8'} = 0;
 }

	$etc8 = $island->{'etc8'};
	$etc8 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	($toto1, $toto2, $toto3, $toto4, $toto5, $toto6, $toto7) = ($1, $2, $3, $4, $5, $6, $7);


 # 리조트가 포화 상태가 되었습니다
 if(($island->{'riz'}> 0) && (rand(40)> $s06) && (rand(500+$s06*2) < 15)) {

 my(@order) = randomArray($HislandNumber);
 my($migrate);

 # 이민선을 탐색
 my($tIsland);
 my($n) = min($HislandNumber, 5);
 my($i);
 for($i = 0; $i < $n; $i++) { # 5섬까지조사하기
 $tIsland = $Hislands[$order[$i]];

	 $tetc5 = $tIsland->{'etc5'};
	 $tetc5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	 ($ts00,$ts01,$ts02,$ts03,$ts04,$ts05,$ts06,$ts07,$ts08,$ts09,$ts10,$ts11,$ts12,$ts13,$ts14,$ts15,$ts16,$ts17,$ts18,$ts19,$ts20,$ts21,$ts22,$ts23,$ts24,$ts25,$ts26,$ts27,$ts28,$ts29,$ts30) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);
	 $ts06b = int($ts06/5);

 # 일자리가 있는 섬으로 이민
 if (($island->{'pop'}> $tIsland->{'pop'}) && ($tIsland->{'riz'}> 0) && ($s06 <= $ts06) && ($island->{'id'} != $tIsland->{'id'})) {
 $migrate = ($ts06 - $s06 + 1) * (random(5) + 1);
		 if ($migrate <= 0) {
			 $migrate = 1;
		 }
		$migrate2 = $migrate;
 last;
 }
 }

 if ($i>= $n) {

 } else {
 # 이민선을 사용했으므로 이민 처리
 my($tLand) = $tIsland->{'land'};
 my($tLandValue) = $tIsland->{'landValue'};
 my($employed) = $migrate;

 # 이민선의 읍에가를 준비하다
 my($employed) = $migrate;
 my($x, $y, $landKind, $lv);
 for($i = 0; $i < $HpointNumber; $i++) {
 $x = $Hrpx[$i];
 $y = $Hrpy[$i];
 $landKind = $tLand->[$x][$y];
 $lv = $tLandValue->[$x][$y];

 if($landKind == $HlandRizort) {
 # 읍
 $n = int((350 - $lv) / 2);
 $n = min(int($n + rand($n)), $employed);
 $employed -= $n;
 $tLandValue->[$x][$y] += $n;
 } elsif ($landKind == $HlandBigRizort) {
 # 평지
 $n = int((800 - $lv) / 2);
 $n = min(int($n + rand($n)), $employed);
 $employed -= $n;
 $tLandValue->[$x][$y] += $n;
 } elsif ($landKind == $HlandKajino) {
 # 평지
 $n = int((2000 - $lv) / 2);
 $n = min(int($n + rand($n)), $employed);
 $employed -= $n;
 $tLandValue->[$x][$y] += $n;
 }

 last if ($employed <= 0);
 }
 $migrate -= $employed;
 $island->{'pop'} -= $migrate;
 $tIsland->{'pop'} += $migrate;

 # 기존 거주지를 처분
 $employed = $migrate;
 for($i = 0; $i < $HpointNumber; $i++) {
 $x = $Hrpx[$i];
 $y = $Hrpy[$i];
 $landKind = $land->[$x][$y];
 $lv = $landValue->[$x][$y];

 if((($landKind == $HlandRizort) && ($lv> 1)) ||
		 (($landKind == $HlandBigRizort) && ($lv> 1))) {
 # 읍
 $n = min($lv - 1, $employed);
 $landValue->[$x][$y] -= $n;
 $employed -= $n;

			if($landValue->[$x][$y] <= 0) {
			 $land->[$x][$y] = $HlandPlains;
			 $landValue->[$x][$y] = 0;
			}

 }
 }

 logUnemployedMigrate2($id, $tIsland->{'id'}, $name, $tIsland->{'name'}, $migrate2);
 }
 } elsif(($island->{'riz'}> 0) && (rand(20)> $s06) && (rand(500+$s06) < 20)) {

 my(@order) = randomArray($HislandNumber);
 my($migrate);

 # 이민선을 탐색
 my($tIsland);
 my($n) = min($HislandNumber, 5);
 my($i);
 for($i = 0; $i < $n; $i++) { # 5섬까지조사하기
 $tIsland = $Hislands[$order[$i]];

 # 일자리가 있는 섬으로 이민
 if (($island->{'pop'}> $tIsland->{'pop'}) &&($island->{'id'} != $tIsland->{'id'})) {
 $migrate = (25 - $s06 + 1) * (random(3) + 1);
		 if ($migrate <= 0) {
			 $migrate = 1;
		 }
		$migrate2 = $migrate;
 last;
 }
 }

 if ($i>= $n) {

 } else {
 # 이민선을 사용했으므로 이민 처리
 my($tLand) = $tIsland->{'land'};
 my($tLandValue) = $tIsland->{'landValue'};
 my($employed) = $migrate;
 my($sekiflag) = 0;

 my($x, $y, $landKind, $lv);
 for($i = 0; $i < $HpointNumber; $i++) {
 $x = $Hrpx[$i];
 $y = $Hrpy[$i];
 $landKind = $tLand->[$x][$y];
 $lv = $tLandValue->[$x][$y];

	 if($landKind == $HlandSeki) {
 logUnemployedReturn2($id, $tIsland->{'id'}, $name, landName($landKind, $lv), $tIsland->{'name'}, $migrate2);
 $sekiflag++;
		 $migrate = 0;
		}

	 }

 # 이민선의 읍에가를 준비하다
 my($employed) = $migrate;
 my($x, $y, $landKind, $lv);
 for($i = 0; $i < $HpointNumber; $i++) {
 $x = $Hrpx[$i];
 $y = $Hrpy[$i];
 $landKind = $tLand->[$x][$y];
 $lv = $tLandValue->[$x][$y];

 if(($landKind == $HlandTown) ||
		 ($landKind == $HlandMinato) ||
		 ($landKind == $HlandProcity) ||
		 ($landKind == $HlandFrocity) ||
		 ($landKind == $HlandNewtown) ||
		 ($landKind == $HlandBigtown) ||
		 ($landKind == $HlandBettown) ||
		 ($landKind == $HlandSeatown) ||
		 ($landKind == $HlandOnsen) ||
		 ($landKind == $HlandSeacity)) {
 # 읍
 $n = int((2000 - $lv) / 2);
 $n = min(int($n + rand($n)), $employed);
 $employed -= $n;
 $tLandValue->[$x][$y] += $n;
 } elsif ($landKind == $HlandPlains) {
 # 평지
 $n = int((255 - $lv) / 2);
 $n = min(int($n + rand($n)), $employed);
 $employed -= $n;
 $tLand->[$x][$y] = $HlandTown;
 $tLandValue->[$x][$y] = $n;
 }

 last if ($employed <= 0);
 }
 $migrate -= $employed;
 $island->{'pop'} -= $migrate;
 $tIsland->{'pop'} += $migrate;

 # 기존 거주지를 처분
 $employed = $migrate;
 for($i = 0; $i < $HpointNumber; $i++) {
 $x = $Hrpx[$i];
 $y = $Hrpy[$i];
 $landKind = $land->[$x][$y];
 $lv = $landValue->[$x][$y];

 if((($landKind == $HlandRizort) && ($lv> 1)) ||
		 (($landKind == $HlandBigRizort) && ($lv> 1)) ||
		 (($landKind == $HlandKajino) && ($lv> 1))) {
 # 읍
 $n = min($lv - 1, $employed);
 $landValue->[$x][$y] -= $n;
 $employed -= $n;

			if($landValue->[$x][$y] <= 0) {
			 $land->[$x][$y] = $HlandPlains;
			 $landValue->[$x][$y] = 0;
			}

 }
 }

	 if($sekiflag == 0) {
		 logUnemployedMigrate3($id, $tIsland->{'id'}, $name, $tIsland->{'name'}, $migrate2);
		}

 }
 }


 # 지진판정
 if(random(1000) < (($island->{'prepare2'} + 1) * $HdisEarthquake)-int($island->{'eis2'}/15)-int($s04/10)) {
	# 지진발생
	logEarthquake($id, $name);

 if($toto2> 0) {
	$toto2--;
	$island->{'etc8'} = "$toto1,$toto2,$toto3,$toto4,$toto5,$toto6,$toto7";
	logOmamori($id, $name);
 } else {

	my($x, $y, $landKind, $lv, $i);
	for($i = 0; $i < $HpointNumber; $i++) {
	 $x = $Hrpx[$i];
	 $y = $Hrpy[$i];
	 $landKind = $land->[$x][$y];
	 $lv = $landValue->[$x][$y];

	 if((($landKind == $HlandTown) && ($lv>= 100)) ||
	 (($landKind == $HlandFoodim) && ($lv < 480)) ||
	 (($landKind == $HlandProcity) && ($lv < 130)) ||
	 ($landKind == $HlandHaribote) ||
 ($landKind == $HlandPark) ||
	 ($landKind == $HlandMinato) ||
	 ($landKind == $HlandOnsen) ||
 ($landKind == $HlandKyujo) ||
 ($landKind == $HlandKyujokai) ||
	 ($landKind == $HlandFactory)) {
		# 1/4에서 괴멸
		if(random(4+$island->{'co5'}*5) == 0) {
		 logEQDamage($id, $name, landName($landKind, $lv),
				"($x, $y)");
		 $land->[$x][$y] = $HlandWaste;
		 $landValue->[$x][$y] = 0;
				if ($kind == $HlandOnsen) {
 	# 금광산은 산에돌아가기
 	$land->[$x][$y] = $HlandMountain; # 바다가 됨
 	$landValue->[$x][$y] = 0;
 		}
		}
	 }
	 if((($landKind == $HlandBigtown) && ($lv>= 100)) ||
	 (($landKind == $HlandBettown) && ($lv>= 100)) ||
	 (($landKind == $HlandSkycity) && ($lv>= 100)) ||
	 (($landKind == $HlandShuto) && ($lv>= 100)) ||
	 (($landKind == $HlandUmishuto) && ($lv>= 100)) ||
	 (($landKind == $HlandRizort) && ($lv>= 10)) ||
	 (($landKind == $HlandKajino) && ($lv>= 10)) ||
	 (($landKind == $HlandBigRizort) && ($lv>= 10)) ||
	 (($landKind == $HlandHTFactory) && ($lv>= 10)) ||
	 (($landKind == $HlandSHTF) && ($lv>= 10)) ||
	 (($landKind == $HlandNewtown) && ($lv>= 100))) {
		# 1/4에서 괴멸
		if(random(3+$island->{'co5'}*5) == 0) {
		 logEQDamagenot($id, $name, landName($landKind, $lv),
				"($x, $y)");
	 $landValue->[$x][$y] -= random(100)+50;
		}
			if($landValue->[$x][$y] <= 0) {
			 # 평지로 되돌리기
			 $land->[$x][$y] = $HlandWaste;
			 $landValue->[$x][$y] = 0;
		 	 logEQDamage($id, $name, landName($landKind, $lv),
				"($x, $y)");
			 next;
			}
	 }
	 if(($landKind == $HlandFarmchi) ||
 ($landKind == $HlandFarmpic) ||
	 ($landKind == $HlandFarmcow)) {
		if(random(6) == 0) {
		 logEQDamagenot($id, $name, landName($landKind, $lv),
				"($x, $y)");
	 $landValue->[$x][$y] -= random(400)+50;
		}
		if($landValue->[$x][$y] <= 0) {
		 # 평지로 되돌리기
		 $land->[$x][$y] = $HlandWaste;
		 $landValue->[$x][$y] = 0;
		 logEQDamage($id, $name, landName($landKind, $lv),
			"($x, $y)");
		 next;
		}
	 }
	}
 }
 }



 # 중과 세에키됨주민
 if(random(100) < $island->{'eisei1'}-10-random(5)) {
	# 부족 메시지
	logKire($id, $name);

	my($x, $y, $landKind, $lv, $i);
	for($i = 0; $i < $HpointNumber; $i++) {
	 $x = $Hrpx[$i];
	 $y = $Hrpy[$i];
	 $landKind = $land->[$x][$y];
	 $lv = $landValue->[$x][$y];

	 if(($landKind == $HlandFarm) ||
 ($landKind == $HlandCollege) ||
 ($landKind == $HlandYakusho) ||
	 ($landKind == $HlandFactory) ||
	 ($landKind == $HlandSHTF) ||
	 ($landKind == $HlandOWNF) ||
	 ($landKind == $HlandHTFactory) ||
 ($landKind == $HlandNursery) ||
 ($landKind == $HlandEneAt) ||
 ($landKind == $HlandEneFw) ||
 ($landKind == $HlandEneWt) ||
 ($landKind == $HlandEneWd) ||
 ($landKind == $HlandEneBo) ||
 ($landKind == $HlandEneSo) ||
 ($landKind == $HlandEneCs) ||
	 ($landKind == $HlandBase) ||
	 ($landKind == $HlandPark) ||
	 ($landKind == $HlandKyujo) ||
	 ($landKind == $HlandKyujokai) ||
	 ($landKind == $HlandZoo) ||
	 ($landKind == $HlandHouse) ||
	 ($landKind == $HlandTaishi) ||
	 ($landKind == $HlandTrain) ||
	 ($landKind == $HlandKura) ||
	 ($landKind == $HlandKuraf) ||
	 ($landKind == $HlandDefence)) {
		# 1/4에서 괴멸
		if(random(100) < $island->{'eisei1'}) {
		 logKireDamage($id, $name, landName($landKind, $lv),
				"($x, $y)");
		 $land->[$x][$y] = $HlandWaste;
		 $landValue->[$x][$y] = 0;
 # 양식장이면 얕은 바다
 if($landKind == $HlandNursery) {
 $land->[$x][$y] = $HlandSea;
 $landValue->[$x][$y] = 1;
 }
		}
	 }
	 if(($landKind == $HlandTown) ||
 ($landKind == $HlandMinato) ||
	 ($landKind == $HlandFoodim) ||
 ($landKind == $HlandProcity) ||
	 ($landKind == $HlandFarmchi) ||
	 ($landKind == $HlandFarmpic) ||
	 ($landKind == $HlandFarmcow)) {
		# 1/4에서 괴멸
		if(random(100) < $island->{'eisei1'}-30) {
		 logKireDamage($id, $name, landName($landKind, $lv),
				"($x, $y)");
		 $land->[$x][$y] = $HlandWaste;
		 $landValue->[$x][$y] = 0;
		}
	 }
	 if(($landKind == $HlandSbase) ||
	 ($landKind == $HlandSeacity) ||
	 ($landKind == $HlandUmiamu) ||
	 ($landKind == $HlandFrocity)) {
		# 1/4에서 괴멸
		if(random(100) < $island->{'eisei1'}-60) {
		 logKireDamage($id, $name, landName($landKind, $lv),
				"($x, $y)");
		 $land->[$x][$y] = $HlandSea;
		 $landValue->[$x][$y] = 0;
		}
	 }

	}
 }



 # 식량부족
 if($island->{'food'} <= 0) {
	# 부족 메시지
	logStarve($id, $name);
	$island->{'food'} = 0;


 if($island->{'eis7'}>= 1) {
	$eis7 = $island->{'eis7'};
	 $cstpop = int($eis7/100);
	 $csten = $eis7%100;
	 $tdmg = random(1000);
	 $cstpop = int($cstpop*$tdmg/1000);
 $island->{'eis7'} = $cstpop*100+$csten;
			if($cstpop < $tdmg) {
			$island->{'eis7'} = 0;
			logEiseiEndNopop($id, $name, "우주 정거장");
			}

	}


	my($x, $y, $landKind, $lv, $i);
	for($i = 0; $i < $HpointNumber; $i++) {
	 $x = $Hrpx[$i];
	 $y = $Hrpy[$i];
	 $landKind = $land->[$x][$y];
	 $lv = $landValue->[$x][$y];

	 if(($landKind == $HlandFarm) ||
	 ($landKind == $HlandFoodim) ||
	 ($landKind == $HlandFoodka) ||
 ($landKind == $HlandFarmchi) ||
 ($landKind == $HlandFarmpic) ||
 ($landKind == $HlandFarmcow) ||
 ($landKind == $HlandCollege) ||
 ($landKind == $HlandYakusho) ||
	 ($landKind == $HlandFactory) ||
	 ($landKind == $HlandHTFactory) ||
	 ($landKind == $HlandSHTF) ||
	 ($landKind == $HlandOWNF) ||
 ($landKind == $HlandNursery) ||
	 ($landKind == $HlandBase) ||
 ($landKind == $HlandMine) ||
 ($landKind == $HlandKura) ||
	 ($landKind == $HlandKuraf) ||
	 ($landKind == $HlandDefence)) {
		# 1/4에서 괴멸
		if(random(4) == 0) {
		 logSvDamage($id, $name, landName($landKind, $lv),
				"($x, $y)");
		 $land->[$x][$y] = $HlandWaste;
		 $landValue->[$x][$y] = 0;
 # 양식장이면 얕은 바다
 if($landKind == $HlandNursery) {
 $land->[$x][$y] = $HlandSea;
 $landValue->[$x][$y] = 1;
 }
		}
	 }
	}
 }

 # 쓰나미판정
 if(random(1000) < $HdisTsunami-int($island->{'eis2'}/15)-int($s04/10)) {
	# 쓰나미발생
	logTsunami($id, $name);

 if($toto2> 0) {
	$toto2--;
	$island->{'etc8'} = "$toto1,$toto2,$toto3,$toto4,$toto5,$toto6,$toto7";
	logOmamori($id, $name);
 } else {

	my($x, $y, $landKind, $lv, $i);
	for($i = 0; $i < $HpointNumber; $i++) {
	 $x = $Hrpx[$i];
	 $y = $Hrpy[$i];
	 $landKind = $land->[$x][$y];
	 $lv = $landValue->[$x][$y];

	 if(($landKind == $HlandTown) ||
	 (($landKind == $HlandProcity) && ($lv < 110)) ||
	 ($landKind == $HlandFarm) ||
	 ($landKind == $HlandFarmchi) ||
	 ($landKind == $HlandFarmpic) ||
	 ($landKind == $HlandFarmcow) ||
	 ($landKind == $HlandEneAt) ||
	 ($landKind == $HlandEneFw) ||
	 ($landKind == $HlandEneWt) ||
	 ($landKind == $HlandEneWd) ||
	 ($landKind == $HlandEneBo) ||
	 ($landKind == $HlandEneSo) ||
	 ($landKind == $HlandEneCs) ||
	 ($landKind == $HlandConden) ||
	 ($landKind == $HlandConden2) ||
	 ($landKind == $HlandConden3) ||
	 ($landKind == $HlandConden4) ||
	 ($landKind == $HlandTrain) ||
	 ($landKind == $HlandCollege) ||
	 ($landKind == $HlandYakusho) ||
	 ($landKind == $HlandFoodim) ||
	 ($landKind == $HlandFoodka) ||
	 ($landKind == $HlandFactory) ||
	 ($landKind == $HlandHTFactory) ||
	 ($landKind == $HlandSHTF) ||
	 ($landKind == $HlandOWNF) ||
	 ($landKind == $HlandBase) ||
	 ($landKind == $HlandDefence) ||
 ($landKind == $HlandPark) ||
	 ($landKind == $HlandMinato) ||
	 ($landKind == $HlandFune) ||
	 ($landKind == $HlandSeki) ||
 ($landKind == $HlandMine) ||
 ($landKind == $HlandNursery) ||
 ($landKind == $HlandKyujo) ||
 ($landKind == $HlandKyujokai) ||
 ($landKind == $HlandZoo) ||
 ($landKind == $HlandNewtown) ||
 ($landKind == $HlandBigtown) ||
 ($landKind == $HlandBettown) ||
 ($landKind == $HlandRizort) ||
 ($landKind == $HlandKajino) ||
 ($landKind == $HlandUmicity) ||
 ($landKind == $HlandBigRizort) ||
 ($landKind == $HlandShuto) ||
 ($landKind == $HlandKura) ||
	 ($landKind == $HlandKuraf) ||
	 ($landKind == $HlandHaribote)) {
		# 1d12 <= (주변의 바다 - 1) 데붕괴
		if(random(12+$island->{'co5'}*5) <
		 (countAround($land, $x, $y, $HlandOil, 7) +
		 countAround($land, $x, $y, $HlandSbase, 7) +
		 countAround($land, $x, $y, $HlandSeacity, 7) +
		 countAround($land, $x, $y, $HlandSeatown, 7) +
		 countAround($land, $x, $y, $HlandUmishuto, 7) +
		 countAround($land, $x, $y, $HlandFune, 7) +
		 countAround($land, $x, $y, $HlandFrocity, 7) +
		 countAround($land, $x, $y, $HlandUmiamu, 7) +
		 countAround($land, $x, $y, $HlandSea, 7) - 1)) {
		 logTsunamiDamage($id, $name, landName($landKind, $lv),
				 "($x, $y)");
		 if($landKind == $HlandFune) {
		 $land->[$x][$y] = $HlandSea;
		 $landValue->[$x][$y] = 0;
 # 양식장이면 얕은 바다
 } elsif($landKind == $HlandNursery) {
 $land->[$x][$y] = $HlandSea;
 $landValue->[$x][$y] = 1;
		 } else {
		 $land->[$x][$y] = $HlandWaste;
		 $landValue->[$x][$y] = 0;
		 }
		}
	 }
	}
 }
 }

 # 괴수판정
 my($r) = random(10000);
 my($pop) = $island->{'pop'};
 do{
	if((($r < ($HdisMonster * $island->{'area'})) &&
	 ($pop>= $HdisMonsBorder1)) ||
	 ($island->{'monstersend'}> 0)) {
	 # 괴수출현
	 # 종류를 결하기
	 my($lv, $kind);
	 if($island->{'monstersend'}> 0) {
		# 인공
		$kind = $island->{'monstersendkind'};
		$island->{'monstersend'}--;
	 } elsif($pop>= $HdisMonsBorder4) {
		# level4까지
		$kind = random($HmonsterLevel4) + 1;
	 } elsif($pop>= $HdisMonsBorder3) {
		# level3까지
		$kind = random($HmonsterLevel3) + 1;
	 } elsif($pop>= $HdisMonsBorder2) {
		# level2까지
		$kind = random($HmonsterLevel2) + 1;
	 } else {
		# level1만
		$kind = random($HmonsterLevel1) + 1;
	 }

	 # lv 의 값을 결하기
	 $lv = ($kind << 4)
		+ $HmonsterBHP[$kind] + random($HmonsterDHP[$kind]);

	 # 어디에 출현할지 결정
	 my($bx, $by, $i);
	 for($i = 0; $i < $HpointNumber; $i++) {
		$bx = $Hrpx[$i];
		$by = $Hrpy[$i];
		if(($land->[$bx][$by] == $HlandTown) ||
		 ($land->[$bx][$by] == $HlandBigtown) ||
		 ($land->[$bx][$by] == $HlandBettown) ||
		 ($land->[$bx][$by] == $HlandSkycity) ||
		 ($land->[$bx][$by] == $HlandUmicity) ||
		 ($land->[$bx][$by] == $HlandRizort) ||
		 ($land->[$bx][$by] == $HlandKajino) ||
		 ($land->[$bx][$by] == $HlandBigRizort) ||
		 ($land->[$bx][$by] == $HlandNewtown)) {

		 # 지형 이름
		 my($lName) = landName($HlandTown, $landValue->[$bx][$by]);

		 # 그헥스를 괴수에
		 $land->[$bx][$by] = $HlandMonster;
		 $landValue->[$bx][$by] = $lv;

		 # 괴수 정보
		 my($mKind, $mName, $mHp) = monsterSpec($lv);

		 # 메시지
		 logMonsCome($id, $name, $mName, "($bx, $by)", $lName);
		 last;
		}
	 }
	}
 } while($island->{'monstersend'}> 0);

 # 지반 침하판정
 if(($island->{'area'}> $HdisFallBorder) &&
 (random(1000) < $HdisFalldown)) {
	# 지반 침하발생
	logFalldown($id, $name);

	my($x, $y, $landKind, $lv, $i);
	for($i = 0; $i < $HpointNumber; $i++) {
	 $x = $Hrpx[$i];
	 $y = $Hrpy[$i];
	 $landKind = $land->[$x][$y];
	 $lv = $landValue->[$x][$y];

	 if(($landKind != $HlandSea) &&
	 ($landKind != $HlandIce) &&
	 ($landKind != $HlandSbase) &&
	 ($landKind != $HlandSeacity) &&
	 ($landKind != $HlandSeatown) &&
	 ($landKind != $HlandUmishuto) &&
	 ($landKind != $HlandFune) &&
	 ($landKind != $HlandUmiamu) &&
	 ($landKind != $HlandOil) &&
	 ($landKind != $HlandGold) &&
	 ($landKind != $HlandOnsen) &&
	 ($landKind != $HlandMountain)) {

		# 주변에 바다가 있다면, 값을-1에
		if(countAround($land, $x, $y, $HlandSea, 7) +
		 countAround($land, $x, $y, $HlandSeacity, 7) +
		 countAround($land, $x, $y, $HlandSeatown, 7) +
		 countAround($land, $x, $y, $HlandUmishuto, 7) +
		 countAround($land, $x, $y, $HlandFune, 7) +
		 countAround($land, $x, $y, $HlandUmiamu, 7) +
		 countAround($land, $x, $y, $HlandSbase, 7)) {
		 logFalldownLand($id, $name, landName($landKind, $lv),
				"($x, $y)");
		 $land->[$x][$y] = -1;
		 $landValue->[$x][$y] = 0;
		}
	 }
	}

	for($i = 0; $i < $HpointNumber; $i++) {
	 $x = $Hrpx[$i];
	 $y = $Hrpy[$i];
	 $landKind = $land->[$x][$y];

	 if($landKind == -1) {
		# -1에나하고 있는 장소를 얕은 바다에
		$land->[$x][$y] = $HlandSea;
		$landValue->[$x][$y] = 1;
	 } elsif ($landKind == $HlandSea) {
		# 얕은 바다는 바다에
		$landValue->[$x][$y] = 0;
	 }

	}
 }

 # 태풍판정
 if(random(1000) < $HdisTyphoon-int($island->{'eis1'}/10)) {
	# 태풍발생
	logTyphoon($id, $name);
	$island->{'Typhoonflag'} = 1;

 if($toto2> 0) {
	$toto2--;
	$island->{'etc8'} = "$toto1,$toto2,$toto3,$toto4,$toto5,$toto6,$toto7";
	logOmamori($id, $name);
 } else {

	my($x, $y, $landKind, $lv, $i);
	for($i = 0; $i < $HpointNumber; $i++) {
	 $x = $Hrpx[$i];
	 $y = $Hrpy[$i];
	 $landKind = $land->[$x][$y];
	 $lv = $landValue->[$x][$y];

	 if(($landKind == $HlandFarm) ||
	 ($landKind == $HlandEneWd) ||
	 ($landKind == $HlandHaribote)) {

		# 1d12 <= (6 - 주변의 숲) 데붕괴
		if(random(12+$island->{'co5'}*5) <
		 (6
		 - countAround($land, $x, $y, $HlandForest, 7)
		 - countAround($land, $x, $y, $HlandMonument, 7))) {
		 logTyphoonDamage($id, $name, landName($landKind, $lv),
				 "($x, $y)");
		 $land->[$x][$y] = $HlandPlains;
		 $landValue->[$x][$y] = 0;
		}
	 }

	 if(($landKind == $HlandFune) ||
	 ($landKind == $HlandNursery)) {

		if(random(100+$island->{'co5'}*50) < 10) {
		 logTyphoonHason($id, $name, landName($landKind, $lv),
				 "($x, $y)");
 $land->[$x][$y] = $HlandSea;
 $landValue->[$x][$y] = 1;
		}
	 }

	}
 }
 }

 # 거대운석판정
 if(random(1000) < $HdisHugeMeteo-int($island->{'eis3'}/50)-int($s04/10)) {
	my($x, $y, $landKind, $lv, $point);

	# 낙하
	$x = random($HislandSize);
	$y = random($HislandSize);
	$landKind = $land->[$x][$y];
	$lv = $landValue->[$x][$y];
	$point = "($x, $y)";

	# 메시지
	logHugeMeteo($id, $name, $point);

 if($island->{'h10'}>= 1) {
	logOmamori2($id, $name);
	$land->[$x][$y] = $HlandSea;
	$landValue->[$x][$y] = 0;
 } elsif($toto2> 1) {
	$toto2--;
	$toto2--;
	$island->{'etc8'} = "$toto1,$toto2,$toto3,$toto4,$toto5,$toto6,$toto7";
	logOmamori($id, $name);
	$land->[$x][$y] = $HlandSea;
	$landValue->[$x][$y] = 0;
 } else {

	# 광역 피해 루틴
	wideDamage($id, $name, $land, $landValue, $x, $y);
		 if (rand(1000) < 100) {
		 $land->[$x][$y] = $HlandMonument;
		 $landValue->[$x][$y] = 79;
		 }
 }
 }

 # 거대 미사일판정
 while($island->{'bigmissile'}> 0) {
	$island->{'bigmissile'} --;

	my($x, $y, $landKind, $lv, $point);

	# 낙하
	$x = random($HislandSize);
	$y = random($HislandSize);
	$landKind = $land->[$x][$y];
	$lv = $landValue->[$x][$y];
	$point = "($x, $y)";

	# 메시지
	logMonDamage($id, $name, $point);

	# 광역 피해 루틴
	wideDamage($id, $name, $land, $landValue, $x, $y);
 }

 # 운석판정
 if(random(1000) < $HdisMeteo-int($island->{'eis3'}/40)-int($s04/10)) {

 if($island->{'h10'}>= 1) {
	# 낙하
	$x = random($HislandSize);
	$y = random($HislandSize);
	$landKind = $land->[$x][$y];
	$lv = $landValue->[$x][$y];
	$point = "($x, $y)";
	$land->[$x][$y] = $HlandSea;
	$landValue->[$x][$y] = 0;
	# 메시지
	logHugeMeteo4($id, $name, $point);
	logOmamori2($id, $name);
 } elsif($toto2> 0) {
	# 낙하
	$x = random($HislandSize);
	$y = random($HislandSize);
	$landKind = $land->[$x][$y];
	$lv = $landValue->[$x][$y];
	$point = "($x, $y)";
	$land->[$x][$y] = $HlandSea;
	$landValue->[$x][$y] = 0;
	# 메시지
	logHugeMeteo4($id, $name, $point);
	$toto2--;
	$island->{'etc8'} = "$toto1,$toto2,$toto3,$toto4,$toto5,$toto6,$toto7";
	logOmamori($id, $name);
 } else {

	my($x, $y, $landKind, $lv, $point, $first);
	$first = 1;
	while((random(2) == 0) || ($first == 1)) {
	 $first = 0;

	 # 낙하
	 $x = random($HislandSize);
	 $y = random($HislandSize);
	 $landKind = $land->[$x][$y];
	 $lv = $landValue->[$x][$y];
	 $point = "($x, $y)";



	 my($i, $count, $sx, $sy);
	 $count = 0;
	 for($i = 0; $i < 19; $i++) {
		 $sx = $x + $ax[$i];
		 $sy = $y + $ay[$i];

		 # 행 기준 위치 조정
		 if((($sy % 2) == 0) && (($y % 2) == 1)) {
		 $sx--;
		 }

		 if(($sx < 0) || ($sx>= $HislandSize) ||
		 ($sy < 0) || ($sy>= $HislandSize)) {
		 # 범위 밖의 경우
		 if($kind == $HlandSea) {
			 # 바다이면 가 산
			 $count++;
		 }
		 } else {
		 # 범위 안의 경우
		 if(($land->[$sx][$sy] == $HlandDefence) && ($landValue->[$sx][$sy] == 77)) {
		 if (rand(100) < 30) {
		 $land->[$sx][$sy] = $HlandWaste;
				$landValue->[$sx][$sy] = 0;
				logTrainEnd2($id, $name, "방위 시설·개정", "($sx, $sy)");
		 }
			 $count++;
		 }
		 }
	 }

	 if(($count> 0) && ($island->{'eis5'}>= 1)) {

		logMidMeteo3($id, $name, $point);
		$island->{'roudenflag'}++;
		$island->{'eis5'} -= random(50);
		 if($island->{'eis5'} < 1) {
		 $island->{'eis5'} = 0;
				logEiseiEnd($id, $name, "방위위성");
		 }

		} else {

		 if(($landKind == $HlandSea) && ($lv == 0)){
			# 바다포차
			logMeteoSea($id, $name, landName($landKind, $lv),
				 $point);
		 } elsif($landKind == $HlandMountain) {
			# 산파괴
			logMeteoMountain($id, $name, landName($landKind, $lv),
					 $point);
			$land->[$x][$y] = $HlandWaste;
			$landValue->[$x][$y] = 0;
			next;
		 } elsif($landKind == $HlandGold) {
			# 산파괴
			logMeteoMountain($id, $name, landName($landKind, $lv),
					 $point);
			$land->[$x][$y] = $HlandWaste;
			$landValue->[$x][$y] = 0;
			next;
		 } elsif($landKind == $HlandOnsen) {
			# 산파괴
			logMeteoMountain($id, $name, landName($landKind, $lv),
					 $point);
			$land->[$x][$y] = $HlandWaste;
			$landValue->[$x][$y] = 0;
			next;
		 } elsif($landKind == $HlandSbase) {
			logMeteoSbase($id, $name, landName($landKind, $lv),
				 $point);
		 } elsif($landKind == $HlandSeacity) {
			logMeteoSbase($id, $name, landName($landKind, $lv),
				 $point);
		 } elsif($landKind == $HlandUmishuto) {
			logMeteoSbase($id, $name, landName($landKind, $lv),
				 $point);
		 } elsif($landKind == $HlandSeatown) {
			logMeteoSbase($id, $name, landName($landKind, $lv),
				 $point);
		 } elsif($landKind == $HlandFune) {
			logMeteoSbase($id, $name, landName($landKind, $lv),
				 $point);
		 } elsif($landKind == $HlandFrocity) {
			logMeteoSbase($id, $name, landName($landKind, $lv),
				 $point);
		 } elsif($landKind == $HlandUmiamu) {
			logMeteoSbase($id, $name, landName($landKind, $lv),
				 $point);
		 } elsif($landKind == $HlandMonster) {
			logMeteoMonster($id, $name, landName($landKind, $lv),
					$point);
		 } elsif($landKind == $HlandSea) {
			# 얕은 바다
			logMeteoSea1($id, $name, landName($landKind, $lv),
				 $point);
		 } elsif($landKind == $HlandIce) {
			# 얕은 바다
			logMeteoSea1($id, $name, landName($landKind, $lv),
				 $point);
		 } else {
			logMeteoNormal($id, $name, landName($landKind, $lv),
				 $point);
		 }
		 $land->[$x][$y] = $HlandSea;
		 $landValue->[$x][$y] = 0;
		 if (rand(1000) < 50) {
		 $land->[$x][$y] = $HlandMonument;
		 $landValue->[$x][$y] = 79;
		 }
		 }
	 }
 }
 }

 # 분화 판정정
 if(random(1000) < $HdisEruption-int($island->{'eis2'}/40)-int($s04/10)) {
	my($x, $y, $sx, $sy, $i, $landKind, $lv, $point);
	$x = random($HislandSize);
	$y = random($HislandSize);
	$landKind = $land->[$x][$y];
	$lv = $landValue->[$x][$y];
	$point = "($x, $y)";
	logEruption($id, $name, landName($landKind, $lv),
		 $point);
	$land->[$x][$y] = $HlandMountain;
	$landValue->[$x][$y] = 0;

 if($toto2> 1) {
	$toto2--;
	$toto2--;
	$island->{'etc8'} = "$toto1,$toto2,$toto3,$toto4,$toto5,$toto6,$toto7";
	logOmamori($id, $name);
 } else {

		 if (rand(1000) < 50) {
		 $land->[$x][$y] = $HlandMonument;
		 $landValue->[$x][$y] = 78;
		 }
		 if (rand(1000) < 100) {
		 $land->[$x][$y] = $HlandMonument;
		 $landValue->[$x][$y] = 75;
		 }
	for($i = 1; $i < 7; $i++) {
	 $sx = $x + $ax[$i];
	 $sy = $y + $ay[$i];

	 # 행 기준 위치 조정
	 if((($sy % 2) == 0) && (($y % 2) == 1)) {
		$sx--;
	 }

	 $landKind = $land->[$sx][$sy];
	 $lv = $landValue->[$sx][$sy];
	 $point = "($sx, $sy)";

	 if(($sx < 0) || ($sx>= $HislandSize) ||
	 ($sy < 0) || ($sy>= $HislandSize)) {
	 } else {
		# 범위 안의 경우
		$landKind = $land->[$sx][$sy];
		$lv = $landValue->[$sx][$sy];
		$point = "($sx, $sy)";
		if(($landKind == $HlandSea) ||
		 ($landKind == $HlandIce) ||
		 ($landKind == $HlandOil) ||
		 ($landKind == $HlandFune) ||
		 ($landKind == $HlandFrocity) ||
		 ($landKind == $HlandUmiamu) ||
		 ($landKind == $HlandSeacity) ||
		 ($landKind == $HlandSeatown) ||
		 ($landKind == $HlandUmishuto) ||
		 ($landKind == $HlandSbase)) {
		 # 바다의 경우
		 if(($lv == 1) ||
		 ($landKind == $HlandIce)) {
			# 얕은 바다
			logEruptionSea1($id, $name, landName($landKind, $lv),
					$point);
		 } else {
			logEruptionSea($id, $name, landName($landKind, $lv),
				 $point);
			$land->[$sx][$sy] = $HlandSea;
			$landValue->[$sx][$sy] = 1;
			next;
		 }
		} elsif(($landKind == $HlandMountain) ||
			($landKind == $HlandMonster) ||
			($landKind == $HlandGold) ||
			($landKind == $HlandOnsen) ||
			($landKind == $HlandWaste)) {
		 next;
		} else {
		 # 그 외의 경우
		 logEruptionNormal($id, $name, landName($landKind, $lv),
				 $point);
		}
		$land->[$sx][$sy] = $HlandWaste;
		$landValue->[$sx][$sy] = 0;
		 if (rand(1000) < 50) {
		 $land->[$sx][$sy] = $HlandMonument;
		 $landValue->[$sx][$sy] = 75;
		 }
	 }
	}
 }
 }

 if($island->{'eis1'}>= 1) {
 $island->{'eis1'} -= random(2);
 if($island->{'eis1'} < 1) {
 $island->{'eis1'} = 0;
		logEiseiEnd($id, $name, "기상위성");
 }
 }
 if($island->{'eis2'}>= 1) {
 $island->{'eis2'} -= random(2);
 if($island->{'eis2'} < 1) {
 $island->{'eis2'} = 0;
		logEiseiEnd($id, $name, "관측위성");
 }
 }
 if($island->{'eis3'}>= 1) {
 $island->{'eis3'} -= random(2);
 if($island->{'eis3'} < 1) {
 $island->{'eis3'} = 0;
		logEiseiEnd($id, $name, "요격위성");
 }
 }
 if($island->{'eis4'}>= 1) {
 $island->{'eis4'} -= random(2);
 if($island->{'eis4'} < 1) {
 $island->{'eis4'} = 0;
		logEiseiEnd($id, $name, "군사위성");
 }
 }
 if($island->{'eis5'}>= 1) {
 $island->{'eis5'} -= random(2);
 if($island->{'eis5'} < 1) {
 $island->{'eis5'} = 0;
		logEiseiEnd($id, $name, "방위위성");
 }
 }
 if($island->{'eis6'}>= 1) {
	 my($i,$sx,$sy);
	 for($i = 0; $i < $HpointNumber; $i++){
		$sx = $Hrpx[$i];
		$sy = $Hrpy[$i];
	 if($land->[$sx][$sy] == $HlandMonster){
		my($tKind, $tName, $tHp) = monsterSpec($landValue->[$sx][$sy]);
		my($tlv) = $landValue->[$sx][$sy];
		my($tspecial) = $HmonsterSpecial[$tKind];
		$point = int($island->{'rena'}/1000);

	 logIreAttackt($id, $name, "비정상", $point, $tName, "($sx, $sy)");

	 $island->{'eis6'} -= 10;

	 $tHp -= int($island->{'rena'}/1000);
	 $tlv -= int($island->{'rena'}/1000);
		$landValue->[$sx][$sy] = $tlv;
	 if($tHp < 1){
	 # 대상의 괴수가 쓰러져 황무지가 됨
		$land->[$sx][$sy] = $HlandWaste;
		$landValue->[$sx][$sy] = 0;
	 # 포상금
		my($value) = $HmonsterValue[$tKind];
		 $island->{'money'} += $value;
		 logMsMonMoney($id, $tName, $value);
		}
	 next;
	 }
	}

 $island->{'eis6'} -= random(2);
 if($island->{'eis6'} < 1) {
 $island->{'eis6'} = 0;
		logEiseiEnd($id, $name, "비정상");
 }
 }

 if($island->{'eis7'}>= 1) {
	$eis7 = $island->{'eis7'};
	 $cstpop = int($eis7/100);
	 $csten = $eis7%100;

	 if($island->{'m17'} < int($cstpop/10000)+1) {
		logNoRokeCst($id, $name, $comName, $point);
		$cstpop -= 1000;
	 } else {
		$island->{'money'} -= $cstpop;
	 }

 $island->{'eis7'} = $cstpop*100+$csten;

 if($cstpop < 1) {
 $island->{'eis7'} = 0;
		logEiseiEndNopop($id, $name, "우주 정거장");
 }
 if($csten < 1) {
 $island->{'eis7'} = 0;
		logEiseiEnd($id, $name, "우주 정거장");
 }
 }

 if(($island->{'h11'}>= 1) && ($island->{'shouhi'} < $island->{'ene'})) {
	 my($i,$sx,$sy);
	 for($i = 0; $i < $HpointNumber; $i++){
		$sx = $Hrpx[$i];
		$sy = $Hrpy[$i];
	 if($land->[$sx][$sy] == $HlandMonster){
		my($tKind, $tName, $tHp) = monsterSpec($landValue->[$sx][$sy]);
		my($tlv) = $landValue->[$sx][$sy];
		my($tspecial) = $HmonsterSpecial[$tKind];
		$point = int($island->{'rena'}/1000);
		$island->{'shouhi'} += random(20000);
		logFuneAttackSSS3($id, $name, "천공성", $point, $tName, "($sx, $sy)");

	 # 대상의 괴수가 쓰러져 황무지가 됨
		$land->[$sx][$sy] = $HlandWaste;
		$landValue->[$sx][$sy] = 1;
 }
 }
 }


 $auc4 = $island->{'auc4'};
 $auc4 =~ /^([0-9]*),([0-9]*),([0-9]*)$/;
 ($auc4a, $auc4b, $auc4c) = ($1, $2, $3);

 if((($HislandTurn % $HturnPrizeUnit) == 0) || ($auc4b == $aucshouhin)) {

	$hcturn = int($HislandTurn/100)*100;

	$auc9 = $island->{'auc9'};
	$auc9 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	($auc9a, $auc9b, $auc9c, $auc9d, $auc9e) = ($1, $2, $3, $4, $5);
	$auc9c2 = int($auc9c/10000);
	$auc9c3 = int($auc9c/10000)*10000;

	$auction1 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	($shuppin1, $avalue1, $ajoutai1, $topvalue1, $topid1) = ($1, $2, $3, $4, $5);


	$auc6 = $island->{'auc6'};
	$auc6 =~ /^([0-9]*),([0-9]*),([0-9]*)$/;
	($auc6a, $auc6x, $auc6y) = ($1, $2, $3);
	 if($auc6a> 2) {
		$auc6a--;
		$island->{'auc6'} = "$auc6a,$auc6x,$auc6y";
	 }

	if(($island->{'auc1'} == $topvalue1) && ($topvalue1 != 0) && ($island->{'money'}+$auc9c3 < $topvalue1*10000) && ($auc4b != $aucshouhin)) {
	 $island->{'auc6'} = "7,0,0";
	}

	if(($island->{'auc1'} == $topvalue1) && ($topvalue1 != 0) && ($island->{'money'}+$auc9c3> $topvalue1*10000) && ($auc4b != $aucshouhin)) {

	 $shouhiauc9 = $auc9c2 - $topvalue1;

	 if($shouhiauc9 < 0) {
		$island->{'money'} -= ($topvalue1-$auc9c2)*10000;
		$auc9c2 = 0;
		$auc9c = $auc9c%10000;
		$auc9a = $auc9b + $auc9c2 + $auc9d + $auc9e;
		$island->{'auc9'} = "$auc9a,$auc9b,$auc9c,$auc9d,$auc9e";
	 } else {
		$auc9c -= $topvalue1*10000;
		$auc9c2 = int($auc9c/10000);
		$auc9a = $auc9b + $auc9c2 + $auc9d + $auc9e;
		$island->{'auc9'} = "$auc9a,$auc9b,$auc9c,$auc9d,$auc9e";
	 }

	 if($shuppin1 != 30) {
		$auc6 = $island->{'auc6'};
		$auc6 =~ /^([0-9]*),([0-9]*),([0-9]*)$/;
		($auc6a, $auc6x, $auc6y) = ($1, $2, $3);
		$auc6a = 1;
		$island->{'auc6'} = "$auc6a,$auc6x,$auc6y";
	 }


	 $aucflag1 += $topvalue1;

	 $auc0 = $island->{'auc0'};
	 $auc0 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	 ($auc0a, $auc0b, $auc0c, $auc0d, $auc0e) = ($1, $2, $3, $4, $5);
	 if($topvalue1> $auc0c) {
	 $island->{'auc0'} = "$shuppin1,$avalue1,$topvalue1,$hcturn,$auc0e";
	 }

	 if($shuppin1 == 0) {
		 $ac = '암석';
		} elsif($shuppin1 == 1) {
		 $ac = '지석';
		} elsif($shuppin1 == 2) {
		 $ac = '빙석';
		} elsif($shuppin1 == 3) {
		 $ac = '풍석';
		} elsif($shuppin1 == 4) {
		 $ac = '염석';
		} elsif($shuppin1 == 5) {
		 $ac = '광석';
		} elsif($shuppin1 == 6) {
		 $ac = '천사미카엘';
		} elsif($shuppin1 == 7) {
		 $ac = '아이스 스콜피온';
		} elsif($shuppin1 == 8) {
		 $ac = '슬라임 레전드';
		} elsif($shuppin1 == 9) {
		 $ac = "부적$avalue1개";
		} elsif($shuppin1 == 10) {
		 $avalue1s = $avalue1 * 1000;
		 $ac = "해상 시설$avalue1s 명 규모";
		} elsif($shuppin1 == 11) {
		 $avalue1s = $avalue1 * 1000;
		 $ac = "식품 연구$avalue1s 명 규모";
		} elsif($shuppin1 == 12) {
		 $ac = "코스모 발전소 $avalue1만 kW";
		} elsif($shuppin1 == 13) {
		 $ac = '암석';
		} elsif($shuppin1 == 14) {
		 $ac = '위성6종';
		} elsif($shuppin1 == 15) {
		 $ac = '우주 정거장';
		} elsif($shuppin1 == 16) {
		 $ac = '황금의 콘덴서';
		} elsif($shuppin1 == 17) {
		 $avalue1s = $avalue1 * 1000;
		 $ac = "금광산$avalue1s 명 규모";
		} elsif($shuppin1 == 18) {
		 $avalue1s = $avalue1 * 1000;
		 $ac = "양식장$avalue1s 명 규모";
		} elsif($shuppin1 == 19) {
		 $ac = '인공괴수f02';
		} elsif($shuppin1 == 20) {
		 $ac = '마왕 사탄';
		} elsif($shuppin1 == 21) {
		 $ac = 'unknown';
		} elsif($shuppin1 == 22) {
		 $ac = "축구팀 전력1.$avalue1배";
		} elsif($shuppin1 == 23) {
		 $ac = "생물 대학 능력1.$avalue1배";
		} elsif($shuppin1 == 24) {
		 $ac = "생물 대학 경험치$avalue1";
		} elsif($shuppin1 == 25) {
		 $ac = '알';
		} elsif($shuppin1 == 26) {
		 $ac = '생물 대학';
		} elsif($shuppin1 == 27) {
		 $ac = "풍력$avalue1만 kW";
		} elsif($shuppin1 == 28) {
		 $ac = "바이오매스$avalue1만 kW";
		} elsif($shuppin1 == 29) {
		 $ac = '이번은 휴식';
		} elsif($shuppin1 == 30) {
		 my($island, $j, $name, $id, $ii);
		 for($ii = 0; $ii < $HislandNumber; $ii++) {
			$j = $ii + 1;
			$island = $Hislands[$ii];
			$id = $island->{'id'};
				if($avalue1 == $island->{'id'}) {
				 $dashiname = $island->{'auc7'};
				}
			}
		 $ac = "$dashiname";
		} else {
		 $ac = '?';
		}

	 if(($shuppin1 == 6) || ($shuppin1 == 7) || ($shuppin1 == 8) || ($shuppin1 == 19) || ($shuppin1 == 20) || ($shuppin1 == 21)) {

		my($i,$sx,$sy);
		my($zlv) = (0);
		for($i = 0; $i < $HpointNumber; $i++){
		 $sx = $Hrpx[$i];
		 $sy = $Hrpy[$i];
			if($land->[$sx][$sy] == $HlandZoo){
			 $zlv += $landValue->[$sx][$sy];
			}
		}

		$etc6 = $island->{'etc6'};
		$etc6 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		($z0,$z1,$z2,$z3,$z4,$z5,$z6,$z7,$z8,$z9,$z10,$z11,$z12,$z13,$z14,$z15,$z16,$z17,$z18,$z19,$z20,$z21,$z22,$z23,$z24,$z25,$z26,$z27,$z28,$z29,$z30) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);
		($z->{'0'},$z->{'1'},$z->{'2'},$z->{'3'},$z->{'4'},$z->{'5'},$z->{'6'},$z->{'7'},$z->{'8'},$z->{'9'},$z->{'10'},$z->{'11'},$z->{'12'},$z->{'13'},$z->{'14'},$z->{'15'},$z->{'16'},$z->{'17'},$z->{'18'},$z->{'19'},$z->{'20'},$z->{'21'},$z->{'22'},$z->{'23'},$z->{'24'},$z->{'25'},$z->{'26'},$z->{'27'},$z->{'28'},$z->{'29'},$z->{'30'}) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);

		$zookazu = $z0+$z1+$z2+$z3+$z4+$z5+$z6+$z7+$z8+$z9+$z10+$z11+$z12+$z13+$z14+$z15+$z16+$z17+$z18+$z19+$z20+$z21+$z22+$z23+$z24+$z25+$z26+$z27+$z28+$z29+$z30;

			if(($zlv> $zookazu) && ($island->{'zoo'}> 0)) {

				if($shuppin1 == 6) {
				 $ack = 13;
				} elsif($shuppin1 == 7) {
				 $ack = 22;
				} elsif($shuppin1 == 8) {
				 $ack = 14;
				} elsif($shuppin1 == 19) {
				 $ack = 17;
				} elsif($shuppin1 == 20) {
				 $ack = 21;
				} elsif($shuppin1 == 21) {
				 $ack = 23;
				}

				logMonsCome2($id, $name, $ac, $topvalue1);
				$z->{"$ack"}++;
				$island->{'etc6'} = "$z->{'0'},$z->{'1'},$z->{'2'},$z->{'3'},$z->{'4'},$z->{'5'},$z->{'6'},$z->{'7'},$z->{'8'},$z->{'9'},$z->{'10'},$z->{'11'},$z->{'12'},$z->{'13'},$z->{'14'},$z->{'15'},$z->{'16'},$z->{'17'},$z->{'18'},$z->{'19'},$z->{'20'},$z->{'21'},$z->{'22'},$z->{'23'},$z->{'24'},$z->{'25'},$z->{'26'},$z->{'27'},$z->{'28'},$z->{'29'},$z->{'30'}";

			}

		} elsif($shuppin1 == 9) {

		 $etc8 = $island->{'etc8'};
		 $etc8 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		 ($toto1, $toto2, $toto3, $toto4, $toto5, $toto6, $toto7) = ($1, $2, $3, $4, $5, $6, $7);
		 $toto2 += $avalue1;
		 $island->{'etc8'} = "$toto1,$toto2,$toto3,$toto4,$toto5,$toto6,$toto7";

		 logMonsCome2($id, $name, $ac, $topvalue1);

		} elsif($shuppin1 == 14) {

		 $island->{'eis1'} = 200;
		 $island->{'eis2'} = 200;
		 $island->{'eis3'} = 200;
		 $island->{'eis4'} = 200;
		 $island->{'eis5'} = 200;
		 $island->{'eis6'} = 200;

		 logMonsCome2($id, $name, $ac, $topvalue1);

		} elsif($shuppin1 == 15) {

		 $island->{'eis7'} = 100099;

		 logMonsCome2($id, $name, $ac, $topvalue1);

		} elsif($shuppin1 == 22) {

		 $eisei4 = $island->{'eisei4'};
		 $eisei4 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		 ($sto, $std, $stk, $stwin, $stdrow, $stlose, $stwint, $stdrowt, $stloset, $styusho, $stshoka) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11);
		 $sto += int($sto * $avalue1 / 10);
		 $std += int($std * $avalue1 / 10);
		 $stk += int($stk * $avalue1 / 10);
		 $island->{'eisei4'} = "$sto,$std,$stk,$stwin,$stdrow,$stlose,$stwint,$stdrowt,$stloset,$styusho,$stshoka";

		 logMonsCome2($id, $name, $ac, $topvalue1);

		} elsif($shuppin1 == 23) {

		 $eisei5 = $island->{'eisei5'};
		 $eisei5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		 ($mshp, $msap, $msdp, $mssp, $mswin, $msexe, $tet) = ($1, $2, $3, $4, $5, $6, $7);
		 $msap += int($msap * $avalue1 / 10);
		 $msdp += int($msdp * $avalue1 / 10);
		 $mssp += int($mssp * $avalue1 / 10);
		 $island->{'eisei5'} = "$mshp,$msap,$msdp,$mssp,$mswin,$msexe,$tet";

		 logMonsCome2($id, $name, $ac, $topvalue1);

		} elsif($shuppin1 == 24) {

		 $eisei5 = $island->{'eisei5'};
		 $eisei5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		 ($mshp, $msap, $msdp, $mssp, $mswin, $msexe, $tet) = ($1, $2, $3, $4, $5, $6, $7);
		 $msexe += $avalue1;
		 $island->{'eisei5'} = "$mshp,$msap,$msdp,$mssp,$mswin,$msexe,$tet";

		 logMonsCome2($id, $name, $ac, $topvalue1);

		} else {

		 # 어디에 출현할지 결정
		 my($bx, $by, $i);
		 for($i = 0; $i < $HpointNumber; $i++) {
			$bx = $Hrpx[$i];
			$by = $Hrpy[$i];
			if(($land->[$bx][$by] == $HlandPlains) ||
			 ($land->[$bx][$by] == $HlandPlains2)) {

				if($shuppin1 == 0) {
				 $land->[$bx][$by] = $HlandMonument;
				 $landValue->[$bx][$by] = 74;
				} elsif($shuppin1 == 1) {
				 $land->[$bx][$by] = $HlandMonument;
				 $landValue->[$bx][$by] = 75;
				} elsif($shuppin1 == 2) {
				 $land->[$bx][$by] = $HlandMonument;
				 $landValue->[$bx][$by] = 76;
				} elsif($shuppin1 == 3) {
				 $land->[$bx][$by] = $HlandMonument;
				 $landValue->[$bx][$by] = 77;
				} elsif($shuppin1 == 4) {
				 $land->[$bx][$by] = $HlandMonument;
				 $landValue->[$bx][$by] = 78;
				} elsif($shuppin1 == 5) {
				 $land->[$bx][$by] = $HlandMonument;
				 $landValue->[$bx][$by] = 79;
				} elsif($shuppin1 == 10) {
				 $land->[$bx][$by] = $HlandUmiamu;
				 $landValue->[$bx][$by] = $avalue1;
				} elsif($shuppin1 == 11) {
				 $land->[$bx][$by] = $HlandFoodim;
				 $landValue->[$bx][$by] = $avalue1;
				} elsif($shuppin1 == 12) {
				 $land->[$bx][$by] = $HlandEneCs;
				 $landValue->[$bx][$by] = $avalue1;
				} elsif($shuppin1 == 13) {
				 $land->[$bx][$by] = $HlandMonument;
				 $landValue->[$bx][$by] = 74;
				} elsif($shuppin1 == 16) {
				 $land->[$bx][$by] = $HlandConden3;
				 $landValue->[$bx][$by] = 0;
				} elsif($shuppin1 == 17) {
				 $land->[$bx][$by] = $HlandGold;
				 $landValue->[$bx][$by] = $avalue1;
				} elsif($shuppin1 == 18) {
				 $land->[$bx][$by] = $HlandNursery;
				 $landValue->[$bx][$by] = $avalue1;
				} elsif($shuppin1 == 25) {
				 $land->[$bx][$by] = $HlandMonument;
				 $landValue->[$bx][$by] = $avalue1;
				} elsif($shuppin1 == 26) {
				 $land->[$bx][$by] = $HlandCollege;
				 $landValue->[$bx][$by] = 4;
				} elsif($shuppin1 == 27) {
				 $land->[$bx][$by] = $HlandEneWd;
				 $landValue->[$bx][$by] = $avalue1;
				} elsif($shuppin1 == 28) {
				 $land->[$bx][$by] = $HlandEneBo;
				 $landValue->[$bx][$by] = $avalue1;
				} elsif($shuppin1 == 30) {
				 my($tn) = $HidToNumber{$avalue1};
				 if($tn eq '') {

				 } else {
				 my($tIsland) = $Hislands[$tn];
				 my($tName) = $tIsland->{'name'};
				 my($tLand) = $tIsland->{'land'};
				 my($tLandValue) = $tIsland->{'landValue'};
					$tauc6 = $tIsland->{'auc6'};
					$tauc6 =~ /^([0-9]*),([0-9]*),([0-9]*)$/;
					($tauc6a, $tauc6x, $tauc6y) = ($1, $2, $3);
					$tIsland->{'auc6'} = "0,0,0";
				 my($tx, $ty);
					$tx = $tauc6x;
					$ty = $tauc6y;
				 my($tL) = $tLand->[$tx][$ty];
				 my($tLv) = $tLandValue->[$tx][$ty];
				 my($tLname) = landName($tL, $tLv);
					$island->{'stocklandkind'} = $tLand->[$tx][$ty];
					$island->{'stocklandvalue'} = $tLandValue->[$tx][$ty];
					$tLand->[$tx][$ty] = $HlandPlains;
					$tLandValue->[$tx][$ty] = 0;
					$land->[$bx][$by] = $island->{'stocklandkind'};
					$landValue->[$bx][$by] = $island->{'stocklandvalue'};

					$tauc9 = $tIsland->{'auc9'};
					$tauc9 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
					($tauc9a, $tauc9b, $tauc9c, $tauc9d, $tauc9e) = ($1, $2, $3, $4, $5);
					$tauc9c += $topvalue1*10000;
					$tauc9c2 = int($tauc9c/10000);
					$tauc9a = $tauc9b + $tauc9c2 + $tauc9d + $tauc9e;
					$tIsland->{'auc9'} = "$tauc9a,$tauc9b,$tauc9c,$tauc9d,$tauc9e";

					$island->{'auc8'} = "$tName 섬출품의$tLname";

					$aucland = $tL * $tLv;

						if($aucland != $topid1) {
							$tIsland->{'auc6'} = "77,0,0";
						}
				 }

				}

			 # 메시지
			 logMonsCome2($id, $name, $ac, $topvalue1);
			 last;
			}
		 }
		}
	 }


	$auction2 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	($shuppin2, $avalue2, $ajoutai2, $topvalue2, $topid2) = ($1, $2, $3, $4, $5);

	if(($island->{'auc2'} == $topvalue2) && ($topvalue2 != 0) && ($island->{'money'}+$auc9c3 < $topvalue2*10000) && ($auc4b != $aucshouhin)) {
	 $island->{'auc6'} = "7,0,0";
	}

	if(($island->{'auc2'} == $topvalue2) && ($topvalue2 != 0) && ($island->{'money'}+$auc9c3> $topvalue2*10000) && ($auc4b != $aucshouhin)) {

	 $shouhiauc9 = $auc9c2 - $topvalue2;

	 if($shouhiauc9 < 0) {
		$island->{'money'} -= ($topvalue2-$auc9c2)*10000;
		$auc9c2 = 0;
		$auc9c = $auc9c%10000;
		$auc9a = $auc9b + $auc9c2 + $auc9d + $auc9e;
		$island->{'auc9'} = "$auc9a,$auc9b,$auc9c,$auc9d,$auc9e";
	 } else {
		$auc9c -= $topvalue2*10000;
		$auc9c2 = int($auc9c/10000);
		$auc9a = $auc9b + $auc9c2 + $auc9d + $auc9e;
		$island->{'auc9'} = "$auc9a,$auc9b,$auc9c,$auc9d,$auc9e";
	 }

	 if($shuppin2 != 30) {
		$auc6 = $island->{'auc6'};
		$auc6 =~ /^([0-9]*),([0-9]*),([0-9]*)$/;
		($auc6a, $auc6x, $auc6y) = ($1, $2, $3);
		$auc6a = 1;
		$island->{'auc6'} = "$auc6a,$auc6x,$auc6y";
	 }

	 $aucflag2 += $topvalue2;

	 $auc0 = $island->{'auc0'};
	 $auc0 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	 ($auc0a, $auc0b, $auc0c, $auc0d, $auc0e) = ($1, $2, $3, $4, $5);
	 if($topvalue2> $auc0c) {
	 $island->{'auc0'} = "$shuppin2,$avalue2,$topvalue2,$hcturn,$auc0e";
	 }

	 if($shuppin2 == 0) {
		 $ac = '암석';
		} elsif($shuppin2 == 1) {
		 $ac = '지석';
		} elsif($shuppin2 == 2) {
		 $ac = '빙석';
		} elsif($shuppin2 == 3) {
		 $ac = '풍석';
		} elsif($shuppin2 == 4) {
		 $ac = '염석';
		} elsif($shuppin2 == 5) {
		 $ac = '광석';
		} elsif($shuppin2 == 6) {
		 $ac = '천사미카엘';
		} elsif($shuppin2 == 7) {
		 $ac = '아이스 스콜피온';
		} elsif($shuppin2 == 8) {
		 $ac = '슬라임 레전드';
		} elsif($shuppin2 == 9) {
		 $ac = "부적$avalue2개";
		} elsif($shuppin2 == 10) {
		 $avalue2s = $avalue2 * 1000;
		 $ac = "해상 시설$avalue2s 명 규모";
		} elsif($shuppin2 == 11) {
		 $avalue2s = $avalue2 * 1000;
		 $ac = "식품 연구$avalue2s 명 규모";
		} elsif($shuppin2 == 12) {
		 $ac = "코스모 발전소 $avalue2만 kW";
		} elsif($shuppin2 == 13) {
		 $ac = '암석';
		} elsif($shuppin2 == 14) {
		 $ac = '위성6종';
		} elsif($shuppin2 == 15) {
		 $ac = '우주 정거장';
		} elsif($shuppin2 == 16) {
		 $ac = '황금의 콘덴서';
		} elsif($shuppin2 == 17) {
		 $avalue2s = $avalue2 * 1000;
		 $ac = "금광산$avalue2s 명 규모";
		} elsif($shuppin2 == 18) {
		 $avalue2s = $avalue2 * 1000;
		 $ac = "양식장$avalue2s 명 규모";
		} elsif($shuppin2 == 19) {
		 $ac = '인공괴수f02';
		} elsif($shuppin2 == 20) {
		 $ac = '마왕 사탄';
		} elsif($shuppin2 == 21) {
		 $ac = 'unknown';
		} elsif($shuppin2 == 22) {
		 $ac = "축구팀 전력1.$avalue2배";
		} elsif($shuppin2 == 23) {
		 $ac = "생물 대학 능력1.$avalue2배";
		} elsif($shuppin2 == 24) {
		 $ac = "생물 대학 경험치$avalue2";
		} elsif($shuppin2 == 25) {
		 $ac = '알';
		} elsif($shuppin2 == 26) {
		 $ac = '생물 대학';
		} elsif($shuppin2 == 27) {
		 $ac = "풍력$avalue2만 kW";
		} elsif($shuppin2 == 28) {
		 $ac = "바이오매스$avalue2만 kW";
		} elsif($shuppin2 == 29) {
		 $ac = '이번은 휴식';
		} elsif($shuppin2 == 30) {
		 my($island, $j, $name, $id, $ii);
		 for($ii = 0; $ii < $HislandNumber; $ii++) {
			$j = $ii + 1;
			$island = $Hislands[$ii];
			$id = $island->{'id'};
				if($avalue2 == $island->{'id'}) {
				 $dashiname = $island->{'auc7'};
				}
			}
		 $ac = "$dashiname";
		} else {
		 $ac = '?';
		}

	 if(($shuppin2 == 6) || ($shuppin2 == 7) || ($shuppin2 == 8) || ($shuppin2 == 19) || ($shuppin2 == 20) || ($shuppin2 == 21)) {

		my($i,$sx,$sy);
		my($zlv) = (0);
		for($i = 0; $i < $HpointNumber; $i++){
		 $sx = $Hrpx[$i];
		 $sy = $Hrpy[$i];
			if($land->[$sx][$sy] == $HlandZoo){
			 $zlv += $landValue->[$sx][$sy];
			}
		}

		$etc6 = $island->{'etc6'};
		$etc6 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		($z0,$z1,$z2,$z3,$z4,$z5,$z6,$z7,$z8,$z9,$z10,$z11,$z12,$z13,$z14,$z15,$z16,$z17,$z18,$z19,$z20,$z21,$z22,$z23,$z24,$z25,$z26,$z27,$z28,$z29,$z30) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);
		($z->{'0'},$z->{'1'},$z->{'2'},$z->{'3'},$z->{'4'},$z->{'5'},$z->{'6'},$z->{'7'},$z->{'8'},$z->{'9'},$z->{'10'},$z->{'11'},$z->{'12'},$z->{'13'},$z->{'14'},$z->{'15'},$z->{'16'},$z->{'17'},$z->{'18'},$z->{'19'},$z->{'20'},$z->{'21'},$z->{'22'},$z->{'23'},$z->{'24'},$z->{'25'},$z->{'26'},$z->{'27'},$z->{'28'},$z->{'29'},$z->{'30'}) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);

		$zookazu = $z0+$z1+$z2+$z3+$z4+$z5+$z6+$z7+$z8+$z9+$z10+$z11+$z12+$z13+$z14+$z15+$z16+$z17+$z18+$z19+$z20+$z21+$z22+$z23+$z24+$z25+$z26+$z27+$z28+$z29+$z30;

			if(($zlv> $zookazu) && ($island->{'zoo'}> 0)) {

				if($shuppin2 == 6) {
				 $ack = 13;
				} elsif($shuppin2 == 7) {
				 $ack = 22;
				} elsif($shuppin2 == 8) {
				 $ack = 14;
				} elsif($shuppin2 == 19) {
				 $ack = 17;
				} elsif($shuppin2 == 20) {
				 $ack = 21;
				} elsif($shuppin2 == 21) {
				 $ack = 23;
				}

				logMonsCome2($id, $name, $ac, $topvalue2);
				$z->{"$ack"}++;
				$island->{'etc6'} = "$z->{'0'},$z->{'1'},$z->{'2'},$z->{'3'},$z->{'4'},$z->{'5'},$z->{'6'},$z->{'7'},$z->{'8'},$z->{'9'},$z->{'10'},$z->{'11'},$z->{'12'},$z->{'13'},$z->{'14'},$z->{'15'},$z->{'16'},$z->{'17'},$z->{'18'},$z->{'19'},$z->{'20'},$z->{'21'},$z->{'22'},$z->{'23'},$z->{'24'},$z->{'25'},$z->{'26'},$z->{'27'},$z->{'28'},$z->{'29'},$z->{'30'}";

			}

		} elsif($shuppin2 == 9) {

		 $etc8 = $island->{'etc8'};
		 $etc8 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		 ($toto1, $toto2, $toto3, $toto4, $toto5, $toto6, $toto7) = ($1, $2, $3, $4, $5, $6, $7);
		 $toto2 += $avalue2;
		 $island->{'etc8'} = "$toto1,$toto2,$toto3,$toto4,$toto5,$toto6,$toto7";

		 logMonsCome2($id, $name, $ac, $topvalue2);

		} elsif($shuppin2 == 14) {

		 $island->{'eis1'} = 200;
		 $island->{'eis2'} = 200;
		 $island->{'eis3'} = 200;
		 $island->{'eis4'} = 200;
		 $island->{'eis5'} = 200;
		 $island->{'eis6'} = 200;

		 logMonsCome2($id, $name, $ac, $topvalue2);

		} elsif($shuppin2 == 15) {

		 $island->{'eis7'} = 100099;

		 logMonsCome2($id, $name, $ac, $topvalue2);

		} elsif($shuppin2 == 22) {

		 $eisei4 = $island->{'eisei4'};
		 $eisei4 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		 ($sto, $std, $stk, $stwin, $stdrow, $stlose, $stwint, $stdrowt, $stloset, $styusho, $stshoka) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11);
		 $sto += int($sto * $avalue2 / 10);
		 $std += int($std * $avalue2 / 10);
		 $stk += int($stk * $avalue2 / 10);
		 $island->{'eisei4'} = "$sto,$std,$stk,$stwin,$stdrow,$stlose,$stwint,$stdrowt,$stloset,$styusho,$stshoka";

		 logMonsCome2($id, $name, $ac, $topvalue2);

		} elsif($shuppin2 == 23) {

		 $eisei5 = $island->{'eisei5'};
		 $eisei5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		 ($mshp, $msap, $msdp, $mssp, $mswin, $msexe, $tet) = ($1, $2, $3, $4, $5, $6, $7);
		 $msap += int($msap * $avalue2 / 10);
		 $msdp += int($msdp * $avalue2 / 10);
		 $mssp += int($mssp * $avalue2 / 10);
		 $island->{'eisei5'} = "$mshp,$msap,$msdp,$mssp,$mswin,$msexe,$tet";

		 logMonsCome2($id, $name, $ac, $topvalue2);

		} elsif($shuppin2 == 24) {

		 $eisei5 = $island->{'eisei5'};
		 $eisei5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		 ($mshp, $msap, $msdp, $mssp, $mswin, $msexe, $tet) = ($1, $2, $3, $4, $5, $6, $7);
		 $msexe += $avalue2;
		 $island->{'eisei5'} = "$mshp,$msap,$msdp,$mssp,$mswin,$msexe,$tet";

		 logMonsCome2($id, $name, $ac, $topvalue2);

		} else {

		 # 어디에 출현할지 결정
		 my($bx, $by, $i);
		 for($i = 0; $i < $HpointNumber; $i++) {
			$bx = $Hrpx[$i];
			$by = $Hrpy[$i];
			if(($land->[$bx][$by] == $HlandPlains) ||
			 ($land->[$bx][$by] == $HlandPlains2)) {

				if($shuppin2 == 0) {
				 $land->[$bx][$by] = $HlandMonument;
				 $landValue->[$bx][$by] = 74;
				} elsif($shuppin2 == 1) {
				 $land->[$bx][$by] = $HlandMonument;
				 $landValue->[$bx][$by] = 75;
				} elsif($shuppin2 == 2) {
				 $land->[$bx][$by] = $HlandMonument;
				 $landValue->[$bx][$by] = 76;
				} elsif($shuppin2 == 3) {
				 $land->[$bx][$by] = $HlandMonument;
				 $landValue->[$bx][$by] = 77;
				} elsif($shuppin2 == 4) {
				 $land->[$bx][$by] = $HlandMonument;
				 $landValue->[$bx][$by] = 78;
				} elsif($shuppin2 == 5) {
				 $land->[$bx][$by] = $HlandMonument;
				 $landValue->[$bx][$by] = 79;
				} elsif($shuppin2 == 10) {
				 $land->[$bx][$by] = $HlandUmiamu;
				 $landValue->[$bx][$by] = $avalue2;
				} elsif($shuppin2 == 11) {
				 $land->[$bx][$by] = $HlandFoodim;
				 $landValue->[$bx][$by] = $avalue2;
				} elsif($shuppin2 == 12) {
				 $land->[$bx][$by] = $HlandEneCs;
				 $landValue->[$bx][$by] = $avalue2;
				} elsif($shuppin2 == 13) {
				 $land->[$bx][$by] = $HlandMonument;
				 $landValue->[$bx][$by] = 74;
				} elsif($shuppin2 == 16) {
				 $land->[$bx][$by] = $HlandConden3;
				 $landValue->[$bx][$by] = 0;
				} elsif($shuppin2 == 17) {
				 $land->[$bx][$by] = $HlandGold;
				 $landValue->[$bx][$by] = $avalue2;
				} elsif($shuppin2 == 18) {
				 $land->[$bx][$by] = $HlandNursery;
				 $landValue->[$bx][$by] = $avalue2;
				} elsif($shuppin2 == 25) {
				 $land->[$bx][$by] = $HlandMonument;
				 $landValue->[$bx][$by] = $avalue2;
				} elsif($shuppin2 == 26) {
				 $land->[$bx][$by] = $HlandCollege;
				 $landValue->[$bx][$by] = 4;
				} elsif($shuppin2 == 27) {
				 $land->[$bx][$by] = $HlandEneWd;
				 $landValue->[$bx][$by] = $avalue2;
				} elsif($shuppin2 == 28) {
				 $land->[$bx][$by] = $HlandEneBo;
				 $landValue->[$bx][$by] = $avalue2;
				} elsif($shuppin2 == 30) {
				 my($tn) = $HidToNumber{$avalue2};
				 if($tn eq '') {

				 } else {
				 my($tIsland) = $Hislands[$tn];
				 my($tName) = $tIsland->{'name'};
				 my($tLand) = $tIsland->{'land'};
				 my($tLandValue) = $tIsland->{'landValue'};
					$tauc6 = $tIsland->{'auc6'};
					$tauc6 =~ /^([0-9]*),([0-9]*),([0-9]*)$/;
					($tauc6a, $tauc6x, $tauc6y) = ($1, $2, $3);
					$tIsland->{'auc6'} = "0,0,0";
				 my($tx, $ty);
					$tx = $tauc6x;
					$ty = $tauc6y;
				 my($tL) = $tLand->[$tx][$ty];
				 my($tLv) = $tLandValue->[$tx][$ty];
				 my($tLname) = landName($tL, $tLv);
					$island->{'stocklandkind'} = $tLand->[$tx][$ty];
					$island->{'stocklandvalue'} = $tLandValue->[$tx][$ty];
					$tLand->[$tx][$ty] = $HlandPlains;
					$tLandValue->[$tx][$ty] = 0;
					$land->[$bx][$by] = $island->{'stocklandkind'};
					$landValue->[$bx][$by] = $island->{'stocklandvalue'};

					$tauc9 = $tIsland->{'auc9'};
					$tauc9 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
					($tauc9a, $tauc9b, $tauc9c, $tauc9d, $tauc9e) = ($1, $2, $3, $4, $5);
					$tauc9c += $topvalue2*10000;
					$tauc9c2 = int($tauc9c/10000);
					$tauc9a = $tauc9b + $tauc9c2 + $tauc9d + $tauc9e;
					$tIsland->{'auc9'} = "$tauc9a,$tauc9b,$tauc9c,$tauc9d,$tauc9e";

					$island->{'auc8'} = "$tName 섬출품의$tLname";

					$aucland = $tL * $tLv;

						if($aucland != $topid2) {
							$tIsland->{'auc6'} = "77,0,0";
						}
				 }

				}

			 # 메시지
			 logMonsCome2($id, $name, $ac, $topvalue2);
			 last;
			}
		 }
		}
	 }


	$auction3 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	($shuppin3, $avalue3, $ajoutai3, $topvalue3, $topid3) = ($1, $2, $3, $4, $5);

	if(($island->{'auc3'} == $topvalue3) && ($topvalue3 != 0) && ($island->{'money'}+$auc9c3 < $topvalue3*10000) && ($auc4b != $aucshouhin)) {
	 $island->{'auc6'} = "7,0,0";
	}

	if((($island->{'auc3'} == $topvalue3) && ($topvalue3 != 0) && ($island->{'money'}+$auc9c3> $topvalue3*10000)) || ($auc4b == $aucshouhin)) {

	 if($auc4b == $aucshouhin) {

		 $auc0 = $island->{'auc0'};
		 $auc0 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		 ($auc0a, $auc0b, $auc0c, $auc0d, $auc0e) = ($1, $2, $3, $4, $5);
		 $shuppin3 = $auc0a;
		 $avalue3 = $auc0b;
		 $auc4c++;

		 $auc5 = $island->{'auc5'};
		 $auc5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		 ($auc5a, $auc5b, $auc5c, $auc5d, $auc5e) = ($1, $2, $3, $4, $5);

	 } else {

		 $shouhiauc9 = $auc9c2 - $topvalue3;

		 if($shouhiauc9 < 0) {
			$island->{'money'} -= ($topvalue3-$auc9c2)*10000;
			$auc9c2 = 0;
			$auc9c = $auc9c%10000;
			$auc9a = $auc9b + $auc9c2 + $auc9d + $auc9e;
			$island->{'auc9'} = "$auc9a,$auc9b,$auc9c,$auc9d,$auc9e";
		 } else {
			$auc9c -= $topvalue3*10000;
			$auc9c2 = int($auc9c/10000);
			$auc9a = $auc9b + $auc9c2 + $auc9d + $auc9e;
			$island->{'auc9'} = "$auc9a,$auc9b,$auc9c,$auc9d,$auc9e";
		 }

		 if($shuppin3 != 30) {
			$auc6 = $island->{'auc6'};
			$auc6 =~ /^([0-9]*),([0-9]*),([0-9]*)$/;
			($auc6a, $auc6x, $auc6y) = ($1, $2, $3);
			$auc6a = 1;
			$island->{'auc6'} = "$auc6a,$auc6x,$auc6y";
		 }

		 $aucflag3 += $topvalue3;

		 $auc0 = $island->{'auc0'};
		 $auc0 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		 ($auc0a, $auc0b, $auc0c, $auc0d, $auc0e) = ($1, $2, $3, $4, $5);
		 if($topvalue3> $auc0c) {
		 $island->{'auc0'} = "$shuppin3,$avalue3,$topvalue3,$hcturn,$auc0e";
		 }

	 }

	 if($shuppin3 == 0) {
		 $ac = '암석';
		} elsif($shuppin3 == 1) {
		 $ac = '지석';
		} elsif($shuppin3 == 2) {
		 $ac = '빙석';
		} elsif($shuppin3 == 3) {
		 $ac = '풍석';
		} elsif($shuppin3 == 4) {
		 $ac = '염석';
		} elsif($shuppin3 == 5) {
		 $ac = '광석';
		} elsif($shuppin3 == 6) {
		 $ac = '천사미카엘';
		} elsif($shuppin3 == 7) {
		 $ac = '아이스 스콜피온';
		} elsif($shuppin3 == 8) {
		 $ac = '슬라임 레전드';
		} elsif($shuppin3 == 9) {
		 $ac = "부적$avalue3개";
		} elsif($shuppin3 == 10) {
		 $avalue3s = $avalue3 * 1000;
		 $ac = "해상 시설$avalue3s 명 규모";
		} elsif($shuppin3 == 11) {
		 $avalue3s = $avalue3 * 1000;
		 $ac = "식품 연구$avalue3s 명 규모";
		} elsif($shuppin3 == 12) {
		 $ac = "코스모 발전소 $avalue3만 kW";
		} elsif($shuppin3 == 13) {
		 $ac = '암석';
		} elsif($shuppin3 == 14) {
		 $ac = '위성6종';
		} elsif($shuppin3 == 15) {
		 $ac = '우주 정거장';
		} elsif($shuppin3 == 16) {
		 $ac = '황금의 콘덴서';
		} elsif($shuppin3 == 17) {
		 $avalue3s = $avalue3 * 1000;
		 $ac = "금광산$avalue3s 명 규모";
		} elsif($shuppin3 == 18) {
		 $avalue3s = $avalue3 * 1000;
		 $ac = "양식장$avalue3s 명 규모";
		} elsif($shuppin3 == 19) {
		 $ac = '인공괴수f02';
		} elsif($shuppin3 == 20) {
		 $ac = '마왕 사탄';
		} elsif($shuppin3 == 21) {
		 $ac = 'unknown';
		} elsif($shuppin3 == 22) {
		 $ac = "축구팀 전력1.$avalue3배";
		} elsif($shuppin3 == 23) {
		 $ac = "생물 대학 능력1.$avalue3배";
		} elsif($shuppin3 == 24) {
		 $ac = "생물 대학 경험치$avalue3";
		} elsif($shuppin3 == 25) {
		 $ac = '알';
		} elsif($shuppin3 == 26) {
		 $ac = '생물 대학';
		} elsif($shuppin3 == 27) {
		 $ac = "풍력$avalue3만 kW";
		} elsif($shuppin3 == 28) {
		 $ac = "바이오매스$avalue3만 kW";
		} elsif($shuppin3 == 29) {
		 $ac = '이번은 휴식';
		} elsif($shuppin3 == 30) {
		 my($island, $j, $name, $id, $ii);
		 for($ii = 0; $ii < $HislandNumber; $ii++) {
			$j = $ii + 1;
			$island = $Hislands[$ii];
			$id = $island->{'id'};
				if($avalue3 == $island->{'id'}) {
				 $dashiname = $island->{'auc7'};
				}
			}
		 $ac = "$dashiname";
		} else {
		 $ac = '?';
		}

	 if(($shuppin3 == 6) || ($shuppin3 == 7) || ($shuppin3 == 8) || ($shuppin3 == 19) || ($shuppin3 == 20) || ($shuppin3 == 21)) {

		my($i,$sx,$sy);
		my($zlv) = (0);
		for($i = 0; $i < $HpointNumber; $i++){
		 $sx = $Hrpx[$i];
		 $sy = $Hrpy[$i];
			if($land->[$sx][$sy] == $HlandZoo){
			 $zlv += $landValue->[$sx][$sy];
			}
		}

		$etc6 = $island->{'etc6'};
		$etc6 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		($z0,$z1,$z2,$z3,$z4,$z5,$z6,$z7,$z8,$z9,$z10,$z11,$z12,$z13,$z14,$z15,$z16,$z17,$z18,$z19,$z20,$z21,$z22,$z23,$z24,$z25,$z26,$z27,$z28,$z29,$z30) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);
		($z->{'0'},$z->{'1'},$z->{'2'},$z->{'3'},$z->{'4'},$z->{'5'},$z->{'6'},$z->{'7'},$z->{'8'},$z->{'9'},$z->{'10'},$z->{'11'},$z->{'12'},$z->{'13'},$z->{'14'},$z->{'15'},$z->{'16'},$z->{'17'},$z->{'18'},$z->{'19'},$z->{'20'},$z->{'21'},$z->{'22'},$z->{'23'},$z->{'24'},$z->{'25'},$z->{'26'},$z->{'27'},$z->{'28'},$z->{'29'},$z->{'30'}) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);

		$zookazu = $z0+$z1+$z2+$z3+$z4+$z5+$z6+$z7+$z8+$z9+$z10+$z11+$z12+$z13+$z14+$z15+$z16+$z17+$z18+$z19+$z20+$z21+$z22+$z23+$z24+$z25+$z26+$z27+$z28+$z29+$z30;

			if(($zlv> $zookazu) && ($island->{'zoo'}> 0)) {

				if($shuppin3 == 6) {
				 $ack = 13;
				} elsif($shuppin3 == 7) {
				 $ack = 22;
				} elsif($shuppin3 == 8) {
				 $ack = 14;
				} elsif($shuppin3 == 19) {
				 $ack = 17;
				} elsif($shuppin3 == 20) {
				 $ack = 21;
				} elsif($shuppin3 == 21) {
				 $ack = 23;
				}

				if($auc4b == $aucshouhin) {
				 logPrizeAuc2($id, $name, $ac, $topvalue3);
				 $island->{'auc4'} = "$auc4a,0,$auc4c";
					 if($auc4c>= $aucdendou) {
						if($auc0c> $auc5c) {
						 $island->{'auc5'} = "$auc0a,$auc0b,$auc0c,$auc0d,$auc4a";
						} else {
						 $island->{'auc5'} = "$auc5a,$auc5b,$auc5c,$auc5d,$auc5e";
						}
						$island->{'auc0'} = "0,0,0,0,11";
						$island->{'auc4'} = "0,0,0";
					 }
				} else {
				 logMonsCome2($id, $name, $ac, $topvalue3);
				}

				$z->{"$ack"}++;
				$island->{'etc6'} = "$z->{'0'},$z->{'1'},$z->{'2'},$z->{'3'},$z->{'4'},$z->{'5'},$z->{'6'},$z->{'7'},$z->{'8'},$z->{'9'},$z->{'10'},$z->{'11'},$z->{'12'},$z->{'13'},$z->{'14'},$z->{'15'},$z->{'16'},$z->{'17'},$z->{'18'},$z->{'19'},$z->{'20'},$z->{'21'},$z->{'22'},$z->{'23'},$z->{'24'},$z->{'25'},$z->{'26'},$z->{'27'},$z->{'28'},$z->{'29'},$z->{'30'}";

			}

		} elsif($shuppin3 == 9) {

		 $etc8 = $island->{'etc8'};
		 $etc8 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		 ($toto1, $toto2, $toto3, $toto4, $toto5, $toto6, $toto7) = ($1, $2, $3, $4, $5, $6, $7);
		 $toto2 += $avalue3;
		 $island->{'etc8'} = "$toto1,$toto2,$toto3,$toto4,$toto5,$toto6,$toto7";

			if($auc4b == $aucshouhin) {
			 logPrizeAuc2($id, $name, $ac, $topvalue3);
			 $island->{'auc4'} = "$auc4a,0,$auc4c";
					 if($auc4c>= $aucdendou) {
						if($auc0c> $auc5c) {
						 $island->{'auc5'} = "$auc0a,$auc0b,$auc0c,$auc0d,$auc4a";
						} else {
						 $island->{'auc5'} = "$auc5a,$auc5b,$auc5c,$auc5d,$auc5e";
						}
						$island->{'auc0'} = "0,0,0,0,11";
						$island->{'auc4'} = "0,0,0";
					 }
			} else {
			 logMonsCome2($id, $name, $ac, $topvalue3);
			}

		} elsif($shuppin3 == 14) {

		 $island->{'eis1'} = 200;
		 $island->{'eis2'} = 200;
		 $island->{'eis3'} = 200;
		 $island->{'eis4'} = 200;
		 $island->{'eis5'} = 200;
		 $island->{'eis6'} = 200;

			if($auc4b == $aucshouhin) {
			 logPrizeAuc2($id, $name, $ac, $topvalue3);
			 $island->{'auc4'} = "$auc4a,0,$auc4c";
					 if($auc4c>= $aucdendou) {
						if($auc0c> $auc5c) {
						 $island->{'auc5'} = "$auc0a,$auc0b,$auc0c,$auc0d,$auc4a";
						} else {
						 $island->{'auc5'} = "$auc5a,$auc5b,$auc5c,$auc5d,$auc5e";
						}
						$island->{'auc0'} = "0,0,0,0,11";
						$island->{'auc4'} = "0,0,0";
					 }
			} else {
			 logMonsCome2($id, $name, $ac, $topvalue3);
			}

		} elsif($shuppin3 == 15) {

		 $island->{'eis7'} = 100099;

			if($auc4b == $aucshouhin) {
			 logPrizeAuc2($id, $name, $ac, $topvalue3);
			 $island->{'auc4'} = "$auc4a,0,$auc4c";
					 if($auc4c>= $aucdendou) {
						if($auc0c> $auc5c) {
						 $island->{'auc5'} = "$auc0a,$auc0b,$auc0c,$auc0d,$auc4a";
						} else {
						 $island->{'auc5'} = "$auc5a,$auc5b,$auc5c,$auc5d,$auc5e";
						}
						$island->{'auc0'} = "0,0,0,0,11";
						$island->{'auc4'} = "0,0,0";
					 }
			} else {
			 logMonsCome2($id, $name, $ac, $topvalue3);
			}

		} elsif($shuppin3 == 22) {

		 $eisei4 = $island->{'eisei4'};
		 $eisei4 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		 ($sto, $std, $stk, $stwin, $stdrow, $stlose, $stwint, $stdrowt, $stloset, $styusho, $stshoka) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11);
		 $sto += int($sto * $avalue3 / 10);
		 $std += int($std * $avalue3 / 10);
		 $stk += int($stk * $avalue3 / 10);
		 $island->{'eisei4'} = "$sto,$std,$stk,$stwin,$stdrow,$stlose,$stwint,$stdrowt,$stloset,$styusho,$stshoka";

			if($auc4b == $aucshouhin) {
			 logPrizeAuc2($id, $name, $ac, $topvalue3);
			 $island->{'auc4'} = "$auc4a,0,$auc4c";
					 if($auc4c>= $aucdendou) {
						if($auc0c> $auc5c) {
						 $island->{'auc5'} = "$auc0a,$auc0b,$auc0c,$auc0d,$auc4a";
						} else {
						 $island->{'auc5'} = "$auc5a,$auc5b,$auc5c,$auc5d,$auc5e";
						}
						$island->{'auc0'} = "0,0,0,0,11";
						$island->{'auc4'} = "0,0,0";
					 }
			} else {
			 logMonsCome2($id, $name, $ac, $topvalue3);
			}

		} elsif($shuppin3 == 23) {

		 $eisei5 = $island->{'eisei5'};
		 $eisei5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		 ($mshp, $msap, $msdp, $mssp, $mswin, $msexe, $tet) = ($1, $2, $3, $4, $5, $6, $7);
		 $msap += int($msap * $avalue3 / 10);
		 $msdp += int($msdp * $avalue3 / 10);
		 $mssp += int($mssp * $avalue3 / 10);
		 $island->{'eisei5'} = "$mshp,$msap,$msdp,$mssp,$mswin,$msexe,$tet";

			if($auc4b == $aucshouhin) {
			 logPrizeAuc2($id, $name, $ac, $topvalue3);
			 $island->{'auc4'} = "$auc4a,0,$auc4c";
					 if($auc4c>= $aucdendou) {
						if($auc0c> $auc5c) {
						 $island->{'auc5'} = "$auc0a,$auc0b,$auc0c,$auc0d,$auc4a";
						} else {
						 $island->{'auc5'} = "$auc5a,$auc5b,$auc5c,$auc5d,$auc5e";
						}
						$island->{'auc0'} = "0,0,0,0,11";
						$island->{'auc4'} = "0,0,0";
					 }
			} else {
			 logMonsCome2($id, $name, $ac, $topvalue3);
			}

		} elsif($shuppin3 == 24) {

		 $eisei5 = $island->{'eisei5'};
		 $eisei5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		 ($mshp, $msap, $msdp, $mssp, $mswin, $msexe, $tet) = ($1, $2, $3, $4, $5, $6, $7);
		 $msexe += $avalue3;
		 $island->{'eisei5'} = "$mshp,$msap,$msdp,$mssp,$mswin,$msexe,$tet";

			if($auc4b == $aucshouhin) {
			 logPrizeAuc2($id, $name, $ac, $topvalue3);
			 $island->{'auc4'} = "$auc4a,0,$auc4c";
					 if($auc4c>= $aucdendou) {
						if($auc0c> $auc5c) {
						 $island->{'auc5'} = "$auc0a,$auc0b,$auc0c,$auc0d,$auc4a";
						} else {
						 $island->{'auc5'} = "$auc5a,$auc5b,$auc5c,$auc5d,$auc5e";
						}
						$island->{'auc0'} = "0,0,0,0,11";
						$island->{'auc4'} = "0,0,0";
					 }
			} else {
			 logMonsCome2($id, $name, $ac, $topvalue3);
			}

		} else {

		 # 어디에 출현할지 결정
		 my($bx, $by, $i);
		 for($i = 0; $i < $HpointNumber; $i++) {
			$bx = $Hrpx[$i];
			$by = $Hrpy[$i];
			if(($land->[$bx][$by] == $HlandPlains) ||
			 ($land->[$bx][$by] == $HlandPlains2)) {

				if($shuppin3 == 0) {
				 $land->[$bx][$by] = $HlandMonument;
				 $landValue->[$bx][$by] = 74;
				} elsif($shuppin3 == 1) {
				 $land->[$bx][$by] = $HlandMonument;
				 $landValue->[$bx][$by] = 75;
				} elsif($shuppin3 == 2) {
				 $land->[$bx][$by] = $HlandMonument;
				 $landValue->[$bx][$by] = 76;
				} elsif($shuppin3 == 3) {
				 $land->[$bx][$by] = $HlandMonument;
				 $landValue->[$bx][$by] = 77;
				} elsif($shuppin3 == 4) {
				 $land->[$bx][$by] = $HlandMonument;
				 $landValue->[$bx][$by] = 78;
				} elsif($shuppin3 == 5) {
				 $land->[$bx][$by] = $HlandMonument;
				 $landValue->[$bx][$by] = 79;
				} elsif($shuppin3 == 10) {
				 $land->[$bx][$by] = $HlandUmiamu;
				 $landValue->[$bx][$by] = $avalue3;
				} elsif($shuppin3 == 11) {
				 $land->[$bx][$by] = $HlandFoodim;
				 $landValue->[$bx][$by] = $avalue3;
				} elsif($shuppin3 == 12) {
				 $land->[$bx][$by] = $HlandEneCs;
				 $landValue->[$bx][$by] = $avalue3;
				} elsif($shuppin3 == 13) {
				 $land->[$bx][$by] = $HlandMonument;
				 $landValue->[$bx][$by] = 74;
				} elsif($shuppin3 == 16) {
				 $land->[$bx][$by] = $HlandConden3;
				 $landValue->[$bx][$by] = 0;
				} elsif($shuppin3 == 17) {
				 $land->[$bx][$by] = $HlandGold;
				 $landValue->[$bx][$by] = $avalue3;
				} elsif($shuppin3 == 18) {
				 $land->[$bx][$by] = $HlandNursery;
				 $landValue->[$bx][$by] = $avalue3;
				} elsif($shuppin3 == 25) {
				 $land->[$bx][$by] = $HlandMonument;
				 $landValue->[$bx][$by] = $avalue3;
				} elsif($shuppin3 == 26) {
				 $land->[$bx][$by] = $HlandCollege;
				 $landValue->[$bx][$by] = 4;
				} elsif($shuppin3 == 27) {
				 $land->[$bx][$by] = $HlandEneWd;
				 $landValue->[$bx][$by] = $avalue3;
				} elsif($shuppin3 == 28) {
				 $land->[$bx][$by] = $HlandEneBo;
				 $landValue->[$bx][$by] = $avalue3;
				} elsif(($shuppin3 == 30) && ($auc4b != $aucshouhin)) {
				 my($tn) = $HidToNumber{$avalue3};
				 if($tn eq '') {

				 } else {
				 my($tIsland) = $Hislands[$tn];
				 my($tName) = $tIsland->{'name'};
				 my($tLand) = $tIsland->{'land'};
				 my($tLandValue) = $tIsland->{'landValue'};
					$tauc6 = $tIsland->{'auc6'};
					$tauc6 =~ /^([0-9]*),([0-9]*),([0-9]*)$/;
					($tauc6a, $tauc6x, $tauc6y) = ($1, $2, $3);
					$tIsland->{'auc6'} = "0,0,0";
				 my($tx, $ty);
					$tx = $tauc6x;
					$ty = $tauc6y;
				 my($tL) = $tLand->[$tx][$ty];
				 my($tLv) = $tLandValue->[$tx][$ty];
				 my($tLname) = landName($tL, $tLv);
					$island->{'stocklandkind'} = $tLand->[$tx][$ty];
					$island->{'stocklandvalue'} = $tLandValue->[$tx][$ty];
					$tLand->[$tx][$ty] = $HlandPlains;
					$tLandValue->[$tx][$ty] = 0;
					$land->[$bx][$by] = $island->{'stocklandkind'};
					$landValue->[$bx][$by] = $island->{'stocklandvalue'};

					$tauc9 = $tIsland->{'auc9'};
					$tauc9 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
					($tauc9a, $tauc9b, $tauc9c, $tauc9d, $tauc9e) = ($1, $2, $3, $4, $5);
					$tauc9c += $topvalue3*10000;
					$tauc9c2 = int($tauc9c/10000);
					$tauc9a = $tauc9b + $tauc9c2 + $tauc9d + $tauc9e;
					$tIsland->{'auc9'} = "$tauc9a,$tauc9b,$tauc9c,$tauc9d,$tauc9e";

					$island->{'auc8'} = "$tName 섬출품의$tLname";

					$aucland = $tL * $tLv;

						if($aucland != $topid3) {
							$tIsland->{'auc6'} = "77,0,0";
						}
				 }

				} elsif(($shuppin3 == 30) && ($auc4b == $aucshouhin)) {
					$ac="없음";
				}

			 # 메시지
				if($auc4b == $aucshouhin) {
				 logPrizeAuc2($id, $name, $ac, $topvalue3);
				 $island->{'auc4'} = "$auc4a,0,$auc4c";
					 if($auc4c>= $aucdendou) {
						if($auc0c> $auc5c) {
						 $island->{'auc5'} = "$auc0a,$auc0b,$auc0c,$auc0d,$auc4a";
						} else {
						 $island->{'auc5'} = "$auc5a,$auc5b,$auc5c,$auc5d,$auc5e";
						}
						$island->{'auc0'} = "0,0,0,0,11";
						$island->{'auc4'} = "0,0,0";
					 }
				} else {
				 logMonsCome2($id, $name, $ac, $topvalue3);
				}
			 last;
			}
		 }
		}
	 }

	$island->{'auc1'} = 0;
	$island->{'auc2'} = 0;
	$island->{'auc3'} = 0;

 }



 if($s01> $s02) {$s02 += 1;}
 if($s02> $s01+10) {$s02 -= 2;}
 if($s03> $s04) {$s04 += 1;}
 if($s04> $s03+5) {$s04 -= 3;}
 if($s05> $s06) {$s06 += 2;}
 if($s06> $s05+15) {$s06 -= 1;}
 if($s07> $s08) {$s08 += 2;}
 if($s08> $s07+20) {$s08 -= 1;}
 if($s09> $s10) {$s10 += 5;}
 if($s10> $s09+50) {$s10 -= 1;}
 if($s11> $s12) {$s12 += 5;}
 if($s12> $s11+1) {$s12 -= 5;}

 $island->{'money'} -= ($s01+$s03+$s05+$s07+$s09+$s11+$s13+$s15+$s17+$s19+$s21+$s23+$s25+$s27+$s29)*10000;

 $island->{'etc5'} = "$s00,$s01,$s02,$s03,$s04,$s05,$s06,$s07,$s08,$s09,$s10,$s11,$s12,$s13,$s14,$s15,$s16,$s17,$s18,$s19,$s20,$s21,$s22,$s23,$s24,$s25,$s26,$s27,$s28,$s29,$s30";


 $s12b = int($s12/5)+1;
 if($s12b> 10) {$s12b = 10;}

 # 식량이 넘치면 환전
 if($island->{'food'}> 99999*$s12b) {
	$island->{'money'} += int(($island->{'food'} - 99999*$s12b) / 10);
	$island->{'food'} = 99999*$s12b;
 }

 # 수입 확인
 $island->{'pika'} = $island->{'money'} - $island->{'oldMoney'};

 # 자금이 넘치면 잘라냄
 if(($island->{'money'}> 999999*$s12b) && ($anothermood != 1)) {

 if($island->{'tai'}> 0) {
	$kifu = "";
	$kifukin = int(($island->{'money'}-999999*$s12b)/$island->{'tai'});
	my($x, $y, $landKind, $lv, $i);
	for($i = 0; $i < $HpointNumber; $i++) {
	 $x = $Hrpx[$i];
	 $y = $Hrpy[$i];
	 $landKind = $land->[$x][$y];
	 if($landKind == $HlandTaishi) {
		$ttlv = $landValue->[$x][$y];
		my($tn) = $HidToNumber{$ttlv};
			if($tn eq '') {
			 # 대상이 이미 없음
			 $land->[$x][$y] = $HlandPlains;
			 $landValue->[$x][$y] = 0;
			}else{
			my($tIsland) = $Hislands[$tn];
			my($tName) = $tIsland->{'name'};
			my($tLand) = $tIsland->{'land'};
			$tIsland->{'money'} += $kifukin;
			$kifu.= "$tName 섬,";
 	}
 }
 }
	logKifu($id, $tId, $name, $tName, $kifu, "$kifukin 억 엔");
 }
	$island->{'money'} = 999999*$s12b;
 }


 $anotherkifu = 0;
 if(($anothermood == 1) && ($island->{'amarimoney'}> 0) && ($anotherkifu < 10)) {
 if($island->{'tai'}> 0) {
	$kifu = "";
	$kifukin = int($island->{'amarimoney'}/$island->{'tai'}/10);
	my($x, $y, $landKind, $lv, $i);
	for($i = 0; $i < $HpointNumber; $i++) {
	 $x = $Hrpx[$i];
	 $y = $Hrpy[$i];
	 $landKind = $land->[$x][$y];
	 if($landKind == $HlandTaishi) {
		$ttlv = $landValue->[$x][$y];
		my($tn) = $HidToNumber{$ttlv};
			if($tn eq '') {
			 # 대상이 이미 없음
			 $land->[$x][$y] = $HlandPlains;
			 $landValue->[$x][$y] = 0;
			}else{
			my($tIsland) = $Hislands[$tn];
			my($tName) = $tIsland->{'name'};
			my($tLand) = $tIsland->{'land'};
			$tIsland->{'money'} += $kifukin;
			$kifu.= "$tName 섬,";
 	}
 }
 }
	logKifu($id, $tId, $name, $tName, $kifu, "$kifukin 억 엔");
	$anotherkifu++;
 }
 }


 # 각종의 값을 계산
 estimate($number);

 # 번영, 재난상
 $pop = $island->{'pop'};
 my($damage) = $island->{'oldPop'} - $pop;
 my($prize) = $island->{'prize'};
 $prize =~ /([0-9]*),([0-9]*),(.*)/;
 my($flags) = $1;
 my($monsters) = $2;
 my($turns) = $3;

 $island->{'hamu'} = $island->{'pop'} - $island->{'oldPop'};
 $island->{'monta'} = $island->{'pts'} - $island->{'oldPts'};

 # 번영상
 if((!($flags & 1)) && $pop>= 3000){
	$flags |= 1;
	logPrize($id, $name, $Hprize[1]);
	 if($island->{'sin'}> 0) {
	 my($value, $str);
	 $value = random(3001);
	 $island->{'money'} += $value;
	 $str = "$value$HunitMoney";
	 # 수입 로그
	 logSinMoney($id, $name, $str);
	 }
	 if($island->{'jin'}> 0) {
	 my($value, $str);
	 $value = random(3001);
	 $island->{'money'} += $value;
	 $str = "$value$HunitMoney";
	 # 수입 로그
	 logJinMoney($id, $name, $str);
	 }
 } elsif((!($flags & 2)) && $pop>= 5000){
	$flags |= 2;
	logPrize($id, $name, $Hprize[2]);
	 if($island->{'sin'}> 0) {
	 my($value, $str);
	 $value = random(4001);
	 $island->{'money'} += $value;
	 $str = "$value$HunitMoney";
	 # 수입 로그
	 logSinMoney($id, $name, $str);
	 }
	 if($island->{'jin'}> 0) {
	 my($value, $str);
	 $value = random(4001);
	 $island->{'money'} += $value;
	 $str = "$value$HunitMoney";
	 # 수입 로그
	 logJinMoney($id, $name, $str);
	 }
 } elsif((!($flags & 4)) && $pop>= 10000){
	$flags |= 4;
	logPrize($id, $name, $Hprize[3]);
	 if($island->{'sin'}> 0) {
	 my($value, $str);
	 $value = random(5001);
	 $island->{'money'} += $value;
	 $str = "$value$HunitMoney";
	 # 수입 로그
	 logSinMoney($id, $name, $str);
	 }
	 if($island->{'jin'}> 0) {
	 my($value, $str);
	 $value = random(5001);
	 $island->{'money'} += $value;
	 $str = "$value$HunitMoney";
	 # 수입 로그
	 logJinMoney($id, $name, $str);
	 }
 }

 # 재난상
 if((!($flags & 64)) && $damage>= 500){
	$flags |= 64;
	logPrize($id, $name, $Hprize[7]);
 } elsif((!($flags & 128)) && $damage>= 1000){
	$flags |= 128;
	logPrize($id, $name, $Hprize[8]);
 } elsif((!($flags & 256)) && $damage>= 2000){
	$flags |= 256;
	logPrize($id, $name, $Hprize[9]);
 }

 $island->{'prize'} = "$flags,$monsters,$turns";
}


sub islandSortPop {
my($flag, $i, $tmp);

# 인구가 같으면 이전 턴의 순서를 유지
my @idx = (0..$#Hislands);
@idx = sort { $Hislands[$b]->{'pop'} <=> $Hislands[$a]->{'pop'} || $a <=> $b } @idx;
@Hislands = @Hislands[@idx];
}
sub islandSortFarm {
my($flag, $i, $tmp);

# 농업 규모가 같으면 이전 턴의 순서를 유지
my @idx = (0..$#Hislands);
@idx = sort { $Hislands[$b]->{'farm'} <=> $Hislands[$a]->{'farm'} || $a <=> $b } @idx;
@Hislands = @Hislands[@idx];
}
sub islandSortFactory {
my($flag, $i, $tmp);

my @idx = (0..$#Hislands);
@idx = sort { $Hislands[$b]->{'factoryt'} <=> $Hislands[$a]->{'factoryt'} || $a <=> $b } @idx;
@Hislands = @Hislands[@idx];
}
sub islandSortMountain {

my($flag, $i, $tmp);

my @idx = (0..$#Hislands);
@idx = sort { $Hislands[$b]->{'mountain'} <=> $Hislands[$a]->{'mountain'} || $a <=> $b } @idx;
@Hislands = @Hislands[@idx];
}

sub islandSortMonument {
my($flag, $i, $tmp);

my @idx = (0..$#Hislands);
@idx = sort { $Hislands[$b]->{'kei'} <=> $Hislands[$a]->{'kei'} || $a <=> $b } @idx;
@Hislands = @Hislands[@idx];
}
sub islandSortLive {
my($flag, $i, $tmp);

my @idx = (0..$#Hislands);
@idx = sort { $Hislands[$b]->{'monsterlive2'} <=> $Hislands[$a]->{'monsterlive2'} || $a <=> $b } @idx;
@Hislands = @Hislands[@idx];
}
sub islandSortRena {
my($flag, $i, $tmp);

my @idx = (0..$#Hislands);
@idx = sort { $Hislands[$b]->{'rena'} <=> $Hislands[$a]->{'rena'} || $a <=> $b } @idx;
@Hislands = @Hislands[@idx];
}
sub islandSortKill {
my($flag, $i, $tmp);

my @idx = (0..$#Hislands);
@idx = sort { $Hislands[$b]->{'taiji'} <=> $Hislands[$a]->{'taiji'} || $a <=> $b } @idx;
@Hislands = @Hislands[@idx];
}
sub islandSortFore {
my($flag, $i, $tmp);

my @idx = (0..$#Hislands);
@idx = sort { $Hislands[$b]->{'fore'} <=> $Hislands[$a]->{'fore'} || $a <=> $b } @idx;
@Hislands = @Hislands[@idx];
}

sub islandSortTare {
my($flag, $i, $tmp);

my @idx = (0..$#Hislands);
@idx = sort { $Hislands[$b]->{'tare'} <=> $Hislands[$a]->{'tare'} || $a <=> $b } @idx;
@Hislands = @Hislands[@idx];
}
sub islandSortZipro {
my($flag, $i, $tmp);

my @idx = (0..$#Hislands);
@idx = sort { $Hislands[$b]->{'zipro'} <=> $Hislands[$a]->{'zipro'} || $a <=> $b } @idx;
@Hislands = @Hislands[@idx];
}
sub islandSortLeje {
my($flag, $i, $tmp);

my @idx = (0..$#Hislands);
@idx = sort { $Hislands[$b]->{'leje'} <=> $Hislands[$a]->{'leje'} || $a <=> $b } @idx;
@Hislands = @Hislands[@idx];
}

sub islandSortForce {
my($flag, $i, $tmp);

my @idx = (0..$#Hislands);
@idx = sort { $Hislands[$b]->{'force'} <=> $Hislands[$a]->{'force'} || $a <=> $b } @idx;
@Hislands = @Hislands[@idx];
}

sub islandSortEisei2 {
my($flag, $i, $tmp);

my @idx = (0..$#Hislands);
@idx = sort { $Hislands[$b]->{'eisei2'} <=> $Hislands[$a]->{'eisei2'} || $a <=> $b } @idx;
@Hislands = @Hislands[@idx];
}

sub islandSortUni {
my($flag, $i, $tmp);

my @idx = (0..$#Hislands);
@idx = sort { $Hislands[$b]->{'uni'} <=> $Hislands[$a]->{'uni'} || $a <=> $b } @idx;
@Hislands = @Hislands[@idx];
}

sub islandSorthck {
my($flag, $i, $tmp);

my @idx = (0..$#Hislands);
@idx = sort { $Hislands[$b]->{'ene'} <=> $Hislands[$a]->{'ene'} || $a <=> $b } @idx;
@Hislands = @Hislands[@idx];
}

sub islandSorthckt {
my($flag, $i, $tmp);

my @idx = (0..$#Hislands);
@idx = sort { $Hislands[$b]->{'etc0'} <=> $Hislands[$a]->{'etc0'} || $a <=> $b } @idx;
@Hislands = @Hislands[@idx];
}

sub islandSorthcr {
my($flag, $i, $tmp);

my @idx = (0..$#Hislands);
@idx = sort { $Hislands[$b]->{'shoritu'} <=> $Hislands[$a]->{'shoritu'} || $a <=> $b } @idx;
@Hislands = @Hislands[@idx];
}

sub islandSorthcy {
my($flag, $i, $tmp);

my @idx = (0..$#Hislands);
@idx = sort { $Hislands[$b]->{'styusho'} <=> $Hislands[$a]->{'styusho'} || $a <=> $b } @idx;
@Hislands = @Hislands[@idx];
}

sub islandSorthct {
my($flag, $i, $tmp);

my @idx = (0..$#Hislands);
@idx = sort { $Hislands[$b]->{'teamforce'} <=> $Hislands[$a]->{'teamforce'} || $a <=> $b } @idx;
@Hislands = @Hislands[@idx];
}


sub islandSortHC {
my($flag, $i, $tmp);
my @idx = (0..$#Hislands);
@idx = sort { $Hislands[$b]->{'kachiten'} <=> $Hislands[$a]->{'kachiten'} || $a <=> $b } @idx;
@Hislands = @Hislands[@idx];
}

sub islandSortac4 {
my($flag, $i, $tmp);

my @idx = (0..$#Hislands);
@idx = sort { $Hislands[$b]->{'auc0c'} <=> $Hislands[$a]->{'auc0c'} || $a <=> $b } @idx;
@Hislands = @Hislands[@idx];
}

# Point 순에정렬
sub islandSort {
 my($flag, $i, $tmp);

 # 인구가 같으면 이전 턴의 순서를 유지
 my @idx = (0..$#Hislands);
 @idx = sort { $Hislands[$b]->{'pts'} <=> $Hislands[$a]->{'pts'} || $a <=> $b } @idx;
 @Hislands = @Hislands[@idx];
}

# 광역 피해 루틴
sub wideDamage {
 my($id, $name, $land, $landValue, $x, $y) = @_;
 my($sx, $sy, $i, $landKind, $landName, $lv, $point);

 for($i = 0; $i < 19; $i++) {
	$sx = $x + $ax[$i];
	$sy = $y + $ay[$i];

	# 행 기준 위치 조정
	if((($sy % 2) == 0) && (($y % 2) == 1)) {
	 $sx--;
	}

	$landKind = $land->[$sx][$sy];
	$lv = $landValue->[$sx][$sy];
	$landName = landName($landKind, $lv);
	$point = "($sx, $sy)";

	# 범위 밖 판정
	if(($sx < 0) || ($sx>= $HislandSize) ||
	 ($sy < 0) || ($sy>= $HislandSize)) {
	 next;
	}

	# 범위에 한분기
	if($i < 7) {
	 # 중심 및 1헥스
	 if($landKind == $HlandSea) {
		$landValue->[$sx][$sy] = 0;
		next;
	 } elsif(($landKind == $HlandSbase) ||
		 ($landKind == $HlandSeacity) ||
		 ($landKind == $HlandSeatown) ||
		 ($landKind == $HlandUmishuto) ||
		 ($landKind == $HlandFune) ||
		 ($landKind == $HlandIce) ||
		 ($landKind == $HlandFrocity) ||
		 ($landKind == $HlandUmiamu) ||
		 ($landKind == $HlandOil)) {
		logWideDamageSea2($id, $name, $landName, $point);
		$land->[$sx][$sy] = $HlandSea;
		$landValue->[$sx][$sy] = 0;
	 } else {
		if($landKind == $HlandMonster) {
	 my($mKind, $mName, $mHp) = monsterSpec($lv);
			if((($mKind == 20)&&($i == 0))||(($mKind == 21)&&($i == 0))){next;}
		 logWideDamageMonsterSea($id, $name, $landName, $point);
		} else {
		 logWideDamageSea($id, $name, $landName, $point);
		}
		$land->[$sx][$sy] = $HlandSea;
		if($i == 0) {
		 # 바다
		 $landValue->[$sx][$sy] = 0;
		} else {
		 # 얕은 바다
		 $landValue->[$sx][$sy] = 1;
		}
	 }
	} else {
	 # 2헥스
	 if(($landKind == $HlandSea) ||
	 ($landKind == $HlandIce) ||
	 ($landKind == $HlandOil) ||
	 ($landKind == $HlandWaste) ||
	 ($landKind == $HlandMountain) ||
	 ($landKind == $HlandGold) ||
	 ($landKind == $HlandOnsen) ||
	 ($landKind == $HlandSeacity) ||
	 ($landKind == $HlandUmishuto) ||
	 ($landKind == $HlandSeatown) ||
	 ($landKind == $HlandFune) ||
	 ($landKind == $HlandFrocity) ||
	 ($landKind == $HlandUmiamu) ||
	 ($landKind == $HlandSbase)) {
		next;
	 } elsif($landKind == $HlandMonster) {
		logWideDamageMonster($id, $name, $landName, $point);
		$land->[$sx][$sy] = $HlandWaste;
		$landValue->[$sx][$sy] = 0;
	 } else {
		logWideDamageWaste($id, $name, $landName, $point);
		$land->[$sx][$sy] = $HlandWaste;
		$landValue->[$sx][$sy] = 0;
	 }
	}
 }
}

# 광역 피해 루틴·미니
sub wideDamageli {
my($target, $tName, $tLand, $tLandValue, $tx, $ty) = @_;
my($sx, $sy, $i, $landKind, $landName, $lv, $point);

for($i = 0; $i < 19; $i++) {
$sx = $tx + $ax[$i];
$sy = $ty + $ay[$i];

# 행 기준 위치 조정
if((($sy % 2) == 0) && (($ty % 2) == 1)) {
$sx--;
}

$landKind = $tLand->[$sx][$sy];
$lv = $tLandValue->[$sx][$sy];
$landName = landName($landKind, $lv);
$point = "($sx, $sy)";

# 범위 밖 판정
if(($sx < 0) || ($sx>= $HislandSize) ||
($sy < 0) || ($sy>= $HislandSize)) {
next;
}
if(($landKind == $HlandSea) ||
($landKind == $HlandOil) ||
($landKind == $HlandWaste) ||
($landKind == $HlandIce) ||
($landKind == $HlandSeacity) ||
($landKind == $HlandSeatown) ||
($landKind == $HlandUmishuto) ||
($landKind == $HlandFune) ||
($landKind == $HlandFrocity) ||
($landKind == $HlandUmiamu) ||
($landKind == $HlandSbase)) {
next;
} elsif($landKind == $HlandMonster) {
logWideDamageMonster($target, $tName, $landName, $point);
$tLand->[$sx][$sy] = $HlandWaste;
$tLandValue->[$sx][$sy] = 0;
} elsif($landKind == $HlandTown) {
logWideDamageWaste($target, $tName, $landName, $point);
$tLand->[$sx][$sy] = $HlandWaste;
$tLandValue->[$sx][$sy] = 0;
} else {
logWideDamageWaste($target, $tName, $landName, $point);
$tLand->[$sx][$sy] = $HlandWaste;
$tLandValue->[$sx][$sy] = 0;
}
}
}


# 로그로 출력
# 제1인 수:메시지
# 제2인 수:당사자
# 제3인 수:상대
# 일반 로그
sub logOut {
 push(@HlogPool,"0,$HislandTurn,$_[1],$_[2],$_[0]");
}

# 지연 로그
sub logLate {
 push(@HlateLogPool,"0,$HislandTurn,$_[1],$_[2],$_[0]");
}

# 기밀 로그
sub logSecret {
 push(@HsecretLogPool,"1,$HislandTurn,$_[1],$_[2],$_[0]");
}

# 기록 로그
sub logHistory {
 open(HOUT, ">>${HdirName}/hakojima.his");
 print HOUT "$HislandTurn,$_[0]\n";
 close(HOUT);
}

# 기록 로그 조정
sub logHistoryTrim {
 open(HIN, "${HdirName}/hakojima.his");
 my(@line, $l, $count);
 $count = 0;
 while($l = <HIN>) {
	chomp($l);
	push(@line, $l);
	$count++;
 }
 close(HIN);

 if($count> $HhistoryMax) {
	open(HOUT, ">${HdirName}/hakojima.his");
	my($i);
	for($i = ($count - $HhistoryMax); $i < $count; $i++) {
	 print HOUT "$line[$i]\n";
	}
	close(HOUT);
 }
}

# Hakoniwa Cup 로그
sub logHcup {
 open(COUT, ">>${HdirName}/hakojima.lhc");
 print COUT "$HislandTurn,$_[0]\n";
 close(COUT);
}

# Hakoniwa Cup 로그 조정
sub logHcupTrim {
 open(CIN, "${HdirName}/hakojima.lhc");
 my(@line, $l, $count);
 $count = 0;
 while($l = <CIN>) {
	chomp($l);
	push(@line, $l);
	$count++;
 }
 close(CIN);

 if($count> $HhcMax) {
	open(COUT, ">${HdirName}/hakojima.lhc");
	my($i);
	for($i = ($count - $HhcMax); $i < $count; $i++) {
	 print COUT "$line[$i]\n";
	}
	close(COUT);
 }
}

# Hakoniwa Auction 로그
sub logAuc {
 open(AOUT, ">>${HdirName}/hakojima.auc");
 print AOUT "$HislandTurn,$_[0]\n";
 close(AOUT);
}

# Hakoniwa Auction 로그 조정
sub logAucTrim {
 open(AIN, "${HdirName}/hakojima.auc");
 my(@line, $l, $count);
 $count = 0;
 while($l = <AIN>) {
	chomp($l);
	push(@line, $l);
	$count++;
 }
 close(AIN);

 if($count> 10) {
	open(AOUT, ">${HdirName}/hakojima.auc");
	my($i);
	for($i = ($count - 10); $i < $count; $i++) {
	 print AOUT "$line[$i]\n";
	}
	close(AOUT);
 }
}

# 로그 쓰기
sub logFlush {
 open(LOUT, ">${HdirName}/hakojima.log0");

 # 전체를 역순으로출력
 my($i);
 for($i = $#HsecretLogPool; $i>= 0; $i--) {
	print LOUT $HsecretLogPool[$i];
	print LOUT "\n";
 }
 for($i = $#HlateLogPool; $i>= 0; $i--) {
	print LOUT $HlateLogPool[$i];
	print LOUT "\n";
 }
 for($i = $#HlogPool; $i>= 0; $i--) {
	print LOUT $HlogPool[$i];
	print LOUT "\n";
 }
 close(LOUT);
}

#----------------------------------------------------------------------
# 로그템플릿
#----------------------------------------------------------------------
# 자금 부족
sub logNoMoney {
 my($id, $name, $comName) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}에서 예정되어 있던${HtagComName_}$comName${H_tagComName}은, 자금이 부족해 중지되었습니다.",$id);
}

sub logNoMoney2 {
 my($id, $name, $comName) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}에서 예정되어 있던${HtagComName_}$comName${H_tagComName}은, 조건부족을 때문에 중지되었습니다.",$id);
}

# 식량 부족
sub logNoFood {
 my($id, $name, $comName) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}에서 예정되어 있던${HtagComName_}$comName${H_tagComName}은, 비축 식량 부족으로 중지되었습니다.",$id);
}

# 위성없음
sub logNoEisei {
 my($id, $name, $comName) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}에서 예정되어 있던${HtagComName_}$comName${H_tagComName}은, 지정한 인공위성이 없기 때문에 중지되었습니다.",$id);
}

# 위성없음개정
sub logNesEisei {
 my($id, $name, $comName) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}에서 예정되어 있던${HtagComName_}$comName${H_tagComName}은, 필요한 인공위성이 없기 때문에 중지되었습니다.",$id);
}

# 허가되지 않는
sub logForbidden {
 my($id, $name, $comName) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}에서 예정되어 있던${HtagComName_}$comName${H_tagComName}은, 실행이허가되지 않았습니다.",$id);
}

# 하코니와 연합군
sub logNiwaren {
 my($id, $name) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}은,<B>하코니와 연합군</B>에${HtagDisaster_}공격${H_tagDisaster}됨했습니다.",$id);
}

# 하코니와 연합군2
sub logNiwaren2 {
 my($id, $name, $comName) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}의${HtagComName_}$comName${H_tagComName}은,${HtagDisaster_}배상금${H_tagDisaster}을 지불해야 합니다.",$id);
}

# 하코니와 연합군3
sub logNiwaren3 {
 my($id, $name, $comName) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}에서 예정되어 있던${HtagComName_}$comName${H_tagComName}은,<B>지원 사격 허가가 취소됨</B> 때문에 중지되었습니다.",$id);
}

# 수도 가능
sub logShuto {
 my($id, $name, $lName, $sName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>은,<B>수도 <B>$sName</B>로서 섬의 중심 도시가 되었습니다.",$id);
 logHistory("${HtagName_}${name} 섬${H_tagName}에<B>수도$sName</B>이 생겼습니다.");
END
}

# 대상 지형 종류 때문에 실패
sub logLandFail {
 my($id, $name, $comName, $kind, $point) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}에서 예정되어 있던${HtagComName_}$comName${H_tagComName}은, 예개간 ${HtagName_}$point${H_tagName}이<B>$kind</B>였기 때문에 중지되었습니다.",$id);
END
}

# 대상 지형의 조건에 한실패
sub logJoFail {
 my($id, $name, $comName, $kind, $point) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}에서 예정되어 있던${HtagComName_}$comName${H_tagComName}은, 예개간 ${HtagName_}$point${H_tagName}이 조건에 맞지 않는 <B>$kind</B>였기 때문에 중지되었습니다.",$id);
END
}

# 대상 지형의 조건에 한실패2
sub logJo2Fail {
 my($id, $name, $comName, $kind, $point) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}에서 예정되어 있던${HtagComName_}$comName${H_tagComName}이지만, 먼저 치안을 충분히 유지하려면<B>군사력</B>을 확보하세요.",$id);
END
}

# 도시 종류에 한실패
sub logBokuFail {
 my($id, $name, $comName, $kind, $point) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}에서 예정되어 있던${HtagComName_}$comName${H_tagComName}은, 예개간 ${HtagName_}$point${H_tagName}이 조건을 충족한 도시가 아니었기 때문에 중지되었습니다.",$id);
END
}

# 괴수의 거부에 한실패
sub logBokuFail2 {
 my($id, $name, $comName, $kind, $point) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}에서 예정되어 있던${HtagComName_}$comName${H_tagComName}은, 예개간${HtagName_}$point${H_tagName}의<b>$kind</b>에 적합하지 않았기 때문에 중지되었습니다.",$id);
END
}

# 주변에 육지가 없으면 매립 실패
sub logNoLandAround {
 my($id, $name, $comName, $point) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}에서 예정되어 있던${HtagComName_}$comName${H_tagComName}은, 예개간 ${HtagName_}$point${H_tagName} 주변에 육지가 없었기 때문에 중지되었습니다.",$id);
END
}

# 주변에 항구가 없으면 선박 실패
sub logNoLandAroundm {
 my($id, $name, $comName, $point) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}에서 예정되어 있던${HtagComName_}$comName${H_tagComName}은, 예개간 ${HtagName_}$point${H_tagName} 주변에 항구 도시가 없었기 때문에 중지되었습니다.",$id);
END
}

# 주변에 항구가 없으면 선박 실패
sub logNoLandArounde {
 my($id, $name, $comName, $point, $lName) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}에서 예정되어 있던${HtagComName_}$comName${H_tagComName}은, 예개간 ${HtagName_}$point${H_tagName} 주변에<B>$lName</B>이 없었기 때문에 중지되었습니다.",$id);
END
}

# 주변에 도시가 없으면 매립 실패
sub logNoTownAround {
 my($id, $name, $comName, $point) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}에서 예정되어 있던${HtagComName_}$comName${H_tagComName}은, 예개간 ${HtagName_}$point${H_tagName} 주변에 인구가 없었기 때문에 중지되었습니다.",$id);
END
}

# 개간 계열 성공
sub logLandSuc {
 my($id, $name, $comName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}에서${HtagComName_}${comName}${H_tagComName}이 실행되었습니다.",$id);
END
}

# 개간 계열 성공개정
sub logLandSucmini {
 my($id, $name, $comName, $point) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}에서${HtagComName_}${comName}${H_tagComName}이 실행되었습니다.",$id);
END
}

# 위성실패
sub logNoRoke {
 my($id, $name, $comName, $point) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}에서 예정되어 있던${HtagComName_}${comName}${H_tagComName}은 로켓이 부족해 때문에 중지되었습니다.",$id);
END
}

# 스테이션식량부족
sub logNoRokeCst {
 my($id, $name, $comName, $point) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}은${HtagDisaster_}로켓 부족${H_tagDisaster}로<B>우주 정거장</B>에식량이운영베않습니다!!",$id);
END
}

# 위성실패개정
sub logNoTech {
 my($id, $name, $comName, $point) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}에서 예정되어 있던${HtagComName_}${comName}${H_tagComName}은 군사 기술 부족 때문에 중지되었습니다.",$id);
END
}

# 위성격침
sub logEiseifail {
 my($id, $name, $comName, $point) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}에서${HtagComName_}${comName}${H_tagComName}이 실행되었지만${HtagComName_}${comName}${H_tagComName}은${HtagDisaster_}실패${H_tagDisaster}한 것 같습니다.",$id);
END
}

# 유전 발견
sub logOilFound {
 my($id, $name, $point, $comName, $str) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}에서<B>$str</B>의 예산을 투입하여${HtagComName_}${comName}${H_tagComName}이 진행되어,<B>유전이 채굴되었습니다</B>.",$id);
END
}

# 온천 발견
sub logHotFound {
 my($id, $name, $point, $comName, $str) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}에서<B>$str</B>의 예산을 투입하여${HtagComName_}${comName}${H_tagComName}이 진행되어,<B>온천이 발견되었습니다</B>.",$id);
END
}

# 유전 발견 여부
sub logOilFail {
 my($id, $name, $point, $comName, $str) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}에서<B>$str</B>의 예산을 투입하여${HtagComName_}${comName}${H_tagComName}이 실행되었지만, 유전은 발견되지 않았습니다.",$id);
END
}

# 온천 발견여부
sub logHotFail {
 my($id, $name, $point, $comName, $str) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}에서<B>$str</B>의 예산을 투입하여${HtagComName_}${comName}${H_tagComName}이 실행되었지만, 온천은 발견되지 않았습니다.",$id);
END
}

# 유전에서 수입
sub logOilMoney {
 my($id, $name, $lName, $point, $str) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>에서,<B>$str</B> 수익이 발생했습니다.",$id);
END
}

# 유전에서 수입
sub logOilMoney2 {
 my($id, $name, $lName, $point, $str, $str2) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>에서,<B>$str</B> 수익이 발생했습니다.(식량<B>$str2</B>소비)",$id);
END
}

# 신전에서 수입
sub logSinMoney {
 my($id, $name, $str) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>신전</B>에서 축제가 열려,<B>$str</B> 수익이 발생했습니다.",$id);
END
}

# 신사에서 수입
sub logJinMoney {
 my($id, $name, $str) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>신사</B>에서 축제가 열려,<B>$str</B> 수익이 발생했습니다.",$id);
END
}

# 유전 고갈
sub logOilEnd {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>은 고갈된 것 같습니다.",$id);
END
}

# 관문에서 수입
sub logSekiMoney {
 my($id, $name, $lName, $point, $str) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>에서,<B>$str</B>의 관세 수익이 발생했습니다.",$id);
END
}

# 금고갈
sub logGoldEnd {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>에서 금이 더 이상 채굴되지 않는 것 같습니다.",$id);
END
}
# 열차 고장
sub logTrainEnd {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>은 고장난 것 같습니다.",$id);
END
}
# 열차 괴멸
sub logTrainEnd2 {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>은 괴멸한 것 같습니다.",$id);
END
}
# 놀이공원에서 수입
sub logParkMoney {
 my($id, $name, $str, $point, $lName) = @_;
 logOut("${HtagName_}${name} 섬의$point 지점${H_tagName}의<B>$lName</B>에서,<B>총 $str</B>의 수익이 발생했습니다.",$id);
END
}

# 놀이공원의 이벤트
sub logParkEvent {
 my($id, $name, $lName, $point, $str) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>로 이벤트가 개최되며,<B>$str</B>의 식량이 소비되었습니다.",$id);
END
}

# 놀이공원이폐원
sub logParkEnd {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>은 시설이 노후화했기 때문에 철거되었습니다.",$id);
END
}

# 괴수 매입
sub logSiire {
 my($id, $name, $lName, $mName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>은<B>$mName</B>을 반입할 동물을 먼저 지정해야 합니다.",$id);
END
}

# 보험에서 수입
sub logHoken {
 my($id, $name, $lName, $point, $str) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>의 사고로,<B>$str</B>의 보험금이 지급되었습니다.",$id);
END
}

# 기념품점 수입
sub logMiyage {
 my($id, $name, $lName, $point, $str) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName 기념비 공원</B>의 기념품점에서<B>$str</B> 수입이 있었습니다.",$id);
END
}

# O 회사에서 수입
sub logMiyage2 {
 my($id, $name, $lName, $point, $dName) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName 회사</B>은,<B>$dName</B>을 개발했습니다.",$id);
END
}

# O 회사에서 수입
sub logMiyage2b {
 my($id, $name, $lName, $str, $dName) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}의<B>$lName 회사</B>이 소유한<B>$dName</B>은 폭발적으로 판매되어,<B>$str</B>의 경제 효과를 거두었습니다.",$id);
END
}

# O 회사에서 수입
sub logMiyage2c {
 my($id, $name, $lName, $str, $dName) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}의<B>$lName 회사</B>이 소유한<B>$dName</B>은 폭발적으로 판매되어,<B>$str</B>의 경제 효과를 거두었습니다. 참고로 해당 약은 판매 금지되었습니다.",$id);
END
}

# 우승에서 수입
sub logYusho {
 my($id, $name, $lName, $point, $str) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}의 야구팀은${HtagName_}$point${H_tagName}의<B>$lName</B>가 출전한 하코니와 리그 결승전에서 우승하여,<B>$str</B>의 경제 효과가 발생했습니다.",$id);
END
}

# 범선에서 수입
sub logParkMoneyf {
 my($id, $name, $lName, $point, $str) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>에서,<B>$str</B>의 관광 수입이 발생했습니다.",$id);
END
}

# 범선에서 수입
sub logTitanicEnd {
 my($id, $name, $lName, $point, $str) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>의 침몰은 반영그림화됨, 많이의 인이눈물을 흐름했습니다.(<B>$str</B>의 이익 수입)",$id);
END
}

# 해저 탐색색인에서 수입
sub logTansaku {
 my($id, $name, $lName, $point, $str) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>이 보물을 발견!<B>$str</B>의 가치가 있는 것으로 확인되었습니다.",$id);
END
}

# 해저 탐색색인의 유전
sub logTansakuoil {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}에서<B>$lName</B>이유전을 발견!",$id);
END
}

# 자금 융통 수입
sub logEnjo {
 my($id, $name, $lName, $point, $str) = @_;
 logOut("개발진흥위원회에서${HtagName_}${name} 섬${H_tagName}에<B>$str</B>의 자금 융통이 지급되었습니다!",$id);
END
}

# 선박, 노후화
sub logParkEndf {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>은 사고로 침몰했습니다.",$id);
END
}

# TITANIC 격침
sub logTitanic {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>은 빙산에 격렬하게 충돌해 순식간에 침몰했습니다.",$id);
END
}

# 행운
sub logOilMoneyt {
 my($id, $name, $lName, $point, $str) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>이락와 했습니다날개근에<B>$str</B>의 값어치가 있었습니다.",$id);
END
}

# 행운2
sub logParkEventt {
 my($id, $name, $lName, $point, $str) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>이 불러온 풍작으로, 추가로<B>$str</B>의 식량이 생겼습니다.",$id);
END
}

# 선박 수확
sub logParkEventf {
 my($id, $name, $lName, $point, $str) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>은,<B>$str</B>의 식량을 얻었습니다.",$id);
END
}

# 방위 시설, 자폭 설정
sub logBombSet {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>의<B>자폭장치가 설정</B>되었습니다.",$id);
END
}

# 방위 시설, 자폭 작동
sub logBombFire {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>,${HtagDisaster_}자폭장치 작동!!${H_tagDisaster}",$id);
END
}

# 대괴도 침입
sub logKuralupin {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>로${HtagDisaster_}대괴도 침입한 것 같습니다!!${H_tagDisaster}",$id);
END
}

# 기념비, 발사
sub logMonFly {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>이<B>굉음과 함께 흔들렸습니다</B>.",$id);
END
}

# 기념비, 낙하
sub logMonDamage {
 my($id, $name, $point) = @_;
 logOut("<B>정체불명의 물체</B>가${HtagName_}${name} 섬 $point${H_tagName}지점에 낙하했습니다!!",$id);
}

# 나무 심기 or 미사일 기지
sub logPBSuc {
 my($id, $name, $comName, $point) = @_;
 logSecret("${HtagName_}${name} 섬 $point${H_tagName}에서${HtagComName_}${comName}${H_tagComName}이 실행되었습니다.",$id);
 logOut("어디선가 ${HtagName_}${name} 섬${H_tagName}의<B>숲</B>이 늘어난 것 같습니다.",$id);
END
}

# 가짜 기지
sub logHariSuc {
 my($id, $name, $comName, $comName2, $point) = @_;
 logSecret("${HtagName_}${name} 섬 $point${H_tagName}에서${HtagComName_}${comName}${H_tagComName}이 실행되었습니다.",$id);
 logLandSuc($id, $name, $comName2, $point);
END
}

# 미사일 발사 또는 괴수 파견 대상이 없음
sub logMsNoTarget {
 my($id, $name, $comName) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}에서 예정되어 있던${HtagComName_}${comName}${H_tagComName}은, 대상 섬이 무인도이므로 중지되었습니다.",$id);
END
}

# 미사일격하려고했습니다(또는 괴수 파견을 시도했습니다)가전력이이 없음
sub logMsNoEne {
 my($id, $name, $comName) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}에서 예정되어 있던${HtagComName_}${comName}${H_tagComName}은, 전력이 부족하여 섬민이 허가하지 않았습니다.",$id);
END
}

# 미사일격하려고했습니다(또는 괴수 파견을 시도했습니다)가전력이이 없음
sub logMsNoEne2 {
 my($id, $name, $comName) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}에서 예정되어 있던<B>포획 도구사용</B>은, 전력이 부족할 가능성이 있어서 중지되었습니다.",$id);
END
}

# 미사일격하려고했습니다(또는 괴수 파견을 시도했습니다)가전력이이 없음
sub logMsNoEne3 {
 my($id, $name, $comName) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}에서 예정되어 있던${HtagComName_}${comName}${H_tagComName}은 출품 권리가 없어서 무효가 되었습니다.",$id);
END
}

# 미사일격하려고했습니다(또는 괴수 파견을 시도했습니다)가전력이이 없음
sub logMsNoEne4 {
 my($id, $name, $comName) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}에서 예정되어 있던${HtagComName_}${comName}${H_tagComName}은 출품 칸이 비어 있지 않아 무효가 되었습니다.",$id);
END
}

# 마술사격하려고했지만마법가코없음
sub logMagicNoTarget {
 my($id, $name, $comName) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}에서 예정되어 있던${HtagComName_}${comName}${H_tagComName}은, 마법학교가 없어서 거짓자를 파견하고봄했습니다.",$id);
END
}

# 미사일 발사를 시도했지만 기지가 없음
sub logMsNoBase {
 my($id, $name, $comName) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}에서 예정되어 있던${HtagComName_}${comName}${H_tagComName}은,<B>미사일 설비가 없어</B> 실행할 수 없었습니다.",$id);
END
}

# 미사일 발사 결과 범위 밖
sub logMsOut {
 my($id, $tId, $name, $tName, $comName, $point) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행했지만,<B>영역 밖의 바다</B>로 빗나간 모양입니다.",$id, $tId);
}

# 위성파괴성공
sub logEiseiAtts {
 my($id, $tId, $name, $tName, $comName, $tEiseiname) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬${H_tagName}을 대상으로${HtagComName_}${comName}${H_tagComName}을 실행하여,<B>$tEiseiname</B>에 명중.<B>$tEiseiname</B>은 흔적도 없이 사라졌습니다.",$id, $tId);
}

# 우주 정거장파괴성공
sub logEiseiAttcst {
 my($id, $tId, $name, $tName, $comName, $tEiseiname, $tdmg) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬${H_tagName}을 대상으로${HtagComName_}${comName}${H_tagComName}을 실행하여,<B>$tEiseiname</B>에 명중.<B>$tdmg%</B>의 손해를 부여했습니다.",$id, $tId);
}

# 위성파괴실패
sub logEiseiAttf {
 my($id, $tId, $name, $tName, $comName, $tEiseiname) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬${H_tagName}의<B>$tEiseiname</B>을 대상으로${HtagComName_}${comName}${H_tagComName}을 실행했지만, 아무것도 명중하지 않고 우주 저편으로 사라져 버렸습니다.",$id, $tId);
}

# 스텔스 미사일 발사 결과 범위 밖
sub logMsOutS {
 my($id, $tId, $name, $tName, $comName, $point) = @_;
 logSecret("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행했지만,<B>영역 밖의 바다</B>로 빗나간 모양입니다.",$id, $tId);
 logLate("<B>누군가</B>가${HtagName_}${tName} 섬 $point${H_tagName}을 대상으로${HtagComName_}${comName}${H_tagComName}을 실행했지만,<B>영역 밖의 바다</B>로 빗나간 모양입니다.",$tId);
}

# 미사일이 방위 시설에 포착됨
sub logMsCaught {
 my($id, $tId, $name, $tName, $comName, $point, $tPoint) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행했지만,${HtagName_}$tPoint${H_tagName}지점 상공에서 역장에 포착되어,<B>공중 폭발</B>했습니다.",$id, $tId);
}

# 스텔스 미사일이 방위 시설에 포착됨
sub logMsCaughtS {
 my($id, $tId, $name, $tName, $comName, $point, $tPoint) = @_;
 logSecret("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행했지만,${HtagName_}$tPoint${H_tagName}지점 상공에서 역장에 포착되어,<B>공중 폭발</B>했습니다.",$id, $tId);
 logLate("<B>누군가</B>가${HtagName_}${tName} 섬 $point${H_tagName}을 대상으로${HtagComName_}${comName}${H_tagComName}을 실행했지만,${HtagName_}$tPoint${H_tagName}지점 상공에서 역장에 포착되어,<B>공중 폭발</B>했습니다.",$tId);
}

# 발사된 미사일을 방위 위성이 포착
sub logMsCaughtE {
 my($id, $tId, $name, $tName, $comName, $point, $tPoint) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행했지만,<B>방위위성</B>에 격추되었습니다.",$id, $tId);
}

# 미사일 발사 결과 효과 없음
sub logMsNoDamage {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행했지만,${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 빗나가 피해가 없었습니다.",$id, $tId);
}

# 스텔스 미사일 발사 결과 효과 없음
sub logMsNoDamageS {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logSecret("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행했지만,${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 빗나가 피해가 없었습니다.",$id, $tId);

 logLate("<B>누군가</B>가${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행했지만,${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 빗나가 피해가 없었습니다.",$tId);
}

# 육지 파괴탄, 산에 명중
sub logMsLDMountain {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logOut("${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 명중.<B>$tLname</B>은 사라지고, 황무지가 되었습니다.",$id, $tId);
}

# 육지 파괴탄, 해저 기지에 명중
sub logMsLDSbase {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logOut("${HtagName_}$tPoint${H_tagName}에 착탄한 뒤 폭발, 같은 지점에 있던<B>$tLname</B>은 흔적도 없이 날아갔습니다.",$id, $tId);
}

# 육지융기탄, 해저 기지에 명중
sub logMsLRSbase {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logOut("${HtagName_}$tPoint${H_tagName}에 착탄한 뒤 폭발, 같은 지점에 있던<B>$tLname</B>은 융기하여 얕은 바다가 되었습니다.",$id, $tId);
}

# 육지 파괴탄, 괴수에 명중
sub logMsLDMonster {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logOut("${HtagName_}$tPoint${H_tagName}에 착탄해 폭발. 육지는<B>$tLname</B>째로 수몰되었습니다.",$id, $tId);
}

# 육지융기탄, 괴수에 명중
sub logMsLRMonster {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logOut("${HtagName_}$tPoint${H_tagName}에 착탄해 폭발. 육지는<B>$tLname</B>째로 융기하여 산이 생겼습니다.",$id, $tId);
}

# 육지 파괴탄, 얕은 바다에 명중
sub logMsLDSea1 {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logOut("${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 착탄. 해저가 깎였습니다.",$id, $tId);
}

# 육지융기탄, 얕은 바다에 명중
sub logMsLRSea1 {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logOut("${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 착탄. 융기하여 황무지가 되었습니다.",$id, $tId);
}

# 육지 파괴탄, 기타의 지형에 명중
sub logMsLDLand {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logOut("${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 착탄. 육지가 수몰되었습니다.",$id, $tId);
}

# 육지융기탄, 기타의 지형에 명중
sub logMsLRLand {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logOut("${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 착탄. 융기시 산이 생겼습니다.",$id, $tId);
}

# 일반 미사일, 황무지에 착탄
sub logMsWaste {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행했지만,${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 떨어졌습니다.",$id, $tId);
}

# 스텔스 미사일, 황무지에 착탄
sub logMsWasteS {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logSecret("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행했지만,${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 떨어졌습니다.",$id, $tId);
 logLate("<B>누군가</B>가${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행했지만,${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 떨어졌습니다.",$tId);
}

# 핵 미사일, 착탄
sub logMsSS {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logOut("${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 착탄하여 대폭발했습니다.",$id, $tId);
}

# 일반 미사일, 괴수에 명중, 경화 중에서 무사
sub logMsMonNoDamage {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행하여,${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 명중, 그러나 경화 상태였기 때문에 효과가 없었습니다.",$id, $tId);
}

# 스텔스 미사일, 괴수에 명중, 경화 중에서 무사
sub logMsMonNoDamageS {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logSecret("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행하여,${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 명중, 그러나 경화 상태였기 때문에 효과가 없었습니다.",$id, $tId);
 logOut("<B>누군가</B>가${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행하여,${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 명중, 그러나 경화 상태였기 때문에 효과가 없었습니다.",$tId);
}

# 일반 미사일, 괴수에 명중, 살상
sub logMsMonKill {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logOut("${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 명중.<B>$tLname</B>은 힘이 다해 쓰러졌습니다.",$id, $tId);
}

# 스텔스 미사일, 괴수에 명중, 살상
sub logMsMonKillS {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logSecret("${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 명중.<B>$tLname</B>은 힘이 다해 쓰러졌습니다.",$id, $tId);
 logLate("${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 명중.<B>$tLname</B>은 힘이 다해 쓰러졌습니다.", $tId);
}

# 일반 미사일, 괴수에 명중, 피해
sub logMsMonster {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행하여,${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 명중.<B>$tLname</B>은 고통스러운 듯 포효했습니다.",$id, $tId);
}

# 스텔스 미사일, 괴수에 명중, 피해
sub logMsMonsterS {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logSecret("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행하여,${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 명중.<B>$tLname</B>은 고통스러운 듯 포효했습니다.",$id, $tId);
 logLate("<B>누군가</B>가${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행하여,${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 명중.<B>$tLname</B>은 고통스러운 듯 포효했습니다.",$tId);
}

# 괴수의 시체
sub logMsMonMoney {
 my($tId, $mName, $value) = @_;
 logOut("<B>$mName</B>의 잔해에는,<B>$value$HunitMoney</B>의 값어치가 있었습니다.",$tId);
}

# 미사일 정리 메시지 로그
sub logMsTotal {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint, $count, $mukou, $bouei, $kaijumukou, $kaijuhit, $fuhatu) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}$count 발의${comName}${H_tagComName}을 실행했습니다.<br>${HtagNumber_}턴${HislandTurn}${H_tagNumber}:${HtagName_}결과${H_tagName}⇒(무효$mukou 발/방위$bouei 발/괴수 상쇄$kaijumukou 발/괴수 명중$kaijuhit 발/불발탄$fuhatu 발)",$id, $tId);
}

# 스텔스 미사일 정리 메시지 로그
sub logMsTotalS {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint, $count, $mukou, $bouei, $kaijumukou, $kaijuhit, $fuhatu) = @_;
 logSecret("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}$count 발의${comName}${H_tagComName}을 실행했습니다.<br>${HtagNumber_}턴${HislandTurn}${H_tagNumber}:${HtagName_}결과${H_tagName}⇒(무효$mukou 발/방위$bouei 발/괴수 상쇄$kaijumukou 발/괴수 명중$kaijuhit 발/불발탄$fuhatu 발)",$id, $tId);
 logLate("<B>누군가</B>가${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}$count 발의${comName}${H_tagComName}을 실행했습니다.<br>${HtagNumber_}턴${HislandTurn}${H_tagNumber}:${HtagName_}결과${H_tagName}⇒(무효$mukou 발/방위$bouei 발/괴수 상쇄$kaijumukou 발/괴수 명중$kaijuhit 발)",$id, $tId);
}

# 일반 미사일 일반 지형에 명중
sub logMsNormal {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logOut("${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 명중, 일대가 괴멸했습니다.",$id, $tId);
}

# 스텔스 미사일 일반 지형에 명중
sub logMsNormalS {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logSecret("${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 명중, 일대가 괴멸했습니다.",$id, $tId);
 logLate("${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 명중, 일대가 괴멸했습니다.",$tId);
}

# 난민 도착
sub logMsBoatPeople {
 my($id, $name, $achive) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}에어디선가<B>$achive${HunitPop}명의 난민</B>이 표류해 왔습니다.${HtagName_}${name} 섬${H_tagName}은 살기 좋아진 것 같습니다.",$id);
}

# 스텔스 미사일, 괴수에타타키락와 됩니다
sub logMsMonsCautS {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logSecret("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행했지만,${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에타타키락와 됨했습니다.",$id, $tId);
}

# 일반 미사일, 괴수에타타키락와 됩니다(스텔스이외)
sub logMsMonsCaut {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행했지만,${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에타타키락와 됨했습니다.",$id, $tId);
}

# 스텔스 미사일, 천사에타타키락와 됩니다
sub logMsMonsCauttS {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logSecret("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행했지만,${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에타격추됨했습니다.",$id, $tId);
}

# 일반 미사일, 천사에타타키락와 됩니다(스텔스이외)
sub logMsMonsCautt {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행했지만,${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에타격추됨했습니다.",$id, $tId);
}

# 스텔스 미사일, 슬라임에타타키락와 됩니다
sub logMsMonsCautlS {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logSecret("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행했지만,${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에빗나갔습니다.",$id, $tId);
}

# 일반 미사일, 슬라임에타타키락와 됩니다(스텔스이외)
sub logMsMonsCautl {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행했지만,${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에빗나갔습니다.",$id, $tId);
}

# 스텔스 미사일, 메카에타타키락와 됩니다
sub logMsMonsCautmS {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logSecret("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행했지만,${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에한요격 미사일에격추됨했습니다.",$id, $tId);
}

# 일반 미사일, 메카에타타키락와 됩니다(스텔스이외)
sub logMsMonsCautm {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행했지만,${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에한요격 미사일에격추됨했습니다.",$id, $tId);
}

# 괴수가 공격
sub logMonsAttack {
 my($id, $name, $mName, $point, $tName, $tPoint) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$mName</B>이${HtagName_}$tPoint${H_tagName}의<B>$tName</B>에향해 불꽃을 내뿜었습니다.",$id, $tId);
}

# 천사가 공격
sub logMonsAttackt {
 my($id, $name, $mName, $point, $tName, $tPoint) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$mName</B>이${HtagName_}$tPoint${H_tagName}의<B>$tName</B>을 공격했습니다.",$id, $tId);
}

# 수도를 공격
sub logMonsAttacks {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>은 괴수에${HtagDisaster_}공격${H_tagDisaster}됨 피해를 받했습니다.",$id);
}

# 방치 사격 능력 상실
sub logAtAttacks {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>로의${HtagDisaster_}방치 사격 능력 상실${H_tagDisaster}이 소문나, 부근의 주민들의 불안이 커지고 있습니다.",$id);
}

# 이레가 공격
sub logIreAttackt {
 my($id, $name, $mName, $point, $tName, $tPoint) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}의<B>$mName</B>이${HtagName_}$tPoint${H_tagName}의<B>$tName</B>을 공격시${HtagDisaster_}$point${H_tagDisaster}의 피해를 부여했습니다.",$id, $tId);
}

# 마술사가 공격
sub logIreAttackt2 {
 my($id, $name, $mName, $maName, $point, $tName, $tPoint) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}의<B>$mName</B>이 일으킨 <B>$maName</B>은${HtagName_}$tPoint${H_tagName}의<B>$tName</B>에${HtagDisaster_}$point${H_tagDisaster}의 피해를 부여했습니다.",$id, $tId);
}

# 마술사가 공격
sub logIreAttackt3 {
 my($id, $name, $mName, $maName, $point, $tName, $tPoint) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}의<B>$mName</B>이 일으킨 <B>$maName</B>은${HtagName_}$tPoint${H_tagName}의<B>$tName</B>을 격파!",$id, $tId);
}

# 마술사가 공격
sub logIreAttackt4 {
 my($id, $name, $mName, $maName, $point, $tName, $tPoint) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}의<B>$mName</B>이 일으킨 <B>$maName</B>은${HtagDisaster_}$point${H_tagDisaster} 지점의<B>$tName</B>을$tPoint 했습니다!",$id, $tId);
}

# 마술사가 공격
sub logIreAttackt5 {
 my($id, $name, $mName, $maName, $point, $tName, $tPoint) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}의<B>$mName</B>이 소유한<B>$maName</B>은${HtagName_}$tPoint${H_tagName}의<B>$tName</B>을 획득!",$id, $tId);
}

# 마술사가 공격
sub logIreAttackt6 {
 my($id, $name, $mName, $maName, $point, $tName, $tPoint) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}의<B>$mName</B>이 소유한<B>$maName</B>은${HtagName_}$tPoint${H_tagName}의<B>$tName</B>의 포획에 실패!",$id, $tId);
}

# 마술사가 공격
sub logIreAttackt7 {
 my($id, $name, $mName, $maName, $point, $tName, $tPoint) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}의<B>$mName</B>이 소유한<B>$maName</B>은${HtagName_}$tPoint${H_tagName}의<B>$tName</B>을 획득!할 수 있지만, 동물원에 더 이상 수용할 수 없습니다.",$id, $tId);
}

# 칸코와 가 공격
sub logMsAttackt {
 my($id, $name, $mName, $point, $cPoint, $tName, $tPoint) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}의<B>$mName</B>이${HtagName_}$tPoint${H_tagName}의<B>$tName</B>을 공격시${HtagDisaster_}$point${H_tagDisaster}의 피해를 부여에${HtagDisaster_}$cPoint${H_tagDisaster}의 피해를 받했습니다.",$id, $tId);
}

# 미카엘상완성
sub logMsAttackmika {
 my($id, $name, $mName, $point, $cPoint, $tName, $tPoint) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}의<B>$mName</B>토<B>$tName</B>의 전투가 전설로 전해지면서, 섬민들은<B>행복의 여신상</B>을 건조했습니다.",$id, $tId);
}

# 공격에서 머리는 네
sub logItiAttack {
 my($id, $name, $mName, $point, $tName, $tPoint) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$mName</B>이${HtagName_}$tPoint${H_tagName}의<B>$tName</B>의 머리를 베기네했습니다.",$id, $tId);
}

# 공격에서 머리는 네
sub logItiAttackms {
 my($id, $name, $mName, $point, $tName, $tPoint) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$mName</B>이${HtagName_}$tPoint${H_tagName}의<B>$tName</B>을 베어냈습니다.",$id, $tId);
}


# 얼음에서 꼬치찌르기시
sub logIceAttack {
 my($id, $name, $mName, $point, $tName, $tPoint) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$mName</B>의 얼음 화살은${HtagName_}$tPoint${H_tagName}의<B>$tName</B>의 중심을 관통했습니다.",$id, $tId);
}

# 헤루파이아
sub logHellAttack {
 my($id, $name, $mName, $point, $tName, $tPoint) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$mName</B>의 소환된 지옥의 불꽃은${HtagName_}$tPoint${H_tagName}의<B>$tName</B>을 불태웠습니다.",$id, $tId);
}

# 역장에서 괴수아중
sub logBariaAttack {
 my($id, $name, $tName, $tPoint) = @_;
 logOut("${HtagName_}${name} 섬$tPoint${H_tagName}의<B>$tName</B>이<B>강력나역장</B>에누름시파괴됨했습니다.",$id, $tId);
}

# 신형 군함이 공격
sub logFuneAttack {
 my($id, $name, $lName, $point, $tName, $tPoint) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>이다탄두 미사일을 발사시,<B>$tName</B>에 명중했습니다.",$id, $tId);
}

# 천공성이 공격
sub logFuneAttackSSS3 {
 my($id, $name, $lName, $point, $tName, $tPoint) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}의<B>$lName</B>이<B>에너지포</B>을 발사시,${HtagName_}$tPoint${H_tagName}의<B>$tName</B>에 명중. 흔적도 없이 날아갔습니다.",$id, $tId);
}

# 신형 군함이 공격
sub logFuneAttackSSS {
 my($id, $name, $lName, $point, $tName, $tPoint) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>이<B>에너지포</B>을 발사시,<B>$tName</B>에 명중했습니다.",$id, $tId);
}

# 신형 군함이 공격
sub logFuneAttackSSSR {
 my($id, $name, $lName, $point, $tName, $tPoint) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}의<B>$tName</B>은<B>산산조각</B>이 되었습니다.",$id, $tId);
}

# 신형 군함이 공격
sub logFuneAttackSSST {
 my($id, $name, $lName, $point, $tName, $tPoint) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}의<B>$tName</B>은<B>산산조각</B>에됨,<B>$lName</B>은${HtagDisaster_}과열${H_tagDisaster}로${HtagDisaster_}대폭발${H_tagDisaster}했습니다.",$id, $tId);
}

# 괴수순살
sub logFuneMonsterSea {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>은 분출한 영향으로 수몰되었습니다.",$id);
}

# 알부화
sub logEggBomb {
 my($id, $name, $lName, $mName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>에서<B>$mName</B>이출현했습니다.",$id);
}

# 마법메테오
sub logMgMeteo {
 my($id, $name, $mName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$mName</B>은${HtagDisaster_}금지저주메테오${H_tagDisaster}을노래했습니다.",$id);
}

# 마법퀘이크
sub logMgEarthquake {
 my($id, $name, $mName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$mName</B>은${HtagDisaster_}퀘이크${H_tagDisaster}을노래했습니다.",$id);
}

# 마법드레인
sub logMgDrain {
 my($id, $name, $mName, $tName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$mName</B>은<B>$tName</B>에 대해${HtagDisaster_}드레인${H_tagDisaster}을노래했습니다.",$id);
}

# 소환
sub logShoukan {
my($id, $name, $nName, $mName, $point) = @_;
logOut("<B>$nName</B>은${HtagName_}${name} 섬 $point${H_tagName}에<B>$mName</B>을${HtagDisaster_}소환${H_tagDisaster}했습니다.",$id);
}

# 소환
sub logNige {
my($id, $name, $lName, $mName, $point) = @_;
logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>동물원</B>에서<B>$mName</B>이${HtagDisaster_}탈출${H_tagDisaster}했습니다.",$id);
}

# 소환
sub logNige2 {
my($id, $name, $lName, $mName, $point) = @_;
logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>동물원</B>에서<B>$mName</B>을${HtagDisaster_}탈출${H_tagDisaster}하게했습니다.",$id);
}

# 대공황
sub logKyoukou {
 my($id, $name, $mName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$mName</B>은${HtagName_}${name} 섬${H_tagName}에${HtagDisaster_}대공황${H_tagDisaster}을 일으켰습니다.",$id);
}

# 부패식
sub logFushoku {
 my($id, $name, $mName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$mName</B>은${HtagName_}${name} 섬${H_tagName}의비축해 둔 <B>식량</B>을 ${HtagDisaster_}부패${H_tagDisaster}시킨 것 같습니다.",$id);
}

# big 요격?!
sub logEiseiBigcome {
 my($id, $name) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}의<B>요격위성</B>은${HtagName_}${name} 섬${H_tagName}을 향해 날아오는${HtagDisaster_}거대운석${H_tagDisaster}을격추한 것 같습니다!!",$id);
}

# 요격?!
sub logEiseicome {
 my($id, $name) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}의<B>요격위성</B>은${HtagName_}${name} 섬${H_tagName}을 향해 날아오는${HtagDisaster_}운석${H_tagDisaster}을격추한 것 같습니다!!",$id);
}

# 위성소멸?!
sub logEiseiEnd {
 my($id, $name, $tEiseiname) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}의<B>$tEiseiname</B>은${HtagDisaster_}붕괴${H_tagDisaster}한 것 같습니다!!",$id);
}

# 위성소멸2?!
sub logEiseiEndNopop {
 my($id, $name, $tEiseiname) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}의<B>$tEiseiname</B>은${HtagDisaster_}무인화된${H_tagDisaster}것 같습니다!!",$id);
}

# 봉인해제
sub logUmlimit {
 my($id, $name, $mName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$mName</B>의<B>봉인</B>이 ${HtagDisaster_}해제${H_tagDisaster}된 것 같습니다.",$id);
}

# 봉인해제 피해
sub logUmlimitDamage {
 my($id, $name, $mName, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>은<B>$mName</B>의${HtagDisaster_}방출된 에너지${H_tagDisaster}로 괴멸했습니다.",$id);
}

# 알해제 피해
sub logEggDamage {
 my($id, $name, $landName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$landName</B>은${HtagDisaster_}알의 파괴균열에 한에너지${H_tagDisaster}로 수몰되었습니다.",$id);
}

# 우리에루의 코메토~
sub logUrieruMeteo {
 my($id, $name, $lName, $point, $tName, $tPoint) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>이 끌어들인 ${HtagDisaster_}소운석${H_tagDisaster}이${HtagName_}$tPoint${H_tagName}의<B>$tName</B>에낙하시일대가 괴멸했습니다.",$id, $tId);
}

# 메카의미사일
sub logMekaNmiss {
 my($id, $name, $lName, $point, $tName, $tPoint) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>이 발사한 미사일이${HtagName_}$tPoint${H_tagName}의<B>$tName</B>에 착탄하여 일대가 괴멸했습니다.",$id, $tId);
}

# 메카의 피해없음
sub logMekaNdamage {
 my($id, $name, $lName, $point, $tName, $tPoint) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>이 발사한 미사일이${HtagName_}$tPoint${H_tagName}의<B>$tName</B>에 착탄했습니다.",$id, $tId);
}

# 메카의 다탄두
sub logMekaSmiss {
 my($id, $name, $lName, $point, $tName, $tPoint) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>이 발사한${HtagDisaster_}다탄두 미사일${H_tagDisaster}이${HtagName_}$tPoint${H_tagName}의<B>$tName</B>에 착탄했습니다.",$id, $tId);
}

# 메카의 아토믹 봄
sub logMekaAB {
 my($id, $name, $lName, $point, $tName, $tPoint) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>이 발사한${HtagDisaster_}아토믹☆봄${H_tagDisaster}이${HtagName_}$tPoint${H_tagName}의<B>$tName</B>에 착탄하여 대폭발했습니다.",$id, $tId);
}

# 오염된 바다가생된
sub logRottenSeaBorn {
 my($id, $name, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}에<B>왕충</B>에서<B>오염된 바다</B>이 발생했습니다.",$id);
}

# 오염된 바다에 마심미포함된
sub logRottenSeaGrow {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>은<B>오염된 바다</B>에빗나갔습니다.",$id);
}

# 이노라출격
sub logMstakeon {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>은<B>괴수퇴치</B>에향카지금했습니다.",$id);
}

# 이노라귀환집
sub logMstakeokaeri {
 my($id, $name, $lName, $point, $tName) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}의<B>$lName</B>이${HtagName_}$point${H_tagName}의<B>$tName</B>에돌아왔습니다. 수고하셨습니다.",$id);
}

# 이노라가출
sub logMstakeiede {
 my($id, $name, $lName, $point, $tName) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}의<B>$lName</B>은 귀환루베키가가 없어서 에여 행에 출했습니다.",$id);
}

# 이노라행분불명
sub logMstakeoff {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>은<B>칸코와이노라</B>손실 때문에 운영곤란어려움이 되었습니다.",$id);
}

# 흡수 합병
sub logOwnFac {
 my($id, $name, $lName, $point, $sName) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>은 주변 시설을 흡수하여,<B>$sName 회사</B>가 되었습니다.",$id);
}

# 흡수 합병2
sub logOwnFac2 {
 my($id, $name, $lName, $lName2, $point, $sName) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$sName 회사</B>은<B>$lName2</B>을 흡수 합병했습니다.",$id);
}

# 탈피 껍질하고미타
sub logNuginugi {
 my($id, $name, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}에<B>왕충</B>이탈피 껍질했습니다.",$id);
}

# 육지 파괴탄, 오염된 바다에 명중
sub logMsLDSeaRotten {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logOut("${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 착탄. 오염된 바다는 바다에침몰봄했습니다.",$id, $tId);
}

# 육지융기탄, 오염된 바다에 명중
sub logMsLRSeaRotten {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logOut("${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 착탄. 오염된 바다는 융기하여 산이 되었습니다.",$id, $tId);
}

# 스텔스 미사일오염된 바다에 명중
sub logMsNormalSRotten {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logSecret("${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 명중, 오염된 바다는 불타 없어졌습니다.",$id, $tId);
 logLate("{HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 명중, 오염된 바다는 불타 없어졌습니다.",$tId);
}

# 일반 미사일오염된 바다에 명중
sub logMsNormalRotten {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logOut("${HtagName_}$tPoint${H_tagName}의<B>$tLname</B>에 명중, 오염된 바다는 불타 없어졌습니다.",$id, $tId);
}

# 레이저 명중
sub logLzrhit {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행하여,<B>$tLname</B>에 명중,<B>$tLname</B>은 불타 없어졌습니다.",$id, $tId);
}

# 레이저 명중이라도,,
sub logLzrefc {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행하여,<B>$tLname</B>에 명중,<B>$tLname</B>은 정화되었습니다.",$id, $tId);
}

# 대사관이라도,,
sub logTaishi {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${comName}${H_tagComName}을 실행했습니다.",$id, $tId);
}

# 마술사,,
sub logTaishi2 {
 my($id, $tId, $name, $tName, $comName, $tLname, $point, $tPoint, $magickind) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬 $point${H_tagName}지점을 향해${HtagComName_}${magickind}${H_tagComName}을 실행했습니다.",$id, $tId);
}

# 대사관이라도,,
sub logKifu {
 my($id, $tId, $name, $tName, $kifu, $kifukin) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}은보유하고키레없었습니다<B>$kifukin</B>을${HtagName_}$kifu 대사관${H_tagName}에기부했습니다.",$id, $tId);
}

# 괴수 파견
sub logMonsSend {
 my($id, $tId, $name, $tName, $mName) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}이<B>$mName</B>을 탈출시켜,${HtagName_}${tName} 섬${H_tagName}로 보냈습니다.",$id, $tId);
}

# 괴수 파견
sub logMonsSend2 {
 my($id, $tId, $name, $tName, $mName) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}의<B>$mName</B>은,${HtagName_}${tName} 섬${H_tagName}로파견됨했습니다.",$id, $tId);
}

# 자금 융통
sub logDoNothing {
 my($id, $name, $comName) = @_;
# logOut("${HtagName_}${name} 섬${H_tagName}에서${HtagComName_}${comName}${H_tagComName}이 실행되었습니다.",$id);
}

# 수출
sub logSell {
 my($id, $name, $comName, $value) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}이<B>$value$HunitFood</B>의${HtagComName_}${comName}${H_tagComName}을 실행했습니다.",$id);
}

# 지원
sub logAid {
 my($id, $tId, $name, $tName, $comName, $str) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}이${HtagName_}${tName} 섬${H_tagName}으로 <B>$str</B>의${HtagComName_}${comName}${H_tagComName}을 실행했습니다.",$id, $tId);
}

# 유치 활동
sub logPropaganda {
 my($id, $name, $comName) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}에서${HtagComName_}${comName}${H_tagComName}이 실행되었습니다.",$id);
}

# 포기
sub logGiveup {
 my($id, $name) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}은 포기되어 <B>무인 섬</B>이 되었습니다.",$id);
 logHistory("${HtagName_}${name} 섬${H_tagName}, 포기되어 <B>무인 섬</B>이 됩니다.");
}

# 사멸
sub logDead {
 my($id, $name) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}에서 주민이 사라져 <B>무인 섬</B>이 되었습니다.",$id);
 logHistory("${HtagName_}${name} 섬${H_tagName}, 주민이 사라져 <B>무인 섬</B>이 됩니다.");
}

# 발견
sub logDiscover {
 my($name) = @_;
 logHistory("${HtagName_}${name} 섬${H_tagName}이 발견됩니다.");
}

# 이름의 변경
sub logChangeName {
 my($name1, $name2) = @_;
 logHistory("${HtagName_}${name1} 섬${H_tagName}, 명칭을${HtagName_}${name2} 섬${H_tagName}에 변경.");
}

# 기아
sub logStarve {
 my($id, $name) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}의${HtagDisaster_}식량이 부족${H_tagDisaster}하고 있습니다!!",$id);
}

# 전력기아
sub logStarve2 {
 my($id, $name) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}의${HtagDisaster_}전력 부족${H_tagDisaster}하고 있습니다!!",$id);
}

# 전력기아열차
sub logStarve3 {
 my($id, $name, $tname, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$tname</B>은${HtagDisaster_}전력 부족${H_tagDisaster}으로 가동이 중지되었습니다!!",$id);
}

# 중과 세역기레
sub logKire {
 my($id, $name) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}의<B>중과 세</B>에 섬민은${HtagDisaster_}키레${H_tagDisaster}했습니다!!",$id);
}

# 부작용?!
sub logStarvefood {
 my($id, $name) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}의<B>유전자 조작 식물</B>에${HtagDisaster_}부작용${H_tagDisaster}이 있었던 것 같습니다!!",$id);
}

# 불경기?!
sub logFukeiki {
 my($id, $name) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}은${HtagDisaster_}불경기${H_tagDisaster}로성장이 정체된 것 같습니다!!",$id);
}

# 포자?!
sub logRotsick {
 my($id, $name) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}의<B>오염된 바다</B>이방출한<B>포자</B>은${HtagName_}${name} 섬${H_tagName}에${HtagDisaster_}역병${H_tagDisaster}을일으킨 것 같습니다!!",$id);
}

# 역병?!
sub logSatansick {
 my($id, $name) = @_;
 logOut("<B>마왕 사탄</B>은${HtagName_}${name} 섬${H_tagName}의<B>식량</B>을${HtagDisaster_}부패${H_tagDisaster}하게,${HtagName_}${name} 섬${H_tagName}에서는${HtagDisaster_}역병${H_tagDisaster}이퍼지고 있는 것 같습니다!!",$id);
}

# 괴수 출현
sub logMonsCome {
 my($id, $name, $mName, $point, $lName) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}에<B>$mName</B> 출현!!${HtagName_}$point${H_tagName}의<B>$lName</B>이 짓밟혀 파괴되었습니다.",$id);
}

# 괴수 출현
sub logMonsCome2 {
 $hcturn = int($HislandTurn/100)*100;
 my($id, $name, $ac, $topvalue) = @_;
 logAuc("${HtagName_}${name} 섬님${H_tagName},<B>Hakoniwa Auction$hcturn </B>에서<FONT COLOR=\"MEDIUMSEAGREEN\"><B>$ac</B></font>을<B>$topvalue 조 엔</B>로 구매해 주셔서 감합니다.",$id);
}

# 괴수 출현
sub logPrizeAuc2 {
 my($id, $name, $ac, $topvalue) = @_;
 logAuc("${HtagName_}${name} 섬님${H_tagName},<FONT COLOR=\"royalblue\"><B>$aucshouhin 연속 순위 1위!</B></font>(상품 <FONT COLOR=\"MEDIUMSEAGREEN\"><B>$ac</B></font>)",$id);
}

# 괴수 출현
sub logPrizeAuc {
 $hcturn = int($HislandTurn/100)*100;
 my($id, $name, $pName, $value) = @_;
 logAuc("${HtagName_}${name} 섬님${H_tagName},<B>Hakoniwa Auction$hcturn 고액 낙찰 순위 1위!</B>(상금<B>$value</B>)",$id);
}

# 괴수 출현(마방진)
sub logMonsComemagic {
 my($id, $name, $mName, $point, $lName) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}의파괴된 <B>마방진</B>에서<B>$mName</B> 출현!!",$id);
}

# 괴수 방치
sub logMonsFree {
 my($id, $name, $mName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}에서<B>$mName</B>을 구매·방치했습니다.",$id);
}

# 괴수 이동
sub logMonsMove {
 my($id, $name, $lName, $point, $mName) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>이<B>$mName</B>에게 짓밟혀 파괴되었습니다.",$id);
}

# 슬라임이분열했습니다
sub lognewMonsterBorn {
my($id, $name, $point) = @_;
logOut("${HtagName_}${name} 섬 $point${H_tagName}에<B>슬라임</B>이분열했습니다.",$id);
}

# 지원 호출입니다
sub lognewKaiju {
my($id, $name, $mName, $point) = @_;
logOut("${HtagName_}${name} 섬 $point${H_tagName}에<B>$mName</B>이도움을 요청해 왔습니다.",$id);
}

# 괴수, 자폭입니다
sub logMonsBomb {
 my($id, $name, $lName, $point, $mName) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$mName</B>이${HtagDisaster_}메루와 다운${H_tagDisaster}을일으켜자폭했습니다.",$id);
}

# 괴수, 주변을 불태우는
sub logMonsFire {
 my($id, $name, $lName, $point, $mName) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>이<B>$mName</B>에한충격파에서 괴멸했습니다.",$id);
}

# 콘덴서아푸
sub logConsFire {
 my($id, $name, $lName, $point, $comName) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>은${HtagComName_}$comName${H_tagComName}로 축적된 황금 보안 에너지가실행되었습니다.",$id);
}

# 괴수 주변을 모두 동결 처리
sub logMonsCold {
 my($id, $name, $lName, $point, $mName) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>은<B>$mName</B>을 처리 과정에서 얼어붙었습니다.",$id);
}

# 괴수, 방위 시설을 밟음무
sub logMonsMoveDefence {
 my($id, $name, $lName, $point, $mName) = @_;
 logOut("<B>$mName</B>이${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>로 도달,<B>${lName}의 자폭장치가 작동!!</B>",$id);
}

# 괴수, 지뢰를 밟아 사망, 시체없음
sub logMonsMineKill {
 my($id, $name, $lName, $point, $mName) = @_;
 logOut("<B>괴수$mName</B>이${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>을 밟아 폭발,<B>괴수$mName</B>은 사라졌습니다.",$id);
}

# 괴수, 지뢰를 밟아 사망, 시체있음
sub logMonsMineDead {
 my($id, $name, $lName, $point, $mName) = @_;
 logOut("<B>괴수$mName</B>이${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>을 밟아 폭발,<B>괴수$mName</B>은 힘이 다해 쓰러졌습니다.",$id);
}

# 괴수, 지뢰를 밟아 피해 발생
sub logMonsMineHit {
 my($id, $name, $lName, $point, $mName) = @_;
 logOut("<B>괴수$mName</B>이${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>을 밟아 폭발,<B>괴수$mName</B>은 고통스러운 듯 포효했습니다.",$id);
}

# 화재
sub logFire {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>이${HtagDisaster_}화재${H_tagDisaster}로 괴멸했습니다.",$id);
}
# 누전
sub logRouden {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>은${HtagDisaster_}누전${H_tagDisaster}을하고 있는 것 같습니다.",$id);
}
# 누전2
sub logRouden2 {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>은${HtagDisaster_}에너지균형이부균등균형${H_tagDisaster}에나하고 있는 것 같습니다.",$id);
}
# 화재미 수행
sub logFirenot {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>이${HtagDisaster_}화재${H_tagDisaster}로 피해를 받했습니다.",$id);
}

# 매장금
sub logMaizo {
 my($id, $name, $comName, $value) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}에서 ${HtagComName_}$comName${H_tagComName} 중에,<B>$value$HunitMoney 상당의 매장금</B>을 발견했습니다.",$id);
}

# 금괴
sub logGold {
 my($id, $name, $comName, $value) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}에서 ${HtagComName_}$comName${H_tagComName} 중에,<B>금괴</B>이 발견되어<B>$value$HunitMoney</B>의 이익이 발생했습니다.",$id);
}

# 알
sub logEggFound {
 my($id, $name, $comName, $value) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}에서 ${HtagComName_}$comName${H_tagComName} 중에,<B>무언가의 알</B>이 발견되어${HtagComName_}$comName 업자${H_tagComName}에는 파괴할 수 없으므로이므 로그대로 두기로 했습니다.",$id);
}

# 유적흔적
sub logIsekiFound {
 my($id, $name, $comName, $value) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}에서 ${HtagComName_}$comName${H_tagComName} 중에,<B>고대 유적</B>이 발견되어<B> 섬의 중요매립저장문화재정</B>에지정됨했습니다.",$id);
}

# 지진발생
sub logEarthquake {
 my($id, $name) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}로 대규모${HtagDisaster_}지진${H_tagDisaster}이 발생!!",$id);
}

# 부적
sub logOmamori {
 my($id, $name) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}소유의<B>부적</B>의 효과인지,${HtagDisaster_}피해${H_tagDisaster}가 없었던 것 같습니다!!",$id);
}

# 마탑바리아
sub logOmamori2 {
 my($id, $name) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}을 <B>배리어</B>의 효과로 ${HtagDisaster_}피해${H_tagDisaster}가 없었던 것 같습니다!!",$id);
}

# 지진 피해
sub logEQDamage {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>은${HtagDisaster_}지진${H_tagDisaster}으로 괴멸했습니다.",$id);
}

# 지진 피해미 수행
sub logEQDamagenot {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>은${HtagDisaster_}지진${H_tagDisaster}로 피해를 받했습니다.",$id);
}

# 식량부족 피해
sub logSvDamage {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>에<B>식량을 찾는 주민이 몰려들었습니다</B>.<B>$lName</B>은 괴멸했습니다.",$id);
}

# 중과 세 피해
sub logKireDamage {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>은${HtagDisaster_}폭됨 섬민${H_tagDisaster}에따라${HtagDisaster_}파괴${H_tagDisaster}됨했습니다.",$id);
}

# 쓰나미발생
sub logTsunami {
 my($id, $name) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}부근에서${HtagDisaster_}쓰나미${H_tagDisaster} 발생!!",$id);
}

# 쓰나미 피해
sub logTsunamiDamage {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>은${HtagDisaster_}쓰나미${H_tagDisaster}로 붕괴했습니다.",$id);
}

# 태풍발생
sub logTyphoon {
 my($id, $name) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}에${HtagDisaster_}태풍${H_tagDisaster} 상륙!!",$id);
}

# 태풍 피해
sub logTyphoonDamage {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>은${HtagDisaster_}태풍${H_tagDisaster}으로 날아갔습니다.",$id);
}

# 태풍 피해·선박
sub logTyphoonHason {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>은${HtagDisaster_}태풍${H_tagDisaster}에따라파손했습니다.",$id);
}

# 운석, 바다
sub logMeteoSea {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>에${HtagDisaster_}운석${H_tagDisaster}이 낙하했습니다.",$id);
}

# 운석, 산
sub logMeteoMountain {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>에${HtagDisaster_}운석${H_tagDisaster}이 낙하,<B>$lName</B>은 사라졌습니다.",$id);
}

# 운석, 해저 기지
sub logMeteoSbase {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>에${HtagDisaster_}운석${H_tagDisaster}이 낙하,<B>$lName</B>은 붕괴했습니다.",$id);
}

# 운석, 괴수
sub logMeteoMonster {
 my($id, $name, $lName, $point) = @_;
 logOut("<B>$lName</B>이 있던${HtagName_}${name} 섬 $point${H_tagName}지점에${HtagDisaster_}운석${H_tagDisaster}이 낙하, 육지는<B>$lName</B>째로 수몰되었습니다.",$id);
}

# 운석, 얕은 바다
sub logMeteoSea1 {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}지점에${HtagDisaster_}운석${H_tagDisaster}이 낙하, 해저가 깎였습니다.",$id);
}

# 운석, 기타
sub logMeteoNormal {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}지점의<B>$lName</B>에${HtagDisaster_}운석${H_tagDisaster}이 낙하, 일대가 수몰되었습니다.",$id);
}

# 운석, 기타
sub logHugeMeteo {
 my($id, $name, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}지점에${HtagDisaster_}거대운석${H_tagDisaster}이 낙하!!",$id);
}
# 운석, 기타
sub logMidMeteo {
 my($id, $name, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}지점에${HtagDisaster_}소혜성${H_tagDisaster}이 낙하!!",$id);
}
# 운석, 기타
sub logMidMeteo2 {
 my($id, $name, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}지점에${HtagDisaster_}소혜성${H_tagDisaster}이 낙하!!했지만, 주변의<b>방위 시설·개정</b>이방어한 것 같습니다.",$id);
}
# 운석, 기타
sub logMidMeteo3 {
 my($id, $name, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}지점에${HtagDisaster_}운석${H_tagDisaster}이 낙하!!했지만, 주변의<b>방위 시설·개정</b>이방어한 것 같습니다.",$id);
}
# 운석, 기타
sub logHugeMeteo4 {
 my($id, $name, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}지점에${HtagDisaster_}운석${H_tagDisaster}이 낙하!!",$id);
}

# 분화
sub logEruption {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}지점에서${HtagDisaster_}화산이 분화${H_tagDisaster},<B>산</B>이 생겼습니다.",$id);
}

# 분화, 얕은 바다
sub logEruptionSea1 {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}지점의<B>$lName</B>은,${HtagDisaster_}분화${H_tagDisaster}의 영향으로 육지가 되었습니다.",$id);
}

# 분화, 바다 or 바다 기준
sub logEruptionSea {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}지점의<B>$lName</B>은,${HtagDisaster_}분화${H_tagDisaster}의 영향으로 해저가 융기하여, 얕은 바다가 되었습니다.",$id);
}

# 분화, 기타
sub logEruptionNormal {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}지점의<B>$lName</B>은,${HtagDisaster_}분화${H_tagDisaster}의 영향으로 괴멸했습니다.",$id);
}

# 지반 침하발생
sub logFalldown {
 my($id, $name) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}에서${HtagDisaster_}지반 침하${H_tagDisaster}가 발생했습니다!!",$id);
}

# 지반 침하 피해
sub logFalldownLand {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>은 바다의 안로 침몰봄했습니다.",$id);
}

# 광역 피해, 수몰
sub logWideDamageSea {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>은<B>수몰</B>했습니다.",$id);
}

# 광역 피해, 바다의 건설
sub logWideDamageSea2 {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>은 흔적도 없이 사라졌습니다.",$id);
}

# 광역 피해, 괴수수몰
sub logWideDamageMonsterSea {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의 육지는<B>$lName</B>째로 수몰되었습니다.",$id);
}

# 광역 피해, 괴수
sub logWideDamageMonster {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>은 사라졌습니다.",$id);
}

# 광역 피해, 황무지
sub logWideDamageWaste {
 my($id, $name, $lName, $point) = @_;
 logOut("${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>은 한순간에 <B>황무지</B>가 되었습니다.",$id);
}

# 수상
sub logPrize {
 my($id, $name, $pName) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}이<B>$pName</B>을 수상했습니다.",$id);
 logHistory("${HtagName_}${name} 섬${H_tagName},<B>$pName</B>을 수상");
}

# 수상
sub logPrizet {
 my($id, $name, $pName, $value) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}이<B>$pName</B>을 수상했습니다.",$id);
 logHistory("${HtagName_}${name} 섬${H_tagName},<B>$pName</B>을 수상(상금<B>$value</B>)");
}

# 하코니와 컵
sub logHC {
 my($id, $name, $stsanka) = @_;
 logHistory("${HtagName_}Hakoniwa Cup$HislandTurn${H_tagName}개최!참가 수$stsanka 섬!");
 logHcup("${HtagName_}Hakoniwa Cup$HislandTurn${H_tagName}개최!참가 수$stsanka 섬!");
}

# 하코니와 컵개회식
sub logHCstart {
 my($id, $name, $str) = @_;
 logHistory("${HtagName_}${name} 섬${H_tagName}에서<B>Hakoniwa Cup 개회식</B>이 진행되며,<B>$str</B>의 경제 효과를 크게 발생시켰습니다.",$id);
 logHcup("${HtagName_}${name} 섬${H_tagName}에서<B>Hakoniwa Cup 개회식</B>이 진행되며,<B>$str</B>의 경제 효과를 크게 발생시켰습니다.",$id);
}

# 하코니와 컵시도합
sub logHCgame {
 my($id, $tId, $name, $tName, $lName, $gName, $goal, $tgoal) = @_;
 logLate("${HtagName_}${name} 섬${H_tagName}에서<B>$gName</B>이 실행되었습니다.${HtagName_}${name} 섬 대표${H_tagName}<B>VS</B>${HtagName_}${tName} 섬 대표${H_tagName} ⇒ <B>$goal-$tgoal</B>",$id, $tId);
 logHcup("${HtagName_}${gName}${H_tagName},${HtagName_}${name} 섬 대표${H_tagName}<B>VS</B>${HtagName_}${tName} 섬 대표${H_tagName} ⇒ <B>$goal-$tgoal</B>",$id, $tId);
}

# 하코니와 컵승리
sub logHCwin {
 my($id, $name, $cName, $str) = @_;
 logLate("${HtagName_}${name} 섬 대표${H_tagName}은,<B>$str</B>을 획득했습니다.",$id);
}

# 하코니와 컵우승
sub logHCwintop {
 my($id, $name, $cName) = @_;
 logHistory("${HtagName_}${name} 섬 대표${H_tagName},<B>Hakoniwa Cup$cName 우승!</B>",$id);
 logHcup("${HtagName_}${name} 섬 대표${H_tagName},<B>Hakoniwa Cup$cName 우승!</B>",$id);
}

# 하코니와 컵부전승
sub logHCantiwin {
 my($id, $name, $gName) = @_;
 logLate("${HtagName_}${name} 섬 대표${H_tagName}은<B>대전 상대</B>가 없어 <B>$gName</B>가 되었습니다.",$id);
 logHcup("${HtagName_}${name} 섬 대표${H_tagName}은<B>대전 상대</B>가 없어 <B>$gName</B>.",$id);
}

# 하코니와 컵
sub logHCsin {
 my($id, $name, $stsin) = @_;
 logHistory("${HtagName_}Hakoniwa Cup 결승 토너먼트 진출 섬!!${H_tagName}<br><font size=\"-1\"><B>$stsin</B></font>");
 logHcup("${HtagName_}Hakoniwa Cup 결승 토너먼트 진출 섬!!${H_tagName}<br><font size=\"-1\"><B>$stsin</B></font>");
}

# 섬이 가득 찬 경우
sub tempNewIslandFull {
 out(<<END);
${HtagBig_}신청이 몰려, 섬이 가득 차서 등록할 수 없습니다.${H_tagBig}$HtempBack
END
}

# 신규 등록 시 이름이 없는 경우
sub tempNewIslandNoName {
 out(<<END);
${HtagBig_}입력이부충분입니다.${H_tagBig}$HtempBack
END
}

# 신규 등록 시 이름이 올바르지 않은 경우
sub tempNewIslandBadName {
 out(<<END);
${HtagBig_}',?()<>\$'등을 넣거나,'무인 섬'등 이상한 이름은 피하세요~${H_tagBig}$HtempBack
END
}

# 이미 같은 이름의 섬이 있는 경우
sub tempNewIslandAlready {
 out(<<END);
${HtagBig_}그 섬이면 이미 발견되어 있습니다.${H_tagBig}$HtempBack
END
}

# 이미같은 IP 의 섬이 있는 경우
sub tempIPIslandAlready {
 out(<<END);
${HtagBig_}당신와 같은 IP 의 섬이이미 발견되어 있습니다.<br>중복 등록방지에고협력해 주세요.${H_tagBig}$HtempBack
END
}

# 비밀번호가 없는 경우
sub tempNewIslandNoPassword {
 out(<<END);
${HtagBig_} 비밀번호가필요입니다.${H_tagBig}$HtempBack
END
}

# 섬을 발견했습니다!!
sub tempNewIslandHead {
 out(<<END);
<CENTER>
${HtagBig_} 섬을 발견했습니다!!${H_tagBig}<BR>
${HtagBig_}${HtagName_}'${HcurrentName} 섬'${H_tagName}을 찾았습니다.${H_tagBig}<BR>
$HtempBack<BR>
</CENTER>
END
}

# 지형의 호출분
sub landName {
 my($land, $lv) = @_;

 if($land == $HlandSea) {
	if($lv == 1) {
 return '얕은 바다';
 } else {
 return '바다';
	}
 } elsif($land == $HlandIce) {
	if($lv> 0) {
 return '천연 스케이트장';
 } else {
 return '빙하';
	}
 } elsif($land == $HlandWaste) {
	return '황무지';
 } elsif($land == $HlandPlains) {
	return '평지';
 } elsif($land == $HlandPlains2) {
	return '개발 예정지';
 } elsif($land == $HlandTown) {
	if($lv < 30) {
	 return '마을';
	} elsif($lv < 100) {
	 return '읍';
	} else {
	 return '도시';
	}
 } elsif($land == $HlandProcity) {
	return '방재 도시';
 } elsif($land == $HlandNewtown) {
	return '뉴타운';
 } elsif($land == $HlandBigtown) {
	return '현대 도시';
 } elsif($land == $HlandBettown) {
	return '고층 도시';
 } elsif($land == $HlandSkycity) {
	return '공업 도시';
 } elsif($land == $HlandUmicity) {
	return '바다 도시';
 } elsif($land == $HlandSeatown) {
	return '해저 신도시';
 } elsif($land == $HlandRizort) {
	return '리조트';
 } elsif($land == $HlandKajino) {
	return '카지노';
 } elsif($land == $HlandBigRizort) {
	return '임시 해변 리조트 호텔';
 } elsif($land == $HlandShuto) {
	return '수도';
 } elsif($land == $HlandUmishuto) {
	return '해저 수도';
 } elsif($land == $HlandForest) {
	return '숲';
 } elsif($land == $HlandFarm) {
	return '농장';
 } elsif($land == $HlandEneAt) {
	return '원자력발전소';
 } elsif($land == $HlandEneFw) {
	return '화력 발전소';
 } elsif($land == $HlandEneWt) {
	return '수력발전소';
 } elsif($land == $HlandEneWd) {
	return '풍력발전소';
 } elsif($land == $HlandEneBo) {
	return '바이오매스 발전소';
 } elsif($land == $HlandEneSo) {
	return '소라발전소';
 } elsif($land == $HlandEneCs) {
	return '코스모 발전소';
 } elsif($land == $HlandConden) {
	return '콘덴서';
 } elsif($land == $HlandConden2) {
	return '콘덴서·개정';
 } elsif($land == $HlandConden3) {
	return '황금의 콘덴서';
 } elsif($land == $HlandConden4) {
	if($lv == 3) {
	 return '황금의 콘덴서(누전안)';
	} elsif($lv == 2) {
	 return '콘덴서·개정(누전안)';
	} elsif($lv == 99) {
	 return '핵융합발전소';
	} else {
	 return '황금의 콘덴서(누전안)';
	}
 } elsif($land == $HlandFoodka) {
	return '식품 가공 공장';
 } elsif($land == $HlandFoodim) {
	if($lv < 480) {
	 return '식품 연구소';
	} else {
	 return '방재형식품 연구소';
	}
 } elsif($land == $HlandFarmchi) {
	return '양계장';
 } elsif($land == $HlandFarmpic) {
	return '양돈장';
 } elsif($land == $HlandFarmcow) {
	return '목장';
 } elsif($land == $HlandYakusho) {
	return '섬관청';
 } elsif($land == $HlandCollege) {
	if($lv == 0) {
	 return '농업대학';
	} elsif($lv == 1) {
	 return '공업대학';
	} elsif($lv == 2) {
	 return '종합대학';
	} elsif($lv == 3) {
	 return '군사대학';
	} elsif($lv == 4) {
	 return '생물 대학(대기안)';
	} elsif($lv == 98) {
	 return '생물 대학(대기안)';
	} elsif($lv == 96) {
	 return '생물 대학(출입 금지안)';
	} elsif($lv == 97) {
	 return '생물 대학(출입 금지안)';
	} elsif($lv == 99) {
	 return '생물 대학(출동안)';
	} elsif($lv == 5) {
	 return '기상대학';
	} elsif($lv == 6) {
	 return '경제대학';
	} elsif($lv == 7) {
	 return '마법학교';
	} elsif($lv == 8) {
	 return '전기공사대학';
	} elsif($lv == 77) {
	 return '문부과학성';
	} elsif($lv == 78) {
	 return '문부과학성';
	} elsif($lv == 79) {
	 return '문부과학성';
	} elsif($lv == 80) {
	 return '문부과학성';
	} elsif($lv == 95) {
	 return '경제대학(저금안)';
	} else {
	 return '기상대학';
	}
 } elsif($land == $HlandHouse) {
	if($lv == 0) {
	 return '오두막';
	} elsif($lv == 1) {
	 return '간이주택';
	} elsif($lv == 2) {
	 return '주택';
	} elsif($lv == 3) {
	 return '고급주택';
	} elsif($lv == 4) {
	 return '저택';
	} elsif($lv == 5) {
	 return '대저택';
	} elsif($lv == 6) {
	 return '고급 저택';
	} elsif($lv == 7) {
	 return '성';
	} elsif($lv == 8) {
	 return '거성';
	} else {
	 return '황금성';
	}
 } elsif($land == $HlandTrain) {
	if($lv == 0) {
	 return '역';
	} elsif($lv < 10) {
	 return '선로';
	} elsif($lv == 10) {
	 return '역(일반 열차 정차 중)';
	} elsif($lv < 20) {
	 return '일반 열차';
	} elsif($lv == 20) {
	 return '역(화물 열차 정차 중)';
	} elsif($lv < 30) {
	 return '화물 열차';
	}
 } elsif($land == $HlandTaishi) {
	return '대사관';
 } elsif($land == $HlandKura) {
	return '창고';
 } elsif($land == $HlandKuraf) {
	return '창고';
 } elsif($land == $HlandFactory) {
	return '공장';
 } elsif($land == $HlandHTFactory) {
	return '첨단 기술 다국적 기업';
 } elsif($land == $HlandSHTF) {
	return '첨단 기술 다국적 기업·개정';
 } elsif($land == $HlandOWNF) {
	return '섬운영기업';
 } elsif($land == $HlandBase) {
	return '미사일 기지';
 } elsif($land == $HlandDefence) {
	if($lv == 77) {
	 return '방위 시설·개정';
	} else {
	 return '방위 시설';
	}
 } elsif($land == $HlandMountain) {
	return '산';
 } elsif($land == $HlandGold) {
	return '금광산';
 } elsif($land == $HlandOnsen) {
	return '온천거리';
 } elsif($land == $HlandMonster) {
	my($kind, $name, $hp) = monsterSpec($lv);
	return $name;
 } elsif($land == $HlandSbase) {
	return '해저 기지';
 } elsif($land == $HlandSeacity) {
	return '해저 도시';
 } elsif($land == $HlandOil) {
	return '해저 유전';
 } elsif($land == $HlandMonument) {
	return $HmonumentName[$lv];
 } elsif($land == $HlandHaribote) {
	return '가짜 기지';
 } elsif($land == $HlandPark) {
 return '놀이공원';
 } elsif($land == $HlandMinato) {
	return '항구 도시';
 } elsif($land == $HlandFune) {
	return $HfuneName[$lv];
 } elsif($land == $HlandFrocity) {
	return '해상 도시';
 } elsif($land == $HlandSunahama) {
	return '해변';
 } elsif($land == $HlandMine) {
 return '지뢰';
 } elsif($land == $HlandNursery) {
 return '양식장';
 } elsif($land == $HlandKyujo) {
 return '야구장';
 } elsif($land == $HlandKyujokai) {
 return '다목적 경기장';
 } elsif($land == $HlandZoo) {
 return '동물원';
 } elsif($land == $HlandUmiamu) {
 return '해상 시설';
 } elsif($land == $HlandSeki) {
	return '관문';
 } elsif($land == $HlandRottenSea) {
	if($lv < 20) {
	 return '오염된 바다';
	} else {
	 return '고사 바다';
	}
 }
}

# 인구기타의 값을 산출
sub estimate {
 my($number) = $_[0];
 my($island);
 my($pop, $area, $farm, $mountain) = (0, 0, 0, 0);
 my($factory1, $factory2) = (0, 0);
 my($monslive, $monslivetype) = (0, 0);
 my($kei, $rena, $fore, $tare, $zipro, $leje) = (0, 0, 0, 0, 0, 0);
 my($oil) = (0);
 my($bas) = (0);
 my($kyu) = (0);
 my($amu) = (0);
 my($par) = (0);
 my($riz) = (0);
 my($fim) = (0);
 my($rot) = (0);
 my($sci) = (0);
 my($sba) = (0);
 my($pro) = (0);
 my($kin) = (0);
 my($nto) = (0);
 my($m26) = (0);
 my($m27) = (0);
 my($m17) = (0);
 my($c11) = (0);
 my($c13) = (0);
 my($c21) = (0);
 my($c28) = (0);
 my($c23) = (0);
 my($co0) = (0);
 my($co1) = (0);
 my($co2) = (0);
 my($co3) = (0);
 my($co4) = (0);
 my($co5) = (0);
 my($co6) = (0);
 my($co7) = (0);
 my($co8) = (0);
 my($co99) = (0);
 my($co77) = (0);
 my($co78) = (0);
 my($co79) = (0);
 my($co80) = (0);
 my($yaku) = (0);
 my($co01) = (0);
 my($co95) = (0);
 my($tet) = (0);
 my($hot) = (0);
 my($hou) = (0);
 my($shu) = (0);
 my($sin) = (0);
 my($jin) = (0);
 my($m74) = (0);
 my($m75) = (0);
 my($m76) = (0);
 my($m77) = (0);
 my($m78) = (0);
 my($m79) = (0);
 my($m84) = (0);
 my($m93) = (0);
 my($m96) = (0);
 my($m97) = (0);
 my($m98) = (0);
 my($m99) = (0);
 my($m100) = (0);
 my($m101) = (0);
 my($m73) = (0);
 my($gyo) = (0);
 my($ky2) = (0);
 my($zoo) = (0);
 my($htf) = (0);
 my($shtf) = (0);
 my($ownf) = (0);
 my($tai) = (0);
 my($tra) = (0);
 my($tra1) = (0);
 my($tra2) = (0);
 my($ene) = (0);
 my($h10) = (0);
 my($h11) = (0);
 my($con99) = (0);
 my($choki2) = (0);
 my($ownfe) = (0);

 # 지형을 가져옴
 $island = $Hislands[$number];
 my($land) = $island->{'land'};
 my($landValue) = $island->{'landValue'};

 $etc5 = $island->{'etc5'};
 $etc5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
 ($s00,$s01,$s02,$s03,$s04,$s05,$s06,$s07,$s08,$s09,$s10,$s11,$s12,$s13,$s14,$s15,$s16,$s17,$s18,$s19,$s20,$s21,$s22,$s23,$s24,$s25,$s26,$s27,$s28,$s29,$s30) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);

 if ($island->{'fukeikimoney'} < $island->{'money'}) {
	$island->{'fukeikimoney'} = $island->{'money'};
 }

 # 수 가능
 my($x, $y, $kind, $value);
 for($y = 0; $y < $HislandSize; $y++) {
	for($x = 0; $x < $HislandSize; $x++) {
	 $kind = $land->[$x][$y];
	 $value = $landValue->[$x][$y];
	 my($mKind, $mName, $mHp) = monsterSpec($value);
	 if(($kind != $HlandSea) &&
	 ($kind != $HlandIce) &&
	 ($kind != $HlandSbase) &&
	 ($kind != $HlandFune) &&
	 ($kind != $HlandFrocity) &&
	 ($kind != $HlandUmicity) &&
 ($kind != $HlandNursery) &&
 ($kind != $HlandUmiamu) &&
 ($kind != $HlandSeacity) &&
 ($kind != $HlandSeatown) &&
 ($kind != $HlandUmishuto) &&
	 ($kind != $HlandOil)){
		$area++;
		if(($kind == $HlandTown) ||
		 ($kind == $HlandProcity) ||
		 ($kind == $HlandOnsen) ||
		 ($kind == $HlandShuto) ||
		 ($kind == $HlandMinato)) {
		 # 읍
		 $pop += $value;
		} elsif(($kind == $HlandFarm) ||
			($kind == $HlandFoodim)) {
		 # 농장
		 $farm += $value;
		} elsif(($kind == $HlandFoodka) && ($value> 0)) {
		 $factory1 += $value*200;
		 $farm += $value*200;
		} elsif($kind == $HlandFarmchi) {
		 $tare += $value;
		 $factory1 += int($value/100)+1;
		} elsif($kind == $HlandFarmpic) {
		 $zipro += $value;
		 $factory1 += int($value/80)+1;
		} elsif($kind == $HlandFarmcow) {
		 $leje += $value;
		 $factory1 += int($value/50)+1;
		} elsif(($kind == $HlandFactory) ||
			($kind == $HlandHTFactory) ||
			($kind == $HlandPark)) {
		 # 공장
		 $factory1 += $value;
		} elsif($kind == $HlandSHTF) {
		 $factory2 += $value;
		} elsif($kind == $HlandOWNF) {
		 $ownfe = int($value/1000);
		 $factory2 += int($value/100)%10*250;
		 $factory1 += int($value%100/10)*250;
		 $farm += $value%10*250;
		} elsif(($kind == $HlandMountain) ||
			($kind == $HlandGold)) {
		 # 산
		 $mountain += $value;
		} elsif($kind == $HlandForest) {
		 $fore += $value;
		} elsif($kind == $HlandNewtown) {
		 # 뉴타운
		 $pop += $value;
		 $nwork = int($value/15);
		 $factory1 += $nwork;
		} elsif($kind == $HlandBigtown) {
		 # 현대 도시
		 $pop += $value;
		 $mwork = int($value/20);
		 $lwork = int($value/30);
		 $factory1 += $mwork;
		 $farm += $lwork;
		} elsif($kind == $HlandBettown) {
		 # 고층 도시
		 $pop += $value;
		} elsif($kind == $HlandSkycity) {
		 # 공업 도시
		 $pop += $value;
		 $factory2 += int($value/60);
		 $farm += int($value/60);
		 $island->{'shouhi'} += int($value/2*(100-$s02)/100);
		} elsif($kind == $HlandRizort) {
		 # 리조트
		 $pop += $value;
		} elsif($kind == $HlandKajino) {
		 # 리조트
		 $pop += $value;
		 $island->{'shouhi'} += int($value/10*(100-$s02)/100);
		} elsif($kind == $HlandBigRizort) {
		 # 리조트
		 $pop += $value;
		} elsif($kind == $HlandBase) {
		 # 기지
		 $bas += $value;
		 $rena += $value;
		 $island->{'shouhi'} += int($value/4*(100-$s02)/100);
		}
 } elsif ($kind == $HlandNursery) {
 # 양식장은 농장의 일종
 $farm += $value;
 } elsif ($kind == $HlandUmiamu) {
 $factory1 += $value;
 } elsif ($kind == $HlandSeacity) {
 $pop += $value;
 } elsif ($kind == $HlandFrocity) {
 $pop += $value;
 } elsif ($kind == $HlandUmicity) {
 $pop += $value;
		$factory2 += int($value/60);
		$farm += int($value/60);
		$island->{'shouhi'} += int($value/2*(100-$s02)/100);
 } elsif ($kind == $HlandUmishuto) {
 $pop += $value;
 } elsif ($kind == $HlandSeatown) {
 $pop += $value;
		 $owork = int($value/40);
		 $factory1 += $owork;
		 $farm += $owork;
 } elsif ($kind == $HlandSbase) {
 $bas += $value;
		$rena += $value;
		$island->{'shouhi'} += int($value/2*(100-$s02)/100);
	 }

 $oil++ if ($kind == $HlandOil);
 $htf++ if ($kind == $HlandHTFactory);
 $shtf++ if ($kind == $HlandSHTF);
 $ownf++ if ($kind == $HlandOWNF);
 $kei++ if ($kind == $HlandMonument);
 $kyu++ if ($kind == $HlandKyujo);
 $kyu++ if ($kind == $HlandKyujokai);
 $ky2++ if ($kind == $HlandKyujokai);
 $zoo++ if ($kind == $HlandZoo);
 $amu++ if ($kind == $HlandUmiamu);
 $par++ if ($kind == $HlandPark);
 $riz++ if ($kind == $HlandRizort);
 $riz++ if ($kind == $HlandKajino);
 $fim++ if (($kind == $HlandFoodim) && ($value < 480));
 $rot++ if (($kind == $HlandRottenSea) && ($value < 20));
 $sci++ if ($kind == $HlandSeacity);
 $sci++ if ($kind == $HlandSeatown);
 $sci++ if ($kind == $HlandSeatown);
 $sba++ if ($kind == $HlandSbase);
 $pro++ if ($kind == $HlandProcity);
 $pro++ if ($kind == $HlandFrocity);
 $kin++ if ($kind == $HlandGold);
 $nto++ if ($kind == $HlandNewtown);
 $m73++ if (($kind == $HlandMonument) && ($value == 73));
 $m96++ if (($kind == $HlandMonument) && ($value == 96));
 $m97++ if (($kind == $HlandMonument) && ($value == 97));
 $m98++ if (($kind == $HlandMonument) && ($value == 98));
 $m99++ if (($kind == $HlandMonument) && ($value == 99));
 $m100++ if (($kind == $HlandMonument) && ($value == 100));
 $m101++ if (($kind == $HlandMonument) && ($value == 101));
 $m26++ if (($kind == $HlandMonument) && ($value == 86));
 $m27++ if (($kind == $HlandMonument) && ($value == 87));
 $m74++ if (($kind == $HlandMonument) && ($value == 74));
 $m75++ if (($kind == $HlandMonument) && ($value == 75));
 $m76++ if (($kind == $HlandMonument) && ($value == 76));
 $m77++ if (($kind == $HlandMonument) && ($value == 77));
 $m78++ if (($kind == $HlandMonument) && ($value == 78));
 $m79++ if (($kind == $HlandMonument) && ($value == 79));
 $m84++ if (($kind == $HlandMonument) && ($value == 84));
 $m93++ if (($kind == $HlandHouse) && ($value == 10));
 $m93++ if (($kind == $HlandHouse) && ($value == 11));
 $h10++ if (($kind == $HlandHouse) && ($value == 10));
 $h11++ if (($kind == $HlandHouse) && ($value == 11));
 $m17++ if (($kind == $HlandMonument) && ($value == 17));
 $m17++ if ($kind == $HlandEneCs);
 $sin++ if (($kind == $HlandMonument) && ($value == 26));
 $jin++ if (($kind == $HlandMonument) && ($value == 27));
 $c11++ if (($kind == $HlandMonster) && ($mKind == 11));
 $c13++ if (($kind == $HlandMonster) && ($mKind == 13));
 $c13++ if (($kind == $HlandMonument) && ($value == 93));
 $c21++ if (($kind == $HlandMonster) && ($mKind == 21));
 $c28++ if (($kind == $HlandMonster) && ($mKind == 28));
 $c28++ if (($kind == $HlandMonster) && ($mKind == 30));
 $c23++ if (($kind == $HlandMonster) && ($mKind == 23));
 $co0++ if (($kind == $HlandCollege) && ($value == 0));
 $co1++ if (($kind == $HlandCollege) && ($value == 1));
 $co01++ if (($kind == $HlandCollege) && ($value == 1));
 $co1++ if (($kind == $HlandCollege) && ($value == 8));
 $co2++ if (($kind == $HlandCollege) && ($value == 2));
 $co1++ if (($kind == $HlandCollege) && ($value == 2));
 $co0++ if (($kind == $HlandCollege) && ($value == 2));
 $co3++ if (($kind == $HlandCollege) && ($value == 3));
 $co4++ if (($kind == $HlandCollege) && ($value == 4));
 $co4++ if (($kind == $HlandCollege) && ($value == 98));
 $co4++ if (($kind == $HlandCollege) && ($value == 97));
 $co4++ if (($kind == $HlandCollege) && ($value == 96));
 $co99++ if (($kind == $HlandCollege) && ($value == 99));
 $co5++ if (($kind == $HlandCollege) && ($value == 5));
 $co6++ if (($kind == $HlandCollege) && ($value == 6));
 $co6++ if (($kind == $HlandCollege) && ($value == 95));
 $co95++ if (($kind == $HlandCollege) && ($value == 95));
 $co7++ if (($kind == $HlandCollege) && ($value == 7));
 $co8++ if (($kind == $HlandCollege) && ($value == 8));
 $co77++ if (($kind == $HlandCollege) && ($value == 77));
 $co77++ if (($kind == $HlandCollege) && ($value == 78));
 $co77++ if (($kind == $HlandCollege) && ($value == 79));
 $co77++ if (($kind == $HlandCollege) && ($value == 80));
 $co78++ if (($kind == $HlandCollege) && ($value == 78));
 $co79++ if (($kind == $HlandCollege) && ($value == 79));
 $co80++ if (($kind == $HlandCollege) && ($value == 80));
 $yaku++ if ($kind == $HlandYakusho);
 $tet++ if (($kind == $HlandCollege) && ($value == 98));
 $tet++ if (($kind == $HlandCollege) && ($value == 97));
 $tet++ if (($kind == $HlandMonster) && ($mKind == 30));
 $hot++ if ($kind == $HlandOnsen);
 $hou++ if ($kind == $HlandHouse);
 $tai++ if ($kind == $HlandTaishi);
 $shu++ if ($kind == $HlandShuto);
 $shu++ if ($kind == $HlandUmishuto);
 $gyo++ if (($kind == $HlandFune) && ($value == 1));
 $gyo++ if (($kind == $HlandFune) && ($value == 2));
 $gyo++ if (($kind == $HlandFune) && ($value == 5));
 $gyo++ if (($kind == $HlandFune) && ($value == 6));
 $gyo++ if (($kind == $HlandFune) && ($value == 11));
 $tra++ if ($kind == $HlandTrain);
 $tra1++ if (($kind == $HlandTrain) && (($value == 10) || ($value == 11) || ($value == 12) || ($value == 13) || ($value == 14) || ($value == 15) || ($value == 16) || ($value == 17) || ($value == 18) || ($value == 19)));
 $tra2++ if (($kind == $HlandTrain) && (($value == 20) || ($value == 21) || ($value == 22) || ($value == 23) || ($value == 24) || ($value == 25) || ($value == 26) || ($value == 27) || ($value == 28) || ($value == 29)));

	 if($kind == $HlandEneAt) {
		 $ene += $value;
	 }
	 if($kind == $HlandEneBo) {
		 $ene += $value;
	 }
	 if($kind == $HlandEneWt) {
		 $ene += int($value*(random(80)+70)/100);
			if($island->{'Typhoonflag'} == 1) {
			$ene += int($value*(random(80)+70)/100);
			}
	 }
	 if(($kind == $HlandEneSo) && ($island->{'Typhoonflag'} != 1)) {
		 $ene += int($value*(random(25)+75)/100);
	 }
	 if($kind == $HlandEneWd) {
		 $ene += int($value*(random(75)+50)/100);
			if($island->{'Typhoonflag'} == 1) {
			$ene += int($value*(random(75)+50)/100);
			}
	 }
	 if(($kind == $HlandEneFw) && ($island->{'oil'}> 0)) {
		 $ene += $value;
		 $ene += $value;
	 } elsif(($kind == $HlandEneFw) && ($island->{'mountain'}> 0)) {
		 $ene += $value;
	 }
	 if(($kind == $HlandEneCs) && ($island->{'eis7'}> 0)) {
		 $ene += $value;
	 }
	 if(($kind == $HlandConden4) && ($value == 99)) {
		 $con99++;
	 }
	 if($kind == $HlandConden) {
		 $ene += $value;
		 $landValue->[$x][$y] = 0;
	 }
	 if($kind == $HlandConden2) {
		 $ene += $value;
		 $landValue->[$x][$y] = 0;
	 }
	 if($kind == $HlandConden3) {
		 $ene += $value;
		 $ene += $value;
		 $landValue->[$x][$y] = 0;
	 }

 if ($kind == $HlandMonster) {
 my($mKind, $mName, $mHp) = monsterSpec($value);
 $monslive++;
 $monslivetype |= (2 ** $mKind);
 }

 if ($kind == $HlandTaishi) {
	 my($tn) = $HidToNumber{$value};
	 my($tIsland) = $Hislands[$tn];
	 if ($tIsland->{'money'}> $island->{'money'}) {
		 $island->{'fukeikimoney'} = $tIsland->{'money'};
	 }
 }

 if ($kind == $HlandKura) {
		$seq = int($value/100);
		$choki = $value%100;
		$choki2 += $choki;
 }

	}
 }


 if($con99> 0) {
	 $magicl = $m79 + int($m100/2);
	 $magica = $m75 + int($m98/2);
		if ($island->{'h10'}> 0) {
		 $magicf += 10;
		 $magici += 10;
		 $magica += 10;
		 $magicw += 10;
		 $magicd += 10;
		}
		if ($island->{'h11'}> 0) {
		 $magicl += 10;
		}
	 if($magica != $magicl) {
		$ene += random($magicl*15000+50000);
		$ene -= int(random($magicl*15000+50000) * (50-$s02)/50);
	 } else {
		$ene += $magicl*15000+50000+$s02*1000;
	 }
 }


 if($island->{'eis7'}>= 1) {
	$eis7 = $island->{'eis7'};
	$cstpop = int($eis7/100);
	$csten = $eis7%100;
	$pop += $cstpop;
 }


 # 대입
 $island->{'pop'} = $pop;
 $island->{'area'} = $area;
 $island->{'farm'} = $farm;
 $island->{'factory'} = "$factory1,$factory2,$co0,$co1,$htf,$shtf,$co95,$co95,$co95,$co95";
 $island->{'factory1'} = $factory1;
 $island->{'factory2'} = $factory2;
 $island->{'factoryt'} = $factory1+$factory2;
 $island->{'mountain'} = $mountain;

 $island->{'oil'} = $oil;
 $island->{'bas'} = $bas;
 $island->{'kyu'} = $kyu;
 $island->{'ky2'} = $ky2;
 $island->{'zoo'} = $zoo;
 $island->{'amu'} = $amu;
 $island->{'par'} = $par;
 $island->{'riz'} = $riz;
 $island->{'fim'} = $fim;
 $island->{'rot'} = $rot;
 $island->{'sci'} = $sci;
 $island->{'sba'} = $sba;
 $island->{'pro'} = $pro;
 $island->{'kin'} = $kin;
 $island->{'nto'} = $nto;
 $island->{'m26'} = $m26;
 $island->{'m27'} = $m27;
 $island->{'m17'} = $m17;
 $island->{'c11'} = $c11;
 $island->{'c13'} = $c13;
 $island->{'c21'} = $c21;
 $island->{'c28'} = $c28;
 $island->{'c23'} = $c23;
 $island->{'co0'} = $co0;
 $island->{'co1'} = $co1;
 $island->{'co01'} = $co01;
 $island->{'co2'} = $co2;
 $island->{'co3'} = $co3;
 $island->{'co4'} = $co4;
 $island->{'co5'} = $co5;
 $island->{'co6'} = $co6;
 $island->{'co7'} = $co7;
 $island->{'co8'} = $co8;
 $island->{'co99'} = $co99;
 $island->{'co77'} = $co77;
 $island->{'co78'} = $co78;
 $island->{'co79'} = $co79;
 $island->{'co80'} = $co80;
 $island->{'yaku'} = $yaku;
 $island->{'tet'} = $tet;
 $island->{'hot'} = $hot;
 $island->{'hou'} = $hou;
 $island->{'tai'} = $tai;
 $island->{'shu'} = $shu;
 $island->{'sin'} = $sin;
 $island->{'jin'} = $jin;
 $island->{'m96'} = $m96;
 $island->{'m97'} = $m97;
 $island->{'m98'} = $m98;
 $island->{'m99'} = $m99;
 $island->{'m100'} = $m100;
 $island->{'m101'} = $m101;
 $island->{'m74'} = $m74;
 $island->{'m75'} = $m75;
 $island->{'m76'} = $m76;
 $island->{'m77'} = $m77;
 $island->{'m78'} = $m78;
 $island->{'m79'} = $m79;
 $island->{'m84'} = $m84;
 $island->{'m93'} = $m93;
 $island->{'m73'} = $m73;
 $island->{'h10'} = $h10;
 $island->{'h11'} = $h11;
 $island->{'gyo'} = $gyo;
 $island->{'htf'} = $htf;
 $island->{'shtf'} = $shtf;
 $island->{'ownf'} = $ownf;
 $island->{'tra'} = $tra;
 $island->{'tra1'} = $tra1;
 $island->{'tra2'} = $tra2;
 $island->{'etc0'} = $tra+int($island->{'trainmoney'}/1000)+int($island->{'trainmoney2'}/500);
 $island->{'ownfe'} = $ownfe;

 $ene = int($ene*(1+$island->{'co8'}/10));
 if($ene < 0) {
	$ene = 0;
 }

 $island->{'shouhi'} += int($pop/200*(100-$s02)/100)+int($factory1/20*(100-$s02)/100)+int($factory2/10*(100-$s02)/100);
 $island->{'shouhi'} += int($island->{'pts'}/300*(100-$s02)/100);
 $island->{'shouhi'} += int($island->{'rena'}/30*(100-$s02)/100);
 $island->{'shouhi'} += int($island->{'rena'}/30*(100-$s02)/100);
 $island->{'sabun'} = $ene-$island->{'shouhi'};
 $island->{'eisei3'} = "$ene,$island->{'shouhi'},$island->{'shouhi'},$ene,$ene";

 $island->{'ene'} = $ene;
 $island->{'con99'} = $con99;

 if($island->{'pts'}> $HouseLevel9) {
	$enekeisu = 2.5;
 } elsif($island->{'pts'}> $HouseLevel8) {
	$enekeisu = 2.35;
 } elsif($island->{'pts'}> $HouseLevel7) {
	$enekeisu = 2.2;
 } elsif($island->{'pts'}> $HouseLevel6) {
	$enekeisu = 2.15;
 } elsif($island->{'pts'}> $HouseLevel5) {
	$enekeisu = 1.9;
 } elsif($island->{'pts'}> $HouseLevel4) {
	$enekeisu = 1.75;
 } elsif($island->{'pts'}> $HouseLevel3) {
	$enekeisu = 1.6;
 } elsif($island->{'pts'}> $HouseLevel2) {
	$enekeisu = 1.45;
 } elsif($island->{'pts'}> $HouseLevel1) {
	$enekeisu = 1.2;
 } else {
	$enekeisu = 1;
 }

 if($HislandSize < 16) {
	$enekeisu = 1;
 }

 $enepoint = int($ene/(10*$enekeisu));

 $magicf = $m78 + int($m96/2);
 $magici = $m76 + int($m97/2);
 $magica = $m75 + int($m98/2);
 $magicw = $m77 + int($m99/2);
 $magicl = $m79 + int($m100/2);
 $magicd = $m74 + int($m101/2);

 if ($island->{'h10'}> 0) {
 $magicf += 10;
 $magici += 10;
 $magica += 10;
 $magicw += 10;
 $magicd += 10;
 }
 if ($island->{'h11'}> 0) {
 $magicl += 10;
 }
 $island->{'etc9'} = "$co7,$magicf,$magici,$magica,$magicw,$magicl,$magicd";

 if ($island->{'sabun'}> 0) {
	my($x, $y, $landKind, $lv, $i);
	for($i = 0; $i < $HpointNumber; $i++) {
	 $x = $Hrpx[$i];
	 $y = $Hrpy[$i];
	 $landKind = $land->[$x][$y];
	 $lv = $landValue->[$x][$y];
	 if(($landKind == $HlandConden) && ($lv < 2000)) {

 $n = int((2000 - $lv) / 2);
 $n = min(int($n + $n), $island->{'sabun'});
 $island->{'sabun'} -= $n;
 $landValue->[$x][$y] += $n;
		if ($value> 2000) {
 $landValue->[$x][$y] = 2000;
		}

	 }
 	 if(($landKind == $HlandConden2) && ($lv < 4000)) {

 $n = int((4000 - $lv) / 10);
 $n = min(int($n*9 + rand($n)), $island->{'sabun'});
 $island->{'sabun'} -= $n;
 $landValue->[$x][$y] += $n;
		if ($value> 4000) {
 $landValue->[$x][$y] = 4000;
		}

	 }
	 if(($landKind == $HlandConden3) && ($lv < 7000)) {

 $n = int((7000 - $lv) / 2);
 $n = min(int($n + $n), $island->{'sabun'});
 $island->{'sabun'} -= $n/2;
 $landValue->[$x][$y] += $n/2;
		if ($value> 7000) {
 $landValue->[$x][$y] = 7000;
		}

	 }

 last if ($island->{'sabun'} <= 0);
	}
 }

 # 섬주의 가판정
 if($island->{'hou'} == 0) {
	$island->{'eisei1'} = 0;
 }

 # 수도판정
 if($island->{'shu'} == 0) {
	$island->{'totoyoso2'} = 555;
 } elsif($island->{'totoyoso2'} == 555) {
	my($onm);
	$onm = $island->{'onm'};
	$island->{'totoyoso2'} = "$onm 시티";
 }

 # 통 산 관광객
 if($island->{'eisei2'} < 0) {
	$island->{'eisei2'} = 0;
 }

 $eisei4 = $island->{'eisei4'};
 $eisei4 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
 ($sto, $std, $stk, $stwin, $stdrow, $stlose, $stwint, $stdrowt, $stloset, $styusho, $stshoka) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11);
 $kachiten = $stwin*3 + $stdrow;
 $island->{'kachiten'} = $kachiten;

 if($island->{'ky2'} == 0) {
	$island->{'eisei4'} = "$sto,$std,$stk,0,0,0,$stwint,$stdrowt,$stloset,$styusho,0";
 }


 if(($island->{'co77'} == 0) || ($island->{'etc5'} == 0)) {
	$island->{'etc5'} = '0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0';
 }


 $etc5 = $island->{'etc5'};
 $etc5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
 ($s00,$s01,$s02,$s03,$s04,$s05,$s06,$s07,$s08,$s09,$s10,$s11,$s12,$s13,$s14,$s15,$s16,$s17,$s18,$s19,$s20,$s21,$s22,$s23,$s24,$s25,$s26,$s27,$s28,$s29,$s30) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);

 $island->{'etc5'} = "$co77,$s01,$s02,$s03,$s04,$s05,$s06,$s07,$s08,$s09,$s10,$s11,$s12,$s13,$s14,$s15,$s16,$s17,$s18,$s19,$s20,$s21,$s22,$s23,$s24,$s25,$s26,$s27,$s28,$s29,$s30";


 if($island->{'zoo'} == 0) {
	$island->{'etc6'} = '0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0';
 }

 $etc6 = $island->{'etc6'};
 $etc6 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
 ($z00,$z01,$z02,$z03,$z04,$z05,$z06,$z07,$z08,$z09,$z10,$z11,$z12,$z13,$z14,$z15,$z16,$z17,$z18,$z19,$z20,$z21,$z22,$z23,$z24,$z25,$z26,$z27,$z28,$z29,$z30) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);
 $zookazu = $z0+$z1+$z2+$z3+$z4+$z5+$z6+$z7+$z8+$z9+$z10+$z11+$z12+$z13+$z14+$z15+$z16+$z17+$z18+$z19+$z20+$z21+$z22+$z23+$z24+$z25+$z26+$z27+$z28+$z29+$z30;

 $island->{'etc6'} = "$z00,$z01,$z02,$z03,$z04,$z05,$z06,$z07,$z08,$z09,$z10,$z11,$z12,$z13,$z14,$z15,$z16,$z17,$z18,$z19,$z20,$z21,$z22,$z23,$z24,$z25,$z26,$z27,$z28,$z29,$z30";

 $island->{'monsterlive'} = $monslive; # 괴수출현 수
 $island->{'monsterlivetype'} = $monslivetype; # 괴수출현종류
 $monsterlive2 = $monslive + $zookazu;
 $island->{'monsterlive2'} = $monsterlive2; # 괴수출현 수

 $island->{'kei'} = $kei;
	$eisei5 = $island->{'eisei5'};
	$eisei5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	($mshp, $msap, $msdp, $mssp, $mswin, $msexe, $tetsub) = ($1, $2, $3, $4, $5, $6, $7);
 $island->{'rena'} = $rena + $co2*100 + $co3*500 + $msexe;
 $island->{'fore'} = $fore;
 $island->{'tare'} = $tare;
 $island->{'zipro'} = $zipro;
 $island->{'leje'} = $leje;

 # 칸코와 판정
 if(($island->{'co4'} == 0) &&
	($island->{'co99'} == 0) &&
	($island->{'c28'} == 0)) {
 $island->{'eisei5'} = "0,0,0,0,0,0,0";
 }

 $eisei5 = $island->{'eisei5'};
 $eisei5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
 ($mshp, $msap, $msdp, $mssp, $mswin, $msexe, $tetsub) = ($1, $2, $3, $4, $5, $6, $7);
 $island->{'eisei5'} = "$mshp,$msap,$msdp,$mssp,$mswin,$msexe,$tet";

 $island->{'eisei6'} = "$c13,$shu,$m26,$m27,$m74,$m75,$m76,$m77,$m78,$m79,$m84,$m93";

 # 실업자 수
 $island->{'unemployed'} = $pop - ($farm + $factory1 + $factory2 + $mountain) * 10;


 my($eiseip1) = (0);
 my($eiseip2) = (0);
 my($eiseip3) = (0);
 my($eiseip4) = (0);
 my($eiseip5) = (0);
 my($eiseip6) = (0);


 if($island->{'eis1'}>= 1) {
	$eiseip1 = 100 + $island->{'eis1'}*2;
 }
 if($island->{'eis2'}>= 1) {
	$eiseip2 = 300 + $island->{'eis2'}*2;
 }
 if($island->{'eis3'}>= 1) {
	$eiseip3 = 500 + $island->{'eis3'}*2;
 }
 if($island->{'eis4'}>= 1) {
	$eiseip4 = 900 + $island->{'eis4'}*2;
 }
 if($island->{'eis5'}>= 1) {
	$eiseip5 = 1500 + $island->{'eis5'}*2;
 }
 if($island->{'eis6'}>= 1) {
	$eiseip6 = 2000 + $island->{'eis6'}*2;
 }


 $etc8 = $island->{'etc8'};
 $etc8 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
 ($toto1, $toto2, $toto3, $toto4, $toto5, $toto6, $toto7) = ($1, $2, $3, $4, $5, $6, $7);
 $island->{'etc8'} = "$toto1,$toto2,$toto3,$toto4,$toto5,$toto6,$toto7";

 $totoyoso2 = $island->{'totoyoso2'};
 $island->{'totoyoso2'} = "$totoyoso2";
 $totoyoso = $island->{'totoyoso'};
 $island->{'totoyoso'} = "$totoyoso";

 $auc1 = $island->{'auc1'};
 $island->{'auc1'} = "$auc1";
 $auc2 = $island->{'auc2'};
 $island->{'auc2'} = "$auc2";
 $auc3 = $island->{'auc3'};
 $island->{'auc3'} = "$auc3";

 $auc4 = $island->{'auc4'};
 $auc4 =~ /^([0-9]*),([0-9]*),([0-9]*)$/;
 ($auc4a, $auc4b, $auc4c) = ($1, $2, $3);
 $island->{'auc4'} = "$auc4a,$auc4b,$auc4c";

 $auc0 = $island->{'auc0'};
 $auc0 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
 ($auc0a, $auc0b, $auc0c, $auc0d, $auc0e) = ($1, $2, $3, $4, $5);
 $island->{'auc0'} = "$auc0a,$auc0b,$auc0c,$auc0d,$auc0e";
 $island->{'auc0c'} = $auc0c;

 $auc5 = $island->{'auc5'};
 $auc5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
 ($auc5a, $auc5b, $auc5c, $auc5d, $auc5e) = ($1, $2, $3, $4, $5);
 $island->{'auc5'} = "$auc5a,$auc5b,$auc5c,$auc5d,$auc5e";
 $island->{'auc5c'} = $auc5c;

 $auc6 = $island->{'auc6'};
 $auc6 =~ /^([0-9]*),([0-9]*),([0-9]*)$/;
 ($auc6a, $auc6x, $auc6y) = ($1, $2, $3);
 $island->{'auc6'} = "$auc6a,$auc6x,$auc6y";

 if($auc6a == 1) {
	$oyasumiritu++;
 }

 $auc7 = $island->{'auc7'};
 $island->{'auc7'} = $auc7;
 $auc8 = $island->{'auc8'};
 $island->{'auc8'} = $auc8;

 $auc9 = $island->{'auc9'};
 $auc9 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
 ($auc9a, $auc9b, $auc9c, $auc9d, $auc9e) = ($1, $2, $3, $4, $5);

 $auc9c2 = int($auc9c/10000);

 $auc9b = $co95*25+$choki2;

 $auc9a = $auc9b + $auc9c2 + $auc9d + $auc9e;

 $island->{'auc9'} = "$auc9a,$auc9b,$auc9c,$auc9d,$auc9e";

 $auc0es = (11-$auc0e)*500;
 if($auc0c == 0) {
	$auc0es = 0;
 }
 if($auc0es < 0) {
	$auc0es = 0;
 }


 if($AnkeitoOnOff == 0) {
	$island->{'anflag'} = 0;
 }


 $etc5 = $island->{'etc5'};
 $etc5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
 ($s00,$s01,$s02,$s03,$s04,$s05,$s06,$s07,$s08,$s09,$s10,$s11,$s12,$s13,$s14,$s15,$s16,$s17,$s18,$s19,$s20,$s21,$s22,$s23,$s24,$s25,$s26,$s27,$s28,$s29,$s30) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);

 $s12b = int($s12/5)+1;
 if($s12b> 10) {$s12b = 10;}

 if($island->{'money'}> 999999*$s12b) {
	$moneypts = 9999*$s12b + (($island->{'money'}-999999*$s12b)/100)**0.75;
 } else {
	$moneypts = $island->{'money'}/100;
 }

 # 종합 Point
 $island->{'pts'} = int($pop + $moneypts + $island->{'food'}/100 + ($farm*2 + $factory1 + $factory2*2 + $mountain*2) + $bas + $area*5 + int($fore/15) + $sci*30 + $pro*20 + $sba*10 + $amu*10 + $oil*500 + $kin*500 + $m26*500 + $m27*500 + $m74*750 + $m75*750 + $m76*750 + $m77*750 + $m78*750 + $m79*750 + $m93*2000 + int($tare/15) + int($zipro/12) + int($leje/10) + int($island->{'rena'}/10) + $eiseip1 + $eiseip2 + $eiseip3 + $eiseip4 + $eiseip5 + $eiseip6 + $hou*500 + $enepoint + $tra1*150 + $tra2*150 + $auc0es);

	$eisei4 = $island->{'eisei4'};
	$eisei4 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	($sto, $std, $stk, $stwin, $stdrow, $stlose, $stwint, $stdrowt, $stloset, $styusho, $stshoka) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11);
	$kachiten = $stwin*3 + $stdrow;
	$kachitent = $stwint*3 + $stdrowt;
	$siaisu = $stwint + $stdrowt + $stloset;
	if($siaisu == 0) {
	 $siaisu = 1;
	}
	$shoritu = int($stwint / $siaisu * 100);
	$teamforce = $sto + $std + $stk;

	$island->{'kachitent'} = $kachitent;
	$island->{'shoritu'} = $shoritu;
	$island->{'styusho'} = $styusho;
	$island->{'teamforce'} = $teamforce;

	$eisei5 = $island->{'eisei5'};
	$eisei5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	($mshp, $msap, $msdp, $mssp, $mswin, $msexe, $tet) = ($1, $2, $3, $4, $5, $6, $7);
	$force = $mshp+$msap+$msdp+$mssp;
	$island->{'force'} = $force;

	$eisei6 = $island->{'eisei6'};
	$eisei6 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	($unimika, $unishuto, $unimeka, $unioumu, $unianseki, $unitiseki, $unihyouseki, $unifuseki, $unienseki, $unikouseki, $uniiseki, $uniden) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12);

	$unimika3 = ($unimika == 0) ? "0" : "1";
	$unishuto3 = ($unishuto == 0) ? "0" : "1";
	$unimeka3 = ($unimeka == 0) ? "0" : "1";
	$unioumu3 = ($unioumu == 0) ? "0" : "1";
	$unianseki3 = ($unianseki == 0) ? "0" : "1";
	$unitiseki3 = ($unitiseki == 0) ? "0" : "1";
	$unihyouseki3 = ($unihyouseki == 0) ? "0" : "1";
	$unifuseki3 = ($unifuseki == 0) ? "0" : "1";
	$unienseki3 = ($unienseki == 0) ? "0" : "1";
	$unikouseki3 = ($unikouseki == 0) ? "0" : "1";
	$uniiseki3 = ($uniiseki == 0) ? "0" : "1";
	$uniden3 = ($uniden == 0) ? "0" : "1";

	$tuni = $unimika+$unishuto+$unimeka+$unioumu+$unianseki+$unitiseki+$unihyouseki+$unifuseki+$unienseki+$unikouseki+$uniiseki+$uniden;
	$uni = $unimika3+$unishuto3+$unimeka3+$unioumu3+$unianseki3+$unitiseki3+$unihyouseki3+$unifuseki3+$unienseki3+$unikouseki3+$uniiseki3+$uniden3;
	$island->{'uni'} = $uni;
	$island->{'tuni'} = $tuni;

 $island->{'pts'} += $island->{'bumon'}*100*$HislandNumber;

 if($anothermood == 1) {
 $island->{'money'} += $island->{'bumon'}*100*$HislandNumber + $auc0es;
 $island->{'pts'} = $island->{'money'}+$island->{'incomemoney'};
 }


 if($island->{'hou'}> 0) {
	 my($x, $y, $i);
	 for($i = 0; $i < $HpointNumber; $i++) {
		$x = $Hrpx[$i];
		$y = $Hrpy[$i];
		my($landKind) = $land->[$x][$y];
		my($lv) = $landValue->[$x][$y];

			if($landKind == $HlandHouse) {
				$etc8 = $island->{'etc8'};
				$etc8 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
				($toto1, $toto2, $toto3, $toto4, $toto5, $toto6, $toto7) = ($1, $2, $3, $4, $5, $6, $7);

			 if(($island->{'pts'}> $HouseLevel9) && ($island->{'m75'}> 0) && ($island->{'m76'}> 0) && ($island->{'m77'}> 0) && ($island->{'m78'}> 0) && ($island->{'c13'}> 0) && ($island->{'shu'}> 0) && ($island->{'m26'}> 0) && ($island->{'m27'}> 0) && ($island->{'m84'}> 0) && ($toto2> 0)) {
					if(($island->{'m74'}> 0) || ($island->{'m79'}> 0)) {
					$landValue->[$x][$y] = 11;
						if($island->{'m74'}>= $island->{'m79'}) {
						$landValue->[$x][$y] = 10;
						}
					}
			 } elsif($island->{'pts'}> $HouseLevel9) {
			 	 $landValue->[$x][$y] = 9;
			 } elsif($island->{'pts'}> $HouseLevel8) {
			 	 $landValue->[$x][$y] = 8;
			 } elsif($island->{'pts'}> $HouseLevel7) {
				 $landValue->[$x][$y] = 7;
			 } elsif($island->{'pts'}> $HouseLevel6) {
			 	 $landValue->[$x][$y] = 6;
			 } elsif($island->{'pts'}> $HouseLevel5) {
				 $landValue->[$x][$y] = 5;
			 } elsif($island->{'pts'}> $HouseLevel4) {
			 	 $landValue->[$x][$y] = 4;
			 } elsif($island->{'pts'}> $HouseLevel3) {
				 $landValue->[$x][$y] = 3;
			 } elsif($island->{'pts'}> $HouseLevel2) {
			 	 $landValue->[$x][$y] = 2;
			 } elsif($island->{'pts'}> $HouseLevel1) {
				 $landValue->[$x][$y] = 1;
			 } else {
				 $landValue->[$x][$y] = 0;
			 }
			}
		}
	}


	# 사멸판정2
	if($island->{'dead'} == 1) {
	 $island->{'pop'} = 0;
	 $island->{'pts'} = 0;
	} elsif($island->{'pop'} == 0) {
	 $island->{'dead'} = 1;
	 $island->{'pts'} = 0;
	}

}


# 범위 안의 지형을 수 가능
sub countAround {
 my($land, $x, $y, $kind, $range) = @_;
 my($i, $count, $sx, $sy);
 $count = 0;
 for($i = 0; $i < $range; $i++) {
	 $sx = $x + $ax[$i];
	 $sy = $y + $ay[$i];

	 # 행 기준 위치 조정
	 if((($sy % 2) == 0) && (($y % 2) == 1)) {
	 $sx--;
	 }

	 if(($sx < 0) || ($sx>= $HislandSize) ||
	 ($sy < 0) || ($sy>= $HislandSize)) {
	 # 범위 밖의 경우
	 if($kind == $HlandSea) {
		 # 바다이면 가 산
		 $count++;
	 }
	 } else {
	 # 범위 안의 경우
	 if($land->[$sx][$sy] == $kind) {
		 $count++;
	 }
	 }
 }
 return $count;
}
# 범위 안의 지형을 수 가능
sub countAround {
 my($land, $x, $y, $kind, $range) = @_;
 my($i, $count, $sx, $sy);
 $count = 0;
 for($i = 0; $i < $range; $i++) {
	 $sx = $x + $ax[$i];
	 $sy = $y + $ay[$i];

	 # 행 기준 위치 조정
	 if((($sy % 2) == 0) && (($y % 2) == 1)) {
	 $sx--;
	 }

	 if(($sx < 0) || ($sx>= $HislandSize) ||
	 ($sy < 0) || ($sy>= $HislandSize)) {
	 # 범위 밖의 경우
	 if($kind == $HlandSea) {
		 # 바다이면 가 산
		 $count++;
	 }
	 } else {
	 # 범위 안의 경우
	 if($land->[$sx][$sy] == $kind) {
		 $count++;
	 }
	 }
 }
 return $count;
}

# 0에서(n - 1)까지의 숫자가한 번씩출해 옵니다 수열을 만들기
sub randomArray {
 my($n) = @_;
 my(@list, $i);

 # 초기 값
 if($n == 0) {
	$n = 1;
 }
 @list = (0..$n-1);

 # 셔터 전체
 for ($i = $n; --$i; ) {
	my($j) = int(rand($i+1));
	if($i == $j) { next; };
	@list[$i,$j] = @list[$j,$i];
 }

 return @list;
}

# 이름 변경실패
sub tempChangeNothing {
 out(<<END);
${HtagBig_}이름과 비밀번호가 모두 비어 있습니다${H_tagBig}$HtempBack
END
}

# 이름 변경 자금 부족
sub tempChangeNoMoney {
 out(<<END);
${HtagBig_} 자금 부족으로 변경할 수 없습니다${H_tagBig}$HtempBack
END
}

# 이름 변경성공
sub tempChange {
 out(<<END);
${HtagBig_}변경완료했습니다${H_tagBig}$HtempBack
END
}

# 실업자가에서 모
sub logUnemployedDemo {
 my($id, $name, $pop) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}로 구직 요청으로<B>$pop${HunitPop}</B>처리가 실행되었습니다.",$id);
}

# 실업자가폭동
sub logUnemployedRiot {
 my($id, $name, $lName, $pop, $point) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}로 구직 요청으로<B>$pop${HunitPop}</B>이 폭동을 일으키고${HtagName_}$point${H_tagName}지점의<B>$lName</B>에<B>쇄도</B>.<B>$lName</B>은 괴멸했습니다.",$id);
}

# 실업자가이민
sub logUnemployedMigrate {
 my($id, $tId, $name, $tName, $pop) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}에서 ${HtagName_}${tName} 섬${H_tagName}으로 구직 요청을 받아<B>$pop${HunitPop}</B>의 이민이도착했습니다.${HtagName_}${tName} 섬${H_tagName}은 살기 좋아진 것 같습니다.",$id, $tId);
}

# 관광객 방문
sub logKankouMigrate {
 my($id, $tId, $name, $lName, $tName, $point, $pop) = @_;
 logOut("${HtagName_}${tName} 섬${H_tagName}에서${HtagName_}${name} 섬 $point${H_tagName}의<B>$lName</B>로<B>$pop${HunitPop}</B>의 관광객이 찾아왔습니다. 활기가 느껴집니다.",$id, $tId);
}

# 실업자가이민
sub logUnemployedMigrate2 {
 my($id, $tId, $name, $tName, $pop) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}의 리조트 시설은 매력 부족으로,${HtagName_}${tName} 섬${H_tagName}으로 <B>$pop${HunitPop}</B>의 관광객이 이동했습니다.",$id, $tId);
}

# 실업자가이민
sub logUnemployedMigrate3 {
 my($id, $tId, $name, $tName, $pop) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}의 리조트 시설은 매력 부족으로,${HtagName_}${tName} 섬${H_tagName}으로 <B>$pop${HunitPop}</B>의 관광객이 돌아갔습니다. 참고하세요.",$id, $tId);
}

# 이민 처리
sub logUnemployedReturn {
 my($id, $tId, $name, $lName, $tName, $pop) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}에서 ${HtagName_}${tName} 섬${H_tagName}으로 구직 요청을 받아<B>$pop${HunitPop}</B>의 이민이도착했지만,${HtagName_}${tName} 섬${H_tagName}의<B>$lName</B>은 수용을 거부한 것 같습니다.",$id, $tId);
}

# 이민 처리
sub logUnemployedReturn2 {
 my($id, $tId, $name, $lName, $tName, $pop) = @_;
 logOut("${HtagName_}${name} 섬${H_tagName}에 몰려온<B>$pop${HunitPop}</B>의 관광객은${HtagName_}${tName} 섬${H_tagName}로 관광을 왔습니다. 그러나${HtagName_}${tName} 섬${H_tagName}의<B>$lName</B>은 수용을 거부한 것 같습니다.",$id, $tId);
}

1;
