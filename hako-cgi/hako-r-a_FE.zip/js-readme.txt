----------------------------------------------------------------------------
●JavaScript 판 하코니와 제도'앗포'Ver.1.00 ●
----------------------------------------------------------------------------
<배포사이트>

 원본 하코니와 제도 2
 http://t.pos.to/hako/
 (http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html)

 JavaScript 판 하코니와 제도'앗포'
 앗포 암자 하코니와 제도 -- http://appoh.execweb.cx/hakoniwa/

----------------------------------------------------------------------------
<제작자에 대해>

 hako-main.cgi hako-tum.cgi hako-top.cgi hako-map.cgi
 hako-mente.cgi hako-readme.txt
 도쿠오카 히로키 씨(tokuoka@taurus.bekkoame.ne.jp)

 hako-js.cgi 및 위 CGI 개조
 앗포 (caa95880@pop06.odn.ne.jp)

----------------------------------------------------------------------------
<이 스크립트의 특징>
서버 부담을 줄이기 위한 개조가 중심입니다.

●JavaScript 기반 일괄 전송 기능
 일괄 전송뿐 아니라, 입력한 명령을 이동해 순서를 변경할 수도 있습니다.

●관광 화면에서 다른 섬으로 이동
 관광 화면에 섬 선택 버튼이 있어 메인 페이지로 돌아가지 않아도 다른 섬으로 이동할 수 있습니다.

●의사 MAP 작성 도구용 데이터 자동 생성
 개발 화면에 들어가, 왼쪽의 '표시' 링크를 클릭하면 선택한 섬의
 의사 MAP 작성 도구용 데이터가 자동 생성됩니다.
 의사 MAP 작성 도구는, 제작자인 MKudo 님의 홈페이지에서 
 배포되어 있습니다.

●목표포착
 개발 화면에서 '표시' 링크를 클릭하고 공격 대상 섬의 MAP을 열고,
 좌표 입력을 보조합니다.( Watson 씨 제작)

●'매립 + 개간(또는 땅고르기)'
 '개간(또는 땅고르기)+나무 심기'명령 추가
 일반 개발 화면에서도 입력을 쉽게 할 수 있도록 '개간 자동 입력'이나
 '땅고르기 자동 입력' 외에 '자동 매립'
 '매립 + 개간(또는 땅고르기)'등을 추가했습니다.
 지정한 지점에'매립'과'개간(땅고르기)'명령을
 설정에 입력됩니다.

●'최근 사건'의 로그를 HTML 파일로 하고 표시
 갱신이 끝나면 자동으로 HTML 파일로 작성되어 표시됩니다.
 또한, 서버 문제 등으로 HTML 파일이 작성되지 않은 경우에도
 섬 이름 변경 화면에서 섬 이름에'로그'와 입력시, 특수 비밀번호를 입력하면
 HTML 파일이 작성됩니다.

----------------------------------------------------------------------------
<사용 조건>
 하코니와 제도 2 스크립트는 본인 책임하에 사용하는 한 기본적으로
 자유롭게 이용할 수 있습니다. 수정한 것을 재배포할 때는
 뒤에서 설명한 내용의 조건을 따라 주세요.

 자세한 내용은,hako-readme.txt 의 사용 조건을 따라 주세요.

----------------------------------------------------------------------------
 재배포 조건
이 스크립트를 개조하거나 재배포할 때는, 이하의 조건을 지켜 주세요.

 ·무료로 배포할 것
 ·hako-readme.txt 및 js-readme.txt 을 수정하지 않고 동봉할 것
 ·hako-readme.txt 에되어 있는 재배포 조건을 지킬 것
 ·재배포 조건으로 이 조건과 동일한 내용을 명시할 것.

위 내용의 조건을 지키기만 하면, 재배포는, 자유롭게 할 수 있습니다.

----------------------------------------------------------------------------

이미 설치된 하코니와에 적용할 경우, 아래처럼 개조해 주세요.


=============================
<hako-js.cgi>
지형을 추가하거나, 방위 시설을 숲로 하고 있는 경우,hako-map.cgi 와 동일,
hako-js.cgi 의
sub landStringJava 모 수정하지 않음으로 리않습니다.

----------------------------------
<hako-main.cgi>

# '돌아가기'링크
$HtempBack = "<A HREF=\"$HthisFile\">${HtagBig_}맨 위로 돌아가기${H_tagBig}</A>";
# 이하에추가
$Body = "<BODY $htmlBody>";

----------
# COOKIE 출력
cookieOutput();

# 헤더출력
tempHeader();
# ↑이것은 소하고하↓의를 추가
if($HmainMode eq 'owner' && $HjavaMode eq 'java' ||
 $HmainMode eq 'commandJava' || # 명령 입력 모드
 $HmainMode eq 'comment' && $HjavaMode eq 'java' || #코멘트입력 모드
 $HmainMode eq 'lbbs' && $HjavaMode eq 'java') { #코멘트입력 모드
	$Body = "<BODY onload=\"init()\" $htmlBody>";
 	require('hako-js.cgi');
 require('hako-map.cgi');
	# 헤더출력
	tempHeaderJava($bbs, $toppage,$imageDir);
	if($HmainMode eq 'commandJava') {
 	# 개발 모드
 	commandJavaMain();
	} elsif($HmainMode eq 'comment') {
 	# 코멘트입력 모드
 	commentMain();
	} elsif($HmainMode eq 'lbbs') {
	 # 로컬 게시판 모드
 	localBbsMain();
	}else{
	 ownerMain();
	}
	# 푸터출력
	tempFooter();
	# 종료
	exit(0);
}elsif($HmainMode eq 'landmap'){
 	require('hako-js.cgi');
 require('hako-map.cgi');
	$Body = "<BODY $htmlBody>";
	# 헤더출력
	tempHeaderJava($bbs, $toppage,$imageDir);
 # 관광 모드
 printIslandJava();
	# 푸터출력
	tempFooter();
	# 종료
	exit(0);
}else{
	# 헤더출력
	tempHeader();
}
----------
 # 메시지
 if($line =~ /MESSAGE=([^\&]*)\&/) {
	$Hmessage = cutColumn($1, 80);
 }

# 이하에아래의 를 추가
 # Java 스크립트 모드
	if($line =~ /JAVAMODE=(cgi|java)/) {
	$HjavaMode = $1;
	}

 if($line =~ /CommandJavaButton([0-9]+)=/) {
	# 명령 전송 버튼의 경우(Java 스크립트)
	$HcurrentID = $1;
	$defaultID = $1;
 }
----------
 } elsif($getLine =~ /Sight=([0-9]*)/) {
	$HmainMode = 'print';
	$HcurrentID = $1;
# 이하에아래의 를 추가
 } elsif($getLine =~ /IslandMap=([0-9]*)/) {
	$HmainMode = 'landmap';
	$HcurrentID = $1;
----------
 } elsif($line =~ /MessageButton([0-9]*)/) {
	$HmainMode = 'comment';
	$HcurrentID = $1;
# 이하에아래의 를 추가
 } elsif($line =~ /CommandJavaButton/) {
	$HmainMode = 'commandJava';
	$line =~ /COMARY=([^\&]*)\&/;
	$HcommandComary = $1;
----------
<BASE HREF="$imageDir/">
</HEAD>
<BODY $htmlBody>
<A HREF="http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html">하코니와 제도 스크립트 배포처</A><HR>

#이를 아래처럼 변경

<BASE HREF="$imageDir/">
</HEAD>
$Body
<A HREF="http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html">하코니와 제도 스크립트 배포처</A><HR>
----------

=============================
<hako-map.cgi>

 # 관광 화면
 tempPrintIslandHead(); # 수 있도록 말로!!
 islandInfo(); # 섬의 정보
 islandMap(0); # 섬의 지도, 관광 모드
#이를 추가
 islandJamp(); # 섬의 이동

----------
 # 개발 화면
 tempOwner(); # '개발계획'

#이것↑을소하고하↓처럼 변경

	if($HjavaMode eq 'java') {
	 tempOwnerJava(); # 'JavaScript 개발계획'
	}else{ # '일반 모드개발계획'
		tempOwner();
	}
----------
 # ○○섬 로컬 게시판
 if($HuseLbbs) {
	tempLbbsHead(); # 로컬 게시판
	tempLbbsInputOW(); # 작성 양식
	tempLbbsContents(); # 게시판내용
 }

#이것↑을하↓처럼 변경

 # ○○섬 로컬 게시판
 if($HuseLbbs) {
	tempLbbsHead(); # 로컬 게시판
		if($HjavaMode eq 'java') { # JavaScript 용작성 양식
			tempLbbsInputJava();
		}else{ tempLbbsInputOW(); } # 일반 모드의 작성 양식
	tempLbbsContents(); # 게시판내용
 }

----------
 out(<<END);
<CENTER>
<TABLE BORDER>
<TR>
<TD $HbgInputCell>
<CENTER>
<FORM action="$HthisFile" method=POST>
<INPUT TYPE=submit VALUE="계획 전송" NAME=CommandButton$Hislands[$HcurrentNumber]->{'id'}>

#이것↑을하↓처럼 변경

 out(<<END);
<CENTER>
<TABLE BORDER>
<TR valign=top>
<TD $HbgInputCell>
<CENTER>
<FORM name="myForm" action="$HthisFile" method=POST>
<INPUT TYPE=submit VALUE="계획 전송" NAME=CommandButton$Hislands[$HcurrentNumber]->{'id'}>
----------
 out(<<END);
</SELECT>
<HR>
<B>대상 섬</B><BR>
<SELECT NAME=TARGETID>

#이것↑을하↓처럼 변경

 out(<<END);
</SELECT>
<HR>
<B>대상 섬</B>:
<B><A HREF=JavaScript:void(0); onClick="jump(myForm)"> 표시 </A></B><BR>
<SELECT NAME=TARGETID>
----------

function ns(x) {
 document.forms[0].elements[2].options[x].selected = true;
 return true;
}

# 위 처리 다음 줄에 아래 코드를 추가.

function jump(theForm) {
 var sIndex = theForm.TARGETID.selectedIndex;
 var url = theForm.TARGETID.options[sIndex].value;
 if (url != "" ) window.open("$HthisFile?IslandMap=" +url,"", "menubar=yes,toolbar=no,location=no,directories=no,status=yes,scrollbars=yes,resizable=yes,width=450,height=630");
}

----------
hako-map.cgi 맨 아래에 아래 처리를 추가.


# 섬의 이동
sub islandJamp {
 $HtargetList = getIslandList($HcurrentID);
 out(<<END);
<CENTER>
<SCRIPT LANGUAGE="JavaScript">
function jump(theForm) {
 var sIndex = theForm.urlsel.selectedIndex;
 var url = theForm.urlsel.options[sIndex].value;
 if (url != "" ) location.href = "$HthisFile?Sight=" +url;
}
</SCRIPT>
<TABLE align=center border=0>
<TR><TD>
<FORM name="urlForm">
<SELECT NAME="urlsel">
$HtargetList<BR>
</SELECT>
</TD>
<TD><input type="button" value=" GO " onClick="jump(this.form)"></TD>
</TR></TABLE>
</form>
</CENTER>
END
}


=============================
<hako-top.cgi>

<H1>${HtagHeader_}자신의 섬으로${H_tagHeader}</H1>
<FORM action="$HthisFile" method="POST">
당신의 섬 이름은?<BR>
<SELECT NAME="ISLANDID">
$HislandList
</SELECT><BR>

비밀번호를 이용하세요!!<BR>
<INPUT TYPE="password" NAME="PASSWORD" VALUE="$HdefaultPassword" SIZE=32 MAXLENGTH=32><BR>
<INPUT TYPE="submit" VALUE="개발 화면으로" NAME="OwnerButton"><BR>
</FORM>

#이것↑을하↓처럼 변경

<H1>${HtagHeader_}자신의 섬으로${H_tagHeader}</H1>
<FORM name="Island" action="$HthisFile" method="POST">
당신의 섬 이름은?<BR>
<SELECT NAME="ISLANDID">
$HislandList
</SELECT><BR>
<Script Language="JavaScript">
<!--
function develope(){
	if(document.Island.CHBOX.checked)
		document.Island.target = "_blank";
	else
		document.Island.target = "";
		return true;
}
//-->
</Script>
비밀번호를 이용하세요!!<BR>
<INPUT TYPE="password" NAME="PASSWORD" VALUE="$HdefaultPassword" SIZE=32 MAXLENGTH=32><BR>
<INPUT TYPE="radio" NAME=JAVAMODE VALUE=cgi checked>일반 모드
<INPUT TYPE="radio" NAME=JAVAMODE VALUE=java>JavaScript 모드<BR>
<INPUT TYPE="submit" VALUE="개발 화면으로" NAME="OwnerButton" onClick="develope()">
<INPUT TYPE="checkbox" NAME="CHBOX" VALUE="on" $chbox>새 화면에서 개발
</FORM>


-----------------------------
<최근 사건의 HTML 출력>

hako-main.cgi 맨 아래에 아래 처리를 추가.

#----------------------------------------------------------------------
# HTML 생성
#----------------------------------------------------------------------
sub logPrintHtml {
	my($sec, $min, $hour, $date, $mon, $year, $day, $yday, $dummy) = localtime(time);
	$mon++;
	my($sss) = "${mon}월${date}일 ${hour} 때${min}분${sec}초";

	$html1=<<_HEADER_;
<HTML><HEAD>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
<TITLE>
최근 사건
</TITLE>
<BASE HREF="$imageDir/">
</HEAD>
<BODY $htmlBody>
<H1>${HtagHeader_}최근 사건${H_tagHeader}</H1>
<FORM>
최신갱신일:$sss..
<INPUT TYPE="button" VALUE=" 다시 읽기" onClick="location.reload()">
</FORM>
<hr>
_HEADER_

$html3=<<_HEADER_;
<HR>
</BODY>
</HTML>
_HEADER_
	my($i);
	for($i = 0; $i < $HtopLogTurn; $i++) {
		$id =0;
		$mode = 0;
		my($set_turn) = 0;
		open(LIN, "${HdirName}/hakojima.log$i");
		my($line, $m, $turn, $id1, $id2, $message);
		while($line = <LIN>) {
			$line =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),(.*)$/;
			($m, $turn, $id1, $id2, $message) = ($1, $2, $3, $4, $5);

			# 기밀관계
			if($m == 1) {
				if(($mode == 0) || ($id1 != $id)) {
				# 기밀 표시 권한 없음
				next;
				}
				$m = '<B>(기밀)</B>';
			} else {
				$m = '';
			}

			# 정확히 표시할지
			if($id != 0) {
				if(($id != $id1) &&	($id != $id2)) {
					next;
				}
			}

			# 표시
			if($set_turn == 0){
				$html2.= "<NOBR><B>=====[<FONT SIZE=4 COLOR=BLUE>턴$turn </FONT>]================================================</B><NOBR><BR>\n";
				$set_turn++;
			}
			$html2.= "<NOBR>${HtagNumber_}★${H_tagNumber}:$message</NOBR><BR>\n";
		}
		close(LIN);
	}
	open(HTML, ">hakolog.html");
	print HTML $html1;
	print HTML $html2;
	print HTML $html3;
	close (HTML);
	chmod(0666,"hakolog.html");
}
-----------------------------
hako-turn.cgi

 # 로그 쓰기
 logFlush();

 # 기록 로그 조정
 logHistoryTrim();

	# 최근 사건 HTML 출력 ←이를 추가
	logPrintHtml();

 # 맨 위로
 topPageMain();
-----------------------------

 # 비밀번호 확인
 if($HoldPassword eq $HspecialPassword) {
	# 특수 비밀번호
	$island->{'money'} = 9999;
	$island->{'food'} = 9999;
 } elsif(!checkPassword($island->{'password'},$HoldPassword)) {
	# password 오류
	unlock();
	tempWrongPassword();
	return;
 }

#이것↑을하↓처럼 변경

 # 비밀번호 확인
 if($HoldPassword eq $HspecialPassword) {
	# 특수 비밀번호
	if($HcurrentName =~ /^로그$/) {
	 # 최근 사건강제출력
		logPrintHtml();
		unlock();
 	tempChange();
	 return;
	}else {
	 # 식량/자금 max 모드
		#$island->{'money'} = 9999;
		#$island->{'food'} = 9999;
	}
 } elsif(!checkPassword($island->{'password'},$HoldPassword)) {
	# password 오류
	unlock();
	tempWrongPassword();
	return;
 }


=*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*=
ver1.1 로의 개조방법

상의 ver1.00 의개조가끝낸 후에, 아래의 개조를 진행하세요.
hako-js.cgi 은,ver1.1의 에바꿔 넣거나해서하세요.

<hako-main.cgi>
# 명령
$HcommandTotal = 33; # 명령 종류

#↑이하에, 이것↓을 추가

# 명령 분할
# 이 명령 분할만은, 자동 입력 명령은 설정하지 마세요.
@HcommandDivido =
	(
	'개발,0,10', # 계획번호00~10
	'건설,11,30', # 계획번호11~30
	'공격,31,40', # 계획번호31~40
	'운영,41,60' # 계획번호41~60
	);
# 주의:공백은 넣지 않도록
# ○→	'개발,0,10', # 계획번호00~10
# ×→	'개발, 0,10 ', # 계획번호00~10

-----------------------------
아래처럼 변경.
'ver1.1부터 추가'와 있음 부분(2곳)및 <BODY> 태그의 부분을 변경.

if($HmainMode eq 'owner' && $HjavaMode eq 'java' ||
 $HmainMode eq 'commandJava' || # 명령 입력 모드
 $HmainMode eq 'command2' || # 명령 입력 모드(ver1.1부터 추가·자동 입력용)
 $HmainMode eq 'comment' && $HjavaMode eq 'java' || #코멘트입력 모드
 $HmainMode eq 'lbbs' && $HjavaMode eq 'java') { #코멘트입력 모드
	$Body = "<BODY onload=\"SelectList('');init()\" $htmlBody>";
 	require('hako-js.cgi');
 require('hako-map.cgi');
	# 헤더출력
	tempHeaderJava($bbs, $toppage,$imageDir);
	if($HmainMode eq 'commandJava') {
 	# 개발 모드
 	commandJavaMain();
	} elsif($HmainMode eq 'command2') {
 	# 개발 모드2(자동 입력 명령용(ver1.1부터 추가))
	 commandMain();
	} elsif($HmainMode eq 'comment') {
 	# 코멘트입력 모드
 	commentMain();

-----------------------------
 # Java 스크립트 모드
	if($line =~ /JAVAMODE=(cgi|java)/) {
	$HjavaMode = $1;
	}

#↑이하에, 이것↓을 추가

	if($getLine =~ /JAVAMODE=(cgi|java)/) {
	$HjavaMode = $1;
	}
 # 명령의 팝업 메뉴를 열기?
	if($line =~ /MENUOPEN=([a-zA-Z]*[0-9]*)/) {
	$HmenuOpen = $1;
	}

-----------------------------

 } elsif($line =~ /CommandButton/) {
	$HmainMode = 'command';

	# 명령 모드의 경우, 명령의 가져오기
	$line =~ /NUMBER=([^\&]*)\&/;

# 이것 ↑을 아래처럼 변경

 } elsif($line =~ /CommandButton/) {
	if($HjavaMode eq 'java'){
	$HmainMode = 'command2';
	}else{
	$HmainMode = 'command';
	}

	# 명령 모드의 경우, 명령의 가져오기
	$line =~ /NUMBER=([^\&]*)\&/;

-----------------------------
 if($cookie =~ /${HthisFile}KIND=\(([^\)]*)\)/) {
	$HdefaultKind = $1;
 }

#이↑하에, 이것↓을 추가

 if($cookie =~ /${HthisFile}JAVAMODESET=\(([^\)]*)\)/) {
	$HjavaModeSet = $1;
 }
-----------------------------

 if($HcommandKind) {
	# 자동 입력 이외
	$cookie.= "Set-Cookie: ${HthisFile}KIND=($HcommandKind) $info";
 }

#↑이하에, 이것↓을 추가

 if($HjavaMode) {
	$cookie.= "Set-Cookie: ${HthisFile}JAVAMODESET=($HjavaMode) $info";
 }

=============================
<hako-top.cgi>


	# 다음 갱신 시간 표시
 my($now) = time;
 $aaa = $HislandLastTime + $HunitTime;
 my($sec, $min, $hour, $date, $mon, $year, $day, $yday, $dummy) = localtime(time);
	$mon++;
 my($sss) = "${mon}월 ${date}일 ${hour} 때 ${min}분 ${sec}초";
 my($sec2, $min2, $hour2, $date2, $mon2, $year2, $day2, $yday2, $dummy2) = localtime($aaa);
	$mon2++;
 my($bbb) = "${mon2}월${date2}일${hour2} 때${min2}분";

#↑이하에, 이것↓을 추가

 if ($HjavaModeSet eq 'java') {
		$radio = ""; $radio2 = "CHECKED";
	}else{
		$radio = "CHECKED";	$radio2 = "";
	}

-----------------------------
아래처럼 변경.


<H1>${HtagHeader_}자신의 섬으로${H_tagHeader}</H1>
<SCRIPT language="JavaScript">
<!--
function newdevelope(){
	newWindow = window.open("", "newWindow");
	document.Island.target = "newWindow";
	document.Island.submit();
}
function develope(){
	document.Island.target = "";
}
//-->
</SCRIPT>
<FORM name="Island" action="$HthisFile" method="POST">
당신의 섬 이름은?<BR>
<SELECT NAME="ISLANDID">
$HislandList
</SELECT><BR>
비밀번호를 이용하세요!!<BR>
<INPUT TYPE="hidden" NAME="OwnerButton">
<INPUT TYPE="password" NAME="PASSWORD" VALUE="$HdefaultPassword" SIZE=32 MAXLENGTH=32><BR>
<INPUT TYPE="radio" NAME=JAVAMODE VALUE=cgi $radio>일반 모드
<INPUT TYPE="radio" NAME=JAVAMODE VALUE=java $radio2>JavaScript 모드<BR>
<INPUT TYPE="submit" VALUE="개발 화면으로" onClick="develope()">
<INPUT TYPE="button" VALUE="새 화면" onClick="newdevelope()">
</FORM>

=============================
<hako-map.cgi>

function jump(theForm) {
 var sIndex = theForm.TARGETID.selectedIndex;
 var url = theForm.TARGETID.options[sIndex].value;
 if (url != "" ) window.open("$HthisFile?IslandMap=" +url,"", "menubar=yes,toolbar=no,location=no,directories=no,status=yes,scrollbars=yes,resizable=yes,width=450,height=630");
}

# 이것 ↑을 아래처럼 변경('j_mode' 기술을 두 군데에 추가)

function jump(theForm, j_mode) {
	var sIndex = theForm.TARGETID.selectedIndex;
	var url = theForm.TARGETID.options[sIndex].value;
	if (url != "" ) window.open("$HthisFile?IslandMap=" +url+"&JAVAMODE="+j_mode, "", "menubar=yes,toolbar=no,location=no,directories=no,status=yes,scrollbars=yes,resizable=yes,width=450,height=630");
}

-----------------------------

<B><A HREF=JavaScript:void(0); onClick="jump(myForm)"> 표시 </A></B><BR>

# 이것 ↑을 아래처럼 변경

<B><A HREF=JavaScript:void(0); onClick="jump(myForm, '$HjavaMode')"> 표시 </A></B><BR>


