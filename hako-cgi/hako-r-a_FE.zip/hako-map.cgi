#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}
#----------------------------------------------------------------------
# 하코니와 제도 ver2.30
# 지도 모드 모듈(ver1.00)
# 사용 조건, 사용 방법 등은,hako-readme.txt 파일을 참조
#
# 하코니와 제도의 페이지: http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html
#----------------------------------------------------------------------
#----------------------------------------------------------------------
# Hakoniwa R.A. ver1.11
# 메인스크립트(하코니와 제도 ver2.30)
# 사용 조건, 사용 방법 등은,read-renas.txt 파일을 참조
#
# KEI PAGE: http://www5b.biglobe.ne.jp/~k-e-i/
#----------------------------------------------------------------------


#----------------------------------------------------------------------
# JavaScript 개발 화면 전용 헤더
#----------------------------------------------------------------------
sub tempHeaderJava {
 # FE에서는 기존 공통 헤더를 사용하되, hakora451 JavaScript 모드에서 필요하던
 # 팝업 메뉴/명령 목록 CSS를 별도로 보강합니다. 이 CSS가 없으면 명령 팝업이
 # 투명한 일반 링크처럼 지도 위에 흩어져 보입니다.
 tempHeader();
 out(<<'END');
<STYLE TYPE="text/css">
<!--
.PopupCell {
 background-color: #E0FFFF;
 border: 1px solid #666666;
 padding: 3px;
 font-size: 12px;
 line-height: 1.35;
 z-index: 9999;
}
.PopupCell TD {
 background-color: #E0FFFF;
 vertical-align: top;
 white-space: nowrap;
}
.PopupCell A {
 white-space: nowrap;
}
.popupnavi {
 background-color: LAVENDER;
 overflow-y: auto;
 overflow-x: hidden;
 color: blue;
 font-weight: bold;
 border-style: none;
 margin: 1px 0px;
 white-space: normal;
 width: 170px;
 height: 34px;
}
.commandjs1 {
 border-width: 0px;
 color: blue;
 width: 100%;
 height: 100%;
 white-space: nowrap;
 background-color: LAVENDER;
}
.commandjs2 {
 border-width: 0px;
 color: red;
 width: 100%;
 height: 100%;
 white-space: nowrap;
 background-color: LAVENDER;
}
#menu {
 position: absolute;
 display: none;
 visibility: hidden;
 z-index: 9999;
 background-color: #E0FFFF;
 border: 1px solid #666666;
 padding: 3px;
}
#menu HR {
 margin: 2px 0;
}
#plan, #PARENT_LINKMSG, #LINKMSG1 {
 background-color: LAVENDER;
}
#LINKMSG1 {
 display: block;
 width: 230px;
 overflow: visible;
}
#LINKMSG1 A {
 white-space: nowrap;
}
#LINKMSG1 TABLE, #LINKMSG1 TD {
 background-color: LAVENDER;
}
-->
</STYLE>
END
}

#----------------------------------------------------------------------
# 관광 모드
#----------------------------------------------------------------------
# 메인
sub printIslandMain {
 # 개방
 unlock();

 # id 에서 섬 번호를 가져옴
 $HcurrentNumber = $HidToNumber{$HcurrentID};

 # 왠지그 섬이 없는 경우
 if($HcurrentNumber eq '') {
	tempProblem();
	return;
 }

 # 이름 가져오기
 $HcurrentName = $Hislands[$HcurrentNumber]->{'name'};

 # 관광 화면
 tempPrintIslandHead(); # 관광 화면!!
 islandInfo(); # 섬의 정보
 islandMap(0); # 섬 지도, 관광 모드

 # ○○섬 로컬 게시판
 if($HuseLbbs) {
	tempLbbsHead(); # 로컬 게시판
	tempLbbsInput(); # 작성 양식
	tempLbbsContents(); # 게시판내용
 }

 # 최근 상황
 tempRecent(0);
}

#----------------------------------------------------------------------
# 개발 모드
#----------------------------------------------------------------------
# 메인
sub ownerMain {
 # 개방
 unlock();

 # 모드를 명시
 $HmainMode = 'owner';

 # id 에서 섬을 가져옴
 $HcurrentNumber = $HidToNumber{$HcurrentID};
 my($island) = $Hislands[$HcurrentNumber];
 $HcurrentName = $island->{'name'};

 if(checkPassword($masterPassword,$HinputPassword)) {
	$HmainMode2 = 'ijiri';
 }

 # 비밀번호
 if(!checkPassword($island->{'password'},$HinputPassword)) {
	# password 오류
	tempWrongPassword();
	return;
 }

 # 개발 화면
 if($HjavaMode eq 'java') {
	tempOwnerJava(); # JavaScript 개발 계획
 } else {
	tempOwner(); # 일반 개발 계획
 }

 # ○○섬 로컬 게시판
 if($HuseLbbs) {
	tempLbbsHead(); # 로컬 게시판
	tempLbbsInputOW(); # 작성 양식
	tempLbbsContents(); # 게시판내용
 }

 # 최근 상황
 tempRecent(1);
}


#------------------------------------------------------------------
# JavaScript 모드 명령 일괄 입력
#------------------------------------------------------------------
sub commandJavaMain {
 # id 에서 섬을 가져옴
 $HcurrentNumber = $HidToNumber{$HcurrentID};
 my($island) = $Hislands[$HcurrentNumber];
 $HcurrentName = $island->{'name'};

 # 비밀번호
 if(!checkPassword($island->{'password'},$HinputPassword)) {
	unlock();
	tempWrongPassword();
	return;
 }

 my($command) = $island->{'command'};
 for(my $i = 0; $i < $HcommandMax; $i++) {
	if($HcommandComary =~ s/^\s*([0-9]+)\s+([0-9]+)\s+([0-9]+)\s+([0-9]+)\s+([0-9]+)\s*//) {
		my($kind, $x, $y, $arg, $target) = ($1, $2, $3, $4, $5);
		$kind = $HcomDoNothing if($kind == 0);
		$command->[$i] = {
			'kind' => $kind,
			'target' => $target,
			'x' => $x,
			'y' => $y,
			'arg' => $arg
		};
	}
 }
 tempCommandAdd();
 writeIslandsFile($HcurrentID);
 ownerMain();
}

#----------------------------------------------------------------------
# 명령 모드
#----------------------------------------------------------------------
# 메인
sub commandMain {
 # id 에서 섬을 가져옴
 $HcurrentNumber = $HidToNumber{$HcurrentID};
 my($island) = $Hislands[$HcurrentNumber];
 $HcurrentName = $island->{'name'};

 # 비밀번호
 if(!checkPassword($island->{'password'},$HinputPassword)) {
	# password 오류
	unlock();
	tempWrongPassword();
	return;
 }

 # 모드에서 분기
 my($command) = $island->{'command'};

 if($HcommandMode eq 'delete') {
	slideFront($command, $HcommandPlanNumber);
	tempCommandDelete();
 } elsif(($HcommandKind == $HcomAutoPrepare) ||
	 ($HcommandKind == $HcomAutoPrepare2)) {
	# 전체 개간, 전체 땅고르기
	# 좌표배열을 만들기
	makeRandomPointArray();
	my($land) = $island->{'land'};

	# 명령 종류결정
	my($kind) = $HcomPrepare;
	if($HcommandKind == $HcomAutoPrepare2) {
	 $kind = $HcomPrepare2;
	}

	my($i) = 0;
	my($j) = 0;
	while(($j < $HpointNumber) && ($i < $HcommandMax)) {
	 my($x) = $Hrpx[$j];
	 my($y) = $Hrpy[$j];
	 if($land->[$x][$y] == $HlandWaste) {
		slideBack($command, $HcommandPlanNumber);
		$command->[$HcommandPlanNumber] = {
		 'kind' => $kind,
		 'target' => 0,
		 'x' => $x,
		 'y' => $y,
		 'arg' => 0
		 };
		$i++;
	 }
	 $j++;
	}
	tempCommandAdd();
 } elsif($HcommandKind == $HcomAutoReclaim) {
 # 매립
 makeRandomPointArray();
 my($land) = $island->{'land'};
 my($landValue) = $island->{'landValue'};

 my($x, $y, $kind, $lv, $i, $n);
 $n = 0;
 for ($i = 0; ($i < $HpointNumber) && ($n < $HcommandMax); $i++) {
 $x = $Hrpx[$i];
 $y = $Hrpy[$i];
 $kind = $land->[$x][$y];
 $lv = $landValue->[$x][$y];

 if (($kind == $HlandSea) && ($lv == 1)) {
 # 얕은 바다
 slideBack($command, $HcommandPlanNumber);
 $command->[$HcommandPlanNumber] = {
 'kind' => $HcomReclaim, # 매립
 'target' => 0,
 'x' => $x,
 'y' => $y,
 'arg' => 0
 };
 $n++;
 }
 }
 tempCommandAdd();
 } elsif($HcommandKind == $HcomAutoDestroy) {
 # 굴착
 makeRandomPointArray();
 my($land) = $island->{'land'};
 my($landValue) = $island->{'landValue'};

 my($x, $y, $kind, $lv, $i, $n);
 $n = 0;
 for ($i = 0; ($i < $HpointNumber) && ($n < $HcommandMax); $i++) {
 $x = $Hrpx[$i];
 $y = $Hrpy[$i];
 $kind = $land->[$x][$y];
 $lv = $landValue->[$x][$y];

 if (($kind == $HlandSea) && ($lv == 1)) {
 # 얕은 바다
 slideBack($command, $HcommandPlanNumber);
 $command->[$HcommandPlanNumber] = {
 'kind' => $HcomDestroy, # 굴착
 'target' => 0,
 'x' => $x,
 'y' => $y,
 'arg' => 0
 };
 $n++;
 }
 }
 tempCommandAdd();
 } elsif($HcommandKind == $HcomAutoSellTree) {
 # 벌채
 # (수량×200그루보다 많은 숲만 대상)
 makeRandomPointArray();
 my($land) = $island->{'land'};
 my($landValue) = $island->{'landValue'};

 my($x, $y, $kind, $lv, $i, $n);
 $n = 0;
 for ($i = 0; ($i < $HpointNumber) && ($n < $HcommandMax - 1); $i++) {
 $x = $Hrpx[$i];
 $y = $Hrpy[$i];
 $kind = $land->[$x][$y];
 $lv = $landValue->[$x][$y];

 if (($kind == $HlandForest) && ($lv> $HcommandArg * 2)) {
 # 숲
 slideBack($command, $HcommandPlanNumber);
 $command->[$HcommandPlanNumber] = {
 'kind' => $HcomSellTree, # 벌채
 'target' => 0,
 'x' => $x,
 'y' => $y,
 'arg' => 0
 };
 $n += 2;
 }
 }
 tempCommandAdd();
 } elsif($HcommandKind == $HcomAutoForestry) {
 # 벌채와 나무 심기
 # (수량×200그루보다 많은 숲만 대상)
 makeRandomPointArray();
 my($land) = $island->{'land'};
 my($landValue) = $island->{'landValue'};

 my($x, $y, $kind, $lv, $i, $n);
 $n = 0;
 for ($i = 0; ($i < $HpointNumber) && ($n < $HcommandMax - 1); $i++) {
 $x = $Hrpx[$i];
 $y = $Hrpy[$i];
 $kind = $land->[$x][$y];
 $lv = $landValue->[$x][$y];

 if (($kind == $HlandForest) && ($lv> $HcommandArg * 2)) {
 # 숲
 slideBack($command, $HcommandPlanNumber);
 $command->[$HcommandPlanNumber] = {
 'kind' => $HcomPlant, # 나무 심기
 'target' => 0,
 'x' => $x,
 'y' => $y,
 'arg' => 0
 };
 slideBack($command, $HcommandPlanNumber);
 $command->[$HcommandPlanNumber] = {
 'kind' => $HcomSellTree, # 벌채
 'target' => 0,
 'x' => $x,
 'y' => $y,
 'arg' => 0
 };
 $n += 2;
 }
 }
 tempCommandAdd();
 } elsif($HcommandKind == $HcomAutoYoyaku) {
 # 개발 예정 계획 자동 입력
 makeRandomPointArray();
 my($land) = $island->{'land'};
 my($landValue) = $island->{'landValue'};

 my($x, $y, $kind, $lv, $i, $n);
 $n = 0;
 for ($i = 0; ($i < $HpointNumber) && ($n < $HcommandMax); $i++) {
 $x = $Hrpx[$i];
 $y = $Hrpy[$i];
 $kind = $land->[$x][$y];
 $lv = $landValue->[$x][$y];

 if ($kind == $HlandPlains) {
 slideBack($command, $HcommandPlanNumber);
 $command->[$HcommandPlanNumber] = {
 'kind' => $HcomYoyaku, # 매립
 'target' => 0,
 'x' => $x,
 'y' => $y,
 'arg' => 0
 };
 $n++;
 }
 }
 tempCommandAdd();
 } elsif($HcommandKind == $HcomAutoUchuste) {
 # 개발 예정 계획 자동 입력
	if(($HcommandArg>= $HcommandMax) ||
	 ($HcommandArg == 0)) {
	 $HcommandArg = 1;
	}
 my($i);
	for($i = 0; $i < $HcommandArg; $i++) {
 slideBack($command, $HcommandPlanNumber);
 $command->[$HcommandPlanNumber] = {
 'kind' => $HcomEiseimente, # 매립
 'target' => 0,
 'x' => $x,
 'y' => $y,
 'arg' => 99
 };
 }
 tempCommandAdd();
 } elsif($HcommandKind == $HcomAutoDelete) {
	# 전체 삭제
	my($i);
	for($i = 0; $i < $HcommandMax; $i++) {
	 slideFront($command, $HcommandPlanNumber);
	}
	tempCommandDelete();
 } elsif($HcommandKind == $HcomIjiri) {

	if($lamount2 == '') {
	 $lamount2 = 0;
	}

	if($lamount1 == -1) {
	 $eisei5 = $island->{'eisei5'};
	 $eisei5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	 ($mshp, $msap, $msdp, $mssp, $mswin, $msexe, $tetsub) = ($1, $2, $3, $4, $5, $6, $7);
	 $island->{'eisei5'} = "$mshp,$msap,$msdp,$mssp,$mswin,$lamount2,$tetsub";
	} elsif($lamount1 == -2) {
 $island->{'eis7'} = $lamount2*100+99;
	} elsif($lamount1 == -3) {
	 $island->{'totoyoso2'} = "$lamount2";
	} elsif($lamount1 == -4) {
	 $island->{'eis6'} = "$lamount2";
	} elsif($lamount1 == -5) {
	 $island->{'eis5'} = "$lamount2";
	} elsif($lamount1 == -6) {
	 $island->{'eis4'} = "$lamount2";
	} elsif($lamount1 == -7) {
	 $island->{'eis3'} = "$lamount2";
	} elsif($lamount1 == -8) {
	 $island->{'eis2'} = "$lamount2";
	} elsif($lamount1 == -9) {
	 $island->{'eis1'} = "$lamount2";
	} elsif($lamount1 == -10) {
	 $etc8 = $island->{'etc8'};
	 $etc8 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	 ($toto1, $toto2, $toto3, $toto4, $toto5, $toto6, $toto7) = ($1, $2, $3, $4, $5, $6, $7);
	 $island->{'etc8'} = "$toto1,$lamount2,$toto3,$toto4,$toto5,$toto6,$toto7";
	} elsif($lamount1 == -11) {
	 if($lamount2> 15) {
		$lamount2 = 15;
	 }
	 $eisei5 = $island->{'eisei5'};
	 $eisei5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	 ($mshp, $msap, $msdp, $mssp, $mswin, $msexe, $tetsub) = ($1, $2, $3, $4, $5, $6, $7);
	 $island->{'eisei5'} = "$lamount2,$msap,$msdp,$mssp,$mswin,$msexe,$tetsub";
	} elsif($lamount1 == -12) {
	 $eisei5 = $island->{'eisei5'};
	 $eisei5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	 ($mshp, $msap, $msdp, $mssp, $mswin, $msexe, $tetsub) = ($1, $2, $3, $4, $5, $6, $7);
	 $island->{'eisei5'} = "$mshp,$lamount2,$msdp,$mssp,$mswin,$msexe,$tetsub";
	} elsif($lamount1 == -13) {
	 $eisei5 = $island->{'eisei5'};
	 $eisei5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	 ($mshp, $msap, $msdp, $mssp, $mswin, $msexe, $tetsub) = ($1, $2, $3, $4, $5, $6, $7);
	 $island->{'eisei5'} = "$mshp,$msap,$lamount2,$mssp,$mswin,$msexe,$tetsub";
	} elsif($lamount1 == -14) {
	 $eisei5 = $island->{'eisei5'};
	 $eisei5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	 ($mshp, $msap, $msdp, $mssp, $mswin, $msexe, $tetsub) = ($1, $2, $3, $4, $5, $6, $7);
	 $island->{'eisei5'} = "$mshp,$msap,$msdp,$lamount2,$mswin,$msexe,$tetsub";
	} elsif($lamount1 == -15) {
	 if($lamount2> 30) {
		$lamount2 = 30;
	 }
	 if($lamount2 == 24) {
		$lamount2 = 7;
	 }
	 if($lamount2 == 25) {
		$lamount2 = 7;
	 }
	 if($lamount2 == 26) {
		$lamount2 = 7;
	 }
	 if($lamount2 == 27) {
		$lamount2 = 7;
	 }
	 $etc6 = $island->{'etc6'};
	 $etc6 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	 ($z0,$z1,$z2,$z3,$z4,$z5,$z6,$z7,$z8,$z9,$z10,$z11,$z12,$z13,$z14,$z15,$z16,$z17,$z18,$z19,$z20,$z21,$z22,$z23,$z24,$z25,$z26,$z27,$z28,$z29,$z30) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);
	 ($z->{'0'},$z->{'1'},$z->{'2'},$z->{'3'},$z->{'4'},$z->{'5'},$z->{'6'},$z->{'7'},$z->{'8'},$z->{'9'},$z->{'10'},$z->{'11'},$z->{'12'},$z->{'13'},$z->{'14'},$z->{'15'},$z->{'16'},$z->{'17'},$z->{'18'},$z->{'19'},$z->{'20'},$z->{'21'},$z->{'22'},$z->{'23'},$z->{'24'},$z->{'25'},$z->{'26'},$z->{'27'},$z->{'28'},$z->{'29'},$z->{'30'}) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);
	 if($HcommandArg == 1) {
		for($y2 = 0; $y2 < 24; $y2++) {
		 $z->{"$y2"}++;
		}
		for($y2 = 28; $y2 < 31; $y2++) {
		 $z->{"$y2"}++;
		}
		$island->{'etc6'} = "$z->{'0'},$z->{'1'},$z->{'2'},$z->{'3'},$z->{'4'},$z->{'5'},$z->{'6'},$z->{'7'},$z->{'8'},$z->{'9'},$z->{'10'},$z->{'11'},$z->{'12'},$z->{'13'},$z->{'14'},$z->{'15'},$z->{'16'},$z->{'17'},$z->{'18'},$z->{'19'},$z->{'20'},$z->{'21'},$z->{'22'},$z->{'23'},$z->{'24'},$z->{'25'},$z->{'26'},$z->{'27'},$z->{'28'},$z->{'29'},$z->{'30'}";
	 } elsif($HcommandArg> 1) {
		$z->{"$lamount2"} += $HcommandArg;
		$island->{'etc6'} = "$z->{'0'},$z->{'1'},$z->{'2'},$z->{'3'},$z->{'4'},$z->{'5'},$z->{'6'},$z->{'7'},$z->{'8'},$z->{'9'},$z->{'10'},$z->{'11'},$z->{'12'},$z->{'13'},$z->{'14'},$z->{'15'},$z->{'16'},$z->{'17'},$z->{'18'},$z->{'19'},$z->{'20'},$z->{'21'},$z->{'22'},$z->{'23'},$z->{'24'},$z->{'25'},$z->{'26'},$z->{'27'},$z->{'28'},$z->{'29'},$z->{'30'}";
	 } else {
		$z->{"$lamount2"}++;
		$island->{'etc6'} = "$z->{'0'},$z->{'1'},$z->{'2'},$z->{'3'},$z->{'4'},$z->{'5'},$z->{'6'},$z->{'7'},$z->{'8'},$z->{'9'},$z->{'10'},$z->{'11'},$z->{'12'},$z->{'13'},$z->{'14'},$z->{'15'},$z->{'16'},$z->{'17'},$z->{'18'},$z->{'19'},$z->{'20'},$z->{'21'},$z->{'22'},$z->{'23'},$z->{'24'},$z->{'25'},$z->{'26'},$z->{'27'},$z->{'28'},$z->{'29'},$z->{'30'}";
	 }
	} elsif($lamount1 == -16) {
	 my($sto, $std, $stk, $stwin, $stdrow, $stlose, $stwint, $stdrowt, $stloset, $styusho, $stshoka) = (0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
	 $eisei4 = $island->{'eisei4'};
	 $eisei4 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	 ($sto, $std, $stk, $stwin, $stdrow, $stlose, $stwint, $stdrowt, $stloset, $styusho, $stshoka) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11);
	 if($stshoka == 0) {
		$stshoka = 16;
 }
	 $island->{'eisei4'} = "$lamount2,$std,$stk,$stwin,$stdrow,$stlose,$stwint,$stdrowt,$stloset,$styusho,$stshoka";
	} elsif($lamount1 == -17) {
	 my($sto, $std, $stk, $stwin, $stdrow, $stlose, $stwint, $stdrowt, $stloset, $styusho, $stshoka) = (0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
	 $eisei4 = $island->{'eisei4'};
	 $eisei4 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	 ($sto, $std, $stk, $stwin, $stdrow, $stlose, $stwint, $stdrowt, $stloset, $styusho, $stshoka) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11);
	 if($stshoka == 0) {
		$stshoka = 16;
 }
	 $island->{'eisei4'} = "$sto,$lamount2,$stk,$stwin,$stdrow,$stlose,$stwint,$stdrowt,$stloset,$styusho,$stshoka";
	} elsif($lamount1 == -18) {
	 my($sto, $std, $stk, $stwin, $stdrow, $stlose, $stwint, $stdrowt, $stloset, $styusho, $stshoka) = (0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
	 $eisei4 = $island->{'eisei4'};
	 $eisei4 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	 ($sto, $std, $stk, $stwin, $stdrow, $stlose, $stwint, $stdrowt, $stloset, $styusho, $stshoka) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11);
	 if($stshoka == 0) {
		$stshoka = 16;
 }
	 $island->{'eisei4'} = "$sto,$std,$lamount2,$stwin,$stdrow,$stlose,$stwint,$stdrowt,$stloset,$styusho,$stshoka";
	} else {
	 my($land) = $island->{'land'};
	 my($landValue) = $island->{'landValue'};
	 if($lamount2> 4000) {
		$lamount2 = 4000;
	 }
	 if($HcommandArg == 1) {
		for($y = 0; $y < $HislandSize; $y++) {
		 for($x = 0; $x < $HislandSize; $x++) {
			$land->[$x][$y] = $lamount1;
			$landValue->[$x][$y] = $lamount2;
		 }
		}
	 } else {
		$land->[$HcommandX][$HcommandY] = $lamount1;
		$landValue->[$HcommandX][$HcommandY] = $lamount2;
	 }
	}
 } else {
	if($HcommandMode eq 'insert') {
	 slideBack($command, $HcommandPlanNumber);
	}
	tempCommandAdd();
	# 명령을 등록
	$command->[$HcommandPlanNumber] = {
	 'kind' => $HcommandKind,
	 'target' => $HcommandTarget,
	 'x' => $HcommandX,
	 'y' => $HcommandY,
	 'arg' => $HcommandArg
	 };
 }

 # IP 등록되어 있지 않은 경우, 이때 건너뜀
	$speaker = $ENV{'REMOTE_HOST'};
	$speaker = $ENV{'REMOTE_ADDR'} if ($speaker eq '');

 if($island->{'ip0'} eq '0') {
	# IP 취득
	$island->{'ip0'} = "$speaker";
	$island->{'ip1'} = "$speaker";
	$island->{'ip2'} = "$speaker";
	$island->{'ip3'} = "$speaker";
	$island->{'ip4'} = "$speaker";
	$island->{'ip5'} = "$speaker";
	$island->{'ip6'} = 0;
	$island->{'ip7'} = 0;
	$island->{'ip8'} = 0;
	$island->{'ip9'} = 0;
 }
 if($island->{'ip0'} eq '') {
	# IP 취득
	$island->{'ip0'} = "$speaker";
	$island->{'ip1'} = "$speaker";
	$island->{'ip2'} = "$speaker";
	$island->{'ip3'} = "$speaker";
	$island->{'ip4'} = "$speaker";
	$island->{'ip5'} = "$speaker";
	$island->{'ip6'} = 0;
	$island->{'ip7'} = 0;
	$island->{'ip8'} = 0;
	$island->{'ip9'} = 0;
 }

 if($island->{'ip5'} != "$speaker") {
	# IP 취득
	$island->{'ip1'} = $island->{'ip2'};
	$island->{'ip2'} = $island->{'ip3'};
	$island->{'ip3'} = $island->{'ip4'};
	$island->{'ip4'} = $island->{'ip5'};
	$island->{'ip5'} = "$speaker";
	$island->{'ip6'} = 0;
	$island->{'ip7'} = 0;
	$island->{'ip8'}++;
	$island->{'ip9'}++;
 }

 # 데이터 쓰기
 writeIslandsFile($HcurrentID);

 # owner mode 로
 ownerMain();

}

#----------------------------------------------------------------------
# 코멘트입력 모드
#----------------------------------------------------------------------
# 메인
sub commentMain {
 # id 에서 섬을 가져옴
 $HcurrentNumber = $HidToNumber{$HcurrentID};
 my($island) = $Hislands[$HcurrentNumber];
 $HcurrentName = $island->{'name'};

 # 비밀번호
 if(!checkPassword($island->{'password'},$HinputPassword)) {
	# password 오류
	unlock();
	tempWrongPassword();
	return;
 }

 # 메시지를 갱신
 $island->{'comment'} = htmlEscape($Hmessage);

 # 데이터 쓰기
 writeIslandsFile($HcurrentID);

 # 코멘트갱신 메시지
 tempComment();

 # owner mode 로
 ownerMain();
}

#----------------------------------------------------------------------
# toto 입력 모드
#----------------------------------------------------------------------
# 메인
sub totoMain {
 # id 에서 섬을 가져옴
 $HcurrentNumber = $HidToNumber{$HcurrentID};
 my($island) = $Hislands[$HcurrentNumber];
 $HcurrentName = $island->{'name'};

 foreach $i (76..99) {
 if(($HislandTurn % 100) == $i) {
	unlock();
	tempTotoend();
	return;
 }
 }

 foreach $i (26..49) {
 if(($HislandTurn % 100) == $i) {
	unlock();
	tempTotoend();
	return;
 }
 }

 # 비밀번호
 if(!checkPassword($island->{'password'},$HinputPassword)) {
	# password 오류
	unlock();
	tempWrongPassword();
	return;
 }

 # 메시지를 갱신
 $island->{'eis8'} = htmlEscape($HyosoMessage);

 # 데이터 쓰기
 writeIslandsFile($HcurrentID);

 # 코멘트갱신 메시지
 tempToto();

 # owner mode 로
 ownerMain();
}

#----------------------------------------------------------------------
# totos 입력 모드
#----------------------------------------------------------------------
# 메인
sub totosMain {
 # id 에서 섬을 가져옴
 $HcurrentNumber = $HidToNumber{$HcurrentID};
 my($island) = $Hislands[$HcurrentNumber];
 $HcurrentName = $island->{'name'};

 # 비밀번호
 if(!checkPassword($island->{'password'},$HinputPassword)) {
	# password 오류
	unlock();
	tempWrongPassword();
	return;
 }

 # 메시지를 갱신
 $island->{'totoyoso2'} = htmlEscape($HshutoMessage);

 # 데이터 쓰기
 writeIslandsFile($HcurrentID);

 # 코멘트갱신 메시지
 tempToto2();

 # owner mode 로
 ownerMain();
}
#----------------------------------------------------------------------
# 정책입력 모드
#----------------------------------------------------------------------
# 메인
sub shoueneMain {
 # id 에서 섬을 가져옴
 $HcurrentNumber = $HidToNumber{$HcurrentID};
 my($island) = $Hislands[$HcurrentNumber];
 $HcurrentName = $island->{'name'};

 # 비밀번호
 if(!checkPassword($island->{'password'},$HinputPassword)) {
	# password 오류
	unlock();
	tempWrongPassword();
	return;
 }

 if($island->{'etc5'} == 0) {
	$island->{'etc5'} = '0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0';
 }

 if($HcommandArg> 50) {
	$HcommandArg = 50;
 }

 # 메시지를 갱신
 $etc5 = $island->{'etc5'};
 $etc5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
 ($s00,$s01,$s02,$s03,$s04,$s05,$s06,$s07,$s08,$s09,$s10,$s11,$s12,$s13,$s14,$s15,$s16,$s17,$s18,$s19,$s20,$s21,$s22,$s23,$s24,$s25,$s26,$s27,$s28,$s29,$s30) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);

 $island->{'etc5'} = "$s00,$HcommandArg,$s02,$s03,$s04,$s05,$s06,$s07,$s08,$s09,$s10,$s11,$s12,$s13,$s14,$s15,$s16,$s17,$s18,$s19,$s20,$s21,$s22,$s23,$s24,$s25,$s26,$s27,$s28,$s29,$s30";

 # 데이터 쓰기
 writeIslandsFile($HcurrentID);

 # 코멘트갱신 메시지
 tempToto2();

 # owner mode 로
 ownerMain();
}
sub bousaiMain {
 # id 에서 섬을 가져옴
 $HcurrentNumber = $HidToNumber{$HcurrentID};
 my($island) = $Hislands[$HcurrentNumber];
 $HcurrentName = $island->{'name'};

 # 비밀번호
 if(!checkPassword($island->{'password'},$HinputPassword)) {
	# password 오류
	unlock();
	tempWrongPassword();
	return;
 }

 if($island->{'etc5'} == 0) {
	$island->{'etc5'} = '0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0';
 }

 if($HcommandArg> 50) {
	$HcommandArg = 50;
 }

 # 메시지를 갱신
 $etc5 = $island->{'etc5'};
 $etc5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
 ($s00,$s01,$s02,$s03,$s04,$s05,$s06,$s07,$s08,$s09,$s10,$s11,$s12,$s13,$s14,$s15,$s16,$s17,$s18,$s19,$s20,$s21,$s22,$s23,$s24,$s25,$s26,$s27,$s28,$s29,$s30) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);

 $island->{'etc5'} = "$s00,$s01,$s02,$HcommandArg,$s04,$s05,$s06,$s07,$s08,$s09,$s10,$s11,$s12,$s13,$s14,$s15,$s16,$s17,$s18,$s19,$s20,$s21,$s22,$s23,$s24,$s25,$s26,$s27,$s28,$s29,$s30";

 # 데이터 쓰기
 writeIslandsFile($HcurrentID);

 # 코멘트갱신 메시지
 tempToto2();

 # owner mode 로
 ownerMain();
}
sub kankouMain {
 # id 에서 섬을 가져옴
 $HcurrentNumber = $HidToNumber{$HcurrentID};
 my($island) = $Hislands[$HcurrentNumber];
 $HcurrentName = $island->{'name'};

 # 비밀번호
 if(!checkPassword($island->{'password'},$HinputPassword)) {
	# password 오류
	unlock();
	tempWrongPassword();
	return;
 }

 if($island->{'etc5'} == 0) {
	$island->{'etc5'} = '0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0';
 }

 if($HcommandArg> 50) {
	$HcommandArg = 50;
 }

 # 메시지를 갱신
 $etc5 = $island->{'etc5'};
 $etc5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
 ($s00,$s01,$s02,$s03,$s04,$s05,$s06,$s07,$s08,$s09,$s10,$s11,$s12,$s13,$s14,$s15,$s16,$s17,$s18,$s19,$s20,$s21,$s22,$s23,$s24,$s25,$s26,$s27,$s28,$s29,$s30) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);

 $island->{'etc5'} = "$s00,$s01,$s02,$s03,$s04,$HcommandArg,$s06,$s07,$s08,$s09,$s10,$s11,$s12,$s13,$s14,$s15,$s16,$s17,$s18,$s19,$s20,$s21,$s22,$s23,$s24,$s25,$s26,$s27,$s28,$s29,$s30";

 # 데이터 쓰기
 writeIslandsFile($HcurrentID);

 # 코멘트갱신 메시지
 tempToto2();

 # owner mode 로
 ownerMain();
}
sub sizenMain {
 # id 에서 섬을 가져옴
 $HcurrentNumber = $HidToNumber{$HcurrentID};
 my($island) = $Hislands[$HcurrentNumber];
 $HcurrentName = $island->{'name'};

 # 비밀번호
 if(!checkPassword($island->{'password'},$HinputPassword)) {
	# password 오류
	unlock();
	tempWrongPassword();
	return;
 }

 if($island->{'etc5'} == 0) {
	$island->{'etc5'} = '0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0';
 }

 if($HcommandArg> 50) {
	$HcommandArg = 50;
 }

 # 메시지를 갱신
 $etc5 = $island->{'etc5'};
 $etc5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
 ($s00,$s01,$s02,$s03,$s04,$s05,$s06,$s07,$s08,$s09,$s10,$s11,$s12,$s13,$s14,$s15,$s16,$s17,$s18,$s19,$s20,$s21,$s22,$s23,$s24,$s25,$s26,$s27,$s28,$s29,$s30) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);

 $island->{'etc5'} = "$s00,$s01,$s02,$s03,$s04,$s05,$s06,$HcommandArg,$s08,$s09,$s10,$s11,$s12,$s13,$s14,$s15,$s16,$s17,$s18,$s19,$s20,$s21,$s22,$s23,$s24,$s25,$s26,$s27,$s28,$s29,$s30";

 # 데이터 쓰기
 writeIslandsFile($HcurrentID);

 # 코멘트갱신 메시지
 tempToto2();

 # owner mode 로
 ownerMain();
}
sub kyouikuMain {
 # id 에서 섬을 가져옴
 $HcurrentNumber = $HidToNumber{$HcurrentID};
 my($island) = $Hislands[$HcurrentNumber];
 $HcurrentName = $island->{'name'};

 # 비밀번호
 if(!checkPassword($island->{'password'},$HinputPassword)) {
	# password 오류
	unlock();
	tempWrongPassword();
	return;
 }

 if($island->{'etc5'} == 0) {
	$island->{'etc5'} = '0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0';
 }

 if($HcommandArg> 50) {
	$HcommandArg = 50;
 }

 # 메시지를 갱신
 $etc5 = $island->{'etc5'};
 $etc5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
 ($s00,$s01,$s02,$s03,$s04,$s05,$s06,$s07,$s08,$s09,$s10,$s11,$s12,$s13,$s14,$s15,$s16,$s17,$s18,$s19,$s20,$s21,$s22,$s23,$s24,$s25,$s26,$s27,$s28,$s29,$s30) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);

 $island->{'etc5'} = "$s00,$s01,$s02,$s03,$s04,$s05,$s06,$s07,$s08,$HcommandArg,$s10,$s11,$s12,$s13,$s14,$s15,$s16,$s17,$s18,$s19,$s20,$s21,$s22,$s23,$s24,$s25,$s26,$s27,$s28,$s29,$s30";

 # 데이터 쓰기
 writeIslandsFile($HcurrentID);

 # 코멘트갱신 메시지
 tempToto2();

 # owner mode 로
 ownerMain();
}
sub chochikuMain {
 # id 에서 섬을 가져옴
 $HcurrentNumber = $HidToNumber{$HcurrentID};
 my($island) = $Hislands[$HcurrentNumber];
 $HcurrentName = $island->{'name'};

 # 비밀번호
 if(!checkPassword($island->{'password'},$HinputPassword)) {
	# password 오류
	unlock();
	tempWrongPassword();
	return;
 }

 if($island->{'etc5'} == 0) {
	$island->{'etc5'} = '0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0';
 }

 if($HcommandArg> 50) {
	$HcommandArg = 50;
 }

 # 메시지를 갱신
 $etc5 = $island->{'etc5'};
 $etc5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
 ($s00,$s01,$s02,$s03,$s04,$s05,$s06,$s07,$s08,$s09,$s10,$s11,$s12,$s13,$s14,$s15,$s16,$s17,$s18,$s19,$s20,$s21,$s22,$s23,$s24,$s25,$s26,$s27,$s28,$s29,$s30) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);

 $island->{'etc5'} = "$s00,$s01,$s02,$s03,$s04,$s05,$s06,$s07,$s08,$s09,$s10,$HcommandArg,$s12,$s13,$s14,$s15,$s16,$s17,$s18,$s19,$s20,$s21,$s22,$s23,$s24,$s25,$s26,$s27,$s28,$s29,$s30";

 # 데이터 쓰기
 writeIslandsFile($HcurrentID);

 # 코멘트갱신 메시지
 tempToto2();

 # owner mode 로
 ownerMain();
}

#----------------------------------------------------------------------
# 옥션입력 모드
#----------------------------------------------------------------------

sub auctionMain {
 # id 에서 섬을 가져옴
 $HcurrentNumber = $HidToNumber{$HcurrentID};
 my($island) = $Hislands[$HcurrentNumber];
 $HcurrentName = $island->{'name'};

 # 비밀번호
 if(!checkPassword($island->{'password'},$HinputPassword)) {
	# password 오류
	unlock();
	tempWrongPassword();
	return;
 }

 if($HAucNumber == 1) {

	if(($island->{'auc2'} != 0) || ($island->{'auc3'} != 0)) {
		unlock();
		tempNoMoney3();
		return;
	}

	 $auction1 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	 ($shuppin1, $avalue1, $ajoutai1, $topvalue1, $topid1) = ($1, $2, $3, $4, $5);

	 if(($island->{'auc1'} == $topvalue1) && ($topvalue1 != 0)) {
		unlock();
		tempNoMoney2();
		return;
	 }

	 if($ajoutai1 == 15) {
		unlock();
		tempNoMoney4();
		return;
	 }

	 $topvalue1 += $HcommandArg;

	 $auc9 = $island->{'auc9'};
	 $auc9 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	 ($auc9a, $auc9b, $auc9c, $auc9d, $auc9e) = ($1, $2, $3, $4, $5);
	 $auc9c3 = int($auc9c/10000)*10000;

	 if($island->{'money'} + $island->{'pika'} + $auc9a*10000 < $topvalue1*10000) {
		unlock();
		tempNoMoney();
		return;
	 }

	 $auction1 = "$shuppin1,$avalue1,0,$topvalue1,$topid1";
	 $island->{'auc1'} = $topvalue1;

	 if((($HislandTurn % $HturnPrizeUnit)> 89) && (random(100) < 3)) {
		$ajoutai1 = 15;
		$auction1 = "$shuppin1,$avalue1,$ajoutai1,$topvalue1,$topid1";
	 }

	 # 데이터 쓰기
	 writeIslandsFile($HcurrentID);

	 # 코멘트갱신 메시지
	 tempToto3();

	 # owner mode 로
	 ownerMain();

 }

 elsif($HAucNumber == 2) {

	if(($island->{'auc1'} != 0) || ($island->{'auc3'} != 0)) {
		unlock();
		tempNoMoney3();
		return;
	}

	 $auction2 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	 ($shuppin2, $avalue2, $ajoutai2, $topvalue2, $topid2) = ($1, $2, $3, $4, $5);

	 if(($island->{'auc2'} == $topvalue2) && ($topvalue2 != 0)) {
		unlock();
		tempNoMoney2();
		return;
	 }

	 if($ajoutai2 == 15) {
		unlock();
		tempNoMoney4();
		return;
	 }

	 $topvalue2 += $HcommandArg;

	 $auc9 = $island->{'auc9'};
	 $auc9 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	 ($auc9a, $auc9b, $auc9c, $auc9d, $auc9e) = ($1, $2, $3, $4, $5);
	 $auc9c3 = int($auc9c/10000)*10000;

	 if($island->{'money'} + $island->{'pika'} + $auc9a*10000 < $topvalue2*10000) {
		unlock();
		tempNoMoney();
		return;
	 }

	 $auction2 = "$shuppin2,$avalue2,0,$topvalue2,$topid2";
	 $island->{'auc2'} = $topvalue2;

	 if((($HislandTurn % $HturnPrizeUnit)> 89) && (random(100) < 3)) {
		$ajoutai2 = 15;
		$auction2 = "$shuppin2,$avalue2,$ajoutai2,$topvalue2,$topid2";
	 }

	 # 데이터 쓰기
	 writeIslandsFile($HcurrentID);

	 # 코멘트갱신 메시지
	 tempToto3();

	 # owner mode 로
	 ownerMain();

 }

 elsif($HAucNumber == 3) {

	if(($island->{'auc1'} != 0) || ($island->{'auc2'} != 0)) {
		unlock();
		tempNoMoney3();
		return;
	}

	 $auction3 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	 ($shuppin3, $avalue3, $ajoutai3, $topvalue3, $topid3) = ($1, $2, $3, $4, $5);

	 if(($island->{'auc3'} == $topvalue3) && ($topvalue3 != 0)) {
		unlock();
		tempNoMoney2();
		return;
	 }

	 if($ajoutai3 == 15) {
		unlock();
		tempNoMoney4();
		return;
	 }

	 $topvalue3 += $HcommandArg;

	 $auc9 = $island->{'auc9'};
	 $auc9 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	 ($auc9a, $auc9b, $auc9c, $auc9d, $auc9e) = ($1, $2, $3, $4, $5);
	 $auc9c3 = int($auc9c/10000)*10000;

	 if($island->{'money'} + $island->{'pika'} + $auc9a*10000 < $topvalue3*10000) {
		unlock();
		tempNoMoney();
		return;
	 }

	 $auction3 = "$shuppin3,$avalue3,0,$topvalue3,$topid3";
	 $island->{'auc3'} = $topvalue3;

	 if((($HislandTurn % $HturnPrizeUnit)> 89) && (random(100) < 3)) {
		$ajoutai3 = 15;
		$auction3 = "$shuppin3,$avalue3,$ajoutai3,$topvalue3,$topid3";
	 }

	 # 데이터 쓰기
	 writeIslandsFile($HcurrentID);

	 # 코멘트갱신 메시지
	 tempToto3();

	 # owner mode 로
	 ownerMain();

 }

}

#----------------------------------------------------------------------
# mskyoka 입력 모드
#----------------------------------------------------------------------
# 메인
sub msMain {
 # id 에서 섬을 가져옴
 $HcurrentNumber = $HidToNumber{$HcurrentID};
 my($island) = $Hislands[$HcurrentNumber];
 $HcurrentName = $island->{'name'};

 # 비밀번호
 if(!checkPassword($island->{'password'},$HinputPassword)) {
	# password 오류
	unlock();
	tempWrongPassword();
	return;
 }

 # 메시지를 갱신
 $island->{'etc7'} = "1,$HcommandArg,$HcommandTarget";

 if ($HcommandArg == 0) {
	$island->{'etc7'} = '0,0,0';
 }

 # 데이터 쓰기
 writeIslandsFile($HcurrentID);

 # 코멘트갱신 메시지
 tempMs();

 # owner mode 로
 ownerMain();
}

#----------------------------------------------------------------------
# ms2kyoka 입력 모드
#----------------------------------------------------------------------
# 메인
sub ms2Main {
 # id 에서 섬을 가져옴
 $HcurrentNumber = $HidToNumber{$HcommandTarget};
 my($island) = $Hislands[$HcurrentNumber];
 $HcurrentName = $island->{'name'};

 $etc7 = $island->{'etc7'};
 $etc7 =~ /^([0-9]*),([0-9]*),([0-9]*)$/;
 ($msjotai, $nokotan, $msid) = ($1, $2, $3);

 if ($msjotai == 1) {
 $island->{'etc7'} = "2,$HcommandArg,$HcurrentID";

 # 데이터 쓰기
 writeIslandsFile($HcurrentID);

 # 코멘트갱신 메시지
 tempMs();

 }

 # owner mode 로
 ownerMain();

}

#----------------------------------------------------------------------
# 로컬 게시판 모드
#----------------------------------------------------------------------
# 메인

sub localBbsMain {
 # id 에서 섬 번호를 가져옴
 $HcurrentNumber = $HidToNumber{$HcurrentID};
 my($island) = $Hislands[$HcurrentNumber];
 my($speaker) = "0<";


 # 왠지그 섬이 없는 경우
 if($HcurrentNumber eq '') {
	unlock();
	tempProblem();
	return;
 }

 # 삭제 모드가 아니고 이름이나 메시지가 없는 경우
 if($HlbbsMode != 2) {
	if(($HlbbsName eq '') || ($HlbbsName eq '')) {
	 unlock();
	 tempLbbsNoMessage();
	 return;
	}
 }

 # 관광객 모드입니다없을 때는 비밀번호 확인
 if($HlbbsMode != 0) {
	if(!checkPassword($island->{'password'},$HinputPassword)) {
	 # password 오류
	 unlock();
	 tempWrongPassword();
	 return;
	}
 }

 elsif ($HlbbsMode == 0) {
 # 관광객 모드
 my($island);

 if ($HlbbsType ne 'ANON') {
 # 공개와 극비

 # id 에서 섬 번호를 가져옴
 my($number) = $HidToNumber{$HspeakerID};
 $island = $Hislands[$number];

 # 왠지그 섬이 없는 경우
 if($number eq '') {
 unlock();
 tempProblem();
 return;
 }

 # 비밀번호 확인
 if(!checkPassword($island->{'password'},$HinputPassword)) {
 # password 오류
 unlock();
 tempWrongPassword();
 return;
 }

 # 통신 비용을 지불
 my($cost) = ($HlbbsType eq 'PUBLIC') ? $HlbbsMoneyPublic : $HlbbsMoneySecret;
 if (($HlbbsType eq 'SECRET') && ($island->{'money'} < $cost)) {
 # 비용부족
 unlock();
 tempLbbsNoMoney();
 return;
 }
 $island->{'money'} -= $cost;
 }

 # 발언자를 기억하다
 if ($HlbbsType ne 'ANON') {
 # 공개와 극비
 $speaker = $island->{'name'}. '섬';
 } else {
 # 익명
 $speaker = $ENV{'REMOTE_HOST'};
 $speaker = $ENV{'REMOTE_ADDR'} if ($speaker eq '');
 }
 if ($HlbbsType ne 'SECRET') {
 # 공개와 익명
 $speaker = "0<$speaker";
 } else {
 # 극비
 $speaker = "1<$speaker";
 }
 }

 my($lbbs);
 $lbbs = $island->{'lbbs'};

 # 모드에서 분기
 if($HlbbsMode == 2) {
	# 삭제 모드
	# 메시지를 전에밀기
	slideBackLbbsMessage($lbbs, $HcommandPlanNumber);
	tempLbbsDelete();
 } else {
	# 기장 모드
	# 메시지를 뒤에밀기
	slideLbbsMessage($lbbs);

	# 메시지 쓰기
	my($message);
	if($HlbbsMode == 0) {
	 $message = '0';
	} else {
	 $message = '1';
	}
	$HlbbsName = "$HislandTurn:". htmlEscape($HlbbsName);
	$HlbbsMessage = htmlEscape($HlbbsMessage);
 $lbbs->[0] = "$speaker<$message>$HlbbsName>$HlbbsMessage";

	tempLbbsAdd();
 }

 # 데이터 쓰기
 writeIslandsFile($HcurrentID);

 # 원래의 모드로
 if($HlbbsMode == 0) {
	printIslandMain();
 } else {
	ownerMain();
 }
}

sub changeAnkeito {

 $HcurrentNumber = $HidToNumber{$HcurrentID};
 my($island) = $Hislands[$HcurrentNumber];

 if(!checkPassword($island->{'password'},$HinputPassword)) {
 # password 오류
 unlock();
 tempWrongPassword();
 return;
 }

 if($AnnType == '') {
 unlock();
 tempWrongPassword6();
 return;
 }

 if($island->{'anflag'} == 2) {
 unlock();
 tempWrongPassword4();
 return;
 }

 if($AnnType == 1) {
 $an1++;
 } elsif($AnnType == 2) {
 $an2++;
 } elsif($AnnType == 3) {
 $an3++;
 } elsif($AnnType == 4) {
 $an4++;
 } elsif($AnnType == 5) {
 $an5++;
 }

 $island->{'anflag'} = 2;

 # 데이터 쓰기
 writeIslandsFile($HcurrentID);
 unlock();

 # 변경성공
 tempChange2();

}

# 로컬 게시판의 메시지를 하나뒤에밀기
sub slideLbbsMessage {
 my($lbbs) = @_;
 my($i);
# pop(@$lbbs);
# push(@$lbbs, $lbbs->[0]);
 pop(@$lbbs);
 unshift(@$lbbs, $lbbs->[0]);
}

# 로컬 게시판의 메시지를 하나전에밀기
sub slideBackLbbsMessage {
 my($lbbs, $number) = @_;
 my($i);
 splice(@$lbbs, $number, 1);
 $lbbs->[$HlbbsMax - 1] = '0<<0>>';
}

#----------------------------------------------------------------------
# 섬 지도
#----------------------------------------------------------------------

# 정보의 표시
sub islandInfo {
 my($island) = $Hislands[$HcurrentNumber];
 # 정보 표시
 my($rank) = $HcurrentNumber + 1;
 my($pop) = $island->{'pop'};
 my($farm) = $island->{'farm'};
 my($factory) = $island->{'factory'};
	$factory =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	($factory1, $factory2, $co0, $co1, $htf, $shtf, $co95, $co95, $co95, $co95) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10);
	$factoryt = $factory1 + $factory2;
 my($mountain) = $island->{'mountain'};
 my($pts) = $island->{'pts'};
 my($rena) = $rena = $island->{'rena'};
 $renae = int($rena / 10 ) + 1;
 my($unemployed);
 if($island->{'pop'}) {
	$unemployed = ($island->{'pop'} - ($farm + $factoryt + $mountain) * 10) / $island->{'pop'} * 100;
	$unemployed = '<font color="'. ($unemployed < 0 ? 'black' : 'red'). '">'. sprintf("%.2f%%", $unemployed). '</font>';
 } else {
	$unemployed = '<font color="black">0.00%</font>';
 }

 my($foodincome, $htincome, $moneyincome) = (0, 0, 0);

 # 수입
 if($pop> $farm * 10) {
	# 농업만으로 인력이 남는 경우
	$foodincome += $farm * 10 * ($co0 + 1); # 농장 전체가동

	 if($factory2 * 10> ($pop - $farm * 10)) {

		 $auc9 = $island->{'auc9'};
		 $auc9 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		 ($auc9a, $auc9b, $auc9c, $auc9d, $auc9e) = ($1, $2, $3, $4, $5);

			$htincome += int(($pop - $farm * 10) / 10);

	 } else {

		 $auc9 = $island->{'auc9'};
		 $auc9 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		 ($auc9a, $auc9b, $auc9c, $auc9d, $auc9e) = ($1, $2, $3, $4, $5);

			$htincome += $factory2;
			$moneyincome +=
			 min(int(($pop - $farm * 10 - $factory2*10) / 10),
				 $factory1 + $mountain) * ($co1 + 1);
	 }

 } else {
	# 농장 규모가 최대치의 경우
	$foodincome += $pop * ($co0 + 1); # 전체나 생 직원일
 }


 $farm1b = ($foodincome == 0) ? "식량전망 없음" : "식량+${foodincome}$HunitFood";
 $factory1 = ($factory1 == 0) ? "없음" : "${factory1}0$HunitPop";
 $factory1b = ($moneyincome == 0) ? "자금전망 없음" : "자금+${moneyincome}$HunitMoney";
 $factory2 = ($factory2 == 0) ? "없음" : "${factory2}0$HunitPop";
 $factory2b = ($htincome == 0) ? "자금 융통전망 없음" : "자금 융통+${htincome}$HunitMoney";

	$alt = "수입 전망";
	$alt2 = "일반직장…$factory1<br>HT 일자리…$factory2<hr>$farm1b<br>$factory1b<br>$factory2b";


 $farm = ($farm == 0) ? "없음" : "<p onMouseOver=\"MM_displayStatusMsg('$alt/$alt2'); Navi2($HislandSize, 'black.gif', '$alt', '$alt2', '$NaviText', ''); return true\" onMouseOut=\"MM_displayStatusMsg(''); NaviClose(); return false\">${farm}0$HunitPop</p>";
 $factoryt = ($factoryt == 0) ? "없음" : "<p onMouseOver=\"MM_displayStatusMsg('$alt/$alt2'); Navi2($HislandSize, 'black.gif', '$alt', '$alt2', '$NaviText', ''); return true\" onMouseOut=\"MM_displayStatusMsg(''); NaviClose(); return false\">${factoryt}0$HunitPop</p>";
 $mountain = ($mountain == 0) ? "없음" : "<p onMouseOver=\"MM_displayStatusMsg('$alt/$alt2'); Navi2($HislandSize, 'black.gif', '$alt', '$alt2', '$NaviText', ''); return true\" onMouseOut=\"MM_displayStatusMsg(''); NaviClose(); return false\">${mountain}0$HunitPop</p>";
 $pts = ($pts == 0) ? "0pts." : "${pts}pts.";
 $monsterlive = $island->{'monsterlive'};
 $monsi = ($monsterlive == 0) ? "" : "${monsterlive}$HunitMonster";
 $monsm = ($monsterlive == 0) ? "" : "${monsterlive}$HunitMonster 출현안!!";


	$auc9 = $island->{'auc9'};
	$auc9 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	($auc9a, $auc9b, $auc9c, $auc9d, $auc9e) = ($1, $2, $3, $4, $5);

	$auc9c2 = int($auc9c/10000);

	$alt = "양초";
	$alt2 = "저금…$auc9b 조 엔<br>옥션 자금 융통…$auc9c2조 엔<hr>합계…$auc9a 조 엔";
	$image2 = 'auc.gif';

	if ($auc9a>= 1)
	 {$auchojo = "+<IMG SRC=\"auc.gif\" ALT=\"양초\" WIDTH=16 HEIGHT=\"16\" onMouseOver=\"MM_displayStatusMsg('$alt/$alt2'); Navi2($HislandSize, '$image2', '$alt', '$alt2', '$NaviText', ''); return true\" onMouseOut=\"MM_displayStatusMsg(''); NaviClose(); return false\">"};
	if ($auc9a == 0)
	 {$auchojo = ""};


 my($mStr1) = '';
 my($mStr2) = '';
 if(($HhideMoneyMode == 1) || ($HmainMode eq 'owner')) {
	# 무조건또는 owner 모드
	$mStr1 = "<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_} 자금${H_tagTH}</NOBR></TH>";
	$mStr2 = "<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$island->{'money'}$HunitMoney$auchojo</NOBR></TD>";
 } elsif($HhideMoneyMode == 2) {
	my($mTmp) = aboutMoney($island->{'money'});

	# 1000억단위 모드
	$mStr1 = "<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_} 자금${H_tagTH}</NOBR></TH>";
	$mStr2 = "<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$mTmp$auchojo</NOBR></TD>";
 }


	$eisei3 = $island->{'eisei3'};
	$eisei3 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	($ene, $shouhi, $sabun, $chikuden, $ene) = ($1, $2, $3, $4, $5);
	$sabun = $ene-$shouhi;
	if ($sabun < 0)
	 {$sabun2 = "<font color=red>부족안!</font>"};
	if ($sabun>= 0)
	 {$sabun2 = ""};

	$alt = "사용 상황";
	$alt2 = "소비$shouhi 만 kW<br>과 부족$sabun 만 kW";
	$image2 = "ele.gif";

	$eleinfo = "<IMG SRC=\"ele.gif\" ALT=\"사용 상황(소비$shouhi 만 kW/과부족$sabun 만 kW)\" WIDTH=16 HEIGHT=\"16\" onMouseOver=\"MM_displayStatusMsg('$alt/$alt2'); Navi2($HislandSize, '$image2', '$alt', '$alt2', '$NaviText', ''); return true\" onMouseOut=\"MM_displayStatusMsg(''); NaviClose(); return false\">$sabun2";
	$island->{'ene'} = $ene;


	$prize = $island->{'prize'};
	my($flags, $monsters, $turns);
	$prize =~ /([0-9]*),([0-9]*),(.*)/;
	$flags = $1;
	$monsters= $2;
	$turns = $3;
	$prize = '';

 # 남은 턴 표시
 my($alt);
 while($turns =~ s/([0-9]*),//) {
 $alt.= "$1${Hprize[0]} ";
 }
 $prize.= "<IMG SRC=\"prize0.gif\" ALT=\"$alt\" WIDTH=16 HEIGHT=16> " if ($alt ne '');

	# 이름에 순위 표시 문자를 추가
	my($f) = 1;
	my($i);
	for($i = 1; $i < 10; $i++) {
	 if($flags & $f) {
		$prize.= "<IMG SRC=\"prize${i}.gif\" ALT=\"${Hprize[$i]}\" WIDTH=16 HEIGHT=16> ";
	 }
	 $f *= 2;
	}

	# 쓰러뜨린 괴수 목록
	$f = 1;
	my($max) = -1;
	my($mNameList) = '';
	for($i = 0; $i < $HmonsterNumber; $i++) {
	 if($monsters & $f) {
		$mNameList.= "[$HmonsterName[$i]] ";
		$max = $i;
	 }
	 $f *= 2;
	}
	if($max != -1) {
	 $prize.= "<IMG SRC=\"${HmonsterImage[$max]}\" ALT=\"$mNameList\" WIDTH=16 HEIGHT=16>$island->{'taiji'}$HunitMonster 퇴치";
	}

 # 출현 중인괴수 목록
 $f = 1;
 $max = -1;
 $mNameList = '';
 my($monslivetype) = $island->{'monsterlivetype'};
 my($monsliveimg);
 for($i = 0; $i < $HmonsterNumber; $i++) {
 if($monslivetype & $f) {
 $mNameList.= "[$HmonsterName[$i]] ";
 $max = $i;
 }
 $f *= 2;
 }
 if($max != -1) {
 $monsliveimg = "<IMG SRC=\"${HmonsterImage[$max]}\" ALT=\"$mNameList\" WIDTH=16 HEIGHT=16> ";
 }

	# 인공위성 발사
	my($me_sat) = "";
	$eis1 = $island->{'eis1'};
	$eis2 = $island->{'eis2'};
	$eis3 = $island->{'eis3'};
	$eis4 = $island->{'eis4'};
	$eis5 = $island->{'eis5'};
	$eis6 = $island->{'eis6'};
	$eis7 = $island->{'eis7'};
	 $cstpop = int($eis7/100);
	 $csten = $eis7%100+1;
	 $csroke = int($cstpop/10000)+1;
	if ($eis1>= 1)
	 {$me_sat.= "<IMG SRC=\"kisho.gif\" ALT=\"기상위성\" WIDTH=16 HEIGHT=\"16\">$eis1%"};
	if ($eis2>= 1)
	 {$me_sat.= "<IMG SRC=\"kansoku.gif\" ALT=\"관측위성\" WIDTH=16 HEIGHT=\"16\">$eis2%"};
	if ($eis3>= 1)
	 {$me_sat.= "<IMG SRC=\"geigeki.gif\" ALT=\"요격위성\" WIDTH=16 HEIGHT=\"16\">$eis3%"};
	if ($eis4>= 1)
	 {$me_sat.= "<IMG SRC=\"gunji.gif\" ALT=\"군사위성\" WIDTH=16 HEIGHT=\"16\">$eis4%"};
	if ($eis5>= 1)
	 {$me_sat.= "<IMG SRC=\"bouei.gif\" ALT=\"방위위성\" WIDTH=16 HEIGHT=\"16\">$eis5%"};
	if ($eis6>= 1)
	 {$me_sat.= "<IMG SRC=\"ire.gif\" ALT=\"비정상\" WIDTH=16 HEIGHT=\"16\">$eis6%"};

		$alt = "우주 정거장";
		$alt2 = "$cstpop$HunitPop 체류<br>인구유지로켓 수…$csroke 개<br>인구유지비용…$cstpop$HunitMoney";
		$image2 = "cst.gif";

	if ($eis7>= 1)
	 {$me_sat.= "<IMG SRC=\"cst.gif\" ALT=\"우주 정거장/$cstpop$HunitPop 체류\" WIDTH=16 HEIGHT=\"16\" onMouseOver=\"MM_displayStatusMsg('$alt/$alt2'); Navi2($HislandSize, '$image2', '$alt', '$alt2', '$NaviText', ''); return true\" onMouseOut=\"MM_displayStatusMsg(''); NaviClose(); return false\">$csten%"};
	if ($eis1 == 0 && $eis2 == 0 && $eis3 == 0 && $eis4 == 0 && $eis5 == 0 && $eis6 == 0 && $eis7 == 0)
	 {$me_sat = ""};

	# 목장계
	my($Farmcpc) = "";
	$tare = $island->{'tare'};
	$zipro = $island->{'zipro'};
	$leje = $island->{'leje'};
	if ($tare>= 1)
	 {$Farmcpc.= "<IMG SRC=\"niwatori.gif\" ALT=\"닭\" WIDTH=16 HEIGHT=\"16\">$tare 만 마리"};
	if ($zipro>= 1)
	 {$Farmcpc.= "<IMG SRC=\"buta.gif\" ALT=\"돼지\" WIDTH=16 HEIGHT=\"16\">$zipro 만 두"};
	if ($leje>= 1)
	 {$Farmcpc.= "<IMG SRC=\"ushi.gif\" ALT=\"우시\" WIDTH=16 HEIGHT=\"16\">$leje 만 두"};
	if ($tare == 0 && $zipro == 0 && $leje == 0)
	 {$Farmcpc = ""};

	$eisei6 = $island->{'eisei6'};
	$eisei6 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	($unimika, $unishuto, $unimeka, $unioumu, $unianseki, $unitiseki, $unihyouseki, $unifuseki, $unienseki, $unikouseki, $uniiseki, $uniden) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12);
	$etc8 = $island->{'etc8'};
	$etc8 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	($toto1, $toto2, $toto3, $toto4, $toto5, $toto6, $toto7) = ($1, $2, $3, $4, $5, $6, $7);

	# 가
	my($house) = "";
	$eisei1 = $island->{'eisei1'};
	$pts = $island->{'pts'};
	 if(($island->{'pts'}> $HouseLevel9) && ($unienseki>0) && ($unitiseki>0) && ($unihyouseki>0) && ($unifuseki>0) && ($unimika>0) && ($unishuto>0) && ($unimeka>0) && ($unioumu>0) && ($uniiseki>0) && ($toto2>0)) {
		 $hlv = 9;
			if(($unikouseki>0) || ($unianseki>0)) {
			$hlv = 11;
				if($unianseki>= $unikouseki) {
				$hlv = 10;
				}
			}
	 } elsif($island->{'pts'}> $HouseLevel9) {
	 	 $hlv = 9;
	 } elsif($island->{'pts'}> $HouseLevel8) {
	 	 $hlv = 8;
	 } elsif($island->{'pts'}> $HouseLevel7) {
		 $hlv = 7;
	 } elsif($island->{'pts'}> $HouseLevel6) {
	 	 $hlv = 6;
	 } elsif($island->{'pts'}> $HouseLevel5) {
		 $hlv = 5;
	 } elsif($island->{'pts'}> $HouseLevel4) {
	 	 $hlv = 4;
	 } elsif($island->{'pts'}> $HouseLevel3) {
		 $hlv = 3;
	 } elsif($island->{'pts'}> $HouseLevel2) {
	 	 $hlv = 2;
	 } elsif($island->{'pts'}> $HouseLevel1) {
		 $hlv = 1;
	 } else {
		 $hlv = 0;
	 }
	$onm = $island->{'onm'};
	if($hlv == 0) {
	 $n = '의오두막';
	} elsif($hlv == 1) {
	 $n = '의간이주택';
	} elsif($hlv == 2) {
	 $n = '의주택';
	} elsif($hlv == 3) {
	 $n = '의고급주택';
	} elsif($hlv == 4) {
	 $n = '의저택';
	} elsif($hlv == 5) {
	 $n = '의대저택';
	} elsif($hlv == 6) {
	 $n = '의고급 저택';
	} elsif($hlv == 7) {
	 $n = '의성';
	} elsif($hlv == 8) {
	 $n = '의거성';
	} elsif($hlv == 9) {
	 $n = '의황금성';
	} elsif($hlv == 10) {
	 $n = '의마탑';
	} else {
	 $n = '의천공성';
	}

	$zeikin = int($island->{'pop'}*($hlv+1)*$eisei1/100);

	$alt = "$onm$n";
	$alt2 = "세율$eisei1%($zeikin$HunitMoney)";
	$image2 = "house${hlv}.gif";

	if ($eisei1> 0)
	 {$house.= "<IMG SRC=\"house${hlv}.gif\" ALT=\"$onm$n\" WIDTH=16 HEIGHT=\"16\" onMouseOver=\"MM_displayStatusMsg('$alt/$alt2'); Navi2($HislandSize, '$image2', '$alt', '$alt2', '$NaviText', ''); return true\" onMouseOut=\"MM_displayStatusMsg(''); NaviClose(); return false\">세율$eisei1%($zeikin$HunitMoney)"};
	if ($eisei1 == 0)
	 {$house = ""};

	$totoyoso2 = $island->{'totoyoso2'};
	if ($totoyoso2 == 0)
	 {$shutohen.= "<INPUT TYPE=\"submit\" VALUE=\"수도 이름 변경\" NAME=\"TotosButton$Hislands[$HcurrentNumber]->{'id'}\">"};
	if ($totoyoso2 == 555)
	 {$shutohen = ""};

	$kakushuyoso = "";
 if (((($HislandTurn % 100)>= 0) && ((($HislandTurn % 100) < 26))) || ((($HislandTurn % 100)>= 50) && ((($HislandTurn % 100) < 76))))
	 {$kakushuyoso.= "<INPUT TYPE=\"submit\" VALUE=\"각종예상\" NAME=\"TotoButton$Hislands[$HcurrentNumber]->{'id'}\">"};

	$auc6 = $island->{'auc6'};
	$auc6 =~ /^([0-9]*),([0-9]*),([0-9]*)$/;
	($auc6a, $auc6x, $auc6y) = ($1, $2, $3);
	$nyuusatu = "";
 if ($auc6a <= 2)
	 {$nyuusatu.= "<INPUT TYPE=\"submit\" VALUE=\"입찰하다\" NAME=\"AuctionButton$Hislands[$HcurrentNumber]->{'id'}\">"};

	$etc5 = $island->{'etc5'};
	$etc5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	($s00,$s01,$s02,$s03,$s04,$s05,$s06,$s07,$s08,$s09,$s10,$s11,$s12,$s13,$s14,$s15,$s16,$s17,$s18,$s19,$s20,$s21,$s22,$s23,$s24,$s25,$s26,$s27,$s28,$s29,$s30) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);

	$s04b = int($s04/10);
	$s06b = int($s06/5);
	$s08b = int($s08/5);
	$s10b = int($s10/5)+1;
	if($s10b> 9) {$s10b = 9;}
	$s12b = int($s12/5)+1;
	if($s12b> 10) {$s12b = 10;}

	if ($s00 != 0)
	 {$seisaku.= "<hr><B>정책(수량 0~50에서 지정해 주세요)</B><br>"};
	 {$seisaku.= "<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\"><tr><td><INPUT TYPE=\"submit\" VALUE=\"생략에네\" NAME=\"ShoueneButton$Hislands[$HcurrentNumber]->{'id'}\"></td><td> 예산$s01조 엔/소비전력-$s02%</td><tr><td><INPUT TYPE=\"submit\" VALUE=\" 교육육성 \" NAME=\"KyouikuButton$Hislands[$HcurrentNumber]->{'id'}\"></td><td> 예산$s09조 엔/지정 가능+$s10b</td></tr><tr><td><INPUT TYPE=\"submit\" VALUE=\" 방재 \" NAME=\"BousaiButton$Hislands[$HcurrentNumber]->{'id'}\"></td><td> 예산$s03조 엔/예측 정확도+$s04b</td></tr><tr><td><INPUT TYPE=\"submit\" VALUE=\" 관광 \" NAME=\"KankouButton$Hislands[$HcurrentNumber]->{'id'}\"></td><td> 예산$s05조 엔/인기+$s06b</td></tr><tr><td><INPUT TYPE=\"submit\" VALUE=\" 자연 \" NAME=\"SizenButton$Hislands[$HcurrentNumber]->{'id'}\"></td><td> 예산$s07조 엔/청소정화+$s08b</td></tr><tr><td><INPUT TYPE=\"submit\" VALUE=\" 저축 \" NAME=\"ChochikuButton$Hislands[$HcurrentNumber]->{'id'}\"></td><td> 예산$s11조 엔/저축$s12b 배</td></tr></table>"};
	if ($s00 == 0)
	 {$seisaku = ""};

	if ($anothermood == 1)
	 {$ptsname = "경제력"};
	if ($anothermood == 0)
	 {$ptsname = "종합 Point"};


 out(<<END);
<CENTER>
<TABLE BORDER>
<TR>
<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}순위${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}$ptsname${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}인구${H_tagTH}</NOBR></TH>
$mStr1
<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}식량${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}면적${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}농장${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}직장${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}채굴장${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}발전력${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}실업률${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell nowrap=nowrap><NOBR>${HtagTH_}군사 기술${H_tagTH}</NOBR></TH>
</TR>
<TR>
<TD $HbgNumberCell ROWSPAN=2 align=middle nowrap=nowrap><NOBR>${HtagNumber_}$rank${H_tagNumber}</NOBR></TD>
<TD $HbgPoinCell align=right nowrap=nowrap><NOBR>${pts}</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$island->{'pop'}$HunitPop</NOBR></TD>
$mStr2
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$island->{'food'}$HunitFood</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$island->{'area'}$HunitArea</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>${farm}</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>${factoryt}</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>${mountain}</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>${ene}만 kW</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>${unemployed}</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>Lv${renae}</NOBR></TD>
</TR>
<TR>
<TD $HbgCommentCell COLSPAN=11 align=left nowrap=nowrap><NOBR>${HtagtTH_}info:<font size="-1"><font color="SALMON">$house</font>$monsliveimg<font color="hotpink">$monsm</font>$Farmcpc$me_sat</font></font>$eleinfo</NOBR></TD>
</TR>
</TABLE></CENTER>


<SCRIPT Language="JavaScript">
<!--

function MM_displayStatusMsg(msgStr) {
 window.status=msgStr;
}

function Navi(HislandSize, position, position2, x, y, img, title, title2, text, exp) {
	StyElm = document.getElementById("NaviView");
	StyElm.style.visibility = "visible";

	if(HislandSize < 15) {
		if(position == 1) {
			if(position2 == 1) {
			 StyElm.style.marginLeft = -32;
			 StyElm.style.marginTop = -360;
			} else {
			 StyElm.style.marginLeft = -32;
			 StyElm.style.marginTop = -120;
			}
		} else {
		 StyElm.style.marginLeft = 240;
		 StyElm.style.marginTop = -240;
		}

	} else {

		if(position == 1) {
		 StyElm.style.marginLeft = 32;
		 StyElm.style.marginTop = (y - 19) * 32;
		} else {
		 StyElm.style.marginLeft = 336;
		 StyElm.style.marginTop = (y - 19) * 32;
		}

	}


	if(HislandSize < 15) {
	 StyElm.innerHTML = "<table><tr><td class='M'><img class='NaviImg' src=" + img + "><\/td><td class='M'><div class='NaviTitle'>" + title + " (" + x + "," + y + ")<\/div><div class='NaviText'><hr>" + title2 + " <\/div><\/td><\/tr><\/table>";
	} else {
	 StyElm.innerHTML = "<table><tr><td class='M'><img class='NaviImg' src=" + img + "><\/td><td class='M' width=256><div class='NaviTitle'>" + title + " (" + x + "," + y + ")<\/div><div class='NaviText'><hr>" + title2 + " <\/div><\/td><\/tr><\/table>";
	}


}

function Navi2(HislandSize,img, title, title2, text, exp) {
	StyElm = document.getElementById("NaviView");
	StyElm.style.visibility = "visible";

	if(HislandSize < 15) {

		 StyElm.style.marginLeft = 0;
		 StyElm.style.marginTop = -400;

	} else {

		 StyElm.style.marginLeft = 0;
		 StyElm.style.marginTop = -656;

	}

	 StyElm.innerHTML = "<table><tr><td class='M'><img class='NaviImg' src=" + img + "><\/td><td class='M'><div class='NaviTitle'>" + title + "<\/div><div class='NaviText'><hr>" + title2 + " <\/div><\/td><\/tr><\/table>";

}

function NaviClose() {
	StyElm = document.getElementById("NaviView");
	StyElm.style.visibility = "hidden";
}

//-->
</SCRIPT>

END
}

# 지도 표시
# 인 수가1이면, 미사일 기지등을 그대로 표시
sub islandMap {
 my($mode) = @_;
 my($island);
 $island = $Hislands[$HcurrentNumber];

 out(<<END);
<CENTER><TABLE BORDER><TR><TD>
END
 # 지형, 지형 값을 가져옴
 my($land) = $island->{'land'};
 my($landValue) = $island->{'landValue'};
 my($l, $lv);

	my($onm);
	$onm = $island->{'onm'};
	my($totoyoso2);
	$totoyoso2 = $island->{'totoyoso2'};
	my($eis1);
	$eis1 = $island->{'eis1'};
	my($eis2);
	$eis2 = $island->{'eis2'};
	my($eis3);
	$eis3 = $island->{'eis3'};
	my($eis5);
	$eis5 = $island->{'eis5'};
	my($area);
	$area = $island->{'area'};
	my($fore);
	$fore = $island->{'fore'};

	my($pop);
	$pop = $island->{'pop'};
	$mikomi = int($pop * 3 * 11 / 500);

	$eisei5 = $island->{'eisei5'};
	$eisei5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	($mshp, $msap, $msdp, $mssp, $mswin, $msexe, $tet) = ($1, $2, $3, $4, $5, $6, $7);

	$eisei4 = $island->{'eisei4'};
	$eisei4 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	($sto, $std, $stk, $stwin, $stdrow, $stlose, $stwint, $stdrowt, $stloset, $styusho, $stshoka) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11);
	$kachiten = $stwin*3 + $stdrow;

	if($stshoka == 0) {
	 $nn = '연습안';
	} elsif($stshoka == 1) {
	 $nn = '예선 제1전투 대기치';
	} elsif($stshoka == 2) {
	 $nn = '예선 제2전투 대기치';
	} elsif($stshoka == 3) {
	 $nn = '예선 제3전투 대기치';
	} elsif($stshoka == 4) {
	 $nn = '예선 제4전투 대기치';
	} elsif($stshoka == 5) {
	 $nn = '예선종료대기치';
	} elsif($stshoka == 6) {
	 $nn = '준준결승전대기치';
	} elsif($stshoka == 7) {
	 $nn = '준결승전대기치';
	} elsif($stshoka == 8) {
	 $nn = '결승전대기치';
	} elsif($stshoka == 9) {
	 $nn = '우승!';
	} elsif($stshoka == 10) {
	 $nn = '연습안';
	} elsif($stshoka == 11) {
	 $nn = '예선 탈락';
	} elsif($stshoka == 12) {
	 $nn = '준준결승';
	} elsif($stshoka == 13) {
	 $nn = '준결승';
	} elsif($stshoka == 14) {
	 $nn = '제2위';
	} else {
	 $nn = '연습안';
	}

	$etc9 = $island->{'etc9'};
	$etc9 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	($co7, $magicf, $magici, $magica, $magicw, $magicl, $magicd) = ($1, $2, $3, $4, $5, $6, $7);


	$etc6 = $island->{'etc6'};
	$etc6 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	($z0,$z1,$z2,$z3,$z4,$z5,$z6,$z7,$z8,$z9,$z10,$z11,$z12,$z13,$z14,$z15,$z16,$z17,$z18,$z19,$z20,$z21,$z22,$z23,$z24,$z25,$z26,$z27,$z28,$z29,$z30) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);
	($z->{'0'},$z->{'1'},$z->{'2'},$z->{'3'},$z->{'4'},$z->{'5'},$z->{'6'},$z->{'7'},$z->{'8'},$z->{'9'},$z->{'10'},$z->{'11'},$z->{'12'},$z->{'13'},$z->{'14'},$z->{'15'},$z->{'16'},$z->{'17'},$z->{'18'},$z->{'19'},$z->{'20'},$z->{'21'},$z->{'22'},$z->{'23'},$z->{'24'},$z->{'25'},$z->{'26'},$z->{'27'},$z->{'28'},$z->{'29'},$z->{'30'}) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);


	$zookazu = $z0+$z1+$z2+$z3+$z4+$z5+$z6+$z7+$z8+$z9+$z10+$z11+$z12+$z13+$z14+$z15+$z16+$z17+$z18+$z19+$z20+$z21+$z22+$z23+$z24+$z25+$z26+$z27+$z28+$z29+$z30;
	$zookazus = $z0*2+$z1+$z2+$z3+$z4+$z5+$z6+$z7+$z8*2+$z9+$z10+$z11+$z12*2+$z13*3+$z14*3+$z15*3+$z16*3+$z17*4+$z18*4+$z19*5+$z20*4+$z21*5+$z22*3+$z23*3+$z24*3+$z25*3+$z26*3+$z27*3+$z28*4+$z29+$z30*4;

	$bariaA = $island->{'rena'}-$zookazus*25;
	$bariaB = $island->{'rena'}-$zookazus*50;

	$mshurui = 0;
	foreach $i (0..30) {

	$zoos = $z->{"$i"};

	 if($zoos> 0) {
		$mNameList.= "[$HmonsterName[$i]$zoos 마리] ";
		$mshurui++;
	 }
	}

	$auc6 = $island->{'auc6'};
	$auc6 =~ /^([0-9]*),([0-9]*),([0-9]*)$/;
	($auc6a, $auc6x, $auc6y) = ($1, $2, $3);

	$auction1 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	($shuppin1, $avalue1, $ajoutai1, $topvalue1, $topid1) = ($1, $2, $3, $4, $5);

	if($shuppin1 == 0) {
	 $ac1 = '?';
	} elsif($shuppin1 == 1) {
	 $ac1 = '지석';
	} elsif($shuppin1 == 2) {
	 $ac1 = '빙석';
	} elsif($shuppin1 == 3) {
	 $ac1 = '풍석';
	} elsif($shuppin1 == 4) {
	 $ac1 = '염석';
	} elsif($shuppin1 == 5) {
	 $ac1 = '광석';
	} elsif($shuppin1 == 6) {
	 $ac1 = '천사미카엘';
	} elsif($shuppin1 == 7) {
	 $ac1 = '아이스 스콜피온';
	} elsif($shuppin1 == 8) {
	 $ac1 = '슬라임 레전드';
	} elsif($shuppin1 == 9) {
	 $ac1 = "부적$avalue1개";
	} elsif($shuppin1 == 10) {
	 $avalue1 = $avalue1 * 1000;
	 $ac1 = "해상 시설$avalue1명 규모";
	} elsif($shuppin1 == 11) {
	 $avalue1 = $avalue1 * 1000;
	 $ac1 = "식품 연구$avalue1명 규모";
	} elsif($shuppin1 == 12) {
	 $ac1 = "코스모 발전소 $avalue1만 kW";
	} elsif($shuppin1 == 13) {
	 $ac1 = '암석';
	} elsif($shuppin1 == 14) {
	 $ac1 = '위성6종';
	} elsif($shuppin1 == 15) {
	 $ac1 = '우주 정거장';
	} elsif($shuppin1 == 16) {
	 $ac1 = '황금의 콘덴서';
	} elsif($shuppin1 == 17) {
	 $avalue1 = $avalue1 * 1000;
	 $ac1 = "금광산$avalue1명 규모";
	} elsif($shuppin1 == 18) {
	 $avalue1 = $avalue1 * 1000;
	 $ac1 = "양식장$avalue1명 규모";
	} elsif($shuppin1 == 19) {
	 $ac1 = '인공괴수f02';
	} elsif($shuppin1 == 20) {
	 $ac1 = '마왕 사탄';
	} elsif($shuppin1 == 21) {
	 $ac1 = 'unknown';
	} elsif($shuppin1 == 22) {
	 $ac1 = "축구팀 전력1.$avalue1배";
	} elsif($shuppin1 == 23) {
	 $ac1 = "생물 대학 능력1.$avalue1배";
	} elsif($shuppin1 == 24) {
	 $ac1 = "생물 대학 경험치$avalue1";
	} elsif($shuppin1 == 25) {
	 $ac1 = '알';
	} elsif($shuppin1 == 26) {
	 $ac1 = '생물 대학';
	} elsif($shuppin1 == 27) {
	 $ac1 = "풍력$avalue1만 kW";
	} elsif($shuppin1 == 28) {
	 $ac1 = "바이오매스$avalue1만 kW";
	} elsif($shuppin1 == 29) {
	 $ac1 = '이번은 휴식';
	} elsif($shuppin1 == 30) {
	 my($island, $j, $name, $id, $ii);
	 for($ii = 0; $ii < $HislandNumber; $ii++) {
		$j = $ii + 1;
		$island = $Hislands[$ii];
		$id = $island->{'id'};
			if($avalue1 == $island->{'id'}) {
			 $dashiname = $island->{'auc7'};
			}
		}
	 $ac1 = "$dashiname";
	} else {
	 $ac1 = '?';
	}

	if($ajoutai1 == 15) {
	 $acjo1 = "<font color=\"red\">(낙찰완료미)</font>";
	} else {
	 $acjot1 = 15-$ajoutai1;
	 $acjo1 = "(남은$acjot1턴)";
	}

	$auction2 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	($shuppin2, $avalue2, $ajoutai2, $topvalue2, $topid2) = ($1, $2, $3, $4, $5);

	if($shuppin2 == 0) {
	 $ac2 = '암석';
	} elsif($shuppin2 == 1) {
	 $ac2 = '지석';
	} elsif($shuppin2 == 2) {
	 $ac2 = '빙석';
	} elsif($shuppin2 == 3) {
	 $ac2 = '풍석';
	} elsif($shuppin2 == 4) {
	 $ac2 = '염석';
	} elsif($shuppin2 == 5) {
	 $ac2 = '광석';
	} elsif($shuppin2 == 6) {
	 $ac2 = '천사미카엘';
	} elsif($shuppin2 == 7) {
	 $ac2 = '아이스 스콜피온';
	} elsif($shuppin2 == 8) {
	 $ac2 = '슬라임 레전드';
	} elsif($shuppin2 == 9) {
	 $ac2 = "부적$avalue2개";
	} elsif($shuppin2 == 10) {
	 $avalue2 = $avalue2 * 1000;
	 $ac2 = "해상 시설$avalue2명 규모";
	} elsif($shuppin2 == 11) {
	 $avalue2 = $avalue2 * 1000;
	 $ac2 = "식품 연구$avalue2명 규모";
	} elsif($shuppin2 == 12) {
	 $ac2 = "코스모 발전소 $avalue2만 kW";
	} elsif($shuppin2 == 13) {
	 $ac2 = '암석';
	} elsif($shuppin2 == 14) {
	 $ac2 = '위성6종';
	} elsif($shuppin2 == 15) {
	 $ac2 = '우주 정거장';
	} elsif($shuppin2 == 16) {
	 $ac2 = '황금의 콘덴서';
	} elsif($shuppin2 == 17) {
	 $avalue2 = $avalue2 * 1000;
	 $ac2 = "금광산$avalue2명 규모";
	} elsif($shuppin2 == 18) {
	 $avalue2 = $avalue2 * 1000;
	 $ac2 = "양식장$avalue2명 규모";
	} elsif($shuppin2 == 19) {
	 $ac2 = '인공괴수f02';
	} elsif($shuppin2 == 20) {
	 $ac2 = '마왕 사탄';
	} elsif($shuppin2 == 21) {
	 $ac2 = 'unknown';
	} elsif($shuppin2 == 22) {
	 $ac2 = "축구팀 전력1.$avalue2배";
	} elsif($shuppin2 == 23) {
	 $ac2 = "생물 대학 능력1.$avalue2배";
	} elsif($shuppin2 == 24) {
	 $ac2 = "생물 대학 경험치$avalue2";
	} elsif($shuppin2 == 25) {
	 $ac2 = '알';
	} elsif($shuppin2 == 26) {
	 $ac2 = '생물 대학';
	} elsif($shuppin2 == 27) {
	 $ac2 = "풍력$avalue2만 kW";
	} elsif($shuppin2 == 28) {
	 $ac2 = "바이오매스$avalue2만 kW";
	} elsif($shuppin2 == 29) {
	 $ac2 = '이번은 휴식';
	} elsif($shuppin2 == 30) {
	 my($island, $j, $name, $id, $ii);
	 for($ii = 0; $ii < $HislandNumber; $ii++) {
		$j = $ii + 1;
		$island = $Hislands[$ii];
		$id = $island->{'id'};
			if($avalue2 == $island->{'id'}) {
			 $dashiname = $island->{'auc7'};
			}
		}
	 $ac2 = "$dashiname";
	} else {
	 $ac2 = '?';
	}

	if($ajoutai2 == 15) {
	 $acjo2 = "<font color=\"red\">(낙찰완료미)</font>";
	} else {
	 $acjot2 = 15-$ajoutai2;
	 $acjo2 = "(남은$acjot2턴)";
	}

	$auction3 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	($shuppin3, $avalue3, $ajoutai3, $topvalue3, $topid3) = ($1, $2, $3, $4, $5);

	if($shuppin3 == 0) {
	 $ac3 = '암석';
	} elsif($shuppin3 == 1) {
	 $ac3 = '지석';
	} elsif($shuppin3 == 2) {
	 $ac3 = '빙석';
	} elsif($shuppin3 == 3) {
	 $ac3 = '풍석';
	} elsif($shuppin3 == 4) {
	 $ac3 = '염석';
	} elsif($shuppin3 == 5) {
	 $ac3 = '광석';
	} elsif($shuppin3 == 6) {
	 $ac3 = '천사미카엘';
	} elsif($shuppin3 == 7) {
	 $ac3 = '아이스 스콜피온';
	} elsif($shuppin3 == 8) {
	 $ac3 = '슬라임 레전드';
	} elsif($shuppin3 == 9) {
	 $ac3 = "부적$avalue2개";
	} elsif($shuppin3 == 10) {
	 $avalue3 = $avalue3 * 1000;
	 $ac3 = "해상 시설$avalue3명 규모";
	} elsif($shuppin3 == 11) {
	 $avalue3 = $avalue3 * 1000;
	 $ac3 = "식품 연구$avalue3명 규모";
	} elsif($shuppin3 == 12) {
	 $ac3 = "코스모 발전소 $avalue3만 kW";
	} elsif($shuppin3 == 13) {
	 $ac3 = '암석';
	} elsif($shuppin3 == 14) {
	 $ac3 = '위성6종';
	} elsif($shuppin3 == 15) {
	 $ac3 = '우주 정거장';
	} elsif($shuppin3 == 16) {
	 $ac3 = '황금의 콘덴서';
	} elsif($shuppin3 == 17) {
	 $avalue3 = $avalue3 * 1000;
	 $ac3 = "금광산$avalue3명 규모";
	} elsif($shuppin3 == 18) {
	 $avalue3 = $avalue3 * 1000;
	 $ac3 = "양식장$avalue3명 규모";
	} elsif($shuppin3 == 19) {
	 $ac3 = '인공괴수f02';
	} elsif($shuppin3 == 20) {
	 $ac3 = '마왕 사탄';
	} elsif($shuppin3 == 21) {
	 $ac3 = 'unknown';
	} elsif($shuppin3 == 22) {
	 $ac3 = "축구팀 전력1.$avalue3배";
	} elsif($shuppin3 == 23) {
	 $ac3 = "생물 대학 능력1.$avalue3배";
	} elsif($shuppin3 == 24) {
	 $ac3 = "생물 대학 경험치$avalue3";
	} elsif($shuppin3 == 25) {
	 $ac3 = '알';
	} elsif($shuppin3 == 26) {
	 $ac3 = '생물 대학';
	} elsif($shuppin3 == 27) {
	 $ac3 = "풍력$avalue3만 kW";
	} elsif($shuppin3 == 28) {
	 $ac3 = "바이오매스$avalue3만 kW";
	} elsif($shuppin3 == 29) {
	 $ac3 = '이번은 휴식';
	} elsif($shuppin3 == 30) {
	 my($island, $j, $name, $id, $ii);
	 for($ii = 0; $ii < $HislandNumber; $ii++) {
		$j = $ii + 1;
		$island = $Hislands[$ii];
		$id = $island->{'id'};
			if($avalue3 == $island->{'id'}) {
			 $dashiname = $island->{'auc7'};
			}
		}
	 $ac3 = "$dashiname";
	} else {
	 $ac3 = '?';
	}

	if($ajoutai3 == 15) {
	 $acjo3 = "<font color=\"red\">(낙찰완료미)</font>";
	} else {
	 $acjot3 = 15-$ajoutai3;
	 $acjo3 = "(남은$acjot3턴)";
	}

 # 명령가져오기
 my($command) = $island->{'command'};
 my($com, @comStr, $i);
 if($HmainMode eq 'owner') {
	for($i = 0; $i < $HcommandMax; $i++) {
	 my($j) = $i + 1;
	 $com = $command->[$i];
	 if($com->{'kind'} < 31) {
		$comStr[$com->{'x'}][$com->{'y'}].=
		 " [${j}]$HcomName[$com->{'kind'}]";
	 }
	 foreach $i (70..79) {
		if($com->{'kind'} == $i) {
		 $comStr[$com->{'x'}][$com->{'y'}].=
		 " [${j}]$HcomName[$com->{'kind'}]";
	 }
	 }
	 foreach $i (100..130) {
		if($com->{'kind'} == $i) {
		 $comStr[$com->{'x'}][$com->{'y'}].=
		 " [${j}]$HcomName[$com->{'kind'}]";
	 }
	 }
	}
 }

	if($HislandSize == 20) {
	 $bar = 'xbar_20.gif';
	} else {
	 $bar = 'xbar.gif';
	}

 # 좌표(상)을 출력
 out("<IMG SRC=\"$bar\"><BR>");

 # 각 지형및 줄바꿈을 출력
 my($x, $y);
 for($y = 0; $y < $HislandSize; $y++) {
	# 짝 수행이면 번호 출력
 if(($y % 2) == 0) {
	 out("<IMG SRC=\"space${y}.gif\" width=16 height=32>");
	}

	# 각 지형을 출력
	for($x = 0; $x < $HislandSize; $x++) {
	 $l = $land->[$x][$y];
	 $lv = $landValue->[$x][$y];

	 landString($l, $lv, $x, $y, $mode, $comStr[$x][$y]);
	}

	# 홀 수행이면 번호 출력
 if(($y % 2) == 1) {
	 out("<IMG SRC=\"space${y}.gif\" width=16 height=32>");
	}

	# 줄바꿈을 출력
	out("<BR>");
 }
 out("<div id=\"NaviView\"></div>");
 out("</TD></TR></TABLE></CENTER>\n");
}

sub landString {
 my($l, $lv, $x, $y, $mode, $comStr) = @_;
 my($point) = "($x,$y)";
 my($image, $alt);

 $alt2 = '';
 $n2 = '';

 if($l == $HlandSea) {

	if($lv == 1) {
	 # 얕은 바다
	 $image = 'land14.gif';
	 $alt = '바다(얕은 바다)';
 } else {
 # 바다
	 $image = 'land0.gif';
	 $alt = '바다';
 }
 } elsif($l == $HlandWaste) {
	# 황무지
	if($lv == 1) {
	 $image = 'land13.gif'; # 착탄점
	 $alt = '황무지';
	} else {
	 $image = 'land1.gif';
	 $alt = '황무지';
	}
 } elsif($l == $HlandPlains) {
	# 평지
	$image = 'land2.gif';
	$alt = '평지';
 } elsif($l == $HlandPlains2) {
	# 평지2
	$image = 'land53.gif';
	$alt = '개발 예정지';
 } elsif($l == $HlandYakusho) {
	# 관청
	$image = 'land52.gif';
	$alt = '섬관청';
 } elsif($l == $HlandKura) {
	# 창고
	$seq = int($lv/100);
	$choki = $lv%100;
	$image = 'land55.gif';
	$alt = "창고";
	$alt2 = "보안 Level${seq}/저금${choki}조 엔";
 } elsif($l == $HlandKuraf) {
	# 창고 Food
	$choki = int($lv/10);
	$kibo = $lv%10;
	$image = 'land55.gif';
	$alt = "창고";
	$alt2 = "규모 Level${kibo}/저장 식량${choki}00만톤";
 } elsif($l == $HlandForest) {
	# 숲
	if($mode == 1) {
	 $image = 'land6.gif';
	 $alt = "숲";
	 $alt2 = "${lv}$HunitTree";
	} else {
	 # 관광객에게는 목장 수를 숨김
	 $image = 'land6.gif';
	 $alt = '숲';
	}

 } elsif($l == $HlandHouse) {
	# 섬주의 가
	my($p, $n);

	if($lv == 0) {
	 $n = "$onm 의오두막";
	} elsif($lv == 1) {
	 $n = "$onm 의간이주택";
	} elsif($lv == 2) {
	 $n = "$onm 의주택";
	} elsif($lv == 3) {
	 $n = "$onm 의고급주택";
	} elsif($lv == 4) {
	 $n = "$onm 의저택";
	} elsif($lv == 5) {
	 $n = "$onm 의대저택";
	} elsif($lv == 6) {
	 $n = "$onm 의고급 저택";
	} elsif($lv == 7) {
	 $n = "$onm 의성";
	} elsif($lv == 8) {
	 $n = "$onm 의거성";
	} elsif($lv == 9) {
	 $n = "$onm 의황금성";
	} elsif($lv == 10) {
	 $n = "$onm 의마탑";
	} else {
	 $n = "$onm 의천공성";
	}

	$image = "house${lv}.gif";
	$alt = "$n";
	$alt2 = "세율$eisei1%($zeikin$HunitMoney)";

 } elsif($l == $HlandTrain) {
	# 열차입니다
	my($p, $n);

	if($lv == 0) {
	 $n = "역";
	} elsif($lv < 10) {
	 $n = "선로";
	} elsif($lv == 10) {
	 $n = "역(일반 열차 정차 중)";
	} elsif($lv < 20) {
	 $n = "일반 열차";
	} elsif($lv == 20) {
	 $n = "역(화물 열차 정차 중)";
	} elsif($lv < 30) {
	 $n = "화물 열차";
	} else {
	 $n = "길선";
	}

	$image = "train${lv}.gif";
	$alt = "$n";

 } elsif($l == $HlandTaishi) {

	my($tn) = $HidToNumber{$lv};
	$tIsland = $Hislands[$tn];
	$ttname = $tIsland->{'name'};
	$image = "land51.gif";
	$alt = "$ttname 섬 대사관";

 } elsif($l == $HlandTown) {
	# 읍
	my($p, $n);
	if($lv < 30) {
	 $p = 3;
	 $n = '마을';
	} elsif($lv < 100) {
	 $p = 4;
	 $n = '읍';
	} else {
	 $p = 5;
	 $n = '도시';
	}

	$image = "land${p}.gif";
	$alt = "$n";
	$alt2 = "${lv}$HunitPop";
 } elsif($l == $HlandProcity) {
	# 읍
	my($c);
	if($lv < 110) {
	 $c = '방재 도시랭크E';
	} elsif($lv < 130) {
	 $c = '방재 도시랭크D';
	} elsif($lv < 160) {
	 $c = '방재 도시랭크C';
	} elsif($lv < 200) {
	 $c = '방재 도시랭크B';
	} else {
	 $c = '방재 도시랭크A';
	}

	$image = "land26.gif";
	$alt = "$c";
	$alt2 = "${lv}$HunitPop";

 } elsif($l == $HlandCollege) {
	# 대학
	my($p, $n);
	if($lv == 0) {
	 $p = 34;
	 $n = '농업대학';
	} elsif($lv == 1) {
	 $p = 35;
	 $n = '공업대학';
	} elsif($lv == 2) {
	 $p = 36;
	 $n = '종합대학';
	} elsif($lv == 3) {
	 $p = 37;
	 $n = '군사대학';
	} elsif($lv == 4) {
	 $p = 44;
	 $n = "생물 대학";
	 $n2 = "대기/HP$mshp.AP$msap.DP$msdp.SP$mssp/$mswin 마리 격파/경험치$msexe";
	} elsif($lv == 98) {
	 $p = 48;
	 $n = "생물 대학";
	 $n2 = "대기/HP$mshp.AP$msap.DP$msdp.SP$mssp/$mswin 마리 격파/경험치$msexe";
	} elsif($lv == 96) {
	 $p = 44;
	 $n = "생물 대학";
	 $n2 = "출입 금지/HP$mshp.AP$msap.DP$msdp.SP$mssp/$mswin 마리 격파/경험치$msexe";
	} elsif($lv == 97) {
	 $p = 48;
	 $n = "생물 대학";
	 $n2 = "출입 금지/HP$mshp.AP$msap.DP$msdp.SP$mssp/$mswin 마리 격파/경험치$msexe";
	} elsif($lv == 99) {
	 $p = 47;
	 $n = '생물 대학(출동안)';
	} elsif($lv == 5) {
	 $p = 46;
	 $n = '기상대학';
	} elsif($lv == 6) {
	 $p = 47;
	 $n = '경제대학';
	} elsif($lv == 7) {
	 $p = 65;
	 $n = "마법학교";
	 $n2 = "불꽃:lv$magicf 얼음:lv$magici 지:lv$magica 바람:lv$magicw 빛:lv$magicl 어둠:lv$magicd";
	} elsif($lv == 8) {
	 $p = 71;
	 $n = '전기공사대학';
	} elsif($lv == 77) {
	 $p = 75;
	 $n = "문부과학성";
	 $n2 = "소비전력-$s02%/지정 가능+$s10b/예측 정확도+$s04b/인기+$s06b/청소정화+$s08b/저축$s12b 배";
	} elsif($lv == 78) {
	 $p = 75;
	 $n = "문부과학성";
	 $n2 = "소비전력-$s02%/지정 가능+$s10b/예측 정확도+$s04b/인기+$s06b/청소정화+$s08b/저축$s12b 배<br><font color = royalblue>(자동 개발 예정지 실행 예정)</font>";
	} elsif($lv == 79) {
	 $p = 75;
	 $n = "문부과학성";
	 $n2 = "소비전력-$s02%/지정 가능+$s10b/예측 정확도+$s04b/인기+$s06b/청소정화+$s08b/저축$s12b 배<br><font color = royalblue>(자동 땅 고르기 실행 예정)</font>";
	} elsif($lv == 80) {
	 $p = 75;
	 $n = "문부과학성";
	 $n2 = "소비전력-$s02%/지정 가능+$s10b/예측 정확도+$s04b/인기+$s06b/청소정화+$s08b/저축$s12b 배<br><font color = royalblue>(자동 개발 예정지 실행 예정)<br>(자동 땅 고르기 실행 예정)</font>";
	} elsif($lv == 95) {
	 $p = 54;
	 $n = '경제대학(저금안)';
	} else {
	 $p = 46;
	 $n = '기상대학';
	}

	$image = "land${p}.gif";
	$alt = "$n";
	$alt2 = "$n2";
 } elsif($l == $HlandKyujokai) {
 # 야구장
 $image = 'land23.gif'; # 기념비의 이미지를 흐름용
 $alt = "다목적 경기장";
 $alt2 = "선 수$nn(공격($sto)지킴($std)KP($stk)팀성적(승점$kachiten/$stwin 승$stlose 패$stdrow 분/통 산$stwint 승$stloset 패$stdrowt 분/우승$styusho 회)";
 } elsif($l == $HlandZoo) {
 # 동물원
 $image = 'land84.gif'; # 기념비의 이미지를 흐름용
 $alt = "동물원 Lv${lv}";
 $alt2 = "$mshurui 종류$zookazu 마리/$mNameList<br>배리어 A[$bariaA]배리어 B[$bariaB]";
 } elsif($l == $HlandFarm) {
	# 농장
	$image = 'land7.gif';
	$alt = "농장";
	$alt2 = "${lv}0${HunitPop}규모";
 } elsif($l == $HlandEneAt) {
	$image = 'land62.gif';
	$alt = "원자력발전소";
	$alt2 = "출력${lv}만 kW";
 } elsif($l == $HlandEneFw) {
	$image = 'land61.gif';
	$alt = "화력 발전소";
	$alt2 = "출력${lv}만 kW";
 } elsif($l == $HlandEneWt) {
	$image = 'land63.gif';
	$alt = "수력발전소";
	$alt2 = "출력${lv}만 kW/70-150%변동";
 } elsif($l == $HlandEneBo) {
	$image = 'land67.gif';
	$alt = "바이오매스 발전소";
	$alt2 = "출력${lv}만 kW";
 } elsif($l == $HlandEneWd) {
	$image = 'land66.gif';
	$alt = "풍력발전소";
	$alt2 = "출력${lv}만 kW/50-125%변동";
 } elsif($l == $HlandEneCs) {
	$image = 'land70.gif';
	$alt = "코스모 발전소";
	$alt2 = "출력${lv}만 kW";
 } elsif($l == $HlandEneSo) {
	$image = 'land68.gif';
	$alt = "소라발전소";
	$alt2 = "출력${lv}만 kW/75-100%변동";
 } elsif($l == $HlandConden) {
	$image = 'land64.gif';
	$alt = "콘덴서";
	$alt2 = "축적전기${lv}만 kW";
 } elsif($l == $HlandConden2) {
	$image = 'land64.gif';
	$alt = "콘덴서·개정";
	$alt2 = "축적전기${lv}만 kW";
 } elsif($l == $HlandConden3) {
	$vlt = $lv*2;
	$image = 'land76.gif';
	$alt = "황금의 콘덴서";
	$alt2 = "축적전기${vlt}만 kW";
 } elsif($l == $HlandConden4) {
	if($lv == 3) {
	 $n = '황금의 콘덴서';
	 $n2 = '누전안';
	 $image = "land78.gif";
	} elsif($lv == 2) {
	 $n = '콘덴서·개정';
	 $n2 = '누전안';
	 $image = "land77.gif";
	} elsif($lv == 99) {

	 if($magicl == $magica) {
	 $vlt = $magicl*15000+50000;
	 $n = "핵융합발전소";
	 $n2 = "${vlt}만 kW";
	 } else {
	 $n = '핵융합발전소';
	 $n2 = '불안정';
	 }
	 $image = "land79.gif";
	}
	$alt = "$n";
	$alt2 = "$n2";
 } elsif($l == $HlandFoodim) {
	# 연구장소
	my($f);
	if($lv < 480) {
	 $f = '식품 연구소';
	} else {
	 $f = '방재형식품 연구소';
	}
	$image = "land25.gif";
	$alt = "$f";
	$alt2 = "농장 환산${lv}0${HunitPop}규모";

 } elsif($l == $HlandFoodka) {
	# 연구장소
	$klv = $lv*200;
	if($lv == 0) {
	 $n = '가공 공장';
	 $n2 = '휴식업안';
	} elsif($lv == 1) {
	 $n = "정육 공장";
	 $n2 = "100톤&50kW 으로 0.175억 엔·농장&일반직장${klv}0${HunitPop}규모";
	} elsif($lv == 2) {
	 $n = "햄버거 공장";
	 $n2 = "100톤&150kW 으로 0.25억 엔·농장&일반직장${klv}0${HunitPop}규모";
	} elsif($lv == 3) {
	 $n = "케이크 공장";
	 $n2 = "100톤&300kW 으로 0.4억 엔·농장&일반직장${klv}0${HunitPop}규모";
	}
	$image = "land73.gif";
	$alt = "$n";
	$alt2 = "$n2";

 } elsif($l == $HlandFarmchi) {
	$works = $lv;
	$image = 'land31.gif';
	$alt = "양계장";
	$alt2 = "${lv}만 마리/생산력${works}$HunitFood";
 } elsif($l == $HlandFarmpic) {
	$works = $lv*2;
	$image = 'land32.gif';
	$alt = "양돈장";
	$alt2 = "${lv}만 두/생산력${works}$HunitFood";
 } elsif($l == $HlandFarmcow) {
	$works = $lv*3;
	$image = 'land33.gif';
	$alt = "목장";
	$alt2 = "${lv}만 두/생산력${works}$HunitFood";
 } elsif($l == $HlandFactory) {
	# 공장
	$image = 'land8.gif';
	$alt = "공장";
	$alt2 = "${lv}0${HunitPop}규모";
 } elsif($l == $HlandHTFactory) {
	# 첨단 기술 공장
	$image = 'land50.gif';
	$alt = "첨단 기술 다국적 기업";
	$alt2 = "${lv}0${HunitPop}규모";
 } elsif($l == $HlandSHTF) {
	$image = 'land85.gif';
	$alt = "첨단 기술 다국적 기업·개정";
	$alt2 = "HT 일자리${lv}0${HunitPop}규모";
 } elsif($l == $HlandOWNF) {
	$image = 'land86.gif';

	$ownfe = int($lv/1000);
	$shts = int($lv/100)%10*250;
	$hts = int($lv%100/10)*250;
	$noujous = $lv%10*250;

	$n = '';
	if($ownfe> 0) {
	 $n.= '<br><font color = royalblue>(오염된 바다의 독소시약소유)</font>';
	}
	if($ownfe> 1) {
	 $n.= '<br><font color = royalblue>(바이러스 백신 보유)</font>';
	}
	if($ownfe> 2) {
	 $n.= '<br><font color = royalblue>(장 수명약소유)</font>';
	}

	$alt = "$onm 회사";
	$alt2 = "농장${noujous}0${HunitPop}규모<br>직장${hts}0${HunitPop}규모<br>HT 일자리${shts}0${HunitPop}규모${n}";
 } elsif($l == $HlandBase) {
	if($mode == 0) {
	 # 관광객의 경우 숲인 척
	 $image = 'land6.gif';
	 $alt = '숲';
	} else {
	 # 미사일 기지
	 my($level) = expToLevel($l, $lv);
	 $image = 'land9.gif';
	 $alt = "미사일 기지";
	 $alt2 = "레벨 ${level}/경험치 $lv";
	}
 } elsif($l == $HlandSbase) {
	# 해저 기지
	if($mode == 0) {
	 # 관광객의 경우 바다인 척
	 $image = 'land0.gif';
	 $alt = '바다';
	} else {
	 my($level) = expToLevel($l, $lv);
	 $image = 'land12.gif';
	 $alt = "해저 기지";
	 $alt2 = "레벨 ${level}/경험치 $lv";
	}
 } elsif($l == $HlandSeacity) {
	# 해저 도시
	if($mode == 0) {
	 # 관광객의 경우 바다인 척
	 $image = 'land0.gif';
	 $alt = '바다';
	} else {
	 my($level) = expToLevel($l, $lv);
	 $image = 'land17.gif';
	 $alt = "해저 도시";
	 $alt2 = "${lv}$HunitPop";
	}
 } elsif($l == $HlandFrocity) {
	# 해상 도시
	my($level) = expToLevel($l, $lv);
	$image = 'land39.gif';
	$alt = "해상 도시 메가플로트";
 	$alt2 = "${lv}$HunitPop";
 } elsif($l == $HlandMinato) {
	# 항구
	my($level) = expToLevel($l, $lv);
	$image = 'land21.gif';
	$alt = "항구 도시";
	$alt2 = "${lv}$HunitPop";
 } elsif($l == $HlandOnsen) {
	# 온천
	my($level) = expToLevel($l, $lv);
	$image = 'land40.gif';
	$alt = "온천거리";
	$alt2 = "${lv}$HunitPop";
 } elsif($l == $HlandSunahama) {
	# 해변
	$image = 'land38.gif';
	$alt = '해변';
 } elsif($l == $HlandDefence) {
	if($lv == 77) {
	 $image = 'land80.gif';
	 $alt = "방위 시설·개정";
	} else {
	 $image = 'land10.gif';
	 $alt = '방위 시설';
	}
 } elsif($l == $HlandHaribote) {
	# 가짜 기지
	$image = 'land10.gif';
	if($mode == 0) {
	 # 관광객에게는 방위 시설처럼 표시
	 $alt = '방위 시설';
	} else {
	 $alt = '가짜 기지';
	}
 } elsif($l == $HlandNursery) {
 # 양식장
 $image = 'nursery.gif';
 $alt = "양식장";
 $alt2 = "${lv}0${HunitPop}규모";
 } elsif($l == $HlandMine) {
 if($mode == 0) {
 # 관광객의 경우 숲인 척
 $image = 'land6.gif';
 $alt = '숲';
 } else {
 # 지뢰
 $image = 'land22.gif'; # 기념비의 이미지를 흐름용
 $alt = "지뢰";
 $alt2 = "피해$lv";
 }
 } elsif($l == $HlandIce) {

	if($lv> 0) {
	 $image = 'land42.gif';
	 $alt = "천연 스케이트장";
	} else {
	 $image = 'land41.gif';
	 $alt = '빙하';
	}
 } elsif($l == $HlandOil) {
	# 해저 유전
	$image = 'land16.gif';
	$alt = '해저 유전';
 } elsif($l == $HlandGold) {
	# 금광산
	$image = 'land15.gif';
	$alt = "금광산";
	$alt2 = "채굴장${lv}0${HunitPop}규모";
 } elsif($l == $HlandMountain) {
	# 산
	my($str);
	$str = '';
	if($lv> 0) {
	 $image = 'land15.gif';
	 $alt = "산";
	 $alt2 = "채굴장${lv}0${HunitPop}규모";
	} else {
	 $image = 'land11.gif';
	 $alt = '산';
	}
 } elsif($l == $HlandMonument) {
	# 기념비
	$image = $HmonumentImage[$lv];
	$alt = $HmonumentName[$lv];
 } elsif($l == $HlandFune) {
	# fune
	$image = $HfuneImage[$lv];
	$alt = $HfuneName[$lv];
 } elsif($l == $HlandMonster) {
	# 괴수
	my($kind, $name, $hp) = monsterSpec($lv);
	my($special) = $HmonsterSpecial[$kind];
	$image = $HmonsterImage[$kind];

	# 경화 중?
	if((($special == 3) && (($HislandTurn % 2) == 1)) ||
 (($special == 8) && ((seqnum($HislandTurn) % 2) == 0)) ||
	 (($special == 4) && (($HislandTurn % 2) == 0))) {
	 # 경화 중
	 $image = $HmonsterImage2[$kind];
	}
	$alt = "$name";
	$alt2 = "체력${hp}";
 } elsif($l == $HlandPark) {
 # 놀이공원
 $image = 'land19.gif'; # 기념비의 이미지를 흐름용
	$alt = "놀이공원";
	$alt2 = "종업원${lv}0${HunitPop}/수익전망${mikomi}$HunitMoney 이상";
 } elsif($l == $HlandKyujo) {
 # 야구장
 $image = 'land23.gif'; # 기념비의 이미지를 흐름용
 $alt = '야구장';
 } elsif($l == $HlandUmiamu) {
 # 해상 시설
 $image = 'land24.gif'; # 기념비의 이미지를 흐름용
	$alt = "해상 시설";
	$alt2 = "종업원${lv}0${HunitPop}";
 } elsif($l == $HlandSeki) {
 # 관문
 $image = 'land27.gif'; # 기념비의 이미지를 흐름용
 $alt = '관문';
 } elsif($l == $HlandRottenSea) {
 # 오염된 바다
	if($lv> 20) {
	 $image = 'land72.gif';
	 $alt = "고사 바다";
	 $alt2 = "수령$lv 턴";
	} else {
	 $image = 'land20.gif';
	 $alt = "오염된 바다";
	 $alt2 = "수령$lv 턴";
	}
 } elsif($l == $HlandNewtown) {
	# 뉴타운
	my($level) = expToLevel($l, $lv);
	$nwork = int($lv/15);
	$image = 'land28.gif';
	$alt = "뉴타운";
	$alt2 = "${lv}$HunitPop/일반직장${nwork}0$HunitPop";
 } elsif($l == $HlandBigtown) {
	# 현대 도시
	my($level) = expToLevel($l, $lv);
	$mwork = int($lv/20);
	$lwork = int($lv/30);
	$image = 'land29.gif';
	$alt = "현대 도시";
	$alt2 = "${lv}$HunitPop/일반직장${mwork}0$HunitPop/농장${lwork}0$HunitPop";
 } elsif($l == $HlandRizort) {
	# 리조트
	my($level) = expToLevel($l, $lv);
	$rwork = $lv+$eis1+$eis2+$eis3+$eis5+int($fore/10)+int($rena/25)-$monsterlive*100;
	$image = 'land43.gif';
	$alt = "리조트";
	$alt2 = "체류 관광객${lv}$HunitPop";
 } elsif($l == $HlandKajino) {
	# 카지노
	my($level) = expToLevel($l, $lv);
	$rwork = int(($lv+$eis1+$eis2+$eis3+$eis5+int($fore/10)+int($rena/10)-$monsterlive*100)/5);
	$image = 'land74.gif';
	$alt = "카지노";
	$alt2 = "체류 관광객${lv}$HunitPop";
 } elsif($l == $HlandBigRizort) {
	# 리조트
	my($level) = expToLevel($l, $lv);
	$image = 'land49.gif';
	$alt = "임시 해변 리조트 호텔";
	$alt2 = "체류 관광객${lv}$HunitPop";
 } elsif($l == $HlandShuto) {
	# 수도
	my($level) = expToLevel($l, $lv);
	$image = 'land29.gif';
	$alt = "수도$totoyoso2";
	$alt2 = "${lv}$HunitPop";
 } elsif($l == $HlandUmishuto) {
	# 바다 수도
	if($mode == 0) {
	 # 관광객의 경우 바다인 척
	 $image = 'land0.gif';
	 $alt = '바다';
	} else {
	my($level) = expToLevel($l, $lv);
	$image = 'land30.gif';
	$alt = "해저 수도$totoyoso2";
	$alt2 = "${lv}$HunitPop";
	}
 } elsif($l == $HlandBettown) {
	# 고층 도시
	my($level) = expToLevel($l, $lv);
	$image = 'land45.gif';
	$alt = "고층 도시";
	$alt2 = "${lv}$HunitPop";
 } elsif($l == $HlandSkycity) {
	# 공업 도시
	my($level) = expToLevel($l, $lv);
	$mwork = int($lv/60);
	$lwork = int($lv/60);
	$ework = int($lv/2)*3;
	$image = 'land81.gif';
	$alt = "공업 도시";
	$alt2 = "${lv}$HunitPop/HT 일자리${mwork}0$HunitPop/농장${lwork}0$HunitPop/전력소비${ework}만 kW";
 } elsif($l == $HlandUmicity) {
	# 바다 도시
	my($level) = expToLevel($l, $lv);
	$mwork = int($lv/60);
	$lwork = int($lv/60);
	$ework = int($lv/2)*3;
	$image = 'land82.gif';
	$alt = "바다 도시";
	$alt2 = "${lv}$HunitPop/HT 일자리${mwork}0$HunitPop/농장${lwork}0$HunitPop/전력소비${ework}만 kW";
 } elsif($l == $HlandSeatown) {
	# 해저 신도시
	if($mode == 0) {
	 # 관광객의 경우 바다인 척
	 $image = 'land0.gif';
	 $alt = '바다';
	} else {
	my($level) = expToLevel($l, $lv);
	$owork = int($lv/40);
	$image = 'land30.gif';
	$alt = "해저 신도시";
	$alt2 = "${lv}$HunitPop/일반직장${owork}0$HunitPop/농장${owork}0$HunitPop";
	}
 }

 if($x < $HislandSize / 2) {
	$position = 0;
 } else {
	$position = 1;
 }
 if($y < $HislandSize / 2) {
	$position2 = 0;
 } else {
	$position2 = 1;
 }

 if($HmainMode2 eq 'ijiri') {
	$alt2.= "<br>land = <font color = red>${l}</font><br>landValue = <font color = red>${lv}</font>";
 }

 my($alt1) = $alt;
 $alt1 =~ s/<[^>]*>//g;
 $alt1 =~ s/\\/\\\\/g;
 $alt1 =~ s/'/\\'/g;
 my($statusAlt) = $alt;
 $statusAlt =~ s/<[^>]*>//g;
 $statusAlt =~ s/\\/\\\\/g;
 $statusAlt =~ s/'/\\'/g;
 my($statusAlt2) = $alt2;
 $statusAlt2 =~ s/<br>/ /ig;
 $statusAlt2 =~ s/<[^>]*>//g;
 $statusAlt2 =~ s/\\/\\\\/g;
 $statusAlt2 =~ s/'/\\'/g;
 my($statusCom) = $comStr;
 $statusCom =~ s/<br>/ /ig;
 $statusCom =~ s/<[^>]*>//g;
 $statusCom =~ s/\\/\\\\/g;
 $statusCom =~ s/'/\\'/g;

 if(($mode == 1) && ($HjavaMode eq 'java')) {
	out(qq|<A HREF="JavaScript:void(0);" onclick="ps($x,$y);set_land($x, $y, '$point\\n $alt1', '$image');" |);
	out(qq|onMouseOver="set_com($x, $y, '$point $alt1');MM_displayStatusMsg('$point $statusAlt $statusAlt2 $statusCom'); return true;" onMouseOut="not_com();MM_displayStatusMsg(''); return false;">|);
	out(qq|<IMG SRC="$image" width=32 height=32 BORDER=0 TITLE="$point $alt $comStr"></A>|);
 } else {
	# 개발 화면 또는 JavaScript 좌표 선택용 지도일 경우 좌표 설정
	if(($mode == 1) || ($HmainMode eq 'islandMap')) {
		out("<A HREF=\"JavaScript:void(0);\" onclick=\"ps($x,$y)\">");
	}

	out("<IMG SRC=\"$image\" width=32 height=32 BORDER=0 onMouseOver=\"MM_displayStatusMsg('$point $statusAlt $statusAlt2 $statusCom'); Navi($HislandSize, $position, $position2, $x, $y,'$image', '$alt', '$alt2<br>$comStr', '$NaviText', ''); return true\" onMouseOut=\"MM_displayStatusMsg(''); NaviClose(); return false\">");

	# 좌표 설정 닫기
	if(($mode == 1) || ($HmainMode eq 'islandMap')) {
		out("</A>");
	}
 }
}

#----------------------------------------------------------------------
# 템플릿기타
#----------------------------------------------------------------------
# 개별 로그 표시
sub logPrintLocal {
 my($mode) = @_;
 my($i);
 for($i = 0; $i < $HlogMax; $i++) {
	logFilePrint($i, $HcurrentID, $mode);
 }
}

# ○○섬 관광 화면
sub tempPrintIslandHead {
 out(<<END);
<CENTER>
${HtagBig_}${HtagName_}'${HcurrentName} 섬'${H_tagName}입니다.${H_tagBig}<BR>
$HtempBack<BR>
</CENTER>
END
}


#------------------------------------------------------------------
# JavaScript 개발 계획 화면
#------------------------------------------------------------------
sub tempOwnerJava {
 $HcurrentNumber = $HidToNumber{$HcurrentID};
 my($island) = $Hislands[$HcurrentNumber];

 my($set_com, $com_max) = ('', '');
 for(my $i = 0; $i < $HcommandMax; $i++) {
	my($command) = $island->{'command'}->[$i];
	my($s_kind, $s_target, $s_x, $s_y, $s_arg) = (
		$command->{'kind'}, $command->{'target'}, $command->{'x'}, $command->{'y'}, $command->{'arg'}
	);
	$set_com .= "[$s_kind,$s_x,$s_y,$s_arg,$s_target]";
	$set_com .= ",\n" if($i < $HcommandMax - 1);
	$com_max .= "0";
	$com_max .= "," if($i < $HcommandMax - 1);
 }

 my($set_listcom) = '';
 my(@click_com) = ('') x 10;
 my($All_listCom) = 0;
 $com_count = scalar(@HcommandDivido);
 for(my $m = 0; $m < $com_count; $m++) {
	my($aa,$dd,$ff) = split(/,/, $HcommandDivido[$m]);
	$set_listcom .= "[ ";
	for(my $i = 0; $i < $HcommandTotal; $i++) {
		my($l_kind) = $HcomList[$i];
		next if($l_kind eq '');
		next if($l_kind < $dd || $l_kind > $ff);
		my($l_cost) = $HcomCost[$l_kind];
		if($l_kind == $HcomHouse) { $l_cost = $island->{'pts'} * 3; }
		elsif(($l_kind == $HcomBettown) || ($l_kind == $HcomKai)) { $l_cost = $island->{'pts'}; }
		if($l_cost == 0) { $l_cost = '무료'; }
		elsif($l_cost < 0) { $l_cost = (-$l_cost) . $HunitFood; }
		else { $l_cost .= $HunitMoney; }
		my($name) = $HcomName[$l_kind];
		$name =~ s/'/\\'/g;
		$set_listcom .= "[$l_kind,'$name','$l_cost'],\n";

		# 지도 클릭 팝업은 '선택한 좌표에 바로 적용할 명령'만 표시한다.
		# 자금 융통, 지원, 섬 포기, 자동 입력, 옥션/관리 명령은
		# 좌표 클릭과 직접 관계가 없으므로 왼쪽 개발계획 선택 목록에만 둔다.
		my($is_popup_command) = 1;
		if(($l_kind >= 41) && ($l_kind <= 69)) {
			$is_popup_command = 0;
		}
		if(defined($HcomAuction) && ($l_kind == $HcomAuction)) {
			$is_popup_command = 0;
		}
		if(defined($HcomIjiri) && ($l_kind == $HcomIjiri)) {
			$is_popup_command = 0;
		}
		if($is_popup_command) {
			$click_com[$m] .= "<a title='$l_cost' href='javascript:void(0);' onClick='cominput(myForm,6,$l_kind)' STYLE='text-decoration:none'>$HcomName[$l_kind]</a><br>\n";
		}
		$All_listCom++;
	}
	$set_listcom =~ s/,\n$//;
	$set_listcom .= " ],\n";
 }
 $set_listcom =~ s/,\n$//;
 my($default_Kind) = ($HdefaultKind eq '') ? $HcomDoNothing : $HdefaultKind;

 my($set_island) = '';
 for(my $i = 0; $i < $HislandNumber; $i++) {
	my($l_name) = $Hislands[$i]->{'name'};
	$l_name =~ s/<[^<]*>//g;
	$l_name =~ s/'/\\'/g;
	my($l_id) = $Hislands[$i]->{'id'};
	$set_island .= "[$l_id,'$l_name']";
	$set_island .= ",\n" if($i < $HislandNumber - 1);
 }

 out(<<END);
<CENTER>
${HtagBig_}${HtagName_}${HcurrentName} 섬${H_tagName} 개발 계획(JavaScript 모드)${H_tagBig}<BR>
$HtempBack<BR>
</CENTER>
<SCRIPT Language="JavaScript">
<!--
var str;
d_Kind = $default_Kind;
d_ID = $HcurrentID;
All_list = $All_listCom;
g = [$com_max];
k1 = [$com_max];
k2 = [$com_max];
tmpcom1 = [ [0,0,0,0,0] ];
tmpcom2 = [ [0,0,0,0,0] ];
command = [
$set_com];
comlist = [
$set_listcom
];
islname = [
$set_island];
//-->
</SCRIPT>
END
 require('./hako-js.cgi');
 makeJS(0);

 out(<<END);
<DIV ID="menu" style="position:absolute; display:none; visibility:hidden; z-index:9999; background-color:#E0FFFF; border:1px solid #666666; padding:3px;">
<TABLE BORDER=0 class="PopupCell" STYLE="background-color:#E0FFFF; border:0; font-size:12px; line-height:1.35;">
<TR><TD class='T' colspan=2>
<FORM name='POPUP'>
<IMG NAME="NAVIIMG" SRC="" width=32 height=32 align="left">
<TEXTAREA NAME="COMSTATUS" rows="2" cols="22" class="popupnavi"></TEXTAREA>
</FORM>
</TD></TR>
<TR><TD>
$click_com[0]<hr>
$click_com[1]<hr>
$click_com[2]
</TD><TD>
$click_com[5]<hr>
$click_com[6]
</TD></TR>
<TR><TD colspan=2><a href="Javascript:void(0);" onClick="menuclose()" STYLE="text-decoration:none">메뉴 닫기</A></TD></TR>
</TABLE>
</DIV>
END

 islandInfo();
 out(<<END);
<CENTER><TABLE BORDER><TR valign=top>
<TD $HbgInputCell width=25%>
<CENTER>
<FORM name="myForm" action="$HthisFile" method=POST>
<B>계획번호</B><SELECT NAME=NUMBER>
END
 for(my $i = 0; $i < $HcommandMax; $i++) {
	my $j = $i + 1;
	out("<OPTION VALUE=$i>$j\n");
 }
 my($open) = ($HmenuOpen eq 'CHECKED') ? 'CHECKED' : '';
 out(<<END);
</SELECT><BR><HR>
<B>개발 계획</B>
<INPUT TYPE="checkbox" NAME="MENUOPEN" onClick="check_menu()" $open>팝업 메뉴 숨김<br>
<SELECT NAME=menu onchange="SelectList(myForm)">
<OPTION VALUE=>전체 종류
END
 for(my $i = 0; $i < $com_count; $i++) {
	my($aa) = split(/,/, $HcommandDivido[$i]);
	out("<OPTION VALUE=$i>$aa\n");
 }
 out(<<END);
</SELECT><br>
<SELECT NAME=COMMAND><option> </option></SELECT>
<HR>
<B>명령 입력</B><BR><B>
<A HREF=JavaScript:void(0); onClick="cominput(myForm,1)">삽입</A>
 <A HREF=JavaScript:void(0); onClick="cominput(myForm,2)">덮어쓰기</A>
 <A HREF=JavaScript:void(0); onClick="cominput(myForm,3)">삭제</A>
</B><HR>
<B>좌표(</B><SELECT NAME=POINTX>
END
 for(my $i = 0; $i < $HislandSize; $i++) {
	my $sel = ($i == $HdefaultX) ? 'SELECTED' : '';
	out("<OPTION VALUE=$i $sel>$i\n");
 }
 out("</SELECT>, <SELECT NAME=POINTY>\n");
 for(my $i = 0; $i < $HislandSize; $i++) {
	my $sel = ($i == $HdefaultY) ? 'SELECTED' : '';
	out("<OPTION VALUE=$i $sel>$i\n");
 }
 out(<<END);
</SELECT><B>)</B><HR>
<B>수량</B><SELECT NAME=AMOUNT>
END
 for(my $i = 0; $i < 100; $i++) { out("<OPTION VALUE=$i>$i\n"); }
 my($myislandID) = $defaultTarget;
 $myislandID = $island->{'id'} if($myislandID eq '');
 out(<<END);
</SELECT><HR>
<B>대상 섬</B>:
<B><A HREF=JavaScript:void(0); onClick="jump(myForm, '$HjavaMode')"> 표시 </A></B>
· <B><A HREF=JavaScript:void(0); onClick="myisland(myForm,'$myislandID')"> 선택 </A></B><BR>
<SELECT NAME=TARGETID>
$HtargetList<BR>
</SELECT>
<HR>
<B>명령 이동</B>:
<BIG><A HREF=JavaScript:void(0); onClick="cominput(myForm,4)" STYLE="text-decoration:none"> ▲ </A>..
<A HREF=JavaScript:void(0); onClick="cominput(myForm,5)" STYLE="text-decoration:none"> ▼ </A></BIG>
<HR>
<INPUT TYPE="hidden" NAME="COMARY" value="">
<INPUT TYPE="hidden" NAME="JAVAMODE" value="$HjavaMode">
<INPUT TYPE=submit VALUE="계획 전송" NAME=CommandJavaButton$Hislands[$HcurrentNumber]->{'id'}>
<br><font size=2>마지막에 <span class='attention'>계획 전송</span>을 눌러야 저장됩니다.</font>
<HR>
<B>비밀번호</B><BR>
<INPUT TYPE=password NAME=PASSWORD VALUE="$HdefaultPassword">
</CENTER>
</TD>
<TD $HbgMapCell><center>
<TEXTAREA NAME="COMSTATUS" cols="48" rows="2"></TEXTAREA>
</center>
END
 islandMap(1);
 out(<<END);
</FORM>
</TD>
<TD BGCOLOR="LAVENDER" id="plan">
<FORM name="allForm" action="$HthisFile" method=POST onSubmit="return setAutoInsertPoint();">
<INPUT TYPE="hidden" NAME=PASSWORD VALUE="$HdefaultPassword">
<INPUT TYPE="hidden" NAME=MENUOPEN VALUE="allmenu">
<INPUT TYPE="hidden" NAME=NUMBER VALUE="0">
<INPUT TYPE="hidden" NAME=POINTY VALUE="0">
<INPUT TYPE="hidden" NAME=POINTX VALUE="0">
<INPUT TYPE="hidden" NAME=JAVAMODE value="$HjavaMode"><br>
<DIV ID='AutoCommand'><B>자동 입력</B><br>
<SELECT NAME=COMMAND>
END
 my %auto_command = map { $_ => 1 } grep { defined($_) && $_ ne '' } (
	$HcomAutoReclaim,
	$HcomAutoDestroy,
	$HcomAutoSellTree,
	$HcomAutoForestry,
	$HcomAutoPrepare,
	$HcomAutoPrepare2,
	$HcomAutoYoyaku,
	$HcomAutoUchuste,
	$HcomAutoDelete
 );
 for(my $i = 0; $i < $HcommandTotal; $i++) {
	my $kind = $HcomList[$i];
	next if($kind eq '');
	next unless($auto_command{$kind});
	my $cost = $HcomCost[$kind];
	$cost = '무료' if($cost == 0);
	out("<OPTION VALUE=$kind>$HcomName[$kind]($cost)\n");
 }
 out(<<END);
</SELECT><br>
<B>벌채 수량</B><SELECT NAME=AMOUNT>
END
 for(my $i = 0; $i < 100; $i++) { out("<OPTION VALUE=$i>$i\n"); }
 out(<<END);
</SELECT>×200본 이상<br>
<INPUT TYPE=submit VALUE="자동 입력 실행" NAME=CommandButton$Hislands[$HcurrentNumber]->{'id'}>
</DIV>
</FORM>
<DIV ID="PARENT_LINKMSG"><DIV ID="LINKMSG1"></DIV></DIV>
</TD></TR></TABLE></CENTER>
<SCRIPT Language="JavaScript">
<!--
if(window.addEventListener) {
 window.addEventListener('load', function(){ SelectList(''); init(); }, false);
} else if(window.attachEvent) {
 window.attachEvent('onload', function(){ SelectList(''); init(); });
} else {
 window.onload = function(){ SelectList(''); init(); };
}
//-->
</SCRIPT>
END
}

#------------------------------------------------------------------
# JavaScript 모드 좌표 선택용 지도
#------------------------------------------------------------------
sub printIslandJava {
 unlock();
 $HcurrentNumber = $HidToNumber{$HcurrentID};
 if($HcurrentNumber eq '') { tempProblem(); return; }
 my($island) = $Hislands[$HcurrentNumber];
 $HcurrentName = $island->{'name'};
 out(<<END);
<CENTER>
${HtagBig_}${HtagName_}${HcurrentName} 섬${H_tagName}${HtagBig}<BR>
공격 또는 개발할 지점을 클릭해 주세요.<BR>
클릭한 지점이 개발 화면의 좌표로 설정됩니다.
</CENTER>
<SCRIPT Language="JavaScript">
<!--
function ps(x, y) {
 if(window.opener && window.opener.document && window.opener.document.myForm) {
	window.opener.document.myForm.POINTX.options[x].selected = true;
	window.opener.document.myForm.POINTY.options[y].selected = true;
 }
 return true;
}
//-->
</SCRIPT>
END
 islandMap(0);
 tempRecent(0);
}

# ○○섬개발 계획
sub tempOwner {
 out(<<END);
<CENTER>
${HtagBig_}${HtagName_}${HcurrentName} 섬${H_tagName}개발 계획${H_tagBig}<BR>
$HtempBack<BR>
</CENTER>

<SCRIPT Language="JavaScript">
<!--
function ps(x, y) {
 document.forms[0].elements[4].options[x].selected = true;
 document.forms[0].elements[5].options[y].selected = true;
 return true;
}

function ns(x) {
 document.forms[0].elements[2].options[x].selected = true;
 return true;
}

//-->
</SCRIPT>
END

 islandInfo();

 out(<<END);
<CENTER>
<TABLE BORDER>
<TR>
<TD $HbgInputCell>
<CENTER>
<FORM action="$HthisFile" method=POST>
<INPUT TYPE=submit VALUE="계획 전송" NAME=CommandButton$Hislands[$HcurrentNumber]->{'id'}>
<HR>
<B> 비밀번호</B></BR>
<INPUT TYPE=password NAME=PASSWORD VALUE="$HdefaultPassword">
<HR>
<B>계획번호</B><SELECT NAME=NUMBER>
END
 # 계획번호
 my($j, $i);
 for($i = 0; $i < $HcommandMax; $i++) {
	$j = $i + 1;
	out("<OPTION VALUE=$i>$j\n");
 }

 out(<<END);
</SELECT><BR>
<HR>
END


 my($island) = $Hislands[$HcurrentNumber];

			 if($island->{'pts'}> $HouseLevel9) {
			 	 $costx = 2;
			 } elsif($island->{'pts'}> $HouseLevel8) {
			 	 $costx = 1.8;
			 } elsif($island->{'pts'}> $HouseLevel7) {
				 $costx = 1.8;
			 } elsif($island->{'pts'}> $HouseLevel6) {
			 	 $costx = 1.6;
			 } elsif($island->{'pts'}> $HouseLevel5) {
				 $costx = 1.6;
			 } elsif($island->{'pts'}> $HouseLevel4) {
			 	 $costx = 1.4;
			 } elsif($island->{'pts'}> $HouseLevel3) {
				 $costx = 1.4;
			 } elsif($island->{'pts'}> $HouseLevel2) {
			 	 $costx = 1.2;
			 } elsif($island->{'pts'}> $HouseLevel1) {
				 $costx = 1;
			 } else {
				 $costx = 1;
			 }

	$costxx = "";

 if ($anothermood != 1) {
	 $costshusei = $costx;
	 $costxx = "<br>개발도 수정…x${costx}";
	} else {
	 $costshusei = 1;
	}

 my($factory) = $island->{'factory'};
	$factory =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	($factory1, $factory2, $co0, $co1, $htf, $shtf, $co95, $co95, $co95, $co95) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10);

	$costco95 = int(0.975**$co95*1000)/1000;

	 if($costco95 < 0.9) {
		$costco95 = 0.9;
	 }

	$costhtf = "";
	$costshtf = "";
	$costco95b = "";

	 if($htf> 0) {
		$costhtf = "<br>첨단 기술 다국적 기업…x0.666";
		$costshusei = $costshusei*2/3;
	 }
	 elsif($shtf> 0) {
		$costshtf = "<br>첨단 기술 다국적 기업·개정…x0.9";
		$costshusei = $costshusei*9/10;
	 }
	 if($co95> 0) {
		$costco95b = "<br>경제대학(저금안)…x${costco95}";
		$costshusei = $costshusei*$costco95;
	 }

	$etc5 = $island->{'etc5'};
	$etc5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	($s00,$s01,$s02,$s03,$s04,$s05,$s06,$s07,$s08,$s09,$s10,$s11,$s12,$s13,$s14,$s15,$s16,$s17,$s18,$s19,$s20,$s21,$s22,$s23,$s24,$s25,$s26,$s27,$s28,$s29,$s30) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);

	$costseisaku = $s01+$s03+$s05+$s07+$s09+$s11+$s13+$s15+$s17+$s19+$s21+$s23+$s25+$s27+$s29+$s02+$s04+$s06+$s08+$s10+$s12+$s14+$s16+$s18+$s20+$s22+$s24+$s26+$s28+$s30;
	$costseisaku2 = int(0.9975**$costseisaku*1000)/1000;
	$costseisaku3 = "";

	 if($costseisaku2 < 0.75) {
		$costseisaku2 = 0.75;
	 }

	 if($s00> 0) {
		$costseisaku3 = "<br>문부과학성…x${costseisaku2}";
		$costshusei = $costshusei*$costseisaku2;
	 }

	$s12b = int($s12/5)+1;
	if($s12b> 10) {$s12b = 10;}

	$costmoney = int(($island->{'money'}/5/(999999*$s12b)+0.8)*1000)/1000;
	$costmoney2 = "소지 자금…x${costmoney}";
	$costshusei = $costshusei*$costmoney;

	$costshusei = int($costshusei*1000)/1000;

	$costshusei = ($costshusei == 1) ? "없음" : "x${costshusei}";

	$alt = "비용 수정($costshusei)";
	$alt2 = "$costmoney2$costxx$costseisaku3$costhtf$costshtf$costco95b";

 out(<<END);

<B>개발 계획</B><BR>
<FONT size=-1>
<SELECT NAME=COMMAND onMouseOver=\"MM_displayStatusMsg('$alt/$alt2'); Navi2($HislandSize, 'black.gif', '$alt', '$alt2', '$NaviText', ''); return true\" onMouseOut=\"MM_displayStatusMsg(''); NaviClose(); return false\"></font>
END

 #명령
 my($kind, $cost, $s);

 if($HmainMode2 eq 'ijiri') {
	 out("<OPTION VALUE=$HcomIjiri $s>$HcomName[$HcomIjiri]\n");
 }

 for($i = 0; $i < $HcommandTotal; $i++) {
	$kind = $HcomList[$i];
	$cost = $HcomCost[$kind];

 my($island) = $Hislands[$HcurrentNumber];

 if($anothermood == 1) {
	 if($kind == $HcomHouse) {
		$cost = $island->{'pts'}*2;
	 }
	 if($kind == $HcomKai) {
		$cost = $island->{'pts'}*2;
	 }
	 if($kind == $HcomBoku2) {
		$cost = $island->{'pts'}*4;
	 }
 } else {
	 if($kind == $HcomHouse) {
		$cost = $island->{'pts'}*3;
	 }
	 if($kind == $HcomBettown) {
		$cost = $island->{'pts'};
	 }
	 if($kind == $HcomKai) {
		$cost = $island->{'pts'};
	 }
	 if($kind == $HcomBoku2) {
		$cost = $island->{'pts'}*4;
	 }
 }

 if (($anothermood != 1) && ($kind != $HcomKura) && ($kind != $HcomKura2) && ($kind != $HcomKuraf) && ($kind != $HcomHouse) && ($kind != $HcomBettown) && ($kind != $HcomKai) && ($kind != $HcomBoku2) && ($kind != $HcomEneCs) && ($kind != $HcomEneNF) && ($kind != $HcomEisei) && ($kind != $HcomSell) && ($kind != $HcomMoney) && ($kind != $HcomFood) && ($kind != $HcomGivefood)) {
	$cost = $cost * $costx;
 }

 if (($htf> 0) && ($kind != $HcomKura) && ($kind != $HcomKura2) && ($kind != $HcomKuraf) && ($kind != $HcomSell) && ($kind != $HcomMoney) && ($kind != $HcomFood) && ($kind != $HcomGivefood)) {
	$cost = int($cost * 2 / 3);
 } elsif (($shtf> 0) && ($kind != $HcomKura) && ($kind != $HcomKura2) && ($kind != $HcomKuraf) && ($kind != $HcomSell) && ($kind != $HcomMoney) && ($kind != $HcomFood) && ($kind != $HcomGivefood)) {
	$cost = int($cost * 9 / 10);
 }
 if (($co95> 0) && ($kind != $HcomKura) && ($kind != $HcomKura2) && ($kind != $HcomKuraf) && ($kind != $HcomSell) && ($kind != $HcomMoney) && ($kind != $HcomFood) && ($kind != $HcomGivefood)) {
	$cost = int($cost * $costco95);
 }
 if (($s00> 0) && ($kind != $HcomKura) && ($kind != $HcomKura2) && ($kind != $HcomKuraf) && ($kind != $HcomSell) && ($kind != $HcomMoney) && ($kind != $HcomFood) && ($kind != $HcomGivefood)) {
	$cost = int($cost * $costseisaku2);
 }
 if (($kind != $HcomKura) && ($kind != $HcomKura2) && ($kind != $HcomKuraf) && ($kind != $HcomSell) && ($kind != $HcomMoney) && ($kind != $HcomFood) && ($kind != $HcomGivefood)) {
	$cost = int($cost * $costmoney);
 }

	if($cost == 0) {
	 $cost = '무료';
	} elsif($cost < 0) {
	 $cost = - $cost;
	 $cost.= $HunitFood;
	} else {
	 $cost.= $HunitMoney;
	}
	if($kind == $HdefaultKind) {
	 $s = 'SELECTED';
	} else {
	 $s = '';
	}

	out("<OPTION VALUE=$kind $s>$HcomName[$kind]($cost)\n");
 }

 my($rank) = $HcurrentNumber + 1;

	$auc6 = $island->{'auc6'};
	$auc6 =~ /^([0-9]*),([0-9]*),([0-9]*)$/;
	($auc6a, $auc6x, $auc6y) = ($1, $2, $3);
	$auction1 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	($shuppin1, $avalue1, $ajoutai1, $topvalue1, $topid1) = ($1, $2, $3, $4, $5);
	$auction2 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	($shuppin2, $avalue2, $ajoutai2, $topvalue2, $topid2) = ($1, $2, $3, $4, $5);
	$auction3 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	($shuppin3, $avalue3, $ajoutai3, $topvalue3, $topid3) = ($1, $2, $3, $4, $5);

 if(($rank < 50) && ($auc6a == 1) && (($shuppin1 == 29) || ($shuppin2 == 29) || ($shuppin3 == 29))) {
	 out("<OPTION VALUE=$HcomAuction $s>$HcomName[$HcomAuction]($cost)\n");
 }

 out(<<END);
</SELECT>
<HR>
<B>좌표(</B>
<SELECT NAME=POINTX>

END
 for($i = 0; $i < $HislandSize; $i++) {
	if($i == $HdefaultX) {
	 out("<OPTION VALUE=$i SELECTED>$i\n");
 } else {
	 out("<OPTION VALUE=$i>$i\n");
 }
 }

 out(<<END);
</SELECT>, <SELECT NAME=POINTY>
END

 for($i = 0; $i < $HislandSize; $i++) {
	if($i == $HdefaultY) {
	 out("<OPTION VALUE=$i SELECTED>$i\n");
 } else {
	 out("<OPTION VALUE=$i>$i\n");
 }
 }
 out(<<END);
</SELECT><B>)</B>
<HR>


END
 if($HmainMode2 eq 'ijiri') {
 out(<<END);
 <SELECT NAME=LAMOUNT1>
END

	 out("<OPTION VALUE='-15' SELECTED>동물원 반입\n");
	 out("<OPTION VALUE='-10' SELECTED>부적 수\n");
	 out("<OPTION VALUE='-9' SELECTED>기상위성\n");
	 out("<OPTION VALUE='-8' SELECTED>관측위성\n");
	 out("<OPTION VALUE='-7' SELECTED>요격위성\n");
	 out("<OPTION VALUE='-6' SELECTED>군사위성\n");
	 out("<OPTION VALUE='-5' SELECTED>방위위성\n");
	 out("<OPTION VALUE='-4' SELECTED>비정상\n");
	 out("<OPTION VALUE='-3' SELECTED>수도의 이름\n");
	 out("<OPTION VALUE='-2' SELECTED>우주 정거장인구\n");
	 out("<OPTION VALUE='-18' SELECTED>사카(KP)\n");
	 out("<OPTION VALUE='-17' SELECTED>사카(지킴)\n");
	 out("<OPTION VALUE='-16' SELECTED>사카(공격)\n");
	 out("<OPTION VALUE='-14' SELECTED>생물 대학 SP\n");
	 out("<OPTION VALUE='-13' SELECTED>생물 대학 DP\n");
	 out("<OPTION VALUE='-12' SELECTED>생물 대학 AP\n");
	 out("<OPTION VALUE='-11' SELECTED>생물 대학 HP\n");
	 out("<OPTION VALUE='-1' SELECTED>생물 대학 경험치\n");

 for($i = 0; $i < 71; $i++) {
	$landName = landName($i, 0);

	if($i == $HdefaultLamount1) {
	 out("<OPTION VALUE=$i SELECTED>$landName\n");
 } else {
	 out("<OPTION VALUE=$i>$landName\n");
 }

 }
 out(<<END);
</SELECT>
<INPUT TYPE=text NAME=LAMOUNT2 SIZE=4 VALUE="$lamount2">
<hr>
END
}
 out(<<END);


<B>수량</B><SELECT NAME=AMOUNT>
END

 # 수량
 for($i = 0; $i < 100; $i++) {

	if($HmainMode2 eq 'ijiri') {
	 if($i == 0) {
		$i2 = '단체';
	 } elsif($i == 1) {
		$i2 = '일괄';
	 } else {
		$i2 = $i;
	 }
	} else {
	 $i2 = $i;
	}

	out("<OPTION VALUE=$i>$i2\n");
 }

 out(<<END);
</SELECT>
<HR>
<B>대상 섬</B><BR>
<FONT size=-1><SELECT NAME=TARGETID>
$HtargetList<BR>
</SELECT></FONT>
<HR>
<B>동작</B><BR>
<INPUT TYPE=radio NAME=COMMANDMODE VALUE=insert CHECKED>삽입
<INPUT TYPE=radio NAME=COMMANDMODE VALUE=write>덮어쓰기<BR>
<INPUT TYPE=radio NAME=COMMANDMODE VALUE=delete>삭제
<HR>
<INPUT TYPE=submit VALUE="계획 전송" NAME=CommandButton$Hislands[$HcurrentNumber]->{'id'}>
$seisaku
</CENTER>
</FORM>
</TD>
<TD $HbgMapCell>
END
 islandMap(1); # 섬 지도, 소유자 모드
 out(<<END);
<CENTER>
<FORM action="$HthisFile" method="POST" target="_blank">
<B>관광할 섬</B><SELECT NAME=TARGETID>$HtargetList<BR></SELECT>
<INPUT TYPE="submit" VALUE="화면 열기" NAME="SightButton"><br><br>
</FORM>
END

 my($island) = $Hislands[$HcurrentNumber];
 # 정보 표시
 my($rank) = $HcurrentNumber + 1;
	if ($rank> 20)
	 {$aucs3.= "<br>③<font color=\"royalblue\"><B>$ac3</B></font>/<font color=\"SALMON\"><B>$topvalue3조 엔이상</B></font>$acjo3"};
	if ($rank < 21)
	 {$aucs3 = ""};

	if (($rank < 51) && ($auc6a == 1) && (($shuppin1 == 29) || ($shuppin2 == 29) || ($shuppin3 == 29)))
	 {$aucs6.= "<font color=\"red\">(출품 가능)</font>"};
	if (($rank> 50) || ($auc6a != 1) || (($shuppin1 != 29) && ($shuppin2 != 29) && ($shuppin3 != 29)))
	 {$aucs6 = ""};

	if ($auc6a> 2)
	 {$aucs6.= "<font color=\"red\">(입찰불가)</font>"};

 out(<<END);

<FORM action="$HthisFile" method=POST>
<B>Hakoniwa Auction</B>$aucs6
<br>①<font color="royalblue"><B>$ac1</B></font>/<font color="SALMON"><B>$topvalue1조 엔이상</B></font>$acjo1
<br>②<font color="royalblue"><B>$ac2</B></font>/<font color="SALMON"><B>$topvalue2조 엔이상</B></font>$acjo2
$aucs3
<br> 비밀번호<INPUT TYPE=password NAME=PASSWORD VALUE="$HdefaultPassword" SIZE=10>


상품 번호<SELECT NAME=AUCNUMBER>
END
 my($i);
 for($i = 1; $i < 3; $i++) {
	out("<OPTION VALUE=$i>$i\n");
 }

 if ($rank> 20) {
	 out("<OPTION VALUE=3>3\n");
 }

 out(<<END);
</SELECT>

금액+<SELECT NAME=AMOUNT>
END

 # 수량
 for($i = 1; $i < 100; $i++) {
	out("<OPTION VALUE=$i>$i\n");
 }

 out(<<END);
</SELECT>조 엔
$nyuusatu
</FORM>
</CENTER>
</TD>
<TD $HbgCommandCell>
END
 for($i = 0; $i < $HcommandMax; $i++) {
	tempCommand($i, $Hislands[$HcurrentNumber]->{'command'}->[$i]);
 }
 my $comment = $Hislands[$HcurrentNumber]->{'comment'};
 out(<<END);

</TD>
</TR>
</TABLE>
</CENTER>
<HR>
<CENTER>
${HtagBig_}코멘트갱신${H_tagBig}<BR>
<FORM action="$HthisFile" method="POST">
코멘트<INPUT TYPE=text NAME=MESSAGE SIZE=80 VALUE="$comment"><BR>
비밀번호<INPUT TYPE=password NAME=PASSWORD VALUE="$HdefaultPassword">
<INPUT TYPE=submit VALUE="코멘트갱신" NAME=MessageButton$Hislands[$HcurrentNumber]->{'id'}>
$kakushuyoso
$shutohen

<BR>
대상 섬<SELECT NAME=TARGETID>$HtargetList<BR></SELECT>
유효 턴 수<SELECT NAME=AMOUNT>
END

 # 수량
 for($i = 0; $i < 25; $i++) {
	out("<OPTION VALUE=$i>$i\n");
 }


 for($ii = 0; $ii < $HislandNumber; $ii++) {
	$j = $ii + 1;
	$island = $Hislands[$ii];

	$etc7 = $island->{'etc7'};
	$etc7 =~ /^([0-9]*),([0-9]*),([0-9]*)$/;
	($msjotai, $nokotan, $msid) = ($1, $2, $3);

	if (($msid == $HcurrentID) && ($msjotai == 1)) {
	 $kyokasinseitiu.= "$island->{'name'} 섬,";
	}

 }

	my($oStr3) = '';
	if($kyokasinseitiu eq ''){
	 $oStr3 = "";
	} else {
	 $oStr3 = "<BR><BR>★<font color=hotpink><B>$kyokasinseitiu 에서, 당신의 섬으로의 지원사격 신청이 도착했습니다.</B></font>★";
	}

 out(<<END);
</SELECT>
<INPUT TYPE="submit" VALUE="대량파괴병기 사용 허가 신청" NAME="MsButton$Hislands[$HcurrentNumber]->{'id'}">
<INPUT TYPE="submit" VALUE="신청허가" NAME="Ms2Button$Hislands[$HcurrentNumber]->{'id'}">
$oStr3
<BR><BR>(주)신청이 허가된 섬에서는 유효 턴 동안 미사일을 요격할 수 있습니다.
<BR>대사관 파견 때도 사전에 신청 허가를 받은 뒤 파견해 주세요.
</FORM>
</CENTER>
END

}

# 입력 완료된 명령 표시
sub tempCommand {
 my($number, $command) = @_;
 my($kind, $target, $x, $y, $arg) =
	(
	 $command->{'kind'},
	 $command->{'target'},
	 $command->{'x'},
	 $command->{'y'},
	 $command->{'arg'}
	 );
 my($name) = "$HtagComName_${HcomName[$kind]}$H_tagComName";
 my($point) = "$HtagName_($x,$y)$H_tagName";
 my($island) = $Hislands[$HcurrentNumber];
 $target = $HidToName{$target};
 if($target eq '') {
	$target = "무인";
 }
 $target = "$HtagName_${target} 섬$H_tagName";
 my($value) = $arg * $HcomCost[$kind];
 if($value == 0) {
	$value = $HcomCost[$kind];
 }
 if($value < 0) {
	$value = -$value;
	$value = "$value$HunitFood";
 } else {
	$value = "$value$HunitMoney";
 }
 $value = "$HtagName_$value$H_tagName";

 my($j) = sprintf("%02d:", $number + 1);

 out("<A CLASS=\"type3\" HREF=\"JavaScript:void(0);\" onClick=\"ns($number)\"><NOBR>$HtagNumber_$j$H_tagNumber<FONT COLOR=\"$HnormalColor\" size=\"-1\">");

 if(($kind == $HcomDoNothing) ||
 ($kind == $HcomGiveup)) {
	out("$name");
 } elsif(($kind == $HcomMissileNM) ||
	 ($kind == $HcomMissilePP) ||
	 ($kind == $HcomMissileWP) ||
	 ($kind == $HcomMissileSPP) ||
	 ($kind == $HcomMissileST) ||
	 ($kind == $HcomMissileSS) ||
	 ($kind == $HcomMissileLR) ||
	 ($kind == $HcomMissileLD)) {
	# 미사일계
	my($n) = ($arg == 0 ? '무제한' : "${arg}발");
	out("$target$point 로$name($HtagName_$n$H_tagName)");
 } elsif($kind == $HcomTaishi) {
	out("$target$point 로$name");
 } elsif($kind == $HcomEiseiAtt) {
	if($arg == 99) {
	 $arg = 99;
	} elsif(($arg>= 7) ||
	 ($arg == 0)) {
	 $arg = 1;
	}
	 if($arg == 1) {
		$t = "기상위성";
	 }
	 if($arg == 2) {
		$t = "관측위성";
	 }
	 if($arg == 3) {
		$t = "요격위성";
	 }
	 if($arg == 4) {
		$t = "군사위성";
	 }
	 if($arg == 5) {
		$t = "방위위성";
	 }
	 if($arg == 6) {
		$t = "비정상";
	 }
	 if($arg == 99) {
		$t = "우주 정거장";
	 }
	out("$target 의<B>$t</B>로$name");
 } elsif($kind == $HcomMagic) {
	if($arg>= 8) {
	 $arg = 0;
	}
	 if($arg == 0) {
		$t = "불 계열 마술사 파견";
	 }
	 if($arg == 1) {
		$t = "얼음계 마술사 파견";
	 }
	 if($arg == 2) {
		$t = "땅 계열 마술사 파견";
	 }
	 if($arg == 3) {
		$t = "바람 계열 마술사 파견";
	 }
	 if($arg == 4) {
		$t = "빛 계열마술사 파견";
	 }
	 if($arg == 5) {
		$t = "어둠 계열마술사 파견";
	 }
	 if($arg == 6) {
		$t = "천공성포격";
	 }
	 if($arg == 7) {
		$t = "동물원 사육·육성 관련 파견";
	 }
	out("$target$point 로${HtagComName_}${t}${H_tagComName}");
 } elsif($kind == $HcomEiseiLzr) {
	out("$target$point 로$name");
 } elsif($kind == $HcomSendMonster) {
	# 괴수 파견
 if ($arg> 30) {
 $arg = 30;
 }
	out("$target 로$name($HmonsterName[$arg])");
 } elsif($kind == $HcomSell) {
	# 식량 수출
	out("$name$value");
 } elsif($kind == $HcomPropaganda) {
	# 유치 활동
	if($arg == 0) {
	 out("$name");
	} else {
	 out("$name($arg 회)");
	}
 } elsif($kind == $HcomEisei) {
	if($arg == 99) {
	 $arg = 99;
	} elsif(($arg>= 7) ||
	 ($arg == 0)) {
	 $arg = 1;
	}

	 if($arg == 1) {
		$t = "기상위성";
	 }
	 if($arg == 2) {
		$t = "관측위성";
	 }
	 if($arg == 3) {
		$t = "요격위성";
	 }
	 if($arg == 4) {
		$t = "군사위성";
	 }
	 if($arg == 5) {
		$t = "방위위성";
	 }
	 if($arg == 6) {
		$t = "비정상";
	 }
	 if($arg == 99) {
		$t = "우주 정거장";
	 }
	out("${HtagComName_}${t} 발사${H_tagComName}");
 } elsif($kind == $HcomEiseimente) {
	if($arg == 99) {
	 $arg = 99;
	} elsif(($arg>= 7) ||
	 ($arg == 0)) {
	 $arg = 1;
	}
	 if($arg == 1) {
		$t = "기상위성";
	 }
	 if($arg == 2) {
		$t = "관측위성";
	 }
	 if($arg == 3) {
		$t = "요격위성";
	 }
	 if($arg == 4) {
		$t = "군사위성";
	 }
	 if($arg == 5) {
		$t = "방위위성";
	 }
	 if($arg == 6) {
		$t = "비정상";
	 }
	 if($arg == 99) {
		$t = "우주 정거장";
	 }
	out("${HtagComName_}${t}복구${H_tagComName}");
 } elsif(($kind == $HcomMoney) ||
	 ($kind == $HcomFood)) {
	# 지원
	out("$target 로$name$value");
 } elsif($kind == $HcomEneGive) {
	# 지원
	out("$target 로$name(${arg}00kW)");
 } elsif($kind == $HcomDestroy) {
	# 굴착
	if($arg != 0) {
	 out("$point 으로 $name(예산${value})");
	} else {
	 out("$point 으로 $name");
	}
 } elsif($kind == $HcomMine) {
 # 지뢰
 if ($arg == 0) {
 $arg = 1;
 } elsif ($arg> 9) {
 $arg = 9;
 }
 out("$point 으로 $name(피해$arg)");
 } elsif($kind == $HcomZoo) {
 if ($arg> 30) {
 $arg = 30;
 }
 out("$point 으로 $name(또는$HmonsterName[$arg]탈출)");
 } elsif($kind == $HcomTrain) {
 if ($arg> 9) {
 $arg = 0;
 }
 out("$point 으로 $name(지정$arg)");
 } elsif($kind == $HcomKura) {
 if ($arg == 0) {
 $arg = 1;
 }
 out("$point 으로 $name($arg 조 엔)");
 } elsif($kind == $HcomKuraf) {
 if ($arg == 0) {
 $arg = 1;
 } elsif ($arg> 9) {
 $arg = 9;
 }
 out("$point 으로 $name(${arg}00만톤)");
 } elsif($kind == $HcomKura2) {
 if ($arg == 0) {
 $arg = 1;
 }
 out("$point 으로 $name($arg 조 엔 or${arg}00만톤)");
 } elsif($kind == $HcomFune) {
 if ($arg == 0) {
 $arg = 1;
 }
 out("$point 으로 $name($HfuneName[$arg])");
 } elsif($kind == $HcomMonument) {
 out("$point 으로 $name($HmonumentName[$arg])");
 } elsif($kind == $HcomFarmcpc) {
	if(($arg>= 4) ||
	 ($arg == 0)) {
	 $arg = 1;
	}
	 if($arg == 1) {
		$t = "양계장";
	 }
	 if($arg == 2) {
		$t = "양돈장";
	 }
	 if($arg == 3) {
		$t = "목장";
	 }
	out("$point 으로 $name($t)");
 } elsif($kind == $HcomCollege) {
		$etc5 = $island->{'etc5'};
		$etc5 =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
		($s00,$s01,$s02,$s03,$s04,$s05,$s06,$s07,$s08,$s09,$s10,$s11,$s12,$s13,$s14,$s15,$s16,$s17,$s18,$s19,$s20,$s21,$s22,$s23,$s24,$s25,$s26,$s27,$s28,$s29,$s30) = ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,$12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22,$23, $24, $25, $26, $27, $28, $29, $30, $31);
		$s10b = int($s10/5)+1;
		if(($s00> 0) && ($arg < 10) && ($arg != 0) && ($arg-1 < $s10b)) {
			if($arg == 0) {
			 $arg = 1;
			}
		 if($arg == 1) {
			$t = "농업대학";
		 }
		 if($arg == 2) {
			$t = "공업대학";
		 }
		 if($arg == 3) {
			$t = "종합대학";
		 }
		 if($arg == 4) {
			$t = "군사대학";
		 }
		 if($arg == 5) {
			$t = "생물 대학";
		 }
		 if($arg == 6) {
			$t = "기상대학";
		 }
		 if($arg == 7) {
			$t = "경제대학";
		 }
		 if($arg == 8) {
			$t = "마법학교";
		 }
		 if($arg == 9) {
			$t = "전기공사대학";
		 }
			out("$point 으로 $name($t)");
		} else {
			out("$point 으로 $name");
		}

 } elsif(($kind == $HcomFarm) ||
	 ($kind == $HcomFoodim) ||
	 ($kind == $HcomFactory) ||
 ($kind == $HcomNursery) ||
 ($kind == $HcomEneAt) ||
 ($kind == $HcomEneFw) ||
 ($kind == $HcomEneWt) ||
 ($kind == $HcomEneBo) ||
 ($kind == $HcomEneWd) ||
 ($kind == $HcomEneSo) ||
 ($kind == $HcomEneCs) ||
 ($kind == $HcomBoku) ||
 ($kind == $HcomPark) ||
 ($kind == $HcomUmiamu) ||
 ($kind == $HcomKai) ||
 ($kind == $HcomHTget) ||
 ($kind == $HcomGivefood) ||
	 ($kind == $HcomMountain)) {
	# 횟수부키
	if($arg == 0) {
	 out("$point 으로 $name");
	} else {
	 out("$point 으로 $name($arg 회)");
	}
 } else {
	# 좌표부키
	out("$point 으로 $name");
 }

 out("</FONT></NOBR></A><BR>");
}

# 로컬 게시판
sub tempLbbsHead {
 out(<<END);
<HR>
<CENTER>
${HtagBig_}${HtagName_}${HcurrentName} 섬${H_tagName}관광객 통신${H_tagBig}<BR>
</CENTER>
END
}

# 로컬 게시판입력 양식
sub tempLbbsInput {
 out(<<END);
<CENTER>
<FORM action="$HthisFile" method="POST">
END
 if ($HlbbsMoneyPublic + $HlbbsMoneySecret> 0) {
 # 발언은 유료
 out("<CENTER><B>참고:</B>");
 out("공개통신은<B>$HlbbsMoneyPublic$HunitMoney</B>입니다.") if ($HlbbsMoneyPublic> 0);
 out("극비통신은<B>$HlbbsMoneySecret$HunitMoney</B>입니다.") if ($HlbbsMoneySecret> 0);
 out("</CENTER>");
 }
 out(<<END);
<TABLE BORDER>
<TR>
<TH> 비밀번호</TH>
<TH> 섬 이름</TH>
<TH>통신방법</TH>
</TR>
<TR>
<TD><INPUT TYPE=password SIZE=32 MAXLENGTH=32 NAME=PASSWORD VALUE="$HdefaultPassword"></TD>
<TD>
<SELECT NAME="ISLANDID2">$HislandList</SELECT>
END
 out(<<END) if ($HlbbsAnon);
<INPUT TYPE="radio" NAME="LBBSTYPE" VALUE="ANON">관광객
END
 out(<<END);
</TD>
<TD>
<INPUT TYPE="radio" NAME="LBBSTYPE" VALUE="PUBLIC" CHECKED>공개
<INPUT TYPE="radio" NAME="LBBSTYPE" VALUE="SECRET"><FONT COLOR="red">극비</FONT>
</TD>
</TR>
<TR>
<TH>이름</TH>
<TH>내용</TH>
<TH>동작</TH>
</TR>
<TR>
<TD><INPUT TYPE="text" SIZE=32 MAXLENGTH=32 NAME="LBBSNAME" VALUE="$HdefaultName"></TD>
<TD><INPUT TYPE="text" SIZE=80 NAME="LBBSMESSAGE"></TD>
<TD><CENTER><INPUT TYPE="submit" VALUE="기장하다" NAME="LbbsButtonSS$HcurrentID"></CENTER></TD>
</TR>
</TABLE>
</FORM>
</CENTER>
END
}

# 로컬 게시판입력 양식 owner mode 용
sub tempLbbsInputOW {
 out(<<END);
<CENTER>
<FORM action="$HthisFile" method="POST">
<TABLE BORDER>
<TR>
<TH>이름</TH>
<TH COLSPAN=2>내용</TH>
</TR>
<TR>
<TD><INPUT TYPE="text" SIZE=32 MAXLENGTH=32 NAME="LBBSNAME" VALUE="$HdefaultName"></TD>
<TD COLSPAN=2><INPUT TYPE="text" SIZE=80 NAME="LBBSMESSAGE"></TD>
</TR>
<TR>
<TH> 비밀번호</TH>
<TH COLSPAN=2>동작</TH>
</TR>
<TR>
<TD><INPUT TYPE=password SIZE=32 MAXLENGTH=32 NAME=PASSWORD VALUE="$HdefaultPassword"></TD>
<TD align=right>
<INPUT TYPE="submit" VALUE="기장하다" NAME="LbbsButtonOW$HcurrentID">
</TD>
<TD align=right>
번호
<SELECT NAME=NUMBER>
END
 # 발언번호
 my($j, $i);
 for($i = 0; $i < $HlbbsMax; $i++) {
	$j = $i + 1;
	out("<OPTION VALUE=$i>$j\n");
 }
 out(<<END);
</SELECT>
<INPUT TYPE="submit" VALUE="삭제" NAME="LbbsButtonDL$HcurrentID">
</TD>
</TR>
</TABLE>
</FORM>
</CENTER>
END
}

# 로컬 게시판내용
sub tempLbbsContents {
 my($lbbs, $line);
 $lbbs = $Hislands[$HcurrentNumber]->{'lbbs'};
 out(<<END);
<CENTER>
<TABLE BORDER>
<TR>
<TH>번호</TH>
<TH>기장내용</TH>
</TR>
END


 my($i);
 for($i = 0; $i < $HlbbsMax; $i++) {
 $line = $lbbs->[$i];
 if($line =~ /([0-9]*)\<(.*)\<([0-9]*)\>(.*)\>(.*)$/) {
 my($j) = $i + 1;
 out("<TR><TD align=center>$HtagNumber_$j$H_tagNumber</TD>");
 my($speaker);
 $speaker = "<FONT COLOR=gray><B><SMALL>($2)</SMALL></B></FONT>" if ($HlbbsSpeaker && ($2 ne ''));
 if($3 == 0) {
 # 관광객
 if ($1 == 0) {
 # 공개
 out("<TD>$HtagLbbsSS_$4> $5$H_tagLbbsSS $speaker</TD></TR>");
 } else {
 # 극비
 if ($HmainMode ne 'owner') {
 # 관광객
 out("<TD><CENTER><FONT COLOR=gray>- 극비 -</FONT></CENTER></TD></TR>");
 } else {
 # 소유자
 out("<TD>$HtagLbbsSS_$4>(비밀) $5$H_tagLbbsSS $speaker</TD></TR>");
 }
 }
 } else {
 # 섬주
 out("<TD>$HtagLbbsOW_$4> $5$H_tagLbbsOW $speaker</TD></TR>");
 }
 }
 }

 out(<<END);

</TD></TR></TABLE></CENTER>
END
}

# 이미같은 IP 의 섬이 있는 경우
sub tempIP2IslandAlready {
 out(<<END);
${HtagBig_}등록된 IP 와 다른 경우 접속할 수 없습니다.${H_tagBig}$HtempBack
END
}

# 로컬 게시판에서 이름이나 메시지가 없는 경우
sub tempLbbsNoMessage {
 out(<<END);
${HtagBig_}이름 또는 내용이 비어 있습니다..${H_tagBig}$HtempBack
END
}

# 쓰기/삭제
sub tempLbbsDelete {
 out(<<END);
${HtagBig_}기록 내용을 삭제했습니다${H_tagBig}<HR>
END
}

# 명령 등록
sub tempLbbsAdd {
 out(<<END);
${HtagBig_}기록을 실행했습니다${H_tagBig}<HR>
END
}

# 통신 자금 부족
sub tempLbbsNoMoney {
 out(<<END);
${HtagBig_} 자금 부족으로 기입할 수 없습니다${H_tagBig}$HtempBack
END
}

# 자금 부족
sub tempNoMoney {
 out(<<END);
${HtagBig_} 자금이족리않습니다${H_tagBig}$HtempBack
END
}

# 자금 부족
sub tempNoMoney2 {
 out(<<END);
${HtagBig_}현재중단입니다요${H_tagBig}$HtempBack
END
}

# 자금 부족
sub tempNoMoney3 {
 out(<<END);
${HtagBig_}입찰은1품까지입니다${H_tagBig}$HtempBack
END
}

# 자금 부족
sub tempNoMoney4 {
 out(<<END);
${HtagBig_}여기의 상품은 낙찰되었습니다${H_tagBig}$HtempBack
END
}

# 명령 삭제
sub tempCommandDelete {
 out(<<END);
${HtagBig_} 명령을 삭제했습니다${H_tagBig}<HR>
END
}

# 명령 등록
sub tempCommandAdd {
 out(<<END);
${HtagBig_} 명령을 등록했습니다${H_tagBig}<HR>
END
}

# 코멘트 변경성공
sub tempComment {
 out(<<END);
${HtagBig_}코멘트를 갱신했습니다${H_tagBig}<HR>
END
}

# toto 변경성공
sub tempToto {
 out(<<END);
${HtagBig_}예상했습니다${H_tagBig}<HR>
END
}

# toto 변경성공
sub tempToto2 {
 out(<<END);
${HtagBig_}변경했습니다${H_tagBig}<HR>
END
}

# toto 변경성공
sub tempToto3 {
 out(<<END);
${HtagBig_}입찰했습니다${H_tagBig}<HR>
END
}

# ms 변경성공
sub tempMs {
 out(<<END);
${HtagBig_}허가신청했습니다${H_tagBig}<HR>
END
}

# toto 변경불능
sub tempTotoend {
 out(<<END);
${HtagBig_}현재, 변경할 수 없습니다${H_tagBig}<HR>$HtempBack
END
}

# 최근 상황
sub tempRecent {
 my($mode) = @_;
 out(<<END);
<HR>
${HtagBig_}${HtagName_}${HcurrentName} 섬${H_tagName}의 최근 상황${H_tagBig}<BR>
END
 logPrintLocal($mode);
}

# 지형의 호출분
sub landName {
 my($land, $lv) = @_;

 if($land == $HlandSea) {
	if($lv == 1) {
 return '얕은 바다';
 } else {
 return '바다';
	}
 } elsif($land == $HlandIce) {
	if($lv> 0) {
 return '천연 스케이트장';
 } else {
 return '빙하';
	}
 } elsif($land == $HlandWaste) {
	return '황무지';
 } elsif($land == $HlandPlains) {
	return '평지';
 } elsif($land == $HlandPlains2) {
	return '개발 예정지';
 } elsif($land == $HlandTown) {
	if($lv < 30) {
	 return '마을';
	} elsif($lv < 100) {
	 return '읍';
	} else {
	 return '도시';
	}
 } elsif($land == $HlandProcity) {
	return '방재 도시';
 } elsif($land == $HlandNewtown) {
	return '뉴타운';
 } elsif($land == $HlandBigtown) {
	return '현대 도시';
 } elsif($land == $HlandBettown) {
	return '고층 도시';
 } elsif($land == $HlandSkycity) {
	return '공업 도시';
 } elsif($land == $HlandUmicity) {
	return '바다 도시';
 } elsif($land == $HlandSeatown) {
	return '해저 신도시';
 } elsif($land == $HlandRizort) {
	return '리조트';
 } elsif($land == $HlandKajino) {
	return '카지노';
 } elsif($land == $HlandBigRizort) {
	return '임시 해변 리조트 호텔';
 } elsif($land == $HlandShuto) {
	return '수도';
 } elsif($land == $HlandUmishuto) {
	return '해저 수도';
 } elsif($land == $HlandForest) {
	return '숲';
 } elsif($land == $HlandFarm) {
	return '농장';
 } elsif($land == $HlandEneAt) {
	return '원자력발전소';
 } elsif($land == $HlandEneFw) {
	return '화력 발전소';
 } elsif($land == $HlandEneWt) {
	return '수력발전소';
 } elsif($land == $HlandEneWd) {
	return '풍력발전소';
 } elsif($land == $HlandEneBo) {
	return '바이오매스 발전소';
 } elsif($land == $HlandEneSo) {
	return '소라발전소';
 } elsif($land == $HlandEneCs) {
	return '코스모 발전소';
 } elsif($land == $HlandConden) {
	return '콘덴서';
 } elsif($land == $HlandConden2) {
	return '콘덴서·개정';
 } elsif($land == $HlandConden3) {
	return '황금의 콘덴서';
 } elsif($land == $HlandConden4) {
	if($lv == 3) {
	 return '황금의 콘덴서(누전안)';
	} elsif($lv == 2) {
	 return '콘덴서·개정(누전안)';
	} elsif($lv == 99) {
	 return '핵융합발전소';
	} else {
	 return '황금의 콘덴서(누전안)';
	}
 } elsif($land == $HlandFoodka) {
	return '식품 가공 공장';
 } elsif($land == $HlandFoodim) {
	if($lv < 480) {
	 return '식품 연구소';
	} else {
	 return '방재형식품 연구소';
	}
 } elsif($land == $HlandFarmchi) {
	return '양계장';
 } elsif($land == $HlandFarmpic) {
	return '양돈장';
 } elsif($land == $HlandFarmcow) {
	return '목장';
 } elsif($land == $HlandYakusho) {
	return '섬관청';
 } elsif($land == $HlandCollege) {
	if($lv == 0) {
	 return '농업대학';
	} elsif($lv == 1) {
	 return '공업대학';
	} elsif($lv == 2) {
	 return '종합대학';
	} elsif($lv == 3) {
	 return '군사대학';
	} elsif($lv == 4) {
	 return '생물 대학(대기안)';
	} elsif($lv == 98) {
	 return '생물 대학(대기안)';
	} elsif($lv == 96) {
	 return '생물 대학(출입 금지안)';
	} elsif($lv == 97) {
	 return '생물 대학(출입 금지안)';
	} elsif($lv == 99) {
	 return '생물 대학(출동안)';
	} elsif($lv == 5) {
	 return '기상대학';
	} elsif($lv == 6) {
	 return '경제대학';
	} elsif($lv == 7) {
	 return '마법학교';
	} elsif($lv == 8) {
	 return '전기공사대학';
	} elsif($lv == 77) {
	 return '문부과학성';
	} elsif($lv == 78) {
	 return '문부과학성';
	} elsif($lv == 79) {
	 return '문부과학성';
	} elsif($lv == 80) {
	 return '문부과학성';
	} elsif($lv == 95) {
	 return '경제대학(저금안)';
	} else {
	 return '기상대학';
	}
 } elsif($land == $HlandHouse) {
	if($lv == 0) {
	 return '오두막';
	} elsif($lv == 1) {
	 return '간이주택';
	} elsif($lv == 2) {
	 return '주택';
	} elsif($lv == 3) {
	 return '고급주택';
	} elsif($lv == 4) {
	 return '저택';
	} elsif($lv == 5) {
	 return '대저택';
	} elsif($lv == 6) {
	 return '고급 저택';
	} elsif($lv == 7) {
	 return '성';
	} elsif($lv == 8) {
	 return '거성';
	} else {
	 return '황금성';
	}
 } elsif($land == $HlandTrain) {
	if($lv == 0) {
	 return '역';
	} elsif($lv < 10) {
	 return '선로';
	} elsif($lv == 10) {
	 return '역(일반 열차 정차 중)';
	} elsif($lv < 20) {
	 return '일반 열차';
	} elsif($lv == 20) {
	 return '역(화물 열차 정차 중)';
	} elsif($lv < 30) {
	 return '화물 열차';
	}
 } elsif($land == $HlandTaishi) {
	return '대사관';
 } elsif($land == $HlandKura) {
	return '창고';
 } elsif($land == $HlandKuraf) {
	return '창고';
 } elsif($land == $HlandFactory) {
	return '공장';
 } elsif($land == $HlandHTFactory) {
	return '첨단 기술 다국적 기업';
 } elsif($land == $HlandSHTF) {
	return '첨단 기술 다국적 기업·개정';
 } elsif($land == $HlandOWNF) {
	return '섬운영기업';
 } elsif($land == $HlandBase) {
	return '미사일 기지';
 } elsif($land == $HlandDefence) {
	if($lv == 77) {
	 return '방위 시설·개정';
	} else {
	 return '방위 시설';
	}
 } elsif($land == $HlandMountain) {
	return '산';
 } elsif($land == $HlandGold) {
	return '금광산';
 } elsif($land == $HlandOnsen) {
	return '온천거리';
 } elsif($land == $HlandMonster) {
	my($kind, $name, $hp) = monsterSpec($lv);
	return $name;
 } elsif($land == $HlandSbase) {
	return '해저 기지';
 } elsif($land == $HlandSeacity) {
	return '해저 도시';
 } elsif($land == $HlandOil) {
	return '해저 유전';
 } elsif($land == $HlandMonument) {
	return $HmonumentName[$lv];
 } elsif($land == $HlandHaribote) {
	return '가짜 기지';
 } elsif($land == $HlandPark) {
 return '놀이공원';
 } elsif($land == $HlandMinato) {
	return '항구 도시';
 } elsif($land == $HlandFune) {
	return $HfuneName[$lv];
 } elsif($land == $HlandFrocity) {
	return '해상 도시';
 } elsif($land == $HlandSunahama) {
	return '해변';
 } elsif($land == $HlandMine) {
 return '지뢰';
 } elsif($land == $HlandNursery) {
 return '양식장';
 } elsif($land == $HlandKyujo) {
 return '야구장';
 } elsif($land == $HlandKyujokai) {
 return '다목적 경기장';
 } elsif($land == $HlandZoo) {
 return '동물원';
 } elsif($land == $HlandUmiamu) {
 return '해상 시설';
 } elsif($land == $HlandSeki) {
	return '관문';
 } elsif($land == $HlandRottenSea) {
	if($lv < 20) {
	 return '오염된 바다';
	} else {
	 return '고사 바다';
	}
 }
}

sub tempChange2 {
 out(<<END);
${HtagBig_}청소 투표 1표를 접수했습니다.${H_tagBig}$HtempBack
END
}

# 비밀번호오류
sub tempWrongPassword3 {
 out(<<END);
${HtagBig_}자신의 섬에는 의미가 없습니다.${H_tagBig}$HtempBack
END
}

# 비밀번호오류
sub tempWrongPassword4 {
 out(<<END);
${HtagBig_}1섬1표까지에서 부탁드립니다.${H_tagBig}$HtempBack
END
}

# 비밀번호오류
sub tempWrongPassword5 {
 out(<<END);
${HtagBig_}3표까지만투입표할 수 없습니다. 결과 를기다려 주세요.${H_tagBig}$HtempBack
END
}

# 비밀번호오류
sub tempWrongPassword6 {
 out(<<END);
${HtagBig_}항목을 선택해 주세요.${H_tagBig}$HtempBack
END
}

1;
