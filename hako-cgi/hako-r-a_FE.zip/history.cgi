#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}

#---------------------------------------------------------------------
#
#	궁극 구상의 하코니와 최근 사건와 최근의 날씨의 이력을 표시
#
#	작성일 : 20001/11/25 (ver0.10)
#	작성자 : 라스티아 <nayupon@mail.goo.ne.jp>
#
#---------------------------------------------------------------------

#---------------------------------------------------------------------
#	초기 설정
#---------------------------------------------------------------------
# 문자 변환 라이브러리 로드

# 로그 데이터 디렉터리 이름
$HlogdirName = 'data';

# 표시하다 로그의 턴 수(hako-main.cgi 의 로그 파일유지 턴 수보다많이 사용할 수 없습니다.)
$HtopLogTurn = 6;

#----------------------------
#	HTML 에관한 설정
#----------------------------
# 브라우저의 제목막대의 명칭
$title = '최근 사건';

# 화면의 색나 배경의 설정(HTML)
$body = '<body bgcolor=lemonchiffon>';

# 화면의'돌아가기'링크선(URL)
$bye = 'http:/www.xxxxxx/cgi-bin/hako-main.cgi';

# H1태그용
$HtagHeader_ = '<FONT COLOR="#4444ff">';
$H_tagHeader = '</FONT>';

# 순위 번호 등
$HtagNumber_ = '<FONT COLOR="#800000"><B>';
$H_tagNumber = '</B></FONT>';

#메인루틴-------------------------------------------------------

&cgiInput;
&tempHeader;

if($HMode == 100) {
	# 날씨
	&logTenki;
} elsif($HMode =~ /([0-9]*)/) {
	if($HMode == 99) {
		&logFilePrintAll;
	} else {
		&logFilePrint($HMode, $HcurrentID);
	}
} else {
	# 날씨
	&logTenki;
}

&tempFooter;
#종료
exit(0);

#서브루틴---------------------------------------------------------
#--------------------------------------------------------------------
#	POST 또는 GET 으로 입력된 데이터 가져오기
#--------------------------------------------------------------------
sub cgiInput {
 my($line, $getLine);

 # 입력을 받아 UTF-8로 처리
 $line = <>;
 $line =~ tr/+/ /;
 $line =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
 $line = $line;
 $line =~ s/[\,\r]//g;

 # GET 값을 받음
 $getLine = $ENV{'QUERY_STRING'};

 if($getLine =~ /tenki/){
	$HMode = 100;
 } elsif($getLine =~ /saikin=([0-9]*)/){
	$HMode = $1;

	if($getLine =~ /id=([0-9]*)/){
	$HcurrentID = $1;
	}

 } else {
	$HMode = 100;
 }
}
#---------------------------------------------------------------------
#	HTML 의헤더와 푸터 부분을 출력
#---------------------------------------------------------------------
# 헤더
sub tempHeader {
	print qq{Content-type: text/html; charset=UTF-8\n\n};
	print qq{<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">\n\n};
	out(<<END);
<HTML>
<HEAD><META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
<TITLE>
$title
</TITLE>
</HEAD>
$body
[최근 사건]
END
	my $i;
	for($i = 0;$i < $HtopLogTurn;$i++) {
		out("<A HREF='history.cgi?saikin=${i}'>[${i}]</A>\n");
	}
	out(<<END);


[각 섬의 최근 상황]
END


	my $id;
	$id = $HcurrentID;
		if($id != 0) {
		my $i;
		for($i = 0;$i < $HtopLogTurn;$i++) {
			out("<A HREF='history.cgi?saikin=${i}&id=${id}'>[${i}]</A>\n");
		}
		}

	out(<<END);
<br>
<br>
END
}
# 푸터
sub tempFooter {
	out(<<END);
</BODY>
</HTML>
END
}
#---------------------------------------------------------------------
#	로그 파일제목
#---------------------------------------------------------------------
sub logDekigoto {
	out(<<END);
<H1>${HtagHeader_}최근 사건${H_tagHeader}</H1>
END
}
#---------------------------------------------------------------------
#	로그 파일 전체 표시
#---------------------------------------------------------------------
#---------------------------------------------------------------------
#	파일 번호를 지정해 로그 표시
#---------------------------------------------------------------------
sub logFilePrint {
	my($fileNumber, $id) = @_;

	open(LIN, "${HlogdirName}/hakojima.log$_[0]");
	my($line, $m, $turn, $id1, $id2, $message);
	while($line = <LIN>) {
		$line =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),(.*)$/;
		($m, $turn, $id1, $id2, $message) = ($1, $2, $3, $4, $5);

		# 기밀관계
		if($m == 1) {
			next;
		} else {
			$m = '';
		}

		if($id != 0) {
		 if(($id != $id1) &&
		 ($id != $id2)) {
			next;
		 }
		}

		# 표시
		out("<NOBR>${HtagNumber_}턴$turn$m${H_tagNumber}:$message</NOBR><BR>\n");
	}
	close(LIN);
}
#---------------------------------------------------------------------
#	문자코드를 shift jis 으로 표준출력에아우와 푸토
#---------------------------------------------------------------------
sub out {
 print STDOUT $_[0];
}

