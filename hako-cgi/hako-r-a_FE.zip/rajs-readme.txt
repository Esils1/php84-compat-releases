――――――――――――――――――――――――――――――――――――
 Hakoniwa R.A. JavaScript version4.xx

 patchworked by neo_otacky. since 2001/12/10

 arranged from Hakoniwa R.A. ver1.11(010713model)
 ver2.11(020610model) by KEI
 JSmode(ver.1.01) scripted by 앗포
 	 based on 하코니와 제도 ver2.30 by 도쿠오카 히로 키

 special thanx to 친분 Watson 라스티아 나가네코...and you
――――――――――――――――――――――――――――――――――――
[사용 조건 및 배포 조건]
 Hakoniwa R.A. 의 read-renas.txt,
 JavaScript 판 하코니와 제도의 js-readme.txt
 및 하코니와 제도 ver2.3의 hako-readme.txt 를 따라 주세요.

·동작하지 않거나 버그가 많아도 문제가 생겨도 감수할 수 있는 분만 이용해 주세요.
·또한 이 스크립트 사용으로 발생한 장애나 피해에 대해서 제작자는 일절
책임을 지지 않습니다. 본인 책임하에 이용해 주세요.

참고: 추가
 동맹 게시판(hako-yy-bbs.cgi,hako-yy-ini.cgi,hako-yy-reg.cgi)은,
KENT WEB 에서 배포하는 'YY-BOARD'를 개조한 것입니다.
 이용 및 재배포는 아래 이용 규정을 따라 주세요.

 CGI 스크립트이용규정
 http://www.kent-web.com/pubc/kitei.html

 또한, 지원은 KENT WEB 에서 제공하지 않습니다.
 폐를 끼치지 않도록 주의해 주세요.
――――――――――――――――――――――――――――――――――――
[데이터의 이전]
 원본에서의 이전에 대해서는 ver1.11(010713model)ver2.11(020610model)
라고도에, 설정사에 오류가 없다면, 그대로 이전할 수 있을 것입니다.

주·섬 ID 이100을 넘는 섬에 대해서는, 이전 후 BattleField 라는 특별한 섬으로
 설정됩니다. 이것은,hako-mente.cgi 의 관리자실'BattleField 를 작성하기'로 일반 섬에 복귀시켜야 합니다.

 3.xx 이전의 JS 판에서 이전하는 경우, 그대로 라면'시간의 신전'이'대학'에
'거대 괴수'가'해상 도시'에되어 버립니다.
 hako-main.cgi 의'지형 번호'를 변경하면 대응할 수 있습니다.
 ('시간의 신전'을34,'거대 괴수'를35,'대학''해상 도시'를46이후에)

 단,'시간의 신전'에 대해서는, 출현조건을 약간 변경하고 있으므로, 타
갱신 후에는 평범한 산이 되어 버릴 것입니다(^^
――――――――――――――――――――――――――――――――――――
[기타]
·이미지 파일은 동봉되어 있지 않습니다. 원본판의 배포처에서 입수할 수 있습니다.read-renas.txt 를 읽어 주세요.

·버그 보고는 이쪽으로 보내 주세요→http://snow.prohosting.com/awinokah/
또한, 버그가 반드시 수정된다는 보장은 없으니 양해해 주세요.

·이 스크립트 설치와 관련해 하코니와 계열 사이트에서 질문할 때는 폐를 끼치지 않도록 각별히 주의해 주세요.
