#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}
# ↑은서버에 맞게 변경해 주세요.
# perl5용입니다.

#----------------------------------------------------------------------
# 하코니와 제도 ver2.30
# 메인스크립트(ver1.02)
# 사용 조건, 사용 방법 등은,hako-readme.txt 파일을 참조
#
# 하코니와 제도의 페이지: http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html
#----------------------------------------------------------------------
#----------------------------------------------------------------------
# Hakoniwa R.A. Final Edition
# 메인스크립트(하코니와 제도 ver2.30)
# 사용 조건, 사용 방법 등은,read-renas.txt 파일을 참조
#
# KEI PAGE: http://www5b.biglobe.ne.jp/~k-e-i/
#----------------------------------------------------------------------


#----------------------------------------------------------------------
# 각종 설정 값
# 아래 설정 값을 서버 환경에 맞게 변경해 주세요.
#----------------------------------------------------------------------

#----------------------------------------------------------------------
# 아래는 반드시 설정해야 하는 항목입니다
#----------------------------------------------------------------------

# 이 파일을 설치할 디렉터리
# my($baseDir) = 'http://장소/hako-mente.cgi';
#
# 예)
# http://cgi2.bekkoame.ne.jp/cgi-bin/user/u5534/hakoniwa/hako-main.cgi
# 처럼 배치한 경우,
# my($baseDir) = 'http://cgi2.bekkoame.ne.jp/cgi-bin/user/u5534/hakoniwa';
# 지정합니다. 끝에 슬래시(/)는 붙이지 않습니다.

my($scriptBaseScheme) = (($ENV{'HTTPS'} || '') =~ /^(on|1)$/i) ? 'https' : 'http';
my($scriptBaseHost) = $ENV{'HTTP_HOST'} || $ENV{'SERVER_NAME'} || 'localhost';
if (!$ENV{'HTTP_HOST'} && $ENV{'SERVER_PORT'} && !(($scriptBaseScheme eq 'http' && $ENV{'SERVER_PORT'} == 80) || ($scriptBaseScheme eq 'https' && $ENV{'SERVER_PORT'} == 443))) {
 $scriptBaseHost.= ":$ENV{'SERVER_PORT'}";
}
my($scriptBasePath) = $ENV{'SCRIPT_NAME'} || '';
$scriptBasePath =~ s{/[^/]*$}{};
my($baseDir) = "$scriptBaseScheme://$scriptBaseHost$scriptBasePath";


# 이미지 파일을 둘 디렉터리
# my($imageDir) = 'http://장소/hako-mente.cgi';
#my($imageDir) = $baseDir;
my($imageDir) = 'https://esils.com/BBdata/hakorenas';

# 문자 변환 라이브러리 위치

# UTF-8 환경에서는 외부 문자 변환 라이브러리를 사용하지 않습니다.
# UTF-8 환경에서는 외부 문자 변환 라이브러리를 사용하지 않습니다.
# 이 비밀번호는, 모든 섬의 비밀번호를 대신 사용할 수 있습니다.
# 예를 들어,'다른 섬의 비밀번호 변경'등도 할 수 있습니다.
my($masterPassword) = '1064';

# 특수 비밀번호
# 이 비밀번호로 '이름 변경'을 실행하면, 그 섬의 자금, 식량이 최대 값이 됩니다.
# (실제로 이름이 변경될 필요는 없습니다.)
$HspecialPassword = 'uhusnuvnurkanjhfhmax';

# 수도 비밀번호
# 이 비밀번호로 '이름 변경'을 실행하면, 그 섬 수도 이름이 변경됩니다.
# (실제로 이름이 변경될 필요는 없습니다.)
$HshutoPassword = 'uhusnuvnurkanjhfhshuto';

# IP 비밀번호
# 이 비밀번호로 '이름 변경'을 실행하면, 그 섬의 IP 가 변경됩니다.(IP 를 변경할 때)
# (실제로 이름이 변경될 필요는 없습니다.)
$HipPassword = 'uhusnuvnurkanjhfhip';

# 오간주 게 비밀번호
# 이 비밀번호로 '이름 변경'을 실행하면, 그 섬의 부적이 증가합니다.
# (실제로 이름이 변경될 필요는 없습니다.)
$HomamoriPassword = 'uhusnuvnurkanjhfhomiya';

# 상태 수정 비밀번호
# 이 비밀번호로 '이름 변경'을 실행하면, 소유자 이름에 입력한 임의 상태를 원하는 이름으로 변경할 수 있습니다.
# (실제로 이름이 변경될 필요는 없습니다.)
$HijiriPassword = 'uhusnuvnurkanjhfhiji';


# 설문 관련
# 사용(1), 미사용(0)
$AnkeitoOnOff = 0;
# 설문 설명
$AnkeitoSetumei = "<FONT COLOR=hotpink>◎이번에 자금 융통을 사용한 입찰에서 4조 1111억 엔에 낙찰된 사례가 있었습니다.
<br> 자금 융통은 비교적 단점 없이 무제한으로 축적할 수 있고,
<br> 하코옥션 상위 입찰에 사용할 수 있어 게임 밸런스에 문제가 있다는 의견이 접수되었습니다.
<br> 여러분의 의견을 들려주세요.</font><br>";
# 질문
$AnkeitoShitumon0 = "하코옥션과 자금 융통 제도에 대해 어떻게 생각하십니까?";
$AnkeitoShitumon1 = "자금 융통에 상한을 둔다. 개인적으로 는 상한을 두고 싶지 않다.";
$AnkeitoShitumon2 = "고액 낙찰 순위의 상품 제도를 조정한다.";
$AnkeitoShitumon3 = "HT 일자리 확보를 어렵게 한다. HT 기업/개정 관련 수정을 한다.";
$AnkeitoShitumon4 = "자금 융통 유지에 수수료가 들도록 제도를 바꾼다.";
$AnkeitoShitumon5 = "기타 의견이 있으므로 다른 선택지로 다시 설문하기를 원한다.";


# 관리자 이름
my($adminName) = '관리자';

# 관리자의 메일 주소
my($email) = 'admin@example.com';

# 게시판 주소
my($bbs) = $baseDir;

# 홈페이지 주소
my($toppage) = "$baseDir/";

# 디렉터리 권한
# 일반적으로 0755이면 충분하지만, 서버에 따라 0777, 0705, 0704 등을 사용해야 할 수도 있습니다
$HdirMode = 0755;

# 데이터 디렉터리 이름
# 여기에서 설정한 이름의 디렉터리 아래에 데이터가 저장됩니다.
# 기본값에서는'data'로 되어 있지만, 보안상
# 보안을 위해 다른 이름으로 변경해 주세요.
$HdirName = 'data';

# 데이터 쓰기 권한

# 잠금 방식
# 1 디렉터리
# 2 시스템 콜(가능하면 이 방식을 권장합니다)
# 3 심볼릭 링크
# 4 일반 파일(권장하지 않음)
my($lockMode) = 2;

# (주)
# 4을 선택하는 경우에는,'key-free'라는, 권한 666의 빈 파일을,
# 이 파일과 같은 위치에 배치해 주세요.

#----------------------------------------------------------------------
# 반드시 설정하는 부분은 이상
#----------------------------------------------------------------------

#----------------------------------------------------------------------
# 아래는 필요에 따라 설정하는 항목입니다
#----------------------------------------------------------------------
#----------------------------------------
# 게임의 진행야 파일등
#----------------------------------------
# 1턴이 몇 초인지
$HunitTime = 21600; # 6 시간

# 이상종료 기준 시간
# (잠금후몇 초에서, 강제 해제하다카)
my($unlockTime) = 12;

# 섬의 최대 수
$HmaxIsland = 30;

# 톱 페이지에 표시할 로그 턴 수
$HtopLogTurn = 1;

# 로그 파일유지 턴 수
$HlogMax = 8;

# 몇 턴마다 백업을 저장할지
$HbackupTurn = 12;

# 백업을 몇 회분 남음습니까
$HbackupTimes = 1;

# 발견 로그유지 줄 수
$HhistoryMax = 20;

# Hakoniwa Cup 로그 유지 줄 수
$HhcMax = 20;

# 포기 명령자동 입력 턴 수
$HgiveupTurn = 24;

# 명령 입력 한계 수
# (게임이 시작된 뒤 변경하면 데이터 파일 호환성이 없어집니다.)
$HcommandMax = 40;

# 공격계, 지원계, 괴수출현에서 섬이 보호되는 기준 인구
# 이 인구를 초과할 때까지 개발만 가능합니다.
$HguardPop = 500; # 5만 명

# 로컬 게시판 행 수 사용 여부(0:사용하지 않음,1:사용함)
$HuseLbbs = 1;

# 로컬 게시판 줄 수
$HlbbsMax = 15;

# 로컬 게시판 익명 발언 허용 여부(0:금지,1:허가)
$HlbbsAnon = 0;

# 로컬 게시판 발언에 작성자 이름을 표시할지(0:표시하지 않음,1:표시함)
$HlbbsSpeaker = 1;

# 로컬 게시판 로그를 이관할지(0:이관하지 않음,1:이관함)
# 기존 가동 중인 게시판 로그를 비밀 발언 형식에 맞게 변환할 수 있습니다.
$HlbbsOldToNew = 1;

# 다른 섬의 로컬 게시판에 글을 쓸 때 필요한 비용(0:무료)
$HlbbsMoneyPublic = 0; # 공개
$HlbbsMoneySecret = 10000; # 극비

# 섬 크기
# (변경할 수 없일 수도)12또는20에서
$HislandSize = 12;

# 다른 사람이 자금을 볼 수 없게 할지
# 0 보이지 않음
# 1 표시 가능
# 2 100의 위에서 반올림
$HhideMoneyMode = 2;

# 비밀번호 암호화(0: 암호화하지 않음, 1: 암호화함)
my($cryptOn) = 1;

# 디버그 모드(1이면 '턴 진행' 버튼을 사용할 수 있음)
$Hdebug = 0;

# 이미지 경로 설정의 설명페이지
$imageExp = 'e.html';

# 괴수 출현 데이터를 어디에 저장할지 설정합니다. 신규 게임은 1을 권장합니다.
# 0: monslive.dat에 저장합니다. 기존 가동 중인 게임은 이 값을 사용합니다.
# 1: hakojima.dat에 저장합니다. 기존 가동 중인 게임에서는 사용하지 마십시오. 데이터가 손상될 수 있습니다.
$HnewGame = 1;

$viewFirst = 0; # 첫 화면에 표시할 섬
$viewNumber = 20; # 표시할 수# CGI 읽기

# 톱 페이지에서 접속 로그를 표시할지 설정합니다. 0: 사용 안 함, 1: 표시
$HtopAxes = 1;
# 1로 설정한 경우 아래 항목을 설정
# 로그 파일 이름
$HaxesLogfile = './axes-hako.log';
# 최대기록건 수
$HaxesMax = 500;

# 부하를 측정할까요?(0:하지 않음,1:측정함)
$Hperformance = 1;

# 평화계 모드?(0:OFF,1:ON)
$lovePeace = 1;

# 어나더 모드?(0:OFF,1:ON)
$anothermood = 0;

# 하코 옥션에서 몇 회 연속 1위일 때 상품을 지급할지
$aucshouhin = 5;

# 하코 옥션에서 연속 1위 상품을 몇 회 받으면 전당에 들어갈지
$aucdendou = 3;

# IP 중복 등록자동자르기?(0:OFF,1:ON)…등록 때 기존의 섬의 IP 은 등록 불가능해집니다.
$IPcut = 1;

#----------------------------------------
# 자금, 식량등의 설정 값와 단위
#----------------------------------------
# 초기 자금
$HinitialMoney = 2000;

# 초기식량
$HinitialFood = 200;

# 오금의 단위
$HunitMoney = '억 엔';

# 식량의 단위
$HunitFood = '00톤';

# 인구의 단위
$HunitPop = '00명';

# 면적 단위
$HunitArea = '00만 평';

# 목의 수의 단위
$HunitTree = '00본';

# 목재 단위당 판매가
$HtreeValue = 5;

# 이름 변경의 비용
$HcostChangeName = 500;

# 인구 1단위당 식량 소비량
$HeatenFood = 0.2;

# 괴수의 수의 단위
$HunitMonster = '마리';

#----------------------------------------
# 기지의 경험치
#----------------------------------------
# 경험치의 최대 값
$HmaxExpPoint = 200; # 단, 최대 255까지

# 레벨의 최대 값
my($maxBaseLevel) = 5; # 미사일 기지
my($maxSBaseLevel) = 4; # 해저 기지

# 경험치가 몇 점에서 레벨업카
my(@baseLevelUp, @sBaseLevelUp);
@baseLevelUp = (20, 60, 120, 200); # 미사일 기지
@sBaseLevelUp = (50, 100, 200); # 해저 기지


# 섬주의 등급
$HouseLevel1 = 15000; # 간이주택
$HouseLevel2 = 20000; # 주택
$HouseLevel3 = 25000; # 고급주택
$HouseLevel4 = 30000; # 저택
$HouseLevel5 = 35000; # 대저택
$HouseLevel6 = 40000; # 고급 저택
$HouseLevel7 = 45000; # 성
$HouseLevel8 = 50000; # 거성
$HouseLevel9 = 55000; # 황금성


#----------------------------------------
# 방위 시설의 자폭
#----------------------------------------
# 괴수에게 밟혔을 때 자폭하면 1, 아니면 0
$HdBaseAuto = 1;

#----------------------------------------
# 재해
#----------------------------------------
# 일반 재해 발생률(확률은0.1%단위)
$HdisEarthquake = 5; # 지진
$HdisTsunami = 5; # 쓰나미
$HdisTyphoon = 5; # 태풍
$HdisMeteo = 5; # 운석
$HdisHugeMeteo = 2; # 거대운석
$HdisEruption = 5; # 분화
$HdisFire = 5; # 화재
$HdisMaizo = 10; # 매장금

# 지반 침하
$HdisFallBorder = 350; # 안정 한계 면적(Hex 수)
$HdisFalldown = 15; # 그 면적를 초과한 경우 확률

# 괴수
$HdisMonsBorder1 = 5000; # 인구 기준1(괴수레벨1)
$HdisMonsBorder2 = 7500; # 인구 기준2(괴수레벨2)
$HdisMonsBorder3 = 9000; # 인구 기준3(괴수레벨3)
$HdisMonsBorder4 = 10000; # 인구 기준4(괴수레벨4)
$HdisMonster = 1; # 단위면적주변의 출현률(0.01%단위)

# 종류
$HmonsterNumber = 31;

# 각 기준에서 출현하는 괴수 번호의 최대값
$HmonsterLevel1 = 4; # 산지라까지
$HmonsterLevel2 = 8; # 이노라 고스트까지
$HmonsterLevel3 = 12; # 킹 이노라까지(전체)
$HmonsterLevel4 = 23; # 킹 이노라까지(전체)

$HmonsterDefence = 500; #괴수가 미사일을 튕겨낼 확률

# 이름
@HmonsterName =
 (
 '인공메카이노라', # 0(인공)
 '괴수이노라', # 1
 '괴수 산지라', # 2
 '괴수레드이노라', # 3
 '괴수다크이노라', # 4
 '영짐승이노라 고스트', # 5
 '괴수고래', # 6
 '괴수킹 이노라', # 7
 '옛짐승왕충', # 8
 '단단한 짐승', # 9
 '괴수바리모아', # 10
 '기묘짐승슬라임', # 11
 '희귀짐승은 네는 무', # 12
 '천사미카엘', # 13
 '슬라임 레전드', # 14
 '마 수레이지라', # 15
 '마 수 퀸 이라', # 16
 '인공괴수f02', # 17
 '천사우리에루', # 18
 '마술사 아루브', # 19
 '추락천사 이세리아', # 20
 '마왕 사탄', # 21
 '아이스 스콜피온', # 22
 'unknown', # 23
 '괴수킹 이노라', # 24
 '괴수킹 이노라', # 25
 '괴수킹 이노라', # 26
 '괴수킹 이노라', # 27
 '칸코와이노라', # 28
 '신짐승테트라', # 29
 '초신 수테트라' # 30
);

# 최소체력, 체력의 폭, 특수 능력, 경험치, 시체의 가격
@HmonsterBHP = ( 2, 1, 1, 3, 2, 1, 4, 7, 6, 5, 7, 3, 5,10, 7, 9, 9, 8, 9, 2, 7,10, 9,10, 1, 1, 1, 1, 0, 5, 0);
@HmonsterDHP = ( 0, 2, 2, 2, 2, 0, 2, 2, 0, 2, 2, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 1, 1, 1, 1, 0, 0, 0);
@HmonsterSpecial = ( 0, 0, 3, 5, 1, 2, 4, 0, 1, 8, 5, 0, 2, 0, 8, 8, 5, 2, 0, 1, 7, 0, 2, 7, 1, 1, 1, 1, 0, 6, 0);
@HmonsterExp = ( 5, 5, 7,12,15,10,20,30,45,40,35, 5,40,99,70,55,60,85,90,95, 0,80,40,99, 1, 1, 1, 1, 0, 7,99);
@HmonsterValue = ( 0, 400, 500, 1000, 800, 300, 1500, 5555, 2500, 3500, 3000, 100, 3500, 99999, 27000, 10000, 12000, 48000, 80000, 95000, 85000, 0, 4000, 99999, 1, 1, 1, 1, 1, 2000, 200000);

# 특수 능력의 내용은,
# 0 특별히 없음
# 1 빠른 이동(최대 2걸음)
# 이족 보행 괴수 속도(최대 이동 칸 수는 불명)
# 3 홀 수 턴은 경화
# 4 짝 수 턴은 경화
# 5 미사일요격
# 6 괴수를 공격
# 7 충격파1
# 8 무작위나 턴에경화
# 9 아이스 스톰

# 이미지 파일
@HmonsterImage =
 (
 'monster7.gif',
 'monster0.gif',
 'monster5.gif',
 'monster1.gif',
 'monster2.gif',
 'monster8.gif',
 'monster6.gif',
 'monster3.gif',
 'monster18.gif',
 'monster25.gif',
 'monster13.gif',
 'monster14.gif',
 'monster16.gif',
 'monster17.gif',
 'monster19.gif',
 'monster22.gif',
 'monster21.gif',
 'f02.gif',
 'monster23.gif',
 'monster24.gif',
 'monster26.gif',
 'monster27.gif',
 'monster29.gif',
 'monster31.gif',
 'monster3.gif',
 'monster3.gif',
 'monster3.gif',
 'monster3.gif',
 'monster30.gif',
 'monster10.gif',
 'monster28.gif'
 );

# 이미지 파일그2(경화 중)
@HmonsterImage2 =
 ('', '', 'monster4.gif', '', '', '', 'monster4.gif', '', '', 'monster25.gif', '', '', '', '', 'monster20.gif', 'monster4.gif', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');


#----------------------------------------
# 유전
#----------------------------------------
# 유전 수입
$HoilMoney = 2500;

# 유전의 고갈확률
$HoilRatio = 80;

#----------------------------------------
# 기념비
#----------------------------------------
# 몇 종류가 있는지
$HmonumentNumber = 70;

# 이름
@HmonumentName =
 (
 '모노리스', # 0
 '성나무',
 '전쟁이의 비석',
 '라스카루',
 '관통',
 '요제후',
 '쿠마',
 '쿠마',
 '쿠마',
 '눈다루마',
 '모아이', # 10
 '지구의 식',
 '바구',
 '휴지통',
 '다크이노라상',
 '테트라상',
 '는네는 무상',
 '로켓',
 '피라미도',
 '아사가오',
 '바라', # 20
 '바라',
 '팬지',
 '선인장',
 '선인장',
 '마방진',
 '신전',
 '신사',
 '휴지통',
 '휴지통',
 '휴지통', # 30
 '휴지통',
 '휴지통',
 '휴지통',
 '휴지통',
 '휴지통',
 '휴지통',
 '휴지통',
 '휴지통',
 '휴지통',
 '휴지통', # 40
 '휴지통',
 '휴지통',
 '휴지통',
 '휴지통',
 '휴지통',
 '휴지통',
 '휴지통',
 '휴지통',
 '휴지통',
 '휴지통', # 50
 '휴지통',
 '휴지통',
 '휴지통',
 '휴지통',
 '휴지통',
 '휴지통',
 '휴지통',
 '휴지통',
 '휴지통',
 '휴지통', # 60
 '휴지통',
 '휴지통',
 '휴지통',
 '휴지통',
 '휴지통',
 '휴지통',
 '휴지통',
 '휴지통',
 '휴지통',
 '휴지통', # 70
 '휴지통',
 '휴지통',
 '붙임시',
 '암석',
 '지석',
 '빙석',
 '풍석',
 '염석',
 '광석',
 '알', # 80
 '알',
 '알',
 '알',
 '고대 유적',
 'Millennium 크리스마스트리',
 '파괴된 침략자',
 '왕충의 탈피 껍질',
 '벚꽃',
 '향일아오이',
 '은은 행', # 90
 '크리스마스트리2002',
 '눈토끼',
 '행복의 여신상',
 '돼지 향취군',
 '산타클로 스',
 '인공염석',
 '인공빙석',
 '인공지석',
 '인공풍석',
 '인공광석',
 '인공암석',
 '모노리스'

 );

# 이미지 파일
@HmonumentImage =
 (
 'monument0.gif', # 0
 'monument5.gif',
 'monument3.gif',
 'monument12.gif',
 'monument11.gif',
 'monument13.gif',
 'monument16.gif',
 'monument15.gif',
 'monument14.gif',
 'monument17.gif',
 'monument18.gif', # 10
 'monument19.gif',
 'monument20.gif',
 'monument21.gif',
 'monument4.gif',
 'monument22.gif',
 'monument23.gif',
 'monument27.gif',
 'monument29.gif',
 'monument30.gif',
 'monument31.gif', # 20
 'monument32.gif',
 'monument33.gif',
 'monument34.gif',
 'monument35.gif',
 'monument40.gif',
 'monument46.gif',
 'monument47.gif',
 'monument21.gif',
 'monument21.gif',
 'monument21.gif', # 30
 'monument21.gif',
 'monument21.gif',
 'monument21.gif',
 'monument21.gif',
 'monument21.gif',
 'monument21.gif',
 'monument21.gif',
 'monument21.gif',
 'monument21.gif',
 'monument21.gif', # 40
 'monument21.gif',
 'monument21.gif',
 'monument21.gif',
 'monument21.gif',
 'monument21.gif',
 'monument21.gif',
 'monument21.gif',
 'monument21.gif',
 'monument21.gif',
 'monument21.gif', # 50
 'monument21.gif',
 'monument21.gif',
 'monument21.gif',
 'monument21.gif',
 'monument21.gif',
 'monument21.gif',
 'monument21.gif',
 'monument21.gif',
 'monument21.gif',
 'monument21.gif', # 60
 'monument21.gif',
 'monument21.gif',
 'monument21.gif',
 'monument21.gif',
 'monument21.gif',
 'monument21.gif',
 'monument21.gif',
 'monument21.gif',
 'monument21.gif',
 'monument21.gif', # 70
 'monument21.gif',
 'monument21.gif',
 'monument63.gif',
 'monument53.gif',
 'monument52.gif',
 'monument48.gif',
 'monument49.gif',
 'monument50.gif',
 'monument51.gif',
 'monument41.gif', # 80
 'monument42.gif',
 'monument43.gif',
 'monument44.gif',
 'monument45.gif',
 'monument9.gif',
 'monument24.gif',
 'monument25.gif',
 'monument26.gif',
 'monument28.gif',
 'monument36.gif', # 90
 'monument37.gif',
 'monument38.gif',
 'monument54.gif',
 'monument55.gif',
 'monument56.gif',
 'monument57.gif',
 'monument58.gif',
 'monument59.gif',
 'monument60.gif',
 'monument61.gif',
 'monument62.gif',
 'monument0.gif'
 );

#----------------------------------------
# 선박
#----------------------------------------
# 몇 종류가 있는지
$HfuneNumber = 12;

# 이름
@HfuneName =
 (
 '어선·개정',
 '소형어선',
 '안형어선',
 '해저 탐사선',
 '범선',
 '대형어선',
 '고속어선',
 '해저 탐사선·개정',
 '호화려고객선박 TITANIC',
 '전함 RENAS',
 '전함 ERADICATE',
 '어선 MASTER',
 '모노리스',
 '모노리스',
 '모노리스',
 '모노리스',
 '모노리스',
 '모노리스',
 '모노리스',
 '전함 ERADICATE·개정'
 );

@HfuneSpecial = ( 0, 0, 0, 0, 0, 0, 1, 2, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 5, 0);
# 특수 능력의 내용은,
# 0 특별히 없음
# 1 빠른 이동(최대 2걸음)
# 이족 보행 괴수 속도(최대 이동 칸 수는 불명)

# 이미지 파일
@HfuneImage =
 (
 'fune1.gif',
 'fune1.gif',
 'fune2.gif',
 'fune5.gif',
 'fune4.gif',
 'fune3.gif',
 'fune6.gif',
 'fune5.gif',
 'fune7.gif',
 'fune8.gif',
 'fune9.gif',
 'fune10.gif',
 'monument0.gif',
 'monument0.gif',
 'monument0.gif',
 'monument0.gif',
 'monument0.gif',
 'monument0.gif',
 'monument0.gif',
 'fune11.gif'
 );

#----------------------------------------
# 수상 관계
#----------------------------------------
# 턴 잔여 정보를 몇 턴마다 출력할지
$HturnPrizeUnit = 100;

# 상의 이름
$Hprize[0] = '턴잔';
$Hprize[1] = '번영상';
$Hprize[2] = '초과 번영상';
$Hprize[3] = '궁극번영상';
$Hprize[4] = '평화상';
$Hprize[5] = '초과 평화상';
$Hprize[6] = '궁극평화상';
$Hprize[7] = '재난상';
$Hprize[8] = '초과 재난상';
$Hprize[9] = '궁극재난상';

#----------------------------------------
# 화면 표시 관련
#----------------------------------------
# <BODY>태그의 옵션
my($htmlBody) = 'BGCOLOR="lemonchiffon"';

# 게임 제목 문자열
$Htitle = '☆Hakoniwa R.A.☆';

# 태그
# 제목문자
$HtagTitle_ = '<FONT SIZE=7 COLOR="#8888ff">';
$H_tagTitle = '</FONT>';

# H1태그용
$HtagHeader_ = '<FONT COLOR="#4444ff">';
$H_tagHeader = '</FONT>';

# 큰 글자
$HtagBig_ = '<FONT SIZE=5>';
$H_tagBig = '</FONT>';

# 섬 이름 등
$HtagName_ = '<FONT COLOR="#a06040"><B>';
$H_tagName = '</B></FONT>';

# 숨김 처리하지 않은 섬 이름
$HtagName2_ = '<FONT COLOR="#808080"><B>';
$H_tagName2 = '</B></FONT>';

# 순위 번호 등
$HtagNumber_ = '<FONT COLOR="#800000"><B>';
$H_tagNumber = '</B></FONT>';

# 순위표에오하기보기이고
$HtagTH_ = '<FONT COLOR="#C00000"><B>';
$H_tagTH = '</B></FONT>';

# toto 표에오하기보기이고
$HtagtTH_ = '<FONT COLOR="royalblue"><B>';
$H_tagtTH = '</B></FONT>';

# 개발계획의 이름
$HtagComName_ = '<FONT COLOR="#d08000"><B>';
$H_tagComName = '</B></FONT>';

# 재해
$HtagDisaster_ = '<FONT COLOR="#ff0000"><B>';
$H_tagDisaster = '</B></FONT>';

# 로컬 게시판, 관광객의 표시 문자
$HtagLbbsSS_ = '<FONT COLOR="#0000ff"><B>';
$H_tagLbbsSS = '</B></FONT>';

# 로컬 게시판, 섬주의 표시 문자
$HtagLbbsOW_ = '<FONT COLOR="#ff0000"><B>';
$H_tagLbbsOW = '</B></FONT>';

# 일반 문자색(BODY 태그의 옵션도 함께 변해야 합니다
$HnormalColor = '#000000';

# 순위표, 세루의 속성
$HbgTitleCell = 'BGCOLOR="LAVENDER"'; # 순위표 머리글시
$HbgNumberCell = 'BGCOLOR="LAVENDER"'; # 순위표순위
$HbgNameCell = 'BGCOLOR="LAVENDERBLUSH"'; # 순위표 섬 이름
$HbgInfoCell = 'BGCOLOR="LIGHTPINK"'; # 순위표 섬의 정보
$HbgCommentCell = 'BGCOLOR="LAVENDER"'; # 순위표코멘트란
$HbgInputCell = 'BGCOLOR="LAVENDER"'; # 개발계획양식
$HbgMapCell = 'BGCOLOR="LAVENDER"'; # 개발계획지도
$HbgCommandCell = 'BGCOLOR="LAVENDER"'; # 개발계획입력완료미계획
$HbgPoinCell = 'BGCOLOR="MOCCASIN"'; # Point 란
$HbgTotoCell = 'BGCOLOR="WHITE"'; # toto 란

#----------------------------------------------------------------------
# 필요에 따라 설정하는 항목은 여기까지입니다
#----------------------------------------------------------------------

#----------------------------------------------------------------------
# 아래쪽 스크립트는 변경을 전제로 하지 않습니다.
# 그래도 문제는 없습니다.
# 명령 이름과 가격 등은 알아보기 쉽게 두는 편이 좋습니다.
#----------------------------------------------------------------------

#----------------------------------------------------------------------
# 각종 상수
#----------------------------------------------------------------------
# 이 파일
$HthisFile = "$baseDir/hako-main.cgi";

# 지형 번호
$HlandSea = 0; # 바다
$HlandWaste = 1; # 황무지
$HlandPlains = 2; # 평지
$HlandTown = 3; # 읍계
$HlandForest = 4; # 숲
$HlandFarm = 5; # 농장
$HlandFactory = 6; # 공장
$HlandBase = 7; # 미사일 기지
$HlandDefence = 8; # 방위 시설
$HlandMountain = 9; # 산
$HlandMonster = 10; # 괴수
$HlandSbase = 11; # 해저 기지
$HlandOil = 12; # 해저 유전
$HlandMonument = 13; # 기념비
$HlandHaribote = 14; # 가짜 기지
$HlandSeacity = 15; # 해저 도시
$HlandPark = 16; # 놀이공원
$HlandMinato = 17; # 항구
$HlandFune = 18; # 선박
$HlandMine = 19; # 지뢰
$HlandNursery = 20; # 양식장
$HlandKyujo = 21; # 야구장
$HlandUmiamu = 22; # 해상 시설
$HlandFoodim = 23; # 식품 연구소
$HlandProcity = 24; # 방재 도시
$HlandGold = 25; # 금광산
$HlandSeki = 26; # 관문
$HlandRottenSea= 27; # 오염된 바다
$HlandNewtown = 28; # 뉴타운
$HlandBigtown = 29; # 현대 도시
$HlandSeatown = 30; # 해저뉴
$HlandFarmchi = 31;
$HlandFarmpic = 32;
$HlandFarmcow = 33;
$HlandCollege = 34;
$HlandFrocity = 35; # 해상 도시
$HlandSunahama = 36; # 해변
$HlandOnsen = 37; # 온천
$HlandHouse = 38; # 섬주의 가
$HlandShuto = 39; # 수도
$HlandUmishuto = 40; # 바다 수도
$HlandIce = 41; # 빙하
$HlandRizort = 42; # 리조트
$HlandBettown = 43; # 고층 도시
$HlandKyujokai = 44; # 다목적 경기장
$HlandBigRizort= 45; # 리조트숙박숙박시설
$HlandHTFactory= 46; # 첨단 기술기업
$HlandTaishi = 47; # 대사관
$HlandPlains2 = 48; # 개발 예정지
$HlandYakusho = 49; # 섬관청
$HlandKura = 50; # 창고
$HlandKuraf = 51; # 창고 Food
$HlandTrain = 52; # 철도 계열
$HlandEneAt = 53; # 철도 계열
$HlandEneFw = 54; # 철도 계열
$HlandEneWt = 55; # 철도 계열
$HlandConden = 56; # 콘덴서계
$HlandConden2 = 57; # 콘덴서계
$HlandEneWd = 58; # 전력계
$HlandEneBo = 59; # 전력계
$HlandEneSo = 60; # 전력계
$HlandEneCs = 61; # 전력계
$HlandFoodka = 62; # 식품가 공장
$HlandKajino = 63; # 카지노
$HlandConden3 = 64; # 콘덴서계
$HlandConden4 = 65; # 콘덴서계
$HlandSkycity = 66; # 공업 도시계
$HlandUmicity = 67; # 바다 도시계
$HlandZoo = 68; # 동물원계
$HlandSHTF = 69; # 첨단 기술기업·개정
$HlandOWNF = 70; # 섬운영기업

# 명령
$HcommandTotal = 90; # 명령 종류

# 계획 번호 설정
# 개간 계열
$HcomPrepare = 01; # 개간
$HcomPrepare2 = 02; # 땅고르기
$HcomReclaim = 03; # 매립
$HcomDestroy = 04; # 굴착
$HcomSellTree = 05; # 벌채
$HcomMinato = 06; # 항구개발
$HcomFune = 07; # 조선
$HcomSeki = 10; # 관문 건설

# 작루계
$HcomPlant = 11; # 나무 심기
$HcomFarm = 12; # 농장 건설
$HcomFactory = 13; # 공장 건설
$HcomMountain = 14; # 채굴장 건설
$HcomBase = 15; # 미사일 기지 건설
$HcomDbase = 16; # 방위 시설 건설
$HcomSbase = 17; # 해저 기지 건설
$HcomMonument = 18; # 기념비 건설
$HcomHaribote = 19; # 가짜 기지 건설
$HcomSeacity = 20; # 해저 도시 건설
$HcomMonbuy = 21; # 괴수구매
$HcomMonbuyt = 22; # tetora 구매
$HcomPark = 23; # 놀이공원 건설
$HcomMine = 24; # 지뢰 설치
$HcomNursery = 25; # 양식장 설치
$HcomKyujo = 26; # 야구장
$HcomUmiamu = 27; # 해상 시설 건설
$HcomFoodim = 28; # 식품 연구소 건설
$HcomProcity = 29; # 방재화
$HcomBoku = 30; # 주민 이주
$HcomNewtown = 70; # 뉴타운 건설
$HcomBigtown = 71; # 현대 도시 건설
$HcomSeatown = 72; # 해저뉴건설
$HcomFarmcpc = 73; # 목장건설
$HcomCollege = 74; # 대학 건설
$HcomOnsen = 75; # 온천 굴착
$HcomReclaim2 = 76; # 매립
$HcomHouse = 77; # 섬주의 가
$HcomRizort = 78; # 리조트
$HcomBettown = 79; # 고층 도시
$HcomGivefood = 100; # 먹이 주기
$HcomKai = 101; # 개장
$HcomHTget = 102; # 첨단 기술 유치
$HcomReclaim3 = 103; # 매립2
$HcomDestroy3 = 104; # 굴착2
$HcomYoyaku = 105; # 개발 예정
$HcomYakusho = 106; # 관청
$HcomKura = 107; # 창고
$HcomKura2 = 108; # 창고2
$HcomKuraf = 109; # 창고 Food
$HcomTrain = 110; # 철도 계열
$HcomEneAt = 111; # 철도 계열
$HcomEneFw = 112; # 철도 계열
$HcomEneWt = 113; # 철도 계열
$HcomConden = 114; # 콘덴서계
$HcomEneWd = 115; # 전력계
$HcomEneBo = 116; # 전력계
$HcomEneSo = 117; # 전력계
$HcomEneCs = 118; # 전력계
$HcomBoku2 = 119; # 마술사 2
$HcomEneNF = 120; # 전력계
$HcomZoo = 121; # 동물원계
$HcomAuction = 122; # 옥션

# 발사계
$HcomMissileNM = 31; # 미사일 발사
$HcomMissilePP = 32; # PP 미사일 발사
$HcomMissileST = 33; # ST 미사일 발사
$HcomMissileLD = 34; # 육지 파괴탄 발사
$HcomSendMonster = 35; # 괴수 파견
$HcomMissileSPP = 36; # SPP 미사일 발사
$HcomMissileSS = 37; # 핵 미사일 발사
$HcomMissileLR = 38; # 지형 융기탄 발사
$HcomEisei = 39; # 인공위성 발사
$HcomEiseimente = 40; # 인공위성 관리
$HcomEiseiLzr = 80; # 위성 레이저
$HcomEiseiAtt = 81; # 인공위성 파괴
$HcomTaishi = 82; # 대사 파견
$HcomMagic = 83; # 마술사 파견

# 운영계
$HcomDoNothing = 41; # 자금 융통
$HcomSell = 42; # 식량 수출
$HcomMoney = 43; # 자금 지원
$HcomFood = 44; # 식량 지원
$HcomPropaganda = 45; # 유치 활동
$HcomGiveup = 46; # 섬 포기
$HcomEneGive = 47; # 전력 지원

# 자동 입력
$HcomAutoPrepare = 61; # 전체 개간
$HcomAutoPrepare2 = 62; # 전체땅고르기
$HcomAutoDelete = 63; # 전체 명령 삭제
$HcomAutoReclaim = 64; # 매립
$HcomAutoDestroy = 65; # 굴착
$HcomAutoSellTree = 66; # 벌채
$HcomAutoForestry = 67; # 벌채와 나무 심기
$HcomAutoYoyaku = 68; # 개발 예정
$HcomAutoUchuste = 69; # 우주 정거장

$HcomIjiri = 60; # 이지리 명령

# 순서
@HcomList =
 ($HcomHouse, $HcomBettown, $HcomKai, $HcomBoku2, $HcomPrepare, $HcomSell, $HcomPrepare2, $HcomYoyaku, $HcomReclaim, $HcomReclaim2, $HcomReclaim3, $HcomDestroy, $HcomDestroy3, $HcomOnsen,
 $HcomSellTree, $HcomPlant, $HcomEneWd, $HcomEneWt, $HcomEneFw, $HcomEneAt, $HcomEneBo, $HcomEneSo, $HcomEneCs, $HcomEneNF, $HcomConden, $HcomFarm, $HcomFoodim, $HcomFarmcpc, $HcomFactory, $HcomHTget, $HcomMountain, $HcomNursery, $HcomCollege,
 $HcomPark, $HcomKyujo, $HcomUmiamu, $HcomZoo, $HcomRizort, $HcomBase, $HcomDbase, $HcomSbase, $HcomSeacity,
 $HcomMonument, $HcomMonbuy, $HcomMonbuyt, $HcomHaribote, $HcomMine,
 $HcomMinato, $HcomFune, $HcomProcity, $HcomNewtown, $HcomBigtown, $HcomSeatown, $HcomBoku, $HcomSeki, $HcomYakusho, $HcomKura, $HcomKuraf, $HcomKura2, $HcomTrain,
 $HcomEisei, $HcomEiseimente, $HcomTaishi, $HcomMagic,
 $HcomMissileNM, $HcomMissilePP, $HcomMissileSPP,
 $HcomMissileST, $HcomMissileLD, $HcomMissileLR, $HcomMissileSS, $HcomEiseiLzr, $HcomEiseiAtt, $HcomSendMonster, $HcomDoNothing,
 $HcomMoney, $HcomFood, $HcomEneGive, $HcomPropaganda, $HcomGiveup, $HcomGivefood,
 $HcomAutoReclaim, $HcomAutoDestroy, $HcomAutoSellTree, $HcomAutoForestry,
 $HcomAutoPrepare, $HcomAutoPrepare2, $HcomAutoYoyaku, $HcomAutoUchuste, $HcomAutoDelete, $HcomAuction, $HcomIjiri);

# JavaScript 모드 명령 분류
@HcommandDivido = (
 '기초 개발,1,20',
 '산업·시설,21,30',
 '미사일·특수,31,40',
 '운영,41,59',
 '자동 입력,60,69',
 '고급 시설,70,89',
 '확장 기능,90,129'
);


# 계획 이름과 비용
$HcomName[$HcomHouse] = '자택 건설/세율 변경';
$HcomCost[$HcomHouse] = 18; # ←이 값은 변경하지 마십시오.><
$HcomName[$HcomBettown] = '고층 도시 계획';
$HcomCost[$HcomBettown] = 28; # ←이 값은 변경하지 마십시오.><
$HcomName[$HcomKai] = '개장·강화';
$HcomCost[$HcomKai] = 28; # ←이 값은 변경하지 마십시오.><
$HcomName[$HcomBoku2] = '마술사 2';
$HcomCost[$HcomBoku2] = 48; # ←이 값은 변경하지 마십시오.><
$HcomName[$HcomPrepare] = '개간';
$HcomCost[$HcomPrepare] = 5;
$HcomName[$HcomPrepare2] = '땅고르기';
$HcomCost[$HcomPrepare2] = 1000;
$HcomName[$HcomReclaim] = '매립';
$HcomCost[$HcomReclaim] = 150;
$HcomName[$HcomEneWt] = '수력 발전소 건설';
$HcomCost[$HcomEneWt] = 300;
$HcomName[$HcomEneFw] = '화력 발전소 건설';
$HcomCost[$HcomEneFw] = 7500;
$HcomName[$HcomEneAt] = '원자력 발전소 건설';
$HcomCost[$HcomEneAt] = 40000;
$HcomName[$HcomEneWd] = '풍력 발전소 건설';
$HcomCost[$HcomEneWd] = 150;
$HcomName[$HcomEneBo] = '바이오매스 발전소 건설';
$HcomCost[$HcomEneBo] = 40000;
$HcomName[$HcomEneSo] = '태양광 발전소 건설';
$HcomCost[$HcomEneSo] = 60000;
$HcomName[$HcomEneCs] = '코스모 발전소 건설';
$HcomCost[$HcomEneCs] = 298000;
$HcomName[$HcomEneNF] = '핵융합 발전소 건설';
$HcomCost[$HcomEneNF] = 1500000;
$HcomName[$HcomConden] = '콘덴서 건설';
$HcomCost[$HcomConden] = 98000;
$HcomName[$HcomReclaim2] = '원거리 매립';
$HcomCost[$HcomReclaim2] = 5000;
$HcomName[$HcomReclaim3] = '2단계 매립';
$HcomCost[$HcomReclaim3] = 5000;
$HcomName[$HcomDestroy3] = '2단계 굴착';
$HcomCost[$HcomDestroy3] = 3000;
$HcomName[$HcomYoyaku] = '개발 예정 계획';
$HcomCost[$HcomYoyaku] = 1000;
$HcomName[$HcomYakusho] = '섬 관청 건설';
$HcomCost[$HcomYakusho] = 30000;
$HcomName[$HcomKura] = '창고건설·저금';
$HcomCost[$HcomKura] = 10500;
$HcomName[$HcomKuraf] = '창고건설·저장 식량';
$HcomCost[$HcomKuraf] = -10000;
$HcomName[$HcomKura2] = '창고인출';
$HcomCost[$HcomKura2] = 500;
$HcomName[$HcomTrain] = '역·선로·열차 건설';
$HcomCost[$HcomTrain] = 10000;
$HcomName[$HcomDestroy] = '굴착';
$HcomCost[$HcomDestroy] = 200;
$HcomName[$HcomOnsen] = '온천 굴착';
$HcomCost[$HcomOnsen] = 50;
$HcomName[$HcomMinato] = '항구 도시 개발';
$HcomCost[$HcomMinato] = 550;
$HcomName[$HcomFune] = '조선·출항';
$HcomCost[$HcomFune] = 500;
$HcomName[$HcomSeki] = '관문 건설';
$HcomCost[$HcomSeki] = 1000;
$HcomName[$HcomSellTree] = '벌채';
$HcomCost[$HcomSellTree] = 0;
$HcomName[$HcomPlant] = '나무 심기';
$HcomCost[$HcomPlant] = 50;
$HcomName[$HcomFarm] = '농장 건설';
$HcomCost[$HcomFarm] = 20;
$HcomName[$HcomFoodim] = '식품 연구소 건설';
$HcomCost[$HcomFoodim] = 5000;
$HcomName[$HcomFarmcpc] = '목장 건설/가축 판매';
$HcomCost[$HcomFarmcpc] = 3000;
$HcomName[$HcomCollege] = '대학 건설';
$HcomCost[$HcomCollege] = 2000;
$HcomName[$HcomFactory] = '공장 건설';
$HcomCost[$HcomFactory] = 100;
$HcomName[$HcomHTget] = '첨단 기술 유치';
$HcomCost[$HcomHTget] = 10000;
$HcomName[$HcomMountain] = '채굴장 건설';
$HcomCost[$HcomMountain] = 300;
$HcomName[$HcomBase] = '미사일 기지 건설';
$HcomCost[$HcomBase] = 300;
$HcomName[$HcomDbase] = '방위 시설 건설';
$HcomCost[$HcomDbase] = 800;
$HcomName[$HcomSbase] = '해저 기지 건설';
$HcomCost[$HcomSbase] = 10000;
$HcomName[$HcomSeacity] = '해저 도시 건설';
$HcomCost[$HcomSeacity] = 77777;
$HcomName[$HcomMonument] = '기념비 건설';
$HcomCost[$HcomMonument] = 9999;
$HcomName[$HcomMonbuy] = '괴수의 구매·배치';
$HcomCost[$HcomMonbuy] = 3980;
$HcomName[$HcomMonbuyt] = '테트라의 구매·배치';
$HcomCost[$HcomMonbuyt] = 10000;
$HcomName[$HcomHaribote] = '가짜 기지 건설';
$HcomCost[$HcomHaribote] = 1;
$HcomName[$HcomMine] = '지뢰 설치';
$HcomCost[$HcomMine] = 100;
$HcomName[$HcomPark] = '놀이공원 건설';
$HcomCost[$HcomPark] = 3000;
$HcomName[$HcomZoo] = '동물원 건설';
$HcomCost[$HcomZoo] = 100000;
$HcomName[$HcomNursery] = '양식장 설치';
$HcomCost[$HcomNursery] = 50;
$HcomName[$HcomKyujo] = '야구장 건설';
$HcomCost[$HcomKyujo] = 5000;
$HcomName[$HcomUmiamu] = '해상 시설 건설';
$HcomCost[$HcomUmiamu] = 15000;
$HcomName[$HcomRizort] = '리조트 개발';
$HcomCost[$HcomRizort] = 50000;
$HcomName[$HcomProcity] = '방재 도시화';
$HcomCost[$HcomProcity] = 25000;
$HcomName[$HcomNewtown] = '뉴타운 건설';
$HcomCost[$HcomNewtown] = 950;
$HcomName[$HcomBigtown] = '현대 도시 건설';
$HcomCost[$HcomBigtown] = 45000;
$HcomName[$HcomSeatown] = '해저 신도시 건설';
$HcomCost[$HcomSeatown] = 69800;
$HcomName[$HcomBoku] = '주민 이주';
$HcomCost[$HcomBoku] = 1000;
$HcomName[$HcomTaishi] = '대사 파견';
$HcomCost[$HcomTaishi] = 50000;
$HcomName[$HcomMagic] = '마술사 파견';
$HcomCost[$HcomMagic] = 5000;
$HcomName[$HcomEisei] = '인공위성 발사';
$HcomCost[$HcomEisei] = 9999;
$HcomName[$HcomEiseimente] = '인공위성 복구';
$HcomCost[$HcomEiseimente] = 5000;
$HcomName[$HcomEiseiLzr] = '위성 레이저 발사';
$HcomCost[$HcomEiseiLzr] = 39999;
$HcomName[$HcomEiseiAtt] = '위성 파괴포 발사';
$HcomCost[$HcomEiseiAtt] = 49999;
$HcomName[$HcomMissileNM] = '미사일 발사';
$HcomCost[$HcomMissileNM] = 20;
$HcomName[$HcomMissilePP] = 'PP 미사일 발사';
$HcomCost[$HcomMissilePP] = 500;
$HcomName[$HcomMissileSPP] = 'SPP 미사일 발사';
$HcomCost[$HcomMissileSPP] = 2000;
$HcomName[$HcomMissileST] = 'ST 미사일 발사';
$HcomCost[$HcomMissileST] = 50;
$HcomName[$HcomMissileLD] = '육지 파괴탄 발사';
$HcomCost[$HcomMissileLD] = 3000;
$HcomName[$HcomMissileLR] = '지형 융기탄 발사';
$HcomCost[$HcomMissileLR] = 5000;
$HcomName[$HcomMissileSS] = '핵 미사일 발사';
$HcomCost[$HcomMissileSS] = 12000;
$HcomName[$HcomSendMonster] = '괴수 파견';
$HcomCost[$HcomSendMonster] = 10000;
$HcomName[$HcomDoNothing] = '자금 융통';
$HcomCost[$HcomDoNothing] = 0;
$HcomName[$HcomSell] = '식량 수출';
$HcomCost[$HcomSell] = -100;
$HcomName[$HcomMoney] = '자금 지원';
$HcomCost[$HcomMoney] = 100;
$HcomName[$HcomFood] = '식량 지원';
$HcomCost[$HcomFood] = -100;
$HcomName[$HcomEneGive] = '전력 지원';
$HcomCost[$HcomEneGive] = 100;
$HcomName[$HcomPropaganda] = '유치 활동';
$HcomCost[$HcomPropaganda] = 2000;
$HcomName[$HcomGiveup] = '섬 포기';
$HcomCost[$HcomGiveup] = 0;
$HcomName[$HcomGivefood] = '먹이 주기';
$HcomCost[$HcomGivefood] = -50000;
$HcomName[$HcomAutoPrepare] = '개간 자동 입력';
$HcomCost[$HcomAutoPrepare] = 0;
$HcomName[$HcomAutoPrepare2] = '땅고르기 자동 입력';
$HcomCost[$HcomAutoPrepare2] = 0;
$HcomName[$HcomAutoDelete] = '전체 계획 백지화';
$HcomCost[$HcomAutoDelete] = 0;
$HcomName[$HcomAutoReclaim] = '매립 자동 입력';
$HcomCost[$HcomAutoReclaim] = 0;
$HcomName[$HcomAutoDestroy] = '굴착 자동 입력';
$HcomCost[$HcomAutoDestroy] = 0;
$HcomName[$HcomAutoSellTree] = '벌채 자동 입력';
$HcomCost[$HcomAutoSellTree] = 0;
$HcomName[$HcomAutoForestry] = '벌채&나무 심기 자동 입력';
$HcomCost[$HcomAutoForestry] = 0;
$HcomName[$HcomAutoYoyaku] = '개발 예정 계획 자동 입력';
$HcomCost[$HcomAutoYoyaku] = 0;
$HcomName[$HcomAutoUchuste] = '우주 정거장 복구 자동 입력';
$HcomCost[$HcomAutoUchuste] = 0;
$HcomName[$HcomAuction] = '옥션 출품';
$HcomCost[$HcomAuction] = 0;
$HcomName[$HcomIjiri] = '원형비밀(>_<)~)';
$HcomCost[$HcomIjiri] = 0;

#----------------------------------------------------------------------
# 변수
#----------------------------------------------------------------------

# COOKIE
my($defaultID); # 섬 이름
my($defaultTarget); # 대상의 이름


# 섬의 좌표 수
$HpointNumber = $HislandSize * $HislandSize;

# JavaScript 모드 설정(hakora451에서 이식)
$HjavaMode = 'cgi';
$HjavaModeSet = 'cgi';
$HcommandComary = '';
$HmenuOpen = '';
$HmenuOpen2 = '';
$HextraJs = 0;
$islandSize = $HislandSize - 1;

#----------------------------------------------------------------------
# 메인
#----------------------------------------------------------------------

# 문자 변환 라이브러리 로드

# '돌아가기'링크
$HtempBack = "<A CLASS=\"type3\" HREF=\"$HthisFile\">${HtagBig_}맨 위로 돌아가기${H_tagBig}</A>";

# 잠금을 끼치기
if(!hakolock()) {
 # 잠금실패
 # 헤더출력
 tempHeader();

 # 잠금실패 메시지
 tempLockFail();

 # 푸터출력
 tempFooter();

 # 종료
 exit(0);
}

# 난수의 초기화
srand(time^$$);

# COOKIE 읽기
cookieInput();

# CGI 읽기
cgiInput();

# 섬 데이터 읽기
if(readIslandsFile($HcurrentID) == 0) {
 unlock();
 tempHeader();
 tempNoDataFile();
 tempFooter();
 exit(0);
}

# 템플릿을 초기화
tempInitialize();

# COOKIE 출력
cookieOutput();

# 헤더출력
# JavaScript 모드는 전용 화면을 출력해야 합니다.
# 일반 헤더를 먼저 출력하면 이후 JavaScript 개발 화면이 중복/중단될 수 있으므로
# hakora451과 동일하게 JavaScript 모드 분기를 먼저 처리합니다.
if((($HmainMode eq 'owner') && ($HjavaMode eq 'java')) ||
   ($HmainMode eq 'commandJava') ||
   (($HmainMode eq 'comment') && ($HjavaMode eq 'java')) ||
   (($HmainMode eq 'lbbs') && ($HjavaMode eq 'java')) ||
   ($HmainMode eq 'islandMap')) {
 require('hako-map.cgi');
 tempHeaderJava();
 if($HmainMode eq 'commandJava') {
	commandJavaMain();
 } elsif($HmainMode eq 'comment') {
	commentMain();
 } elsif($HmainMode eq 'lbbs') {
	localBbsMain();
 } elsif($HmainMode eq 'islandMap') {
	printIslandJava();
 } else {
	ownerMain();
 }
 tempFooter();
 exit(0);
}

tempHeader();

if($HmainMode eq 'turn') {
 # 턴진행
 require('hako-turn.cgi');
 require('hako-top.cgi');
 turnMain();

} elsif($HmainMode eq 'new') {
 # 섬 신규 생성
 require('hako-turn.cgi');
 require('hako-map.cgi');
 newIslandMain();

} elsif($HmainMode eq 'print') {
 # 관광 모드
 require('hako-map.cgi');
 printIslandMain();

} elsif($HmainMode eq 'islandMap') {
 # JavaScript 모드 좌표 선택용 지도
 require('hako-map.cgi');
 printIslandJava();

} elsif($HmainMode eq 'owner') {

 # 개발 모드
 require('hako-map.cgi');
 ownerMain();

} elsif($HmainMode eq 'command') {
 # 명령입력 모드
 require('hako-map.cgi');
 commandMain();

} elsif($HmainMode eq 'commandJava') {
 # JavaScript 모드 명령 일괄 입력
 require('hako-map.cgi');
 commandJavaMain();

} elsif($HmainMode eq 'comment') {
 # 코멘트입력 모드
 require('hako-map.cgi');
 commentMain();

} elsif($HmainMode eq 'lbbs') {

 # 로컬 게시판 모드
 require('hako-map.cgi');
 localBbsMain();

} elsif($HmainMode eq 'change') {
 # 정보 변경 모드
 require('hako-turn.cgi');
 require('hako-top.cgi');
 changeMain();

} elsif($HmainMode eq 'ipinfo') {
 # IP 정보 모드
 if($HoldPassword eq $masterPassword) {
	# 마스터 비밀번호
	require('hako-top2.cgi');
	topPageMain();
 } else {
	require('hako-top.cgi');
	topPageMain();
 }

} elsif($HmainMode eq 'chowner') {
 # 소유자 이름 변경 모드
 require('hako-turn.cgi');
 require('hako-top.cgi');
 changeOwner();

} elsif($HmainMode eq 'ankeito') {
 require('hako-map.cgi');
 changeAnkeito();

} elsif($HmainMode eq 'totoyoso') {
 # 코멘트입력 모드
 require('hako-map.cgi');
 totoMain();

} elsif($HmainMode eq 'totoyoso2') {
 # 코멘트입력 모드
 require('hako-map.cgi');
 totosMain();

} elsif($HmainMode eq 'shouene') {
 # 코멘트입력 모드
 require('hako-map.cgi');
 shoueneMain();

} elsif($HmainMode eq 'bousai') {
 # 코멘트입력 모드
 require('hako-map.cgi');
 bousaiMain();

} elsif($HmainMode eq 'kankou') {
 # 코멘트입력 모드
 require('hako-map.cgi');
 kankouMain();

} elsif($HmainMode eq 'sizen') {
 # 코멘트입력 모드
 require('hako-map.cgi');
 sizenMain();

} elsif($HmainMode eq 'kyouiku') {
 # 코멘트입력 모드
 require('hako-map.cgi');
 kyouikuMain();

} elsif($HmainMode eq 'chochiku') {
 # 코멘트입력 모드
 require('hako-map.cgi');
 chochikuMain();

} elsif($HmainMode eq 'auction') {
 # 코멘트입력 모드
 require('hako-map.cgi');
 auctionMain();

} elsif($HmainMode eq 'mskyoka') {
 require('hako-map.cgi');
 msMain();

} elsif($HmainMode eq 'ms2kyoka') {
 require('hako-map.cgi');
 ms2Main();

} else {
 # 그 외에는 톱 페이지 모드
 require('hako-top.cgi');
 topPageMain();
}

# 푸터출력
tempFooter();

# 종료
exit(0);

# 명령을 전에밀기
sub slideFront {
 my($command, $number) = @_;
 my($i);

 # 각각밀기
 splice(@$command, $number, 1);

 # 마지막에 자금 융통
 $command->[$HcommandMax - 1] = {
	'kind' => $HcomDoNothing,
	'target' => 0,
	'x' => 0,
	'y' => 0,
	'arg' => 0
	};
}

# 명령을 후에밀기
sub slideBack {
 my($command, $number) = @_;
 my($i);

 # 각각밀기
 return if $number == $#$command;
 pop(@$command);
 splice(@$command, $number, 0, $command->[$number]);
}

#----------------------------------------------------------------------
# 섬 데이터 입출력
#----------------------------------------------------------------------

# 전체 섬 데이터 읽기
sub readIslandsFile {
 my($num) = @_; # 0이면 지형읽기 전
 # -1이면 전체 지형을 읽어들임
 # 번호가 지정되면 해당 섬의 지형만 읽어들임

 # 데이터 파일 열기
 if(!open(IN, "${HdirName}/hakojima.dat")) {
	rename("${HdirName}/hakojima.tmp", "${HdirName}/hakojima.dat");
	if(!open(IN, "${HdirName}/hakojima.dat")) {
	 return 0;
	}
 }

 open(OIN, "${HdirName}/howner.dat");
 open(PIN, "${HdirName}/ips.dat");
 open(AIN, "${HdirName}/auction.dat");
 open(KIN, "${HdirName}/an.dat");

 # 각매개변수읽기
 $HislandTurn = int(<IN>); # 턴 수
 if($HislandTurn == 0) {
	return 0;
 }
 $HislandLastTime = int(<IN>); # 최종 갱신 시간
 if($HislandLastTime == 0) {
	return 0;
 }
 $HislandNumber = int(<IN>); # 섬의 총 수
 $HislandNextID = int(<IN>); # 다음에 할당할 ID

 $auction1 = <AIN>;
 chomp($auction1);
 if($auction1 == '') {
	$shuppin = random(27)+1;
	$auction1 = "$shuppin,0,0,0,0";
 }
 $auction2 = <AIN>;
 chomp($auction2);
 if($auction2 == '') {
	$shuppin = random(27)+1;
	$auction2 = "$shuppin,0,0,0,0";
 }
 $auction3 = <AIN>;
 chomp($auction3);
 if($auction3 == '') {
	$shuppin = random(27)+1;
	$auction3 = "$shuppin,0,0,0,0";
 }

 $an1 = int(<KIN>);
 if($an1 == '') {
	$an1 = "0";
 }
 $an2 = int(<KIN>);
 if($an2 == '') {
	$an2 = "0";
 }
 $an3 = int(<KIN>);
 if($an3 == '') {
	$an3 = "0";
 }
 $an4 = int(<KIN>);
 if($an4 == '') {
	$an4 = "0";
 }
 $an5 = int(<KIN>);
 if($an5 == '') {
	$an5 = "0";
 }

 # 턴 처리판정
 my($now) = time;
 if((($Hdebug == 1) &&
	($HmainMode eq 'Hdebugturn')) ||
 (($now - $HislandLastTime)>= $HunitTime)) {
	$HmainMode = 'turn';
	$num = -1; # 전체 섬읽어들임
 }

 # 섬읽기
 my($i);
 for($i = 0; $i < $HislandNumber; $i++) {
	 $Hislands[$i] = readIsland($num);
	 $HidToNumber{$Hislands[$i]->{'id'}} = $i;
 }

 # 괴수출현 수읽기
 if (!$HnewGame) {
 if (open(MIN, "<${HdirName}/monslive.dat")) {
 for ($i = 0; $i < $HislandNumber; $i++) {
 $Hislands[$i]->{'monsterlive'} = int(<MIN>);
 $Hislands[$i]->{'monsterlivetype'} = int(<MIN>);
 $Hislands[$i]->{'eisei1'} = int(<MIN>);
 $Hislands[$i]->{'eisei2'} = int(<MIN>);
 $Hislands[$i]->{'eisei3'} = int(<MIN>);
 $Hislands[$i]->{'eisei4'} = int(<MIN>);
 $Hislands[$i]->{'eisei5'} = int(<MIN>);
 $Hislands[$i]->{'eisei6'} = int(<MIN>);
 }
 close(MIN);
 } else {
 for ($i = 0; $i < $HislandNumber; $i++) {
 $Hislands[$i]->{'monsterlive'} = 0;
 $Hislands[$i]->{'monsterlivetype'} = 0;
 $Hislands[$i]->{'eisei1'} = 0;
 $Hislands[$i]->{'eisei2'} = 0;
 $Hislands[$i]->{'eisei3'} = 0;
 $Hislands[$i]->{'eisei4'} = 0;
 $Hislands[$i]->{'eisei5'} = 0;
 $Hislands[$i]->{'eisei6'} = 0;
 }
 }
 }

 # 파일을 닫기
 close(IN);
 close(OIN);
 close(PIN);
 close(AIN);
 close(KIN);
 return 1;
}

# 섬 하나 읽기
sub readIsland {
 my($num) = @_;
 my($name, $id, $prize, $absent, $comment, $password, $money, $food,
 $pop, $area, $farm, $factory, $mountain, $pts, $eis1, $eis2, $eis3, $eis4, $eis5, $eis6, $eis7, $eis8, $taiji, $onm, $monslive, $monslivetype, $eisei1, $eisei2, $eisei3, $eisei4, $eisei5, $eisei6, $score);
 $name = <IN>; # 섬 이름
 chomp($name);
 if($name =~ s/,(.*)$//g) {
	$score = int($1);
 } else {
	$score = 0;
 }
 $id = int(<IN>); # ID 번호
 $id1= int(<OIN>);
 $ownername = <OIN>;
 chomp($ownername);
 $totoyoso = <OIN>;
 chomp($totoyoso);
 $totoyoso2 = <OIN>;
 chomp($totoyoso2);
 $kei = int(<OIN>);
 $rena = int(<OIN>);
 $momotan = int(<OIN>);
 $fore = int(<OIN>);
 $pika = int(<OIN>);
 $hamu = int(<OIN>);
 $monta = int(<OIN>);
 $tare = int(<OIN>);
 $zipro = int(<OIN>);
 $leje = int(<OIN>);
 $ipname = <PIN>;
 chomp($ipname);
 $ip0 = <PIN>;
 chomp($ip0);
 $ip1 = <PIN>;
 chomp($ip1);
 $ip2 = <PIN>;
 chomp($ip2);
 $ip3 = <PIN>;
 chomp($ip3);
 $ip4 = <PIN>;
 chomp($ip4);
 $ip5 = <PIN>;
 chomp($ip5);
 $ip6 = <PIN>;
 chomp($ip6);
 $ip7 = <PIN>;
 chomp($ip7);
 $ip8 = int(<PIN>);
 $ip9 = int(<PIN>);
 $etc0 = int(<PIN>);
 $etc1 = int(<PIN>);
 $etc2 = int(<PIN>);
 $etc3 = int(<PIN>);
 $etc4 = int(<PIN>);
 $etc5 = <PIN>;
 chomp($etc5);
 $etc6 = <PIN>;
 chomp($etc6);
 $etc7 = <PIN>;
 chomp($etc7);
 $etc8 = <PIN>;
 chomp($etc8);
 $etc9 = <PIN>;
 chomp($etc9);
 $auc0 = <AIN>;
 chomp($auc0);
 if($auc0 == '') {
	$auc0 = '0,0,0,0,0';
 }
 $auc1 = int(<AIN>);
 if($auc1 == '') {
	$auc1 = 0;
 }
 $auc2 = int(<AIN>);
 if($auc2 == '') {
	$auc2 = 0;
 }
 $auc3 = int(<AIN>);
 if($auc3 == '') {
	$auc3 = 0;
 }
 $auc4 = <AIN>;
 chomp($auc4);
 if($auc4 == '') {
	$auc4 = '0,0,0';
 }
 $auc5 = <AIN>;
 chomp($auc5);
 if($auc5 == '') {
	$auc5 = '0,0,0,0,0';
 }
 $auc6 = <AIN>;
 chomp($auc6);
 if($auc6 == '') {
	$auc6 = '0,0,0';
 }
 $auc7 = <AIN>;
 chomp($auc7);
 $auc8 = <AIN>;
 chomp($auc8);
 $auc9 = <AIN>;
 chomp($auc9);
 if($auc9 == '') {
	$auc9 = '0,0,0,0,0';
 }

 $anflag = int(<KIN>);
 if($anflag == '') {
	$anflag = '1';
 }

 $prize = <IN>; # 수상
 chomp($prize);
 $absent = int(<IN>); # 연속 자금 융통 수
 $comment = <IN>; # 코멘트
 chomp($comment);
 $password = <IN>; # 암호화 비밀번호
 chomp($password);
 $money = int(<IN>); # 자금
 $food = int(<IN>); # 식량
 $pop = int(<IN>); # 인구
 $area = int(<IN>); # 면적
 $farm = int(<IN>); # 농장
 $factory = <IN>;
 chomp($factory);
 $mountain = int(<IN>); # 채굴장
 $pts = int(<IN>); # 포인트
 $eis1 = int(<IN>);
 $eis2 = int(<IN>);
 $eis3 = int(<IN>);
 $eis4 = int(<IN>);
 $eis5 = int(<IN>);
 $eis6 = int(<IN>);
 $eis7 = int(<IN>);
 $eis8 = <IN>;
 chomp($eis8);
 $taiji = int(<IN>);
 $onm = <IN>;
 chomp($onm);
 $monslive = int(<IN>) if ($HnewGame); # 괴수출현 수
 $monslivetype = int(<IN>) if ($HnewGame); # 괴수출현종류
 $eisei1 = int(<IN>) if ($HnewGame);
 $eisei2 = int(<IN>) if ($HnewGame);
 $eisei3 = (<IN>) if ($HnewGame);
 chomp($eisei3);
 $eisei4 = (<IN>) if ($HnewGame);
 chomp($eisei4);
 $eisei5 = (<IN>) if ($HnewGame);
 chomp($eisei5);
 $eisei6 = (<IN>) if ($HnewGame);
 chomp($eisei6);

 # HidToName 테이블에 저장
 $HidToName{$id} = $name;	#

 # 지형
 my(@land, @landValue, $line, @command, @lbbs);

 if(($num == -1) || ($num == $id)) {
	if(!open(IIN, "${HdirName}/island.$id")) {
	 rename("${HdirName}/islandtmp.$id", "${HdirName}/island.$id");
	 if(!open(IIN, "${HdirName}/island.$id")) {
		exit(0);
	 }
	}
	my($x, $y);
	for($y = 0; $y < $HislandSize; $y++) {
	 $line = <IIN>;
	 for($x = 0; $x < $HislandSize; $x++) {
		$line =~ s/^(..)(...)//;
		$land[$x][$y] = hex($1);
		$landValue[$x][$y] = hex($2);
	 }
	}

	# 명령
	my($i);
	for($i = 0; $i < $HcommandMax; $i++) {
	 $line = <IIN>;
	 $line =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	 $command[$i] = {
		'kind' => int($1),
		'target' => int($2),
		'x' => int($3),
		'y' => int($4),
		'arg' => int($5)
		}
	}

	# 로컬 게시판
	for($i = 0; $i < $HlbbsMax; $i++) {
	 $line = <IIN>;
	 chomp($line);
 if ($HlbbsOldToNew) {
 # 게시판 로그의 형식을 변환하다
 if ($line =~ /^([0-9]*)\>(.*)\>(.*)$/) {
 # 표준 형식 로그임
 $line = "0<<$1>$2>$3";
 }
 }
	 $lbbs[$i] = $line;
	}

	close(IIN);
 }

 # 섬형로 하고반환
 return {
	 'name' => $name,
 'ownername' => $ownername,
	 'id' => $id,
	 'id1' => $id1,
	 'score' => $score,
	 'prize' => $prize,
	 'absent' => $absent,
	 'comment' => $comment,
	 'password' => $password,
	 'money' => $money,
	 'food' => $food,
	 'pop' => $pop,
	 'area' => $area,
	 'farm' => $farm,
	 'factory' => $factory,
	 'mountain' => $mountain,
	 'pts' => $pts,
	 'eis1' => $eis1,
	 'eis2' => $eis2,
	 'eis3' => $eis3,
	 'eis4' => $eis4,
	 'eis5' => $eis5,
	 'eis6' => $eis6,
	 'eis7' => $eis7,
	 'eis8' => $eis8,
	 'taiji' => $taiji,
	 'onm' => $onm,
	 'ipname' => $ipname,
	 'ip0' => $ip0,
	 'ip1' => $ip1,
	 'ip2' => $ip2,
	 'ip3' => $ip3,
	 'ip4' => $ip4,
	 'ip5' => $ip5,
	 'ip6' => $ip6,
	 'ip7' => $ip7,
	 'ip8' => $ip8,
	 'ip9' => $ip9,
	 'etc0' => $etc0,
	 'etc1' => $etc1,
	 'etc2' => $etc2,
	 'etc3' => $etc3,
	 'etc4' => $etc4,
	 'etc5' => $etc5,
	 'etc6' => $etc6,
	 'etc7' => $etc7,
	 'etc8' => $etc8,
	 'etc9' => $etc9,
	 'auc0' => $auc0,
	 'auc1' => $auc1,
	 'auc2' => $auc2,
	 'auc3' => $auc3,
	 'auc4' => $auc4,
	 'auc5' => $auc5,
	 'auc6' => $auc6,
	 'auc7' => $auc7,
	 'auc8' => $auc8,
	 'auc9' => $auc9,
	 'anflag' => $anflag,
 'monsterlive' => $monslive,
 'monsterlivetype' => $monslivetype,
 'eisei1' => $eisei1,
 'eisei2' => $eisei2,
 'eisei3' => $eisei3,
 'eisei4' => $eisei4,
 'eisei5' => $eisei5,
 'eisei6' => $eisei6,
 'totoyoso' => $totoyoso,
 'totoyoso2' => $totoyoso2,
 'kei' => $kei,
 'rena' => $rena,
 'momotan' => $momotan,
 'fore' => $fore,
 'pika' => $pika,
 'hamu' => $hamu,
 'monta' => $monta,
 'tare' => $tare,
 'zipro' => $zipro,
 'leje' => $leje,
	 'land' => \@land,
	 'landValue' => \@landValue,
	 'command' => \@command,
	 'lbbs' => \@lbbs,
 };
}

# 소유자 이름을 기술
sub writeIslandsOwner {
 my($num) = @_;
 # File Open
 open(OUT, ">${HdirName}/howner.tmp");
 my($i);
 for($i = 0; $i < $HislandNumber; $i++){
 print OUT "$Hislands[$i]->{'id1'}\n";
 print OUT "$Hislands[$i]->{'ownername'}\n";
 print OUT "$Hislands[$i]->{'totoyoso'}\n";
 print OUT "$Hislands[$i]->{'totoyoso2'}\n";
 print OUT "$Hislands[$i]->{'kei'}\n";
 print OUT "$Hislands[$i]->{'rena'}\n";
 print OUT "$Hislands[$i]->{'momotan'}\n";
 print OUT "$Hislands[$i]->{'fore'}\n";
 print OUT "$Hislands[$i]->{'pika'}\n";
 print OUT "$Hislands[$i]->{'hamu'}\n";
 print OUT "$Hislands[$i]->{'monta'}\n";
 print OUT "$Hislands[$i]->{'tare'}\n";
 print OUT "$Hislands[$i]->{'zipro'}\n";
 print OUT "$Hislands[$i]->{'leje'}\n";
 }

 close(OUT);

 # 원래 이름으로
 unlink("${HdirName}/howner.dat");
 rename("${HdirName}/howner.tmp", "${HdirName}/howner.dat");
}

# 전체 섬 데이터 쓰기
sub writeIslandsFile {
 my($num) = @_;

 # 파일을 열기
 open(OUT, ">${HdirName}/hakojima.tmp");
 open(HOUT, ">${HdirName}/howner.tmp");
 open(POUT, ">${HdirName}/ips.tmp");
 open(AOUT, ">${HdirName}/auction.tmp");
 open(KOUT, ">${HdirName}/an.tmp");

 # 각 매개변수 쓰기
 print OUT "$HislandTurn\n";
 print OUT "$HislandLastTime\n";
 print OUT "$HislandNumber\n";
 print OUT "$HislandNextID\n";

 print AOUT "$auction1\n";
 print AOUT "$auction2\n";
 print AOUT "$auction3\n";

 print KOUT "$an1\n";
 print KOUT "$an2\n";
 print KOUT "$an3\n";
 print KOUT "$an4\n";
 print KOUT "$an5\n";

 # 섬의 쓰기
 my($i);
 for($i = 0; $i < $HislandNumber; $i++) {
	 writeIsland($Hislands[$i], $num);
 }

 # 괴수출현 수의 쓰기
 if (!$HnewGame) {
 if (open(MIN, ">${HdirName}/monslive.dat")) {
 for ($i = 0; $i < $HislandNumber; $i++) {
 print MIN $Hislands[$i]->{'monsterlive'}. "\n";
 print MIN $Hislands[$i]->{'monsterlivetype'}. "\n";
 print MIN $Hislands[$i]->{'eisei1'}. "\n";
 print MIN $Hislands[$i]->{'eisei2'}. "\n";
 print MIN $Hislands[$i]->{'eisei3'}. "\n";
 print MIN $Hislands[$i]->{'eisei4'}. "\n";
 print MIN $Hislands[$i]->{'eisei5'}. "\n";
 print MIN $Hislands[$i]->{'eisei6'}. "\n";
 }
 close(MIN);
 }
 }

 # 파일을 닫기
 close(OUT);
 close(HOUT);
 close(POUT);
 close(AOUT);
 close(KOUT);

 # 원래 이름으로
 unlink("${HdirName}/hakojima.dat");
 rename("${HdirName}/hakojima.tmp", "${HdirName}/hakojima.dat");

 unlink("${HdirName}/howner.dat");
 rename("${HdirName}/howner.tmp", "${HdirName}/howner.dat");

 unlink("${HdirName}/ips.dat");
 rename("${HdirName}/ips.tmp", "${HdirName}/ips.dat");

 unlink("${HdirName}/auction.dat");
 rename("${HdirName}/auction.tmp", "${HdirName}/auction.dat");

 unlink("${HdirName}/an.dat");
 rename("${HdirName}/an.tmp", "${HdirName}/an.dat");

}

# 섬 하나 쓰기
sub writeIsland {
 my($island, $num) = @_;
 my($score);
 $score = int($island->{'score'});
 print OUT $island->{'name'}. ",$score\n";
 print OUT $island->{'id'}. "\n";
 print OUT $island->{'prize'}. "\n";
 print OUT $island->{'absent'}. "\n";
 print OUT $island->{'comment'}. "\n";
 print OUT $island->{'password'}. "\n";
 print OUT $island->{'money'}. "\n";
 print OUT $island->{'food'}. "\n";
 print OUT $island->{'pop'}. "\n";
 print OUT $island->{'area'}. "\n";
 print OUT $island->{'farm'}. "\n";
 print OUT $island->{'factory'}. "\n";
 print OUT $island->{'mountain'}. "\n";
 print OUT $island->{'pts'}. "\n";
 print OUT $island->{'eis1'}. "\n";
 print OUT $island->{'eis2'}. "\n";
 print OUT $island->{'eis3'}. "\n";
 print OUT $island->{'eis4'}. "\n";
 print OUT $island->{'eis5'}. "\n";
 print OUT $island->{'eis6'}. "\n";
 print OUT $island->{'eis7'}. "\n";
 print OUT $island->{'eis8'}. "\n";
 print OUT $island->{'taiji'}. "\n";
 print OUT $island->{'onm'}. "\n";
 print OUT $island->{'monsterlive'}. "\n" if ($HnewGame);
 print OUT $island->{'monsterlivetype'}. "\n" if ($HnewGame);
 print OUT $island->{'eisei1'}. "\n" if ($HnewGame);
 print OUT $island->{'eisei2'}. "\n" if ($HnewGame);
 print OUT $island->{'eisei3'}. "\n" if ($HnewGame);
 print OUT $island->{'eisei4'}. "\n" if ($HnewGame);
 print OUT $island->{'eisei5'}. "\n" if ($HnewGame);
 print OUT $island->{'eisei6'}. "\n" if ($HnewGame);
 print HOUT $island->{'id1'}. "\n";
 print HOUT $island->{'ownername'}. "\n";
 print HOUT $island->{'totoyoso'}. "\n";
 print HOUT $island->{'totoyoso2'}. "\n";
 print HOUT $island->{'kei'}. "\n";
 print HOUT $island->{'rena'}. "\n";
 print HOUT $island->{'momotan'}. "\n";
 print HOUT $island->{'fore'}. "\n";
 print HOUT $island->{'pika'}. "\n";
 print HOUT $island->{'hamu'}. "\n";
 print HOUT $island->{'monta'}. "\n";
 print HOUT $island->{'tare'}. "\n";
 print HOUT $island->{'zipro'}. "\n";
 print HOUT $island->{'leje'}. "\n";
 print POUT $island->{'name'}. "\n";
 print POUT $island->{'ip0'}. "\n";
 print POUT $island->{'ip1'}. "\n";
 print POUT $island->{'ip2'}. "\n";
 print POUT $island->{'ip3'}. "\n";
 print POUT $island->{'ip4'}. "\n";
 print POUT $island->{'ip5'}. "\n";
 print POUT $island->{'ip6'}. "\n";
 print POUT $island->{'ip7'}. "\n";
 print POUT $island->{'ip8'}. "\n";
 print POUT $island->{'ip9'}. "\n";
 print POUT $island->{'etc0'}. "\n";
 print POUT $island->{'etc1'}. "\n";
 print POUT $island->{'etc2'}. "\n";
 print POUT $island->{'etc3'}. "\n";
 print POUT $island->{'etc4'}. "\n";
 print POUT $island->{'etc5'}. "\n";
 print POUT $island->{'etc6'}. "\n";
 print POUT $island->{'etc7'}. "\n";
 print POUT $island->{'etc8'}. "\n";
 print POUT $island->{'etc9'}. "\n";
 print AOUT $island->{'auc0'}. "\n";
 print AOUT $island->{'auc1'}. "\n";
 print AOUT $island->{'auc2'}. "\n";
 print AOUT $island->{'auc3'}. "\n";
 print AOUT $island->{'auc4'}. "\n";
 print AOUT $island->{'auc5'}. "\n";
 print AOUT $island->{'auc6'}. "\n";
 print AOUT $island->{'auc7'}. "\n";
 print AOUT $island->{'auc8'}. "\n";
 print AOUT $island->{'auc9'}. "\n";
 print KOUT $island->{'anflag'}. "\n";

 # 지형
 if(($num <= -1) || ($num == $island->{'id'})) {
	open(IOUT, ">${HdirName}/islandtmp.$island->{'id'}");

	my($land, $landValue);
	$land = $island->{'land'};
	$landValue = $island->{'landValue'};
	my($x, $y);
	for($y = 0; $y < $HislandSize; $y++) {
	 for($x = 0; $x < $HislandSize; $x++) {
		printf IOUT ("%02x%03x", $land->[$x][$y], $landValue->[$x][$y]);
	 }
	 print IOUT "\n";
	}

	# 명령
	my($command, $cur, $i);
	$command = $island->{'command'};
	for($i = 0; $i < $HcommandMax; $i++) {
	 printf IOUT ("%d,%d,%d,%d,%d\n",
			 $command->[$i]->{'kind'},
			 $command->[$i]->{'target'},
			 $command->[$i]->{'x'},
			 $command->[$i]->{'y'},
			 $command->[$i]->{'arg'}
			 );
	}

	# 로컬 게시판
	my($lbbs);
	$lbbs = $island->{'lbbs'};
	for($i = 0; $i < $HlbbsMax; $i++) {
	 print IOUT $lbbs->[$i]. "\n";
	}

	close(IOUT);
	unlink("${HdirName}/island.$island->{'id'}");
	rename("${HdirName}/islandtmp.$island->{'id'}", "${HdirName}/island.$island->{'id'}");
 }
}

#----------------------------------------------------------------------
# 입출력
#----------------------------------------------------------------------

# 표준 출력으로 출력
sub out {
 print STDOUT $_[0];
}

# 디버그 로그
sub HdebugOut {
 open(DOUT, ">>debug.log");
 print DOUT ($_[0]);
 close(DOUT);
}

# CGI 읽기
sub cgiInput {
 my($line, $getLine);

 # 입력을 받아 UTF-8로 처리
 $line = <>;
 $line =~ tr/+/ /;
 $line =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
 $line = $line;
 $line =~ s/[\x00-\x1f\,]//g;

 # GET 값을 받음
 $getLine = $ENV{'QUERY_STRING'};
 # JavaScript 모드
 if($line =~ /JAVAMODE=(cgi|java)/) {
	$HjavaMode = $1;
 } elsif($getLine =~ /JAVAMODE=(cgi|java)/) {
	$HjavaMode = $1;
 } elsif($HjavaModeSet =~ /^(cgi|java)$/) {
	$HjavaMode = $HjavaModeSet;
 }
 if($getLine =~ /IslandMap=([0-9]*)/) {
	$HmainMode = 'islandMap';
	$HcurrentID = $1;
	$defaultTarget = $1;
 }
 if($getLine =~ /view([0-9]+|ALL)/) {
 my($num) = $1;
 if($num eq "ALL") {
	$viewFlag = 'ALL';
	$viewFirst = 0;
	} else {
	$viewFlag = ''; $viewFirst = $num;
	}
 }

 # 대상의 섬
 if($line =~ /CommandJavaButton([0-9]+)=/) {
	# 명령 전송 버튼(JavaScript 모드)
	$HcurrentID = $1;
	$defaultID = $1;
 } elsif($line =~ /CommandButton([0-9]+)=/) {
	# 명령 전송 버튼
	$HcurrentID = $1;
	$defaultID = $1;
 }

 if($line =~ /ISLANDNAME=([^\&]*)\&/){
	# 이름 지정한 경우
	$HcurrentName = cutColumn($1, 20);
 }

if($line =~ /OWNERNAME=([^\&]*)\&/){
 # 소유자 이름의 경우
 $HcurrentOwnerName = cutColumn($1, 20);
}

 if($line =~ /ISLANDID=([0-9]+)\&/){
	# 기타의 경우
	$HcurrentID = $1;
	$defaultID = $1;

 }

 if($line =~ /ISLANDID2=([0-9]+)\&/){
 # 게시판의 발언 섬
 $HspeakerID = $1;
 }
 if($line =~ /LBBSTYPE=([^\&]*)\&/){
 # 게시판의 통신형식
 $HlbbsType = $1;
 }

 if($line =~ /ann=([^\&]*)\&/){
 # 게시판의 통신형식
 $AnnType = $1;
 }

 # 비밀번호
 if($line =~ /OLDPASS=([^\&]*)\&/) {
	$HoldPassword = $1;
	$HdefaultPassword = $1;
 }
 if($line =~ /PASSWORD=([^\&]*)\&/) {
	$HinputPassword = $1;
	$HdefaultPassword = $1;
 }
 if($line =~ /PASSWORD2=([^\&]*)\&/) {
	$HinputPassword2 = $1;
 }

 # 메시지
 if($line =~ /MESSAGE=([^\&]*)\&/) {
	$Hmessage = cutColumn($1, 80);
 }

 # YOSO
 if($line =~ /MESSAGE=([^\&]*)\&/) {
	$HyosoMessage = cutColumn($1, 44);
 }

 # shuto
 if($line =~ /MESSAGE=([^\&]*)\&/) {
	$HshutoMessage = cutColumn($1, 32);
 }

 # 로컬 게시판
 if($line =~ /LBBSNAME=([^\&]*)\&/) {
	$HlbbsName = $1;
	$HdefaultName = $1;
 }
 if($line =~ /LBBSMESSAGE=([^\&]*)\&/) {
	$HlbbsMessage = cutColumn($1, 80);
 }

 # main mode 가져오기
 if($line =~ /TurnButton/) {
	if($Hdebug == 1) {
	 $HmainMode = 'Hdebugturn';
	}
 } elsif($line =~ /ChangeOwnerButton/) {
 $HmainMode = 'chowner';
 } elsif($line =~ /OwnerButton/) {
	$HmainMode = 'owner';
 } elsif($line =~ /AnkeButton/) {
	$HmainMode = 'ankeito';
 } elsif($getLine =~ /Sight=([0-9]*)/) {
	$HmainMode = 'print';
	$HcurrentID = $1;
 } elsif($line =~ /SightButton/) {
 $HmainMode = 'print';
 $line =~ /TARGETID=([^\&]*)\&/;
 $HcurrentID = $1;
 } elsif($line =~ /NewIslandButton/) {
	$HmainMode = 'new';
 } elsif($line =~ /LbbsButton(..)([0-9]*)/) {
	$HmainMode = 'lbbs';
	if($1 eq 'SS') {
	 # 관광객
	 $HlbbsMode = 0;
	} elsif($1 eq 'OW') {
	 # 섬주
	 $HlbbsMode = 1;
	} else {
	 # 삭제
	 $HlbbsMode = 2;
	}
	$HcurrentID = $2;

	# 삭제할 수 없으므로 번호를 가져옴
	$line =~ /NUMBER=([^\&]*)\&/;
	$HcommandPlanNumber = $1;

 } elsif($line =~ /ChangeInfoButton/) {
	$HmainMode = 'change';
 } elsif($line =~ /IPInfoButton/) {
	$HmainMode = 'ipinfo';
 } elsif($line =~ /MessageButton([0-9]*)/) {
	$HmainMode = 'comment';
	$HcurrentID = $1;
 } elsif($line =~ /TotoButton([0-9]*)/) {
	$HmainMode = 'totoyoso';
	$HcurrentID = $1;
 } elsif($line =~ /TotosButton([0-9]*)/) {
	$HmainMode = 'totoyoso2';
 $HcurrentID = $1;
 } elsif($line =~ /ShoueneButton([0-9]*)/) {
	$HmainMode = 'shouene';
 $HcurrentID = $1;
	$line =~ /AMOUNT=([^\&]*)\&/;
	$HcommandArg = $1;
 } elsif($line =~ /BousaiButton([0-9]*)/) {
	$HmainMode = 'bousai';
 $HcurrentID = $1;
	$line =~ /AMOUNT=([^\&]*)\&/;
	$HcommandArg = $1;
 } elsif($line =~ /KankouButton([0-9]*)/) {
	$HmainMode = 'kankou';
 $HcurrentID = $1;
	$line =~ /AMOUNT=([^\&]*)\&/;
	$HcommandArg = $1;
 } elsif($line =~ /SizenButton([0-9]*)/) {
	$HmainMode = 'sizen';
 $HcurrentID = $1;
	$line =~ /AMOUNT=([^\&]*)\&/;
	$HcommandArg = $1;
 } elsif($line =~ /KyouikuButton([0-9]*)/) {
	$HmainMode = 'kyouiku';
 $HcurrentID = $1;
	$line =~ /AMOUNT=([^\&]*)\&/;
	$HcommandArg = $1;
 } elsif($line =~ /ChochikuButton([0-9]*)/) {
	$HmainMode = 'chochiku';
 $HcurrentID = $1;
	$line =~ /AMOUNT=([^\&]*)\&/;
	$HcommandArg = $1;
 } elsif($line =~ /AuctionButton([0-9]*)/) {
	$HmainMode = 'auction';
 $HcurrentID = $1;
	$line =~ /AUCNUMBER=([^\&]*)\&/;
	$HAucNumber = $1;
	$line =~ /AMOUNT=([^\&]*)\&/;
	$HcommandArg = $1;
 } elsif($line =~ /MsButton([0-9]*)/) {
 $HmainMode = 'mskyoka';
	$HcurrentID = $1;
	$line =~ /TARGETID=([^\&]*)\&/;
	$HcommandTarget = $1;
	$defaultTarget = $1;
	$line =~ /AMOUNT=([^\&]*)\&/;
	$HcommandArg = $1;
 } elsif($line =~ /Ms2Button([0-9]*)/) {
 $HmainMode = 'ms2kyoka';
	$HcurrentID = $1;
	$line =~ /TARGETID=([^\&]*)\&/;
	$HcommandTarget = $1;
	$defaultTarget = $1;
	$line =~ /AMOUNT=([^\&]*)\&/;
	$HcommandArg = $1;
 } elsif($line =~ /CommandJavaButton([0-9]+)=/) {
	# JavaScript 모드 일괄 전송
	$HcurrentID = $1;
	$HmainMode = 'commandJava';
	$line =~ /COMARY=([^\&]*)\&/;
	$HcommandComary = $1;
	$line =~ /COMMAND=([^\&]*)\&/;
	$HcommandKind = $1;
	$HdefaultKind = $1;
	$line =~ /AMOUNT=([^\&]*)\&/;
	$HcommandArg = $1;
	$line =~ /TARGETID=([^\&]*)\&/;
	$HcommandTarget = $1;
	$defaultTarget = $1;
	$line =~ /POINTX=([^\&]*)\&/;
	$HcommandX = $1;
	$HdefaultX = $1;
	$line =~ /POINTY=([^\&]*)\&/;
	$HcommandY = $1;
	$HdefaultY = $1;
	if($line =~ /MENUOPEN=on/) {
		$HmenuOpen = 'CHECKED';
	} elsif($line =~ /MENUOPEN2=on/) {
		$HmenuOpen2 = 'CHECKED';
	}
 } elsif($line =~ /CommandButton/) {
	$HmainMode = 'command';

	# 명령 모드의 경우, 명령의 가져오기
	$line =~ /NUMBER=([^\&]*)\&/;
	$HcommandPlanNumber = $1;
	$line =~ /COMMAND=([^\&]*)\&/;
	$HcommandKind = $1;
	$HdefaultKind = $1;
	$line =~ /AMOUNT=([^\&]*)\&/;
	$HcommandArg = $1;
	$line =~ /TARGETID=([^\&]*)\&/;
	$HcommandTarget = $1;
	$defaultTarget = $1;
	$line =~ /POINTX=([^\&]*)\&/;
	$HcommandX = $1;
	$HdefaultX = $1;
 $line =~ /POINTY=([^\&]*)\&/;
	$HcommandY = $1;
	$HdefaultY = $1;
	$line =~ /COMMANDMODE=(write|insert|delete)/;
	$HcommandMode = $1;

	$line =~ /LAMOUNT1=([^\&]*)\&/;
	$lamount1 = $1;
	$HdefaultLamount1 = $1;
	 if($line =~ /LAMOUNT2=([^\&]*)\&/) {
		$lamount2 = cutColumn($1, 40);
	 }

 } else {
	$HmainMode = 'top';
 }


 if($line =~ /IMGLINEMAC=([^&]*)\&/){
 my($flag) = 'file:///'. $1;
 $HimgLine = $flag;
 }

 if($line =~ /IMGLINE=([^&]*)\&/){
 my($flag) = substr($1, 0, -10);
 $flag =~ tr/\\/\//;
 if($flag eq 'del'){ $flag = $imageDir; } else { $flag = 'file:///'. $flag; }
 $HimgLine = $flag;
 }


}

#cookie 입력
sub cookieInput {
 my($cookie);

 $cookie = $ENV{'HTTP_COOKIE'};

 if($cookie =~ /${HthisFile}OWNISLANDID=\(([^\)]*)\)/) {
	$defaultID = $1;
 }
 if($cookie =~ /${HthisFile}OWNISLANDPASSWORD=\(([^\)]*)\)/) {
	$HdefaultPassword = $1;
 }
 if($cookie =~ /${HthisFile}TARGETISLANDID=\(([^\)]*)\)/) {
	$defaultTarget = $1;
 }
 if($cookie =~ /${HthisFile}LBBSNAME=\(([^\)]*)\)/) {
	$HdefaultName = $1;
 }
 if($cookie =~ /${HthisFile}POINTX=\(([^\)]*)\)/) {
	$HdefaultX = $1;
 }
 if($cookie =~ /${HthisFile}POINTY=\(([^\)]*)\)/) {
	$HdefaultY = $1;
 }
 if($cookie =~ /${HthisFile}KIND=\(([^\)]*)\)/) {
	$HdefaultKind = $1;
 }
 if($cookie =~ /${HthisFile}JAVAMODESET=\(([^\)]*)\)/) {
	$HjavaModeSet = $1;
	$HjavaMode = $1 if($1 =~ /^(cgi|java)$/);
 }
 if($cookie =~ /${HthisFile}LAMOUNT1=\(([^\)]*)\)/) {
	$HdefaultLamount1 = $1;
 }

 if($cookie =~ /${HthisFile}IMGLINE=\(([^\)]*)\)/) {
 $HimgLine = $1;
 }

}

#cookie 출력
sub cookieOutput {
 my($cookie, $info);

 # 삭제 가능 기한 설정
 my($sec, $min, $hour, $date, $mon, $year, $day, $yday, $dummy) =
	gmtime(time + 30 * 86400); # 현재 + 30일

 # 2자리화
 $year += 1900;
 if ($date < 10) { $date = "0$date"; }
 if ($hour < 10) { $hour = "0$hour"; }
 if ($min < 10) { $min = "0$min"; }
 if ($sec < 10) { $sec = "0$sec"; }

 # 요일일을 문자에
 $day = ("Sunday", "Monday", "Tuesday", "Wednesday",
	 "Thursday", "Friday", "Saturday")[$day];

 # 월을 문자에
 $mon = ("Jan", "Feb", "Mar", "Apr", "May", "Jun",
	 "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")[$mon];

 # 경로와 기간 설정
 $info = "; expires=$day, $date\-$mon\-$year $hour:$min:$sec GMT\n";
 $cookie = '';

 if(($HcurrentID) && ($HmainMode eq 'owner')){
	$cookie.= "Set-Cookie: ${HthisFile}OWNISLANDID=($HcurrentID) $info";
 }
 if($HinputPassword) {
	$cookie.= "Set-Cookie: ${HthisFile}OWNISLANDPASSWORD=($HinputPassword) $info";
 }
 if($HcommandTarget) {
	$cookie.= "Set-Cookie: ${HthisFile}TARGETISLANDID=($HcommandTarget) $info";
 }
 if($HlbbsName) {
	$cookie.= "Set-Cookie: ${HthisFile}LBBSNAME=($HlbbsName) $info";
 }
 if($HcommandX) {
	$cookie.= "Set-Cookie: ${HthisFile}POINTX=($HcommandX) $info";
 }
 if($HcommandY) {
	$cookie.= "Set-Cookie: ${HthisFile}POINTY=($HcommandY) $info";
 }
 if($HcommandKind) {
	# 자동 입력 이외
	$cookie.= "Set-Cookie: ${HthisFile}KIND=($HcommandKind) $info";
 }
 if($lamount1) {
	$cookie.= "Set-Cookie: ${HthisFile}LAMOUNT1=($lamount1) $info";
 }

 if($HimgLine) {
 $cookie.= "Set-Cookie: ${HthisFile}IMGLINE=($HimgLine) $info";
 }
 if($HjavaMode) {
	$cookie.= "Set-Cookie: ${HthisFile}JAVAMODESET=($HjavaMode) $info";
 }

 out($cookie);
}

#----------------------------------------------------------------------
# 유티리티
#----------------------------------------------------------------------
sub hakolock {
 if($lockMode == 1) {
	# directory 방식 잠금
	return hakolock1();

 } elsif($lockMode == 2) {
	# flock 방식 잠금
	return hakolock2();
 } elsif($lockMode == 3) {
	# symlink 방식 잠금
	return hakolock3();
 } else {
	# 일반 파일 방식 잠금
	return hakolock4();
 }
}

sub hakolock1 {
 # 잠금을 시도
 if(mkdir('hakojimalock', $HdirMode)) {
	# 성공
	return 1;
 } else {
	# 실패
	my($b) = (stat('hakojimalock'))[9];
	if(($b> 0) && ((time() - $b)> $unlockTime)) {
	 # 강제 해제
	 unlock();

	 # 헤더출력
	 tempHeader();

	 # 강제 해제 메시지
	 tempUnlock();

	 # 푸터출력
	 tempFooter();

	 # 종료
	 exit(0);
	}
	return 0;
 }
}

sub hakolock2 {
 open(LOCKID, '>>hakojimalockflock');
 if(flock(LOCKID, 2)) {
	# 성공
	return 1;
 } else {
	# 실패
	return 0;
 }
}

sub hakolock3 {
 # 잠금을 시도
 if(symlink('hakojimalockdummy', 'hakojimalock')) {
	# 성공
	return 1;
 } else {
	# 실패
	my($b) = (lstat('hakojimalock'))[9];
	if(($b> 0) && ((time() - $b)> $unlockTime)) {
	 # 강제 해제
	 unlock();

	 # 헤더출력
	 tempHeader();

	 # 강제 해제 메시지
	 tempUnlock();

	 # 푸터출력
	 tempFooter();

	 # 종료
	 exit(0);
	}
	return 0;
 }
}

sub hakolock4 {
 # 잠금을 시도
 if(unlink('key-free')) {
	# 성공
	open(OUT, '>key-locked');
	print OUT time;
	close(OUT);
	return 1;
 } else {
	# 잠금 시간 확인
	if(!open(IN, 'key-locked')) {
	 return 0;
	}

	my($t);
	$t = <IN>;
	close(IN);
	if(($t != 0) && (($t + $unlockTime) < time)) {
	 # 120초 이상 경과하면 강제로 잠금을 해제
	 unlock();

	 # 헤더출력
	 tempHeader();

	 # 강제 해제 메시지
	 tempUnlock();

	 # 푸터출력
	 tempFooter();

	 # 종료
	 exit(0);
	}
	return 0;
 }
}

# 잠금을 해제
sub unlock {
 if($lockMode == 1) {
	# directory 방식 잠금
	rmdir('hakojimalock');

 } elsif($lockMode == 2) {
	# flock 방식 잠금
	close(LOCKID);

 } elsif($lockMode == 3) {
	# symlink 방식 잠금
	unlink('hakojimalock');
 } else {
	# 일반 파일 방식 잠금
	my($i);
	$i = rename('key-locked', 'key-free');
 }
}

# 작은 쪽을 반환
sub min {
 return ($_[0] < $_[1]) ? $_[0] : $_[1];
}

# 비밀번호엔코드
sub encode {
 if($cryptOn == 1) {
	return crypt($_[0], 'h2');
 } else {
	return $_[0];
 }
}

# 비밀번호 확인
sub checkPassword {
 my($p1, $p2) = @_;

 # null 확인
 if($p2 eq '') {
	return 0;
 }

 # 마스터 비밀번호 확인
 if($masterPassword eq $p2) {
	return 1;
 }

 # 본래의 확인
 if($p1 eq encode($p2)) {
	return 1;
 }

 return 0;
}

# 1000억단위원형메루틴
sub aboutMoney {
 my($m) = @_;
 if($m < 500) {
	return "추정500${HunitMoney}미만";
 } else {
	$m = int(($m + 500) / 1000);
	return "추정${m}000${HunitMoney}";
 }
}

# 이스케이프문자의 처리
sub htmlEscape {
 my($s) = @_;
 $s =~ s/&/&amp;/g;
 $s =~ s/</&lt;/g;
 $s =~ s/>/&gt;/g;
 $s =~ s/\"/&quot;/g; #"
 return $s;
}

# 80자리에절리갖춤에
sub cutColumn {
 my($s, $c) = @_;
 if(length($s) <= $c) {
	return $s;
 } else {
	# 합계80자리가 됨까지절리 처리
	my($ss) = '';
	my($count) = 0;
	while($count < $c) {
	 $s =~ s/(^[\x80-\xFF][\x80-\xFF])|(^[\x00-\x7F])//;
	 if($1) {
		$ss.= $1;
		$count ++;
	 } else {
		$ss.= $2;
	 }
	 $count ++;
	}
	return $ss;
 }
}

# 섬 이름으로 번호를 얻음(ID 가 아니라 번호)
sub nameToNumber {
 my($name) = @_;

 # 전체 섬에서 찾기
 my($i);
 for($i = 0; $i < $HislandNumber; $i++) {
	if($Hislands[$i]->{'name'} eq $name) {
	 return $i;
	}
 }

 # 찾을 수 없었던 경우
 return -1;
}

sub ipToNumber {
 my($ip0) = @_;

 # 전체 섬에서 찾기
 my($i);
 for($i = 0; $i < $HislandNumber; $i++) {
	if($Hislands[$i]->{'ip0'} eq $ip0) {
	 return $i;
	}
 }

 my($ip1) = @_;

 # 전체 섬에서 찾기
 my($i);
 for($i = 0; $i < $HislandNumber; $i++) {
	if($Hislands[$i]->{'ip1'} eq $ip1) {
	 return $i;
	}
 }

 my($ip2) = @_;

 # 전체 섬에서 찾기
 my($i);
 for($i = 0; $i < $HislandNumber; $i++) {
	if($Hislands[$i]->{'ip2'} eq $ip2) {
	 return $i;
	}
 }

 my($ip3) = @_;

 # 전체 섬에서 찾기
 my($i);
 for($i = 0; $i < $HislandNumber; $i++) {
	if($Hislands[$i]->{'ip3'} eq $ip3) {
	 return $i;
	}
 }

 my($ip4) = @_;

 # 전체 섬에서 찾기
 my($i);
 for($i = 0; $i < $HislandNumber; $i++) {
	if($Hislands[$i]->{'ip4'} eq $ip4) {
	 return $i;
	}
 }

 my($ip5) = @_;

 # 전체 섬에서 찾기
 my($i);
 for($i = 0; $i < $HislandNumber; $i++) {
	if($Hislands[$i]->{'ip5'} eq $ip5) {
	 return $i;
	}
 }

 # 찾을 수 없었던 경우
 return -1;
}

# 괴수의 정보
sub monsterSpec {
 my($lv) = @_;

 # 종류
 my($kind) = ($lv>> 4) & 31;

 # 이름
 my($name);
 $name = $HmonsterName[$kind];

 # 체력
 my($hp) = ($lv & 15);

 return ($kind, $name, $hp);
}

# 경험치에서 레벨을 산출
sub expToLevel {
 my($kind, $exp) = @_;
 my($i);
 if($kind == $HlandBase) {
	# 미사일 기지
	for($i = $maxBaseLevel; $i> 1; $i--) {
	 if($exp>= $baseLevelUp[$i - 2]) {
		return $i;
	 }
	}
	return 1;
 } else {
	# 해저 기지
	for($i = $maxSBaseLevel; $i> 1; $i--) {
	 if($exp>= $sBaseLevelUp[$i - 2]) {
		return $i;
	 }
	}
	return 1;
 }

}

# (0,0)에서(size - 1, size - 1)까지의 숫자가한 번씩 나오도록
# (@Hrpx, @Hrpy)을 설정
sub makeRandomPointArray {
 # 초기 값
 my($y);
 @Hrpx = (0..$HislandSize-1) x $HislandSize;
 for($y = 0; $y < $HislandSize; $y++) {
	push(@Hrpy, ($y) x $HislandSize);
 }

 # 셔터 전체
 my ($i);
 for ($i = $HpointNumber; --$i; ) {
	my($j) = int(rand($i+1));
	if($i == $j) { next; }
	@Hrpx[$i,$j] = @Hrpx[$j,$i];
	@Hrpy[$i,$j] = @Hrpy[$j,$i];
 }
}

# 0에서(n - 1)의 난수
sub random {
 return int(rand(1) * $_[0]);
}

# 부여한 숫자값에 대응하는 의사 난수(0에서9의 정수만)
sub seqnum {
 my($v) = sin($_[0] + 1234); # 1234은 임의 정수, 난수의 계열을 변경 가능
 return (substr($v, -2, 1));
}

#----------------------------------------------------------------------
# 로그 표시
#----------------------------------------------------------------------
# 파일 번호를 지정해 로그 표시
sub logFilePrint {
 my($fileNumber, $id, $mode) = @_;
 open(LIN, "${HdirName}/hakojima.log$_[0]");
 my($line, $m, $turn, $id1, $id2, $message);
 while($line = <LIN>) {
	$line =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),(.*)$/;
	($m, $turn, $id1, $id2, $message) = ($1, $2, $3, $4, $5);

	# 기밀관계
	if($m == 1) {
	 if(($mode == 0) || ($id1 != $id)) {
		# 기밀 표시 권한 없음
		next;
	 }
	 $m = '<B>(기밀)</B>';
	} else {
	 $m = '';
	}

	# 정확히 표시할지
	if($id != 0) {
	 if(($id != $id1) &&
	 ($id != $id2)) {
		next;
	 }
	}

	# 표시
	out("<NOBR>${HtagNumber_}턴$turn$m${H_tagNumber}:$message</NOBR><BR>\n");
 }
 close(LIN);
}

#----------------------------------------------------------------------
# 템플릿
#----------------------------------------------------------------------
# 초기화
sub tempInitialize {
 # 섬 선택(기본값: 자기 섬)
 $HislandList = getIslandList($defaultID);
 $HtargetList = getIslandList($defaultID);
}

# 섬 데이터 드롭다운 메뉴용
sub getIslandList {
 my($select) = @_;
 my($list, $name, $id, $s, $i);

 #섬 목록의 메뉴
 $list = '';
 for($i = 0; $i < $HislandNumber; $i++) {
	$name = $Hislands[$i]->{'name'};
	$id = $Hislands[$i]->{'id'};
	if($id eq $select) {
	 $s = 'SELECTED';
	} else {
	 $s = '';
	}
	$list.=
	 "<OPTION VALUE=\"$id\" $s>${name} 섬\n";
 }
 return $list;
}


# 헤더
sub tempHeader {

$HislandNextTurn = $HislandTurn + 1;

$baseIMG = $imageDir;

 out(<<END);
Content-type: text/html; charset=UTF-8

<HTML>
<HEAD><META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
<TITLE>
$Htitle
</TITLE>
<BASE HREF="$baseIMG/">

<STYLE type="text/css">
<!--

	A:link.type1 { color:#0000FF; text-decoration: none; }

	A:visited.type1 { color:#800080; text-decoration: none; }

	A:hover.type1, A:focus.type1 { color:#0000FF; text-decoration: underline; }

	A:action.type1 { color:#FF0000; text-decoration: underline; }



	A:link.type2 { color:#0000FF; text-decoration: underline; }

	A:visited.type2 { color:#800080; text-decoration: underline; }

	A:hover.type2, A:focus.type2 { color:#FF00FF; text-decoration: underline; }

	A:action.type2 { color:#FF0000; text-decoration: underline; }



	A:link.type3 { color:#0000FF; text-decoration: none; }

	A:visited.type3 { color:#800080; text-decoration: none; }

	A:hover.type3, A:focus.type3 { background-color: pink; color: #FFFFFF; text-decoration: none; }

	A:action.type3 { color:#FF0000; text-decoration: none; }


	/* 관광 화면내비게이터·창 */
	#NaviView{
	 visibility: hidden;
	 z-index:1;
	 position:absolute;
	 background-color: #000000;
	 border: solid #4169E1;
	 border-width: 10px 1px 1px 1px;
	 margin-top : -224px;
	}
	.NaviTitle {
	 color: #ffffff;
	 font-size: 11pt;
	}
	.NaviImg {
	 margin : 1px;
	}
	.NaviText {
	 color: #ffffff;
	 font-size: 9pt;
	}
	TD.M {
	 cursor:default;
	 border-style:outset;
	 border-width:0px;
	 border-color:#CCCCFF;
	}

	body{ scrollbar-3dlight-color:royalblue;
	scrollbar-arrow-color:royalblue;
	scrollbar-darkshadow-color:lemonchiffon;
	scrollbar-face-color:lemonchiffon;
	scrollbar-highlight-color:lemonchiffon;
	scrollbar-shadow-color:royalblue;
	scrollbar-track-color:lemonchiffon;

-->

</STYLE>

</HEAD>
<BODY $htmlBody>
[<A CLASS="type3" HREF="http://t.pos.to/hako/" target="_blank">하코니와 제도 스크립트 배포처</A>] [<A CLASS="type3" HREF="http://www5b.biglobe.ne.jp/~k-e-i/" target="_blank">Hakoniwa R.A. 스크립트 배포처</A>] [<A CLASS="type3" HREF="$toppage">톱 페이지</A>]<HR>

<hr WIDTH="100%">
END

}

# 푸터
sub tempFooter {
 my($uti, $sti, $cuti, $csti) = times();
 $uti += $cuti;
 $sti += $csti;
 my($cpu) = $uti + $sti;
 out(<<END);
<HR>
<P align=center>
관리자:$adminName(<A CLASS="type3" HREF="mailto:$email">$email</A>)<BR>
게시판(<A CLASS="type3" HREF="$bbs">$bbs</A>)<BR>
톱 페이지(<A CLASS="type3" HREF="$toppage">$toppage</A>)<BR>
하코니와 제도의 페이지(<A CLASS="type3" HREF="http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html">http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html</A>)<BR>
Hakoniwa R.A. 의페이지(<A CLASS="type3" HREF="http://www5b.biglobe.ne.jp/~k-e-i/">http://www5b.biglobe.ne.jp/~k-e-i/</A>)
<br>

</P>
<DIV align="right">
<SMALL>CPU($cpu) : user($uti) system($sti)</SMALL>
</DIV>
</BODY>
</HTML>
END
}

# 잠금실패
sub tempLockFail {
 # 제목
 out(<<END);
${HtagBig_}동시접속오류입니다.<BR>
브라우저의'돌아가기'버튼을 누름시,<BR>
잠시 기다렸다가 다시오시 도시하세요.${H_tagBig}$HtempBack
END
}

# 강제 해제
sub tempUnlock {
 # 제목
 out(<<END);
${HtagBig_}지난 접속이 비정상 종료된 것 같습니다.<BR>
잠금을 강제 해제했습니다.${H_tagBig}$HtempBack
END
}

# hakojima.dat 이 없음
sub tempNoDataFile {
 out(<<END);
${HtagBig_}데이터 파일을 열 수 없습니다.${H_tagBig}$HtempBack
END
}

# 비밀번호오류
sub tempWrongPassword {
 out(<<END);
${HtagBig_} 비밀번호가 다릅니다.${H_tagBig}$HtempBack
END
}

# 무언가문제발생
sub tempProblem {
 out(<<END);
${HtagBig_}문제발생, 일단복귀해 주세요.${H_tagBig}$HtempBack
END
}

sub get_host {
	$host = "";
	$addr = "";
	if($Hlipdisp) {
		$host = $ENV{'REMOTE_HOST'};
		$addr = $ENV{'REMOTE_ADDR'};

		if ($get_remotehost) {
			if ($host eq "" || $host eq "$addr") {
				$host = gethostbyaddr(pack("C4", split(/\./, $addr)), 2);
			}
		}
		if ($host eq "") { $host = $addr; }

		$addr = "(${addr})";
	}
}
