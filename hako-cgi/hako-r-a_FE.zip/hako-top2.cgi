#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}
#----------------------------------------------------------------------
# 하코니와 제도 ver2.30
# 톱 페이지 모듈(ver1.00)
# 사용 조건, 사용 방법 등은,hako-readme.txt 파일을 참조
#
# 하코니와 제도의 페이지: http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html
#----------------------------------------------------------------------
#----------------------------------------------------------------------
# Hakoniwa R.A. Final Edition
# 메인스크립트(하코니와 제도 ver2.30)
# 사용 조건, 사용 방법 등은,read-renas.txt 파일을 참조
#
# IP 확인용의 개조판. 정보 변경 항목에 마스터 비밀번호를 입력하면
# 얼굴 아이콘을 클릭하면 하위 순위를 볼 수 있습니다.
#
# KEI PAGE: http://www5b.biglobe.ne.jp/~k-e-i/
#----------------------------------------------------------------------

#----------------------------------------------------------------------
# 톱 페이지 모드
#----------------------------------------------------------------------
# 메인
sub topPageMain {
 # 개방
 unlock();

 # 템플릿출력
 tempTopPage();
}

# 톱 페이지
sub tempTopPage {
 # 제목
 out(<<END);
${HtagTitle_}$Htitle${H_tagTitle}(하위 순위)
END

 # 디버그 모드이면 '턴 진행' 버튼
 if($Hdebug == 1) {
 out(<<END);
<FORM action="$HthisFile" method="POST">
<INPUT TYPE="submit" VALUE="턴을 진행하기" NAME="TurnButton">
</FORM>
END
 }

 my($mStr1) = '';
 if($HhideMoneyMode != 0) {
	$mStr1 = "<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_} 자금${H_tagTH}</NOBR></TH>";
 }

 # 양식
 out(<<END);
<H1>${HtagHeader_}턴$HislandTurn${H_tagHeader}</H1>

<HR>
<H1>${HtagHeader_}자신의 섬으로${H_tagHeader}</H1>
<FORM action="$HthisFile" method="POST">
당신의 섬 이름은?<BR>
<SELECT NAME="ISLANDID">
$HislandList
</SELECT><BR>

비밀번호를 이용하세요!!<BR>
<INPUT TYPE="password" NAME="PASSWORD" VALUE="$HdefaultPassword" SIZE=32 MAXLENGTH=32><BR>
<INPUT TYPE="submit" VALUE="개발 화면으로" NAME="OwnerButton"><BR>
</FORM>
END
 my($island, $j, $farm, $factory, $mountain, $name, $id, $prize, $ii);
 for($ii = 0; $ii < $HislandNumber; $ii++) {
	$j = $ii + 1;
	$island = $Hislands[$ii];

	$id = $island->{'id'};

	if($island->{'absent'} == 0) {
		$name = "${HtagName_}$island->{'name'} 섬${H_tagName}";
	} else {
	 $name = "${HtagName2_}$island->{'name'} 섬($island->{'absent'})${H_tagName2}";
	}

	$ip0 = $island->{'ip0'};
	$ip1 = $island->{'ip1'};
	$ip2 = $island->{'ip2'};
	$ip3 = $island->{'ip3'};
	$ip4 = $island->{'ip4'};
	$ip5 = $island->{'ip5'};
	$ip6 = $island->{'ip6'};
	$ip7 = $island->{'ip7'};
	$ip8 = $island->{'ip8'};
	$ip9 = $island->{'ip9'};

	$island->{'ippts'} = 0;


	 my($ip0) = @_;
	 # 전체 섬에서 찾기
	 my($i);
	 for($i = 0; $i < $HislandNumber; $i++) {
		if($Hislands[$i]->{'ip0'} eq $island->{'ip0'}) {
		if($Hislands[$i]->{'id'} != $island->{'id'}) {
		 $island->{'ippts'}++;
		 $island->{'ipkaburi'}.= "$Hislands[$i]->{'name'} 섬(ID:$Hislands[$i]->{'id'})/";
		}
		}
	 }
	 my($ip1) = @_;
	 # 전체 섬에서 찾기
	 my($i);
	 for($i = 0; $i < $HislandNumber; $i++) {
		if($Hislands[$i]->{'ip1'} eq $island->{'ip0'}) {
		if($Hislands[$i]->{'id'} != $island->{'id'}) {
		 $island->{'ippts'}++;
		 $island->{'ipkaburi'}.= "$Hislands[$i]->{'name'} 섬(ID:$Hislands[$i]->{'id'})/";
		}
		}
	 }
	 my($ip2) = @_;
	 # 전체 섬에서 찾기
	 my($i);
	 for($i = 0; $i < $HislandNumber; $i++) {
		if($Hislands[$i]->{'ip2'} eq $island->{'ip0'}) {
		if($Hislands[$i]->{'id'} != $island->{'id'}) {
		 $island->{'ippts'}++;
		 $island->{'ipkaburi'}.= "$Hislands[$i]->{'name'} 섬(ID:$Hislands[$i]->{'id'})/";
		}
		}
	 }
	 my($ip3) = @_;
	 # 전체 섬에서 찾기
	 my($i);
	 for($i = 0; $i < $HislandNumber; $i++) {
		if($Hislands[$i]->{'ip3'} eq $island->{'ip0'}) {
		if($Hislands[$i]->{'id'} != $island->{'id'}) {
		 $island->{'ippts'}++;
		 $island->{'ipkaburi'}.= "$Hislands[$i]->{'name'} 섬(ID:$Hislands[$i]->{'id'})/";
		}
		}
	 }
	 my($ip4) = @_;
	 # 전체 섬에서 찾기
	 my($i);
	 for($i = 0; $i < $HislandNumber; $i++) {
		if($Hislands[$i]->{'ip4'} eq $island->{'ip0'}) {
		if($Hislands[$i]->{'id'} != $island->{'id'}) {
		 $island->{'ippts'}++;
		 $island->{'ipkaburi'}.= "$Hislands[$i]->{'name'} 섬(ID:$Hislands[$i]->{'id'})/";
		}
		}
	 }
	 my($ip5) = @_;
	 # 전체 섬에서 찾기
	 my($i);
	 for($i = 0; $i < $HislandNumber; $i++) {
		if($Hislands[$i]->{'ip5'} eq $island->{'ip0'}) {
		if($Hislands[$i]->{'id'} != $island->{'id'}) {
		 $island->{'ippts'}++;
		 $island->{'ipkaburi'}.= "$Hislands[$i]->{'name'} 섬(ID:$Hislands[$i]->{'id'})/";
		}
		}
	 }


	 my($ip0) = @_;
	 # 전체 섬에서 찾기
	 my($i);
	 for($i = 0; $i < $HislandNumber; $i++) {
		if($Hislands[$i]->{'ip0'} eq $island->{'ip1'}) {
		if($Hislands[$i]->{'id'} != $island->{'id'}) {
		 $island->{'ippts'}++;
		 $island->{'ipkaburi'}.= "$Hislands[$i]->{'name'} 섬(ID:$Hislands[$i]->{'id'})/";
		}
		}
	 }
	 my($ip1) = @_;
	 # 전체 섬에서 찾기
	 my($i);
	 for($i = 0; $i < $HislandNumber; $i++) {
		if($Hislands[$i]->{'ip1'} eq $island->{'ip1'}) {
		if($Hislands[$i]->{'id'} != $island->{'id'}) {
		 $island->{'ippts'}++;
		 $island->{'ipkaburi'}.= "$Hislands[$i]->{'name'} 섬(ID:$Hislands[$i]->{'id'})/";
		}
		}
	 }
	 my($ip2) = @_;
	 # 전체 섬에서 찾기
	 my($i);
	 for($i = 0; $i < $HislandNumber; $i++) {
		if($Hislands[$i]->{'ip2'} eq $island->{'ip1'}) {
		if($Hislands[$i]->{'id'} != $island->{'id'}) {
		 $island->{'ippts'}++;
		 $island->{'ipkaburi'}.= "$Hislands[$i]->{'name'} 섬(ID:$Hislands[$i]->{'id'})/";
		}
		}
	 }
	 my($ip3) = @_;
	 # 전체 섬에서 찾기
	 my($i);
	 for($i = 0; $i < $HislandNumber; $i++) {
		if($Hislands[$i]->{'ip3'} eq $island->{'ip1'}) {
		if($Hislands[$i]->{'id'} != $island->{'id'}) {
		 $island->{'ippts'}++;
		 $island->{'ipkaburi'}.= "$Hislands[$i]->{'name'} 섬(ID:$Hislands[$i]->{'id'})/";
		}
		}
	 }
	 my($ip4) = @_;
	 # 전체 섬에서 찾기
	 my($i);
	 for($i = 0; $i < $HislandNumber; $i++) {
		if($Hislands[$i]->{'ip4'} eq $island->{'ip1'}) {
		if($Hislands[$i]->{'id'} != $island->{'id'}) {
		 $island->{'ippts'}++;
		 $island->{'ipkaburi'}.= "$Hislands[$i]->{'name'} 섬(ID:$Hislands[$i]->{'id'})/";
		}
		}
	 }
	 my($ip5) = @_;
	 # 전체 섬에서 찾기
	 my($i);
	 for($i = 0; $i < $HislandNumber; $i++) {
		if($Hislands[$i]->{'ip5'} eq $island->{'ip1'}) {
		if($Hislands[$i]->{'id'} != $island->{'id'}) {
		 $island->{'ippts'}++;
		 $island->{'ipkaburi'}.= "$Hislands[$i]->{'name'} 섬(ID:$Hislands[$i]->{'id'})/";
		}
		}
	 }


	 my($ip0) = @_;
	 # 전체 섬에서 찾기
	 my($i);
	 for($i = 0; $i < $HislandNumber; $i++) {
		if($Hislands[$i]->{'ip0'} eq $island->{'ip2'}) {
		if($Hislands[$i]->{'id'} != $island->{'id'}) {
		 $island->{'ippts'}++;
		 $island->{'ipkaburi'}.= "$Hislands[$i]->{'name'} 섬(ID:$Hislands[$i]->{'id'})/";
		}
		}
	 }
	 my($ip1) = @_;
	 # 전체 섬에서 찾기
	 my($i);
	 for($i = 0; $i < $HislandNumber; $i++) {
		if($Hislands[$i]->{'ip1'} eq $island->{'ip2'}) {
		if($Hislands[$i]->{'id'} != $island->{'id'}) {
		 $island->{'ippts'}++;
		 $island->{'ipkaburi'}.= "$Hislands[$i]->{'name'} 섬(ID:$Hislands[$i]->{'id'})/";
		}
		}
	 }
	 my($ip2) = @_;
	 # 전체 섬에서 찾기
	 my($i);
	 for($i = 0; $i < $HislandNumber; $i++) {
		if($Hislands[$i]->{'ip2'} eq $island->{'ip2'}) {
		if($Hislands[$i]->{'id'} != $island->{'id'}) {
		 $island->{'ippts'}++;
		 $island->{'ipkaburi'}.= "$Hislands[$i]->{'name'} 섬(ID:$Hislands[$i]->{'id'})/";
		}
		}
	 }
	 my($ip3) = @_;
	 # 전체 섬에서 찾기
	 my($i);
	 for($i = 0; $i < $HislandNumber; $i++) {
		if($Hislands[$i]->{'ip3'} eq $island->{'ip2'}) {
		if($Hislands[$i]->{'id'} != $island->{'id'}) {
		 $island->{'ippts'}++;
		 $island->{'ipkaburi'}.= "$Hislands[$i]->{'name'} 섬(ID:$Hislands[$i]->{'id'})/";
		}
		}
	 }
	 my($ip4) = @_;
	 # 전체 섬에서 찾기
	 my($i);
	 for($i = 0; $i < $HislandNumber; $i++) {
		if($Hislands[$i]->{'ip4'} eq $island->{'ip2'}) {
		if($Hislands[$i]->{'id'} != $island->{'id'}) {
		 $island->{'ippts'}++;
		 $island->{'ipkaburi'}.= "$Hislands[$i]->{'name'} 섬(ID:$Hislands[$i]->{'id'})/";
		}
		}
	 }
	 my($ip5) = @_;
	 # 전체 섬에서 찾기
	 my($i);
	 for($i = 0; $i < $HislandNumber; $i++) {
		if($Hislands[$i]->{'ip5'} eq $island->{'ip2'}) {
		if($Hislands[$i]->{'id'} != $island->{'id'}) {
		 $island->{'ippts'}++;
		 $island->{'ipkaburi'}.= "$Hislands[$i]->{'name'} 섬(ID:$Hislands[$i]->{'id'})/";
		}
		}
	 }


	 my($ip0) = @_;
	 # 전체 섬에서 찾기
	 my($i);
	 for($i = 0; $i < $HislandNumber; $i++) {
		if($Hislands[$i]->{'ip0'} eq $island->{'ip3'}) {
		if($Hislands[$i]->{'id'} != $island->{'id'}) {
		 $island->{'ippts'}++;
		 $island->{'ipkaburi'}.= "$Hislands[$i]->{'name'} 섬(ID:$Hislands[$i]->{'id'})/";
		}
		}
	 }
	 my($ip1) = @_;
	 # 전체 섬에서 찾기
	 my($i);
	 for($i = 0; $i < $HislandNumber; $i++) {
		if($Hislands[$i]->{'ip1'} eq $island->{'ip3'}) {
		if($Hislands[$i]->{'id'} != $island->{'id'}) {
		 $island->{'ippts'}++;
		 $island->{'ipkaburi'}.= "$Hislands[$i]->{'name'} 섬(ID:$Hislands[$i]->{'id'})/";
		}
		}
	 }
	 my($ip2) = @_;
	 # 전체 섬에서 찾기
	 my($i);
	 for($i = 0; $i < $HislandNumber; $i++) {
		if($Hislands[$i]->{'ip2'} eq $island->{'ip3'}) {
		if($Hislands[$i]->{'id'} != $island->{'id'}) {
		 $island->{'ippts'}++;
		 $island->{'ipkaburi'}.= "$Hislands[$i]->{'name'} 섬(ID:$Hislands[$i]->{'id'})/";
		}
		}
	 }
	 my($ip3) = @_;
	 # 전체 섬에서 찾기
	 my($i);
	 for($i = 0; $i < $HislandNumber; $i++) {
		if($Hislands[$i]->{'ip3'} eq $island->{'ip3'}) {
		if($Hislands[$i]->{'id'} != $island->{'id'}) {
		 $island->{'ippts'}++;
		 $island->{'ipkaburi'}.= "$Hislands[$i]->{'name'} 섬(ID:$Hislands[$i]->{'id'})/";
		}
		}
	 }
	 my($ip4) = @_;
	 # 전체 섬에서 찾기
	 my($i);
	 for($i = 0; $i < $HislandNumber; $i++) {
		if($Hislands[$i]->{'ip4'} eq $island->{'ip3'}) {
		if($Hislands[$i]->{'id'} != $island->{'id'}) {
		 $island->{'ippts'}++;
		 $island->{'ipkaburi'}.= "$Hislands[$i]->{'name'} 섬(ID:$Hislands[$i]->{'id'})/";
		}
		}
	 }
	 my($ip5) = @_;
	 # 전체 섬에서 찾기
	 my($i);
	 for($i = 0; $i < $HislandNumber; $i++) {
		if($Hislands[$i]->{'ip5'} eq $island->{'ip3'}) {
		if($Hislands[$i]->{'id'} != $island->{'id'}) {
		 $island->{'ippts'}++;
		 $island->{'ipkaburi'}.= "$Hislands[$i]->{'name'} 섬(ID:$Hislands[$i]->{'id'})/";
		}
		}
	 }


	 my($ip0) = @_;
	 # 전체 섬에서 찾기
	 my($i);
	 for($i = 0; $i < $HislandNumber; $i++) {
		if($Hislands[$i]->{'ip0'} eq $island->{'ip4'}) {
		if($Hislands[$i]->{'id'} != $island->{'id'}) {
		 $island->{'ippts'}++;
		 $island->{'ipkaburi'}.= "$Hislands[$i]->{'name'} 섬(ID:$Hislands[$i]->{'id'})/";
		}
		}
	 }
	 my($ip1) = @_;
	 # 전체 섬에서 찾기
	 my($i);
	 for($i = 0; $i < $HislandNumber; $i++) {
		if($Hislands[$i]->{'ip1'} eq $island->{'ip4'}) {
		if($Hislands[$i]->{'id'} != $island->{'id'}) {
		 $island->{'ippts'}++;
		 $island->{'ipkaburi'}.= "$Hislands[$i]->{'name'} 섬(ID:$Hislands[$i]->{'id'})/";
		}
		}
	 }
	 my($ip2) = @_;
	 # 전체 섬에서 찾기
	 my($i);
	 for($i = 0; $i < $HislandNumber; $i++) {
		if($Hislands[$i]->{'ip2'} eq $island->{'ip4'}) {
		if($Hislands[$i]->{'id'} != $island->{'id'}) {
		 $island->{'ippts'}++;
		 $island->{'ipkaburi'}.= "$Hislands[$i]->{'name'} 섬(ID:$Hislands[$i]->{'id'})/";
		}
		}
	 }
	 my($ip3) = @_;
	 # 전체 섬에서 찾기
	 my($i);
	 for($i = 0; $i < $HislandNumber; $i++) {
		if($Hislands[$i]->{'ip3'} eq $island->{'ip4'}) {
		if($Hislands[$i]->{'id'} != $island->{'id'}) {
		 $island->{'ippts'}++;
		 $island->{'ipkaburi'}.= "$Hislands[$i]->{'name'} 섬(ID:$Hislands[$i]->{'id'})/";
		}
		}
	 }
	 my($ip4) = @_;
	 # 전체 섬에서 찾기
	 my($i);
	 for($i = 0; $i < $HislandNumber; $i++) {
		if($Hislands[$i]->{'ip4'} eq $island->{'ip4'}) {
		if($Hislands[$i]->{'id'} != $island->{'id'}) {
		 $island->{'ippts'}++;
		 $island->{'ipkaburi'}.= "$Hislands[$i]->{'name'} 섬(ID:$Hislands[$i]->{'id'})/";
		}
		}
	 }
	 my($ip5) = @_;
	 # 전체 섬에서 찾기
	 my($i);
	 for($i = 0; $i < $HislandNumber; $i++) {
		if($Hislands[$i]->{'ip5'} eq $island->{'ip4'}) {
		if($Hislands[$i]->{'id'} != $island->{'id'}) {
		 $island->{'ippts'}++;
		 $island->{'ipkaburi'}.= "$Hislands[$i]->{'name'} 섬(ID:$Hislands[$i]->{'id'})/";
		}
		}
	 }


	 my($ip0) = @_;
	 # 전체 섬에서 찾기
	 my($i);
	 for($i = 0; $i < $HislandNumber; $i++) {
		if($Hislands[$i]->{'ip0'} eq $island->{'ip5'}) {
		if($Hislands[$i]->{'id'} != $island->{'id'}) {
		 $island->{'ippts'}++;
		 $island->{'ipkaburi'}.= "$Hislands[$i]->{'name'} 섬(ID:$Hislands[$i]->{'id'})/";
		}
		}
	 }
	 my($ip1) = @_;
	 # 전체 섬에서 찾기
	 my($i);
	 for($i = 0; $i < $HislandNumber; $i++) {
		if($Hislands[$i]->{'ip1'} eq $island->{'ip5'}) {
		if($Hislands[$i]->{'id'} != $island->{'id'}) {
		 $island->{'ippts'}++;
		 $island->{'ipkaburi'}.= "$Hislands[$i]->{'name'} 섬(ID:$Hislands[$i]->{'id'})/";
		}
		}
	 }
	 my($ip2) = @_;
	 # 전체 섬에서 찾기
	 my($i);
	 for($i = 0; $i < $HislandNumber; $i++) {
		if($Hislands[$i]->{'ip2'} eq $island->{'ip5'}) {
		if($Hislands[$i]->{'id'} != $island->{'id'}) {
		 $island->{'ippts'}++;
		 $island->{'ipkaburi'}.= "$Hislands[$i]->{'name'} 섬(ID:$Hislands[$i]->{'id'})/";
		}
		}
	 }
	 my($ip3) = @_;
	 # 전체 섬에서 찾기
	 my($i);
	 for($i = 0; $i < $HislandNumber; $i++) {
		if($Hislands[$i]->{'ip3'} eq $island->{'ip5'}) {
		if($Hislands[$i]->{'id'} != $island->{'id'}) {
		 $island->{'ippts'}++;
		 $island->{'ipkaburi'}.= "$Hislands[$i]->{'name'} 섬(ID:$Hislands[$i]->{'id'})/";
		}
		}
	 }
	 my($ip4) = @_;
	 # 전체 섬에서 찾기
	 my($i);
	 for($i = 0; $i < $HislandNumber; $i++) {
		if($Hislands[$i]->{'ip4'} eq $island->{'ip5'}) {
		if($Hislands[$i]->{'id'} != $island->{'id'}) {
		 $island->{'ippts'}++;
		 $island->{'ipkaburi'}.= "$Hislands[$i]->{'name'} 섬(ID:$Hislands[$i]->{'id'})/";
		}
		}
	 }
	 my($ip5) = @_;
	 # 전체 섬에서 찾기
	 my($i);
	 for($i = 0; $i < $HislandNumber; $i++) {
		if($Hislands[$i]->{'ip5'} eq $island->{'ip5'}) {
		if($Hislands[$i]->{'id'} != $island->{'id'}) {
		 $island->{'ippts'}++;
		 $island->{'ipkaburi'}.= "$Hislands[$i]->{'name'} 섬(ID:$Hislands[$i]->{'id'})/";
		}
		}
	 }

	$ippts = $island->{'ippts'};

	$island->{'iprank'} = $island->{'ippts'};


	islandSortip();
	 }

 out(<<END);

<HR>

<H1>${HtagHeader_}표의 설명${H_tagHeader}</H1>
<P>
·IP 발견 수는 각 섬에 기록된 6개의 IP 를 다른 모든 섬의 IP 와 비교해산출합니다.<br>
 즉, 여러 건이 발견되면 다른 섬에 같은 IP 가 있다는 뜻입니다.<br><br>
·IP 변화 수는 인터넷 제공업체에 따라 달라지므로, 횟수가 많다고 해서 반드시 문제가 있는 것은 아닙니다.<br>
 여러 회선을 사용하는 경우에는 오탐일 수도 있습니다. 참고로 BIGLOBE 는 접속할 때마다 IP 가 바뀝니다(T∇T)<br><br>
·하위 순위는 동일 IP 발견 수를 기준으로 정렬합니다. 순위가 높을수록 주의해서 확인해 주세요.<br>
 이런 항목도 집계하면 부정행위 조사에 참고가 되지 않겠느냐는 의견은<br>
 필요하면 알려 주세요. 예: 미사일 발사 수, 댓글 발언 수 등.<br><br>
·등록 시 IP 는 섬 발견 시점의 IP 이며, 기존 섬은 최초 명령 입력 시점의 IP 가 기록됩니다.<br>
 이 정보는 기본적으로 공개되지 않습니다.(백업 사용 시에는 대응하지 않을 수 있습니다.<br><br>
·최신부터 과거 5회까지의 IP 변동값입니다. 명령 입력 시점의 IP 가 최신값으로 기록됩니다.<br>
 비정상적인 경우에 갱신되며, 이때 이전 IP 는 순차적으로 뒤로 밀립니다.
</P>
<TABLE BORDER>
<TR>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}순위${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_} 섬${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}동일 IP 발견 수${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}최신${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}―${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}―${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}―${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}옛${H_tagTH}</NOBR></TH>
<TH $HbgTitleCell align=center nowrap=nowrap><NOBR>${HtagTH_}등록 때${H_tagTH}</NOBR></TH>
</TR>
END

 my($island, $j, $farm, $factory, $mountain, $name, $id, $prize, $ii);
 for($ii = 0; $ii < $HislandNumber; $ii++) {
	$j = $ii + 1;
	$island = $Hislands[$ii];

	$id = $island->{'id'};

	if($island->{'absent'} == 0) {
		$name = "${HtagName_}$island->{'name'} 섬${H_tagName}";
	} else {
	 $name = "${HtagName2_}$island->{'name'} 섬($island->{'absent'})${H_tagName2}";
	}

	$ip0 = $island->{'ip0'};
	$ip1 = $island->{'ip1'};
	$ip2 = $island->{'ip2'};
	$ip3 = $island->{'ip3'};
	$ip4 = $island->{'ip4'};
	$ip5 = $island->{'ip5'};
	$ip6 = $island->{'ip6'};
	$ip7 = $island->{'ip7'};
	$ip8 = $island->{'ip8'};
	$ip9 = $island->{'ip9'};

	$ippts = $island->{'ippts'};

	$island->{'iprank'} = $island->{'ippts'};

	out(<<END);
<TR>
<TD $HbgNumberCell ROWSPAN=3 align=center nowrap=nowrap><NOBR>${HtagNumber_}$j${H_tagNumber}</NOBR></TD>
<TD $HbgNameCell ROWSPAN=3 align=left nowrap=nowrap>
<NOBR>
<A STYlE=\"text-decoration:none\" HREF="${HthisFile}?Sight=${id}">
$name
</A><br>(ID:$island->{'id'})
</NOBR>
</TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$island->{'ippts'}</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$island->{'ip5'}</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$island->{'ip4'}</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$island->{'ip3'}</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$island->{'ip2'}</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$island->{'ip1'}</NOBR></TD>
<TD $HbgInfoCell align=right nowrap=nowrap><NOBR>$island->{'ip0'}</NOBR></TD>
</TR>
<TR>
<TD $HbgCommentCell COLSPAN=7 align=left nowrap=nowrap><NOBR>${HtagTH_}동일 IP 가 발견된 섬:${H_tagTH}$island->{'ipkaburi'}</NOBR></TD>
</TR>
<TR>
<TD $HbgCommentCell COLSPAN=7 align=left nowrap=nowrap><NOBR>${HtagTH_}기타 정보:${H_tagTH}00~99턴에서의 IP 변동 수($island->{'ip8'}회)·통 산 IP 변동 수($island->{'ip9'}회)</NOBR></TD>
</TR>
END
 }

 out(<<END);
</TABLE>

<HR>
<H1>${HtagHeader_}새 섬을 탐색${H_tagHeader}</H1>
END

 if($HislandNumber < $HmaxIsland) {
	out(<<END);
<FORM action="$HthisFile" method="POST">
섬 이름<BR>
<INPUT TYPE="text" NAME="ISLANDNAME" SIZE=32 MAXLENGTH=32> 섬<BR>
비밀번호<BR>
<INPUT TYPE="password" NAME="PASSWORD" SIZE=32 MAXLENGTH=32><BR>
비밀번호 재확인<BR>
<INPUT TYPE="password" NAME="PASSWORD2" SIZE=32 MAXLENGTH=32><BR>

<INPUT TYPE="submit" VALUE="찾으러 가기" NAME="NewIslandButton">
</FORM>
END
 } else {
	out(<<END);
 섬의 수가 최대 수입니다... 현재 등록할 수 없습니다.
END
 }

 out(<<END);
<HR>
<H1>${HtagHeader_} 섬 이름과 비밀번호 변경${H_tagHeader}</H1>
<P>
(주의)이름의 변경에는$HcostChangeName${HunitMoney}이 들어갑니다.
</P>
<FORM action="$HthisFile" method="POST">
어느 섬입니까?<BR>
<SELECT NAME="ISLANDID">
$HislandList
</SELECT>
<BR>
새 이름을 입력하세요(변경하는 경우만)<BR>
<INPUT TYPE="text" NAME="ISLANDNAME" SIZE=32 MAXLENGTH=32> 섬<BR>
비밀번호(필수)<BR>
<INPUT TYPE="password" NAME="OLDPASS" SIZE=32 MAXLENGTH=32><BR>
새 비밀번호(변경할 경우만)<BR>
<INPUT TYPE="password" NAME="PASSWORD" SIZE=32 MAXLENGTH=32><BR>
비밀번호 재확인(변경할 경우만)<BR>
<INPUT TYPE="password" NAME="PASSWORD2" SIZE=32 MAXLENGTH=32><BR>

<INPUT TYPE="submit" VALUE="변경" NAME="ChangeInfoButton">
<INPUT TYPE="submit" VALUE="(·∀·)" NAME="IPInfoButton">
</FORM>

<HR>

END

}

# 톱 페이지용 로그 표시
sub logPrintTop {
 my($i);
 for($i = 0; $i < $HtopLogTurn; $i++) {
	logFilePrint($i, 0, 0);
 }
}

sub islandSortip {
my($flag, $i, $tmp);

my @idx = (0..$#Hislands);
@idx = sort { $Hislands[$b]->{'iprank'} <=> $Hislands[$a]->{'iprank'} || $a <=> $b } @idx;
@Hislands = @Hislands[@idx];
}

# 기록 파일 표시
sub historyPrint {
 open(HIN, "${HdirName}/hakojima.his");
 my(@line, $l);
 while($l = <HIN>) {
	chomp($l);
	push(@line, $l);
 }
 @line = reverse(@line);

 foreach $l (@line) {
	$l =~ /^([0-9]*),(.*)$/;
	out("<NOBR>${HtagNumber_}턴${1}${H_tagNumber}:${2}</NOBR><BR>\n");
 }
 close(HIN);
}

1;
