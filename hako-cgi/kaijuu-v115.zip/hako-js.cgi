#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}
#----------------------------------------------------------------------
# 괴수퇴치제도 JavaScript 개발 화면 모듈
# Java Applet을 사용하지 않고 브라우저 JavaScript로 계획을 편집한다.
#----------------------------------------------------------------------

package H2;

sub _jsq {
 my($s) = @_;
 $s = '' unless defined $s;
 $s =~ s/\\/\\\\/g;
 $s =~ s/'/\\'/g;
 $s =~ s/\r//g;
 $s =~ s/\n/\\n/g;
 return "'$s'";
}

sub ownerJavaMain {
 # 개방
 unlock();

 # 모드를 명시
 $H2::mainMode = 'owner';
 $H2::javaMode = 1;

 # id에서 섬을 가져옴
 $H2::currentNumber = $H2::idToNumber{$H2::currentID};
 my($island) = $H2::islands[$H2::currentNumber];
 $H2::currentName = $island->{'name'};

 # 비밀번호
 if(!checkPassword($island->{'password'},$H2::inputPassword)) {
	tempWrongPassword();
	return;
 }

 # 개발 화면
 tempOwnerJava();

 # ○○섬 로컬 게시판
 if($H2::useLbbs) {
	tempLbbsHead();
	tempLbbsInputJava();
	tempLbbsContents();
 }

 # 최근 상황
 tempRecent(1);
}

sub tempOwnerJava {
 $H2::currentNumber = $H2::idToNumber{$H2::currentID};
 my($island) = $H2::islands[$H2::currentNumber];

 my($set_com, $com_max) = ('', '');
 for(my $i = 0; $i < $H2::commandMax; $i++) {
	my($command) = $island->{'command'}->[$i];
	my($s_kind, $s_target, $s_x, $s_y, $s_arg) =
	 (
	 $command->{'kind'},
	 $command->{'target'},
	 $command->{'x'},
	 $command->{'y'},
	 $command->{'arg'}
	 );
	$set_com .= "[$s_kind,$s_x,$s_y,$s_arg,$s_target]";
	$set_com .= ",\n" if($i != $H2::commandMax - 1);
	$com_max .= ($i == $H2::commandMax - 1) ? '0' : '0,';
 }

 my($set_listcom, $set_costs) = ('', '');
 for(my $i = 0; $i < $H2::commandTotal; $i++) {
	my($kind) = $H2::comList[$i];
	my($name) = _jsq($H2::comName[$kind]);
	$set_listcom .= "[$kind,$name]";
	$set_listcom .= ",\n" if($i != $H2::commandTotal - 1);
	$set_costs .= "$kind:" . ($H2::comCost[$kind] || 0);
	$set_costs .= "," if($i != $H2::commandTotal - 1);
 }

 my($set_island) = '';
 for(my $i = 0; $i < $H2::islandNumber; $i++) {
	my($l_name) = _jsq($H2::islands[$i]->{'name'});
	my($l_id) = $H2::islands[$i]->{'id'};
	$set_island .= "[$l_id,$l_name]";
	$set_island .= ",\n" if($i != $H2::islandNumber - 1);
 }

 my($set_land) = '';
 my($land) = $island->{'land'};
 for(my $x = 0; $x < $H2::islandSize; $x++) {
	$set_land .= '[';
	for(my $y = 0; $y < $H2::islandSize; $y++) {
	 $set_land .= $land->[$x][$y];
	 $set_land .= ',' if($y != $H2::islandSize - 1);
	}
	$set_land .= ']';
	$set_land .= ",\n" if($x != $H2::islandSize - 1);
 }

 out(<<END);
<CENTER>
${H2::tagBig_}${H2::tagName_}${H2::currentName} 섬${H2::_tagName}개발계획${H2::_tagBig}<BR>
$H2::tempBack<BR>
</CENTER>
<SCRIPT Language="JavaScript">
<!--
isIE4 = (navigator.appVersion.charAt(0)>=4 && (navigator.appVersion).indexOf("MSIE") != -1);
isNN4 = (navigator.appVersion.charAt(0)>=4 && (navigator.appName).indexOf("Netscape")!=-1);
isNN6 = !!document.getElementById;

var mouseX = 0;
var mouseY = 0;
var g = [$com_max];
var command = [
$set_com
];
var comlist = [
$set_listcom
];
var comcost = {$set_costs};
var islname = [
$set_island
];
var landmap = [
$set_land
];

var COM_DO_NOTHING = $H2::comDoNothing;
var COM_GIVEUP = $H2::comGiveup;
var COM_SELL = $H2::comSell;
var COM_MONEY = $H2::comMoney;
var COM_FOOD = $H2::comFood;
var COM_PROPAGANDA = $H2::comPropaganda;
var COM_DESTROY = $H2::comDestroy;
var COM_FARM = $H2::comFarm;
var COM_FACTORY = $H2::comFactory;
var COM_RECLAIM = $H2::comReclaim;
var COM_MOUNTAIN = $H2::comMountain;
var COM_SEND_MONSTER = $H2::comSendMonster;
var COM_AUTO_PREPARE = $H2::comAutoPrepare;
var COM_AUTO_PREPARE2 = $H2::comAutoPrepare2;
var COM_AUTO_DELETE = $H2::comAutoDelete;
var COM_PREPARE = $H2::comPrepare;
var COM_PREPARE2 = $H2::comPrepare2;
var LAND_WASTE = $H2::landWaste;
var COMMAND_MAX = $H2::commandMax;

var missileCommands = {
 $H2::comMissileNM: true,
 $H2::comMissilePP: true,
 $H2::comMissileST: true,
 $H2::comMissileTH: true,
 $H2::comMissileSPP: true,
 $H2::comMissileSTI: true,
 $H2::comMissileLD: true
};

function init(){
 for(var i = 0; i < command.length ;i++) {
	g[i] = commandName(command[i][0]);
 }
 outp();
 var str = plchg();
 str = '<NOBR><font color=blue>---- 전송 완료 ----</font></NOBR><br>' + str;
 disp(str, '#ccffcc');
 document.onkeydown = commandKeyDown;
}

function commandKeyDown(e) {
 e = e || window.event;
 var src = e.target || e.srcElement;
 var tag = src && src.tagName ? src.tagName.toUpperCase() : '';
 if(tag == 'INPUT' || tag == 'TEXTAREA' || tag == 'SELECT') { return true; }
 var code = e.keyCode || e.which;
 if(code == 46) {
	cominput(3);
	if(e.preventDefault) { e.preventDefault(); }
	return false;
 }
 return true;
}

function commandName(kind) {
 for(var i = 0; i < comlist.length; i++) {
	if(Number(comlist[i][0]) == Number(kind)) { return comlist[i][1]; }
 }
 return '자금 조달';
}

function islandName(id) {
 for(var i = 0; i < islname.length; i++) {
	if(Number(islname[i][0]) == Number(id)) { return islname[i][1]; }
 }
 return '무인';
}

function moneyText(arg, cost) {
 var v = Number(arg) * Number(cost);
 if(v == 0) { v = Number(cost); }
 if(v < 0) { return (-v) + '$H2::unitFood'; }
 return v + '$H2::unitMoney';
}

function commandText(c, name) {
 var kind = '<FONT COLOR="#d08000"><B>' + name + '</B></FONT>';
 var point = '<FONT COLOR="#a06040"><B>(' + c[1] + ',' + c[2] + ')</B></FONT>';
 var target = '<FONT COLOR="#a06040"><B>' + islandName(c[4]) + ' 섬</B></FONT>';
 var cost = comcost[c[0]] || 0;
 var arg;
 if(c[0] == COM_DO_NOTHING || c[0] == COM_GIVEUP) {
	return kind;
 } else if(missileCommands[c[0]]) {
	arg = (Number(c[3]) == 0) ? '무제한' : (c[3] + '발');
	return target + point + ' 로 ' + kind + '(<FONT COLOR="#a06040"><B>' + arg + '</B></FONT>)';
 } else if(c[0] == COM_SEND_MONSTER) {
	return target + ' 로 ' + kind;
 } else if(c[0] == COM_SELL) {
	return kind + '<FONT COLOR="#a06040"><B>' + moneyText(c[3], cost) + '</B></FONT>';
 } else if(c[0] == COM_PROPAGANDA) {
	arg = Number(c[3]) == 0 ? '1회' : (c[3] + '회');
	return kind + '(' + arg + ')';
 } else if(c[0] == COM_MONEY || c[0] == COM_FOOD) {
	return target + ' 로 ' + kind + '<FONT COLOR="#a06040"><B>' + moneyText(c[3], cost) + '</B></FONT>';
 } else if(c[0] == COM_DESTROY) {
	if(Number(c[3]) != 0) {
	 return point + ' 에서 ' + kind + '(예산<FONT COLOR="#a06040"><B>' + moneyText(c[3], cost) + '</B></FONT>)';
	}
	return point + ' 에서 ' + kind;
 } else if(c[0] == COM_FARM || c[0] == COM_FACTORY || c[0] == COM_RECLAIM || c[0] == COM_MOUNTAIN) {
	if(Number(c[3]) != 0) {
	 return point + ' 에서 ' + kind + '(' + c[3] + '회)';
	}
	return point + ' 에서 ' + kind;
 }
 return point + ' 에서 ' + kind;
}

function plchg(){
 var strn1 = '';
 for(var i = 0; i < COMMAND_MAX; i++) {
	var c = command[i];
	var tmpnum = (i < 9) ? '0' : '';
	strn1 += '<A STYLE="text-decoration:none;color:000000" HREF="JavaScript:void(0);" onClick="ns(' + i + ');return false;"><NOBR>' +
	'<FONT COLOR="#d08000"><B>' + tmpnum + (i + 1) + ':</B></FONT>' +
	commandText(c, g[i]) + '</NOBR></A><BR>\\n';
 }
 return strn1;
}

function disp(str,bgclr){
 if(str == null) { str = ''; }
 var el = document.getElementById ? document.getElementById('LINKMSG1') : null;
 if(el) { el.innerHTML = str; }
 var plan = document.getElementById ? document.getElementById('plan') : null;
 if(plan) { plan.style.backgroundColor = bgclr; }
}

function markUnsent(){
 var str = plchg();
 str = '<NOBR><font color=red><b>----- 미전송 -----</b></font></NOBR><br>' + str;
 disp(str, 'white');
 outp();
}

function outp(){
 var comary = '';
 for(var k = 0; k < command.length; k++) {
	comary += Number(command[k][0]) + ' ' + Number(command[k][1]) + ' ' + Number(command[k][2]) + ' ' + Number(command[k][3]) + ' ' + Number(command[k][4]) + ' ';
 }
 document.myForm.COMARY.value = comary;
}

function selectedNumber(name) {
 var el = document.myForm.elements[name];
 return Number(el.options[el.selectedIndex].value);
}

function cominput(x, k, z) {
 var a = selectedNumber('NUMBER');
 var b = selectedNumber('COMMAND');
 var c = selectedNumber('POINTX');
 var d = selectedNumber('POINTY');
 var e = selectedNumber('AMOUNT');
 var f = selectedNumber('TARGETID');
 if(x == 6) { b = Number(k); }
 if(typeof z != 'undefined') { f = Number(z); }

 if(x == 1 || x == 6) {
	for(var i = COMMAND_MAX - 1; i > a; i--) {
	 command[i] = command[i - 1].slice(0);
	 g[i] = g[i - 1];
	}
 } else if(x == 3) {
	for(var i = a; i < COMMAND_MAX - 1; i++) {
	 command[i] = command[i + 1].slice(0);
	 g[i] = g[i + 1];
	}
	command[COMMAND_MAX - 1] = [COM_DO_NOTHING,0,0,0,0];
	g[COMMAND_MAX - 1] = commandName(COM_DO_NOTHING);
	markUnsent();
	return true;
 } else if(x == 4) {
	if(a == 0) { return true; }
	var tmp = command[a]; command[a] = command[a - 1]; command[a - 1] = tmp;
	var tg = g[a]; g[a] = g[a - 1]; g[a - 1] = tg;
	ns(a - 1);
	markUnsent();
	return true;
 } else if(x == 5) {
	if(a == COMMAND_MAX - 1) { return true; }
	var tmp = command[a]; command[a] = command[a + 1]; command[a + 1] = tmp;
	var tg = g[a]; g[a] = g[a + 1]; g[a + 1] = tg;
	ns(a + 1);
	markUnsent();
	return true;
 }

 command[a] = [Number(b), Number(c), Number(d), Number(e), Number(f)];
 g[a] = commandName(b);
 ns(Math.min(a + 1, COMMAND_MAX - 1));
 markUnsent();
 menuclose();
 return true;
}

function firstEmptySlot(start) {
 start = Number(start) || 0;
 for(var i = start; i < COMMAND_MAX; i++) {
	if(Number(command[i][0]) == COM_DO_NOTHING) { return i; }
 }
 return -1;
}

function autoInput() {
 var kind = selectedNumber('AUTOCOMMAND');
 if(kind == COM_AUTO_DELETE) {
	for(var i = 0; i < COMMAND_MAX; i++) {
	 command[i] = [COM_DO_NOTHING,0,0,0,0];
	 g[i] = commandName(COM_DO_NOTHING);
	}
	ns(0);
 } else if(kind == COM_AUTO_PREPARE || kind == COM_AUTO_PREPARE2) {
	var realKind = (kind == COM_AUTO_PREPARE2) ? COM_PREPARE2 : COM_PREPARE;
	var idx = firstEmptySlot(0);
	for(var y = 0; y < $H2::islandSize; y++) {
	 for(var x = 0; x < $H2::islandSize; x++) {
		idx = firstEmptySlot(idx);
		if(idx < 0) { break; }
		if(landmap[x][y] == LAND_WASTE) {
		 command[idx] = [realKind,x,y,0,0];
		 g[idx] = commandName(realKind);
		 idx++;
		}
	 }
	 if(idx < 0) { break; }
	}
	var next = firstEmptySlot(0);
	ns(next < 0 ? COMMAND_MAX - 1 : next);
 }
 markUnsent();
 return false;
}

function ps(e, x, y) {
 if(typeof y == 'undefined') {
	y = x;
	x = e;
	e = window.event;
 }
 getMouseData(e);
 document.myForm.POINTX.options[x].selected = true;
 document.myForm.POINTY.options[y].selected = true;
 showMenu();
 return false;
}

function ns(x) {
 if(x >= COMMAND_MAX) { x = COMMAND_MAX - 1; }
 document.myForm.NUMBER.options[x].selected = true;
 return false;
}

function set_com(x, y, land) {
 var com_str = land + '\\n';
 for(var i = 0; i < COMMAND_MAX; i++) {
	var c = command[i];
	if(Number(c[1]) == Number(x) && Number(c[2]) == Number(y) && Number(c[0]) < 30) {
	 com_str += '[' + (i + 1) + ']' + g[i] + ' ';
	}
 }
 window.status = com_str;
 if(document.myForm && document.myForm.COMSTATUS) {
	document.myForm.COMSTATUS.value = com_str;
 }
}

function jump(theForm) {
 var sIndex = theForm.TARGETID.selectedIndex;
 var url = theForm.TARGETID.options[sIndex].value;
 if(url != '') {
	window.open('$H2::thisFile?IslandMap=' + url + '&JAVAMODE=1', '', 'menubar=yes,toolbar=no,location=no,directories=no,status=yes,scrollbars=yes,resizable=yes,width=450,height=630');
 }
 return false;
}

function showMenu() {
 var el = document.getElementById ? document.getElementById('menu') : null;
 if(!el) { return true; }
 el.style.left = mouseX + 'px';
 el.style.top = Math.max(0, mouseY - 50) + 'px';
 el.style.zIndex = 9999;
 el.style.display = 'block';
 el.style.visibility = 'visible';
 return true;
}

function menuclose() {
 var el = document.getElementById ? document.getElementById('menu') : null;
 if(el) { el.style.display = 'none'; el.style.visibility = 'hidden'; }
 return false;
}

function getMouseData(e) {
 e = e || window.event;
 if(!e) { return true; }
 if(typeof e.pageX == 'number') {
	mouseX = e.pageX;
	mouseY = e.pageY;
 } else {
	mouseX = e.clientX + (document.documentElement.scrollLeft || document.body.scrollLeft || 0);
	mouseY = e.clientY + (document.documentElement.scrollTop || document.body.scrollTop || 0);
 }
 return true;
}

window.onload = init;
//-->
</SCRIPT>
<DIV ID="menu" STYLE="position:absolute; visibility:hidden; display:none; z-index:9999;">
<TABLE BORDER=0 BGCOLOR=#ccffcc>
<TR><TD NOWRAP>
END

 for(my $i = 0; $i < $H2::commandTotal; $i++) {
	my($kind) = $H2::comList[$i];
	next if($kind >= 30);
	my($cost) = $H2::comCost[$kind];
	if($cost == 0) {
	 $cost = '무료';
	} elsif($cost < 0) {
	 $cost = -$cost;
	 $cost .= $H2::unitFood;
	} else {
	 $cost .= $H2::unitMoney;
	}
	out("<a href=\"javascript:void(0);\" onClick=\"cominput(6,${kind});return false;\" STYLE=\"text-decoration:none\">$H2::comName[$kind]($cost)<BR></A>\n");
	out("<HR>\n") if($i == 4);
 }

 out(<<END);
<HR>
<a href="Javascript:void(0);" onClick="menuclose();return false;" STYLE="text-decoration:none">메뉴 닫기</A>
</TD></TR>
</TABLE>
</DIV>
END

 islandInfo();

 out(<<END);
<CENTER>
<FORM name="myForm" action="$H2::thisFile" method=POST>
<TABLE BORDER>
<TR valign=top>
<TD $H2::bgInputCell>
<CENTER>
<B> 비밀번호</B></BR>
<INPUT TYPE=password NAME=PASSWORD VALUE="$H2::defaultPassword">
<HR>
<B>동작</B><BR>
<A HREF="JavaScript:void(0);" onClick="cominput(1);return false;">삽입</A>
<A HREF="JavaScript:void(0);" onClick="cominput(2);return false;">덮어쓰기</A>
<A HREF="JavaScript:void(0);" onClick="cominput(3);return false;">삭제</A>
<HR>
<B>계획번호</B><SELECT NAME=NUMBER>
END

 for(my $i = 0; $i < $H2::commandMax; $i++) {
	my($j) = $i + 1;
	out("<OPTION VALUE=$i>$j\n");
 }

 out(<<END);
</SELECT><BR>
<HR>
<B>개발계획</B><BR>
<SELECT NAME=COMMAND>
END

 for(my $i = 0; $i < $H2::commandTotal; $i++) {
	my($kind) = $H2::comList[$i];
	my($cost) = $H2::comCost[$kind];
	if($cost == 0) {
	 $cost = '무료';
	} elsif($cost < 0) {
	 $cost = - $cost;
	 $cost .= $H2::unitFood;
	} else {
	 $cost .= $H2::unitMoney;
	}
	my($s) = ($kind == $H2::defaultKind) ? 'SELECTED' : '';
	out("<OPTION VALUE=$kind $s>$H2::comName[$kind]($cost)\n");
 }

 out(<<END);
</SELECT>
<HR>
<B>좌표(</B>
<SELECT NAME=POINTX>
END

 for(my $i = 0; $i < $H2::islandSize; $i++) {
	my($s) = ($i == $H2::defaultX) ? ' SELECTED' : '';
	out("<OPTION VALUE=$i$s>$i\n");
 }

 out(<<END);
</SELECT>, <SELECT NAME=POINTY>
END

 for(my $i = 0; $i < $H2::islandSize; $i++) {
	my($s) = ($i == $H2::defaultY) ? ' SELECTED' : '';
	out("<OPTION VALUE=$i$s>$i\n");
 }

 out(<<END);
</SELECT><B>)</B>
<HR>
<B>수량</B><SELECT NAME=AMOUNT>
END

 for(my $i = 0; $i < 100; $i++) {
	out("<OPTION VALUE=$i>$i\n");
 }

 out(<<END);
</SELECT>
<HR>
<B>대상 섬</B>:
<B><BIG><A HREF="JavaScript:void(0);" onClick="jump(myForm);return false;" STYLE="text-decoration:none"> 표시 </A></BIG></B><BR>
<SELECT NAME=TARGETID>
$H2::targetList
</SELECT>
<HR>
<B> 명령 이동</B><br>
<BIG><A HREF="JavaScript:void(0);" onClick="cominput(4);return false;" STYLE="text-decoration:none"> ▲ </A>..
<A HREF="JavaScript:void(0);" onClick="cominput(5);return false;" STYLE="text-decoration:none"> ▼ </A></BIG>
<HR>
<INPUT TYPE="hidden" NAME="COMARY" value="">
<INPUT TYPE="hidden" NAME="JAVAMODE" value="1">
<INPUT TYPE=submit VALUE="계획 전송" NAME=CommandJavaButton$H2::islands[$H2::currentNumber]->{'id'}>
<p><font size=2>마지막에 <font color=red>계획 전송 버튼</font>을<br>누르는 것을 잊지 마세요.</font>
</CENTER>
</TD>
<TD $H2::bgMapCell><center>
<TEXTAREA NAME="COMSTATUS" cols="48" rows="2"></TEXTAREA></center>
END
 islandMapJava(1);
 my $comment = $H2::islands[$H2::currentNumber]->{'comment'};
 $comment =~ s/\t.*$//;
 out(<<END);
</TD>
<TD $H2::bgCommandCell id="plan">
<CENTER>
<B>자동 입력</B><BR>
<SELECT NAME=AUTOCOMMAND>
END

 for my $kind ($H2::comAutoPrepare, $H2::comAutoPrepare2, $H2::comAutoDelete) {
	my($cost) = $H2::comCost[$kind];
	$cost = '무료' if($cost == 0);
	out("<OPTION VALUE=$kind>$H2::comName[$kind]($cost)\n");
 }

 out(<<END);
</SELECT><BR>
<INPUT TYPE=button VALUE="자동 입력 계획 전송" onClick="autoInput();return false;">
<HR>
<span id="LINKMSG1"></span>
<BR>
</CENTER>
</TD>
</TR>
</TABLE>
</FORM>
</CENTER>
<HR>
<CENTER>
${H2::tagBig_}코멘트갱신${H2::_tagBig}<BR>
<FORM action="$H2::thisFile" method="POST">
코멘트<INPUT TYPE=text NAME=MESSAGE SIZE=80 VALUE="$comment"><BR>
비밀번호<INPUT TYPE=password NAME=PASSWORD VALUE="$H2::defaultPassword">
<INPUT TYPE="hidden" NAME=JAVAMODE VALUE="1">
<INPUT TYPE=submit VALUE="코멘트갱신" NAME=MessageButton$H2::islands[$H2::currentNumber]->{'id'}>
</FORM>
</CENTER>
END
}

sub commandJavaMain {
 $H2::currentNumber = $H2::idToNumber{$H2::currentID};
 my($island) = $H2::islands[$H2::currentNumber];
 $H2::currentName = $island->{'name'};
 $H2::javaMode = 1;

 if(!checkPassword($island->{'password'},$H2::inputPassword)) {
	unlock();
	tempWrongPassword();
	return;
 }

 my($command) = $island->{'command'};
 my($comary) = $H2::commandComary || '';
 for(my $i = 0; $i < $H2::commandMax; $i++) {
	if($comary =~ s/^\s*([0-9]+)\s+([0-9]+)\s+([0-9]+)\s+([0-9]+)\s+([0-9]+)\s*//) {
	 my($kind, $x, $y, $arg, $target) = ($1, $2, $3, $4, $5);
	 $kind = $H2::comDoNothing if($kind == 0);
	 $command->[$i] = {
		'kind' => $kind,
		'x' => $x,
		'y' => $y,
		'arg' => $arg,
		'target' => $target
	 };
	} else {
	 $command->[$i] = {
		'kind' => $H2::comDoNothing,
		'target' => 0,
		'x' => 0,
		'y' => 0,
		'arg' => 0
	 };
	}
 }
 tempCommandAdd();
 writeIslandsFile($H2::currentID);
 ownerJavaMain();
}

sub commentJavaMain {
 $H2::currentNumber = $H2::idToNumber{$H2::currentID};
 my($island) = $H2::islands[$H2::currentNumber];
 $H2::currentName = $island->{'name'};
 $H2::javaMode = 1;

 if(!checkPassword($island->{'password'},$H2::inputPassword)) {
	unlock();
	tempWrongPassword();
	return;
 }
 my($host) = $ENV{'REMOTE_HOST'};
 my($addr) = $ENV{'REMOTE_ADDR'};
 if ($host eq '') { $host = $addr; }
 if ($host eq $addr) { $host = gethostbyaddr(pack('C4',split(/\./,$host)),2) || $addr; }
 $island->{'comment'} = htmlEscape($H2::message)."\t". $host;
 writeIslandsFile($H2::currentID);
 tempComment();
 ownerJavaMain();
}

sub islandMapJava {
 my($mode) = @_;
 my($island) = $H2::islands[$H2::currentNumber];
 out(<<END);
<CENTER><TABLE BORDER><TR><TD>
END
 my($land) = $island->{'land'};
 my($landValue) = $island->{'landValue'};
 my($command) = $island->{'command'};
 my($com, @comStr);
 if($H2::mainMode eq 'owner') {
	for(my $i = 0; $i < $H2::commandMax; $i++) {
	 my($j) = $i + 1;
	 $com = $command->[$i];
	 if($com->{'kind'} < 21) {
		$comStr[$com->{'x'}][$com->{'y'}] .= " [${j}]$H2::comName[$com->{'kind'}]";
	 }
	}
 }
 out("<IMG SRC=\"xbar.gif\" width=400 height=16><BR>");
 for(my $y = 0; $y < $H2::islandSize; $y++) {
	if(($y % 2) == 0) {
	 out("<IMG SRC=\"space${y}.gif\" width=16 height=32>");
	}
	for(my $x = 0; $x < $H2::islandSize; $x++) {
	 my($l) = $land->[$x][$y];
	 my($lv) = $landValue->[$x][$y];
	 landStringJava($l, $lv, $x, $y, $mode, $comStr[$x][$y]);
	}
	if(($y % 2) == 1) {
	 out("<IMG SRC=\"space${y}.gif\" width=16 height=32>");
	}
	out("<BR>");
 }
 out("</TD></TR></TABLE></CENTER>\n");
}

sub landStringJava {
 my($l, $lv, $x, $y, $mode, $comStr) = @_;
 my($point) = "($x,$y)";
 my($image, $alt);

 if($l == $H2::landSea) {
	if($lv == 1) { $image = 'land14.gif'; $alt = '바다(얕은 바다)'; }
	else { $image = 'land0.gif'; $alt = '바다'; }
 } elsif($l == $H2::landWaste) {
	if($lv == 1) { $image = 'land13.gif'; $alt = '황무지'; }
	elsif($lv > 1) {
	 $alt = '황무지(한 송이의 꽃)';
	 if($lv < 4) { $image = 'flower0.gif'; } else { $image = 'flower2.gif'; }
	} else { $image = 'land1.gif'; $alt = '황무지'; }
 } elsif($l == $H2::landPlains) { $image = 'land2.gif'; $alt = '평지'; }
 elsif($l == $H2::landForest) {
	$image = 'land6.gif';
	$alt = ($mode == 1) ? "숲(${lv}$H2::unitTree)" : '숲';
 } elsif($l == $H2::landTown) {
	my($p, $n);
	if($lv < 30) { $p = 3; $n = '마을'; }
	elsif($lv < 100) { $p = 4; $n = '마을'; }
	else { $p = 5; $n = '도시'; }
	$image = "land${p}.gif"; $alt = "$n(${lv}$H2::unitPop)";
 } elsif($l == $H2::landFarm) { $image = 'land7.gif'; $alt = "농장(${lv}0${H2::unitPop}규모)"; }
 elsif($l == $H2::landFactory) { $image = 'land8.gif'; $alt = "공장(${lv}0${H2::unitPop}규모)"; }
 elsif($l == $H2::landBase) { my($level) = expToLevel($l, $lv); $image = 'land9.gif'; $alt = "미사일 기지 (레벨 ${level}/경험치 $lv)"; }
 elsif($l == $H2::landSbase) {
	if($mode == 0) { $image = 'land0.gif'; $alt = '바다'; }
	else { my($level) = expToLevel($l, $lv); $image = 'land12.gif'; $alt = "해저 기지 (레벨 ${level}/경험치 $lv)"; }
 } elsif($l == $H2::landDefence) { $image = 'land10.gif'; $alt = '방위 시설'; }
 elsif($l == $H2::landHaribote) { $image = 'land10.gif'; $alt = ($mode == 0) ? '방위 시설' : '가짜 시설'; }
 elsif($l == $H2::landHoihoi) { $image = 'hoihoi0.gif'; $alt = '방어 시설'; }
 elsif($l == $H2::landOil) { $image = 'land16.gif'; $alt = '해저 유전'; }
 elsif($l == $H2::landMountain) {
	if($lv > 0) { $image = 'land15.gif'; $alt = "산(채굴장${lv}0${H2::unitPop}규모)"; }
	else { $image = 'land11.gif'; $alt = '산'; }
 } elsif($l == $H2::landMonument) { $image = $H2::monumentImage[$lv]; $alt = $H2::monumentName[$lv]; }
 elsif(($l == $H2::landMonster)||($l == $H2::landMonsterS)) {
	my($kind, $name, $hp) = monsterSpec($lv);
	my($special) = $H2::monsterSpecial[$kind];
	$image = $H2::monsterImage[$kind];
	if((($special == 3) && (($H2::islandTurn % 2) == 1)) || (($special == 4) && (($H2::islandTurn % 2) == 0))) {
	 $image = $H2::monsterImage2[$kind];
	}
	$alt = "괴수$name(체력${hp})";
	if($l == $H2::landMonsterS) { $alt = "괴수$name(체력${hp}:착탄 지점)"; }
	elsif($H2::monsterInvisible[$kind] == 1) {
	 my($ia) = ($H2::islandTurn + $lv + $x) % 5;
	 if($ia == 4) { $image = 'land5.gif'; $alt = "도시(100$H2::unitPop)"; }
	 elsif($ia == 3) { $image = 'land7.gif'; $alt = "농장(100${H2::unitPop}규모)"; }
	 elsif($ia == 2) { $image = 'land14.gif'; $alt = '바다(얕은 바다)'; }
	 elsif($ia == 1) { $image = 'land13.gif'; $alt = '황무지'; }
	 else { $image = 'land1.gif'; $alt = '황무지'; }
	}
 } else {
	$image = 'land1.gif';
	$alt = '황무지';
 }

 my($full) = "$point $alt";
 my($status) = $full;
 $status .= " $comStr" if(defined $comStr && $comStr ne '');
 my($jsfull) = _jsq($full);
 my($jsstatus) = _jsq($status);
 if($mode == 1) {
	out(qq#<A HREF="JavaScript:void(0);" onclick="ps(event,$x,$y);return false;" onMouseOver="set_com($x,$y,$jsfull); return true;" onMouseOut="window.status = '';">#);
 } else {
	out(qq#<A HREF="JavaScript:void(0);" onclick="ps(event,$x,$y);return false;" onMouseOver="window.status = $jsstatus; return true;" onMouseOut="window.status = '';">#);
 }
 out("<IMG SRC=\"$image\" ALT=\"$status\" TITLE=\"$status\" width=32 height=32 BORDER=0></A>");
}

sub printIslandJava {
 unlock();
 $H2::currentNumber = $H2::idToNumber{$H2::currentID};
 if($H2::currentNumber eq '') {
	tempProblem();
	return;
 }
 $H2::currentName = $H2::islands[$H2::currentNumber]->{'name'};
 out(<<END);
<SCRIPT Language="JavaScript">
<!--
var mouseX = 0;
var mouseY = 0;
function ps(e, x, y) {
 if(typeof y == 'undefined') { y = x; x = e; e = window.event; }
 getMouseData(e);
 if(window.opener && window.opener.document && window.opener.document.myForm) {
	window.opener.document.myForm.POINTX.options[x].selected = true;
	window.opener.document.myForm.POINTY.options[y].selected = true;
 }
 showMenu();
 return false;
}
function showMenu() {
 var el = document.getElementById('menu');
 if(!el) { return true; }
 el.style.left = mouseX + 'px';
 el.style.top = Math.max(0, mouseY - 20) + 'px';
 el.style.zIndex = 9999;
 el.style.visibility = 'visible';
 el.style.display = 'block';
 return true;
}
function menuclose() {
 var el = document.getElementById('menu');
 if(el) { el.style.display = 'none'; el.style.visibility = 'hidden'; }
 return false;
}
function getMouseData(e) {
 e = e || window.event;
 if(!e) { return true; }
 if(typeof e.pageX == 'number') { mouseX = e.pageX; mouseY = e.pageY; }
 else {
	mouseX = e.clientX + (document.documentElement.scrollLeft || document.body.scrollLeft || 0);
	mouseY = e.clientY + (document.documentElement.scrollTop || document.body.scrollTop || 0);
 }
 return true;
}
function cominput(kind) {
 if(window.opener && window.opener.cominput) {
	window.opener.cominput(6, kind, $H2::currentID);
 }
 menuclose();
 return false;
}
//-->
</SCRIPT>
<DIV ID="menu" STYLE="position:absolute; visibility:hidden; display:none; z-index:9999;">
<TABLE BORDER=0 BGCOLOR=#ccffcc>
<TR><TD NOWRAP>
END
 for(my $i = 0; $i < $H2::commandTotal; $i++) {
	my($kind) = $H2::comList[$i];
	next unless(($kind >= 31 && $kind <= 38) || ($kind == $H2::comSendMonster) || ($kind == $H2::comMoney) || ($kind == $H2::comFood));
	my($cost) = $H2::comCost[$kind];
	if($cost == 0) { $cost = '무료'; }
	elsif($cost < 0) { $cost = -$cost; $cost .= $H2::unitFood; }
	else { $cost .= $H2::unitMoney; }
	out("<a href=\"javascript:void(0);\" onClick=\"cominput(${kind});return false;\" STYLE=\"text-decoration:none\">$H2::comName[$kind]($cost)<BR></A>\n");
 }
 out(<<END);
<HR>
<a href="Javascript:void(0);" onClick="menuclose();return false;" STYLE="text-decoration:none">메뉴 닫기</A>
</TD></TR>
</TABLE>
</DIV>
<center>${H2::tagBig_}${H2::tagName_}'${H2::currentName} 섬'${H2::_tagName}${H2::_tagBig}</center>
END
 islandMapJava(0);
 tempRecent(0);
}

sub tempLbbsInputJava {
 out(<<END);
<CENTER>
<FORM action="$H2::thisFile" method="POST">
<TABLE BORDER>
<TR>
<TH>이름</TH>
<TH COLSPAN=2>내용</TH>
</TR>
<TR>
<TD><INPUT TYPE="text" SIZE=32 MAXLENGTH=32 NAME="LBBSNAME" VALUE="$H2::defaultName"></TD>
<TD COLSPAN=2><INPUT TYPE="text" SIZE=80 NAME="LBBSMESSAGE"></TD>
</TR>
<TR>
<TH> 비밀번호</TH>
<TH COLSPAN=2>동작</TH>
</TR>
<TR>
<TD><INPUT TYPE=password SIZE=32 MAXLENGTH=32 NAME=PASSWORD VALUE="$H2::defaultPassword"></TD>
<TD align=right>
<INPUT TYPE="submit" VALUE="기록하기" NAME="LbbsButtonOW$H2::currentID">
</TD>
<TD align=right>
번호
<SELECT NAME=NUMBER>
END
 for(my $i = 0; $i < $H2::lbbsMax; $i++) {
	my($j) = $i + 1;
	out("<OPTION VALUE=$i>$j\n");
 }
 out(<<END);
</SELECT>
<INPUT TYPE="submit" VALUE="삭제" NAME="LbbsButtonDL$H2::currentID">
<INPUT TYPE="hidden" NAME=JAVAMODE VALUE="1">
</TD>
</TR>
</TABLE>
</FORM>
</CENTER>
END
}

1;
