#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}
# ↑은서버에 맞게 변경해 주세요.
# perl5용입니다.

#----------------------------------------------------------------------
# 모형정원 제도 ver2.20
# 메인 스크립트
# 사용 조건과 사용 방법은 hako-readme.txt 파일을 참조해 주세요
#
# 모형정원 제도의 페이지: http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html
#----------------------------------------------------------------------
# 괴수퇴치제도 ver1.15
# 메인 스크립트(ver1.15)
# Arranged by 차차마루
# 사용 조건등은,readme.txt 파일을 참조
# 배포페이지: http://www.geocities.co.jp/SiliconValley-Bay/2566/
# ### 주의!! 원본판과 데이터 호환은 되지 않습니다.###
#
# [이력]
# v1.00 2000/03/12 처음판
# 2000/05/07 일반배포시작
# v1.10 2000/06/11
# v1.15 2000/07/01
#----------------------------------------------------------------------

package H2;


#----------------------------------------------------------------------
# 각종 설정 값
# 아래 설정 값을 서버 환경에 맞게 변경해 주세요.
#----------------------------------------------------------------------

#----------------------------------------------------------------------
# 아래는 반드시 설정해야 하는 항목입니다
#----------------------------------------------------------------------

# 이 파일을 설치할 디렉터리
# my($baseDir) = 'http://서버/디렉터리';
#
# 예)
# http://cgi2.bekkoame.ne.jp/cgi-bin/user/u5534/hakoniwa/hakojima.cgi
# 처럼 배치한 경우,
# my($baseDir) = 'http://cgi2.bekkoame.ne.jp/cgi-bin/user/u5534/hakoniwa';
# 지합니다. 끝에 슬래시(/)는 붙이지 않습니다.

my($scriptBaseScheme) = (($ENV{'HTTPS'} || '') =~ /^(on|1)$/i) ? 'https' : 'http';
my($scriptBaseHost) = $ENV{'HTTP_HOST'} || $ENV{'SERVER_NAME'} || 'localhost';
if (!$ENV{'HTTP_HOST'} && $ENV{'SERVER_PORT'} && !(($scriptBaseScheme eq 'http' && $ENV{'SERVER_PORT'} == 80) || ($scriptBaseScheme eq 'https' && $ENV{'SERVER_PORT'} == 443))) {
 $scriptBaseHost.= ":$ENV{'SERVER_PORT'}";
}
my($scriptBasePath) = $ENV{'SCRIPT_NAME'} || '';
$scriptBasePath =~ s{/[^/]*$}{};
my($baseDir) = "$scriptBaseScheme://$scriptBaseHost$scriptBasePath";


# 이미지 파일을 둘 디렉터리
# my($imageDir) = 'http://서버/디렉터리';
#my($imageDir) = $baseDir;
my($imageDir) = 'https://esils.com/BBdata/hakoimg';
# 문자 변환 라이브러리 위치

# UTF-8 환경에서는 외부 문자 변환 라이브러리를 사용하지 않습니다.
# UTF-8 환경에서는 외부 문자 변환 라이브러리를 사용하지 않습니다.
# 이 비밀번호는, 모든 섬의 비밀번호를 대신 사용할 수 있습니다.
# 예를 들어,'다른 섬의 비밀번호 변경'등도 할 수 있습니다.
my($masterPassword) = '1064';

# 특수 비밀번호
# 이 비밀번호로 '이름 변경'을 실행하면, 그 섬의 자금, 식량이 최댓값이 됩니다.
# (실제로 이름이 변경될 필요는 없습니다.)
$H2::specialPassword = 'yourspecialpassword';

# 관리자 이름
my($adminName) = '관리자의 이름';

# 관리자의 메일 주소
my($email) = 'admin@example.com';

# 게시판 주소
my($bbs) = $baseDir;

# 홈페이지 주소
my($toppage) = "$baseDir/";

# 사양서의 주소
my($manpage) = "$baseDir/hako-readme.txt";

# 디렉터리 권한
# 일반적으로 0755이면 좋지만,0777,0705,0704등에서 없으면 사용 불가는 서버도 있습니다
$H2::dirMode = 0755;

# 데이터 디렉터리 이름
# 여기에서 설정한 이름의 디렉터리 아래에 데이터가 저장됩니다.
# 기본값에서는'data'로 되어 있지만, 보안상
# 보안을 위해 다른 이름으로 변경해 주세요.
$H2::dirName = 'data';

# 잠금 방식
# 1 디렉터리
# 2 시스템 콜(가능하면 이 방식을 권장합니다)
# 3 심볼릭 링크
# 4 일반 파일(권장하지 않음)
my($lockMode) = 2;

# (주)
# 4을 선택하는 경우에는,'key-free'라는, 권한 666의 빈 파일을,
# 이 파일과 같은 위치에 배치해 주세요.

#----------------------------------------------------------------------
# 반드시 설정하는 부분은 이상
#----------------------------------------------------------------------

#----------------------------------------------------------------------
# 아래는 필요에 따라 설정하는 항목입니다
#----------------------------------------------------------------------
#----------------------------------------
# 게임의 진행야 파일등
#----------------------------------------
# 1턴이 몇 초인지
$H2::unitTime = 3600*3; # 3 시간

# 이상종료 기준 시간
# (잠금 후 몇 초 뒤 강제 해제할지)
my($unlockTime) = 120;

# 섬의 최대 수
$H2::maxIsland = 30;

### ---v--- ver1.10 ---v---
# 종료 턴
# 0으로 하면 자동 종료하지 않습니다
$H2::lastTurn = 0;
### ---^--- ver1.10 ---^---

# 톱 페이지에 표시할 로그 턴 수
$H2::topLogTurn = 1;

# 로그 파일 유지 턴 수
$H2::logMax = 8;

# 백업을 몇 턴오키에취는 가
$H2::backupTurn = 12;

# 백업을 몇 회분 남음습니까
$H2::backupTimes = 4;

# 발견 로그유지 줄 수
$H2::historyMax = 10;

# 포기 명령 자동 입력 턴 수
$H2::giveupTurn = 28;

### ---v--- ver1.10 ---v---
# 신규 발견 섬의 다른 섬에 대한 미사일 발사불허 턴 수
# 0 에하면 발견 직후라도 미사일 발사가 허용됩니다
$H2::noMissileTurn = 20;

# 신규 발견 섬의 다른 섬에 대한 괴수 파견불허 턴 수
# 0 에하면 발견 직후라도괴수 파견이허용됩니다
$H2::noSendMonsterTurn = 20;

# 신규 발견 섬의 지원불허 턴 수
# 0 에하면 발견 직후라도지원이허용됩니다
$H2::noAidTurn = 20;
### ---^--- ver1.10 ---^---

# 명령 입력 한계 수
# (게임이 시작된 뒤 변경하면 데이터 파일 호환성이 없어집니다.)
$H2::commandMax = 24;

### ---v--- ver1.15 ---v---
# 로컬 게시판 사용 여부(0:사용하지 않음,1:사용함)
$H2::useLbbs = 1;
### ---^--- ver1.15 ---^---

# 로컬 게시판 줄 수
# (게임이 시작된 뒤 변경하면 데이터 파일 호환성이 없어집니다.)
$H2::lbbsMax = 10;

# 섬 크기
# (변경할 수 없일 수도)
$H2::islandSize = 12;

# 다른 사람이 자금을 볼 수 없게 할지
# 0 보이지 않음
# 1 표시 가능
# 2 100의 위에서 반올림
$H2::hideMoneyMode = 1;

### ---v--- ver1.10 ---v---
# 각 섬의 턴 턴을 표시하다여부(0:표시하지 않음,1:표시함)
$H2::startTurnPrint = 0;
### ---^--- ver1.10 ---^---

### ---v--- ver1.15 ---v---
# JavaScript 개발 화면 사용 여부(0:사용하지 않음,1:사용함)
$H2::useJAVA = 1;
### ---^--- ver1.15 ---^---

# 비밀번호 암호화(0: 암호화하지 않음, 1: 암호화함)
my($cryptOn) = 1;

# 디버그 모드(1이면 '턴 진행' 버튼을 사용할 수 있음)
$H2::debug = 0;

#----------------------------------------
# 자금, 식량등의 설정 값와 단위
#----------------------------------------
# 초기 자금
$H2::initialMoney = 10000;

# 초기 식량
$H2::initialFood = 1000;

# 자금의 단위
$H2::unitMoney = '억 엔';

# 식량의 단위
$H2::unitFood = '00톤';

# 인구의 단위
$H2::unitPop = '00인';

# 면적의 단위
$H2::unitArea = '00만 평';

# 나무 수의 단위
$H2::unitTree = '00본';

# 목재 단위당 판매 수입
$H2::treeValue = 5;

# 이름 변경의 비용
$H2::costChangeName = 500;

# 인구 1단위당 식량 소비량
$H2::eatenFood = 0.2;

#----------------------------------------
# 기지의 경험치
#----------------------------------------
# 경험치의 최댓값
$H2::maxExpPoint = 200; # 단, 최대라도255까지

# 레벨의 최댓값
my($maxBaseLevel) = 5; # 미사일 기지
my($maxSBaseLevel) = 3; # 해저 기지

# 경험치가 몇 점이면 레벨업할지
my(@baseLevelUp, @sBaseLevelUp);
@baseLevelUp = (20, 60, 120, 200); # 미사일 기지
@sBaseLevelUp = (50, 200); # 해저 기지

#----------------------------------------
# 방위 시설의 자폭
#----------------------------------------
# 괴수에게 밟혔을 시 자폭하면 1, 아니면 0
$H2::dBaseAuto = 1;

#----------------------------------------
# 재해
#----------------------------------------
# 일반 재해 발생률(확률은0.1%단위)
$H2::disEarthquake = 3; # 지진
$H2::disTsunami = 10; # 쓰나미
$H2::disTyphoon = 15; # 태풍
$H2::disMeteo = 10; # 운석
$H2::disHugeMeteo = 3; # 거대운석
$H2::disEruption = 10; # 분화
$H2::disFire = 8; # 화재
$H2::disMaizo = 20; # 매장금
$H2::disOogui = 10; # 대식 대회
$H2::disTeiden = 15; # 정전

# 지반 침하
$H2::disFallBorder = 120; # 안정 전체한계의 면적(Hex 수)
$H2::disFalldown = 30; # 그 면적를 초과한 경우 확률

# 괴수
$H2::disMonsBorder1 = 500; # 인구 기준1(괴수레벨1)
$H2::disMonsBorder2 = 1000; # 인구 기준2(괴수레벨2)
$H2::disMonsBorder3 = 2500; # 인구 기준3(괴수레벨3)
### ---v--- ver1.10 ---v---
$H2::disMonsBorder4 = 3000; # 인구 기준4(괴수레벨4)
$H2::disMonsBorder5 = 4000; # 인구 기준5(괴수레벨5)
### ---^--- ver1.10 ---^---
$H2::disMonster = 10; # 단위 면적 주변의 출현율(0.01%단위)
### ---v--- ver1.10 ---v---
$H2::disFlower = 3; # 단위 면적 주변의 한 송이의 꽃의효과(0.01%단위)
### ---^--- ver1.10 ---^---

# 종류
$H2::monsterNumber = 10; ### 최대25까지(ver1.10)

# 각 기준에서 출현하는 괴수 번호의 최대값
$H2::monsterLevel1 = 2; # 산지라까지
$H2::monsterLevel2 = 4; # 다크이노라까지
$H2::monsterLevel3 = 7; # 킹 이노라까지
### ---v--- ver1.10 ---v---
$H2::monsterLevel4 = 8; # 은테나까지
$H2::monsterLevel5 = 9; # 은테나고스트까지(전체)
### ---^--- ver1.10 ---^---

# 이름
@H2::monsterName =
 (
 '메카이노라', # 0(인공)
 '이노라', # 1
 '산지라', # 2
 '레드이노라', # 3
 '다크이노라', # 4
 '이노라 고스트', # 5
 '고래', # 6
 '킹 이노라', # 7
 '는테나', # 8
 '는테나고스트' # 9
);

# 최소체력, 체력의 폭, 특수 능력, 경험치, 시체의 가격
@H2::monsterBHP = ( 2, 1, 1, 3, 2, 1, 4, 5, 2, 1);
@H2::monsterDHP = ( 0, 2, 2, 2, 2, 0, 2, 2, 2, 0);
@H2::monsterSpecial = ( 0, 0, 3, 0, 1, 2, 4, 0, 0, 2);
@H2::monsterExp = ( 5, 5, 7,12,15,35,20,30,40,50);
@H2::monsterValue = ( 0, 400, 500, 1000, 800, 1000, 1500, 2000, 3000, 4000);

# 특수 능력의 내용은,
# 0 특별히 없음
# 1 빠른 이동(최대 2걸음)
# 2족 보행이지만 속도는 알 수 없음(최대 몇 칸 이동하는지 불명)
# 3 홀 수 턴은 경화
# 4 짝 수 턴은 경화

### ---v--- ver1.10 ---v---
# 이동(0:일반 1:미사일 발사전)
@H2::monsterPreMove = ( 1, 1, 1, 1, 1, 1, 1, 1, 0, 0);
### ---^--- ver1.10 ---^---

# 포효(0:없음 1:있음)
@H2::monsterShout = ( 0, 0, 0, 1, 0, 0, 0, 1, 0, 0);

### ---v--- ver1.10 ---v---
# 바다등로의 이동(0:없음 1:있음)
@H2::monsterSeaMove = ( 0, 0, 0, 0, 0, 0, 0, 0, 0, 1);

# 보이지 않는 괴수(0:아니오 1:예)
@H2::monsterInvisible = ( 0, 0, 0, 0, 0, 0, 0, 0, 1, 1);
### ---^--- ver1.10 ---^---

# 이미지 파일
@H2::monsterImage =
 (
 'monster7.gif',
 'monster0.gif',
 'monster5.gif',
 'monster1.gif',
 'monster2.gif',
 'monster8.gif',
 'monster6.gif',
 'monster3.gif',
 'land1.gif',
 'land14.gif'
 );

# 이미지 파일그2(경화 중)
@H2::monsterImage2 =
 ('', '', 'monster4.gif', '', '', '', 'monster4.gif', '', '', '');


#----------------------------------------
# 유전
#----------------------------------------
# 유전 수입
$H2::oilMoney = 1000;

# 유전의 고갈확률
$H2::oilRatio = 40;

#----------------------------------------
# 기념비
#----------------------------------------
# 몇종류있는 지
$H2::monumentNumber = 3;

# 이름
@H2::monumentName =
 (
 '모노리스',
 '평화기념비',
 '전쟁이의 비석'
 );

# 이미지 파일
@H2::monumentImage =
 (
 'monument0.gif',
 'monument0.gif',
 'monument0.gif'
 );

#----------------------------------------
# 수상 관계
#----------------------------------------
# 턴잔을 몇 매 턴출습니까
$H2::turnPrizeUnit = 100;

# 상의 이름
$H2::prize[0] = '턴잔';
$H2::prize[1] = '번영상';
$H2::prize[2] = '초과 번영상';
$H2::prize[3] = '궁극번영상';
$H2::prize[4] = '평화상';
$H2::prize[5] = '초과 평화상';
$H2::prize[6] = '궁극평화상';
$H2::prize[7] = '재난상';
$H2::prize[8] = '초과 재난상';
$H2::prize[9] = '궁극재난상';

#----------------------------------------
# 화면 표시 관련
#----------------------------------------
# <BODY>태그의 옵션
my($htmlBody) = 'BGCOLOR="#c0c0c0"';

# 게임 제목 문자열
$H2::title = '괴수퇴치제도';

# 태그
# 제목문자
$H2::tagTitle_ = '<FONT SIZE=7 COLOR="#8888ff">';
$H2::_tagTitle = '</FONT>';

# H1태그용
$H2::tagHeader_ = '<FONT COLOR="#4444ff">';
$H2::_tagHeader = '</FONT>';

# 큰 글자
$H2::tagBig_ = '<FONT SIZE=6>';
$H2::_tagBig = '</FONT>';

# 섬 이름 등
$H2::tagName_ = '<FONT COLOR="#a06040"><B>';
$H2::_tagName = '</B></FONT>';

# 숨김 처리하지 않은 섬 이름
$H2::tagName2_ = '<FONT COLOR="#808080"><B>';
$H2::_tagName2 = '</B></FONT>';

# 순위 번호 등
$H2::tagNumber_ = '<FONT COLOR="#800000"><B>';
$H2::_tagNumber = '</B></FONT>';

# 순위표 머리글
$H2::tagTH_ = '<FONT COLOR="#C00000"><B>';
$H2::_tagTH = '</B></FONT>';

# 개발계획의 이름
$H2::tagComName_ = '<FONT COLOR="#d08000"><B>';
$H2::_tagComName = '</B></FONT>';

# 재해
$H2::tagDisaster_ = '<FONT COLOR="#ff0000"><B>';
$H2::_tagDisaster = '</B></FONT>';

# 로컬 게시판,(순 수나)관광객의 표시 문자
$H2::tagLbbsSS_ = '<FONT COLOR="#008000"><B>';
$H2::_tagLbbsSS = '</B></FONT>';

# 로컬 게시판, 섬주의 표시 문자
$H2::tagLbbsOW_ = '<FONT COLOR="#ff0000"><B>';
$H2::_tagLbbsOW = '</B></FONT>';

# 로컬 게시판, 타 섬주의 표시 문자
$H2::tagLbbsAOW_ = '<FONT COLOR="#0000ff"><B>';
$H2::_tagLbbsAOW = '</B></FONT>';

# 일반 문자색(BODY 태그의 옵션도 함께 변해야 합니다
$H2::normalColor = '#000000';

# 순위표, 세루의 속성
$H2::bgTitleCell = 'BGCOLOR="#ccffcc"'; # 순위표 머리글시
$H2::bgNumberCell = 'BGCOLOR="#ccffcc"'; # 순위표순위
$H2::bgNameCell = 'BGCOLOR="#ccffff"'; # 순위표 섬 이름
$H2::bgInfoCell = 'BGCOLOR="#ccffff"'; # 순위표 섬의 정보
$H2::bgCommentCell = 'BGCOLOR="#ccffcc"'; # 순위표코멘트란
$H2::bgInputCell = 'BGCOLOR="#ccffcc"'; # 개발계획양식
$H2::bgMapCell = 'BGCOLOR="#ccffcc"'; # 개발계획지도
$H2::bgCommandCell = 'BGCOLOR="#ccffcc"'; # 개발계획입력완료미계획

#----------------------------------------------------------------------
# 필요에 따라 설정하는 항목은 여기까지입니다
#----------------------------------------------------------------------

#----------------------------------------------------------------------
# 아래쪽 스크립트는 변경을 전제로 하지 않습니다.
# 그래도 문제는 없습니다.
# 명령 이름과 가격 등은 알아보기 쉽게 두는 편이 좋습니다.
#----------------------------------------------------------------------

#----------------------------------------------------------------------
# 각종 상수
#----------------------------------------------------------------------
# 이 파일
$H2::thisFile = "$baseDir/hako-main.cgi";

### ---v--- ver1.15 ---v---
# JavaScript 개발 화면용 CGI
$H2::javaFile = "$baseDir/hako-js.cgi";
$H2::javaMode = 0;
$H2::commandComary = '';
### ---^--- ver1.15 ---^---

# 지형 번호 ###최대255까지 가능
$H2::landSea = 0; # 바다
$H2::landWaste = 1; # 황무지
$H2::landPlains = 2; # 평지
$H2::landTown = 3; # 마을 계열
$H2::landForest = 4; # 숲
$H2::landFarm = 5; # 농장
$H2::landFactory = 6; # 공장
$H2::landBase = 7; # 미사일 기지
$H2::landDefence = 8; # 방위 시설
$H2::landMountain = 9; # 산
$H2::landMonster = 10; # 괴수
$H2::landSbase = 11; # 해저 기지
$H2::landOil = 12; # 해저 유전
$H2::landMonument = 13; # 기념비
$H2::landHaribote = 14; # 가짜 시설
$H2::landHoihoi = 15; # 방어 시설
### ---v--- ver1.10 ---v---
$H2::landMonsterS = 16; # 착탄 지점의 괴수
### ---^--- ver1.10 ---^---

# 명령
$H2::commandTotal = 31; # 명령 종류

# 계획 번호 설정
# 개간 계열
$H2::comPrepare = 01; # 개간
$H2::comPrepare2 = 02; # 땅고르기
$H2::comReclaim = 03; # 매립
$H2::comDestroy = 04; # 굴착
$H2::comSellTree = 05; # 벌채

# 작루계
$H2::comPlant = 11; # 나무심기
$H2::comFarm = 12; # 농장 건설
$H2::comFactory = 13; # 공장 건설
$H2::comMountain = 14; # 채굴장 건설
$H2::comBase = 15; # 미사일 기지건설
$H2::comDbase = 16; # 방위 시설 건설
$H2::comSbase = 17; # 해저 기지건설
$H2::comMonument = 18; # 기념비 건조
$H2::comHaribote = 19; # 가짜 기지건설
$H2::comHoihoi = 20; # 방어 시설 설치

# 발사계
$H2::comMissileNM = 31; # 미사일 발사
$H2::comMissilePP = 32; # PP 미사일 발사
$H2::comMissileST = 33; # ST 미사일 발사
$H2::comMissileLD = 34; # 육지 파괴탄환 발사
$H2::comSendMonster = 35; # 괴수 파견
$H2::comMissileTH = 36; # 토마호크발사
$H2::comMissileSPP = 37; # SPP 미사일 발사
$H2::comMissileSTI = 38; # 접속착탄환 발사

# 운영계
$H2::comDoNothing = 41; # 자금 조달
$H2::comSell = 42; # 식량 수출
$H2::comMoney = 43; # 자금지원
$H2::comFood = 44; # 식량지원
$H2::comPropaganda = 45; # 유치 활동
$H2::comGiveup = 46; # 섬 포기

# 자동 입력
$H2::comAutoPrepare = 61; # 전체 개간
$H2::comAutoPrepare2 = 62; # 전체땅고르기
$H2::comAutoDelete = 63; # 전체 명령 삭제

# 순서
@H2::comList =
 ($H2::comPrepare, $H2::comSell, $H2::comPrepare2, $H2::comReclaim, $H2::comDestroy,
 $H2::comSellTree, $H2::comPlant, $H2::comFarm, $H2::comFactory, $H2::comMountain,
 $H2::comBase, $H2::comDbase, $H2::comSbase, $H2::comMonument, $H2::comHaribote, $H2::comHoihoi,
 $H2::comMissileSTI, $H2::comMissileNM, $H2::comMissilePP,
## $H2::comMissileST,### ST 미사일폐지
 $H2::comMissileSPP, $H2::comMissileLD, $H2::comMissileTH, $H2::comSendMonster, $H2::comDoNothing,
 $H2::comMoney, $H2::comFood, $H2::comPropaganda, $H2::comGiveup,
 $H2::comAutoPrepare, $H2::comAutoPrepare2, $H2::comAutoDelete);

# 계획 이름과 비용
$H2::comName[$H2::comPrepare] = '개간';
$H2::comCost[$H2::comPrepare] = 5;
$H2::comName[$H2::comPrepare2] = '땅고르기';
$H2::comCost[$H2::comPrepare2] = 100;
$H2::comName[$H2::comReclaim] = '매립';
$H2::comCost[$H2::comReclaim] = 150;
$H2::comName[$H2::comDestroy] = '굴착';
$H2::comCost[$H2::comDestroy] = 200;
$H2::comName[$H2::comSellTree] = '벌채';
$H2::comCost[$H2::comSellTree] = 0;
$H2::comName[$H2::comPlant] = '나무심기';
$H2::comCost[$H2::comPlant] = 50;
$H2::comName[$H2::comFarm] = '농장 건설';
$H2::comCost[$H2::comFarm] = 20;
$H2::comName[$H2::comFactory] = '공장 건설';
$H2::comCost[$H2::comFactory] = 100;
$H2::comName[$H2::comMountain] = '채굴장 건설';
$H2::comCost[$H2::comMountain] = 300;
$H2::comName[$H2::comBase] = '미사일 기지건설';
$H2::comCost[$H2::comBase] = 300;
$H2::comName[$H2::comDbase] = '방위 시설 건설';
$H2::comCost[$H2::comDbase] = 800;
$H2::comName[$H2::comSbase] = '해저 기지건설';
$H2::comCost[$H2::comSbase] = 8000;
$H2::comName[$H2::comMonument] = '기념비 건조';
$H2::comCost[$H2::comMonument] = 9999;
$H2::comName[$H2::comHaribote] = '가짜 기지건설';
$H2::comCost[$H2::comHaribote] = 1;
$H2::comName[$H2::comHoihoi] = '방어 시설 설치';
$H2::comCost[$H2::comHoihoi] = 1000;
$H2::comName[$H2::comMissileNM] = '미사일 발사';
$H2::comCost[$H2::comMissileNM] = 20;
$H2::comName[$H2::comMissilePP] = 'PP 미사일 발사';
$H2::comCost[$H2::comMissilePP] = 50;
$H2::comName[$H2::comMissileST] = 'ST 미사일 발사';
$H2::comCost[$H2::comMissileST] = 50;
$H2::comName[$H2::comMissileTH] = '토마호크발사';
$H2::comCost[$H2::comMissileTH] = 600;
$H2::comName[$H2::comMissileSPP] = 'SPP 미사일 발사';
$H2::comCost[$H2::comMissileSPP] = 200;
$H2::comName[$H2::comMissileSTI] = '접속착탄환 발사';
$H2::comCost[$H2::comMissileSTI] = 20;
$H2::comName[$H2::comMissileLD] = '육지 파괴탄환 발사';
$H2::comCost[$H2::comMissileLD] = 100;
$H2::comName[$H2::comSendMonster] = '괴수 파견';
$H2::comCost[$H2::comSendMonster] = 3000;
$H2::comName[$H2::comDoNothing] = '자금 조달';
$H2::comCost[$H2::comDoNothing] = 0;
$H2::comName[$H2::comSell] = '식량 수출';
$H2::comCost[$H2::comSell] = -100;
$H2::comName[$H2::comMoney] = '자금지원';
$H2::comCost[$H2::comMoney] = 100;
$H2::comName[$H2::comFood] = '식량지원';
$H2::comCost[$H2::comFood] = -100;
$H2::comName[$H2::comPropaganda] = '유치 활동';
$H2::comCost[$H2::comPropaganda] = 1000;
$H2::comName[$H2::comGiveup] = '섬 포기';
$H2::comCost[$H2::comGiveup] = 0;
$H2::comName[$H2::comAutoPrepare] = '개간 자동 입력';
$H2::comCost[$H2::comAutoPrepare] = 0;
$H2::comName[$H2::comAutoPrepare2] = '땅고르기 자동 입력';
$H2::comCost[$H2::comAutoPrepare2] = 0;
$H2::comName[$H2::comAutoDelete] = '전체계획을 백지 철회';
$H2::comCost[$H2::comAutoDelete] = 0;

#----------------------------------------------------------------------
# 변수
#----------------------------------------------------------------------

# COOKIE
my($defaultID); # 섬 이름
my($defaultTarget); # 대상의 이름


# 섬의 좌표 수
$H2::pointNumber = $H2::islandSize * $H2::islandSize;

#----------------------------------------------------------------------
# 메인
#----------------------------------------------------------------------

# 문자 변환 라이브러리 로드

# '돌아가기'링크
$H2::tempBack = "<A HREF=\"$H2::thisFile\">${H2::tagBig_}맨 위로 돌아가기${H2::_tagBig}</A>";

# 잠금을 끼치기
if(!hakolock()) {
 # 잠금실패
 # 헤더출력
 tempHeader();

 # 잠금실패 메시지
 tempLockFail();

 # 푸터출력
 tempFooter();

 # 종료
 exit(0);
}

# 난수의 초기화
srand;

# COOKIE 읽기
cookieInput();

# CGI 읽기
cgiInput();

# 섬 데이터 읽기
if(readIslandsFile($H2::currentID) == 0) {
 unlock();
 tempHeader();
 tempNoDataFile();
 tempFooter();
 exit(0);
}

# 템플릿을 초기화
tempInitialize();

# COOKIE 출력
cookieOutput();

# 헤더출력
tempHeader();

### ---v--- ver1.10 ---v---
if(($H2::mainMode eq 'turn') && (($H2::lastTurn == 0)||($H2::islandTurn < $H2::lastTurn))) {
### ---^--- ver1.10 ---^---
 # 턴진행
 require('hako-turn.cgi');
 require('hako-top.cgi');
 turnMain();

} elsif($H2::mainMode eq 'new') {
 # 섬 신규 생성
 require('hako-turn.cgi');
 require('hako-map.cgi');
 newIslandMain();

} elsif($H2::mainMode eq 'print') {
 # 관광 모드
 require('hako-map.cgi');
 printIslandMain();

} elsif($H2::mainMode eq 'islandmap') {
 # JavaScript 모드 대상 섬 지도
 require('hako-map.cgi');
 require('hako-js.cgi');
 printIslandJava();

} elsif($H2::mainMode eq 'owner') {

 # 개발 모드
 require('hako-map.cgi');
 if($H2::javaMode) {
	require('hako-js.cgi');
	ownerJavaMain();
 } else {
	ownerMain();
 }

} elsif($H2::mainMode eq 'commandjava') {
 # JavaScript 모드 명령 입력
 require('hako-map.cgi');
 require('hako-js.cgi');
 commandJavaMain();

} elsif($H2::mainMode eq 'command') {
 # 명령 입력 모드
 require('hako-map.cgi');
 commandMain();

} elsif($H2::mainMode eq 'comment') {
 # 코멘트입력 모드
 require('hako-map.cgi');
 if($H2::javaMode) {
	require('hako-js.cgi');
	commentJavaMain();
 } else {
	commentMain();
 }

} elsif($H2::mainMode eq 'lbbs') {

 # 로컬 게시판 모드

 $H2::lbbsMyID = $defaultID;### 쿠키 id

 require('hako-map.cgi');
 localBbsMain();

} elsif($H2::mainMode eq 'change') {
 # 정보 변경 모드
 require('hako-turn.cgi');
 require('hako-top.cgi');
 changeMain();

} else {
 # 그 외에는 톱 페이지 모드
 require('hako-top.cgi');
 topPageMain();
}

# 푸터출력
tempFooter();

# 종료
exit(0);

# 명령을 앞으로 당기기
sub slideFront {
 my($command, $number) = @_;
 my($i);

 # 각각밀기
 splice(@$command, $number, 1);

 # 마지막에 자금 조달
 $command->[$H2::commandMax - 1] = {
	'kind' => $H2::comDoNothing,
	'target' => 0,
	'x' => 0,
	'y' => 0,
	'arg' => 0
	};
}

# 명령을 뒤로 밀기
sub slideBack {
 my($command, $number) = @_;
 my($i);

 # 각각밀기
 return if $number == $#$command;
 pop(@$command);
 splice(@$command, $number, 0, $command->[$number]);
}

#----------------------------------------------------------------------
# 섬 데이터 입출력
#----------------------------------------------------------------------

# 전체 섬 데이터 읽기
sub readIslandsFile {
 my($num) = @_; # 0이면 지형읽기 전
 # -1이면 전체 지형을 읽어들임
 # 번호가 지정되면 해당 섬의 지형만 읽어들임

 # 데이터 파일 열기
 if(!open(IN, "${H2::dirName}/hakojima.dat")) {
### ---v--- ver1.15 ---v---
	rename("${H2::dirName}/hakojima.tmp", "${H2::dirName}/hakojima.dat");
	if(!open(IN, "${H2::dirName}/hakojima.dat")) {
	 return 0;
	}
### ---^--- ver1.15 ---^---
 }

 # 각매개변수읽기
 $H2::islandTurn = int(<IN>); # 턴 수
 if($H2::islandTurn == 0) {
	return 0;
 }
 $H2::islandLastTime = int(<IN>); # 최종 갱신 시간
 if($H2::islandLastTime == 0) {
	return 0;
 }
 $H2::islandNumber = int(<IN>); # 섬의 총 수
 $H2::islandNextID = int(<IN>); # 다음에 할당할 ID

 # 턴 처리판정
 my($now) = time;
 if((($H2::debug == 1) &&
	($H2::mainMode eq 'H2::debugturn')) ||
 (($now - $H2::islandLastTime)>= $H2::unitTime)) {
	$H2::mainMode = 'turn';
	$num = -1; # 전체 섬읽어들임
 }

 # 섬읽기
 my($i);
 for($i = 0; $i < $H2::islandNumber; $i++) {
	 $H2::islands[$i] = readIsland($num);
	 $H2::idToNumber{$H2::islands[$i]->{'id'}} = $i;
 }

 # 파일을 닫기
 close(IN);

 return 1;
}

# 섬 하나 읽기
sub readIsland {
 my($num) = @_;
### ---v--- ver1.10 ---v---
 my($name, $id, $prize, $absent, $comment, $password, $money, $food,
 $pop, $area, $farm, $factory, $mountain, $score, $sturn);
 $name = <IN>; # 섬 이름
 chomp($name);
 if($name =~ s/,(.*),(.*)$//g) {###$name에서 $score, $sturn을 제거
	$score = int($1);
	$sturn = int($2);
 } elsif($name =~ s/,(.*)$//g) {###$name에서 $score를 제거
	$score = int($1);
	$sturn = 1;
 } else {
	$score = 0;
	$sturn = 1;
 }
### ---^--- ver1.10 ---^---
 $id = int(<IN>); # ID 번호
 $prize = <IN>; # 수상
 chomp($prize);
 $absent = int(<IN>); # 연속 자금 조달 수
 $comment = <IN>; # 코멘트
 chomp($comment);
 $password = <IN>; # 암호화 비밀번호
 chomp($password);
 $money = int(<IN>); # 자금
 $food = int(<IN>); # 식량
 $pop = int(<IN>); # 인구
 $area = int(<IN>); # 면적
 $farm = int(<IN>); # 농장
 $factory = int(<IN>); # 공장
 $mountain = int(<IN>); # 채굴장

 # H2::idToName 테이블로 저장
 $H2::idToName{$id} = $name;	#

 # 지형
 my(@land, @landValue, $line, @command, @lbbs);

 if(($num == -1) || ($num == $id)) {
### ---v--- ver1.15 ---v---
	if(!open(IIN, "${H2::dirName}/island.$id")) {
	 rename("${H2::dirName}/islandtmp.$id", "${H2::dirName}/island.$id");
	 if(!open(IIN, "${H2::dirName}/island.$id")) {
		exit(0);
	 }
	}
### ---^--- ver1.15 ---^---
	my($x, $y);
	for($y = 0; $y < $H2::islandSize; $y++) {
	 $line = <IIN>;
	 for($x = 0; $x < $H2::islandSize; $x++) {
		$line =~ s/^(..)(..)//;### 지형 번호도16진행정수이자리
		$land[$x][$y] = hex($1);
		$landValue[$x][$y] = hex($2);
	 }
	}

	# 명령
	my($i);
	for($i = 0; $i < $H2::commandMax; $i++) {
	 $line = <IIN>;
	 $line =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),([0-9]*)$/;
	 $command[$i] = {
		'kind' => int($1),
		'target' => int($2),
		'x' => int($3),
		'y' => int($4),
		'arg' => int($5)
		}
	}

	# 로컬 게시판
	for($i = 0; $i < $H2::lbbsMax; $i++) {
	 $line = <IIN>;
	 chomp($line);
	 $lbbs[$i] = $line;
	}

	close(IIN);
 }

 # 섬 형태로 반환
 return {
	 'name' => $name,
	 'score' => $score,
### ---v--- ver1.10 ---v---
	 'sturn' => $sturn,
### ---^--- ver1.10 ---^---
	 'id' => $id,
	 'prize' => $prize,
	 'absent' => $absent,
	 'comment' => $comment,
	 'password' => $password,
	 'money' => $money,
	 'food' => $food,
	 'pop' => $pop,
	 'area' => $area,
	 'farm' => $farm,
	 'factory' => $factory,
	 'mountain' => $mountain,
	 'land' => \@land,
	 'landValue' => \@landValue,
	 'command' => \@command,
	 'lbbs' => \@lbbs,
 };
}

# 전체 섬 데이터 쓰기
sub writeIslandsFile {
 my($num) = @_;

 # 파일을 열기
### ---v--- ver1.15 ---v---
 if(!open_r(OUT, ">${H2::dirName}/hakojima.tmp")) {
	# 잠시정적에종료
	return 1;
 }
### ---^--- ver1.15 ---^---

 # 각매개변수쓰기
 print OUT "$H2::islandTurn\n";
 print OUT "$H2::islandLastTime\n";
 print OUT "$H2::islandNumber\n";
 print OUT "$H2::islandNextID\n";

 # 섬의 쓰기
 my($i);
 for($i = 0; $i < $H2::islandNumber; $i++) {
	 writeIsland($H2::islands[$i], $num);
 }

 # 파일을 닫기
 close(OUT);

### ---v--- ver1.15 ---v---
 # 원래 이름으로
 rename("${H2::dirName}/hakojima.tmp", "${H2::dirName}/hakojima.dat");
### ---^--- ver1.15 ---^---
}

# 섬 하나 쓰기
sub writeIsland {
 my($island, $num) = @_;
### ---v--- ver1.10 ---v---
 my($score, $sturn);

 $score = int($island->{'score'});
 $sturn = int($island->{'sturn'});
 print OUT $island->{'name'}. ",$score,$sturn\n";
### ---^--- ver1.10 ---^---
 print OUT $island->{'id'}. "\n";
 print OUT $island->{'prize'}. "\n";
 print OUT $island->{'absent'}. "\n";
 print OUT $island->{'comment'}. "\n";
 print OUT $island->{'password'}. "\n";
 print OUT $island->{'money'}. "\n";
 print OUT $island->{'food'}. "\n";
 print OUT $island->{'pop'}. "\n";
 print OUT $island->{'area'}. "\n";
 print OUT $island->{'farm'}. "\n";
 print OUT $island->{'factory'}. "\n";
 print OUT $island->{'mountain'}. "\n";

 # 지형
 if(($num <= -1) || ($num == $island->{'id'})) {
### ---v--- ver1.15 ---v---
	if(!open_r(IOUT, ">${H2::dirName}/islandtmp.$island->{'id'}")) {
	 # 잠시정적에종료
	 return 1;
	}
### ---^--- ver1.15 ---^---

	my($land, $landValue);
	$land = $island->{'land'};
	$landValue = $island->{'landValue'};
	my($x, $y);
	for($y = 0; $y < $H2::islandSize; $y++) {
	 for($x = 0; $x < $H2::islandSize; $x++) {
		printf IOUT ("%02x%02x", $land->[$x][$y], $landValue->[$x][$y]);### 지형 번호도16진행정수이자리
	 }
	 print IOUT "\n";
	}

	# 명령
	my($command, $cur, $i);
	$command = $island->{'command'};
	for($i = 0; $i < $H2::commandMax; $i++) {
	 printf IOUT ("%d,%d,%d,%d,%d\n",
			 $command->[$i]->{'kind'},
			 $command->[$i]->{'target'},
			 $command->[$i]->{'x'},
			 $command->[$i]->{'y'},
			 $command->[$i]->{'arg'}
			 );
	}

	# 로컬 게시판
	my($lbbs);
	$lbbs = $island->{'lbbs'};
	for($i = 0; $i < $H2::lbbsMax; $i++) {
	 print IOUT $lbbs->[$i]. "\n";
	}
	close(IOUT);
### ---v--- ver1.15 ---v---
	rename("${H2::dirName}/islandtmp.$island->{'id'}", "${H2::dirName}/island.$island->{'id'}");
### ---^--- ver1.15 ---^---
 }
}

### ---v--- ver1.15 ---v---
# 리와 라이개설
sub open_r {
 my($retry) = 5;
 while (! open($_[0], $_[1])) {
 $retry--;
 if ($retry <= 0) {
 return 0;
 }
 select undef, undef, undef, 0.2;
 }
 return 1;
}
### ---^--- ver1.15 ---^---
#----------------------------------------------------------------------
# 입출력
#----------------------------------------------------------------------

# 표준 출력으로 출력
sub out {
 print STDOUT $_[0];
}

# 디버그 로그
sub H2::debugOut {
 open(DOUT, ">>debug.log");
 print DOUT ($_[0]);
 close(DOUT);
}

# CGI 읽기
sub cgiInput {
 my($line, $getLine);

 # 입력을 받아 UTF-8로 처리
 $line = <>;
 $line =~ tr/+/ /;
 $line =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
 $line = $line;
 $line =~ s/[\x00-\x1f\,]//g;

 # GET 값을 받음
 $getLine = $ENV{'QUERY_STRING'};

 # JavaScript 개발 화면 여부
 if(($line =~ /JAVAMODE=1/) || ($getLine =~ /JAVAMODE=1/)) {
	$H2::javaMode = 1;
 } else {
	$H2::javaMode = 0;
 }

 # 대상의 섬
 if($line =~ /CommandJavaButton([0-9]+)=/) {
	# JavaScript 모드 명령 전송버튼의 경우
	$H2::currentID = $1;
	$defaultID = $1;
 } elsif($line =~ /CommandButton([0-9]+)=/) {
	# 명령 전송버튼의 경우
	$H2::currentID = $1;
	$defaultID = $1;
 }

 if($line =~ /ISLANDNAME=([^\&]*)\&/){
	# 이름 지정의 경우
	$H2::currentName = cutColumn($1, 32);
 }

 if($line =~ /ISLANDID=([0-9]+)\&/){
	# 기타의 경우
	$H2::currentID = $1;
	$defaultID = $1;
 }

 # 비밀번호
 if($line =~ /OLDPASS=([^\&]*)\&/) {
	$H2::oldPassword = $1;
	$H2::defaultPassword = $1;
 }
 if($line =~ /PASSWORD=([^\&]*)\&/) {
	$H2::inputPassword = $1;
	$H2::defaultPassword = $1;
 }
 if($line =~ /PASSWORD2=([^\&]*)\&/) {
	$H2::inputPassword2 = $1;
 }

 # 메시지
 if($line =~ /MESSAGE=([^\&]*)\&/) {
	$H2::message = cutColumn($1, 80);
 }

 # 로컬 게시판
 if($line =~ /LBBSNAME=([^\&]*)\&/) {
	$H2::lbbsName = $1;
	$H2::defaultName = $1;
 }
 if($line =~ /LBBSMESSAGE=([^\&]*)\&/) {
	$H2::lbbsMessage = cutColumn($1, 80);
 }

 # JavaScript 모드 명령 배열
 if($line =~ /COMARY=([^\&]*)\&/) {
	$H2::commandComary = $1;
 }

 # main mode 의가져오기
 if($getLine =~ /IslandMap=([0-9]*)/) {
	$H2::mainMode = 'islandmap';
	$H2::currentID = $1;
 } elsif($line =~ /TurnButton/) {
	if($H2::debug == 1) {
	 $H2::mainMode = 'H2::debugturn';
	}
 } elsif($line =~ /OwnerButton/) {
	$H2::mainMode = 'owner';
 } elsif($getLine =~ /Sight=([0-9]*)/) {
	$H2::mainMode = 'print';
	$H2::currentID = $1;
 } elsif($line =~ /NewIslandButton/) {
	$H2::mainMode = 'new';
 } elsif($line =~ /LbbsButton(..)([0-9]*)/) {
	$H2::mainMode = 'lbbs';
	if($1 eq 'SS') {
	 # 관광객
	 $H2::lbbsMode = 0;
	} elsif($1 eq 'OW') {
	 # 섬주
	 $H2::lbbsMode = 1;
	} else {
	 # 삭제
	 $H2::lbbsMode = 2;
	}
	$H2::currentID = $2;

	# 삭제할 수 없으므로 번호를 가져옴
	$line =~ /NUMBER=([^\&]*)\&/;
	$H2::commandPlanNumber = $1;

 } elsif($line =~ /ChangeInfoButton/) {
	$H2::mainMode = 'change';
 } elsif($line =~ /MessageButton([0-9]*)/) {
	$H2::mainMode = 'comment';
	$H2::currentID = $1;
 } elsif($line =~ /CommandJavaButton/) {
	$H2::mainMode = 'commandjava';
 } elsif($line =~ /CommandButton/) {
	$H2::mainMode = 'command';

	# 명령 모드의 경우, 명령의 가져오기
	$line =~ /NUMBER=([^\&]*)\&/;
	$H2::commandPlanNumber = $1;
	$line =~ /COMMAND=([^\&]*)\&/;
	$H2::commandKind = $1;
	$H2::defaultKind = $1;
	$line =~ /AMOUNT=([^\&]*)\&/;
	$H2::commandArg = $1;
	$line =~ /TARGETID=([^\&]*)\&/;
	$H2::commandTarget = $1;
	$defaultTarget = $1;
	$line =~ /POINTX=([^\&]*)\&/;
	$H2::commandX = $1;
	$H2::defaultX = $1;
 $line =~ /POINTY=([^\&]*)\&/;
	$H2::commandY = $1;
	$H2::defaultY = $1;
	$line =~ /COMMANDMODE=(write|insert|delete)/;
	$H2::commandMode = $1;
 } else {
	$H2::mainMode = 'top';
 }

}


#cookie 입력
sub cookieInput {
 my($cookie);

 $cookie = $ENV{'HTTP_COOKIE'};

 if($cookie =~ /${H2::thisFile}OWNISLANDID=\(([^\)]*)\)/) {
	$defaultID = $1;
 }
 if($cookie =~ /${H2::thisFile}OWNISLANDPASSWORD=\(([^\)]*)\)/) {
	$H2::defaultPassword = $1;
 }
 if($cookie =~ /${H2::thisFile}TARGETISLANDID=\(([^\)]*)\)/) {
	$defaultTarget = $1;
 }
 if($cookie =~ /${H2::thisFile}LBBSNAME=\(([^\)]*)\)/) {
	$H2::defaultName = $1;
 }
 if($cookie =~ /${H2::thisFile}POINTX=\(([^\)]*)\)/) {
	$H2::defaultX = $1;
 }
 if($cookie =~ /${H2::thisFile}POINTY=\(([^\)]*)\)/) {
	$H2::defaultY = $1;
 }
 if($cookie =~ /${H2::thisFile}KIND=\(([^\)]*)\)/) {
	$H2::defaultKind = $1;
 }

}

#cookie 출력
sub cookieOutput {
 my($cookie, $info);

 # 삭제 가능 기한 설정
 my($sec, $min, $hour, $date, $mon, $year, $day, $yday, $dummy) =
	gmtime(time + 30 * 86400); # 현재 + 30일

 $year += 1900;
 # 2자리화
 if ($date < 10) { $date = "0$date"; }
 if ($hour < 10) { $hour = "0$hour"; }
 if ($min < 10) { $min = "0$min"; }
 if ($sec < 10) { $sec = "0$sec"; }

 # 요일일을 문자에
 $day = ("Sunday", "Monday", "Tuesday", "Wednesday",
	 "Thursday", "Friday", "Saturday")[$day];

 # 월을 문자에
 $mon = ("Jan", "Feb", "Mar", "Apr", "May", "Jun",
	 "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")[$mon];

 # 경로와 기간 설정
 $info = "; expires=$day, $date\-$mon\-$year $hour:$min:$sec GMT\n";
 $cookie = '';

 if(($H2::currentID) && ($H2::mainMode eq 'owner')){
	$cookie.= "Set-Cookie: ${H2::thisFile}OWNISLANDID=($H2::currentID) $info";
 }
 if($H2::inputPassword) {
	$cookie.= "Set-Cookie: ${H2::thisFile}OWNISLANDPASSWORD=($H2::inputPassword) $info";
 }
 if($H2::commandTarget) {
	$cookie.= "Set-Cookie: ${H2::thisFile}TARGETISLANDID=($H2::commandTarget) $info";
 }
 if($H2::lbbsName) {
	$cookie.= "Set-Cookie: ${H2::thisFile}LBBSNAME=($H2::lbbsName) $info";
 }
 if($H2::commandX) {
	$cookie.= "Set-Cookie: ${H2::thisFile}POINTX=($H2::commandX) $info";
 }
 if($H2::commandY) {
	$cookie.= "Set-Cookie: ${H2::thisFile}POINTY=($H2::commandY) $info";
 }
 if($H2::commandKind) {
	# 자동 입력 이외
	$cookie.= "Set-Cookie: ${H2::thisFile}KIND=($H2::commandKind) $info";
 }

 out($cookie);
}

#----------------------------------------------------------------------
# 유티리티
#----------------------------------------------------------------------
sub hakolock {
 if($lockMode == 1) {
	# directory 방식 잠금
	return hakolock1();

 } elsif($lockMode == 2) {
	# flock 방식 잠금
	return hakolock2();
 } elsif($lockMode == 3) {
	# symlink 방식 잠금
	return hakolock3();
 } else {
	# 일반 파일 방식 잠금
	return hakolock4();
 }
}

sub hakolock1 {
 # 잠금을 시도
 if(mkdir('hakojimalock', $H2::dirMode)) {
	# 성공
	return 1;
 } else {
	# 실패
	my($b) = (stat('hakojimalock'))[9];
	if(($b> 0) && ((time() - $b)> $unlockTime)) {
	 # 강제 해제
	 unlock();

	 # 헤더출력
	 tempHeader();

	 # 강제 해제 메시지
	 tempUnlock();

	 # 푸터출력
	 tempFooter();

	 # 종료
	 exit(0);
	}
	return 0;
 }
}

sub hakolock2 {
### ---v--- ver1.15 ---v---
 open(LOCKID, '>>hakojimalockflock');
### ---^--- ver1.15 ---^---
 if(flock(LOCKID, 2)) {
	# 성공
	return 1;
 } else {
	# 실패
	return 0;
 }
}

sub hakolock3 {
 # 잠금을 시도
 if(symlink('hakojimalockdummy', 'hakojimalock')) {
	# 성공
	return 1;
 } else {
	# 실패
### ---v--- ver1.15 ---v---
	my($b) = (lstat('hakojimalock'))[9];
### ---^--- ver1.15 ---^---
	if(($b> 0) && ((time() - $b)> $unlockTime)) {
	 # 강제 해제
	 unlock();

	 # 헤더출력
	 tempHeader();

	 # 강제 해제 메시지
	 tempUnlock();

	 # 푸터출력
	 tempFooter();

	 # 종료
	 exit(0);
	}
	return 0;
 }
}

sub hakolock4 {
 # 잠금을 시도
 if(unlink('key-free')) {
	# 성공
	open(OUT, '>key-locked');
	print OUT time;
	close(OUT);
	return 1;
 } else {
	# 잠금 시간 확인
	if(!open(IN, 'key-locked')) {
	 return 0;
	}

	my($t);
	$t = <IN>;
	close(IN);
### ---v--- ver1.15 ---v---
	if(($t != 0) && (($t + $unlockTime) < time)) {
	 # 강제 해제
### ---^--- ver1.15 ---^---
	 unlock();

	 # 헤더출력
	 tempHeader();

	 # 강제 해제 메시지
	 tempUnlock();

	 # 푸터출력
	 tempFooter();

	 # 종료
	 exit(0);
	}
	return 0;
 }
}

# 잠금을 해제
sub unlock {
 if($lockMode == 1) {
	# directory 방식 잠금
	rmdir('hakojimalock');

 } elsif($lockMode == 2) {
	# flock 방식 잠금
###	unlink('hakojimalockflock');
	close(LOCKID);

 } elsif($lockMode == 3) {
	# symlink 방식 잠금
	unlink('hakojimalock');
 } else {
	# 일반 파일 방식 잠금
	my($i);
	$i = rename('key-locked', 'key-free');
 }
}

# 작은 쪽을 반환
sub min {
 return ($_[0] < $_[1]) ? $_[0] : $_[1];
}

# 비밀번호엔코드
sub encode {
 if($cryptOn == 1) {
	return crypt($_[0], 'h2');
 } else {
	return $_[0];
 }
}

# 비밀번호 확인
sub checkPassword {
 my($p1, $p2) = @_;

 # null 확인
 if($p2 eq '') {
	return 0;
 }

 # 마스터 비밀번호 확인
 if($masterPassword eq $p2) {
	return 1;
 }

 # 본래의 확인
 if($p1 eq encode($p2)) {
	return 1;
 }

 return 0;
}

# 1000억단위원형메루틴
sub aboutMoney {
 my($m) = @_;
 if($m < 500) {
	return "추정500${H2::unitMoney}미만";
 } else {
	$m = int(($m + 500) / 1000);
	return "추정${m}000${H2::unitMoney}";
 }
}

# 이스케이프문자의 처리
sub htmlEscape {
 my($s) = @_;
 $s =~ s/&/&amp;/g;
 $s =~ s/</&lt;/g;
 $s =~ s/>/&gt;/g;
 $s =~ s/\"/&quot;/g; #"
 return $s;
}

# 80자리에절리갖춤에
sub cutColumn {
 my($s, $c) = @_;
 if(length($s) <= $c) {
	return $s;
 } else {
	# 합계80자리가 됨까지절리 처리
	my($ss) = '';
	my($count) = 0;
	while($count < $c) {
	 $s =~ s/(^[\x80-\xFF][\x80-\xFF])|(^[\x00-\x7F])//;
	 if($1) {
		$ss.= $1;
		$count ++;
	 } else {
		$ss.= $2;
	 }
	 $count ++;
	}
	return $ss;
 }
}

# 섬 이름으로 번호를 얻음(ID가 아니라 번호)
sub nameToNumber {
 my($name) = @_;

 # 전체 섬에서 찾기
 my($i);
 for($i = 0; $i < $H2::islandNumber; $i++) {
	if($H2::islands[$i]->{'name'} eq $name) {
	 return $i;
	}
 }

 # 찾을 수 없었던 경우
 return -1;
}

# 괴수의 정보
### ---v--- ver1.10 ---v--- 원본에 복귀했습니다
sub monsterSpec {
 my($lv) = @_;

 # 종류
 my($kind) = int($lv / 10);

 # 이름
 my($name);
 $name = $H2::monsterName[$kind];

 # 체력
 my($hp) = $lv - ($kind * 10);

 return ($kind, $name, $hp);
}
### ---^--- ver1.10 ---^---

# 경험치에서 레벨을 산출
sub expToLevel {
 my($kind, $exp) = @_;
 my($i);
 if($kind == $H2::landBase) {
	# 미사일 기지
	for($i = $maxBaseLevel; $i> 1; $i--) {
	 if($exp>= $baseLevelUp[$i - 2]) {
		return $i;
	 }
	}
	return 1;
 } else {
	# 해저 기지
	for($i = $maxSBaseLevel; $i> 1; $i--) {
	 if($exp>= $sBaseLevelUp[$i - 2]) {
		return $i;
	 }
	}
	return 1;
 }

}

# (0,0)에서(size - 1, size - 1)까지의 숫자가한 번씩 나오도록
# (@H2::rpx, @H2::rpy)을 설정
sub makeRandomPointArray {
 # 초기 값
 my($y);
 @H2::rpx = (0..$H2::islandSize-1) x $H2::islandSize;
 for($y = 0; $y < $H2::islandSize; $y++) {
	push(@H2::rpy, ($y) x $H2::islandSize);
 }

 # 셔터 전체
 my ($i);
 for ($i = $H2::pointNumber; --$i; ) {
	my($j) = int(rand($i+1));
	if($i == $j) { next; }
	@H2::rpx[$i,$j] = @H2::rpx[$j,$i];
	@H2::rpy[$i,$j] = @H2::rpy[$j,$i];
 }
}

# 0에서(n - 1)의 난수
sub random {
 return int(rand(1) * $_[0]);
}

#----------------------------------------------------------------------
# 로그 표시
#----------------------------------------------------------------------
# 파일 번호를 지정해 로그 표시
sub logFilePrint {
 my($fileNumber, $id, $mode) = @_;
 open(LIN, "${H2::dirName}/hakojima.log$_[0]");
 my($line, $m, $turn, $id1, $id2, $message);
 while($line = <LIN>) {
	$line =~ /^([0-9]*),([0-9]*),([0-9]*),([0-9]*),(.*)$/;
	($m, $turn, $id1, $id2, $message) = ($1, $2, $3, $4, $5);

	# 기밀관계
	if($m == 1) {
	 if(($mode == 0) || ($id1 != $id)) {
		# 기밀 표시 권한 없음
		next;
	 }
	 $m = '<B>(기밀)</B>';
	} else {
	 $m = '';
	}

	# 정확히 표시할지
	if($id != 0) {
	 if(($id != $id1) &&
	 ($id != $id2)) {
		next;
	 }
	}

	# 표시
	out("<NOBR>${H2::tagNumber_}턴$turn$m${H2::_tagNumber}:$message</NOBR><BR>\n");
 }
 close(LIN);
}

#----------------------------------------------------------------------
# 템플릿
#----------------------------------------------------------------------
# 초기화
sub tempInitialize {
 # 섬 선택(기본값은 자신)
 $H2::islandList = getIslandList($defaultID);
 $H2::targetList = getIslandList($defaultTarget);
}

# 섬 데이터 드롭다운 메뉴용
sub getIslandList {
 my($select) = @_;
 my($list, $name, $id, $s, $i);

 #섬 목록의 메뉴
 $list = '';
 for($i = 0; $i < $H2::islandNumber; $i++) {
	$name = $H2::islands[$i]->{'name'};
	$id = $H2::islands[$i]->{'id'};
	if($id eq $select) {
	 $s = 'SELECTED';
	} else {
	 $s = '';
	}
	$list.=
	 "<OPTION VALUE=\"$id\" $s>${name} 섬\n";
 }
 return $list;
}


# 헤더
sub tempHeader {
 out(<<END);
Content-type: text/html; charset=UTF-8

<HTML>
<HEAD><META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
<TITLE>
$H2::title
</TITLE>
<BASE HREF="$imageDir/">
</HEAD>
<BODY $htmlBody>
<A HREF="http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html">모형정원 제도 스크립트 배포처</A>
<center>
[ <A HREF="$manpage">사양서</A> ]
[ <A HREF="$bbs">게시판</A> ]
[ <A HREF="$toppage">홈페이지</A> ]
</center><HR>
END
}

# 푸터
sub tempFooter {
 out(<<END);
<HR>
<p><center>
[ <A HREF="$manpage">사양서</A> ]
[ <A HREF="$bbs">게시판</A> ]
[ <A HREF="$toppage">홈페이지</A> ]
</center>
<DIV align=right><A HREF="http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html">본가·모형정원 제도의 페이지</A></DIV>
<DIV align=center>관리자:<A HREF="mailto:$email">$adminName</A></DIV><br>
</BODY>
</HTML>
END
}

# 잠금실패
sub tempLockFail {
 # 제목
 out(<<END);
${H2::tagBig_}동시접속오류입니다.<BR>
브라우저의'돌아가기'버튼을 누름시,<BR>
잠시 기다렸다가 다시오시 도시하세요.${H2::_tagBig}$H2::tempBack
END
}

# 강제 해제
sub tempUnlock {
 # 제목
 out(<<END);
${H2::tagBig_}지난 접속이 비정상 종료된 것 같습니다.<BR>
잠금을 강제 해제했습니다.${H2::_tagBig}$H2::tempBack
END
}

# hakojima.dat 이 없음
sub tempNoDataFile {
 out(<<END);
${H2::tagBig_}데이터 파일을 열 수 없습니다.${H2::_tagBig}$H2::tempBack
END
}

# 비밀번호 오류
sub tempWrongPassword {
 out(<<END);
${H2::tagBig_} 비밀번호가 다릅니다.${H2::_tagBig}$H2::tempBack
END
}

# 무언가문제발생
sub tempProblem {
 out(<<END);
${H2::tagBig_}문제발생, 일단복귀해 주세요.${H2::_tagBig}$H2::tempBack
END
}
