#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}
#----------------------------------------------------------------------
# 모형정원 제도 ver2.20
# 지도 모드 모듈
# 사용 조건과 사용 방법은 hako-readme.txt 파일을 참조해 주세요
#
# 모형정원 제도의 페이지: http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html
#----------------------------------------------------------------------
# 괴수퇴치제도 ver1.15
# 지도 모드 모듈(v1.15)
# Arranged by 차차마루
# 사용 조건등은,readme.txt 파일을 참조
# 배포페이지: http://www.geocities.co.jp/SiliconValley-Bay/2566/
#
# [이력]
# v1.00 2000/03/12 처음판
# v1.01 2000/04/29 로컬 게시판의 순 수 관광객판정의 버그 수정
# 2000/05/07 일반배포시작
# v1.10 2000/06/11
# v1.15 2000/07/01
#----------------------------------------------------------------------

package H2;

#----------------------------------------------------------------------
# 관광 모드
#----------------------------------------------------------------------
# 메인
sub printIslandMain {
 # 개방
 unlock();

 # id에서 섬 번호를 가져옴
 $H2::currentNumber = $H2::idToNumber{$H2::currentID};

 # 왠지그 섬이 없는 경우
 if($H2::currentNumber eq '') {
	tempProblem();
	return;
 }

 # 이름 가져오기
 $H2::currentName = $H2::islands[$H2::currentNumber]->{'name'};

 # 관광 화면
 tempPrintIslandHead(); # 수 있도록 말로!!
 islandInfo(); # 섬의 정보
 islandMap(0); # 섬 지도, 관광 모드

 # ○○섬 로컬 게시판
### ---v--- ver1.15 ---v---
 if($H2::useLbbs) {
	tempLbbsHead(); # 로컬 게시판
	tempLbbsInput(); # 작성 양식
	tempLbbsContents(); # 게시판내용
 }
### ---^--- ver1.15 ---^---

 # 최근 상황
 tempRecent(0);
}

#----------------------------------------------------------------------
# 개발 모드
#----------------------------------------------------------------------
# 메인
sub ownerMain {
 # 개방
 unlock();

 # 모드를 명시
 $H2::mainMode = 'owner';

 # id에서 섬을 가져옴
 $H2::currentNumber = $H2::idToNumber{$H2::currentID};
 my($island) = $H2::islands[$H2::currentNumber];
 $H2::currentName = $island->{'name'};

 # 비밀번호
 if(!checkPassword($island->{'password'},$H2::inputPassword)) {
	# password 오류
	tempWrongPassword();
	return;
 }

 # 개발 화면
 tempOwner(); # '개발계획'

 # ○○섬 로컬 게시판
### ---v--- ver1.15 ---v---
 if($H2::useLbbs) {
	tempLbbsHead(); # 로컬 게시판
	tempLbbsInputOW(); # 작성 양식
	tempLbbsContents(); # 게시판내용
 }
### ---^--- ver1.15 ---^---

 # 최근 상황
 tempRecent(1);
}

#----------------------------------------------------------------------
# 명령 모드
#----------------------------------------------------------------------
# 메인
sub commandMain {
 # id에서 섬을 가져옴
 $H2::currentNumber = $H2::idToNumber{$H2::currentID};
 my($island) = $H2::islands[$H2::currentNumber];
 $H2::currentName = $island->{'name'};

 # 비밀번호
 if(!checkPassword($island->{'password'},$H2::inputPassword)) {
	# password 오류
	unlock();
	tempWrongPassword();
	return;
 }

 # 모드에서 분기
 my($command) = $island->{'command'};

 if($H2::commandMode eq 'delete') {
	slideFront($command, $H2::commandPlanNumber);
	tempCommandDelete();
 } elsif(($H2::commandKind == $H2::comAutoPrepare) ||
	 ($H2::commandKind == $H2::comAutoPrepare2)) {
	# 전체 개간, 전체땅고르기
	# 좌표배열을 만들기
	makeRandomPointArray();
	my($land) = $island->{'land'};

	# 자동 입력 시작 위치 보정: 지정이 없으면 기존 명령 아래 첫 빈 슬롯부터 추가
	if($H2::commandPlanNumber !~ /^[0-9]+$/) {
		my($emptyNo) = $H2::commandMax - 1;
		for(my $pi = 0; $pi < $H2::commandMax; $pi++) {
			if($command->[$pi]->{'kind'} == $H2::comDoNothing) { $emptyNo = $pi; last; }
		}
		$H2::commandPlanNumber = $emptyNo;
	}

	# 명령 종류결정
	my($kind) = $H2::comPrepare;
	if($H2::commandKind == $H2::comAutoPrepare2) {
	 $kind = $H2::comPrepare2;
	}

	my($i) = 0;
	my($j) = 0;
	while(($j < $H2::pointNumber) && ($i < $H2::commandMax)) {
	 my($x) = $H2::rpx[$j];
	 my($y) = $H2::rpy[$j];
	 if($land->[$x][$y] == $H2::landWaste) {
		slideBack($command, $H2::commandPlanNumber);
		$command->[$H2::commandPlanNumber] = {
		 'kind' => $kind,
		 'target' => 0,
		 'x' => $x,
		 'y' => $y,
		 'arg' => 0
		 };
		$i++;
	 }
	 $j++;
	}
	tempCommandAdd();
 } elsif($H2::commandKind == $H2::comAutoDelete) {
	# 전체 삭제
	my($i);
	for($i = 0; $i < $H2::commandMax; $i++) {
	 slideFront($command, $H2::commandPlanNumber);
	}
	tempCommandDelete();
 } else {
	if($H2::commandMode eq 'insert') {
	 slideBack($command, $H2::commandPlanNumber);
	}
	tempCommandAdd();
	# 명령을 등록
	$command->[$H2::commandPlanNumber] = {
	 'kind' => $H2::commandKind,
	 'target' => $H2::commandTarget,
	 'x' => $H2::commandX,
	 'y' => $H2::commandY,
	 'arg' => $H2::commandArg
	 };
 }

 # 데이터 쓰기
 writeIslandsFile($H2::currentID);

 # owner mode 로
 ownerMain();

}

#----------------------------------------------------------------------
# 코멘트입력 모드
#----------------------------------------------------------------------
# 메인
sub commentMain {
 # id에서 섬을 가져옴
 $H2::currentNumber = $H2::idToNumber{$H2::currentID};
 my($island) = $H2::islands[$H2::currentNumber];
 $H2::currentName = $island->{'name'};

 # 비밀번호
 if(!checkPassword($island->{'password'},$H2::inputPassword)) {
	# password 오류
	unlock();
	tempWrongPassword();
	return;
 }

 # 메시지를 갱신
 # 동시에리도와 호스트(가져오지 못한 경우에는 IP 주소)을 갱신
 my($host) = $ENV{'REMOTE_HOST'};
 my($addr) = $ENV{'REMOTE_ADDR'};
 if ($host eq '') { $host = $addr; }
 if ($host eq $addr) { $host = gethostbyaddr(pack('C4',split(/\./,$host)),2) || $addr; }
 $island->{'comment'} = htmlEscape($H2::message)."\t". $host;### 탭 구분

 # 데이터 쓰기
 writeIslandsFile($H2::currentID);

 # 코멘트갱신 메시지
 tempComment();

 # owner mode 로
 ownerMain();
}

#----------------------------------------------------------------------
# 로컬 게시판 모드
#----------------------------------------------------------------------
# 메인

sub localBbsMain {
 # id에서 섬 번호를 가져옴
 $H2::currentNumber = $H2::idToNumber{$H2::currentID};
 my($island) = $H2::islands[$H2::currentNumber];

 # 쿠키 id에서 섬을 가져옴
 my($myisland) = $H2::islands[$H2::idToNumber{$H2::lbbsMyID}];


 # 왠지그 섬이 없는 경우
 if($H2::currentNumber eq '') {
	unlock();
	tempProblem();
	return;
 }

 # 삭제 모드가 아니고 이름이나 메시지가 없는 경우
 if($H2::lbbsMode != 2) {
	if(($H2::lbbsName eq '') || ($H2::lbbsMessage eq '')) {### bug fixed
	 unlock();
	 tempLbbsNoMessage();
	 return;
	}
 }

 # 관광객 모드가 아닐 시는 비밀번호 확인
 if($H2::lbbsMode != 0) {
	if(!checkPassword($island->{'password'},$H2::inputPassword)) {
	 # password 오류
	 unlock();
	 tempWrongPassword();
	 return;
	}
 }
 # 관광객 모드의 시는 쿠키 비밀번호가 있다면 비밀번호 확인
 else {
	if(($H2::defaultPassword eq '') || (!checkPassword($myisland->{'password'},$H2::defaultPassword))) {
	 # password 없고, 또는,password 오류이므로 순 수 관광객
	 $H2::lbbsMode = -1;
	}
 }

 my($lbbs);
 $lbbs = $island->{'lbbs'};

 # 모드에서 분기
 if($H2::lbbsMode == 2) {
	# 삭제 모드
	# 메시지를 앞으로 당기기
	slideBackLbbsMessage($lbbs, $H2::commandPlanNumber);
	tempLbbsDelete();
 } else {
	# 기장 모드
	# 메시지를 뒤에밀기
	slideLbbsMessage($lbbs);

	# 메시지 쓰기
	my($message);
	if($H2::lbbsMode == 0) {### 타 섬주
	 $message = '2';
	} elsif($H2::lbbsMode == -1) {### 순 수 관광객
	 $message = '0';
	} else {
	 $message = '1';
	}
	$H2::lbbsName = "$H2::islandTurn:". htmlEscape($H2::lbbsName);
	$H2::lbbsMessage = htmlEscape($H2::lbbsMessage);

	if($message eq '2') {
	 # 타 섬주의 경우 메시지에 섬 이름을 탭 구분으로 추가
	 $lbbs->[0] = "$message>$H2::lbbsName>$H2::lbbsMessage\t$myisland->{'name'} 섬";
	} else {
	 $lbbs->[0] = "$message>$H2::lbbsName>$H2::lbbsMessage";
	}

	tempLbbsAdd();
 }

 # 데이터 쓰기
 writeIslandsFile($H2::currentID);

 # 원래의 모드로
 if($H2::lbbsMode < 1) {
	printIslandMain();
 } else {
	ownerMain();
 }
}

# 로컬 게시판의 메시지를 하나뒤에밀기
sub slideLbbsMessage {
 my($lbbs) = @_;
 my($i);
# pop(@$lbbs);
# push(@$lbbs, $lbbs->[0]);
 pop(@$lbbs);
 unshift(@$lbbs, $lbbs->[0]);
}

# 로컬 게시판의 메시지를 하나앞으로 당기기
sub slideBackLbbsMessage {
 my($lbbs, $number) = @_;
 my($i);
 splice(@$lbbs, $number, 1);
 $lbbs->[$H2::lbbsMax - 1] = '0>>';
}

#----------------------------------------------------------------------
# 섬 지도
#----------------------------------------------------------------------

# 정보의 표시
sub islandInfo {
 my($island) = $H2::islands[$H2::currentNumber];
 # 정보 표시
 my($rank) = $H2::currentNumber + 1;
 my($farm) = $island->{'farm'};
 my($factory) = $island->{'factory'};
 my($mountain) = $island->{'mountain'};
 $farm = ($farm == 0) ? "보유하지 않음" : "${farm}0$H2::unitPop";
 $factory = ($factory == 0) ? "보유하지 않음" : "${factory}0$H2::unitPop";
 $mountain = ($mountain == 0) ? "보유하지 않음" : "${mountain}0$H2::unitPop";

 my($mStr1) = '';
 my($mStr2) = '';
 if(($H2::hideMoneyMode == 1) || ($H2::mainMode eq 'owner')) {
	# 무조건또는 owner 모드
	$mStr1 = "<TH $H2::bgTitleCell nowrap=nowrap><NOBR>${H2::tagTH_} 자금${H2::_tagTH}</NOBR></TH>";
	$mStr2 = "<TD $H2::bgInfoCell align=right nowrap=nowrap><NOBR>$island->{'money'}$H2::unitMoney</NOBR></TD>";
 } elsif($H2::hideMoneyMode == 2) {
	my($mTmp) = aboutMoney($island->{'money'});

	# 1000억단위 모드
	$mStr1 = "<TH $H2::bgTitleCell nowrap=nowrap><NOBR>${H2::tagTH_} 자금${H2::_tagTH}</NOBR></TH>";
	$mStr2 = "<TD $H2::bgInfoCell align=right nowrap=nowrap><NOBR>$mTmp</NOBR></TD>";
 }
 out(<<END);
<CENTER>
<TABLE BORDER>
<TR>
<TH $H2::bgTitleCell nowrap=nowrap><NOBR>${H2::tagTH_}순위${H2::_tagTH}</NOBR></TH>
<TH $H2::bgTitleCell nowrap=nowrap><NOBR>${H2::tagTH_}포인트${H2::_tagTH}</NOBR></TH>
<TH $H2::bgTitleCell nowrap=nowrap><NOBR>${H2::tagTH_}인구${H2::_tagTH}</NOBR></TH>
$mStr1
<TH $H2::bgTitleCell nowrap=nowrap><NOBR>${H2::tagTH_}식량${H2::_tagTH}</NOBR></TH>
<TH $H2::bgTitleCell nowrap=nowrap><NOBR>${H2::tagTH_}면적${H2::_tagTH}</NOBR></TH>
<TH $H2::bgTitleCell nowrap=nowrap><NOBR>${H2::tagTH_}농장규모${H2::_tagTH}</NOBR></TH>
<TH $H2::bgTitleCell nowrap=nowrap><NOBR>${H2::tagTH_}공장규모${H2::_tagTH}</NOBR></TH>
<TH $H2::bgTitleCell nowrap=nowrap><NOBR>${H2::tagTH_}채굴장규모${H2::_tagTH}</NOBR></TH>
</TR>
<TR>
<TD $H2::bgNumberCell align=middle nowrap=nowrap><NOBR>${H2::tagNumber_}$rank${H2::_tagNumber}</NOBR></TD>
<TD $H2::bgInfoCell align=right nowrap=nowrap><NOBR>$island->{'score'}점</NOBR></TD>
<TD $H2::bgInfoCell align=right nowrap=nowrap><NOBR>$island->{'pop'}$H2::unitPop</NOBR></TD>
$mStr2
<TD $H2::bgInfoCell align=right nowrap=nowrap><NOBR>$island->{'food'}$H2::unitFood</NOBR></TD>
<TD $H2::bgInfoCell align=right nowrap=nowrap><NOBR>$island->{'area'}$H2::unitArea</NOBR></TD>
<TD $H2::bgInfoCell align=right nowrap=nowrap><NOBR>${farm}</NOBR></TD>
<TD $H2::bgInfoCell align=right nowrap=nowrap><NOBR>${factory}</NOBR></TD>
<TD $H2::bgInfoCell align=right nowrap=nowrap><NOBR>${mountain}</NOBR></TD>
</TR>
</TABLE></CENTER>
END
}

# 지도 표시
# 인 수가1이면, 미사일 기지등을 그대로 표시
sub islandMap {
 my($mode) = @_;
 my($island);
 $island = $H2::islands[$H2::currentNumber];

 out(<<END);
<CENTER><TABLE BORDER><TR><TD>
END
 # 지형, 지형 값을 가져옴
 my($land) = $island->{'land'};
 my($landValue) = $island->{'landValue'};
 my($l, $lv);

 # 명령 가져오기
 my($command) = $island->{'command'};
 my($com, @comStr, $i);
 if($H2::mainMode eq 'owner') {
	for($i = 0; $i < $H2::commandMax; $i++) {
	 my($j) = $i + 1;
	 $com = $command->[$i];
	 if($com->{'kind'} < 21) {
		$comStr[$com->{'x'}][$com->{'y'}].=
		 " [${j}]$H2::comName[$com->{'kind'}]";
	 }
	}
 }

 # 좌표(상)을 출력
 out("<IMG SRC=\"xbar.gif\" width=400 height=16><BR>");

 # 각 지형및 줄바꿈을 출력
 my($x, $y);
 for($y = 0; $y < $H2::islandSize; $y++) {
	# 짝 수행이면 번호 출력
 if(($y % 2) == 0) {
	 out("<IMG SRC=\"space${y}.gif\" width=16 height=32>");
	}

	# 각 지형을 출력
	for($x = 0; $x < $H2::islandSize; $x++) {
	 $l = $land->[$x][$y];
	 $lv = $landValue->[$x][$y];
	 landString($l, $lv, $x, $y, $mode, $comStr[$x][$y]);
	}

	# 홀 수행이면 번호 출력
 if(($y % 2) == 1) {
	 out("<IMG SRC=\"space${y}.gif\" width=16 height=32>");
	}

	# 줄바꿈을 출력
	out("<BR>");
 }
 out("</TD></TR></TABLE></CENTER>\n");
}

sub landString {
 my($l, $lv, $x, $y, $mode, $comStr) = @_;
 my($point) = "($x,$y)";
 my($image, $alt);

 if($l == $H2::landSea) {

	if($lv == 1) {
	 # 얕은 바다
	 $image = 'land14.gif';
	 $alt = '바다(얕은 바다)';
 } else {
 # 바다
	 $image = 'land0.gif';
	 $alt = '바다';
 }
 } elsif($l == $H2::landWaste) {
	# 황무지
	if($lv == 1) {
	 $image = 'land13.gif'; # 착탄 지점
	 $alt = '황무지';
	} elsif($lv> 1) {
	 $alt = '황무지(한 송이의 꽃)';
	 if($lv < 4) {
		$image = 'flower0.gif';
	 } else {
		$image = 'flower2.gif';
	 }
	} else {
	 $image = 'land1.gif';
	 $alt = '황무지';
	}
 } elsif($l == $H2::landPlains) {
	# 평지
	$image = 'land2.gif';
	$alt = '평지';
 } elsif($l == $H2::landForest) {
	# 숲
	if($mode == 1) {
	 $image = 'land6.gif';
	 $alt = "숲(${lv}$H2::unitTree)";
	} else {
	 # 관광객에게는 목장 수를 숨김
	 $image = 'land6.gif';
	 $alt = '숲';
	}
 } elsif($l == $H2::landTown) {
	# 마을
	my($p, $n);
	if($lv < 30) {
	 $p = 3;
	 $n = '마을';
	} elsif($lv < 100) {
	 $p = 4;
	 $n = '마을';
	} else {
	 $p = 5;
	 $n = '도시';
	}

	$image = "land${p}.gif";
	$alt = "$n(${lv}$H2::unitPop)";
 } elsif($l == $H2::landFarm) {
	# 농장
	$image = 'land7.gif';
	$alt = "농장(${lv}0${H2::unitPop}규모)";
 } elsif($l == $H2::landFactory) {
	# 공장
	$image = 'land8.gif';
	$alt = "공장(${lv}0${H2::unitPop}규모)";
 } elsif($l == $H2::landBase) {
# 미사일 기지를 원형 표시로 사용하지 않을 경우 아래 ## 6곳을 삭제
##	if($mode == 0) {
##	 # 관광객의 경우 숲인 척
##	 $image = 'land6.gif';
##	 $alt = '숲';
##	} else {
	 # 미사일 기지
	 my($level) = expToLevel($l, $lv);
	 $image = 'land9.gif';
	 $alt = "미사일 기지 (레벨 ${level}/경험치 $lv)";
##	}
 } elsif($l == $H2::landSbase) {
	# 해저 기지
	if($mode == 0) {
	 # 관광객의 경우 바다인 척
	 $image = 'land0.gif';
	 $alt = '바다';
	} else {
	 my($level) = expToLevel($l, $lv);
	 $image = 'land12.gif';
	 $alt = "해저 기지 (레벨 ${level}/경험치 $lv)";
	}
 } elsif($l == $H2::landDefence) {
	# 방위 시설
	$image = 'land10.gif';
	$alt = '방위 시설';
 } elsif($l == $H2::landHaribote) {
	# 가짜 시설
	$image = 'land10.gif';
	if($mode == 0) {
	 # 관광객에게는 방위 시설처럼 표시
	 $alt = '방위 시설';
	} else {
	 $alt = '가짜 시설';
	}
 } elsif($l == $H2::landHoihoi) {
	# 방어 시설
	$image = 'hoihoi0.gif';
	$alt = '방어 시설';
 } elsif($l == $H2::landOil) {
	# 해저 유전
	$image = 'land16.gif';
	$alt = '해저 유전';
 } elsif($l == $H2::landMountain) {
	# 산
	my($str);
	$str = '';
	if($lv> 0) {
	 $image = 'land15.gif';
	 $alt = "산(채굴장${lv}0${H2::unitPop}규모)";
	} else {
	 $image = 'land11.gif';
	 $alt = '산';
	}
 } elsif($l == $H2::landMonument) {
	# 기념비
	$image = $H2::monumentImage[$lv];
	$alt = $H2::monumentName[$lv];
### ---v--- ver1.10 ---v---
 } elsif(($l == $H2::landMonster)||($l == $H2::landMonsterS)) {
	# 괴수
	my($kind, $name, $hp) = monsterSpec($lv);
	my($special) = $H2::monsterSpecial[$kind];
	$image = $H2::monsterImage[$kind];

	# 경화 중?
	if((($special == 3) && (($H2::islandTurn % 2) == 1)) ||
	 (($special == 4) && (($H2::islandTurn % 2) == 0))) {
	 # 경화 중
	 $image = $H2::monsterImage2[$kind];
	}
	$alt = "괴수$name(체력${hp})";

	# 착탄 지점?
	if($l == $H2::landMonsterS) {
	 # 착탄 지점
	 $alt = "괴수$name(체력${hp}:착탄 지점)";
	} elsif($H2::monsterInvisible[$kind] == 1) {
	 my($ia) = ($H2::islandTurn + $lv + $x) % 5;
	 if($ia == 4) {
		$image = 'land5.gif';
		$alt = "도시(100$H2::unitPop)";
	 } elsif($ia == 3) {
		$image = 'land7.gif';
		$alt = "농장(100${H2::unitPop}규모)";
	 } elsif($ia == 2) {
		$image = 'land14.gif';
		$alt = '바다(얕은 바다)';
	 } elsif($ia == 1) {
		$image = 'land13.gif';
		$alt = '황무지';
	 } else {
		$image = 'land1.gif';
		$alt = '황무지';
	 }
	}
 }
### ---^--- ver1.10 ---^---

 # JavaScript 을이용했습니다 표시
 out(qq#<A HREF="JavaScript:void(0);" #);
 # 개발 화면일 경우 좌표 설정
 if($mode == 1) {
	out("onclick=\"ps($x,$y)\" ");
 }
 out(qq#onMouseOver="status = '$point $alt $comStr'; return true;" onMouseOut="status = '';">#);

 out("<IMG SRC=\"$image\" ALT=\"$point $alt $comStr\" width=32 height=32 BORDER=0>");

 # 좌표 설정닫기지
 out("</A>");
}


#----------------------------------------------------------------------
# 템플릿기타
#----------------------------------------------------------------------
# 개별 로그 표시
sub logPrintLocal {
 my($mode) = @_;
 my($i);
 for($i = 0; $i < $H2::logMax; $i++) {
	logFilePrint($i, $H2::currentID, $mode);
 }
}

# ○○섬으로 수 있도록 말로!!
sub tempPrintIslandHead {
 out(<<END);
<CENTER>
${H2::tagBig_}${H2::tagName_}'${H2::currentName} 섬'${H2::_tagName}되도록!!${H2::_tagBig}<BR>
$H2::tempBack<BR>
</CENTER>
END
}

# ○○섬개발계획
sub tempOwner {
 out(<<END);
<CENTER>
${H2::tagBig_}${H2::tagName_}${H2::currentName} 섬${H2::_tagName}개발계획${H2::_tagBig}<BR>
$H2::tempBack<BR>
</CENTER>
<SCRIPT>
<!--
function ps(x, y) {
 document.forms[0].elements[4].options[x].selected = true;
 document.forms[0].elements[5].options[y].selected = true;
 return true;
}

function ns(x) {
 document.forms[0].elements[2].options[x].selected = true;
 return true;
}

//-->
</SCRIPT>
END

 islandInfo();

 out(<<END);
<CENTER>
<TABLE BORDER>
<TR>
<TD $H2::bgInputCell>
<CENTER>
<FORM action="$H2::thisFile" method=POST>
<INPUT TYPE=submit VALUE="계획 전송" NAME=CommandButton$H2::islands[$H2::currentNumber]->{'id'}>
<HR>
<B> 비밀번호</B></BR>
<INPUT TYPE=password NAME=PASSWORD VALUE="$H2::defaultPassword">
<HR>
<B>계획번호</B><SELECT NAME=NUMBER>
END
 # 계획번호
 my($j, $i);
 for($i = 0; $i < $H2::commandMax; $i++) {
	$j = $i + 1;
	out("<OPTION VALUE=$i>$j\n");
 }

 out(<<END);
</SELECT><BR>
<HR>
<B>개발계획</B><BR>
<SELECT NAME=COMMAND>
END

 #명령
 my($kind, $cost, $s);
 for($i = 0; $i < $H2::commandTotal; $i++) {
	$kind = $H2::comList[$i];
	$cost = $H2::comCost[$kind];
	if($cost == 0) {
	 $cost = '무료'
	} elsif($cost < 0) {
	 $cost = - $cost;
	 $cost.= $H2::unitFood;
	} else {
	 $cost.= $H2::unitMoney;
	}
	if($kind == $H2::defaultKind) {
	 $s = 'SELECTED';
	} else {
	 $s = '';
	}
	out("<OPTION VALUE=$kind $s>$H2::comName[$kind]($cost)\n");
 }

 out(<<END);
</SELECT>
<HR>
<B>좌표(</B>
<SELECT NAME=POINTX>

END
 for($i = 0; $i < $H2::islandSize; $i++) {
	if($i == $H2::defaultX) {
	 out("<OPTION VALUE=$i SELECTED>$i\n");
 } else {
	 out("<OPTION VALUE=$i>$i\n");
 }
 }

 out(<<END);
</SELECT>, <SELECT NAME=POINTY>
END

 for($i = 0; $i < $H2::islandSize; $i++) {
	if($i == $H2::defaultY) {
	 out("<OPTION VALUE=$i SELECTED>$i\n");
 } else {
	 out("<OPTION VALUE=$i>$i\n");
 }
 }
 out(<<END);
</SELECT><B>)</B>
<HR>
<B>수량</B><SELECT NAME=AMOUNT>
END

 # 수량
 for($i = 0; $i < 100; $i++) {
	out("<OPTION VALUE=$i>$i\n");
 }

 out(<<END);
</SELECT>
<HR>
<B>대상 섬</B><BR>
<SELECT NAME=TARGETID>
$H2::targetList<BR>
</SELECT>
<HR>
<B>동작</B><BR>
<INPUT TYPE=radio NAME=COMMANDMODE VALUE=insert CHECKED>삽입
<INPUT TYPE=radio NAME=COMMANDMODE VALUE=write>덮어쓰기<BR>
<INPUT TYPE=radio NAME=COMMANDMODE VALUE=delete>삭제
<HR>
<INPUT TYPE=submit VALUE="계획 전송" NAME=CommandButton$H2::islands[$H2::currentNumber]->{'id'}>

</CENTER>
</FORM>
</TD>
<TD $H2::bgMapCell>
END
 islandMap(1); # 섬 지도, 소유자 모드
 out(<<END);
</TD>
<TD $H2::bgCommandCell>
END
 for($i = 0; $i < $H2::commandMax; $i++) {
	tempCommand($i, $H2::islands[$H2::currentNumber]->{'command'}->[$i]);
 }

 out(<<END);

</TD>
</TR>
</TABLE>
</CENTER>
<HR>
<CENTER>
${H2::tagBig_}코멘트갱신${H2::_tagBig}<BR>
<FORM action="$H2::thisFile" method="POST">
코멘트<INPUT TYPE=text NAME=MESSAGE SIZE=80><BR>
비밀번호<INPUT TYPE=password NAME=PASSWORD VALUE="$H2::defaultPassword">
<INPUT TYPE=submit VALUE="코멘트갱신" NAME=MessageButton$H2::islands[$H2::currentNumber]->{'id'}>
</FORM>
</CENTER>
END

}

# 입력 완료된 명령 표시
sub tempCommand {
 my($number, $command) = @_;
 my($kind, $target, $x, $y, $arg) =
	(
	 $command->{'kind'},
	 $command->{'target'},
	 $command->{'x'},
	 $command->{'y'},
	 $command->{'arg'}
	 );
 my($name) = "$H2::tagComName_${H2::comName[$kind]}$H2::_tagComName";
 my($point) = "$H2::tagName_($x,$y)$H2::_tagName";
 $target = $H2::idToName{$target};
 if($target eq '') {
	$target = "무인";
 }
 $target = "$H2::tagName_${target} 섬$H2::_tagName";
 my($value) = $arg * $H2::comCost[$kind];
 if($value == 0) {
	$value = $H2::comCost[$kind];
 }
 if($value < 0) {
	$value = -$value;
	$value = "$value$H2::unitFood";
 } else {
	$value = "$value$H2::unitMoney";
 }
 $value = "$H2::tagName_$value$H2::_tagName";

 my($j) = sprintf("%02d:", $number + 1);

 out("<A STYlE=\"text-decoration:none\" HREF=\"JavaScript:void(0);\" onClick=\"ns($number)\"><NOBR>$H2::tagNumber_$j$H2::_tagNumber<FONT COLOR=\"$H2::normalColor\">");

 if(($kind == $H2::comDoNothing) ||
 ($kind == $H2::comGiveup)) {
	out("$name");
 } elsif(($kind == $H2::comMissileNM) ||
	 ($kind == $H2::comMissilePP) ||
	 ($kind == $H2::comMissileST) ||
	 ($kind == $H2::comMissileTH) ||
	 ($kind == $H2::comMissileSPP) ||
	 ($kind == $H2::comMissileSTI) ||
	 ($kind == $H2::comMissileLD)) {
	# 미사일계
	my($n) = ($arg == 0 ? '무제한' : "${arg}발");
	out("$target$point 로$name($H2::tagName_$n$H2::_tagName)");
 } elsif($kind == $H2::comSendMonster) {
	# 괴수 파견
	out("$target 로$name");
 } elsif($kind == $H2::comSell) {
	# 식량 수출
	out("$name$value");
 } elsif($kind == $H2::comPropaganda) {
	# 유치 활동
	# 횟수 포함
	if($arg == 0) {
	 out("$name(1회)");
	} else {
	 out("$name($arg 회)");
	}
 } elsif(($kind == $H2::comMoney) ||
	 ($kind == $H2::comFood)) {
	# 지원
	out("$target 로$name$value");
 } elsif($kind == $H2::comDestroy) {
	# 굴착
	if($arg != 0) {
	 out("$point 에서$name(예산${value})");
	} else {
	 out("$point 에서$name");
	}
 } elsif(($kind == $H2::comFarm) ||
	 ($kind == $H2::comFactory) ||
	 ($kind == $H2::comReclaim) ||
	 ($kind == $H2::comMountain)) {
	# 농장 건설 공장 건설 매립 채굴장 건설
	# 횟수 포함
	if($arg == 0) {
	 out("$point 에서$name");
	} else {
	 out("$point 에서$name($arg회)");
	}
 } else {
	# 좌표 포함
	out("$point 에서$name");
 }

 out("</FONT></NOBR></A><BR>");
}

# 로컬 게시판
sub tempLbbsHead {
 out(<<END);
<HR>
<CENTER>
${H2::tagBig_}${H2::tagName_}${H2::currentName} 섬${H2::_tagName}관광객 통신${H2::_tagBig}<BR>
</CENTER>
END
}

# 로컬 게시판입력 양식
sub tempLbbsInput {
 out(<<END);
<CENTER>
<FORM action="$H2::thisFile" method="POST">
<TABLE BORDER>
<TR>
<TH>이름</TH>
<TH>내용</TH>
<TH>동작</TH>
</TR>
<TR>
<TD><INPUT TYPE="text" SIZE=32 MAXLENGTH=32 NAME="LBBSNAME" VALUE="$H2::defaultName"></TD>
<TD><INPUT TYPE="text" SIZE=80 NAME="LBBSMESSAGE"></TD>
<TD><INPUT TYPE="submit" VALUE="등록" NAME="LbbsButtonSS$H2::currentID"></TD>
</TR>
</TABLE>
</FORM>
</CENTER>
END
}

# 로컬 게시판입력 양식 owner mode 용
sub tempLbbsInputOW {
 out(<<END);
<CENTER>
<FORM action="$H2::thisFile" method="POST">
<TABLE BORDER>
<TR>
<TH>이름</TH>
<TH COLSPAN=2>내용</TH>
</TR>
<TR>
<TD><INPUT TYPE="text" SIZE=32 MAXLENGTH=32 NAME="LBBSNAME" VALUE="$H2::defaultName"></TD>
<TD COLSPAN=2><INPUT TYPE="text" SIZE=80 NAME="LBBSMESSAGE"></TD>
</TR>
<TR>
<TH> 비밀번호</TH>
<TH COLSPAN=2>동작</TH>
</TR>
<TR>
<TD><INPUT TYPE=password SIZE=32 MAXLENGTH=32 NAME=PASSWORD VALUE="$H2::defaultPassword"></TD>
<TD align=right>
<INPUT TYPE="submit" VALUE="등록" NAME="LbbsButtonOW$H2::currentID">
</TD>
<TD align=right>
번호
<SELECT NAME=NUMBER>
END
 # 발언번호
 my($j, $i);
 for($i = 0; $i < $H2::lbbsMax; $i++) {
	$j = $i + 1;
	out("<OPTION VALUE=$i>$j\n");
 }
 out(<<END);
</SELECT>
<INPUT TYPE="submit" VALUE="삭제" NAME="LbbsButtonDL$H2::currentID">
</TD>
</TR>
</TABLE>
</FORM>
</CENTER>
END
}

# 로컬 게시판내용
sub tempLbbsContents {
 my($lbbs, $line);
 $lbbs = $H2::islands[$H2::currentNumber]->{'lbbs'};
 out(<<END);
<CENTER>
<TABLE BORDER>
<TR>
<TH>번호</TH>
<TH>내용</TH>
</TR>
END

 my($i);
 for($i = 0; $i < $H2::lbbsMax; $i++) {
	$line = $lbbs->[$i];
	if($line =~ /([0-9]*)\>(.*)\>(.*)$/) {
	 my($j) = $i + 1;
	 out("<TR><TD align=center>$H2::tagNumber_$j$H2::_tagNumber</TD>");
	 if($1 == 0) {
		# 관광객
		out("<TD>$H2::tagLbbsSS_$2> $3$H2::_tagLbbsSS</TD></TR>");
	 } elsif($1 == 2) {
		# 타 섬주
		# 메시지에 탭 구분으로 추가한 섬 이름을 분리
		my($i_mess,$i_name) = split(/\t/, $3);
		out("<TD>$H2::tagLbbsAOW_$2> $i_mess$H2::_tagLbbsAOW<font size=2 color=#008080>($i_name)</font></TD></TR>");
	 } else {
		# 섬주
		out("<TD>$H2::tagLbbsOW_$2> $3$H2::_tagLbbsOW</TD></TR>");
	 }
	}
 }

 out(<<END);
</TD></TR></TABLE></CENTER>
END
}

# 로컬 게시판에서 이름이나 메시지가 없는 경우
sub tempLbbsNoMessage {
 out(<<END);
${H2::tagBig_}이름 또는 내용이 비어 있습니다..${H2::_tagBig}$H2::tempBack
END
}

# 쓰기/삭제
sub tempLbbsDelete {
 out(<<END);
${H2::tagBig_}기록 내용을 삭제했습니다${H2::_tagBig}<HR>
END
}

# 명령 등록
sub tempLbbsAdd {
 out(<<END);
${H2::tagBig_}기록을 수행했습니다${H2::_tagBig}<HR>
END
}

# 명령 삭제
sub tempCommandDelete {
 out(<<END);
${H2::tagBig_} 명령을 삭제했습니다${H2::_tagBig}<HR>
END
}

# 명령 등록
sub tempCommandAdd {
 out(<<END);
${H2::tagBig_} 명령을 등록했습니다${H2::_tagBig}<HR>
END
}

# 코멘트 변경성공
sub tempComment {
 out(<<END);
${H2::tagBig_}코멘트를 갱신했습니다${H2::_tagBig}<HR>
END
}

# 최근 상황
sub tempRecent {
 my($mode) = @_;
 out(<<END);
<HR>
${H2::tagBig_}${H2::tagName_}${H2::currentName} 섬${H2::_tagName}의 최근 상황${H2::_tagBig}<BR>
END
 logPrintLocal($mode);
}

1;
