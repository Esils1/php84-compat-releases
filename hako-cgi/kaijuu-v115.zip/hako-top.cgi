#!/usr/bin/perl
BEGIN {
 require FindBin;
 FindBin->import();
 chdir $FindBin::Bin or die "chdir $FindBin::Bin: $!";
 unshift @INC, $FindBin::Bin;
}
#----------------------------------------------------------------------
# 모형정원 제도 ver2.20
# 톱 페이지 모듈
# 사용 조건과 사용 방법은 hako-readme.txt 파일을 참조해 주세요
#
# 모형정원 제도의 페이지: http://www.bekkoame.ne.jp/~tokuoka/hakoniwa.html
#----------------------------------------------------------------------
# 괴수퇴치제도 ver1.15
# 톱 페이지 모듈(ver1.15)
# Arranged by 차차마루
# 사용 조건등은,readme.txt 파일을 참조
# 배포페이지: http://www.geocities.co.jp/SiliconValley-Bay/2566/
#
# [이력]
# v1.00 2000/03/12 처음판
# 2000/05/07 일반배포시작
# v1.10 2000/06/11
# v1.15 2000/07/01
#----------------------------------------------------------------------

package H2;

#----------------------------------------------------------------------
# 톱 페이지 모드
#----------------------------------------------------------------------
# 메인
sub topPageMain {
 # 개방
 unlock();

 # 템플릿출력
 tempTopPage();
}

# 톱 페이지
sub tempTopPage {
 # 제목
 out(<<END);
${H2::tagTitle_}$H2::title${H2::_tagTitle}
END

 # 디버그 모드이면 '턴 진행' 버튼
 if($H2::debug == 1) {
 out(<<END);
<FORM action="$H2::thisFile" method="POST">
<INPUT TYPE="submit" VALUE="턴을 진행하기" NAME="TurnButton">
</FORM>
END
 }

 my($mStr1) = '';
 if($H2::hideMoneyMode != 0) {
	$mStr1 = "<TH $H2::bgTitleCell align=center nowrap=nowrap><NOBR>${H2::tagTH_} 자금${H2::_tagTH}</NOBR></TH>";
 }
### ---v--- ver1.10 ---v---
 my($mStr2) = '';
 if($H2::startTurnPrint == 1) {
	$mStr2 = "<TH $H2::bgTitleCell align=center nowrap=nowrap><NOBR>${H2::tagTH_}턴${H2::_tagTH}</NOBR></TH>";
 }
### ---^--- ver1.10 ---^---

 # 양식
 out(<<END);
<P>
<FONT SIZE=6><B>${H2::tagHeader_}턴$H2::islandTurn${H2::_tagHeader}</B></FONT>
END

### ---v--- ver1.10 ---v---
 if(($H2::lastTurn == 0)||($H2::islandTurn < $H2::lastTurn)) {
	# 다음 턴 진행까지의 시간 표시
	nextTurnTimePrint();
 } else {
	out(" <B>종료했습니다.</B>\n");
 }
### ---^--- ver1.10 ---^---

 out(<<END);### $mStr2을 추가(ver1.10)
</P>
<HR>
<!--### ---v--- ver1.15 ---v--- ###-->
END

 out(<<END);
<!--### ---^--- ver1.15 ---^--- ###-->
<H1>${H2::tagHeader_}자신의 섬으로${H2::_tagHeader}</H1>
<FORM action="$H2::thisFile" method="POST">
당신의 섬 이름은?<BR>
<SELECT NAME="ISLANDID">
$H2::islandList
</SELECT><BR>

비밀번호 입력!!<BR>
<INPUT TYPE="password" NAME="PASSWORD" VALUE="$H2::defaultPassword" SIZE=32 MAXLENGTH=32><BR>
<INPUT TYPE="radio" VALUE="0" NAME="JAVAMODE" CHECKED>통상 모드
<INPUT TYPE="radio" VALUE="1" NAME="JAVAMODE">JavaScript 모드<BR>
<INPUT TYPE="submit" VALUE="개발 화면으로" NAME="OwnerButton"><BR>
</FORM>
<!--### ---v--- ver1.15 ---v--- ###-->
END

 out(<<END);
<!--### ---^--- ver1.15 ---^--- ###-->
<HR>

<H1>${H2::tagHeader_}섬의 정보${H2::_tagHeader}</H1>
<P>
섬 이름을 클릭하면,<B>관광</B>할 수 있습니다.
</P>
<TABLE BORDER>
<TR>
<TH $H2::bgTitleCell align=center nowrap=nowrap><NOBR>${H2::tagTH_}순위${H2::_tagTH}</NOBR></TH>
<TH $H2::bgTitleCell align=center nowrap=nowrap><NOBR>${H2::tagTH_} 섬${H2::_tagTH}</NOBR></TH>
<TH $H2::bgTitleCell align=center nowrap=nowrap><NOBR>${H2::tagTH_}포인트${H2::_tagTH}</NOBR></TH>
<TH $H2::bgTitleCell align=center nowrap=nowrap><NOBR>${H2::tagTH_}인구${H2::_tagTH}</NOBR></TH>
<TH $H2::bgTitleCell align=center nowrap=nowrap><NOBR>${H2::tagTH_}면적${H2::_tagTH}</NOBR></TH>
$mStr1
<TH $H2::bgTitleCell align=center nowrap=nowrap><NOBR>${H2::tagTH_}식량${H2::_tagTH}</NOBR></TH>
<TH $H2::bgTitleCell align=center nowrap=nowrap><NOBR>${H2::tagTH_}농장규모${H2::_tagTH}</NOBR></TH>
<TH $H2::bgTitleCell align=center nowrap=nowrap><NOBR>${H2::tagTH_}공장규모${H2::_tagTH}</NOBR></TH>
<TH $H2::bgTitleCell align=center nowrap=nowrap><NOBR>${H2::tagTH_}채굴장규모${H2::_tagTH}</NOBR></TH>
$mStr2
</TR>
END

 my($island, $j, $farm, $factory, $mountain, $name, $id, $prize, $ii, $comment_line, $comment, $host);
 for($ii = 0; $ii < $H2::islandNumber; $ii++) {
	$j = $ii + 1;
	$island = $H2::islands[$ii];

	$comment_line = $island->{'comment'}; ### 코멘트과 원격 호스트(탭 구분)
	($comment,$host) = split(/\t/,$comment_line,2); ### 분리
	# 이하 표시용의 조정
	if ($host =~ /(.*)\.(\d+)$/) { ; }
	elsif ($host =~ /(.*)\.(.*)\.(.*)\.(.*)$/) { $host = "\*\.$2\.$3\.$4"; }
	elsif ($host =~ /(.*)\.(.*)\.(.*)$/) { $host = "\*\.$2\.$3"; }

	$id = $island->{'id'};
	$farm = $island->{'farm'};
	$factory = $island->{'factory'};
	$mountain = $island->{'mountain'};
	$farm = ($farm == 0) ? "보유하지 않음" : "${farm}0$H2::unitPop";
	$factory = ($factory == 0) ? "보유하지 않음" : "${factory}0$H2::unitPop";
	$mountain = ($mountain == 0) ? "보유하지 않음" : "${mountain}0$H2::unitPop";
	if($island->{'absent'} == 0) {
	 $name = "${H2::tagName_}$island->{'name'} 섬${H2::_tagName}";
	} else {
	 $name = "${H2::tagName2_}$island->{'name'} 섬($island->{'absent'})${H2::_tagName2}";
	}

	$prize = $island->{'prize'};
	my($flags, $monsters, $turns);
	$prize =~ /([0-9]*),([0-9]*),(.*)/;
	$flags = $1;
	$monsters= $2;
	$turns = $3;
	$prize = '';

	# 남은 턴 표시
	while($turns =~ s/([0-9]*),//) {
	 # JavaScript 을이용했습니다 표시
	 $prize.= <<EOP;
<A HREF="JavaScript:void(0);" onMouseOver="status = '$1${H2::prize[0]}'; return true;" onMouseOut="status = '';">
<IMG SRC="prize0.gif" ALT="$1${H2::prize[0]}" WIDTH=16 HEIGHT=16 BORDER=0></A>
EOP
	}

	# 이름에 순위 표시 문자를 추가
	my($f) = 1;
	my($i);
	for($i = 1; $i < 10; $i++) {
	 if($flags & $f) {
		# JavaScript 을이용했습니다 표시
		$prize.= <<EOP;
<A HREF="JavaScript:void(0);" onMouseOver="status = '${H2::prize[$i]}'; return true;" onMouseOut="status = '';">
<IMG SRC="prize${i}.gif" ALT="${H2::prize[$i]}" WIDTH=16 HEIGHT=16 BORDER=0></A>
EOP
	 }
	 $f *= 2;
	}

	# 쓰러뜨린 괴수 목록
	$f = 1;
	my($max) = -1;
	my($mNameList) = '';
	for($i = 0; $i < $H2::monsterNumber; $i++) {
	 if($monsters & $f) {
		$mNameList.= "[$H2::monsterName[$i]] ";
		$max = $i;
	 }
	 $f *= 2;
	}
	if($max != -1) {
	 # JavaScript 을이용했습니다 표시
	 $prize.= <<EOP;
<A HREF="JavaScript:void(0);" onMouseOver="status = '$mNameList'; return true;" onMouseOut="status = '';">
<IMG SRC="${H2::monsterImage[$max]}" ALT="$mNameList" WIDTH=16 HEIGHT=16 BORDER=0></A>
EOP
	}


### ---v--- ver1.10 ---v---
	my($commentColspan) = 7;
	my($mStr1) = '';
	if($H2::hideMoneyMode == 1) {
	 $mStr1 = "<TD $H2::bgInfoCell align=right nowrap=nowrap><NOBR>$island->{'money'}$H2::unitMoney</NOBR></TD>";
	 $commentColspan++;
	} elsif($H2::hideMoneyMode == 2) {
	 my($mTmp) = aboutMoney($island->{'money'});
	 $mStr1 = "<TD $H2::bgInfoCell align=right nowrap=nowrap><NOBR>$mTmp</NOBR></TD>";
	 $commentColspan++;
	}
	my($mStr2) = '';
	if($H2::startTurnPrint == 1) {
	 $mStr2 = "<TD $H2::bgInfoCell align=right nowrap=nowrap><NOBR>$island->{'sturn'}턴</NOBR></TD>";
	 $commentColspan++;
	}
### ---^--- ver1.10 ---^---

# 리도와 호스트(또는 IP 주소)의 소스 표시있음
	out(<<END);### $mStr2을 추가,COLSPAN=${commentColspan} 에 변경(ver1.10)
<TR>
<TD $H2::bgNumberCell ROWSPAN=2 align=center nowrap=nowrap><NOBR>${H2::tagNumber_}$j${H2::_tagNumber}</NOBR></TD>
<TD $H2::bgNameCell ROWSPAN=2 align=left nowrap=nowrap>
<NOBR>
<A STYlE=\"text-decoration:none\" HREF="${H2::thisFile}?Sight=${id}">
$name
</A><!--$host-->
</NOBR><BR>
$prize
</TD>
<TD $H2::bgInfoCell align=right nowrap=nowrap>
<NOBR>$island->{'score'}점</NOBR></TD>
<TD $H2::bgInfoCell align=right nowrap=nowrap>
<NOBR>$island->{'pop'}$H2::unitPop</NOBR></TD>
<TD $H2::bgInfoCell align=right nowrap=nowrap><NOBR>$island->{'area'}$H2::unitArea</NOBR></TD>
$mStr1
<TD $H2::bgInfoCell align=right nowrap=nowrap><NOBR>$island->{'food'}$H2::unitFood</NOBR></TD>
<TD $H2::bgInfoCell align=right nowrap=nowrap><NOBR>$farm</NOBR></TD>
<TD $H2::bgInfoCell align=right nowrap=nowrap><NOBR>$factory</NOBR></TD>
<TD $H2::bgInfoCell align=right nowrap=nowrap><NOBR>$mountain</NOBR></TD>
$mStr2
</TR>
<TR>
<TD $H2::bgCommentCell COLSPAN=${commentColspan} align=left nowrap=nowrap><NOBR>${H2::tagTH_}코멘트:${H2::_tagTH}$comment</NOBR></TD>
</TR>
END
 }

 out(<<END);
</TABLE>

<HR>
<H1>${H2::tagHeader_}새 섬을 탐색${H2::_tagHeader}</H1>
END

 if($H2::islandNumber < $H2::maxIsland) {
	out(<<END);
<FORM action="$H2::thisFile" method="POST">
섬 이름<BR>
<INPUT TYPE="text" NAME="ISLANDNAME" SIZE=32 MAXLENGTH=32> 섬<BR>
비밀번호<BR>
<INPUT TYPE="password" NAME="PASSWORD" SIZE=32 MAXLENGTH=32><BR>
비밀번호 재확인<BR>
<INPUT TYPE="password" NAME="PASSWORD2" SIZE=32 MAXLENGTH=32><BR>

<INPUT TYPE="submit" VALUE="찾으러 가기" NAME="NewIslandButton">
</FORM>
END
 } else {
	out(<<END);
 섬의 수가 최대 수입니다... 현재 등록할 수 없습니다.
END
 }

 out(<<END);
<HR>
<H1>${H2::tagHeader_} 정보 변경${H2::_tagHeader}</H1>
<P>
(주의) 이름 변경에는 $H2::costChangeName${H2::unitMoney}이 들어갑니다.
</P>
<FORM action="$H2::thisFile" method="POST">
어느 섬입니까?<BR>
<SELECT NAME="ISLANDID">
$H2::islandList
</SELECT>
<BR>
새 이름을 입력하세요(변경하는 경우만)<BR>
<INPUT TYPE="text" NAME="ISLANDNAME" SIZE=32 MAXLENGTH=32> 섬<BR>
비밀번호(필수)<BR>
<INPUT TYPE="password" NAME="OLDPASS" SIZE=32 MAXLENGTH=32><BR>
새 비밀번호(변경할 경우만)<BR>
<INPUT TYPE="password" NAME="PASSWORD" SIZE=32 MAXLENGTH=32><BR>
비밀번호 재확인(변경할 경우만)<BR>
<INPUT TYPE="password" NAME="PASSWORD2" SIZE=32 MAXLENGTH=32><BR>

<INPUT TYPE="submit" VALUE="변경" NAME="ChangeInfoButton">
</FORM>

<HR>

<H1>${H2::tagHeader_}최근 사건${H2::_tagHeader}</H1>
END
 logPrintTop();
 out(<<END);
<H1>${H2::tagHeader_}발견 기록${H2::_tagHeader}</H1>
END
 historyPrint();
}

# 톱 페이지용 로그 표시
sub logPrintTop {
 my($i);
 for($i = 0; $i < $H2::topLogTurn; $i++) {
	logFilePrint($i, 0, 0);
 }
}

# 기록 파일 표시
sub historyPrint {
 open(HIN, "${H2::dirName}/hakojima.his");
 my(@line, $l);
 while($l = <HIN>) {
	chomp($l);
	push(@line, $l);
 }
 @line = reverse(@line);

 foreach $l (@line) {
	$l =~ /^([0-9]*),(.*)$/;
	out("<NOBR>${H2::tagNumber_}턴${1}${H2::_tagNumber}:${2}</NOBR><BR>\n");
 }
 close(HIN);
}

# 다음 턴 진행까지의 시간 표시
sub nextTurnTimePrint {
	my($Now) = time;
	my($Rest) = $H2::islandLastTime + $H2::unitTime - $Now;
	my($Restjikan) = int($Rest / 3600);
	my($Resthun) = int(($Rest % 3600) / 60);
	out(" <B>다음 턴 진행까지, 남은$Restjikan 시간$Resthun 분</B>\n");
}

1;
